# R398 cumulative low-rank bridge audit — FINAL PASS

FINAL PASS for the cumulative positive-switch decomposition, direct closed-rank source payments, full coefficients and explicitly unpaid high-rank remainder. No general core/root bound is certified. Only this audit file is edited. The independent screen below preceded the author proof; its initial F/log method is a valid weaker preliminary route, superseded by the direct CDF receipt below. Fix the same actual full f, original receiver field and marked gamma_0 from R397. Nested gamma_i are positive endpoint restrictions of gamma_0. Their outgoing/incoming capacities remain beta sigma and C_col sigma, sigma=qdu. The witness z sampled under full pi_u or pi_v is not the old transported source and does not inherit its historical qualification.

## Cumulative switch mark and captured part

For increasing thresholds the R397 mark is b_i(z)=Delta min(f,T_i)/f times (1-s/D_i)_+, zero on f=0 or D_i=0. Therefore sum_i b_i(z)<=1 pointwise. With gamma_i<=gamma_0, any nonnegative endpoint witness cost can be summed by bounding its cumulative b mark under the one original gamma_0. No number of stages is paid.

For strict far mass m_u>K m_v, pi_u(c_v)=f(Qu intersect Qv)/m_u<=m_v/m_u<1/K. Thus the captured large-end switching part

    B_cap=sum_i integral gamma_i pi_u(b_i c_v)

is <=G_0/K. This is a piece of the positive switching bill, not a new separately spendable old capture-square credit.

## Large-end external low-Z and small-end low-T

Use the unchanged full global source rank T_u(z)=T_z(m_u), strict smaller occupation Z_u(z)=Z_z(m_u/K-), and F_u=pi_u[h/(h+T_u)]. The actual closed-window envelope gives 0<=T_u-Z_u<=B_K=epsilon0 h. Hence on Z_u<=Lh,

    h/(h+T_u)>=1/(1+L+epsilon0),
    pi_u{Z_u<=Lh}<=(1+L+epsilon0)F_u.

After summing b_i under gamma_0, dropping the external condition only enlarges the bound, and outgoing capacity yields

    B_ext,lowZ<=beta(1+L+epsilon0) integral sigma F_u.

Likewise under pi_v the low closed-rank set T_v<=Lh has probability <=(1+L)F_v. The incoming capacity relative to actual qdv gives

    B_small,lowT<=C_col(1+L) integral sigma F_v.

These use different endpoint posteriors but the same unchanged complete source and global rank field. There is no replacement of the original source by a newly qualified current source or an artificial next receiver history.

## Native du rank-witness budget, including atoms

By full matching and positive Fubini,

    integral sigma F
      =h integral f(z) integral q_u c_u(z)
            /[m_u(h+T_z(m_u))]du dz
      <=lambda h integral f(z) integral rho_z(du)/(h+T_z(m_u)) dz.

Under the rank measure rho_z, every mass atom occupies a whole rank interval and its CLOSED endpoint T_z(m_u) is at least every rank in that interval. The decreasing function 1/(h+t) therefore gives

    integral rho_z/(h+T_z(m_u))
       <=integral_0^(J_b(z)) dt/(h+t)
       =log(1+J_b(z)/h).

This includes first and terminal mass atoms and requires no atom splitting or absent first-crossing assumption. Zero occupation contributes zero. Thus

    integral sigma F<=lambda h log(1+J_max/h) W.

All units and q weights are retained; replacing sigma by du without q would change the coefficient. With fixed L and the already synchronized h this is a root/polylogarithmic source price with its actual epsilon0/constants, not an unconditional new budget for all switching costs.

## Exact remaining switch measure

Combining these bounds gives a once-only upper bound on the actual cumulative switch bill by

    G_0/K
    +[beta(1+L+epsilon0)+C_col(1+L)]
       lambda h log(1+J_max/h)W
    +B_ext,highZ+B_small,highT.

The residuals retain b_i and gamma_i and use the exact complementary gates external Z_u>Lh or small T_v>Lh. They are positive parts of the switch measure, not discarded tails. At high external Z one can normalize an additional actual-smaller receiver through its true Z_u(z); its E_uv/Z normalizer and all old labels must remain. This creates an auxiliary witness measure and does not grant that receiver a historical outgoing row or core property.

The R397 master inequality, its theta/rho coefficients, initial potential and old ledger must still be carried when using this result. In particular no proof that the entire original gamma traffic is paid follows simply from a positive switching-price decomposition. Even a possible small G/K absorption leaves the high-rank residuals to be budgeted. No new blanket root closure is certified.

Reviewer actually ran 101 exact Fraction scalar checks of cumulative b<=1 and the two witness inequalities. They are execution-only bounded scalar diagnostics, not a native core fixture or proof of geometry. No R398 author proof was read before this screen. The complete final author and bookkeeping review follows.


## Stronger direct low-rank receipt independently screened (preferred)

The logarithmic witness route above is valid but unnecessary for these LOW-rank pieces. For every finite source rank measure rho_z with CLOSED CDF T_z, the entire set of mass atoms/continuum ranks satisfying T_z(m)<=a h has rho_z-mass at most a h. A crossing atom is excluded as a whole; no additional first-atom term occurs. This statement would fail for a strict LEFT CDF, so the endpoint convention is essential.

Actual matching and Tonelli therefore give

    integral sigma(du) pi_u{T_u<=a h}
      <=lambda integral f(z) rho_z{T_z(m)<=a h}dz
      <=lambda a h W.

Together with T_u-Z_u<=epsilon0 h and the cumulative marks, the preferred receipts are

    P_ext,lowZ<=beta lambda (L+epsilon0)h W,
    P_small,lowT<=C_col lambda Lh W,
    P_L=lambda h[beta(L+epsilon0)+C_col L].

There is no extra logarithm or stage factor. At L=0 the large-end zero-Z piece has price beta lambda epsilon0 h W, and the small-end T=0 sublevel has rank measure zero. These are payments of actual positive SWITCHING components; they do not authorize recycling an already charged R388/R390 payment on another measure.

Reviewer actually ran 162 Fraction finite-atomic closed-rank sublevel checks; all passed. The earlier 101 scalar checks and 162 are separate reviewer-only bounded diagnostics, not additional author/parent experiment counts and not native core realizations.

## Geometry support checkpoint reviewed

Read r398_geometry.md and the exact extracted script/result. Strict far m_u>K m_v implies the CLOSED occupation T_v(z)<=the STRICT smaller occupation Z_u(z) for every z, including equal-mass atoms of w at m_v. The support of pi_v is Qv, whereas the external lift is supported outside Qv. Thus rank inclusion cannot transfer a small-posterior source cost into that external lift at the same source.

The shared posterior relation pi_u(b_i c_v)=(m_v/m_u)pi_v(b_i c_u) has the stated direction. It makes the large-end shared switching term cheap; reversing it would lose the far ratio. The exact external reweighting E_uv integral (b_i/Z_u)1_highZ dnu_ext retains a nonzero Z denominator. A lower bound on E_uv alone does not upper-bound E_uv/Z_u. The summed pointwise source budget is not a cross-source coupling. No assertion of impossibility or native-core counterexample is made.

Reviewer actually reran r398_geometry_check.py: exit 0, 1176 Fraction checks. It is exactly the embedded block after outer whitespace removal. These check rank inclusion and support in source-cell/receiver-quadrature examples with rational K=2. They do not prove the proposed high-small/high-external comparison, qualify a new receiver history or pay the high residuals.

## Preliminary main/readme coefficient audit

Read the current parent main/readme. Inserting the shared G0/K and preferred P_L into the R397 inequality with theta=1/4,rho=1/2 gives G0/8<=sW+G0/K+P_LW+R_L. For n>=9, K>=exp(3)>16, so G0<=16R_L+16(s+P_L)W. Hence

    BH<=32R_L+E387 X_q+[S390+40s+32P_L]W,

and the entrance coefficients 64R_L, 80s and 64P_L before the outer Lambda are correct. Old fees are not doubled or omitted. For n<=8 the actual identity 2G0=integral fD0 and D0<=S A_n give the separate price G0<=S(1+8log2)W/2. No root closure or positive fixed paid fraction is claimed, and the enlarged residual coefficient is explicit.

The user-PDF reading/rendering in the parent report is a parent action/provenance statement, not an additional source verification performed by this audit. The completed final bridge review follows. The exact two high residuals and master coefficients must remain in the final report.


## Final bridge proof and full bookkeeping review

Read the entire r398_bridge.md, r398_exactcheck.py, its result and the final main/readme. The bridge proof is consistent with the independent direct-CDF derivation. All stages use the SAME original endpoint-restricted gamma0 and full pi, with no source, q, mass, rank, clock or historical recomputation. The cumulative b bound follows just from monotone min(f,T) increments and the factor in [0,1]. For finite sums all integrals are positive; monotone convergence supplies the infinite sum. No stage-dependent matching or new receiver qualification is introduced.

The actual-center closed-window bound has the correct endpoints and 1/q_- coefficient, and its strict-left complement gives T_u-Z_u<=epsilon0 h. The CLOSED rank sublevel has occupation at most its threshold, including first/crossing/terminal mass atoms. The direct native-du source integration keeps q_u<=lambda. It is this direct bound, NOT the preliminary logarithmic F bound, that the final price uses.

The five-term split is exact and nonnegative: large shared, large external low/high Z, small low/high T. The stronger shared relation B_cap<=B_small/K<=G0/K is correct. Source marks are summed before applying beta sigma or C_col sigma, giving one price across all stages. There is no missing q conversion or extra first-atom constant. At L=0 it pays the external zero-Z term beta lambda epsilon0 h W; the small zero-closed-rank part has zero rank mass.

The two high terms remain actual sums against gamma_i,b_i and their respective full endpoint posteriors. The external lift keeps its E_uv/Z_u factor and the original normalized source probability. Neither a lower E_uv bound nor T_v<=Z_u controls the high-small cost through the external law; their source supports differ. Full matching of an unmarked difference-set mass cannot transfer the actual stage/source weight between points. These are unpaid joint geometric tasks, not omitted parts of the proof or claims of impossibility.

The R397 master inequality uses its initial potential, theta=1/4,rho=1/2 and s=1+sqrt(n): G0/8<=sW+B. It has not been replaced by an unjustified statement that switching cost equals original gamma traffic. For n>=9, K>=exp(3)>16 gives the coefficient 16 after absorbing ONLY G0/K. The price is

    G0<=16R_L+16(s+P_L)W,
    P_L=lambda h[beta(L+epsilon0)+C_col L].

The exact coefficient 1/(1/8-1/K) could be retained; 16 is conservative. The full n<=8 complement independently follows from 2G0=integral fD0 and D0<=S A_n, giving S(1+8log2)W/2. No dimensions are discarded. With synchronized h the coefficient is root dimension times the explicitly frozen epsilon0^-1 and other parameters, with no additional CDF logarithm.

The final parent BH and entrance substitutions have the correct constants:

    BH<=32R_L+E387 X_q+[S390+40s+32P_L]W,

and, before the outer Lambda, the entrance contains 64R_L, 2E387 X_q, [2S390+80s+64P_L]W plus the unchanged 8lambda H W and 2d_eff A_n Wnu/H. No old internal fee is deleted or charged twice, and no new X coefficient is used. A future R_L<=delta X_q+CW would incur 64Lambda delta absorption. The larger residual coefficient prevents asserting that the new ledger beats the old on every input or pays a fixed positive fraction of the original core.

## Actual final numerical checks

Reviewer ACTUALLY ran final r398_exactcheck.py: exit 0, 3003 Fraction checks, split 432 marked-nested, 384 atomic-boundary and 2187 expanded-atoms. Reviewer also ran r398_geometry_check.py: 1176 Fraction checks. The latter is the proof's embedded Python block with only surrounding whitespace stripped. Parent reruns are repetitions of those same cases, not new independent counts.

The marked models use finite source incidence, receiver quadrature, rational K=2 and their actually computed mass-window capacity. They include positive endpoint costs and exact nested endpoint restrictions. Their variable q factors are actual algebraic weights; they do not assert native cube radii/du or the exponential gap and synchronized historical/core gates. The atomic stress cases correctly exclude a whole crossing atom using the closed endpoint. The analytic center/Tonelli/CDF proof, not these diagnostics, supplies the general real-du statement.

Reviewer-only preliminary 101 and 162 scalar checks are execution diagnostics and are not merged into the parent's 3003+1176. No new MATLAB or dimension-rate experiment is claimed. The final main/readme correctly state the revised exactcheck filename, counts, no-stage/no-extra-log payment, two high residuals, small-dimension complement and lack of general closure. The parent PDF reading/rendering statement is provenance, not a fresh independent verification of that document in this audit.

FINAL PASS covers this once-only application of old center/rank tools to the distinct cumulative switch bill. R_L, the general original core budget, and the old H/soft/entry/scale/history/time-atom/limit costs remain unproved or payable as explicitly stated. No new history transition, negative-square credit reuse or blanket theorem is certified.

## Frozen SHA256 bindings

Older /tmp dependencies were cleaned during finalization. Their authoritative archive members are bound directly below, without recreating or modifying those files. The relevant archived R390 lift/support paragraph was reread; inherited definitions are not a re-audit of the entire historical reduction.

- `/tmp/r398_main.md`: `67c0afa0d5cadb3784592fbcbf74860deecf58bf8a3b68727d88fc5531f13c8e`
- `/tmp/r398_readme.md`: `f038b5b29bcb766facdab2ce8178ad2d2fd62d9628126fe29b60cc4c0870978e`
- `/tmp/r398_bridge.md`: `359cb19f6ff267eb8b88e618f67313d7f386c330281cae49a8d40f526e16bd00`
- `/tmp/r398_exactcheck.py`: `6c7686c6a9a3a10d38b5aeb51e44aa26694f95cc8ae12e09cf876bee977306a9`
- `/tmp/r398_bridge.result.txt`: `793a3c625c222ac788a7aeb45289254d8cf5c3e7c12481c671b93d95920447f8`
- `/tmp/r398_geometry.md`: `fe624ad8fc696823fb6b78b2b2617b5d88029d127948e17a4ba5b163e405be53`
- `/tmp/r398_geometry_check.py`: `acb8f174d8e80cd4572edddfe5538338df3c37a078d429157746bde416dd86e7`
- `/tmp/r398_geometry.result.txt`: `96e5397642b0186b40d5ddde02c89f286cd35d1439d5e2a0cac9ed770e8d51f2`
- `/tmp/r390_aux.md`: `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/397/research.zip::r397_source.md`: `897f5256b56b482c9f964a690471de940dd771022048912f92ebf5fb6ff9381a`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/390/research.zip::r390_geometry.md`: `4cc51254b6d0314500888c61d65ff09c43890a50efdda600c05fae75bff45b34`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/391/research.zip::r391_geometry.md`: `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/397/research.zip::r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
