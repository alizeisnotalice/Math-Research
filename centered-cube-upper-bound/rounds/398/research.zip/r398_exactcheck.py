from fractions import Fraction as F
from itertools import product
cnt={'marked_nested':0,'atomic_boundary':0,'expanded_atoms':0}
patterns=[(1,1,1),(1,0,0),(0,1,0),(0,0,1)]
for fs in ((1,2,4),(1,3,5),(2,3,7)):
 f=list(map(F,fs)); masses=[sum(f[z]*c[z] for z in range(3)) for c in patterns]
 K=F(2); edges=[(0,1),(0,2),(3,1)]
 assert all(masses[u]>K*masses[v] for u,v in edges)
 for qs in ((F(1),)*4,(F(3,4),F(1),F(7,8),F(3,4))):
  for dw in ((F(1,4),F(1,5),F(1,6),F(1,7)),(F(1,3),F(1,4),F(1,5),F(1,6))):
   mu=[dw[u]/masses[u] for u in range(4)]; sig=[dw[u]*qs[u] for u in range(4)]
   gam={e:F(1,100) for e in edges}; beta=F(3,4); Ccol=F(2)
   assert all(sum(v for (u,w),v in gam.items() if u==k)<=beta*sig[k] for k in range(4))
   assert all(sum(v for (u,w),v in gam.items() if w==k)<=Ccol*sig[k] for k in range(4))
   G0=sum(gam.values()); W=sum(f)
   T={(u,z):sum(mu[w]*patterns[w][z] for w in range(4) if masses[w]<=masses[u]) for u in range(4) for z in range(3)}
   Z={(u,z):sum(mu[w]*patterns[w][z] for w in range(4) if masses[w]<masses[u]/K) for u in range(4) for z in range(3)}
   Bwindow=max(T[u,z]-Z[u,z] for u in range(4) for z in range(3))
   def posterior(u,arr): return sum(f[z]*patterns[u][z]*arr[z]/masses[u] for z in range(3))
   for thresholds in ((F(1,4),F(3,4),F(2),F(8)),(F(1,2),F(1),F(3),F(9)),(F(0),F(1,2),F(4),F(12))):
    stages=[gam,{e:v for e,v in gam.items() if 1 not in e},{}]
    bs=[]
    for i,gi in enumerate(stages,1):
     D=[sum(g*(F(patterns[u][z],1)/masses[u]+F(patterns[v][z],1)/masses[v]) for (u,v),g in gi.items()) for z in range(3)]
     bi=[(min(f[z],thresholds[i])-min(f[z],thresholds[i-1]))/f[z]*max(1-F(1,1000)/D[z],F(0)) if D[z] else F(0) for z in range(3)]
     bs.append(bi)
    assert all(sum(b[z] for b in bs)<=1 for z in range(3))
    for h,L in product((F(1,10),F(1,3),F(1)),(F(0),F(1),F(2),F(4))):
     eps=Bwindow/h
     total=cap=elo=ehi=slo=shi=small=F(0)
     for gi,bi in zip(stages,bs):
      for (u,v),g in gi.items():
       total+=g*(posterior(u,bi)+posterior(v,bi)); small+=g*posterior(v,bi)
       cap+=g*posterior(u,[bi[z]*patterns[v][z] for z in range(3)])
       elo+=g*posterior(u,[bi[z]*(1-patterns[v][z])*(Z[u,z]<=L*h) for z in range(3)])
       ehi+=g*posterior(u,[bi[z]*(1-patterns[v][z])*(Z[u,z]>L*h) for z in range(3)])
       slo+=g*posterior(v,[bi[z]*(T[v,z]<=L*h) for z in range(3)])
       shi+=g*posterior(v,[bi[z]*(T[v,z]>L*h) for z in range(3)])
     assert total==cap+elo+ehi+slo+shi
     assert cap<=small/K<=G0/K
     assert elo<=beta*(L+eps)*h*W
     assert slo<=Ccol*L*h*W
     assert total<=G0/K+h*(beta*(L+eps)+Ccol*L)*W+ehi+shi
     cnt['marked_nested']+=1
for atoms in product(range(4),repeat=3):
 ranks=[]; run=F(0)
 for a in atoms: run+=a; ranks.append(run)
 for threshold in (F(0),F(1,2),F(1),F(2),F(4),F(7)):
  selected=sum(F(a) for a,t in zip(atoms,ranks) if t<=threshold)
  assert selected<=threshold
  cnt['atomic_boundary']+=1
for atoms in product((1,2,3),repeat=5):
 ranks=[]; run=F(0)
 for a in atoms: run+=a; ranks.append(run)
 for threshold in map(F,(0,F(1,2),1,2,3,5,8,12,16)):
  selected=sum(F(a) for a,t in zip(atoms,ranks) if t<=threshold)
  assert selected<=threshold
  cnt['expanded_atoms']+=1
print('PASS',cnt,'total',sum(cnt.values()))
