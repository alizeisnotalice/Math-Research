# R660：共享真实容量的多 blocking-clique 合并付款

状态：得到一项真正使用方体坐标乘积的合并估计，允许任意多个 blocking 点共同使用同一批实际保留 owners，并在整批真实 receiver 并集上只支付一次该批容量。packing_core 已独审乘积 lens、layer-cake 和合并式；主代理进一步扩大了能保留指数折扣的质量范围。尚未构造覆盖全族且全局共享容量受控的分簇，因而没有证明 V≤K√n P。

## 1. 冻结实际对象与一项主结论

用真实 disjoint full owners E_i⊂B_i，v_i=|E_i|，w_i=v_i/d_i。令 q_i 是本轮实际 residual 递推保留的共同权，0≤q_i≤w_i；选取真实 F_i⊂E_i，|F_i|=d_iq_i。所有 F_i 全局不交。这里 F_i 是 Lebesgue owner pieces，不是任意新来源，也不是改变旧 KKT 源。

考虑一批有限 blocking 点 Z={z_b}，及附着于这些点的一批 rejected 行：每个此类 j 选有 z_{b(j)}∈A_j。令 r 为这些 rejected 行的最大半径。

取同一批实际保留行 I，使每个 i∈I 满足

    Z⊂A_i，s_i≥r。

这是共同的真实 I，不能按每个点分别选一批后相加。实际 blocking cliques 的共同保留成员满足此条件；若共同成员不足，下面的结论不适用。

记

    c0=1+1/a，c=c0^n，
    U=Σ_{i∈I}|F_i|，T=Σ_{i∈I}q_i，
    B=T/c−1，L=log[U/(c(2r)^n)]。

当 T>c 时，B>0，且下述证明自动给 L≥B。令 V_group 为这批 rejected 行的实际 receiver 并集体积（或其实际剩余 owner 并集体积；后者更小）。主估计为

    V_group ≤ U exp{−L+e^(L/n) log(L/B)}。           (MERGE)

尤其，若

    B>1， B≤L≤n log B，

则

    V_group ≤ e^(−B) U。                            (MERGE+)

clique 数、点数和行数都不出现在常数中。这里整批只支付同一个 U 一次，保留了真实组体积，绝没有将 V_group 替换成 Σ_j d_j。

## 2. 方体乘积给出共同容量 lens

对每个坐标 l 令

    Δ_l=max_{z∈Z} z_l−min_{z∈Z} z_l， Δ_1=Σ_l Δ_l。

若 i∈I 且 s_i≤s，则因为 A_i 同时包含全部 Z，其中心满足

    max_Z z_l−s_i≤y_{il}≤min_Z z_l+s_i。

所以每个 x∈F_i⊂B_i 都满足

    max_Z z_l−c0s≤x_l≤min_Z z_l+c0s。

真实 F_i 不交，故共同容量的累计分布严格满足

    F(s):=Σ_{i∈I:s_i≤s}|F_i|
      ≤V_Z(s):=∏_{l=1}^n [2c0s−Δ_l]_+，
    F(s)≤U。                                        (LENS)

这一步使用同一个 cube 半径同时控制所有坐标；任意盒子不能直接套用。若某因子非正，V_Z(s)=0。其余情形由 log(1−x)≤−x 得

    V_Z(s)≤c(2s)^n exp[−Δ_1/(2c0s)]。                (PRODUCT)

单点 Z 时全部 Δ_l=0，退化为主代理的单点累计容量界。

## 3. Layer-cake 强迫 blocking 点聚集

所有 i∈I 的 s_i≥r，故非负 Tonelli 严格给

    T=Σ_i |F_i|/(2s_i)^n
      =n∫_r^∞ F(s)/(2^n s^(n+1)) ds
      ≤n∫_r^∞ min(U,V_Z(s))/(2^n s^(n+1)) ds。     (LC)

先注意 T≤U/(2r)^n。因此 T>c 推出 U>c(2r)^n 和 L>0。设

    S0=(U/(c2^n))^(1/n)=r e^(L/n)>r。

在 [r,S0] 用 PRODUCT，并将其指数因子上界为 exp[−Δ_1/(2c0S0)]；在 [S0,∞) 用 F(s)≤U。尾积分恰为 c，所以

    T≤c+c n log(S0/r) exp[−Δ_1/(2c0S0)]
      =c[1+L exp(−Δ_1/(2c0S0))]。

于是 L≥B，且

    Δ_1≤2c0S0 log(L/B)。                            (DIAM)

这不是根据交盒体积推断来源质量；它直接限制同一批真实 F_i 在多个 blocking 点共同可用时的坐标跨度。

## 4. 将共同容量用于整批真实 receiver 并集

对附着于 z_b 的 rejected j，若 x∈B_j，则

    ||x−z_b||∞≤(1+1/a)s_j≤c0r。

所以这批 receiver 的并集包含于一个矩形，其第 l 个边长为 2c0r+Δ_l。由 log(1+x)≤x，

    V_group≤∏_l(2c0r+Δ_l)
      ≤c(2r)^n exp[Δ_1/(2c0r)]。

代入 DIAM 以及 U=c(2r)^n e^L，得到 MERGE。

主代理的加强无需 L 接近 B。若 B>1 且 B≤L≤nlogB，则 log(L/B)≥0、e^(L/n)≤B，因此

    −L+e^(L/n)log(L/B)
      ≤−L+B log(L/B)
      ≤−L+B(L/B−1)=−B。

这证明 MERGE+。例如 B=√n 且该区间非空时，可在共享容量质量参数 L 一直达到 (n/2)logn 的范围内保留 e^(−√n) 折扣；不需要额外的 L−B≤1 条件。

## 5. 可执行用途及准确的全局未证步

对一批候选 blocking 点及其 rejected 行，可以有限计算共同实际成员 I、r、T、U、B、L。若 MERGE+ 的区间成立，则把这批真实 rejected owners 合并为一组，按 e^(−B)U 一次付款；无需为每个 clique 单独支付 U。

这确实给出了共享容量的多 clique 合并规则，但尚未得到全族分簇。未证内容有三项，不能省略：

- 所有 blocking cliques 的共同 I 可能太小，使 T≤c；两两共享大量成员不推出整个簇共享足够容量。
- 不同合并簇仍可能重复使用同一个 F_i；局部 MERGE+ 不自动给 source-disjoint partition 或全局可控的重复次数。
- L>nlogB 的簇不在 MERGE+ 的付款范围内，不能直接丢弃或视为已经支付。MERGE 原式仍有效，但未证明其在该区间留下需要的净收益。

与全局目标的用途是准确的：若最终实际分簇覆盖所有未保留 owner pieces，并使各簇付款之和≤A Σ_i|F_i|，则

    V≤(1+A)Σ_i d_iq_i，
    P≥Σ_i d_iq_i/t≥V/[t(1+A)]，

因为本轮实际 residual 递推的 q/t 是同一全族可行共同权。要取 t=O(√n)，仍须从真实 cube 几何证明 A 为绝对常数。本文没有假设该分簇存在，也没有把这个要求改写成新的 LP/Hall 条件冒充完成。

## 6. 与最初 exclusive-receiver 局部化的关系

最初独立核得 β=(a+1)/(a−1)：若 |B_i∩B_j|>0 且 s_i≥βs_j，则 A_j⊂int A_i。故两个不同极大 cliques 的互斥成员若 receivers 相交，其体积比严格小于 β^n≤33/31。包含阈值本身适用于一般对称凸体 homothets；cube 的 2-Helly 才能将图 cliques 作为真实共同点族付款。

这个限制不能直接控制共享 U：同一个 F_i 被多个 blocking cliques 使用，并不要求这些 rejected receiver 组彼此相交。正因如此，主结果改为对共同 I 在全部 blocking 点上的坐标 lens 作一次估计；没有任意分配共享成员后滥用“互斥成员”条件。

## 7. 复核与工具证据

packing_core 已独立复核 LENS、LC、DIAM 和 MERGE 的方向与实际 F_i 条件；主代理给出 MERGE+ 的宽范围加强，本文已复核其 log 不等式。

指定本机数学 Python/SymPy 实际核得：尾付款 U/(2S0)^n=c；加强范围的代数差为 B(log x−x+1)；n=16、B=4、L=16log4 的端点检查给指数约 −15.3289952935≤−4。数值只作 sanity check，证明是上述乘积界及精确非负积分。没有扫描、昂贵计算、Git 写入或改动他人文件。
