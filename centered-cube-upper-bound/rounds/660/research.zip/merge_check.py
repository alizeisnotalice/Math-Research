import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import sys,json,platform,hashlib,time
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.threads=1
P=Path(__file__).parent
L,B,n,K=sp.symbols('L B n K',positive=True)
psi=-L+sp.exp(L/n)*sp.log(L/B);h=-L+K*sp.exp(L/n)
checks={'psi_derivative':str(sp.diff(psi,L)),'psi_second_derivative':str(sp.simplify(sp.diff(psi,L,2))),'h_second_derivative':str(sp.diff(h,L,2)),'psi_at_L_equals_B':str(sp.simplify(psi.subs(L,B)+B)),'h_minus_psi':str(sp.simplify(h-psi)),'far_exponent_identity':str(sp.simplify(1+1/(32*n)-sp.Rational(33,32)-(1-n)/(32*n)))}
assert sp.simplify(psi.subs(L,B)+B)==0 and sp.simplify(sp.diff(h,L,2)-K*sp.exp(L/n)/n**2)==0
assert sp.simplify(1+1/(32*n)-sp.Rational(33,32)-(1-n)/(32*n))==0

def compute(nv,kind,bits):
 ctx.prec=bits;N=arb(nv);logn=N.log();eps=arb(1)/10**20
 if kind=='B2': b=arb(2)
 elif kind=='B4':b=arb(4)
 elif kind=='lower':b=2*logn+eps
 elif kind=='upper':b=N/2-eps
 else:b=(2*logn+N/2)/2
 l0=N*b.log();l1=N*logn;k=(l1/b).log(); far=(1+(1+1/(32*N))/N)**nv; limit=(arb(33)/32).exp()
 assert b>1 and l0>=b
 if kind in ('lower','upper','middle'):assert b>2*logn and b<N/2 and l1>=l0
 points=[('L0',l0),('midpoint',(l0+l1)/2),('L1',l1)] if kind not in ('B2','B4') else [('L0',l0)]
 vals=[]
 for label,x in points:
  p=-x+(x/N).exp()*(x/b).log()+b
  bound=-x+k*(x/N).exp()+b
  gap=bound-p
  vals.append({'point':label,'L':str(x),'psi_plus_B':str(p),'psi_sign':'negative' if p<0 else 'positive' if p>0 else 'undetermined','h_plus_B':str(bound),'h_sign':'negative' if bound<0 else 'positive' if bound>0 else 'undetermined','h_minus_psi':str(gap),'bound_relation':'strict' if gap>0 else 'undetermined'})
 return {'n':nv,'B_kind':kind,'B':str(b),'precision_bits':bits,'L_equals_B':'exact identity psi(B,B)+B=0','far_coefficient':str(far),'far_gap_exp_33_32_minus_coefficient':str(limit-far),'far_strict':limit>far,'points':vals}
def row(nv,kind):
 for bits in (192,384,768):
  z=compute(nv,kind,bits)
  if all(v['psi_sign']!='undetermined' and (kind in ('B2','B4') or v['h_sign']!='undetermined') for v in z['points']) and z['far_strict']:return z
 return z
if __name__=='__main__':
 t=time.monotonic();data=[]
 for nval in (16,32):
  for k in ('B2','B4'):data.append(row(nval,k))
 for nval in (16,32,64,128,256,1024,4096):
  for k in ('lower','middle','upper'):data.append(row(nval,k))
 result={'task':'R660-MERGE-02','sympy':checks,'cases':data,'python':platform.python_version(),'versions':{'sympy':sp.__version__,'python_flint':flint.__version__},'wall_seconds':time.monotonic()-t,'max_workers':1,'command':'OPENBLAS_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r660-20261115/merge_check.py','sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite Arb interval checks; no general theorem or finite cube realization asserted'}
 (P/'merge_results.json').write_text(json.dumps(result,indent=2)+'\n');print('cases',len(data),'psi signs',sorted(set(p['psi_sign'] for c in data for p in c['points'])),'expanded h signs',sorted(set(p['h_sign'] for c in data if c['B_kind'] not in ('B2','B4') for p in c['points'])),'precision',sorted(set(c['precision_bits'] for c in data)),'wall',result['wall_seconds'],flush=True)
