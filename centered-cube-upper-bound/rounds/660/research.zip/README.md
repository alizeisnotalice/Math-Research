# R660 minimal research and verification package

General pure C_n <= K sqrt(n), and the prior general n^(1/2+o(1)) target, remain unproved.

Read REPORT.tex for the self-contained finite packing construction, global once-paid far estimate, shared-source product estimate, complete cost ledger, and exact unproved near-allocation hypothesis. No PDF was compiled. AUDIT.md and FINAL_REVIEW.md contain independent mathematical reviews. Three author appendices retain the audited construction and geometric details; their conditional branches are not general theorems.

Actual computations:
- R660-RP-01: 16 deterministic rational-input interval families, dimension 1, 4 families at each N=64,128,256,512. Floating comparison at all OLD breakpoints; this grid is not claimed to optimize the new recursion globally.
- Three saved selected-threshold packing certificates were independently reconstructed with Fraction on every positive-length full membership cell; every old positive breakpoint was also checked exactly. audit_numeric.json retains exact owner atoms, weights, all old objectives, and all final capacity inequalities as a reviewable certificate. It is included for independent constraint inspection, not as extra numerical coverage.
- R660-MERGE-02: SymPy identities and finite Arb 192-bit interval checks at 25 parameter groups, 67 psi points, and 63 expanded h points. The 21 envelope comparisons marked undetermined at the upper endpoint are exact analytic equalities, not strict interval successes. The independent numerical auditor checked this record's counts/hashes but did not rerun Arb.
- No finite high-dimensional configuration or dimension-asymptotic claim was numerically certified. The report proves why few-label high-dimensional tests would automatically pass the proposed root threshold.

The frozen commands and original versions, input seeds, results and CPU/wall times appear in NUMERIC.md, result JSON files and AUDIT_NUMERIC.md. Original interpreter:
 /Users/zzh/.local/share/math-research-tools/venv/bin/python (Python 3.12.14).
Dependencies: residual producer NumPy 2.5.4; merge check SymPy 1.14.0, python-flint 0.9.0; independent exact audit uses the Python standard library only.

Verify archive hashes, Python syntax, TeX environment pairing and the final review binding:

    python verify.py

This is not a LaTeX compilation or a new proof audit.

To independently replay the three exact finite certificates from the archive, preserving the archived outputs:

    python verify.py --replay --workdir /Volumes/data/CodexTemp/centered-cube-r660-replay

Use a new, nonexistent workdir; the verifier copies required inputs there, executes audit_numeric.py and compares all mathematical records, provenance hashes and scope metadata, omitting only machine/run timestamps and timings. It does not rerun the floating scan or Arb checks.

To rerun the producers, first copy the archive into a separate workdir, then use the original interpreter on residual_probe.py or merge_check.py. These rewrite their adjacent result files; new timings and possibly floating rounding need not match archived hashes. The original certificate file also contains an independently added all-old-breakpoint optimum field; regenerating it with the producer alone does not reproduce that review step.

Package file hashes are in manifest.json. General near-scale grouping with a globally payable shared-source budget is still missing. Neither a conditional certificate nor a finite numerical result closes that gap.
