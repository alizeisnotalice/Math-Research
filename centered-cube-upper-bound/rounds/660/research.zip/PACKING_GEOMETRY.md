# R660：残余构造的大尺度全族付款与近尺度合并范围

日期：2026-11-15。只负责本文件。**一般 `V ≤ K sqrt(n) P` 尚未证明。** 本轮可证明的主估计是：实际 residual 构造中，大尺度提供至少半数阻挡负载的全部损失，可用一个全空间积分一次支付；其余行的尺度落在 `[s_j,n s_j]`。与已核对的方体乘积合并估计结合后，近尺度合并无需另留“来源总量超大”的例外。剩余缺口是一个明确的、未证明的全族分组及来源分配步骤。

## 1. 固定输入、实际构造与真实损失

沿用 TASK.md。`a=32n`，`A_j=Q(y_j,s_j)`，`B_j=Q(y_j,s_j/a)`，`d_j=(2s_j)^n`，按半径非增次序排列。取真实不交 full owners `E_j⊂B_j`，令

\[
 v_j=|E_j|,\qquad w_j=v_j/d_j\le a^{-n},\qquad
 V=\sum_jv_j.
\]

使用 packing_entry 给出的实际残余构造，固定同一个 `t>0`：

\[
 q_j=\min\left\{w_j,
 \left(t-\operatorname*{ess\,sup}_{A_j}
                  \sum_{i<j}q_i1_{A_i}\right)_+\right\}.
\tag{1}
\]

同一组 `theta_j=q_j/t` 在全空间共同可行。定义

\[
 S=\sum_jd_jq_j,\qquad P\ge S/t.
\tag{2}
\]

由于 Lebesgue 测度无原子，可以选真实子owners

\[
 F_j\subset E_j,\quad |F_j|=d_jq_j,
 \qquad X_j=E_j\setminus F_j.
\tag{3}
\]

`F_j` 全局不交，`X_j` 全局不交，且

\[
 \sum_j|F_j|=S,\qquad \sum_j|X_j|=V-S.
\tag{4}
\]

下面始终支付实际 `X_j`，不把接收体积换成计数或假来源密度。

## 2. 被裁剪行的完整饱和点：包括当前行

若 `q_j<w_j`，记 `(1)` 中的前缀本质上确界为 `ell_j`。前缀负载已不超过 `t`，所以

\[
 \ell_j+q_j=t.
\]

有限方体 arrangement 的正测 membership cells 上负载恒定，因此可以在 `A_j` 中选一个达到前缀上确界的正测 cell，再选一点 `z_j`，避开全族所有方体的边界。于是

\[
 \sum_{i\le j}q_i1_{A_i}(z_j)=t.
\tag{5}
\]

后继任何 `q_i>0` 的方体都不能包含此点；否则在该点附近一个正测 cell 上总负载会超过 `t`。故最终负载也满足

\[
 \sum_iq_i1_{A_i}(z_j)=t,
 \qquad q_i>0, z_j\in A_i\Longrightarrow i\le j, s_i\ge s_j.
\tag{6}
\]

这正是采用完整饱和后前缀的原因。若排除当前 partial 行，只能写 `t−a^{-n}`；本报告的全部 `t/2` 分割均使用 `(5)`–`(6)`，没有漏掉该误差。

## 3. 主估计：大尺度阻挡的全部损失一次付款

令 `c_0=1+1/a`。把被裁剪行分为两类。若

\[
 \sum_{i:s_i\ge n s_j}q_i1_{A_i}(z_j)\ge t/2,
\tag{7}
\]

称该行为大尺度阻挡行。其余称近尺度行。

**全族估计。** 对所有大尺度阻挡行的实际损失，有

\[
 \boxed{\quad
 \sum_{j\text{ satisfying }(7)}|X_j|
 \le \frac{2}{t}\left(1+\frac{c_0}{n}\right)^n S
 \le \frac{2e^{33/32}}{t}S.
 \quad}
\tag{8}
\]

**证明。** 固定满足 `(7)` 的 `j` 及 `x∈X_j⊂B_j`。因 `z_j∈A_j`，逐坐标有

\[
 \|x-z_j\|_\infty\le c_0s_j.
\]

若 `(7)` 中的 `i` 包含 `z_j`，则

\[
 \|x-y_i\|_\infty
 \le s_i+c_0s_j
 \le\left(1+\frac{c_0}{n}\right)s_i.
\]

因此整个损失并集上都有

\[
 \sum_iq_i1_{(1+c_0/n)A_i}(x)\ge t/2.
\]

`X_j` 是真实全局不交 owners，故积分一次即得

\[
 \sum_{j\text{ satisfying }(7)}|X_j|
 \le\frac2t\sum_iq_i|(1+c_0/n)A_i|
 =\frac2t(1+c_0/n)^n S.
\]

最后用 `c_0≤33/32` 与 `(1+u/n)^n≤e^u`。证毕。

这是一个对原全部尺度有限族同时成立的预算。每个保留来源 `d_iq_i` 在右侧只出现一次；没有把各个 blocking clique 的来源总量相加。

## 4. 剩余每行确有一个受限尺度实际 clique

对近尺度行，`(6)`、`(7)` 给出

\[
 I_j=\{i:q_i>0,\ z_j\in A_i,\ s_j\le s_i<n s_j\},
 \qquad T_j:=\sum_{i\in I_j}q_i>t/2.
\tag{9}
\]

这是同一真实残余解的实际 clique，不是另解局部 packing。其保留来源总量

\[
 U_j=\sum_{i\in I_j}|F_i|
\]

满足

\[
 U_j\le (1+1/a)^n(2n s_j)^n.
\tag{10}
\]

因为每个 `F_i⊂B_i`，且 `A_i` 包含 `z_j`，全部这些来源都在 `Q(z_j,c_0 n s_j)` 内，来源又全不交。

式 `(8)` 已经支付大尺度行；下一步不再要求处理无界尺度范围，而是处理 `(9)` 中彼此共享来源的近尺度 cliques。

## 5. 单点来源质量估计与直接逐点付款的缺陷

以下引理用于核对后面的参数范围。记

\[
 c=c_0^n\le e^{1/32}.
\]

若一批真实不交 `F_i⊂B_i` 的方体共同包含 `z`，半径均不小于 `r`，设

\[
 T=\sum_i |F_i|/d_i,\quad U=\sum_i|F_i|,\quad d_r=(2r)^n.
\]

则

\[
 T\le
 \begin{cases}
 U/d_r,&U\le c d_r,\\
 c[1+\log(U/(c d_r))],&U>c d_r.
 \end{cases}
\tag{11}
\]

**证明。** `x∈F_i` 时 `||x−z||∞≤c_0s_i`。所以来源核不超过

\[
 \frac{c}{[2\max(c_0r,\|x-z\|_\infty)]^n}.
\]

在总质量为 `U`、密度不超过 `1` 的集合上，该径向非增核积分由同体积中心方体取得最大值；这可直接比较该方体内外的核值证明。对该方体按 `||x−z||∞` 积分，得到 `(11)`。其中密度 `≤1` 来自真实子owners 不交，并非额外来源帽。证毕。

特别地，`T>c` 时

\[
 U\ge c d_r e^{T/c-1}.
\tag{12}
\]

对共用同一个实际阻挡点的若干裁剪行，最大半径为 `r`，其 receiver 并集不超过 `c d_r`，因而由 `(12)` 至多为 `e^{1-T/c}U`。

**不能直接逐点相加。** 一个早期大方体可以以很小的 `q_i` 贡献很大的 `d_iq_i`，在其内部许多互不相交、极小尺度的饱和簇中反复出现。各小簇总来源体积可以任意小，却让这个大来源被每个 clique 重复计入 `U`。所以“每个点局部有指数付款”不推出来源总量只被支付一次。这个障碍要求合并共享背景，不能以 clique 个数或任意分配 shared members 消除。

## 6. 多阻挡点的方体乘积合并，以及范围扩展

本节的乘积累计式由 joint_source_gain 独立提出并交换，已逐步核对。这里将它与 `(9)`–`(10)` 接合，并证明扩大后的参数范围。

设某组近尺度裁剪行的最大半径为 `r`，阻挡点集合为有限 `Z`。假设有一批**实际共同来源** `I`，满足：

- 每个 `A_i` 包含全部 `Z`；
- `r≤s_i≤nr`；
- 使用真实不交来源 `F_i`，或它们的真实子集；
- `T=Σ_{i∈I}|F_i|/d_i>c`。

记 `U=Σ_{i∈I}|F_i|`，

\[
 \Delta_k=\max_{z\in Z}z_k-\min_{z\in Z}z_k,
 \quad D_1=\sum_{k=1}^n\Delta_k,
 \quad B=T/c-1,
 \quad L=\log\frac{U}{c d_r}.
\]

对共同来源的累计质量 `F(s)=Σ_{i∈I:s_i≤s}|F_i|`，真正的区间乘积给出

\[
 F(s)\le\min\left\{U,
       \prod_{k=1}^n[2c_0s-\Delta_k]_+\right\}.
\tag{13}
\]

这是因为每个相应 `F_i` 同时在全部 `Q(z,c_0s)` 内。区间交集的笛卡尔积是辅助几何区域；原见证始终是共同半径方体，没有改成任意矩形模型。

Layer cake 与乘积上界得到

\[
 T\le n\int_r^\infty\frac{F(s)}{2^n s^{n+1}}\,ds,
\quad
 \prod_k[2c_0s-\Delta_k]_+
 \le c(2s)^n e^{-D_1/(2c_0s)}.
\]

令 `S_0=r e^{L/n}`，在其处分裂积分，并用 `(11)` 保证 `L≥B>0`，有

\[
 T\le c\left[1+L e^{-D_1/(2c_0S_0)}\right],
 \qquad
 D_1\le2c_0S_0\log(L/B).
\tag{14}
\]

组内每个 receiver 在对应阻挡点周围半径至多 `c_0r`，故**整组 receiver 的真实并集**满足

\[
 \begin{aligned}
 W_Z&\le\prod_k(\Delta_k+2c_0r)\\
 &\le c d_r\exp[D_1/(2c_0r)]\\
 &\le U\exp\left[-L+e^{L/n}\log(L/B)\right].
 \end{aligned}
\tag{15}
\]

这里是对任意多个阻挡点联合付款一次，不是把每个点的 `c d_r` 相加。

**扩展范围引理。** 若

\[
 n\ge16,\qquad 2\log n\le B\le n/2,
 \qquad B\le L\le n\log n,
\tag{16}
\]

则

\[
 -L+e^{L/n}\log(L/B)\le-B,
 \qquad \boxed{\ W_Z\le e^{-B}U.\ }
\tag{17}
\]

**证明。** 当 `L≤n log B` 时，`e^{L/n}≤B` 且
`log(L/B)≤(L−B)/B`，直接得到结论。

余下区间 `[n log B,n log n]`，令

\[
 K=\log(n\log n/B),\qquad h(L)=-L+K e^{L/n}.
\]

目标左侧不超过凸函数 `h(L)`，故只需验两个端点。由 `B≥2 log n`，

\[
 h(n\log n)=n\log(\log n/B)
 \le-n\log2\le-B.
\]

又 `B>e`、`B≤n/2`，函数 `log x/x` 递减，故

\[
 (n/B)\log B\ge2\log(n/2)
 \ge1+\log(n/2)\ge1+K
\]

（`n≥16` 足够），所以 `h(n log B)≤−B`。证毕。

**与实际 near clique 的接点。** 来源半径不超过 `nr` 自动给 `U≤c(2nr)^n`，即 `L≤n log n`。因此在 `(16)` 的负载范围内，不再需要另假设来源总量接近其最小值，也不再需要单独处理所谓超大来源总量情形。

## 7. 完整总账，以及唯一未证的全族步骤

可以将需要的合并条件精确写成如下陈述，但**本报告没有证明它存在**：将全部近尺度损失行分成组 `G_h`，每组最大半径为 `r_h`，阻挡点为 `Z_h`；给每组分配实际来源份额 `x_{hi}`，使

\[
 x_{hi}\ge0,\qquad \sum_hx_{hi}\le q_i,
\tag{18}
\]

且 `x_hi>0` 只允许在

\[
 A_i\supset Z_h,\qquad r_h\le s_i\le nr_h
\tag{19}
\]

时发生，并有共同负载

\[
 T_h=\sum_i x_{hi}\ge T_0>c.
\tag{20}
\]

`(18)` 可以通过无原子性把原 `F_i` 切成真正不交的份额 `F_hi`，使 `|F_hi|=d_i x_hi`。这样

\[
 U_h=\sum_i d_i x_{hi},\qquad \sum_hU_h\le S.
\]

若再处于 `(16)` 的范围（例如统一 `B_0=T_0/c−1≥2 log n`，且 `t/c−1≤n/2`），`(17)` 给出

\[
 \sum_{j\text{ near}}|X_j|\le e^{-B_0}S.
\tag{21}
\]

结合已经无条件证明的 `(8)`，总账为

\[
 \boxed{\quad
 V\le\left[1+\frac{2e^{33/32}}t+e^{-B_0}\right]S,
 \qquad
 V\le\left[t+2e^{33/32}+t e^{-B_0}\right]P.
 \quad}
\tag{22}
\]

因此，若能在 `t` 为绝对常数倍 `sqrt(n)` 时实际构造 `(18)`–`(20)` 且 `T_0` 为 `t` 的固定比例，就得到所需阶。**当前未证的不是 `(22)` 的代数，也不是尺度范围，而是近尺度 cliques 共享来源时能否构造 `(18)`–`(20)`。** 单行的 `(9)` 并不保证全族来源分配；各组独立选共同来源会违反 `(18)`。

## 8. 近 receiver 交叠的进一步定位

来自 joint_source_gain 的几何量

\[
 \beta=\frac{a+1}{a-1}
\]

满足：若 `B_i∩B_j≠empty` 且 `s_i≥beta s_j`，则 `A_i⊇A_j`。证明是

\[
 \|y_i-y_j\|_\infty+s_j
 \le(s_i+s_j)/a+s_j\le s_i.
\]

它还能给一个对同一 residual 解、全部行同时有效的定量估计。对被剪行 `j` 令

\[
 Y_j=\{i<j:B_i\cap B_j\ne\varnothing,\ A_i\not\supset A_j\}.
\]

这些半径在 `[s_j,beta s_j)`，其全部真实子owners `F_i` 落在
`Q(y_j,(2beta+1)s_j/a)` 内。故

\[
 \boxed{\quad
 \sum_{i\in Y_j}q_i
 \le\left(\frac{2\beta+1}{a}\right)^n
 =:\gamma_n<10^{-n}.
 \quad}
\tag{23}
\]

这里使用的是来源真实不交与 `d_i≥d_j`。因此实际阻挡负载 `t` 分为：

1. 完整包含 `A_j` 的共同背景；
2. 与 `B_j` 相交但不包含 `A_j` 的方体，负载总和至多 `gamma_n`；
3. receiver 与 `B_j` 不交、但其大方体参与阻挡的 crossers。

第一项在整个 `A_j` 上存在，适合区域合并；第二项已有绝对小预算。第三项中的大尺度部分已由 `(8)` 全族支付。剩下的具体困难就是近尺度、receiver 不交的 crossers 及其共享背景如何满足 `(18)`。没有将 shared members 任意归属给某个 clique，也没有给远处 crossers 假设独立性。

## 9. 核验、范围与分支结论

实际运行本机数学 Python，检查了 `gamma_n` 在 `n=1,2,8,32` 的值，均小于 `10^{-n}`；其中 `gamma_1≈0.0977822581`。另对 `(16)` 范围内 `n=16,32,64,256,1024` 的有限标量网格核验了 `Psi(L)+B≤0`，并核得 `2e^(33/32)≈5.6091387125`。数值只核查标量公式，严格证明分别为 `(8)`、`(16)`–`(17)`、`(23)`；未进行新的几何族搜索。

本轮主交付为 `(8)` 的大尺度一次全族预算、`(17)` 到完整近尺度范围的扩展，以及保留真实损失与来源份额的总账 `(22)`。一般 `sqrt(n)` 结论仍取决于未证的近尺度全族合并 `(18)`–`(20)`。没有隐藏半径、标签数或深度常数，也没有宣称该合并自动存在。
