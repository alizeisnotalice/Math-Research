from pathlib import Path
import argparse, ast, hashlib, json, re, shutil, subprocess, sys
p=argparse.ArgumentParser()
p.add_argument("--replay",action="store_true")
p.add_argument("--workdir")
args=p.parse_args()
base=Path(__file__).resolve().parent
manifest=json.loads((base/"manifest.json").read_text())
for name,rec in manifest["files"].items():
    raw=(base/name).read_bytes()
    assert len(raw)==rec["bytes"],name
    assert hashlib.sha256(raw).hexdigest()==rec["sha256"],name
    if name.endswith(".py"):ast.parse(raw,filename=name)
text=(base/"REPORT.tex").read_text()
stack=[]
for kind,env in re.findall(r"\\(begin|end)\{([^}]+)\}",text):
    if kind=="begin":stack.append(env)
    else:
        assert stack and stack.pop()==env,(kind,env)
assert not stack
report_hash=manifest["files"]["REPORT.tex"]["sha256"]
assert report_hash in (base/"FINAL_REVIEW.md").read_text()
out={"hashes":len(manifest["files"]),"python_syntax":"pass","tex_environment_pairs":"pass (not compilation)","final_review_report_hash":report_hash}
if args.replay:
    assert args.workdir,"--replay needs an explicit new workdir"
    dest=Path(args.workdir).resolve()
    assert not dest.exists(),"Use a new workdir to preserve earlier records"
    dest.mkdir(parents=True)
    required=["TASK.md","residual_results.json","residual_certificates.json","merge_check.py","merge_results.json","audit_numeric.py"]
    for name in required:shutil.copy2(base/name,dest/name)
    run=subprocess.run([sys.executable,str(dest/"audit_numeric.py")],cwd=dest,text=True,capture_output=True)
    (dest/"replay_stdout.txt").write_text(run.stdout)
    assert run.returncode==0,run.stderr
    archived=json.loads((base/"audit_numeric.json").read_text())
    replay=json.loads((dest/"audit_numeric.json").read_text())
    excluded={"python","wall_seconds","cpu_seconds","command"}
    assert {k:v for k,v in archived.items() if k not in excluded}=={k:v for k,v in replay.items() if k not in excluded}
    out["exact_replay"]={"pass":True,"cases":len(replay["records"]),"wall_seconds":replay["wall_seconds"],"cpu_seconds":replay["cpu_seconds"],"python":replay["python"],"scope":"3 Fraction certificates plus saved merge metadata only"}
print(json.dumps(out,ensure_ascii=False,indent=2))
