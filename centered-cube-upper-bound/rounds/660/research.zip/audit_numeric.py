"""R660 independent exact certificate audit; no producer imports or code reads.
Only clusters N=64,128,256 are computed. Merge results receive metadata review.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json, hashlib, time, resource, platform
P=Path(__file__).resolve().parent
start=time.monotonic(); cpu=resource.getrusage(resource.RUSAGE_SELF)
raw=json.loads((P/'residual_results.json').read_text())
certs=json.loads((P/'residual_certificates.json').read_text())
selected={(r['N'],r['mode']):r for r in raw['results'] if r['mode']=='clusters' and r['N'] in (64,128,256)}
assert len(selected)==3 and {c['N'] for c in certs}=={64,128,256}

def verify(c):
    inp=selected[c['N'],c['mode']]; n=inp['N']; den=inp['coordinate_denominator']
    triples=inp['intervals']
    assert len(triples)==n and all(s>0 for y,s,j in triples)
    assert sorted(triples,key=lambda row:(-row[1],row[2]))==triples
    assert len({j for _,_,j in triples})==n
    # Retain rational coordinates even if a future input is not divisible by 32.
    A=[(F(y-s),F(y+s)) for y,s,j in triples]
    B=[(F(y)-F(s,32),F(y)+F(s,32)) for y,s,j in triples]
    d=[(hi-lo)/den for lo,hi in A]
    bp=sorted({x for interval in B for x in interval})
    lengths=[F(0)]*n; union=F(0); receiver_atoms=[]
    for left,right in zip(bp,bp[1:]):
        mid=(left+right)/2
        cover=[j for j,(lo,hi) in enumerate(B) if lo<mid<hi]
        if cover:
            owner=min(cover) # first in radius-descending order, tag resolves ties
            length=(right-left)/den
            lengths[owner]+=length;union+=length
            receiver_atoms.append([str(left/den),str(right/den),owner])
    assert union==sum(lengths)==F(c['V'])==F(inp['V'])
    assert sum(v==0 for v in lengths)==inp['zero_owners']
    w=[v/dj for v,dj in zip(lengths,d)]
    assert all(0<=x<=F(1,32) for x in w)
    # All positive-length membership cells of the full A arrangement.
    ap=sorted({x for interval in A for x in interval})
    cells=[]; indices=[[] for _ in range(n)]
    for left,right in zip(ap,ap[1:]):
        mid=(left+right)/2
        members=[j for j,(lo,hi) in enumerate(A) if lo<mid<hi]
        if members:
            k=len(cells);cells.append((left,right,members))
            for j in members:indices[j].append(k)
    # Old raw loads use all earlier w_i, whether later capacity retains them or not.
    load=[F(0)]*len(cells); ell=[]
    for j in range(n):
        assert indices[j]
        ell.append(max(load[k] for k in indices[j]))
        for k in indices[j]:load[k]+=w[j]
    thresholds=sorted({v for l,wj in zip(ell,w) for v in (l,l+wj) if v>0})
    active_thresholds=sorted({v for l,wj in zip(ell,w) if wj>0 for v in (l,l+wj) if v>0})
    def old_value(t):
        theta=[min(wj,max(F(0),t-l))/t for l,wj in zip(ell,w)]
        return sum(dj*x for dj,x in zip(d,theta))
    all_values=[(t,old_value(t)) for t in thresholds]
    Gold=max(v for t,v in all_values)
    oldt=F(c['old_threshold']);t=F(c['keep_threshold'])
    assert len(thresholds)==inp['positive_thresholds']
    assert oldt==F(inp['old_threshold']) and t==F(inp['keep_threshold']) and t in thresholds
    assert oldt in thresholds and old_value(oldt)==Gold
    assert Gold==F(c['Gold_at_selected_threshold'])==F(c['Gold_all_old_breakpoints_exact'])
    assert old_value(t)==F(c['old_at_keep_threshold'])
    # New retained-load recursion, reconstructed directly on all membership cells.
    keep_load=[F(0)]*len(cells); q=[]; retained_ell=[]
    for j in range(n):
        l=max(keep_load[k] for k in indices[j]); retained_ell.append(l)
        qj=min(w[j],max(F(0),t-l));q.append(qj)
        assert 0<=qj<=w[j]
        for k in indices[j]:keep_load[k]+=qj
        assert all(keep_load[k]<=t for k in indices[j])
    theta=[qj/t for qj in q]
    # Separate final capacity reconstruction, independent of incremental keep_load.
    final_load=[sum(theta[j] for j in members) for left,right,members in cells]
    assert max(final_load)<=1 and all(z==v/t for z,v in zip(final_load,keep_load))
    Gkeep=sum(dj*x for dj,x in zip(d,theta))
    ratio=Gkeep/Gold
    assert Gkeep==F(c['Gkeep_at_selected_threshold'])
    assert ratio==F(c['gain_exact']) and max(final_load)==F(c['capacity_exact'])
    assert Gkeep>Gold
    if n==64:assert ratio==F(22088823,18133504) and ratio>F(6,5)
    return {'N':n,'mode':'clusters','pass':True,'V':str(union),'zero_owners':sum(v==0 for v in lengths),'ownership_rule':'first containing B in descending radius, tag tie-break','positive_A_cells':len(cells),'all_old_positive_breakpoints':len(thresholds),'active_old_positive_breakpoints':len(active_thresholds),'old_maximizing_saved_threshold':str(oldt),'Gold_all_old_breakpoints':str(Gold),'new_selected_threshold':str(t),'Gkeep_at_selected_threshold':str(Gkeep),'new_threshold_old_G':str(old_value(t)),'gain_ratio_exact':str(ratio),'gain_absolute_exact':str(Gkeep-Gold),'max_capacity_all_space_ae':str(max(final_load)),'outside_A_union_capacity':'0','v':list(map(str,lengths)),'w':list(map(str,w)),'old_ell':list(map(str,ell)),'new_retained_ell':list(map(str,retained_ell)),'new_q_unnormalized':list(map(str,q)),'new_theta':list(map(str,theta)),'old_breakpoint_objectives':[[str(ti),str(vi)] for ti,vi in all_values],'receiver_owner_atoms':receiver_atoms,'full_A_cells':[[str(left/den),str(right/den),members,str(load)] for (left,right,members),load in zip(cells,final_load)]}

records=[verify(c) for c in certs]
# Metadata/provenance audit only: deliberately do not import or execute merge_check.
merge=json.loads((P/'merge_results.json').read_text())
script=(P/'merge_check.py').read_bytes()
assert hashlib.sha256(script).hexdigest()==merge['sha256']
cases=merge['cases'];base=[c for c in cases if c['B_kind'] in ('B2','B4')];expanded=[c for c in cases if c['B_kind'] not in ('B2','B4')]
assert {(c['n'],c['B_kind']) for c in base}=={(n,b) for n in (16,32) for b in ('B2','B4')}
assert {(c['n'],c['B_kind']) for c in expanded}=={(n,b) for n in (16,32,64,128,256,1024,4096) for b in ('lower','middle','upper')}
assert len(cases)==25 and len(base)==4 and len(expanded)==21
assert all([p['point'] for p in c['points']]==(['L0'] if c in base else ['L0','midpoint','L1']) for c in cases)
points=[p for c in cases for p in c['points']];expanded_points=[p for c in expanded for p in c['points']]
assert len(points)==67 and len(expanded_points)==63
assert all(c['precision_bits']==192 and c['far_strict'] for c in cases)
assert all(p['psi_sign']=='negative' for p in points) and all(p['h_sign']=='negative' for p in expanded_points)
assert all(p['bound_relation']==('undetermined' if p['point']=='L1' else 'strict') for p in points)
merge_summary={'review':'read script and saved results only; Arb computations not rerun','script_hash_matches':True,'groups':25,'psi_points':67,'expanded_h_points':63,'precision_bits':[192],'psi_all_saved_negative':True,'expanded_h_all_saved_negative':True,'far_all_saved_strict':True,'strict_positive_h_minus_psi':46,'L1_h_equals_psi_symbolically_not_strict':21,'n_base':[16,32],'n_expanded':[16,32,64,128,256,1024,4096],'B_base':[2,4],'B_expanded':['2 log(n)+10^-20','(2 log(n)+n/2)/2','n/2-10^-20'],'L_samples':['n log(B)','(n log(B)+n log(n))/2','n log(n)'],'scope':'metadata and range consistency only; no independent high-dimensional numerical theorem or finite cube realization'}
now=resource.getrusage(resource.RUSAGE_SELF)
result={'task':'R660-independent-numeric-audit','pass':True,'method':'single-process Fraction interval membership sweeps; no producer imports or code reads','records':records,'merge_metadata_audit':merge_summary,'limits':'new selected-threshold feasibility/objective only; no new all-threshold optimum, high-dimensional numerical claim, calibrated state, or dimension bound','python':platform.python_version(),'workers':1,'blas_threads':1,'wall_seconds':time.monotonic()-start,'cpu_seconds':now.ru_utime+now.ru_stime-cpu.ru_utime-cpu.ru_stime,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python audit_numeric.py','sha256':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ('TASK.md','residual_results.json','residual_certificates.json','merge_check.py','merge_results.json','audit_numeric.py')}}
(P/'audit_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({**{k:v for k,v in result.items() if k!='records'},'records':[{k:v for k,v in r.items() if not isinstance(v,list)} for r in records]},indent=2))
