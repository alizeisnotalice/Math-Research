import os
for v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[v]='1'
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from pathlib import Path
import random,json,time,resource,hashlib,platform
import numpy as np
P=Path(__file__).parent
S=32768
modes=['nested','separated','alternating','clusters']
def make(N,mode):
 r=random.Random(660000+10*N+modes.index(mode)); out=[]
 for j in range(N):
  if mode=='nested': c=r.randrange(-20,21)*32; radius=(2000+15*(N-j))*32
  elif mode=='separated':c=j*5000*32;radius=r.randrange(300,1200)*32
  elif mode=='alternating': c=(j%32)*500*32 + (j//32)*31*32;radius=(r.randrange(1600,2200) if j%2==0 else r.randrange(150,300))*32
  else: c=(j%8)*2400*32+r.randrange(-800,801)*32;radius=r.randrange(200,1800)*32
  out.append([c,radius,j])
 return sorted(out,key=lambda x:(-x[1],x[2]))
def build(A):
 n=len(A); edges=sorted(set([c-r for c,r,_ in A]+[c+r for c,r,_ in A])); idx={x:i for i,x in enumerate(edges)}; spans=[(idx[c-r],idx[c+r]) for c,r,_ in A]
 # receiver endpoints integral since radii multiples of 32
 be=sorted(set([c-r//32 for c,r,_ in A]+[c+r//32 for c,r,_ in A]));bi={x:i for i,x in enumerate(be)}; owned=[False]*(len(be)-1);vs=[]
 for c,r,_ in A:
  lo,hi=bi[c-r//32],bi[c+r//32];v=sum(be[i+1]-be[i] for i in range(lo,hi) if not owned[i]);vs.append(v)
  for i in range(lo,hi):owned[i]=True
 d=[F(2*r,S) for c,r,_ in A]; w=[F(v,2*r) for v,(_,r,_) in zip(vs,A)];L=[];loads=[F(0)]*(len(edges)-1)
 for (a,b),wi in zip(spans,w):
  L.append(max(loads[a:b]));
  for i in range(a,b):loads[i]+=wi
 ts=sorted(set(x for l,wi in zip(L,w) for x in (l,l+wi) if x>0));return edges,spans,d,w,L,ts,F(sum(vs),S),vs
class Tree:
 def __init__(self,n,k):
  self.size=1
  while self.size<n:self.size*=2
  self.mx=np.zeros((2*self.size,k));self.lazy=np.zeros_like(self.mx)
 def query(self,a,b,node=1,l=0,h=None):
  if h is None:h=self.size
  if a<=l and h<=b:return self.mx[node]
  mid=(l+h)//2;vals=[]
  if a<mid:vals.append(self.query(a,b,node*2,l,mid))
  if b>mid:vals.append(self.query(a,b,node*2+1,mid,h))
  return (vals[0] if len(vals)==1 else np.maximum(vals[0],vals[1]))+self.lazy[node]
 def add(self,a,b,x,node=1,l=0,h=None):
  if h is None:h=self.size
  if a<=l and h<=b:self.mx[node]+=x;self.lazy[node]+=x;return
  mid=(l+h)//2
  if a<mid:self.add(a,b,x,node*2,l,mid)
  if b>mid:self.add(a,b,x,node*2+1,mid,h)
  self.mx[node]=np.maximum(self.mx[node*2],self.mx[node*2+1])+self.lazy[node]
def evaluate(arg):
 N,mode=arg;start=time.monotonic();cpu=time.process_time();A=make(N,mode);edges,spans,d,w,L,ts,V,vs=build(A)
 t=np.array(list(map(float,ts)));wf=np.array(list(map(float,w)));df=np.array(list(map(float,d)));lf=np.array(list(map(float,L)))
 old=np.minimum(wf[:,None],np.maximum(0,t[None,:]-lf[:,None]));go=(df@old)/t
 tree=Tree(len(edges)-1,len(t));obj=np.zeros(len(t))
 for j,(a,b) in enumerate(spans):
  load=tree.query(a,b);q=np.minimum(wf[j],np.maximum(0,t-load));tree.add(a,b,q);obj+=df[j]*q
 new=obj/t; cap=tree.mx[1]/t
 assert np.all(new+1e-9*np.maximum(1,abs(go))>=go) and np.max(cap)<=1+1e-10
 io=int(np.argmax(go));ik=int(np.argmax(new));return {'N':N,'mode':mode,'seed':660000+10*N+modes.index(mode),'intervals':A,'coordinate_denominator':S,'positive_thresholds':len(ts),'V':str(V),'old_threshold':str(ts[io]),'keep_threshold':str(ts[ik]),'Gold_float':float(go[io]),'Gkeep_float':float(new[ik]),'gain_ratio':float(new[ik]/go[io]),'gain_absolute':float(new[ik]-go[io]),'max_capacity_all_thresholds':float(max(cap)),'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'zero_owners':sum(v==0 for v in vs)}
def replay(z):
 A=z['intervals'];edges,spans,d,w,L,ts,V,vs=build(A);told=F(z['old_threshold']);t=F(z['keep_threshold']);assert t in ts and told in ts
 old=[min(wi,max(F(),told-li)) for wi,li in zip(w,L)];old2=[min(wi,max(F(),t-li)) for wi,li in zip(w,L)];loads=[F()]*(len(edges)-1);q=[]
 for (a,b),wi in zip(spans,w):
  qi=min(wi,max(F(),t-max(loads[a:b])));q.append(qi)
  for i in range(a,b):loads[i]+=qi
 o=sum((di*qi for di,qi in zip(d,old)),F())/told;k=sum((di*qi for di,qi in zip(d,q)),F())/t;old_at_keep=sum((di*qi for di,qi in zip(d,old2)),F())/t
 cap=max(loads)/t;assert cap<=1 and k>=old_at_keep and k>=o
 return {'N':z['N'],'mode':z['mode'],'old_threshold':str(told),'keep_threshold':str(t),'V':str(V),'Gold_at_selected_threshold':str(o),'Gkeep_at_selected_threshold':str(k),'old_at_keep_threshold':str(old_at_keep),'gain_exact':str(k/o),'capacity_exact':str(cap),'input_ref':f"residual_results.json N={z['N']} mode={z['mode']}",'note':'Exact values at selected old breakpoints; float search does not certify global ordering of very close breakpoint objectives.'}
if __name__=='__main__':
 start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN);results=[]
 print('R660-RP-01 PID',os.getpid(),'max_workers 4',flush=True)
 with ProcessPoolExecutor(max_workers=4,mp_context=get_context('fork')) as pool:
  for Ns in ([64,128],[256],[512]):
   out=list(pool.map(evaluate,[(n,mode) for n in Ns for mode in modes],chunksize=1));results.extend(out);print('passed',Ns,'max gain',max(z['gain_ratio'] for z in out),flush=True)
 chosen=[]
 for z in [max(results,key=lambda z:z['gain_ratio'])]+sorted(results,key=lambda z:z['gain_absolute'],reverse=True):
  if z not in chosen:chosen.append(z)
  if len(chosen)==3:break
 cert=[replay(z) for z in chosen];r1=resource.getrusage(resource.RUSAGE_CHILDREN)
 out={'task':'R660-RP-01','results':results,'wall_seconds':time.monotonic()-start,'worker_cpu_seconds':r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'parent_cpu_seconds':time.process_time(),'max_workers':4,'BLAS_threads':1,'python':platform.python_version(),'numpy':np.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'real one-dimensional intervals; no dimension-order or global proof claim'}
 (P/'residual_results.json').write_text(json.dumps(out,indent=2)+'\n');(P/'residual_certificates.json').write_text(json.dumps(cert,indent=2)+'\n');print('COMPLETE',len(results),'wall',out['wall_seconds'],flush=True)
