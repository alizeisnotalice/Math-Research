# R660 independent numerical certificate audit

**Verdict: PASS for the three saved one-dimensional cluster certificates (N=64,128,256).** Their new retained-load packing is feasible on all space a.e. and its objective at the saved selected threshold is strictly greater than the maximum of the old construction over every old positive breakpoint. The N=64 exact ratio is independently verified as 22088823/18133504, which is greater than 6/5.

The audit does not certify a globally optimal new threshold, a packing-LP optimum, a high-dimensional numerical conclusion, a calibrated or near-extremal state, or a dimension bound. Merge checking below is a read-only consistency review of its saved Arb results; those Arb computations were not rerun.

## Independence, inputs, and scope

I first read TASK.md, then residual_results.json and residual_certificates.json as raw interval inputs and proposed expected answers. I did not read or import the residual producer's algorithm functions. The parent supplied the mathematical retained-load recursion, including the normalization and zero-owner convention. I independently implemented the exact geometry and both old/new constructions in audit_numeric.py, using Python's Fraction and one process. The only producer source read was merge_check.py, as explicitly requested for its separate metadata review.

Only the clusters records N=64,128,256 were computed. No 16-family floating rerun, larger scan, LP solve, or new candidate search was performed. Only audit_numeric.py, audit_numeric.json, and this report were written. Other workers' files were not modified and no Git operation was performed.

## Exact geometry and old threshold maximum

Each input triple is (center numerator, radius numerator, original tag), with common coordinate denominator 32768. I verified that the saved list is in descending radius order, with original tag resolving radius ties. For n=1, a=32, the actual intervals are A=(y-s,y+s) and B=(y-s/32,y+s/32), divided by the common denominator. Every positive-length atom of the full B endpoint arrangement is assigned to its first containing label in that order. This gives genuine disjoint receiver owners E, exact lengths v, and union length V=sum v. All w=v/d satisfy 0<=w<=1/32, where d=2s.

Separately, every positive-length membership cell of the full A endpoint arrangement is constructed. For each label j, old L_j is the maximum of the sum of earlier w_i on **all** cells inside A_j. This is the exact essential supremum; neither center load nor an owner average is substituted. Zero-volume receiver owners are retained in order with w=0.

I evaluated G_old(t)=sum d_j min(w_j,max(0,t-L_j))/t at every distinct positive breakpoint in {L_j,L_j+w_j}. There are respectively 46,119,249 such thresholds, matching the saved counts. This includes extra harmless breakpoints from zero owners; filtering them would leave 45,113,233. Each positive threshold is stored with its exact rational objective in audit_numeric.json. The saved old threshold attains the maximum, and all reported exact old scores agree.

This finite breakpoint maximum is also the old construction's maximum over t>0: between breakpoints its numerator is affine in t, so its objective is A+B/t and is monotone or constant. Below the first positive breakpoint the zero-L positive terms are constant; above the last breakpoint the objective decays to zero. Thus no unsampled interior t can exceed the endpoint maximum.

## New retained-load certificate

For each saved selected threshold t, I restart q at zero and compute in the same radius order

q_j=min(w_j,max(0,t-max_{x in A_j} sum_{i<j}q_i 1_{A_i}(x))),

taking the maximum over every full A membership cell in A_j. Here q is **unnormalized**, q=0 for w=0, final theta=q/t, and G_keep=sum d_j q_j/t. The incremental loads are checked against t after every update.

A separate final reconstruction sums theta_j directly on every full A membership cell and checks its exact maximum. For all three records this maximum is exactly 1; outside the union of A the load is zero. The finitely many interval endpoints are Lebesgue null and do not affect a.e. feasibility. Consequently this is a shared globally feasible packing, rather than a source-site or center-only check. All v,w,L,q,theta vectors, receiver owner atoms, and final full-cell loads are saved in audit_numeric.json.

| N | V | old positive breakpoints | selected new t | exact selected new G_keep | maximum final capacity |
|---|---|---|---|---|---|
| 64 | 112223/32768 | 46 | 1/32 | 7362941/438272 | 1 |
| 128 | 202301/32768 | 119 | 3/32 | 605647/34656 | 1 |
| 256 | 74731/8192 | 249 | 3/32 | 2373261775045/131982529536 | 1 |

For N=64, max_t G_old(t)=331/24, attained at t=3/32; the old objective at the new threshold is only 5199/512. The certified comparison uses the old **maximum**, and gives

G_keep/max_t G_old = 22088823/18133504 > 6/5,

G_keep-max_t G_old = 3955319/1314816 > 0.

For N=128 and N=256 the very large exact old maximum, ratio, and positive difference agree with every fraction in residual_certificates.json; the complete fractions are preserved in audit_numeric.json. Approximate ratios are 1.1199588263 and 1.1069391370. The strict comparisons in the audit use rational arithmetic, not these decimal displays. The new score is only certified at its selected threshold, even though it already exceeds the old threshold construction's full maximum.

## Merge results: count, precision, provenance, and endpoint review

I read merge_check.py and merge_results.json and verified the saved script SHA-256 matches the source bytes. The listed work is exactly:

- Four base groups: n=16,32 and B=2,4; one L0=n log B point in each group.
- Twenty-one expanded groups: n=16,32,64,128,256,1024,4096 and three B choices, namely 2 log n+10^-20, (2 log n+n/2)/2, and n/2-10^-20.
- Each expanded group has L0=n log B, its midpoint with L1, and L1=n log n.

This is 25 groups, 67 total psi points, and 63 expanded h points. Every saved group uses 192-bit precision; the script permits escalation to 384 or 768 bits, but no saved group needed that. Every saved psi+B sign is negative and every saved expanded h+B sign is negative. All 25 saved far-coefficient comparisons are strict against exp(33/32). This review verifies those recorded counts and signs and the code's ranges; it does not recompute the transcendental Arb enclosures.

The lower/upper B samples are displaced **inside** the expanded range by 10^-20. They are not the exact B=2 log n or B=n/2 boundary. The four B=2,4 groups are separate base tests, not members of the expanded 2 log n<B<n/2 grid.

The relation h-psi is recorded strictly positive at 46 sampled points. At the 21 L1 points its saved interval sign is undetermined because h=psi exactly there: K=log(L1/B), so (K-log(L1/B)) exp(L1/n)=0. The saved undetermined relation is therefore consistent with equality and must not be called strict. Separately, psi(B,B)+B=0 is an exact symbolic identity; L=B is not an additional numeric point in the 67-point count.

These finite scalar checks cannot certify a high-dimensional finite cube realization, all real parameters in the displayed ranges, or the final dimension theorem. Any extension by analytic convexity or other general argument needs its own proof audit.

## Reproduction and resources

Command, run with this directory as cwd:

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python audit_numeric.py

Actual final run used Python 3.12.14, one process, and only the standard library for its computations; BLAS environment limits were all one. Recorded wall time was about 0.2611 s and CPU time about 0.2598 s. No arbitrary precision transcendental work was rerun. The audit JSON records SHA-256 hashes for the frozen task, both residual JSON inputs, both merge files, and this independent script.
