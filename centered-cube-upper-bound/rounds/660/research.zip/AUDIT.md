# R660 独立审计：A/B/C

2026-11-15。先独立推导 A/B/C，随后读取 `CLIQUE_GEOMETRY.md`、`THRESHOLD_DECISION.md`；二者相关原子段通过。读取时 `PACKING_GEOMETRY.md` 不存在，未声称已审该稿。未重跑烟测、网格或数值扫描，未操作 Git，只写本文件。

**总判定：全族 far 付款、near 范围消除、多点共享 lens 引理及 A/B/C 均按本文精确条件成立。** A 给出全族实际可行构造及对旧阈值的弱支配；B 给出特定 receiver 交互的窄尺度限制；C 给出共同点、大尺度前缀的指数收费。尚无全族一次容量分配，不能据此声称纯 \(\sqrt n\) 或完整全局预算。

## 决定性新增引理：共享多点 lens 与一次付款（独立通过）

本节先按任务命题独立证明。随后仅定位了作者 `CLIQUE_GEOMETRY.md` 的段落标题；当时尚未出现这个新增段，不声称已核作者新稿。下面的结论是真实共享行族的条件收费，不是全族分组定理。

设同一个有限行族 \(I\) 的每个 \(A_i\) 都包含同一非空有限点集 \(Z\)，所有 \(s_i\ge r>0\)，真实 \(F_i\subset B_i\) 两两不交。记 \(u_i=|F_i|\)、\(q_i=u_i/(2s_i)^n\)、\(U=\sum_Iu_i\)、\(T=\sum_Iq_i>c\)，其中 \(c_0=1+1/a,c=c_0^n\)。令 \(\Delta_k=\max_Zz_k-\min_Zz_k\ge0\)。

**真实 lens，而非父方体体积。** 若 \(x\in F_i\)、\(z\in Z\)，则 \(\|x-z\|_\infty\le c_0s_i\)。因此对任何 \(s\)，
\[
\bigcup_{i:s_i\le s}F_i\subset\bigcap_{z\in Z}Q(z,c_0s),
\qquad
U(s):=\sum_{i:s_i\le s}u_i
\le\min\!\left(U,\prod_k[2c_0s-\Delta_k]_+\right).
\tag{L1}
\]
第一式用同一个 \(F_i\) 同时接近所有 \(Z\)，第二式用真实不交性。若 lens 某方向退化，体积为零，不产生边界例外。若不同点使用不同的行族，不能得到 (L1)。

**系数与积分起点。** 有限求和交换给出
\[
\frac n{2^n}\int_r^\infty U(s)s^{-n-1}\,ds
=\sum_i\frac{nu_i}{2^n}\int_{s_i}^\infty s^{-n-1}\,ds
=\sum_i\frac{u_i}{(2s_i)^n}=T.
\tag{L2}
\]
所以任务中的系数与起点均正确；\(s_i=r\) 的跳点不影响积分。若某参与行 \(s_i<r\)，这个等式即不再成立。

设
\[
D_0=c(2r)^n,\quad L=\log(U/D_0),\quad B=T/c-1>0,
\quad\delta_k=\Delta_k/(2c_0r),\ S=\sum_k\delta_k.
\]
若 \(U\le D_0\)，则 \(T\le U/(2r)^n\le c\)，矛盾；故 \(L>0\)。置 \(q=e^{L/n}>1\)，将 (L2) 以 \(x=s/r\) 归一化并在 \(q\) 分开。对所有 \(x>0\)，
\[
\prod_k(x-\delta_k)_+\le x^n e^{-S/x},
\]
因为存在非正因子时左侧为零，否则用 \(1-u\le e^{-u}\)。从而
\[
\begin{aligned}
T/c
&\le n\int_1^q e^{-S/x}\frac{dx}{x}
  +n e^L\int_q^\infty x^{-n-1}\,dx\\
&\le L e^{-S/q}+1.
\end{aligned}
\]
尾部恰付 1，没有遗漏系数。因此
\[
\boxed{L\ge B,\qquad
\sum_k\Delta_k\le2c_0r\,e^{L/n}\log(L/B).}
\tag{L3}
\]

**目标 receivers 的真实外包。** 任意目标父方体 \(A'_j\) 半径 \(s'_j\le r\)，且包含至少一个 \(z\in Z\)，都有
\[
B'_j\subset\bigcup_{z\in Z}Q(z,c_0r)
\subset\prod_k[\min_Zz_k-c_0r,\max_Zz_k+c_0r].
\]
所以其真实并集（或实际不交 owner 子集）的体积至多
\[
\prod_k(2c_0r+\Delta_k)
\le D_0e^S
\le\boxed{U\exp\!\left[-L+e^{L/n}\log(L/B)\right].}
\tag{L4}
\]
端点包含与有限目标数不引入额外因子；对任意可测目标并集同样由该统一外包成立。

**主代理加强通过。** 若 \(B>1\) 且 \(B\le L\le n\log B\)，则 \(e^{L/n}\le B\)，而 \(\log(L/B)\le(L-B)/B\)。故 (L4) 的指数至多
\[
-L+B\log(L/B)\le-B,
\]
得到 \(\boxed{|\cup B'_j|\le e^{-B}U}\)。不需要 \(L\approx B\)。但该区间必须非空；\(B>1\) 本身不保证 \(L\le n\log B\)，区间之外不能擅用此加强。

**适用范围与剩余缺口。** (L1) 的坐标 lens 乘积及 (L4) 的坐标外包是实质方体几何，区别于仅共同一点的通用对称凸体付款。它确实允许多点、多 clique 使用同一族 \(I\) 的真实体积 \(U\) 一次收费。尚未证明任意 blocked 行可分成满足上述同族包含、共同半径下限和参数区间的目标组，也未证明不同组不会重复花费同一 \(F_i\)。不能由各 clique 各自的 prefix 或各行不同 esssup 见证拼成这里的同一共享 \(I\)。因此这是严格有效的新条件付款引理，不是纯 \(\sqrt n\) 的全局完成。

## 全族 far 付款与 near 参数范围：新增独审通过

### 完整饱和前缀可用 \(\tau\)，没有 \(b\) 损失

固定同一个半径非增残余递推，阈值 \(\tau>0\)，\(F_j\subset E_j\) 体积为 \(d_jq_j\)，丢失片 \(D_j=E_j\setminus F_j\)。若 \(|D_j|>0\)，则 \(q_j<w_j\)。记加入当前行前的 esssup 为 \(\ell_j\le\tau\)。若 \(q_j=0\)，递推迫使 \(\ell_j=\tau\)；若 \(0<q_j<w_j\)，则 \(q_j=\tau-\ell_j\)。两者都有
\[
\ell_j+q_j=\tau.
\]
有限 membership cells 保证 esssup 在 \(A_j\) 内某个正测 cell 上取得。可选 \(z_j\) 避开全族所有面，并在最终 cap 的满测集内，于是
\[
\sum_{i\le j}q_i1_{A_i}(z_j)=\tau.
\]
任何未来 \(q_i>0\) 的 \(A_i\) 不可能包含这个 \(z_j\)，否则违反最终 cap。因此准确的点行族
\[
I(z_j)=\{i:q_i>0,\ z_j\in A_i\}\subset\{i:i\le j\}
\]
有总负载 \(\tau\)，且每个 \(s_i\ge s_j\)。不是“所有前缀行都包含 \(z_j\)”。它是最终 positive-q 的点 clique；不能仅凭此把它称为含零权行的全 \(A\) 图极大 clique。

将该点负载分成 \(s_i\ge ns_j\) 的 far 与 \(s_j\le s_i<ns_j\) 的 near，至少一支达到 \(\tau/2\)。每个丢失行选一个见证即可；若两支都达标可优先归 far。

### 一次全族 far 付款

置 \(\lambda=1+c_0/n\)。若行 \(j\) 的 far 达标，则对任意 \(x\in D_j\subset B_j\)，有 \(\|x-z_j\|_\infty\le c_0s_j\)，而所有参与 far 的 \(i\) 满足
\[
\|x-y_i\|_\infty\le s_i+c_0s_j\le\lambda s_i.
\]
因此全族同一个膨胀负载场在所有这些 \(D_j\) 上至少为 \(\tau/2\)。真实丢失片两两不交，故
\[
\frac\tau2|D_{\rm far}|
\le\int_{D_{\rm far}}\sum_iq_i1_{\lambda A_i}(x)\,dx
\le\lambda^n\sum_i d_iq_i.
\]
于是无全族重数损失地得到
\[
\boxed{|D_{\rm far}|\le\frac{2\lambda^n}{\tau}U_{\rm total}
\le\frac{2e^{33/32}}\tau U_{\rm total},
\quad U_{\rm total}=\sum_i|F_i|.}
\tag{FAR}
\]
常数由 \(\lambda^n\le e^{c_0}\le e^{33/32}\)。这里不要求各 \(z_j\) 相同；共同的全族场与不交 \(D_j\) 消除了重复计费。\(n=1\) 时当前行落 far，near 为空，证明仍成立。

**独立较弱版本并不矛盾。** 若坚持只看 \(i<j\) 的前缀，则由 \(q_j<w_j\le b\) 有 \(\ell_j=\tau-q_j>\tau-b\)。当 \(\tau>b\) 时可用 \(T=\tau-b>0\)，得到 \(2e^{33/32}U_{\rm total}/T\) 的弱界。该推导不能把 \(T\) 偷换成 \(\tau\)；主稿采用上面的含当前行饱和前缀则可合法消除损失。

### Near 的超大 \(U\) 例外在指定范围内消除

对一个真正共享的近组，若同一 \(I\) 包含全部 \(Z\)，且所有 \(s_i\in[r,nr]\)，则共同点包络给
\[
U_I\le c(2nr)^n,\qquad L\le n\log n.
\]
这不能从各行各自有 near 负载自动推给它们的交集。\(B\) 仍是该共享 \(I\) 已证明负载除以 \(c\) 后减 1；若用较低的已证负载下限，lens 论证可相应使用较小正 \(B\)，但其参数范围必须核实。

严格的解析加强如下：若 \(n\ge16\)、\(2\log n\le B\le n/2\)，则对每个 \(B\le L\le n\log n\)，
\[
\boxed{\Psi(L)=-L+e^{L/n}\log(L/B)\le-B.}
\tag{NEAR}
\]
当 \(L\le L_0=n\log B\)，上一节已证。其余置 \(L_1=n\log n\)、\(K=\log(n\log n/B)>0\)。有 \(\Psi(L)\le f(L)=-L+Ke^{L/n}\)，且 \(f\) 凸，故只需核两端点：
\[
f(L_1)=n\log(\log n/B)\le-n\log2\le-B.
\]
又本范围 \(B>e\)，\(\log B/B\) 递减，故
\[
\frac nB\log B\ge2\log(n/2),\qquad
K\le\log(n/2),\qquad\log(n/2)\ge1.
\]
于是 \(f(L_0)/B=-(n/B)\log B+K\le-1\)。凸性完成整个第二段。该证明无需 \(L\approx B\)，但不能删除 \(n,B\) 范围。

**全局状态。** (FAR) 已经是真实全族付款，(NEAR) 让每个满足共享条件及参数范围的 near merge 在 \(U_I\) 的全部可能范围内享有 \(e^{-B}U_I\) 支付。仍缺覆盖所有 near 丢失行的共同 \(I\) 分组，以及跨组不重复花费来源的分配。不能把这两个已证局部/分支结论宣称为纯 \(\sqrt n\) 的完成。

## A. 实际保留前缀：通过，网格结论须限域

固定 \(t>0\)，记 \(L_j=\operatorname{ess\,sup}_{A_j}\sum_{i<j}w_i1_{A_i}\)，并按任务递推 \(q_j\)。归纳假设前缀负载 a.e. 不超过 \(t\)，则其在 \(A_j\) 上的 esssup 也不超过 \(t\)。添加
\[
q_j=\min\{w_j,(t-\operatorname{ess\,sup}_{A_j}\sum_{i<j}q_i1_{A_i})_+\}
\]
后，\(A_j\) 内负载仍至多 \(t\)，外部不变。有限多个异常零测集取并仍零测，故 \(q/t\) 是同一个全空间 a.e. packing 的可行向量。

又 \(q_i\le w_i\)，故实际前缀 esssup 不超过 \(L_j\)，逐行有
\[
q_j\ge\min\{w_j,(t-L_j)_+\}.
\]
在旧的至多 \(2m\) 个正断点上比较同一个 \(t\)，即得
\[
\boxed{P\ge G_{\rm keep}\ge G_{\rm old}.}
\]
这不证明旧网格包含新递推关于 \(t\) 的全局最优点，也不保证每个族严格改善。零 owner 行可保留为 \(w_j=q_j=0\)。每个 \(q_jd_j\le|E_j|\)，可由 Lebesgue 无原子性在真实 \(E_j\) 内选取该体积的 \(F_j\)，不需虚构来源或抽象图。

作者的三立方体路径例及其解析计算相容：旧值 \(3d/2\)，新值 \(2d\)，只说明阻挡解除确可严格改善，不能校准根阶难度。递推可行性本身适用于一般可测集合；用最大 clique 权计算真实 esssup 时，才使用方体的正体积 2-Helly 性质。

## B. 包含与极大 clique：通过，但只约束真实 receiver 交边

这里的 clique 必须属于父 \(A_j\) 的正体积相交图，不是 receiver 图。令 \(a=32n>1\)、\(\beta=(a+1)/(a-1)\)。若 \(|B_i\cap B_j|>0\)，则
\[
\|y_i-y_j\|_\infty<(s_i+s_j)/a.
\]
若 \(s_i\ge\beta s_j\)，则对 \(z\in A_j\)，
\[
\|z-y_i\|_\infty
 <s_j+(s_i+s_j)/a\le s_i.
\]
所以连等号半径边界也给 \(A_j\subset\operatorname{int}A_i\)。若 receivers 只有零体积触边，不能沿用这个严格内含结论。

若 \(D\) 是包含 \(j\) 的 inclusion-maximal clique，\(A_i\supset A_j\) 使 \(i\) 与 \(D\) 每个成员有正体积交；极大性迫使 \(i\in D\)。因此对不同极大 cliques \(C,D\)，若 \(i\in C\setminus D,j\in D\setminus C\) 且 receivers 正测相交，两端包含都被排除，严格得到
\[
\boxed{\beta^{-1}<s_i/s_j<\beta,
\quad \max(d_i,d_j)/\min(d_i,d_j)<\beta^n\le33/31.}
\]
最后常数由作者所写正项级数逐项比较严格成立。这里需要的是“极大”而非“最大基数”；所有最大 cliques 固然极大，但只取最大 cliques 可能漏掉行和真实约束。

**费用与适用面。** 结论仅涉及两个 clique 的互斥成员及真实 receiver 交边；对共享成员没有同样的半径限制，不能让每个 clique 分别领取同一共享行的全部容量。任意指派 clique 后也不能自动保留集合差条件。blocking point 只证明父 \(A\) 相交，不保证 receiver \(B\) 相交，故不能把本引理套给所有阻挡关联。

包含阈值与归属包含推理对固定对称凸体同位似族同样成立。方体特征是把一个 clique 或归属包含链变成真实共同正体积交，而不是上述三角不等式。作者已正确限定此范围。

## C. 同一点的大尺度负载：通过；组收费须共享见证

取参与某一前缀负载的有限索引集 \(I\)，每个 \(i\in I\) 都有同一 \(z\in A_i\)、\(s_i\ge r>0\)，且真实 \(F_i\subset E_i\subset B_i\) 两两不交。置
\[
u_i=|F_i|=d_iq_i,\quad U=\sum_{i\in I}u_i,
\quad d_r=(2r)^n,\quad c=(1+1/a)^n.
\]
对任意 \(D>0\)，所有 \(d_i<D\) 的 \(F_i\) 均在以同一 \(z\) 为中心、体积至多 \(cD\) 的方体内。因此
\[
\sum_{i:d_i<D}u_i\le\min(U,cD).
\]
Layer cake 给出完整严格估计
\[
\begin{aligned}
\sum_{i\in I}q_i
&=\int_0^{1/d_r}\sum_{i:d_i<1/u}u_i\,du\\
&\le\int_0^{1/d_r}\min(U,c/u)\,du\\
&=\begin{cases}
U/d_r,&U\le cd_r,\\
c[1+\log(U/(cd_r))],&U>cd_r.
\end{cases}
\end{aligned}
\]
积分端点不影响恒等式；\(U=0\) 另作零值即可。故负载至少 \(t>c\) 时，
\[
\boxed{U\ge cd_r\exp(t/c-1).}
\]
若 \(U\) 还包括未参与负载的 pieces，右侧负载上界随 \(U\) 单调，结论仍成立但更弱。此共同点包络与积分同样适用于固定对称凸体，不是方体独有机制。

**合法组收费。** 要给一组目标 receivers 收费，须同时证明：这些父方体包含同一 \(z\)；取 \(r\) 为组内最大父半径；在这个同一 \(z\) 有一个确实只使用 \(s_i\ge r\) 的前缀，负载至少 \(t\)。此时目标 receiver 并集至多 \(cd_r\)，可由上式用至多 \(e^{1-t/c}U\) 支付。

每行自己的 esssup 见证可能不同，也可能在 clique 共同交之外。半径非增只保证某行前缀半径不小于该行半径，不能把较晚小行的前缀半径下限提升为整个目标组的最大半径。因此不能拼接不同位置、不同时间的前缀。最后，即使每组局部收费合法，汇总仍须控制同一个 \(F_i\) 被多个组重复收费的次数或给出共享容量分配；A/B/C 都没有自动完成这一步。

**停止结论。** A 给出实际保留构造；新增共享 lens 给出多点条件付款；含当前行的饱和前缀使 far 分支已经取得无重数损失的全族付款；near 的超大体积例外在指定参数范围内已消除。准确未证步仍是覆盖所有 near 行的合格共享分组及跨组容量分配，使某个真正共同可行向量达到 \(V/(K\sqrt n)\)。此处没有反证一般目标，也没有把条件付款升级为纯根阶定理。审计到此停止。
