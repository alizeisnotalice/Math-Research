from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product,combinations
from math import comb,factorial
from pathlib import Path
import json

def dc(x):
 if isinstance(x,F):return D(x.numerator)/D(x.denominator)
 return D(x)
def canon(x):return str(D(format(x,'.18g')).normalize())
def pvec(q,m):
 v=[(-q).exp()]
 for j in range(1,m+1):v.append(v[-1]*q/j)
 return v

def tail(q,k):
 term=pvec(q,k)[k];v=term;j=k
 while term>v*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;v+=term
 return v

def matvec(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def gamma_int(d,lo,hi):
 def s(x):return (-x).exp()*sum(x**j/D(factorial(j)) for j in range(d+1))
 return D(factorial(d))*(s(lo)-s(hi))
def flux(q,p,m,future):
 out=D(0)
 for r in range(m+1):
  c=sum(D(comb(m,j)*comb(m-j,r-j)*(-1)**(r-j))*future[j] for j in range(r+1))
  out+=c*(q*p)**r*gamma_int(m-r,q*p,q)/D(factorial(m))
 return out

def probabilistic(precision):
 with localcontext() as ctx:
  ctx.prec=precision;out=[];gammas=[];vertices=[]
  patterns=[([F(1,2),F(1,2)],[F(0),F(0)]),([F(1,2),F(1,4)],[F(2),F(1,2)]),([F(3,4),F(1,2),F(1,4)],[F(1,4),F(4),F(1)])]
  for m in (1,2,4,8):
   for q0 in (D('0.25'),D(2),D(8)):
    for pat,(pp,bb) in enumerate(patterns):
     qs=[];q=q0
     for p,b in zip(pp,bb):qs.append(q);q=q*dc(p)+dc(b)
     terminal=tail(q,m+1);future=[D(1)]*(m+1);total=D(0);raw=D(0)
     for i in reversed(range(len(pp))):
      p=dc(pp[i]);beta=dc(bb[i]);probs=pvec(beta,m)
      B=[[probs[j-k] if j>=k else D(0) for j in range(m+1)] for k in range(m+1)]
      right=matvec(B,future)
      total+=flux(qs[i],p,m,right);raw+=flux(qs[i],p,m,[D(1)]*(m+1))
      death=[[D(comb(k,j))*p**j*(1-p)**(k-j) if j<=k else D(0) for j in range(m+1)] for k in range(m+1)]
      future=matvec(death,right)
     hit=1-sum(x*y for x,y in zip(pvec(q0,m),future))
     tol=D(10)**(-precision+15)
     assert abs(hit-terminal-total)<tol and total>=-tol and raw+tol>=total and 0<=hit<=1
     out.append(dict(m=m,q0=str(q0),pattern=pat,hit=canon(hit),terminal=canon(terminal),last_exit=canon(total),raw_downcrossings=canon(raw)))
  for n in (1,4,16,64,256):
   B=D(2)**n
   for c in (D('0.001'),D(1),D(32)):
    for r in (2,3,5):
     v=B*tail(c/B,r)+c*gamma_int(r-2,c/B,c)/D(factorial(r-1))
     assert -D('1e-50')<=v<=c/(r-1)+D('1e-50')
     gammas.append(dict(n=n,c=str(c),r=r,volume_over_c=canon(v/c),cap=canon(D(1)/(r-1))))
  for n in (8,16,32,64,128,256,1024):
   R=2**n;T=D(n)*D(2).ln();m=int((64*(2+T).ln()).to_integral_value(rounding='ROUND_CEILING'));x=D(m)/D(R)
   if x<D('0.1'):
    term=-D(R)*x*x/2;logno=term;j=2
    while abs(term)>max(abs(logno),D('1e-1000'))*D(10)**(-precision+8):
     term*=-x*D(j)/(j+1);j+=1;logno+=term
   else:logno=D(R)*(1+x).ln()-m
   no_dup=logno.exp();term=(-D(m)).exp();low=term
   for j in range(1,m+1):
    term*=D(R-j+1)/D(R)*D(m)/j;low+=term
   good=no_dup-low
   bound=max(D(0),D(1)/16-D(m*m)/(2*D(R)));core=(1-D(1)/n)**n
   tol=D(10)**(-precision+10)
   assert good>=bound-tol and good>=-tol and core>=D('0.25')
   vertices.append(dict(n=n,m=m,all_distinct_hit=canon(good),analytic_probability_lower=canon(bound),core_normalized_volume=canon(core*good)))
  return dict(last_exit=out,gamma=gammas,vertices=vertices)

def shifts():
 out=[]
 for n in (1,2,3):
  for r in (2,3,5):
   for pat in range(6):
    ys=[tuple(F(((i*(j+1)+pat*i*i)%7),8) for j in range(n)) for i in range(r)]
    if pat==4:ys[-1]=tuple(v+1 for v in ys[-1])
    if pat==5:ys=[tuple(F(i%2) for _ in range(n)) for i in range(r)]
    spans=[max(y[j] for y in ys)-min(y[j] for y in ys) for j in range(n)]
    predicted=F(1)
    for v in spans:predicted*=max(F(0),1-v)
    cuts=[sorted(set([F(0),F(1)]+[y[j]%1 for y in ys])) for j in range(n)]
    exact=F(0)
    for ids in product(*[range(len(c)-1) for c in cuts]):
     s=[(cuts[j][i]+cuts[j][i+1])/2 for j,i in enumerate(ids)]
     cells=[tuple((y[j]-s[j]).numerator//(y[j]-s[j]).denominator for j in range(n)) for y in ys]
     if len(set(cells))==1:
      v=F(1)
      for j,i in enumerate(ids):v*=cuts[j][i+1]-cuts[j][i]
      exact+=v
    assert exact==predicted
    if sum(spans)<=F(1,2):assert exact>=F(1,2)
    out.append(dict(n=n,r=r,pattern=pat,same_cell_probability=str(exact)))
 return out

def cover():
 out=[]
 for n in (1,2,3):
  d=F(1,n);a,b=F(1),F(2)
  for pat in (0,1,2):
   ys=[tuple(d*F((i*(j+1)+pat)%7,8) for j in range(n)) for i in range(6)]
   caps=[F(3+(i*2+pat)%7,4) for i in range(6)]
   for r in (2,3,5):
    cap=min(b,sorted(caps,reverse=True)[r-1]);tests=0;hits=0
    for x in product([F(-1),F(-1,2),F(0),F(1,2),F(1),F(3,2)],repeat=n):
     hit=False
     for ids in combinations(range(6),r):
      c=min([b]+[caps[i] for i in ids]);needed=max([a]+[2*max(abs(x[j]-ys[i][j]) for j in range(n)) for i in ids])
      hit|=needed<=c
     if hit:
      assert cap>=a and all(abs(x[j]-d/2)<=(cap+d)/2 for j in range(n));hits+=1
     tests+=1
    out.append(dict(n=n,pattern=pat,r=r,receivers=tests,hits=hits))
 return out

def main():
 s=shifts();c=cover();a=probabilistic(70);b=probabilistic(110);assert a==b
 result=dict(status='PASS finite guards; cooperative geometric budget remains unproved',shift=s,cover=c,**a,notes=['Fraction-exact geometry. Decimal70/110 agree at 18 digits, not interval certification.','Last-exit identity checked against a killed-chain matrix product using analytic integer-gamma time integration.','Scalar radial paths are realizable by nonnegative atomic cube sources at one fixed receiver; they do not measure a full-space weak ratio.','No random sampling or seeds.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',shift_cases=len(s),cover_cases=len(c),receiver_checks=sum(x['receivers'] for x in c),last_exit_cases=len(a['last_exit']),gamma_cases=len(a['gamma']),vertex_cases=len(a['vertices']))))
if __name__=='__main__':main()
