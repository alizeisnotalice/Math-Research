# 第560轮复现说明与数值笔记

解压到一个独立目录，使用指定解释器运行：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r560_numeric.py --all
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r560_certificate.py > certificate_reproduced.json
```

归档脚本只读写自身目录。`ccu_r560_numeric.json`包含必要的冻结dyadic输入；`--all`保留它。证书会独立重算质量、动作分段、原标签和完整能量，最后仅调用浮点代码作对照。程序默认不编译或生成PDF。以下原始笔记中的`/tmp/ccu_r560_*`为运行时来源路径；可复现成员名是同basename的相邻文件，最终运行/哈希见MANIFEST.json。NUMERICS与REPORT内的作者计算时间不等同主代理最终复现时间。

仅数值探索使用Sobol采样；严格Arb结果的对象是冻结有限样本，不是采样误差。没有将周期无限原子来源直接视为有限一般L1输入。

# R560 周期格点完整场：公式审计与数值输入合同

日期：2026-10-23。责任：主证明展开/统一符号角色，仅此文件。结论：周期平移计数、原 α、完整 Gram 与两种 selector 的公式均成立；有限块及小盒平滑可以逼近所述诊断模型，但连续模型的 α 阈值筛选另需稳定性或误差控制。没有得到一般 L1 的目标估计。

## 1. 固定对象、冻结顺序和单位

以 β∈T^n=[0,1)^n 表示真实 Lebesgue 中心，避免与 b_geom 混淆。周期计数测度

    μ∞=Σ_{z∈Z^n}δ_z

不是有限测度、不是 L1 函数。本文只定义每个周期的字段及能量，不把无穷总能量除以无穷总质量。

盒的 R 是**边长**：Q(B,R)=B+[-R/2,R/2]^n。原选择 R(β) 可测且周期，所有平移 k+β 使用同一个选择。定义

    m0(β)=μ∞Q(β,R(β)),       q0(β)=m0(β)/R(β)^n,
    E={β:q≤q0(β)≤λ_band},    s(β)=log_γ m0(β).

这里只在 E 内使用 s，因此 m0>0。q0 是实际格点质量密度，**不再除以 λ_band**。λ_band 是原密度带的上端，与之前 resolvent 的 killing rate 无关。

主代理已冻结的数值见证：

- 每个 n 取 a=√n、b_geom=2a；原固定有限网格 R_k=a(1+k/32)，k=0,…,32。
- 在这 33 个半径上选 q0 最大者，完全相同值取最小 R；先作此选择，再用 E 的密度带筛选。它是 grid witness，不是所有连续半径的最优选择。
- q∈{1,2,4}，λ_band=2q；因此 C=1+ln(γλ_band/q)=1+ln(2γ)。若 γ=2，则 C=1+ln4。
- A_n=1+n ln(b_geom/a)=1+n ln2。

G>1、γ>1、h>0 是运行前必须写入 manifest 的固定输入；沿母合同可取 0<h<min(1/6,log_γ2)，例如 γ=2、h=1/8。所有候选完整区间为 g∈[1,G]、新边长 g^(1/n)R。

原 R 网格覆盖 [a,b_geom]，故必须筛 top；这与“原 R 已限制到 b_geom/G^(1/n)”的较窄子模型不同。这里遵从主代理最新冻结的完整网格，再用 top 删除。不在原 L 或 α 建立前偷偷删除 top。

源点质量为 1；中心积分 dβ 是真实 Lebesgue 体积、T^n 体积为 1；g 是体积倍率、没有另一个 n Jacobian。若改用新边长 r 积分，才使用 dg=n(r/R)^(n-1)dr/R。σ 是 log_γ(质量) 的无量纲坐标，窗长度严格为 1；其三角核没有额外 lnγ 因子。

## 2. 平移计数和每个格点同一个完整字段

对任意 r>0，闭盒逐点恒等式为

    Σ_{k∈Z^n}1_{0∈Q(k+β,r)}
      =Σ_{k∈Z^n}1_{-k∈Q(β,r)}=μ∞Q(β,r).

因此不是把来源积分换成随机中心的自平方，而是先对所有真实父中心 k+β 求和，再作来源场。对任意 z∈Z^n，换元 B↦B-z 得同一个字段 A_z=A_0。

对 E 中的父定义

    m(β,g)=μ∞Q(β,g^(1/n)R),
    κ(β,g)=m(β,g)/m0(β)≥1,
    q_new(β,g)=m(β,g)/(gR^n)=q0(β)κ(β,g)/g,
    u(β,g)=log_γ κ(β,g),
    ℓ(β,g)=s(β)+u(β,g)=log_γ m(β,g),
    j(β,g)=floor(u(β,g)/h).

特别是 u=log_γ κ，**不是 log_γ g**。j 由实际质量比决定，不由候选体积决定。旧窗 s 也绝不改成 density 的对数。

给某个筛选后的周期父集合 D⊂E，以及每父来源前的概率 π_β，实际子场在每个格点均为

    A_j(σ)=∫_{T^n}1_D(β)∫_[1,G]
        q_new(β,g) 1_[ℓ(β,g),ℓ(β,g)+1](σ)
        1_{j(β,g)=j} π_β(dg)dβ.                    (F)

支持盒里的来源条件已由平移计数完整吸收为 m；没有删除来源交叉项。π 可依赖 β、全部旧场和先行冻结的 α，但不得观察随后选到的来源 z 才重新选择 g。

所有半径都有限且 R≥a>0，所以每个格点只接收有界区域内的父；m、相位范围和系数都有固定 n 下的有限上界。因此 (F) 及下面的 Fubini/Tonelli 操作有意义。

## 3. 母定义 α：消去的是同一个 m0，而非另加归一

准确母定义来自只读

    /Users/zhengzhihao/Math-Research-centered-cube-work/
      centered-cube-upper-bound/rounds/518/research.zip:r518_proof.md §1

其中 k_B=t_BR_B^(-n)1_QB 1_[s_B,s_B+1]，L=∫_E k_B，

    α(B)=〈L,k_B〉/(C t_B q_B).

当前 t_B=1，整个原 E（尚未 low/rapid/top 删除）的每源旧场为

    L(σ)=∫_E q0(β')1_[s(β'),s(β')+1](σ)dβ'.

由于所有格点处 L 相同，

    〈L,k_B〉
      =t_B R_B^(-n) Σ_{z∈Q_B}∫_[s_B,s_B+1]L(σ)dσ
      =t_B q_B ∫_[s_B,s_B+1]L(σ)dσ.

所以原提议正确：

    α(β)=C^(-1)∫_[s(β),s(β)+1]L(σ)dσ
         =C^(-1)∫_E q0(β')T(s(β)-s(β'))dβ',
    T(x)=(1-|x|)_+.                                      (α)

没有额外 m0、q0、R^n 或源数因子。尽管 μ∞ 不是 L1，原窗帽是局部几何事实，仍给 0≤L≤C 和 0≤α≤1：对固定 σ、来源 z，窗及密度带使

    γ^(σ-1)/λ_band ≤ R_B^n ≤ γ^σ/q.

积分 R_B^(-n)1_{z∈Q_B} 的同心立方体包络给

    1+n ln(R_max/R_min)=1+ln(γλ_band/q)=C.

这只核局部原窗帽，不把母合同其余全局分格或 L1 付款自动迁移到周期模型。

**筛选顺序**：先在整个原 E 建 L，按 (α) 算 α 并冻结。然后依次互斥定义

    low   ={β∈E: α(β)≤1/A_n};
    high  =E\low;
    rapid ={β∈high: κ(β,G)≥max(γ^h,A_n α(β))};
    top   ={β∈high\rapid: R(β)≥b_geom/G^(1/n)};
    bulk  =E\(low∪rapid∪top).

π 的比较场 D=bulk。边界等号照上述方向处理；不得删完后重算 L 或 α。top 后所有 bulk 父都满足完整 g∈[1,G] 的边长上限。若 E 或 bulk 为空，报告为空；不另找好中心替代 Lebesgue 域。

## 4. 完整能量与 Gram：先积分场，再平方

定义每周期质量 W_per=1，按单位来源格点的能量

    B_per=Σ_j∫_R A_j(σ)^2dσ.

这才是此诊断模型所谓“能量/质量”。若用有限盒平均极限，可另外证明它等于该极限；当前不写无限量 E∞/W∞。

用 T(x)=(1-|x|)_+，完整 Gram 为

    B_per=∫_D∫_D∫π_β(dg)∫π_β'(dg')
       q_new(β,g)q_new(β',g')
       1_{j(β,g)=j(β',g')}
       T(ℓ(β,g)-ℓ(β',g')) dβ dβ'.              (Gram)

所有父对、所有动作对和实际相位都在；不同父对不会因为周期性被删掉。同一个父样本的能量再取平均，或把各中心自平方相加，都不是 (Gram)。对于没有 phase 分组的旧场，B_old,all=∫L_E²，也由同一双父三角核给出；它生成原 α。若公平比较 bulk 上的新 selector，还应另报 B_old,bulk=∫L_bulk²，保持同一个父域。原 α 仍来自 L_E，绝不由 L_bulk 重算。

相位后的比较平移 Z=Σ_jU_(-jh)A_j 与真实分相位能量 B_per 不是同一字段。本文件只计算真实 B_per，不用平移后窗代替实际窗。

## 5. 两个概率及质量平台的精确有限压缩

两种概率均合法且总质量为 1：

    N_β=1+∫_1^G dg/κ(β,g)+G/κ(β,G),
    π_ad=N_β^(-1)[dg/κ(β,g)+δ_1+(G/κ(β,G))δ_G],
    π_common=(dg/g+δ_G)/(1+lnG).

连续部分区间 [1,G] 中是否包含端点无关紧要；δ_1、δ_G 是另加的原子。G>1 时两个端点不同。N≥1，且 κ≥1 给 N≤2G。

设开平台 (g_i,g_{i+1}) 上实际新质量 M_i 为常整数，κ_i=M_i/m0，ℓ_i=log_γM_i，j_i=floor(log_γκ_i/h)。每个平台的整段场可压缩成一个窗和 phase，系数分别为

    ad:     c_i=q0/N · ln(g_{i+1}/g_i),
    common: c_i=q0 κ_i/(1+lnG)·(1/g_i-1/g_{i+1}).

这是因为

    q_new · (dg/κ)/N =q0 dg/(Ng),
    q_new · (dg/g)/(1+lnG)=q0 κ dg/[(1+lnG)g²].

ad 的 g=1、G 两个端点**场系数均为 q0/N**，但窗和 phase 必须分别使用 m0、m_G：

    (q0κ_G/G)·(G/κ_G)/N=q0/N.

common 只有 G 原子，场系数 q0κ_G/[G(1+lnG)]。归一 N 的连续部分仍按 (g_{i+1}-g_i)/κ_i 算，不能误用上面的场权 ln 比。

一个父因此可输出有限列表 (ℓ,j,c)，其对另一父的精确窗 Gram 是 Σ c c'1_{j=j'}T(ℓ-ℓ')。这不需要 σ 采样网格。

**闭计数与跳点**：

    m(β,r)=Π_i [floor(β_i+r/2)-ceil(β_i-r/2)+1].

盒是闭的。每坐标进入源的边长阈值是 r=2|z-β_i|；转换到 g 为 (r/R)^n。对 (1,G) 内所有阈值去重并排序，开段上取任一点计数。g=1 和 G 的原子必须分别重新按闭盒计数，尤其 G 恰好是质量跳点时不能继承左平台的质量。连续积分在有限跳点上的值无影响，但端点原子有影响。

高维应存 log m、log κ，或大整数计数；不要先把 m 作为 double 连乘再溢出。γ=2、h=1/8 时，phase 可用整数比较

    2^j ≤ (m/m0)^8 <2^(j+1)

准确确定，避免 log float 在恰好 phase 平台边界时错分。窗口差也可直接用 log_γ(M/M')，而非分别算很大的 log 后相减。一般 γ,h 需指明区间或浮点比较规则；浮点规则不是边界证书。

## 6. 有限块和小盒平滑：能恢复到哪一层

### 6.1 有限格点块

固定 n 和上述有限几何参数，取

    μ_L=Σ_{z∈Z^n∩[-L,L]^n}δ_z.

对它在整空间使用相同固定 R 网格、带和选择规则，重建其原场及 α。中心只在有限源块的 b_geom/2 邻域可能有非零贡献。离块边界有充分缓冲的来源，其全部相关父、旧 α 所需的旧源/父，以及候选盒均与无限周期模型完全相同。取保守 3b_geom 缓冲足够；不在此优化常数。

固定 n 下，边界来源比例为 O(n b_geom/L)，趋于 0。局部场有固定 n、固定参数的有限包络，因此归一能量可趋于 B_per，质量每来源仍为 1。这个极限先固定 n，再 L→∞；若要 n 同时增长，须显式追踪缓冲大小、场包络、有限块源格/中心边界与相应误差，不能只写“边界可忽略”。它也不自动验证连续母合同的所有原来源格分割与入口费用。

### 6.2 小盒 mollification

再取有限块，令

    f_{L,ε}(x)=Σ_z ε^(-n)1_{z+[-ε/2,ε/2]^n}(x).

它是非负 L1，质量等于格点数。**固定有限 R 网格非常关键**：对几乎每个 β，每个原网格盒的边界都避开有限格点；ε 充分小时其质量恰好等于原来的整数。因而最大 grid-density 的选择、固定 tie-break、qband（即使恰等号）、旧 m0 和旧 s 都最终稳定。

对候选连续 g，除有限真实进入跳点之外，质量也最终等于同一个整数；g=1、G 两个端点的边长对每个已选 grid R 都固定，故对几乎每个 β 也最终稳定。于是在这些点

    κ_ε=κ_0 exactly eventually,
    u_ε=u_0, ℓ_ε=ℓ_0, j_ε=j_0 exactly eventually.

即使一个平台恰有 κ=γ^(jh)，也会保留同一个 floor 标签；**不能以“phase 不连续所以一定失败”否定此逼近，也不能笼统用连续性跳过它**。候选进入点本身对 dg 积分零测，g=G 原子则已单独处理。κ≥1、有限半径和固定 n 给所需支配，N 及相应冻结标签场可以收敛。

若改回“每个 β 都选择恰在格点进入时的连续半径最优点”，原盒边界会在正体积中心集上含原子，平滑后的质量一般趋向部分盒质量而非闭盒整数；上述最终整数稳定论证不能直接用。故本次采用主代理冻结的固定 R 网格。

**仍需单独控制的筛选跳跃**：真正连续原场的 α_ε 通常只收敛到 α_0，而不最终完全相等。于是 low 的 α=1/A_n、以及 rapid 中 κ_G=A_nα 的阈值，仍可能翻转。固定 grid 下 α 只依赖旧整数质量窗，阈值水平集甚至可能有正体积，不能默认它们零测。需要下列之一：

1. 对实际有限输入证明相关 α 判别有严格 margin，并控制 α_ε 误差；
2. 明确估计 ambiguous 中心集及其整场/Gram贡献；
3. 仅声称具有冻结原子筛选标签的场被 L1 模型逼近，同时明确它尚不等于按连续母定义重新筛得的 bulk。

γ^h 门或 phase 平台若依赖的只是已最终稳定的整数质量，则其恰等号本身可稳定；α 依赖的门另按上一段处理。top 是固定 grid R 的几何判别，也最终稳定。源点变为小盒内 y 后，还需对 y 的盒内平均作支配收敛，不能只检查 y=z 一个点。固定 n、有限块、有限 radius/phase 上界允许做这种局部误差论证，但这里没有把它升级成一个新的完整母恢复定理。

## 7. 数值 Agent 的最小输入/输出合同

输入 manifest 至少含：n、a=√n、b_geom=2a、33 点固定 R 网格与最小 R tie-break、q∈{1,2,4}、λ_band=2q、γ、h、G、边界闭计数规则、训练/评价独立 RNG seed、中心样本数、计数/log 精度、phase 等号规则。所有原中心样本必须来自 T^n 的真实均匀 Lebesgue 分布；不得只取格点、格心、角点或有利中心。

实现顺序：

1. 每个中心先计算全部 33 个实际质量、选 grid-density 最大 R，再筛原 E。
2. 用训练中心估计整个原 E 的 L 或 (α) 的质量窗核；不先删 low/top。冻结训练结果。
3. 对评价中心按同一原选择求 α 的训练估计，再冻结 low/rapid/top/bulk 标签。若 α 未有确定误差证书，这只是估计筛选模型，不称真正母 α 的精确分类；报告离阈值的 margin 和训练量敏感性。
4. 对每个 bulk 中心枚举实际质量平台，按 §5 对两个概率分别输出完整 (ℓ,j,c) 列表。
5. 用独立两批评价中心构造交叉字段 Gram。条件于已冻结训练场，〈A_hat^(1),A_hat^(2)〉 是该冻结模型 B_per 的无自身平方对角偏差估计。每批中心体积权为 1/N；π 的归一已在 c 内，不再补另一层概率/中心归一。
6. 比较 ad/common/old 时保留同一原 E、同一冻结 α 及同一 bulk，另报告 E、low、rapid、top、bulk 的体积估计与有效样本数。任何 q 档太稀或为空均如实报告，不放大条件样本冒充 Lebesgue 权。

Monte Carlo、浮点计数和训练后的阈值标签都不是数学证书。要认证有限模型，至少需计数/phase 区间认证、α及分类误差、Lebesgue 积分误差，以及全 Gram 的区间控制；要回到 L1 还需 §6 的块边界、mollification 和筛选跳跃误差。此任务没有提供一般维数上界或原连续全集付款。

## 8. 实跑核验与停止点

只作轻量精确符号/计数检查，未跑高维扫描，未编译 PDF，未修改 repo 或他人文件。实际解释器：

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python
    Python 3.12.14; SymPy 1.14.0

SymPy 精确验证：

    (q0 κ/g)(1/κ)/N - q0/(Ng) = 0;
    (q0 κ/G)(G/κ)/N - q0/N = 0;
    ∫_[l,r] q0 κ dg/g² = q0 κ(1/l-1/r).

Fraction 对 4 个有理中心、5 个有理边长（含闭边界）共 20 项验证平移计数两侧一致。它们只是公式和实现常数核验；平移计数及完整 Gram 的一般证据是前面的证明。

已交付公式与最小数值合同。等待主代理下一项真实几何输入，不自行重复核心证明。


---

# R560 periodic lattice diagnostic: completed bounded experiment

Owner g558_numeric_sol. Files: `/tmp/ccu_r560_numeric.py`, `/tmp/ccu_r560_numeric.json`, `/tmp/ccu_r560_numeric.md`. No repo/other-role edits, PDF compilation, parallel batch or dimension-fit claim.

**Observed decision:** in the effective n=128,q=1 bulk, the current mass-adaptive law has roughly **2.1 times the complete cross-field energy of the common law**. Both are below the old bulk energy. The endpoint ablation below shows that adaptive improves the two-endpoint common benchmark by9.5–25.1%; its higher energy versus the original common law cannot be attributed to density tilt alone. The actual adaptive law still does not improve the original common law in this model. It is periodic atomic/QMC evidence, not a general L1 theorem, a root bound, or an exact optimizer result. Training-dependent bulk is measurably unstable; absolute energies must be read with that limitation. The final actual-recovery calculation below gives adaptive/common cost ratios1.440(G2) and1.265(G4), and adaptive/two-endpoint ratios.943 and.900. Thus the smaller improvement over the two-endpoint benchmark survives restoration, while the original common law remains better in this frozen model.

## Frozen model and legal field

Source μ=Σ_(z∈Z^n)δ_z, center b∈[0,1)^n, W_per=1. Dimensions initially8,32,128; a=√n,b_geom=2a. Original side R belongs to the fixed33-point grid a(1+k/32),k=0,…,32. For each center choose maximum density q0=μQ/R^n, ties smallest R. Then retain original E={q≤q0≤2q}, q∈{1,2,4}. Maximum grid density above2q is excluded rather than replaced by a different parent. The entire original E is fixed before any deletion. The fixed finite grid does not cover the continuous maximal oracle.

Frozen λ_band=2q, γ=2,h=1/8, C=1+ln4, A_n=1+nln2. λ_band is a density-band upper endpoint, not infinite periodic total source mass. Dilated side is Rg^(1/n), g∈[1,G], initially G2,4. Atom count uses the closed-cube floor/ceil formula; source-radius endpoints are preserved. All products use logcount.

An independent training sample builds the full original field L(σ)=mean(q0·1_[s,s+1](σ)), s=log2m(1), before any bulk removal. Freeze α_b=C^−1∫_[s_b,s_b+1]L. Ordered deletion is low α≤1/A_n; then rapid κ(G)≥max(2^h,A_nα); then top R≥2a/G^(1/n); bulk is the remainder. Training does not use either evaluation batch. All these definitions were independently checked by g558_proof_sol and frozen by the parent before field runs.

## Exact action integration and complete Gram

Every true entry radius is enumerated. On a constant-mass interval g∈(l,u), κ=m(g)/m(1) is constant, and its phase j=floor(log2κ/h) and window [log2m(g),log2m(g)+1] are constant. No fixed-g action grid is used.

For each center the adaptive normalization is

    N=1+Σ_(segments)(u−l)/κ + G/κ(G).

The integrated new-field coefficients, before center averaging, are:

| law | each continuous segment | atom at1 | atom atG |
|---|---|---|---|
| adaptive | q0·ln(u/l)/N | q0/N | q0/N |
| common | q0·κ(1/l−1/u)/(1+lnG) | none | q0·κ(G)/(G(1+lnG)) |

These include q_new=κq0/g, all masses, phases and endpoint atoms. The final field is a finite sum of rectangles in σ for each phase. A sorted endpoint sweep first averages all centers, then integrates its square. It includes every cross-center Gram term. A separate two-channel sweep computes cross energy ⟨A_1,A_2⟩ between two independent evaluation scrambles. Thus the reported main comparison avoids mistaking each sample's self-energy diagonal bias for geometric growth.

The implementation pressure test uses κ=1 on[1,1.5),κ=2 on[1.5,4],N=4.75, checks law normalization, and compares sweep energies and cross energy against the complete naive triangular Gram sum. All assertions passed. A two-window geometry test gives .75 including cross terms; two coincident half-weight windows give1 rather than the .5 sum of self energies.

## Resources, runs and reproducibility

Specified interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`; Python3.12.14, NumPy2.5.4, SciPy1.18.1. Machine15 logical CPU,24GiB RAM. One process at a time, BLAS/OMP/MKL threads≤2. Largest observed RSS117,129,216 bytes (~112MiB).

Reproduce the complete authorized bounded experiment:

    OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r560_numeric.py --all

Default without `--all` runs geometry only and overwrites the JSON with that subset; retain the delivered full JSON before doing so. Exact output is in the delivered JSON, including all phase energies and branch shares.

Seeds: geometry560; independent training scramble56001; independent evaluation scrambles56011,56021. Sobol samples are nested under sample doubling; training and evaluation use distinct scrambles. “Independent” refers to randomized scrambles, not a rigorous QMC confidence certificate.

| stage | input | actual runtime/result |
|---|---|---|
| geometry |8 centers/dimension, n8/32/128,G4 | .563s process, .0173s internal; direct count vs floor/ceil had no count mismatch, max log-sum discrepancy1.14e−13 |
| calibration |M=T64,n8/32/128,q1/2/4,G2/4 |1.30s internal; n8 bulk empty, n32 mostly empty or2–3 centers; q4 empty/sparse; stopped these cases |
| mass-jump pressure |one explicit κ-step model | normalization/complete-Gram assertions passed; algebraic test, not lattice data |
| expansion |only n128,q1,G2/4; (M,T)=(512,512),(1024,1024),(1024,512) |2.25s,4.49s,4.28s respectively; no new dimension/shape/parameter search |
| training stability |same1024 eval centers, compare T512 vs1024 labels | about2.2s; no energy rerun, changes recorded below |

Floating arithmetic is not interval-certified. Initial actual counts were also checked by direct integer enumeration. Each action interval uses exact analytic formulas from floating input jump locations; no quadrature approximation to the continuous action law is introduced. Phase labels now use exact big-integer comparisons 2^j≤(m/m0)^8<2^(j+1), conditional on the counted integer masses; no log-rounding phase decision is used. The geometric floor/ceil decisions for floating radii still need interval certification. No mollification theorem is asserted for the atomic experiment; original R grid endpoints are generic relative to source jumps, while subsequent action jumps and their masses remain explicitly included.

## Main complete-field results

All entries here are **cross energies between the two evaluation fields**, per unit periodic cell. “Old bulk” uses exactly the same bulk centers as each new-law comparison. “Old Q” is the full original-E field energy before branch deletion.

| M | training T | G | old Q | old bulk | common | adaptive | adaptive/common |
|---:|---:|---:|---:|---:|---:|---:|---:|
|512|512|2|.0799244|.0700746|.00641467|.0135578|2.114|
|1024|1024|2|.0822566|.0720665|.00631844|.0138131|2.186|
|1024|512|2|.0822566|.0721599|.00637336|.0138640|2.175|
|512|512|4|.0799244|.0185548|.000942144|.00197024|2.091|
|1024|1024|4|.0822566|.0140895|.000684353|.00143077|2.091|
|1024|512|4|.0822566|.0191515|.000938295|.00199216|2.123|

For M=T1024 the independent-batch self energies are:

| G | law | evaluation batch1 | batch2 | cross |
|---:|---|---:|---:|---:|
|2|common|.00658690|.00696329|.00631844|
|2|adaptive|.0142017|.0141480|.0138131|
|4|common|.000770975|.000691275|.000684353|
|4|adaptive|.00160716|.00135238|.00143077|

These differences show finite-sample effects; single-batch self-square alone was not used for the decision. No formal statistical error interval is claimed from two scrambles.

## Bulk, phase and training audit

At M=T1024,q1,n128, original E fractions are845/1024 and855/1024. Ordered branch center fractions and N ranges:

| G | batch | low | rapid | top | bulk | actual N range on bulk |
|---:|---:|---:|---:|---:|---:|---|
|2|1|.08105|.11816|0|.62598|[2.17914,3.80992]|
|2|2|.06738|.12891|0|.63867|[2.22203,3.65941]|
|4|1|.08105|.54199|0|.20215|[3.35544,5.62052]|
|4|2|.06738|.58203|0|.18555|[3.33522,5.96985]|

The JSON also contains q0-weighted center mass for every branch, plus additive old-energy shares ⟨L_branch,L_old⟩/||L_old||². At G2 the old-energy shares (low,rapid,top,bulk) are(.00880,.07949,0,.91171) and(.00595,.10184,0,.89221); at G4 they are(.00880,.62644,0,.36477) and(.00595,.68653,0,.30752). Thus the large-G energy decrease is partly changed bulk, and is not a same-center comparison across G. Within each G, common and adaptive always use identical bulk.

The decisive phase concentration is visible in complete cross energy:

| G | common phase0 | common total | adaptive phase0 | adaptive total |
|---:|---:|---:|---:|---:|
|2|.000537690|.00631844|.0112994|.0138131|
|4|.0000537176|.000684353|.00105708|.00143077|

Adaptive phase0 contributes about82% and74% of its total, versus common phase0 about9% and8%. The adaptive atom atg=1 lies in this phase; this observation is consistent with retained original-phase load, but the table does not separately isolate that atom from the pre-first-jump continuous interval. No demonstrated suppression of the high-load layer follows.

Threshold diagnostics: “near low” means |A_nα−1|<.05, at most1/1024 of centers; “near rapid” means |ln(κ(G)/K)|<.05, around3.8–5.7% of centers forG2 and8.2–9.7% forG4. Doubling independent training512→1024 on the same1024 evaluation centers changes7.2–7.5% of labels forG2,7.7–7.9% forG4. These include two-way bulk/rapid changes, not just the net bulk fraction. Absolute G4 energies move roughly25–30% with training; the adaptive/common factor remains2.09–2.12. This is evidence of a robust direction of comparison in this finite model, not a certified asymptotic rate.

## Stop point

All three requested stages were completed within the initial resource scale. Empty/sparse cases were not enlarged. The effective n128 comparison already distinguishes the two current laws, and adaptive did not improve common. More sampling would not establish the missing general theorem. No larger G, dimension scan, fitted growth exponent, continuous-radius optimality claim, or general root conclusion was attempted. A final integer-phase audit checked35,928 plateau/endpoint labels over the expanded bulk and the frozen small instance, with zero changes from the recorded energies; it took6.60s and ran no additional field-energy batch. The delivered implementation uses these exact integer phase comparisons directly.

Independent-certificate input is frozen in JSON `certificate_instance`: n32,M=T64,q1,G2; all training and evaluation centers as exact30-bit dyadic numerators, the complete33-point grid specification, chosen parent indices, floating diagnostics and bulk3+2 parents. The full source is the factorized integer lattice, not a truncated list of favorable atoms. g558_certificate_sol is independently auditing this small instance; its certificate is separate from the larger QMC evidence.

## Authorized same-input endpoint/density ablation — final addition

This is one added decision test, not a new scan: n128,q1,M=T1024,G2/4, identical seeds, original E, independently trained α and frozen bulk as above. The prior `certificate_instance` is unchanged. A single process completed both G cases in4.95s. It did not refit or enlarge samples. The two-endpoint comparison is

    π_two=(dg/g+δ1+δG)/(2+lnG).

Its segment field coefficient is q0κ(1/l−1/u)/(2+lnG), initial atom q0/(2+lnG), end atom q0κG/[G(2+lnG)]. The same exact action-platform and complete endpoint-sweep Gram engines were used.

| G | common complete cross energy | two-endpoint common | adaptive | ad/two | two/common |
|---:|---:|---:|---:|---:|---:|
|2|.00631843623|.01525617648|.01381313241|.90541247|2.41454941|
|4|.000684352997|.001910622582|.001430767250|.74884871|2.79186705|

**Corrected interpretation:** the original approximately2.1 ratio is not evidence against the density tilt alone. Once both endpoint atoms are present, the adaptive density/normalization change lowers energy by about9.5% forG2 and25.1% forG4 relative to π_two. Adding the initial endpoint to the common law, with its prescribed renormalization, raises energy by factors2.41 and2.79. The actual adaptive law still has higher energy than the actual original common law in this frozen diagnostic. These are comparisons of complete laws; this ablation does not separate the effect of adaptive continuous density from its changed normalization and end-atom weights.

For localization decompose the actual adaptive field as Y_init+Y_cont+Y_end. The following matrices are the **symmetric independent-batch cross Grams**

    H_ij=1/2[〈Y_i^(1),Y_j^(2)〉+〈Y_j^(1),Y_i^(2)〉],

in order(init,cont,end). They include all center pairs and phases. Every matrix entry contributes once in Σ_ijH_ij; off-diagonal pairs therefore contribute twice to the total.

ForG2, entries are in units10^−3:

| | init | cont | end |
|---|---:|---:|---:|
|init|8.538421214|1.272873609|.005941726|
|cont|1.272873609|.578134578|.438434390|
|end|.005941726|.438434390|1.262077168|

Matrix sum=.013813132410002964, versus directly swept adaptive cross energy .013813132410002999; floating discrepancy3.5e−17.

ForG4, entries are in units10^−3:

| | init | cont | end |
|---|---:|---:|---:|
|init|.801408862|.118014642|0|
|cont|.118014642|.119954103|.054030580|
|end|0|.054030580|.165313841|

Matrix sum=.001430767250365435, versus directly swept .001430767250365436. The additive Gram attribution to the initial atom is its matrix row sum:71.1% and64.3% of total adaptive energy. The pure initial-atom diagonal alone is .00853842 and .000801409. Thus the initial atom, including its cross terms with the other pieces, accounts for most of the observed initial-phase load. Merely deleting Y_init without renormalizing would be a subprobability field, so it is not treated as another legal selector comparison.

**True flat parents:** tested by exact integer equality m(G)=m(1), not an approximate κ threshold. G2 bulk counts are641 and654; G4 counts207 and190. Both batches at both G have **zero** true-flat parents. Accordingly flat center fraction, q0-weighted mass fraction, oldscore fraction (defined explicitly as Σ_flat q0α / Σ_bulk q0α), and old/new energy attributions are all0. No near-flat threshold was introduced and no search for flat centers was run. This absence is specific to the frozen sample and does not refute a flat-sector obstruction in other inputs.

Reproduce only the appended ablation, preserving the existing JSON and frozen certificate input:

    OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r560_numeric.py --ablation-only

The JSON `endpoint_density_ablation` contains full precision, all three per-phase energy tables, both batch flat statistics, the3×3 matrices and energy fractions. The original main results and certificate_instance remain intact. The same floating/QMC and trained-threshold limitations apply; no further certification or larger scan was requested or attempted. Work stops after this addition.

## Final actual-recovery calculation: per-parent C_eta

The parent authorized this final decision calculation on exactly the same n128,q1,M=T1024, seeds, independent training and original frozen bulk, G2/4. No extra dimensions, G values, q bands, centers or selector parameters were introduced. The actual bridge is `/tmp/ccu_r560_weighted_bridge.tex`.

Each parent's **entire** law field is divided by its own efficiency before aggregation and complete Gram integration:

    common: eta=p=1/(1+lnG),
    two:    eta=2/(2+lnG),
    ad:     I=1+Σ_segments ln(u/l)/κ +1/κ(G), eta=I/N,
    C_eta=Σ_j || mean_B [F_(B,j)/eta_B] ||².

The independent-batch cross version uses every real window/phase/endpoint exactly as before. In particular the adaptive coefficients after division are q0ln(u/l)/I for each continuous segment and q0/I for each endpoint; N cancels. The computation does **not** divide an overall raw energy by average eta. Its constant-eta common/two identities C_eta=rawE/eta² were checked to1e−12. Every adaptive eta was checked against (2+lnG)/(2G)≤eta≤1.

One single-process main run took4.56s, within the existing resource scale. The script function `recovery_same_bulk()` is included in `--all`; `--recovery-only` appends just this calculation while preserving all earlier data and `certificate_instance`.

| G | common C_eta cross | two C_eta cross | adaptive C_eta cross | ad/common | ad/two | two/common |
|---:|---:|---:|---:|---:|---:|---:|
|2|.01811336048|.02766342119|.02608552381|1.440126|.942961|1.527238|
|4|.003896980241|.005477272273|.004929097477|1.264851|.899918|1.405517|

**Decision:** the raw adaptive improvement relative to the two-endpoint benchmark survives actual per-parent recovery, but shrinks from9.5% to5.7% forG2 and from25.1% to10.0% forG4. The actual adaptive law is still worse than the actual original common law in this frozen experiment: restored cost is44.0% higher forG2 and26.5% higher forG4. This comparison uses the full restored field, including its positive cross terms. It does not establish a general L1 ordering.

Independent evaluation self-energies (not used as the main estimator) are:

| G | law | batch1 self C_eta | batch2 self C_eta | cross C_eta |
|---:|---|---:|---:|---:|
|2|common|.01888296419|.01996198389|.01811336048|
|2|two|.02847721478|.02821939780|.02766342119|
|2|adaptive|.02684269312|.02670860187|.02608552381|
|4|common|.004390241811|.003936396219|.003896980241|
|4|two|.006235872375|.005065202317|.005477272273|
|4|adaptive|.005564942391|.004649317287|.004929097477|

Actual adaptive efficiencies vary by parent; the other two laws have constants common=.5906161,two=.7426256 forG2 and common=.4190598,two=.5906161 forG4. Adaptive empirical distribution:

| G | eval batch | min eta | 10% | median | 90% | max eta | mean eta | q0alpha-weighted mean |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|2|1|.681265|.703957|.724614|.750503|.789153|.725700|.726637|
|2|2|.685570|.705483|.725704|.747227|.781396|.726261|.727039|
|4|1|.473112|.499894|.532309|.565000|.584043|.530854|.532658|
|4|2|.468525|.506349|.532450|.558866|.587198|.532832|.534603|

The sample Pearson correlations are:

| G | batch | corr(eta,N) | corr(eta,I) | corr(eta,kappaG) | corr(eta,alpha) |
|---:|---:|---:|---:|---:|---:|
|2|1|−.9838|−.9761|.9919|.2191|
|2|2|−.9815|−.9714|.9922|.2386|
|4|1|−.9631|−.9078|.9873|.4897|
|4|2|−.9548|−.8937|.9861|.5813|

The joint eta-quartile distributions are retained in JSON, including means of kappaG,alpha,N,I in each bin. For example G4 batch1 progresses from lowest-eta quartile mean(eta,kappaG,alpha,N,I)=(.4991,1.9978,.03293,5.0272,2.5065) to highest(.5633,3.2707,.03927,3.7568,2.1149). These correlations are descriptive; they were not assumed independent or used to replace the complete parent-pair Gram. The previous training-label and finite-scramble limitations remain in force.

To reproduce just this final addition:

    OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r560_numeric.py --recovery-only

JSON `per_parent_recovery` contains all full-precision costs, raw controls, restored phase energies, both self energies and eta joint summaries. `certificate_instance` and all earlier results were retained. No additional certification, scan or general-dimensional extrapolation is made. This completes the final calculation and work stops.


---

# R560：冻结 n=32 有限实例的独立算术证书

## 1. 认证范围和结论

本角色只拥有 `/tmp/ccu_r560_certificate.py`、`.json`、`.md`；没有修改 numeric 作者脚本或 repo，没有编译 PDF。输入是 numeric 角色在 `/tmp/ccu_r560_numeric.json` 中冻结的 `certificate_instance`：n=32，q=1，G=2，M=T=64，训练 seed=56001，评价 seeds=56011、56021，全部中心是给定整数除以 2^30。R 网格是 `√32(1+k/32)`，k=0,…,32，最大 density 同值时取最小 k。

**可靠的有限比较结果：** 同一批训练标签及同一 3+2 个 bulk 父，完整交叉 Gram 的 adaptive/common 比值严格包围于

`[1.0134332026086000054176488175241644192069196527704627524 +/- 6.08e−56]`。

adaptive 能量高约 1.3433%；两者差严格为正：

`[1.03791875275998047422607123375508327134151783498494215e−5 +/- 2.40e−59]`。

因此这个**固定有限输入**没有显示 adaptive 优于 common。它也没有复现“约两倍”：那是不同 n=128、大样本输入的诊断，不能拿本小实例替代核验其统计结论。本证书没有发现冻结 n=32 实例的质量平台、端点或 phase 实现错误。

没有认证 Lebesgue 中心积分误差，没有认证真实母 α 的训练误差，没有认证周期模型到一般 L1 的恢复误差，也没有一般 root 定理。下面所有“精确分类”仅指冻结 64 点训练场所定义的有限 α。

## 2. 独立几何实现

证书核心没有导入作者的计数、mass platform、selector 系数或 Gram 组装函数；最后才导入作者脚本计算浮点对照。

对每个中心坐标 x=B/D，D=2^30，候选格点 z 是否在闭盒内，用整数不等式

`[2(zD−B)·32]^2 ≤ n(32+k)^2D²`

准确判定。浮点数仅初始化整数区间两端的搜索起点，随后用上述不等式修正到准确的首末格点，另核首末外侧确实不在盒内；任何 sqrt 误差都不能决定最终闭计数。每个坐标格点数连乘为 Python 大整数。源始终是完整 Z^32 的笛卡尔积计数，没有截断源或只取少数原子。

`R^n=n^(n/2)((32+k)/32)^n` 是精确有理数，所以全部 33 个 grid density、最大值选择、qband `1≤q0≤2` 都由 Fraction 比较。训练 64 中心中 49 个进入原 E；两评价批分别 53、50 个进入 E，与作者冻结记录逐项一致。所有被选 k 都逐项核对，无 qband 或 tie-break 不确定项。原 float q0 与准确有理值的最大显示差为 `3.8191672047105385e−14`，符合其对数浮点求值的有限舍入误差。

给定原 R，所有坐标入盒阈值 `r=2|z−x|` 转成

`g=(2|z−x|)^n/R^n`，

仍是精确有理数。枚举边界也有准确守卫：对每坐标 x，浮点 rmax 只初始化整数 L、U；随后必要时向外延伸，直到同时准确满足 `L<x<U`、`gentry(L)>G`、`gentry(U)>G`，其中 `gentry(z)=(2|z−x|)^n/R^n`。然后枚举 `L<z<U`。因为距离在 x 的两侧向外单调，所有遗漏的外侧整数都严格有 gentry>G；这才是无遗漏证明，浮点安全垫本身不作证明。脚本准确筛 `1<g≤G`，排序并合并同一 g 的全部坐标进入事件。在相邻阈值之间质量是整数乘积；在 g=G 若恰有事件先加入，再取闭端点质量。原 g=1 质量也另作准确闭计数。因此没有依靠浮点中点采样或左平台外推来处理端点。

## 3. α、分支和 phase

旧质量窗的 σ 端点为 log2 m、log2(2m)。两个窗的重叠长度准确表示为

`log2[min(2m,2m')/max(m,m')]`

（仅在分子大于分母时非零）。训练权 q0/T 是有理数，所有 log 由 Arb 192 bits 包围。有限训练 α 除数是合同中的 `C=1+ln4`；它不同于 common 概率的归一 `1+lnG`。

按合同顺序 low、rapid、top、bulk，全部判别均用有理数或分离的 Arb 区间。不以浮点 floor 或容差强制定标签。本冻结输入没有 uncertain 判别，所有标签与作者逐项一致：

| 评价 seed | low | rapid | top | bulk |
|---|---:|---:|---:|---:|
| 56011 | 40 | 10 | 0 | 3 |
| 56021 | 37 | 11 | 0 | 2 |

两个批的 bulk 原中心索引（0-based）分别是 35、48、54 和 20、49；原 Rgrid 索引分别是 0、0、4 和 0、0。它们共有 10 个实际开质量平台（2+2+1+2+3）。

对每个平台和 G 端点，κ=m/m0 是有理数；phase j 由

`2^j ≤ κ^8 <2^(j+1)`

的 Fraction 比较准确确定，不调用对数 floor。G 端点 phase 分别为 2、2、0、2、4。旧作者浮点路径已由作者改成整数比较路径，本证书独立得到同样 phase。common 的 8+7 个矩形、adaptive 的 11+9 个矩形，phase 顺序与作者全部一致。

## 4. 两个端点、概率归一及完整 Gram

对平台 `(l,u)`、质量 m_i、κ_i=m_i/m0，精确有理归一为

`N=1+Σ (u−l)/κ_i+G/κ_G`。

脚本用 Fraction 对每个 bulk 父准确核对 adaptive 概率总质量等于 1。平台场系数用 Arb 计算：

- adaptive：`q0/(MN) ln(u/l)`；
- common：`q0 κ_i/[M(1+lnG)] (1/l−1/u)`。

adaptive 的 g=1、G 两个独立端点均有场系数 `q0/(MN)`，但前者使用 m0 的窗和 phase=0，后者使用 m_G 的窗和准确 phase_G；common 只有 G 端点 `q0 κ_G/[MG(1+lnG)]`。没有把 g=1 原子漏掉或把 g=G 的窗继承自左平台。

完整 Gram 没有对 σ 数值采样。每个窗口 `[log2 m,log2(2m)]` 对应整数排序端点 m、2m；对每个 phase 按这些整数端点扫场，再在相邻端点精确长度 `log2(m_next/m_prev)` 上积场平方。全部父间、动作间交叉都保留。双评价批交叉能量通过两个完整自能量和相加场能量的极化公式计算；区间运算保持包围性。

| 有限能量 | Arb 包围中心值 | 作者 float |
|---|---:|---:|
| seed56011 common 自能量 | .00143506374587619991032885073848001297449 | .0014350637458761888 |
| seed56011 adaptive 自能量 | .00131698925396777146596618628447025979467 | .0013169892539677565 |
| seed56021 common 自能量 | .000681930996951778093935318996422841906418 | .0006819309969517787 |
| seed56021 adaptive 自能量 | .000761958975324220942441880954879928166675 | .0007619589753242147 |
| common 双批交叉 | .000772651751783673350610022967532143870362 | .0007726517517836712 |
| adaptive 双批交叉 | .000783030939311273155352283679869694703076 | .0007830309393112665 |

各完整 Arb 能量半径不超过 `2.03e−59`，完整带半径输出见 JSON。作者 float 的最大此表绝对差约 `1.5e−17`，远小于 adaptive−common 的有限差 `1.04e−5`，所以这个比较符号不能归因于浮点舍入。两批各自的 adaptive/common 自能量比一小于 1、一大于 1，分别为 `.9177217791` 和 `1.1173549505`；这也说明不能把有限中心自平方直接当一般改善结论。

## 5. 实跑记录和边界

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r560_certificate.py > /tmp/ccu_r560_certificate.json
```

最终运行约 1.15 秒、单进程。Python 3.12.14，python-flint 0.9.0，Arb 192 bits；NumPy、SciPy 版本亦记录在 JSON。脚本标准输出只含 JSON，所有有理 N、bulk 平台 g 端点、质量和 phase 均保存在结果中。冻结输入到达前另作 n128、M=T32、G4 的 3.18 秒轻量独立试跑；未扩参，其输出随后被本冻结输入覆盖，不作为本证书结论。

认证到此停止：这些是固定 dyadic 中心、固定训练场、有限 Rgrid 和完整连续 g 平台的严格**有限算术**结果。Sobol 64 点对真实中心积分的误差、训练场对真实母 α 的误差及其阈值翻转，都没有本证书的上界。周期源、块边界和小盒 mollification 另有公式合同要求，不能从这些小数升级为一般连续证明。


## 6. 父审修复与原实例重现

父审指出旧版本的 `segments` 虽在浮点 rmax 外加了宽裕整数垫，却没有准确证明外侧整数全在范围之外。本版本加入上节的 Fraction 外端守卫及必要时延伸；没有改变冻结输入、参数、分类、源模型或 selector。

同一实例重跑：所有 103 个 E 父共 3296 个坐标均通过双侧准确守卫，实际需要延伸的次数为 0；全部被核外端 `gentry/G` 的最小值约为 `17239.681698703782`，准确有理值保存在 JSON。因此本次修复补足了覆盖证明，未发现漏跳点，所有原能量区间和比较结果保持逐字相同。重跑耗时约 1.1445 秒、单进程。

修复后脚本 SHA256：

`65e554a309b77d939689ab64fec7aaf8cdfedabda400f10755a780baded4b502`

冻结 `certificate_instance` 规范 JSON（sort_keys=True、separators=(',',':')）的 SHA256：

`0a76426296d886510e8dfa4e939ed790115f8129db061e28127d39871a77027e`

其余 numeric JSON 新增消融字段不参与此哈希或此证书。最终差的 Arb 半径仍为 `2.40e−59`、比值半径仍为 `6.08e−56`；没有新增统计或连续误差主张。完成本修复后停止。
