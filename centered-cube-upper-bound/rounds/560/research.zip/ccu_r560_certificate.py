"""Independent exact-geometry/Arb finite Sobol-instance certificate, R560.
No author assembly code used for the exact computation; imported only for comparison. No quadrature error certification.
"""
from pathlib import Path
import sys,json,platform,math,time,hashlib
from fractions import Fraction as F
from collections import defaultdict
import numpy as np, scipy, flint
from scipy.stats import qmc
from flint import arb,ctx
ctx.prec=192
n=32;M=64;T=64;G=2;q=F(1)
coverage_guards=[]

def A(x):
    if isinstance(x,F): return arb(x.numerator)/x.denominator
    return arb(x)
def lnratio(x):return A(x).log()
def log2ratio(x):return lnratio(x)/arb(2).log()
def dyadic(row):return [F(float(x)) for x in row]
def counts(b,k):
    # R²=n(1+k/32)². Floats only initialize endpoints; integer comparisons fix them.
    R=math.sqrt(n)*(1+k/32);out=[]
    for x in b:
        B,D=x.numerator,x.denominator
        rhs=n*(32+k)**2*D*D
        def inside(z):return (2*(z*D-B)*32)**2<=rhs
        lo=math.floor(float(x)-R/2)-2;hi=math.ceil(float(x)+R/2)+2
        while not inside(lo):lo+=1
        while not inside(hi):hi-=1
        assert not inside(lo-1) and not inside(hi+1)
        out.append(hi-lo+1)
    return out

def record(row):
    b=dyadic(row);Ms=[math.prod(counts(b,k)) for k in range(33)]
    Rns=[F(n**(n//2))*F(32+k,32)**n for k in range(33)]
    qs=[F(m)/v for m,v in zip(Ms,Rns)]
    k=max(range(33),key=lambda k:qs[k])
    if not q<=qs[k]<=2*q:return None
    return dict(b=b,k=k,m=Ms[k],q0=qs[k],Rn=Rns[k])

def segments(rec):
    b,k=rec['b'],rec['k'];Rn=rec['Rn'];c=counts(b,k);events=defaultdict(lambda:defaultdict(int))
    rmax=math.sqrt(n)*(1+k/32)*G**(1/n)
    for d,x in enumerate(b):
        # Floats initialize only: exact exterior guards certify exhaustive search.
        def entry(z):return (2*abs(F(z)-x))**n/Rn
        left=math.floor(float(x)-rmax/2)-2
        right=math.ceil(float(x)+rmax/2)+2
        extensions=0
        while not (F(left)<x and entry(left)>G):left-=1;extensions+=1
        while not (F(right)>x and entry(right)>G):right+=1;extensions+=1
        gl,gr=entry(left),entry(right)
        assert F(left)<x<F(right) and gl>G and gr>G
        coverage_guards.append((gl/F(G),gr/F(G),extensions))
        # Any z outside (left,right) is farther from x on its respective side.
        for z in range(left+1,right):
            g=entry(z)
            if 1<g<=G:events[g][d]+=1
    last=F(1);out=[]
    for g,changes in sorted(events.items()):
        if g>last:out.append((last,g,math.prod(c)))
        for d,delta in changes.items():c[d]+=delta
        last=g
    if last<G:out.append((last,F(G),math.prod(c)))
    return out,math.prod(c)

def phase(kappa):
    v=kappa**8;j=v.numerator.bit_length()-v.denominator.bit_length()
    def p2(k):return F(2**k) if k>=0 else F(1,2**(-k))
    while v<p2(j):j-=1
    while v>=p2(j+1):j+=1
    assert p2(j)<=v<p2(j+1)
    return j

def classify(r,train):
    m=r['m'];alpha=arb(0)
    for t in train:
        lo=max(m,t['m']);hi=min(2*m,2*t['m'])
        if hi>lo:alpha+=A(t['q0']/T)*log2ratio(F(hi,lo))
    alpha/=1+arb(4).log();An=1+n*arb(2).log()
    seg,mG=segments(r);kap=F(mG,m)
    if alpha*An<1:label='low'
    elif alpha*An>1:
        if kap**8>=2 and A(kap)>=An*alpha:label='rapid'
        elif (kap**8<2 or A(kap)<An*alpha):
            label='top' if F(32+r['k'],64)**n*G>=1 else 'bulk'
        else:label='uncertain'
    else:label='uncertain'
    return label,seg,mG,str(alpha)

def fields(r,seg,mG,law):
    m=r['m'];q0=r['q0'];kapG=F(mG,m)
    N=F(1)+sum((u-l)*F(m,mm) for l,u,mm in seg)+F(G)/kapG
    assert N>0
    rect=[];C=1+arb(G).log()
    for l,u,mm in seg:
        kap=F(mm,m)
        coeff=A(q0/F(M)/N)*lnratio(u/l) if law=='adaptive' else A(q0/F(M)*kap*(1/l-1/u))/C
        rect.append((phase(kap),mm,2*mm,coeff))
    if law=='adaptive':rect.append((0,m,2*m,A(q0/F(M)/N)))
    coeff=A(q0/F(M)/N) if law=='adaptive' else A(q0/F(M)*kapG/F(G))/C
    rect.append((phase(kapG),mG,2*mG,coeff))
    return rect,N

def energy(rect):
    events=defaultdict(lambda:defaultdict(list))
    for j,l,u,c in rect:events[j][l].append(c);events[j][u].append(-c)
    total=arb(0)
    for j,ev in events.items():
        cur=arb(0);last=min(ev)
        for x,changes in sorted(ev.items()):
            if x>last:total+=cur*cur*log2ratio(F(x,last))
            for change in changes:cur+=change
            last=x
        assert cur.contains(0)
    return total

def main():
    start=time.perf_counter()
    frozen=json.load(open(str(Path(__file__).with_name('ccu_r560_numeric.json'))))['certificate_instance']
    assert (frozen['n'],frozen['M'],frozen['T'],frozen['G'])==(n,M,T,G)
    D=frozen['dyadic_denominator']
    trpts=[[F(x,D) for x in row] for row in frozen['training_b_numerators']]
    train=[r for row in trpts if (r:=record(row)) is not None]
    batches=[];allrect=[]
    for batch in frozen['evaluation']:
        records=[];rects={'common':[],'adaptive':[]};labels=defaultdict(int)
        original={tuple(e['b_numerators']):e for e in batch['E_parents']}
        pts=[[F(x,D) for x in row] for row in batch['all_b_numerators']]
        for index,row in enumerate(pts):
            r=record(row)
            if r is None:continue
            raw=tuple(int(x*D) for x in row);orig=original[raw]
            assert r['k']==orig['R_grid_index']
            label,seg,mG,alpha=classify(r,train);labels[label]+=1
            assert label==orig['branch'],(index,label,orig['branch'])
            data=dict(index=index,Rgrid_index=r['k'],mass=str(r['m']),q0=str(r['q0']),q0_float_difference=float(r['q0'])-orig['q0_float'],label=label,alpha_arb=alpha,segments=len(seg),massG=str(mG),phaseG=phase(F(mG,r['m'])))
            if label=='bulk':
                for law in rects:
                    rs,N=fields(r,seg,mG,law);rects[law].extend(rs)
                data['N']=str(N)
                data['segment_exact']=[dict(glo=str(l),ghi=str(u),mass=str(mm),phase=phase(F(mm,r['m']))) for l,u,mm in seg]
                assert (1+sum((u-l)*F(r['m'],mm) for l,u,mm in seg)+F(G*r['m'],mG))/N==1
            records.append(data)
        assert len(records)==len(original)
        es={law:energy(rs) if rs else arb(0) for law,rs in rects.items()}
        batches.append(dict(seed=batch['seed'],records=records,labels=dict(labels),energies={law:str(e) for law,e in es.items()},adaptive_over_common=str(es['adaptive']/es['common']) if es['common']>0 else None))
        allrect.append(rects)
    cross={}
    for law in ['common','adaptive']:
        e=(energy(allrect[0][law]+allrect[1][law])-energy(allrect[0][law])-energy(allrect[1][law]))/2
        cross[law]=str(e)
    # Author implementation is imported ONLY for an external floating comparison.
    sys.path.insert(0,str(Path(__file__).resolve().parent))
    import ccu_r560_numeric as author
    trfloat=np.array([[float(x) for x in row] for row in trpts])
    L=author.old_rects(author.parent_records(trfloat,math.sqrt(n)*(1+np.arange(33)/32),1),T)
    floatpacks=[]
    for batch in frozen['evaluation']:
        pf=np.array(batch['all_b_numerators'])/D
        floatpacks.append(author.batch_fields(pf,L,1,G,math.sqrt(n)))
    exact_cross={law:(energy(allrect[0][law]+allrect[1][law])-energy(allrect[0][law])-energy(allrect[1][law]))/2 for law in ['common','adaptive']}
    assert exact_cross['adaptive']>exact_cross['common']
    comparison=dict(adaptive_minus_common_arb=str(exact_cross['adaptive']-exact_cross['common']),adaptive_over_common_arb=str(exact_cross['adaptive']/exact_cross['common']))
    phase_matches=[]
    for batch_i,pack in enumerate(floatpacks):
        for law in ['common','adaptive']:
            independent=allrect[batch_i][law]; authored=pack[0][law]
            assert len(independent)==len(authored)
            assert [v[0] for v in independent]==[v[0] for v in authored]
            phase_matches.append(dict(batch=batch_i,law=law,rectangles=len(independent),all_phases_match=True))
    floatcompare=dict(batches=[{law:pack[1][law]['self_energy'] for law in ['common','adaptive']} for pack in floatpacks],cross={law:author.cross_rectangles(floatpacks[0][0][law],floatpacks[1][0][law])[0] for law in ['common','adaptive']})
    out=dict(script_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),frozen_input_sha256=hashlib.sha256(json.dumps(frozen,sort_keys=True,separators=(',',':')).encode()).hexdigest(),coverage_guards=dict(coordinates_checked=len(coverage_guards),all_exact_outside=True,extensions=sum(v[2] for v in coverage_guards),minimum_exterior_g_over_G=str(min(min(v[0],v[1]) for v in coverage_guards))),python=sys.executable,python_version=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,flint=flint.__version__,arb_precision_bits=ctx.prec,parameters=dict(n=n,M=M,T=T,G=G,q=str(q),training_seed=56001,evaluation_seeds=[56011,56021]),training_parent_count=len(train),batches=batches,cross_energy_arb=cross,strict_finite_comparison=comparison,author_phase_comparison=phase_matches,author_float_comparison=floatcompare,elapsed_seconds=time.perf_counter()-start,scope='Exact dyadic/rational geometry and Arb finite sample energy; no QMC integration error bound.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
