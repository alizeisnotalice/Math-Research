"""R560 periodic lattice diagnostic, geometry engine only until formulas frozen.
One process. No general L1 or rigorous statistical certificate.
"""
import os
from pathlib import Path
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['OMP_NUM_THREADS']='2'
os.environ['MKL_NUM_THREADS']='2'
import math,json,time,platform
import numpy as np
from scipy.stats import qmc


def logcount(b,R):
    """Closed-cube atomic count; endpoint inclusion is intentional."""
    c=np.floor(b+R/2).astype(np.int64)-np.ceil(b-R/2).astype(np.int64)+1
    return -math.inf if np.any(c<=0) else float(np.log(c).sum())


def logcount_direct(b,R):
    vals=[]
    for x in b:
        vals.append(sum(abs(z-x)<=R/2 for z in range(math.floor(x-R/2)-1,math.ceil(x+R/2)+2)))
    return -math.inf if not all(vals) else sum(math.log(x) for x in vals)


def radius_jumps(b,rmin,rmax):
    vals=[]
    for x in b:
        for z in range(math.ceil(x-rmax/2),math.floor(x+rmax/2)+1):
            r=2*abs(z-x)
            if rmin<=r<=rmax:vals.append(r)
    return np.unique(np.array(vals))


def mass_segments(b,R,G):
    """g is VOLUME dilation; each open segment has constant lattice mass.
    Returns exact floating breakpoints from source entry radii, plus endpoint
    masses (closed cube) kept separately for atoms at 1 and G.
    """
    n=len(b);rmax=R*G**(1/n)
    rs=radius_jumps(b,R,rmax)
    gs=np.exp(n*np.log(rs/R)) if len(rs) else np.array([])
    pts=np.unique(np.r_[1.,gs[(gs>1)&(gs<G)],float(G)])
    seg=[]
    for l,u in zip(pts[:-1],pts[1:]):
        mid=math.sqrt(l*u)
        seg.append((float(l),float(u),logcount(b,R*mid**(1/n))))
    return seg,logcount(b,R),logcount(b,rmax)


def energy_rectangles(rectangles):
    """Complete Gram: average field first, then exact integral of its square.
    rectangles=(phase,left,right,coefficient) already include MC averaging.
    Endpoint sweep O(M log M), no pairwise sample squares.
    """
    events={}
    for j,l,r,c in rectangles:
        ev=events.setdefault(int(j),[]);ev.append((l,c));ev.append((r,-c))
    out={}
    for j,ev in events.items():
        ev.sort();cur=0.;last=ev[0][0];energy=0.
        for x,change in ev:
            energy+=cur*cur*(x-last)
            cur+=change;last=x
        out[j]=energy
    return sum(out.values()),out


def integrals_piece(l,u,logk):
    """Continuous π_ad mass, ad field /q0, common field/q0 before norms."""
    invk=math.exp(-logk)
    return (u-l)*invk,math.log(u/l),math.exp(logk)*(1/l-1/u)


def geometry_calibration():
    st=time.perf_counter();records=[];maxerr=0.
    for n in [8,32,128]:
        b=qmc.Sobol(n,scramble=True,seed=560).random_base2(3)
        a=math.sqrt(n)
        for row in b:
            for R in [a,1.25*a,2*a]:
                maxerr=max(maxerr,abs(logcount(row,R)-logcount_direct(row,R)))
        seg,l0,lG=mass_segments(b[0],a,4)
        records.append(dict(n=n,a=a,G=4,segments=len(seg),logm1=l0,logmG=lG,breakpoints=[x[:2] for x in seg]))
    rect=[(0,0,1,.5),(0,.5,1.5,.5)]
    E,_=energy_rectangles(rect)
    assert abs(E-.75)<1e-14
    # Two identical centers: square of mean equals one, mean self energy=.5.
    assert abs(energy_rectangles([(0,0,1,.5),(0,0,1,.5)])[0]-1)<1e-14
    return dict(stage='geometry-only',python=platform.python_version(),numpy=np.__version__,seed=560,centers_per_dimension=8,max_direct_count_logerror=maxerr,records=records,full_gram_triangle_test=E,elapsed_seconds=time.perf_counter()-st,limitations='No field run: legal parent, alpha, bulk and normalization pending formula contract.')



def cross_rectangles(rect1,rect2):
    events={}
    for channel,rect in enumerate([rect1,rect2]):
        for j,l,r,c in rect:
            ev=events.setdefault(int(j),[]);ev.append((l,channel,c));ev.append((r,channel,-c))
    out={}
    for j,ev in events.items():
        ev.sort();v=[0.,0.];last=ev[0][0];E=0.
        for x,ch,c in ev:
            E+=v[0]*v[1]*(x-last);v[ch]+=c;last=x
        out[j]=E
    return sum(out.values()),out


def window_integrals(rect,windows):
    # Input is old L, so all phases are zero. Exact integral via prefix scan.
    events=[]
    for _,l,r,c in rect:events.extend([(l,c),(r,-c)])
    events.sort();xs=[];areas=[];vals=[];value=0.;area=0.;last=events[0][0] if events else 0.
    for x,delta in events:
        area+=value*(x-last);value+=delta;last=x
        xs.append(x);areas.append(area);vals.append(value)
    xs=np.asarray(xs);areas=np.asarray(areas);vals=np.asarray(vals)
    def primitive(z):
        if not len(xs):return 0.
        k=int(np.searchsorted(xs,z,side='right'))-1
        return 0. if k<0 else float(areas[k]+vals[k]*(z-xs[k]))
    return np.array([primitive(r)-primitive(l) for l,r in windows])


def parent_records(points,grid,q):
    out=[]
    for b in points:
        logs=np.array([logcount(b,float(R)) for R in grid])
        densities=logs-len(b)*np.log(grid)
        k=int(np.argmax(densities));q0=math.exp(densities[k])
        if q<=q0<=2*q:out.append(dict(b=b,R=float(grid[k]),logm=float(logs[k]),q0=q0))
    return out


def old_rects(records,M):
    return [(0,r['logm']/math.log(2),r['logm']/math.log(2)+1,r['q0']/M) for r in records]



def integer_mass(b,R):
    counts=np.floor(b+R/2).astype(np.int64)-np.ceil(b-R/2).astype(np.int64)+1
    return math.prod(int(x) for x in counts)


def exact_phase(m,m0):
    # gamma=2,h=1/8: 2^j <= (m/m0)^8 < 2^(j+1).
    A=m**8;B=m0**8
    j=A.bit_length()-B.bit_length()
    if A < (B << j):j-=1
    return j

def transformed_rects(record,segments,logmG,G,M,law,h=.125):
    logm=record['logm'];q0=record['q0'];s=logm/math.log(2)
    m0=integer_mass(record['b'],record['R'])
    logkG=logmG-logm
    N=1+sum((u-l)*math.exp(logm-lm) for l,u,lm in segments)+G*math.exp(-logkG)
    C=1+math.log(G)
    rect=[]
    for l,u,lm in segments:
        logk=lm-logm
        mm=integer_mass(record['b'],record['R']*math.sqrt(l*u)**(1/len(record['b'])))
        phase=int(round(logk/math.log(2)/h)) if record.get('synthetic') else exact_phase(mm,m0)
        start=lm/math.log(2)
        coef=q0*(math.log(u/l)/N if law=='adaptive' else math.exp(logk)*(1/l-1/u)/C)/M
        rect.append((phase,start,start+1,coef))
    if law=='adaptive':
        rect.append((0,s,s+1,q0/N/M))
        coef=q0/N/M
    else:coef=q0*math.exp(logkG)/G/C/M
    phase=int(round(logkG/math.log(2)/h)) if record.get('synthetic') else exact_phase(integer_mass(record['b'],record['R']*G**(1/len(record['b']))),m0);start=logmG/math.log(2)
    rect.append((phase,start,start+1,coef))
    return rect,N


def classify(records,trainrect,M,G,a,C):
    windows=[(r['logm']/math.log(2),r['logm']/math.log(2)+1) for r in records]
    alphas=window_integrals(trainrect,windows)/C
    branches={k:[] for k in ['low','rapid','top','bulk']};near_low=0;near_rapid=0
    for r,alpha in zip(records,alphas):
        n=len(r['b']);An=1+n*math.log(2);K=max(2**.125,An*alpha)
        seg,logm,logmG=mass_segments(r['b'],r['R'],G)
        kG=math.exp(logmG-logm)
        if abs(alpha*An-1)<.05:near_low+=1
        if abs(math.log(kG/K))<.05:near_rapid+=1
        if alpha<=1/An:label='low'
        elif kG>=K:label='rapid'
        elif r['R']>=2*a/G**(1/n):label='top'
        else:label='bulk'
        branches[label].append(dict(**r,alpha=float(alpha),kG=kG,K=K,segments=seg,logmG=logmG))
    return branches,dict(near_low=near_low/M,near_rapid=near_rapid/M)


def batch_fields(points,trainrect,q,G,a):
    n=points.shape[1];M=len(points);grid=a*(1+np.arange(33)/32)
    records=parent_records(points,grid,q);C=1+math.log(4)
    branches,near=classify(records,trainrect,M,G,a,C)
    fields={law:[] for law in ['old','bulk_old','common','adaptive']}
    fields['old']=old_rects(records,M);fields['bulk_old']=old_rects(branches['bulk'],M)
    Ns=[]
    for r in branches['bulk']:
        for law in ['common','adaptive']:
            rect,N=transformed_rects(r,r['segments'],r['logmG'],G,M,law)
            fields[law].extend(rect)
            if law=='adaptive':Ns.append(N)
    stats=dict(E_centers=len(records),E_center_fraction=len(records)/M,bulk_center_fraction=len(branches['bulk'])/M,branch_center_fraction={k:len(v)/M for k,v in branches.items()},branch_q_mass={k:sum(r['q0'] for r in v)/M for k,v in branches.items()},N_range=[min(Ns),max(Ns)] if Ns else None,near_threshold=near)
    for law in fields:
        E,ph=energy_rectangles(fields[law]);stats[law]=dict(self_energy=E,phase_energy=ph)
    # Old deletion attribution: <L_branch,L_old>/||L_old||², sums to one.
    oldE=stats['old']['self_energy']
    stats['old_energy_branch_share']={k:cross_rectangles(old_rects(v,M),fields['old'])[0]/oldE if oldE else None for k,v in branches.items()}
    return fields,stats


def run_field_stage(M=64,T=64,dimensions=(8,32,128),qs=(1,2,4),Gs=(2,4)):
    st=time.perf_counter();results=[]
    for n in dimensions:
        a=math.sqrt(n);grid=a*(1+np.arange(33)/32)
        training=qmc.Sobol(n,scramble=True,seed=56001).random_base2(int(math.log2(T)))
        evals=[qmc.Sobol(n,scramble=True,seed=s).random_base2(int(math.log2(M))) for s in [56011,56021]]
        for q in qs:
            tr=parent_records(training,grid,q);L=old_rects(tr,T)
            for G in Gs:
                packs=[batch_fields(p,L,q,G,a) for p in evals]
                cross={}
                for law in ['old','bulk_old','common','adaptive']:
                    E,ph=cross_rectangles(packs[0][0][law],packs[1][0][law]);cross[law]=dict(energy=E,phase_energy=ph)
                results.append(dict(n=n,a=a,q=q,G=G,M=M,T=T,training_E_fraction=len(tr)/T,batches=[x[1] for x in packs],cross=cross,interpretation='Independent scrambled-Sobol cross field energy, numerical diagnostic only'))
    return dict(stage='field',M=M,T=T,dimensions=list(dimensions),qs=list(qs),Gs=list(Gs),seed_training=56001,seeds_evaluation=[56011,56021],lambda_band='2q',C=1+math.log(4),grid='sqrt(n)*(1+k/32),k=0..32; maxdensity then smallest R tie',results=results,elapsed_seconds=time.perf_counter()-st)


def stress_engine():
    # Explicit mass-jump pressure model: kappa=1 then 2, G=4.
    b=np.array([.2]*8);r=dict(b=b,R=3.,logm=0.,q0=1.,synthetic=True)
    seg=[(1.,1.5,0.),(1.5,4.,math.log(2))]
    N=1+.5+2.5/2+4/2
    normalization=(1+.5+2.5/2+4/2)/N
    allrect=[];res={}
    for law in ['common','adaptive']:
        rect,_=transformed_rects(r,seg,math.log(2),4,1,law)
        E,ph=energy_rectangles(rect)
        naive=sum(c*d*max(0.,1-abs(l-u)) for j,l,_,c in rect for k,u,_,d in rect if j==k)
        res[law]=dict(energy_sweep=E,energy_naive_gram=naive,phase_energy=ph)
        assert abs(E-naive)<1e-13
        allrect.append(rect)
    cross,ph=cross_rectangles(*allrect)
    naive=sum(c*d*max(0.,1-abs(l-u)) for j,l,_,c in allrect[0] for k,u,_,d in allrect[1] if j==k)
    assert abs(cross-naive)<1e-13
    return dict(kappa_step='1 on [1,1.5),2 on [1.5,4]',N=N,normalization=normalization,fields=res,cross_energy=cross,cross_naive=naive,interpretation='Implementation pressure test only, not sampled lattice data')


def training_stability():
    n=128;a=math.sqrt(n);grid=a*(1+np.arange(33)/32)
    train=qmc.Sobol(n,scramble=True,seed=56001).random_base2(10)
    Ls=[old_rects(parent_records(train[:T],grid,1),T) for T in [512,1024]]
    results=[]
    for seed in [56011,56021]:
        pts=qmc.Sobol(n,scramble=True,seed=seed).random_base2(10)
        rec=parent_records(pts,grid,1)
        for G in [2,4]:
            assignments=[]
            for L in Ls:
                groups,_=classify(rec,L,1024,G,a,1+math.log(4))
                assignments.append({float(r['b'][0]):k for k,v in groups.items() for r in v})
            change={}
            for r in rec:
                old,new=[x[float(r['b'][0])] for x in assignments]
                if old!=new:change[old+'->'+new]=change.get(old+'->'+new,0)+1
            results.append(dict(seed=seed,G=G,E_centers=len(rec),label_switches=change,switch_fraction_all_centers=sum(change.values())/1024))
    return results


def ablation_same_bulk():
    """R560 authorized endpoint/density ablation; all original inputs frozen."""
    st=time.perf_counter();n=128;M=T=1024;q=1;a=math.sqrt(n)
    grid=a*(1+np.arange(33)/32)
    train=qmc.Sobol(n,scramble=True,seed=56001).random_base2(10)
    L=old_rects(parent_records(train,grid,q),T)
    evals=[qmc.Sobol(n,scramble=True,seed=s).random_base2(10) for s in [56011,56021]]
    out=[]
    for G in [2,4]:
        batches=[]
        for pts in evals:
            groups,_=classify(parent_records(pts,grid,q),L,M,G,a,1+math.log(4))
            bulk=groups['bulk'];flat=[r for r in bulk if integer_mass(r['b'],r['R']*G**(1/n))==integer_mass(r['b'],r['R'])]
            fields={k:[] for k in ['common','two','adaptive','init','cont','end','old_bulk']}
            flats={k:[] for k in ['common','two','adaptive','old_bulk']}
            fields['old_bulk']=old_rects(bulk,M);flats['old_bulk']=old_rects(flat,M)
            flatkeys={float(r['b'][0]) for r in flat}
            for r in bulk:
                ad,N=transformed_rects(r,r['segments'],r['logmG'],G,M,'adaptive')
                common,_=transformed_rects(r,r['segments'],r['logmG'],G,M,'common')
                # ad has all continuous segments, then initial atom, then end atom.
                cont,init,end=ad[:-2],ad[-2:-1],ad[-1:]
                norm=2+math.log(G);factor=(1+math.log(G))/norm
                two=[(j,l,u,c*factor) for j,l,u,c in common]
                s=r['logm']/math.log(2)
                two.append((0,s,s+1,r['q0']/norm/M))
                local=dict(adaptive=ad,common=common,two=two,init=init,cont=cont,end=end)
                for k,rr in local.items():fields[k].extend(rr)
                if float(r['b'][0]) in flatkeys:
                    for k in ['common','two','adaptive']:flats[k].extend(local[k])
            qbulk=sum(r['q0'] for r in bulk);qflat=sum(r['q0'] for r in flat)
            scorebulk=sum(r['q0']*r['alpha'] for r in bulk);scoreflat=sum(r['q0']*r['alpha'] for r in flat)
            stats=dict(bulk_count=len(bulk),flat_count=len(flat),flat_fraction_of_bulk=len(flat)/len(bulk) if bulk else None,flat_q0_mass_fraction=qflat/qbulk if qbulk else None,flat_oldscore_q0alpha_fraction=scoreflat/scorebulk if scorebulk else None,flat_q0_mass=qflat/M,flat_oldscore_q0alpha=scoreflat/M)
            batches.append((fields,flats,stats))
        energies={k:cross_rectangles(batches[0][0][k],batches[1][0][k])[0] for k in ['common','two','adaptive','old_bulk']}
        phases={k:cross_rectangles(batches[0][0][k],batches[1][0][k])[1] for k in ['common','two','adaptive']}
        labels=['init','cont','end'];matrix=[]
        for x in labels:
            matrix.append([.5*(cross_rectangles(batches[0][0][x],batches[1][0][y])[0]+cross_rectangles(batches[0][0][y],batches[1][0][x])[0]) for y in labels])
        reconstructed=sum(map(sum,matrix))
        assert abs(reconstructed-energies['adaptive'])<1e-12
        attribution={}
        for k in energies:
            numerator=.5*(cross_rectangles(batches[0][1][k],batches[1][0][k])[0]+cross_rectangles(batches[0][0][k],batches[1][1][k])[0])
            self_flat=cross_rectangles(batches[0][1][k],batches[1][1][k])[0]
            attribution[k]=dict(flat_energy_attribution=numerator,flat_energy_fraction=numerator/energies[k] if energies[k] else None,flat_only_cross_energy=self_flat)
        out.append(dict(G=G,n=n,q=q,M=M,T=T,energies=energies,phase_energies=phases,ratios=dict(adaptive_over_two=energies['adaptive']/energies['two'],two_over_common=energies['two']/energies['common']),adaptive_component_labels=labels,adaptive_symmetric_cross_matrix=matrix,matrix_sum=reconstructed,batches=[x[2] for x in batches],flat_energy_attribution=attribution))
    for row in out:
        mat=row['adaptive_symmetric_cross_matrix']; total=row['energies']['adaptive']
        diag=mat[0][0]; attrib=sum(mat[0])
        row['initial_atom_diagnostic']=dict(diagonal_energy=diag,additive_gram_attribution=attrib,additive_energy_fraction=attrib/total,drop_if_initial_field_removed_without_renormalization=2*attrib-diag)
    return dict(frozen_input='n128,q1,M=T1024,same seeds/training/bulk as original main run',results=out,elapsed_seconds=time.perf_counter()-st,warning='Added ablation only; same floating/QMC limitations, no certification or enlarged parameter scan.')


def recovery_same_bulk():
    """Actual per-parent eta division BEFORE full field aggregation."""
    st=time.perf_counter();n=128;M=T=1024;q=1;a=math.sqrt(n)
    grid=a*(1+np.arange(33)/32)
    train=qmc.Sobol(n,scramble=True,seed=56001).random_base2(10)
    L=old_rects(parent_records(train,grid,q),T)
    evals=[qmc.Sobol(n,scramble=True,seed=x).random_base2(10) for x in [56011,56021]]
    results=[]
    def summarize(rows,G):
        vals=np.asarray(rows);eta=vals[:,0]
        correlations={}
        for j,name in enumerate(['eta','N','I','kappaG','alpha','q0']):
            if j:correlations[name]=float(np.corrcoef(eta,vals[:,j])[0,1])
        bins=[];order=np.argsort(eta)
        for k,indices in enumerate(np.array_split(order,4)):
            part=vals[indices]
            bins.append(dict(eta_quartile=k+1,count=len(indices),eta_range=[float(min(part[:,0])),float(max(part[:,0]))],mean_eta=float(np.mean(part[:,0])),mean_kappaG=float(np.mean(part[:,3])),mean_alpha=float(np.mean(part[:,4])),mean_N=float(np.mean(part[:,1])),mean_I=float(np.mean(part[:,2]))))
        return dict(count=len(rows),eta_quantiles={str(p):float(np.quantile(eta,p)) for p in [0,.1,.25,.5,.75,.9,1]},eta_mean=float(np.mean(eta)),eta_q0_weighted_mean=float(np.average(eta,weights=vals[:,5])),eta_q0alpha_weighted_mean=float(np.average(eta,weights=vals[:,5]*vals[:,4])),correlations=correlations,eta_quartiles_joint=bins)
    for G in [2,4]:
        batch=[];p=1/(1+math.log(G));eta_two=2/(2+math.log(G))
        for pts in evals:
            groups,_=classify(parent_records(pts,grid,q),L,M,G,a,1+math.log(4))
            fields={law:[] for law in ['common','two','adaptive']};raw={law:[] for law in fields};rows=[]
            for r in groups['bulk']:
                ad,N=transformed_rects(r,r['segments'],r['logmG'],G,M,'adaptive')
                common,_=transformed_rects(r,r['segments'],r['logmG'],G,M,'common')
                I=1+sum(math.log(u/l)*math.exp(r['logm']-lm) for l,u,lm in r['segments'])+math.exp(r['logm']-r['logmG'])
                eta=I/N
                assert eta>=(2+math.log(G))/(2*G)-1e-13 and eta<=1+1e-13
                norm=2+math.log(G);factor=(1+math.log(G))/norm
                two=[(j,l,u,c*factor) for j,l,u,c in common]
                left=r['logm']/math.log(2);two.append((0,left,left+1,r['q0']/norm/M))
                for law,rect,efficiency in [('common',common,p),('two',two,eta_two),('adaptive',ad,eta)]:
                    raw[law].extend(rect)
                    fields[law].extend((j,l,u,c/efficiency) for j,l,u,c in rect)
                rows.append([eta,N,I,r['kG'],r['alpha'],r['q0']])
            batch.append((fields,raw,summarize(rows,G)))
        restored={law:cross_rectangles(batch[0][0][law],batch[1][0][law])[0] for law in ['common','two','adaptive']}
        rawenergies={law:cross_rectangles(batch[0][1][law],batch[1][1][law])[0] for law in ['common','two','adaptive']}
        phase={law:cross_rectangles(batch[0][0][law],batch[1][0][law])[1] for law in ['common','two','adaptive']}
        selfenergies=[{law:energy_rectangles(b[0][law])[0] for law in ['common','two','adaptive']} for b in batch]
        assert abs(restored['common']-rawenergies['common']/p**2)<1e-12
        assert abs(restored['two']-rawenergies['two']/eta_two**2)<1e-12
        results.append(dict(G=G,n=n,q=q,M=M,T=T,raw_cross=rawenergies,C_eta_cross=restored,C_eta_self=selfenergies,C_eta_phase=phase,ratios=dict(adaptive_over_common=restored['adaptive']/restored['common'],adaptive_over_two=restored['adaptive']/restored['two'],two_over_common=restored['two']/restored['common']),fixed_eta=dict(common=p,two=eta_two,adaptive_universal_lower=(2+math.log(G))/(2*G)),adaptive_eta_batches=[b[2] for b in batch],warning='Adaptive per-parent eta division occurred before aggregation, not division by mean eta.'))
    return dict(frozen_input='same n128,q1,M=T1024,seeds/training/original bulk as prior results',results=results,elapsed_seconds=time.perf_counter()-st,scope='Per-cell periodic atomic/QMC diagnostic only; not a general L1 result.')


if __name__=='__main__':
    import argparse,resource,scipy
    parser=argparse.ArgumentParser()
    parser.add_argument('--all',action='store_true',help='Reproduce the authorized full bounded experiment; default geometry only')
    parser.add_argument('--recovery-only',action='store_true',help='Append exact per-parent recovery diagnostic to existing JSON')
    parser.add_argument('--ablation-only',action='store_true',help='Append same-bulk endpoint/density ablation to existing JSON')
    args=parser.parse_args()
    if args.recovery_only:
        with open(str(Path(__file__).with_name('ccu_r560_numeric.json'))) as f:result=json.load(f)
        result['per_parent_recovery']=recovery_same_bulk()
        with open(str(Path(__file__).with_name('ccu_r560_numeric.json')),'w') as f:json.dump(result,f,indent=2)
        print('Appended per-parent recovery; existing certificate instance preserved')
        raise SystemExit(0)
    if args.ablation_only:
        with open(str(Path(__file__).with_name('ccu_r560_numeric.json'))) as f:result=json.load(f)
        result['endpoint_density_ablation']=ablation_same_bulk()
        with open(str(Path(__file__).with_name('ccu_r560_numeric.json')),'w') as f:json.dump(result,f,indent=2)
        print('Appended same-bulk ablation; existing certificate instance preserved')
        raise SystemExit(0)
    result=geometry_calibration()
    try:
        with open(str(Path(__file__).with_name('ccu_r560_numeric.json'))) as f:previous=json.load(f)
        if 'certificate_instance' in previous:result['certificate_instance']=previous['certificate_instance']
    except FileNotFoundError:pass
    if args.all:
        result['field_calibration']=run_field_stage(M=64,T=64)
        result['mass_jump_pressure']=stress_engine()
        result['expanded']=[run_field_stage(M=M,T=T,dimensions=(128,),qs=(1,),Gs=(2,4)) for M,T in [(512,512),(1024,1024),(1024,512)]]
        result['training_stability_same_evaluation']=training_stability()
        result['endpoint_density_ablation']=ablation_same_bulk()
        result['per_parent_recovery']=recovery_same_bulk()
    result['runtime_metadata']=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,cpu_count=os.cpu_count(),physical_ram_bytes=os.sysconf('SC_PAGE_SIZE')*os.sysconf('SC_PHYS_PAGES'),BLAS_threads=2,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    with open(str(Path(__file__).with_name('ccu_r560_numeric.json')),'w') as f:json.dump(result,f,indent=2)
    print('Saved',Path(__file__).with_name('ccu_r560_numeric.json'))

