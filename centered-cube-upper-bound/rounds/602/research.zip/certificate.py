#!/usr/bin/env python3
"""R602 scalar Fraction/SymPy checks only; no geometric budget claim."""
import argparse,hashlib,json,platform,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import sympy as s

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
 A,T,la,D,a,b=s.symbols('alpha T lambda D a b',positive=True);h=A-T;dp=D+b;delta=(a-la*T*b)/(la*dp)
 symbolics={
 'identity_delta_le_h':s.simplify(h-(h-delta)-delta),
 'identity_delta_gt_h':s.simplify(h-0-h),
 'signed_row_equals_delta':s.simplify(a/(la*dp)-T*b/dp-delta),
 'saturated_signed_row_equals_h':s.simplify(h/delta*(a/(la*dp)-T*b/dp)-h),
 'positive_row_decomposition':s.simplify(a/(la*dp)-(delta+T*b/dp))}
 assert all(v==0 for v in symbolics.values())
 grids={
 'initial':{'alpha':['1/4','1/2'],'T_over_alpha':['0','1/2'],'lambda':['1'],'D':['1'],'a':['0','1','2'],'b':['0','1','2']},
 'boundary_and_negative_delta':{'alpha':['1/1000000','1/4','999999/1000000'],'T_over_alpha':['0','1/1000000','999999/1000000'],'lambda':['1'],'D':['1'],'a':['0','1/1000000','1'],'b':['0','1','1000000']},
 'wide_dynamic_range':{'alpha':['1/1000','1/64','1/4','1/2','999/1000'],'T_over_alpha':['0','1/1000','1/2','999/1000'],'lambda':['1/1000','1','1000'],'D':['1/1000','1','1000'],'a':['0','1/1000','1','1000'],'b':['0','1/1000','1','1000']}}
 import itertools
 stages=[];witness={};total=0
 for stage,g in grids.items():
  counts={'cases':0,'negative_delta':0,'zero_delta':0,'delta_between_zero_and_h':0,'delta_equal_h':0,'delta_above_h':0}
  for A0,tr,lam,d0,aa,bb in itertools.product(*(map(F,g[k]) for k in ('alpha','T_over_alpha','lambda','D','a','b'))):
   t=A0*tr;hh=A0-t;DD=d0+bb;de=(aa-lam*t*bb)/(lam*DD);tau=F(1) if de<=hh else hh/de
   cut=hh-max(F(0),hh-de);neg=tau*t*bb/DD;pos=tau*aa/(lam*DD)
   assert 0<A0<1 and 0<=t<A0 and d0>0 and lam>0
   assert cut==min(hh,de) and 0<=tau<=1 and 0<=neg<A0 and 0<=pos<=2*A0
   assert pos-neg==min(hh,de)
   # Stronger scalar cap, derived from pos=min(h,delta)+neg and neg<=T.
   assert pos<=A0
   key='negative_delta' if de<0 else ('zero_delta' if de==0 else ('delta_between_zero_and_h' if de<hh else ('delta_equal_h' if de==hh else 'delta_above_h')))
   counts[key]+=1;counts['cases']+=1;total+=1
   if key not in witness:witness[key]={'alpha':str(A0),'T':str(t),'lambda':str(lam),'D':str(d0),'a':str(aa),'b':str(bb),'delta':str(de),'h':str(hh),'tau':str(tau),'positive_row':str(pos),'negative_row':str(neg),'signed_difference':str(pos-neg)}
  stages.append({'stage':stage,'counts':counts})
 # Force the h=delta dividing boundary with exact formula a=lambda*h*(D+b)+lambda*T*b.
 ties=[]
 for A0,t in ((F(1,4),F(0)),(F(1,4),F(1,8)),(F(999,1000),F(998,1000))):
  lam=F(3,2);d0=F(2,3);bb=F(7,5);aa=lam*(A0-t)*(d0+bb)+lam*t*bb;de=(aa-lam*t*bb)/(lam*(d0+bb));assert de==A0-t
  ties.append({'alpha':str(A0),'T':str(t),'a':str(aa),'lambda':str(lam),'D':str(d0),'b':str(bb),'delta_equal_h':True,'tau':'1'})
 q,theta,C=s.symbols('q theta C',positive=True)
 restore_identity=s.simplify(C*(theta/q)/(1-theta/q)-C*theta/(q-theta));assert restore_identity==0
 restore_grid={'q':['2','3','10','1000'],'theta':['0','1/1000','1/4','1/2','999/1000','1'],'C_over_q':['0','1/1000','1','2']};rcount=0;csmall=0
 for qq,th,ratio in itertools.product(*(map(F,restore_grid[k]) for k in ('q','theta','C_over_q'))):
  cc=ratio*qq;alpha=th/qq;value=cc*alpha/(1-alpha);assert cc/qq<=2 and qq>=2 and th<=1
  assert value<=4*th
  if cc<=2:assert value<=2*th;csmall+=1
  rcount+=1
 d={'scope':'Scalar truncation and source row-cap certificate only. No geometry, integral, all-family price, receiver gain or root bound is proved.','definitions':'lambda,D>0;0<alpha<1;0<=T<alpha;a,b>=0;h=alpha-T;Dprime=D+b;delta=(a-lambda*T*b)/(lambda*Dprime). tau=1 if delta<=h, otherwise h/delta.','symbolic_residuals':{k:str(v) for k,v in symbolics.items()},'branch_proof':'If delta<=h, h-delta>=0 and identity gives delta; tau=1 so signed row=delta. If delta>h, h-delta<0 and identity gives h; tau=h/delta gives signed row=h. Both include negative delta. Negative row=tau*T*b/(D+b) is nonnegative and<alpha; positive row=signed row+negative row<=h+T=alpha, stronger than2alpha. tau in[0,1].','input_grids':grids,'stages':stages,'grid_case_count':total,'explicit_boundary_ties':ties,'branch_witnesses':witness,'all_assertions_passed':True,'restore':{'formula_exact':'C*alpha/(1-alpha)=C*theta/(q-theta), alpha=theta/q','symbolic_identity_residual':str(restore_identity),'proof':'Under C/q<=2,q>=2,0<=theta<=1: C*theta/(q-theta)<=2*theta/(1-theta/q)<=4*theta. When C<=2, sharper<=2*theta/(q-theta)<=2*theta. theta0 is the continuous boundary extension, not a valid positive-alpha source test.','grid':restore_grid,'cases':rcount,'C_le_2_branch_cases':csmall},'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':s.__version__,'processes':1,'runtime_seconds':time.perf_counter()-start,'command':shlex.join([sys.executable,*sys.argv]),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'stages':stages,'total':total,'explicit_ties':len(ties),'restore_cases':rcount,'execution':d['execution']}))
if __name__=='__main__':main()
