# Round 66: signed arrival curvature and the failure of positive payments

2026-10-11. **The uniform centered-cube objective sqrt(n)n^{o(1)} remains
unproved.** The retained fully general weak bound is O(n log n). This round
does not turn large positive proxy costs into a weak-type counterexample.
The cap-energy route is only sufficient; none of the negative results below
establishes that the original weak target fails.

## Main progress and corrected route

An exact signed arrival-curvature formula holds for arbitrary finite
positive atomic sources, including genuine capture ties and coincident lag
events. It cancels local density profiles linear in volume. A general
entropy upper bound for the unrenormalized positive arrival envelope is
matched in logarithmic order by an actual one-dimensional good-set grid.

The improved curvature formula does not justify taking its positive part:
a single bounded positive majority-digit source with separated scales has
an explicit divergent positive-curvature lower budget. A verified finite
atomic approximation retains half of a regularly distributed receiver
set inside the ORIGINAL good set. Thus even at fixed n=1,H=3,W=1 the bare
positive-curvature charge is unbounded. The charged scales are entirely
in the multisource submajority region. The shared-source construction and
the finite-atom transfer are proved, not inferred from numerical growth.

For the conserved dyadic replacement of Round65, every target block's
self-energy on the original good set is bounded by c R^n H times its mass.
At alpha=2n^2+1 the entire block diagonal is at most ceHW. This pays the
diagonal without a global target-height factor. The signed cross-block
sum remains unpaid. An exact target-subclass example shows that taking
positive parts BEFORE receiver integration makes the cross budget grow
logarithmically despite bounded target density. This does not rule out
absolute estimates applied AFTER the spatial integral has already
retained its cancellations.

## Reproduction and evidence scope

The archive contains five members: proof.md, proof.tex.txt,
mass_band_probe.py, results.json and inventory.json. Preserve the supplied
result, then run `python3 -B mass_band_probe.py` in an extracted temporary
directory using Python 3.12.14 and NumPy 2.3.5. Three Python guards are
embedded below; save and execute each block independently. The first two
use the standard library; the separated-scale guard also uses NumPy for
its last, deliberately noncertifying binary-profile pressure stage.

The parent independently reviewed the finite source proofs, corrected the
platform hypothesis to log B>2, and checked the order of limits in the
atomic transfer. The final main script was replayed in a fresh temporary
directory with byte-identical JSON. All three embedded guards were run;
their exact outputs and hashes are in the receipt below. Static LaTeX
checks are not compilation. The standalone source is saved as .tex.txt;
no PDF or compilation is produced.

At the user's renewed request, all 64 canonical skill entries and 437
direct reference files were reopened and hash-compared in Round66; none
had changed from Round65 and no direct reference was missing. The two
L--N shared-ledger resolver checks passed. N03, N04, L03 and F05 entries
were reread in context, and researchers reread the actual method/interface
conditions. This is not a fresh reading or certification of every PDF. No external Carleson, martingale or outer
embedding theorem is silently transferred to arbitrary cube histories.
The retained global spectral theorem is identified separately wherever
used; it is not certified by the finite numerical tests here.



# Round 66: exact signed arrival curvature and an unpaid positive envelope

The purpose is a source-uniform budget for actual capped cube energy, not an
estimate restricted to the witness below. The following identity holds for
every finite positive atomic source, at every receiver outside its sites.
It retains the cancellations that a positive arrival-mass envelope discards.
Neither the identity nor a finite numerical check estimates the full
source-uniform energy constant. The general weak-type target remains open.

## Exact signed formula, including coincident lag events

Fix a receiver x and write the merged positive capture-volume events as
0<v_1<...<v_J with masses delta_j>0. Set

    F(v)=sum_{v_j<=v} delta_j, A(v)=F(v)/v,
    D_b(v)=A(bv)-A(v), b>1,
    E_b(x)=integral_0^infinity D_b(v)^2 dv/v.

For cubes v_j=(2||x-y_j||_infinity)^n; all equal-distance source masses are
merged before using the formula. Define

    Gamma_j=F(v_j)+F(v_j-)-b^(-1)F(bv_j)-b F((v_j/b)-).

Then the exact identity is

    E_b(x)=sum_j delta_j Gamma_j/v_j^2.                 (AC)

The inner left limit in the final term is essential when v_i=v_j/b.
The formula has no source-count, dimension or scale-grid error. In the
research application b=e and u=log v, so it is the actual time-step-one
energy used in previous rounds.

Proof: F vanishes for v<v_1 and equals total mass for v>v_J, so all
integrals below converge and the boundary terms F(v)^2/v^2 and
F(v)F(bv)/v^2 vanish at both endpoints. Integration by parts gives

    I=integral F(v)^2 dv/v^3
     =1/2 sum_j delta_j[F(v_j)+F(v_j-)]/v_j^2.

For cadlag step functions the product jump identity, with no exclusion of
common jumps, is

    d[F(v)F(bv)]=F(bv)dF(v)+F(v-)d[F(bv)].

The first full value and second left value count a simultaneous product
jump once. Thus

    C=integral A(v)A(bv) dv/v
     =1/2 sum_j delta_j[b^(-1)F(bv_j)+b F((v_j/b)-)]/v_j^2.

Changing variable in integral A(bv)^2 dv/v gives I. Consequently
E_b=2I-2C, proving (AC). All of this is a finite sum argument followed by
ordinary integration; there is no stochastic stopping or hidden exchange.

Equivalently, Gamma_j/v_j is

    A(v_j)+A(v_j-)-A(bv_j)-A((v_j/b)-).

Thus a locally continuous profile F(v)=rho v has zero curvature whenever
all four arguments lie in that linear region. This is the coherent density
contribution the earlier positive charge fails to cancel. Individual Gamma_j
may be negative: for b=2 and events (v,delta)=(1,1),(2,4), Gamma=(-3/2,7/2),
so E_b=-3/2+7/2=2, while its positive part is 7/2. This also checks a genuine
coincidence between an inner event and another event shifted by b.

## Positive envelopes are sufficient only after an independent budget

On the original G={M mu<=H}, define

    P_G=integral_G sum_j delta_j F(v_j)/v_j^2 dx,
    Q_G^+=integral_G sum_j delta_j max(Gamma_j,0)/v_j^2 dx.

For b=e the exact energy obeys E_G<=Q_G^+<=2P_G, since
Gamma_j<=F(v_j)+F(v_j-)<=2F(v_j). These are valid direction-of-bound
statements, not estimates of P_G or Q_G^+. For finite sources the envelopes
are integrable: G forces v_j>=delta_j/H, and the upper bounds may depend on
the number and masses of the events. Such dependence cannot be suppressed
in the main theorem. The parent requested independent numerical pressure
on Q_G^+; its source-uniform budget is not assumed.

There is a general entropy upper bound for this envelope, consistent with
the previously retained entropy route. Expanding a tied batch into its
original atoms does not change P. For atom i, on G its distance volume v_i
satisfies v_i>=p_i/H and F(v_i)<=min(Hv_i,W). Cube radial volume pushes
Lebesgue measure to dv_i, so its contribution is at most

    integral_{p_i/H}^infinity p_i min(Hv,W) dv/v^2
       =H p_i[1+log(W/p_i)].

Writing a_i=p_i/W and Ent(a)=sum_i a_i log(1/a_i) yields

    P_G<=HW[1+Ent(a)].                                (PE)

This is a finite, fully general bound, but its entropy cannot be suppressed
for this positive proxy: the equal-mass example below has Ent=log N and a
matching logarithmic lower order. This does not prove entropy is necessary
for the actual signed energy or for the weak-type theorem.

## Exact logarithmic failure of the unrenormalized positive envelope

Let n=1, N=2^m>=16, h=1/N, H=2 and

    mu_N=h sum_{j=0}^{N-1} delta_{jh}, W=1.

The exact strict bad set is the disjoint union

    Omega=union_j (jh-h/4,jh+h/4).                    (G)

Indeed an interval capturing k>=2 atoms has length at least (k-1)h,
so its average is at most k/(k-1)<=2. An interval capturing one atom exceeds
2 exactly when its center has distance less than h/4 from that atom.
At an atom arbitrarily small intervals apply. Boundary equalities are good.
This proves (G) for all radii, not for a sampled radius list.

Let S=G intersect [1/4,3/4]. The excluded intervals are periodic with
period h and occupy exactly half each period, including the partial end
periods, so |S|=1/4. For a receiver in S, excluding the finite set of
distance ties, let v_(k) be the k-th arrival volume. For 1<=k<=K=N/4,
the interval centered at x of length (k+1)h contains at least k source sites.
It stays within the lattice's endpoint range for N>=16; direct lattice
counting also covers its endpoint alignments. Hence

    v_(k)<=(k+1)h, delta_k=h, F(v_(k))=kh.

Therefore pointwise almost everywhere on S,

    sum_j delta_j F(v_j)/v_j^2
      >=sum_{k=1}^K k/(k+1)^2 >=(1/4)sum_{k=1}^K 1/k.

Integrating gives the exact lower bound

    P_G>= H_K/16,    P_G/(HW)>=H_K/32 -> infinity.     (P)

Thus no dimension-only constant pays this positive arrival envelope even
on the true final good set. This is different from Round65's H=1/4 grid,
where only external receivers survive and squared single jumps vanish.
Here an interior set of fixed positive measure survives, and coherent
arrivals contribute at many small mass scales.

The actual energy does not inherit this divergence. For example the
already proved Round65 conserved replacement with n=1, alpha=3 has beta=8,
B_1=3(e+1). Its explicit bound is

    E_G/(HW)<=[sqrt(8 kappa_1)+sqrt(3(e+1))]^2,
    kappa_1<=3 log 3,

uniformly in N. This is only a fixed-dimension calibration of the
counterexample, not an improvement of the general dimension dependence.
Large P_G is not large weak-type output.

## Executable exact finite checks

The following program checks (AC) by an independent event-interval integral
using rational b, positive rational masses, deliberately tied lag events,
and several receiver dimensions. It also verifies the exact grid cap
interval union and finite lattice rank bounds. These finite checks support
the algebra and endpoint conventions; the proof above establishes the
general identity and the divergence in (P). No floating exponent fit occurs.

```python
from fractions import Fraction as F
from itertools import product
import random, json

def merge(events):
    d={}
    for v,p in events:
        assert v>0 and p>0
        d[v]=d.get(v,F(0))+p
    return sorted(d.items())

def cumulative(events,v,left=False):
    return sum((p for t,p in events if t<v or (not left and t==v)),F(0))

def check(events,b):
    events=merge(events); jumps={}
    for v,p in events:
        jumps[v/b]=jumps.get(v/b,F(0))+p/b
        jumps[v]=jumps.get(v,F(0))-p
    keys=sorted(jumps);coef=F(0);exact=F(0)
    for i,v in enumerate(keys):
        coef+=jumps[v]
        exact+=coef**2/2*(v**-2-(keys[i+1]**-2 if i+1<len(keys) else 0))
    signed=F(0);positive=F(0);P=F(0)
    for v,p in events:
        gamma=(cumulative(events,v)+cumulative(events,v,True)
               -cumulative(events,b*v)/b-b*cumulative(events,v/b,True))
        signed+=p*gamma/v**2;positive+=p*max(gamma,0)/v**2
        P+=p*cumulative(events,v)/v**2
    assert signed==exact and 0<=signed<=positive<=2*P
    return exact,positive

assert check([(F(1),F(1)),(F(2),F(4))],F(2))==(F(2),F(7,2))
rng=random.Random(660031);checks=1
for b in [F(3,2),F(2),F(3),F(5,4)]:
    for J in [1,2,4,8,16]:
        for repeat in range(8):
            ev=[(b**rng.randint(-4,5),F(rng.randint(1,9),7)) for _ in range(J)]
            check(ev,b);checks+=1
for n in [1,2,3,4]:
    sites=list(product([F(0),F(1)],repeat=n))
    for off in [F(0),F(1,7),F(1,3)]:
        x=tuple(F(2)+off+F(k,11) for k in range(n))
        ev=[((2*max(abs(a-z) for a,z in zip(x,y)))**n,F(i+1))
            for i,y in enumerate(sites)]
        check(ev,F(2));checks+=1

geometry=0;bounds=[]
for N in [16,32,64,128,256]:
    h=F(1,N);sites=[j*h for j in range(N)]
    # Every k>=2 block cannot exceed H=2, including the k=2 equality.
    for k in range(2,N+1):assert F(k,k-1)<=2;geometry+=1
    endpoints=sorted({F(1,4),F(3,4)}|
       {a for y in sites for a in [y-h/4,y+h/4] if F(1,4)<a<F(3,4)})
    length=F(0)
    for a,z in zip(endpoints,endpoints[1:]):
        x=(a+z)/2
        if min(abs(x-y) for y in sites)>=h/4:length+=z-a
    assert length==F(1,4);geometry+=1
    for j in range(N//4,3*N//4):
        for frac in [F(1,4),F(3,8),F(1,2),F(5,8),F(3,4)]:
            x=(j+frac)*h
            if not F(1,4)<=x<=F(3,4):continue
            distances=sorted(2*abs(x-y) for y in sites)
            # Full tied batches, not partial averages, decide actual cap.
            for v in set(distances):
                assert h*sum(t<=v for t in distances)<=2*v
            for k in range(1,N//4+1):
                assert distances[k-1]<=(k+1)*h
                assert F(k,(k+1)**2)>=F(1,4*k)
            geometry+=1
    harmonic=sum((F(1,k) for k in range(1,N//4+1)),F(0))
    bounds.append({'N':N,'exact_P_over_HW_lower':str(harmonic/32)})
print(json.dumps({'exact_curvature_event_checks':checks,
 'exact_geometry_cases':geometry,'grid_lower_bounds':bounds},sort_keys=True))
```

## Skills and remaining use

L03's current distinction between exact rational certificates and nearest
high-precision comparisons is retained. N04's requirement for an actual
uniform cumulative budget prevents interpreting (AC) as a paid stopping
argument. The formula is a direct finite Stieltjes calculation, not an
imported martingale theorem. A positive-curvature envelope is a separate
candidate, and its possible failure must not be confused with failure of
the signed identity or of the weak-type goal.


# Round 66: a genuine submajority obstruction to positive arrival curvature

The general centered-cube weak upper bound remains unproved. This note proves that the new positive-curvature arrival charge is not a uniformly affordable substitute for the signed energy, even for finite positive atomic sources in dimension one, with fixed total mass and fixed original maximal-function threshold. The obstruction lies entirely in the multisource submajority region. It therefore addresses the unpaid branch of Round 65 rather than its already paid majority tail.

The construction first uses a bounded positive density to make all scale estimates explicit, then passes to finite atoms with an elementary, verified good-receiver set. No weak-type counterexample is claimed.

## 1. The candidate being tested

In dimension one write

\[
 F_x(v)=\mu([x-v/2,x+v/2]),\qquad A_x(u)=e^{-u}F_x(e^u),\qquad q=e^{-1}.
\]

For a finite atomic source, merge equal arrival volumes into masses \(\delta_j\), and set

\[
 \Gamma_x(v_j)=F_x(v_j)+F_x(v_j^-)-qF_x(ev_j)-eF_x((v_j/e)^-).
\]

The new exact signed arrival identity, proved separately by the parent agent, has the form

\[
 \int_{\mathbb R}|A_x(u+1)-A_x(u)|^2du
 =\sum_j\frac{\delta_j\Gamma_x(v_j)}{v_j^2}.
\]

This note tests only its proposed sufficient positive charge

\[
 Q_+(\mu;G)=\int_G\sum_j\frac{\delta_j[\Gamma_x(v_j)]_+}{v_j^2}\,dx.
\]

It does not reprove the signed identity or discard its endpoint conventions. For a density, define its continuous arrival analogue by

\[
 Q_+^{\rm ac}=\int dx\int_0^\infty
 \frac{[2F_x(v)-qF_x(ev)-eF_x(v/e)]_+}{v^2}\,dF_x(v).
\]

Since \(F_x\) is absolutely continuous,

\[
 \frac{dF_x}{dv}=\frac{f(x+v/2)+f(x-v/2)}2,
 \quad
 \frac{2F_x(v)-qF_x(ev)-eF_x(v/e)}v
 =2A_x(u)-A_x(u+1)-A_x(u-1).
\]

Consequently, on an interval whose two endpoints stay in a region where \(f\ge1-\eta\), the positive arrival charge is at least \(1-\eta\) times the integral of the positive second scale difference.

## 2. An elementary plateau-to-curvature lemma

Let \(a<b\), \(\ell=b-a>2\), and let \(A\) be locally integrable. Suppose

\[
 |A(u)-\alpha|\le\varepsilon\quad(u\in[a-1,a+1]),\qquad
 |A(u)-\beta|\le\varepsilon\quad(u\in[b-1,b+1]).
\]

Put \(L A(u)=2A(u)-A(u-1)-A(u+1)\). Then

\[
 \int_a^b[LA(u)]_+du\ge\frac{|\beta-\alpha|}{2\ell}-4\varepsilon. \tag{2.1}
\]

This requires no martingale or smoothness hypothesis. To prove it, changes of variable give

\[
 J:=\int_a^b LA(u)du
 =-\int_{a-1}^a A+\int_a^{a+1}A
   +\int_{b-1}^bA-\int_b^{b+1}A,
 \qquad |J|\le4\varepsilon.
\]

For \(I=\int_a^b(u-a)LA(u)du\), all interior coefficients cancel. Its lower endpoint coefficients are \(-(u+1-a)\) on \([a-1,a]\) and \(u-a-1\) on \([a,a+1]\); their integrals total \(-1\). Its upper coefficients are \(u-a+1\) on \([b-1,b]\) and \(-(u-a-1)\) on \([b,b+1]\); their integrals total \(+1\). The sum of their absolute integrals is \(1+2\ell\). Thus

\[
 |I-(\beta-\alpha)|\le(1+2\ell)\varepsilon.
\]

If \(P=\int_a^b(LA)_+\) and \(N=\int_a^b(LA)_-\), then \(|I|\le\ell(P+N)\) and \(|P-N|\le4\varepsilon\). Therefore

\[
 P\ge\frac{|\beta-\alpha|}{2\ell}
       -\left(3+\frac1{2\ell}\right)\varepsilon,
\]

which proves (2.1). Retaining the negative curvature is essential: the estimate pays the absolute difference of successive plateaus.

## 3. A single positive source encoding many coherent plateaus

Fix an odd integer \(m\ge3\), an even integer \(B\ge8\), and \(\eta=1/2\). On \([0,1]\) define

\[
 r_j(x)=\begin{cases}1,&\{B^j x\}<1/2,\\-1,&\{B^j x\}\ge1/2,\end{cases}
 \quad j=1,\ldots,m,
 \qquad
 f_m(x)=1+\eta\,\operatorname{sign}\Big(\sum_{j=1}^m r_j(x)\Big).
\]

Set \(f_m=0\) outside \([0,1]\). Because \(B\) is even, the \(r_j\) are independent fair signs under Lebesgue measure on \([0,1]\): each reads the lower or upper half of a different base-\(B\) digit. The unused first digit causes no difficulty. Since \(m\) is odd, the sign never vanishes, and

\[
 1-\eta\le f_m\le1+\eta\quad\hbox{on }[0,1],\qquad
 \int f_m=1.
\]

Hence, for this continuous source, \(H=3/2\) makes the actual good set all of \(\mathbb R\).

Let

\[
 g_k(x)=1+\eta\,\mathbb E\left[\operatorname{sign}(S_m)\mid r_1(x),\ldots,r_k(x)\right],
 \quad S_m=\sum_{j=1}^m r_j,
 \quad g_0=1.
\]

These are finite averages over the remaining signs. They are auxiliary source-design quantities. They are not identified with a cube filtration or a compensator.

Define plateau volumes and times

\[
 v_k=B^{-k-1/2},\qquad u_k=\log v_k,
 \quad k=0,\ldots,m.
\]

Remove from \([0,1]\) the points within \(ev_0/2\) of its two endpoints, and, for every \(j=1,\ldots,m\), the points within \(ev_j/2\) of a jump of \(r_j\). Denote the remaining set by \(E\). The jumps of \(r_j\) have spacing \(B^{-j}/2\), so

\[
 |[0,1]\setminus E|\le\frac{e(2m+1)}{\sqrt B}
 \le\frac{12(m+1)}{\sqrt B}. \tag{3.1}
\]

For \(x\in E\), \(k\ge1\), and \(|s|\le1\), the averaging interval of volume \(e^s v_k\) stays inside \([0,1]\) and crosses no jump of any \(r_j\), \(j\le k\), because \(v_k\le v_j\). With these first signs fixed, the remaining pattern is periodic with period \(B^{-k-1}\), and its average over one period is \(g_k(x)\). After deleting complete periods, the two partial end periods have total length at most \(2B^{-k-1}\). Since the density and its conditional average lie between \(1-\eta\) and \(1+\eta\),

\[
 |A_x(u_k+s)-g_k(x)|
 \le\frac{4\eta B^{-k-1}}{e^s v_k}
 \le\frac{4\eta e}{\sqrt B}\le\frac{12}{\sqrt B}. \tag{3.2}
\]

For \(k=m\), the density is constant on the interval and the error is actually zero. For \(k=0\), the whole density has period \(B^{-1}\) on \([0,1]\) and mean one, so the same period-removal estimate applies. Thus (3.2) holds for all endpoints used below, with \(\varepsilon=12/\sqrt B\).

Apply (2.1) to each disjoint interval \([u_k,u_{k-1}]\), of length \(\log B>2\). For every \(x\in E\),

\[
 \int_{u_m}^{u_0}[L A_x(u)]_+du
 \ge\frac1{2\log B}\sum_{k=1}^m|g_k(x)-g_{k-1}(x)|
      -\frac{48m}{\sqrt B}. \tag{3.3}
\]

All spatial endpoints stay inside \([0,1]\) on this volume window, so the continuous arrival charge over \(E\) and this window is at least \((1-\eta)\) times (3.3).

## 4. Exact shared-source variation and the divergent lower bound

Write

\[
 p_m=2^{-(m-1)}\binom{m-1}{(m-1)/2}.
\]

For every \(k\), conditioning on the first \(k-1\) signs shows that the difference of the two next conditional majority values is twice the probability that the other \(m-1\) signs sum to zero. Monotonicity in the next sign means that the absolute increment equals one half of this difference. Averaging over the past therefore gives the exact identity

\[
 \int_0^1|g_k-g_{k-1}|dx=\eta p_m,
 \qquad
 \int_0^1\sum_{k=1}^m|g_k-g_{k-1}|dx=\eta m p_m. \tag{4.1}
\]

Each individual increment is at most \(\eta\). Consequently, by (3.1), removing \([0,1]\setminus E\) costs at most \(12\eta m(m+1)/\sqrt B\). Integrating (3.3) proves the finite, explicit lower bound

\[
 Q_{+,m}^{\rm ac}([0,1];[v_m,v_0])\ge L_m(B):=
 (1-\eta)\left[
 \frac{\eta m p_m}{2\log B}
 -\frac{6\eta m(m+1)}{\sqrt B\log B}
 -\frac{48m}{\sqrt B}\right]. \tag{4.2}
\]

The left side integrates all receivers in \([0,1]\), so it dominates the lower bound from \(E\). It is unnecessary to assume that the bracket is positive for the first few small \(m\).

As a separate calibration, \(\|f_m\|_2^2=1+\eta^2=5/4\). The already proved full-scale spectral lemma from [Round 57](../centered_cube_round057_20261011/proof.tex.txt) therefore bounds the true signed square energy by \((5/4)\kappa_1\), independently of \(m\). Expanding rather than shrinking the scale gives the same full-time integral by translation. This reused spectral bound is not needed to prove the positive-charge obstruction. The continuous charge above is explicitly an arrival analogue; no unproved full-scale continuous arrival identity with vanishing small-scale endpoint is asserted.

Choose \(B=2m^{12}\). If \(m=2l+1\), the elementary induction

\[
 \frac{\binom{2l}{l}}{4^l}\ge\frac1{2\sqrt l}
 \quad(l\ge1)
\]

starts at \(l=1\); its induction step uses
\((2l+1)/(2l+2)\ge\sqrt{l/(l+1)}\), whose squared form reduces to \(1\ge0\). Thus \(p_m\ge1/\sqrt{2m}\). The positive main term in (4.2) is at least a fixed positive multiple of \(\sqrt m/\log m\), while both error terms tend to zero. In particular,

\[
 L_m(2m^{12})\longrightarrow\infty.
\]

This is an actual source with one total mass budget, not a receiver-dependent resampling. Moreover, throughout the window,

\[
 F_x(ev)\le(1+\eta)e B^{-1/2}<1/2
\]

for the stated \(B=2m^{12}\), \(m\ge3\). Every charged scale is therefore strictly below the majority threshold, even when the enlarged cube is used.

## 5. Passing to finite atoms without changing their true good set

Fix \(m\) first. For \(N\) a multiple of \(2B^m\), let \(h=1/N\), let \(I_i=[(i-1)h,ih]\), put \(y_i=(i-1/2)h\), and define

\[
 \mu_N=\sum_{i=1}^N p_i\delta_{y_i},\qquad p_i=\int_{I_i}f_m(y)dy.
\]

The discontinuities of \(f_m\) align with this grid, and \(p_i\) equals either \(h/2\) or \(3h/2\). Thus all weights are positive and the total mass is exactly one.

Let

\[
 E_h=\{x\in[0,1]:\operatorname{dist}(x,(\mathbb Z+1/2)h)\ge h/4\}.
\]

This set occupies one half of every grid cell. For the ORIGINAL atomic maximal function at threshold \(H=3\),

\[
 E_h\subset G_N:=\{M\mu_N\le3\}. \tag{5.1}
\]

Indeed, an interval capturing just one atom has length at least \(h/2\), and its mass is at most \(3h/2\), so its average is at most three. An interval capturing \(k\ge2\) atoms has length at least \((k-1)h\), and its mass is at most \(3kh/2\); its average is at most \(3k/[2(k-1)]\le3\). Empty intervals have average zero. This proves (5.1) at every radius, including closed endpoint captures.

Let \(a=v_m>0\), \(b=v_0\), and define the restricted atomic receiver charge

\[
 q_N(x)=\sum_{j:\ a\le v_j\le b}
 \frac{\delta_j[\Gamma_{N,x}(v_j)]_+}{v_j^2}.
\]

Let \(q(x)\) be the continuous arrival integral over the same volume window. Then

\[
 \sup_{x\in[0,1]}|q_N(x)-q(x)|\longrightarrow0. \tag{5.2}
\]

Here is a direct justification, retaining the atomic open endpoints. The atomic and continuous cumulative distribution functions differ uniformly by at most \((3/2)h\). Their interval masses differ by at most \(3h\). At a source arrival in dimension one, a tie group contains at most two atoms, so replacing the open/closed endpoint pair by twice the continuous interval mass incurs at most another \(3h\). Thus \(\Gamma_{N,x}(v)\) converges uniformly to the continuous \(\Gamma_x(v)\) on the fixed compact volume window, also at the scaled open endpoints. Constants may depend on \(a,b\), which are fixed during this limit.

Replace \(\Gamma_N\) in the sum by \(\Gamma\). The error is bounded by \(O(h)a^{-2}\sum_i p_i=O(h)a^{-2}\). The remaining sum is the source-cell quadrature for

\[
 K(x,y)=\frac{[\Gamma_x(2|x-y|)]_+}{(2|x-y|)^2}
 1_{\{a\le2|x-y|\le b\}}.
\]

Away from its two distance cutoffs, this kernel is uniformly Lipschitz in \(y\), uniformly in \(x\in[0,1]\), because a bounded density gives a Lipschitz interval-mass function and \(2|x-y|\ge a\). At most a fixed number of source cells intersect the cutoff points \(y=x\pm a/2,x\pm b/2\); their total mass is \(O(h)\) and the kernel is bounded. Cellwise comparison proves (5.2). The same kernel argument shows that \(q\) is continuous in \(x\) (moving cutoffs affect source mass by \(O(|\Delta x|)\)).

For every continuous \(q\) on \([0,1]\), cellwise uniform continuity gives

\[
 \int_{E_h}q(x)dx\longrightarrow\frac12\int_0^1q(x)dx.
\]

Together with (5.1)--(5.2), this yields

\[
 \liminf_{N\to\infty}Q_+(\mu_N;G_N)
 \ge\frac12 Q_{+,m}^{\rm ac}([0,1];[a,b])
 \ge\frac12L_m(B). \tag{5.3}
\]

For sufficiently large \(N\), all the restricted scales have enlarged captured mass below \(1/2\), because \(F_{N,x}(ev)\le(3/2)eb+3h\). They capture at least two atoms in their enlarged interval, since \(a>0\), every source cell is occupied, and \(x\in[0,1]\). Hence (5.3) remains valid when the positive charge is restricted to the genuine multisource submajority branch.

Choose successively an odd \(m\) and a finite sufficiently large \(N\), rather than interchanging the two limits. Since \(H=3\) and \(W=1\) are fixed,

\[
 \sup_{\substack{\mu\text{ finite positive atomic}\\ W=1}}
 \frac{Q_+(\mu;\{M\mu\le3\})}{3}=\infty.
\]

Thus no source-uniform dimension-only bound for this bare positive arrival-curvature charge is possible. Its signed counterpart remains a viable object: this proof specifically shows that taking the positive part loses affordable cancellation.

## 6. Skills and audit boundaries

Current E03, N04, M04, and I02 entrances, method files, cube interfaces, and provenance status sections were re-read for this round. E03 requires an actual node mass flow and a checked terminal term; neither arbitrary cube histories nor receiver-dependent splits are freely identified with its Bellman tree. N04 requires uniform error partial sums; here the finite error sums are explicitly displayed in (4.2). M04's general selection theorems are not assumed: every sign pattern and every exceptional set is explicitly finite and Borel. I02 does not supply a universal cube compensator: the auxiliary \(g_k\) are finite conditional averages of independent source digits, and their approximation to true cube averages is separately proved in (3.2). The F05 method/interface was also rechecked for the separately reused Round 57 spectral calibration. No external theorem or source constant from these skills is used in the new obstruction.

The executable finite checks below support algebra and the proposed mechanism; the proofs above establish the asymptotic claim and the transfer to arbitrary large finite atom sets. Numerical refinement is not outward-rounded interval certification.

## 7. Executable guard

Run the following Python block using the bundled Python runtime. Stages 1--4 use only the standard library and exact rational or high-precision Decimal arithmetic. Stage 5 uses NumPy and probes a denser, ordinary binary version to avoid constructing the enormous separated-scale asymptotic examples. This last stage is deliberately a deterministic discretization diagnostic, not a numerical proof of the theorem.

```python
from fractions import Fraction as F
from math import comb
from decimal import Decimal, localcontext

# Stage 1: finite conditional averages, no martingale theorem invoked.
variation_checks = 0
for m in range(1, 18, 2):
    def avg(k, s):
        rem = m-k
        return sum(F(comb(rem, a), 2**rem) *
                   (1 if s+2*a-rem > 0 else -1)
                   for a in range(rem+1))
    pm = F(comb(m-1, (m-1)//2), 2**(m-1))
    total = F(0)
    for k in range(1, m+1):
        variation = F(0)
        for a in range(k):
            s = 2*a-(k-1)
            parent = avg(k-1, s)
            plus, minus = avg(k, s+1), avg(k, s-1)
            assert parent == (plus+minus)/2
            variation += F(comb(k-1, a), 2**(k-1)) * (
                abs(plus-parent)+abs(minus-parent))/2
            variation_checks += 1
        assert variation == pm
        total += variation
    assert total == m*pm
print('stage1 exact conditional-variation checks:', variation_checks)

# Stage 2: all interior coefficients of the second difference cancel.
curvature_checks = 0
ell = F(5)
for seed in range(200):
    values = {j: F(((seed+11)*(j+3)**2+7*j) % 37, 19)
              for j in range(-1, 6)}
    curv = [2*values[j]-values[j-1]-values[j+1] for j in range(5)]
    J = sum(curv)
    I = sum((F(j)+F(1,2))*curv[j] for j in range(5))
    assert J == -values[-1]+values[0]+values[4]-values[5]
    assert I == -F(1,2)*(values[-1]+values[0]) + \
                  F(11,2)*values[4]-F(9,2)*values[5]
    alpha = (values[-1]+values[0])/2
    beta = (values[4]+values[5])/2
    eps = max(abs(values[-1]-alpha), abs(values[0]-alpha),
              abs(values[4]-beta), abs(values[5]-beta))
    P = sum(max(z, F(0)) for z in curv)
    assert P >= abs(beta-alpha)/(2*ell)-4*eps
    curvature_checks += 1
print('stage2 exact endpoint/curvature checks:', curvature_checks)

# Stage 3: actual atomic cap at every possible maximizing arrival radius.
cap_checks = 0
for N in (2, 4, 8, 16, 32, 64):
    h = F(1, N)
    sites = [(F(i)+F(1,2))*h for i in range(N)]
    weights = [h*F(1 if (i.bit_count()%2) == 0 else 3, 2)
               for i in range(N)]
    assert sum(weights) == 1
    receivers = sorted({(F(i)+t)*h for i in range(N)
                        for t in (F(0), F(1,4), F(3,4), F(1))})
    for x in receivers:
        groups = {}
        for y,p in zip(sites, weights):
            v = 2*abs(x-y)
            assert v >= h/2
            groups[v] = groups.get(v, F(0))+p
        mass = F(0)
        for v,p in sorted(groups.items()):
            mass += p
            assert mass/v <= 3
            cap_checks += 1
print('stage3 exact original-cap arrival checks:', cap_checks)

# Stage 4: two precisions for the finite lower-bound formula.
def lower(m, prec):
    with localcontext() as ctx:
        ctx.prec = prec
        B = Decimal(2*m**12)
        pm = Decimal(comb(m-1,(m-1)//2))/Decimal(2**(m-1))
        assert pm >= 1/(Decimal(2*m).sqrt())
        eta = Decimal('0.5')
        L = (1-eta)*(eta*m*pm/(2*B.ln()) -
             6*eta*m*(m+1)/(B.sqrt()*B.ln())-48*m/B.sqrt())
        assert Decimal('1.5')*Decimal(1).exp()/B.sqrt() < Decimal('0.5')
        return +L
rows = []
max_refinement = Decimal(0)
for m in (9,33,129,513,2049,8193,32769):
    a,b = lower(m,80),lower(m,140)
    difference = abs(a-b)
    max_refinement = max(max_refinement,difference)
    assert difference < Decimal('1e-70')
    assert b > 0
    rows.append((m,str(b)[:22]))
print('stage4 lower-bound rows:', rows)
print('stage4 max Decimal refinement:', max_refinement)

# Stage 5: actual e-step continuous profile, deterministic spatial/time grids.
# NumPy is supplied by the bundled Codex Python runtime.
import numpy as np
pressure = []
for m in (4,8,12,16,20):
    n = 2**m
    ix = np.arange(n,dtype=np.uint32)
    signs = np.zeros(n,dtype=np.int16)
    for j in range(m):
        signs += 2*((ix>>j)&1).astype(np.int16)-1
    f = 1+0.5*np.sign(signs)
    cdf = np.r_[0.,np.cumsum(f)/n]
    def C(t):
        t = np.asarray(t)
        z = np.clip(t,0,1)*n
        index = np.minimum(z.astype(np.int64),n-1)
        return np.where(t<=0,0,np.where(t>=1,1,
                        cdf[index]+(z-index)*f[index]/n))
    def density(t):
        index = np.clip((t*n).astype(np.int64),0,n-1)
        return np.where((t>0)&(t<1),f[index],0)
    results=[]
    for nx,du in ((257,0.025),(513,0.0125)):
        x=0.25+(0.5/nx)*(np.arange(nx)+0.5)
        us=np.arange(-m*np.log(2),np.log(0.125),du)
        Q,E=0.,0.
        for u in us:
            v=np.exp(u+du/2)
            def mass(w):
                return C(x+w/2)-C(x-w/2)
            mv=mass(v)
            Gamma=2*mv-np.exp(-1)*mass(np.e*v)-np.e*mass(v/np.e)
            arrival_rate=(density(x+v/2)+density(x-v/2))/2
            Q+=(0.5/nx)*np.sum(arrival_rate*np.maximum(Gamma,0)/v)*du
            D=(np.exp(-1)*mass(np.e*v)-mv)/v
            E+=(0.5/nx)*np.sum(D*D)*du
        assert Q>=0 and E>=0
        results.append((float(Q),float(E)))
    pressure.append((m,results))
print('stage5 deterministic profile pressure:',pressure)
print('PASS (finite checks; no interval-arithmetic assertion)')
```

Actual replay passed all five stages: 525 exact conditional-variation checks; 200 exact endpoint/curvature checks; 15,141 exact original-cap arrival checks; seven 80/140-digit lower-bound comparisons, with maximum refinement difference \(3.043\cdot10^{-81}\). The rigorous lower formula gives approximately 0.011074 at \(m=9\), 0.029904 at \(m=513\), and 0.143906 at \(m=32769\). Its divergence is proved analytically above, not inferred from these values.

The deterministic binary pressure gave fine-grid \((Q_+,E)\) values approximately (0.025233, 0.009749), (0.148889, 0.038019), (0.226101, 0.050462), (0.295324, 0.060210), and (0.390446, 0.071392) for depths 4, 8, 12, 16, and 20. Spatial aliasing is visible in some coarse/fine comparisons, so these probes are recorded only as pressure evidence. The separated-scale source proof and its finite-atom transfer carry the theorem.


# Round 66: paid block diagonals and a logarithmic obstruction to positive target budgets

The general target energy remains unbounded by the required subpower budget. This note proves a height-free diagonal payment for EVERY CZ block of EVERY finite positive source, then refutes a natural positive cross-block payment on the exact targets of that construction. It also identifies the signed cancellation that a valid general estimate must retain. The counterexample is used to disprove an interface, not to substitute a special-family upper bound for the general theorem.

## Current skill conditions

Current F05, G01 and G02 entry/method/cube-interface files were read. Their entry SHA256 values are F05 9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9, G01 a09c5ad3047b402a07c26651b8c79b42a46843228b48cc961956c76372bc0cd4, and G02 2d17a11f000d8016583ca4427a9a9099f5c37b9ec09286fb50d01c6aa848ec1d. F05 requires two actual absolute Schur margins; a PSD Gram diagonal bound is a different assertion. G01 requires an actual tree/measure/packing-to-embedding bridge, which is not supplied by disjoint spatial support. G02 requires its actual outer geometry and size, not a renamed ordinary cap. No external Carleson, outer-Lp, PDE or sparse theorem is invoked. All new bounds below are proved directly. The retained sharp global L² theorem is used only to calibrate the counterexample's finite signed energy.

## 1. A new general height-free target trace payment

Use the actual Round65 construction: for α>1, λ=(α+1)^nH, maximal bad half-open dyadic cubes Q satisfy m_Q=μ(Q)>λℓ_Q^n, and F_Q=(m_Q/ℓ_Q^n)1_Q. Let G={Mμ≤H} be the ORIGINAL source good set, q=e^(1/n), c=1−e^(−1), u=n log L and D=A_{qL}−A_L. Put R=(α+1)/(α−1).

For every selected Q,
∫_G∫ |DF_Q|² du dx ≤ c R^n H m_Q.                 (BT)
Therefore the total block trace is ≤cR^nHW. This bound has no global target height, number of blocks, stopping depth, separation or minimum-mass factor.

Proof. For any y∈Q and x∈G, a centered cube of full side 2(||x−y||∞+ℓ_Q) contains all original μ mass in Q. Hence
H[2(||x−y||∞+ℓ_Q)]^n≥m_Q.
Writing t_Q=(m_Q/H)^(1/n)>(α+1)ℓ_Q gives
2||x−y||∞≥t_Q−2ℓ_Q≥t_Q/R.
Thus v_y(x)=(2||x−y||∞)^n≥m_Q/(HR^n) for ALL points y in the uniform target block. Jensen against normalized Lebesgue measure on Q and the exact one-source time identity ∫|d_L(x−y)|²du=c/v_y(x)² yield
∫_G∫|DF_Q|²
≤m_Q² avg_{y∈Q} c∫_{v_y≥m_Q/(HR^n)}v_y^(-2)dx
=cR^nHm_Q.
Here |{x:v_y(x)<s}|=s; Tonelli applies to the nonnegative integrands.

At α=2n²+1, R=(1+1/n²), so (BT) sums to ≤ceHW. Together with Round65's already-paid O(HW) FULL signed replacement error, this removes both individual block self-energies and replacement error as exponential costs.

For FINITE ATOMIC μ the residual density in Round65 is zero. Its target is a finite sum of uniform blocks, and the only unclosed target quantity is the complete signed cross-block energy. For a general finite positive Borel source, F also contains an unchanged residual f_0≤λ. The lemma pays every block but does not pay f_0's self-energy or its mixed terms; these remain additional parts of the target-energy problem. No atomic approximation or cap-set convergence is silently assumed.

## 2. The tempting positive-budget interface is false

For distinct blocks define the actual time-integrated cross interaction at a receiver:
J_{ij}(x)=∫_R DF_{Q_i}(x,u)DF_{Q_j}(x,u)du.
A possible attempt is to use original cap, disjoint blocks and distance from G to conclude
P:=Σ_{i≠j}∫_G (J_{ij}(x))_+dx ≤ C_nHW.           (FALSE)
The stronger absolute-in-time payment Σ_{i≠j}∫_G∫|DF_iDF_j| is also at least P. Both fail already at n=1 on exact CZ targets.

Let N=2^m≥8, h=1/N, H=2, α=3=2n²+1, and
μ_N=hΣ_{j=0}^{N−1}δ_{jh}, W=1, λ=8.
The exact maximal bad dyadic intervals are
Q_j=[jh,jh+h/16), F_j=16 1_{Q_j}, m_j=h.
At side h/8 the density is exactly 8 and the interval is NOT bad; its child of side h/16 has density 16>8. Dyadic intervals of side below h contain at most one atom; intervals of side at least h contain at most ℓ/h atoms and have density at most one. Consequently there is no larger bad ancestor and no missing selected block. Thus F_N=ΣF_j is the ACTUAL Round65 target, with density 16, disjoint blocks and mass one. Closed 3Q_j lies in the original atom hole described next.

The exact original bad set is
Ω_N=∪_{j=0}^{N−1}(jh−h/4,jh+h/4).               (G)
Indeed, for receiver radius r<h/2 at most one atom is captured, and its average exceeds 2 exactly when its distance is <h/4. For r≥h/2 the captured atom count is at most 2r/h+1, so the average is ≤1+h/(2r)≤2. Endpoints and equal-distance ties therefore cause no additional bad region. This calculation concerns μ_N, not a maximal function recomputed from F_N.

## 3. An exact logarithmic lower bound for the positive cross budget

The retained time kernel for capture lengths a≤b at n=1 is
J(a,b)=(1−1/(2e))/b²−1/(2ea²) if b≤ea,
and J(a,b)=−(e−1)²/(2eb²) if b≥ea.
It is positive exactly when b/a<sqrt(2e−1). This is used as an existing tool, not claimed as a new derivation.

Let k≥1, d=kh, j=i+k, and take
I_{ik}=[ih−2d,ih−d], 2k≤i≤N−1−k.
The interval lies inside the lattice range, and (G) gives |G∩I_{ik}|=d/2 exactly: each complete h-period has a good half. For every x∈I_{ik}, y∈Q_i and z∈Q_{i+k}, the capture lengths a=2(y−x), b=2(z−x) obey
1≤b/a≤2+1/(16k)≤33/16,
b≤49d/8.
In particular b<ea. Since e>8/3 (from its positive Taylor series),
1−[1+(33/16)²]/(2e)>1−1345/(512·8/3)=61/4096=:γ_0.
Consequently J(a,b)≥γ_0/b²≥64γ_0/(2401d²). This lower bound holds for EVERY pair of points in the two blocks. Averaging them with their uniform target densities gives
J_{i,i+k}(x)≥h²·64γ_0/(2401d²)>0 on I_{ik},
so
∫_G (J_{i,i+k})_+dx ≥ h·32γ_0/(2401k).
For k≤K=floor(N/6), there are N−3k≥N/2 permissible i. Counting both ordered orientations yields
P_N≥[61/307328]Σ_{k=1}^K1/k →∞.                (P)
Meanwhile HW=2, n=1, α=3 and global target density16 are all fixed. Thus the proposed dimension-only positive cross-block budget fails on the actual target subclass, even though its diagonal payment is affordable. No increase of threshold, hidden overlap assumption or atomic-to-density limit is involved.

## 4. What the full signed cancellation does in this counterexample

Write T_N=Σ_i∫_G∫|DF_i|², and N_N=Σ_{i≠j}∫_G(-J_{ij})_+dx. Then the exact target energy is
E_G(F_N)=T_N+P_N−N_N.
The general lemma gives T_N≤cRHW=4c. The separately retained global L² estimate and ||F_N||²_2=16 give E_G(F_N)≤16κ_1. Therefore
−4c≤P_N−N_N≤16κ_1,
N_N≥P_N−16κ_1.
Thus the negative cross budget also diverges logarithmically and cancels the positive one up to a constant. This is an actual signed aggregate statement about this counterexample, not an assertion of a general target upper bound.

There is also exact FULL-SPACE cross-block cancellation in this one-dimensional example: K_1(y−z)=0 for y≠z. Its distinct intervals have positive separation, permitting the off-diagonal Fubini bound, so ∫_{R}J_{ij}(x)dx=0. Restricting to original G transfers the signed cross interaction to the complementary bad holes, with opposite sign. This identity identifies where cancellation lies; it does not prove a uniform all-source obstacle payment, and K_n is not identically zero when n≥2.

## 5. Exact remaining general estimate

For a finite atomic source and its actual target, the trace is already paid by (BT). It remains to show
Σ_{Q≠Q'}∫_G∫ DF_Q DF_{Q'} ≤ A_n HW
with A_n subpower (ideally polylogarithmic). Both signs must be retained. The counterexample rules out replacing this quantity by P or by an absolute-in-time majorant. It does NOT refute an absolute Schur test on the already spatially integrated Gram entries |∫_G J_{QQ′}(x)dx|: taking that integral first may already retain spatial cancellations. It also does not refute signed operator factorizations or geometry-dependent grouping.

Disjoint dyadic source supports do not produce a receiver filtration: centered receiver cubes capture many unrelated dyadic blocks and arbitrary centers. The G01 single-tree packing embedding and G02 outer-size theorems therefore supply no unproved bridge. A formal Gram diagonal bound alone also cannot supply F05's uniform Schur or multiplier bound.

The stronger uniform target estimate over all α still approaches the original atomic energy difficulty as α→∞, because the already-proved signed approximation error tends to zero. This explains why dropping β by merely asserting a target-energy theorem is not progress. The concrete progress here is the paid height-free block trace and the exact exclusion of positive cross-budget interfaces; no complete general signed cross estimate or global low-height alternative is proved.

## 6. Reproducible exact guard

The standalone program below checks the actual maximal dyadic intervals, strict parent ties and original good masks for three thresholds H=2,4,8; exact capture ties for small grids; complete good-length fractions; and every capture-ratio/kernel lower bound used above on deterministic representative pairs through N=4096. It also checks the general trace proof's distance inequality at rational original-good boundary points for n=1,...,64, α=3/2 and α=2n²+1, with three block-density factors. Its q=e kernel lower certificate uses e>8/3 analytically, avoiding floating transcendental certification. Rational lower budgets are returned numerically only for compact display. No interval or general upper-bound claim is attached to the finite guard.

```python

from fractions import Fraction as F
from math import ceil,floor
import json

def closed_mass(x,r,N,h):
    lo=max(0,ceil((x-r)/h)); hi=min(N-1,floor((x+r)/h))
    return h*max(0,hi-lo+1)
def actual_good(x,N,h,H):
    return all(r and closed_mass(x,r,N,h)<=H*2*r
               for r in sorted({abs(x-j*h) for j in range(N)}))
def hole_good(x,N,h,H):
    return all(abs(x-j*h)>=h/(2*H) for j in range(N))
def halfopen_mass(a,b,N,h):
    lo=max(0,ceil(a/h)); hi=min(N-1,ceil(b/h)-1)
    return h*max(0,hi-lo+1)
def good_length(a,b,N,h,H):
    bad=F(0)
    for j in range(N):
        left=j*h-h/(2*H); right=j*h+h/(2*H)
        bad+=max(F(0),min(b,right)-max(a,left))
    return b-a-bad

def run():
    maximal_checks=0; mask_checks=0; ratio_checks=0; length_checks=0
    gamma=F(61,4096); e_lower=F(8,3); budgets=[]
    for N in (8,16,32,64,128,256,1024,4096):
        h=F(1,N); K=N//6
        harmonic=sum((F(1,k) for k in range(1,K+1)),F(0))
        conservative=F(61,307328)*harmonic
        counted=64*gamma/F(2401)*sum((F(N-3*k,N*k) for k in range(1,K+1)),F(0))
        assert counted>=conservative
        budgets.append({"N":N,"exact_lower_budget_float":float(conservative),
                        "counted_pair_lower_budget_float":float(counted)})
        for H in (F(2),F(4),F(8)):
            ell=h/(8*H); lam=4*H
            # All selected child intervals, exact λ parent ties, representative larger ancestors.
            for j in range(N):
                a=j*h
                assert halfopen_mass(a,a+ell,N,h)==h
                assert h/ell>lam and halfopen_mass(a,a+2*ell,N,h)/(2*ell)==lam
                maximal_checks+=2
                for L in (h/F(4),h/F(2),h,2*h,4*h,F(2)):
                    base=(a//L)*L
                    assert halfopen_mass(base,base+L,N,h)<=lam*L
                    maximal_checks+=1
            js=range(N) if N<=32 else (0,1,N//2,N-2,N-1)
            for j in js:
                for offset in (F(-1,4),F(0),F(1,8),F(1,4),F(3,8),F(1,2),F(3,4)):
                    x=(j+offset)*h
                    # Full actual maximal finite capture check, including distance ties.
                    assert actual_good(x,N,h,H)==hole_good(x,N,h,H)
                    mask_checks+=1
            ks=sorted({1,2,K,max(1,K//2)} & set(range(1,K+1)))
            for k in ks:
                d=k*h
                for i in sorted({2*k,N-1-k,(2*k+N-1-k)//2}):
                    if i<2*k or i>N-1-k: continue
                    left=i*h-2*d; right=i*h-d
                    assert good_length(left,right,N,h,H)==d*(1-1/H)
                    assert good_length(left,right,N,h,H)>=d/2
                    length_checks+=2
                    for x in (left,(left+right)/2,right):
                        for offy in (F(0),ell/2,ell):
                            for offz in (F(0),ell/2,ell):
                                a=2*(i*h+offy-x); b=2*((i+k)*h+offz-x)
                                assert a>0 and b>=a and b/a<=F(33,16)
                                assert b<=F(49,8)*d
                                # J is increasing in e on this branch, and actual e>8/3.
                                kernel_lower=(1-1/(2*e_lower))/b**2-1/(2*e_lower*a**2)
                                assert kernel_lower>=gamma/b**2>=64*gamma/(2401*d**2)
                                ratio_checks+=3
    trace_checks=0
    for n in range(1,65):
        for alpha in (F(3,2),F(2*n*n+1)):
            R=(alpha+1)/(alpha-1); lam=(alpha+1)**n
            for tau in (F(1)+F(1,8*n),F(3,2),F(2)):
                t=tau*(alpha+1); mass=t**n
                # μ=mass δ0; Q=[0,1)^n is its exact maximal bad cube.
                assert mass>lam and mass/2**n<=lam
                x=(t/2,)*n
                for pattern in ((F(0),)*n,(F(1),)*n,tuple(F(j%2) for j in range(n))):
                    dist=max(abs(x[j]-pattern[j]) for j in range(n))
                    assert (2*dist)**n>=mass/R**n
                    # Original receiver is a true cap boundary: Mμ(x)=1.
                    assert mass/(2*max(x))**n==1
                    trace_checks+=2
    return {"exact_maximal_and_parent_checks":maximal_checks,
            "exact_original_good_mask_checks":mask_checks,
            "exact_good_length_checks":length_checks,
            "exact_capture_ratio_kernel_checks":ratio_checks,
            "exact_general_trace_geometry_checks":trace_checks,
            "positive_budget_lower_bounds":budgets,
            "scope":"exact Fraction finite guard; analytic e>8/3; no interval or general energy claim"}
if __name__=="__main__": print(json.dumps(run(),sort_keys=True))
```

## Actual replay

The embedded standard-library program completed in approximately 5.4 seconds. All 134,976 dyadic maximal/parent checks, 1,701 exact original-good-mask comparisons, 468 exact good-length checks, 18,954 rational capture-ratio/kernel lower comparisons and 2,304 all-dimension trace-geometry checks passed. The displayed conservative positive-budget lower bounds increase from 0.0001984850 at N=8 to 0.0014098347 at N=4096. These numbers are deliberately conservative rational lower bounds, not numerically integrated target energies; the harmonic lower formula proves unboundedness independently of the finite replay.


# Round66: captured-mass bands and signed arrival curvature

The new measurements distinguish the entropy-sensitive positive arrival charge from actual signed cap energy. They also split the previously reported “early” energy into a paid single-source branch and the genuinely remaining residual. The tested grids do not exhibit large Qplus; this is specific to these inputs and gives no uniform estimate. The separately audited majority-digit construction in the main proof obstructs such a uniform Qplus budget.

## Actual quantities and implementation

Every stored source is a finite positive measure with exact rational positive weights and machine-float positions interpreted as exact binary rationals. Duplicate positions are merged. The source mass is W=1, the true cap is G={Mμ≤H}, and receiver integration uses full-space Lebesgue importance sampling. There is no receiver box or scale cutoff. For each receiver, write τ_i=(2||x−y_i||∞)^n/(W/H), a_i=p_i/W. Actual M/H is the maximum of cumulative mass/τ at the complete arrival batches.

With t=e^u/(W/H), the signed difference is C(t)/t in normalized units. Its event changes are +a_i/e at t=τ_i/e and −a_i at t=τ_i. Each interval contributes C²(t_left^−2−t_right^−2)/2, including the final infinite interval. This evaluates the signed square including all cross terms; it is not a diagonal surrogate.

The time-energy bands use the current mass m(t)/W: m=0 is separate; the positive bands are (2^−j,2^−(j−1)] for j≥1. Exact integer cumulative weights resolve dyadic boundaries, and enough bands are retained to cover the smallest actual source weight. Zero-length simultaneous event intervals contribute zero; the next interval uses the whole batch.

At distinct arrival volumes v_j with batch mass δ_j and cumulative mass F, the additional point quantities are

- P=Σ_j δ_j F(v_j)/v_j², with F(v_j) including the full tied batch;
- Γ_j=F(v_j)+F(v_j−)−e^−1F(ev_j)−eF((v_j/e)−);
- signed curvature attribution δ_jΓ_j/v_j²; their sum equals actual point energy;
- Qplus=Σ_j δ_j max(Γ_j,0)/v_j².

Per-source signed attribution divides each source's mean contribution by its own mass fraction. It can be negative and is not a probability or an individual source energy. On the heldout cases its normalized means range from −0.37031 to 3.09684; up to seven sources in a case have negative mean attribution. This is cancellation information, not a positive mass allocation.

The disjoint partition is E_single when the expanded cube Q_(u+1) contains at most one source atom; E_majority on its complement when current captured mass is at least 3W/4; E_residual otherwise. These add to total energy, without assigning all current-zero-mass or all pre-majority energy to the residual. Distinct-source counts, not mass or arrival-group counts, define the single branch.

## Sampling and uncertainty

The full proposal is half the global-scale source-center proposal (radial volume scale W/H) and half the individual-scale source-center proposal (scale p_i/H). Each first chooses source center with probability p_i/W, a uniform cube-cone face/sign/direction, and then half uniform radial volume inside its scale and half inverse-volume tail outside. For scale B, radial Lebesgue density is 1/(2B) for v≤B and B/(2v²) for v>B. All components are evaluated in the denominator, regardless of which generated the receiver. U=0 is replaced by the next positive machine float. The ideal continuous sampler has normalized full-space density; machine random numbers and arithmetic are not interval-certified continuum integration.

On true G, the mixture density is at least Σ_i p_i²/v_i²/(4HW). Thus the normalized energy score has envelope 4(1−e^−1)N. For the normalized P and Qplus scores the program uses the coarser envelopes 4/a_min and 8/a_min. The point inequalities E≤Qplus≤2P explain the latter comparison; the source-entropy charge bound and counterexamples are separate analytic work. These finite score envelopes give the formal, per-row Hoeffding radius B sqrt(log40/(2S)) for ideal independent draws. Energy radii on the heldout rows range from 0.8585 to 54.943 and are practically useless here. They are not simultaneous confidence bounds across all rows and do not include floating arithmetic error. Sample SE is reported as a variance diagnostic, not a certified confidence limit. Ratios and mass fractions are ratios of empirical means, without asserted ratio confidence intervals.

## Pilot, heldout scope, and findings

The 13-row pilot used 3,328 receivers. Its eight n=1 grids N=16,64,256,1024 at H=2,4 exposed increasing P with modest observed E. The four nested pilots and one shared-face pilot supplied geometry controls. They selected this focused heldout expansion; they were not included in the table below. Deep pilot charges before the exact-group correction were exploratory only; the final serialized pilot is recomputed with the corrected implementation.

The heldout set has 64 rows and 180,224 independent registered receiver draws. It contains eight grids with two seeds×4,096; four frozen Round65 geometries with two seeds×4,096; nested and unequal nested sources at n=1,4,16 and N=16,64, with two seeds×2,048; and shared-coordinate-face sources at n=2,4,8,16, N=16,64, with two seeds×2,048. Source count and dimension are varied independently. No new active total-energy search or exponent fit was performed. The four Round65 geometries retain their historical selection bias, but these receiver seeds are held out from their selection run.

For each grid below, the two seeds are combined by averaging their means; the displayed ± value is sqrt(SE₁²+SE₂²)/2, using independent draws of the same fixed source. All values are normalized by HW.

|N|H|E|P|Qplus|
|---:|---:|---:|---:|---:|
|16|2|0.67030 ±0.00755|1.56784 ±0.01797|0.75499 ±0.00849|
|64|2|0.65099 ±0.00764|1.86493 ±0.02297|0.75512 ±0.00885|
|256|2|0.65408 ±0.00766|2.18290 ±0.02789|0.76906 ±0.00901|
|1024|2|0.66461 ±0.00761|2.60149 ±0.03312|0.78568 ±0.00900|
|16|4|0.64062 ±0.00641|1.44312 ±0.01307|0.71648 ±0.00708|
|64|4|0.62687 ±0.00639|1.66881 ±0.01547|0.71828 ±0.00718|
|256|4|0.62767 ±0.00645|1.92905 ±0.01814|0.72472 ±0.00728|
|1024|4|0.63714 ±0.00641|2.22476 ±0.02068|0.73934 ±0.00726|

The increasing charge P agrees with the analytically established entropy obstruction for that proxy. It does not force entropy in the actual signed energy. For these grids roughly 71% of energy has current mass zero. Only about 3.6–7.3% of H=2 energy and 12.8–15.2% of H=4 energy comes from positive current mass ≤W/16. Including the zero band creates a large “tiny mass” fraction, but m(t)=0 does not constrain the expanded captured mass m(et). The expanded cube can already contain many atoms.

The residual partition is more informative than the old early/post-majority split:

|Frozen geometry|H|single fraction, two seeds|majority fraction|residual fraction|
|---|---:|---:|---:|---:|
|n1,N64 equally spaced control|1/4|0.0054,0.0048|0.3157,0.3166|0.6790,0.6786|
|n4,N16 perturbed candidate|0.0260893|0.4940,0.4974|0.0207,0.0225|0.4853,0.4801|
|n4,N16 original vertices, same H|0.0260893|0.7195,0.7239|0.0175,0.0152|0.2630,0.2609|
|n16,N64 selected candidate|3.5798e−10|0.8104,0.8088|about 0.00001|0.1896,0.1912|

Thus the n16 candidate's nearly all “early” energy from Round65 is mostly in the single branch; reporting it as entirely unpaid would be incorrect. The n4 perturbation changes the residual fraction substantially without a correspondingly established total-energy gain. Shared-coordinate-face sources have a different residual concentration: n16,N64 has residual fractions 0.9983 and 0.9961, while total means are 0.6400±0.0242 and 0.6136±0.0226. This pressures the structure of a residual proof, not its constant or its impossibility.

Equal and unequal deep clusters at N64 show no observed charge growth in these tests: P is about 0.51–0.58 and Qplus about 0.63–0.71. Their selected total energies have SE around 0.02. Across all heldout rows Qplus/E lies between 1.0064 and 1.1828. This favorable range is explicitly not general evidence for uniform Qplus control: the main analytic majority-digit counterexample tests a different failure mechanism absent from the uniform grids and these few clusters. Neither a large charge nor large cap energy is itself a weak maximal-function counterexample.

## Precision and finite guards

Very deep positions yield exact distinct machine-coordinate distances whose float logs coincide. Charges P and Qplus are discontinuous at some true arrival ties, whereas total event energy is continuous. The final implementation detects near log ties and computes actual L-infinity distances using shared-scale Python integers for exact binary input geometry, restoring physical order and whole arrival batches. It used this fallback on 26,739 accepted receiver rows and corrected 64,822 false log-tie boundaries. Genuine equal-distance groups are retained. Near log differences ±1 also trigger a Decimal100 scale-CDF fallback. Random draws triggered none; three deterministic near-e cases all triggered it and agreed with independent Decimal80/120 calculation. These local fallbacks are not a universal floating classification certificate.

The frozen output includes:

- six rational-volume algebra tests, each at Decimal80/120, with independently summed signed events, curvature identity, and pair Gram;
- one formal exact-e-endpoint test at both precisions, using integer exponent keys to enforce the upper closed CDF and lower strict CDF without inferring equality from rounded e;
- six actual receiver geometry guards: three near-e ratios, genuine open-region face ties, and two deep near-tie configurations;
- all three metric maxima from every heldout row: 192 actual receiver checks at both precisions, with O(N log N) event/curvature and full proposal density; 12 of these also use pair Gram, while N1024 never incurs unnecessary quadratic Gram checks;
- 128 closest accepted/rejected gate receiver checks, preserving exact machine coordinates and confirming both precision classifications.

The maximum actual extreme float relative error in energy/P/Qplus is 1.79e−14; full mixture-density relative error is 2.59e−15. Decimal80/120 extreme value changes are at most 2.99e−78 relative. Actual event/curvature identity residuals are at most 3.11e−78 at 80 digits. Float mass-band and disjoint-partition vectors agree with independent Decimal event integration to relative L1 errors 3.16e−14 and 3.13e−14. Across all sampled receivers the relative event/curvature discrepancy is 1.81e−14; weighted band/partition sum discrepancies are at most 3.56e−15. Minimum sampled |log(M/H)| is 6.80e−7, and all retained closest gates agree with Decimal80/120. These are finite nearest-rounded implementation diagnostics, not outward-rounded interval certificates, all-receiver gate guarantees, or proof of the Monte Carlo integral.

Current L01/L02/L03/H05 entries and applicable method/interface material were reread from disk. Their limitations remain: true common-source realizability matters; finite heuristic cases do not prove a global bound; Decimal agreement is not an outward interval library; concentration requires the actual independence and score envelope. No external source theorem was inferred from a provenance title. General results and counterexamples require the separate main proof.

## Reproduction and freeze

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round066_20261011/mass_band_probe.py
```

Python3.12.14, NumPy2.3.5; no installation was performed. The standalone program writes `results.json` beside itself, uses no previous-round imports, and serializes no runtime field. The final run took 8.85958 seconds locally for 77 rows/183,552 receivers plus the listed guards. The frozen script SHA256 is `0eb6954a2196a8459365a1787a06e3beedbb54bbb9acbc0245bd61af12208f1c`; JSON SHA256 is `239806923183bc33936cb598ba4c059fbae7b2fad7f0896da6b7cd4b860cf076`. The report is descriptive evidence; no numerical theorem, fitted exponent, or restricted-family upper result is claimed.


## General integration status

For finite positive atoms, Round65 pays the entire replacement error and
this round pays the replacement block trace. The remaining target task is
a source-uniform subpower upper bound on the SUM of signed cross-block
interactions on the original receiver set. For non-atomic sources, the
unchanged residual density also has unpaid self and mixed terms. The
atomic reduction must be invoked with its proved cap/limit hypotheses,
not by assuming a cap set survives arbitrary approximation.

Alternatively, the exact signed arrival-curvature formula gives a
source-sum representation of the same energy. Its pointwise positive part
cannot supply a general budget, even in the earlier unpaid region. The
majority-digit counterexample has ordinary signed continuous energy at
most (5/4)kappa_1. Its finite atoms also have bounded signed energy by the
Round65 dimension-one bound [sqrt(8 kappa_1)+sqrt(3(e+1))]^2 HW. Thus the
new counterexample concerns loss of signs, not growth of actual energy.

No source-dependent depth, minimum mass, finite-grid size or entropy may
be absorbed into a dimension-only constant. The next route must retain
enough aggregate cancellation, integrate spatially before imposing
positive bounds, or use a genuinely weaker stopped weak-type quantity.
The original weak theorem and its final all-scale return remain open.

## Independent replay receipt

```json
{
  "embedded": {
    "arrival_curvature": {
      "exit_code": 0,
      "guard_sha256": "42100637b0d30dd0913fe8fbf1fdc20f25aecf3a368db4f610ac6009bb872504",
      "runtime_seconds": 7.257364334000158,
      "source_sha256": "55194e9ee05ef5691e264a3e25e8117cbb351db3527205ee27a58f1c2dbf747c",
      "stderr": "",
      "stdout": "{\"exact_curvature_event_checks\": 173, \"exact_geometry_cases\": 1736, \"grid_lower_bounds\": [{\"N\": 16, \"exact_P_over_HW_lower\": \"25/384\"}, {\"N\": 32, \"exact_P_over_HW_lower\": \"761/8960\"}, {\"N\": 64, \"exact_P_over_HW_lower\": \"2436559/23063040\"}, {\"N\": 128, \"exact_P_over_HW_lower\": \"586061125622639/4620913692595200\"}, {\"N\": 256, \"exact_P_over_HW_lower\": \"623171679694215690971693339/4203615587921145840040396800\"}]}\n"
    },
    "early_budget": {
      "exit_code": 0,
      "guard_sha256": "3adb21f3c4ad62a2d321fe1f9e433078f705da56e883a48f309e394d9102ed9a",
      "runtime_seconds": 0.4154904580063885,
      "source_sha256": "e8012e39f81befb78fa277ec4298831a78f6a0467a4cea29efc850d5b74260ce",
      "stderr": "",
      "stdout": "stage1 exact conditional-variation checks: 525\nstage2 exact endpoint/curvature checks: 200\nstage3 exact original-cap arrival checks: 15141\nstage4 lower-bound rows: [(9, '0.01107399735989696090'), (33, '0.01353475513634097027'), (129, '0.01923332436293113307'), (513, '0.02990431584839388380'), (2049, '0.04897442488938853134'), (8193, '0.08295715411854126322'), (32769, '0.14390625735301963907')]\nstage4 max Decimal refinement: 3.042494416824273377089341987E-81\nstage5 deterministic profile pressure: [(4, [(0.025241387367992, 0.009748551548603646), (0.025232622782482568, 0.009748512563060604)]), (8, [(0.1489442204440032, 0.03801431433526219), (0.14888881898778686, 0.03801918575465259)]), (12, [(0.22965095840662508, 0.052466212633210725), (0.22610068360102392, 0.05046183025996901)]), (16, [(0.3139383660753364, 0.0629329222774582), (0.29532368769463146, 0.06021006124054792)]), (20, [(0.3936014137386221, 0.07669691855481331), (0.39044578604483593, 0.07139184009589944)])]\nPASS (finite checks; no interval-arithmetic assertion)\n"
    },
    "target_energy": {
      "exit_code": 0,
      "guard_sha256": "e8e2feb99b08f40842f7c60843f1fe54c038daa8f0f7652bd15de694a8dbb33c",
      "runtime_seconds": 5.619995874993037,
      "source_sha256": "e50dd2d3b73a1e9d34a8362edc7e9d0fefa0ede8f83999942528279065661b66",
      "stderr": "",
      "stdout": "{\"exact_capture_ratio_kernel_checks\": 18954, \"exact_general_trace_geometry_checks\": 2304, \"exact_good_length_checks\": 468, \"exact_maximal_and_parent_checks\": 134976, \"exact_original_good_mask_checks\": 1701, \"positive_budget_lower_bounds\": [{\"N\": 8, \"counted_pair_lower_budget_float\": 0.00024810625780924617, \"exact_lower_budget_float\": 0.00019848500624739692}, {\"N\": 16, \"counted_pair_lower_budget_float\": 0.00044659126405664307, \"exact_lower_budget_float\": 0.0002977275093710954}, {\"N\": 32, \"counted_pair_lower_budget_float\": 0.000720335168506178, \"exact_lower_budget_float\": 0.0004532074309315563}, {\"N\": 64, \"counted_pair_lower_budget_float\": 0.0009766328710176977, \"exact_lower_budget_float\": 0.0005813562821873162}, {\"N\": 128, \"counted_pair_lower_budget_float\": 0.0012517144125528848, \"exact_lower_budget_float\": 0.0007235490452888331}, {\"N\": 256, \"counted_pair_lower_budget_float\": 0.001522203467992169, \"exact_lower_budget_float\": 0.0008587935730084753}, {\"N\": 1024, \"counted_pair_lower_budget_float\": 0.0020713520194416846, \"exact_lower_budget_float\": 0.0011345308468167137}, {\"N\": 4096, \"counted_pair_lower_budget_float\": 0.002621378203888591, \"exact_lower_budget_float\": 0.0014098346885610372}], \"scope\": \"exact Fraction finite guard; analytic e>8/3; no interval or general energy claim\"}\n"
    }
  },
  "frozen_hashes": {
    "arrival_curvature.md": "55194e9ee05ef5691e264a3e25e8117cbb351db3527205ee27a58f1c2dbf747c",
    "arrival_curvature.tex.txt": "aeb44d131bbdc326a624493a9eb46089af557de38f664492ef66e858531b9d55",
    "early_budget.md": "e8012e39f81befb78fa277ec4298831a78f6a0467a4cea29efc850d5b74260ce",
    "early_budget.tex.txt": "079884bb78793a503c5f1d48121e10be9334bf09aff9cae5896f75285c67e14c",
    "mass_band_probe.py": "0eb6954a2196a8459365a1787a06e3beedbb54bbb9acbc0245bd61af12208f1c",
    "numeric_report.md": "93ed0c386da5be2e0f235e025dc092eeac432efa3a257b753cf07f970b9c2140",
    "results.json": "239806923183bc33936cb598ba4c059fbae7b2fad7f0896da6b7cd4b860cf076",
    "target_energy.md": "e50dd2d3b73a1e9d34a8362edc7e9d0fefa0ede8f83999942528279065661b66",
    "target_energy.tex.txt": "a62ed3af1f6cd844c03659506b7fd201d82a65dba365d1cc1ea69476b09e6145"
  },
  "main": {
    "exit_code": 0,
    "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round066-main-replay-mujycluu",
    "result_byte_identical": true,
    "runtime_seconds": 8.872204708000936,
    "stderr": ""
  },
  "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round066-replay-t3ia9yz9",
  "skill_reload": {
    "changed_since_round65": 0,
    "direct_references": 437,
    "entries": 64,
    "manifest_sha256": "089bbbec94e84385b991d907cca6bf15affee3c7556694c3e1e021a4b9f4f4b5",
    "missing": 0,
    "shared_ledger_resolver_checks_passed": 2
  }
}
```
