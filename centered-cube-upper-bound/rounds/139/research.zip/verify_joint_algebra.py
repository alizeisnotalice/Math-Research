from fractions import Fraction as F
from pathlib import Path
import json
rows=json.loads(Path(__file__).with_name('joint_algebra_checks.json').read_text())['cases']
for row in rows:
 a,b,e,w=map(F,row['parameters']);m=a*e/(a*w+2*b*e);B=a*a/(4*e*(a*w+b*e))
 assert str(m)==row['peak'] and str(B)==row['bound']
 for r in [F(0),m/2,m,2*m,a/b]:
  if r<=a/b:
   assert B-r*(a-b*r)/(e+w*r)**2==(a*e-(a*w+2*b*e)*r)**2/(4*e*(a*w+b*e)*(e+w*r)**2)
print('PASS',len(rows),'exact rational algebra cases; no traffic certification')
