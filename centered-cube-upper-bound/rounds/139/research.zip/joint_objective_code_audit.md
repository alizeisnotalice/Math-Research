# R139 六来源联合正目标代码独审

审计范围仅为冻结保存系数下的有限目标及 `joint_objective_probe.py` 实现，不认证FULL、原实际dx体积、连续来源、一般根阶或全局最优。本次未运行完整producer，未重新计算φ/C核，未计算新的F时间积分；仅实读代码、输入、已有输出及所用tanh-sinh实现，并做有理代数/FA端点的只读核验。只写本文件，不修改producer及其他作者稿。

绑定producer SHA256：`a6f1235f1f22efe44975129b5a15ea098bd3e1e72356fb830aa6cf1d0cc2ddec`。

输入R136 `active_traffic_v2.json` SHA256：`1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`；R138 `core_capacity_probe.json` SHA256：`268bd6ca487de9111dec63085c81c9bfd2fc5eb8aa760483dd000581eae6900d`。两输入与producer硬编码预期值及R138来源合同一致。

## JCA1. 目标、共同参数与质量量词

固定每例的六来源位置、保存T,p,K,D,B_FA,A_i,J_i,K0_i,Q_i、阈值、terminal good/bad、各score开段c_i,k_i。四个eps质量固定，f₀=1−Σ四eps；第五far质量为f₀−m，第六CORE质量为m。m是整份有限ν(m)的同一个共同参数，不能只改变外hard质量而冻结内来源后验或α。

准确目标为

\[
F(m)=\frac{pm}{q(m)}\sum_{v\ good,u\ bad}
\rho_v(m)\nu_v(m)\nu_u(m)\Psi_{vu}
\int_\tau^h\delta_{vu}(t)\chi_{FA}(t,v,u)
\frac{w_v(t)w_u(t)}{e_t(m)^2}\frac{dt}{t},
\quad e_t(m)=\sum_i\nu_i(m)w_i(t).
\]

原R=1、冻结hard支持只有CORE，所以外hard因子是pm/q，不存在额外R⁻ⁿ体积或额外来源后验。内两份Π各提供ν_iw_i/e_t，故总分母必须e_t²；ρ在固定m下不随t变化。Ψ定义是未归一化signed score后缀的正max，与m、ν及e_t无关；FA也只用固定p,Q,c,k与δ，不由新ρ或q重选。

q(m)=max(Q₀,Q_J,Q*)，α(m)=[Dq(m)−U_total(m)]/Q_J(m)，原good上的ρ=[1−(U_v+αJ_v)/(TA_v)]₊。使用U_v的写法与实际正good余量一致：这些来源U_v=min(TA_v,DK_v)，若U_v=TA_v则ρ恒0；若ρ可能正则U_v=DK_v。CORE确是U=TA零ρ支，不应因其存活后验或δ/FA资格制造正交通。

本模型以冻结120位保存decimal为精确有理系数来定义新的有限目标；不把这些保存值升级成原超越核的区间证书。A=0及非good行置ρ=0。有效质量要求m>0、f₀−m>0，并保留high、heavy、hard帽、q>0、α≥0与至少一正good ρ。边界仍可记录诊断F，但不因此进入合格峰。

## JCA2. 输入系数、α与质量门实现

`state(m)`逐m用Fraction重建q,Q_J,e_g,U_total、α、六个ν和ρ；未复用旧ρ，也未把原参考m的q/α当常数。独立对全部12例核验以下精确有理身份均通过：

- 六atom固定顺序为G1,G2,G3,G4,B,CORE，前四ν不变，总ν严格为1。
- R138 rebuilt_U恰等于1_E min(TA,DK0)，包括CORE重建值与旧显示舍入值的差异。
- 保存Q₀、Q_J、Q*、e_g、U_total的每个slope/intercept分别恰等于Σν_i(m)K0_i、Σν_i(m)J_i、Σν_i(m)Q_i、Σν_i(m)wg_i、Σν_i(m)U_i展开所得仿射系数。
- 每个good来源确为U=DK0或U=TA的上述两个分支；各例Q_J>0，来源正权使有效行e_t>0。
- 六保存位置中只有CORE满足原R=1的closed hard盒，支持特定λ_support=DK0_CORE−U_CORE>0合法。

gate精确用high p e_g≥2Kq、strict heavy e_g>Wq、hard m≤4q、strict两质量正、q>0、α≥0和positive_good_rho。sup是否可取由这些实际不等式判断，未以数值接近sup代替strict gate。gate计算是有理数判断，mp仅输出显示值。当前菜单的正good端有保存正δ/FA/Ψ witness，因此positive_good_rho不会在本输入误收一个完全零时交通端。

Γ_support保留Q_J/q及R=1，只对冻结单点hard支持使用；αQ_J≥λ_support m和实际mρ/q≤Γ逐massert。旧λ₀=0保留不适用，未以CORE的单点w_h冒充box inf。本项诊断不改变F的掩码，不宣称每个采样都进入一般HM3均匀小Γ支。

## JCA3. score、后缀Ψ、FA根及端点

全部12例score段连续覆盖保存[τ,h]，c_i>0。开段中点判据α_i²<lo·hi等价α_i<√(lo hi)，准确恢复strict k_t=#(α_i<t)，包括重复阈值；阈值时刻本身对dt/t积分是零测集，不影响此有限目标。

代码对每个pair、每段令N=k_v+k_u、d=k_v−k_u，重建signed增量

\[
d c_vc_u\frac{lo^{-N}-hi^{-N}}{N}
\]

并向后累加，包含终端suffix(h)=0。N=0时必d=0，primitive置0正确。每段suffix导数符号固定，故max由断点达到；max(suffix)>0是准确Ψ。不能只看瞬时δ>0，亦不能把此后缀改成含e_t⁻²的版本。独立核12×36=432个pair的Ψ全与保存值一致，所有原suffix_ambiguous均为false。

正δ段必k_v>0，FA严格不等式

\[
Q_v/(p w_v)<B_{FA}\delta
\iff t^{k_v}<B_{FA}\delta p c_v/Q_v=:K_{FA}
\]

给正根t*=K_FA^(1/k_v)。`prepare`用Fraction幂比较先判K_FA≤lo^kv时空、K_FA≥hi^kv时整段，否则按当前90/120精度取根并cut；每个切段mid<cap正确选active。端点等号排除只影响零测集；未额外乘t或漏掉dt/t。

独立只读核了所有eligible正δ的46个保存段：无缺段，FA active全部一致；重建FA根与旧记录最大相对差约4.7081481×10⁻¹²⁰；裁剪后的lo/hi与旧active区间最大相对差约6.6625226×10⁻¹²¹。当前保存输入未发现FA错误。

**协议预检缺口：** producer的`prepare`只按准确公式重建FA，并没有主动assert与旧保存FA区间一致；协议承诺的“比对失败停止该例”并未在producer自动执行。上述独立核验补足了当前冻结输入的实质比对，但不能说该自动失败机制已实现。Ψ旧值则确有assert。此差别不改变本批F公式；未来换输入需重新比对，不能沿用本次PASS。

## JCA4. e_t重算、log变量、共用指数与tanh-sinh累加

在每个m上六ν重新传入`kernel_vector`；其coef[k]=Σ_{i:k_i=k}ν_i c_i，因此每个时间节点x=log t都有

\[
e_t(m)=\sum_k coef[k]e^{-kx}.
\]

节点powers可以跨m缓存，因为只依piece、精度及固定k；coef、e_t及分母不能缓存成旧m值，代码未这样做。`kernel_vector`实际求共同指数积分

\[
I_N(m)=\int_{\log lo}^{\log hi}
\frac{e^{-Nx}}{[\sum_k coef[k]e^{-kx}]^2}dx,
\]

恰是∫t⁻ᴺ/e_t² dt/t。聚合相同N仅共用这个核积分，pair coefficient δ c_vc_u和当前ν_vν_uρ_v仍在`evaluate`逐pair分配；没有丢失两个后验分母或来源质量。

中点归一norm_N=e^(−N x_mid)/e_mid²为当前m上的正数，只是改善规模；求积integrand除norm，返回值再乘norm，数学式不变。没有把e_mid当整个时段分母。

实读本机vendor `mpmath/calculus/quadrature.py` 的TanhSinh：`get_nodes(a,b,degree,prec)`已经把节点和权重变换到目标有限log区间；degree1含零节点和初始整网格，之后degree仅给新增交错节点。库的sum_next等价

\[
S_d=\tfrac12S_{d-1}+2^{-d}\sum_{new\ nodes}w f(x).
\]

代码`prev/2+h*fsum(...)`与其完全一致，degree1从0起；既没有重复全部旧节点，也没有漏掉旧半权。get_nodes的区间Jacobian已在w中，不需再乘(loghi−loglo)/2。度数与dps包含在nodes缓存key；Ns也在key，prepared piece按dps隔离，90/120不复用低精度根或权重。

degree3起以相邻层相对change作为收敛启发，maxdegree9后保留warning，不能把target 10⁻⁷⁰/10⁻¹⁰⁰解释为已证明积分误差。90/120复核也是数值一致性证据，非区间证书；归一化不改变这一限制。

## JCA5. 目标合成、峰搜索与当前输出证据

`evaluate`对每pair累计ρ_v ν_v ν_u δ c_vc_u I_N，S为36pair总和，F=(pm/q)S。仅原good/bad、Ψ、正δ和FA资格进入piece，zero ρ/ν支不计算核积分，不制造CORE正ρ。非eligible质量可输出诊断但`ranked`与稳定峰只选择eligible且F>0点；严格sup不能被当合格点。32个90位硬预算、候选至多3个120位复核及未探测区间标记均属于有限采样，不构成全局最优或上界。

近似并列的标记与协议未完全对齐：局部峰筛选用了10⁻⁵⁰容差，但最终ranked/稳定峰排序按数值严格大小，代码没有输出该容差的并列诊断。需要如实后处理标记，而不能称已认证唯一最优；这一报告缺口不改变每点F。

本次所读既有输出 `joint_objective_probe.json` SHA256为 `302321823f8b7ef6df3cff2ac6b9ad3ec3b3be0dc5ffe509602a4ca0643df27d`。保存12例均无exception，36个已保存120位复核全部报告passed；所有保存采样和复核quadrature_warning_count均为0。这只是对既有账本状态的核验，本审计没有重新运行目标积分，亦不把输出passed标记升级为独立误差证书。

## JCA6. 冻结结论

**有限目标实现通过：** 共同m重算ν/q/α/ρ/e_t，signed后缀Ψ、strict FA根及分段、log时间与e_t²、共用指数分配和tanh-sinh新增节点累加均符合JCA1的保存六来源F(m)。发现并记录两项协议/报告缺口：自动旧FA区间比对缺失（当前输入已独立只读核对通过），近似并列诊断未自动输出。未发现应改动F数学公式的错误。

该PASS仅适用于绑定保存输入与代码。FULL、真实dx体积、一般HM3 box inf、全局最佳m、所有未探测质量区间和一般根阶均未认证；没有删除或复用任何原负账。交付本文件后停止，不改producer、不重跑全批。
