"""Independent scalar quadrature check of the E2 CDF coefficients."""
import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=80
root=Path(__file__).resolve().parent
d=json.loads((root/'shell_probe.json').read_text());case=next(c for c in d['cases'] if c['id']=='E2')
s=mp.mpf(case['parameters']['s']);H=mp.mpf(case['parameters']['H']);L=mp.mpf('.5');y=mp.mpf('.2')
def E(k,x):return mp.mpf(1)/(k-1) if x==0 else mp.expint(k,x)
def phi(x):
 r=abs(x);return 1-E(3,mp.mpf('.5')-r)-E(3,mp.mpf('.5')+r) if r<=mp.mpf('.5') else E(3,r-mp.mpf('.5'))-E(3,r+mp.mpf('.5'))
def mass(T):
 lo,hi=-T/2,T/2;cuts=sorted(set([lo,hi]+[x for x in [y-L/2,y+L/2] if lo<x<hi]))
 return mp.quad(lambda x:((1-s)*(1 if abs(x-y)<=L/2 else 0)+s*phi((x-y)/L))/L,cuts)
a=mass(H);c=mass(mp.mpf(1));row=case['coordinates'][0]
errs={'a':abs(a-mp.mpf(row['a_i'])),'c':abs(c-mp.mpf(row['c_i']))};assert max(errs.values())<mp.mpf('1e-65')
print(json.dumps({'case':'E2','dps':80,'errors':{k:mp.nstr(v,30) for k,v in errs.items()},'threshold':'1e-65','pass':True,'scope':'floating cross-check only, not interval certificate'},indent=2))
