"""Portable replay; install mpmath==1.3.0. Never overwrite saved producer outputs."""
import argparse, importlib.util, tempfile, shutil, zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('mode',choices=['algebra','objective','shell']);p.add_argument('--r138-archive',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
if a.mode=='algebra':
 exec(compile((root/'verify_joint_algebra.py').read_text(),str(root/'verify_joint_algebra.py'),'exec'),{'__file__':str(root/'verify_joint_algebra.py')})
else:
 if not a.r138_archive:p.error('--r138-archive is required; use repository rounds/138/research.zip')
 work=Path(tempfile.mkdtemp(prefix='cube-r139-replay-'));print('Replay output directory:',work,flush=True)
 name='joint_objective_probe' if a.mode=='objective' else 'shell_probe'
 for f in [name+'.py', 'joint_objective_protocol.md' if a.mode=='objective' else 'shell_probe_protocol.md','joint_hard_margin.md']:
  shutil.copy2(root/f,work/f)
 with zipfile.ZipFile(a.r138_archive) as z:
  dep='core_capacity_probe.json' if a.mode=='objective' else 'pair_kernel_probe.py'
  matches=[f for f in z.namelist() if f.endswith('/'+dep)];assert len(matches)==1
  (work/dep).write_bytes(z.read(matches[0]))
 spec=importlib.util.spec_from_file_location('probe',work/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 if a.mode=='objective':
  m.SRC=root/'active_traffic_v2.json';m.CAP=work/'core_capacity_probe.json'
 else:m.R138_SOURCE=work/'pair_kernel_probe.py'
 m.main()
