#!/usr/bin/env python3
"""One-shot finite shell and offset-cost probe for R139 HS4-HS16."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

VENDOR = Path("/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor")
sys.path.insert(0, str(VENDOR))
import mpmath as mp

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "shell_probe.json"
PROTOCOL = ROOT / "shell_probe_protocol.md"
R138_SOURCE = Path("/Users/zhengzhihao/Desktop/T/output/centered_cube_round138_20261015/pair_kernel_probe.py")
PROTOCOL_SHA256 = "a92ee63632f1e54e7c3f93a038d1cc9e4c7c568ac014a86787e6339c78c173d1"

MENU = [
    ("initial", "I1", 16, "low", "zero"),
    ("initial", "I2", 16, "low", "plus02"),
    ("initial", "I3", 128, "low", "zero"),
    ("initial", "I4", 128, "low", "plus02"),
    ("pressure", "P1", 128, "low", "plus04"),
    ("pressure", "P2", 128, "low", "half_pm02"),
    ("pressure", "P3", 128, "low", "one_then_zero"),
    ("pressure", "P4", 128, ".25", "zero"),
    ("expanded", "E1", 1024, "low", "zero"),
    ("expanded", "E2", 1024, "low", "plus02"),
    ("expanded", "E3", 4096, "low", "zero"),
    ("expanded", "E4", 1024, ".25", "zero"),
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def enc(value):
    if isinstance(value, mp.mpf):
        return mp.nstr(value, n=mp.mp.dps)
    if isinstance(value, dict):
        return {str(k): enc(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [enc(v) for v in value]
    return value


def expint(k: int, z: mp.mpf) -> mp.mpf:
    if z == 0:
        return mp.mpf(1) / (k - 1)
    return mp.expint(k, z)


# Copied from R138 pair_kernel_probe.py:63-69; no import or old-producer run.
def phi(x: mp.mpf) -> mp.mpf:
    r = abs(mp.mpf(x))
    half = mp.mpf(".5")
    if r <= half:
        return 1 - expint(3, half - r) - expint(3, half + r)
    return expint(3, r - half) - expint(3, r + half)


# Copied from R138 pair_kernel_probe.py:72-79.
def phi_primitive(x: mp.mpf) -> mp.mpf:
    x = mp.mpf(x)
    if x < 0:
        return -phi_primitive(-x)
    half = mp.mpf(".5")
    if x <= half:
        return x - expint(4, half - x) + expint(4, half + x)
    return half - expint(4, x - half) + expint(4, x + half)


def phi_interval(left: mp.mpf, right: mp.mpf) -> mp.mpf:
    return phi_primitive(right) - phi_primitive(left)


def overlap_length(left: mp.mpf, right: mp.mpf, core_left: mp.mpf, core_right: mp.mpf) -> mp.mpf:
    return max(mp.mpf(0), min(right, core_right) - max(left, core_left))


def M_s(s: mp.mpf, delta: mp.mpf, q: mp.mpf) -> mp.mpf:
    left, right = delta - q, delta + q
    hard = overlap_length(left, right, mp.mpf("-.5"), mp.mpf(".5"))
    return (1 - s) * hard + s * phi_interval(left, right)


def offsets_for(kind: str, n: int) -> list[mp.mpf]:
    zero = mp.mpf(0)
    plus02 = mp.mpf(".2")
    if kind == "zero":
        return [zero] * n
    if kind == "plus02":
        return [plus02] * n
    if kind == "plus04":
        return [mp.mpf(".4")] * n
    if kind == "half_pm02":
        return [plus02] * (n // 2) + [-plus02] * (n - n // 2)
    if kind == "one_then_zero":
        return [mp.mpf(1)] + [zero] * (n - 1)
    raise ValueError(f"unknown offset pattern: {kind}")


def calculate_case(stage: str, case_id: str, n: int, s_tag: str, pattern: str, dps: int):
    mp.mp.dps = dps
    a = mp.mpf(".5")
    b = mp.mpf(1)
    L = mp.mpf(".5")
    R = mp.mpf(1)
    g = mp.sqrt(mp.mpf(".5"))
    gamma = 1 + mp.mpf(1) / n
    ell = 1 + mp.log(n)
    j = int(mp.floor(mp.log(g / L) / mp.log(gamma)))
    cj = gamma ** (-j)
    s_low = mp.mpf("1.1") * (1 - mp.power(2, -mp.mpf(1) / n))
    s = s_low if s_tag == "low" else mp.mpf(s_tag)
    offsets = offsets_for(pattern, n)
    ms = 1 - s + s * phi(mp.mpf(".5"))
    H0 = g * cj ** (-mp.mpf(".5")) * ms * ell ** (mp.mpf(1) / (2 * n))
    H = max(a, min(b, H0))
    qH = H / (2 * L)
    qR = R / (2 * L)
    coords = []
    pis = []
    max_mass_resid = mp.mpf(0)
    all_pi_valid = True
    for offset in offsets:
        delta = -offset / L
        ai = M_s(s, delta, qH) / R
        ci = M_s(s, delta, qR) / R
        bi = ci - ai
        pi = bi / ci if ci > 0 else mp.nan
        resid = abs((ai + bi) - ci)
        max_mass_resid = max(max_mass_resid, resid / max(mp.mpf(1), abs(ci)))
        all_pi_valid = all_pi_valid and (pi >= 0 and pi <= 1)
        coords.append({"offset_y_minus_z": offset, "delta_z_minus_y_over_L": delta, "a_i": ai, "b_i": bi, "c_i": ci, "pi_i": pi, "mass_residual": resid})
        pis.append(pi)

    logZ = mp.fsum(mp.log(row["c_i"]) for row in coords)
    mu = mp.fsum(pis)
    uniform_mu = n * (1 - H / R)
    logcore = mp.fsum(mp.log1p(-pi) for pi in pis)
    norm = mp.fprod((1 - pi) + pi for pi in pis)
    chi = (s * phi(R / (2 * H))) / ms
    zetas = {"quarter": mp.mpf(".25"), "inverse_n_log_nplus2": 1 / (n * mp.log(n + 2))}
    log_prices = {}
    for label, zeta in zetas.items():
        log_prices[label] = n * zeta * mp.log(H / H0) + mp.fsum(mp.log1p(pi * (chi ** (-zeta) - 1)) for pi in pis)

    summary = {
        "stage": stage,
        "id": case_id,
        "input": {"n": n, "soft_tag": s_tag, "offset_pattern": pattern},
        "parameters": {"a": a, "b": b, "L": L, "R": R, "g": g, "gamma": gamma, "ell": ell, "j": j, "cj": cj, "s_low": s_low, "s": s, "m_s": ms, "H0": H0, "H": H, "H_over_R": H / R},
        "coordinates": coords,
        "summary": {
            "logZ_sum_log_ci": logZ,
            "mu_sum_pi": mu,
            "uniform_mu_reference_n_times_1_minus_H_over_R": uniform_mu,
            "logcore_sum_log_1_minus_pi": logcore,
            "poisson_binomial_total_normalization": norm,
            "chi": chi,
            "zeta_values": zetas,
            "log_inverse_shell_prices_HS14": log_prices,
            "zero_shell_H_ge_R": H >= R,
        },
        "checks": {
            "coordinate_mass_identities": max_mass_resid <= mp.mpf("1e-65"),
            "pi_in_unit_interval": all_pi_valid,
            "normalization_within_1e-65": abs(norm - 1) <= mp.mpf("1e-65"),
            "chi_positive": chi > 0,
            "zero_shell_pi_all_zero_if_H_ge_R": (not H >= R) or all(pi == 0 for pi in pis),
        },
    }
    return summary


def primary_metrics(result):
    return {
        "H_over_R": result["parameters"]["H_over_R"],
        "logZ": result["summary"]["logZ_sum_log_ci"],
        "mu": result["summary"]["mu_sum_pi"],
        "uniform_mu": result["summary"]["uniform_mu_reference_n_times_1_minus_H_over_R"],
        "logcore": result["summary"]["logcore_sum_log_1_minus_pi"],
        "chi": result["summary"]["chi"],
        "log_price_quarter": result["summary"]["log_inverse_shell_prices_HS14"]["quarter"],
        "log_price_inv_n_log_nplus2": result["summary"]["log_inverse_shell_prices_HS14"]["inverse_n_log_nplus2"],
    }


def write_state(state):
    OUT.write_text(json.dumps(enc(state), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    if OUT.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {OUT}")
    protocol_hash = sha256(PROTOCOL)
    if protocol_hash != PROTOCOL_SHA256:
        raise RuntimeError(f"frozen protocol hash mismatch: expected {PROTOCOL_SHA256}, got {protocol_hash}")
    source_hash = sha256(R138_SOURCE)
    state = {
        "status": "running",
        "run_count": 1,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "scope": "finite fixed-menu HS4-HS16 shell and offset-cost arithmetic only; no integral and no general budget certification",
        "protocol_sha256": protocol_hash,
        "r138_phi_source_path": str(R138_SOURCE),
        "r138_phi_source_sha256": source_hash,
        "python_version": sys.version,
        "mpmath_version": mp.__version__,
        "precision_dps": [90, 120],
        "tolerance_absolute": "1e-65",
        "cases": [],
        "exceptions": [],
    }
    write_state(state)
    for stage, case_id, n, s_tag, pattern in MENU:
        try:
            r90 = calculate_case(stage, case_id, n, s_tag, pattern, 90)
            r120 = calculate_case(stage, case_id, n, s_tag, pattern, 120)
            m90, m120 = primary_metrics(r90), primary_metrics(r120)
            differences = {key: abs(m90[key] - m120[key]) for key in m90}
            max_difference = max(differences.values())
            r120["precision_comparison"] = {
                "absolute_differences": differences,
                "maximum_absolute_difference": max_difference,
                "threshold": mp.mpf("1e-65"),
                "pass": max_difference <= mp.mpf("1e-65"),
            }
            basic_checks = all(r120["checks"].values())
            r120["status"] = "PASS_FLOATING_POINT_ARITHMETIC" if basic_checks and r120["precision_comparison"]["pass"] else "FAIL_OR_UNRESOLVED"
            r120["precision_90_snapshot"] = {"summary": r90["summary"], "H": r90["parameters"]["H"], "H0": r90["parameters"]["H0"]}
            state["cases"].append(r120)
        except Exception as exc:
            failure = {"stage": stage, "id": case_id, "n": n, "soft_tag": s_tag, "offset_pattern": pattern, "status": "EXCEPTION", "exception": f"{type(exc).__name__}: {exc}"}
            state["cases"].append(failure)
            state["exceptions"].append(failure)
        state["completed_cases"] = len(state["cases"])
        write_state(state)
        print(f"{case_id}: {state['cases'][-1]['status']}", flush=True)

    passed = sum(row.get("status") == "PASS_FLOATING_POINT_ARITHMETIC" for row in state["cases"])
    state["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    state["summary"] = {"cases": len(state["cases"]), "passed": passed, "failed_or_unresolved": len(state["cases"]) - passed}
    state["status"] = "COMPLETE_ALL_PASS" if passed == 12 and not state["exceptions"] else "COMPLETE_WITH_FAILURES_OR_UNRESOLVED"
    write_state(state)
    print(json.dumps(state["summary"], ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
