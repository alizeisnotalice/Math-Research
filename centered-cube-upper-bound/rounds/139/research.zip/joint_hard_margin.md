# R139：同一硬来源与RC余量的联合付款

状态：推导冻结，待独审。目标为原RT2在Hhat<L₊、C_J(v)≤3中的实际剩余。本稿证明一个有明确全局价格的联合阈值子支；不声称其覆盖多数交通或解决一般主瓶颈。固定原同一尺度带[a,b]、b≤2a，在V、y、t和来源之前给定。只使用RT1–6、原FIRST/high与R138接口；ν任意相关，无e_t下界。外硬来源z无需属于Z_t，更不被假定为bad。

## HM1：共同剩余恒等式与核心储备

记H=Hhat，Q₀=∫K₀dν，Q_J=∫Jdν，m_s=1−s+sφ(1/2)，κ=(H₀/H)ⁿ。原定义给TH₀ⁿ=m_sⁿ、Q₀≤q、0≤U≤DK₀，因此

\[
 \boxed{\alpha Q_J=D(q-Q_0)+\int(DK_0-U)d\nu.} \tag{HM1}
\]

对外硬盒Q_R(x)，令d=min(R,H)，核心C_x=Q_d(x)，m_c=ν(C_x)。在该真实硬H盒内

\[
 K_0(x-z)\ge m_s^n/H^n=T\kappa. \tag{HM2}
\]

这条下界不向盒外延伸。原B准确为1_{R≤L}1_{Q_R(x)}。故R≤L时，外硬z全部满足U(z)=0，特别核心储备下界为D Tκ。

R>L时仍有U≤TA，且A=w_τ−w_h≤1−w_h。定义

\[
 \omega_c=\inf_{z\in C_x}w_h(y,z)>0,
 \quad
 \lambda_c=\begin{cases}
 DT\kappa,&R\le L,\\
 T[D\kappa-1+\omega_c]_+,&R>L.
 \end{cases} \tag{HM3}
\]

真实连续正权在有限盒上的inf为正；ω_c仅作为明确可计算量保留，没有维数无关下界假设。逐点DK₀−U≥λ_c于核心，故

\[
 \boxed{\alpha Q_J\ge\lambda_c m_c.} \tag{HM4}
\]

若不用ω_c，R>L时可用较弱T(Dκ−1)₊。HM3还保留了Dκ=1临界处的真实w_h储备，没有把该处机械记为零。

完整clamp核对：H₀<a时H=a、κ<1；a≤H₀≤b时κ=1；H₀>b时H=b、κ>1。R≤L的λ_c在全部clamp及D≥1下都严格为正；R>L时仅在Dκ−1+ω_c>0的实际分支使用正λ_c。H₀≥a且D≥1时该条件成立；下钳位H₀<a不能免费假设成立。H<L₊不等于H=a。

## HM2：硬质量乘good余量，不分别取sup

对实际good余量点v，令a_v=(1−DK₀(x−v)/(TA(v)))₊。A=0、B(v)=1及Q_J=0按原零行处理；其余有ρ(v)=(a_v−αJ(x−v)/(TA(v)))₊。若λ_c>0，由HM4，

\[
 \rho(v)\le\left[a_v-\frac{\lambda_cJ(x-v)}{TA(v)Q_J}m_c\right]_+.
\]

对同一实际m_c使用max_{m≥0}m(a−bm)₊=a²/(4b)，得到

\[
 \boxed{\frac{m_c}{qR^n}\rho(v)\le
 \Gamma_c(v):=\frac{Q_J}{q}
 \frac{a_v^2TA(v)}{4\lambda_cJ(x-v)R^n}.} \tag{HM5}
\]

同时原硬帽给m_c/(qRⁿ)≤16/3，故可取min{16/3,Γ_c}。HM5使用的是外硬来源实际质量与同一ρ的联合二次优化；没有先对两个因子分别取sup，没有改α，也没有要求核心来源存活于Z_t。Q_J/q≤1可作正上界，但保留该比更尖。

若R≤min(L,H)，核心就是全部外硬盒，λ_c=DTκ。HM5此时覆盖整个硬载体，且不要求D>1或H₀≥a。这是一个明确、非空几何范围；但Γ_c是否小仍须按实际来源检查，不能据核范围宣称全部余量已付。

在C_J(v)≤3的原good层，J(x−v)≥p w_g(v)/K，因此也有可检查的充分上界

\[
 \Gamma_c(v)\le
 \frac{K a_v^2 T}{4\lambda_c p R^n}\frac{A(v)}{w_g(v)}.
 \tag{HM6}
\]

该式只帮助核验阈值，不把A/w_g或pRⁿ当常数。

## HM3：外壳的准确价格与共享容量

若R>H，按m(z)=#{i:|x_i−z_i|>H/2}将Q_R分为不交层S_m，m=0,…,n，S₀=C_x。令

\[
 \vartheta=\frac{s\phi(R/(2H))}{m_s},\qquad
 \kappa_m=\kappa\vartheta^m.
\]

真实核逐坐标给K₀≥Tκ_m于S_m。令ω_m=inf_{S_m}w_h（空层忽略），并按HM3将κ、ω_c换成κ_m、ω_m定义λ_m≥0。则只有一份共同容量：

\[
 \boxed{\sum_{m=0}^n\lambda_m\nu(S_m)\le\alpha Q_J.} \tag{HM7}
\]

不能对每个m独立领取一份αQ_J后相加。对任一选定层并集S⊂Q_R，若其统一认证下界λ_S>0，则ν(S)λ_S≤αQ_J，HM5按m_c→ν(S)、λ_c→λ_S原样成立。S及其认证下界λ_S必须在外硬z积分之前共同选定：可依赖ω、V、j、x、y、t、v及共同容量数据，但不得依正在积分的外硬z逐源重选。所选交通与补集只分一次，不将全部候选重复求和。R≤L时所有λ_m=DTκ_m>0；壳层可能出现的ϑ^{-m}费用必须体现在λ_S中，不能省略。

## HM4：联合阈值子支的完整根阶价格

在外硬z积分之前，按HM3规定的共同选择量词选定一个核心或层并集S及其λ_S，令

\[
 \Gamma_S(v)=\frac{Q_J}{q}
 \frac{a_v^2TA(v)}{4\lambda_SJ(x-v)R^n},
 \qquad \mathcal G_S=\{\lambda_S>0,\ \Gamma_S(v)\le(n+1)^{-3}\}.
 \tag{HM8}
\]

在原RT2正项上只取z∈S、good v∈𝒢_S，并保持H<L₊、C_J(v)≤3、原high/FA/Ψ/ρ，所得记P_I^{hard-joint}。则对每个合法有限截断

\[
 \boxed{2\Lambda P_I^{hard-joint}\le40\Lambda\sqrt n\,W_\beta.} \tag{HM9}
\]

这是真实dx、β、time/j/history的价格，不是√nX。Γ阈值是hard质量与ρ联合预算的认证条件；它不要求hard质量或ρ分别小，也不要求来源归一化下界。尚未证明𝒢_S覆盖大多数高likelihood交通。

## HM5：选择器费用的自含核查

以下soft包络已在R117记录，本节仅自证以核对本次完整接合，不登记为新核定理。固定L，写f_s(x)=P_{s,L}(x−y)。任意非负可微函数s↦f_s满足

\[
 \sup_{0\le s\le1}f_s\le\frac12
 \left(f_0+f_1+\int_0^1|\partial_sf_s|ds\right).
\]

逐坐标将硬/软混合展开成潜在Bernoulli子集A。每个对应乘积核都质量1，系数为s^{|A|}(1−s)^{n−|A|}。对0<s<1，三角不等式及非负Tonelli给

\[
 \int|\partial_s f_s|dx
 \le\frac{\mathbb E|K_s-ns|}{s(1-s)}
 \le\frac{\sqrt n}{\sqrt{s(1-s)}},\qquad K_s\sim\operatorname{Bin}(n,s).
\]

这里只对潜在混合指标使用二项分布；没有假定硬、软分量支撑不交，更没有假定ν独立。因为∫₀¹[s(1−s)]^{-1/2}ds=π，

\[
 D_n:=\int\sup_s P_{s,L}(x-y)dx
 \le1+\frac\pi2\sqrt n\le3\sqrt n. \tag{HM10}
\]

端点s=0只作支配核，未当作原实际软度行。

在事先固定的[a,b]内，以γ=1+1/n上取整L至L_k，L≤L_k≤γL；网格数N_L≤log2/logγ+2≤2n+3。φ偶单调，硬支撑随L扩大，因此逐坐标p_{s,L}≤γp_{s,L_k}，整维

\[
 p_{s,L}\le\gamma^n p_{s,L_k}\le3p_{s,L_k}.
\]

所以对实际所有可测s(x),L(x)选择器，

\[
 \boxed{\int\sup_{s\in[0,1],\ L\in[a,b]}
 P_{s,L}(x-y)dx\le3(2n+3)D_n.} \tag{HM11}
\]

这里没有跨全部绝对尺度取sup。[a,b]必须按原合同先固定；若另有尺度带求和，其原预算仍需独立保留。

比例带的0≤j≤log(b/a)/(2logγ)给可用j数N_j≤n+2；空heavy列不贡献。对每个j，原t∈[τ_j,h]⊂[a/c_j,bc_j]，且c_j≤1，因此时间总长度≤log2。这一步可上放到接收点无关的固定时间窗。RT4保证固定(ω,V,j,y,t)后的Π_t不依x或外硬z。

## HM6：HM9的完整付款证明

首先固定ω、V、j、x、y、t、v及共同容量数据，并在外硬z积分之前共同选定S、λ_S；二者在该z积分中保持不变。随后在同一实际x,y,t,v积分外硬来源z。原history因子a_ω≤1；保留z∈S，再由HM5、HM8得到

\[
 \frac1q\int_S h_R(x-z)a_\omega(x,y,z)d\nu(z)
 \rho_x(v)\mathbf1_{\mathcal G_S}(v)
 \le(n+1)^{-3}. \tag{HM12}
\]

这是把hard质量与ρ一起积分后的结果；没有用16/3硬帽替代其联合抑制。所有原截断和额外门只缩小正项，可以保留或在此后正放松。

接着使用0≤FA,Ψ≤1、δ_t≤n，以及同一Π_t的两端总质量均为1。于是当前时刻的双来源积分至多n/(n+1)³。e_t全部留在原Π中，未使用e_t下界或ν总质量帽。

对实际接收核使用HM11，时间≤log2，j数≤n+2，恢复β及原V期望，得到

\[
 P_I^{hard-joint}\le
 \frac{n\log2}{(n+1)^3}(n+2)\,3(2n+3)D_n\,W_\beta.
\]

由n(n+2)(2n+3)≤3(n+1)³及D_n≤3√n，右端≤27(log2)√nWβ。再乘2Λ，因54log2<40，得到HM9。没有改β为ν，没有条件化dx，也没有把唯一j或连续soft参数当免费。原ν相关对上述正上界无影响。

可依ω、V、j、x、y、t、v及共同容量数据，先按可测规则共同选定一个S及λ_S（例如满足阈值的最大初始壳层并集），再积分外硬z并使用HM12；不得依正在积分的z逐源重选S或λ_S，也不能将所有候选S的HM9价格无条件累加。若该子支与其他已付正交通重合，应先从尚未付款的截断I中剔除交集再登记。

## HM7：覆盖范围、残余与停止点

本轮新付款是：**由同一FIRST/RC剩余证明的hard质量×rho联合阈值子支，在完整原积分中有40Λ√nWβ价格。** soft包络不是新成果；新处是HM1–8将它接到一个来自真实硬来源的共同余量抑制，而非分别使用硬帽和ρ≤1。

覆盖核心以及任一已认证λ_S>0的硬层并集；在R≤min(L,H)时可以直接取整个硬载体。外硬来源从未被假定属于Z_t，所以不使用e_t≥w_B·hard质量。H₀、H与κ始终按RT6精确值，未将H₀近似为max(L,R)·m_s，也未以欧氏体积比例推断ν核心质量。

仍未付的准确部分是：所选S之外的外壳、λ_S=0的clamp域，以及Γ_S>(n+1)^{-3}的共同高余量域。HM7记录了它们共享的实际容量，但没有给其一般根阶预算。实际数值中增大CORE使ρ归零，只能由HM4–5解释抑制方向，不能据此宣布这些剩余域为空或小质量。当前未证明本子支覆盖多数高likelihood交通。

下一准确问题是能否在上述Γ大域，利用保留的same-x good、FA/Ψ与共同坏来源预算取得额外衰减，或在真实外积分中支付壳层λ_m的分布；不能把这些费用改名后当常数。一般εX+Cε√n log^A(n)Wβ目标仍未完成。

本子支不另开ε槽，未返还N_Z；N_Zc与N_del保持原负门各一次。不重复领取16/3硬帽、α容量或其他正支价格。只改本文件，无git/PDF，到此停止。
