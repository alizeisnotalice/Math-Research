# R139 主代理：剩余与归一化不能分别最大化

待审代数观察，尚无一般几何付款。
固定x,y,t,v及一个硬来源可测子域B。若r(z)=DK0(z)−U(z)≥c>0，且w_t(y,z)≥w_B>0于B，则m=ν(B)满足

alpha QJ≥c m， e_t≥w_B m（B⊂Z_t才成立）。

最后一个条件不可从“外硬来源”自动得到；原硬z不一定是存活Z_t来源，不能在一般原交通中使用e下界。这正是共享归一化必须核实的域问题。

若另有准确分解e_t=e_rest+∫_B wtν，B⊂Z_t且e_rest>0，则rho_v≤(a_v−c Jv m/(TA_v QJ))+，所以对任何其余非负乘子，可用

m rho_v/e_t² ≤ m(a_v−b_v m)+/(e_rest+w_B m)²， b_v=c Jv/(TA_v QJ).

右边在0≤m≤a_v/b_v的最大值为a_v²/[4 e_rest(a_v w_B+b_v e_rest)]，峰点m*=a_v e_rest/(a_v w_B+2b_v e_rest)（a_v,b_v>0）。这是固定其余量的代数，不可将q,QJ,a_v随m变化的实际数值模型误作固定；对给定实际行这些是已固定参数，用作点态包络时合法。

相比先丢rho或e中的m，其联合价格显式更小。仍缺：B⊂Z_t、wt下界的原硬几何保证、e_rest逆量与真实dx积分的费用；若e_rest=0，不能套此式，须回原双来源积分，尤其原good v的质量不应被另设为零。
