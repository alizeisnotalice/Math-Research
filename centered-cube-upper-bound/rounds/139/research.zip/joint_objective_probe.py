#!/usr/bin/env python3
"""Bounded joint objective probe from saved coefficients; no kernel rerun."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,datetime,time,traceback
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from mpmath.calculus.quadrature import TanhSinh
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
CAP=ROOT.parent/'centered_cube_round138_20261015/core_capacity_probe.json'
OUT=ROOT/'joint_objective_probe.json'
EXPECTED_SRC='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
EXPECTED_CAP='268bd6ca487de9111dec63085c81c9bfd2fc5eb8aa760483dd000581eae6900d'
ORDER=['I1','I2','P1','I3','I4','P2','P3','P4','E1','E2','E3','E4']
RULE=TanhSinh(mp.mp)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def mf(q):return mp.mpf(q.numerator)/q.denominator
def fj(q):return dict(numerator=str(q.numerator),denominator=str(q.denominator))
def dec(x,dps=None):return mp.nstr(x,dps or mp.mp.dps)
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def line_at(line,m):return line[0]*m+line[1]
def rel(a,b):return abs(a-b)/max(abs(b),mp.mpf('1e-2000'))

class Model:
 def __init__(self,case,cap):
  self.case=case;self.cap=cap;self.at=case['atoms'];self.n=case['n'];self.sup=jf(cap['mass_supremum'])
  self.p=fr(case['derived']['p']);self.T=fr(case['derived']['T']);self.K=fr(case['parameters']['K']);self.D=fr(case['parameters']['D']);self.BFA=fr(case['parameters']['B_FA'])
  self.fixed=[fr(a['nu']) for a in self.at[:4]];self.f0=1-sum(self.fixed)
  self.lines={k:(jf(v['slope']),jf(v['intercept'])) for k,v in cap['affine_coefficients'].items()}
  self.W=jf(cap['heavy_saved_rational_coefficient']);self.U=[jf(a['rebuilt']) for a in cap['rebuilt_U_audit']]
  self.A=[fr(a['A']) for a in self.at];self.J=[fr(a['J']) for a in self.at];self.K0=[fr(a['K0']) for a in self.at]
  self.av=[max(1-self.D*self.K0[i]/(self.T*self.A[i]),F(0)) if self.A[i]>0 else F(0) for i in range(6)]
  self.lam=self.D*self.K0[5]-self.U[5];assert self.lam>0
  self.oldlam=max(self.D*self.T*(fr(case['derived']['H0'])/fr(case['derived']['Hhat']))**self.n-self.T,F(0));assert self.oldlam==0
  self.segs=[]
  for s in case['score_segments']:
   lo,hi=fr(s['lo']),fr(s['hi']);assert lo<hi and len(s['c'])==len(s['k'])==6
   ks=[sum(fr(al)**2<lo*hi for al in a['thresholds']) for a in self.at];assert ks==s['k']
   self.segs.append(dict(lo=lo,hi=hi,k=ks,c=[fr(x) for x in s['c']]))
  assert self.segs[0]['lo']==fr(case['derived']['tau']) and self.segs[-1]['hi']==fr(case['derived']['h'])
  assert all(self.segs[i-1]['hi']==s['lo'] for i,s in enumerate(self.segs) if i)
  self.pairs=[];self.psi_check=[];primitive_cache={}
  for i,v in enumerate(self.at):
   for j,u in enumerate(self.at):
    increments=[]
    for si,s in enumerate(self.segs):
     power=s['k'][i]+s['k'][j];diff=s['k'][i]-s['k'][j]
     key=(si,power)
     if key not in primitive_cache:primitive_cache[key]=(s['lo']**(-power)-s['hi']**(-power))/power if power else F(0)
     increments.append(diff*s['c'][i]*s['c'][j]*primitive_cache[key])
    suffix=[F(0)]*(len(increments)+1)
    for ii in range(len(increments)-1,-1,-1):suffix[ii]=suffix[ii+1]+increments[ii]
    psi=max(suffix)>0;old=case['pairs'][i*6+j]
    assert old['v']==v['name'] and old['z_prime']==u['name'] and not old['suffix_ambiguous']
    assert old['Psi']==psi,'Saved-coefficient Psi reconstruction mismatch'
    eligibility=v['good'] and u['bad'] and psi
    self.pairs.append(dict(pid=i*6+j,i=i,j=j,v=v['name'],u=u['name'],Psi=psi,eligible=eligibility))
    self.psi_check.append(dict(pid=i*6+j,Psi=psi,saved_agrees=True,max_suffix_sign=1 if max(suffix)>0 else 0))
  self.prep={};self.nodes={}

 def prepare(self,dps):
  if dps in self.prep:return self.prep[dps]
  mp.mp.dps=dps;pieces=[]
  for si,s in enumerate(self.segs):
   candidates=[];cuts=[mf(s['lo']),mf(s['hi'])]
   for pair in self.pairs:
    if not pair['eligible']:continue
    i,j=pair['i'],pair['j'];delta=max(s['k'][i]-s['k'][j],0)
    if not delta:continue
    kv=s['k'][i];assert kv>0
    Kfa=self.BFA*delta*self.p*s['c'][i]/fr(self.at[i]['Q'])
    if Kfa<=s['lo']**kv:continue
    cap=mf(s['hi']) if Kfa>=s['hi']**kv else mf(Kfa)**(mp.mpf(1)/kv)
    if cap<mf(s['hi']):cuts.append(cap)
    candidates.append(dict(**pair,delta=delta,N=s['k'][i]+s['k'][j],factor=delta*s['c'][i]*s['c'][j],cap=cap))
   cuts=sorted(set(cuts))
   for lo,hi in zip(cuts,cuts[1:]):
    if hi<=lo:continue
    mid=mp.sqrt(lo*hi);active=[p for p in candidates if mid<p['cap']]
    if not active:continue
    pieces.append(dict(index=len(pieces),segment=si,lo=lo,hi=hi,loglo=mp.log(lo),loghi=mp.log(hi),pairs=active,k=s['k'],c=[mf(x) for x in s['c']]))
  self.prep[dps]=pieces;return pieces

 def state(self,m):
  qvals={lab:line_at(self.lines[lab],m) for lab in ['Q0','QJ','Qstar']};q=max(qvals.values());QJ=qvals['QJ'];eg=line_at(self.lines['eg'],m);Ut=line_at(self.lines['Utotal'],m)
  alpha=(self.D*q-Ut)/QJ;nu=self.fixed+[self.f0-m,m]
  rho=[max(1-(self.U[i]+alpha*self.J[i])/(self.T*self.A[i]),F(0)) if self.at[i]['good'] and self.A[i]>0 else F(0) for i in range(6)]
  positive=[self.at[i]['name'] for i in range(6) if rho[i]>0 and self.at[i]['good']]
  gates=dict(m_positive=m>0,far_positive=self.f0-m>0,high=self.p*eg>=2*self.K*q,heavy=eg>self.W*q,hard_cap=m<=4*q,q_positive=q>0,alpha_nonnegative=alpha>=0,positive_good_rho=bool(positive))
  gamma=[];threshold=F(1,(self.n+1)**3)
  for i,a in enumerate(self.at):
   if not a['good'] or self.A[i]<=0:continue
   G=(QJ/q)*self.av[i]**2*self.T*self.A[i]/(4*self.J[i]*self.lam)
   actual=(m/q)*rho[i];assert actual<=G
   gamma.append(dict(v=a['name'],positive_rho=rho[i]>0,Gamma_support=dec(mf(G)),QJ_over_q=dec(mf(QJ/q)),threshold=dec(mf(threshold)),small_gain_pass=G<=threshold,actual_m_rho_over_q=dec(mf(actual)),support_bound_pass=True))
  assert alpha*QJ>=self.lam*m
  return dict(q=q,QJ=QJ,eg=eg,alpha=alpha,nu=nu,rho=rho,gates=gates,allowed=all(gates.values()),positive_good=positive,q_winners=[lab for lab,val in qvals.items() if val==q],hard=self.p*m/q,gamma=gamma)

 def node_shapes(self,piece,degree,dps,Ns):
  key=(dps,piece['index'],degree,tuple(Ns))
  if key in self.nodes:return self.nodes[key]
  ks=sorted(set(piece['k']));out=[]
  for x,w in RULE.get_nodes(piece['loglo'],piece['loghi'],degree,mp.mp.prec):
   powers={k:mp.exp(-k*x) for k in set(ks+Ns)}
   out.append((w,[powers[k] for k in ks],[powers[n] for n in Ns]))
  self.nodes[key]=(ks,out);return ks,out

 def kernel_vector(self,piece,nu,dps,Ns):
  coef={k:mp.fsum(nu[i]*piece['c'][i] for i in range(6) if piece['k'][i]==k) for k in set(piece['k'])}
  xm=(piece['loglo']+piece['loghi'])/2;em=mp.fsum(val*mp.exp(-k*xm) for k,val in coef.items());norm=[mp.exp(-N*xm)/(em*em) for N in Ns]
  prev=None;last_error=None;target=mp.mpf('1e-70') if dps==90 else mp.mpf('1e-100')
  for degree in range(1,10):
   ks,nodes=self.node_shapes(piece,degree,dps,Ns);sums=[[] for _ in Ns]
   for w,powers,nums in nodes:
    et=mp.fsum(coef[k]*power for k,power in zip(ks,powers));den=et*et
    for ni,num in enumerate(nums):sums[ni].append(w*num/(den*norm[ni]))
   h=mp.mpf(2)**(-degree);cur=[(prev[ni]/2 if prev is not None else 0)+h*mp.fsum(values) for ni,values in enumerate(sums)]
   if prev is not None:
    last_error=max(rel(cur[ni],prev[ni]) for ni in range(len(Ns)))
    if degree>=3 and last_error<=target:break
   prev=cur
  values={N:cur[ni]*norm[ni] for ni,N in enumerate(Ns)}
  return values,dict(degree=degree,last_relative_change=dec(last_error) if last_error is not None else None,target=dec(target),converged=last_error is not None and last_error<=target)

 def evaluate(self,m,dps,definition,stage,nodeid):
  mp.mp.dps=dps;start=time.monotonic();st=self.state(m);pieces=self.prepare(dps)
  nu=[mf(x) for x in st['nu']];rho=[mf(x) for x in st['rho']]
  contributions=[mp.mpf(0)]*36;records=[];warnings=0
  # Boundary with no rho has exact zero objective, not an eligible peak.
  for piece in pieces:
   active=[p for p in piece['pairs'] if rho[p['i']]>0 and nu[p['i']]>0 and nu[p['j']]>0]
   Ns=sorted(set(p['N'] for p in active));values={};conv=dict(degree=0,last_relative_change=None,target=None,converged=True)
   if Ns:values,conv=self.kernel_vector(piece,nu,dps,Ns)
   if not conv['converged']:warnings+=1
   part=[]
   for p in active:
    val=rho[p['i']]*nu[p['i']]*nu[p['j']]*mf(p['factor'])*values[p['N']]
    contributions[p['pid']]+=val;part.append(dict(pid=p['pid'],contribution=dec(val),shared_power=p['N']))
   def et(t):return mp.fsum(nu[i]*piece['c'][i]*t**(-piece['k'][i]) for i in range(6))
   records.append(dict(piece=piece['index'],segment=piece['segment'],lo=dec(piece['lo']),hi=dec(piece['hi']),e_t_lo=dec(et(piece['lo'])),e_t_mid=dec(et(mp.sqrt(piece['lo']*piece['hi']))),e_t_hi=dec(et(piece['hi'])),shared_kernels={str(N):dec(value) for N,value in values.items()},pair_contributions=part,quadrature=conv))
  good={a['name']:mp.fsum(contributions[i*6:(i+1)*6]) for i,a in enumerate(self.at) if a['good']};S=mp.fsum(contributions);total=mf(st['hard'])*S
  if st['allowed'] and not total>0:raise ArithmeticError('Allowed positive-rho model returned nonpositive objective')
  rec=dict(node_id=nodeid,stage=stage,precision=dps,mass_definition=definition,m=dec(mf(m)),fraction_of_sup=dec(mf(m/self.sup)),q=dec(mf(st['q'])),q_winners=st['q_winners'],alpha=dec(mf(st['alpha'])),QJ=dec(mf(st['QJ'])),QJ_over_q=dec(mf(st['QJ']/st['q'])),e_g=dec(mf(st['eg'])),nu=[dec(x) for x in nu],rho=[dec(x) for x in rho],positive_good=st['positive_good'],gates=st['gates'],eligible=st['allowed'],hard_prefactor=dec(mf(st['hard'])),internal_S=dec(S),objective_F=dec(total),good_contributions={key:dec(value) for key,value in good.items()},pair_contributions=[dec(v) for v in contributions],time_piece_records=records,quadrature_warning_count=warnings,Gamma_support_at_m=st['gamma'],status='positive_eligible' if st['allowed'] else 'excluded_boundary_or_gate',elapsed_seconds=time.monotonic()-start,FULL_certified=False)
  return rec,total

 def static_record(self):
  H=fr(self.case['derived']['Hhat']);y=fr(self.case['parameters']['y']);needed=abs(y)+H/2
  return dict(pair_masks=self.psi_check,score_segments=[dict(lo=str(s['lo']),hi=str(s['hi']),k=s['k'],c_saved=self.case['score_segments'][i]['c']) for i,s in enumerate(self.segs)],old_lambda0=fj(self.oldlam),old_Gamma_not_applicable=True,uniform_HM3=dict(computed=False,reason='Missing saved C at farthest box coordinate; kernel recomputation prohibited',required_C_distance=str(needed),omega_core=None,lambda_uniform=None),lambda_support=fj(self.lam),lambda_support_scope='Exact for saved coefficients on finite hard support CORE only; not a general box infimum',hard_R=1)

def run_case(case,cap,checkpoint):
 start=time.monotonic();model=Model(case,cap);out=dict(id=case['id'],stage=case['stage'],n=case['n'],status='running',static=model.static_record(),supremum_source=cap['mass_supremum'],supremum_attained=cap['supremum_attained'],points=[],verifications=[],mass_budget_90=32)
 numeric={};masses={};index={};counts=0
 def add(m,definition,stage):
  nonlocal counts
  if m in index:return index[m]
  if counts>=32:out.setdefault('budget_events',[]).append('90-digit hard budget reached');return None
  pid=len(out['points']);rec,value=model.evaluate(m,90,definition,stage,pid);out['points'].append(rec);numeric[pid]=value;masses[pid]=m;index[m]=pid;counts+=1;checkpoint(out);return pid
 fractions=sorted(set([F(1,2**j) for j in [1,2,4,8,16,32,64,128]]+[F(1,8),F(1,4),F(3,8),F(1,2),F(5,8),F(3,4),F(7,8),F(15,16),F(31,32),F(1)]))
 assert len(fractions)==16
 for x in fractions:add(x*model.sup,dict(kind='sup_fraction',x=fj(x)),'coarse')
 add(F(1,10**300),dict(kind='original_reference',m_exact='1/10^300'),'coarse_reference')
 add(jf(cap['feasible_interior']['m']),dict(kind='R138_feasible_interior'),'coarse_interior')
 knots={}
 for ci,cell in enumerate(cap['winner_cells']):
  if not cell['feasible']:continue
  for bound in ['lower','upper']:
   m=jf(cell[bound])
   if 0<m<model.sup:knots.setdefault(m,dict(kind='R138_cell_endpoint',cell=ci,bound=bound))
 assert len(knots)<=3,'Unexpected structural knot count; do not expand'
 for m,definition in sorted(knots.items()):add(m,definition,'structural')
 def ranked(valid_only=True):
  ids=[i for i,r in enumerate(out['points']) if not valid_only or (r['eligible'] and numeric[i]>0)]
  return sorted(ids,key=lambda i:(-numeric[i],masses[i]))
 for roundno in range(2):
  sortedids=sorted(masses,key=lambda i:masses[i]);positions={i:p for p,i in enumerate(sortedids)};peaks=[]
  for i in ranked():
   pos=positions[i];neighbors=[sortedids[j] for j in [pos-1,pos+1] if 0<=j<len(sortedids)]
   if all(numeric[i]>=numeric[j]*(1-mp.mpf('1e-50')) for j in neighbors):peaks.append(i)
   if len(peaks)==2:break
  if len(peaks)<2:
   for i in ranked():
    if i not in peaks:peaks.append(i)
    if len(peaks)==2:break
  proposals=[]
  for center in peaks:
   pos=positions[center]
   for jj in [pos-1,pos+1]:
    if not 0<=jj<len(sortedids):continue
    other=sortedids[jj];left,right=sorted([center,other],key=lambda i:masses[i]);a,b=masses[left],masses[right]
    if b/a>16:
     mp.mp.dps=90;x=mp.sqrt(mf(a/model.sup)*mf(b/model.sup));xs=mp.nstr(x,90);new=fr(xs)*model.sup;definition=dict(kind='geometric_sup_fraction_90',left=left,right=right,x_decimal=xs)
    else:new=(a+b)/2;definition=dict(kind='arithmetic_mean',left=left,right=right)
    if a<new<b:proposals.append((new,definition))
  for new,definition in proposals:add(new,definition,f'local_round_{roundno+1}')
 top=ranked()[:3];out['candidate_peak_node_ids']=top
 for i in top:
  rec,value=model.evaluate(masses[i],120,out['points'][i]['mass_definition'],'verification',i)
  old=out['points'][i];errs=dict(F=rel(value,fr_to_mp(old['objective_F'])),S=rel(fr_to_mp(rec['internal_S']),fr_to_mp(old['internal_S'])))
  for key,val in rec['good_contributions'].items():
   if fr_to_mp(val) or fr_to_mp(old['good_contributions'][key]):errs[f'good:{key}']=rel(fr_to_mp(val),fr_to_mp(old['good_contributions'][key]))
  passed=all(e<=mp.mpf('1e-55') for e in errs.values()) and rec['gates']==old['gates'] and rec['positive_good']==old['positive_good']
  rec['verification']=dict(relative_errors={key:dec(val) for key,val in errs.items()},passed=passed,gate_zero_branch_agreement=rec['gates']==old['gates'] and rec['positive_good']==old['positive_good'])
  out['verifications'].append(rec);checkpoint(out)
 stable=[r for r in out['verifications'] if r['verification']['passed'] and r['eligible'] and mp.mpf(r['objective_F'])>0]
 stable=sorted(stable,key=lambda r:(-mp.mpf(r['objective_F']),mp.mpf(r['m'])))
 reference=next(r for r in out['points'] if r['mass_definition']['kind']=='original_reference')
 out['summary']=dict(evaluated_90_count=counts,verified_120_count=len(out['verifications']),stable_positive_count=len(stable),best_verified_node_id=stable[0]['node_id'] if stable else None,best_verified_F=stable[0]['objective_F'] if stable else None,best_verified_m=stable[0]['m'] if stable else None,best_verified_m_over_sup=stable[0]['fraction_of_sup'] if stable else None,best_Gamma_support=stable[0]['Gamma_support_at_m'] if stable else None,original_reference_F=reference['objective_F'],best_over_reference=dec(mp.mpf(stable[0]['objective_F'])/mp.mpf(reference['objective_F'])) if stable and mp.mpf(reference['objective_F'])>0 else None,all_failed_nodes=[r['node_id'] for r in out['verifications'] if not r['verification']['passed']],not_global_optimum=True,unprobed_mass_intervals_remain=True,FULL_certified=False,real_dx_volume_certified=False)
 out['status']='completed_positive_verified' if stable else 'completed_without_stable_positive';out['elapsed_seconds']=time.monotonic()-start;checkpoint(out)
 return out

def fr_to_mp(s):return mf(fr(s))
def main():
 if OUT.exists():raise SystemExit('Refuse another joint objective producer run')
 assert sha(SRC)==EXPECTED_SRC and sha(CAP)==EXPECTED_CAP
 src=json.loads(SRC.read_text());cap=json.loads(CAP.read_text());assert len(src['cases'])==len(cap['cases'])==12 and cap['input_sha256']==EXPECTED_SRC
 sources=[ROOT/'joint_objective_protocol.md',Path(__file__),SRC,CAP,ROOT/'joint_hard_margin.md']
 data=dict(status='running',run_count=1,started_utc=utc(),input_sha256={str(SRC):EXPECTED_SRC,str(CAP):EXPECTED_CAP},sha256={str(p):sha(p) for p in sources},execution_order=ORDER,scope='Fresh finite necessary-model F(m) with new rho/nu/e_t and original FA/Psi. No kernel producer rerun, FULL, dx volume or global optimum certificate.',cases=[],exceptions=[])
 save(data);sm={c['id']:c for c in src['cases']};cm={c['id']:c for c in cap['cases']}
 for cid in ORDER:
  slot=len(data['cases']);data['cases'].append(dict(id=cid,status='initializing'))
  def checkpoint(row):data['cases'][slot]=row;save(data)
  try:
   row=run_case(sm[cid],cm[cid],checkpoint);print(cid,row['status'],'90-count',row['summary']['evaluated_90_count'],'bestF',row['summary']['best_verified_F'],'fraction',row['summary']['best_verified_m_over_sup'],'elapsed',row['elapsed_seconds'],flush=True)
  except Exception as exc:
   rec=dict(id=cid,status='exception',exception=repr(exc),traceback=traceback.format_exc(),partial_record=data['cases'][slot]);data['exceptions'].append(dict(id=cid,exception=repr(exc)));checkpoint(rec);print(cid,repr(exc),flush=True)
 data['summary']=dict(case_count=len(data['cases']),positive_verified_ids=[c['id'] for c in data['cases'] if c['status']=='completed_positive_verified'],exception_ids=[e['id'] for e in data['exceptions']],total_evaluations_90=sum(c.get('summary',{}).get('evaluated_90_count',0) for c in data['cases']),total_peak_verifications_120=sum(c.get('summary',{}).get('verified_120_count',0) for c in data['cases']),global_optimization_certified=False,FULL_certified=False,real_dx_volume_certified=False)
 data['status']='completed_with_failures' if data['exceptions'] or len(data['summary']['positive_verified_ids'])<12 else 'completed_positive_finite_probes';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
