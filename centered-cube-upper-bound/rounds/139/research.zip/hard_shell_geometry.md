# R139：外硬来源载体上的精确壳生成函数

状态：固定参数公式与有价选择器覆盖分别陈述。只写本文件；不重证主代理/Astra 的 α 余量，不把外硬 z 换成辅助 bad 来源，不操作 Git/PDF。

## 1. 准确量词与未加 p 的壳质量

固定 n≥1、0<H<R、L>0、s∈[0,1]、任意 y,z∈Rⁿ。令
\[
 h_R(x-z)=R^{-n}1_{\{|x_i-z_i|\le R/2\ \forall i\}},\qquad
 p(x-y)=P_{s,L}(x-y)=\prod_i L^{-1}p_s((x_i-y_i)/L),
\]
\[
 p_s(u)=(1-s)1_{|u|\le1/2}+s\phi(u),\qquad
 d_H(x,z)=\#\{i:|x_i-z_i|>H/2\}.
\tag{HS1}
\]
在单独的真实硬载体 h_R dx 下，各坐标均匀独立，故对 j=0,...,n，
\[
 \int h_R(x-z)1_{\{d_H=j\}}dx
 ={n\choose j}(H/R)^{n-j}(1-H/R)^j.
\tag{HS2}
\]
这只属于固定 z 的 Lebesgue 载体；不表示来源 ν 的坐标独立。加入 p 后不得沿用相同 binomial 概率或以 sup p 作为本稿的主要费用。

## 2. 保留真实 p 的一维系数与整维表达

定义 \(\Phi(u)=\int_{-\infty}^u\phi(r)dr\)，以及实际区间概率
\[
 M_s(\delta,q)=
 (1-s)\big|[\delta-q,\delta+q]\cap[-1/2,1/2]\big|
 +s[\Phi(\delta+q)-\Phi(\delta-q)].
\tag{HS3}
\]
对每个固定来源差 \(\delta_i=(z_i-y_i)/L\)，令
\[
 a_i=R^{-1}M_s(\delta_i,H/(2L)),\quad
 c_i=R^{-1}M_s(\delta_i,R/(2L)),\quad
 b_i=c_i-a_i\ge0.
\tag{HS4}
\]
这些系数保留 y−z、s 及全部 L/R/H 依赖；a_i/c_i 是联合密度下的核心坐标概率，不是 H/R。其量纲为长度的 −1 次方。

对任意 t≥0，非负 Tonelli 与真实产品积分给
\[
 \boxed{\int p(x-y)h_R(x-z)t^{d_H(x,z)}dx
 =\prod_{i=1}^n(a_i+t b_i).}
\tag{HS5}
\]
壳 j 的真实联合质量是多项式的 j 次系数
\[
 S_j(y,z)=\sum_{|I|=j}\prod_{i\in I}b_i\prod_{i\notin I}a_i,
 \qquad \sum_jS_j=\prod_ic_i.
\tag{HS6}
\]
尤其核心补集只收一次：\(\int p h_R1_{d_H\ge1}dx=\prod_i c_i-\prod_i a_i\)。这不是无量纲概率，整维联合质量的量纲为长度的 −n 次方，与原 p h_R dx 一致。

原严格 s>0 时 φ>0，所有 c_i>0。令 \(\pi_i=b_i/c_i\)，则归一联合载体 \(p h_Rdx/\prod c_i\) 下 d_H 为参数 π_i 的 Poisson-binomial；独立性仍只来自这个固定 y,z、固定参数的真实 dx 产品，不能平均成 ν 或 β 的独立坐标。

## 3. 显式尾价格与硬重叠损失

对整数 D_*∈[1,n] 和任意 u≥0，HS5 给无需 sup p 的真实 Chernoff 界
\[
 \int p h_R1_{\{d_H\ge D_*\}}dx
 \le\inf_{u\ge0}e^{-uD_*}\prod_i(a_i+e^ub_i)
 =\prod_ic_i\inf_{u\ge0}
 \exp\left[-uD_*+\sum_i\log(1-\pi_i+e^u\pi_i)\right].
\tag{HS7}
\]
写 \(\mu(y,z)=\sum_i\pi_i\)，由 \(\log(1+x)\le x\)，当 D_*≥μ>0 时可进一步取 u=log(D_*/μ)，得
\[
 \int p h_R1_{d_H\ge D_*}dx
 \le\prod_ic_i\exp\{-D_*\log(D_*/\mu)+D_*-\mu\}.
\tag{HS8}
\]
μ=0 的正壳质量为0；若 s=0 导致某 c_i=0，则整维联合载体质量为0，不在该行定义条件概率。HS7--8 的每个 π_i、μ 和质量 \(\prod c_i\) 都显式依赖当前 y−z，不能给来源差距作独立平均。

为解释定位作用，记
\[
 u_i^T=\big|[\delta_i-T/(2L),\delta_i+T/(2L)]\cap[-1/2,1/2]\big|,
 \quad v_i^T=\Phi(\delta_i+T/(2L))-\Phi(\delta_i-T/(2L)).
\]
一般偏移下恰有
\[
 \boxed{\pi_i=
 \frac{(1-s)(u_i^R-u_i^H)+s(v_i^R-v_i^H)}
 {(1-s)u_i^R+sv_i^R}.}
\tag{HS9}
\]
\(u_i^R-u_i^H\) 是真实硬 p 在载体内而落于核心外的显式一维损失，不能省略。如果 s<1 且 u_i^R>0，则
\[
 \pi_i\le\min\left\{1,
 \frac{u_i^R-u_i^H}{u_i^R}
 +\frac{s}{1-s}\frac{v_i^R-v_i^H}{u_i^R}\right\}.
\tag{HS10}
\]
当硬重叠很小时这个条件界可能粗，但 c_i 同时保留了该小重叠；不能丢掉 c_i 后只按概率收壳价。如果 u_i^R=0、s>0，条件概率为 \((v_i^R-v_i^H)/v_i^R\)，而未归一质量 c_i=sv_i^R/R 仍有 s 的费用。

诊断特例 y=z、L≤H≤R：硬 p 全在核心，u_i^R=u_i^H=1，故
\[
 \pi_i=\frac{s\int_{H/2<|x|\le R/2}\phi_L(x)dx}
 {1-s+s\int_{|x|\le R/2}\phi_L(x)dx}
 \le\frac{s}{1-s}\int_{H/2<|x|\le R/2}\phi_L(x)dx
\tag{HS11}
\]
只在 s<1 使用最后一式；s=1 保留准确比值。它说明均匀载体的1−H/R不能替代联合 p 的壳概率。此特例仅解释生成函数，不替代一般 y−z 的 HS9，更不作为原特殊族付款定理。

## 4. d 壳内 K₀ 下界与 T 的精确接合

固定 s>0，并定义
\[
 m_s=1-s+s\phi(1/2),\quad
 \beta_H=s\phi(R/(2H)),\quad \chi_H=\beta_H/m_s\in(0,1).
\]
在外硬载体内，核心坐标的低核因子至少 m_s，外壳坐标至少 β_H。因此
\[
 \boxed{K_0(x-z)=P_{s,H}(x-z)
 \ge H^{-n}m_s^{n-d_H}\beta_H^{d_H}.}
\tag{HS12}
\]
原 H₀/T 定义恰满足
\[
 H_0=g c_j^{-1/2}m_s\ell^{1/(2n)},\quad
 T=\frac{c_j^{n/2}}{g^n\sqrt\ell}
 =\frac{m_s^n}{H_0^n},\qquad\ell=1+\log n.
\]
故壳内准确比较为
\[
 \boxed{K_0/T\ge(H_0/H)^n\chi_H^{d_H}.}
\tag{HS13}
\]
例如只由此下界认证 K₀≥T 的壳须满足 \(d_H\log(1/\chi_H)\le n\log(H_0/H)\)。实际无钳位 H=H₀ 时，d=0 得到K₀≥T，正壳则不能由该下界自动认证；下钳位 H=a>H₀ 时，甚至 d=0 的这个下界也不够，不能反向断言实际K₀<T。上钳位 H=b<H₀ 时 H≥R，已不属于本稿H<R的非空外壳情形，硬载体上d=0。

保留真实 p，任意 ζ>0 的逆核壳费用也有明确生成函数上界
\[
 \int p h_R(T/K_0)^\zeta dx
 \le(H/H_0)^{n\zeta}
 \prod_i(a_i+\chi_H^{-\zeta}b_i).
\tag{HS14}
\]
若再限制d≥D_*，完整上界显式为
\[
 \int p h_R(T/K_0)^\zeta1_{d_H\ge D_*}dx
 \le (H/H_0)^{n\zeta}\cdot
 \inf_{u\ge0}e^{-uD_*}\prod_i(a_i+e^u\chi_H^{-\zeta}b_i).
\]
ζ 与原 γ=1+1/n 不混用；该式显示壳概率与壳内低核损失必须同账，并未把逆核价格当常数。

## 5. 原尺度关系的准确形式与费用

令 m=min(L,R)、M=max(L,R)，\(r_j=c_jg/m\in[1,\gamma]\)。由g²=mM，准确有
\[
 \boxed{H_0=M(m/M)^{1/4}r_j^{-1/2}m_s\ell^{1/(2n)}.}
\tag{HS15}
\]
所以“约为M m_s”还带实际比例与对数因子，不能写成等式。原b≤2a只给m/M≥1/2，因而
\[
 2^{-1/4}\gamma^{-1/2}Mm_s\ell^{1/(2n)}
 \le H_0\le Mm_s\ell^{1/(2n)}.
\]
这些尺度因子一旦取n次幂，其费用仍须保留；不能从一维常数比较宣称维数价格免费。

实际H≥a、R≤b≤2a且H<R时，1<R/H≤2，故 \(\phi(R/(2H))\ge\phi(1)>0\)。严格 \(s>1-2^{-1/n}\) 保证χ_H>0，并只给例如
\[
 \chi_H^{-1}\le\frac1{\phi(1)(1-2^{-1/n})}.
\tag{HS16}
\]
这是可达随n增长的价格，不是每个壳的免费常数。HS15--16不控制偏移硬重叠损失HS9，也不保证HS7里的μ小或足以抵消HS14的\(\chi_H^{-\zeta d}\)。

## 6. 实际选择器的一项有价覆盖

HS5 的乘积身份要求 L/R/H/s 在 dx 积分中固定。它不能逐 x 选参数后继续当作 Poisson-binomial 公式。以下给一个明确的合法覆盖价格，而非免费冻结。

在一个参数单元 \(\mathcal C\) 内，设
\[
 L_-\le L(x)\le L_+,\quad R_-\le R(x)\le R_+,\quad
 s_-\le s(x)\le s_+,\quad H(x)\ge H_-,
\]
其中 L_+/R_+ 是该单元上端点，不是原第二测试尺度 L⁺。令
\[
 \kappa_s=1+s_+-s_-,\qquad \widetilde s=s_+/\kappa_s,
\qquad E_{\mathcal C}=
 \left[\kappa_s\frac{L_+}{L_-}\frac{R_+}{R_-}\right]^n.
\tag{HS17}
\]
此处 \(p_{s,L}(r)=L^{-1}p_s(r/L)\) 为一维密度。φ 偶单调及硬支持包含给每坐标
\[
 p_{s(x),L(x)}(r)
 \le\kappa_s(L_+/L_-)p_{\widetilde s,L_+}(r).
\]
证明使用 \(\kappa_s(1-\widetilde s)=1-s_-\)、\(\kappa_s\widetilde s=s_+\)；没有取 p 的 supremum。硬载体同时满足 \(h_{R(x)}\le(R_+/R_-)^nh_{R_+}\)。这些是逐 x 界，选择器可依赖全部坐标，并不需要它独立于来源。

由于 H(x)≥H_-，\(d_{H(x)}\ge D_*\Rightarrow d_{H_-}\ge D_*\)，故
\[
 \boxed{\int_{x\in\mathcal C}p_{s(x),L(x)}(x-y)h_{R(x)}(x-z)
 1_{d_{H(x)}\ge D_*}dx
 \le E_{\mathcal C}
 \int P_{\widetilde s,L_+}(x-y)h_{R_+}(x-z)
 1_{d_{H_-}\ge D_*}dx.}
\tag{HS18}
\]
若 H_-≥R_+，D_*≥1 的右侧为0；否则按 HS4--8 的固定参数生成函数计算，仍保留当前 y−z。宽参数单元的价格可指数大；窄单元可以减小 E_C，但单元数、实际不交覆盖与总求和必须另计。H₀/钳位/其他原门的变化也不能从 HS18 消失；若用于 HS13 的 K₀/T 认证，还须在该单元内保留相应 H₀/H、s 与 χ 的上下价格。

HS17--18 仅为真实有价的前向 p h_R 接口，本稿不设计 n 次幂笛卡尔网格。它不顺便控制逆 K₀：离散 s 或 H 后，K₀ 下界需要独立保留严格正的 s 下端点、尺度及 core/outer 因子；不能把 p 的上包络反向取倒数。选择器/分层总价在此仍未支付。

## 7. 来源、核心补集与完整停点

对于一个固定参数块，即使 ν 任意相关，非负 Tonelli 仍给无粗 p sup 的真实表达
\[
 \int d\beta(y)d\nu(z)\int p h_R1_{d_H\ge D_*}dx
 =\int d\beta(y)d\nu(z)\sum_{j\ge D_*}S_j(y,z).
\tag{HS19}
\]
若保留额外 history/high 门，可在原正上界中只删除这些≤1因子，不能将其搬给负项。HS19 不允许将 β、ν 的坐标差距平均成独立 Bernoulli；给 c_i/π_i 作这种平均会改变原相关来源。原 β−ν 与硬 z 因子继续保留。

固定 y,z 的全部 d 壳已经由 HS5--6 有限求和一次，没有每壳重新领取同一个 hard 行帽。实际核心补集是否有输入无关可求和价，仍须支付以下明确内容：

- HS9 的偏移硬重叠损失与全部一维 soft 区间质量；不能只取 HS11 的居中特例。
- HS13--16 的 H₀/H 钳位比例、χ 的逆幂及维数价格；若用低核倒数，则必须与同一 HS5 生成函数共同估计。
- HS17--18 的选择器覆盖价格和单元总和；固定块公式不认证全接收域或免费跨 j。
- 原 \(q^{-1}\)、真实 high/history、后续来源 \(\Pi_t\) 与时间积分、唯一 j/种子求和以及 signed \(2\Lambda\)。本稿仍带 raw 外硬 \(h_R\nu(z)\)，不另外乘硬来源先积分版本的16/3。

原 H₀≈max(L,R)m_s、严格 s 下门及 b≤2a 确保了核范围与正性，未给上述 y−z 分布和外预算。HS7 的显式 Chernoff 价可在**实际验证**π_i后用于指定几何层；它不自动证明整个核心补集小，也不登记 \(\varepsilon X+\sqrt n\operatorname{polylog}(n)W_\beta\)。

最终结果：获得精确壳质量、保留真实 p 的产品生成函数、一般偏移损失、低核壳下界与有价自适应覆盖。没有重证 α 剩余公式、没有根阶猜测或数值拟合、没有新负项消费。一般目标仍未证明；交付后停止。
