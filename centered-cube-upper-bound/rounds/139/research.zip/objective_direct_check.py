"""Independent original-t scalar quadrature for one saved verified candidate."""
from pathlib import Path
import sys,json
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=80
root=Path(__file__).resolve().parent
out=json.loads((root/'joint_objective_probe.json').read_text());src=json.loads((root/'active_traffic_v2.json').read_text())
case=next(c for c in out['cases'] if c['id']=='I1');s=next(c for c in src['cases'] if c['id']=='I1')
r=next(r for r in case['verifications'] if r['node_id']==case['summary']['best_verified_node_id'])
nu=list(map(mp.mpf,r['nu']));rho=list(map(mp.mpf,r['rho']));terms=[]
for p in r['time_piece_records']:
 seg=s['score_segments'][p['segment']];cs=list(map(mp.mpf,seg['c']));ks=seg['k'];pairs=[divmod(q['pid'],6) for q in p['pair_contributions']]
 def integrand(t):
  w=[c*t**(-k) for c,k in zip(cs,ks)];e=sum(n*v for n,v in zip(nu,w))
  return sum(rho[i]*nu[i]*nu[j]*(ks[i]-ks[j])*w[i]*w[j] for i,j in pairs)/(e*e*t)
 terms.append(mp.quad(integrand,[mp.mpf(p['lo']),mp.mpf(p['hi'])]))
f=mp.mpf(r['hard_prefactor'])*sum(terms);reference=mp.mpf(r['objective_F']);err=abs(f/reference-1)
assert err<mp.mpf('1e-60')
print(json.dumps({'case':'I1','node_id':r['node_id'],'dps':80,'F':mp.nstr(f,75),'relative_error':mp.nstr(err,12),'threshold':'1e-60','pass':True,'scope':'independent original-t integration with saved masks; not interval or mask certificate'},indent=2))
