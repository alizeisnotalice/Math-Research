# R139 硬来源—RC余额独立先审

本稿先核原RT1–6及既有NG2代数，不读取作者 `joint_hard_margin.md`。仅写本文件，无git/PDF，不扩展长反例。一般根阶预算尚未证明。

## HMA1. 必须共同固定的参数与精确残余身份

固定原同一ω,V,j,x,y与共同实际s,L,R,g,H=Hhat,T,q,ν,Q_J,E,U,α。随后对外hard来源z积分时，它们须是这一共同对象；原history接受因子可随z变化并保持在[0,1]。若另一个选择器依z重选这些容量/核参数，不能把不同α余额直接合并成以下同一ν积分。

保留实际soft下门s>1−2^(−1/n)、s≤1，D≥1，J>0，Q_J=∫Jν>0，FIRST ∫K0ν≤q。记

\[
U(z)=1_E(z)\min(TA(z),DK_0(z)),
\quad F_{rec}=U+\alpha J,
\quad\alpha Q_J=Dq-\int U\,d\nu.
\]

定义非负原K0残余（不是原ρ_z）

\[
\mathcal R(z)=DK_0(z)-U(z)
=D1_{E^c}(z)K_0(z)+1_E(z)(DK_0(z)-TA(z))_+.
\]

于是准确身份

\[
\boxed{\alpha Q_J=D\left(q-\int K_0d\nu\right)
+\int\mathcal R(z)d\nu(z).}\tag{HMA1}
\]

三个费用：FIRST松弛、E外完整K0余额、E内K0超过TA的残余。α不是“未消费整个∫K0”且不能把E内已在U支付的DK0再领一次。

对任意不交划分C_j，有∑∫_Cj𝓡≤αQ_J；在某bad子域D_g⊂Eᶜ上𝓡=DK0，所以原bad容量可保留。但若同时加入硬盒C的残余，必须写D_g与C的不交部分或取并集；不能把重叠D_g∩C的DK0收两次。

原外hard z不自动是bad，也不等同内bad来源。z∈E且TA(z)≥DK0(z)时𝓡(z)=0，哪怕K0(z)很大也没有这份K0残余可再利用。不能用一个未经扣U的硬质量去控制共同α。

## HMA2. 硬内盒/外壳的精确扣除

令Q_H(x)={z:‖x−z‖∞≤H/2}、Q_R(x)为外hard支撑，C=Q_H∩Q_R、S=Q_R\Q_H。外hard核h_R(x−z)=R⁻ⁿ1_QR，原history因子η_hist(z)∈[0,1]。真实盒内下界

\[
k_H=m_s^n/H^n>0,\qquad m_s=1-s+s\phi(1/2),\qquad K_0(z)\ge k_H\ (z\in C)
\]

包括closed hard边界。定义

\[
\varepsilon(z)=1-U(z)/(DK_0(z))\in[0,1],
\]

则𝓡=DK0 ε；Eᶜ上ε=1，E内ε=(1−TA/(DK0))_+。该ε是原K0剩余比例，不能误认成good端ρ。准确可用的硬加权残余帽为

\[
\boxed{\frac1{qR^n}\int_C\varepsilon(z)\eta_{hist}(z)d\nu(z)
\le\frac{\alpha Q_J}{Dk_HqR^n}.}\tag{HMA2}
\]

它只支付带ε的原hard质量。全盒hard质量需要把U费用显式加回：

\[
\boxed{\frac1{qR^n}\int_C\eta_{hist}d\nu
\le\frac{\int_C\eta_{hist}U\,d\nu+\alpha Q_J}{Dk_HqR^n}.}\tag{HMA3}
\]

因此分盒后E内U不能免费丢掉；只取C∩Eᶜ则U=0。外壳S应保留真实∫_S𝓡与∫_SU，或使用另经核验的K0下界并支付其参数价。仅凭盒内k_H，不能给S套同一核下界。

## HMA3. 可用的ρ_v联合帽与clamp参数费

对actual good目标v，在A_v>0、Q_J>0时记

\[
a_v=(1-DK_v/(TA_v))_+,\quad
\rho_v=(a_v-\alpha J_v/(TA_v))_+.
\]

既有NG2标量代数给ρα≤a_v²TA_v/(4J_v)，仅用于原固定共同α，不重选。由HMA3，内盒全硬质量的联合上界为

\[
\rho_v\frac1{qR^n}\int_C\eta_{hist}d\nu
\le\frac{\rho_v\int_C\eta_{hist}U d\nu}{Dk_HqR^n}
+\frac{Q_Ja_v^2TA_v}{4Dk_HqR^nJ_v}.
\tag{HMA4}
\]

第一项是可能同在E的hard来源已耗U费用，不能免费删去。C∩Eᶜ的第一项为0；但不能假定整个C属于Eᶜ。

另有一个不需硬B强化的保守margin：U(z)≤T（A≤1），所以在C上𝓡(z)≥(Dk_H−T)_+。若

\[
\lambda_{core}:=Dk_H-T>0,
\]

则共同α满足αQ_J≥λ_core∫_Cη_histν，从而

\[
\boxed{\rho_v\frac1{qR^n}\int_C\eta_{hist}d\nu
\le\frac{Q_J}{q}\Gamma_v\le\Gamma_v,\qquad
\Gamma_v=\frac{a_v^2TA_v}{4J_v\lambda_{core}R^n}.}\tag{HMA5}
\]

所有参数费保留，尤其λ_core可能小或非正，J_v、Rⁿ、T与A_v不能消去。A=0、B(v)=1或Q_J=0零交通按原约定处理，不计算Γ分母。

原RT6有TH0ⁿ=m_sⁿ，κ_H=k_H/T=(H0/H)ⁿ，H=max(a,min(b,H0))。H0≥a时κ_H≥1；H0<a下钳位H=a时κ_H<1。保守λ_core>0准确等价Dκ_H>1，不能由D≥1、κ_H≥1把等号当严格positive margin；下钳位可能完全不满足。实际s>1−2^(−1/n)始终保留，未置s=0。

若另需利用原非空τ<h_time≤g的时间差，A(z)≤η_A=1−(τ/h_time)ⁿ<1可把margin加强为T(Dκ_H−η_A)>0。其逆数仍应付，Dκ_H=1时可能仅剩(τ/h_time)ⁿ的指数小隙；不能借该加强声称参数费无维数损失。本轮主候选HMA5只需保守U≤T版。

外壳S=Q_R\Q_H保留原交通。若R>H，可用K0≥H⁻ⁿ[sφ(R/(2H))]ⁿ的合法外hard盒下界，但其sⁿ、尺度与margin价必须完整保留，不能沿用内盒k_H。对多个不交margin域，应由同一身份αQ_J≥∑λ_i∫_Ciη_histν控制其**加权和**，不可每域独立领一份α容量再无证合并。

## HMA4. 原硬B的精确历史核验

按主代理补充要求，实读R122 `mixed_test_capacity_private.md` MC14：

\[
B_r(w)=1_{\{R\le L\}}1_{Q_R(x)}(w).
\]

同轮 `mixed_capacity_proof_audit_private.md` 的相应审段及R125 `joint_geometry_source_budget_private.md` JSB12前定义均一致。**B不是整个L硬盒**；它是R≤L条件下的R硬盒捕获指示，属于原RC沿用的硬门而非另一个币/标记。

因此外hard z满足z∈Q_R且R≤L时，确实B(z)=1⇒z∉E⇒U(z)=0。此情况下可直接使用未扣U的原K0容量（仍只在该actual硬门分支），但描述必须改成准确R盒定义。R>L时B=0，该强化没有资格。主代理的保守U≤T版无需这项强化，避免依赖任何未核盒身份。

## HMA5. 新Γ小子支的独立根阶筛查（未读作者稿）

采用HMA5已经严格定义的共同残余margin λ_core>0及Γ_v，新增原正指示：外hard z∈C=Q_H∩Q_R、actual good v且Γ_v≤(n+1)⁻³。先在同一x,y及共同参数上积分hard z，联合ρhard帽≤Γ_v≤(n+1)⁻³。这里ρ_v不得随z重选，history≤1仅在明确正上界放松；内bad源不是外hard z。

固定原(ω,V,j,y,t)后，Π_t在x之前构造，是同一真实概率的两份拷贝。只对正项放松门并用δ≤n，可逐点把源对积分上界为n(n+1)⁻³；来源相关、不乘积、e_t小均不影响这一步的概率质量1。原e_t=0行零处理。实际时间窗⊂[τ,h_time]且继承τ≥a_scale、h_time≤b，故dt/t长度≤log2。

固定原单一[a_scale,b]、b≤2a_scale且γ=1+1/n。合法j按同一个原比例带/时间合同计数O(n)；由min(L,R)/g≥√(a_scale/b)、c_j处于该比值与γ倍之间，整数候选数≤n+2，保守使用N_j≤2(n+1)。唯一j(x)仍在原交通中；本证明主动付这份有限j包络次数，不能又称它免费。若[a,b]随j另选，不能用此同块计数。

**尺度包络。** 预先取网格a_scale、min(b,a_scaleγ),…、b，γⁿ≥2使网格数N_L≤n+1。q_s在|u|上非增，包括hard边界向下跳；L_k≤L≤L_(k+1)给P_(s,L)≤γⁿP_(s,L_(k+1))≤eP_(s,L_(k+1))。故∫sup_(L∈[a,b],s∈[0,1])P_(s,L)≤eN_L∫sup_sP_(s,L_fixed)，grid在x前固定，常数不依y或物理尺度。

**soft包络自证。** 对固定L，F_s=P_(s,L)是同一个全维scalar s的光滑密度多项式。逐点

\[
\sup_{0\le s\le1}F_s\le\frac12[F_0+F_1+\int_0^1|\partial_sF_s|ds].
\]

将乘积混合写成独立Bernoulli(s) latent mask的概率平均，各mask分量都是质量1的产品核；三角不等式积分得

\[
\int|\partial_sF_s|dx\le
\frac{\mathbb E|\operatorname{Bin}(n,s)-ns|}{s(1-s)}
\le\frac{\sqrt n}{\sqrt{s(1-s)}}.
\]

端点导数帽虽奇异但可积，∫₀¹[s(1−s)]⁻¹/²ds=π，F0/F1质量各1，因此

\[
\int\sup_sP_{s,L}dx\le1+\pi\sqrt n/2.
\tag{HMA6}
\]

latent独立性属于原固定核的乘积分解，不是来源ν或Π的坐标独立。full [0,1]仅为数学上界菜单，实际traffic仍保留严格soft下门；s=0不是新actual FIRST测试资格。

恢复原β(y)、唯一j包络及期望（每个原固定块/source β只按原Wβ账出现一次），上述正子支满足

\[
2\Lambda P_{core,small\Gamma}
\le2\Lambda\log2\frac n{(n+1)^3}
N_j\,eN_L(1+\pi\sqrt n/2)W_\beta
\le4e\Lambda\log2(1+\pi/2)\sqrt nW_\beta
<40\Lambda\sqrt nW_\beta.
\tag{HMA7}
\]

这是真实可付款的明确子支：hard质量已由原剩余FIRST与实际ρ联合控制，Π可在x外合法固定，scale/soft/j菜单次数全部收费，β−ν没有替换。若同一β在多个[a,b]块重复使用，必须真实加总而不能沿用单份Wβ；块固定契约及唯一source分配是该根阶结论的范围条件。

外壳Q_R\Q_H、λ_core≤0行及Γ_v>(n+1)⁻³源全部保留原余交通；不假设该子支有固定正覆盖量。不得累计bad容量加hard未消费容量，也不取回N_Z或给负项添加此门。**独立筛查：新小Γ子支及常数40Λ通过准确合同；一般根阶仍未闭合。** 先行证据落盘后才读作者冻结HM1–9。

## HMA6. 作者冻结后审绑定与必要合同修正

HMA1–5先于作者稿读取保存，以上独立推导保持不变。随后实读作者 `joint_hard_margin.md` 原冻结SHA256 `7bfedefff1091083a8b4404e55bff2e7b4c9b466f7f97bba0eac7a25f7acba07`，核验HM1–12及其适用合同。唯一必要修正是壳并集S及认证下界λ_S的选择时机：原“按actual row和v选择”若容许依外hard积分变量z逐源重选，不能对这些不同集合的局部质量使用同一个Γ小帽。作者已收紧HM7、HM8前文、HM12及覆盖段量词，公式不变。

本后审最终绑定修订SHA256 **`9c96174c303728902f8a1ce77f9d90a24128f7730ab8005a4c67c20e577de820`**（已实读并核对）。准确合同为：固定共同ω,V,j,x,y,t,v及共同容量数据，在外hard z积分之前选定一个S⊂Q_R及λ_S>0，在整个该z积分中保持不变；可依上述共同数据，不得依正在积分的z逐源重选。source选择可依内good v，因下述联合质量帽本就逐v成立。

这是**适用合同收紧**，不是core或最大初始壳并集公式失败。core固定规则及满足自身Γ阈值的单一最大初始壳并集保持有效；未从“每个z各有某个可用集合”推广到其无限制并集。不能对全部候选S分别用HM9后加总且仍只付一次价格。

## HMA7. HM1–8残余、clamp、壳价与联合核验

HM1准确等于HMA1。FIRST Q₀≤q使两项均非负；全程扣除了可能在E的外hard来源U。α为原共同值，标量优化只是该值的上界，不重选α，也不把外hard z当成bad。HM2盒内核界含closed边界；φ偶且非增给每个hard坐标1−s+sφ(|x_i−z_i|/H)≥m_s，因此K₀≥Tκ，不外推到盒外。

作者HM3使用了比独立保守版更尖的真实权余量。R>L时

\[
U(z)\le TA(z)\le T[1-w_h(y,z)],\quad
DK_0(z)-U(z)\ge T[D\kappa-1+w_h(y,z)],
\]

再与残余本来非负合并，故核心上λ_c=T[Dκ−1+ω_c]₊成立。R≤L时由HMA4准确原B门得U=0，λ_c=DTκ。核心有限盒、实际正连续w_h使ω_c>0；不宣称维数无关ω_c下界，1/λ_c完整留在Γ。Dκ=1临界处的ω_c确能使margin正，下钳位则仍需检查Dκ−1+ω_c>0。H₀<a、a≤H₀≤b、H₀>b三种κ分别<1、=1、>1；upper clamp在实际目标H<L₊≤b中不能出现，作者并未借此去除lower clamp。

HM4来自同一残余积分。HM5与HMA5同一标量联合优化，作者定义Γ_c含Q_J/q，较独立先审去掉该比的Γ更尖；两种记号不可混同。m_cρ/(qRⁿ)≤Γ_c及min{16/3,Γ_c}通过，ρ≤1和原hard帽使后者合法。A=0、B(v)=1及Q_J=0行沿原零约定，不在这些行计算Γ分母。HM6用原good核界J_v≥p w_g/K和Q_J/q≤1，准确给

\[
\Gamma_c\le\frac{K a_v^2T}{4\lambda_c pR^n}\frac{A(v)}{w_g(v)}.
\]

其中pRⁿ、A/w_g、λ_c都未免费置常数；good/high门不负责替代Γ小条件。R≤min(L,H)时core等于整个hard载体、λ_c=DTκ在所有clamp都正，是真实几何范围，但不保证每个源的Γ小。

R>H时按严格“外H盒”坐标数m分S_m：inside是≤H/2，outside是>H/2；S₀=core，边界原子不会漏计或重计。外坐标soft项至少sφ(R/(2H))，内坐标至少m_s，故

\[
K_0\ge H^{-n}m_s^{n-m}[s\phi(R/(2H))]^m
=T\kappa\vartheta^m=T\kappa_m.
\]

实际s>1−2^(−1/n)>0使ϑ>0，且R>H给ϑ≤1。HM7由不交S_m上的逐点残余下界求和，**仅一份**αQ_J；任何selected union必须保留自己的统一λ_S，不能把壳费ϑ^(−m)删去，也不能把重叠bad容量再加一份。本稿没有将HM7身份登记为一般root付款。

HM8正确指定了真正被支付的正子支：单一共同S、λ_S>0、Γ_S≤(n+1)⁻³，以及原实际H<L₊、C_J≤3、good/high/FA/Ψ等门。阈值针对原ν质量与同一ρ的联合帽，不要求ν坐标独立、不假设e_t下界、不先取hard和ρ的两个独立sup。

## HMA8. 单一壳并集的可测选择与积分次序

可测性可直接从真实w_h证实。记

\[
\psi_h(r)=\min\{1,\ b C(r/b)/(c_jh)\},\qquad
w_h(y,z)=\prod_{i=1}^n\psi_h(|y_i-z_i|).
\]

原C连续、正且非增，所以ψ_h亦然。令d=min(R,H)，则有限盒core的inf准确为

\[
\omega_c=\prod_{i=1}^n\psi_h(|x_i-y_i|+d/2).
\]

R>H时每个非空S_m的inf准确为

\[
\omega_m=\min_{I\subset[n],\ |I|=m}
\left(\prod_{i\in I}\psi_h(|x_i-y_i|+R/2)\right)
\left(\prod_{i\notin I}\psi_h(|x_i-y_i|+H/2)\right).
\]

最远端点可逐坐标选取；R>H时选R端点的坐标确在outside，其他坐标H端点属于inside。故strict outside约定不影响该inf，且有限min与乘积使ω_m、λ_m jointly measurable。ν(S_m)作为移动盒/壳的非负可测指示积分亦可测。

例如预先列有限初始壳并集S^(k)=⋃_{m≤k}S_m，令λ^(k)=min_{m≤k}λ_m，对满足λ^(k)>0且自身Γ^(k)≤阈值的k取最大索引，空集为fallback，即是可测、唯一、不重复的选择。λ^(k)须对全部所选层认证，不依源质量为零就删掉几何下界要求。任意其他预先给出的可测单一S规则也可用HM12；没有证明任意不可测优化规则自动可用。

先固定x,y,t,v和共同容量数据并选S，再在外hard z积分保留1_S，history≤1给

\[
\frac1q\int_S h_R(x-z)a_{history}(z)d\nu(z)\,\rho_v\le\Gamma_S(v)\le(n+1)^{-3}.
\]

这一步允许S依v，因为逐v成立。之后可放松其余正门，用原两份Π_t概率和δ≤n，将source pair积分帽为n/(n+1)³；Π_t在固定ω,V,j,y,t后不依x/外hard z，e_t=0按原零行。两个e_t分母已在两概率内，既没有裸e_t省略，也没有把dx从source后验依赖中非法提出。不得先让ν/α/核参数随z变化再称同一积分，亦不得对每个z重选S后仍用上述ν(S)帽。

## HMA9. HM9–12全部选择器价格与TeX转写

作者HM10的soft包络与HMA6一致：固定全维scalar s的latent Bernoulli展开，各mask核质量1；只用核乘积，不用ν独立。端点s=0、1只在包络菜单中，actual traffic仍保留严格soft下门。导数帽在(0,1)可积，质量界D_n≤1+π√n/2≤3√n通过。作者指出此soft工具已见R117，不将其记为本轮新一般核定理；本轮新付款是其与shared Γ阈值接口的接合。

作者用较松但正确的菜单价：N_L≤2n+3，逐点向上grid给P_(s,L)≤γⁿP_(s,L_grid)≤3P_(s,L_grid)，包含hard跳边界；同一preassigned [a,b]的legal j满足N_j≤n+2。每j的共同时间窗⊂[a/c_j,bc_j]，c_j≤1、b/a≤2，长度≤log2；可上放至x无关的窗口，然后把真实Π_t先固定再积分接收kernel包络。没有把自适应L/s/x选择当fixed-kernel免费积分。

因n(n+2)(2n+3)≤3(n+1)³，作者完整账为

\[
P_I^{hard-joint}\le
\frac{n(n+2)3(2n+3)\log2}{(n+1)^3}D_nW_\beta
\le27\log2\sqrt nW_\beta,
\]

故原signed coefficient 2Λ给54log2 Λ√nWβ<40Λ√nWβ。此为包括dx、β、time、j、scale、soft菜单的真实价格；单一S不额外加全部候选的价格。原唯一source/receiver分配和每块Wβ只计一次是必需合同。同一β跨多个[a,b]重用须加真实账，不能在每块各领全份Wβ。只放松正门，上述付款先与既有已付正支剔除交集；N_Z、负账和补集原公式保留，无负门删改，也无新增epsilon槽。

已读主代理 `research.tex` 当前冻结数学内容（本次所读SHA256 `477d3d07375299a458547fe114ed08615e97ec1ae926c7a8259ea0ee7820615d`），核对核心(1)–(5)：(1)逐字数学等价HM1；(2)是其标量二次优化；(3)保留Q_J/q、λ_S、J_v、Rⁿ，等价HM5/8一般集合版；(4)是不交shell共享容量HM7；(5)与HM9一致为40Λ√nWβ。core clamp与B的定义、shellκ_d、原raw q分母及两份Π中的两个e_t分母均转写正确。TeX定理显式S/λ在外hard z积分前共同选定，不依z逐源重选，与修订作者稿相容。TeX从27log2乘2Λ得40Λ上帽的常数亦正确；不另做编译/PDF。

**后审结论：修订冻结稿HM1–12及research.tex(1)–(5)在上述原合同内通过。** 这是新可付小Γ子支，不是一般根阶闭合；未选壳、λ_S≤0及Γ_S过大行仍未付，core/壳容量身份没有变成全域覆盖证据。不宣称该子支覆盖多数高likelihood交通。
