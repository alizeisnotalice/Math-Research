import sympy as s
u,v,R,D,n,T,S,F,H=s.symbols('u v R D n T S F H',positive=True)
amgm=s.simplify((1/u**2+1/v**2)/2-1/(u*v)-(u-v)**2/(2*u**2*v**2))
weight=s.exp(D/R)/R**n
layer=s.simplify(-s.diff(weight,R)/weight-(n/R+D/R**2))
change=s.simplify(T/S*s.exp(F-s.log(T))-s.exp(F)/S)
assert amgm==layer==change==0
print('SymPy:',s.__version__)
print('graph Schur identity residual:',amgm)
print('variable-radius layer derivative residual:',layer)
print('Gibbs exponential cancellation residual:',change)
print('Scope: scalar algebra only; no endpoint moment, history, or whole-target certificate.')
