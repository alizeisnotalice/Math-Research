# R442 数值计算索引（完成）

责任：numeric统一本轮独立数值任务，无agent、他人编辑、repo修改或solver。

只读输入：`/tmp/r442_contract.md`，作者消息及`/tmp/r442_mainproof.md`中joint reference/retention精确定义；geometry作者冻结joint primitive、clipped masses及terminal Holder接口。作者已有小样本不重复。

实际计算：
- SymPy一般primitive余项残差0。
- 3个不同affine clipped-level profile，3/4/8 cells；p1/2根式精确积分，经Arb核primitive与count-free Holder。含zero/tiny intersection、unequal density。
- 3个不同posterior模型，2×3×3、3×4×4、4×5×8；12/8/51正ret atoms。实际interval几何p_A、q_v，terminal-conditioned k0，原子级Fraction乘法恒等式及Arb KL链、retention/Jensen价格。含zero、rare、subprob。

命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r442_numeric.py`
环境：Python3.12.14，SymPy1.14.0，flint0.9.0，Arb256bit。环境可用不是原命题认证。

归档输出：`r442_numeric.py`、`r442_numeric.md`、`r442_numeric_certificate.json`、`r442_numeric_run.txt`、`r442_numeric_resources.txt`、本索引；全部位于`/tmp/`，脚本向自身目录输出，不依赖作者脚本。

状态：实际运行通过。仅有限积分／概率接口，不认证原history、cube全场或一般阶数。交付停止。

## 作者独立接口与复现分工
- geometry：SymPy一般导数恒等式及18项Arb检查，命令 `python r442_geometry_check.py`；输出 geometry.result.txt。
- mainproof：三组Fraction后验与有理对数乘积、总Jensen，命令 `python r442_mainproof_check.py`；输出 mainproof.result.txt。
- complement：共同父图参考的局部代数，命令 `python r442_complement_check.py`；输出 complement_check.txt。
上述 python 均指指定独立解释器；最终隔离复跑用于复现，不增加样本覆盖数。
