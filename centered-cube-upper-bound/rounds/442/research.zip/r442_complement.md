# R442 complement：共同父图逆向积分的准确边界

结论：实际中心容量给出一个保留原两来源、阶段、历史与终端核的有限图参考测度，质量至多 \(C_gW\)。但相对密度恰为 \(S/T_G\)；用熵不等式控制剩余端点势时，这个密度代价精确抵消图负项。没有得到新的全 \(J\) 价格，也不把以下参考测度改写称为独立付款。

沿用 /tmp/r442_contract.md、/tmp/r441_main.md 与 /tmp/r435_contract.md。本文只走共同父图这一条路线。记 \(D=\|y-z\|_1\)、\(C_g=1+2n\log(b/a)\)。所有零分支省去；所有参考变量均来自原流，没有重采样来源或终端。

## 1. 实际可变半径中心容量

本附件中 \(\mu(dy)=f(y)dy\) 始终表示完整来源测度，非接收中心测度。

定义
\[
 \kappa(dy,dz)=\frac{G(y,z)}{\sqrt{U(y)U(z)}}\,\mu(dy)\mu(dz),
\qquad
 k_{yz}(dA)=c_A(y)c_A(z)\frac{e^{D/R_A}}{R_A^n}\,dA.
\]
由 \(G\) 对称及 \(U(y)=\int G(y,z)\mu(dz)\)，
\[
 \kappa(\Omega)\le\frac12\iint G(y,z)
 \left(\frac1{U(y)}+\frac1{U(z)}\right)\mu(dy)\mu(dz)\le W. \tag{1}
\]
实际选定的半径可任意依赖中心。令 \(d_j=|y_j-z_j|\)、
\(V(R)=\prod_j(R-d_j)_+\)、\(w(R)=e^{D/R}R^{-n}\)。所有 \(R_A\le R\) 且捕获两来源的中心都在体积 \(V(R)\) 的矩形内。层蛋糕给
\[
 \int k_{yz}\le w(b)V(b)+\int_a^b[-w'(R)]V(R)dR\le C_g. \tag{2}
\]
这里 \(wV=e^{D/R}\prod_j(1-d_j/R)\le1\)，且非空时 \(D/R\le n\)，所以 \((-w')V\le2n/R\)。这一步使用实际中心与实际半径，不引入虚拟父立方体。

## 2. 原终端核不能丢失的密度

令 \(\ell_z(dt)=1_{\{f(z)>t\}}dt/f(z)\)。把原 \(P\) 的其余标记、oldsource 权、冻结的 stage-averaged early 比例、原两条路径和终端统一保留在原条件正核 \(K_t(A,y,z;d\omega)\) 中；它是次概率核乘原系数，逐起始记录总质量不超过 \(S\)。准确地
\[
 dP=\sigma(dA)\pi_A(dy)\pi_A(dz)\ell_z(dt)
          K_t(A,y,z;d\omega). \tag{3}
\]
这里 \(K_t\) 选择原 \(i(t)\)，并未把早期门替换成 true-level cutoff。定义
\[
 d\Lambda=\kappa(dy,dz)k_{yz}(dA)\ell_z(dt)
                    K_t(A,y,z;d\omega)/S.
\]
(1)–(2) 和原逐起始记录行界给
\[
 \Lambda(\Omega)\le C_gW,
 \qquad dP=\frac{S}{T_G}\,d\Lambda. \tag{4}
\]
共同父图的定义和 Tonelli 保证 (3) 在 \(G=1\) 上集中。第二式逐因子由 \(m_A=q_AR_A^n\) 验证。它保持原终端路径；没有用独立终端列帽代替起始重数。故负图项有合法上界
\[
 \int\log T_G\,dP
 \le R\log\frac{S C_gW}{R}. \tag{5}
\]
原保留门给 \(T_G<C/s\)，且 \(T_G\ge qa^n/W>0\)，所以此处对数按有限 \(P\) 可积。这是已允许静态 \(T_G\) 矩的 Jensen 后果，不宣称为新全余项收益。

## 3. 唯一仍缺的联合比较，以及为何容量不足

原目标 integrand 记为
\[
 F=\log\frac{m_t(A)}{B_{AC}(t)}-\Phi_t(v,z),\quad J=\int F\,dP.
\]
图分拆的余因子准确为
\[
 H=F-\log T_G
 =\log\left[
 \frac{m_t(A)}{m_A}\,
 \frac{\sqrt{U(y)U(z)}}{m_v}\,e^{-D/R_A}\,
 \frac{B_{vC}(t)}{B_{AC}(t)}\right]. \tag{6}
\]
全部变量和终端 \(v\) 仍是同一原记录。父图容量 (2) 只控制不含方括号的中心积分；不能把它应用到这个含实际终端与 cell 比值的加权中心积分。

特别地，令 \(\operatorname{Ent}(P|\Lambda)=\int\log(dP/d\Lambda)dP\)。由 (4)，
\(\operatorname{Ent}=R\log S-\int\log T_GdP\)。若直接用 Gibbs 控制 \(\int H dP\)，看似有利的图负项便精确抵消，而且
\[
 \int e^H d\Lambda=\frac1S\int e^F dP. \tag{7}
\]
故有限参考质量 \(\Lambda(\Omega)\le C_gW\) 本身不支付 \(J\)；(7) 只是原联合指数矩的同一写法。原 lowcommon/highrank/history 仍存在于 \(K_t\)，但其行界与实际中心容量目前没有给出 (6) 方括号的加权平均价格。**所缺正是保留这些原门的加权中心—终端比较，而非更多裸图度数或边缘熵界。** 没有这一量化步骤，不能由 (4)–(5) 推出 \(J\le\varepsilon\sqrt nX+C_\varepsilon n\,\mathrm{polylog}(n)W\)。

本轮到此停止：取得准确的共同父图参考及其密度账，定位加权容量这一个缺口；没有新增独立分支或完整 R433 收据。

实际本机 SymPy 1.14.0 核验 Schur 恒等式、可变半径权导数和 (7) 的标量抵消，残差均为零。脚本 /tmp/r442_complement_check.py，输出 /tmp/r442_complement_check.txt。它们不认证未证加权比较或原历史，也未进行有限 LP、反例扫描或模型实验。
