"""R442 mixed primitive: bounded symbolic and interval checks only."""
import sympy as sp
from fractions import Fraction as Q
from flint import arb,ctx
ctx.prec=192
A,c,Y,X,m,Ap,cp,Yp=sp.symbols('A c Y X m Ap cp Yp',positive=True)
p=sp.symbols('p',positive=True)
F=A**p*c**(1-p)*(Y/m)**p
actual=sp.diff(F,A)*Ap+sp.diff(F,c)*cp+sp.diff(F,Y)*Yp-(1-p)*cp*(A*Y/(m*X))**p
remainder=p*Ap*A**(p-1)*c**(1-p)*(Y/m)**p+p*Yp*A**p*c**(1-p)*Y**(p-1)/m**p+(1-p)*cp*(A*Y/m)**p*(c**(-p)-X**(-p))
assert sp.simplify(actual-remainder)==0
print('SymPy general mixed-primitive residual: 0')
def b(x):
    if isinstance(x,Q):return arb(x.numerator)/x.denominator
    return arb(x)
checks=0
# Each tuple denotes exact clipped masses/derivatives with c<=X<=A, c<=Y<=m.
models=[(Q(3),Q(1,4),Q(1),Q(1,2),Q(2),Q(1),Q(1,5),Q(1,2)),
        (Q(7,2),Q(3,4),Q(5,4),Q(1),Q(3),Q(1,2),Q(1,3),Q(1,4)),
        (Q(2),Q(1,2),Q(1),Q(1,2),Q(2),Q(0),Q(1,4),Q(0))]
for row in models:
    AA,cc,YY,XX,mm,da,dc,dy=map(b,row)
    for pp0 in (Q(1,4),Q(1,2),Q(3,4)):
        pp=b(pp0)
        rem=pp*da*AA**(pp-1)*cc**(1-pp)*(YY/mm)**pp+pp*dy*AA**pp*cc**(1-pp)*YY**(pp-1)/mm**pp+(1-pp)*dc*(AA*YY/mm)**pp*(cc**(-pp)-XX**(-pp))
        if row[0]==Q(2): assert rem.contains(0)
        else: assert rem>0
        checks+=1
print('Arb fixed derivative checks:',checks,'PASS')
# Three fixed cell partitions; exact endpoint mass, arbitrary partial fixed mask.
for cs,ys in [([Q(1,5),Q(2,5)],[Q(1),Q(1)]),([Q(1,7),Q(3,7),Q(2,7)],[Q(1,2),Q(1),Q(2)]),([Q(1,3),Q(1,6)],[Q(2,3),Q(1,3)])]:
    for pp0 in (Q(1,4),Q(1,2),Q(3,4)):
        pp=b(pp0)
        lhs=sum((b(x)**(1-pp)*b(y)**pp for x,y in zip(cs,ys)),arb(0))
        rhs=b(sum(cs))**(1-pp)*b(sum(ys))**pp
        if cs==[Q(1,3),Q(1,6)]: assert (rhs-lhs).contains(0)
        else: assert rhs>lhs
        checks+=1
print('PASS',checks,'Arb fixed derivative/Holder checks plus one general symbolic identity.')
print('Scope: mixed clipped-mass primitive and finite endpoint merging; not a native-history model or the unresolved full-center fractional-affinity estimate.')
