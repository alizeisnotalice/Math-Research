"""Independent bounded affine-clipping and posterior-interface checks.
Uses no original-history fixture and no solver. Outputs beside this script.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform
import sympy as sp
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256

def A(x):
 x=F(x);return arb(str(x.numerator))/arb(str(x.denominator))
def logratio(a,b):return (A(a)/A(b)).log()
def pos_or_zero(x):assert x>=0 or x.contains(0)

# General derivative identity; nonnegative remainder has three terms.
a,c,y,x,mv,p=sp.symbols('A c Y X mv p',positive=True)
da,dc,dy=sp.symbols('Aprime cprime Yprime',nonnegative=True)
ff=a**p*c**(1-p)*(y/mv)**p
base=(1-p)*dc*(a*y/(mv*x))**p
remainder=(p*a**(p-1)*da*c**(1-p)*(y/mv)**p
 +p*a**p*c**(1-p)*(y/mv)**(p-1)*dy/mv
 +(1-p)*dc*(a*y/mv)**p*(c**(-p)-x**(-p)))
symres=sp.simplify(sp.diff(ff,a)*da+sp.diff(ff,c)*dc+sp.diff(ff,y)*dy-base-remainder)
assert symres==0

# Fixed positive L1 cell profiles; each listed volume is realizable by interval
# subpieces. Exact A(t)=sum X_C(t). Fixed w is absorbed in c-volume.
clip_specs=[
 ('initial_affine_unequal_density',[F(1),F(3),F(2)],
 [F(3,4),F(1),F(1,4)],[F(1,4),F(1),F(3,4)],[F(1,4),F(1,2),F(1,16)]),
 ('zero_and_tiny_intersection',[F(1),F(4),F(2),F(5)],
 [F(1),F(1,2),F(1),F(1,3)],[F(1,2),F(1),F(2,3),F(1)],
 [F(0),F(1,1000000),F(1,4),F(1,1000)]),
 ('expanded_eight_cells',[F((i%4)+1) for i in range(8)],
 [F((i%3)+1,4) for i in range(8)],
 [F(((i+1)%3)+1,4) for i in range(8)],
 [F(0) if i==0 else min(F((i%3)+1,4),F(((i+1)%3)+1,4))*F((i%4)+1,5) for i in range(8)])]
clip=[]
for label,levels,xvol,yvol,cvol in clip_specs:
 assert all(F(0)<=cc<=xx and cc<=yy for cc,xx,yy in zip(cvol,xvol,yvol))
 mA=sum((f*v for f,v in zip(levels,xvol)),F(0));mV=sum((f*v for f,v in zip(levels,yvol)),F(0))
 Iw=sum((f*v for f,v in zip(levels,cvol)),F(0));knots=sorted({F(0),*levels})
 integral=arb(0);Fend=arb(0);nonzero=0
 for k,(fk,xx,yy,cc) in enumerate(zip(levels,xvol,yvol,cvol)):
  if not cc:continue # primitive identically zero; no c^negative power
  nonzero+=1
  # For t<fk, Y_C/X_C=Yvol/Xvol, so integrate sqrt(A(t)) exactly.
  factor=A(cc)*(A(yy)/(A(mV)*A(xx))).sqrt()
  for l,r in zip(knots,knots[1:]):
   if l>=fk:continue
   r=min(r,fk)
   al=sum((vv*min(f,l) for f,vv in zip(levels,xvol)),F(0))
   ar=sum((vv*min(f,r) for f,vv in zip(levels,xvol)),F(0))
   slope=sum((vv for f,vv in zip(levels,xvol) if f>l),F(0));assert slope>0
   # int sqrt(A) dt = 2/(3 A') [A^(3/2)] endpoints.
   integral+=factor*2/(3*A(slope))*(A(ar)**F(3,2)-A(al)**F(3,2))
  Fend+=(A(mA)*A(fk*cc)*A(fk*yy)/A(mV)).sqrt()
 holder=(A(mA)*A(Iw)).sqrt()
 assert Fend-integral/2>0
 assert holder-Fend>0 or (holder-Fend).contains(0)
 clip.append({'label':label,'cells':len(levels),'nonzero_intersections':nonzero,
  'levels':list(map(str,levels)),'X_volumes':list(map(str,xvol)),
  'Y_volumes':list(map(str,yvol)),'c_weighted_volumes':list(map(str,cvol)),
  'mA':str(mA),'mv':str(mV),'Iw':str(Iw),
  'exact_affine_radical_integral_Arb':str(integral),'sum_terminal_primitives_Arb':str(Fend),
  'Holder_count_free_upper_Arb':str(holder),
  'primitive_margin_F_minus_half_integral_Arb':str(Fend-integral/2),
  'Holder_margin_Arb':str(holder-Fend)})
 print(label,'cells=',len(levels),'half-integral=',integral/2,'Fend=',Fend,'Holder=',holder)

# Geometric references from actual integer-interval parents/terminal cubes,
# fixed positive L1 f on unit cells, and clipped mass at rational t.
def posterior(label,levels,parents,terminals,t,betas,kind):
 K=len(levels);V=len(terminals);mt=[min(f,t) for f in levels]
 mvs=[sum(levels[l:r],F(0)) for l,r in terminals]
 qs=[[mt[j]/mvs[v] if l<=j<r else F(0) for j in range(K)] for v,(l,r) in enumerate(terminals)]
 assert all(sum(row,F(0))<=1 for row in qs)
 totals={name:arb(0) for name in ['J','raw','H','Fit','fullKL','terminalKL','alpha_entropy']}
 R=F(0);B=sum(betas,F(0));records=[];conditional_diff=False;atoms=0
 for z,((pl,pr),beta) in enumerate(zip(parents,betas)):
  parent_mass=sum(mt[pl:pr],F(0));pA=[mt[j]/parent_mass if pl<=j<pr else F(0) for j in range(K)]
  assert sum(pA,F(0))==1
  active=[j for j in range(pl,pr) if levels[j]>t];assert active
  Q=[[F(0)]*V for _ in range(K)]
  for j in active:
   allow=[v for v,(l,r) in enumerate(terminals) if l<=j<r];assert allow
   weights=[F(1+(j+2*v)%4) for v in allow];den=sum(weights,F(0))
   for v,w in zip(allow,weights):Q[j][v]=F(1,len(active))*w/den
  assert sum((sum(row,F(0)) for row in Q),F(0))==1
  FF=[[F(0)]*V for _ in range(K)]
  for j in range(K):
   for v in range(V):
    if not Q[j][v]:continue
    if kind=='basic':fkeep=F((z+j+v)%3+1,3)
    elif kind=='rare':fkeep=F(0) if z==2 else (F(1,1000) if (j//2+v)%2 else F(1,10000))
    else:fkeep=F((z+2*j+v)%5,5) if (j,v)!=(3,V-1) else F(1,1000000)
    assert 0<=fkeep<=1;FF[j][v]=fkeep
  ret=[[Q[j][v]*FF[j][v] for v in range(V)] for j in range(K)]
  alpha=sum((sum(row,F(0)) for row in ret),F(0));R+=beta*alpha
  Qv=[sum((Q[j][v] for j in range(K)),F(0)) for v in range(V)]
  rv=[sum((ret[j][v] for j in range(K)),F(0)) for v in range(V)]
  if not alpha:
   records.append({'base':z,'beta':str(beta),'alpha':'0','zero_acceptance_skipped':True});continue
  ae=-A(beta*alpha)*A(alpha).log();totals['alpha_entropy']+=ae
  for v in range(V):
   if not rv[v]:continue
   pv=rv[v]/alpha;qv=Qv[v];assert qv>0
   totals['terminalKL']+=A(beta*rv[v])*logratio(pv,qv)
   for j in range(K):
    if not ret[j][v]:continue
    k0=Q[j][v]/Qv[v];k=ret[j][v]/rv[v]
    marginal=sum(Q[j],F(0));conditional_diff|=(k0!=marginal)
    assert pA[j]>0 and qs[v][j]>0
    # Algebraic log decomposition certified before any transcendental rounding.
    assert qs[v][j]/pA[j]==(k0/pA[j])*(k/k0)/(k/qs[v][j])
    wt=beta*ret[j][v];atoms+=1
    for name,num,den in [('J',qs[v][j],pA[j]),('raw',k0,pA[j]),('H',k,k0),('Fit',k,qs[v][j])]:
     totals[name]+=A(wt)*logratio(num,den)
    totals['fullKL']+=A(wt)*logratio(ret[j][v]/alpha,Q[j][v])
  records.append({'base':z,'beta':str(beta),'alpha':str(alpha),
   'pA_geometry':list(map(str,pA)),'qv_geometry':[list(map(str,row)) for row in qs],
   'Q_cell_terminal':[[str(x) for x in row] for row in Q],
   'retention_F':[[str(x) for x in row] for row in FF],
   'retained_cell_terminal':[[str(x) for x in row] for row in ret]})
 assert R>0 and B>=R
 bound=A(R)*logratio(B,R)
 gap=totals['J']-totals['raw']-totals['H']+totals['Fit'];assert gap.contains(0)
 chain=totals['fullKL']-totals['H']-totals['terminalKL'];assert chain.contains(0)
 for value in [totals['H'],totals['Fit'],totals['alpha_entropy']-totals['H'],bound-totals['alpha_entropy']]:pos_or_zero(value)
 assert conditional_diff
 out={'label':label,'cells':K,'base_labels':len(parents),'terminals':V,'retained_atoms':atoms,
  'density_levels':list(map(str,levels)),'t':str(t),'parents':parents,'terminals_geometry':terminals,
  'B':str(B),'R':str(R),'values_Arb':{k:str(v) for k,v in totals.items()},
  'R_log_B_over_R_Arb':str(bound),'decomposition_residual_Arb':str(gap),
  'KL_chain_residual_Arb':str(chain),'k0_genuinely_conditioned_on_terminal':conditional_diff,
  'records':records}
 print(label,'grid=',len(parents),V,K,'retained atoms=',atoms,'R=',R,'H=',totals['H'],'bound=',bound)
 return out
post=[posterior('initial_joint_base',[F(1),F(2),F(3)],[(0,3),(1,3)],[(0,2),(1,3),(0,3)],F(1,2),[F(1),F(3,2)],'basic'),
 posterior('rare_selection_zero_terminal_and_zero_base',[F(1),F(4),F(2),F(6)],[(0,4),(1,4),(0,4)],[(0,1),(1,3),(2,4),(0,4)],F(5,2),[F(1),F(3,2),F(2,3)],'rare'),
 posterior('expanded_finite_grid',[F((i%4)+1) for i in range(8)],[(0,8),(1,7),(0,5),(3,8)],[(0,4),(2,6),(4,8),(0,8),(1,7)],F(3,2),[F(1),F(2),F(3,2),F(5,4)],'expanded')]
# Global B=R=0 is a zero measure, with all prices set to zero, never log(0/0).
report={'environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'flint':flint.__version__,'Arb_bits':ctx.prec},
 'primitive_symbolic_residual':str(symres),'clipping_profiles':clip,'posterior_models':post,
 'global_zero_measure_convention':'B=R=0: every price 0; no logarithm evaluated',
 'scope':'Independent finite affine clipping and finite probability interfaces only; geometry references are real interval clipping, but no original path/history or global-order certification.'}
(ROOT/'r442_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: symbolic primitive; 3 affine clipping profiles; 3 distinct posterior grids, full terminal-conditioned reference and same-measure identity.')
