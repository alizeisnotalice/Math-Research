# R442 独立有限接口证书

按指定新环境实际执行`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r442_numeric.py`。Python3.12.14、SymPy1.14.0、flint0.9.0、Arb256bit。未调用求解器、无参数扫描、无原history实例。作者已有primitive点核及三组最小后验表，本任务独立采用不同的affine积分和retention表。

## 三阶段joint primitive核验

冻结接口为A=m_t(parent)，X_C=B_parent,C，Y_C=B_terminal,C，0≤c_C≤X_C,Y_C、c'_C≥0及A',Y'≥0。令

`F=A^p c^(1−p)(Y/mv)^p`。

SymPy核得F'减去目标项`(1−p)c'(AY/(mv X))^p`的余项恰为

`p A^(p−1)A'c^(1−p)(Y/mv)^p`
`+p A^p c^(1−p)(Y/mv)^(p−1)Y'/mv`
`+(1−p)c'(AY/mv)^p(c^(−p)−X^(−p))`。

符号残差0，三项均非负。c∞=0的cell设primitive及该cell贡献为0，不计算负幂。

有限profile中每cell有固定正密度level，X/Y/c由固定体积及冻结gate系数乘min(f_C,t)给出，A=ΣX。p=1/2时Y_C/X_C在活动段恒定，目标积分化为精确affine根式原函数`2 A(t)^(3/2)/(3 A')`，经Arb向外计算，未做浮点quadrature。

|阶段|cell数|一半目标积分|ΣF∞|Holder上界√(m_A Iw)|
|--|--|--|--|--|
|基础不同密度|3|.610293|2.652633|2.822897|
|空cell／10^−6微小交集|4|.097403|.767685|1.834855|
|扩大有限cell范围|8|1.593774|5.840867|6.082763|

所有区间严格分离，保持mv真实完整质量。endpoint Holder使用ΣY∞=mv、Σc∞=Iw，因此ΣF∞≤m_A^p Iw^(1−p)，没有乘cell数。本profile只认证clipped-set代数；未声明任意指定体积数组能由同一对中心cube几何同时实现。

## 三阶段terminal-conditioned posterior核验

另用正L1密度在单位区间cell上分段常数，parent和terminal均为实际区间，精确计算

`p_A(C)=B_AC(t)/m_t(A)`, `q_v(C)=B_vC(t)/m_v`。

p_A和为1，q_v和≤1；从parent内1{f>t}的实际活动cell产生参考source，再用一个明确有限terminal随机核形成Qξ(C,v)。该随机核仅为概率接口，不赋予原路径/history资格；全octave/q-band未认证。

选择FξCv∈[0,1]，ret=QF，αξ=Σret，k0(C|v)=Q(C,v)/Q(v)，k(C|v)=ret(C,v)/ret(v)，从而

`J=Σβret log(q_v/p_A)=raw+H−Fit`，

`raw=Σβret log(k0/p_A)`, `H=Σβret log(k/k0)`, `Fit=Σβret log(k/q_v)`。

逐正质量atom先用Fraction核上述log比的乘法恒等式，再用Arb计算所有加权log；没有把k0替换成不含v的cell边缘。三例均确实有k0(C|v)≠Q(C)。同时核完整KL链、Fit≥0及

`0≤H≤Σβ α log(1/α)≤R log(B/R)`，B=Σβ、R=Σβα。

|阶段|ξ×v×C|正ret atom数|R|H|Rlog(B/R)|
|--|--|--|--|--|--|
|基础joint base|2×3×3|12|43/24|.06817237|.59688380|
|rare retention／zero terminal／零接受ξ|3×4×4|8|17/8000|.000201584|.015526659|
|扩大有限grid|4×5×8|51|11019602317/5040000000|.72581678|2.11412431|

rare例固定retention为10^−3／10^−4并含整条α=0纤维、Q(v)=0终端和零cell；均先跳过零质量，未计算log(0/0)。扩大例含10^−6单项retention和零门。一般B=R=0采用零测度约定，不给墓地原流费用。

## 输出与范围

`r442_numeric_certificate.json`保存全部有理输入、actual interval cell reference、Q/F/ret表、Arb误差和环境。`r442_numeric_run.txt`是实际stdout，`r442_numeric_resources.txt`是资源记录；索引`r442_compute_index.md`列责任与复现。

本核验支持作者joint primitive和same-measure posterior代数接口。Holder去cell数不等于原arrival已被该primitive支配；H预算也未支付raw−Fit。未认证完整原stage/path、low-common、q-band或全R433目标，也未拟合全局阶数。交付停止。
