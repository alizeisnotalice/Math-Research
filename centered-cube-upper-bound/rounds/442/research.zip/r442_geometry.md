# R442 — a joint clipped-overlap primitive, with the old source retained

**Scope.** This is a bounded proof attempt on the unchanged R442 contract. It proves a native joint exponential-moment upper bound which removes the microcell-count loss and retains a fixed old source and actual parent–terminal overlap. It does **not** prove the remaining global geometric budget. No new fee is entered in the mother ledger, and no part of the R441 capture payment is charged again.

## 1. Exact candidate and admissible frozen restrictions

Let \(\mathcal P\) be the same complete lifted original measure, of mass \(R\), and put
\[
 F(t,A,v,z)=\log\frac{m_t(A)B_{v,C(z)}(t)}{m_vB_{A,C(z)}(t)},
 \qquad J=\int F\,d\mathcal P.
\]
All stage, old-source, early, clock, rank, first-deletion and path restrictions are retained in this definition. The original terminal starts from an own-high initial receiver; its whole unfiltered terminal law is bounded by \(1_{\{Z_v(z)\le h\}}\rho_z(dv)/h\), as proved in R441. This is the whole-terminal bound, not a sum of per-generation bounds.

Fix a parent \(A\), its actual old source \(y\), and a terminal receiver \(v\). Choose a jointly measurable, time-independent indicator \(w_{A,v}(y,z)\) which equals one on the projection of the original records under consideration. It can retain the original full-field low-common condition, static old/new rank restrictions, and terminal own-low condition. Choose also a fixed pair indicator \(G(A,v)\) containing the original parent–terminal projection; in particular one may retain \(m_v<m_A/K^2\) and the original terminal-center-outside-parent restriction. These choices must be necessary original restrictions. They do not assign history to \(v\). In particular G here does not contain a generation-dependent enlargement or an initial-node-dependent far gate; such a gate would require retaining its extra original labels, and is simply omitted from this bound. Neither w nor G contains the current index i(t), early factors, or current D_i restrictions.

The low-common soft factor and other factors bounded by one can be removed for this upper bound, while their necessary static support is kept in \(w\). A general fractional mask is allowed only if the original measure is actually dominated by the displayed bound with that mask; being bounded by one alone is insufficient.

For \(0<p<1\), define the following genuine-center, old-source-weighted quantity:
\[
 I^w_{Av}(y)=\int f(z)c_A(z)c_v(z)w_{A,v}(y,z)\,dz,
\]
\[
 \mathcal K_p=
 \sum_e\int\sigma(dA)\pi_A(dy)a_0^e(A,y)
 \int G(A,v)\left(\frac{I^w_{Av}(y)}{m_A}\right)^{1-p}\frac{dv}{m_v}.
 \tag{1}
\]
Here \(a_0^e\) is the original endpoint source density for direction \(e\), with \(a_i^e\le a_0^e\). It is not a new parent probability or a refreshed endpoint. The candidate proved below is
\[
 \boxed{\int e^{pF}\,d\mathcal P
       \le \frac{\mathcal K_p}{h(1-p)}.} \tag{2}
\]
The still missing step is a useful global price for (1), or for its less relaxed version keeping the original current gates. Equation (1) is an upper relaxation, not an equivalent necessary target.

## 2. Mixed primitive: all clipping levels and cells

Write \(g_t=\min(f,t)\). For one grid cell \(C\), abbreviate
\[
 A_t=m_t(A),\quad X(t)=B_{AC}(t),\quad Y(t)=B_{vC}(t),
\]
\[
 c(t)=\int_{C\cap Q_A\cap Q_v}g_t(z)w_{A,v}(y,z)\,dz.
\]
Then \(c\le X,Y\), all four masses are nondecreasing and locally absolutely continuous, and
\[
 c'(t)=\int_{C\cap Q_A\cap Q_v}1_{\{f(z)>t\}}w_{A,v}(y,z)\,dz
\]
for almost every \(t\). For \(c(\infty)>0\), all relevant denominators are positive for \(t>0\). Set
\[
 \mathfrak F(t)=A_t^p c(t)^{1-p}(Y(t)/m_v)^p.
\]
Its derivative satisfies
\[
 \mathfrak F'(t)\ge(1-p)c'(t)
       \left(\frac{A_tY(t)}{m_vX(t)}\right)^p. \tag{3}
\]
Indeed the two terms involving \(A_t'\) and \(Y'\) are nonnegative, and the remaining difference is
\[
 (1-p)c'(t)(A_tY(t)/m_v)^p
                \bigl(c(t)^{-p}-X(t)^{-p}\bigr)\ge0.
\]
On compact time intervals away from zero this is the ordinary absolutely-continuous chain rule. At zero, \(A_t,c(t),Y(t)\to0\) and \(\mathfrak F(0+)=0\). At infinity all masses have their full-source limits. If \(c(\infty)=0\), the cell contributes zero throughout; no negative power of zero is evaluated. Integrating (3) gives
\[
 \int_0^\infty c'(t)
       \left(\frac{m_t(A)B_{vC}(t)}{m_vB_{AC}(t)}\right)^pdt
 \le\frac{m_A^p}{1-p}\,c_C(\infty)^{1-p}
                    \left(\frac{B_{vC}(\infty)}{m_v}\right)^p.
 \tag{4}
\]
For a countable cell partition, Tonelli and Hölder yield
\[
 \sum_C c_C(\infty)^{1-p}
           (B_{vC}(\infty)/m_v)^p
 \le \left(\sum_C c_C(\infty)\right)^{1-p}
      \left(\sum_C B_{vC}(\infty)/m_v\right)^p
 = [I^w_{Av}(y)]^{1-p}.
 \tag{5}
\]
Thus there is no factor equal to the number of cells, even for arbitrary concentrated \(f\). Moreover cells without actual masked parent–terminal capture contribute zero. The result uses actual source integrals, not boundary volume as a source-mass bound.

## 3. Passing to the actual lifted measure

At a fixed clipping level \(t\), only its one original clipping interval contributes. Its stage-averaged early factor stays frozen; it is never replaced by a new levelwise event. The original source density is \(a_i^e(A,y)\). For an upper bound, use \(a_i^e\le a_0^e\), remove remaining positive factors, integrate the other generated path to at most one, and apply the whole-terminal bound to the new-source path. Future conditioning is not imposed on that law. With the static necessary supports retained, the resulting positive dominating expression is
\[
 \frac1h\sum_e\sigma(dA)\pi_A(dy)a_0^e(A,y)
 \frac{dv}{m_v}G(A,v)
 \frac{c_A(z)c_v(z)}{m_A}
 1_{\{f(z)>t\}}w_{A,v}(y,z)\,dz\,dt.
 \tag{6}
\]
The terminal own-low restriction can be kept in \(w\); its presence does not increase the law. The full conditional terminal estimate holds for each actual starting record, so old-source dependence is retained. Equation (6) is a positive upper bound for the projection used here, not a replacement of the original path measure by independent filtered terminals.

Multiply (6) by \(e^{pF}\), sum cells and integrate \(t\). Equations (4)–(5), including the factor \(m_A^{-1}\) in (6), give
\[
 \frac{m_A^{p-1}[I^w_{Av}(y)]^{1-p}}{h(1-p)}
 =\frac1{h(1-p)}\left(\frac{I^w_{Av}(y)}{m_A}\right)^{1-p}.
\]
This proves (2). There is no extra stage multiplicity and no extra factor two beyond the explicit sum over the two original endpoint directions. No current occupancy is recomputed.

Under the original finite-receiver contract, \(m_v\ge qa^n>0\), \(I^w_{Av}/m_A\le1\), and the endpoint densities are bounded. Hence \(\mathcal K_p<\infty\). The original signed \(F\) is integrable by the archived R441 bounds; consequently, when \(R>0\), Jensen is legitimate and gives
\[
 J\le\frac Rp\log\frac{\mathcal K_p}{h(1-p)R}. \tag{7}
\]
For \(R=0\), the actual target is zero and no logarithm is needed.

## 4. What this changes, and the one unpaid geometric step

The mixed primitive removes the specific microcell-count loss from separately pricing the parent entropy. It preserves both the negative terminal term and the actual masked triple capture, including the old source. It does not settle the full receiver integral in (1).

For example, Hölder in \(dv/m_v\) alone produces the factor
\[
 \left[\int G(A,v)1_{\{I^w_{Av}(y)>0\}}\frac{dv}{m_v}\right]^p
 \left[\int G(A,v)\frac{I^w_{Av}(y)}{m_A}\frac{dv}{m_v}\right]^{1-p}.
 \tag{8}
\]
The first factor is not a fixed-source occupancy: positive parent–terminal overlap can be supplied by different points of \(Q_A\). The original sourcewise column estimate therefore cannot be substituted for it. A crude enclosure of all intersecting cubes only gives exponential dimension dependence. Dropping the old-source and low-common restrictions before this step loses precisely the possible geometric saving.

The unresolved concrete calculation is to sum the fractional masked overlap in (1) over actual terminals and parents with their true matching masses, while retaining enough of the original old-source/current restrictions to avoid this multiplicity. No such estimate is proved here. In particular, (2) alone does not give a root-dimensional source price.

A polynomial global estimate of the illustrative form \(\mathcal K_p/h\le C(n+2)^b(X+nW)\), for one fixed \(p\), would suffice through (7): \(R\le SX\), \(R\log(X/R)\le X/e\), and \(\log(1+nW/X)\le nW/X\) give an \(O(\log(n+2))X+O(nW)\) bound. For each fixed error tolerance the logarithmic X term can be absorbed into \(\epsilon\sqrt n X\) at sufficiently large dimension; finitely many lower dimensions use the original coarse bound. Here S and p are fixed and all constants retain their dependence on S, p and C; the O-notation is not uniform in S. This is only an unproved sufficient benchmark, not a claimed necessary new theorem or an additional assumption of the original problem.

Thus the mother ledger and original remaining measure are unchanged. This attachment stops at (2), with the global old-source-weighted fractional-overlap price explicitly open.

## 5. Actual local checks

Executed with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`:

- Script: `/tmp/r442_geometry_check.py`.
- Captured stdout: `/tmp/r442_geometry.result.txt`.
- SymPy: the general mixed-primitive derivative minus the three displayed nonnegative remainder terms is identically zero.
- Arb at 192-bit precision: 9 fixed derivative checks and 9 fixed finite-cell Hölder checks, at \(p=1/4,1/2,3/4\), including exact equality cases. All 18 pass.

These are symbolic and interval checks of the analytic interface. They are not native-cube history fixtures and do not verify the unresolved all-parent receiver estimate. The proof of (2) is the analytic argument above; the finite checks do not replace it.
