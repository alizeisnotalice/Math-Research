# R442：同一原流的历史后验偏移可付；原终端拟合负项仍保留

本稿得到一个全流比较：原阶段、首次删除及未来筛选对有限 cell 后验造成的条件 KL 偏移，至多为
\[
 R\log(SX_q/R)\quad\text{且至多 }SX_q/e.
\]
它不刷新终端或来源，不改变原 \(\mathcal P\)，也不按阶段重复收费。该比较保留负终端拟合项；尚未支付原未过滤 exclusive/保源路径通道的几何信息部分。因此不是一般闭合。

## 1. 共同参考法，只用于分析，不生成新历史

沿用 R441 同一 \(\mathcal P\)，质量 \(R=R433\)。其 level 提升用 R440 已核的原 stage-averaged early 比例。原 \(\Gamma_i\) 是原完整标记 \(\Gamma_0\) 的嵌套正限制，首次删除标签可保为 \(\Delta\Gamma_j\) 的共同记录；后验与路径核均取完整原场。

构造有限参考测度 \(\mathcal B\)：保原方向 \(e\) 和完整边记录 \(\omega\)（包括旧来源 \(y\)、父 \(A\)、原时钟及首次删除标签）；新来源与 level 的因子为
\[
 \frac{c_A(z)}{m_A}1_{\{f(z)>t\}}\,dz\,dt.
\tag{1}
\]
随后使用原初始 exclusive 核及原固定来源路径生成法。定义域外或初始非 active 的质量送墓地；原 \(\mathcal P\) 在墓地为零。补墓地只是使参考核成为概率核，不授予任何原资格。所有原阶段与未来权都留作参考空间上的接受函数 \(0\le F\le1\)，故
\[
 d\mathcal P=F\,d\mathcal B,\qquad
 B:=\mathcal B(1)\le2G_0\le SX_q.
\tag{2}
\]
若原 level 从 \(T_0>0\) 开始，只在该区间构造，(2) 仍成立。确切总质量证明是对 (1) 积分：
\(\int_{T_0}^\infty1_{f(z)>t}dt\le f(z)\)，再对 \(Q_A\) 积分恰受 \(m_A\) 控制。两原方向之和为 \(2G_0\)，没有另加一个因子 2 或阶段数。

这里的构造直接使用 R440 `mainproof` §2–4 核实的共同记录及固定路径核；原生成路径来源、质量与终止定义见 R423 `research.zip::r423_main.md:7–15`，原终端裁剪密度必须使用未过滤版本见 R427 `research.zip::r427_main.md:28–44`。没有把原强历史改成独立抽样；参考法中不存在的资格仍在 \(F\) 中筛除。

把 \(\xi=(e,\omega,t)\) 作为条件基标签。其参考边缘记 \(\beta(d\xi)\)，总质量为 \(B\)。在 \(m'_t(A)>0\) 的条件纤维，原生新来源参考分布是
\[
 \frac{c_A(z)1_{\{f(z)>t\}}\,dz}{m'_t(A)},
\]
不是 \(g_t c_A/m_t(A)\)。这一区别不能抹去。

## 2. 精确有限 cell 条件比较

令 \(C=C(z)\)，\(v\) 为实际新来源终端。参考条件联合 law 为
\(Q_\xi(dC,dv)\)，保留流条件总接受率为
\(\alpha_\xi=E_{\mathcal B}[F\mid\xi]\)。当 \(\alpha_\xi>0\)，保留条件 law 记 \(P_\xi\)；其密度相对 \(Q_\xi\) 至多 \(1/\alpha_\xi\)。实际全流是
\(\beta(d\xi)\alpha_\xi P_\xi\)，不丢掉进入量。

令
\[
 k_\xi(C\mid v)=P_\xi(C\mid v),\qquad
 k_\xi^0(C\mid v)=Q_\xi(C\mid v),
\]
二者都是**同一参考与原保留测度的条件后验**，不是另行赋予来源的新概率。欧氏路径字段、有限统一路径长度与有限 cell 集保证标准可测条件核可取。无需对“来源 × 完整连续历史”假定产品绝对连续；所用绝对连续是明确的 \(\mathcal P=F\mathcal B\)。

父几何 cell 概率和终端几何 cell 次概率分别是
\[
 p_A^t(C)=B_{AC}(t)/m_t(A),\qquad
 q_v^t(C)=B_{vC}(t)/m_v.
\tag{3}
\]
父与微格相交至多 \((b/d+2)^n\) 格；在这个有限集合上 \(\sum_Cp_A^t(C)=1\)、\(\sum_Cq_v^t(C)\le1\)。实际支持上相应分母正。墓地约定任取，不贡献原流。

R441 原 signed integrand 恰为 \(\log(q_v^t(C)/p_A^t(C))\)。对**同一** \(\mathcal P\) 精确有
\[
 \boxed{J=\mathcal I_0+\mathcal H-\mathcal F,}
\tag{4}
\]
其中
\[
\begin{aligned}
 \mathcal I_0&=\int\log\frac{k_\xi^0(C\mid v)}{p_A^t(C)}\,d\mathcal P,\\
 \mathcal H&=\int\log\frac{k_\xi(C\mid v)}{k_\xi^0(C\mid v)}\,d\mathcal P,\\
 \mathcal F&=\int\log\frac{k_\xi(C\mid v)}{q_v^t(C)}\,d\mathcal P\ge0.
\end{aligned}
\tag{5}
\]
终端负势没有丢掉：它进入 \(-\mathcal F\)。非负性来自每个 \((\xi,v)\) 上的 KL 加次概率总质量罚，具体为
 \(D(k_\xi\Vert q_v^t/\sum_Cq_v^t)-\log\sum_Cq_v^t\ge0\)。

## 3. 全部历史后验偏移，一次支付

条件 KL 链式分解及 \(dP_\xi/dQ_\xi\le1/\alpha_\xi\) 给
\[
\begin{aligned}
 \alpha_\xi E_{P_\xi(v)}
 D(k_\xi(\cdot\mid v)\Vert k_\xi^0(\cdot\mid v))
 &\le\alpha_\xi D(P_\xi\Vert Q_\xi)\\
 &\le\alpha_\xi\log(1/\alpha_\xi).
\end{aligned}\tag{6}
\]
零接受率贡献 0；接受率 1 时两条件 law 相同。隐藏的原路径权已通过条件平均保留在 \(P_\xi\)，不需其成为独立接受位。

对同一 \(\beta\) 积分，利用 \(R=\int\alpha_\xi d\beta\)，Jensen 严格推出
\[
 0\le\mathcal H
 \le\int\alpha_\xi\log(1/\alpha_\xi)d\beta
 \le R\log(B/R)
 \le R\log(SX_q/R).
\tag{7}
\]
另有 \(\mathcal H\le B/e\le SX_q/e\)。\(R=0\) 时全部结论取 0；\(B=0\) 必有 \(R=0\)。这里的比率无量纲。这个价格跨全部阶段一次结算，因为 \(\beta\) 在同一个 level 只对应原一个阶段，而 \(\int dt\,1_{f>t}\) 已在 (2) 全部积分。

由 R441 初始/终端势可积，(4) 不作无穷减无穷：有限 cell 条件 entropy 使 \(\int|\log k_\xi|d\mathcal P\le R\log N_d\)；(7) 保证 \(\log k_\xi^0\) 同样可积；(3) 的两几何负对数正是已证可积的初始 cell 势和终端势。故 \(\mathcal I_0,\mathcal F,J\) 均为有限实数。

## 4. 实际回代与未支付的几何量

将 (4)、(7) 代入 R441 同流比较，得到
\[
 \begin{split}
 2(\sqrt n-\log_+M_*)R
 \le SX_q+\mathcal I_0-\mathcal F
       +R\log(SX_q/R)+4rC_dA_nW.
 \end{split}
\tag{8}
\]
这确实支付了先前完整 \(J\) 内的历史后验偏移，未付的是**同一保留流加权**的 raw-terminal cell likelihood 与终端拟合之差，不是未经标记的完整信息量。

若要证明 \(R\le\epsilon X_q+\) 来源费，可先在 \(R\le\epsilon X_q\) 时结束该比较；否则 \(S>\epsilon\)，并有
\[
 \left[2(\sqrt n-\log_+M_*)-\log(S/\epsilon)\right]R
 \le SX_q+\mathcal I_0-\mathcal F+4rC_dA_nW.
\tag{9}
\]
这仅是全目标证明的两种情况，不新增一轮付费分支；括号正性、bulk 的吸收和所有旧入口系数仍须核验。

**明确剩余条件。** 原 old-source \(y\)、low-common、父与 exclusive 核都在 \(\xi\)、\(Q_\xi\) 和原 \(F\) 中。它们目前没有给出
\[
 \mathcal I_0-\mathcal F
 \le \epsilon\sqrt n\,X_q+
             C_\epsilon n\operatorname{polylog}(n+2)W.
\tag{10}
\]
特别不能把 \(k_\xi^0(C\mid v)\) 当成 \(q_v^t(C)\)：它还以父内 \(1_{f>t}\) 为起始来源，并经过依来源的完整路径选择。在父内活动来源集合上，原始增量来源相对 clipped posterior 的密度为 \(m_t(A)/(t m'_t(A))\)（\(t>0\)）；其动态范围没有统一界，故不能另以未证的 LlogL 价支付起始偏差。需要保留负终端拟合项联合比较。low-common 约束的是原严格小质量共同捕获，未证明它控制此条件 likelihood。可逆静态后验、独立终端参考或无过滤路径的平均信息也不能直接替代 (10)。

与 R435 的静态父后验检查不同，本稿的 (6)–(7) 对原完整保留测度成立，并给出一次显式可吸收价格；但这不是 (10) 的证明，也不把条件信息改名成根阶付款。此单一路线到此停止，无母账修改。

## 5. 本机精确核验范围

同前缀脚本用 Fraction 建三组有限 reference/acceptance 表，含零 cell/terminal、全接受和严格历史筛选，验证 (4)、条件 KL 链分解、(6) 及总质量 Jensen。所有 log 线性组合通过清分母后有理乘积比较，未用浮点符号判定。模型只核同测度信息代数，不是原生连续中心、原 low-common 或全历史实现；一般结果依 (1)–(7) 的证明。

实际运行结果：三组接受率分别为 5/8、9/16、1；合并参考质量 B=3、保留质量 R=77/32。三组精确恒等式及条件界、合并 Jensen 均通过。输出保存于 `/tmp/r442_mainproof.result.txt`；没有将检查数量解释为原合同的样本覆盖。
