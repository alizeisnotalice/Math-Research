from fractions import Fraction as F
from math import lcm


def add(expr, coefficient, argument):
    coefficient, argument = F(coefficient), F(argument)
    if not coefficient or argument == 1:
        return
    assert argument > 0
    expr[argument] = expr.get(argument, F(0)) + coefficient


def combine(*terms):
    out = {}
    for scale, expr in terms:
        for argument, coefficient in expr.items():
            add(out, F(scale) * coefficient, argument)
    return out


def product_certificate(expr):
    denom = lcm(*(x.denominator for x in expr.values())) if expr else 1
    prod = F(1)
    for argument, coefficient in expr.items():
        prod *= argument ** int(coefficient * denom)
    return prod


tables = [
    (F(1), [[F(1, 4)] * 2, [F(1, 4)] * 2],
     [[F(1), F(0)], [F(1, 2), F(1)]]),
    (F(1, 2), [[F(1, 2), F(1, 4)], [F(0), F(1, 4)]],
     [[F(1, 2), F(1)], [F(0), F(1, 4)]]),
    (F(3, 2), [[F(1, 2), F(0)], [F(0), F(1, 2)]],
     [[F(1), F(0)], [F(0), F(1)]]),
]
parent = [F(1, 2), F(1, 2)]
terminal = [[F(1, 2), F(1, 4)], [F(1, 4), F(1, 2)]]
total_h, conditional_cap = {}, {}
mass_b = mass_r = F(0)
for idx, (beta, raw, accepted) in enumerate(tables, 1):
    assert sum(map(sum, raw), F(0)) == 1
    ret = [[raw[c][v] * accepted[c][v] for v in range(2)]
           for c in range(2)]
    alpha = sum(map(sum, ret), F(0))
    col0 = [sum(raw[c][v] for c in range(2)) for v in range(2)]
    col = [sum(ret[c][v] for c in range(2)) for v in range(2)]
    j, info0, hist, fit, joint, marginal = {}, {}, {}, {}, {}, {}
    for v in range(2):
        if col[v]:
            add(marginal, beta * col[v], col[v] / (alpha * col0[v]))
        for c in range(2):
            mass = beta * ret[c][v]
            if not mass:
                continue
            k0, k = raw[c][v] / col0[v], ret[c][v] / col[v]
            add(j, mass, terminal[c][v] / parent[c])
            add(info0, mass, k0 / parent[c])
            add(hist, mass, k / k0)
            add(fit, mass, k / terminal[c][v])
            add(joint, mass, accepted[c][v] / alpha)
    assert product_certificate(combine((1, j), (-1, info0), (-1, hist), (1, fit))) == 1
    assert product_certificate(combine((1, joint), (-1, hist), (-1, marginal))) == 1
    assert product_certificate(hist) >= 1
    assert product_certificate(fit) >= 1
    assert product_certificate(marginal) >= 1
    cap = {}
    add(cap, beta * alpha, 1 / alpha)
    assert product_certificate(combine((1, cap), (-1, joint))) >= 1
    total_h = combine((1, total_h), (1, hist))
    conditional_cap = combine((1, conditional_cap), (1, cap))
    mass_b += beta
    mass_r += beta * alpha
    print(f"PASS case {idx}: alpha={alpha}, exact signed identity and conditional entropy bounds")

global_cap = {}
add(global_cap, mass_r, mass_b / mass_r)
assert product_certificate(combine((1, global_cap), (-1, conditional_cap))) >= 1
assert product_certificate(combine((1, global_cap), (-1, total_h))) >= 1
print(f"PASS joint Jensen: B={mass_b}, R={mass_r}; all weights retained")
print("Certificates: exact rational products after clearing log coefficients")
print("Scope: finite conditional-probability algebra, not native geometry or original-history certification")
