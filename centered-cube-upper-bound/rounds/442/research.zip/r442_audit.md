# R442 independent final audit

FINAL PASS（限定于联合交叠幂上界、同一原流的历史后验偏移价格及列明的参考测度身份；不认证全父核、raw-minus-fit或完整R433预算）。独立PRE先于新作者证明，后审于2026-10-21完成。16件冻结输入与主稿回代均已核；四脚本实际隔离复现一致。原母账不变，无范围内剩余实质阻断。研究稿日期2026-10-20不表示本审计运行日期。

## 1. 保原旧来源的joint primitive

固定真实父A、旧来源/记录及终端v，必须选t静态必要门w、G；当前i(t)、early、D_i门不能伪装为静态w。作者已明示这些仅在正上界中删除，或须保额外原标签。任意fractional mask≤1并不足以支配原费用，需另有真实测度支配；正文保留此条件。初始/代数依赖的far门没有被误投影成G(A,v)。

对c_C=∫C∩QA∩Qv min(f,t)w，c_C≤B_AC，原函数
 F_C=m_t(A)^p c_C^(1−p)(B_vC/m_v)^p
满足F_C′≥(1−p)c_C′exp(pJ_record)，0<p<1。m_t′、B_vC′余项非负；0端连续极限为0，零c_C不取负幂，∞端为完整f质量。Tonelli/Hölder及Σ_CB_vC(∞)=m_v给
 Σ_C∫c_C′exp(pJ_record)dt≤m_A^p(I_Av^w)^(1−p)/(1−p)。

原whole-terminal≤ρ_z/h仅在原初始own-high且未来正权不重归一时调用；保原a_i≤a_0和旧来源，不先以总S删去其关联。固定t唯一stage，新来源π_A与clip增量的f消去，得到作者(6)正支配。m_A^−1与primitive的m_A^p精确结合成(I/m_A)^(1−p)，故
 ∫exp(pJ_record)dP≤K_p/[h(1−p)]。
两个方向只在显式求和出现一次。K_p有限（原|E|有限、统一正下质量及有限原流），但其所需多项式/根阶全中心价格未证。Hölder消cell数不等于支付outer kernel。

充分benchmark的S依赖已明确修订。若K_p/h≤C(n+2)^b(X+nW)，对固定S,p的直接粗价保S常数；根稿更尖case R>εX给
 J≤p^−1 log(C(n+2)^b/ε)R+(εn/p)W。
该式只是未证kernel价格的条件推论，不能无条件记账或解释为对S一致。

## 2. 同一base与条件后验

参考Bcal从原Γ_0两端完整记录附原新来源和一次概率clip draw、原未过滤路径；非法/初始inactive送墓地。stage由同一个t选择，全部原正筛选作F∈[0,1]，P=F Bcal，Bcal(1)≤2G0≤SX。没有每stage重启base，没有刷新history或来源，也不要求完整连续历史相对某产品测度AC。

ξ=(方向、完整旧记录、t)下，原参考新来源按c_A1_{f>t}/m_t′分布，而非min(f,t)c_A/m_t。k0须为这个base继续给定真实终端v后的实际cell后验。作者及独立numeric均保此区别。条件接受率α及KL链给
 0≤H_hist≤∫β αlog(1/α)≤Rlog(B/R)≤Rlog(SX/R)≤SX/e。
零B/R/α按零测度约定；全接受偏移为0。两端总量2G0已在base内计入，不再乘2或stage数。

p_A=B_AC/m_t(A)为父几何概率；q_v=B_vC/m_v为次概率，不能重新归一。作者Fit采用Σk log(k/q_v)，含−logΣq_v≥0的总质量罚，因此
 J=I0+H_hist−Fit，Fit≥0
严格成立。未偷换为含−k+q的广义KL。有限cell条件entropy、H_hist有限及R441两端势可积使log k0、I0、Fit分别可积，不以∞−∞获利。原source/父/终端支持保证实际正质量cell上的几何分母正。

回代R441得到主稿(4)（R>εX时）正确；R≤εX只是证明分情况，不是另收费分支。括号正性、bulk SX的吸收及原16/32/64母账系数仍待原参数核验。H_hist有价并不支付I0−Fit；作者和根稿均保留此缺口。

## 3. 共同父图参考

修后complement已明确μ(dy)=f(y)dy是来源测度，非receiver dA/m_A；式(6)各因子相乘的排版已修。Schur给κ质量≤W，真实selector层饼含b端base给逐对中心核≤C_g。原sourcewise核质量≤S保持完整level/history/path，构造Λ后确有Λ(1)≤C_gW、dP=(S/T_G)dΛ。TG在原P上有正下界与既有上门，log可积，故Jensen的∫logTG≤Rlog(SC_gW/R)合法。

随后Gibbs的相对密度代价精确抵消图项，∫e^(J_record−logTG)dΛ=S^−1∫e^J_record dP是同一正积分身份（允许扩展值）。它不提供新加权中心价格。已付静态图矩不被重复抵扣。

## 4. 本机复现与证据范围

实际在 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r442_audit_isolated_3lpasmtp` 使用指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 运行四脚本，全部exit0，四stdout与冻结输入逐字一致；再生numeric_certificate.json亦逐字一致。环境Python3.12.14、SymPy1.14.0、flint0.9.0，geometry Arb192bit、numeric Arb256bit一致；未运行MATLAB或solver。

geometry是1个一般符号身份及18个固定Arb导数/Hölder检查；mainproof为三张有限表的精确有理对数乘积、条件链及总Jensen；complement为标量参考变换身份。独立numeric另核3个affine clipped profile（3/4/8 cells，解析根式积分）及3张不同terminal-conditioned posterior表（12/8/51正ret atom），含零接受、零terminal、稀有和微小交集。profile数组只认证clipped-set接口，未声称同一真实cube几何可同时实现；后验的实际区间几何不赋原K/history资格。Arb误差与Fraction精确身份分开，不以有限检查证明一般几何界。

共享索引和资源文件只记录实际工作/运行，不增加理论或参数覆盖；隔离复跑不计新样本。PRE临时符号/三表辅助不纳正式统计。所有一般结果以上述测度和解析证明为依据。

最终限定：保留真实joint primitive、历史偏移价格和合法回代；K_p全中心价、I0−Fit所需预算、一般弱型结论及最终ε/全尺度结算仍未证明。根稿明确原母账不修改，本PASS不得用于认证这些未证项。交付后停止扩展。

## 冻结字节 SHA-256（16输入）

- `r442_main.md`: `67a4f7fce435ca61597112088bf9f5b925b924b3602364b871afe6e73e1a773b`
- `r442_geometry.md`: `ead201ddb473a94baf698d8be0626f7dfa21b2d9c39a120dca1c628259e37366`
- `r442_geometry_check.py`: `3a68320dec6f6f8c7f27430c83a50c7570dfbbc0f95e4934fe50f4d88c0981b1`
- `r442_geometry.result.txt`: `8c9a02cf3d43cd63a4a6d1e52c71a3fcb7901df965f4f4752ed0eca3f506483e`
- `r442_mainproof.md`: `b9d0ef941fbced04d9a11001db8637803c3d425b743accdaad149c193b0d1845`
- `r442_mainproof_check.py`: `c7985738beae2095ccdf963d080f473b887688ee68532ee7670a7cc25ea3a3e9`
- `r442_mainproof.result.txt`: `26dcc4407ce56a62dde79af383365f604fd27b9078736ee77bb84eda2b133f3f`
- `r442_complement.md`: `3a68a9708c8f5cedcbf2d8bb65a51d9ff199e7253472d2e774506f4c6e4c98cc`
- `r442_complement_check.py`: `e3770e57cc93a6e6e0478bd401c3bfc0dd49386086380be4587073e2552c7374`
- `r442_complement_check.txt`: `8ab9a25fe91e8079df6d19201c0566455480ffcb29a2847d0aba59a735a29d47`
- `r442_numeric.md`: `d328b306d799d41404024d4643b56329aab72da7d045e90f859edca14d559a2c`
- `r442_numeric.py`: `12cfd607719d38ba4d0ab9fc3675fcc2d9582282291eaf84a58d625ef4cc8b53`
- `r442_numeric_certificate.json`: `55b548084812a65f971d9fd844085ca27b417ce9e20ed8ad8b59fcf5560af2bb`
- `r442_numeric_run.txt`: `405e01b257a59124d90d7dbc2f574476156f318c8b8e2e5aa8b21550d8bb62d9`
- `r442_numeric_resources.txt`: `50a31856546103d8bad84899c8d8904c3be5e40640bebdfdb57588782188b5a4`
- `r442_compute_index.md`: `c2d09cf8907a757a18cc7fdd73fb39c49225c33077a6745aa08dca682fa79b0a`
