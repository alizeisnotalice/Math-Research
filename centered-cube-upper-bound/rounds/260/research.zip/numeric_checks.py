#!/usr/bin/env python3
"""R260 bounded actual-C and exact posterior-TV diagnostics, standalone."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def m(x):return mp.mpf(x.numerator)/x.denominator
def enc(x):return mp.nstr(x,50)
def C_and_derivative(x,side='right'):
    E=lambda n,t:mp.expint(n,t)
    if x<1:
        c=mp.mpf(4)/3-x-E(4,1)-E(4,x)+E(4,x+1)
        cp=-1+E(3,x)-E(3,x+1)
    else:
        # Positive exponential-scale differences; never subtract two CDFs near .5.
        c=E(4,x-1)-2*E(4,x)+E(4,x+1)
        cp=(-1+E(3,1)-E(3,2))if x==1 and side=='left'else -E(3,x-1)+2*E(3,x)-E(3,x+1)
    return c,cp

def grids():
    initial={F(j,100)for j in range(201)}
    stress={c+sign*F(1,10**k)for c in [F(1,2),F(1)]for sign in [-1,1]for k in range(1,25)}|{F(x)for x in [0,1,2,4,8,16,32,64,100]}
    expanded={F(j,2)for j in range(4,201)}
    return [('initial',initial),('stress',stress),('expanded',expanded)]
def actual_values(dps):
    with mp.workdps(dps):
        stage=[];allpoints=set();global_max=mp.mpf(0);maxat=None
        for phase,pts in grids():
            best=mp.mpf(0);at=None
            for v in sorted(pts):
                sides=['left','right']if v==1 else['right']
                for side in sides:
                    c,cp=C_and_derivative(m(v),side);assert c>0 and cp<=0
                    z=abs(cp/c);assert z<=12
                    if z>best:best=z;at={'d':fs(v),'side':side}
            if best>global_max:global_max=best;maxat=at
            stage.append({'phase':phase,'points':len(pts),'max_absolute_log_derivative':enc(best),'maximizer':at})
            allpoints|=pts
        points=sorted(allpoints);pairs=set(zip(points,points[1:]))
        for u in points:
            for anchor in [F(0),F(1),F(2),F(100)]:
                if u!=anchor:pairs.add(tuple(sorted((u,anchor))))
        worst=mp.mpf(0);where=None
        for u,v in sorted(pairs):
            # Guard exact rational locations and log subtraction when separation=1e-24.
            with mp.extradps(50):
                cu=C_and_derivative(m(u))[0];cv=C_and_derivative(m(v))[0]
                ratio=abs(mp.log(cu)-mp.log(cv))/m(v-u)
            ratio=+ratio
            assert ratio<=12
            if ratio>worst:worst=ratio;where={'u':fs(u),'v':fs(v)}
        tail=[]
        for d in [2,4,8,16,32,64,100]:
            cc,cp=C_and_derivative(mp.mpf(d));tail.append({'d':d,'C':enc(cc),'absolute_log_derivative':enc(abs(cp/cc))})
        return {'stages':stage,'unique_points':len(points),'tested_pairs':len(pairs),'global_max_absolute_log_derivative':enc(global_max),'derivative_maximizer':maxat,'max_finite_log_Lipschitz_ratio':enc(worst),'finite_ratio_pair':where,'safe_tested_L':12,'tail':tail,'precision_scope':'40/70 ordinary arithmetic, pair log differences use 50 internal guard digits; no interval or general Lipschitz proof.'}

def exact_TV():
    rows=[]
    deleted=[(F(0),F(0)),(F(1,10),F(1,10)),(F(1,10),F(1,2)),(F(1,2),F(1,10)),(F(9,10),F(1,100)),(F(1),F(0))]
    for s in [F(1),F(3,2),F(2),F(3),F(10)]:
        phase='initial'if s<=F(3,2)else'stress'if s<=3 else'expanded'
        for profile in ['extremal_two','interior_three']:
            p=[s/(1+s),1/(1+s)]if profile=='extremal_two'else[F(1,4),F(1,2),F(1,4)]
            rawratios=[1/s,s]if profile=='extremal_two'else[1/s,F(1),s]
            norm=sum(x*r for x,r in zip(p,rawratios));q=[x*r/norm for x,r in zip(p,rawratios)]
            assert sum(p)==sum(q)==1 and max(rawratios)/min(rawratios)==s*s
            commonTV=sum(abs(x-y)for x,y in zip(p,q))/2;t=(s-1)/(s+1);assert commonTV<=t
            for alpha,beta in deleted:
                P=[(1-alpha)*x for x in p]+[alpha,F(0)];Q=[(1-beta)*x for x in q]+[F(0),beta]
                assert sum(P)==sum(Q)==1
                tv=sum(abs(x-y)for x,y in zip(P,Q))/2;bound=max(alpha,beta)+min(1-alpha,1-beta)*t;assert tv<=bound
                row={'phase':phase,'sqrt_R':fs(s),'R':fs(s*s),'profile':profile,'alpha':fs(alpha),'beta':fs(beta),'common_raw_ratios':list(map(fs,rawratios)),'P':list(map(fs,P)),'Q':list(map(fs,Q)),'TV':fs(tv),'common_conditional_TV':fs(commonTV),'common_bound_tanh_delta_half':fs(t),'proposed_bound':fs(bound),'margin':fs(bound-tv),'degenerate_common_support':alpha==1 or beta==1}
                if alpha==1 or beta==1:
                    row['scope']='Abstract probability/limit diagnostic; one-sided zero common mass is impossible for strictly positive common raw weights.'
                if alpha<1 and beta<1:
                    # Global raw laws with these common ratios normalize to P and Q.
                    row['raw_P_total']=fs(1/(1-alpha));row['raw_Q_total']=fs(norm/(1-beta))
                rows.append(row)
    return rows

def numericfields(obj,prefix=''):
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            if isinstance(v,str):
                try:out[prefix+k]=mp.mpf(v)
                except ValueError:pass
            elif isinstance(v,(dict,list)):out.update(numericfields(v,prefix+k+'/'))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):out.update(numericfields(v,prefix+str(i)+'/'))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();tv=exact_TV();lo=actual_values(40);hi=actual_values(70)
    with mp.workdps(100):
        x=numericfields(lo);y=numericfields(hi);assert x.keys()==y.keys();diff=[abs(x[k]-y[k])/max(1,abs(y[k]))for k in x];md=enc(max(diff));assert max(diff)<mp.mpf('1e-35')
    result={'schema':'R260-C-TV-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'exact_TV_cases':len(tv),'TV_equalities':sum(F(r['margin'])==0 for r in tv),'C_unique_points':hi['unique_points'],'C_pair_checks':hi['tested_pairs'],'precision_fields_compared':len(diff)},'TV_formula_audit':'For exclusive masses alpha,beta, TV(P,Q)<=max(alpha,beta)+min(1-alpha,1-beta)TV(P_common,Q_common). Common raw ratio range exp(2delta)=R gives optimal common TV<=(sqrt(R)-1)/(sqrt(R)+1)=tanh(delta/2). This is independent of score variation.','exact_TV_cases':tv,'mp40':lo,'mp70':hi,'precision_max_relative_difference':md,'scope':'Bounded local actual-C and finite rational posterior diagnostics only. No FULL, score-stability, root conclusion, or general Lipschitz proof.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':md,'derivative_max':hi['global_max_absolute_log_derivative'],'pair_max':hi['max_finite_log_Lipschitz_ratio'],'pair':hi['finite_ratio_pair']}))
if __name__=='__main__':main()
