#!/usr/bin/env python3
"""Round 52: exact weak-p source lower guards and endpoint budget diagnostics.

Standard library only. Actual weak-p tests use positive, disjoint uniform cubes
in R^n and Lebesgue receiver volumes, not a discrete observation proxy. Their
inner level-set boxes give lower bounds, not exact maximal level-set volumes.
Strong-Lp and optimization sections check explicit analytic scalar certificates;
they do not measure an operator norm or assign a value to the unknown D(p).
The enormous dimensions in the lower-budget section are symbolic integers;
no high-dimensional source or maximal-volume computation is claimed there.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import combinations
from pathlib import Path
import json
import sys
import time

if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)


def fs(x):
    x = F(x)
    return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'


def dec(x):
    x = F(x)
    return Decimal(x.numerator) / Decimal(x.denominator)


def ds(x):
    return format(x, '.24E')


def root_interval(x, n, bits=64):
    """Monotone dyadic floor root; endpoint powers are checked exactly."""
    x = F(x)
    assert x >= 0 and n >= 1
    if n == 1:
        return x, x
    den = 1 << bits
    lo, hi = 0, den
    while F(hi, den) ** n <= x:
        hi *= 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if F(mid, den) ** n <= x:
            lo = mid
        else:
            hi = mid
    lower, upper = F(lo, den), F(hi, den)
    assert lower ** n <= x < upper ** n
    return lower, upper


def intersection_volume(boxes, n):
    v = F(1)
    for i in range(n):
        gap = min(b[1][i] for b in boxes) - max(b[0][i] for b in boxes)
        if gap <= 0:
            return F(0)
        v *= gap
    return v


def union_ie(boxes, n):
    total = F(0)
    for k in range(1, len(boxes) + 1):
        for chosen in combinations(boxes, k):
            total += (-1) ** (k + 1) * intersection_volume(chosen, n)
    assert total >= 0
    return total


def weak_source_guards():
    records = []
    for n in range(1, 5):
        if n == 1:
            points = [(F(0),), (F(1),), (F(2),)]
        else:
            points = [tuple(F(0) for _ in range(n)),
                      tuple(F(i == 0) for i in range(n)),
                      tuple(F(i == 1) for i in range(n))]
        for eta in (F(1, 64), F(1, 256)):
            height = F(1, 3) / (2 * eta) ** n
            assert min(max(abs(x[i] - y[i]) for i in range(n))
                       for x, y in combinations(points, 2)) > 2 * eta
            assert 3 * height * (2 * eta) ** n == 1
            for lam in (F(1, 4), F(1, 2), F(1), F(2)):
                boxes, root_certificates = [], []
                for size in range(1, 4):
                    lower, upper = root_interval(F(size, 3) / lam, n)
                    root_certificates.append({'subset_size': size,
                                              'side_lower': fs(lower),
                                              'side_upper': fs(upper)})
                    for subset in combinations(points, size):
                        low = tuple(max(y[i] for y in subset) - lower / 2 + eta
                                    for i in range(n))
                        high = tuple(min(y[i] for y in subset) + lower / 2 - eta
                                     for i in range(n))
                        if all(low[i] < high[i] for i in range(n)):
                            boxes.append((low, high))
                volume = union_ie(boxes, n)
                assert volume > 0 and lam < height
                # int f^p = height^(p-1), since mass is exactly one.
                # Q = lambda^p V / int f^p; Q^k avoids irrational powers.
                for k in (2, 4, 16, 64):
                    q_power = (lam * volume) ** k * lam / height
                    assert q_power > 0
                    q = (dec(q_power).ln() / Decimal(k)).exp()
                    relative = q / Decimal(k).sqrt()
                    records.append({'n': n, 'eta': fs(eta), 'lambda': fs(lam),
                                    'p': fs(F(k + 1, k)), 'k': k,
                                    'source_mass': '1', 'density_height': fs(height),
                                    'nonempty_inner_boxes': len(boxes),
                                    'root_certificates': root_certificates,
                                    'inner_union_volume': fs(volume),
                                    'weak_p_lower_power_k': fs(q_power),
                                    'weak_p_lower_decimal': ds(q),
                                    'relative_to_epsilon_minus_half_decimal': ds(relative),
                                    'status': 'actual positive L1 density; certified level-set lower bound'})
    return records


def strong_guards():
    records = []
    for k in (1, 2, 4, 8, 16, 32, 64, 128, 256):
        eps, p = F(1, k), F(k + 1, k)
        clo, chi = root_interval(F(1, 2 ** k), k + 1, bits=96)
        assert F(1, 2) ** (k + 1) <= F(1, 2 ** k)
        assert clo >= F(1, 2)
        etas = {F(1, 2), F(1, 4), F(1, 16), F(1, 256), F(1, 65536)}
        if eps < 1:
            etas.add(eps ** 2)
        for eta in sorted(etas, reverse=True):
            a = (1 - eta) / p
            assert 0 < a < 1 / p and 1 - a * p == eta
            norm_lo, norm_hi = clo / (1 - a), chi / (1 - a)
            assert norm_lo <= norm_hi
            scaled_lo = norm_lo * eps / p
            scaled_hi = norm_hi * eps / p
            power_lower = (-Decimal(2).ln() - dec(p) * dec(1 - a).ln()).exp()
            special = eta == eps ** 2 and eps < 1
            if special:
                assert a == 1 - eps and norm_lo >= 1 / (2 * eps)
            records.append({'k': k, 'p': fs(p), 'a': fs(a), 'eta_one_minus_ap': fs(eta),
                            'input_Lp_power': fs(1 / eta),
                            'strong_norm_lower_interval': [fs(norm_lo), fs(norm_hi)],
                            'strong_norm_lower_over_p_over_epsilon_interval':
                                [fs(scaled_lo), fs(scaled_hi)],
                            'strong_power_lower_decimal': ds(power_lower),
                            'special_eta_epsilon_squared': special,
                            'weak_p_1d_analytic_upper': '3',
                            'status': 'analytic centered-interval lower certificate; no operator evaluation'})
    return records


def optimization_guards():
    records = []
    alpha = F(1, 2)
    ratios = (F(1, 4), F(1, 2), F(3, 4), F(1), F(5, 4), F(2), F(4))
    for n in range(1, 257):
        A = (1 + F(2, n)) ** n
        B = (2 * n + 4) ** n
        logB = Decimal(n) * Decimal(2 * n + 4).ln()
        eps_opt = dec(alpha) / logB
        assert 0 < eps_opt < 1
        assert A < 9
        best = dec(A) * (logB / dec(alpha)).sqrt() * dec(alpha).exp()
        sampled = []
        for ratio in ratios:
            eps = dec(ratio) * eps_opt
            fee = dec(A) / eps.sqrt() * (eps * logB).exp()
            # Derivative sign is sign(ratio-1) exactly for eps=ratio*alpha/logB.
            sign = (ratio > 1) - (ratio < 1)
            assert fee >= best * (1 - Decimal('1e-60'))
            sampled.append({'epsilon_ratio_to_optimum': fs(ratio),
                            'epsilon_decimal': ds(eps),
                            'epsilon_at_most_one': eps <= 1,
                            'log_fee_derivative_sign_exact': sign,
                            'scalar_fee_decimal': ds(fee)})
        records.append({'n': n, 'A_exact': fs(A), 'B_exact': str(B),
                        'logB_decimal': ds(logB), 'epsilon_opt_decimal': ds(eps_opt),
                        'hypothetical_alpha': '1/2', 'optimized_fee_excluding_unknown_C': ds(best),
                        'samples': sampled,
                        'status': 'hypothetical D(1+epsilon)<=C epsilon^(-1/2); scalar optimization only'})
    return records


def log2_interval(terms=128):
    lower = sum((F(2, (2 * j + 1) * 3 ** (2 * j + 1))
                 for j in range(terms)), F(0))
    tail = F(9, 4 * (2 * terms + 1) * 3 ** (2 * terms + 1))
    return lower, lower + tail


def lower_budget_guards():
    lo, hi = log2_interval()
    assert 0 < lo < hi < 1
    records = []
    for k in range(16, 257, 8):
        eps = F(1, 2 ** k)
        loglo, loghi = k * lo, k * hi
        nlo = (1 / (4 * eps * loghi)).numerator // (1 / (4 * eps * loghi)).denominator
        nhi = (1 / (4 * eps * loglo)).numerator // (1 / (4 * eps * loglo)).denominator
        assert nlo == nhi
        n = nlo
        assert n >= 2 and 2 * n + 4 <= 1 / eps
        assert eps * n * loghi <= F(1, 4)
        assert 8 * eps * n * loglo >= 1
        alpha_costs = []
        for numerator in range(5):
            alpha = F(numerator, 4)
            exponent = 2 * alpha * k
            assert exponent.denominator == 1
            required_squared = F(n, 144 * 2 ** exponent.numerator)
            alpha_costs.append({'alpha': fs(alpha),
                                'necessary_C_over_c_squared_lower': fs(required_squared),
                                'necessary_C_over_c_lower_decimal': ds(dec(required_squared).sqrt())})
        records.append({'k': k, 'epsilon': fs(eps), 'n_exact_floor': str(n),
                        'floor_certified_from_log_interval': True,
                        'epsilon_logB_upper_certificate': fs(eps * n * loghi),
                        'eight_epsilon_n_log_lower_certificate': fs(8 * eps * n * loglo),
                        'regularization_fee_upper': '12',
                        'D_over_unknown_lower_coefficient_c_squared_lower': fs(F(n, 144)),
                        'hypothetical_power_requirements': alpha_costs,
                        'status': 'symbolic lower-budget certificate using accepted C_n>=c sqrt(n); c unspecified'})
    return records, {'series': 'log(2)=2 sum_{j>=0} 1/[(2j+1)3^(2j+1)]',
                     'terms': 128, 'lower': fs(lo), 'upper': fs(hi),
                     'tail_bound': fs(hi - lo)}


def normalized_difference_guards():
    """Actual R^n positive-density test for T_n=n(A_{1+1/n}-A_1)."""
    loglo, loghi = log2_interval()
    parameters = {(n, k) for n in (2, 4, 8, 16, 32, 64)
                  for k in (2, 4, 16, 64, 256)}
    selections = {}
    # Cap this exact big-integer family at k=256; no huge-grid enumeration.
    for power in (5, 6, 7, 8):
        k = 2 ** power
        low = F(k, 4 * power) / loghi
        high = F(k, 4 * power) / loglo
        nlo = low.numerator // low.denominator
        nhi = high.numerator // high.denominator
        assert nlo == nhi and nlo >= 2
        parameters.add((nlo, k))
        selections[(nlo, k)] = {'definition': 'n=floor(k/(4 log(k)))',
                                'n_exact': nlo,
                                'logk_rational_interval': [fs(power * loglo), fs(power * loghi)]}
    records = []
    for n, k in sorted(parameters):
        side = F(1, n)
        height = F(n ** n)
        receiver_side = 1 - side
        V = receiver_side ** n
        ratio = F(n, n + 1) ** n
        amplitude = n * (1 - ratio)
        assert height * side ** n == 1
        assert 0 < ratio < 1 and amplitude > 0 and V > 0
        # Direct interval intersection at three actual R^n receivers, all
        # strictly inside the designated receiver cube. Both averages capture
        # the entire density cube; the check uses its Lebesgue intersection.
        samples = []
        for shift in (F(0), F(1, 4), F(-49, 100)):
            x = shift * receiver_side
            assert abs(x) < receiver_side / 2
            averages = []
            for L in (F(1), 1 + side):
                one_dim_intersection = min(side / 2, x + L / 2) - max(-side / 2, x - L / 2)
                assert one_dim_intersection == side
                average = height * one_dim_intersection ** n / L ** n
                averages.append(average)
            assert averages == [F(1), ratio]
            assert n * (averages[0] - averages[1]) == amplitude
            samples.append({'every_coordinate': fs(x),
                            'A_1_exact': fs(averages[0]),
                            'A_1_plus_1_over_n_exact': fs(averages[1])})
        # Weak norm uses strict thresholds; take tau approaching amplitude
        # from below. Thus amplitude^p V is a valid supremum lower bound.
        Qk = amplitude ** (k + 1) * V ** k / n ** n
        assert Qk > 0
        logarithm = dec(Qk).ln()
        norm = (logarithm / Decimal(k + 1)).exp()
        Q = (logarithm / Decimal(k)).exp()
        ratios = []
        for log_power in (0, 1, 2):
            denominator = Decimal(k).sqrt() * Decimal(k).ln() ** log_power
            ratios.append({'log_power': log_power,
                           'weak_norm_lower_over_sqrt_k_log_k_power': ds(norm / denominator)})
        records.append({'n': n, 'k': k, 'p': fs(F(k + 1, k)),
                        'operator': 'T_n=n(A_{1+1/n}-A_1)',
                        'source': 'n^n indicator of centered cube of side 1/n',
                        'source_mass': '1', 'source_height': str(n ** n),
                        'receiver_inner_cube_side': fs(receiver_side),
                        'receiver_volume': fs(V), 'absolute_amplitude': fs(amplitude),
                        'direct_receiver_samples': samples,
                        'input_Lp_power_definition': 'n^(n/k)',
                        'weak_p_power_lower_power_k_exact': fs(Qk),
                        'weak_p_power_lower_decimal': ds(Q),
                        'weak_p_norm_ratio_lower_decimal': ds(norm),
                        'diagnostic_ratios': ratios,
                        'dimension_selection': selections.get((n, k), {'definition': 'fixed parameter grid'}),
                        'status': 'actual finite positive L1 density and Lebesgue receiver volume; normalized difference, not M'})
    return records


def main():
    started = time.monotonic()
    with localcontext() as ctx:
        ctx.prec = 80
        weak = weak_source_guards()
        strong = strong_guards()
        optim = optimization_guards()
        lower, logmeta = lower_budget_guards()
        difference = normalized_difference_guards()
        counts = {'actual_positive_density_weak_p_lower': len(weak),
                  'strong_Lp_analytic_lower': len(strong),
                  'hypothetical_endpoint_scalar_optimization': len(optim),
                  'symbolic_general_alpha_lower_budget': len(lower),
                  'actual_positive_density_normalized_difference': len(difference)}
        weak_values = [Decimal(r['weak_p_lower_decimal']) for r in weak]
        relative_values = [Decimal(r['relative_to_epsilon_minus_half_decimal']) for r in weak]
        opt_values = [Decimal(r['optimized_fee_excluding_unknown_C']) for r in optim]
        strong_values = [Decimal(r['strong_power_lower_decimal']) for r in strong]
        difference_values = [Decimal(r['weak_p_norm_ratio_lower_decimal']) for r in difference]
        data = {'round': 52, 'status': 'PASS', 'standard_library_only': True,
                'counts': counts, 'total_parameter_cases': sum(counts.values()),
                'scope': {
                    'actual_source': 'Three disjoint uniform small cubes, equal masses, R^n Lebesgue receivers; n=1..4.',
                    'actual_source_limit': 'Only a full-capture inner union lower bound. No exact D(p), all-source upper bound, or asymptotic fit.',
                    'strong_vs_weak': 'Strong norm grows at least 1/(2epsilon) on eta=epsilon^2; 1D weak-p has analytic upper 3. These are different endpoint quantities.',
                    'unknown_target': 'Dimension-free weak-p bound D(1+epsilon)<=C epsilon^(-1/2) times logarithmic factors remains unproved.',
                    'optimization': 'Reported fees exclude unknown endpoint coefficient C. Decimal values are scalar diagnostics.',
                    'normalized_difference': 'Actual cube density for T_n=n(A_{1+1/n}-A_1); no implication of a counterexample to the maximal operator M. Finite diagnostic ratios do not reject an unspecified constant.',
                    'lower_budget': 'Assumes previously accepted C_n>=c sqrt(n); c is never assigned a numerical value. Huge dimensions are not enumerated.',
                    'phase_counts': 'Parameter families in one reproducible run, not claims of independent executions.',
                    'old_dyadic_H_lambda_operator_cases': 0},
                'root_precision_bits': {'actual_source': 64, 'strong_scalar': 96},
                'summary_ranges': {
                    'actual_weak_p_lower_decimal': [ds(min(weak_values)), ds(max(weak_values))],
                    'actual_weak_p_relative_to_epsilon_minus_half':
                        [ds(min(relative_values)), ds(max(relative_values))],
                    'strong_power_lower_decimal': [ds(min(strong_values)), ds(max(strong_values))],
                    'hypothetical_optimized_fee_excluding_unknown_C': [ds(min(opt_values)), ds(max(opt_values))],
                    'optimization_dimensions': [1, 256],
                    'lower_budget_k': [16, 256],
                    'lower_budget_n': [lower[0]['n_exact_floor'], lower[-1]['n_exact_floor']],
                    'general_alpha_subchecks': 5 * len(lower),
                    'strong_special_eta_epsilon_squared_cases':
                        sum(r['special_eta_epsilon_squared'] for r in strong),
                    'normalized_difference_weak_norm_ratio_lower':
                        [ds(min(difference_values)), ds(max(difference_values))],
                    'normalized_difference_dimensions': [2, 64],
                    'normalized_difference_k': [2, 256],
                    'normalized_difference_floor_selected_cases': 4},
                'log2_rational_enclosure': logmeta,
                'actual_weak_p_sources': weak, 'strong_Lp_certificates': strong,
                'endpoint_optimization': optim, 'general_alpha_lower_budgets': lower,
                'actual_normalized_difference_sources': difference}
        path = Path(__file__).with_name('results.json')
        path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
        print('PASS', sum(counts.values()), 'parameter cases', counts)
        print('Runtime seconds:', round(time.monotonic() - started, 3))
        print('Results:', path)


if __name__ == '__main__':
    main()
