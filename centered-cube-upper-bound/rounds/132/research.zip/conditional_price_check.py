"""R132 GD16/SS3 conditional scalar prices only: 3 dimensions, no quadrature."""
from pathlib import Path
import hashlib
import json
import sys
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
SOURCES={'good_gate_defect.md':'2db474e72fd580a9d4f4dc2cee5b22c78fad794afc1dcd53cfba48fe738d7bb7',
         'softness_selection.md':'20bd44a1a2308e2f3da361818d7cf65361b14f999bb5b2b39ec4b5b9786074b2'}
POWERS=(80,96,128)
DIGITS=(80,120)
M=16
K=3

def observe(mp,power,digits):
    with mp.workdps(digits):
        n_integer=1<<power
        sqrt_n_integer=1<<(power//2)
        n=mp.mpf(n_integer);S=1/n;eta=mp.power(2,-34)
        fmt=lambda x:mp.nstr(x,digits)
        lower=-mp.expm1(-mp.log(2)/n)
        lowcap=eta**2/(16*M**2)
        A=2*mp.e*mp.sqrt(mp.mpf(K)/3)
        F0=n*(2*mp.sqrt(S)+S*M)
        H0=1+F0+max(mp.mpf(0),mp.log(A))
        hard_price=4*H0*(1+max(mp.mpf(0),mp.log(n/(4*H0))))
        third_log=mp.log(n)+mp.log(mp.log(2))+mp.log(mp.mpf(K)/3)/2-eta*n/4
        third_price=mp.exp(third_log)
        theta=hard_price+third_price
        log_factor=-n*mp.log1p(-S)
        factor=mp.exp(log_factor)
        selected=factor*theta
        sqrt_n=mp.mpf(sqrt_n_integer)
        root_log=sqrt_n*mp.log(n)
        baseline=n*mp.log(2)/4
        # SS4 C=nS=1, exact C<=n/2 for all three specified dimensions.
        factor_SS4=mp.exp(1/(1-S))
        return dict(stage=POWERS.index(power)+1,n_power=power,n_integer=str(n_integer),
            sqrt_n_exact_integer=str(sqrt_n_integer),digits=digits,M=M,K=K,
            S=fmt(S),S_exact_expression='1/2^'+str(power),eta=fmt(eta),
            GD10_cap=fmt(lowcap),cap_exact_expression='2^-80',
            gates=dict(strict_softness_observed=bool(lower<S),strict_softness_symbolic_proof='1-2^(-1/n)<ln(2)/n<1/n=S',
                       strict_lower_numeric=fmt(lower),strict_margin_numeric=fmt(S-lower),
                       low_soft_cap_exact=(power>=80),low_soft_cap_observed=bool(S<=lowcap),
                       cap_equality_exact=(power==80),S_less_than_one=True,
                       SS4_C_nS_exact=1,SS4_C_le_n_over_2_exact=(n_integer>=2)),
            F0=fmt(F0),F0_exact_expression='2*sqrt(n)+16',H0=fmt(H0),
            H0_exact_expression='2*sqrt(n)+18+ln(2) for K=3,M=16,S=1/n',
            theta_hard_price=fmt(hard_price),theta_third_test_price=fmt(third_price),
            theta_third_test_log_price=fmt(third_log),Theta=fmt(theta),
            selector_log_factor=fmt(log_factor),selector_factor=fmt(factor),
            selector_factor_SS4_sharp_upper_numeric=fmt(factor_SS4),selector_factor_SS4_coarse_upper=fmt(mp.exp(2)),
            selected_price=fmt(selected),SS3_positive_coefficient_price=fmt(mp.mpf(16)/3*selected),
            ratios=dict(Theta_over_sqrt_n=fmt(theta/sqrt_n),
                       Theta_over_sqrt_n_ln_n=fmt(theta/root_log),
                       selected_over_sqrt_n_ln_n=fmt(selected/root_log),
                       Theta_over_n=fmt(theta/n),selected_over_n=fmt(selected/n),
                       Theta_over_old_baseline=fmt(theta/baseline),selected_over_old_baseline=fmt(selected/baseline),
                       selected_over_Theta=fmt(selected/theta)),
            status='CONDITIONAL_SCALAR_MPMATH_OBSERVATION_NOT_INTERVAL',
            source_E_M_membership_certified=False,FIRST_FULL_or_source_root_claim=False)

def main():
    import mpmath as module
    if module.__version__!='1.3.0' or not Path(module.__file__).resolve().is_relative_to(VENDOR):
        raise RuntimeError('expected existing mpmath1.3.0 vendor')
    sources={}
    for name,expected in SOURCES.items():
        data=(HERE/name).read_bytes();actual=hashlib.sha256(data).hexdigest()
        if actual!=expected:raise RuntimeError('formula source SHA mismatch: '+name)
        sources[name]=dict(sha=actual,text=data.decode('utf-8'))
    result=dict(header=dict(version='R132-GD16-SS3-price-v1',sources=sources,
                code_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                python=sys.executable,mpmath_version=module.__version__,mpmath_path=module.__file__,digits=DIGITS,
                stages='one preselected dimension per stage: 2^80,2^96,2^128',quad_requests=0,
                scope='conditional formula only: E_M membership and actual source/history/FIRST/FULL unverified; K=3 fixed scalar input is not original K legality certification',
                formulas=dict(Theta='4H0[1+log_+(n/(4H0))]+n log(2) sqrt(K/3) exp(-eta*n/4)',
                    H0='1+n(2sqrt(S)+SM)+log_+(2e sqrt(K/3))',selector='(1-S)^(-n)',
                    SS3='(16/3)(1-S)^(-n)Theta'),interval_certificate=False),cases=[])
    mp=module.mp
    for power in POWERS:
        observations=[]
        for digits in DIGITS:
            try:observations.append(observe(mp,power,digits))
            except Exception as error:
                observations.append(dict(n_power=power,digits=digits,status='EXCEPTION_PRESERVED',error_type=type(error).__name__,error=str(error)))
        comparison={}
        with mp.workdps(120):
            for key in ('Theta','selected_price','selector_factor'):
                if all(key in o for o in observations):
                    v0,v1=(mp.mpf(o[key]) for o in observations)
                    comparison[key+'_relative_precision_difference']=mp.nstr(abs(v1-v0)/abs(v1),120)
        result['cases'].append(dict(n_power=power,stage=POWERS.index(power)+1,observations=observations,
            precision_comparison=comparison))
    result['summary']=dict(case_count=3,observation_count=6,quad_requests=0,
        failed_observations=sum(o['status'].startswith('EXCEPTION') for c in result['cases'] for o in c['observations']),
        parameters_only=True,interval_certificate=False,FIRST_FULL_or_source_root_claim=False)
    target=HERE/'conditional_price_check.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status='SAVED',output=str(target),sha=hashlib.sha256(target.read_bytes()).hexdigest(),**result['summary'])))

if __name__=='__main__':main()
