<!-- SOURCE main_integration.md SHA256 63401932175703022f1213eefb1dbe5599cf4b081af20f1563c7d54d6016fd68 -->
# 第132轮：good门几何衰减、低软度选择与时间截面窗口

日期：2026-10-14。一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未证明。本轮完成三个有明确条件、已独立审查的估计，保留全部未付费用；不登记一般根阶付款。

## 统一接口与结论

原正余项沿用R131 SI5：真实接收积分B、来源概率Π_t的两份乘积、δ_t=[k_t(v)-k_t(z′)]_+、dt/t、完整β_V、V和j。硬来源已按实际行帽积分，其费用16/3；signed母式另乘2Λ，Λ=128/119。不能再次使用已消费N_Z；N_Zc和N_del各保留一次。不同模块中u记号不同：GD用1-t/g，AW用原far指数参数，合用时不得混同。

1. GD3–8给全部合法位置的真实混合核亲和包络。硬交叠费用由原C权重抵消为γ√ω，交叉项≤√γ，全软余项保留min(ω^(-1/2),768√(1+d))，不假定其≤1。三项是三个整维乘积之和，不是逐坐标选赢家。
2. GD9–16在来源质量类 max_m n^(-1)Σ_i D_mi≤M、固定共同L/R/g及软度 1-2^(-1/n)<s≤2^(-72)/M²下，以good门衰减控制真实来源score的时间积分。价格Θ完整列于证明；s=O(1/n)时为O(√n log n)，但低软度窗非空要求极大维数。数值n=6561菜单不属于该条件分支。
3. SS1–4允许共同尺度下任意可测s(x)≤S，以(1-S)^(-n)付软度选择成本。对p与Q同时支配，保留第三全软测试；右侧min不是新good(S)门，不新增FIRST容量。nS=O(loglog n)时此选择成本可为对数幂，仍须满足GD低S条件和质量类。
4. AW3–9确定原两种定向的准确闭尺度窗口；AW12–18给真实核连续尺度包络。固定共同t靠近上端时总对数宽度≤3/n；完整软度arcsine支配另付既有D_n=2πexp(5/16)√n。此包络只替换外部正核，双门仍按实际p/Q/g判断，不能与GD价格直接相乘后声称一般闭合。

## 证据、失败信息与复现边界

亲和量预先固定12例、三个阶段各4例，每例30/50位各一次，共24观察，生产进程退出0；0异常，0精度差标志。原菜单含5个s=1压力测试，它们不属于原去除TOP后的剩余交通。5例观察到亲和量大于1，因此没有采用全域亲和度≤1的强猜测。

同核对照1/4/9理论全线积分恰为1。E4原函数复核指出第4例积分假衰减约2.06023e-7；30/50位差很小不能认证准确度，其求积程序误差估计也不是严格上界。原始数据全部保留并加诊断，不把core或core+tail误称有方向保证的区间证书。诊断新增求积次数0。粗TV候选在活动低门坐标的菜单没有正净余量，不作为本轮主结果。

window_exact_check.py使用标准库Fraction，对3阶段各8例共24例核查尺度、乘积、比例带、far约束和窗口费用代数；全部通过。这只验证有限代数输入，不认证FULL来源交通。条件价格另见conditional_price_check：n=2^80、2^96、2^128，S=1/n、M=16、K=3，80/120位共6观察、零异常、零新增求积；三个参数均满足严格低软度窗。Θ/(√n ln n)约为3.84427、3.87022、3.90267，软度选择因子约e。此项只检查已证公式及显式参数窗，不产生一般证明。

复现：先解压全部归档成员，Python3运行window_exact_check.py即可。affinity_probe.py和diagnostic_check.py依赖既有mpmath 1.3.0，使用PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor，本机解释器为/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3。亲和生产命令见冻结协议，勿重复启动；diagnostic_check.py只重算E4诊断、不跑积分。脚本含本机VENDOR验证，异机需显式调整路径并记录新代码哈希，不声称开箱即用。release_check记录本轮实际重跑范围。不会编译PDF。

## 技能与文献状态

继续使用更新64项技能中N04误差预算与L03精确证书的边界：没有统一误差部分和界不能用望远镜取得总费用；不同精度结果接近不是向外舍入证书。该两技能L–N组自身仍注明进行中审核，不将其名称当已证接口。内部工具RT13、R122共同arcsine混合的适用条件和历史来源由各自审稿逐条记录；本轮不声称新增原始文献定理或重新读完全部64项文献。

## 剩余唯一总任务与下一步

目标始终是任意正L1输入的一般一致根阶预算。尚缺：(i)质量类E_M补集及全部壳层真实质量；(ii)实际低软度窗以外的整个中间软层；(iii)g随接收点移动的尺度成本，尤其早期时间截面；(iv)跨j及完整β/history求和。有限参数块不能被当连续选择器的免费覆盖。

下一步应在保留实际双门的联合接收列上同时处理质量重尾与移动g，不再把这两个费用分开取全域上确界后线性求和。可用本轮GD8作为显式位置包络、AW8作为确切可行尺度域；任何拟议耦合估计必须先保留其来源质量、实际score和误差费用，再筛查命题。这里未给出该耦合命题的证明，也不将重命名余项算进展。

额度：本轮没有可归因到模型或Agent的实际扣额数据，不猜测成本比例。独立作者、审查和数值任务完成后停止，后续复用；不为保持人数启动重复探索。


<!-- SOURCE good_gate_defect.md SHA256 2db474e72fd580a9d4f4dc2cee5b22c78fad794afc1dcd53cfba48fe738d7bb7 -->
# R132：good 门的全位置包络与有限低软度时间分支

**结论与范围。** 得到三项完整混合核的全位置亲和包络 GD8，以及一个固定共同参数、固定 j 的真实来源／时间价格 GD16。核心不是全域亲和度 ≤1：hard–hard 项由原 C 权重抵消为至多 γ√ω；两个交叉项至多 √γ；全软项保留显式、可增长的位置费用。第三个整维测试用已审 RT13 的 hard-window 缺口，不能删去其 √s 全软费用。

GD16 仅在显式很低的软度范围和显式来源几何域内成立。它使用实际 s>1−2^(−1/n)，不是 s=0 扩展；但现有 RT13 常数使其非空维数非常大。没有覆盖当前全部中间软度，更没有支付自适应参数覆盖和 Σj。其余交通完整留在 SI5；不登记一般根阶结论。

实读：R131 `source_integrability.md` SI1–12；R130 `hard_carrier_joint_geometry.md` HC1、3、5，`soft_anchor_extension.md` SA1–4；R128 `joint_receiver_tail.md` RT4–5、RT11–13（RT13 在原文件第159–174行）。不用 RT8 对实际混合载体作替代。

## 1. 对象与共同 Chernoff 式

固定原合法共同 s,L,R,g,j，γ=1+1/n，m₀=min(L,R)，
\[
a\le L,R\le b\le2a,\quad g^2=LR,\quad
m_0\le c_jg\le\gamma m_0,\quad c_jg\le b,
\quad s>1-2^{-1/n}.
\tag{GD1}
\]
记 h_H=H⁻¹1_[−H/2,H/2]，φ_H=H⁻¹φ(·/H)，q_(s,H)=(1−s)h_H+sφ_H。原 φ=h₁*w，w(r)=∫₀¹e^(−|r|/t)dt；F=max(h₁,φ)，C(d)=∫_[−1/2,1/2]F(u−d)du。H₁=L、H₂=min(b,γL)、H₃=b；k₁,k₂=q_(s,H_m)，k₃=φ_b。三个 K_m 是各自的整维乘积，Q*=(K₁+K₂+K₃)/3。

对固定 y,v，令
\[
d_i=|y_i-v_i|/b,\quad
\alpha_i=\frac b{c_j}C(d_i),\quad
\omega_i=\min(1,\alpha_i/g),\quad w_g(v)=\prod_i\omega_i.
\]
原 k_t(v)=#{i:α_i<t}；阈值等号不计入活动坐标。以下始终取同一个 θ 和同一个整维 m，不作逐坐标赢家选择。

令 \(\mathcal B^{B}_\xi(v,z')\) 为 SI4 在一个实际参数恒为上述值的接收子域 B 上的限制；c_ξ、bad、RC、high、history 等均保持原值。因为 0≤c_ξ≤1，只在正上界中删去这些因子及 bad 门，得到
\[
\mathcal B^B_\xi(v,z')\le
\int p(x,y)1_{\{p(x,y)w_g(v)\le KQ^*(x,v)\}}dx
\le\min\left\{1,K^\theta3^{-\theta}
\sum_{m=1}^3\prod_i a_{mi}(\theta)\right\},
\tag{GD2}
\]
\[
a_{mi}(\theta)=\omega_i^{-\theta}
\int_{\mathbb R}q_{s,L}(u-y_i)^{1-\theta}k_m(u-v_i)^\theta du.
\]
证明只用 good 门上的比值 ≥1、(ΣK_m)^θ≤ΣK_m^θ、非负 Tonelli 与固定乘积核的 dx 分解。ω_i>0，故没有零分母。来源 ν 不需要产品结构。系数 3^(−θ) 只出现一次。GD2 本身是旧 Chernoff 入口，不作为新增估计。

## 2. 四项全保留；硬交叠抵消原权重

下文 θ=1/2。对 H∈[L,b]，定义四个真实归一化亲和项 A_hh、A_hφ、A_φh、D_H：例如
\[
A_{h\phi}=\omega^{-1/2}\int\sqrt{h_L(u-y)\phi_H(u-v)}du,
\quad
D_H=\omega^{-1/2}\int\sqrt{\phi_L(u-y)\phi_H(u-v)}du.
\]
其余两项按下标替换。令 ℓ=|[y±L/2]∩[v±H/2]|、d=|y−v|/b。准确地 A_hh=ℓ/√(LHω)。有
\[
\boxed{A_{hh}\le\min\left\{
\gamma\sqrt\omega,
\sqrt\gamma\sqrt{(1-|y-v|/H)_+}\right\},
\qquad A_{h\phi},A_{\phi h}\le\sqrt\gamma.}
\tag{GD3}
\]
第一界：ℓ≤(b−|y−v|)_+≤bC(d)。未饱和时 bC=c_jgω，故 A_hh≤(c_jg/√LH)√ω≤γ√ω；饱和时 A_hh≤1≤γ√ω。另一方面 ω≥ℓ/(γL)：未饱和由 c_jg≤γL，饱和由 ℓ≤L。故 A_hh²≤γℓ/H≤γ(1−|y−v|/H)_+。

交叉项用 Cauchy–Schwarz。第一项平方至多 ω⁻¹∫_[y±L/2]φ_H(u−v)du。因 H≤b、φ 偶单调、该窗包含于 y 的 b 窗，积分≤(b/H)C(d)。未饱和时上界为 c_jg/H≤γ，饱和时直接用概率质量≤1。第二项在 v 的 H 窗积分 φ_L，包含于 v 的 b 窗，同理积分≤(b/L)C(d)，未饱和费用 c_jg/L≤γ。**不把这两个窗当成 hard-z 窗，也没有要求它们长度≤m₀。**

由 √(a+b)≤√a+√b，对 m=1,2，四项全部保留为
\[
a_{mi}(1/2)\le(1-s)A_{hh}
 +\sqrt{s(1-s)}(A_{h\phi}+A_{\phi h})+sD_{H_m}.
\tag{GD4}
\]
这不是混合核亲和度的恒等分解；它是四个非负交项构成的上界。

## 3. 全软费用的全位置显式上界

有一个足够保守但无位置限制的界
\[
\boxed{D_{H_m}\le\mathcal R_i:=
\min\{\omega_i^{-1/2},\ 768\sqrt{1+d_i}\},\qquad m=1,2,3.}
\tag{GD5}
\]
第一项是概率密度的 Cauchy–Schwarz。第二项的证明如下，特别不使用错误的多项式 φ 尾。

对 r≥0，直接限制 w 的 t 积分至 [1−1/(2(1+r)),1]，及在上界作 t↦1/t，给
\[
\frac{e^{-r-1/2}}{2(1+r)}\le w(r)
\le\frac{2e^{-r}}{1+r}.
\]
再与 h₁ 卷积，利用 ||r−u|−r|≤1/2，得到
\[
\frac1{9}\frac{e^{-r}}{1+r}\le\phi(r)
\le8\frac{e^{-r}}{1+r}.
\tag{GD6}
\]
下界可先取 e⁻¹/[3(1+r)]，再用 e<3。已审 logφ 的 4-Lipschitz 性给 C(d)≥e⁻²φ(d)>e⁻ᵈ/[81(1+d)]。原 c_jg≤b 保证 ω≥C。

以 b 缩放接收变量，L,H≥b/2 和偶单调性给
\[
\int\sqrt{\phi_L(u-y)\phi_H(u-v)}du
\le16e^{-d/2}\left(\pi+\frac2{\sqrt{1+d}}\right).
\]
其中中间区间 [0,d] 的剩余积分为 ∫₀ᵈ[(1+r)(1+d−r)]⁻¹/²dr≤π，两侧尾各至多 (1+d)⁻¹/²；b/√LH≤2 已计入16。除以 √ω≥e⁻ᵈ/²/[9√(1+d)]，并用 π<10/3，得到 GD5 的768。位置费用允许增长，不能裁剪为1。

第三测试的 hard-anchor 可直接使用 RT13。令 ρ=1−η、η=2⁻³⁴，κ=√ρ。真实 λ=L/b∈[1/2,1]，RT13 给
\[
\left(\int\sqrt{h_L(u-y)\phi_b(u-v)}du\right)^2
\le\rho\int_{d-\lambda/2}^{d+\lambda/2}\phi
\le\rho C(d).
\]
因 C≤ω，得到 A_hφ,b≤κ，**无 γ 费用**，且对饱和与未饱和 ω 同时成立。因此
\[
\boxed{a_{3i}(1/2)\le\sqrt{1-s}\,\kappa+\sqrt s\,\mathcal R_i.}
\tag{GD7}
\]
纯硬锚点仅作为实际混合核的一个交项使用；√s 项没有删除。RT13 的使用不要求把实际 s 置零。

把 GD3–7 代入 GD2，就是全位置、全合法 s 的可核验分层包络：
\[
\begin{split}
U_{mi}&=(1-s)\min\{\gamma\sqrt{\omega_i},
\sqrt\gamma\sqrt{(1-|y_i-v_i|/H_m)_+}\}
+2\sqrt{\gamma s(1-s)}+s\mathcal R_i\quad(m=1,2),\\
U_{3i}&=\sqrt{1-s}\kappa+\sqrt s\mathcal R_i,\\
\boxed{\mathcal B^B_\xi(v,z')&\le
\min\{1,\sqrt{K/3}\sum_{m=1}^3\prod_i\widehat U_{mi}\}.}
\tag{GD8}
\end{split}
\]
这里当 ω_i=1 时可取 \(\widehat U_{mi}=\min(1,U_{mi})\)，否则取 U_mi。理由是饱和时原 a_mi≤1；未饱和时不作此裁剪。GD8 的三项是上界项，不能称作三个真实赢家事件的精确分拆。

## 4. 一个确实给时间价格的有限分支

取 M≥1，定义真实来源几何域
\[
E_M(y)=\{v:\max_{m=1,2,3}n^{-1}\sum_i D_{H_m}(y_i,v_i)\le M\}.
\tag{GD9}
\]
它只使用三个明确的纯软一维交项，不由未知带门接收列反向定义。GD5 给出的 n⁻¹Σ_i R_i≤M 是不必计算 D 的充分条件；ω_i≥M⁻² 对所有 i 又是其充分条件。这里只限坐标均值，允许少数坐标 D_i 很大，不要求来源坐标独立。可按 M=1,2,4,…作不交壳层；各壳的来源质量与价格须真实求和，不能重复免费领取同一个总容量。

本节额外限制实际软度为
\[
1-2^{-1/n}<s\le\frac{\eta^2}{16M^2},\qquad\eta=2^{-34}.
\tag{GD10}
\]
这是原域的一个很小子区间，不是对原剩余软度的通用假设。它非空的准确必要充分维数条件是
\(n>\log2/[-\log(1-\eta^2/(16M^2))]\)。尤其 n=6561 的实际软度不属于此支。

设 ε_mi=2√s+sD_(H_m)(y_i,v_i)、F₀=n(2√s+sM)。由 GD4，对 v∈E_M，m=1,2，
\[
a_{mi}\le\gamma(\sqrt{\omega_i}+\varepsilon_{mi}),\qquad\sum_i\varepsilon_{mi}\le F_0.
\]
若 α_i<t≤g，则 ω_i=α_i/g<t/g。令 u=1−t/g（这里 u 是本节新积分变量，**不等于**原 h=g exp(−u_old/n) 的固定参数）。由 √ω≤1−(1−ω)/2 及 1+x≤eˣ，乘积得
\[
\boxed{\prod_i a_{mi}\le e\exp\{F_0-k_t(v)u/2\},\qquad m=1,2.}
\tag{GD11}
\]
可把非活动饱和坐标的费用改为0，但本节保守计入 F₀。这里没有隐藏 exp(Cn√s)；下一步明确将它转成时间积分费用。

GD10、κ≤1−η/2、GD7 以及对 n 个正数的 AM–GM 给
\[
\prod_i a_{3i}\le\left[\kappa+\sqrt s\,n^{-1}\sum_iD_{H_3}(y_i,v_i)\right]^n\le(1-\eta/4)^n\le e^{-\eta n/4}.
\tag{GD12}
\]
故记 A=2e√(K/3)、B₃=√(K/3)e^(−ηn/4)，有
\[
\mathcal B^B_\xi(v,z')1_{E_M}(v)
\le1_{E_M}(v)\{
\min(1,Ae^{F_0-k_t(v)u/2})+B_3\}.
\tag{GD13}
\]
这是用 min(1,X+Y)≤min(1,X)+Y 作的正上界；A 中的2来自两个整维硬测试，不是坐标代价或实际赢家分支系数。

原时间窗满足 a/c_j≤t≤g，且 a/c_j≥g/2。因此 0≤u≤1/2 且 |dt/t|=du/(1−u)≤2du。令
\[
H_0=1+F_0+\log_+A.
\]
对任意 0≤k≤n（允许 k 随 t,v 变动），有
\[
k\min(1,Ae^{F_0-ku/2})
\le\min\{n,2H_0/u\}\quad(u>0).
\tag{GD14}
\]
证明取 x=ku/2。x≤H₀ 时直接估计；x>H₀≥1 时，x exp(F₀+logA−x)≤x exp(H₀−1−x)≤H₀。于是
\[
\int_0^{1/2}2\min\{n,2H_0/u\}du
\le4H_0\left[1+\log_+\frac n{4H_0}\right].
\tag{GD15}
\]

在 SI1 的每个实际 t，Π_t 是同一个真实概率，δ_t=[k_t(v)−k_t(z′)]_+≤k_t(v)。不要求 Π_t 不随 t 变动，也不要求 ν 有坐标独立性。将 GD13–15 作逐点界再积分，得到固定共同参数块、固定 j、固定 (ω,V,y) 的来源／时间价格
\[
\boxed{
\int_{J_{far}}\frac{dt}{t}\iint
\delta_t(v,z')\mathcal B^B_\xi(v,z')1_{E_M}(v)
\,d\Pi_t(v)d\Pi_t(z')
\le\Theta(n,s,M,K),}
\tag{GD16}
\]
\[
\Theta=4H_0\left[1+\log_+\frac n{4H_0}\right]
+n\log2\,\sqrt{K/3}\,e^{-\eta n/4}.
\]
也可取与旧基线 (n/4)log2 的较小值：每个 t 有 ∫δ dΠ_t²≤n/4，且 \(\mathcal B^B\le1\)。原 J_far 若为空则贡献0；本证明只扩大其时间区间，不宣称其非空。

特别在同时满足 GD10 的 s≤S/n（S 为给定常数）分支，H₀≤1+2√(Sn)+SM+log_+A。因此固定 M,S,K 时，GD16 为 O(√n log(n+2))，加上明示的指数小项。这是一个真实来源时间积分界，**不是**把局部接收概率替代来源积分。n√s 代价仍在 H₀ 中，不能用于一般 s 接近1的中间层；那时只回到旧粗价。

E_M 也不强制 k_t=0：对 M>1、t/g>M⁻²，可存在 M⁻²≤ω_i<t/g 的活动坐标。原 C 连续从1降至0，故这些原阈值位置的区间非空。这只是参数几何相容性，不认证特定 ν 的 live、FIRST、high 或 FULL 非空实例。

## 5. 回原 SI5 的费用与未覆盖量

GD8 是所有位置／所有实际 s 的新包络；GD16 是其中明确限定的来源／时间分支。其原正项费用为 (16/3)Θ，乘回母式外2Λ后是 (32Λ/3)Θ，再对原 dβ_V(y)、EΣ_V 和实际参数块、j 求和。原 β−ν 全部保留。

在每个固定参数块，把 v∈E_M 且 GD10 成立的交通与补集按真实指示分开。补集仍是
\[
\frac{16}{3}\mathbb E\sum_{V,j}\int d\beta_V(y)
\int\frac{dt}{t}\iint\delta_t\,
\mathcal B_\xi(v,z')\,1_{\mathrm{未覆盖}}\,
d\Pi_t(v)d\Pi_t(z').
\tag{GD17}
\]
可在那里用全位置 GD8 或旧固定参数基线1；没有赋予补集新的根阶价格。远来源的全软费用、超出 GD10 的软度、尺度选择与 Σj 都在此列账，不把不同包络的指数因子直接相乘。

实际 x↦(s,L,R,g) 一般不是固定的。GD16 直接适用于原接收域中共同参数固定的部分；若选择器只有有限／可数参数块，必须对这些块的价格真实求和。连续选择器的离散化误差、上下核比较和覆盖数尚未证明，不能将单块定理直接读成整个 SI4 的上界；唯一 j(x) 也不能自动省掉先分块后的 Σj。没有主张这类恒参数块已覆盖实际未付交通的正测部分。

硬 z 已按 SI2 的真实行帽先积分，其历史接受因子仍包含在 c_ξ≤1 中；不再错误引入总质量／尺度比。原 ν³/e_t² 的两份 ν/e_t 精确保留为 Π_t²，第三份硬 ν 由原 q 与 h_R 帽支付；same-source live、high、严格 bad／非严格 good 和 RC 等均只在正上界中放松，未改定义。N_Zc、N_del 留在原母式各一次，本稿未使用负项，也不取回已消费 N_Z。

数值探路已报告某些实际 near-soft 的 m3 远来源 a>1；这与 GD7 的 √s R 费用一致。本文没有把数值当证明，也不把 TV/P 正 margin 在 ω=1、score=0 的例子作为主要成果。所获改动是可检查的 GD8 及有限范围 GD16；全自适应、多 j 的一般根预算仍未证明。


<!-- SOURCE good_gate_audit.md SHA256 c9e1d02c17d9e000d4cf666d364f352b4d8dcc2c7c28cdf608d167b4d85bcd40 -->
# R132 good 门候选：先行独立审查

STATEMENT_STATUS: PASS_WITH_EXPLICIT_SINGLE_TERM_AND_LOG_CONVENTIONS
GENERAL_ROOT_PAYMENT_STATUS: UNPROVED

此稿只据任务消息与 R132/TASK_CONTEXT、已审原 φ/C 核定义独立推导；尚未读取本轮作者长稿或数值文件。结论是：四项估计及所提乘积常数成立；无需额外的相对误差因子。任意 A 的尾式须写 log₊A；真实赢家单支和三项数值上界拆分的 Chernoff 系数须区别。第三核、D 的条件失败域及实际自适应费用仍留账。

## GG1. 固定参数和准确四项展开

固定整数 n≥1、原 s∈(1−2^(−1/n),1]、a≤L,R≤b≤2a、g=√(LR)、γ=1+1/n、c_j=γ^(−j)，并保留

`m₀=min(L,R)≤c_jg≤γm₀`、`c_jg≤b`。

当前只审 m=1,2：H=L 或 H=min(b,γL)，故 L≤H≤γL≤γb 且 H≤b，测试核与锚点使用同一软度 s。所有参数在接收 x 积分中固定。令 h_L=L⁻¹h₁(·/L)、φ_L=L⁻¹φ(·/L)，q_{s,L}=(1−s)h_L+sφ_L，及

\[
\omega=\min\{1,bC(|y-v|/b)/(c_jg)\}>0,
\quad
a_m={\int_{\mathbb R}\sqrt{q_{s,L}(x-y)q_{s,H}(x-v)}dx\over\sqrt\omega},
\quad
D_m={\int_{\mathbb R}\sqrt{\phi_L(x-y)\phi_H(x-v)}dx\over\sqrt\omega}.
\tag{GG1}
\]

这些是固定来源位置的一维 Lebesgue 接收积分；不是来源概率。分子 affinity≤1，故对每一有限位置 D_m 有限；这不提供位置统一的常数 M。

对混合平方根作非负四项上界，准确系数为

\[
a_m\le(1-s)A_{hh}
 +\sqrt{s(1-s)}(A_{h\phi}+A_{\phi h})+sD_m.
\tag{GG2}
\]

四项的统一估计如下。

- hard–hard：设硬区间交长为 ℓ。若 ω<1，则 ℓ≤bC=c_jgω，因为两硬区间包含于相应长 b 区间，而 C 至少包含它们的硬重叠比例。因此 `A_hh=ℓ/(√(LH)√ω)≤γ√ω`，用 c_jg≤γm₀≤γ√(LH)。若 ω=1，则 A_hh≤1≤γ√ω。两种分支均包括边界。
- hard–soft：Cauchy–Schwarz 给 `∫√(h_L φ_H)≤√(∫_{hard L}φ_H)`。H≤b 及 φ≤F、径向单调性给 `∫_{hard L}φ_H≤bC/H`。未饱和时除 √ω 后≤√(c_jg/H)≤√γ；饱和时用完整概率 affinity≤1。故 A_{hφ}≤√γ。
- soft–hard：同理以 hard H 区间积分 φ_L，有 `∫_{hard H}φ_L≤bC/L`，从而 A_{φh}≤√γ。此处不能误把 L 分母写成 H；两式分别应用，最后同受比例带控制。

于是

\[
\boxed{a_m\le\gamma\sqrt\omega+2\sqrt\gamma\sqrt s+sD_m.}
\tag{GG3}
\]

上式只是把 GG2 中 (1−s)、√(1−s) 放松为 1；不把实际 s 改成零。m=3 的测试软度为 1，GG2 的同软度系数不适用于它。

## GG2. 乘积误差不需要额外常数

若在当前来源 v 的每一坐标都有 D_{m,i}≤M，令

\[
\epsilon_s=2\sqrt s+sM,\qquad F=n\epsilon_s.
\tag{GG4}
\]

由 GG3 和 γ≥1，逐坐标有 `a_{m,i}/γ≤√ω_i+ε_s`。令本节 u=1−t/g（不是原远窗指数参数），0≤u≤1/2。原活动坐标 α_i<t 给 ω_i=α_i/g<t/g=1−u，故

\[
\sqrt\omega_i\le\sqrt{1-u}\le1-u/2.
\]

非活动坐标只用 √ω_i≤1。于是

\[
\begin{cases}
a_{m,i}/\gamma\le1-u/2+\epsilon_s\le e^{\epsilon_s-u/2},&\alpha_i<t,\\
a_{m,i}/\gamma\le1+\epsilon_s\le e^{\epsilon_s},&\alpha_i\ge t.
\end{cases}
\]

乘过 n 个坐标并用 γⁿ≤e，得到候选原常数

\[
\boxed{\prod_i a_{m,i}\le e\exp\{F-k_t(v)u/2\}.}
\tag{GG5}
\]

不应先把 ε_s 除以 √ω_i；那会产生不必要的逆小权误差。上述加法指数化直接保留活动坐标损失，因此无需更大的 F 或额外活动数系数。此证明只要求共同 M 覆盖参与此式的坐标，M 可以依 n；未覆盖来源必须另留账。

## GG3. good Chernoff：三项上界与真实赢家分支不同

固定共同参数后 p=P_{s,L}(x−y) 是概率密度。good 门 `p w_g(v)≤KQ_x^*(v)` 给

\[
B_{good}(v):=\int p1_{good}dx
\le\min\left\{1,\sqrt{K/3}\sum_{m=1}^3\prod_i a_{m,i}\right\}.
\tag{GG6}
\]

证明是 `1_good≤(KQ*/(p w_g))^(1/2)`、Q*=(K₁+K₂+J)/3，再用 √(ΣK_m)≤Σ√K_m。m、θ=1/2 为整维共同选择，没有逐坐标挑选测试。任何额外实际正门只能使左边更小。

令 T_m=√(K/3)∏a_{m,i}。合法的数值上界拆分为

\[
\min(1,T_1+T_2+T_3)\le\sum_{m=1}^3\min(1,T_m).
\tag{GG7}
\]

因此在**上界的单项**上应用 GG5，可用 `A=e√(K/3)`。但 GG7 的三项一般不代表三个真实不交来源事件，不得各自领取一份实际负项或捕获账。

若确要按最大测试核选真实赢家 m，则该域 Q*≤K_m，单支合法 Chernoff 系数为 √K，故用 `A=e√K`。不能未经额外条件把 √(K/3) 直接用于该赢家事件。第三测试 m=3 完整保留；其全 soft 测试不由 GG3–5 自动付款。

## GG4. 截断 score 尾式与完整时间积分

对任意 A>0、F≥0，定义

\[
C_0=F+\log_+A+1\ge1.
\]

则对所有 k∈[0,n]、u>0，

\[
\boxed{k\min\{1,Ae^{F-ku/2}\}
\le\min\{n,2C_0/u\}.}
\tag{GG8}
\]

令 x=ku/2、B=F+log₊A≥0；因 A e^F≤e^B，只需 `x min(1,e^{B−x})≤B+1`。x≤B 时显然；x>B 时令 z=x−B>0，`(B+z)e^(−z)≤B+1`。故式成立。若另明确 A≥1，则 log₊A 可换为 log A。**任意 A 的原写法不成立**：当 F+log A+1<0 时右侧甚至为负。u=0 时只使用 k≤n，不能写 1/u。

在原合法固定参数远窗内，t≥a/c_j，g≤b≤2a，且 c_j≤1，故 t/g≥1/2；上端 t≤g，于是 u∈[0,1/2]。换元 dt/t=−du/(1−u)。对任意可测 k=k(t)∈[0,n]，不要求单调、不要求冻结，GG8 给

\[
\begin{aligned}
\int_{J_{far}}k(t)\min\{1,Ae^{F-k(t)(1-t/g)/2}\}{dt\over t}
&\le\int_0^{1/2}{\min(n,2C_0/u)\over1-u}du\\
&\le\min\left\{n\log2,\;4C_0\left[1+\log_+\frac{n}{4C_0}\right]\right\}.
\end{aligned}
\tag{GG9}
\]

末式第二个界用 (1−u)⁻¹≤2，并在 u=2C₀/n 切分；若 n≤4C₀，则直接用 2∫₀^{1/2}n du=n≤4C₀。第一界来自原概率帽，独立成立。原远窗可为空或更短，扩大至此窗只是正上界。

更一般地，即使 Π_t 及 k_t 随 t 变化，只要其为当时同一归一来源概率、δ_t≤k_t(v)，GG8 的右侧已对 k、来源一致，仍可逐 t 积分并得到 GG9。没有交换不同 t 的来源律，也未假设来源坐标独立。

## GG5. 准确低软度条件价格及尚未覆盖的账

在某固定参数、真实来源子域上，若两个测试 m=1,2 均满足每坐标 D_{m,i}≤M，GG7–9 可给它们的数值上界之和至多两份 GG9。若 K 为原固定常数，并进一步有

\[
s\le S/n,\qquad M\le M_0\sqrt n
\tag{GG10}
\]

其中 S,M₀ 与 n/来源无关，则

`F=2n√s+nsM≤(2√S+SM₀)√n`，

故 m1/2 的固定参数 score–时间价格为 `O_{S,M₀,K}(√n log(en))`。这是明确的条件价格，严格实际下门仍须同时满足；低 s 上界不能替代原下门。没有证明 GG10 覆盖全部来源，也没有证明全局统一 M。仅有 affinity≤1 给 D≤ω^(−1/2)，当 ω 很小时不足以提供所需 M；D 的失败域不能删除或因重命名而视作已付。

对第三核，至少须原位保留 `∫dt/t ∫δ_t min(1,T₃) dΠ_t(z′)dΠ_t(v)`，连同 m1/2 的 D 条件失败域。不能把 GG10 的条件 √n log n 费用写成整个 good 门价格。若某后续证明确实限定到一个真实赢家分支，则按 GG3 的 √K 系数与原不交资格办理。

回实际交通还须保留 dβ(y)、β−ν、原 ν³/e_t²、硬来源帽只领一次、q、EΣ_{V,j}、出生/删除/history 及所有 x 自适应参数。固定参数核积分中的 p 归一化和因子化，不能对 x 依赖 s,L,R,g 直接套用。Π_t 独立 x 并不使这些参数或 D_g/S_g 独立 x。先硬来源帽所得 16/3 也是原条件块操作，不能免除共同块包络、j 求和与原负项资格。

本稿只使用正上界，未消费 N_{𝒵ᶜ}/N_del，已消费 N_𝒵 不返回；GG7 的多个数值项不生成新的负项预算。没有数值运行，没有宣称一般根阶闭合。

**先行停点：GG3、GG5 成立且原 F 常数可保留；GG8 需 log₊A（或 A≥1），真实单赢家支需 √K 系数。GG9–10 给准确固定参数低 s 条件价格，第三核和其余真实费用未付。等待具体作者稿后再按需后审。**

## GG6. 补充先审：坐标均值弱化及第三核

本节仍在作者长稿之前，独立审主代理补充候选；只调用已审 R128 RT13 的真实核常数，不重审其长证明。上文逐坐标 D≤M 是充分而较强的条件，可以严格弱化如下。

### m1/2 只需平均 affinity 帽

令 `ε_i=2√s+sD_{m,i}`，在 GG2 的逐坐标指数化中直接保留 ε_i。若

\[
\overline D_m:=\frac1n\sum_{i=1}^nD_{m,i}\le M,
\tag{GG11}
\]

则 Σ_i ε_i≤n(2√s+sM)=F，故 GG5 原式照旧成立。这里不需要最大 D_i≤M，也没有除以小 √ω_i 的相对误差。GG9–10 的 m1/2 条件价格因此在均值条件 GG11 下成立。

### m3 的 hard affinity 缺口

m3 测试是 φ_b。定义

\[
A_{h\phi,b}=\omega^{-1/2}\int\sqrt{h_L(x-y)\phi_b(x-v)}dx,
\quad
D_3=\omega^{-1/2}\int\sqrt{\phi_L(x-y)\phi_b(x-v)}dx.
\]

原 L/b∈[1/2,1]，故 R128 RT13 对归一化区间 I 给

\[
\left(\int\sqrt{h_L\phi_b}\right)^2
=\frac{(\int_I\sqrt\phi)^2}{L/b}
\le\rho\int_I\phi
\le\rho C(|y-v|/b),\qquad\rho=1-2^{-34}.
\]

区间 I 包含在同中心的长 1 区间内，后者 φ 质量≤完整 C；又 ω≥C，所以

\[
A_{h\phi,b}\le\sqrt\rho,\qquad
a_{3,i}\le\sqrt{1-s}\sqrt\rho+\sqrt s\,D_{3,i}.
\tag{GG12}
\]

这是正软度 mixed anchor 对全 soft 测试的平方根展开，未将整个测试改成纯硬，也没有把原源分布视作产品。

若 `overline D_3≤M` 且 M>0，再要求

\[
s\le 2^{-72}/M^2,
\tag{GG13}
\]

则 √s M≤2⁻³⁶，而 √ρ≤1−2⁻³⁵。于是

\[
\frac1n\sum_i a_{3,i}
\le\sqrt\rho+\sqrt s M
\le1-2^{-36}.
\]

由 AM–GM，

\[
\boxed{\prod_i a_{3,i}\le(1-2^{-36})^n\le e^{-n2^{-36}}.}
\tag{GG14}
\]

D_{3,i}>0 对有限来源位置成立，故 M=0 的非空层不满足均值假设；不应计算 2⁻⁷²/0。这里的常数没有漏平方根或坐标平均系数。

在 GG7 的数值三项拆分中，第三项的固定参数 score–时间费用遂不超过

\[
n\min\{1,\sqrt{K/3}e^{-n2^{-36}}\}\log2
\le n\sqrt{K/3}e^{-n2^{-36}}\log2.
\tag{GG15}
\]

只用 δ_t≤k_t(v)≤n、Π_t 的子/概率质量≤1 和时间窗对数长度≤log2。它不是新的负项支，也没有取得第三核真实赢家分支的 √(K/3) 系数；若按真实最大核赢家分支，则照 GG3 换成 √K。

### 严格软度及完整余域

GG13 还须与原 `s>1−2^(−1/n)` 同时满足。对一个给定 M，非空的必要充分数值条件是

\[
1-2^{-1/n}<\min\{1,2^{-72}/M^2\}.
\tag{GG16}
\]

当 U=2⁻⁷²/M²∈(0,1) 时等价于 `n>log2/[−log(1−U)]`；严格性不能去掉。U≥1 时原软度区间本身非空。若 M=M(n)，必须逐 n 检查，不能拿一个固定 M 的维数门代替。特别 GG10 的低 s 根阶型价格与 GG13 也须同时满足；两条各自形式好看不表示它们对某实际来源层自动有共同覆盖。

因此可审的完整条件层是：固定共同参数下，三项各自满足 GG11，实际 s 满足原严格下门及 GG13；在此层两项 GG9 加一项 GG15 控制固定参数 score–时间上界。若还满足 GG10，则前两项有条件 O(√n log(en)) 价格。该层可以依赖来源 v，但其选择器须可测并保留在来源积分中；D_m 由非负参数积分构成，可用原核可测性与 Tonelli 保证可测。参数/来源变化时 M 的一致性是实质假设。

原正项必须按这一实际条件层与其补域分开；不满足均值帽、GG13 或任何额外来源质量可比条件的部分全部保留原 integrand。本文没有证明这种层覆盖全来源，也不引入未经证明的质量可比假设。j、x 自适应、β/time、ν³/e_t² 和原负项账仍按 GG5 保留；固定核条件界不等于一般付款。

**补充先审 PASS：均值弱化无常数损失；m3 的 2⁻³⁶ 缺口及 GG15 费用正确。原严格软度交集与条件失败域不可省略。完成先行审查，等待作者冻结稿。**

## GG7. 冻结整稿的增量后审

本节在 GG1–GG6 全部先行审查落盘后才读取 `good_gate_defect.md`。实读 SHA-256：`2db474e72fd580a9d4f4dc2cee5b22c78fad794afc1dcd53cfba48fe738d7bb7`。

**FINAL_PROOF_STATUS: PASS_FOR_GD3_8_AND_CONDITIONAL_GD16。无阻断修订。** 该状态仅认证作者明确的固定参数全位置包络及低软度/来源几何条件价格，不认证整个原交通根阶预算。主代理另外的 s(x)≤S 稿不在本次审查范围内；没有读或重跑数值。

### 新增 GD5 位置界：解析核对通过

对 r≥0，限制 w 的积分至 `t∈[1−1/(2(1+r)),1]`，该区间长 1/[2(1+r)]，且 `r(1/t−1)≤r/(1+2r)≤1/2`，因此得到作者的下界。上界可由 t=1/(1+v) 写为

`w(r)=e^(−r)∫₀∞e^(−rv)/(1+v)²dv≤e^(−r)min(1,1/r)≤2e^(−r)/(1+r)`，

r=0 直接用 w(0)=1。与长 1 硬密度卷积时，对 |u|≤1/2 有 `|r−u|≤r+1/2`、`1+|r−u|≤(3/2)(1+r)`，故下界至少 `e^(−r−1)/[3(1+r)]>e^(−r)/[9(1+r)]`。上界使用 `1+|r−u|≥(1+r)/2` 和 `e^(−|r−u|)≤e^(1/2)e^(−r)`，得小于 `8e^(−r)/(1+r)`。GD6 的两个保守常数对全 r 域成立。

再用 C(d)≥e⁻²φ(d)，得到 `ω≥C(d)>e^(−d)/[81(1+d)]`。以 b 缩放，L,H≥b/2 给 b/√(LH)≤2；由偶单调性与 GD6，affinity 分子不超过

\[
16e^{-d/2}\left[\int_0^d{dr\over\sqrt{(1+r)(1+d-r)}}+{2\over\sqrt{1+d}}\right]
\le16e^{-d/2}\left(\pi+{2\over\sqrt{1+d}}\right).
\]

中间段由 `1+r≥r`、`1+d−r≥d−r` 的 beta 积分≤π；d=0 时中间段为零。两侧尾分别写 r=−t、r=d+t，剩余指数 e⁻ᵗ，分母≥√(1+d)，各至多 1/√(1+d)。没有把 φ 的真实 e^(−r)/r 尾误写成纯多项式。

除以 √ω 的下界后，得到 `144[π√(1+d)+2]≤144(π+2)√(1+d)<768√(1+d)`。结合两概率密度的 Cauchy–Schwarz 给 D≤ω⁻¹/²，故 GD5 的 min 界对 m=1,2,3 及全部有限位置成立，包括饱和权。它允许随位置增长，没有被错误裁成 1。

### 其他新增与合并步骤

- GD3 新增的第二个 hard–hard 界正确：ω≥ℓ/(γL)，故 A_hh²≤γℓ/H；因 L≤H，区间交长 ℓ≤(H−|y−v|)₊，从而得到作者的距离截断式。GD4 的四项是上界而非恒等式，稿中已明确。
- GD7 的 m3 平均缺口与先行 GG12–14 一致。GD8 的饱和裁剪只在 ω_i=1 时使用 a_mi≤1；未饱和坐标没有非法裁剪。三个乘积仍分别使用整维共同 m。
- GD9 的 E_M 以真实 D 的坐标均值定义；由 GD5 可用平均 R_i≤M 作充分条件，而每坐标 ω_i≥M⁻² 确实推出 R_i≤M。可测性由非负参数核积分及有限求和给出。壳层分解不免费，作者已保留其来源质量/价格总和。
- GD10 与先行 GG16 相同：M≥1 时 U=η²/(16M²)=2⁻⁷²/M²∈(0,1)，严格非空条件准确为 `n>log2/[−log(1−U)]`。n=6561 不在该实际软度支内；原 far 窗也可能为空，稿中未把数值相容性当 FULL 实例。GD11 的 F₀ 使用均值 D 帽，无额外相对误差。

### GD16 两项合并只付一份时间价：通过

由 GD11，两个 hard 测试的数值上界之和不超过 `2e√(K/3)exp(F₀−ku/2)`。因此先设 A=2e√(K/3)，再使用 `min(1,X+Y)≤min(1,X)+Y`，得到 GD13。这里应付一份以 `H₀=1+F₀+log₊A` 为参数的 GG9 时间价，**不必**把单项时间价再乘 2。作者明确这些只是上界项，并未误用为两个真实赢家分支。

GD14 的任意 A 情况使用 log₊A，修正了先行指出的域问题。GD15 在 n≤4H₀ 时左侧为 n≤4H₀；n>4H₀ 时在 u=2H₀/n 切分恰得 `4H₀[1+log(n/(4H₀))]`。第三项用 δ≤n 和时间长度≤log2，精确保留 `n log2 √(K/3)e^(−ηn/4)`。两份 Π_t 的概率归一化逐 t 使用，不要求 k 或 Π_t 不随 t 改变，故 GD16 的来源时间界成立。

与旧 `(n/4)log2` 基线取 min 也合法：E_M 指示及接收列均≤1，完整同 Π_t 双源满足 Eδ≤n/4。GD10 再交 s≤S/n 时 H₀≤1+2√(Sn)+SM+log₊A；固定 M,S,K 下声明的 O(√n log(n+2)) 条件价格正确。它不覆盖一般 s，也不说明 E_M 承担全部真实来源。

作者 GD17、第 5 节保留条件失败域、实际 x 自适应/参数覆盖、j 求和、β−ν、ν³/e_t² 与原正门的定义。硬来源帽只消费一次；外母式因子 (16/3)·2Λ=32Λ/3 正确。N_{𝒵ᶜ}、N_del 未消费，N_𝒵 不返回。全位置 GD8 与有限条件 GD16 的适用范围明确，未将它们登记为一般根阶闭合。

**最终绑定结论：整稿在所声明固定参数范围内通过；新增 GD5 的解析常数和 GD16 的合并时间价均正确。未覆盖部分照旧留账。审查完成后停止，不扩展数值或其他稿件。**


<!-- SOURCE softness_selection.md SHA256 20bd44a1a2308e2f3da361818d7cf65361b14f999bb5b2b39ec4b5b9786074b2 -->
# R132：低软度选择器的正包络费用

主代理推导；独审状态另见附件。本稿保持实际尺度L,R,g共同固定，允许软度s=s(x)为任意可测选择器。它不覆盖尺度选择器，不把固定参数结果当一般闭合。

令0<S<1，实际0<s(x)≤S且保原strict下门。记r=(1-S)^(-1)，p_s=P_s,L，Q_s=(P_s,L+P_s,Lplus+P_1,b)/3，ω及wg仍为实际固定g的权重。逐坐标
\[
q_{s,H}\le r q_{S,H},
\]
因为1-s≤1=r(1-S)，且s≤S≤rS。三整维测试中全软项不变，也被r^n支配，故
\[
p_s\le r^n p_S,\qquad Q_s\le r^n Q_S.
\tag{SS1}
\]
对原good门p_s w_g(v)≤KQ_s(v)，逐接收点有
\[
p_s1_{good(s)}\le\min\{p_s,\sqrt{Kp_sQ_s/w_g(v)}\}
\le r^n\min\{p_S,\sqrt{Kp_SQ_S/w_g(v)}\}.
\tag{SS2}
\]
右侧的min不是新good(S)事件的指示函数。取真实dx积分，并用积分min≤两积分的min，固定S的GD Chernoff三项包络依然适用，另付r^n。丢bad/RC/history仅在正上界中进行，原负项不动；Π_t不依x、外硬帽合法等条件与GD原命题相同。

令D_mi、E_M为GD的全软余项及max_m坐标均值≤M的来源类。它们只依真实φ、H_m、L及ω，不依s，故在s(x)变化下同一个E_M仍合法。假定固定S满足GD的S≤2^-72/M²及实际strict可行性，固定j的E_M部分来源／时间价至多
\[
\frac{16}{3}(1-S)^{-n}\,\Theta(n,S,M,K),
\tag{SS3}
\]
尚需恢复β、V等外层。Θ取GD16原完整三测试时间价，不省略第三测试或其指数尾。本式使用固定S概率核作正包络，不能因此新增一份FIRST容量或把实际比较门改判成good(S)。

若nS=C且C≤n/2，则
\[
(1-S)^{-n}\le e^{C/(1-C/n)}\le e^{2C}.
\tag{SS4}
\]
这是软度适应性费用，不能无条件称常数。取C=O(loglog n)、M=(log n)^O(1)、log_+K=O(log n)，在GD低S条件最终满足的大维范围内，Θ的硬测试项为O((√(nC)+CM+log_+K+1)log n)，乘e^(2C)仍为√n乘对数幂；第三测试n√(K/3)exp(-n2^-36)log2也完整保留。这里只是给定质量类及共同尺度上的条件时间价格；低软度之外、E_M补集和全部j/尺度覆盖没有被证明可付。

因此不必在这个明确低软度窗口额外机械支付全区间arcsine D_n，但不能拿SS4免除实际L(x),R(x),g(x)的变化成本。N_Z已消费不返还，N_Zc与Ndel各一次保留。


<!-- SOURCE softness_selection_audit.md SHA256 484d3be61e3ea7d009d06954338d46dd4e96a22a30645e4bbab2f93fc624b051 -->
# R132 softness selection：先行代数映射与条件预算独审

## 先行独立筛查（读作者稿之前）

固定L,R,g,j及同一物理源权wg，0≤s(x)≤S<1，r=(1−S)^(−1)。原一维q_s=(1−s)h₁+sφ中hard系数比(1−s)/(1−S)≤r、soft系数s/S≤1≤r（S=0时直接单hard），故q_s≤r q_S。整维p_s≤r^n p_S，两个同软度测试同样支配；第三测试J=P_(1,b)不随s变且r≥1，所以三整维平均Q_s≤r^nQ_S。

在真实good门p_s wg≤KQ_s上，p_s²≤Kp_sQ_s/wg≤r^(2n)Kp_SQ_S/wg；另始终p_s≤r^n p_S，因而

\[
p_s1_{\{p_sw_g\le KQ_s\}}
\le r^n\min\{p_S,\sqrt{Kp_SQ_S/w_g}\}.
\]

这个式子保留原门在左侧，右侧是正包络；不将事件重判为p_S wg≤KQ_S，不更换RC，亦不赋予p_S新的FIRST等式或独立容量。第三测试完整保留。若原额外门/ρ≤1，乘入左式仍是正上界；signed负项不可同样正替换后相减。

nS=C≤n/2时 `−nlog(1−S)≤nS/(1−S)≤2C`，所以r^n≤e^(2C)。C=O(loglog n)才给polylog费用；若C无统一帽或S接近1，则不能称此选择成本为常数。原actual strictsoftness还要求每个非空行s(x)>1−2^(−1/n)，因此S也必须高于此下端；不额外扩域到s=0。

此代数结论PASS。固定S来源/时间包络若确已证明、且其来源质量类仅依同一ν、wt、et、t,g等固定对象，则可乘r^n涵盖可测软度选择器。是否满足S≤2^(−72)/M²等工具条件及GD16具体价格，须后读定义核对；本稿不预设GD预算已审PASS。L/R/g若也随x变，当前映射不免费涵盖这些选择，也未付Σj或原source总账。

## 作者稿后审与最终绑定

ALGEBRA_MAPPING_STATUS: PASS
GD16_BUDGET_TRANSFER_STATUS: PASS_CONDITIONAL_ON_GD16
GD16_PROOF_STATUS: NOT_REAUDITED_HERE
NEW_GENERAL_ROOT_PAYMENT_STATUS: NONE

先行代数筛查保存后读取主代理 `softness_selection.md`，实读、复核SHA-256：`20bd44a1a2308e2f3da361818d7cf65361b14f999bb5b2b39ec4b5b9786074b2`。只读GD必要定义、GD13–16价格及条件以核映射，没有将待审GD16另认证为一般结果；不改他人文件，不执行数值/Git/PDF。

### SS1–2及固定S包络转接：PASS

作者单坐标系数比较、两同软度测试的r^n支配及第三全软测试J的保留，与先行独证完全一致。SS2第一步是原good门内平方估计，门外左边零；第二步两个因素各付r^n后取平方根，最终只付r^n而非r^(n/2)或r^(2n)。min不定义新good(S)事件；作者明确这一点。

取真实dx积分，`∫min(p_S,√(Kp_SQ_S/wg))≤min(∫p_S,∫√(Kp_SQ_S/wg))`；∫p_S=1，另一项以完整三整维Q_S拆成 `√(K/3)Σ_m∏_i a_(m,i)(1/2;S)`。因此SS2确落在GD2同一个固定S正包络上，另乘r^n。3^(−1/2)及三项和不变，没有逐坐标重选赢家。原bad/RC/FA/Ψ/history可乘左侧而在正上界中删掉，不能给负项套同样包络后相减。

S≥s(x)只作原future软度测试的比较；该证明没有使用新的p_S f=q等式，也没有新增一份FIRST或重新构造同源ν。原实际strictsoftness不改变。

### 来源质量类与低S条件：PASS于固定几何和原来源接口

已读GD定义 `D_H(y_i,v_i)=ω_i(v)^(−1/2)∫√(φ_L(u−y_i)φ_H(u−v_i))du`；它只依φ、L、H、C及固定g权重，不依混合软度s。H₁=L、H₂=min(b,γL)、H₃=b在本任务固定，所以 `E_M={max_m n^(−1)Σ_iD_(H_m)≤M}`不随s(x)改变，三个测试均保留。若尺度/g也变化，这一来源类不再由本证明免费固定。

GD的低软度上限为η²/(16M²)，η=2^(−34)，确等于2^(−72)/M²；作者SS3完整保留该条件及原strict可行性。非空实际选择器类须有S>σ_n=1−2^(−1/n)；否则左侧类为空，不能以形式价格冒称新覆盖。GD最大允许上限的非空维数条件为 `n>log2/[-log(1−2^(−72)/M²)]`；若使用更小具体S，需相应更强的 `n>log2/[-log(1−S)]`。此外M≥1及GD的原far/固定Π_t/硬帽条件仍继承，不能将ν、Z_t或Π_t按软度重新选择。

### SS3–4价格和第三测试：条件转接PASS

在GD16成立的范围内，固定S的F₀=n(2√S+SM)、H₀=1+F₀+log₊(2e√(K/3))及

\[
\Theta(n,S,M,K)=4H_0[1+\log_+(n/(4H_0))]
+n\log2\sqrt{K/3}\,e^{-n2^{-36}}
\]

全部原样保留。SS2的点态正包络可在真实t与两份Π_t下按GD16同样积分，故固定j、E_M部分原正价格为 `(16/3)r^nΘ`；这仍待GD16本身独审确认。原母式外2Λ若回账需再乘一次，完整系数为 `(32Λ/3)r^nΘ`，另积分β、EΣV、j及合法参数块；SS3未声称这些外层已付。

nS=C≤n/2时 `r^n≤exp(C/(1−C/n))≤e^(2C)`正确。C=O(loglog n)、M=polylog(n)、log₊K=O(log n)且低S条件最终成立时，Θ硬测试部分为 `O((√(nC)+CM+log₊K+1)log(n+2))`，乘e^(2C)给条件√n对数幂价；第三测试的 `n log2 √(K/3)e^(−n2^(−36))`仍在Θ内且同乘r^n，未删除或使用错误尾指数。C任意/靠近n不能称polylog成本，作者SS4准确保留限制。

### 未付范围与最终判定

此次映射确可涵盖固定L,R,g下的任意共同可测s(x)≤S低软度选择器，不需再机械付全软度arcsine包络；但它不能覆盖低S域外、E_M补集、L/R/g自适应、Σj/time总和和完整β/source价格，亦不认证这些恒尺度域已有实际正质量覆盖。原scoreδ在GD时间价格中按原对象处理，没有从r^n映射另获score损失。

N_Z已消费不返还，N_Zc/N_del各一次未消费；原signed母式和RC价格不变。**最终结论：SS1–2代数映射、SS4选择成本PASS；SS3及条件根时间价仅在GD16及全部显式低软度/来源条件成立时转接，GD16在本稿不另作全证明认证。一般root目标UNPROVED。** 绑定以上SHA后停止。


<!-- SOURCE adaptive_window_geometry.md SHA256 7aa318d0f6dee1c132222ff83d09f483b86e4b73d2b178fba8055001d1b33291 -->
# R132：原比例带与共同时间截面的接收尺度窗口

**结论。** 原比例带把固定 g,j 下的 L、R 限制在两个各至多 γ 倍的定向窗口。固定原共同时间 t 后，g 仍可变化，但两个 L 窗口可以精确写出；靠近允许时间上端时，其尺度包络成本为绝对常数。下文给出真实混合核的连续尺度支配，以及一次共同软度混合后的显式积分价。这里没有冻结实际 g(x)，没有改成全软算子，也没有支付全部 Σj、score、history 或原 signed 根预算。

只使用 R128 RT1–6、R131 SI4–5 和 R122 已审共同软度混合；不修改其他文件，不执行数值、Git 或 PDF。端点以闭窗口作正外包，原唯一比例带的端点归属不变。

定向资格已回查 R114 `ratio_settlement.md` §1、S1–2：原尺度变量明确是 \(|\log(L/R)|\)，实际接口为 \(a\le L,R\le b\)，没有固定 \(L\le R\)。因此下文保留两支；不是把硬、软核标签互换。若另一个已合法限制的子交通只含其中一支，可直接删掉另一支的包络项。

## 1. 固定 g,j 的精确代数窗口

令 γ=1+1/n、c=c_j=γ^{-j}≤1、m=min(L,R)，保留

\[
a\le L,R\le b\le2a,\qquad LR=g^2,
\qquad cg/\gamma\le m\le cg.
\tag{AW1}
\]

固定 g,j，设

\[
\ell(g)=\max\{a,g^2/b,cg/\gamma\}.
\tag{AW2}
\]

则闭合代数可行域恰为

\[
m\in[\ell(g),cg],\qquad
g\in[a/c,bc],
\tag{AW3}
\]

其中第二个区间非空才有可行参数。证明：小尺度下界是 a，配对大尺度 g²/m≤b 等价于 m≥g²/b，比例带再给第三个下界。因 c≤1，上界 cg≤g；其余 L,R 下界和上界随之成立。区间非空等价于 a≤cg 且 g²/b≤cg，即 a/c≤g≤bc。

两种定向分支为

\[
\begin{array}{ll}
L\le R:& L\in[\ell(g),cg],\quad R=g^2/L;\\
L\ge R:& L\in[g/c,g^2/\ell(g)],\quad R=g^2/L.
\end{array}
\tag{AW4}
\]

两个 L 区间各自的端点比都等于 cg/ℓ(g)≤γ。固定 g,j 的尺度自由度因此不是整个 [a,b]。但两支通常相隔：不能把两个窄窗合称一个 γ 倍窗。L=R 的重合不需重复计数，保留两项求和则是安全上界。

## 2. 共同 t 所允许的 g 和两个 L 窗口

原 far 时间限制为

\[
t\in I_{j,V,y}\cap[a/c,g(x)e^{-u/n}],\qquad u>0.
\tag{AW5}
\]

固定 ξ=(ω,V,j,y,t)，令

\[
G=t e^{u/n},\qquad
d=d_j(t)=\log\frac{bc}{G}.
\tag{AW6}
\]

若 t<a/c 或 t>bc e^{-u/n}，对应贡献为空。在其余时间内 G≥a/c，实际

\[
G\le g(x)\le bc,\qquad 0\le d\le
\ell_j=[\log(bc^2/a)-u/n]_+.
\tag{AW7}
\]

不能从 t≤g e^{-u/n} 推出 g=t e^{u/n}：它只给单侧下界。对 AW4 在全部 g∈[G,bc] 上取并集，得到以下**闭合代数域的精确投影**：

\[
\boxed{
I_-=[A_-,B_-]=[\max\{a,G^2/b,cG/\gamma\},bc^2],
\qquad
I_+=[A_+,B_+]=[G/c,b].}
\tag{AW8}
\]

实际 history、FIRST、双门可进一步缩小此域；本稿不声称 AW8 的每个参数都在实际交通中出现。

证明投影的反向包含也不需额外假设。小尺度分支上，ℓ(g) 随 g 非减，cg≤bc²，故落在 I_-。若 L∈[ℓ(G),cG]，取 g=G；若 L∈[cG,bc²]，取 g=L/c、m=L。两者均满足 AW1。大尺度分支上 L≥G/c 且 L≤b；反向对任意 L∈[G/c,b]，取 g=cL、m=c²L，AW1 同样成立。因此 AW8 没有先按整个 [a,b] 支付覆盖。

记两窗对数宽度 W_±=log(B_±/A_±)，有

\[
\boxed{W_+=d,\qquad
0\le W_-\le\min\{2d,d+\log\gamma,\log(bc^2/a)\}.}
\tag{AW9}
\]

三项分别来自 A_-≥G²/b、A_-≥cG/γ、A_-≥a。特别当 d=0，两窗都退化为单尺度 bc² 与 b；当 0≤d≤1/n，W_-+W_+≤3/n。

## 3. 真实核的连续尺度包络

原一维核 p_s=(1−s)h₁+sφ 偶且随绝对值非增。因此对任意固定 s∈[0,1]、z∈Rⁿ，

\[
H^nP_{s,H}(z)=\prod_{i=1}^n p_s(z_i/H)
\quad\text{随 }H\text{ 非减}.
\tag{AW10}
\]

所以 H≤U 时 P_{s,H}≤(U/H)^nP_{s,U}。对 AW4 两个窄窗，各用一个上端点便给固定 g 的点态支配

\[
P_{s,L}(z)\le\gamma^n
\big[P_{s,cg}(z)+P_{s,g^2/\ell(g)}(z)\big],
\qquad\gamma^n\le e.
\tag{AW11}
\]

这里 g 必须固定；把 g 改为 g(x) 后，右端仍是移动尺度核，不能据此将其空间积分当作 2。

对任意固定实尺度窗 0<A≤B，由 AW10 可以得到比网格更直接的支配：

\[
\boxed{
\sup_{H\in[A,B]}P_{s,H}(z)
\le P_{s,B}(z)+n\int_A^B P_{s,H}(z)\frac{dH}{H}.}
\tag{AW12}
\]

确切证明：令 f(H)=HⁿP_{s,H}(z) 非减。任意 H∈[A,B] 满足

\[
P_{s,B}(z)+n\int_H^B P_{s,r}(z)\frac{dr}{r}
\ge f(H)\left[B^{-n}+n\int_H^B r^{-n-1}dr\right]
=P_{s,H}(z).
\]

再扩大非负积分到 [A,B] 即得 AW12。这不需要在硬核跳面求导，也不使用自由尺度图的 Jacobian。右端的真实 Lebesgue 积分准确为

\[
1+n\log(B/A).
\tag{AW13}
\]

退化窗 A=B 时保留单个概率核，费用为 1。

## 4. 同一个可变软度的完整费用

实际 s(x)>σ_n:=1−2^{-1/n}。使用 R122 已审共同 arcsine 混合，在每个 n 一次固定软度节点与权重，定义

\[
K_H(z)=\int_0^1P_{\sigma_n+(1-\sigma_n)r,H}(z)
\frac{dr}{\pi\sqrt{r(1-r)}},\qquad
D_n=2\pi e^{5/16}\sqrt n.
\tag{AW14}
\]

则 ∫K_H dz=1，且 sup_{s∈[σ_n,1]}P_{s,H}≤D_nK_H。它可以用至多 n+1 个共同矩节点精确表示，所有坐标、尺度与接收点使用同一组节点。只用其核支配与空间质量；不声称 σ_n 节点必满足每个实际行更强的 FIRST 软度门，也不据此新增 q 容量。

这里引用的是 R122 `remaining_mixture_geometry_private.md` 的 RM-S，以及 `softness_mixture_proof_audit_private.md` §1–2 已核准的常数 \(D_n=2\pi e^{5/16}\sqrt n\) 和共同节点实现；它是既有工具，不登记为本轮新软度估计。

HⁿK_H(z) 同样非减。对 I_± 定义

\[
E_\pm(z)=K_{B_\pm}(z)+n\int_{A_\pm}^{B_\pm}K_H(z)\frac{dH}{H},
\qquad E_{j,t}=D_n(E_-+E_+).
\tag{AW15}
\]

于是对于原 ξ 固定后、任何仍合法的可测 s(x),L(x),R(x)，在其贡献域上严格有

\[
\boxed{p_x(y)\le E_{j,t}(x-y),\qquad
\int E_{j,t}(z)dz
=D_n[2+n(W_-+d)]
\le D_n[2+n(d+\min\{2d,d+\log\gamma\})].}
\tag{AW16}
\]

两窗若重叠，可先合并后用一次 AW12，减少常数；AW16 为统一安全版本。特别 d≤1/n 时该成本≤5D_n。固定共同 s 时在 AW15 中直接用 P_{s,H} 代替 K_H，删除 D_n；这并未将实际任意软度改成固定软度。

因此得到的是原真实混合算子的窄窗包络，不是换成 P_{1,H}。软度只付一个 D_n，不逐坐标、逐节点或逐空间来源重复付根阶费用。

## 5. 放回 SI4 时保留双门及全部剩余费用

保留 SI4 已积分硬 z 后的 0≤c_ξ(x;v,z′)≤1，原 Q*、g(x)、RC、FA、Ψ、history 均按实际参数计算。AW16 只替换外部正核 p，给

\[
\mathcal B_\xi(v,z')\le
\int E_{j,t}(x-y)c_\xi(x;v,z')
1_{D_{g(x)}}(z')1_{S_{g(x)}}(v)\,dx.
\tag{AW17}
\]

**不得**将双门里的 p、Q* 或 g 改成包络节点的值；不把 good/bad 集移出 x 积分。此式是带门联合对象的严格接收包络。若继续把门丢掉，才得到 AW16 的无来源位置常数，那一步会再次失去联合几何收益。

共享 t 确实削减靠近上端的尺度成本，但没有使全部 t 窗都变窄。由 d=log(bc/t)−u/n，dt/t=−dd，且 0≤d≤ℓ_j，所以全时间的粗包络价满足

\[
\int_{a/c}^{bc e^{-u/n}}\int E_{j,t}(z)dz\,\frac{dt}{t}
\le D_n\big[(2+n\log\gamma)\ell_j+n\ell_j^2\big]
\le D_n(3\ell_j+n\ell_j^2).
\tag{AW18}
\]

空时间窗取零；原 I_{j,V,y} 仍可进一步缩小积分。特别末端截面 d≤h≤1/n 的总包络价至多 5D_n h≤5D_n/n。这个局部时间收益不可免费推广到整个区间；剩余 d>1/n 区域没有在本稿中得到额外支付。

这个末端窗口不被称为“已付根阶分支”：原 score、Σj、两份来源概率、完整 β 与 history 的总账尚未完成。

例如仅看原尺度/时间代数，在 j=0、b/a=2 且固定 u、n 增大时，最早允许 t=a 给 d=log2−u/n，仍为常数量级。这不是实际 FULL 行反例；它只证明本稿所用比例带与 far 时间约束本身不强迫所有截面都是 O(1/n) 窄窗。固定 g 的定向宽度已被压缩，**剩余的尺度自由参数是 g 在 [t e^{u/n},bc] 内的移动**；软度 s(x) 的费用另外由 AW14 明确保留。

原 SI5 仍须积分 δ_ξ(v,z′)dΠ_ξ(v)dΠ_ξ(z′)，再对 dt/t、Σj、完整 dβ_V(y) 和 EΣV 求和。AW18 不取消这些步骤，不删除 β−ν；原唯一 j(x) 也不允许在逐 j 包络后免除总和。以所有门都丢弃的粗基线估计，Σj 的窗口数仍可为 O(n)，因而不能把 AW16 的局部根阶软度价登记为全局根阶付款。

全程不改变原 signed 母式：N_{𝒵ᶜ}、N_del 各保留一次，不取回已消费 N_𝒵，也不对负项套正包络后相减。

**完成范围：** AW3–9 给原约束直接产生的精确闭窗口；AW12–18 给无网格、保留真实混合核的严格包络和显式维度成本。它减少了末端时间截面的真实自适应尺度费用，并定位早期截面仍未收缩的 g 自由度。没有证明联合 score/source/history 的全局根预算，到此停止。


<!-- SOURCE adaptive_window_audit.md SHA256 6a1b5922c8962b252fb278fea3e4c3329ff3b6c31b417cfea2d01652061b1d06 -->
# R132 adaptive scale windows：先行独立量词与正包络审查

STATEMENT_AUDIT_STATUS: PASS_WITH_POSITIVE_TIME_AND_WINDOW_SCOPE
GENERAL_ROOT_BUDGET_STATUS: UNPROVED

本稿只核父任务给出的命题，未读取 `adaptive_window_geometry.md` 作者稿；R132 TASK_CONTEXT尚不存在，不据此补造新定义。原R131比例带、strictsoftness、固定t来源接口及原费用继承不改。

## 1. 固定g的两个尺度支：PASS

假设γ=1+1/n，0<c_j≤1，a≤L,R≤b≤2a，g²=LR，m=min(L,R)，原带 `c_jg/γ≤m≤c_jg`。它与R131 `m≤c_jg≤γm` 完全等价，无方向反转。

m≤g，而原带上界c_jg≤g已包含此条件。m≥a且max(L,R)=g²/m≤b给m≥g²/b。因此固定g时恰有

\[
M_0(g):=\max\{a,g^2/b,c_jg/\gamma\}\le m\le c_jg.
\]

若M₀>c_jg为空。若非空，L小/大两支分别为

\[
L\in[M_0,c_jg],\qquad
L\in[g/c_j,g^2/M_0],
\]

各乘法宽度均为c_jg/M₀≤γ。原a/b限制已经通过M₀保留；两支L=R可重合，求和上包络可以重计该点但须付两支费用。非空还推出g≤bc_j及g≥a。

## 2. 固定正t的并集窗口：PASS，明确padding

需要t>0、u固定，令G=t exp(u/n)>0。实际 `t≤g exp(−u/n)` 等价g≥G。任一非空实际行又有g≤bc_j，故必有G≤bc_j；否则该t窗口无实际行。令d=log(bc_j/G)≥0。

L小支中M₀(g)随g递增且c_jg≤bc_j²，因此所有可能L均在

\[
I_-=[\max\{a,G^2/b,c_jG/\gamma\},bc_j^2].
\]

L大支L≥g/c_j≥G/c_j且L≤b，因此包含于

\[
I_+=[G/c_j,b].
\]

空区间忽略，闭端点只作上包络。对非空I_-，上端与G²/b、c_jG/γ两下端比较，准确得到

\[
\logwidth(I_-)\le\min\{2d,d+\log\gamma\},
\qquad\logwidth(I_+)=d.
\]

此为**包含**，不声称这些外区间每个尺度都可由合法g/m实现。裸t上门未保证G/c_j≥a，故给出的I_+可能含a以下padding；用它做正核包络可以，但不能把其padding当原合法FIRST测试尺度。若需窗口全在[a,b]，应改成I_+^act=[max(a,G/c_j),b]，其宽度≤d。对真实far另有t≥a/c_j时，G/c_j≥a自动成立；这一简化依赖该下门，不由父命题单独上门推出。t=0不能定义d或有限乘法窗口，原dt/t实际正窗没有该点。

固定g的γ窄窗与固定t的d宽窗不能混同：g随x时并集一般不再只有γ宽度。

## 3. 正核尺度支配：PASS，直接证明兼容hard跳

令q_s为固定s的非负偶径向递减概率密度，P_(s,H)(x)=H^(−n)∏_iq_s(x_i/H)。对固定x，F(H)=H^nP_(s,H)(x)非减。对任意A≤h≤B，

\[
P_{s,B}(x)\ge(h/B)^nP_{s,h}(x),\qquad
n\int_h^B P_{s,H}(x)\frac{dH}{H}
\ge P_{s,h}(x)[1-(h/B)^n].
\]

两式相加并扩大正积分至[A,B]即给

\[
\sup_{H\in[A,B]}P_{s,H}(x)
\le P_{s,B}(x)+n\int_A^B P_{s,H}(x)\frac{dH}{H}.
\]

该证明仅用单调性，不需q_s或P_H可微，物理hard面的正跳已经包含。等价Stieltjes证明中，d(H^nP_H)是正测度，其贡献以减号丢去；不能把正跳当负误差。原闭hard核的H版本及B端点可用；尺度sup有合法可测版本。Tonelli及∫P_H=1给右侧质量恰为 `1+n log(B/A)`，因而sup积分≤该值。若q_s不归一化为概率，质量需相应修改，不能只凭偶递减断言1。

将两窗口的正包络相加、空窗省略，可得固定s的保守总质量

\[
\le2+n\{d+\min(2d,d+\log\gamma)\}.
\]

固定g两支则总质量≤2(1+n logγ)≤4。上述都是固定中心/同源核包络；窗口和中心的选择量词不能免费改变。

## 4. s选择、D_n与费用边界

固定s的尺度证明不允许把实际s(x)直接冻结。若采用已审真实全mask先验包络E_H，逐H同时支配原P_(s,H)、质量D_n≤1+(π/2)√n；E_H仍同形且沿H有H^nE_H非减，故可合法得 `∫sup_H E_H≤D_n[1+n log(B/A)]`。这里D_n只引用原h/φ完整mask正包络的已审结论，不引用自由核表/arcsine工具的未知迁移。两支soft包络费用对应乘D_n，不能把D_n省去，亦不能把依s的倾斜、门或来源权自动纳入E_H。

特别R131 θ=s/32768的接收矩、原Q*三整维和及其good/bad绝对门、RC、g/h、score和history都有实际x参数依赖；对裸P_s的上述上包络不等于这些联合矩已获共同包络。固定t后ν/Z_t/w_t/e_t不依x可使用Tonelli，但原终端D_g/S_g与RC不提前抽出。真实hard z、β−ν、ν³/e_t²、δ、FA/Ψ、dt/t、Σj及全部截断仍保留；若放松唯一j或拆分两支/参数窗必须显式支付费用。

d若为常数量级，n d可造成额外维数费用；固定g的窄窗不证明实际g(x)选择的总源价格。也没有从窗口几何证明该费经原时间/来源平均为O(polylog n)，或可由未消费负项抵消。原N_Zc/N_del各一次未消费，N_Z不返回，主账不变。

**先行结论：给定正时间及原尺度带，两个全位置包含窗口和正核尺度支配成立；padding/合法FIRST范围、s选择与全部来源费用需按上文保留。未证明一般根阶。** 等待作者冻结稿增量绑定，不读取其长证明或改他人文件。

## 5. 冻结作者稿的增量证明复核

FINAL_PROOF_AUDIT_STATUS: PASS_FOR_WINDOWS_AND_POSITIVE_ENVELOPES
GENERAL_ROOT_BUDGET_STATUS: UNPROVED
NEW_GENERAL_PAYMENT_STATUS: NONE

先行独立稿保存后读取 `adaptive_window_geometry.md`，最终实读、复核SHA-256：`7aa318d0f6dee1c132222ff83d09f483b86e4b73d2b178fba8055001d1b33291`。本轮TASK_CONTEXT此时已落盘，亦已读取；初次未存在的记录保留为时间顺序，无未解决定义缺口。只补核作者所指R114比例带及R122已审arcsine常数/共同节点接口；未运行数值或修改他人文件。

1. **AW1–4闭合可行域PASS。** 作者补出更准确g范围[a/c,bc]：a≤cg且g²/b≤cg分别给这两个端点。ℓ(g)≤cg等价这些条件，第三项cg/γ≤cg自动。定向两支端点比相同且≤γ。R114 `ratio_settlement.md:11`确用|log(L/R)|，原接口a≤L,R≤b没有指定L≤R；保留两支不是换硬/软标签。

2. **AW5–9实际正时间及精确投影PASS。** 作者明列t≥a/c，故G≥a/c，原G≤bc时cG≥a；先行I_+低于a的padding风险已由实际far下门解除。除已证正向包含外，作者反向构造成立：L∈[ℓ(G),cG]取g=G，L∈[cG,bc²]取g=L/c,m=L；大支L∈[G/c,b]取g=cL,m=c²L，各满足[a,b]、g²=LR及比例带。因此AW8确为闭合代数域精确投影，但不保证FIRST/history实际实现。W_+=d、W_-三上界及d=0退化窗、d≤1/n时总宽≤3/n全部正确。时间为空直接零；原比例带实际半开归属未改。

3. **AW10–13含hard跳的连续尺度包络PASS。** H^nP_H非减及作者直接积分证明与先行独证相同；无需硬面导数或额外Stieltjes假设。固定g的两个上端点比较成本γ^n≤e合法，但右端在g(x)时仍移动尺度，作者没有把其积分当2。AW12右侧质量1+nlog(B/A)、A=B单核费用1正确。可测sup/普通sup基线只作粗包络，不是新根付款。

4. **AW14–16真实arcsine包络及一次费用PASS。** 已实际读取R122 `softness_mixture_proof_audit_private.md` §1–2，核常数 `D_n^arc=2πexp(5/16)√n`，标准arcsine节点每n只预固定一次、至多n+1节点同时实现n次多项式矩。作者σ_n=1−2^(−1/n)是全实际软度的共同下端，K_H质量1，H^nK_H非减；先取arcsine支配再尺度包络，质量 `D_n^arc[2+n(W_-+d)]` 正确。这里作者D_n是概率arcsine混合的支配常数，与本审第4节可选完整mask包络的质量常数属于两个合法实现，不能混同或替换实际账中符号。作者明确混合节点可能低于某行实际s，不将它们误当该行合法FIRST测试，不添q容量。软度、坐标、尺度及接收点共用同一组节点，没有重复根阶费用。

5. **AW17–18带门回代与时间费用PASS于给定SI接口。** 外部正核p被E替换时，双门内p/Q*/g、RC/FA/Ψ/history仍在原x实际参数判定，不改判包络节点。在固定ξ给定SI4的合法cξ≤1接口上，正扩大方向正确；本审没有据此重新认证SI4的上游母式。由W_-≤d+logγ及dt/t=−dd，积分d∈[0,ℓ_j]给 `D_n^arc[(2+nlogγ)ℓ_j+nℓ_j²]≤D_n^arc(3ℓ_j+nℓ_j²)`，nlogγ≤1正确。末端d≤h≤1/n包络质量≤5D_n^arc，总时间价≤5D_n^arc h，h窗被实际ℓ_j截短只减少费用。

作者第203–211行明确没有将末端价登记为已付根分支：原δ dΠ²、dt/t、Σj、完整β−ν、history及signed负项仍在。所有t不因共享时间而变成O(1/n)宽窗；j=0,b/a=2且最早t=a时d=log2−u/n说明单靠尺度代数仍可能为常数量级，该例没有冒称FULL。原N_Zc/N_del各一次，N_Z不返回。

**最终绑定结论：AW3–9精确闭窗口、AW12–18真实核包络及显示成本PASS。实际窗口对原门的覆盖量、score/source总价格及一般signed根预算仍UNPROVED；无新一般付款。** 无需作者修订，本审到此停止。


<!-- SOURCE soft_range_history.md SHA256 631b55969ec2a3799970c639f1db8b62d65bb7eb8fc4442ec712cd270bbc7d8a -->
# 原实际软度范围与第三测试：限定历史核对

本记只核原 R114 分支及 R128–131 的必要原对象；为查 R114 的继承删除门，另取已经定位的 R117 独审祖链两段。不重证历史结论，不作数值或新付款。以下“未找到”仅指这些有限片段。

## 1. SI4/RT2 的实际软度范围

原实际下门仍是
\[
s(x)>1-2^{-1/n}>\frac{\log2}{2n}.
\]
R128 已追溯其 FIRST/FULL/history 继承，并明确实际 \(s=0\) 交通为空；RT1–6 才是未付原泛函，RT10/14–22 的硬端点只是删掉该下门后的扩展条件模型。[原下门及范围分离](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:5)

确有另一条继承上门，但它是**近全软切除**，不是小软度上界。已接受 CS/BC 总账的独审原文规定：只有
\[
n>4\cdot10^6\log(n+2),\qquad
d_n=1000\sqrt{\frac{\log(n+2)}n}<\frac12
\]
才作 TOP/LOWTRACE/HIGHTRACE 分割；互补小维数由完整强包络一次支付。先删除 TOP/LOWTRACE，再删除实际 softtop \(L_s>b-2a/n\)，等号保留。因此该祖链的实际余项继承
\[
s\le1-d_n,\qquad L_s\le b-2a/n
\]
及其余原门。没有 \(d_n=\min(1/2,\ldots)\) 的截断版本，也不能仅凭 \(n\ge512\) 宣称该实际大维余项非空。[删除范围与独审正面祖链](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:168)

R114 严格接收 R113 的同一 \(\Gamma_F^c,T_F^c\)，保留原 FULL/FIRST/strict CP/GP/deep、失败币及软来源核；上面的独审祖链明确 R114 没有替换原 \(x,s,L_s,a,b\)。[R114 原输入](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:9) 当前 SI3/4 又保留全部实际参数/history，并把先前已付子支的不交化指示纳入 \(a_\xi^+\)；没有新增小软度门。[SI3/4](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/source_integrability.md:32)

结论：当前实际未付中间硬层有继承的近全软上门；本次有限定位**未找到** \(s\lesssim\mathrm{polylog}(n)/n\) 的已审上界，也未找到将其以上全部中高软度交通支付的结果。TOP 已付不能替代后一结论。最近固定参数核引理允许较宽软度范围，亦不解除实际交通的祖链门。

## 2. 原第三测试全软仍必须保留

原三个测试是
\[
K_1=P_{s,L},\qquad K_2=P_{s,L^+},\qquad
J=K_3=P_{1,b},\qquad Q_x^*=(K_1+K_2+J)/3.
\]
第三测试内部软度为 \(1\)，与实际锚核的 \(s(x)\) 分属不同位置；缩小锚软度不允许删掉 \(J\) 或把它改成 \(P_{s,b}\)。FIRST 对 \(J,Q^*\) 的共同容量帽仍保留。[RT5 与原帽](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:68) [BD 三个整维测试](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/bad_denominator.md:26)

BD 的已审坏分母消除用 \(Q^*(bad)\ge J(bad)/3\)，而 good 端对三个**整维**核求和；两个 \(3^{\pm\theta}\) 只在整维消掉一次，不能逐坐标任选测试或产生 \(3^n\)。[BD 独审](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/bad_denominator_audit.md:26) 辅助 \(s=0\) 支撑外可强制 m3 唯一赢家，是边界模型专属推理，不能据此删除实际 \(s>0\) 的另两个测试。[边界独审](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail_proof_audit.md:33)

## 3. 可以调用的 normalized hard-window/full-soft affinity 缺口

**可以直接调用 RT13，前提是归一化对象准确。** 它对任意位置、任意区间 \(I\) 长 \(\lambda\in[1/2,1]\) 已证明
\[
\frac{(\int_I\sqrt\phi)^2}{\lambda\int_I\phi}\le1-2^{-34}.
\]
原文明确区间概率是 Lebesgue 均匀概率，不是来源概率；独审核过常数、全位置及整个长度范围。[RT13](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:161) [独审全范围](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail_proof_audit.md:25)

具体接口：给硬窗口 \(W=[z-R/2,z+R/2]\)，\(R/b\in[1/2,1]\)，令
\[
u_W=1_W/R,\quad Z_W=\int_W b^{-1}\phi((x-v)/b)\,dx>0,\quad
q_W=1_Wb^{-1}\phi((x-v)/b)/Z_W.
\]
取 \(I=(W-v)/b\)、\(\lambda=R/b\)，RT13 的同一式恰给
\[
\int_W\sqrt{u_Wq_W}\,dx
=\frac{\int_I\sqrt\phi}{\sqrt{\lambda\int_I\phi}}
\le\sqrt{1-2^{-34}}<1.
\]
这只是已审式的归一化重述；乘积硬立方体与同窗口受限归一化的乘积全软核得到 \((1-2^{-34})^{n/2}\)，乘积性来自真实 \(dx\) 与给定核，不要求来源 \(\nu\) 独立。第三测试的 pure hard \(L\) 与 full-soft \(b\) 满足 \(L/b\in[1/2,1]\) 时可用。[原乘积调用](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:169)

此接口尚不能换成实际条件化载体 \(p_s(x-y)h_R(x-z)/\int p_sh_R\)，也不能免费取接收点自适应参数的上确界。RT8 已明说不认证带硬 \(z\) 条件化载体的归一化缺口；BD 也明确非归一化矩的指数衰减不能直接转为实际条件化概率的严格矩阵缺口，因为归一化质量本身可能指数衰减。[RT8 明确边界](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:99) [BD 归一化警示](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/bad_denominator.md:181) 因而已审 hard-window 缺口可复用，但实际 SI4/RT2 的完整联合费用仍未由它支付。


<!-- SOURCE affinity_diagnostic_note.md SHA256 ea8e161947fb2a88655d2aef8a90d6d8b5c73b6b30fc65dd1116bacab1c3c648 -->
# R132：亲和积分与误差诊断

旧 affinity_protocol.md、affinity_probe.py、affinity_results.json 未改动；本补充只读取被冻结结果并计算 E4 原函数，不导入 producer、不重跑 quad、不增加核菜单。diagnostic_check.py/json 单独保留计算与哈希绑定。E4 数值使用既有 mpmath 1.3.0、80 digits，仍不是区间认证。

12 例 × 30/50 digits 的旧结果有 5 个明确浮点 gain：ID6=6.3810457683、ID7=1.1325798767、ID8=1.2031132617、ID11=1.0454646319、ID12=14.5609526033。原始结果未裁剪。它们相对 1 的差远大于所记录的 quad 估计，但该估计不是严格误差界。五例 core 的两几何硬区间交集外费用分别等于整个 core（ID6/7/11/12）或约 0.8855685（ID8），因此 gain 的来源是 core 中的软区间费用，并非被截去的极远尾。

ID1/4/9 的同位置、同尺度、同软度、ω=1 控制有全线解析 a=∫q=1。旧标签 LOSS 仅表示未经裁剪的 core 数字小于 1，不能说是真实全线损失。T 超过硬区间时，原 φ 的 E3 差有 E4 原函数，故同核精确截断表达为

    core_exact = 1 − 2s[E4(T/L−1/2)−E4(T/L+1/2)].

真实截断尾的 E4 浮点值为 ID1 4.79775e−41、ID4 4.53900e−37、ID9 4.62335e−41；对应旧 core−core_exact 约 −2.17768e−11、−2.06023e−7、−2.18069e−11。这些偏差明显来自核心 quadrature，并非截断尾或多精度舍入。E4 公式是解析恒等式；其 80 位求值没有 outward rounding。

旧实验的两精度共用 Gauss–Legendre maxdegree=6 和相同有限分片，改变 digits 主要改变算术精度，不保证提高积分节点的近似阶。最大 30/50 位差仅 4.284e−29，而最大核心 quad 估计 5.945e−7，两者测量不同误差。控制 ID4 的实际核心偏差 2.06023e−7 略超过其 quad 估计 2.000002e−7；ID1/9 亦如此。这直接说明 mpmath 的估计不能当作严格误差上界，更不能用精度一致认证积分准确。旧全菜单解析指数截断尾上界的浮点最大值为 1.010e−34，与 core 误差另列。

新公式的全软余项 D=∫R√(φ_L(u−y)φ_H(u−v))/√ω(v)du 可直接复用 s=1 的 ID4/6/8/10/12，因这时 sm 也等于 1，不需新 quad。它们的旧 D_core 依次约为 0.999999794、6.381045768、1.203113262、0.999999783、14.560952603；完整数值、核心估计、解析尾数值和精度差在 diagnostic_check.json 中分别保留。ID4 的完整 D 解析恰为 1，不能把上述数字视作真损失；ID10 的接近 1 也不能仅靠同精度一致认证。其余 near 例的 D 不计算、不自由填造。

候选 TV margin 的旧结果也保留原含义：所有 ω<1 例子的 τ²−log(1/ω)<0；唯一正 margin ID10≈3.728e−9 有 ω=1、g 截点一坐标 score=0。因此旧菜单未给出“正 margin 且 g 坐标 score=1”的实例。此结论不能替代原较早时间 t 的判定。

时间价部分本次未计算，等待作者准确常数及适用域冻结。若另授权 n=2^80/2^96/2^128、s=1/n、M=16 的条件核算，须单独绑定公式；这些平方根可精确为 2^40/2^48/2^64，且严格 soft 由 1−2^(−1/n)<ln2/n<1/n 得到。旧 n6561 near 菜单的 s≈0.0001057006，不据此冒认满足未来极低 s 分支。所有补充仍不授 FIRST/FULL、真实来源或 root 结论。


<!-- SOURCE release_check.md SHA256 c69454aa58d18fdc9f9d490863f320ac81cc5c6ca692d505b33c46fc8055804f -->
# R132 归档前独立核验

RELEASE_CHECK_STATUS: PASS
WINDOW_ISOLATED_REPLAY: EXECUTED_AND_BYTE_IDENTICAL
INTEGRATION_PRODUCERS_RERUN: NO
HIGH_PRECISION_DIAGNOSTIC_OR_PRICE_RERUN: NO
GENERAL_ROOT_PAYMENT_CERTIFIED: NO

PASS仅覆盖本次列出的作者/审稿绑定、冻结资产、24项窗口精确重放及新增条件费用的静态一致性。本角色仅新增本文件，没有改作者、旧数据或源码，没有Git/PDF操作；没有重新认证所有上游数学证明或原FIRST/FULL实例。

## 1. 作者与独审绑定

|作者文件|当前SHA-256|审稿与准确结论|
|---|---|---|
|good_gate_defect.md|`2db474e72fd580a9d4f4dc2cee5b22c78fad794afc1dcd53cfba48fe738d7bb7`|good_gate_audit.md的GG7最终实读绑定一致；先行GG1–6及后审部分在同一份独立审稿内。GD3–8及条件GD16通过，完整一般根预算未证。|
|adaptive_window_geometry.md|`7aa318d0f6dee1c132222ff83d09f483b86e4b73d2b178fba8055001d1b33291`|adaptive_window_audit.md第5节最终绑定一致；闭窗口/正包络及显示费用通过，未付actual参数/来源总账。|
|softness_selection.md|`20bd44a1a2308e2f3da361818d7cf65361b14f999bb5b2b39ec4b5b9786074b2`|softness_selection_audit.md最终绑定一致；SS代数与固定几何低软度条件转接通过，GD16依赖由上列最终GD审稿提供。SS审稿自身不重复认证GD16。|

主代理已澄清“两个GD审稿”指先行/后审两部分，不是第二位独立GD审者。不存在第二份审稿不作为缺口，也没有虚构双审。

本次实读审稿SHA：

- good_gate_audit.md：`c9e1d02c17d9e000d4cf666d364f352b4d8dcc2c7c28cdf608d167b4d85bcd40`。
- adaptive_window_audit.md：`6a1b5922c8962b252fb278fea3e4c3329ff3b6c31b417cfea2d01652061b1d06`。
- softness_selection_audit.md：`484d3be61e3ea7d009d06954338d46dd4e96a22a30645e4bbab2f93fc624b051`。

范围准确保留：GD来源几何均值帽、极低s和补域；AW固定g窄窗与固定t并集宽窗、arcsine常数及窗口价格；SS只涵盖固定L/R/g的s(x)≤S选择器。三整维测试保持整维求和，真实赢家分支与Chernoff数值上界项不混同；β、ν³/e_t²、Σj、实际自适应、history和未消费负项仍留账。

## 2. 六个冻结affinity/diagnostic资产

|文件|bytes|SHA-256|
|---|---:|---|
|affinity_protocol.md|3124|`60d0ea8924dac91ed56549c19ab729f93306ed4608330afee340d3c2d5450d4d`|
|affinity_probe.py|13809|`1ba364f86d06e9372f563af5b7490e2510c1de3c38f0fcfe59ed09b02a36124e`|
|affinity_results.json|205349|`fcf6621458c42fb2a655f7c50802efc9510b92afc296ed10be8d8d486e97f01b`|
|affinity_diagnostic_note.md|3355|`ea8e161947fb2a88655d2aef8a90d6d8b5c73b6b30fc65dd1116bacab1c3c648`|
|diagnostic_check.py|4194|`604070f96a865290e9d8f2c62ec605d72be1df0352bac0e979088d21dbaf69f3`|
|diagnostic_check.json|6832|`f75e47e7fe79ff67b7922267090dcb50f6e63015e3ed119de1ebe9600e013a07`|

affinity结果header的源码、协议、完整协议快照哈希均与现文件一致；diagnostic源码内置的三项affinity SHA及结果header的输入绑定一致，diagnostic_code_sha也匹配现代码。diagnostic note无另一个运行时内置SHA，本表明确绑定其当前字节。

affinity12例×30/50位共24观察，原数据没有裁剪。5个core gain只是有限浮点观察；ID1/4/9解析全线a=1。diagnostic用E4原函数的截断恒等式解释这些同核控制，未导入/重跑producer；记录new_quad_requests=0、new_kernel_cases=0。ID4约2.06023e−7的旧core假亏损不能称真loss，30/50位稳定不能认证积分准确。C求积估计、core求积估计、精度差与解析截断尾分开，均非向外舍入证书。所有ω<1例子的TV margin负；唯一正margin是score=0的ID10。s=1例只能作广义核/D交项测试，原TOP已排该剩余交通，不能据此声称s=1原中间层FULL。m3的分量soft=1不改变near例的anchor实际s。

## 3. 窗口精确隔离重放

实际将window_exact_check.py原字节复制到新临时目录，以 `/opt/homebrew/bin/python3 -I` 执行一次，cwd为该临时目录；解释器版本3.14.6，只有标准库Fraction/JSON/hashlib/pathlib。退出0、stderr为空。临时目录内结果与scratch原window_exact_results.json **逐字节完全一致**，临时目录在比较后清理；没有覆盖原JSON。

|文件|bytes|SHA-256|
|---|---:|---|
|window_exact_check.py|1548|`509d0dce5caf6cab546fd3d578b85329794664f7d668af9385d9acf0e742621a`|
|window_exact_results.json|14465|`220162ce83365fc38c4390ab68cfc7bfe0892f7767dc53d18b41105f0ccb5f8d`|

24/24 case，阶段[8,8,8]，所有布尔checks为真；结果source_sha256与复制源码/现源码一致。有限有理检查核尺度窗、g乘积、比例带、far时间和两个方向分支/宽度，不认证FIRST/history或实际窗口覆盖量，也没有积分原核。

## 4. 新增conditional price：只读静态核验

新增文件已出现，本次仅读源码、保存结果及GD/SS相应公式，没有执行该程序或新的高精度计算。

|文件|bytes|SHA-256|
|---|---:|---|
|conditional_price_check.py|6160|`08a5afba232827ae1443e1aa74932b41f9d33e776bfb2d60839e416772c71eb0`|
|conditional_price_check.json|45428|`1f297b9a1aeaefce70e73822ed05431d114804e2942aad8707685c9fbe6cd232`|

结果header的code_sha匹配；内嵌GD/SS作者文本及各自SHA均与第1节现作者一致。3个预指定维度n=2⁸⁰/2⁹⁶/2¹²⁸，分别80/120位，共6观察，0异常、quad_requests=0；它们不是6次原核积分。

M=16、K=3、S=1/n、η=2⁻³⁴时，GD10上限η²/(16M²)=2⁻⁸⁰。三维度S均在该上限内，n=2⁸⁰恰为等号；严格下门由 `1−2^(−1/n)<log2/n<1/n` 保证，不依赖取消误差。整数平方根2⁴⁰/2⁴⁸/2⁶⁴和F₀=2√n+16字段逐项核对。

代码与GD16/SS3公式一致：A=2e、H₀=2√n+18+log2；Θ保留4H₀[1+log₊(n/(4H₀))]及第三项n log2 exp(−n2⁻³⁶)，第三项的极小数和log单独保存，没有删成0。selector=(1−S)^−n以log1p稳定计算；SS3正项价为(16/3)selector·Θ，母式2Λ不伪造为已付外层。保存的Θ/(√n log n)约3.84427/3.87022/3.90267，selected/(√n log n)约10.44981/10.52036/10.60855；它们只是条件公式的有限观察，不以三点拟合认证增长阶。

结果明确E_M membership未认证、K=3不代表原K合法性认证、FIRST/FULL/来源history未验证。此新增文件的时间价格不等于diagnostic本身重跑；diagnostic里NOT_COMPUTED状态仅描述它自己的任务，不能误读为本轮没有新增独立scalar-price资产。

## 5. 依赖与不可移植边界

affinity、diagnostic、conditional price都强制mpmath1.3.0来自本机绝对vendor路径 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`，并记录bundled Python3.12.14。单独复制脚本/JSON到新机器不能直接宣称可运行，须显式供给正确依赖并满足路径守卫；没有自动安装或独立包封装认证。window精确脚本只用标准库，本次隔离重放实际成功。

数学审稿仍依赖所明确引用的旧轮RT13真实核缺口、arcsine来源接口、SI/GD母式及原资格；SHA绑定确认当前字节，不替代这些上游证明/原文的阅读，也不让有限浮点、source路径或工具目录名认证一般付款。实际固定块到全部自适应参数、全来源及所有j的统一预算仍未闭合。可按以上范围归档，不能写成一般root目标完成。
