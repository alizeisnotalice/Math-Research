# R132：good 门的全位置包络与有限低软度时间分支

**结论与范围。** 得到三项完整混合核的全位置亲和包络 GD8，以及一个固定共同参数、固定 j 的真实来源／时间价格 GD16。核心不是全域亲和度 ≤1：hard–hard 项由原 C 权重抵消为至多 γ√ω；两个交叉项至多 √γ；全软项保留显式、可增长的位置费用。第三个整维测试用已审 RT13 的 hard-window 缺口，不能删去其 √s 全软费用。

GD16 仅在显式很低的软度范围和显式来源几何域内成立。它使用实际 s>1−2^(−1/n)，不是 s=0 扩展；但现有 RT13 常数使其非空维数非常大。没有覆盖当前全部中间软度，更没有支付自适应参数覆盖和 Σj。其余交通完整留在 SI5；不登记一般根阶结论。

实读：R131 `source_integrability.md` SI1–12；R130 `hard_carrier_joint_geometry.md` HC1、3、5，`soft_anchor_extension.md` SA1–4；R128 `joint_receiver_tail.md` RT4–5、RT11–13（RT13 在原文件第159–174行）。不用 RT8 对实际混合载体作替代。

## 1. 对象与共同 Chernoff 式

固定原合法共同 s,L,R,g,j，γ=1+1/n，m₀=min(L,R)，
\[
a\le L,R\le b\le2a,\quad g^2=LR,\quad
m_0\le c_jg\le\gamma m_0,\quad c_jg\le b,
\quad s>1-2^{-1/n}.
\tag{GD1}
\]
记 h_H=H⁻¹1_[−H/2,H/2]，φ_H=H⁻¹φ(·/H)，q_(s,H)=(1−s)h_H+sφ_H。原 φ=h₁*w，w(r)=∫₀¹e^(−|r|/t)dt；F=max(h₁,φ)，C(d)=∫_[−1/2,1/2]F(u−d)du。H₁=L、H₂=min(b,γL)、H₃=b；k₁,k₂=q_(s,H_m)，k₃=φ_b。三个 K_m 是各自的整维乘积，Q*=(K₁+K₂+K₃)/3。

对固定 y,v，令
\[
d_i=|y_i-v_i|/b,\quad
\alpha_i=\frac b{c_j}C(d_i),\quad
\omega_i=\min(1,\alpha_i/g),\quad w_g(v)=\prod_i\omega_i.
\]
原 k_t(v)=#{i:α_i<t}；阈值等号不计入活动坐标。以下始终取同一个 θ 和同一个整维 m，不作逐坐标赢家选择。

令 \(\mathcal B^{B}_\xi(v,z')\) 为 SI4 在一个实际参数恒为上述值的接收子域 B 上的限制；c_ξ、bad、RC、high、history 等均保持原值。因为 0≤c_ξ≤1，只在正上界中删去这些因子及 bad 门，得到
\[
\mathcal B^B_\xi(v,z')\le
\int p(x,y)1_{\{p(x,y)w_g(v)\le KQ^*(x,v)\}}dx
\le\min\left\{1,K^\theta3^{-\theta}
\sum_{m=1}^3\prod_i a_{mi}(\theta)\right\},
\tag{GD2}
\]
\[
a_{mi}(\theta)=\omega_i^{-\theta}
\int_{\mathbb R}q_{s,L}(u-y_i)^{1-\theta}k_m(u-v_i)^\theta du.
\]
证明只用 good 门上的比值 ≥1、(ΣK_m)^θ≤ΣK_m^θ、非负 Tonelli 与固定乘积核的 dx 分解。ω_i>0，故没有零分母。来源 ν 不需要产品结构。系数 3^(−θ) 只出现一次。GD2 本身是旧 Chernoff 入口，不作为新增估计。

## 2. 四项全保留；硬交叠抵消原权重

下文 θ=1/2。对 H∈[L,b]，定义四个真实归一化亲和项 A_hh、A_hφ、A_φh、D_H：例如
\[
A_{h\phi}=\omega^{-1/2}\int\sqrt{h_L(u-y)\phi_H(u-v)}du,
\quad
D_H=\omega^{-1/2}\int\sqrt{\phi_L(u-y)\phi_H(u-v)}du.
\]
其余两项按下标替换。令 ℓ=|[y±L/2]∩[v±H/2]|、d=|y−v|/b。准确地 A_hh=ℓ/√(LHω)。有
\[
\boxed{A_{hh}\le\min\left\{
\gamma\sqrt\omega,
\sqrt\gamma\sqrt{(1-|y-v|/H)_+}\right\},
\qquad A_{h\phi},A_{\phi h}\le\sqrt\gamma.}
\tag{GD3}
\]
第一界：ℓ≤(b−|y−v|)_+≤bC(d)。未饱和时 bC=c_jgω，故 A_hh≤(c_jg/√LH)√ω≤γ√ω；饱和时 A_hh≤1≤γ√ω。另一方面 ω≥ℓ/(γL)：未饱和由 c_jg≤γL，饱和由 ℓ≤L。故 A_hh²≤γℓ/H≤γ(1−|y−v|/H)_+。

交叉项用 Cauchy–Schwarz。第一项平方至多 ω⁻¹∫_[y±L/2]φ_H(u−v)du。因 H≤b、φ 偶单调、该窗包含于 y 的 b 窗，积分≤(b/H)C(d)。未饱和时上界为 c_jg/H≤γ，饱和时直接用概率质量≤1。第二项在 v 的 H 窗积分 φ_L，包含于 v 的 b 窗，同理积分≤(b/L)C(d)，未饱和费用 c_jg/L≤γ。**不把这两个窗当成 hard-z 窗，也没有要求它们长度≤m₀。**

由 √(a+b)≤√a+√b，对 m=1,2，四项全部保留为
\[
a_{mi}(1/2)\le(1-s)A_{hh}
 +\sqrt{s(1-s)}(A_{h\phi}+A_{\phi h})+sD_{H_m}.
\tag{GD4}
\]
这不是混合核亲和度的恒等分解；它是四个非负交项构成的上界。

## 3. 全软费用的全位置显式上界

有一个足够保守但无位置限制的界
\[
\boxed{D_{H_m}\le\mathcal R_i:=
\min\{\omega_i^{-1/2},\ 768\sqrt{1+d_i}\},\qquad m=1,2,3.}
\tag{GD5}
\]
第一项是概率密度的 Cauchy–Schwarz。第二项的证明如下，特别不使用错误的多项式 φ 尾。

对 r≥0，直接限制 w 的 t 积分至 [1−1/(2(1+r)),1]，及在上界作 t↦1/t，给
\[
\frac{e^{-r-1/2}}{2(1+r)}\le w(r)
\le\frac{2e^{-r}}{1+r}.
\]
再与 h₁ 卷积，利用 ||r−u|−r|≤1/2，得到
\[
\frac1{9}\frac{e^{-r}}{1+r}\le\phi(r)
\le8\frac{e^{-r}}{1+r}.
\tag{GD6}
\]
下界可先取 e⁻¹/[3(1+r)]，再用 e<3。已审 logφ 的 4-Lipschitz 性给 C(d)≥e⁻²φ(d)>e⁻ᵈ/[81(1+d)]。原 c_jg≤b 保证 ω≥C。

以 b 缩放接收变量，L,H≥b/2 和偶单调性给
\[
\int\sqrt{\phi_L(u-y)\phi_H(u-v)}du
\le16e^{-d/2}\left(\pi+\frac2{\sqrt{1+d}}\right).
\]
其中中间区间 [0,d] 的剩余积分为 ∫₀ᵈ[(1+r)(1+d−r)]⁻¹/²dr≤π，两侧尾各至多 (1+d)⁻¹/²；b/√LH≤2 已计入16。除以 √ω≥e⁻ᵈ/²/[9√(1+d)]，并用 π<10/3，得到 GD5 的768。位置费用允许增长，不能裁剪为1。

第三测试的 hard-anchor 可直接使用 RT13。令 ρ=1−η、η=2⁻³⁴，κ=√ρ。真实 λ=L/b∈[1/2,1]，RT13 给
\[
\left(\int\sqrt{h_L(u-y)\phi_b(u-v)}du\right)^2
\le\rho\int_{d-\lambda/2}^{d+\lambda/2}\phi
\le\rho C(d).
\]
因 C≤ω，得到 A_hφ,b≤κ，**无 γ 费用**，且对饱和与未饱和 ω 同时成立。因此
\[
\boxed{a_{3i}(1/2)\le\sqrt{1-s}\,\kappa+\sqrt s\,\mathcal R_i.}
\tag{GD7}
\]
纯硬锚点仅作为实际混合核的一个交项使用；√s 项没有删除。RT13 的使用不要求把实际 s 置零。

把 GD3–7 代入 GD2，就是全位置、全合法 s 的可核验分层包络：
\[
\begin{split}
U_{mi}&=(1-s)\min\{\gamma\sqrt{\omega_i},
\sqrt\gamma\sqrt{(1-|y_i-v_i|/H_m)_+}\}
+2\sqrt{\gamma s(1-s)}+s\mathcal R_i\quad(m=1,2),\\
U_{3i}&=\sqrt{1-s}\kappa+\sqrt s\mathcal R_i,\\
\boxed{\mathcal B^B_\xi(v,z')&\le
\min\{1,\sqrt{K/3}\sum_{m=1}^3\prod_i\widehat U_{mi}\}.}
\tag{GD8}
\end{split}
\]
这里当 ω_i=1 时可取 \(\widehat U_{mi}=\min(1,U_{mi})\)，否则取 U_mi。理由是饱和时原 a_mi≤1；未饱和时不作此裁剪。GD8 的三项是上界项，不能称作三个真实赢家事件的精确分拆。

## 4. 一个确实给时间价格的有限分支

取 M≥1，定义真实来源几何域
\[
E_M(y)=\{v:\max_{m=1,2,3}n^{-1}\sum_i D_{H_m}(y_i,v_i)\le M\}.
\tag{GD9}
\]
它只使用三个明确的纯软一维交项，不由未知带门接收列反向定义。GD5 给出的 n⁻¹Σ_i R_i≤M 是不必计算 D 的充分条件；ω_i≥M⁻² 对所有 i 又是其充分条件。这里只限坐标均值，允许少数坐标 D_i 很大，不要求来源坐标独立。可按 M=1,2,4,…作不交壳层；各壳的来源质量与价格须真实求和，不能重复免费领取同一个总容量。

本节额外限制实际软度为
\[
1-2^{-1/n}<s\le\frac{\eta^2}{16M^2},\qquad\eta=2^{-34}.
\tag{GD10}
\]
这是原域的一个很小子区间，不是对原剩余软度的通用假设。它非空的准确必要充分维数条件是
\(n>\log2/[-\log(1-\eta^2/(16M^2))]\)。尤其 n=6561 的实际软度不属于此支。

设 ε_mi=2√s+sD_(H_m)(y_i,v_i)、F₀=n(2√s+sM)。由 GD4，对 v∈E_M，m=1,2，
\[
a_{mi}\le\gamma(\sqrt{\omega_i}+\varepsilon_{mi}),\qquad\sum_i\varepsilon_{mi}\le F_0.
\]
若 α_i<t≤g，则 ω_i=α_i/g<t/g。令 u=1−t/g（这里 u 是本节新积分变量，**不等于**原 h=g exp(−u_old/n) 的固定参数）。由 √ω≤1−(1−ω)/2 及 1+x≤eˣ，乘积得
\[
\boxed{\prod_i a_{mi}\le e\exp\{F_0-k_t(v)u/2\},\qquad m=1,2.}
\tag{GD11}
\]
可把非活动饱和坐标的费用改为0，但本节保守计入 F₀。这里没有隐藏 exp(Cn√s)；下一步明确将它转成时间积分费用。

GD10、κ≤1−η/2、GD7 以及对 n 个正数的 AM–GM 给
\[
\prod_i a_{3i}\le\left[\kappa+\sqrt s\,n^{-1}\sum_iD_{H_3}(y_i,v_i)\right]^n\le(1-\eta/4)^n\le e^{-\eta n/4}.
\tag{GD12}
\]
故记 A=2e√(K/3)、B₃=√(K/3)e^(−ηn/4)，有
\[
\mathcal B^B_\xi(v,z')1_{E_M}(v)
\le1_{E_M}(v)\{
\min(1,Ae^{F_0-k_t(v)u/2})+B_3\}.
\tag{GD13}
\]
这是用 min(1,X+Y)≤min(1,X)+Y 作的正上界；A 中的2来自两个整维硬测试，不是坐标代价或实际赢家分支系数。

原时间窗满足 a/c_j≤t≤g，且 a/c_j≥g/2。因此 0≤u≤1/2 且 |dt/t|=du/(1−u)≤2du。令
\[
H_0=1+F_0+\log_+A.
\]
对任意 0≤k≤n（允许 k 随 t,v 变动），有
\[
k\min(1,Ae^{F_0-ku/2})
\le\min\{n,2H_0/u\}\quad(u>0).
\tag{GD14}
\]
证明取 x=ku/2。x≤H₀ 时直接估计；x>H₀≥1 时，x exp(F₀+logA−x)≤x exp(H₀−1−x)≤H₀。于是
\[
\int_0^{1/2}2\min\{n,2H_0/u\}du
\le4H_0\left[1+\log_+\frac n{4H_0}\right].
\tag{GD15}
\]

在 SI1 的每个实际 t，Π_t 是同一个真实概率，δ_t=[k_t(v)−k_t(z′)]_+≤k_t(v)。不要求 Π_t 不随 t 变动，也不要求 ν 有坐标独立性。将 GD13–15 作逐点界再积分，得到固定共同参数块、固定 j、固定 (ω,V,y) 的来源／时间价格
\[
\boxed{
\int_{J_{far}}\frac{dt}{t}\iint
\delta_t(v,z')\mathcal B^B_\xi(v,z')1_{E_M}(v)
\,d\Pi_t(v)d\Pi_t(z')
\le\Theta(n,s,M,K),}
\tag{GD16}
\]
\[
\Theta=4H_0\left[1+\log_+\frac n{4H_0}\right]
+n\log2\,\sqrt{K/3}\,e^{-\eta n/4}.
\]
也可取与旧基线 (n/4)log2 的较小值：每个 t 有 ∫δ dΠ_t²≤n/4，且 \(\mathcal B^B\le1\)。原 J_far 若为空则贡献0；本证明只扩大其时间区间，不宣称其非空。

特别在同时满足 GD10 的 s≤S/n（S 为给定常数）分支，H₀≤1+2√(Sn)+SM+log_+A。因此固定 M,S,K 时，GD16 为 O(√n log(n+2))，加上明示的指数小项。这是一个真实来源时间积分界，**不是**把局部接收概率替代来源积分。n√s 代价仍在 H₀ 中，不能用于一般 s 接近1的中间层；那时只回到旧粗价。

E_M 也不强制 k_t=0：对 M>1、t/g>M⁻²，可存在 M⁻²≤ω_i<t/g 的活动坐标。原 C 连续从1降至0，故这些原阈值位置的区间非空。这只是参数几何相容性，不认证特定 ν 的 live、FIRST、high 或 FULL 非空实例。

## 5. 回原 SI5 的费用与未覆盖量

GD8 是所有位置／所有实际 s 的新包络；GD16 是其中明确限定的来源／时间分支。其原正项费用为 (16/3)Θ，乘回母式外2Λ后是 (32Λ/3)Θ，再对原 dβ_V(y)、EΣ_V 和实际参数块、j 求和。原 β−ν 全部保留。

在每个固定参数块，把 v∈E_M 且 GD10 成立的交通与补集按真实指示分开。补集仍是
\[
\frac{16}{3}\mathbb E\sum_{V,j}\int d\beta_V(y)
\int\frac{dt}{t}\iint\delta_t\,
\mathcal B_\xi(v,z')\,1_{\mathrm{未覆盖}}\,
d\Pi_t(v)d\Pi_t(z').
\tag{GD17}
\]
可在那里用全位置 GD8 或旧固定参数基线1；没有赋予补集新的根阶价格。远来源的全软费用、超出 GD10 的软度、尺度选择与 Σj 都在此列账，不把不同包络的指数因子直接相乘。

实际 x↦(s,L,R,g) 一般不是固定的。GD16 直接适用于原接收域中共同参数固定的部分；若选择器只有有限／可数参数块，必须对这些块的价格真实求和。连续选择器的离散化误差、上下核比较和覆盖数尚未证明，不能将单块定理直接读成整个 SI4 的上界；唯一 j(x) 也不能自动省掉先分块后的 Σj。没有主张这类恒参数块已覆盖实际未付交通的正测部分。

硬 z 已按 SI2 的真实行帽先积分，其历史接受因子仍包含在 c_ξ≤1 中；不再错误引入总质量／尺度比。原 ν³/e_t² 的两份 ν/e_t 精确保留为 Π_t²，第三份硬 ν 由原 q 与 h_R 帽支付；same-source live、high、严格 bad／非严格 good 和 RC 等均只在正上界中放松，未改定义。N_Zc、N_del 留在原母式各一次，本稿未使用负项，也不取回已消费 N_Z。

数值探路已报告某些实际 near-soft 的 m3 远来源 a>1；这与 GD7 的 √s R 费用一致。本文没有把数值当证明，也不把 TV/P 正 margin 在 ω=1、score=0 的例子作为主要成果。所获改动是可检查的 GD8 及有限范围 GD16；全自适应、多 j 的一般根预算仍未证明。
