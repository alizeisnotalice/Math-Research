"""R132 post-run E4 diagnostics only. Never imports or reruns the frozen producer."""
from pathlib import Path
import json
import hashlib
import sys
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
EXPECTED_RESULTS_SHA='fcf6621458c42fb2a655f7c50802efc9510b92afc296ed10be8d8d486e97f01b'
EXPECTED_CODE_SHA='1ba364f86d06e9372f563af5b7490e2510c1de3c38f0fcfe59ed09b02a36124e'
EXPECTED_PROTOCOL_SHA='60d0ea8924dac91ed56549c19ab729f93306ed4608330afee340d3c2d5450d4d'

def main():
    import mpmath as module
    mp=module.mp
    if module.__version__!='1.3.0' or not Path(module.__file__).resolve().is_relative_to(VENDOR):
        raise RuntimeError('expected existing vendor mpmath1.3.0')
    paths={'results':HERE/'affinity_results.json','producer':HERE/'affinity_probe.py','protocol':HERE/'affinity_protocol.md'}
    hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()}
    if hashes!={'results':EXPECTED_RESULTS_SHA,'producer':EXPECTED_CODE_SHA,'protocol':EXPECTED_PROTOCOL_SHA}:
        raise RuntimeError('frozen R132 input hash mismatch')
    old=json.loads(paths['results'].read_text())
    controls=[]; fullsoft=[]
    with mp.workdps(80):
        def number(encoded):
            n,d=encoded['$q'];return mp.mpf(n)/mp.mpf(d)
        def fmt(x):return mp.nstr(x,80)
        for case in old['cases']:
            o=case['observations'][1];core=mp.mpf(o['core_affinity'])
            if case['id'] in (1,4,9):
                if not o['exact_same_kernel_normalization_control']:raise RuntimeError('missing exact same-kernel control')
                n=case['input']['n']
                s=mp.mpf(1) if case['input']['softness']=='one' else 1-mp.power(2,-mp.mpf(1)/n)+mp.power(2,-24)
                L=number(case['input']['L']);T=number(o['T']);r=T/L
                # No quadrature: E4 primitive of the original E3 difference.
                tail=2*s*(mp.expint(4,r-mp.mpf(1)/2)-mp.expint(4,r+mp.mpf(1)/2))
                exactcore=1-tail
                controls.append(dict(id=case['id'],T_over_L=fmt(r),s=fmt(s),
                    exact_expression='1-2*s*[E4(T/L-1/2)-E4(T/L+1/2)]',
                    tail_expression='2*s*[E4(T/L-1/2)-E4(T/L+1/2)]',
                    tail_numeric=fmt(tail),analytic_core_numeric=fmt(exactcore),
                    old_core=fmt(core),old_core_minus_analytic_core=fmt(core-exactcore),
                    old_core_quad_error_estimate=o['core_quad_error_estimate'],
                    old_precision_difference=case['precision_comparison']['absolute_difference'],
                    interpret='old LOSS is quadrature error; all-line same-kernel affinity is exactly one; E4 numeric is noninterval'))
            if case['input']['softness']=='one':
                fullsoft.append(dict(id=case['id'],D_core=o['core_affinity'],
                    D_definition='integral_R sqrt(phi_L(u-y)*phi_H(u-v))/sqrt(omega(v)) du',
                    reused_frozen_s1=True,quad_error_estimate=o['core_quad_error_estimate'],
                    truncation_tail_upper_numeric=o['tail']['total_upper_numeric'],
                    precision_difference=case['precision_comparison']['absolute_difference'],
                    interpret='same s=1 frozen integral; D_core is finite-cutoff observation, not certified full-line D'))
    result=dict(header=dict(version='R132-E4-diagnostic-v1',digits=80,hashes=hashes,
                diagnostic_code_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                python=sys.executable,mpmath_version=module.__version__,mpmath_path=module.__file__,
                new_quad_requests=0,new_kernel_cases=0,interval_certificate=False),
                same_kernel_controls=controls,fullsoft_D_from_frozen_results=fullsoft,
                time_price_status='NOT_COMPUTED_WAITING_FOR_FROZEN_AUTHOR_CONSTANTS')
    target=HERE/'diagnostic_check.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status='SAVED',path=str(target),sha=hashlib.sha256(target.read_bytes()).hexdigest(),new_quad_requests=0)))

if __name__=='__main__': main()
