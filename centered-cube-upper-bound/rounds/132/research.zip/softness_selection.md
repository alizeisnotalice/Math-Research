# R132：低软度选择器的正包络费用

主代理推导；独审状态另见附件。本稿保持实际尺度L,R,g共同固定，允许软度s=s(x)为任意可测选择器。它不覆盖尺度选择器，不把固定参数结果当一般闭合。

令0<S<1，实际0<s(x)≤S且保原strict下门。记r=(1-S)^(-1)，p_s=P_s,L，Q_s=(P_s,L+P_s,Lplus+P_1,b)/3，ω及wg仍为实际固定g的权重。逐坐标
\[
q_{s,H}\le r q_{S,H},
\]
因为1-s≤1=r(1-S)，且s≤S≤rS。三整维测试中全软项不变，也被r^n支配，故
\[
p_s\le r^n p_S,\qquad Q_s\le r^n Q_S.
\tag{SS1}
\]
对原good门p_s w_g(v)≤KQ_s(v)，逐接收点有
\[
p_s1_{good(s)}\le\min\{p_s,\sqrt{Kp_sQ_s/w_g(v)}\}
\le r^n\min\{p_S,\sqrt{Kp_SQ_S/w_g(v)}\}.
\tag{SS2}
\]
右侧的min不是新good(S)事件的指示函数。取真实dx积分，并用积分min≤两积分的min，固定S的GD Chernoff三项包络依然适用，另付r^n。丢bad/RC/history仅在正上界中进行，原负项不动；Π_t不依x、外硬帽合法等条件与GD原命题相同。

令D_mi、E_M为GD的全软余项及max_m坐标均值≤M的来源类。它们只依真实φ、H_m、L及ω，不依s，故在s(x)变化下同一个E_M仍合法。假定固定S满足GD的S≤2^-72/M²及实际strict可行性，固定j的E_M部分来源／时间价至多
\[
\frac{16}{3}(1-S)^{-n}\,\Theta(n,S,M,K),
\tag{SS3}
\]
尚需恢复β、V等外层。Θ取GD16原完整三测试时间价，不省略第三测试或其指数尾。本式使用固定S概率核作正包络，不能因此新增一份FIRST容量或把实际比较门改判成good(S)。

若nS=C且C≤n/2，则
\[
(1-S)^{-n}\le e^{C/(1-C/n)}\le e^{2C}.
\tag{SS4}
\]
这是软度适应性费用，不能无条件称常数。取C=O(loglog n)、M=(log n)^O(1)、log_+K=O(log n)，在GD低S条件最终满足的大维范围内，Θ的硬测试项为O((√(nC)+CM+log_+K+1)log n)，乘e^(2C)仍为√n乘对数幂；第三测试n√(K/3)exp(-n2^-36)log2也完整保留。这里只是给定质量类及共同尺度上的条件时间价格；低软度之外、E_M补集和全部j/尺度覆盖没有被证明可付。

因此不必在这个明确低软度窗口额外机械支付全区间arcsine D_n，但不能拿SS4免除实际L(x),R(x),g(x)的变化成本。N_Z已消费不返还，N_Zc与Ndel各一次保留。
