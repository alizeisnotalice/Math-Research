from fractions import Fraction as F
from pathlib import Path
import json, hashlib

def mix(a,b,k): return a+(b-a)*k
rows=[]
for stage,n in enumerate((6561,16384,65536),1):
 gamma=F(n+1,n); eta=F(100*n+1,100*n); a=F(1); b=F(2)
 for j,kg,km,kt in [(0,F(0),F(0),F(0)),(1,F(1,2),F(1),F(1,2)),(8,F(1),F(0),F(1)),(2,F(1,3),F(1,2),F(2,3))]:
  c=gamma**(-j); g=mix(eta*a/c,b*c,kg)
  mlo=max(a,g*g/b,c*g/gamma); mhi=c*g
  assert mlo<=mhi
  m=mix(mlo,mhi,km); t=mix(a/c,g/eta,kt); G=t*eta
  low=max(a,G*G/b,c*G/gamma); up=b*c*c
  pluslow=G/c
  checks={"fixed_g_width":mhi/mlo<=gamma,"minus_width_square":up/low<=(b*c/G)**2,"minus_width_gamma":up/low<=gamma*b*c/G,"plus_width":b/pluslow==b*c/G}
  for orient in (0,1):
   L,R=(m,g*g/m) if orient==0 else (g*g/m,m)
   local={"scale":a<=L<=b and a<=R<=b,"product":L*R==g*g,"band":c*g/gamma<=min(L,R)<=c*g,"far":a/c<=t<=g/eta,"correct_branch":(low<=L<=up) if orient==0 else (pluslow<=L<=b)}
   local.update(checks)
   rows.append(dict(stage=stage,n=n,j=j,orientation=orient,g=str(g),t=str(t),L=str(L),R=str(R),checks=local))
assert len(rows)==24 and all(all(x["checks"].values()) for x in rows)
result=dict(scope="FINITE_EXACT_WINDOW_ALGEBRA_NOT_FULL_TRAFFIC",arithmetic="Fraction",stages=[8,8,8],cases=24,passed=24,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),rows=rows)
p=Path(__file__).with_name("window_exact_results.json");p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(dict(cases=24,passed=24,sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
