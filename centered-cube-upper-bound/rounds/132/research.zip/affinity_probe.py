"""R132: 12 frozen full-line affinity kernel cases, 30/50 digit observations only.

Uses existing mpmath vendor through PYTHONPATH. No computation at import.
No interval certificate, FIRST/FULL realization, or source-budget conclusion.
"""
from argparse import ArgumentParser
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import sys
import time

N = 6561
DIGITS = (30, 50)
MAXDEGREE = 6
MAX_EVALS = 20000
VENDOR = '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor'
HERE = Path(__file__).resolve().parent
NOTE = HERE / 'affinity_protocol.md'
EXPECTED_NOTE_SHA = '60d0ea8924dac91ed56549c19ab729f93306ed4608330afee340d3c2d5450d4d' # pre-execution frozen protocol


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def rational(x):
    return {'$q': [str(x.numerator), str(x.denominator)]}


def encode_input(x):
    if isinstance(x, Q): return rational(x)
    if isinstance(x, dict): return {str(k): encode_input(v) for k,v in x.items()}
    if isinstance(x, (list,tuple)): return [encode_input(v) for v in x]
    return x


def group(name):
    gamma = 1 + Q(1,N)
    if name == 'A':
        return dict(group=name,n=N,j=0,gamma=gamma,cj=Q(1),g=Q(1),
                    a=Q(1,2),b=Q(1),L=Q(1),R=Q(1),y=Q(0))
    cj = 1/gamma
    L = (cj+cj/gamma)/2
    R = 1/L
    return dict(group=name,n=N,j=1,gamma=gamma,cj=cj,g=Q(1),
                a=R/2,b=R,L=L,R=R,y=Q(0))


def menu(stage):
    A,B=group('A'),group('B')
    rows={1:[(1,A,Q(0),1,'near'),(2,A,Q(1,4096),2,'near'),(3,A,Q(1,2),1,'near'),(4,A,Q(0),3,'one')],
          2:[(5,A,Q(2),1,'near'),(6,A,Q(8),2,'one'),(7,A,Q(32),3,'near'),(8,A,Q(1,2),3,'one')],
          3:[(9,B,Q(0),1,'near'),(10,B,Q(1,4096),2,'one'),(11,B,Q(8),3,'near'),(12,B,Q(32),2,'one')]}[stage]
    return [dict(**p,id=i,stage=stage,d=d,v=d*p['b'],m=m,softness=s,theta=Q(1,2)) for i,p,d,m,s in rows]


def legality(case):
    a,b,L,R,g,cj,gamma=(case[k] for k in ('a','b','L','R','g','cj','gamma'))
    return dict(physical_scale_window=(0<a<=L<=b and a<=R<=b and b<=2*a),
                exact_g_relation=L*R==g*g,ratio_band=cj/gamma*g<=min(L,R)<=cj*g,
                original_g_window=a/cj<=g<=b*cj,cj_definition=cj==gamma**(-case['j']),
                dimension_at_least_6561=case['n']>=6561,
                softness_structural=case['softness'] in ('one','near'),theta_half=case['theta']==Q(1,2))


class BudgetError(RuntimeError):
    pass


class Probe:
    def __init__(self,mp):
        self.mp=mp
        self.evaluations=0
        self.phi_calls=0
        self.phi_cache={}
        self.C_cache={}

    def number(self,q):
        if isinstance(q,Q): return self.mp.mpf(q.numerator)/q.denominator
        return self.mp.mpf(q)

    def string(self,x):
        return self.mp.nstr(x,n=self.mp.dps)

    def phi(self,x):
        self.phi_calls+=1
        r=abs(x)
        if r in self.phi_cache: return self.phi_cache[r]
        half=self.mp.mpf(1)/2
        def E3(a):
            return half if a==0 else self.mp.expint(3,a)
        value=(1-E3(half-r)-E3(half+r) if r<=half else E3(r-half)-E3(r+half))
        if not self.mp.isfinite(value) or value<=0:
            raise ArithmeticError('nonpositive/nonfinite floating original phi')
        self.phi_cache[r]=value
        return value

    def integrate(self,func,lo,hi,cuts):
        if hi<=lo:
            return self.mp.mpf(0),self.mp.mpf(0),[]
        points=sorted({lo,hi,*(c for c in cuts if lo<c<hi)})
        total,error=self.mp.mpf(0),self.mp.mpf(0)
        pieces=[]
        def wrapped(x):
            self.evaluations+=1
            if self.evaluations>MAX_EVALS:
                raise BudgetError('per-case/per-precision integrand request budget exceeded')
            return func(x)
        for left,right in zip(points,points[1:]):
            value,estimate=self.mp.quad(wrapped,[left,right],method='gauss-legendre',
                                        maxdegree=MAXDEGREE,error=True)
            total+=value
            error+=abs(estimate)
            pieces.append(dict(lo=self.string(left),hi=self.string(right),
                               value=self.string(value),quad_error_estimate=self.string(estimate)))
        return total,error,pieces

    def C(self,d):
        if d in self.C_cache: return self.C_cache[d]
        half=self.mp.mpf(1)/2
        def F(u):
            r=abs(u-d)
            return self.mp.mpf(1) if r<=half else self.phi(r)
        result=self.integrate(F,-half,half,[d-half,d,d+half])
        self.C_cache[d]=result
        if result[0]<=0 or not self.mp.isfinite(result[0]):
            raise ArithmeticError('nonpositive/nonfinite floating original C')
        return result


def observe(mp,case,digits):
    start=time.monotonic()
    with mp.workdps(digits):
        probe=Probe(mp)
        L,R,b,g,cj,y,v=(probe.number(case[k]) for k in ('L','R','b','g','cj','y','v'))
        theta=probe.number(case['theta'])
        lower=1-mp.power(2,-mp.mpf(1)/case['n'])
        s=mp.mpf(1) if case['softness']=='one' else lower+mp.power(2,-24)
        Hq=case['L'] if case['m']==1 else (min(case['b'],case['gamma']*case['L']) if case['m']==2 else case['b'])
        H=probe.number(Hq); sm=mp.mpf(1) if case['m']==3 else s
        Tq=max(abs(case['y']),abs(case['v']))+80*max(case['L'],Hq,case['b'],case['R'])
        T=probe.number(Tq)
        legal=legality(case)
        legal.update(Hm_in_physical_window=case['a']<=Hq<=case['b'],strict_softness_observed=bool(lower<s<=1),
                     truncation_beyond_both_hard_intervals=(Tq>abs(case['y'])+case['L']/2 and Tq>abs(case['v'])+Hq/2))
        out=dict(input=encode_input(case),digits=digits,legality=legal,s_lower=probe.string(lower),
                 s_actual=probe.string(s),s_margin=probe.string(s-lower),kernel_s=probe.string(sm),
                 Hm=rational(Hq),T=rational(Tq),theta=probe.string(theta),status='EXPLORATORY_MPMATH_NOT_INTERVAL')
        if not all(legal.values()):
            out.update(status='PARAMETER_LEGALITY_UNDETERMINED')
            return out
        try:
            cv,cv_error,cv_pieces=probe.C(abs(y-v)/b)
            raw=b*cv/(cj*g); omega=min(mp.mpf(1),raw); norm=mp.power(omega,theta)
            out.update(C_v=probe.string(cv),C_quad_error_estimate=probe.string(cv_error),C_pieces=cv_pieces,
                       raw_weight_v=probe.string(raw),omega_v=probe.string(omega),
                       g_coordinate_score_observed=1 if omega<1 else 0,
                       score_scope='one coordinate at g only; earlier t may be smaller; floating branch observation')
            def kernel(u,center,width,soft):
                r=abs((u-center)/width)
                hard=mp.mpf(1) if r<=mp.mpf(1)/2 else mp.mpf(0)
                return ((1-soft)*hard+soft*probe.phi(r))/width
            def f(u):
                return mp.power(kernel(u,y,L,s),1-theta)*mp.power(kernel(u,v,H,sm),theta)
            cuts=[y-L/2,y,y+L/2,v-H/2,v,v+H/2]
            core,error,pieces=probe.integrate(f,-T,T,cuts)
            affinity=core/norm
            inside=mp.mpf(0); outside=mp.mpf(0)
            for piece in pieces:
                midpoint=(mp.mpf(piece['lo'])+mp.mpf(piece['hi']))/2
                both=abs(midpoint-y)<L/2 and abs(midpoint-v)<H/2
                piece['inside_both_geometric_hard_intervals']=bool(both)
                piece['normalized_value']=probe.string(mp.mpf(piece['value'])/norm)
                if both: inside+=mp.mpf(piece['value'])/norm
                else: outside+=mp.mpf(piece['value'])/norm
            A0=2*mp.sinh(mp.mpf(1)/2)
            rate=(1-theta)/L+theta/H; shift=(1-theta)*y/L+theta*v/H
            pref=mp.power(s*A0/L,1-theta)*mp.power(sm*A0/H,theta)/norm
            right=pref*mp.exp(-rate*T+shift)/rate
            left=pref*mp.exp(-rate*T-shift)/rate
            tail=left+right
            penalty=mp.log(1/omega)
            tau=(min(abs(y-v)/L,mp.mpf(1))+min(abs(y-v)/H,mp.mpf(1)))/8
            margin=tau*tau-penalty; tv_bound=mp.exp(-margin/2)
            exact_control=(case['v']==case['y'] and Hq==case['L'] and sm==s and omega==1)
            out.update(core_affinity=probe.string(affinity),core_quad_error_estimate=probe.string(error/norm),
                       core_pieces=pieces,observed_relation_to_one=('GAIN' if affinity>1 else 'LOSS' if affinity<1 else 'EQUAL'),
                       exact_same_kernel_normalization_control=bool(exact_control),control_identity='a=1' if exact_control else None,
                       formal_core_plus_tail_bound=probe.string(affinity+tail),
                       tail=dict(right_upper_numeric=probe.string(right),left_upper_numeric=probe.string(left),
                           total_upper_numeric=probe.string(tail),rate=probe.string(rate),shift=probe.string(shift),
                           prefactor=probe.string(pref),formula='P exp(-rate*T +/- shift)/rate; approximate evaluation of analytic tail bound',
                           outward_interval=False),
                       soft_tail_fees=dict(core_inside_both_geometric_intervals=probe.string(inside),
                           core_outside_intersection=probe.string(outside),outside_plus_analytic_tail=probe.string(outside+tail),
                           meaning='geometric partition; kernel sm=1 has no hard mass; no certified core error'),
                       TV_candidate=dict(log_inverse_omega=probe.string(penalty),tau=probe.string(tau),tau_squared=probe.string(tau*tau),
                           margin=probe.string(margin),bound_numeric=probe.string(tv_bound),core_to_bound_ratio=probe.string(affinity/tv_bound),
                           observed_core_le_candidate=bool(affinity<=tv_bound),theorem_certificate=False))
        except Exception as error:
            out.update(status='EXCEPTION_PRESERVED',error_type=type(error).__name__,error=str(error))
        out.update(integrand_requests=probe.evaluations,phi_calls=probe.phi_calls,
                   elapsed_seconds=f'{time.monotonic()-start:.3f}',interval_certificate=False,FIRST_FULL_or_source_root_claim=False)
        return out


def compare(mp,observations):
    with mp.workdps(50):
        if all('core_affinity' in o for o in observations):
            values=[mp.mpf(o['core_affinity']) for o in observations]
            delta=values[1]-values[0]
            return dict(core_50_minus_30=mp.nstr(delta,50),absolute_difference=mp.nstr(abs(delta),50),
                        status='UNDETERMINED_PRECISION_DISAGREEMENT' if abs(delta)>mp.mpf('1e-8')*(1+abs(values[1])) else 'STABLE_FLOAT_OBSERVATION',
                        interpretation='not interval error; same quadrature cap at both precisions')
        return dict(status='UNDETERMINED_MISSING_OBSERVATION',absolute_difference=None)


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--stage',required=True,choices=('1','2','3','all'))
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        import mpmath as module
        if module.__version__!='1.3.0' or not Path(module.__file__).resolve().is_relative_to(Path(VENDOR)):
            raise RuntimeError('expected existing mpmath 1.3.0 vendor')
        note_bytes=NOTE.read_bytes()
        if sha_bytes(note_bytes)!=EXPECTED_NOTE_SHA: raise RuntimeError('pre-execution frozen protocol SHA mismatch')
    except Exception as error:
        print(json.dumps(dict(status='ENVIRONMENT_ERROR',error=str(error))))
        return 2
    stages=(1,2,3) if args.stage=='all' else (int(args.stage),)
    cases=[c for stage in stages for c in menu(stage)]
    result=dict(header=dict(version='R132-affinity-v1',case_count=len(cases),digits=DIGITS,maxdegree=MAXDEGREE,
                max_integrand_requests_per_case_precision=MAX_EVALS,python=sys.executable,python_version=sys.version,
                mpmath_version=module.__version__,mpmath_path=module.__file__,
                code_sha=sha_bytes(Path(__file__).read_bytes()),frozen_protocol_sha=sha_bytes(note_bytes),
                frozen_protocol_text=note_bytes.decode('utf-8'),interval_certificate=False,FIRST_FULL_or_source_root_claim=False),cases=[])
    failures=0; disagreements=0
    for case in cases:
        observations=[]
        for digits in DIGITS:
            try: observation=observe(module.mp,case,digits)
            except Exception as error:
                observation=dict(input=encode_input(case),digits=digits,status='EXCEPTION_PRESERVED',error_type=type(error).__name__,error=str(error))
            if observation['status']!='EXPLORATORY_MPMATH_NOT_INTERVAL': failures+=1
            observations.append(observation)
        comparison=compare(module.mp,observations)
        if comparison['status']!='STABLE_FLOAT_OBSERVATION': disagreements+=1
        result['cases'].append(dict(id=case['id'],stage=case['stage'],input=encode_input(case),observations=observations,precision_comparison=comparison))
        print(json.dumps(dict(case=case['id'],statuses=[o['status'] for o in observations],comparison=comparison['status'])),flush=True)
    result['summary']=dict(case_count=len(cases),observation_count=2*len(cases),failed_or_undetermined_observations=failures,
                         precision_undetermined_cases=disagreements,stages=stages,no_menu_expansion=True,no_bound_clipping=True,
                         only_original_specified_m=True,interval_certificate=False,FIRST_FULL_or_source_root_claim=False)
    serialized=json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)
    if args.output:
        args.output.write_text(serialized+'\n',encoding='utf-8')
        print(json.dumps(dict(status='SAVED',output=str(args.output.resolve()),**result['summary'])))
    else: print(serialized)
    return 1 if failures else 0


if __name__=='__main__': sys.exit(main())
