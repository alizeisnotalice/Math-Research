# R132 affinity：执行前冻结协议

本协议冻结 12 例、3 阶段各 4 例；仅作真实核浮点观察，不授予区间认证、FIRST/FULL、来源或 root 结论。目标允许大于 1；不得裁剪真实积分，也不因结果调整菜单。

对象为 θ=1/2，a_m=∫R q_s,L(u−y)^(1−θ)q_sm,Hm(u−v)^θ du / ω(v)^θ，q_s,H=((1−s)h1+sφ)(·/H)/H，sm=s（m1/2）、sm=1（m3）；H1=L，H2=min(b,γL)，H3=b。φ 用原 E3 差分分支：r≤1/2 时 1−E3(1/2−r)−E3(1/2+r)，外为 E3(r−1/2)−E3(r+1/2)。C(d)=∫[-1/2,1/2]max(h1,φ)(u−d)du，独立分片 quad 切硬面；ω=min(1,bC(|y−v|/b)/(cjg))。

n=6561，γ=1+1/n，y=0，snear=1−2^(−1/n)+2^(−24)，sone=1。A: j=0,cj=g=L=R=b=1,a=1/2。B: j=1,cj=γ^-1,g=1,L=(cj+cj/γ)/2,R=b=1/L,a=b/2。两组保留精确有理尺度检查 LR=g²、cjg/γ≤min(L,R)≤cjg、a≤L,R≤b≤2a、a/cj≤g≤bcj；s 严格原下门及 Hm 尺度检查独立记录。v=d b。

|阶段|ID|组|d|m|s|
|---|---:|---|---|---:|---|
|初探|1|A|0|1|near|
|初探|2|A|1/4096|2|near|
|初探|3|A|1/2|1|near|
|初探|4|A|0|3|one|
|压力|5|A|2|1|near|
|压力|6|A|8|2|one|
|压力|7|A|32|3|near|
|压力|8|A|1/2|3|one|
|扩大|9|B|0|1|near|
|扩大|10|B|1/4096|2|one|
|扩大|11|B|8|3|near|
|扩大|12|B|32|2|one|

固定 T=max(|y|,|v|)+80max(L,Hm,b,R)，只算 [-T,T] 核心，切 y,v 及各自 ±半尺度。mpmath 1.3.0 既有 vendor，30/50 digits，Gauss–Legendre maxdegree=6；每例每精度共计 C 与核心 integrand 请求 ≤20000。超预算/异常保留原输入和已得字段，不扩大精度、T 或菜单。总 24 次观察，单一进程；协议与源码 SHA 在运行前冻结，运行时核对协议并保存完整文本。

截断尾独立使用 A0=2sinh(1/2)、q_s,H(u−c)≤s A0/H exp(−|u−c|/H)，仅在两硬区间外。令 λ=(1−θ)/L+θ/Hm，η=(1−θ)y/L+θv/Hm，P=(sA0/L)^(1−θ)(smA0/Hm)^θ/ω^θ。左右尾上界分别 P exp(−λT±η)/λ；记录此解析公式的浮点值、左右分量及总和，不能称 outward interval。核心 quad 值不是严格下界；core+tail 也不是已认证全线数值上界。核心各分片按两几何硬区间交集分组，记录 outside-intersection 核费用及另加解析尾费用，用于辨认 soft-tail 代价；sm=1 时几何区间不代表核含硬质量。

分别记录核心 quad 估计、C 的 quad 估计、30/50 位差异；三者均非严格误差证书。若核心亲和差异超过 1e−8(1+|a50|)，标 UNDETERMINED_PRECISION_DISAGREEMENT；其他仅稳定浮点观察。原始 relation-to-one 如实列 gain/loss/equal，归一化同核控制例另标解析 a=1，但不填造或裁剪数值。

同菜单观察作者候选 τ=[min(|y−v|/L,1)+min(|y−v|/Hm,1)]/8，penalty=log(1/ω)，margin=τ²−penalty，TV 候选 exp((penalty−τ²)/2) 与 a_core 比值，不把候选上界当数值裁剪器或认证。ω<1 对应一坐标 g 截点 kt(v)=1，ω=1 对应 0；浮点判支只作观察，原 t 可能更小。margin 不强求正。本实验无 bad 位置、共同三整维核求和、外层来源、history 或交通付款结论。
