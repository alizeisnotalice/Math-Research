"""Replay the single frozen preflight with minimal input and full math equality."""
from pathlib import Path
import json,subprocess,tempfile,sys,os,time,hashlib,platform
ROOT=Path(__file__).resolve().parent
IGNORE={'runtime_seconds','peak_rss_bytes','interpreter','python_version','sympy_version','command'}
def project(v):
 if isinstance(v,dict):return {k:project(x) for k,x in v.items() if k not in IGNORE}
 if isinstance(v,list):return [project(x) for x in v]
 return v
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
start=time.perf_counter();manifest=json.loads((ROOT/'input_manifest.json').read_text())
assert sha(ROOT/'preflight_input.json')==manifest['minimal_input_sha256']
mini=json.loads((ROOT/'preflight_input.json').read_text());expected=json.loads((ROOT/'expected_math.json').read_text())
frozen=set(mini['rows'][0]['residual_witness_masks']);assert len(frozen)==10
with tempfile.TemporaryDirectory(prefix='r576-preflight-repro-') as td:
 output=Path(td)/'preflight.json'
 command=[sys.executable,str(ROOT/'ccu_r576_preflight.py'),'--input',str(ROOT/'preflight_input.json'),'--output',str(output)]
 process=subprocess.run(command,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),capture_output=True,text=True,timeout=60)
 assert process.returncode==0,process.stderr
 result=json.loads(output.read_text())
 assert project(result)==expected,'Mathematical/certificate field changed'
 # Derived from freshly reconstructed cells, not from the input reference list.
 derived=set().union(*(set(c['witness_masks']) for c in result['refined_cells']))
 quantile_refs={c['T'] for c in result['columns'] if c['kind']=='quantile'}
 assert derived==frozen==quantile_refs
 receipt={'status':'PASS_PORTABLE_SINGLE_MODEL_FULL_CERTIFICATE_REPLAY','script_sha256':sha(ROOT/'ccu_r576_preflight.py'),'input_manifest':manifest,'actual_input_sha256':result['input_sha256'],'mathematical_projection_sha256':hashlib.sha256(canonical(project(result))).hexdigest(),'all_mathematical_and_geometry_fields_equal':True,'ignored_fields':sorted(IGNORE),'input_hash_comparison':'Reference uses minimal input hash; original full R574 hash retained in manifest, neither is ignored.','derived_fresh_residual_witness_union':sorted(derived),'frozen_reference_masks':sorted(frozen),'derived_witness_union_equals_frozen_ten_references':True,'quantile_columns_equal_same_references':True,'certificate_type':'Exact radical/Fraction receiver arrangement and rational root-isolated decisions; no float or LP. Input extraction is not an independent geometry audit.','original_script_sha256':sha(ROOT/'ccu_r576_preflight.py'),'returncode':process.returncode,'stderr':process.stderr.strip(),'interpreter':sys.executable,'python_version':platform.python_version(),'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+sys.executable+' '+str(ROOT/'reproduce.py'),'replayed_runtime_seconds':result['runtime_seconds'],'replayed_peak_rss_bytes':result['peak_rss_bytes'],'total_elapsed_seconds':time.perf_counter()-start}
(ROOT/'reproduction_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'all_math_equal':True,'derived_witness_union':sorted(derived),'frozen_ten_refs_equal':True,'minimal_input_bytes':manifest['minimal_input_bytes'],'elapsed_seconds':receipt['total_elapsed_seconds']},indent=2))
