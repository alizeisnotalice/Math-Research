"""Frozen six-source 46-column exact receiver-incidence preflight; no LP."""
from fractions import Fraction as F
from math import isqrt,gcd
from functools import cmp_to_key
from pathlib import Path
import json,sys,platform,time,resource,signal,argparse,shlex,hashlib
import sympy as S
parser=argparse.ArgumentParser()
parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'ccu_r574_numeric.json')
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'preflight.json')
args=parser.parse_args();START=time.perf_counter();PREC=192;DEN=2**PREC;ROOT={};DECISIONS=0
def rootbounds(d):
    if d not in ROOT:
        v = isqrt(d * DEN * DEN)
        ROOT[d] = (F(v, DEN), F(v, DEN) if v * v == d * DEN * DEN else F(v + 1, DEN))
    return ROOT[d]

def clean(v):
    return {d: c for d, c in v.items() if c}

def add(a, b):
    z = a.copy()
    for d, c in b.items():
        z[d] = z.get(d, F(0)) + c
    return clean(z)

def neg(a):
    return {d: -c for d, c in a.items()}

def sub(a, b):
    return add(a, neg(b))

def mul(a, b):
    z = {}
    for d, c in a.items():
        for e, f in b.items():
            g = gcd(d, e)
            q = d * e // (g * g)
            z[q] = z.get(q, F(0)) + c * f * g
    return clean(z)

def rat(x):
    return clean({1: F(x)})

def sqrtr(k, c=F(1)):
    q = 1
    d = k
    p = 2
    while p * p <= d:
        while d % (p * p) == 0:
            q *= p
            d //= p * p
        p += 1
    return rat(c * q) if d == 1 else clean({d: c * q})

def bounds(v):
    lo = F(0)
    hi = F(0)
    for d, c in v.items():
        a, b = rootbounds(d)
        lo += c * (a if c >= 0 else b)
        hi += c * (b if c >= 0 else a)
    return (lo, hi)

def sign(v):
    global DECISIONS
    if not v:
        return 0
    lo, hi = bounds(v)
    DECISIONS += 1
    if lo > 0:
        return 1
    if hi < 0:
        return -1
    raise AssertionError('Unresolved exact algebraic sign: ' + str(v))

def key(v):
    return tuple(sorted(v.items()))

def unkey(v):
    return dict(v)

def expr(v):
    return str(sum((S.Rational(c.numerator, c.denominator) * S.sqrt(d) for d, c in sorted(v.items()))))

def exactout(v):
    lo, hi = bounds(v)
    return {'radical_coefficients': {str(d): str(c) for d, c in sorted(v.items())}, 'expression': expr(v), 'isolating_interval': [str(lo), str(hi)], 'display': str(S.N(sum((S.Rational(c.numerator, c.denominator) * S.sqrt(d) for d, c in v.items())), 20))}
def timeout(sig,frame):raise TimeoutError('frozen 60-second cap')
signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
raw=args.input.read_bytes();old=json.loads(raw)
case=next(r for r in old['rows'] if r['model']=='n2_six_grid' and r['A']==2)
z=[list(map(F,p)) for p in case['unit_source_positions']];N=6
assert len(z)==N
subs=[]
def makebox(ids,m):
 r=sqrtr(m,F(1,2))
 lo=[max(z[i][j] for i in ids) for j in range(2)]
 hi=[min(z[i][j] for i in ids) for j in range(2)]
 box=[(sub(rat(lo[j]),r),add(rat(hi[j]),r)) for j in range(2)]
 return box if all(sign(sub(b,a))>0 for a,b in box) else None
for mask in range(1,1<<N):
 ids=[i for i in range(N) if mask>>i&1];subs.append({'mask':mask,'m':len(ids),'ids':ids,'box':makebox(ids,len(ids))})
refs=case['residual_witness_masks'];assert len(refs)==10
columns=[]
for mask in refs:
 q=subs[mask-1];m=q['m'];budget=F(m,8);K=[];R=[]
 for j in range(2):
  coord=sorted(set(z[i][j] for i in q['ids']));cum=0
  for v in coord:
   cum+=sum(z[i][j]==v for i in q['ids'])
   if cum>budget:lo=v;break
  cum=0
  for v in reversed(coord):
   cum+=sum(z[i][j]==v for i in q['ids'])
   if cum>budget:hi=v;break
  R.append((lo,hi))
 K=[i for i in q['ids'] if all(lo<=z[i][j]<=hi for j,(lo,hi) in enumerate(R))]
 assert K==q['ids'] and budget<1
 box=makebox(K,m);assert box==q['box']
 fee=rat(1)
 for a,b in box:fee=mul(fee,sub(b,a))
 columns.append({'kind':'quantile','T':mask,'mass':m,'K':sum(1<<i for i in K),'epsilon':'1/8','box':box,'fee':fee})
for i in range(N):
 for cap in range(1,7):
  half=sqrtr(cap,F(1,2));box=[(sub(rat(x),half),add(rat(x),half)) for x in z[i]]
  columns.append({'kind':'star','anchor':i,'cap':cap,'box':box,'fee':rat(cap)})
assert len(columns)==46
hboxes=[columns[10+i*6+1]['box'] for i in range(N)]
coords=[]
for j in range(2):
 vals={key(e) for q in subs if q['box'] for e in q['box'][j]}
 vals.update(key(e) for c in columns for e in c['box'][j])
 coords.append(sorted(vals,key=cmp_to_key(lambda a,b:sign(sub(unkey(a),unkey(b))))))
index=[{v:i for i,v in enumerate(cs)} for cs in coords]
def ibox(box):return [tuple(index[j][key(e)] for e in box[j]) for j in range(2)]
cb=[(q,ibox(q['box'])) for q in subs if q['box']];colboxes=[ibox(c['box']) for c in columns];hb=[ibox(b) for b in hboxes]
def inside(js,b):return all(lo<=v<hi for v,(lo,hi) in zip(js,b))
actual=[set() for c in columns];sufficient=[set() for c in columns];cells=[];resvol={}
for ix in range(len(coords[0])-1):
 for iy in range(len(coords[1])-1):
  js=[ix,iy];witness=[q for q,b in cb if inside(js,b)]
  if not witness or any(inside(js,b) for b in hb):continue
  area=mul(sub(unkey(coords[0][ix+1]),unkey(coords[0][ix])),sub(unkey(coords[1][iy+1]),unkey(coords[1][iy])))
  assert sign(area)>0
  ci=len(cells);ac=[];sc=[]
  for j,(c,b) in enumerate(zip(columns,colboxes)):
   a=inside(js,b)
   if c['kind']=='quantile':
    s=any(q['m']<=c['mass'] and F((c['T']&~q['mask']).bit_count())<=F(c['mass'],8) for q in witness)
   else:s=any(q['mask']>>c['anchor']&1 and q['m']<=c['cap'] for q in witness)
   assert not s or a
   if a:actual[j].add(ci);ac.append(j)
   if s:sufficient[j].add(ci);sc.append(j)
  resvol=add(resvol,area)
  cells.append({'cell_indices':js,'witness_masks':[q['mask'] for q in witness],'exact_area_coefficients':{str(d):str(v) for d,v in area.items()},'actual_columns':ac,'source_sufficient_columns':sc})
assert resvol=={int(d):F(c) for d,c in case['exact_volume_E_minus_H_A']['radical_coefficients'].items()}
assert all(actual[j]==sufficient[j] for j in range(10))
baseline=[j for j,c in enumerate(columns) if c['kind']=='quantile' and c['T'] in [15,60]]
assert len(baseline)==2
allcells=set(range(len(cells)))
assert set.union(*(sufficient[j] for j in baseline))==allcells
basefee={}
for j in baseline:basefee=add(basefee,columns[j]['fee'])
assert basefee==rat(F(1,2))
certcols=[]
for j,c in enumerate(columns):
 extra=actual[j]-sufficient[j];vol={}
 for i in extra:vol=add(vol,{int(d):F(v) for d,v in cells[i]['exact_area_coefficients'].items()})
 if c['kind']=='star':assert sign(sub(c['fee'],basefee))>0
 certcols.append({k:v for k,v in c.items() if k not in ['box','fee']}|{'column_index':j,'box_expressions':[[expr(e) for e in p] for p in c['box']],'exact_fee':exactout(c['fee']),'actual_cell_count':len(actual[j]),'source_sufficient_cell_count':len(sufficient[j]),'extra_actual_cell_indices':sorted(extra),'extra_actual_volume':exactout(vol),'dominated_by_common_baseline':c['kind']=='star','fee_minus_baseline':exactout(sub(c['fee'],basefee)) if c['kind']=='star' else None})
result={'status':'STOP_NO_EFFECTIVE_GEOMETRIC_ADVANTAGE_NO_LP','model':'R574 n2_six_grid A2','source_positions':[[str(x) for x in p] for p in z],'input_sha256':hashlib.sha256(raw).hexdigest(),'columns_count':46,'quantile_columns_count':10,'star_columns_count':36,'new_axis_interval_counts':[len(c)-1 for c in coords],'refined_residual_cell_count':len(cells),'exact_residual_volume':exactout(resvol),'baseline_quantile_columns':baseline,'baseline_source_sufficient_covers_all_refined_cells':True,'exact_baseline_fee':exactout(basefee),'quantile_actual_equals_source_incidence':True,'star_columns_with_extra_geometry':sum(bool(actual[j]-sufficient[j]) for j in range(10,46)),'all_stars_strictly_dominated_by_same_baseline':True,'dominance_certificate':'Replace any star of weight w by w on each baseline quantile column. Common baseline covers every residual cell already by source-sufficient incidence, total fee w/2 < w*cap. Quantile columns have identical actual/source incidence. Therefore no actual-incidence cost benefit can alter a minimizing selection in this fixed column family.','LP_executed':False,'columns':certcols,'refined_cells':cells,'sign_decisions':DECISIONS,'comparison_unresolved':0,'arithmetic_error':'0 exact radical volumes and Fraction root isolators','interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Only the frozen six-source 46-column preflight; not a general global budget or nontrivial quantile-trim mechanism test.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');signal.alarm(0)
print(json.dumps({k:v for k,v in result.items() if k not in ['columns','refined_cells']},ensure_ascii=False,indent=2))
