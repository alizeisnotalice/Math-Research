# R576 单模型最小复现支撑

最终实际重放通过：`PASS_PORTABLE_SINGLE_MODEL_FULL_CERTIFICATE_REPLAY`。全部数值/几何证书逐字段相同；附加断言从**重新构造的完整残余cells**导出全部witness并集，准确等于冻结10个参考masks及10个quantile列标签：
`[7,11,13,14,15,28,44,52,56,60]`。

本机命令：
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r576_repro_support/reproduce.py`

迁移目录后使用有SymPy的Python运行同目录`reproduce.py`，使用当前解释器重放原样副本`ccu_r576_preflight.py`至临时输出；不会写原实验输出或修改原稿。

`preflight_input.json`仅734 bytes：保留一个model/A、source坐标、冻结reference masks、原残余体积的根式系数。连原体积的显示小数/隔离区间也未复制，因为脚本不读取它们。`input_manifest.json`逐层列明抽取规则和原666,576-byte R574完整文件SHA256；抽取只复用原几何记录，不是一次独立几何审查。

`expected_math.json`保留完整数学合并参考。复现仅忽略runtime、RSS、路径、版本、命令字段；不忽略任何cell、面积/费用、覆盖关系、支配证书、符号判定计数或数值区间。输入哈希也不忽略：参考改为精简输入的实际哈希，原完整输入哈希独立保留于manifest，两者在回执中说明。数学内容与原结果一致。

`reproduction_receipt.json`保存真实命令、返回码、代码/数学投影哈希、全部附加断言与资源。最终单模型重放约0.168秒，单进程；冻结算法仍为Fraction/精确根式与有理sqrt隔离决定，没有float或LP。

准备过程中先验证734-byte精简前的同case输入可重放，再进一步剔除未读取的体积显示字段并最终完整重放；未改变模型或数值计算范围。原脚本和原结果未修改。最终交付即停。
