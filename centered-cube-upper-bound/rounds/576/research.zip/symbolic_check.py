"""Exact symbolic check of the common-grid scalar optimization; no weak bound claim."""
import sympy as s
import json,platform,sys
from pathlib import Path
q=s.symbols('q', positive=True);t=s.symbols('t', positive=True)
h=t*(1+q*t)/(t-1);ts=1+s.sqrt(1+1/q)
res=[s.simplify(s.diff(h,t)-(q*t*t-2*q*t-1)/(t-1)**2),s.simplify((q*t*t-2*q*t-1).subs(t,ts)),s.simplify(h.subs(t,ts)-(s.sqrt(q)+s.sqrt(q+1))**2)]
assert res==[0,0,0]
rows=[]
for n in [2,8,64]:
 for qr in [s.Integer(1),s.Integer(2)]:
  base=(s.sqrt(qr)+s.sqrt(qr+1))**2
  rows.append({'n':n,'q':int(qr),'exact_base':str(base),'exact_certificate':str(base**n),'display_only':str(s.N(base**n,12))})
out={'status':'PASS_THREE_SYMBOLIC_IDENTITIES','identity_residuals':list(map(str,res)),'rows':rows,'scope':'Exact identities support scalar derivative/stationary/value formulas only; numerical displays finite and exploratory. Global minimum and exponential limitation proved analytically in REPORT. No general weak estimate improved.','interpreter':sys.executable,'python':platform.python_version(),'sympy':s.__version__}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(out['status'])
