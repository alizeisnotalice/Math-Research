# Round 65: paid capture tails and conserved original-cap error

2026-10-11. **The uniform objective C_n^square <= sqrt(n)n^{o(1)} remains unproved.**
The retained fully general weak-type benchmark is O(n log n). No improved
general weak upper is claimed here. All source-count and depth dependence
is explicit. The cap-energy route is a sufficient avenue, not a necessary
condition for the original weak theorem; its failure would not settle that theorem.

## Result and exact remaining interfaces

For every finite positive atomic source and its ORIGINAL good receiver set,
the strict-majority capture tail has a dimension-independent HW budget.
The full-capture tail has a sharper constant; the one-source entrance also
has a paid budget. These regions give an actual all-source decomposition,
leaving an explicit multisource submajority region unestimated. A fixed
one-dimensional grid proves that squared surviving arrival jumps alone
cannot pay the complete energy, even though the coherent tail itself is paid.

For every finite positive Borel source, a conserved dyadic redistribution
has complete signed error bounded by (e+1)^2 HW on the original good set,
with no atom-count or minimum-mass loss. Its target height, however, is
[4(n^2+1)]^n H. The target energy remains unpaid at the requested scale.
This is a classical decomposition with explicitly derived error constants,
not a claimed new asymptotic maximal theorem. An affordable error does not
make its exponentially expensive target affordable.

The main numerical search changes positive masses, actual positions and
thresholds, using full-space Lebesgue receivers and full signed event
integrals. Independent heldout replication exposes selection inflation.
A paired early/post split shows that the paid majority tail can be tiny
while almost all measured energy precedes majority capture. This changes
the next task: one cannot rely on majority capture alone, and one must not
recursively charge receiver-dependent sources without a shared mass budget.

## Reproduction and verification scope

This archive contains exactly five files: proof.md, proof.tex.txt,
adversarial_cap_probe.py, results.json and inventory.json. Extract to a
temporary directory, preserve the supplied results.json, then run
`python3 -B adversarial_cap_probe.py` with Python 3.12.14 and NumPy 2.3.5.
The script writes a new results.json alongside itself. The --pilot option
reproduces the exploratory search, not the final result. Two standalone
standard-library Python guards are embedded in the proof sections below.
Save each Python block separately and execute it to reproduce those checks.

The parent independently reran the final script in a fresh temporary
directory: JSON output is byte-identical. Both embedded guards passed and
their code was compared with the frozen final report. Receipts appear below.
LaTeX is saved as a standalone .tex.txt source, statically checked but not
compiled; no PDF is produced. No omitted draft or external input is needed
for these numerical replays. The retained global L2 spectral theorem is
explicitly a prior result, not an output certified by these finite tests.

## Updated skills

All 64 canonical installed skill entries and 437 direct reference paths
were reopened and rehashed following the user's reload request. They match
the Round64 snapshot and none is missing. Matching prior reading is retained;
the researchers reread the entries and method/interface conditions they
actually use. The parent also reread N03, N04, L03 and A02 entrances and
the N04 method/interface/provenance. Hash agreement is neither fresh full
reading of every external paper nor mathematical certification. No unverified
external theorem is imported into the two new direct proofs below.



# Round 65: paid capture tails and an unpaid multisource entrance

This round proves dimension-independent budgets for two actual receiver/time regions of every finite positive atomic source: the one-source entrance and the tail after a fixed strict majority of the total source mass has been captured. The completely captured tail has a sharper constant. A separate all-space example proves that the squared surviving-arrival jumps cannot control the actual square energy: their budget tends to zero while a coherent captured tail stays positive. The remaining submajority multisource region is not estimated, and the general weak-type target remains unproved.

## Current skills and scope

Current E03, N04, F04, and L03 `SKILL.md`, method, and cube-interface files were reread, together with relevant provenance status and actual-reading-card sections. Entrance SHA-256 prefixes were respectively `5d5876513650`, `0ec449afa32e`, `1102ac9b098f`, `0e2d41f62f83`. E03 requires genuine node-mass flow and terminal terms; no cube filtration or free Bellman budget is asserted here. N04 forbids inferring a bounded total error from finitely many positive payments. F04's Poisson/heat-kernel interfaces do not transfer to cube indicators without a bridge; no such transfer is used. L03 distinguishes exact rational finite checks from Decimal refinement. After the latest reload request, the same four current entrances and key method/interface files were reread again before freezing; no tree-flow, summability, semigroup, or interval-arithmetic premise is silently imported. All results below are direct geometric and Tonelli arguments, with no imported external theorem. The strict-majority center-diameter observation was supplied by the parent and independently audited here.

Let \(\mu=\sum_{i=1}^Np_i\delta_{y_i}\), with merged distinct sites, positive weights, and \(W=\sum_i p_i\). Fix \(H>0\), use the original true \(G=\{M\mu\le H\}\), and write
\[
 F_x(v)=\mu\bigl(x+[-v^{1/n}/2,v^{1/n}/2]^n\bigr),\quad
 A_u=e^{-u}F_x(e^u),\quad D=A_{u+1}-A_u.
\]
Set \(q=e^{-1}\), \(c=1-q\). Finite positive atomic sources have finite capped energy by the retained individual-atom estimate and Minkowski; the new bounds below have no atom-number factor.

## 1. A pointwise signed bound using nesting

For every receiver and volume, \(0\le F_x(v)\le F_x(ev)\le W\). Hence
\[
 -cW\le qF_x(ev)-F_x(v)\le qW,
 \qquad |D(x,\log v)|\le cW/v,
\tag{1}
\]
since \(c>q\). The lower bound uses \(F_x(ev)\ge F_x(v)\); the upper uses positivity. This improves the loose bound \(W/v\). If \(F_x(v)\ge\theta W\) with \(\theta\ge q\), then
\[
 qF_x(ev)-F_x(v)\le(q-\theta)W\le0,
\]
so the actual difference is nonpositive throughout that captured-mass tail. No martingale or source-independent scale comparison is needed.

## 2. A global majority-capture stopping budget

For \(0<\theta\le1\), define the actual capture volume
\[
 v_\theta(x)=\inf\{v>0:F_x(v)\ge\theta W\}.
\]
For finite atoms a positive threshold volume is attained at one of the finitely many distance volumes; away from source sites it is positive. At a source site the infimum may be zero, which does not affect the geometric sublevel statement. All source sites lie outside the original good set. On \(G\),
\[
 v_\theta(x)\ge a_\theta:=\theta W/H.
\tag{2}
\]
This follows from applying the original cap to the threshold cube, including its endpoint.

**Geometric lemma.** If \(\theta>1/2\), then for every \(t>0\),
\[
 |\{x:v_\theta(x)\le t\}|\le t.
\tag{3}
\]
For arbitrary \(\theta>0\), the weaker bound \(t/\theta\) always holds.

**Proof.** The sublevel is precisely the set of centers whose side-\(t^{1/n}\) cube contains mass at least \(\theta W\). When \(\theta>1/2\), any two such cubes have source-mass overlap at least \((2\theta-1)W>0\). They therefore intersect, so their centers differ by at most \(t^{1/n}\) in every coordinate. The entire center set lies in a rectangular box with each side at most \(t^{1/n}\); its volume is at most \(t\). The set is a finite union of closed intersections of source-centered cubes, so measurability is immediate. For general \(\theta\), Fubini gives \(\int F_x(t)dx=tW\); Markov then gives \(t/\theta\). The strict threshold in (3) cannot be replaced by \(\theta=1/2\): two equal atoms far enough apart give two disjoint center cubes, of total volume \(2t\), each capturing exactly half the mass. \(\square\)

Define the actual stopped tail
\[
 E^{\rm post}_\theta=\int_G\int_{\log v_\theta(x)}^\infty D(x,u)^2du\,dx.
\]
By (1), the pointwise tail is at most \(c^2W^2/(2v_\theta(x)^2)\). For any positive measurable \(v_\theta\), Tonelli gives
\[
 \int_G v_\theta^{-2}dx
 =\int_{a_\theta}^\infty 2t^{-3}|\{x\in G:v_\theta(x)\le t\}|dt.
\]
Endpoint choices do not affect this identity. Combining (2)–(3) proves the genuinely general budget
\[
 \boxed{E^{\rm post}_\theta\le c^2 HW/\theta\quad(\theta>1/2).}
\tag{4}
\]
For every \(0<\theta\le1\), the Fubini version proves
\[
 E^{\rm post}_\theta\le c^2 HW/\theta^2.
\tag{5}
\]
Thus (4) has constants approaching \(2c^2<0.8\) as \(\theta\downarrow1/2\). A convenient fixed choice is \(\theta=3/4\). The stopped process is the actual arrival profile, and Lebesgue geometry and total source mass are both used essentially. Positivity of the tail difference itself is not assumed; in the strict-majority case it is nonpositive.

If one starts one time unit earlier, when the enlarged cube first captures the same mass fraction, (1) gives
\[
 \int_G\int_{\log v_\theta(x)-1}^\infty D^2
 \le (e-1)^2 HW/\theta\quad(\theta>1/2).
\tag{6}
\]
This is a larger but still dimension-independent cost. It can be useful for an exact residual description, but does not justify recursively repeating the payment.

## 3. The completely captured tail has a sharper geometric payment

Let \(v_*(x)=(2\max_i\|x-y_i\|_\infty)^n\). For \(u\ge\log v_*\), both cubes capture all the source, and
\[
 D(x,u)=-cWe^{-u},\qquad
 E^{\rm term}=\frac{c^2W^2}{2}\int_Gv_*^{-2}dx.
\]
Write \(d_k=\max_i y_{i,k}-\min_i y_{i,k}\). The full-space distribution of \(v_*\) is exactly
\[
 V(t)=|\{x:v_*(x)\le t\}|=\prod_{k=1}^n(t^{1/n}-d_k)_+.
\]
Below \(t^{1/n}=\max d_k\) it is zero. Above that point its almost-everywhere derivative is
\[
 V'(t)=\frac1n\sum_{k=1}^n\prod_{j\ne k}(1-d_j/t^{1/n})\le1.
\]
The formula is valid also with some or all \(d_k=0\), and the distribution is absolutely continuous. Thus the full-space pushforward measure is dominated by \(dt\). On the original good set \(v_*\ge W/H\), so
\[
 \boxed{E^{\rm term}\le\frac{c^2}{2}HW.}
\tag{7}
\]
This is stronger than the \(\theta=1\) version of (4). The constant is attained for a single atom, and by the grid example below. For any positive subsource of mass \(m\), the same proof on the original \(G\) gives \(c^2Hm/2\), because the original cap dominates that subsource. Summing such *diagonal* tail estimates does not estimate mixed terms of the summed response.

## 4. The one-source entrance is also paid

Let \(\mathcal B\subset G\times\mathbb R\) be the region where the enlarged cube \(Q_{u+1}(x)\) contains at most one distinct source atom. If it contains none then \(D=0\); if it contains exactly \(y_i\), nesting gives \(D=D_{p_i\delta_{y_i}}\) at that receiver/time. The regions are disjoint, hence
\[
 E(\mathcal B)\le\sum_i\|D_{p_i\delta_{y_i}}\|_{L^2(G\times\mathbb R)}^2
 \le cH\sum_i p_i=cHW.
\tag{8}
\]
The final inequality uses the exact atom point energy \(cp_i^2/v_i^2\), the cap cutoff \(v_i\ge p_i/H\), and the cube radial pushforward \(dv_i\). Equal-distance ties create no problem: if two distinct sites are captured simultaneously, that receiver/time is outside \(\mathcal B\).

For any fixed \(\theta>1/2\), define the explicit unpaid region
\[
 \mathcal R_\theta=\{(x,u):x\in G,\ F_x(e^u)<\theta W,
                  \#\{i:y_i\in Q_{u+1}(x)\}\ge2\}.
\]
Every receiver/time outside it is in \(\mathcal B\) or the paid majority tail. Therefore
\[
 \boxed{E_G\le(c+c^2/\theta)HW+E(\mathcal R_\theta).}
\tag{9}
\]
Using (6) instead, the residual may be made stricter by requiring \(F_x(e^{u+1})<\theta W\), with paid constant \(c+(e-1)^2/\theta\). This is an actual general decomposition, not an abstract dual identity. There is no estimate for its residual here. A recursive source split depending on the receiver would need its own shared-mass accounting; ordinary tree telescoping does not supply it.

## 5. Surviving squared arrival jumps miss a coherent tail

For almost every receiver of a one-dimensional finite source, distance ties are absent, and the upward jump of \(A\) when atom \(i\) arrives is \(p_i/v_i(x)\), where \(v_i=2|x-y_i|\). Consider the positive budget
\[
 J_G=\int_G\sum_i(p_i/v_i(x))^2dx.
\]
It is the actual squared-arrival-jump budget on final good receivers. It also describes those receivers' jumps after any rule that kills a path at its first cap violation, since these receivers never violate the cap.

Take \(H=1/4\), \(W=1\), and
\[
 \mu_N=\frac1N\sum_{i=1}^N\delta_{(i-1/2)/N}.
\]
The true good set is exactly
\[
 G_N=(-\infty,-1-1/(2N)]\cup[2+1/(2N),\infty).
\tag{10}
\]
To prove this, an interval capturing a consecutive block \(i,\ldots,j\), of mass \(m=(j-i+1)/N\), has average above \(H\) at some radius exactly when its center lies in
\((y_j-m/(2H),y_i+m/(2H))\), if that interval is nonempty. At an atom use small positive radii. Every such block interval is contained in the full-block interval \((-1-1/(2N),2+1/(2N))\): its left endpoint is at least the full-block left endpoint and its right endpoint at most the full-block right endpoint. Conversely the full block proves every center in that open interval bad. This establishes (10), including its endpoints.

Let \(h_N=\sum_{i=1}^N1/i\) denote the harmonic number. Direct rational integration gives
\[
 J_{G_N}=\frac1{4N^2}\sum_{i=1}^N
 \left(\frac1{1+i/N}+\frac1{1+(N+1-i)/N}\right)
 =\frac{h_{2N}-h_N}{2N}\le\frac1{2N}.
\tag{11}
\]
On this same true good set the complete-capture volume starts at four, and its tail pushforward is exactly \(dv\). Thus the actual terminal energy is
\[
 E_N^{\rm term}=\frac{c^2}{2}\int_4^\infty v^{-2}dv=\frac{c^2}{8},
\tag{12}
\]
attaining (7), since \(HW=1/4\). In particular
\[
 \frac{E_{G_N}}{J_{G_N}}\ge
 \frac{c^2N}{4(h_{2N}-h_N)}\sim\frac{c^2}{4\log2}N\longrightarrow\infty.
\tag{13}
\]
This is an all-space, true-filter obstruction at fixed dimension, mass, and height; it does not rely on a local receiver limit or on numerical fitting. No finite constant, even depending on dimension, bounds actual energy by this surviving jump-square budget. The omitted response is the coherent contribution of many small arrivals. The completely captured tail pays it through total mass and geometry, while its individual squared jumps vanish.

The example does not refute a budget that also settles jumps on killed bad receivers, a signed cross-arrival budget, or the desired \(HW\) energy bound. In fact its displayed normalized terminal energy is the fixed constant \(c^2/2\). It is distinct from a positive gate split or full-history drift obstruction.

## Executed deterministic checks

The standalone code below has three stages. Stage 1 uses Fraction arithmetic for every consecutive-block cap endpoint and the exact integrated jump formula. Stage 2 checks actual strict-majority cube-center geometry and the full-capture distribution derivative in rational dimensions. Stage 3 computes actual \(e\)-step stopped point energies by independently grouped distance events, with all time endpoints split, at Decimal 80 and 140 digits. It checks the point tail bound, negative sign in the majority tail, and the exact full-capture tail. These finite checks do not prove an unsampled spatial energy integral; the proofs above establish the global estimates. Decimal refinement is not an outward-rounded interval certificate. Execution passed 11082 exact cap/jump checks, 172 rational geometry checks, and 46 event checks at each precision. The maximum relative 80/140-digit refinement discrepancy was \(5.089\times10^{-80}\). At \(N=128\), the exact-formula terminal/jump ratio was approximately 18.499; its divergence is proved by (13), not fitted.

```python
from fractions import Fraction as F
from itertools import product
from decimal import Decimal as D, localcontext

stage1=0
for N in [1,2,4,8,16,32,64,128]:
    y=[F(2*i-1,2*N) for i in range(1,N+1)]
    left=-F(1)-F(1,2*N); right=F(2)+F(1,2*N)
    for i in range(N):
        for j in range(i,N):
            m=F(j-i+1,N)
            assert y[j]-2*m>=left and y[i]+2*m<=right
            stage1+=1
    direct=sum((1/(yi-left)+1/(right-yi))/(4*N*N) for yi in y)
    harmonic=sum(F(1,k) for k in range(N+1,2*N+1))
    assert direct==harmonic/(2*N) and direct<=F(1,2*N)
    assert 2*(y[-1]-left)==4 and 2*(right-y[0])==4
    stage1+=4
print('stage 1 exact cap/jump checks:',stage1)

stage2=0
for n in [1,2,3,4]:
    y=[tuple(F(s) for s in z) for z in product([0,1],repeat=n)]
    p=[F(i+1) for i in range(len(y))]; W=sum(p)
    centers=list(product([F(-1,2),F(0),F(1,2),F(1),F(3,2)],repeat=n))
    for L in [F(1,2),F(1),F(2),F(3)]:
        captured=[]
        for x in centers:
            mask=[i for i,yi in enumerate(y) if max(abs(a-b) for a,b in zip(x,yi))<=L/2]
            captured.append((x,set(mask),sum(p[i] for i in mask)))
        for theta in [F(51,100),F(3,4),F(1)]:
            selected=[r for r in captured if r[2]>=theta*W]
            if selected:
                for k in range(n): assert max(r[0][k] for r in selected)-min(r[0][k] for r in selected)<=L
                # All actually selected source sets intersect the first selected set.
                for r in selected: assert r[1]&selected[0][1]
            stage2+=1
    for widths in product([F(0),F(1,4),F(1)],repeat=n):
        L=F(2)
        deriv=sum(product_term for product_term in
                  [__import__('functools').reduce(lambda a,b:a*b,
                   [1-widths[j]/L for j in range(n) if j!=k],F(1)) for k in range(n)])/n
        assert 0<=deriv<=1
        stage2+=1
    # Half-mass endpoint: two isolated equal atoms give disjoint center cubes.
    volume=F(2)*(F(1)**n)
    assert volume>F(1)**n
    stage2+=1
print('stage 2 rational geometry checks:',stage2)

def dec(v): return D(v.numerator)/D(v.denominator) if isinstance(v,F) else D(v)

def run(precision):
    with localcontext() as ctx:
        ctx.prec=precision; q=(-D(1)).exp(); c=1-q
        tol=D(10)**(-(precision-12)); data={}; checks=0
        cases=[(1,[(F(i,4),) for i in range(4)],[F(1,4)]*4),
               (2,[(F(0),F(0)),(F(1),F(0)),(F(0),F(1)),(F(1),F(1))],[F(1,4)]*4),
               (3,[(F(0),F(0),F(0)),(F(1),F(1,3),F(2,3)),(F(-1),F(1),F(0))],[F(1,6),F(1,3),F(1,2)]),
               (4,[(F(0),)*4,(F(1),F(0),F(1,2),F(-1,2))],[F(2,5),F(3,5)])]
        for case,(n,y,p) in enumerate(cases):
            for off in [F(0),F(1,7)]:
                x=tuple(F(3)+off+F(k,11) for k in range(n))
                pairs=sorted((F(2)**n*max(abs(a-b) for a,b in zip(x,yi))**n,pi) for yi,pi in zip(y,p))
                groups=[]
                for v,pi in pairs:
                    if groups and groups[-1][0]==v: groups[-1]=(v,groups[-1][1]+pi)
                    else: groups.append((v,pi))
                W=sum(p); cumulative=F(0); maximum=F(0)
                for v,pi in groups: cumulative+=pi; maximum=max(maximum,cumulative/v)
                H=2*maximum
                assert maximum<=H  # this receiver is in its true cap set
                for theta in [F(1,4),F(1,2),F(51,100),F(3,4),F(1)]:
                    cumulative=F(0)
                    for v,pi in groups:
                        cumulative+=pi
                        if cumulative>=theta*W: cut=dec(v); break
                    assert cut>=dec(theta*W/H)
                    ev=[(dec(v),dec(pi)) for v,pi in groups]
                    points=sorted(set([cut]+[a for v,pi in ev for a in [v,q*v] if a>cut]))
                    energy=D(0)
                    for j,lo in enumerate(points):
                        hi=points[j+1] if j+1<len(points) else None
                        mid=(lo+hi)/2 if hi is not None else 2*lo
                        F0=sum((pi for v,pi in ev if v<=mid),D(0))
                        F1=sum((pi for v,pi in ev if q*v<=mid),D(0))
                        coeff=q*F1-F0
                        assert abs(coeff)<=c*dec(W)+tol
                        if theta>=F(1,2): assert coeff<=tol
                        energy+=coeff**2/2*(1/lo**2-(1/hi**2 if hi is not None else D(0)))
                    bound=c*c*dec(W)**2/(2*cut**2)
                    assert energy<=bound+tol
                    if theta==1: assert abs(energy-bound)<=tol
                    data[(case,off,theta)]=energy; checks+=1
        for N in [1,2,4,16,64,128]:
            harmonic=sum((D(1)/D(k) for k in range(N+1,2*N+1)),D(0))
            J=harmonic/(2*N); terminal=c*c/8
            ratio=terminal/J
            assert abs(ratio-c*c*N/(4*harmonic))<=tol*max(D(1),ratio)
            assert abs(terminal-(c*c/2)*D('0.25'))<=tol
            data[('grid',N)]=ratio;checks+=1
        return data,checks

low,cl=run(80); high,ch=run(140)
with localcontext() as ctx:
    ctx.prec=160
    err=max(abs(low[k]-high[k])/max(abs(high[k]),D('1e-100')) for k in high)
    assert err<D('1e-65')
    print('stage 3 event checks per precision:',cl,ch)
    print('maximum relative refinement:',err)
    print('grid terminal/jump ratios:',[(N,str(high[('grid',N)])) for N in [1,2,4,16,64,128]])
```

## Remaining status

The tail payments are general-source theorems, not bounds restricted to the grid witness. They use the true original cap set and the actual centered-cube difference. They leave the multisource submajority entrance in (9) unpaid. The jump-square obstruction explains why a tempting positive arrival settlement cannot pay it by itself. No source-uniform \(n^{o(1)}\) estimate of that residual, and no improved general weak-type upper bound, is established.


# Round 65: a cap-aware conserved replacement with a paid all-source error

## Result and limitation

For every finite positive Borel measure μ on R^n, H>0 and α>1, there is an explicit dyadic-block mass redistribution F such that
mass(F)=W=mass(μ),
0≤F≤βH almost everywhere, β=[2(α+1)]^n,
MF(x)≤R^nH on the ORIGINAL G={Mμ≤H}, R=(α+1)/(α−1),
and, with q=exp(1/n), u=n log L and D=A_{qL}−A_L,
∫_G∫ |D(μ−F)|² du dx ≤ B_n(α)HW,
B_n(α)=2n²(q+1)(1+R^n)/(α−1).

This is a full signed aggregate error bound, not a diagonal or stagewise square estimate. It is independent of the number of atoms, minimum atom mass, stopping depth and number of blocks. At α=2n+1,
B_n(2n+1)=n(q+1)[1+(1+1/n)^n]≤n(e+1)^2.
The replacement height then obeys only β=[4(n+1)]^n. More decisively, α=2n²+1 yields
B_n(2n²+1)=(q+1)[1+(1+1/n²)^n]≤(e+1)²,
while β=[4(n²+1)]^n.
Thus the error itself can already meet a dimension-independent O(HW) budget. The genuine remaining obstruction in this cap-energy sufficient route is the target energy (or an affordable global target height), not the O(n) error in the first example. The sqrt(n)n^{o(1)} general weak upper remains unproved.

The mechanism is the classical dyadic Calderón–Zygmund redistribution, proved directly here. No novelty claim is made for that decomposition or its exponential height. The substantive quantitative interface is the original-cap bound for MF and the resulting aggregate error payment without an exponential height multiplier. This is more than global target existence and does not assume independent coordinates or Gram orthogonality.

## Skills and evidence scope

Current A02 and N04 entry, method, cube-interface and provenance were consulted. A02 requires an actual objective-error domination in addition to a map; N04 requires a uniformly bounded cumulative error before passing to infinitely many blocks. Their entry SHA256 values are respectively 5718759f09c75af3353a9e041f2f20ebcbca429d49eeb85ccea3bef998f141e5 and 0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107. N03 was checked and not applied: there is no oscillatory phase or stationary-phase theorem in this proof. No external occupation, balayage, sparse-domination or square-function theorem is imported. The only spectral input in the later consequence is the explicitly retained sharp L² theorem from prior rounds, and that dependence is separate from the directly proved error lemma.

## 1. Actual construction for arbitrary finite positive sources

Use one fixed half-open dyadic grid, and put λ=(α+1)^nH. Select all maximal dyadic cubes Q for which μ(Q)>λ|Q|. Each bad cube has a maximal bad ancestor: the mass of any ancestor is at most W while its volume tends to infinity. Distinct maximal cubes are disjoint; the family is at most countable. Since its dyadic parent is not bad,
λ<μ(Q)/|Q|≤2^nλ.

Let U be their union, ν=μ restricted to U^c, and m_Q=μ(Q). For every dyadic cube S, either it lies inside a selected cube and ν(S)=0, or S itself is not bad and ν(S)≤μ(S)≤λ|S|. Covering open sets by contained sufficiently fine dyadic cubes gives ν≤λ dx. This measure domination, rather than an unproved atomic approximation, yields a density f_0≤λ.

Define
F=f_0+Σ_Q (m_Q/|Q|)1_Q,
b_Q=μ restricted to Q − (m_Q/|Q|)1_Q dx.
The cubes are disjoint, so F≤2^nλ=βH. Its mass is W, μ−F=Σ_Q b_Q in total variation, each b_Q has mass zero, and Σ_Q ||b_Q||_{TV}≤2W. For finite atomic sources every atom lies in a sufficiently fine bad cube, so f_0=0 and there are at most N selected cubes. No N enters a bound.

The full-side normalization is important. If Q has side ℓ and center z_Q, and x∈αQ (closed dilation), a cube CENTERED AT x of side (α+1)ℓ captures Q. Therefore
Mμ(x)≥m_Q/[(α+1)ℓ]^n>H.
Thus every αQ lies inside the original Ω={Mμ>H}, and G avoids every αQ. The incorrect half-side factor [2/(α+1)]^n is not used.

## 2. Local redistribution has an affordable receiver cap

Fix x∈G and a receiver cube C=x+[-L/2,L/2]^n. If C intersects Q in positive volume, take y∈C∩Q. Since x is outside αQ, in some coordinate |x_j-z_{Q,j}|≥αℓ/2. Hence L≥(α−1)ℓ. Every source point z∈Q has
||x-z||∞≤L/2+ℓ≤RL/2, R=(α+1)/(α−1).
So the ENTIRE original Q mass belongs to the cube x+[-RL/2,RL/2]^n whenever its redistributed density contributes to C. The residual ν in C also belongs to that larger cube. As Q are disjoint,
∫_C F≤μ(x+[-RL/2,RL/2]^n)≤H(RL)^n.
Dividing by L^n proves MF(x)≤R^nH for every x∈G. This estimate uses the original source cap and is independent of the global height β.

Consequently, pointwise on G×R,
|Dμ|≤H, |DF|≤R^nH, |D(μ−F)|≤(1+R^n)H.
The difference of two averages in [0,H] has absolute value at most H, with no factor two.

## 3. A complete all-time cancellation payment

For a full-side cube kernel k_L and shifts y,z,
||k_L(·−y)−k_L(·−z)||_1
=2[1−∏_j(1−|y_j−z_j|/L)_+]
≤2n||y−z||∞/L.
Thus, if y∈Q and z=z_Q,
||d_L(·−y)−d_L(·−z)||_1
≤nℓ(1+q^{-1})/L.

On G the difference vanishes when L<(α−1)ℓ/q, because even the outer cube centered at y cannot reach a receiver outside αQ. The same holds for the center z. Therefore, with du=n dL/L,
∫_G∫ |d_L(x-y)−d_L(x-z_Q)| du dx
≤∫_{(α−1)ℓ/q}^∞ nℓ(1+q^{-1}) n dL/L²
=n²(q+1)/(α−1).

Subtract the SAME center kernel from both parts of b_Q, using its zero total mass. Both the source part and its uniform redistributed part have mass m_Q and lie in Q. Hence
∫_G∫ |Db_Q| ≤ 2n²(q+1)m_Q/(α−1).
Summing absolute values by Tonelli yields
∫_G∫ |D(μ−F)| ≤ 2n²(q+1)W/(α−1).              (L1)

This proof works for a countable cube family. At each scale the total-variation series defines D(μ−F); the integrated sum of its absolute values on G is finite by (L1). There is no infinite-stage boundary term or unproved occupation limit.

Multiply (L1) by the pointwise bound from Section 2:
∫_G∫ |D(μ−F)|²≤2n²(q+1)(1+R^n)HW/(α−1).
Every mixed term is included in this square of the complete aggregate. We did not sum individual square errors. Taking α=2n+1 proves the dimension-linear example. Taking α=2n²+1 instead gives the dimension-independent bound (q+1)[1+(1+1/n²)^n]≤(e+1)²: indeed q=e^{1/n}≤e and (1+1/n²)^n≤e^{1/n}≤e. Its global height is [4(n²+1)]^n. Taking α→∞ makes this error budget arbitrarily small but sends the global target height to infinity.

## 4. An explicit dimension-only obstacle consequence, and why it is insufficient

Using only the separately retained global sharp L² theorem
||DF||²_{L²(dx du)}≤κ_n||F||²_2≤κ_nβHW,
the already PAID construction gives
E_G(μ)≤A_n(α)HW,
A_n(α)=[sqrt(κ_n[2(α+1)]^n)+sqrt(B_n(α))]^2.

For finite atomic μ, Round64's actual spatial identity then gives
B_free−B_bad=E_G−T_G≤A_n(α)HW.
This is a quantitative dimension-only upper bound obtained from a conserved construction and a finite full-error payment. It is not obtained by merely renaming E_G. It is exponential and does not approach the requested asymptotic target.

For example α=3/2 has β=5^n and R^n=5^n:
A_n(3/2)=5^n[sqrt(κ_n)+2n sqrt((q+1)(1+5^{-n}))]^2.
The dyadic exponential benchmark is classical in principle; no claim of a new asymptotic bound is made. The useful distinction is that at α≈n the ERROR alone is O(n), and at α≈n² it is O(1), independently of height. The full signed error is therefore already affordable for the cap-energy sufficient route at α=2n²+1; the target norm remains unaffordable. Replacing the dyadic height by an affordable global height while retaining the receiver cap and the cancellation payment is the exact missing construction. No remote-interaction cancellation theorem, entropy removal or subpower obstacle estimate is claimed.

## 5. Near-coincident and tie pressure

The estimate has no minimum-mass or separation factor. For two n=2 atoms at 0 and te_1, t→0, Round64's separate B_free and B_bad diverge like cp²/(3t²); the present bound applies to their DIFFERENCE via the genuine conserved replacement. It does not separately charge either divergent interaction.

Dyadic source points on faces are assigned by half-open membership. A cube of density EXACTLY λ is not selected. Selected cubes have strict density >λ, so the closed α-dilation lies inside the strict original bad set even when captured atoms sit on the centered receiver boundary. Ties in capture distances are counted together. These conventions are implemented in the rational checks below.

## 6. Standalone numerical audit

The program below checks dyadic maximal selection and parent bounds for near-coincident, unequal-weight, tensor-corner and tied-boundary source configurations in n=1,...,4. It checks the original good gate exactly, actual uniform-cube captured mass, the enlarged-source comparison, the receiver cap and pointwise signed-error envelope at multiple rational scales. The source list and all finite parameters are given in code. Its additional one-dimensional check integrates the actual absolute translation defect outside the dilated interval over ALL scales, using exact event partitions and Decimal logarithms, against the proved cancellation bound. Decimal output is finite evidence, not an interval certificate. No numerical result establishes a general inequality; the preceding proof does.

```python

from fractions import Fraction as F
from itertools import product
from decimal import Decimal, localcontext
import json

def side(k): return F(2)**k
def cell(y,k):
    ell=side(k)
    return (k,tuple(int(v//ell) for v in y))
def in_cell(y,Q):
    k,a=Q; ell=side(k)
    return all(a[j]*ell<=y[j]<(a[j]+1)*ell for j in range(len(y)))
def qmass(Q,src): return sum(p for y,p in src if in_cell(y,Q))
def selected(src,n,lam):
    # Every listed atom is already bad at k=-20, all cubes at k=20 are below λ.
    assert max(p for y,p in src)<=sum(p for y,p in src)<=lam*side(20)**n
    assert all(p>lam*side(-20)**n for y,p in src)
    candidates=set()
    for y,p in src:
        bad=[cell(y,k) for k in range(-20,21) if qmass(cell(y,k),src)>lam*side(k)**n]
        candidates.add(max(bad,key=lambda Q:Q[0]))
    cubes=sorted(candidates)
    for Q in cubes:
        assert qmass(Q,src)>lam*side(Q[0])**n
        k,a=Q; parent=(k+1,tuple(v//2 for v in a))
        assert qmass(parent,src)<=lam*side(k+1)**n
        assert qmass(Q,src)<=2**n*lam*side(k)**n
    assert sum(qmass(Q,src) for Q in cubes)==sum(p for y,p in src)
    return cubes

def cap(x,src,H):
    n=len(x)
    radii=sorted({max(abs(x[j]-y[j]) for j in range(n)) for y,p in src})
    return all(r and sum(p for y,p in src if max(abs(x[j]-y[j]) for j in range(n))<=r)
               <=H*(2*r)**n for r in radii)
def captured(x,L,src):
    return sum(p for y,p in src if all(abs(x[j]-y[j])<=L/2 for j in range(len(x))))
def target_captured(x,L,cubes,src):
    n=len(x); ans=F(0)
    for Q in cubes:
        k,a=Q; ell=side(k); vol=F(1)
        for j in range(n):
            vol*=max(F(0),min(x[j]+L/2,(a[j]+1)*ell)-max(x[j]-L/2,a[j]*ell))
        ans+=qmass(Q,src)*vol/ell**n
    return ans

def norm1(L,y,alpha,q):
    # Actual d_L shifted by y minus d_L centered at 0, outside [-α/2,α/2].
    endpoints=sorted({-alpha/2,alpha/2}|{z+s*L for z in (F(0),y) for s in (-q/2,-F(1,2),F(1,2),q/2)})
    ans=F(0)
    def d(x,z):
        return (1/(q*L) if abs(x-z)<=q*L/2 else 0)-(1/L if abs(x-z)<=L/2 else 0)
    for a,b in zip(endpoints,endpoints[1:]):
        x=(a+b)/2
        if abs(x)>alpha/2: ans+=(b-a)*abs(d(x,y)-d(x,0))
    return ans

def alltime_norm(y,alpha,q):
    lines=[(z,s) for z in (F(0),y) for s in (-q/2,-F(1,2),F(1,2),q/2)]
    lines += [(-alpha/2,F(0)),(alpha/2,F(0))]
    knots={F(0)}
    for a,s in lines:
        for b,t in lines:
            if s!=t and (b-a)/(s-t)>0: knots.add((b-a)/(s-t))
    knots=sorted(knots)
    def dec(x): return Decimal(x.numerator)/Decimal(x.denominator)
    with localcontext() as ctx:
        ctx.prec=80
        total=Decimal(0)
        for lo,hi in zip(knots,knots[1:]+[None]):
            if hi is None:
                L1=2*lo; L2=3*lo; L3=4*lo
            else:
                L1=(2*lo+hi)/3; L2=(lo+2*hi)/3; L3=(lo+hi)/2
            v1=norm1(L1,y,alpha,q); v2=norm1(L2,y,alpha,q)
            B=(v1-v2)/(1/L1-1/L2); A=v1-B/L1
            assert norm1(L3,y,alpha,q)==A+B/L3
            if lo==0:
                assert A==0 and B==0
            elif hi is None:
                assert A==0
                total+=dec(B/lo)
            else:
                total+=dec(A)*(dec(hi)/dec(lo)).ln()+dec(B)*(1/dec(lo)-1/dec(hi))
        bound=dec((q+1)/(alpha-1))
        assert total>=0 and total<=bound
        return float(total/bound)

def run():
    checks=0; good_count=0; block_count=0; configurations=0
    for n in range(1,5):
        cases=[]
        cases.append([(tuple(F(0) for j in range(n)),F(1)),
                      (tuple(F(1,64) if j==0 else F(0) for j in range(n)),F(1))])
        cases.append([(tuple(F(1) for j in range(n)),F(3)),
                      (tuple(F(-1) for j in range(n)),F(1,7)),
                      (tuple(F(0) if j==0 else F(2) for j in range(n)),F(2,3))])
        cases.append([(tuple(F(v) for v in y),F(1)) for y in product((0,1),repeat=n)])
        for src in cases:
            for alpha in (F(3,2),F(2*n+1)):
                H=F(1,64); lam=(alpha+1)**n*H; R=(alpha+1)/(alpha-1)
                cubes=selected(src,n,lam); block_count+=len(cubes); configurations+=1
                for t in (-128,-64,-32,-16,-8,-4,0,4,8,16,32,64,128):
                    for pattern in (tuple(F(t) for j in range(n)),
                                    tuple(F(t) if j==0 else F(1,2) for j in range(n))):
                        x=pattern
                        if not cap(x,src,H): continue
                        good_count+=1
                        for Q in cubes:
                            k,a=Q; ell=side(k); z=tuple((v+F(1,2))*ell for v in a)
                            assert max(abs(x[j]-z[j]) for j in range(n))>alpha*ell/2
                            checks+=1
                        for L in map(F,(1,2,4,8,16,32,64,128,256)):
                            mass=target_captured(x,L,cubes,src)
                            assert mass<=captured(x,R*L,src)<=H*(R*L)**n
                            checks+=2
                            q=F(3,2)
                            dm=captured(x,q*L,src)/(q*L)**n-captured(x,L,src)/L**n
                            df=target_captured(x,q*L,cubes,src)/(q*L)**n-mass/L**n
                            assert abs(dm-df)<=(1+R**n)*H
                            checks+=1
    ratios=[alltime_norm(y,a,q) for y in (F(-1,2),F(-1,4),F(0),F(1,4),F(1,2))
            for a in (F(3,2),F(3),F(5),F(9)) for q in (F(3,2),F(2))]
    translation_checks=0
    for n in (1,2,4,8,16,32):
        for L in (F(1,4),F(1),F(4)):
            for delta in (F(0),F(1,8),F(1,2),F(2)):
                overlap=F(1)
                for j in range(n): overlap*=max(F(0),1-delta/(L*(j+1)))
                actual=2*(1-overlap)
                assert actual<=2*n*delta/L
                translation_checks+=1
    return {"source_configurations":configurations,"selected_blocks_total":block_count,
            "true_good_receivers":good_count,"exact_cap_geometry_error_checks":checks,
            "exact_translation_volume_checks":translation_checks,
            "alltime_1d_translation_checks":len(ratios),
            "largest_observed_L1_to_proved_bound_ratio":max(ratios),
            "scope":"exact finite rational geometry; Decimal80 all-time L1 values; no interval claim"}
if __name__=="__main__": print(json.dumps(run(),sort_keys=True))
```

## Actual replay

The standalone audit completed in approximately one second. It passed 13,269 exact rational cap/geometry/signed-error-envelope comparisons on 24 source configurations, 59 selected blocks and 446 true-good receiver instances. All 72 exact translation-volume inequalities passed. The 40 Decimal80 all-time one-dimensional defect integrals also passed the proved L1 bound, with largest observed ratio 0.7140593642054712. These finite tests include near-coincident atoms, unequal masses, dyadic boundary ties and multiple capture ties. No count, separation or minimum-mass dependence appears in the analytic bound.

Final skill reload: A02 and N04 SKILL.md, method.md and cube-interface.md were again read from the current installed paths after the final user reload request. Their six SHA256 values match the earlier reads exactly; the applicable objective-error domination and countable summability restrictions are unchanged. The embedded numerical plan was not enlarged: the general arbitrary-α proof already covers α=2n²+1, and the reported replay counts remain 13,269/72/40.


# Round65: active positive-source cap-energy search

This round actively changes actual atom positions, positive masses and H to search the actual capped energy

\[
\mathcal E_H(\mu)/(HW)=\frac1{HW}\int_{M\mu\le H}\int_{\mathbb R}|A_{e^{1/n}L}\mu-A_L\mu|^2\,du\,dx,
\qquad u=n\log L.
\]

The computation retains signed time increments and their complete cross terms. Source measures are positive throughout. High search scores frequently decrease on independent heldout receivers. The tested range contains no observed large-energy candidate, but it supplies no source-independent or dimension-only upper bound.

## Reproduction and actual scope

Run the standalone script without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B adversarial_cap_probe.py
```

It writes `results.json` beside itself. Python3.12.14 and NumPy2.3.5 were used, with one BLAS thread. No installation, Git operation, spatial-box approximation or time-grid approximation was used. The last complete energy run took 5.220885 seconds. A final added assertion on the exact majority threshold was subsequently checked on the unchanged stored split cases in 0.645091 seconds; no search was repeated for that metadata/assertion update. Runtime is printed, not serialized.

The four-configuration exploratory pilot searched 240 candidates using 122880 receiver evaluations. The default final run searches 1500 candidates in 15 configurations: n=1,2,4,8,16 and requested N=4,16,64 varied independently. Each configuration has 36 initial geometry/threshold pairs and 64 active mutations, each evaluated on 512 receivers, for 768000 search receiver evaluations. A common receiver seed is used within each configuration. These evaluations are dependent and must not be counted as an independent statistical sample of size 768000.

The first independent heldout stage has 90 rows: raw-mean winner, mean-minus-SE winner and matched best initial control, each on two fresh seeds with 8192 receivers. The winner roles can name the same candidate; those rows nevertheless use independent receiver seeds. Sixteen fresh crossed source/threshold followup rows use 32768 receivers each at (n,N)=(1,64),(4,16), selected after inspecting the first heldout results. Total independent heldout receiver count is 1261568 over 106 rows. Default registered search-plus-heldout evaluations total 2029568. The majority-stop diagnostic reuses 212992 registered heldout receivers in eight rows; it does not add new independent sampling evidence.

Every retained candidate and control has the exact requested count 4,16 or64 after duplicate merging. All stored source masses sum exactly to W=1. Source coordinates and rational weights are stored for selected candidates; search traces retain candidate IDs, parent IDs, operation, H, mean, SE, source hash and random seeds. The executable regenerates the entire search deterministically.

## Search parameters and selection boundary

Initial geometries are a correlated equally spaced diagonal, a random cloud, distinct binary vertices or a perturbed binary subset when N exceeds2^n, positive nested dyadic positions, four nested clusters, and correlated coordinate slabs. Each initial geometry is tested at H=2^{jn}, j=-3,-2,-1,0,1,2. Thus H^(1/n), rather than the same absolute H at every dimension, initially spans 1/8 to4.

Mutations cycle through zero-mean coordinate noise, displacement of one atom, positive logarithmic mass redistribution, and threshold changes. Every mutation also changes H. Zero-mean refers to the coordinate displacement, never to a signed source. Coordinates are normalized to maximum absolute coordinate1. Positive integer mass weights are generated at nominal resolution2^20, with floor1, then normalized by their exact integer sum. The actual positive H is the exact Fraction of the chosen machine value; log2 H is restricted to[-4n,4n]. Seven of the fifteen penalized winners have unequal final masses, so this is not solely a position/threshold search.

The four leaders for mutation are ranked by mean minus sampleSE. That quantity is a heuristic ranking penalty, not a confidence bound. A raw-mean winner is independently retained. The finite bounded search neither covers all sources nor certifies a local or global optimum. The common random numbers reduce some comparison noise while permitting substantial overfitting; independent heldout seeds address that selection issue on the retained candidates. No selected search mean is pooled with a heldout mean.

## All-space receiver proposal, true cap and full time energy

Let a_i=p_i/W, V=W/H and tau_i=(2||x-y_i||_infinity)^n/V. At each selected source center i, choose B=V or B=Va_i with equal probability. Each radial component has density

\[
q_B(v)=\begin{cases}1/(2B),&v\le B,\\B/(2v^2),&v>B,\end{cases}
\]

whose two integrals against dv equal1/2. Draw v=BU or B/U with equal probability; choose face and sign uniformly and free cone coordinates uniformly[-1,1]. Uniform cube-cone coordinates obey dx=dv d sigma. Center i is chosen with probability a_i. The complete mixture density is evaluated over all centers and both scales:

\[
q=(H/W)q_{core},\qquad
q_{core}=\frac14\sum_i a_i\min(1,\tau_i^{-2})+
\frac14\sum_i\min(1,(a_i/\tau_i)^2).
\]

Only dividing by the selected component would be incorrect; the code always uses the complete density. Machine U=0 is replaced by the next positive float. The ideal proposal has full-space support, with no receiver box or volume cutoff. Finite machine transforms are not certified unbiased continuum sampling.

The true all-scale maximal value is the maximum cumulative normalized mass divided by arrival tau, using complete tied batches. Positive partial cumulative sums at a common tau have their largest value at the full batch. The signed time events are +a_i/e at tau_i/e and -a_i at tau_i. On every open event interval D/H=C/t, integrated exactly in real arithmetic as C^2(t_left^{-2}-t_right^{-2})/2. The final infinite interval is included. Equal events have zero length; the next positive interval uses the entire tied coefficient. There is no time mesh or omitted tail. The normalized score is 1_G Ecore/qcore, with Epoint=H^2 Ecore.

The individual-mass component on G has density (1/2)sum a_i^2/tau_i^2, since every tau_i>=a_i. Hilbert Cauchy gives Ecore<=cN sum a_i^2/tau_i^2, c=1-e^{-1}. Our half-weight individual component therefore supplies the finite score envelope B=4cN. This is independent of dimension and mass imbalance but still depends on actual source count. Each heldout row reports the formal two-sided95% Hoeffding radius B sqrt(log40/(2S)). It applies per row to independent exact continuous-proposal scores. It is not simultaneous certification of all rows and does not cover machine transform bias. For N64, S32768 it is approximately1.21408, vastly wider than the observed SE; for N16 at that sample count it is approximately.30352.

## Active winners versus independent replication

Search means range .269772–.839412. All106 heldout means range .585311–.761829. The initially largest search winner, n4,N64, scores .839412±.062827 but independently gives .659370±.013256 and .658449±.013218. The n8,N16 winner scores .744305±.047493 but gives .600505±.010603 and .588317±.010381. These differences are direct evidence of selection bias, not evidence that the event formula is inaccurate.

The largest initial heldout value is an equally spaced n1,N64 initial source at H=.25: .761829±.010557 and .745482±.010504. The corresponding searched mutation scores .831319±.049022 on selection receivers but only .742102±.011796 and .741474±.011750 on fresh heldout receivers.

The n4,N16 winner seems initially to improve the original vertex control: .719014±.008501/.700233±.008453 versus .654334±.008672/.657205±.008628. Crossed followup separates geometry and threshold:

| source | H | independent means ± sampleSE |
|---|---|---|
|Original n4,N16 vertices|.0625|.667245±.004372; .667739±.004386|
|Perturbed selected positions|.0625|.684292±.004001; .695144±.004013|
|Original vertices|.0260892827|.717166±.004041; .719854±.004037|
|Perturbed selected positions|.0260892827|.718131±.004279; .716610±.004261|

Threshold adjustment accounts for most of the apparent improvement. At the selected threshold the original and perturbed geometries agree within these diagnostic errors. Both have equal positive masses.

Fresh n1,N64 crossed followup gives original grid at H=.25, .750618±.005260/.747273±.005255, and mutated source at the same H, .745337±.005340/.737427±.005324. At the mutated H=.146806255 both sources are lower, about .72–.74. This winner does not improve its original control on the followup.

At n16,N64, the selected candidate gives .653622±.010783/.667145±.010863, versus .637219±.010940/.645246±.010997 for the matched initial control. The search does not establish a growing energy sequence, nor does this tested range establish a small universal budget. No exponent was fitted; a large capped energy alone would not be a weak-type counterexample.

## Majority-stop paid branch and remaining early energy

The new analytic branch supplied by the parent uses v_theta(x), the first actual capture volume containing at least theta W source mass. For theta>1/2 the sublevel volume is at most v: two heavy cubes contain a common positive source mass, so their centers have infinity diameter at most the cube side. On G, v_theta>=theta W/H. The profile bound |D|<=cW/v then gives

\[
\mathcal E_{post,theta}/(HW)\le c^2/theta.
\]

For theta>=e^{-1} the signed increment after this stopping volume is nonpositive. These are analytic inputs; the numerical rows do not prove them. We split at theta=3/4 using exact integer cumulative source masses to resolve the stopping threshold, including tied arrivals. Event intervals are cut at the actual normalized stopping volume; early and post energies sum to the full signed-squared time energy.

The reference paid budget is c^2/.75=.532768535. The actual diagnostic split, using the same registered receivers, is:

| source/threshold | early means | post means | total means |
|---|---|---|---|
|n1,N64 grid,H=.25|.513297; .510935|.237321; .236338|.750618; .747273|
|n4,N16 original vertices,H=.0260892827|.705834; .708419|.011332; .011435|.717166; .719854|
|n4,N16 perturbed winner,sameH|.702604; .700725|.015527; .015885|.718131; .716610|
|n16,N64 selected candidate|.653615; .667124|.00000670; .00002111|.653622; .667145|

Early SE is .00359 for the grid, about .00402–.00423 for n4, and .01078–.01086 for n16. Post SE is .00168, .000205–.000238, and .00000254/.00001362 respectively. The high-dimensional candidate's post branch is tiny while essentially all its actual energy is early. The proven late budget leaves a material early branch unpaid. The early/post/total scores are dependent paired quantities, not independent estimates to combine using independent-error arithmetic.

The maximum pointwise score-decomposition discrepancy is8.881784e-16. No positive post coefficient was found. The pointwise post envelope c^2/(2 tau_theta^2) and cap stopping inequality tau_theta>=.75 pass. Each row's largest post receiver is retained and rechecked with Decimal80/120 signed truncated events; maximum float relative discrepancy is1.847631e-15. These diagnostics agree with the analytic post budget but do not turn the Monte Carlo means into a certified bound.

## Arithmetic checks and limits

All212 retained nearest accepted/rejected gate receivers agree with Decimal80/120 actual-source maxima. The smallest retained absolute float log maximal margin is9.495868e-7. Fifteen largest-score receivers, three per dimension, have independent Decimal signed pair-Gram and event checks. Maximum float energy relative error is3.834332e-15, complete mixed-density relative error1.329218e-15, Decimal80/120 energy relative change1.148889e-78, and Decimal120 event/Gram relative discrepancy2.422431e-118. Largest observed heldout score is9.37902. Twenty single-atom point checks verify the analytic energy c p^2/v^2 and three unequal-mass n2 common-face checks verify actual positive-volume arrival ties. The single-atom full integral equals cHW analytically; this round does not repeat a new Monte Carlo calibration of that mean.

The retained machine coordinates are interpreted exactly in Decimal arithmetic; masses and H use their recorded Fractions. The high-precision arithmetic is nearest rounding, not outward-rounded certification. Gate checks cover selected borderline points; no claim is made that every executed float gate is interval-certified. All-space support eliminates box truncation, and event integration eliminates time truncation, but pseudorandom machine sampling and transform error remain outside the formal ideal-proposal Hoeffding statement. The reported SE and ESS describe these finite samples and do not certify missing rare tails.

L01/L02/L03/H05 current SKILL entries and method conditions were reread before finalization. Their relevant restrictions are respected: actual common positive sources rather than proxy parameter feasibility, no unproved lattice-to-continuum transfer, search heuristics separated from certification, no nearest-Decimal-as-interval claim, and an actual independent-score range for Hoeffding. No unreviewed literature theorem is asserted. The finite search and the paid-branch diagnostic are distinct from the general mathematical proof still required for the early cap energy.


## Integration audit and next general task

The two constructions are alternatives; their unpaid terms cannot be
identified or cancelled without a new proof. In the capture decomposition,
R_theta contains original-good receivers with current captured mass below
theta W and at least two distinct atoms in the enlarged cube. Its budget
is not implied by the paid one-source and majority branches. In the
redistribution construction, an O(HW) aggregate error is available, but the
new density has a huge global height and no proved affordable energy on G.
Its receiver cap MF <= (1+1/n^2)^n H does not by itself estimate its time
energy. The retained L2 estimate costs kappa_n [4(n^2+1)]^n HW, which is
unacceptable. Taking alpha still larger reduces error but worsens height.

The next possible source-budget route must handle coherent multisource
arrivals before majority capture without summing one payment per depth or
source. The exact jump counterexample rules out one overly strong positive
budget. Any cluster/stopping refinement must retain the original receiver
set and account for shared source mass and cross terms. Alternatively the
replacement target needs a genuine geometric energy estimate rather than
the global-height bound. Neither requirement is currently proved. No final
weak-type or all-scale return can be asserted from this round alone.

## Independent replay receipt

```json
{
  "embedded": {
    "obstacle_budget": {
      "exit_code": 0,
      "guard_sha256": "b567b9afef98acf8dc9116fdbc10c2b3e9c363db7fee2a862b6d9ba2a7127eec",
      "source_sha256": "336e59e0ed6d6b02d9b722362240b5432fdaf1fabfc7837873e397b1d9c53fd6",
      "stderr": "",
      "stdout": "{\"alltime_1d_translation_checks\": 40, \"exact_cap_geometry_error_checks\": 13269, \"exact_translation_volume_checks\": 72, \"largest_observed_L1_to_proved_bound_ratio\": 0.7140593642054712, \"scope\": \"exact finite rational geometry; Decimal80 all-time L1 values; no interval claim\", \"selected_blocks_total\": 59, \"source_configurations\": 24, \"true_good_receivers\": 446}\n"
    },
    "stopped_budget": {
      "exit_code": 0,
      "guard_sha256": "fc05c45905aa83c2174fdcaaac8e3bd0a6b35249b0b8b7348f890e057d6bad15",
      "source_sha256": "45ec6dbdb4c5d54454aca0d75a416038cc4b6378e1169ee585861242d3bfddb7",
      "stderr": "",
      "stdout": "stage 1 exact cap/jump checks: 11082\nstage 2 rational geometry checks: 172\nstage 3 event checks per precision: 46 46\nmaximum relative refinement: 5.088437035858178068700876866456372407206524831191418229599825937565577717031504522878198417740072394967995137314371159760048482633127691877676848520905782528326E-80\ngrid terminal/jump ratios: [(1, '0.19978820044686402435147597732478133425800464192302010622624263462957519130584404161140178689940888063091131831797278089797769764315629751045'), (2, '0.34249405790890975603110167541391085872800795758232018210213023079355747081001835704811734897041522393870511711652476725367605310255365287506'), (4, '0.62972641041413050827482109175540833312091519405379695771123382022079985252123450264006566977674844176347282321612433753959199257129939928246'), (16, '2.3581960835006687658264971344807455376716989363805384011856724821839454354643617720522545907708883270664057278647838578356412053635024709728'), (64, '9.2755386421073478449926677355462530455500885548515538113548384882778520288879928785456264848155340406571189013077417210065626938556673470861'), (128, '18.498964449036186877197667768780695416100775384296561748727512991481179999516569842969593254619568123384713312297480549463297108402187431351')]\n"
    }
  },
  "frozen_hashes": {
    "adversarial_cap_probe.py": "4021b3f7b34bcba4d4a8a7897725b45f9bae3bea768ae6d15fafeabaf53dc6a0",
    "numeric_report.md": "f09031f9e24e214bb5ed574e14f575ee105236850316ca4a59a21bc5a05678f1",
    "obstacle_budget.md": "336e59e0ed6d6b02d9b722362240b5432fdaf1fabfc7837873e397b1d9c53fd6",
    "obstacle_budget.tex.txt": "5dd6379a6122bc9c2b986ad010f3f3193c5d30004b39a9490f166471f9abf891",
    "results.json": "dc4f86989d10f7c8cce0353e0be35c46a1de0620a7e946317082e4b9cc80a0ad",
    "stopped_budget.md": "45ec6dbdb4c5d54454aca0d75a416038cc4b6378e1169ee585861242d3bfddb7",
    "stopped_budget.tex.txt": "599350bc76f4b853ad52aa2bfa18d1e9ed65ee7adb52c2c1da049ea49352d3bd"
  },
  "main": {
    "exit_code": 0,
    "python": "/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
    "result_byte_identical": true,
    "runtime_seconds": 5.263857291996828,
    "stderr": "",
    "stdout_last_line": "{\"runtime_seconds\": 5.216793709005287, \"counts\": {\"configurations\": 15, \"selection_candidates\": 1500, \"selection_receivers\": 768000, \"heldout_rows\": 106, \"heldout_receivers\": 1261568, \"closest_gate_checks\": 212, \"extreme_Gram_checks\": 15, \"paid_split_rows\": 8, \"paid_receivers_reused\": 212992}, \"largest_heldout\": [[0.7618285371456397, 0.010557266293777266, 1, 64, \"matched_initial_control\"], [0.750617961934848, 0.0052604318941631345, 1, 64, \"matched_initial_control\"], [0.747272965864336, 0.005255236117311012, 1, 64, \"matched_initial_control\"], [0.7454818388291968, 0.010503807785013522, 1, 64, \"matched_initial_control\"], [0.7453372324022549, 0.005340320217487854, 1, 64, \"mean_minus_SE_winner\"], [0.7429286443955316, 0.00585262004418975, 1, 64, \"matched_initial_control\"], [0.7421017975923847, 0.011796368892052008, 1, 64, \"raw_mean_winner\"], [0.7414737600557255, 0.011750399041467607, 1, 64, \"raw_mean_winner\"]]}"
  },
  "replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round065-replay-yk2owc4x"
}
```
