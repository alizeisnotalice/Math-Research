#!/usr/bin/env python3
"""Active positive-source search for actual all-space capped time energy.
NumPy receiver batching; exact event formula in real arithmetic, no space/time cutoff.
Run with Python+NumPy; --pilot produces the deliberately small pilot only.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse, hashlib, itertools, json, math, time
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import numpy as np
C=1-math.exp(-1)


def source(family,n,N):
    rng=np.random.default_rng(640001+1009*n+37*N)
    if family=='single':
        coords=[[.25]*n]; weights=[F(3)]
    elif family=='vertices':
        coords=list(itertools.product([-1.,1.],repeat=n));weights=[F(4**n)]*len(coords)
    elif family=='diagonal':
        coords=[[(2*j+1-N)/(2*N)]*n for j in range(N)];weights=[F(1,N)]*N
    elif family=='clusters':
        coords=[[(2 if j<N//2 else -2)+((j%(N//2))+.5)/(256*N)]+[((j*(k+3))%N-N/2)/(128*N) for k in range(n-1)] for j in range(N)]
        weights=[F(1,N)]*N
    elif family=='nested':
        coords=[[0.]*n]+[[2.**(-j)]*n for j in range(1,N)];weights=[F(1,N)]*N
    elif family=='unequal_cloud':
        coords=(rng.integers(-512,513,size=(N,n))/1024).tolist();weights=[F((j+1)**2) for j in range(N)]
        total=sum(weights);weights=[p/total for p in weights]
    else:raise ValueError(family)
    merged={}
    for y,p in zip(coords,weights):merged[tuple(y)]=merged.get(tuple(y),F(0))+p
    return dict(family=family,n=n,N_requested=N,N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W=str(sum(merged.values())))


def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])


def point_batch(x,src,H,proposal="global"):
    y,a=arrays(src);n=src['n'];V=float(F(src['W'])/F(H))
    dist=np.max(np.abs(x[:,None,:]-y[None,:,:]),axis=2)
    with np.errstate(divide='ignore'):
        lt=n*np.log(2*dist)-math.log(V)
    ix=np.argsort(lt,axis=1,kind='stable');slt=np.take_along_axis(lt,ix,axis=1)
    cum=np.cumsum(np.broadcast_to(a,lt.shape)[np.arange(len(x))[:,None],ix],axis=1)
    lm=np.max(np.log(cum)-slt,axis=1);cap=lm<=0
    if proposal=='global':q=np.sum(a[None,:]*.5*np.exp(-2*np.maximum(lt,0)),axis=1)
    elif proposal=='mass':q=np.sum(.5*np.exp(-2*np.maximum(lt-np.log(a)[None,:],0)),axis=1)
    elif proposal=='mixed':q=.5*np.sum(a[None,:]*.5*np.exp(-2*np.maximum(lt,0)),axis=1)+.5*np.sum(.5*np.exp(-2*np.maximum(lt-np.log(a)[None,:],0)),axis=1)
    else:raise ValueError(proposal)
    energy=np.zeros(len(x));diag=np.zeros(len(x))
    if np.any(cap):
        L=lt[cap];K=len(L)
        ev=np.concatenate([L-1,L],axis=1);change=np.broadcast_to(np.concatenate([a/math.e,-a]),ev.shape)
        order=np.argsort(ev,axis=1,kind='stable');ev=np.take_along_axis(ev,order,axis=1)
        coef=np.cumsum(np.take_along_axis(change,order,axis=1),axis=1)
        # Equal events have zero interval length. Full tied cumulative mass is used next.
        intervals=-np.expm1(2*(ev[:,:-1]-ev[:,1:]))
        energy[cap]=np.sum((coef[:,:-1]*np.exp(-ev[:,:-1]))**2*intervals/2,axis=1)+(coef[:,-1]*np.exp(-ev[:,-1]))**2/2
        diag[cap]=C*np.sum(a[None,:]**2*np.exp(-2*L),axis=1)
    return lm,q,energy,diag


def draw(src,H,S,seed,proposal="global"):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/F(H))
    center=rng.choice(len(a),size=S,p=a)
    U=rng.random(S);U=np.maximum(U,np.nextafter(0.,1.))
    inner=rng.integers(0,2,size=S)==0
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))
    if proposal=='mass':mass_branch=np.ones(S,dtype=bool)
    elif proposal=='mixed':mass_branch=rng.integers(0,2,size=S)==0
    else:mass_branch=np.zeros(S,dtype=bool)
    lv+=np.where(mass_branch,np.log(a[center]),0)
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1
    theta[np.arange(S),face]=sign
    x=y[center]+(.5*np.exp(lv/n))[:,None]*theta
    return x,center,inner,U,face,sign,mass_branch


def probe(src,H,S,seed,stage,proposal="global"):
    x,center,inner,U,face,sign,mass_branch=draw(src,H,S,seed,proposal)
    batches=[point_batch(x[j:j+512],src,H,proposal) for j in range(0,S,512)]
    lm,q,energy,diag=[np.concatenate([b[k] for b in batches]) for k in range(4)]
    score=energy/q;dscore=diag/q
    bound=2*C*src['N']*(float(F(src['W'])/min(F(p) for p in src['weights'])) if proposal=='global' else (2 if proposal=='mixed' else 1))
    assert np.all(np.isfinite(score)) and float(np.max(score))<=bound*(1+1e-12)
    def saved(i):
        return dict(receiver=x[i].tolist(),score=float(score[i]),log_M_over_H=float(lm[i]),qcore=float(q[i]),energycore=float(energy[i]),selected_center=int(center[i]),radial_inner=bool(inner[i]),individual_mass_branch=bool(mass_branch[i]),U=float(U[i]),face=int(face[i]),sign=int(sign[i]))
    borders=[]
    for accepted in [True,False]:
        ids=np.flatnonzero((lm<=0)==accepted)
        if len(ids):borders.append(dict(accepted=accepted,**saved(ids[np.argmin(np.abs(lm[ids]))])))
    top=[saved(i) for i in np.argsort(score)[-3:][::-1]]
    sm=float(score.sum());ss=float(score@score);k=max(1,S//100)
    return dict(source=src,H=str(F(H)),stage=stage,proposal=proposal,seed=seed,samples=S,cap_hits=int(np.sum(lm<=0)),mean=float(score.mean()),sample_SE=float(score.std(ddof=1)/math.sqrt(S)),source_diagonal_mean=float(dscore.mean()),source_diagonal_SE=float(dscore.std(ddof=1)/math.sqrt(S)),energy_ESS=sm*sm/ss if ss else 0,top_one_percent_fraction=float(np.sort(score)[-k:].sum()/sm) if sm else 0,max_score=float(score.max()),score_bound=bound,formal_Hoeffding95_radius=bound*math.sqrt(math.log(40)/(2*S)),min_abs_log_M=float(np.min(abs(lm))),extremes=top,closest_gate_receivers=borders)


def decimal_point(src,H,x,precision,energy=True,proposal="global"):
    with localcontext() as ctx:
        ctx.prec=precision
        W=D(F(src['W']).numerator)/D(F(src['W']).denominator);h=D(F(H).numerator)/D(F(H).denominator);V=W/h
        a=[D(F(p).numerator)/D(F(p).denominator)/W for p in src['weights']]
        vols=[(2*max(abs(D.from_float(z)-D.from_float(t)) for z,t in zip(x,y)))**src['n']/V for y in src['coords']]
        groups={}
        for v,p in zip(vols,a):groups[v]=groups.get(v,D(0))+p
        vp=sorted(groups.items());cum=D(0);M=D(0)
        for v,p in vp:cum+=p;M=max(M,cum/v)
        qglobal=sum(p*(D('.5') if v<=1 else D('.5')/v**2) for v,p in zip(vols,a));qmass=sum(D('.5') if v<=p else D('.5')*p*p/v**2 for v,p in zip(vols,a))
        q=qglobal if proposal=='global' else qmass if proposal=='mass' else (qglobal+qmass)/2
        out=dict(M=str(M),qcore=str(q),cap=M<=1,arrival_groups=len(vp))
        if energy:
            e=D(1).exp();ih=1/e;c=1-ih;gram=D(0)
            for v,p in vp:
                for w,t in vp:
                    small,big=min(v,w),max(v,w);rho=big/small
                    kernel=(2-ih-ih*rho*rho)/(2*big*big) if rho<=e else -c*c/(2*ih*big*big)
                    gram+=p*t*kernel
            events={}
            for v,p in vp:
                events[v/e]=events.get(v/e,D(0))+p/e;events[v]=events.get(v,D(0))-p
            ordered=sorted(events);coef=D(0);event=D(0)
            for i,v in enumerate(ordered):
                coef+=events[v]
                event+=coef**2/2*(v**-2-(ordered[i+1]**-2 if i+1<len(ordered) else 0))
            out.update(gram=str(gram),event=str(event),gram_event_relative=str(abs(gram-event)/max(abs(gram),D('1e-1000'))))
        return out


def guards(rows):
    gates=[]
    for row in rows:
        for p in row['closest_gate_receivers']:
            lo=decimal_point(row['source'],row['H'],p['receiver'],80,False,row['proposal']);hi=decimal_point(row['source'],row['H'],p['receiver'],120,False,row['proposal'])
            assert lo['cap']==hi['cap']==p['accepted']
            gates.append(dict(stage=row['stage'],family=row['source']['family'],n=row['source']['n'],N=row['source']['N'],seed=row['seed'],receiver=p['receiver'],float_log_M=p['log_M_over_H'],decimal80=lo,decimal120=hi))
    checks=[]
    # Three largest score receivers in each dimension, all drawn from final rows.
    for n,proposal in sorted(set((r['source']['n'],r['proposal']) for r in rows)):
        choices=sorted([(p['score'],r,p) for r in rows if r['source']['n']==n and r['proposal']==proposal for p in r['extremes']],key=lambda t:t[0],reverse=True)[:3]
        for _,r,p in choices:
            lo=decimal_point(r['source'],r['H'],p['receiver'],80,proposal=r['proposal']);hi=decimal_point(r['source'],r['H'],p['receiver'],120,proposal=r['proposal'])
            target=float(hi['gram']);q=float(hi['qcore'])
            err=abs(p['energycore']-target)/max(abs(target),1e-300)
            assert err<1e-9 and float(hi['gram_event_relative'])<1e-70
            checks.append(dict(proposal=r['proposal'],n=n,N=r['source']['N'],family=r['source']['family'],seed=r['seed'],H=r['H'],receiver=p['receiver'],float_energy_relative_error=err,float_q_relative_error=abs(p['qcore']-q)/q,precision_energy_relative_error=str(abs(D(lo['gram'])-D(hi['gram']))/abs(D(hi['gram']))),decimal80=lo,decimal120=hi))
    # Actual positive-volume ties and asymmetric unequal masses.
    ties=[]
    for n in [1,2,4,8,16]:
        s=source('single',n,1)
        for H in [F(1),F(7,3)]:
            x=np.array([[3.]*n,[.25+.6*(3/float(H))**(1/n)]*n])
            lm,q,en,_=point_batch(x,s,H)
            for j in range(len(x)):
                z=decimal_point(s,H,x[j].tolist(),120)
                exact=C/float((2*max(abs(t-.25) for t in x[j]))**n/(3/float(H)))**2
                assert abs(en[j]-exact)<1e-12*max(1,exact)
                ties.append(dict(n=n,H=str(H),kind='one_atom_point',actual=float(en[j]),analytic=exact))
    s=dict(family='common_face_tie',n=2,N_requested=2,N_labels=2,N=2,coords=[[-.25,0.],[.25,0.]],weights=['1/3','2/3'],W='1')
    for x in [[0.,2.],[.125,2.],[0.,.5]]:
        lm,q,en,_=point_batch(np.array([x]),s,1);z=decimal_point(s,1,x,120)
        assert z['arrival_groups']==1
        if z['cap']:assert abs(en[0]-float(z['gram']))<1e-14
        ties.append(dict(kind='actual_tied_face',receiver=x,decimal120=z,float_energy=float(en[0])))
    return dict(gate_checks=gates,extreme_energy_Gram_checks=checks,one_atom_and_true_tie_checks=ties)



def packed(coords,weights,family,N_requested=None):
    coords=np.array(coords,float)
    size=float(np.max(abs(coords)))
    if size>0:coords=coords/size
    raw=np.maximum(np.array(weights,float),1e-12);raw=raw/raw.sum()
    integers=np.maximum(1,np.rint(raw*(2**20)).astype(np.int64));weights=[F(int(k),int(integers.sum())) for k in integers]
    merged={}
    for y,p in zip(coords,weights):merged[tuple(float(t) for t in y)]=merged.get(tuple(float(t) for t in y),F(0))+p
    return dict(family=family,n=coords.shape[1],N_requested=N_requested or len(coords),N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W='1')


def initial_geometry(kind,n,N,rng):
    if kind=='diagonal':y=np.array([[(2*j+1-N)/N]*n for j in range(N)])
    elif kind=='cloud':y=rng.uniform(-1,1,size=(N,n))
    elif kind=='binary_subset':
        if N<=2**n:
            ids=rng.choice(2**n,N,replace=False);y=np.array([[1. if (int(j)>>k)&1 else -1. for k in range(n)] for j in ids])
        else:
            y=rng.choice([-1.,1.],size=(N,n))+rng.normal(0,.07,size=(N,n))
    elif kind=='nested':y=np.array([[0.]*n]+[[2.**(-j)]*n for j in range(1,N)])
    elif kind=='multi_cluster':
        clusters=min(N,4);centers=rng.uniform(-1,1,size=(clusters,n))
        levels=np.array([2.**(-(j%8)-5) for j in range(N)])
        y=centers[np.arange(N)%clusters]+levels[:,None]*rng.uniform(-1,1,size=(N,n))
    elif kind=='coordinate_slabs':
        y=np.zeros((N,n));y[:,0]=np.linspace(-1,1,N)
        for k in range(1,n):y[:,k]=np.where((np.arange(N)//(k+1))%2,1.,-1.)
    else:raise ValueError(kind)
    return packed(y,np.ones(N),kind,N)


def mutate(src,H,rng,step):
    y,a=arrays(src);mode=step%4
    if mode==0:
        noise=rng.normal(size=y.shape);noise-=noise.mean(axis=0)
        y+=rng.choice([.01,.03,.1,.3])*noise
        operation='zero_mean_coordinate_perturbation'
    elif mode==1:
        j=int(rng.integers(len(y)));y[j]+=rng.normal(0,rng.choice([.03,.15,.5]),size=src['n'])
        operation='one_atom_displacement'
    elif mode==2:
        loga=np.log(a)+rng.normal(0,rng.choice([.2,.5,1.]),size=len(a))
        loga-=loga.max();a=np.exp(np.clip(loga,-16,0));operation='positive_mass_redistribution'
    else:operation='threshold_change'
    log2H=math.log2(float(F(H)))+float(rng.normal(0,src['n']*(.1 if step%8<4 else .35)))
    log2H=min(4*src['n'],max(-4*src['n'],log2H))
    return packed(y,a,'adversarial',src['N_requested']),str(F.from_float(2.**log2H)),operation


def short(row,candidate,parent,operation):
    return dict(candidate=candidate,parent=parent,operation=operation,source_hash=hashlib.sha256(json.dumps(row['source'],sort_keys=True).encode()).hexdigest(),H=row['H'],mean=row['mean'],sample_SE=row['sample_SE'],selection_score=row['mean']-row['sample_SE'],max_score=row['max_score'],cap_hits=row['cap_hits'],actual_N=row['source']['N'],samples=row['samples'],seed=row['seed'])


def search(n,N,steps=64,S=512):
    rng=np.random.default_rng(650013+1009*n+37*N);receiver_seed=651000+1000*n+N
    pool=[];trace=[];initial=[]
    kinds=['diagonal','cloud','binary_subset','nested','multi_cluster','coordinate_slabs']
    for kind in kinds:
        src=initial_geometry(kind,n,N,rng)
        for exponent in [-3,-2,-1,0,1,2]:
            H=F(2)**(exponent*n);row=probe(src,H,S,receiver_seed,'selection','mixed')
            row['candidate']=len(pool);pool.append(row);initial.append(row['candidate'])
            trace.append(short(row,row['candidate'],None,'initial_'+kind))
    for step in range(steps):
        leaders=sorted(pool,key=lambda r:r['mean']-r['sample_SE'],reverse=True)[:4]
        parent=leaders[step%len(leaders)]
        src,H,operation=mutate(parent['source'],parent['H'],rng,step)
        row=probe(src,H,S,receiver_seed,'selection','mixed');row['candidate']=len(pool);pool.append(row)
        trace.append(short(row,row['candidate'],parent['candidate'],operation))
    raw=max(pool,key=lambda r:r['mean']);penalized=max(pool,key=lambda r:r['mean']-r['sample_SE']);control=max((pool[i] for i in initial),key=lambda r:r['mean']-r['sample_SE'])
    selected=[]
    for role,row in [('raw_mean_winner',raw),('mean_minus_SE_winner',penalized),('matched_initial_control',control)]:
        selected.append(dict(role=role,candidate=row['candidate'],selection_mean=row['mean'],selection_SE=row['sample_SE'],source=row['source'],H=row['H']))
    return dict(n=n,N_requested=N,selection_samples=S,mutation_steps=steps,proposal='mixed',receiver_seed=receiver_seed,parameter_seed=650013+1009*n+37*N,trace=trace,selected=selected)



def split_batch(x,src,H):
    lm,q,total,diag=point_batch(x,src,H,'mixed');cap=lm<=0
    post=np.zeros(len(x));logstop=np.zeros(len(x));largest_positive_post_coefficient=0.
    if np.any(cap):
        y,a=arrays(src);V=float(F(src['W'])/F(H))
        L=src['n']*np.log(2*np.max(abs(x[cap,None,:]-y[None,:,:]),axis=2))-math.log(V)
        order=np.argsort(L,axis=1,kind='stable');sortedL=np.take_along_axis(L,order,axis=1)
        # Rational integer masses make the majority threshold exact even at equality.
        masses=[F(p)/F(src['W']) for p in src['weights']];den=math.lcm(*(p.denominator for p in masses))
        assert den<2**60
        integers=np.array([p.numerator*(den//p.denominator) for p in masses],dtype=np.int64)
        cumulative=np.cumsum(integers[order],axis=1)
        stop=sortedL[np.arange(len(L)),np.argmax(4*cumulative>=3*den,axis=1)];logstop[cap]=stop
        ev=np.concatenate([L-1,L],axis=1);change=np.broadcast_to(np.concatenate([a/math.e,-a]),ev.shape)
        order=np.argsort(ev,axis=1,kind='stable');ev=np.take_along_axis(ev,order,axis=1)
        coef=np.cumsum(np.take_along_axis(change,order,axis=1),axis=1)
        left=np.maximum(ev[:,:-1],stop[:,None]);right=ev[:,1:];active=right>left
        factors=np.where(active,-np.expm1(2*np.minimum(left-right,0)),0)
        post[cap]=np.sum((coef[:,:-1]*np.exp(-left))**2*factors/2,axis=1)+(coef[:,-1]*np.exp(-np.maximum(ev[:,-1],stop)))**2/2
        if np.any(active):largest_positive_post_coefficient=max(0.,float(np.max(coef[:,:-1][active])))
        assert largest_positive_post_coefficient<1e-12
        assert np.min(stop)>=math.log(.75)-1e-12
        assert np.all(post[cap]<=C*C*np.exp(-2*stop)/2+1e-12)
    early=total-post
    assert np.min(early)>-1e-12
    return lm,q,total,post,early,logstop,largest_positive_post_coefficient


def decimal_split(src,H,x,precision):
    with localcontext() as ctx:
        ctx.prec=precision
        wf=F(src['W']);hf=F(H);V=D(wf.numerator)/D(wf.denominator)/(D(hf.numerator)/D(hf.denominator))
        weights=[F(p)/wf for p in src['weights']]
        vp=sorted([((2*max(abs(D.from_float(z)-D.from_float(t)) for z,t in zip(x,y)))**src['n']/V,p) for y,p in zip(src['coords'],weights)])
        cumulative=F(0);stop=None
        for v,p in vp:
            cumulative+=p
            if cumulative>=F(3,4):stop=v;break
        e=D(1).exp();c=1-1/e;events={}
        for v,p in vp:
            a=D(p.numerator)/D(p.denominator)
            events[v/e]=events.get(v/e,D(0))+a/e;events[v]=events.get(v,D(0))-a
        ordered=sorted(events);coef=D(0);total=D(0);post=D(0)
        for i,v in enumerate(ordered):
            coef+=events[v];right=ordered[i+1] if i+1<len(ordered) else None
            total+=coef**2/2*(v**-2-(right**-2 if right else 0))
            left=max(v,stop)
            if right is None or right>left:
                assert coef<=D(10)**(-precision+10)
                post+=coef**2/2*(left**-2-(right**-2 if right else 0))
        assert post<=c*c/(2*stop*stop)+D(10)**(-precision+10)
        return dict(total=str(total),post=str(post),early=str(total-post),stop_volume_normalized=str(stop),point_post_envelope=str(c*c/(2*stop*stop)))


def paid_branch_split(rows):
    chosen=[]
    for r in rows:
        n,N=r['source']['n'],r['source']['N_requested']
        if (n,N)==(1,64) and r['stage']=='crossed_followup' and r['role']=='matched_initial_control' and r['threshold_role']=='matched_initial_control':chosen.append(r)
        if (n,N)==(4,16) and r['stage']=='crossed_followup' and r['threshold_role']=='mean_minus_SE_winner':chosen.append(r)
        if (n,N)==(16,64) and r['stage']=='heldout' and r['role']=='raw_mean_winner':chosen.append(r)
    result=[]
    for r in chosen:
        x,*_=draw(r['source'],r['H'],r['samples'],r['seed'],'mixed')
        batches=[split_batch(x[j:j+512],r['source'],r['H']) for j in range(0,len(x),512)]
        lm,q,total,post,early,stop=[np.concatenate([b[k] for b in batches]) for k in range(6)]
        ts,ps,es=total/q,post/q,early/q
        assert abs(float(ts.mean())-r['mean'])<1e-13
        i=int(np.argmax(ps));lo=decimal_split(r['source'],r['H'],x[i].tolist(),80);hi=decimal_split(r['source'],r['H'],x[i].tolist(),120)
        rel=abs(float(hi['post'])-post[i])/max(float(hi['post']),1e-300);assert rel<1e-9
        result.append(dict(n=r['source']['n'],N=r['source']['N'],source=r['source'],H=r['H'],role=r['role'],seed=r['seed'],receivers_reused=r['samples'],total_mean=float(ts.mean()),total_SE=float(ts.std(ddof=1)/math.sqrt(len(x))),post_mean=float(ps.mean()),post_SE=float(ps.std(ddof=1)/math.sqrt(len(x))),early_mean=float(es.mean()),early_SE=float(es.std(ddof=1)/math.sqrt(len(x))),max_point_decomposition_error=float(np.max(abs(ts-ps-es))),max_positive_post_coefficient=max(b[6] for b in batches),paid_post_analytic_budget=C*C/.75,max_post_score=float(ps[i]),max_post_receiver=x[i].tolist(),max_post_energy_relative_error=rel,decimal80=lo,decimal120=hi))
    return dict(theta='3/4',definition='Post integrates u>=log of first actual capture volume with cumulative mass>=3W/4, including full ties. Early is the complementary signed-squared time integral.',sampling='Same registered heldout receivers regenerated, no new receiver draws or independent estimates. Total/early/post are dependent paired scores; each SE is reported separately.',scope='Parent proved post budget c^2HW/theta; displayed normalized reference is analytic, not inferred from MC. The early branch remains unpaid. Decimal checks are nearest arithmetic, not interval certification.',rows=result)

def main(pilot=False):
    start=time.monotonic()
    configs=[(n,N) for n in [1,2,4,8,16] for N in [4,16,64]]
    if pilot:configs=[(1,4),(2,16),(8,16),(16,64)]
    searches=[]
    for n,N in configs:
        s=search(n,N,steps=24 if pilot else 64,S=512);searches.append(s)
        print(json.dumps(dict(progress='search',n=n,N=N,winners=[(r['role'],r['selection_mean'],r['selection_SE'],r['H']) for r in s['selected']])),flush=True)
    rows=[]
    if not pilot:
        for configindex,s in enumerate(searches):
            for roleindex,r in enumerate(s['selected']):
                for rep in [0,1]:
                    row=probe(r['source'],r['H'],8192,6600000+10000*configindex+100*roleindex+rep,'heldout','mixed')
                    row.update(role=r['role'],candidate=r['candidate'],selection_mean=r['selection_mean'],selection_SE=r['selection_SE']);rows.append(row)
        # Independent crossed position/threshold followup after the first heldout stage.
        for configindex,(n,N) in enumerate([(1,64),(4,16)]):
            cfg=next(t for t in searches if t['n']==n and t['N_requested']==N)
            winner=cfg['selected'][1];control=cfg['selected'][2]
            for sourceindex,r in enumerate([winner,control]):
                for thresholdindex,t in enumerate([winner,control]):
                    for rep in [0,1]:
                        row=probe(r['source'],t['H'],32768,6800000+10000*configindex+1000*sourceindex+100*thresholdindex+rep,'crossed_followup','mixed')
                        row.update(role=r['role'],candidate=r['candidate'],threshold_role=t['role'],selection_mean=r['selection_mean'],selection_SE=r['selection_SE']);rows.append(row)
        g=guards(rows)
        paid=paid_branch_split(rows)
    else:g={};paid={}
    result=dict(round=65,status='PILOT' if pilot else 'PASS',numpy_version=np.__version__,counts=dict(configurations=len(searches),selection_candidates=sum(len(s['trace']) for s in searches),selection_receivers=sum(sum(t['samples'] for t in s['trace']) for s in searches),heldout_rows=len(rows),heldout_receivers=sum(r['samples'] for r in rows),closest_gate_checks=len(g.get('gate_checks',[])),extreme_Gram_checks=len(g.get('extreme_energy_Gram_checks',[])),paid_split_rows=len(paid.get('rows',[])),paid_receivers_reused=sum(r['receivers_reused'] for r in paid.get('rows',[]))),proposal=dict(component='q_B(v)=1/(2B) for v<=B, B/(2v^2) otherwise; each integrates1',mixture='Source center i chosen with p_i/W, B=W/H or p_i/H with equal probability; density evaluated as COMPLETE .5 global + .5 individual source-center mixture.',normalized_density='qcore=.25sum_i a_i min(1,tau_i^-2)+.25sum_i min(1,(a_i/tau_i)^2); q=(H/W)qcore',score_envelope='4(1-exp(-1))*actual_N on the true cap; global alone2cN W/pmin; individual alone2cN'),selection=dict(objective='Active search accepts leaders ranked mean minus sampleSE; also retains raw mean winner and best initial control. This penalty is heuristic, not a confidence bound.',variables='Actual atom coordinates, strictly positive rational masses, H. Every mutation also changes H. Coordinates normalized to maxabs1, log2H within[-4n,4n], mass integer weights floor1 at resolution2^20.',randomness='Common receiver seed within each configuration search; candidates therefore share samples. Independent heldout seeds for every role and replicate; no search scores pooled into heldout mean.',limits='Finite stochastic parameter search; no global optimization certificate and no guarantee of finding worst sources. Candidate winners and controls may coincide, intentionally retained with separate fresh heldout seeds. Two configurations(n1N64,n4N16) were selected after first heldout inspection for fresh crossed source/threshold followup; those rows are retained separately, without pooling.'),scope=dict(space='Full-space Lebesgue receiver proposal, no box cutoff.',time='Full signed time event integral including infinite final tail; true tied arrival batches.',source='All sources positive; zero-mean perturbation describes coordinate displacement only, never a signed source.',arithmetic='Float geometry and transforms, Decimal80/120 nearest arithmetic on retained gates/extremes, not interval certification.',confidence='Sample SE diagnostic; formal per-row95 Hoeffding radius Bsqrt(log40/(2S)) for independent ideal continuous scores. Selection scores do not satisfy independent heldout inference.',interpretation='n and requestedN vary independently; actual mergedN recorded. No exponent fit, general energy theorem, or large-energy weak counterexample.'),searches=searches,rows=rows,guards=g,paid_branch_split=paid)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(runtime_seconds=time.monotonic()-start,counts=result['counts'],largest_heldout=sorted([(r['mean'],r['sample_SE'],r['source']['n'],r['source']['N'],r['role']) for r in rows],reverse=True)[:8])),flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');main(parser.parse_args().pilot)
