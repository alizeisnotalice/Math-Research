#!/usr/bin/env python3
"""Finite joint ordered-stop diagnostic; actual source/cubes, counting receiver labels."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def fixture(stage,widths,N):
 before=sum(COUNTS.values());M=len(widths)-1;sigma=F(2,5);theta=F(1,4);R=F(2);An=F(2);s=N*An*sigma;W=F(len(widths));atoms=[]
 for j,h in enumerate(widths):
  cuts=sorted(set([j-h,j+h]+[x for x in [F(j)-F(1,10),F(j)+F(1,10)] if j-h<x<j+h]))
  for lo,hi in zip(cuts,cuts[1:]):atoms.append((j,lo,hi,(hi-lo)/(2*h)))
 def cap(i,a):return a[0] in [i,i+1]
 def inner(i,a):
  _,lo,hi,_=a;left=F(i)+F(1,2)-sigma;right=F(i)+F(1,2)+sigma
  hit=lo>=left and hi<=right;outside=hi<=left or lo>=right
  ck('exact_source_atom_inner_geometry',hit or outside)
  return hit
 incid=[[cap(i,a) for a in atoms] for i in range(M)]
 ins=[[inner(i,a) for a in atoms] for i in range(M)]
 for i in range(M):
  for j,h in enumerate(widths):
   left=F(i)-F(1,2);right=F(i)+F(3,2);full=F(j)-h>=left and F(j)+h<=right;outside=F(j)+h<=left or F(j)-h>=right
   ck('actual_full_cube_packet_capture',full==(j in [i,i+1]) and (full or outside))
  ck('actual_full_source_q1',sum(a[3] for a,hit in zip(atoms,incid[i]) if hit)==R)
 p=[sum((a[3]/R for k,a in enumerate(atoms) if ins[i][k]),F(0)) for i in range(M)]
 b=[F(1) if x>=theta else x for x in p]
 for x,z in zip(p,b):
  ck('merged_rich_inner_stop_probability',z==(1 if x>=theta else x))
  ck('merged_stop_paid_once_by_p_over_theta',z<=x/theta)
  if x==theta:ck('theta_equality_is_rich_first',z==1)
  if x<theta:ck('remaining_receiver_posterior_shell_strict',1-x>1-theta)
 # Original finite-label kernel before all stop filters: source-conditioned neighbour plus 1/2 terminal.
 P=[[F(0) for _ in range(M)] for _ in range(M)]
 for i in range(M):
  for k,a in enumerate(atoms):
   if not incid[i][k]:continue
   nxt=i-1 if a[0]==i else i+1
   if 0<=nxt<M:P[i][nxt]+=a[3]/R/2
 for j in range(M):ck('diagnostic_counting_reference_subinvariant',sum(P[i][j] for i in range(M))<=1)
 # Discrete source-column envelope is checked on every complete positive source atom, not point probes.
 for k,a in enumerate(atoms):ck('finite_label_inner_column_capacity',sum(F(ins[i][k])/R for i in range(M))<=sigma*An)
 init=[F(1) if i%2==0 else F(1,2) for i in range(M)];states=[(i,tuple([i-1]) if i else tuple(),init[i]) for i in range(M)];totals=Counter();generations=[];priority_overlap=F(0);summed_inner_expectation=F(0)
 for depth in range(N):
  incoming=[F(0)]*M
  for i,hist,weight in states:incoming[i]+=weight
  for i,v in enumerate(incoming):ck('actual_joint_generation_marginal_counting_cap',v<=1)
  outgoing=[];g=Counter();expectedstop=sum((incoming[i]*b[i] for i in range(M)),F(0));posteriorinner=sum((incoming[i]*p[i] for i in range(M)),F(0))
  for i,hist,weight in states:
   if p[i]>=theta:
    g['rich']+=weight
    # A rich row would also have inner source mass; it must never be counted a second time.
    ck('rich_before_source_sampling_not_double_charged',b[i]==1)
    continue
   local=F(0)
   for k,a in enumerate(atoms):
    if not incid[i][k]:continue
    prob=a[3]/R;mass=weight*prob;local+=prob
    oldhit=any(incid[v][k] for v in hist)
    if ins[i][k]:
     g['inner']+=mass
     if oldhit:priority_overlap+=mass
     continue
    ck('remaining_draw_actual_contracted_shell',not ins[i][k])
    if oldhit:g['ancestor']+=mass;continue
    nxt=i-1 if a[0]==i else i+1
    if not 0<=nxt<M:g['Q_terminal']+=mass;continue
    g['Q_terminal']+=mass/2
    if depth+1==N:g['horizon_terminal']+=mass/2
    else:outgoing.append((nxt,hist+(i,),mass/2));g['continue']+=mass/2
   ck('actual_full_pi_source_draw_conserves',local==1)
  summed_inner_expectation+=posteriorinner
  ck('generation_inner_expectation_source_column_budget',posteriorinner<=sigma*An*W)
  ck('joint_generation_ordered_branches_conserve',sum(g.values())==sum(incoming))
  ck('rich_and_inner_exact_merged_expectation',g['rich']+g['inner']==expectedstop)
  ck('merged_stop_expectation_bound',expectedstop<=posteriorinner/theta)
  for key,val in g.items():
   if key!='continue':totals[key]+=val
  generations.append(dict(depth=depth,incoming=list(map(str,incoming)),branches={k:str(v) for k,v in g.items()},merged_rich_inner=str(expectedstop)))
  states=outgoing
 ck('full_first_stop_distribution_conserves',sum(totals.values())==sum(init))
 ck('no_unsettled_path_after_horizon',not states)
 ck('merged_expectation_summed_once',totals['rich']+totals['inner']<=summed_inner_expectation/theta<=N*sigma*An*W/theta)
 ck('global_merged_4sW_finite_label_analogue',totals['rich']+totals['inner']<=s*W/theta==4*s*W)
 return dict(stage=stage,receiver_labels=M,maximum_draws=N,widths=list(map(str,widths)),source='packets [j-h_j,j+h_j] mass1, actual density1/(2h_j)',actual_R='2',actual_q='1',sigma=str(sigma),theta=str(theta),p_inner=list(map(str,p)),rich_equality_labels=[i for i,x in enumerate(p) if x==theta],source_W=str(W),discrete_column_An=str(An),s_for_sigma_budget=str(s),combined_budget_4sW=str(4*s*W),first_stop_mass={k:str(v) for k,v in totals.items()},initial_mass=str(sum(init)),inner_and_ancestor_overlap_assigned_only_inner=str(priority_overlap),generations=generations,exact_checks=sum(COUNTS.values())-before,scope='Actual positive-L1 source and actual cube endpoints; receiver labels use counting measure, NOT receiver dx. Continuation is source-dependent finite subkernel, not native rank/mass-growth Q. An=2 is explicitly verified discrete column cap, not the physical continuous An.')
def abstract_cap():
 before=sum(COUNTS.values());q=[F(1),F(2),F(3)];P=[[F(0),F(1,2),F(0)],[F(1,4),F(0),F(1,2)],[F(0),F(1,4),F(0)]];v=[F(1),F(1,2),F(3)]
 for j in range(3):ck('separate_abstract_nonuniform_reference_subinvariant',sum(q[i]*P[i][j] for i in range(3))<=q[j])
 for depth in range(8):
  ck('separate_abstract_each_generation_cap',all(0<=v[i]<=q[i] for i in range(3)))
  v=[sum(v[i]*P[i][j] for i in range(3)) for j in range(3)]
 return dict(exact_checks=sum(COUNTS.values())-before,scope='Separate rational counting-kernel certificate only, not a cube receiver field.')
def main():
 models=[fixture('initial',[F(1,5),F(1,5),F(1,8),F(1,10)],2),fixture('boundary_stress',[F(1,5),F(1,5),F(1,5),F(1,8),F(1,10),F(1,5)],4),fixture('expanded',[F(6,25),F(6,25),F(1,8),F(1,10),F(1,8),F(1,5),F(1,10),F(1,8),F(1,5)],6)]
 absmodel=abstract_cap();out=dict(status='PASS',total_exact_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),models=models,abstract_subinvariance=absmodel,scope='Finite joint ordered stopping, exact actual source integrals and cube incidences; no true receiver dx or native full-history realization. Merged rich+inner is one stop probability and only one budget, 4sW finite-label analogue, not a proof of general payment.')
 (BASE/'r355_path_checks_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(COUNTS.values()),models=[{k:m[k] for k in ['stage','exact_checks','first_stop_mass','inner_and_ancestor_overlap_assigned_only_inner']} for m in models]),sort_keys=True))
if __name__=='__main__':main()
