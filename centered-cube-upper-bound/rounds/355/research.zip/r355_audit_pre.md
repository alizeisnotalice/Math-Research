# R355 independent preliminary audit — global radius-capacity obstruction

No R355 author proof was read. The object here is the actual hard inverse-cube capture field J_y=int_E c_u(y)du/(q_u R_u^n), with q_u>=q_->0 and a<=R_u<=b. It is not the general soft receiver intensity. No new B_H payment or general weak-type theorem is claimed.

## 1. Global finite menu: PASS, no source homogeneity needed

If the ACTUAL radii on E take values in one common global set {r_1,...,r_M}, partition E into disjoint E_j={R_u=r_j}. For every source location y,
 q_-J_y=int_E c_u(y)[q_-/q_u]R_u^{-n}du
 <=sum_j r_j^{-n}|E_j intersect Q_{r_j}(y)|<=M.
Only the actual receiver Lebesgue volume and lower q bound enter. Full-f matching, source periodicity, uniform source density, and upper q bound are not needed for this geometric inequality. An arbitrary nonuniform full f cannot evade it while the same hard field and common finite menu are retained.

The original strict high-past event is bounded by J_y and requires q_-J_y>(1+sqrt(n))/epsilon. Hence M>(1+sqrt(n))/epsilon is NECESSARY. Equality is also excluded because the original gate is strict. This is not a sufficient condition for realization, and no atom splitting or local source selection changes it.

M counts distinct radii in the global field, or bounds the size of a common available menu. It is NOT the number of alternatives at each individual receiver when those alternatives vary continuously with u. A private singleton R(u) can already produce an infinite global radius set. The finite-menu bound cannot be applied to that situation with M=1.

## 2. Actual radial support gives a sharper capacity

For any radius field in [a,b],
 q_-J_y<=int sup_{a<=r<=b} h_r(u-y)du=A_n=1+n log(b/a).
Thus both M and A_n bound the original column in a global finite-menu field.

More precisely, for sorted distinct common radii r_1<...<r_M the exact positive radial envelope has mass
 C_menu=1+sum_{j=1}^{M-1}[1-(r_j/r_{j+1})^n].
Indeed its central cube contributes one, and on the radial gap (r_j,r_{j+1}] the best available density is r_{j+1}^{-n}. Consequently C_menu<=min(M,A_n), and C_menu>(1+sqrt(n))/epsilon is a stronger necessary gate. This is a true receiver-center envelope, not a source density cap or an assumed upper bound on the target.

For a common radius support equal to a finite union of disjoint closed intervals [a_j,b_j], ordered with b_j<a_{j+1}, the exact envelope mass is
 C_union=1+sum_j n log(b_j/a_j)
           +sum_{j>=2}[1-(b_{j-1}/a_j)^n].
Merge overlapping intervals first. Degenerate intervals recover the discrete formula. The cruder union bound sum_j[1+n log(b_j/a_j)] is safe but may overcount. All quantities are capped again by the full [a,b] envelope. These formulas retain the actual widths and gaps; receiver-dependent radius jitter is not a free finite-menu operation.

## 3. Octave dimensions <=256: universally empty in this hard contract

Set x=sqrt(n), s=1+x, epsilon=119/3072. For b/a<=2,
 A_n<=1+n log2<1+n<=x(1+x)=xs,  x>=1.
If n<=256 then x<=16<1/epsilon. Hence A_n<s/epsilon and the original strict high-past event is empty, for ANY source f and ANY measurable hard radius selector in the octave, even a continuum of radii. This is not only a defect of the previous periodic/four-menu experiment. More generally nonempty original hard high-past requires A_n>s/epsilon, and in particular x>1/epsilon by the same coarse comparison. No optimized critical dimension is asserted here.

Changing source nonuniformity or adding more radii in dimensions <=256 does not resolve this obstruction under the same hard q-band and octave. A general soft field has a different receiver intensity and cannot be dismissed by this hard J calculation. Other scale ratios or thresholds require their own actual capacity test; this note does not alter any original threshold to construct a different easier input.

## 4. Random common menus and jitter: pathwise accounting

If one common random seed selects a finite global menu and a measurable hard field, the above inequality holds separately for each realized seed. Almost-sure M_seed<=s/epsilon implies the event is absent almost surely. A bound only on expected M does NOT imply emptiness; at most it gives an averaged capacity or a Markov tail estimate with all seed costs retained.

If each menu entry is jittered by one shared random offset per entry, the realized field still has at most M radii. If receivers independently choose offsets in fixed bands, the actual global support is generally continuous: use C_union with those bands, not M. If the bands or their union are random, all widths/gaps and any expectations must be charged for that actual seed. Choosing favorable different seeds privately per source does not produce a common original field or a free union of paid events.

These are necessary geometry constraints for experiment design. Passing them supplies no original high-past, low-pe, source-history, square, or rank qualification by itself.

## 5. Local executed evidence

A fresh Python Fraction process ran 473 exact checks: a rational exp(7/10)>2 certificate; all n=1,...,256 comparing 1+(7/10)n with (1+floor(sqrt(n)))/epsilon; 201 actual 1D column integrations for f=1 on [-5,5] and receivers [-2,2] with common radii 1,2 and q=1; and 15 discrete-envelope/count comparisons. The q=1 fixture lies in the band [1,4/3]. It tests the geometric column bound, not a positive original high-past field. These are auditor computations, separate from parent/author totals.

Status: PASS for the universal common-menu and octave necessary conditions, with the global/private-menu distinction and hard/soft limitation stated. No R355 author/main/ledger files have been reviewed yet. The practical decision is to preregister these necessary checks before attempting another numerical realization of the hard core.

## Second independently screened candidate: first rich-receiver stopping — PASS

This section was screened before reading any new author proof. Use the R353 remaining original marked input R (or a restriction thereof), with initial marginal <=q du, and the legal R352 fresh killed posterior/rank process. All original y/u/v/r/w_0 labels and fields remain frozen. Its per-generation live marginals obey kappa_j<=q and there are at most N source-draw opportunities.

Let s=1+sqrt(n), A=A_n and choose a SINGLE global shrink sigma_* in (0,1] by sigma_*^n=min(1,s/(NA)). Define the measurable fixed-field posterior test
 p_inner(w)=pi_w(sigma_* Q_w),  rich={p_inner>=theta},  0<theta<1.
At each visited current receiver, test rich BEFORE its next source draw. First visit to rich stops and pays the entire path. Otherwise draw from the genuine full-f pi_w, test the R352 ancestor recapture event, and use the same rank subkernel on the fresh part. No conditional posterior given later survival replaces pi_w. Additional stopping is a positive contraction, so each generation still has kappa_j<=q.

The entire hit mass at generation j is bounded by
 int_rich kappa_j <=theta^{-1}int kappa_j p_inner
 <=theta^{-1}int_E q_w pi_w(sigma_*Q_w)dw
 =theta^{-1}int f(z) int_E1_{z in sigma_*Q_w}R_w^{-n}dw dz
 <=theta^{-1}sigma_*^n A W.
The last bound is the already proved actual-center shrunk-cube envelope, not a source-density assumption. First-hit branches are disjoint. Summing at most N visits gives total rich-stopped mass <=N sigma_*^n A W/theta<=sW/theta. It is an actual whole-path branch payment, not merely a fractional source-sampling event. The factor N is explicitly prepaid by the chosen shrink; this is not a source-potential telescoping argument.

For theta=1/4 the new adopted price would be 4sW, with no receiver-X charge. It uses FULL W, because every new posterior uses full f. With the order above, R is exactly partitioned into first-rich stops, first ancestral recaptures that occur before a rich stop, and ordinary fresh/rank terminals. The old recapture bound applies once to its newly restricted branch; do not add a second whole-input recapture fee. If composing instead by a positive restriction of pre-existing complete paths, keep their original initial labels and justify the actual generation marginals before any conditioning on their future terminals.

Every receiver visited by a remaining ordinary terminal path has p_inner<theta and therefore full posterior mass >1-theta in Q_w minus sigma_*Q_w. This is a property of the full posterior at that receiver. It does NOT assert that every actual sampled source point on that path lies in the shell; filtering those source samples further would require another exact payment. Nor does it make the remaining source mass small or suppress cross-path occupation. The original R353 crossing gate remains attached only to INITIAL w_0, not to these later current receivers.

If sigma_*=1, every actual posterior has p_inner=1, so the first test stops all input and the remaining path family is empty. Otherwise its logarithmic side shrink is exactly log(NA/s)/n. Under the octave and q-band contract, N<=sqrt(n)+2 and A/s<=sqrt(n), so NA/s<=3n and -log(sigma_*)<=log(3n)/n. Thin geometric width is not an estimate of f-shell mass.

Executed a separate fresh Fraction process with 373 finite algebra/capacity-allocation cases: first-hit whole-mass inequalities, per-generation capacity under a nilpotent shift example, and N min(1,s/(NA)) A<=s. This does not realize a continuous hard high-past field or a native rank kernel and is not added to parent/author totals.

Second-candidate status: PASS as a new source-paid first-rich marked branch with its explicit N-dependent shrink and untouched complement. General root payment of the shell-concentrated fresh remainder remains unproved. Await frozen author/main/ledger/numeric files for final audit.

## Independent strengthened stopping screen: actual sources also outside the inner cube

The proposed richer order is valid: at a current receiver, first stop the whole rich row; otherwise draw from the TRUE full-f posterior, stop if that source lies in sigma_*Q_w; only then test first ancestral recapture, and finally apply Q on the surviving part. The new source-inner test is not renormalized, and all original marked fields stay fixed. All added killing remains a contraction, so the same per-generation kappa_j<=q and horizon N hold.

There is a sharper joint price than adding separate 4sW and sW estimates. For p=pi_w(sigma_*Q_w), the conditional rich-or-inner stop probability is
 b(p)=1_{p>=theta}+p1_{p<theta}<=p/theta.
Thus the two disjoint stopped categories TOGETHER cost at most (N/theta)sigma_*^n A W<=sW/theta=4sW for theta=1/4. The weaker separate total 5sW would also be valid, but is unnecessary. This is a joint capacity charge, not a cancellation or reused negative credit. Ancestor recapture is still charged only for its new remaining category, at its existing alpha_rec X_q price.

On remaining ordinary terminal paths, every visited receiver has full posterior mass >3/4 outside sigma_*Q_w, and every actual source drawn on that path (including the rank-terminal draw) is outside that inner cube. These are different statements and both now follow from the stated event order. Actual source draws also avoid ancestors on the fresh complement. None gives cross-path disjointness or a general occupation bound.

For nonzero original high-past entrance the existing proof gives N<=sqrt(n), not merely its unconditional O(sqrt(n)) bound. Together with A/s<=sqrt(n), this proves max(1,NA/s)<=n and -log(sigma_*)<=log(n)/n. Empty input is handled separately. This logarithmic shell width remains geometric information, not small source mass.

Executed 75 additional Fraction cases verifying the merged stop probability and exact stopped/surviving mass conservation, separate from all earlier counts and from parent/author results. Strengthened screen: PASS with the 4sW joint price; no new X fee and no general bound for the remaining shell/fresh occupation.
