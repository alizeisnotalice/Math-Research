R355 additional ordered-path stopping diagnostic

Frozen fresh local processes returned PASS 1,094 exact Fraction assertions: initial 103, threshold/priority stress 226, expanded 754, plus 11 separately classified abstract nonuniform-reference subinvariance checks. The earlier r355_numeric.py/result/md dimension certificate is unchanged.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r355_path_checks.py
```

This self-contained script writes r355_path_checks_result.json beside itself. It imports no other temporary scripts or data.

Actual source and cube component. At every integer j there is a uniform interval packet [j-h_j,j+h_j] of mass 1. The three fixtures have 4,6,9 packets, h_j in {1/10,1/8,1/5,6/25}. Every receiver label i is the actual interval cube of side R=2 centered at i+1/2. Exact endpoint inequalities verify it captures precisely packets i and i+1, so its actual full-source m=2,q=1. For sigma=2/5, all source packets are partitioned at the endpoints of every contracted cube. Every resulting positive source atom is entirely inside or outside every contracted cube; its exact probability uses the full-source posterior pi_i=f 1_Qi/2. No sample point replaces its source integral.

Receiver labels carry counting reference measure, not receiver Lebesgue dx. This distinction is essential: the script's verified source-column constant An_discrete=2 is not the physical continuous An. The figures below therefore test the finite counting-kernel counterpart of the accounting and event order, rather than certify a continuous 4sW theorem.

The exact path order is:

1. Compute p_i=pi_i(contracted cube). If p_i>=theta=1/4, stop the entire path as rich before sampling a new source.
2. Otherwise draw a source from the full pi_i. If it lies in the contracted cube, stop as inner.
3. If it lies in a previously visited receiver cube, stop as ancestor hit.
4. Otherwise use a source-dependent diagnostic continuation: move toward the sampled packet to the neighboring receiver with probability 1/2, or terminate normally. At an unavailable neighbor terminate normally. A surviving continuation at the prescribed final generation is recorded separately as horizon_terminal.

The finite initial history is the preceding receiver label where available. This is not a realization of the original complete u/v/y/r mark history. The continuation is not the native rank kernel and has no strict mass-growth claim. The imposed N=2,4,6 draw horizon is explicitly a finite diagnostic cap, not inferred from physical mass growth.

The unfiltered diagnostic transition has off-diagonal entries at most 1/4 and counting-reference column sums at most 1. With initial densities 1 or 1/2, the exact joint enumeration verifies every generation's receiver marginal is at most q=1. History-dependent stop filters are retained; choices are not treated as independent. A separate three-state abstract rational kernel verifies the same per-generation statement with reference q=(1,2,3), without calling that matrix a cube field.

Boundary, conservation, and new combined price. Some rows have p=theta exactly, and the expanded fixture has p>theta as well. Both are rich-first stops. For every row the combined rich/inner stop probability is

b(p)=1_{p>=theta}+p 1_{p<theta} <= p/theta.

The program checks this probability and its exact expectation, rather than charging a rich bound plus a separate inner bound. On the full source-atom partition it checks the discrete contracted column cap D_inner<=sigma An_discrete. Each generation consequently has sum incoming_i p_i <=sigma An_discrete W. Setting s=N An_discrete sigma matches sigma=min(1,s/(N An_discrete)) exactly here. Summing the already merged stops gives at most sW/theta=4sW, once. This is the checked finite-label analogue; it is not a true-dx certificate for the original An.

All first-stop categories plus terminal/horizon categories sum exactly to the original incoming mass (5/2,4,6 respectively). The rich+inner masses are 1829/1600, 11897/6400, and 1032859/614400. Priority matters: positive mass is simultaneously inner and ancestor-captured, namely 189/1600, 129/800, and 969551/3072000 in the three fixtures. It is assigned only to inner, with no duplicate ancestor charge. Every source draw retained after the inner-source stop lies outside the contracted cube, and every retained receiver has full-posterior shell probability strictly greater than 1-theta. Exact equality p=theta is never misclassified as a survivor.

The expanded fixture has a positive separately recorded horizon-terminal mass 2187/32768000; it is not relabeled as native-Q absorption or omitted from conservation. The result stores exact generation marginals and all first-stop totals, not only a scalar geometric-series bound.

Scope. This verifies joint-event ordering, boundary conventions, merged 4 rather than 5 accounting, source-dependent transitions, and per-generation caps in explicit finite models. It does not prove the general source-column envelope, implement the original native path kernel, establish original high-past/core qualification, or pay the remaining all-shell/no-ancestor occupation. Positive-L1 source geometry and finite receiver counting tests are explicitly separated from actual receiver dx.
