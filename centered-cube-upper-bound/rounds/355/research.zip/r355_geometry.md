# R355 — One root budget for first inner-rich visitation along the entire actual path

## Proved statement and its price

This note upgrades the actual inner-center capacity to a whole-path payment. It pays every path that first reaches a receiver whose true full-f posterior has a specified amount of mass in one common inner cube. The charge is root order and has no multiplicative generation count. The price is explicit: the common shrink factor is chosen with that generation count in advance. This is not a free source telescoping identity.

Write

    x=√n,  s=1+x,
    A_n=1+n log(b/a),
    N=max(1,ceil(log[(λ/q_-)(b/a)^n]/log K)),  K=e^x,
    σ_*^n=min(1,s/(N A_n)).                            (1)

For any fixed 0<θ<1, define the measurable receiver predicate

    rich(w) ⇔ π_w(σ_*Q_w)≥θ,
    π_w(dz)=f(z)1_{Q_w}(z)dz/m_w.                      (2)

Starting with the R353 crossing entrance R, perform the ordered path construction below. Its combined first-rich-or-inner stopping mass obeys

    B_rich+B_inner≤(s/θ)W.                           (3)

At θ=1/4 the combined whole-path payment costs 4(1+√n)W and no new receiver/X_q fee. The rich and inner-source stops use one joint estimate, rather than adding their separate coarse bounds. They concern the entire legal path, rather than only its initial witness.

The final remaining paths have, at every receiver they visit,

    π_w(σ_*Q_w)<1/4,
    π_w(Q_w\σ_*Q_w)>3/4.                             (4)

In the final remainder, every actually resampled source lies in Q_w\σ_*Q_w and also avoids the earlier ancestor cubes. The first property comes from the separately paid first-inner-source stop; it is not inferred from the posterior statement (4). The second comes from the existing recapture stop.

## 1. Original field and entrance marks remain unchanged

Keep the original arbitrary nonnegative f∈L¹, W=∫f, true centered cubes

    Q_w=w+[-R_w/2,R_w/2]^n,
    m_w=∫f1_{Q_w}=q_wR_w^n,
    q_-=3λ/4≤q_w≤λ,  a≤R_w≤b≤2a.

Let c_w=1_{Q_w}, ξ_z(dw)=q_wc_w(z)dw/m_w and σ(dw)=q_wdw. The symbol σ(dw) denotes this receiver measure; the scalar σ_* in (1) is the separate shrink factor.

The R350 complete noncyclic rank subkernel Q_z(u,dw) is frozen from the full original field and satisfies

    Q_z(u,E)≤1,
    surviving edges have c_u(z)c_w(z)=1 and m_w>Km_u,
    ∫ξ_z(du)Q_z(u,dw)≤ξ_z(dw).                        (5)

Its missing probability is an ordinary terminal outcome. It is not renormalized.

The entrance R is the R353 measure after the two paid disjoint masks (clock-near and old-source inner) are removed. Its initial witness w_0 retains every original mark, including

    (y_old,v_old,u_old,r_old,w_0),
    m_{w_0}>K m_{u_old}>K²m_{v_old},
    r_old<σ_353R_{w_0},  y_old∉σ_353Q_{w_0}.          (6)

Here σ_353 is the already chosen R353 shrink factor; it is not replaced by σ_*. The full J, ηΩ, old source g_ex, old physical clock with its terminal atom, high-past/outside/prefix and R351 core gates are unchanged. Its incoming w_0 density I is at most q_wdw, by restriction of the existing rank column. Later receivers are not declared to satisfy the old core or old Ω gates.

## 2. Precise step order and the terminal decomposition

At a current receiver w_j, with all previous marks retained, first test the deterministic predicate (2).

1. If w_j is rich, stop the whole current path and charge it to its first rich visitation.
2. If it is nonrich, sample z_j from the unchanged full-f probability π_{w_j}.
3. If z_j∈σ_*Q_{w_j}, stop and charge its first inner-source visit.
4. Otherwise, if z_j belongs to the ancestor union

       H_j=Q_{v_old}∪Q_{u_old}∪union_{i<j}Q_{w_i},

   stop and charge first ancestor recapture.
5. Otherwise apply Q_{z_j}(w_j,dw_{j+1}). Missing rank mass terminates the path normally; its surviving part continues with all old and new marks.

No source draw is conditioned on later rank success, a future no-recapture event, or a new posterior gate. The rich decision is made before that draw. No rejected probability is renormalized.

Each surviving jump raises mass by a strict factor K. Since all masses lie in [q_-a^n,λb^n], no path can have N surviving jumps. Thus there are at most N current-receiver checks, indexed j=0,...,N−1, including the receiver at normal termination. The complete nonnegative decomposition is

    R=B_rich+B_inner+B_rec,new+F_shell.               (7)

F_shell consists of normally terminated paths which never hit a rich receiver, never sampled an inner source, and never recaptured an ancestor. Equations (4) and (6) therefore hold, and every sampled z_j lies outside σ_*Q_{w_j} as well as outside the ancestor union.

## 3. Actual arrival domination, including first hits

Define the unconstrained receiver transition

    P(u,dw)=∫π_u(dz)Q_z(u,dw).

Using the same full f and (5), Tonelli gives

    ∫σ(du)P(u,dw)
       =∫f(z)∫ξ_z(du)Q_z(u,dw)dz
       ≤∫f(z)ξ_z(dw)dz
       =σ(dw).                                      (8)

The actual history-dependent process only deletes probability from this transition: it stops rich arrivals, stops inner sources and recaptured sources, and preserves the substochastic rank transition on the rest. Since its entrance I≤σ, induction shows that its actual arrival measure at every generation has density κ_j(w)≤q_w relative to the original Lebesgue dw.

Let h_j(w)dw be its first-rich hitting measure at generation j. Because the process already stops every earlier rich visit,

    h_j(w)=κ_j(w)1_{rich(w)},  0≤h_j≤q_w.              (9)

There is no claim that sum_j h_j≤q. Different generations and different paths can reach the same receiver. The generation count is explicitly budgeted below rather than erased.

At a rich arrival, the posterior in (2) gives

    θ∫h_j(w)dw≤∫h_j(w)π_w(σ_*Q_w)dw.                (10)

This inequality merely integrates the known posterior of a receiver already hit. Equivalently, one may append a genuine π_w draw as a probability-one certificate mark at the stopped receiver. That mark does not change the hit event, condition the posterior on success, or continue the original path.

## 4. Shared geometric budget with an explicit capacity allocation

For every fixed z and every 0<α≤1, the actual-center envelope from R353 is

    ∫_E 1_{z∈αQ_w}R_w^{-n}dw≤α^n A_n.               (11)

For completeness, with t=(2||w−z||∞)^n, contributing centers satisfy t≤α^nb^n and R_w^n≥max(a^n,t/α^n). Since the volume of {w:(2||w−z||∞)^n≤t} is exactly t, the envelope integral is

    ∫_0^{α^na^n}dt/a^n
      +∫_{α^na^n}^{α^nb^n}α^n dt/t
      =α^n[1+n log(b/a)].

This is an integral over actual receiver centers; it does not cap the mass of f in a boundary strip.

Use (9), q_w/m_w=R_w^{-n}, and (11) in the right side of (10):

    ∫h_j(w)π_w(σ_*Q_w)dw
      =∫f(z)∫h_j(w)1_{z∈σ_*Q_w}dw/m_w dz
      ≤σ_*^n A_n W.                                 (12)

To settle both disjoint stopping rules at once, put p(w)=π_w(σ_*Q_w). Their conditional combined stop probability at a current receiver is exactly

    b_θ(p)=1_{p≥θ}+p1_{p<θ}≤p/θ.                     (13a)

The first term is the rich stop before the draw. The second is the subsequent inner-source stop at a nonrich receiver. Because κ_j is the arrival density of this exact ordered process, including all earlier kills,

    B_rich,j+B_inner,j
       =∫κ_j(w)b_θ(p(w))dw
       ≤θ^{-1}∫κ_j(w)π_w(σ_*Q_w)dw
       ≤θ^{-1}σ_*^nA_nW.

The last step is the same actual-source Fubini estimate (12), now using κ_j≤q directly. Summing the at most N generations yields the single joint charge

    θ(B_rich+B_inner)≤Nσ_*^nA_nW≤sW.                 (13)

This proves (3). Rich and inner-source stops are disjoint because the rich decision occurs before any source draw. Ancestor recapture is tested only afterward. There is no posterior conditioning on source survival and no second charge for the same stop.

The argument includes the exact cost of sharing a source across generations and paths. We do not prove a generation-independent occupation domination; instead σ_* was chosen so the sum of all allowed geometric capacities is root order.

Keeping the larger R353 shrink factor at every generation would, by this argument, give Nσ_353^nA_nW/θ, which can be of order nW. That loss is not claimed to vanish. The explicitly smaller common inner cube in (1) is essential to the proved new bound.

## 5. The remaining boundary layer stays quantitatively thin

The exact relative inward displacement is

    −log σ_* = log(max(1,N A_n/s))/n.                 (14)

The elementary bounds N≤1+x log2+log(4/3)/x≤3x and A_n≤1+x² imply, for x≥1,

    N A_n/s≤3x(1+x²)/(1+x)≤3x²=3n.

Hence

    0≤1−σ_*≤−log σ_*≤log(3n)/n.                     (15)

On a nonempty original high-past entrance, the previously audited guard gives x>1/ε and N≤x. Together with A_n/s≤x this sharpens (15) to −log σ_*≤log n/n. The general bound log(3n)/n remains valid without that guard. The thickness at each coordinate face is at most R_w log(3n)/(2n), or R_w log n/(2n) under the nonempty original guard. Equation (15) is only a geometric width bound. It is not used to assert that the arbitrary f assigns little mass to this layer; indeed the remaining paths have the opposite posterior concentration (4).

The surviving conditions have distinct meanings:

- At the initial witness w_0, the old source and old time still satisfy the R353 crossing guard (6).
- At every visited receiver w_j, its original full-f posterior assigns more than 3/4 of its mass to Q_{w_j}\σ_*Q_{w_j}.
- Every actually sampled z_j lies in Q_{w_j}\σ_*Q_{w_j} and avoids the earlier ancestor union. The first-inner-source fee, rather than the posterior guard alone, establishes this sample-level conclusion.

No old-time condition is moved to w_j for j>0. No later full-f posterior is called an original qualified traffic row.

## 6. Recapture and ledger: reuse the old fee, do not stack it

On every nonrich surviving history, the next source draw before any source test is still exactly π_{w_j}. Restricting its recapture event by the preceding non-inner test only decreases its mass. The ancestor mass argument of R352 therefore remains valid:

    π_{w_j}(H_j)
       ≤[m_{v_old}+m_{u_old}+sum_{i<j}m_{w_i}]/m_{w_j}
       <1/(K−1).

There are at most N draws and total live mass is at most R. Consequently

    B_rec,new≤[N/(K−1)]R≤α_rec X_q,                  (16)

with the same already audited effective coefficient and original high-past dimension guard. Stopping rich paths and inner-source paths can only reduce this recapture mass. We never divide by the probability of passing the inner test.

Thus the correct replacement of the former R353 recapture decomposition is

    R≤F_shell+α_rec X_q+(s/θ)W.                      (17)

The old whole-R recapture bill is not added a second time. Combining with the two earlier R353 payments, at θ=1/4,

    G_core≤F_shell+(c_eff+α_rec)X_q+sW_ex+4sW.        (18)

Relative to the prior R353 ordered ledger, the only new fee is 4sW and there is zero new X_q fee. All existing external multipliers apply. The former fresh terminal remainder is replaced by the narrower F_shell through the explicitly reordered path construction (7), not by deleting its mass from the account.

The global cross-path terminal source charge for F_shell is still unproved. It has both the original crossing marks and the all-visited posterior boundary concentration, but these alone are not asserted to make source regions disjoint across paths. The general root goal remains open.

## 7. Executed exact checks

The following self-contained code was actually run using fractions.Fraction. It passed 450 exact uniform-capacity allocations and five finite first-hit/termination models. The models include N=1, equality at the posterior threshold (which belongs to the hit branch), conservation, and per-generation arrival caps. They are algebra diagnostics, not centered-cube realizations or tests of the original high-past gate.

```python
from fractions import Fraction as F
checks=0
for N in range(1,151):
 for A,s in [(F(10),F(3)),(F(2),F(5)),(F(21,2),F(7,2))]:
  power=min(F(1),s/(N*A))
  assert 0<power<=1 and N*A*power<=s
  if N*A<=s: assert power==1
  else: assert N*A*power==s
  checks+=1
for N in [1,2,4,8,16]:
 theta=F(1,4); post=[F(0)]*(N-1)+[theta]
 alive=[F(1)]*N; initial=sum(alive)
 totalhit=F(0); totalterm=F(0)
 for j in range(N):
  assert all(0<=v<=1 for v in alive)
  hits=[alive[i] if post[i]>=theta else F(0) for i in range(N)]
  assert theta*sum(hits)<=sum(hits[i]*post[i] for i in range(N))
  totalhit+=sum(hits)
  cont=[F(0)]*N
  for i in range(N):
   surviving=alive[i]-hits[i]
   if i+1<N: cont[i+1]+=surviving
   else: totalterm+=surviving
  assert sum(alive)==sum(hits)+sum(cont)+(alive[-1]-hits[-1])
  alive=cont
 assert not any(alive) and totalhit+totalterm==initial
 assert totalhit==N
print('PASS',checks,'exact uniform inner-capacity allocations;',
      '5 finite first-hit/terminal models including threshold equality and N=1')
```

The merged stopping price was separately checked in 303 exact rational cases, plus three equality cases p=θ. An ordered four-state model tests inner/ancestor overlap being charged to inner first, with total rich, inner, recapture and normal-terminal masses respectively 1417/4000, 369/2000, 369/2000 and 1107/4000, summing exactly to one. Its code was also actually run:

```python
from fractions import Fraction as F
count=0
for theta in [F(1,4),F(1,2),F(3,4)]:
 for k in range(101):
  p=F(k,100)
  b=F(1) if p>=theta else p
  assert b<=p/theta
  count+=1
for theta in [F(1,4),F(1,2),F(3,4)]:
 p=theta
 assert (F(1) if p>=theta else p)==1
N=4; theta=F(1,4)
arrivals=[F(1,4)]*N
rich=inner=rec=terminal=F(0)
for j in range(N):
 nxt=[F(0)]*N
 before=sum(arrivals); jr=ji=ja=jt=F(0)
 for i,a in enumerate(arrivals):
  p=F(1,2) if i==N-1 else F(1,5)
  if p>=theta: jr+=a; continue
  # Source categories: inner-only, inner+ancestor, ancestor-only, neither.
  # Their probabilities are 1/10, 1/10, 1/5, 3/5.
  ji+=a*F(1,5)
  ja+=a*F(1,5)
  fresh=a*F(3,5)
  if i+1<N:
   nxt[i+1]+=fresh/2; jt+=fresh/2
  else: jt+=fresh
 assert before==jr+ji+ja+jt+sum(nxt)
 rich+=jr; inner+=ji; rec+=ja; terminal+=jt; arrivals=nxt
assert not any(arrivals) and rich+inner+rec+terminal==1
print('PASS',count,'exact joint b(p) inequalities plus 3 threshold equalities;',
      'ordered rich/inner/recapture/terminal conservation:',
      rich,inner,rec,terminal)
```

Only /tmp/r355_geometry.md was authored. The proved joint whole-path payment is (3)/(13)/(18), with the explicit shrink-factor price (1), and not a claimed free source-potential cancellation.
