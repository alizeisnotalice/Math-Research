from fractions import Fraction as F
checks=0
for N in range(1,151):
 for A,s in [(F(10),F(3)),(F(2),F(5)),(F(21,2),F(7,2))]:
  power=min(F(1),s/(N*A))
  assert 0<power<=1 and N*A*power<=s
  if N*A<=s: assert power==1
  else: assert N*A*power==s
  checks+=1
for N in [1,2,4,8,16]:
 theta=F(1,4); post=[F(0)]*(N-1)+[theta]
 alive=[F(1)]*N; initial=sum(alive)
 totalhit=F(0); totalterm=F(0)
 for j in range(N):
  assert all(0<=v<=1 for v in alive)
  hits=[alive[i] if post[i]>=theta else F(0) for i in range(N)]
  assert theta*sum(hits)<=sum(hits[i]*post[i] for i in range(N))
  totalhit+=sum(hits)
  cont=[F(0)]*N
  for i in range(N):
   surviving=alive[i]-hits[i]
   if i+1<N: cont[i+1]+=surviving
   else: totalterm+=surviving
  assert sum(alive)==sum(hits)+sum(cont)+(alive[-1]-hits[-1])
  alive=cont
 assert not any(alive) and totalhit+totalterm==initial
 assert totalhit==N
print('PASS',checks,'exact uniform inner-capacity allocations;',
      '5 finite first-hit/terminal models including threshold equality and N=1')

from fractions import Fraction as F
count=0
for theta in [F(1,4),F(1,2),F(3,4)]:
 for k in range(101):
  p=F(k,100)
  b=F(1) if p>=theta else p
  assert b<=p/theta
  count+=1
for theta in [F(1,4),F(1,2),F(3,4)]:
 p=theta
 assert (F(1) if p>=theta else p)==1
N=4; theta=F(1,4)
arrivals=[F(1,4)]*N
rich=inner=rec=terminal=F(0)
for j in range(N):
 nxt=[F(0)]*N
 before=sum(arrivals); jr=ji=ja=jt=F(0)
 for i,a in enumerate(arrivals):
  p=F(1,2) if i==N-1 else F(1,5)
  if p>=theta: jr+=a; continue
  # Source categories: inner-only, inner+ancestor, ancestor-only, neither.
  # Their probabilities are 1/10, 1/10, 1/5, 3/5.
  ji+=a*F(1,5)
  ja+=a*F(1,5)
  fresh=a*F(3,5)
  if i+1<N:
   nxt[i+1]+=fresh/2; jt+=fresh/2
  else: jt+=fresh
 assert before==jr+ji+ja+jt+sum(nxt)
 rich+=jr; inner+=ji; rec+=ja; terminal+=jt; arrivals=nxt
assert not any(arrivals) and rich+inner+rec+terminal==1
print('PASS',count,'exact joint b(p) inequalities plus 3 threshold equalities;',
      'ordered rich/inner/recapture/terminal conservation:',
      rich,inner,rec,terminal)
