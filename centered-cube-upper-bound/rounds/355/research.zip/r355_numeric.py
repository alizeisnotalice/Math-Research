#!/usr/bin/env python3
"""Exact rational interval certificate for necessary octave and menu gates."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent;C=Counter();EPS=F(119,3072)
def ck(k,v):
 C[k]+=1
 assert v,k
def log2_bracket(N=100):
 z=F(1,3);lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0));rem=2*z**(2*N+1)/(F(2*N+1)*(1-z*z));hi=lo+rem
 ck('atanh_log2_positive_series_remainder',z>0 and z<1 and rem>0)
 return lo,hi
def sqrt_bracket(n,digits=60):
 den=10**digits;k=isqrt(n*den**2);lo=F(k,den);hi=lo if k*k==n*den**2 else F(k+1,den)
 ck('sqrt_rational_lower_upper_squared',lo*lo<=n<=hi*hi)
 ck('sqrt_bracket_exact_or_strict',lo==hi or lo*lo<n<hi*hi)
 return lo,hi
def row(n,loglo,loghi):
 sl,sh=sqrt_bracket(n);L=1+n*loglo;U=1+n*loghi;targetlo=(1+sl)/EPS;targethi=(1+sh)/EPS
 if L>targethi:sign='passes'
 elif U<=targetlo:sign='fails'
 else:raise AssertionError(('unresolved',n))
 ck('strict_gate_certified_without_float',L>targethi if sign=='passes' else U<=targetlo)
 return dict(n=n,status=sign,log_envelope_lower=str(L),log_envelope_upper=str(U),sqrt_lower=str(sl),sqrt_upper=str(sh),gate_rhs_lower=str(targetlo),gate_rhs_upper=str(targethi),certified_gap_lower=str(L-targethi),certified_gap_upper=str(U-targetlo))
def main():
 lo,hi=log2_bracket();rows=[];n=1
 while True:
  r=row(n,lo,hi);rows.append(r)
  if r['status']=='passes':break
  n+=1
  assert n<10000
 ck('minimum_positive_integer_full_predecessor_scan',all(x['status']=='fails' for x in rows[:-1]) and rows[-1]['status']=='passes')
 # Independent squaring certificate on the two adjacent integers; EPS(1+n log2)-1 > sqrt(n).
 independent=[]
 for r in rows[-2:]:
  m=r['n'];a=EPS*(1+m*lo)-1;b=EPS*(1+m*hi)-1
  ck('adjacent_squared_interval_positive',a>0)
  ck('independent_squared_neighbour_gate',a*a>m if r['status']=='passes' else b*b<=m)
  independent.append(dict(n=m,left_lower=str(a),left_upper=str(b),squared_lower_minus_n=str(a*a-m),squared_upper_minus_n=str(b*b-m)))
 menus=[]
 for m in [256,1024,2048,4096]:
  sl,sh=sqrt_bracket(m);a=(1+sl)/EPS;b=(1+sh)/EPS;floorlo=a.numerator//a.denominator;floorhi=b.numerator//b.denominator
  ck('menu_threshold_floor_certified',floorlo==floorhi)
  M=floorlo+1
  ck('strict_minimum_menu_necessary_integer',F(M)>b and F(M-1)<=a)
  menus.append(dict(n=m,sqrt_lower=str(sl),sqrt_upper=str(sh),threshold_lower=str(a),threshold_upper=str(b),minimum_integer_global_menu_count=M,octave_dimension_gate=row(m,lo,hi)['status']))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),epsilon=str(EPS),target_inequality='1+n log(2) > (1+sqrt(n))/epsilon',log2=dict(method='100 positive terms of 2 sum z^(2j+1)/(2j+1), z=1/3; geometric remainder upper',lower=str(lo),upper=str(hi),width=str(hi-lo)),minimum_dimension=n,strict_neighbour_certificate=rows[-2:],independent_squared_neighbours=independent,all_smaller_positive_integer_dimensions_certified_failing=n-1,menus=menus,scope='Necessary numerical gates only. qminus J <= min(menu_count,1+n log2) is an analytic input, not established from these arithmetic examples. Passing either gate is not sufficient for an actual highpast/core configuration. No new source or receiver model constructed.')
 (BASE/'r355_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),minimum_dimension=n,adjacent=[(r['n'],r['status']) for r in rows[-2:]],menus=[(r['n'],r['minimum_integer_global_menu_count'],r['octave_dimension_gate']) for r in menus]),sort_keys=True))
if __name__=='__main__':main()
