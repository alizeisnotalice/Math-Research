# R355 — General radius-menu and octave necessary gates

Let f>=0 be the same full L1 source used in the hard contract, m_u=q_u R_u^n, q_u>=q_->0, and actual Lebesgue receivers E. For J_y=integral_E 1_{y in Q_u}du/m_u, assume the entire receiver field uses a single finite global set of radii r1<...<rM. Then, for every y modulo the established measurable versions,
\[
q_-J_y\le\int_E 1_{y\in Q_u}R_u^{-n}du
\le\int_{\mathbb R^n}\max_j\{r_j^{-n}1_{\|u-y\|_\infty\le r_j/2}\}\,du
=1+\sum_{j=2}^M[1-(r_{j-1}/r_j)^n].
\]
The last equality integrates over the central cube of volume r1^n and each successive cube annulus. Consequently
\[
q_-J_y\le\min\{M,1+n\log(r_M/r_1)\}\le\min\{M,A_n\},\quad A_n=1+n\log(b/a).
\]
Use 1-exp(-t)<=t to obtain the logarithmic bound. For arbitrary continuous selector R in [a,b], the same center envelope max(a,2||u-y||inf)^(-n) supported in Q_b(y) integrates to A_n. No source uniformity, periodicity, density cap, or source-volume replacement is used.

The original strict high-past gate is Z_y(m_u/K-)>(1+sqrt(n))/(epsilon q_-), with Z_y<=J_y. It therefore requires BOTH
\[
M>(1+\sqrt n)/\varepsilon\quad\hbox{(if a global finite menu exists)},\qquad
1+n\log2>(1+\sqrt n)/\varepsilon\quad\hbox{(in an octave)}.
\]
Necessary does not mean sufficient. In particular changing a four-menu source from uniform to nonuniform cannot evade this bound. A receiver-private list of candidate radii is not a global menu of the same cardinality; the union of all actual radii is what enters M. A random common menu obeys the bound for each seed. Radius jitter must be counted through its actual expanded scale envelope, not kept at the former M without proof.

At epsilon=119/3072, the separate exact-arithmetic certificate proves the first integer satisfying the octave numerical condition is n=1458, by certifying all n=1,...,1457 fail. This is not a claim that a difficult source exists at n=1458. At n=2048 and 4096 a finite global menu must have at least1195 and1678 distinct radii respectively; the sharper annular sum above can still exclude such a menu. At n<=256 the dimension gate already excludes the original hard branch, no matter how many scales or what source is used.

This sharpens the interpretation of R354: nonuniformity alone was not a sufficient change to its four-menu model, and all its tested dimensions were below the necessary hard gate. Its actual multi-scale weak-ratio comparison and finite L1 realization remain valid, but neither was evidence for this remaining high-past traffic. The conditions apply to the current inverse-hard-cube J contract, not an arbitrary full-soft row J or all branches of the overall maximal problem. They do not remove any general unpaid slot from the main ledger.
