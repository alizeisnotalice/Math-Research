# R355 final independent audit — PASS for the adopted path-stopping receipt

Reviewed the final geometry proof, global-radius gate note, main/ledger/README, both numeric scripts and results/notes, and the extracted geometry checks. Only owned audit files were written. No author files or Git state were modified, and no full parent pipeline was repeated. Historical/global reduction and outer aggregation remain inherited; the arbitrary-input root-order theorem is not certified complete.

## 1. Global radius capacity and numeric-model correction: PASS

For the actual hard field J_y=int_E c_u(y)du/(q_u R_u^n), q_->0, a common GLOBAL menu r_1<...<r_M yields
 q_-J_y<=int max_j h_{r_j}(u-y)du
 =1+sum_{j>=2}[1-(r_{j-1}/r_j)^n]<=min(M,A_n).
The actual receiver-center integral proves this without source uniformity or periodicity. An arbitrary selector in [a,b] still satisfies the continuum envelope A_n=1+n log(b/a). A receiver-private menu of M choices with receiver-dependent values is not a common global menu. Common-seed random menus obey the condition seedwise; any continuum jitter requires its actual global envelope.

The strict old high-past event therefore needs both sufficient actual radius capacity and A_n>(1+sqrt(n))/epsilon. Finite-menu size alone cannot certify a realization. The numerical note rigorously brackets log2 by 100 positive atanh terms and a rational geometric remainder, and sqrt by scaled integer square roots. Every predecessor integer 1,...,1457 is individually certified failing, 1458 passing the NUMERICAL NECESSARY full-octave condition, with a second positive squaring check on the two adjacent dimensions. No unproved monotonicity or float sign is used. The necessary minimum integer global-menu counts 1195/1678 at n=2048/4096 are likewise rigorously rounded; they are weak necessary bounds, not sufficient cardinalities. The sharper annular capacity can still exclude a menu of those sizes.

Thus nonuniform source data with the old four global radii cannot activate the hard branch, and all prior dimensions <=256 were excluded even with arbitrary continuum hard selectors. This does not exclude general soft fields or other unresolved branches, and the menu note does not remove a general unpaid slot. Passing n=1458 or any menu test does not construct actual f, original history, or high-past traffic.

## 2. Genuine rich/inner whole-path payment: PASS

The input is the ORIGINAL R353 crossing submeasure R after the old clock and inner-source payments, with incoming initial witness density <=q. Original f/m/q/J/core, old source/receiver/time/small endpoint, eta-Omega, and all ancestral masks remain fixed. The old R353 scalar shrink and new sigma_* are distinct. No original prefix condition is transferred to a later endpoint.

The unmodified full-f posterior/rank kernel P obeys (q du)P<=q du by its sourcewise xi column. Every added rich/inner/ancestor stop is a positive history-dependent contraction, so each generation has actual marginal kappa_j<=q. This is per generation, not an unproved bound on their sum. Strict mass growth gives at most N current-receiver tests, including the normal rank-terminal receiver, and no N+1 test.

The deterministic predicate p(w)=pi_w(sigma_*Q_w)>=theta is tested BEFORE drawing a source. Nonrich arrivals draw from the genuine full-f pi_w, then test inner source first, ancestor union second, and only then the substochastic rank kernel. No conditional-on-future-survival posterior or rejected-probability renormalization occurs. Rich, inner, ancestor and ordinary terminal outcomes form the exact marked partition of R.

At a current receiver the combined rich-or-inner stop probability is exactly b_theta(p)=1_{p>=theta}+p1_{p<theta}<=p/theta. The actual center envelope gives
 int kappa_j(w)pi_w(sigma_*Q_w)dw<=sigma_*^n A_n W.
Choosing sigma_*^n=min(1,s/(NA_n)), s=1+sqrt(n), explicitly allocates capacity across generations, so the ENTIRE combined stopping mass is <=N sigma_*^n A_n W/theta<=sW/theta=4sW. This pays whole rich-hit paths, not only a fractional source event. Rich and inner stops share one p/theta charge; the discarded separate 5sW estimate is not used. Full W is required because the posteriors use full f, not g_ex.

The generation factor is not erased by telescoping or by claiming cumulative arrival <=q; it is prepaid by the smaller common inner cube. The proof is valid for arbitrary f in L1 and actual receiver dx. It does not require a density bound on f in the resulting boundary layer.

## 3. Exact complement, geometry and recapture reuse: PASS

The final exact order is R->rich stop->full-f source draw->inner stop->ancestor recapture->rank terminal/continue. Thus R=B_joint+B_rec,new+F_shell. The old ancestor union excludes the current cube and includes the old v/u and all preceding witnesses. Restricting recapture by previous stops only reduces its old N/(K-1) bound; the proof never divides by the inner-survival probability. B_rec,new uses the existing alpha_rec price ONCE, replacing rather than stacking the former whole-R recapture decomposition.

Every receiver visited by a remaining normal terminal path is nonrich, hence its FULL posterior places >3/4 mass outside sigma_*Q_w. Every ACTUAL sampled source on that remaining path, including the rank-terminal draw, is also outside the inner cube and avoids all ancestors. These are separate conclusions from separate stops. They are not asserted for a source draw stopped as inner, or for a rich path that stopped before drawing a source.

The original old-r/old-y crossing relation belongs only to initial w_0. It is not transported to later w_j. On nonempty original high-past input, inherited N<=sqrt(n) and A_n/s<=sqrt(n) give -log sigma_*<=log(n)/n; without that guard only the stated log(3n)/n estimate is used. The sigma_*=1 case stops all input as rich and has empty remaining path family.

This coordinate width need not mean small high-dimensional cube volume; such a shell can occupy most of the cube. Arbitrary f can concentrate there. Neither a fixed paid fraction for every input nor cross-path source disjointness is proved. Fresh regions remain disjoint along each path only, so the remaining occupation budget is still open.

## 4. Full ledger: PASS, no new X coefficient

The accurate reconstruction starts at G_core, keeps its previous clock/inner costs, then applies the new ordered path partition to R. The hard-slot W price becomes [C_epsilon,n+8s]W from the old [C_epsilon,n+4s]W, an increase of exactly 4sW. The W_ex price remains (D_top+C_hit+s)W_ex. All receiver charges, including the original peeling beta, old gamma, restricted recapture alpha, and clock c_eff, remain unchanged. Entrance factor two and exterior Lambda make the new source charge 8Lambda sW.

Under the explicit same-certified-X historical CZ hypothesis, the coefficient remains <889/2304 with unallocated headroom >1415/2304. This headroom is not a bound for unpaid integrals. The original entrance, all exterior factors, soft/crossing and hard-contract-exterior terms, distance/low-pe/extreme-scale/threshold complements, chronological initial/deletion/future-deleted-source atoms, H/layer/source/physical-scale/outer-integral/limit costs and single-use overlap credit are preserved. General B_H and weak-type closure are not claimed.

## 5. Actual evidence and its limits: PASS

Read all of numeric.py/result/notes, path_checks.py/result/notes and both proof code blocks. The parent reports fresh runs: numeric 4408 exact rational assertions; path 1094=103+226+754+11 separate abstract-reference checks; geometry 450 capacity cases, five first-hit models, 303 merged-probability cases, three equality cases and its ordered conservation example. The extracted geometry script is byte-identical to the two proof blocks concatenated. I did not repeat these full pipelines.

The 4408 arithmetic checks certify necessary thresholds only, not actual source fields. The path fixtures have genuine positive-L1 interval sources and exact cube/source atom integration, including positive inner/ancestor overlap assigned only to inner. However receiver labels use COUNTING measure, the column constant A_n=2 is a verified discrete analogue, and continuation is a diagnostic source-dependent neighbor kernel with no native strict-mass-growth claim. An imposed horizon is recorded separately as horizon_terminal, not silently called native rank absorption. Initial histories do not implement all original old marks. The notes and final main make these limits explicit. The final scope-only note correction says that draws retained AFTER the inner-source stop lie outside the contracted cube; it does not assert this for draws absorbed by that stop. This wording change requires no code rerun.

The stored path outputs conserve their full initial mass; the expanded model retains positive horizon-terminal mass. Equality p=theta belongs to rich and never to the survivor. The merged expectation, per-generation caps, all actual source-atom inequalities and abstract nonuniform-reference appendix are properly separated. The finite 4sW analogue does not replace the real-dx analytic envelope proof.

My independent preliminary executions were 473 gate/column cases, 373 finite first-rich/capacity-allocation cases and 75 merged-stop probability cases; they are algebra/diagnostic auditor evidence, not part of parent totals or full native-model certification. Final review additionally inspected exact result metadata and embedded-code equality without repeating the pipelines. Unused nonlinear square/Gram exploration is not certified as a new paid tool by this audit.

## Conclusion

PASS for the new combined first-rich/first-inner source payment, its exact sequential composition and source price, all surviving shell/fresh guards, global radius necessary conditions and evidence scope. The remaining shell-concentrated cross-path terminal occupation and all other global/historical unpaid slots remain open. This is not a general root-order theorem or a proof that only constants/logarithms remain.

## Frozen SHA256 bindings

Current adopted files plus required inherited interfaces. Previous bindings do not constitute a fresh audit of the whole historical reduction.

```
e6cd4f8de5b18a3e6da0afd23cb44fa20affcdd409244a37e6bd3fbb6967edd5  /tmp/r355_main.md
1185347b4fd68f4d4a41da70f0862bf3709436ac3b6143592422f894c1550fd9  /tmp/r355_ledger.md
f376ba6a30202991f2158bea0325be4235a27464d92daf65d1ae37eb436ac1c0  /tmp/r355_readme.md
42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64  /tmp/r355_geometry.md
82c004a88b15d805da9fa38af2ac8ddf1192a5fe0f8b7bf62dae61cc1af27a07  /tmp/r355_menu_gate.md
96c52486b39e54af4fedc548941f625cfad6cc2ca9c4ea53b401a8050f97cef6  /tmp/r355_numeric.py
3c986ecf72c832b0a6635304414cc5c1dca7de514d3867efa6a2729da54ffad0  /tmp/r355_numeric_result.json
f1e2b263d8e8f2a7ba14d7c3f480bf2670b70792d484c7fcdbcc0c9b9decf284  /tmp/r355_numeric.md
6ce914b31ff7047d1563a124b7e8cad89edfb44c9c18cb3388b4ba21b9020dcb  /tmp/r355_path_checks.py
1c3ff2457ee228003439a316c2ccf9b17d4c0bb2a46b670a74ec457ace018bdd  /tmp/r355_path_checks_result.json
9035f76ff17576447dc5160f144b27e92e298c58225fedd5777fe90f09c9d915  /tmp/r355_path_checks.md
e6d63b7985b600bdd5a4d0209f0f8a9c0271757b053b57d4085333b9d302b2d1  /tmp/r355_geometry_checks.py
6fa02307d5600eef08a18d755c7f1b1254c97d9cae0071ea67eebee8e2259947  /tmp/r355_audit_pre.md
c0a99aa47c05f0425bb89596a82698682fc92b462320146fbf373a7ee4fdba42  /tmp/r353_geometry.md
77250864bef33b7df84c46fe0fff6353b91b6a566ec5a436388112ab08624eae  /tmp/r353_ledger.md
3395925e97e1b2f4b983f03cb47a643b46fb3883e9386c27a77ba5916d13fd5a  /tmp/r353_audit.md
3ffe96d2acab960535e236abf7fcf2a0ee0d351d7755d49501a3175dd69cfdcc  /tmp/r352_core.md
27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b  /tmp/r351_core.md
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
```
