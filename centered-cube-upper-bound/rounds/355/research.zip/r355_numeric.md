R355 necessary dimension/menu gate certificate

Frozen fresh standard-library Python processes each returned PASS 4,408 exact rational assertions. No floating-point value determines any sign, threshold, floor, or reported minimum. The script and result are portable beside this note:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r355_numeric.py
```

With epsilon=119/3072, the smallest positive integer satisfying

1+n log(2) > (1+sqrt(n))/epsilon

is **n=1458**. Every integer n=1,...,1457 was individually certified to fail, and n=1458 was certified to pass. There is no inference from an unproved monotonicity of a sampled curve. The result retains exact rational bounds at the adjacent integers, plus an independent check after multiplying by epsilon, subtracting 1, and squaring positive bounds.

For orientation only, the certified gap An-(1+sqrt(n))/epsilon has decimal displays:

| n | Gap display | Strict decision |
|---:|---:|---|
| 1457 | -0.28032513801495477837 | fails |
| 1458 | +0.07472608434987686304 | passes |

Certificate construction. For z=1/3,

log(2)=2 sum_(j>=0) z^(2j+1)/(2j+1).

Use the first 100 positive terms as lower bound L. The positive remainder is at most 2 z^201/[201(1-z^2)], giving the rational upper bound U. Their width is approximately 1.4048e-98. This follows by replacing all later denominators by 201 and summing a geometric series; it is an outward bound, not a precision heuristic. For sqrt(n), compute k=isqrt(n*10^120). The bounds k/10^60 and (k+1)/10^60 enclose sqrt(n), with coincident endpoints when the square is exact. The program checks their squared inequalities. It then compares An lower/upper bounds against the opposite outward endpoints of the threshold. The JSON contains the exact fractions, not only the decimal displays.

For a global menu of M physical radii, the separate strict necessary condition is M>(1+sqrt(n))/epsilon. The smallest admissible integer is:

| n | Threshold display | Necessary minimum integer M | Octave dimension gate |
|---:|---:|---:|---|
| 256 | 438.857142857142857 | 439 | fails |
| 1024 | 851.899159663865546 | 852 | fails |
| 2048 | 1194.074370046426350 | 1195 | passes |
| 4096 | 1677.983193277310924 | 1678 | passes |

For each row the rational threshold endpoints have the same floor. The program checks M is strictly larger than the upper endpoint and M-1 is no larger than the lower endpoint. Thus strictness is retained even at an exact-integer threshold. The square-root and log certificates are recomputed from integers/rational series, with no dependency on prior temporary files.

Scope and next-model constraint. The analytic inputs q_-J<=M and q_-J<=1+n log(2) come from the parent proof; these arithmetic checks do not establish those operator inequalities. They certify only their necessary numerical consequences. A proposed octave model with n<=1457 is excluded by this gate, regardless of its finite menu size. A model at n=2048 or 4096 must also have at least 1195 or 1678 global scales, respectively, before it can possibly reach the stated strict high-past threshold. Passing both tests is not sufficient for an actual source/receiver or original-history realization. No new few-menu source model was built, no universal exponent was fitted, and no remaining core traffic was declared paid.
