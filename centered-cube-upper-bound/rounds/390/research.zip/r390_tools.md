# R390 本机工具与父代理诊断记录

实际调用 MATLAB R2026a Update 4，确认 Optimization、Global Optimization、Symbolic Math 等工具箱出现在 ver 输出。用 extractFileText 重新读取用户的第355轮后路线建议PDF；提取有公式排版/OCR失真，路线文字仅作为建议，不作为证明来源。

尝试以 syms 对R389时钟反导数作符号交叉核验，工具返回 `无法解析名称 'jupyter.Idler'`，该次未获得符号计算结果。不声称符号验证通过。随即普通算术 `disp(2+2)` 返回4，MATLAB会话仍可执行；没有更改path或重启用户环境。

实际执行 `run('/tmp/r390_rank_column.m')`，81个有限秩构型（alpha=0.01,0.05,0.2；beta=0.5,0.8,0.95；c=0.1,1,10；N=16,256,4096）通过列积分上界及逐级接近检查。每个构型包含从c跨越A=c/beta的原子，其余用等距rank增量离散，终点严格小于B=c/alpha。

输出：
```
PASS 81 rank configurations; each bound gap decreases at N=16,256,4096.
Finest-grid min/max gaps: 0.000109934327702 0.0113102162851
Largest observed excess above log(beta/alpha) alone: 0.499890065672
```

该浮点诊断支持不能漏掉首个跨rank阈值的原子贡献；证明使用原子rank区间嵌入与解析积分，不依赖浮点断言。它不认证真实立方体可实现性，也不认证原困难h门非空。精确原子模型的最优常数不等于施加真实中心原子容量后的最优常数。

另实际运行一次Python标准库Fraction枚举：4个增量取1/4,1/2,1，四个lower cut与三个ratio，共972个有限原子比较，验证更粗的log(U/L)+min(1,maxatom/L)界。log采用80项正atanh级数的有理下界；该诊断未用于本轮新定理或作为一般证明，不将它列入可复现核心测试计数。

本机默认python3未安装numpy/scipy/sympy/pypdf/fitz，不代表电脑其他环境或MATLAB缺这些能力。新精确核心脚本以标准库Fraction运行，不依赖上述包。
