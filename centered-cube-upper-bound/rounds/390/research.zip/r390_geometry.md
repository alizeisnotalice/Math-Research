# R390 — A quantitative external-source capture interface; joint payment remains open

## 1. Exact claim on the actual remainder

Keep the frozen R389 field and the exact positive measure dΓ_order whose total is G_order=∫q_u(K_actual1)(u)du. All original clocks, source/target marks, outside/dense/deep gates, R387 middle ranks and R388 fractional retentions stay unchanged. No new transition or receiver family is introduced.

For any actual pair with m_u>K m_v define

 I_uv=f(Q_u∩Q_v),
 p_uv=1−I_uv/m_u=π_u(Q_v^c)≥1−1/K,
 T_u(z)=T_z(m_u),   Z_u(z)=Z_z(m_u/K−),
 F_u=∫ h/[h+T_u(z)] π_u(dz),
 N_uv=∫1_{Q_v^c}[T_u(z)−Z_u(z)]π_u(dz),
 E_uv=∫1_{Q_v^c}Z_u(z)π_u(dz).                           (1)

F_u is exactly the old R388 full-source witness, not a new optimizable field. The following inequality holds for every such pair, independently of the current source and all actual retained marks:

 E_uv≥h p_uv²/F_u−h p_uv−N_uv
     ≥h p_uv²/F_u−(h+B_K)p_uv,
 B_K=(1+log K)/q_-=(1+√n)/q_-.                            (2)

Both right sides may be replaced by their positive parts. More importantly, E_uv is the genuine joint geometric quantity

 E_uv=(1/m_u)∫_{m_w<m_u/K}
                  f(Q_u∩Q_w∖Q_v) μ(dw).                 (3)

Thus the full-source witness shortage forces actual lower-mass receiver occupation on sources outside the current small cube. It does not merely assert that some source exists outside it. Formula (3) retains the real receiver measure, full f, and the overlap subtraction.

This note proves (2)–(3), but does not prove a root-order budget for the repeated use of that external occupation by different original edges. It is a quantitative geometry interface, not an additional completed payment in the ledger.

## 2. Proof: full matching and an actual-center mass-window bound

First I_uv≤m_v<m_u/K by full-f matching. This proves the lower bound on p_uv without a source density assumption.

The difference T_u(z)−Z_u(z) is the occupation of actual receivers whose masses lie in the closed interval [m_u/K,m_u]. For any 0<L≤U, write ρ=2||w−z||_∞. Capture and the true q-band give m_w≥q_-ρ^n, so

 c_w(z)1_{L≤m_w≤U}/m_w
 ≤1_{q_-ρ^n≤U}/max(L,q_-ρ^n).

Integration in actual Lebesgue dw yields

 ∫c_w(z)1_{L≤m_w≤U}μ(dw)
 ≤[1+log(U/L)]/q_-.                                      (4)

The central cube contributes 1/q_-, and the remaining radial shells give log(U/L)/q_-. Closed endpoints, arbitrary selected radius fields and mass atoms are allowed. This is a center-capacity estimate; it makes no estimate of source mass from a boundary volume. Taking L=m_u/K and U=m_u gives

              0≤T_u(z)−Z_u(z)≤B_K,
              N_uv≤B_K p_uv.                            (5)

Now apply Cauchy to the actual probability π_u restricted to Q_v^c:

 p_uv²
 ≤[∫1_{Q_v^c}(h+T_u)dπ_u]
   [∫1_{Q_v^c}1/(h+T_u)dπ_u]
 ≤[h p_uv+N_uv+E_uv]F_u/h.                               (6)

All quantities are finite because T_u≤J_max. Moreover F_u≥h/(h+J_max)>0 on every actual receiver. Rearranging (6), then applying (5), proves (2). Tonelli proves (3) directly. No atom or zero-rank division is needed, and no independence among the coordinates of f or between the old and new sources is assumed.

The first inequality in (2), retaining N_uv, is stronger than the uniform-center version. No already-spent capture square is subtracted here: N_uv and the set difference in (3) are identities inside this new nonnegative external-occupation quantity.

## 3. Consequence on the R388-shortage support, with exact qualifications

Let a_u^mid be the post-R387, pre-R388 row density used in the frozen fractional payment. A receiver carrying positive G_order cost necessarily had positive R388 shortage. Therefore

                  F_u<a_u^mid/D≤1/D.                    (7)

It is not valid to replace a_u^mid by the smaller current K_actual1 in (7). Under the existing synchronized h,

                         B_K=ε_0 h.

Thus every actual surviving pair obeys the exact useful bound

 E_uv≥h[p_uv²/F_u−(1+ε_0)p_uv]
     >h[D p_uv²−(1+ε_0)p_uv].                            (8)

Retaining p_uv and F_u is preferable; no new threshold or coefficient is chosen here.

A convenient uniform corollary is available if the already frozen choices are D=2 and ε_0≤1/2. The original strict-past gate forces J_max>h. If n≤3, the octave bound gives

 q_-J_max≤1+n log2<4,
 q_-h=(1+√n)/ε_0≥4,

a contradiction. Thus any live term has n≥4. Consequently K=exp(√n)≥exp(2)>7 and p_uv>6/7. For p≥6/7, the function 2p²−(3/2)p is increasing and its value at 6/7 is 9/49. Equations (7)–(8) therefore imply

                         E_uv>(9/49)h.                  (9)

This corollary does not cover a different frozen D or ε_0 without rechecking its constants; the exact pairwise inequality (2) remains valid in all cases. If no live terms exist, it is vacuous.

All these statements survive any further positive restriction, including a separately paid incoming branch at the small receiver. They assert no Y_w, next clock/history qualification, or outgoing row density for w.

## 4. Cost-preserving external-source lift and the unproved joint bound

For E_uv>0 there is a well-defined probability on the additional source z and actual receiver w:

 Π_uv(dz,dw)
 = [f(z)c_u(z)(1−c_v(z))c_w(z)1_{m_w<m_u/K}
       /(m_u E_uv)] dz μ(dw).                            (10)

Equation (3) verifies its normalization exactly. Therefore dΓ_order times Π_uv is a cost-preserving lift of the existing traffic. It has an external source z∉Q_v and an actual smaller receiver w capturing z. Its z law is biased by 1_{Q_v^c}Z_u(z); it is not the original π_u, and it is not a new source-exact target plan or a legitimate inherited original-history transition.

The lower bound (9) supplies a uniform normalization bound. For example, writing

 Ω=∫ E_uv dΓ_order,

it proves G_order≤49Ω/(9h) under that corollary's fixed parameters. This does **not** pay Ω. Distinct edges can repeatedly use the same triples (u,z,w), and the factors in (10) do not establish a source-column capacity.

Explicitly, the new-source marginal of this lift is f(z) times

 L_ext(z)=∫dΓ_order(old labels)
       c_u(z)(1−c_v(z))Z_u(z)/(m_u E_uv).                 (11)

Its total is exactly G_order. To use the lift for a W budget one must prove a genuine aggregate bound on this marginal, or an equally strong joint cancellation retaining f(Q_u∩Q_w∖Q_v) in (3), while pricing any exceptional traffic by εX_q. Equations (2), (9) and the normalization alone supply no such bound. In particular replacing E_uv by its lower bound and charging each old edge separately repeats the source resource without controlling its multiplicity.

This is the specific unproved step after the new inequality. A bounded L^p norm of the old auxiliary kernel, finite strict-far chain length, or the pointwise row probability in (10) does not control (11). No W price, added X_q absorption, or new negative credit is entered for this note. The existing R389 ledger remains unchanged; any independently proved incoming-column payment retains its own full price and complement.

Status: (2) is a new rigorous two-source geometric capture inequality on the actual remainder. The requested general source budget and the aggregate external-source reuse bound have not been proved. The work stops at that interface rather than treating the fourfold cost as a paid quantity.

## 5. Executed checks and scope

Executed locally:

    python3 /tmp/r390_geometry_check.py

    PASS {'external_cauchy': 1296, 'cube_external_identity': 320,
          'cube_pair_cauchy': 320, 'normalized_lift': 320,
          'constant_boundaries': 15} total 2271

All arithmetic uses Fraction. Stage 1 checks the stronger N_uv formula and its B_K-style relaxation for arbitrary finite posterior data, including empty and full outside sets. Stage 2 uses actual two-dimensional cubes and a full piecewise-constant Lebesgue source on [-2,2]^2, with densities in [3/4,1], exact cube matching, positive receiver quadrature, and strict rational far mass K=2. It independently computes (3) by source summation and receiver/triple summation, verifies the pairwise Cauchy inequality, and verifies normalization (10). Its receiver integration is quadrature, not native Lebesgue du; its bound uses its actual maximum T−Z and does not numerically assume (4). The general center estimate (4) is proved analytically.

Stage 3 certifies log2<7/10 by a positive atanh series with a rational tail, exp(2)>7 by a finite positive Taylor sum, and the exact 9/49 boundary. No sampled floating-point exponent or square root is used as proof. The diagnostics do not claim the full synchronized R385–389 historical gates or a source-column budget for (11).
