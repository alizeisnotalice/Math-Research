# R390 independent audit — FINAL PASS

Scope: only this audit file; no author/repository edits. The intermediate-rank column and endpoint-witness receipt below were independently checked before reading the R390 author proof. Final author proofs, scripts, numeric result/notes, tool record and integrated main/ledger/readme have now been reviewed. PASS applies to the precise statements and complete accounting below, with explicit nonempty-ratio guards. No general remaining source budget or history iteration is certified. The earlier r390_audit_prefilter.md remains a separate initial gap analysis.

## 1. Exact actual kernel and nonempty support

Keep R389's exact K_actual on the same full f and actual du field, including the single original clock average, source/target/spatial/history marks, mass loss and T_u/max(J,T_u). Set sigma=q_u du and rho_y(du)=c_u(y)du/m_u. Its actual cost is G_order=integral q_u K_actual1 du, not merely the upper G_prefix. The middle support retains strict m_u>K m_v and

    alpha<T_v/T_u<beta, alpha=tau/2, beta=(1+d)^-1.

Use 0<alpha<beta<1 for the nonempty column formula. If alpha>=beta, the selected middle kernel is empty and its column constant is zero, rather than applying a potentially negative expression involving log(beta/alpha). The initialized parameters in the existing ledger are in the nonempty admissible range.

All masses and inclusive ranks come from full E/f; no receiver deletion or source reset is made. Strict far mass implies m_u>m_v, so allowed u's entire occupied rank interval lies AFTER the whole closed small-end rank c=T_y(m_v). This use of whole atoms is essential.

## 2. Atom-safe reciprocal-rank column bound

Fix source y and small receiver v with c=T_v>0. Put A=c/beta and B=c/alpha. Every selected u satisfies A<T_u<B. Uniformize each mass atom over its own occupied rank interval. Its left rank is >=c, and for every internal rank s in that interval, T_u>=s and T_u>A. Thus its reciprocal satisfies

    1/T_u <=1/max(A,s).

The intervals for different mass atoms are disjoint; the nonatomic and singular parts have the same rank representation. Therefore

    integral_selected rho_y(du)/T_u
      <=integral_c^B ds/max(A,s)
      =1-beta+log(beta/alpha)=:C_rank.

The initial allowed atom may start at rank c and jump across A. Its complete contribution is not bounded by log(B/A) alone. The extra 1-beta is the correctly budgeted crossing-atom term. Strict/inclusive endpoint choices only lower the bound. If c=0, alpha>0 excludes every live selected endpoint (or equivalently rank-zero small receivers have zero rho_y mass), so the contribution is zero without division.

The estimate allows arbitrary nonnegative frozen marks<=1, including the actual clock ratio; no symmetry or product source/target assumption is used.

## 3. Actual qdu incoming measure

The exact kernel has

    K(u,dv)=integral pi_u(dy) c_v(y)chi_actual(y,u,v)dv/[m_v T_u(y)].

Integrate q_u du, retain the actual full-f source, and use q_u<=lambda and Section 2:

    (sigma K)(dv)
      <=[lambda C_rank/m_v] integral f(y)c_v(y)dy dv
      =lambda C_rank dv
      <=C_col sigma(dv),
    C_col=(lambda/q_-)C_rank.

Thus the full-f matching cancellation occurs BEFORE the q_v band conversion. Omitting the q_u/q_v factor, using mdu, or dropping the source/exit marginal would give the wrong column budget. This is a genuine actual ONE-EDGE incoming density; it does not say the auxiliary kernel is sigma-subinvariant. In general C_col>1, so repeated application without a new joint bound would accumulate that factor.

## 4. Endpoint full-source witness as a new priced branch

For the ORIGINAL R388 full-source witness F_v=integral pi_v(dz) h/[h+T_z(m_v)] and any t>0, pay each actual edge by the factor

    p(v)=min(1,F_v/t).

The exact positive remainder has factor (1-F_v/t)_+. It preserves all original source, target, clock and history labels. The paid amount is

    integral p(v)(sigma K)(dv)
      <=C_col integral p(v)sigma(dv)
      <=(C_col/t)integral q_vF_v dv
      <=[C_col lambda h log(1+Jmax/h)/t] W.

This also pays every endpoint with F_v>=t in full, and partially pays smaller-F endpoints, at the same bound as that hard endpoint gate. No incoming endpoint alpha_v/Y_v or future transition qualification is required. This new receipt uses the full posterior only as a globally priced witness, after deriving the real column budget.

The old R388 large-end witness fee is NOT free reusable credit. This is a distinct payment on the remaining actual incoming edges and has the explicit additional source-W price above, carried through the original entrance with multiplier 2Lambda. There is no new X coefficient, target-cap/h/t/template change, old square reuse or new source-exact plan. If a different complete alternative receipt is selected, its entire actual flow and fees must be stated instead of mixing residuals across plans.

If t>1, F_v<=1 makes the hard F_v>=t branch empty; the soft split remains valid but has no claimed full endpoint coverage. Normally take 0<t<=1/2 to state the posterior consequence below. Nothing here proves a fixed fraction of arbitrary G_order is paid.

## 5. Necessary condition on retained endpoints

A positive remaining edge has F_v<t. Hence for every s>=0,

    pi_v{z:T_z(m_v)<=s h} <=(1+s)F_v<(1+s)t.

For 0<t<=1/2 choose s=1/(2t)-1>=0. Strictly more than half the endpoint's FULL f posterior is then at rank T_z(m_v)>h[1/(2t)-1]. This is a fresh actual small-endpoint condition, involving that endpoint's full posterior, not a transfer of old a_mid or alpha/Y qualification. Its current source rank and all earlier pair gates remain separately fixed. It is not a general budget for the retained cold-endpoint traffic.

The R388 large-u posterior gate still uses pre-payment a_mid, not a389=K_actual1. The endpoint F_v condition cannot replace that earlier density or reconstruct a descendant source/history process.

## 6. Bounded reviewer evidence and pending final review

Reviewer actually ran 1944 Python Fraction atomic intermediate-rank column cases, against a certified rational positive-series LOWER logarithm approximation. The cases include crossing atoms; they support only the stated finite rank-measure inequality, not native cube/history realization or a source-budget proof. This is separate from author/parent counts and from the earlier 192 prefilter scalar checks. No parent MATLAB floating diagnostics or full author pipeline was repeated.

PASS for the stated column constant, qdu conversion and new actual endpoint-witness payment. Final author, evidence and integration reviews follow.


## 7. Integration review and resolved naming issue

Read the current main and ledger. The ledger names the new endpoint threshold t_cold=1/8, correctly distinct from old layered-plan depth t. Its P390 equals C_col lambda h log(1+Jmax/h)/t_cold. It is explicitly added once to C338+S386+P388+P389, and the full entrance doubles the complete source coefficient before Lambda. E387, original H entry, all old parameters and unpaid interfaces remain. There is no new X term or discount of the old R388 witness fee.

For fixed inherited absorption parameters, alpha,beta,C_col and t_cold are dimension-independent. With the original synchronized h and epsilon0 inverse bound, P390 has the stated root-log^(5/2) source scale, with its parameter dependence retained and no claim to pay H entry. The cold-endpoint consequence at t_cold=1/8 is strictly more than half full-posterior mass above rank 3h. The large-end R388 posterior condition remains attached to pre-payment a_mid, not the new smaller row.

The initial main used generic t while the ledger used t_cold. That naming issue was reported and is resolved in the final main: t_cold=1/8 is now consistent, avoiding confusion with old layered-plan depth. It was a naming issue rather than a constant/proof failure.


## 8. Author incoming proof and script: reviewed

After the independent screen, read r390_aux.md and its entire check script. Its exact adjoint formula retains q_u/q_v and the true pi_v; no reversibility or unweighted-column inference is made. The interval-empty guard 0<alpha<beta<1 is explicit. Its random-rank atom proof, including internal atom contribution below c/beta, agrees with Section 2 and preserves 1-beta. The optional actual-geometry mass-atom capacity rho_y{m=t}<=1/q_- follows by integrating density 1/t over the capture-center cube of volume t/q_-. Consequently its refined crossing correction is valid; it is only an alternative constant, not another payment.

The soft paid and remaining endpoint multipliers are an EXACT decomposition of the current sigma incoming density and also of the original marked source/clock edges. The certificate's extra posterior source z is only used to compute full F_v; it is not substituted for original transported y. The old R388 source price is retained and the new fee explicitly added. C_col is not presumed <=1, so its auxiliary resampling interpretation does not imply cross-generation sigma domination.

Read all 8395 Fraction check definitions. Atomic columns and variable-q matching/incoming tests support the bounded algebra; the matched receivers are positive quadrature, while source interval geometry is exact. The final 387 native one-dimensional tests verify only the stated center mass-atom cap, not the entire current hard/history residual. The proof and code distinguish these scopes and do not assert global coverage from six positive incoming configurations. No author pipeline was repeated.

Incoming author result: PASS within its stated scope. Final auxiliary geometry, actual example, tools record and integrated byte binding are reviewed below.


## 9. External-capture geometry proof: PASS, no booked payment

Read r390_geometry.md and its entire check script. For each actual pair, p_uv=pi_u(Q_v^c)>=1-1/K follows from I_uv<=m_v. The closed mass window [m_u/K,m_u] equals T_u-Z_u, so the actual-center capacity is B_K=(1+log K)/q_-. Its bound controls N_uv<=B_K p_uv without bounding f by a density cap.

Cauchy on pi_u restricted to Q_v^c yields p_uv^2<=(h p_uv+N_uv+E_uv)F_u/h, hence the stated E_uv lower bounds and positive-part alternatives. Tonelli gives the exact common-source identity E_uv=m_u^-1 integral_{m_w<m_u/K} f(Q_u intersect Q_w outside Q_v)mu(dw). All ranks and source masses are original and finite; F_u>=h/(h+Jmax)>0. No source independence or old-square subtraction appears.

On positive actual R388-shortage support F_u<a_mid/D<=1/D uses the OLD pre-payment density a_mid, as required. With the corollary's frozen D=2 and epsilon0<=1/2, the nonempty strict-past condition rules out n<=3 by the octave Jmax bound; n>=4 gives K>7, p_uv>6/7 and E_uv>9h/49. Those extra parameter guards are stated rather than treated as universal for arbitrary D. The normalized external-source/receiver lift is a legitimate probability where E_uv>0; its source marginal L_ext remains unpaid. Repeated use of the same external captured source is not controlled by its normalization or lower bound. No new fee, X absorption or negative credit is entered for this geometry note.

The 2271 Fraction tests check posterior algebra, exact source-cell/triple identities and lift normalization with RECEIVER quadrature; the source cells align with the actual cube arrangement. Their constant checks use rational log/exp certificates. They do not certify all synchronized historical gates or an incoming budget for L_ext. This scope matches the code and final main/ledger.

## 10. Full small-endpoint posterior and incoming-weighted numeric review

Read r390_numeric.py, its saved result and the final explanation completely. The minimum-mass v family is a single inclusive mass atom, not arbitrarily ordered equal masses. Thus T_y(m_v)=(V_v/m_v)tau(y), where tau is the ACTUAL source capture fraction of that family. The literal h=V_v/(100m_v) makes w=1/(1+100tau). Every posterior source has tau<=1, so F_v>=1/101 uniformly. The common core of all v cubes has tau=1 and contains D; using w<=1 outside it gives the stated uniform upper for every actual v.

The exact du-average follows by Fubini: (bg/m_v) integral tau/(1+100tau)dy+P/(101m_v). The product trapezoid decomposition retains choose(4,k), plateau lengths and two ramps per coordinate. I0=1/101 and I1=(100-log101)/10000 are correct. For k>=2 the lower secant z/101 and upper tangent at E z=2^-k give the stated rigorous continuum moment bounds; the finite rational test values are implementation safeguards, not their proof. The coarea/product geometry belongs to actual source/center intervals and does not assume independent coordinates of the full f.

The packet-only posterior contribution and the conditional packet witness 1/101 are kept distinct. The full background outside D is correctly retained in F, despite carrying no designated present surplus cost. Negative-half density remains in full W and u/w matching even though the actual small posterior lies in the positive x1 region. No source reset occurs.

The code computes designated RAW original incoming cost and AFTER-ORDER incoming cost separately, with variable actual masses, complete continuous clock and terminal atom. It does not identify either with the current fully filtered G_order. Bounds on original and after-order columns are uniform in each v, not merely means. Consequently multiplying these cost bounds by uniform gamma lower/upper bounds gives valid actual flow-weighted soft-payment enclosures, regardless of correlations. The more accurate du-average F is reported only as geometry information and is NOT multiplied by flow as if independent. Separate interval endpoints are not falsely required to add exactly.

The actual fixture has diagnostic h/H, no R385--388 complete filtering/history certification and no native C_col hypothesis certificate. The saved flag explicitly states that absence. It therefore illustrates full-posterior computation and positive soft marks, not the general incoming-payment theorem's actual hard remainder or an all-input coverage rate. Baseline costs, full W/X and original-vs-after-order comparison are kept explicit; no full payment is invented from witness exceeding a diagnostic column. The 407 Fraction assertions are split 221 geometry/rank, 95 coarea and 91 incoming/split checks, over 1+8+4 parameter executions. Table decimals display exact bounds rather than providing extra floating certificates.

## 11. MATLAB/tools record and final complete accounting

Read r390_tools.md and r390_rank_column.m. The script has 27 alpha/beta/c triples and three grid sizes, totaling 81 floating grid configurations. It retains the first crossing atom and reports convergence toward the analytic bound. These are finite rank diagnostics, not native cube/hard-history realizations or a proof. The tool record's extra 972 finite rational exploratory comparisons are explicitly excluded from the reproducible core total. The attempted Symbolic Math call failed with the recorded jupyter.Idler error and is not represented as a successful symbolic result. The record does not claim every local environment lacks such tools; ordinary MATLAB numeric arithmetic remained available. No tool result here is treated as a new geometric theorem or source price.

Read final main, ledger and readme. The main now consistently uses t_cold, and the ledger correctly refers to the flat bundled r389_ledger.md dependency. The exact final estimate is

    BH<=G_cold+E387 X_q+(C338+S386+P388+P389+P390)W,
    P390=C_col lambda h log(1+Jmax/h)/t_cold.

The original entrance retains 8lambda H W and 2d_eff A_n W_nu/H, plus twice G_cold, twice E387 and twice the entire stated source coefficient, and then multiplication by Lambda. Hence P390 gets exactly 2Lambda. All old prices are present once; no new X term or old witness/square discount is inserted. The original synchronized h/t, target capacity and matching are unchanged. With fixed original absorption parameters and t_cold, C_col has no n dependence and P390 retains the previously stated root-log^(5/2) source scale, with explicit old-parameter dependence and no claim to pay H entry.

Cold-endpoint full-source posterior conditions do not confer Y_v, alpha_v, old row acceptance or next-history eligibility; large-u old failure conditions still use a_mid. C_col generally exceeds one and cannot be iterated as an invariant sigma capacity. The external-source Cauchy/lift is not added to the paid bill. General G_cold, H entry/choice, soft/crossing/entry, tail/scale complements, initial/deleted/future-deleted history atoms, aggregation/truncation/limits all remain unpaid.

Parent reports actual runs 8395+2271+407=11073 Fraction assertions, with the 81 MATLAB floating grid evaluations separate. Reviewer evidence is separately 1944 atomic column cases and 192 prefilter scalar splits. No parent pipeline or floating tests were needlessly rerun in this file review. The audit does not certify LaTeX layout/compilation or freshly re-prove the whole historical reduction.

FINAL PASS: no outstanding correction found in the incoming-column receipt, priced endpoint soft split, auxiliary geometry, numeric scope or final accounting. General root closure remains open.

## 12. Final byte bindings

| File | SHA256 |
| --- | --- |
| `/tmp/r390_main.md` | `f925d686a5ba9125ec294200214841b8448c134478f164720056fe91ce239559` |
| `/tmp/r390_ledger.md` | `fea0ea4fb0134ff61ca69de3c2bce51e6d28013fe0a82d448857b2fa6dffb42b` |
| `/tmp/r390_readme.md` | `fb02a3042108075d9e8206cc3b258c4d77657f97f186db2a72159a3af7cdc984` |
| `/tmp/r390_aux.md` | `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36` |
| `/tmp/r390_aux_check.py` | `b5bd6a27e7d28e079ca2496d4368079aabc16053e3c901b60fc27ee1679e6053` |
| `/tmp/r390_geometry.md` | `4cc51254b6d0314500888c61d65ff09c43890a50efdda600c05fae75bff45b34` |
| `/tmp/r390_geometry_check.py` | `3c3f230534f27582644a852f00f199e9b504f954de8420ce776ee63e17a21725` |
| `/tmp/r390_numeric.md` | `6afc21b23fd23322f2c666e7fabf51bdc6bef3024dbde80c8e03ba9bcbf83b8f` |
| `/tmp/r390_numeric.py` | `456b08a208589057c72a121ac4f524f397f31d0a2cee6cf9ea512e7b7b2fa324` |
| `/tmp/r390_numeric.result.json` | `0172d2ead0f82e8e43f74f985aec0ea06674f1e18fecfbbac40b1c376945a750` |
| `/tmp/r390_tools.md` | `c2e93dd08716ae5e01208e8517f8448899d60e32bb1946f52e396e652cbf9da0` |
| `/tmp/r390_rank_column.m` | `5ce8d450c10fdd1625189df3ca8a28b44da134f0acbc0fe55c4385b269508152` |
| `/tmp/r390_audit_prefilter.md` | `b16fa7a0c4920ddd6483f9d396041b35478496925a39242c622688f6bbca9dca` |
| `/tmp/r389_ledger.md` | `10f4145bbc83290f6482ef6ac3b4289ff2d59921e74cb9ff011685c53c9bb7d6` |
| `/tmp/r389_geometry.md` | `e007b0a5fca2af7e19fd8f7574c110c2ce1029de5d46d056c837fdecb22f2985` |
| `/tmp/r389_aux.md` | `a9886d08238803e049faa6f34085d823fa888cfede624756f10b3d962ad07fc4` |
| `/tmp/r388_geometry.md` | `b3868aa0575a9893734711b9d39d8922f8f43b82fc6afc14791e9beef6ed7d00` |
