from fractions import Fraction as F
from itertools import product
from random import Random

counts={'external_cauchy':0,'cube_external_identity':0,'cube_pair_cauchy':0,'normalized_lift':0,'constant_boundaries':0}
# Stage 1: exact posterior Cauchy, including empty and full outside sets.
pi=[F(1,6),F(1,3),F(1,2)]
for T in product((F(1,2),F(2),F(5)),repeat=3):
    for h in (F(1,5),F(1)):
        for B in (F(0),F(1,2),F(2)):
            Z=[max(t-B,F(0)) for t in T]
            witness=sum(pi[i]*h/(h+T[i]) for i in range(3))
            for outside in product((0,1),repeat=3):
                p=sum(pi[i]*outside[i] for i in range(3))
                ext=sum(pi[i]*outside[i]*Z[i] for i in range(3))
                Nout=sum(pi[i]*outside[i]*(T[i]-Z[i]) for i in range(3))
                assert ext>=h*p*p/witness-h*p-Nout
                assert ext>=h*p*p/witness-(h+B)*p
                counts['external_cauchy']+=1

# Stage 2: actual two-dimensional cubes and actual Lebesgue source cells.
# Receiver measure here is positive quadrature, explicitly not native du.
rng=Random(390)
qminus=F(3,4); K=F(2); h=F(1,100)
cells=[(F(i,4)+F(1,8),F(j,4)+F(1,8)) for i in range(-8,8) for j in range(-8,8)]
for trial in range(10):
    source=[F(rng.randrange(12,17),16)*F(1,16) for _ in cells]
    cubes=[]
    for radius in (F(1),F(3,2),F(2)):
        for x,y in ((F(-1,2),F(0)),(F(0),F(0)),(F(1,2),F(0)),(F(0),F(1,2))):
            cubes.append((x,y,radius))
    cap=[[int(abs(x-cx)<R/2 and abs(y-cy)<R/2) for x,y in cells] for cx,cy,R in cubes]
    masses=[sum(source[z]*cap[u][z] for z in range(len(cells))) for u in range(len(cubes))]
    volume=[F(1+(u%3),64) for u in range(len(cubes))]
    mu=[volume[u]/masses[u] for u in range(len(cubes))]
    for u,(_,_,R) in enumerate(cubes):
        assert qminus<=masses[u]/R**2<=1
    for u in range(len(cubes)):
        piu=[source[z]*cap[u][z]/masses[u] for z in range(len(cells))]
        Tu=[sum(mu[w]*cap[w][z] for w in range(len(cubes)) if masses[w]<=masses[u]) for z in range(len(cells))]
        Zu=[sum(mu[w]*cap[w][z] for w in range(len(cubes)) if K*masses[w]<masses[u]) for z in range(len(cells))]
        B=max(Tu[z]-Zu[z] for z in range(len(cells)))
        witness=sum(piu[z]*h/(h+Tu[z]) for z in range(len(cells)))
        for v in range(len(cubes)):
            if masses[u]<=K*masses[v]: continue
            p=sum(piu[z]*(1-cap[v][z]) for z in range(len(cells)))
            ext=sum(piu[z]*(1-cap[v][z])*Zu[z] for z in range(len(cells)))
            triple=sum(mu[w]*sum(source[z]*cap[u][z]*cap[w][z]*(1-cap[v][z]) for z in range(len(cells))) for w in range(len(cubes)) if K*masses[w]<masses[u])/masses[u]
            assert ext==triple
            counts['cube_external_identity']+=1
            assert p>=1-F(1,K)
            assert ext>=h*p*p/witness-(h+B)*p
            counts['cube_pair_cauchy']+=1
            if ext:
                # Sum of the proposed cost-preserving (z,w) lift density.
                total=sum(piu[z]*(1-cap[v][z])*mu[w]*cap[w][z]/ext for z in range(len(cells)) for w in range(len(cubes)) if K*masses[w]<masses[u])
                assert total==1
                counts['normalized_lift']+=1

# Stage 3: rational constants; no float-based claim about exp or sqrt.
# log 2 < 7/10, from the positive atanh series plus a rigorous tail.
z=F(1,3); N=12
log2_upper=2*sum(z**(2*j+1)/F(2*j+1) for j in range(N))+2*z**(2*N+1)/((2*N+1)*(1-z*z))
assert log2_upper<F(7,10)
# n<=3: A_n<31/10<4<=2(1+sqrt(n)).
for n in range(1,4):
    assert 1+n*log2_upper<4
    counts['constant_boundaries']+=1
# n>=4: K>=exp(2)>7; the displayed finite Taylor sum is a lower bound.
term=F(1); exp2_lower=term
for j in range(1,7):
    term*=F(2,j); exp2_lower+=term
assert exp2_lower>7
for p,eps0 in product((F(6,7),F(7,8),F(9,10),F(1)),(F(1,10),F(1,4),F(1,2))):
    assert 2*p*p-(1+eps0)*p>=F(9,49)
    counts['constant_boundaries']+=1
print('PASS',counts,'total',sum(counts.values()))
