"""R390 full-source small-endpoint posterior on genuine continuous centers.
Exact Fraction enclosures; Python standard library, no old /tmp imports.
"""
from fractions import Fraction as F
from math import comb
from pathlib import Path
from itertools import product
import json,hashlib
COUNTS={'geometry_rank':0,'coarea_bound':0,'incoming_cost':0}
def ck(x,k):
 assert x,k
 COUNTS[k]+=1

def logbounds(x,N=32):
 assert x>=1
 p=0
 while x>2:x/=2;p+=1
 def one(z):
  t=(z-1)/(z+1)
  lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
  return lo,lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 lo,hi=one(x);l2,u2=one(F(2));return lo+p*l2,hi+p*u2

# Analytic moment bounds for ramp product z: z/101 <= z/(1+100z)
# and the tangent at Ez=2^-k is an upper. These finite algebra checks supplement
# the displayed exact identities, not replace their elementary proofs.
for k,z in product(range(2,5),[F(0),F(1,4),F(1,2),F(3,4),F(1)]):
 m=F(1,2**k);fun=lambda t:t/(1+100*t)
 ck(fun(z)-z/101==100*z*(1-z)/(101*(1+100*z)),'coarea_bound')
 ck(fun(m)+(z-m)/(1+100*m)**2-fun(z)==100*(z-m)**2/((1+100*z)*(1+100*m)**2),'coarea_bound')

def case(eta,b,wfactor,P):
 n=4;R=F(51,100);bg=F(3,4);left=F(1,5);VD=F(1,100)**4;V=eta**4;Bw=wfactor*eta;Vw=Bw**4
 mv=bg*R**4+P;qv=mv/R**4;h=V/(100*mv)
 mu0=F(17,20)+P;mul=mu0-left*eta/2;muu=mu0+left*eta/2
 mw0=bg*b**4+left*(b/2-F(2,5))*b**3+P;mwl=mw0-left*b**3*Bw/2;mwu=mw0+left*b**3*Bw/2
 ck(R<1<b<=2*R and R>eta,'geometry_rank')
 ck(bg<=qv<=1 and bg<=mul<=muu<=1 and bg<=mwl/b**4<=mwu/b**4<=1,'geometry_rank')
 ck(mul>8*mv and mwl>mv and mwu<mul,'geometry_rank')
 # Entire v capture union stays in positive x1 background and Q4.
 ck(F(7,10)-(R+eta)/2>0 and F(7,10)+(R+eta)/2<2,'geometry_rank')
 # D lies in the common v capture core, hence tau=1 there.
 centers=[F(7,10)]+[F(1,4)]*3;dlo=[F(47,100)]+[F(1,10)]*3;dhi=[F(12,25)]+[F(11,100)]*3
 for c,l,u in zip(centers,dlo,dhi):ck(c-(R-eta)/2<=l<=u<=c+(R-eta)/2,'geometry_rank')
 # Other two families also capture all D and fit inside Q4.
 for center,rr,side in [([F(0)]*4,F(1),eta),([F(2,5),F(0),F(0),F(0)],b,Bw)]:
  for c,l,u in zip(center,dlo,dhi):
   ck(c+side/2-rr/2<=l and c-side/2+rr/2>=u and abs(c)+side/2+rr/2<2,'geometry_rank')
 # All same-mass v receivers form ONE inclusive rank group. No (mass,id) rank.
 # T_y(mv)=(V/mv)*tau(y), since both other groups have strictly greater mass.
 ck(h/(h+V/mv)==F(1,101),'geometry_rank')
 # Uniform lower and upper for each actual receiver v, not only average.
 pointlo=F(1,101)
 core=(R-eta)**4
 pointhi=(bg*core+P)/(101*mv)+bg*(R**4-core)/mv
 ck(pointlo<=pointhi<1,'coarea_bound')
 # True du-average F by exact Fubini/ramp decomposition over full sources.
 lnlo,lnhi=logbounds(F(101))
 I1lo=(100-lnhi)/10000;I1hi=(100-lnlo)/10000
 ck(0<I1lo<=I1hi<F(1,101),'coarea_bound')
 integrallo=core/101;integralhi=integrallo
 ramp_terms=[]
 for k in range(1,5):
  coeff=comb(4,k)*(R-eta)**(4-k)*(2*eta)**k
  if k==1:il,iu=I1lo,I1hi
  else:il,iu=F(1,101*2**k),F(1,100+2**k)
  integrallo+=coeff*il;integralhi+=coeff*iu
  ramp_terms.append({'ramp_coordinate_count':k,'geometric_coefficient':str(coeff),'integral_lower':str(il),'integral_upper':str(iu)})
 avglo=(bg*integrallo+P/101)/mv;avghi=(bg*integralhi+P/101)/mv
 packetmass=(bg*VD+P)/mv;packetcontrib=packetmass/101
 outsidebglo=avglo-packetcontrib;outsidebghi=avghi-packetcontrib
 ck(pointlo<=avglo<=avghi<=pointhi,'coarea_bound')
 ck(0<packetcontrib<avglo and outsidebglo>0,'coarea_bound')
 ck(abs((bg*R**4+P)/mv-1)==0,'coarea_bound')
 # Preserve actual original clock and receiver mass variation in incoming cost.
 Iv=V/mv;Iul=V/muu;Iuu=V/mul;Iwl=Vw/mwu;Iwu=Vw/mwl
 Jl=Iv+Iul;Ju=Iv+Iuu;Jbl=Jl+Iwl;Jbu=Ju+Iwu;Tl=Iv+Iwl;Tu=Iv+Iwu+Iuu
 ck(Tl>Ju and Iv>h,'incoming_cost')
 pmin=(F(151,200)-F(7,10)-eta)/R*((F(151,200)-F(1,4)-eta)/R)**3
 pmax=(F(151,200)-F(7,10)+eta)/R*((F(151,200)-F(1,4)+eta)/R)**3
 ck(0<pmin<=pmax<1,'incoming_cost')
 fD=bg+P/VD;elo=1-b**(-4);eb=b**(-4)
 prelo=V*V*(fD-qv)*VD/mv*(1-mv/mul)*(1-pmax)
 prehi=V*V*(fD-qv)*VD/mv*(1-mv/muu)*(1-pmin)
 costlo=prelo*(elo/Ju+eb/Jbu);costhi=prehi*(elo/Jl+eb/Jbl)
 afterlo=prelo*(elo/Tu+eb/Jbu);afterhi=prehi*(elo/Tl+eb/Jbl)
 ainlo=costlo/(qv*V);ainhi=costhi/(qv*V)
 aafterlo=afterlo/(qv*V);aafterhi=afterhi/(qv*V)
 # This same bound is uniform in every v center, not merely for its mean.
 conditional_alpha_hi=V/qv*(1-qv/fD)*(1-mv/muu)*(1-pmin)*(elo/Jl+eb/Jbl)
 ck(ainhi==packetmass*conditional_alpha_hi and 0<conditional_alpha_hi<1,'incoming_cost')
 ck(0<ainlo<=ainhi<pointlo and 0<aafterlo<=aafterhi<=ainhi,'incoming_cost')
 # New t=1/8 receipt: uniform-in-v F bounds, never du mean times flow.
 tsoft=F(1,8);gammalo=min(F(1),pointlo/tsoft);gammahi=min(F(1),pointhi/tsoft)
 ck(0<gammalo<=gammahi<1,'incoming_cost')
 paidlo=gammalo*costlo;paidhi=gammahi*costhi
 remlo=(1-gammahi)*costlo;remhi=(1-gammalo)*costhi
 ck(0<paidlo<=paidhi and 0<remlo<=remhi,'incoming_cost')
 # Comparison is a finite diagnostic, not a generally established incoming fee.
 E=2*V+Vw;W=bg*4**4+left*F(4**4,2)+P
 Xlo=V*mul+V*qv+Vw*mwl/b**4;Xhi=V*muu+V*qv+Vw*mwu/b**4
 ck(bg*E<=Xlo<=Xhi<=E,'incoming_cost')
 return {'eta':str(eta),'b':str(b),'w_side_factor':str(wfactor),'P':str(P),'mv':str(mv),'qv':str(qv),'h_H_diagnostic':str(h),
  'Fv_pointwise_bounds':[str(pointlo),str(pointhi)],'Fv_true_du_mean_bounds':[str(avglo),str(avghi)],
  'mean_enclosure_width':str(avghi-avglo),'packet_conditional_w':str(F(1,101)),
  'packet_posterior_mass':str(packetmass),'packet_only_F_contribution':str(packetcontrib),
  'extra_spike_only_F_contribution':str(P/(101*mv)),
  'background_outside_D_mean_F_bounds':[str(outsidebglo),str(outsidebghi)],
  'full_mean_over_packet_contribution_bounds':[str(avglo/packetcontrib),str(avghi/packetcontrib)],
  'ramp_terms':ramp_terms,
  'designated_incoming_original_cost_bounds':[str(costlo),str(costhi)],
  'designated_incoming_original_density_bounds':[str(ainlo),str(ainhi)],
  'designated_incoming_after_order_density_bounds':[str(aafterlo),str(aafterhi)],
  'incoming_conditional_source_density_upper':str(conditional_alpha_hi),
  'uniform_witness_over_incoming_density_upper':str(pointlo/ainhi),
  'soft_t':str(tsoft),'soft_paid_fraction_uniform_bounds':[str(gammalo),str(gammahi)],
  'soft_paid_original_cost_bounds':[str(paidlo),str(paidhi)],
  'soft_remaining_original_cost_bounds':[str(remlo),str(remhi)],
  'soft_paid_after_order_cost_bounds':[str(gammalo*afterlo),str(gammahi*afterhi)],
  'twice_packet_contribution_below_incoming_lower':2*packetcontrib<ainlo,
  'native_Ccol_budget_hypotheses_certified':False,
  'full_W':str(W),'full_Xq_bounds':[str(Xlo),str(Xhi)]}

def summary(cases):
 out={'executed_parameter_fields':len(cases),'exact_case_digest':hashlib.sha256(json.dumps(cases,sort_keys=True).encode()).hexdigest()}
 for key in ['Fv_true_du_mean_bounds','designated_incoming_original_density_bounds','soft_paid_fraction_uniform_bounds']:
  out[key+'_global_lower']=str(min(F(c[key][0]) for c in cases));out[key+'_global_upper']=str(max(F(c[key][1]) for c in cases))
 out['minimum_witness_over_incoming_upper']=str(min(F(c['uniform_witness_over_incoming_density_upper']) for c in cases))
 return out

def main():
 base=[case(F(1,1000),F(101,100),F(2),F(1,2**20))]
 pressure=[case(e,b,w,F(1,2**20)) for e,b,w in product([F(1,2000),F(1,500)],[F(201,200),F(203,200)],[F(3,2),F(5,2)])]
 expanded=[case(e,F(101,100),F(2),p) for e,p in product([F(1,2000),F(1,500)],[F(1,2**22),F(1,2**18)])]
 result={'scope':'True positive-volume R389-style continuous center field and full positive L1 f. Full small-endpoint posterior averaged by exact Fubini geometry, with rational log/moment enclosures. No center quadrature or packet-only substitution. Actual same-full-f q/m/caps and diagnostic clock/past gates; not the full R385-388 filtered/native G_smooth or synchronized history. Incoming cost comparison is a finite designated-column diagnostic, not a general incoming-payment/root theorem.',
  'fraction_assertions':COUNTS,'baseline':base[0],'stages':{'baseline':summary(base),'parameter_pressure':summary(pressure),'expanded_packet_ratio':summary(expanded)}}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNTS,'total',sum(COUNTS.values()),'fields1/8/4')
 print('Result written beside script; full Fraction bounds in JSON.')
if __name__=='__main__':main()
