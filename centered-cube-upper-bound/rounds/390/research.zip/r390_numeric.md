# R390: the complete small-endpoint source posterior

This evaluates an actual full-f posterior witness on R389-style genuine continuous receiver boxes, not only its cost-carrying source packet. Exact geometry/Fubini formulas plus rational logarithm and moment bounds enclose the whole source integral. A separate uniform-in-v enclosure controls the new soft multiplier under the **actual incoming traffic weights**. The du mean is never multiplied by incoming cost as if they were independent.

The input has actual same-full-f q/m/caps and literal diagnostic clock/past gates. It is not the R385–R388 filtered/native G_smooth, synchronized h choice, historical FIRST/selector qualification, or a general incoming-payment/root theorem. In particular the native Ccol budget assumptions are not certified by this example.

## Actual field and why the rank is computable

n=4, lambda=1, a=Rv=.51, Ru=1, b=Rw=1.01 at baseline. Retain the complete source

f=[.75+.2*1_(x1<0)]1_Q4+(P/|D|)1_D,
D=[.47,.48] times [.1,.11]^3, |D|=10^-8, P=2^-20.

Actual receiver centers occupy three disjoint positive-volume boxes: u around 0 of side eta=.001, v around (.7,.25,.25,.25) of side eta, and w around (.4,0,0,0) of side 2eta. Their fixed radii are 1,.51,1.01 respectively; hard softness is zero. The variable actual u/w masses and their genuine du interval bounds are retained, as are full W=217.6+P and Xq. The script independently checks capture of D, containment in Q4, q in [3/4,1], and the matched mass inequalities. No receiver mass/weight is reset.

The v mass mv=.75*Rv^4+P is constant over that family and strictly smaller than every other receiver mass. Thus all equal-mass v receivers form **one inclusive mass atom**, with no private mass/id ordering. For every source y,

T_y(mv)=Vv*tau(y)/mv,
tau(y)=|E_v intersect Q_Rv(y)|/Vv, Vv=eta^4.

Choose literal diagnostic h=H=Vv/(100mv), as in R389. Then the witness is exactly

w(y)=h/(h+T_y(mv))=1/(1+100tau(y)).

The complete posterior is pi_v(dy)=f(y)1_Q_Rv(v)(y)dy/mv. It is not normalized on D. Every v capture cube lies entirely in the positive-x1 background, but the global source is not changed to a uniform density: the negative-half density remains in full W, in actual u/w matching and in their incoming clock. Sources outside Q_Rv(v) are absent only because the actual posterior assigns them zero mass.

## Bounds for every actual v, and a separate true du mean

D lies inside the common core Q_(Rv-eta) of all v capture cubes. There tau=1, so its **conditional** witness is 1/101. For every source tau<=1. Therefore each individual v obeys

F_v=integral w d pi_v >=1/101.

All v capture cubes contain the same common core. Using w<=1 on the remaining boundary gives the rigorous uniform upper

F_v <= [.75(Rv-eta)^4+P]/(101mv)
       +.75[Rv^4-(Rv-eta)^4]/mv.

These are full-posterior bounds for every v, not statements only about its du mean.

For additional source geometry evidence, compute the true du mean by Fubini:

mean_(v in E_v) F_v
 =(.75/mv) integral tau/(1+100tau)dy +P/(101mv).

The one-dimensional capture fraction is a trapezoid: plateau width Rv-eta at value 1 and two ramps of width eta. Expanding by the number k of ramp coordinates retains all binomial factors:

integral tau/(1+100tau)dy
 =sum_(k=0)^4 binom(4,k)(Rv-eta)^(4-k)(2eta)^k I_k,
I_k=integral_[0,1]^k z/(1+100z)dt, z=product(t_i).

Here I0=1/101 and I1=(100-log101)/10000 exactly. A range-reduced positive atanh series supplies explicit rational lower/upper bounds for log101. For k>=2, the exact moment Ez=2^-k and the elementary secant/tangent identities imply

1/(101*2^k) <= I_k <= 1/(100+2^k).

The lower follows from f(z)-z/101=100z(1-z)/[101(1+100z)]. The upper follows from the nonnegative tangent error 100(z-m)^2/[(1+100z)(1+100m)^2], m=2^-k. Thus these are justified continuum integral bounds, not estimates from finitely checked sample z. The code also checks those exact algebraic identities at representative rational values as implementation safeguards. Zero-tau source boundaries carry zero joint capture measure; they create no spurious posterior charge.

Baseline results (displays of exact Fraction bounds):

| quantity | lower | upper |
|---|---:|---:|
| F_v, every v | .009900990099 | .017643517190 |
| true du mean F_v | .009972534756 | .009973192932 |
| background outside D contribution to that mean | .009972347200 | .009973005376 |
| full mean / packet-only posterior contribution | 53171.0 | 53174.5 |

The mean enclosure width is 6.58176e-7. The D posterior mass is 1.894314253e-5 and its complete contribution to F_v is only 1.875558666e-7. This includes both the extra packet and the ordinary background inside D; the extra-spike-only contribution is separately 1.860923766e-7. Its conditional witness 1/101 must not be confused with either of these posterior-mass-weighted contributions. Keeping only D would miss over 99.998% of this witness's integral. The full background sources have zero designated present surplus cost but still legitimately contribute to F_v.

## Incoming traffic and the new t=1/8 soft multiplier

The designated real u→v far traffic and its physical clock are enclosed as in R389. Masses mu(u),mw(w) vary with first receiver coordinates. Pointwise bounds give genuine full-du bounds for occupations, target overlap and incoming costs; there is no receiver-center quadrature. The early [1,b) interval and terminal b atom are both retained. The post-order cost uses max(J,Tu) on the early interval and Jb at the terminal. No other incoming families or history-filtered traffic are claimed to have been computed.

At baseline, the original designated cost lies in [4.007576577e-19,4.031278947e-19]. Dividing by the actual qv*|E_v| gives incoming column density between 5.343335004e-7 and 5.374937570e-7. The same upper is valid at every v, because all ingredient bounds were uniform on complete center boxes. The conditional source-cost density is bounded above by .0283741<1. After the order receipt the incoming column density lies between 5.151302147e-7 and 5.187860664e-7. These are only the specified positive branch, with full fields unchanged.

The new accepted receipt uses gamma(v)=min(1,F_v/t), t=1/8. For this fixture the uniform bounds above imply

.07920792079 <= gamma(v) <= .14114813752, for every v.

Consequently the **actual incoming-flow-weighted** paid fraction is in this same interval regardless of its correlation with v. The original designated paid cost is rigorously in [3.174318081e-20,5.690075152e-20], and its remaining cost in [3.441914607e-19,3.711969723e-19]. After the order receipt, the corresponding paid-cost enclosure is [3.060237011e-20,5.492029753e-20]. Endpoint bounds of separate intervals are not claimed to add exactly; the underlying pointwise positive split does.

The more precise du-average witness is reported as geometry information only. It is **not** used to claim a paid fraction of 8 times that mean under flow weights. This distinction is essential. The uniform bounds guarantee a positive partial payment but do not show full payment; the remainder is positive on this diagnostic branch. Likewise the fact that F_v is much larger than the incoming cost density does not replace the actual receipt's specified min(1,F_v/t) rule by an invented full-payment rule.

For comparison, using only D inside F would produce a baseline soft factor of about 1.50045e-6 instead of the certified actual factor >=.0792079. This quantifies the concrete omitted-source error, not an alternative legitimate full-posterior computation. The general Ccol/t*SF source price requires the original retained-column hypotheses; they are not established by this nonnative example, and no such budget is certified here.

## Bounded stages, decision and reproduction

Stage 1 is the baseline. Stage 2 uses eta in {.0005,.002}, b in {1.005,1.015}, wside factor in {3/2,5/2}, with P fixed (8 fields). Stage 3 uses eta in {.0005,.002}, P in {2^-22,2^-18}, b=1.01,wside factor=2 (4 fields). These actual u/w changes alter the incoming clock/cost but not the formula for the lowest-mass v rank group. Across all 13 fields full mean F is about .00994–.01005; the uniform witness/incoming-density-upper comparison is at least 4592. This is finite evidence for retaining full-source witnesses at small endpoints. It is not a dimension-rate fit or a native high-past example.

Run `python3 r390_numeric.py`. Only the Python standard library is used; no old /tmp imports, optimizer, Monte Carlo, point-source substitution or third-party packages. The script writes `r390_numeric.result.json` beside itself, with a full rational baseline, coarea terms and stage extrema/digests. **407 exact Fraction assertions** passed: 221 actual geometry/rank checks, 95 coarea-bound algebra checks and 91 incoming-cost/soft-split checks. A second fresh process reproduced result bytes. Table decimals are displays, not additional float certificates. Only the owned R390 files were changed; no repository/Git actions.
