% R390: diagnostic of the sharp inclusive-rank column bound.
% This is an atomic rank model, not a native cube or original hard gate instance.
r390_rows=[];
for r390_alpha=[0.01,0.05,0.2]
 for r390_beta=[0.5,0.8,0.95]
  for r390_c=[0.1,1,10]
   r390_A=r390_c/r390_beta; r390_B=r390_c/r390_alpha;
   r390_bound=1-r390_beta+log(r390_beta/r390_alpha);
   r390_prev=Inf;
   for r390_N=[16,256,4096]
    r390_eps=(r390_B-r390_A)/(r390_N^2+1);
    r390_start=r390_A+r390_eps;
    r390_end=r390_B-r390_eps;
    r390_t=linspace(r390_start,r390_end,r390_N+1);
    r390_val=(r390_start-r390_c)/r390_start+sum(diff(r390_t)./r390_t(2:end));
    r390_gap=r390_bound-r390_val;
    assert(r390_gap>=-1e-12 && r390_gap<r390_prev);
    r390_prev=r390_gap;
    r390_rows(end+1,:)=[r390_alpha,r390_beta,r390_c,r390_N,r390_val,r390_bound,r390_gap];
   end
  end
 end
end
fprintf('PASS %d rank configurations; each bound gap decreases at N=16,256,4096.\n',size(r390_rows,1));
fprintf('Finest-grid min/max gaps: %.12g %.12g\n',min(r390_rows(3:3:end,7)),max(r390_rows(3:3:end,7)));
fprintf('Largest observed excess above log(beta/alpha) alone: %.12g\n',max(r390_rows(:,5)-log(r390_rows(:,2)./r390_rows(:,1))));
