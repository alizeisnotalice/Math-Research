from fractions import Fraction as F
from itertools import product
count={'atomic_column':0,'matched_incoming':0,'soft_receipt':0,'native_atom':0};positive=0;positive_incoming=0;strict_soft=0

def loglo(x,N=90):
 assert x>=1
 z=(x-1)/(x+1)
 return 2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
# Sourcewise rank interval: all mass atoms have size <=1 for refined q_-=1 bound.
for weights in product((F(1,8),F(1,2),F(1)),repeat=4):
 mass=[F(1),F(2),F(4),F(8)];T=[sum(weights[:j+1]) for j in range(4)]
 for alpha in (F(1,8),F(1,4),F(1,2)):
  for beta in (F(1,2),F(3,4),F(4,5)):
   if alpha>=beta:continue
   log=loglo(beta/alpha)
   for v in range(4):
    ids=[u for u in range(4) if mass[u]>mass[v] and alpha*T[u]<T[v]<beta*T[u]]
    col=sum(weights[u]/T[u] for u in ids)
    cap=1-beta+log
    refined=min(1-beta,beta/T[v])+log
    assert col<=cap and col<=refined
    assert all(T[u]-weights[u]>=T[v] for u in ids)
    count['atomic_column']+=3;positive+=bool(ids)
# Matched actual interval/source geometry; receivers here are finite quadrature.
R=[F(1),F(1),F(3,2),F(2)];center=[F(-1,4),F(1,4),F(0),F(1,2)]
ends=sorted({x for a,r in zip(center,R) for x in (a-r/2,a+r/2)})
cells=[]
for j,(a,b) in enumerate(zip(ends,ends[1:])):
 y=(a+b)/2;density=1+F(j%3-1,8);c=[int(abs(y-z)<r/2) for z,r in zip(center,R)]
 if any(c):cells.append(((b-a)*density,c))
m=[sum(f*c[u] for f,c in cells) for u in range(4)]
du=[F(1,5),F(1,3),F(1,2),F(2,3)];mu=[du[u]/m[u] for u in range(4)]
q=[m[u]/R[u] for u in range(4)];lam=F(9,8);qm=3*lam/4;sig=[q[u]*du[u] for u in range(4)]
assert all(qm<=v<=lam for v in q)
for alpha in (F(1,8),F(1,4),F(1,2)):
 for beta in (F(1,2),F(3,4),F(4,5)):
  if alpha>=beta:continue
  C=(lam/qm)*(1-beta+loglo(beta/alpha))
  B=[[F(0) for v in range(4)] for u in range(4)]
  ranks=[]
  for f,c in cells:
   T=[sum(mu[v]*c[v] for v in range(4) if m[v]<=m[u]) for u in range(4)];ranks.append(T)
   for u in range(4):
    if not c[u] or not T[u]:continue
    for v in range(4):
     if m[u]>F(3,2)*m[v] and alpha*T[u]<T[v]<beta*T[u]:
      mark=(1-m[v]/m[u])*F(1+(u+v)%3,3)
      B[u][v]+=f*c[v]*mu[v]*mark/(m[u]*T[u])
  kappa=[sum(sig[u]*B[u][v] for u in range(4))/sig[v] for v in range(4)]
  G=sum(sig[u]*sum(B[u]) for u in range(4))
  assert G==sum(sig[v]*kappa[v] for v in range(4))
  assert all(0<=z<=C for z in kappa)
  count['matched_incoming']+=2;positive_incoming+=G>0
  for h in (F(1,10),F(1,2),F(1)):
   witness=[sum(f*c[v]*h/(h+T[v])/m[v] for (f,c),T in zip(cells,ranks)) for v in range(4)]
   SF=sum(sig[v]*witness[v] for v in range(4))
   for threshold in (F(1,4),F(1,2),F(3,4)):
    paid=sum(sig[v]*kappa[v]*min(1,witness[v]/threshold) for v in range(4))
    rem=sum(sig[v]*kappa[v]*max(0,1-witness[v]/threshold) for v in range(4))
    hard=sum(sig[v]*kappa[v] for v in range(4) if witness[v]>=threshold)
    assert paid+rem==G and paid<=C*SF/threshold and paid>=hard
    for v in range(4):
     if witness[v]<threshold and threshold<=F(1,2):
      s=1/(2*threshold)-1
      low=sum(f*c[v]/m[v] for (f,c),T in zip(cells,ranks) if T[v]<=s*h)
      assert low<F(1,2)
    count['soft_receipt']+=3;strict_soft+=paid>hard
# Native real-center constant-mass atoms for q=1, f=1 on [-5,5].
patch=[(F(-2),F(-1),F(1)),(F(-1),F(0),F(1)),(F(0),F(1),F(3,2)),(F(1),F(2),F(2))]
for y in (F(j,16) for j in range(-64,65)):
 for r in (F(1),F(3,2),F(2)):
  atom=sum(max(F(0),min(B,y+r/2)-max(A,y-r/2))/r for A,B,R0 in patch if R0==r)
  assert 0<=atom<=1
  count['native_atom']+=1
print('PASS',count,'total',sum(count.values()),'positive_atomic_columns',positive,'positive_incoming',positive_incoming,'strict_soft_cases',strict_soft)
