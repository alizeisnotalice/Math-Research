"""256-bit scalar certificates and finite splice probes, not geometric instances."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json,sys,hashlib
import flint
from flint import arb,ctx
ctx.prec=256
E=arb(1).exp()
constants={
 'moment_factor':(F(5)*F(9,10)**16,F(1)),
 'small_S_squared':(F(1,307200),F(1,16)),
 'small_R':(F(9,59392),F(1,8)),
 'large_S_squared':(F(27,5120),F(1,16)),
 'large_R':(F(81,1024),F(1,8)),
}
cert=[]
for name,(left,right) in constants.items():
 assert left<right
 ball=arb(left.numerator)/left.denominator
 cap=arb(right.numerator)/right.denominator
 assert ball<cap
 cert.append({'name':name,'left':str(left),'right':str(right),'interval':str(ball),'pass':True})
for name,b in [('log4_below_3over2',arb(3)/2-arb(4).log()),('log5over4_below_half',arb(1)/2-(arb(5)/4).log())]:
 assert b>0
 cert.append({'name':name,'positive_gap':str(b),'pass':True})
cases=[];skips=[]
stages=[('initial',[256,257,1024]),('boundary',[2**22,2**24+1,2**26]),('expanded',[2**32,2**48])]
for stage,ns in stages:
 for n in ns:
  k=isqrt(16384*n)
  if k*k<16384*n:k+=1
  root=arb(n).sqrt();c0=arb(1)+arb(1)/(32*n);c=c0**n
  for fac in [F(1),F(5,4),F(4)]:
   T=4096*root*fac.numerator/fac.denominator;theta=T/c
   assert theta>=30*k and k>=2048
   floor=theta-1;cut=3*k+n*(c0*n/k).log()
   candidates=[('floor',floor),('floor_plus_one',floor+1),('floor_plus_theta',floor+theta),('cut_minus_one',cut-1),('cut',cut),('cut_plus_one',cut+1),('x_half',arb(n)/2),('x_one_minus',arb(n)-1),('x_one',arb(n)),('x_one_plus',arb(n)+1)]
   for tag,L in candidates:
    meta={'stage':stage,'n':n,'k':k,'T_factor':str(fac),'location':tag}
    if not tag.startswith('floor') and not L>=floor:
     skips.append(dict(meta,reason=('below domain' if L<floor else 'interval comparison unresolved')));continue
    if tag=='cut' or L>=cut:
     factor=n*(1+c0*((3*k-L)/n).exp()).log()
     assert factor<k
     moment_log=arb(5).log()-k*arb(30).log()
     assert moment_log < -3*k
     normalized_bound=arb(2)/3/c # M<=2U/c e^-2k vs target3Ue^-2k
     assert normalized_bound<1
     cases.append(dict(meta,branch='large_L',log_dilation=str(factor),log_moment_upper=str(moment_log),ratio_to_target=str(normalized_bound),pass_check=True))
    elif L<cut:
     x=L/n
     S=2*(2*E*n*x.exp()*(2*L/theta).log()).sqrt()
     R=8*E*n*x.exp()/k
     sr=S/L;rr=R/L
     assert sr<arb(1)/4 and rr<arb(1)/8
     mainlog=arb(2).log()-L+S+R
     taillog=(arb(k)/(k-1)).log()+n*(1+c0).log()-T.log()-(k-1)*n
     ratio=((mainlog+2*k).exp()+(taillog+2*k).exp())/3
     assert ratio<1
     cases.append(dict(meta,branch='moderate_L',S_over_L=str(sr),R_over_L=str(rr),ratio_to_target=str(ratio),pass_check=True))
    else:skips.append(dict(meta,reason='splice branch unresolved'))
# Conditional overhead if each subinterval's actual pointwise profile load is <= exp(k) times its old local q-load.
absorption=[]
for n in [256,257,2**22,2**48]:
 k=isqrt(16384*n)
 if k*k<16384*n:k+=1
 logfee=arb(9).log()+2*arb(n).log()-arb(k)/2
 assert logfee<0
 absorption.append({'n':n,'conditional_log_9n2_exp_minus_k2':str(logfee),'pass':True})
record={'interpreter':sys.executable,'python':sys.version,'python_flint':flint.__version__,'precision_bits':ctx.prec,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Exact rational and Arb scalar certificates plus finite parameter probes only. No full-dimensional owner family instantiated, no anchor-reuse budget certified.','constants':cert,'case_count':len(cases),'skip_count':len(skips),'cases':cases,'skips':skips,'conditional_absorption':absorption}
Path(__file__).with_name('SHORT_SAMPLE_RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'constants':len(cert),'passed_cases':len(cases),'skipped_candidates':len(skips),'branches':sorted({c['branch'] for c in cases}),'precision_bits':ctx.prec,'conditional_absorption_points':len(absorption)}))
