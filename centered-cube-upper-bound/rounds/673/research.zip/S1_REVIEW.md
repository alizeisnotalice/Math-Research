# R673：少样本local bound与真实多target共享anchor独立审查

**独立statement结论PASS。** 对同一真实有限共点来源，在n≥256、T≥4096√n、k=ceil(128√n)时，可从R662 raw(9),(C)证明

M=E| (∩_{ℓ≤k}Aᵢℓ)+c₀rQ |≤3Ue^(−2k)。

对同fixed target subinterval的一个actual anchor pool Ja，若Ta≤τ且每个接收target h满足q(Ja∩Jh)≥τ/4，则使用一条shared iid anchor sample并积分真实receiver union，严格得到

|⋃_{h∈H_a}Xh|≤3e^{−(2−log4)k}U_Ja≤3e^(−k/2)U_Ja。

没有假设全部targets有一个共同core，也没有使用target事件独立性。该式只为一个anchor的整个receiver union付款，尚未支付跨anchors重复U_Ja。

本文件先读TASK和R662必要raw小段、独立完成证明并发送父代理，再写本文；截至第8节尚未读作者S2/A1结论。主代理负责Arb计算，本代理未重跑grid或自行启动数值job。只写本S1，无spawn/Git/PDF/MATLAB或他人文件修改。

## 1. 准确family、ceiling与raw适用范围

a=32n、c₀=1+1/a、c=c₀ⁿ≤32/31；真实不交Fi⊂Q(yi,si/a)，di=(2si)ⁿ，qi=|Fi|/di。所有Ai=Q(yi,si)共点z，si≥r>0，T=Σqi、U=Σ|Fi|。label draws iid、law qi/T、有放回。零q可略；T>0保证U>0。没有si upper cutoff或来源空间坐标独立假设。

令θ=T/c、L=log[U/(c(2r)ⁿ)]，沿用真实累积容量的L≥θ−1。k=ceil(128√n)≥2048，k²≥16384n。这里要使用较精确c≤32/31，得到

θ≥3968√n， 30k≤3840√n+30≤3968√n，

故θ≥30k。仅用c≤2不能证明该30k关系，不能漏掉这一点。

已实际回读R662 REPORT的raw(9)与(B)/(C)推导。raw(9)本身只需k>α（本次α=1、k>1）、θ≥2及L≥θ−1；k≥2θ是后面推旧(10)的额外条件。本次不使用(10)或其导出的(A)。raw(C)的Young步骤只需k>0，完整low-level tail需k>1；它不要求k≥2θ。

cut L_λ=L+log(2/θ)+t≥θ−1+log(2/θ)>0、L_λ≤L+t和K=log(2L/θ)≥0也保持，故没有因少样本而丢失r以下或t>n的合法性。

## 2. raw(9)给sample-minimum一阶矩

取α=1，并将其middle integral上放到Gamma integral∫₀∞e^(−y)y^kdy=k!，得

E d_min≤(U/c)[e^(1−θ)+e k!θ^(−k)+θ^(−k)/(k−1)]。

这条仅用k>1。用k!≤k^k、θ≥30k、e<3和e³<27，将括号乘e^(3k)：第二项≤3(9/10)^k；第三项≤(9/10)^k。第一项≤e^(1−27k)≤e^(−26k)≤(9/10)^k。因此总和≤5(9/10)^k<1，最后可用k≥2048≥16与精确5(9/10)^16<1。

故u*:=(U/c)e^(−3k)满足E d_min≤u*。又u*/(2r)ⁿ=e^(L−3k)≥1，因为L≥30k−1≥3k。这一点不是从一个可能为负的log(c₀n/k)单独推出。

## 3. large-L分支不用Jensen

设h(d)=(d^(1/n)+2c₀r)ⁿ。sample halo包含于被抽中最小parent的halo，所以M≤E h(d_min)。h递增，h(d)/d递减，因此对任意d>0，

h(d)≤h(u*)max(1,d/u*)。

E d_min≤u*便给M≤2h(u*)。若

L≥3k+nlog(c₀n/k)，

则h(u*)/u*=[1+c₀e^{−(L−3k)/n}]ⁿ≤e^k。于是

M≤2(U/c)e^(−2k)≤2Ue^(−2k)。

包括分支等号，不使用不成立的concavity/Jensen。即使log(c₀n/k)<0，u*≥(2r)ⁿ仍由第2节全域lower bound保证。

## 4. complementary分支的全域覆盖

若上述large-L不成立，令x=L/n、w=k/n、v=θ/n。则

30w−1/n≤x<3w+log(c₀/w)。

这迫使w<1：否则左端至少27w−1/n>1，而log(c₀/w)≤log2<1，矛盾。故e^x≤c₀e³/w。x>0、K=log(2x/v)≥0。

在raw(C)中写S=2sqrt[2e n e^x log(2L/θ)]、R=8e n e^x/k。

若0<x≤1，用原maximum log(2y)/y²≤2/e得

S/L≤4sqrt(en)/θ<1/4。

又θ−1≥29k，故

R/L≤8e² n/[k(θ−1)]≤8e²/(29·16384)<1/8。

若x≥1，使用log(2x/v)≤2x/v、e^x≤c₀e³/w，得

(S/L)²≤16c₀e⁴ n/(θk)<1/16，

R/L≤8c₀e⁴ n/k²<1/8。

这两个strict比较只用c₀≤2、e<3、θ≥30k和k²≥16384n即可：相应上界分别为27/5120<1/16和81/1024<1/8。首式开方给S/L<1/4，故两个x分支均有S+R≤3L/8。

因此raw(C)首项≤2Ue^(−5L/8)≤2Ue^(−2k)，最后一步用L≥30k−1。x=1被两侧覆盖，无空洞；w≥1的互补域已经被证明为空，不是遗漏。

## 5. 少样本tail必须重新核算

raw(C)tail为D=[k/(k−1)](1+c₀)ⁿ(U/T)e^(−(k−1)n)。不能沿用需要k≥2θ的旧D≤Ue^(−θn)。本次使用T≥2、k≥2、1+c₀≤3、log3<2，得到

D/U≤e^{−(k−3)n}≤e^(−2k)，

后一步在n≥256、k≥2048成立，甚至n≥4、k≥6已足够。故complementary branch M≤3Ue^(−2k)。large-L branch已≤2Ue^(−2k)，最终统一得到claimed3Ue^(−2k)。

所有ceil、equalities、small/large x、small/large w、full low-level tail及finite positive sources均已保留。没有数值外推，也没有偷偷恢复k≥2T/c。

## 6. 一条shared anchor draw支付真实multi-target union

固定actual subinterval[α,β)，β/α=2^(1/n)。G={qᵢ>0,β≤si<nα}，actual Jh={i∈G:zh∈Ai}，真实Xh不交且sh<β。固定anchor Ja⊂G，其parents共点za，Ta≤τ。固定collection H_a，要求每个h满足q(Ja∩Jh)≥μ=τ/4。若collection空，union为0；否则Ta≥μ，故第1–5节local theorem的load threshold自动满足。source si≥β使local r=β合法。

在当前抽样之前冻结Ja和H_a，再从Ja以qi/Ta iid有放回抽k个labels，同一tuple用于所有h。定义E_h={全部抽样labels都属于Ja∩Jh}。则

P(E_h)=[q(Ja∩Jh)/Ta]^k≥4^(−k)。

on E_h，sample intersection含实际zh；每x∈Xh由原witness几何满足||x−zh||∞≤c₀sh<c₀β。因此整个Xh含于该sample intersection+c₀βQ。重复draw不影响containment，anchor commonpoint也保证每次sample交集非空。

记Y_a=⋃_{h∈H_a}Xh，D_sample为该共同sample halo。对Y_a中真实receiver点按其owner h，得到P(x∈D_sample)≥4^(−k)。非负Fubini于是给

4^(−k)|Y_a|≤E|D_sample∩Y_a|≤E|D_sample|≤3U_Jae^(−2k)。

没有把h的event概率相乘，也没有Σh target-count loss，更没有假设全H的common core达到μ。得到

|Y_a|≤3e^{−(2−log4)k}U_Ja≤3e^(−k/2)U_Ja。

log4<3/2可由e>8/3推出e³>16，故最后比较严格成立。receiver始终是固定真实measurable union，普通Lebesgue积分；boundary/null faces不改变体积，亦无需BV。这里是新的analytical iid anchor certificate，不是将原Poisson first-k/history改成另一分布。

## 7. 适用限制与尚未付的全族费用

- Ta≤τ是4^(−k) lower bound的重要条件；若任意anchor总load更大，应保留[q(intersection)/Ta]^k，不能仍用1/4。
- Ja、H_a须在当前anchor tuple抽样前冻结（或在使fresh tuple仍保有该iid law的conditional state下固定）。若按当前sample事后选择receivers，不能直接使用上述conditional probability。
- source≥β与target sh<β分别保证local theorem和真实receiver containment；不能混用相邻subinterval端点。
- 单anchor的U_Ja可以覆盖任意多actual receivers，但不同anchors可能重复同一Fi。任何全族cover仍需Σ_aU_Ja或对应weighted column费用；pairwise anchor intersection<μ本身不认证这个费用。
- 贪心选一个actual anchor并capture所有overlap≥μ targets能给finite cover（anchor自身被capture），但不是已付global budget。

第6节是一个真实many-receiver局部联合界，不是全familyAU。主Astra的global cover/packing若要利用它，仍需实际证明source reuse或all-space load的定量约束。

## 8. 独立阶段交付

少样本bound与共享anchor real receiver union应用均已独立审核通过。已回读R662必要原式以确认raw applicability；未读作者新稿或重复主代理Arb。待作者proof形成，仅对照上述参数/低尾/联合量词与hash，不提前作最终稿认证。只写本S1，授权阶段完成。

## 9. 追加独审：minimum-mass μ-profile的4/5联合捕获

父代理给出新精确statement，独立核验PASS；尚未据此签作者稿或全局column。

对固定subinterval的earliest uncovered seed a，在其actual Ja中取R671 minimum-owner-mass profile t_i,a，总rateμ=τ/4，0≤t_i,a≤qi。对应真实Fi^a⊂Fi不交、质量M_Ja(μ)，其parents共点za、source半径≥β，所以第1–5节少样本定理在r=β下适用。

定义capture collection为当前尚未付targets g满足

Σ_{i:zg∈Ai}t_i,a≥(4/5)μ。

collection由实际geometry/profile在当前tuple抽样前决定。一次shared iid draw的law为t_i,a/μ；对每个captured g，全部k次draw的parents都含zg的概率≥(4/5)^k。on该事件真实Xg⊂sample intersection+c₀βQ。按同一receiver union积分，得到

|Y_a|≤3exp[−(2−log(5/4))k]M_Ja(μ)
     ≤3e^(−3k/2)M_Ja(μ)。

最后用log(5/4)<1/2即可。没有target independence或sum-over-target fee。这个profile law是auxiliary certificate，原qi、Ih、first-k history未改。

seed自己的witness含于全部profile parents，field为μ，所以被capture；有限targets给finite cover。对后来seed g，在earlier a步骤它仍uncovered且未被capture，因此

Σ_{i:zg∉Ai}t_i,a>μ/5=τ/20。

这是真实retained fractional rate的positive missing margin，严格大于0，不再只是一个arbitrarily-tiny excluding label。但它只相对该earlier profile，不说明这些rate/owners在全部先前groups之外globally fresh。

后来profile t_i,g的positive support在Jg={i∈G:zg∈Ai}中。因此对ordered seed pairs严格有

Σ_i min(t_i,a,t_i,g)
≤Σ_{i:zg∈Ai}t_i,a<(4/5)μ。

非严格≤版本当然正确。此weighted-min overlap约束没有被升级为uniform column预算或anchor数量界。

## 10. 新profile证书的费用不可与旧指数重复相乘

4/5捕获不等于zg位于所有selected parents：只有占profile rate至少4/5的parents含zg。因而不能直接沿用R671 exact-intersection capture的deterministic containment；本节receiver covering必须通过上述共同tuple概率支付其(5/4)^k反因子。missing margin和pair profile separation都由新threshold直接得到。

新单anchor费用是3exp[−(2−log(5/4))k]乘**owner质量**M_Ja(μ)。不能在此之外再乘R671旧complete-intersection的e^(−μ/8)；这里已经重新使用少样本volume bound并付检测概率。若将某个已证mass inequality代入M，应单独保留其确切代数，不能将price comparison的saving计算两次。

对真实profile-anchor cover及非负weightsλ_a，全局exact sufficient charge仍为

3exp[−(2−log(5/4))k]Σ_i d_iΣ_aλ_at_i,a
=3exp[−(2−log(5/4))k]Σ_{qi>0}|Fi|Σ_aλ_at_i,a/qi。

真实subpieces跨anchors可以重叠，全部reuse仍在该column中。finite capture、positive missing rate或pair weighted-min separation本身都没有给该列和统一费用。没有新AU或general sqrt(n)结论。

## 11. 作者S2完整proof第二阶段对照

完成第1–5节独立证明后实际读取S2_SHORT_SAMPLE.md，SHA-256：

`7fa20746b242fa804fcbb4d69f9434d46a31dfa5358cd38358a407a596b4c958`。

作者(2)核对了ceil及c≤32/31；(6)明确只用raw sample tail而不用旧large-k simplification；(7)的moment、large-L cutoff与h(d)单调比值、complement w<1、small/large x exact rational ratios和D少样本tail均与独立审核一致。作者用e>2、2^29>30给moment首项更直接的30^(−k)界，也正确。无必须修改数学点，local theorem最终proof PASS。

已读主代理SHORT_SAMPLE_CHECK.py及现有结果metadata，不执行该job。记录是7个scalar certificates、145个通过point cases、95个skips和4个conditional absorption点，Python3.12.14/python-flint0.9.0/Arb256bit。它们不实例化真实owner geometry、不认证anchor reuse；全域证明依赖上述解析推导。最终数值scope/哈希待主代理最终版绑定，任何跳过地点不得当作已通过。

## 12. uniform β下seed选择、profile分离及scope更新

共同halo固定为β后，greedy anchor可以从尚未captured的actual targets中任取；也可选seed scalar M_Jh(μ)最小者、用固定次序破ties。seed自己profile field为μ，必被capture，所以finite cover仍成立。此选择只改变auxiliary grouping顺序，不改变原radius/source/Poisson order。

不再需要“captured target半径≤seed半径”。若不取earliest，则必须坚持第9节使用r=β；不能未经证明把halo替回较小seed radius。min-M选择不证明algorithm的global最优或总fee界。

特别区分R671 exact-intersection capture与本轮4/5 capture：本轮captured zg可不在20%的selected parents中，seed profile不一定支持于整组fullcommonpool。M_Ja(μ)只是seed池的minimum mass；旧R671“seed minimizer仍为captured group minimizer”不能移植。本轮整个group的price来自shared random tuple事件，不是complete-intersection theorem的e^(−μ/8)乘M。

若采用canonical one-partial profiles，令ρ_i,a=t_i,a/qi（qi=0省去）。第9节weighted-min bound和两profile总massμ给

Σqi|ρ_i,a−ρ_i,b|=2μ−2Σmin(t_i,a,t_i,b)>2μ/5。

除两个profile各自至多一个partial label外，ρ差只能0或±1；其|difference|−difference²为0。其余至多两个labels各至多1/4，再用qi≤a^(−n)，得到

Σqi(ρ_i,a−ρ_i,b)²>2μ/5−a^(−n)/2。

这是qi加权的rate-Hilbert量，不是di或|Fi|加权owner质量，也不是fresh globally-unused容量。有限profile separation本身没有支付第10节column。

## 13. 最终作者/主报告审查及条件relative-load账

实际读取A1_JOINT_COVER.md和主REPORT完整数学正文，随后定点读最终修订。**PASS，无剩余必改数学项。** A1的shared draw/Fubini真实并集、seed-only M、uniform β任意/min-M seed、q-weighted L1/L2、exact fractional费及未付column均与独立审查一致。“weaker packing alternative”已收紧为alternative，不声称pointwise load目标在逻辑上弱于所有weighted-total source预算。

A1(4.3)及REPORT的M_Ja(μ/5)≤M_Ja(μ)e^(−4μ/(5c))由R671纯几何logM′≥1/c在正rate间积分得出，不对μ/5调用local intersection theorem。它没有断言actual later witness恰好miss那个cheap prefix，也没有把rate margin换成已付owner-mass retirement。主稿明确新η只付一次、不叠旧e^(−μ/8)，捕获profile通常不是captured组的full-common-core profile。

最终新增relative-load条件账正确。令S_B(x)=Σ_{a∈B}Σ_i t_i,a1_Ai(x)、Q_B(x)=Σ_{i∈G_B}qi1_Ai(x)。若真实全空间S_B≤e^kQ_B，则可求和；因为i∈G_B意味着β≤si<nα，整个B=[α,β)都位于(si/n,si]，每source的ground-membership次数≤nL_n。因此Σ_BQ_B≤3n²τ a.e.，从而

H_b=η_nΣ_BS_B≤9n²e^(−k/2)τ≤(216/64⁴)τ。

末步用k/2≥64√n和e^x≥x⁴/24。该relative-load前提仍未证明；只有absolute逐B bound τe^k不能用source次数求和，因为丢掉了局部qi权重。主报告准确保留这一差别、原family P₀/V₀定义、原baseline zero-extension和完整far/rim总账。

## 14. 最终版本与数值scope绑定

最终实际读取版本SHA-256：

- REPORT.tex：`c2189166108598a05eef0498a91b2c87c640f8e4fcb170ac01ddb65ca0af471c`
- A1_JOINT_COVER.md：`eef523c9d2fc7e802216212ec478848c3bfb3923efcc8140bfcc220d3e33e03a`
- S2_SHORT_SAMPLE.md：`7fa20746b242fa804fcbb4d69f9434d46a31dfa5358cd38358a407a596b4c958`
- SHORT_SAMPLE_CHECK.py：`93f3c9240337ebdde60a14e77ecd6ce3cf8ee44341239b1325ecc1742804b741`
- SHORT_SAMPLE_RESULT.json：`96e0f399131e92742bc0c04a20f9ae609476997a4c562bbe839c4c4d9f4b993d`

结果metadata实际核对为7 scalar constants、145 pass（61 large-L/84 complementary；27 initial/58 boundary/60 expanded）、95全为below-domain skips、4个9n²e^(−k/2) conditional points；script digest与实际最终文件一致。没有interval未决当作pass，没有真实高维source family或column证书被构造。本代理只读代码/结果，未重复Arb job；全域和联合geometry审核是前述解析证明，不以hash或finite points代替。

**最终独审PASS。** 少样本theorem、真实many-receiver联合界及quantitative missed-rate成立；完整累计source费或全空间load仍OPEN，未证明一般AU/√n结论。只写本S1，无spawn/Git/PDF/MATLAB、无重复数值实验，交付停止。
