# R673 S2 — independent all-parameter short-sample intersection proof

**Verdict: PASS.** Under the genuine common-point/disjoint-owner assumptions below, with n>=256, T>=4096 sqrt(n), and k=ceil(128 sqrt(n)),

    E | intersection_{j=1}^k A_{i_j}+c0 r[-1,1]^n |
      <=3U exp(-2k).                                         (1)

The labels are iid with replacement of law q_i/T. In particular, the old requirement k>=2T/c is NOT imposed. The proof uses the unsimplified sample-minimum tail and the raw low-level estimate (C), both before that extra requirement was introduced in R662.

The main agent owns the actual Arb checks. Every new scalar comparison needed below is also established by an explicit exact rational bound, so the proof is not a parameter-grid extrapolation. This is a local intersection theorem, not a paid sum over anchor populations.

## 1. Assumptions and parameter ranges

Let a=32n, c0=1+1/a, c=c0^n<=32/31. The original cubes A_i=Q(y_i,s_i) contain a common point z, and s_i>=r>0. Genuine measurable F_i subset Q(y_i,s_i/a) are disjoint. Put

    d_i=(2s_i)^n,   q_i=|F_i|/d_i,
    T=sum_i q_i,   U=sum_i |F_i|,
    theta=T/c,     d0=(2r)^n,
    L=log(U/(c d0)),
    k=ceil(128 sqrt(n)).

Zero-rate sources may be omitted. The load assumption ensures T,U>0. We have

    theta >=3968 sqrt(n) >=30k,
    k>=2048,   k^2>=16384n.                                (2)

Indeed k<=128sqrt(n)+1 and 30k<=3840sqrt(n)+30<=3968sqrt(n) for n>=256. This verifies the ceiling, rather than treating k as exactly 128sqrt(n).

The cumulative real-owner bound is

    H(u):=sum_{d_i<=u}|F_i| <= min(cu,U).                    (3)

Every contributing owner lies in Q(z,c0 u^(1/n)/2), and their actual disjointness proves (3). In particular the original layer calculation gives

    T<=c[1+log(U/(c d0))],
    L>=theta-1>=30k-1.                                    (4)

Here U>=T d0>c d0, so the indicated logarithmic branch is valid. All square roots and logarithms below are in their valid ranges. In particular L>1, L>=theta/2 and log(2L/theta)>=0.

## 2. Recheck the raw sample-minimum estimate without k>=2theta

Let d_min be the smallest d_i among the k independent sampled labels. For

    Q(u)=sum_{d_i>u}q_i,

Stieltjes integration of (3), dropping only its nonpositive boundary term, gives

    Q(u)<=c[1+log(U/(cu))]  for 0<u<=U/c,
    Q(u)<=U/u              for u>=U/c.                     (5)

Also Pr(d_min>u)=(Q(u)/T)^k. Set u0=(U/c)exp(1-theta); equation (4) ensures u0>=d0. Split the nonnegative tail integral at u0 and U/c. On the middle interval substitute y=1+log(U/(cu)). For every k>1 this yields

    E d_min
      <=(U/c)[ exp(1-theta)
          + e theta^(-k) integral_1^theta exp(-y)y^k dy
          + theta^(-k)/(k-1) ]
      <=(U/c)[ exp(1-theta)
          + e k! theta^(-k)
          + theta^(-k)/(k-1) ].                             (6)

The first term used the probability bound one; the last term is the full u>=U/c tail. The middle extension to [0,infinity) is nonnegative and gives k!. No relation between k and theta other than theta>1 and k>1 was used. This is raw R662 (9) at alpha=1, not its subsequent k>=2theta simplification.

Now theta>=30k and k!<=k^k imply

    e k!theta^(-k) <= e 30^(-k),
    theta^(-k)/(k-1) <=30^(-k).

The first term also obeys exp(1-theta)<=30^(-k): since k>=1,

    exp(1-theta)<=exp(1-30k)<=exp(-29k)<30^(-k),

using e>2 and 2^29>30. Therefore the bracket in (6) is less than 5*30^(-k). With e<3, e^3<27, k>=16, and the exact integer comparison

    5*9^16=9265100944259205 < 10^16,

we obtain

    5*30^(-k)
      =5*(e^3/30)^k exp(-3k)
      <5*(9/10)^k exp(-3k)
      <=exp(-3k).

Consequently

    E d_min <= (U/c)exp(-3k).                              (7)

This is the small-sample minimum estimate actually needed for the large-L branch.

## 3. Large-L branch, including the cutoff hypothesis

Suppose

    L>=3k+n log(c0n/k).                                    (8)

Put u_star=(U/c)exp(-3k). Independently of the sign of log(c0n/k), equation (4) ensures L>=3k and hence u_star>=d0. Thus this cutoff is legitimate even when the displayed threshold in (8) has a negative logarithmic term.

The expanded sampled intersection is contained in the smallest sampled cube expanded by c0r. Its volume is bounded by h(d_min), where

    h(d)=(d^(1/n)+2c0r)^n.

The function h is increasing and h(d)/d is decreasing. Thus for every d>0,

    h(d)<=h(u_star) max(1,d/u_star).

By (7),

    E h(d_min)<=h(u_star)[1+E d_min/u_star]
                  <=2h(u_star).

Condition (8) gives

    h(u_star)/u_star
      =[1+c0 exp(-(L-3k)/n)]^n
      <=[1+k/n]^n
      <=exp(k).

We conclude

    M:=E |intersection A_{i_j}+c0r[-1,1]^n|
      <=2(U/c)exp(-2k)
      <=2Uexp(-2k).                                        (9)

Repeated sampled labels cause no change to either containment or d_min.

## 4. Recheck the raw low-level bound (C)

For the complementary branch we use the raw R662 estimate

    M<=2U exp(-L+S+R)+D,                                   (10)
    A=n exp(L/n),
    S=2sqrt(2e A log(2L/theta)),
    R=8e A/k,
    D=[k/(k-1)](1+c0)^n(U/T)exp(-(k-1)n).

Its derivation does not use k>=2theta. The precise checks are:

- Nonempty axis-parallel intersections distribute over common cubical enlargement, so M=integral (G(x)/T)^k dx for G=sum_i q_i1_{A_i+c0rQ}.
- At level lambda=Texp(-t), the raw source-layer cut is L_lambda=L+log(2/theta)+t. It is positive since theta>=2 and L>=theta-1.
- On 0<=t<=n, L_lambda<=L+t and log(1+t/L)<=t, because theta>=2 and L>=1. Thus the level-set bound with K=log(2L/theta)>=0 remains valid.
- The elementary inequality 4sqrt(eAt)<=kt/2+8eA/k holds for every k>0. Its integration gives the factor 2 in (10).
- The entire t>n tail uses integral G<=(1+c0)^nU and only k>1; this is the displayed D. No low-level tail or sample-minimum branch is dropped.

All of these hypotheses hold by (2)-(4). Only the later large-sample simplification of raw (9), unused here, needs k>=2theta.

## 5. Complementary branch: every x=L/n range

Assume (8) fails. Let

    x=L/n,   w=k/n,   v=theta/n.

We have

    x<3w+log(c0/w),   x>=30w-1/n.                          (11)

These inequalities force w<1. Otherwise c0<=2 and log 2<1 would give

    27w<log(c0/w)+1/n<2,

contradicting w>=1. Therefore

    exp(x)<=c0 exp(3)/w.                                   (12)

Every logarithm in S is nonnegative by (4).

### 5a. Range 0<x<=1

Here A<=en. Put y=L/theta>=1-1/theta>1/2. The elementary maximum

    max_{y>=1/2} log(2y)/y^2=2/e

gives

    S/L<=4sqrt(en)/theta,
    (S/L)^2<=16e n/theta^2
             <48/(30^2*128^2)
             =1/307200<1/16.                               (13)

Also theta-1>=29k, so

    R/L<=8e^2n/[k(theta-1)]
        <72/(29*128^2)
        =9/59392<1/8.                                      (14)

Thus S/L<1/4 and R/L<1/8. Both comparisons are valid for the entire x<=1 range; no unretained additive term is being suppressed.

### 5b. Range x>=1

Use log(2x/v)<=2x/v and (12). Then

    (S/L)^2
      =8e exp(x)log(2x/v)/(n x^2)
      <=16e exp(x)/(theta x)
      <=16c0 e^4 n/(theta k)
      <16*2*3^4/(30*128^2)
      =27/5120<1/16.                                      (15)

Likewise

    R/L=8e exp(x)/(kx)
        <=8c0e^4 n/k^2
        <8*2*3^4/128^2
        =81/1024<1/8.                                     (16)

These rational estimates use only c0<=2 and e<3 and retain every n,k,theta factor. They prove the proposed bounds over all dimensions, not just at sampled endpoints. The overlap x=1 is harmless.

Combining both ranges gives S+R<=3L/8, hence

    2U exp(-L+S+R)
      <=2U exp(-5L/8)
      <=2U exp(-2k),                                      (17)

because L>=30k-1 and (5/8)(30k-1)>=2k for k>=1.

## 6. The complete tail D

Since T>=2 and k>=2, [k/(k-1)]/T<=1. Also 1+c0<=3 and log 3<2. Therefore

    D/U<=exp(-(k-1-log 3)n)
        <=exp(-(k-3)n).

Now k>=2048>=6 implies k-3>=k/2, and n>=256>=4 implies (k-3)n>=2k. Thus

    D<=U exp(-2k).                                         (18)

Equations (10), (17), and (18) give M<=3Uexp(-2k) throughout the complementary branch. The large-L branch was already covered by (9). This proves (1) for every allowed parameter tuple.

## 7. Evidence scope and stop

The proof uses the same actual owner geometry as R662. It imposes no independence on source coordinates and changes no source q or original pool. Independence is only that of the replacement label draws. The original full-space source feasibility and all later global receiving questions are unaffected.

The rational scalar checks required by this author proof are explicit in (13)-(16) and the integer inequality after (6). The parent is responsible for actual local Arb/SymPy execution and records; no such run is claimed here. In particular this note does not import any unrun numerical output.

The raw equations' applicability, cutoff, ceiling, both splice branches and full low-level tail have all been checked. No correction to the candidate constants 128, 3 or 2 is necessary. No bound on repeatedly reused anchor-source mass is supplied. This bounded proof task is complete and stops here.

