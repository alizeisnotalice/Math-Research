# R673: new joint capture, full global bound still OPEN
Goal unchanged: pure C_n<=K sqrt(n), arbitrary L1, all scales, fixed Lebesgue. R658 historical synthesis/recovery done, do not restart history reading. R670 fullaccount and R669self correction retained. R672 repair interface at mostfactor2, don't redo it.

NEW independently proved shortsample theorem:
For genuine disjoint owners Fi⊂Q(yi,si/a), a=32n,c0=1+1/a,c=c0^n<=32/31, common-point parent family Ai, si>=r, n>=256,T=sumqi>=4096sqrt n,U_I=sum|Fi|,
k=ceil128sqrt n IID replacement qi/T gives E|intersection Ai_l+c0 r Q|<=3U_I e^-2k.
This does NOT require k>=2T/c. Raw R662(9) atalpha1 and(C) are applicable before the oldlargek simplification. theta=T/c>=30k,L>=theta-1. Samplemin≤(U_I/c)e^-3k via theta>=30k, k!<=k^k,5(.9)^16<1. SplitL at3k+nlog(c0n/k); largeL usesh(d)≤h(u*)max(1,d/u*) withu*=(U_I/c)e^-3k>=r-volume. Complementary rawC keepsfulltail; S/L<1/4,R/L<1/8 with explicitrationalconstants; D<=U_Ie^-2k. See S2 fullproof, not oldfinaltheorem.

NEW true many-target union price:
Fixedactual subinterval[alpha,beta), beta/alpha=2^(1/n), sourceG={positiveqi,beta<=si<nalpha}, J_h={G:zh∈Ai}, T(Jh)>5tau/16, tau16384sqrt n.
For seed a choose canonical minimum-mass REAL profilet_a supportedJa with0<=t<=q,sumt=mu=tau/4, M_a=sumdi ti. Its pieces genuine Fi subsets but mayrepeatacrossanchors.
Capture all currentlyuncoveredtargets h with W_a(h)=sum_i ti,a 1Ai(zh)>=4mu/5. IID fromt_a/mu detects eachwithprob>=.8^k. On detection realXh inside sampledintersection+c0beta Q. One shared auxiliary draw+Fubini yields deterministic |Y_a|<=3exp[-(2-log1.25)k]M_a<=eta M_a, eta=3e^-1.5k. No targetcountfactor or all-targetcommoncore. Originalq/process unchanged; thisdraw onlyproofdevice.
Seedselfcaptured -> finitecover. Uniformbeta allows any deterministicseed order; choosingmin currentM islegal and nondecreasing. NOT oldearliest seedradius. ProfileoptimalONLYseedpool, notcapturedgroupfullcommonpool. DO NOT multiplyold e^-mu8 price into eta.
Later seedb misses >mu/5=tau/20 ofoldprofilea; pairmin overlap<.8mu and L1(t_a-t_b)>2mu/5. Withcanonicalonepartial each, weighted-q L2>2mu/5-(32n)^(-n)/2. This israte separationNOT freshcapacity orownermass separation. M_Ja(mu/5)<=M_Ja(mu)e^-4mu/(5c), socheapratecanhaveexponentiallysmallmass; no claim actualmiss equalscheapportion.

EXACT unpaid globalquantity:
Vrem<=eta sum_a M_a =sum_i|Fi| eta sum_a ti,a/qi, allsubintervals included, zeroqi omitted. Or concreteb_i=eta sum_a ti,a: proving allspace sum b_i1Ai<=A tau would givepacking b/(A tau), payVrem<=A tauP0 andfinishfullaccount. Neitherboundproved. Pairwiseprofile separationdoesnotcontrolreuseonparentscontainingafixedx, andminM orderdoesnotimplydisjointportions.
An explicitly UNPROVED but less stringent sufficient target: perintervalB actualprofileload S_B(x)<=e^k Q_B(x), Q_B=sum_i∈G_B qi1Ai. Actual sourceincidence≤nL_n≤3n² then givesglobalbload≤9n²e^-k/2 tau≤(216/64^4)tau. Absolute S_B<=tau e^k for eachB wouldNOTsum via thisincidencebookkeeping; keep localqweights. Do notclaimthepremise fromscalarabsorptionchecks.
Unchanged V0<=Cadm[U+(Kfar+Kup(n))U/tau+Vrem],P0>=U/tau. GeneralallL1/allscale scope notclosed.

Actualnumeric: prescribedPython3.12.14,flint0.9.0,Arb256bit plusFraction. 7constants;145admissiblescalarprobes (61large/84moderate;stages27/58/60),95belowdomain skipped,0intervalunresolved;n256..2^48,integerceilingk,loadfactors1,5/4,4. Four conditional9n²e^-k/2 points. No geometricinputinstances instantiated, no generalproof inferredfromfinitechecks. NoMATLAB/PDF/install.
Next task: exploit this robust partial-overlap joint capture to get an actual complete weighted mass or allspace packing bound, not reprove scalar theorem or stack localfees. At most1Astra+3GPT6.1Sol; R673used1Astra2Sol, stoppedafterdeliveries. Reusecontexts. Only genuinecomputations forproofdecisions.
