# R673 A1 — minimum-mass anchors with quantitative joint capture

## Result and global status

The new short-sample theorem gives a stronger real joint cover rule. A genuine minimum-mass anchor of rate mu=tau/4 pays the union of **any number of actual same-subinterval receivers** whose witness receives at least 4mu/5 of that anchor's rate. Its fee is

    |Y_a|≤3 exp[−(2−log(5/4))k] M_a
           ≤3 exp(−3k/2) M_a,
    k=ceil(128 sqrt(n)).                                  (0.1)

Unlike full-common-core capture, a later uncaptured seed now misses more than tau/20 of every earlier anchor's retained rate. The joint estimate does not require the entire anchor support to contain all captured witnesses.

No complete weighted source-budget or all-space packing-load bound has been proved for the resulting family of anchors. The quantitative miss is real, but it is not treated as fresh source capacity, mass separation or a global debit bound. The general pure sqrt(n) goal remains open.

The short-sample scalar theorem is supplied by the completed S2_SHORT_SAMPLE.md proof and the independent S1_REVIEW.md check. Its scalar cases are not recomputed here. All original q_i, I_h, source/target order, genuine F_i and X_h, original clips, first-k histories and future-repeat masks remain unchanged. The iid samples below are auxiliary proof samples, not replacements for any original shared history.

## 1. Genuine minimum-mass anchor and the short-sample input

Work in one of the fixed source-range subintervals [alpha,beta) from R670. Every remaining actual target h has

    J_h={i∈G:z_h∈A_i},
    G={i:q_i>0,beta≤s_i<n alpha},
    T(J_h)>5tau/16,

and g_G≤1 throughout B_h. The actual X_h are disjoint. Put mu=tau/4.

For a seed a, let t_i,a be its R671 smallest-radius minimum-mass subweights:

    0≤t_i,a≤q_i,   support(t_a)⊂J_a,
    Σ_i t_i,a=mu,
    M_a=Σ_i d_i t_i,a=M_Ja(mu).                            (1.1)

Resolve equal-radius ties by one fixed label order. There is at most one partially used label. Each t_i,a is realized by a genuine measurable F_i,a⊂F_i of volume d_i t_i,a. These pieces are disjoint across labels for this anchor, but need not be disjoint from the pieces reused by other anchors.

All positively weighted parents contain the seed witness z_a and have s_i≥beta. The independently established R673 theorem therefore applies with r=beta, rate mu and owner mass M_a. For iid labels with replacement of law t_i,a/mu, set

    D_a=(intersection_{j=1}^k A_{i_j})+c0 beta Q.

It gives

    E|D_a|≤3M_a exp(−2k).                                 (1.2)

The larger-than-usual common halo beta is valid because every source has radius at least beta, while every receiver target in this subinterval has s_h<beta. No earliest-target or radius ordering of seeds is needed for this application.

## 2. One shared draw pays an arbitrary captured receiver union

Define the retained anchor rate seen by target h's actual witness as

    W_a(h)=Σ_i t_i,a 1_{A_i}(z_h).                         (2.1)

Let H_a be any collection of actual remaining targets in this same fixed subinterval such that

    W_a(h)≥4mu/5  for every h∈H_a.                         (2.2)

No joint intersection of all these target pools is assumed. For each h, the event that every sampled parent contains z_h has probability

    Pr(E_h)=[W_a(h)/mu]^k≥(4/5)^k.                         (2.3)

Repeated labels cause no change to this iid-with-replacement probability. On E_h, the sampled intersection contains z_h. By the real witness/receiver geometry,

    X_h⊂z_h+c0s_h Q⊂D_a.

Using the same draw for every target and integrating only the actual disjoint receiver pieces,

    (4/5)^k |union_{h∈H_a}X_h|
      ≤Σ_{h∈H_a}Pr(E_h)|X_h|
      ≤E|D_a intersect union_{h∈H_a}X_h|
      ≤E|D_a|.

Combining with (1.2) proves (0.1). The last simplification uses log(5/4)<1/2.

There is no independence assumption between E_h and E_g. There is no target-count factor, full-parent receiver envelope or source/receiver measure substitution. Measurable rough X_h cause no boundary difficulty in this integral argument.

This certificate already contains its full short-sample factor. It must **not** be multiplied by the older exp(−mu/8) full-core factor. Also M_a is the minimum mass of the seed pool J_a only. Captured targets can omit positively weighted anchor parents, so the selected profile need not be a feasible full common core of the captured group and need not minimize any group-common-core price.

## 3. An actual greedy cover with quantitative miss

The following finite auxiliary procedure covers all remaining targets in the subinterval.

1. Among uncovered targets choose a seed a. One permitted choice is a target minimizing the already defined M_Jh(mu), with a fixed tie rule.
2. Construct its real minimum-mass profile (1.1).
3. Assign to this anchor all still-uncovered actual targets satisfying (2.2), then remove them from the uncovered list.
4. Repeat until none remain.

The seed always satisfies W_a(a)=mu, so at least one target is removed each step. The actual X_h are assigned once, and each anchor's assigned receiver union has the bound (0.1).

If the minimum-mass seed rule is used, selected anchor masses are nondecreasing, and each target captured at a stage has its own M_Jh(mu) at least that stage's anchor mass. This ordering is legitimate because beta is a common halo for the subinterval. No cumulative budget is inferred from the ordering itself.

For distinct selected anchors a before b, noncapture gives the strict quantitative miss

    Σ_i t_i,a 1_{A_i^c}(z_b)>mu/5=tau/20.                 (3.1)

Let rho_i,a=t_i,a/q_i for positive original q_i. Since the support of t_b lies in J_b,

    Σ_i min(t_i,a,t_i,b)
      ≤Σ_{i:z_b∈A_i}t_i,a<4mu/5.

Both profiles have total rate mu, and hence

    Σ_i q_i|rho_i,a−rho_i,b|>2mu/5.                        (3.2)

This is an exact weighted L1 separation, with no q_max loss. For completeness, each canonical prefix has at most one partial label. At all other coordinates the difference of the normalized profiles is 0 or ±1. Therefore

    Σ_i q_i(rho_i,a−rho_i,b)^2
      >2mu/5−a^(−n)/2,                                  (3.3)

because the difference between absolute value and square can occur on at most two partial-label coordinates, each contributing at most q_i/4≤a^(−n)/4.

The weights in (3.2)–(3.3) are source rates q_i, not owner masses d_i q_i. These inequalities do not assert disjoint new owner pieces. They do not by themselves establish a bound on the number or weighted total price of anchors.

## 4. Exact accumulated price and the unresolved global geometry

Let

    eta_k=3 exp[−(2−log(5/4))k]≤3exp(−3k/2).

For a nonnegative weighted cover by anchors, with weights lambda_a and coverage of the actual remaining receivers, the exact available whole-family account is

    V_rem≤eta_k Σ_a lambda_a M_a
          =Σ_{i:q_i>0}|F_i|
                 [eta_k Σ_a lambda_a(t_i,a/q_i)].          (4.1)

The greedy partition from §3 uses lambda_a=1. Fractional alternatives are allowed only if their actual receiver coverage is proved. Source portions reused across anchors are charged with their actual fractions every time; their overlap is not discarded.

A proof that the right side of (4.1) is at most A U would finish the remaining receiver payment. An alternative packing route remains available: define

    b_i=eta_k Σ_a lambda_a t_i,a.

If one could prove the original-parent all-space load bound

    Σ_i b_i1_{A_i}≤A tau a.e.,                             (4.2)

then b/(A tau) would be a genuine original-family feasible packing and its objective would pay the same sum in (4.1) through P0. Neither (4.1)'s source budget nor (4.2)'s load bound is proved here.

The quantitative miss removes the R671 defect of arbitrarily small missing **rate**, but not the source-mass repetition problem. In particular:

* The q-weighted separation can occur on labels outside the set of parents containing a different fixed point x. It need not separate the repeated profiles on those parents which contribute to the load in (4.2).
* A rate loss need not be a comparable owner-mass loss. Within a real minimum-mass prefix, R671's geometric growth gives

      M_a(mu/5)≤M_a(mu) exp[−4mu/(5c0^n)].                 (4.3)

  Thus its genuine smallest-radius portion has rate mu/5 but can have exponentially smaller mass than the full prefix. This does not assert that a later witness actually misses exactly that portion; it identifies the additional geometric statement that would be needed to turn (3.1) into a mass debit. No such exclusion of cheap-prefix losses has been proved.
* Minimum-mass ordering only compares M-values. It does not make the real portions used by successive anchors disjoint, and it does not show that large source-mass reuse forces 80-percent rate capture.

All actual geometric information is still present: fixed G, common source radii, source-center admission, genuine disjoint F_i/X_h, high witness load and low load on whole B_h. The attempted cumulative argument stopped at the absence of a bound converting these constraints and (3.1) into the weighted price in (4.1) or the all-space load in (4.2). No orthant/arrangement count or pairwise-separation heuristic is substituted for that bound.

The argument is applied to every fixed subinterval, not to a special source or function class. The known finite near-window scale bookkeeping remains available, but it does not pay the currently unknown accumulation within a subinterval. No unproved per-source cap is declared necessary for the original goal.

## Verification and bounded stop

Only the delivered statement and exact hypotheses of S2_SHORT_SAMPLE.md were read for this application; its scalar proof and the main agent's numerical verification were not duplicated. The independent S1 reviewer separately checked the 4/5 joint application, the distinction between seed mass and group common-core mass, and the weighted-rate separation before final file binding.

No numerical experiment, MATLAB session, abstract incidence scan, Git operation, PDF compilation, child agent or edit to another agent's file was performed. The strongest new joint result is (0.1), valid for arbitrarily many actual receivers without an all-target common core, together with the real positive miss (3.1). The complete accumulated source or packing budget remains open. Work stops here.
