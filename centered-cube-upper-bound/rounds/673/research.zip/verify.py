from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for name in ('SHORT_SAMPLE_CHECK.py','verify.py'):ast.parse((p/name).read_text())
r=json.loads((p/'SHORT_SAMPLE_RESULT.json').read_text())
assert r['precision_bits']==256 and r['case_count']==len(r['cases'])==145
assert r['skip_count']==len(r['skips'])==95
assert all(x['pass_check'] for x in r['cases'])
assert all(x['reason']=='below domain' for x in r['skips'])
assert len(r['constants'])==7 and all(x['pass'] for x in r['constants'])
assert len(r['conditional_absorption'])==4 and all(x['pass'] for x in r['conditional_absorption'])
assert r['script_sha256']==hashlib.sha256((p/'SHORT_SAMPLE_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text();stack=[]
assert s.count(chr(92)+'begin{document}')==s.count(chr(92)+'end{document}')==1
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
for name in ('REPORT.tex','A1_JOINT_COVER.md','S2_SHORT_SAMPLE.md','SHORT_SAMPLE_CHECK.py','SHORT_SAMPLE_RESULT.json'):
 assert hashlib.sha256((p/name).read_bytes()).hexdigest() in (p/'S1_REVIEW.md').read_text(),name
m=p/'MANIFEST.json'
if m.exists():
 for name,v in json.loads(m.read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, saved scalar records, syntax and final audit bindings; not mathematical proof verification','manifest_checked':m.exists()}))
