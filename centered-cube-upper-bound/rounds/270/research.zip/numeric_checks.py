#!/usr/bin/env python3
"""R270 actual common-soft loss and offcore tail diagnostics."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 f=F(x);return mp.mpf(f.numerator)/f.denominator
def phi(u):
 u=abs(u)
 if u<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-u)-mp.expint(3,mp.mpf('.5')+u)
 return mp.expint(3,u-mp.mpf('.5'))-mp.expint(3,u+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L
def qint(fn,a,b,knots):
 if b<=a:return mp.mpf(0)
 pts=sorted(set([a,b]+[v for v in knots if a<v<b]));return sum(mp.quad(fn,[x,y]) for x,y in zip(pts,pts[1:]))
def menu():return [(8,'1/2','same','0','0'),(8,'1/2','plus','0','1/n'),(8,'1','same','1/1000000','logn/n'),(8,'3/4','plus','3/5','1/2'),(64,'1/2','same','root_minus','1/n'),(64,'1/2','plus','root_plus','logn/n'),(64,'1','same','0','1/2'),(64,'3/4','plus','2','0'),(512,'1/2','plus','0','1/n'),(512,'3/4','plus','11/10','logn/n'),(4096,'1','same','4','1/2'),(4096,'1/2','same','1/100000000','1/n')]

def run(dps):
 with mp.workdps(dps):
  c0=phi(mp.mpf('1.5'));alpha=c0/8;beta=c0/40;rows=[];root=mp.findroot(lambda r:C(r)-mp.mpf('.5'),(.6,.8))
  for n,ls,As,Ds,ss in menu():
   L=mm(ls);A=L if As=='same' else min((1+mp.mpf(1)/n)*L,mp.mpf(1));D=root+(-1 if Ds=='root_minus' else 1)*mp.mpf('1e-10') if Ds.startswith('root_') else mm(Ds)
   s=mp.mpf(1)/n if ss=='1/n' else mp.log(n)/n if ss=='logn/n' else mm(ss);assert 0<=s<=mp.mpf('.5')
   epsilon=mp.mpf('.5')/(8*mp.sqrt(n));h=(1+epsilon)/2;cr=C(D);om=min(mp.mpf(1),cr/L);knots=[-L/2,L/2,D-A/2,D+A/2]
   integrand=lambda x:L*P(s,L,x)*P(s,A,x-D)/om
   I=qint(integrand,-h,h,knots)
   core=qint(integrand,-L/2,L/2,knots)
   sh=lambda x:s*phi(x/L)*(1-s)*(1 if abs(x-D)<A/2 else 0)/A/om
   softsoft=lambda x:s*s*phi(x/L)*phi((x-D)/A)/A/om
   mixed=qint(sh,-h,-L/2,knots)+qint(sh,L/2,h,knots)
   SS=qint(softsoft,-h,-L/2,knots)+qint(softsoft,L/2,h,knots)
   u=mixed+SS;assert abs(I-core-u)<mp.mpf('1e-40')
   bound=1-alpha*(1-cr)-beta*s+epsilon*s*s;tailbound=s*(30*(1-cr)+mp.mpf(2)/n)+(1+epsilon)*s*s
   assert I<=bound+mp.mpf('1e-40') and u<=tailbound+mp.mpf('1e-40')
   if I and u:
    # Stable I^n-core^n; log1p handles tiny positive u/I.
    logI=n*mp.log(I);diff=-mp.expm1(n*mp.log1p(-u/I)) if core else mp.mpf(1);off=mp.exp(logI)*diff;logoff=logI+mp.log(diff)
   else:off=mp.mpf(0);logoff=mp.ninf
   rows.append({'stage':'initial' if n==8 else 'stress' if n==64 else 'expanded','n':n,'L':ls,'A_mode':As,'A':enc(A),'D_input':Ds,'D':enc(D),'s_input':ss,'s':enc(s),'epsilon':enc(epsilon),'C_D':enc(cr),'Omega':enc(om),'saturated':cr>=L,'I':enc(I),'I_bound':enc(bound),'I_margin':enc(bound-I),'core':enc(core),'tail_u':enc(u),'tail_mixed_SH':enc(mixed),'tail_SS':enc(SS),'tail_decomposition_residual':enc(abs(I-core-u)),'tail_bound':enc(tailbound),'tail_margin':enc(tailbound-u),'tensor_Delta':enc(n*(1-cr)),'tensor_I_power_n':enc(I**n),'tensor_offcore':enc(off),'tensor_log_offcore':enc(logoff),'tensor_offcore_fraction':enc(off/I**n) if I else None})
  return {'c0':enc(c0),'alpha0':enc(alpha),'beta0':enc(beta),'cases':rows}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','L','A_mode','D_input','s_input']:
    try:
     val=mp.mpf(v)
     if mp.isfinite(val):out[path+k]=val
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(50);hi=run(80)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);print('precision_diagnostic',worst,md,flush=True);assert diff[worst]<mp.mpf('1e-20')
 out={'schema':'R270-commonsoft-tail-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_cases_per_precision':12,'stages':{'initial':4,'stress':4,'expanded':4},'source_tail_decompositions_per_precision':12,'repeated_tensor_diagnostics_per_precision':12,'precision_fields_compared':len(diff)},'mp50':lo,'mp80':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'scope':['Actual continuous one-coordinate same-soft kernels with b1,a.5,s<=.5,L in[.5,1],A=L or min(gamma L,1),W side1+epsilon,epsilon=.5/(8sqrt n). Source and target hard endpoints explicitly split.','The normalized offcore tail u is split into mixed SH (source soft,target hard) and SS; source hard vanishes off its own core. I,core and both tails are independently integrated.','Repeated-coordinate tensor offcore I^n-core^n uses log1p/expm1 to avoid cancellation. No unspecified C/n exp(-alpha Delta/2) comparison has been invented.','Working precision is50/80 digits; the actual cross-precision difference is reported rather than assuming50 digits accuracy, with displayed-field tolerance1e-20. Ordinary mpmath quadrature is not interval certification. These finite candidate checks do not prove universal bounds, original FULL/history/gate qualifications, or dimension order.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
