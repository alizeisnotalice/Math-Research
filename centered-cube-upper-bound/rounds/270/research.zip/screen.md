# R270 independent statement screen

**Verdict: PASS for the stated fixed-parameter same-soft square and off-core column theorem.** This screen precedes author-proof reading. It establishes no source/posterior payment or general closure.

Assume integer n≥1, 0<a≤b≤2a, d=a/(8√n), ε=d/b≤1/(8√n), γ=1+1/n, a≤L≤A≤min(γL,b), and 0≤s≤1/2. All cubes have full side length. Keep the original C=h*max(h,φ), Ω_i=min(1,bC_i/L), Δ_i=1−C_i, W=Q_(b+d)(y), and positive physical weight barw_L=product Ω_i. Set

    c0=φ(3/2), α0=c0/8, β0=c0/40, Δ=sum_i Δ_i.

The old proven facts used are HH≤1−c0Δ_i, each mixed normalized column≤1, SS≤1+ε, φ≤φ(0)<4/5, 0<c0≤1. These refer to the original fixed receiver measure, not a source probability or node FIRST.

## 1. New coordinate square loss

Both mixed terms also obey ≤φ(0)/C_i. For source-hard/target-soft, use height φ(0), source core length L, and L/(AΩ_i)≤1/C_i. For source-soft/target-hard, the hard target support has length at most A and Ω_i≥C_i. Hence both are at most m_i=min(1,φ(0)/C_i).

The one-coordinate normalized column I_i satisfies

    I_i ≤ 1−c0Δ_i(1−s)^2−2s(1−s)(1−m_i)+εs²
        ≤ 1−α0Δ_i−β0s+εs².                 (S1)

Indeed, HH contributes at least c0Δ_i/4. Reserve c0Δ_i/8 for the first claimed loss. If C_i<9/10, its remaining c0Δ_i/8 exceeds c0/80≥c0s/40. If C_i≥9/10, m_i≤8/9 and the mixed loss is at least s/9≥c0s/40. Equality cases s=0 and C_i=9/10 cause no gap. Thus there is a uniform soft loss as well as the fixed source-distance loss.

## 2. Actual first-exit tail

Let r_i=|y_i−v_i|/b. The source off-core coordinate means |x_i−y_i|>L/2. Source-hard terms vanish almost everywhere there, so only source-soft/target-hard and source-soft/target-soft remain.

For the former, the target hard interval outside the source core has length at most (A−L)+2br_i. Thus its unweighted SH tail is at most

    min(1, φ(0)[(A−L)+2br_i]/(AΩ_i)).

If C_i<9/10, mixed≤1 and Δ_i>1/10 give the proposed bound immediately. If C_i≥9/10, monotonicity and C(1)≤φ(0)<4/5 imply r_i<1. The exact expression

    C(r)=1−r+integral_(1/2)^(1/2+r) φ(u)du,  0≤r≤1,

implies Δ_i≥(1−φ(0))r_i>r_i/5. Also Ω_i≥C_i≥9/10, (A−L)/A≤1/n, and b/A≤2. Consequently

    φ(0)[(A−L)+2br_i]/(AΩ_i)
      ≤ 8/(9n)+(32/9)r_i
      ≤ 30Δ_i+2/n.

The larger proposed constants therefore have slack. Clipping A=b is harmless because A≤γL still holds. Restricting to W can only reduce this tail.

Including soft coefficients, the coordinate off-core tail T_i obeys

    T_i ≤ s(30Δ_i+2/n)+(1+ε)s².              (S2)

The last term follows from the whole SS column, not an unproved SS boundary decay. No original score k_t is identified with a soft label.

## 3. Tensor union and the 1/n gain

For F²=P_s,L(x−y)P_s,A(x−v)/barw_L(y,v), define the dimensionless actual off-core column

    Zoff=L^n integral_W 1_{2||x−y||∞>L} F² dx.

A product first-exit decomposition, or the positive union bound, yields

    Zoff ≤ sum_i T_i product_(k≠i) I_k.

Using (S1) in exponential form and (S2), including the omitted coordinate explicitly, gives

    Zoff ≤ exp(α0+β0/2)
       [30sΔ+2s+(9/8)ns²]
       exp(−α0Δ−β0ns+nεs²).                (S3)

This is a genuine dx tensor identity/bound at fixed parameters; it makes no tensor assumption on β,ν or Π.

Halo absorption is uniform in all n, not merely asymptotic. With z=√n,

    nεs²−(β0/2)ns
      ≤ zs²/8−(β0/2)z²s
      ≤ s³/(128β0)≤1/(1024β0).

Retain half the distance exponent and half the soft exponent. The elementary maxima

    sup_D D exp(−α0D/2)=2/(eα0),
    sup_s s exp(−β0ns/2)=2/(eβ0n),
    sup_s ns² exp(−β0ns/2)=16/(e²β0²n)

then prove the explicit uniform statement

    Zoff ≤ C*/n · exp(−α0Δ/2),               (S4)

where one valid absolute constant is

    C*=exp[α0+β0/2+1/(1024β0)]
         [120/(α0β0e²)+4/(β0e)+18/(β0²e²)].

The maxima may be taken over all nonnegative s,D, which only weakens the bound. In particular n=1 and s=0 are covered, without treating an infinite list of small dimensions separately. The earlier analytic c0>1/128 makes C* an absolute finite constant. The numerical value of that constant is not needed as proof.

## 4. Scope for later use

The 1/n gain is a fixed-parameter, same-soft, source-off-core normalized square-column estimate. It keeps half the fixed Δ_b damping. It does not yet remove a scale/soft menu, justify an adaptive envelope, carry original posterior weights through receiver integration, sum j bands, or pay a source norm. Such steps need their own stated interfaces and costs. The J target σ=1 is not covered by this same-soft soft-loss statement. The physical scales, clipped target, and full W are unchanged.

## 5. Independent bounded diagnostic (not the proof)

Actually executed ordinary mpmath at 35 dps on eight one-coordinate configurations, checking (S1) and the SH tail (16 inequalities), including n=1,2,16,512, saturated/non-saturated weights and clipped A. Output:

    phi0 0.55679127144964308526 c0 0.079558587399944243651
    PASS 8 genuine one-coordinate square and SH-tail configurations (16 inequalities)

This is finite non-interval evidence, not an all-dimensional or FULL certificate. Reproduce with Python and mpmath; the following is the exact executed mathematical script.

```python
import mpmath as m
m.mp.dps=35
E=lambda k,x:m.expint(k,x)
def phi(x):
    x=abs(x)
    return (E(3,x-m.mpf('.5'))-E(3,x+m.mpf('.5')) if x>=m.mpf('.5')
            else 1-E(3,m.mpf('.5')-x)-E(3,m.mpf('.5')+x))
def C(r):
    return (1-r+E(4,0)-E(4,r)+E(4,r+1)-E(4,1) if r<=1
            else E(4,r-1)-2*E(4,r)+E(4,r+1))
phi0=phi(0);c0=phi(m.mpf('1.5'))
print('phi0',m.nstr(phi0,20),'c0',m.nstr(c0,20))
cases=[(1,'.5','0','.5'),(1,'.8','.1','.1'),(2,'.5','.3','.5'),
       (2,'1','1.2','.5'),(16,'.5','.1','.5'),(16,'.9','.6','.1'),
       (512,'.5','0','.5'),(512,'1','1.2','.1')]
for n,L0,r0,s0 in cases:
    L=m.mpf(L0);r=m.mpf(r0);s=m.mpf(s0)
    A=min(1,(1+m.mpf(1)/n)*L)
    d=m.mpf('.5')/(8*m.sqrt(n));w=1+d
    om=min(1,C(r)/L);Delta=1-C(r)
    def f(x):
        return (1-s)*int(abs(x)<=m.mpf('.5'))+s*phi(x)
    cuts=sorted(set([-w/2,w/2]+[x for x in [-L/2,L/2,r-A/2,r+A/2]
                               if -w/2<x<w/2]))
    I=m.fsum(m.quad(lambda x:f(x/L)*f((x-r)/A)/(A*om),[lo,hi])
             for lo,hi in zip(cuts,cuts[1:]))
    SH=m.fsum(m.quad(lambda x:phi(x/L)/(A*om),[lo,hi])
              for lo,hi in zip(cuts,cuts[1:])
              if abs((lo+hi)/2)>L/2 and abs((lo+hi)/2-r)<A/2)
    assert I<=1-c0*Delta/8-c0*s/40+d*s*s+m.mpf('1e-28')
    assert SH<=30*Delta+m.mpf(2)/n+m.mpf('1e-28')
print('PASS 8 genuine one-coordinate square and SH-tail configurations (16 inequalities)')
```

# Addendum: off-core prefix Abel, boundary flux, and a weighted soft grid

**Independent verdict: PASS for the following fixed-kernel adaptive extension**, with an essential shell term. No original source/posterior payment is asserted by this extension.

## A. Exact finite prefix and its extra shell

Fix y,v,s and the common W. Write F_i²=a_i B_i² at ordered scales ell≤L_1<...<L_m≤b; here a_i is scalar in the receiver x, is nonincreasing, and B_i² is nondecreasing. Put B_0²=0 and r(x)=2||x−y||_infinity. For each receiver, allowed scales r>L_i form a prefix. Positive telescoping proves

    max_i 1_{r>L_i} a_i B_i²
      ≤ sum_i a_i 1_{r>L_i}(B_i²−B_(i−1)²).

After integration the RHS equals, exactly,

    a_m integral_{r>L_m} B_m²
    + sum_(i<m)(a_i−a_(i+1)) integral_{r>L_i} B_i²
    + sum_(i<m) a_(i+1) integral_{L_i<r≤L_(i+1)} B_i².       (A1)

The final line is positive and cannot be omitted or replaced by ordinary off-core Abel. The first two lines are bounded by 2 ell^(-n) times the normalized uniform fixed-L off-core bound: this uses a_(i+1)/a_i≥(L_i/L_(i+1))^(2n) and 1−z²≤2(1−z).

Take nested finite grids including ell,b, with mesh tending to zero. They recover the measurable scale supremum using the original hard-kernel one-sided convention and limits. In the shell sum at a point ell<r<b, the lower grid scale approaches r from below. Consequently its integrand tends to F_(r−)(x)². For fixed finite y,v,n the scales lie in a compact positive interval, C_i>0, Ω_i have a positive lower bound, and the receiver support is the fixed compact W. A uniform bounded dominator therefore justifies the shell limit by dominated convergence. This argument is only at the kernel level and does not invent a uniform dominator over original sources.

The source boundary trace is s φ(1/2), taken from outside the hard source core. A synchronous target hard jump also uses its left trace; it must not be treated as an automatically included hard-boundary value. Bounding that trace above by the closed target indicator is legitimate for the estimates below. Ties between multiple source faces are lower-dimensional receiver sets, irrelevant to the coarea integral.

## B. Self-contained face-column bound

At a source face x_i−y_i=±L/2, the target factor divided by Ω_i is at most e^4, uniformly in A∈[L,min(γL,b)] and the displacement.

For r_i≤1, Ω_i≥C(1)>1/12. Indeed

    C(1)=integral_0^1 t²(1−exp(−1/t))²dt >1/12.

Thus the whole target profile (bounded by one) divided by Ω_i is <12. For r_i≥1, the target hard factor is zero almost everywhere unless a boundary equality occurs, where its upper indicator bound still satisfies the previous endpoint estimate. The soft argument is at least r_i−1/2. Also C(r_i)≥φ(r_i+1/2). On x≥1/2,

    φ(x)=integral_0^1 t(1−exp(−1/t)) exp[−(x−1/2)/t]dt.

Its logarithmic hazard is nonincreasing (positive Laplace mixture) and its initial value is less than 2/(1−exp(−1))<4. Hence

    φ(r_i−1/2)/C(r_i)
      ≤ φ(r_i−1/2)/φ(r_i+1/2) ≤ exp(4).

This proves the face bound. The endpoint r_i=1 is harmless; the target left trace cannot add a positive hard mass beyond the bound.

The l-infinity coarea formula, with its L/2 face velocity in each sign, now yields the outside-source trace flux per dlog L:

    Flux(L) ≤ exp(4) exp(α0+β0/2) n s L^(-n)
              exp[−α0Δ−β0ns+nεs²].                         (A2)

Other coordinates are integrated over the source-face rectangle, contained in their W intervals; their full I_k bounds from (S1) therefore apply as upper bounds. The missing face-coordinate distance/soft exponent costs at most exp(α0+β0/2). There is no extra n from a separate coordinate union after (A2). Since

    integral_ell^b L^(-n) dlog L ≤ ell^(-n)/n,

the shell contributes a constant times s ell^(-n), and optimization in s gives the desired 1/n. In particular an arbitrary count of scale nodes has not been charged as a free constant.

## C. Keep soft damping, then sum nodes

The same halo completion of the square gives

    exp[−β0ns+nεs²] ≤ exp[1/(1024β0)] exp[−β0ns/2].

Optimize only half the remaining soft damping, retaining exp(−β0ns/4). From (S3), one valid fixed-column constant with this retained damping is

    Ct=exp[α0+β0/2+1/(1024β0)]
       [240/(α0β0e²)+8/(β0e)+72/(β0²e²)].

By (A2), the shell constant can be taken as

    Cs=exp[4+α0+β0/2+1/(1024β0)]·4/(β0e).

Thus for each fixed s∈[0,1/2], including s=0 separately as a zero off-core kernel,

    integral_W sup_(L∈[ell,b]) 1_{r>L} F_L² dx
      ≤ (2Ct+Cs)/n ·ell^(-n) exp(−α0Δ/2) exp(−β0ns/4).    (A3)

For the full same-soft interval, choose s_i=i/[2(n+1)], i=0,...,n+1, and round s upward. For i≥1, consecutive survival ratios give P_s≤e P_(s_i) for each of the two common-soft densities, so F_s²≤e² F_(s_i)². Node zero has identically zero source-off-core kernel. Since n/[2(n+1)]≥1/4,

    sum_(i=1)^(n+1) exp(−β0 n s_i/4)
      ≤ 1/[exp(β0/16)−1].

Combining with (A3) proves a bound with no soft-node count M:

    integral_W sup_(0≤s≤1/2,L∈[ell,b]) 1_{r>L} F_(s,L)² dx
      ≤ e²(2Ct+Cs)/[exp(β0/16)−1]
          ·ell^(-n)/n·exp(−α0Δ/2).                       (A4)

This is the fixed-y,v, same-soft moving-kernel theorem. It permits the original target choices A=L or min(γL,b). It supplies no J gap, no node FIRST, no original Π exchange, and no automatic all-source or signed-traffic payment.

## D. Actual bounded finite algebra check

Independently executed 21 exact Fraction finite-prefix configurations, including r at grid endpoints. All passed both the prefix inequality and exact Abel-plus-shell identity. This is bookkeeping evidence, separate from the coarea/limit proof above.

```python
from fractions import Fraction as F
checks=0
for n in (1,2,4):
    ls=[F(1),F(5,4),F(3,2),F(2)]
    aa=[x**(-2*n) for x in ls]
    bb=[F((i+1)**2,3) for i in range(4)]
    for r in (F(3,4),F(1),F(9,8),F(5,4),F(7,4),F(2),F(9,4)):
        val=max([F(0)]+[aa[i]*bb[i] for i in range(4) if r>ls[i]])
        rhs=sum(aa[i]*(bb[i]-(bb[i-1] if i else 0))
                for i in range(4) if r>ls[i])
        tail=aa[-1]*bb[-1]*int(r>ls[-1])+sum(
            (aa[i]-aa[i+1])*bb[i]*int(r>ls[i]) for i in range(3))
        shell=sum(aa[i+1]*bb[i]*int(ls[i]<r<=ls[i+1]) for i in range(3))
        assert val<=rhs
        assert rhs==tail+shell
        checks+=1
print('PASS',checks,'exact finite-prefix/Abel-shell configurations')
```

# Addendum: original posterior/clock and source-cap bridge

**Independent statement verdict: PASS, conditional on the original R266/R267 row and common-leaf qualifications retained verbatim.** This is a response/source-fraction theorem, not a claim that every original source is paid.

Let Cenv=2Ct+Cs from (A3), G=[exp(β0/16)−1]^(-1), and

    Cstar=4 exp(2) G Cenv,   H(y,v)=exp[−α0Δ_b(y,v)/4].

Each same-soft moving kernel has (A4). The norm of the sum of the two moving kernels costs at most twice their common norm, hence its squared envelope is at most

    (Cstar/n) a^(-n) H(y,v)^2.

This accounts for the factor four; no further soft-node count M is due. The fixed-distance H is independent of original receiver x, selectors and auxiliary time. With the actual good-upper-score direction, the nonnegative original pair traffic can be bounded using delta_good≤k_good and the full other posterior mass≤1. Applying the already proved original-time R266 weighted-clock theorem to the complete Π_(y,j,t), rather than replacing it by a relative-clock law, gives

    Aoff = sqrt(Cstar/n) a^(-n/2) B_(α0/4).

Its hypotheses and the genuine off-core support mask remain necessary. In particular this step has not changed the posterior carrier, good set, high/history gates, or original source normalization. The external scale comparison remains the one original Cout, not a second rounding fee.

Using the actual disjoint j receiver masks gives a full moving row bound J0 Aoff², with J0≤n+2 and J0/n≤3. For any source σ≤β satisfying the window cap σ(Q_(b+d)(x))≤tau for every receiver, the original all-p source theorem at p=2 and Young yield

    Poff,mov,σ ≤ epsilon_mov X
      + [Cout²/(4 epsilon_mov)] Cstar B_(α0/4)²
        (J0/n) [tau/(lambda a^n)] Wσ.

Taking tau=lambda a^n sqrt(n) therefore gives a genuine root-scale source-mass coefficient, with B_(α0/4)=O(log(n+2)) and all absolute constants displayed. In original constants Cout²/4=256 Lambda² K gamma^n/27. Common-leaf receiver control, not source-leaf disjointness alone, is what permits the single X error term.

The J leg is independently bounded by the old uniform-v p=3/2 row with s0=1/2 and M≤n+2. Source-cap substitution leaves the explicit factor

    n^(1/4) J0 M (n log(2)/4)^(3/2)
      exp[−cJ n/2 + (n ε/2)(exp(cJ)+1/2)]

in addition to its original c_p,Cout,c_n and epsilon_J factors. Since nε≤sqrt(n)/8, this is a fixed polynomial times exp(−cJ n/2+O(sqrt(n))). It is asymptotically bounded by a root-scale/polylogarithmic envelope, with possibly enormous constants depending on the already fixed cJ and original K. This argument does not assert practical finite-n suppression. The factor n^(1/4), J0 and M must remain in the exact finite-dimensional formula. J does not borrow the new same-soft gap.

Use the same σ for the three original allocated legs, with epsilon_mov+epsilon_J=epsilon; no additional signed negative credit is used. R268's general-tau filling construction supplies a final σ_infinity(tau) with the window cap, applied only once at its final source mass. For the **new booked branch**, restrict to R≥L and source-off-core and to the original already defined low-soft range. Only theta_267 β was previously paid there, so

    zeta=σ_infinity(tau)−theta_267 β≥0

is the extra source allocation, with its own Wzeta fee. This positivity follows from the initial capped fraction at this tau and monotone filling, not from comparing limiting algorithms at different tau. R269 reverse sources are not rebooked; R268 forward core is excluded. The broader s≤1/2 kernel/source theorem is available only when all its original qualifications hold and is not silently registered as payment of previously unassigned wider-soft traffic. The complementary source and other unpaid domains remain.

A bounded independent Fraction bookkeeping run checked Cout's 256/27 coefficient and the powers of a/J0 bounds for n in {1,2,16,512}; it is algebra evidence only, not a physical/FULL verification. No old physical numerical suite was rerun.
