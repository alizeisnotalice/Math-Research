#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
from fractions import Fraction as Q
checks=0
for N in range(1,9):
    a=[Q(1,i+1) for i in range(N)]
    B=[Q((i+1)**2,3) for i in range(N)]
    for p in range(N+1):
        lhs=max([a[i]*B[i] for i in range(p)]+[Q(0)])
        rhs=sum(a[i]*(B[i]-(B[i-1] if i else 0)) for i in range(p))
        assert lhs<=rhs
        checks+=1
for N in range(2,9):
    a=[Q(1,i+1) for i in range(N)]
    B=[[Q((i+1)*(r+1)+i*i,7) for r in range(N+2)] for i in range(N)]
    V=[sum(B[i][r] for r in range(i+1,N+2)) for i in range(N)]
    left=sum(a[i]*sum(B[i][r]-(B[i-1][r] if i else 0)
             for r in range(i+1,N+2)) for i in range(N))
    right=(a[-1]*V[-1]+sum((a[i]-a[i+1])*V[i] for i in range(N-1))
           +sum(a[i]*B[i-1][i] for i in range(1,N)))
    assert left==right
    checks+=1
print('Exact Fraction prefix/rearrangement assertions:',checks)

if not args.check_only:
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'result.json'
  subprocess.run([sys.executable,str(root/'numeric_checks.py'),'--output',str(out)],check=True)
  assert out.read_bytes()==(root/'numeric_checks.json').read_bytes(),'numeric replay differs'
 print('Full numerical replay byte-identical')
print('Manifest and exact algebra PASS')
