#!/usr/bin/env python3
"""Exact interval execution of a real, mass-minimal four-signature exchange."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json
BITS=100;count=0

def check(ok):
 global count
 assert ok
 count+=1

def sqrtbox(x):
 if not x:return F(0),F(0)
 scale=1<<BITS;k=isqrt(x.numerator*scale*scale//x.denominator);lo=F(k,scale)
 return (lo,lo) if k*k*x.denominator==x.numerator*scale*scale else (lo,F(k+1,scale))
def inv(x):
 lo,hi=sqrtbox(x)
 return 1/hi,1/lo

def add(a,b):return a[0]+b[0],a[1]+b[1]
def sub(a,b):return a[0]-b[1],a[1]-b[0]
def mul(a,b):
 v=[x*y for x in a for y in b];return min(v),max(v)
def sc(a,t):return mul(a,(t,t))
def square(a):return (F(0) if a[0]<=0<=a[1] else min(a[0]**2,a[1]**2),max(a[0]**2,a[1]**2))
def overlap(a,b):return max(a[0],b[0])<=min(a[1],b[1])
def coarse(a):
 z=1<<60
 return [str(F(a[0].numerator*z//a[0].denominator,z)),str(F(-((-a[1].numerator*z)//a[1].denominator),z))]

n=2
recv=[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),
      ((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]
axes=[sorted(set([F(-2),F(2)]+[c[d]+sgn*r/2 for c,r,w in recv for sgn in [-1,1]])) for d in range(n)]
vol={}
for ids in product(*[range(len(ax)-1) for ax in axes]):
 box=[(axes[d][i],axes[d][i+1]) for d,i in enumerate(ids)];area=F(1)
 for lo,hi in box:area*=hi-lo
 sig=tuple(int(all(lo>=c[d]-r/2 and hi<=c[d]+r/2 for d,(lo,hi) in enumerate(box))) for c,r,w in recv)
 for bit,(c,r,w) in zip(sig,recv):
  check(bool(bit) or any(hi<=c[d]-r/2 or lo>=c[d]+r/2 for d,(lo,hi) in enumerate(box)))
 vol[sig]=vol.get(sig,F(0))+area
check(sum(vol.values())==16)
sigs=sorted(s for s in vol if any(s));ix={s:i for i,s in enumerate(sigs)}
P=(1,0,0,1);Q=(0,1,0,1);T=(0,0,0,1);U=(1,1,0,1);V=(0,0,1,1)
check(all(s in ix and vol[s]>0 for s in [P,Q,T,U,V]))
x=[{U:F(1),V:F(9,4),T:F(3,4)}.get(s,F(0)) for s in sigs]
z=[F(0)]*len(x)
for s,v in [(U,1),(T,1),(P,-1),(Q,-1)]:z[ix[s]]=F(v)
m=[r**n for c,r,w in recv];mu=[w/mm for (c,r,w),mm in zip(recv,m)]
check(all(sum(v*s[i] for v,s in zip(x,sigs))==m[i] for i in range(4)))
check(all(sum(v*s[i] for v,s in zip(z,sigs))==0 for i in range(4)))
check(sum(x)==m[3]==4);check(sum(z)==0)
check(all(not v or s[3] for v,s in zip(x,sigs)))
rs=sorted(set(r for c,r,w in recv));pref=[]
for k,r in enumerate(rs):
 ell=r**(-n)-(rs[k+1]**(-n) if k+1<len(rs) else 0)
 active=[i for i,(c,t,w) in enumerate(recv) if t<=r]
 J=[sum(mu[i]*s[i] for i in active) for s in sigs]
 vv=[sum(recv[i][2]*s[i] for i in active) for s in sigs]
 pref.append((ell,active,J,vv))

def Qbox(xx):
 ans=(F(0),F(0))
 for ell,active,J,vv in pref:
  for i in active:
   for j in active:
    h=(F(0),F(0))
    for mass,s,jj in zip(xx,sigs,J):
     if mass and s[i] and s[j] and jj:h=add(h,sc(inv(jj),mass))
    ans=add(ans,sc(square(h),ell*mu[i]*mu[j]))
 return ans

def moment(J,active,A,B):
 ans=(F(0),F(0))
 for mass,s,jj in zip(x,sigs,J):
  a=sum(mu[i]*s[i] for i in active if i in A);b=sum(mu[i]*s[i] for i in active if i in B)
  if mass*a*b and jj:ans=add(ans,sc(inv(jj),mass*a*b))
 return ans

common={3};X={0};Y={1}
I=(F(0),F(0));Iblock=(F(0),F(0));norm=(F(0),F(0));normblock=(F(0),F(0))
AX=AY=KB=KXY=CU=(F(0),F(0));Bcross=F(0)
for ell,active,J,vv in pref:
 b=sum(mu[i] for i in active if i in common);p=sum(mu[i] for i in active if i in X);q=sum(mu[i] for i in active if i in Y);s=b+p+q
 alpha=inv(s);beta=inv(b+p);gamma=inv(b+q)
 dp=sub(alpha,beta);dq=sub(alpha,gamma)
 d0=sub(add(alpha,inv(b)),add(beta,gamma)) if b else (F(0),F(0))
 if b:check(d0[0]>=0)
 Bcross+=ell*2*p*q/s
 closed=add(add(sc(square(d0),b*b),sc(square(dp),p*p+2*b*p)),add(sc(square(dq),q*q+2*b*q),(2*p*q/s,2*p*q/s)))
 normblock=add(normblock,sc(closed,ell))
 MBB=moment(J,active,common,common);MXX=moment(J,active,X,X);MYY=moment(J,active,Y,Y)
 MBX=moment(J,active,common,X);MBY=moment(J,active,common,Y);MXY=moment(J,active,X,Y)
 block=add(add(mul(d0,MBB),mul(dp,add(MXX,sc(MBX,2)))),add(mul(dq,add(MYY,sc(MBY,2))),sc(mul(alpha,MXY),2)))
 Iblock=add(Iblock,sc(block,ell))
 AX=add(AX,sc(mul(sub(beta,alpha),inv(b+p)),ell*(p*p+2*b*p)))
 AY=add(AY,sc(mul(sub(gamma,alpha),inv(b+q)),ell*(q*q+2*b*q)))
 if b:KB=add(KB,sc(mul(d0,sqrtbox(b)),ell*b))
 KXY=add(KXY,sc(mul(alpha,inv(p+q)),ell*2*p*q))
 CU=add(CU,sc(add(sc(mul(d0,alpha),b*b),(2*p*q/s,2*p*q/s)),ell))
 for i in active:
  for j in active:
   h=delta=(F(0),F(0))
   for mass,ss,jj in zip(x,sigs,J):
    if mass and ss[i] and ss[j] and jj:h=add(h,sc(inv(jj),mass))
   for mass,ss,jj in zip(z,sigs,J):
    if mass and ss[i] and ss[j] and jj:delta=add(delta,sc(inv(jj),mass))
   I=add(I,sc(mul(h,delta),ell*mu[i]*mu[j]))
   norm=add(norm,sc(square(delta),ell*mu[i]*mu[j]))
check(overlap(I,Iblock));check(overlap(norm,normblock));check(norm[0]>=Bcross>0)
WB=sum(v for v,s in zip(x,sigs) if any(s[i] for i in common));WX=sum(v for v,s in zip(x,sigs) if any(s[i] for i in X));WY=sum(v for v,s in zip(x,sigs) if any(s[i] for i in Y));WXY=sum(v for v,s in zip(x,sigs) if any(s[i] for i in X) and any(s[i] for i in Y))
upper=sub(add(sc(KB,WB),sc(KXY,WXY)),add(sc(AX,x[ix[P]]),sc(AY,x[ix[Q]])))
lower=sub(add(sc(KB,x[ix[T]]),sc(CU,x[ix[U]])),add(sc(AX,WX),sc(AY,WY)))
check(I[1]<=upper[0]);check(lower[1]<=I[0])
oldQ=Qbox(x);out=[]
for H in [F(0),F(1,40),F(1,32),F(1,8)]:
 a=[F(0)]*len(x);gp=gm=F(0)
 for ell,active,J,vv in pref:
  for j in range(len(x)):
   if J[j]>=H:a[j]+=ell*vv[j]
  b=J[ix[T]];p=J[ix[P]]-b;q=J[ix[Q]]-b
  vb=vv[ix[T]];vx=vv[ix[P]]-vb;vy=vv[ix[Q]]-vb
  if max(b+p,b+q)<H<=b+p+q:gp+=ell*(vb+vx+vy)
  if b+q<H<=b+p:gp+=ell*vy
  if b+p<H<=b+q:gp+=ell*vx
  if b<H<=min(b+p,b+q):gm+=ell*vb
 deltaa=sum(aa*zz for aa,zz in zip(a,z));check(deltaa==gp-gm)
 reverse=2*lower[0]-deltaa
 if reverse<=0:
  check(H==F(1,8));check(2*I[1]-deltaa<0);out.append(dict(H=str(H),delta_a=str(deltaa),move='no certified reverse; forward mass unavailable'));continue
 bound=min(x[ix[U]],x[ix[T]],reverse/(2*norm[1]));scale=1<<20
 h=F(bound.numerator*scale//bound.denominator,scale);check(h>0)
 xx=[v-h*zz for v,zz in zip(x,z)]
 check(all(v>=0 for v in xx));check(sum(xx)==4)
 check(all(sum(v*s[i] for v,s in zip(xx,sigs))==m[i] for i in range(4)))
 newQ=Qbox(xx);oldlin=sum(aa*v for aa,v in zip(a,x));newlin=sum(aa*v for aa,v in zip(a,xx))
 improvement=(newlin-newQ[1])-(oldlin-oldQ[0]);guarantee=h*reverse/2
 check(improvement>=guarantee>0)
 if H==0:
  check(newQ[1]<oldQ[0])
  check(oldQ[0]-newQ[1]>F(1,50))
 out.append(dict(H=str(H),delta_a=str(deltaa),step=str(-h),Q_old=coarse(oldQ),Q_new=coarse(newQ),F_gain_lower=str(F(improvement.numerator*(1<<60)//improvement.denominator,1<<60))))
print(json.dumps(dict(status='PASS',checks=count,fixture='actual_n2_mass_minimal_W4',
 positive_volumes={''.join(map(str,s)):str(vol[s]) for s in [P,Q,T,U,V]},
 I=coarse(I),curvature=coarse(norm),Bcross=str(Bcross),
 coarse_lower_cert=coarse(lower),coarse_upper_cert=coarse(upper),cases=out,
 scope='Finite actual-cube receiver quadrature and complete continuous source partition; no new optimization or root claim'),sort_keys=True))
