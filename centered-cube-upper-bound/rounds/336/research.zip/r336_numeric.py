#!/usr/bin/env python3
"""Exact typed-exchange directions on real complete cube signatures; no optimizer."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from collections import Counter
from math import isqrt
import json,hashlib
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def sqrtbox(x):
 s=1<<100;k=isqrt(x.numerator*s*s//x.denominator);return F(k,s),F(k+1,s)
def brief(x):
 a=abs(x.numerator)
 if max(a.bit_length(),x.denominator.bit_length())<1200:return str(x)
 raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def interval_sum(coeff,Klo,Khi):
 lo=hi=F(0)
 for i,row in enumerate(coeff):
  for j,v in enumerate(row):
   lo+=v*(Klo[i][j] if v>=0 else Khi[i][j]);hi+=v*(Khi[i][j] if v>=0 else Klo[i][j])
 return lo,hi

def fixtures():
 return [('n1',1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),('n2',2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('n3',3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]
def field(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sign*r/2 for x,r,w in recv for sign in [-1,1]])) for a in range(n)];groups={}
 for ids in product(*[range(len(p)-1) for p in axes]):
  b=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];m=F(1)
  for lo,hi in b:m*=hi-lo
  sig=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(b))) for x,r,w in recv)
  for v,(x,r,w) in zip(sig,recv):ck('physical_source_incidence',v or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(b)))
  groups[sig]=groups.get(sig,F(0))+m
 sigs=sorted(groups);mi=[r**n for x,r,w in recv];w=[w for x,r,w in recv];mu=[a/b for a,b in zip(w,mi)];rs=sorted(set(r for x,r,w in recv));P=len(sigs);Klo=[[F(0)]*P for i in range(P)];Khi=[[F(0)]*P for i in range(P)];aH={F(0):[F(0)]*P,F(1,8):[F(0)]*P}
 for k,r in enumerate(rs):
  ell=r**(-n)-(rs[k+1]**(-n) if k+1<len(rs) else 0);active=[i for i,(x,t,w) in enumerate(recv) if t<=r];J=[sum(mu[i]*c[i] for i in active) for c in sigs]
  for i,c in enumerate(sigs):
   V=sum(w[v]*c[v] for v in active)
   for H,a in aH.items():
    if J[i]>=H:a[i]+=ell*V
   for j,d in enumerate(sigs):
    A=sum(mu[v]*c[v]*d[v] for v in active)
    if A:
     lo,hi=sqrtbox(J[i]*J[j]);Klo[i][j]+=ell*A*A/hi;Khi[i][j]+=ell*A*A/lo
 return sigs,[groups[c] for c in sigs],mi,Klo,Khi,aH

def directions(sigs):
 P=len(sigs);index={c:i for i,c in enumerate(sigs)};out={}
 for i,A in enumerate(sigs):
  for j in range(i+1,P):
   B=sigs[j];union=tuple(a|b for a,b in zip(A,B));inter=tuple(a&b for a,b in zip(A,B))
   if union not in index or inter not in index:continue
   specs=[]
   if any(A) and any(B) and not any(inter):specs.append(('three_disjoint_union',[(index[union],1),(i,-1),(j,-1)]))
   if inter!=A and inter!=B:specs.append(('four_union_intersection',[(index[union],1),(index[inter],1),(i,-1),(j,-1)]))
   for kind,terms in specs:
    for sign in [-1,1]:
     d=[0]*P
     for k,v in terms:d[k]+=sign*v
     if any(d):out.setdefault(tuple(d),kind)
 zero=sigs.index(tuple([0]*len(sigs[0])))
 for sign in [-1,1]:
  d=[0]*P;d[zero]=sign;out[tuple(d)]='zero_pattern_only'
 for d,kind in out.items():ck('exchange_mean_preservation',all(sum(v*c[i] for v,c in zip(d,sigs))==0 for i in range(len(sigs[0]))))
 return [(kind,d) for d,kind in out.items()]

def endpoint_sources(sigs,orig,mi):
 non=[i for i,c in enumerate(sigs) if any(c)];cols=[sigs[i] for i in non];N=len(mi);A=[[F(c[i]) for c in cols] for i in range(N)];rr=0;piv=[]
 for col in range(len(cols)):
  found=next((i for i in range(rr,N) if A[i][col]),None)
  if found is None:continue
  A[rr],A[found]=A[found],A[rr];v=A[rr][col];A[rr]=[x/v for x in A[rr]]
  for i in range(N):
   if i!=rr:
    v=A[i][col];A[i]=[x-v*y for x,y in zip(A[i],A[rr])]
  piv.append(col);rr+=1
  if rr==N:break
 free=next(i for i in range(len(cols)) if i not in piv);d=[F(0)]*len(cols);d[free]=1
 for row,col in enumerate(piv):d[col]=-A[row][free]
 out=[];base=[orig[i] for i in non]
 for sign in [-1,1]:
  v=[sign*x for x in d];t=min(-x/y for x,y in zip(base,v) if y<0);full=[F(0)]*len(sigs)
  for i,x,y in zip(non,base,v):full[i]=x+t*y
  out.append((f'null_endpoint_sign_{sign}',full))
 return out

def evaluate(x,a,Klo,Khi,sigs,mi,dirs):
 P=len(x);W=sum(x);linear=sum(v*z for v,z in zip(x,a));qlo,qhi=interval_sum([[v*z for z in x] for v in x],Klo,Khi);Flo,Fhi=linear-qhi,linear-qlo;cLo=max(F(0),Flo/W);cHi=max(F(0),Fhi/W);stats=Counter();best={};minface=W==max(mi)
 ck('source_mean_nonnegative',all(v>=0 for v in x) and all(sum(v*s[i] for v,s in zip(x,sigs))==mi[i] for i in range(len(mi))))
 for kind,d in dirs:
  dW=sum(d);limit=min((-v/t for v,t in zip(x,d) if t<0),default=None)
  label='mass_reducing' if dW<0 else 'mass_preserving' if dW==0 else 'mass_increasing';stats[kind+'_available']+=1
  if limit==0:continue
  if minface and dW<0:ck('minimum_mass_face_blocks_reduction',False)
  stats[kind+'_feasible']+=1;stats[label+'_feasible']+=1
  gLo,gHi=interval_sum([[-2*v*t for t in d] for v in x],Klo,Khi);da=sum(v*z for v,z in zip(d,a));gLo+=da;gHi+=da
  hLo=gLo-(cHi if dW>=0 else cLo)*dW;hHi=gHi-(cLo if dW>=0 else cHi)*dW
  kLo,kHi=interval_sum([[F(v*t) for t in d] for v in d],Klo,Khi);kLo=max(F(0),kLo);kHi=max(F(0),kHi)
  if hHi<=0:stats['certified_nonpositive_derivative']+=1;continue
  if hLo>0:stats['certified_positive_derivative']+=1
  if limit is None:
   ck('unbounded_zero_add_no_gain',hHi==0);continue
  hf=float((hLo+hHi)/2);kf=float((kLo+kHi)/2)
  numeric=min(float(limit),max(0,hf/(2*kf))) if kf>0 else float(limit) if hf>0 else 0
  step=min(limit,max(F(0),F(str(numeric)).limit_denominator(10**7)))
  if step==0:continue
  new=[v+step*t for v,t in zip(x,d)];newW=sum(new)
  ck('exact_line_source_feasible',all(v>=0 for v in new) and newW>0 and all(sum(v*s[i] for v,s in zip(new,sigs))==mi[i] for i in range(len(mi))))
  gainLo=hLo*step-kHi*step*step;gainHi=hHi*step-kLo*step*step
  upper_step=min(limit,max(F(0),hHi/(2*kLo))) if kLo else limit;line_upper=max(F(0),hHi*upper_step-kLo*upper_step**2)
  nl,nu=interval_sum([[v*z for z in new] for v in new],Klo,Khi);newlinear=sum(v*z for v,z in zip(new,a));ratioLo=max(F(0),(newlinear-nu)/newW)-cHi;ratioHi=max(F(0),(newlinear-nl)/newW)-cLo
  ck('exact_line_gain_enclosures',gainLo<=gainHi<=line_upper and ratioLo<=ratioHi)
  item=dict(kind=kind,mass_class=label,direction=list(d),step=str(step),max_step=str(limit),derivative_lower=brief(hLo),derivative_upper=brief(hHi),derivative_lower_decimal=float(hLo),quadratic_gain_lower=brief(gainLo),quadratic_gain_upper=brief(line_upper),quadratic_gain_lower_decimal=float(gainLo),quadratic_gain_upper_decimal=float(line_upper),actual_positive_ratio_gain_lower=float(ratioLo),actual_positive_ratio_gain_upper=float(ratioHi),source_mass_after=float(newW),ratio_lower_after=float(max(F(0),(newlinear-nu)/newW)))
  for key in [kind,label,'all_nonzero_geometric' if kind!='zero_pattern_only' else 'zero_pattern_only']:
   if key not in best or item['actual_positive_ratio_gain_lower']>best[key]['actual_positive_ratio_gain_lower']:best[key]=item
 return dict(W_exact=str(W),mass_above_universal_min_exact=str(W-max(mi)),on_exact_min_mass_face=minface,current_positive_ratio_lower=float(cLo),current_positive_ratio_upper=float(cHi),direction_counts=dict(stats),best_moves=best)

def main():
 results=[];stages=[]
 for stage in ['baseline','nearopt','endpoint_stress']:
  before=sum(C.values())
  for label,n,recv in fixtures():
   sigs,orig,mi,Klo,Khi,aHs=field(n,recv);dirs=directions(sigs);sources=[]
   if stage=='baseline':sources=[('original_full_uniform',orig)]
   elif stage=='nearopt':
    for h in ['H0','H1over8']:
     snap=SOURCE_SNAPSHOT[str(n)+'_'+h];by={tuple(c):F(v) for c,v in zip(snap['signatures'],snap['x'])};sources.append(('R334_'+h,[by.get(c,F(0)) for c in sigs]))
   else:
    sources=endpoint_sources(sigs,orig,mi)
    # Exact minimal-mass layered source on actually realized nested signatures.
    levels=sorted(set(mi));layer=[F(0)]*len(sigs);old=F(0)
    for level in levels:
     sig=tuple(int(m>=level) for m in mi);ck('realized_min_face_chain',sig in sigs);layer[sigs.index(sig)]+=level-old;old=level
    sources.append(('exact_minimum_mass_chain',layer))
   for name,x in sources:
    for H,a in aHs.items():
     r=evaluate(x,a,Klo,Khi,sigs,mi,dirs);results.append(dict(stage=stage,n=n,source=name,H=str(H),signatures=[list(c) for c in sigs],**r))
  stages.append(dict(stage=stage,checks=sum(C.values())-before))
 selected_certificates=[]
 for r in results:
  if r['H']=='0' and r['source'] in ['R334_H0','exact_minimum_mass_chain'] and 'all_nonzero_geometric' in r['best_moves']:
   selected_certificates.append(dict(n=r['n'],source=r['source'],H=r['H'],certificate=r['best_moves']['all_nonzero_geometric']))
  records=[];references={};lookup={}
  for key,v in r['best_moves'].items():
   light={k:v[k] for k in ['kind','mass_class','derivative_lower_decimal','quadratic_gain_lower_decimal','quadratic_gain_upper_decimal','actual_positive_ratio_gain_lower','actual_positive_ratio_gain_upper','source_mass_after','ratio_lower_after']};token=json.dumps(light,sort_keys=True)
   if token not in lookup:lookup[token]=len(records);records.append(light)
   references[key]=lookup[token]
  r['best_moves']=references;r['move_records']=records
 out=dict(status='PASS',selected_certificates=selected_certificates,exact_checks=dict(C),total_exact_checks=sum(C.values()),stages=stages,evaluations=results,snapshot_provenance=SNAPSHOT_PROVENANCE,scope='Exact real-cube source signatures; finite receiver quadrature. Rational K enclosures certify typed-direction gains; numeric screen chooses a feasible rational line step, no stationarity/global optimality claim.')
 (BASE/'r336_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),evaluations=len(results),stages=stages),sort_keys=True))
SOURCE_SNAPSHOT = {'1_H0': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '1_H1over8': {'signatures': [[0, 1], [1, 0], [1, 1]], 'x': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '2_H0': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['152192675345354542508815/111014552212439362614092', '85979941608203/117492357305350462170218', '67636281/67089491', '111931209459059/150777896946455508989764', '56578442/91119697', '111931209459059/150777896946455508989764', '56578442/91119697', '32636771/86095918', '41/38439068']}, '2_H1over8': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'x': ['41124905712548/19183577004021', '172102783108485012209/437079922942850737428', '15498842/54211263', '47/4031264895478', '6497413/11392034', '47/4031264895478', '6497413/11392034', '0', '152040/353867']}, '3_H0': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['4427208217662176873923899605435104719801910732720069/1553012758086789705933097045293926421416243062528368', '9069628557741113471982278370985520477352474076753/557011166154917661470830900804615459045965902613581936376', '109951249/78606499', '23420327782968043843502544128714838662811557718256213/1438359231874780692476777865308294502211726654579517026236012', '96607821/69066997', '45726070/59629773', '242612854204622554633088594081394238046139619/1754261154533557326602070738752568555842629427839248', '6977014/83064919', '6133347/73020632', '4845835/11622246', '888386820965112287087277719689633629120072089351/6423660010772338539841551689887334583782197006626170928', '7651719/91097627', '7436688/88537573', '39714235/95250583', '11/98616464', '10016407/48264251', '19364335/93307423', '5/18827343']}, '3_H1over8': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'x': ['1102263955985462639645696207051/322408913886015672509181343095', '898238076882875450257393373195/4847202747846505250602092260232', '48470485/34833957', '1296683457332360839897830014461/6997351569953595983890100052920', '69971289/50285795', '39958693/72919309', '220646/238537049318033', '0', '0', '23647347/94501669', '220646/238537049318033', '0', '0', '23647347/94501669', '0', '0', '0', '1892532/2524157']}}
SNAPSHOT_PROVENANCE = {'file': 'r335_numeric.py', 'sha256': 'ffbb222a50190ee234b6fbadf5c099ef813f229ede4463d5bb6aaf49a230db10', 'note': 'Exact R334 H0/H1/8 source snapshot copied self-contained; no runtime file dependency.'}
if __name__=='__main__':main()
