from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
import json
checks=0
def ck(x):
 global checks
 checks+=1
 assert x
out=[]
with localcontext() as ctx:
 ctx.prec=80
 for stage,ks,ms in [('initial',[0,1,2],[1,4]),('stress',[0,1,4,8],[1,4,16]),('expanded',[1,4,16,64],[4,16,64])]:
  for k in ks:
   K=F(2**k)
   for M in ms:
    r=F(M+1,M)
    N=int((Decimal(2)**k).ln()/(Decimal(M+1)/M).ln()) if k else 0
    while r**N>K:N-=1
    while r**(N+1)<=K:N+=1
    rem=K/r**N
    ck(1<=rem<r)
    lo=1+2*(N*(r-1)/r+(1-1/rem))
    hi=1+2*(N*(r-1)+(rem-1))
    ck(lo<=hi)
    target=1+2*Decimal(k)*Decimal(2).ln()
    # Ordinary Decimal diagnostic; bracket proof is geometric lower/upper sums.
    ck(Decimal(lo.numerator)/Decimal(lo.denominator)<=target+Decimal('1e-70'))
    ck(target<=Decimal(hi.numerator)/Decimal(hi.denominator)+Decimal('1e-70'))
    # Exact telescoping volume bounds imply high->low comparison constants.
    for qminus in [F(3,4),F(1),F(2)]:
     mu=F(7,3);L=mu/(K*qminus);U=K*mu/qminus
     ck(U/L==K*K)
     ck((K/mu)*L==1/qminus)
     mv=F(5,2);small_volume=mv/(K*qminus)
     ck(small_volume/mv==1/(K*qminus))
    out.append(dict(stage=stage,n=max(1,2*k),k=k,subdivision=M,shells=2*N+(2 if rem>1 else 0),lower=float(lo),upper=float(hi),sharp=float(target),width=float(hi-lo)))
 # Spatial dimensions enter only via t=(2dist_inf)^n; check the actual volume normalization.
 for n in [1,2,3,8,32,128,1024]:
  for side in [F(1,2),F(1),F(3,2),F(2)]:
   ck((2*(side/2))**n==side**n)
result=dict(scope='Actual continuum radial receiver envelope: staircase radii and constant-density compact f realize lower sums; Decimal logs are diagnostics, rational bracket directions follow analytic shell integrals. No proof of reverse-far budget.',checks=checks,exact_checks=checks-2*len(out),ordinary_decimal_checks=2*len(out),models=len(out),cases=out)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(exact_checks=checks-2*len(out),ordinary_decimal_checks=2*len(out),models=len(out),largest_k=64,scope=result['scope'])))
