# R336 — directional mass separation and the remaining original hard integral

## Fixed original contract

Use positive f∈L1, ν≤f dx, true receiver du on finite E, a≤R≤b≤2a, q∈[q_-,λ], q_-=3λ/4, m=qR^n=∫_{Q_u}f, dμ=du/m. Preserve c_u(y)=1_{Q_u}(y), E_r, original J_y(r), V_y(r)=∫_{E_r}c_u(y)du and ell=b^(-n)δ_b+nr^(-n-1)dr. Xq=∫_E qdu, W=||f||1. All conclusions here concern the exact hard-matched positive pair slot, not a general soft-kernel replacement.

For a measurable ordered receiver-pair set D define the positive primitive
\[
 T_D=\int\ell(dr)\int\frac{f(y)}{J_y(r)}
       \int_{E_r^2}1_D(u,v)m_u c_u(y)c_v(y)d\mu(u)d\mu(v)\,dy.
\]
Zero-J integrands are zero. The original gated boundary contribution is
\[
 B_{H,D}=\int\ell(dr)\int\frac{f(y)1_{J_y(r)\ge H}}{J_y(r)}
       \int_{E_r^2}1_D c_u(y)c_v(y)\nu(Q_u\setminus Q_v)
                         d\mu(u)d\mu(v)\,dy.
\]
Since ν(Q_u\Q_v)≤m_u, 0≤B_{H,D}≤T_D for every original H≥0. This orientation is essential: u captures the ν source and v misses it.

## A Lebesgue volume estimate in the favourable far direction

Let K≥1 and D_<={m_u<m_v/K}. For fixed v,y, a capturing u in D_< obeys R_u^n≤m_v/(Kq_-). Consequently its center lies in the cube centered at y of that volume, so
\[
 \int_{E_r}1_{m_u<m_v/K}c_u(y)du\le\frac{m_v}{Kq_-}.
\]
This bounds receiver Lebesgue volume, not arbitrary source mass. Using m_udμ(u)=du gives
\[
 \int_{E_r^2}1_{D_<}m_uc_uc_vd\mu(u)d\mu(v)
 \le\frac{V_y(r)}{Kq_-}.                                   \tag{1}
\]
The same numerator is at most V_y(r)J_y(r) by dropping D_<. For any auxiliary threshold t>0, split the ORIGINAL J, keeping all prefixes and its terminal atom. The strict low part is bounded by
\[
 \int f(y)\int_{J_y(r)<t}V_y(r)\ell(dr)dy\le\lambda t W.
\]
This is the existing strict stopping bound; equality at an atom belongs to the high side, so an atom crossing t is not partially included. On J≥t, (1) and ∫f∫ell V=Xq give Xq/(Kq_-t). Thus
\[
 B_{H,D_<}\le T_{D_<}\le\lambda tW+\frac{X_q}{Kq_-t}
 \lefteqn{\phantom{B_{H,D_<}}}\qquad(t>0).
\]
Optimization and Young's inequality yield, for every δ>0,
\[
 \boxed{B_{H,D_<}\le 2\sqrt{\frac{\lambda X_qW}{Kq_-}}
                  \le\delta X_q+\frac{\lambda}{Kq_-\delta}W.} \tag{2}
\]
There is no An factor or extra source copy. This estimate does not apply with u and v reversed while retaining the same m_u numerator.

## Combining the near and favourable far estimates once

The main near-mass theorem uses D_0={K^-1≤m_v/m_u≤K} and the sharp true-receiver envelope C_K=(1+2logK)/q_-. It gives
\[
 B_{H,D_0}\le\delta_0X_q+\frac{\lambda(1+2\log K)}{q_-\delta_0}W.
\]
The three sets D_<, D_0 and D_>={m_u>Km_v} partition all ordered pairs (ties lie in D_0). Applying (2) and the near theorem with δ_0=δ_<=ε/2 gives the COMPLETE original hard-slot statement
\[
 \boxed{B_H\le B_{H,D_>}+\varepsilon X_q+
 \frac{2\lambda}{q_-\varepsilon}
       \left(1+2\log K+K^{-1}\right)W.}                    \tag{3}
\]
The unpriced integral B_{H,D_>} retains the exact original f,ν,J,H,ell and real receiver dx. It is a specified ordered part of the original integrand, not an unnamed new residual. In it the capturing cube has mass MORE than K times the missed cube's mass.

For example, K=exp(√n) pays every other ordered pair with source cost
\[
 \frac{8}{3\varepsilon}(1+2\sqrt n+e^{-\sqrt n})W
       =O_\varepsilon(\sqrt n)W.
\]
K=n+2 gives an O_ε(log(n+2)) source cost with a larger explicit remaining set. These are exact parameter substitutions into proved inequalities, not exponents fitted from finite data. Even K=exp(√n) need not eliminate the remaining set: within one physical octave m ratios can be as large as (λ/q_-)2^n. A mass ratio exp(√n) corresponds to a radius ratio on the order of exp(1/√n); it must not be called a large Euclidean separation without an additional argument.

## Global accounting and scope

Formula (3) is applied to the WHOLE B_H slot once. The old entrance
T_*≤8λH W_β+2d_eff A_n W_ν/H+2B_H
therefore keeps its original first two terms, adds 2εXq and the stated source coefficient, and retains 2B_{H,D_>}. The outer factor 128/119 multiplies all of these. Old local payments must not be added again for pairs now covered by (3). No extra λH completion is introduced by this direct positive-pair argument; a different a_H−Q_all relaxation may still carry its own completion according to its separate ledger.

This proves a genuine general hard-pair payment, including the full comparable-mass branch and one far orientation. It does not prove a bound for B_{H,D_>}, general soft layers, time atoms, all outer scales, or the final sum of absorption coefficients. Those are still required for the original uniform weak-type goal.
