# R336 — comparable receiver masses have a dimension-free full-source receipt

**Main result.** The original real-dx receiver geometry pays the entire comparable-mass part of the positive receiver-pair expansion of B_H. It also pays the comparable-mass part of the all-row loss X_q−Q_all. For any K≥1 and δ>0, either part is at most

\[
 \boxed{\delta X_q+\frac{\lambda}{q_-\delta}
       [1+2\log K]W_f.}                         \tag{1}
\]

Here q_-=3λ/4, so the source coefficient is at most
`(4/(3δ))[1+2 log K]`, independent of dimension. The original high-row part additionally has the direct bound `C_K X_q/H`, where `C_K=q_-^{-1}[1+2log K]`. This includes equal masses. The noncomparable-mass complement remains unpaid by this theorem. No source-bundle exchange or positive-volume signature assumption is needed.

## 1. Original fields and the independent geometric lemma

Work only in the specified hard matched slot: f≥0 in L¹, β=f dx, ν≤f dx, finite actual receiver set E, a≤R(u)≤b≤2a, and

\[
 q(u)=R(u)^{-n}\int_{Q_u}f\in[q_-,\lambda],\quad
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 c_u(y)=1_{Q_u}(y),
\]

where Q_u is the centered cube of side R(u). Keep the ORIGINAL

\[
 E_r=\{u\in E:R(u)\le r\},\quad
 J_y(r)=\int_{E_r}c_u(y)d\mu(u),\quad
 A_{yz}(r)=\int_{E_r}c_u(y)c_u(z)d\mu(u),
\]
\[
 \ell=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,\qquad
 V_y(r)=\int_{E_r}c_u(y)du,\qquad X_q=\int_Eq(u)du\le X=\lambda|E|.
\]

Define the symmetric comparable-mass gate
`N_K(u,v)=1_{K^{-1}≤m_v/m_u≤K}`. For every actual u, every source position y, and every prefix r,

\[
 \boxed{\int_{E_r}N_K(u,v)c_v(y)d\mu(v)\le C_K,
 \qquad C_K=\frac{1+2\log K}{q_-}.}              \tag{2}
\]

**Proof.** Write d=2‖v−y‖∞. On the comparable-mass captured set,

\[
 \frac1{m_v}\le\frac K{m_u},\qquad
 m_v=q(v)R(v)^n\ge q_-d^n,\qquad
 d^n\le R(v)^n=\frac{m_v}{q(v)}\le\frac{K m_u}{q_-}.
\]

Consequently the actual receiver density is bounded by the radial majorant

\[
 \min\left\{\frac K{m_u},\frac1{q_-d^n}\right\}
       1_{d^n\le K m_u/q_-}.                               \tag{3}
\]

Set L^n=m_u/(Kq_-) and U^n=K m_u/q_-. These are majorant breakpoints; no assertion that the actual radius R(v) is at least L is made. The integral of (3) is exactly

\[
 \frac K{m_u}L^n+\frac1{q_-}\int_L^U t^{-n}d(t^n)
 =\frac{1+n\log(U/L)}{q_-}
 =\frac{1+2\log K}{q_-}.
\]

This is a bound on real receiver dx, using the true lower bound on q. There is no upper bound on source density, and this sharper form does not require q≤λ. Restricting to E_r can only decrease the integral. The lemma covers continuum radii, arbitrary physical atoms, and equal masses; no mass-band discretization is used.

## 2. Direct receipt for the original positive pair integral

The original high-row scalar has the positive expansion

\[
 B_H(f,\nu)=\int\ell(dr)\int f(y)\frac{1_{J_y(r)\ge H}}{J_y(r)}
 \iint_{E_r^2}c_u(y)c_v(y)
       \nu(Q_u\setminus Q_v)d\mu(u)d\mu(v)\,dy.             \tag{4}
\]

Zero rows contribute zero. This follows by expanding
`A_yz(1−A_yz/J_y)` with the ORIGINAL J and then integrating ν(dz).
Let B_{H,K} be (4) with the additional factor N_K(u,v). Positivity and ν≤f imply `ν(Q_u\setminus Q_v)≤m_u`. Applying (2) to the v integral gives

\[
 B_{H,K}\le C_K\int\ell(dr)\int f(y)
       \frac{1_{J_y(r)\ge H}}{J_y(r)}V_y(r)dy
 \le\frac{C_K}{H}X_q.                                      \tag{5}
\]

The last identity uses
`∫ f V_y(r)dy=∫_{E_r}m_u du` and the ORIGINAL inclusive tail
`ell([R(u),b])=R(u)^{-n}`. Additional original positive masks bounded by one may be retained in the left side and dropped for this upper bound. In particular, no source-middle-distance complement needs to be removed to use (5).

There is also a bound independent of the given H. For any auxiliary T>0, split the source clocks of this SAME positive integral into J_y(r)<T and J_y(r)≥T, retaining all original masks. On low rows, integrate the v factor without the near gate: `∫c_v dμ=J_y(r)`. The resulting coefficient is bounded by

\[
 l_T(y)=\int\ell(dr)1_{J_y(r)<T}V_y(r)\le\lambda T.           \tag{6}
\]

For completeness, if τ is the first physical radius crossing T, positive Fubini gives
`l_T=∫_{R(u)<τ}q(u)[1−(R(u)/τ)^n]c_u(y)dμ(u)≤λJ_y(τ−)≤λT`.
If the row never crosses, the b atom completes the full tail and
`l_T=∫q(u)c_u(y)dμ(u)≤λJ_y(b)<λT`. Thus crossing atoms and both endpoint cases are included correctly; the crossing atom is never split internally. On the high part apply (2) and 1/J≤1/T. Hence

\[
 B_{H,K}\le\lambda T W_f+\frac{C_K}{T}X_q.                  \tag{7}
\]

Optimizing T (with zero cases immediate) gives
`B_{H,K}≤2√(λ C_K X_q W_f)`, and Young's inequality proves (1).
This is a paid component of the actual integral, not a change of its square denominator or source order.

## 3. The saturated all-row square loss has the same receipt

Define the genuine common-source pair kernels

\[
 S_r^{\rm G}(u,v)=\int f(y)\frac{c_u(y)c_v(y)}{J_y(r)}dy,
 \qquad G_r(u,v)=\int f(y)\frac{c_u(y)c_v(y)}{\sqrt{J_y(r)}}dy,
\]

and `dξ=ell(dr)1_{E_r²}dμ(u)dμ(v)`. Positive Fubini and the matched identity Cf=m give the saturated row capacities
`∫_{E_r}S_r^G(u,v)dμ(v)=m_u` almost everywhere. Consequently

\[
 X_q-Q_{\rm all}(f)
 =\int d\xi\left[\frac{m_u+m_v}{2}S_r^{\rm G}(u,v)-G_r(u,v)^2\right]. \tag{8}
\]

Every integrand in brackets is nonnegative. Indeed, with
`I_r(u,v)=∫f c_uc_v`, Cauchy gives `G²≤I S^G`, and
`I≤min(m_u,m_v)≤(m_u+m_v)/2`.

Let L_K denote (8) restricted by N_K. It is a genuine nonnegative part of the original all-row relaxation, including its clock-variance contribution. By symmetry,

\[
 0\le L_K\le T_K:=\int d\xi\,N_K(u,v)m_uS_r^{\rm G}(u,v).    \tag{9}
\]

Expanding S^G and splitting its source clock at J=T gives exactly the same proof as (6)–(7):

\[
 T_K\le\lambda T W_f+\frac{C_K}{T}X_q
 \le\delta X_q+\frac{\lambda C_K}{\delta}W_f.                \tag{10}
\]

In particular this pays the ENTIRE positive S^G term on comparable-mass pairs; it does not manufacture a Dirichlet credit by increasing fit. It works even when S^G is saturated and every θ-occupancy construction is identically one.

The relation to the actual slot is
`B_H(f,ν)≤B_H(f,f)≤B_all(f,f)=X_q−E_all(f)≤X_q−Q_all(f)`.
Thus the full all-row route has the exact remaining complement

\[
 B_H(f,\nu)\le
 \delta X_q+\frac{\lambda C_K}{\delta}W_f+L_{>K},\quad
 L_{>K}=\int d\xi(1-N_K)
       \left[\frac{m_u+m_v}{2}S_r^{\rm G}-G_r^2\right]\ge0.   \tag{11}
\]

No extra λH W_f is charged on this all-row route. Alternatively, the direct actual-pair route keeps B_H=B_{H,K}+B_{H,>K} and pays only B_{H,K} by (5) or (1). These two routes are alternatives, not two credits to add. The direct ν version retains the actual ν and only uses ν≤f for the explicit upper bound on its cube mass.

## 4. Fees, complements, and bounded conclusion

For fixed K the receipt (1) is dimension-free and therefore stronger than a root-dimension source fee for this component. Even when log K is of root/polylogarithmic size, the displayed source price is exactly linear in 1+log K; any choice of K must use this actual price. Formula (5) pays the high-row component within εX_q whenever H≥C_K/ε.

All quantities in (1)–(11) are for the original hard matched slot. No α reset, soft substitution, source-density assumption, or alternate q is made. Every original prefix and ell atom remains. Any outer multiplier M must multiply both parts of the receipt: to allocate εX one must choose δ so that Mδ≤ε (using X_q≤X), and the source bill becomes MλC_K W_f/δ. Original entrance costs, including any 8λH W_f term, and other scales/history slots remain unchanged. The auxiliary threshold T in the proof is only a partition of this positive component, not a new original cutoff or a deletion of low-source mass.

The remaining mass-noncomparable component has not been estimated here. No conclusion is drawn that the earlier far-mass oriented cut receipt also pays its reverse orientation, fit, or full L_{>K}. The general global root bound therefore remains open. The source-bundle exchange branch is stopped because the real-dx narrow-radius envelope provides a direct new payment for the requested saturated near-mass component.

Local verification actually run: `/tmp/r336_core_checks.py` uses Decimal arithmetic at 70 digits on 24 finite-incidence common-source systems. Its 576 assertions checked saturation, pairwise nonnegativity, the exact X_q−Q_all loss identity, the comparable-pair positive majorant and source expansion, and the original ν pair-loss expansion. All passed at tolerance 10^-55; maximum checked identity error was 1.3×10^-68. These are algebra diagnostics, not actual-dx approximations or numerical evidence for the general theorem. The continuum envelope and stopped-clock receipt are proved above. The parent round is independently checking the analytic envelope and real-field cases; those results are not preclaimed here.

Authored files are `/tmp/r336_core.md` and its necessary reproducible local algebra check `/tmp/r336_core_checks.py`. No other files or Git state were changed. Bounded delivery ends here.
