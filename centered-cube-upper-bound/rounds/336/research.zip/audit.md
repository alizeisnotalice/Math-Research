# R336 independent preauthor screen — actual near-mass variance payment

Owned only /tmp/r336_audit.md; no Git/other-author edits. Derived before reading R336 author proof. Fixed TRUE hard-matched receiver Lebesgue field, m_u=q(u)R(u)^n=integral_Q_u f, q in[q_-,lambda], dmu=du/m, beta=f dx, nu<=f dx, full original ell/J. Fixed K>=1, H>0 for the first bound. All prefixes and terminal atom remain. Arbitrary finite receiver quadrature does not automatically satisfy the receiver-density envelope below.

## 1. Original oriented near-mass branch

The exact nonnegative original variance is

 BH=integral beta(dy)ell(dr)1{J_y(r)>=H}/J_y(r) integral_(u,v in E_r)dmu(u)dmu(v) cu(y)cv(y) nu(Q_u\Q_v).

There is no1/2 in this ORIENTED capture/miss expression. Restrict the actual numerator to 1/K<=m_v/m_u<=K, never recomputing J. Since nu(Q_u\Q_v)<=m_u, it suffices to bound integral_(v mass-near)cv(y)dmu(v), uniformly in u,y. A first valid interval envelope gives[1+log(K²lambda/q_-)]/q_-, but the following sharper argument removes lambda.

## 2. Sharp receiver-density bound

For fixed u and y, write t=(2||v-y||infinity)^n. Capture and mass-nearness imply

 1/m_v<=min(K/m_u,1/(q_-t)),  t<=K*m_u/q_-.

The level-volume variable t has Lebesgue volume distribution dt, because a centered cube with side t^(1/n) has volume t. Thus, integrating an actual RECEIVER-density envelope against dv,

 integral_(v mass-near)cv(y)dmu(v)
 <=integral_0^(K*m_u/q_-)min(K/m_u,1/(q_-t))dt
 =(1+2logK)/q_-=:C_K.

The breakpoint is m_u/(Kq_-). This uses neither an assumed actual minimum radius at that breakpoint nor a source-density cap. Original physical [a,b], E and prefix restrictions only reduce this bound. At K1 it gives1/q_-. Radius endpoints and the original ell atom are inclusive.

Consequently BH_near<=(C_K/H) integral ell integral_(u in E_r)m_u dmu(u) integral f(y)cu(y)dy=(C_K/H)X_q, X_q=integral_E q du. The last step uses exact inclusive tail R(u)^(-n); no A_n factor is introduced. Hence H>=C_K/epsilon pays this original positive branch by epsilon X_q<=epsilon lambda|E|. It does not grant a free change in the original H or remove its entrance/source fees. If X_q is not finite this is merely an extended nonnegative inequality; the existing finite-E contract makes it finite.

## 3. Stronger arbitrary splitting threshold: genuine comparable-mass payment

Define SAME-source SG_r(u,v)=integral f(y)cu(y)cv(y)/J_y(r)dy and G_r(u,v)=integral f(y)cu(y)cv(y)/sqrt(J_y(r))dy. Its true row marginal is m_u. For symmetric near-mass pairs set

 T_near=integral dxi 1near m_u SG,
 L_near=integral dxi1near[((m_u+m_v)/2)SG-G²].

Cauchy G²<=I_uv SG and I_uv<=min(m_u,m_v) show L_near>=0; symmetry makes its positive first term exactly T_near, so L_near<=T_near. Original BH_near<=T_near for EVERY H>=0 by dropping its gate and the missed-source factor as above. These are distinct pair quantities, not identities of an auxiliary cut with all original traffic.

For ANY auxiliary threshold T>0, integrate SG first in y and split its ORIGINAL J_y(r), without changing it. On J<T, the near-v integral is at most J, leaving the actual first moment V_y(r); the strict low-row stopping lemma pays at most lambda T W_f. Its crossing atom is excluded whole and the never-crossing b atom is retained. On J>=T the sharp receiver bound pays at most C_K X_q/T. Therefore

 0<=L_near<=T_near<=lambda T W_f+C_K X_q/T,
 BH_near<=T_near.

For positive X_q,W_f optimize T to obtain2sqrt(lambda C_K X_q W_f), and Young gives for every delta>0

 T_near<=delta X_q+(lambda C_K/delta)W_f,
 lambda C_K<=(4/3)(1+2logK).

This is a genuine new hard comparable-mass positive-pair receipt, with no source/private-selection copies or A_n. Fixed K is dimension-free; logK<=sqrt(n) gives root source coefficient at fixed delta. The auxiliary split threshold T is not the original BH threshold H and does not alter the original slot. Far-mass pairs remain an EXACT separate positive complement. The full all-row identity X_q-Q_all=L_near+L_far may use this receipt without a new slot-internal lambda H completion; finite-H a_H-Q completion and all original entrance/outer/history fees remain distinct. No general root bound follows until the far complement and the other original slots are paid.

All estimates use actual hard matching beta=f, nu<=f and receiver Lebesgue measure, plus positive Fubini. They do not migrate automatically to nonmatched general-soft fields or arbitrary receiver quadrature. The positive original branch and the comparable-mass Gram loss need no R335 source attainment or union-availability assumption.

## 4. Bounded local execution and status

Default and bundled Python both reported mpmath unavailable; no dependency was installed. Reviewer instead executed standard-library Decimal60 arithmetic with three actual1D scale-envelope selections R(v)=max(a,2|v|) on[-b/2,b/2], checked by512-panel Simpson quadrature against1+log(b/a); these can have q1 under a sufficiently large compact constant source. Six sharp mass-window integral evaluations and36 exact Fraction Young checks also passed. Ordinary quadrature/Decimal comparisons are not interval certificates, full BH evaluations or the analytical proof.

Await R336 author proof for final file comparison. General root closure is not certified.

Actual reviewer counts: 9 ordinary Decimal comparisons; 36 exact Fraction algebra assertions.


## 5. Independent directional small-capturing-mass receipt

Before any author proof, the additional ordered receipt also passes. Let T_<K be the same source-integrated first-moment pair expression but with m_u<=m_v/K, u the CAPTURING/source-first endpoint of the original positive loss. For fixed v,y, m_u=q_u R_u^n and q_u>=q_- imply R_u^n<=m_v/(Kq_-). Any capturing receiver center u therefore lies in the centered cube about y of volume m_v/(Kq_-), regardless of its actual selected radius. Thus

 integral_(u active,m_u<=m_v/K) m_u cu(y)dmu(u)=integral cu(y)du<=m_v/(Kq_-).

After multiplying by dmu(v)cv(y) and integrating v, the original ordered numerator is at most V_y(r)/(Kq_-). On original J>=T this gives X_q/(Kq_-T). On J<T it is at most J*V_y, giving the same lambda T W_f low-row bound. For every delta>0,

 T_<K<=delta X_q+lambda W_f/(Kq_-delta).

Original BH's SMALL-capturing/LARGE-missed subintegral is at most T_<K for any original H, since nu(Q_u\Q_v)<=m_u; all other original masks may remain by positive domination. There is no factor1/2 for this directed receipt. It DOES NOT pay the opposite large-capturing/small-missed orientation, nor the symmetric whole far-mass Gram loss, whose first moment includes the larger endpoint mass after swapping. No second use of the Young epsilon or source fee is implicit. Actual receiver dx, q lower bound, matching source beta=f and unchanged full J are essential; no density cap or enlarged-scale source cap is used.


## 6. Author core and primary directional proof comparison

Read complete frozen `/tmp/r336_core.md`, its576-check Decimal script, and `/tmp/r336_directional.md`. PASS. The sharp original-dv density envelope and its breakpoint match the independent proof, do not assume a fictitious actual minimum radius, and do not impose a source-density cap. The ordered positive BH expansion has the correct normalization; symmetry is used only for the separate nonnegative SG all-row loss. Same-source Gibbs marginal/zero-J exclusions give the full X_q-Qall identity. Cauchy proves every pair loss nonnegative, so the remaining mass-far complement is an actual positive component. Strict low-J stopping retains the never-crossing b atom and excludes the whole crossing atom; a/b and equality cases are handled. Choosing an AUXILIARY threshold T does not change the original H, J, source, selector or any already fixed original gate.

The main directional formula partitions all ordered pairs into strict small-capturing/large-missed, closed comparable, and strict large-capturing/small-missed. Allocating epsilon/2 to each of the first two gives exactly source coefficient2lambda/(q_-epsilon)*(1+2logK+1/K), and K=exp(sqrt(n)) yields the stated root source cost. Equalities/ties belong to the comparable part. The remaining ordered large-capturing integral is original and explicit; neither the old oriented potential nor symmetry supplies its missing estimate. The direct-positive receipt introduces NO slot-internal lambda H completion; the separate finite-H aH-Qall route may still need one. Original8lambda H entrance and all outer fees stay. Core576 assertions are70-digit ordinary Decimal finite-incidence diagnostics, not exact/interval or continuum receiver approximations; I read their scope/code without rerunning them.

## 7. Independent four-type screen and frozen author comparison

Before reading its fine proof I independently expanded the nonempty-common quartet: z=e_union+e_intersection-e_P-e_Q has Cz=0 and mass0. On prefix groups B,X,Y, Delta_phi has nonnegative BB mixed finite difference, nonpositive XX/BX and YY/BY blocks, and positive XY cross blocks; all empty blocks are omitted. The exact orthogonal-block squared norm and the source moment inner product are those in author equations(2)–(3). The common high-gate gain is signed: when both P,Q exceed H but B does not, its contribution is -V_B. A Q decrease is therefore not a general F increase at positive H.

Read COMPLETE final `/tmp/r336_aux.md` and292-check script. PASS. The I_lower/I_upper coefficients follow monotonicity of (x²+2bx)/sqrt(x+b) and actual full source-pattern masses; extra captures outside the union correctly remain in J_t. No geometric density or unproved curvature upper bound is substituted. The two directional step rules use the correct feasible interval and keep Delta_H. Empty intersection requires an actual zero-signature column/mass accounting, and cannot give a mass-decreasing move on an exact minimum-mass face. All four useful signatures in the n2 example have positive volume; the source has W=m_receiver4=4, so minimality is exact. Interval code covers signed products, block expansion, actual means, nonnegativity, W preservation and high-gate ties. The reported reverse H0 Gram improvement is explicitly finite relaxed-source geometry; at H1/8 reverse hurts F and forward has no removable masses, which the file correctly keeps. No general favorable uncrossing, availability, multiplicity or root payment follows.

## 8. Complete finite numeric and sharp-envelope code review

Read ALL `/tmp/r336_numeric.py` and notes/result scope. PASS. Full actual cube face signatures are included, with both signs of all realized triple/quartet moves and a separate zero-pattern normalization class. Candidate source means and minimum-mass chain are exactly checked. The initial mean-cone sources/field and full physical prefixes remain fixed; no optimization solver is called. Signed Gram interval sums correctly switch lower/upper bounds with coefficient signs; PSD allows truncating a negative lower curvature enclosure to zero. The parametric derivative uses c=max(0,F/W), distinct from a true positive ratio when F is nonpositive. Feasible rational line steps are screened numerically then all claimed source/derivative/curvature/gain inequalities are exact. Maximum QUADRATIC line-gain upper bounds are not falsely called exact nonlinear ratio optimizers; positive-ratio gains are independently enclosed. Enumerated typed local directions are not asserted to span the whole mean cone or certify global stationarity.

Parent reports fresh16522 exact assertions over36 source/target evaluations. Source fixtures remain compact continuous L1 on complete face cells while RECEIVERS remain quadrature, so they do not certify the new dv envelope. Reviewer instead ran7 metadata checks: embedded provenance matches final R335 numeric source hash and all6 source snapshots agree exactly. These are separate from16522 and the earlier reviewer36 exact/9 ordinary diagnostic assertions.

Read `/tmp/r336_envelope.py`: exact geometric-shell lower/upper sums bracket the radial integral, with Decimal logs used only for ordinary diagnostics and exact post-adjustment of shell count. The dimension checks confirm t=(2dist_infinity)^n has volume t. Its scalar identities correctly cancel actual mass and q_- and give the directed1/(Kq_-) coefficient. It does not compute the full BH or its reverse complement. Final ledger/result-count attribution still awaits the primary frozen report.

Current proof/script bindings:

- `/tmp/r336_core.md`: `5c58be7fcae306f48bbb6f77ad130c0674eddf6265dcac07e53849a391cfcd8b`
- `/tmp/r336_core_checks.py`: `e5cc93d2c3e46cf613112bc9ad6e7d4ad894d117fd511a66dc5e646b96690535`
- `/tmp/r336_directional.md`: `728ec1d156320edcaaee48dc29fbf499fcfdd3e1d4b3c73c84f948b43b10c813`
- `/tmp/r336_aux.md`: `215bc0e038f34fba9868eb8475f4fbc2573dec87f5473663ea312bad4c81792c`
- `/tmp/r336_aux_checks.py`: `ede3a62b42a69a0026ce0baee5e99edaf8fa0cb427b5f73a3c201e540f59ae41`
- `/tmp/r336_numeric.py`: `059175ebf2c90dfcb321e50b3ea2bb8e0fc30d42db018f0dcae69c15c0e14de0`
- `/tmp/r336_numeric.md`: `86449ecbc61bee1d30d140e6e76be161e7d8de220a512da9df094f82f2e643d1`
- `/tmp/r336_numeric_result.json`: `e018ed8a54644ed6f9d99b737308dd65cbd295305fbb0fcd90781873bb592cf4`
- `/tmp/r336_envelope.py`: `b9c4ba7041715b341e968740275aeccaf678398ff37c942d19b9278524a339fc`
- `/tmp/r336_envelope.json`: `508d3fc163b94f8bb808c79010475a623f2b9bcec0be774b4186d0e21ec68d46`


## 9. Final envelope realization and total-ledger comparison

Read complete final `/tmp/r336_envelope.md`, script and result, and final `/tmp/r336_ledger.md`. PASS. In the radial VOLUME coordinate v=(2dist_infinity)^n, core radius^n=L and annular radius^n equal to each shell's upper endpoint produce the stated exact geometric lower sums. The shell ending at V=m/q_- gives a positive-measure reference-mass anchor (constant-radius core when K1). Receivers lie in the cube of side U^(1/n) and selected cubes lie in its doubled cube, so f=q_-1_Q_(2U^(1/n)) really gives every selected mean q_-. For K=2^k,n=max(1,2k), b/a=(K²)^(1/n)<=2. These are legitimate finite-volume one-octave hard fields for the receiver envelope, not a false fixed-low-dimensional sharpness claim or a computed full BH example. Exact rational bracket directions come from elementary shell integrals; Decimal logs are ordinary diagnostics. Parent's358 exact/60 ordinary envelope checks are separately attributed.

The full original entrance substitution is correct: the retained8lambda H Wbeta+2d_eff A_n Wnu/H is followed by2B_rev+2epsilon X_q+4lambda/(q_-epsilon)*(1+2logK+1/K)Wbeta. No old local pair payment is added a second time. The direct positive-pair route incurs no slot-internal lambda H completion; the separate aH-Qall route keeps its own fee if used. The all-row near loss route and direct BH route are alternatives, not additional credits.

Exact Fraction arithmetic confirms2*(128/119)*(119/1024)=1/4; adding the old1/256 gives65/256, leaving191/256. This is a contribution on the SAME authenticated X receiver budget, not a new proof that all other branches fit. The final ledger now explicitly conditions any leaf/outer transfer on its original weighted M3/source/scale aggregation; X_q<=lambda|E| is a local bound and does not imply sum|E_leaf|<=|E0|. Remaining source fees require their authentic outer source ledger as well. Thus the stated absorption arithmetic is not incorrectly promoted to global closure.

The updated gap list correctly removes the now-paid near-mass branch from this HARD slot and retains the precise ordered capturing-mass>K*missed-mass residual. It separately retains non-hard/general-soft dense crossing and later innovations, other not-embedded hard terms, broad-distance/lowpe/extreme-aspect complements, all historical time atoms, suffix/Phi_next negative-credit restrictions, original H entrance and all physical scale/outer costs. Within the new three-way hard-pair statement the residual is a specified original positive subdomain, not just an arbitrary renamed auxiliary functional. No bound for that residual or all-input root theorem is certified.

## Final bounded verdict and evidence attribution

PASS for final core sharp near-mass continuum payment, primary directional payment/combination, auxiliary four-type source formulas and finite fixture, numeric/code/result scope, actual-envelope realization and final ledger. No outstanding substantive correction remains in the reviewed final bytes. This is a genuine newly paid positive hard-pair component and corresponding near part of the all-row relaxation. General uniform root weak type remains UNPROVED. No TeX/PDF compilation or word-for-word review of subsequently typeset research.tex is claimed. No Git/other-author file edits and no repeated full numerical pipeline were performed by this reviewer.

Primary actual executions remain separate: numeric16522 exact; aux292 exact; envelope358 exact+60 ordinary Decimal; core576 ordinary70-digit Decimal algebra. Reviewer executed36 exact Young algebra assertions,9 ordinary60-digit envelope comparisons and7 exact provenance comparisons, plus a Fraction calculation of the displayed total-budget coefficients. Failed mpmath imports are not computational evidence. These counts are NOT combined as independent input examples or general-dimension tests. Earlier awaiting-author statements are superseded by this final receipt.

## Final SHA256 bindings

- `/tmp/r336_core.md`: `5c58be7fcae306f48bbb6f77ad130c0674eddf6265dcac07e53849a391cfcd8b`
- `/tmp/r336_core_checks.py`: `e5cc93d2c3e46cf613112bc9ad6e7d4ad894d117fd511a66dc5e646b96690535`
- `/tmp/r336_directional.md`: `728ec1d156320edcaaee48dc29fbf499fcfdd3e1d4b3c73c84f948b43b10c813`
- `/tmp/r336_aux.md`: `215bc0e038f34fba9868eb8475f4fbc2573dec87f5473663ea312bad4c81792c`
- `/tmp/r336_aux_checks.py`: `ede3a62b42a69a0026ce0baee5e99edaf8fa0cb427b5f73a3c201e540f59ae41`
- `/tmp/r336_numeric.py`: `059175ebf2c90dfcb321e50b3ea2bb8e0fc30d42db018f0dcae69c15c0e14de0`
- `/tmp/r336_numeric.md`: `86449ecbc61bee1d30d140e6e76be161e7d8de220a512da9df094f82f2e643d1`
- `/tmp/r336_numeric_result.json`: `e018ed8a54644ed6f9d99b737308dd65cbd295305fbb0fcd90781873bb592cf4`
- `/tmp/r336_envelope.py`: `b9c4ba7041715b341e968740275aeccaf678398ff37c942d19b9278524a339fc`
- `/tmp/r336_envelope.md`: `ac29b15d6ae88b86c78b03c1c0a53b5b0e1c4209e7643fbbb287352b28ef3c1c`
- `/tmp/r336_envelope.json`: `508d3fc163b94f8bb808c79010475a623f2b9bcec0be774b4186d0e21ec68d46`
- `/tmp/r336_ledger.md`: `4a0922cf8ec494a7f897b829bc486d256f07896853f4f73ede1f9bcd19e18697`
