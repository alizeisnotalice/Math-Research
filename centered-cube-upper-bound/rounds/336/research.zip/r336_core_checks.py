from decimal import Decimal as D, getcontext
from random import Random
getcontext().prec=70
tol=D('1e-55'); checks=0; worst=D(0)
for seed in range(24):
 rng=Random(seed); nr=4; ns=5
 f=[D(rng.randint(1,9))/7 for _ in range(ns)]
 nu=[f[j]*D(rng.randint(0,5))/5 for j in range(ns)]
 mu=[D(rng.randint(1,6))/9 for _ in range(nr)]
 c=[[int(j==0 or rng.randrange(2)) for j in range(ns)] for i in range(nr)]
 m=[sum(f[j]*c[i][j] for j in range(ns)) for i in range(nr)]
 J=[sum(mu[i]*c[i][j] for i in range(nr)) for j in range(ns)]
 SG=[[sum(f[j]*c[u][j]*c[v][j]/J[j] for j in range(ns) if J[j]) for v in range(nr)] for u in range(nr)]
 G=[[sum(f[j]*c[u][j]*c[v][j]/J[j].sqrt() for j in range(ns) if J[j]) for v in range(nr)] for u in range(nr)]
 for u in range(nr):
  err=abs(sum(SG[u][v]*mu[v] for v in range(nr))-m[u]); worst=max(worst,err)
  assert err<tol; checks+=1
 x=sum(mu[u]*m[u]**2 for u in range(nr))
 Q=sum(mu[u]*mu[v]*G[u][v]**2 for u in range(nr) for v in range(nr))
 loss=D(0); nearlinear=D(0); near_loss=D(0); K=D(2)
 for u in range(nr):
  for v in range(nr):
   term=(m[u]+m[v])*SG[u][v]/2-G[u][v]**2
   assert term>=-tol; checks+=1
   loss+=mu[u]*mu[v]*term
   if 1/K<=m[v]/m[u]<=K:
    nearlinear+=mu[u]*mu[v]*m[u]*SG[u][v]
    near_loss+=mu[u]*mu[v]*term
 err=abs(loss-(x-Q)); worst=max(worst,err); assert err<tol; checks+=1
 assert -tol<=near_loss<=nearlinear+tol; checks+=1
 via_source=sum(f[j]/J[j]*sum(mu[u]*m[u]*c[u][j]*sum(mu[v]*c[v][j] for v in range(nr) if 1/K<=m[v]/m[u]<=K) for u in range(nr)) for j in range(ns) if J[j])
 err=abs(nearlinear-via_source); worst=max(worst,err); assert err<tol; checks+=1
 H=D('0.8'); direct=pair=D(0)
 for y in range(ns):
  if J[y]>=H:
   for z in range(ns):
    A=sum(mu[u]*c[u][y]*c[u][z] for u in range(nr))
    direct+=f[y]*nu[z]*A*(1-A/J[y])
   for u in range(nr):
    for v in range(nr):
     ndiff=sum(nu[z]*c[u][z]*(1-c[v][z]) for z in range(ns))
     pair+=f[y]/J[y]*mu[u]*mu[v]*c[u][y]*c[v][y]*ndiff
 err=abs(direct-pair); worst=max(worst,err); assert err<tol; checks+=1
print({'cases':24,'algebra_assertions':checks,'max_identity_error':str(worst),'precision':70,'tolerance':str(tol),'scope':'finite incidence algebra only; continuum envelope is proved analytically'})
