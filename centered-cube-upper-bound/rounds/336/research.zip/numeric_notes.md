# R336 — realizable typed exchanges, mass faces and certified line gains

Run `r336_numeric.py` with the bundled Python. The standard library is sufficient; the script resolves its small result JSON beside itself. R334 exact repaired source snapshots and provenance are embedded, so runtime needs no earlier file, MATLAB or optimizer.

## Complete actual patterns and tested sources

The physical cube fixtures remain n1/2/3 with mixed radii1,3/2,2, actual q=λ=1 and positive finite receiver quadrature. Source cells are cut at EVERY actual receiver face within Q4; outside Q4 has the already present zero signature. Thus the4/10/19 complete source signatures are geometrically realized by positive-volume sets. Every source variation is an actual compact L1 source after distributing a pattern mass over those cells. This is not continuous receiver dx or complete original history.

Three stages retain all physical prefixes and terminal ell atoms:

* Baseline: full uniform1_Q4, three sources.
* Near-optimal candidates: the six existing exact R334 H0/H1/8 repaired sources; no new optimization.
* Stress: both existing first-nullspace endpoints in each geometry, plus one explicit exact minimum-mass source, nine sources.

Each source is evaluated at BOTH target gates H0 and H1/8, giving36 source/target evaluations. A source optimized for H1/8 is not treated as near-optimal for H0. The minimum-mass source assigns successive mass increments to the actually realized nested signatures1{m_i≥level}; the script verifies each required signature exists and Cx=m. It attains the universal lower bound W=max_i m_i, so its mass-minimal status is exact in these fixtures.

## Enumerated exchanges and signs

For each unordered realized pair of nonempty disjoint signatures A,B with realized union U, the three-type direction is e_U−e_A−e_B. It has ΔW=−1. Both orientations are included. Degenerate empty-pattern instances are recorded separately as zero-pattern addition/deletion, not credited as geometric improvement.

For each incomparable pair A,B with ALL required columns present, the four-type direction is e_(A∪B)+e_(A∩B)−e_A−e_B. Empty intersection is legal because the actual zero pattern exists. It has ΔW=0. Both orientations are included. Comparable/identical pairs give a zero direction and are omitted. Duplicate direction vectors are removed. Exact checking verifies CΔ=0.

The n1/2/3 geometries respectively permit2/8/32 oriented nontrivial three-type directions and2/26/142 four-type directions, before source-dependent feasibility. Two separate zero-only directions are also retained. The exact allowed interval is0≤t≤min_(Δj<0)x_j/(−Δj). Zero addition is unbounded but has no positive positive-ratio derivative. On an exact W=max m face no mass-decreasing direction has positive allowed step; this is checked, not inferred from rounded W. R334 n2/3 masses exceed the bound by tiny positive rationals, which are reported honestly.

## Derivative and line certificate

For the target F=aH·x−||Φx||² use c=max(0,F/W). With Δmass_removed=−ΔW, the parametric derivative is

h=Δa+c Δmass_removed−2<Φx,ΔΦ>.

This resolves the sign convention: the term is −cΔW. Along a feasible direction the exact parametric residual improvement is

h t−κt², κ=||ΔΦ||²≥0.

A floating midpoint screen chooses a rational feasible step near the clipped quadratic maximizer. It is NOT called the exact nonlinear ratio line maximizer. Exact100-bit integer-square-root bounds on the full frozen Gram entries then enclose h,κ, the step's gain and the maximum possible quadratic line gain. The latter upper uses h_upper and κ_lower. Every saved selected move is checked for exact nonnegative source masses, Cx=m, W>0 and line-gain enclosure.

The actual POSITIVE ratio improvement is independently bracketed using F(new)/W(new) and F(old)/W(old). In nonpositive H1/8 cases a tiny positive parametric F increment can leave the positive ratio at0; those are not reported as genuine positive-ratio gains. All saved decimal numbers are descriptive conversions of rational enclosures; numeric screening itself is not a certificate or a global optimizer.

## Results affecting the next proof choice

On the exact minimum-mass H0 sources:

|n|initial positive ratio|best certified ratio gain|move|mass change|
|---|---:|---:|---|---|
|1|.021780413|≥.0056340093|inverse three-type|increases W1.5→1.782975|
|2|.019445016|≥.0078393321|four-type|keeps W4|
|3|.009653830|≥.0052022319|four-type|keeps W8|

All strict mass-decreasing moves are infeasible there. Yet substantial improvements remain. Thus minimizing source mass alone is insufficient, and even a minimum-mass face needs its mass-preserving overlap degrees of freedom. The n1 example additionally requires allowing an increase in source mass to improve the ratio.

On the MATCHED R334 H0 candidates, the best observed certified geometric ratio gains are only approximately1.45e−15,4.66e−10,1.58e−10 in n1/2/3. The n1 move is a tiny three-type mass decrease; n2/3 use four-type mass preservation. No positive certified three-type mass-decrease gain was found in n2/3. These checks do not upgrade local stationarity to global optimality; they agree with the separately bracketed R334 finite optimum to the expected small residual scale.

For the H1/8-matched candidates, n1 repeats its H0 behavior. In n2 no increasing line was saved; n3 has parametric increments of order7.1e−15 but positive-ratio improvement0, consistent with its nonpositive relaxed target. The completion H term remains outside this directional positive-ratio test.

Baseline zero-pattern deletion yields ratio gains approximately.0154365,.0144315,.0108632. They are explicitly separated from geometric exchanges, whose best gains are approximately.0004500,.0008087,.0001118. Removing unused mass is normalization progress, not a receipt for source overlap. Endpoint stress admits materially larger three/four-type gains, confirming source-dependent allowed steps matter; no endpoint is claimed worst-case.

## Reproduction and limits

Two fresh standalone processes pass **16,522 exact rational/integer assertions**. Stage counts are5,422 baseline,5,334 near-optimal and5,766 stress. Floating point is used only to select a candidate rational step and order descriptive saved gains; every asserted mean, nonnegativity, derivative/curvature interval and line-gain bound is rationally checked. Geometry checks repeat across stages and are not counts of independent inputs.

The result JSON stores all direction availability/feasibility counts. `best_moves` maps categories to indices in a deduplicated `move_records` list. Six selected H0 certificates retain exact direction vectors, allowed and used rational steps, and rational-bound values or explicitly encoded fraction digests; the script recomputes the full fractions before checking. The source is self-contained and the result is about115KiB; no large regenerated data is required.

This evidence favors preserving four-type mass-neutral variations and, where needed, mass-increasing inverse-union variations. It provides no general root bound, exhaustive mean-cone direction basis, continuum receiver result, or implication from typed local stationarity to global optimality. The only changed files are this round's Python, note and result JSON.
