# Sharp receiver envelope: local three-stage verification

The main geometric argument bounds real receiver measure, not arbitrary source density. Its radial variable is v=(2||u−y||∞)^n, whose cube-volume distribution is exactly dv. For a fixed reference mass m and K≥1, the majorant is min(K/m,1/(q_- v)) on 0≤v≤Km/q_-. Its integral is C_K=(1+2logK)/q_-.

The local script uses initial, stress and expanded stages, K=2^k up to k=64, and rational geometric subdivisions r=1+1/M for M up to64. There are30 parameter models. Set L=m/(Kq_-), V=m/q_-, U=Km/q_- in VOLUME coordinates. On the core 0≤v≤L, set actual receiver radius^n=L. On each annular shell of the two intervals [L,V],[V,U], set radius^n equal to the upper endpoint of that shell. Each receiver then captures y=0, with q=q_- and mass in [m/K,Km]. Assign f=q_- times the indicator of the cube of side 2U^(1/n); this makes every selected receiver mean exactly q_-, so arbitrary source-density bounds are not being assumed. The shell ending at V supplies an actual positive-measure anchor set with receiver mass m.

For n=max(1,2k), the total radius ratio is at most2, so these are legitimate one-octave hard receiver fields. For k=0 the annulus is empty and the radius is constant. The underlying standalone envelope is valid in every dimension; its sharp one-octave realization here selects dimensions consistent with the mass range. No claim of sharpness in an incompatible fixed small dimension is made.

Writing N=floor(log K/log r) and remainder s=K/r^N∈[1,r), the actual staircase receiver integral times q_- is

1+2[N(r−1)/r+(1−1/s)].

The left-endpoint upper sum is

1+2[N(r−1)+(s−1)].

They bracket1+2logK, and their gap tends to0 as the subdivision is refined. Lower sums are genuine actual-field integrals, not point-probe approximations. Rational powers verify the choice of N and bracket ordering exactly. Comparison with Decimal logarithms is separately labelled an ordinary diagnostic; the bracket direction itself follows the elementary integral proof. The scalar directional volume identity (m_v/(Kq_-))/m_v=1/(Kq_-) is also checked at three q_- values. Spatial cube-volume normalization is checked in dimensions1,2,3,8,32,128,1024.

The actual local run passed358 exact rational assertions and60 ordinary Decimal comparisons, reported separately. No numerical exponent fitting is used. The source coefficient's dependence on logK follows the proved analytic integral. These checks neither bound the remaining reverse far-mass integral nor certify all outer scales/history.

Run `python3 r336_envelope.py`; it writes `r336_envelope.json`. No third-party libraries or network are needed. Other round checks (finite pair algebra, actual-source exchanges and direction enumeration) are separate scripts and evidence scopes.
