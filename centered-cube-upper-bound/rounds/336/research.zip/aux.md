# R336 — real four-type source exchanges on a mass-minimal face

**Bounded result.** A realized four-signature rectangle has an exact orthogonal-block feature curvature and a source-overlap direction certificate. These permit a genuine mass-preserving improvement even when total source mass is already minimal. The original high gate can favor either direction and is retained exactly. A real cube execution on a mass-minimal face is certified below. No signature closure, uniform favorable direction, global availability theorem, or root bound is asserted.

## 1. A real quartet, not a formal union/intersection

Keep the finite actual field of R334/R335: positive receiver weights `w_i`, actual masses `m_i=q_iR_i^n`, `μ_i=w_i/m_i`, all physical prefixes, the full-row features `Φ_s(r,i,j)=s_is_j/√J_s(r)`, and the original `a_H(s)=∫ell V_s1_(J_s≥H)`. The feature measure is `ell(dr)μ_iμ_j`, where `ell=b^-nδ_b+nr^-n-1dr`. Zero rows have zero feature. Set `Q(x)=||Φx||²`, `F(x)=a_H·x−Q(x)`.

Let `P,Q` be incomparable REAL source signatures. Require their union `U` and intersection `I` also to be realized by positive-volume source regions. Every nonzero type must be among the actual columns. If `I=0`, the zero-signature source region must be included explicitly; outside finitely many bounded cubes such a region is indeed realizable. Its mass cannot be omitted when computing the exchange's total mass.

Write the three disjoint receiver groups as `B=P∩Q`, `X=P\Q`, `Y=Q\P`. With

\[
 z=e_U+e_I-e_P-e_Q,
\]

one has `Cz=0` and `1·z=0`. Its EXACT feasible interval is

\[
 -\min(x_U,x_I)\le t\le\min(x_P,x_Q).                       \tag{1}
\]

Thus any feasible move remains on a mass-minimal face if its starting source is on that face. For contained signatures the direction is identically zero, so they are excluded.

If `I=0` and a mass-minimal source had `x_P,x_Q>0` and realized union `U`, the R335 three-type move `e_U−e_P−e_Q` would lower its total mass while preserving `Cx`; this is impossible. Consequently the empty-intersection quartet does not supply that forward move on the minimal face. A mass-minimal source also has zero mass on the zero signature, so its reverse allowance is zero as well. This observation is an application of R335, not a newly counted source payment. The useful example below has a NONEMPTY common type.

## 2. Exact prefix blocks and overlap curvature

At each physical prefix write

\[
 b=J_I(r),\quad p=\sum_{i\in X,R_i\le r}\mu_i,\quad
 q=\sum_{i\in Y,R_i\le r}\mu_i,\quad s=b+p+q=J_U(r),
\]
\[
 \alpha=s^{-1/2},\quad\beta=(b+p)^{-1/2},\quad
 \gamma=(b+q)^{-1/2},\quad
 \delta_0=\alpha+b^{-1/2}-\beta-\gamma,
 \quad\delta_p=\alpha-\beta,\quad\delta_q=\alpha-\gamma.
\]

Omit empty blocks and use zero-normalized features whenever their prefix mass is zero. In particular the `B²` block is absent when `b=0`; no inverse of zero is taken. For `b>0`, `δ₀≥0` by the nonnegative mixed finite difference of `t↦t^-1/2`. The other two coefficients are nonpositive.

The REAL feature difference `ΔΦ=Φ_U+Φ_I−Φ_P−Φ_Q` has coefficient `δ₀` on `B²`, `δ_p` on `X²,B×X,X×B`, `δ_q` on the analogous `Y` blocks, and `α` on `X×Y,Y×X`. Hence

\[
 \boxed{D²:=\|\Delta\Phi\|²=
 \int\ell\,[b²\delta_0²+(p²+2bp)\delta_p²
                 +(q²+2bq)\delta_q²+2pq/s].}               \tag{2}
\]

In particular `D²≥B_cross:=∫ell 2pq/s>0`; the original terminal atom guarantees positivity. This lower bound is an exclusive receiver-pair witness. No unproved constant-factor upper comparison is used in the step rule below.

For an arbitrary actual source column `t`, let `b_t,p_t,q_t` denote its captured prefix masses in these groups. Define the true full-source moments

\[
 M_{GH}(r)=\sum_t x_t\frac{J_{G\cap t}(r)J_{H\cap t}(r)}{\sqrt{J_t(r)}}.
\]

These preserve the original normalization, including capture outside `U`. Then the directional inner product is EXACTLY

\[
 I_x:=\langle\Phi x,\Delta\Phi\rangle
 =\int\ell[\delta_0M_{BB}+\delta_p(M_{XX}+2M_{BX})
       +\delta_q(M_{YY}+2M_{BY})+2\alpha M_{XY}].             \tag{3}
\]

Thus common-group and exclusive-cross overlaps favor one sign, while the two within-side blocks favor the other. This explains why a formal uncrossing rule has no automatic sign.

## 3. Linear-source geometric bounds for choosing a direction

The following bounds can certify a direction without evaluating the full source quadratic. Define nonnegative geometric coefficients

\[
 A_X=\int\ell(\beta-\alpha)\frac{p²+2bp}{\sqrt{b+p}},\quad
 A_Y=\int\ell(\gamma-\alpha)\frac{q²+2bq}{\sqrt{b+q}},
\]
\[
 K_B=\int\ell\delta_0b^{3/2},\quad
 K_{XY}=\int\ell\frac{2\alpha pq}{\sqrt{p+q}},\quad
 C_U=\int\ell[\delta_0b²/\sqrt s+2pq/s].                    \tag{4}
\]

Again empty terms are zero. Let `W_B,W_X,W_Y` be the actual source masses whose signatures meet those receiver groups, and `W_XY` the mass meeting BOTH exclusive groups. These are source masses, not source volume bounds. Then

\[
 \boxed{\quad
 \underline I:=K_Bx_I+C_Ux_U-A_XW_X-A_YW_Y
 \le I_x\le
 K_BW_B+K_{XY}W_{XY}-A_Xx_P-A_Yx_Q=:\overline I.\quad}       \tag{5}
\]

For proof, `M_BB≤W_B b^(3/2)` and `M_XY≤W_XY pq/√(p+q)`, since each original denominator dominates the captured group masses. The actual columns `P,Q` give the two negative-block lower contributions in the upper bound. Conversely columns `I,U` give the displayed positive contributions in the lower bound; each negative block is at most its fully captured `B∪X` or `B∪Y` value times `W_X` or `W_Y`. The function `(a²+2ac)/√(a+c)` increases in both nonnegative arguments, which justifies that last bound. These coefficients may be loose, but no total-mass product or artificial density is substituted.

For several quartets, any sum of these source-mass terms must retain their actual source-column multiplicities. No source-once summation is supplied merely by naming different receiver groups.

## 4. The original high gate and an executable move

Let `v_B=V_I`, `v_X=V_P−V_I`, `v_Y=V_Q−V_I`. The exact linear gain is `Δ_H=a_H(U)+a_H(I)−a_H(P)−a_H(Q)`. It decomposes as

\[
 \Delta_H=G_H^+-G_H^-,
\]
\[
 G_H^+=\int\ell[(v_B+v_X+v_Y)1_{\max(b+p,b+q)<H\le s}
       +v_Y1_{b+q<H\le b+p}+v_X1_{b+p<H\le b+q}],
\]
\[
 G_H^-=\int\ell v_B1_{b<H\le\min(b+p,b+q)}.                 \tag{6}
\]

This includes ties exactly. The common-type loss in (6) is real; unlike the disjoint R335 exchange, `Δ_H` need not be nonnegative. At `H=0`, `Δ_H=0` because `a_0` is receiver-linear.

For every feasible `t`, there are the exact identities

\[
 Q(x+tz)-Q(x)=2tI_x+t²D²,
 \qquad F(x+tz)-F(x)=t(\Delta_H-2I_x)-t²D².                 \tag{7}
\]

The useful geometric sufficient rules are now explicit:

* Forward: if `g_+=Δ_H−2 overline I>0` and `min(x_P,x_Q)>0`, choose `0<t≤min(x_P,x_Q,g_+/(2D²))`.
* Reverse: if `g_-=2 underline I−Δ_H>0` and `min(x_U,x_I)>0`, choose `0<h≤min(x_U,x_I,g_-/(2D²))` and `t=−h`.

The resulting increase of `F` is at least `t g_+/2` or `h g_-/2`; the ratio increase is that amount divided by the UNCHANGED `W`. Certified lower slope bounds and upper curvature bounds may be substituted. If (5) is inconclusive, the exact blocks (2)–(3) provide an executable one-dimensional choice: clip `(Δ_H−2I_x)/(2D²)` to (1). This is not assumed favorable when its feasible clipped value is zero.

Strict decrease of `Q` alone has a separate condition: forward requires `I_x<0` and `t<−2I_x/D²`; reverse requires `I_x>0` and `h<2I_x/D²`. At positive `H`, a decrease of `Q` need not increase `F`. The gate term in (6) cannot be discarded.

## 5. Real mass-minimal cube execution and exact checks

The self-contained `/tmp/r336_aux_checks.py` uses the four actual `n=2` cubes of R335, with center/radius/receiver weight

`((-1/2,0),1,1/10)`, `((0,-1/2),1,1/10)`, `((1/2,1/2),3/2,1/5)`, `((0,0),2,1/10)`.

Its COMPLETE face partition of `Q4` certifies the real quartet
`P=1001,Q=0101,I=0001,U=1101`, with positive areas `5/8,5/8,1,3/16`. The additional real type `V=0011` has area `5/4`.

Put compact continuous `L¹` source masses `x_U=1,x_V=9/4,x_I=3/4` on those regions, constant within each region, and zero elsewhere. All four selected cube means are exactly `q_i=λ=1`. Its source mass is `W=4=m_4`, so it is provably MASS MINIMAL: every feasible source has mass at least the mass captured by receiver 4. The quartet preserves `Cx` and `W`, and stays on this minimal face.

The coarse lower overlap certificate in (5) is strictly positive (about `0.04098`), so it certifies the reverse direction at `H=0` without a generic gradient oracle. The script executes the rational step

\[
 t=-186535/524288.
\]

It preserves all actual means/nonnegativity, and rigorously lowers the FULL source Gram energy by MORE than `1/50`; at `H=0` it raises `F` by the same amount. All physical radii `1,3/2,2` and their full prefixes remain. A further `H=1/32` run has exact `Δ_H=−1/40` and a strict feasible improvement; the tie case `H=1/40` is also checked.

For the SAME starting source at `H=1/8`, `Δ_H=1/8` and exact intervals certify `2I_x−Δ_H<0`: reverse moves hurt `F`, while forward moves are unavailable because `x_P=x_Q=0`. Thus this quartet has no feasible improving `F` direction there, even though a sufficiently small reverse move would still lower `Q`. This is a scope check within the one actual example, not a general obstruction claim.

Two fresh runs passed **292 exact assertions**, using rational arithmetic and outward rational square-root intervals of 100 bits. Output intervals are rounded outward to 60-bit dyadics. The checks cover the positive-volume source cells, local means, mass minimality, block/feature agreement, source-overlap bounds, gate cases including ties, and certified improvements. Run:

```sh
python3 /tmp/r336_aux_checks.py
```

The receivers in this diagnostic remain finite quadrature receivers; its source regions and source integrals are complete continuous ones. It is not a continuum receiver theorem or a numerical optimum. The missing global step is enough REAL available quartets with favorable overlap balances and controlled source multiplicity. Neither mass minimality nor a KKT condition supplies that geometry. Only `/tmp/r336_aux.md` and `/tmp/r336_aux_checks.py` are authored; no other research file or Git state is changed.
