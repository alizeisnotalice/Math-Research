#!/usr/bin/env python3
"""Accepted-source Bernoulli bridge with original finite-cube source gates."""
from fractions import Fraction as F
from itertools import product
from collections import Counter
from pathlib import Path
import json,math,hashlib
BASE=Path(__file__).resolve().parent
SOURCE=Counter();LOG=Counter()
def ck(k,v):SOURCE[k]+=1;assert v,k
def lk(k,v):LOG[k]+=1;assert v,k

def cert(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<512:return str(x)
 a=abs(x.numerator);raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')

def logbounds(x,N=64):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=logbounds(1/x,N);return -hi,-lo
 power=0
 while x>2:x/=2;power+=1
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));hi=lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 if power:
  a,b=logbounds(F(2),N);lo+=power*a;hi+=power*b
 return lo,hi

def bernoulli(alpha,beta,ratio):
 # Extended endpoints handled explicitly, no 0*log(0) numerical operation.
 if alpha==beta:
  lk('equal_probability_corner',alpha in [F(0),F(1)] or 0<alpha<1)
  return dict(kl_bounds=['0','0'],correction_bounds=['0','0'],alpha_logratio_bounds=['0','0'],endpoint='equal')
 lk('bernoulli_orientation',0<=beta<alpha<=1)
 if beta==0:
  lk('zero_beta_infinite_kl',alpha>0)
  return dict(kl='infinity',endpoint='beta_zero_positive_alpha')
 lk('accepted_probability_ratio',alpha/beta==ratio)
 lr=logbounds(ratio);lhs=(alpha*lr[0],alpha*lr[1])
 if alpha==1:
  corr=(F(0),F(0));KL=lr;lk('alpha_one_finite_endpoint',KL[0]>0)
 else:
  arg=(1-beta)/(1-alpha);lc=logbounds(arg);corr=((1-alpha)*lc[0],(1-alpha)*lc[1]);neg=logbounds((1-alpha)/(1-beta));KL=(lhs[0]+(1-alpha)*neg[0],lhs[1]+(1-alpha)*neg[1])
  lk('correction_argument_exact',arg-1==(alpha-beta)/(1-alpha))
  lk('reciprocal_log_arguments_exact',arg*((1-alpha)/(1-beta))==1)
 lk('correction_nonnegative_below_gap',0<=corr[0]<=corr[1]<=alpha-beta)
 lk('kl_nonnegative_interval',0<=KL[0]<=KL[1])
 lk('log_identity_interval',KL[0]+corr[0]<=lhs[1] and lhs[0]<=KL[1]+corr[1])
 return dict(kl_bounds=list(map(cert,KL)),correction_bounds=list(map(cert,corr)),alpha_logratio_bounds=list(map(cert,lhs)),kl_decimal=float(sum(KL)/2),correction_decimal=float(sum(corr)/2),gap_exact=str(alpha-beta),identity_scope='Exact log-argument identity with outward rational atanh-series bounds; no global funding claim.')

def fixtures():
 return [('initial',1,F(5,4),F(1,100),[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5)),((F(0),),F(2),F(1,10))]),('boundary_stress',2,F(3,2),F(1,50),[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),('expanded',3,F(2),F(1,100),[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]

def geometry(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sgn*R/2 for x,R,w in recv for sgn in [-1,1]])) for a in range(n)];groups={};count=0
 for ids in product(*[range(len(p)-1) for p in axes]):
  cell=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];mass=math.prod(hi-lo for lo,hi in cell)
  signature=tuple(int(all(lo>=x[a]-R/2 and hi<=x[a]+R/2 for a,(lo,hi) in enumerate(cell))) for x,R,w in recv)
  for c,(x,R,w) in zip(signature,recv):ck('actual_cube_face_cell',c or any(hi<=x[a]-R/2 or lo>=x[a]+R/2 for a,(lo,hi) in enumerate(cell)))
  groups[signature]=groups.get(signature,F(0))+mass;count+=1
 ck('full_positive_L1_source_partition',sum(groups.values())==4**n)
 mi=[R**n for x,R,w in recv]
 for i,m in enumerate(mi):ck('actual_q_one',sum(v*c[i] for c,v in groups.items())==m)
 return groups,count

def model(name,n,K,h,recv):
 groups,cells=geometry(n,recv);mi=[R**n for x,R,w in recv];weights=[w for x,R,w in recv];mu=[w/m for w,m in zip(weights,mi)];rs=sorted(set(R for x,R,w in recv));pairs=[];totalgap=F(0);stats=Counter()
 for hused in [h,F(1)]:
  for H in [F(0),2*hused,F(1,8)]:
   for l,r in enumerate(rs):
    active=[i for i,(x,R,w) in enumerate(recv) if R<=r];ell=r**-n-(rs[l+1]**-n if l+1<len(rs) else 0)
    for i in active:
     past=[j for j,m in enumerate(mi) if mi[i]>K*m]
     ck('far_past_inside_physical_prefix',all(j in active for j in past))
     for j in active:
      if mi[i]<=K*mi[j]:continue
      O=alpha=beta=F(0);acceptedcells=0
      for c,fmass in groups.items():
       J=sum(mu[t]*c[t] for t in active);Z=sum(mu[t]*c[t] for t in past);keep=bool(J>=H and Z>hused and c[i] and c[j])
       stats['highpast_pair_cells_rejected_by_H']+=bool(Z>hused and c[i] and c[j] and J<H)
       stats['highpast_pair_cells_at_H_equality']+=bool(Z>hused and c[i] and c[j] and J==H)
       a=hused/J if keep else F(0)
       ck('original_acceptance_in_unit_interval',0<=a<=1)
       if keep:
        ck('strict_highpast_implies_strict_J',J>=Z>hused and a<1)
        O+=fmass/J;alpha+=fmass*c[j]/mi[j]*a;beta+=fmass*c[i]/mi[i]*a;acceptedcells+=1
      ck('original_overlap_bridge',O==mi[j]*alpha/hused==mi[i]*beta/hused)
      ck('finite_posterior_probabilities',0<=beta<=alpha<1)
      if beta:ck('original_mass_ratio_preserved',alpha/beta==mi[i]/mi[j])
      traffic=ell*mu[i]*mu[j]*(mi[i]-mi[j])*O
      alternate=ell*weights[i]*weights[j]/hused*(alpha-beta)
      ck('retained_original_massgap_traffic',traffic==alternate)
      totalgap+=traffic;stats['pairs']+=1;stats['positive_pairs']+=bool(alpha);stats['zero_pairs']+=not alpha
      B=bernoulli(alpha,beta,mi[i]/mi[j])
      pairs.append(dict(h=str(hused),H=str(H),r=str(r),ell=str(ell),large_endpoint=i,small_endpoint=j,accepted_source_signatures=acceptedcells,overlap_original_exact=str(O),alpha_exact=str(alpha),beta_exact=str(beta),mass_ratio_exact=str(mi[i]/mi[j]),traffic_original_exact=str(traffic),bernoulli=B))
 return dict(stage=name,n=n,K=str(K),h_primary=str(h),source='f=beta=nu=1_Q4',W=str(4**n),q='1',lambda_='1',geometric_source_cells=cells,source_signature_count=len(groups),receiver_entries=[dict(center=list(map(str,x)),R=str(R),quadrature_weight=str(w)) for x,R,w in recv],counts=dict(stats),pairs=pairs,scope='Physical finite cube receivers and full positive-L1 source integration; receiver weights are quadrature, not continuum du. Exact original highpast, J, H and physical ell/terminal atom retained. K/h chosen finite diagnostic values, not original root parameters.')

def main():
 models=[];stages=[]
 for args in fixtures():
  b=sum(SOURCE.values());l=sum(LOG.values());models.append(model(*args));stages.append(dict(name=args[0],source_exact_checks=sum(SOURCE.values())-b,log_rational_interval_checks=sum(LOG.values())-l))
 # Endpoint algebra only: alpha=1 cannot occur with the strict actual highpast gate above.
 endpoints=[dict(alpha=str(a),beta=str(b),result=bernoulli(a,b,r)) for a,b,r in [(F(0),F(0),F(2)),(F(1),F(1),F(1)),(F(1),F(1,2),F(2)),(F(1,2),F(0),None),(F(1,2),F(1,2),F(1))]]
 out=dict(status='PASS',total_source_exact_checks=sum(SOURCE.values()),total_log_rational_interval_checks=sum(LOG.values()),source_check_counts=dict(SOURCE),log_check_counts=dict(LOG),stages=stages,models=models,endpoint_algebra_only=endpoints,scope='Accepted-source bridge and Bernoulli identity only. Source/traffic rational checks separate from outward rational log intervals; no global source funding, continuum receiver proof, or full historical qualification.')
 (BASE/'r343_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['status','total_source_exact_checks','total_log_rational_interval_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
