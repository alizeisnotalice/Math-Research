# R343 — Shared-source heat bath, exact entropy credit, and the capped-log screen

**Status.** No new root-order payment for localbad is obtained. The actual source identity improves the available receiver-side entropy account, but its cost is not absorbable. Capping the logarithm recovers the original far traffic rather than a new source budget. This note stops at these checked conclusions.

## Fixed original field and the true source marginal

Keep the full R340 hard contract, original E_r, m_u=q_uR_u^n, μ(du)=du/m_u, f, J_y(r), ell, H, and every original G_out gate. The large-endpoint set A may be the current localbad set. At fixed r put

    I_r(u,v)=∫ f(y)c_u(y)c_v(y)/J_y(r) dy,
    P_r(u,dv)=I_r(u,v)dv/(m_um_v),       u,v∈E_r.    (1)

Use zero on J=0. Tonelli gives ∫I_r(u,v)μ(dv)=m_u for du-a.e. u∈E_r. The exceptional captured source set where J=0 has zero joint measure, since its joint mass is ∫f1_{J=0}J=0. Thus P_r is a Markov kernel du-a.e. and du P_r(u,dv) is symmetric. All statements use actual Lebesgue receivers, not an abstract replacement matrix.

Its shared-source sampling law is

    f(y)J_y(r)dy × [c_u(y)μ(du)/J_y(r)]
                   × [c_v(y)μ(dv)/J_y(r)].          (2)

The source marginal is fJ, not f. Starting with source f and the two conditional receiver laws in (2) would omit one factor J. The high-past condition provides a lower bound for J on retained traffic, not the upper bound needed to erase this factor.

## Exact entropy credit and two honest costs

Write ρ_y(du)=1_{E_r}c_u(y)μ(du), J=∫ρ_y, V=∫mρ_y, and m_0=q_-a^n. The full row entropy is

    L_y(r)=∫m log(m/m_0)ρ_y
          −(V/J)∫log(m/m_0)ρ_y.                     (3)

It is also the full pair entropy from R342. Let L_A be its original oriented far/high-past/outside/A restriction. Put k=log K. Then

    k G_out(A) ≤ Γ_A :=∫ell∫f1_{J≥H}L_A
                ≤ Γ_H :=∫ell∫f1_{J≥H}L_y.          (4)

Every gate is unchanged on the left. The second inequality drops gates only for a positive upper bound.

Define the true receiver posterior fraction

    θ_H(u,r)=(1/m_u)∫f(y)c_u(y)1_{J_y(r)≥H}dy.

Thus 0≤θ_H≤1. Source integration of the first term in (3) gives the exact identity

    Γ_H = Ψ_H − C_H,                                 (5)
    Ψ_H=∫ell(dr)∫_{E_r}m_u log(m_u/m_0)θ_H(u,r)du,
    C_H=∫ell(dr)∫f(y)1_{J≥H}(V/J)
                          ∫log(m/m_0)ρ_y dy≥0.

This is the actual cancellation term; it is not an adjustable credit. In particular, using the complete original physical tail,

    Γ_A≤Γ_H≤Ψ_H≤Ψ,
    Ψ=∫E q_u log(m_u/m_0)du
      ≤[c+nT]X_q,
    c=log(λ/q_-),       T=log(b/a).                  (6)

Indeed ∫_[R_u,b]ell=R_u^(-n), including every selector atom and the original b atom. No new source or receiver bound is introduced.

Combining (6) with the already proved R342 real-center-volume entropy bound yields the honest estimate

    G_out(A)≤(1/k) min{
          Ψ,
          W[c+(1+c)nT+(n²/2)T²] }.                   (7)

For k=√n the two coarse scales are O(√n)X_q and O(n^(3/2))W. Neither gives εX_q+Cε√n polylog(n)W. The exact credit C_H and the original omitted-pair credit can improve (7), but neither is bounded favorably here. In particular Ψ cannot be substituted for Ψ_H−C_H and then advertised as an absorbable cost.

With H removed, source integration of (3) is exactly the Dirichlet form of the genuine reversible kernel (1):

    ∫fL_y=(1/2)∬du P_r(u,dv)
                       (m_u−m_v)log(m_u/m_v).        (8)

Equation (8) explains the fJ source marginal in (2). It is not a source-normalization theorem.

## Capped logarithm: what it does and does not buy

For a mass pair use the nonnegative symmetric kernel

    e_k(u,v)=|m_u−m_v|min{|log(m_u/m_v)|,k}.

Let L_cap,A be the original oriented gated row integral of e_k/J. Since the strict far gate has log(m_u/m_v)>k,

    L_cap,A = k g_A                                  (9)

exactly, where g_A is the original G_out row. Thus capping removes the extra logarithmic charge but also makes the retained quantity precisely the original target times k. It does not construct a source-normalized flow.

The full capped row satisfies

    L_cap,all=(1/(2J))∬e_k dρ_y dρ_y≤kV.             (10)

To see this, replace the capped log by k and use |m_u−m_v|≤m_u+m_v. Therefore its integrated upper bounds are

    ∫ell∫f1_{J≥H}L_cap,all
       ≤ k min{X_q, [1+nT]W}.                        (11)

Here ∫ell∫fV=X_q follows from the same actual-source identity, while V≤r^n gives the second bound. Dividing (11) by k returns the existing unabsorbed receiver bound or order-n source bound. No threshold count or factor k is available a second time.

The sharper comparison to the original square-root dispersion D is

    L_cap,all≤k coth(k/4)D.                           (12)

For x=|log(m_u/m_v)|>0, the pairwise ratio is min(x,k)coth(x/4). It increases to k coth(k/4) for x≤k and decreases thereafter. The first monotonicity follows from sinh(t)cosh(t)≥t; zero-gap pairs contribute zero. After division by k, (12) recovers the previous c_K D comparison, with c_K=coth(k/4). It adds no new overlap credit.

Consequently no source bridge is obtained from truncation alone. A valid continuation must control the fJ-weighted actual pair flow using the true negative credit in (5) and/or the original omitted pairs, or supply a source-flow construction with its J-weight and multiplicity explicitly paid. Source conditional entropy with marginal f cannot replace the marginal in (2) without that step. No new row stress family or general counterexample is asserted.

## Verification

The saved check script uses a genuinely realizable positive-volume one-dimensional cube field to verify the heat-bath/source marginal and exact entropy cancellation. This is a diagnostic of (1)–(8), not a test of the localbad high-past target. Actual execution details follow below.

`/tmp/r343_core_checks.py` was actually run with Fraction arithmetic: 5 geometry assertions, 12 heat-bath/source-law assertions, 4 entropy-credit assertions, and 144 capped-pair cases passed. The real-dx fixture has f=50 on [-1/100,1/100]∪[99/100,101/100], receiver intervals [-1/20,1/20] and [9/20,11/20], and respective radii 1,2. Every receiver cube has q=1; m=1,2 and receiver volumes are both 1/10. Its source marginal masses in (2) are 3/20,1/20, while the original source masses are 1,1. The entropy is exactly (log 2)/30 at r=2; the complete original ell integral is (log 2)/60. Source incidences are constant over the entire positive-volume receiver intervals, checked at the extremal endpoints, so these calculations are continuous-field integrals rather than a point-receiver approximation. The capped-pair checks use masses 4^i and K=4^d, allowing exact rational log coefficients. None of these checks establishes a localbad/high-past payment. Only this note and its check script are authored; bounded work stops here.
