# R343 independent preauthor screen — common posterior Bernoulli entropy

Owned only `/tmp/r343_audit.md`; no Git/other-author edits and no R343 author proof read for this screen. Fixed original hard-matched field, actual finite receiver du, f>=0 in L1, m_u=f(Q_u)=q_uR_u^n with q_-<=q_u<=lambda, 0<a<=R<=b, original full prefixes/J, H, strict mass/past/center gates and inclusive ell. This is an exact interface/entropy comparison, NOT a new root budget.

## Disposition and common-test normalization — PASS

Take K>lambda/q_->=1, h>0 and fixed(r,u,v) with u,v in E_r and m_u>K m_v. For every source y define the SAME test for the two original posteriors

 a_uv(y)= (h/J_y(r))1_{J_y(r)>=H}1_{Z_y(m_u/K-)>h}c_u(y)c_v(y),

zero on J0. The original strict global past of m_u/K consists of receivers w with

 R_w^n=m_w/q_w < m_u/(Kq_-) <=lambda R_u^n/(Kq_-)<R_u^n.

Thus all that past is already present in E_r whenever r>=R_u. On the positive test set J_y(r)>=Z_y(m_u/K-)>h. Consequently0<=a_uv<=1. It is not necessary to lower-bound J outside the original source gate, where the test is zero. This implication cannot be dropped for pairs whose large endpoint has not entered the prefix.

Under the ORIGINAL posterior probabilities p_u(dy)=f(y)c_u(y)dy/m_u and p_v defined similarly, let

 alpha=integral a_uv dp_v, beta=integral a_uv dp_u.

Both use the same actual common source, same test and same original denominator. They satisfy the exact linear relation beta=(m_v/m_u)alpha, including the zero case. In particular alpha0 iff beta0, and alpha>0 gives alpha/beta=m_u/m_v>1. The weighted common-source overlap Istar=int f c_u c_v1_H1_past/J equals m_v alpha/h. It is not the unweighted I_uv, and no factor h may be omitted from this identity.

Joint measurability follows from the frozen cube/radius/prefix/past fields and nonnegative source integration. No favorable test is selected separately under the two probabilities; doing so would destroy the ratio identity.

## Exact binary identity and global factors

Let R=m_u/m_v>1. Use the binary relative entropy

 d(alpha||beta)=alpha log(alpha/beta)+(1-alpha)log((1-alpha)/(1-beta)).

For alpha=beta=0 set d0,c0. For alpha1 take beta1/R<1 and set the zero-complement product below to0, giving d=log R,c0. There is no beta0<alpha situation in this construction; all entropies are finite. The actual strict-J test generally has alpha<1, but the endpoint convention remains correct.

The exact identity is

 alpha log R=d(alpha||beta)+c,
 c=(1-alpha)log((1-beta)/(1-alpha)),
 0<=c<=alpha-beta=alpha(1-1/R).

The upper inequality is log(1+x)<=x, with endpoint limits. All logs are of dimensionless probability or mass ratios.

Let chi_out(r,u,v) retain the original outside-center and optional large-endpoint A gates, besides the strict far domain. Define the positive receiver-pair weight w=1-1/R, and integrate all quantities against original du dv ell with these gates. Then the ORIGINAL traffic satisfies

 h G_out(A)=integral ell du dv chi_out1_far w alpha,
 h L_A=integral ell du dv chi_out1_far w alpha log R,
 RawD=integral ell du dv chi_out1_far w d.

The source1/J,H and global-past gates have been integrated INSIDE alpha, not dropped or changed. It follows exactly that

 RawD=h L_A-Ccorr,
 0<=Ccorr<=h G_out(A),
 h(log K-1)G_out(A)<=RawD<=h L_A.                     (1)

There is no missing m_u/m_v or symmetric1/2 factor: this is the original ordered far traffic. Original physical terminal/selector atoms remain in ell. For log K>1, (1) gives the proposed positive comparison. If K=exp(sqrt(n)), the stated crude lower coefficient vanishes at n1; one must not divide by it there.

A directly sharper bound, if desired, follows from the already proved c<=alpha(1-1/R). The function log R-1+1/R is increasing for R>1, so

 RawD>=h[log K-1+1/K]G_out(A).                       (2)

This coefficient is positive for every K>1, including K=e at n1. This optional scalar sharpening is NOT a new source payment or a bound on RawD; the coarse statement(1) is correct with its stated endpoint restriction.

## Finiteness and precise missing source budget

The fixed hard band gives positive uniform mass bounds q_-a^n<=m<=lambda b^n, a finite range of log R, finite actual mu(E) and original finite ell. All source/pair tests are bounded probabilities. More sharply0<=RawD<=h L_A and the original row entropy's proved elementary bound makes the integral finite. Even a receiver-du pair bound by finite |E|^2 and the bounded log range suffices here. No infinite-relative-entropy object is subtracted.

This construction does not provide a conserved GLOBAL source entropy budget. There is a different test for each(r,u,v) and a repeated receiver-pair/physical-layer measure du dv ell. A bound for one Bernoulli divergence, or the entropy W log N of a single nested SOURCE partition, cannot be integrated against that repeated measure without a proved multiplicity/flow statement. Full posterior KL can moreover be infinite when the two cube supports have exclusive source regions; the finite binary test is not a claim that the full laws have uniformly finite entropy. A source data-processing inequality alone therefore supplies no root estimate for the actual pair integral.

The currently available covariance/log-mass bound from the exact row account is still coarse: L_A<=L_row and integral f ell L_row is at most W[c+(1+c)nT+n^2T^2/2], c=log(lambda/q_-),T=log(b/a). Thus RawD<=h times that quantity, which does not close the desired root budget after the log-K comparison. To improve it one needs an actual common-source allocation/occupation or source-flow certificate for the weighted repeated tests, retaining original full J and ell and pricing its complement. No such statement is inferred by this screen.

## Actual local tool use and stopping point

Reviewer ran30 exact rational alpha/beta probability/ratio guards and120 ordinary Decimal80 scalar entropy/correction assertions, including alpha0 and1. All passed. The Decimal checks are NOT interval certificates or proof of an integrated entropy budget; the general identities above are analytical. No original cube field, high-past fixture, full numeric pipeline or global source-flow model was simulated.

Independent proposition screen PASS for the stated frozen contract and factors, with the crude n1 division restriction as stated (or optional valid strengthening(2)). No new root or epsilon/source payment is certified. Await author/file comparison and final integration before an archive freeze; only this audit file was written.


## Final geometry author comparison — PASS

Read complete `/tmp/r343_geometry.md` and its scalar checks after the independent screen. The final version adopts the valid sharp coefficient kappa_K=log K-1+1/K, so it never divides by the degenerate coarse coefficient at n1. The acceptance test includes precisely the original source/H/past/capture factors and h/J. Actual far-past radius ordering proves it is in[0,1]; it is the SAME test under the two actual posteriors. Their ratio is the original mass ratio only when acceptance is positive, with the linear relation still valid at zero. The weighted common-source overlap, actual du dv endpoint measures and the indispensable factor h are all retained in equations(3)-(7).

The Bernoulli correction is included with the proper sign and endpoint convention. The normalized entropy budget is stated as a missing estimate, not concluded from the scalar lower bound. Source-tree depth reuse costs D W and conditional source entropy D W log2, not a single W resource regardless of depth. The repeated per-mass-band source upper cost remains order n on a full octave and cannot be divided by log K without an actual flux traversal. No root payment, free source tree or generally impossible bridge is claimed.

Parent reports actual fresh geometry execution43 exact Fraction assertions (28 ratio guards,3 h-factor identities,12 depth-reuse identities) plus56 ordinary Decimal70 assertions (not interval certificates). Code inspection agrees with those limited scalar scopes. Neither the tests nor the analytic inequality bound the integrated accepted entropy by a root source fee.

## Final core heat-bath/entropy comparison — PASS

Read complete `/tmp/r343_core.md` and its script. For fixed r, the kernel with density I_r(u,v)/(m_um_v) relative to actual dv is Markov du-a.e. The captured J0 exceptional sets have zero JOINT source/receiver mass by Tonelli; hence the claimed a.e. row identity is valid without changing actual receiver measure. The kernel is reversible for du. Its shared-source mixture has marginal f(y)J_y(r)dy, whose mass is |E_r|, not W. Omitting that J would change the flow law, and high past provides the wrong-direction bound to erase it.

The exact integrated identity Gamma_H=Psi_H-C_H retains a nonnegative, fixed entropy cancellation. Actual hard source matching and the original inclusive tail give Psi<=integral q_u log(m_u/m_0)du<= [c+nT]X_q. This is not an epsilon receiver bill; after division by log K it can be order sqrt(n)X_q. The alternative real-center bound remains order n^(3/2)W. Neither is registered as a new payment.

Capping the log on original far pairs yields exactly(log K)times the original traffic. The full capped upper bounds recover only X_q or A_n W, and the capped-to-square-root ratio k*coth(k/4) gives the previously derived c_K after division. The monotonicity and coefficients are correct; no extra original square/negative credit is subtracted. The real positive-volume one-dimensional fixture has actual hard q1 on both continuous receiver intervals, complete source masses1,1, source marginal masses3/20,1/20, row entropy(log2)/30 at r2 and original ell integral(log2)/60. Extreme endpoint checks establish constant incidences on the entire intervals. It is not a localbad/high-past fixture.

Parent reports completed165 core check units:5 geometry,12 heat-bath/source-law,4 entropy-credit and144 capped-pair cases. The capped cases contain multiple asserted facts in some cases; unit counts are not silently promoted to numbers of distinct original fields. These calculations are exact Fraction/log-coefficient diagnostics, not a general source-flow estimate.

## Final numeric code, notes and result — PASS for the stated bounded interface

Read the full numeric code, final notes and result metadata. The source f=1_Q4 is integrated over its complete positive-volume cube-face partition, with the zero incidence pattern retained. Original cube masses and q1 are checked exactly. Actual receiver entries have finite quadrature weights, so they are not claimed to be a continuum du construction. Source high-past, H, J and physical ell/terminal atom are kept in the tested massgap identities. H can genuinely reject sources; exact H ties remain included.

The final notes correctly disclose that NO outside-center restriction is imposed in this numeric test, although a fixed source-independent pair mask could be placed on both sides of its identity. The script thus tests the acceptance bridge, not a computed value of the full original G_out. Its rational K/h choices are not root parameters. In particular the n1 choice K=5/4 is below the sufficient universal lambda/q_-=4/3 criterion, but q is ACTUALLY constant1 in this fixture and every past's physical-prefix inclusion is explicitly certified, so its finite acceptance calculation is valid. This does not weaken the theorem's stated sufficient condition or certify its general instance at K=5/4.

The independent source overlap sums preserve O=m_v alpha/h=m_u beta/h and exact quadrature traffic ell*w_i*w_j(alpha-beta)/h. O is the weighted overlap and may exceed1; alpha,beta are the probabilities. Positive beta0/alpha>0 arises only in the explicitly separate algebraic endpoint test with infinite KL; it is not claimed to occur under the original common test. Actual strict-past acceptance gives alpha<1. Source support, rejection terms and zero acceptance are not discarded.

Rational log enclosures use positive atanh expansions with geometric tails and reciprocal/range reduction, so the563 interval comparisons are outward rational certificates, not exact evaluations of logs. The ordinary decimal displays are excluded from both exact source/traffic and interval counts. Parent reports completed fresh numeric7599 exact source/traffic checks plus563 rational-log comparisons. Saved result independently reads PASS and stages280/941/6378 source checks,96/168/288 plus11 endpoint log checks. They do not constitute global entropy funding, continuum receiver proof, the original high-past parameters or full historical qualification. Reviewer's separate30 exact plus120 ordinary scalar checks are not added to primary counts.

## Final main and complete ledger — PASS, zero new payment

Read final `/tmp/r343_main.md` and `/tmp/r343_ledger.md`. They consistently use kappa_K, distinguish Bernoulli p/q from original q_u, and keep all original endpoint/source/clock factors. The proposed accepted-entropy budget is explicitly unproved. The source fJ marginal and unresolved conditional entropy are not mistaken for a bounded f-source Shannon resource. No auxiliary identity or finite experiment receives a new source bill, receiver epsilon or negative credit.

The ledger is the unchanged R342 source-only local-growth replacement: hard slot2epsilon X_q, inherited entrance4epsilon X_q, source C_epsilon,n+2[1+3sqrt(n)+log(8/3)], and the original localbad residual. The inherited8lambda H W_beta and2d_eff A_n W_nu/H remain; no new completion fee is added. W_beta=f and nu<=f refer to the same hard matched source/response; the historical entrance is carried conditionally rather than re-certified in its entirety. The previous exact arithmetic remains4*(128/119)*(119/3072)=1/6, plus the authentic same-X CZ1/256 gives131/768 and637/768 unallocated. This round does NOT add another1/6.

The full unpriced localbad traffic, general soft crossing/post-crossing and nonembedded hard slots, wide/extreme scales and low-pe complements, chronological initial/deletion/future-source atoms, suffix credit, source/scale/outer sums and limits all remain due. No inference of global root closure or “only constants/logs remain” is certified. Next progress needs a genuinely bounded shared-source flow/correlation/geometry estimate, not another unpriced representation of this same accepted entropy.

## Final bindings and disposition

Only this audit file was written by the reviewer. No full numeric pipeline/optimizer or TeX/PDF compiler was rerun by the reviewer. Actual parent replay reports and saved result metadata are distinguished from independent code/proof inspection. The prior hard contract and R342 covering proof are unchanged inherited source files bound below; their inclusion supports self-contained location, not a re-audit of all historical coefficients. Earlier awaiting statements record independent preauthor stages and are superseded here.

| File | SHA256 |
|---|---|
| /tmp/r343_geometry.md | `301e9ec2599badbef9c9be78bdad4b45b550eb5ca61e8a2b9711bf7c1e0b4566` |
| /tmp/r343_geometry_checks.py | `8283869fc6fe0ddedf087b0b03756cb4109665f01e8956c1eaad81cd36b7cc37` |
| /tmp/r343_core.md | `63b5db7e7df3f77fbffa8253ac34d631740d31277208efd145e371c4b785c909` |
| /tmp/r343_core_checks.py | `079bd5fe7e606c3521e8b9d35ad02dbfb77028be3123430915f1b2e7c5f5bac9` |
| /tmp/r343_main.md | `feed9bae36fdc3bb3b6a13a095a5a1fca4aeead507221c6863eaaace74049f3c` |
| /tmp/r343_ledger.md | `016834874f6eec2db7e930fd4c48f6c02cfbde5078e0b9c2ee4fe1fc4ce4560a` |
| /tmp/r343_numeric.py | `9b4ff5d305d376032d3587f723efc952dd859ea4515166123dd97e944b97cc5b` |
| /tmp/r343_numeric.md | `0f8b19aa017abe14442d6451f94ee81610dee947aabf6b3e1e0f398868cf63c7` |
| /tmp/r343_numeric_result.json | `d16ce9939045cbb6c7b160b1428973e61f62d39ef5c63e308c54fdc5353cf2af` |
| /tmp/r340_core.md | `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90` |
| /tmp/r342_geometry.md | `d8d62f1ad59e894ed936fdd64328e608a1b6b682190dbc3b45aed826571dd983` |

Final disposition: PASS for the exact accepted-source entropy bridge, auxiliary identities, evidence scope and unchanged complete ledger. No outstanding correction requested. Frozen after final byte bindings; later changes require a new binding. No new root payment or general global closure is established.
