"""Scalar source-acceptance entropy checks; not a full traffic simulation."""
from fractions import Fraction as F
from decimal import Decimal, localcontext


def dec(x):
    return Decimal(x.numerator)/Decimal(x.denominator)

counts={'exact_likelihood_ratios':0,'decimal_entropy_identities':0,'decimal_correction_bounds':0,'exact_h_scaling':0,'exact_tree_reuse':0}
with localcontext() as ctx:
    ctx.prec=70
    for ratio in [F(2),F(4),F(8),F(16)]:
        for alpha in [F(1,100),F(1,8),F(1,4),F(1,2),F(3,4),F(99,100),F(1)]:
            beta=alpha/ratio
            assert alpha/beta==ratio
            counts['exact_likelihood_ratios']+=1
            a,b=dec(alpha),dec(beta)
            first=a*(a/b).ln()
            if alpha==1:
                kl=first; correction=Decimal(0)
            else:
                kl=first+(1-a)*((1-a)/(1-b)).ln()
                correction=(1-a)*((1-b)/(1-a)).ln()
            assert abs(first-kl-correction)<Decimal('1e-60')
            counts['decimal_entropy_identities']+=1
            assert -Decimal('1e-60')<=correction<=a-b+Decimal('1e-60')
            counts['decimal_correction_bounds']+=1
# I_a=h I_weighted; alpha=I_a/m_v. Preserve the h and endpoint factors.
for h,mu,mv,Iweighted in [(F(2),F(8),F(1),F(1,8)),(F(3),F(16),F(2),F(1,6)),(F(1,2),F(9),F(3),F(1))]:
    Ia=h*Iweighted
    alpha=Ia/mv
    assert (mu-mv)*Iweighted==mv*(mu-mv)*alpha/h
    counts['exact_h_scaling']+=1
# A complete balanced binary source partition reuses exactly W at each level.
for depth in range(1,13):
    W=F(7,3)
    reused=sum(2**level*(W/F(2**level)) for level in range(1,depth+1))
    assert reused==depth*W
    counts['exact_tree_reuse']+=1
print({'counts':counts,'exact_assertions':counts['exact_likelihood_ratios']+counts['exact_h_scaling']+counts['exact_tree_reuse'],'decimal_assertions':counts['decimal_entropy_identities']+counts['decimal_correction_bounds'],'status':'passed'})
