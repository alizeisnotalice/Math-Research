# R343 — Accepted source-likelihood bridge and the unresolved reuse fee

**Status.** No new root-order payment for the R342 localbad traffic is proved. The new exact statement below incorporates the true f/J source weight and all original gates into a finite Bernoulli source-likelihood comparison. Its remaining budget is stated explicitly; a bounded source Shannon entropy is not substituted for it.

## 1. Exact original branch and common acceptance

Use the unchanged R342 hard contract and original G_out. Let A be the current localbad endpoint set

    A={u:m_u<e^{-√n} f(Q_{(1+√n)b}(u))},

or any fixed measurable subset of E. Retain the original actual du,dv, full masses m, source f, original J, physical ell including the b atom, K,h,H, global strict past, and outside-center gate. Put

    D_r={(u,v)∈E_r²:u∈A, m_u>K m_v,
                         ||u-v||∞>α_out R_u/2},

where α_out is the original center-dilation parameter. For (u,v)∈D_r define the *common* source acceptance function

    a_{r,u,v}(y)=h 1_{Q_u}(y)1_{Q_v}(y)
                1_{J_y(r)≥H}1_{Z_y(m_u/K-)>h}/J_y(r),             (1)

with value zero on zero-J rows. The original far ratio, K>λ/q_-, ensures every strict small-mass receiver is already in E_r when u∈E_r. Thus J_y(r)≥Z_y(m_u/K-)>h on this acceptance set, and

    0≤a_{r,u,v}≤1.

Define the real source posteriors and accepted probabilities

    p_u(dy)=f(y)1_{Q_u}(y)dy/m_u,
    A_{r,u,v}=∫a_{r,u,v} dp_v,
    B_{r,u,v}=∫a_{r,u,v} dp_u.                                      (2)

The symbols A_{r,u,v},B_{r,u,v} denote probabilities; they are distinct from the endpoint set A. Both use exactly the same acceptance function, not privately chosen tests.

Because (1) is supported on the actual common intersection,

    B_{r,u,v}=(m_v/m_u)A_{r,u,v}.                                  (3)

This remains true when both probabilities vanish. For positive A_{r,u,v}, their likelihood ratio is exactly m_u/m_v>K. No nesting of Q_v inside Q_u is needed and no infinite KL(p_v||p_u) is invoked.

Changing the endpoint measures using dμ=du/m gives the exact original branch

    G_out(A)=(1/h)∫ell(dr)∬_{D_r}
                   (1-m_v/m_u)A_{r,u,v} du dv.                    (4)

In particular the factor h, the Lebesgue endpoint measures, and the source acceptance from the original high-past and 1/J weights are all retained.

## 2. Finite Bernoulli entropy and the support correction

For probabilities 0≤B≤A≤1 with B=A/r and r>1, use the usual endpoint conventions for Bernoulli relative entropy

    d_B(A||B)=A log(A/B)+(1-A)log((1-A)/(1-B)).

Then the exact identity is

    A log r=d_B(A||B)+C(A,B),
    C(A,B)=(1-A)log((1-B)/(1-A)),
    0≤C(A,B)≤A-B≤A.                                                (5)

For A=1 the correction is its limiting value 0; for A=B=0 all terms are zero. The upper bound follows from log(1+x)≤x. Thus this expression accounts for the outside-support completion instead of ignoring it.

Define the actual accepted entropy quantity

    D_raw(A)=∫ell(dr)∬_{D_r}(1-m_v/m_u)
                      d_B(A_{r,u,v}||B_{r,u,v}) du dv.              (6)

All receiver gates and the original physical clock remain as in (4). Use the sharper correction bound C(A,B)≤A-B=A(1-1/r) in (5). Then

    d_B(A||B)≥A[log r-1+1/r].

The function log r-1+1/r is increasing and strictly positive for r>1. Define

    κ_K=log K-1+1/K>0.

Multiplying by the nonnegative endpoint weight and integrating yields, for every K>1,

    h κ_K G_out(A)≤D_raw(A).                                       (7)

This is the promised finite source-likelihood bridge. It uses the actual far ratio and high-past acceptance, rather than raw unweighted overlap I_uv. For K=e^{√n}, κ_K=√n-1+e^{-√n}; the bound remains nondegenerate at n=1. The weaker factor log K-1 is unnecessary.

## 3. What still has to be paid

A root-order conclusion would follow, for example, from the new estimate

    D_raw(A)/h ≤ κ_K δX_q + C_δ n polylog(n) W,                 (8)

with the corresponding √n source fee after (7). No such estimate is proved here.

In fact (5) also gives d_B(A||B)≤A log r. Thus

    D_raw(A)/h
       ≤ ∫ell(dr)∫f(y)1_{J_y(r)≥H} L_A(y,r)dy,                     (9)

where L_A is exactly the original gated receiver-pair logarithmic account of `/tmp/r342_core.md`, not a new source entropy. Its available coarse bound is

    D_raw(A)/h
       ≤ W[c+(1+c)nT+(n²/2)T²],
    c=log(λ/q_-),    T=log(b/a).                                  (10)

The inclusive physical tail in that formula contains the original b atom. In a general octave, (10) is O(n²)W, so (7) gives only O(n^{3/2})W, not a root bound. The improvement needed in (8) is a full factor of n in the normalized entropy budget. Formula (7) is consequently not entered as a paid improvement in the main ledger.

A common source partition alone does not bound (6): its endpoint weights are the actual du dv(1-m_v/m_u), and its Bernoulli experiment still depends on the receiver pair through the original full-J acceptance. The Shannon entropy of the source cell probabilities is a different quantity. Projecting a joint accepted law to source-cell labels also leaves a nonnegative conditional relative entropy inside each label; dropping that term would reverse the upper bound needed here. No source-flow domination of (6) is established.

## 4. The precise recursive reuse cost

For a common nested binary source partition with exact half-mass children, each depth has total source mass W. Charging a source-mass receipt at every one of D depths therefore costs exactly

    Σ_{depth=1}^D Σ_{cells at that depth}W_cell = D W.               (11)

The corresponding actual conditional source entropy is D W log 2, not W log 2. This is a calculation for a single shared source tree, not private endpoint partitions.

The R342 source-window receipt applied separately to large-endpoint mass bands of log-width s costs at most

    [1+log(λ/q_-)+s]W

per band. The entire allowed mass interval has log-width

    Δ=log(m_max/m_min)=log(λ/q_-)+n log(b/a),
    m_min=q_-aⁿ,       m_max=λbⁿ.

Using at most 1+ceil(Δ/s) bands therefore yields the explicit repeated-source fee

    [1+ceil(Δ/s)] [1+log(λ/q_-)+s] W.                               (12)

With s=log K=√n, this remains O(n)W in a full octave. Thin windows and wider windows merely trade the number of repeated W charges against the per-window logarithm in this calculation. When a recursive construction also has overshooting small children or nonrepresented pair pieces, their actual traffic must additionally be retained; (12) does not pay them.

The far mass ratio cannot divide (12) for free: that receipt assigns each pair according to its large endpoint and does not establish a log K-fold source-entropy traversal. To use a shared source tree at root cost, the missing positive assertion is a domination of the actual accepted entropy (6), or the actual cut flux from R342 core, by a source-tree conditional entropy resource with a proved bounded reuse factor. Equations (7),(10)–(12) specify the current deficit without equating receiver and source entropies. No new counterexample or general impossibility claim is made.

## 5. Verification

`/tmp/r343_geometry_checks.py` was actually executed. It passed 43 exact Fraction assertions (28 likelihood ratios, 3 retained-h-factor identities, 12 exact depth-reuse identities) and 56 Decimal assertions at precision 70 (28 Bernoulli identities and 28 support-correction bounds, tested with tolerance 10^{-60}). The Decimal checks are numerical diagnostics, not exact logarithmic certificates. These scalar tests do not simulate the full original traffic or establish (8). The identities and inequalities are proved above. Reproduce with `python3 /tmp/r343_geometry_checks.py`.
