"""R343 exact checks: real positive-volume cube field, plus capped-log algebra."""
from fractions import Fraction as F
counts={"geometry":0,"heatbath":0,"entropy":0,"capped_pair":0}
source=[(-F(1,100),F(1,100)),(F(99,100),F(101,100))]
receivers=[(-F(1,20),F(1,20)),(F(9,20),F(11,20))]
R=[F(1),F(2)]; density=F(50)
source_mass=[(b-a)*density for a,b in source]
vol=[b-a for a,b in receivers]
incidence=[[1,0],[1,1]]
for i,(left,right) in enumerate(receivers):
    for j,(a,b) in enumerate(source):
        if incidence[i][j]:
            assert right-R[i]/2<=a and b<=left+R[i]/2
        else:
            assert b<=left-R[i]/2 or a>=right+R[i]/2
        counts["geometry"]+=1
m=[sum(source_mass[j]*incidence[i][j] for j in range(2)) for i in range(2)]
assert m==[1,2] and [m[i]/R[i] for i in range(2)]==[1,1]
counts["geometry"]+=1
mu=[vol[i]/m[i] for i in range(2)]
J=[sum(mu[i]*incidence[i][y] for i in range(2)) for y in range(2)]
I=[[sum(source_mass[y]*incidence[i][y]*incidence[j][y]/J[y] for y in range(2)) for j in range(2)] for i in range(2)]
P=[[I[i][j]*mu[j]/m[i] for j in range(2)] for i in range(2)]
for i in range(2):
    assert sum(P[i])==1
    counts["heatbath"]+=1
    for j in range(2):
        assert vol[i]*P[i][j]==vol[j]*P[j][i]
        mixture=sum(source_mass[y]*J[y]*(incidence[i][y]*mu[i]/J[y])*(incidence[j][y]*mu[j]/J[y]) for y in range(2))
        assert mixture==vol[i]*P[i][j]
        counts["heatbath"]+=2
assert sum(source_mass[y]*J[y] for y in range(2))==sum(vol)==F(1,5)
assert sum(source_mass)==2
counts["heatbath"]+=2
# Constant reference logs cancel. Coefficients below are exact multiples of log 2.
logcoeff=[F(0),F(1)]
dirichlet=sum(vol[i]*P[i][j]*(m[i]-m[j])*(logcoeff[i]-logcoeff[j])/2 for i in range(2) for j in range(2))
positive=sum(vol[i]*m[i]*logcoeff[i] for i in range(2))
credit=F(0)
for y in range(2):
    V=sum(incidence[i][y]*mu[i]*m[i] for i in range(2))
    logmoment=sum(incidence[i][y]*mu[i]*logcoeff[i] for i in range(2))
    credit+=source_mass[y]*V/J[y]*logmoment
assert dirichlet==F(1,30)
assert positive==F(1,5) and credit==F(1,6)
assert positive-credit==dirichlet
# For 1<=r<2 only the radius-one row exists, so entropy is zero.
# The original terminal ell atom at b=2 has mass 1/2.
assert dirichlet/F(2)==F(1,60)
counts["entropy"]+=4
# For masses 4^i, all log ratios are exact integer multiples of log 4.
for d in range(1,5):
    cK=F(2**d+1,2**d-1)
    for i in range(6):
        for j in range(6):
            gap=abs(i-j)
            normalized_cap=F(abs(4**i-4**j)*min(gap,d),d)
            square=(2**i-2**j)**2
            assert normalized_cap<=cK*square
            if gap>d:
                assert normalized_cap==abs(4**i-4**j)
            counts["capped_pair"]+=1
print("PASS",counts)
print("Real dx fixture: source marginal masses",[source_mass[y]*J[y] for y in range(2)],"receiver volumes",vol)
print("Entropy at r=2 is (1/30)log 2; full ell integral is (1/60)log 2.")
print("The fixture does not test the original localbad/high-past residual.")
