# R287 — exact cube-shell capacity for actual capped two-packet traffic

## 0. Main original-integrand payment: a fractional heavy-packet gate

Use the fixed R286 first-anchor partition C_k of the TWO original sources: mu=rho/(4lambda)+nu/q_-, iid mu anchors, and every source point belongs to the FIRST anchor ball of radius 2r containing it. This is a Borel disjoint partition up to sets null for both original sources; its realization is chosen before receiver, clock and auxiliary slots. Write m_(nu,k)=nu(C_k) and

V=b^n Psi_n(4r/b),  T0=4lambda V,
A_high(y,z)=E_partition sum_k 1_{C_k}(y)1_{C_k}(z)
                                      1{m_(nu,k)>=T0}.       (F)

Then A_high is a measurable function in [0,1], independent of the receiver, physical clock and auxiliary slots. For ANY remaining ORIGINAL positive traffic with the stipulated full-soft response, actual caps, near/source/history masks, original full Pi x Pi, R2<=D and ns<=D, its A_high fractional part satisfies

P_current,A_high <=2Lambda B_D W_nu
                 <=8Lambda sqrt(nD) W_nu.                  (P)

There is NO K, kappa, soft-menu B or positive coverage assumption in (P). This is a new root-level geometric source payment. If no packet has mass at least T0, its gate is zero. The exact leftover is the SAME original current traffic multiplied by 1-A_high. Thus (P) does not claim to solve the full target.

Proof at each actual physical xi: fix one partition, set rho_k=1_{C_k}rho, nu_k=1_{C_k}nu. On the ORIGINAL qualified receiver set,

F_k/q=(P_{s,L}*rho_k)/q<=1,
H_k=h_R*nu_k<=4lambda.

If H_k>0, the receiver lies in Q_b+B_1(A_k,2r), whose exact volume is V by Section 2 below. Hence each high cell satisfies

integral_E (F_k/q)H_k dx <=4lambda V<=m_(nu,k).

Sum only over high cells. Disjoint ORIGINAL source restrictions give sum_k m_(nu,k)=W_nu, so the total is at most W_nu. Taking the partition expectation and using Tonelli gives precisely the original pair factor (F), with true receiver measure dx. All current positive masks can stay on the left and be dropped only in the majorant. There is no attempt to recover ALL original near pairs from the partition, so no reciprocal capture-probability K is needed.

Now apply the original full-posterior upper-slot score bound f_D before the physical clock substitution, keep the actual L,R>=a_xi qualification and unique j until its sum is at most one, and integrate the uniform source price against dxi/xi. The partition and high-cell threshold b,r,T0 do not change with xi. The single outside 2Lambda proves (P).

Zero hard-mass cells cannot be high because T0>0; zero soft-mass cells contribute zero. With zero total anchor mass both original sources vanish. For nonzero anchor mass, the R286 first-hit partition covers both sources almost surely, because each source is absolutely continuous with respect to mu and the never-hit set is mu-null by Fubini. Each random cell mass is measurable by integrating its Borel indicator; the countable sum in (F) is at most one for each realization. Thus its expectation, all interchanges, and exact complement are well-defined. The soft source need not itself have bounded support for the elementary receiver-volume bound; only the hard cell support is used there.

The larger problem's required bridge remains the complement 1-A_high. The threshold V can be large, as quantified below; no free coverage follows from joint density or from the existence of the partition.

## 1. Precise constructive statement

Let rho,nu be finite nonnegative L1 sources supported in the same B_1(c,R0), with masses m_rho,m_nu. Let a<=a_xi<=L(x),R(x)<=b<=2a, ns(x)<=D and q_-=3lambda/4<=q(x)<=lambda. On the measurable qualified receiver set E retain the ORIGINAL full soft cap P_{s,L}*rho<=q and the ORIGINAL hard maximal cap M_[a,b]nu<=4lambda. These caps can also be inherited from larger original sources by positivity. Define

T_E=integral_E [(P_{s(x),L(x)}*rho)(x)/q(x)]
                    (h_{R(x)}*nu)(x) dx.

For u>=0 set

Psi_n(u)=sum_{k=0}^n binom(n,k)u^k/k!,
V_n(b,R0)=b^n Psi_n(2R0/b).

If m_nu>4lambda a^n put

t_nu=min{b,(m_nu/(4lambda))^(1/n)},
C_nu=V_n(b,R0)-(t_nu-2R0)_+^n.

Otherwise put C_nu=V_n(b,R0). Then, for the arbitrary actual variable selectors,

T_E <=4lambda C_nu.                                           (G)

This can be combined with the known actual capped two-packet estimate as

T_E <=min{
  4lambda C_nu,
  [6+4sqrt(2nR0/a_xi)] [(16/3)m_rho+(1+log B)m_nu]
}.                                                           (M)

No relation nu<=rho is used. No cap is assigned to a latent soft component, and (G) has no B, D or kappa factor. It is a true Lebesgue receiver-volume estimate exploiting the full hard maximal cap; it applies regardless of the two relative captures.

In particular the explicit extreme-mass condition

m_nu>=4lambda V_n(b,R0)                                     (H)

gives T_E<=m_nu, so this branch has a dimension-free original hard-source payment. More precisely, when m_nu>4lambda b^n,

T_E<=4lambda b^n[Psi_n(u)-(1-u)_+^n],  u=2R0/b.               (S)

For the R286 packets R0=2r=a/(8sqrt(n)),

u0=2R0/b=a/(4b sqrt(n)),
Psi_n(u0)<=exp(2sqrt(nu0))=exp(n^(1/4)sqrt(a/b)).              (E)

Thus the sufficient heavy threshold in (H) can still be exponential in n^(1/4). This theorem pays that explicit extreme packet-mass regime; it does not claim the remaining intermediate regime has a polylogarithmic price. The cost improvement is the minimum (M), and the full-cap subtraction in (G)/(S).

## 2. Exact outer volume, with no source-overlap factor

Write Q_b=[-b/2,b/2]^n. A receiver with (h_R*nu)(x)>0 for some R<=b lies in c+Q_b+B_1(0,R0), up to null boundary issues. This follows directly from x-z in Q_R subset Q_b for a contributing original z in B_1(c,R0).

The Minkowski sum Q_b+B_1(0,R0) consists exactly of points satisfying

sum_i (|x_i|-b/2)_+<=R0.

Partition by the k coordinates outside the cube. Choose those coordinates in binom(n,k) ways and their signs in 2^k ways. The remaining coordinates contribute b^(n-k), and the k positive excesses occupy a simplex of volume R0^k/k!. Consequently

|Q_b+B_1(0,R0)|
 =sum_{k=0}^n binom(n,k)b^(n-k)(2R0)^k/k!
 =V_n(b,R0).                                               (1)

This counts actual receiver volume once. It is not a sum over all source-centered cubes and carries no hidden overlap multiplicity.

## 3. The full maximal cap removes an interior cube

For every h in [a,b] with m_nu>4lambda h^n, a receiver satisfying

||x-c||_infty<(h/2-R0)_+

has the entire source ball inside Q_h(x), hence

(h_h*nu)(x)=m_nu/h^n>4lambda.

Such a receiver is excluded from E by the ORIGINAL maximal cap, even if its ACTUALLY selected R would give a smaller response. This is exactly where the full maximal cap matters.

If m_nu>4lambda a^n, let h approach t_nu from below through [a,b], or use h=b directly when m_nu>4lambda b^n. The union of the forbidden open cubes has volume (t_nu-2R0)_+^n. Its boundary has zero Lebesgue measure. At equality m_nu=4lambda a^n the argument does not grant a forbidden a-cube; this is why Section 1 uses the strict condition. The forbidden cube is contained in the outer Minkowski sum.

The actual integrand is bounded by 4lambda because its soft factor is at most one and the actual hard response inherits the maximal cap. It vanishes off the outer sum. Removing the forbidden interior cube therefore proves (G), and t_nu=b proves (S).

The argument uses no regularity of the selectors beyond measurability. Zero source mass gives T_E=0. Source restrictions, current masks, near gates and history qualifications may all remain on the left; deleting them only enlarges this nonnegative majorant.

## 4. Explicit dimensional cost and disjoint source allocation

Since binom(n,k)<=n^k/k!,

Psi_n(u)<=sum_{k=0}^infinity (nu)^k/(k!)^2<=exp(2sqrt(nu)).

For the last inequality, the 2k-th exponential coefficient is at least (nu)^k/(k!)^2 because binom(2k,k)<=4^k. Substitution R0=2r gives (E).

For ANY disjoint partition of the original sources into common-radius packets, sum (G) only over packets that satisfy (H), or the sharper condition m_nu>4lambda b^n and m_nu>=4lambda b^n[Psi_n(u)-(1-u)_+^n]. Each such packet has T_packet<=m_nu. Hence their total is at most the ORIGINAL hard-source mass, by disjoint allocation. This applies realization-by-realization to the R286 first-anchor partition. Recovering original pairs from that partition still costs the established K probability factor; it is not free and is not removed by this geometry theorem.

At each physical clock this pays the retained same-packet heavy branch by W_nu. Restoring the original full-posterior score bound, unique j and physical clock gives at most 2Lambda B_D W_nu for a fixed disjoint partition, or 2Lambda K B_D W_nu when the R286 same-cluster recovery with probability >=1/K is also needed. Those statements concern the indicated actual packet-heavy allocations only. The original 2Lambda occurs once.

## 5. Exact remaining scope

The theorem has not proved a dimension-free bound for ALL actual capped two-packet products. In particular, masses between roughly lambda a_xi^n and lambda b^n Psi_n(2R0/b) need not be paid by the geometric extreme-mass argument. The known kappa product estimate remains the available generic alternative in (M).

No low-capture contribution is silently treated as zero: (G) is valid for it, but only the stated mass condition turns that receiver capacity into a source payment without kappa. The next required improvement is to replace the worst-case outer receiver volume by a source-weighted boundary capacity in this intermediate regime, using the actual captured mass rather than the support ball alone.

## 6. Executed local mathematical checks

Python Fraction arithmetic was actually used to evaluate Psi_n at n=1,4,16,64,256, a=1,b=2,R0=1/(8sqrt(n)). The exact finite polynomial was converted to floating point only to check the analytic exponential upper bound (E) and 15 heavy-mass scalar ratios. Outputs Psi_n were respectively 1.125, 1.26188215, 1.56151547, 2.27422170, 4.24510774; all checks passed.

A separate exact rational check used n=1,a=1/2,b=1,R0=1/16=2r, lambda=1, source sites (0,1/16,1/8,1), rho masses (1,2,1,3), nu masses (1,4,1,6), and anchor masses rho/4+nu/(3/4). It enumerated all 24 weighted first-appearance anchor permutations, with probability product_k w_(pi_k)/(sum of remaining weights). The exact heavy threshold was T0=9/2. In every partition it checked

(number of high cells) T0 <= sum_high m_(nu,k) <= W_nu.

The expected paid hard mass was 629/54<=12=W_nu. The exact fractional gate matrix was

[89/108, 89/108, 35/54, 0]
[89/108, 1,      89/108,0]
[35/54,  89/108, 89/108,0]
[0,       0,      0,     1].

All entries were in [0,1], with genuinely fractional entries and zeros. This verifies the allocation arithmetic and the possibility of partial coverage, not any universal coverage fraction. These are finite atomic diagnostics, not an original continuous L1 history or a numerical proof of the analytic volume/capacity theorem. Only this Markdown deliverable was written for R287; no repository, Git or PDF operation was performed.
