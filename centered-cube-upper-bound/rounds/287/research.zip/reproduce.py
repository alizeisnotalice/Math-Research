from pathlib import Path
import json,hashlib,subprocess,sys
p=Path(__file__).resolve().parent
for name,h in json.loads((p/'manifest.json').read_text()).items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
saved=(p/'r287_checks.json').read_bytes()
subprocess.run([sys.executable,str(p/'r287_checks.py')],check=True)
assert (p/'r287_checks.json').read_bytes()==saved,'JSON mismatch'
print('ALL PASS; recomputed JSON is byte-identical')
