# R287 — one-sided actual capture, exact degree prices and adaptive source payments

## Bounded result

A lower bound on EITHER actual capture suffices for a new paid branch if its opposite-source neighbor degree has a controlled logarithm. The soft-capture branch pays only nu; the hard-capture branch pays only rho and retains a factor B. There is also an unconditional adaptive soft-capture gate with a prescribed linear nu budget and no degree cutoff.

Keep the same original sources, actual selectors, full response caps, posterior and physical clock as in `/tmp/r286_joint_mass.md`. Write A_xi=a_xi^n, q_-=3lambda/4, and B>=1 for the DIRECT full-soft point weak constant majorant proved in `/tmp/r285_symmetric.md` section 1. Retain all current original positive masks. At a fixed physical xi define

    p_y=P_{s(x),L(x)}(x-y), h_z=h_{R(x)}(x-z),
    N(y)=nu(B_1(y,r)), M(z)=rho(B_1(z,r)),
    d_rho(z,xi)=M(z)/(q_- A_xi),
    d_nu(y,xi)=N(y)/(4lambda A_xi).

The actual captures are

    c_rho= [integral_{B_1(z,r)}p_w rho(dw)]/[M(z)p_y],
    c_nu= [integral_{B_1(y,r)}h_v nu(dv)]/[N(y)h_z]

on contributing near pairs, with zero convention off that domain. The soft capture can exceed one. The hard capture lies in [0,1]. Zero M or N near fibers have zero original rho x nu product mass.

For I(u,v)=min(u,v)[2+log(max(u,v)/min(u,v))], define, for d>=0 and theta>0,

    m=max(1,theta d),
    Phi_rho(d,theta)=(d/m)[2+log B+log m],
    Phi_nu(d,theta)=(d/m) I(B,m),                         (1)

with zero values at d=0. The following raw traffic bounds hold for every fixed xi:

    T_{c_rho>=theta_rho}(xi)
       <=integral Phi_rho(d_rho(z,xi),theta_rho) nu(dz),   (2)

    T_{c_nu>=theta_nu}(xi)
       <=(16/3) integral Phi_nu(d_nu(y,xi),theta_nu)rho(dy).
                                                               (3)

Further original positive gates, including any restriction on the OTHER capture, can be retained on the left. Thresholds may also depend measurably on their indicated source endpoint, provided they are independent of the receiver and auxiliary slots.

## 1. Both natural point heights and the one actual capture cap

The original w(x)=integral_0^1 exp(-|x|/u)du lies in [0,1]. Since phi=h*w and integral h=1, phi<=1. Therefore every coordinate of (1-s)h+s phi is <=1, and

    p_y<=L^(-n)<=A_xi^(-1), h_z<=A_xi^(-1).

This is a direct point-height statement, not a cap on a latent component. The gated functions f=p_y/q and g=h_z have weak constants <=B/q_- and <=1, respectively.

On c_rho>=theta, the ORIGINAL full-soft cap gives f<=1/(theta M). Combined with the natural height, this is

    f<=u=1/[q_- A_xi max(1,theta d_rho)],
    g<=v=A_xi^(-1).

The general-height capped product bound gives

    integral f g <=u v I((B/q_-)/u,1/v)
                  =u I(B max(1,theta d_rho),1).

Multiplying this pairwise bound by the near-fiber rho mass M gives exactly Phi_rho in (1), since B max(1,theta d)>=1. Tonelli then proves (2). In particular the logarithm is attached to nu, with reciprocal M allocation; no rho packet is replicated.

On c_nu>=theta, the ORIGINAL hard cap gives h_z<=4lambda/(theta N). Now

    f<=u=(q_- A_xi)^(-1),
    g<=v=1/[A_xi max(1,theta d_nu)].

The same product calculation, multiplied by the near-fiber nu mass N, gives

    N u v I((B/q_-)/u,1/v)
       =(4lambda/q_-)(d_nu/m)I(B,m).

This is (3). The different orientation of B is real. For theta d>=1 and m>=B,

    Phi_nu=(B/theta)[2+log(theta d/B)],

while for 1<=m<=B it is d[2+log(B/m)]. The degenerate case B=m=1 with theta d<1 belongs to this latter formula, not to the displayed B/theta formula. Replacing the resulting B by log B is not justified by this argument.

## 2. Global logarithmic degree budgets, rather than a per-edge cutoff

The exact prices imply, for every theta>0,

    Phi_rho(d,theta)
       <=theta^(-1)[2+log B+log_+(theta d)],
    Phi_nu(d,theta)
       <=(B/theta)[2+log_+(theta d/B)].                  (4)

For the second inequality, set t=theta d/B. When theta d>=max(1,B), it is equality. When 1<=theta d<=B, use t(2+log(1/t))<=2. When theta d<=1, use d<=1/theta and 2+log B<=2B. This includes B=m=1 with theta d<1 without asserting equality there.

Define the source-weighted degree logarithms at the minimal physical length a:

    L_rho_to_nu=integral log_+(M(z)/(q_-a^n))nu(dz),
    L_nu_to_rho=integral log_+(N(y)/(4lambda a^n))rho(dy).

For 0<theta_rho,theta_nu<=1, since a_xi>=a, (2)-(4) give uniformly in xi

    T_{soft capture}
       <=theta_rho^(-1)[(2+log B)W_nu+L_rho_to_nu],
    T_{hard capture}
       <=(16B/(3theta_nu))[2W_rho+L_nu_to_rho].          (5)

These are genuine global weighted budgets, and allow arbitrary individual large degrees when their logarithmic source cost is integrable. The integrals are finite for each fixed source pair because M<=W_rho and N<=W_nu; their bounds may still depend on dimensionless total masses. No uniform root-level bound on these logarithms is inferred from the original response caps. This file uses no unproved entropy estimate.

## 3. Concrete moderate-log-degree branches and exact residual

For an unconditional explicit branch choice put

    ell=log(n+2), theta=1/ell, H=exp(ell^2).

Pay the current original integrand first on

    A={c_rho>=theta, d_rho(z,xi)<=H},

and then on the disjoint gate

    A^c intersect C,    C={c_nu>=theta, d_nu(y,xi)<=H}.

No lower bound on the OTHER capture is imposed in either payment. Equations (2)-(4) give raw source prices

    T_A<=ell[2+log B+ell^2]W_nu,
    T_{A^c intersect C}<=(16/3)B ell[2+ell^2]W_rho.      (6)

The exact leftover is the same current original integrand multiplied by

    ({c_rho<theta} union {d_rho>H})
      intersect ({c_nu<theta} union {d_nu>H}).           (7)

Thus the extreme-degree conditions are explicit, rather than hidden in a source normalization. If applied only to an already unspent R286 remainder, retain its original mask throughout; the same estimates hold and no previously paid branch need be charged again.

For D=O(log(n+2)), B is polynomial in log(n+2). Hence (6), multiplied by the one existing 2Lambda B_D, is sqrt(n) times a polylogarithmic source payment.

## 4. An all-degree adaptive soft-capture payment

There is a useful stronger sufficient branch with no arbitrary degree cutoff or averaged-log assumption. Choose any target budget J>=1, fixed before the receiver and clock. Set

    d_0(z)=M(z)/(q_-a^n),
    ell_rho(z)=2+log B+log_+d_0(z),
    theta_rho(z)=ell_rho(z)/J.                          (8)

The threshold may exceed one, which is legitimate because c_rho may exceed one. On the original gate

    c_rho(x,y,z)>=theta_rho(z),                         (9)

equations (2) and (4) give the unconditional raw source payment

    T_adaptive(xi)<=(3/2)J W_nu.                        (10)

Indeed d_rho(z,xi)<=d_0(z), and

    2+log B+log_+(theta_rho d_rho)
       <=ell_rho+log_+theta_rho
       <=ell_rho+log ell_rho
       <=(3/2)ell_rho,

using J>=1, ell_rho>=2 and log ell_rho<=ell_rho/2. Division by theta_rho proves (10). The threshold is a concrete logarithmic neighbor-degree requirement on the actual soft capture; no recovery factor is left unpaid. The threshold is below one precisely when J>ell_rho(z); on those source fibers the other capture is completely unrestricted. For very large degrees it demands correspondingly greater relative soft capture; no coverage claim is implied outside this exact gate.

The original score and clock price of (9) is therefore

    P_adaptive<=3Lambda B_D J W_nu.                     (11)

### Symmetric adaptive hard capture and sequential payment

There is a symmetric unconditional sufficient hard-capture gate. Put

    d_nu,0(y)=N(y)/(4lambda a^n),
    ell_nu(y)=2+log_+d_nu,0(y),
    theta_nu(y)=ell_nu(y)/J,              J>=1.

On the original gate c_nu>=theta_nu(y), equation (4) gives

    Phi_nu(d_nu(y,xi),theta_nu(y))
       <=(B/theta_nu)[2+log_+(theta_nu d_nu/B)]
       <=(B/theta_nu)[ell_nu+log_+theta_nu]
       <=(3/2)BJ.

Here d_nu(y,xi)<=d_nu,0(y), B>=1, J>=1, ell_nu>=2 and log ell_nu<=ell_nu/2. The raw and original score-clock prices are therefore

    T_hard adaptive(xi)<=8BJ W_rho,
    P_hard adaptive<=16Lambda B_D BJ W_rho.              (12)

If theta_nu>1 the hard gate is empty because c_nu<=1; the same price remains valid. Thus the statement covers every source degree without silently imposing an unmentioned cutoff.

For the final sequential ledger, let I_0 be the original current positive integrand, and let A in [0,1] be the already paid upstream heavy-fraction allocation, so its remainder is I_0(1-A). Keep every original source cut, qualification, full posterior, physical selector and remaining positive mask inside I_0. Define

    G_rho=1{c_rho>=ell_rho/J},
    G_nu=1{c_nu>=ell_nu/J}.

The exact disjoint-after-allocation identity is

    I_0=I_0 A
        +I_0(1-A)G_rho
        +I_0(1-A)(1-G_rho)G_nu
        +I_0(1-A)(1-G_rho)(1-G_nu).                     (13)

The two new adaptive terms have combined raw price

    (3/2)J W_nu+8BJ W_rho,

and combined original score-clock price

    3Lambda B_D J W_nu+16Lambda B_D BJ W_rho.            (14)

Choosing J=log^3(n+2) gives a root-polylog price when D=O(log(n+2)), with no arbitrary H gate. The exact remaining original integrand is

    I_0(1-A)1{c_rho<ell_rho/J, c_nu<ell_nu/J}.          (15)

All thresholds are fixed from the original source pair and its minimum physical length before the receiver and auxiliary slots are chosen. This is an additional positive source payment; it makes no claim that the residual in (15) vanishes.

## 5. Strictly added one-sided coverage in an admissible local L1 configuration

This local example shows that removing the other capture genuinely adds positive raw traffic, even in the R285 jointly dense region. It is not a construction of a full original history.

Take n=1, lambda=q=a=b=L=R=1, s=0, r=1/16 and receivers x in E=(-.001,.001). Let rho have mass 3/4 uniformly on I=[.489,.491]. Let nu have mass epsilon>0 uniformly on I and mass 1 uniformly on J=[.514,.516]. For all x in E, I lies inside the selected unit interval and J lies outside. The actual soft response is 3/4<=q; the actual hard maximal response on [a,b]=[1,1] is epsilon<=4 when epsilon<=1.

Every contributing pair has y,z in I. Its neighborhoods contain all their respective relevant masses, so

    M(z)=3/4, N(y)=1+epsilon,
    c_rho=1, c_nu=epsilon/(1+epsilon), d_rho=1.

Both R285 density lower bounds hold, since kappa_1=6+4sqrt(1/8) and 3/4>4/kappa_1, 1+epsilon>(3/4)/kappa_1. Choosing epsilon small makes c_nu smaller than any fixed positive capture threshold while leaving positive traffic on E. The soft branch in (6) still pays it. This is precisely traffic excluded by the earlier two-capture gate and now included by a one-sided actual-capture estimate.

## 6. Original score and clock bookkeeping

Define all actual capture gates on the original row using its original s,L,R. The degree thresholds in sections 3-4 depend only on original sources and the physical clock, and never on the auxiliary slots. Retain the full Pi_t x Pi_t, the explicit upper-slot R2<=D qualification, and every current positive source/history mask while applying the original score bound. Only then make xi=c_jt/b and retain the unique actual j until its sum is at most one.

Each uniform raw price above is multiplied by exactly 2Lambda B_D, with B_D<=4sqrt(nD). Exact degree prices can instead be integrated against f_D(xi)dxi/xi before taking a uniform bound. No new grid factor, posterior, source domination, fixed-scale replacement or additional Lambda is used. Keep source-pair-dependent constants inside the original outer weighted sum unless a common bound is actually available.

## 7. Actual local diagnostics

A local Python run checked the generalized capped-product algebra against both exact formulas for 140 combinations of B, degree and capture threshold, including thresholds above one and degrees from 1e-12 to 1e12. The same run checked the hard logarithmic majorant, three adaptive budget levels per combination, and the two strict density inequalities in section 5. Output:

    PASS paired soft/hard height formulas, hard envelope and adaptive prices=140
    boundary example dense kappa=7.414213562373095

These floating diagnostics check algebraic consistency, not a continuous-history model or an interval certificate. The analytic inequalities above are the proof. Only this temporary Markdown deliverable was written.

The final adaptive-hard extension was also checked locally: 180 parameter combinations verified the symmetric adaptive price, and 16 rational cases verified the sequential ledger identity including fractional A. Output:

    PASS symmetric adaptive hard price checks=180 exact sequential ledger checks=16

These additional diagnostics have the same evidence limits as the preceding checks.
