#!/usr/bin/env python3
"""Portable deterministic R287 finite/scalar diagnostics. Requires mpmath."""
import json,random
from pathlib import Path
from fractions import Fraction as Q
from itertools import permutations
from math import comb
import mpmath as mp
R=random.Random(28720261017)

def I(x,y):return min(x,y)*(2+mp.log(max(x,y)/min(x,y)))
def evaluate(case,dps):
    with mp.workdps(dps):
        B,d,t,L,v=[mp.mpf(s) for s in case]; qm=3*L/4; m=max(mp.mpf(1),t*d)
        soft=d/m*I(B*m,1); hard=mp.mpf(16)/3*d/m*I(B,m)
        M=qm*v*d; N=4*L*v*d
        u=min(1/(v*qm),1/(t*M)); h=1/v
        softdirect=M*u*h*I((B/qm)/u,1/h)
        u=1/(v*qm); h=min(1/v,4*L/(t*N))
        harddirect=N*u*h*I((B/qm)/u,1/h)
        err=max(abs(soft-softdirect)/max(1,abs(soft)),abs(hard-harddirect)/max(1,abs(hard)))
        assert err<mp.mpf('1e-35')
        return +soft,+hard,+err

def scalar(count,spread,bmax):
    cases=[]
    for j in range(count):
        with mp.workdps(90):
            B=mp.mpf(10)**R.randint(0,bmax); t=mp.mpf(10)**R.randint(-spread,spread); d=mp.mpf(10)**R.randint(-spread,spread)
            if j%5==0:d=1/t
            elif j%5==1:d=B/t
            cases.append(tuple(mp.nstr(x,85) for x in (B,d,t,mp.mpf(10)**R.randint(-spread,spread),mp.mpf(10)**R.randint(-spread,spread))))
    err=mp.mpf(0); prec=mp.mpf(0)
    for c in cases:
        a=evaluate(c,40); b=evaluate(c,60)
        with mp.workdps(80):
            err=max(err,a[2],b[2]); prec=max(prec,*[abs(x-y)/max(1,abs(y)) for x,y in zip(a[:2],b[:2])])
    assert prec<mp.mpf('1e-35')
    return {'cases':count,'precision_runs':2*count,'max_normalized_algebra_error':mp.nstr(err,12),'max_normalized_40_vs_60_error':mp.nstr(prec,12),'degree_theta_lambda_volume_exponent_range':[-spread,spread],'max_B_exponent':bmax,'transition_cases':sum(j%5<2 for j in range(count))}

def asymptotic(ns,bmax):
    count=0; mxs=mp.mpf(0); mxh=mp.mpf(0)
    for dp in [40,60]:
      with mp.workdps(dp):
       for n in ns:
        logn=mp.log(n+2); theta=1/logn; H=mp.exp(logn**2)
        for B in [mp.mpf(1),mp.mpf(10)**bmax]:
         for degree in [mp.mpf('1e-12'),1,1/theta,H/2,H]:
          if degree>H:continue
          m=max(1,theta*degree); s=degree/m*I(B*m,1); h=mp.mpf(16)/3*degree/m*I(B,m)
          lp=max(0,mp.log(theta*H)); sb=(2+mp.log(B)+lp)/theta; hb=mp.mpf(16)/3*B/theta*(2+lp)
          assert s<=sb*(1+mp.mpf('1e-35')) and h<=hb*(1+mp.mpf('1e-35'))
          mxs=max(mxs,s/sb); mxh=max(mxh,h/hb); count+=1
    return {'precision_runs':count,'n_values':ns,'max_soft_bound_ratio':mp.nstr(mxs,12),'max_hard_bound_ratio':mp.nstr(mxh,12),'max_bound_violation':'0'}

def minkowski(ns):
    count=0;maxratio=mp.mpf(0)
    for dp in [40,60]:
      with mp.workdps(dp):
       for n in ns:
        for a_over_b in [mp.mpf('1e-6'),mp.mpf('0.1'),mp.mpf(1)]:
          # r=a/(16sqrt(n)), u=4r/b, with a/b<=1.
          u=a_over_b/(4*mp.sqrt(n)); term=mp.mpf(1); psi=term
          for k in range(1,n+1):
            term*=mp.mpf(n-k+1)*u/(k*k);psi+=term
          upper=mp.exp(2*mp.sqrt(n*u)); assert psi<=upper*(1+mp.mpf('1e-35'))
          maxratio=max(maxratio,psi/upper);count+=1
    return {'precision_runs':count,'n_values':ns,'a_over_b_values':['1e-6','0.1','1'],'max_Psi_to_exponential_ratio':mp.nstr(maxratio,12),'max_bound_violation':'0'}

def adaptive(count,spread,bmax,ns):
    cases=[]
    for k in range(count):
      with mp.workdps(90):
        B=mp.mpf(10)**R.randint(0,bmax);d0=mp.mpf(10)**R.randint(-spread,spread)
        n=ns[k%len(ns)];J=[mp.mpf(1),mp.log(n+2)**3,mp.mpf(10)**R.randint(1,spread+3)][k%3]
        degree=d0 if k%4==0 else d0*mp.mpf(10)**(-R.randint(0,spread+3))
        cases.append(tuple(mp.nstr(v,85) for v in [B,d0,degree,J]))
    maxs=mp.mpf(0);maxh=mp.mpf(0);maxprec=mp.mpf(0);above=0
    for c in cases:
      vals=[]
      for dp in [40,60]:
       with mp.workdps(dp):
        B,d0,d,J=map(mp.mpf,c);assert 0<d<=d0 and J>=1
        er=2+mp.log(B)+max(0,mp.log(d0));en=2+max(0,mp.log(d0));tr=er/J;tn=en/J
        mr=max(1,tr*d);mn=max(1,tn*d)
        soft=d/mr*I(B*mr,1);hard=mp.mpf(16)/3*d/mn*I(B,mn)
        sr=soft/(mp.mpf('1.5')*J);hr=hard/(8*B*J)
        assert sr<=1+mp.mpf('1e-35') and hr<=1+mp.mpf('1e-35')
        maxs=max(maxs,sr);maxh=max(maxh,hr);vals.append((+soft,+hard))
        if dp==60 and (tr>1 or tn>1):above+=1
      with mp.workdps(80):
        maxprec=max(maxprec,*[abs(x-y)/max(1,abs(y)) for x,y in zip(*vals)])
    assert maxprec<mp.mpf('1e-35')
    return {'cases':count,'precision_runs':2*count,'cases_with_threshold_above_one':above,'J_choices':['1','log(n+2)^3','10^k, 1<=k<=spread+3'],'max_soft_to_1point5J_ratio':mp.nstr(maxs,12),'max_hard_including_16over3_to_8BJ_ratio':mp.nstr(maxh,12),'max_normalized_40_vs_60_error':mp.nstr(maxprec,12),'max_bound_violation':'0'}

def partitions(xs,rw,nw):
    X=list(map(Q,xs)); n=len(X); r=Q(1,4); b=Q(3,2);u=4*r/b
    V=b*b*(1+2*u+u*u/2)
    rho=[Q(50*w) for w in rw];nu=[Q(50*w) for w in nw];Wnu=sum(nu)
    hit=[[abs(X[i]-X[k])<=2*r for k in range(n)] for i in range(n)]
    pairs=[(i,j) for i in range(n) for j in range(n) if abs(X[i]-X[j])<=r]
    types={'all_heavy':0,'mixed':0,'none_heavy':0};checks=0;maxA=Q(0);maxledger=Q(0)
    lambdas=[Q(1,10000),Q(1),Q(5),Q(10),Q(20),Q(1000000)]
    for lam in lambdas:
      mu=[rho[k]/(4*lam)+nu[k]/(Q(3,4)*lam) for k in range(n)];W=sum(mu)
      probability=Q(0);weightedledger=Q(0);weightedvolume=Q(0);A={pair:Q(0) for pair in pairs}
      for order in permutations(range(n)):
        p=Q(1);left=W
        for k in order:p*=mu[k]/left;left-=mu[k]
        probability+=p
        labels=[next(k for k in order if hit[i][k]) for i in range(n)]
        cells=[[i for i in range(n) if labels[i]==k] for k in range(n)]
        assert sum(sum(rho[i] for i in c) for c in cells)==sum(rho)
        assert sum(sum(nu[i] for i in c) for c in cells)==Wnu
        masses=[sum((nu[i] for i in c),Q(0)) for c in cells]
        active=[k for k,c in enumerate(cells) if c]
        heavy=[masses[k]>=4*lam*V for k in range(n)]
        flags=[heavy[k] for k in active]
        types['all_heavy' if all(flags) else 'none_heavy' if not any(flags) else 'mixed']+=1
        ledger=sum(masses[k] for k in active if heavy[k]);volume=sum((4*lam*V for k in active if heavy[k]),Q(0))
        assert volume<=ledger<=Wnu
        weightedledger+=p*ledger;weightedvolume+=p*volume
        for i,j in pairs:
          if labels[i]==labels[j] and heavy[labels[i]]:A[i,j]+=p
        checks+=1
      assert probability==1 and weightedvolume<=weightedledger<=Wnu
      assert all(0<=a<=1 for a in A.values())
      maxA=max(maxA,*A.values());maxledger=max(maxledger,weightedledger/Wnu)
    return {'permutations_per_lambda':__import__('math').factorial(n),'lambda_partition_checks':checks,'lambda_values':[str(v) for v in lambdas],'near_pairs':len(pairs),'heavy_cell_configurations':types,'exact_volume':str(V),'total_probability_each_lambda':'1','max_expected_pair_A':str(maxA),'max_weighted_heavy_source_ratio':str(maxledger),'max_source_sum_error':'0','max_weighted_A_violation':'0','max_heavy_volume_payment_violation':'0'}

settings=[('simple',64,2,3,[2,3,10],['0','1/8'],[1,1],[1,1]),('nonuniform_stress',256,10,15,[2,10,100,1000],['0','1/8','3/8','5/8'],[1,2,1,3],[2,1,3,1]),('expanded',1024,40,100,[2,100,1000,10000],['0','1/8','3/8','3','25/8','27/8'],[1,2,1,3,1,1],[2,1,3,1,2,1])]
stages=[]
for name,count,spread,bmax,ns,xs,rw,nw in settings:
    stages.append({'name':name,'scalar':scalar(count,spread,bmax),'logarithmic_degree_bound':asymptotic(ns,bmax),'minkowski':minkowski(ns),'partition':partitions(xs,rw,nw),'adaptive':adaptive(count,spread,bmax,ns)})
assert stages[-1]['partition']['heavy_cell_configurations']['mixed']>0
result={'status':'PASS','seed':28720261017,'scope':'Finite rational partition/source-ledger algebra and ordinary mpmath scalar diagnostics, not intervals or a FULL continuous L1 history. Partition r,b are independent rational geometry parameters, not the original radius. A(y,z) is the probability-weighted same-cell heavy indicator; heavy uses nu(C)>=4lambda V and anchor mu=rho/(4lambda)+nu/q_minus.','stages':stages}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True,indent=2))
