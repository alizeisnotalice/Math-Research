# R287 independent audit: one-sided actual capture with degree cost

## 1. Independent statement screen before author proof

**Preauthor screen: PASS for both proposed raw one-sided bounds.** This section was derived and sent to the parent before reading any R287 author proof. Only this audit file is owned/written; no repository, Git, PDF, or author file is changed.

Fix a physical clock xi, write A0=a_xi^n, q_-=3lambda/4, and keep the original receiver/selector qualifications, original full-soft cap, original hard cap, original near condition, and full posterior. For original near degrees M(z)=rho(B_1(z,r)), N(y)=nu(B_1(y,r)), put

    d_rho=M/(q_- A0),   d_nu=N/(4lambda A0).

The actual soft point p_y has height <=A0^-1 and direct weak constant <=B; the actual hard point h_z has height <=A0^-1 and weak constant <=1. Hence p_y/q has natural height <=(q_-A0)^-1 and weak constant <=B/q_-. These facts concern the actual selector-dependent point functions on the qualified receiver set; no actual cap is assigned to a maximal envelope.

### Soft capture alone

For theta>0 and m_rho=max(1,theta d_rho), gate both point functions by c_rho>=theta. The actual full-soft cap gives the additional height p_y/q<=1/(theta M). Thus the gated heights are

    u=1/(q_- A0 m_rho),   v=1/A0.

For functions of heights u,v and weak constants A,C, the capped product is I(vA,uC), where I(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))]. With A=B/q_-, C=1 this is

    1/(q_- A0 m_rho) I(Bm_rho,1)
      =1/(q_- A0 m_rho)[2+log B+log m_rho],

since B,m_rho>=1. It depends on z through M only. Integrating the original near rho mass gives M(z), hence exactly

    T_soft(theta)<=integral nu(dz)
      d_rho/max(1,theta d_rho)
      [2+log B+log max(1,theta d_rho)].

No hard capture assumption was used. Any further original positive pair gates may be retained on the left and dropped in this majorant.

### Hard capture alone

Put m_nu=max(1,theta d_nu), and gate both functions by c_nu>=theta. The actual hard cap gives h_z<=4lambda/(theta N); combined with its natural height, this gives

    u=1/(q_- A0),   v=1/(A0 m_nu).

The same weak constants give edge price

    1/(q_- A0 m_nu) I(B,m_nu).

Integrating original near nu mass gives N(y), hence exactly

    T_hard(theta)<=(16/3) integral rho(dy)
      d_nu/max(1,theta d_nu) I(B,max(1,theta d_nu)).

No soft capture assumption was used. The factor 16/3 belongs outside this rho-integral; the soft-direction formula has no such factor. Both orientations therefore agree with the proposed statements.

### Marginals, zeros, and finite-degree scope

These calculations use the exact original incidence identities integral_near rho(dy)=M(z) and integral_near nu(dz)=N(y), equivalently the normalized reciprocal-degree marginals on positive degrees. Near edges with M=0 or N=0 have zero original product measure by Tonelli. On p_yh_z=0 the original traffic is zero. Ratio conventions there are harmless; no singular pair charge is integrated. The bounds use finite source masses and arbitrary nonnegative L1 densities without any source comparison.

Let ell=log(n+2), theta=1/ell, and E=exp(ell^2). On the gate d_rho<=E, m_rho<=E and d_rho/m_rho<=ell, so

    T_soft,moderate<=ell[2+log B+ell^2] W_nu.

For m>=1 and B>=1, I(B,m)<=B[2+log m]: if m<=B, I(B,m)<=2B; if m>=B, the formula is B[2+log(m/B)]. Consequently on d_nu<=E,

    T_hard,moderate<=(16/3)ell B[2+ell^2] W_rho.

These are uniform source prices at each physical clock, and become root-polylog after the one original 2Lambda B_D clock price if B is polynomial in log(n+2). The hard direction retains a polynomial B factor; the soft direction retains only log B. No source-log/entropy moment for unrestricted degrees is established.

Starting from the R286 exact residual prevents recharge. At the same theta, the two new disjoint candidate paid pieces are (i) c_rho>=theta,c_nu<theta,d_rho<=E and (ii) c_rho<theta,c_nu>=theta,d_nu<=E. The exact remaining pieces are both captures below theta, sole soft capture with d_rho>E, and sole hard capture with d_nu>E, all multiplying the SAME prior current original integrand and masks. No coverage fraction follows.

The author proof and clock integration remain to be read; no unprovided adaptive-threshold statement is accepted by this screen.

## 2. Independent geometry screen, before reading its author proof

The parent subsequently supplied the fixed first-anchor partition and proposed heavy-cell fractional gate. The following check was completed and sent to the parent before opening the geometry author file.

For each fixed admissible disjoint radius-2r partition, retain the original upper scale R<=b as well as the actual caps. For cluster k, F_k/q<=1 and H_k<=4lambda. Its hard response vanishes outside Q_b+B_1(A_k,2r), of volume V=b^n Psi_n(4r/b). Thus

    integral_E (F_k/q)H_k<=4lambda V.

A heavy cell with m_(nu,k)>=4lambda V therefore costs at most m_(nu,k). Summing the exact disjoint hard masses costs at most W_nu. For each realization the common-cell heavy-pair indicator sum is between zero and one. Its expectation A_high is therefore in [0,1], is independent of receiver/clock/auxiliary slots, and supplies an actual fractional original-integrand allocation. Nonnegative Tonelli gives raw price W_nu for that allocation, without any reciprocal coincidence-probability factor. The exact complement is 1-A_high. The one original score-clock price is 2Lambda B_D W_nu. No coverage fraction follows; A_high can be zero.

## 3. Author reading, version bindings, and main verdict

The one-sided author and geometry author were then read in full. The geometry file's final added diagnostics were read on its later version. Checked bindings at this stage:

- `/tmp/r287_degree_log.md`: `04b7a76e83a9a7c57b0c3fa91fd139f64b7993654812ed58b0c7a882a2a39e6f`.
- `/tmp/r287_geometry.md`: `3334d2261a0fe08002e79148b1c9cab30862b09fb5fecdb8e7c834df810ba565`.

**Main mathematical verdict: PASS for the exact one-sided prices, their moderate-degree payments, the adaptive soft-capture payment, the fractional heavy-packet root payment, and the auxiliary receiver-shell estimate.** Two small wording imprecisions in the frozen degree file are recorded in Section 8; neither invalidates the main inequalities.

The author one-sided formulas agree exactly with Section 1. All point heights are direct bounds on actual selected point kernels. The source cap supplies only the additional actual capture height; neither the soft maximal envelope nor any latent component is given FIRST. The other capture is not used. Endpoint-dependent thresholds are valid because the relevant threshold is fixed for the edge receiver integration. Further positive current masks may be retained on the left, including fractional 1-A_high, and dropped only in the majorant.

The general logarithmic majorants in author (4) are valid for all d>=0, theta>0 and B>=1, including theta>1. In the hard direction the B factor remains; no substitution of log B for B is justified. The source-weighted logarithms at a dominate their a_xi counterparts. They are finite for each fixed source pair because M<=W_rho, N<=W_nu and denominators are fixed positive numbers, but this gives no dimension-uniform or outer-ledger root budget. The author explicitly does not infer such a budget.

The n=1 local L1 example is consistent: the two short intervals are within near radius of each other, only the I interval is inside every selected receiver cube, the original response caps hold, both original dense thresholds hold, c_rho=1, and c_nu=epsilon/(1+epsilon). Thus positive new one-sided traffic really can occur outside the previously paid two-capture gate. It is correctly described as a local configuration rather than a full original history.

## 4. Explicit adaptive threshold audit

For J>=1 let d_0=M/(q_-a^n), ell_rho=2+log B+log_+d_0, and theta_rho=ell_rho/J. This is a positive measurable threshold fixed before receiver and clock. Soft capture may exceed one, so theta_rho>1 is allowed. Since d_rho(xi)<=d_0,

    2+log B+log_+(theta_rho d_rho)
      <=ell_rho+log_+theta_rho
      <=ell_rho+log ell_rho
      <=(3/2)ell_rho.

The last inequality is valid for every ell_rho>=2; J>=1 gives log_+theta_rho<=log ell_rho. Dividing the valid soft majorant by theta_rho therefore proves raw price (3/2)J W_nu and full original price 3Lambda B_D J W_nu. No source entropy assumption, degree cutoff, or inverse recovery multiplier is hidden here. The exact adaptive gate alone is paid, and its complement is not claimed small. This explicit adaptive result was audited only after the author's derivation was available.

## 5. Geometry author and full-maximal-cap subtraction

The fractional gate is measurable: the first-hit cells are jointly Borel; their masses are measurable integrals; the countable common-cell heavy indicator sum is at most one; and its expectation is measurable. The fixed random partition covers both original sources almost surely because both are absolutely continuous with respect to the finite anchor measure. Zero total anchor mass gives zero traffic; zero hard-mass cells cannot pass the strictly positive heavy threshold. The same realization and exact disjoint source identities apply at every receiver and clock.

The exact outer volume is

    |Q_b+B_1(0,R0)|
      =sum_{k=0}^n binom(n,k)b^(n-k)(2R0)^k/k!
      =b^n Psi_n(2R0/b).

The coordinate/simplex decomposition in the author proof counts the receiver region once. The heavy root payment uses R0=2r and its threshold 4lambda b^n Psi_n(4r/b). There is no K, kappa, or B factor in this main payment, because only its fractional common-heavy-cell traffic is allocated; all original near pairs are not recovered from the partition.

The auxiliary full-maximal-cap subtraction is also correct. If m_nu>4lambda h^n for an allowed h in [a,b], every receiver in the open cube of side (h-2R0)_+ has the whole hard source inside Q_h and violates the original maximal cap. Letting h increase to t_nu=min(b,(m_nu/(4lambda))^(1/n)) removes volume (t_nu-2R0)_+^n. The strict condition m_nu>4lambda a^n handles the lower endpoint correctly. At m_nu=4lambda b^n with b>a, approach b from below; when b=a and the strict mass condition holds, use h=b directly. The excluded cube lies in the outer region and has a null boundary. Hence the stated 4lambda C_nu bound and its minimum with the existing kappa packet price are valid.

The inequality Psi_n(u)<=exp(2sqrt(nu)) follows from binom(n,k)<=n^k/k! and the even exponential coefficients. For R0=2r it gives exp(n^(1/4)sqrt(a/b)), exactly as stated. This can make the heavy threshold large. Neither the shell estimate nor its generic minimum is booked as a root payment for all packet masses. The original K factor remains necessary only when an independent same-cluster recovery claim is actually used; it is absent from the fractional A_high gate.

## 6. Original gates, clock, source ledger, and exact combined remainder

All new capture gates are evaluated on original physical rows with actual s,L,R. Degrees may depend on physical xi but not auxiliary slots; the adaptive threshold uses only a and source degrees. A_high and its heavy threshold are fixed before receiver and clock. The original full posterior and explicit upper-slot R2<=D and ns<=D qualifications remain until the original score bound is applied BEFORE xi=c_jt/b substitution. The actual lower-scale receiver gate and unique j remain until their respective uses. The one outside 2Lambda and existing B_D occur once. Source-pair-dependent parameters remain in the original outer weighted sum until a common bound is proved. No signed credit, source comparison, new source ledger, or new grid factor appears.

For the proposed sequential integration, start with the exact R286 current remainder. First pay its A_high fractional part, retaining (1-A_high) on the complement. On that complement pay the moderate-degree sole-soft-capture branch, then the disjoint moderate-degree sole-hard-capture branch. Each bound is valid with all prior positive masks retained, so there is no recharge of R286's both-capture payment or of R287's earlier fractional payment.

With ell=log(n+2), theta=1/ell and H=exp(ell^2), the exact remaining root-level integrand is

    (1-A_high) I_dense * [
       1{c_rho<theta,c_nu<theta}
       +1{c_rho>=theta,c_nu<theta,d_rho>H}
       +1{c_rho<theta,c_nu>=theta,d_nu>H} ].

Here I_dense is the SAME current original jointly dense positive integrand with every original source/history cut, near condition, actual selector, unique j, full posterior, score qualification, and clock retained. Its both-capture portion was already paid by R286 and is not included again. If the explicit adaptive gate is additionally allocated, it must likewise be applied only to the remaining current integrand, and its exact complement retained; no automatic adaptive coverage is inferred by this receipt.

The R287 geometry price 2Lambda B_D W_nu and the two moderate-degree prices from Section 1 are root-polylog when D=O(log(n+2)) and B is polynomial in log(n+2). The displayed remaining three branches may still carry all remaining traffic. No global logarithmic-degree estimate, universal heavy-cell coverage, or full root theorem has been proved.

## 7. Actually run bounded local mathematical checks

A fresh local Python calculation used generalized product heights for B in {1,2,100,1e8}, d in {1e-5,.1,1,1e5}, theta in {.01,.3,1,4}, and A0 in {1e-4,1,16,1e4}. It checked both exact one-sided scalar formulas, the hard majorant, and adaptive prices for J in {1,10,1e4}. Fraction arithmetic separately checked the volume formula for n=1,2. Actual output:

    PASS one-sided height equalities=512 hard-majorant checks=256 adaptive checks=768 exact low-dimensional volume checks=2
    Finite algebra/ordinary floating diagnostics only; no coverage, global source-entropy, or interval certificate.

These are finite algebra checks, not a continuous original-history construction, interval proof, or numerical evidence of a global capture fraction. The analytic arguments supply the universal statements. No upstream proof was re-audited.

## 8. Two minor author wording corrections requested

1. In degree-file Section 1, the asserted exact expression for the hard price when m>=B additionally requires theta d>=1. At the degenerate allowed case B=m=1 and theta d<1, the expression with log(theta d/B) is not equal to the actual price. That case is covered by the stated lower branch, and the main majorant remains true. The corresponding Section 2 phrase that the majorant is equality whenever m>=B needs the same qualification.
2. In Section 4, a moderate logarithmic degree and an arbitrary polylogarithmic J do not by themselves ensure theta_rho<1. The exact condition is J>ell_rho (or J>=ell_rho for <=1). A sufficiently large polylogarithmic J can be chosen on a specified moderate-degree regime. This does not affect the adaptive payment, which is valid even for theta_rho>1.

Both points were sent to the parent. They are precision corrections to subsidiary wording; the exact Phi formulas, inequalities, main paid branches, and explicit unpaid residual are valid at the hashes in Section 3.

## 9. Final author amendments and adaptive-hard audit

The final amended degree author was read in full and checked at SHA256

`/tmp/r287_degree_log.md`: `9a9dd881e3976a7bc5eb459e559a14407b34efbb9d409f45064a4106b8ed6da3`.

This supersedes its older binding in Section 3. Both requested wording corrections in Section 8 are present: the hard exact-expression/equality regime now requires theta d>=1, and threshold<1 is stated precisely as J>ell_rho. They are resolved.

The amended author explicitly derives an additional adaptive-hard branch. Its statement was independently screened and sent to the parent before reading the added proof. Put

    d_nu,0=N/(4lambda a^n),
    ell_nu=2+log_+d_nu,0,  beta=ell_nu/J,  J>=1.

Since d_nu(xi)<=d_nu,0 and B>=1,

    2+log_+(beta d_nu/B)
      <=ell_nu+log_+beta
      <=ell_nu+log ell_nu
      <=(3/2)ell_nu.

The established hard majorant is therefore at most (3/2)BJ. Its required outside raw factor 16/3 gives exactly 8BJ W_rho. Restoring the one score-clock multiplier gives 16Lambda B_D BJ W_rho. This retains the polynomial B factor; it does not replace it by log B. If beta>1 the actual hard capture gate is empty, and the bound remains valid. Finite source degrees give finite measurable positive thresholds without any uniform degree bound or entropy assumption.

A fresh additional local run checked this new result at 120 scalar combinations, including d=0 and thresholds above one. Fraction arithmetic also checked all 16 combinations of a fractional allocation A in {0,1/4,2/3,1} and two binary adaptive gates. Actual output:

    PASS adaptive-hard scalar prices=120 exact fractional sequential-ledger identities=16
    Bounded algebra diagnostics only; no traffic-coverage or global entropy conclusion.

## 10. Final integrated checkpoint and exact final residual

**Final integration verdict: PASS, with no outstanding correction requested.** The complete final checkpoint was read and hash-checked:

`/Users/zhengzhihao/Desktop/T/output/centered_cube_round287_20261017_final_checkpoint/proof.tex.txt`: `3c62cedec17ab38984df03d0f4190786db14edb59a6b3a19d8cfb0eff5396f33`.

It matches the final degree author hash in Section 9 and geometry author hash `3334d2261a0fe08002e79148b1c9cab30862b09fb5fecdb8e7c834df810ba565` from Section 3. No upstream re-audit is claimed. This final integration replaces the optional fixed-H ledger of Section 6 with the stronger, explicitly derived adaptive ledger; no fixed-H cutoff is required in the final proof.

Let I_0 be exactly the R286 unspent original positive integrand, including its dense and earlier low-capture qualifications and all original masks. The final checkpoint uses A=A_high, alpha=ell_rho/J and beta=ell_nu/J. The exact four responsibility weights are

    A,
    (1-A)1{c_rho>=alpha},
    (1-A)1{c_rho<alpha}1{c_nu>=beta},
    (1-A)1{c_rho<alpha}1{c_nu<beta}.

They are nonnegative and sum pointwise to one. Consequently the first three pieces do not recharge one another or any previously paid R286 piece. Their correct raw source price is

    (1+(3/2)J) W_nu + 8BJ W_rho.

The final checkpoint retains actual a<=L,R<=b<=2a, the physical L,R>=a_xi and ns<=D qualifications, actual full response caps, full original posterior, and explicit upper-slot R2<=D. Its score bound is applied BEFORE clock substitution. All new allocation weights are auxiliary-slot independent; A is also receiver/clock independent, while alpha,beta are source-endpoint thresholds fixed at the minimal physical scale. The unique actual j is retained until its multiplicity is bounded by one. Thus the original price is exactly

    2Lambda B_D[(1+(3/2)J)W_nu+8BJ W_rho],

with B_D<=4sqrt(nD) and no extra grid, K, kappa, Lambda, or scale factor. The integrated volume bound has the correct argument 4r/b and exponent exp(n^(1/4)sqrt(a/b)). Its possibly large heavy threshold is explicit; it is not treated as giving universal coverage. The polynomial B cost is retained on the hard source-price orientation. The source sums use the original terminal ledger, with outer-data-dependent parameters kept inside their original averages.

For J=log^3(n+2), J>=1 for every n>=1, so both adaptive derivations apply. The stated established bounds D=O(log(n+2)) and B=O(log^4(n+2)) give a root-polylog budget for these specified new pieces. No global bound on source logarithms is invoked.

The exact final unpaid expression, superseding the fixed-H alternative in Section 6, is

    I_0 (1-A_high)
      1{c_rho<ell_rho(z)/J}
      1{c_nu<ell_nu(y)/J}.

Every original source, history cut, near condition, actual selector, physical clock, unique j, full posterior, and upper-slot qualification inside I_0 is retained. This expression may carry all remaining traffic. The final proof correctly claims neither positive coverage nor a general root upper bound. The exact remaining task is to pay this original residual or derive a further legitimate source-conserving transfer with its complete source cost.

**Final receipt: PASS at the final author/checkpoint hashes above. Only this owned temporary audit file was written; no author/checkpoint, repository, Git, or PDF state was changed.**

## 11. Final notation-only proof freeze and README consistency

**PASS.** The final proof now uses vartheta_rho and vartheta_nu for adaptive capture thresholds, avoiding collision with the original source measures alpha,beta. Its new SHA256 is

`/Users/zhengzhihao/Desktop/T/output/centered_cube_round287_20261017_final_checkpoint/proof.tex.txt`: `75ca9693eb2f5a274111b74815e82479430e0f5fbca20b5ea9e3e7b35c8649fa`.

A local inverse-renaming check replaced only the five occurrences of `\vartheta_\rho` by `\alpha` and the four occurrences of `\vartheta_\nu` by `\beta`, in memory without writing the proof. The resulting text recovered the previously audited proof SHA256 `3c62cedec17ab38984df03d0f4190786db14edb59a6b3a19d8cfb0eff5396f33` exactly. This verifies that the only proof changes are the requested threshold renamings. The original source inequality rho<=beta<=alpha<=f dx was separately checked to remain intact. No new mathematical tests were needed or run for this notation change.

The checkpoint README was also read for mathematical assertions, combined price, and exact residual, at SHA256

`/Users/zhengzhihao/Desktop/T/output/centered_cube_round287_20261017_final_checkpoint/README.md`: `26b29bde6129f45551e7e677bd82a91a34181d7e20ffab87a0e7116cb4ff0aa8`.

Its explicitly defined threshold names alpha,beta correspond to the newly renamed proof thresholds. The README correctly states the heavy fractional raw price W_nu, soft adaptive price (3/2)J W_nu, hard adaptive price 8BJ W_rho, combined original price 2Lambda B_D[(1+(3/2)J)W_nu+8BJ W_rho], and exact residual I_0(1-A) times both adaptive-capture failures. Its auxiliary shell formula and strict lower-mass condition agree with the audited geometry author. It correctly retains B on the hard direction, gives no uniform source-entropy or coverage inference, and leaves general closure open. Its numerical section clearly limits the samples to algebra/partition diagnostics rather than continuous L1/FULL histories or interval certificates. This README check did not re-run or independently audit the parent's reported larger numerical experiment; the analytic conclusion and prior audit scope are unchanged.

**Frozen final integration receipt: PASS at the new proof and README hashes above. The exact unpaid original residual and all original masks remain as stated in Section 10, with only threshold notation changed. Only this owned audit file was appended; it is now frozen pending any explicit further review request.**
