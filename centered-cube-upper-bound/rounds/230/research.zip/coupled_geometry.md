# R230：实际 far clock、尺度节点与双后验的联合结算

**主结论。** 在R229已审的实际连续L/R/s覆盖中保留原far门，先完成每个节点的receiver积分，再用**同一真实后验的iid score正差界**，最后联合求尺度–时长和。这给不含静态后验包络的新估计：

\[
 \boxed{P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(18e^4N_n)e^{-U}
 \mathbb E\sum_{V,j}\frac{c_j^{2n}a^{-n}}q
 \|\beta\|\,\|\nu\|.}
 \tag{CG0}
\]

这里U≥0是固定原far偏移，`N_n≤8+4sqrt n log(n−1)`；q、a、β、ν均取各原行的真实值，允许其余标签依赖，不能无价移出所标求和。所有实际L/R/s、原三测试腿及原同一history均覆盖。右侧已经**不含两份后验包络质量**，但来源密度比 `||ν||/(qa^n)` 及跨原叶子/比例带的来源总价仍未支付，故不宣布一般root弱型闭合。

精确共同窗口/capture接口在CG9保留；CG0是其明确正放松。R227 pair-envelope提供的保窗口补充在CG12，仍有自己的来源费用，不能和CG0重复领取。

## CG1 输入、原量与节点clock

只调用冻结R229 `adaptive_geometry.md` AG1–14、R224 QG及R227 arbitrary-normalizer pair工具。n≥2（原应用n≥512），γ=1+1/n，c=c_j=γ^{-j}，0<a≤b≤2a。共同原分母为q>0。实际L(x),R(x)∈[a,b]、s(x)∈[0,1]任意可测，保原band

\[
 c/\gamma\le\min(L,R)/\sqrt{LR}\le c,
 \qquad g=\sqrt{LR}.
 \tag{CG1}
\]

原三腿是 `(A_1,σ_1)=(L,s)`、`(A_2,σ_2)=(min(b,γL),s)`、`(A_3,σ_3)=(b,1)`。为避免冲突，far偏移用U，pair第二来源仍用u。本次所估原正行满足

\[
 t\ge a/c,\qquad t\le g e^{-U/n},\qquad U\ge0\ \hbox{固定}.
\]

R229的向上节点从M0=a/c²开始按γ倍增，末点精确截b，记集合mathcal M_j；M0>b则原band为空。实际M=max(L,R)对应M*满足M≤M*≤γM。两朝向节点为 `(L*,R*)=(M*,c²M*)` 或 `(c²M*,M*)`，故g*=cM*≥g，节点全部在[a,b]。原三腿采用同样节点公式。其点态覆盖损失≤e⁴，再用**一份**公共soft菜单 `4 sum_(r in S_n)`；本稿不重复其证明。

关键是原far门在每个节点上仍推出

\[
 t\le cM^*e^{-U/n},\quad
 I_M(U)=[a/c,cM e^{-U/n}],\quad
 \ell_M(U)=\left(\log(M/M_0)-U/n\right)_+.
 \tag{CG2}
\]

节点右端≤左端时没有dt/t交通。端点没有dt/t质量，原严格far门可上放成闭区间。不能先把这些区间统一放到最长窗再求和。

## CG2 两个联合尺度–时长和

对任意U≥0及上述末点截b网格，

\[
 \boxed{\sum_{M\in\mathcal M_j}M^{-n}n\ell_M(U)
 \le3e^{-U}M_0^{-n}=3e^{-U}c^{2n}a^{-n},}
 \tag{CG3}
\]
\[
 \boxed{\sum_{M\in\mathcal M_j}M^{-n}\sqrt{2n\ell_M(U)}
 \le(3+\sqrt2)e^{-U}M_0^{-n}
 <5e^{-U}c^{2n}a^{-n}.}
 \tag{CG4}
\]

CG3用于主结论；CG4只用于保capture窗口的pair补充。

**证明。** 空网格直接成立；M0=b时唯一节点的ell为0。否则令 `x=n log(M/M0)`、`h=n log γ`。正规节点x=kh，k≥0；至多另有一个非正规末点 `x_cap=n log(b/M0)`，若已是正规节点不重复。Bernoulli给γ^n≥2，且log(1+1/n)≤1/n，因此

\[
 \log2\le h\le1,\qquad q_0=e^{-h}\le1/2.
\]

保留x≥U的节点并写s=x−U≥0。CG3的归一项准确为 `e^U M0^n M^{-n}n ell_M=e^{-s}s`。正规尾的s=s0+kh，s0≥0，故

\[
 \sum_{k\ge0}e^{-(s_0+kh)}(s_0+kh)
 =e^{-s_0}\left[\frac{s_0}{1-q_0}+
 \frac{h q_0}{(1-q_0)^2}\right]
 \le2e^{-s_0}(s_0+1)\le2.
\]

第一处上界分别用 `1/(1−q0)≤2`、`h≤1`及 `q0/(1−q0)²≤2`。若x=U，原项为零，包含它仍合法。唯一非正规末点另用 `s e^{-s}≤1` 支付≤1，得到CG3。没有把最后截断点的间距视为h。

CG4的归一项为 `e^{-s}sqrt(2s)`。因为 `2s e^{-s}≤2/e<1`，它≤e^{-s/2}。正规尾和≤`1/(1−e^{-h/2})≤2+sqrt2`，唯一额外截断点≤1，得到CG4。正规尾向无穷延拓只增加正项。

原上端b还给准确空支

\[
 U\ge n\log(bc_j^2/a)\quad\Longrightarrow\quad
 \ell_M(U)=0\ \hbox{对所有节点，原far交通为零}.
 \tag{CG5}
\]

可以只保CG5允许的j，但不据此免费合并不同j的来源预算。

## CG3 Receiver先积分后，原双后验可以归一

固定(j,y,t)时，原ν、Z_{j,t}(y)、w_t、e_t和k_t都不依receiver x及hard来源z。原后验为

\[
 \Pi_{j,t}(y,dv)=1_{Z_{j,t}(y)}(v)w_t(y,v)\nu(dv)/e_t(y).
\]

在原过程有效且e_t>0处，它是同一个概率分布；过程无效/e_t=0处将共同域表达中的后验取零，成为质量≤1的子概率，而不是发明新过程。下面两份Π必须是这个同一后验，不能改用不同carrier或不同条件化权。

**iid score引理。** 对任意质量m≤1的正测度π及可测k∈[0,n]，

\[
 \iint(k(v)-k(u))_+\,\pi(dv)\pi(du)
 =\int_0^n p(r)(m-p(r))\,dr
 \le nm^2/4\le n/4,
 \quad p(r)=\pi\{k>r\}.
 \tag{CG6}
\]

证明是 `(a−b)_+=∫_0^n 1_{b≤r<a}dr` 后Tonelli；原子的端点不影响dr积分。此处k_t正是n个坐标threshold score之和，故取值[0,n]。这不使用归一化函数的导数、删除负信用或FIRST。

### 每节点的准确共同窗口

沿用R229

\[
 \bar w_d(y,v)=\prod_l\min\{1,bC(|y_l-v_l|/b)/d\},\quad
 E_d(y,v)=\exp\{-\tfrac\kappa2\sum_l(1-\min(1,bC(|y_l-v_l|/b)/d))\},
 \quad\kappa=25/2^{68}.
\]

固定节点、朝向ε、腿i、soft节点r，定义真实共同窗口积分

\[
 J_{i,\varepsilon,M,r}(y,z,v)=
 \int 1_{x\notin Q_{d_{\varepsilon,M}}(v)}
 \frac{h_{R^*}(x-z)
 \sqrt{P_{r,L^*}(x-y)P_{\sigma_i^*,A_i^*}(x-v)}}
 {\sqrt{\bar w_{c^2M}(y,v)}}\,dx.
 \tag{CG7}
\]

前两腿σ_i*=r；J腿σ_3*=1、A_3*=b。无排除时指示恒为1，不解释成排除单点。原R≤L朝向可取 `d=max(a,R*/γ³)`；仅在原H0≥a支，R>L朝向也可取d=a；H0<a时不给该朝向完整Qa排除。原capture/history保在实际χ中再作明确正上放，不在节点重算资格。

CG7等于同一hard窗口的一维积分乘积差除以 `(R*)^n sqrt(bar w_(c²M))`。其QG上界为

\[
 0\le J_{i,\varepsilon,M,r}
 \le M^{-n}E_{c^2M}(y,v)\Phi_{i,\varepsilon,M,r}(y,z,v)
 \le M^{-n},\qquad 0\le\Phi\le1.
 \tag{CG8}
\]

Phi准确为 `1−prod_l(I_l^exc/I_l)`；有零I_l时J=0，无排除时Phi=1。全部参数已经经过R229合法点态有限和，所以CG8不是把固定QG直接用于θ(x)。

## CG4 无后验包络的原量回代

令F_i(x)为R229原实际半密度腿核，χ包含原a_ω、ρ、high、good/bad、history及当前未付支，并在实际far窗外为零。原χ对x、t、来源的依赖不冻结。R229点态覆盖中继续保 `1_{t in I_M(U)}`，然后对x积分，得到保共同窗口的原交通上界

\[
 P_{far}(U)\le8\Lambda e^4\sqrt{K/3}\,
 \mathbb E\sum_{V,j}\frac1q
 \int\beta(dy)\nu(dz)
 \sum_{i,\varepsilon,M,r}
 \int_{I_M(U)}\frac{dt}{t}
 \iint\delta_t(y;v,u)J_{i,\varepsilon,M,r}(y,z,v)
 \Pi_{j,t}(y,dv)\Pi_{j,t}(y,du),
 \tag{CG9}
\]

其中δ_t=(k_t(y,v)−k_t(y,u))_+。外系数8Λe⁴来自原2Λ、原good比较的sqrt(K/3)及覆盖4e⁴：

\[
 p_y\le\sqrt{K/3}\sum_{i=1}^3
 \sqrt{p_yK_i(x-v)}/\sqrt{w_g(y,v)}.
\]

原terminal-good/bad等x依赖门只作非负上放，没有改变Π的carrier。正因Π不依x，CG9中的两份Π仍是同一真实过程，可以在使用CG8的统一列帽后直接用CG6，而无需静态sup。依次有

\[
 \int_{I_M(U)}\frac{dt}{t}\iint\delta_t J_{i,\varepsilon,M,r}\Pi_t\Pi_t
 \le M^{-n}\frac n4\ell_M(U).
 \tag{CG10}
\]

此处删E≤1和Phi≤1是明确放松；不在删去后再声称保其几何收益。对每个腿/朝向/soft节点，用CG3支付尺度和≤`(3/4)e^{-U}c^{2n}a^{-n}`。随后三腿×两朝向×N_n及原4e⁴给

\[
 4e^4\cdot3\cdot2\cdot N_n\cdot(3/4)=18e^4N_n.
\]

最后β(dy)与完整hardν(dz)积分为||β||||ν||，得到CG0。hard源从未限制到Z_g；原v/u的ν质量已通过原Π精确归一，不再次乘||ν||²。外q是原共同分母而非测试Q，也没有换成节点FIRST输入。

这个顺序保同一carrier和时间：**先x积分、再统一QG列帽、再同一t的Π⊗Π归一、再积分本节点clock、最后求节点和。** 原j由正节点展开后仍显式求和；若某些q/a/来源确实独立j，可另证相应数值级数约简，本稿不预先使用。

## CG5 保capture窗口的pair补充（有包络价）

CG9是尚保hard源z及capture共同窗口的精确有限节点上界。若不愿删E或Phi，可以另取共同静态包络

\[
 A_j(y,v)\ge\sup_{t\in[a/c,bc]}1_{Z_{j,t}(y)}(v)w_t(y,v)/e_t(y).
\]

也可仅覆盖本次共同far区间 `[a/c,bc exp(−U/n)]`。没有授其ν质量为1或普遍有限。R227已证任意归一化函数pair界给

\[
 \int_{I_M(U)}\delta_t
 a_{j,t}(y,v)a_{j,t}(y,u)\,dt/t
 \le\sqrt{2n\ell_M(U)}A_j(y,v)A_j(y,u).
 \tag{CG11}
\]

于是CG9也给另一条正上界

\[
 P_{far}(U)\le8\Lambda e^4\sqrt{K/3}\,
 \mathbb E\sum_{V,j}\frac1q
 \int\beta(dy)\nu(dz)\nu(dv)\nu(du)
 A_j(y,v)A_j(y,u)
 \sum_{i,\varepsilon,M,r}
 J_{i,\varepsilon,M,r}(y,z,v)\sqrt{2n\ell_M(U)}.
 \tag{CG12}
\]

保J可以继续研究原共同来源几何；删Phi并用CG4则回到有包络的粗界，系数为外 `2Λsqrt(K/3)` 乘 `120e⁴N_n e^{-U}`，且原两包络费用仍在。主结论CG0更直接地消除了这个包络障碍；CG12不是额外可叠加的信用。两者可分别作为同一正量的上界取较小值。

## CG6 新结论及最早未付来源项

R229先将所有节点clock扩到共同最长窗，显式损失为N_n sqrt n，且带两份后验包络。CG0同时消去这两项：原Π通过iid score界直接归一，n ell_M又与物理M^-n联合求和，只剩公共soft菜单N_n和真实e^-U。这覆盖全部实际L/R/s及原三腿，不是特殊soft或窄尺度族。

然而剩余原量

\[
 \mathbb E\sum_{V,j}\frac{c_j^{2n}}{qa^n}
 \|\beta_V\|\,\|\nu_V\|
\]

仍未被本稿证明可由W_β或W_β+W_ν支付。最早缺口已收缩为实际hard来源的物理尺度拥挤与跨叶子/比例带总账；**不再是任意静态后验包络质量的控制问题。** ν≤β与W对称不自动控制 `||ν||/(qa^n)`；FIRST控制实际p_y，不能直接给节点hard全来源质量帽。进一步若要用CG9的Phi改善拥挤，必须同原high/FIRST及真实来源联合估计。

本路线未使用16/3 hard帽，不可在保hard来源的CG9上重复领取。没有消费signed、suffix或删除信用。全部ρ/history只在原χ上正放松，没有给任何负项复制新权。CG0是一条新的有价全域联合估计，不是一般root弱型定理。

## CG7 本机核查与可复现短脚本

实际运行本机mpmath，60位精度，n=2、16、512，6组(n,j)，每组测试U=0、半个正规步长、接近末端、恰在空窗边界及超出边界，共30组、84个断言通过。观测最大归一线性和约1.06814853527682939，最大归一平方根和约1.35102220946152204。数值只核查节点/端点实现，不证明锐常数或一般阶；CG3–4的严格依据是解析推导。

以下为实际运行的代码。parent数值代理另有独立完整菜单，本稿不代其声明结果。

```python
import mpmath as mp
mp.mp.dps=60
out=[]; assertions=0
for n,j in ((2,0),(16,0),(16,5),(512,0),(512,88),(512,177)):
    gam=1+mp.mpf(1)/n; c=gam**(-j); M0=1/c**2
    if M0>2: continue
    nodes=[M0]
    while nodes[-1]<2: nodes.append(min(mp.mpf(2),nodes[-1]*gam))
    delta=n*mp.log(gam); endpoint=n*mp.log(2/M0)
    for U in (mp.mpf(0),delta/2,max(mp.mpf(0),endpoint-delta/3),endpoint,endpoint+1):
        gaps=[n*mp.log(M/M0)-U for M in nodes]
        root=mp.fsum(mp.exp(-s)*mp.sqrt(2*max(mp.mpf(0),s)) for s in gaps)
        linear=mp.fsum(mp.exp(-s)*max(mp.mpf(0),s) for s in gaps)
        assert root<=3+mp.sqrt(2); assertions+=1
        assert linear<=3; assertions+=1
        if U>=endpoint:
            assert root==0; assertions+=1
            assert linear==0; assertions+=1
        out.append((n,j,mp.nstr(U,12),mp.nstr(root,18),mp.nstr(linear,18)))
print('mpmath_dps=',mp.mp.dps,'assertions=',assertions,'cases=',len(out))
print('max_root=',max(mp.mpf(v[3]) for v in out))
print('max_linear=',max(mp.mpf(v[4]) for v in out))
for row in out: print(row)
```

实际Python为 `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`，PYTHONPATH为 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`。证明只需初等不等式及已审工具，不依这个数值环境。
