#!/usr/bin/env python3
"""Finite actual-node scale-clock checks plus an analytical constant-five bound."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
HERE=Path(__file__).resolve().parent

def exact_components():
 rows=[]
 for n in (2,4,8,16,64,512,4096,1000000):
  lower=F(2)+F(n-1,2*n)
  row={'n':n,'positive_binomial_first_three_terms':str(lower),'strictly_above_two':lower>2}
  if n<=64:row.update({'gamma_power_exact':str((1+F(1,n))**n),'gamma_power_ge_lower':(1+F(1,n))**n>=lower})
  rows.append(row)
 poly=[]
 for j in range(65):
  s=F(j,8);left=1+s+s*s/2-2*s;right=((s-1)**2+1)/2
  assert left==right and right>0
  poly.append(str(left))
 assert F(3,4)**2>F(1,2)
 return {'binomial_checks':rows,'exponential_majorant_identity':'1+s+s^2/2-2s=((s-1)^2+1)/2>0; exp(s)>=1+s+s^2/2 for s>=0.','identity_rational_samples':65,'identity_sample_values_sha256':hashlib.sha256(json.dumps(poly).encode()).hexdigest(),'geometric_ratio_rational_comparison':{'three_quarters_squared':str(F(3,4)**2),'one_half':str(F(1,2)),'strict':True,'geometric_sum_bound':str(1/(1-F(3,4))),'capped_term_bound':1,'combined_bound':5},'scope':'Universal analytic inequalities are stated separately from finite Fraction samples. gamma^n lower bound follows the positive binomial expansion, not numerical exponentiation.'}

def menu():
 out=[]
 for n in (2,4,8,16,32,64):
  for phase in ('0','1/2'):
   for u in ('zero','half_window','cap'):out.append({'phase':'initial','n':n,'ratio':'2','phase_fraction':phase,'u_kind':u})
 for n in (2,16,64):
  for ratio in ('1001/1000','2'):
   for phase in ('0','999999/1000000'):
    for u in ('node_minus','node','node_plus','cap_minus','cap','cap_plus'):out.append({'phase':'stress','n':n,'ratio':ratio,'phase_fraction':phase,'u_kind':u,'offset':'1e-30'})
 for n in (512,4096,1000000):
  for ratio in ('2','16'):
   for phase in ('0','1/3'):
    for u in ('zero','node_minus','node','node_plus','cap','beyond'):out.append({'phase':'expanded','n':n,'ratio':ratio,'phase_fraction':phase,'u_kind':u,'offset':'1e-25'})
 for n in (2,16,512):
  for u in ('cap_minus','cap','cap_plus'):out.append({'phase':'stress_cap_coincident_with_regular','n':n,'ratio':str((1+F(1,n))**3),'ratio_gamma_power':3,'phase_fraction':'0','u_kind':u,'offset':'1e-30'})
 return out

def num(s):
 q=F(s);return mp.mpf(q.numerator)/q.denominator

def evaluate(c,dps):
 with mp.workdps(dps):
  n=c['n'];h=n*mp.log(1+mp.mpf(1)/n);X=c['ratio_gamma_power']*h if 'ratio_gamma_power' in c else n*mp.log(num(c['ratio']));phase=num(c['phase_fraction'])*h
  # Regular nodes are phase+k*h strictly below X. X is the unique cap, never duplicated.
  count=max(0,int(mp.ceil((X-phase)/h)))
  while count and phase+(count-1)*h>=X:count-=1
  while phase+count*h<X:count+=1
  j=max(0,(count-1)//2);node=phase+j*h;off=mp.mpf(c.get('offset','0'));kind=c['u_kind']
  if kind=='zero':u=mp.mpf(0)
  elif kind=='half_window':u=X/2
  elif kind=='cap':u=X
  elif kind=='cap_minus':u=max(mp.mpf(0),X-off)
  elif kind=='cap_plus':u=X+off
  elif kind=='beyond':u=X+1
  elif kind=='node':u=node
  elif kind=='node_minus':u=max(mp.mpf(0),node-off)
  elif kind=='node_plus':u=node+off
  else:raise ValueError(kind)
  first=max(0,int(mp.floor((u-phase)/h))+1)
  while first<count and phase+first*h<=u:first+=1
  while first>0 and phase+(first-1)*h>u:first-=1
  active=max(0,count-first);regular=mp.mpf(0);linear=mp.mpf(0);used=0
  while used<active:
   y=phase+(first+used)*h-u
   if y>100:break
   regular+=mp.exp(-y)*mp.sqrt(2*y);linear+=mp.exp(-y)*y;used+=1
  omitted=active-used;tail=mp.mpf(0)
  if omitted:
   y=phase+(first+used)*h-u;ratio=mp.exp(-h/2)
   tail=mp.exp(-y/2)*(-mp.expm1(-omitted*h/2))/(1-ratio)
  cap_y=X-u;cap=mp.exp(-cap_y)*mp.sqrt(2*cap_y) if cap_y>0 else mp.mpf(0)
  linear_cap=mp.exp(-cap_y)*cap_y if cap_y>0 else mp.mpf(0)
  linear_partial=linear+linear_cap;linear_upper=linear_partial+tail
  partial=regular+cap;upper=partial+tail;empty=active==0 and cap_y<=0
  assert upper<5 and linear_upper<3 and (not empty or (partial==0 and linear_partial==0))
  vals={'linear_regular_sum_evaluated':linear,'linear_cap_term':linear_cap,'linear_sum_partial':linear_partial,'linear_sum_upper_evaluated':linear_upper,'linear_margin_to_three':3-linear_upper,'n_log_gamma':h,'X_n_log_ratio':X,'first_regular_phase':phase,'u':u,'regular_sum_evaluated':regular,'cap_s':cap_y,'cap_term':cap,'normalized_sum_partial':partial,'analytic_omitted_regular_tail_upper_evaluated':tail,'normalized_sum_upper_evaluated':upper,'margin_to_five':5-upper}
  result={k:mp.nstr(v,32) for k,v in vals.items()}
  result.update({'regular_nodes_before_unique_cap':count,'first_active_regular_index':first if active else None,'last_regular_index':count-1 if count else None,'active_regular_nodes':active,'evaluated_regular_nodes':used,'omitted_regular_nodes':omitted,'cap_active':cap_y>0,'actual_empty_boundary':empty,'upper_below_five_ordinary_check':True,'linear_tail_majorant':'s exp(-s)<=exp(-s/2), since exp(s/2)>=1+s/2+s^2/8>s; same finite geometric remainder upper.','tail_scope':'Exact analytical geometric-tail formula, evaluated with ordinary mpmath; not an outward interval enclosure.','node_length_rule':'each term uses its own s=x-u and L=s/n; no maximum-length replacement'})
  return result

def normalized_score_checks():
 rows=[]
 for n in (2,16,512,1000000):
  menus=[('balanced_endpoints',[0,n],[F(1,2),F(1,2)]),('extreme_mass_endpoints',[0,n],[F(1,100),F(99,100)]),('one_score',[n//2],[F(1)]),('three_scores',[0,n//3,n],[F(1,5),F(2,5),F(2,5)]),('heterogeneous_integer_scores',[i*n//10 for i in range(11)],[F(i+1,66) for i in range(11)]),('zero_mass_branch',[0,n//2,n],[F(0),F(1),F(0)])]
  for name,scores,probs in menus:
   assert sum(probs)==1 and min(probs)>=0 and min(scores)>=0 and max(scores)<=n
   pair=sum((p*q*max(k-l,0) for p,k in zip(probs,scores) for q,l in zip(probs,scores)),F(0))
   knots=sorted(set([0,n]+scores));integral=F(0)
   for a,b in zip(knots,knots[1:]):
    # Any interior midpoint gives the same upper-level set on this knot interval.
    midpoint=F(a+b,2);tail=sum((p for p,k in zip(probs,scores) if k>midpoint),F(0))
    integral+=(b-a)*tail*(1-tail)
   assert pair==integral and pair<=F(n,4)
   rows.append({'n':n,'name':name,'scores':scores,'probabilities':[str(p) for p in probs],'positive_pair_exact':str(pair),'tail_integral_exact':str(integral),'upper_n_over_four':str(F(n,4)),'bound_holds':True,'equality':pair==F(n,4)})
 return {'case_count':len(rows),'results':rows,'analytic_proof':'For a genuine probability distribution on [0,n], sum pi pj (ki-kj)_+ = integral_0^n P(k>r)(1-P(k>r)) dr <= n/4. Normalization is essential.','scope':'Finite exact arbitrary normalized distributions and the stated analytic identity; not an actual source geometry/FULL budget.'}

def main(output):
 rows=[];maxdiff=mp.mpf(0);maxlinear=mp.mpf(0)
 for c in menu():
  a=evaluate(c,40);b=evaluate(c,70)
  with mp.workdps(70):diff=abs(mp.mpf(a['normalized_sum_upper_evaluated'])-mp.mpf(b['normalized_sum_upper_evaluated']));maxdiff=max(maxdiff,diff);ldiff=abs(mp.mpf(a['linear_sum_upper_evaluated'])-mp.mpf(b['linear_sum_upper_evaluated']));maxlinear=max(maxlinear,ldiff)
  assert [a[k] for k in ('active_regular_nodes','cap_active','actual_empty_boundary')]==[b[k] for k in ('active_regular_nodes','cap_active','actual_empty_boundary')]
  rows.append({'configuration':c,'at_40dps':a,'at_70dps':b,'maximum_sum_precision_difference':mp.nstr(diff,16),'linear_sum_precision_difference':mp.nstr(ldiff,16)})
 top=max(rows,key=lambda r:mp.mpf(r['at_70dps']['normalized_sum_upper_evaluated']))
 result={'schema':'R230_scale_clock_actual_node_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'exact_analytic_components':exact_components(),'normalized_score_checks':normalized_score_checks(),'linear_analytic_bound':{'regular_infinite_sum':'exp(-s0)[s0/(1-q)+h q/(1-q)^2]<=2(s0+1)exp(-s0)<=2, h<=1 and q=exp(-h)<=1/2.','cap_bound':'s exp(-s)<=1','total_bound':3,'scope':'Analytic bound using each node length; not inferred from finite samples.'},'normalization_identity':'Original sum = exp(-u) M0^(-n) S, because Mk^(-n)=M0^(-n) exp(-xk) and sqrt(2n Lk)=sqrt(2(xk-u)_+).','case_count':len(rows),'summary':{'maximum_case':top['configuration'],'maximum_upper_evaluated':top['at_70dps']['normalized_sum_upper_evaluated'],'maximum_40_70dps_sum_difference':mp.nstr(maxdiff,16),'maximum_linear_sum_upper_evaluated':max((r['at_70dps']['linear_sum_upper_evaluated'] for r in rows),key=mp.mpf),'maximum_linear_40_70dps_difference':mp.nstr(maxlinear,16),'empty_cases':sum(r['at_70dps']['actual_empty_boundary'] for r in rows)},'results':rows,'scope':['Normalized S sums only x>u, and preserves a unique capped last node.','Arbitrary first phase in [0,h) is retained. u>=0 and n>=2.','The universal constant five uses an explicit analytic majorant, not a fit to finite samples.','Ordinary high precision numerical and algebraic-component checks, not floating-point interval certificates.','No claim of original source-mass/envelope budget, FULL histories, or global theorem closure.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['summary']))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'scale_clock_checks.json');main(ap.parse_args().output)
