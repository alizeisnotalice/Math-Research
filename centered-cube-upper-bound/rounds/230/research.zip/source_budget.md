# R230：先归一两后验，再保留真实 hard 来源费

**范围与结论。** 本稿只估原连续 clock 正交通；不重复本轮 `coupled_geometry.md` 的节点求和证明。固定真实时刻后先对两份同源后验积分，确可完全消除 R229 AG13 中两静态包络的总质量，而且原 score 的通用常数可由 `n` 改成 `n/4`。结合本轮已证线性节点和，得到下文 SB4 的全参数有限来源价。该价仍含真实拥挤比 `ν_V(V)/(q a^n)`，不是一般 `W_β` 付款；共同 cut、low-N 与 hard rank 的现有已读条款没有将这个比值结算掉。本稿不把旧负账、hard cap 或 FIRST 再领一次。

## SB1 固定原行及合法工具

使用本轮 `task_contract.md`、R229 冻结稿 [adaptive_geometry.md AG1–7](/Users/zhengzhihao/Desktop/T/output/centered_cube_round229_20261016_final_checkpoint/adaptive_geometry.md:1)、R228 [clock_source_budget.md CS1–9](/Users/zhengzhihao/Desktop/T/output/centered_cube_round228_20261016_final_checkpoint/clock_source_budget.md:1)，以及 R226 [source_geometry.md SG1–4](/Users/zhengzhihao/Desktop/T/output/centered_cube_round226_20261016_final_checkpoint/source_geometry.md:1)。不重新审旧尺度几何定理。

固定原 `(ω,V,j)`，`γ=1+1/n`、`c=c_j=γ^{-j}`，`a≤L(x),R(x)≤b≤2a`、`g=√(LR)`，保原比例带。`q>0` 是原共同标量，`β=β_V`、`ν=ν_V` 是预冻结实际来源。本祖链确有 `ν≤β≤f dx`。hard 来源是 `ν(dz)`，不属于后验，未限制到 `Z_t(y)`。

固定 `(j,y,t)` 后，原 `Z_t(y)`、`w_t(y,·)`、`e_t(y)` 和 score 不依 receiver `x`；原后验为

\[
 \Pi_{y,t}(dv)=\frac{1_{Z_t(y)}(v)w_t(y,v)}{e_t(y)}\nu(dv),
 \qquad k_t(y,v)=-\partial_{\log t}\log w_t(y,v)\in[0,n]. \tag{SB1}
\]

原有效行且 `e_t>0` 时 `Π` 是概率测度；无效行或零分母直接取零。原删除与阈值时刻可取任一有界 a.e. score 版本，它们不改变 `dt/t` 积分。本稿不把删除跳测度混入这个密度，也不据此领取删除或 boundary 负信用。

令 `𝒫_U` 为仍未付原正交通限制到实际 far 门 `t≤g(x)e^{-U/n}`，`U≥0` 固定。原 high、good-v/bad-u、capture `ρ_0`、FA、suffix、history、共同 cut/low-N 及 hard/source RN 权均保留在真实可测因子 `0≤χ≤1` 中；只在下文明确正上放时删除。`U` 不是辅助来源变量 `u`。原 terminal-good 点态比较仍是

\[
 p_y\le\sqrt{K/3}\sum_{i=1}^3
 \frac{\sqrt{p_yK_i(x-v)}}{\sqrt{w_g(y,v)}}. \tag{SB2}
\]

因此后续外因子仍为 `2Λ√(K/3)/q`；三腿为原 `(L,s)`、`(min(b,γL),s)`、`(b,1)`，不增加独立第三尺度或独立 soft 的资格。

## SB2 同一真实后验的 Gini 界

**引理。** 对任意概率测度 `π` 及可测 `k∈[0,n]`，

\[
 \iint(k(v)-k(u))_+\,\pi(dv)\pi(du)
 =\int_0^n F(r)(1-F(r))\,dr\le n/4,
 \quad F(r)=\pi\{k>r\}. \tag{SB3}
\]

证明：`(a-b)_+=∫_0^n 1_{b≤r<a}dr`。Tonelli 后，两份相同测度给乘积 `π{k>r}π{k≤r}`，且 `F(1-F)≤1/4`。证毕。质量为 `m≤1` 的子概率版本右侧为 `nm²/4≤n/4`。常数由各半质量放在 score `0,n` 取等，故本引理本身不可能再统一改善。

对原同一 `(j,y,t)` 应用 SB3，得到

\[
 \iint\delta_{y,t}(v,u)\Pi_{y,t}(dv)\Pi_{y,t}(du)\le n/4,
 \qquad\delta_{y,t}=(k_t(y,v)-k_t(y,u))_+. \tag{SB4}
\]

这不要求 `e_t` 的上下比，不要求无删除，不使用任何静态包络，也不要求把真实 good/bad 组分别归一。应用时先将其余非负 pair 门上放到 1，才对完整两份 `Π` 使用 SB4。它是正上界；不能以 iid 对称为由消去原带不对称门的正交通，亦未借回此前丢掉的反向负项。

## SB3 receiver-first 的合法顺序

先固定 `j,y,z,v,u,t`，保实际 receiver 参数与 far 门，按 R229 AG2–4 覆盖。向上节点 `M≥M_0=a/c²`、最后一节点截在 `b`，两朝向；共同 soft 菜单 `S_n` 只付一次 `4N_n`，其中

\[
 N_n\le8+4\sqrt n\log(n-1),\qquad n\ge2.
\]

每个原 receiver fiber 的实际 `g≤cM`，故其真实 far 时刻必在

\[
 I_M(U)=[a/c,\ cM e^{-U/n}],\qquad
 |I_M(U)|_{d\log t}=L_M=(\log(M/M_0)-U/n)_+. \tag{SB5}
\]

空区间取零。没有在节点重算 capture、high、FIRST 或 process；所有 fiber 原门只作正上放。尺度覆盖损失至多 `e⁴`。对每固定节点、soft、朝向及腿，R229 AG9–10 给全 receiver 核积分

\[
 J(y,z,v)=\frac{\prod_l I_l-\prod_l I_l^{\rm exc}}
 {(R^*)^n\sqrt{\bar w_{c^2M}(y,v)}}
 \le M^{-n}E_{c^2M}(y,v)\Phi(y,z,v)\le M^{-n}. \tag{SB6}
\]

本稿最后一步明确舍去 `E,Φ≤1`；原捕获排除仅在其已认证支使用，下截断没有额外 `Q_a` 排除。即便不使用任何排除，SB6 的最后界仍成立。

此处两份 `Π` 与 score 在固定 `j,y,t` 不依 `x`，所以可用 Tonelli 先积 `x`。SB6 随后消去 `z,v,u` 依赖的核上界；**此后**对 `ν(dz)` 积分得真实 `ν(V)`，再对完整两份 `Π` 用 SB4。没有把 hard `z` 改成后验，没有把节点核当实际 FIRST 测试。对单腿、单朝向、单 soft 节点、单物理节点，得到

\[
 \int\beta(dy)\nu(dz)\int_{I_M(U)}\frac{dt}{t}
 \iint\delta\,\Pi_{y,t}(dv)\Pi_{y,t}(du)\,M^{-n}
 \le\|\beta\|\|\nu\|M^{-n}\frac{nL_M}{4}. \tag{SB7}
\]

有限原截断下所有换序直接合法；一般非负版本由单调极限成立。实际 histories 即使耦合各槽，只要其 RN 权在 `[0,1]`，上放掉该权后也由同一乘积母测度支配，不要求 histories 条件独立。

## SB4 去包络后的全参数有限来源价

本轮节点引理的线性版本为

\[
 \sum_{M\in\mathcal M_j}M^{-n}nL_M
 \le3e^{-U}M_0^{-n}=3e^{-U}c^{2n}a^{-n}. \tag{SB8}
\]

只核其常数：令 `h=n logγ∈[log2,1]`、`r=e^{-h}≤1/2`。第一正正规节点的 `s_0∈[0,h]` 给正规和
`e^{-s_0}[s_0/(1-r)+hr/(1-r)^2]≤2(s_0+1)e^{-s_0}≤2`；额外截断端点的 `s e^{-s}≤1`。乘 `e^{-U}M_0^{-n}` 即 SB8；详细网格/端点证明属主几何稿。

将 SB7–8 连同三腿、两朝向和共同 `4e⁴N_n` 相加，得到

\[
 \boxed{\mathcal P_U\le
 18e^4N_n\,2\Lambda\sqrt{K/3}\,e^{-U}
 \mathbb E\sum_{V,j}\frac{c_j^{2n}}{q a^n}
                  \|\nu_V\|\|\beta_V\|.} \tag{SB9}
\]

常数恰为 `3腿×2朝向×4e⁴N_n×(1/4)×3=18e⁴N_n`。这是原实际正量的上界，不是另造的 receiver 测试。任意 degree 删除已由真实每时刻的归一处理，不再出现两包络总质量或其乘积。

若同一个物理窗内 `a,q,β_V,ν_V` 不随比例 `j` 改变（原当前定义如此），则无需以原唯一 `j` 来声称不重叠，直接用

\[
 \sum_{j\ge0}c_j^{2n}=\frac1{1-\gamma^{-2n}}\le\frac43
\]

给出更简洁的真实费用

\[
 \mathcal P_U\le
 24e^4N_n\,2\Lambda\sqrt{K/3}\,e^{-U}
 \mathbb E\sum_V\|\beta_V\|\,
       \underbrace{\frac{\|\nu_V\|}{q a^n}}_{\text{实际 hard 来源拥挤比}}. \tag{SB10}
\]

若某次应用改为随 `j` 变的来源或窗，则仅用 SB9，不能提出该比值。`q` 有质量/长度ⁿ单位，故拥挤比无量纲，SB9–10 与 `W_β` 同为质量单位。

## SB5 剩余来源预算：已授与未授的准确界线

SB10 将原包络问题变成一个明确的**真实来源二次质量费**；它尚不等于 `C W_β`。本轮没有证明一般根阶付款。

1. R221 SL1 的实际 hard band 确授：对每个真实 receiver `x` 与全部合法 `B∈[a,b]`，`ν(Q_B(x))≤(16/3)qB^n`。它不能直接改写为 `ν(V)≤Cqa^n`：终端叶边长是 `256na`，不是物理窗 `a`。R221 SL4 的单小胞结算确可替代该胞中的全质量，但仍须支付整个 receiver 覆盖与共同占用；本稿不重领该局部价。
2. R226 SG1–2 确保两源同构造、共同 cut 承载及 `ν≤β`。低-N 是保原 receiver 门时的体积占比 `|N_α∩Q_R(x)|<R^n/(1+log n)`；不是 `ν(N_α)` 的质量上帽。hard rank 是细格 `C` 上的相对质量 `ν(C∩V)/ν(V)<√n/(k+1)`，没有格内密度帽，也没有 soft rank。把这些相对/体积条件直接填成 `ν(V)/(qa^n)≤C` 不合法。
3. 原低叶均值只给 `ν(V)/(qa^n)≤[16e^{1/128}/(3√n)](256n)^n`。此式来自 R221 SL3；它是已知有限价，不是本轮新付款，也不足以由 SB10 推出根阶。共同来源质量可比 `ν(V)≤α(V)<√nν(V)` 同样不提供所需局部物理质量上帽。

若对拥挤比作真实 dyadic 分层，记 `𝒱_m={V:2^m<ν(V)/(qa^n)≤2^{m+1}}`、`W_m=𝔼Σ_{V∈𝒱_m}||β_V||`，则 SB10 右侧保留 `Σ_m2^{m+1}W_m`。原来源不交只给 `Σ_mW_m≤W_β`，没有额外层衰减。这是费用的直接展开，不作为新成果或新未知条件定理。改变 `U` 后可收 `e^{-U}`，但相应浅 clock 部分仍是原未付交通，不能为每叶任选 `U≈log(ν(V)/(qa^n))` 后只保深尾。

最早仍需证明的步骤因此十分具体：利用 SB6 中尚未舍去的同一 hard 来源窗口、`Φ(y,z,v)`、QG 缺口与**原** high/capture/receiver 门，结算真实来源拥挤层；或者给覆盖这些层的真实 receiver 预算。仅恢复静态包络或来源阶段不会解决这一步。SB9 已无需包络，所以本稿在此停止，不把同一未付来源量另行命名为闭合。

## SB6 实际本机核验

系统 Python `fractions.Fraction` 实际运行了 963 项精确断言：`n=2,16,512`，每维64组八点有理概率分布，核对 SB3 的直接双和等于尾概率分层和、`n/4` 上界、三种子概率质量以及两端各半的等号。全部 PASS。该有限代数检查不替代 SB2 的一般证明，不是 FULL 输入认证，亦不验证来源拥挤预算。
