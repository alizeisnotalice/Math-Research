# R230 independent audit

## Initial proposition screening — before author drafts

Read `task_contract.md`. Use the frozen R229 adaptive-grid and R227 pair statements as established inputs, without re-auditing them. No new author proof or numerical result was read before this screening.

### Independent proof of the proposed scale-clock sum

Fix \(n\ge2\), \(\gamma=1+1/n\), \(c=\gamma^{-j}\), \(M_0=a/c^2\), and a fixed \(U\ge0\). The grid consists of regular points \(M_0\gamma^k\) followed, if necessary, by one final point capped at \(b\). If \(M_0>b\), the admissible band is empty. Set
\[
 h=n\log\gamma,\quad q_0=e^{-h},\quad x_M=n\log(M/M_0),\quad
 \ell_M=(x_M-U)_+/n.
\]
Bernoulli and \(\log(1+t)\le t\) give \(q_0\le1/2\) and \(h\le1\). After the regular nodes below \(U\) are removed, write their nonnegative excesses as \(v_k=v_0+kh\), \(v_0\ge0\). Since \(\sqrt{2v}\le v+1/2\),
\[
\begin{aligned}
\sum_{k\ge0}e^{-v_k}\sqrt{2v_k}
&\le \frac{e^{-v_0}(v_0+1/2)}{1-q_0}
 +\frac{e^{-v_0}h q_0}{(1-q_0)^2}\\
&\le2+2=4.
\end{aligned}
\]
The last step uses \(e^{v_0}\ge1+v_0\ge v_0+1/2\). The possible unique capped endpoint contributes at most 1 by the same inequality. Thus, independently of the number of nodes,
\[
\boxed{\sum_M M^{-n}\sqrt{2n\ell_M}\le5e^{-U}M_0^{-n}.}
\]
An exact regular endpoint is counted once, and can harmlessly be overpaid by the extra 1. Nodes with \(x_M=U\) have zero clock length. The singleton grid, \(U=0\), positive \(U\), and all empty windows are covered. The proof does not need an asymptotic approximation to the grid or an extra factor of \(\sqrt n\).

As a local tool check, ordinary 50-digit mpmath evaluation tested 108 combinations of \(n\), admissible first/middle/last \(j\), \(U\), and far-endpoint perturbations. It found no violation (maximum normalized sum approximately 1.41849; this is a finite diagnostic, not the proof). The general estimate is the analytic argument above.

### Original clock and source qualifications

In an actual R229 node fiber, \(g\le cM\), while the actual far endpoint is \(g e^{-U/n}\). Hence the actual clock is contained in
\[
 I_M=[a/c,cM e^{-U/n}],\qquad |I_M|_{d\log t}=\ell_M.
\]
The node clock indicator must be retained in the pointwise finite node sum **before** the receiver integral. Receiver-first Tonelli then yields the same physical column multiplied by this indicator, and R227 can be applied separately on each fixed node window. It is not valid to first enlarge all clocks to \([a/c,bc]\) and recover the node length afterward. All original heavy/process/valid masks stay in the posterior densities, zero outside their original support; no new process or endpoint is recomputed at the node.

The parameter \(U\) must be fixed for this application, as are \((\omega,V,j,a,b)\) before the receiver integral. If an application instead makes \(U\) receiver-dependent, extracting \(e^{-U}\) needs an additional qualified decomposition; this proposition alone does not supply it. The same common static source envelopes may dominate all node windows, since these are subwindows of \([a/c,bc]\). Their two source masses are not normalized to one by this operation.

With the original three-leg pre-hard-cap coefficient \(2\Lambda\sqrt{K/3}\), two orientations and the common-soft factor \(4N_n\), the coarse coupled price is \(40e^4N_n e^{-U}c^{2n}a^{-n}E_a\) **per leg**, or \(120e^4N_n\) for all three. The more precise bound must retain each original hard-source column and its correct inherited capture product difference. Capture radii follow their original qualified R229 branches and are not recomputed using node far endpoints. No additional hard cap has been used.

This is an estimate for the positive remainder, using the pair absolute variation to dominate its positive score. It supplies no cancellation in the original signed ledger, and cannot recover already consumed negative credit after a positive enlargement. The true \(dx\), \(\beta(dy)\nu(dz)\nu(dv)\nu(du)\), common \(q\), actual source process, original branch partition, and static envelopes must survive the return to the original traffic.

**Initial conclusion.** The proposed sum with constant 5 is valid and can remove the extra clock \(\sqrt n\) from the coarse R229 node sum. The remaining soft menu costs \(O(\sqrt n\log n)\); the actual source/envelope budget, including \(\|\nu\|/(qa^n)\) in the crude bound, is still unproved. Await author statements for full integration review; do not register this screening as a new global root payment.

## Independent screening of the normalized-carrier strengthening

The parent's subsequent strengthening also passes at the statement level. After the receiver-first node column has been bounded by \(M^{-n}\), dropping \(E\) and the capture fraction to 1 removes its dependence on auxiliary \(v,u\) and hard \(z\). For the **same original** fixed-\((j,y,t)\) posterior, its mass is 1 on an active row and at most 1 under zero extension of invalid rows. Since \(0\le(k_v-k_u)_+\le n\),
\[
 \iint (k_v-k_u)_+\,\Pi_{y,t}(dv)\Pi_{y,t}(du)\le n.
\]
No static source envelope is needed for this coarser order of operations. The resulting scale sum is
\[
 \sum_M M^{-n}n\ell_M
 =e^{-U}M_0^{-n}\sum_M e^{-s_M}s_M,
 \qquad s_M=(x_M-U)\ge0,
\]
where only positive-length nodes are included. On the regular tail, summing \((v_0+kh)e^{-(v_0+kh)}\) exactly and using \(v_0e^{-v_0}\le1\), \(h\le1\), \(q_0\le1/2\) gives at most 4. The unique cap contributes at most 1. Thus the same constant 5 is valid. The coefficient for all three legs remains \(2\Lambda\sqrt{K/3}\,120e^4N_n e^{-U}\), with \(\sum_{V,j}c_j^{2n}a^{-n}q^{-1}\|\beta_V\|\|\nu_V\|\) and the original expectation retained.

This argument must not renormalize a truncated/new carrier or recompute \(e_t\) at a node. Actual process/clock masks stay unchanged or are extended by zero. Terminal-good qualification first justifies the original three-leg comparison; positive enlargement may then remove it, along with high/history gates. Once those gates are removed, this estimate cannot reuse high's \(1/(2K)\), same-receiver FIRST, or terminal good/bad disjointness as though they still restricted the enlarged receiver column. It uses neither a negative term nor a second hard cap.

The strengthening really eliminates the two envelope masses from the **coarse** bound. It still leaves the full actual \(\beta\) and hard-source \(\nu\) masses divided by \(qa^n\), summed over the original rows. No general-input bound for that quantity has yet been supplied, so the global root conclusion remains open. More refined capture/source estimates may use the exact retained factors, with their original qualifications, instead of this positive coarse enlargement.

## Independent screening of the final sharper constants

For any common subprobability carrier \(\mu\), mass \(m\le1\), and score \(k\in[0,n]\), Tonelli's layer identity gives
\[
 \iint(k(v)-k(u))_+\,d\mu(v)d\mu(u)
 =\int_0^n p_r(m-p_r)\,dr
 \le nm^2/4\le n/4,
 \quad p_r=\mu\{k>r\}.
\]
Thus the proposed \(n/4\) improvement is valid and sharp for the unrestricted common-carrier class. It requires two copies of the **same** original posterior; any actual asymmetric gate is first bounded positively by 1 rather than replaced by an alternative carrier. Local Fraction checks verified 66 endpoint-score/mass combinations, including the equality case; the general proof is the layer identity.

The regular linear scale sum is also at most 2, rather than the earlier coarse 4:
\[
 e^{-s_0}\left[\frac{s_0}{1-q_0}+\frac{h q_0}{(1-q_0)^2}\right]
 \le2e^{-s_0}(s_0+1)\le2,
\]
using \(q_0\le1/2\), \(h\le1\), and \((1+s)e^{-s}\le1\). The unique cap contributes at most 1. Hence
\[
 \sum_M M^{-n}n\ell_M\le3e^{-U}M_0^{-n}.
\]
Combining this with \(n/4\), two orientations and \(4e^4N_n\) gives \(6e^4N_n e^{-U}c^{2n}a^{-n}\) per leg, and \(18e^4N_n\) for all three legs, with the original exterior \(2\Lambda\sqrt{K/3}\). These constants supersede the earlier valid but weaker 5/120 screening constants. The original-carrier, fixed-U, source-measure and unpaid-density qualifications are unchanged.

## Author review checkpoints

Read the complete final `coupled_geometry.md`, SHA256 `ebc4ec8ad3580cc63f2c592e65a446126fc7498e37b4308e26fb3be693d7c8a8`. **Pass for CG0–12 and their stated scope.** The text retains the actual far restriction in the pointwise node expansion before receiver integration. It then uses the uniform node column cap, the same original posterior twice, and finally each node's own clock length. The \(18e^4N_n\) coefficient and original \(2\Lambda\sqrt{K/3}\) factor are correct; no extra two-source mass or hard capacity factor is introduced. The exact shared-window/capture expression remains an optional sharper interface, with proper upper/lower-clamp eligibility, rather than a duplicated credit. CG5 covers the empty and equality endpoints. The arbitrary source envelopes in the pair supplement retain their costs and are absent from the main coarse bound.

Read all of `source_budget.md`, SHA256 `109cba9775668ab5858fb0d2fd19e7d556cfc8a0aa291f2a763d236d5e44830c`. **Pass for the bounded source conclusion.** SB3–7 justify the common-carrier normalization only after the uniform receiver column bound; deleted or invalid rows do not become a new renormalized carrier. SB9 has the full actual \(\beta\) and hard \(\nu\) masses and the correct 18 coefficient. If the physical window, q and both sources are independent of j, SB10 legitimately sums \(c_j^{2n}\le4/3\), giving 24; it does not rely on recovering original j-disjointness after positive enlargement. Its fallback for j-dependent data is explicit.

The source text keeps the next obstruction precise. A hard cap at actual receiver anchors does not cap the mass of the macro leaf; low-N is a volume condition, rank is relative mass, and coupled \(\nu\le\beta\) is not a physical density bound. I narrowly checked the cited R221 SL3 finite leaf-mean constant against the frozen source: the exponential \((256n)^n\) fee is copied accurately and is not a root payment. A leafwise choice of deeper U cannot discard the resulting shallow traffic. No original FIRST/high factor is restored after its gate has been dropped, and no negative or second hard-cap credit is consumed.

Statically reviewed `scale_clock_checks.py`, its raw JSON and `numeric_notes.md`; independently executed the complete script with local mpmath 1.3.0 and an external output path. It returned successfully, and the **entire JSON was byte-identical** to the archived output. It contains 189 deterministic scale/phase/endpoint cases at 40/70 digits, including 75 empty cases, plus 24 exact Fraction score distributions. The repeated cap is avoided by keeping regular points strictly below the unique cap. The large-grid omitted tail uses a valid exponential majorant for both linear and square-root terms, with ordinary high-precision evaluation explicitly distinguished from an outward interval certificate. Ratios beyond the original physical range and arbitrary first phases are generalized sum stress checks, not new original source models. Numerical maxima or precision agreement are not used to prove the universal constants.

Numerical bindings: script `0c51c86467d5742197219895abda68a7b8cd731b3f8a834d08ace3a8d114d307`; complete JSON `ae483cf76b7898d93a092813a6c27580ccba45bae1cea4369ff0ebc86d0861e3`. The author's extra embedded 84 analytic-grid and 963 source-algebra checks are reported finite execution evidence, not additional independently archived FULL certification. Await parent proof/report/driver for final integration and hash freeze.

## Final integration review — 2026-10-17, frozen

Read the full parent `proof.tex.txt` and final `report.md`. Equations (230.1)–(230.5) integrate the accepted node sums and common-posterior bound with the correct order, all three original legs, original measures and coefficient. The requested explicit domain repair \(0<a\le b\le2a\) is present. U is fixed before receiver integration; the shallow complement, \(\sqrt K\), physical source density and original global accounting remain unpaid. The report accurately describes the new no-envelope result, finite numerical scope and next source-congestion task, without claiming the global endpoint or a paid middle layer. The conditional j summation is stated with its actual independence hypothesis.

Statically reviewed final `reproduce.py`: it verifies manifest hashes before execution, copies `task_contract.md` and the numerical script to a fresh external directory, runs the complete script with `--output`, compares the **entire** JSON byte-for-byte, and verifies the manifest again. It inherits the supplied vendor environment. The final package replay will be performed by the parent after this freeze and recorded externally; this audit does not pre-claim that run. The independent complete numerical execution already recorded above is distinct from that final package receipt.

**Final verdict: pass for the bounded R230 results; no outstanding requested correction.** The original far positive traffic now has a bound with only the common-soft \(N_n=O(\sqrt n\log n)\) dimension cost, explicit \(e^{-U}\) decay, and the actual hard-source density fee. The remaining weighted source-congestion sum and the shallow clock complement are not settled. No original negative credit, hard cap, discarded high gate or node FIRST budget is reused. Audit writing stops here.

Final reviewed SHA256 bindings (excluding this audit itself):

| File | SHA256 |
|---|---|
| task_contract.md | `28fcb2eab62eb9051bba8019b08c765b8d92ba2ca8c778e2cb931e12ff899a12` |
| proof.tex.txt | `5fa75bbd644d85602e8e068d4d3b24e407a5fdf6af569d3d27c2537556b175ba` |
| report.md | `69def78a122cc231ebc9ebdd52e99f561020a73b225e8f05443d34218f77edac` |
| coupled_geometry.md | `ebc4ec8ad3580cc63f2c592e65a446126fc7498e37b4308e26fb3be693d7c8a8` |
| source_budget.md | `109cba9775668ab5858fb0d2fd19e7d556cfc8a0aa291f2a763d236d5e44830c` |
| scale_clock_checks.py | `0c51c86467d5742197219895abda68a7b8cd731b3f8a834d08ace3a8d114d307` |
| scale_clock_checks.json | `ae483cf76b7898d93a092813a6c27580ccba45bae1cea4369ff0ebc86d0861e3` |
| numeric_notes.md | `f5aba3f9425e1dd04b2c794fcc46886af57f2a6dbd83a6a0e2328331cf36ae69` |
| reproduce.py | `7c26c6f644919a749aff5ff39de7a01337c3cd7d69951804bb795b4cf49959dd` |
