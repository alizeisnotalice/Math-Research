# R440互补：条件monotone lift与保原mask的熵分部积分

本稿没有取得根阶新付款。它给一个不同于R435累计load Abel式的精确接口：当前microentropy、stage内填充开启的负收益、原marked删除的正成本及终端同时保留。monotone lift须用原stage-averaged early ratio，不能换成true-level early indicator再套本公式；原门适用性由`/tmp/r440_mainproof.md`（r321）§2–4逐项核实；不从RN θ_i单点变化猜测。

## 1. 条件命题及适用范围

**条件ML。** 存在同一原完整marked记录空间及正测度Λ，使阶段原流为Λ_i=1_{I_i}Λ、I_{i+1}⊂I_i；原新增保留权可写为固定mark函数或逐stage递减的正权F_i。所有初始/未来路径核必须先在该共同空间固定再作限制，不能重建或归一来源。则把Λ_iF_i经任意固定非负source kernel投影，所得实际保留密度逐stage非增。证明就是Λ_{i+1}F_{i+1}≤Λ_iF_i；不要求条件RN平均θ_i本身非增。

出处`/tmp/r440_history.md`定位R397 `r397_source.md:40–43`、R408 `research.tex:173–198`、R413 `research.tex:543–571`：原γ_i和原Γ_i嵌套，a_i只是投影；故不能任意制造history replacement。D_i↓、s_i^e↓使旧D_i(y)>s及高s_i^e门递减；静态质量/rank/lowcommon、固定路径mark、light full-cell均不随stage变。filled门只随当前level t增加。原early必须准确冻结为：对共同记录的首次删除j及当前来源z，

e_i^j(z)=|[T_{i−1},T_i)∩[0,f(z))∩[0,(1−δ)T_j)|
         /|[T_{i−1},T_i)∩[0,f(z))|。

原b_early=b_i e_i精确；e_i随i为1→至多一个crossing fraction→0，零增量选单调延拓。e_i在本stage内固定并保留在原θ_i，不换成1{t<(1−δ)T_j}。r321主证明`/tmp/r440_mainproof.md`§2给准确early比率，§3核原first-deletion/soft/future与固定full-f路径，§4以共同权(4)证明固定t的stage下降；§5明确本稿ML对原流适用，但只限此averaged选择。若只知RN θ_i∈[0,1]仍不足。R413的对称M_i仅是支配，不替换真实流。

## 2. 精确current-mask定义

固定R439网格、τ及light条件M_{C(z)}<m_A/K。令P(t,z)=∫_0^t1_{f(z)>r}φ(ell_{C(z)}(r))dr为累计microentropy，∫P(∞,z)dz≤nlog(4n²+3)W。原stage系数（包括上述averaged e_i）不随新插入的level r重算。这里的level只是原δg_i的均匀积分标签，不是重新定义的原early时钟。

定义

G_i(t,z)=Σ_e∫σ(dA)c_A(z)/m_A
  ·1_{M_C<m_A/K}1_{m_t(A)≥τm_A}
  ·∫π_A(dy)a_i^e(A,y)θ_i^e(A,y,z),
c_i(z)=(1−s/D_i(z))_+, U_i(t,z)=c_i(z)G_i(t,z).

Γ_i原marked流与这里G_i勿混同。G_i定义为固定t的共同延拓，**不含**1{T_{i−1}≤t<T_i}；实际积分才取本stage窗口。G_i≤D_i；在每个固定stage内，early ratio已冻结，U_i随t非减，只有filled门开启。ML适用时，对每个相同t有G_{i+1}(t,z)≤G_i(t,z)，于是stage边界U也非增。

大维数下R439的light+filled原贡献≤(4/s) I_N，其中

I_N=Σ_{i≤N}∫dz∫_{T_{i−1}}^{T_i}U_i(t,z)dP(t,z).

没有删θ、路径或stage。原低填充SτX、重cell价格保持独立。

## 3. 新mask-sensitive精确式

在边界T_i先计本stage的filled开启，再作原stage删除。有限N的Stieltjes分部积分严格给

I_N = T_N^ent − I_0^ent − F_N^ent + D_N^ent,          (1)
T_N^ent=∫P(T_N,z)U_{N+1}(T_N,z)dz,
I_0^ent=∫P(T_0,z)U_1(T_0,z)dz,
F_N^ent=Σ_i∫dz∫_{(T_{i−1},T_i]}P(t,z)d_tU_i(t,z),
D_N^ent=Σ_i∫P(T_i,z)[U_i(T_i,z)−U_{i+1}(T_i,z)]dz.

P连续；因此同一level的fill/delete相撞也按此约定精确计算。F_N^ent≥0是实际fill开启带来的有利负项。ML成立时D_N^ent≥0是真实marked删除成本，含stage-averaged early ratio下降；其符号不是付款。终端不能由D_i↓直接去掉。

若改用true-t early展开（本稿不用），stage内可能有early关闭原子，d_tU须分为dF−dC，右侧必须另加非负关闭价格∫P dC。不能把另一lift在加filled后产生的量与本稿混用；该关闭可作为numeric现有delete事件，无需更改代数接口。

边界还准确分解为

U_i−U_{i+1}=(c_i−c_{i+1})G_i+c_{i+1}(G_i−G_{i+1}).   (2)

前项是clipping下降；后项是条件ML下的实际retained记录删除，不能称任意RN replacement。G_i≤D_i给G_i(c_i−c_{i+1})≤D_i−D_{i+1}，但乘子P(T_i,z)仍须保留。

**条件stage-count-free上界。** 在共同marked空间逐记录计价：每份初始权至多分期删除一次，或留在终端。filled mask≤1，c_i也递减。因此

T_N^ent+D_N^ent≤∫P(∞,z)U_1^all(z)dz
 ≤SA_n·nlog(4n²+3)W,                                (3)

其中U_1^all去掉filled/light门，≤D_1。此证明只用嵌套测度，不是receiver tree。它避免虚假stage数，但仍是O(n²log n)W，不足所需O(n polylog n)W。

## 4. 唯一未付signed比较

采用r321已核的averaged共同提升后，(1)暴露的准确缺口是：原实际删除时刻的累计entropy收费与终端，能否由stage内fill收益抵消到

T_N^ent+D_N^ent−F_N^ent
 ≤εsX_q/4+C_ε nlog^A(n+2)W                          (4)

并对N一致、终端合法。(4)未证。它量化的是每份实际记录从填充开启到删除之间积累的source entropy；原D单调只提供删除正测度，未给这个entropy residence预算。不能把当前门施加给旧entropy，也不能单独丢掉终端、或用负fill项的存在声称其覆盖删除项。

因此本路线尚未消除R439的multiplicity。r321已按原归档验证当前averaged选择的ML，所以(1)–(3)可用于真实删除预算；改换不满足ML的门时，必须保留相应signed边界差，不能把它强制改正。本文不假定未过滤Dη有强上界。

## 5. 数值接口（仅代数）

numeric已实际核下列精确离散式：B_j累计entropy，W_j为两level间load；level j先fill A_j≥0、再delete d_j≥0，W_{j+1}=W_j+A_j−d_j，则

ΣW_j(B_j−B_{j−1})=B_MW_{M+1}−B_0W_1−ΣB_jA_j+ΣB_jd_j.

输入由共同record r的fill level及嵌套系数g_{i+1,r}≤g_{i,r}、D_i↓、c_i构造；不得自造原a_i更新。实际完成3例21事件，含非零初端/终端、fill/delete相撞及(3)，全部Fraction断言通过；指定Python3.12.14、SymPy1.14.0另核单事件符号残差为0。报告`/tmp/r440_numeric.md`，脚本`/tmp/r440_numeric.py`，完整证书`/tmp/r440_numeric_certificate.json`。我已核报告与本文符号、事件顺序及范围一致，不复跑扩大。有限算例只验接口，不认证ML或原history。一般结论依以上条件与证明。

交付即停；无母账修改。
