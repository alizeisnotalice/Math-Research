# R440: a native boundary-center entropy budget across every clipping level

**Outcome.** A genuine joint source/clipping/center estimate is proved below: its cost is O(A_nW/q), uniformly over the actual variable-side selector. For δ=a/n² it is O(nW/q), compatible with a later division by s=1+√n. What remains unproved is the comparison of the original marked path-arrival measure with this paid measure. No whole-flow payment, contraction, or change to the R433 mother ledger is claimed.

## 1. Fixed-level geometric capacity, including the variable-side base term

Keep full f≥0 in L1, actual Lebesgue receivers v∈E, actual cubes Q_v of side a≤R_v≤b≤2a, and m_v=∫_{Q_v}f=q_vR_v^n with q_v≥q>0. Let C be a grid cube of side δ, g_t=min(f,t),

\[
 M_C(t)=\int_Cg_t,\qquad b_{vC}(t)=\int_{C\cap Q_v}g_t,
 \qquad A_n=1+n\log(b/a).
\]

A cube *cuts* C if it intersects C without containing all of C. Boundary conventions do not affect the source integrals. For every actual selector,

\[
 \int_{Q_v\text{ cuts }C}R_v^{-n}\,dv
 \le (1+\delta/a)^n A_n. \tag{1}
\]

Indeed, for R_v≤r and Q_v∩C≠∅, its center belongs to C+[-r/2,r/2]^n, of volume (r+δ)^n. The exact layer-cake decomposition, including the lower-dimensional possibility of constant selected side, gives

\[
 \begin{aligned}
 \int_{Q_v\cap C\ne\varnothing}R_v^{-n}\,dv
 &\le b^{-n}(b+\delta)^n
   +n\int_a^b r^{-n-1}(r+\delta)^n\,dr\\
 &\le(1+\delta/a)^n[1+n\log(b/a)].
 \end{aligned}
\]

This is a sublevel-set bound for the actual selector, not integration over an independent radius. Since u log(1/u)≤1/e,

\[
 I_C(t):=\int_{Q_v\text{ cuts }C}
 \frac{b_{vC}(t)}{m_v}\log\frac{M_C(t)}{b_{vC}(t)}\,dv
 \le \frac{(1+\delta/a)^nA_n}{eq}M_C(t). \tag{2}
\]

Terms with b=0 are zero. This controls center capacity, without bounding f by a boundary volume.

## 2. All clipping levels are paid once

For fixed C,v write M=M_C(t), b=b_{vC}(t). If b(∞)=0 everything below is zero. Otherwise b(t),M(t)>0 for every t>0 and are locally absolutely continuous. For F(t)=b(t)log(M(t)/b(t)), the a.e. identity is

\[
 F'=b'\log(M/b)-b'+bM'/M. \tag{3}
\]

The lower endpoint is legitimate: 0≤F(t)≤M(t)/e→0 as t↓0 by dominated convergence. At infinity M,b converge to their full-f masses. Integrating (3) on finite intervals and using bM'/M≥0 gives

\[
 \begin{aligned}
 \int_0^\infty b'(t)\log\frac{M(t)}{b(t)}\,dt
 &\le b_\infty\left[\log\frac{M_\infty}{b_\infty}+1\right]\\
 &\le M_\infty. \tag{4}
 \end{aligned}
\]

The final inequality is u(log(1/u)+1)≤1 for 0<u≤1. The left integrand is nonnegative, so passing to the endpoints uses monotone convergence; no signed infinite cancellation is needed. Since b'(t)=∫_{C∩Q_v}1_{f(x)>t}dx a.e., (1), (4), and Tonelli prove the all-grid theorem

\[
 \boxed{
 \sum_C\int_{Q_v\text{ cuts }C}\frac{dv}{m_v}
 \int_0^\infty\!\int_{C\cap Q_v}
 1_{f(x)>t}\log\frac{M_C(t)}{b_{vC}(t)}\,dx\,dt
 \le\frac{(1+\delta/a)^nA_n}{q}W.}
 \tag{5}
\]

This applies to the countable grid because ∑_CM_C(∞)=W. Receivers containing the whole cell have b=M and contribute zero, so they can also be included in (5). For δ=a/n² the prefactor (1+δ/a)^n≤e^{1/n}; there is no stage count or time-integral divergence. This theorem does **not** multiply the entropy by an unfiltered D_i.

## 3. Why a small-δ center-boundary gain cannot be assumed

A single exact native family shows why (1) cannot be replaced by a bound vanishing with δ. Take f=q1_{[-b,b]^n}, C=[−δ/2,δ/2]^n, 0<t≤q, E={a≤2||v||∞≤b}, and R_v=2||v||∞. Then Q_v⊂[-b,b]^n, m_v=qR_v^n, and M=tδ^n. On the subdomain where the largest center coordinate in absolute value exceeds all others by at least δ/2, the corresponding cube face passes through zero and b_{vC}=M/2. The other coordinates capture all of C. This actual center subdomain has shell volume n(R−δ)^{n−1}dR. Thus, for δ<a,

\[
 I_C(t)\ge\frac{M\log2}{2q}
 n\int_a^b\frac{(R-\delta)^{n-1}}{R^n}\,dR
 \ge\frac{M\log2}{2q}n(1-\delta/a)^{n-1}\log(b/a). \tag{6}
\]

For b=2a and δ=a/n² this is order nM/q. This is a check of the **boundary kernel's sharp scale**, not an original-history counterexample and not a claim that nW/q is useless. Its scale is exactly compatible with the contemplated division by √n. No broader family was scanned.

## 4. The original-arrival comparison still needed

Retain the original stage, clipping label, both sources, all history and future gates. For one actual fixed-source chain v_0,…,v_N, set

\[
 \Phi_t(v,x)=\log\frac{m_v}{b_{v,C(x)}(t)}.
\]

On live records these quantities are finite almost everywhere by density differentiation and the actual absolutely continuous source/center marginals. The exact balance is

\[
 \log\frac{m_{v_0}}{m_{v_N}}
 =\Phi_t(v_0,x)-\Phi_t(v_N,x)
  +\log\frac{b_{v_0,C(x)}(t)}{b_{v_N,C(x)}(t)}. \tag{7}
\]

The positive capture correction is bounded by log(M_C(t)/b_{v_N,C}(t)). Hence (5) could pay this correction if the relevant marked terminal-arrival projection were dominated, with an admissible coefficient, by the **native measure**

\[
 1_{f(x)>t}c_v(x)\,dx\,dt\,\frac{dv}{m_v}. \tag{8}
\]

No such comparison has been proved. The terminal law ρ_x|_{Z≤h}/h is a conditional law per starting record; after summing the original parent/stage records it still carries their arrival multiplicity. It does not establish (8). Nor does own-low rank imply low original D_i or endpoint-history eligibility. Identities (7) may be integrated on bounded-log truncations, but removing those cutoffs under original weights also needs the missing comparison or another integrability argument.

Thus (5) is a real entropy-weighted native center budget, while transferring original marked loss to that budget remains the single unresolved step of this attempt. It is not declared equivalent to, or necessary for, the whole target. No new receiver or source receives old history.

## 5. Actual local verification

Executed `/tmp/r440_geometry_check.py` with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (python-flint 0.9.0); stdout: `/tmp/r440_geometry.result.txt`.

* Nine Fraction configurations at n=9,16,25 verify actual cube/cell intersection volumes and the multiplicative form of (7).
* Fifteen Arb interval checks at 192-bit precision certify the three fixed-parameter coefficients in (6), its geometric lower bound, and compatibility with (2). The certified I_C/(nM/q) values for the explicit subdomain are approximately .223656, .230278, .233663.
* Six Arb checks integrate log ratios of exact affine clipping masses on three source-cell examples and verify both inequalities in (4); these are analytic primitives with rigorous intervals, not floating quadrature.

The first Arb clipping run exposed an unsupported direct Fraction-to-arb constructor. It was replaced by exact numerator/denominator conversion and the complete script was rerun successfully. These checks certify the stated finite arithmetic only. The general bounds are proved above; original-history arrival domination and the whole root-scale budget remain unproved. No further exploration is undertaken.
