from fractions import Fraction as F

def overlap(a,b,c,d): return max(F(0),min(b,d)-max(a,c))
count=0
for n in (9,16,25):
    delta=F(1,n*n)
    for frac in (F(1,4),F(1,2),F(3,4)):
        # Full density f=1 on [-3,3]^n, actual sides 2 and 1, q=1.
        C=(F(0),delta)
        parent=[(F(-1),F(1))]*n
        child=[(frac*delta-1,frac*delta)]+[(delta/2-F(1,2),delta/2+F(1,2))]*(n-1)
        x=[frac*delta/2]+[delta/2]*(n-1)
        b0=F(1); b1=F(1)
        for j in range(n):
            assert parent[j][0]<x[j]<parent[j][1]
            assert child[j][0]<x[j]<child[j][1]
            b0*=overlap(*C,*parent[j])
            b1*=overlap(*C,*child[j])
        m0=F(2**n); m1=F(1)
        assert b0==delta**n and b1==frac*b0
        # Exact multiplicative form of the logarithmic balance.
        assert m0/m1==(m0/b0)/(m1/b1)*(b0/b1)
        # Terminal/source replacement would omit this strictly positive ratio.
        assert b0/b1>1
        count+=1
    print('dimension',n,': 3 exact capture/balance configurations PASS')
print('PASS',count,'configurations; analytic logarithms are checked via exact multiplicative identities.')
print('Scope: full uniform f and selected cube/source-cell geometry only; not a certified original historical flow, center integral, or terminal-cost bound.')

# R440 continuation: certified ball arithmetic, fixed three parameters only.
from flint import arb, ctx
from math import comb
ctx.prec=192
arb_checks=0
for n in (9,16,25):
    d=arb(1)/(n*n)
    l2=arb(2).log()
    # Exact analytic primitive of n integral_1^2 (R-d)^(n-1) R^(-n) dR.
    J=l2
    for k in range(1,n):
        J+=arb(comb(n-1,k))*(-d)**k*(1-arb(2)**(-k))/k
    J*=n
    lower=n*(1-d)**(n-1)*l2
    cost=l2*J/2  # I_C /(M/q) on the explicitly selected subdomain.
    upper=(1+d)**n*(1+n*l2)/arb(1).exp()
    assert J>lower; arb_checks+=1
    assert J<n*l2; arb_checks+=1
    assert cost<upper; arb_checks+=1
    assert (1-d)**(n-1)>=1-arb(n-1)/(n*n); arb_checks+=1
    assert upper<(arb(1)/n).exp()*(1+n*l2)/arb(1).exp(); arb_checks+=1
    print('Arb n=',n,'I_C/(n M/q) in',cost/n)
print('PASS',arb_checks,'Arb strict interval/coefficient checks at 192 bits, flint 0.9.0.')
print('The analytic native-center proof is in the note; Arb verifies only its finite parameter arithmetic, not original marked-arrival domination.')

# Continuous clipping integral on one source cell; three contiguous suffix captures.
def ball(x):
    if isinstance(x,F): return arb(x.numerator)/x.denominator
    return arb(x)

def primitive(x):
    return arb(0) if x.is_zero() else x*x.log()-x

def intlog(a,c,l,u):
    if a == 0:
        return ball(u-l)*ball(c).log()
    return (primitive(ball(a*u+c))-primitive(ball(a*l+c)))/ball(a)
clipchecks=0
for caps in ((F(0),F(0),F(1)),(F(0),F(1,2),F(1)),(F(1,2),F(1),F(1))):
    densities=(F(1),F(2),F(4)); vols=(F(1,3),)*3
    integral=arb(0)
    endpoints=(F(0),F(1),F(2),F(4))
    for lo,hi in zip(endpoints,endpoints[1:]):
        M_s=sum(v for v,d in zip(vols,densities) if d>lo)
        M_c=sum(v*d for v,d in zip(vols,densities) if d<=lo)
        b_s=sum(v*k for v,d,k in zip(vols,densities,caps) if d>lo)
        b_c=sum(v*d*k for v,d,k in zip(vols,densities,caps) if d<=lo)
        if b_s:
            integral+=ball(b_s)*(intlog(M_s,M_c,lo,hi)-intlog(b_s,b_c,lo,hi))
    Mf=sum(v*d for v,d in zip(vols,densities))
    bf=sum(v*d*k for v,d,k in zip(vols,densities,caps))
    rhs=ball(bf)*(ball(Mf/bf).log()+1)
    assert integral<rhs; clipchecks+=1
    assert rhs<ball(Mf); clipchecks+=1
    print('Clipping caps=',caps,'integral=',integral,'upper M=',Mf)
print('PASS',clipchecks,'Arb continuous-clipping bound checks; interval integration of exact affine pieces, not quadrature.')
