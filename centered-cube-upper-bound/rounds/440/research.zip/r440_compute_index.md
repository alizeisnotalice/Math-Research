# R440 计算索引（已完成）

责任：numeric独占本轮IBP数学计算；不启动agent、不修改他人或repo，不重复其他角色的昂贵实验。

输入只读：
- `/tmp/r440_contract.md`：任务边界与未付款multiplicity。
- `/tmp/r440_history.md`：原动态源头；不重建a_i。
- complement经消息冻结的mask-sensitive单事件／求和公式及同record单调条件；正式推导由其`/tmp/r440_complement.md`负责。

计算：
- 基础4事件/4record/2stage；collision压力5/5/4；扩大12/9/6，共3例21事件。
- Fraction精确核每事件更新、fill收益、删除费用、initial和非零terminal，以及stage-count-free初始unfilled上界。
- SymPy化简一般单事件IBP残差为0。
- 状态：全部实际运行通过；仅有限代数接口，非原history或一般上界认证。

指定环境与实际命令：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r440_numeric.py`

sys.executable同上；Python3.12.14、SymPy1.14.0。未使用flint，当前Fraction／符号恒等式不需要它。环境功能本身不认证数学命题。

输出归档：
- `/tmp/r440_numeric.md`：范围、等式与三阶段结果。
- `/tmp/r440_numeric.py`：便携脚本，输出到自身目录。
- `/tmp/r440_numeric_certificate.json`：确切有理数据、每事件记录及环境字段。
- `/tmp/r440_numeric_run.txt`：实际命令stdout。
- `/tmp/r440_numeric_resources.txt`：实际进程资源。
- `/tmp/r440_compute_index.md`：本索引。

无LP、随机样本、几何扫描、原阶段算子仿真或新树模型。交付停止。

追加状态：在同一脚本、同一指定解释器中实际重跑四个early比率接口（f内段终止、c端点、c跨stage、有限终端早于c）。核e_i非增及精确有限终端剪裁和；零增量合法选0延拓。原3模型21事件未改变。输出仍为上述同名JSON/stdout/resources，无新文件依赖或数学扫描。

## 其他本轮计算责任（合并索引）

- geometry独占真实交叠质量核与Arb参数算术：`r440_geometry_check.py` → `r440_geometry.result.txt`，9个Fraction配置、15项192位Arb系数与6项解析截断积分检查。使用同一独立解释器和python-flint0.9.0；不认证原marked到达权。
- mainproof负责冻结early的有限符号接口：`r440_mainproof_check.py` → `r440_mainproof.result.txt`，18列单调比率及36项恒等式，另检查加filled后两种提升不同及RN均值变化。与numeric的early部分有交叉，不能累计为独立几何覆盖。
- 独审隔离复跑上述三个脚本，stdout及numeric JSON一致；这是复现，不增加参数覆盖。
- 主代理归档后仅检查包内隔离复现及哈希；不重新运行昂贵优化。

本轮没有安排SciPy/CVXPY/MATLAB实验：当前决策是精确代数、区间误差与原测度适用性，未用浮点最优状态替代证书。后续按具体几何放缩目标选择工具。
