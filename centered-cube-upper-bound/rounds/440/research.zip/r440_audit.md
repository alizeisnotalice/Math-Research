# R440 independent final audit

FINAL PASS（仅限本轮列明的一般几何预算、保原stage平均early的共同单调提升及条件分部积分；不认证完整R433上界或新增原流付款）。2026-10-20。15件冻结输入后审完成；唯一发现的溯源错误已修正并复核，现无此范围内的阻断项。原母账、所有旧费用、有限终端和未付删除成本均保留。

## 数学与源合同核验

1. 独立先验推导确认一般正预算。固定(v,C)，B=∫C∩Qv f、M=∫C f，有
   ∫b′(t)log(M_C(t)/b(t))dt ≤ B[1+log(M/B)]≤M。
   B或M为零时整项为零；端点可用非负截断及单调收敛，不作不定的有符号∞相减。实际选择器的精确层饼 R_v^−n=b^−n+∫_(R_v)^b n r^−n−1dr 保留b端base，中心子水平集合体积≤(r+d)^n。Tonelli及可数格求和严格给出 (1+d/a)^n[1+nlog(b/a)]W/q，包含b=a和有正测度的端点选择器。该式没有D_i、history或任意未受控到达乘子；作者的持续穿格例及路径捕获损失身份不补出该乘子。

2. 共同提升核验针对原加权边级联。已实际回读所引用的R391、R397、R408、R413及后续相关冻结定义。history初稿错误援引旧无权接收占用的TeX段；现已改引R391权威附件r391_geometry.md:20–46的 γ_A=1_(A×A)γ、实际双端密度s_A和 D_A=∫s_A cR^−n，§1/§4及修正记录一致。R408/R413的s_i、D_i为嵌套原流的加权投影；a_i不是clipping增量，也不由后筛选密度重算。

3. 首次删除j、原时钟、旧/新来源及未过滤full-f路径可保存在同一正记录空间。后来的固定路径/质量/来源门不重建生成核；受限路径不被宣称仍独立。对固定j,F，stage平均early比率依次为1、至多一个crossing fraction、0，零增量作单调延拓。冻结该比率再展开clipping层，正好保留本轮选定的R439分解。true-level early指示乘filled后一般改变正分拆，不能混用。固定t的共同负载下降不包含stage窗口；每个固定stage中只有filled开启。归一RN均值θ_i可以升高，下降的是未归一原测度。有限尚存片须单列，只有原清空极限才去掉。

4. complement的Stieltjes式符号及碰撞顺序正确：I_N=terminal−initial−fillGain+deletionCost；同level先fill再stage删除，P连续，边界权精确分拆。删除成本非负而未付，终端不自动消失。逐原记录总删除或存活仅计一次，给所列stage-count-free粗界，但该粗界仍不足根阶目标。若另换true-level early，必须补关闭测度。当前证明没有抹去原source、D_i或终端到达重数。

## 实际复现与证据边界

使用指定解释器 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，在独立目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r440_audit_isolated_0f2n8mqa` 实际运行geometry、mainproof、numeric三脚本，均退出0；三份stdout与冻结输入逐字一致，再生numeric_certificate.json也逐字一致。Python3.12.14、SymPy1.14.0、python-flint0.9.0/Arb192bit与记录一致。未运行MATLAB或新增优化。

几何证据为9个Fraction配置及15+6项Arb区间参数断言；一般中心预算另依解析证明。mainproof为18列early、36身份及两个接口反差检查。numeric为3个有限共同记录模型/21事件、四个early边界接口及SymPy残差0；零增量取0的数值范围为来源已在T_prev以下的尾部，不外推任意plateau。三者交叉部分和本次复跑均不增加覆盖数，不混称完整原生history实例或一般定理的数值证书。资源文件只保留实际进程记录，不作为数学证明。PRE的临时高精小数诊断不纳入最终正式计算统计。

未证项仍是：原marked到达投影相对原生几何测度的受控支配，以及累计熵的终端/删除成本与fill收益的根阶联合结算。因此无新增R433付款、无闭合、无新吸收；本PASS不能用于认证这些未证结论。

## 冻结字节 SHA-256（15输入）

- `r440_main.md`: `6f2a575218634de20374fb340f19fb0c5bdcd298899ca4d7a44182f1c91f1004`
- `r440_geometry.md`: `667d70b527b21515f139fe2f7f0431dc70038adafe0411b0b1d5ae13d7345e1c`
- `r440_geometry_check.py`: `c7be9f5d1f8682caa597ddfdc964ef19728b9eb5f7b5ff14111683c1601ab8c6`
- `r440_geometry.result.txt`: `b1dcbe6fbf2627dd366dba32ac7723efa12700c93e1b1b52436233486047b8d5`
- `r440_history.md`: `4a6a39b0f6d8bddf7f1cf83f1a43de1b871dcd335f4290ec8283200e78fad7ed`
- `r440_mainproof.md`: `887e87a8da98f6132303d3c6861c2ce1568e6c19c933314282ef6d0e026987f0`
- `r440_mainproof_check.py`: `8756c73bb8462a335f479e8350cf9bc1300ffc3dc56fa6b0320a9542e588383b`
- `r440_mainproof.result.txt`: `a21e13ffd05dfc4f89a014cc31ae4c2662ced60e911d2370d24d1712b1a92a8d`
- `r440_complement.md`: `e686b69331992ccd6b0017d72a2f6f4015db8dede98f0a94a398ec8f9d7b7906`
- `r440_numeric.md`: `2ad9d7adac12bb2fc4993f4020147e4c7bc6c9bbddd284fccf7f492da34e96a1`
- `r440_numeric.py`: `02d75f31f2ac8f6886921ec8cfca3b794691aeb6f1d468c0e2a3a329773faa41`
- `r440_numeric_certificate.json`: `76d8abd7ad1001f934032d0e78b8cd010df004456dae42f528c380d434fc0210`
- `r440_numeric_run.txt`: `18e6faf211aabc463cfe40fb1f59e92cab769f028021aa34ec7f5b1cc0d6a95f`
- `r440_numeric_resources.txt`: `e92d5cdae29646f71e0ea5f4fdc0f8e7d3b6fdaeddca8021cb3833e0f5e85b7d`
- `r440_compute_index.md`: `030a7c5fe98fca40271bf4bee03bc58d281301dd9d36abe4444defed35f6a055`
