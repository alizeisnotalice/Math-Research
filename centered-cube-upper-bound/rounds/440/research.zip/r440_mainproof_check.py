from fractions import Fraction as F


def length(a, b, *ends):
    return max(F(0), min(b, *ends) - a)


def ratio(a, b, f, cut):
    d = length(a, b, f)
    if f == 0:
        return F(0)
    return length(a, b, f, cut) / d if d else F(a < cut)


configs = [
    ([0, 1, 2, 3], F(5), F(1, 4)),
    ([0, 1, 2, 3], F(3, 2), F(1, 4)),
    ([0, 1, 2, 3], F(1, 2), F(1, 4)),
    ([0, 1, 10, 11], F(8), F(1, 3)),
    ([0, 1, 10, 11], F(0), F(1, 3)),
    ([0, 1, 10, 11], F(20), F(1, 3)),
]
sequences = identities = 0
for raw, f, delta in configs:
    ts = list(map(F, raw))
    for j in range(1, len(ts)):
        cut = (1 - delta) * ts[j]
        es = [ratio(a, b, f, cut) for a, b in zip(ts, ts[1:])]
        assert all(x >= y for x, y in zip(es, es[1:]))
        sequences += 1
        for i in range(1, j + 1):
            a, b = ts[i - 1:i + 1]
            d = length(a, b, f)
            late = max(F(0), min(b, f, ts[j]) - max(a, cut))
            assert d * es[i - 1] == d - late
            identities += 1

# The level expansion with frozen original ratio and the alternative true-level
# early indicator agree before a level-dependent filled gate, but not after it.
a, b, f, cut, fill = map(F, [0, 2, 3, 1, 1])
e = ratio(a, b, f, cut)
assert e * length(a, b, f) == length(a, b, f, cut) == 1
frozen_filled = e * length(max(a, fill), b, f)
true_level_filled = length(max(a, fill), b, f, cut)
assert frozen_filled == F(1, 2) and true_level_filled == 0

# A projected conditional average may rise although the unnormalized
# retained measure does not.
base0, marked0, base1, marked1 = map(F, [4, 1, 1, 1])
assert marked1 <= marked0 and marked1 / base1 > marked0 / base0

print(f"PASS {sequences} monotone early sequences, {identities} early identities")
print("PASS frozen-filled = 1/2, true-level-filled = 0; expansions must not mix")
print("PASS RN average can rise while retained unnormalized mass is nonincreasing")
print("Scope: exact finite algebra only; no native full-history certification")
