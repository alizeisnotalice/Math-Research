# R440：原阶段索引与密度定义溯源

检索起点为 R413 契约和 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/413/research.zip`；按其中明确引用继续只读 R408、R397、R391 的归档。下列行号均为对应 ZIP 成员解压后的原始行号（可用 `unzip -p ARCHIVE MEMBER | nl -ba` 复核）。

## 1. 原接收端弱端点删除及 R397 阶段迭代

R391 的当前权威附件 `r391_geometry.md:20–46` 定义对任一当前接收集 A⊂E，先作真实双端边限制 γ_A=1_{A×A}γ，令 s_A 为其相对 σ 的两端边缘密度之和，再定义：
\[
D_A(z)=\int_E s_A(w)c_w(z)R_w^{-n}\,dw,
\quad e_A(z)=\mathbf1_{D_A(z)>s}(1-T/f(z))_+,
\quad p_A(w)=\int e_A(z)\,\pi_w(dz),\quad
A_0=E,\ A_{j+1}=\{w\in A_j:p_{A_j}(w)>1-\theta\}.
\]
即每轮保留后验通过严格 `>` 门的接收端，删去其余 (win A_j)。这里用原始完整 (f,m_w,pi_w)；阶段改变的是实际双端边限制及其加权占用，不改源场/后验。已删除边在仍存活端点的贡献也必须删除；不能替换成无权接收中心占用。以上 (T) 是一次 R391 cascade 的密度剪裁阈值。

R397 `r397_source.md:40–43` 再定义外层阈值级联：给递增序列 (0<T_0<T_1<\cdots)，阶段 i 从 (A_i) 出发，“run the full R391 deletion rule at threshold (T_i)” 得到该轮极限保留集 (A_{i+1})，并置
\[
\gamma_i=\mathbf1_{A_i\times A_i}\gamma,\quad G_i=\gamma_i(E^2),\quad D_i=D_{A_i}.
\]
因此边测度是原固定 \(\gamma\) 的嵌套正限制，跨界边随某端点删除即删；未重建核或归一化来源。R397 `r397_source.md:63–71` 定义阶段剪裁费用而非旧来源密度：
\[
b_i(z)=\frac{\min(f(z),T_i)-\min(f(z),T_{i-1})}{f(z)}(1-s/D_i(z))_+,
\quad B_i=\int\gamma_i(du,dv)[\pi_u(b_i)+\pi_v(b_i)].
\]
零 (f) 或 (D_i) 按文中约定置零。也有等价的源积分式 (B_i=\int[\min(f,T_i)-\min(f,T_{i-1})](D_i-s)_+dz)（同文件 `:57–60`）。这是“剪裁增量 × 当前占用门”，不是 (a_i^e)。

## 2. R408 的动态占用定义及单调性

R408 `research.tex:173–198`（同包 `r408_main.md:7–10` 是摘要性合同）明确 \(\gamma_i\) 为原完整标记边测度按既有端点作嵌套正限制，\(\gamma_{i+1}\le\gamma_i\)；可取 R397 的 \(\mathbf1_{A_i^2}\gamma_0\)。令 (s_i(A)\sigma(dA)) 为 \(\gamma_i\) 两端边缘之和，(\sigma(dA)=q_A dA)。故
\[
0\le s_{i+1}\le s_i\le S,\quad \int s_i\,d\sigma=2G_i.
\]
对真实来源 (z)，
\[
\alpha_i^z(dA)=s_i(A)q_Ac_A(z)\,dA/m_A
=s_i(A)c_A(z)R_A^{-n}dA,\qquad D_i(z)=\alpha_i^z(E).
\]
这就是两端占用；等价地 (D_i(z)=\int\gamma_i(du,dv)[c_u(z)/m_u+c_v(z)/m_v])。由于 \(\gamma_i\) 嵌套正限制、(c_A/m_A\) 固定非负，(s_i(A))、(\alpha_i^z)、(D_i(z)) 均逐阶段非增。该单调性是定义后由正限制推出，不是 clipping 的单调性本身。\(D_i\) 是当前实际端点占用，不等于来源全场重数 (J)。

## 3. 原流旧来源系数 (a_i^e) 与其关系

R413 `research.tex:543–571`（同包 `r413_main.md:3b`）在原实际流的两种端点方向 (e=u,v) 上定义旧来源投影：
\[
d\Gamma_i^e(A,y)=\sigma(dA)a_i^e(A,y)\pi_A(dy),\quad
0\le a_i^e\le B_e,\quad B_u=\beta,\ B_v=C_{\rm col},
\]
其中原文说明 (a_i^u) 是原 \(\ell_i\) 总量、(a_i^v) 是原 (k_i)（`research.tex:554–555`）。然后定义
\[
s_i^e(A)=\int a_i^e(A,y)\pi_A(dy),\quad e=u,v,
\qquad s_i=s_i^u+s_i^v,
\]
并有
\[
D_i(x)=\int_E[s_i^u(A)+s_i^v(A)]c_A(x)R_A^{-n}dA.
\]
此处的 (s_i^e) 是原流 \(\Gamma_i\) 的端点边缘密度；其和与上一节实际边测度两端密度 (s_i) 匹配。它们随 (i) 非增，因为 \(\Gamma_i\) 是嵌套原流限制。**(a_i^e) 不等于 clipping 增量** \([\min(f,T_i)-\min(f,T_{i-1})]/f\)，也没有证据表明它由此公式生成；(T_i) 影响阶段删除筛选，而 (b_i) 才直接含 clipping 增量与 (D_i)。R413 明确称 (a_i^e,s_i^e,D_i) 为“原、未加新门”定义，新增门不重算它们（同文件 `:540–570`）。

## 4. 对“树”的判定及精确限度

此处是递减接收集 (A_i) 与递减边测度 \(\gamma_i=\mathbf1_{A_i^2}\gamma_0\)，并非已定义的接收树：归档没有节点父子映射、分叉规则或树流守恒。可说“嵌套阶段/级联”，不能据这些引用称 receiver tree。R397 `r397_source.md:42` 是阶段更新规则的外层摘要；R391 `r391_geometry.md:20–46` 给真实双端边加权占用及单一剪裁阈值下的内层更新公式；两者合起来支持按 (T_i) 逐阶段应用该删除规则。R413 所用 (a_i^e) 是同一原实际流在阶段后的旧来源投影密度，不能由 (b_i) 或任意重新筛选后的密度替换。

**来源缺口说明。** 本次范围内能核对到 R391 删除算子、R397 阈值级联定义及 R413 对 (\Gamma_i,a_i^e) 的原流 RN 定义；归档未给出一个将每个 (a_i^e(A,y)) 化成 clipping 公式的恒等式，因为它不是该类量。R408/R413 是从前述边级联取原流投影的接口，而不是独立重建一棵新接收树。

独审修正记录：初稿误引R391 research.tex:1993–2016的旧无权接收占用；已回读r391_geometry.md:20–46改为当前真实边加权定义。R408/R413和本轮主证明从始至终使用加权D_i，不能把这次溯源修正解读为更换原流。
