# R440 mask-sensitive IBP精确接口核验

已读R440 contract/history并采用complement冻结公式。实际按用户指定解释器运行`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r440_numeric.py`。Fraction负责有限数值，SymPy仅核一般单事件恒等式。完成3个确定性模型、21个事件，没有随机扫描、LP、新几何样本或原history模拟。脚本及输出在同目录：`r440_numeric.py`、`r440_numeric_certificate.json`、`r440_numeric_run.txt`、`r440_numeric_resources.txt`。

## 接口和符号

供给非负非降累计数据B_j。第j个开区间使用W_j；在事件t_j先按旧stage开启fill A_j≥0，再作原stage形式的删除d_j≥0。因此

`W_{j+1}=W_j+A_j−d_j`，

`Σ_j W_j(B_j−B_{j−1})=B_MW_{M+1}−B_0W_1−Σ_jB_jA_j+Σ_jB_jd_j`。

这里B只是有限有理累计接口数据，不冒称本实验构造了真实current entropy。g_i,r也是显式单调有限系数，非原a_i的重建；其适用性仍取决于主证明对原记录的monotone lift认证。

每个record有精确fill事件ℓ_r；g_i,r=base_r(r+1)/(i+r+1)逐stage非增。D_i供给为逐stage非增正有理数，c_i=(1−s/D_i)_+。脚本独立核

`Γ_i(j)=Σ_{ℓ_r≤j}g_i,r`, `A_j=c_iΣ_{ℓ_r=j}g_i,r`。

stage边界上

`d_j=c_iΓ_i(j)−c_{i+1}Γ_{i+1}(j)`。

并逐项认证d_j≥0、更新后的W与新stage实际Γ一致。碰撞时另拆d_j为“只删既有record”及“当次新fill也被删除”的loss，两项均非负；忽略后者会误计W。

## 三阶段实际结果

|阶段|事件×record，stage数|LHS=RHS|末端B_MW_{M+1}|初端B_0W_1|碰撞fill删除loss|
|--|--|--|--|--|--|
|基础|4×4，2|913/256|2045/384|1/4|0|
|fill/deletion碰撞压力|5×5，4|61247/23625|304399/88200|4/25|7111/5040|
|扩大有限范围|12×9，6|1879466119/151351200|115465050121/7729722000|27/35|26401/80080|

压力例在事件2、3、5同时fill和stage deletion；扩大例有多次碰撞及无fill删除。两者都必须先按旧stage开启fill，随后删除包括新fill的部分。所有项都乘同一事件累计B_j，没有把左／右B混用。

三例初端与末端均严格非零。脚本保存并核验每事件的W_before、W_after、A、d、collision loss和B，以及完整有理系数。删除贡献符号为**加**ΣB_jd_j；fill收益为**减**ΣB_jA_j；初端为减，末端为加。JSON另记录错误删去末端、fill或deletion各自造成的确切偏差，避免把终端默认为零或把删除当收益。

## 范围

实际检验支持这条带mask／事件顺序的IBP代数接口。它没有认证原stage删除算子生成这些g_i,r，也没有生成原a_i^e、来源路径、θ、current entropy或原保留历史。因此不能由这21事件推出原weighted entropy价格、终端控制或整体R433上界。没有将有限数据拟合当一般几何定理。


## 指定环境与附加接口核验

sys.executable=/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python，Python3.12.14，SymPy1.14.0；这些字段保存于JSON。SymPy将一般单事件

`W_j(B_j−B_prev)−[B_j(W_j+A_j−d_j)−B_prev W_j−B_j A_j+B_j d_j]`

展开为精确0。这个符号恒等式不含原history适用性假设；环境可用也不认证命题。

按complement追加的同record单调条件，三例还精确核验了stage-count-free上界：设U0=c0Σ_all_records g0,r（包括尚未fill的记录），则W_final+Σd_j≤U0，以及terminal+ΣB_jd_j≤B_M U0。确切左右值保存在每例JSON字段中。这仍保留initial-unfilled multiplicity，并非根阶费用界。

本轮计算责任、输入、状态和全部输出列于`r440_compute_index.md`；未机械调用所有数学库，未由可运行环境得出任何原历史结论。

## 唯一追加：原early stage比率

保持原21事件模型及结果不变，按冻结接口另核stage常量

`e_i=length([Tprev,Ti]∩[0,f)∩[0,c))/length([Tprev,Ti]∩[0,f))`, `c=(1−δ)T_delete`。

零增量且f≤Tprev时选e_i=0作单调延拓。Fraction实际核四个小例：f在stage内终止、c恰端点、c跨stage，以及有限终端早于c。对应e序列为(1,1,1/2,0)、(1,1,0,0)、(1,1,1/3,0,0,0)、(1,1)，均非增。精确加权和分别9/4、3/2、25/12、5/4，全部等于

`Σδg_i e_i=min(T_N,f,c)−min(T_0,f,c)`。

该测试没有将原early stage平均系数改成pointwise level mask。全部δ、T_delete、截断端点、分子分母和比率保存在JSON的early_ratio_cases。仍用指定独立解释器实际重跑；仅补冻结early代数，不认证原history。
