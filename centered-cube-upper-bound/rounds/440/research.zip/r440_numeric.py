"""Three exact mask-sensitive IBP interface models, no original-history claim.
All event indices are exact integers; fill is applied before stage deletion.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform
import sympy as sp

wj,bj,bprev,aa,dd=sp.symbols("W_j B_j B_prev A_j d_j")
wnext=wj+aa-dd
single_event_residual=sp.expand(wj*(bj-bprev)-(bj*wnext-bprev*wj-bj*aa+bj*dd))
assert single_event_residual==0
ROOT=Path(__file__).resolve().parent

def model(name,M,fills,base,bounds,Ds,s,B0,increments):
    assert len(increments)==M and len(Ds)==len(bounds)+1
    R=len(fills);assert len(base)==R and all(0<=j<=M for j in fills)
    assert all(Ds[i]>=Ds[i+1]>0 for i in range(len(Ds)-1))
    # Explicit monotone-lift algebra assumption, not a reconstruction of a_i.
    g=[[b*F(r+1,i+r+1) for r,b in enumerate(base)] for i in range(len(Ds))]
    assert all(g[i+1][r]<=g[i][r] for i in range(len(Ds)-1) for r in range(R))
    cs=[max(F(0),1-s/d) for d in Ds]
    assert all(cs[i]>=cs[i+1] for i in range(len(cs)-1))
    Gamma=lambda i,j:sum((g[i][r] for r in range(R) if fills[r]<=j),F(0))
    i=0;W=cs[0]*Gamma(0,0);W1=W;B=B0
    lhs=fillprice=deleteprice=deleteqty=collisionloss=F(0);rows=[]
    for j,inc in enumerate(increments,1):
        assert inc>=0
        expected=cs[i]*Gamma(i,j-1);assert W==expected
        B+=inc;lhs+=W*inc
        newmass=sum((g[i][r] for r in range(R) if fills[r]==j),F(0))
        A=cs[i]*newmass
        old_inclusive=cs[i]*Gamma(i,j)
        assert old_inclusive==W+A
        d=dpre=loss=F(0);oldstage=i
        if j in bounds:
            d=old_inclusive-cs[i+1]*Gamma(i+1,j)
            dpre=cs[i]*Gamma(i,j-1)-cs[i+1]*Gamma(i+1,j-1)
            loss=cs[i]*newmass-cs[i+1]*sum((g[i+1][r] for r in range(R) if fills[r]==j),F(0))
            assert d==dpre+loss and d>=0 and dpre>=0 and loss>=0
            i+=1
        Wnext=W+A-d
        assert Wnext==cs[i]*Gamma(i,j) and Wnext>=0
        fillprice+=B*A;deleteprice+=B*d;deleteqty+=d;collisionloss+=loss
        rows.append({'event':j,'stage_before':oldstage,'stage_after':i,
          'B_before':str(B-inc),'B_event':str(B),'delta_B':str(inc),
          'W_before':str(W),'old_stage_fill_A':str(A),'deletion_d':str(d),
          'deletion_preexisting_only':str(dpre),'collision_fill_deletion_loss':str(loss),
          'W_after':str(Wnext),'lhs_increment':str(W*inc),
          'signed_fill_benefit':str(-B*A),'deletion_cost':str(B*d)})
        W=Wnext
    assert i==len(Ds)-1
    terminal=B*W;initial=B0*W1;rhs=terminal-initial-fillprice+deleteprice
    assert lhs==rhs and terminal>0 and initial>0
    unfilled_initial=cs[0]*sum(g[0],F(0))
    assert W+deleteqty<=unfilled_initial
    assert terminal+deleteprice<=B*unfilled_initial
    return {'name':name,'events':M,'records':R,'stages':len(Ds),
      'fill_events':fills,'base_coefficients':list(map(str,base)),
      'g_stage_record':[[str(a) for a in row] for row in g],
      'D':list(map(str,Ds)),'s':str(s),'c':list(map(str,cs)),
      'LHS':str(lhs),'terminal':str(terminal),'initial_subtraction':str(initial),
      'fill_benefit_subtraction':str(fillprice),'deletion_cost_addition':str(deleteprice),
      'RHS':str(rhs),'collision_fill_deletion_loss_total':str(collisionloss),
      'initial_unfilled_all_records_load':str(unfilled_initial),
      'terminal_plus_unweighted_deletion_load':str(W+deleteqty),
      'terminal_plus_weighted_deletion_price':str(terminal+deleteprice),
      'stage_count_free_bound_BM_unfilled_initial':str(B*unfilled_initial),
      'terminal_omission_error_RHS_minus_LHS':str(-terminal),
      'fill_omission_error_RHS_minus_LHS':str(fillprice),
      'deletion_omission_error_RHS_minus_LHS':str(-deleteprice),
      'event_rows':rows}

cases=[
 model('Stage 1 basic',4,[0,1,2,4],[F(1),F(2),F(1,2),F(3,2)],
       [3],list(map(F,[12,8])),F(3),F(1,3),[F(1,2),F(2,3),F(1,4),F(3,4)]),
 model('Stage 2 fill/deletion collision pressure',5,[0,2,3,3,5],
       [F(1,2),F(2),F(1),F(3),F(1,3)],[2,3,5],list(map(F,[20,15,10,8])),
       F(4),F(2,5),[F(1,7),F(2,7),F(1,3),F(2,5),F(1,2)]),
 model('Stage 3 expanded finite event/record range',12,[0,1,2,4,5,7,9,10,12],
       [F(k+2,k+1) for k in range(9)],[3,5,8,10,12],list(map(F,[30,24,18,15,12,10])),
       F(3),F(3,7),[F((j%4)+1,j+3) for j in range(1,13)])]
assert sum(c['events'] for c in cases)==21
assert F(cases[1]['collision_fill_deletion_loss_total'])>0
assert F(cases[2]['collision_fill_deletion_loss_total'])>0
for c in cases:
 print(c['name'],': events=',c['events'],'records=',c['records'],'stages=',c['stages'])
 print(' LHS=RHS=',c['LHS'],'terminal=',c['terminal'],'initial=',c['initial_subtraction'])
 print(' subtract fill=',c['fill_benefit_subtraction'],'add deletion=',c['deletion_cost_addition'],
       'collision loss=',c['collision_fill_deletion_loss_total'])
# Frozen early ratio is a stage constant, not a pointwise time mask.
early_specs=[
 ('f_ends_inside_stage',F(5,2),F(1,4),F(3),[F(0),F(1),F(2),F(3),F(4)]),
 ('c_exact_endpoint',F(5),F(1,2),F(4),[F(1,2),F(1),F(2),F(3),F(4)]),
 ('c_crosses_stage',F(9,2),F(1,3),F(7,2),[F(1,4),F(1),F(2),F(3),F(7,2),F(5),F(6)]),
 ('finite_terminal_before_c',F(3),F(1,4),F(3),[F(1,4),F(1),F(3,2)])]
early=[]
for name,f,delta,Tdelete,thresholds in early_specs:
 cutoff=(1-delta)*Tdelete;ratios=[];layers=[];numerators=[]
 for a,b in zip(thresholds,thresholds[1:]):
  den=max(F(0),min(b,f)-a)
  num=max(F(0),min(b,f,cutoff)-a)
  assert F(0)<=num<=den
  ratio=num/den if den else F(0)
  if not den:assert f<=a # legal monotone zero extension after f ends
  ratios.append(ratio);layers.append(den);numerators.append(num)
 assert all(ratios[i]>=ratios[i+1] for i in range(len(ratios)-1))
 actual=sum((dg*e for dg,e in zip(layers,ratios)),F(0))
 expected=min(thresholds[-1],f,cutoff)-min(thresholds[0],f,cutoff)
 assert actual==expected
 early.append({'name':name,'f':str(f),'delta':str(delta),'T_delete':str(Tdelete),
  'c':str(cutoff),'stage_thresholds':list(map(str,thresholds)),
  'delta_g':list(map(str,layers)),'early_numerators':list(map(str,numerators)),
  'stage_constant_ratios':list(map(str,ratios)),
  'weighted_sum':str(actual),'clipped_identity_RHS':str(expected),
  'ratios_nonincreasing':True,'zero_increment_extension':'0 when f<=Tprev'})
 print('Early:',name,'ratios=',','.join(map(str,ratios)),'exact sum=',actual)
(ROOT/'r440_numeric_certificate.json').write_text(json.dumps({'environment':{'sys_executable':sys.executable,'python_version':platform.python_version(),'sympy_version':sp.__version__},'single_event_sympy_residual':str(single_event_residual),'cases':cases,'early_ratio_cases':early,
 'scope':'Only finite monotone-lift algebra interface; rational B is supplied cumulative data, not certified original current entropy; no original history/geometry or global inequality.'},indent=2)+'\n')
print('Environment:',sys.executable,platform.python_version(),'SymPy',sp.__version__)
print('SymPy single-event IBP residual:',single_event_residual)
print('PASS: 3 models, 21 events; exact IBP, initial/terminal, fill benefit and deletion cost, collision ordering.')
print('PASS: four early ratio interfaces, including three required boundary types and finite-terminal clipping.')
