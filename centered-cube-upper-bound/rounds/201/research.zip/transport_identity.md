# R201：物理截帽的完整尺度输运与真实空间交换

状态：基础输运检查点。本文证明含 uniform 硬面的物理核及截帽的分布恒等式，明确哪些奇异通量严格抵消、哪些内部反应和空间交换仍存在。另列固定常数系数的无维度质量变差工具和真实 J 的显式线性误差价。它们不支付一般原 weighted 伴随，也不控制任意 receiver 选择 L(x)；没有登记一般根阶闭合。

## TI1　变量、原测度与局部资格

固定 s∈[0,1]、来源中心 y，写 r=log L、X=x−y，
\[
 f_s=(1-s)1_{[-1/2,1/2]}+s\phi,\quad
 p_r(x)=e^{-nr}f_s^{\otimes n}(e^{-r}X),\quad \phi=h*w.
\]
核按原闭硬面定义。分布恒等式在紧 r 区间、紧 receiver 测试函数上使用，不需要原输入 f 光滑。这里 f_s 是物理一维核，不是输入来源密度。

先固定 B,J>0，再允许 B=B(r,x,y,v)、J=J(r,x,v)>0；原 J=P1,b(x−v) 实际不依 r。定义
\[
 F_r(x)={\min(p_r(x)^2,(B_r(x)J_r(x))^2)\over J_r(x)}
 =\min\{p_r^2/J_r,B_r^2J_r\}. \tag{TI1}
\]
定义截帽 strata 为 unsaturated p<BJ、saturated p>BJ。p=0 时 F=0，不使用 log p。B=0 的扩展可用 TI9 的有限差分，不用含 log B 的式子。

原回代固定 (ω,V,j,y,t) 时，
\[
 d\Pi_{y,t}(z)=1_{Z_t(y)}(z)w_t(y,z)d\nu_V(z)/e_t(y)
\]
不依 receiver x 或运行 L；外 β=βV 同样在运行 L 前固定。两槽始终是同一原 Π，β、ν 只共父，不假 β≥ν。若使用适应后验、Πg 或变动 t，其相对于原 ν 的真实密度须并入后文空间权 G；不能仍称该基础测度固定。

本稿不重构 actual α/history/原停止树。A、H、原接收域、unique-j、FIRST 及其余资格全部保留在真实 G 中。微分式若要求 G 的额外正则性，必须单独证明；TI9–11 的有限差分不作该假设。

## TI2　含硬面的原密度 continuity 方程

精确缩放流为
\[
 \Phi_h^y(x)=y+e^h(x-y),\quad
 p_{r+h}(\Phi_h^y x)=e^{-nh}p_r(x),\quad
 \det D\Phi_h^y=e^{nh}. \tag{TI2}
\]
由对任意紧支撑光滑测试函数换元，得到完整分布式
\[
 \partial_r p_r+\operatorname{div}_x(Xp_r)=0. \tag{TI3}
\]
这不是只在 bulk 成立。以一个面 |Xi|=L/2 为例，令 Δp=p_inside−p_outside≥0。尺度导数的面测度为 +(L/2)Δp dH^{n−1}，空间 divergence 的面测度为 −(L/2)Δp dH^{n−1}，两者严格抵消。多面交角余维至少二，不另生单面测度。

等价弱式是 ∫p(∂rζ+X·∇xζ)drdx=0。它对 s=0 的纯硬核、s=1 的纯软核以及所有混合 s 都成立。

## TI3　固定常数 B、J 的截帽：反应项不可丢

令 σ=1_sat−1_unsat。完整分布恒等式为
\[
 \boxed{\partial_rF+\operatorname{div}_x(XF)=n\sigma F.} \tag{TI4}
\]
证明一：在缩放流上 e^{nh}F_{r+h}(Φh x)=min(e^{-nh}p_r²/J,e^{nh}B²J)。其 h 导数为 nσ 乘该最小值，在帽等号处用 Lipschitz 链法的 a.e. 导数。再按流换元，得到 TI4。

证明二：bulk 内材料导数 D_y=∂r+X·∇ 满足 D_y p=−np。unsaturated 支上 D_yF=−2nF，saturated 支上 D_yF=0。加 div X=n 后恰得 −nF 或 +nF。帽阈值处 F 两支连续，不产生 delta。

在原硬面上必须使用真正有限帽跳
\[
 \Delta F={\min((p_+)^2,(BJ)^2)-\min((p_-)^2,(BJ)^2)\over J}. \tag{TI5}
\]
∂rF 的面项是 +(L/2)ΔF，div(XF) 的面项是 −(L/2)ΔF，所以完整输运中不留下非线性 jump defect。但单独 ∂r 链式不能把 ΔF 替换成任一侧 Fp·Δp；例如 p−=0、p+=1、BJ>1 时，ΔF=1/J 而右导数乘 Δp 为 2/J。严格相消的是同一有限 secant 的两份面项，不是虚假的光滑链式。

因此原硬面和连续 dilation 的几何已统一；所得量不是质量守恒密度，因为 nσF 仍在。

## TI4　固定常数的全空间质量：无维度但仅共同尺度

本节转录父级提供的辅助恒等式，并给完整推导。设 f=f_s^{⊗n}，∫f=1，M(r)=∫F_r(x)dx。由 x=y+e^r z，
\[
 \boxed{M(r)=B\int f(z)
 e^{-|\log[f(z)/(BJ)]-nr|}\,dz.} \tag{TI6}
\]
f=0 的积分项定义为 0。确切代数为
min(e^{-nr}f²/J,e^{nr}B²J)=Bf exp(−|log(f/(BJ))−nr|)。

每个 z 分量是关于 r 的单峰函数，峰高 Bf(z)，从 r=−∞ 的 0 增至峰再回到 r=+∞ 的 0。因此正 Tonelli 或 AC 导数给
\[
 \operatorname{Var}_\mathbb R^+ M\le B,\qquad
 \operatorname{TV}_\mathbb R M\le2B. \tag{TI7}
\]
M 在紧区间 AC，且 M(±∞)=0（以 Bf 支配收敛），故 TV M=2Var+M。TI7 不声称 Var+M 必等于 B：不同 z 峰可互相抵消。任意子区间也有 Var+≤B；保留初末态时仍使用真实 M(r0)、M(r1)。

纯硬核 f=1_unitcube 给 M(r)=min(e^{-nr}/J,B²J e^{nr})，在阈值两侧 M'=∓nM，整条路径正变差为 B。这同时检验 TI4 的 ±n 反应是必须的，并说明无维度全路径费来自共同质量的单峰积分，而不是把瞬时 n 项删去。

TI7 只控制先 ∫dx 后共同标量 L 的质量变差。它不控制 ∫sup_L F_L dx，也不控制原 ∫F_{L(x)}(x)dx。把正变差或上确界移过 receiver 积分正是尚未证明的选择器步骤。B 可依固定来源 y,v 而不依 x,r；逐来源用 TI7 后会留下 ∫B(y,v)β(dy)Π²，不能自动把 B=B0/Wg 的倒 overlap 费用换成线性 WA。软度 s 在本式中固定；共同 soft 选择也不被 TI7 免费覆盖。

## TI5　变系数的精确分布反应

先假 B,J 在 (r,x) 上正且 C1（局部远离零），不对输入来源作梯度假设。令 D_y=∂r+X·∇x，off tie 定义 θ=1_unsat，σ=1−2θ。完整式为
\[
 \boxed{\partial_rF+\operatorname{div}_x(XF)=\mathcal R_F,}
\]
\[
 \mathcal R_F=n(1-2\theta)F
 -\theta F D_y\log J+(1-\theta)F D_y\log(B²J). \tag{TI8}
\]
证明：在两个 bulk strata 分别对 p²/J、B²J 用材料导数；加 div X=n。帽阈值 F 连续；物理硬面有限 ΔF 的 transport secant 相消同 TI3，即使 B、J 在空间变化也不改变该速度。对 p=BJ 的正测度部分，Lipschitz min 链法要求两分支材料导数 a.e. 兼容；可在该 a.e. 意义选择 θ∈[0,1]，不能声称任意孤立等号点两 RHS 相同。

TI8 的分布弱式为 ∫F(∂rζ+X·∇ζ)+∫RF ζ=0。若 B/J 只有 BV 或有跳，不直接把 log 导数写成经典函数；必须按合法的空间/尺度迹加入其完整有限系数跳。一般仅可测系数直接改用 TI9–11。

若 B 不依 x,r，J=J(x)，式子简化为
\[
 \mathcal R_F=\sigma F\{n+X\cdot\nabla\log J\}
 =\sigma(F/J)\operatorname{div}_x(XJ). \tag{TI8a}
\]
这是精确公式，不是把 div(XJ) 当成无权零积分：σF/J 的空间变化不能丢掉。

## TI6　原软 J 的明确系数价

原 J=P1,b(x−v)>0，已证 |∇logJ|∞≤Lφ/b，Lφ=2/(1−e^{−1})。B 固定于 x,r 时，
\[
 |\mathcal R_F-n\sigma F|\le(L_\phi/b)\|x-y\|_1 F. \tag{TI8b}
\]
帽保留点态 F≤Bp。物理矩 ∫|z|fs(z)dz≤11/12（硬核矩 1/4、w 混合 Laplace 的矩 2/3 及三角不等式）给
\[
 \int|\mathcal R_F|dx\le nB\{1+11L_\phi L/(12b)\}. \tag{TI8c}
\]
在 [a,b] 共同尺度上，若用完整 flux 边界消失，或直接对缩放后固定 z 的积分作 AC 链法，则
\[
 \operatorname{TV}_{[\log a,\log b]}\int F_rdx
 \le nB(1+11L_\phi/12)\log(b/a). \tag{TI8d}
\]
该代价保留全部 n；对 receiver selector 或带实际 A/H 的伴随不能直接使用。它是无输入梯度的真实 J 误差工具，不是新的根阶界。B 若依 x，则 TI8 的 DlogB 项完整存在，不能仍用此固定帽价。

## TI7　真实空间权的微分式与合法边界

令 G=A²H，或将后验空间密度、接收域等并入 G。若 G 在 (r,x) 上 C1，且各项可积，
\[
 \partial_r(GF)+\operatorname{div}_x(XGF)
 =G\mathcal R_F+F D_yG. \tag{TI9}
\]
若只想用有跳的版本，须有相应 piecewise AC/合法双侧迹及加权变差可积；乘积跳使用真实有限 Δ(GF)，不默认 G 的单侧值。一般 BV 的弱产品也须指定合法配对/trace，不能把未证明的原 good/BV 作为已知。原 A 的同 α 变化、good 恢复、history/FIRST 和 high/bad 进入均在 D_yG 或其有限差分中；TI9 不支付它们。

对全空间 receiver 积分，只有 div 项在足够衰减/可积 flux 条件下严格消失。充分条件是相应截断后 ∫|X|GF dx 有限并可用 cutoff 通过极限，或直接核验 annulus flux→0。有限空间区域若具有合法边界迹，则保留法向 flux；任意可测原接收域没有免费 perimeter/trace，必须并入 G 或用下一节差分。

所以“负 Jacobian 与面相消”只消除完整 transport 的奇异部分；空间积分后仍有 GRF、FDG。不能仅由 ∫div=0 推出所有 n 项消失。原 source 固定时不需要 β 的梯度；若改把 divergence 移到 source-y 一侧，则需要另行合法化，不能因 β∈L1 就积分分部。

## TI8　固定原来源积分后的向量 flux

在固定 (ω,V,j,t) 的真实基础测度
\[
 dm=\beta(dy)\Pi_{y,t}(du)\Pi_{y,t}(dv)
\]
下，先有限截断使所有 signed 项可积，令
\[
 \mathcal E(r,x)=\int G_rF_r\,dm,\qquad
 \mathcal Q(r,x)=\int(x-y)G_rF_r\,dm.
\]
TI9 正确给
\[
 \partial_r\mathcal E+\operatorname{div}_x\mathcal Q
 =\int(G\mathcal R_F+FD_yG)\,dm. \tag{TI10}
\]
它是不同 source 速度 x−y 的真实向量总 flux，不能随意写成某个共同速度乘 E。固定 Π 不产生额外 x 导数；若 Π 空间适应，则其相对于 ν² 的实际密度必须乘进 G，归一分母和支持变化一并保留，不视作免费概率。

任意 L1 的 β 允许以上固定-source Fubini，不授予 ∇β 或总变差控制。无界 joint 积分只在绝对可积、或正负项各有控制时通过，禁止 ∞−∞。原 beta/nu 共父不消除 B0/Wg、两槽 normalizer、window/j/time 的复用价。

## TI9　任意可测系数、资格的精确 flow 差分

本节不假 B,J,G 有梯度、BV 或 trace。假 B,J 正可测，G≥0 可测，并在有关的有限限制上使下式积分存在；状态缺原资格时先用真实零延拓，不能虚构另一侧 α。

固定起点 (r,x)，写 p=p_r(x)，
\[
 B_h=B(r+h,\Phi_h^yx),\ J_h=J(r+h,\Phi_h^yx),\ G_h=G(r+h,\Phi_h^yx),\ G_0=G(r,x),
\]
\[
 T_h=e^{nh}F_{r+h}(\Phi_h^yx)
 =\min\{e^{-nh}p²/J_h,e^{nh}B_h²J_h\},
\]
\[
 F_h^{\rm fr}=\min\{e^{-nh}p²/J_0,e^{nh}B_0²J_0\},\quad C_h=T_h-F_h^{\rm fr}. \tag{TI11}
\]
B0,J0 这里是 flow 起点系数，不与原来源帽常数的符号混淆。为避免歧义，使用时可改名 B_start,J_start。Frozen 仅冻结系数，没有冻结物理 Jacobian；T_h 的式子直接由 TI2，含闭硬面完全成立。

若 I(r)=∫G_rF_r dx，则准确换元给
\[
 \boxed{I(r+h)-I(r)
 =\int G_0(F_h^{\rm fr}-F_0)dx
 +\int F_h^{\rm fr}(G_h-G_0)dx
 +\int G_h C_hdx.} \tag{TI12}
\]
三个項依次是真实 frozen reaction、资格/权重的 transport 交换、J/B 系数交换。没有 spatial gradient 的假设。相应正上界保留各项正部，不能把第二、三项改称 0。

Frozen 反应本身精确为
\[
 F_h^{\rm fr}-F_0
 =\int_0^h n\sigma_\tau^{\rm fr}F_\tau^{\rm fr}\,d\tau, \tag{TI13}
\]
有向积分处理 h<0，帽等号只造成导数切换，不产生 delta。

系数交换可以在保留帽后量化。设
\[
 \omega_h=\max\{|\log(J_h/J_0)|,
 |\log(B_h²J_h/(B_0²J_0))|\}.
\]
两个 min 分量分别乘 J0/Jh 与 Bh²Jh/(B0²J0)，故
\[
 e^{-\omega_h}F_h^{\rm fr}\le T_h\le e^{\omega_h}F_h^{\rm fr},\qquad
 |C_h|\le(e^{\omega_h}-1)F_h^{\rm fr}. \tag{TI14}
\]
这个比较保留真实帽，不以未截断 p²/J 替代。ωh 可为∞，此时不声称有限价。B=0 端点直接用 TI11 的 min 差，不用 ratio/log。一般可测系数/资格只给此真实差分，没有统一线性于 |h| 的模量。

对原固定 dm 可将 TI12 乘来源权后 Fubini；若使用空间适应后验，则须先并入 G 的真实 ν² 密度。不同来源的 flow Φh^y 不同，不能由此把原共同 selector 偷换成每个来源独立选择。

## TI10　原接收域、来源边界与 selector 的差分位置

若 G 包含 1_Ereceiver(x)，TI12 第二项保留 1_E(Φh^yx)−1_E(x)。它是准确空间边界差分；没有 perimeter 假设时不简化成 surface area×h。若把 flow 移到来源 β，则必须使用 β 的实际推前差；β∈L1 至多给通常的 L1 连续性，不提供可求和 BV/线性 h 速率。

原 receiver 可能选 L=L(x)、s=s(x)、R=R(x)、j=j(x)。TI2 只比较同一固定 s 的 L 与 e^hL。以实际 L(x) 为起点，flow 后的原尺度为 L(Φh^yx)，其 clock 错配为
\[
 \epsilon_h^y(x)=\log L(\Phi_h^yx)-\log L(x)-h. \tag{TI15}
\]
这一般不为零。必须在 flow 律与实际值间再加完整尺度差
F_{L(Φh x)}(Φh x)−F_{e^hL(x)}(Φh x)，并保留 s/R/j、history、source/窗口或帽的切换。没有这些 selector 的空间正则性，不能把这种差压成一个梯度项，更不能设其为零。若 source-y 的共同 selector 改写后不再共同，还须保留相应整行一致性。

R200 的 shell coarea 可以对有合法迹的原 signed current 面先积分 β，再聚合连续密度；TI3 解释它与负空间 divergence 的精确接缝。但任意L1 β 的 coarea 密度仅a.e.尺度确定，不补齐所有资格 trace/BV。TI12 是无需这些额外正则性的准确替代接口，不是把其误差命名为已付来源预算。

## TI11　有限验证建议及最终边界

数值仅需验证定义明确的辅助族，不重建任意 physical FULL 输入。对有限阶梯 base f≥0，∑w_i a_i=1，取 u=L^n，
\[
 M(u)=\sum_i{w_i\over J}\min\{a_i²/u,(BJ)²u\},\qquad
 u_i=a_i/(BJ).
\]
每段 M=C/u+Du，内部 stationary sqrt(C/D) 是最小值，应计入实际正变差分割；C0或D0分别处理。a_i0 项为0，帽等号连续，不重复计原子。检验 Var+≤B、两端0及 TV=2Var+。纯hard单层可直接核 TI4 的±n及全路径B。另用不同正 Jh/Bh 及任意 G0,Gh 检验 TI12–14，可发现遗漏资格或系数交换；它们只是有限精确算术，不是一般 source/Pi/FIRST 证书。

本文严格证明含硬面的 continuity 与 nonlinear cap transport；完整 transport 中的硬面 secant 取消，但反应/系数/真实权重项保留。固定常数质量的 TI7 确有无维度全路径价，但仅是共同尺度先积分 receiver 的辅助工具。原一般目标仍需要在同一 alpha、同一来源、实际 dx 与 selector 下支付 TI9/TI12 的空间交换和实际原 net flux；本稿没有替 Astra 的主预算证明这些项，也没有把无输入梯度改写成无费用。
