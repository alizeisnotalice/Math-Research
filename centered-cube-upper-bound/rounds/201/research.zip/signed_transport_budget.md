# R201：真实目标核的带权输运价格与原分母补偿

本稿证明一个对真实 J 的截帽输运 score 估计：硬面与连续尺度项合并后，目标核部分按接收几何只有 √(n+|y−v|₂²/b²) 型费用；联合反集中与分数权尾积分，将粗 B² 或 B^{3/2} 来源代价改善为 B a_m 乘明确对数项。随后给出原 A 分母的精确消项。仍未控制原 capture、资格与接收点选择器的全部输运误差，不声称一般根阶闭合。

## 1. 定义和适用范围

固定原窗口 a≤L≤b≤2a、来源 y,v、帽 B>0，写
\[
 p=P_{s,L}(x-y),\quad J=J_v=P_{1,b}(x-v),\quad
 F=\frac{\min(p^2,B^2J^2)}J,\quad X=x-y,\quad d=(v-y)/b.
\tag{ST1}
\]
B 必须对 x 和运行 s,L 固定。原 high-A 层 A≥1−η（固定 0<η<1）可取 B=B₀/W_g(y,v)，B₀=K/[3(1−η)]，W_g=∏C(|y_i−v_i|/b)。此处 W_g 是来源固定下界，不是依接收点终端 g 改变的 w_g。

定义 ℓ(r)=φ′(r)/φ(r)，
\[
 \mathscr S_y(x)=n+X\cdot\nabla\log J_v(x).
\tag{ST2}
\]
本轮 `transport_identity.md` 证明含完整 current 硬面跳的基础分布式
\[
 \partial_{\log L}F+\operatorname{div}_x(XF)
 =\epsilon F\mathscr S_y,\qquad
 \epsilon=\begin{cases}-1&p<BJ,\\1&p>BJ.\end{cases}
\tag{ST3}
\]
帽等号按 Lipschitz 链规则处理，不任意指定单侧导数。ST3 不允许在取 receiver 上的正部或适应尺度上确界以后直接删除散度。

## 2. 偶奇正交给出的真实位移价格

记
\[
 I_{\rm loc}=\int\ell(r)^2\phi(r)dr\le64,\qquad
 V_{\rm sc}=\int(1+r\ell(r))^2\phi(r)dr\le9/4.
\tag{ST4}
\]
|ℓ|≤8 来自 R199 `score_anticoncentration.md` SC2；V_sc≤9/4 来自 R198 `scale_geometry.md` 的 s=1 scale-score 矩，不把两个 Fisher 记号混用。φ 为偶概率密度且指数尾，积分分部给 Eℓ=0、E(1+rℓ)=0。

在 J_v(x)dx 概率下令 r_i=(x_i-v_i)/b，则 r_i 独立同 φ 律，
\[
 \mathscr S_y=\sum_i\{1+r_i\ell(r_i)+d_i\ell(r_i)\}.
\]
1+rℓ 为偶函数，ℓ 为奇函数，二者协方差为零。因此
\[
 \boxed{\mathbb E_J\mathscr S_y^2=nV_{\rm sc}+I_{\rm loc}\|d\|_2^2
 \le V(n,d):=\tfrac94n+64\|d\|_2^2.}
\tag{ST5}
\]
独立性只来自已知乘积 receiver 核 J，不是来源独立性。

由于 0≤F≤B²J，对任意可测原权 G(x)∈[0,1]，包括依赖实际选择器的权，
\[
 \int GF|\mathscr S_y|dx\le B^2\sqrt{V(n,d)}.
\tag{ST6}
\]
ST6 同样适用于任意接收点依赖的 s(x),L(x)；其证明仅用点态 B²J，不需要把这些参数冻结。所有 dx 正上放前均从原接收域开始，扩大至全空间只用于这个非负估计。

## 3. 分数权尾积分：来源幂从 B² 改善到 B a_m

令
\[
 m=\#\{i:|y_i-v_i|\ge3b/4\},\quad h_0=1/16,\quad
 q_m=\min(1,\sqrt{128/(m+1)}),\quad
 a_m=\min(1,2q_m/(1-e^{-h_0})).
\]
已审 R198 对每个固定 s,L 给 ∫Fdx≤Ba_m。这里的目标截断已经由对称帽处理，不能再次把原单侧截断当作等号。

**引理 ST-A（任意分数权）。** 对任意 0≤h≤1 且 E_Jh≤q∈(0,1]，置 ℓ_q=log(2/q)，则
\[
 \mathbb E_J[h|\mathscr S_y|]\le M_{n,d}(q),
\tag{ST7}
\]
\[
 M_{n,d}(q)=q\left[(64\sqrt n+8\sqrt2\|d\|_2)
 \left(\sqrt{\ell_q}+\frac1{2\sqrt{\ell_q}}\right)
 +16(\ell_q+1)\right].
\tag{ST8}
\]
q=0 时左侧为零，定义 M(0)=0。h 可以与全部 score 任意相关。

证明。令 U=Σ(1+r_iℓ(r_i))、Y=Σd_iℓ(r_i)。R199 SC2–3 对 s=1 给 U 的双侧 subgamma 尾，参数 v=2048n,c=16。ℓ 在 φ 律下对称且 |ℓ|≤8；每坐标 E exp(λd_iℓ)≤cosh(8λ|d_i|)≤exp(32λ²d_i²)，故 Y 双侧 subgaussian 参数 v=64||d||₂²。这里没有假设 U 与 Y 独立。

对任一上述尾变量 Z，layer-cake 直接给 E[h|Z|]≤∫₀∞min(q,P(|Z|>z))dz。按 z=√(2vt)+ct、在 t=log(2/q) 切开，得 q{√(2v)(√ℓ_q+1/(2√ℓ_q))+c(ℓ_q+1)}。分别用于 U,Y，再以 |U+Y|≤|U|+|Y|，即得 ST8。证毕。

取 h=F/(B²J)，则 E_Jh≤q=min(1,a_m/B)，结合 ST6 得真正固定参数核价
\[
 \boxed{\int GF|\mathscr S_y|dx
 \le\mathcal K_1(n,d,B):=B^2\min\{\sqrt{V(n,d)},M_{n,d}(\min(1,a_m/B))\}.}
\tag{ST9}
\]
其中 B²q=min(B²,Ba_m)，对数仅为 log(2max(1,B/a_m))。因此这是显式 Ba_m 对数惩罚，不是另一个未知来源矩。无须使用任意来源梯度。

### 软度与尺度选择费用

若 L 固定而先上放为 sup_s F，R198 给 ∫sup_sF≤D_soft Ba_m，D_soft=2√(2n)。若 s 固定但上放全部 L，则取 D_scale=1+2nlog2。若两参数都上放，则取统一
\[
 D_{\rm all}=2\sqrt{2n}(1+2n\log2).
\tag{ST10}
\]
相同证明把 ST9 中 q 换成 q_D=min(1,D a_m/B)，即
\[
 \int\sup_{\text{相应参数}}F|\mathscr S_y|dx
 \le\mathcal K_D:=B^2\min\{\sqrt{V(n,d)},M_{n,d}(q_D)\}.
\tag{ST11}
\]
选择费没有消失：B²q_D=min(B²,DBa_m)。纯 ST6 的 B² 版本虽无需选择费，tiny-W_g 的来源代价仍更大。不能把固定参数 ST9 的 q 无费用于适应选择。

## 4. 原 carrier 下的维数价格

已审 R188 `source_reversibility.md` SR2 明确
\[
 Z_{j,V,y,t}\subset D_y
 =V\cap\{z:\|z-y\|_1\le17na\}
 \cap\{z:\|z-y\|_\infty\le b(5\log n+1/2)\}.
\]
所以对原 Π_t 支持中的 v，
\[
 \|d\|_2^2\le\frac{\|v-y\|_1\|v-y\|_\infty}{b^2}
 \le17n(a/b)(5\log n+1/2).
\tag{ST12}
\]
这将 ST5 的几何价格控制为 C√(n(1+log n))，而不是用 L¹ 位移得到的 O(n log n)。它仍乘 ST9/11 中完整 B、a_m、D 及对数来源权；不把这个核分量价说成全部原来源根价。

## 5. 原 A 分母怎样消去裸维数项

在一个实际 smooth cell 中，假定原 capture 与其余门有相应可微代表、ρ>0，且 L⁺=γL<b。只在这一节作经典微分；没有将 good 或 α 全局授予 BV。写
\[
 P_v=p_v+p_v^+,\quad S_v=P_v+J_v,\quad z_v=J_v/S_v,\quad
 W=\rho_v^2z_v^2 F,\quad \mathcal D=\partial_{\log L}+(x-y)\cdot\nabla_x.
\]
由于两个 current 核以 v 为中心、尺度都与 L 同比变化，
\[
 \mathcal D S_v=-nS_v+J_v\mathscr S_y+(v-y)\cdot\nabla_xP_v.
\tag{ST13}
\]
结合 ST3 和乘积法则，得到
\[
 \boxed{\partial_{\log L}W+\operatorname{div}_x(XW)
 =W\left[(2+\epsilon-2z_v)\mathscr S_y
 -2\frac{(v-y)\cdot\nabla P_v}{S_v}
 +2\frac{\mathcal D\rho_v}{\rho_v}\right].}
\tag{ST14}
\]
其中 |2+ε−2z_v|≤3；未截帽支系数为 1−2z_v，已截帽支为 3−2z_v。原 denominator 并没有留下另一个裸 n(1−s) 项。

高 A≥1−η 时 z_v≥A≥1−η。仅对绝对连续梯度，|∂log p_v|≤L_φ/L、|∂log p_v^+|≤L_φ/L⁺，故
\[
 2\left|\frac{(v-y)\cdot\nabla P_v}{S_v}\right|
 \le2\eta L_\phi\frac{\|v-y\|_1}{L}.
\tag{ST15}
\]
不能把 ST15 当作 target 硬面的分布梯度界。ρ=0 处不写逆 ρ，正确项是 2ρz_v²F·Dρ（在其链法资格内）。

若 L⁺=b 被截住，则 ST13 还多出
\[
 C_+=np_v^++(x-v)\cdot\nabla p_v^+,
\]
ST14 的右侧另有 −2W C_+/S_v；其 current hard-face 部分也要保留。尺度端点 L=b/γ 的切换不能免费删去。

### 必须另保留的实际误差

- target 的 p_v、p_v^+、K₀ 硬面：ST14 只写 ac 部分。跨面需使用实际两侧 denominator/ρ 的有限差分；不能把分布乘积写成任意一侧导数。
- 同 α capture：在 smooth active 区域，
\[
 \mathcal D\rho=(1-\rho)\mathcal D\log a
 -(k/a)\mathcal D\log k
 -(\alpha J/a)(\mathcal D\log\alpha+\mathcal D\log J).
\tag{ST16}
\]
  α=0 时用未除 α 的式子 \(Dρ=(k+αJ)Da/a²−(Dk+J Dα+α DJ)/a\)。实际 αQ_J=Dq−∫Uν 还携带 U 的资格界面、失捕获和恢复，不能由 FIRST 上容量给其带权变差。
- 原 H：乘 H 后须保 W·DH、H 的跳交换和 receiver 域边界。没有光滑/BV 资格时，使用本轮基础稿的精确输运有限差分，不能默认存在有限误差测度。
- 接收点选择器：对 L=L(x)、s=s(x)、R=R(x)，ST14 的散度不能在逐 x 正变差或上确界后消掉。选择图边界/状态交换必须随原函数保留；真实共同选择只允许先聚合来源，不允许先对全 dx 积分再自由交换 sup。

## 6. 实际来源回代和第一处未付款

固定 (ω,V,j,y,t) 后 Π_t 与 x 无关。因而 ST9/11 是对真实目标核 score 分量的正估计，可先对 dx 应用，再按原 β(dy)Π_t(dv)Π_t(du) 积分；bad 槽正上放至概率帽只在此正估计后使用。对 ST14 的 J-score 部分，所得准确来源费用至多
\[
 3\,\mathbb E\sum_{V,j}\int_{I_j}\frac{dt}{t}
 \int\beta_V(dy)\int\Pi_{y,t}(dv)\,
 \mathcal K_D(n,(v-y)/b,B_0/W_g(y,v)).
\tag{ST17}
\]
如果还在辅助 L 路径上积分，另乘逐窗 log(b/a)≤log2；s,L 都固定的单点估计用 D=1；固定 s 后逐个共同 L 核验、再对辅助路径积分也可用 D=1 并支付路径长度。固定 s 但真实 L(x) 适应时至少用 D_scale（或安全 D_all），不能用 D=1。固定 L 的 sup_s 用 D_soft，全参数上确界用 D_all。H、A 可在这项正估计中上放，但它们的导数/有限差分不因此消失。跨 j/time/window 的费用仍是完整求和；只有实际推得 uniform 原行价后才能使用原唯一 j 的资格合并。

ST17 明确保留了归一化 Π_t，并非 ν/e_t；没有用 ν≤β。若仅另有一个已证统一来源权上界 R_*，才可将相应源积分界为 R_* T_* W_β≤R_*T_*W_A；本文没有该上界，尤其 W_g 可极小。

实际原伴随仍需同时支付 ST15、ST16、target/clamp 硬面、H 资格与 selector 输运误差。只有合计给原伴随 C≤B_nW_A 后，才可使用修复后的 E_J≤nW_ν/(2K) 得 Raw≤(32Λ/3)√(nB_n/(2K))W_A。本稿没有把 ST17 单独当作这个 C。特别地，即使 ST17 的所有来源因子都另获常数价，若 companion 仍只有 C=O(√n·polylog(n))W_A，和 n 阶能量作 Cauchy 只给 O(n^{3/4}·polylog(n))W_A；它不是所需 O(√n·polylog(n)) 的原 raw 付款。后者仍需 companion 达到 n^{o(1)} 来源价，或另一项已经证明的联合能量结算。

最早的实质未付项是原共同来源下的带权 capture/资格输运（ST16 及其有限差分）与 selector 散度边界；即使仅考虑已估 J-score，ST17 中的 tiny-W_g 来源权也尚未收费。新可核改进是：真实 J、实际 carrier 与帽的反集中共同给出了 ST9/11 的显式几何价格，并在原 denominator 中消去了额外裸维数项。它不是一般闭合，也不是把未知矩假设为小。
