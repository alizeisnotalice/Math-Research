# R201 independent audit

## 1. Author-before-proof premise screen

Read `task_contract.md` before the new author manuscripts. This section records independent derivation, not acceptance of an unreceived proof. Scope is the common original window and common scalar scale; all source, receiver, selector and qualification costs remain in the original account. Only this audit file is owned by the auditor.

Write \(r=\log L\), \(X=x-y\), \(p=P_{s,L}(x-y)\). The physical dilation identity is
\[
\partial_r p+\operatorname{div}_x(Xp)=0
\]
in distributions, including the moving current hard faces. For fixed positive spatial constants \(B,J\), put \(F=\min(p^2/J,B^2J)\). Its correct transport equation is
\[
\partial_rF+\operatorname{div}_x(XF)=n\sigma F,
\qquad \sigma=\mathbf1_{p>BJ}-\mathbf1_{p<BJ}.
\]
Thus the nonlinear cap is not a conserved density. At a moving hard face, its time singularity uses the exact secant \(\Delta F\), not a chosen derivative \(F_p\Delta p\). The spatial flux has exactly the opposite singularity because the face normal velocity is \(X\cdot n\). These singularities cancel only in the complete transport equation. A separate continuous chain rule across the jump would leave a nonlinear defect; for an uncapped square its pretrace defect is \((\Delta p)^2/J\).

For positive spatial \(C^1\) coefficients independent of \(r\), the reaction is
\[
R_F=n\sigma F-F\mathbf1_{p<BJ}X\cdot\nabla\log J
 +F\mathbf1_{p>BJ}X\cdot\nabla\log(B^2J).
\]
When \(B\) is spatially constant this is \(\sigma F[n+X\cdot\nabla\log J]\). The cap equality is treated by the almost-everywhere Lipschitz chain rule; branch formulas are not asserted to agree at every equality point. A positive-measure equality region has the corresponding almost-everywhere derivative compatibility. Spatial discontinuities of \(B,J\) require their own trace and flux terms.

For a sufficiently regular weight \(G\), multiplication adds \(F(\partial_r+X\cdot\nabla)G\). For BV weights it requires genuine traces and product-jump terms. Mere measurability of the actual \(A^2H\) does not confer BV or authorize multiplication of singular distributions. The receiver boundary, history, cap, \(\alpha\), parameter-clamp and qualification exchanges must all be included. R200 signed aggregation and weighted absolute integrability establish a well-defined integral; by themselves they do not establish its full scale BV.

There is a gradient-free finite-flow identity even for measurable coefficients. Let \(\Phi_h^y x=y+e^h(x-y)\), \(J_h=J(\Phi_h^yx)\), \(B_h=B(\Phi_h^yx)\). Exact physical scaling gives
\[
D_h:=e^{nh}F_{e^hL}(\Phi_h^yx)
=\min(e^{-nh}p^2/J_h,e^{nh}B_h^2J_h).
\]
With \(\widetilde F_h=\min(e^{-nh}p^2/J,e^{nh}B^2J)\), \(G'_h=G_{e^hL}(\Phi_h^yx)\), the exact difference is
\[
G'_hD_h-GF=G(\widetilde F_h-F)
+\widetilde F_h(G'_h-G)+G'_h(D_h-\widetilde F_h).
\]
States must be defined on the flowed receiver points, or consistently zero-extended. Both scales must belong to the chosen legal family. Truncation or absolute integrability is required for signed integration. Fixed \((\omega,V,j,y,t)\) posterior measures can be integrated by Fubini without differentiating the \(L^1\) source density; the flow is centered at each fixed \(y\). This does not remove the second and third differences or prove that the actual selector gives a legal scale family.

## 2. Further candidates independently screened

For spatially constant \(B,J\), normalized base density \(f\), and all scalar scales,
\[
M(r)=\int F_{e^r}(x)\,dx
=B\int f(z)e^{-|\log(f(z)/(BJ))-nr|}\,dz.
\]
Zero-density terms are zero. Each component has positive variation \(Bf(z)\), so \(\operatorname{Var}_+M\le B\) and \(\operatorname{TV}M\le2B\); dominated convergence gives zero limits at both infinite scale endpoints. This is a statement after integrating the receiver, not a bound on \(\int\sup_LF\) or an adaptive \(L(x)\).

For the actual fixed spatial density \(J=P_{1,b}(x-v)\), let \(\ell=\phi'/\phi\), \(U=1+r\ell(r)\), \(d=(v-y)/b\). Exponential tails justify integration by parts. Even/odd parity gives
\[
\mathbb E_JU=\mathbb E_J\ell=\mathbb E_J(U\ell)=0,
\quad
\mathbb E_JS_y^2=nV_{\rm scale}+I_{\rm loc}\|d\|_2^2,
\quad S_y=n+(x-y)\cdot\nabla\log J.
\]
Here \(V_{\rm scale}=\int\phi(1+r\phi'/\phi)^2<9/4\) and \(I_{\rm loc}=\int\phi'^2/\phi\le64\) are different moments. For \(0\le K\le F\le B^2J\),
\[
\int K|S_y|\le B^2\sqrt{nV_{\rm scale}+I_{\rm loc}\|d\|_2^2}.
\]
If the fixed-parameter cap estimate \(\int F\le Ba_m\) applies, Cauchy improves its coefficient to \(\min(B^2,B^{3/2}\sqrt{a_m})\). The carrier estimate \(\|d\|_2^2\le\|d\|_1\|d\|_\infty\) preserves the actual carrier constants. Neither estimate pays the source-dependent \(B^2\), selector, or posterior denominator.

On a smooth active branch with fixed \(B\), \(L_+=\gamma L\), \(z=J/(p_v+p_{+,v}+J)\) and \(W=\rho^2z^2F\), direct differentiation gives
\[
(\partial_r+X\cdot\nabla)W+nW
=W\left[(2+\sigma-2z)S_y
-2\frac{(v-y)\cdot\nabla(p_v+p_{+,v})}{p_v+p_{+,v}+J}
+2\frac{(\partial_r+X\cdot\nabla)\rho}{\rho}\right].
\]
The last term is used only where \(\rho>0\), or written without division as a product containing \(2\rho\). On high \(A\ge1-\eta\), the second term is bounded by \(2\eta L_\phi\|v-y\|_1/L\). Target hard faces, the \(L_+\) clamp, \(\alpha\), and all additional weights remain separate. This is a verified smooth identity, not a whole-path or source payment.

The weighted-tail refinement also passes. For \(h=K/(B^2J)\in[0,1]\) and \(\mathbb E_Jh\le q=\min(1,a_m/B)\), layer cake gives \(\mathbb E h|T|\le\int_0^\infty\min(q,\mathbb P(|T|>t))\,dt\). Thus R199's score event bound applies to this weight. For the independent location sum, \(|\ell|\le8\) and mean zero give the Hoeffding tail \(2\exp[-t^2/(128\|d\|_2^2)]\), and consequently
\[
M_d(q)=q\sqrt{128}\|d\|_2\left[\sqrt{\log(2/q)}+\frac1{2\sqrt{\log(2/q)}}\right].
\]
The location sum and scale-score sum need not be independent: estimate each and add. Use the zero expression when \(d=0\). The coefficient is \(B^2[M_U(q)+M_d(q)]\); a shorthand proportional to \(Ba_m\) with \(\log(B/a_m)\) is restricted to \(B\ge a_m\), not substituted on the \(q=1\) branch.

## 3. Numerical static checkpoint

Read `transport_checks.py`, `score_moments.py`, and the current `numerical_review.md`; did not execute them. The seven transport fixtures retain \(r=L^n\), exact density normalization, \(u=BJr\), zero density, duplicate breakpoint and scalar homogeneity branches. On each segment the mass is \(C/u+Du\); internal minima are enclosed by integer-square-root rational bounds and included in both variation estimates. The independent component peak sum is \(B\), and the finite certificate checks the complete positive variation rather than endpoint-only increases. These are finite constant-coefficient mass examples, not actual spatial weights or selector evidence.

The moment diagnostic uses the correct \(\phi'\), separate \(I_{\rm loc}\) and \(V_{\rm scale}\), and the analytic omitted-tail envelopes \(128e^{1/2-X}\) and \(2e^{1/2-X}(64X^2+144X+145)\). The latter follows by integrating \((1+8r)^2e^{1/2-r}\). Two precisions diagnose quadrature stability; the code correctly disclaims a certified quadrature error. These computations are not the proof of the uniform moment bounds.

Also read complete `weighted_score_checks.py`. The sample formula H+Laplace(sqrt(U)) has the exact required mixture density phi; radial log derivative and its odd extension have the correct signs. The 11 configurations reuse samples within each dimension. The 33 empirical weighted tails include a fractional last sample, so they implement top-q mass rather than a rounded sample count. The two interpolation grids and selected 40-digit comparisons are explicitly finite sensitivity diagnostics, not uniform interpolation certificates. No confidence interval or original FULL input is claimed. The code records observed bound violations rather than certifying the general bound. No necessary revision was found and no numerical script was run by this auditor.

Read `reproduce.py`: it verifies the future manifest's file hashes, runs all three scripts with their actual `--output` interfaces, and compares complete generated JSON bytes. Standard-library and numeric interpreters are distinguished; the numeric interpreter and inherited PYTHONPATH remain explicit environment requirements. Fresh output files are required. This static acceptance does not claim that the final manifest-bound driver has already been run.

## 4. Full author review

Read the complete `transport_identity.md` (224 lines, author version `cd46dc69c88700427910b2055b1a3243d331d5e9c4a37ccaf5d7e65fc9137508`) after the independent screen. TI1–15 agree with the independent derivation. In particular: the weak-form reaction sign is correct; the hard-face secants cancel only in the complete transport; space/scale dependent coefficients use the material derivative; the cap equality is only an almost-everywhere compatibility statement; the constant-coefficient variation estimate is after receiver integration; and the actual soft-J bound preserves its linear dimension cost. TI9–10 retain the real finite coefficient/qualification/domain differences and the spatial selector mismatch. No necessary revision was found. This accepts the stated identities and auxiliary bounds, not an original weighted source payment.

Read complete `signed_transport_budget.md` ST1–17 after the independent screen. The exact even/odd variance, fractional-weight layer-cake tail, \(q_D\) selector cost, carrier conversion, smooth denominator identity, and clamped \(-2WC_+/S_v\) correction are correct. ST16 retains the actual reserve derivative, and ST17 remains an explicit source-weighted score price rather than a companion payment. A companion cost of order \(\sqrt n\) combined with the old order-\(n\) energy only yields order \(n^{3/4}\) raw cost; the manuscript states this accurately. The requested narrow selector clarification was reread in ST10/17: D=1 means s,L fixed, or each common L estimated separately before auxiliary path integration; fixed s with adaptive L(x) pays D_scale, fixed L with soft supremum pays D_soft, and both pay D_all. Final author version `5ac2169b5f94a093f432fdc256ac675d81517eed2e74e52c417f95201903e364` passes within this scope.

## 5. Final integration and freeze

Read the complete 753-line `proof.tex.txt`, the final report, parent checkpoint, numerical review, and reproducer. The detailed TeX agrees with both accepted author manuscripts, including the signed reaction, exact finite flow, even/odd moments, fractional tails, D_scale qualification, clamped denominator correction, and actual source price. No necessary transcription correction was found. The report's final process-status sentence was reread. The current JSON metadata confirms seven exact fixtures, two moment-precision rows, and eleven MC cases with thirty-three tail comparisons. Parent/author replay statements are recorded as their execution evidence; this auditor performed static review and did not rerun experiments or compile TeX. The manifest-bound full driver is still a later parent action, not prematurely certified here.

Accepted scope: exact physical transport and finite-flow identities; constant-coefficient receiver-mass variation; fixed-reference score and capped-mass estimates with explicit parameter and source costs; smooth original-denominator identity with all outstanding jumps and qualification terms retained. No general original weighted scale budget or new raw root-order payment is certified. The earliest unresolved terms are weighted capture/qualification transport and actual selector exchanges; tiny-W_g source cost remains even for the estimated score component. One selector-wording correction was requested and verified. All required review work for this round is complete, and this audit is frozen after the hash binding below. No self-hash or future manifest is included.

## 6. Final SHA-256 binding

| File | SHA-256 |
|---|---|
| numerical_review.md | `8fc6408ae58ea5f05c79940215ab2f88b5ab2a3a7caaf3a21c73de0350f58758` |
| parent_checkpoint.md | `d9d4ae0944f0ddbe8b7e97e37ab42b4de895e2c208b3b572ab5a7e994f8dfee4` |
| proof.tex.txt | `afe45ce2a524874dce27c6478d929de7046943e4343b855f8a9ed19c2dca9f79` |
| report.md | `db22b54d12aed315d10e5009dadad23eeebaa300ea38f592294ef23b3a77aa00` |
| reproduce.py | `2286f5da1075d8b7e36e4ada21d447c32b353fff384781e69b5486d5724893d1` |
| score_moments.json | `a7962bb4890012917755a457cab68f4f49274e663fd23a29a0e4f948b294afbb` |
| score_moments.py | `1afe10bab81595724caafa59473ecdea16faeaa9f3d3f4af1607b6266b0d05eb` |
| signed_transport_budget.md | `5ac2169b5f94a093f432fdc256ac675d81517eed2e74e52c417f95201903e364` |
| task_contract.md | `f7222071cc3f4baa2a93b158823810bc1ec22fed9985c0505bbc1e0d02bfc4c1` |
| transport_checks.json | `693aa3ae6f20dad8efca95b7f8a31280452b1c2275b5681d9a17df2eab08c4fe` |
| transport_checks.py | `0cc0e0d691e09b3b978a6a1e728998a8e6001f999e3b2601f637dc51c1d80818` |
| transport_identity.md | `cd46dc69c88700427910b2055b1a3243d331d5e9c4a37ccaf5d7e65fc9137508` |
| weighted_score_checks.json | `3d011d5ed9b67a219ab0d53187b515d6bf181f7753ad1b9de29045acaa30b8e7` |
| weighted_score_checks.py | `64bcce5596868727342e51dbe55212e183f9ebbe7e18b42664ea4759484ae42d` |
