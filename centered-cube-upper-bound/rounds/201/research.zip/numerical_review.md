# R201 fixed-coefficient transport mass checks

The author confirmed the fixed-B,J interface before execution. Seven finite normalized piecewise-constant densities passed using Fraction and integer square root only. There are three initial fixtures (uniform, two equal humps with a rational interior minimum, and an irrational interior minimum), two stress fixtures (duplicate breakpoints with a zero-density cell, and four density levels), and two expanded fixtures (densities from 2^-20 to 2^20, and B,J homogeneity).

The code retains r=L^n, so the true receiver volume dilation is included. It computes M(r)=sum w_i min(a_i^2/r,(BJ)^2 r)/J, with sum w_i a_i=1, and uses u=BJr to remove coefficient scaling exactly. At every breakpoint it independently checks the direct mass, normalized B sum w_i min(a_i^2/u,u), and likelihood form B sum w_i a_i min(a_i/u,u/a_i). Zero-density terms are defined as zero without division. B and J are constant scalars throughout this task.

Positive distinct density levels generate the breakpoints. Equal density levels are merged, zero-density cells do not add spurious breakpoints, and the cap profile is continuous at a breakpoint; it has no jump variation atom there. In each open segment the normalized mass is C/u+Du. The first segment C=0 and last segment D=0 are handled separately. Otherwise Fraction comparisons of C with D times squared endpoints locate a possible strict interior minimum. Equality puts the stationary point at an existing endpoint, without counting it twice.

Internal roots are essential. sqrt(C/D) and sqrt(CD) are enclosed by dyadic rationals using integer isqrt at 128 bits; exact squared comparisons verify each enclosure. The internal mass is 2sqrt(CD). Endpoint values and these minimum enclosures give rational positive-variation and total-variation bounds for the whole interval (0,infinity). No floating root or floating total variation enters a certificate. The two endpoint limits are zero, and the computed total-variation enclosure equals twice the positive-variation enclosure exactly. Independently, individual component peak masses sum exactly to B, and all actual positive-variation upper bounds are <=B, total-variation upper bounds <=2B.

The equal-hump fixture a=(1/4,4),w=(2,1/8),B=J=1 has actual positive variation 13/16. A calculation that ignores the internal minimum gives only 17/32. The wide-range fixture has positive variation enclosed near 0.99862036 B, while the same incorrect shortcut gives about 0.50000048 B. These decimals are explanatory displays; the JSON rational intervals are the certificate. The uniform fixture attains B exactly. The B=7/3,J=5/7 fixture reproduces the equal-hump normalized variation and scales both variation intervals by B exactly.

This checks a finite fixed-coefficient transport auxiliary, not a conserved capped density or the original joint positive traffic. It does not cover spatially varying J, original A or H, adaptive L(x), actual source/history/FIRST or FULL eligibility. No extra selector or source cost has been paid, and no general root-scale bound or dimension order is inferred from the fixtures.

Reproduce with standard-library Python, no installation:

```sh
python3 transport_checks.py --output transport_checks.json
```

Copy the script and its local task_contract.md to relocate it; the JSON binds the latter using a portable filename hash. A temporary-directory copy was independently executed and complete JSON byte equality passed. Only the three assigned numerical files were written. L03's exact rational residual discipline is used; no floating interval API or external theorem is invoked.

## Additional weighted-score Monte Carlo diagnostics

The parent authorized a separate finite test of S=sum_i[1+X_i ell(X_i)]+sum_i d_i ell(X_i), ell=phi'/phi. The sampler was checked first: if U is uniform[0,1], T=sqrt(U) has density 2t, and mixing Laplace(T) gives integral_0^1 exp(-abs(x)/t)dt=w(x). Adding an independent uniform[-1/2,1/2] variable produces phi=h*w. Coordinates and samples use the standard PCG64 pseudorandom generator. This is a sampling implementation of the stated density, not an original source/history or FULL construction.

The default Python 3.14 had neither NumPy nor SciPy. The existing bundled Python 3.12 has NumPy 2.3.5. An existing SciPy 1.15.3 tree was found, but its public special import fails in an unrelated PROPACK extension; it was not modified, repaired, or used. The approved alternative uses NumPy and the existing mpmath 1.3.0. The source has ordinary imports and no absolute machine paths.

Each n=1,4,16,64 has 20003 samples, with explicit PCG64 seed 20261016+n and a SHA of the sampled float64 array. The odd signed ell is interpolated from its negative radial log derivative, evaluated using the actual E3/E2 formulas. Actual sample radii are scanned before table construction; the largest radius is about 10.674432. The coarse table has 1024 Chebyshev core intervals and 2048 quadratic exterior intervals, both dense at 1/2. A second table doubles both counts. Grid formulas, counts and hashes are recorded. The table domain covers every observed sample, so no extrapolation is used.

The interpolation is an explicit approximation, not an exact evaluation of ell at every sample. Independent 40-digit mpmath evaluations at 256 selected actual radii plus seam-neighbor/control points give maximum coarse/fine discrepancies about 3.09e-6 and 7.18e-7. Recomputing selected sample scores on the fine table gives maximum change about 3.39e-5. These are finite diagnostics, not a uniform interpolation error certificate or a certified bias bound.

There are 11 cases: n=1 uses zero and uniform displacement; n=4,16,64 additionally compare uniform d_i=1 with sparse d_1=sqrt(n), other entries zero, so the latter two share exactly the same l2 norm. Same-n configurations reuse the same samples and are not independent experiments. Each case reports empirical score mean, sample variance, and top-q absolute-score mass for q=1,1/10,1/100, totaling 33 comparisons. Source-coordinate means/second moments and scale-score mean/variance are also retained as empirical sampler controls; no confidence acceptance criterion is attached to them.

For each q the sorted absolute scores are summed with normalization 1/N, not divided by tail count. The last sample is fractionally included to attain qN exactly: for N=20003 the q=.1 and .01 cases include fractions 3/10 and 3/100. Thus this is empirical weighted mass, not a conditional tail mean. The scalar comparison uses the supplied M=q[(64sqrt(n)+8sqrt(2)||d||2)(sqrt(log(2/q))+1/(2sqrt(log(2/q))))+16(log(2/q)+1)]. No asymptotic or dimensional fit is performed.

No observed comparison exceeds M; the largest empirical/M ratio is about 0.02276641. This is finite Monte Carlo evidence only. There are no confidence intervals, concentration correction for empirical tail selection, statistical certification, or uniform/general theorem conclusion. The loose observed comparisons do not pay the original variable-coefficient budget.

Actual local reproduction command:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 weighted_score_checks.py --output weighted_score_checks.json
```

Any suitable Python with the recorded NumPy/mpmath versions can import the script normally; a unified driver may select this interpreter with --numeric-python. JSON omits timing and absolute execution paths. A fresh isolated-directory copy of script and contract repeated the fixed-seed run; the full JSON matched byte-for-byte, including sample and table hashes. The run takes about one second locally. The previously frozen transport_checks.py/json were not changed; only the separately assigned weighted-score script/JSON and this appended note were added.
