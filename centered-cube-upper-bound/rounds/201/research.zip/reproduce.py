#!/usr/bin/env python3
"""Hash verification and finite numerical replay; not a proof checker."""
import argparse,hashlib,json,subprocess,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--verify-only',action='store_true')
p.add_argument('--output-dir',type=Path)
p.add_argument('--numeric-python',default=sys.executable,help='Python with numpy and mpmath')
a=p.parse_args()
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest),'file hashes',flush=True)
if not a.verify_only:
 if a.output_dir is None:p.error('--output-dir required')
 a.output_dir.mkdir(parents=True,exist_ok=True)
 for script,exe in [('transport_checks.py',sys.executable),('score_moments.py',a.numeric_python),('weighted_score_checks.py',a.numeric_python)]:
  name=Path(script).with_suffix('.json').name;out=a.output_dir/name
  if out.exists():p.error('Use fresh output paths: '+str(out))
  subprocess.run([exe,str(ROOT/script),'--output',str(out)],check=True,env=os.environ.copy())
  assert out.read_bytes()==(ROOT/name).read_bytes(),name+' differs; inspect environment and numerical results'
  print(name,'complete JSON byte-identical',flush=True)
