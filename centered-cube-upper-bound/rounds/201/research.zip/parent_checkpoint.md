# R201 主代理计算检查点（未完成轮次）

2026-10-16。基线R200已推送。此文件记录实际进展，不宣称全轮独审或一般上界完成。

主要候选：设真实参考密度J_v=b^-n∏φ((x_i-v_i)/b)，φ为原偶的一维密度；r=(x-v)/b,d=(v-y)/b, ℓ=φ'/φ,U=1+rℓ。在J下，若相应边界项消失且二阶矩有限，则EU=Eℓ=0，偶奇性给E(Uℓ)=0，独立坐标给

E_J[n+(x-y)·∇logJ_v]^2=n Eφ U²+||d||₂² Eφℓ²。

由F≤B²J及Cauchy得到 ∫F|n+(x-y)·∇logJ|dx≤B²√(n Vφ+Iφ||d||₂²)。此处B必须相对x常数。将其接入完整输运方程、核实原来源对carrier条件和真实B²费用由Astra负责；不能用全空间signed积分代替点态selector的正变差。来源位移二范数的改善不消除B²权重、H/A material derivative和所有资格费用。

实际运行：PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 score_moments.py --output score_moments.json（在本目录）。25/40位mpmath分段求积均完成，Iφ约1.61686148001522308418409674，Vφ约0.99016508953918365325865304。两精度差小于1e-20，有限截尾X=80。

解析尾：I尾≤128 exp(1/2-X)，V尾≤2 exp(1/2-X)(64X²+144X+145)，由|ℓ|≤8和φ≤exp(1/2-r)积分得到。这不认证浮点求积误差；数值不是一般常数证明，更非原FULL证书。严格推导拟沿用已证I≤64、V≤9/4，并由独审核其出处和范围。

已分配且尚未最终核验：Astra原加权signed transport预算，Sol基础分布/有限差分恒等式，Sol独立审核，Sol精确帽质量路径数值。全轮尚待交付、审核、详细LaTeX整合、总复现和单轮提交。不得将此检查点宣称GitHub已同步。

## 本轮继续：分数权尾估计

独审已确认：h=F/(B²J)∈[0,1]且∫hJ≤q=min(1,a_m/B)。Layercake给∫h|T|J≤∫₀∞min(q,P_J(|T|>u))du，不需要h与T独立。分别对scale score之和与location score之和应用尾界，无需两和独立。令ellq=log(2/q)，候选显式界为

∫F|S_y|dx≤B²q[(64√n+8√2||d||₂)(√ellq+1/(2√ellq))+16(ellq+1)]。

系数B²q=min(B²,Ba_m)，保留q=1支及所有真实来源权重。完整证明与原权重回代由Astra责任稿提供；命题筛查通过不等于最终稿审核通过。

注意原raw回代：若新√n价仅充当companion并与E_J≤nW_A/(2K)做Cauchy，则仍可能给n^(3/4)。主目标需要companion为n^o(1)或证明更强联合结算；核级根阶本身不认证原弱型根阶。

主代理本机另重跑transport_checks.py至/tmp/r201_parent_transport_replay.json，7例PASS，与保存JSON cmp逐字节一致。等待新增weighted-score数值和数学稿全文。

最终交付阶段更新：两责任数学稿全文独审通过，分数权尾估计纳入ST7–11，Dscale量词已修正。新增MC已完成且作者隔离重放一致。此前“等待”句记录当时检查点，不是最终状态；最终复现以归档README实际记录为准。
