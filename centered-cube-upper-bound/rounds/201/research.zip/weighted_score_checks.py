#!/usr/bin/env python3
"""Finite Monte Carlo weighted scale/shift scores with explicit interpolation."""
import argparse,hashlib,json,math,time
from fractions import Fraction as F
from pathlib import Path
import numpy as np
import mpmath as mp
HERE=Path(__file__).resolve().parent
N_SAMPLES=20003
BASE_SEED=20261016


def exact_log_derivative(radius,dps):
    with mp.workdps(dps):
        r=mp.mpf(float(radius));half=mp.mpf('.5')
        phi=1-mp.expint(3,half+r)-mp.expint(3,half-r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
        derivative=mp.expint(2,r+half)-mp.expint(2,abs(r-half))
        assert phi>0
        return float(derivative/phi)


def make_grid(max_radius,core_intervals,outer_intervals):
    # Chebyshev core points cluster at zero and at the phi seam. Exterior
    # quadratic spacing clusters at the same seam, then covers actual samples.
    core=.25*(1-np.cos(np.linspace(0,math.pi,core_intervals+1)))
    outer=.5+(max_radius-.5)*np.linspace(0,1,outer_intervals+1)**2
    grid=np.unique(np.concatenate((core,outer)))
    grid[0]=0.;grid[-1]=max_radius
    assert np.all(np.diff(grid)>0) and np.any(grid==.5)
    values=np.array([exact_log_derivative(x,25) for x in grid],dtype=np.float64)
    return grid,values


def sampled_sources():
    sources={}
    for n in (1,4,16,64):
        seed=BASE_SEED+n
        rng=np.random.Generator(np.random.PCG64(seed))
        h=rng.uniform(-.5,.5,size=(N_SAMPLES,n))
        t=np.sqrt(rng.random(size=(N_SAMPLES,n)))
        w=rng.laplace(loc=0.,scale=t,size=(N_SAMPLES,n))
        x=h+w
        assert np.all(np.isfinite(x))
        sources[n]=(x,seed,hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()).hexdigest())
    return sources


def tail_value(abs_scores,q):
    ordered=np.sort(abs_scores)[::-1]
    target=q*len(ordered);whole=target.numerator//target.denominator;fraction=target-whole
    weighted=float(np.sum(ordered[:whole],dtype=np.float64))
    if fraction:weighted+=float(fraction)*float(ordered[whole])
    weighted/=len(ordered)
    assert F(whole)+fraction==q*len(ordered)
    threshold=ordered[whole] if fraction else ordered[whole-1]
    return weighted,whole,fraction,float(threshold)


def run():
    sources=sampled_sources()
    max_radius=max(float(np.max(np.abs(item[0]))) for item in sources.values())
    grid,values=make_grid(max_radius,1024,2048)
    fine_grid,fine_values=make_grid(max_radius,2048,4096)
    largest=np.abs(sources[64][0]).ravel()
    indices=np.linspace(0,len(largest)-1,256,dtype=int)
    points=list(largest[indices])
    points += [0.,.5,max_radius,.5-1e-8,.5+1e-8]
    points += [float((grid[i]+grid[i+1])/2) for i in list(range(1016,1024))+list(range(1024,1032))]
    errors=[]
    for x in points:
        reference=exact_log_derivative(x,40)
        coarse=float(np.interp(x,grid,values));fine=float(np.interp(x,fine_grid,fine_values))
        errors.append({'radius':float(x),'mpmath_40dps':reference,'coarse':coarse,'fine':fine,
            'coarse_absolute_error':abs(coarse-reference),'fine_absolute_error':abs(fine-reference)})
    rows=[];source_rows=[]
    for n,(x,seed,digest) in sources.items():
        radius=np.abs(x)
        ell=np.sign(x)*np.interp(radius,grid,values)
        scale_score=np.sum(1+x*ell,axis=1)
        assert np.all(np.isfinite(ell))
        source_rows.append({'n':n,'seed':seed,'sample_sha256_little_endian_float64':digest,
            'maximum_abs_coordinate':float(np.max(radius)),'coordinate_mean':float(np.mean(x)),
            'coordinate_second_moment':float(np.mean(x*x)),'theoretical_coordinate_second_moment':13/12,
            'scale_score_mean':float(np.mean(scale_score)),'scale_score_sample_variance_ddof1':float(np.var(scale_score,ddof=1))})
        configurations=[('zero',np.zeros(n)),('uniform',np.ones(n))]
        if n>1:
            sparse=np.zeros(n);sparse[0]=math.sqrt(n);configurations.append(('sparse_same_l2',sparse))
        for label,d in configurations:
            score=scale_score+np.sum(ell*d,axis=1)
            l2=float(np.sqrt(np.sum(d*d)))
            tail_rows=[]
            for q in (F(1),F(1,10),F(1,100)):
                empirical,whole,fraction,threshold=tail_value(np.abs(score),q)
                qf=float(q);L=math.log(2/qf)
                bound=qf*((64*math.sqrt(n)+8*math.sqrt(2)*l2)*(math.sqrt(L)+1/(2*math.sqrt(L)))+16*(L+1))
                tail_rows.append({'q':str(q),'whole_tail_samples':whole,'fractional_last_sample':str(fraction),
                    'tail_threshold_abs_score':threshold,'empirical_weighted_absolute_score':empirical,
                    'theoretical_bound_scalar':bound,'empirical_over_bound':empirical/bound,
                    'observed_at_or_below_bound':empirical<=bound})
            # Same actual sample subset, evaluated on the expanded interpolation
            # grid, gives an explicit finite sensitivity diagnostic.
            selected=np.linspace(0,N_SAMPLES-1,256,dtype=int)
            selected_x=x[selected]
            fine_ell=np.sign(selected_x)*np.interp(np.abs(selected_x),fine_grid,fine_values)
            fine_score=np.sum(1+selected_x*fine_ell,axis=1)+np.sum(fine_ell*d,axis=1)
            rows.append({'stage':'initial' if n==1 else ('stress' if n==4 else 'expanded'),
                'n':n,'displacement_label':label,'d':d.tolist(),'d_l2':l2,'empirical_score_mean':float(np.mean(score)),
                'empirical_score_sample_variance_ddof1':float(np.var(score,ddof=1)),
                'empirical_absolute_score_mean':float(np.mean(np.abs(score))),
                'expanded_grid_selected_sample_count':len(selected),
                'max_selected_score_change_on_expanded_grid':float(np.max(np.abs(fine_score-score[selected]))),
                'tails':tail_rows})
    return {'schema':'r201_weighted_score_mc_v1','status':'COMPLETED_FINITE_MC',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'numpy_version':np.__version__,'mpmath_version':mp.__version__,
            'numpy_entry_sha256':hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),
            'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest(),
            'scipy':'not used; existing full special import fails in unrelated PROPACK extension'},
        'sampling':{'samples_per_n':N_SAMPLES,'generator':'numpy.random.PCG64','base_seed':BASE_SEED,
            'formula':'X=H+Laplace(T), H uniform[-1/2,1/2], T=sqrt(U), U uniform[0,1], independent',
            'mixture_verification':'T density 2t times Laplace density exp(-abs(x)/t)/(2t) integrates to w(x)=integral_0^1 exp(-abs(x)/t)dt; H convolution gives phi'},
        'score_formula':'S=sum_i(1+X_i ell(X_i))+sum_i d_i ell(X_i), ell=phi_prime/phi',
        'theoretical_formula':'q[(64sqrt(n)+8sqrt(2)||d||2)(sqrt(L)+1/(2sqrt(L)))+16(L+1)], L=log(2/q)',
        'interpolation':{'method':'linear interpolation of signed log derivative via radial grid; not exact ell evaluations per sample',
            'grid_dps':25,'validation_dps':40,'actual_max_sample_radius':max_radius,'coarse_core_intervals':1024,'coarse_outer_intervals':2048,
            'fine_core_intervals':2048,'fine_outer_intervals':4096,'coarse_node_count':len(grid),'fine_node_count':len(fine_grid),
            'grid_rule':'core .25(1-cos(theta)), theta uniform[0,pi]; outer .5+(Rmax-.5)t^2, t uniform[0,1]',
            'coarse_grid_sha256':hashlib.sha256(np.asarray(grid,dtype='<f8').tobytes()).hexdigest(),
            'coarse_values_sha256':hashlib.sha256(np.asarray(values,dtype='<f8').tobytes()).hexdigest(),
            'max_coarse_validation_error':max(r['coarse_absolute_error'] for r in errors),
            'max_fine_validation_error':max(r['fine_absolute_error'] for r in errors),'validation_points':errors},
        'source_sample_controls':source_rows,'statistical_certification':False,'confidence_intervals':None,'case_count':len(rows),'tail_comparison_count':sum(len(r['tails']) for r in rows),'cases':rows,
        'summary':{'observed_bound_violations':sum(not t['observed_at_or_below_bound'] for r in rows for t in r['tails']),
            'maximum_empirical_over_bound':max(t['empirical_over_bound'] for r in rows for t in r['tails'])},
        'limitations':['Finite Monte Carlo with no confidence interval or statistical certification; observed comparisons do not prove the theoretical bound.',
            'Scores use a disclosed numerical interpolation approximation; finite validation and expanded-grid sensitivity are not a uniform interpolation error certificate.',
            'Identical samples are reused across same-n displacements for comparison, so cases are not independent experiments.',
            'No original reciprocal/good/alpha/history/FIRST/FULL input is constructed.',
            'No asymptotic or dimension-order fit, optimization over d, or general uniform conclusion.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'weighted_score_checks.json');args=ap.parse_args()
    t=time.monotonic();r=run();args.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'cases':r['case_count'],'tail_comparisons':r['tail_comparison_count'],'summary':r['summary'],'seconds':round(time.monotonic()-t,3)},sort_keys=True))
