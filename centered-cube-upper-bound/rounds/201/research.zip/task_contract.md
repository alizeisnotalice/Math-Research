# R201 共同来源的尺度输运与净通量

基线5bc7bc91cc5dd5cb32e57f30dc167c68ac6aba9d；R200已独审、重放并推送。一般目标仍未完成。上一轮属于进展，本轮不是重新归约或反例排除。

准确主对象：同一原window、ω,V,j,t及共同s,R的 E_x(L)=∫β(dy)∫Π_y,t² H(x,L,y,u,v) A(x,L,v)² F(x,L,y,v)，F=min(p_y²,(BJ_v)²)/J_v。保持同一个actual α以及其失捕获、恢复和完整资格交换。最终需要此对象及真实选择器费用的一般根阶预算。

主策略：把尺度连续负项与来源硬面统一为带符号输运量，先聚合共同来源，后取正部。只导出换积分顺序、未付款误差改名、固定系数核结论，都不算主预算完成。要明确哪项实际维度价格改善及原对象能否适用。

允许已审工具：R198正soft混合及固定s尺度BV；R199精确帽面、连续score和同α补偿；R200完整二次净面、ramp恢复和共同shell接口，全部保持原适用范围。文件在对应Desktop/T/output/centered_cube_round*_20261016_final_checkpoint。只读必要片段。

必须保留：真实Lebesgue dx、原β和ν及Π，全部J/B/A/H依赖，初末态、资格入口和history/FIRST、适应R、soft选择、j/time/window。FIRST及reserve是上容量；不能当补偿下界。good无自动BV，任意L1来源无梯度控制；截帽非线性不是质量守恒密度。固定B,J的输运只是辅助，不能替原一般结论。

分工：Astra raw_budget负责signed_transport_budget.md原加权预算；Sol exact_certificate负责transport_identity.md基础物理分布恒等式及变系数误差；Sol audit负责audit.md先独筛再读作者；父负责合同、主要综合、计算任务设计和最终记录。数值任务在精确公式确定后安排，按初探、端点/硬面压力、扩大参数三阶段实际运行，有限证据不认证一般阶数。

所有Agent不独占仓库，不改别人文件，不git/spawn，不自行扩展。交付后等待。完成轮次后详细LaTeX、复现材料与独审紧凑归档，外部备份、逐轮提交推送，不编译PDF。没有实际模型扣额数据，不猜成本。
