"""Finite high-precision diagnostics, not interval certificates."""
import json, argparse
import mpmath as mp
p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
rows=[]
for dps in (25,40):
 mp.mp.dps=dps; h=mp.mpf('.5'); X=mp.mpf(80)
 def phi(r): return 1-mp.expint(3,h+r)-mp.expint(3,h-r) if r<=h else mp.expint(3,r-h)-mp.expint(3,r+h)
 def dp(r): return mp.expint(2,r+h)-mp.expint(2,abs(r-h))
 cuts=[0,h,1,2,4,8,16,32,64,X]
 I=2*mp.quad(lambda r:dp(r)**2/phi(r),cuts)
 V=2*mp.quad(lambda r:(1+r*dp(r)/phi(r))**2*phi(r),cuts)
 mean=2*mp.quad(lambda r:phi(r)+r*dp(r),cuts)
 # Analytic tail envelopes from |phi'/phi|<=8, phi<=exp(1/2-r).
 ti=128*mp.exp(h-X)
 tv=2*mp.exp(h-X)*(64*X**2+144*X+145)
 assert I<64 and V<mp.mpf(9)/4 and abs(mean)<mp.mpf('1e-20')
 rows.append({k:mp.nstr(v,dps+5) for k,v in dict(I=I,V=V,mean_U=mean,tail_I_bound=ti,tail_V_bound=tv).items()}|{'dps':dps,'cutoff':80})
assert abs(mp.mpf(rows[0]['I'])-mp.mpf(rows[1]['I']))<mp.mpf('1e-20')
assert abs(mp.mpf(rows[0]['V'])-mp.mpf(rows[1]['V']))<mp.mpf('1e-20')
with open(a.output,'w') as f: json.dump({'scope':'floating quadrature diagnostics; analytic tail only; no certified quadrature error','rows':rows},f,indent=2);f.write('\n')
print('PASS two precision moment diagnostics')
