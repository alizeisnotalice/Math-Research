#!/usr/bin/env python3
"""Rationally enclosed mass variation for finite constant-coefficient dilation."""
import argparse
from fractions import Fraction as F
import hashlib,json,math
from pathlib import Path
HERE=Path(__file__).resolve().parent
BITS=128


def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def sqrt_bounds(x):
    assert x>=0
    denominator=1<<BITS
    floor=math.isqrt((x.numerator<<(2*BITS))//x.denominator)
    lower=F(floor,denominator)
    upper=lower if lower*lower==x else F(floor+1,denominator)
    assert lower*lower<=x<=upper*upper
    return lower,upper


def check(stage,name,aa,ww,B=1,J=1):
    a=list(map(F,aa));w=list(map(F,ww));B,J=map(F,(B,J));cap=B*J
    assert B>0 and J>0 and all(x>=0 for x in a+w)
    assert sum((x*y for x,y in zip(a,w)),F(0))==1
    breaks=sorted({x for x,y in zip(a,w) if x>0 and y>0})
    def mass(u):return sum((y*min(x*x/u,u) for x,y in zip(a,w)),F(0))
    # u=cap*r makes coefficient homogeneity exact, not a floating comparison.
    for u in breaks:
        r=u/cap
        physical=sum((y*min(x*x/r,cap*cap*r)/J for x,y in zip(a,w)),F(0))
        likelihood=B*sum((y*x*min(x/u,u/x) for x,y in zip(a,w) if x>0),F(0))
        assert physical==B*mass(u)==likelihood
    pvlo=pvhi=tvlo=tvhi=naive=F(0);segments=[];interior=0
    for index in range(len(breaks)+1):
        lo=F(0) if index==0 else breaks[index-1]
        hi=breaks[index] if index<len(breaks) else None
        collapsed=[i for i in range(len(a)) if a[i]<=lo]
        C=sum((w[i]*a[i]*a[i] for i in collapsed),F(0))
        D=sum((w[i] for i in range(len(a)) if a[i]>lo),F(0))
        left=F(0) if lo==0 else mass(lo)
        right=F(0) if hi is None else mass(hi)
        record={'u_left':lo,'u_right':hi,'C_normalized':C,'D_normalized':D,
            'C_physical':C/J,'D_physical':cap*cap*D/J,'mass_left':B*left,'mass_right':B*right}
        if C==0:
            assert right>=left
            pvl=pvu=right-left;tvl=tvu=right-left;branch='increasing'
        elif D==0:
            assert left>=right
            pvl=pvu=F(0);tvl=tvu=left-right;branch='decreasing'
        elif C<=D*lo*lo:
            assert right>=left
            pvl=pvu=right-left;tvl=tvu=right-left;branch='increasing'
        elif hi is not None and C>=D*hi*hi:
            assert left>=right
            pvl=pvu=F(0);tvl=tvu=left-right;branch='decreasing'
        else:
            assert hi is not None and D*lo*lo<C<D*hi*hi
            rootlo,roothi=sqrt_bounds(C/D)
            value_lo,value_hi=sqrt_bounds(C*D);value_lo*=2;value_hi*=2
            pvl,pvu=right-value_hi,right-value_lo
            tvl,tvu=left+right-2*value_hi,left+right-2*value_lo
            assert pvl>=0 and tvl>=0
            interior+=1;branch='interior-minimum'
            record.update({'critical_u_interval':[rootlo,roothi],'critical_r_interval':[rootlo/cap,roothi/cap],
                'minimum_mass_interval':[B*value_lo,B*value_hi]})
        pvlo+=pvl;pvhi+=pvu;tvlo+=tvl;tvhi+=tvu
        naive+=max(F(0),right-left)
        record.update({'branch':branch,'positive_variation_interval':[B*pvl,B*pvu],'total_variation_interval':[B*tvl,B*tvu]})
        segments.append(record)
    assert tvlo==2*pvlo and tvhi==2*pvhi
    assert 0<=pvlo<=pvhi<=1 and 0<=tvlo<=tvhi<=2
    component_peaks=[B*x*y for x,y in zip(a,w)]
    assert sum(component_peaks,F(0))==B
    if name=='equal_humps_internal_minimum':
        assert pvlo==pvhi==F(13,16) and naive==F(17,32)
    return {'stage':stage,'name':name,'inputs':{'density':a,'cell_volume':w,'B':B,'J':J},
        'r_breakpoints':[x/cap for x in breaks],'u_breakpoints':breaks,'segments':segments,
        'interior_minimum_count':interior,'positive_variation_interval':[B*pvlo,B*pvhi],
        'total_variation_interval':[B*tvlo,B*tvhi],'component_positive_variation_sum':sum(component_peaks,F(0)),
        'component_peak_masses':component_peaks,'incorrect_breakpoint_only_positive_variation':B*naive,
        'interior_minima_strictly_improve_lower_bound_over_naive':pvlo>naive,'status':'PASS'}


def run():
    dual_a=['1/4',4];dual_w=[2,'1/8']
    rows=[
        check('initial','uniform',[1],[1]),
        check('initial','equal_humps_internal_minimum',dual_a,dual_w),
        check('initial','irrational_internal_minimum',['1/2',2],['1/2','3/8']),
        check('stress','duplicate_breakpoints_zero_density',[1,1,2,0],['1/4','1/4','1/4',5]),
        check('stress','four_density_levels',['1/16','1/2',2,16],[4,'1/2','1/8','1/64']),
        check('expanded','wide_dynamic_range',['1/1048576',1,1048576],[262144,'1/2','1/4194304']),
        check('expanded','B_J_homogeneity',dual_a,dual_w,'7/3','5/7'),
    ]
    base,scaled=rows[1],rows[-1];factor=F(7,3)
    assert scaled['positive_variation_interval']==[factor*x for x in base['positive_variation_interval']]
    assert scaled['total_variation_interval']==[factor*x for x in base['total_variation_interval']]
    return {'schema':'r201_transport_mass_v1','arithmetic':'Fraction and integer isqrt; no floating roots',
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'formulas':{'mass':'M(r)=sum w_i min(a_i^2/r,(BJ)^2 r)/J','normalization':'sum w_i a_i=1',
            'normalized_variable':'u=BJ*r, M=B sum w_i min(a_i^2/u,u)',
            'likelihood_form':'M=B sum w_i a_i min(a_i/u,u/a_i), zero-density terms defined as zero',
            'segment':'C/u+D*u','critical_minimum':'u=sqrt(C/D), mass/B=2sqrt(CD)',
            'global_bounds':'positive variation <=B, total variation <=2B; M(0+)=M(infinity)=0'},
        'sqrt_enclosure_bits':BITS,'case_count':len(rows),'stage_counts':{'initial':3,'stress':2,'expanded':2},
        'cases':rows,'status':'PASS','limitations':['Finite piecewise-constant normalized densities and fixed positive B,J only.',
            'These rational enclosures certify only the listed finite examples, not the general total-variation theorem.',
            'No original space-variable J, A, H, source/history, coarea or FULL eligibility is constructed.',
            'The true dx dilation factor r is retained; fixed-coefficient transport does not pay the original variable-coefficient errors.',
            'No floating total variation or dimension-order fit is used.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'transport_checks.json');args=ap.parse_args()
    r=run();args.output.write_text(json.dumps(encode(r),indent=2,sort_keys=True)+'\n')
    print('PASS: 7 finite densities with rational critical-point variation enclosures')
