# R499：外部来源匹配与真实 slack 的同权比较

本轮只尝试把 R498 的同对 outside 输运与真实负信用
\(-\int u d\,d\widehat\nu\) 联合结算。没有得到新的整体费用；下面给出准确比较及卡住的那一步。它不是将守恒式重新命名为估计。

## 1. 原积分与待检验机制

沿 R498 同一真实场、\(K_0\)、\(\mu=f\,dx\)、\(\widehat\nu=\nu_\tau ds\)、质量/mark 次序及全部真实分母。记
\[
 G=\sum_{j\ge0}(K_0^*)^j1,\qquad
 u=\sum_{j\ge0}K_0^j b_R,\qquad 0\le u\le1,
 \quad I=\int u\,d\widehat\nu\le R_\tau.
\]
保 R498 的有效来源纤维函数
\[
 \psi_x(B)=e^\beta[1+\beta\log(M(x)/m_B)],\quad
 d_x(B)=\psi_x(B)-1-V_x\psi_x(B)\ge0,
 \quad d(B)=\pi_B d_x.
\]
这里只在 \(x\in Q_B\) 的实际 joint 上使用此 slack。
已付混合/empty 误差后目标是
\(H_{\rm source}-\int u d\,d\widehat\nu\) 的根阶上界。

尝试机制：把每个祖先对的 head 来源落在
\(Q_B\setminus Q_A\) 的部分，按真实来源质量搬到
\(Q_A\setminus Q_B\)；利用其 density deficit 与 inside 捕获项共同支付质量差。需要核对的不只是质量守恒，而是这个 deficit 是否与上述 slack 处在同一个累计权下。

## 2. 同对输运与来源 ceiling 的准确差

固定 \(\widehat B\prec\widehat A\)，故 \(m_B\le m_A\)。记
\[
 I_{AB}=\mu(Q_A\cap Q_B),\qquad
 H_{AB}=\mu((Q_B\setminus Q_A)\cap\{v_z(B)<K\}).
\]
在 \(m_A>I_{AB}\) 时，R498 已证的精确外部输运密度为
\[
 a_{AB}=\frac{m_AH_{AB}}{m_B(m_A-I_{AB})}\le1,
\]
\[
 1-a_{AB}=
 \frac{m_A(m_B-I_{AB}-H_{AB})}{m_B(m_A-I_{AB})}
 +\frac{I_{AB}(m_A-m_B)}{m_B(m_A-I_{AB})}. \tag{1}
\]
原 \(z\) 及 head 标签保留为条件附加量，人工来源
\(w\) 按 \(\mu|_{Q_A\setminus Q_B}\) 归一抽取。
零外部质量取零核。\(w\notin Q_B\)，故不能把
\(\psi_w(B)\)、\(d_w(B)\) 当作原 \(\pi_B\) 纤维；
\(v_w(B)\) 虽是可定义的全场前缀统计，也不自动低于 \(K\)。

来源局部 ceiling 的合法标量差准确为
\[
 \log M(w)-\log M(z)
 =\log\frac{m_A}{m_B}
   +\log\frac{M(w)}{m_A}
   -\log\frac{M(z)}{m_B}. \tag{2}
\]
右边后两项分别在真实 \(w\in Q_A\)、\(z\in Q_B\) 上非负。
因此质量次序本身不给该 signed 差固定符号：不能只保第一项当作下降，亦不能免费删除正的父来源局部尾。

式 (1) 的 inside/outside 常数测试抵消是质量守恒，不是新信用。
对非恒定的 head/ceiling 测试，必须保 (2) 的来源尾及原 \(z\) 标签。

## 3. 真正的权重核对：不能把 \(G(A)\) 消失掉

定义共同的未加终端权最大点测度
\[
 d\mathcal Q=
 \widehat\nu(d\widehat A)\pi_A(dx)
 \frac{1_{\{\widehat B\prec\widehat A\}}}{T}
 1_{\{v_x(A)\ge K\}}
 e^{-[v_x(A)-v_x(B)]/T}\rho_x(d\widehat B).
 \tag{3}
\]
完整祖先 outside 量使用的是
\[
 \int G(A)\frac{H_{AB}}{m_B}\,d\mathcal Q,
 \tag{4}
\]
若讨论 R497 boundary 部分，再保 \(\chi_\partial(A,x)\)。
输运 (1) 在这个原权下完全合法。

但真实 slack 的正质量差项不是 (4) 的权。因为对实际共同捕获来源 \(x\)，
\[
 \psi_x(A)=\psi_x(B)-e^\beta\beta\log(m_A/m_B),
\]
逐来源有准确式
\[
 d_x(B)=\psi_x(B)(1-V_x1(B))-1
       +e^\beta\beta V_x\log(m_A/m_B)(B).
 \tag{5}
\]
换序后
\[
 \int u d\,d\widehat\nu
 = e^\beta\beta\int u(B)\log(m_A/m_B)\,d\mathcal Q
 +\int u(B)\bigl[\pi_B\{\psi_x(B)(1-V_x1(B))\}-1\bigr]
       \,d\widehat\nu(B). \tag{6}
\]
这里权为 \(u(B)\)，没有 \(G(A)\)。不能把 (4) 中 density deficit
直接扣到 (6)；\(G\ge1\)、\(u\le1\) 也不给所需方向的支配。

由于 \(V_x1\le1\)，式 (6) 最后的括号至少 \(-1\)。因此单独抽取质量差项只得到
\[
 \int u d\,d\widehat\nu
 \ge e^\beta\beta\int u(B)\log(m_A/m_B)d\mathcal Q-I.
 \tag{7}
\]
损失是完整 \(I\)，不是已付 \(W\) 费用；回代不会产生系数小于 1 的收缩。
\(d_x\ge0\) 不能证明其两个展开部分分别非负。

唯一仍缺的几何比较是：在 (3) 的真实共同捕获、void、质量序下，将
外部输运所产生的父来源局部尾与 inside head 项一起结算，且保持 (6)
的 \(u(B)\) 信用及其余括号，不能用 \(G(A)\) 的累计 outside 量逐项替代。
目前删正限制只会把该父局部尾上放到
\(\int G(A)\pi_A\log(M(w)/m_A)\,d\widehat\nu(A)\)，仍是未付累计量。
本附件未证明这一比较，不以新的尾积分名称或 \(\int d\) 的全局守恒作为付款。

这说明下一步若保此路线，必须直接处理同权的 signed head/slack 几何，
而不是继续优化同对输运常数。原 \(\tau X\)、R495 非rank 收据、R498 混合/empty
收据均不变；本附件没有额外可扣费用。

## 4. 实际本机符号核验

指定 Python 环境实际执行以下三个恒等式核验；它们只校验 (1)、(2)、(5)
的符号，不验证一般几何估计或 native/history 模型。

```python
import sympy as s
P,V,g,b=s.symbols('P V g b')
assert s.expand(P-1-(P*V-b*g)-(P*(1-V)-1+b*g))==0
A,B,I,H=s.symbols('A B I H',positive=True)
d=A*H/(B*(A-I))
assert s.factor(1-d-A*(B-I-H)/(B*(A-I))
                -I*(A-B)/(B*(A-I)))==0
ellw,ellz,ma,mb=s.symbols('ellw ellz ma mb',real=True)
assert s.expand((ellw-ellz)-((ma-mb)+(ellw-ma)-(ellz-mb)))==0
print('3 exact symbolic identities PASS; no global geometric bound tested.')
```

实际 stdout 与上述输出一致。本轮没有得到新的全局可付款不等式，现于精确权重缺口处停止。
