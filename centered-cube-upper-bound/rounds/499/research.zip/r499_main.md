# 第499轮：同权停止路径桥与联合势差的有限深度核验

## 本轮目标与结果状态

基线为已推送第498轮db3ec1c87925227c4495d6e160ce8d50f6dae613。目标仍是任意非负L1来源下的一般中心立方体极大算子根阶一致弱型界。本轮建设性尝试在同一完整积分内联合使用head质量谱、负Bellman势差和外部来源匹配；没有获得新的根阶付款。报告记录准确的共同路径表示、有限信用可认证尾项及未跨越的几何条件，避免继续把不相同的权重直接抵扣。

全部沿R495–498原固定场：μ=f dx，W=||f||1，νhat=t q_A dA|t≥τ ds，0<τ≤S，q≤q_A≤λ，a≤R_A≤b≤2a，m_A=μ(Q_A)。同质量由连续mark排序，来源π_A=μ|QA/m_A，ρ_x=1_QA νhat/m_A。K0为原max-only支配父核，G=Σ(K0*)^j1，b=b_R，u=ΣK0^j b。I=∫Gb dνhat=∫u dνhat，Rτ=I+Eempty。不得把raw链与原成功链或其lowGram记录当同律。

沿R498，ψ_x=e^β[1+βlog(M(x)/m_A)]，d_x=ψ_x−1−V_xψ_x≥0，d=π_Bd_x。保源平均与signed补偿，准确主目标是Hsource−∫u d≤aRτ+C√n log^A(n+2)W，a<1，而不是分别控制Hsource和负项。R498混合误差已经有O(W)价，本轮不重复收费。

## 1. 明确排除守恒的误读

真实kernel换序给
\[
\int d\,d\widehat\nu=H_{\rm source}+E_{\rm source}-R_\tau,
\quad E_{\rm source}=\int\widehat\nu(dA)\pi_A(dx)
1_{v_x(A)\ge K}e^{-v_x(A)/T}\psi_x(A).
\]
因此Hsource−∫u d=Rτ−Esource+∫(1−u)d。其余项可用empty预算界，但这只是停止守恒，不给a<1的新上界。本轮没有把此恒等式当作付款。

作者给出d_x的三项非负分解及实际有限信用u_N=Σ_{j<N}K0^j b。尾信用≤(Φmax−1)e^{αL}2^{-N}Rτ，α=4c/T；选N可吸收尾信用，但仍须支付Hsource−∫u_Nd。若逐代收KW再乘N，可能重新产生线性费用。数值只核这些真实有限量，不把抽象终端帽移植到不满足其选参的小模型。

## 2. 外部匹配与势差为何不能直接相抵

几何附件保持原共同pair测度dQ，准确区分祖先贡献G(A)b(B)dQ与势差中的u(B)dQ。同对outside匹配密度≤1仍成立，但它的人工来源不取得原head或history资格。完整d中质量差正项之外还存在可负基线；单抽正项会付出I级损失，不能给严格收缩。此处不是否定原一般目标，而是要求所有信用先放到下面同一停止路径中比较。

## 3. 同一真实rank停止路径的首边、末边和累计边

本节是合法连接，不是新费用界。将K=K0、b=b_R。原初始测度νhat所诱导的rank停止有限路径测度为
\[
\sum_{k\ge0}\widehat\nu(dA_0)
 K(A_0,dA_1)\cdots K(A_{k-1},dA_k)b(A_k).
\]
其总量为I；零长度路径保留，终端消失及可积性沿原Green帽。对于至少有一条边的路径，首边测度、末边测度与累计边测度分别是
\[
F(dA,dB)=\widehat\nu(dA)K(A,dB)u(B),
\]
\[
L_e(dA,dB)=\widehat\nu(dA)G(A)K(A,dB)b(B),
\]
\[
O(dA,dB)=\widehat\nu(dA)G(A)K(A,dB)u(B).
\]
这里G是相对νhat的到达密度。所有source/mark/void包含在同一K内，展开时必须恢复其原分母。F和L_e总量均为I−∫b dνhat，但不是同测度；O同时支配它们，因为G≥1、u≥b。不能把这种共同支配当免费可交换性。

对任意有界父函数φ，有限路径逐边望远镜，或直接用K u=u−b、K*G=G−1，给
\[
\int O(dA,dB)[\phi(A)-\phi(B)]
=\int\phi u\,d\widehat\nu-\int\phi Gb\,d\widehat\nu.
\tag{P1}
\]
取φ=log m（质量不增，mark等质量贡献0）得
\[
0\le\int O\log(m_A/m_B)\le L I,
\quad L=\log(m_+/m_-).
\]
这只是路径质量跨度预算，不是LW来源价；I仍待估。

对任意有界edge函数w，令
\[
\mathcal T(dA,dB,dC)=\widehat\nu(dA)G(A)
K(A,dB)K(B,dC)u(C).
\]
则准确首末边比较为
\[
\int w\,dF-\int w\,dL_e
=\int\mathcal T[d,w],\qquad
[d,w]=w(A,B)-w(B,C).
\tag{P2}
\]
证明是沿每条长度至少2的路径相邻边望远镜；也可用两条resolvent身份直接验证。有限总ν、 bounded G和w使所有交换绝对可积。该式定位了将祖先outside信用移向势差所须支付的实际相邻边变化。没有证明对所需head/overlap测试，此变化有利或有根阶来源价；不能把(P2)当已支付连接。

## 4. 实际决策与剩余任务

本轮的三条尝试汇合于同一限制：纯source总势差回收只恢复Rτ，有限步信用留下真实终端，pair外部匹配与inside平方必须在相同累计路径及head测试下结算。当前不继续优化这些守恒式常数，也不声称已有统一收缩。

下一步若沿此方向，必须证明真实head/overlap测试在(P2)相邻边上的有价变化，或使用原成功族中额外的几何见证并给同流比较；不能把原lowGram资格直接写到raw路径上。有限模型不含单一真实半径selector与原成功记录，故其信用大小不构成一般根阶证据。

原一次τX、原非rank累计费用、empty价、入口倍率64(128/119)/(1−32δ_old−16η_old)、初始/删除/跳跃/未来删来源、宽距、低强度、极端比和全尺度未付槽全部保留。一般目标仍活跃且未完成。

## 5. 本机复现

主控路径桥使用指定独立Python和SymPy有理算术，三组有限次Markov核验证首末边总质量、共同占用支配、端点势差、相邻边恒等式与质量跨度上界，共15项实际断言。有限核不认证中心立方体几何，通式证明在上文给出。其余实际验证详见proof、geometry和numeric；归档后按replay输出重放，不编译PDF。

```python
import sympy as s
cases=[(s.Rational(1,4),s.Rational(1,5),s.Rational(1,3)),(s.Rational(1,2),0,s.Rational(2,3)),(0,s.Rational(3,4),0)]
checks=0
for a,c,t in cases:
 K=s.Matrix([[0,a,c],[0,0,t],[0,0,0]]);one=s.ones(3,1);nu=s.Matrix([[1,2,3]])
 e=(one-K*one)/3;b=one-K*one-e;res=(s.eye(3)-K).inv();u=res*b;occ=nu*res
 F=s.Matrix(3,3,lambda i,j:nu[i]*K[i,j]*u[j]);L=s.Matrix(3,3,lambda i,j:occ[i]*K[i,j]*b[j]);O=s.Matrix(3,3,lambda i,j:occ[i]*K[i,j]*u[j]);phi=[3,2,0]
 assert sum(F)==sum(L)==(nu*u)[0]-(nu*b)[0];checks+=1
 assert all(O[i,j]>=F[i,j] and O[i,j]>=L[i,j] for i in range(3) for j in range(3));checks+=1
 edge=sum(O[i,j]*(phi[i]-phi[j]) for i in range(3) for j in range(3));end=sum(nu[i]*u[i]*phi[i]-occ[i]*b[i]*phi[i] for i in range(3));assert edge==end;checks+=1
 w=s.Matrix([[0,2,5],[0,0,-1],[0,0,0]])
 diff=sum((F[i,j]-L[i,j])*w[i,j] for i in range(3) for j in range(3))
 triple=sum(occ[i]*K[i,j]*K[j,k]*u[k]*(w[i,j]-w[j,k]) for i in range(3) for j in range(3) for k in range(3));assert diff==triple;checks+=1
 assert 0<=edge<=3*(nu*u)[0];checks+=1
print(f'PASS {checks} rational path-bridge assertions; three finite kernels only')

```

本轮实际隔离重放总计310项报告核验单位：主路径桥15、geometry符号3、proof符号/有理26、numeric精确/Arb266。numeric只复用3个连续mark模型及N=1,2,4（N=3为递推中间量），没有新高维原生场或原选参扫描。N=4未回收信用约0.927700、0.247575、1.470136；另外的signed empty修正分别约1.718283、2.925586、2.925586，精确相加给全部差额。Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb384bits，命令、stdout和规范结果SHA见r499_replay.json；规范JSON仅排除compute_index.seconds，SHA256为8aff8b79c0489247ac8f477ad723f4ad5130288c501b4389742e1bb4a7a4f67a。未把有限模型外推至一般阶数。
