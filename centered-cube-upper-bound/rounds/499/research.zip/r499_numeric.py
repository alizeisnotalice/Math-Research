from pathlib import Path
from fractions import Fraction as F
import sys,platform,json,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0
E=sp.Symbol('E',positive=True);l3,l4,l9=sp.symbols('l3 l4 l9',real=True)

def ck(x):
 global checks
 assert x
 checks+=1

def clean(x):return sp.expand(x)
def eq(x):ck(clean(x)==0)
def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def er(x):
 x=F(x)*72;assert x.denominator==1;return E**x.numerator

def add(*polys):
 out={}
 for p in polys:
  for k,v in p.items():out[k]=clean(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v!=0}
def scale(p,a):return {k:clean(a*v) for k,v in p.items() if a*v!=0}
def mul(p,q):
 out={}
 for k,v in p.items():
  for kk,vv in q.items():out[k+kk]=clean(out.get(k+kk,0)+v*vv)
 return out

def at(p,x):return clean(sum(v*er(k*x) for k,v in p.items()))
def integ(p,a,b):return clean(sum(v*((er(k*b)-er(k*a))/sp.Rational(k.numerator,k.denominator) if k else sp.Rational((b-a).numerator,(b-a).denominator)) for k,v in p.items()))
Earb=ar(F(1,72)).exp();subarb={E:Earb,l3:arb(3).log(),l4:arb(4).log(),l9:arb(9).log()}
def ev(x):
 x=sp.sympify(x)
 if x.is_Rational:return ar(F(int(x.p),int(x.q)))
 if x in subarb:return subarb[x]
 if x.is_Add:return sum((ev(z) for z in x.args),arb(0))
 if x.is_Mul:
  y=arb(1)
  for z in x.args:y*=ev(z)
  return y
 if x.is_Pow and x.exp.is_Integer:return ev(x.base)**int(x.exp)
 raise ValueError(x)
def val(p,xx):return sum((ev(v)*(ar(k)*xx).exp() for k,v in p.items()),arb(0))
def interval(a,b):return ar((a+b)/2)+arb(0,str(ar((b-a)/2)))
def meanpoly(ps,weights):return add(*(scale(p,sp.Rational(w.numerator,w.denominator)) for p,w in zip(ps,weights)))
# Centering and explicit cost-algebra identities, independent of finite models.
p,x,y,EX,EY,nX,nY=sp.symbols('p x y EX EY nX nY')
h=p*x+(1-p)*y
C=p*(h-x)*(1-EX-nX)+(1-p)*(h-y)*(1-EY-nY)
eq(C+p*(h-x)*EX+(1-p)*(h-y)*EY+p*(h-x)*nX+(1-p)*(h-y)*nY)
mu=[F(3),F(1),F(8)];capture=[[1,0,0],[1,1,0],[0,1,1]];mass=[F(3),F(4),F(9)];logs=[l3,l4,l9];ell=[l4,l9,l9];nu=mass;W=sum(mu)
pi=[[mu[x]*capture[a][x]/mass[a] for x in range(3)] for a in range(3)]
hh=[sum(sp.Rational(w.numerator,w.denominator)*ell[x] for x,w in enumerate(pi[a])) for a in range(3)]
prefix=[[sum(capture[b][x] for b in range(a)) for x in range(3)] for a in range(3)]
for x in range(3):
 for a in range(3):ck(sum(nu[b]*capture[b][x] for b in range(a+1))<=2*mass[a])
z=sp.symbols('z',real=True)
def rq(q):return sp.Rational(q.numerator,q.denominator)
def pat(poly,q):return clean(sum(v.subs(z,rq(q))*er(k*q) for k,v in poly.items()))
def anti(poly,k):
 if not k:return sp.integrate(poly,z)
 out=sp.Integer(0);der=poly;j=0
 while der!=0:
  out+=(-1)**j*der/rq(k)**(j+1);der=sp.diff(der,z);j+=1
 return clean(out)
def pint(poly,lo,hi):
 ans=sp.Integer(0)
 for k,v in poly.items():
  p=anti(v,k)
  ans+=p.subs(z,rq(hi))*er(k*hi)-p.subs(z,rq(lo))*er(k*lo)
 return clean(ans)
def convolute(poly,lo,hi,y0,tt):
 out={-1/tt:clean(y0*er(lo/tt))}
 for k,v in poly.items():
  pp=anti(v,k+1/tt)
  out=add(out,{k:pp/rq(tt)},{-1/tt:-er((k+1/tt)*lo)*pp.subs(z,rq(lo))/rq(tt)})
 deriv={k:sp.diff(v,z)+rq(k)*v for k,v in out.items()}
 for v in add(scale(deriv,rq(tt)),out,scale(poly,-1)).values():eq(v)
 eq(pat(out,lo)-y0)
 return out
models=[]
for label,tt,kk in [('initial',F(1),F(1,2)),('atom_boundary',F(1),F(1)),('expanded_threshold',F(1,2),F(3,2))]:
 beta=F(2)/tt;eb=er(beta)
 psi=[[eb*(1+sp.Rational(beta.numerator,beta.denominator)*(ell[x]-logs[a])) for x in range(3)] for a in range(3)]
 breaks=[];pieces=[];yend=[]
 for a in range(3):
  bp=sorted({F(0),F(1)}|{kk-prefix[a][x] for x in range(3) if capture[a][x] and 0<kk-prefix[a][x]<1});breaks.append(bp)
  yn=sp.Integer(0);out=[]
  for lo,hi in zip(bp,bp[1:]):
   mid=(lo+hi)/2;active=[capture[a][x] and prefix[a][x]+mid>=kk for x in range(3)]
   b=1-sum(pi[a][x] for x in range(3) if active[x]);D=sp.Integer(0)
   for x in range(3):
    if active[x]:D+=sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*sum(er(-F(prefix[a][x]-prefix[j][x]-1)/tt)*yend[j] for j in range(a) if capture[j][x])
   D=clean(D)
   if b==1:yp={F(0):sp.Integer(1),-1/tt:clean((yn-1)*er(lo/tt))}
   else:
    bb=sp.Rational(b.numerator,b.denominator)
    yp=add({F(0):sp.Integer(1)},{-b/tt:clean((yn-1-D/(bb-1)*er(-lo/tt))*er(b*lo/tt))},{-1/tt:clean(D/(bb-1))})
   up=add({F(0):sp.Rational(b.numerator,b.denominator)},scale(yp,1-sp.Rational(b.numerator,b.denominator)),{-1/tt:D})
   # Exact ODE and Volterra absorption equation on the whole interval.
   deriv={k:sp.Rational(k.numerator,k.denominator)*v for k,v in yp.items()}
   eq(at(yp,lo)-yn)
   for v in add(scale(deriv,sp.Rational(tt.numerator,tt.denominator)),yp,scale(up,-1)).values():eq(v)
   out.append((lo,hi,yp,up));yn=at(yp,hi)
  pieces.append(out);yend.append(yn)
 # Ancestor V for parent-constant source functions; exact exponential polynomials.
 def ancestor(a,x,field,sample):
  out={}
  threshold=kk-prefix[a][x]
  if threshold<1:
   if sample<threshold:
    out=add(out,{1/tt:clean(field[a][x]*(er(-threshold/tt)-er(-1/tt)))})
   else:out=add(out,{F(0):field[a][x],1/tt:-field[a][x]*er(-1/tt)})
  for j in range(a+1,3):
   if not capture[j][x]:continue
   low=max(F(0),kk-prefix[j][x])
   if low<1:out=add(out,{1/tt:clean(field[j][x]*er(F(prefix[a][x]-prefix[j][x])/tt)*(er(-low/tt)-er(-1/tt)))})
  return out
 field=[[hh[a]-ell[x] for x in range(3)] for a in range(3)]
 Ctotal=Chead=Cemp=Cweighted=Cemptyweighted=Ud=I=sourcehead=parenthead=empty=empty_source=total_d=sp.Integer(0)
 dpieces=[[] for _ in range(3)]
 partpieces={name:[[] for _ in range(3)] for name in ('gate','slack','tail')}
 for a in range(3):
  eq(sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*(hh[a]-ell[x]) for x in range(3)))
  for lo,hi,yp,up in pieces[a]:
   mid=(lo+hi)/2;active=[capture[a][x] and prefix[a][x]+mid>=kk for x in range(3)]
   Cpoly=meanpoly([ancestor(a,x,field,mid) for x in range(3)],pi[a])
   dpoly=meanpoly([add({F(0):psi[a][x]-1},scale(ancestor(a,x,psi,mid),-1)) for x in range(3)],pi[a])
   dpieces[a].append(dpoly);total_d+=mass[a]*integ(dpoly,lo,hi)
   sourceparts={name:[] for name in partpieces}
   for x in range(3):
    if not capture[a][x]:
     for name in sourceparts:sourceparts[name].append({})
     continue
    vall={F(0):psi[a][x],1/tt:-psi[a][x]*er(-1/tt)}
    for j in range(a+1,3):
     if capture[j][x]:vall=add(vall,{1/tt:psi[j][x]*er(F(prefix[a][x]-prefix[j][x])/tt)*(1-er(-1/tt))})
    vrank=ancestor(a,x,psi,mid)
    remaining=F(sum(capture[j][x] for j in range(a,3)))
    ck(remaining<=2)
    endexp={1/tt:er(-remaining/tt)}
    sourceparts['gate'].append(add(vall,scale(vrank,-1)))
    sourceparts['slack'].append(add({F(0):psi[a][x]},scale(endexp,-psi[a][x]),scale(vall,-1)))
    sourceparts['tail'].append(add(scale(endexp,psi[a][x]),{F(0):sp.Integer(-1)}))
   for name in partpieces:partpieces[name][a].append(meanpoly(sourceparts[name],pi[a]))
   for v in add(*(partpieces[name][a][-1] for name in partpieces),scale(dpoly,-1)).values():eq(v)

   bR=1-sum(pi[a][x] for x in range(3) if active[x])
   nnpoly={}
   for x in range(3):
    w=sp.Rational(pi[a][x].numerator,pi[a][x].denominator)
    if not w:continue
    if not active[x]:
     Chead+=mass[a]*w*(hh[a]-ell[x])*sp.Rational((hi-lo).numerator,(hi-lo).denominator)
     sourcehead+=mass[a]*w*psi[a][x]*sp.Rational((hi-lo).numerator,(hi-lo).denominator)
    else:
     npoly={-1/tt:er(-F(prefix[a][x])/tt)}
     Cemp+=mass[a]*w*(hh[a]-ell[x])*integ(npoly,lo,hi)
     empty_source+=mass[a]*w*psi[a][x]*integ(npoly,lo,hi)
     nnpoly=add(nnpoly,scale(npoly,w))
   Ctotal+=mass[a]*integ(Cpoly,lo,hi)
   Cweighted+=mass[a]*integ(mul(up,Cpoly),lo,hi)
   Cemptyweighted+=mass[a]*integ(mul(add({F(0):sp.Integer(1)},scale(up,-1)),Cpoly),lo,hi)
   Ud+=mass[a]*integ(mul(up,dpoly),lo,hi)
   I+=mass[a]*integ(up,lo,hi)
   empty+=mass[a]*integ(add({F(0):sp.Integer(1)},scale(up,-1)),lo,hi)
   parenthead+=mass[a]*bR*sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*psi[a][x] for x in range(3))*sp.Rational((hi-lo).numerator,(hi-lo).denominator)

 eq(Ctotal+Chead+Cemp);eq(Cweighted+Cemptyweighted-Ctotal)
 eq(parenthead-sourcehead-eb*sp.Rational(beta.numerator,beta.denominator)*Chead)
 eq(I-sourcehead+eb*sp.Rational(beta.numerator,beta.denominator)*(Cemp+Cemptyweighted)+Ud)
 # Source-centering remains zero with u(A,s) at that SAME parent, not u(B).
 for a in range(3):eq(hh[a]-sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*ell[x] for x in range(3)))
 quantities=dict(I=I,empty=empty,source_head=sourcehead,parent_head=parenthead,C_total=Ctotal,C_head=Chead,C_emp=Cemp,uC=Cweighted,one_minus_u_C=Cemptyweighted,u_d=Ud)
 values={name:str(ev(clean(value))) for name,value in quantities.items()}
 for name,value in quantities.items():ck(ev(clean(value)).is_finite())
 ck(ev(I)>0);ck(ev(empty)>0);ck(ev(Ud)>0)
 ck(abs(ev(Cemp))<arb(3).log()*ar(tt)*ar(-kk/tt).exp()*ar(W))
 ck(abs(ev(Cemptyweighted))<arb(3).log()*ev(empty))
 eq(total_d-sourcehead-empty_source+sum(mass))
 parttotals={name:sum(mass[a]*integ(partpieces[name][a][k],lo,hi) for a in range(3) for k,(lo,hi,yp,up) in enumerate(pieces[a])) for name in partpieces}
 eq(sum(parttotals.values())-total_d)
 previous=[[{} for item in pieces[a]] for a in range(3)]
 finite=[];oldcredit=sp.Integer(0)
 H0=sum(mu[x]*min(kk,F(sum(capture[a][x] for a in range(3)))) for x in range(3))
 spectrum=clean(sourcehead-eb*H0)
 correction=clean(eb*rq(beta)*(Cemp+Cemptyweighted))
 for N in range(1,5):
  conv=[];ends=[]
  for a in range(3):
   ys=sp.Integer(0);oneparent=[]
   for k,(lo,hi,yp,up) in enumerate(pieces[a]):
    cp=convolute(previous[a][k],lo,hi,ys,tt);oneparent.append(cp);ys=pat(cp,hi)
   conv.append(oneparent);ends.append(ys)
  current=[]
  for a in range(3):
   ps=[]
   for k,(lo,hi,yp,up) in enumerate(pieces[a]):
    mid=(lo+hi)/2;active=[capture[a][x] and prefix[a][x]+mid>=kk for x in range(3)]
    b=1-sum(pi[a][x] for x in range(3) if active[x]);D=sp.Integer(0)
    for x in range(3):
     if active[x]:D+=rq(pi[a][x])*sum(er(-F(prefix[a][x]-prefix[j][x]-1)/tt)*ends[j] for j in range(a) if capture[j][x])
    ps.append(add({F(0):rq(b)},scale(conv[a][k],1-rq(b)),{-1/tt:clean(D)}))
   current.append(ps)
  credit=sum(mass[a]*pint(mul(current[a][k],dpieces[a][k]),lo,hi) for a in range(3) for k,(lo,hi,yp,up) in enumerate(pieces[a]))
  ck(ev(clean(credit))>0);ck(ev(clean(Ud-credit))>0)
  if N>1:ck(ev(clean(credit-oldcredit))>0)
  target=clean(sourcehead-credit);tail=clean(Ud-credit)
  eq(target-I-tail-correction)
  if N in (1,2,4):
   partcredit={name:clean(sum(mass[a]*pint(mul(current[a][k],partpieces[name][a][k]),lo,hi) for a in range(3) for k,(lo,hi,yp,up) in enumerate(pieces[a]))) for name in partpieces}
   eq(sum(partcredit.values())-credit)
   for value in partcredit.values():
    if clean(value)==0:eq(value)
    else:ck(ev(value)>0)
   finite.append(dict(N=N,credit_by_d_part={name:str(ev(value)) for name,value in partcredit.items()},credit=str(ev(clean(credit))),source_head_minus_credit=str(ev(target)),remaining_credit_to_true_u=str(ev(tail)),target_minus_I=str(ev(clean(target-I))),finite_credit_minus_local_head_spectrum=str(ev(clean(credit-spectrum))),decomposition='target-I=remaining_credit_to_true_u+signed_empty_correction, exact0 residual'))
  previous=current;oldcredit=credit
 models.append(dict(label=label,T=str(tt),K=str(kk),c='2',beta=str(beta),continuous_mark='s in[0,1],rho_parent=1; exact piecewise exponential Volterra solution',finite_credit=finite,d_integral_parts={name:str(ev(value)) for name,value in parttotals.items()},d_decomposition_scope='U_x<=c=2 so actual a<=c and g(a)=psiB; gate=Vallpsi-Vrankpsi,slack=psiB(1-exp(-D/T))-Vallpsi,tail=psiB exp(-D/T)-1',integral_d=str(ev(total_d)),empty_source=str(ev(empty_source)),conservation='integral d=source_head+empty_source-R,exact0',local_head_spectrum_term=str(ev(spectrum)),signed_empty_correction=str(ev(correction)),mark_breakpoints=[[str(z) for z in v] for v in breaks],convolution_y_endpoint_values=[str(ev(z)) for z in yend],quantities=values,signed_residual='exact0 in Laurent polynomial E=exp(1/72) and symbolic log3/log4/log9',centered_same_parent_u_term='exact0; this does not set u(B)*C(B) to zero'))
result=dict(scope='Same three frozen R498 scalar continuous-mark models; finite atomic source/parent incidence,not nativeL1/Lebesgue/history.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r499_numeric.py',seconds=time.perf_counter()-start),checks=checks,models=models,N_values=[1,2,4],baseline_static_copy_SHA256='4cc9353064697e4eb97c0825c552c293e4794a4eb5c9d0ebf53f88c7a5dd9421',formulas=dict(uN='u0=0,uN=bR+K0 uNminus1',credit='integral uN*d',conservation='integral d=source_head+empty_source-R',terminal='source_head-creditN-I=integral(u-uN)d+exp(beta)*beta*(Cemp+integral(1-u)C)'),decision='Finite-step credit is measured on the same exact continuous-mark chain. Conservation alone is not a gain;finite deficits are split into genuine unresolved credit and signed empty correction.',errors='Exact polynomial-times-exponential integration with Laurent formal exp(1/72) and symbolic logs;384-bit Arb values. No discrete mark, solver,MC, parameter scan or unrelated R495/deep rerun.')
(ROOT/'r499_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;3 reused continuous-mark models,N1/2/4 credits;no new geometry')
