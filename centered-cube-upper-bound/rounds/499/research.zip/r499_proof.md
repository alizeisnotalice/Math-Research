# R499：真实 CDF 缺陷三分解与有限步信用

沿用 R498 同一实际场、同一带连续 mark 的 raw 最大父核 \(K_0\)，不改来源或质量。记
\(\widehat\nu=\nu_\tau ds\)、\(R=\widehat\nu(E)\)、\(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)\)、\(c=rS\)、\(\beta=c/T\)、\(L=\log(m_+/m_-)\)、\(K=\kappa T\)。
令 \(b_R(B)=\pi_B\{v_x(B)<K\}\)、\(u=\sum_{j\ge0}K_0^jb_R\le1\)。R498 的局部势与缺陷为
\[
\psi_x(B)=e^\beta[1+\beta\log(M(x)/m_B)],\qquad
d_x(B)=\psi_x(B)-1-V_x\psi_x(B)\ge0,\quad d(B)=\pi_Bd_x.
\]
这里 \(M(x)\) 是实际来源可捕获父的 essential 最高质量；\(V_x\) 保留原祖先 rank 门和指数 void。完整已证账是
\[
I=H_{\rm source}-\int ud\,d\widehat\nu+\mathcal E_{\rm mix},
\qquad |\mathcal E_{\rm mix}|\le\overline C_{\rm mix}W,
\quad H_{\rm source}=\int\widehat\nu\pi_B1_{v_x(B)<K}\psi_x(B).
\tag{1}
\]
本稿给出可计算的非负缺陷分解及有限信用误差；**未证明 (1) 的完整根阶预算**。

## 1. 同一来源的三个非负缺陷

固定有效 \((B,x)\)，置
\[
w=v_x(B),\quad D=U_x-w,\quad \ell=\log(M(x)/m_B),
\quad D_*=c(1+\ell),\quad
g(a)=\psi_x(B)-\frac{e^\beta}{T}(a-c)_+.
\]
用 \(a\) 表示实际祖先 rank 与 \(w\) 的差。\(\bar\psi(a)\) 是在来源秩 fiber 上的条件均值，不假定一个 rank 对应唯一父。连续 mark 将质量原子展开，来源秩推前为 Lebesgue 测度。闭质量窗
\(\rho_x[m_B,m_A]\le c[1+\log(m_A/m_B)]\) 给出
\[
D\le D_*,\qquad 0\le\bar\psi(a)\le g(a),\qquad
\int_0^{D_*}g(a)e^{-a/T}\frac{da}{T}=\psi_x(B)-1.
\tag{2}
\]
最后等式直接在 \(a=c\) 分段积分；\(g(D_*)=e^\beta>0\)。于是准确地
\[
\begin{aligned}
d_x(B)={}&\underbrace{\int_0^D1_{w+a<K}\bar\psi(a)e^{-a/T}\frac{da}{T}}_{d_{\rm gate}}\\
&+\underbrace{\int_0^D[g(a)-\bar\psi(a)]e^{-a/T}\frac{da}{T}}_{d_{\rm slack}}
+\underbrace{\int_D^{D_*}g(a)e^{-a/T}\frac{da}{T}}_{d_{\rm tail}}.
\end{aligned}\tag{3}
\]
三项分别保留真实 rank 门损失、实际质量增长相对闭窗包络的余量、局部来源总秩未填满包络的余量。它们没有逐代重新收费，也没有把来源质量换成边界体积。零来源行不进入 joint；\(D=0\) 时积分按空区间取零。

## 2. 有限步信用能准确逼近，但不是新源价格

令 \(u_N=\sum_{j=0}^{N-1}K_0^jb_R\)，\(u_0=0\)。则
\[
0\le u_N\uparrow u\le1,\qquad u-u_N=K_0^Nu.
\]
沿已证 R495 参数 \(\alpha=4c/T\le1\)，同一 raw 核满足
\((K_0^*)^N1\le e^{\alpha L}2^{-N}\)。因
\(0\le d\le d_{\max}:=e^\beta(1+\beta L)-1\)，得到
\[
0\le\int(u-u_N)d\,d\widehat\nu
\le d_{\max}e^{\alpha L}2^{-N}R.
\tag{4}
\]
取 \(N=\max\{0,\lceil\log_2(d_{\max}e^{\alpha L}/\varepsilon)\rceil\}\)
即使右侧不超过 \(\varepsilon R\)；若 \(d_{\max}=0\)，取 \(N=0\)。故只要能估计真实有限信用，终端不会隐藏额外 \(W\) 次数。可是
\[
H_{\rm source}-\int u_Nd
=H_{\rm source}-\int ud+\int(u-u_N)d
\]
本身没有减少正头部价格。特别不能把 (4) 误作有限步信用已经足够大。

## 3. 一次信用产生的实际同父比较，以及停止点

写 \(E_x(B)=1_{v_x(B)<K}\)、\(b=b_R(B)\)、\(h_1(B,x)=V_x1(B)\)。祖先质量不小于 \(m_B\)，故 \(V_x\psi_x\le\psi_x(B)h_1\)。在 head 上
\[
h_1(B,x)\le e^{-(K-v_x(B))/T}.
\]
由 \(u\ge b\)、\(d_x\ge0\)，保留同父后验而不把两个来源独立于父，得到
\[
\begin{aligned}
H_{\rm source}-\int ud\,d\widehat\nu
\le{}&\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)
 E_x(B)[1-E_z(B)]\psi_x(B)\\
&+\int\widehat\nu\pi_B E_x\psi_x(B)b(B)h_1(B,x)
+\int b(B)^2d\widehat\nu.
\end{aligned}\tag{5}
\]
证明只需在 \(b\pi_Bd_x\) 中保留 \(E_xd_x\)，再代入
\(d_x\ge\psi_x(B)(1-h_1)-1\)。末项来自 \(b\pi_BE_x=b^2\)，没有错置来源均值。

按来源秩积分，\(\int b^2d\widehat\nu\le KW\)。设
\(\Phi_{\max}=e^\beta(1+\beta L)\)，则 (5) 的第二项至多
\[
\Phi_{\max}\int\mu(dx)\int_0^{\min(U_x,K)}e^{-(K-w)/T}dw
\le\Phi_{\max}TW.
\tag{6}
\]
这是一条完整有效的同父比较，但 \(\Phi_{\max}T=e^\beta(T+cL)\) 仍含线性质量宽度；第一项还保留 head/high 来源错配的真实 \(\psi_x\) 权。当前工具未把该项与 (3) 的剩余信用联合控制到根阶。此处的两来源是 raw 父后验抽样，不能赋予它们原成功记录的 low-Gram、旧 pair 或接受历史资格。将实际成功核换成 raw 核的上放没有保留那些门，因此不能在 (5) 上无价调用其几何信用。

作为判断标尺，更小的势 \(1+(U_x-v_x(A))/T\) 的无门 Volterra 缺陷为零；有门时仅剩
\[
1_{w<K}\left[\frac hT+\frac{(U_x-K)_+}{T}(1-e^{-h/T})\right],
\qquad h=\min(U_x,K)-w.
\]
它说明优化纯来源包络会直接回到 rank 门费用，不能单凭更小势认定付款。本轮因此保留 (3)–(5) 作为有限、可计算的判据，未取得新的根阶费用；first/last edge 转移或实际成功族信用若要进入，仍需同一接受测度上的额外比较。本稿不将任何守恒式或新增名称计作闭合。

## 4. 已执行的短符号／有理检查

以下检查分段积分、门端点及 (5) 的标量方向；不是原生高维场或原 history 认证。连续 mark 的三个既有有限模型由独立 numeric 稿核验，本稿不把它们声称为自己的运行结果。

```python
import sympy as s
from fractions import Fraction as F
a=s.symbols('a', real=True)
e=s.E
checks=0
def integ(lo,hi):
    out=0
    if lo<min(hi,1):out+=s.integrate(2*e*s.exp(-a),(a,lo,min(hi,1)))
    if max(lo,1)<hi:out+=s.integrate(e*(3-a)*s.exp(-a),(a,max(lo,1),hi))
    return s.simplify(out)
assert s.simplify(integ(0,2)-(2*e-1))==0; checks+=1
for D in [s.Rational(1,2),s.Integer(1),s.Rational(3,2),s.Integer(2)]:
    for delta in [s.Integer(0),s.Rational(1,2),s.Integer(3)]:
        h=min(D,delta)
        d=2*e-1-integ(h,D)
        gate=integ(0,h); tail=integ(D,2)
        assert s.simplify(d-gate-tail)==0; checks+=1
for p in [F(0),F(1,4),F(1,2),F(1)]:
    for psi in [F(1),F(2),F(5)]:
        hit=F(1,3)
        low=max(F(0),psi*(1-hit)-1)
        lhs=p*psi-p*p*low
        rhs=p*(1-p)*psi+p*p*psi*hit+p*p
        assert lhs<=rhs; checks+=1
D,h=s.symbols('D h',nonnegative=True)
expr=s.integrate((1+D-a)*s.exp(-a),(a,0,h))
assert s.simplify(expr-(h+(D-h)*(1-s.exp(-h))))==0; checks+=1
print(f'{checks} symbolic/Fraction assertions PASS; envelope splitting, same-parent bound, rank benchmark only.')
```

实际 stdout：`26 symbolic/Fraction assertions PASS; envelope splitting, same-parent bound, rank benchmark only.`
