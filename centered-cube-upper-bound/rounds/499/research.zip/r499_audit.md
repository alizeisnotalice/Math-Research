# R499 独立终审

FINAL PASS（限定范围）。三项正 slack 分解、有限步信用与真实终端、同一 rank 停止路径的首边/末边/累计边桥均成立。本轮**没有新的根阶付款**，没有证明严格吸收；完整目标与原母账仍未闭合。

独立 PRE 先核停止守恒及有限信用终端，再审最终白名单七件。未发现必要修补项，认证范围如下。

- **slack 与终端。** 来源实际 ceiling、mark 和原 rank/void 保留；g(D*)=exp(β)>0，d_gate+d_slack+d_tail=d_x 的三项均非负且分解精确。有限 u_N 是 rank 停止概率部分和，不是未加权 Green；u−u_N=K₀^N u、d_max 及分数质量帽给文中尾价。选 N 只能支付未收回信用的尾，不能使 H_source−∫u_Nd 自动获得几何上界。未加权 ∫d=H_source+E_source−R_τ 只恢复停止守恒，不能免费将 u 改成1。
- **同父一次比较。** u≥b_R、d_x≥0 产生 proof(5) 的 head/high 错配、带 b_R 的边界指数项和 b_R²，方向与来源均值位置正确。边界价格 Φ_max T=exp(β)(T+cL) 仍含线性质量宽度；其信用未与实际 head 错配共同付款。原参数的几何尾帽没有套到不满足选参的有限小 T 模型。
- **路径桥。** 对同一核 K₀ 的真实 rank 停止路径，首边 F=νhat K₀u、末边 L_e=νhat G K₀b_R、累计边 O=νhat G K₀u，零长度路径保留。首末质量均为 I−∫b_Rνhat；O 支配它们不代表可交换。P1 的端点势差、P2 的相邻边差 w(A,B)−w(B,C) 符号及顺序正确；有界 G、有限 νhat 和有界测试保证绝对可积。log-mass 的非负跨度仅给≤LI，不能把 I 改成已付 W。
- **几何同权范围。** 原祖先 outside 权 G(A)b_R(B) 与势差质量项的 u(B) 不同。共同 Q 的来源/质量分母换序准确，外部子测度的密度缺陷不能跨权直接抵扣。拆开 d_x 后保留的基线可为负，丢掉它需付整份 I；这不能产生小于1的恢复系数。人工外部来源不获原 head/history 资格，raw 路径亦未自动继承原 low-Gram 见证。

**独立实际复现。** 指定 Python `-I` 隔离重放 main15、geometry3、proof26、numeric266，共310项报告核验单位；全部 stdout 与冻结 replay 一致。numeric JSON 仅去 compute_index.seconds 后逐字段一致，规范 SHA256 为 `8aff8b79c0489247ac8f477ad723f4ad5130288c501b4389742e1bb4a7a4f67a`。数值复用三例有限原子来源/有限父的连续 mark 模型，N=1/2/4 的多项式×指数卷积、共振与初值保留；形式环恒等式精确、Arb384位作值/符号包围。其有限信用分解不认证原 L¹/Lebesgue 困难流或一般根阶估计。没有从有限样本排除原几何路线。

原一次 τX、非rank收据、R498混合/empty价、入口倍率及其他全尺度未付槽不变。真正未付的是同权 head/slack 联合几何及所需相邻边变化的来源价；本报告只认证准确接口和无新付款的结论。

## 最终输入绑定

- `r499_main.md`: `5419e8b7fd02bfcec699d8e574d00a7202cc67be43fd4b1821a26b4c9d6a6c3c`
- `r499_geometry.md`: `e42c1cacfe7ddd750bae5e8a026cd23c797a4a8092c56121df16c36aa2929d24`
- `r499_proof.md`: `479264281d92157f2d633deaadf0f167a2aceb91dee9c1e708db429f99f7f5d8`
- `r499_numeric.md`: `1f99503b118073b515a7ecb6b6a617342cc0d91b7993465e86e1ef8cfa3c3c8e`
- `r499_numeric.py`: `086943dcddb9952793883b8d7952dea66969c3f5bda905af381153e40e10a1d9`
- `r499_numeric.json`: `182dbdb9f4273df56564e171153251a947c00c0acb0a84adeb17f5f45d692be9`
- `r499_replay.json`: `1f58c0ef71cd9880d13d802fd7b0d143aca9cfb43d245d46dd472fcb717ca37b`
