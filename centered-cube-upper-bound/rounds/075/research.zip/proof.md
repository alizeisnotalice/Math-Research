# 中心立方体第75轮：软层覆盖反例、远尾统一支付与定价证书

2026-10-11。**一般目标 C_n^square <= sqrt(n)n^{o(1)} 仍未证明。** 保留的全一般基准为 O(n log n)。本轮没有把有限模型、条件覆盖或反例排除当成主定理。原始赢家路线的维数一致覆盖仍是未解决接口；旧的未截断物理门软层覆盖则已被反例否定，应从待证主依赖中删除。

## 本轮目标、已证明结果及准确缺口

本轮以一般有限 t 覆盖为目标，检查固定代表的价格结构、软层完整真实分支，以及可扩大的数值分离器。沿用原始源质量、Lebesgue 接收点和完整同距离到达批次，不更换观察点分布，不把未筛选尺度重复计费。

1. **覆盖结构，已证。** 固定代表的可行价格多面体是贪心边际向量凸包加正正交锥；对所有代表取交集才得到全对偶。优化代表后的列系数既不普遍超模也不普遍次模，反例使用完整真实阈值带。任意相距超过总质量阈值半径的来源块，其 T、B_t、O_t 精确相加；递归拆分把所有输入无损归约到按自身质量半径连通的终端块，无层数收费。连通块的统一覆盖未证。
2. **旧软层覆盖，已否定。** 固定 n=2、delta=1/2、L=1、B=2，互异微观原子及趋零阈值使完整实际低背景分支上的物理门容量覆盖 B_t/T 趋零，每个固定 t>0 都成立。证明同时控制完整分支分母、所有固定代表和所有容量包，不是任意接收子集的反例，也不是弱型常数反例。
3. **全部软层远尾，已支付。** 对任意源和任意有限物理尺度族 Jcal subset [1,2]，R_n(a)=1+2 log[2n(1+n log2)]+2a。将每层按源位移 ||x-y||_infinity>R_n(a)L 截断，所有 delta_s=2^(-s) 层满足 integral sum_s max_L |T_(s,tail,L)f| <=2 exp(-a)||f||_1。半径仅 O(log n+a)，同一质量一次收费；不需要逐层弱范数相加。尚未处理近区主项和所有倍尺度窗口的最终回代。
4. **新近区接口，部分已证。** 按实际费用归一化的逐源核支配门修复上述深尾反例。包围盒正核包络与混合物理门有严格支付式；网格可覆盖任意源的全部截断核心，但费用仍为 O(n log n)。真实均匀盒近区子事件排除便宜的 bbox-only 普遍覆盖；该反例体积小且整源物理门可满覆盖，不否定完整分支、混合门或付费异常集方案。
5. **可复现数值接口，已证有限范围。** q=2 的每个固定代表可精确最小割分离全部来源子集。q=1+1/k 用有理凸包近似及辅助节点最小割；误差为 epsilon*s，通过共同来源容量得到 epsilon*T，总误差不乘原子数。任何有限库上界都不能冒充连续代表或 Lebesgue 积分上界。

近区剩余任务是构造共同来源的混合门/核支配包，或直接的弱体积预算，支付全部边界不匹配及异常集，达到维数允许的总费。既不能保留被否定的全域物理门假设，也不能把指数包围盒价格藏入常数。当前没有证明 sqrt(n) 阶 geom 总余项，目标保持 active。

## 数值范围与复现方法

主 q=2 试验由 S=64 初探扩到每源 S=256：10 个源，n=2..8，N=4..64；2,560 训练点及 10,240 独立验证点。10 个有限库有理区间通过审计，9 个量化模型原/对偶等目标；64点平面稠密源仅得 [0.1887409247,0.2250682406] 的十进近似，精确端点在 JSON，不能称精确最优。训练满覆盖在独立验证下降，数值笔记保留逐批 SE、宽的理想抽样 Hoeffding 半径与机器抽样限制。

目标指数试验包含 n=1,4,9,16,64、两档近似误差、150 次全子集定价对照、30 个有理 LP 证书；大 N 压力、同密度赢家并列及故意粗舍入的凸包修复均实际运行。覆盖守卫使用真实赢家；深尾数值在对数/缩放坐标中计算，不将 exp(-R) 下溢误当零；N_bound=2^24 的两行只是已证公式的参数代入，实际核求值最大 N_numeric=64。

本包只依赖 Python 标准库。父代理将代码复制到独立目录重放，两个主结果 JSON 逐字节一致，所有补充守卫退出码为0。实际时间、stdout、哈希存于 inventory.json。有限证书和浮点诊断的边界在正文逐项列明。LaTeX 以 proof.tex.txt 保存，仅做静态检查，未编译、未生成 PDF。

先在临时目录解压，保留结果文件备份，再运行 `python3 -B pricing_probe.py` 和 `python3 -B parent_pl.py`。proof.md 恰有五个 Python 块，按出现顺序对应 coverage_guard.py、soft_guard.py、envelope_guard.py、audit_guard.py、soft_audit_guard.py；后两个守卫需与两个主脚本/JSON 同目录。

```sh
python3 -B pricing_probe.py
python3 -B parent_pl.py
```

可用标准库 re 的模式 `r"```python\n(.*?)\n```"`、flags=re.S 提取五块，分别写成上述文件名再运行。检查数量恰为五，不执行未知附加块。主脚本 --pilot 仅应在临时副本运行，避免覆盖冻结 FINAL JSON。

## 技能与证据、协作和归档边界

重新核验64个 canonical 安装入口，合计277,108字节、437处直接引用均存在，与第74轮入口哈希一致。按本轮任务实际读取 B02/A04/L03、M02/B01/E03/C04、D04、A02/G02/N04 及相关方法或来源边界；入口可读及哈希一致不等于64项全部定理已验收，也不等于所有原文已全文阅读。下界及先前反例的作用是压力检验，不把特殊族替代一般目标。本轮新结论有自包含证明，不通过未读文献填补假设。

覆盖、软层和核包络子任务使用 Astra medium；数值实现与独立审计使用 6.1 Sol high。主代理整合并独立重放。GitHub 只新增本轮 README 与 research.zip，并更新项目总览；中间稿、缓存和原始文献重复副本留在仓库外。历史依赖尚未完成全量去重，未擅删旧资料。

下面按证明、数值笔记、独立审计给出完整材料。组件中的“本任务未操作 Git”描述子任务职责；最终仓库同步由主代理另行完成并验证。

# Round 75 coverage: fixed-representative price geometry and exact separated-source reduction

Status: the arbitrary-input centered-cube bound C_n <= sqrt(n)n^{o(1)} remains UNPROVED. This note proves an exact finite-t description of each fixed-representative dual constraint system, gives complete-Lebesgue-band counterexamples to supermodularity and submodularity after optimizing the representative, and removes separated source components with no loss. None of these facts provides the remaining uniform coverage of a mass-connected component. The retained general weak benchmark remains O(n log n).

## 1. Fixed input, unchanged target, and method scope

Let mu=sum_i p_i delta_{y_i}, p_i>0, with distinct sites and total mass W. Fix lambda>0, beta>1, t>0 and q=1+t. All cubes are centered, closed and axis parallel. On the original all-scale band Omega={lambda<Mmu<=beta lambda}, choose the smallest-volume complete-batch actual maximizing cube Q(x). Put F=mu(Q), M=F/|Q|, T=integral_Omega M dx, and pi_J=mu_J(Q)/F. Source receivers are null. Every integral is with respect to Lebesgue measure.

For a fixed representative c define

    f_c(J)=integral_Omega M 1{c in Q(x)} pi_J(x)^q dx,
    f_c(empty)=0,    b_J=max_c f_c(J).

The retained R73 capacity LP is

    B_t=max sum_J alpha_J b_J,
    alpha>=0,  sum_{J contains i}alpha_J<=1.

Its finite dual minimizes sum_i u_i over u_i>=0 and u(J)>=b_J for every J. The retained bounds are O_t<=B_t<=q O_t and B_t<=min(T,[1+log beta+1/t]W). The missing interface remains B_{1/sqrt(n)}>=kappa_n T with kappa_n>=n^{-o(1)}, uniformly over every physical source and threshold.

The actual objective and R74 interfaces were reread. Current M02 and B01 are used only in the finite closed-convex separation/LP scope; L03 only for exact rational guards. E03 diagnoses rather than supplies the unresolved cross-source budget. C04 was checked: its smooth qBnB hypotheses are not available for discontinuous representative gates, and no qBnB convergence result is invoked. The arguments below are self-contained finite convexity and physical cube geometry. No external theorem is claimed from an unread paper. R74 boundary/refinement stability is retained but not reproved or used as the new coverage step.

## 2. Fixed-representative supermodularity is valid for every source

For every fixed c, f_c is nonnegative, increasing and supermodular:

    f_c(A)+f_c(B)<=f_c(A union B)+f_c(A intersect B).       (75.1)

At a receiver let z=pi_{A intersect B}, a=pi_{A\B}, b=pi_{B\A}. All are nonnegative. Convexity of s^q gives increasing increments,

    (z+a+b)^q-(z+b)^q >= (z+a)^q-z^q.

Multiply by M 1{c in Q}, then integrate. The same proof gives increasing marginal increments for arbitrary nested sets, not just pairs. This proof also holds for any nonnegative finite receiver measure; the full-band application retains the original Lebesgue measure.

Subtracting a modular source price u(J) preserves supermodularity. Thus fixed-c column pricing has a real supermodular structure. No step so far permits replacing fixed c by the separately optimized c_J in (75.1).

## 3. Exact fixed-representative price polyhedra

For a permutation sigma of the N sites write P_j={sigma(1),...,sigma(j)}, P_0=empty, and define its greedy marginal vector

    d^sigma_{c,sigma(j)}=f_c(P_j)-f_c(P_{j-1}).

Every coordinate is nonnegative, and sum_i d^sigma_{c,i}=f_c([N]). Define

    D_c={u in R^N: u(J)>=f_c(J) for every J},
    G_c=conv{d^sigma_c:sigma a permutation}+R_+^N.

Then the following identity is exact:

    D_c=G_c.                                                   (75.2)

These are upward-closed polyhedra, generally not cones. The singleton inequalities already imply u_i>=0, so a separate positivity condition in D_c is redundant.

Proof of G_c subset D_c: list the elements of a subset J in sigma order. When an element i is added to the smaller set of earlier elements of J, its marginal is no larger than its marginal at the full prefix P_{j-1}, by (75.1). Telescoping over J gives f_c(J)<=sum_{i in J}d^sigma_{c,i}. Convex combinations and coordinatewise nonnegative additions preserve these inequalities.

For the converse, G_c is closed: its convex-hull summand is compact and its nonnegative-orthant summand is closed; a converging sequence of sums admits a converging subsequence of the compact summands, after which the other summands also converge. Suppose u in D_c but u not in G_c. Strict finite-dimensional separation gives a vector a with

    a dot u < inf_{v in G_c} a dot v.

Necessarily a_i>=0, since otherwise the right side is minus infinity along an orthant ray. Order the coordinates so a_{sigma(1)}>=...>=a_{sigma(N)}>=a_{sigma(N+1)}=0. Then

    a dot u = sum_{j=1}^N [a_{sigma(j)}-a_{sigma(j+1)}]u(P_j)
       >= sum_j [a_{sigma(j)}-a_{sigma(j+1)}]f_c(P_j)
        = a dot d^sigma_c.

The greedy vector belongs to G_c, contradicting separation. This proves (75.2), without importing an infinite-dimensional dual or an unverified polyhedral theorem.

There are two useful consequences.

First, if every column is required to use the same fixed c, its optimal capacity-packing score equals exactly f_c([N]). Any greedy vector is a feasible price vector with that total cost, and the full-source column with coefficient one attains it. Thus a fixed-representative packing gains nothing from subdividing the source unless other representatives or external prices are coupled to it.

Second, let H be the bounding box of all original sites. The global dual can be rewritten exactly as

    B_t=min {sum_i u_i: u belongs to intersection_{c in H} G_c}.  (75.3)

Representatives outside H may be clamped to H without losing positive captured gates, so restricting to H loses no columns. In (75.3), the convex combination of greedy marginal vectors is permitted to depend on c. The formula does not assert one common source order, does not exchange an infimum and a supremum, and supplies no bound on the number of representatives needed. The finite dual of R73 guarantees attainment even though (75.3) uses a continuum of equivalent constraint descriptions.

## 4. A physical full-band counterexample: optimizing representatives destroys supermodularity

Let R=(W/lambda)^{1/n}. Suppose all distinct source sites satisfy

    ||y_i-y_j||_infinity>2R,    i!=j.                         (75.4)

A cube capturing two different sites has side L>2R and average at most W/L^n<lambda. Thus every actual band winner captures exactly one source. For source i define v_i(x)=(2||x-y_i||_infinity)^n. Its part of the actual band is exactly

    p_i/(beta lambda)<=v_i(x)<p_i/lambda.

The source halos are disjoint. On this shell M=p_i/v_i and F=p_i. The radial volume identity |{v_i<v}|=v gives its occupation

    T_i=p_i log beta,    T=W log beta.                       (75.5)

If a representative c belongs to one of these winning cubes, then

    ||c-y_i||_infinity<=2||x-y_i||_infinity
                         <(p_i/lambda)^{1/n}<=R.

Condition (75.4) therefore makes the possible representative regions for different sources disjoint. A single fixed representative can earn positive traffic from at most one shell. Choosing c=y_i earns all of shell i. Consequently, for every q>1 and every nonempty J,

    b_J=(log beta) max_{i in J} p_i.                         (75.6)

For each fixed c, the set function f_c in this example is actually modular: it is a nonnegative multiple of one source-incidence indicator, or identically zero. Yet its optimized envelope (75.6) is not supermodular. Two equal positive masses already give b_{1}+b_{2}=2b_{1,2}>b_{1,2}+b_empty. There is also an overlapping violation: for masses (1,epsilon,1), 0<epsilon<1, A={1,2}, B={2,3},

    b_A+b_B-b_{A union B}-b_{A intersect B}
         =(1-epsilon)log beta>0.                           (75.7)

For N equal masses, sum_i b_{i}/b_[N]=N. Thus arbitrary repetition of a merge justified only by fixed-representative supermodularity can lose an unbounded source-count factor, even in dimension one.

This is not a coverage obstruction. Singleton columns attain T, and the exact dual u_i=p_i log beta obeys u(J)>=b_J. Therefore

    B_t=O_t=T

on this entire physical family. A small best single representative is not a small capacity optimum or a large weak constant. The source-capacity constraints correctly pay the many separated representatives.

Optimized coefficients are not universally submodular either. For n=1, mu=(delta_0+delta_1)/2, lambda=1/100 and beta=2, the entire actual band is (-49,-24] union [25,50), up to endpoints. Every winner there captures both sites, M=1/[2 max(|x|,|x-1|)], and T=log2. On [-1,2] the nearest-atom average is at least 1/4>2lambda, so no missing central band occurs; outside that interval the full-source average dominates. Every representative in [0,1] is contained in every band winner. Hence

    b_J=T (mu_J(R)/W)^q.

For the two singleton sets, b_1+b_2=2^{1-q}T<T=b_{1,2}; this violates submodularity for every q>1. These counterexamples concern complete Lebesgue bands and true all-scale winners, not selected receiver samples.

## 5. The exact extra debt in an uncrossing step

There is a useful quantitative replacement for false global supermodularity. Let c_A,c_B be maximizing representatives for A,B, and write I=A intersect B and U=A union B. Define directed disagreement traffic

    D_{B|A}=integral_Omega M 1{c_B in Q,c_A not in Q}
                           [pi_B^q-pi_I^q] dx,
    D_{A|B}=integral_Omega M 1{c_A in Q,c_B not in Q}
                           [pi_A^q-pi_I^q] dx.

Then

    b_A+b_B<=b_U+b_I+min(D_{B|A},D_{A|B}).                    (75.8)

Use c_A for U and c_B for I. Where both gates hold, convexity gives the supermodular inequality. Where only the c_A gate holds, pi_A^q<=pi_U^q. Where only the c_B gate holds, the exact positive remainder is pi_B^q-pi_I^q. Integrating and using b_U>=f_{c_A}(U), b_I>=f_{c_B}(I) proves the D_{B|A} bound. Swapping A and B proves the other.

Since 0<=pi_I<=pi_B<=1, the mean-value bound further gives

    D_{B|A}<=q integral_Omega M 1{c_B in Q,c_A not in Q}
                               pi_{B\A} dx.                (75.9)

Thus it is the representative-gate disagreement on exclusive source traffic that must be controlled in any uncrossing proof. It cannot be silently deleted. The separated-source example makes this debt macroscopic, but Section 6 shows why that particular debt need not be paid by merging. No estimate summing (75.8) over arbitrary repeatedly used source packets is claimed.

## 6. Exact direct sums for general separated clusters

Now partition the sources into arbitrary nonempty clusters I_1,...,I_m, with local measures mu_a and masses W_a. They may each have many atoms, nonuniform weights and internal geometry. Assume only

    dist_infinity(supp mu_a,supp mu_b)>R=(W/lambda)^{1/n}
    for a!=b.                                                (75.10)

This is weaker than (75.4). A cube that meets two clusters has side L>R and average less than lambda. Consequently every original receiver with Mmu>lambda has a unique cluster whose local maximal value exceeds lambda. Uniqueness also follows geometrically: a local witnessing cube has side at most R, and two such cubes centered at the same receiver would put points of different clusters at distance at most R. Every mixed cube is below threshold, so the original maximizing cube and its complete-batch tie rule agree exactly with that cluster's local maximizing cube.

Thus the original full band is the disjoint union of the local full bands Omega_a={lambda<Mmu_a<=beta lambda}, the actual winners agree on each piece, and

    T(mu)=sum_a T(mu_a).                                     (75.11)

For every fixed c and every original column J, with J_a=J intersect I_a,

    f_c^mu(J)=sum_a f_c^{mu_a}(J_a),
    max_a b^{mu_a}_{J_a}<=b_J^mu<=sum_a b^{mu_a}_{J_a},        (75.12)

where empty local columns have score zero. The common representative may contribute to several local pieces under (75.10); replacing the sum by a maximum requires the stronger separation 2R and is not used here.

Nevertheless the full optimum is exactly additive:

    B_t(mu)=sum_a B_t(mu_a),    O_t(mu)=sum_a O_t(mu_a).        (75.13)

For the lower bound, combine optimal local packings (or partitions); their source sets are disjoint and each local column has the same original score. For the upper bound, apply the last inequality of (75.12) to an arbitrary global packing, and restrict every global column to each cluster. In each cluster the restricted columns satisfy the same source capacities, after combining repeated local subsets. Hence each local objective is at most B_t(mu_a). For a global partition the nonempty intersections with a cluster form a genuine local partition, proving the analogous O_t bound. Equivalently, concatenating the local optimal dual prices is globally feasible because u(J)=sum_a u_a(J_a)>=sum_a b_a(J_a)>=b_J.

Under the stronger separation dist>2R, a representative cannot gate positive captured traffic from two clusters. Then (75.12) improves to the exact identity b_J=max_a b_a(J_a), recovering (75.6) for singleton clusters. Strong separation is not required for (75.13).

## 7. A source-only reduction that applies to every input

The preceding lemma gives a lossless preprocessing step for every finite positive source. For a current source block I of mass W_I, form the graph on its sites with an edge whenever

    ||y_i-y_j||_infinity <= (W_I/lambda)^{1/n}.

If disconnected, split into its connected components and repeat within each using its own mass. If connected, stop. Every actual split has at least two strictly smaller blocks, so this finite procedure terminates. The terminal blocks partition the original sources; no mass is copied. Applying (75.11)--(75.13) at each split yields

    T=sum_terminal T_I,    B_t=sum_terminal B_{t,I},
    O_t=sum_terminal O_{t,I}.                              (75.14)

All comparisons use the same lambda, beta and t. No internal tree node is charged; this is repeated exact algebra, not an unproved Carleson sum or receiver-specific first-majority selection. Terminal graphs are connected at their own mass radii. The number of terminal pieces and the depth introduce no loss.

It is therefore sufficient, and equivalently necessary for a bound intended for all inputs, to prove the desired B_t>=kappa_n T just for these terminal mass-connected sources. Their occupation-weighted coverage ratios combine by (75.14). This is a genuine all-input reduction, not an assumption that arbitrary sources already have low complexity.

It still leaves the main difficulty: connectivity supplies neither a bound on atom count nor a fixed representative capturing most cooperative packets, and a chain may have arbitrarily many sites. The local price polyhedra in (75.3) remain simultaneously constrained by many representative gates inside one terminal component. No dimension-only lower bound for that intersection's minimal total price is proved. Neither the fixed-c pricing oracle nor exact finite LP optimization proves such a bound. An estimate of the disagreement traffic (75.8) inside mass-connected components, or another finite-t source allocation argument, is still required.

## 8. Reproducible three-stage exact guard and limitations

The embedded standard-library Python uses Fraction and actual complete-distance-batch maximizing cubes. Seed is 750211. Pilot uses dimensions 1,2 and three sources; stress uses dimensions 2,3 and four sources; expanded uses dimensions 4,8 and five sources. Nested, strongly correlated and unequal-weight sources are included. It verifies fixed-c supermodularity, all greedy marginal subset inequalities, nonnegative weighted greedy minimization, fixed-cardinality capacity packings, and directed-gate uncrossing at q=2,3. These finite receiver functionals are not Lebesgue cubature.

Separate exact guards check the isolated analytic family up to dimension 16 and eight sites, its normalized primal/dual certificate, and the overlapping supermodularity violation. Multi-site separated-cluster winners are checked in dimensions 1,2,4,8; the low-threshold complete two-atom band is also checked at rational receivers. The full-band formulas and direct-sum assertions are analytic theorems above, not inferred from these samples. No growth-rate fit, floating-point feasibility claim, generic interval library, or unrun min-cut algorithm is asserted.

The parent agent develops independent pricing/min-cut code. This file owns only the proofs and guard below; it does not claim that code was independently executed here. No Git operation or TeX compilation was performed.

```python
from fractions import Fraction as F
from itertools import permutations,combinations
from random import Random
from math import comb
import json
rng=Random(750211)
counts=dict(winners=0,supermodular=0,greedy_subset=0,weighted_greedy=0,packing=0,gate_defect=0,isolated=0,cluster_winner=0,cluster_gate=0)
def winner(pts,ps,x):
 d=[max(abs(a-b) for a,b in zip(y,x)) for y in pts]
 assert min(d)>0
 best=None
 for r in sorted(set(d)):
  ids=tuple(i for i,a in enumerate(d) if a<=r)
  mass=sum((ps[i] for i in ids),F(0));v=mass/(2*r)**len(x)
  if best is None or v>best[0]:best=(v,r,ids,mass)
 counts['winners']+=1
 return best
def gate(c,x,r):return max(abs(a-b) for a,b in zip(c,x))<=r
def table(rows,ps,c,q):
 N=len(ps);ans=[F(0)]*(1<<N)
 for x,M,r,S,m in rows:
  if gate(c,x,r):
   for mask in range(1,1<<N):
    z=sum((ps[i] for i in S if mask>>i&1),F(0))/m
    ans[mask]+=M*z**q
 return ans
stages=[]
for label,dims,N in [('pilot',[1,2],3),('stress',[2,3],4),('expanded',[4,8],5)]:
 before=dict(counts)
 for n in dims:
  for kind in ['nested','correlated','unequal']:
   pts=[tuple(F((2**i)*(j+1) if kind=='nested' else i*(j+1) if kind=='correlated' else i*(j+2)+((i+j)%3),4) for j in range(n)) for i in range(N)]
   ps=[F((i+1)**2 if kind=='unequal' else 1) for i in range(N)]
   raw=[]
   for k in range(18):
    x=tuple(F(rng.randrange(-20,61),7)+F(j+1,101) for j in range(n))
    raw.append((x,*winner(pts,ps,x)))
   lam=sorted(row[1] for row in raw)[5]
   rows=[row for row in raw if lam<row[1]<=2*lam]
   assert rows
   cs=pts+[tuple(sum(y[j] for y in pts)/N for j in range(n))]
   for q in [2,3]:
    tables=[table(rows,ps,c,q) for c in cs]
    for values in tables:
     for A in range(1<<N):
      for B in range(1<<N):
       assert values[A]+values[B]<=values[A|B]+values[A&B]
       counts['supermodular']+=1
     greedy=[]
     for order in permutations(range(N)):
      d=[F(0)]*N;S=0
      for i in order:d[i]=values[S|1<<i]-values[S];S|=1<<i
      for A in range(1<<N):
       assert sum((d[i] for i in range(N) if A>>i&1),F(0))>=values[A]
       counts['greedy_subset']+=1
      greedy.append((order,d))
     a=[F(rng.randrange(8),3) for i in range(N)]
     order=tuple(sorted(range(N),key=lambda i:(-a[i],i)))
     expected=next(sum(a[i]*d[i] for i in range(N)) for o,d in greedy if o==order)
     assert expected==min(sum(a[i]*d[i] for i in range(N)) for o,d in greedy)
     counts['weighted_greedy']+=1
     # Every uniform fixed-cardinality packing obeys the one-representative bound.
     for size in range(1,N+1):
      z=sum((values[sum(1<<i for i in J)] for J in combinations(range(N),size)),F(0))/comb(N-1,size-1)
      assert z<=values[-1];counts['packing']+=1
    # Directed-gate uncrossing, verified for arbitrary reps and actual winners.
    for trial in range(24):
     ia=rng.randrange(len(cs));ib=rng.randrange(len(cs));A=rng.randrange(1,1<<N);B=rng.randrange(1,1<<N)
     ca,cb=cs[ia],cs[ib];fa,fb=tables[ia],tables[ib]
     loss=F(0)
     for x,M,r,S,m in rows:
      if gate(cb,x,r) and not gate(ca,x,r):
       piB=sum((ps[i] for i in S if B>>i&1),F(0))/m
       piI=sum((ps[i] for i in S if (A&B)>>i&1),F(0))/m
       loss+=M*(piB**q-piI**q)
     assert fa[A]+fb[B]<=fa[A|B]+fb[A&B]+loss
     counts['gate_defect']+=1
 stages.append(dict(stage=label,dimensions=dims,N=N,counts={k:counts[k]-before[k] for k in counts}))
# Full-band isolated-source analytic family: exact winner and primal/dual guards.
for n in [1,2,4,8,16]:
 for N in [2,4,8]:
  aa=[F(i+1) for i in range(N)];ps=[a**n for a in aa];D=4*sum(aa)
  pts=[tuple(F(i)*D if j==0 else F(0) for j in range(n)) for i in range(N)]
  assert D**n>2**n*sum(ps)
  for i,y in enumerate(pts):
   r=aa[i]/(2*(1+F(1,2*n)))
   for sign in [-1,1]:
    x=tuple(y[j]+sign*r/(j+1) for j in range(n));M,rr,S,m=winner(pts,ps,x)
    assert F(1)<M<F(2) and S==(i,) and rr==r
    counts['isolated']+=1
  coeff=[F(0)]+[max(ps[i] for i in range(N) if mask>>i&1) for mask in range(1,1<<N)]
  for mask in range(1,1<<N):assert coeff[mask]<=sum(ps[i] for i in range(N) if mask>>i&1)
  assert sum(coeff[1<<i] for i in range(N))==sum(ps)
  assert coeff[1]+coeff[2]>coeff[3]+coeff[0]
# Overlapping optimized-column supermodularity failure, normalized by log(beta).
p=[F(1),F(1,17),F(1)]
v=lambda A:max([p[i] for i in range(3) if A>>i&1],default=F(0))
assert v(3)+v(6)-v(7)-v(2)==F(16,17)
# General separated clusters with multi-site local actual winners.
for n in [1,2,4,8]:
 base=[tuple(F(i*(j+1),5) for j in range(n)) for i in range(3)];pw=[F(1),F(2),F(3)]
 lam=F(1,64);W=2*sum(pw);Rbound=max(F(1),W/lam)
 shift=10*(Rbound+n+1)
 allpts=base+[tuple(y[j]+(shift if j==0 else 0) for j in range(n)) for y in base]
 ps=pw+pw
 for grp in [0,1]:
  for k in range(12):
   x0=tuple(F(rng.randrange(-40,41),11)+F(j+1,103) for j in range(n))
   x=tuple(x0[j]+(grp*shift if j==0 else 0) for j in range(n))
   local=winner(base,pw,x0);whole=winner(allpts,ps,x)
   if local[0]>lam:
    assert whole[0]==local[0] and whole[1]==local[1]
    assert whole[2]==tuple(i+3*grp for i in local[2]);counts['cluster_winner']+=1
    for c in allpts:
     if gate(c,x,whole[1]):
      assert all(max(abs(c[j]-y[j]) for j in range(n))>Rbound for y in allpts[3*(1-grp):3*(1-grp)+3])
      counts['cluster_gate']+=1
# Complete low-threshold two-atom band: the optimized function is not submodular.
for x in [F(-40),F(-30),F(30),F(40)]:
 M,r,S,m=winner([(F(0),),(F(1),)],[F(1,2),F(1,2)],(x,))
 assert F(1,100)<M<=F(1,50) and S==(0,1)
for q in [2,3]: assert 2*F(1,2)**q<1
print(json.dumps(dict(status='PASS',seed=750211,scope='exact finite actual-winner guards; full-band counterfamily and direct-sum theorem are proved analytically',counts=counts,stages=stages),indent=2))
```

Actual stdout:

```json
{
  "status": "PASS",
  "seed": 750211,
  "scope": "exact finite actual-winner guards; full-band counterfamily and direct-sum theorem are proved analytically",
  "counts": {
    "winners": 660,
    "supermodular": 92160,
    "greedy_subset": 301824,
    "weighted_greedy": 180,
    "packing": 744,
    "gate_defect": 864,
    "isolated": 140,
    "cluster_winner": 50,
    "cluster_gate": 130
  },
  "stages": [
    {
      "stage": "pilot",
      "dimensions": [
        1,
        2
      ],
      "N": 3,
      "counts": {
        "winners": 108,
        "supermodular": 3072,
        "greedy_subset": 2304,
        "weighted_greedy": 48,
        "packing": 144,
        "gate_defect": 288,
        "isolated": 0,
        "cluster_winner": 0,
        "cluster_gate": 0
      }
    },
    {
      "stage": "stress",
      "dimensions": [
        2,
        3
      ],
      "N": 4,
      "counts": {
        "winners": 108,
        "supermodular": 15360,
        "greedy_subset": 23040,
        "weighted_greedy": 60,
        "packing": 240,
        "gate_defect": 288,
        "isolated": 0,
        "cluster_winner": 0,
        "cluster_gate": 0
      }
    },
    {
      "stage": "expanded",
      "dimensions": [
        4,
        8
      ],
      "N": 5,
      "counts": {
        "winners": 108,
        "supermodular": 73728,
        "greedy_subset": 276480,
        "weighted_greedy": 72,
        "packing": 360,
        "gate_defect": 288,
        "isolated": 0,
        "cluster_winner": 0,
        "cluster_gate": 0
      }
    }
  ]
}
```

Guard SHA-256 (including final newline): `215ede4447a23f6c16da9b4fd536ef8229393fa6b19dcb567a5d2973c80bb663`.
Stdout SHA-256: `b762be33a5c8bd92ada8bfbaa59267ac0636cb12ad8de7a73eeb27d7a1540412`.


# Round 75: the physical soft-packet coverage target fails, and two paid repairs

**Status.** This note proves a genuine counterexample to input/threshold-uniform finite-t coverage by the R74 physical-cube packet gates, even on the FULL actual low-background contrast branch at n=2, delta=1/2, one physical scale L=1 and B=2. It does not disprove a weak maximal estimate. Two general repairs are proved: an input/source-count-independent strong L1 payment for the far source-displacement branch in a physical window, with truncation radius O(log n), and a capacity-preserving kernel-dominance packet gate. General coverage for the remaining truncated core is still unproved. The main centered-cube goal is not completed.

R74's ray payment, same-source Cauchy, common-clock rounding, and distinct-source raw-entropy counterexample remain valid. What is newly disproved is the proposed uniform lower coverage for the UNTRUNCATED physical-gate soft score. Do not retain that assertion as an open universal lemma. No Git operation, TeX compilation or PDF creation occurred. The current D04 entry/method/cube-interface were checked for correct common-law conditioning and for the prohibition on assuming a Borel pushforward preserves volume; the proofs below are elementary and import no external entropy theorem.

## 1. Exact E2 identities used in the counterexample

Write h=1_{[-1/2,1/2]}, w(x)=integral_0^1 exp(-|x|/t)dt, phi=h*w. The R74 endpoint masks give, at n=2 and delta=1/2,

    K=(13/32)hh+(7/32)(h phi+phi h)+(5/32)phi phi,
    J=(25/104)hh+(1/56)(h phi+phi h)+(9/40)phi phi,
    I=integral J=228/455.

K has mass one, J has mass I, J<=4K, and the actual contrast satisfies |T|^2<=FC with F=mu*K_L, C=mu*J_L. Here nu=mu is positive. Outside both hard coordinate intervals, the exact formulas are

    T=-(3/16)mu*(phi tensor phi),
    F=(5/32)mu*(phi tensor phi),
    C=(9/40)mu*(phi tensor phi).                         (1)

No auxiliary smoothing kernel is substituted.

### A global comparison valid across hard boundaries

The actual phi is positive and even, phi(1/2)=integral_0^1 t(1-exp(-1/t))dt>(1/4), because e>2. Hence h<=4phi. Also log phi is globally 4-Lipschitz. On [0,1/2], |phi'|<=w(0)=1 and phi>=phi(1/2)>1/4. On [1/2,infinity), phi is a positive mixture of exponentials; its logarithmic decay rate is nonincreasing and its initial rate is at most 1/phi(1/2)<4. This last monotonicity follows from exponential tilting of the variable 1/t (or its nonnegative variance for x>1/2); the right endpoint follows by dominated convergence of the first derivative. Evenness completes the assertion.

Therefore

    (1/5)phi(z1)phi(z2) <= J(z) <=5phi(z1)phi(z2).       (2)

Indeed the all-soft coefficient is 9/40>1/5, while 16(25/104)+8(1/56)+9/40<5. If all source sites lie in [-epsilon,epsilon]^2, epsilon=1/1024, then for every receiver x and every pair of sites i,j,

    J(x-y_i)/J(x-y_j) <=25 exp(16epsilon)<50.            (3)

The estimate includes hard-boundary configurations. For equal masses 1/N this implies the original-source J-posterior tau_i<=50/N everywhere. No source coincidence is used.

### Sharp enough actual tail bounds

For u>3/2 put c=2sinh(1/2). Direct integration of h against w and v=1/t-1 give

    phi(u)=e^(-u) integral_0^infinity A(v)e^(-uv)dv,
    A(v)=2sinh((1+v)/2)/(1+v)^3.

The bounds c e^(-3v)<=A(v)<=c e^(3v/2) follow from sinh increasing, log(1+v)<=v, and (1/2)coth(1/2)<3/2. Therefore

    c e^(-u)/(u+3) <=phi(u)<=c e^(-u)/(u-3/2).           (4)

These inequalities, rather than an asymptotic equivalence, supply all constants below.

## 2. A long true low-background tail strip

Take N>=2 distinct sites y_i in [-epsilon,epsilon]^2, epsilon=1/1024, of masses 1/N. Fix the physical family {1}; its actual selector is L=1. For any real R>=1000 let

    S_R={x: R/3<=x1<=2R/3, 0<=x1+x2-R<=1/100},
    M_R=(200/51)c^2 exp(-R-1/100-2epsilon)/R^2,
    lambda_R=M_R/6,    B=2.

The strip has Lebesgue area R/300. For x in S_R and every source site, all hard factors vanish and

    M_R <=phi(x1-y_i1)phi(x2-y_i2)<=(6/5)M_R.            (5)

Here are explicit checks for (5). Set z=x-y_i. Its sum lies between R-2epsilon and R+1/100+2epsilon. For the lower bound in (4),

    (z1+3)(z2+3) <=(R+1/100+2epsilon+6)^2/4
                       <=(51/200)R^2.

For the upper bound, with a=3/2+epsilon,

    (z1-3/2)(z2-3/2)
       >=(2/9)R^2-a(R+1/100)+a^2 >=(11/50)R^2.

The worst normalized inequalities occur at R=1000, where they are rational checks; the normalized margins improve thereafter. Thus the upper/lower ratio is at most

    (51/44)exp(1/100+4epsilon)<(51/44)(51/50)<6/5.

Use exp(d)<=1/(1-d) for d=1/100+4epsilon<1 and 1/(1-d)<51/50. The lower exponential bound and all denominator estimates are positive.

Define the FULL actual low branch, not merely a chosen receiver subset,

    E_R={x: |T_1 mu(x)|>lambda_R, F_1(x)<=2lambda_R}.

By (1) and (5), S_R is contained in E_R. On S_R,

    |T|>=3M_R/16>lambda_R,
    F<=3M_R/16<2lambda_R,
    C>=9M_R/40=(27/20)lambda_R.

Hence its entire selected C-occupation satisfies

    T_R:=integral_E_R C dx >= (9/2000)lambda_R R.        (6)

Moreover C<=8lambda_R throughout E_R by C<=4F. E_R is bounded for each R, since the fixed-scale actual kernels decay at infinity and the source is finite. T_R is finite, and the usual band C>lambda_R/2 holds from Cauchy. The finite-physical-family and true-crossing requirements are thus met exactly.

## 3. Uniform upper bound for EVERY physical-gate packet configuration

Use precisely R74's column class: each nonsingleton packet P has a fixed representative c_P and gate g_P=1{c_P in Q(x,1)}, while singleton columns may be ungated. Let pi_P=(mu_P*J)(x)/C(x) and alpha_P>=0 satisfy every original-source capacity sum_{P contains i}alpha_P<=1. Every source subset is allowed; the argument does not restrict representatives, column count or optimization.

If k=|P| then (3) gives pi_P<=50k/N globally. Every representative gate is a unit cube in receiver space. Therefore for q=1+t>1,

    integral_E_R C g_P pi_P^q dx
       <=8lambda_R 50^q(k/N)^q.

Since sum_P alpha_P(k/N)^q<=sum_P alpha_P k/N<=1, all nonsingleton gated columns together contribute at most 8lambda_R 50^q. Ungated singletons contribute at most (50/N)^t T_R, because tau_i^(1+t)<=tau_i(50/N)^t and their individual capacities are at most one. These separate upper bounds remain valid for one common combined capacity family. Taking the supremum and using (6) yields

    B_t(E_R)/T_R
       <=1800*50^(1+t)/R+(50/N)^t.                       (7)

For every fixed t>0 and every proposed kappa>0, choose R and then N sufficiently large to make the right side less than kappa. All other parameters remain fixed: n=2, delta=1/2, B=2, physical family {1}, positive mass W=1. This disproves ANY input/threshold-independent positive coverage fraction for that untruncated physical-gate score, even allowing all source packets and optimal representatives. It is stronger than a raw-entropy counterexample and stronger than an obstruction on an arbitrarily isolated receiver subset.

It is not a weak-constant lower bound. At this fixed scale, the genuine unpowered C budget is integral C=I, so the whole low branch already has lambda_R|E_R|<=2I. The counterexample only defeats an unnecessarily universal intermediate coverage demand. No large n limit or N-dependent hidden constant enters the contradiction.

## 4. General repair I: pay far source-displacement tails once, at O(log n) radius

This section applies to arbitrary finite signed/complex measures nu, mu=|nu|, W=mu(R^n), including L1 inputs. It does not sum weak norms of source pieces.

**Finite-window envelope lemma [proved].** If k>=0 is integrable and decreases along each ray, and Jcal is any finite subset of [1,2], then for every R>=0,

    integral_{||z||infinity>R} max_{L in Jcal} k_L(z) dz
      <=(1+n log 2) integral_{||z||infinity>R/2} k(z)dz.   (8)

Adjoin endpoints 1,2 and sort the scales L_0<...<L_m. Ray monotonicity gives k_{L_j}>=(L_{j-1}/L_j)^n k_{L_{j-1}}. For any nonnegative sequence with that property,

    max_j k_{L_j} <= k_2+sum_{j=1}^m[1-(L_{j-1}/L_j)^n]k_{L_{j-1}}.

To verify, bound each upward increment by k_{L_j}-(L_{j-1}/L_j)^n k_{L_{j-1}}, add to the initial value, and telescope. Upon integration on the fixed outside set, every k_L tail is at most the k_2 tail because L<=2. Finally sum_j[1-exp(-n log(L_j/L_{j-1}))]<=n log2. This proves (8) without grid-size dependence. The R73 failed dimension-free strong bound is not asserted; the factor 1+n log2 remains here.

The actual K is ray-decreasing. For r>=1/2 its tail mass obeys

    integral_{||z||infinity>r}K(z)dz <=n delta exp(1/2-r). (9)

Indeed each endpoint product coordinate is hard with probability at least 1-delta; a soft coordinate has law U+V, |U|<=1/2 and density of V equal to w. The exact w-tail is 2 integral_0^1 t exp(-a/t)dt<=exp(-a). A union bound over coordinates proves (9); no independence across the chosen endpoint mixture is required.

Put D=psi_(delta/2)^tensor n-psi_delta^tensor n. Define the true source-relative tail

    D_tail,L(z)=D_L(z)1{||z||infinity>RL},
    T_tail,L nu=nu*D_tail,L.

Since |D_L|<=2K_L and L>=1, the maximal tail is bounded pointwise by mu*H_R, where

    H_R(z)=2*1{||z||infinity>R}max_{L in Jcal}K_L(z).

Tonelli, (8) and (9) give the complete source-mass payment

    ||max_L |T_tail,L nu|||_1
       <=2n(1+n log2)delta exp(1/2-R/2)W.                (10)

There is no source-count or scale-grid factor. For a>=0 choose

    R_n(a)=1+2log[2n(1+n log2)]+2a.

Then the right side of (10) is at most delta exp(-a)W. In particular the weak volume where this tail exceeds eta lambda costs at most delta exp(-a)W/(eta lambda). A legitimate crossing split is

    {max|T|>lambda} subset
       {max|T_core|>(1-eta)lambda}
          union {max|T_tail|>eta lambda},  0<eta<1.

This pays all deep-tail sources simultaneously. It removes the R-to-infinity escape in (7) at a dimension-dependent radius only O(log n+a), rather than treating the failed coverage as a remaining universal target.

The nonnegative core kernels K_R=K1_{||z||infinity<=R} and J_R=J1_{||z||infinity<=R} retain ray monotonicity, with masses at most 1 and I and J_R<=4K_R. The signed D_R=D1_{||z||infinity<=R} need not be ray-decreasing; it retains the same restricted-joint-measure Cauchy inequality |nu*(D_R)_L|^2<=F_core C_core. They have a new hard outer boundary, which must be treated honestly in any representative construction. Core coverage is not proved.

### Pay the entire telescoping tail in one strong L1 budget

For the true soft layers delta_s=2^(-s), s>=0, use the SAME R_n(a) for every layer. Formula (10), followed by monotone convergence/Tonelli for nonnegative sums, gives

    integral sum_{s>=0} max_{L in Jcal}|T_(s,tail,L)nu| dx
       <=sum_{s>=0}2^(-s)exp(-a)W=2exp(-a)W.            (10a)

In particular the sum is finite almost everywhere, and

    ||sup_{L in Jcal}sum_{s>=0}|T_(s,tail,L)nu|||_1
       <=2exp(-a)W.                                    (10b)

Thus the entire far-tail remainder in the actual telescoping decomposition is paid once, with a strong L1 bound; no per-layer weak-quasinorm sum or threshold allocation is required. This is stated for a finite physical family, as required by the window objective. No unproved passage to an arbitrary continuous-scale selector is appended. The near-core series and the positive base kernel still require their own estimates.

## 5. General repair II: per-source kernel-dominance gates with an explicit fee

Fix a ray-decreasing positive kernel k of mass m (K or J, or an appropriately gated truncated version). Let G=mu*k_{L(x)} on an actual band A={a<G<=b} intersected with the chosen event. For a source packet P, fixed representative c, and fixed A0>=1 define

    g_(P,c,A0)(x)=1{ k_L(x-y_i)<=A0 k_L(x-c) for every i in P }.

This is a Borel gate using the same original source and physical selector. It is stronger than an aggregate inequality, so it survives assigning only a subset of P during rounding. On the gate, u_P=mu_P*k_L<=A0 w_P k_L(x-c). The R74 ray-envelope proof, now with envelope mass A0 m w_P, yields

    integral_A G g_(P,c,A0) pi_P^(1+t) dx
       <=[1+log(b/a)+1/t] A0 m w_P.                     (11)

Normalize the column score by 1/A0. Source capacities remain sum_{columns containing i}alpha<=1, with the ACTUAL original masses charged once. Then every feasible family has

    sum_columns (alpha/A0) integral_A G g pi_P^(1+t)
       <=[1+log(b/a)+1/t] m W.                          (12)

The pointwise score is <=1, since A0>=1. Ungated singleton columns have A0=1,c=y_i and supply full coverage at t=0. The physical-gate columns from R74 may also be retained as a separate paid column type. One must not omit the factor 1/A0 or hide A0 in an absolute constant.

The common-clock rounding proof transfers with factor 1+t. After assignment P' subset P, the retained gate is valid for P', and the maximal allowed dominance gate can only grow; keep the same c and A0. The coefficient 1/A0 is fixed during conditional Jensen. Thus the source-capacity optimum lies between the genuine common-partition optimum and (1+t) times that optimum, for this expanded normalized column class. This is payment and rounding, not a general lower-coverage theorem.

### The new gate actually repairs the counterexample

For the whole clustered source in Sections 1--3, choose c=0 and A0=50. Equations (2) and the log-Lipschitz bound give J(x-y_i)<=50J(x) for every receiver, not only in the balanced strip. Thus the whole-source column is gated everywhere and has pi_P=1. Its normalized score is exactly T_R/50 on the FULL actual low branch. The new optimum consequently satisfies B_t^dom(E_R)>=T_R/50 for every t>=0, uniformly in R,N. This is a strict repair of the demonstrated obstruction, with its fee explicitly paid.

### Dimension and softness losses outside that example

For general n, define Pphi=phi^tensor n and

    C_K={ (4-3delta/2)^n+(4-3delta)^n }/2,
    q_all={ (delta/2)^n+delta^n }/2,
    j_all=2delta^n(1-2^(-n))^2/(1+2^(-n)).

Then q_all Pphi<=K<=C_K Pphi and j_all Pphi<=J<=4C_K Pphi. Hence a source packet of l1-radius D about c, with L>=L_min, admits a global dominance factor no larger than

    A_K=(C_K/q_all)exp(4D/L_min),
    A_J=(4C_K/j_all)exp(4D/L_min).                       (13)

These can be exponential in n and severe as delta tends to zero; (13) is not a subpower solution. A sharper local statement has no such coefficient ratio: on the gate where every source site and c have exactly the SAME hard-coordinate indicators in every coordinate, each mask product has ratio at most exp(4D/L), so both K and J have A0=exp(4D/L_min). A hard-boundary mismatch, including the new core truncation boundary, is not automatically covered. Producing common packets with small paid A0 while paying all mismatch volume remains an open geometric task.

## 6. Random translation representation: exact identity, failed free transfer

Let H=h^tensor n and rho_m be the product shift law with a delta_0 coordinate for each hard factor and a w-density coordinate for each soft factor. Then k_m=H*rho_m. Thus K=H*rho_K with rho_K=sum q_m rho_m, while J=I H*rho_J with rho_J=I^(-1)sum q_m zeta_m^2 rho_m for I>0. Consequently

    mu*K_L(x)=integral A_L mu(x-Lz)rho_K(dz),
    mu*J_L(x)=I integral A_L mu(x-Lz)rho_J(dz).           (14)

These are exact positive formulas. For a receiver-dependent L(x), the map x->x-L(x)z need not preserve Lebesgue measure or even have a nonzero Jacobian. For example in one dimension, z=1 and L(x)=x on [1,2] collapse the interval to zero. This conditional example alone is not a counterexample to an averaged weak inequality, but it blocks a free change of receiver variables. Moreover a representative c for the shifted receiver corresponds to c+L(x)z in the original physical cube, which is generally not a fixed common representative. Finally convexity gives the wrong Jensen direction for turning averages of conditional packet-power scores into a lower bound for a common mixed score. No conditional weak norms are averaged here. A valid transfer would have to pay these exact common-source, volume and gate costs.

## 7. Updated minimum unresolved interface

The original general weak goal remains unproved. The untruncated uniform physical-gate coverage assertion is now false and removed from the proof dependency list. The far source-displacement branch is genuinely paid by (10), uniformly for all input measures. What remains is a dimension/softness-controlled coverage or weak-volume argument for the truncated core at radius R_n(a)=O(log n+a), using physical gates, normalized kernel-dominance gates, or another common-source construction, with all hard-boundary mismatches charged. The exponential factors in (13) cannot serve as the required subpower budget. No full-scale localization or final n^(1/2+o(1)) estimate has been completed.

## 8. Reproducible guard and numerical limits

The embedded guard verifies exact mask coefficients and rational strip constants, then runs three true-E2 far-tail stages at R=1000,3000; 10^5,10^6; 10^8,10^10, with 4,16,64 actual distinct source sites respectively. It never forms exp(-R). Instead it uses the exact identity exp(x)x phi(x)=integral_0^infinity A(s/x)e^(-s)ds and numerical Simpson integration on [0,40]. The first attempt at 512/1024 panels was too coarse to resolve the O(1/R) analytic envelope width at the largest R; it failed that numerical assertion and was replaced by 4096/8192 panels. This was a quadrature-resolution failure, not a failed analytic inequality. The reported refinement difference is diagnostic rather than a certified outward-rounded error estimate.

The last two table rows also print the analytic bound (7) with N_bound=2^24; this is evaluation of the proved all-N formula, NOT a numerical evaluation of that many atoms. N_numeric records the actual kernel source count. The additional tail-payment guard checks 189 actual-E2 pointwise finite-grid envelopes, 60 radius-fee identities, and six exact finite geometric layer sums. No spatial integral, all-packet optimization or asymptotic exponent is inferred from cubature. The counterexample and fee theorems are analytic proofs above.

Guard SHA-256: `4543cc2449c5ebfbed778e4949c92f12b98c8ab33a39b8a207b66a0b6e08de54`.

```python
import math,json
from fractions import Fraction as Q
from functools import lru_cache
counts=dict(exact_coefficients=0,strip_constants=0,actual_tail_points=0,posterior_checks=0,dominance_checks=0,scaled_refinements=0, tail_envelope_points=0, tail_radius_fees=0, tail_layer_sums=0)
a00,b00=Q(9,16),Q(1,4);a10,b10=Q(3,16),Q(1,4);a11,b11=Q(1,16),Q(1,4)
js=[2*(a-b)**2/(a+b) for a,b in ((a00,b00),(a10,b10),(a11,b11))]
assert js==[Q(25,104),Q(1,56),Q(9,40)]
I=js[0]+2*js[1]+js[2]
assert 16*js[0]+8*js[1]+js[2]<5 and js[2]>Q(1,5)
counts['exact_coefficients']+=5
eps=Q(1,1024);d=Q(1,100)+4*eps
assert 1/(1-d)<Q(51,50) and Q(51,44)*Q(51,50)<Q(6,5)
# Rational envelope denominator bounds for all R>=1000 follow monotonically
# from the following R=1000 worst-case tests; expanded rows are regressions.
for R in (1000,3000,100000,1000000,100000000,10000000000):
    a=Q(3,2)+eps
    assert Q(2,9)*R*R-a*(R+Q(1,100))+a*a>=Q(11,50)*R*R
    assert (R+Q(1,100)+2*eps+6)**2/4<=Q(51,200)*R*R
    assert Q(3,16)>Q(1,6) and Q(5,32)*Q(6,5)<=2*Q(1,6)
    assert Q(9,40)/Q(1,6)==Q(27,20)
    assert 8/(Q(27,20)/300)<1800
    counts['strip_constants']+=1
c=2*math.sinh(.5)
@lru_cache(None)
def scaled_phi(x,M):
    # Exact identity: exp(x)*x*phi(x)=integral_0^infty A(s/x)e^-s ds.
    # Simpson on [0,40]; omitted tail is positive and tiny, not interval-certified.
    def f(s):
        v=s/x
        return 2*math.sinh((1+v)/2)/(1+v)**3*math.exp(-s)
    T=40.;h=T/M
    return h*(f(0)+f(T)+sum((4 if j%2 else 2)*f(j*h) for j in range(1,M)))/3
@lru_cache(None)
def phi(x,M=256):
    x=abs(x)
    def f(t):
        if not t:return 0.
        if x>=.5:return t*(math.exp(-(x-.5)/t)-math.exp(-(x+.5)/t))
        return t*(2-math.exp(-(.5-x)/t)-math.exp(-(.5+x)/t))
    return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)
def J(z):
    h=[float(abs(v)<=.5) for v in z]; p=[phi(v) for v in z]
    return float(js[0])*h[0]*h[1]+float(js[1])*(h[0]*p[1]+p[0]*h[1])+float(js[2])*p[0]*p[1]
max_rel_refine=0.;rows=[]
# Initial, far-tail stress, expanded-radius/source-count stages.
for stage,Rs,N in ((1,(1000.,3000.),4),(2,(1e5,1e6),16),(3,(1e8,1e10),64)):
    ys=[(-float(eps)+2*float(eps)*j/(N-1),float(eps)-2*float(eps)*j/(N-1)) for j in range(N)]
    for R in Rs:
        logM=math.log(200/51)+2*math.log(c)-R-.01-2*float(eps)-2*math.log(R)
        # Work with logarithms after adding R; never form exp(-R).
        logMplusR=math.log(200/51)+2*math.log(c)-.01-2*float(eps)-2*math.log(R)
        for frac,u in ((1/3,0.),(.5,.005),(2/3,.01)):
            x=(R*frac,R+u-R*frac)
            logs=[]
            for y in ys:
                z=(x[0]-y[0],x[1]-y[1])
                psc=[scaled_phi(v,4096) for v in z]
                refined=[scaled_phi(v,8192) for v in z]
                max_rel_refine=max(max_rel_refine,max(abs(a-b)/b for a,b in zip(psc,refined)))
                counts['scaled_refinements']+=2
                for v,vsc in zip(z,refined):
                    assert c*v/(v+3)<=vsc<=c*v/(v-1.5)
                # z1+z2=R+u analytically (opposite source coordinates).
                log_prod_plus_R=-u+sum(math.log(vsc)-math.log(v) for vsc,v in zip(refined,z))
                assert logMplusR-1e-10<=log_prod_plus_R<=logMplusR+math.log(6/5)+1e-10
                logs.append(log_prod_plus_R)
            top=max(logs);ratios=[math.exp(v-top) for v in logs]
            avg_log=top+math.log(sum(ratios)/N)
            loglambda_plusR=logMplusR-math.log(6)
            assert math.log(3/16)+avg_log>loglambda_plusR
            assert math.log(5/32)+avg_log<=loglambda_plusR+math.log(2)
            assert math.log(9/40)+avg_log>=loglambda_plusR+math.log(27/20)-1e-10
            post=[v/sum(ratios) for v in ratios]
            assert max(post)<=50/N
            counts['posterior_checks']+=1;counts['actual_tail_points']+=1
        # Analytic all-column bound, with independently expanded N in last rows.
        Nbound=max(N,2**24) if stage==3 else N
        bound=1800*50**1.5/R+math.sqrt(50/Nbound)
        rows.append(dict(stage=stage,R=R,N_numeric=N,N_bound=Nbound,physical_coverage_upper_t_half=bound))
# Known hard-boundary pressure; true J is used, not a surrogate smooth kernel.
ys=[(-float(eps),float(eps)),(0.,0.),(float(eps),-float(eps))]
for x in ((0.,0.),(.5,.5),(.5+float(eps)/2,.5-float(eps)/2),(2.,-3.),(-5.,4.)):
    center=J(x)
    for y in ys:
        value=J((x[0]-y[0],x[1]-y[1]))
        assert value<=50*center
        counts['dominance_checks']+=1
# Tail-payment stress on actual E2 K and increasing physical grids.
def K_actual(z,L,n,delta):
    a=math.prod((1-delta/2)*float(abs(v/L)<=.5)+(delta/2)*phi(v/L) for v in z)
    b=math.prod((1-delta)*float(abs(v/L)<=.5)+delta*phi(v/L) for v in z)
    return (a+b)/(2*L**n)
for stage,ngrids in ((1,4),(2,8),(3,16)):
    Ls=[1+j/ngrids for j in range(ngrids+1)]
    for n in (1,2,4):
        for delta in (1.,1/n,1/(8*n)):
            for radius in (0.,.5,.75,1.,2.,5.,10.):
                z=tuple(radius*(i+1)/n for i in range(n))
                values=[K_actual(z,L,n,delta) for L in Ls]
                bound=values[-1]+sum((1-(u/v)**n)*w for u,v,w in zip(Ls,Ls[1:],values))
                assert max(values)<=bound+1e-12
                assert sum(1-(u/v)**n for u,v in zip(Ls,Ls[1:]))<=n*math.log(2)+1e-12
                counts['tail_envelope_points']+=1
for n in (1,2,8,32,128):
    for a in (0.,1.,4.):
        R=1+2*math.log(2*n*(1+n*math.log(2)))+2*a
        for delta in (1.,.5,1/n,1/(16*n)):
            fee=2*n*(1+n*math.log(2))*delta*math.exp(.5-R/2)
            assert abs(fee-delta*math.exp(-a))<=1e-12*max(1,delta)
            counts['tail_radius_fees']+=1
for S in (1,2,4,8,16,64):
    assert sum((Q(1,2)**s for s in range(S)),Q(0))==2*(1-Q(1,2)**S)
    counts['tail_layer_sums']+=1
print(json.dumps(dict(status='PASS',counts=counts,I=str(I),seed='deterministic',
    max_scaled_phi_4096_8192_relative_change=max_rel_refine,
    scope='exact coefficients and rational envelope constants; floating true-E2 scaled-tail checks, not spatial cubature or certified quadrature',rows=rows),indent=2))
```

Actual stdout:

```json
{
  "status": "PASS",
  "counts": {
    "exact_coefficients": 5,
    "strip_constants": 6,
    "actual_tail_points": 18,
    "posterior_checks": 18,
    "dominance_checks": 15,
    "scaled_refinements": 1008,
    "tail_envelope_points": 189,
    "tail_radius_fees": 60,
    "tail_layer_sums": 6
  },
  "I": "228/455",
  "seed": "deterministic",
  "max_scaled_phi_4096_8192_relative_change": 4.84706770511698e-11,
  "scope": "exact coefficients and rational envelope constants; floating true-E2 scaled-tail checks, not spatial cubature or certified quadrature",
  "rows": [
    {
      "stage": 1,
      "R": 1000.0,
      "N_numeric": 4,
      "N_bound": 4,
      "physical_coverage_upper_t_half": 639.9316369738256
    },
    {
      "stage": 1,
      "R": 3000.0,
      "N_numeric": 4,
      "N_bound": 4,
      "physical_coverage_upper_t_half": 215.667568261897
    },
    {
      "stage": 2,
      "R": 100000.0,
      "N_numeric": 16,
      "N_bound": 16,
      "physical_coverage_upper_t_half": 8.131727983645298
    },
    {
      "stage": 2,
      "R": 1000000.0,
      "N_numeric": 16,
      "N_bound": 16,
      "physical_coverage_upper_t_half": 2.4041630560342617
    },
    {
      "stage": 3,
      "R": 100000000.0,
      "N_numeric": 64,
      "N_bound": 16777216,
      "physical_coverage_upper_t_half": 0.008090295945685149
    },
    {
      "stage": 3,
      "R": 10000000000.0,
      "N_numeric": 64,
      "N_bound": 16777216,
      "physical_coverage_upper_t_half": 0.001789974525313009
    }
  ]
}
```


# R75: ungated kernel envelopes, a general near-field cover, and its cost obstruction

**Status.** The box-envelope domination and band payment below are proved. A common grid gives genuine coverage for arbitrary finite positive sources, with no assumption on global source diameter, but its cost is `1/t = O(n log(nR))`, not `n^{o(1)}`. More seriously, a true low-contrast near-field example disproves uniform inexpensive **bbox-envelope-only** coverage when `nt -> infinity`. Physical gates repair that example, so it does not disprove a hybrid gate/envelope scheme, full-event coverage after paid exceptions, or the target `C_n <= sqrt(n) n^{o(1)}`. That target remains unproved.

This note actually read R74 `astra_soft.md` and `astra_soft.tex.txt`, and A02/G02/N04 SKILL instructions, their cube interfaces, and the provenance index output (the latter was truncated, and no external source theorem is asserted). The three skills are used as auditing rules: explicit positive domination before upper-bound transfer; capture plus payment rather than payment alone; and explicit summable error budgets. All mathematical claims proved below are elementary derivations here, not attributed to a literature theorem. No Git, compilation or PDF operation occurred. Only this file and its `.tex.txt` companion are owned by this task.

## 1. Units and actual kernels

A scale window is `[L0,2L0]`, with `L0>0`. First use dimensionless coordinates `x/L0`, source positions `y/L0`, and scales `L/L0`; henceforth the window is `[1,2]`. If packet halfwidths in original coordinates are `D_i`, write `d_i=D_i/L0`. Writing `1+2D_i` without that normalization is dimensionally wrong. Scale selectors may be arbitrary measurable functions in the window.

Let `h=1_{[-1/2,1/2]}`, `w(s)=int_0^1 exp(-|s|/v)dv`, and `phi=h*w`. Both `h,phi` are probability densities, even and nonincreasing in absolute value, of height at most one. Write `k_m(z)=prod_i k_{m,i}(z_i)` with each factor `h` or `phi`. For the endpoint Bernoulli laws `a_m` and `b_m` of parameters `delta/2` and `delta`, put `q_m=(a_m+b_m)/2`, `j_m=(a_m-b_m)^2/q_m` (zero if the denominator is zero), and

`K=sum q_m k_m`, `J=sum j_m k_m`, `I=sum j_m <= min(4,2n delta)`.

Thus `K<=1`, `J<=I`, `J<=4K`. Given a finite positive measure `mu` of mass `W`, and a signed/complex measure `nu` with `|nu|<=mu`, use the same selector in `F=mu*K_L`, `C=mu*J_L`, and the endpoint contrast `T`. The same-measure Cauchy inequality gives `|T|^2<=FC`, and `|T|<=2F`. Statements below apply to arbitrary Borel source packets and countable families; finite atomic sources are not required.

## 2. A correct ungated packet envelope

Let `P` be a fixed source packet with `w_P=mu(P)>0`, in the essential axis-aligned box `c_P+prod[-d_i,d_i]`. Define

`e_{m,d}(z)=prod_i k_{m,i}((|z_i|-d_i)_+)`.

For every source point in this box and every `1<=L<=2`,

`|x_i-y_i|/L >= (|x_i-c_i|/L - d_i/L)_+ >= (|x_i-c_i|/L-d_i)_+`.

Coordinate monotonicity proves the **pointwise** domination

`sup_{y in box} (k_m)_L(x-y) <= (e_{m,d})_L(x-c_P)`.

The envelope is even and coordinatewise nonincreasing, hence decreases along every ray. By splitting the one-dimensional integral at `d_i`, its exact mass is

`int e_{m,d} = prod_i [1+2d_i k_{m,i}(0)] <= A_P:=prod_i(1+2d_i)`.

Define `E^K_P=sum q_m e_{m,d}` and `E^J_P=sum j_m e_{m,d}`. They are fixed positive ray-decreasing kernels, not receiver-dependent kernels. Their masses satisfy

`M^K_P<=A_P`, `M^J_P<=I A_P`,

and the actual packet columns satisfy `u_P^K<=w_P(E^K_P)_L(x-c_P)` and `u_P^J<=w_P(E^J_P)_L(x-c_P)`. No physical representative gate occurs. If `I=0`, the `J` branch is trivial. Measurability and the inequalities hold in the usual almost-everywhere sense for essential boxes. Unbounded boxes have infinite price and do not supply finite-budget columns.

**Band payment.** Write either `(k,m,G)=(K,1,F)` or `(J,I,C)`, `u_P=mu|_P*k_L`, `pi_P=u_P/G`. For `A subset {a<G<=b}`, `0<a<b<infinity`, and `t>0`,

`int_A G pi_P^(1+t) <= H(a,b,t) m w_P A_P`,

where `H=1+log(b/a)+1/t`. One can replace `m A_P` by the exact envelope mass `M_P`.

Here is the proof, including the issue that the dominating column need not sum to `G`. For a positive ray-decreasing kernel `e` of mass `M`, let `a_e(theta)=sup_{r>0} r^n e(r theta)`. Monotonicity gives `a_e(theta)/n <= int_0^infinity r^(n-1)e(r theta)dr`, hence `int a_e/n<=M`, and `e_L(r theta)<=a_e(theta)r^{-n}` for all scales. Since the **actual** packet obeys `u_P<=G` and `u_P<=v_P:=w_P e_L(x-c_P)`,

`G pi_P^(1+t) <= min(b,u_P,u_P^(1+t)/a^t) <= min(b,v_P,v_P^(1+t)/a^t)`.

In polar coordinates about `c_P`, put `v=r^n` and `B_theta=w_P a_e(theta)`. The radial integral is exactly

`(1/n) int_0^infinity min(b,B_theta/v,B_theta^(1+t)/(a^t v^(1+t)))dv = (B_theta/n)H`.

The two breakpoints are `B_theta/b` and `B_theta/a`; the zero case contributes zero. Tonelli and the directional mass bound conclude the proof. Measurability of the radial supremum follows from rational radii approaching from below. This transfers an upper bound by genuine pointwise domination; it does not claim the envelope columns are actual posteriors.

## 3. Capacities, exact coverage debt, and the hybrid version

A common family consists of fixed packets and coefficients `alpha_P>=0`, satisfying `sum_P alpha_P 1_P(y)<=1` for `mu`-almost every source point. The coefficients and boxes are common to the whole receiver event. Set

`Benv=(1/W)sum_P alpha_P w_P A_P`,

`S_t(x)=sum_P alpha_P pi_P(x)^(1+t)`, `T_A=int_A G`.

Positivity and source capacity give `0<=S_t<=sum alpha_P pi_P<=1`. The theorem proves

`int_A G S_t <= H m W Benv`.

It only yields the desired weak payment if there is a **separate** coverage lower bound `int_A G S_t >= kappa T_A`; that would imply `T_A<=H m W Benv/kappa`. No reverse inequality is implied by the envelope or by source capacity.

A rigorous hybrid retains the R74 gated columns at price one: a gated column has representative `c_P`, gate `g_P=1_{||x-c_P||_infinity<=L(x)/2}`, and score `g_P pi_P^(1+t)`. An envelope column has no gate and price `A_P`. Treat both as separately indexed columns even when their underlying packet is identical; **both consume the same source capacity**. For the combined score and budget,

`int_A G S_t^hyb <= H m sum_columns alpha_P w_P price_P`, `S_t^hyb<=1`.

The gated proof is `u_P<=m w_P L^{-n}<=m w_P/(2||x-c_P||_infinity)^n` on its gate, followed by the same three-piece integral using cube radial volume. Thus hybrid payment is proved. Uniform hybrid coverage remains open. Using an inexpensive gated column and an ungated envelope column for the same source without dividing capacity would double-count the source.

For low events `|T|>lambda,F<=B lambda`, one has `lambda/B<C<=4B lambda`; hence a cover of the full low event or of a paid remainder gives `lambda|A| <= B H I W Benv/kappa`. For `K` high bands the usual geometric `2^{-j}` weak-volume summation is available, provided coverage and budgets are supplied on those actual bands. No dimension-subpower bound on `Benv/kappa` is assumed here.

## 4. General near-field grid coverage, with its honest dimension cost

This construction does not require bounded global source diameter, finite source count, or separated atoms. Partition the entire source space into a fixed half-open grid of side `ell>0`, and use its nonempty cells as packets. Centers are fixed cell centers; every packet has `d_i<=ell/2`, so its envelope price is at most `(1+ell)^n`. These disjoint packets have coefficients one and consume each source exactly once; thus `Benv<=(1+ell)^n` even for countably many occupied cells.

For any positive kernel `k`, define actual near traffic

`G_near(x)=int_{||x-y||_infinity<=R L(x)} k_L(x-y)dmu(y)`.

Suppose on a measurable receiver set `A` it obeys `G_near>=(1-epsilon)G`, with `0<=epsilon<1`. The source near box has side at most `4R`, since `L<=2`. It meets at most

`M=ceil(4R/ell+2)^n`

source cells. For their normalized near contributions `v_P=u_P^near/G`, we have `sum v_P>=1-epsilon` and `pi_P>=v_P`. The elementary power-mean inequality gives the **pointwise genuine coverage**

`sum_P pi_P^(1+t) >= sum_near v_P^(1+t) >= M^(-t)(1-epsilon)^(1+t)`.

Thus `kappa=M^(-t)(1-epsilon)^(1+t)` works on every such `A`, for the actual posterior, and a common global partition suffices. Choose `ell=1/n`, so the capacity cost is at most `e`, and choose `t=1/(1+log M)`. Then `M^(-t)>=e^(-1)` and, since `t<=1`, `kappa>=e^(-1)(1-epsilon)^2`. But

`1/t=1+log M = O(1+n log(2+nR))`.

For `R=O(log n)` this is `O(n log n)`, not a subpower cost. Taking larger cells improves the count but increases `(1+ell)^n`; pretending that cell source-capacity summability removes this geometric price is incorrect. This is a complete general near-field estimate and also a quantitative statement of why this naive clustering does not meet the intended target.

If only an integrated tail budget `int_A G_tail<=D m W` is known, fix `0<epsilon<1` and define `A_bad={G_tail>epsilon G}`. The actual band's lower bound `G>a` gives `a|A_bad|<=epsilon^{-1}D m W`. This is an explicit exceptional-volume payment. It does not give pointwise near domination on all of `A`, or permit division by `G` before controlling the bad set. A chosen tail lemma must be stated with the same physical selector and window; none is inferred just from decay at one fixed scale.

### Direct application after the proved R75 tail payment

After this note's initial construction, `soft.md` Sections 1--4 were read in full. That companion proves that the old physical-gate-only score fails even on a **full** true low branch, and proves the following separate strong tail estimate for any finite scale family in `[1,2]`:

`||max_L |nu*(D_tail)_L|||_1 <= 2n(1+n log 2)delta exp(1/2-R/2)W`.

Here `D_tail(z)=D(z)1_{||z||_infinity>R}`. Its proof first establishes `int_{||z||>R}max_L k_L <= (1+n log2)int_{||z||>R/2}k` for any positive ray-decreasing kernel, and then uses `|D|<=2K` and the actual soft tail `int_{||z||>r}K<=n delta exp(1/2-r)`. This is strong L1 payment of a common convolution envelope, not a sum of weak norms.

For `R_n(a)=1+2log[2n(1+n log2)]+2a`, the fee is at most `delta exp(-a)W`. Summing the true layers `delta_s=2^{-s}` pays their entire tail by `2exp(-a)W`, with Tonelli and no hidden layer count. The crossing split must keep its explicit threshold fraction, as in `soft.md`.

This immediately removes the near-dominance hypothesis from the grid theorem **for the truncated core itself**: take `k_R=k 1_{||z||<=R}`, and let `G=mu*(k_R)_L` with its own actual band and posterior. Every core packet is bounded by the already-proved *untruncated* packet envelope, so its price is still at most `m A_P`. But the core source displacement is always at most `RL`, so only `M` grid cells can contribute and `epsilon=0` identically. Consequently the grid yields, for arbitrary finite measures and the full selected core band,

`Benv<=e`, `kappa>=e^{-1}`, `t^{-1}=1+log M=O(n log(nR))`.

Thus tails plus grid core coverage form a rigorously general interface. Its displayed polynomial dimension fee remains too large for the intended subpower return. Core truncation has new boundaries; this argument handles them by positive domination, without claiming the truncated kernel remains a product or that a physical gate automatically sees its boundary.

## 5. An actual low-contrast obstruction to cheap bbox-only coverage

This is a general impossibility result for the bbox price interface, not a finite search and not a global source-diameter assumption used to prove the target.

For every integer `n>=2`, take the positive probability density

`dmu(y)=2^n 1_{[-1/4,1/4]^n}(y)dy`, `nu=mu`, `delta=1/n`, `L=1`,

and receiver set `A=[-1/4,1/4]^n`. All displacements have absolute coordinates at most `1/2`, so every hard factor equals one. In particular all traffic is near whenever `R>=1/2`.

First, `phi<=3/4`: its maximum is at zero, and the `w` mass outside `[-1/2,1/2]` is at least `2 int_{1/2}^1 t/e dt=3/(4e)>1/4`. Let `r_i=1-phi(x_i-y_i)>=1/4`. Telescoping the endpoint products gives

`prod_i(1-r_i/(2n))-prod_i(1-r_i/n) >= (1/8)(1-1/n)^(n-1) >=1/32`.

The last bound follows, for example, from `(1+1/(n-1))^(n-1)<3<4`, using the binomial expansion bounded by `sum 1/j!<3`. Integrating proves `T>=1/32`. Since `F<=1`, this is a true low event for `lambda=1/64,B=64`.

For the empty mask put `a0=(1-1/(2n))^n`, `b0=(1-1/n)^n`, `q0=(a0+b0)/2`, `j0=(a0-b0)^2/q0`. Bernoulli's inequality gives `a0>=1/2`; `(1-1/n)^n<=e^{-1}<3/8` gives `b0<3/8`; also `q0<=1`. Hence `q0>=1/4`, `j0>1/64`. (The elementary bounds `e>8/3` and `e<3` follow from its series.) On the whole receiver set,

`1/4<=F<=1`, `1/64<C<=I<=2`.

Thus `A` is a single genuine `C` band `(1/128,3)` as well. For every measurable packet of source mass `p=mu(P)`,

`pi_P^K<=4p`, `pi_P^J<=128p`.

Now use the smallest essential source box of `P`; any larger chosen box only raises the price. Let its coordinate widths be `s_i=2d_i<=1/2`. Volume gives `p<=prod_i(2s_i)`, and convexity of `z -> log(1+exp z)` gives

`A_P=prod_i(1+s_i) >= (1+(1/2)p^(1/n))^n`.

For positive `p`, every essential width is positive; the zero-mass case is omitted. This derivation applies to disconnected packets, highly irregular measurable packets, arbitrary overlaps with fractional capacities, and any number of scales in the packet family.

Let an envelope-only family have `sum alpha_P p A_P<=Benv`. Split it at `eta=2^{-n}`. For the small-mass packets, source capacity gives

`sum_{p<=eta} alpha_P pi_P^(1+t) <= (D eta)^t sum alpha_P pi_P <= D^t 2^{-nt}`,

where `D=4` for `K` and `D=128` for `J`. Every large-mass packet has `A_P>=(5/4)^n`; thus

`sum_{p>eta} alpha_P pi_P^(1+t) <= sum_{p>eta} alpha_P pi_P <= D sum_{p>eta}alpha_P p <= D Benv (4/5)^n`.

Consequently, at every receiver in `A`, and hence also after integrating against `G`,

**`S_t <= D^t 2^{-nt} + D Benv (4/5)^n`.**

If `0<t<=1`, `nt -> infinity`, and `log Benv=o(n)`, this upper bound tends to zero. In particular, the desired combination `1/t=n^{o(1)}`, `Benv=n^{o(1)}`, and fixed positive coverage `kappa` is impossible for **all actual band subevents** in this bbox-envelope-only interface. The proof covers shared multiscale clustering automatically because it covers every source-capacity family, not merely a chosen grid or hierarchy.

**Direct target parameter.** At `t=1/sqrt(n)`, the `J` score obeys `S_t <= 128^(1/sqrt(n)) 2^(-sqrt(n)) + 128 Benv (4/5)^n`. If `log Benv=o(n)`, both terms are smaller than `n^(-A)` eventually for every fixed `A>0`: the first exponent is `-log(2)sqrt(n)+O(n^(-1/2))`, the second is `-log(5/4)n+o(n)`. Thus even coverage `kappa_n=n^{-o(1)}` is impossible for this bbox-only demand on every actual near subevent at this target parameter. This explicit conclusion still makes no claim about the full branch, the hybrid interface, or paid exceptions.

The obstruction persists if the exact mixed-envelope mass is charged: `M_P^K>=q0 A_P>=A_P/4`, and `M_P^J/I>=j0 A_P/I>=A_P/128`. Thus switching from the upper price `A_P` to exact mask masses changes only fixed constants in this example.

**Precise scope.** The receiver volume is `2^{-n}`, so `lambda|A|=2^{-n}/64`; it can be deleted with a small explicitly paid weak budget. It need not be a substantial fraction of the full selected low event. Moreover, the original physical gate of the whole-source packet, with representative zero, equals one on `A`; that single price-one gated packet has posterior one and gives perfect hybrid coverage. Thus this example does **not** refute the hybrid scheme or a full-event scheme with separately paid exceptions. It proves that paying tails alone and then demanding a cheap bbox-only cover of every near subevent cannot be a valid general proof.

## 6. What remains unpaid

A useful remaining formulation is a hybrid family on actual low/high bands together with an explicit exceptional-volume budget, satisfying both `sum alpha w price <= B_n W` and `int_good G S_t^hyb >= kappa_n int_good G`. The required return is the displayed payment factor `(1+log(b/a)+1/t)B_n/kappa_n`, with actual dimension dependence. Nothing above supplies a subpower bound for it.

A scale hierarchy is not a proof of budget: if a whole-source partition is charged at each of `q` levels, the source charge is `qW` unless coefficients have been divided so their sums respect capacity. Any claimed entropy descent must give a nonnegative paid quantity `d_j`, a uniformly bounded-below potential `H_j`, and `H_{j+1}<=H_j-d_j+epsilon_j` with controlled error sums. Then `sum_{j<q}d_j<=H_0-inf H+sum epsilon_j`. No such recurrence controlling hybrid capture loss and bbox inflation has been established here. The existence of a tree or its depth alone supplies neither capture nor packing.

The new positive information is therefore a rigorous ungated alternative with explicit geometric fee, plus a complete arbitrary-source near-field cover at its real cost. The new negative information pinpoints why that alternative cannot simply replace the cheap gates everywhere. The general weak-type target remains unproved.

## 7. Executed three-stage guard

The guard was executed with Python standard library, deterministically. Stage 1 checks rational geometric domination for both the hard and triangular probability kernels. Stage 2 checks actual E2/phi product masks with Simpson evaluation, dimensions `1,2,3,5`, and scales `1,3/2,2`. Stage 3 checks exact rational empty-mask, contrast, grid-budget, and equal-subcube fee identities for dimensions `2,4,8,16,32,64,128`. The stages passed respectively 270, 414, and 28 checks. Stage 2 is floating regression evidence, not certified quadrature or a universal proof; Sections 2--5 contain the proofs.

```json
{"status":"PASS","counts":{"stage1_exact_domination":270,"stage2_actual_mask_domination":414,"stage3_rational_bounds":28},"scope":"Stage 1 rational geometry; Stage 2 deterministic floating actual E2 values (not certified quadrature); Stage 3 exact rational obstruction and grid constants."}
```

Reproducible guard:

```python
from fractions import Fraction as Q
import math,itertools,json
cnt={"stage1_exact_domination":0,"stage2_actual_mask_domination":0,"stage3_rational_bounds":0}
def phi(x,M=512):
 x=abs(float(x))
 def f(t):
  if t==0:return 0.
  if x>=.5:return t*(math.exp(-float(x-.5)/t)-math.exp(-float(x+.5)/t))
  return t*(2-math.exp(-float(.5-x)/t)-math.exp(-float(.5+x)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)
for d,L,z,y in itertools.product([Q(0),Q(1,8),Q(1,2)],[Q(1),Q(3,2),Q(2)],[Q(-2),Q(-1,2),Q(0),Q(3,4),Q(2)],[Q(-1),Q(0),Q(1)]):
 y*=d;r=max(abs(z)/L-d,Q(0))
 for k in [lambda x:Q(abs(x)<=Q(1,2)),lambda x:max(Q(0),1-abs(x))]:
  assert k((z-y)/L)<=k(r)
  cnt['stage1_exact_domination']+=1
for n in [1,2,3,5]:
 delta=Q(1,max(n,2));ds=[Q(i+1,8*n) for i in range(n)]
 for L in [Q(1),Q(3,2),Q(2)]:
  for x0 in [Q(0),Q(1,2),Q(3,2)]:
   x=[x0+Q(i,8) for i in range(n)];y=[(-1)**i*ds[i] for i in range(n)]
   actualK=actualJ=envK=envJ=I=0.
   for mask in itertools.product((0,1),repeat=n):
    s=sum(mask);a=(delta/2)**s*(1-delta/2)**(n-s);b=delta**s*(1-delta)**(n-s);q=(a+b)/2
    j=(a-b)**2/q if q else Q(0);I+=float(j);av=ev=1.
    for i,m in enumerate(mask):
     av*=phi((x[i]-y[i])/L) if m else float(abs((x[i]-y[i])/L)<=Q(1,2))
     z=max(abs(x[i])/L-ds[i],Q(0));ev*=phi(z) if m else float(z<=Q(1,2))
    assert av<=ev+1e-12
    actualK+=float(q)*av;actualJ+=float(j)*av;envK+=float(q)*ev;envJ+=float(j)*ev
    cnt['stage2_actual_mask_domination']+=1
   assert actualK<=envK+1e-12 and actualJ<=envJ+1e-12
   assert I<=min(4,2*n*float(delta))+1e-12
for n in [2,4,8,16,32,64,128]:
 a0=(1-Q(1,2*n))**n;b0=(1-Q(1,n))**n;q0=(a0+b0)/2;j0=(a0-b0)**2/q0
 assert a0>=Q(1,2) and b0<Q(3,8) and j0>Q(1,64)
 assert Q(1,8)*(1-Q(1,n))**(n-1)>=Q(1,32)
 ell=Q(1,n);R=Q(4);M=(4*R/ell+2)**n;cost=(1+ell)**n
 assert cost<3 and M>1
 for k in [1,2,3,4]:
  mass=Q(1,2**(k*n));A=(1+Q(1,2**(k+1)))**n
  assert mass>0 and A>=1
  if mass>=Q(1,2**n):assert A>=Q(5,4)**n
  cnt['stage3_rational_bounds']+=1
print(json.dumps({'status':'PASS','counts':cnt},indent=2))
```


# Round 75: certified finite-receiver pricing at the target exponent

Status: the statements below are finite optimization identities and error bounds. They do not estimate the original Lebesgue occupation uniformly in the dimension. In particular, neither a finite representative library nor a finite training measure is the continuum problem. The general square-root upper bound remains unproved.

## 1. Shared source capacities and the correct approximation norm

Let there be N physical source indices and finitely many receiver rows r. Their nonnegative weights are nu_r; their posterior vectors a_r satisfy a_ri>=0 and sum_i a_ri=1. A representative c has a fixed gate g_rc in {0,1}. A source column J has posterior s_rJ=sum_{i in J}a_ri. All choices of J and c are common across receivers. Set T=sum_r nu_r and

    b_f(J,c)=sum_r nu_r g_rc f(s_rJ).
    B_f=sup sum_{J,c} alpha_Jc b_f(J,c),
    alpha>=0, sum_{J,c:i in J}alpha_Jc<=1 for each i.

One may take any finite library of representatives. All subsequent error inequalities also hold for an arbitrary library, with suprema, because they hold separately for every feasible packing. Empty columns have zero score and are discarded.

Suppose f(s)=s^q, q>1, and a convex piecewise-linear function F obeys

    s^q <= F(s) <= s^q + epsilon s,  0<=s<=1.             (P1)

Then

    B_f <= B_F <= B_f + epsilon T.                       (P2)

Indeed, at every row,

    sum_Jc alpha_Jc g_rc s_rJ
       <= sum_i a_ri sum_{J,c:i in J}alpha_Jc <=1.

Multiply this by epsilon nu_r and sum. This proves (P2) before taking any optimization, without needing an optimizer. The same proof works with integrals and arbitrary nonnegative receiver measures of finite total mass. It uses the actual common source capacities. A uniform absolute error epsilon, by contrast, would only give N epsilon T by the crude bound sum alpha<=N; deleting that N without the factor s in (P1) is invalid.

If all receiver weights are replaced downward by nu'_r with total difference Delta=sum_r(nu_r-nu'_r), then

    B_f(nu') <= B_f(nu) <= B_f(nu')+Delta.                (P3)

Here s^q<=s gives the same rowwise packing bound <=1. Combining with an exactly certified interval [L_F,U_F] for B_F(nu') gives

    max(0,L_F-epsilon T') <= B_f(nu) <= U_F+Delta,         (P4)
    T'=sum_r nu'_r.

If instead the true nu_r are enclosed between nu'_r and a certified upper endpoint, use the upper bound on Delta. These bounds refer to the same receiver rows and representative library throughout. They do not compensate for an untested representative or receiver.

## 2. A rational upper polygon at q=1+1/k

Fix an integer k>=1, q=(k+1)/k in (1,2], and a rational 0<epsilon_0<1. The intended square-dimension parameter is n=k^2, so t=q-1=1/sqrt(n). The construction also applies to any real q in (1,2] when certified endpoint evaluations are supplied; no interpolation in dimension is asserted here.

Take the first positive knot a=epsilon_0^k and geometric successive knots with ratio at most a rational r>1 satisfying

    q(q-1)(r-1)^2/8 <= epsilon_0.                        (P5)

End at 1, shortening the last interval if necessary. There are finitely many knots for each k and epsilon_0; their number is bounded by 2+ceil(k log(1/epsilon_0)/log r). This is an implementation-size statement, not a dimension-free complexity theorem.

The exact chord on [0,a] is a^(q-1)s=epsilon_0 s. Convexity gives 0<=chord-s^q<=epsilon_0 s. On a positive interval [a,b], the usual second-derivative interpolation estimate has an elementary proof: with H=q(q-1)a^(q-2), the function H(s-a)(b-s)/2 minus (chord-s^q) is concave with zero endpoints, since its second derivative is -H+q(q-1)s^(q-2)<=0. It is therefore nonnegative. Hence

    0<=chord-s^q<=H(b-a)^2/8<=epsilon_0 s,

where we divide by s>=a, use a^(q-1)<=1, b/a<=r, and (P5).

At each rational knot x in (0,1), the value x^q is the nonnegative k-th root of x^(k+1). Start bisection at [0,x], compare rational powers exactly, and retain an upper endpoint u_x after B iterations. Since x^q<=x,

    0<=u_x-x^q<=2^(-B)x.

Use u_0=0 and u_1=1 exactly. The polygon joining these rational upper endpoints is above f and at most f+(epsilon_0+2^(-B))s: the interpolation of the endpoint errors is at most 2^(-B)s. Thus it satisfies (P1), with epsilon=epsilon_0+2^(-B), except that its convexity has not yet been guaranteed by rounding.

Remove that issue by taking the lower convex hull of the finitely many upper nodes, including (0,0) and (1,1). Its graph C is the infimum of all convex combinations of node heights having the specified horizontal barycenter. Jensen's inequality gives f(s)<=C(s), because every upper node lies above f. Using just the two neighboring original nodes shows C(s) is no higher than the original polygon. Consequently C satisfies (P1) with the same epsilon and is convex. Equivalently, the exact rational monotone-chain construction removes a middle node whenever consecutive slopes decrease; collinear intermediate nodes can also be removed. This construction works for every finite k, even when a fixed bisection precision is insufficient to preserve the original tiny slope gaps.

Write its increasing breakpoints as theta_j. With a_0 the first slope and d_j the successive slope increases,

    C(s)=a_0 s + sum_j d_j(s-theta_j)_+, d_j>=0.          (P6)

Every number in (P6) is rational. No unverified floating interval API or assumed monotonicity of rounded slopes enters the certificate.

## 3. Exact graph-cut pricing for a fixed representative

For fixed c and nonnegative prices u_i, the separation problem is

    max_{z in {0,1}^N} [sum_r nu_r g_rc C(sum_i a_ri z_i)
                         -sum_i u_i z_i].              (P7)

The empty column is allowed in pricing, so this maximum is nonnegative. Use (P6). The source node i has unary profit

    h_i=-u_i+a_0 sum_r nu_r g_rc a_ri.

For each pair (r,j) with A_rj=nu_r g_rc d_j>0, add one auxiliary binary node eta_rj. Its unary profit is A_rj(1-theta_j), and add a directed edge from eta_rj to source node i of penalty capacity A_rj a_ri for every positive a_ri. Holding z fixed and optimizing this one auxiliary node produces

    max_{eta in {0,1}} eta A_rj[1-theta_j-sum_i a_ri(1-z_i)]
       = A_rj(sum_i a_ri z_i-theta_j)_+.

Different auxiliaries are independent given z, proving the exact reduction of (P7) to maximizing unary profits minus directed cut penalties. This is why the normalization sum_i a_ri=1 was specified. A general row total can instead be kept explicitly in the auxiliary unary profit; it must not silently be set to one.

Connect the graph source to every positive-profit node with capacity its profit, and every negative-profit node to the sink with capacity its negative profit. The selected nodes are the source side of a cut. If H_+ is the sum of positive unary profits, the cut capacity is precisely H_+ minus the modeled objective. Thus a minimum cut solves (P7). Clearing denominators produces an integer-capacity network. A certificate consists of a feasible flow, capacity and conservation checks, a source/sink separating cut, and equality of flow value and cut capacity. Weak flow/cut duality then proves optimality independently of how the candidate flow was found. Finally evaluate the selected subset directly in (P7) and verify equality, including the eliminated auxiliaries.

This is a finite fixed-representative identity. It does not solve optimization in the physical representative c. Optimizing c separately for different source columns destroys the fixed-c supermodularity, as the full-band counterexamples elsewhere in this round show.

## 4. The q=2 simplification and complete finite-library separation

When q=2, no polygon is needed. Put Q_ij=sum_r nu_r g_rc a_ri a_rj>=0. Then

    b(J,c)-u(J)
      =sum_i[(sum_j Q_ij)-u_i]z_i-sum_{i<j}Q_ij|z_i-z_j|. (P8)

Indeed sum_i(row sum Q_i)z_i counts Q_ii z_i and, for each pair, Q_ij(z_i+z_j); subtracting Q_ij|z_i-z_j| leaves 2Q_ij z_i z_j. The pair penalty is encoded by two opposite directed arcs each of capacity Q_ij; a cut pays exactly one of these arcs when its endpoints are separated. It must not pay twice the desired pair penalty.

For any finite representative library, apply the appropriate pricing oracle to every distinct gate pattern. The maximum over those calls is the exact maximum violation over every source subset and every registered representative. In a finite master LP, a feasible packing supplies a lower bound. A nonnegative source-price vector whose maximum violation is rho>=0 is repaired to u_i+rho: every nonempty subset J gains |J|rho>=rho. The corrected dual is feasible for all registered columns and has cost sum_i u_i+N rho. This is a valid global finite-library upper bound, even if the candidate prices came from floating-point optimization or an unfinished exact simplex procedure.

The additive N rho belongs in the certificate. A residual rho alone is not a rho-optimality assertion. When exact master optimization and exact pricing both terminate with rho=0, the feasible primal and dual with matching values certify the finite optimum. Exact column generation adds a previously absent positive-violation column at every nonterminal step and so terminates after finitely many additions, but the crude finite bound is exponential in N times the library size. No efficient uniform iteration count is inferred.

## 5. Scope and relation to the general route

The current B02 skill is used only for the distinction between restricted optimization and certified global separation. A04 supplies the shared-variable audit: source choices and capacities cannot change with receiver rows. L03 supplies rational certificate discipline, not a generic floating interval implementation. Their current entrances and relevant provenance/method files were read. The graph representation and approximation bounds above were proved directly, without citing an unread external paper.

The numerical implementation records actual complete-batch cube winners, exact posterior rows and representative gates. Its three stages probe small cases against exhaustive subsets, difficult correlated and heterogeneous sources, and larger source counts/dimensions. The true exponent q=1+1/k tests use rational endpoint enclosures and the epsilon T correction. Finite-row certificates remain finite-row certificates, including when all subsets are separated exactly. Held-out receiver estimates are diagnostics for selection bias; they are not continuum dual certificates. The original target still needs a dimension-only lower bound for full-Lebesgue coverage (or another complete weak branch payment), not merely an algorithm for solving each sampled model.


# Round 75: exact q2 mincut pricing and certified finite-library LP pressure

The completed probe prices all source subsets by exact mincut for each registered representative, allowing source-capacity LP column generation through 64 sites in dimensions 2–8. Nine of the ten quantized training LPs have matching rational primal/dual objectives. The dense 64-site planar case has a certified wider bracket, not a proved exact optimum. Strong training coverage still decreases under independent validation. These are finite-library, finite-training results; no unrestricted continuum LP upper bound or `C_n≤√n n^{o(1)}` theorem follows.

## Actual object, library and finite functional

Every input is a single positive finite atomic source of normalized mass one, with exact rational sites and positive integer relative weights. Every sampled receiver is interpreted as its exact binary coordinate. The code tests every complete equal-distance arrival batch of the original all-scale centered cube, selecting the smallest volume among maximizers. No receiver-dependent source regrouping, private packet band, or selected radius mesh replaces the original winner. Source receiver coincidences are excluded null points.

Let `Q*`, `F=μ(Q*)`, and `M=F/|Q*|` be the original winner, and keep `Ω={λ<M≤2λ}`. For a whole-site subset J and fixed representative c, its power score is `g_c π_J²`, where `g_c=1{c∈Q*}` and `π_J=μ_J(Q*)/F`. The source-capacity LP uses nonnegative α_J with `Σ_{J∋i}α_J≤1`. Its pointwise aggregate score is at most one, since `Σα_Jg_cπ_J²≤Σα_Jπ_J≤1`.

The registered representative library consists of every source site, the whole-source bounding-box center, and the bounding-box centers of the eight explicitly registered macro packets where present. Exact duplicate points are merged. It is fixed before receiver training. It is not an optimization over all representatives or a complete source-bounding-box arrangement. The source coordinates, weights, threshold, macro labels and all registered representatives are saved.

At training receivers x_r, put `ν_r=1_Ω(M/λ)/(S qcore)`. The unquantized finite witness is

`b_J(c)=Σ_r ν_r g_c(r)[Σ_{i∈J}a_ri]²`, `a_ri=μ({y_i})1{y_i∈Q*}/F`.

A common source subset J is chosen once; its representative is fixed across all receivers. The finite-library coefficient is `max_{c in library} b_J(c)`. This functional is an empirical full-space importance objective. Even an exact optimum or upper certificate for it does not upper-bound the continuum spatial LP, and the finite library is an additional restriction.

## Proposal, quantization and error direction

The proposal is the full three-component law from R73/R74: center uniformly over sites with probability 1/2 at volume scale `V=1/λ`; center by normalized source mass with probability 1/4 at V; and center by mass with probability 1/4 at its own scale `Va_i`. Each radial law gives half its mass to `v=bU` and half to `v=b/U`, with a normalized cube-cone angular law. Its complete dimensionless density is

`qcore=Σ_i min(1,τ_i^−2)/(4N)+Σ_i a_i min(1,τ_i^−2)/8+Σ_i min(1,(a_i/τ_i)^2)/8`,

where `τ_i=(2‖x−y_i‖∞)^n/V`. All components and centers are included at every band receiver. Ideal continuous-proposal expectations recover the original spatial occupation and packing integrals. Finite-machine sampling uses `random.Random` and ordinary floating construction; exact evaluation of realized points does not certify that their law is the ideal continuous law.

The density terms are individually enclosed by exact outward rational rounding to denominator `2^100`. If `qlo≤qcore≤qhi`, then `M/(λSqhi)≤ν≤M/(λSqlo)`. The code rounds the lower endpoint downward to `νfloor` at denominator `2^40`. An upward enclosure of each remaining error, at denominator `2^60`, is summed as Δ. Quantization is applied to the entire nonnegative receiver weight, preserving the positive quadratic structure.

For every subset and representative, `0≤b_J−b_J^floor≤Δ`. More strongly, for every capacity-feasible packing the aggregate error is at most Δ, rather than NΔ, by the pointwise aggregate bound above. Thus rational packing/dual endpoints `[L,U]` for the quantized finite library give `[L,U+Δ]` for its original unquantized receiver functional. Likewise its occupation lies in `[Tfloor,Tfloor+Δ]`. A certified ratio enclosure is `[L/(Tfloor+Δ), min(1,(U+Δ)/Tfloor)]`. These ratios concern the true finite receiver functional, not the Lebesgue continuum ratio.

## Exact pricing by mincut

For fixed c, define the nonnegative symmetric moment matrix

`G_ij=Σ_r νfloor_r g_c(r) a_ri a_rj`.

Then `b_J^floor(c)=Σ_{i,j∈J}G_ij`. For nonnegative source prices u_i, the reduced score is `b_J^floor(c)−Σ_{i∈J}u_i`. Its graph uses one node per source site, unary bias `h_i=Σ_jG_ij−u_i`, and undirected edge capacity `G_ij` for each pair i≠j. The identity

`Σ_{i,j∈J}G_ij−Σ_{i∈J}u_i = Σ_{i∈J}h_i−Σ_{i∈J,j∉J}G_ij`

gives the maximum as `Cpositive−minimum_st_cut`, where positive h_i receive source arcs and negative h_i receive sink arcs. The empty subset is allowed and has reduced value zero.

All moment entries share an exact integer scaling: for captured integer mass C_r, the denominator uses `2^40 lcm_r(C_r²)`. Price denominators are then cleared exactly. The integer Dinic implementation checks every original arc flow is within capacity, conservation at every internal node, source/sink net flow, residual cut equality, and agreement of the selected subset's direct quadratic objective with `Cpositive−flow`. No floating tolerance determines the oracle value. Representatives with identical training gate patterns share one matrix, without changing the finite library objective.

## Master LP, strict brackets and limits

The initial master contains site singletons, the full source and registered macro blocks. For each added subset, its coefficient is maximized over the entire registered library. Pricing runs across every distinct representative gate pattern, adding positively priced subsets. Final prices are rerun through every exact mincut; all final oracle values are zero, certifying the dual covers every subset in that finite library.

For small N≤8, the master uses rational simplex and is compared with an independently assembled all-subset LP. Pricing is also compared with exhaustive subsets at zero prices and three separately generated nonnegative price vectors. The final small-input comparison count is 80, all passed.

For larger inputs, an ordinary floating simplex is used only to propose a basis, with a budget of 128 pivots and repeated-basis detection. Fraction arithmetic reconstructs the basis. Negative proposed primal entries are clipped to zero and all remaining weights are divided by `max(1,maximum site load)`, giving a strictly capacity-feasible rational primal. Proposed dual prices are clipped to zero. If the largest active-column dual residual is κ, adding κ to every site price covers all active columns. Global representative pricing produces residual ρ; adding ρ to every price covers every finite-library column. The exact extra objective costs are Nκ and Nρ. The stopping threshold controls certificate width, not feasibility acceptance. An arbitrary warm basis does not inherit a claimed lexicographic perturbation termination theorem, and intermediate lower objectives need not be monotone.

The final primal lower endpoint and repaired dual upper endpoint are checked independently. When occupation first-moment prices `u_i=Σ_rνfloor_r a_ri` are cheaper, they are used instead: `gπ²≤π` proves all subset constraints, and their sum is exactly Tfloor. Every representative mincut is rerun after this substitution. The dense planar case uses this valid but potentially non-sharp upper bound.

Nine quantized cases have zero primal/dual gap. The dense planar N64 case has `L≈.1887409246886193`, `U≈.2250682405674524`, a gap `.0363273158788331`; Δ is about `8.19×10^−12`. The original repaired master price sum was about `.546134`, so its occupation-price substitute is materially stronger. This wider bracket records an algorithmic limitation of the bounded master proposal, not a mathematical coverage counterexample or an exact optimum.

## Pilot, pressure expansion and completed record

The initial three-source pilot used 64 training draws and two 128-draw validation batches per source: 192 training draws, 768 validation draws and 76 exhaustive pricing comparisons. An initial ten-source pressure run retained only 64 training draws per source: 640 training draws and 10,240 held-out draws. Its binary n8 source happened to have zero training band receivers; other large sources had only 5–9 distinct training gate patterns. Those sparse witnesses were not interpreted as absence of spatial band traffic. The final registration enlarged training to 256 draws per source while preserving independently selected held-out seeds.

Several expanded prototypes with prolonged exact master refinement were manually interrupted at the dense 64-site planar source before a final JSON was written. The final bounded basis-proposal/bracket method completes that input and records its wider gap. All interrupted production processes were stopped; no incomplete prototype is counted as a successful final result. The earlier completed pilot/pressure summaries above remain part of the development record, while the saved JSON is the final 256-draw archive.

The FINAL archive has 10 sources, 2,560 training draws, 10,240 held-out draws, 260 training band receivers, 809 active subset columns, 116 distinct representative gate patterns and 1,195 production pricing calls. All subsets are covered by the pricing certificate despite only the active columns being stored. Full source and representative definitions, training band receivers, quantized weights, primal allocations, dual prices, active coefficients, mincut summaries, individual held-out batch statistics and replay seeds are saved in a compact JSON of about 0.41 MB. The individual held-out receiver coordinates and scores are regenerated from those seeds rather than stored. No asymptotic order is fitted.

## Training ratios and both held-out batches

The table displays decimal approximations to certified finite-functional training ratio bounds. Nine intervals have width below the displayed precision; their common rounded value is marked `≈`. The dense N64 planar endpoints are also rounded approximations. These displayed decimals are not outward interval enclosures; the exact rational bounds are in JSON. Held-out cells show `mean ± one sample SE` separately for the two independent 512-draw seeds. Packing and occupation use the same receivers, so their ratio is a dependent diagnostic without a separately certified ratio interval. The frozen trained packing is a feasible continuum lower route; these sample values are estimates, not certified continuum integrals or upper bounds.

| Source | n/N | library reps | true finite-training B/T bounds, decimal approximations | frozen packing: seed 1; seed 2 | actual occupation: seed 1; seed 2 |
|---|---:|---:|---:|---|---|
| vertices4_n2 | 2/4 | 5 | ≈0.732771 | 0.40076 ± 0.04126; 0.35810 ± 0.04040 | 0.54320 ± 0.05332; 0.48390 ± 0.05216 |
| heterogeneous6_n2 | 2/6 | 7 | ≈0.806408 | 0.25902 ± 0.03631; 0.32979 ± 0.04254 | 0.50733 ± 0.05125; 0.54459 ± 0.05400 |
| unequal8_n3 | 3/8 | 9 | ≈0.685208 | 0.22776 ± 0.03100; 0.23613 ± 0.03213 | 0.42125 ± 0.04545; 0.39558 ± 0.04403 |
| macro8_n2_K2 | 2/16 | 25 | ≈0.800922 | 0.28306 ± 0.03806; 0.35341 ± 0.04174 | 0.34409 ± 0.04429; 0.47333 ± 0.04953 |
| macro8_n4_K4 | 4/32 | 41 | ≈0.943237 | 0.46352 ± 0.08581; 0.36586 ± 0.07922 | 0.69174 ± 0.10273; 0.53843 ± 0.09342 |
| macro8_n8_K8 | 8/64 | 73 | ≈1.000000 | 0.44576 ± 0.12233; 0.51067 ± 0.13028 | 0.78137 ± 0.15969; 0.61789 ± 0.14345 |
| cloud_n4_N16 | 4/16 | 17 | ≈0.848917 | 0.31026 ± 0.04580; 0.33246 ± 0.04686 | 0.47781 ± 0.05917; 0.49357 ± 0.05975 |
| cloud_n8_N32 | 8/32 | 33 | ≈0.920090 | 0.44117 ± 0.07826; 0.46189 ± 0.07819 | 0.70925 ± 0.09799; 0.60095 ± 0.08931 |
| cloud_n2_N64 | 2/64 | 65 | endpoints ≈(0.838594, 1.000000) | 0.10113 ± 0.02161; 0.12896 ± 0.02485 | 0.25760 ± 0.03748; 0.27273 ± 0.03875 |
| binary_n8_N16 | 8/16 | 17 | ≈1.000000 | 0.24310 ± 0.06169; 0.38572 ± 0.08584 | 0.52229 ± 0.08891; 0.72712 ± 0.11388 |

Three examples delimit what these numbers show. For macro8/n8/K8, the finite training ratio encloses 1, but the combined held-out packing is `.47821±.08936` against occupation `.69963±.10733`. For the binary n8/N16 source, enlarging training removes the initial zero-band witness and its finite training ratio again encloses 1, while held-out packing is `.31441±.05285` against occupation `.62470±.07224`. For the dense planar N64 source, the certified training ratio has endpoints approximately `.838594` and `1`, and the frozen packing estimates `.11504±.01647` against occupation `.26516±.02695`. These are finite training and selection effects; none bounds the best continuum packing from above.

Each nonnegative held-out score has the ideal-law range bound `8N`. The stored formal two-sided 95% Hoeffding radius is `8N sqrt(log(40)/(2·512))`, ranging from `1.92065` at N4 to `30.73033` at N64. Those radii are much wider than the SEs and are not simultaneous guarantees over this archive. They also assume exact ideal continuous sampling and evaluation; pseudorandom finite-machine construction and ordinary decimal means/SEs are not certified by the finite rational LP witnesses.

## Verification and replay

The current L02/L03 boundaries are retained: sources, constraints and search restrictions are explicit; actual tied winners are preserved; finite search and spatial theorems are separated; rational directions and capacity/dual feasibility determine certification. This module implements q=2 (t=1). The parent handles the separate convex piecewise-linear q<2 extension; no target-scale `t≈1/√n` experiment is claimed by this q2 archive.

The successful final run exited 0 in 4.629896667 seconds. A separate temporary-directory replay exited 0 in 4.622372750 seconds, with empty stderr and byte-identical JSON. The independent audit additionally reconstructed all training matrices and checked the final global pricing with a separate Edmonds–Karp implementation, and its temporary-directory replay exited 0 with empty stderr and byte-identical JSON in 4.5268 seconds. Runtime is printed and excluded from deterministic JSON. The script uses only the Python standard library and was executed with bundled Python 3.12.14. No SciPy installation, network access, Git operation, compilation, or old-round file edit was used.

To replay without overwriting the frozen archive:

```sh
TASK_PRICING_REPLAY_DIR=$(mktemp -d)
cp /Users/zhengzhihao/Desktop/T/output/centered_cube_round075_20261011/pricing_probe.py "$TASK_PRICING_REPLAY_DIR/pricing_probe.py"
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 "$TASK_PRICING_REPLAY_DIR/pricing_probe.py"
shasum -a 256 "$TASK_PRICING_REPLAY_DIR/pricing_results.json"
```

Use `--pilot` only on a temporary copy; it writes a PILOT JSON beside its script. The experiment verifies a scalable fixed-library pricing mechanism and rigorously bounds its completed finite objectives. Uniform arbitrary-source continuum coverage remains unproved.

Frozen pricing_probe.py SHA256: `f1b28fabe30e4a3696824238aed0aea12a7780e0865eb689948c290c8fdd5b6c`.

Frozen pricing_results.json SHA256: `ad03e29c3fcf87fafbf89ee1714c4fd1fb0b4320a4e23fff4763925a23a9826c`.


# 第 75 轮独立定价与列生成证书审计

**最终结论：第75轮冻结对象通过本次独立审计，未发现影响其已声明结论的实质错误。** q2 压力档案有 10 个严格有理有限库上下界，其中 9 个量化模型原/对偶目标相等；64 源二维云实例保留宽 gap。父任务的目标指数 PL 近似、graph-hinge 变换和误差预算也通过独立数学及数值核验。所有目标都是实际有限 receiver functional；本轮不是任意源或维数上界证明，`C_n≤√n n^{o(1)}` 主目标仍未证明。

## 固定共同代表的定价接口

真实输入为非负 receiver weights `w_r`、非负 source posteriors `a_ri`（每行和 1）、一份固定共同代表 c 决定的全部 closed cube gates `g_r∈{0,1}`，以及 site dual prices `u_i≥0`。定价目标是

`H(z)=Σ_r w_r g_r f(Σ_i a_ri z_i)−Σ_i u_i z_i`，`z_i∈{0,1}`。

这里 z 是同一份源子集，不可改成 receiver-dependent `z_ri`；c 也不能按 receiver 分别调整。权重、posterior 和 gates 必须从同一个实际赢家对象生成。接入下述 mincut 后，它们不再是待优化变量。

对于 `f(s)=s^q,q>1`，集合目标超模。直接证明：固定增量 a≥0 的 `f(s+a)−f(s)` 随 s 不减；集合包含只会提高 s，而所有 `w_rg_r≥0`。减去 prices 是模函数，不改变超模性。该结构允许固定代表的精确定价；这项事实不解决代表的全连续搜索。

### 凸分段线性 hinge 图

设 `f(0)=0`，`f(s)=a0·s+Σ_k d_k(s−θ_k)_+`，`d_k≥0`。以选中节点在 s-side 的约定，为每个 site 赋 profit

`p_i=−u_i+a0Σ_r w_rg_r a_ri`。

对每个 r,k 设 `A=w_rg_r d_k≥0`，引入一个辅助二元节点 y，profit 为 `A(Σ_i a_ri−θ_k)`，并加有向 penalty edge `aux→site_i`，容量 `A a_ri`。固定 z 时，选 y=1 的附加净项恰为

`A(Σ_i a_ri−θ_k)−AΣ_{i:z_i=0} a_ri=A(Σ_i a_ri z_i−θ_k)`。

选 y=0 的贡献为 0，所以消去 y 精确给 `A(s−θ_k)_+`。这不是近似 big-M，也没有强制 site 都必须被选的错误逻辑。负 node profit 可以直接使用 `node→sink` 容量；无须假定初始 slope 非负。图大小是 `N+R·K` 节点、至多 `N·R·K` 个 hinge-source arcs，真实稀疏 posterior 可减少边数。

任意图中，正 profit 用 `source→node` 容量 p，负 profit 用 `node→sink` 容量 −p。有向 penalty edges 保持上述方向。对任一 source-side 选择集，cut cost 等于“正 profits 总和−该选择集的净 profit”，因此 `max H=sum_positive_profits−mincut`。辅助节点只作精确消元，不承担选择代表或选择不同真实输入的权力。

### q=2 的更小图

令 `Q_ij=Σ_r w_rg_r a_ri a_rj≥0`。二次目标为 `Σ_i Q_ii z_i+2Σ_{i<j}Q_ij z_i z_j−u·z`，利用

`2 z_i z_j=z_i+z_j−|z_i−z_j|`

得到 site profit `Σ_j Q_ij−u_i`，以及每对 sites 的双向 arcs，各容量 Q_ij。其 cut penalty 是 `Q_ij|z_i−z_j|`，所以精确恢复原二次目标。对角项不加 pair edge。若只给双向边中的一个方向，会破坏等价；若 pair capacity 用 2Q_ij，也会产生错误因子。

本审计不声称一般整数优化问题因此可解：非负 quadratic interactions 和固定 receiver/representative 是这里的实质条件。若改成负权重、非凸 hinge 增量或自由 joint gates，该接口不能直接沿用。

## 代表范围与列生成方向

有限代表库 C 时，完整有限 LP 的列可以记作 `(J,c)`；capacity 列只依赖 J。相同 J 的低系数代表可被高系数代表支配，所以也可把其 coefficient 写成 `b_J=max_{c∈C}b_J(c)`。对每个 c 全 subset 定价后再对 C 最大化，才能检查该库的全部列。只对少量已有列、局部 representatives 或 sampled subsets 定价，不足以给库上对偶证书。

在 maximization master 中，restricted-column primal 是完整有限 LP 的下界；restricted master 的 dual 只覆盖已生成列，不能直接作完整上界。若每个 c 的全球 pricing maximum 都≤0，所得非负 u 才覆盖库中每个子集。空集目标为 0，应作为 pricing baseline，但不得作为需要生成的非空 source column。

若只知 `max_{J,c} violation≤ε`，可把每个价格改为 `u_i+ε`。每个非空 J 增价 `|J|ε≥ε`，于是得到真正完整有限对偶可行向量，目标最多增加 `Nε`。与 master 的原可行值相结合，才得到 gap bound；“ε-feasible”本身不能被写成“ε-optimal”。这里的 repair 仍只覆盖定价时列明的 receiver functional 和 representative 库。

## 独立数学自测

`audit_guard.py` 另行实现有理 Edmonds-Karp，并逐次核对最终 residual source-side cut 的 capacity 等于 flow，以及 `sumpos−cut` 等于选中节点的直接 profit。定价参考是完整枚举 source subsets，而非再次调用图公式。

所有自测 posterior 来自一个实际正原子源：位置 `0,1/8,1,3`，质量 `1,3,2,7` 归一化为 13，阈值 `λ=1/4`。独立程序对每个有理 receiver 比较所有完整到达半径，截取原带，再固定抽取 12 个 receiver；使用正有理有限 quadrature weights `M/32`。这些权重只定义有限 functional，不被称为空间积分。五个共同代表 `0,1/8,1/2,1,3` 和四组非负 prices 产生 20 个 pricing 情形。

q2 网络和三-hinge 凸 PL 网络分别与全部 16 子集穷举比对，共 40 次，首次运行退出码 0、`PASS`，约 0.0754 秒。PL 取 `a0=1/4`、hinge knots `1/4,1/2,3/4`、每个 slope increment `1/2`。该 PL 是本自测明确的函数；测试正确变换不等于对任意 q 已认证 approximation error。

## 当前技能边界

已读当前 L03（本会话第74轮）、A04、B02 的 SKILL.md 与 method/cube-interface/provenance。L03 支持明确有理包络/弱对偶核验，不能凭 Decimal 或很窄误差条声称通用 interval API。A04 在本接口中只提供“同一真实输入的 source/representative 必须共享”这一建模纪律，未调用其有缺口的最少非前视边结论。B02 要求真正全球 separation 才认证全 constraints，有限库或 sampled receivers 不被称为半无限全域证书。本轮上述变换由本地直接恒等式证明，未把技能名称或未阅读文献当作该变换的原文定理。

## 训练权重量化的无 N 误差预算

主数值对象是 `q=2`。对每个实际 band receiver，原 score 为 `(M/λ)/qcore`。逐项密度 `2^100` 向下/向上有理包络满足 `qlo≤qcore≤qhi`，因此 `score_lower=(M/λ)/qhi≤score≤(M/λ)/qlo=score_upper`。取训练样本总数 S（含 band 外零分数），以 `2^40` 向下量化 `score_lower/S` 得到 receiver weight `ν̃_r`，记录

`Δ=Σ_r ceil_{2^60}(score_upper/S−ν̃_r)`。

所以每个真实 receiver weight `ν_r` 都满足 `0≤ν_r−ν̃_r≤` 该行误差上界。给定任意可行源 packing，令 `π_{rJ}=Σ_{i∈J}a_ri`。q2、非负 weights、容量约束给

`0≤Σ_J α_J g_{r,c_J} π_{rJ}²≤Σ_J α_Jπ_{rJ}≤1`。

因此对**所有可行 packings 同时**，两目标差不超过 Δ，取 maxima 后得到

`B_quant≤B_true_finite_library≤B_quant+Δ`。

这不是把每个 column 的统一误差 Δ 直接相加；那种做法会产生最多 NΔ。这里可免 N 的理由是只量化 receiver weight，并保留同一完整 posterior 和共享 capacities。一般 PL 函数绝对误差 ε 不自动拥有同样预算：只有 `|f−PL|(s)≤η s` 的相对型控制才能直接通过 `Σαπ≤1` 得到无 N 的误差上界。

矩阵分母 `den=2^40·lcm_r(C_r²)`；实际整数源质量 w_i、captured mass C_r 给 `a_ri=w_i/C_r`。保存矩阵项应为 `Σ_r gate·weight_integer·[D/C_r²]·w_iw_j`，全部非负整数且对称。这没有 posterior 归一化成总源质量 W 的遗漏：W 已进入 winner M，posterior 的分母是当前捕获 C_r。

有限训练的 `B_true_finite_library` 仍不是空间 continuum B。冻结 packing 可以通过合法共同代表和源容量成为空间 B 的一个候选下路线；其 held-out sample mean 是该路线的估计，不能把训练有限上界或库上 global pricing 停止搬成无限空间对偶证书。

## 父任务的相对误差 PL 接口：独立推导

对于 `k≥1,q=1+1/k∈(1,2]`，令 `0<ε0<1`，首正结点 `a=ε0^k`。0 到 a 的真值弦为 `L(s)=a^(q−1)s=ε0s`。由凸性 `L≥s^q`，又 `s^q≥0`，故首段 `0≤L(s)−s^q≤ε0s`，不需要在 0 附近使用奇异二阶导数。

后续相邻结点 `[a,b]` 满足 `b/a≤r`。`f''(s)=q(q−1)s^(q−2)≤q(q−1)a^(q−2)`，于是弦误差满足

`0≤L(s)−f(s)≤q(q−1)a^(q−2)(b−a)^2/8`。

除以 `s≥a` 得到 `≤q(q−1)a^(q−1)(r−1)^2/8≤q(q−1)(r−1)^2/8`。因此只要后一个量≤ε0，整个真值 polygon 都有相对误差 ε0s。这一 `/8` 可以直接由 `H(s)=Lmax·(s−a)(b−s)/2−(chord−f)` 二阶导≤0、端点 H=0 推出，不依赖数值采样。

在结点 s，用目标 `s^(k+1)` 对 k 次方作 exact rational bisection，初区间 `[0,s]` 有效，因为 `s^q≤s`。100 步后 `lo^k≤s^(k+1)≤hi^k` 且 `hi−lo=s2^−100`；取上端 u 有 `0≤u−s^q≤s2^−100`。两结点误差上界经线性插值仍≤`s2^−100`，所以取整 polygon 有

`f(s)≤L_upper(s)≤f(s)+(ε0+2^−100)s`。

上端始终≤s，首末点是 `(0,0),(1,1)`，所以 polygon 还满足 `0≤L_upper(s)≤s`。若其 slope 非减，它立即有非负 hinge increments，适用前述 graph。微小 endpoint 扰动本身不能替代 slope 检查，也不应把仅测试有限 k 的检查写成任意 k 的自动结论。

更稳健的处理是精确 greatest convex minorant，也就是删去凹折点的 lower convex hull。由于 f 凸且 `f≤L_upper`，f 本身属于可行 minorants，故 `f≤C≤L_upper`；同一相对误差界完全保留，C 的 slopes 单调、hinge increments 非负。这项凸包处理无需重新放大误差，且不会产生需要负 capacity 的 hinge。

给所有真实 receiver 和源 packings应用 `|C(s)−s^q|≤εs`，容量恒等式 `Σ_J α_Jπ_J≤1` 给出目标差≤εT；相同 fixed-library LP 的最优值也满足该误差界。这个推导不证明库外代表分离，也不证明任意源具有足够覆盖率。

## 冻结对象的独立实际核验

独立 `audit_guard.py` 对主数据不依赖主程序断言：它从保存 seeds 重建训练 proposal 坐标，再比较所有实际到达半径，独立求 complete tied winner、posterior、密度上下包络、整 receiver 量化权重及 Δ。矩阵也从真实训练坐标和固定 gates 重新累积。仅在小 N 比对生产 oracle 时导入 `pricing_probe.py`；参考目标仍来自独立子集穷举，最终全部库定价用另外实现的 exact Edmonds-Karp，而非生产 Dinic。

最终增强守卫实际运行退出码 0、`PASS`，约 **7.0304 秒**。检查量如下：

|独立检查|实际数量|证据类型|
|---|---:|---|
|q2 训练 proposal/完整 winner 重建|2,560 receiver，260 band|有理评价实际浮点坐标；不认证理想连续 law|
|active coefficient 和最佳库代表|809 source columns|逐一对全部重建 gate matrices 最大化|
|主压力档案 primal/dual bracket|10|Fraction 容量、非负价格、全部最终全库 separation；9 个零 gap|
|最终 global pricing|116 gate patterns|独立 exact Edmonds-Karp，每个最大残差均为 0|
|小 N 生产 q2 oracle|80|四组价格/每个真实 gate matrix，与全部 subsets 穷举比较|
|另一路真实 1D fixture 自测|20 q2＋20 hinge|12 个真实 receiver、5 共同代表、4 prices，每次全部16子集|
|父 PL node/hull/hinge certificates|10 curves|raw-node root 幂比较、ratio/curvature 预算、凸包/斜率恒等式|
|父 PL pricing|150|对每个真实 receiver functional 全子集穷举|
|父 PL 完整 serialized flow witnesses|10|重建全部网络容量，逐 arc 流界、全部节点守恒、cut=flow|
|父 PL 的原/对偶 LP|30|PL、true-root lower、true-root upper 各10；全列弱对偶及目标相等|
|父 PL posterior 点|3,360|所有子集（含空集）的 `s^q≤PL≤s^q+εs` 精确幂比较|
|父 PL stress pricing|12|N16/24 真实 posteriors，独立 exact Edmonds-Karp 图重算；不称穷举|
|exact density ties|5|维数1,4,9,16,64的完整到达、最小半径密度 tie|
|coarse convex-hull regression|101 有理点|bits=1 的实际凹折点被删除，误差及上下方向仍正确|

对父 PL 系数另用独立 130 步 root bracket 重建 true coefficient 的上下参考，其更窄区间完全落入保存 true-root coefficient bounds。0、1 的 root 端点按精确恒等式处理，避免把明知精确的 1 人为扩成近似区间。完整流 witness 的每条容量由 saved source posterior、gates、hinges、prices 重新生成，不只检查文件中的布尔 `maxflow_equals_cut` 标记。

父 PL 的 finite functional 权重为明确的均匀 `ν_r=1/#rows`，属于 deterministic 诊断对象，**不是 M 加权空间积分或 importance law**。其小例规格是 k=1,2,3,4,8，n=k²，N≤8；两个 stress 是 n4/N16、n64/N24。反过来 q2 随机压力档案只使用 q=2，不能把它称为 `t=1/√n` 数值验证。两类对象及其误差预算已经在各自报告中分开。

## 大 N 有理 bracket 与明确剩余 gap

生产 large-N 浮点计算只提出一个 basis，最终接受完全由 Fraction 见证决定。basic primal 负项截为 0，再除以 `max(1,max_site_load)`，得到严格容量可行的 packing。raw dual 截为非负，并按 active/global 全局残差逐 site 加价；必要时用 occupation first-moment prices 替换。我的守卫从保存 primal 重新核对 loads/目标，从保存 prices 和全部独立 mincuts 核对上界，不依赖浮点 tolerance、迭代数或 proposed basis 的“最优”标签。

主档案唯一非零量化 gap 是 `cloud_n2_N64`：

`L≈0.1887409246886193`，`U≈0.2250682405674524`，`U−L≈0.036327315878833144`。

这是约 19.25% L 的宽间隙，不能称为 tiny residual 或 exact optimum。该例采用 `u_i=Σ_rνfloor_r a_ri` 的 occupation upper，守卫逐项核对这些价格，且其和恰为 `Tfloor`。原 repaired master upper 约 .546134，替换确实更强。global pricing 后每个库中 pattern 最大残差仍为 0。最终 unquantized finite upper 是 U+Δ，而不是 L+Δ。

此例 `Δ≈8.19×10^−12`；全部档案最大 Δ 约 `2.077675271411339×10^−11`。因此宽 gap 来自有限主问题求解预算，不来自 weight quantization，也不是数学上的 coverage counterexample。其余九个量化模型有相等有理 primal/dual 目标；加入 Δ 后仍仅得到相应有限 training functional 的 certified interval。

审计早期指出 Dinic 注释曾声称独立流守恒检查而代码只有 reverse-pointer 检查；最终冻结实现已记录原 edge index 并真实验证 `0≤flow≤capacity`、所有 internal balances、source/sink netflow 及 cut equality。另指出 warm feasible basis 不自动继承 lexicographic infinitesimal feasibility、近似 master 值不必逐轮单调；最终数值报告已明确只用 proposal 和有理 bracket，不作该终止/单调理论声称。这些早期问题均未被留在最终证书的接受逻辑中。

## 冻结哈希与独立 replay

本次实际验收对象的 SHA256：

- `pricing_probe.py`: `f1b28fabe30e4a3696824238aed0aea12a7780e0865eb689948c290c8fdd5b6c`
- `pricing_results.json`: `ad03e29c3fcf87fafbf89ee1714c4fd1fb0b4320a4e23fff4763925a23a9826c`
- `parent_pl.py`: `a9ce01eb049affdfa67f4d359606a1534a6a3ffd066d1a097bf9805115e9c05a`
- `parent_pl_results.json`: `4561ba28c7d999f843f2cde90dd102d99c6cb63dd77811652d13d54133f6a7a4`

除了 guard，分别把两份 self-contained 主代码复制到独立临时目录，使用 bundled Python 完整执行。`pricing_probe.py` replay 退出码0、empty stderr，约 **4.5268秒**，生成的结果与冻结 JSON **byte-identical**；`parent_pl.py` replay 同样退出码0、empty stderr，约 **0.6540秒**、结果 byte-identical。未覆盖原档案、未修改主代码或旧轮文件、未操作 Git。runtime 是打印字段，未进入决定性 JSON。

已快速审读 `parent_pl.md` 的 P1–P8 与对应 `.tex.txt` 内容：相对误差 norm、首段避免奇异 f''、后段 `/8` concavity、任意 k 的 exact convex hull、graph capacities、finite-library separation 与 `Nρ` repair 均在其明确假设下正确。`pricing_numeric.md` 正确公开本次范围、独立 validation 的选择效应、宽 gap、机器 proposal 与理想 law 差别。held-out seed/batch statistics 并不等于保存每个 receiver 的完整轨迹；本审计没有把 sample SE、Hoeffding ideal-law 行或小数比例升级为空间积分证书。

**剩余主缺口没有改变：** 需要在任意真实源与增长维数中建立足够的全 Lebesgue coverage，或另一条完整 weak branch payment。fixed-representative polynomial pricing、相对 PL 误差预算和成功 finite-library 优化都不能单独闭合该目标。


# R75 independent audit: full-branch soft traffic and physical packet gates

**Status (11 October 2026).** The fixed-dimension physical-gate coverage counterexample below is **proved**, including the denominator on the complete actual low-background branch. The new finite-window far-tail payment lemma and its **entire soft-layer strong-tail sum** are **proved**. A kernel-dominance gate has a **proved conditional payment theorem**, but no general optimized coverage theorem is supplied. The requested general centered-cube bound \(C_n\leq\sqrt n\,n^{o(1)}\) remains unproved. This is not a weak-type counterexample.

This audit owns only `soft_counter_audit.md` and `soft_audit_guard.py`. It does not modify the author's files, run Git, compile TeX, or create a PDF. R74 `astra_soft.md` and `astra_soft.tex.txt` were read. The R75 author supplied the exact construction directly. The complete final `soft.md` and `soft.tex.txt` were subsequently read; final-file comparison is recorded in Section 8. The proof here is independently derived, not inferred from a floating test.

## 1. Skill use and evidence boundary

The current A02, L03 and N04 SKILL.md files and their method/cube-interface references were actually read, together with their provenance descriptions. Their application is methodological:

* A02: a change of gate or truncation changes the feasible payment model; set inclusion alone does not transfer a lower coverage bound. Every objective comparison below is written explicitly.
* L03: the guard uses Python `Fraction` for exact mask identities and rational inequalities. No floating interval library or quadrature certificate is claimed. The only exponential upper bound used in its constant certificates is the elementary analytic inequality \(e^x\leq(1-x)^{-1}\), \(0\leq x<1\), proved by comparing \(x^k/k!\leq x^k\) term by term.
* N04: far-tail errors need a total threshold/volume budget before summing layers or windows. A finite-window estimate does not by itself pay infinitely many windows. No entropy descent recurrence is asserted.

No external paper is invoked as evidence for these elementary arguments.

## 2. Exact actual E2 kernels

Write \(h=\mathbf1_{[-1/2,1/2]}\), \(w(s)=\int_0^1e^{-|s|/t}\,dt\), \(\varphi=h*w\). Both \(w\) and \(\varphi\) have mass one. For \(n=2,\delta=1/2\), the four endpoint mask weights are
\[
 \alpha=(9,3,3,1)/16,\qquad \beta=(4,4,4,4)/16.
\]
Consequently, with products evaluated at the two coordinates,
\[
\begin{aligned}
 D&=\frac5{16}hh-\frac1{16}(h\varphi+\varphi h)-\frac3{16}\varphi\varphi,\\
 K&=\frac{13}{32}hh+\frac7{32}(h\varphi+\varphi h)+\frac5{32}\varphi\varphi,\\
 J&=\frac{25}{104}hh+\frac1{56}(h\varphi+\varphi h)+\frac9{40}\varphi\varphi,\\
 I&=\int J=\frac{228}{455}.
\end{aligned}
\]
These follow from \(q=(\alpha+\beta)/2\) and \(q\zeta^2=2(\alpha-\beta)^2/(\alpha+\beta)\), not from a replacement kernel. Always \(J\leq4K\) and \(|D|\leq2K\).

### Global kernel comparison: verified, with the regularity distinction retained

For \(s\geq1/2\),
\[
 \varphi(s)=\int_0^1t(1-e^{-1/t})e^{-(s-1/2)/t}\,dt.
\]
In particular \(\varphi(1/2)\geq(1-e^{-1})/2>1/4\), since \(e>2\). Evenness and monotonicity give \(h\leq4\varphi\) everywhere, including the closed hard-support boundary. Thus
\[
 \frac15\varphi(s_1)\varphi(s_2)\leq J(s_1,s_2)
 \leq5\varphi(s_1)\varphi(s_2).                 \tag{1}
\]
For the upper bound the exact coefficient is
\(16(25/104)+8(1/56)+9/40<5\); for the lower bound \(9/40>1/5\).

The function **\(\varphi\)** is globally 4-log-Lipschitz. On \([0,1/2]\), \(|\varphi'|\leq1\) and \(\varphi>1/4\). On \((1/2,\infty)\), put \(a=s-1/2\). The logarithmic derivative magnitude is the mean of \(1/t\) under the positive density proportional to \(t(1-e^{-1/t})e^{-a/t}\). It decreases with \(a>0\), because its derivative is minus the variance. Its limit at \(a\downarrow0\) is at most \(1/\varphi(1/2)<4\), by dominated convergence in numerator and denominator. Evenness gives the negative half-line, and integration gives
\[
 e^{-4|r-s|}\leq\varphi(r)/\varphi(s)\leq e^{4|r-s|}.      \tag{2}
\]
The variance argument is only differentiated for \(a>0\), where all required moments are finite. The endpoint limit uses only the first-moment formulas, not an endpoint second-moment assertion.

**Do not call \(J\) log-Lipschitz:** its hard terms jump at hard-support boundaries. The valid global source comparison uses (1) and (2), and carries their factor 25.

## 3. Near-cluster source and a true deep-tail crossing band

Fix \(\varepsilon=1/1024\). For every \(N\geq2\), choose any \(N\) distinct sites \(y_i\in[-\varepsilon,\varepsilon]^2\) and put
\(\mu=N^{-1}\sum_i\delta_{y_i}\), all signs positive. For example, the rational sites \(y_i=(-\varepsilon+2\varepsilon(i-1)/(N-1),0)\) are distinct and valid. The physical scale is identically \(L=1\), \(W=1\), and \(B=2\). Define
\[
 F=\mu*K,\quad C=\mu*J,\quad d=\mu*D,\qquad
 A=E_{\rm low}=\{|d|>\lambda,\ F\leq2\lambda\},\qquad
 T_A=\int_A C\,dx.                                      \tag{3}
\]
Throughout this note, \(T_A\) is traffic; \(d\) is contrast. This avoids using the same symbol for both.

### Tail asymptotic inequalities with explicit constants

Put \(c=2\sinh(1/2)\). For \(s>3/2\), change variables \(v=1/t-1\) to obtain
\[
 \varphi(s)=e^{-s}\int_0^\infty e^{-sv}
 \frac{2\sinh((1+v)/2)}{(1+v)^3}\,dv.
\]
The factor in the integrand lies between \(ce^{-3v}\) and \(ce^{3v/2}\). For the lower bound use \(\sinh((1+v)/2)\geq\sinh(1/2)\) and \(\log(1+v)\leq v\). For the upper bound the logarithmic derivative of the numerator is \(\tfrac12\coth((1+v)/2)\leq\tfrac12\coth(1/2)<3/2\), while \((1+v)^{-3}\leq1\). The final strict inequality follows from \(e>2\). Therefore
\[
 \frac{ce^{-s}}{s+3}\leq\varphi(s)
 \leq\frac{ce^{-s}}{s-3/2}.                              \tag{4}
\]

For \(R\geq1000\), use coordinates \(x_1\in[R/3,2R/3]\) and \(u=x_1+x_2-R\in[0,1/100]\). Their Jacobian is one, so the receiver strip
\[
 S_R=\{R/3\leq x_1\leq2R/3,\ 0\leq x_1+x_2-R\leq1/100\}
\]
has volume \(R/300\). Set
\[
 M_R=\frac{200}{51}\frac{c^2e^{-R-1/100-2\varepsilon}}{R^2},
 \qquad \lambda=M_R/6.                                 \tag{5}
\]
For all \(x\in S_R\) and all sites, (4) yields
\[
 M_R\leq\varphi(x_1-y_{i1})\varphi(x_2-y_{i2})
 \leq\frac65M_R.                                       \tag{6}
\]
Here are the denominator and exponential checks, rather than a numerical asymptotic substitution:

* The lower-tail denominator is at most
\(\bigl[(R+1/100+2\varepsilon+6)/2\bigr]^2\leq(51/200)R^2\), by AM–GM. The dimensionless left side decreases as \(R\) grows; the guard checks \(R=1000\).
* For the upper-tail denominator, let \(b_0=3/2+\varepsilon\). Then its product is at least \((R/3-b_0)(2R/3-b_0)\geq(11/50)R^2\). The minimum in \(x_1\) occurs at an endpoint; \(u\geq0\) only increases it. This ratio increases for \(R\geq1000\), so again the guard checks the worst endpoint.
* The upper/lower ratio is at most
\(\frac{51}{44}e^{1/100+4\varepsilon}\leq\frac{51}{44}(1-89/6400)^{-1}<6/5\). This is an exact rational certificate after the elementary exponential comparison.

All shifted coordinates exceed \(3/2\), so every hard factor vanishes on \(S_R\). If \(V=\mu*(\varphi\varphi)\), then on this strip
\[
 |d|=\frac3{16}V\geq\frac3{16}M_R>\lambda,
 \qquad F=\frac5{32}V\leq\frac3{16}M_R<2\lambda,
 \qquad C=\frac9{40}V\geq\frac{27}{20}\lambda.
\]
Thus \(S_R\subset A\), with the actual strict contrast and actual background condition, not a surrogate event.

## 4. The denominator is the complete actual branch

The denominator in the result is \(T_A\) from (3), on **all** of \(A\). The strip supplies only its lower bound:
\[
 0<\frac9{2000}\lambda R\leq T_A\leq\int_{\mathbb R^2}C=I. \tag{7}
\]
No equality \(A=S_R\) is claimed or needed. Hard-support strips, other quadrants, and any additional low-background receivers are retained in \(T_A\). On the complete branch \(A\), Cauchy and \(J\leq4K\) give
\[
 \lambda/2<C\leq8\lambda.                              \tag{8}
\]
The lower inequality follows from \(|d|^2\leq FC\) and \(F\leq2\lambda\); the upper inequality is valid globally on \(A\). These are the actual R74 amplitude-band assumptions, with ratio 16.

The global posterior comparison is also on all of \(\mathbb R^2\), not just on the strip. For any two sources,
\[
 J(x-y_i)/J(x-y_j)\leq25e^{4\sum_{k=1}^2|y_{ik}-y_{jk}|}
 \leq25e^{16\varepsilon}<50.
\]
Consequently
\[
 \tau_i(x)=\frac{J(x-y_i)}{\sum_jJ(x-y_j)}\leq\frac{50}{N},
 \quad \pi_P=\sum_{i\in P}\tau_i\leq\frac{50|P|}{N}.      \tag{9}
\]
Every denominator is positive, by the positive all-soft mask. Equations (7)–(9) are enough to treat arbitrary other receivers in the full branch.

## 5. Uniform upper bound for every allowed packet configuration

Allow every nonempty packet \(P\subset\{1,\ldots,N\}\), a representative \(c_P\) fixed independently of \(x\), and the original physical gate
\[
 g_P(x)=\mathbf1_{\{c_P\in x+[-1/2,1/2]^2\}}.
\]
Representatives may be optimized without restriction: every such gate has Lebesgue volume exactly one. Allow ungated singleton coefficients \(\beta_i\) in addition to gated packet coefficients \(\alpha_P\). All coefficients are nonnegative, fixed independently of \(x\), and satisfy the common capacities
\[
 \beta_i+\sum_{P\ni i}\alpha_P\leq1\quad\text{for every }i.
\]
For \(t>0\), let \(B_t(A)\) be the supremum of
\[
 \sum_P\alpha_P\int_A Cg_P\pi_P^{1+t}
 +\sum_i\beta_i\int_A C\tau_i^{1+t}.
\]
This includes overlapping fractional packets and arbitrary fixed representatives; no partition/attainment assumption is used. Gated singletons can be replaced by their ungated version, so including them causes no missing case.

Put \(s_P=|P|/N\). Equations (8),(9) and gate volume one give
\[
 \int_A Cg_P\pi_P^{1+t}\leq8\lambda\,50^{1+t}s_P^{1+t}.
\]
Capacity summation gives \(\sum_P\alpha_Ps_P\leq1\), and \(s_P^{1+t}\leq s_P\). Hence **all gated packets together**, irrespective of how many there are, contribute at most \(8\lambda50^{1+t}\).

For the ungated singleton traffic,
\[
 \sum_i\beta_i\int_A C\tau_i^{1+t}
 \leq(50/N)^t\int_A C\sum_i\beta_i\tau_i
 \leq(50/N)^tT_A.
\]
Combining with (7), uniformly before taking the supremum,
\[
 \boxed{\quad
 \frac{B_t(A)}{T_A}
 \leq\frac{16000}{9R}50^{1+t}+(50/N)^t
 \leq\frac{1800}{R}50^{1+t}+(50/N)^t\longrightarrow0.
 \quad}                                                \tag{10}
\]
The limit is for every fixed \(t>0\), letting \(R,N\to\infty\), for example \(N=\lceil R\rceil\). All of \(n,\delta,L,B,\varepsilon\) are fixed. The threshold tends to zero by (5). Source sites stay distinct. Formula (10) does not apply if coefficients or representatives can change with the receiver; that is a different feasible model. Nor is the convergence uniform over \(t\downarrow0\): ungated singletons give \(B_0(A)=T_A\).

This disproves a positive lower coverage constant for this particular physical-gate packet model on the complete actual branch. It does not disprove R74's paid upper bound, a separately paid deletion scheme, or a larger admissible gate class.

There is no weak-type failure here. Indeed \(\|D\|_1\leq\sum_m|\alpha_m-\beta_m|=5/8\), so for this one fixed scale \(\lambda|\{|d|>\lambda\}|\leq5W/8\) by Tonelli and Markov. Even the strip has \(\lambda|S_R|=\lambda R/300\to0\).

## 6. New finite-window far-tail payment: independently proved

Let \(k\geq0\) be integrable and ray-decreasing, and let \(1\leq L_1<\cdots<L_M\leq2\). Dilation means \(k_L(z)=L^{-n}k(z/L)\). Along each ray,
\[
 k_{L_{j+1}}(z)\geq(L_j/L_{j+1})^n k_{L_j}(z).
\]
For any nonnegative finite sequence its maximum is at most its last term plus the sum of positive successive decreases. Thus, pointwise,
\[
 \max_jk_{L_j}\leq k_{L_M}
 +\sum_{j<M}[1-(L_j/L_{j+1})^n]k_{L_j}.
\]
Each \(k_{L_j}\) integrated over the **fixed spatial cutoff** \(\|z\|_\infty>R\) is at most \(\int_{\|u\|_\infty>R/2}k(u)\,du\). Also
\(1-e^{-nv}\leq nv\), so the sum of coefficients is at most \(n\log(L_M/L_1)\leq n\log2\). Therefore
\[
 \int_{\|z\|_\infty>R}\max_jk_{L_j}(z)\,dz
 \leq(1+n\log2)\int_{\|u\|_\infty>R/2}k(u)\,du.        \tag{11}
\]
This is a finite-window theorem; no scalar bound on a supremum can be integrated term by term without the telescoping argument. It uses \(R/2\), not \(R\), after dilation. The empty family is trivial and the one-scale case has zero coefficient sum.

For \(r\geq1/2\), the actual one-dimensional soft tail obeys
\[
 \int_{|s|>r}\varphi(s)\,ds
 \leq\int_{|s|>r-1/2}w(s)\,ds
 =2\int_0^1te^{-(r-1/2)/t}\,dt\leq e^{1/2-r}.
\]
For the actual \(n\)-dimensional endpoint mixture, a union bound over coordinates and averaging the two endpoint mask laws give
\[
 \int_{\|z\|_\infty>r}K(z)\,dz
 \leq\frac34n\delta e^{1/2-r}\leq n\delta e^{1/2-r}.      \tag{12}
\]
The softer displayed bound is the author's proposed one and is correct. The corresponding \(J\)-tail is also paid:
\[
 \int_{\|z\|_\infty>r}J(z)\,dz
 \leq e^{1/2-r}\sum_mq_m\zeta_m^2|m|
 \leq3n\delta e^{1/2-r},                               \tag{13}
\]
because \(\zeta^2\leq4\) and \(\mathbb E_q|m|=3n\delta/4\). For this exact \(n=2,\delta=1/2\) construction the first coefficient in (13) is exactly \(17/35\), from \(2/56+2(9/40)\). This is a coordinate union bound; it is not claiming disjoint tail events.

For the **actual scale-dependent cutoff** define
\(D_L^{\rm far}(z)=D_L(z)\mathbf1_{\{\|z\|_\infty>RL\}}\), with \(R\geq1\). Since \(L\geq1\),
\[
 \max_L|D_L^{\rm far}(z)|
 \leq2\mathbf1_{\{\|z\|_\infty>R\}}\max_LK_L(z).
\]
This explicitly relaxes the scaled cutoff to the fixed cutoff before (11). Hence for every finite signed or complex measure \(\nu\), \(W=\|\nu\|\), Tonelli gives
\[
 \left\|\max_L|\nu*D_L^{\rm far}|\right\|_1
 \leq2n(1+n\log2)\delta e^{1/2-R/2}W.                  \tag{14}
\]
The analogous selected/maximal far \(J\)-traffic bound is
\(3n(1+n\log2)\delta e^{1/2-R/2}W\).
No positivity of \(D\) is assumed; its absolute value is bounded before convolution.

Put \(A_n=2n(1+n\log2)\), choose \(a\geq0\), and
\[
 R=1+2\log A_n+2a.
\]
Then \(R\geq1\), \(e^{1/2-R/2}=A_n^{-1}e^{-a}\), and (14) is at most \(\delta e^{-a}W\), exactly as proposed. At this same radius the far \(J\) bound is at most \((3/2)\delta e^{-a}W\).

**What this repairs.** By Markov, a far-contrast exception at threshold \(\theta\lambda\) costs at most \(\delta e^{-a}W/(\theta\lambda)\). The deep-tail obstruction can thus be assigned a separate weak-volume budget, instead of demanding physical-gate coverage on that tail. A layer sum must explicitly pay \(\sum_s\delta_s e^{-a_s}/\theta_s\); an infinite window sum requires the appropriate localization theorem or an additional summable budget. The new lemma alone proves neither truncated-core packet coverage nor the full centered-cube theorem.

### Entire soft-layer tail: one strong budget, verified in the final update

The final author's Section 4 adds \(\delta_s=2^{-s}\), \(s\geq0\), using the same \(R_n(a)\) and the same finite physical family for all layers. This is valid without a per-layer weak threshold allocation. Equation (14) gives each layer fee \(2^{-s}e^{-a}W\). Apply Tonelli to the **nonnegative** sum of maximal absolute values:
\[
 \int\sum_{s\geq0}\max_{L\in\mathcal J}|T_{s,\mathrm{tail},L}\nu|\,dx
 \leq\sum_{s\geq0}2^{-s}e^{-a}W=2e^{-a}W.
\]
The sum is finite almost everywhere; all scales in the finite family are covered by the same majorant. Thus
\[
 \left\|\sup_{L\in\mathcal J}\sum_{s\geq0}|T_{s,\mathrm{tail},L}\nu|\right\|_1
 \leq2e^{-a}W,
\]
and also \(\|\sup_L|\sum_sT_{s,\mathrm{tail},L}\nu|\|_1\leq2e^{-a}W\). Absolute convergence justifies the latter series. The whole far-tail exception at threshold \(\eta\lambda\) therefore costs \(2e^{-a}W/(\eta\lambda)\), paid once. The earlier general warning about layer budgets is fulfilled here by the explicit geometric strong sum; an infinite physical-window sum, the near-core series, and the base-kernel estimate remain separate tasks.

## 7. Kernel-dominance gates: a proved payment interface, still requiring coverage

For a fixed source packet of mass \(w_P\), representative \(c_P\), and \(u_P=\mu_P*J_{L(x)}\), replace the physical gate by a measurable gate satisfying
\[
 g_P(x)=1\ \Longrightarrow\ u_P(x)\leq D_0w_P J_{L(x)}(x-c_P),\qquad D_0>0. \tag{15}
\]
On an actual \(C\)-band \(a<C\leq b\), the summand \(Cg_P(u_P/C)^{1+t}\) is bounded by
\(\min(b,u_P,u_P^{1+t}/a^t)\). On the gate, each of these bounds may be replaced by the common envelope centered at \(c_P\) with coefficient \(D_0w_P\). R74's three-piece radial integration therefore yields
\[
 \int_A Cg_P(u_P/C)^{1+t}
 \leq D_0[1+\log(b/a)+1/t]Iw_P.                        \tag{16}
\]
After common-capacity summation the total fee is at most \(D_0[1+\log(b/a)+1/t]IW\). More generally varying \(D_P\) requires the explicit budget \(\sum_P\alpha_PD_Pw_P\), not merely the unweighted source capacity. The same proof applies to \(K\), with its mass one, if its own domination condition is provided.

This replacement avoids the particular example: choose the whole cluster as a single packet and choose \(c_P\) to be any cluster site. Equations (1),(2) imply \(u_P\leq50J(x-c_P)\) globally. Thus (15) with \(D_0=50\) opens this packet gate everywhere, its posterior is one, and its score equals \(T_A\). This does not establish uniform \(D_0\) and useful packet coverage for arbitrary sources. It is a concrete conditional repair with an explicit paid factor, not a completed general theorem.

### Audit of the author's stronger normalized per-source gate and rounding

The author's final Section 5 uses the stronger condition
\[
 g_{P,c,A_0}(x)=\mathbf1_{\{k_{L(x)}(x-y_i)\leq A_0k_{L(x)}(x-c)\text{ for all }i\in P\}},\qquad A_0\geq1,
\]
and divides the score by \(A_0\). This implies (15), so (16) proves payment with the original unweighted source capacities and no factor \(A_0\) in the final budget. Different columns may have different fixed \(A_0\); normalization is columnwise. Pointwise the summed normalized score is at most one, since \(\pi_P^{1+t}/A_0\leq\pi_P\) and common capacities sum the source posteriors at most once. Ungated singletons use \(A_0=1\).

Unlike aggregate dominance alone, per-source dominance survives replacing \(P\) by any assigned subset. Here is the full clock coefficient check. Give column \(P\) a clock of rate \(\alpha_P\), and assign each source to its earliest incident clock. Let \(r_i=\sum_{P\ni i}\alpha_P\leq1\). Conditional on column \(P\)'s clock being \(s\), a source \(i\in P\) survives its competitors with probability \(e^{-(r_i-\alpha_P)s}\geq e^{-(1-\alpha_P)s}\). Thus the surviving contribution \(u'_P\) has conditional mean at least \(e^{-(1-\alpha_P)s}u_P\). Jensen with \(q=1+t\), followed by the clock density, gives coefficient
\[
 \int_0^\infty\alpha_Pe^{-\alpha_Ps}e^{-q(1-\alpha_P)s}\,ds
 =\frac{\alpha_P}{1+t-t\alpha_P}\geq\frac{\alpha_P}{1+t}.
\]
The factor \(1/A_0\), the old gate, representative, and denominator \(G\) are fixed during this conditioning. The assigned subpacket has a valid gate at least as large as the old gate. Assigned singleton pieces may be improved to their ungated \(A_0=1\) columns; unassigned sources are also added as ungated singletons. They form one genuine common partition. Therefore the claimed comparison \(O_t\leq B_t\leq(1+t)O_t\) holds for the normalized per-source column class, without assuming an optimum is attained. It is **not** established by aggregate dominance alone, since aggregate dominance need not survive a subset assignment.

For the example, the whole source with \(c=0,A_0=50\) has the per-source gate open everywhere by (1),(2). Its normalized score is exactly \(T_A/50\), on the complete branch and for every \(t\geq0\). Thus the final author's normalized repair restores a fraction \(1/50\), rather than the unnormalized fraction one described above.

The final author's general-dimension comparisons are also verified for \(n\geq1,0<\delta\leq1\): \(\psi_s\leq(4-3s)\varphi\) gives
\[
 C_K=\tfrac12[(4-3\delta/2)^n+(4-3\delta)^n],\quad
 q_{\rm all}=\tfrac12[(\delta/2)^n+\delta^n],\quad
 j_{\rm all}=\frac{2\delta^n(1-2^{-n})^2}{1+2^{-n}}.
\]
Thus \(q_{\rm all}\varphi^{\otimes n}\leq K\leq C_K\varphi^{\otimes n}\) and \(j_{\rm all}\varphi^{\otimes n}\leq J\leq4C_K\varphi^{\otimes n}\). The quoted factors \((C_K/q_{\rm all})e^{4D/L_{\min}}\) and \((4C_K/j_{\rm all})e^{4D/L_{\min}}\) follow exactly. They may be exponential and do not provide the required subpower coverage. If all hard-coordinate indicators agree between every source and the representative, maskwise comparison really does remove the coefficient ratio; an additional cutoff indicator mismatch for truncated kernels still requires separate control.

The random-shift formulas in final Section 6 are exact convolution identities. The example \(L(x)=x,z=1\) only concerns a fixed conditional shift and correctly blocks a free variable change; it is not promoted to an averaged weak counterexample. A fixed representative becomes \(c+L(x)z\), so that common-representative debt is real.

## 8. Reproducibility and final acceptance scope

Run:

```text
python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round075_20261011/soft_audit_guard.py
```

Actual stdout:

```json
{
  "status": "PASS",
  "exact_assertions": 2504,
  "fee_rows": 126,
  "I": "228/455",
  "J_tail_coordinate_coefficient": "17/35",
  "scope": "rational identities and inequalities; analytic envelope, exp comparison, log-Lipschitz and integration proofs are in soft_counter_audit.md"
}
```

The guard checks the exact coefficients, \(R=1000\) denominator endpoints and their stated monotonic extension, posterior and strip exponential constants via a rational majorant, strict crossing/background inequalities, denominator coefficient, packet coefficient rounding, and the general mask/tail coefficient identities for 126 \((n,\delta)\) rows. It does not claim a quadrature error certificate or a numerical approximation to the full event integral. The complete-branch proof is (7)–(10); no event-grid restriction is used.

**Accepted:** the physical-gate packet lower-coverage counterexample; the complete actual-event denominator; the uniform all-packet upper bound; the finite-window far-tail estimate and complete soft-layer strong-tail sum; the conditional kernel-dominance gate payment and normalized per-source clock rounding.

**Not accepted as proved:** arbitrary-source truncated-core coverage, dimension-uniform optimized soft-packet coverage, an unpaid entropy exception scheme, a sum over infinitely many windows without localization, or the general \(\sqrt n\,n^{o(1)}\) target.


### Final-file comparison and correction record

Both complete author files were read after creation. Their coefficients, strip construction, full-event denominator, all-packet bound, finite-window telescoping, far-tail normalization, normalized per-source gate, general-dimension comparisons, and random-shift limitations agree with the independent derivations above. The author's embedded Python guard was executed directly from Markdown without writing or modifying another file. Its SHA-256 (including the final code newline) is `583d22d920bd52ad49e612d0919a66ff3ec93fd48e0bdb44133f5335d6e3b1a5`, matching the claimed SHA; stdout reproduced PASS, 18 tail points, 18 posterior checks, 15 dominance checks, 1008 scaled refinements, and `4.84706770511698e-11` maximum observed relative refinement difference. This remains diagnostic floating evidence.

One wording correction was sent to the author: the Markdown Section 4 originally listed \(D_R\) among kernels retaining ray monotonicity. Only the nonnegative \(K_R,J_R\) have that property; signed \(D_R\) can jump upward from a negative tail to zero at truncation. Its required property is the restricted-joint-measure Cauchy inequality. The TeX source already stated the correct \(K_R,J_R\) version. This correction does not affect any counterexample or payment estimate above. The author corrected the Markdown sentence, and its final text was re-read and confirmed. The corrected nonnegative-kernel formulation now agrees with the TeX source.


The latest author's appended whole-layer tail paragraphs were read in both Markdown and TeX and accepted as proved above. The updated embedded guard was independently rerun as well: SHA-256 `4543cc2449c5ebfbed778e4949c92f12b98c8ab33a39b8a207b66a0b6e08de54` matches the latest source, PASS includes 189 finite-window point checks, 60 radius-fee identities and six finite geometric layer sums in addition to the previous counts. The earlier guard SHA is retained above only as a chronological reproducibility record; this latest SHA identifies the final accepted guard. No unresolved correction remains in the reviewed author files.

## 9. Final independent audit of `envelope.md`

The complete R75 `envelope.md` was independently read after the parent requested this extension. Its bbox envelope, actual-posterior band payment, common source capacities, arbitrary-source grid estimate, and uniform-box bbox-only obstruction are **accepted as proved**, subject to their stated scope. The following checks are analytic; the embedded guard was also independently executed as recorded below.

### 9.1 Units, domination and exact envelope mass

Normalize a physical window `[L0,2L0]` by `L0` first. A physical packet halfwidth `D_i` becomes `d_i=D_i/L0`; thus its geometric price is `prod_i(1+2d_i)`. This normalization is necessary. It remains invariant when the common dimensionless coordinates are returned to physical coordinates.

For a packet in `c+prod_i[-d_i,d_i]`, `1<=L<=2` implies

```text
|x_i-y_i|/L >= (|x_i-c_i|/L-d_i/L)_+ >= (|x_i-c_i|/L-d_i)_+.
```

Every hard or soft factor is even and nonincreasing in its absolute argument, so the displayed tensor envelope really dominates the actual kernel pointwise. Its essential-box qualification is legitimate: a source-null set can be removed once, independently of the receiver and scale. Each one-dimensional envelope is constant at `k(0)` on `[-d_i,d_i]`, and outside that interval is a translated copy of the original half-line density. Its integral is exactly `1+2d_i k(0)`. Hence each mask envelope is a positive fixed ray-decreasing kernel of mass `prod_i(1+2d_i k_{m,i}(0))`, bounded by `A_P=prod_i(1+2d_i)`; the mixed K/J envelope masses are at most `A_P` and `I A_P` respectively. No receiver-dependent envelope kernel or unspecified small displacement approximation occurs.

The band proof also has the correct direction. The actual packet satisfies both `u_P<=G` and `u_P<=w_P e_L(x-c)`. The former permits the three-piece minimum bound on `G pi_P^(1+t)`; the latter replaces this minimum by a larger envelope minimum. The envelope columns need not sum to `G`, and are not treated as actual posteriors. The directional envelope calculation then pays the true mass of `e`. This supplies an upper payment, not lower coverage.

### 9.2 Common capacities and the full-space grid

For countably many Borel packets the constraint `sum_P alpha_P 1_P(y)<=1` for source-almost every `y` implies, by Tonelli,

```text
sum_P alpha_P u_P(x) <= G(x),
sum_P alpha_P w_P <= W.
```

On bands with `G>0`, all actual posteriors are defined and `sum alpha_P pi_P^(1+t)<=sum alpha_P pi_P<=1`. Thus the stated priced budget and score bounds apply to countably many occupied grid cells and arbitrary finite positive measures; no atomic assumption, global support diameter or minimum separation is used. A hybrid may index the same source packet twice with different column types, but both copies consume this same source capacity. The proposed hybrid payment does not double-charge available capacity or evade geometric envelope prices.

A fixed half-open grid of side `ell` partitions all source space once. Its packet prices are at most `(1+ell)^n`, so `Benv<=(1+ell)^n` even for unbounded support. A source near-box of side `2RL(x)<=4R` meets at most `M=ceil(4R/ell+2)^n` cells. For the actual near contributions `v_P=u_P^near/G`, positivity gives `pi_P>=v_P`, and Holder/power mean gives

```text
sum_P pi_P^(1+t) >= M^(-t)(1-epsilon)^(1+t)
```

whenever near traffic is at least `(1-epsilon)G`. This is genuine posterior coverage by one globally fixed partition. For `ell=1/n`, the budget is at most `e`. Taking `t=1/(1+log M)` gives coverage at least `e^(-1)(1-epsilon)^2`, but `1/t=O(1+n log(2+nR))`. With `R=O(log n)` the fee is `O(n log n)` on fixed-ratio bands. It is not a subpower fee.

The integrated bad-set estimate is also correct when `epsilon>0`: `G>a` on the band and `G_tail>epsilon G` imply `a|A_bad|<=epsilon^(-1) int_A G_tail`. The case `epsilon=0` belongs to exact near domination and is not an occasion to divide by zero.

### 9.3 True uniform-box plateau obstruction, with its exact scope

The input is the genuine probability density `2^n 1_{[-1/4,1/4]^n}`, with `nu=mu`, `delta=1/n`, `L=1`; the receiver set is the same cube `A=[-1/4,1/4]^n`. Every source displacement has absolute coordinate at most `1/2`, so all hard factors equal one and all traffic is near for `R>=1/2`.

The bound `phi<=3/4` is valid: its maximum is at zero, while the w-tail beyond `1/2` is at least `3/(4e)>1/4`, using `e<3`. With `r_i=1-phi(x_i-y_i)` one has `1/4<=r_i<=1`. Telescoping the two endpoint products gives `n` positive terms, each at least `(1/(8n))(1-1/n)^(n-1)`. Thus the actual contrast is at least `1/32`; `lambda=1/64,B=64` gives a true low-event subevent. No signs, artificial kernel, or finite receiver approximation are substituted.

The empty-mask estimates also hold: `a0>=1/2`, `b0<3/8`, `q0>=1/4`, `q0<=1`, and `j0>1/64`. Therefore, on all of this `A`, `1/4<=F<=1` and `1/64<C<=I<=2`; it lies in the genuine C band `(1/128,3)`. A packet of probability mass `p` has actual posteriors at most `4p` for K or `128p` for J.

For every measurable packet of positive mass, its smallest essential bounding box has widths `s_i<=1/2`, and `p<=prod_i(2s_i)` by source density and volume. Positive mass forces each width to be positive. Convexity of `z -> log(1+exp z)` yields

```text
A_P=prod_i(1+s_i) >= (1+(1/2)p^(1/n))^n.
```

This argument includes disconnected and irregular packets, overlaps with fractional capacities, and arbitrary families of differently sized packets. Splitting the families at `eta=2^(-n)` and applying the actual source capacity gives the pointwise bound

```text
S_t(x) <= D^t 2^(-nt) + D Benv (4/5)^n,
D=4 for K; D=128 for J.
```

The first term follows from `pi_P^t<=(D eta)^t` for small packets and `sum alpha_P pi_P<=1`; the second follows from `A_P>=(5/4)^n`, `pi_P<=D p`, and the priced source budget for large packets. Hence for `0<t<=1`, `nt->infinity`, `log Benv=o(n)`, coverage tends to zero. In particular cheap `1/t=n^{o(1)}` and `Benv=n^{o(1)}` cannot supply a fixed coverage fraction on every actual near band **subevent** using bbox envelopes alone. At `t=1/sqrt(n)`, the first term is `D^(1/sqrt(n)) 2^(-sqrt(n))`, and the second still decays under any subexponential budget, so the obstruction is explicit at that exponent as well.

Charging the exact mixed envelope mass does not remove this obstruction: the empty hard mask gives `M_P^K>=A_P/4` and `M_P^J/I>=A_P/128`. A budget for those exact normalized masses bounds the coarse `A_P` budget up to the fixed factors 4 or 128. There is no unaccounted exponential improvement hidden in this replacement.

**Scope is essential.** This `A` is a true low-contrast receiver subevent and a true amplitude band subevent. It is not claimed to be the entire selected low-background event, or a fixed fraction of its total traffic. Its weak volume is `lambda|A|=2^(-n)/64`, which can be deleted by an explicitly paid small exceptional-volume budget. The whole-source packet with representative zero has physical gate equal to one on all of `A`, posterior one, and price one. Thus hybrid coverage on `A` is perfect. The obstruction does not refute full-branch coverage after paid exceptions, a hybrid model, normalized dominance gates, or the general centered-cube target.

### 9.4 Guard replay and outstanding target

The envelope Markdown embedded guard was extracted and executed directly, without modifying the author's file or creating another source file. Its code SHA-256 including the final newline was `89ce5e296a4629523b1c5563e494a9077e574dd0db442c8a6555c7247442c4c5`. Actual replay output was:

```json
{
  "status": "PASS",
  "counts": {
    "stage1_exact_domination": 270,
    "stage2_actual_mask_domination": 414,
    "stage3_rational_bounds": 28
  }
}
```

The second stage remains deterministic floating regression, not outward-rounded quadrature or a universal proof. The theory above provides the domination, capacity, coverage, price and obstruction proofs.

A general dimension-subpower hybrid coverage/budget theorem with all exceptions paid is still unproved. The grid supplies coverage at a real `O(n log n)` cost; the bbox-only obstruction prevents simply assuming that its expense can be removed on every near subevent. Neither the envelope note nor this audit completes `C_n<=sqrt(n) n^{o(1)}`.

### 9.5 Final frozen additions: exact core coverage and the target exponent

The author's final frozen update was re-read. It now states `0<epsilon<1` in the integrated bad-set argument and explicitly applies the grid to the truncated core. This application is accepted: use the infinity-norm cutoff `k_R(z)=k(z)1_{||z||_infinity<=R}`, define `G=mu*(k_R)_L`, and retain its actual band and actual posterior. Every core packet is bounded by the already-proved untruncated K/J tensor envelope. Payment therefore retains the **untruncated** mass parameter `m=1` or `m=I`, not an unsupported tensor-envelope claim or a replacement by the smaller core mass. Every nonzero core source contribution lies within `RL`, so at most `M` grid cells contribute and near coverage has `epsilon=0` exactly. This gives `Benv<=e`, `kappa>=e^(-1)`, and `1/t=1+log M=O(1+n log(2+nR))` on the full selected core band for arbitrary finite sources. Together with the already-proved tail payment, this is a complete general interface at its displayed polynomial dimension cost, not at the desired subpower cost.

The frozen `t=1/sqrt(n)` statement is also accepted. For J, uniformly over bbox-only capacity families of subexponential budget,

```text
S_t <= 128^(1/sqrt(n)) 2^(-sqrt(n)) + 128 Benv (4/5)^n.
```

The logarithms of its terms are `-log(2)sqrt(n)+O(n^(-1/2))` and `-log(5/4)n+o(n)`. Both are below `-A log n` eventually for every fixed `A>0`. Thus coverage `kappa_n=n^(-o(1))` is impossible for that universal bbox-only **near-subevent** demand at this exponent. All limitations in Section 9.3 remain: it is neither the full low branch nor a hybrid counterexample, and the subevent has a small explicit weak-volume price.

The final embedded guard was replayed once more after these additions. Its code SHA and PASS counts remained `89ce5e296a4629523b1c5563e494a9077e574dd0db442c8a6555c7247442c4c5` and `270/414/28`. This audit extension is now frozen, with no unresolved correction in the reviewed envelope statements. No author's file was modified, and no Git or compilation was run.


## 可移植独立守卫：audit_guard.py

```python
#!/usr/bin/env python3
"""Round 75 independent pricing audit. Exact references are exhaustive subsets
and a separately implemented rational Edmonds-Karp closure network. Receiver
posteriors in self-tests come from complete all-scale centered-interval winners.
This script never certifies a continuum integral from a finite receiver list.
"""
from fractions import Fraction as F
from collections import deque
from pathlib import Path
import itertools,json,hashlib,time,importlib.util,math,random
ROOT=Path(__file__).parent

def graph_maxprofit(profits,edges):
    """Maximum of node profit minus directed crossing penalties; exact flow.
    Selected nodes are on the source side. Certificate: terminal cut=flow.
    """
    n=len(profits);S=n;T=n+1;cap=[[F(0) for _ in range(n+2)] for _ in range(n+2)]
    for i,p in enumerate(profits):
        if p>=0:cap[S][i]+=p
        else:cap[i][T]-=p
    for i,j,c in edges:assert c>=0;cap[i][j]+=c
    residual=[r[:] for r in cap];flow=F(0)
    while True:
        par={S:None};q=deque([S])
        while q and T not in par:
            i=q.popleft()
            for j,z in enumerate(residual[i]):
                if z>0 and j not in par:par[j]=i;q.append(j)
        if T not in par:break
        path=[];j=T
        while j!=S:i=par[j];path.append((i,j));j=i
        f=min(residual[i][j] for i,j in path);flow+=f
        for i,j in path:residual[i][j]-=f;residual[j][i]+=f
    reach={S};q=deque([S])
    while q:
        i=q.popleft()
        for j,z in enumerate(residual[i]):
            if z>0 and j not in reach:reach.add(j);q.append(j)
    net=[[cap[i][j]-residual[i][j] for j in range(n+2)] for i in range(n+2)]
    assert all(net[i][j]==-net[j][i] and net[i][j]<=cap[i][j] for i in range(n+2) for j in range(n+2))
    balance=[sum(row) for row in net]
    assert balance[S]==flow and balance[T]==-flow and all(balance[i]==0 for i in range(n))
    cut=sum(cap[i][j] for i in reach for j in range(n+2) if j not in reach)
    assert cut==flow and T not in reach
    val=sum(p for p in profits if p>0)-cut
    selected={i for i in range(n) if i in reach}
    direct=sum(profits[i] for i in selected)-sum(c for i,j,c in edges if i in selected and j not in selected)
    assert val==direct
    return val,selected

def objective(rows,w,g,u,mask,fun):
    return sum(wr*gr*fun(sum(a for i,a in enumerate(row) if mask>>i&1)) for row,wr,gr in zip(rows,w,g))-sum(ui for i,ui in enumerate(u) if mask>>i&1)

def brute(rows,w,g,u,fun):
    vals=[objective(rows,w,g,u,m,fun) for m in range(1<<len(u))]
    m=max(range(len(vals)),key=vals.__getitem__)
    return vals[m],m

def quadratic_cut(rows,w,g,u):
    n=len(u);Q=[[sum(wr*gr*row[i]*row[j] for row,wr,gr in zip(rows,w,g)) for j in range(n)] for i in range(n)]
    profits=[sum(Q[i])-u[i] for i in range(n)]
    edges=[(i,j,Q[i][j]) for i in range(n) for j in range(n) if i!=j and Q[i][j]]
    v,chosen=graph_maxprofit(profits,edges);mask=sum(1<<i for i in chosen)
    assert v==objective(rows,w,g,u,mask,lambda s:s*s)
    return v,mask

def pl_cut(rows,w,g,u,a0,hinges):
    n=len(u);profits=[-u[i]+a0*sum(wr*gr*row[i] for row,wr,gr in zip(rows,w,g)) for i in range(n)];edges=[]
    for row,wr,gr in zip(rows,w,g):
        for theta,d in hinges:
            assert d>=0
            A=wr*gr*d
            if not A:continue
            aux=len(profits);profits.append(A*(sum(row)-theta));edges.extend((aux,i,A*a) for i,a in enumerate(row) if a)
    v,chosen=graph_maxprofit(profits,edges);mask=sum(1<<i for i in chosen if i<n)
    fun=lambda s:a0*s+sum(d*max(F(0),s-theta) for theta,d in hinges)
    assert v==objective(rows,w,g,u,mask,fun)
    return v,mask

def actual_fixture():
    y=[F(0),F(1,8),F(1),F(3)];p=[F(j,13) for j in (1,3,2,7)];lam=F(1,4);ret=[]
    for k in range(-128,385):
        x=F(k,32)
        if x in y:continue
        candidates=[]
        for r in sorted({abs(x-z) for z in y}):
            ids=tuple(i for i,z in enumerate(y) if abs(x-z)<=r);mass=sum(p[i] for i in ids)
            candidates.append((mass/(2*r),r,ids,mass))
        M,r,ids,mass=max(candidates,key=lambda z:z[0])
        if lam<M<=2*lam:ret.append((x,r,M,[p[i]/mass if i in ids else F(0) for i in range(4)]))
    # Subsample fixed rational receivers, keeping varied actual winner cells.
    idx=sorted({j*(len(ret)-1)//11 for j in range(12)});ret=[ret[j] for j in idx]
    return y,p,ret

def math_selftest():
    y,p,ds=actual_fixture();rows=[z[3] for z in ds];w=[z[2]/32 for z in ds];tested=0
    assert all(sum(r)==1 and all(a>=0 for a in r) for r in rows)
    a0=F(1,4);hinges=[(F(j,4),F(1,2)) for j in (1,2,3)]
    fun=lambda s:a0*s+sum(d*max(F(0),s-theta) for theta,d in hinges)
    for c in [F(0),F(1,8),F(1,2),F(1),F(3)]:
        g=[int(abs(x-c)<=r) for x,r,M,row in ds]
        for u in [[F(0)]*4,[F(i+1,100) for i in range(4)],[F(1)]*4,[F(3,50),F(0),F(1,100),F(1,25)]]:
            v,m=brute(rows,w,g,u,lambda s:s*s);assert quadratic_cut(rows,w,g,u)[0]==v
            vp,mp=brute(rows,w,g,u,fun);assert pl_cut(rows,w,g,u,a0,hinges)[0]==vp;tested+=1
    return dict(actual_receiver_count=len(ds),fixed_representatives=5,price_vectors=4,exhaustive_quadratic_oracles=tested,exhaustive_hinge_oracles=tested)

def import_production():
    spec=importlib.util.spec_from_file_location('audited_pricing_probe',ROOT/'pricing_probe.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def independent_receiver(src,x):
    n=src['n'];ys=[tuple(map(F,y)) for y in src['y']];ws=src['w'];W=src['W'];lam=F(src['lam']);N=len(ys)
    distance=[max(abs(x[k]-y[k]) for k in range(n)) for y in ys]
    candidates=[]
    for r in sorted(set(distance)):
        ids=tuple(i for i,d in enumerate(distance) if d<=r);C=sum(ws[i] for i in ids)
        candidates.append((F(C,W)/(2*r)**n,r,ids,C))
    M,r,ids,C=max(candidates,key=lambda z:z[0])
    if not lam<M<=2*lam:return None
    qlo=qhi=F(0);QD=1<<100
    for w,d in zip(ws,distance):
        tau=(2*d)**n*lam;a=F(w,W)
        terms=[min(F(1),1/tau**2)/(4*N),a*min(F(1),1/tau**2)/8,min(F(1),(a/tau)**2)/8]
        for z in terms:
            qlo+=F(z.numerator*QD//z.denominator,QD);qhi+=F(-(-z.numerator*QD//z.denominator),QD)
    sl=M/lam/qhi;su=M/lam/qlo
    return dict(x=x,radius=r,captured_indices=ids,captured_integer_mass=C,score_lower=sl,score_upper=su)

def independent_draws(src,S,seed):
    rng=random.Random(seed);n=src['n'];N=src['N'];cumulative=[];total=0
    for w in src['w']:total+=w;cumulative.append(total/src['W'])
    band=[]
    for _ in range(S):
        z=rng.random();component=0 if z<.5 else 1 if z<.75 else 2
        if component==0:i=rng.randrange(N)
        else:
            z=rng.random();i=next((j for j,c in enumerate(cumulative) if z<c),N-1)
        b=float(1/F(src['lam']))*(src['w'][i]/src['W'] if component==2 else 1.)
        U=max(rng.random(),math.nextafter(0.,1.));v=b*U if rng.randrange(2)==0 else b/U
        theta=[rng.uniform(-1,1) for _ in range(n)];theta[rng.randrange(n)]=rng.choice([-1,1]);r=.5*math.exp(math.log(v)/n)
        x=tuple(F(float(F(src['y'][i][k]))+r*theta[k]) for k in range(n))
        receiver=independent_receiver(src,x)
        if receiver is not None:band.append(receiver)
    return band

def rebuild(row):
    src=row['source'];N=src['N'];n=src['n'];S=row['training_samples'];QW=1<<40;QE=1<<60
    band=independent_draws(src,S,row['training_seed']);saved=row['training_receivers'];assert len(band)==len(saved)==row['training_band_count']
    delta=F(0)
    for d,z in zip(band,saved):
        assert tuple(map(F,z['x']))==d['x'] and F(z['radius'])==d['radius']
        assert set(z['captured_indices'])==set(d['captured_indices']) and z['captured_integer_mass']==d['captured_integer_mass']
        score=d['score_lower']/S;integer=score.numerator*QW//score.denominator;assert integer==z['weight_integer'];d['weight_integer']=integer
        quant=F(integer,QW);gap=d['score_upper']/S-quant
        delta+=F(-(-gap.numerator*QE//gap.denominator),QE)
    assert delta==F(row['quantization_error_upper'])
    assert F(sum(d['weight_integer'] for d in band),QW)==F(row['training_quantized_occupation'])
    D=math.lcm(*(d['captured_integer_mass']**2 for d in band)) if band else 1;den=QW*D;assert den==row['matrix_denominator']
    matrices=[];patterns=[];repmap=[]
    for c in src['representatives']:
        c=tuple(map(F,c));pattern=tuple(all(abs(d['x'][k]-c[k])<=d['radius'] for k in range(n)) for d in band)
        if pattern not in patterns:
            G=[[0]*N for _ in range(N)]
            for active,d in zip(pattern,band):
                if active:
                    factor=d['weight_integer']*(D//d['captured_integer_mass']**2)
                    for i in d['captured_indices']:
                        for j in d['captured_indices']:G[i][j]+=factor*src['w'][i]*src['w'][j]
            patterns.append(pattern);matrices.append(G)
        repmap.append(patterns.index(pattern))
    assert len(matrices)==row['distinct_gate_matrices']
    return matrices,repmap,den

def matrix_subset(G,m,den):
    ids=[i for i in range(len(G)) if m>>i&1]
    return F(sum(G[i][j] for i in ids for j in ids),den)

def independent_matrix_price(G,den,u):
    # Independent network and Edmonds-Karp; integer capacities improve speed.
    mult=math.lcm(*(x.denominator for x in u));scale=den*mult
    p=[sum(G[i])*mult-int(u[i]*scale) for i in range(len(u))]
    arcs=[(i,j,G[i][j]*mult) for i in range(len(u)) for j in range(len(u)) if i!=j and G[i][j]]
    val,chosen=graph_maxprofit(p,arcs);mask=sum(1<<i for i in chosen)
    value=val/scale
    assert value==matrix_subset(G,mask,den)-sum(u[i] for i in chosen)
    return value,mask

def audit_production():
    data=json.loads((ROOT/'pricing_results.json').read_text());production=import_production();checks=0;final_oracles=0;bands=0;columns=0;gaps=[];deltas=[]
    for row in data['cases']:
        src=row['source'];N=src['N'];G,repmap,den=rebuild(row);cg=row['column_generation'];lp=cg['LP'];u=list(map(F,lp['dual']));p={int(m):F(v) for m,v in lp['primal'].items()};coeff={int(m):F(v) for m,v in cg['active_coefficients'].items()};reps={int(m):rid for m,rid in cg['active_representatives'].items()}
        assert all(a>=0 for a in p.values()) and all(x>=0 for x in u)
        loads=[sum(a for m,a in p.items() if m>>i&1) for i in range(N)];assert all(x<=1 for x in loads) and loads==list(map(F,lp['loads']))
        for m,b in coeff.items():
            vals=[matrix_subset(A,m,den) for A in G];assert b==max(vals)==vals[repmap[reps[m]]]
            assert sum(u[i] for i in range(N) if m>>i&1)>=b
        value=sum(coeff[m]*a for m,a in p.items());assert value==F(lp['value'])==F(row['training_registered_library_B_lower'])
        upper=sum(u);assert value<=upper==F(lp.get('dual_upper_value',lp['value']))
        assert F(lp.get('primal_dual_gap',0))==upper-value
        assert min(sum(u[i] for i in range(N) if m>>i&1)-b for m,b in coeff.items())==F(lp['min_dual_slack'])
        gaps.append(upper-value);deltas.append(F(row['quantization_error_upper']))
        if lp.get('dual_upper_source')=='occupation_first_moment':
            occupation=[sum(F(z['weight_integer'],1<<40)*F(src['w'][i],z['captured_integer_mass']) for z in row['training_receivers'] if i in z['captured_indices']) for i in range(N)]
            assert occupation==u and upper==F(row['training_quantized_occupation'])
        assert F(row['training_registered_library_B_upper'])==upper+F(row['quantization_error_upper'])
        assert len(cg['final_pricing'])==len(G)
        for A,saved in zip(G,cg['final_pricing']):
            v,m=independent_matrix_price(A,den,u);assert v==0==F(saved['value'])
            ms=saved['mask'];assert matrix_subset(A,ms,den)-sum(u[i] for i in range(N) if ms>>i&1)==0
            positive=sum(max(0,sum(A[i])*saved['capacity_scale']//den-int(u[i]*saved['capacity_scale'])) for i in range(N))
            assert positive==saved['positive'] and positive-saved['flow']==0;final_oracles+=1
        history=cg['history'];assert F(history[-1]['maximum_reduced_cost'])==F(lp.get('global_dual_repair',0))
        assert F(history[-1]['maximum_reduced_cost'])<=F(1,10**12)
        if 'registered_library_optimal' in cg:assert cg['registered_library_optimal']==(upper==value)
        if N<=8:
            # Every subset constraint, plus independently chosen prices.
            for m in range(1,1<<N):
                b=max(matrix_subset(A,m,den) for A in G);assert b<=sum(u[i] for i in range(N) if m>>i&1)
            rng=random.Random(750075+N);vectors=[[F(0)]*N]+[[F(rng.randrange(33),64) for _ in range(N)] for _ in range(3)]
            for vector in vectors:
                for A in G:
                    vals=[matrix_subset(A,m,den)-sum(vector[i] for i in range(N) if m>>i&1) for m in range(1<<N)]
                    bruteval=max(vals);orig=production.maxcut_pricing(A,den,vector)
                    assert orig['value']==bruteval==independent_matrix_price(A,den,vector)[0];checks+=1
        bands+=row['training_band_count'];columns+=len(coeff)
    return dict(archive_status=data['status'],registered_cases=len(data['cases']),training_draws=data['counts']['training_draws'],training_band_reconstructed=bands,active_columns_checked=columns,rational_master_primal_dual_brackets=len(data['cases']),final_global_pricing_oracles=final_oracles,production_exhaustive_smallN_oracles=checks,zero_gap_quantized_masters=sum(x==0 for x in gaps),maximum_quantized_gap_decimal=float(max(gaps)),maximum_weight_error_decimal=float(max(deltas)),hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'pricing_probe.py',ROOT/'pricing_results.json']})

def curve_data(record):
    raw=[tuple(map(F,p)) for p in record['raw_nodes']];nodes=[tuple(map(F,p)) for p in record['convex_nodes']];k=record['k'];eps0=F(record['epsilon0']);eta=F(1,2**record['root_bisection_bits']);eps=F(record['epsilon']);ratio=F(record['ratio'])
    assert eps==eps0+eta and raw[0]==(0,0) and raw[-1]==(1,1) and raw[1][0]==eps0**k
    assert F(record['curvature_budget'])==F(k+1,k)*F(1,k)*(ratio-1)**2/8<=eps0
    assert all(b[0]>a[0] and b[0]<=a[0]*ratio for a,b in zip(raw[1:],raw[2:]))
    for x,u in raw:
        assert 0<=u<=x and u**k>=x**(k+1)
        low=u-eta*x;assert low<=0 or low**k<=x**(k+1)
    slopes=[(b[1]-a[1])/(b[0]-a[0]) for a,b in zip(nodes,nodes[1:])]
    assert slopes==list(map(F,record['convex_slopes'])) and all(a<=b for a,b in zip(slopes,slopes[1:]))
    assert all(p in raw for p in nodes) and nodes[0]==(0,0) and nodes[-1]==(1,1)
    cache={}
    def value(x):
        x=F(x)
        if x not in cache:
            j=next((j for j in range(len(nodes)-1) if nodes[j][0]<=x<=nodes[j+1][0]),None);assert j is not None
            cache[x]=nodes[j][1]+slopes[j]*(x-nodes[j][0])
        return cache[x]
    for x,u in raw:assert value(x)<=u
    a0=F(record['linear_coefficient']);hinges=[tuple(map(F,p)) for p in record['hinges']]
    assert a0==slopes[0]
    assert hinges==[(nodes[j][0],slopes[j]-slopes[j-1]) for j in range(1,len(slopes)) if slopes[j]>slopes[j-1]]
    return value,a0,hinges

def parent_source_check(src):
    ys=[tuple(map(F,y)) for y in src['y']];weights=src['w'];W=sum(weights);n=src['n'];lam=F(src['lam']);rows=[]
    for r in src['rows']:
        x=tuple(map(F,r['x']));dist=[max(abs(x[j]-y[j]) for j in range(n)) for y in ys];candidates=[]
        for radius in sorted(set(dist)):
            ids=tuple(i for i,d in enumerate(dist) if d<=radius);C=sum(weights[i] for i in ids);candidates.append((F(C,W)/(2*radius)**n,radius,ids,C))
        M,radius,ids,C=max(candidates,key=lambda z:z[0]);a=[F(weights[i],C) if i in ids else F(0) for i in range(len(weights))]
        assert lam<M<=2*lam and M==F(r['M']) and radius==F(r['r']) and C==r['C'] and set(ids)==set(r['ids']) and a==list(map(F,r['a']))
        rows.append(dict(a=a,nu=F(r['nu'])))
    gates=[tuple(int(all(abs(F(r['x'][j])-F(c[j]))<=F(r['r']) for j in range(n))) for r in src['rows']) for c in src['representatives']]
    assert gates==[tuple(g) for g in src['representative_gate_patterns']]
    assert list(dict.fromkeys(gates))==[tuple(g) for g in src['gate_patterns']]
    return rows

def parent_lp(lp,coeff,N):
    p={int(m):F(v) for m,v in lp['primal'].items()};u=list(map(F,lp['dual']));loads=[sum(v for m,v in p.items() if m>>i&1) for i in range(N)]
    assert all(v>=0 for v in p.values()) and all(v>=0 for v in u) and all(v<=1 for v in loads) and loads==list(map(F,lp['loads']))
    margins=[sum(u[i] for i in range(N) if m>>i&1)-v for m,v in coeff.items()];assert min(margins)==F(lp['min_dual_slack'])>=0
    assert sum(coeff[m]*v for m,v in p.items())==sum(u)==F(lp['value'])

def parent_flow_witness(cert,rows,g,prices,a0,hinges):
    N=len(prices);unary=[-prices[i]+a0*sum(r['nu']*active*r['a'][i] for r,active in zip(rows,g)) for i in range(N)];edges=[]
    for r,active in zip(rows,g):
        if not active or not r['nu']:continue
        for theta,d in hinges:
            A=r['nu']*d;j=len(unary);unary.append(A*(1-theta))
            edges.extend((j,i,A*a) for i,a in enumerate(r['a']) if a)
    S,T=len(unary),len(unary)+1
    for i,p in enumerate(unary):
        if p>0:edges.append((S,i,p))
        elif p<0:edges.append((i,T,-p))
    scale=cert['capacity_scale'];expected=sorted((i,j,int(c*scale)) for i,j,c in edges if c)
    assert all((c*scale).denominator==1 for i,j,c in edges)
    arcs=cert['original_arcs'];assert sorted((i,j,c) for i,j,c,f in arcs)==expected
    assert cert['source']==S and cert['sink']==T
    selected=set(cert['source_side']);assert S in selected and T not in selected;balance=[0]*(T+1)
    for i,j,c,f in arcs:assert 0<=f<=c;balance[i]-=f;balance[j]+=f
    flow=cert['flow'];assert balance[S]==-flow and balance[T]==flow and all(balance[i]==0 for i in range(S))
    assert sum(c for i,j,c,f in arcs if i in selected and j not in selected)==flow==cert['cut']
    positive=sum(max(F(0),p) for p in unary);assert positive-F(flow,scale)==F(cert['value'])
    assert sum(1<<i for i in range(N) if i in selected)==cert['mask']

def audit_parent_pl():
    d=json.loads((ROOT/'parent_pl_results.json').read_text());curves=[]
    for c in d['curves']:curves.append(curve_data(c))
    count=flowcount=lpcount=pointcount=stresscount=0
    for case in d['cases']:
        src=case['source'];N=src['N'];rows=parent_source_check(src);value,a0,hinges=curves[case['curve_index']];curve=d['curves'][case['curve_index']];k=case['k'];eps=F(curve['epsilon']);patterns=src['gate_patterns'];pack=case['full_packing'];coeff={}
        for m in range(1<<N):
            posterior=[sum(r['a'][i] for i in range(N) if m>>i&1) for r in rows];vals=[value(x) for x in posterior]
            for x,v in zip(posterior,vals):
                assert v**k>=x**(k+1);low=v-eps*x;assert low<=0 or low**k<=x**(k+1);pointcount+=1
            coeff[m]=[sum(r['nu']*active*v for r,active,v in zip(rows,g,vals)) for g in patterns]
        for pc in case['pricing_checks']:
            prices=list(map(F,pc['prices']));idx=pc['gate_pattern_index'];best=max(coeff[m][idx]-sum(prices[i] for i in range(N) if m>>i&1) for m in coeff);cert=pc['graphcut']
            assert best==F(pc['exhaustive_value'])==F(cert['value'])
            assert coeff[cert['mask']][idx]-sum(prices[i] for i in range(N) if cert['mask']>>i&1)==best;count+=1
            if 'original_arcs' in cert:parent_flow_witness(cert,rows,patterns[idx],prices,a0,hinges);flowcount+=1
        PL={m:max(vals) for m,vals in coeff.items() if m};assert PL=={int(m):F(v) for m,v in pack['coefficients_PL'].items()}
        lo={int(m):F(v) for m,v in pack['coefficients_true_lower'].items()};hi={int(m):F(v) for m,v in pack['coefficients_true_upper'].items()}
        # Exact 130-step root reference for every posterior, distinct from
        # production root cache. Its narrow intervals must lie in saved ones.
        cache={}
        for m in PL:
            posterior=[sum(r['a'][i] for i in range(N) if m>>i&1) for r in rows];ints=[]
            for x in posterior:
                if x in (0,1):cache[x]=(x,x)
                if x not in cache:
                    a,b=F(0),x;target=x**(k+1)
                    for _ in range(130):
                        mid=(a+b)/2
                        if mid**k<=target:a=mid
                        else:b=mid
                    cache[x]=(a,b)
                ints.append(cache[x])
            lows=[sum(r['nu']*active*z[0] for r,active,z in zip(rows,g,ints)) for g in patterns];highs=[sum(r['nu']*active*z[1] for r,active,z in zip(rows,g,ints)) for g in patterns]
            assert lo[m]<=max(lows)<=max(highs)<=hi[m]<=PL[m]
        for key,c in [('PL_LP',PL),('true_root_lower_LP',lo),('true_root_upper_LP',hi)]:parent_lp(pack[key],c,N);lpcount+=1
        assert F(pack['T'])==sum(r['nu'] for r in rows)
        assert F(pack['Bbar'])==F(pack['PL_LP']['value']) and F(pack['epsilon_times_T'])==eps*F(pack['T'])
        assert list(map(F,pack['theorem_interval']))==[F(pack['Bbar'])-eps*F(pack['T']),F(pack['Bbar'])]
        u=list(map(F,pack['PL_LP']['dual']))
        for gidx,cert in enumerate(pack['final_pricing']):
            assert max(coeff[m][gidx]-sum(u[i] for i in range(N) if m>>i&1) for m in coeff)==0==F(cert['value'])
    for stress in d['stress']:
        rows=parent_source_check(stress['source']);N=stress['source']['N'];c=next(c for c in d['curves'] if c['k']==stress['k'] and c['epsilon0']==stress['epsilon0']);value,a0,hinges=curve_data(c);w=[r['nu'] for r in rows];a=[r['a'] for r in rows];idx=0
        for p in [[F(0)]*N,[F(i%5,32) for i in range(N)]]:
            for g in stress['source']['gate_patterns'][:3]:
                v,m=pl_cut(a,w,g,p,a0,hinges);assert v==F(stress['pricing'][idx]['value']);idx+=1;stresscount+=1
    coarse=d.get('coarse_convex_hull_regression')
    if coarse:
        val,a0,hinges=curve_data(coarse['curve']);assert coarse['curve']['convex_hull_removed_nodes']>0
        k=coarse['curve']['k'];eps=F(coarse['curve']['epsilon'])
        for j in range(101):
            x=F(j,100);v=val(x);assert v**k>=x**(k+1);low=v-eps*x;assert low<=0 or low**k<=x**(k+1)
    ties=d.get('exact_density_tie_regressions',[])
    for tie in ties:
        n=tie['n'];row=tie['row'];assert tie['w']==[1,2**n-1]
        expected=F(1,2**(2*n));assert F(row['M'])==expected and F(row['r'])==1 and row['ids']==[0]
        assert all(F(z['density'])==expected for z in row['stages']) and len(row['stages'])==2
        assert F(tie['lambda_value'])<expected<=2*F(tie['lambda_value'])
    return dict(parent_PL_curve_certificates=len(curves),parent_PL_exhaustive_pricing_checks=count,parent_PL_full_flow_witnesses=flowcount,parent_PL_exact_LPs=lpcount,parent_PL_posterior_checks=pointcount,parent_PL_independent_stress_cuts=stresscount,parent_PL_exact_density_ties=len(ties),parent_PL_coarse_hull_pointchecks=101 if coarse else 0,parent_PL_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'parent_pl.py',ROOT/'parent_pl_results.json']})

def main():
    start=time.monotonic();out=math_selftest()
    if (ROOT/'pricing_probe.py').exists() and (ROOT/'pricing_results.json').exists():out.update(audit_production())
    if (ROOT/'parent_pl_results.json').exists():out.update(audit_parent_pl())
    out.update(status='PASS',seconds=time.monotonic()-start)
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
```


## 可移植独立守卫：soft_audit_guard.py

```python
#!/usr/bin/env python3
"""Exact rational guard for R75 soft-counter constants; no quadrature claims."""
from fractions import Fraction as Q
from math import comb
import json
checks=[]
def ck(name, assertion):
    assert assertion, name
    checks.append(name)
eps=Q(1,1024)
a=[Q(9,16),Q(3,16),Q(3,16),Q(1,16)]
b=[Q(1,4)]*4
q=[(x+y)/2 for x,y in zip(a,b)]
j=[2*(x-y)**2/(x+y) for x,y in zip(a,b)]
ck('K exact coefficients', q==[Q(13,32),Q(7,32),Q(7,32),Q(5,32)])
ck('J exact coefficients', j==[Q(25,104),Q(1,56),Q(1,56),Q(9,40)])
ck('I exact', sum(j)==Q(228,455))
ck('contrast exact', [x-y for x,y in zip(a,b)]==[Q(5,16),Q(-1,16),Q(-1,16),Q(-3,16)])
ck('J lower comparison', Q(9,40)>=Q(1,5))
ck('J upper comparison', 16*j[0]+4*(j[1]+j[2])+j[3]<5)
# exp(x)<=1/(1-x), 0<=x<1, is proved by termwise series comparison.
ck('posterior ratio < 50', 25/(1-16*eps)<50)
ck('tail product ratio < 6/5', Q(51,44)/(1-Q(1,100)-4*eps)<Q(6,5))
R=Q(1000)
# Ratios improve monotonically as R increases. Check the worst endpoint.
ck('lower-tail denominator product upper', ((1+(Q(1,100)+2*eps+6)/R)/2)**2<=Q(51,200))
d=Q(3,2)+eps
ck('upper-tail denominator product lower', (Q(1,3)-d/R)*(Q(2,3)-d/R)>=Q(11,50))
ck('all receivers outside hard supports', R/3-eps>Q(3,2))
ck('strip actual contrast > lambda', Q(3,16)>Q(1,6))
ck('strip actual F < 2 lambda', Q(5,32)*Q(6,5)<Q(2,6))
ck('strip actual C lower', Q(9,40)*6==Q(27,20))
ck('full-branch denominator lower coefficient', Q(27,20)/300==Q(9,2000))
ck('packet ratio coefficient rounded upward', 8/Q(9,2000)<1800)
ck('actual J coordinate tail coefficient', j[1]+j[2]+2*j[3]==Q(17,35))
# General n,delta check q*zeta^2 <=4q and exact E_q|m| =3n delta/4.
fee_rows=0
for n in range(1,33):
    for delta in {Q(1),Q(1,2),Q(1,n),Q(1,4*n)}:
        coeff_soft=Q(0)
        fee=Q(0)
        for k in range(n+1):
            aa=(delta/2)**k*(1-delta/2)**(n-k)
            bb=delta**k*(1-delta)**(n-k)
            qq=(aa+bb)/2
            cc=2*(aa-bb)**2/(aa+bb) if aa+bb else Q(0)
            ck(f'mask domination n={n} d={delta} k={k}', cc<=4*qq)
            coeff_soft+=comb(n,k)*k*cc
            fee+=comb(n,k)*cc
        ck(f'J tail coefficient n={n} d={delta}', coeff_soft<=3*n*delta)
        ck(f'I fee n={n} d={delta}', fee<=min(Q(4),2*n*delta))
        fee_rows+=1
print(json.dumps({'status':'PASS','exact_assertions':len(checks),'fee_rows':fee_rows,'I':'228/455','J_tail_coordinate_coefficient':'17/35','scope':'rational identities and inequalities; analytic envelope, exp comparison, log-Lipschitz and integration proofs are in soft_counter_audit.md'},indent=2))
```
