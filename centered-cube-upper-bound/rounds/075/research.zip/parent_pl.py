#!/usr/bin/env python3
"""Exact rational convex-PL graph-cut pricing; finite receiver/library certificates.

Standalone Python standard library. No floating point enters a certificate.
Run this file to regenerate parent_pl_results.json. The finite functional below
is a diagnostic, not Lebesgue integration or a continuous representative oracle.
"""
from fractions import Fraction as F
from collections import deque
from bisect import bisect_right
from functools import lru_cache
from pathlib import Path
import json, math, time

BITS = 100


def clean(x):
    if isinstance(x, F): return str(x)
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)): return [clean(v) for v in x]
    return x


@lru_cache(None)
def root_interval(s, k, bits=BITS):
    """Enclose s**((k+1)/k) by exactly bits bisections on [0,s]."""
    s = F(s)
    assert 0 <= s <= 1 and isinstance(k, int) and k >= 1
    if s in (0, 1): return s, s
    lo, hi, target = F(0), s, s**(k+1)
    for _ in range(bits):
        mid = (lo+hi)/2
        if mid**k <= target: lo = mid
        else: hi = mid
    assert lo**k <= target <= hi**k and hi-lo == s/F(2**bits)
    return lo, hi


class ConvexPL:
    def __init__(self, k, eps0, bits=BITS):
        self.k, self.eps0, self.bits = k, F(eps0), bits
        assert isinstance(k, int) and k >= 1 and 0 < self.eps0 < 1
        self.q = F(k+1, k)
        m = 1
        while self.q*(self.q-1)/(8*m*m) > self.eps0: m += 1
        self.r = 1+F(1, m)
        self.eps = self.eps0+F(1, 2**bits)
        knots = [F(0), self.eps0**k]
        while knots[-1] < 1: knots.append(min(F(1), knots[-1]*self.r))
        raw = [(s, root_interval(s, k, bits)[1]) for s in knots]
        self.raw_slopes = [(b[1]-a[1])/(b[0]-a[0]) for a, b in zip(raw, raw[1:])]
        # Exact lower convex hull. Each chord is a convex combination of upper
        # nodes, hence lies above the convex true function by Jensen. The hull
        # lies below the original polygon, retaining its relative error bound.
        hull = []
        for point in raw:
            while len(hull) >= 2:
                a, b = hull[-2:]
                if (b[1]-a[1])/(b[0]-a[0]) <= (point[1]-b[1])/(point[0]-b[0]): break
                hull.pop()
            hull.append(point)
        self.nodes = hull
        self.knots = [p[0] for p in hull]
        self.slopes = [(b[1]-a[1])/(b[0]-a[0]) for a, b in zip(hull, hull[1:])]
        assert all(a <= b for a, b in zip(self.slopes, self.slopes[1:]))
        self.a0 = self.slopes[0]
        self.hinges = [(hull[j][0], self.slopes[j]-self.slopes[j-1]) for j in range(1, len(self.slopes)) if self.slopes[j] > self.slopes[j-1]]
        self.raw = raw

    @lru_cache(None)
    def value(self, s):
        s = F(s)
        assert 0 <= s <= 1
        j = min(len(self.slopes)-1, bisect_right(self.knots, s)-1)
        return self.nodes[j][1]+self.slopes[j]*(s-self.nodes[j][0])

    def check_value(self, s):
        s = F(s); v = self.value(s)
        assert v >= 0 and v**self.k >= s**(self.k+1)
        low = v-self.eps*s
        assert low <= 0 or low**self.k <= s**(self.k+1)
        assert v == self.a0*s+sum(d*max(F(0), s-t) for t, d in self.hinges)
        return v

    def certificate(self):
        return dict(k=self.k, n=self.k**2, q=self.q, epsilon0=self.eps0,
                    epsilon=self.eps, root_bisection_bits=self.bits,
                    root_rule='mid^k <= s^(k+1); bracket [0,s]',
                    ratio=self.r, curvature_budget=self.q*(self.q-1)*(self.r-1)**2/8,
                    raw_nodes=self.raw, raw_slopes=self.raw_slopes,
                    raw_slopes_nondecreasing=all(a <= b for a,b in zip(self.raw_slopes,self.raw_slopes[1:])),
                    convex_hull_removed_nodes=len(self.raw)-len(self.nodes),
                    convex_nodes=self.nodes, convex_slopes=self.slopes,
                    convex_slopes_nondecreasing=True, linear_coefficient=self.a0,
                    hinges=self.hinges,
                    bound='s^q <= fbar(s) <= s^q + epsilon*s on [0,1]')


class Dinic:
    def __init__(self, n): self.g=[[] for _ in range(n)]; self.original=[]
    def edge(self,a,b,c):
        assert isinstance(c,int) and c>=0
        if not c: return
        i=len(self.g[a]); self.g[a].append([b,c,len(self.g[b])]); self.g[b].append([a,0,i]); self.original.append((a,b,c,i))
    def solve(self,s,t):
        value=0; n=len(self.g)
        while True:
            level=[-1]*n; level[s]=0; queue=deque([s])
            while queue:
                a=queue.popleft()
                for b,c,_ in self.g[a]:
                    if c and level[b]<0: level[b]=level[a]+1; queue.append(b)
            if level[t]<0: break
            ptr=[0]*n
            def push(a,bound):
                if a==t: return bound
                while ptr[a]<len(self.g[a]):
                    edge=self.g[a][ptr[a]]; b,c,r=edge
                    if c and level[b]==level[a]+1:
                        z=push(b,min(bound,c))
                        if z: edge[1]-=z; self.g[b][r][1]+=z; return z
                    ptr[a]+=1
                return 0
            while True:
                z=push(s,sum(e[1] for e in self.g[s]))
                if not z: break
                value+=z
        reach={s}; queue=deque([s])
        while queue:
            for b,c,_ in self.g[queue.popleft()]:
                if c and b not in reach: reach.add(b); queue.append(b)
        cut=sum(c for a,b,c,_ in self.original if a in reach and b not in reach)
        balances=[0]*n; flows=[]
        for a,b,c,i in self.original:
            flow=c-self.g[a][i][1]; assert 0<=flow<=c
            balances[a]-=flow; balances[b]+=flow; flows.append(flow)
        assert t not in reach and cut==value
        assert balances[s]==-value and balances[t]==value
        assert all(balances[i]==0 for i in range(n) if i not in (s,t))
        return value, reach, cut, flows


def direct(rows, gates, curve, mask, prices):
    N=len(prices)
    return sum(row['nu']*g*curve.value(sum(row['a'][i] for i in range(N) if mask>>i&1)) for row,g in zip(rows,gates))-sum(prices[i] for i in range(N) if mask>>i&1)


def graph_pricing(rows, gates, curve, prices, save_witness=False):
    N=len(prices); prices=list(map(F,prices)); assert all(p>=0 for p in prices)
    assert len(rows)==len(gates) and all(g in (0,1) for g in gates)
    assert all(row['nu']>=0 and len(row['a'])==N and all(a>=0 for a in row['a']) and sum(row['a'])==1 for row in rows)
    unary=[-prices[i]+curve.a0*sum(row['nu']*g*row['a'][i] for row,g in zip(rows,gates)) for i in range(N)]
    edges=[]; aux=[]
    for row,g in zip(rows,gates):
        if not g or not row['nu']: continue
        for theta,d in curve.hinges:
            A=row['nu']*d; node=len(unary); unary.append(A*(1-theta)); aux.append(node)
            for i,a in enumerate(row['a']):
                if a: edges.append((node,i,A*a))
    s,t=len(unary),len(unary)+1
    for i,z in enumerate(unary):
        if z>0: edges.append((s,i,z))
        elif z<0: edges.append((i,t,-z))
    scale=math.lcm(*(c.denominator for _,_,c in edges)) if edges else 1
    graph=Dinic(t+1)
    for a,b,c in edges: graph.edge(a,b,int(c*scale))
    flow,reach,cut,flows=graph.solve(s,t)
    positive=sum(max(F(0),z) for z in unary); value=positive-F(flow,scale)
    mask=sum(1<<i for i in range(N) if i in reach)
    assert value==direct(rows,gates,curve,mask,prices) and value>=0
    cert=dict(mask=mask,value=value,positive_unary=positive,flow=flow,cut=cut,capacity_scale=scale,
              nodes=t+1,auxiliary_nodes=len(aux),arcs=len(graph.original),
              capacity_bounds_checked=True,flow_conservation_checked=True,maxflow_equals_cut=True,direct_objective_equals_cut=True)
    if save_witness: cert.update(original_arcs=[(a,b,c,f) for (a,b,c,_),f in zip(graph.original,flows)],source=s,sink=t,source_side=sorted(reach))
    return cert


def simplex(coeff,N):
    """Exact capacity LP primal/dual witnesses, no numerical solver dependency."""
    masks=list(coeff); K=len(masks); total=K+N
    rows=[[F(bool(mask>>i&1)) for mask in masks]+[F(j==i) for j in range(N)]+[F(1)] for i in range(N)]
    reduced=[coeff[m] for m in masks]+[F(0)]*N; basis=list(range(K,total)); value=F(0); pivots=0
    while True:
        eligible=[j for j,z in enumerate(reduced) if z>0]
        if not eligible: break
        entering=max(eligible,key=lambda j:(reduced[j],-j))
        eligible=[i for i,row in enumerate(rows) if row[entering]>0]; assert eligible
        leaving=min(eligible,key=lambda i:tuple([rows[i][-1]/rows[i][entering]]+[z/rows[i][entering] for z in rows[i][K:K+N]]))
        row=rows[leaving]; pivot=row[entering]; row=[z/pivot for z in row]; rows[leaving]=row
        for i in range(N):
            if i!=leaving and rows[i][entering]:
                factor=rows[i][entering]; rows[i]=[a-factor*b for a,b in zip(rows[i],row)]
        factor=reduced[entering]; value+=factor*row[-1]; reduced=[a-factor*b for a,b in zip(reduced,row[:-1])]; basis[leaving]=entering; pivots+=1
        assert pivots<10000
    primal={m:F(0) for m in masks}
    for i,b in enumerate(basis):
        if b<K: primal[masks[b]]=rows[i][-1]
    dual=[-reduced[K+i] for i in range(N)]
    loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
    slack=[sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks]
    assert all(z>=0 for z in primal.values()) and all(z>=0 for z in dual) and all(z<=1 for z in loads) and all(z>=0 for z in slack)
    assert sum(coeff[m]*primal[m] for m in masks)==value==sum(dual)
    return dict(value=value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,min_dual_slack=min(slack),pivots=pivots,exact_primal_dual_equality=True)


def receiver(y,w,x,lam):
    """Actual centered cube winner: earliest radius under density ties."""
    n=len(x); W=sum(w); events={}
    for i,z in enumerate(y):
        r=max(abs(a-b) for a,b in zip(x,z)); assert r>0
        events.setdefault(r,[]).append(i)
    captured=0; ids=[]; best=F(0); stages=[]
    for r,block in sorted(events.items()):
        captured+=sum(w[i] for i in block); ids+=block
        density=F(captured,W)/(2*r)**n
        stages.append(dict(radius=r,entering=block,captured_mass=captured,density=density))
        if density>best: best=density; winner=(r,tuple(ids),captured)
    r,ids,C=winner
    return dict(x=x,r=r,ids=ids,C=C,M=best,band=lam<best<=2*lam,stages=stages,
                a=[F(w[i],C) if i in ids else F(0) for i in range(len(y))])


def fixture(n,N):
    # Several nearby pairs and heterogeneous masses give genuine distinct
    # radial capture stages, with additional dimensions preserving cube geometry.
    coords=[F(-3,4)+F(3*i,2*(N-1)) for i in range(N)]
    y=[tuple([c]+[F((i%2)*2-1,32) if j==1 else F(0) for j in range(1,n)]) for i,c in enumerate(coords)]
    w=[1+i%3 for i in range(N)]
    candidates=[]
    for t in (F(-5,8),F(-3,8),F(-1,8),F(1,8),F(3,8),F(5,8)):
        for h in (F(5,16),F(7,16),F(9,16)):
            x=tuple([t]+[h if j==1 else F(0) for j in range(1,n)]) if n>1 else (t+h,)
            if x not in y: candidates.append(receiver(y,w,x,F(1)))
    densities=sorted(r['M'] for r in candidates); lam=densities[len(densities)//2]*F(2,3)
    actual=[receiver(y,w,r['x'],lam) for r in candidates]
    band=[r for r in actual if r['band']]
    # Keep a small deterministic selection covering winner patterns and densities.
    selected=[]; patterns=set()
    for r in sorted(band,key=lambda r:(len(r['ids']),r['M'],r['x'])):
        if r['ids'] not in patterns or len(selected)<3:
            selected.append(r); patterns.add(r['ids'])
        if len(selected)>=6: break
    assert selected and all(r['band'] for r in selected)
    for r in selected: r['nu']=F(1,len(selected))
    reps=list(y)
    for block in (range(N),range(N//2),range(N//2,N)):
        reps.append(tuple((min(y[i][j] for i in block)+max(y[i][j] for i in block))/2 for j in range(n)))
    reps=list(dict.fromkeys(reps))
    gates=[tuple(int(max(abs(r['x'][j]-c[j]) for j in range(n))<=r['r']) for r in selected) for c in reps]
    unique=list(dict.fromkeys(gates)); assert any(any(g) for g in unique)
    return dict(n=n,N=N,y=y,w=w,lam=lam,representatives=reps,rows=selected,
                receiver_candidates=len(actual),receiver_band_count=len(band),gate_patterns=unique,
                representative_gate_patterns=gates)


def full_packing(src,curve):
    N=src['N']; rows=src['rows']; patterns=src['gate_patterns']; T=sum(r['nu'] for r in rows)
    coeff={}; lower={}; upper={}; reps={}; pointchecks=0
    for mask in range(1,1<<N):
        pl=[]; los=[]; his=[]
        posterior=[sum(r['a'][i] for i in range(N) if mask>>i&1) for r in rows]
        for s in posterior: curve.check_value(s); pointchecks+=1
        intervals=[root_interval(s,curve.k) for s in posterior]
        for g in patterns:
            pl.append(sum(r['nu']*gate*curve.value(s) for r,gate,s in zip(rows,g,posterior)))
            los.append(sum(r['nu']*gate*iv[0] for r,gate,iv in zip(rows,g,intervals)))
            his.append(sum(r['nu']*gate*iv[1] for r,gate,iv in zip(rows,g,intervals)))
        coeff[mask]=max(pl); lower[mask]=max(los); upper[mask]=min(coeff[mask],max(his)); reps[mask]=pl.index(coeff[mask])
        assert lower[mask]<=upper[mask]<=coeff[mask]
        # Source-capacity relative-error coefficient certificate.
        paid=sum(r['nu']*sum(r['a'][i] for i in range(N) if mask>>i&1) for r in rows)
        assert coeff[mask]-lower[mask] <= curve.eps*paid
    bar=simplex(coeff,N); lo=simplex(lower,N); hi=simplex(upper,N)
    theorem_lower=bar['value']-curve.eps*T
    assert theorem_lower<=lo['value']<=hi['value']<=bar['value']
    # Check sum alpha_J s_J<=1 at each row, without a factor N.
    row_loads=[sum(alpha*sum(r['a'][i] for i in range(N) if mask>>i&1) for mask,alpha in bar['primal'].items()) for r in rows]
    assert all(z<=1 for z in row_loads)
    final_pricing=[graph_pricing(rows,g,curve,bar['dual']) for g in patterns]
    assert all(z['value']==0 for z in final_pricing)
    return dict(all_nonempty_subsets=(1<<N)-1,T=T,Bbar=bar['value'],epsilon_times_T=curve.eps*T,
                theorem_interval=[theorem_lower,bar['value']],certified_true_q_interval=[lo['value'],hi['value']],
                Bbar_minus_epsilonT_le_Btrue_le_Bbar=True,PL_LP=bar,true_root_lower_LP=lo,true_root_upper_LP=hi,
                coefficients_PL=coeff,coefficients_true_lower=lower,coefficients_true_upper=upper,
                best_gate_pattern= reps,posterior_point_checks=pointchecks,PL_primal_row_occupancy=row_loads,
                all_library_final_pricing_zero=True,final_pricing=final_pricing)


def main():
    start=time.monotonic(); curves=[]; cases=[]; comparisons=0
    specs=[(1,4),(2,6),(3,8),(4,6),(8,4)]
    for k,N in specs:
        src=fixture(k*k,N)
        for eps0 in (F(1,16),F(1,64)):
            curve=ConvexPL(k,eps0); curves.append(curve.certificate())
            checks=[]
            pricesets=[[F(0)]*N,[F(i%4+1,16) for i in range(N)],[F((3*i+1)%7,8) for i in range(N)]]
            for pidx,prices in enumerate(pricesets):
                for gidx,g in enumerate(src['gate_patterns']):
                    cert=graph_pricing(src['rows'],g,curve,prices,save_witness=(pidx==1 and gidx==0))
                    brute=max(direct(src['rows'],g,curve,m,prices) for m in range(1<<N))
                    assert brute==cert['value']; comparisons+=1
                    checks.append(dict(prices=prices,gate_pattern_index=gidx,exhaustive_value=brute,all_masks=1<<N,exhaustive_equals_graphcut=True,graphcut=cert))
            packing=full_packing(src,curve)
            cases.append(dict(source=src,k=k,q=curve.q,epsilon0=eps0,curve_index=len(curves)-1,pricing_checks=checks,full_packing=packing))
            print('small',k*k,N,str(eps0),'patterns',len(src['gate_patterns']),'rows',len(src['rows']),'Bbar',float(packing['Bbar']),'seconds',round(time.monotonic()-start,2),flush=True)
    stress=[]
    for k,N in ((2,16),(8,24)):
        src=fixture(k*k,N); curve=ConvexPL(k,F(1,64)); result=[]
        for p in ([F(0)]*N,[F(i%5,32) for i in range(N)]):
            for g in src['gate_patterns'][:3]: result.append(graph_pricing(src['rows'],g,curve,p))
        stress.append(dict(source=src,k=k,q=curve.q,epsilon0=curve.eps0,pricing=result,exhaustive=False))
        print('stress',k*k,N,'oracle_calls',len(result),'seconds',round(time.monotonic()-start,2),flush=True)
    density_ties=[]
    for n in (1,4,9,16,64):
        y=[tuple([F(0)]+[F(0)]*(n-1)),tuple([F(1)]+[F(0)]*(n-1))]
        w=[1,2**n-1]; x=tuple([F(-1)]+[F(0)]*(n-1))
        density=F(1,2**(2*n)); row=receiver(y,w,x,density*F(2,3))
        assert row['band'] and row['r']==1 and row['ids']==(0,)
        assert len(row['stages'])==2 and all(e['density']==density for e in row['stages'])
        density_ties.append(dict(n=n,y=y,w=w,lambda_value=density*F(2,3),row=row,earliest_density_tie_winner_verified=True))
    # Deliberately coarse root brackets exercise convexification rather than
    # silently assuming the upper endpoint polygon has monotone slopes.
    coarse=ConvexPL(8,F(1,64),bits=1)
    assert len(coarse.raw)>len(coarse.nodes)
    for j in range(101): coarse.check_value(F(j,100))
    out=dict(status='VERIFIED',scope='Finite deterministic actual tied-winner receiver functional, fixed registered finite representative library. Neither Lebesgue integral nor continuous representative pricing is certified.',
             dependencies='Python standard library only',arithmetic='Fraction root brackets, exact integer capacities/flow, exact rational primal/dual simplex',
             curves=curves,cases=cases,stress=stress,exact_density_tie_regressions=density_ties,
             coarse_convex_hull_regression=dict(curve=coarse.certificate(),rational_point_checks=101),
             counts=dict(small_cases=len(cases),small_exhaustive_pricing_comparisons=comparisons,stress_cases=len(stress),full_packing_LPs=3*len(cases),exact_density_tie_tests=len(density_ties)),
             limitations=['No continuum x integration certificate','No continuous representative c oracle','No dimension-uniform continuum packing bound inferred from finite results'])
    Path(__file__).with_name('parent_pl_results.json').write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,2),flush=True)


if __name__=='__main__': main()
