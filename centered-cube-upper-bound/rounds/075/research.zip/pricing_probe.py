#!/usr/bin/env python3
"""Round75: certified q2 fixed-representative mincut pricing and finite-library
column generation on actual tied-winner receiver functionals. Standard library.
Finite-training upper certificates never imply continuum unrestricted LP bounds.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
from collections import deque
import argparse,json,math,random,time,hashlib

QD=1<<100
QW=1<<40
QE=1<<60

def floor_grid(x,Q):return F(x.numerator*Q//x.denominator,Q)
def ceil_grid(x,Q):return F(-(-x.numerator*Q//x.denominator),Q)
def clean(o):
    if isinstance(o,F):return str(o)
    if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
    if isinstance(o,(tuple,list)):return [clean(v) for v in o]
    return o

def proposed_basis(coeff,masks,N):
    K=len(masks);rows=[[float(bool(mask>>i&1)) for mask in masks]+[float(j==i) for j in range(N)]+[1.] for i in range(N)];cost=[float(coeff[m]) for m in masks]+[0.]*N;basis=list(range(K,K+N))
    seen=set()
    for iteration in range(128):
        identity=tuple(basis)
        if identity in seen:return basis
        seen.add(identity)
        entering=max(range(K+N),key=lambda j:cost[j])
        if cost[entering]<=1e-11:return basis
        eligible=[i for i in range(N) if rows[i][entering]>1e-11]
        if not eligible:return None
        leaving=min(eligible,key=lambda i:(rows[i][-1]/rows[i][entering],basis[i]));r=rows[leaving];factor=r[entering];r=[z/factor for z in r];rows[leaving]=r
        for i in range(N):
            if i!=leaving and abs(rows[i][entering])>1e-15:
                factor=rows[i][entering];rows[i]=[a-factor*b for a,b in zip(rows[i],r)]
        factor=cost[entering];cost=[a-factor*b for a,b in zip(cost,r[:-1])];basis[leaving]=entering
    return basis

def rebuild_basis(coeff,masks,N,basis):
    K=len(masks);B=[[F(bool(masks[b]>>i&1)) if b<K else F(b-K==i) for b in basis]+[F(i==j) for j in range(N)] for i in range(N)]
    for j in range(N):
        pivot=next((i for i in range(j,N) if B[i][j]),None)
        if pivot is None:return None
        B[j],B[pivot]=B[pivot],B[j];factor=B[j][j];B[j]=[z/factor for z in B[j]]
        for i in range(N):
            if i!=j and B[i][j]:
                factor=B[i][j];B[i]=[a-factor*b for a,b in zip(B[i],B[j])]
    inverse=[row[N:] for row in B];rows=[]
    for inv in inverse:
        D=math.lcm(*(z.denominator for z in inv));integer=[int(z*D) for z in inv];row=[F(sum(integer[j] for j in range(N) if mask>>j&1),D) for mask in masks]+inv+[sum(inv)]
        rows.append(row)
    original=[coeff[m] for m in masks]+[F(0)]*N;costB=[original[b] for b in basis];value=sum(costB[i]*rows[i][-1] for i in range(N));reduced=[original[j]-sum((costB[i]*rows[i][j] for i in range(N) if costB[i]),F(0)) for j in range(K+N)]
    return rows,reduced,value

def simplex(coeff,N):
    """Exact primal simplex with largest reduced cost and lexicographic ratio.
    Slack columns supply the exact infinitesimal RHS perturbation ordering.
    """
    masks=list(coeff);K=len(masks);total=K+N
    rows=[[F(bool(mask>>i&1)) for mask in masks]+[F(j==i) for j in range(N)]+[F(1)] for i in range(N)]
    reduced=[coeff[m] for m in masks]+[F(0)]*N;basis=list(range(K,total));value=F(0);pivots=0
    warm=False
    if N>=16:
        proposal=proposed_basis(coeff,masks,N)
        rebuilt=rebuild_basis(coeff,masks,N,proposal) if proposal is not None else None
        if rebuilt is None:
            proposal=list(range(N));rebuilt=rebuild_basis(coeff,masks,N,proposal)
        if rebuilt is not None:rows,reduced,value=rebuilt;basis=proposal;warm=True
        if warm:
            trial_dual=[max(F(0),-reduced[K+i]) for i in range(N)]
            residual=max([F(0)]+[coeff[m]-sum(trial_dual[i] for i in range(N) if m>>i&1) for m in masks])
            if True:
                dual=[z+residual for z in trial_dual];primal={m:F(0) for m in masks}
                for i,b in enumerate(basis):
                    if b<K:primal[masks[b]]=max(F(0),rows[i][-1])
                loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
                repair_scale=max([F(1)]+loads)
                primal={m:z/repair_scale for m,z in primal.items()}
                loads=[z/repair_scale for z in loads]
                assert all(v>=0 for v in primal.values()) and all(v<=1 for v in loads)
                value=sum(coeff[m]*primal[m] for m in masks);margins={m:sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks};assert all(v>=0 for v in margins.values()) and value<=sum(dual)
                return dict(value=value,dual_upper_value=sum(dual),primal_dual_gap=sum(dual)-value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,min_dual_slack=min(margins.values()),pivots=0,float_basis_proposal_used=True,active_dual_repair=residual,primal_repair_scale=repair_scale)

    while True:
        eligible_entering=[j for j,z in enumerate(reduced) if z>0]
        entering=max(eligible_entering,key=lambda j:(reduced[j],-j)) if eligible_entering else None
        if entering is None:break
        eligible=[i for i,row in enumerate(rows) if row[entering]>0]
        assert eligible,'bounded capacity LP cannot be unbounded'
        leaving=min(eligible,key=lambda i:tuple([rows[i][-1]/rows[i][entering]]+[z/rows[i][entering] for z in rows[i][K:K+N]]));row=rows[leaving];pivot=row[entering];row=[z/pivot for z in row];rows[leaving]=row
        for i in range(N):
            if i!=leaving and rows[i][entering]:
                factor=rows[i][entering];rows[i]=[a-factor*b for a,b in zip(rows[i],row)]
        factor=reduced[entering];value+=factor*row[-1];reduced=[a-factor*b for a,b in zip(reduced,row[:-1])];basis[leaving]=entering;pivots+=1
        assert pivots<10000
    primal={m:F(0) for m in masks}
    for i,b in enumerate(basis):
        if b<K:primal[masks[b]]=rows[i][-1]
    dual=[-reduced[K+i] for i in range(N)]
    assert all(z>=0 for z in primal.values()) and all(z>=0 for z in dual)
    loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
    assert all(z<=1 for z in loads)
    margins={m:sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks}
    assert all(z>=0 for z in margins.values())
    assert sum(coeff[m]*primal[m] for m in masks)==value==sum(dual)
    return dict(value=value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,min_dual_slack=min(margins.values()),pivots=pivots,float_basis_proposal_used=warm,dual_upper_value=value,primal_dual_gap=F(0),active_dual_repair=F(0))


class Dinic:
    def __init__(self,n):self.g=[[] for _ in range(n)];self.original=[]
    def edge(self,a,b,c):
        assert c>=0
        if not c:return
        index=len(self.g[a]);self.g[a].append([b,c,len(self.g[b])]);self.g[b].append([a,0,len(self.g[a])-1]);self.original.append((a,b,c,index))
    def solve(self,s,t):
        value=0;n=len(self.g)
        while True:
            level=[-1]*n;level[s]=0;queue=deque([s])
            while queue:
                a=queue.popleft()
                for b,c,r in self.g[a]:
                    if c and level[b]<0:level[b]=level[a]+1;queue.append(b)
            if level[t]<0:break
            ptr=[0]*n
            def push(a,bound):
                if a==t:return bound
                while ptr[a]<len(self.g[a]):
                    edge=self.g[a][ptr[a]];b,c,r=edge
                    if c and level[b]==level[a]+1:
                        z=push(b,min(bound,c))
                        if z:edge[1]-=z;self.g[b][r][1]+=z;return z
                    ptr[a]+=1
                return 0
            while True:
                z=push(s,sum(c for b,c,r in self.g[s]))
                if not z:break
                value+=z
        reach={s};queue=deque([s])
        while queue:
            for b,c,r in self.g[queue.popleft()]:
                if c and b not in reach:reach.add(b);queue.append(b)
        cut=sum(c for a,b,c,index in self.original if a in reach and b not in reach)
        assert t not in reach and cut==value
        # Flow conservation and capacity checks are independent of cut equality.
        balances=[0]*n
        for a,b,c,index in self.original:
            flow=c-self.g[a][index][1];assert 0<=flow<=c
            balances[a]-=flow;balances[b]+=flow
        assert balances[s]==-value and balances[t]==value and all(balances[i]==0 for i in range(n) if i not in [s,t])
        for a in range(n):
            for b,res,r in self.g[a]:
                back=self.g[b][r];assert back[0]==a and back[2]<len(self.g[a])
        return value,reach,len(self.original)

def subset_value(G,mask,den):
    ids=[i for i in range(len(G)) if mask>>i&1]
    return F(sum(G[i][j] for i in ids for j in ids),den)

def maxcut_pricing(G,den,prices):
    """Exact max_J b_J(c)-sum_{i in J}u_i; empty J allowed, value >=0.
    G is nonnegative symmetric integer moment matrix / den.
    Returns subset, exact value and maxflow=mincut witness summary.
    """
    N=len(G);assert len(prices)==N and all(u>=0 for u in prices)
    multiplier=math.lcm(*(u.denominator for u in prices));scale=den*multiplier
    h=[sum(G[i])*multiplier-int(prices[i]*scale) for i in range(N)]
    graph=Dinic(N+2);source=N;sink=N+1;positive=sum(max(0,z) for z in h)
    for i,z in enumerate(h):
        if z>0:graph.edge(source,i,z)
        elif z<0:graph.edge(i,sink,-z)
        for j in range(i):
            assert G[i][j]==G[j][i]
            w=G[i][j]*multiplier
            graph.edge(i,j,w);graph.edge(j,i,w)
    flow,reach,arcs=graph.solve(source,sink);mask=sum(1<<i for i in range(N) if i in reach);value=F(positive-flow,scale)
    direct=subset_value(G,mask,den)-sum((prices[i] for i in range(N) if mask>>i&1),F(0));assert value==direct and value>=0
    return dict(mask=mask,value=value,positive=positive,flow=flow,capacity_scale=scale,arc_count=arcs,maxflow_equals_cut=True,direct_objective_equals_cut=True)

def pack(label,y,weights,n,lam,blocks=None):
    y=[tuple(map(F,z)) for z in y];merged={}
    for p,w in zip(y,weights):merged[p]=merged.get(p,0)+int(w)
    yy=list(merged);ww=[merged[z] for z in yy];N=len(yy);assert N==len(y),'registered blocks require distinct source sites'
    reps=list(yy);kinds=['source_site']*N
    def add(c,kind):
        c=tuple(c)
        if c not in reps:reps.append(c);kinds.append(kind)
    add(tuple((min(z[k] for z in yy)+max(z[k] for z in yy))/2 for k in range(n)),'whole_bbox_center')
    for block in blocks or []:add(tuple((min(yy[i][k] for i in block)+max(yy[i][k] for i in block))/2 for k in range(n)),'registered_macro_bbox_center')
    return dict(label=label,n=n,N=N,y=yy,w=ww,W=sum(ww),lam=F(lam),blocks=blocks or [],representatives=reps,representative_kinds=kinds)

def actual_receiver(src,x):
    n=src['n'];N=src['N'];ys=src['y'];ws=src['w'];W=src['W'];lam=src['lam'];dist=[max(abs(x[k]-y[k]) for k in range(n)) for y in ys]
    assert all(dist),'atom receiver is excluded null set'
    events={}
    for i,r in enumerate(dist):events.setdefault(r,[]).append(i)
    best=F(0);captured=0;ids=[];answer=None
    for r,block in sorted(events.items()):
        captured+=sum(ws[i] for i in block);ids+=block;M=F(captured,W)/(2*r)**n
        if M>best:best=M;answer=(r,tuple(ids),captured)
    r,ids,C=answer;band=lam<best<=2*lam
    if not band:return dict(x=x,r=r,ids=ids,C=C,band=False,score_lower=F(0),score_upper=F(0))
    V=1/lam;qlo=F(0);qhi=F(0)
    for w,d in zip(ws,dist):
        tau=(2*d)**n/V;a=F(w,W)
        terms=[min(F(1),1/tau**2)/(4*N),a*min(F(1),1/tau**2)/8,min(F(1),(a/tau)**2)/8]
        for z in terms:qlo+=floor_grid(z,QD);qhi+=ceil_grid(z,QD)
    assert 0<qlo<=qhi
    sl=best/lam/qhi;su=best/lam/qlo;assert sl<=8*N and su<=8*N+F(1,1000000)
    return dict(x=x,r=r,ids=ids,C=C,band=True,score_lower=sl,score_upper=su,density_relative_width=float((qhi-qlo)/qlo))

def draw_receivers(src,S,seed):
    rng=random.Random(seed);n=src['n'];N=src['N'];cumulative=[];total=0
    for w in src['w']:total+=w;cumulative.append(total/src['W'])
    out=[]
    for _ in range(S):
        z=rng.random();component=0 if z<.5 else 1 if z<.75 else 2
        if component==0:center=rng.randrange(N)
        else:
            z=rng.random();center=next((i for i,c in enumerate(cumulative) if z<c),N-1)
        b=float(1/src['lam'])*(src['w'][center]/src['W'] if component==2 else 1.)
        U=max(rng.random(),math.nextafter(0.,1.));vol=b*U if rng.randrange(2)==0 else b/U
        theta=[rng.uniform(-1,1) for _ in range(n)];theta[rng.randrange(n)]=rng.choice([-1,1]);radius=.5*math.exp(math.log(vol)/n)
        x=tuple(F(float(src['y'][center][k])+radius*theta[k]) for k in range(n));out.append(actual_receiver(src,x))
    return out

def training_matrices(src,rows):
    S=len(rows);band=[r for r in rows if r['band']];D=math.lcm(*(r['C']**2 for r in band)) if band else 1;den=QW*D
    delta=F(0)
    for r in band:
        lower=r['score_lower']/S;upper=r['score_upper']/S;quant=floor_grid(lower,QW);r['weight_integer']=quant.numerator*(QW//quant.denominator);delta+=ceil_grid(upper-quant,QE)
    patterns={};rep_map=[];matrices=[]
    for c in src['representatives']:
        pattern=tuple(max(abs(r['x'][k]-c[k]) for k in range(src['n']))<=r['r'] for r in band)
        if pattern not in patterns:
            G=[[0]*src['N'] for _ in range(src['N'])]
            for active,r in zip(pattern,band):
                if active and r['weight_integer']:
                    factor=r['weight_integer']*(D//r['C']**2)
                    for i in r['ids']:
                        for j in r['ids']:G[i][j]+=factor*src['w'][i]*src['w'][j]
            patterns[pattern]=len(matrices);matrices.append(G)
        rep_map.append(patterns[pattern])
    return matrices,rep_map,den,delta,band

def restricted_column_generation(src,matrices,rep_map,den,max_rounds=100):
    N=src['N'];active={};reps={};history=[];cache={}
    def best(mask):
        if mask not in cache:
            values=[subset_value(G,mask,den) for G in matrices];gid=max(range(len(values)),key=lambda j:values[j]);rid=rep_map.index(gid);cache[mask]=(values[gid],rid)
        return cache[mask]
    initial=[1<<i for i in range(N)]+[(1<<N)-1]+[sum(1<<i for i in block) for block in src['blocks']]
    for mask in initial:active[mask],reps[mask]=best(mask)
    oracle_calls=0;certificate=[]
    for iteration in range(max_rounds):
        lp=simplex(active,N);certificates=[maxcut_pricing(G,den,lp['dual']) for G in matrices];oracle_calls+=len(certificates)
        residual=max(c['value'] for c in certificates);violations=sorted({c['mask'] for c in certificates if c['value']>F(1,10**12)})
        history.append(dict(iteration=iteration,active_columns=len(active),objective=lp['value'],maximum_reduced_cost=residual,LP_pivots=lp['pivots']))
        if N==64 and iteration%10==0:print('CG',src['label'],'round',iteration,'columns',len(active),'gap',float(lp['primal_dual_gap']),'residual',float(residual),flush=True)
        if not violations:
            lp['global_dual_repair']=residual
            lp['dual']=[u+residual for u in lp['dual']]
            lp['dual_upper_value']=sum(lp['dual']);lp['primal_dual_gap']=lp['dual_upper_value']-lp['value']
            certificate=[maxcut_pricing(G,den,lp['dual']) for G in matrices];oracle_calls+=len(certificate)
            assert all(c['value']==0 for c in certificate)
            lp['min_dual_slack']=min(sum(lp['dual'][i] for i in range(N) if m>>i&1)-active[m] for m in active)
            assert lp['min_dual_slack']>=0 and lp['primal_dual_gap']>=0
            break
        for mask in violations:
            value,rid=best(mask)
            assert mask not in active or value>active[mask]
            active[mask]=value;reps[mask]=rid
    else:raise RuntimeError('registered column generation round cap reached')
    assert all(c['value']==0 for c in certificate)
    return dict(LP=lp,active_coefficients=active,active_representatives=reps,history=history,oracle_calls=oracle_calls,final_pricing=certificate,registered_library_optimal=(lp['primal_dual_gap']==0),registered_library_bracket_certified=True)

def validate(src,rows,result):
    scores=[];occupation=[];paid=[]
    for r in rows:
        factor=F(0)
        for mask,alpha in result['LP']['primal'].items():
            c=src['representatives'][result['active_representatives'][mask]]
            if max(abs(r['x'][k]-c[k]) for k in range(src['n']))<=r['r']:
                a=F(sum(src['w'][i] for i in r['ids'] if mask>>i&1),r['C']);factor+=alpha*a*a
        assert 0<=factor<=1
        base=float((r['score_lower']+r['score_upper'])/2);scores.append(base*float(factor));occupation.append(base)
    def stats(v):
        mean=sum(v)/len(v);se=math.sqrt(sum((z-mean)**2 for z in v)/(len(v)-1)/len(v));B=8*src['N']
        return dict(mean=mean,sample_SE=se,maximum=max(v),ideal_bound=B,ideal_Hoeffding95_radius=B*math.sqrt(math.log(40)/(2*len(v))))
    return dict(packing=stats(scores),occupation=stats(occupation),max_density_relative_width=max((r.get('density_relative_width',0.) for r in rows),default=0.),sample_ratio=sum(scores)/sum(occupation) if sum(occupation) else None)

def fixtures(pilot=False):
    ans=[]
    def add(*args,**kw):ans.append(pack(*args,**kw))
    add('vertices4_n2',[(-1,-1),(-1,1),(1,-1),(1,1)],[1]*4,2,F(1,32))
    add('heterogeneous6_n2',[(-2,-1),(-2,1),(0,F(-1,2)),(0,F(1,2)),(2,-1),(2,1)],[1,1,2,2,4,4],2,F(1,32))
    rng=random.Random(750008);add('unequal8_n3',[tuple(F(rng.randrange(-32,33),32) for _ in range(3)) for j in range(8)],[1+j%4 for j in range(8)],3,F(1,64))
    if pilot:return ans
    for n,N in [(2,16),(4,32),(8,64)]:
        rng=random.Random(750000+n*100+N);macro=[tuple(F(rng.randrange(-16,17),8) for k in range(n)) for g in range(8)];K=N//8
        yy=[tuple(macro[g][k]+F(2*j+1-K,4096*K)*(1 if k%2==0 else -1) for k in range(n)) for g in range(8) for j in range(K)];blocks=[list(range(g*K,(g+1)*K)) for g in range(8)]
        add(f'macro8_n{n}_K{K}',yy,[1]*(N),n,F(1,2**(n+3)),blocks)
    for n,N in [(4,16),(8,32),(2,64)]:
        rng=random.Random(751000+n*100+N);yy=[tuple(F(rng.randrange(-64,65),64) for k in range(n)) for j in range(N)];add(f'cloud_n{n}_N{N}',yy,[1+(j%8)**2 for j in range(N)],n,F(1,2**(n+1)))
    n=8;N=16;rng=random.Random(752816);labels=rng.sample(range(1<<n),N);yy=[tuple(F(2*((v>>k)&1)-1) for k in range(n)) for v in labels];add('binary_n8_N16',yy,[1]*N,n,F(1,2**(n+3)))
    return ans

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args();start=time.monotonic();records=[];exhaustive_checks=0
    for sid,src in enumerate(fixtures(args.pilot)):
        trainS=64 if args.pilot else 256
        training=draw_receivers(src,trainS,751000+sid);G,rep_map,den,delta,band=training_matrices(src,training);result=restricted_column_generation(src,G,rep_map,den)
        occupation_prices=[sum((F(r['weight_integer'],QW)*F(src['w'][i],r['C']) for r in band if i in r['ids']),F(0)) for i in range(src['N'])]
        lp=result['LP']
        if sum(occupation_prices)<lp['dual_upper_value']:
            lp['pre_occupation_dual_upper']=lp['dual_upper_value'];lp['dual']=occupation_prices;lp['dual_upper_value']=sum(occupation_prices);lp['primal_dual_gap']=sum(occupation_prices)-lp['value'];lp['dual_upper_source']='occupation_first_moment'
            result['final_pricing']=[maxcut_pricing(matrix,den,occupation_prices) for matrix in G];result['oracle_calls']+=len(G)
            assert all(c['value']==0 for c in result['final_pricing'])
            lp['min_dual_slack']=min(sum(lp['dual'][i] for i in range(src['N']) if mask>>i&1)-value for mask,value in result['active_coefficients'].items())
            assert lp['min_dual_slack']>=0 and lp['primal_dual_gap']>=0
            result['registered_library_optimal']=(lp['primal_dual_gap']==0)
        else:lp['dual_upper_source']='repaired_master_prices'

        small_guard=None
        if src['N']<=8:
            exact={};bestreps={}
            for mask in range(1,1<<src['N']):
                values=[subset_value(matrix,mask,den) for matrix in G];gid=max(range(len(values)),key=lambda j:values[j]);exact[mask]=values[gid];bestreps[mask]=rep_map.index(gid)
            bruteLP=simplex(exact,src['N']);assert bruteLP['value']==result['LP']['value']
            # Price vectors independent of the column-generation optimal dual.
            rng=random.Random(759000+sid);vectors=[[F(0)]*src['N']]+[[F(rng.randrange(0,33),64) for _ in range(src['N'])] for j in range(3)]
            for prices in vectors:
                for matrix in G:
                    brute=max([F(0)]+[subset_value(matrix,mask,den)-sum(prices[i] for i in range(src['N']) if mask>>i&1) for mask in range(1,1<<src['N'])]);oracle=maxcut_pricing(matrix,den,prices);assert brute==oracle['value'];exhaustive_checks+=1
            small_guard=dict(all_subsets=len(exact),exhaustive_LP_equals_column_generation=True,independent_price_vectors=len(vectors),distinct_gate_matrices=len(G))
        validation=[];S=128 if args.pilot else 512
        for seed in [752000+10*sid,752001+10*sid]:validation.append(dict(seed=seed,samples=S,**validate(src,draw_receivers(src,S,seed),result)))
        quantT=F(sum(r['weight_integer'] for r in band),QW)
        records.append(dict(source=src,training_seed=751000+sid,training_samples=trainS,training_band_count=len(band),distinct_gate_matrices=len(G),matrix_denominator=den,quantization_error_upper=delta,training_quantized_occupation=quantT,training_registered_library_B_lower=result['LP']['value'],training_registered_library_B_upper=result['LP']['dual_upper_value']+delta,column_generation=result,small_exhaustive_guard=small_guard,validation=validation,training_receivers=[dict(x=r['x'],radius=r['r'],captured_indices=r['ids'],captured_integer_mass=r['C'],weight_integer=r['weight_integer']) for r in band]))
        print(src['label'],'N',src['N'],'matrices',len(G),'CG rounds',len(result['history']),'columns',len(result['active_coefficients']),'seconds',round(time.monotonic()-start,3),flush=True)
    out=dict(float_proposal_iteration_limit=128,round=75,status='PILOT' if args.pilot else 'FINAL',scope='q=2 source-capacity LP for the registered finite representative library and quantized actual tied-winner training functional; independent held-out full-space evaluation. No continuum unrestricted B upper bound.',counts=dict(sources=len(records),training_draws=sum(r['training_samples'] for r in records),validation_draws=sum(v['samples'] for r in records for v in r['validation']),exhaustive_pricing_comparisons=exhaustive_checks,pricing_oracle_calls=sum(r['column_generation']['oracle_calls'] for r in records)),cases=records)
    Path(__file__).with_name('pricing_results.json').write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n');print('DONE',out['counts'],'seconds',time.monotonic()-start,flush=True)

if __name__=='__main__':main()
