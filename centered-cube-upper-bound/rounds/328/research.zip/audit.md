# R328 independent preauthor screen — general-soft whole-crossing budget

Ownership: only /tmp/r328_audit.md. No Git or other-author edits. No new R328 author proof has been read. Original U_y=1_E alpha P_s,L/q, full J,A, actual R/L/s/q, same beta,nu, original masks and source ledger are frozen. Use only FIRST rho=integral U_y beta<=1_E, original same-R nu cap4lambda R^n and finite integral rho. No beta=f, hard q or alpha reset is assumed.

## 1. Exact weighted physical-overshoot identity

For H>0 define the original crossing rows Y_H={J_y(b)>=H}, tau_y=first radius with J_y>=H, h_y=Delta J_y(tau_y), and o_y=J_y(tau_y)-H. The left limit is<=H, so0<=o_y<=h_y; if h_y=0 then o_y=0. Set kappa_y=o_y/h_y when h_y>0 and0 otherwise. Rows that never cross contribute zero. Define the actual weighted overshoot density

 rho_over(u)=integral_(Y_H) kappa_y U_y(u)1{R(u)=tau_y}beta(dy).

Positive Tonelli gives the EXACT source/receiver identity

 integral_(Y_H)o_y beta(dy)=integral_E rho_over(u)du,
 0<=rho_over<=rho.

It uses the original full J and entire physical-radius atom. It does not substitute a clipped receiver row or sort/recompute an original history. Continuous crossings have no overshoot. Measurability follows from original inclusive CDF crossing/atom kernels. Counting each source's selected atom before Tonelli is essential; integral beta DeltaJ_y(t) at a single fixed t does not by itself settle a y-dependent crossing.

## 2. Strong universal whole-initializer account

Let F_y(r)=integral[A-A²/J]nu. It is nonnegative, right-continuous and nondecreasing, with all intrinsic block and prediction innovations retained. The original high-J physical loss has exact decomposition

 B_H=E_H+I_after,
 E_H=integral_(Y_H)tau_y^(-n)F_y(tau_y)beta(dy),
 I_after=integral_(Y_H)beta(dy)integral_(tau_y,b]r^(-n)dF_y(r)>=0.

The original same-R cap gives

 F_y(tau)<=integral_prefix U_y nu(Q_R)du
          <=4lambda tau^n J_y(tau).

Therefore, without a hard shared identity,

 E_H<=4lambda H beta(Y_H)+4lambda integral rho_over,
 B_H<=4lambda H Wbeta+4lambda integral rho_over+I_after.

This is a useful exact weighted budget, not a dimension-free bound on each DeltaJ. Universally only integral rho_over<=integral rho is supplied, so this yields at most4X_rho, X_rho=lambda integral rho, as overshoot output price; coefficient4 is not an absorbable small error. To use a small4delta X_rho charge one must actually prove integral rho_over<=delta integral rho on the original fields/outer range. Authentic M3 can aggregate only the corresponding weighted original occupancy; it does not prove that small ratio.

There IS a directly source-priced positive initializer subclass: rows with o_y<=delta H have their WHOLE crossing paid by4lambda H(1+delta)Wbeta. h_y<=delta H is a sufficient but stronger condition. The complete large-overshoot initializer and all post-crossing innovations remain. This row selection is source-only and retains original full J; its coverage may be zero. It is not a new proof that every crossing satisfies the condition.

## 3. A usable envelope-controlled positive overshoot component

For any frozen original receiver subset B, split rho_over by1_B and1_Bc, leaving the same kappa_y and crossing times. If a genuine original kernel envelope proves

 sup_y integral U_y(u)1_B(u)du<=M_B,

then integral rho_over^B<=M_B Wbeta. Hence

 E_H<=4lambda H Wbeta+4lambda M_B Wbeta
                   +4lambda integral rho_over^Bc.

This gives a source payment of a real overshoot component without changing q, alpha, J or any hard cap. It cannot be added to another whole-B_H payment covering that same component.

For example the already independently audited R321 high-softness joint(s,L) envelope, on B={s>=1-1/(2sqrt(n))} in one physical octave, gives M_B<=13sqrt(n)/q_-. It therefore prices this overshoot component by(208/3)sqrt(n)Wbeta, with the original low-softness overshoot still explicit. This reuses the existing high-soft envelope; no new theorem or general original-history coverage of this branch is claimed. If that original lineage makes the high-soft event empty, the component is simply zero.

Another precise conditional case: if ALL original receivers in one physical R=t atom have L in a fixed interval[ell_t,u_t], the fullsoft positive profile/dilation envelope gives

 DeltaJ_y(t)<=[1+nlog(u_t/ell_t)]Csoft/q_-.

A multiplicative width exp(C/n) yields a root Csoft atom bound and source-priced whole crossing. For general varyingL over[a,b], the same generic bound is A_n Csoft/q_-, potentially order n^(3/2), not root. The narrow-window condition must apply to the ORIGINAL full atom. Splitting it into ratio bands and charging each source anew is forbidden; uniqueness of one band for each receiver does not itself control their sum on a y-dependent crossing.

## 4. Small relative increments do not pay the later scale sum

At a radius block with old mass J, new mass h and capture fractions p_z,v_z,

 DeltaF=integral[h v_z(1-v_z)+Jh/(J+h)(v_z-p_z)^2]nu(dz).

The within-block term is order h, without an h/J multiplier. The between coefficient is also asymptotic to h when h/J is small, not h²/J. For example J=100,h=1,p=v=1/2 gives intrinsic increment1/4 even though h/J=1/100; with p=0,v=1 the innovation coefficient100/101 exceeds1/100. Splitting a real same-radius block into many artificial microbatches does not remove the physical group's intrinsic variance. Its common-rank identity still retains all resulting innovations.

The actual same-R cap/FIRST can bound total baseline by4X_rho or A_nWnu, but neither supplies the required small output plus root source bound for I_after. A weighted rate/variance certificate, extra original atom envelope condition or a proved shared-source geometry estimate is needed. The whole physical crossing account pays no chronological initial/deletion/future-source atoms and gives no general-soft legacy identity.

## 5. Actual bounded tool evidence and initial verdict

Actually executed402 exact Fraction assertions:240 source-row overshoot checks,80 weighted source/receiver identities,80 pointwise density bounds,2 unsuppressed intrinsic/innovation checks. Finite arrays retain FIRST but are algebra diagnostics, not a claimed actual soft-kernel/history construction. General-input statements above are analytic Tonelli/variance/envelope arguments; no R327 run or broad counterexample search was repeated.

Initial verdict: PASS for the universal weighted-overshoot account, source-priced small-overshoot rows, and conditional original-envelope-controlled component. No universal root atom bound or generally root-priced post-H scale sum follows. Await author proofs for bounded comparison; all original full-J/source/outer obligations remain intact.

## 6. Final author comparison and bounded verdict (2026-10-18)

The preauthor statements in sections1–5 above describe the initial screen, not the final read status. The reviewer subsequently read the complete final /tmp/r328_aux.md and /tmp/r328_core.md, numeric source/notes, checkpoint ledger and combined report. Final bounded verdict: PASS; no mathematical correction remains within this scope.

Hard-matched theorem: beta=f, nu<=f, alpha=1, s=0, L=R and q=h_R*f are essential. They justify both h=DeltaJ<=1/q_- and J(b)<=A_n/q_-. A late physical atom contributes its WHOLE positive variance increment, bounded by2lambda h. Multiplicative growth therefore pays the atoms h/J_- >=eta by

 (2lambda/q_-) log_+(A_n/(q_-H))/log(1+eta) Wbeta.

At eta=A_n^(-1/2), the16/3 coefficient is correct. At a legitimately chosen H=sqrt(A_n)/lambda the displayed root/log crossing-plus-large-atom formula is correct. The existing initializer is charged once; paid blocks stay in subsequent original J,A,F. Continuous and smaller atoms satisfy I_rem=D_rem-Z_old-C_small with STRICT old physical prefix, and the stated C_small<=min(eta,1/(q_-H))I_rem. This is not a small upper bound on I_rem. The original negative square is already represented and cannot be subtracted again. Physical radius atoms are not historical time/deletion atoms.

General-soft theorem: E_H=L^-_H+C_H-S_H is exact with the complete ORIGINAL crossing square. L^-_H<=4lambda H beta(Y_H) uses only the actual hard cap. The actual crossing occupancy pi<=rho<=1 is supported, up to dx-null sets, on the countable effective atomic radius set of rho dx: the common countable positive-Lebesgue level set argument correctly removes beta-null rows, even though tau depends on y. This is a necessary point that a fixed-radius integral alone would not prove. The proof handles tau=a,b, J(tau-)=H, continuous crossings, empty spectrum, and never-crossing rows. Countable capacities use finite exhaustions, without assuming a monotone radius enumeration. The finite weighted suffix-maximum shell formula is correct; unweighted capacity is1+sum[1-(t_i/t_(i+1))^n], while empty capacity is0. Thus

 B_H<=4lambda H beta(Y_H)+K(T,eta)Wnu-S_H+I_H.

No beta=f identity, source density cap or higher-soft response cap has been imported into this theorem. The actual H and its low-row entrance remain fixed. Pure source replacement consumes no new positive X reserve. With target/recovery2Lambda all four terms carry that factor exactly once. Dense spectra can have capacity A_n; no root claim follows without a bound on its actual weighted occupancy or cancellation by S_H.

## 7. Numeric and integration scope

The reviewer read the actual numeric implementation and scope notes, without repeating the primary's final runs. The source f=beta=nu=1_Q4 and shell receiver fields are genuine finite L1 inputs; SAME-current-radius tensor intersections and positive-volume source-box enclosures are correct. q=1, FIRST and same-radius caps hold. The high-J central source subset is positive but has tiny mass; the representative H uses declared d=1 and is not a certification of the original lowpe/history parameter. Full-nu FIRST MOMENT is integrated exactly; full-nu SECOND MOMENT and global B_H are not computed. Neither selected probes nor their box enclosures replace them.

Primary reported actual fresh executions recorded in verification.txt:4044 numeric+138 hard-atom+696 general crossing/capacity+434 independent capacity=5312 exact assertions. This receipt attributes those runs to the primary. The independent reviewer's earlier402 Fraction assertions are separate and are not added to that count. These diagnostics support algebra and model bookkeeping; they do not replace the analytic proof or prove a dense-spectrum root estimate. The434-check script independently evaluates shell capacities and weighted suffix maxima in dimensions1 through64.

Checkpoint ledger/combined PASS for bounded mathematical scope. The R323 entrance remains qualified by its actual masks/source/outer contract; hard matching is not asserted for a general-soft slot. Crossing and post-crossing replacements are not added twice. No free H change, no unproved global absorption and no new epsilon loss are claimed. The existing2Lambda epsilon_CZ=1/256 is not the complete original epsilon ledger. The unresolved hard continuous/small innovations, general-soft dense-atom C_H-S_H and subsequent I_H, original Phi_next/full-square and suffix slots, initial/deletion/future-deletion time atoms, wider scale/aspect/outer and entrance obligations all remain explicit. In particular the requested general dimension-only bound is still unproved.

Only the mathematical source/report and code scopes stated above were reviewed. research.tex is hash-bound as primary-owned typesetting metadata; no compilation or independent line-by-line TeX certification is asserted.

## 8. Frozen SHA256 bindings

- /tmp/r328_aux.md — 7e9947b4efbf4184ffe0c30bfea876ea7193a6a405052f7573ad81f4e3075b29
- /tmp/r328_core.md — 6106aef465c641d4397d07fa6cc987bf3a99385c3b6741d6cee914de69d93ee9
- /tmp/r328_numeric.py — 910281e86362c3a0a2016b55ca4d0da1db470146f3370f5f079f2d4ce5cd5cad
- /tmp/r328_numeric.md — ebeb675914e2b3edcce54a94fd0bce0d1f540449b0b5f3828aeb2541230105fe
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/aux_checks.py — 53f989228348d93b994e2936d6ea9ff54e6fe0a7a34b39965c7a0fd57f9a0f92
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/capacity_checks.py — 869b023cbb6b503ab018948fdeb2586b214dadcc71b74e776172c0933374557a
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/combined.md — 239ebfc9c66a265806cc35fb9b2d18715abde00f861613fe0fc83510b987575e
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/core_checks.py — b57bd1d451794a4a99ee158bd62f7ce1ee1bbd3873965a891ea65fa05fdb8321
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/general_soft.md — 6106aef465c641d4397d07fa6cc987bf3a99385c3b6741d6cee914de69d93ee9
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/hard_atoms.md — 7e9947b4efbf4184ffe0c30bfea876ea7193a6a405052f7573ad81f4e3075b29
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/ledger.md — 93854c5f29dbdac99cdb1833067805632416e01770f73d38a3b9309bafd199f6
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/numeric.py — 910281e86362c3a0a2016b55ca4d0da1db470146f3370f5f079f2d4ce5cd5cad
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/numeric_notes.md — ebeb675914e2b3edcce54a94fd0bce0d1f540449b0b5f3828aeb2541230105fe
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/numeric_summary.json — 27d57995cd63d6398ae9a8504c7d8983e19cf48d30eda22a1d0e0bfdded92a98
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/research.tex — 15ed2f308530d98d4e8e01bf79700513d543503474b82742ef99a3386dd83a8b
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round328_20261018_final_checkpoint/verification.txt — 9633494f1c46959004f79432154316b7ef686eec30ab31aa98e7af1471421932

Final status: PASS for these bounded receipts and integration; exact unpaid terms above retained. Frozen after this append. No other file was edited and no Git operation was used.
