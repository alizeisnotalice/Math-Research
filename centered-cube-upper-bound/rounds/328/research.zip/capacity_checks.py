from fractions import Fraction as F
from itertools import combinations
count=0
for n in (1,2,4,8,16,32,64):
 for k in range(1,6):
  for radii in combinations([F(1),F(5,4),F(3,2),F(7,4),F(2)],k):
   cap=F(1)+sum((1-(a/b)**n for a,b in zip(radii,radii[1:])),F(0))
   volume=F(0);prev=F(0)
   for r in radii:
    volume+=(r**n-prev**n)/r**n;prev=r
   assert cap==volume and 1<=cap<=k
   weights=[F(i+1,k) for i in range(k)]
   weighted=F(0);prev=F(0)
   for i,r in enumerate(radii):
    weighted+=(r**n-prev**n)*max(weights[j]/radii[j]**n for j in range(i,k));prev=r
   assert 0<weighted<=cap
   count+=2
print('PASS capacity exact checks',count)
