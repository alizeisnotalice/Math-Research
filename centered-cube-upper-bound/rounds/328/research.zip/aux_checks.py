from fractions import Fraction as F
from itertools import product
ct=dict(atom_identity=0,atom_fee=0,correction=0,
        large_fee=0,count=0,small_bound=0,nondiscount=0)
hs=(F(1,4),F(3,4),F(5,4),F(1,3))
vs=((F(0),F(1,2),F(1)),(F(1),F(0),F(1,2)),
    (F(1,2),)*3,(F(0),F(1),F(0)))
w=(F(1,3),)*3
for H,eta in product((F(1,2),F(1),F(3)),
                     (F(1,8),F(1,4),F(1,2))):
    J=H; A=[J*v for v in (F(1,4),F(1,2),F(3,4))]
    N=0; Ilarge=Csmall=Ismall=F(0)
    for i,(h,v) in enumerate(zip(hs,vs)):
        t=1+F(i,10); p=[a/J for a in A]
        delta=sum(w[k]*(h*v[k]*(1-v[k])
                  +J*h/(J+h)*(v[k]-p[k])**2) for k in range(3))
        L=sum(w[k]*h*(v[k]*(1-v[k])+(v[k]-p[k])**2)
              for k in range(3))
        C=sum(w[k]*h*h/(J+h)*(v[k]-p[k])**2 for k in range(3))
        Anew=[A[k]+h*v[k] for k in range(3)]
        oldF=sum(w[k]*(A[k]-A[k]**2/J) for k in range(3))
        newF=sum(w[k]*(Anew[k]-Anew[k]**2/(J+h)) for k in range(3))
        assert newF-oldF==delta==L-C>=0; ct['atom_identity']+=1
        assert delta/t<=2*h and h<=F(4,3); ct['atom_fee']+=1
        assert C<=(h/J)*delta; ct['correction']+=1
        if h>=eta*J:
            N+=1; Ilarge+=delta/t
        else:
            Ismall+=delta/t; Csmall+=C/t
        J+=h; A=Anew
    assert H*(1+eta)**N<=J; ct['count']+=1
    assert Ilarge<=F(8,3)*N; ct['large_fee']+=1
    assert Csmall<=eta*Ismall; ct['small_bound']+=1
for d in (F(1,2),F(1,16),F(1,1024)):
    J=1/d; h=F(1); p=v=F(1,2)
    assert h/J==d and h*v*(1-v)+J*h/(J+h)*(v-p)**2==F(1,4)
    ct['nondiscount']+=1
print('PASS',ct,'total',sum(ct.values()))
