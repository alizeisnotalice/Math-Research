#!/usr/bin/env python3
"""Exact actual uniform-source, many-radius R328 diagnostic; standard library only."""
from fractions import Fraction as Q
from collections import Counter
from pathlib import Path
import json,hashlib

def fmt(x):
 if not isinstance(x,Q) or max(x.numerator.bit_length(),x.denominator.bit_length())<1800:return str(x)
 raw=(str(x.numerator.bit_length())+":").encode()+x.numerator.to_bytes((x.numerator.bit_length()+7)//8,"big",signed=False)+b"/"+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,"big")
 return dict(decimal=float(x),fraction_sha256=hashlib.sha256(raw).hexdigest(),encoding="numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes")
C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k

def ln2_bounds():
 t=Q(1,3);lo=2*sum((t**(2*i+1)/Q(2*i+1) for i in range(40)),Q(0))
 return lo,lo+2*t**81/(81*(1-t*t))
def inter(side,R,z):
 if side==0:return Q(0)
 out=Q(1)
 for x in z:out*=max(Q(0),min(side/2,x+R/2)-max(-side/2,x-R/2))
 return out

def model(n):
 eta=Q(1,4*n);rs=[1+Q(j,n) for j in range(n+1)];sides=[r-eta for r in rs]
 vols=[s**n-(sides[j-1]**n if j else 0) for j,s in enumerate(sides)]
 hs=[v/r**n for v,r in zip(vols,rs)];Js=[];acc=Q(0)
 for j,(r,v,h) in enumerate(zip(rs,vols,hs)):
  acc+=h;Js.append(acc)
  ck('actual_q_FIRST_and_cap',Q(1)==r**n/r**n and Q(1)<=4)
  ck('Q_R_receiver_inside_Q4',(r-eta)/2+r/2<=2)
  ck('central_source_whole_capture',(r-eta)/2+eta/2<=r/2)
  ck('physical_atom_bound',0<h<=1)
  ck('shell_positive_and_partition',v>0 and sum(vols[:j+1])==(r-eta)**n)
 ck('actual_source_receiver_mass',4**n>0 and eta**n>0 and sum(vols)==(2-eta)**n)
 # Integrated full-nu FIRST MOMENT is exact by Tonelli, not sampling.
 M=sum(vols);ck('full_nu_first_moment',sum(h*r**n for h,r in zip(hs,rs))==M)
 lo,hi=ln2_bounds();Hlo=(1+n*lo)/4;Hhi=(1+n*hi)/4
 gates=[]
 for J in Js:
  ck('certified_root_gate_decision',J*J<Hlo or J*J>=Hhi)
  gates.append(J*J>=Hhi)
 ck('nonempty_root_high_J',gates[-1])
 cross=gates.index(True);Jc=Js[cross];prev=Js[cross-1] if cross else Q(0)
 ck('first_cross_old_strict',prev*prev<Hlo)
 ck('actual_whole_cross_bound',Jc<=1 or (Jc-1)**2<=Hlo)
 # Integral initializer <=r_cross^-n M_cross<=J_cross<=H+1, with nu=f and q=1.
 Mcr=sum(vols[:cross+1]);ck('integrated_initializer_upper',Mcr/rs[cross]**n<=Jc)
 zlist=[('central',[Q(0)]*n),('one_boundary',[Q(1,2)]+[Q(0)]*(n-1)),('diffuse_boundary',[Q(1,2)]*n),('one_far',[Q(3,2)]+[Q(0)]*(n-1)),('source_edge',[Q(2)]+[Q(0)]*(n-1))]
 columns=[];positive=0
 for name,z in zlist:
  A=Q(0);J=Q(0);F=Q(0);Fs=[];preloss=Q(0);corr=Q(0);postdelta=Q(0)
  for j,(r,h) in enumerate(zip(rs,hs)):
   cv=inter(sides[j],r,z)-inter(sides[j-1] if j else 0,r,z);a=cv/r**n;v=a/h
   ck('actual_shell_intersection_fraction',0<=a<=h)
   newA=A+a;newJ=J+h;newF=newA-newA*newA/newJ
   intrinsic=h*v*(1-v)
   innovation=J*h/newJ*(A/J-v)**2 if J else Q(0)
   ck('actual_column_variance_increment',newF-F==intrinsic+innovation)
   if J:
    p=A/J;L=h*(v*(1-v)+(v-p)**2);D=h*h/newJ*(v-p)**2
    ck('strict_old_prefix_loss',newF-F==L-D)
    ck('predictable_correction_bound',0<=D<=h/J*(newF-F))
    if gates[j-1]:preloss+=L;corr+=D;postdelta+=newF-F
   A,J,F=newA,newJ,newF;Fs.append(F)
  ck('post_cross_predictor_complete',postdelta==Fs[-1]-Fs[cross] and postdelta==preloss-corr)
  ell=[r**(-n)-(rs[j+1]**(-n) if j<n else 0) for j,r in enumerate(rs)]
  B=sum(w*f for w,f,g in zip(ell,Fs,gates) if g)
  parts=rs[cross]**(-n)*Fs[cross]+sum(rs[j]**(-n)*(Fs[j]-Fs[j-1]) for j in range(cross+1,n+1))
  ck('BH_ell_and_innovation_endpoint',B==parts)
  positive+=B>0
  # Positive-volume sourcebox, actual capture-volume monotonicity in |z_i|.
  width=eta/2;zc=[min(Q(2)-width,x) for x in z];near=[max(Q(0),x-width/2) for x in zc];far=[x+width/2 for x in zc]
  lower=upper=Q(0)
  for j,(r,h) in enumerate(zip(rs,hs)):
   low=(inter(sides[j],r,far)-inter(sides[j-1] if j else 0,r,far))/r**n
   up=(inter(sides[j],r,near)-inter(sides[j-1] if j else 0,r,near))/r**n
   # A shell need not be coordinatewise decreasing. Bound cumulative using each
   # shell's actual intersection extremes only after interval extrema refinement:
   # triangle-safe enclosure by outer-box minimum minus inner-box maximum.
   low=max(Q(0),(inter(sides[j],r,far)-inter(sides[j-1] if j else 0,r,near))/r**n)
   up=min(h,(inter(sides[j],r,near)-inter(sides[j-1] if j else 0,r,far))/r**n)
   center=(inter(sides[j],r,zc)-inter(sides[j-1] if j else 0,r,zc))/r**n
   ck('positive_sourcebox_capture_enclosure',0<=low<=center<=up<=h)
   lower+=low;upper+=up
  columns.append(dict(mode=name,BH_at_point=fmt(B),F_final=fmt(F),post_loss=fmt(preloss),post_correction=fmt(corr),positive_box_side=str(width),positive_box_mass=str(width**n),positive_box_A_final_lower=str(lower),positive_box_A_final_upper=str(upper)))
 ck('nonzero_selected_column_variance',positive>0)
 atomcounts=[]
 for ratio in [Q(1,4),Q(1,2)]:
  count=0;product=Q(1)
  for j in range(cross+1,n+1):
   if hs[j]>=ratio*Js[j-1]:count+=1;product*=Js[j]/Js[j-1]
  # H is irrational: H>prev and H<=Jc; use Jc for fully exact post-cross count.
  ck('large_atom_multiplicative_count',(1+ratio)**count<=product<=Js[-1]/Jc)
  atomcounts.append(dict(ratio=str(ratio),post_cross_large_atoms=count))
 return dict(n=n,eta=str(eta),receiver_volume=str(M),W_beta=str(4**n),W_nu=str(4**n),central_source_mass=str(eta**n),central_J=str(Js[-1]),central_J_decimal=float(Js[-1]),H2_lower=str(Hlo),H2_upper=str(Hhi),first_high_index=cross,first_high_radius=str(rs[cross]),J_cross=str(Jc),cross_atom=str(hs[cross]),root_high_radii=sum(gates),full_nu_first_moment=str(M),full_nu_second_moment='NOT COMPUTED; point/box diagnostics are not substituted for this integral',columns=columns,large_atom_counts=atomcounts)

def main():
 stages=[];models=[]
 for title,ns in [('initial',[4,8]),('boundary_manyscale',[16,32]),('expanded',[64])]:
  before=sum(C.values());models.extend(model(n) for n in ns);stages.append(dict(stage=title,dimensions=ns,checks=sum(C.values())-before))
 result=dict(status='PASS',total_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='Actual positive-L1 f=beta=nu=1_Q4; actual s0,L=R,q=lambda1,alpha1,FIRST; positive-dx shell receiver field. Representative root H uses lambda=d1. Not a full original-history, winner or lowpe certificate. Full-nu second moment/BH is not computed.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
