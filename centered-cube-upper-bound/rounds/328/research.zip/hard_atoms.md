# R328 — source payment of large relative physical atoms, with the small/continuous innovation kept exact

**Proved new positive allocation.** In the R327 hard-matched slot, the post-crossing variance innovation from all physical-radius atoms with relative row increment `ΔJ/J_-≥η` has source-once fee

\[
 \frac{2\lambda}{q_-}
 \frac{\log_+(A_n/(q_-H))}{\log(1+\eta)}W_\beta.          \tag{0}
\]

With `η=1/√A_n`, this is at most `(16/3)√A_n log_+(A_n/(q_-H))Wβ`: root times a logarithm on a finite octave. Zero new output loss is used. The complete within-atom variance is included. Continuous innovation and the smaller relative atoms remain unpaid; an exact transfer below locates their remaining strictly ordered cube-overlap cost and its old-potential subtraction. Small relative increments do not themselves make that remaining cost small.

## 1. Preserve the actual hard-matched contract and the paid crossing

Use R327's ORIGINAL fields: `β=f`, `0≤ν≤β`, `α=1,s=0,L=R`, `E` finite, `a≤R(u)≤b`, and

\[
 q(u)=h_{R(u)}*f(u)\in[q_-,\lambda],\quad q_-=3\lambda/4,
 \quad U_y(u)=\frac{1_E(u)c_u(y)}{q(u)R(u)^n},
 \quad c_u(z)=1_{Q_{R(u)}(u)}(z).
\]

Thus `ρ(u)=∫U_y(u)β(dy)=1_E(u)`, `Xρ=λ|E|`. Keep the full original

\[
 J_y(r)=\int_{R(u)\le r}U_y(u)du,\quad
 A_{yz}(r)=\int_{R(u)\le r}U_y(u)c_u(z)du,
\]
\[
 F_y(r)=\int\left[A_{yz}(r)-A_{yz}(r)^2/J_y(r)\right]\nu(dz),
 \quad\ell_n=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
 \quad A_n=1+n\log(b/a).                                \tag{1}
\]

The source `ν` is never replaced by a density-capped input. For `Y_H={y:J_y(b)≥H}`, let `τ_y` be its inclusive first crossing of the actual `J≥H` gate. R327 gives the exact identity

\[
 B_H=\mathcal E_H+\mathcal I_H,
 \quad\mathcal I_H=\int_{Y_H}\beta(dy)
                   \int_{(\tau_y,b]}t^{-n}dF_y(t),
 \quad\mathcal E_H\le(\lambda H+4/3)W_\beta.              \tag{2}
\]

The whole crossing atom is already included in `E_H`. It is not included again below. This is the physical-radius clock, not chronological/source-history deletion time. After a portion of innovation is paid, its receiver block remains in every later ORIGINAL `J,A,F`; paid blocks are not deleted from the predictor's history.

Two hard-kernel row facts are

\[
 \Delta J_y(t)\le1/q_-,\qquad J_y(b)\le A_n/q_-.          \tag{3}
\]

The first follows from `E∩{R=t}∩Q_t(y)` having volume at most `t^n`. For the second, integrate `q_-^{-1}sup_{a≤R≤b}h_R(u-y)` over the actual receiver set and then all space; the exact full-space envelope mass is `A_n`. Neither bound is granted to an arbitrary coarse block spanning several physical radii. Physical-radius atoms lie in a common countable set: a zero-volume level set `{R=t}` has zero row atom for every `y`. This also makes the positive atomic allocations below measurable.

## 2. Whole-atom innovation has a dimension-free source fee

Fix `y` and a late atom `t>τ_y`. Write

\[
 j=J_y(t-)\ge H,\quad h=\Delta J_y(t)>0,\quad
 p_z=A_{yz}(t-)/j,\quad v_z=\Delta A_{yz}(t)/h.
\]

The exact positive whole-atom increment is

\[
 \Delta F_y(t)=\int\left[h v_z(1-v_z)
             +\frac{jh}{j+h}(v_z-p_z)^2\right]\nu(dz).  \tag{4}
\]

Both `p_z,v_z∈[0,1]`. The actual source cap inherited from the SAME `q` gives

\[
 \int v_z\nu(dz)
 =h^{-1}\int_{R(u)=t}U_y(u)\nu(Q_t(u))du
 \le\lambda t^n,
\]
\[
 \int p_z\nu(dz)
 =j^{-1}\int_{R(w)<t}U_y(w)\nu(Q_{R(w)}(w))dw
 \le\lambda t^n.                                      \tag{5}
\]

Here `ν(Q_R(w))≤f(Q_R(w))=q(w)R(w)^n≤λR(w)^n`; no cap is evaluated at a new receiver or radius. Since

`v(1−v)+(j/(j+h))(v−p)²≤v(1−v)+(v−p)²≤v+p`,

equations (4),(5) give the actual integrated estimate

\[
 \boxed{\quad t^{-n}\Delta F_y(t)\le2\lambda h
                                     \le2\lambda/q_-.\quad} \tag{6}
\]

This pays the full within-block variance as well as the drift. It is not a point-source sample standing in for integration in `ν`.

## 3. Large relative atoms are a source-paid root/log branch

Fix `η>0`. Allocate the late physical atoms with

\[
 h/j\ge\eta                                                   \tag{7}
\]

to `I_large`; allocate all other late atoms and the continuous part of `dF_y` to `I_rem`. This is an exact positive decomposition `I_H=I_large+I_rem`. Each large atom multiplies the full `J` by at least `1+η`. Small atoms and continuous growth only increase it further. Hence its rowwise count `N_y` satisfies

\[
 (1+\eta)^{N_y}H\le J_y(b)\le A_n/q_-,\quad
 N_y\le\frac{\log_+(A_n/(q_-H))}{\log(1+\eta)}.          \tag{8}
\]

If `A_n/(q_-H)≤1`, there are no such late atoms. Infinite counts are impossible. By (6),

\[
 \boxed{\quad I_{\rm large}\le
 \frac{2\lambda}{q_-}
  \frac{\log_+(A_n/(q_-H))}{\log(1+\eta)}W_\beta.\quad}  \tag{9}
\]

The more precise fee is `2λ∫β(dy)Σ_large ΔJ_y(t)`. Formula (9) is its source-linear count bound. The count factor is explicitly paid; there are no independent copies of `Wβ` per source/scale.

For `η=1/√A_n≤1`, use `log(1+η)≥η/2` and `λ/q_-=4/3`:

\[
 I_{\rm large}\le\frac{16}{3}\sqrt{A_n}
                      \log_+(A_n/(q_-H))W_\beta.          \tag{10}
\]

For example, if the original ledger legitimately chooses `H=√A_n/λ`, (2),(10) imply

\[
 B_H\le\left[\sqrt{A_n}+\frac43+
      \frac{16}{3}\sqrt{A_n}\log(4\sqrt{A_n}/3)\right]W_\beta
           +I_{\rm rem}.                               \tag{11}
\]

A finite octave has `A_n≤1+n log2`. Changing `H` or its complementary low-row ledger is not free; (9) is valid for the actual fixed `H`. It adds zero `Xρ` loss. In an old outer receipt, replace only the `I_H` residual slot by (9) plus `I_rem`, multiplying both by that slot's actual recovery/target coefficients. Do not add the already-paid R327 crossing again.

There is no coverage guarantee for the large-atom branch. In particular if `1/(q_-H)<η`, all late atoms are small. A continuously distributed radius law has no large physical atoms. Neither case contradicts (9).

## 4. Small atoms: exact predictable centering, not an innovation discount

At the same atom let

\[
 L_y(t)=h\int[v_z(1-v_z)+(v_z-p_z)^2]\nu(dz),\qquad
 C_y(t)=\frac{h^2}{j+h}\int(v_z-p_z)^2\nu(dz).
\]

Then

\[
 \Delta F_y(t)=L_y(t)-C_y(t),\qquad
 0\le C_y(t)\le(h/j)\Delta F_y(t).                       \tag{12}
\]

On the continuous part of the actual radius pushforward the predictable squared loss equals `dF_y` exactly. Consequently define `χ_rem(y,t)` to be one for a remaining continuous level or remaining small atom after `τ_y`, and zero on allocated large atoms and at/before `τ_y`. With the STRICT old full prefix

\[
 p^-_{yz}(t)=A_{yz}(t-)/J_y(t-),
\]

the actual predictable remaining loss is

\[
 L_{\rm rem}=\int\beta(dy)\int_E\frac{U_y(u)}{R(u)^n}
     \chi_{\rm rem}(y,R(u))
                  \int(c_u(z)-p^-_{yz}(R(u)))^2\nu(dz)du.
\]

The exact identity and error estimate are

\[
 I_{\rm rem}=L_{\rm rem}-C_{\rm small},\quad
 0\le C_{\rm small}\le\min\{\eta,1/(q_-H)\}I_{\rm rem}
                    \le\min\{\eta,1/(q_-H)\}X_\rho.      \tag{13}
\]

The last bound uses R327's `I_H≤B_H≤Xρ`. The correction is favorable; it need not be spent as a positive error if retained. Replacing `I_rem` by `L_rem` loses only this controlled favorable term, but does NOT prove `I_rem≤ηXρ`. For instance, the scalar binary mixture `v=p=1/2` has `ΔF=h/4` independently of how small `h/j` is. This illustrates the within-block term in (4); it is not an original-cube counterexample. Arbitrarily grouping continuous radii into row-clock increments cannot use the single-physical-radius atom cap (3) for free.

## 5. The remaining exact geometric term has strictly ordered physical scales

Let `j=J_y(R(u)-)`, and use the ORIGINAL old receiver law `U_y(w)1_(R(w)<R(u))dw/j`. It includes previously paid blocks. Since the capture indicators are binary,

\[
 (c_u(z)-p_z)^2
 =\int(c_u(z)-c_w(z))^2\frac{U_y(w)1_{R(w)<R(u)}}j dw
                              -p_z(1-p_z).
\]

Thus

\[
 L_{\rm rem}=D_{\rm rem}-Z_{\rm old},                    \tag{14}
\]
\[
 D_{\rm rem}=\int\beta(dy)\int_E\frac{U_y(u)\chi_{\rm rem}(y,R(u))}
                                   {R(u)^nJ_y(R(u)-)}
  \int_{R(w)<R(u)}U_y(w)
       \nu\big(Q_{R(u)}(u)\triangle Q_{R(w)}(w)\big)dw\,du,
\]
\[
 Z_{\rm old}=\int\beta(dy)\int_E\frac{U_y(u)\chi_{\rm rem}(y,R(u))}
                                      {R(u)^n}
                         \frac{F_y(R(u)-)}{J_y(R(u)-)}du.
                                                               \tag{15}
\]

These are true boundary SOURCE masses at actual cubes; no boundary volume is multiplied by an assumed density. All new/old pairs have `R(w)<R(u)`, including when `u` belongs to a whole physical-radius atom. Its within-block variance has not disappeared: it is represented by averaging the real new capture indicators against the strict old prefix and by the exact corrections (12)–(15).

Both nonnegative terms are finite. Bound the symmetric difference by the sum of the two actual captured masses. Its new-cube part is at most `Xρ` by FIRST and `ν(Q_R)≤qR^n`. Its old-cube part is at most `Xρ` because `ν(Q_(R(w))(w))≤λR(w)^n≤λR(u)^n` and the full old receiver mass cancels `J_y(R(u)-)`. Therefore

\[
 D_{\rm rem}\le2X_\rho,
 \qquad\boxed{\ I_{\rm rem}=D_{\rm rem}-Z_{\rm old}-C_{\rm small}.\ } \tag{16}
\]

This is an alternative ledger for the original variance innovation. Its old-potential and centering credits already encode the relevant original square; the original whole `E_full` must not be subtracted again. The bound `2Xρ` is not an absorbable small coefficient. No estimate `D_rem−Z_old≤εXρ+C√A_n log^C(Wβ+Wν)` is proved. This strictly ordered geometric predictor loss, with all original source roles and full history, is the precise remaining budget. General-soft extensions are outside this note.

## 6. Executed bounded algebra checks and actual-model scope

A local Fraction run passed **138 exact assertions** of whole-atom identity/source-fee inequalities, multiplicative counts, positive large/small allocation and the small-centering bound. The short scalar mixtures are not claimed to realize an original high-dimensional cube kernel. The separate numerical author is checking a genuine growing-dimension hard input with `f=β=ν=1_(Q4)`, actual radial receiver shells, `q=1`, exact growing `J`, positive central source region, and exact selected-source capture volumes. Selected-source values do not replace integration of full `F_y`; the integrated theorem above is analytical.

```python
from fractions import Fraction as F
from itertools import product
ct=dict(atom_identity=0,atom_fee=0,correction=0,
        large_fee=0,count=0,small_bound=0,nondiscount=0)
hs=(F(1,4),F(3,4),F(5,4),F(1,3))
vs=((F(0),F(1,2),F(1)),(F(1),F(0),F(1,2)),
    (F(1,2),)*3,(F(0),F(1),F(0)))
w=(F(1,3),)*3
for H,eta in product((F(1,2),F(1),F(3)),
                     (F(1,8),F(1,4),F(1,2))):
    J=H; A=[J*v for v in (F(1,4),F(1,2),F(3,4))]
    N=0; Ilarge=Csmall=Ismall=F(0)
    for i,(h,v) in enumerate(zip(hs,vs)):
        t=1+F(i,10); p=[a/J for a in A]
        delta=sum(w[k]*(h*v[k]*(1-v[k])
                  +J*h/(J+h)*(v[k]-p[k])**2) for k in range(3))
        L=sum(w[k]*h*(v[k]*(1-v[k])+(v[k]-p[k])**2)
              for k in range(3))
        C=sum(w[k]*h*h/(J+h)*(v[k]-p[k])**2 for k in range(3))
        Anew=[A[k]+h*v[k] for k in range(3)]
        oldF=sum(w[k]*(A[k]-A[k]**2/J) for k in range(3))
        newF=sum(w[k]*(Anew[k]-Anew[k]**2/(J+h)) for k in range(3))
        assert newF-oldF==delta==L-C>=0; ct['atom_identity']+=1
        assert delta/t<=2*h and h<=F(4,3); ct['atom_fee']+=1
        assert C<=(h/J)*delta; ct['correction']+=1
        if h>=eta*J:
            N+=1; Ilarge+=delta/t
        else:
            Ismall+=delta/t; Csmall+=C/t
        J+=h; A=Anew
    assert H*(1+eta)**N<=J; ct['count']+=1
    assert Ilarge<=F(8,3)*N; ct['large_fee']+=1
    assert Csmall<=eta*Ismall; ct['small_bound']+=1
for d in (F(1,2),F(1,16),F(1,1024)):
    J=1/d; h=F(1); p=v=F(1,2)
    assert h/J==d and h*v*(1-v)+J*h/(J+h)*(v-p)**2==F(1,4)
    ct['nondiscount']+=1
print('PASS',ct,'total',sum(ct.values()))
```

Only `/tmp/r328_aux.md` is authored; no Git or other agent's files were changed. The bounded result is the actual paid large-atom branch (9), not a root assertion for its complete small/continuous complement.
