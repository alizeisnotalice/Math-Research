from fractions import Fraction as F
from random import Random
rng=Random(328); envelope=0; crossing=0
for n in range(1,13):
    for K in range(1,9):
        ts=[F(1)+F(i,K) for i in range(K)]
        eta=[F(rng.randrange(0,9),8) for t in ts]
        exact=sum((ts[i]**n-(ts[i-1]**n if i else 0))*
                  max(eta[j]/ts[j]**n for j in range(i,K))
                  for i in range(K))
        unweighted=F(1)+sum(1-(ts[i-1]/ts[i])**n
                            for i in range(1,K))
        assert 0<=exact<=unweighted<=K
        assert exact<=sum(eta)
        envelope+=1
for _ in range(600):
    old=F(rng.randrange(0,9),4)
    atom=F(rng.randrange(1,13),4)
    H=old+atom*F(rng.randrange(1,5),4)
    p=F(rng.randrange(0,9),8); v=F(rng.randrange(0,9),8)
    Aold=old*p; Aatom=atom*v; J=old+atom; A=Aold+Aatom
    square=A*A/J; Ffull=A-square
    assert Ffull==Aold+Aatom-square
    assert Ffull<=H+Aatom-square
    crossing+=1
print('weighted-spectrum checks',envelope,
      'whole-crossing square checks',crossing)
