# R328 actual many-radius high-J diagnostic

Frozen bounded computation, standard-library `fractions.Fraction`; no random matrices, quadrature or floating-point gate decisions. Run:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r328_numeric.py
```

The script writes compact deterministic JSON beside itself. Long nonnegative exact fractions are represented by an explicitly encoded numerator/denominator digest and a descriptive decimal; all assertions use the full fractions before compression.

## Actual input and scope

For n=4,8,16,32,64, let η=1/(4n), f=β=ν=1 on the side-4 cube Q4, λ=q=1, s=0, α=1 and L=R. Radii r_j=1+j/n, j=0,...,n. Actual receiver field E is Q_(2−η), partitioned into E0=Q_(1−η) and shells Ej=Q_(r_j−η) minus Q_(r_(j−1)−η). Boundaries are null. All receiver kernel cubes lie within Q4 by the exact coordinate margin (r_j−η)/2+r_j/2≤2. Consequently their actual response is q=1, FIRST density is 1_E, and the selected same-radius ν response is 1≤4λ. This is an actual endpoint-soft kernel subcase with shared full β=f=ν, not arbitrary receiver weights.

Every y in the positive-volume central source box Qη is captured by every receiver at its assigned radius, since (r_j−η)/2+η/2=r_j/2. Thus the exact row occupation increments are

h0=(1−η)^n; hj=[(r_j−η)^n−(r_(j−1)−η)^n]/r_j^n.

The representative root threshold is H²=(1+n log2)/4 with declared λ=d=1. The script encloses log2 by 40 positive atanh terms and an exact geometric remainder. Each prefix gate and its first crossing are decided by squared rational comparisons to this enclosure.

| n | final central J | first high radius | number of high radius blocks |
|---|---:|---:|---:|
|4|2.504493|5/4|4|
|8|4.164786|5/4|7|
|16|7.483036|9/8|15|
|32|14.118403|9/8|29|
|64|27.388578|35/32|59|

All five dimensions therefore have a genuine positive-Lebesgue high-J source subset, unlike R327. Its mass η^n is small: approximately 1.53e−5, 9.09e−13, 1.26e−29, 3.71e−68, 7.46e−155. Full Wβ=Wν=4^n is retained. This is nonvacuity evidence, not an extremal construction or a dimension-rate conclusion.

## Exact tested quantities

For central y, selected source locations z are 0, (1/2,0,...), (1/2,...,1/2), (3/2,0,...), and (2,0,...). Each actual shell capture integral is computed by tensor interval intersections with the current hard cube Q_rj(z), subtracting the inner receiver cube using the SAME current radius. It is not inferred from shell centers. For each column, exact pooling gives

ΔF=h v(1−v)+Jh/(J+h)(v−p)².

The strict old-prefix predictor loss is L=h[v(1−v)+(v−p)²], its exact correction C=h²/(J+h)(v−p)², and ΔF=L−C with 0≤C≤(h/J)ΔF. All post-crossing blocks are retained, including any large blocks. The finite ell sum with final b atom equals r_cross^(−n)F_cross plus every later r_j^(−n)ΔF_j. Several selected columns have positive variance; the fully central and support-edge columns have zero variance. Positive-volume source boxes surrounding the probes additionally receive safe exact capture enclosures, obtained as outer-box minimum minus inner-box maximum and the reverse bound. Shell intersections themselves need not be coordinatewise monotone.

For post-cross atoms with h/J≥1/4 or ≥1/2, the product of actual occupation multipliers controls (1+ratio)^count and is ≤J_final/J_cross. Counts for ratio1/4 are 1,1,1,0,0; all ratio1/2 counts are zero. These values do not remove the remaining small-atom/continuous expense.

The full-ν FIRST MOMENT is actually integrated by Tonelli: ∫ν A(prefix)=Σ prefix |Ej|, because ν(Q_rj(x))=r_j^n for every receiver. Hence the whole-cross initializer has the certified upper bound r_cross^(−n) M_cross≤J_cross≤H+1. This upper bound is not an evaluation of full-ν variance. Full-ν second moments and global BH are NOT computed; selected columns or source-box enclosures are never substituted for that global integral.

## Actual execution

Two fresh standalone processes passed the same 4,044 exact checks: initial n4/8:452; boundary/many-scale n16/32:1,568; expanded n64:2,024. The JSON gives complete category counts and exact gate data. Descriptive decimals alone are not certificates. No full original winner/lowpe/history qualification or overall root budget is asserted.
