# R328 — general-soft whole crossing via the actual atomic radius capacity

## Result

For the ORIGINAL general fields U_y=1_E alpha P_(s,L)/q, arbitrary actual s and L,R in [a,b], fixed alpha, FIRST rho<=1_E, and the SAME actual cap nu(Q_R(u))<=4lambda R(u)^n, the entire first physical-radius crossing has the exact decomposition

    E_H=L^-_H+C_H-S_H,
    0<=L^-_H<=4lambda H beta(Y_H),                       (1)

where S_H is the ORIGINAL complete capture square at the crossing and C_H is actual hard-cube traffic carried only by effective physical-radius atoms. No soft/scale pointwise envelope is used.

Let T be the countable effective atomic radius set of rho(u)du, and let pi(u) be the actual crossing-atom source occupancy defined below. Then

    C_H=integral pi(u) h_(R(u))*nu(u)du,
    0<=pi<=rho<=1,
    C_H<=K(T,eta) W_nu,                                 (2)

where eta_t=esssup_(E intersection {R=t}) pi and

    K(T,eta)=integral sup_(t in T) eta_t h_t(x)dx.        (3)

For finitely many sorted atoms t_1<...<t_k this is the explicit number

    K(T,eta)=sum_(i=1)^k (t_i^n-t_(i-1)^n)
                              max_(j>=i) eta_(t_j)/t_j^n,
    t_0=0.                                             (4)

In particular

    K(T,1)=1+sum_(i=1)^(k-1)[1-(t_i/t_(i+1))^n]
            <=min{k,1+nlog(b/a)}.                       (5)

For empty T, K=0. For countable T, (3) equals the supremum of (4) over finite subsets, with the same weights, and K<=A_n=1+nlog(b/a).

Thus all general soft/varying-L/R inputs whose effective radius distribution is atomless have a whole-crossing receipt 4lambda H W_beta. More generally a radius spectrum with K(T,eta)<=C sqrt(n)polylog(n+2) gives the whole-crossing source fee

    4lambda H W_beta+C sqrt(n)polylog(n+2)W_nu.          (6)

These are genuine general-kernel statements; they impose no source density cap, source order, high-softness assumption, or L=R identity. They do NOT establish a dimension-only root bound for arbitrary dense atomic spectra. The actual post-crossing innovation remains unpaid as well.

## 1. Original clocks and whole-square crossing

Keep all original fields, q in [3lambda/4,lambda], source measures beta,nu, and actual dx integration. The proof needs only nonnegativity, finite original rows and masses, FIRST, and the stated actual-radius nu cap. Define

    J_y(r)=integral_(R(u)<=r) U_y(u)du,
    A_yz(r)=integral_(R(u)<=r) U_y(u)c_u(z)du,
    c_u(z)=1_(Q_(R(u))(u))(z),
    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    ell_n([R,b])=R^(-n).

Let H>0 be the ACTUAL threshold already chosen by the entrance. Set

    F_y(r)=integral [A_yz(r)-A_yz(r)^2/J_y(r)]nu(dz),
    Y_H={y:J_y(b)>=H},
    tau_y=inf{r in [a,b]:J_y(r)>=H}  for y in Y_H.

At zero J use F=0. Inclusive CDF conventions give J_y(tau_y)>=H and J_y(tau_y-)<=H. Crossings, left limits and the diagonal event tau_y=R(u) are measurable. No original atom is split or fractionally ordered.

The nonnegative Stieltjes variance innovation identity is kernel-independent: adding a mass h with captured fraction v_z to old mass j with captured fraction p_z changes F by

    integral [h v_z(1-v_z)+jh/(j+h)(v_z-p_z)^2]nu(dz).

Thus F is increasing. The R327 Stieltjes settlement continues to hold for the GENERAL U:

    B_H=E_H+I_H,
    E_H=integral_(Y_H) tau_y^(-n)F_y(tau_y)beta(dy),
    I_H=integral_(Y_H) beta(dy)
                  integral_(tau_y,b] r^(-n)dF_y(r).      (7)

The crossing atom is wholly in E_H. I_H contains only innovations STRICTLY after tau_y, including a terminal physical atom if it is later than the crossing. If tau_y=b, there is no later term. The terminal ell_n atom and physical R atoms remain distinct and are both retained. This algebra is reused, not claimed as a new innovation identity.

## 2. Exact original square and the old-prefix payment

Write A_yz^-=A_yz(tau_y-) and Delta A_yz=A_yz(tau_y)-A_yz^-. Define

    L^-_H=integral_(Y_H) beta(dy) tau_y^(-n)
                                      integral A_yz^- nu(dz),
    C_H=integral_(Y_H) beta(dy) tau_y^(-n)
                                      integral Delta A_yz nu(dz),
    S_H=integral_(Y_H) beta(dy) tau_y^(-n)
                        integral A_yz(tau_y)^2/J_y(tau_y)nu(dz).

These definitions give (1) exactly. In particular S_H uses the WHOLE old-plus-atom capture numerator and the SAME full J_y(tau_y). It is not a within-atom surrogate square.

For each crossing row, Tonelli and the actual cap give

    tau_y^(-n) integral A_yz^- nu(dz)
      =integral_(R(u)<tau_y) U_y(u)
                    nu(Q_(R(u))(u))/tau_y^n du
      <=4lambda integral_(R(u)<tau_y)U_y(u)(R(u)/tau_y)^n du
      <=4lambda J_y(tau_y-)<=4lambda H.                 (8)

This proves the payment in (1). The source mass beta(Y_H) is charged once and may be bounded by W_beta. No beta or nu density bound was used. General softness and arbitrary L/R do not affect (8).

## 3. Actual crossing occupancy and the effective atomic set

Define, using the original source and crossing selector,

    pi(u)=integral_(Y_H)1_(tau_y=R(u))U_y(u)beta(dy).

Then 0<=pi<=rho<=1_E, and positive Tonelli gives exactly

    C_H=integral_E pi(u) R(u)^(-n)nu(Q_(R(u))(u))du.     (9)

This is a source-integrated atom receipt, not an estimate of sup_y Delta J_y(t). It does not introduce a virtual receiver, change q, or substitute a new source in A,J or the square.

Define the effective radius measure and its atoms by

    m(B)=integral_(R(u) in B)rho(u)du,
    T={t in [a,b]:m({t})>0}.                            (10)

Assume the useful original finite-occupancy regime X_rho=lambda integral rho<infinity. Then m is finite and T is countable. The same countability follows locally in the sigma-finite case, but the finite regime is sufficient here.

For completeness, pi vanishes almost everywhere outside R^(-1)(T), despite the row-dependent crossing time. The set T_dx={t:|E intersection {R=t}|>0} is countable because Lebesgue measure is sigma-finite. Outside T_dx every original row has Delta J_y(t)=0, since its receiver measure has a Lebesgue density. For each t in T_dx\T, Tonelli gives integral Delta J_y(t)beta(dy)=m({t})=0. Countability allows removal of one beta-null set of rows so that all such jumps vanish simultaneously. Hence, for beta-almost every row, a nonzero jump can occur only at a t in T. Applying Tonelli to pi on R^(-1)([a,b]\T) proves the claimed almost-everywhere support.

Thus if T is empty, C_H=0 exactly. Continuous crossings satisfy J_y(tau_y)=H and have no atom bill; their entire prefix and full square are still present in E_H. No limiting perturbation of the old radius selector is involved.

## 4. Exact radius capacity and the general-soft receipt

For t in T let eta_t be the essential supremum of pi on E intersection {R=t}. It lies in [0,1]. For almost every u and each fixed source z,

    pi(u) h_(R(u))(u-z)
                  <=sup_(t in T) eta_t h_t(u-z).

Integrating first in u and then in the ACTUAL nu proves (2). Translation invariance is used only to evaluate the total mass of this explicit reference envelope; neither E nor the original receiver selector is translated.

For a finite sorted spectrum, put d=2||x||_infinity. On t_(i-1)<d<=t_i, the envelope in (3) equals max_(j>=i) eta_(t_j)/t_j^n. That shell has volume t_i^n-t_(i-1)^n. This proves (4). When all weights equal one the suffix maximum is t_i^(-n), giving (5). The bound by k is immediate, and

    1-(t_i/t_(i+1))^n <= n log(t_(i+1)/t_i)

telescopes to the logarithmic bound. Countable spectra follow by monotone convergence along finite exhaustions. Useful further bounds, with no hidden source copies, are

    K(T,eta)<=sum_(t in T)eta_t,
    K(T,eta)<=[sup_t eta_t]A_n,
    C_H<=min{K(T,eta)W_nu,4lambda integral pi}.          (11)

The sum is permitted to be infinite; the A_n bound is always finite. Every source is integrated once against one envelope. Unlike a separate W_nu fee for every physical atom, (4) includes overlaps of the centered radial envelopes exactly.

Combining (1),(7),(9), the full original target has the sharpened ledger

    B_H<=4lambda H beta(Y_H)+K(T,eta)W_nu-S_H+I_H.       (12)

The ORIGINAL full crossing square is visible in (12), while I_H retains the true later within-atom and running-mean variance innovations. No second independent copy of S_H is added or spent. Dropping -S_H gives the simpler receipt (6) plus I_H. Keeping the signed atomic term C_H-S_H is appropriate if a later proof estimates that term directly.

For the old target factor 2 and recovery Lambda=128/119, the replaced B_H slot is bounded by

    8Lambda lambda H L_out[beta(Y_H)]
      +2Lambda L_out[K(T,eta)W_nu]
      -2Lambda L_out[S_H]+2Lambda L_out[I_H].            (13)

With variable outer data keep these exact source-weighted sums. The original H, lambda d, aspect and all source-conservation/recovery factors remain. A root-scale choice of H cannot be inserted freely into an already frozen entrance. No receiver absorption reserve is consumed by the pure source version of (12).

## 5. Exact unpaid complement and limits

The theorem removes the naive multiplication of a full softness envelope by a full scale envelope from the crossing bill. It handles arbitrary actual softness and arbitrary mismatch between L and R through FIRST and actual capture. Its improvement is explicit: atomless radii have zero atom fee; a finite or clustered atomic spectrum pays its capacity (4), at most its atom count; weighted crossing occupancy can reduce that capacity further.

For a dense unit-weight atomic spectrum over an octave, K approaches A_n=1+nlog(b/a), of order n. The current hypotheses do not prove a root bound on K(T,eta), nor do they prove that S_H cancels its excess. The precise remaining signed crossing term is C_H-S_H, with C_H defined by actual crossing-source traffic (9), not a pointwise soft envelope. I_H also remains unpriced in general. These are two distinct unresolved pieces; paying a favorable atomic spectrum does not settle the later innovation.

A claim that fixed alpha or shared q automatically makes eta_t small is not justified. Nor can source mass be bounded by the Lebesgue volume of a boundary set. No source order nu<=beta<=f is used in this theorem; if a future estimate uses it, the same-slot identification must be verified. The result is a genuine all-general-field crossing bound and covers broad general-soft branches, but is not the requested dimension-only root closure for every original field.

## 6. Executed exact algebraic diagnostics

The following standard-library Fraction script was actually run. It passed 96 exact weighted-spectrum checks (dimensions 1 through 12 and 1 through 8 radii), and 600 exact whole-crossing square checks. These validate the capacity arithmetic and the old-plus-atom square bookkeeping. They are algebraic diagnostics, not numerical evidence for an unproved dense-spectrum root estimate or a native history realization.

```python
from fractions import Fraction as F
from random import Random
rng=Random(328); envelope=0; crossing=0
for n in range(1,13):
    for K in range(1,9):
        ts=[F(1)+F(i,K) for i in range(K)]
        eta=[F(rng.randrange(0,9),8) for t in ts]
        exact=sum((ts[i]**n-(ts[i-1]**n if i else 0))*
                  max(eta[j]/ts[j]**n for j in range(i,K))
                  for i in range(K))
        unweighted=F(1)+sum(1-(ts[i-1]/ts[i])**n
                            for i in range(1,K))
        assert 0<=exact<=unweighted<=K
        assert exact<=sum(eta)
        envelope+=1
for _ in range(600):
    old=F(rng.randrange(0,9),4)
    atom=F(rng.randrange(1,13),4)
    H=old+atom*F(rng.randrange(1,5),4)
    p=F(rng.randrange(0,9),8); v=F(rng.randrange(0,9),8)
    Aold=old*p; Aatom=atom*v; J=old+atom; A=Aold+Aatom
    square=A*A/J; Ffull=A-square
    assert Ffull==Aold+Aatom-square
    assert Ffull<=H+Aatom-square
    crossing+=1
print('weighted-spectrum checks',envelope,
      'whole-crossing square checks',crossing)
```

Only /tmp/r328_core.md is authored. Work stops at this bounded result.
