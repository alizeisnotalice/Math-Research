# R439 bounded geometry checkpoint: common-grid extraction and the unresolved boundary charge

**Outcome:** no new payment of the original middle joint traffic. The fixed-box estimate can be used by a legitimate common random partition, but the original low-common gate has not yielded the additional collision or boundary-charge estimate needed to recover the unweighted traffic. The R433 mother ledger stays unchanged.

## 1. A legal common selection, with its entire cost

Keep the original actual field, full μ=fdy, parent posterior π_A, and all original flow labels. For fixed A put

\[
 R_*=(m_A/(qK))^{1/n},\qquad
 H_A=\{Z_A>(4-\varepsilon_0)h\},\qquad
 c_0=\frac{\varepsilon_0}{(4-\varepsilon_0)sK}.
\]

The archived capacity says that every axis box of side lengths ℓ_i satisfies

\[
 \pi_A(H_A\cap B)\le c_0\prod_i(1+\ell_i/R_*). \tag{1}
\]

Choose positive widths ℓ_i before drawing y,z and use **one common lattice**, shifted uniformly in its fundamental box. Its cells C form a countable partition. For every realized shift, (1) gives

\[
 \sum_C\pi_A(H_A\cap C)\pi_A(C)
 \le c_0\prod_i(1+\ell_i/R_*).
\]

Averaging the shift is exact:

\[
 \int\pi_A(dy)\pi_A(dz)1_{H_A}(y)
 \prod_i\left(1-\frac{|y_i-z_i|}{\ell_i}\right)_+
 \le c_0\prod_i(1+\ell_i/R_*). \tag{2}
\]

The product is precisely the probability that both sources lie in the same cell. Source coordinates need not be independent. Widths may be measurable functions of the frozen parent/full field; they cannot be chosen after observing the current source pair without another selection argument.

Thus, if ℓ_i/R_* are fixed constants, the **original** flow projection bound Π433≤Sσπ_A² pays the left collision-weighted original traffic at most

\[
 S c_0\prod_i(1+\ell_i/R_*)X_q. \tag{3}
\]

This includes the selection cost and retains all original gates in the actual positive integral. It does not pay the original unweighted middle traffic. The independently developed Poisson-cell argument gives a smoother whole-distance kernel; (2) is not offered as a competing new payment.

## 2. What the actual low-common condition says about the cells

Let C be the realized cell containing y, and define its genuine small-receiver boundary occupation

\[
 \mathcal B_C(A,y)=
 \int_{m_u<m_A/K}\frac{c_u(y)}{m_u}
       1_{\overline C\not\subset Q_u}\,du. \tag{4}
\]

If z lies in the same cell, then every receiver containing y but excluding z is counted in (4). Consequently, on the original gates,

\[
 \mathcal B_C(A,y)\ge Z_A(y)-C_A(y,z)
 >(3-\varepsilon_0)h. \tag{5}
\]

This uses the actual receiver u and original sources; u receives no new history. Cell closure causes no issue: exclusion of z implies failure to contain the closure. With full L1 sources, grid boundaries also have zero source mass for almost every shift.

Equation (5) is a lower bound on witness occupation cutting the source cell. It does **not** imply a positive probability of source-pair collision. Nor has it yielded a smaller global price for the collision traffic. After exchanging source and receiver, the immediate matching estimate is only

\[
 \frac{\mu(Q_A\cap C\cap Q_u)}{m_u}\le1.
\]

This loses the joint parent/cell restrictions and returns receiver-center occupancy, with no established root-scale saving. Bounding the cutting region by its volume would instead require an unavailable source density bound.

The concrete missing step is a shared charge for these actual cutting receivers, retaining the parent posterior and the original same-cell/low-common labels, that either (a) recovers a definite fraction of the middle traffic with summably priced partitions, or (b) budgets its complement directly. Neither is proved. An arbitrary pair's bounding rectangle, though small in (1), does not provide such a charge: it can depend on both sampled sources and has no certified extraction probability.

## 3. Exact local verification; limited scope

Executed `/tmp/r439_geometry_check.py`; stdout is `/tmp/r439_geometry.result.txt`. Three stages use dimensions 1, 2, and 4, with 12 rational configurations each. The program partitions each shift interval at every exact floor-change location and verifies the collision product in (2). Twelve further rational assertions verify the stationary-width algebra for the capacity/collision ratio. Total: **48 exact Fraction assertions, all passed**.

For orientation only, even an oracle allowed to optimize a width for a known coordinate displacement δ_i=|y_i−z_i|/R_* has minimum ratio

\[
 \inf_{\ell_i>|y_i-z_i|}
 \frac{1+\ell_i/R_*}{1-|y_i-z_i|/\ell_i}
 =(\sqrt{1+\delta_i}+\sqrt{\delta_i})^2.
\]

For diffuse displacements δ_i=D/n the product equals exp(2n asinh√(D/n)), of order exp(2√(nD)) for fixed D. This is only a calculation of this comparison's cost; it is not a counterexample to the original target. No further bare-grid optimization was pursued after the independent Poisson calculation.

The tests establish grid geometry and algebra only. They do not certify original-history instances, (unproved) collision recovery, or a new general budget. This bounded attempt ends at the boundary-charge gap in §2.
