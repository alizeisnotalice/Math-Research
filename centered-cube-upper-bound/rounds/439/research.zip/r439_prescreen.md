# R439 独立预审（PRE；先于本轮作者证明）

已独立读取权威 rounds/413/research.zip 的 r413_main.md 第9、48行，以及 rounds/423/research.zip 的 r423_main.md 第9、15行。目录为 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound。两成员SHA256分别为 ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f、e52bfc72017e1531968661bf6319760a665c9fa2046c0d306b803786dd8b4caf。明确原新来源保Z_A(z)>(L−ε_0)h、L≥4，故与旧来源同可使用Z0=(4−ε_0)h。本审查未赋新来源或辅助父额外历史。

## 1. full-cell heavy价格：成立

固定半开网格，mesh δ_g=a/n²，M_C=μ(C)。对实际父A置R_*=(m_A/(q_-K))^(1/n)，H_A={Z_A>Z0}。非空H_A需R_*>a；R_*≤a时strict past为空。完整matching及真实相关中心包含给

 Z0 μ(C∩H_A)≤∫_C Z_A dμ≤(R_*+δ_g)^n
 ≤R_*^n exp(nδ_g/a)。

所以π_A(C∩H_A)≤exp(nδ_g/a)/(Kq_-Z0)。这是全来源格，不要求格内f均匀或密度有界。

heavy事件取M_C≥m_A/K，含等号。其父满足R_A≤R_C=(KM_C/q_-)^(1/n)。若Q_A与C有实际来源交集，则A属于C+Q_RC，相关中心体积≤(R_C+δ_g)^n≤KM_C exp(nδ_g/a)/q_-。非空时R_C≥a，故该步含等号亦合法；不把actual selector端点当中心零测集。M_C=0没有有效heavy父来源。

使用原全stage静态推前≤Sσπ_A²、原新z∈H_A、q_A≤λ，积分旧π_A至1，再对全格求和∑M_C=W，得到

 R_heavy,z≤ Sλ exp(2nδ_g/a) W/(q_-² Z0)
 =Sr ε_0 exp(2/n) W/[(4−ε_0)s]。

只有一次S，不另乘stage或两来源2；这是指定新z分支。countable网格求和全为非负Tonelli。原half-open cell与cube边界不产生质量重复，f为L1密度。

## 2. low-fill价格：成立，但须保原stage标签

原非降阈值的δg_i(z)=∫_(T_{i−1},T_i]1_{f(z)>t}dt。附加t只是将同一来源密度原子拆成正分量；原a_i^e、θ_i、history等仍冻结在i，不能用g_t重新生成Γ_i、π_A或m_A。原每端a_i^e≤B_e，合S；所有其他正限制可上放到1。

定义m_t(A)=∫QA min(f,t)，其绝对连续导数为m_t'(A)=∫QA1_{f>t}dz（a.e. t），m_0=0、m_∞=m_A。对τ>0，链式积分给

 ∫_0^∞m_t'(A)1_{m_t(A)<τm_A}dt=min(τ,1)m_A≤τm_A。

原阶段区间不重叠，有限/无限阶段可正Tonelli合并。因此在heavy补集上再付lowfill也不超过

 R_lowfill≤S∫σ(dA)/m_A ∫m_t'1_lowfill dt≤SτX_q。

严格填充等号层若有平台，其导数为0，不漏质量原子；τ∈(0,1)是后续熵解释的实用范围。使用的始终是实际full m_A，不把clipped m_t当新匹配场。

## 3. light+filled的熵下界不支付原加权费用

对z∈C∩QA，light为M_C<m_A/K，filled为m_t(A)≥τm_A。令m_C(t)=∫C min(f,t)，并取足够大的固定对称邻格使QA包含于其union（例如索引Chebyshev距离≤ceil(b/δ_g)+1）。邻格数≤(4n²+3)^n；N_C(t)为其clipped质量和。因此在有效来源点m_C(t)>0处

 log[N_C(t)/m_C(t)]>log(τK)=√n+logτ。

这不是原a-grid的5^n邻格，必须保细网格增加的O(nlog n)熵上界。τK≤1时该下界不强，不能一概称“高熵”；固定τ下可另分有限低n，原粗价足够给依τ常数，但大n主桥仍需证明。

原实际light-filled费用仍为Σ_i∫_(Ti−1,Ti]∫1_{f>t}L_i(z)1_light,filled dzdt，且L_i≤D_i(z)。可用未加权clipped格熵耗散不能免费消去D_i，也不能把原历史门转给g_t。即使记录了高熵下界，原whole预算尚未推出；需要对同一stage加权的source费用另证几何比较。

## 4. 实际小算术与状态

Python3/Fraction实际运行3个τ=1/4,1/2,3/4的单一clipping-profile模型：源密度值(1,3,7)、体积(1/2,1/3,1/5)、m_A=29/10；原阶段区间(0,1],(1,4],(4,8]固定，阶段系数≤S=3/2。精确核∫m_t'1_lowfill=τm_A及带原阶段系数的≤Sτm_A，全部通过。这只是clipping/阈值代数，非完整native/history样本。

两个独立正分支的候选分解合法：R433≤R_light,filled+SτX_q+[Sr ε_0e^(2/n)/((4−ε_0)s)]W，所有原标签仍在剩余中。未认证其整体关闭、原账新增或吸收。PRE保存后再读作者稿，等待最终审核请求。
