# R439互补：微格边界桥的严格重cell付款与连续低填充付款；D_i乘数仍未消去

不假定每源边界概率为nδ/a。取δ=a/n²的半开网格，shift可任意固定；下面的界对每个shift成立，因此无需随机shift来掩盖边界。保持原δg_i、a_i、θ_i、终端和历史，不造非嵌套receiver树。

## 1. 重full-cell的真实容量

令M_C=∫_C f，Z0=(4−ε_0)h=(4−ε_0)s/(ε_0q)。原新来源z确有Z_A(z)>(L−ε_0)h≥Z0、L≥4，准确归档出处见附件。

由R438的实际receiver容量，对任何原父和微cell，

π_A(C∩{Z_A>Z0})≤exp(nδ/a)/(KqZ0).                    (1)

若高rank非空则R_*=(m_A/(qK))^{1/n}>a，故(1)没有漏掉R_*<a情形。现在只看M_C≥m_A/K的原流。该条件迫m_A≤KM_C，真实父RA≤(KM_C/q)^{1/n}；凡Q_A捕获C内来源，A位于C加这个半边长cube内。因此其父中心总体积≤(KM_C/q)exp(nδ/a)。

对每cell先用(1)，再用σ≤λdA及原一次sourcewise帽S，最后Σ_CM_C=W，得到

Π433{M_{C(z)}≥m_A/K}
 ≤ S r exp(2/n)/(qZ0) W
 = S r ε_0 exp(2/n)/[(4−ε_0)s] W.                   (2)

n≥9时exp(2/n)<5/4，故≤(5Sr/28s)W。这使用完整f质量，未给source密度帽，未乘阶段数。

(2)正好避免边界陷阱：若微cell未完全落在严格小receiver内，不能断言其质量小；但其full质量若不小，已经由(2)支付。其余cell的full质量本来就<m_A/K，所以不论receiver是否切穿，都有m_C(t)=∫_C min(f,t)<m_A/K。无需猜测边界测度。原两源同cell时切穿rank可很大，亦不与此论证冲突。

## 2. 低current填充可连续付εX

精确展开δg_i(z)=∫_{T_{i−1}}^{T_i}1_{f(z)>t}dt，只提升一个level标签，不改原stage系数或θ。记m_t(A)=∫_{Q_A}min(f,t)。给定0<τ<1，将m_t(A)<τm_A的贡献上放原stage系数到S；level区间逐源不重叠，且m_t绝对连续，故

贡献≤S∫σ(dA)/m_A ∫_0^∞m_t'(A)1_{m_t(A)<τm_A}dt
    ≤SτX_q.                                         (3)

这里保留连续t到积分完成，不能在跨越τm_A的整个stage上付同价，以免overshoot。选τ=ε/S（必要时缩至<1）才给εX；正式入口余额仍由主代理核验。

## 3. 原current entropy与准确失败点

取微格邻域index半径M=2n²+1，N_C(t)为这些邻格m_D(t)之和。其union包含每个捕获z∈C的实际Q_A。令ell_C=log(N_C/m_C)、φ(u)=u−1+e^{−u}。与原熵相同的直接微分为

E_δ'=Σm_C'(ell_C−1)+Σ_C(m_C/N_C)N_C'
     ≥Σm_C'φ(ell_C),
0≤E_δ≤nlog(4n²+3)W_t.

第二项保留self邻格即得下界。零格和无限和可直接处理：记邻格数d_grid=(4n²+3)^n。t>0时m_C(t)>0当且仅当M_C>0；零格m_C及其导数恒零，熵项定义为零。对几乎每个t有m_C′≤m_C/t及N_C′≤N_C/t，所以在任意[ε,T]上，Σ_C|∂_t[m_C log(N_C/m_C)]|≤W(log d_grid+2)/ε。故无限和局部绝对连续，求导/积分交换合法。再用Eδ(t)≤log d_grid·W_t及t↓0时W_t→0、T↑∞时W_t≤W，得到全部level的耗散界，无额外终端收费。定义原stage level平均η_i^δ，故严格

Σ_i∫δg_i η_i^δ≤nlog(4n²+3)W.                        (4)

在未被(2)(3)覆盖的贡献上，m_C(t)<m_A/K且N_C(t)≥m_t(A)≥τm_A，所以ell_C(t)≥√n+logτ。若√n≥4(1+|logτ|)，则φ≥s/4。

关键是原父积分仍有receiver multiplicity：由原load定义、θ≤1，只能推出

R433≤SτX_q+(5Sr/28s)W
       +(4/s)Σ_i∫δg_i(z)D_i(z)η_i^δ(z)dz.           (5)

这里所有原stage系数均保留到正上放；没有将η当作私有父函数。较低有限维可用R433≤SX_q≤SrA_nW支付C_τsW。

(5)是一个真实全分解，但不是目标付款。已有(4)不带D_i；用D_i≤SA_n只给O(S n^{3/2}log n)W。即使填充已连续解决、切穿重cell已支付，单靠φ≥s/4仍只能把load变为D_iη_i^δ/s，而非η_i^δ/s。若D_i为n量级，不能从一个s量级的局部熵门免费删除该因子。当前缺少的单一实质桥是原历史/占用与current熵的**加权multiplicity比较**；本文没有证明它，也不把(5)中的未付项换名当闭合。

## 4. 证据与状态

`/tmp/r439_complement_check.py`已实际运行：Fraction核8组纯参数常数、邻域degree及φ门；正Taylor尾严格核exp(2/9)<5/4、atanh正级数核log2<7/10。输出`/tmp/r439_complement_check.result.json`。没有特殊几何模型或反例扫描；一般估计由正文证明。

新增严格成果是(2)、(3)及保原level的(5)。主余项仍受D_i乘数阻挡，母账、全尺度及最终吸收不变。交付后停止。
