from fractions import Fraction as F
import json

def exp_interval(x,N=24):
 term=F(1); total=term
 for k in range(1,N+1):
  term*=x/k;total+=term
 first=term*x/(N+1)
 tail=first/(1-x/(N+2))
 return total,total+tail
x=F(1,3); N=8
log2lo=2*sum((x**(2*k+1)/(2*k+1) for k in range(N)),F(0))
log2hi=log2lo+2*x**(2*N+1)/((2*N+1)*(1-x*x))
assert log2hi<F(7,10)
elo,ehi=exp_interval(F(2,9))
assert ehi<F(5,4)
rows=[]
for n,ell in [(9,3),(16,4),(64,8),(256,16)]:
 s=1+ell
 M=2*n*n+1
 assert 2*M+1==4*n*n+3
 assert F(ell)-log2hi-1>=F(s,4)
 for ep in [F(1,2),F(1,8)]:
  assert ep/(4-ep)<=F(1,7)
  # q*Z0=(4-ep)*s/ep, hence lambda/(q^2 Z0)=r*ep/((4-ep)*s).
  coefficient=ep/((4-ep)*s)
  assert F(5,4)*coefficient<=F(5,28*s)
  rows.append({'n':n,'eps0':str(ep),'neighbor_radius':M,
   'entropy_log_degree_base':2*M+1,'heavy_cell_prefactor_without_Sr_exp':str(coefficient),
   'phi_lower_over_s':str((F(ell)-log2hi-1)/s)})
print(json.dumps({'rows':rows,'log2_upper':str(log2hi),'exp_2_over_9_upper':str(ehi),
 'scope':'Exact Fraction scalar normalization and entropy constants only. No geometry/history models or scan; the general capacity estimate is proved analytically.'},indent=2))
