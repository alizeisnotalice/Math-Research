"""Six exact clipped-layer parent checks; no geometry/history certification.
Run python3 r439_numeric.py; certificate is written next to this script.
"""
from fractions import Fraction as F
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
S=F(7,3)
cases=[
 ('two_levels',[F(1),F(3)],[F(1,2),F(1,2)],F(1,4),[F(0),F(1,3),F(2,3),F(2),F(4)]),
 ('three_levels',[F(1,2),F(2),F(5)],[F(1,4),F(1,2),F(1,4)],F(1,2),list(map(F,[0,1]))+[F(3,2),F(3),F(5)]),
 ('rational_levels',[F(2,3),F(7,4),F(9,2)],[F(1,3),F(1,6),F(1,2)],F(2,5),[F(0),F(1,2),F(1),F(3,2),F(3),F(5)]),
 ('repeated_levels',[F(1),F(1),F(10)],[F(1,4),F(1,4),F(1,2)],F(3,4),list(map(F,[0,2,7,8,10]))),
 ('concentrated_levels',[F(1,100),F(1),F(100)],[F(1,2),F(49,100),F(1,100)],F(1,10),[F(0),F(1,50),F(1,5),F(1,2),F(2),F(100)]),
 ('uniform_near_full',[F(7,3)],[F(1)],F(99,100),[F(0),F(1),F(2),F(7,3)])]

def clipped_mass(levels,vol,t):return sum((v*min(f,t) for f,v in zip(levels,vol)),F(0))

def low_integral(levels,vol,target,a,b):
    # Exact open linear segments: no floating mask at left stage time.
    knots=sorted({a,b}|{f for f in levels if a<f<b})
    source_integrals=[F(0)]*len(levels);thresholds=[]
    for l,r in zip(knots,knots[1:]):
        active=[f>l for f in levels] # exact and constant on the open segment
        slope=sum((v for v,on in zip(vol,active) if on),F(0))
        ml=clipped_mass(levels,vol,l)
        if not slope or ml>=target:continue
        length=min(r-l,(target-ml)/slope)
        assert length>=0
        if 0<length<r-l:thresholds.append(l+length)
        for k,on in enumerate(active):
            if on:source_integrals[k]+=vol[k]*length
    return source_integrals,thresholds

reports=[]
for label,levels,vol,tau,stages in cases:
    assert all(f>0 for f in levels) and all(v>0 for v in vol) and sum(vol,F(0))==1
    assert stages[0]==0 and stages[-1]>=max(levels) and all(a<b for a,b in zip(stages,stages[1:]))
    mA=sum((v*f for v,f in zip(vol,levels)),F(0));target=tau*mA
    total=weighted=naive=F(0);rows=[];cross=[]
    for i,(a,b) in enumerate(zip(stages,stages[1:])):
        layers=[v*(min(f,b)-min(f,a)) for f,v in zip(levels,vol)]
        assert sum(layers,F(0))==clipped_mass(levels,vol,b)-clipped_mass(levels,vol,a)
        accepted,threshold=low_integral(levels,vol,target,a,b)
        coeff=[S*F((i+k)%4+1,4) for k in range(len(levels))]
        assert all(F(0)<=x<=S for x in coeff)
        weighted_i=sum((cc*x for cc,x in zip(coeff,accepted)),F(0))
        accepted_i=sum(accepted,F(0));total+=accepted_i;weighted+=weighted_i
        naive_i=sum(layers,F(0)) if clipped_mass(levels,vol,a)<target else F(0)
        naive+=naive_i;cross+=threshold
        assert all(F(0)<=x<=y for x,y in zip(accepted,layers))
        rows.append({'stage':[str(a),str(b)],'full_layer_mass':str(sum(layers,F(0))),
          'exact_lowfill_layer_mass':str(accepted_i),'source_layer_masses':list(map(str,layers)),
          'source_lowfill_integrals':list(map(str,accepted)),
          'unchanged_stage_source_coefficients':list(map(str,coeff)),
          'weighted_lowfill_integral':str(weighted_i),'threshold_inside_stage':list(map(str,threshold))})
    assert total==target and weighted<=S*target and naive>=total
    assert cross # each prescribed case really has an interior crossing
    reports.append({'label':label,'density_levels':list(map(str,levels)),
      'interval_volumes':list(map(str,vol)),'tau':str(tau),'mA':str(mA),
      'exact_lowfill_integral':str(total),'tau_mA':str(target),
      'weighted_lowfill_integral':str(weighted),'S_tau_mA':str(S*target),
      'naive_left_stage_mask_integral':str(naive),'naive_overcount':str(naive-total),
      'stages':rows})
    print(label,'mA=',mA,'exact integral=',total,'tau*mA=',target,
          'weighted=',weighted,'<=',S*target,'left-mask overcount=',naive-total,
          'crossing=',','.join(map(str,cross)))
(ROOT/'r439_numeric_certificate.json').write_text(json.dumps({'S':str(S),'cases':reports,
 'scope':'Six exact positive L1 piecewise-constant parents; finite algebra checks only, no original geometry/history certification.'},indent=2)+'\n')
print('PASS: six exact layer expansions, continuous lowfill integrals, unchanged coefficient bounds; no left-stage masks used for acceptance.')
