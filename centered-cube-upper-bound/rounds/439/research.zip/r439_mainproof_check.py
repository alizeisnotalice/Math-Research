from fractions import Fraction as F
from decimal import Decimal as D, localcontext

cnt=0
for rate in [F(1,2),F(1),F(2)]:
 for gap in [F(0),F(1,2),F(2)]:
    # Divide the Gamma(2)-mixed collision integral by exp(-rate*gap).
    coeff=rate**2*((gap/rate+1/rate**2)-gap/rate)
    assert coeff==1
    assert rate**2*(F(2)/rate**3)==2/rate
    cnt+=1
print(f'PASS {cnt} exact Gamma-mixing/mean identities (Fraction).')
with localcontext() as ctx:
 ctx.prec=70
 for n0 in [9,64,1024]:
    n=D(n0)
    for label,dist in [('small',D(1)/32),('unit',D(1)),('logn',n.ln())]:
        x=(1+2*n/dist).sqrt()-1
        cost=x*dist+n*(1+2/x).ln()
        low=2*(2*n*dist).sqrt()-2*dist
        high=2*(2*n*dist).sqrt()
        assert abs(dist-2*n/(x*(x+2)))<D('1e-60')
        assert low<=cost<=high
        print(f'n={n0} D={label}: x={x:.12g}, exponent/sqrt(n)={cost/n.sqrt():.12g}, exponent-logK={cost-n.sqrt():.12g}')
print('PASS 9 70-digit parameter diagnostics (3/3/3); analytic inequalities, not decimal output, justify bounds.')
print('No actual history simulation and no unweighted remainder estimate claimed.')
