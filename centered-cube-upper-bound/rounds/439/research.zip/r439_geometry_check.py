from fractions import Fraction as F
from itertools import product

def floor(x): return x.numerator//x.denominator

def collision(y,z,l):
    cuts={F(0),l}
    for x in (y,z):
        r=x-floor(x/l)*l
        cuts.add(r)
    cuts=sorted(cuts)
    total=F(0)
    for a,b in zip(cuts,cuts[1:]):
        u=(a+b)/2
        if floor((y-u)/l)==floor((z-u)/l): total+=b-a
    return total/l

count=0
for n in (1,2,4):
    stage=0
    for seed in range(12):
        p=F(1); expected=F(1)
        for j in range(n):
            y=F((seed+2*j)%9-4,5)
            z=y+F((3*seed+j)%11,10)
            l=F(3+(seed+j)%7,5)
            p*=collision(y,z,l)
            expected*=max(F(0),1-abs(y-z)/l)
        assert p==expected
        count+=1; stage+=1
    print('dimension',n,':',stage,'exact offset-partition checks PASS')
# Stationary-width identity with rational square root: delta=t^2/(1+2t).
# Then l/R=t, and delta+sqrt(delta^2+delta)=t.
for t in [F(1,8),F(1,4),F(1,2),F(1),F(2),F(4)]:
    d=t*t/(1+2*t)
    assert t*t-2*d*t-d==0
    ratio=(1+t)/(1-d/t)
    assert ratio==1+2*d+2*(t-d)
    count+=2
print('PASS',count,'total exact geometric/algebraic assertions')
print('Scope: random-grid offset geometry and stationary-width algebra only; no actual-history flow or missing collision lower bound is certified.')
