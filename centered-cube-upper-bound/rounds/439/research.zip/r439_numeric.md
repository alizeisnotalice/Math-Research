# R439 六个实际连续层积分有限核验

已实际执行`python3 r439_numeric.py`，纯stdlib Fraction，输出`r439_numeric_certificate.json`、`r439_numeric_run.txt`。所有文件在脚本同目录。未做LP、几何采样或重型计算，未验证原history。

每个parent取Q=[−1/2,1/2]，依给定正有理长度分割为相邻区间，各段f为正有理常数，Q外f=0。因此是实际正L1密度和正体积parent；不是离散原子替代。定义m_t=∫_Q min(f,t)，m_A=∫_Qf。

脚本对每个stage [T_{i−1},T_i]先以f的真实level再分段。在每个开段m_t线性，精确解与τm_A的相交时刻，积出

`∫stage m_t' 1{m_t<τm_A}dt`。

逐source段同时验证δg_i=min(f,T_i)−min(f,T_{i−1})的连续层积分。未使用浮点或stage左端mask代替连续资格。每例都包含一个落在stage内部的阈值交点。

|例|m_A|τ|阈值交点t|精确lowfill积分=τm_A|若错用stage左mask的额外量|
|--|--|--|--|--|--|
|two levels|2|1/4|1/2|1/2|1/6|
|three levels|19/8|1/2|17/12|19/16|1/16|
|rational levels|199/72|2/5|53/40|199/180|7/60|
|repeated levels|11/2|3/4|29/4|33/8|3/8|
|concentrated levels|299/200|1/10|289/1000|299/2000|211/2000|
|uniform near full|7/3|99/100|231/100|231/100|7/300|

六例中stage覆盖从0到最大f，故积分都恰为τm_A；截断stage范围时只需≤。额外令S=7/3，为每个stage/source段固定有理系数a_ik∈[0,S]，保持其stage归属不变，逐段验证加权原层积分≤Sτm_A。全部确切源层质量、系数和积分存于JSON，未以新stage或重取系数替换。

代数原因是m_t绝对连续、非降，且m'_t=∫_Q1{f>t}；在m_t<τm_A的区间只累计至τm_A。这支持主代理的层展开及固定parent低fill费用计算。六个有限例不认证原stage历史、中心场sigma积分或sourcewise cap本身；若原系数确有≤S且保持不变，才可由该层代数回到SτX。未额外做microgrid entropy实验，避免扩大本轮任务。
