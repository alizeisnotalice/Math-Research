from fractions import Fraction as F
from itertools import product

# Exact cube volumes for full f=1 on [-2,2]^n.
# Qu=[-1,1]^n; Qv has side 1 and center (d,0,...,0).
# Both matched q-values are 1. These are pair diagnostics, not historical core flows.
cases=0
for n,d,b0,bu,bv in product((4,9,16,25),(F(0),F(1,2),F(3,4),F(1)),(F(1,3),F(1)),(F(1,2),),(F(3,4),)):
    mu=F(2)**n; mv=F(1)
    I=min(F(1),F(3,2)-d)
    assert 0<I<=mv<mu
    # log 2 > 1/2 and n/2 >= sqrt(n) certify mu/mv > exp(sqrt(n)).
    assert F(n,2)**2>=n
    common=I/mu
    tv=(I*(1/mv-1/mu)+(mu-I)/mu+(mv-I)/mv)/2
    assert common+tv==1
    assert common<=mv/mu
    # Same b on each disjoint source region: exact maximal common marked submeasure.
    U=b0*I/mu+bu*(mu-I)/mu
    V=b0*I/mv+bv*(mv-I)/mv
    common_b=b0*I/mu
    assert common_b<=mv/mu*V
    assert U+V == 2*common_b+(U-common_b)+(V-common_b)
    assert U-common_b>=0 and V-common_b>=0
    # Endpoint-specific positive retained marks cannot enlarge the common submeasure.
    ou,ov=F(1,4),F(3,5)
    joint_common=I*b0*min(ou/mu,ov/mv)
    assert joint_common<=common_b
    cases+=1
print(f'PASS: {cases} exact full-f matched cube-pair and marked-packet records')
print('Scope: real cube volumes, q=1 matching and strict far mass certificate; no continuous receiver flow, original rank/clock/history or R414 occurrence-layer realization.')
