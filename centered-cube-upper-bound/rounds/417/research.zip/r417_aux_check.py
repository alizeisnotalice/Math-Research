from fractions import Fraction as F
from itertools import product
from math import isqrt

def root(x):
    a,b=isqrt(x.numerator),isqrt(x.denominator)
    assert a*a==x.numerator and b*b==x.denominator
    return F(a,b)
def clip(f,t): return min(f,t)
def phi(d,s): return 2*max(F(0),root(d)-root(s))
def potential(f,t,d,s):
    return 2*f*root(min(d,s))+clip(f,t)*phi(d,s)
counts={'scalar_atoms':0,'finite_switches':0,'two_endpoint':0}
for f,t0,t1,d0,d1,s in product([F(0),F(1),F(4)],[F(0),F(1,4)],[F(1),F(8)],[F(1),F(4),F(9)],[F(0),F(1,4),F(1)],[F(1,4),F(1)]):
    dv=clip(f,t1)-clip(f,t0)
    cross=dv*(phi(d0,s)-phi(d1,s))
    assert cross>=0
    switch_old=dv*phi(d0,s); switch_new=dv*phi(d1,s)
    assert switch_old==switch_new+cross
    linear=dv*max(F(0),d0-s)
    assert linear==(root(d0)+root(s))*switch_old/2
    defect=f if d0<=s else clip(f,t1)
    weighted=defect*(d0-d1)/root(d0)
    assert weighted<=potential(f,t1,d0,s)-potential(f,t1,d1,s)
    counts['scalar_atoms']+=1
for f,ds,ts in product([F(0),F(1),F(10)],[[F(9),F(4),F(1),F(0)],[F(4),F(4),F(1,4),F(1,4)]],[[F(0),F(1,8),F(1),F(20)],[F(1,4),F(1,4),F(8),F(16)]]):
    s=F(1); v=[clip(f,t) for t in ts]; ps=[phi(d,s) for d in ds]
    lhs=sum((v[i]-v[i-1])*ps[i] for i in range(1,4))
    rhs=v[-1]*ps[-1]-v[0]*ps[0]+sum(v[i]*(ps[i]-ps[i+1]) for i in range(3))
    assert lhs==rhs and lhs<=(v[-1]-v[0])*ps[0]
    counts['finite_switches']+=1
# Exact two-endpoint diagnostic: one directed edge cost 4, both endpoint
# posteriors (1/2,1/2), source cell masses/densities (1,4), unit volumes.
# D=(4,1), full f frozen. Increasing T below 2/5 preserves the edge;
# T>=2/5 removes both endpoints for theta=1/4, equality deletes.
for t in [F(0),F(1,8),F(1,4),F(2,5),F(1),F(4),F(8)]:
    f=[F(1),F(4)]; ds=[F(4),F(1)]; s=F(1,4); G=F(4); theta=F(1,4)
    defect=[clip(x,t)/x for x in f]
    weak=sum(defect)/2>=theta
    new=[F(0),F(0)] if weak else ds
    removed=G if weak else F(0)
    exact=sum(f[j]*defect[j]*(ds[j]-new[j])/root(ds[j]) for j in range(2))
    endpoint=removed*sum(defect[j]/root(ds[j]) for j in range(2))
    assert exact==endpoint # sum of BOTH endpoint expectations
    assert exact>=theta*removed/root(max(ds))
    drop=sum(potential(f[j],t,ds[j],s)-potential(f[j],t,new[j],s) for j in range(2))
    assert exact<=drop
    counts['two_endpoint']+=1
counts['signed_joint']=0
signs={'positive':0,'negative':0,'zero':0}
for f,tnew,x,y,s in product([F(1),F(4)],[F(1),F(8)],[F(1),F(9,4),F(4)],[F(0),F(1,4),F(1)],[F(1,4),F(1)]):
    tprev=F(1,4); start=F(9)
    def e(t,d): return max(F(0),1-t/f) if d>s else F(0)
    dv=clip(f,tnew)-clip(f,tprev)
    old=1-e(tprev,start); restore=e(tprev,start)-e(tprev,x)
    assert restore>=0
    cut=(dv/f if x>s else F(0))
    assert 1-e(tnew,x)==old+restore+cut
    scale=f*(x-y)/root(x)
    enew=(1-e(tnew,x))*scale
    eold=old*scale; erestore=restore*scale
    joint=dv*((x-y)/root(x)*(x>s)-(phi(x,s)-phi(y,s)))
    switch=dv*phi(x,s); post=dv*phi(y,s)
    assert enew-switch==eold+erestore+joint-post
    signs['positive' if joint>0 else 'negative' if joint<0 else 'zero']+=1
    counts['signed_joint']+=1
print('PASS',counts,'total',sum(counts.values()),'mixed sign',signs)
print('Fraction algebra with rational square roots; finite posterior edge diagnostic only, no native cube/history certification.')
