% R417 diagnostic: full L1 smoothed lattice input via an interior lower-average formula.
% Additional partially captured cells are omitted: computed q is a LOWER bound.
% Numerical probabilities only; not original Gamma/history or upper bound.
rng(4172026,'twister');
ns=[64 256 1024 4096]; ks=2.^(1:7); ts=(1:19)/20;
alphas=2.^((-4:20)/4); B=4096; chunk=256;
eta=0.01; rad=sqrt(log(2*numel(ns)*numel(alphas)/eta)/(2*B));
fprintf('MATLAB %s seed4172026 sample%d simultaneousHoeffdingRadius %.9g\n',version,B,rad);
for n=ns
 delta=1/(100*n); best=zeros(B,1)-Inf;
 for start=1:chunk:B
  U=rand(chunk,n); counts=zeros(chunk,numel(ts));
  for ti=1:numel(ts), counts(:,ti)=sum(U<=ts(ti),2); end
  v=zeros(chunk,1)-Inf;
  for k=ks
   vals=counts*log1p(1/k)-n*log1p((ts+delta)/k);
   v=max(v,max(vals,[],2));
  end
  best(start:start+chunk-1)=v;
 end
 % Truncate sources to integer lattice [-L,L]^n. Interior consists of unit
 % cells in [-M,M]^n; largest chosen cube stays in the finite lattice box.
 rmax=(max(ks)+max(ts)+delta)/2;
 L=ceil(100*n*(rmax+2)); M=L-ceil(rmax)-2;
 logboundary=n*log((2*M)/(2*L+1)); boundary=exp(logboundary);
 estimates=zeros(size(alphas)); low=estimates; ps=estimates;
 for ai=1:numel(alphas)
  ps(ai)=mean(best>log(alphas(ai)));
  estimates(ai)=boundary*alphas(ai)*ps(ai);
  low(ai)=boundary*alphas(ai)*max(0,ps(ai)-rad);
 end
 [peak,ii]=max(estimates); [pl,jj]=max(low);
 fprintf('n%d delta%.9g boundary%.9g empiricalPeak%.9g atAlpha%.9g prob%.9g conservativePeak%.9g atAlpha%.9g peakOverSqrt%.9g\n',n,delta,boundary,peak,alphas(ii),ps(ii),pl,alphas(jj),peak/sqrt(n));
 fprintf('  minlogQ %.9g medianlogQ %.9g maxlogQ %.9g\n',min(best),median(best),max(best));
 assert(all(isfinite(best)) && boundary>0 && boundary<1);
end
fprintf('Floating Monte Carlo on fixed candidate grid; Hoeffding statement assumes independent uniform sampling, not certified PRNG randomness.\n');
fprintf('No inference of asymptotic exponent, extremal optimum, original hard core, or general upper bound.\n');
