# R417 independent audit — frozen

FINAL PASS within the bounded R417 scope: exact actual two-endpoint weighted identity and separately controlled restoration/J-positive/J-negative terms. Independent screening preceded author reading. Final main/README, both proofs and three Python scripts reviewed; all Python scripts independently rerun with byte-identical delivered stdout. No new unweighted R414/root payment or P is certified. Original ledger unchanged; only this audit file edited.

## Original weighted joint identity

Let v_prev=min(f,T_prev), Δv=min(f,T_new)−v_prev≥0, e_T(x)=1_{x>s}(1−min(f,T)/f), φ_s(x)=2(√x−√s)_+. For f>0 the identity

1−e_new(x)=d_prev+[e_prev^lim−e_prev(x)]+1_{x>s}Δv/f

is algebraically exact with d_prev=1−e_prev^lim. Here e_prev^lim is the actual preceding deletion-stage limit, not e_prev(D_i) substituted at the threshold. If D decreases to s from above, the former can be positive while the latter at s is zero. Current microstep x≤D_i ensures the restoration bracket≥0. At x=s the strict indicator vanishes; when x=y=0 the weighted decrement is defined as zero. The f=0 set has no source-weighted contribution and Δv=0.

Multiplying by f(x−y)/√x and summing both endpoint contributions uses the exact original deletion identity ΔD=∫removedγ(c_u/m_u+c_v/m_v), with no cancellation or missing factor2. For one complete stage,

E_new^w−B_i^sqrt=E_old^w+E_restore^w+J_i−∫Δv_i φ_s(D_after),
B_i^sqrt=∫Δv_i φ_s(D_pre),
J_i=∫Δv_i Σ_micro[1_{x>s}(x−y)/√x−(φ_s(x)−φ_s(y))].

The identity follows by telescoping φ on the unchanged threshold within that stage. Finite/countable microsteps are justified by positive sums and Σ(x−y)/√x≤2√D_pre, ΣΔφ≤2√D_pre. Thus the two terms defining J are separately integrable under Δv≤f and D_pre≤M, f∈L1; no conditional infinity subtraction occurs. An actual stage-limit jump at s is included rather than silently discarded. A finite-stage postterminal term remains unless a legitimate limiting argument removes it.

J has both signs. Above s its bracket is −(√x−√y)^2/√x; at a strict crossing it is 2√s−√x−y/√x. For s=1, x=9/4→0 it is positive, and x=9→0 it is negative. This is not a free signed credit or new original-fee settlement.

## Independently screened global correction bounds

Restoration is zero for x>s: the preceding actual limit must then be strictly above s and has the same e_prev value. It can be nonzero when x≤s, including x=s after a previous limit approached s from above. Its coefficient lies in[0,f]. Along the complete original monotone occupation chain,

Σ_{x≤s}(x−y)/√x≤2√s,

so the total weighted restoration is≤2√s W. Threshold changes without occupation decrement contribute zero.

J+ is possible only at a strict x>s≥y crossing. There is at most one such crossing for each source along the entire original monotone chain, including finite/infinite stage limits. The positive bracket is≤√s and Δv_i≤f, hence ΣJ_i+≤√s W. If the threshold is reached only as a limit, the later x=s steps have J=0 and this assertion is still valid.

Since J_i−≤Δv_i ΣΔφ and Δv_i≤f, telescoping the global nonnegative φ decrease gives ΣJ_i−≤∫fφ(D0)≤2√M W. These bounds are for the signed weighted formula. They do not restore an unweighted deleted-edge cost without the amplitude factor. From the weak endpoint condition only E_new^w≥θ removed_mass/√M follows. Original linear switching is Δv(D−s)+=[(√D+√s)/2]Δvφ_s(D), and this factor cannot be discarded. No old low-D potential or R408 late fraction may be charged again.

## Bounded author review and evidence

Auxiliary §§1–5 retain the pre-deletion occupation in the switch, both endpoints, actual previous-stage limit, finite terminal and the two separately integrable parts of J. The full weighted potential is concave in D: its slope drops from f/√D below s to min(f,T)/√D above s. Thus the stated deletion inequality and the O(√M W) weighted budget have the correct direction. Recovering the original deleted mass by that inequality alone costs √M again. Its source-height tranche is an exact positive layer formula, not a paid tail estimate.

Geometry retains actual old y and marked new z as different labels. For m_u>Km_v, maximal diagonal source-preserving common posterior is f1_{Q_u∩Q_v}/m_u, mass I_uv/m_u≤1/K. With b_i and different endpoint gates, the literal pointwise minimum is the exact common submeasure. The estimate does not imply a fixed unpaid fraction of each marked packet: b_i may concentrate on the intersection. No chain conservation, terminal once-only charge, history refresh or blanket denial of other geometry is inferred.

Independent final-code runs so far:

- parent:693 rational-square tracks,105/210/378, tests restoration/J-sign budgets. Its boundary choice at D=s is a dominating previous limiting e, not a claim of a finite-history realization.
- aux:307 records,216 scalar/12 finite switches/7 two-endpoint/72 signed joint. Finite source/edge algebra only.
- geometry:32 actual full-f matched cube-pair records with q=1, exact volumes and strict far mass. These are single pair diagnostics, not continuous receiver flows or original rank/clock/history/current-D fixtures.

The earlier independent192 rational-square microchains are separate reviewer execution, not archived experiments or added to these counts. No general root bound or P has been proved by these finite checks.

## Final report, numerical scope and accounting

Final main/README use the auxiliary deletion-threshold clock, not original history-time atoms. They do not infer overall RHS improvement, root closure, or a new deleted-flow receipt from the weighted bounds. The exact original linear-to-square-root amplitude is still present. Old-stage defect bounds are upper bounds and are not substituted as subtractive lower credits. R408 late cost and old low-occupation potential are not charged twice.

The frozen formal G/BH/entrance equations agree with R414/R416: G_0≤16 Fhat[R414+C413X_q+V413W], Fhat=(1−32δ−16η)^−1; BH retains32 Fhat on R414/C/V and unchanged outside E387,S390,8s; the entrance retains64 Fhat and its original H, entrance constant and other slots. No new feedback factor or new formal remainder is inserted.

Reviewed the final MATLAB script and nonempty1266-byte delivered output. Parent reports its actual connector rerun; the auditor did not independently invoke MATLAB. The former empty diary/result capture was identified and replaced with the actual returned output, not counted as passed evidence while empty. Final output's four empirical peaks match the report. Its probability calculations and Hoeffding displays remain ordinary floating Monte Carlo, conditional on ideal IID sampling for the probabilistic interpretation, not certified PRNG or interval evidence.

The lattice formula is a valid LOWER average: for even k and a center offset x, a whole source cell of sideδ is captured when its lattice center lies within(k+t)/2; each coordinate has at least k+1 such centers if2dist(x,Z)≤t and k otherwise. Taking the product gives k^{n−N_t}(k+1)^{N_t}. Dividing by(k+t+δ)^n gives the displayed q_low. Partial cells are omitted and can only raise actual f(Q)/|Q|. Thus this is not exact matching of the selected cubes. The finite source box, interior[-M_L,M_L]^n and its boundary factor(2M_L/(2L+1))^n are correct; candidate cubes stay within the finite source range. The fixed finite grid and4096 samples per dimension do not prove a growth exponent, an extremal optimum, an original high-occupation/core realization or a general upper bound. They are not combined with the three Fraction record counts.

The external ball-paper note is explicitly not a theorem input and is not independently revalidated in this audit. It supplies no cube estimate or accounting step here. No missing theorem is inferred from the workflow-skill labels.

No substantive correction to the final mathematical reports remains. Weighted restoration and signed-correction estimates are accepted only in their stated scope; the early/hard joint geometric budget is still open.

## SHA-256 bindings

Bindings refer to final bytes read/reviewed. A later generated TeX/manifest/package is not bound by this audit.

- `r417_main.md`: `d843290d3b81e5906127e0118f315e37d121a48c7c2fc3513bb8aeb983229aaa`
- `r417_readme.md`: `953052e4d75d09fd3ecf10d0c82a8a55ffb6f2f2ae6a0e7daabc816fbc1dc637`
- `r417_aux.md`: `070c1a80e331095fe9e597c78d013d6e8b4a7d17a7958363ce426edac84e29ee`
- `r417_geometry.md`: `f2bd8e2c5f983d8e0daecd9fc6ca8668a664e5b3894a24791b6b08c0c89e7d85`
- `r417_parent_check.py`: `241af5e782d69e63ef13b32baff57aea540bbd8ac9ce0d5989575119f3ca81f1`
- `r417_aux_check.py`: `9bce85db0980b5da9d0750124161555335e1271f726074ac43abdbaae6de84f1`
- `r417_geometry_check.py`: `9d75a5c378c665a8b97441b872fc8a0870c9eb9074564834eb4431eabe0819d3`
- `r417_native_probe.m`: `7b67388ac7ad96b03b036c76def1f1fc7779ba6757081ff48fb836e55d5e4dce`
- `r417_parent.result.txt`: `7a2f0b35857efe64dbd5a210f8dd7790873441aee70c82f5f96f8b6013f3a345`
- `r417_aux.result.txt`: `c14f74efb6bdc0f32affd6977ece1bfb7ce69bf1026d7028b39be1ca2f404767`
- `r417_geometry.result.txt`: `d2d2dd21c757667fa4e2b1b4b04c49678b3f74cb53fb0acd6bc173936f441111`
- `r417_native_probe.result.txt`: `32a58a3aa9c555de5b941d5848c75d59492fac255688184086fd845117d1ead0`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`
- `r416_main.md`: `74aae18d74d3603e7f006a875b696ab04014f7ddec8e3321e5d77d5342a9604b`

Frozen conclusion: no new R414 payment; original full accounting and unresolved general goal retained.
