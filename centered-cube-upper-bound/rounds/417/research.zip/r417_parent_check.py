from fractions import Fraction as F
from itertools import product
from collections import Counter
s=F(4); r=F(2)
phi=lambda a: 2*max(F(0),a-r) # a=sqrt(D)
counts=Counter(); signs=Counter()
for label,levels in [('initial',[0,1,2,3]),('pressure',[0,1,2,4,8]),('expanded',[0,1,2,3,8,16])]:
 for roots in product(levels,repeat=4):
  if not all(roots[i]>=roots[i+1] for i in range(3)): continue
  for f in (F(1),F(3),F(10)):
   Ts=(F(0),F(1,2),F(2),F(7))
   restoration=F(0); jp=F(0); jm=F(0)
   for i in range(3):
    a,b=map(F,roots[i:i+2]); x,y=a*a,b*b
    dv=min(f,Ts[i+1])-min(f,Ts[i])
    # Boundary D_i=s uses largest admissible previous limiting e; supports
    # the inequality even if a specific finite-history realization has e=0.
    prev=(1-min(f,Ts[i])/f) if x>=s else F(0)
    ex=(1-min(f,Ts[i])/f) if x>s else F(0)
    restore=f*(prev-ex)*(x-y)/a if a else F(0)
    restoration+=restore
    j=dv*((x-y)/a*int(x>s) - (phi(a)-phi(b))) if a else F(0)
    jp+=max(j,F(0)); jm+=max(-j,F(0))
    signs['positive' if j>0 else 'negative' if j<0 else 'zero']+=1
    assert restore>=0 and (x<=s or restore==0)
    assert max(j,F(0))<=dv*r
   assert restoration<=2*f*r
   assert jp<=f*r
   assert jm<=f*phi(F(roots[0]))
   counts[label]+=1
print('PASS',dict(counts),'total',sum(counts.values()),'jump signs',dict(signs))
print('Exact rational-square deletion tracks, auxiliary threshold clock only; not original spatial/history realization.')
