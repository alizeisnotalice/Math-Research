"""Exact single-point full-dyadic probability-bridge kernel benchmark."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import time,json,sys,platform,hashlib,resource
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def coeff(n,k):
 s=min(Q(k,n),Q(1,2));return (1-s)**(n-k)*s**k
R_symbol=sp.symbols('R',positive=True)
assert sp.cancel(R_symbol/(R_symbol-1)-1/(R_symbol-1)-1)==0
rows=[]
for n in [2,4,8,16,32,64]:
 R=2**n;cs={k:coeff(n,k) for k in range(1,n+1)}
 assert min(cs.values())==Q(1,R) and all(c>=Q(1,R) for c in cs.values())
 for k in range(1,n//2):assert cs[k]>cs[k+1]
 # Every distinct threshold in a full dyadic-volume period is rational.
 thresholds=sorted(set(cs.values()));critical=[]
 for c in thresholds:
  ge=sum(comb(n,k) for k in range(1,n+1) if cs[k]>=c)
  gt=sum(comb(n,k) for k in range(1,n+1) if cs[k]>c)
  left=c*(1+ge);strict=c*(1+gt)
  assert left<=1 and strict<=left
  item={'threshold_exact':str(c),'threshold':iv(A(c)),'multiplicity_equal':ge-gt,'left_limit_lambda_volume_exact':str(left),'at_strict_threshold_lambda_volume_exact':str(strict),'left_limit':iv(A(left))}
  if c>Q(1,R):
   k=max(i for i in range(1,n+1) if cs[i]==c);p=Q(k,n)
   csum=c*sum(comb(n,i) for i in range(k+1))
   binomial_tail=sum((Q(comb(n,i))*p**i*(1-p)**(n-i) for i in range(k+1)),Q(0))
   assert csum==left and left<=binomial_tail<1
   item.update({'nonflat_k':k,'binomial_lower_tail_exact':str(binomial_tail),'candidate_le_binomial_tail_lt_one_exact':True})
  else:assert left==1;item['flat_minimum_candidate_exactly_one']=True
  critical.append(item)
 # Inspect each open subinterval and the strict jump itself, with exact infinite tails.
 probes=thresholds+[(lo+hi)/2 for lo,hi in zip(thresholds,thresholds[1:]+[Q(1)])]
 checks=[];L=3
 for lam in probes:
  assert Q(1,R)<=lam<1
  counts=sum(comb(n,k) for k in range(1,n+1) if cs[k]>lam)
  W=lam*(1+counts)
  direct_inf=Q(0);truncated=Q(0)
  for k,c in cs.items():
   jmax=0 if c>lam else -1
   direct_inf+=lam*comb(n,k)*Q(R)**(jmax+1)/Q(R-1)
   for j in range(-L,1):
    if c*Q(R)**(-j)>lam:truncated+=lam*comb(n,k)*Q(R)**j
  assert direct_inf==W and W-truncated==lam*Q(R)**(-L)
  # Scaling by R shifts every dyadic center-shell index by -1.
  scaled=lam*R*sum((Q(comb(n,k))*Q(R)**((0 if c>lam else -1))/Q(R-1) for k,c in cs.items()),Q(0))
  assert scaled==W
  checks.append({'lambda_exact':str(lam),'lambda_volume_exact':str(W),'finite_scales_min_j':-L,'finite_scales_max_j':0,'omitted_small_scale_tail_exact':str(lam*Q(R)**(-L)),'infinite_sum_residual':'0','dyadic_periodicity_residual':'0'})
 weak=max([Q(1)]+[Q(z['left_limit_lambda_volume_exact']) for z in critical]);assert weak==1
 rows.append({'stage':'initial' if n<=8 else 'expanded_dimension','n':n,'R_volume_scaling':str(R),'period_lambda_exact':[str(Q(1,R)),'1 (excluded)'],'annular_category_volume':'binom(n,k)*a^n, k=1..n, where a=2^j is smallest legal radius parameter','category_counts_sum':str(sum(comb(n,k) for k in range(1,n+1))),'coefficients':[{'k':k,'s_star_exact':str(min(Q(k,n),Q(1,2))),'c_k_exact':str(c)} for k,c in cs.items()],
  'weak_L1_quasinorm_exact':str(weak),'weak_L1_over_sqrt_n':iv(A(weak)/A(n).sqrt()),'distinct_thresholds':len(thresholds),'all_threshold_candidates':critical,'period_checks':checks,'all_nonflat_candidates_strictly_below_one':True,'infinite_tail_included_exactly':True})
out={'status':'PASS_EXACT_SINGLE_POINT_WEAK_L1_NORM_ONE_ALL_6_DIMENSIONS','definition':'P_(a,s)(x)=a^(-n)(1-s)^(n-k)s^k on [-a,a]^n, k=# coordinates |x_i|>a/2; a=2^j, j integer, 0<=s<=1/2. H_n=sup_(j,s)P_(2^j,s).',
 'reduction':{'minimal_scale':'For x!=0 outside measure-zero dyadic faces, the smallest legal a has k>=1; optimize s*=min(k/n,1/2), c_k=(1-s*)^(n-k)s*^k.',
 'larger_scale':'At a_next=2a, all coordinates are inner and maximum is (2a)^(-n). Later scales are smaller. Since c_k>=2^(-n), H_n(x)=c_k a^(-n) on the smallest-scale category.',
 'distribution_formula':'lambda|{H>lambda}|=lambda sum_k binom(n,k) sum_{j: c_k R^(-j)>lambda} R^j; R=2^n. Infinite small-scale tail is a convergent geometric sum; large scales have finite upper cutoff.',
 'one_period':'For 1/R<=lambda<1, jmax=0 if c_k>lambda, else -1; exact result W(lambda)=lambda[1+sum_{c_k>lambda}binom(n,k)]. W(R lambda)=W(lambda). The added1 is the whole infinite tail, not an extra source atom.',
 'critical_values':'Supremum occurs among left limits c[1+sum_{c_k>=c}binom(n,k)] and lambda->1. Strict > sets at equality use c_k>lambda. Jumps are not treated as attained maxima.'},
 'general_analytic_result':'For every integer n>=1, ||H_n||_(weak L1)=1. For a nonflat threshold k<n/2, candidate=c_k sum_{i=0}^k binom(n,i)<=P[Bin(n,k/n)<=k]<1. At the flat minimum c=2^-n, left limit is1; equivalently W(lambda)->1 as lambda->1-. Thus no super-root-n single-point obstruction in this model.',
 'mollifier_boundary':'This is a unit Dirac-input kernel calculation, not a general L1 maximal-operator bound. A compactly supported probability mollifier approximates each fixed kernel at continuity points; finite subfamilies can transfer point-test lower bounds. No convergence of the full weak norm or general L1 upper bound is asserted.',
 'rows':rows,'error_policy':'All coefficients, thresholds, counts, strict-level comparisons, geometric tails and weak norms are exact Fraction. Arb256 encloses conversion and sqrt normalization only. No sampling, numerical integration, optimization or floating threshold decisions.',
 'versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'BLAS_threads':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r611_numeric.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'n':r['n'],'thresholds':r['distinct_thresholds'],'weak_norm':r['weak_L1_quasinorm_exact']} for r in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
