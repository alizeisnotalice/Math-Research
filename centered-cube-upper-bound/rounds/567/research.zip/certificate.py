#!/usr/bin/env python3
"""R567 exact critical cases; no random search and no solver."""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
import argparse, json, platform
from itertools import product as cartesian


def frac(x):
    return F(str(x))


def fs(x):
    return str(x.numerator) + '/' + str(x.denominator)


def product(xs):
    p=F(1)
    for x in xs: p*=x
    return p


def overlap(*intervals):
    return max(F(0),min(b for a,b in intervals)-max(a for a,b in intervals))


def probability(A,D,y,z,l):
    aa=[];dd=[];bb=[];ee=[]
    for (am,ap),(dm,dp),yy,zz in zip(A,D,y,z):
        Y=(max(yy,zz)-l,min(yy,zz))
        a=overlap(Y,(am,ap-l))/l
        d=overlap(Y,(dm,dp-l))/l
        b=overlap(Y,(max(am,dm),min(ap,dp)-l))/l
        u=overlap(Y,(min(am,dm),max(ap,dp)-l))/l
        e=u-a-d+b
        assert e>=0
        aa.append(a);dd.append(d);bb.append(b);ee.append(e)
    cross=sum((ee[j]*product(bb[:j]+bb[j+1:]) for j in range(len(y))),F(0))
    terms=[product(aa),product(dd),-product(bb),cross]
    p=sum(terms,F(0))
    q=product([max(F(0),1-abs(yy-zz)/l) for yy,zz in zip(y,z)])
    assert 0<=p<=q<=1
    return p,q,terms


def direct_probability(A,D,y,z,l):
    # Independent left-endpoint integration. All containment changes occur
    # at box endpoints or endpoints minus l; no use of a,d,b,e formula.
    slices=[]
    for (am,ap),(dm,dp),yy,zz in zip(A,D,y,z):
        lo,hi=yy-l,yy
        cuts=sorted({lo,hi,*[v for v in [am,ap,am-l,ap-l,dm,dp,dm-l,dp-l,zz,zz-l] if lo<v<hi]})
        slices.append(list(zip(cuts,cuts[1:])))
    total=F(0)
    def inbox(v,box): return all(lo<=x<=hi for x,(lo,hi) in zip(v,box))
    for rect in cartesian(*slices):
        left=[(lo+hi)/2 for lo,hi in rect]
        if not all(v<=zz<=v+l for v,zz in zip(left,z)): continue
        # Subdivide the physical cell at all A,D faces; membership in A U D
        # is constant on each open elementary rectangle.
        physical=[]
        for v,(am,ap),(dm,dp) in zip(left,A,D):
            cuts=sorted({v,v+l,*[w for w in [am,ap,dm,dp] if v<w<v+l]})
            physical.append([(lo+hi)/2 for lo,hi in zip(cuts,cuts[1:])])
        if all(inbox(v,A) or inbox(v,D) for v in cartesian(*physical)):
            total+=product([hi-lo for lo,hi in rect])/l**len(y)
    return total


def cube(lo,hi):
    return [(frac(a),frac(b)) for a,b in zip(lo,hi)]


def run(contract=None):
    # All endpoints and scales here are exact rationals. These are critical
    # deterministic cases, deliberately distinct from the author's broad scan.
    specs=[
      ('tied_collision_zero',[-2,-2],[2,2],[-2,-2],[2,2],[0,0],[1,1],2),
      ('single_collision_zero',[-2,-2],[2,2],[-2,-2],[2,2],[0,0],[1,0],2),
      ('positive_crossing',[-1,-1],[1,1],[0,-1],[2,1],['1/2',0],['1/2',0],'3/2'),
      ('crossing_and_separation',[-1,-1],[1,1],[0,-1],[2,1],['1/2',0],['-1/4',0],'3/2'),
      ('two_coordinate_box_defect',[-1,-1],[1,1],[0,0],[2,2],['1/2','1/2'],['-1/2',0],'3/2'),
      ('nested_three_dimensional',[-2,-2,-2],[2,2,2],[-1,-1,-1],[1,1,1],[0,0,0],['3/2',0,0],2),
      ('unequal_side_lengths',[-1,-1],[1,1],['-1/2','-1/2'],['1/2','1/2'],[0,0],['3/4','3/4'],1),
      ('boundary_anchor',[-1,-1],[1,1],[0,-1],[2,1],[0,1],[-1,1],1),
    ]
    records=[]
    for name,alo,ahi,dlo,dhi,y,z,l in specs:
        A=cube(alo,ahi);D=cube(dlo,dhi);y=list(map(frac,y));z=list(map(frac,z));l=frac(l)
        assert all(am<=yy<=ap and dm<=yy<=dp and am<=zz<=ap for (am,ap),(dm,dp),yy,zz in zip(A,D,y,z))
        assert len({ap-am for am,ap in A})==len({dp-dm for dm,dp in D})==1
        p,q,terms=probability(A,D,y,z,l)
        assert direct_probability(A,D,y,z,l)==p
        for s in [F(1),F(1,2),F(2,3)]:
            ps,qs,termss=probability(A,D,y,z,s*l)
            assert direct_probability(A,D,y,z,s*l)==ps
            strong=ps-p+q-qs
            final=ps-1+(1-p)/s
            qconvex=qs-1+(1-q)/s
            assert strong>=0 and final>=0 and qconvex>=0
            records.append(dict(name=name,A=[[fs(a),fs(b)] for a,b in A],D=[[fs(a),fs(b)] for a,b in D],y=list(map(fs,y)),z=list(map(fs,z)),ell=fs(l),s=fs(s),p=fs(p),q=fs(q),p_scaled=fs(ps),q_scaled=fs(qs),terms=list(map(fs,terms)),terms_scaled=list(map(fs,termss)),strong_residual=fs(strong),persistence_residual=fs(final),q_convex_residual=fs(qconvex)))
    # Q''(t) = sum_{i!=j} x_i x_j prod_{k!=i,j}(1-t*x_k)
    # before first zero. Single/tied zero and all-zero vectors included.
    derivatives=[]
    for xx in [[F(0),F(0)],[F(1,2),F(1,2)],[F(1,2),F(1,4)],[F(1,4),F(1,3),F(1,2)]]:
        nonzero=[x for x in xx if x]
        t0=min([1/x for x in nonzero],default=F(2))
        for t in [F(0),t0/2,t0]:
            factors=[1-t*x for x in xx]
            d2=sum((xx[i]*xx[j]*product([factors[k] for k in range(len(xx)) if k not in (i,j)]) for i in range(len(xx)) for j in range(len(xx)) if i!=j),F(0))
            leftd=-sum((xx[i]*product(factors[:i]+factors[i+1:]) for i in range(len(xx))),F(0))
            assert d2>=0
            if t==t0 and nonzero: assert leftd<=0
            derivatives.append(dict(x=list(map(fs,xx)),t=fs(t),Q_second_derivative=fs(d2),left_derivative=fs(leftd)))
    script=Path(__file__).resolve()
    hashes={script.name:sha256(script.read_bytes()).hexdigest(), 'contract':None if contract is None else {'path':str(contract), 'sha256':sha256(contract.read_bytes()).hexdigest()}}
    return dict(scope='Exact critical-case arithmetic plus independent analytic scale-persistence proof; no weighted residual/terminal estimate',python=platform.python_version(),arithmetic='fractions.Fraction; zero rounding error',case_count=len(records),independent_direct_integration_checks=32,derivative_check_count=len(derivatives),all_checks_pass=True,critical_cases=records,derivative_checks=derivatives,hashes=hashes,log_mixture=dict(ell_range='[a/8,b]',sup_range='[a/4,b]',L='ln(8b/a)',Psi_small='-ln(1-eta)-eta for 0<=eta<=1/2',Psi_large='ln(2)-1+eta for 1/2<=eta<=1',price='L/Psi(eta) times c0*Lcl(K)*W',weak_t_eta='ln((1-eta/2)/(1-eta)); 0<eta<=1/2',unpaid=['low-cover original inverse-L weighted residual','separated/terminal bill','mother/root-order estimate']))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path)
    parser.add_argument('--contract',type=Path,help='Optional contract file, used only for metadata hashing')
    args=parser.parse_args();out=json.dumps(run(args.contract),indent=2,ensure_ascii=False)+'\n'
    if args.output: args.output.write_text(out)
    print(out,end='')
