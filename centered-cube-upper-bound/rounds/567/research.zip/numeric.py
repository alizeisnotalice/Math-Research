"""R567: exact rational full-coordinate union probability persistence probes.
Structural geometry only: no LP, Gram, or full weighted-budget experiment.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,hashlib,json,math,platform,random,resource,time

def prod(xs):
 p=F(1)
 for x in xs:p*=x
 return p

def intersect_length(*intervals):return max(F(0),min(q[1] for q in intervals)-max(q[0] for q in intervals))
def probability(A,D,y,z,l):
 a=[];d=[];b=[];u=[];e=[]
 for (al,ah),(dl,dh),yy,zz in zip(A,D,y,z):
  Y=(max(yy,zz)-l,min(yy,zz));aa=intersect_length(Y,(al,ah-l))/l;dd=intersect_length(Y,(dl,dh-l))/l;bb=intersect_length(Y,(max(al,dl),min(ah,dh)-l))/l;uu=intersect_length(Y,(min(al,dl),max(ah,dh)-l))/l
  a.append(aa);d.append(dd);b.append(bb);u.append(uu);e.append(uu-aa-dd+bb)
 assert all(v>=0 for v in e)
 cross=sum((ee*prod(b[:j]+b[j+1:]) for j,ee in enumerate(e)),F(0));single=prod(a)+prod(d)-prod(b);p=single+cross;q=prod([max(F(0),1-abs(zz-yy)/l) for yy,zz in zip(y,z)])
 assert 0<=p<=q<=1
 return dict(p=p,q=q,single_box=single,crossing=cross,bounding_box=prod(u),a=a,d=d,b=b,u=u,e=e)

def independent_grid_integral(A,D,y,z,l):
 # Exact piecewise-constant auxiliary left-endpoint integral. Containment is
 # checked directly at all source-box coordinate cuts and gap midpoints.
 breaks=[]
 for (al,ah),(dl,dh),yy,zz in zip(A,D,y,z):
  vals={yy-l,yy};vals.update(v for v in [zz-l,zz,al,ah,al-l,ah-l,dl,dh,dl-l,dh-l] if yy-l<v<yy);breaks.append(sorted(vals))
 intervals=[list(zip(v[:-1],v[1:])) for v in breaks];answer=F(0);pieces=0
 for cell in product(*intervals):
  left=[(v+w)/2 for v,w in cell]
  if not all(v<=zz<=v+l for v,zz in zip(left,z)):continue
  tests=[]
  for v,(al,ah),(dl,dh) in zip(left,A,D):
   cuts=sorted({v,v+l}|{b for b in [al,ah,dl,dh] if v<b<v+l});tests.append(cuts+[(a+b)/2 for a,b in zip(cuts[:-1],cuts[1:])])
  contained=True
  for point in product(*tests):
   if not (all(a<=v<=b for v,(a,b) in zip(point,A)) or all(a<=v<=b for v,(a,b) in zip(point,D))):contained=False;break
  if contained:answer+=prod([b-a for a,b in cell])/l**len(y)
  pieces+=1
 return answer,pieces

def pack(obj):
 if isinstance(obj,F):return str(obj)
 if isinstance(obj,dict):return {k:pack(v) for k,v in obj.items()}
 if isinstance(obj,(list,tuple)):return [pack(v) for v in obj]
 return obj

def check(case,independent=False):
 A,D,y,z,l,r=case['A'],case['D'],case['y'],case['z'],case['ell'],case['r'];big=probability(A,D,y,z,l);small=probability(A,D,y,z,r*l);loss=big['p']-(big['q']-small['q']);bound=1-(1-big['p'])/r
 assert small['p']>=loss and small['p']>=bound
 out=dict(**case,p_large=big,p_small=small,strong_bound=loss,claimed_bound=bound,strong_slack=small['p']-loss,claimed_slack=small['p']-bound,nonmonotone=small['p']<big['p'])
 if independent:
  exact,pieces=independent_grid_integral(A,D,y,z,l);assert exact==big['p'];out['independent_integral']=exact;out['independent_auxiliary_pieces']=pieces
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();st=time.perf_counter();critical=[]
 def add(name,A,D,y,z,l,r,ind=False):critical.append(check(dict(name=name,A=A,D=D,y=y,z=z,ell=l,r=r),ind))
 add('sharp_shrink_loss_n1',[(-F(2),F(2))],[(-F(2),F(2))],[F(0)],[F(1,2)],F(1),F(1,2),True)
 add('probability_one_persists',[(-F(2),F(2))],[(-F(2),F(2))],[F(0)],[F(0)],F(1),F(3,4),True)
 add('source_separation_boundary',[(-F(2),F(2))],[(-F(2),F(2))],[F(0)],[F(1)],F(1),F(7,8),True)
 add('mixed_endpoint_n2',[(-F(1),F(1))]*2,[(-F(1,2),F(3,2))]*2,[F(0)]*2,[-F(3,4),F(0)],F(3,2),F(3,4),True)
 add('positive_unique_crossing_n2',[(-F(1),F(1))]*2,[(F(0),F(2)),(-F(1),F(1))],[F(1,2),F(0)],[F(1,4),F(0)],F(3,2),F(3,4),True)
 add('diagonal_union_not_bounding_box',[(-F(1),F(1))]*2,[(-F(1,2),F(3,2))]*2,[F(0)]*2,[F(3,4),F(3,4)],F(3,2),F(1,2),True)
 add('capture_boundary_y',[(-F(1),F(0))]*2,[(F(0),F(1))]*2,[F(0)]*2,[-F(1,2),-F(1,2)],F(1),F(3,4),True)
 rng=random.Random(567);records=[]
 for n in [1,2,3,4]:
  for k in range(16):
   sideA=F(rng.choice([1,2,3]));sideD=F(rng.choice([1,2,3]));ca=[sideA*F(rng.randint(-4,4),8) for _ in range(n)];cd=[sideD*F(rng.randint(-4,4),8) for _ in range(n)];A=[(v-sideA/2,v+sideA/2) for v in ca];D=[(v-sideD/2,v+sideD/2) for v in cd];y=[F(0)]*n;z=[lo+(hi-lo)*F(rng.choice([0,1,2,3,4]),4) for lo,hi in A]
   for l in [F(1,4),F(1,2),F(1),F(2),F(4)]:
    for r in [F(1,2),F(3,4),F(7,8)]:records.append(check(dict(name=f'n{n}_case{k}',A=A,D=D,y=y,z=z,ell=l,r=r)))
 allrows=critical+records;summary=dict(cases=len(allrows),main_cases=len(records),critical_cases=len(critical),range_violations=0,strong_loss_violations=0,claimed_persistence_violations=0,min_claimed_slack=min(t['claimed_slack'] for t in allrows),nonmonotone_shrink_cases=sum(t['nonmonotone'] for t in allrows),positive_crossing_cases=sum(t['p_large']['crossing']>0 for t in allrows),bounding_box_strictly_exceeds_union_cases=sum(t['p_large']['bounding_box']>t['p_large']['p'] for t in allrows),exact_arithmetic='fractions.Fraction; all endpoints and comparisons exact',seed=567)
 payload=pack(dict(schema='R567.numeric.1',scope='Full-coordinate structural probability only, not integrated weighted dV/Cstar or general dimension evidence',definition=dict(p='Uniform anchored u in [0,1]^n: z in J_ell(u) and J_ell(u) subset A union D, same u at both scales',range='y in A intersection D, z in A; r in (0,1], ell>0',strong='p_r_ell >= p_ell - (q_ell-q_r_ell)',claimed='p_r_ell >= 1-r^-1*(1-p_ell)'),summary=summary,critical_cases=critical,records=records,cost=dict(seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,processes=1,LP_calls=0),python=platform.python_version(),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
 Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(dict(summary=payload['summary'],cost=payload['cost'],critical=[dict(name=t['name'],p_large=t['p_large']['p'],p_small=t['p_small']['p'],crossing=t['p_large']['crossing'],slack=t['claimed_slack']) for t in payload['critical_cases']]),indent=2))
if __name__=='__main__':main()
