"""Small independent algebra/Arb checks; no model or optimizer is rerun."""
import argparse, hashlib, json, platform, time
from pathlib import Path
import sympy as sp
import flint
from flint import arb, ctx

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args(); start=time.perf_counter();ctx.prec=192
    s,t,ell,delta,A,a,L,C,b0,D,T=sp.symbols('s t ell delta A a L C b0 D T',positive=True)
    checks={
      'Psi_small_integral':sp.simplify(sp.integrate(1-sp.exp(t)*(1-s),(t,0,-sp.log(1-s)))+sp.log(1-s)+s),
      'Psi_large_integral':sp.simplify(sp.integrate(1-sp.exp(t)*(1-s),(t,0,sp.log(2)))-(sp.log(2)-1+s)),
      'Psi_join':sp.simplify((-sp.log(1-s)-s-(sp.log(2)-1+s)).subs(s,sp.Rational(1,2))),
      'Psi_low_derivative':sp.simplify(sp.diff(-sp.log(1-s)-s,s)-s-s**2/(1-s)),
      'Psi_high_derivative':sp.simplify(sp.diff(sp.log(2)-1+s,s)-s-(1-s)),
      'mixed_scale_square':sp.simplify((1-sp.sqrt(delta))**2-(1-delta/ell)*(1-ell)-(ell-sp.sqrt(delta))**2/ell),
      'mixed_optimum_derivative':sp.simplify(sp.diff((1-delta/ell)*(1-ell)/(1-delta),ell).subs(ell,sp.sqrt(delta))),
      'mixed_optimum_value':sp.simplify(((1-delta/ell)*(1-ell)/(1-delta)).subs(ell,sp.sqrt(delta))-(1-sp.sqrt(delta))/(1+sp.sqrt(delta))),
    }
    gap=1-8*A*A*a
    allow=(b0*b0*gap*T*T/(4*D)-4*C)/(8*A*A)
    checks['full_budget_allowance']=sp.simplify(4*D/b0**2*(4*C+8*A*A*allow)/gap-T*T)
    # The rho normalization is integral omega/kappa divided by that same I.
    NB,NC,IB,IC=sp.symbols('NB NC IB IC',positive=True)
    checks['restored_denominator']=sp.simplify(NB*NC*(IB/NB)*(IC/NC)-IB*IC)
    checks['full_vs_far_credit']=sp.simplify((1/(8*A*A)+a)<1/(4*A*A))
    inequality=str(checks.pop('full_vs_far_credit'))
    assert all(v==0 for v in checks.values()),checks
    profiles=[]
    for numerator,denominator in [(1,1024),(1,16),(1,4),(1,2),(3,4),(1,1)]:
        eta=arb(numerator)/denominator
        psi=-(1-eta).log()-eta if numerator*2<=denominator else arb(2).log()-1+eta
        margin=psi-eta*eta/2
        assert margin>0
        profiles.append({'eta':f'{numerator}/{denominator}','Psi':psi.str(40),
                         'Psi_minus_eta_squared_over_two':margin.str(40),
                         'eta_squared_over_Psi':(eta*eta/psi).str(40)})
    geometry=[]
    for n in [4,16,64,256,1024,4096]:
        x=1/arb(n).sqrt()
        log_profile=n*((1-x).log()-(1+x).log())
        log_cap=n*(1-arb(1)/n).log()
        exp_gap=-2*arb(n).sqrt()-log_profile
        assert exp_gap>0
        geometry.append({'n':n,'mixed_capacity':log_cap.exp().str(40),
                         'log_max_average_profile':log_profile.str(40),
                         'log_exponential_bound_minus_log_profile':exp_gap.str(40)})
    result={'scope':'Symbolic identities and finite Arb192 diagnostics, not an original-history example or a full residual budget',
      'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,
      'precision_bits':ctx.prec,'symbolic_residuals':{k:str(v) for k,v in checks.items()},
      'far_credit_equivalence':inequality,'profile_checks':profiles,'geometry_checks':geometry,
      'all_checks_pass':True,'seconds':time.perf_counter()-start,
      'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'all_checks_pass':True,'symbolic_zero_residuals':len(checks),'profile_cases':len(profiles),'geometry_cases':len(geometry),'seconds':result['seconds']}))

if __name__=='__main__':main()
