# 第567轮便携复现

解压本包后在任意新目录放置 numeric.py、certificate.py、verify.py。前两者仅用Python标准库；第三个需SymPy和python-flint。已实际在只有这些脚本的新建目录执行，数学字段与作者记录完全一致。无旧资料、优化器或 /tmp 合同依赖。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python numeric.py --output numeric.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python certificate.py --output certificate.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --output verify.json
```

numeric.json 会重建全部967条记录；归档的numerics_summary.json只省略可重建的960条主记录。比较summary、critical_cases和实际重新生成records；时间/RSS属于执行元数据。certificate.json与exact_certificate.json的数学字段一致，脚本文件名造成hashes键名变化时不改变证书。`--contract path`仅是可选合同元数据哈希，不参与数学。

verify.json保留10个SymPy零残差、6个Arb阈值证书和6个解析诊断维数。运行时间会变化；固定精度和输入的数学结果须一致。Arb球区间验证只覆盖明确表达式和有限输入，其一般式有REPORT的解析证明。

独立复现记录为verification.json；manifest列全部其他成员的字节数和SHA256。ZIP CRC另由归档检查核验。REPORT.tex保留详细LaTeX，没有编译PDF；结构检查仅核环境、括号、数学定界符、唯一手动编号、引用与Python AST，不冒充TeX编译通过。

历史证明引用固定在SOURCES所列已提交研究包。R565完整原测度与R566近支定理是本轮已证输入，不需要重跑历史数值优化；本包没有新认证全尺度极限。
