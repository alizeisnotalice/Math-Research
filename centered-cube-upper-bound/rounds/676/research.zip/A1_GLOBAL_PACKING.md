# R676 A1 — original-target representatives and the unpaid joint reserve

## Result

No new bound V_rem<=C tau P0, and no sufficient estimate V_rem<=A U+B(tau P0-U), is proved in this bounded investigation. The route tested here genuinely permits packing the original target parents themselves. Its failure is located before a global source-reserve estimate: a jointly feasible representative selection produces intersecting stars, whereas the available joint source certificate requires actual capture. Those are different geometric conditions. Neither implication nor its cumulative replacement has been proved.

P0 throughout is the packing optimum over the **entire original finite family O**, including admission-discarded labels:

    P0=max sum_{i in O} d_i theta_i,
       theta_i>=0,  sum_{i in O}theta_i 1_Ai<=1 a.e.

A construction using some actual target labels gives a lower bound for this P0; it does not redefine P0 on the admitted set or q support. The original q, owners, source order, corrected self convention, witnesses, and actual disjoint X_h remain unchanged.

## 1. The concrete full-scale representative construction

Process the actual remaining target parents by decreasing radius, with a fixed tie rule. Choose an unremoved parent A_r, and remove all remaining A_h whose interiors intersect A_r. Repeat. The chosen original parents have disjoint interiors, so assigning theta_r=1 to each chosen representative, and zero elsewhere, is a genuine feasible original-family packing. In particular,

    sum_r d_r <=P0.                                         (1)

Let C_r be the actual targets removed with r, and let V_r=sum_{h in C_r}|X_h|. These groups partition the complete remaining demand, with sum_r V_r=V_rem. This construction includes all occupied scales in one packing; no average over the number of scale intervals is used.

Its exact available geometric envelope is, however,

    X_h subset Q(y_r,s_r+c0 s_h)
          subset Q(y_r,(1+c0)s_r),
    V_r <=(1+c0)^n d_r.                                    (2)

Here s_h<=s_r and parent intersection gives ||y_h-y_r||_infinity<=s_h+s_r. Real receiver disjointness proves (2). Summing it gives only an exponential-dimensional estimate. The small concentric owner boxes do not change (2) to c d_r.

The known sharper common-point estimate cannot be inserted at this step. For any x and D,

    sum_{h:x in A_h, d_h<=D}|X_h|<=cD.                      (3)

Thus a true parent clique can be paid by its largest parent. But each C_r in (2) is an intersection star, not necessarily a clique. Pairwise intersection with A_r does not give one point in every member. Also different valid cliques can have intersecting representative parents; choosing all of those representatives with weight one need not give a packing. Formula (3) is a previously available local constraint, not claimed as progress of this round.

## 2. Why the strong source reserve has not paid the star discrepancy

The real common-point source theorem gives a strong reserve for each individual actual seed pool. In the inherited notation, if J_h has rate T_h, then its genuine owner mass satisfies

    U_Jh >=c d_h exp(T_h/c-1)                               (4)

in the present high-rate regime. This follows from the established minimum-mass growth inequality and d_min>=d_h. Its relevant scope and proof were separately checked by S2; no new local theorem is asserted here. For a true parent clique one may choose its largest target h and compare (3) with (4). This still gives only one local source debit.

There are two distinct missing steps when attempting to use (4) in the genuine packing construction (1).

First, the receiver group C_r need not satisfy any capture condition for the source profile at r. In particular,

    A_h intersects A_r

has not been shown to imply

    sum_i t_i,r 1_Ai(z_h) >=(4/5)nu.                        (5)

The witnesses may lie at different positions in intersecting target parents. The source family at r shares z_r, and the source family at h shares z_h; target-parent intersection alone does not identify these two actual sections of the source arrangement. Thus the existing R673 joint bound cannot price all of V_r by the mass of r's profile. Replacing its receiver group by a star without proving (5) would silently discard a necessary geometric hypothesis.

Second, if one instead refines the stars into genuine capture groups, each such group has a valid local joint price, but the same source can be used in many refined groups. Disjointness of the selected target representatives controls sum_r d_r in (1). It does not establish a bound for those repeated source fractions. A fixed source can meet many smaller disjoint representative parents. The known finite near-window incidence counts scales for that source, not the number or total payment of these groups. No uniform weighted cumulative debit was obtained.

The strong volume separation implicit in (4) does not repair this point by an ordinary dilation argument. A source cutoff volume at least exp(Omega(sqrt(n)))d_h gives only a guaranteed radius factor exp(Omega(1/sqrt(n))). It does not guarantee a radius ratio of order n, which would make an additive target-radius displacement a 1+O(1/n) enlargement. No exponential volume factor has been discarded on the basis of that weaker radius separation.

## 3. What a successful joint use of the original parents must still supply

For the actual selection (1), the unproved requirement is a simultaneous settlement of the real star demands: their total must be controlled by the selected-parent value and/or source reserve charged without uncontrolled repetition. It is not enough to establish the price for one star, choose one locally valuable original parent, or attach an independently reusable reserve to each seed. The needed estimate must hold for the same complete family of groups and keep every incidence in its sum.

One possible sufficient account would be

    sum_r V_r <=C tau sum_r d_r + A U,

with absolute constants and with the real C_r above. This is not asserted and is not presented as a new reduction: it merely identifies what the attempted concrete construction failed to prove. Since sum_r d_r<=P0 and U<=tau P0, such an estimate would indeed close the desired complete account. No local source growth or common-point receiver estimate in this note establishes it.

The broader target still allows a different full-space packing on all of O, including admission-discarded labels, and need not use this radius-greedy representative choice. The failure recorded here does not rule out that broader possibility. It also does not establish a counterexample for actual admissible inputs.

## Checkpoint and stop

This round produced no new global payment inequality. The useful decision is to reject a specific invalid shortcut: jointly feasible target representatives yield stars, whereas the cheaply priced source groups require genuine capture; strong local owner-mass reserve does not bridge that mismatch or pay subsequent reuse. The common-point demand bound, source mass growth, and packing definitions remain inherited tools rather than newly counted progress.

Only the requested R675 continuation, R672 account/repair sections, and necessary current definitions were consulted. No historical scan, source-cap refinement, single-target repair, equivalent LP repackaging, new high-fraction threshold, repeated scalar computation, MATLAB session, child agent, Git operation, PDF, or edit to another agent's file was used. A numerical test would not verify the missing all-input geometric implication or cumulative source budget, so none was substituted for it. Work stops at this bounded checkpoint.
