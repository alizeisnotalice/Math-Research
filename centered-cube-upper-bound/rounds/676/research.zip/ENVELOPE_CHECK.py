from pathlib import Path
import hashlib,json,platform
from flint import arb,ctx
import flint
ctx.prec=256

def logfee(n,b):
 n=arb(n);c0=1+1/(32*n);logc=n*c0.log();c=logc.exp();tau=16384*n.sqrt()
 return n*(b+c0).log()-logc+3-3*tau/(8*c)

def sign(a):
 if a>0:return 1
 if a<0:return -1
 raise AssertionError('interval sign unresolved')

probes=[]
for stage,ns in [('initial',[256,4096,2**20]),('stress',[2**24,2**25,2**26,2**27]),('expanded',[2**32,2**40,2**48])]:
 for n in ns:
  for b in (1,2):
   v=logfee(n,b)
   probes.append({'stage':stage,'n':n,'base_offset':b,'log_fee':str(v),'sign':sign(v),'pass':True})
brackets=[]
for b in (1,2):
 lo=256;hi=512
 while sign(logfee(hi,b))<0:lo=hi;hi*=2
 evaluations=[]
 while hi-lo>1:
  mid=(lo+hi)//2;s=sign(logfee(mid,b));evaluations.append([mid,s])
  if s<0:lo=mid
  else:hi=mid
 assert sign(logfee(lo,b))==-1 and sign(logfee(hi,b))==1
 brackets.append({'base_offset':b,'negative_n':lo,'positive_n':hi,'negative_log_fee':str(logfee(lo,b)),'positive_log_fee':str(logfee(hi,b)),'binary_sign_queries':evaluations,'scope':'adjacent certified sign change, not a claim of unique or first root','pass':True})
# Recheck only the critical adjacent dimensions at doubled precision.
ctx.prec=512
rechecks=[]
for z in brackets:
 for key,sgn in [('negative_n',-1),('positive_n',1)]:
  v=logfee(z[key],z['base_offset']);assert sign(v)==sgn
  rechecks.append({'base_offset':z['base_offset'],'n':z[key],'precision_bits':512,'log_fee':str(v),'sign':sgn,'pass':True})
r={'scope':'upper-certificate scalar costs only, not actual geometric examples, lower bounds, or a general maximal theorem','python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':256,'probes':probes,'brackets':brackets,'critical_rechecks':rechecks,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('ENVELOPE_RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'probes':len(probes),'brackets':[{k:z[k] for k in ['base_offset','negative_n','positive_n']} for z in brackets],'critical_rechecks':len(rechecks),'all_pass':True}))
