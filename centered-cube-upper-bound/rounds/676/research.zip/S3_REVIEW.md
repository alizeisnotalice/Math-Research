# R676 S3 independent bounded review

Status: FINAL PASS within the bounded scope below. No mandatory mathematical correction found in the final REPORT or the two author files. This does not certify a new complete global bound.

## Scope and source binding

Before reading either author file, independently derived the clique receiver envelope and packing weight, the two-step representative envelope, the radius-greedy star envelope, the source-mass bound from the supplied prefix growth, and the resulting fee/asymptotic direction. Then compared those derivations with the two author texts.

Final reviewed source SHA-256 values:

- REPORT.tex: 5e22fd816033fdac0c4824ceea843703e3d490e07fdee11512e1bc0cf963ab2c
- A1_GLOBAL_PACKING.md: 99b090f698b6b738c76872b468e8b18bde339e64ecd28a5a7dc5a569f79df7ce
- S2_SCALE_COUPLING.md: e3b775da971a9e0fce36a6e183ffed66b30200858671cb4d9d20a92ee3b0ada9
- ENVELOPE_CHECK.py: 6769819cda95a64214e7d49cc2acacd3a54657c96c7671782060219a871104fa
- ENVELOPE_RESULT.json: 446cd41acb37589eb3491d33c8b81d5caa30936cf7ba93df69932499acf13fbf

The common-seed prefix-growth theorem, genuine source geometry and strong near reserve are accepted exactly as supplied in the bounded review contract; their historical proofs were not reopened. This review certifies the deductions below, not the general complete packing objective or any new root-order bound. No numerical calculation was rerun; MATLAB, Git, PDF and subagents were not used. Only S3_REVIEW.md is written by this reviewer.

## 1. Single actual target clique

If every original target parent in a finite subfamily contains x, then for y in the actual X_h subset Q(y_h,s_h/(32n)),

    ||y-x||_infinity <= s_h/(32n)+s_h <= c0 R,

where R=max_h s_h and d_max=(2R)^n. Real receiver disjointness gives V_C=sum_h|X_h|<=c d_max. Setting the ORIGINAL maximum parent's packing coefficient to V_C/(c d_max)<=1 pays exactly V_C/c. Setting that coefficient to one also gives a valid objective at least V_C/c. This uses a variable in the entire original packing family, even if its original q is zero. It does not impose q caps on final packing variables.

Finite axis-parallel box Helly justifies replacing a common-point hypothesis by pairwise intersection for these parent boxes. Combining separately chosen representatives still requires a genuine joint packing condition. Pairwise disjoint representative interiors are sufficient because the packing constraint is a.e.; arbitrary intersecting representatives cannot all be assigned weight one for free.

## 2. Double compression and the star envelope

For a clique C_a with common point w_a and maximum representative of radius r_a, suppose its representative contains the common representative point x. For any member h and y in X_h,

    ||y-x||_infinity
      <= s_h/(32n)+s_h+r_a+r_a
      <= (2+c0) R,

where R=max_a r_a. Consequently the FULL represented receiver union has volume at most (2+c0)^n d_max. The original member parents are not known to contain x. Reapplying the coefficient c from a single clique would discard two genuine displacement steps.

For a descending-radius greedy representative r, each removed member has s_h<=s_r and intersects A_r. Thus

    ||y-y_r||_infinity <= s_r+c0 s_h <=(1+c0)s_r.

The exact directly available star envelope is (1+c0)^n d_r. Members of a star need not have a common point. Greedy representatives have disjoint interiors and are original variables, so sum_r d_r<=P0 is valid. These geometry/packing claims are genuine upper certificates and preserve the complete receiver volume.

## 3. Strong reserve and fee

For the largest actual representative, every real source parent in its fixed near pool has volume at least d_rep. Let M(t) be its minimum-mass prefix. Since T>3tau/8-2c>c in the stipulated n>=256 regime, t=c is available. The elementary initial mass bound M(c)>=c d_rep and the supplied growth inequality give

    U_J=M(T)>=M(c)exp((T-c)/c)
               >=c d_rep exp(T/c-1).

The same conclusion follows from the actual common-point cumulative owner capacity H(u)<=min(cu,U_J), with d_min>=d_rep. The branch U_J<=c d_rep would imply T<=c and is excluded by the strong reserve.

Combining this lower bound for available source mass with the receiver envelope is an UPPER price for that receiver union:

    V <= E_b(n) U_J,
    E_b(n)=[(b+c0)^n/c] exp(3-3tau/(8c)),
    log E_b(n)=n log(b+c0)-log c+3-3tau/(8c).

Here b=2 is the double-clique union and b=1 is one radius-greedy star. For a genuine single clique, the sharper V_C<=exp(3-3tau/(8c))U_J follows. Strict reserve inequalities can harmlessly be weakened to these non-strict displayed bounds.

Since c0 tends to one, c tends to exp(1/32), and tau=16384 sqrt(n),

    log E_b(n)/n -> log(b+1)>0.

Thus these explicit certificates are not bounded uniformly over all dimensions. A small coefficient in moderate dimensions does not establish all-dimension absorption. Conversely an unbounded upper certificate is neither a realized lower bound for V/U_J nor a counterexample to the desired packing theorem.

## 4. Capture and cumulative source reuse

The largest target's source pool shares its actual witness, but target-parent intersection does not imply a fixed-rate capture of another target's actual witness. Neither a star nor the double-clique condition supplies the R673 detection hypothesis for all represented receiver pieces. This missing implication is correctly identified rather than assumed.

Even separate legal local prices cannot be summed as independent reserves if the same genuine source owners occur in multiple groups. Disjoint original representatives certify their own packing objective, not a uniform bound on those repeated source debits. No cumulative source-reuse estimate is proved in either file. The stated nonclosure is therefore accurate and does not claim an impossibility theorem for other legal allocations.

## 5. Numerical/report verification boundary

The finalized REPORT was read in full and compared with the independent derivations above. Its geometry, source-reserve deduction, fee formulas, asymptotic direction and unproved-global-budget status agree. The report explicitly defines a=32n, resolving the author-note notation ambiguity. CONTINUE.md was also read for consistency, without reopening earlier records.

Read ENVELOPE_CHECK.py and ENVELOPE_RESULT.json without executing them. The script evaluates exactly F_b above using Arb, retains finite-n c, and declares an unresolved interval sign to be a failure. The JSON records Python 3.12.14, python-flint 0.9.0, 256-bit working precision, and the matching script SHA-256 above. Its twenty probes match the report's dimensions and sign distribution: six initial negative signs, four negative and four positive stress-stage signs, and six expanded positive signs.

The recorded adjacent sign pairs are b=1 at 73808781/73808782 and b=2 at 29381233/29381234. The four logged 512-bit rechecks retain those negative/positive signs. The report correctly says adjacent certified sign changes and makes no first-root or unique-root claim. The bisection procedure only needs maintained opposite-sign endpoints for this stated conclusion. These are consistency and source inspections of the main agent's saved computational evidence; this reviewer did not independently rerun the numerical calculations.

Such scalar probes concern explicit upper-certificate costs, not actual admissible near-receiver realizations. The analytic all-dimension divergence is separately proved by the displayed limit. Historical source checks, literature abstract accuracy, and the inherited finite-family/all-input recovery were outside this bounded audit and were not independently recertified.

## Final disposition

PASS for the stated actual-parent envelopes and packing construction, the strong-reserve mass deduction, the two conservative upper-certificate fees, their asymptotic nonuniformity, and the report/script/result interpretation. The inherited single-clique fact is not counted as new progress. Joint capture/alignment and cumulative source reuse remain unpaid. No general root bound, counterexample, realized lower bound or impossibility theorem follows from this review.
