# R676 S2 — target-clique compression and its nonclosure across scales

**Bounded outcome.** A real target-parent clique can be paid without its internal logarithmic scale factor: its whole actual receiver volume is at most c times its largest ORIGINAL target parent volume, so one original packing variable pays that clique. However this compression is not closed under another Helly step. A clique of the representative parents need not be a clique of all the represented targets. The proved second-step receiving envelope costs (2+c0)^n.

Even using the FULL strong near-source reserve of the largest representative, the resulting explicit joint fee is only

    [(2+c0)^n/c] exp(3-3tau/(8c)) U_{J_*}.                   (1)

Its logarithm has the unabsorbable term n log(2+c0)-O(sqrt(n)). This is the size of this upper certificate, NOT a lower bound on the actual optimal packing or on realized source reuse. No admitted counterexample or impossibility theorem is asserted.

No complete improvement of Vrem<=Ctau P0 is proved. The precise new bridge/stopping point is that real source growth prices one representative, while Helly controls only representative intersection; it does not provide common sampled-source capture for the other represented receivers. The note spells out that full fee rather than relabeling the LP or repeating the generic clique CDF as progress.

Only this assigned file is written. No new child, Git, PDF, abstract counterexample scan or numerical job is introduced. Original parents, owners, q and actual receiver measures remain unchanged.

## 1. Exact target-clique packing, retaining all receiver volume

Let C be any actual collection of remaining targets whose original parents A_h have a common point x. Axis-parallel box Helly permits the same conclusion if these target parents are pairwise intersecting. Let h_* have maximum radius R in C; put d_*=(2R)^n and V_C=sum_{h in C}|X_h|.

For y in X_h subset B_h,

    ||y-x||_infinity<=s_h/a+s_h=c0s_h<=c0R.

The actual X_h are disjoint. Thus

    union_{h in C}X_h subset Q(x,c0R),
    V_C<=c d_*.                                             (2)

This is a consequence of the given common-point volume geometry. The additional packing step is explicit: put weight V_C/(c d_*) on the ORIGINAL target parent A_{h_*}, and zero elsewhere. That weight is at most one, is feasible on all space, and has objective exactly V_C/c. The new weight is not constrained by q_{h_*}; a lost target can have q_{h_*}=0 without affecting feasibility.

Thus bounding sum_h |X_h|/d_h over this clique is unnecessary for paying its whole volume. Its generic log-range first-moment bound can be bypassed by choosing a different original packing variable.

For an actual partition into such cliques C_a, if their chosen representative parents have pairwise disjoint interiors, the same weights combine into one feasible original-family packing and pay the entire Vrem/c. No such partition with disjoint representatives has been constructed for the full input. This special implication is not a theorem that the original task is solved.

## 2. What Helly does not preserve after compression

Consider any actual partition into target cliques C_a and largest-radius representatives h_a of radius r_a. Suppose the representative parents themselves contain a common point x. For each original clique choose a common point w_a of its FULL member parents. This w_a is a clique point, not an asserted saturation witness.

Let R=max_a r_a, and choose h_* attaining it. For a target h in C_a and y in its real X_h,

    ||y-x||_infinity
      <=||y-y_h||+||y_h-w_a||+||w_a-y_{h_a}||+||y_{h_a}-x||
      <=s_h/a+s_h+r_a+r_a
      <=(2+c0)R.

Consequently the only immediate joint receiving envelope is

    union_a union_{h in C_a}X_h subset Q(x,(2+c0)R),
    sum_a V_{C_a}<=(2+c0)^n d_*.                            (3)

The key distinction is exact: every representative contains x, but an arbitrary member of C_a is only known to contain w_a. There is no established common point for ALL member parents, so (2) cannot be applied again with coefficient c. Representative Helly alone does not justify merging all the represented cliques at the first-step price.

Likewise the standard descending-radius independent-parent selection creates stars: a removed parent intersects its selected representative, but the other removed parents need not intersect one another. Its true receiving envelope is Q(y_rep,(1+c0)R), of volume (1+c0)^n d_rep. Calling those stars cliques would lose a real exponential fee.

These are actual-parent geometric implications. No arbitrary graph or nonadmitted fixture is substituted for the frozen near-target geometry.

## 3. Apply the strong REAL source reserve, not just generic clique volume

The largest representative h_* is itself an actual remaining target. Its retained fixed-range population satisfies

    T_*:=T(J_{h_*})>3tau/8-2c,                              (4)
    U_{J_*}=sum_{i in J_{h_*}}|F_i|.

Every parent in this source population contains the actual saturation witness z_{h_*}, its radius is at least the target radius R, and its owner is genuine. The common-point cumulative owner bound gives

    log(U_{J_*}/(c d_*))>=T_*/c-1,
    U_{J_*}>=c d_* exp(T_*/c-1).                            (5)

For completeness, this is the source-layer consequence H(u)<=min(cu,U_{J_*}) with all source volumes at least d_*. The large load ensures U_{J_*}>c d_*, so the logarithmic branch used in (5) is valid.

For one original target clique, (2) and (5) give the strong LOCAL bridge

    V_C<=exp(1-T_*/c) U_{J_*}
       <=exp(3-3tau/(8c)) U_{J_*}.                          (6)

This uses the actual strong near reserve, not merely T>nu, and retains its positive tau/16-2c slack.

For the full collection whose representatives only form a clique, combine (3) and (5) instead:

    sum_a V_{C_a}
      <=[(2+c0)^n/c]exp(1-T_*/c) U_{J_*}
      <=[(2+c0)^n/c]exp(3-3tau/(8c)) U_{J_*}.              (7)

This proves (1), including the whole represented receiver collection with no count of its cliques or targets. It does not sum a separate upper price for every C_a.

The coefficient in (7) is not bounded uniformly in n: c is bounded above and below, c0 tends to one, and tau=16384sqrt(n). Thus n log(2+c0) dominates the negative constant times sqrt(n) as n grows. The strong source reserve cannot absorb THIS particular geometric envelope throughout the all-dimension problem.

Again, this assesses the upper certificate (7). It does not imply that the left side is actually that large or that the optimal packing cannot improve on it.

## 4. The missing original-geometry statement

To improve (7) using the allowed short-sample tool, the actual represented receivers would need a proved joint detection relation with an affordable common-point source population. The population J_{h_*} only guarantees that its parents contain z_{h_*}. Its being associated with the largest representative does not show that it contains the saturation witnesses z_h of the other clique members, or that those members receive any fixed positive fraction of its rate.

Representative intersection x does not repair this: x need not lie in every member parent, and it is unrelated to those different saturation witnesses in the way required by R673 joint detection. Sources for different members may differ. Importing a positive overlap fraction here would be an additional unproved assumption.

Actual center admission and the high-witness/low-entire-B_h condition have not been used to derive the required alignment. They remain part of the contract, but neither says that two cliques with intersecting representatives have source pools with a fixed-rate overlap. I have not inferred this from a graph clique, a source-mass inequality, or a scalar reserve.

This is why the source-growth saving in (6) cannot simply be propagated through repeated target-clique compression. A valid next step would need a new actual cube-geometric bound for this cross-clique alignment or a different simultaneous original-family packing. No Hall/dual equivalence is substituted for such a bound.

## 5. Success criterion and stop

The proposed route was meant to remove cross-scale losses by charging actual target cliques to original largest parents, then combining those choices without requiring uniform source-column bounds. It DOES remove a single clique's scale-span cost exactly. But the compression is not stable under representative overlap; its computed all-receiver fee is (7), which grows exponentially in n after the available source reserve is spent.

Therefore this is a decision-changing obstacle for this particular scale-coupling scheme, not a complete global budget improvement and not a new restricted-function theorem. The given generic clique CDF is not counted as a new result. The same real Vrem, all source owners and all original packing variables have been retained, and the precise missing alignment has been isolated.

No numerical exploration was warranted for that analytic missing step. This bounded task ends here; the general complete packing objective is still open.
