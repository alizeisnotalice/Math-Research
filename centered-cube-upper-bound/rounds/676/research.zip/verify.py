from pathlib import Path
import ast,hashlib,json,re,collections
p=Path(__file__).resolve().parent
for n in ('ENVELOPE_CHECK.py','verify.py'):ast.parse((p/n).read_text())
r=json.loads((p/'ENVELOPE_RESULT.json').read_text())
assert r['precision_bits']==256 and len(r['probes'])==20 and len(r['brackets'])==2 and len(r['critical_rechecks'])==4
assert collections.Counter((z['stage'],z['sign']) for z in r['probes'])=={('initial',-1):6,('stress',-1):4,('stress',1):4,('expanded',1):6}
assert all(z['pass'] for k in ('probes','brackets','critical_rechecks') for z in r[k])
for z in r['brackets']:
 assert z['positive_n']==z['negative_n']+1
 for key,sign in [('negative_n',-1),('positive_n',1)]:
  assert any(t['n']==z[key] and t['base_offset']==z['base_offset'] and t['sign']==sign and t['precision_bits']==512 for t in r['critical_rechecks'])
assert r['script_sha256']==hashlib.sha256((p/'ENVELOPE_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
assert s.count(chr(92)+'begin{document}')==s.count(chr(92)+'end{document}')==1
review=(p/'S3_REVIEW.md').read_text()
for n in ('REPORT.tex','A1_GLOBAL_PACKING.md','S2_SCALE_COUPLING.md','ENVELOPE_CHECK.py','ENVELOPE_RESULT.json'):
 assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,n
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity and recorded scalar signs, not a geometric theorem or mathematical proof checker','manifest_checked':(p/'MANIFEST.json').exists()}))
