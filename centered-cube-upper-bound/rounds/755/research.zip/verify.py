from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from fractions import Fraction as F
from itertools import combinations, permutations, product
from math import isqrt, prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION=256
ALPHA=F(7,8)
RADIUS_SPLIT=F(5,8)


def point(*vals):
    return tuple(map(F,vals))


def exact_sum(vals):
    return sum(vals,F(0))


def ball(x):
    x=F(x)
    return arb(fmpq(x.numerator,x.denominator))


def encode(x):
    x=F(x)
    if x.numerator.bit_length()+x.denominator.bit_length()<=420:
        return str(x)
    return ball(x).str(23)


def vol(A):
    return prod(max(F(0),r-l) for l,r in A)


def box(center,r):
    return tuple((c-r,c+r) for c in center)


def meet(*boxes):
    return tuple((max(l for l,_ in row),min(r for _,r in row))
                 for row in zip(*boxes))


def overlap(*boxes):
    return vol(meet(*boxes))


def inside(A,z):
    assert not (all(l<=x<=r for (l,r),x in zip(A,z))
                and any(x in (l,r) for (l,r),x in zip(A,z)))
    return all(l<x<r for (l,r),x in zip(A,z))


def radius_region(r):
    return "below_test_5_over_8" if r<RADIUS_SPLIT else "at_least_test_5_over_8"


def native_axis(S,a,fraction):
    number=fraction*a
    assert number.denominator==1 and int(number)%2==0
    N=int(number)
    centers=[S*(-fraction+F(2*j+1,a)) for j in range(N)]
    assert centers[0]-S/a==-fraction*S and centers[-1]+S/a==fraction*S
    return centers


def axis_fraction(y,S):
    return max(F(0),min(F(1),y+S)-max(F(-1),y-S))/2


def native_shell(n,a,S,gamma,beta):
    outer=native_axis(S,a,gamma)
    inner=native_axis(S,a,beta)
    first=(len(outer)-len(inner))//2
    assert outer[first:first+len(inner)]==inner
    amount=len(outer)**n-len(inner)**n
    # All remaining closed cores tile the outer cube minus the inner cube a.e.
    outer_fractions=[axis_fraction(y,S) for y in outer]
    inner_fractions=[axis_fraction(y,S) for y in inner]
    weighted_q=sum(outer_fractions)**n-sum(inner_fractions)**n
    # Extreme labels actually attained by the native grid.
    first_outside=inner[-1]+2*S/a
    assert first_outside in outer and first_outside not in inner
    q_min=min(outer_fractions)**n
    q_max=axis_fraction(first_outside,S)*max(outer_fractions)**(n-1)
    assert 0<q_min<=weighted_q/amount<=q_max<1
    return {"S":S,"count":amount,"q_sum":weighted_q,
            "q_min":q_min,"q_max":q_max,
            "common_half_width":(1-gamma+F(1,a))*S,
            "outer_axis_cells":len(outer),"inner_axis_cells":len(inner)}


def explicitly_check_two_dimensional_shell():
    # Independent small actual geometry verifies the tensor/native count.
    n,a,S=2,128,F(5,4)
    gamma,beta=F(31,32),F(25,32)
    upper=native_axis(S,a,gamma)
    lower=set(native_axis(S,a,beta))
    geometry=native_shell(n,a,S,gamma,beta)
    small=box((F(0),)*n,F(1))
    price_patch=box((F(0),)*n,F(1,32))
    total_q=F(0)
    seen=0
    for xy in product(upper,repeat=n):
        if all(x in lower for x in xy):
            continue
        parent=box(xy,S)
        assert overlap(parent,price_patch)==vol(price_patch)
        assert not overlap(box(xy,S/a),box((F(0),)*n,F(1,a)))
        total_q+=overlap(parent,small)/vol(small)
        seen+=1
    assert seen==geometry["count"] and total_q==geometry["q_sum"]
    return {"dimension":n,"a":a,"directly_enumerated_actual_large_parents":seen,
            "total_true_overlap_probability":str(total_q)}


def shell_pressure(n):
    L=isqrt(n)
    assert L*L==n
    a=32*n
    gamma=1-F(1,8*n)
    beta=max(F(25,32),1-F(1,n))
    step=1+F(1,n)
    assert gamma<step*beta
    layers=[native_shell(n,a,step**j,gamma,beta) for j in range(1,2*L+2)]
    assert beta*layers[0]["S"]>F(1,a)
    physical_small=F(2**n)
    v_small=physical_small/a**n
    central_radius=F(1,8*n)
    patch_fraction=central_radius**n
    extra_strength=F(L,2)  # added value in units of d_s
    m_small=(1+extra_strength)*physical_small
    patch_price=physical_small*(extra_strength+patch_fraction)
    prob_patch=patch_price/m_small
    intersection_half=min(t["common_half_width"] for t in layers)
    assert central_radius<intersection_half<1
    # The price is Lebesgue on one enclosing ambient cube, plus a uniform patch mass.
    ambient_radius=2*layers[-1]["S"]
    assert all(ambient_radius>(1+gamma)*t["S"] for t in layers)
    price_total=(2*ambient_radius)**n+extra_strength*physical_small
    for t in layers:
        S=t["S"]
        d=(2*S)**n
        weight=d/a**n
        m=d+extra_strength*physical_small
        common_part=extra_strength+(1-ALPHA)*patch_fraction
        p_sum=(ALPHA*t["q_sum"]+common_part*t["count"])/(1+extra_strength)
        p_unmasked_sum=(t["q_sum"]+extra_strength*t["count"])/(1+extra_strength)
        # Every receiver cuts the small parent, and the masked p is strictly above q.
        assert (ALPHA*t["q_max"]+common_part)/(1+extra_strength)>t["q_max"]
        assert 1+extra_strength/t["q_max"]>L
        assert ball(1/S)>(arb(n).log()/n).sqrt()/64
        t.update(d=d,v=weight,m=m,a_raw=weight/m,p_sum=p_sum,p_unmasked_sum=p_unmasked_sum,
                 p_min=(ALPHA*t["q_min"]+common_part)/(1+extra_strength),
                 p_max=(ALPHA*t["q_max"]+common_part)/(1+extra_strength))
        assert t["count"]*weight == (gamma**n-beta**n)*d

    assert all(b["d"]>2*a_layer["d"] for a_layer,b in zip(layers,layers[1:]))
    peak_raw=exact_sum(t["count"]*t["a_raw"] for t in layers)
    assert L<peak_raw and ALPHA*peak_raw<L
    V=v_small+exact_sum(t["count"]*t["v"] for t in layers)
    P0=layers[-1]["d"]  # all parents contain the same open central patch
    by_caps=[]
    for G,eta in ((F(L),F(1,2)),(F(L+1),F(1))):
        lam_s=F(3,4)*v_small/(G*m_small)
        F_peak=lam_s+eta*peak_raw/G
        assert F_peak<1 and V/G<=price_total
        assert lam_s*m_small <= v_small/G
        outline=[]
        for role,omega,role_eta in (
                ("small_is_source",lam_s*m_small,F(1)),
                ("large_is_source",v_small/G,eta)):
            by_layer=[]
            for t in layers:
                regional_peak=role_eta*t["count"]*t["a_raw"]
                a_label=role_eta*t["a_raw"]
                if role=="large_is_source":
                    assert a_label*t["m"]<=t["v"]
                c=omega*a_label
                original_flow=c*t["p_sum"]
                # Independently integrate the full price using μ restricted to I and P.
                inside_patch=t["count"]*a_label*patch_price/m_small
                outside_patch=ALPHA*a_label*physical_small*(t["q_sum"]-t["count"]*patch_fraction)/m_small
                assert original_flow==omega*(inside_patch+outside_patch)
                assert inside_patch==regional_peak*prob_patch
                assert regional_peak<1<L
                by_layer.append({
                    "r":1/t["S"],"peak":regional_peak,"T_masked":original_flow,
                    "T_unmasked":c*t["p_unmasked_sum"],"per_label_c":c,
                    "per_label_min_c_times_p":c*t["p_min"],"per_label_max_c_times_p":c*t["p_max"],
                })
            peak=exact_sum(x["peak"] for x in by_layer)
            assert peak<=peak_raw and ALPHA*peak<L
            if role=="large_is_source":
                assert peak<=G*F_peak<=G
            T=exact_sum(x["T_masked"] for x in by_layer)
            T0=exact_sum(x["T_unmasked"] for x in by_layer)
            assert T0>=T
            paid_excess=omega*prob_patch*max(F(0),peak-L)
            paid_to_threshold=T-paid_excess
            assert paid_to_threshold==T-omega*prob_patch*peak+omega*prob_patch*min(F(L),peak)
            if role=="small_is_source" or eta==1:
                assert paid_excess>0
            else:
                assert paid_excess==0
            groups={}
            for x in by_layer:
                group=radius_region(x["r"])
                groups.setdefault(group,[]).append(x)
            assert len(groups)==2
            bracket=[]
            for group,rows in groups.items():
                regional_peak=exact_sum(x["peak"] for x in rows)
                assert regional_peak<L
                # Split the actual positive part proportionally at the common price patch.
                one_budget_share=paid_excess*regional_peak/peak
                bracket.append({
                    "test_range":group,"actual_T":encode(exact_sum(x["T_masked"] for x in rows)),
                    "unmasked_T":encode(exact_sum(x["T_unmasked"] for x in rows)),
                    "peak_U_if_range_considered_alone":encode(regional_peak),
                    "false_reset_positive_part":"0","actual_common_positive_part_share":encode(one_budget_share),
                })
            assert sum(exact_sum(x["peak"] for x in rows)/peak for rows in groups.values())==1
            assert sum(exact_sum(x["T_masked"] for x in rows) for rows in groups.values())==T
            assert paid_excess<=T and paid_to_threshold+paid_excess==T
            outline.append({
                "role":role,"omega_s":encode(omega),"global_peak_U_on_price_patch":encode(peak),
                "outside_patch_U_upper_bound":encode(ALPHA*peak),
                "T0_unmasked_test_star":encode(T0),"T_current_test_star":encode(T),
                "root_threshold_L":L,
                "omega_integral_min_U_L":encode(paid_to_threshold),
                "omega_integral_positive_U_minus_L":encode(paid_excess),
                "positive_part_over_actual_T":encode(paid_excess/T),
                "positive_part_over_L_times_total_price":encode(paid_excess/(L*price_total)),
                "sum_of_per_dyadic_layer_reset_positive_parts":"0",
                "two_declared_relative_radius_ranges":bracket,
                "original_flow_by_layer":[{key:encode(value) for key,value in x.items()} for x in by_layer],
            })
        assert sum(F(x) for x in (lam_s*m_small,v_small/G))<=(1+1)*price_total
        by_caps.append({
            "chosen_cap_G_not_extremal_G":str(G),"K":"1","eta_big_multiplier_of_cap":str(eta),
            "exact_F_maximum_at_shared_patch":encode(F_peak),
            "small_original_source_weight":encode(lam_s),"both_roles":outline,
        })
    return {
        "dimension":n,"a":a,"L":L,"number_of_genuine_large_scales":len(layers),
        "test_relative_radius_split":str(RADIUS_SPLIT),
        "one_finite_geometric_family_preterminal":True,
        "centrally_added_price_ratio_to_d_s":str(extra_strength),
        "whole_price_S":encode(price_total),"owner_total_V":encode(V),"P0":encode(P0),
        "true_small_price_m_s":encode(m_small),"price_patch_radius":str(central_radius),
        "true_rho_s_mass_of_patch":encode(prob_patch),
        "all_large_parents_common_half_width":encode(intersection_half),
        "all_large_common_overlap_fraction_of_A_s":encode(intersection_half**n),
        "outer_taper_b":str(ALPHA),
        "masked_p_above_geometric_q_and_absolute_density_above_sqrt_n_for_all_edges":True,
        "joint_ownership":"all native shrunken cores are disjoint a.e., with exact complete ownership",
        "each_layer":[{k:encode(v) for k,v in t.items()} for t in layers],
        "roles_with_original_normalization":by_caps,
    }


def pressure_from_cells(name,n,parents,owners,cells,eta,b,expected_p=None):
    K,G=F(1),F(2)
    assert all(not overlap(A,B) for A,B in combinations(owners,2))
    d=[vol(A) for A in parents]
    v=[vol(A) for A in owners]
    m=[exact_sum(price for price,membership in cells if j in membership) for j in range(len(d))]
    total_price=exact_sum(row[0] for row in cells)
    assert all(x>=y for x,y in zip(m,d)) and m[0]>d[0] and sum(v)/G<=total_price
    lam=[e*K*vj/(G*mj) for e,vj,mj in zip(eta,v,m)]
    assert sum(lam)<1 and all(x*y <= K*z/G for x,y,z in zip(lam,m,v))
    indices=range(1,len(d))
    results=[]
    for role,omega,a in (("small_is_source",lam[0]*m[0],[v[j]/m[j] for j in indices]),
                         ("large_is_source",K*v[0]/G,[G*lam[j]/K for j in indices])):
        direct=F(0)
        largest=F(0)
        for k,(price,membership) in enumerate(cells):
            if 0 not in membership:
                continue
            W=exact_sum(a[j-1]*b[role][j-1][k] for j in indices if j in membership)
            largest=max(largest,W)
            direct+=omega*price*W/m[0]
        assert ball(largest)<arb(n).sqrt()
        ratios=[]
        T=F(0)
        T0=F(0)
        range_mass={}
        for j in indices:
            raw=exact_sum(price for price,I in cells if 0 in I and j in I)
            price=exact_sum(value*b[role][j-1][k] for k,(value,I) in enumerate(cells)
                           if 0 in I and j in I)
            c=omega*a[j-1]
            p=price/m[0]
            if expected_p:
                assert p==expected_p[j-1]
            if role=="small_is_source":
                original=lam[0]*v[j]*price/m[j]
            else:
                original=lam[j]*v[0]*price/m[0]
            assert c*p==original
            T+=original
            T0+=c*raw/m[0]
            r=(d[0],d[j])
            # Compare r=(d_s/d_L)^(1/n) to the fixed rational split directly.
            branch="below_test_5_over_8" if r[0]<r[1]*RADIUS_SPLIT**n else "at_least_test_5_over_8"
            range_mass[branch]=range_mass.get(branch,F(0))+original
            ratios.append({"j":j,"c":encode(c),"p":encode(p),"flow_c times p":encode(original),
                           "m_s":encode(m[0]),"m_L":encode(m[j]),"q":str(overlap(parents[0],parents[j])/d[0])})
        assert direct==T and sum(range_mass.values())==T
        results.append({
            "role":role,"selected_pair_records":ratios,"T_current":encode(T),
            "T0_unmasked_test_pairs":encode(T0),"peak":encode(largest),
            "omega_integral_min_U_L":encode(T),"actual_positive_part":"0",
            "T_by_test_radius_range":{key:encode(value) for key,value in range_mass.items()},
        })
    return {"original_configuration":name,"dimension":n,"m":list(map(encode,m)),"d":list(map(encode,d)),
            "whole_price_S":encode(total_price),"roots_in_arb":arb(n).sqrt().str(23),
            "roles":results}


def earlier_753():
    n,a=2,64
    locations=(
        (point(0,0),F(15,16)),(point("1/16",0),F(1)),
        (point("1/4","-1/8"),F(17,16)),(point("-5/16","3/16"),F(9,8)),
        (point(0,"3/8"),F(17,16)),(point("3/8","-3/8"),F(3,2)),
        (point("-9/16","1/8"),F(13,8)),
    )
    parents=[box(y,s) for y,s in locations]
    cores=[box(y,s/a) for y,s in locations]
    support=(
        (point("-7/8","-7/8"),F(2)),(point("7/8","7/8"),F(3)),
        (point("-7/8","7/8"),F(4)),(point("7/8","-7/8"),F(1)),
        (point(0,0),F(1)),(point(1,0),F(2)),(point(-1,"1/8"),F(2)),
    )
    cells=[(price,frozenset(i for i,R in enumerate(parents) if inside(R,z))) for z,price in support]
    B={
        "large_is_source": (
             ("1","7/8","1/2","1","1/4"),("0","1/2","1/3","1/4","1/4"),
             ("1/3","0","1/5","1/4","1/2"),("3/4","1/4","1/2","0","1"),
             ("1/2","1/3","1/4","0","1"),("5/8","1","1/3","3/4","1/2"),
        ),
        "small_is_source": (
             ("1","1","1","1","3/4"),("0","3/4","1/6","1/2","1/4"),
             ("1/2","0","3/5","1/4","1"),("3/4","1/2","1/4","0","1/4"),
             ("1/2","3/4","0","1/2","1"),("1","1/3","1/2","5/8","1/4"),
        ),
    }
    masks={role:[tuple(map(F,vals))+(F(0),F(0)) for vals in entries] for role,entries in B.items()}
    return pressure_from_cells("R753 original one-small six-large rational configuration",
                               n,parents,cores,cells,[F(i+2,i+3) for i in range(7)],masks)


def earlier_754():
    n,a=5,160
    z0=(F(1,8),)+(F(0),)*(n-1)
    def translate(tail):
        return tuple(x+y for x,y in zip(z0,tail))
    centers=[z0,translate((F(1),)*(n-1)+(F(0),)),translate((F(5,4),)*(n-1)+(F(0),))]
    radii=(F(1),F(5,4),F(5,4))
    parents=[box(y,s) for y,s in zip(centers,radii)]
    cores=[box(y,s/a) for y,s in zip(centers,radii)]
    head=(F(1,2),F(-1,8),F(-1,2))
    mass=((F(1,4),F(1,10),F(1,20)),(F(1,4),F(1,10),F(1,4)))
    M=10*vol(parents[1])
    patches=[]
    b0,b1=[],[]
    for g,tail in enumerate((F(-1,4),F(1,4))):
        for site,u in enumerate(head):
            patches.append((box(translate((u,)*(n-1)+(tail,)),F(1,32)),mass[g][site]*M))
            b0.append(F(1,2) if site==1 else F(1))
            b1.append(F(3,4))
    outside=translate((F(5,4),)+(F(1,2),)*(n-2)+(F(0),))
    patches.append((box(outside,F(1,32)),M/10))
    b0.append(F(0))
    b1.append(F(0))
    cells=[]
    for patch,price in patches:
        bounds=[overlap(P,patch) for P in parents]
        assert all(x in (0,vol(patch)) for x in bounds)
        cells.append((price,frozenset(i for i,x in enumerate(bounds) if x)))
    b={name:[b0,b1] for name in ("small_is_source","large_is_source")}
    return pressure_from_cells("R754 coherent shared price with original nonbinary taper",
                               n,parents,cores,cells,(F(3,4),F(1,2),F(3,4)),b,
                               expected_p=(F(3,5),F(3,8)))


def continuous_rank_cdfs(x, y, P, Q):
    """Integrate the two jittered CDFs exactly, one rank interval at a time."""
    F0 = G0 = D = left = right = F(0)
    segments = []
    for rank in sorted(set(x) | set(y)):
        p = exact_sum(weight for rank_x, weight in zip(x, P) if rank_x == rank)
        q = exact_sum(weight for rank_y, weight in zip(y, Q) if rank_y == rank)
        base, slope = F0 - G0, p - q
        difference_integral = (p + q) * (base**2 + base*slope + slope**2/3)
        D += difference_integral
        segments.append({
            "rank": rank,
            "F_start": str(F0),
            "G_start": str(G0),
            "P_mass": str(p),
            "Q_mass": str(q),
            "D_contribution": str(difference_integral),
        })
        # Simpson's three values integrate the cubic separation densities exactly.
        for t, weight in ((F(0), F(1, 6)), (F(1, 2), F(2, 3)), (F(1), F(1, 6))):
            Ft, Gt = F0 + t*p, G0 + t*q
            left += 2*weight*q*Ft**2*(1-Gt)
            right += 2*weight*p*Gt**2*(1-Ft)
        F0, G0 = F0 + p, G0 + q
    assert F0 == G0 == 1
    return D, left, right, segments


def rank_checks():
    cases = (
        ((2,2),(2,2),(F(1,3),F(2,3)),(F(2,5),F(3,5))),
        ((1,2,5),(0,2,6),(F(1,4),F(1,2),F(1,4)),(F(1,4),F(1,2),F(1,4))),
        ((2,4,8),(1,3,6),(F(1,2),F(1,3),F(1,6)),(F(1,4),F(1,4),F(1,2))),
        ((0,2,2,7),(0,2,7),(F(1,5),F(1,4),F(1,4),F(3,10)),(F(1,5),F(1,2),F(3,10))),
    )
    result = []
    for x, y, P, Q in cases:
        u = [[F((i+2*j+1)%7,8) for j in range(len(y))] for i in range(len(x))]
        H = exact_sum(P[i]*Q[j]*u[i][j] for i,j in product(range(len(x)),range(len(y))))
        marginals = [F(0)]*4
        jittered_marginals = [F(0)]*4
        left = right = ties = block = block_prod = F(0)
        ord_left = ord_right = ord_prod = jittered_mass = F(0)
        enumerated_orders = 0
        for a,b,c,d in product(range(len(x)),range(len(x)),range(len(y)),range(len(y))):
            mass = P[a]*P[b]*Q[c]*Q[d]
            edges = (u[a][c],u[a][d],u[b][c],u[b][d])
            A = max(x[a],x[b]) <= min(y[c],y[d])
            B = max(y[c],y[d]) <= min(x[a],x[b])
            for k, value in enumerate(edges):
                marginals[k] += mass*value
            left += mass*A
            right += mass*B
            ties += mass*(A and B)
            block += mass*(A or B)
            if A or B:
                assert sum(edges) <= 3+prod(edges)
                block_prod += mass*prod(edges)
            ranks = (x[a],x[b],y[c],y[d])
            order_options = [
                tuple(permutations(i for i, value in enumerate(ranks) if value == rank))
                for rank in sorted(set(ranks))
            ]
            order_mass = mass/prod(map(len,order_options))
            for pieces in product(*order_options):
                order = tuple(i for piece in pieces for i in piece)
                enumerated_orders += 1
                jittered_mass += order_mass
                for k, value in enumerate(edges):
                    jittered_marginals[k] += order_mass*value
                if max(order[:2]) < 2:
                    assert A
                    ord_left += order_mass
                    ord_prod += order_mass*prod(edges)
                if min(order[:2]) >= 2:
                    assert B
                    ord_right += order_mass
                    ord_prod += order_mass*prod(edges)
        assert marginals == jittered_marginals == [H]*4 and jittered_mass == 1
        assert block == left+right-ties

        def median(values, weights):
            return min(v for v in values if exact_sum(w for z,w in zip(values,weights) if z <= v) >= F(1,2))

        xmed, ymed = median(x,P), median(y,Q)
        if xmed <= ymed:
            witness = exact_sum(w for z,w in zip(x,P) if z <= xmed)**2*exact_sum(w for z,w in zip(y,Q) if z >= ymed)**2
        else:
            witness = exact_sum(w for z,w in zip(y,Q) if z <= ymed)**2*exact_sum(w for z,w in zip(x,P) if z >= xmed)**2
        assert block >= witness >= F(1,16)
        coarse_upper = F(63,64)+block_prod/4
        assert H <= 1-block/4+block_prod/4 <= coarse_upper

        D, integrated_left, integrated_right, segments = continuous_rank_cdfs(x,y,P,Q)
        assert (ord_left,ord_right) == (integrated_left,integrated_right)
        p_ord = ord_left+ord_right
        assert p_ord == F(1,3)+D
        assert D >= 0 and p_ord <= block and ord_prod <= block_prod
        direct_upper = F(11,12)-D/4+ord_prod/4
        assert direct_upper == 1-p_ord/4+ord_prod/4
        assert H <= direct_upper < min(F(1),coarse_upper)
        result.append({
            "source_ordered_volume_ranks": x,
            "receiver_ordered_volume_ranks": y,
            "P": list(map(str,P)),
            "Q": list(map(str,Q)),
            "u": [list(map(str,row)) for row in u],
            "H": str(H),
            "probability_block": str(block),
            "median_witness_probability": str(witness),
            "both_included_at_rank_equality": str(ties),
            "block_weighted_product": str(block_prod),
            "R755_upper_bound": str(coarse_upper),
            "explicit_rank_order_permutations_enumerated": enumerated_orders,
            "order_block_P_then_Q": str(ord_left),
            "order_block_Q_then_P": str(ord_right),
            "order_block_probability": str(p_ord),
            "continuous_CDF_squared_difference_D": str(D),
            "continuous_CDF_segments": segments,
            "ordered_block_weighted_product": str(ord_prod),
            "H_improved_direct_upper_bound": str(direct_upper),
        })
    assert result[-1]["continuous_CDF_squared_difference_D"] == "0"
    return result


def report():
    ctx.prec=PRECISION
    script=Path(__file__)
    return {
        "schema":"r755-real-positive-part-overload-verification-v1",
        "runtime":{
            "python":platform.python_version(),"python_executable":sys.executable,
            "python_flint":flint.__version__,"arb_precision_bits":PRECISION,
            "script_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands":"directory containing verify.py and verify.json",
            "write_command":[sys.executable,"-B",script.name,"--out","verify.json"],
            "rerun_command":[sys.executable,"-B",script.name,"--check","verify.json"],
        },
        "actual_preterminal_overload_stars":[shell_pressure(n) for n in (4,16)],
        "direct_small_geometry_crosscheck":explicitly_check_two_dimensional_shell(),
        "reconstructed_original_price_and_m_stress":[earlier_753(),earlier_754()],
        "finite_rank_2_by_2_marginal_and_union_checks":rank_checks(),
        "scope":[
            "The displayed positive examples are genuine unique-owner geometry and actual finite-price capped packings, without the complete R754 terminal filter.",
            "The test cap is K=1, with G in {2,3} at n=4 and in {4,5} at n=16. These choices verify the displayed mass caps and packing only; G is not an estimate of the full G_n, and these are not claimed as R748-selected weights.",
            "R753 and R754 original price/denominator cases are reconstructed and compared through dedicated finite checks. The earlier R749 tests are outside this run. R746 motivates unique ownership; its greedy inefficiency is historical evidence rather than a new calculation here.",
            "L=sqrt(n) in every calculation. The test radius division 5/8 is explicitly diagnostic and is not the theorem's unspecified C0-dependent branch.",
            "Exact tensor counts cover the full labeled family at n=4 and n=16. A small independent two-dimensional shell enumerates every center.",
            "All arithmetic on masses and overlap lengths is exact rational; long fractions are printed as certified Arb intervals.",
            "The 2-by-2 check uses three finite abstract rank distributions.",
        ],
    }


def main():
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    result=json.dumps(report(),indent=2,sort_keys=True)+"\n"
    if args.out:
        args.out.write_text(result,encoding="utf-8")
        print(f"wrote {args.out} ({len(result)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8")!=result:
            raise SystemExit("rerun differs from saved data")
        print(f"identical rerun of {args.check} ({len(result)} bytes)")


if __name__=="__main__":
    main()
