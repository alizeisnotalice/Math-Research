"""Exact finite check of the four-parent two-price moment, including two real L1 price pockets."""
from fractions import Fraction as Q
from itertools import product
from math import prod


def inverse_mirror(distance, radii, h, dim):
    return prod((1 - distance / (2 * h * radius)) ** (-dim) for radius in radii)


def run(dim):
    radii = tuple(map(Q, (1, 2, 3, 5)))
    centers = (Q(0), Q(3, 2), Q(-13, 5), Q(9, 2))
    a = 32 * dim
    h = 1 + Q(1, a)
    d = [(2 * radius) ** dim for radius in radii]
    v = [volume / a**dim for volume in d]
    assert all(d[j + 1] > 2 * d[j] for j in range(3))
    assert max(c - r for c, r in zip(centers, radii)) == -Q(1, 2)
    assert min(c + r for c, r in zip(centers, radii)) == Q(2, 5)
    assert all(abs(centers[i] - centers[j]) > (radii[i] + radii[j]) / a
               for i in range(4) for j in range(i + 1, 4))
    # The L1 price is Lebesgue on [-10,10]^n with two uniform, positive density increments.
    radius = Q(1, 64 * dim)
    pockets = (-Q(1, 4), Q(1, 4))
    price = (d[0] / 3, 2 * d[0])
    pocket_volume = (2 * radius) ** dim
    assert all(weight > pocket_volume for weight in price)
    assert all(-Q(1, 2) < center - radius < center + radius < Q(2, 5) for center in pockets)
    m = [entry + sum(price) - 2 * pocket_volume for entry in d]
    S = Q(20) ** dim + sum(price) - 2 * pocket_volume
    assert all(value >= required for value, required in zip(m, d))
    chi = (Q(1, 3), Q(3, 4))
    masses = [mass * weight for mass, weight in zip(price, chi)]
    M = sum(masses)
    p = M / m[0]
    posterior = [weight / M for weight in masses]
    g = [share / actual for share, actual in zip(v, m)]
    w = [Q(i + 1, 8) * rate for i, rate in enumerate(g)]
    assert sum(w) <= 1 and all(wi * mi <= vi for wi, mi, vi in zip(w, m, v))
    bounds = []
    for upper in (False, True):
        conditional = raw = Q(0)
        for i, j in product(range(2), repeat=2):
            gap = abs(pockets[i] - pockets[j])
            dist = gap + 2 * radius if upper else max(Q(0), gap - 2 * radius)
            mirror = inverse_mirror(dist, radii[1:], h, dim)
            conditional += posterior[i] * posterior[j] * mirror
            raw += masses[i] * masses[j] * mirror / m[0]
            # Each remaining radius occupies its own volume bin; the actual maximum
            # in that bin is a valid mirror radius. Check each full receiver volume.
            for k in (1, 2, 3):
                D = (1 - dist / (2 * h * radii[k])) ** dim
                assert v[k] / d[k] <= 2 * h**dim * D
        assert raw == M * p * conditional
        bounds.append(p * conditional)
    assert 0 < bounds[0] <= bounds[1]
    c_forward = w[0] * w[1] * g[2] * g[3]
    c_reverse = g[0] * g[1] * w[2] * w[3]
    assert c_forward != c_reverse
    for coeff in (c_forward, c_reverse):
        assert coeff * M * bounds[1] <= (2 * h**dim) ** 3 * S
    ratio = M / (Q(9, 10) ** dim)
    return ratio, bounds, c_reverse / c_forward


if __name__ == "__main__":
    for n in (4, 16, 64):
        density, interval, orientation = run(n)
        print(f"n={n} density={float(density):.8g} "
              f"B=[{float(interval[0]):.8g},{float(interval[1]):.8g}] "
              f"reverse/forward={orientation}")
    print("All interval endpoint comparisons and mass identities used exact fractions.")
