# R272 independent clock-compression screen

**Verdict: PASS.** The proposed original-row clock estimate has constant **one**, improving R271's valid Schur constant four. This is a conditional analytic estimate, not a payment of the remaining spatial/source integral. This screen preceded author-proof reading.

## 1. Exact inverse-degree ledger

Fix the original x,y,j and nonempty interval [tau,g]. Keep the original pure clamp weights, original right-continuous finite-tree decreasing carrier and raw degree e_t. Assume e_g>0, hence e_t≥e_g>0 throughout. Let m_t=Π_t k_t. On every carrier-constant phase,

    d(1/e_t)=(m_t/e_t)dlogt.

Threshold changes in k_t do not jump w_t or e_t. A carrier deletion makes 1/e jump upward. Therefore, with the start carrier already right-continuous and an included right endpoint,

    J_e=integral_tau^g (m_t/e_t)dlogt
       =1/e_g−1/e_tau
          −sum_(tau<t≤g)[1/e_t−1/e_(t−)]≥0.              (C1)

It follows that J_e≤1/e_g−1/e_tau≤1/e_g. At an open right endpoint, all terminal values and event sums must instead use the corresponding left-limit convention. At g=tau the integral is zero and there are no internal events. A genuinely empty interval is zero separately.

The exact sum formula uses the original finite-jump carrier and absolutely continuous inter-event degree. For a different arbitrary decreasing carrier with additional continuous or singular deletion variation, the endpoint upper bound still holds but that additional positive inverse-degree variation must also be subtracted for an exact identity. It is not silently absent from a universal monotonicity assertion.

## 2. Clock Cauchy and source Cauchy

For any time-static nonnegative physical target K and fixed terminal weight w_g, define

    B_t=integral_(Z_t) k_t(v)w_t(v)sqrt(K(v)/w_g(v)) ν(dv).

On m_t=0, this B_t is zero. On the remaining clock, Cauchy in dlogt gives

    [integral B_t/e_t dlogt]^2
       ≤J_e integral B_t²/(e_t m_t)dlogt.                (C2)

The factors are sqrt(m_t/e_t) and B_t/sqrt(e_t m_t). Thus there is no degree change of measure, Schur loss, extra n or extra clock length. Source Cauchy with measure 1_Z k_t w_t ν has mass e_t m_t, and Tonelli gives

    integral B_t²/(e_t m_t)dlogt
       ≤integral (K/w_g) D_Z(v)ν(dv),
    D_Z(v)=integral_tau^g 1_(Z_t)(v)k_t(v)w_t(v)dlogt.   (C3)

All extended nonnegative versions follow by finite positive truncation. If J_e=0 then m_t=0 almost everywhere in the continuous clock, and the original left side is zero; this case is handled before any formal 0 times infinity on the right. K and the terminal weight must be static at the fixed actual row. A time-dependent gate/target may remain inside an integral or be bounded by a proved static majorant, not factored out without qualification.

For a smaller actual clock domain, positive enlargement to the full original raw interval yields (C2)–(C3). The exact endpoint/event formula (C1) refers to that full interval. A data-dependent disconnected subdomain has its own integral J, not automatically the same endpoint difference without its phase bookkeeping.

## 3. Retain the common surviving hard source and its exact discount

Let H be the original terminal-carrier near hard numerator from R271. On H>0 its retained support gives

    eta R^n H≤e_g,   eta=1−d/(2b)≥15/16.

Define the dimensionless exact clock discount

    theta_e=eta R^n H J_e.

Then

    0≤theta_e≤(eta R^n H/e_g)(1−e_g/e_tau)
              ≤1−e_g/e_tau≤1.                         (C4)

Consequently the actual hard-weighted clock square satisfies

    H² [integral B_t/e_t dlogt]^2
      ≤H² J_e integral (K/w_g)D_Z ν
      =[H/(eta R^n)] theta_e integral (K/w_g)D_Z ν
      ≤[H/(eta R^n)] integral (K/w_g)D_Z ν.              (C5)

This is exactly constant one in place of R271's four. H=0 is an original zero response handled first; if e_g=0, the terminal-support inequality forces H=0 and does not authorize any division by e_g. The exact discount may be retained under the original x,y,leaf integral. If e_tau=e_g then the nonnegative continuous clock vanishes, consistent with theta_e=0.

Deletion inverse jumps lower J_e. This is an exact positive-degree ledger for estimating the positive response; it neither spends the original signed N_del credit nor creates an additional negative payment. The already screened pure-weight bound D_Z≤1_(Z_tau)(w_tau−w_g), including removed sources, remains valid.

## 4. Resulting outer coefficients and unproved scope

If the three-target source Cauchy in R271 is otherwise unchanged, its factor 12 becomes 3. Keeping theta_e replaces the old A_int by the corresponding integral with the extra theta_e(x,y) factor; dropping theta_e≤1 gives

    F(x)^2≤3 A(x)/(eta q),
    P≤epsilon X+Lambda²K/(eta q lambda epsilon) A_int
      ≤epsilon X+[4Lambda²K/(3eta epsilon)] A_int/lambda².

This is the same original FIRST source slot, raw ν degree, physical target and common-leaf receiver accounting. Variable original parameters must stay under their original outer measure or be uniformly bounded legitimately. A_int (or its sharper discounted variant) still contains the original selector, terminal weight and genuine sources; no global bound or input payment has been established here.

## 5. Actual bounded arithmetic evidence

Executed five exact Fraction clamp laws with positive surviving terminal mass, including no deletion, an internal deletion, a terminal deletion, both, and a deletion at the initial endpoint. The exact inter-event inverse-degree increments match (C1) and obey (C4). This tests event bookkeeping, not a FULL geometry instance or the final spatial estimate.

```python
from fractions import Fraction as F
from math import prod
A=[(F(4),F(4)),(F(1),F(2)),(F(3,4),F(3))]
nu=[F(1),F(2),F(1,2)];tau=F(1,2);g=F(4);eta=F(15,16)
cases=[(F(5),F(5),F(5)),(F(5),F(3,2),F(5)),
       (F(5),F(5),g),(F(5),F(3,2),g),(F(5),tau,F(5))]
for deaths in cases:
    def e(t,pre=False):
        return sum(mu*prod(min(F(1),a/t) for a in aa)
                   for mu,aa,death in zip(nu,A,deaths)
                   if death>=t if pre or death>t)
    knots=sorted(set([tau,g]+[a for aa in A for a in aa if tau<a<g]
                     +[d for d in deaths if tau<d<g]))
    Je=sum(1/e(r,True)-1/e(l) for l,r in zip(knots,knots[1:]))
    jumps=sum(1/e(t)-1/e(t,True) for t in sorted(set(deaths))
              if tau<t<=g)
    assert Je==1/e(g)-1/e(tau)-jumps
    assert 0<=Je<=1/e(g)-1/e(tau)
    H=F(1)
    assert eta*H*Je<=1-e(g)/e(tau)
print('PASS 5 exact inverse-degree continuous/jump endpoint ledgers')
```

# Independent addendum: a full adaptive target column

**Statement-screen verdict: PASS for the adopted Jeffreys-angle proof with constant 6 sqrt(n).** This argument was checked before reading `/tmp/r272_adaptive.md`. It is a true adaptive receiver-column tool, not a source or posterior budget.

Fix finite y,z,v, 0<a≤b≤2a, n≥1. Put Eyz=exp[6||y−z||_1/b]. For independent R,A∈[a,b], define

    T_(R,A,s)(x)=h_R(x−z)P_(s,A)(x−v)
                  /sqrt(barw_R(y,v)barw_A(y,v)).

The R271 clamp column gives, with r0=min(R,A), M=max(R,A),

    integral T_(R,A,s) dx
      ≤Eyz M^(−n) sqrt(barw_r0/barw_M)
      ≤Eyz (RA)^(−n/2).                                  (A1)

The last inequality uses the true coordinate clamp ratio barw_r0/barw_M≤(M/r0)^n, not a source normalization. A target scale satisfying A≥L has m=min(L,R)≤min(R,A); consequently barw_m≥sqrt(barw_R barw_A). Hence this separated kernel majorizes the original target-only column, including all three actual targets.

For fixed soft s, separate

    T_(R,A,s)=alpha(R)alpha(A) B_R(x) D_A(x),
    alpha(r)=r^(−n)/sqrt(barw_r(y,v)),
    B_R=1_(Q_R(z)),  D_A=product_i f_s((x_i−v_i)/A).

Both profiles increase. Their **rectangular increments** are exactly ΔB_R ΔD_A≥0; this is stronger than merely asserting a general two-variable monotone profile. Alpha is nonincreasing with logarithmic slope in [−n,−n/2]. On finite rectangular menus, positive prefix telescoping and two separate Abel sums using (A1) yield

    integral max_(R,A) T_(R,A,s) dx
       ≤Eyz [2a^(−n/2)−b^(−n/2)]²≤4 Eyz a^(−n).        (A2)

If menu endpoints are interior, their corresponding endpoints first give the same formula with the smaller ranges. Positive dense exhaustion then proves the all-scale version. Fixed finite source centers and positive a,C_i give bounded compact receiver domination (hard source supports lie in Q_b(z)); original measurable selectors and hard-boundary conventions therefore present no new obstacle. There is no physical-scale menu charge.

## Jeffreys mixture and all soft choices

Let μ_J(ds)=ds/[πsqrt(s(1−s))]=(2/π)dtheta under s=sin²theta. For a monomial g(theta)=sin^(2k)(theta)cos^(2(n−k))(theta), its maximum is at sin²theta0=k/n.

For 1≤k≤n−1, the interval |theta−theta0|≤1/(4sqrt(n)) lies in [0,π/2], and both sine and cosine are at least 3/4 their values at theta0. Thus (log g)''≥−64n/9, and Taylor at its maximum loses at most 2/9<1/4. The interval's normalized μ_J mass is 1/[πsqrt(n)], so its integral is at least exp(−1/4)max(g)/[πsqrt(n)].

For k=0 or n, use the one-sided interval of length 1/(2sqrt(n)). The elementary log cos(theta)≥−theta² for 0≤theta≤1/2 gives loss at most 1/2 and the same normalized interval mass. Therefore every nonnegative degree-n soft monomial satisfies

    max g≤πsqrt(e n) integral g dμ_J<6sqrt(n) integral g dμ_J.

The actual P_(s,A) has a finite expansion into these monomials with nonnegative spatial coefficients. Hence, pointwise for all s,

    P_(s,A)≤6sqrt(n) integral P_(u,A) μ_J(du).

Positive supremum/integral interchange is an upper bound, not an equality. Apply (A2) at each u and use μ_J mass one to conclude

    integral sup_(a≤R,A≤b,0≤s≤1) T_(R,A,s) dx
      ≤24sqrt(n) Eyz a^(−n).                              (A3)

This uniformly covers the original actual target-only selectors via A≥L. It does not confer FIRST at an auxiliary selector, remove a terminal pure weight without the original one-time gamma comparison, or pay any subsequent source integral. The near anchor condition bounds Eyz by exp[3/(8sqrt(n))].

# Independent addendum: common-hard-core anchor relocation

**Statement-screen verdict: PASS, only on x∈Q_R(y).** Directly read the frozen R256 `cluster_payment.md` CP8/CP19, lines 235–278. Its hypotheses are two positive L1 sources dominated by f, the genuine receiver hard band, and one same actual scale R(x); no ordering between the two sources is needed.

Let m=c_jg∈[a,b], and use the original pure weight ratio

    Phi_(y,v)=w_tau(y,v)/w_g(y,v)−1,
    log(1+Phi_(y,v))
       =sum_i clip(log[m/(bC(|y_i−v_i|/b))],0,log(m/a)).

The clip is one-Lipschitz in log C. On the actual near hard pair ||y−z||_1≤d/2, therefore

    Phi_(y,v)≤exp(delta)Phi_(z,v)+(exp(delta)−1),
    delta=6d/(2b)≤3/(8sqrt(n)).                            (A4)

This changes only the pure symmetric anchor of the weight. It is not a reversibility assertion or an exchange of actual Π laws/carriers.

On the additional receiver core x∈Q_R(y), H/R^n times ρ(dy) becomes bounded by the same-scale near-pair density h_R(x−y)h_R(x−z)ρ(dy)ν(dz), after positively enlarging the remaining terminal hard mask. The previously proved clock/degree bound must be obtained **before** discarding that gate. Since theta_e≤1 and D_Z/w_g≤Phi_y, (A4) applies to the sharpened residual A_theta as well as its unweighted majorant.

For every original actual receiver, master FIRST for all future soft parameters and all physical scales gives

    sum_(i=1)^3 integral K_i(x,v)ν(dv)≤3q.

This includes fixed J=P_(1,b): soft 1 is future and b is legal. The statement uses actual targets, not newly chosen soft nodes. With ρ≤f and ν≤f, CP19 gives for the error

    A_error ≤3q(exp(delta)−1)
              integral_E integral_near h_R(x−y)h_R(x−z)ρ(dy)ν(dz)dx
            ≤48qλ kappa_d(exp(delta)−1) sqrt(Wρ Wν).       (A5)

Here kappa_d=2+nlog(1+d/a)≤2+sqrt(n)/8. Since q≤λ and exp(delta)−1≤delta exp(delta), a fully uniform bound is

    A_error ≤(153/4)exp(3/8) λ² sqrt(Wρ Wν).               (A6)

For the principal term, the remaining near anchor integral is at most h_R*ρ≤4λ. Hence

    A_(theta,core)≤4λexp(delta) Qν + A_error,

    Qν=integral_E integral ν(dz)h_R(x−z)
               sum_i integral ν(dv)K_i(x,v)Phi_(z,v) dx.  (A7)

Keeping theta_e and original source gates can be sharper. The displayed pure-Qν majorant uses their positive upper bounds. Every R,A,s,m in (A7) is still the same actual receiver selector. Qν remains an unpaid two-source spatial integral; the adaptive unweighted target column (A3) does not automatically control its Phi factor. The halo x outside Q_R(y) cannot be converted into the first h_R(x−y) and remains in the original expression. Source masses and outer sums remain their real ledgers; (A6) alone does not authorize replacing them by a different source total.

## Bounded exact arithmetic evidence for these addenda

Actually executed 44 exact Fraction monomial checks for n=1,...,8, using the exact Jeffreys beta-integral. Also checked the coefficient 48·51/64=153/4. These are bounded algebra diagnostics, not the proof of (A3), interval certification, or a FULL geometry test.

```python
from fractions import Fraction as F
from math import comb
checks=0
for n in range(1,9):
    a=[F(comb(2*k,k),4**k) for k in range(n+1)]
    for k in range(n+1):
        mode=F(k,n)**k*F(n-k,n)**(n-k)
        mean=a[k]*a[n-k]/comb(n,k)
        assert mode*mode<=36*n*mean*mean
        checks+=1
assert F(48)*F(51,64)==F(153,4)
print('PASS',checks,'exact Jeffreys monomial-ratio checks and anchor-error coefficient')
```
