# R272 final independent integration audit

**Verdict: PASS. No necessary mathematical correction found in the reviewed main.** The exact-clock improvement, true adaptive target envelope and anchor-relocation error are established within their stated scopes. Q and the halo term remain unpaid.

Reviewed main: `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/272/work/proof.tex.txt`

SHA256: `f24fdeab20327988094c4b96f8ad45be1f3d4d5eccde8d1ba295afac0c9182eb`.

The independent statement screens preceded this main/author reading. They are recorded in `/tmp/r272_screen.md`, SHA256 `58a0e3ce0d6459e7c7da52b9201a75d8ee2d890427d7168d7a6b88b99de7bca0`. The R256 frozen CP19 was directly read for the common-scale near-pair interface. No finite test is used as proof of a uniform analytic claim.

## 1. Original carrier and exact clock: PASS

The main retains the original terminal hard-source gate before bounding the hard numerator by H. Only ρ≤β≤α≤f and the independent hard domination ν≤f are needed; it does not use ν≤β. Actual complete posteriors, high/good-upper-score orientation, original physical selectors, common leaf receiver accounting and unique receiver j are retained.

Equations (1)–(3) correctly improve R271's Schur four to one by direct clock Cauchy. The derivative d(1/e)=(m/e)dlogt is taken on the original carrier-constant phases; inverse-degree deletion jumps are subtracted, including an event at g and excluding the initial event already contained in Z_tau. All endpoints change together if the right endpoint is open. The finite-tree carrier supplies exactly the regularity needed for the displayed sum formula. Threshold births create no weight jump. The zero-H/empty response convention is read before defining divided clock quantities, and such rows are zero-extended; on the remaining rows e_g>0. Zero m and J_e=0 are correctly separated from division or 0 times infinity.

The exact discount theta=eta R^n H J_e≤e_gJ_e≤1−e_g/e_tau≤1 is correct. The physical kernels and terminal denominator are static at fixed actual x,y,j during clock Cauchy. Pure D_Z, including its valid deleted-source meaning, is retained. No signed deletion credit or second hardcap is used in this calculation.

## 2. Outer three-target constant: PASS

Source Cauchy uses only the actual FIRST factor integral p_y dρ≤q; the y-dependent degree stays in the other factor. Three target terms cost three, the new clock cost is one, and the original exterior is 2Lambda sqrt(K/3). Thus (4) has precisely Lambda²K/(eta q lambda epsilon) times A_theta. The old coefficient four is not accidentally retained. Unique actual j incurs no menu count, and a single Young bound is justified by the original common-leaf receiver qualifier. The warning on variable exterior parameters is necessary and present.

## 3. Full-scale/full-soft target envelope: PASS

For A≥L, barw_min(L,R)≥barw_min(A,R)≥sqrt(barw_R barw_A). This justifies independent physical R,A relaxation. The actual clamp column and the true ratio barw_min/barw_max≤(max/min)^n give the separated fixed-column E_yz(RA)^(−n/2); no clamp is removed by an unsupported normalization.

The two profiles are a hard cube B_R and the positive averaged target profile D_A. Their rectangular increments are exactly ΔB_R ΔD_A≥0. Thus the two-variable prefix/Abel argument is valid here, rather than an unjustified inference from arbitrary two-variable monotonicity. The amplitude slope [−n,−n/2], finite sums including endpoints, and their terminal terms give E_yz(2a^(−n/2)−b^(−n/2))². Positive dense exhaustion is compatible with the scale-right-continuous hard kernels and fixed finite-source measurability. The a=b case is included as a single scale.

The adopted Jeffreys-angle argument is correct for every n≥1: interior angular windows fit, retain sine/cosine at least 3/4, and lose at most 2/9<1/4; endpoint windows lose at most 1/2. Nonnegative product coefficients then give pi sqrt(e n)<6sqrt(n) for the entire common scalar softness. The probability mixture is shared across coordinates. Positive supremum/integral upper bounds yield (5), with the exact pi sqrt(e) expression and safe 24sqrt(n) constant. The three-target sum is correctly stated to cost up to three copies. This theorem is an actual adaptive dx column; it still gives no node FIRST or source budget. Replacing the physical bar-weight by original w_g, if later used, has its original one-time gamma^n fee.

## 4. Anchor relocation on the common hard core: PASS

The pure ratio Phi has the stated clipped-log expression because m=c_jg lies in [a,b] and w_tau=barw_a. The clip is one-Lipschitz in log C, so its anchor displacement costs one logLip6, not two. The original hard-near condition gives delta_*=3d/b≤3/(8sqrt(n)). Equation (10) uses actual future FIRST for K1,K2 and J=P_(1,b), all at their legal actual physical scales, to pay its additive 3q factor. It changes the pure weight center only, not a posterior anchor or carrier.

The condition x∈Q_R(y) is indispensable: only there does H/R^n times ρ become a same-actual-R product h_R(x−y)h_R(x−z). This is kept explicit. The CP19 estimate applies to ρ and ν independently dominated by f, with the same receiver R(x); it does not require their sum≤f or ν≤β. Its near-l1 factor two and hence 16lambda kappa_d are retained. The additive anchor error is therefore exactly 48q lambda kappa_d(exp(delta_*)−1)W_pair before exterior Young. The uniform inequality kappa_d(exp(delta_*)−1)≤(51/64)exp(3/8) is correct.

## 5. Full final substitution and remaining terms: PASS

Dropping nonnegative near/theta/terminal masks in the principal anchor term and applying h_R*ρ≤4lambda gives A_anc≤4lambda Q with one unchanged actual selector. Pure Phi symmetry is not mistaken for symmetry of original kernels or posteriors. The main can instead retain A_anc if that relaxation is too expensive.

Substitution after the one already performed Young inequality gives exactly (14): the Q coefficient 4Lambda²K exp(delta_*)/(eta q epsilon), the original halo coefficient Lambda²K/(eta q lambda epsilon), and the paid anchor-error coefficient 48Lambda²K kappa_d(exp(delta_*)−1)/(eta epsilon). In the last term q cancels exactly; no preliminary uniform q relaxation is needed. There is only one epsilon X. The source quantity W_pair stays on its genuine ledger and is not silently equated to input mass.

The halo x outside Q_R(y) remains in A_theta,halo; near does not imply membership in that core. Q still contains actual selectors, both raw ν sources and the pure loss ratio. The new adaptive column by itself does not bound this weighted source integral. These two gaps and all other original signed/source branches remain explicit, so the main does not certify a new general root-order closure.

## Evidence boundary

The independent screen records five actually executed exact clamp/event inverse-degree ledgers and 44 exact Jeffreys monomial checks with reproducible Python code. These are bounded algebra diagnostics only, not interval or FULL certificates. This final step read the entire hash-bound main for consistency and performed no redundant physical/numeric suite. No repository file was modified.
