#!/usr/bin/env python3
import argparse,hashlib,json,re,subprocess,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for code in re.findall(r'```python\n(.*?)```',(root/'screen.md').read_text(),flags=re.S):
 exec(compile(code,'audit-code','exec'),{})
print('Manifest and exact audit arithmetic PASS')
if not args.check_only:
 with tempfile.TemporaryDirectory() as td:
  for stem in ('numeric_checks','anchor_checks'):
   out=Path(td)/(stem+'.json')
   subprocess.run([sys.executable,str(root/(stem+'.py')),'--output',str(out)],check=True)
   assert out.read_bytes()==(root/(stem+'.json')).read_bytes(),stem+' replay differs'
 print('Both numerical replays byte-identical')
