#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
import mpmath as m

def C(r):
 r=abs(r)
 return 1-r+m.mpf(1)/3-m.expint(4,r)-m.expint(4,1)+m.expint(4,r+1) if r<=1 else m.expint(4,r-1)-2*m.expint(4,r)+m.expint(4,r+1)
def run(dps):
 with m.workdps(dps):
  rows=[]
  for n in (1,8,64,512,4096,1000000):
   a=m.mpf('.5'); b=m.mpf(1); d=a/(8*m.sqrt(n)); delta=3*d/b
   for kind in ('single','diffuse','boundary'):
    if kind=='single':blocks=[(1,m.mpf('.8'),d/2)];scale=m.mpf('.75')
    elif kind=='diffuse':blocks=[(n,m.mpf('1.2'),d/(2*n))];scale=m.mpf(1)
    else:blocks=[(n,m.mpf(1)-m.mpf('1e-10'),-d/(2*n))];scale=m.mpf('.75')
    def lograt(v):return min(m.log(scale/a),max(m.mpf(0),m.log(scale/C(v))))
    ly=sum(k*lograt(v) for k,v,z in blocks);lz=sum(k*lograt(v-z) for k,v,z in blocks)
    assert abs(ly-lz)<=delta+m.mpf('1e-35')
    fee=(2+m.sqrt(n)/8)*m.expm1(3/(8*m.sqrt(n)))
    fee_bound=m.mpf(51)/64*m.exp(m.mpf(3)/8)
    assert fee<=fee_bound
    rows.append({'n':n,'stage':'initial' if n<=8 else 'stress' if n<=512 else 'expanded','kind':kind,'log_1_plus_Phi_y':m.nstr(ly,90),'log_1_plus_Phi_z':m.nstr(lz,90),'delta':m.nstr(delta,90),'log_transfer_margin':m.nstr(delta-abs(ly-lz),90),'fee':m.nstr(fee,90),'fee_bound':m.nstr(fee_bound,90)})
  return rows
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=p.parse_args()
a,b=run(50),run(80)
with m.workdps(120):
 errs=[abs(m.mpf(x[k])-m.mpf(y[k]))/max(1,abs(m.mpf(y[k]))) for x,y in zip(a,b) for k in x if k not in ('n','stage','kind')]
 mx=max(errs);assert mx<m.mpf('1e-35')
 out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases_per_precision':18,'precision_fields':len(errs),'maxdiff':m.nstr(mx,100),'mp50':a,'mp80':b,'scope':'Finite real C-profile clamp-loss center translations and exact analytic fee formula. Compressed identical-coordinate blocks avoid million-coordinate arrays. Stable log(1+Phi) is tested, equivalent to both positive transfer inequalities. No receiver integral, source FIRST/FULL or interval certification is asserted.'}
args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'cases':18,'maxdiff':out['maxdiff']}))
