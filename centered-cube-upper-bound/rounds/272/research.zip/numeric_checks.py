#!/usr/bin/env python3
"""R272 arcsine-mixture coefficients and exact finite two-Abel checks."""
import argparse,hashlib,json,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def scalar(dps):
 with mp.workdps(dps):
  rows=[]
  for n in [1,2,8,16,64,512,4096,65536,1000000]:
   ks=sorted({k for k in [0,1,2,math.isqrt(n),n//4,n//2,n-1,n] if 0<=k<=n})
   for k in ks:
    logmax=mp.mpf(0) if k in [0,n] else k*mp.log(mp.mpf(k)/n)+(n-k)*mp.log1p(-mp.mpf(k)/n)
    logbeta=mp.loggamma(mp.mpf(k)+mp.mpf('.5'))+mp.loggamma(mp.mpf(n-k)+mp.mpf('.5'))-mp.loggamma(n+1)
    logc=logmax-logbeta+mp.log(mp.pi);c=mp.exp(logc);ratio=c/mp.sqrt(n);assert ratio<=6
    rows.append({'stage':'initial' if n<=16 else 'stress' if n<=4096 else 'expanded','n':n,'k':k,'s_max_exact':str(F(k,n)),'log_max_soft_monomial':enc(logmax),'log_beta':enc(logbeta),'log_c_nk':enc(logc),'c_nk':enc(c),'c_over_sqrt_n':enc(ratio),'margin_to_6_sqrt_n':enc(6*mp.sqrt(n)-c)})
  best=max(rows,key=lambda r:mp.mpf(r['c_over_sqrt_n']))
  return {'cases':rows,'maximum_sampled_ratio':best['c_over_sqrt_n'],'maximizer':{'n':best['n'],'k':best['k']}}

def amplitude(n,c,grid):return [r**(-n)/min(F(1),2*c/r)**(n//2) for r in grid]
def price(n,c,grid):
 a=amplitude(n,c,grid);d=[r**(-n//2) for r in grid];margins=[];ratios=[]
 for i in range(len(grid)-1):
  ratio=a[i+1]/a[i];lower=(grid[i]/grid[i+1])**n;assert ratio>=lower and ratio<=1
  assert d[i]*(1-ratio)<=2*(d[i]-d[i+1])
  ratios.append(str(ratio));margins.append(str(ratio-lower))
 value=d[-1]+sum(d[i]*(1-a[i+1]/a[i]) for i in range(len(grid)-1));bound=2-F(2)**(-n//2);assert value<=bound
 return a,value,bound,ratios,margins

def exact():
 grids=[[F(1),F(3,2),F(2)],[F(1)+F(i,8) for i in range(9)],[F(1),F(9,8),F(5,4),F(7,4),F(2)]];cs=[F(1,4),F(3,4),F(1)];rows=[];edgechecks=0;profiles=0
 for n in [2,8,32]:
  for ci,c in enumerate(cs):
   for gi,grid in enumerate(grids):
    other=grids[(gi+1)%len(grids)];cc=cs[(ci+1)%len(cs)];a,P,B,ratios,margins=price(n,c,grid);aa,PP,BB,rr,mm=price(n,cc,other);assert P*PP<=B*BB;edgechecks+=len(ratios)+len(rr)
    tests=[]
    for pattern in ['constant','step','mixed']:
     if pattern=='constant':deltaB=[F(1)]+[F(0)]*(len(grid)-1);deltaD=[F(2)]+[F(0)]*(len(other)-1)
     elif pattern=='step':deltaB=[F(i==len(grid)//2) for i in range(len(grid))];deltaD=[F(i==len(other)-1) for i in range(len(other))]
     else:deltaB=[F(i%3,5) for i in range(len(grid))];deltaD=[F((i+1)%4,7) for i in range(len(other))]
     Bs=[sum(deltaB[:i+1]) for i in range(len(grid))];Ds=[sum(deltaD[:j+1]) for j in range(len(other))]
     assert all(x>=0 for x in deltaB+deltaD)
     left=max(a[i]*aa[j]*Bs[i]*Ds[j] for i in range(len(grid)) for j in range(len(other)));right=sum(a[i]*aa[j]*deltaB[i]*deltaD[j] for i in range(len(grid)) for j in range(len(other)));assert left<=right;profiles+=1
     tests.append({'pattern':pattern,'delta_B':list(map(str,deltaB)),'delta_D':list(map(str,deltaD)),'max_pointwise_exact':str(left),'double_Abel_sum_exact':str(right),'margin_exact':str(right-left)})
    rows.append({'n':n,'c':str(c),'other_c':str(cc),'grid':list(map(str,grid)),'other_grid':list(map(str,other)),'amplitudes':list(map(str,a)),'other_amplitudes':list(map(str,aa)),'ratios_exact':ratios,'ratio_margins_exact':margins,'other_ratios_exact':rr,'other_ratio_margins_exact':mm,'Abel_price_exact':str(P),'other_Abel_price_exact':str(PP),'one_dimensional_bound_exact':str(B),'two_dimensional_price_exact':str(P*PP),'two_dimensional_bound_exact':str(B*BB),'profile_checks':tests})
 return {'cases':rows,'amplitude_ratio_checks':edgechecks,'monotone_profile_checks':profiles}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','s_max_exact']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=scalar(50);hi=scalar(80);ex=exact()
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-40')
 out={'schema':'R272-arcsine-double-Abel-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'arcsine_cases_per_precision':len(hi['cases']),'arcsine_stages':{s:sum(r['stage']==s for r in hi['cases']) for s in ['initial','stress','expanded']},'exact_two_Abel_cases':len(ex['cases']),'exact_amplitude_ratio_checks':ex['amplitude_ratio_checks'],'exact_monotone_profile_checks':ex['monotone_profile_checks'],'precision_fields_compared':len(diff)},'mp50':lo,'mp80':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'exact_Abel':ex,'scope':['Arcsine coefficient c_nk uses exact beta-function formula evaluated by ordinary50/80 loggamma; endpoint monomials have max1 with0^0 interpreted by continuous endpoint convention. Only deduplicated prescribed k menu tested, not every k at large n.','No dimension order or universal6 constant inferred from samples. Ordinary mpmath is not directed interval certification.','Abel models are exact finite rational tool arrays, n even2/8/32, receiver scale grids in[1,2],same per-coordinate c1/4,3/4,1. Rowbound d_i=r_i^(-n/2),price=d_last+sum d_i(1-a_next/a_i),bound2-2^(-n/2).','Double monotone profiles have explicit nonnegative increments and certify only the displayed finite pointwise inequality. No original geometry/FIRST/history/FULL/source budget or root conclusion.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'maximum_sampled_ratio':hi['maximum_sampled_ratio']}))
if __name__=='__main__':main()
