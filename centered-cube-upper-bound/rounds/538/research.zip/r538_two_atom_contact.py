"""Exact fixed-mass contact-vertex calibration; not a general weak-type bound."""
import json,sys,platform
from functools import cmp_to_key, lru_cache
from pathlib import Path
import sympy as s

ZERO = s.Integer(0)
R_SINGLE = s.sqrt(2) / 2


@lru_cache(None)
def simp(x):
    return s.expand(x)


@lru_cache(None)
def sign(x):
    answer = s.sign(simp(x))
    assert answer in (-1, 0, 1)
    return int(answer)


def compare(a, b):
    return sign(a - b)


def unique_sorted(values):
    return sorted(set(map(simp, values)), key=cmp_to_key(compare))


def minimum(a, b):
    return a if compare(a, b) <= 0 else b


def maximum(a, b):
    return a if compare(a, b) >= 0 else b


def interval_union_length(intervals):
    intervals = sorted(intervals, key=cmp_to_key(lambda x, y: compare(x[0], y[0])))
    if not intervals:
        return ZERO
    total = ZERO
    lower, upper = intervals[0]
    for left, right in intervals[1:]:
        if compare(left, upper) > 0:
            total += upper - lower
            lower, upper = left, right
        else:
            upper = maximum(upper, right)
    return simp(total + upper - lower)


def full_union_area(x, y):
    """All three nonempty subsets of two equal atoms, with atom 1 at zero."""
    a = R_SINGLE
    boxes = [([-a / 2, -a / 2], [a / 2, a / 2]),
             ([x - a / 2, y - a / 2], [x + a / 2, y + a / 2])]
    lower = [maximum(ZERO, x) - s.Rational(1, 2),
             maximum(ZERO, y) - s.Rational(1, 2)]
    upper = [minimum(ZERO, x) + s.Rational(1, 2),
             minimum(ZERO, y) + s.Rational(1, 2)]
    if all(compare(right, left) > 0 for left, right in zip(lower, upper)):
        boxes.append((lower, upper))
    endpoints = unique_sorted([value for low, high in boxes
                               for value in (low[0], high[0])])
    area = ZERO
    for left, right in zip(endpoints, endpoints[1:]):
        midpoint = (left + right) / 2
        intervals = [(low[1], high[1]) for low, high in boxes
                     if compare(low[0], midpoint) < 0
                     and compare(midpoint, high[0]) < 0]
        area += (right - left) * interval_union_length(intervals)
    return simp(area)


def main():
    offsets = [-s.Rational(1, 2), -R_SINGLE / 2, ZERO,
               R_SINGLE / 2, s.Rational(1, 2)]
    vertices = unique_sorted([left - right for left in offsets for right in offsets])
    best = ZERO
    maximizers = []
    records = []
    for x in vertices:
        for y in vertices:
            area = full_union_area(x, y)
            records.append({"x": str(x), "y": str(y), "area": str(area)})
            if compare(area, best) > 0:
                best, maximizers = area, [(x, y)]
            elif compare(area, best) == 0:
                maximizers.append((x, y))
    expected = s.Rational(3, 2) - s.sqrt(2) / 4
    assert len(vertices) == 13 and len(records) == 169
    assert s.simplify(best - expected) == 0
    assert len(maximizers) == 4
    result = {
        "scope": "Exact exhaustive contact-vertex check for n=2,N=2,m=(1/2,1/2),lambda=1",
        "arithmetic": "SymPy exact quadratic radicals; every ordering uses exact sign",
        "sympy_version": s.__version__,
        "executable": sys.executable,
        "python": platform.python_version(),
        "axis_vertices": list(map(str, vertices)),
        "candidate_count": len(records),
        "maximum": str(best),
        "maximum_decimal": str(s.N(best, 25)),
        "maximizers": [[str(x), str(y)] for x, y in maximizers],
        "certificate": "All 169 candidate areas are listed; exact comparison selects the stated maximum",
        "limitation": "A regression calibration of the general contact theorem, not its proof and not a bound for arbitrary masses or N",
        "records": records,
    }
    target = Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
