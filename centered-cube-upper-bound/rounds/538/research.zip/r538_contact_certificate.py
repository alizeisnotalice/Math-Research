from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache,cmp_to_key
from itertools import product
import json,sys,platform
import sympy as s
import numpy as np
from scipy.optimize import linprog
from flint import arb,ctx
ctx.prec=256
@lru_cache(None)
def ball(q):
 q=s.sympify(q)
 if q.is_Rational:return arb(int(q.p))/int(q.q)
 if q.is_Add:return sum((ball(t) for t in q.args),arb(0))
 if q.is_Mul:
  v=arb(1)
  for t in q.args:v*=ball(t)
  return v
 if q.is_Pow and q.exp==s.Rational(1,2):return ball(q.base).sqrt()
 if q.is_Pow and q.exp.is_Integer:return ball(q.base)**int(q.exp)
 raise ValueError(q)
def norm(q):return s.expand(q)
def cmp(a,b):
 z=norm(a-b)
 if z==0:return 0
 v=ball(z)
 if v>0:return 1
 if v<0:return -1
 raise AssertionError(('undecided',z,str(v)))
def ordered(seq):return sorted(set(map(norm,seq)),key=cmp_to_key(cmp))
def rects(x):
 N=len(x);out=[]
 for mask in range(1,1<<N):
  ids=[i for i in range(N) if mask>>i&1];r=s.sqrt(s.Rational(len(ids),N));lo=[];hi=[]
  for d in range(2):
   vv=ordered([x[i][d] for i in ids]);lo.append(norm(vv[-1]-r/2));hi.append(norm(vv[0]+r/2))
  if all(cmp(a,b)<0 for a,b in zip(lo,hi)):out.append((lo,hi))
 return out

def union_y(intervals):
 if not intervals:return s.Integer(0)
 intervals=sorted(intervals,key=cmp_to_key(lambda a,b:cmp(a[0],b[0])))
 low,high=intervals[0];total=s.Integer(0)
 for a,b in intervals[1:]:
  if cmp(a,high)>0:total+=high-low;low,high=a,b
  elif cmp(b,high)>0:high=b
 return norm(total+high-low)
def area(x):
 rr=rects(x);edges=ordered([v for lo,hi in rr for v in [lo[0],hi[0]]]);z=s.Integer(0)
 for l,r in zip(edges[:-1],edges[1:]):
  mid=(l+r)/2
  active=[(lo[1],hi[1]) for lo,hi in rr if cmp(lo[0],mid)<0 and cmp(mid,hi[0])<0]
  z+=(r-l)*union_y(active)
 return norm(z)
def block_step(x,d):
 N=len(x);other=1-d;off=[s.Integer(0)]+[sgn*s.sqrt(s.Rational(k,N))/2 for k in range(1,N+1) for sgn in [-1,1]]
 endpoints=[(i,o) for i in range(N) for o in off]
 endpoints=sorted(endpoints,key=cmp_to_key(lambda a,b:cmp(x[a[0]][d]+a[1],x[b[0]][d]+b[1])))
 A=[];bb=[]
 for (i,oi),(j,oj) in zip(endpoints[:-1],endpoints[1:]):
  row=[0]*(N-1)
  if i:row[i-1]+=1
  if j:row[j-1]-=1
  A.append(row);bb.append(norm(oj-oi))
 rr=rects(x);gradient=[s.Integer(0)]*N
 for (i,oi),(j,oj) in zip(endpoints[:-1],endpoints[1:]):
  l=x[i][d]+oi;r=x[j][d]+oj
  if cmp(l,r)==0:continue
  mid=(l+r)/2
  active=[(lo[other],hi[other]) for lo,hi in rr if cmp(lo[d],mid)<0 and cmp(mid,hi[d])<0]
  length=union_y(active);gradient[j]+=length;gradient[i]-=length
 res=linprog(-np.array([float(t) for t in gradient[1:]]),A_ub=np.array(A,float),b_ub=np.array([float(v) for v in bb]),bounds=[(-.8,.8)]*(N-1),method='highs')
 assert res.success
 # Reconstruct a vertex exactly from independent active integer rows.
 chamber_rows=len(A)
 for i in range(N-1):
  for sign in [-1,1]:
   row=[0]*(N-1);row[i]=sign;A.append(row);bb.append(s.Rational(4,5))
 selected=[];values=[];selected_indices=[]
 for row_index,(row,b) in enumerate(zip(A,bb)):
  if abs(np.dot(row,res.x)-float(b))>1e-8:continue
  if s.Matrix(selected+[row]).rank()>len(selected):selected.append(row);values.append(b);selected_indices.append(row_index)
  if len(selected)==N-1:break
 assert len(selected)==N-1
 assert all(i<chamber_rows for i in selected_indices)
 vv=s.Matrix(selected).inv()*s.Matrix(values)
 for row,b in zip(A,bb):assert cmp(sum(a*v for a,v in zip(row,vv)),b)<=0
 out=[list(p) for p in x]
 for i in range(1,N):out[i][d]=norm(vv[i-1])
 before=area(x);after=area(out);assert cmp(after,before)>=0
 return out,dict(axis=d,rank=len(selected),artificial_wall_count=0,active_rows=selected,active_rhs=list(map(str,values)),area_before=str(before),area_after=str(after),area_after_arb256=str(ball(after)))
raw=json.loads(Path(__file__).with_name('r538_union_search.json').read_text());results=[]
for rr in raw['results']:
 x=[[s.Rational(round(v*10**6),10**6) for v in p] for p in rr['positions']]
 start=area(x);steps=[]
 # One pass suffices for a product-chamber vertex, further passes examine adjacent choices.
 for d in [0,1]:x,st=block_step(x,d);steps.append(st)
 final=area(x)
 results.append(dict(N=rr['N'],seed=rr['seed'],rounded_initial_area=str(start),rounded_initial_arb256=str(ball(start)),positions=[[str(v) for v in p] for p in x],masses=[str(s.Rational(1,len(x)))]*len(x),steps=steps,final_area=str(final),final_arb256=str(ball(final)),scope='Exact union-area certificate for this algebraic configuration and nondecreasing block vertex moves; not a global-optimality certificate.'))
 print(rr['N'],rr['seed'],str(final),str(ball(final)),flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(executable=sys.executable,python=platform.python_version(),sympy=s.__version__,precision_bits=256,results=results),indent=2))
