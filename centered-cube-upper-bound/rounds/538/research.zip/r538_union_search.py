import numpy as np
from scipy.optimize import differential_evolution
import scipy,json,sys,platform,time
from pathlib import Path

def model(N):
 bits=np.array([[bool(mask>>i&1) for i in range(N)] for mask in range(1,1<<N)])
 def rectangles(x,w):
  spanlo=np.min(np.where(bits[:,:,None],x[None,:,:],np.inf),axis=1)
  spanhi=np.max(np.where(bits[:,:,None],x[None,:,:],-np.inf),axis=1)
  r=np.sqrt(bits@w)
  lo=spanhi-r[:,None]/2;hi=spanlo+r[:,None]/2
  ok=np.all(hi>lo,axis=1)
  return lo[ok],hi[ok]
 def area(x,w):
  lo,hi=rectangles(x,w);edges=np.unique(np.r_[lo[:,0],hi[:,0]]);total=0.
  for left,right in zip(edges[:-1],edges[1:]):
   mid=(left+right)/2;ids=np.flatnonzero((lo[:,0]<mid)&(hi[:,0]>mid))
   if not len(ids):continue
   ids=ids[np.argsort(lo[ids,1])];bottom=lo[ids[0],1];top=hi[ids[0],1];length=0.
   for i in ids[1:]:
    if lo[i,1]>top:length+=top-bottom;bottom=lo[i,1];top=hi[i,1]
    else:top=max(top,hi[i,1])
   length+=top-bottom;total+=(right-left)*length
  return total
 return area
results=[]
for N,seed,iterations in [(4,53801,70),(4,53802,100),(6,53803,100)]:
 area=model(N);w=np.ones(N)/N
 # Translation fixed by first atom at the origin; search domain is explicit only.
 def obj(z):return -area(np.r_[[[0.,0.]],z.reshape(N-1,2)],w)
 start=time.time();res=differential_evolution(obj,[(-.8,.8)]*(2*N-2),seed=seed,maxiter=iterations,popsize=6,polish=True,tol=1e-7,workers=1,updating='immediate')
 x=np.r_[[[0.,0.]],res.x.reshape(N-1,2)]
 r=dict(N=N,seed=seed,iterations=iterations,positions=x.tolist(),masses=w.tolist(),area=float(-res.fun),success=bool(res.success),message=str(res.message),evaluations=int(res.nfev),elapsed_seconds=time.time()-start)
 results.append(r);print(N,seed,r['area'],r['evaluations'],r['elapsed_seconds'],flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(scope='Bounded numerical search of exact-all-subset receiving rectangles for finite atomic sources in dimension two. Differential evolution returns candidates, not global optimality or all-dimensional estimates. Floating sweep is later certified for rounded candidates.',executable=sys.executable,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,results=results),indent=2))
