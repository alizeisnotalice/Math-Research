#!/usr/bin/env python3
"""Reproduce the exact R323 finite dual-prefix diagnostic run.

These are algebra/radius-atom checks, not full native-kernel realizations.
The seed, loop bounds, thresholds, and checks match the original inline run.
"""

from fractions import Fraction as F
from random import Random

rng = Random(323)
checks = 0
for case in range(120):
    n = 1 + case % 4
    nx = 5
    ny = 3
    nz = 4
    radii = [F(1), F(1), F(3, 2), F(2), F(2)]
    vol = [F(rng.randrange(1, 5), 10) for _ in range(nx)]
    q = [F(rng.randrange(3, 5), 4) for _ in range(nx)]
    beta = [F(rng.randrange(1, 4), 5) for _ in range(ny)]
    nu = [F(rng.randrange(1, 4), 7) for _ in range(nz)]
    raw = [[F(rng.randrange(0, 8), 5) for _ in range(nx)] for _ in range(ny)]
    scale = max(
        F(1),
        max(sum(beta[y] * raw[y][x] for y in range(ny)) for x in range(nx)),
    )
    U = [[v / scale for v in row] for row in raw]
    cap = [[rng.randrange(2) for z in range(nz)] for x in range(nx)]
    cuts = sorted(set(radii))
    layers = []
    for i, r in enumerate(cuts):
        wt = r ** (-n) - (cuts[i + 1] ** (-n) if i + 1 < len(cuts) else 0)
        xs = [x for x in range(nx) if radii[x] <= r]
        J = [sum(U[y][x] * vol[x] for x in xs) for y in range(ny)]
        K = [
            sum(F(cap[x][z]) * vol[x] / q[x] / radii[x] ** n for x in xs)
            for z in range(nz)
        ]
        layers.append((r, wt, xs, J, K))
    thresholds = [F(1, 10), F(1, 2), F(2)]
    thresholds.extend(
        K[z]
        for r, wt, xs, J, K in layers
        for z in range(nz)
        if K[z] > 0
    )
    H = F(1, 4)
    for G in thresholds:
        N = F(0)
        for r, wt, xs, J, K in layers:
            for y in range(ny):
                if J[y] < H:
                    continue
                for z in range(nz):
                    if K[z] >= G:
                        continue
                    # A genuinely endpoint-dependent positive mask;
                    # no symmetry is assumed.
                    pair = sum(
                        U[y][u]
                        * U[y][w]
                        * vol[u]
                        * vol[w]
                        * cap[u][z]
                        * F(1 + ((u + 2 * w + y + z + case) % 3), 3)
                        for u in xs
                        for w in xs
                    )
                    N += beta[y] * nu[z] * wt * pair / J[y]
        assert N <= G * sum(nu)
        checks += 1

print("PASS exact dual-prefix checks:", checks)
print("These are finite algebra/radius-atom diagnostics, not full native-kernel realizations.")
