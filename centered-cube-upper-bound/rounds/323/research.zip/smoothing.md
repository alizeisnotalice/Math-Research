# R323 — a source-conserving binary stopping average and its actual boundary remainder

**Result.** Every finite positive L¹ hard source admits one frozen, mass-preserving averaging with density at most `2K`, with no remaining high-average source class. In the original R302 loss, the whole small-relative-packet branch and the tag-accepted middle branch use this SAME averaged input in one maximal-L² estimate. The whole large-relative-packet branch is separately paid by the original same-radius cap. The sole unallocated loss is a real source-boundary disagreement at intermediate packet/receiver scales. No root bound for that disagreement is proved.

The positive tag comparison itself is R319's tool, not a new claim. R318's boundary identity and R319's arbitrary-packet low/high split were inspected; neither constructs the cyclic binary stopping partition below or automatically eliminates the high-average source class. This note adds that construction and the two relative-scale payments. It does not replace the original source inside any gate, kernel, `J`, or capture square.

## 1. Original interface and available maximal theorem

Use the contract of `/tmp/r322_mass_geometry.md`, §§1–2: arbitrary finite positive L¹ sources `β,ν`, unchanged actual fields and original row weights `U_y(u)`, original FIRST

\[
 \rho(u)=\int U_y(u)\,\beta(dy)\le1_E(u),\qquad
 \nu(Q_{R(u)}(u))\le4\lambda R(u)^n,\quad a\le R(u)\le b. \tag{1}
\]

Assume the original FIRST occupancy has finite mass, `X_ρ=λ∫ρ(u)du<∞`; a finite original receiver set suffices and gives `X_ρ≤X=λ|E|`. Any endpoint restriction is retained only in the original numerator/pair mask: the full original `U,A,J` stay fixed. In particular no monotone-convergence claim is made for a quotient obtained by rebuilding `J` from truncated endpoints. Set

\[
 J_y(r)=\int_{R(u)\le r}U_y(u)du,\quad
 A_{yz}(r)=\int_{R(u)\le r}U_y(u)c_u(z)du,
 \quad c_u(z)=1_{Q_{R(u)}(u)}(z),
\]
\[
 \ell_n=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
 \qquad\ell_n([R,b])=R^{-n}.                              \tag{2}
\]

The loss may retain any original `0≤v(y,z,r)≤1` and pair mask `0≤M(y,z,r,u,w)≤1`. Denote its positive baseline and overlap by

\[
 N=\int d\Xi\,c_u(z)M,\quad
 E_{\rm cap}=\int d\Xi\,c_u(z)c_w(z)M,\quad
 B=N-E_{\rm cap}=\int d\Xi\,c_u(z)(1-c_w(z))M,            \tag{3}
\]
where both endpoints are in the prefix and

\[
 d\Xi=\beta(dy)\nu(dz)\ell_n(dr)1_{J_y(r)\ge H}
       \frac{v(y,z,r)}{J_y(r)}U_y(u)U_y(w)du\,dw .
\]

This includes original `B_H`, its actual tent weighting, and its R322 capacity-failure subtraffic. Those factors remain original. As in R322, `N≤A_nWν`, `A_n=1+n log(b/a)`, so the signed identities below are finite.

The only non-elementary input is the already-authorized dimension-uniform strong L² theorem for the **centered cube maximum over all radii**:

\[
 M_\square g(x)=\sup_{t>0}t^{-n}\int_{Q_t(x)}|g|,
 \qquad\|M_\square g\|_2\le C_2\|g\|_2,                 \tag{4}
\]

with absolute `C₂` independent of `n`. Its exact scope was rechecked in `rounds/104/research.zip::proof.md:427–487`, and in the primary paper: [Bourgain, *On the Hardy–Littlewood maximal function for the cube*](https://arxiv.org/html/1212.2661v1), (1.1), (1.2), the introductory theorem and the cube definition (1.8). In particular (1.1) takes `sup_{t>0}`. Thus (4) covers the auxiliary radii slightly above `b` used below; it is not merely a fixed-band estimate. This enlarges only a positive upper-bound response of the new `g`, not the actual selector or a hard cap. No explicit numerical value of `C₂` is asserted.

## 2. Binary stopping gives an automatic density cap with factor two

Fix `K>0`. Use an axis grid of base side `a`. At level `k=qn+j`, `q∈Z`, `0≤j<n`, the first `j` side widths are `a2^{-q-1}` and the other widths are `a2^{-q}`. Use half-open boxes with the corresponding integer lattice. Going from level `k` to `k+1` bisects exactly coordinate `j+1`. Thus the grids are nested; a parent has twice its child's volume, and every box has largest side at most twice its smallest side. This is not the n-ary split whose parent/child ratio is `2^n`.

Call a grid box high if `ν(D)>K|D|`, and let `𝒟` be the boxes maximal by inclusion among all high boxes. They are disjoint. Every ancestor chain eventually has average at most `Wν/|D|→0`, so every high box has a maximal high ancestor. Its immediate parent is not high, hence for every `D∈𝒟`

\[
 K|D|<m_D:=\nu(D)\le2K|D|,
 \quad \sum_{D\in\mathcal D}|D|<W_\nu/K.                 \tag{5}
\]

Along fine levels all side widths tend to zero with eccentricity at most two. Lebesgue differentiation therefore gives `dν/dz≤K` almost everywhere outside `Ω=⋃𝒟`. L¹ sources give zero mass to all grid boundaries. Define

\[
 g(z)=1_{\Omega^c}(z)\frac{d\nu}{dz}(z)
             +\sum_{D\in\mathcal D}\frac{m_D}{|D|}1_D(z).
\]
\[
 \boxed{\ \int g=W_\nu,\quad 0\le g\le2K,\quad
       \|g\|_2^2\le2KW_\nu.\ }                          \tag{6}
\]

Every original source is included, once. For `z∈D`, the associated source tag is uniform on this one frozen `D`; outside `Ω`, leave `z` fixed. This is a receiver-independent Markov source lift with original `z` marginal `ν` and tag marginal `g(z')dz'`. Infinite chains/boxes cause no missing mass: the selected boxes are a countable disjoint family, and outside them the original density is retained. The construction is fixed across all `y,r,u,w`.

## 3. Exact three-way allocation at the original capturing endpoint

Let `t>1`. For `D∈𝒟`, write `δ_D=max_i side_i(D)` and `d_D=min_i side_i(D)`, and let

\[
 \theta_D(u)=|D\cap Q_{R(u)}(u)|/|D|.
\]

Classify at the actual capturing endpoint `u`:

\[
 \begin{array}{lll}
 \text{small packet:}&\delta_D\le R(u)/t;\\
 \text{large packet:}&R(u)\le d_D/t;\\
 \text{middle packet:}&\delta_D>R(u)/t\ \text{and}\ R(u)>d_D/t.
 \end{array}                                               \tag{7}
\]

The first two are disjoint because `t>1`. The names refer to packet size relative to the receiver, not to the original source density. Define three capturing-end weights summing to one source-almost everywhere:

* `w_reg=1` on `Ωᶜ`; on small packets set `w_reg=1`; on middle packets set `w_reg=θ_D`; on large packets set it zero.
* `w_large=1` precisely on large packets.
* `w_bdry=1−θ_D` precisely on middle packets.

Insert each weight in the original positive baseline/overlap/loss (3), preserving all original masks and denominators. This gives the exact positive allocation

\[
 B=B_{\rm reg}+B_{\rm large}+B_{\rm bdry},\qquad
 N=N_{\rm reg}+N_{\rm large}+N_{\rm bdry}.                 \tag{8}
\]

Here `B_bdry` is the **original** capture/miss loss multiplied by

\[
 1_{z\in D}\,1_{d_D/t<R(u)<t\delta_D}\,[1-\theta_D(u)] .  \tag{9}
\]

In particular all the low-`p`, middle-distance, low-softness and other original gates survive if present. No `A/J` is recomputed for `g` or for a component. Formula (9) vanishes on whole captured packets; if the original capture and (9) are positive, `D` is a genuinely partially intersected source packet. Neither boundary volume times a density cap for the original source nor a small boundary-error assertion is used.

## 4. One L² payment for the entire regularized branch

Integrate the second endpoint in a positive upper bound, use FIRST, and use the exact tail (2). For any one of these endpoint weights this yields

\[
 N_w\le\int_E \rho(u)R(u)^{-n}\int c_u(z)w(u,z)\,\nu(dz)\,du.   \tag{10}
\]

This retains the original `ρ` exactly, and uses no component FIRST. If either endpoint has been restricted, integrate that endpoint against its original numerator and use the full original denominator `J`; its mass divided by `J` is at most one. At each actual `u`, put `R'=R(u)(1+2/t)`. If a small packet meets `Q_R(u)`, its entire box lies in `Q_{R'}(u)`, so

\[
 \nu(D\cap Q_R(u))\le m_D\le\int_{Q_{R'}(u)}g_D.
\]

For a middle packet the accepted original mass obeys the R319 positive tag comparison

\[
 \theta_D(u)\nu(D\cap Q_R(u))\le\theta_D(u)m_D
          =\int_{Q_R(u)}g_D\le\int_{Q_{R'}(u)}g_D.         \tag{11}
\]

The good outside source is already part of `g`. Summing these disjoint original source assignments at this receiver gives a SINGLE test input:

\[
 R^{-n}\int c_u(z)w_{\rm reg}(u,z)\nu(dz)
 \le c_t h_{R'}*g(u)\le c_tM_\square g(u),
 \quad c_t=(1+2/t)^n.                                    \tag{12}
\]

There is no number-of-packets, number-of-scales, or cross-energy factor. All cross terms are included in the one global L² norm of `g`. Since `0≤ρ≤1`, weighted Cauchy–Schwarz gives `∫ρ M_□g≤(∫ρ)^{1/2}(∫ρ(M_□g)²)^{1/2}≤C₂(∫ρ)^{1/2}||g||₂`. Thus for every `ε>0`,

\[
 \boxed{\ N_{\rm reg}\le
 \varepsilon X_\rho+\frac{c_t^2C_2^2}{4\varepsilon\lambda}\|g\|_2^2
 \le\varepsilon X_\rho+
       \frac{c_t^2C_2^2K}{2\varepsilon\lambda}W_\nu.\ }   \tag{13}
\]

In (13), the pre-Young bound is `N_reg≤c_t∫ρ M_□g≤c_tC₂ sqrt(X_ρ/λ)||g||₂`. The tag lift remains source-conserving; acceptance depends on the actual cube only after the frozen lift has been defined. On the small branch the original traffic is paid in full by a proved enlargement comparison. The enlarged radius is only used on the positive response of the valid L² input `g` in (12), so it needs no original enlarged-radius cap or mask transport.

## 5. Whole large packets have a separate same-radius-cap payment

For a fixed `D`, use (10), `ρ≤1`, and the actual same-radius cap (1). On the large branch any nonzero captured source forces

\[
 u\in D+Q_{d_D/t},\qquad
 |D+Q_{d_D/t}|=\prod_i(side_i(D)+d_D/t)
                       \le v_t|D|,\quad v_t=(1+1/t)^n.
\]

Consequently

\[
 \boxed{\ N_{\rm large}\le4\lambda v_t\sum_D|D|
          \le\frac{4\lambda v_t}{K}\nu(\Omega).\ }        \tag{14}
\]

The potentially overlapping receiver supports have been summed with their full fee; source cells themselves are disjoint. This is not a claim that the original source has bounded density on a boundary layer. The hard cap is evaluated at the unchanged actual `R(u)` throughout. It pays the whole large-packet loss, including its tag-rejected part.

Combining (8), (13), (14) gives both interfaces:

\[
 \boxed{\ B\le\varepsilon X_\rho+
   \frac{c_t^2C_2^2K}{2\varepsilon\lambda}W_\nu
   +\frac{4\lambda v_t}{K}\nu(\Omega)+B_{\rm bdry}.\ }    \tag{15}
\]
\[
 B\le\varepsilon X_\rho+
   \frac{c_t^2C_2^2K}{2\varepsilon\lambda}W_\nu
   +\frac{4\lambda v_t}{K}\nu(\Omega)
   +N_{\rm bdry}-E_{\rm cap}.                            \tag{16}
\]

Equation (16) retains the original WHOLE capture-square credit when `M=1`; (15) instead retains the exact positive unallocated loss. They are alternative ledgers, not additive payments. Neither `g` nor its tags replace the original `U,A,J,v,M` in the remainder.

Choose `t=2n`. Then `c_t≤e`, `v_t≤√e`, and the remaining packet collar satisfies

\[
 d_D/(2n)<R(u)<2n\delta_D,\qquad\delta_D/d_D\le2.         \tag{17}
\]

For the customary root choice `K=λ√n`, (15) becomes

\[
 \boxed{\ B\le\varepsilon X_\rho+
  \left[\frac{e^2C_2^2}{2\varepsilon}\sqrt n
             +\frac{4\sqrt e}{\sqrt n}\right]W_\nu
  +B_{\rm bdry}.\ }                                     \tag{18}
\]

All parameters are legitimate for `n=1` too. Another fixed choice such as `K=λ` prices its own allocated branches with a dimension-free source coefficient; the partition and remainder then change with `K`. No free optimization over different remainders is licensed. The same bad source can use the L² receipt at some actual radii and the volume receipt at others: both fees are explicitly present in (15), with no hidden scale multiplicity.

## 6. Exact R322 application, domination, and what remains open

Put the original R322 capacity-failure gate into `M` at its actual capturing endpoint, and apply (15) to that exact positive subtraffic. Every part of that failure traffic in the good source, small-packet branch, large-packet branch, or accepted middle fraction is now paid. The only failure traffic left is (9) WITH the original R322 failure gate and all original spatial/softness/posterior gates. No assertion that the binary stopping labels coincide with the earlier R322 partition is required.

For optional matched `τ≥ν`, construct the stopping boxes from `τ`. Then outside `Ω`, `ν≤τ≤K`, and inside a box its `ν` average is at most `2K`. Thus (6), (13) still use `Wν`; (14) instead costs `4λv_t τ(Ω)/K`, since `|D|<τ(D)/K`. This extra source budget must be identified explicitly. On the R321 matched coupled lineage one may use `τ=βᶜ` or `τ=f`; it does not identify the abstract row source `β` with either one. The main theorem takes `τ=ν` and needs no source ordering.

The missing estimate is now an actual intermediate-scale boundary source integral, not a high-average class:

\[
 N_{\rm bdry}\le\int_E \rho(u)R(u)^{-n}
 \sum_{D:\ d_D/t<R(u)<t\delta_D}
 [1-\theta_D(u)]\,\nu(D\cap Q_{R(u)}(u))\,du.             \tag{19}
\]

The positive loss `B_bdry` is sharper than this baseline, retaining its full second endpoint, original `J`, and capture/miss factor. The current contract does not bound (19) or `B_bdry` by a root source fee. Summing a radial envelope for each intermediate collar can still have `n log(2t²)` scale cost; that is not silently declared logarithmic. No control of original boundary density, and no uniform positive accepted fraction, follows from (5). This limitation preserves the genuinely unpaid geometric task.

To absorb the `εX_ρ` in (18), the application must supply its already-proved original entrance and the certified outer FIRST-occupancy budget. For a family of original slots with nonnegative outer weights `c_V`, the output term is exactly `ελ Σ_V c_V∫ρ_V`, not `ελ Σ_V c_V|E_V|`. Thus an outer M3 certificate for the former may be used without presuming a certificate for the latter. The source fees likewise sum with their actual outer weights and require the original source-conservation ledger; reusing the same source in several slots is not free. Each slot retains its original full `J_V` under all endpoint restrictions. This note neither certifies that global entrance/M3 budget nor spends an unrecorded absorption reserve. There is no free `ns≤D` or changed source/receiver selector.

## 7. Executed finite diagnostics and minimal reproduction

The following local Python/Fraction run returned

`PASS {'parent_volume':378,'stop_mean':24,'density_cap':3,'mass':3,'allocation':600,'row_comparison':75,'small_containment':294,'large_volume':40} total 1417`.

It checks finite binary source trees in `n=1,2,3`, the factor-two stop, source conservation, exact three-way allocation, and the simultaneous positive row comparison. The infinite-tree argument and maximal-L² theorem above are proofs/inputs, not consequences of these finite tests. These diagnostics do not certify original low-pe/history eligibility. No separate test file was written.

```python
from fractions import Fraction as F
from itertools import product
from math import prod
ct=dict(parent_volume=0,stop_mean=0,density_cap=0,mass=0,
        allocation=0,row_comparison=0,small_containment=0,large_volume=0)
def volume(B): return prod(y-x for x,y in B)
def overlap(B,C):
    return prod(max(F(0),min(y,v)-max(x,u))
                for (x,y),(u,v) in zip(B,C))
for n in (1,2,3):
    depth=6; root=tuple((F(0),F(1)) for _ in range(n)); nodes={():root}
    for lev in range(depth):
        for path in [v for v in nodes if len(v)==lev]:
            B=nodes[path]; i=lev%n; mid=sum(B[i])/2
            for bit in (0,1):
                C=list(B)
                C[i]=(B[i][0],mid) if bit==0 else (mid,B[i][1])
                nodes[path+(bit,)]=tuple(C)
                assert volume(nodes[path+(bit,)])*2==volume(B)
                ct['parent_volume']+=1
    leaves=[p for p in nodes if len(p)==depth]
    vals=(F(0),F(0),F(0),F(0),F(1,4),F(1,2),F(1),F(4))
    den={p:vals[i%8] for i,p in enumerate(leaves)}
    def mass(B): return sum(den[p]*overlap(B,nodes[p]) for p in leaves)
    assert mass(root)<=volume(root)
    stops=[]
    for lev in range(1,depth+1):
        for p in [p for p in nodes if len(p)==lev]:
            if any(p[:len(s)]==s for s in stops): continue
            if mass(nodes[p])>volume(nodes[p]):
                stops.append(p); avg=mass(nodes[p])/volume(nodes[p])
                assert 1<avg<=2; ct['stop_mean']+=1
    owner={p:next((s for s in stops if p[:len(s)]==s),None) for p in leaves}
    good=[p for p in leaves if owner[p] is None]
    assert all(den[p]<=1 for p in good); ct['density_cap']+=1
    assert (sum(mass(nodes[s]) for s in stops)
            +sum(den[p]*volume(nodes[p]) for p in good)==mass(root))
    ct['mass']+=1
    def gmass(Q):
        return (sum(den[p]*overlap(nodes[p],Q) for p in good)
                +sum(mass(nodes[s])*overlap(nodes[s],Q)/volume(nodes[s])
                     for s in stops))
    for R,x0 in product((F(1,16),F(1,4),F(1),F(4),F(16)),
                        (F(-1,4),F(1,4),F(1,2),F(3,4),F(5,4))):
        x=(x0,)+(F(1,2),)*(n-1)
        Q=tuple((v-R/2,v+R/2) for v in x)
        Qbig=tuple((v-(1+F(1,n))*R/2,v+(1+F(1,n))*R/2) for v in x)
        regular=sum(den[p]*overlap(nodes[p],Q) for p in good)
        for s in stops:
            D=nodes[s]; lo=min(y-x for x,y in D); hi=max(y-x for x,y in D)
            small=hi<=R/(2*n); large=R<=lo/(2*n)
            middle=not(small or large); assert not(small and large)
            theta=overlap(D,Q)/volume(D)
            reg=F(1) if small else theta if middle else F(0)
            big=F(1) if large else F(0)
            rest=(1-theta) if middle else F(0)
            assert reg+big+rest==1; ct['allocation']+=1
            if overlap(D,Q)>0:
                I=tuple((max(x,u),min(y,v)) for (x,y),(u,v) in zip(D,Q))
                regular+=mass(I)*reg
            if small and overlap(D,Q)>0:
                assert all(u<=x and y<=v for (x,y),(u,v) in zip(D,Qbig))
                ct['small_containment']+=1
            if large:
                side=lo/(2*n); expanded=prod(y-x+side for x,y in D)
                assert expanded<=volume(D)*(1+F(1,2*n))**n
                ct['large_volume']+=1
        assert regular<=gmass(Qbig); ct['row_comparison']+=1
print('PASS',ct,'total',sum(ct.values()))
```

Only `/tmp/r323_smoothing.md` is authored here. No other author's files or Git were changed.
