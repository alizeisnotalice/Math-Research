# R323 — hard-source cumulative payment and a legitimate shared-source restart

## Outcome

There is a general root-priced positive allocation inside the R322 recent/middle/source-capacity-failure baseline. Define the ACTUAL hard incidence row

    V_z(x)=1_E(x)c_x(z)/(q(x)R(x)^n),
    K_z(r)=integral_(R(x)<=r) V_z(x)dx.                         (1)

For every fixed G>0, the portion of that baseline with K_z(r)<G costs at most

    lambda G W_nu.                                           (2)

This holds for general common softness s, all actual L/R ratios, arbitrary admissible alpha, original full J, and arbitrary positive endpoint masks. No source density, source concentration, source order, or replacement of the hard source is required. Choosing lambda G of root/log order gives a root/log source bill. The actual complement has BOTH J_y(r)>=H and K_z(r)>=G, in addition to every previous recent/middle/capacity-failure condition. The entire original capture square remains in the signed interface.

On the explicitly matched beta<=f, q=P_(s,L)*f slot, a second useful fact is

    B_H[alpha]<=B_H[1],                                      (3)

with the SAME E,s,L,R,q,beta,nu,H. This is a proved monotonicity comparison at the original B_H entrance, not an exchange of an enlarged square in the old Phi_core. The unmasked field still satisfies FIRST by actual source domination and actual q. One can therefore restart the existing R302/R320/R322 source ledger on this unmasked field without adding a new source/X fee. It removes the arbitrary-alpha obstruction to subsequent shared-source arguments, but does not itself prove a bound for B_H[1].

Neither (2) nor the valid restart closes the general root theorem. The remaining double-high cross-Gram geometry is specified below. No high-softness or enlarged concentrated-source branch is claimed as new progress.

## 1. Original core and the new disjoint allocation

Keep the R302 original U_y=1_E alpha P_(s,L)(x-y)/q, J_y(r), A_yz(r), and

    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    ell_n([R,b])=R^(-n), q_-<=q<=lambda.

Use the same frozen actual source partition nu=sum_j nu_j, nu_j supported in D_j, m_j=||nu_j||. Its R322 failure condition is strict:

    m_j<lambda R(u)^n/sqrt(n).

The recent-layer condition is r<kappa R(u), with the already chosen kappa^n>=A_n. The capturing endpoint and the other endpoint retain their original roles. In particular the w endpoint and the denominator J_y(r) retain all old receivers.

Let M_core(y,z,r,u,w) in [0,1] denote the actual conjunction of these failure/recent/middle conditions and any remaining original positive masks. Its two endpoints lie in R(u),R(w)<=r. Define

    N_core=integral beta(dy)nu(dz)ell_n(dr)1_(J>=H)/J
                *integral U_y(u)U_y(w)c_u(z) M_core du dw,
    E_full=integral beta(dy)nu(dz)ell_n(dr)1_(J>=H) A_yz(r)^2/J,
    Phi_core=N_core-E_full.

The original physical v=1 is used here. A frozen endpoint-independent weight v<=1 and additional endpoint-dependent positive masks can be inserted in the positive baseline estimates; a tent weight recalculated from changed A,J is not silently frozen in the restart (3).

Insert 1_(K_z(r)<G)+1_(K_z(r)>=G)=1 in N_core. Call the pieces N_core,lowK and N_core,highK. This is an EXACT disjoint positive allocation. Then

    Phi_core <=lambda G W_nu+Phi_double,
    Phi_double=N_core,highK-E_full.                           (4)

Both terms subtracted in Phi_double remain finite, separately bounded by the original F1<=A_nW_nu. The square is NOT restricted to the high-K source set or to the original core masks. In a separately chosen positive-loss interface, the analogous low-K oriented loss is paid by its baseline and the retained complement is the positive high-K loss; one must not add E_full to that positive interface.

## 2. Proof of the universal hard-side prefix receipt

Integrate the original w endpoint to its full J, and drop only positive restrictions. FIRST then gives

    N_core,lowK
       <=integral nu(dz)ell_n(dr)1_(K_z(r)<G)
                       integral_(R(u)<=r) rho(u)c_u(z)du
       <=integral nu(dz)ell_n(dr)1_(K_z(r)<G)
                       integral_(R(u)<=r) c_u(z)du,

where rho(u)=integral U_y(u)beta(dy)<=1_E(u). By (1),

    c_u(z)1_E(u)=q(u)R(u)^n V_z(u)<=lambda R(u)^n V_z(u).

For each z push V_z(u)du forward by the ACTUAL R(u), obtaining a finite measure eta_z on [a,b]. Its inclusive CDF is K_z(r). Positive Tonelli and monotonicity give

    integral ell_n(dr)1_(K_z(r)<G)
                    integral_[a,r] s^n eta_z(ds)
      <=integral 1_(K_z(s)<G) s^n eta_z(ds) ell_n([s,b])
      =integral 1_(K_z(s)<G)eta_z(ds)<=G.                    (5)

The last step is the inclusive-CDF prefix-mass fact. An entire same-radius atom that jumps across G is excluded; an atom landing at G is excluded by the strict low gate. Equality K=G belongs to the retained high-K part. The top radius b atom in ell_n is retained through its exact inclusive tail. Equations (5) and the preceding display prove (2).

Finiteness is direct and does not require a density cap:

    K_z(b)<=q_-^(-1) integral sup_(a<=R<=b) h_R(x-z)dx
            =A_n/q_-.

The new hard row is an explicitly defined integral on the ACTUAL E and ACTUAL selected R,q. It is not a private capture tree, a freely translated receiver set, or a hypothetical posterior. This proof uses the same elementary prefix mechanism as R302 on the other source side; it is not presented as a new abstract prefix lemma.

## 3. Choices, exact fees, and success/failure meaning

A useful shared choice is G=H, where the original R302 threshold is

    H=sqrt(d A_n/(4lambda)), S=sqrt(lambda d A_n).

Then lambda G=S/2. Thus (4) adds (S/2)W_nu at the B_H level, S W_nu after the original factor 2 in T_target, and Lambda S W_nu after the old recovery Lambda=128/119. It adds zero X loss. Alternatively choose G=C sqrt(n)log^A(n+2)/lambda with the displayed C and A and pay the resulting coefficient exactly.

In the R322 G322 ledger, replace

    2Lambda L_out[Phi_core]

by

    2Lambda lambda G W_nu + 2Lambda L_out[Phi_double]

when G is common. If G varies with genuine outer data, keep the actual weighted sum of lambda G||nu_V||. Keep all other source costs, the original lambda d/aspect dependence, the old-layer option, and the rectangle inflation costs exactly once. This is a replacement of the original residual slot, not another independent copy of the near/far/old/shape prices.

The success event is the explicitly tested K_z(r)<G, not small individual m_j. The failure event is K_z(r)>=G. Arbitrarily refining a source partition can make every m_j small without making K_z small; hence capacity failure alone cannot supply the new gate or a Schur smallness factor. The receipt pays a genuine low-incidence portion of the dispersed-source core, but makes no claim that it has a uniformly positive coverage fraction.

## 4. Removing alpha by an actual matched-source comparison

This paragraph requires the EXACT matched old slot beta=beta^c<=f and q(x)=P_(s(x),L(x))*f(x). Define

    Ubar_y(x)=1_E(x)P_(s(x),L(x))(x-y)/q(x).

Then U_y<=Ubar_y and

    integral Ubar_y(x)beta(dy)
      <=1_E(x) P_(s(x),L(x))*f(x)/q(x)=1_E(x).

All actual receiver selectors and same-radius hard-source caps remain unchanged. This proves FIRST for the new field, rather than granting it to an arbitrary enlargement.

For a finite receiver measure mu and a fixed capture indicator c_z, write

    V_z(mu)=integral c_z dmu -(integral c_z dmu)^2/mu(total),

with zero on an empty row. If another finite positive measure sigma is added, the exact two-block variance identity is

    V_z(mu+sigma)=V_z(mu)+V_z(sigma)
          +Jk/(J+k)(p-b)^2>=V_z(mu),                       (6)

where J=mu(total), k=sigma(total), p=mu(c_z)/J, and b=sigma(c_z)/k; empty blocks are handled by their zero contribution. Apply this to mu=U_y1_(R<=r)dx and sigma=(Ubar_y-U_y)1_(R<=r)dx, then integrate in nu(z). Since Jbar>=J, the gate 1_(J>=H) is also monotone. Thus (3) follows.

This use of (6) is a transfer argument employing the additional matched q/source contract, not a rediscovery of the R313 ANOVA identity. It applies to the physical B_H. It does not assert Phi_core[alpha]<=Phi_core[1], monotonicity of the separately chosen tent formula, or preservation of the old numerical A,J under unmasking.

To use (3), restart from the original T_target<=root_source+2B_H[alpha], insert B_H[alpha]<=B_H[1], and apply R320/R322/(4) afresh to Ubar. Existing receipts are not added twice. Their source constants, h,t,kappa and fixed source partition remain valid because their hypotheses and envelope bounds hold for Ubar; their actual baseline allocations and whole square are now those of Ubar. Alternatively, R302 directly permits choosing this dominating alpha=1 row at its entrance. Other original eligibility/target masks stay in the target that this row dominates; they are not claimed to be identities of the enlarged B_H.

## 5. Genuine cross-Gram geometry and its unresolved double-high step

For a fixed actual prefix r, use the receiver Hilbert space L2(E intersect {R<=r},dx) and define

    F_y(x)=sqrt(q(x)R(x)^n) U_y(x),
    G_z(x)=c_x(z)/sqrt(q(x)R(x)^n).

Then exactly, for general original softness and aspect,

    A_yz(r)=<F_y,G_z>,
    ||G_z||_2^2=K_z(r),
    ||F_y||_2^2=integral qR^n U_y^2
                  <=integral (R/L)^n U_y.                  (7)

The inequality uses alpha<=1 and P_(s,L)<=L^(-n). If the actual receiver support has the retained aspect v=min(1,(L/R)^(n/2))>=v0, it is at most v0^(-2)J_y. If that receiver qualification has not been retained, one must instead keep the displayed integral or the full (b/a)^n bound; no aspect price disappears.

The retained whole square is exactly the squared cross-Gram size

    E_full=integral beta(dy)nu(dz)ell_n(dr)1_(J>=H)
                          |<F_y,G_z>|^2/J_y.               (8)

Thus double-high J_y,K_z does not by itself give a lower bound on (8): it gives large row masses or norms, while the correlation of F_y and G_z is the missing quantity. Two-sided Schur bounds control operator norms ABOVE, not this correlation BELOW. The allowed F05 elementary Schur principle therefore does not convert the source-label failure threshold into a lower bound for the negative square.

For completeness, the actual hard factor has a valid two-sided Schur bound. As an operator L2(nu)->L2(dx), G has kernel G_z(x). Choose receiver weight w(x)=sqrt(q(x)R(x)^n) and source weight 1. Its actual source row sum satisfies

    integral G_z(x)nu(dz)
      <=4lambda R(x)^n/sqrt(q(x)R(x)^n)
      <=(4lambda/q_-)w(x),

using only the same actual selected-radius nu cap. Its receiver column sum satisfies

    integral_(R<=r) G_z(x)w(x)dx
       =integral_(E,R<=r)c_x(z)dx<=r^n,

because those receivers lie in Q_r(z). Hence ||G||^2<= (4lambda/q_-)r^n. Both sides are checked against their stated measures; no measure-density replacement is used.

The special hard matched case s=0,L=R,alpha=1 gives F_y=G_y, J_y=K_y, and A_yz=A_zy is a PSD Gram kernel on the matched source base beta. Actual q=h_R*f and beta<=f improve its source row inequality to integral G_y beta<=w. The same column bound yields ||G:L2(beta)->L2(dx)||^2<=r^n. This confirms an exact source symmetry in that special case. General s,L give the cross-Gram (7), not that same Gram matrix; neither the symmetry nor its norm can be silently transferred.

This special Gram improvement still does not pay the complete multiscale double-high core. No bound of the form N_core,highK-E_full<=epsilon X+C sqrt(n)log^A W has been proved here, even on this special case. A successful continuation must control the actual cross-Gram correlations or use the genuine self-normalization to reduce the aggregate positive high/high baseline. Source order alone and the two verified Schur upper bounds do not provide that step.

## 6. Local executed check and stopping point

A local standard-library Python run performed 1,595 exact Fraction checks of (2). It used finite receiver/source arrays, nonconstant q in [3/4,1], unequal receiver volumes, repeated radius atoms at both endpoints, original full J with a nonzero H gate, and nonsymmetric endpoint masks in [0,1]. Thresholds included exact positive K values, so whole crossing/equality atoms were tested. Every computed low-K baseline was <=G W_nu for lambda=1.

These are algebra/radius-atom diagnostics, not claimed realizations of the complete soft/history/low-pe model. The analytic proof (5) supplies the original continuous-input result. No smoothing code, new source-partition construction, or high-softness test was duplicated.

Only `/tmp/r323_core_geometry.md` is authored. The source-incidence root receipt and matched unmask transfer are proved; the resulting double-high general root budget remains open. Work stops at this exact scope, with no Git operations or changes to other agents' files.
