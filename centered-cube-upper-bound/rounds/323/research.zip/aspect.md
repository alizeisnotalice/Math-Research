# R323 — quarter-power actual witness bridge and an explicit low-soft aspect tail

Scope: one original outer-data/clock instance of the raw low-pe, `m>M` traffic. This is a bounded improvement of its aspect entrance, not payment of its whole extreme-aspect complement or of the complete weak event. All references `r::member:lines` mean `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/r/research.zip`, the stated member and one-based lines. No repository files were changed.

## 1. Actual target and what was already available

Keep exactly the original fields and sources in `299::r299_geometry.md:5–17` and `302::r302_geometry.md:5–18`:

\[
dT=I_0(x,y,z)\frac{p_y(x)h_{R(x)}(x-z)}{q(x)}\,dx\,\beta(dy)\nu(dz),
\quad p_y=P_{s(x),L(x)}(x-y),
\]

`a<=L,R<=b<=2a`, `q_-=3lambda/4<=q<=lambda`, arbitrary finite positive L1 sources, the original accepted set E, original FIRST and same-receiver hard cap. The complete original `m,e_g`, unique ratio band and history/source masks remain inside I0. Put

\[
v=\min\{1,(L/R)^{n/2}\},\quad
\kappa_0=\frac{2K}{(1+\log n)M},\quad
\gamma=1+1/n,\quad G=\gamma^{n/2},
\quad\psi_\infty=3-\frac{2}{3\gamma^n}.
\]

On this ACTUAL target, not on an arbitrary full-soft row, the two proven heights are

\[
p_y\le\kappa_0(LR)^{-n/2},\qquad
p_y\le\kappa_0G L^{-n/4}R^{-3n/4}.                 \tag{H}
\]

The second holds in BOTH orientations (`299::r299_geometry.md:48–62`). Earlier `296::spatial_geometry.md:58–84` used that second height with the fixed lower scale a. Earlier `298::r298_capture_geometry.md:75–82` and `299::r299_geometry.md:66–113` used it in the own-witness envelope, but with the old half-power penalty

\[
\chi_r=\min\{1,(L/r)^{n/2}\min[1,(R/r)^{3n/2}]\}.       \tag{1}
\]

Thus the second height itself, or its 3/4 shell decay, is not new here. The improvement below uses its matching QUARTER-power penalty before the common-rate rank bridge.

The authentic old low gate has `K_orig=1`; an enlarged K>=1 only gives a positive enlarged target, and K<1 leaves its omitted strip. This K is not the independent R322 radial cutoff. No `ns<=D`, source density cap, or `beta+nu<=f` is assumed.

## 2. New single-witness receipt, with all receiver integration retained

For a frozen accepted witness u, write r=R(u) and define

\[
\chi'_r(L,R)=\min\{1,(L/r)^{n/4}\min[1,(R/r)^{7n/4}]\}.  \tag{2}
\]

For R<r, (H) and (2) give

\[
I_0p_y\chi'_r h_R(x-z)
\le\kappa_0G r^{-2n}1_{Q_R(z)}(x)
\le\kappa_0G r^{-2n}1_{Q_r(z)}(x).                   \tag{3}
\]

For R>=r, `L^(-n/4)min(1,(L/r)^(n/4))<=r^(-n/4)`, so the product is at most

\[
\kappa_0G r^{-n/4}R^{-7n/4}1_{Q_R(z)}(x).           \tag{4}
\]

Consequently the SAME positive envelope for all actual scales is

\[
E'_r(x-z)=r^{-n}\sup_{r\le t\le b}
t^{-n}(t/r)^{-3n/4}1_{Q_t(z)}(x).
\]

The inner block (3) is already its t=r member; it is not summed over smaller R. Cube-shell integration yields the exact finite-window price

\[
\int E'_r\,dx=r^{-n}\Psi_{3/4}((b/r)^n),\qquad
\Psi_{3/4}(B)=1+\int_1^B w^{-7/4}dw
=\frac73-\frac43B^{-3/4}\le\frac73.                 \tag{5}
\]

Thus any fixed `0<=omega(y,z)<=1`, supported in the actual witness cube, obeys

\[
\int I_0p_yh_R\,\omega\chi'_r/q\,dx\,\nu(dz)
\le\frac{\kappa_0G}{q_-}r^{-n}\Psi_{3/4}((b/r)^n)
\int\omega(y,z)\nu(dz).                             \tag{6}
\]

The dx extension occurs only AFTER (H) has been used on the original target. By the original witness cap `nu(Q_r(u))<=4lambda r^n`, the whole-witness cost is at most `(112/9)kappa0 G`. The hard cap is never transferred to a smaller unsupported cube.

On L<=R, `chi'_r>=chi_r` for every r. If R<r the ratio of the raw penalties is `(R/L)^(n/4)>=1`; if R>=r it is the quarter versus half power of L/r. This monotonicity need not hold for L>R. To retain ALL old paid allocations globally use

\[
\chi^\vee_r=\max(\chi_r,\chi'_r),\quad
C_\vee=\psi_\infty+\frac73G.                        \tag{7}
\]

Since `max<=sum`, its single-witness fee is at most `(kappa0 C_vee/q_-)r^(-n)nu(omega)`. This unoptimized sum is deliberate. Both penalties, and their maximum, decrease as the witness radius r increases.

For `pi_y=U_y du/I_y`, put `D^vee=integral chi^vee_(R(u))1_capture pi_y(du)` and `H_N^vee=1-(1-D^vee)^N`. The exact finite product averaging of `299::r299_geometry.md:115–130` gives

\[
T_{H_N^\vee}\le\frac{16}{3}\kappa_0C_\vee N W_\beta. \tag{8}
\]

This is an actual monotone enlargement of the R299 paid allocation. Its increment is positive whenever a positive-traffic set has `D^vee>D_old`; no universal capture fraction or complete historical realization is asserted. The exact leftover remains `T_(1-H_N^vee)`. On the separately declared L<=R branch, C_vee can be replaced by `(7/3)G` using chi' alone.

## 3. Exact common-rate bridge: inverse-aspect exponent halves

Choose the SAME original z-independent admissible row mask alpha as in `302::r302_geometry.md:7–11`, dominating the target being estimated. Set

\[
U_y(u)=\alpha(u,y)1_E(u)p_y(u)/q(u),\quad
A_{yz}(r)=\int_{R(u)\le r}1_{Q_{R(u)}(u)}(z)U_y(u)du,
\quad J_y(r)=\int_{R(u)\le r}U_y(u)du.                \tag{9}
\]

Use a common Poisson rate t against `U_y du`, not against normalized pi_y. Give each captured source to a minimum-radius witness (ties by index), and define

\[
B_t(y)=\mathbb E\int\max_i[r_i^{-n}1_{Q_{r_i}(u_i)}(z)]\nu(dz),
\quad C_t=\int B_t(y)\beta(dy).
\]

These are LITERALLY the R301 quantities (`301::r301_geometry.md:40–58`), with the same finite source costs. As chi^vee decreases in r, the maximum penalized capture also uses that minimum-radius witness. Summing (6) and the old receipt over its disjoint source pieces therefore proves

\[
T_{\mathbb EH^\vee_{\max}}\le(\kappa_0C_\vee/q_-)C_t.\tag{10}
\]

The prefix lower bound now is, in BOTH orientations,

\[
r\le R\ \Longrightarrow\ \chi^\vee_r\ge\chi'_r
\ge\min(1,(L/R)^{n/4})=\sqrt v.
\]

Hence on v>=v0,

\[
1\le\frac{\mathbb EH^\vee_{\max}}{\sqrt{v_0}}
+e^{-tA_{yz}(R)}.
\]

The second term is bounded by `C_t/t` using the unchanged inclusive-CDF atom calculation in `301::r301_geometry.md:70–99`. No altered source measure, rank, or row normalization appears. Thus

\[
T_{v\ge v_0}\le(d_\vee+1/t)C_t,\qquad
d_\vee=\frac{\kappa_0C_\vee}{q_-\sqrt{v_0}}.         \tag{11}
\]

At `t=1/d_vee`, `d_vee(1-exp(-A/d_vee))<=min(d_vee,A)` and the ORIGINAL positive layer identity give

\[
T_{v\ge v_0}\le2O_{d_\vee},\qquad
O_d=\int\beta(dy)\ell_n(dr)\nu(dz)\min(d,A_{yz}(r)),\tag{12}
\]

`ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr`. The layer variable has not replaced original dx. R302's ORIGINAL `Q=JM-integral A^2 dnu` and boundary fee

\[
B_H=\int\beta(dy)\ell_n(dr)1_{J_y(r)\ge H}Q_y(r)/J_y(r)
\]

therefore remain exactly unchanged for a FIXED H. The established R302 clipping inequality (`302::r302_geometry.md:26–56,71–88`) gives

\[
T_{v\ge v_0}\le8\lambda H W_\beta
+\frac{2d_\vee A_n}{H}W_\nu+2B_H,\quad
A_n=1+n\log(b/a).                                   \tag{13}
\]

One may use `d_eff=min{d_old,d_vee}`, with `d_old=kappa0 psi_inf/(q_-v0)`: both complete entrances hold for the same row fields, and O_d is increasing. This avoids worsening small dimensions or mild aspects. It is not a free supremum of unrelated source choices.

If H is reoptimized, it must be renamed: for `H'=sqrt(d_eff A_n/(4lambda))`,

\[
T_{v\ge v_0}\le4\sqrt{\lambda d_{\rm eff}A_n}
(W_\beta+W_\nu)+2B_{H'}.                            \tag{14}
\]

The inverse-aspect power of the explicit source coefficient improves from `v0^(-1/2)` to `v0^(-1/4)`; the d parameter improves from `v0^(-1)` to `v0^(-1/2)`. Equivalently the new entrance down to v0 squared has comparable order to the old entrance down to v0. If retaining the old H is necessary for a frozen middle decomposition, use (13), with that SAME B_H and its full square. Neither (13) nor (14) pays B_H or the remaining v<v0.

## 4. Actual soft profile: one explicit paid extreme tail

On L<=R the second height gives the useful normalized bound

\[
F_s((x-y)/L)=p_y(x)L^n\le\kappa_0G v^{3/2},\quad
F_s(u)=\prod_{i=1}^n[(1-s)h(u_i)+s\phi(u_i)].        \tag{15}
\]

Here `h=1_[-1/2,1/2]`, `w(t)=integral_0^1 exp(-|t|/r)dr`, `phi=h*w` are authentic (`116::proof.md:22–27,262`). For t>=0,

\[
\phi(1/2+t)=\int_0^1r(1-e^{-1/r})e^{-t/r}dr
\le\tfrac12e^{-t},\qquad 0\le\phi\le1.
\]

Thus `integral sqrt(phi)<=1+2sqrt(2)<4`. Fix the actual branch

\[
\mathcal A=\{s(x)\le1/4096,\ v(x)\le2^{-n/4}\}.
\tag{16}
\]

This condition implies L<R. It is an actual traffic restriction, not an assumption `ns<=D`. With `s0=1/4096` and `g(u)=sqrt(h(u)+s0 phi(u))`,

\[
F_s1_{\mathcal A}\le\sqrt{\kappa_0G}\,2^{-3n/16}
\prod_i g(u_i),\qquad
\int g\le1+\sqrt{s_0}\int\sqrt\phi<17/16.           \tag{17}
\]

The product g is ray-decreasing. Its full dilation envelope for L in[a,b] has L1 mass at most `A_n(integral g)^n`: this follows by layer-cake into star-shaped superlevel sets, whose dilation indicator envelopes have mass exactly `A_n` times the set volume. It also covers jumps of h, with no differentiability assumption. First apply the original receiver cap `h_R*nu<=4lambda` and `q>=q_-`, then positively extend dx using (17). This proves the SOURCE receipt

\[
T_{\mathcal A}\le\frac{16}{3}A_n\sqrt{\kappa_0G}
2^{-3n/16}(17/16)^n W_\beta
\le\frac{16}{3}e^{1/4}\sqrt{\kappa_0}A_n e^{-n/16}W_\beta
\le\frac{256}{3}e^{1/4}\sqrt{\kappa_0}W_\beta.        \tag{18}
\]

The estimates used are `G<=sqrt(e)`, `log2>2/3`, `log(17/16)<1/16`, `A_n<=n+1`, and `(n+1)e^(-n/16)<=16`. The last uniform constant is intentionally loose. All full m/e_g gates, actual source masks and unique j are retained until they are dropped positively; there is NO independent sum of this source fee over ratio bands. This gives a concrete payable aspect/softness family with its complete complement retained.

Priority/novelty qualification: R294 already supplied a fractional-full-profile mechanism, including `R_delta=integral H_sigma^(1-delta)` and its dimension dependence (`294::joint_geometry.md:211–248`). Equation (18) is an explicit uniform small-softness/tiny-aspect specialization of that mechanism using the global height (15), not a claim to have discovered fractional moments anew. It establishes an unconditional receipt for the defined actual subset, not a full historical nonempty fixture or an exhaustive extreme-aspect payment.

## 5. Exact replacement in the current ledger; complete complement

Take any frozen cutoff `0<v0<=1`. In the exact R322 split, write

\[
T_{\rm extreme}=T_{v<v_0,\,\mathcal A}
+T_{v<v_0,\,\mathcal A^c}.                           \tag{19}
\]

The first term is bounded by (18). The second is the original positive dx integral with precisely these extra gates:

`v<v0` AND `[s>1/4096 OR v>2^(-n/4)]`.

Endpoint choices are exact: (16) uses inclusive <=, so its complement uses strict >; the old extreme split is still strict v<v0. For v>=v0 use (13) with the SAME H if preserving the already selected R320/R322 boundary decomposition. Replace its explicit R302 entrance source terms by (13), not by an additional copy of them; retain the same B_H, including its full square and the R322 old-layer/source-shape priority. If instead using (14), rerun that decomposition at H', explicitly.

At the authentic old outer price `Lambda=128/119`, (18) adds at most

\[
\Lambda\frac{16}{3}e^{1/4}\sqrt{\kappa_0}A_n e^{-n/16}W_\beta
\]

and leaves `Lambda T_(v<v0,A^c)`. The source terms and `2B_H` in (13) also carry Lambda ONCE; the factor2 is the common-rate/clipped-capacity factor, not an old high-branch factor. For authentic varying outer parameters retain the corresponding weighted source integral; use an existing common source budget only when those parameters are common or uniformly bounded. No source-disjointness between (18) and the (13) cost is claimed; their source fees add. There is zero new X absorption coefficient.

For an optional finite-cover payment of the second term, use its actual allocation H_N^vee from (8) and retain `T_(v<v0,A^c,1-H_N^vee)` exactly. Its extra source fee is `(16/3)kappa0 C_vee N W_beta`, times the original outer coefficient, in addition to (18). This optional allocation must not also be counted as a whole-branch common-rate payment. N=ceil(sqrt(n)) is root order with its displayed kappa0.

The full signed R322 `Phi_core=N_core−E_full` can remain at fixed H. Its independent wide/source geometry, initial I, actual jumps J, future-deleted D, suffix slot and original entry/all-scale bridges have not been paid here. In particular choosing `v0=2^(-n/2)` still makes (14)'s source coefficient exponential. The improvement does not make the full legal aspect interval root order.

## 6. Actual local arithmetic checks and their limits

Executed local Python 3 using `fractions.Fraction` and `math`, with no new files other than this note: 465 exact rational assertions passed. With `X=(L/r)^(n/4)`, `Y=(R/r)^(n/4)`, the grid `{1/4,1/2,3/4,1,5/4,3/2,2,4}` checked (3)–(4), `chi'>=chi` when X<=Y, the prefix `chi'>=min(1,X/Y)` when Y>=1, admissibility of their maximum, inclusive endpoint clipping `min(d,A)<=dA/J+A(J−A)/J`, and (5) for rational B=t^4. These are finite arithmetic checks supporting, not replacing, the universal algebra above.

For v0=1/(n+1), the following ordinary floating-point diagnostics used the exact displayed formulas. Units of d are kappa0/q_-; the last ratio is the optimized explicit source coefficient ratio, before taking min with the old bound:

| n | old d units | new d_vee units | sqrt(new/old) |
|---:|---:|---:|---:|
| 1 | 5.33333333333 | 8.43790283299 | 1.25781826238 |
| 4 | 13.6346666667 | 14.2499394714 | 1.02231385656 |
| 16 | 46.7036995716 | 26.9527689633 | 0.759671882504 |
| 64 | 178.934819574 | 53.0900938886 | 0.544702435138 |
| 256 | 707.847083566 | 105.766609504 | 0.386549012209 |
| 1024 | 2823.49301889 | 211.325675534 | 0.273579010121 |

The executed soft-cutoff arithmetic also checked `1+4/64=17/16`. The proof of (18) is analytic; these diagnostics are neither outward interval certificates nor full original source/history realizations. A direct numerical extension would evaluate the actual phi fractional norm at two precisions and compare it with the rigorous bound4; it is unnecessary for the stated theorem and was not run. No global proof claim follows from this file.
