from fractions import Fraction as F
from itertools import product
from math import prod
ct=dict(parent_volume=0,stop_mean=0,density_cap=0,mass=0,
        allocation=0,row_comparison=0,small_containment=0,large_volume=0)
def volume(B): return prod(y-x for x,y in B)
def overlap(B,C):
    return prod(max(F(0),min(y,v)-max(x,u))
                for (x,y),(u,v) in zip(B,C))
for n in (1,2,3):
    depth=6; root=tuple((F(0),F(1)) for _ in range(n)); nodes={():root}
    for lev in range(depth):
        for path in [v for v in nodes if len(v)==lev]:
            B=nodes[path]; i=lev%n; mid=sum(B[i])/2
            for bit in (0,1):
                C=list(B)
                C[i]=(B[i][0],mid) if bit==0 else (mid,B[i][1])
                nodes[path+(bit,)]=tuple(C)
                assert volume(nodes[path+(bit,)])*2==volume(B)
                ct['parent_volume']+=1
    leaves=[p for p in nodes if len(p)==depth]
    vals=(F(0),F(0),F(0),F(0),F(1,4),F(1,2),F(1),F(4))
    den={p:vals[i%8] for i,p in enumerate(leaves)}
    def mass(B): return sum(den[p]*overlap(B,nodes[p]) for p in leaves)
    assert mass(root)<=volume(root)
    stops=[]
    for lev in range(1,depth+1):
        for p in [p for p in nodes if len(p)==lev]:
            if any(p[:len(s)]==s for s in stops): continue
            if mass(nodes[p])>volume(nodes[p]):
                stops.append(p); avg=mass(nodes[p])/volume(nodes[p])
                assert 1<avg<=2; ct['stop_mean']+=1
    owner={p:next((s for s in stops if p[:len(s)]==s),None) for p in leaves}
    good=[p for p in leaves if owner[p] is None]
    assert all(den[p]<=1 for p in good); ct['density_cap']+=1
    assert (sum(mass(nodes[s]) for s in stops)
            +sum(den[p]*volume(nodes[p]) for p in good)==mass(root))
    ct['mass']+=1
    def gmass(Q):
        return (sum(den[p]*overlap(nodes[p],Q) for p in good)
                +sum(mass(nodes[s])*overlap(nodes[s],Q)/volume(nodes[s])
                     for s in stops))
    for R,x0 in product((F(1,16),F(1,4),F(1),F(4),F(16)),
                        (F(-1,4),F(1,4),F(1,2),F(3,4),F(5,4))):
        x=(x0,)+(F(1,2),)*(n-1)
        Q=tuple((v-R/2,v+R/2) for v in x)
        Qbig=tuple((v-(1+F(1,n))*R/2,v+(1+F(1,n))*R/2) for v in x)
        regular=sum(den[p]*overlap(nodes[p],Q) for p in good)
        for s in stops:
            D=nodes[s]; lo=min(y-x for x,y in D); hi=max(y-x for x,y in D)
            small=hi<=R/(2*n); large=R<=lo/(2*n)
            middle=not(small or large); assert not(small and large)
            theta=overlap(D,Q)/volume(D)
            reg=F(1) if small else theta if middle else F(0)
            big=F(1) if large else F(0)
            rest=(1-theta) if middle else F(0)
            assert reg+big+rest==1; ct['allocation']+=1
            if overlap(D,Q)>0:
                I=tuple((max(x,u),min(y,v)) for (x,y),(u,v) in zip(D,Q))
                regular+=mass(I)*reg
            if small and overlap(D,Q)>0:
                assert all(u<=x and y<=v for (x,y),(u,v) in zip(D,Qbig))
                ct['small_containment']+=1
            if large:
                side=lo/(2*n); expanded=prod(y-x+side for x,y in D)
                assert expanded<=volume(D)*(1+F(1,2*n))**n
                ct['large_volume']+=1
        assert regular<=gmass(Qbig); ct['row_comparison']+=1
print('PASS',ct,'total',sum(ct.values()))
