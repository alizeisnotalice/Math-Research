# R323 A: quarter-power penalty and finite iid bridge

The standalone standard-library script passes 1,068 exact Fraction assertions. Three scalar stages use n4,8 initial168 checks; boundary n4,8 pressure360; expanded n16,64,256 (252). A finite iid bridge adds288 checks. All physical ratios L,R,r lie in[1,2]. No B/binary-CZ work is performed.

With G=(1+1/n)^(n/2), kappa0=1, the new gate is

    chi'=min(1,(L/r)^(n/4) min(1,(R/r)^(7n/4))).

The script checks263 triples: 93 R<r transfers give p chi' R^-n<=G r^-2n; 170 R>=r transfers give <=G r^(-n/4)R^(-7n/4), using p=G L^(-n/4)R^(-3n/4). All170 latter cases also verify chi'>=sqrt(v), with sqrt(v)=min(1,(L/R)^(n/4)). Exponents are integers because every n is a multiple of4. New chi' exceeds old chi in53 cases and old exceeds new in53: the result is not uniform gate dominance, so using max(old,new) matters.

The new envelope bound7G/3 has the usual radial calculation: inside Q_r its bound isG r^-2n, while outside it isG r^(-n/4)R^(-7n/4); integrating shell volume gives G+(4/3)G after multiplying by r^n. The script independently integrates 21 FINITE centered nested-cube menus exactly, using shell-volume differences and the maximum coefficient among all larger cubes. New-only fees use ONLY the new height (not the minimum with old height), and all are <=7G/3.

The old psi=3-2/(3G^2) receipt additionally requires the original height p<=(LR)^(-n/2). It cannot be imported from the new height alone. Old and max-gate finite fees explicitly retain BOTH bounds through their minimum. All21 old, new, max and subadditivity comparisons pass; max fee<=psi+7G/3 is supported on these menus. This finite comparison is not a proof over all continuous scale selections; the analytical height/envelope argument must supply that conclusion.

Finite iid witness/rank bridge

Three witnesses have first-coordinate centers -1/2,0,1/2 and L=R=1,3/2,2, with probabilities1/6,1/3,1/2. Sources are three finite points at first coordinate -1,0,1; other coordinates are0. Actual centered cube incidence is computed, then one common uniform mark gives capture probability max(chi,chi') times that incidence. These are explicitly FINITE ATOMS, not an original positive-L1 realization.

For n4,16, r1,3/2,2 and N1,2,3, every witness tuple is enumerated. All54 capture comparisons give1-(1-D)^N. All162 minimum-captured-radius increments give(1-D_prev)^N-(1-D_current)^N, with54 total-rank-mass checks. Another18 two-source checks retain the COMMON mark via min(a_i(z),a_i(z')), rather than independent source marks. No capture or endpoint rank mass is discarded.

Scope: exact scalar height transfers, finite centered cube-envelope menus and finite-atom iid/mark identities only. No original FULL/history/source realization, native height provenance or root-budget closure is certified. In particular the old-height requirement is explicit. No floating-point fits or dimension-order claims are made.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r323_checks.py
```

The script prints deterministic exact JSON to stdout; it creates no JSON file. Only `/tmp/r323_checks.py` and this short note are owned outputs.
