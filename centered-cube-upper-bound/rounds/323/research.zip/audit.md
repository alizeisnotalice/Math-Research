# R323 independent preauthor screen — cyclic binary source smoothing on B_H

Ownership: only /tmp/r323_audit.md, no Git or other-author edits. This initial screen was completed before reading /tmp/r323_smoothing.md or other new author proofs. The target is the original B_H positive loss/baseline or a specified fixed-weight restriction, not a claim that B_H equals original raw traffic.

## 1. The binary CZ construction really applies to arbitrary finite positive L1 nu

Use ONE nested cyclic binary rectangular filtration on all integer levels: at level kn+j (0<=j<n), the first j coordinate side lengths are2^(k+1), the others2^k, with aligned dyadic cells. Every parent has twice the volume and two children, and all rectangles have aspect<=2. This is not the unrestricted family of all independently indexed product rectangles. At small scales it differentiates L1 (bounded eccentricity), and ancestor volumes tend to infinity so finite total mass forces their averages to zero. Thus every bad point belongs to a maximal cell with nu(D)/|D|>K, K>0. Maximal bad rectangles are pairwise disjoint and countable; their parents have average<=K, giving

 K<nu(D)/|D|<=2K.

Outside their union the original density is <=K almost everywhere. Source L1 null boundaries cause no lost mass. The mass-preserving density g=nu on the good source plus sum_D[nu(D)/|D|]1_D satisfies0<=g<=2K, integral g=Wnu and||g||2²<=2K Wnu. The factor is2, not2^n. The density cap applies to g, not the original concentrated density inside bad cells. All source stopping data is frozen before evaluating a particular receiver.

## 2. Exact positive original allocation and one common upper density

Keep original U,J,A,v,pair masks, E, physical R/L, nu and beta. Integrate the missed endpoint to the SAME full J only after positive domination, and use the original inclusive ell tail to reach the actual capturing mixed row. This permits the following source allocations without granting any component FIRST.

For small bad packets with dmax(D)<=R(u)/(2n), a captured point z in D implies D subset Q_(R+2dmax)(u) subset Q_R'(u), R'=(1+1/n)R. Hence nu_D(Q_R)<=integral_Q_R' g_D, and h_R nu_D<=c_n h_R' g_D, c_n=(1+1/n)^n<=e.

Good-source traffic is actual g_good. Its h_R g_good<=c_n h_R' g_good by positive cube inclusion. A middle whole-packet-contained source has nu_D(Q_R)=integral_Q_R g_D. Alternatively attach one frozen uniform mark in D conditional on its original source label, retaining original z and all masks. Tag acceptance in the actual Q_R multiplies that traffic by theta_D(u)=|D intersect Q_R(u)|/|D|; its row is bounded by h_R g_D since theta_D nu_D(Q_R)<=theta_D nu(D). It includes every whole-packet-contained traffic. Reject its exact1-theta complement. Neither version assumes an accepted fraction for arbitrary concentrated nu_D.

These good, small and selected middle-accepted contributions must be combined BEFORE L2/Young: the same inflated R' works, since h_R g_middle<=c_n h_R' g_middle and the source packet subsets are disjoint at each receiver. Their row is bounded by c_n h_R' g<=e M_cube g, with one actual g, not separate full g bills. M_cube is the genuine all-radius strongL2 auxiliary maximal operator; using R'>b is allowed for this NEW g response and does not invoke an original nu cap at that enlarged radius.

Consequently their combined baseline has receipt

 epsilon X_E+[e² C2² K/(2epsilon lambda)]Wnu,
 X_E=lambda|E|,

using||g||2²<=2K Wnu and Young. All original target/outer coefficients still multiply this loss and source price. It is not a certificate that this local X_E is the complete old/native output or that all global epsilon slots have been absorbed. Finite |E| is required for the direct receiver budget; original finite truncations can restrict the capturing endpoint while keeping full original J rather than assuming quotient monotonicity under row truncation.

## 3. Large packets and exact partial-middle remainder

For dmin(D)>=2nR(u), the capturing receiver support lies in D+Q_(dmin/(2n)). Its volume is

 product_i(d_i+dmin/(2n))<=e^(1/2)|D|.

The original capturing mixed row is<=4lambda, by FIRST and the ORIGINAL same-R cap for nu_D<=nu. Thus its whole baseline is<=4sqrt(e)lambda|D|<4sqrt(e)lambda nu(D)/K. Summing disjoint bad packet source masses gives4sqrt(e)lambda Wnu/K, without receiver multiplicity or box-count fee. No enlarged-radius or hard-winner assumption is used.

Small and large packet predicates are disjoint. The remaining middle packet sizes obey dmax>R/(2n) and dmin<2nR; bounded aspect can describe a polynomial size band, but does not pay its actual boundary source mass. Under the uniform-tag version, residual is exactly the original middle positive loss multiplied by1-theta_D; whole-contained packets have no rejection. Under the binary whole-contained version, retain the corresponding partially captured middle packets. This is an actual source/mark allocation with original z marginal, not source replacement by g. At K=lambda sqrt(n), the combined source price is

 [e²C2²sqrt(n)/(2epsilon)+4sqrt(e)/sqrt(n)]Wnu.

It does not prove the retained middle partial-capture/rejection fee root-order or small, and no thin boundary volume times nonexistent original density is used. The signed version can keep full capture square only by partitioning the ENTIRE positive baseline first, paying the other baselines once and retaining the complete original E_full once. A signed certificate is not the isolated positive partial-middle loss.

## 4. Unmasking is a legitimate enlargement only under its actual contract

For fixed original sources, E, R,s,L,q and capture field, U_alpha<=U_1. The functional F(mu)=A-A²/J is the capture variance of a positive receiver measure. Adding a positive receiver measure increases it by nonnegative intrinsic-block and between-block ANOVA terms. This is monotonicity under ACTUAL measure addition, not separate monotonicity in arbitrary ordered scalars A,J. The inclusive high-J indicator also only increases. Therefore B_H[alpha]<=B_H[1], with zero-J rows harmless.

This source-free variance inequality does not imply FIRST for U_1. To APPLY the new payments after unmasking, require the separate genuine cap integral P_s,L beta/q<=1 on the SAME original E. For example the matched beta<=f and actual full-soft P_s,L*f=q give it. Remove only alpha; do not enlarge E, change original sources/selectors or grant historical row qualifiers to the newly admitted auxiliary endpoints. Rebuild the enlarged B_H fields J1,A1 from U1 if choosing that bound, while original target masks remain in the target. No monotonicity of recomputed tent weight, Phi_core, source-gate allocation or signed compensated remainder is asserted. Unmasking alone has no root-source payment.

## 5. Actual bounded local tool evidence

Local Python standard-library exact Fractions:3 binary-parent mass/average checks;243 variance-addition/high-J monotonicity checks;12 small-packet interval-inclusion checks. Total258 assertions PASS. These are bounded algebra/geometry diagnostics, not native/history realizations, all-input coverage or a global weak theorem. No R322 or earlier test was repeated. The general statements above are analytic.

## 6. Current screen verdict

PASS for the precise cyclic-binary CZ construction, one-g positive L2 allocation, source-once large-packet payment, and conditional lawful unmasking. Await final author proof/integration for bounded comparison, original output/outer multiplier calibration and hash binding. The partial-middle original source geometry remains unproved; no global closure follows.

## 7. Author comparison completed

Read /tmp/r323_smoothing.md in full only after the independent screen above. SHA256 bdfbe576f6a456f600540606fc3cbfb16abcf748b371e04e2a29c12c7117432a. PASS: the cyclic filtration is one nested binary filtration; its maximal high boxes have average in (K,2K], and all original source mass enters one g. The simultaneous regularized row comparison uses one common enlarged auxiliary radius and one global g, so there is no hidden packet/scale copy of the L2 bill. The original same-R cap pays whole large packets by disjoint source-box volume. The explicit middle partial-capture tag rejection remains original traffic; it is not replaced by its averaged source. Equation (16) is an alternative signed baseline-minus-whole-overlap certificate, not an additional positive allocation. Its overlap remains the same original weighted M overlap, and becomes the whole square when M=1. The stated all-radius L2 input licenses auxiliary radii above b only for g. Finite receiver localization should keep full original J or rebuild the whole auxiliary contract explicitly; normalized quotients are not asserted monotone under row truncation.

Read /tmp/r323_aspect.md in full after the independent mechanism screen. PASS for its quarter-power witness penalty, its max with the old half-power penalty, and the unchanged common-rate C_t and inclusive rank estimate on the same U. For R<r the raw quarter penalty and the global 3/4 height give the central r^(-2n) envelope; for R>=r its shell exponent is 7/4 and exact finite-window integral is 7/3-(4/3)B^(-3/4). The source-witness price, monotonicity in r and prefix lower bound sqrt(v) are consistent. This improves the inverse-aspect exponent of the explicit source coefficient, not the complete legal aspect interval. At fixed H the SAME original B_H remains. Reoptimization uses H' and B_H', and cannot silently reuse a decomposition frozen at old H. The explicit tiny-soft/tiny-aspect fractional-profile subset is source-paid with the stated constants; its complete A^c and v<v0 complements remain. No full nonempty historical fixture or general root aspect coverage follows. The original low gate K_orig=1 versus optional K>=1 and independent radial cutoff distinctions are retained.

## 8. Independent small hard-prefix screen (before author proof)

For each fixed z define the original common-source cumulative

 K_z(s)=integral_{E,R(u)<=s} c_u(z)/(q(u) R(u)^n) du.

Keep full J and original FIRST. In any positive original loss/baseline with an added gate K_z(r)<G, cancel the missed endpoint only in a positive majorant, giving an upper bound by the capturing endpoint. Since K_z is nondecreasing and R(u)<=r, the gate implies K_z(R(u))<G. Dropping the remaining layer gate and using ell([R,b])=R^(-n) yields, per z,

 integral_E c_u(z)R(u)^(-n)1{K_z(R(u))<G}du
 =integral q(u)1{K_z(R(u))<G}dK_z(R(u))
 <=lambda integral 1{K_z(s)<G}dK_z(s)<=lambda G.

The last inequality uses the inclusive cumulative and excludes a jump crossing G; a jump landing exactly at G is also excluded by the strict gate. The same bound with <=G holds as well, since a landing atom cannot overshoot G. Thus the total positive fee is <=lambda G Wnu, with no y copy or density premise. K must use the same original accepted E, actual R,q and be common across y. It is an auxiliary original-B_H allocation, not an identity with raw traffic, and says nothing about K_z>=G. Measurability follows from the original fields and Tonelli; each fixed z cumulative is finite since a>0, q_->0 and finite E (or the actual finite-field contract).

## 9. Sharper weighted FIRST receiver budget, independently screened

Retain the actual capturing marginal rho(u)=integral U_y(u) beta(dy), rather than replacing it by1_E before Cauchy–Schwarz. The one-g comparison gives

 N_reg<=c_t integral rho M_cube g
 <=c_t (integral rho)^(1/2)(integral rho (M_cube g)^2)^(1/2)
 <=c_t C2 (integral rho)^(1/2)||g||2,

since0<=rho<=1. Young therefore yields exactly

 epsilon lambda integral rho+[c_t² C2²K/(2epsilon lambda)]Wnu.

This is the sharper source-conserving version of (13). It keeps original full J and all original fields; it requires finite integral rho, supplied by the original finite-band full-soft row envelope/source mass contract when available, rather than a sum of leaf receiver-set volumes. The large-packet source fee is unchanged, since rho<=1 still bounds each support volume. The coarse epsilon X_E statement remains a valid consequence but must not be substituted into an outer ledger that only proves the weighted M3 bound.

For AUTHENTIC matched old leaves and seeds with M3: E sum_V integral rho_V<=|E0|, the target factor2 and original outer Lambda produce new output loss2Lambda epsilon X_old. This use is conditional on exactly that authenticated common-source/seed range; it does not establish free clock copies, sum_V |E_V|<=|E0|, the missing original entrance, or whole global closure. If parameters vary by outer instance retain their weighted sum or use a justified uniform choice.

## 10. Final weighted smoothing comparison and hard-prefix author proof

The final smoothing amendment /tmp/r323_smoothing.md SHA256 4b8867be79da79de3d616370c1b2a8bc1abe9f550aa984bcab1529a98998e175 supersedes the initial bdfbe576... binding. Compared its changed contracts and every displayed Young/total receipt: (10),(13),(15),(16),(18),(19) retain original rho and X_rho=lambda integral rho. The weighted Cauchy proof and full-J endpoint-truncation safeguards are present. PASS. The mathematical source fees and exact remainder are otherwise unchanged; original finite-band integrable occupancy suffices. This refinement avoids unsupported summation of leaf receiver volumes.

Read /tmp/r323_core_geometry.md fully after the independent small-prefix proof in §8. PASS: equation(5) is the same original-J, common-hard-source positive Tonelli argument; inclusive threshold atoms and the only explicit ell b atom are retained. K_z(b)<=A_n/q_- gives direct finiteness without requiring an original source density cap. The choice G=H adds lambda G=S/2 at B level and Lambda S after factor2 and outer recovery, with zero new X loss. A varying G must retain its genuine weighted source ledger.

The core signed replacement is EXACTLY N_core,highK-E_full with the original WHOLE square; its positive alternative retains high-K capture/miss loss without a second square. The matched unmask statement has its independently proved FIRST and applies only to physical B_H, restarting the complete auxiliary decomposition rather than asserting monotonicity of old Phi or recomputed tent weights. The target's original e/m/history qualifications are not transferred to newly admitted auxiliary receivers.

The stated cross-Gram identity is correct: F_y=sqrt(qR^n)U_y, G_z=c_z/sqrt(qR^n), with ||F_y||²<=integral(R/L)^n U_y. Bounding this by v0^(-2)J requires the aspect gate on the WHOLE auxiliary receiver row; otherwise the explicit integral or full(b/a)^n remains. Both Schur estimates are genuine upper bounds under their declared source/receiver measures. In the special s=0,L=R,alpha=1 case F_y=G_y,J_y=K_y, but this does not lower-bound the general cross-correlation or pay the multiscale high/high remainder. No false PSD/norm-to-negative-square transfer appears.

## 11. Final integration verdict and exact remaining gap

Read the complete final checkpoint combined.md (SHA256 f47646d11a444849493651f57f897ee0bdcd81f11d4cb92516c1467e62d7abd7) and compared its displayed old ledger with inherited_ledger.md §11 and the three audited proofs. PASS at this bounded scope, conditional on the explicitly inherited original ledger contracts; this is not a new comprehensive audit of all historical coefficients.

The fixed-H aspect entrance replaces only the old explicit source terms; the original U,J,A,B_H and all R320/R322 baseline priorities remain fixed. Low K_z(r)<G is paid first INSIDE N_core, then the ONE frozen CZ construction splits the high-K baseline into regularized, large and middle-rejected parts. This is an exact disjoint positive priority; it does not require source-disjointness between different paid-source upper bounds. The final signed slot is N_res-E_full, with the original whole E_full subtracted once. It cannot be identified with isolated positive middle-boundary loss or original raw traffic.

The total target factor2 and original recovery Lambda multiply the new CZ output loss once:2Lambda epsilon L_out[X_rho]. The authentic M3 bound permits L_out[X_rho]<=X_old, without sum|E_V|. A fresh local exact Fraction arithmetic assertion verified2*(128/119)*(119/32768)=1/128. This is ONE additional arithmetic assertion beyond the earlier258 screen assertions; neither is merged into primary test counts. The new old-output coefficient is E_original+1/128. The missing H0 entrance coefficient, original unspecified epsilon parameters and authentic outer contract still prevent any certified general absorption. Source fees have their actual weighted source sums, with no softness-band or leaf copies silently discarded.

The complete unapportioned scope is explicit: (i) the signed Phi_res with actual intermediate packet tag rejection, J>=H and K>=G, recent/middle and original source-capacity-failure predicates; (ii) the full extreme-aspect A^c complement; (iii) independent initial I, real deletion jumps J, future-deleted D and terminal suffix/negative domains; (iv) the historical hard-band entry, physical-scale bridge and small-dimension/outer-error bookkeeping. The separate native H_rootleft is not B_H and receives no new identity. No uniform coverage fraction, boundary-density cap, cross-Gram negative-square saving or general root theorem is proved. These are genuine unresolved estimates, not merely constants or logarithms.

## 12. Evidence and hash receipt

The primary reports fresh executions of aspect and smoothing diagnostics. The actual smoothing_checks.log inspected here contains1417 exact assertions with counts parent_volume378, stop_mean24, density_cap3,mass3,allocation600,row_comparison75,small_containment294,large_volume40. Read numeric_notes.md and the aspect script scope:1068 Fraction assertions cover scalar transfers, finite centered-cube menus and FINITE-ATOM iid/common-mark identities; they are not original full-history/positive-L1 realizations. The source author reports1595 exact finite-array low-K checks; those are diagnostics, not the analytic continuous-source proof. No reviewer repeat of these tests is claimed. Only the reviewer258+1 bounded local assertions above were independently run here.

Current final bindings (SHA256):

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/smoothing.md: 4b8867be79da79de3d616370c1b2a8bc1abe9f550aa984bcab1529a98998e175

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/aspect.md: 016e4e2459fab9777302b8c5baea653d905d24aedc531eb39400892635092b65

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/core_geometry.md: 0aaa532df5969b0382f4f9ec25611160d7773a1c2864604168410420da44d18a

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/inherited_ledger.md: 5afd04957c06ab4c2c08fc920cc4d503ffb488e5f585ebd6b282fe4fe1e4a2d5

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/combined.md: f47646d11a444849493651f57f897ee0bdcd81f11d4cb92516c1467e62d7abd7

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/aspect_checks.py: 8b42de77c47b0b838f25ade8d3f43292517eccc8e3a641650d4e5fbc7d630bab

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/aspect_checks_summary.json: dcfe9ed9bd5a6baaccb7420a87de4df483d38c3651b288b3f4badd3d08dc99f8

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/numeric_notes.md: 25db77484c08b2e5e7d485c9342dc30a1f7670393f591e7e14ac9ea8e541f88b

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/smoothing_checks.py: 2fd15fc5a0c9dbf2028e70c3f0c1a770e8612ff199ad3d4a7fe6ddce7d6b56bb

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round323_20261018_final_checkpoint/smoothing_checks.log: f70d6577af4f3f618566862cb0ed658bb043e90920ab931d0f4c8b1c3c7abb43

Verdict: PASS for the stated branch payments, same-H aspect replacement, source/occupancy budgets and exact complements. No certification of the general centered-cube root bound or full global epsilon absorption. Freeze this receipt; any changed mathematical proof/integration bytes require a new explicit binding.
