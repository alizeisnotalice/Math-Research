# R323：完整总账下的 B_H 来源平滑化与双高边界核心

日期：2026-10-18。一般中心立方体 n^(1/2+o(1)) 一致弱型上界尚未证明。本轮是有实际付款的新分支结果，不是一般闭合；不能称只剩常数和对数。所有结果以原正 L1 来源、真实 dx、原 E,R,q、完整 U,J,A 和原包含端点的层测度为基础。

## 1. 继承入口，不混同两条路线

完整旧账继承 rounds/322/research.zip::ledger.md，尤其 §§1–3、7–11；所有原定义、费用和未付积分均保留。历史路线的 R_out 不等于 X_band。原带至真实历史的 H0 桥仍未证明。原生硬带入口 N 的 H_rootleft 也没有被本轮替换成 B_H。本轮只在旧历史槽的 R302 辅助 B_H 内实施下列替换。

本轮使用 E03 的增量/终端守卫及 F05 的实际双侧核检查；不引用未定义的 G03 私有捕获树定理。来源平滑化所用强 L2 工具是旧 R104 已核准的全尺度中心立方体最大算子定理，见 smoothing.md §1。没有假定实际来源有密度帽。

## 2. 新的精确优先序与付款

保留 R322 的近/远、旧层、来源形状成功、核心四级付款，固定同一个 H。设其末项 Phi_core=N_core-E_full。先在 N_core 中按 K_z(r)<G 付款，再对 K_z(r)>=G 部分应用一份共同二元停止分解。二元分解与旧来源形状标签不同；二者只在正被积式中交叉，不复制来源质量。

K_z(r)=∫_{E,R(x)<=r} c_x(z)/(q(x)R(x)^n) dx，G>0。低 K 部分至多 lambda G W_nu。所有等号 K=G 留在高侧。

在实际 nu 上以密度阈值 K_CZ>0 构造共同循环二元停止包 D；K_CZ |D|<nu(D)<=2K_CZ |D|。记 Omega 为这些包的并。保持来源一次分配的平均输入 g 满足 0<=g<=2K_CZ，∫g=W_nu，||g||_2²<=2K_CZ W_nu。令 t_CZ=2n。小包 max side(D)<=R/(2n) 全额接受；大包 R<=min side(D)/(2n) 单独支付；其余包按 theta_D=|D∩Q_R|/|D| 接受，剩余权为 1-theta_D。

两个付费项的统一界为

P_CZ=epsilon X_rho + C_CZ W_nu,
X_rho=lambda∫rho(x)dx,
C_CZ=e² C2² K_CZ/(2 epsilon lambda)+4 sqrt(e) lambda/K_CZ.

实际大包费可收紧为 4 sqrt(e)lambda nu(Omega)/K_CZ；上式只用了 nu(Omega)<=W_nu。K_CZ=lambda sqrt(n) 时 C_CZ=e² C2² sqrt(n)/(2epsilon)+4sqrt(e)/sqrt(n)。这一 K_CZ 与旧 low-pe 阈值 K_orig 无关。改变 K_CZ 会改变余项，不能跨余项自由取最优。

令 N_res 为 N_core 内 K_z(r)>=G、实际中间包且权 1-theta_D 的正基线，仍保留全部旧来源门、距离/近期门和完整 J。则

Phi_core <= lambda G W_nu + epsilon X_rho + C_CZ W_nu + Phi_res,
Phi_res=N_res-E_full.

整个 E_full 只扣一次。另一合法版本使用相应正损失 B_res，但不能同时扣整个平方。本轮选择上面的有符号版本，不把该有符号量误称独立正损失。

## 3. 固定 H 的比例费用改进

保留两条原 low-pe 高度不等式，令 G_n=(1+1/n)^(n/2)，psi=3-2/(3G_n²)，C_vee=psi+7G_n/3。新门 chi'_r=min(1,(L/r)^(n/4) min(1,(R/r)^(7n/4)))，与旧门取 max。其共同 witness 费用给出

d_eff=min(kappa0 psi/(q_- v0), kappa0 C_vee/(q_- sqrt(v0))),
T_* <=8lambda H W_beta+2d_eff A_n/H W_nu+2B_H.

这里 B_H 的 H、U、J、平方全不改变。如果另取 H'=sqrt(d_eff A_n/(4lambda))，必须同时改成 B_H' 并重做其距离分解。本轮总账选择固定 H，避免暗中替换余项。优化后的显式源费比例幂改善为 v0^(-1/4)，仍非全比例根阶结论。

可选 tiny-soft 尾部 A={s<=1/4096,v<=2^(-n/4)} 按 aspect.md §4 给出 P_tail=(16/3)e^(1/4)sqrt(kappa0) A_n e^(-n/16) W_beta。该机制继承 R294，不算新的全局证明。只用它支付原 extreme 与 A 的交集，保留 T_extreme,A^c。

## 4. 明列更新后的旧总账

设 Lambda=128/119，L_out 为旧共同来源/唯一带的真实外层汇总，B_rect、S_near、S_mod、A_pre、C_G、E_original、各时间项均按 R322 ledger 原定义。固定 H 时合法更新为

R_out <= A_pre+C_G sqrt(n)W_beta+Lambda(S_near+S_mod)
 + E_original X_old + 2Lambda epsilon L_out[X_rho]
 + Lambda T_extreme,A^c + Lambda L_out[P_tail]
 + Lambda L_out[(8lambda H+2e_beta)||beta||
                  +(2d_eff A_n/H+2e_nu)||nu||]
 + (32Lambda/3) Csoft W_beta + 8Lambda sqrt(n) B_rect
 + 2Lambda L_out[(lambda G+C_CZ)||nu||+Phi_res]
 + 2Lambda(I_rem+J_rem+D_rem+P_suffix-N_Zc-N_del).

P_tail 在上式按每实例定义，不能再次按全 W_beta 逐实例复制。在已有共同源预算且参数一致时方可外提常数。所有新预算替换原对应槽，不额外添加旧 Pi_mid 或 Phi_core。

匹配 M3 只保证 L_out[X_rho]<=X_old，不能无证使用 sum |E_V|。因此新增接收吸收系数确为 2Lambda epsilon。可选 epsilon=119/32768，使其等于 1/128；此时新增源费常数固定，仍为根阶。总系数为 E_original+1/128，其中

E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)
 +epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G.

这些未定参数以及缺失 H0 的入口系数仍须统一解决，不能据新增1/128声称全局可吸收。任意其他外层集若没有 M3，保留 L_out[X_rho] 不外提。

## 5. 独立未付账与下一步

1. Phi_res：实际中间包边界拒绝、J>=H且K>=G，同时保留近期、中距离、旧来源形状失败。主攻其真实联合来源与捕获平方；高拥挤不是已证的重叠节省。
2. 全 extreme 补集 v<v0 且 A^c：不能选有利阈值后删除。
3. I_rem 初始原子、J_rem 真删除跳跃、D_rem 未来被删来源连续项：各需真实势差/耗散预算。
4. P_suffix 及未用负项必须保持原域、原系数；不能由终端 good 定理替换上项。
5. 历史 H0 入口、全物理尺度桥、小维度回补和外层来源/误差统一仍未闭合；原生入口的 H_rootleft 仍独立。

没有从薄层体积推出实际边界来源质量小。没有把 F05 Schur 上界当作捕获平方下界。alpha=1 的合法比较只允许从 B_H 入口重新开始，不能在已分解 Phi_res 中换一个更大的负平方。

## 6. 本机验证、范围与资源

主代理 fresh 跑 aspect_checks.py：1068项 Fraction 检查通过，含初探、边界压力、扩大到 n=256；新旧门互不统一支配。fresh 跑 smoothing_checks.py：1417项 Fraction 检查通过，n=1,2,3 的有限二元树/正体积盒。前者不是完整历史实现，后者不认证无限树或全局最大定理。prefix 检查与独审证据以最终随包摘要为准。

有限计算不替代正文证明。分支成功率没有已证统一正下界。模型实际扣额数据不可得，未估算模型成本比例。本轮仅归档必要证明、复现代码和摘要，不编译 PDF。
