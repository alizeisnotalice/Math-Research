#!/usr/bin/env python3
"""R323 quarter-penalty algebra, finite nested-cube fees and iid ranks."""
from fractions import Fraction as F
from itertools import product
from collections import Counter
import json
counts=Counter();diagnostics=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def gates(n,L,R,r):
 old=min(F(1),(L/r)**(n//2)*min(F(1),(R/r)**(3*n//2)))
 new=min(F(1),(L/r)**(n//4)*min(F(1),(R/r)**(7*n//4)))
 return old,new

def scalar(n,grid):
 G=(1+F(1,n))**(n//2)
 for L,R,r in product(grid,repeat=3):
  old,new=gates(n,L,R,r);p=G*L**(-n//4)*R**(-3*n//4)
  ck('gate_range',0<=old<=1 and 0<=new<=1)
  if R<r:ck('quarter_lower_R_transfer',p*new*R**(-n)<=G*r**(-2*n))
  else:
   ck('quarter_upper_R_transfer',p*new*R**(-n)<=G*r**(-n//4)*R**(-7*n//4))
   ck('root_v_improvement',new>=min(F(1),(L/R)**(n//4)))
  diagnostics['new_greater_old']+=new>old;diagnostics['old_greater_new']+=old>new

def envelope(n):
 G=(1+F(1,n))**(n//2);psi=3-F(2,3)/G**2;Rs=[F(1),F(5,4),F(3,2),F(7,4),F(2)];Ls=Rs
 def integral(coeff):
  return sum(((R**n-(Rs[j-1]**n if j else F(0)))*max(coeff[j:]) for j,R in enumerate(Rs)),F(0))
 rows=[]
 for r in [F(1),F(3,2),F(2)]:
  oldcoeff=[];newcoeff=[];maxcoeff=[]
  for R in Rs:
   values=[]
   for L in Ls:
    old,new=gates(n,L,R,r)
    # The old psi receipt retains BOTH height bounds explicitly.
    p=min((L*R)**(-n//2),G*L**(-n//4)*R**(-3*n//4))
    values.append((p*old*R**(-n),p*new*R**(-n),p*max(old,new)*R**(-n),G*L**(-n//4)*R**(-3*n//4)*new*R**(-n)))
   oldcoeff.append(max(v[0] for v in values));newcoeff.append(max(v[3] for v in values));maxcoeff.append(max(v[2] for v in values))
  O=integral(oldcoeff)*r**n;N=integral(newcoeff)*r**n;M=integral(maxcoeff)*r**n
  ck('finite_old_fee',O<=psi)
  ck('finite_quarter_fee',N<=F(7,3)*G)
  ck('finite_max_fee',M<=psi+F(7,3)*G)
  ck('finite_max_subadditivity',M<=O+N)
  rows.append(dict(n=n,r=r,old_fee=O,new_fee=N,max_fee=M,psi=psi,G=G,upper=psi+F(7,3)*G))
 return rows

def iid(n):
 pi=[F(1,6),F(1,3),F(1,2)];centers=[F(-1,2),F(0),F(1,2)];Ls=[F(1),F(3,2),F(2)];Rs=Ls;zs=[F(-1),F(0),F(1)]
 cases=0
 for r in [F(1),F(3,2),F(2)]:
  marks={z:[max(gates(n,Ls[i],Rs[i],r))*int(abs(z-centers[i])<=Rs[i]/2) for i in range(3)] for z in zs}
  for N in [1,2,3]:
   tuples=list(product(range(3),repeat=N))
   prob=lambda ids:__import__('functools').reduce(lambda a,i:a*pi[i],ids,F(1))
   prod=lambda vals:__import__('functools').reduce(lambda a,v:a*v,vals,F(1))
   for z in zs:
    a=marks[z];D=sum((pi[i]*a[i] for i in range(3)),F(0));direct=sum((prob(ids)*(1-prod(1-a[i] for i in ids)) for ids in tuples),F(0))
    ck('iid_capture_probability',direct==1-(1-D)**N)
    previous=F(0);ranktotal=F(0)
    for R in Rs:
     current=sum((pi[i]*a[i] for i in range(3) if Rs[i]<=R),F(0))
     exact=sum((prob(ids)*(prod(1-a[i] if Rs[i]<R else F(1) for i in ids)-prod(1-a[i] if Rs[i]<=R else F(1) for i in ids)) for ids in tuples),F(0))
     ck('iid_minimum_radius_rank',exact==(1-previous)**N-(1-current)**N)
     previous=current;ranktotal+=exact
    ck('iid_no_lost_rank_mass',ranktotal==direct);cases+=1
   a,b=marks[zs[0]],marks[zs[1]]
   D=sum(pi[i]*a[i] for i in range(3));E=sum(pi[i]*b[i] for i in range(3));both=sum(pi[i]*min(a[i],b[i]) for i in range(3))
   direct=sum((prob(ids)*(1-prod(1-a[i] for i in ids)-prod(1-b[i] for i in ids)+prod(1-max(a[i],b[i]) for i in ids)) for ids in tuples),F(0))
   ck('common_mark_joint_sources',direct==1-(1-D)**N-(1-E)**N+(1-D-E+both)**N)
 return cases

def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [serial(v) for v in x]
 return x

def main():
 stages=[];fee=[]
 for name,ns,grid in [('initial',[4,8],[F(1),F(3,2),F(2)]),('boundary',[4,8],[F(1),F(5,4),F(7,4),F(2)]),('expanded',[16,64,256],[F(1),F(3,2),F(2)])]:
  before=sum(counts.values())
  for n in ns:scalar(n,grid);fee.extend(envelope(n))
  stages.append(dict(stage=name,n=ns,checks=sum(counts.values())-before))
 before=sum(counts.values());iidcases=sum(iid(n) for n in [4,16]);stages.append(dict(stage='finite_iid_bridge',n=[4,16],checks=sum(counts.values())-before,capture_cases=iidcases))
 print(json.dumps(serial(dict(status='PASS',arithmetic='Fraction',check_counts=dict(counts),total_checks=sum(counts.values()),diagnostics=dict(diagnostics),stages=stages,fee_rows=fee,scope='Scalar height transfers, finite nested centered cube-envelope menus and finite-atom iid witness/mark rank identities. Not original source/kernel/history realization or root closure.',height_assumptions='New transfer uses p<=G L^(-n/4)R^(-3n/4),kappa0=1. The old psi fee additionally retains p<=(LR)^(-n/2); fee test uses the minimum of both.')),sort_keys=True))
if __name__=='__main__':main()
