# R293 independent audit

## Independent preauthor screen

Written before opening any R293 author proof. The R292 clipped overlap Gamma is a fixed nonnegative source-displacement kernel only after its full legal scale/common-soft supremum and frozen parameters have been specified. A weak-L1 bound on its Lebesgue distribution is a spatial-kernel statement. It does not directly control its source-weighted convolution or the beta-weighted large-E traffic.

The original beta FIRST is an actual RECEIVER response cap integral P_(s(x),L(x))(x-y) beta(dy)<=q(x). It is not beta<=C dx, a pointwise density bound, a cap for every scale at every source point, or a FIRST property for Gamma. Likewise the original hard cap controls h_(R(x))*nu at the actual receiver; it cannot be extended to every source anchor or every scale without proof. The original source chain may supply beta<=f dx (and a documented original nu relation), but f is an arbitrary L1 input, not a bounded constant density. No extra source ordering is used here.

In general the endpoint convolution step L1*weak-L1 -> weak-L1 cannot be invoked as a normed Young inequality; its p=1 endpoint requires a separate structural proof or an explicit endpoint loss. Tonelli controls integrals, not distribution functions of sums. In particular weak distribution of Gamma cannot be averaged over arbitrary nu by swapping a superlevel set with the source integral. A normalized convolution with an actual positive probability source is still not covered by that unsupported endpoint rule.

A safe integrated transfer is available with EXPLICIT restricted source hypotheses. Suppose 0<=K<=H and |{K>t}|<=k/t, nu has total mass V, and beta has total mass W and density <=D. Positive layercake gives uniformly in the translated anchor
 integral K(z-y) beta(dy)<=Phi(Dk,HW),
where Phi(c,v)=v if v<=c, and c[1+log(v/c)] if v>c, with the evident zero conventions. Therefore integral (K*nu) beta<=V Phi(Dk,HW). This is a valid finite capped-weak restricted test. It costs the density cap and a logarithm; neither can be omitted. The strong bound <=V min(HW,D||K||1) is independently valid. General L1 beta can be split into bounded-density pieces and these explicit costs added, leaving any density/entropy sum as a genuine hypothesis or unpaid budget.

For the original large-E slot, frozen t_min=a/c_j and monotonicity give {E^-_(j,M)(y,g)>theta_j} subset {Gamma_(j,M)(t_min)*nu(y)>theta_j}, after positively dropping the forbidden-set restriction. Any resulting source-only gate S may be paid through the original full-soft row marginal bound
 T_S<=(16/3)Csoft_n A_n beta(S), A_n=1+n log(b/a),
which was established by consuming the actual hard cap BEFORE receiver extension and using the fixed all-soft source envelope. The independent column bound remains A_n||nu||. Thus an explicitly justified estimate for beta(S), rather than a bare Lebesgue superlevel estimate, is the required bridge. The row source fee is generally polynomial here and does not itself give the desired root price.

Under beta<=D dx a simple safe specialization is beta(S)<=min(W,D||Gamma(t_min)||1 V/theta_j), by ordinary strong-L1 Markov; any sharper weak-kernel claim must still establish its endpoint convolution and density transfers. If beta is only absolutely continuous, finite beta mass alone does not remove concentration dependence.

These are constructive conditional boundaries, not a campaign of admissible-history counterexamples. No assertion is made that arbitrary concentrated sources satisfy every original FULL/history qualification, or that no additional original geometric structure could close the bridge. Actual selector dependence, q_-, original source sums, and Lambda once remain mandatory.

## Independent homogeneous all-scale majorant screen

Before any R293 author proof: this new kernel-only construction is valid. For a nonnegative ray-decreasing integrable profile F on R^(2n), positive star-levelset layercake proves
 sup_(g>0) g^(-2n)F(X/g)<=2n integral_0^infinity g^(-2n)F(X/g)dg/g.
For normalized product F(u,v)=Q_rho(u)h_(1/rho)(v), integrate x and define kappa(delta)=integral F(u,u-delta)du, whose mass is 1. Then
 Phi(delta)=2n integral_0^infinity g^(-n)kappa(delta/g)dg/g
 is homogeneous of degree -n. Specifically Phi(r omega)=r^(-n)a(omega), a(omega)=2n integral_0^infinity t^(n-1)kappa(t omega)dt, and integral_sphere a=2n. Thus |{Phi>v}|=2/v EXACTLY for every v>0. Possible infinite angular values form a sphere-null set by integrability; the origin also has zero Lebesgue measure. Positive countable homogeneous sums with summable angular mass have exactly additive weak constants by the same polar identity.

For each fixed original ratio band and orientation L>=R, enlarge to L'=g/c_(j+1), R'=g c_j. Both scales enlarge, and L'R'=gamma g², so normalized product costs gamma^n. Set g'=sqrt(gamma)g and rho=1/sqrt(c_j c_(j+1)) to obtain reciprocal shape scales; the all-scale g' integral safely drops physical endpoints. The reverse orientation pays a second profile. Original softness is paid by H<=sum_k a_(n,k)Q_k. Hence the actual fixed-band kernel Gamma is bounded by a positive homogeneous kernel with weak norm at most 4gamma^n Csoft_n. This statement does not require clipping, source-nearness or an endpoint convolution theorem. It is a fixed-band spatial majorant only.

A self-contained root bound for the coefficient sum is available: with binomial probabilities p_k(s), each interior coordinate rises then falls and the two endpoint coordinates are monotone, so integral_0^1 sum_k|p'_k(s)|ds=2(Csoft_n-1). Meanwhile sum_k|p'_k(s)|=E|Bin(n,s)-ns|/[s(1-s)]<=sqrt(n)/sqrt(s(1-s)). Integrating gives Csoft_n<=1+(pi/2)sqrt(n). Therefore the fixed-band weak kernel price is root order. It does not remove the source-convolution or source-weighted-transfer problem, and summing different j remains explicitly unpaid unless covered by a separate construction.

Executed mpmath at 35 digits for the n=2 unit-cube convolution profile: the angular integral is 4.0 (expected 4); its polar weak coefficient is 2.0 (expected 2), error 0.0. Exact binomial coefficient sums at n=[1, 2, 8, 64, 512, 1024] obeyed the displayed root bound. These finite diagnostics supplement the algebraic proof.

The homogeneous majorant has positive angular mass and is not locally integrable at the origin: each radial annulus has the same positive integral, yielding logarithmic divergence. It is also not integrable at infinity. Thus its direct convolution with an ordinary source positive on an open ball is already infinite at interior points. This is a kernel-operator limitation, not an original FULL-history example. Any useful source transfer should preserve the actual finite cap Gamma<=a^-n A_n (and, when needed, the actual integrable far profile), e.g. use Gamma<=min(a^-n A_n,Phi). A finite spatial weak norm alone cannot discard these endpoint regularizations.

## General concentration-function restricted test

No bounded-density assumption is needed if its cost is stated explicitly. Define omega_beta(s)=sup_{Leb(A)<=s} beta(A), with standard outer-measure conventions. For any capped weak kernel, positive layercake gives
 integral(K*nu)d beta <= ||nu|| integral_0^H omega_beta(k/t)dt.
The actual kernel distribution may replace k/t for a sharper valid bound. This is finite by omega<=||beta||, and it preserves exactly the source concentration dependence missing from a bare spatial weak norm. It specializes to Phi(Dk,H||beta||) when beta<=D dx. It does not assert that the original FIRST cap controls omega_beta.

Executed mpmath at 30 digits: 54 positive parameter combinations verified the exact bounded-density layercake integral versus Phi, maximum discrepancy 3.1554e-30. This checks the scalar implementation, while the positive layercake proof is exact.

## Final column-geometry author review

PASS for /tmp/r293_column_geometry.md SHA256 290bcb8a63ee28b7bcccc8e8479ebd66276d17c5b597113e3585d7e27702a03c. W1--W3 and S1--S3 are valid in their stated scope. The direct all-scale ray-monotonicity proof (4) has the correct upper-bound direction. Integrating the SAME x gives the convolution profile of mass D; polar coordinates give exact homogeneous weak coefficient 2D, including n=1 and angular infinities on null sets. Positive homogeneous sums have exactly additive coefficients only because they share degree -n. This is not a general weak-L1 triangle inequality.

Both original band orientations enlarge both unnormalized scales to g/c_(j+1) and g c_j (assigned to the appropriate source), with product gamma g². Normalization therefore costs gamma^n exactly; the reciprocal aspect r=1/sqrt(c_j c_(j+1)) is correct. Extending the artificial g' to all positive values is a positive majorant and is never granted original response caps. The binomial variation proof of Csoft<=1+(pi/2)sqrt(n) matches the independent derivation above.

The finite height W3 is valid: for smaller soft scale L<=cg, the n-dimensional 2n-power radial envelope costs 2c^n t^-n D; for smaller hard scale R<=cg, V<=h_tau gives 2c^n t^-n h_tau. Sum yields B_t=2c^n t^-n(D+h_tau). Each profile layercake is an upper bound, not an unproved equality. The separate R292 cap a^-n A_n may be minimized with it. The tied-hard finite-window formula (9) and total mass 1+2n log(b/a) are exact; only its homogeneous majorant has asserted exact weak coefficient 2.

S1 correctly retains the cap and the ORIGINAL hard-source density rearrangement (or an actual frozen restriction) with no density assumption derived from the hard cap. S2 is the exact finite capped-weak/density scalar price and may be integrated against beta only at its explicit source-weighted cost. The explanation of the unregularized homogeneous divergence is valid as a kernel-transfer limitation and explicitly does not claim a FULL original-history construction. All j coefficients and actual original gates remain to be paid. No new positive root gate or coverage statement is introduced.

Final column verdict: a constructive root-order weak bound for each actual fixed-band clipped spatial column is proved, together with a valid finite height and conditional source interaction. The missing general beta-weighted large-E source payment is precisely retained. The source-author proof and final README are not yet audited at this receipt.

## Final source-transfer author audit

PASS for /tmp/r293_source_transfer.md SHA256 59551dcb181eb28191c3c536444516493cae960cf431eef6ee0f1d311c0abfaa. The original actual receiver product is retained until its column majorant, and q is relaxed only to q_-. The finite cap H0 remains in all source convolutions. S2--S4 agree with the independently derived concentration-modulus layercake. The rearrangement formula is finite for all original L1 beta, but its actual concentration charge is not suppressed. S5 uses actual original beta FIRST before extending the receiver; taking a minimum in S6 applies to the same positive suballocation. Symmetric capped pair integration uses reflection and needs no source ordering.

The optimal density formula S7 and normalized mass logarithm S8 are correct with B0,D and source mass explicit. The p>1 estimate S9 has correct constant: layercake gives ||k||_(p')^(p')<=p K H^(1/(p-1)), hence the displayed Holder product. It is not an endpoint Young transfer.

The genuine source split S10--S12 is valid and disjoint: the nu-low piece consumes full original beta FIRST on E, giving N|E|; epsilon X follows only with the explicitly stated E subset E0 and X=lambda|E0|. The beta-low/nu-high piece inherits original source caps and has the explicit Psi price. Its exact leftover is the SAME current original mask times 1{v(z)>N}1{b(y)>B0}. Original e_g,m,tree/history and any prior E^- restriction are never recomputed. Different j/roots do not receive disjoint sources without a separate allocation.

No proof defect found. This provides constructive restricted source payments, including an epsilon X density-low piece and an explicit root-times-density/log conditional branch. The general high/high concentration remainder, as well as the earlier joint source/selector budget, is not paid by these arguments.

## Final README integration

PASS for /tmp/r293_README.md SHA256 c3447b74ff47cf9c16b723974fd557b1e9d5801098e78247de0968a804d4a5f6. Kernel constants, finite height, source concentration premise, independent FIRST minimum, original qualifiers, ratio-band fees and limits of numerical evidence match the two audited proofs. The ambiguous remainder sentence now explicitly retains original low pe/high m, failure of the joint entropy payment gate, and large clipped-column mass. No assertion of arbitrary-source coverage, weak convolution endpoint, source density cap from FIRST, or global weak-type closure is made.

## Final evidence-only hash update

PASS unchanged. Final column geometry SHA256 3834d925ee3b1473f77031086a3b5a48e68861119fff4a408fe2be1bcbff877e. Replacing only its final evidence paragraph with the previously read paragraph reconstructs the audited SHA256 290bcb8a63ee28b7bcccc8e8479ebd66276d17c5b597113e3585d7e27702a03c exactly, verifying that all mathematical text is unchanged. The updated evidence paragraph matches existing /tmp/r293_checks.json status PASS: 65 exact hard-face cases, 27 radial cases, 288 exact orientation checks, 11 coefficient sums, 216 capped rearrangement cases, and displayed Csoft(10000)=125.99912186808116146. It preserves the distinction between exact homogeneous weak coefficient 2 and finite-window upper bound. No new mathematics or numerical rerun was needed. Audit frozen with this final author binding.
