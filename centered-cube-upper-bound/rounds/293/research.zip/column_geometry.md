# R293: a general root-order weak distribution bound for the actual clipped column

## 1. Main theorem and the separate source-transfer issue

Use the actual R292 column, with n>=1, gamma=1+1/n, c=c_j, c_+=c_(j+1)=c/gamma, t in the nonempty physical interval [a/c,bc], and

    V(u)=min{H_sigma(u),tau},
    H_sigma(u)=sup_(0<=s<=sigma) product_i p_s(u_i),
    D=int V,  h_tau=min(1,tau).

Here tau=(2K/(ell M))c_j^(n/2)c_(j+1)^(-n) in the original low-pe application. The SAME common softness is used, and the original low-pe reduction to this clipped profile is retained. Write

    Gamma(t;y,z)=int_x sup_{a<=L,R<=b, g=sqrt(LR)>=t,
                         c_+<=min(L,R)/g<=c}
           g^(-2n)V((x-y)/L)1_{Q_R(z)}(x) dx.

There exists an explicit nonnegative homogeneous kernel Phi_j,V of degree -n, independent of t and of the sources, such that

    Gamma(t;y,z)<=Phi_j,V(z-y),
    ||Phi_j,V||_(1,infinity)=4 gamma^n D.                  (W1)

Thus the original finite-scale column satisfies the GENERAL weak distribution estimate

    ||Gamma(t;0,.)||_(1,infinity)
       <=4 gamma^n D
       <=4e[1+(pi/2)sqrt(n)].                              (W2)

This holds for arbitrary displacement, full softness sigma=1, and all actual within-band scale selectors before receiver integration. It is neither a fixed-offset result nor a fixed-scale model extrapolation. The clipped mass D is retained and may be smaller than the last bound.

An independent finite height bound is

    Gamma(t;y,z)<=B_t:=2c^n t^(-n)(D+h_tau).                (W3)

It may be minimized with the R292 bound a^(-n)[1+n log(b/a)]. Combining (W1) and (W3) gives a bounded weak kernel majorant rather than discarding the physical lower scale.

The remaining source transfer is substantive. Phi itself is nonintegrable at the origin, and its convolution can be infinite even for a bounded source satisfying the original hard cap globally. Sections 5-6 give the exact source rearrangement estimate available after retaining B_t and explain what the actual caps do and do not supply. No general root source payment for the old E^- large traffic is asserted.

## 2. Homogeneous weak majorants: proof and exact constants

Let F>=0 be integrable on R^(2n), nonincreasing along rays from zero, with mass m. For every X and every g0>0, ray monotonicity gives F(X/g)>=F(X/g0) for g>=g0. Therefore

    sup_(g>0) g^(-2n)F(X/g)
       <=2n int_0^infinity g^(-2n)F(X/g) dg/g.             (4)

This follows directly by integrating g^(-2n) on [g0,infinity), and then taking the supremum; no selector/integral exchange is made.

For profiles f,h on R^n, with h the normalized unit cube density and f ray-nonincreasing of mass D, fix an aspect r>0 and put

    f_r(u)=r^(-n)f(u/r),
    h_(1/r)(v)=r^n h(r v),
    F_r(u,v)=f_r(u)h_(1/r)(v),
    kappa_r(delta)=int f_r(x)h_(1/r)(x-delta) dx.

The product profile F_r is ray-nonincreasing on R^(2n), has mass D, and int kappa_r=D. Applying (4) at X=(x-y,x-z) and integrating x yields

    Phi_r(delta)=2n int_0^infinity g^(-n)
                                  kappa_r(delta/g) dg/g.  (5)

The function Phi_r is homogeneous of degree -n. Polar coordinates and positive Tonelli give

    int_(S^(n-1)) Phi_r(theta) dtheta=2n D.

Indeed the substitution u=1/g turns the radial integral into the polar mass integral of kappa_r. Consequently, for every lambda0>0,

    |{delta:Phi_r(delta)>lambda0}|=(2D)/lambda0,
    ||Phi_r||_(1,infinity)=2D.                             (6)

The value at delta=0 may be infinity and does not affect Lebesgue distribution. Polar integrability ensures finiteness for almost every direction. The same formulas use the two-point sphere when n=1.

Most importantly, positive homogeneous kernels of the SAME degree -n have exactly additive weak constants:

    ||sum_l alpha_l Phi_l||_(1,infinity)
      =(1/n)int_sphere sum_l alpha_l Phi_l
      =sum_l alpha_l ||Phi_l||_(1,infinity),               (7)

for alpha_l>=0 and finite total angular mass. This is an exact consequence of homogeneity, not a generally valid weak-L1 triangle inequality.

## 3. Both orientations of the actual ratio band

Assume first L>=R. The band gives

    L<=g/c_+,  R<=g c.

Enlarge the two unnormalized profiles to these two scales. Their product is gamma g^2. Set g'=sqrt(gamma)g and

    r=1/sqrt(c c_+).

The enlarged scales become r g' and g'/r. Since V and the cube indicator are ray-nonincreasing,

    g^(-2n)V((x-y)/L)1_{Q_R(z)}(x)
       <=gamma^n [g'^(-2n) F_r((x-y)/g',(x-z)/g')],         (8)

where F_r is defined using f=V. The factor gamma^n is exactly the normalization ratio. The artificial enlarged scales need not remain below b: they are used solely for a positive column majorant, never granted actual FIRST or hard caps.

For the opposite orientation L<=R, use enlarged soft scale g c and hard scale g/c_+, which gives the reciprocal aspect 1/r. Take the two nonnegative majorants, relax g' to all positive scales, apply (4), and integrate the SAME x. Thus

    Gamma(t;y,z)<=gamma^n[Phi_r(z-y)+Phi_(1/r)(z-y)].

Define the right side to be Phi_j,V. Equations (6)-(7) give its exact weak constant 4gamma^n D. Also gamma^n<=e. This proves (W1)-(W2), independently of any unproved convolution theorem.

To bound D explicitly, expand the original common-soft product:

    product_i p_s(u_i)=sum_(k=0)^n b_(n,k)(s)Q_k(u),
    b_(n,k)(s)=binom(n,k)s^k(1-s)^(n-k),

where Q_k is the probability density obtained by averaging products with exactly k soft coordinates. Hence H_sigma<=sum_k a_(n,k)Q_k, where a_(n,k)=max_s b_(n,k)(s), and D<=Csoft_n:=sum_k a_(n,k).

There is a short all-n bound without factorial asymptotics. Each b_(n,k) is unimodal, so

    Csoft_n=1+int_0^1 sum_k (b'_(n,k)(s))_+ ds.

The binomial derivative and sum b'=0 imply

    sum_k(b'_k)_+= E|Bin(n,s)-ns|/[2s(1-s)]
                  <=sqrt(n)/[2sqrt(s(1-s))].

Integration gives Csoft_n<=1+(pi/2)sqrt(n). Endpoints are handled by the finite polynomial derivatives and the integrable displayed upper bound. The original shared softness is never changed to independent coordinate choices.

## 4. Independent finite height and the hard tied-scale sanity model

For L<=R, the actual smaller soft scale satisfies L<=c g. Drop the hard indicator, enlarge V to scale c g, and use the radial envelope inequality in n dimensions with exponent 2n:

    int sup_(g>=t) g^(-2n)V((x-y)/(cg)) dx
       <=2c^n t^(-n)D.

The bound follows by positive layer cake over star-shaped superlevel sets, placing the supremum inside that positive layer integral; each indicator-level radial threshold contributes a core term and an equal tail term. For R<=L, use V<=h_tau and R<=cg; the same identity for the unit cube gives 2c^n t^(-n)h_tau. Adding proves (W3). This is a finite bound for the original column, not for the unbounded homogeneous majorant.

For comparison only, take the hard tied-scale family L=R, s=0. Directly applying the positive scale-envelope identity with exponent 2n before integrating x gives the exact finite-window formula

    Gamma_hard(delta)
      =b^(-2n)product_i(b-|delta_i|)_+
        +2n int_a^b L^(-2n-1)product_i(L-|delta_i|)_+ dL.   (9)

Thus int Gamma_hard=1+2n log(b/a). Nevertheless its homogeneous majorant from (5) has EXACT weak constant 2, so ||Gamma_hard||_(1,infinity)<=2. We do not claim that the finite-window kernel itself has weak constant equal to 2. This illustrates why the strong volume may be linear in n while the weak column bound is constant. The general proof above did not assume this model.

## 5. A valid source-weighted estimate after retaining the physical cap

Set K_j=4gamma^n D and let B be either (W3) or its minimum with the independent R292 height bound. Let f>=0 be the Lebesgue density of ANY original hard-source restriction, of mass m, and let f* be its decreasing rearrangement. For each y, layer cake/rearrangement yields

    int Gamma(t;y,z) f(z)dz
       <=int_0^infinity f*(u) min{B,K_j/u}du.              (S1)

One may use the density of the actual frozen restriction nu|Z^-_(j,t)(y) here; its rearrangement can depend on y. Replacing it by the full nu rearrangement is a positive relaxation. This is a genuine source interaction estimate for the actual finite column, not a weak-norm assertion about a point kernel alone. It remains valid for unbounded L1 densities because the right side is <=B m.

For a source piece with an independently established density cap f<=v and mass m, (S1) gives the explicit useful special case

    int Gamma(t;y,z)f(z)dz <=K_j v Psi(Bm/(K_j v)),
    Psi(u)=u                    for 0<=u<=1,
    Psi(u)=1+log u              for u>=1.                  (S2)

Zero mass or zero K_j is handled by zero contribution. The formula follows from the exact scalar integral int_0^B min{m,K_j v/s}ds. No source is duplicated, and this price can be integrated against the ORIGINAL beta if its resulting source-weighted right side is controlled.

The full weak distribution theorem does not itself provide such control on beta. In particular the original maximal hard cap

    sup_(a<=R<=b) h_R*nu(x)<=4lambda at actual receivers

controls averages on cubes of side at least a. It is not a pointwise density cap f<=4lambda and cannot be substituted for v in (S2). Even a source of arbitrarily large density supported in a sufficiently small ball, with total mass m<=4lambda a^n, satisfies that hard cap everywhere. This is a direct check of the scale qualification, not a FULL original-history counterexample.

## 6. Precise obstruction to the unregularized homogeneous transfer

The homogeneous majorant has positive finite angular integral whenever D>0. Therefore

    int_(|delta|<epsilon) Phi_j,V(delta) ddelta
       =[int_sphere Phi_j,V] int_0^epsilon dr/r=infinity. (S3)

Let an original hard-source density equal v>0 on a ball and vanish outside, with its total mass chosen <=4lambda a^n. Its maximal hard average is then <=4lambda everywhere. At every interior point y, however, Phi_j,V*nu(y)=infinity by (S3), while the actual finite-scale Gamma*nu(y)<=B||nu|| is finite.

Thus replacing Gamma by Phi inside E^- loses indispensable source-scale information even under the full hard cap. This explicitly demonstrates the failure of THAT direct transfer. It does not disprove the desired original theorem, invalidate the weak column result, or construct a FULL remaining traffic history.

For the actual R292 quantity

    E^-_(j,M)(y,g)=int_(Z^-_(j,g)(y))Gamma_(j,M)(g;y,z)nu(dz),

(S1) is the rigorous currently available source-weighted consequence of (W1)-(W3). To pay its large-value original traffic, one still needs a joint estimate of this rearrangement/finite-scale source interaction against the actual beta/FIRST weights, or a source-conserving localization that supplies the required local density/mass control at its stated cost. Neither a Lebesgue weak estimate in y nor the singular homogeneous majorant can replace that step.

All original q, full e_g, low-pe, high-m, forbidden-set, unique j and source-ledger definitions remain those of R292. This note introduces no new positive root gate. A sum over ratio bands must retain its actual coefficients; homogeneity makes positive weak constants additive, not free. No general root source closure is claimed.

## Evidence and bounded outcome

The analytic result is the new general weak column theorem (W1)-(W2), together with the actual finite cap (W3) and source estimate (S1)-(S2). The independent first full run of /tmp/r293_checks.py passed: exact homogeneous hard face identities for n=1,...,64 and128; 27 radial cases at40/60 base digits plus2n guard digits throughn64; 288 rational orientation-enlargement checks throughn10^6; 11 common-soft sums at40/60 digits throughn10000; and216 capped-rearrangement checks. At n=10000 it obtained Csoft=125.99912186808116146, below1+pi sqrt(n)/2=158.07963267948966. These finite diagnostics are recorded separately in /tmp/r293_checks.json. They check the stated scalar/geometric identities, not the original global source-transfer problem. The finite-window hard kernel was not asserted to have weak norm exactly2.
