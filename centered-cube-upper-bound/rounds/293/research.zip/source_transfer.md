# R293 — capped overlap source transfer with the actual FIRST budget retained

## 1. Scope and input from the overlap geometry

This note transfers the new overlap distribution estimate to the ORIGINAL source/receiver integral. It proves an explicit source-concentration receipt and a density-controlled source payment. It does not assume that arbitrary beta has the required density or concentration bound.

Fix one original outer datum and terminal source pair beta=b(y)dy, nu=v(z)dz, both finite positive L1. Retain the original actual p_y=P_(s(x),L(x))(x-y), h_R(x-z), q_-=3lambda/4<=q(x)<=lambda, beta FIRST integral p_y beta<=q(x), the actual hard cap, and every current low-pe/high-m/history/source restriction. Let T denote that SAME nonnegative traffic, without its original outside Lambda.

The main geometry supplies a receiver-column majorant Gamma for this actual suballocation, and a homogeneous degree-minus-n function Phi such that

    Gamma(y,z)<=k(y-z)=min(H0,Phi(y-z)),
    H0=a^(-n)A_n, A_n=1+n log(b/a),
    |{Phi>t}|=K_j/t, t>0,
    K_j=4gamma^n D_sigma(tau_j).

All dependence on j,M, softness and the clipping threshold remains in this exact K_j. A root-order bound for K_j is an input from the geometry proof, not derived here. Source-dependent threshold anchors are allowed only when the same displayed majorant holds uniformly for their actual columns. Otherwise one must first freeze the parameter or use its legitimately dominating endpoint column.

THE FINITE CAP H0 STAYS IN EVERY SOURCE CONVOLUTION. The homogeneous Phi alone is not locally integrable and cannot replace k in a source integral. The capped k need not be globally integrable either, but it is bounded, so its convolution against a finite source is everywhere finite.

## 2. Actual receiver integral to a capped source charge

Keep the original p_y h_R/q and all its actual gates until the column majorant is applied. Since q>=q_-, positive Tonelli and the actual Gamma domination give

    T<=q_-^(-1) integral beta(dy) integral k(y-z)nu(dz). (S1)

The auxiliary forbidden source set in E^-(y,t) can be dropped only positively here; the original e_g, m and low-pe gate are not recomputed on that enlargement. Equation (S1) is a majorant of the actual receiver integral, not a replacement posterior or a claim about a source-sampled hard capture.

Let beta*(u) be the decreasing rearrangement of the ORIGINAL density b with respect to Lebesgue measure. Define

    omega_beta(V)=sup_(|B|<=V) beta(B)=integral_0^V beta*(u)du,

and the explicit source concentration charge

    R_(K,H)(beta)
       =H integral_0^(K/H) beta*(u)du
          +K integral_(K/H)^infinity beta*(u)du/u.       (S2)

For K=0 set R=0. For positive K,H it is finite and <=H W_beta. Layer cake and the weak distribution give, for EACH hard-source point z,

    integral k(y-z)beta(dy)
       =integral_0^H beta(z+{Phi>t})dt
       <=integral_0^H omega_beta(K/t)dt
       =R_(K,H)(beta).                                 (S3)

The final identity follows by nonnegative Tonelli. This is the correct use of a Lebesgue level-volume estimate against arbitrary beta: the volume K/t is passed through beta's ACTUAL concentration modulus, not multiplied by an unproved density cap.

Consequently

    T<=(W_nu/q_-)R_(K_j,H0)(beta).                     (S4)

No assertion L1*weak-L1 -> weak-L1 has been used. The right side depends only on the original source density distribution and mass, not on an unknown E^- superlevel or a newly defined traffic norm.

## 3. Keep the independent source-linear FIRST estimate

The original beta FIRST independently gives

    T<=integral_E (h_R*nu)(x)dx<=A_n W_nu.              (S5)

The last step integrates the exact hard point-scale envelope over [a,b]. No overlap convolution is used. Taking the minimum of two valid bounds for the SAME positive suballocation yields the genuine source-linear receipt

    T<=W_nu min{A_n, R_(K_j,H0)(beta)/q_-}.             (S6)

Thus the capped weak overlap estimate can improve the original source coefficient when its source concentration charge is small. The available hypotheses alone still guarantee the original A_n coefficient. Both costs must not be subtracted from a different suballocation or counted as a free negative credit.

There is a symmetric capped-pair estimate with beta and nu exchanged, even if the original Γ relation is directed: integration against k(y-z), or its reflected kernel, has the same weak distribution and height. Hence also

    T<=(W_beta/q_-)R_(K_j,H0)(nu).

This does not replace the asymmetric FIRST estimate (S5).

## 4. Optimal cap/weak/density transfer, with every mass parameter explicit

If an ORIGINAL source piece satisfies b<=B0 almost everywhere and has mass W_beta, then omega_beta(V)<=min(W_beta,B0 V). Integrating this sharper modulus gives

    R_(K,H)(beta)<=Psi(H W_beta,K B0),                  (S7)

where

    Psi(x,y)=x,                    0<=x<=y,
    Psi(x,y)=y[1+log(x/y)],         x>y>0,

with value zero when the relevant source mass or B0 is zero. This is the optimal bound from only a kernel height H, weak constant K, a source density cap B0 and its total mass. It is attained in the relaxed one-anchor problem by placing density B0 on the largest values of min(H,Phi); finite positive L1 hard sources approximate a point anchor. It is not an assertion that original cube responses attain this relaxation.

For B0=Dq_-, (S4) becomes exactly

    T<=D K_j W_nu g(H0 W_beta/(Dq_- K_j)),              (S8)
    g(z)=z for 0<=z<=1, g(z)=1+log z for z>=1.

A safe displayed consequence is D K_j[1+log_+(H0 W_beta/(Dq_-K_j))]W_nu. With H0=a^(-n)A_n, the logarithm contains

    A_n W_beta/(a^n Dq_- K_j).

Neither this dimensionless mass nor D is suppressed. A root-order K_j transfers to a root-polylog original source price if D and this logarithmic factor have suitable uniform polylog bounds. The actual beta FIRST is a receiver-response cap and does NOT supply either source premise.

For another valid restricted strong-type transfer, if b belongs to L^p, 1<p<infinity, the capped weak kernel has

    ||k||_(p')<=[p K H^(1/(p-1))]^(1/p'),

by integrating its actual distribution for 0<t<H. Hölder at a fixed anchor then gives

    T<=(W_nu/q_-)||b||_p
                   (p K_j)^(1-1/p) H0^(1/p).         (S9)

This is a STRONG p>1 argument with its norm and H0 cost retained. It is not an endpoint weak Young claim and is not applied to a general L1 density without proving that extra norm bound.

## 5. A genuine density-source split retaining the original gates

One positive source split is available directly from the actual caps. Let E be contained in the original receiver set E0 with X=lambda|E0|, as in the R115 receiver ledger. Freeze N>0 and B0>0, and partition the ORIGINAL source densities, without changing e_g or m:

    nu_lo=nu 1{v<=N}, nu_hi=nu 1{v>N},
    beta_lo=beta 1{b<=B0}, beta_hi=beta 1{b>B0}.

Split the current original traffic first by z in nu_lo, then by z in nu_hi and y in beta_lo; the last part has both source densities high. On the first part h_R*nu_lo<=N, while the FULL original beta response divided by q is <=1. Therefore

    T_(nu_lo)<=N|E|<= (N/lambda)X.                     (S10)

This uses FIRST on the original receiver set before any positive receiver extension. With the original outer Lambda, choosing N=epsilon lambda/Lambda pays <=epsilon X.

For the second part, (S7) gives the actual source receipt

    T_(nu_hi,beta_lo)
       <=[W_(nu_hi)/q_-]
                  Psi(H0 W_(beta_lo),K_j B0),         (S11)

or its minimum with A_n W_(nu_hi). The outer factor is Lambda ONCE. This is an explicit source-linear controlled-density branch on arbitrary source distances, not an E^- threshold allocation. If B0=Dq_- and the normalized log in (S8) is controlled, it has the corresponding root-polylog source price.

The exact remaining original integrand is its original full mask multiplied by

    1{v(z)>N}1{b(y)>B0}.                              (S12)

The original low-pe, m, accepted-hard and E^- restrictions remain if already present. No claim is made that (S12) is small, or that the supplied source definitions make either new density piece nontrivial. This split also states precisely what FIRST can pay without pretending it controls beta's source density.

## 6. Smallest missing premise and stopping conclusion

The weak overlap distribution controls Lebesgue volume, whereas beta and nu are arbitrary finite L1 source measures. Their concentration moduli have no uniform quantitative rate supplied merely by those mass assumptions. The true transferable bound is (S3), or the explicit optimal density version (S7), together with the independent FIRST baseline (S6).

Thus a sufficient additional source premise is, for example, a proved density bound b<=Dq_- on the source piece being charged and a proved bound on the exact normalized mass logarithm in (S8). More generally a proved original concentration modulus may be inserted directly into integral_0^H omega_beta(K/t)dt. These are explicit source hypotheses, not automatic consequences of K_j being root order.

Without such source control, or a new geometric allocation that exploits the original receiver caps beyond the column relaxation (S1), this transfer alone does not produce a uniform root source budget for arbitrary positive L1 inputs. In particular it does not pay the high/high concentration remainder (S12). This is the precise remaining premise, not an assertion that the whole original problem is impossible.

For all original terminal/seed data, retain K_j,H0,q_-, the density caps and the source charge INSIDE the original weighted sum unless a valid common bound is proved. Different j or roots do not acquire disjoint source mass merely by being different parameters; their exact original allocation coefficients must still be paid.

## 7. Actual bounded diagnostics

A local Python run checked 81 cap/weak/density cases spanning nine-order mass and density regimes, including both branches of Psi, by explicit integration of min(H,K/u). Nine further step-density cases checked the source rearrangement charge against the optimal density formula and the strong-type bound at p=1.1,2,10. Output:

    PASS sharp cap/weak/density and strong-type source-transfer checks=90

These are finite scalar diagnostics. The layer-cake/rearrangement and actual cap arguments above prove the stated inequalities. No convolution endpoint theorem, new FIRST, source posterior or unproved density hypothesis is used. Only this temporary Markdown deliverable was written; no Git or other author files were modified.
