#!/usr/bin/env python3
"""R293 homogeneous kernel geometry diagnostics; exact Fractions + mpmath40/60."""
import json,random
from fractions import Fraction as F
from pathlib import Path
from math import comb
import mpmath as mp
R=random.Random(29320261018)
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(str(x))
def face(ns):
 for n in ns:
  integral=sum((F(comb(n-1,k)*(-1)**k,2**k)*(F(1,n+k)-F(1,n+k+1)) for k in range(n)),F(0))
  weak=2**n*2*n*integral;assert weak==2
  weights=[F(R.randint(1,100),R.randint(1,100)) for _ in range(5)]
  assert sum(weak*w for w in weights)==2*sum(weights)
 return {'dimensions':ns,'exact_face_integral_cases':len(ns),'exact_additive_weight_cases':len(ns),'weak_norm_each':'2','max_exact_error':'0'}
def radial(ns):
 pe=mp.mpf(0);he=mp.mpf(0);re=mp.mpf(0);count=0
 for n in ns:
  for j in range(3):
   direction=[F(R.randint(1,10),R.randint(1,10)) for _ in range(n)];scale=F(10)**[-3,0,3][j];level=F(10)**[3,0,-3][j]
   vals=[]
   for dp in [40,60]:
    with mp.workdps(dp):
     delta=list(map(mm,direction));c=mm(scale);lev=mm(level)
     def angular(ds):
      with mp.workdps(dp+2*n):
       M=max(ds);ratios=[d/M for d in ds]
       return 2*n*M**(-n)*mp.quad(lambda u:u**(n-1)*mp.fprod(1-u*d for d in ratios),[0,1])
     a=angular(delta);b=angular([c*d for d in delta]);expected=a*c**(-n)
     err=abs(b-expected)/max(1,abs(expected));assert err<mp.mpf('1e-30');he=max(he,err)
     radius=(a/lev)**(mp.mpf(1)/n);rerr=abs(lev*radius**n-a)/max(1,abs(a));assert rerr<mp.mpf('1e-30');re=max(re,rerr)
     vals.append(+a)
   with mp.workdps(90):pe=max(pe,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
   count+=1
 assert pe<mp.mpf('1e-30')
 return {'cases':count,'precision_runs':2*count,'base_decimal_precisions':[40,60],'radial_quad_guard_digits':'2*n','dimensions':ns,'max_normalized_homogeneity_error':mp.nstr(he,12),'max_normalized_radial_level_identity_error':mp.nstr(re,12),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_violation':'0'}
def orientation(ns):
 checks=0;maxratio=mp.mpf(0)
 for n in ns:
  gamma=F(n+1,n)
  for j in range(12):
   c=F(R.randint(1,100),R.randint(101,200));cp=c/gamma;r=cp+(c-cp)*F(j,11)
   L=1/r;RR=r;Lp=1/cp;Rp=c
   assert Lp>=L and Rp>=RR and Lp*Rp==gamma and (Lp/L)*(Rp/RR)==gamma
   # Same exact inequalities in the reverse orientation.
   assert Rp>=RR and Lp>=L;checks+=2
  with mp.workdps(60):
   gn=mp.exp(n*mp.log1p(mp.mpf(1)/n));assert gn<=mp.e;maxratio=max(maxratio,gn/mp.e)
 return {'n_values':ns,'exact_oriented_enlargement_cases':checks,'max_gamma_power_over_e':mp.nstr(maxratio,12),'max_exact_enlargement_or_normalization_error':'0'}
def Csoft(n,dp):
 with mp.workdps(dp):
  if n==1:return mp.mpf(2)
  acc=mp.mpf(2);lnfact=mp.loggamma(n+1)
  for k in range(1,n//2+1):
   loga=lnfact-mp.loggamma(k+1)-mp.loggamma(n-k+1)+k*mp.log(mp.mpf(k)/n)+(n-k)*mp.log1p(-mp.mpf(k)/n)
   acc+=mp.exp(loga)*(1 if 2*k==n else 2)
  return +acc

def softness(ns):
 pe=mp.mpf(0);maxratio=mp.mpf(0);rows=[]
 for n in ns:
  a=Csoft(n,40);b=Csoft(n,60)
  with mp.workdps(90):
   err=abs(a-b)/max(1,abs(b));assert err<mp.mpf('1e-30');pe=max(pe,err)
   bound=1+mp.pi*mp.sqrt(n)/2;assert b<=bound;ratio=b/bound;maxratio=max(maxratio,ratio)
   rows.append({'n':n,'Csoft':mp.nstr(b,20),'root_bound':mp.nstr(bound,20),'ratio':mp.nstr(ratio,15)})
 return {'cases':len(ns),'precision_runs':2*len(ns),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_Csoft_to_root_bound_ratio':mp.nstr(maxratio,12),'rows':rows,'max_violation':'0'}
def capped(count,spread):
 worst=mp.mpf(0);pe=mp.mpf(0)
 for j in range(count):
  ss=['0' if j%13==i else '1e'+str(R.randint(-spread,spread)) for i in range(3)]
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    H,K,V=map(mp.mpf,ss)
    if not H or not K or not V:formula=integral=mp.mpf(0)
    elif H*V<=K:
     formula=H*V;integral=mp.quad(lambda u:H,[0,V])
    else:
     cut=K/H;formula=K*(1+mp.log(H*V/K))
     # First interval in u, second under u=cut*exp(t), preserving the entire finite interval.
     integral=mp.quad(lambda u:H,[0,cut])+mp.quad(lambda t:min(H,K/(cut*mp.exp(t)))*cut*mp.exp(t),[0,mp.log(V/cut)])
    err=abs(formula-integral)/max(1,abs(formula));assert err<mp.mpf('1e-30');worst=max(worst,err);vals.append(+formula)
  with mp.workdps(90):pe=max(pe,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
 assert pe<mp.mpf('1e-30')
 return {'cases':count,'precision_runs':2*count,'input_exponent_range':[-spread,spread],'max_normalized_formula_vs_piecewise_quad_error':mp.nstr(worst,12),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_violation':'0'}
settings=[('initial',list(range(1,9)),[1,2,4],[1,2,16],[1,2,8],24,2),('boundary_stress',list(range(9,33)),[1,8,16],[63,64,65,1023,1024,1025],[63,64,65,512,1024],64,15),('expanded',list(range(33,65))+[128],[1,32,64],[10000,100000,1000000],[2048,4096,10000],128,50)]
stages=[]
for name,fns,rns,ons,cns,count,spread in settings:
 stages.append({'name':name,'hard_tied_face':face(fns),'homogeneous_radial':radial(rns),'ratio_orientation':orientation(ons),'common_soft_sum':softness(cns),'capped_rearrangement':capped(count,spread)})
out={'status':'PASS','seed':29320261018,'scope':'Exact finite Fraction face integral, positive homogeneous sum and orientation algebra, plus ordinary mpmath40/60 radial, binomial common-soft and capped rearrangement diagnostics. No endpoint convolution theorem, source-density transfer, FULL/history certificate, or full-source closure.','kappa':'product_i max(0,1-abs(u_i)); integral kappa=1','Phi':'2n integral_0^infinity g^-n kappa(delta/g) dg/g','two_orientation_receipt':'4 gamma^n D, before optional Csoft coefficient sum','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
