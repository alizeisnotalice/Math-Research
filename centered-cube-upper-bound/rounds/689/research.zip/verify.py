from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json, hashlib
from flint import arb,ctx
p=Path(__file__).resolve().parent
r=json.loads((p/'RESULT.json').read_text())
assert r['script_sha256']==hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()
rows=[r['shared_blocker_fixture'],r['cap_pressure_fixture']]+[c for f in r['negative_continuation_rays'] for c in f['checks']]+r['positive_continuation_fixture']['checks']
assert len(rows)==27
for c in rows:
 boxes=[[(F(a),F(b)) for a,b in B] for B in c['boxes']]; N=len(boxes)
 axes=[]
 for k in range(len(boxes[0])):
  e=sorted({v for B in boxes for v in B[k]}); axes.append([(a,b) for a,b in zip(e,e[1:])])
 cells=[]
 for intervals in product(*axes):
  point=[(a+b)/2 for a,b in intervals]; mass=F(1)
  for a,b in intervals: mass*=b-a
  cells.append(([int(all(a<x<b for x,(a,b) in zip(point,B))) for B in boxes],point,mass))
 assert len(cells)==len(c['positive_cells'])
 u=list(map(F,c['baseline_u'])); v=list(map(F,c['proposal'])); dlt=list(map(F,c['exact_delta_primal'])); y=list(map(F,c['dual_cell_prices_y'])); z=list(map(F,c['dual_cap_multipliers_z']))
 d=[]
 for B in boxes:
  vol=F(1)
  for a,b in B: vol*=b-a
  d.append(vol)
 assert d==list(map(F,c['d_i'])) and all(0<=dlt[i]<=u[i] for i in range(N)) and all(x>=0 for x in y+z)
 b=[]
 for (A,x,m),stored in zip(cells,c['positive_cells']):
  assert A==stored['A_row'] and x==list(map(F,stored['point'])) and m==F(stored['Lebesgue_mass'])
  old=sum(A[i]*u[i] for i in range(N)); add=sum(A[i]*v[i] for i in range(N)); rem=sum(A[i]*dlt[i] for i in range(N)); rhs=max(F(0),old+add-1)
  assert old<=1 and add<=1 and rem>=rhs and old+add-rem<=1
  assert rhs==F(stored['required_deletion_b']); b.append(rhs)
 assert all(sum(cells[j][0][i]*y[j] for j in range(len(cells)))-z[i]<=d[i] for i in range(N))
 cost=sum(d[i]*dlt[i] for i in range(N)); dual=sum(b[j]*y[j] for j in range(len(cells)))-sum(u[i]*z[i] for i in range(N))
 assert cost==dual==F(c['optimal_capped_deletion_C'])==F(c['exact_dual_objective'])
 assert sum(d[i]*v[i] for i in range(N))-cost==F(c['net_gain'])
ctx.prec=256
for n in (1,2,8,256,65536,10**6): assert 8*(1+(1+arb(1)/(32*n))/n)**n < 8*(arb(33)/32).exp()
manifest=p/'MANIFEST.json'
if manifest.exists():
 data=json.loads(manifest.read_text())
 for name,digest in data['sha256'].items(): assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: 27 exact capped primal/dual certificates rebuilt from box endpoints; 6 Arb checks; manifest if present. Finite scope only.')
