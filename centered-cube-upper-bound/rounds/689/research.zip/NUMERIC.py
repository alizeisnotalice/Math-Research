#!/usr/bin/env python3
"""R689 exact capped deletion LP certificates for four frozen geometric mechanisms."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,sys,time,platform
import numpy as np
import scipy
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent;start=time.time()
def cube(y,s):return [(v-s,v+s) for v in y]
def inside(p,B):return all(lo<=v<=hi for v,(lo,hi) in zip(p,B))
def volume(B):
 v=F(1)
 for lo,hi in B:v*=hi-lo
 return v
def cells(boxes):
 axes=[]
 for d in range(len(boxes[0])):
  ep=sorted(set(v for B in boxes for v in B[d]));axes.append([((a+b)/2,b-a) for a,b in zip(ep,ep[1:])])
 out=[]
 for xs in product(*axes):
  p=[v[0] for v in xs];mass=F(1)
  for x in xs:mass*=x[1]
  mask=[int(inside(p,B)) for B in boxes]
  out.append({'point':p,'Lebesgue_mass':mass,'A_row':mask,'mask':sum((x<<i for i,x in enumerate(mask)))})
 return out
def serial(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v

def audit(name,boxes,u,proposal,delta,dual_by_mask,z):
 cc=cells(boxes);di=[volume(B) for B in boxes];n=len(boxes);y=[F(0)]*len(cc)
 for mask,value in dual_by_mask.items():
  indices=[j for j,c in enumerate(cc) if c['mask']==mask]
  assert indices,(name,mask)
  y[indices[0]]=value
 b=[]
 for row in cc:
  a=row['A_row'];baseline=sum((u[i]*a[i] for i in range(n)),F(0));prop=sum((proposal[i]*a[i] for i in range(n)),F(0));rhs=max(F(0),baseline+prop-1);removed=sum((delta[i]*a[i] for i in range(n)),F(0))
  assert baseline<=1 and prop<=1 and removed>=rhs,(name,row,baseline,prop,removed,rhs)
  after=baseline+prop-removed;assert after<=1
  row.update({'baseline_load':baseline,'proposal_load':prop,'required_deletion_b':rhs,'actual_deletion_load':removed,'new_load':after});b.append(rhs)
 assert all(F(0)<=delta[i]<=u[i] for i in range(n))
 assert all(v>=0 for v in y+z)
 adj=[sum((F(cc[j]['A_row'][i])*y[j] for j in range(len(cc))),F(0)) for i in range(n)]
 assert all(adj[i]-z[i]<=di[i] for i in range(n)),(name,adj,z,di)
 primal=sum((di[i]*delta[i] for i in range(n)),F(0));dual=sum((b[j]*y[j] for j in range(len(cc))),F(0))-sum((u[i]*z[i] for i in range(n)),F(0));assert primal==dual,(name,primal,dual)
 value=sum((di[i]*proposal[i] for i in range(n)),F(0));gain=value-primal
 lp=linprog(np.array([float(d) for d in di]),A_ub=-np.array([c['A_row'] for c in cc],dtype=float),b_ub=-np.array([float(v) for v in b]),bounds=[(0,float(v)) for v in u],method='highs')
 assert lp.success and abs(lp.fun-float(primal))<1e-10,(name,lp)
 return {'name':name,'boxes':boxes,'d_i':di,'baseline_u':u,'proposal':proposal,'positive_cells':cc,'all_positive_cells_checked':True,'exact_delta_primal':delta,'dual_cell_prices_y':y,'dual_cap_multipliers_z':z,'dual_Atranspose_y':adj,'optimal_capped_deletion_C':primal,'exact_dual_objective':dual,'proposal_value':value,'net_gain':gain,'new_coefficients':[u[i]-delta[i]+proposal[i] for i in range(n)],'HiGHS_crosscheck':{'success':bool(lp.success),'objective':float(lp.fun),'objective_error':abs(lp.fun-float(primal))},'all_primal_caps_and_dual_columns_checked':True}
def append_far_fee_certificate():
    from flint import arb,ctx
    import flint
    ctx.prec=256;tick=time.time();dst=ROOT/'RESULT.json';old=json.loads(dst.read_text());checks=[]
    bound=8*(arb(33)/32).exp()
    for n in (1,2,8,256,65536,10**6):
        c0=1+arb(1)/(32*n)
        value=(arb(8).log()+n*(1+c0/n).log()).exp()
        assert value<bound
        checks.append({'n':n,'c0_upper_exact':str(1+F(1,32*n)),'far_fee_coefficient_of_U_over_tau':str(value),'uniform_coefficient_bound':str(bound),'margin_to_uniform_bound':str(bound-value),'coefficient_le_uniform_bound':True})
    old['global_far_hit_fee_scalar_check']={'scope':'Scalar verification of the independently proved original-family far-hit R=n filter fee. It is a one-time charge of the qualifying large-hit receiver class, tested across all original remaining targets and does not depend on these toy LPs or a small final g. The geometric filter proof itself is external to this numerical audit.','formula':'K_farnew(n)=8[1+c0/n]^n U/tau, c0=1+1/a<=1+1/(32n)','actual_a_note':'The actual much larger a only decreases c0 and improves the fee.','analytic_uniform_bound':'log(1+x)<=x gives8[1+c0/n]^n<=8exp(c0)<=8exp(33/32) for n>=1. The6 finite checks are not the all-n proof.','precision_bits':ctx.prec,'python_flint_version':flint.__version__,'checks':checks,'command':[sys.executable,str(Path(__file__).resolve()),'--far-fee-only'],'elapsed_seconds':time.time()-tick}
    old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();dst.write_text(json.dumps(old,indent=2)+'\n')
    print(json.dumps({'far_fee_checks':checks,'elapsed_seconds':time.time()-tick,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()},indent=2))

if '--far-fee-only' in sys.argv:
    append_far_fee_certificate()
    raise SystemExit(0)

# 1. Shared central blocker versus proportional deletion.
squares=[cube([F(0),F(0)],F(1)),cube([F(-3,2),F(0)],F(1)),cube([F(3,2),F(0)],F(1))];u=[F(1,8),F(7,8),F(7,8)];proposal=[F(0),F(1,8),F(1,8)]
shared=audit('shared blocker small proposal',squares,u,proposal,[F(1,8),F(0),F(0)],{3:F(2),5:F(2)},[F(0)]*3)
assert shared['optimal_capped_deletion_C']==F(1,2) and shared['net_gain']==F(1,2)
beta=[max(sum((proposal[j]*c['A_row'][j] for j in range(3)),F(0)) for c in shared['positive_cells'] if c['A_row'][i]) for i in range(3)]
propdelta=[u[i]*beta[i] for i in range(3)];propcost=sum((shared['d_i'][i]*propdelta[i] for i in range(3)),F(0));assert propcost==F(15,16)
for c in shared['positive_cells']:assert sum((propdelta[i]*c['A_row'][i] for i in range(3)),F(0))>=c['required_deletion_b']
shared['proportional_beta']=beta;shared['proportional_delta']=propdelta;shared['proportional_cost']=propcost;shared['proportional_gain']=shared['proposal_value']-propcost;assert shared['proportional_gain']==F(1,16)
# 2. Duplicate column and positive baseline cap are indispensable.
intervals=[[(F(-1,2),F(1,2))],[(F(-3,2),F(3,2))],[(F(-1,2),F(1,2))]]
capped=audit('cap and zero-cap duplicate pressure',intervals,[F(1,4),F(3,4),F(0)],[F(0),F(0),F(1,2)],[F(1,4),F(1,4),F(0)],{7:F(3)},[F(2),F(0),F(2)])
assert capped['optimal_capped_deletion_C']==1
uncapped=linprog(np.array([1.,3.,1.]),A_ub=-np.array([c['A_row'] for c in capped['positive_cells']],dtype=float),b_ub=-np.array([float(c['required_deletion_b']) for c in capped['positive_cells']]),bounds=(0,None),method='highs');assert uncapped.success and abs(uncapped.fun-.5)<1e-10
capped['uncapped_relaxation_objective']=F(1,2);capped['uncapped_invalid_candidate']=[F(1,2),F(0),F(0)];capped['uncapped_candidate_violates_baseline_cap']=True
# 3. Exact negative-continuation breakpoint rays.
negative=[];rayboxes=[[(F(-1),F(1))],[(F(-2),F(0))],[(F(2),F(6))],[(F(1),F(3))]]
for slack in (F(1,8),F(1,32),F(1,128),F(1,512)):
 checks=[]
 for t in sorted(set((slack/2,slack,3*slack/2,2*slack,F(1,2)))):
  excess=max(F(0),t-slack);row=audit('negative ray s='+str(slack)+' t='+str(t),rayboxes,[F(1,2),F(1,2),1-slack,F(0)],[F(0),t,F(0),t],[t,F(0),excess,F(0)],{3:F(2),12:F(4) if excess else F(0)},[F(0),F(0),F(0),F(2) if excess else F(0)])
  assert row['optimal_capped_deletion_C']==2*t+4*excess and row['net_gain']==4*t-row['optimal_capped_deletion_C']
  single=[t,F(0),F(0),F(0)];feasible=all(sum((single[i]*c['A_row'][i] for i in range(4)),F(0))>=c['required_deletion_b'] for c in row['positive_cells']);assert feasible==(t<=slack)
  row['t']=t;row['single_blocker_delta']=single;row['single_blocker_feasible']=feasible;checks.append(row)
 negative.append({'slack_s':slack,'checks':checks,'exact_cost_formula':'2t+4(t-s)_+, 0<=t<=1/2','exact_gain_formula':'2t for t<=s;4s-2t for t>=s','initial_gain_slope':F(2),'max_ray_gain':2*slack,'maximizer_t':slack,'scope':'Piecewise-linear formula certified by the stated primal/dual families; finite checks are not an unrelated scan.'})
# 4. Positive continuation after a tiny first slack.
positiveboxes=[cube([F(0),F(0)],F(1)),cube([F(-2),F(0)],F(1,4)),cube([F(-3,2),F(0)],F(1)),cube([F(3,2),F(0)],F(1))];uu=[F(1),F(15,16),F(0),F(0)];positivechecks=[]
for t in (F(0),F(1,32),F(1,16),F(1,8),F(1)):
 excess=max(F(0),t-F(1,16));row=audit('positive continuation t='+str(t),positiveboxes,uu,[F(0),F(0),t,t],[t,excess,F(0),F(0)],{9:F(4),6:F(1,4) if excess else F(0)},[F(0)]*4)
 assert row['optimal_capped_deletion_C']==4*t+F(1,4)*excess and row['net_gain']==8*t-row['optimal_capped_deletion_C'];row['t']=t;positivechecks.append(row)
assert positivechecks[-1]['net_gain']==F(241,64)
# Exact final packing primal/dual on the full four-parent positive-cell arrangement.
cc=cells(positiveboxes);packtheta=[F(0),F(0),F(1),F(1)];prices=[F(0)]*len(cc)
for mask,value in ((9,F(4)),(6,F(1,4)),(4,F(15,4))):prices[next(j for j,c in enumerate(cc) if c['mask']==mask)]=value
for c in cc:assert sum((packtheta[i]*c['A_row'][i] for i in range(4)),F(0))<=1
for i,B in enumerate(positiveboxes):assert sum((prices[j]*cc[j]['A_row'][i] for j in range(len(cc))),F(0))>=volume(B)
assert sum(prices,F(0))==sum((packtheta[i]*volume(positiveboxes[i]) for i in range(4)),F(0))==8
continuation={'checks':positivechecks,'exact_cost_formula':'4t+(1/4)(t-1/16)_+, 0<=t<=1','gain_slopes':[F(4),F(15,4)],'gain_at1':F(241,64),'final_packing_theta':packtheta,'final_packing_optimum':F(8),'final_packing_dual_cell_prices':prices,'final_packing_positive_cells':cc,'scope':'Tiny first slack can be followed by cheap blockers and continued positive gain; it is not a general no-go criterion.'}
allrows=[shared,capped]+[r for fam in negative for r in fam['checks']]+positivechecks
out={'scope':'Four frozen actual finite interval/square deletion-LP mechanism certificates. No actual high-tau owner history, global budget theorem or general breakpoint no-go claim. All packing/deletion inequalities use a.e. positive cells; boundaries are not silently counted as positive overlap.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Fraction geometry, all-positive-cell primal/cap/dual checks and objectives; SciPy HiGHS only cross-checks numerical optima','deletion_LP':'min d.delta subject A.delta>=b=max(fu+fproposal-1,0),0<=delta<=u on every positive cell','deletion_dual':'max b.y-u.z subject y,z>=0,A^T y-z<=d, including cap0 columns','shared_blocker_fixture':serial(shared),'cap_pressure_fixture':serial(capped),'negative_continuation_rays':serial(negative),'positive_continuation_fixture':serial(continuation),'summary':{'frozen_fixture_classes':4,'exact_capped_LP_primal_dual_checks':len(allrows),'all_exact_primal_dual_and_cap_checks_passed':True,'all_HiGHS_crosschecks_passed':True,'negative_slacks':['1/8','1/32','1/128','1/512'],'positive_continuation_gain_at1':'241/64','positive_continuation_final_packing_value':'8'},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest()},indent=2))

append_far_fee_certificate()
