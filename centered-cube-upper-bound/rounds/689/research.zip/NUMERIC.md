# R689 exact capped deletion LPs and frozen breakpoint mechanisms

## Outcome and scope

All four frozen geometric fixture classes match their proposed formulas. Twenty-seven capped deletion LPs have exact rational primal and dual certificates, with all positive Lebesgue cells and all baseline caps checked. HiGHS agrees with every exact optimum. The examples distinguish a genuinely shared blocker, an invalid uncapped relaxation, an expensive continuation after a small breakpoint, and a cheap continuation after a small breakpoint.

These are actual finite interval/square mechanism certificates. They do not supply an original high-tau owner history, a global budget theorem, or a general no-go result from a small first slack. The independent original-family far-hit scalar fee is appended separately below.

## LP and exact certification conventions

For parent boxes Ai with volume di, feasible baseline u and proposal p, construct every full-dimensional arrangement cell. On each cell c set

`b_c=max(f_u+f_p−1,0)`.

The exact deletion LP is

`min sum_i di delta_i`,

`A delta>=b`, `0<=delta_i<=u_i`.

Its dual is

`max b.y−u.z`,

`y,z>=0`, `A^T y−z<=d`.

Every supplied rational delta is checked against every cell and cap. Every rational dual is checked against every column, including columns whose baseline cap is zero. Equal exact objectives prove optimality. A dual row price y_c corresponds to a constant density y_c/|cell_c| on that positive-volume cell if an integral dual is desired.

The arrangement includes all open cells between every coordinate endpoint, with exact masses; outside the finite bounding box all relevant loads vanish. Boundary points are not substituted for positive cells. These are a.e. packing/deletion constraints. No float objective is treated as proof.

## 1. Shared central blocker versus proportional deletion

Three radius-one squares have centers `(0,0),(-3/2,0),(3/2,0)` and di=4. Take

`u=(1/8,7/8,7/8)`, `p=(0,1/8,1/8)`.

Deleting `delta=(1/8,0,0)` fixes both overload regions at once. Its cost is1/2. Dual prices2 on each central/left and central/right positive overlap cell, with all cap multipliers zero, give the same value1/2. The proposal value is1, so exact gain is1/2.

Proportional deletion uses beta_i=1/8 for all three squares and delta_i=beta_i u_i. Its cost is15/16 and its gain only1/16. The code checks its feasibility on every positive two-dimensional cell. Thus feasibility of a proportional rule does not make that deletion optimal.

## 2. Baseline caps and a zero-cap duplicate column

Use intervals

`S=[-1/2,1/2]`, `B=[-3/2,3/2]`, `H=S`,

with volumes `(1,3,1)`, baseline `(1/4,3/4,0)` and proposal `(0,0,1/2)`.

The exact capped optimum is

`delta=(1/4,1/4,0)`, `C=1`.

A dual price3 on the inner cell and cap multipliers `z=(2,0,2)` give

`dual=(1/2)3−(1/4)2=1`.

The multiplier on the zero-cap H column has no objective penalty, but is necessary to satisfy that column's dual constraint. It is retained explicitly.

Dropping caps yields a relaxation with optimum1/2. The candidate delta=(1/2,0,0) has that cost but exceeds the available S mass1/4. It is not a valid deletion. Both the capped and uncapped HiGHS objectives are cross-checked, while only the exact capped primal/dual certifies the intended operation.

## 3. Negative continuation after a shrinking first slack

The actual intervals are

`A0=[-1,1]`, `A1=[-2,0]`, `A2=[2,6]`, `H=[1,3]`,

with volumes `(2,2,4,2)`. For `s=1/8,1/32,1/128,1/512`, take

`u=(1/2,1/2,1−s,0)`, `p=t(0,1,0,1)`, `0<=t<=1/2`.

The two overload constraints are

`delta0+delta1>=t` on(-1,0),

`delta2+deltaH>=(t−s)_+` on(2,3).

The exact primal is `delta=(t,0,(t−s)_+,0)`. Dual price2 on the first overload cell and price4 on the second after the breakpoint prove

`C(t)=2t+4(t−s)_+`.

When the second price is4, its zero-cap H column requires multiplier z_H=2, which is explicitly checked. All other cell constraints and caps are included. The stated primal/dual families establish the piecewise formula on the frozen ray; finite evaluations verify their implementation at the requested points.

The proposal value is4t. Therefore

`G(t)=2t` for t<=s,

`G(t)=4s−2t` for t>=s.

Its initial slope is2 but its maximum on this ray is2s, attained at t=s:

| s | exact maximum ray gain |
|---|---:|
| 1/8 | 1/4 |
| 1/32 | 1/16 |
| 1/128 | 1/64 |
| 1/512 | 1/256 |

For each s, the code checks t=s/2,s,3s/2,2s,1/2, with duplicate removal. The single-blocker deletion t e0 is feasible exactly while t<=s and fails a required positive cell afterward. The positive initial slope alone does not give a uniform finite gain for this frozen family.

## 4. Positive continuation through a cheap new blocker

Use four actual squares

`A=Q((0,0),1)`, `B=Q((-2,0),1/4)`,

`L=Q((-3/2,0),1)`, `R=Q((3/2,0),1)`.

Their volumes are `(4,1/4,4,4)`. B is disjoint from A and lies inside L. Take

`u=(1,15/16,0,0)`, `p=t(0,0,1,1)`, `0<=t<=1`.

Exact deletion is

`deltaA=t`, `deltaB=(t−1/16)_+`, `deltaL=deltaR=0`,

with cost

`C(t)=4t+(1/4)(t−1/16)_+`.

A dual price4 on an A/R overlap cell, together with price1/4 on a B/L cell after the breakpoint, attains that cost; all cap multipliers may be zero. The gain has slope4 before1/16 and15/4 afterward, so continuation remains profitable. Checks are at t=0,1/32,1/16,1/8,1.

At t=1 the gain is exactly241/64 and new packing is `(0,0,1,1)` of value8. The full four-parent packing optimum is also8: an exact positive-cell dual assigns price4 to an A/R cell,1/4 to a B/L cell and15/4 to an L-only cell. The total is8 and every parent-volume constraint is met. This matches the exact final primal.

This contrast shows that a tiny first breakpoint is not a general obstruction. The costs of blockers encountered afterward determine continuation: the negative ray adds volume-cost4 per unit to an existing cost2, while this positive ray adds only1/4 to cost4. No general original-history conclusion is drawn from either model.

## Independent original-family far-hit fee scalar check

The separately proved far-hit filter with radius class R=n is tested on all original remaining targets and pays the qualifying large-hit receiver class once, with fee

`8[1+c0/n]^n U/tau`,

`c0=1+1/a<=1+1/(32n)`.

This fee does not follow from the toy deletion LPs and does not require a small final g. The current appendix checks only its scalar coefficient; the original-family geometric proof and once-only accounting are independent analytic inputs.

At 256-bit Arb precision, substituting the worst permitted c0 gives:

| n | coefficient of U/tau (approx.) |
|---|---:|
| 1 | 16.250000000 |
| 2 | 18.187988281 |
| 8 | 20.597656266 |
| 256 | 21.706572251 |
| 65536 | 21.746099088 |
| 1000000 | 21.746244434 |

Every certified ball lies below

`8exp(33/32)=22.436554849897812896...`.

The all-n bound is analytic: `log(1+x)<=x` gives

`8[1+c0/n]^n<=8exp(c0)<=8exp(33/32)`.

The six finite checks are sanity checks, not an all-dimensions numerical proof. The actual much larger a decreases c0 and improves the coefficient. Full intervals, margins and provenance are retained in RESULT.json.

## Reproducibility and stopping

Executed frozen LP command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r689-20261116/NUMERIC.py
```

The later scalar fee append did not rerun the27 LPs:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r689-20261116/NUMERIC.py --far-fee-only
```

RESULT.json retains exact parent boxes, di, caps, proposals, every positive cell and its mass, primal deletions, dual cell prices, cap multipliers, gains, solver outcomes and final packing dual. Python/platform/NumPy/SciPy versions and python-flint version are recorded. Geometry and all LP certificates use Fraction; SciPy1.18.1/HiGHS is only a floating cross-check. The far-fee appendix uses256-bit Arb.

The27 capped LP checks and one uncapped-relaxation cross-check completed in about0.033seconds of run-body time; the fee append took about0.008seconds. All assertions passed, errors are empty, and both processes exited with code zero. Source SHA-256: `c3434f97afdb98f8a0d50bfee02a2a6c0900aedde52cbb0e1e6ac9d85c8ee4c8`. Result SHA-256: `0e3e4924d2dd450c84f6bdbce3070d11ebf16ae4f7dcdca94ad087ca552abe94`.

Only the three owned R689 files were written. No scan beyond the frozen inputs, MATLAB, package installation, Git, PDF or new agent was used. Computation is stopped.
