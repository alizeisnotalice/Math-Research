# R689 continuation — general bound remains open

Maintain the frozen raw-admission, radius-ordered parent, actual disjoint receiver and all-original-label packing contract. No small-final-field assumption on receivers is valid.

New paid class: T_n(h)=sum q_i over all positive sources with s_i>=n s_h and positive-volume hit of A_h. If T_n>=tau/8, its entire actual receiver piece is paid once. The joint class costs <=8 exp(33/32) U/tau. Full account is V0<=C_adm{[1+(Kfar+Kup+Kall)/tau]U+V_*}. No old fee was removed. Surviving parents have, on each tight cell they contain, >7tau/8 small-radius source rate; the common collection and its cost are not controlled.

Every final tight cell has a true first-saturation birth source. These birth regions partition all tight cells. Birth deletion gives a legal positive step, but its total cost and step length are not uniform. Future exhausted capacities can force larger earlier sources; no monotone radius cascade is proved.

Exact all-cell capped deletion cost and its dual are certificate formats only. Unrestricted optimization is original P0 again. Fixed real receiver w_h=|X_h|/d_h gives V_*=d.w and feasible ray t<=1/||F_w||inf. A lower bound on sup_t[tV_*-C_w(t)] of (gamma V_*-A U)/tau would suffice, but is not proved and is not necessary for other proofs. Preserve all new tight cells, caps, and integrated marginal costs. Do not spend another round merely rederiving this LP or collecting toy counterexamples.

Next substantive target: simultaneous shared deletion across the actual surviving receiver union with a controlled cumulative gain; alternatively a direct original-P0 payment. Use product geometry and true source/receiver history. Positive initial slope and finite toy gains are not global payment.

Validation: 27 rational all-cell deletion certificates and six 256-bit Arb scalar fee checks. Main verify.py independently rebuilds cells from endpoints. Models are auxiliary finite packing examples, not original high-tau histories. Metadata wording was corrected after execution, mathematical fields unchanged. No MATLAB/PDF. User cap from next round: at most one Astra and three GPT-6.1 Sol; local computation according to useful independent tasks.
