# 中心立方体第97轮：共同来源割、捕获中间层与真实外域抵消

2026-10-12。任意非负 L1 输入、真实勒贝格接收测度及全部尺度上的 C_n≤sqrt(n)n^{o(1)} 仍未证明。保留一般 O(n log n) 基准。本轮的严格新工具包括空间来源割证书、额外支付的捕获中间层、同帽深浅分解和正尺度截止下的真实正则化误差；它们的一般剩余费用仍未付清。

共同来源路线把单一深度分布改为保留空间位置的全部有限来源子集约束，并证明该分配至少优于每棵分离树，保留可数尾质量。软层路线另付根阶费用后，获得真正针对已捕获来源的中间下限；软似然倾斜向原硬需求的归一化仍需支付，已用完整原门合资格的真实输入检查这一缺陷。能量路线保留同一帽外四项 Gram 抵消，支付深源与正尺度正则化误差，留下明确的浅层超额项。原始文献的支持、Sobolev 与维数条件均按实际适用范围记录。

主代理还直接验证了一个形状接近立方体的非线性扩散自相似剖面。其线性卷积最大函数与原立方体最大函数在绝对常数内双向比较，因而不能把它的单剖面解或固定时刻质量守恒当作弱端点证明。任意多来源非线性比较和真实最大预算仍缺失。

三名 Astra high 路线、一名 Astra high 与一名 Sol high 独审、两名 Sol high 数值及一名 Sol high 来源核验延续原上下文工作。作者命题先交盲审，随后审计完整 Markdown、对应 LaTeX 文本和程序；主代理另行审核与隔离重放。报告区分原文阅读、作者推导、有限实验、程序重放及独立重建，重放不增加输入数。

私人下界配方、相关程序及未公开定量压力结论只留本地。公开包仅含明确 PUBLIC 内容、中性公开复现和必要清单，保持五个归档成员。详细 LaTeX 只做静态检查，不编译 PDF。


## 原目标、同输入分支与维度账

统一 Q(x,L)=x+[-L/2,L/2]^n、A_L=L^-n integral_Q、mu=f dy、W=||f||1。原局部事件保留 L*∈[1,2]、单位锚点、后来严格硬见证、最早硬接触 A_L*f=lambda、整个窗口 P1<lambda/2、原中间下限以及包和物理删除。theta=log^-2(n+2)，alpha=[10log(n+2)]^-1；原粗门仅在原 L* 成立。帽能量阈值 kappa、分层强度和来源残留质量使用不同符号，不互相代换。

原账：H_n=1+n log2，Cext=2H_n/sqrt(n+2)，Bbase=4+2log2 sqrt(7n/3)，Tsoft=1+log2 min{2n,sqrt[n(theta^-1+4theta/3)]}。固定 p0>0，a0=n^-p0、rho0=n^-1/2、Pdom=[5+3log(1/a0)]/rho0。h*=(16n^(3/2))^-1，E*=exp(nh*)，B*=1+E*[1+(2n²+n)h*]，Pphys=2[E*+B*+2(1+E*)sqrt n]，物理并集只付一次。Aold=Bbase+Cext+Tsoft/alpha+Pdom+Pphys。

设 b_n=exp(-s_n)/2 为原极低截点。新分支 Ecap={捕获的 P1≤b_n lambda} 另付 Cext；其与已付的全来源 P1 极低分支不同。于是局部总账为 (Aold+Cext)W+lambda|Frem|。Frem 上实际已捕获后验满足 E F>b_n 与 E G<alpha。原门未重选、来源未替换。全尺度回代仍保留 C_loc log(n+2)，若另按原强度作二进分层，另付 J_n=O(log n) 及实际重叠。第88轮方差常数和第94轮薄环累计费用仍未证明。

|接口|本轮严格结论|一般未付量|
|---|---|---|
|空间来源割|全部有限 I 的 sum_I x_j≤kappa r(I)^n/6 保证一个全局保留来源在全部帽外接收点、全部尺度均≤kappa/6；有限前缀误差≤真实尾质量|最优未保留质量 B/W 一般不小；这些约束是充分系统，不是原问题的精确 Hall 刻画|
|同帽剩余能量|帽系数≤4e+1；B_energy≤c_n J0 J1(B/W)^2，其中 J0=log(16n²)、J1=log(32n²)、c_n=n/(1−2^-n)|需要对任意输入证明 B/W 足够小，或支付其余分支|
|捕获中间层|Ecap 每个真实子割均有 lambda measure(A)≤Cext mu(N_A)|捕获中间余集的统一来源列预算|
|同后验联合分数|tilted share>1/2；原硬份额只得到>b_n/(2M^n)，可行列费 Cscore=(2/b_n)min(M^n H_n,T1)；去掉 F 下限的比值筛选是合法弱化|不能把大的似然份额当成常数硬份额；较弱筛选在原压力例中可保留全部捕获来源，仍未给一般列收益；指数上界未证明为必要费用|
|同帽外 Gram|D_(Omega,R)(b)=双积分真实外部交核；绝对可积上界 V²/(nR^n)；零总质量另有一阶矩界|R 向零及浅层费用；带符号补偿不能拆成无偿正项|
|深浅分解|E_(Omega,kappa)(f)≤(1+eta)D_(Omega,2r)(b_D)+(1+eta^-1)E_(Omega,(1−gamma)kappa)(f_S)|同帽体积、浅来源、阈值降低与重复分解的累计费用全部保留|
|真实正则化|固定截止误差≤[2n/(n+1)] epsilon R^(-n−1)V²；尺度依赖误差≤2nV² integral epsilon(L)L^(-n−2)dL|任意来源近尺度误差与支持域逆算子的维数常数；不继承原门|
|立方体形正核|q=n² 时 M_cube≤3 M_G≤6 M_cube，一般输入、全尺度均成立|线性卷积并非非线性多源演化；双向比较保留原端点困难|

共同帽回代须对同一任意 f 和每个 kappa 同时成立：|Omega|≤A W/kappa、原全尺度超额能量≤B_energy kappa W。对 q=lambda/kappa≥4，费用≤qA+16nB_energy/(qlog2)，从而≤4A+8sqrt(nAB_energy/log2)。第95轮另有其原假设下的较锐返回 4A+2sqrt(2nAB_energy)；本轮未把两种证明中的符号或假设混用。无论用哪一式，A、B_energy 的一般子幂预算均未完成。

可选全窗口粗门需另付 Tsoft/alpha，可选近锚删除付 1+nlog(1+1/sqrt n)。反复用于新输入 f_i、阈值 lambda_i 时，转换至 lambda_0 的费用为 (lambda_0/lambda_i) times 当前费用 times ||f_i||1；终端接收需求不能省略。本轮没有证明这些费用可和，也没有给私人原门未知补集计零。

下一轮主瓶颈应针对共同列预算或来源自适应帽的浅层支付。已知分离树过计、似然份额误转硬份额、单剖面卷积冒充多来源非线性解均不再作为强猜想。


## 1. Scope and actual input

Let \(n\ge2\), \(f\ge0\) be integrable, \(W=\int f\), and \(\kappa>0\). Retain the R95 maximal bad rectangles, their original labels \(\ell_Q\), the actual bad-source measure \(\mu=f1_U\,dy\), and the one cap \(\Omega=\bigcup_Q(1+1/n)Q\). Its volume is at most \(4eW_{\rm bad}/\kappa\). All source restrictions use this same physical input; none inherits a new original gate or stopping label.

We prove a spatial source-allocation certificate that is at least as effective as every separation-tree allocation on the same source pieces. It retains all source-subset constraints and fixes the full source restriction before any receiver or scale is selected. The countable extension has an explicit tail-mass error. New actual-source pressure shows strict improvement over every separation tree in a local branch and shows why singleton capacities alone are insufficient. The resulting residual is fully charged through the retained common-cap energy argument. Its general smallness remains unproved; this is not the root-order weak theorem.

Put \(\theta=1/6\), \(J_0=\log(16n^2)\), \(J_1=\log(32n^2)\), and \(c_n=n/(1-2^{-n})\). The construction also applies with a smaller positive \(\theta\).

## 2. One allocation and every source cut

Take a finite or countable decomposition
\[
 \mu=\sum_j\mu_j,\qquad m_j=\|\mu_j\|>0,\qquad\sum_jm_j=W_{\rm bad}. \tag{1}
\]
The pieces can be disjoint density restrictions. More generally a nonnegative measure decomposition with the exact sum (1) is sufficient; it cannot count the same source mass twice. Each piece has an almost-everywhere support enclosure
\(S_j=\prod_{i=1}^n[l_{ji},u_{ji}]\), and a certified number
\[
 0<a_j\le2\mathop{\rm ess\,inf}_{y\sim\mu_j}
             \operatorname{dist}_\infty(y,\Omega^c). \tag{2}
\]
Zero-mass pieces are omitted. Such countable pieces are always available: each original bad rectangle is bounded and has positive padding clearance. Using finer support enclosures is optional, not free new source mass.

For every finite nonempty index set \(I\), define
\[
 r(I)=\max\left\{\max_{j\in I}a_j,
 \max_{1\le i\le n}\left(\max_{j\in I}l_{ji}-\min_{j\in I}u_{ji}\right)_+\right\}.
 \tag{3}
\]
This is nondecreasing under inclusion. Choose one collection of masses \(x_j\) satisfying
\[
 0\le x_j\le m_j,\qquad
 \sum_{j\in I}x_j\le\theta\kappa r(I)^n
 \quad\hbox{for every finite nonempty }I. \tag{4}
\]
Set \(g=\sum_j(x_j/m_j)\mu_j\). These fractions are fixed for all receivers and all scales.

**Spatial capture lemma.** For all \(x\in\Omega^c\) and \(L>0\),
\[
 A_Lg(x)\le\theta\kappa. \tag{5}
\]
For a finite family of pieces positively captured by \(Q(x,L)\), choose a source point in each positive intersection outside the exceptional null sets in (2). Exterior capture forces \(L\ge a_j\). A captured point in \(S_j\) also gives \(l_{ji}\le x_i+L/2\) and \(u_{ji}\ge x_i-L/2\). Hence \(r(I)\le L\). The captured retained mass from this finite family is at most \(\sum_Ix_j\le\theta\kappa L^n\). If infinitely many pieces are captured, apply this inequality to every finite subfamily and use nonnegative monotone convergence. Divide by \(L^n\).

The conclusion is pointwise in every exterior receiver and scale. In particular, for every measurable exterior set \(E\) and every measurable positive scale selector \(L(x)\),
\[
 \int_E A_{L(x)}g(x)\,dx\le\theta\kappa|E|. \tag{6}
\]
Thus arbitrary receiver sets or Hall cuts do not require separate source allocations. Equation (4) is a sufficient geometric source-cut system, not an assertion that these inequalities are necessary for all exterior-safe source restrictions. Support enclosures and individual clearances may impose constraints on configurations with no common exterior receiver. We do not call this relaxation an exact Hall characterization of the original problem.

## 3. Finite optimization, countable tails, and source splitting

Let \(R_*\) be the maximum of \(\sum_jx_j\) under (4), and put
\[
 B_*=W_{\rm bad}-R_*. \tag{7}
\]
For a finite family this is a finite linear program. No solver status is needed for the theorem: zero is feasible, the box is compact, and the objective is continuous. A feasible allocation is a lower certificate for retained mass. Any nonnegative finite dual weights \(u_j,v_I\) with
\[
 u_j+\sum_{I\ni j}v_I\ge1
\]
give the elementary upper certificate
\[
 \sum_jx_j\le\sum_jm_ju_j+
       \sum_I\theta\kappa r(I)^n v_I. \tag{8}
\]
This follows by multiplying and summing the stated constraints; no claim of unverified numerical dual optimality is made.

The countable maximum also exists. A maximizing sequence has a coordinatewise convergent subsequence by successive compact-interval extraction and a diagonal argument. Every finite constraint passes to its limit. Summability of \(m_j\) gives a uniform tail bound for the objective, so the total retained masses converge too.

Let \(R_K\) be the optimum for the first \(K\) pieces. Extending its allocation by zero is feasible for the whole system: for any finite \(I\), use (4) on its head and monotonicity of \(r\); an empty head has zero mass. Restricting a full optimum to its head is feasible in the head problem. Consequently
\[
 R_K\uparrow R_*,\qquad
 0\le R_*-R_K\le\sum_{j>K}m_j. \tag{9}
\]
A finite calculation therefore leaves an explicitly paid tail of actual source mass. It never declares an unprocessed tail free.

Splitting one piece into density fractions with identical enclosure and clearance does not change \(R_*\). A feasible unsplit allocation can be split in the same mass proportions; any partially chosen split pieces have at most the mass of the corresponding full original groups, with exactly the same value of \(r\). Conversely, the union cuts for all fragments give the unsplit constraints after their allocated masses are summed. This is invariance under redundant labeling of the same physical source. Refining to genuinely smaller geometric enclosures can improve the sufficient system and is not claimed to leave it unchanged.

## 4. Domination of every separation tree

For comparison, take any finite rooted tree whose leaves are the same pieces and whose internal nodes have at least two children. For an internal node \(v\), let
\[
 d_v=\min_{\substack{j,k\text{ below }v\\
                   j,k\text{ in different children}}}
       \operatorname{dist}_\infty(S_j,S_k),\qquad
 \tau_v=\max\{d_v,\min_{j\text{ below }v}a_j\}. \tag{10}
\]
At a leaf \(j\), set \(\tau_j=a_j\). Impose the laminar capacities
\[
 \sum_{j\text{ below }v}x_j\le\theta\kappa\tau_v^n,
 \qquad0\le x_j\le m_j. \tag{11}
\]
This includes the inherited depth bound as well as separation; omitting it would create a needlessly weak comparison.

Every tree allocation is exterior-safe. If a receiving cube captures more than one leaf, take their lowest common ancestor. Two active children force \(L\ge d_v\), and at least one captured leaf forces \(L\ge\min_{j\text{ below }v}a_j\). Thus its total retained capture is bounded by that node's capacity. A single active leaf is handled by its leaf constraint.

More strongly, every allocation satisfying (11) satisfies every constraint (4). For a nonsingleton \(I\), its lowest common ancestor has two children meeting \(I\). The coordinate span in (3) is at least the box distance for such a pair, hence at least \(d_v\); also \(\max_{j\in I}a_j\ge\min_{j\text{ below }v}a_j\). Thus \(r(I)\ge\tau_v\), while \(\sum_Ix_j\) is at most the node mass. Singletons use their leaf constraints. Therefore
\[
 R_*\ge R_{\mathcal T}\quad\hbox{for every such tree }\mathcal T.
 \tag{12}
\]
This comparison holds for general supplied source pieces, not only a test family.

The exact maximum tree mass is obtained by the recursion
\[
 R_j=\min\{m_j,\theta\kappa a_j^n\},\qquad
 R_v=\min\{\theta\kappa\tau_v^n,\sum_{w\text{ child of }v}R_w\}.
 \tag{13}
\]
The upper bound is immediate. To attain it, combine child allocations and, if their total exceeds the parent capacity, scale their combined allocation by the common factor needed to reach that capacity. Scaling down preserves every descendant constraint. This is a single completed allocation, not a separate choice at each receiving cut.

The private actual-source checks below show that (12) can be strict even against the best choice of separation tree. A short edge crossing any root partition can restrict an entire large source cluster in (11), whereas (4) uses the span of the particular subset a cube could capture. The repair pays those local subsets directly; it does not postulate a stronger packing theorem.

## 5. The residual has a paid common-cap budget

Use a maximizing allocation, or any feasible allocation with retained mass \(R\), and write \(b=\mu-g\), \(B=W_{\rm bad}-R\). Keep every point's original bad-rectangle label, even if one piece spans several labels. Define
\[
 N_b(x,L)=\sum_{\ell_Q>L/(8n)}A_L(b1_Q)(x),\qquad
 \widehat N_b(x,L)=\sum_{\ell_Q>L/(16n)}A_L(b1_Q)(x).
 \tag{14}
\]
The original short source contributes less than \(2\kappa/3\), and the near part of \(g\) is at most (5). Therefore
\[
 (A_Lf-\kappa)_+^2\le(N_b-\kappa/6)_+^2
 \quad\hbox{on }\Omega^c. \tag{15}
\]
The original per-label exterior scale windows and mass conservation give
\[
 \int_{\Omega^c}\int N_b\,dL/L\,dx\le BJ_0,
 \quad
 \int_{\Omega^c}\int\widehat N_b\,dL/L\,dx\le BJ_1. \tag{16}
\]
These are restrictions of the original labels, with total mass \(B\). Cube nesting on \(s\in[L,2L]\) gives
\(\widehat N_b(x,s)\ge(L/s)^nN_b(x,L)\); hence, for
\(h_b(x)=\int\widehat N_b(x,s)\,ds/s\),
\(N_b(x,L)\le c_nh_b(x)\).

For \(B>0\), remove the one additional set
\(\{x\in\Omega^c:h_b(x)>\kappa J_1B/W\}\). Its volume is at most \(W/\kappa\), and outside the resulting \(\Omega^*\),
\[
 |\Omega^*|\le(4e+1)W/\kappa,
 \qquad
 \mathcal E_\kappa(f;\Omega^*)
 \le c_nJ_0J_1\kappa\frac{B^2}{W}. \tag{17}
\]
Here \(\mathcal E_\kappa=\int_{(\Omega^*)^c}\int_0^\infty(A_Lf-\kappa)_+^2\,dL/L\,dx\). For \(B=0\), the energy is zero outside the base cap. If \(W=0\) or \(W_{\rm bad}=0\), use the empty residual and the original short bound. All scale and source tails in (16) are covered by nonnegative Tonelli; (9) pays finite-optimization truncation errors.

For any fixed piece geometry, (12) makes the residual and the coefficient in (17) no worse than those obtained from any separation tree. A subpower coefficient would still require a uniform sufficiently small \(B/W\). The general finite-source optimization does not prove such a bound.

## 6. Return formula, limits, and verification scope

The retained reconstruction interface in the R95 integrated proof states: if, for every threshold of the same input, one has a common cap of volume at most \(A_nW/\kappa\) and all-scale exterior excess energy at most \(B_n\kappa W\), uniformly over all inputs, then
\[
 C_n\le4A_n+2\sqrt{2nA_nB_n}. \tag{18}
\]
Our coefficient in (17) is \(B_n=c_nJ_0J_1(B/W)^2\) only for the supplied allocation. We have not uniformly bounded it by a subpower function. No original selector, smooth gate, coarse gate, or layered Hall fee is transferred to the restricted source. The general target remains OPEN.

The all-subset system is still a geometric outer estimate of captured mass. It counts each selected piece's entire retained mass once a cube merely touches that piece, and independent clearance bounds do not encode a common exterior center. Singleton constraints can therefore be expensive for wide boundary pieces, and finer partitions may introduce many coupled constraints. These losses, and a uniform residual bound for general physical inputs, are the next unresolved requirements. They are not hidden behind (18).

A04 was used as a shared-variable check, not as an optimality theorem for independently chosen cuts. G03 explicitly lacks a verified private capture-tree/source-to-Gram interface, so no theorem is imported from that interface. The source vectors, spatial enclosures, tree capacities and comparison above are defined and proved here. No new primary-paper reading is claimed.

The three stages have actually completed on 21 distinct positive L1 densities on continuum space: pilot 6, stress 6, and expanded 9. The pilot dimensions were 4 and 6; stress and expansion used 4, 6 and 8. The expanded inputs contained up to 512 actual source pieces. Each physical input was executed twice: the first execution completed the checks but its separate receipt writer failed, then the final run completed both checks and receipt saving. This is 42 fixture executions on 21 distinct inputs, not 42 new sources. All arithmetic certifying source masses, capacities, cap volumes, subset inequalities, tree optima and receiver boxes is rational.

On small instances the program enumerates every source subset and uses subset dynamic programming over every binary child partition to certify the optimum over all binary trees. On large chains the proved cardinality-to-span lemma reduces all subsets to the stated finite cardinality checks; it does not pretend to enumerate them individually. Ten of the physical inputs also undergo exhaustive duplicate-label subset checks with their source unchanged. These checks are not new physical inputs.

The full exterior receiver space and all scales are covered by the geometric certificates, not by a receiver grid. Three pressure inputs additionally have exact positive-volume receiver boxes and nondegenerate scale intervals that violate the independently assigned absorption budgets before the shared-cut repair. No receiver energy integral was computed. Private recipes, quantitative tree-overcharge results and the exact execution output are outside the public block.

Both auditors independently passed the complete Markdown and matching TeX mathematics, private source proofs, embedded algorithm and exact results. Each also independently extracted and replayed the embedded program: the mathematical JSON agreed after removing only total and per-stage timing fields. Astra reported external elapsed time 0.319093667 seconds; Sol reported 0.295699375 seconds. These two auditor replays are separate from the 42 author fixture executions and introduce no new physical sources. Neither replay is a receiver-energy computation or an independent reconstruction of the author algorithm. The statement-first reviews and the final full reviews agree on the conditional scope: a uniform small residual remains unpaid.

## 1. Result and limitation

The part of the original middle event whose **captured** P1 contribution is below the original extreme cutoff can be paid at root order. This gives a legitimate joint pair of moment conditions on the actual captured posterior, rather than transferring the full P1 lower bound through an unproved source truncation. The extra deletion costs another explicit Cext; it is not the already-paid full-P1-low event.

The resulting P1 likelihood tilt has an exact joint score estimate, but converting its mass back to original hard demand has a potentially exponential normalization cost. A new private physical pressure family, checked on a positive-volume receiver cube with the same earliest selector and all stated original gates, verifies that a large tilted share need not be a constant hard share. Thus this round obtains a useful paid captured-middle refinement and a qualified obstruction to a particular score-conversion step. It does not prove the general root-order weak bound, nor rule out a different use of the joint gates.

## 2. Original data and the additional captured-low deletion

Let n>=2, dmu=f dy, f>=0 in L1, W=||f||1, and Q(x,L)=x+[-L/2,L/2]^n. Write H_n=1+n log2. On the original Fnew use its actual earliest L=L*(x) in [1,2], A_L f=lambda, original anchor and later strict witness, full-window P_(1,s)<lambda/2, original middle P_(1,L)>b_n lambda, and all retained packet/physical gates. Let

    phi=1_[-1/2,1/2]*w, w(t)=integral_0^1 exp(-|t|/v)dv,
    Phi=phi^tensor n, M=phi(0), m=phi(1/2),
    ell=-log phi, ell_e=-log m, mu_ell=integral_(-1/2)^(1/2) ell,
    d=log(M/m),
    s_n=ell_e+(n-1)mu_ell+(d/2)sqrt((n-1)log(n+2)),
    b_n=(1/2)exp(-s_n), Cext=2H_n/sqrt(n+2).                 (1)

The actual captured law and captured contribution are

    pi_x(dy)=1_Q(x,L)(y)dmu(y)/(lambda L^n),
    C1(x)=L^(-n)integral_Q(x,L) Phi((x-y)/L)dmu(y).          (2)

Define Ecap={x in Fnew:C1(x)<=b_n lambda}. Then every measurable subcut A of Ecap satisfies

    lambda|A|<=Cext mu(N_A),                               (3)

with N_A its essential original capture neighborhood. Thus Ecap is paid with the same physical source and original selector. On Frem=Fnew\Ecap one has the genuinely captured bounds

    b_n<Z_x:=E_pi Phi((x-Y)/L)<1/2.                        (4)

The upper bound follows from the original full P1 gate; the lower follows from the new paid branch. The full P1 lower gate alone does not imply it.

Proof of (3). C1/lambda<=e^-s_n/2 implies pi{Phi<e^-s_n}>=1/2 by the elementary first-moment bound. Coordinatewise monotonicity of phi implies that radial normalization to the boundary of the unit cube only increases the loss sum. The reference cone fraction is

    delta_n=Pr{ell_e+sum_(j=1)^(n-1) ell(U_j)>s_n},

where only the reference U_j are independent uniform variables on [-1/2,1/2]. Their range has length d. For a bounded variable X of range d, the second derivative of its tilted log moment-generating function is a variance at most d^2/4. Integrating twice gives log E exp(t(X-EX))<=t^2d^2/8. Markov and optimization at the deviation in (1) give delta_n<=(n+2)^(-1/2). The sourcewise radial hard envelope integrates to H_n, and restriction to this cone multiplies its integral by delta_n. Normalize the at-least-half captured rows by a factor at most two. This gives a common original-capture allocation with columns at most 2H_n delta_n, proving (3), including all subcuts. The original P1 lower gate and any uncaptured source contribution play no role in this payment.

## 3. Exact joint score on the same posterior

Keep theta=log^(-2)(n+2), alpha=1/[10log(n+2)]. At the SAME original selector put

    F_x(y)=Phi((x-y)/L), G_x(y)=Phi_theta((x-y)/L).

The original selected coarse gate gives E_pi G_x<alpha. Thus (4) and this upper bound are truly joint constraints on one probability law. More generally, after paying R96's additional full-window coarse-high branch, one may use a legal s=L/t in [1,2] and G_x(y)=Phi_theta(t(x-y)/L), with E_pi G_x<u=alpha t^(-n). This optional version needs its explicit extra fee and any near-anchor complement. It is not needed for the main t=1 theorem here.

For h>0, R>0 define the actual source-dependent score set

    S_x(h,R)={y in Q(x,L):F_x(y)>=h, G_x(y)/F_x(y)<=R}.

Then, without independence,

    integral_(S_x) F_x dpi > b_n-h-u/R,
    pi_x(S_x)>=max(0,b_n-h-u/R)/M^n.                       (5)

Indeed the F-weight on {F<h} is at most h; that on {G/F>R} is at most E G/R<u/R. Subtract their union from Z_x>b_n. Taking

    h=b_n/4, R=4u/b_n                                    (6)

gives F-weight greater than b_n/2, and hard captured share greater than b_n/(2M^n).

Equivalently, define the normalized likelihood tilt

    dnu_x=(F_x/Z_x)dpi_x.

All quantities are finite: m^n<=F_x<=M^n on the captured cube, so the Radon--Nikodym derivative and its logarithm are bounded for each n. Under this law

    E_nu(G/F)=E_pi G/Z_x<u/Z_x,
    nu_x{G/F>4u/b_n}<1/4,
    nu_x{F<b_n/4}<1/4,
    nu_x(S_x)>1/2.                                       (7)

The change of measure back to pi costs its actual density bound M^n/Z_x. It is not permissible to identify the two posterior masses or assume their coordinates are independent. No variational theorem, martingale or unproved conditional concentration theorem is being invoked.

## 4. Original-capture capacity and its unpaid normalization

Let S_x be (6). Its weighted kernel

    k_x(y)=L(x)^(-n)1_Q(x,L)(y)F_x(y)1_(S_x)(y)

has row mass greater than b_n lambda/2. Normalizing it to lambda demand uses multiplier at most 2/b_n and preserves original capture support. The sourcewise envelope is bounded both by M^n times the hard envelope and by the ordinary smooth physical envelope. Hence every measurable subcut A of Frem has the valid estimate

    lambda|A| <= Cscore mu(N_A),
    Cscore=(2/b_n)min(M^n H_n,T1),
    T1=1+(log2)sqrt(7n/3).                                (8)

The uniform source column is proved by Tonelli on the same physical source. There is no separate capacity for each receiver or source label. Estimate (8) is not claimed root order: b_n is exponentially small. Retaining the joint score may reduce a particular column, but a general estimate for that restricted column remains absent.

The private qualified pressure tests the concrete conversion in (7), not arbitrary abstract laws. Its conclusion is only that a substantial likelihood-tilted score share cannot be declared a constant hard captured share merely from these joint gates. This does not establish a weak-norm lower bound or a lower bound for optimal source allocation. It does identify the normalization defect in this particular attempted inference while leaving (3)--(8) valid. It does not prove that the exponential coefficient in (8) is necessary: the actual small receiver volume can compensate in a common-column estimate.

### 4.1 A weaker ratio-only alternative

The hard-likelihood cutoff in (6) is optional. For S0_x={G_x/F_x<=4u/b_n}, one has

    integral_(S0_x) F_x dpi > Z_x-b_n/4 >3b_n/4.            (8a)

The corresponding original-capture weighted rows have multiplier at most 4/(3b_n), hence shared column bound [4/(3b_n)]min(M^n H_n,T1). This valid weakening avoids deleting low-F sources solely because of the additional cutoff. It does not itself supply a root-order column estimate. The particular private family is rechecked for this alternative rather than used to rule it out by assertion; its quantified outcome is recorded privately below. Accordingly the normalization pressure is explicitly limited to the two-cutoff extraction and the general passage between tilted and hard shares, not all likelihood-tilt strategies.

## 5. Complete local fee and repeated-use scope

For clarity keep all previously paid constants. With fixed p0>0, let

    Bbase=4+2log2 sqrt(7n/3),
    Tsoft=1+(log2)min(2n,sqrt(n(theta^(-1)+4theta/3))),
    a0=n^(-p0), rho0=n^(-1/2), Pdom=(5+3log(1/a0))/rho0,
    h*=1/(16n^(3/2)), E*=exp(nh*),
    B*=1+E*[1+(2n^2+n)h*],
    Pphys=2[E*+B*+2(1+E*)sqrt(n)],
    Aold=Bbase+Cext+Tsoft/alpha+Pdom+Pphys.                 (9)

The already-paid physical union Pphys is charged once. The new captured-low branch adds another Cext, so the exact local statement is

    lambda|E_initial| <= (Aold+Cext)W+lambda|Frem|.        (10)

One may substitute (8), but it supplies no root-order conclusion. The optional all-window coarse refinement adds Tsoft/alpha; R96's optional near-anchor deletion at 1+1/sqrt(n) adds 1+n log(1+1/sqrt(n)). Neither is silently included in (10). The original all-scale transfer retains C_loc log(n+2), and any separately used kappa stratification retains its actual J_n and overlaps. Any separate R83 registered-width union carries its own Cext.

There is no source restriction, changed threshold or recursion in (3)--(10), hence no hidden terminal. If repeated at current inputs f_i, thresholds lambda_i and original reselected contacts, each added branch costs Cext W_i at its own threshold. At original threshold lambda_0 its price is (lambda_0/lambda_i)Cext W_i; all optional fees transform identically. No summability of this occupation, no favorable terminal after an out-of-branch exit and no transfer of old gates to a restricted input is proved here. An unfinished recursive receiver remainder keeps its actual terminal demand (or the retained full-window bound with its threshold conversion).

## 6. Verification and remaining task

D02 was read with its finite-domain conditions. The tilt above is an explicitly defined finite likelihood change of measure, not an appeal to an extended entropy principle. H05's dependence requirement is respected in (3): independence is used only for the reference cone. The captured law and all actual gates retain arbitrary input correlations.

Three new stages used six distinct compact positive-L1 physical sources defined by exact formulas, with an entire explicit receiver cube in each case. Rather than enumerate their exponentially many identical sign components, the program checks rigorously proved product formulas and uniform all-window bounds with rational outward logarithm intervals. No Monte Carlo, exponent fit or floating qualification is used. The stages contain 2/2/2 dimensions and passed 174 assertions, 58/58/58, in 2.040806750 seconds. Detailed recipes, quantified outcomes and the reproducible program are PRIVATE below. This is actual original-selector qualification, not the private phase author's former included-node calculation. The phase author's separate original-root work is not assumed in this proof.

Independent Astra audit read the complete MD and matching detailed TeX, including the private whole-receiver original-gate proof, and passed all stated mathematics and scope. It also read the complete ratio-only addendum and independently replayed the final program: PASS 174 (58/58/58), internal 2.044775459 seconds and external 2.063908125 seconds. Its earlier 168-check replay is historical, not an additional source group; the final replay uses the same six physical source formulas. The fixed-p0 eventual quantifier and the finite p0=1,4,16 checks remain distinct.

Independent Sol audit also read the complete MD and matching TeX, including the private whole-receiver, all-earlier-contact and all-window gate proof and the ratio-only addendum, and passed the mathematics and scope. Its final extracted replay passed 174 checks (58/58/58), internal 2.037771417 seconds and external 2.058227292 seconds. This is an independent replay of the same six source formulas and exact sufficient inequalities, not an independent numerical integration of the original operator.

The new noncircular result is the root-priced captured-middle refinement (3). Its remaining score-capacity problem is not solved: the return from soft likelihood weight to hard demand must preserve the small normalizing mass, or a different common allocation must bypass it with a proved source budget. All public claims stop at that boundary.

## A0. Result and scope

The exterior cube average admits an exact signed quadratic kernel. Keeping that kernel avoids the deep-concentration divergence of the full weighted-gradient relaxation. Its finite-depth consequence has an explicit geometric cost, and a shallow/deep decomposition leaves the genuine shallow-source excess as a separate, fully stated obligation. No uniform shallow-source budget is proved. In fact, for a prescribed cap, that remainder cannot be controlled by source mass alone without further geometry. This is a cancellation-preserving estimate and a precise limitation of the proposed route, not a proof of the general root-order target.

Write $Q_L=[-L/2,L/2]^n$, $A_L\nu(x)=L^{-n}\nu(x+Q_L)$ for a finite measure, and
\[
 \mathcal E_{\Omega,\lambda}(f)
 =\int_{\Omega^c}\int_0^\infty(A_Lf(x)-\lambda)_+^2\,\frac{dL}{L}\,dx.
 \tag{A1}
\]
Here $n\ge2$, $\lambda>0$, and the same measurable cap $\Omega$ is used at every scale. Receiver measure is ordinary $n$-dimensional Lebesgue measure. No cap-volume fee is hidden in a weighted receiver measure.

## A1. Exact exterior Gram identity and its absolute-integrability certificate

Let $b$ be any finite real signed Borel measure on $\mathbb R^n$, put $V=|b|(\mathbb R^n)$, and fix $R>0$. Define
\[
 \begin{split}
 D_{\Omega,R}(b)&=\int_{\Omega^c}\int_R^\infty |A_Lb(x)|^2\,\frac{dL}{L}\,dx,\\
 K_{\Omega,R}(y,z)&=\int_R^\infty
 \frac{|(y+Q_L)\cap(z+Q_L)\cap\Omega^c|}{L^{2n}}\,\frac{dL}{L}.
 \end{split}
 \tag{A2}
\]
Then
\[
 0\le K_{\Omega,R}(y,z)\le\frac1{nR^n},\qquad
 D_{\Omega,R}(b)=\iint K_{\Omega,R}(y,z)\,db(y)\,db(z)
 \le\frac{V^2}{nR^n}.
 \tag{A3}
\]
The quadratic form is nonnegative; its individual signed cross terms need not be nonnegative.

Proof. Indicator functions of the translated closed cubes and the cap complement are jointly measurable. The intersection in (A2) has volume at most $L^n$. Hence its scale integral is at most $\int_R^\infty L^{-n-1}\,dL=1/(nR^n)$. More explicitly, the integral of the absolute dominating integrand against $dx\,dL/L\,d|b|(y)\,d|b|(z)$ is at most $V^2/(nR^n)$. Ordinary signed Fubini is therefore applicable, including for unbounded receiver space and the infinite scale interval. Expanding $|A_Lb|^2$ and integrating $x$ gives exactly (A3). No gradient norm, boundary trace, spectral extension, or unproved signed limit exchange occurs.

For $b=f\,dx-s\,dx$ with $f,s\ge0$ integrable, the identity retains
\[
 D_{\Omega,R}(b)=K[f,f]-2K[f,s]+K[s,s],
 \quad K[p,q]=\iint K_{\Omega,R}(y,z)p(y)q(z)\,dy\,dz.
 \tag{A4}
\]
All three integrals are finite for $R>0$. In particular, the reference square is not discarded, and the negative cross contribution is not estimated as an independent positive energy. If additionally $b=-\Delta u$ for an actual potential, (A3) applies directly to that same signed charge; it neither replaces it by $|\nabla u|$ nor assumes the existence of a new potential.

## A2. Paid large-scale cancellation

Suppose also $b(\mathbb R^n)=0$ and, for one anchor $z_0\in\mathbb R^n$,
\[
 M_1(z_0)=\int\|y-z_0\|_1\,d|b|(y)<\infty.
\]
For every $R>0$,
\[
 D_{\Omega,R}(b)
 \le\min\left\{\frac{V^2}{nR^n},
 \frac{2VM_1(z_0)}{(n+1)R^{n+1}}\right\}.
 \tag{A5}
\]
The second term pays the cancellation of the total signed mass and improves the large-scale power by one. Its moment and dimension dependence are explicit.

Proof. Zero total mass gives the exact anchored identity
\[
 A_Lb(x)=L^{-n}\int
 [1_{y+Q_L}(x)-1_{z_0+Q_L}(x)]\,db(y).
\]
Cauchy--Schwarz against $|b|$ and then Tonelli bound the full-space squared norm by
\[
 V L^{-2n}\int |(y+Q_L)\triangle(z_0+Q_L)|\,d|b|(y).
\]
The symmetric-difference volume is
\[
 2\left[L^n-\prod_{j=1}^n(L-|y_j-z_{0j}|)_+\right]
 \le2L^{n-1}\|y-z_0\|_1.
\]
The inequality follows from a union bound on the coordinate strips; if a coordinate displacement exceeds $L$, its right side already exceeds $2L^n$. Restricting the squared norm to $\Omega^c$ can only decrease it. Integrating $2VM_1L^{-n-1}$ against $dL/L$ over $[R,\infty)$ gives the second term in (A5); (A3) gives the first. These are actual kernel and total-variation estimates, not a claim of dimension-free Schur control.

For $0<R_0<R$, the finite interval $[R_0,R]$ may retain the exact kernel in (A4), while the remaining tail is paid by (A5). No terminal term is omitted. Taking $R\to\infty$ removes that tail under the stated moment condition; taking $R_0\downarrow0$ is not justified by this bound and is not performed.

## A3. Deep positive sources: geometric zero scales replace deep gradients

Let $\Omega$ be bounded and open with $0<|\Omega|<\infty$, let $\kappa>0$, and let $f\ge0$ be in $L^1$, with mass $W$. Assume for a specified $r>0$ that
\[
 f=0\quad\hbox{almost everywhere on }
 \{y:\operatorname{dist}_\infty(y,\Omega^c)<r\}.
 \tag{A6}
\]
Since the distance is zero on $\Omega^c$, this includes support inside the same cap. Let $s\ge0$ be an integrable reference satisfying $s\le\kappa$ almost everywhere and $\int s=W$. Then with $b=(f-s)dx$,
\[
 \mathcal E_{\Omega,\kappa}(f)
 \le D_{\Omega,2r}(b)
 \le\frac{4W^2}{n(2r)^n}.
 \tag{A7}
\]
If the reference has finite first moment, (A5) also applies. A reference supported in bounded $\Omega$ has that property. If $s=\kappa1_\Omega$ and $W=\kappa|\Omega|$, the cap fee is exactly $|\Omega|=W/\kappa$, and the explicit normalized energy coefficient in (A7) is $4|\Omega|/[n(2r)^n]$.

Proof. For $x\in\Omega^c$ and $L<2r$, no positive-mass portion of $f$ lies in $x+Q_L$: any captured $y$ has $\operatorname{dist}_\infty(y,\Omega^c)\le\|y-x\|_\infty\le L/2<r$. Thus $A_Lf(x)=0$ on the entire small-scale interval. For $L\ge2r$, the actual bounded reference gives $A_Ls\le\kappa$, so $(A_Lf-\kappa)_+\le|A_L(f-s)|$. Integrate only over those larger scales and apply (A3), using $\|f-s\|_1\le2W$. This proves (A7). In particular, small-scale averages of the negative reference are not mistakenly charged as actual positive excess.

This estimate is uniform under arbitrarily deep concentration at fixed $r$, $W$, and cap. It therefore survives the deep-source pressure that destroys the full weighted-gradient certificate in the previous round. It does not make the geometric factor subpower. For example, even for a cube of half-side $a$ its displayed factor is $4(a/r)^n/n$; approaching the boundary destroys uniform control. This is the actual coefficient of the proved estimate, not a lower bound for the cube maximal constant.

## A4. Same-cap shallow/deep split with every remainder retained

Now let $f\ge0$ be any $L^1$ source, without (A6). Fix the same bounded open cap, $\kappa>0$, and $r>0$. Put
\[
 \begin{split}
 d(y)&=\operatorname{dist}_\infty(y,\Omega^c),\\
 f_D&=f1_{\{d\ge r\}},\qquad f_S=f-f_D,\qquad m=\int f_D,\\
 \gamma&=\frac{m}{\kappa|\Omega|},\qquad
 s_D=\gamma\kappa1_\Omega,\qquad b_D=(f_D-s_D)dx.
 \end{split}
 \tag{A8}
\]
Assume $0<m<\kappa|\Omega|$, so $0<\gamma<1$. This restriction is a hypothesis, not automatic for an arbitrary prescribed cap. Then, for every $\eta>0$,
\[
 \mathcal E_{\Omega,\kappa}(f)
 \le(1+\eta)D_{\Omega,2r}(b_D)
 +(1+\eta^{-1})\mathcal E_{\Omega,(1-\gamma)\kappa}(f_S),
 \tag{A9}
\]
with
\[
 D_{\Omega,2r}(b_D)
 \le\min\left\{\frac{4m^2}{n(2r)^n},
 \frac{2\|b_D\|_1M_1(b_D;z_0)}{(n+1)(2r)^{n+1}}\right\}.
 \tag{A10}
\]
One may use the exact kernel instead of either bound. All statements allow the shallow energy to be infinite. If $m=0$, the exact identity $f=f_S$ almost everywhere handles the case directly; no division by $m$ is used. If $|\Omega|=0$ or $m\ge\kappa|\Omega|$, (A8)--(A10) do not supply this decomposition with a positive residual threshold.

Proof. The two source pieces are measurable and nonnegative. The deep piece has mass $m$, and the reference has exactly that same mass. Thus $b_D$ has zero total mass, total variation at most $2m$, and finite first moment because both pieces are supported in bounded $\Omega$. Formula (A10) follows from (A3) and (A5).

For $x\in\Omega^c$, $L<2r$ gives $A_Lf_D=0$ as in A3. Therefore $(A_Lf-\kappa)_+^2\le(A_Lf_S-(1-\gamma)\kappa)_+^2$ on that entire interval. For $L\ge2r$, the exact decomposition is
\[
 A_Lf-\kappa=A_Lb_D+
 [A_Lf_S-(1-\gamma)\kappa]+[A_Ls_D-\gamma\kappa].
\]
The final bracket is nonpositive because $s_D\le\gamma\kappa$. Hence the positive part is at most $|A_Lb_D|+(A_Lf_S-(1-\gamma)\kappa)_+$. The elementary inequality $(u+v)^2\le(1+\eta)u^2+(1+\eta^{-1})v^2$ yields (A9) on the larger scales. Adding the small-scale bound is legitimate because the coefficient $1+\eta^{-1}$ is at least one. This proves the all-scale statement on the one original cap.

This accounts for the signed reference, its mass, the threshold loss, the entire shallow source, and both scale endpoints. Applying a separate theorem to $f_S$ at its smaller threshold would require that theorem's cap and volume hypotheses on this same $\Omega$; the original cap budget cannot simply be borrowed. Iteration is not claimed. A bounded source-density, a small shallow mass, or a source-depth distribution alone does not establish the remaining exterior energy estimate.

## A5. Obstruction and precise remaining requirement

The previous deep-concentration fixture is compatible with (A7): its positive source remains separated from the exterior, so exact exterior averaging stays bounded at each fixed dimension while the relaxed deep gradient may diverge. The new shallow pressure has the opposite effect. For a fixed prescribed cap, moving a positive source closer to its boundary can make actual exterior excess energy unbounded at fixed source mass. The private appendix proves this using full-dimensional receiver boxes and continuous scale intervals. It is an obstruction to discarding the shallow term in (A9), not a claim that a suitably changed or enlarged common cap must fail.

For the general target, a cap family would still have to satisfy $|\Omega_\kappa|\le A_n W/\kappa$ for every threshold of the same physical input, with both terms in (A9) bounded in total by $B_n\kappa W$. The common-cap reconstruction retained in the R96 ledger has the precise form, for $q=\lambda/\kappa\ge4$,
\[
 \frac{\lambda|\{M_{\rm cube}f>\lambda\}|}{W}
 \le A_n q+\frac{16nB_n}{q\log2}.
 \tag{A11}
\]
For $A_n>0$, taking $q=\max\{4,4\sqrt{nB_n/(A_n\log2)}\}$ gives
\[
 C_n\le4A_n+8\sqrt{nA_nB_n/\log2}.
 \tag{A12}
\]
This is the previously retained energy-to-weak transfer, not a new theorem proved here. No subpower $A_n,B_n$ family is constructed by (A7) or (A9). The gain is that the deep piece can now be paid without a full weighted-gradient estimate; the unresolved part is a spatially valid shallow budget, including the reduced threshold and any cap enlargement needed to obtain it. The general root-order bound and original gate qualification remain unproved.

The companion source role investigates a supported divergence extension and its paid smoothing error. Such an extension is not assumed in the proofs above. The companion public numerical role evaluates diffuse-source exterior signed kernels and actual full-space geometry; its independent runs are not counted as this author's experiments.

## A6. Execution and evidence levels

Before proof, the exact signed kernel, finite-depth implication, shallow/deep inequality, and fixed-cap pressure were sent to both auditors. Both independent blind screens passed with the explicit hypotheses retained above. Full mathematical and execution reviews are recorded separately.

The author actually executed three bounded stages, using only Python standard-library integer and rational arithmetic. Kernel geometry and physical source tests were deliberately kept distinct.

|Stage|Distinct actual positive sources|Atom-kernel matrices|Point receiver--scale checks|Seconds|
|---|---:|---:|---:|---:|
|Pilot|3|2|80|0.006679000|
|Pressure|3|2|80|0.010680334|
|Expanded|4|3|120|0.032739209|

All stages passed. Seven genuine deep/shallow mixture sources use dimensions $2,3,4,5,8,12,16$; five exterior receivers and eight rational scales per source give 280 actual hard-average checks. Forty-one have positive actual excess. They verify the exact signed decomposition, threshold loss, small-scale deep zero, and Young bound. These are pointwise checks and do not compute receiver-space energy. Three further physical sources test the fixed-cap shallow obstruction; each includes an exact positive-volume receiver box and an entire continuous scale interval. Those are local lower witnesses, not full-space energy integrations or new original-gate examples.

Separately, seven $3\times3$ exact atom-kernel matrices use the same dimensions and rational cutoffs. Their piecewise polynomial receiver-intersection volumes are integrated over every scale from the stated cutoff to infinity, including the exact polynomial tail. They check symmetry, nonnegativity, pairwise principal minors, selected signed quadratic forms, and both explicit bounds. There are 223 ordered-pair scale pieces; these dependent pieces are not separate experiments. Atoms are kernel geometry tests and are not represented as positive $L^1$ physical inputs. The full general positive-semidefinite statement comes from the proof (A3), not finite matrix tests.

Complete standard-library code, exact parameter domains, receipts, and stable certificate digests are retained in the private appendix. Timings are display-only. An exploratory run before adding the shallow-pressure witnesses and later replays are not counted as extra sources or experiments. No floating quadrature, dimension-exponent fitting, Git operation, or PDF compilation was used. The current J04 bookkeeping boundary and F05 kernel/measure boundary were read; neither supplies a stochastic Fubini theorem or an automatic Schur constant here. All integral identities used above have direct deterministic proofs, and no new primary-paper reading is claimed by this role.

## S0. Exact contribution and remaining budget

A supported right inverse of divergence is a real primary theorem, but its Sobolev input and geometric constants are not supplied by the mass of an arbitrary physical source. The new independently proved interface here instead controls the actual error of regularizing finite charges on ONE cap and a positive scale cutoff. It avoids charging a deep Dirichlet norm. It neither asserts exact agreement of changed inputs nor supplies the remaining near-scale capacity. Alternative owns the exterior signed Gram and shallow/deep decomposition; those proofs are not duplicated here.

Full-side notation is \(k_L=L^{-n}1_{[-L/2,L/2]^n}\), \(A_Lb=k_L*b\). For a Borel cap \(\Omega\), \(R>0\), write
\[
T_{\Omega,R}b(x,L)=1_{\Omega^c}(x)1_{[R,\infty)}(L)A_Lb(x),
\quad \|T_{\Omega,R}b\|_{\mathcal H}^2
=\int_{\Omega^c}\int_R^\infty|A_Lb|^2\,\frac{dL}{L}\,dx.
\]
The receiver measure is actual Lebesgue measure and the scale measure is \(dL/L\). No smoothness of the cap is required for the estimates below.

## S1. One primary theorem with its actual input contract

New primary: [Costabel–McIntosh, On Bogovskii and regularized Poincaré integral operators for de Rham complexes on Lipschitz domains](https://costabel.perso.math.cnrs.fr/publis/PoiBogdeRhv2.pdf), author version December 29, 2008 (Math. Z. 265 (2010), 297–320). Complete Sections 2–3 and 4.1, printed pp. 3–12, were read. Proposition 4.1(ii) and Corollary 3.4 give (1); Theorem 3.2 proves order-minus-one symbols. External pseudodifferential mapping textbooks and later cohomology proofs were not reread.

Let \(D\) be bounded, starlike with respect to a ball \(B\), and \(\theta\in C_c^\infty(B)\), \(\int\theta=1\). For top-degree \(h\in H_D^s(\mathbb R^n)\), \(s\in\mathbb R\), with zero charge,
\[
\operatorname{div}\mathcal B_D h=h,
\quad\operatorname{supp}\mathcal B_Dh\subset\overline D,
\quad\|\mathcal B_Dh\|_{H^{s+1}(\mathbb R^n)}
\le C_{n,s,D,\theta}\|h\|_{H^s(\mathbb R^n)}.
\tag{1}
\]
The spaces are GLOBAL supported Sobolev spaces, not silently substituted intrinsic negative-order spaces. Thus \(s=-1\) gives an \(L^2\) vector field; \(s=0\) gives \(H^1\). The constant is independent of \(h\), but its value and dimension-uniform bound are not supplied. The proof involves \(2^{\ell-1}\), bump Fourier seminorms and localization constants. Source (3.13) retains \(h-(\int h)\theta\) without zero charge; support follows from the star hull. These qualifications do not certify a general physical cap.

For the actual \(b=f_D-s_D\), equal mass supplies the zero-mean condition only. A common physical cap need not be starlike, and its reference charge may touch its boundary even if \(f_D\) is deep. Finite total variation supplies neither a global \(H^{-1}\) norm nor its mass-controlled bound. Necessity is immediate: if \(\operatorname{div}v=b\) with \(v\in L^2\), then \(|\langle b,\psi\rangle|\le\|v\|_2\|\nabla\psi\|_2\) for compact smooth tests. The retained private R96 physical concentration pressure already shows why a full-gradient norm can overcharge; it is not counted as a new R97 experiment. Thus (1) can construct a qualified corrector, but it does not settle this project's general near-energy budget.

## S2. Exact same-cap regularization error

Let \(n\ge1\), \(b\) be ANY finite signed Borel measure, \(V=\|b\|_{\rm TV}\), \(R>0\), \(\varepsilon\ge0\), and \(\rho\) a probability measure supported in \(\{z:\|z\|_\infty\le\varepsilon\}\). It need not have a density or be symmetric. Then
\[
\|T_{\Omega,R}(b-b*\rho)\|_{\mathcal H}^2
\le\frac{2n}{n+1}\,\varepsilon R^{-n-1}V^2.
\tag{2}
\]
No mean-zero, potential, \(H^{-1}\), domain regularity or new cap is needed for (2). The cases \(V=0\) and \(\varepsilon=0\) give zero error. The positive cutoff \(R\) is indispensable.

Proof. The exact overlap of two translated cubes gives
\[
\|k_L-k_L(\cdot-z)\|_2^2
=2L^{-n}\left[1-\prod_{j=1}^n(1-|z_j|/L)_+\right]
\le2n\varepsilon L^{-n-1}.
\tag{3}
\]
For coordinates smaller than \(L\), use \(1-\prod(1-a_j)\le\sum a_j\). If any coordinate is at least \(L\), the bracket is at most one and \(\sum|z_j|/L\ge1\); the same upper bound holds. Thus there is no hidden assumption \(\varepsilon<L\). Also the bracket is always at most one, a useful retained alternative to the linear upper bound.

Jensen for the probability law gives \(\|k_L-k_L*\rho\|_2^2\le\int\|k_L-k_L(\cdot-z)\|_2^2\rho(dz)\). Convolution Minkowski for the finite signed measure then gives
\[
\|A_L(b-b*\rho)\|_2^2
\le V^2\|k_L-k_L*\rho\|_2^2
\le2n\varepsilon V^2 L^{-n-1}.
\tag{4}
\]
These are genuine \(L^2\) functions: \(\|A_Lb\|_2\le VL^{-n/2}\), and in particular \(\|T_{\Omega,R}b\|_{\mathcal H}^2\le V^2/(nR^n)\). Translations of the cube kernel are continuous in \(L^2\), so the Bochner integrals exist; finite total variation gives absolute norm integrability. Joint measurability in scale and receiver, followed by Tonelli, permits integration of (4). Restricting to the SAME \(\Omega^c\) only decreases the norm. Finally \(\int_R^\infty L^{-n-2}dL=R^{-n-1}/(n+1)\), proving (2).

This proof is our direct rough-cube calculation, not a stated consequence of (1), and not a vector Poisson or random-Fubini theorem.

## S3. Scale-dependent approximants and actual positive excess

Let \(\rho_L\) be jointly measurable probability kernels with \(\|z\|_\infty\le\varepsilon(L)\) on their support. The same calculation gives
\[
\int_{\Omega^c}\int_R^\infty|A_Lb-A_L(b*\rho_L)|^2\,\frac{dL}{L}\,dx
\le2nV^2\int_R^\infty\varepsilon(L)L^{-n-2}\,dL.
\tag{5}
\]
In particular, if \(\varepsilon(L)\le\delta L/n\),
\[
\text{error}\le\frac{2\delta V^2}{nR^n}.
\tag{6}
\]
Parameter-dependent approximants are explicitly fields, not a single new physical input or a common generator. Every application of (1) to them still needs its own support, zero charge, Sobolev bound and uniform geometric constants.

If \(\nu=f\,dx\ge0\), \(m\ge0\), both have mass \(W\), \(m\le\kappa\,dx\), and \(b=\nu-m\), then \(V\le2W\). The actual, unchanged positive excess satisfies
\[
(A_L\nu-\kappa)_+\le|A_Lb|.
\]
For a fixed probability law, \(\nu*\rho\ge0\), \(m*\rho\le\kappa dx\), their masses remain \(W\), and subtraction commutes with convolution. Nevertheless their actual cubes, cap-contact structure and original gates need not agree. The legitimate inequality is the paid norm comparison
\[
\left(\int_{\Omega^c}\int_R^\infty(A_L\nu-\kappa)_+^2\,\frac{dL}{L}\,dx\right)^{1/2}
\le\|T_{\Omega,R}(b*\rho)\|_{\mathcal H}
+\sqrt{\frac{2n}{n+1}\varepsilon R^{-n-1}}\,V.
\tag{7}
\]
For example, an error allowance \(\eta\kappa W\) is certified by \(\varepsilon\le\eta(n+1)\kappa WR^{n+1}/(2nV^2)\) when \(V>0\). Squaring (7) requires its cross term; it cannot simply add two squared energies with coefficient one.

For fixed \(R\), (2) proves strong convergence of the restricted operators as \(\varepsilon\downarrow0\). The positive part is 1-Lipschitz, so the same statement holds for truncated excess energy of a positive input. This is a legitimate extension limit on one cap. It gives no estimate uniform as \(R\downarrow0\); a different approximating cap at each scale or regularization is not justified by this statement. The raw small-scale divergence obstruction remains. Applying (1) after regularization may be legitimate if \(b*\rho\in H_D^{-1}\) and its support lies in a genuine qualified domain, but its norm may increase without bound when smoothing is removed. Smooth compact kernels make finite charges regular, not inexpensive.

## S4. Actual continuum-receiver checks in three stages

New neutral inputs: let \(U_a\) denote the unit-mass uniform density on the cube of full side \(a\). Use \(\nu=U_a\), \(m=U_{2a}(\cdot-4ae_1)\), \(W=1\), \(\kappa=(2a)^{-n}\), and the SAME cap \(\Omega=[-a/2,a/2]^n\), whose volume is \(a^n\). Thus \(m\le\kappa\), both are genuine positive compact \(L^1\cap L^2\) sources with equal mass, and disjoint support gives \(V=2\). Take \(\rho=(\delta_{\varepsilon e_1}+\delta_{-\varepsilon e_1})/2\). This probability kernel verifies the full generality of (2), but is not a smooth-kernel experiment or numerical implementation of the primary inverse.

At each reported fixed scale, compute the ACTUAL exterior \(L^2(dx)\) error in (4), with every receiver included. Cube averaging of a uniform box separates into one-dimensional piecewise linear factors
\[
p_{a,L,c}(x)=\frac{[\min(x+L/2,c+a/2)-\max(x-L/2,c-a/2)]_+}{aL}.
\]
The error is a sum of six product functions. For any linear pieces \(p,q\) on \([l,r]\),
\[
\int_l^r pq=\frac{r-l}{6}(2p(l)q(l)+p(l)q(r)+p(r)q(l)+2p(r)q(r)).
\tag{8}
\]
Use all support/kink endpoints; add the cap endpoints when integrating inside it. Expanding the signed six-by-six quadratic form and subtracting the exact inside-cap integral gives the entire exterior error, not sampled receivers. Equation (8) is an elementary polynomial integral, not an atom model substituted for physical input.

| Stage | Dimensions | a | epsilon/a | Scales L/a |
|---|---|---|---|---|
| Pilot | 2,3 | 1 | 1/8 | 1/2,1,3 |
| Boundary/parameter stress | 5,8 | 1/4 | 1/8 | 1/2,1,3 |
| Expanded | 12,20 | 1/2 | 1/32 | 1/2,1,3 |

Six distinct physical positive pairs and eighteen fixed-scale norms were checked with Fraction arithmetic: exterior error was positive and at most the whole-space error, which was at most \(8n\varepsilon L^{-n-1}\). There were 84 exact assertions in 0.234923 seconds. One initial command had a syntax error before executing any assertion; the corrected complete primitive below was the successful run. Decimals are displays only. The largest whole-space/bound ratio was approximately 0.000718859; no fitted dimension law follows from these fixtures. No scale quadrature, random receiver sampling, original gates or direct all-scale target energy was computed. Continuum-scale integration in (2) is proved analytically.

Complete reproduction, writing no extra file:

```python
from fractions import Fraction as F

def p(x,a,L,c=F(0)):
 return max(F(0),min(x+L/2,c+a/2)-max(x-L/2,c-a/2))/(a*L)

def cross(a,c,b,d,L,H=None):
 knots=sorted(set([c+sgn*(a+L)/2 for sgn in [-1,1]]
  +[c+sgn*abs(a-L)/2 for sgn in [-1,1]]
  +[d+sgn*(b+L)/2 for sgn in [-1,1]]
  +[d+sgn*abs(b-L)/2 for sgn in [-1,1]]
  +([] if H is None else [-H/2,H/2])))
 out=F(0)
 for l,r in zip(knots,knots[1:]):
  if H is not None and not (-H/2 <= (l+r)/2 <= H/2): continue
  pl,pr=p(l,a,L,c),p(r,a,L,c)
  ql,qr=p(l,b,L,d),p(r,b,L,d)
  out+=(r-l)*(2*pl*ql+pl*qr+pr*ql+2*pr*qr)/6
 return out
count=0
for ns,a,rel in [([2,3],F(1),F(1,8)),
                  ([5,8],F(1,4),F(1,8)),
                  ([12,20],F(1,2),F(1,32))]:
 for n in ns:
  eps=a*rel; sep=4*a; cap=a
  terms=[(a,F(0),F(1)),(2*a,sep,F(-1)),
   (a,eps,F(-1,2)),(a,-eps,F(-1,2)),
   (2*a,sep+eps,F(1,2)),(2*a,sep-eps,F(1,2))]
  assert sum(t[2] for t in terms)==0; count+=1
  kappa=(2*a)**(-n)
  assert kappa*(2*a)**n==1; count+=1
  for L in [a/2,a,3*a]:
   total=F(0); inside=F(0)
   for ai,ci,wi in terms:
    for aj,cj,wj in terms:
     total+=wi*wj*cross(ai,ci,aj,cj,L)*cross(ai,F(0),aj,F(0),L)**(n-1)
     inside+=wi*wj*cross(ai,ci,aj,cj,L,cap)*cross(ai,F(0),aj,F(0),L,cap)**(n-1)
   exterior=total-inside; bound=8*n*eps/L**(n+1)
   assert 0<=exterior<=total<=bound; count+=3
   assert exterior>0; count+=1
assert count==84
print(count)
```

## S5. Skills, common-cap scope and unpaid endpoint

This round the current F05, J03, J04 and G01 entries were read; J04 method and cube interface, and J03 cube interface were read. F05's two-sided Schur certificate remains distinct from a supported right inverse; no row/column theorem produces its Sobolev norm. J03 requires actual exit law, full exterior data and killing mass; it does not assert deterministic Newtonian redistribution or a cap energy bound. J04 requires the actual predictable law and integrability for random compensation; the finite-TV Bochner proof in S2 uses no unverified random Fubini. G01 requires actual all-node packing or qualified harmonic domain geometry; arbitrary physical caps and forced obstacle potentials do not supply these.

The authorized evidence root is `/Users/zhengzhihao/Desktop/T/数学工具64项_最终交付验收_20261011/f-zip/fresh-extraction/zip-root/数学工具64项_完整验收提升_20261007`, read only. The old registry root remains missing, and the registry was not modified. The new primary was read from the author's PDF, not inferred from a hash or skill title. Only the indicated primary sections were read; no 23-page full-paper or external textbook audit is claimed. R96 primary/obstacle results were not reread as new R97 evidence.

The retained endpoint transfer must have an actual common cap for EVERY \(\kappa\) for the SAME physical \(f\), with \(|\Omega|\le A_n W/\kappa\) and actual all-scale excess energy at most \(B_n\kappa W\). The zero input is trivial. For \(W>0\), its exact formula, with \(q=\lambda/\kappa\ge4\), is
\[
\lambda|\{M_{\rm cube}f>\lambda\}|/W
\le A_n q+\frac{16nB_n}{q\log2}.
\tag{9}
\]
The regularization error carries \(V^2\varepsilon R^{-n-1}\), rather than an automatic \(\kappa W\) budget; the extension carries \(C_{n,s,D,\theta}\|h\|_{H^s}\). Neither pays the actual near-scale remainder or verifies \(A_n,B_n\) uniformly. There is no infinite minimax argument, source-dependent cap replacement, or assertion of original gate inheritance. Source splitting must preserve signed compensation, and all cross terms must be charged. General root-order closure remains unproved.

Both auditors received exact statements (2) and (6) before proof, passed blind checks, and completed full MD/TeX own-proof and scope reviews. Their receipts do not claim a full independent primary-paper reread. Astra separately extracted and replayed the 84-assertion primitive successfully; that replay is not a new experiment or all-scale numerical energy. Source theorem reading, our transfers, author execution and reviewer replay remain separate evidence claims.

## P0. What this route establishes

A doubly nonlinear diffusion has explicit compact profiles that give a positive linear convolution family uniformly comparable with centered cube averages. The comparison holds for every nonnegative L1 input. It does not identify the convolution with nonlinear evolution. The reverse comparison shows that a weak endpoint bound for this kernel family retains the original problem's difficulty. Ordinary orthotropic fast p-diffusion and the crystalline total-variation endpoint do not provide the desired inexpensive pointwise bridge; the actual-input pressure derivations remain local.

The updated A02 method was reread: a new family or a feasible mapping supplies no bound without the correct direction of objective domination. That distinction is essential here. E03 and J04 were reread as well; no tree telescope or random exit identity is invoked for this deterministic nonlinear flow.

## P1. An explicit compact profile, with a checked boundary

Fix n>=2 and a real q>1, and put
\[
 p=\frac q{q-1},\quad m=q,\quad \beta=\frac{q-1}{n+q},\quad c=\frac{\beta^{q-1}}{q^2},\quad S(y)=\sum_j|y_j|^q.
\]
Consider the equation
\[
 \partial_t U=\sum_j\partial_j\bigl(|\partial_j(U^m)|^{p-2}\partial_j(U^m)\bigr).
\tag{P1}
\]
For any C>0 let F(y)=(C-cS(y))_+ and U(x,t)=t^{-n\beta}F(t^{-\beta}x), t>0. On {F>0},
\[
 \partial_j(F^q)=-q^2c\,|y_j|^{q-2}y_j F^{q-1},\qquad
 |\partial_j(F^q)|^{p-2}\partial_j(F^q)=-\beta y_jF. \tag{P2}
\]
The identity extends by zero to the exterior. Indeed F is locally Lipschitz with compact support, F^q is continuously differentiable across F=0 for q>1, and the resulting flux -beta yF is a continuous, locally Lipschitz compact vector field. Its distributional divergence has no surface measure. The coordinate hyperplanes cause no omitted flux because |y|^{q-2}y is continuous for q>1, and the final flux in (P2) is Lipschitz. The time derivative across the moving boundary likewise has no surface term because U vanishes continuously there. The time exponents match since
\[
 n\beta[m(p-1)-1]+p\beta=1.
\]
Consequently U is an actual nonnegative weak solution of (P1), with finite conserved mass. This is a directly verified solution, not a claim of a general Cauchy theory or superposition principle.

Let V_(n,q) be the volume of {S<1}. Layer-cake gives
\[
 \int (1-S)_+\,dy=V_{n,q}\int_0^1(1-v)^{n/q}dv
 =\frac{q}{n+q}V_{n,q}.
\]
Thus C can be uniquely chosen so that
\[
 C^{1+n/q}c^{-n/q}\frac{qV_{n,q}}{n+q}=1. \tag{P3}
\]
No uncomputed normalization is assumed. The resulting time slices are precisely the positive probability kernels
\[
 G_s(x)=\frac{1+n/q}{V_{n,q}s^n}\left(1-\frac{\|x\|_q^q}{s^q}\right)_+,\qquad s>0, \tag{P4}
\]
with s=(C/c)^{1/q}t^beta.

## P2. General positive convolution comparisons and their exact price

Use half-side R>0 and K_R=(2R)^{-n}1_{[-R,R]^n}. At s=R(n+q)^{1/q}, every point in this cube has ||x||_q^q<=nR^q, and (P4) yields
\[
 G_s(x)\ge\frac1{V_{n,q}R^n(n+q)^{n/q}}.
\]
Therefore the pointwise positive kernel inequality is
\[
 K_R\le D_{n,q}G_{R(n+q)^{1/q}},\qquad
 D_{n,q}=\frac{V_{n,q}}{2^n}(n+q)^{n/q}. \tag{P5}
\]
It follows by ordinary integration for every positive L1 input that
\[
 M_\square f\le D_{n,q}\sup_{s>0}(G_s*f). \tag{P6}
\]
Measurability follows by restricting the scale supremum to positive rationals: the kernels are L-infinity bounded on compact scale intervals and converge pointwise away from their null boundaries, so dominated convergence against L1 data gives scale continuity.

This forward estimate must be audited against a reverse one. Define U_r^q=(V_(n,q)r^n)^{-1}1_{||x||_q<r}. Direct integration gives
\[
 G_s=\int_0^1(n+q)t^{n+q-1}U_{st}^q\,dt,\qquad
 \int_0^1(n+q)t^{n+q-1}dt=1. \tag{P7}
\]
Since the lq ball of radius r lies in [-r,r]^n,
\[
 \sup_sG_s*f\le M_q f\le\frac{2^n}{V_{n,q}}M_\square f. \tag{P8}
\]
All these are positive convolution statements for the same input and actual receiver. All scales are retained, with no receiver deletion or source relabeling.

Choose q=n^2. The unit lq ball lies in the unit cube and contains the cube of half-side n^{-1/q}; hence
\[
 2^n n^{-1/n}\le V_{n,n^2}\le2^n.
\]
The elementary inequalities n<=2^n and n(n+1)<=3^n for n>=2 (both follow by induction) now show
\[
 M_\square f\le3\sup_sG_s*f\le6M_\square f. \tag{P9}
\]
In particular, this deformation removes the geometric mismatch of a Gaussian-shaped profile with a cube. It does not lower the order of the weak constant: (P6),(P8) explicitly show equivalence within absolute factors. The important unpaid bridges are a comparison with the nonlinear solution of (P1) for an arbitrary input, and a uniform weak maximal estimate for that actual solution. Neither follows from the single-profile computation, comparison principles alone, or L1 contraction at each fixed time. No addition of translated profiles is asserted to solve (P1).

## P3. Primary reading and limits

The primary paper [Feo, Vazquez and Volzone, Anisotropic p-Laplacian Evolution of Fast Diffusion type](https://arxiv.org/pdf/2105.03981) was read in its v1 PDF: Section 2 through the explicit orthotropic profiles, printed pp.5–8, and Section 13, printed pp.46–48. The former gives the fast-profile formula and its integrability range. The latter develops self-similar scaling for doubly nonlinear equations; its existence discussion leaves further work. No general doubly nonlinear existence, maximal inequality or dimension-uniform comparison is imported. Equations (P1)–(P9) above are checked directly, rather than attributed as the paper's maximal-function theorem. The earlier Spector–Stockdale heat paper was recognized as retained R91/R92 material and is not counted as a new reading.

## P4. Three-stage validation and remaining task

The local exact program ran pilot dimensions 2,3,4, known-route-pressure dimensions 8,16,32 and expanded dimensions 64,128,256. It passed 208 rational assertions in 0.000765250 seconds. There are 18 actual TV source/scale fixtures, 27 ordinary fast-profile parameter contracts and 9 compact-kernel algebra contracts. These are different units: the 27 and 9 are not extra PDE simulations or independent physical sources. Four small-dimensional compact flux identities were evaluated with exact rational powers; the general flux identity and full mass integral are proved analytically above. Large-dimensional gamma-volume logarithms are floating diagnostics only, not interval certificates. No full-source nonlinear solver, original-gate qualification, cube receiver-energy integration or new weak-norm lower bound was produced.

The pressure checks reject a cheap ordinary-p or TV bridge; they do not reject other nonlinear operators. The repaired cube-shaped kernel is a useful exact interface, but its reverse bound prevents treating it as an endpoint improvement. A productive continuation must control actual multi-source nonlinear evolution or another operator beyond this equivalent convolution family, with every dimension-dependent constant and mass transfer charged. The general root-order target remains OPEN.

本轮在实际正紧支撑 L1 来源上计算同一帽外的有符号平均平方能量。全部接收变量按原 Lebesgue 测度积分，全部尺度 L>0 保留。计算不使用接收点权重、有限尺度代理或梯度替代。来源、参考密度和帽规则在费用比较前固定；本轮没有原 Fnew 门控资格，也没有一般维数指数拟合。

固定 kappa=1、W=1/2，参考来源 s=(1/2) times indicator of [-1/2,1/2]^n。正来源 f 是该单位立方体内有限个均匀小盒的实际质量混合。共同帽为

```text
Omega = [-r,r]^n, r=(1+1/n)/2,
|Omega|=(1+1/n)^n, |Omega|*kappa/W=2*(1+1/n)^n.
```

f 和 s 都与帽外有严格正距离。设 b=f-s；计算量是

```text
E_signed(Omega) = integral_{x outside Omega} integral_0^infinity
                   |A_L b(x)|^2 dL/L dx.
```

它不是原正超额能量的等式。因为 A_L s<=1/2<=kappa，逐点有

```text
(A_L f-kappa)_+^2 <= |A_L(f-s)|^2.
```

因此计算量是同一帽外真实正超额能量的可审核上界。其严格下界是这个有符号量的下界，不能误当作正超额能量下界，更不能误当作任意帽最优值下界。八维例另有直接来自正来源的真实超额能量小盒下界。

## 三阶段实际执行及判别结果

1. 初探：二维中心均匀小盒，半边长 1/4、总质量 1/2。
2. 已知压力：两个二维中心深集中来源，半边长分别为 1/64、1/4096，各有质量 1/2；以及一个二维重叠、相关、两尺度来源。后者两块各有质量 1/4，中心分别是全坐标 -1/8 和全坐标 +1/8，半边长分别为 1/4 和 1/64。
3. 扩大参数：保持第二阶段重叠两尺度规则，分别在 n=3、4、8 执行。这是实际不同维数的来源；坐标相关由真实混合保留，没有把来源混合换成独立坐标边缘。

共 7 个实际正来源—维数组合，7 个共同帽证书，112 个有限物理尺度区间，以及 7 个完整无穷尺度尾。四项能量字段不是额外输入，审计重放不是新实验。所有 source center/halfwidth/mass 和帽体积都保存为精确有理数。

下表是严格 Fraction 证书的近似显示，显示小数本身不作为向外区间证书。最后一列是保留四项抵消之前的绝对项费用与实际有符号能量之比，精确比值区间见 JSON。

|阶段与来源|n|真实帽体积|E_signed 近似|去掉抵消的费用比|
|---|---:|---:|---:|---:|
|初探，中心半宽 1/4|2|9/4|0.00339654|25.8862|
|深集中，中心半宽 1/64|2|9/4|0.00927531|9.7914|
|深集中，中心半宽 1/4096|2|9/4|0.00977097|9.3441|
|重叠相关两尺度|2|9/4|0.00376501|23.6238|
|重叠相关两尺度|3|64/27|0.00566877|9.4745|
|重叠相关两尺度|4|625/256|0.00754819|5.3803|
|重叠相关两尺度|8|43046721/16777216|0.01739851|1.9728|

两项判别有用。首先，在相同二维帽上，中心半宽从 1/64 降到 1/4096 时，实际来源 L2 平方从 256 增至 1048576，外部有符号平均能量却只从约 0.00927531 变到约 0.00977097。这里只记录两次实际有限计算，不据此断言极限或一般集中不敏感定理。全来源 L2 量是单独的真实来源积分，不是帽外能量，不被当成已证明的通用能量上界。

其次，保留交叉项在全部七例中都给严格更小费用，差别约为 2 至 26 倍；但优势随着本有限维数菜单改变，不能以这些数值拟合维数阶。这里证明的是同一来源、同一帽、同一平均算子的真实抵消，并非只证明一个选择后的代数代理可抵消。

## 精确外部 Gram 积分

每个分量是一个实际概率盒密度乘其质量。对一维源区间 I_i=[a_i,b_i]，定义真正的归一化捕获函数

```text
q_i(x,L)=length(I_i intersection [x-L/2,x+L/2]) / length(I_i).
X_ij(L)=integral_R q_i(x,L)*q_j(x,L) dx.
C_ij(L)=integral_{-r}^r q_i(x,L)*q_j(x,L) dx.
```

它们分别是整个接收直线和帽内坐标区间的原始空间积分。对于 n 维两个概率盒分量，其共同帽外积分为

```text
G_ij(L)=product_{coordinate k} X_ij,k(L)
          - product_{coordinate k} C_ij,k(L).
```

这是整个位于帽外的接收域积分：先积分整个 R^n，再减去同一个真实帽，既不忽略远接收点，也不把固定接收截断域冒充全空间。分量内的乘积结构来自明确声明的均匀盒法；对不同分量仍保留完整双和，所以整体混合的相关性不被消去。

对正来源分量取系数 c_i=mass_i，对参考分量取 c_s=-1/2，则

```text
E_signed = sum_{i,j} c_i*c_j * integral_0^infinity
                             G_ij(L)*L^(-2n-1) dL.
```

程序逐尺度保存 ff、ss、2fs 及 ff+ss-2fs 的完整多项式。异分量同时出现两种顺序，交叉系数的 2 明确保留。ff/ss/fs 都是同一帽外有限积分，不是可能发散的全空间 RAW 平方积分。不能把它们与另一个帽的费用拼接。

这个恒等式中换积分合法。帽与所有来源支撑之间的共同距离 d>0，使 L<2d 时外部捕获完全为零；大尺度上，各正分量对的全空间核积分不超过 L^n，因此所有绝对项的尺度尾受常数乘 L^(-n-1) 支配。n>=2 时尤其可积。先对正分量应用 Tonelli，再对有限双和作线性组合，不需要对条件收敛的有符号积分换序。

## 物理尺度分段及接收积分

固定 L 时，q_i 在接收坐标 x 上连续、分段仿射；实际移动折面是

```text
x = a_i +/- L/2, x = b_i +/- L/2,
```

帽面是 x=+r 和 x=-r。程序将所有分量的这些仿射直线纳入同一安排。所有正尺度直线交点给完整尺度分段；它包括来源边缘间距，以及边缘与帽面的两倍间距。不存在靠数值采样找折点的步骤。

在一个开尺度区间内，这些仿射边界的次序固定；每个相邻接收条带内 q_i(x,L) 恰好是 a*x+b+c*L。一个条带的 q_i*q_j 是 x 的二次多项式；上下积分限又是 L 的仿射函数，所以实际条带积分是次数不超过 3 的 L 多项式。分别累加所有条带与帽内条带，得到 X_ij、C_ij 的精确多项式。区间中点仅用于识别已由全部交点隔开的固定分支；不是用中点值代替积分。

完整 n 个坐标多项式全部相乘。相同坐标的缓存是精确算术复用，没有丢失任何一个坐标宽度，也没有减少接收维数。帽体积一直是 (2r)^n，不按一条轴、一组轮廓或概率条件化来收费。

若所得分子多项式为 sum_d p_d*L^d，尺度积分每项恰为

```text
p_d * (h^(d-2n)-l^(d-2n))/(d-2n),  if d != 2n,
p_d * log(h/l),                      if d == 2n.
```

低尺度零段是精确多项式恒零，并按 f 与 s 两者的最小帽距离核对，不是只检查正来源。所有有限物理区间之间没有间隙。多项式正负系数保留到积分以后，不能在空间积分前取绝对值。

## 完整无穷尺度尾

当 L 超过两来源任意点的最大间距，

```text
X_ij(L)=E[(L-|Y_i-Y_j|)_+]=L-E|Y_i-Y_j|.
```

当 L>=2*(r+maximum source extent) 时，帽内每个接收点的立方体都捕获两个源区间的全部质量，因此 C_ij(L)=2r。程序的最后一个物理折点同时涵盖这两个条件，不提前把 C 写成常数。

最后区间一直延伸到正无穷。每个幂项按其真实指数解析积分，不用一个未证明的小尾截断。f 与 s 总质量相同，故完整有符号分子 L^n 项精确抵消；保存的尾多项式次数至多 n-1。程序用精确系数断言这件事，未以浮点近零替代。n=8 的无穷尺度尾仍约为 0.0000104286，明确加入总能量，没有作零处理。

## 有理及对数误差

除最后展示数字和计时外，程序只使用标准库 Fraction、任意精度整数和精确多项式。对数按 2 的整数幂把参数归一到 [1,2]，采用 atanh 的 100 个正项；参数不超过 1/3，余项上界为

```text
(2/201)*(1/3)^201/(1-1/9).
```

所有乘法与除法在 256 位二进格上分别向外取整。乘 log(2) 的整数系数及多项式中的负对数系数均按符号交换端点，保证完整带符号积分被包住。最后才向外舍入到 80 位。没有声称某个通用浮点区间库已验证；本程序的整数舍入协议与误差证明直接给出。JSON 的小数显示不是精确证书。

## 与真实超额能量的区别及正体积见证

全部四个二维输入还可独立证明：同一帽外真实正超额能量恰为零。若正来源支撑位于 maxnorm<=b_f，帽外捕获需要 L>=2(r-b_f)，而 A_L f<=W/L^n。当 W<=[2(r-b_f)]^n 时，这保证所有帽外平均不超过 kappa=1。四例都以精确有理比较通过这个判据。它们的有符号能量却严格为正，再次说明本代理是比原超额更强的费用，并非原超额本身。

八维重叠例则另有真实超额正性证书。取 eta=1/1024，接收盒为

```text
[-r-eta,-r-eta/2] times [-1/8-eta,-1/8+eta]^7,
L in [1/2, 1/2+eta].
```

这个完整八维盒严格在帽外，实际 dx 体积为 2^-74。仅利用正来源的较宽分量，区间左端捕获质量的统一下界除以右端 L^8，就得每个接收点、每个尺度的原平均严格大于 7.6。捕获质量随 L 不减，但平均并未被假定单调。积分真实正超额的平方并向下取整，给

```text
actual positive-excess energy outside the SAME cap >= 5/2^80 > 0.
```

相应全空间全尺度上界是实际有符号能量的严格上端点，约 0.01739851。极小的下界盒没有被归一成大体积接收集，也不暗示高负载或一般下界。n=3,4 没有执行这个真实超额零性/正性的判定，仍只提供有符号上界。

## 保留结论与未解费用

本轮得到新的可执行实际外域抵消证书：完整的四项平均积分、共同帽体积、低尺度零段和无穷尺度尾都能在有限复杂度下精确结算。深集中压力说明把外域平均替换为全来源 L2 费用会在这些特定输入上极度粗糙；完整交叉项也比两项绝对费用更准确。

但这个数值证书没有给任意正 L1 输入、任意维数的一般有符号能量界。帽规则针对单位支撑参考类；没有证明所有来源都能按同一体积费用进入该类，没有支付任意来源的参考构造，也没有估计所需的一般浅层/边界核。原 Fnew 联合门、任意共同帽最优值、一般 root-dimension 弱型目标均未闭合。不能把有限例中的严格抵消比值当作普适维数收益。

## 实际运行、复现及冻结

```text
python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round097_20261012/energy_probe.py
```

最终实际运行 0.378559208 秒，标准库自包含，结果 125408 字节；没有旧轮导入、文件外依赖、抽样或来源再优化。结果 JSON 不保存运行时间，可逐字节重放。尺度见证是 base85(zlib(compact JSON))，保存记录数、SHA256、全部多项式和每段积分区间。112 个有限尺度区间是物理公式片，不是 112 次独立输入或求积节点。

代码 SHA256：`9092f1a60b612e7fe3fd96e3eab8709a0ceb8a1ad32508ce8b9b99c90fd57176`。
结果 SHA256：`f88e4f72fad39b804cdd76dbdf9f3689d4215b7464580204fab03e5b4a43418d`。

The numerical argument now controls the original earliest contact through a continuous prefix bound. It certifies separate partial receiver relations, including selected-gate exclusion, but their required joint qualification remains unresolved. The remaining residual class and general weak-type bound stay open.

## R97 independent Astra audit — current disposition

The contract and precise claims were screened before author proofs. Five theoretical MD/TeX modules have now received full own-proof and consistency review: coverage, adaptive, alternative, sources and parent flow. Public energy report/code and the stated copied or extracted replays were also independently checked. Private phase full proof/code/report review and copied final replay also PASS; its two certified positive subsets remain distinct, and their stronger intersection is unresolved. No primary-paper reading by an author is attributed to this auditor.

The spatial source-cut program supplies one allocation for all receivers/scales, dominates the stated separation-tree program and has a legitimate countable extension with paid source tails. Its general residual mass remains unbounded. The captured-middle deletion is separately root-priced and repairs a real full-versus-captured moment gap; the subsequent likelihood normalization and shared source-column budget remain. Signed exterior Gram identities retain negative cross terms, common caps and the full infinite scale tail. Their deep-source estimate and shallow split keep the explicit depth and threshold losses. Regularization is paid above a positive scale cutoff, and supplies no uniform near-scale or Sobolev budget. The parent's positive convolution comparison is equivalent to the cube maximal problem; it is not a nonlinear superposition or weak bound.

The public numerical certificate integrates seven actual positive L1 input/dimension instances over the entire cap complement and all scales. Its 112 finite physical scale pieces and seven analytic infinite tails are not extra inputs. Four examples have zero actual positive excess despite positive signed energy; the separate higher-dimensional positive-volume witness concerns the prescribed cap only. The auditor's byte-identical replay verifies the producer computation and is not an independent energy reconstruction. Author fixtures, exact arithmetic units, physical source definitions, continuum coverage and repeated executions remain separate.

General root-order closure, a generally small allocation deficit, a root-priced score capacity and a uniform common-cap near-energy budget remain OPEN. All original classification fees, optional once-only full-window refinement, scale/threshold conversions and unfinished terminal demands remain charged. Private constructions and their quantified pressure conclusions are excluded from this public summary.

## Independent R97 audit

Independent statement-first screening and full Markdown/TeX mathematical reviews passed. The general arbitrary-positive-L1 root-order weak bound remains unproved. Spatial allcut allocation is sufficient with a residual source mass that is not uniformly paid. Captured-middle refinement pays its added deletion, while the score normalization remains explicit. The convolution kernel bridge preserves the original endpoint difficulty; signed exterior and regularization transfers retain their actual cap and signed residual hypotheses.

The original-root numerical work certifies two different partial receiver events. One retains P1 and brackets the original first contact; another certifies selected coarse HIGH with P1 unknown. Their required full conjunction remains UNKNOWN. Producer replays were isolated and compared exactly with only their stated timing exclusions; they do not count as independent reconstruction.

The new standalone exact guard independently reconstructs one actual asymmetric diffuse input/reference pair on one common cap: an exterior signed square at one scale and its continuous tail integral. It preserves negative cross terms. Actual positive-excess energy on that tail is zero, so the signed proxy is not identified with the target energy. It rebuilds none of the seven producer energy cases and reuses no previous-round gradient test. Its temporary-copy run passed in 0.017478000 seconds externally.

The public producer contains seven actual input/dimension instances, 112 finite continuum scale intervals and seven exact infinite tails. Actual excess, signed proxy and source L2 quantities are kept distinct. Author test counts, scalar checks, physical sources, auditor replays and independent guard reconstructions are separately recorded. No private construction or quantified unpublished lower recipe is included here.

## 主代理实际验证、文献归属与复现边界

下列为主代理真正执行的隔离重放时间，均 exit 0、stderr 为空。先复制或提取被冻结的最终程序至临时目录，再实际运行；不是只阅读作者结果，也不是新实验。energy 的全部 JSON 字节完全相同，没有排除字段。parent_flow 只排除顶层计时，phase 只排除明确列出的计时字段；其余数学、资格与描述字段全部一致。coverage 排除顶层与分阶段计时后逐字段一致；alternative 对照全阶段及稳定摘要 SHA；adaptive 和 sources 核验其实际完整断言输出。

|模块|隔离重放秒数|状态|
|---|---:|---|
|energy|0.351331416|PASS|
|phase|5.391393542|PASS|
|parent_flow|0.016145500|PASS|
|coverage|0.284482958|PASS|
|adaptive|2.008924375|PASS|
|sources|0.220918167|PASS|
|alternative|0.058025791|PASS|

这些单位不可相加：公开生产数值有 7 个实际正来源、112 个有限尺度公式片和 7 个完整无穷尾；coverage 有 21 个实际来源，其作者 42 次执行只是每例重跑一次；adaptive 有 6 个实际公式来源，扩大参数后同一来源的重复检验不增加输入数；alternative 有 7 个深浅混合来源和 3 个局部压力来源，另 7 个原子核矩阵不计正 L1 来源；sources 有 6 个实际正来源对、18 个整个帽外的固定尺度平方积分。parent_flow 有 18 个实际 TV 源/尺度单位、27 个参数合同和 9 个正核合同；后两类不计物理输入。私人 phase 始终使用同一个冻结物理输入，未重新优化来源，原门未决补集不删去。

独立 Sol 守卫用不同于生产程序的源对距离矩公式，重新构建一个新的非对称实际正来源及参考项，计算整个帽外的固定尺度平方积分和一段完整连续尺度尾。它不导入生产程序、不读取生产结果或私人配方。此独立重建与生产程序的三方逐字节重放分别计数；其严格积分、证明及结果见守卫节和 inventory.json。主代理另实际执行该守卫，耗时 0.014702666 秒。最终 zip 提取后的复现另存收据，不预先声称已经通过。

主代理直接读 Feo–Vázquez–Volzone v1 §2（印刷页5–8）和 §13（46–48）；来源作者读 Costabel–McIntosh §2、完整 §3 与 §4.1 命题4.1（3–12），Sol 另只核对命题4.1(ii)所在页的陈述和短证。其余审计或主代理没有据转述声称独立通读后者。原文用于明确适用条件；本轮派生的不等式另有直接证明。旧轮阅读不重复计入。

更新后的64个安装入口取当前字节哈希快照；这只证明读取了文件版本清单，不等于重新审核全部64个定理或原文。实际采用的 A02、A04、D02、E03、F05、G01/G03、H05、J03/J04 等按各模块所列范围阅读。证据包以明确的只读新根访问，缺失的旧注册根未被擅改，也未重新安装全局技能。未将技能摘要本身当作定理证据。

公开五成员包的复现：解压后运行 `python3 energy_probe.py`，逐字节对比原 `energy_results.json`；运行 `proof.md` 中准确标题“独立公开审核程序”下唯一 Python 块。来源模块另外包含其自行归属的84断言程序，不要混作独立守卫。私人程序、依赖树和配方只留本地。全部 LaTeX 仅做环境、括号、标签引用和控制字符的静态检查；没有编译、生成或查看 PDF。有限数值不推断一般阶数。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""R97 independent physical signed-tail reconstruction; stdlib only.
One asymmetric diffuse input, one reference and one common cap. No producer
imports, stored-results reads, private recipes or general weak-type claim.
"""
from fractions import Fraction as F
import json


def uniform_self_distance(halfwidth):
    # Integral of |Y-Z| for two iid Uniform[-a,a] variables.
    return 2 * halfwidth / 3


def uniform_reference_distance(center, halfwidth):
    # Reference is Uniform[-1,1]; source interval lies strictly inside it.
    assert abs(center) + halfwidth < 1
    # Integral over reference: E_Z |y-Z|=(1+y^2)/2 for |y|<=1.
    return (1 + center**2 + halfwidth**2 / 3) / 2


def reconstruct():
    n = 2
    mass, kappa = F(1), F(1, 4)
    # f is uniform probability on this asymmetric rectangle; s=1/4 on cap.
    centers, halfwidths = (F(1, 4), F(0)), (F(1, 8), F(1, 4))
    cap_halfwidth, cap_volume = F(1), F(4)
    assert mass == kappa * cap_volume
    source_volume = 4 * halfwidths[0] * halfwidths[1]
    assert source_volume == F(1, 8)
    assert all(abs(c) + a < cap_halfwidth for c, a in zip(centers, halfwidths))
    r = F(4)
    # At L>=4 every x inside cap captures the whole source and reference.
    # Thus A_L(f-s)=0 inside cap and exterior signed L2 equals full-space L2.
    assert r/2 >= 2 * cap_halfwidth
    assert all(r/2 >= cap_halfwidth + abs(c) + a
               for c, a in zip(centers, halfwidths))
    ff = tuple(uniform_self_distance(a) for a in halfwidths)
    ss = (F(2, 3), F(2, 3))
    fs = tuple(uniform_reference_distance(c, a)
               for c, a in zip(centers, halfwidths))
    # Tonelli: spatial overlap of full-side cubes is product (L-|y-z|)_+.
    # Here all coordinate gaps <=2, so L>=4 removes every positive-part kink.
    # Signed coefficients 1+1-2 cancel the leading L^2 exactly.
    p1 = -sum(ff) - sum(ss) + 2 * sum(fs)
    p0 = ff[0]*ff[1] + ss[0]*ss[1] - 2*fs[0]*fs[1]
    fixed_scale = (p1*r + p0) / r**(2*n)
    # Integrate the actual exterior signed square in dL/L on [4,infinity).
    tail = p1/((2*n-1)*r**(2*n-1)) + p0/(2*n*r**(2*n))
    ff_tail = F(1,2)/r**2 - sum(ff)/(3*r**3) + ff[0]*ff[1]/(4*r**4)
    ss_tail = F(1,2)/r**2 - sum(ss)/(3*r**3) + ss[0]*ss[1]/(4*r**4)
    fs_tail = F(1,2)/r**2 - sum(fs)/(3*r**3) + fs[0]*fs[1]/(4*r**4)
    assert tail == ff_tail + ss_tail - 2*fs_tail
    assert 0 < tail < ff_tail + ss_tail
    assert fixed_scale == F(35651,4718592)
    assert tail == F(48067,18874368)
    # Actual excess on these scales is zero by total mass, despite proxy>0.
    assert mass/r**n < kappa
    return dict(scope='ONE actual diffuse input/reference/common-cap pair; exact exterior signed square at L=4 and continuous tail L>=4',
                physical_inputs=1, fixed_scale_exterior_integrals=1,
                continuous_exterior_signed_tail_integrals=1,
                producer_energy_reconstructions=0, saved_arithmetic_checks=0,
                source_mass=str(mass), cap_volume=str(cap_volume),
                signed_polynomial=[str(p0),str(p1)],
                fixed_scale_signed_square=str(fixed_scale),
                allscale_from_four_signed_square=str(tail),
                actual_positive_excess_on_tail='0',
                general_root_bound='UNPROVED')


if __name__ == '__main__':
    print(json.dumps(reconstruct(), sort_keys=True))
```
