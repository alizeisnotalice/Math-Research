"""R97 actual diffuse signed exterior averaging; neutral public sources only.
Fractions; full receiver integration; continuous scale intervals plus infinity.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json,time,zlib,base64,hashlib

D=1<<256;OUT=1<<80

def fl(q):return q.numerator//q.denominator
def ce(q):return -fl(-q)
def down(q):return F(fl(q*OUT),OUT)
def up(q):return F(ce(q*OUT),OUT)
def iv(l,u):
    assert 0<=l<=u
    return {'lower':str(l),'upper':str(u),'display_only':[float(l),float(u)]}
def unit_log(q):
    assert 1<=q<=2
    t=(q-1)/(q+1);tl=fl(t*D);tu=ce(t*D)
    vl=tl*tl//D;vu=(tu*tu+D-1)//D;pl=tl;pu=tu;sl=su=0
    for j in range(100):
        sl+=2*pl//(2*j+1);su+=(2*pu+2*j)//(2*j+1)
        pl=pl*vl//D;pu=(pu*vu+D-1)//D
    tail=ce(D*F(2,201)*F(1,3)**201/F(8,9))
    return F(sl,D),F(su+tail,D)
LOG2=unit_log(F(2))
@lru_cache(None)
def logs(q):
    assert q>0
    k=q.numerator.bit_length()-q.denominator.bit_length();z=q/F(2)**k
    if z<1:k-=1;z*=2
    if z>=2:k+=1;z/=2
    l,u=unit_log(z)
    if k>=0:return l+k*LOG2[0],u+k*LOG2[1]
    return l+k*LOG2[1],u+k*LOG2[0]

def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0:p.pop()
    return tuple(p)
def add(p,q):return trim([(p[i] if i<len(p) else F(0))+(q[i] if i<len(q) else F(0)) for i in range(max(len(p),len(q)))])
def scale(p,a):return trim([a*x for x in p])
def sub(p,q):return add(p,scale(q,-1))
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for i,x in enumerate(p):
        if x:
            for j,y in enumerate(q):
                if y:r[i+j]+=x*y
    return trim(r)
def power(p,k):
    r=(F(1),)
    for _ in range(k):r=mul(r,p)
    return r
def value(p,x):
    r=F(0)
    for y in reversed(p):r=r*x+y
    return r

def lines_for(intervals,r):
    return tuple(sorted({(z,s) for interval in intervals for z in interval for s in (F(-1,2),F(1,2))}|{(-r,F(0)),(r,F(0))}))
def crossing_points(lines):
    out={F(0)}
    for a,b in combinations(lines,2):
        if a[1]!=b[1]:
            x=(b[0]-a[0])/(a[1]-b[1])
            if x>0:out.add(x)
    return out

def affine_capture(interval,x,L):
    """q(x,L)=ax*x+b0+b1*L in this fixed physical arrangement slab."""
    l,u=interval
    upper=(F(0),u,F(0)) if u<x+L/2 else (F(1),F(0),F(1,2))
    lower=(F(0),l,F(0)) if l>x-L/2 else (F(1),F(0),F(-1,2))
    q=tuple((a-b)/(u-l) for a,b in zip(upper,lower))
    return (F(0),F(0),F(0)) if q[0]*x+q[1]+q[2]*L<=0 else q

def slab_product_integral(qa,qb,l,u):
    a,b,c=qa;d,e,f=qb
    ps=(mul((b,c),(e,f)),add(scale((e,f),a),scale((b,c),d)),(a*d,))
    result=(F(0),)
    for k,p in enumerate(ps):
        result=add(result,scale(mul(p,sub(power(u,k+1),power(l,k+1))),F(1,k+1)))
    return result

@lru_cache(None)
def coordinate_pair(i,j,r,lo,hi):
    L=lo+1 if hi is None else (lo+hi)/2
    lines=sorted(lines_for((i,j),r),key=lambda p:value(p,L))
    # Crossings are excluded from the open scale interval. Constant duplicate
    # lines are removed by lines_for; all other orders are fixed here.
    assert all(value(a,L)<value(b,L) for a,b in zip(lines,lines[1:]))
    X=C=(F(0),)
    for left,right in zip(lines,lines[1:]):
        x=(value(left,L)+value(right,L))/2
        qa=affine_capture(i,x,L);qb=affine_capture(j,x,L)
        p=slab_product_integral(qa,qb,left,right)
        X=add(X,p)
        if -r<x<r:C=add(C,p)
    assert len(X)<=4 and len(C)<=4
    return X,C

def integrate_poly(p,n,lo,hi):
    """Integral polynomial(L)*L^(-2n-1) on one whole scale interval."""
    if all(c==0 for c in p):return F(0),F(0)
    assert lo>0
    l=u=F(0)
    for d,c in enumerate(p):
        if not c:continue
        exponent=d-2*n
        if hi is None:
            assert exponent<0
            t=-c*lo**exponent/exponent;l+=t;u+=t
        elif exponent:
            t=c*(hi**exponent-lo**exponent)/exponent;l+=t;u+=t
        else:
            ll,uu=logs(hi/lo)
            if c>0:l+=c*ll;u+=c*uu
            else:l+=c*uu;u+=c*ll
    assert l<=u
    return l,u

def codec(rows):
    data=json.dumps(rows,separators=(',',':')).encode()
    return {'codec':'base85 zlib compact JSON','payload':base64.b85encode(zlib.compress(data,9)).decode(),'sha256':hashlib.sha256(data).hexdigest(),'record_count':len(rows)}

def source_payload(s):return [{'center':[str(x) for x in c],'halfwidth':str(e),'mass':str(m)} for c,e,m in s]

def source_l2(sources):
    v=F(0)
    for c,e,m in sources:
        for z,h,w in sources:
            overlap=F(1)
            for x,y in zip(c,z):overlap*=max(F(0),min(x+e,y+h)-max(x-e,y-h))
            v+=m*w*overlap/((2*e)**len(c)*(2*h)**len(c))
    return v

def case(name,n,sources,stage):
    assert n>=2 and sum(m for c,e,m in sources)==F(1,2)
    assert all(len(c)==n and m>0 and e>0 and all(abs(z)+e<=F(1,2) for z in c) for c,e,m in sources)
    r=(1+F(1,n))/2
    reference=(tuple(F(0) for _ in range(n)),F(1,2),F(1,2))
    allsources=tuple(sources)+(reference,)
    intervals=[tuple((z-e,z+e) for z in c) for c,e,m in allsources]
    breaks={F(0)}
    for j in range(n):
        # Global arrangement includes every component's physical moving
        # face and cap face. It therefore also partitions every pair.
        breaks.update(crossing_points(lines_for(tuple(b[j] for b in intervals),r)))
    points=sorted(breaks);ranges=list(zip(points,points[1:]))+[(points[-1],None)]
    total=[[F(0),F(0)] for _ in range(4)];segments=[];scale_zero=F(0);tail=None
    for lo,hi in ranges:
        polys=[(F(0),) for _ in range(4)]
        for i in range(len(allsources)):
            for j in range(i,len(allsources)):
                X=C=(F(1),)
                for k in range(n):
                    xx,cc=coordinate_pair(intervals[i][k],intervals[j][k],r,lo,hi)
                    X=mul(X,xx);C=mul(C,cc)
                gram=sub(X,C)
                # Signed f-s coefficient; offdiagonals account for both orders.
                m=allsources[i][2]*allsources[j][2]*(1 if i==j else 2)
                if j<len(sources):index=0
                elif i==j:index=1
                else:index=2
                polys[index]=add(polys[index],scale(gram,m))
        polys[3]=sub(add(polys[0],polys[1]),polys[2])
        bounds=[integrate_poly(p,n,lo,hi) for p in polys]
        for k,(l,u) in enumerate(bounds):total[k][0]+=l;total[k][1]+=u
        # A polynomial identity, rather than a finite scale check.
        if all(c==0 for c in polys[3]) and scale_zero==lo and hi is not None:scale_zero=hi
        if hi is None:
            tail={'start':str(lo),'polynomial_signed':[str(x) for x in polys[3]],'degree_signed':len(polys[3])-1,'degree_full_ff':len(polys[0])-1,'all_scale_analytic_tail':iv(max(F(0),down(bounds[3][0])),max(F(0),up(bounds[3][1])))}
            # Equal source/reference masses eliminate the L^n term.
            assert len(polys[3])<=n
        segments.append([str(lo),None if hi is None else str(hi),[[str(x) for x in p] for p in polys],[[str(l),str(u)] for l,u in bounds]])
    certs=[iv(max(F(0),down(l)),max(F(0),up(u))) for l,u in total]
    ff,ss,cross,signed=certs
    absolute_upper=up(total[0][1]+total[1][1]+total[2][1])
    two_square_upper=up(2*(total[0][1]+total[1][1]))
    assert F(signed['upper'])<=min(absolute_upper,two_square_upper)
    margin=min(r-abs(z)-e for c,e,m in allsources for z in c)
    assert margin>0 and scale_zero>=2*margin
    positive_excess_witness=None
    if n==8 and name=='overlapping_correlated_two_scale':
        eta=F(1,1024);box=((-r-eta,-r-eta/2),)+tuple((F(-1,8)-eta,F(-1,8)+eta) for _ in range(n-1))
        Llo=F(1,2);Lhi=Llo+eta
        # Actual wide component alone gives a lower captured mass for every
        # receiver and every scale in this full positive-volume rectangle.
        c,e,m=sources[0];capture=m
        for (l,u),z in zip(box,c):
            t=max(abs(l-z),abs(u-z))
            capture*=max(F(0),min(e,t+Llo/2)-max(-e,t-Llo/2))/(2*e)
        avg=capture/Lhi**n;assert avg>1
        vol=F(1)
        for l,u in box:vol*=u-l
        gl,gu=logs(Lhi/Llo);lower=down(vol*(avg-1)**2*gl)
        positive_excess_witness={'receiver_box':[[str(l),str(u)] for l,u in box],'actual_dx_volume':str(vol),'scale_interval':[str(Llo),str(Lhi)],'actual_average_uniform_lower':str(avg),'actual_excess_energy_strict_lower':str(lower),'uses_only_positive_wide_component':True,'contained_in_cap_complement':all(u<-r for l,u in box[:1])}
        assert lower>0
    l2=source_l2(sources)
    source_extent=max(abs(z)+e for c,e,m in sources for z in c)
    first_possible_exterior_capture=2*(r-source_extent)
    actual_excess_zero=F(1,2)<=first_possible_exterior_capture**n
    ratios=None
    if F(signed['lower'])>0:
        ratios={'absolute_term_bound_over_actual_signed_interval':iv(down((total[0][0]+total[1][0]+total[2][0])/F(signed['upper'])),up(absolute_upper/F(signed['lower']))),'two_square_bound_over_actual_signed_interval':iv(down(2*(total[0][0]+total[1][0])/F(signed['upper'])),up(two_square_upper/F(signed['lower'])))}
    return {'name':name,'stage':stage,'dimension':n,'positive_source':source_payload(sources),'reference':source_payload((reference,))[0],'W':'1/2','kappa':'1','actual_source_L2_squared':str(l2),'actual_signed_source_L2_squared':str(l2-F(1,4)),'L2_is_source_quantity_not_exterior_energy':True,'actual_positive_excess_witness':positive_excess_witness,'reference_density':'1/2','cap_halfside':str(r),'actual_global_cap_volume':str((2*r)**n),'cap_normalized_volume_kappa_over_W':str(2*(2*r)**n),'minimum_margin_includes_f_and_s':str(margin),'signed_source_mass':'0','certified_exact_zero_scale_prefix':str(scale_zero),'finite_physical_scale_intervals':len(ranges)-1,'infinite_tail_intervals':1,'ff_exterior_energy':ff,'ss_exterior_energy':ss,'twice_fs_exterior_energy':cross,'actual_signed_exterior_energy':signed,'positive_excess_energy_upper_from_signed':signed['upper'],'actual_f_support_extent':str(source_extent),'exterior_first_capture_global_lower':str(first_possible_exterior_capture),'actual_positive_excess_identically_zero_certificate':actual_excess_zero,'actual_positive_excess_energy_exact_if_certified_zero':'0' if actual_excess_zero else None,'positive_excess_not_computed_exactly':not actual_excess_zero,'absolute_terms_selected_upper':str(absolute_upper),'two_square_selected_upper':str(two_square_upper),'cancellation_ratios':ratios,'tail':tail,'whole_scale_polynomial_witness':codec(segments),'polynomial_schema':['Llower','Lupper or null infinity','ff,ss,2fs,signed numerator coefficient arrays in ascending L powers','exact rational lower/upper integrated values'],'scope':'full original Lebesgue receiver cap complement and every L>0; no Fnew gates/general dimension estimate'}

def build():
    cases=[]
    cases.append(case('moderate_centered',2,(((F(0),)*2,F(1,4),F(1,2)),),'pilot'))
    for eps in (F(1,64),F(1,4096)):
        cases.append(case('deep_centered_'+str(eps),2,(((F(0),)*2,eps,F(1,2)),),'stress'))
    for n,stage in ((2,'stress'),(3,'expanded'),(4,'expanded'),(8,'expanded')):
        # Fixed overlapping source mixture, unequal widths, correlated centers.
        sources=(((F(-1,8),)*n,F(1,4),F(1,4)),((F(1,8),)*n,F(1,64),F(1,4)))
        cases.append(case('overlapping_correlated_two_scale',n,sources,stage))
    return {'round':97,'public_neutral_only':True,'case_count':len(cases),'distinct_positive_source_dimension_instances':len(cases),'quantity':'integral over Omega complement and all L of |A_L(f-s)|^2 dL/L dx; positive excess upper, not equal to positive excess','all_cases_same_reference_rule_and_cap_rule':True,'fixed_before_cost_comparison':True,'arithmetic':'exact Fraction polynomials;256-bit directed integer atanh/log100terms;80-bit final outward endpoints','no_float_in_certification':True,'cases':cases,'counts':{'pilot':1,'stress':3,'expanded':3,'finite_physical_scale_intervals':sum(r['finite_physical_scale_intervals'] for r in cases),'infinite_scale_tails':len(cases)},'general_weak_target':'UNRESOLVED'}
if __name__=='__main__':
    t=time.perf_counter();data=build();p=Path(__file__).with_name('energy_results.json');p.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'elapsed_seconds':time.perf_counter()-t,'bytes':p.stat().st_size,'cases':data['case_count']}))
