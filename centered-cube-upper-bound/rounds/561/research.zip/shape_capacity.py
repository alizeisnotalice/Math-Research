"""R561 finite shape-capacity geometry certificate; no Gram assertion.
Exact cube capacity and rigorous Arb enclosure of an analytic ball lower bound.
"""
from fractions import Fraction as F
from math import factorial,comb
import sys,platform,json,time,hashlib
import flint
from flint import arb,ctx
ctx.prec=192
NS=[16,32,64,128,256,512,1024];a=F(1,2);theta=F(3,4)
def A(x):return arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
def rational_endpoint(x,upper):return str((x.upper() if upper else x.lower()).fmpq())
def main():
 start=time.perf_counter();records=[]
 for n in NS:
  m=n//2;c2=(arb(factorial(m)).log()/m).exp()/arb.pi();c=c2.sqrt()
  tn=2*c/arb(n).sqrt();R2=c2-A(a*a)-2*A(a)*tn
  cube=F(sum(comb(n,d) for d in range(3*n//4+1,n+1)),2**n)
  r=dict(n=n,cube_exact=str(cube),cube_arb=str(A(cube)),c_squared_arb=str(c2),unit_volume_ball_radius_arb=str(c),t_n_arb=str(tn),R_squared_arb=str(R2))
  if R2>0:
   ball=(R2/c2)**m;ratio=A(cube)/ball
   r.update(valid=True,ball_capacity_lower_bound_arb=str(ball),ball_lower_bound_exact_interval=[rational_endpoint(ball,False),rational_endpoint(ball,True)],cube_over_ball_lower_bound_arb=str(ratio),analytic_ratio_exact_interval=[rational_endpoint(ratio,False),rational_endpoint(ratio,True)],actual_cube_over_actual_ball_capacity_upper_exact=rational_endpoint(ratio,True))
  elif R2<=0:r.update(valid=False,reason='R_squared_nonpositive')
  else:r.update(valid=False,reason='R_squared_sign_uncertain')
  records.append(r)
 limit=(-arb.pi()*arb(1).exp()*A(a*a)-2*A(a)*(2*arb.pi()*arb(1).exp()).sqrt()).exp()
 assert F(259,128)**4<27
 out=dict(python=sys.executable,python_version=platform.python_version(),flint_version=flint.__version__,arb_precision_bits=ctx.prec,script_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),parameters=dict(n=NS,a=str(a),theta=str(theta),cube_side=1,ball_volume=1),records=records,stirling_analytic_limit_arb=str(limit),L1_cube_uniform_chernoff_base_fourth_less_one_exact=str(F(259,128)**4/F(27)),elapsed_seconds=time.perf_counter()-start,scope='Geometric capacity only. Ball is a lower bound, so reported analytic quotient bounds actual cube/ball ratio from above; no whole Gram or operator certificate.')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
