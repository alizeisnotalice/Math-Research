"""R561 exact joint moment and true high-center volume for correlated axis laws.
All mathematical outputs use Fraction; decimal fields are display only.
"""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
from math import comb,prod
import sys,json,platform,time,hashlib
NS=[4,8,16,32,64,128];AS=[F(1,4),F(1,2),F(3,4)]
TH=[F(3,4),F(7,8)];TS=[F(0),F(1,2)];KS=[1,2,4,8,16,32,64,128]

def distinct_dp(n,t):
    d={(False,0):F(1)};saved={}
    for k in range(1,max(KS)+1):
        new=defaultdict(F)
        for (origin,D),p in d.items():
            if t:new[(True,D)]+=p*t
            if D:new[(origin,D)]+=p*(1-t)*F(D,n)
            if D<n:new[(origin,D+1)]+=p*(1-t)*F(n-D,n)
        d=dict(new);assert sum(d.values())==1
        if k in KS:saved[k]=d.copy()
    return saved

def moment(dist,a,singleton_correction=True):
    return sum((p*(1 if D==0 or (singleton_correction and not origin and D==1) else (1-a)**D) for (origin,D),p in dist.items()),F(0))

def enumeration(n,t,a,k):
    # Coordinates explicitly built; independent of DP span shortcut.
    atoms=[tuple(F(0) for _ in range(n))]+[tuple(a if i==j else F(0) for j in range(n)) for i in range(n)]
    probs=[t]+[(1-t)/n]*n
    answer=F(0)
    for ids in product(range(n+1),repeat=k):
        p=prod(probs[i] for i in ids)
        if not p:continue
        answer+=p*prod(max(F(0),1-max(atoms[i][j] for i in ids)+min(atoms[i][j] for i in ids)) for j in range(n))
    return answer

def exact_volume(n,t,a,theta,strict=True):
    # High centers lie in [-1/2,1/2]^n: outside at most one axis atom is caught.
    return sum((F(comb(n,D))*(1-a)**D*a**(n-D) for D in range(n+1) if (t+(1-t)*F(D,n)>theta if strict else t+(1-t)*F(D,n)>=theta)),F(0))

def spatial_moment(n,t,a,k):
    inner=sum((F(comb(n,D))*(1-a)**D*a**(n-D)*(t+(1-t)*F(D,n))**k for D in range(n+1)),F(0))
    return inner+n*a*((1-t)/n)**k

def center_enumeration(n,t,a,theta):
    # Product cells for coordinates in L,common,right; test actual axis atoms.
    intervals=[(F(-1,2),a-F(1,2)),(a-F(1,2),F(1,2)),(F(1,2),a+F(1,2))]
    atoms=[tuple(F(0) for _ in range(n))]+[tuple(a if i==j else F(0) for j in range(n)) for i in range(n)]
    probs=[t]+[(1-t)/n]*n;answer=F(0)
    for ids in product(range(3),repeat=n):
        b=[sum(intervals[i])/2 for i in ids]
        p=sum((w for z,w in zip(atoms,probs) if all(abs(z[j]-b[j])<=F(1,2) for j in range(n))),F(0))
        if p>theta:answer+=prod(intervals[i][1]-intervals[i][0] for i in ids)
    return answer

def marginal_profile(n,t,a,theta):
    p0=1-(1-t)/n
    def quantile(level):return F(0) if level<=p0 else a
    return (1-(quantile(theta)-quantile(1-theta)))**n

def main():
    start=time.perf_counter();checks=[]
    for n in [2,3,4]:
        for t in TS:
            dp=distinct_dp(n,t)
            for a in AS:
                for k in [1,2,4]:
                    direct=enumeration(n,t,a,k)
                    assert direct==moment(dp[k],a)
                    checks.append(dict(n=n,t=str(t),a=str(a),k=k,exact=str(direct)))
    center_checks=[]
    for nn in [2,3,4]:
        for tt in TS:
            for aa in AS:
                for th in TH:
                    direct=center_enumeration(nn,tt,aa,th)
                    assert direct==exact_volume(nn,tt,aa,th)
                    center_checks.append(dict(n=nn,t=str(tt),a=str(aa),theta=str(th),volume=str(direct)))
    records=[]
    for n in NS:
        for t in TS:
            ds=distinct_dp(n,t)
            for a in AS:
                moments={k:moment(ds[k],a) for k in KS}
                for k in KS:assert moments[k]==spatial_moment(n,t,a,k)
                for theta in TH:
                    bounds={k:moments[k]/theta**k for k in KS}
                    kbest=min(KS,key=lambda k:bounds[k]);vol=exact_volume(n,t,a,theta)
                    assert all(vol<=b for b in bounds.values())
                    profile=marginal_profile(n,t,a,theta)
                    records.append(dict(n=n,origin_mass=str(t),axis_amplitude=str(a),theta=str(theta),marginal_profile=str(profile),marginal_zero_mass=str(1-(1-t)/n),true_strict_high_volume=str(vol),true_nonstrict_high_volume=str(exact_volume(n,t,a,theta,False)),true_volume_display=float(vol),best_k=kbest,best_raw_moment_bound=str(bounds[kbest]),best_with_trivial_one=str(min(F(1),bounds[kbest])),best_bound_display=float(min(F(1),bounds[kbest])),moment_bounds={str(k):dict(moment=str(moments[k]),raw_markov_bound=str(bounds[k]),display=float(bounds[k])) for k in KS}))
    # Force explicit pressure checks: singleton correction and origin-only survival.
    pressures=[]
    for n,t in [(4,F(0)),(128,F(0)),(128,F(1,2))]:
        dp=distinct_dp(n,t)
        for k in [1,2,128]:
            a=F(3,4);correct=moment(dp[k],a);wrong=moment(dp[k],a,False)
            delta=(1-t)**k*F(n,n**k)*a
            assert correct-wrong==delta
            assert correct>=t**k
            pressures.append(dict(n=n,t=str(t),a=str(a),k=k,singleton_correction=str(delta),moment=str(correct),origin_only_mass=str(t**k)))
    out=dict(python=sys.executable,python_version=platform.python_version(),script_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),parameters=dict(n=NS,a=list(map(str,AS)),theta=list(map(str,TH)),origin_mass=list(map(str,TS)),k=KS),enumeration_checks=checks,center_geometry_checks=center_checks,spatial_moment_identity_checks=6*2*3*8,records=records,pressure_checks=pressures,elapsed_seconds=time.perf_counter()-start,scope='Exact finite rational correlated source laws; no generally dimension-uniform asymptotic inference; iid samples used only for center moment identity.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
