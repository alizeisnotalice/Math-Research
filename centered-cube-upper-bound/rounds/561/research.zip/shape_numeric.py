"""R561 finite-source cube/ball geometry and complete-field diagnostic.
All source atoms retained. Only specified three R561 files are mutated.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2'
import math,json,time,platform
import numpy as np
from scipy.special import gammaln


def ball_radius(n):return math.exp(float(gammaln(n/2+1))/n)/math.sqrt(math.pi)

def atoms_cloud(n,kind,seed=56100):
    rng=np.random.default_rng(seed+n)
    if kind=='product':return rng.uniform(-.5,.5,size=(64,n))
    if kind=='diagonal':
        t=rng.uniform(-.5,.5,size=(64,1))
        return t+0.02*rng.uniform(-.5,.5,size=(64,n))
    raise ValueError(kind)


def entry_radii(B,atoms,shape):
    delta=np.asarray(B)[...,None,:]-atoms
    return 2*np.max(np.abs(delta),axis=-1) if shape=='cube' else np.linalg.norm(delta,axis=-1)/ball_radius(atoms.shape[1])


def sample_centers(atoms,M,b,seed):
    """Shared normalized proposal for probability source mu=(1/64)sum delta."""
    rng=np.random.default_rng(seed);n=atoms.shape[1]
    source=rng.integers(0,len(atoms),size=M);choice=rng.integers(0,2,size=M)
    cube=rng.uniform(-b/2,b/2,size=(M,n))
    normal=rng.standard_normal((M,n));normal/=np.linalg.norm(normal,axis=1)[:,None]
    ball=normal*(rng.uniform(size=M)**(1/n)*ball_radius(n)*b)[:,None]
    B=atoms[source]+np.where(choice[:,None]==0,cube,ball)
    mc=np.mean(entry_radii(B,atoms,'cube')<=b,axis=1)
    mb=np.mean(entry_radii(B,atoms,'ball')<=b,axis=1)
    p=(mc+mb)/(2*b**n)
    assert np.all(p>0)
    return B,p,choice


def mass_platforms(entries,R,G,n):
    """(l,u,mask) open plateaux plus exact closed endpoint membership."""
    g=(entries/R)**n
    pts=np.unique(np.r_[1.,g[(g>1)&(g<G)],G]);out=[]
    for l,u in zip(pts[:-1],pts[1:]):
        mask=g<=math.sqrt(l*u)
        out.append((float(l),float(u),mask))
    return out,entries<=R,entries<=R*G**(1/n)


def geometry_calibration(M=256):
    st=time.perf_counter();records=[]
    for n in [4,8,16]:
        c=ball_radius(n);ballvol=math.pi**(n/2)/math.exp(float(gammaln(n/2+1)))*c**n
        for kind in ['product','diagonal']:
            atoms=atoms_cloud(n,kind);B,p,choice=sample_centers(atoms,M,1.,56111+n)
            mc=np.mean(entry_radii(B,atoms,'cube')<=1.,axis=1)
            mb=np.mean(entry_radii(B,atoms,'ball')<=1.,axis=1)
            plat=[]
            for shape in ['cube','ball']:
                ent=entry_radii(B[0],atoms,shape);R=8**(-1/n)
                seg,m0,mG=mass_platforms(ent,R,4,n)
                for l,u,mask in seg:
                    direct=ent<=R*math.sqrt(l*u)**(1/n)
                    assert np.array_equal(mask,direct)
                plat.append(dict(shape=shape,platforms=len(seg),mass0=int(sum(m0)),massG=int(sum(mG))))
            records.append(dict(n=n,cloud=kind,atom_count=64,total_source_mass=1,ball_unitvolume=ballvol,proposal_min=float(min(p)),proposal_max=float(max(p)),cube_mu_volume_estimate=float(np.mean(mc/p)),ball_mu_volume_estimate=float(np.mean(mb/p)),paired_volume_exact_identity=float(np.max(abs((mc+mb)/(2*p)-1))),platform_check=plat))
    return dict(stage='geometry-only',M=M,records=records,source_seed=56100,center_seed_rule='56111+n, shared across shapes and cloud kinds',diagonal_noise_width=.02,elapsed_seconds=time.perf_counter()-st,python=platform.python_version(),numpy=np.__version__,scope='No field/bulk comparison before main contract confirmation; volume estimates are importance-MC evidence only.')


def proposal_density(entries_cube,entries_ball,n,a=.5,b=1.):
    def pk(ent):
        radial=np.maximum(np.maximum(a,ent)**(-n)-b**(-n),0)
        return .5*np.mean(ent<=b,axis=-1)/b**n+np.mean(radial,axis=-1)/(2*n*math.log(b/a))
    return .5*(pk(entries_cube)+pk(entries_ball))


def sample_scale_centers(atoms,M,seed,a=.5,b=1.):
    rng=np.random.default_rng(seed);n=atoms.shape[1]
    src=rng.integers(0,len(atoms),size=M);shape=rng.integers(0,2,size=M);mode=rng.integers(0,2,size=M)
    R=np.where(mode==0,b,np.exp(rng.uniform(math.log(a),math.log(b),size=M)))
    cube=rng.uniform(-.5,.5,size=(M,n))*R[:,None]
    normal=rng.standard_normal((M,n));normal/=np.linalg.norm(normal,axis=1)[:,None]
    ball=normal*(rng.uniform(size=M)**(1/n)*ball_radius(n)*R)[:,None]
    B=atoms[src]+np.where(shape[:,None]==0,cube,ball)
    ec=entry_radii(B,atoms,'cube');eb=entry_radii(B,atoms,'ball')
    p=proposal_density(ec,eb,n,a,b);assert np.all(p>0)
    return B,p,ec,eb


def scale_proposal_calibration(M=4096):
    st=time.perf_counter();rows=[]
    for n in [4,8,16]:
        for kind in ['product','diagonal']:
            atoms=atoms_cloud(n,kind);B,p,ec,eb=sample_scale_centers(atoms,M,56131+n)
            row=dict(n=n,cloud=kind,M=M,proposal_min=float(min(p)),proposal_max=float(max(p)),known_volume_checks={})
            for shape,ent in [('cube',ec),('ball',eb)]:
                for R in [.5,1.]:
                    v=np.mean(ent<=R,axis=1)/p/R**n
                    row['known_volume_checks'][shape+'_'+str(R)]=dict(estimate=float(np.mean(v)),iid_standard_error=float(np.std(v,ddof=1)/math.sqrt(M)),target=1.)
            rows.append(row)
    return dict(M=M,formula='p=(p_cube+p_ball)/2; pK=mu(K_b)/(2b^n)+mean[(max(a,rho)^(-n)-b^(-n))_+]/(2n ln(b/a))',records=rows,elapsed_seconds=time.perf_counter()-st,scope='Shared four-component proposal; each MC integral has exact target1. No field comparison or Gaussian confidence certificate.')


def parents(entries,p,n,a=.5,b=1.):
    grid=a+(b-a)*np.arange(33)/32;vol=grid**n;out=[];M=len(p)
    for i,ent in enumerate(entries):
        counts=np.sum(ent[:,None]<=grid[None,:],axis=0)
        densities=counts/64/vol;k=int(np.argmax(densities));q0=float(densities[k])
        if q0<=0:continue
        out.append(dict(idx=i,band=math.frexp(q0)[1]-1,R=float(grid[k]),count=int(counts[k]),q0=q0,weight=1/(M*p[i]),entries=ent,mask=ent<=grid[k]))
    return out


def add_rect(field,band,mask,phase,left,coef):
    for atom in np.flatnonzero(mask):field.setdefault((band,int(atom),phase),[]).append((left,left+1,coef))


def old_field(records):
    f={}
    for r in records:add_rect(f,r['band'],r['mask'],0,math.log2(r['count']/64),r['weight']/r['R']**r['n'])
    return f


def build_primitives(field):
    out={}
    for key,rr in field.items():
        events=sorted([(l,c) for l,u,c in rr]+[(u,-c) for l,u,c in rr])
        xs=[];areas=[];vals=[];v=0.;area=0.;last=events[0][0]
        for x,d in events:
            area+=v*(x-last);v+=d;last=x
            xs.append(x);areas.append(area);vals.append(v)
        out[key]=(np.array(xs),np.array(areas),np.array(vals))
    return out


def window_value(primitives,key,l,u):
    if key not in primitives:return 0.
    xs,areas,vals=primitives[key]
    def primitive(x):
        j=int(np.searchsorted(xs,x,side='right'))-1
        return 0. if j<0 else float(areas[j]+vals[j]*(x-xs[j]))
    return primitive(u)-primitive(l)


def phase_int(count,count0):
    A=int(count)**8;B=int(count0)**8;j=A.bit_length()-B.bit_length()
    if A<(B<<j):j-=1
    return j


def classify_parents(records,primitives,n,G):
    C=1+math.log(4);An=1+n*math.log(2)
    groups={x:[] for x in ['low','rapid','top','bulk']}
    for r0 in records:
        r=dict(r0);s=math.log2(r['count']/64)
        alpha=sum(window_value(primitives,(r['band'],int(atom),0),s,s+1) for atom in np.flatnonzero(r['mask']))/(C*r['count'])
        seg,mask0,maskG=mass_platforms(r['entries'],r['R'],G,n)
        kG=sum(maskG)/r['count'];K=max(2**.125,An*alpha)
        label='low' if alpha<=1/An else 'rapid' if kG>=K else 'top' if r['R']>=G**(-1/n) else 'bulk'
        r.update(alpha=alpha,segments=seg,maskG=maskG,kG=float(kG),K=K)
        groups[label].append(r)
    return groups


def build_candidate_fields(groups,n,G):
    fields={law:{} for law in ['common','two','adaptive','common_eta','two_eta','adaptive_eta']}
    eta_rows=[]
    for r in groups['bulk']:
        cnt0=r['count'];cntG=int(sum(r['maskG']));kG=cntG/cnt0
        N=1+sum((u-l)*cnt0/sum(mask) for l,u,mask in r['segments'])+G/kG
        I=1+sum(math.log(u/l)*cnt0/sum(mask) for l,u,mask in r['segments'])+1/kG
        etas=dict(common=1/(1+math.log(G)),two=2/(2+math.log(G)),adaptive=I/N)
        eta_rows.append((r['band'],etas['adaptive'],N,I,kG,r['alpha'],r['weight']))
        amplitude=r['weight']/r['R']**n
        for l,u,mask in r['segments']:
            cnt=int(sum(mask));kap=cnt/cnt0;j=phase_int(cnt,cnt0);left=math.log2(cnt/64)
            coeff=dict(common=amplitude*(1/l-1/u)/(1+math.log(G)),two=amplitude*(1/l-1/u)/(2+math.log(G)),adaptive=amplitude*math.log(u/l)/(kap*N))
            for law,c in coeff.items():
                add_rect(fields[law],r['band'],mask,j,left,c)
                add_rect(fields[law+'_eta'],r['band'],mask,j,left,c/etas[law])
        for endpoint,mask in [(1,r['mask']),(G,r['maskG'])]:
            cnt=int(sum(mask));kap=cnt/cnt0;j=phase_int(cnt,cnt0);left=math.log2(cnt/64)
            if endpoint==1:coeff=dict(two=amplitude/(2+math.log(G)),adaptive=amplitude/N)
            else:coeff=dict(common=amplitude/G/(1+math.log(G)),two=amplitude/G/(2+math.log(G)),adaptive=amplitude/(kap*N))
            for law,c in coeff.items():
                add_rect(fields[law],r['band'],mask,j,left,c)
                add_rect(fields[law+'_eta'],r['band'],mask,j,left,c/etas[law])
    return fields,eta_rows


def cross_field(f1,f2,aggregate_bands=False):
    def remap(f):
        if not aggregate_bands:return f
        out={}
        for (band,atom,j),v in f.items():out.setdefault((atom,j),[]).extend(v)
        return out
    f1,f2=remap(f1),remap(f2);byband={};total=0.
    for key in f1.keys()&f2.keys():
        ev=sorted([(l,0,c) for l,u,c in f1[key]]+[(u,0,-c) for l,u,c in f1[key]]+[(l,1,c) for l,u,c in f2[key]]+[(u,1,-c) for l,u,c in f2[key]])
        v=[0.,0.];E=0.;last=ev[0][0]
        for x,ch,c in ev:E+=v[0]*v[1]*(x-last);v[ch]+=c;last=x
        E/=64;total+=E
        if not aggregate_bands:byband[key[0]]=byband.get(key[0],0.)+E
    return float(total),{str(k):float(v) for k,v in byband.items()}


def shape_stage(n,kind,M=256,T=256,Gs=(2,4)):
    st=time.perf_counter();atoms=atoms_cloud(n,kind)
    samples=[sample_scale_centers(atoms,S,seed+n) for S,seed in [(T,56141),(M,56151),(M,56161)]]
    results=[]
    for shape,ix in [('cube',2),('ball',3)]:
        train=parents(samples[0][ix],samples[0][1],n)
        for r in train:r['n']=n
        oldtrain=old_field(train);primitive=build_primitives(oldtrain)
        training_counts={k:sum(r['band']==k for r in train) for k in {r['band'] for r in train}}
        evalrecords=[]
        for sample in samples[1:]:
            rr=parents(sample[ix],sample[1],n)
            for r in rr:r['n']=n
            evalrecords.append(rr)
        for G in Gs:
            batch=[]
            for rr in evalrecords:
                groups=classify_parents(rr,primitive,n,G)
                fields,etas=build_candidate_fields(groups,n,G)
                fields['old_all']=old_field(rr);fields['old_bulk']=old_field(groups['bulk'])
                for label,items in groups.items():fields['branch_'+label]=old_field(items)
                bands={}
                for k in {r['band'] for r in rr}:
                    ss={};allband=[r for r in rr if r['band']==k]
                    for label,items in groups.items():
                        bb=[r for r in items if r['band']==k];ww=np.array([r['weight'] for r in bb])
                        ss[label]=dict(count=len(bb),center_volume=float(sum(ww)),effective_sample_size=float(sum(ww)**2/sum(ww**2)) if len(ww) else 0.,q0_mass=float(sum(r['weight']*r['q0'] for r in bb)),oldscore=float(sum(r['weight']*(1+math.log(4))*r['q0']*r['alpha'] for r in bb)))
                    bands[str(k)]=dict(q=2.**k,training_count=training_counts.get(k,0),evaluation_count=len(allband),untrained=training_counts.get(k,0)==0,low_training=training_counts.get(k,0)<8,branches=ss)
                batch.append((fields,bands,etas,groups))
            energies={}
            for law in ['old_all','old_bulk','common','two','adaptive','common_eta','two_eta','adaptive_eta']:
                diagonal,byband=cross_field(batch[0][0][law],batch[1][0][law]);aggregate,_=cross_field(batch[0][0][law],batch[1][0][law],True)
                energies[law]=dict(band_diagonal=diagonal,byband=byband,all_band_complete=aggregate,cross_band_fee=aggregate-diagonal,batch_self_diagonal=[cross_field(bb[0][law],bb[0][law])[0] for bb in batch],batch_self_complete=[cross_field(bb[0][law],bb[0][law],True)[0] for bb in batch])
            deletion={}
            for label in ['low','rapid','top','bulk']:
                a1,_=cross_field(batch[0][0]['branch_'+label],batch[1][0]['old_all']);a2,_=cross_field(batch[0][0]['old_all'],batch[1][0]['branch_'+label])
                deletion[label]=.5*(a1+a2)
            eta_summary=[]
            for fields,bands,etas,groups in batch:
                eta_summary.append(dict(bulk_count=len(groups['bulk']),adaptive_eta_range=[min(x[1] for x in etas),max(x[1] for x in etas)] if etas else None,flat_bulk_count=sum(r['kG']==1 for r in groups['bulk']),alpha_range=[min(r['alpha'] for r in sum(groups.values(),[])),max(r['alpha'] for r in sum(groups.values(),[]))] if sum(groups.values(),[]) else None,alpha_outside_0_1=sum(r['alpha']>1+1e-12 for r in sum(groups.values(),[])),bulk_q0alpha=float(sum(r['weight']*r['q0']*r['alpha'] for r in groups['bulk'])),near_low_volume=float(sum(r['weight'] for r in sum(groups.values(),[]) if abs(r['alpha']*(1+n*math.log(2))-1)<.05)),near_rapid_volume=float(sum(r['weight'] for r in sum(groups.values(),[]) if abs(math.log(r['kG']/r['K']))<.05))))
            results.append(dict(shape=shape,G=G,energies=energies,old_branch_gram_attribution=deletion,batches=[b[1] for b in batch],eta_summary=eta_summary,training_bands={str(k):dict(count=v,center_weight_ESS=sum(r['weight'] for r in train if r['band']==k)**2/sum(r['weight']**2 for r in train if r['band']==k),max_source_old_field=max([float(max(z[2])) for key,z in primitive.items() if key[0]==k],default=0.)) for k,v in training_counts.items()}))
    return dict(n=n,cloud=kind,M=M,T=T,frozen_center_inputs=[dict(role=role,points=sample[0].tolist(),proposal_density=sample[1].tolist()) for role,sample in zip(['training','evaluation1','evaluation2'],samples)],a=.5,b=1.,An=1+n*math.log(2),C=1+math.log(4),atoms=atoms.tolist(),results=results,elapsed_seconds=time.perf_counter()-st)


def run_shape_main(M=256,T=256,dimensions=(4,8,16),kinds=('product','diagonal')):
    st=time.perf_counter();rows=[]
    for n in dimensions:
        for kind in kinds:
            row=shape_stage(n,kind,M,T);rows.append(row)
            print('completed',n,kind,'seconds',row['elapsed_seconds'],flush=True)
    return dict(M=M,T=T,seed_sources=56100,seed_training_rule='56141+n',seed_eval_rules=['56151+n','56161+n'],source_mass=1.,source_atom_count=64,body_volume='R^n',q_bands='all dyadic floor(log2 q0), none dropped',records=rows,elapsed_seconds=time.perf_counter()-st)


def coincident_source_pressure():
    """Exact radial-shell integrals for 64 coincident atoms, mu=delta0.
    Known shape-invariant normalization pressure, not either main cloud.
    """
    out=[]
    for n in [4,8,16]:
        grid=.5+.5*np.arange(33)/32
        shells=np.r_[grid[0]**n,np.diff(grid**n)]
        ks=[math.frexp(float(R**(-n)))[1]-1 for R in grid]
        L={k:sum(shells[i]/grid[i]**n for i in range(33) if ks[i]==k) for k in set(ks)}
        for G in [2,4]:
            bulk={k:0. for k in L};branches={x:0. for x in ['low','rapid','top','bulk']}
            for i,R in enumerate(grid):
                k=ks[i];alpha=L[k]/(1+math.log(4))
                label='low' if alpha<=1/(1+n*math.log(2)) else 'top' if R>=G**(-1/n) else 'bulk'
                branches[label]+=shells[i]
                if label=='bulk':bulk[k]+=shells[i]/R**n
            diag=sum(x*x for x in bulk.values());complete=sum(bulk.values())**2
            eta=dict(common=1/(1+math.log(G)),two=2/(2+math.log(G)),adaptive=(2+math.log(G))/(2*G))
            out.append(dict(n=n,G=G,source='64 coincident atoms of mass1/64, total mass1',shape='cube=ball by exact unit-volume radial shells',old_band_fields={str(k):float(v) for k,v in L.items()},old_bulk_diagonal=float(diag),old_bulk_complete=float(complete),C_eta_all_laws=dict(band_diagonal=float(diag),all_band_complete=float(complete)),raw_diagonal={k:float(diag*x*x) for k,x in eta.items()},branches_center_volume={k:float(v) for k,v in branches.items()}))
    return dict(records=out,scope='Analytic known-null calibration, no sampling, no assertion that main product/diagonal clouds coincide.')



def source_target_sample(atoms,y,M,seed):
    B,py,_,_=sample_scale_centers(atoms[y:y+1],M,seed)
    ec=entry_radii(B,atoms,'cube');eb=entry_radii(B,atoms,'ball')
    pg=proposal_density(ec,eb,atoms.shape[1])
    return B,py,ec,eb,pg


def target_old_field(records,y):
    out={}
    for r in records:
        if r['mask'][y]:
            out.setdefault((r['band'],y,0),[]).append((math.log2(r['count']/64),math.log2(r['count']/64)+1,r['weight']/r['R']**r['n']))
    return out


def merge_fields(destination,extra):
    for key,v in extra.items():destination.setdefault(key,[]).extend(v)


def target_candidates(groups,n,G,y):
    fields={law:{} for law in ['common','two','adaptive','common_eta','two_eta','adaptive_eta']}
    eta_rows=[];max_action_importance=0.
    for r in groups['bulk']:
        c0=r['count'];cG=int(sum(r['maskG']));kG=cG/c0
        N=1+sum((u-l)*c0/sum(mask) for l,u,mask in r['segments'])+G/kG
        I=1+sum(math.log(u/l)*c0/sum(mask) for l,u,mask in r['segments'])+1/kG
        eta=dict(common=1/(1+math.log(G)),two=2/(2+math.log(G)),adaptive=I/N)
        amp=r['weight']/r['R']**n
        eta_rows.append((r['band'],eta['adaptive'],N,I,r['alpha'],r['kG']))
        def insert(mask,j,left,coefs):
            if not mask[y]:return
            for law,c in coefs.items():
                fields[law].setdefault((r['band'],y,j),[]).append((left,left+1,c))
                fields[law+'_eta'].setdefault((r['band'],y,j),[]).append((left,left+1,c/eta[law]))
        for l,u,mask in r['segments']:
            cnt=int(sum(mask));kap=cnt/c0;j=phase_int(cnt,c0);left=math.log2(cnt/64)
            insert(mask,j,left,dict(common=amp*(1/l-1/u)/(1+math.log(G)),two=amp*(1/l-1/u)/(2+math.log(G)),adaptive=amp*math.log(u/l)/(kap*N)))
            if mask[y]:max_action_importance=max(max_action_importance,amp*r['sample_M']/math.sqrt(l*u))
        for g,mask in [(1,r['mask']),(G,r['maskG'])]:
            cnt=int(sum(mask));kap=cnt/c0;j=phase_int(cnt,c0);left=math.log2(cnt/64)
            coefs=dict(two=amp/(2+math.log(G)),adaptive=amp/N) if g==1 else dict(common=amp/G/(1+math.log(G)),two=amp/G/(2+math.log(G)),adaptive=amp/(kap*N))
            insert(mask,j,left,coefs)
            if mask[y]:max_action_importance=max(max_action_importance,amp*r['sample_M']/g)
    return fields,eta_rows,max_action_importance


def selector_signature(r,primitives,n,G):
    groups=classify_parents([r],primitives,n,G)
    label=next(k for k,v in groups.items() if v);rr=groups[label][0]
    c0=rr['count'];cg=int(sum(rr['maskG']));N=1+sum((u-l)*c0/sum(mask) for l,u,mask in rr['segments'])+G*c0/cg
    I=1+sum(math.log(u/l)*c0/sum(mask) for l,u,mask in rr['segments'])+c0/cg
    return rr['R'],rr['band'],c0,rr['alpha'],label,N,I,tuple((l,u,int(sum(mask)),phase_int(int(sum(mask)),c0)) for l,u,mask in rr['segments'])


def source_stratified_checks():
    n=16;H=n*math.log(2);atoms=atoms_cloud(n,'diagonal');sample=source_target_sample(atoms,0,64,56200)
    maxima={}
    for shape,ix in [('cube',2),('ball',3)]:
        rr=parents(sample[ix],sample[1],n);maxima[shape]=max((r['weight']*64/r['R']**n for r in rr if r['mask'][0]),default=0.)
        assert maxima[shape]<=4*H*(1+1e-12)
    return dict(n=n,cloud='diagonal',points=64,theoretical_raw_bound=4*H,observed_old_importance=maxima,proposal_normalization='each source-centered four-component mixture integrates exactly1 by unit-volume bodies and normalized log-scale mixture',scope='Geometric importance bound precheck only; no new source-stratified field result yet')


def source_stratified_pilot(Ty=256,My=128):
    """Only authorized n16 diagonal, G2, all64 sources, paired shapes."""
    import hashlib
    st=time.perf_counter();n=16;G=2;atoms=atoms_cloud(n,'diagonal');C=1+math.log(4);H=n*math.log(2)
    codehash=hashlib.sha256(open(__file__,'rb').read()).hexdigest()
    training_fields={shape:{} for shape in ['cube','ball']};training_ledger={shape:{} for shape in training_fields};training_inputs=[]
    for y in range(64):
        sample=source_target_sample(atoms,y,Ty,562100+y)
        training_inputs.append(dict(source=y,seed=562100+y,points=sample[0].tolist(),p_y=sample[1].tolist()))
        for shape,ix in [('cube',2),('ball',3)]:
            rr=parents(sample[ix],sample[1],n)
            for r in rr:r.update(n=n,sample_M=Ty)
            field=target_old_field(rr,y);merge_fields(training_fields[shape],field)
            source_bands={}
            for k in {r['band'] for r in rr}:
                active=[r for r in rr if r['band']==k and r['mask'][y]]
                w=np.array([r['weight']/r['R']**n for r in active]);counts=len(active)
                source_bands[str(k)]=dict(parent_count=sum(r['band']==k for r in rr),receiver_count=counts,importance_amplitude_ESS=float(sum(w)**2/sum(w*w)) if counts else 0.,maximum_unaveraged_importance=float(max(w)*Ty) if counts else 0.)
                if counts:assert max(w)*Ty<=4*H*(1+1e-12)
            training_ledger[shape][str(y)]=source_bands
    primitives={shape:build_primitives(f) for shape,f in training_fields.items()}
    cap={}
    for shape in primitives:
        violations=[];maximum=0.
        for key,(_,_,values) in primitives[shape].items():
            v=float(max(values));maximum=max(maximum,v)
            if v>C:violations.append(dict(source=key[1],band=key[0],max_L=v,excess=v-C))
        cap[shape]=dict(maximum_L=maximum,C=C,violations=violations,violating_source_band_count=len(violations))
    # Same coordinates/full mu/frozen training, different integration weights:
    # the selector signature MUST agree. No target-y argument is accepted.
    dependency_checks=0
    for shape,ix in [('cube',2),('ball',3)]:
        sample=source_target_sample(atoms,0,32,562999)
        rr=parents(sample[ix],sample[1],n)
        for r in rr[:16]:
            r.update(n=n,sample_M=32);other=dict(r);other['weight']=r['weight']*7
            assert selector_signature(r,primitives[shape],n,G)==selector_signature(other,primitives[shape],n,G)
            dependency_checks+=1
    training_seconds=time.perf_counter()-st
    print('source training frozen, cap', {s:cap[s]['maximum_L'] for s in cap},'selector checks',dependency_checks,flush=True)
    allfields={shape:[{law:{} for law in ['common','two','adaptive','common_eta','two_eta','adaptive_eta','old_all','old_bulk','branch_low','branch_rapid','branch_top','branch_bulk']} for batch in range(2)] for shape in ['cube','ball']}
    ledgers={shape:[{} for _ in range(2)] for shape in ['cube','ball']};all_eta={shape:[[] for _ in range(2)] for shape in ['cube','ball']};eval_inputs=[[],[]]
    branch_prices={shape:[{} for _ in range(2)] for shape in ['cube','ball']};max_actions=0.
    for batch in range(2):
        for y in range(64):
            seed=562200+batch*1000+y;sample=source_target_sample(atoms,y,My,seed)
            eval_inputs[batch].append(dict(source=y,seed=seed,points=sample[0].tolist(),p_y=sample[1].tolist(),p_global=sample[4].tolist()))
            for shape,ix in [('cube',2),('ball',3)]:
                rr=parents(sample[ix],sample[1],n)
                for r in rr:r.update(n=n,sample_M=My)
                groups=classify_parents(rr,primitives[shape],n,G)
                fields,etas,maxw=target_candidates(groups,n,G,y);max_actions=max(max_actions,maxw)
                for law,f in fields.items():merge_fields(allfields[shape][batch][law],f)
                merge_fields(allfields[shape][batch]['old_all'],target_old_field(rr,y));merge_fields(allfields[shape][batch]['old_bulk'],target_old_field(groups['bulk'],y))
                for label,items in groups.items():merge_fields(allfields[shape][batch]['branch_'+label],target_old_field(items,y))
                ledger={}
                for k in {r['band'] for r in rr}:
                    bands={}
                    for label,items in groups.items():
                        ss=[r for r in items if r['band']==k];active=[r for r in ss if r['maskG'][y]]
                        # Non-source-specific parent prices use the balanced mixture
                        # p_global, since target-conditioned supports differ.
                        weights=np.array([1/(64*My*sample[4][r['idx']]) for r in ss])
                        bands[label]=dict(parent_count=len(ss),receiving_parent_count=len(active),balanced_center_volume=float(sum(weights)),balanced_q0_mass=float(sum(w*r['q0'] for w,r in zip(weights,ss))),balanced_oldscore=float(sum(w*C*r['q0']*r['alpha'] for w,r in zip(weights,ss))))
                    ledger[str(k)]=dict(training_receivers=training_ledger[shape][str(y)].get(str(k),{}).get('receiver_count',0),branches=bands)
                ledgers[shape][batch][str(y)]=ledger
                all_eta[shape][batch].extend((y,*x) for x in etas)
        print('source evaluation batch complete',batch+1,flush=True)
    assert max_actions<=4*H*(1+1e-11)
    results={}
    for shape in allfields:
        fs=allfields[shape];energies={}
        for law in ['old_all','old_bulk','common','two','adaptive','common_eta','two_eta','adaptive_eta']:
            d,by=cross_field(fs[0][law],fs[1][law]);a,_=cross_field(fs[0][law],fs[1][law],True)
            energies[law]=dict(band_diagonal_cross=d,byband_cross=by,all_band_complete_cross=a,cross_band_fee=a-d,band_diagonal_self=[cross_field(f[law],f[law])[0] for f in fs],all_band_complete_self=[cross_field(f[law],f[law],True)[0] for f in fs])
        deletion={}
        for label in ['low','rapid','top','bulk']:
            c1,_=cross_field(fs[0]['branch_'+label],fs[1]['old_all']);c2,_=cross_field(fs[0]['old_all'],fs[1]['branch_'+label]);deletion[label]=.5*(c1+c2)
        results[shape]=dict(energies=energies,old_branch_gram_attribution=deletion,evaluation_source_band_ledger=ledgers[shape],eta_rows=all_eta[shape])
    return dict(n=n,cloud='diagonal',source_seed=56100+n,diagonal_noise_width=.02,G=G,Ty=Ty,My=My,source_count=64,source_mass=1.,a=.5,b=1.,An=1+n*math.log(2),C=C,atoms=atoms.tolist(),code_sha256=codehash,training_frozen_before_evaluation=True,selector_no_target_argument_checks=dependency_checks,training_cap=cap,training_source_band_ledger=training_ledger,training_inputs=training_inputs,evaluation_inputs=eval_inputs,results=results,theoretical_raw_importance_bound=4*H,observed_max_action_importance=max_actions,training_seconds=training_seconds,elapsed_seconds=time.perf_counter()-st,scope='Only the authorized paired n16 source-stratified pilot; empirical alpha labels and no geometric/asymptotic certificate.')


def compact_view(value):
    """Remove only seed-rebuildable raw input arrays; retain all decisions/costs."""
    import hashlib
    rebuildable={'points','proposal_density','p_y','p_global','atoms'}
    if isinstance(value,dict):
        out={}
        for key,item in value.items():
            if key in rebuildable and isinstance(item,list):
                arr=np.asarray(item,dtype='<f8')
                header=json.dumps(list(arr.shape),separators=(',',':')).encode()
                out[key+'_rebuild']=dict(shape=list(arr.shape),dtype='little-endian float64',sha256=hashlib.sha256(header+arr.tobytes(order='C')).hexdigest(),status='regenerate from retained model/RNG seeds and code')
            else:out[key]=compact_view(item)
        return out
    if isinstance(value,list):return [compact_view(x) for x in value]
    return value


if __name__=='__main__':
    import argparse,resource,scipy
    p=argparse.ArgumentParser()
    p.add_argument('--output',default='/tmp/ccu_r561_shape_numeric.json',help='JSON output path; default retains the full local file')
    p.add_argument('--compact',action='store_true',help='Omit only rebuildable input arrays, replacing them with hashes/shapes')
    p.add_argument('--all',action='store_true',help='Reproduce calibration, initial/expanded comparisons and the authorized source pilot')
    p.add_argument('--source-pilot',action='store_true',help='Append the single authorized n16 diagonal source-stratified pilot')
    p.add_argument('--source-check',action='store_true',help='Only source proposal bound precheck')
    args=p.parse_args()
    output_path=args.output
    if args.source_check:
        print(json.dumps(source_stratified_checks(),indent=2));raise SystemExit(0)
    if args.source_pilot:
        try:
            with open(output_path) as f:out=json.load(f)
        except FileNotFoundError:out={}
        out['source_stratified_precheck']=source_stratified_checks()
        out['source_stratified_pilot']=source_stratified_pilot()
        out['source_stratified_maxrss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        out['runtime_metadata']=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,BLAS_threads=2)
        if args.compact:out=compact_view(out)
        with open(output_path,'w') as f:json.dump(out,f,indent=None if args.compact else 2,separators=(',',':') if args.compact else None)
        print('Source pilot appended; earlier data retained');raise SystemExit(0)
    out=geometry_calibration()
    out['scale_proposal_calibration']=scale_proposal_calibration()
    out['known_null_pressure']=coincident_source_pressure()
    if args.all:
        out['initial_main']=run_shape_main()
        out['expanded_once']=run_shape_main(M=1024,T=2048,dimensions=(8,16))
        out['source_stratified_precheck']=source_stratified_checks()
        out['source_stratified_pilot']=source_stratified_pilot()
    out['runtime_metadata']=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,BLAS_threads=2,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    if args.compact:out=compact_view(out)
    with open(output_path,'w') as f:json.dump(out,f,indent=None if args.compact else 2,separators=(',',':') if args.compact else None)
    print('Saved',output_path)

