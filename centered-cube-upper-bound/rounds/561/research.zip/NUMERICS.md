# 第561轮：实际计算、复现与误差账目

归档中的三份程序和结果分别对应精确联合矩、Arb形状容量以及有限完整场诊断。严格区分一般分析证明、有限有理/区间证书和浮点积分；后者仍未通过足以判定形状阶数的误差门槛。

复现（在解压目录）：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python joint_moment.py > joint_moment.reproduced.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_capacity.py > shape_capacity.reproduced.json
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_numeric.py --all --compact --output shape_numeric.reproduced.json
```

主代理实际重新执行了这三个完整命令范围。两份精确结果除耗时外逐字段相同；完整场重新生成的全部共同数学值、来源输入哈希和能量完全一致。302个旧训练带count字段现扩充为count/ESS/帽记录，count逐项相等；代码同时输出从同一场可计算的自交与帽诊断。旧本机输出另含手工汇总索引，未作为不可复现数据复制。归档JSON采用最终程序的新输出格式。最后复现峰值RSS294,240,256字节；不是原pilot170MiB的同一次运行。运行耗时、内存及实际代码哈希允许变化，数学结果未变化。

精简JSON只省略固定seed可再生的坐标和提议矩阵，保留其形状、float64字节哈希，以及全部判据/费用/ESS/跨带项。本机全量JSON继续保留。未新增PDF或缓存。



---

# R561：联合中心容量矩的有限有理探路

## 结论与范围

此指标在本组相关轴点分布中，确实比单边缘分位乘积提供额外的可测区分。最清晰的一族是：ν均匀于 n 个轴点 `(1/2)e_i`、r=1、θ=3/4。所有 n∈{4,8,16,32,64,128} 的边缘分位轮廓 P 都严格等于 1；而联合矩上界随本次有限维数增长显著下降，n=128、k=128 时给出 `7.701253655569563e−8`，真实严格高捕获中心体积为 `2.0779977134665415e−9`。

这不是一般维数阶的结论，也没有将辅助 iid 样本替代原 Gram 的真实来源。全部输出是指定有限原子概率模型的精确有理算术结果；没有 Monte Carlo、QMC、浮点求积或数值优化误差。小数只供阅读，签名证据为 JSON 中的 Fraction 字符串。

## 1. 准确矩恒等式和容量上界

对任意概率 ν、边长 r，`p(B)=νQ(B,r)`。取辅助 iid `Z_1,…,Z_k~ν`，Tonelli 与每坐标允许中心区间的交给出

`r^(−n)∫p(B)^k dB = E Π_(a=1)^n(1−[max_j Z_ja−min_j Z_ja]/r)_+`。

因此对严格高捕获集 `H_θ={B:p(B)>θ}`，

`|H_θ|/r^n ≤ θ^(−k) E Π_a(1−span_a/r)_+`。

坐标之间从未假定独立；乘积来自交盒体积，不是把 ν 的坐标期望因式分解。辅助 iid 仅用于这个中心容量恒等式。

本实验 ν 为：原点质量 t∈{0,1/2}，每个轴点 `a e_i` 质量 `(1−t)/n`，其中 a∈{1/4,1/2,3/4}。r=1；θ∈{3/4,7/8}；k∈{1,2,4,8,16,32,64,128}。没有扩展其他参数。

## 2. 精确 DP 与必须保留的同点事件

状态 `(o,d)`：o 表示是否抽过原点，d 表示出现过多少个不同轴点。初态 `(False,0)` 概率1。每一步：

- 以 t 转入 `(True,d)`；
- 以 `(1−t)d/n` 保持 `(o,d)`；
- 以 `(1−t)(n−d)/n` 转入 `(o,d+1)`。

每一步状态概率之和以 Fraction 精确断言等于1。终态的跨度乘积为：

- d=0：1（全抽原点）；
- o=False、d=1：1（全抽同一个轴点）；
- 其余：`(1−a)^d`。

**同轴同点的第二项不能漏掉。** 如果把该项也错写为 `(1−a)^d`，负误差恰为

`a (1−t)^k n^(1−k)`。

脚本对 n=4、128，t=0、1/2，k=1、2、128 的压力实例准确核这个修正。特别 k=1 的真矩恒等于1；错误公式在 t=0 时给 1−a，可能凭空制造改善。原点全抽事件另外贡献至少 `t^k`，也在压力核验中保留。

## 3. 独立真实中心几何与第二套矩公式

令 `I=[−1/2,1/2]`、`J=[a−1/2,1/2]`（长 c=1−a）、`L=[−1/2,a−1/2)`（长 a）。

当中心 B∈I^n，令 D 为落入 J 的坐标数，则恰捕获 D 个轴点，且捕获原点，所以

`p(B)=t+(1−t)D/n`。

若恰有一个坐标在右外段 `(1/2,a+1/2]`，其他坐标均在 I，只捕获匹配的那个轴点，质量 `(1−t)/n`；这类中心总体积恰为 na。两坐标在 I 外、或有坐标在 I∪[a−1/2,a+1/2] 外，不能捕获任何轴点。对于 n≥4、θ>1/2，这些外段都不是高捕获中心。

故真实严格高中心体积准确为

`V_θ=Σ_[t+(1−t)D/n>θ] binom(n,D)c^D a^(n−D)`。

严格 `>` 的阈值必须保留；JSON 另存非严格 `≥` 体积，避免原子阈值等号混淆。

同一空间划分给出完全独立的矩公式

`M_k=Σ_(D=0)^n binom(n,D)c^D a^(n−D)[t+(1−t)D/n]^k + a n[(1−t)/n]^k`。

这里外段项正是 iid DP 同点修正的空间对应。全部 n、t、a、k 的 288 项，脚本均准确断言此空间矩等于 iid distinct-count DP 矩。

此外另用 n=2,3,4 的真实坐标构造：逐一枚举每坐标 L/J/右外段，取区间内部中心，直接逐点测试是否捕获原子，再按体积相加；共36项准确等于上述高体积公式。该核验没有使用 D 公式来决定捕获质量。

## 4. P=1 的盲点与有限维数复核

使用广义分位 `q(u)=inf{x:F(x)≥u}`。每个边缘在0的质量是 `p0=1−(1−t)/n`，在 a 的质量 `(1−t)/n`；因为 `1−θ<1/2≤p0`，`q(1−θ)=0`，且当 θ≤p0 时 `q(θ)=0`。此时

`P=Π_i(1−[q_i(θ)−q_i(1−θ)])_+=1`。

脚本准确计算每个输入的 P，没有把全部网格强称 P=1：例如 t=0、n=4、θ=7/8 时 P=(1−a)^4，并非1。

主区分实例 t=0、a=1/2、θ=3/4 的准确有限结果如下。best k 仅在预设八个 k 中选择，不声称全整数最优；上界另与显然的中心容量上界1取最小。

| n | P | best k | 联合矩容量上界 | 真实严格高体积 |
|---:|---:|---:|---:|---:|
| 4 | 1 | 4 | .5493827160493827 | .0625 |
| 8 | 1 | 8 | .3180670462772443 | .03515625 |
| 16 | 1 | 16 | .11554679100842773 | .0106353759765625 |
| 32 | 1 | 32 | .015169841368122333 | .0010512007866054773 |
| 64 | 1 | 64 | .00026082534975288243 | .000012182286081466635 |
| 128 | 1 | 128 | .00000007701253655569563 | .0000000020779977134665415 |

更稀的高捕获事件也被分开：t=0、a=3/4、θ=7/8、n=128，P=1，但 k=128 的上界约 `6.417133830084064e−37`，真实体积约 `1.712670731719269e−51`。该有限例说明联合范围矩能检测分散到许多不同坐标的少量尾质量；它没有证明某个一般指数率。

## 5. 稀尾、原点团块与高矩压力

加入原点团块会真实改变容量，指标没有一律报小：t=1/2、a=1/4、θ=3/4、n=128 时，P=1，真实严格高体积约 `.9999999989500152`，预设 k 的矩上界与1取最小后仍为1。这是正确的无区分结果，不能为追求增益丢掉原点团块。

临界族 t=0、a=1/4、θ=3/4、n=128 的真实体积约 `.4661102121389204`，本次八个 k 的上界也未小于1。联合矩比边缘 P 具有额外信息，不表示它对每个 P=1 输入都能给非平凡常数。

也不能无限增大 k：对固定本模型，所有轴点同时落入盒的中心集合体积为 `c^n>0`，因而 `M_k≥c^n`，`θ^(−k)M_k≥θ^(−k)c^n→∞`。DP 的全部不同坐标占据与空间全捕获区都保留了这一高矩压力。某些有限网格 best k=128 只是碰到本次预算上端，不能宣称128以后的 k 都更好或都更差。

## 6. 实际运行、独立核验与停止点

命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python joint_moment.py > joint_moment.json
```

Python 3.12.14，全部数学运算为标准库 Fraction，无 Arb 依赖或求积器。最终单进程运行约1.82秒；未与 numeric 的主任务重复求解、未改其他文件。

- 54项小 n≤4、k≤4 的直接 iid 原子元组穷举准确等于 DP；该穷举直接计算各坐标 max−min，未用 distinct-count 捷径。
- 36项小 n 真实中心区间枚举准确等于高体积公式。
- 288项全维空间矩准确等于 DP。
- 72个完整 `(n,t,a,θ)` 记录都检查真实严格高体积不超过全部八个 k 的容量上界。
- 同点修正和原点全抽压力核验全部通过。

最终脚本 SHA256：`cf439eae663a09fa533b9eebf2b2f3361e6183c39c6d8777a181c74171b4858a`。精确输入、每个矩、每个上界和真实体积均在 JSON，所有 decimal 字段仅作显示。

新信息是：该联合指标在指定相关概率族中确实突破 P=1 的边缘盲点，同时如实显示团块和临界输入的失败区。没有一般 root 阶、没有真实 Gram 全局付款、没有原子到 L1 的定量平滑预算；到此停止。


---

# R561：方体与等体积 Euclidean 球的高捕获中心容量

## 结论及严格证据范围

对同一概率源 `ν_n=n^(−1)Σ_i δ_((1/2)e_i)`、阈值 θ=3/4，边长1方体的真实高捕获中心体积随本次维数增长很小，而体积1 Euclidean 球有一个趋于正数的明确中心体积下界。n=128 的真实 cube/ball 容量比至多 `1.22841602736e−6`；n=1024 至多 `5.07493072521e−58`。

这些数值是192位 Arb 的严格包围，球分母仅是已证**下界**。因此 JSON 的 `cube_over_ball_lower_bound_arb` 是“真 cube 容量除以解析球下界”的区间，给真 cube/真 ball 容量比的严格**上界**，不是对真容量比的双侧包围。

下文另给固定 mollification 的严格 L1 几何压力接口：方体容量仍指数小，球容量下界仍趋于同一正常数。此处对比的是高捕获中心的几何容量，不是整体 Gram、全尺度算子或目标 root 估计。

## 1. 半径归一和捕获证明的独立审计

设 n 为正偶数，m=n/2，a=1/2。体积1 Euclidean 球的半径为

`c_n=Γ(n/2+1)^(1/n)/√π`，

因为单位 Euclidean 球体积 `π^(n/2)/Γ(n/2+1)`，从而其乘 `c_n^n` 恰为1。计算中等价使用

`c_n²=exp(log(m!)/m)/π`，

m! 是准确整数，没有 Gamma 求积或近似 Stirling 替代有限数据。

定义 `t_n=2c_n/√n`，`R_n²=c_n²−a²−2a t_n`。假定 R_n²>0。对任意中心 B 满足 |B|<R_n，若坐标 `B_i≥−t_n`，则

`|B−a e_i|²=|B|²+a²−2aB_i <R_n²+a²+2a t_n=c_n²`。

所以对应轴点严格落在球 `B+c_n B_2` 内。坏坐标 `B_i<−t_n` 每个对 |B|² 贡献严格大于 t_n²，故其数目 b 满足

`b≤|B|²/t_n²<R_n²/t_n²<c_n²/t_n²=n/4`。当 b>0 时首项也可严格；b=0、B=0 时保留非严格首项。

好坐标数严格大于3n/4，捕获质量严格大于3/4。由此整个中心 Euclidean 开球半径 R_n 都属于高捕获集，体积为

`L_n=(R_n/c_n)^n=[1−a²/c_n²−4a/(c_n√n)]^(n/2)`。

开闭中心球边界为 Lebesgue 零测，不影响体积下界。这里没有把每坐标独立，也没有使用随机中心的集中近似。

方体 side1 的真实严格高体积已独立几何计数为

`V_n=Pr{Bin(n,1/2)>3n/4}=2^(−n)Σ_(d>3n/4)binom(n,d)`。

本脚本再次用准确整数求和生成 V_n。严格 `>` 与题设一致，不把阈值等号质量加入。

## 2. 仅指定七个维数的严格有限计算

全部 R_n² 以 Arb 比较严格为正，无无效项。下表给区间的可读中心值；完整192位区间和精确有理端点见 JSON，表中舍入数不单独充当外包界。

| n | 方体真实容量 V_n | 球容量下界 L_n | 解析商 V_n/L_n |
|---:|---:|---:|---:|
| 16 | .0106353759765625 | .00015706049545965818 | 67.71515615964838 |
| 32 | .0010512007866054773 | .00087979059551709849 | 1.1948306698909781 |
| 64 | .000012182286081466635 | .0014184396997139668 | .0085885117879337655 |
| 128 | 2.0779977134665416e−9 | .0016916074580485614 | 1.2284160273588059e−6 |
| 256 | 8.0389576943057922e−17 | .0018143418303250788 | 4.4307845191804006e−14 |
| 512 | 1.6452466690792985e−31 | .0018661057384204731 | 8.8164707669345886e−29 |
| 1024 | 9.5751481669438648e−61 | .0018867544574346728 | 5.0749307252003117e−58 |

n=16、32 的商上界大于1，这个下界本身没有证明球的容量大于方体。n≥64 的指定有限数据已经严格区分二者：真实球容量至少大于所列球下界，而方体容量已精确计算。

例如 n=128：

`V_n/L_n=[1.228416027358805850859861435896973328057187499183796342e−6 +/-5.71e−61]`。

n=1024：

`V_n/L_n=[5.0749307252003116961334306769780991621869096632121391e−58 +/-2.95e−111]`。

JSON 同时保存该解析商区间的准确有理 lower/upper，以及直接可用的真容量比上界 `actual_cube_over_actual_ball_capacity_upper_exact`。这些端点由 Arb 的准确 dyadic endpoint 转成 fmpq，没有以十进制显示舍入替代端点。

## 3. 正极限由 Stirling 证明，不能由七点数据推断

Stirling 给出 `c_n²=[n/(2πe)](1+o(1))`。令

`u_n=a²/c_n²+4a/(c_n√n)=O(1/n)`，

则 `log L_n=(n/2)log(1−u_n)=−(n/2)u_n+o(1)`，从而

`L_n→L_*=exp(−πe a²−2a√(2πe))>0`。

a=1/2 时，另以 Arb192 计算这个解析极限表达式：

`[.0018966522704923645391274694194726665537652891536658929053 +/-4.54e−59]`。

这是用 Stirling 加 Taylor 得到的极限结论，七个有限数据只核对趋势，没有作为渐近证明。

## 4. 固定 L1 mollification：只迁移几何容量

按主代理指定，取 `δ_n=n^(−2)`，将每轴点均匀抹在 ∞ 半径 δ_n 的小方体上：

`f_n(x)=n^(−1)Σ_i (2δ_n)^(−n) 1_(a e_i+[-δ_n,δ_n]^n)(x)`。

这是非负 L1 密度，积分准确等于1。无需假定不同小方体互不重叠即可得到以下逐团质量比较。

### 方体上界

若 side1 方体捕获某团的任意正质量，该团中心 a e_i 必落在同中心、边长 `L=1+2δ_n` 的扩大方体中。因此逐中心有

`∫_(Q(B,1)) f_n ≤ ν_n Q(B,L)`，

从而严格高集包含关系成立。按上一节的准确方体几何缩放，

`|{B:∫_(Q(B,1))f_n>3/4}| ≤ L^n Pr{Bin(n,1−a/L)>3n/4}`。

这不是把 mollified 源当作依然离散，而是用扩大盒逐团作上界。用 Chernoff 参数 ln3，令 p=1−a/L，得

`Pr{Bin(n,p)>3n/4} ≤ [(1+2p)/3^(3/4)]^n`，

所以 a=1/2 时整个中心体积不超过

`[(3L−1)/3^(3/4)]^n`。

对所有 n≥16，`L≤129/128`，故 `3L−1≤259/128`。准确有理比较 `(259/128)^4<27` 证明统一底数 `(259/128)/3^(3/4)<1`。因此这组真正 L1 源的方体高容量仍有严格指数上界，不依赖有限维表格猜测。

### 球下界

每团相对其原子中心的 Euclidean 半径至多

`ρ_n=√n δ_n=n^(−3/2)`。

保持 `t_n=2c_n/√n`，改取

`R_(ε,n)²=(c_n−ρ_n)²−a²−2a t_n`。

在 `c_n>ρ_n`、`R_(ε,n)²>0` 时，若 |B|<R_(ε,n) 且 `B_i≥−t_n`，同样的平方距离估计给 `|B−a e_i|<c_n−ρ_n`；三角不等式保证该团的**整个**小方体都严格进入半径 c_n 的球。坏坐标数仍严格小于 n/4，因为 `R_(ε,n)²<c_n²`。所以球捕获的完整团数大于3n/4，且

`|{B:∫_(B+c_nB_2)f_n>3/4}| ≥(R_(ε,n)/c_n)^n`。

Stirling 给 `c_n≈const·√n`，从而 `nρ_n/c_n=O(1/n)→0`；相对于原 L_n 的对数修正趋于0。因此这个球下界对充分大 n 合法，并仍趋于同一正数 L_*。本次没有新增 smoothed 有限参数扫描，也不把该极限措辞误读为已逐项计算所有小 n 的 R_(ε,n)²。

这证明了一组总质量1的真实 L1 密度上，方体与等体积球的高捕获中心容量可以强烈不同。它不能直接比较两个 maximal operator 的弱型常数，也不能补齐真实 Gram 的来源、相位、首次进入或旧信用预算；那些都不是本几何容量命题。

## 5. 实际运行与复现

命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_capacity.py > shape_capacity.json
```

Python 3.12.14、python-flint0.9.0、Arb192 bits。单进程内部耗时约 `.00574` 秒；只运行 n=16,32,64,128,256,512,1024。cube 值为准确 Fraction，球量及其比值为 Arb 包围；没有浮点积分或 Monte Carlo。脚本还以 Fraction 核验 L1 Chernoff 底数的四次幂小于1。

脚本 SHA256：`afa6f26b3593c266b35c7580ca7778729f69f40ae5ac00f27fbdb376e031c545`。

仅新增本任务三个独占文件，没有修改 joint_moment 三文件、numeric 作者文件或 repo；未编译PDF。完成后停止。


---

# R561 finite-source cube versus ball diagnostic

Owner g558_numeric_sol. Only `shape_numeric.py`, `.json`, `.md` were edited; R560 files/repo/other-role files were not changed. No PDF compiled.

**Current outcome:** the complete finite model produces different cube/ball fields and branch costs, but the current sampling does not establish a reliable cost ordering or any polynomial separation. Source-level dilution remains substantial: training fields exceed their known cap, some estimated alpha exceed1, and evaluation self energies differ greatly from independent-batch cross energies. No alpha was clipped. These are unresolved numerical integration errors, not geometric counterexamples or proof failures. One expansion was completed, then sampling stopped. The subsequent sole authorized n16 source-stratified pair is reported at the end: it completed in4.53s with no cap/alpha violations, but source-band ESS and cross/self gaps remain insufficient for a geometric conclusion.

## Frozen inputs, proposal and costs

For n4,8,16 each source has64 atoms of equal mass1/64, total W=1. Product cloud: uniform points in[-.5,.5]^n. Strongly correlated cloud: t·(1,…,1)+.02U, t uniform[-.5,.5], U uniform[-.5,.5]^n. Source seed56100+n. All actual atom coordinates are retained. Cube has unit side, ball radius c_n=Gamma(n/2+1)^(1/n)/sqrt(pi), so both scaled bodies have volume R^n. Their entry radii are2||y−B||∞ and||y−B||2/c_n.

Parent froze a=.5,b=1, so A_n=1+nln2 remains dimension-dependent; it was not replaced by a constant-volume window. Original R grid is .5+.5k/32,k0…32. Select maximum true source density across all33 points, ties smallest R. Every positive selected density q0 is retained in its unique dyadic band k=floor(log2q0),q=2^k; effectively bands are[q,2q), with lambda_band=2q and C=1+ln4. No favorable band is selected, and no sparse band is dropped. G2/4, gamma2,h1/8 are fixed.

The shared center proposal first picks a source atom uniformly, then cube/ball each half; within that body it picks b-uniform with probability1/2 or log-uniform R∈[a,b] followed by uniform-in-body(R) with probability1/2. For body K and rho_K(B−y),

    p_K(B)=mu K(B,b)/(2b^n)
      + mean_y[(max(a,rho_K(B−y))^(−n)−b^(−n))_+]/[2nln(b/a)],
    p(B)=(p_cube(B)+p_ball(B))/2.

Each sampled center has actual Lebesgue weight1/(M p(B)), not uniform-center weight1/M. Both shapes use exactly the same sampled centers and proposal. The density uses every one of the64 real atoms. Each mixture component is normalized by its actual body volume; direct integration over R gives integral p=1. It covers every contributing old/candidate body with scale≤b. Original top screening remains after alpha/low/rapid, so no original parent is pretruncated to manufacture bulk.

Main seeds: training56141+n; independent evaluations56151+n and56161+n. Main initial T256 plus two M256 evaluations for every n/cloud. One expansion only, n8/16 and both clouds, T2048 plus two M1024 evaluations. No new atoms, G, band selection or dimensions were introduced. All actual centers and their proposal densities are frozen in the JSON, as well as RNG seeds.

## Complete finite-source fields and alpha

The periodic q_new shortcut is **not** used. Every real source y has a separate field. Its parent/action coefficient is R_B^(−n)/g times actual source membership, and energy is

    (1/64)sum_y sum_(band,j) integral A_(y,band,j)(sigma)^2 d sigma.

The complete parent-pair Gram at the same real source is retained by an endpoint sweep. The source integral is a sum of source-wise squares, not a square after averaging sources. This is the actual atomic Hilbert space; no cross-parent terms at a fixed source are deleted.

For each band, the training old field L_(y,k) includes **all** original parents in that band before deletion. With count0 old source atoms, alpha_B is

    alpha_B = [sum_(y in oldbody) integral_[log2(count0/64),+1] L_(y,k)]/(C count0).

This equals the full mother definition because equal atomic weights cancel against m0=count0/64. Alpha is one fixed training-field function queried at every evaluation parent. It is never recomputed from bulk or replaced by a global scalar old field. Ordered low/rapid/top/bulk and their equality rules are the same as R560. Untrained bands get zero empirical training field but are explicitly flagged: their resulting low classification is **not** an exact mother-alpha certificate.

All64 source-entry radii are enumerated for every candidate parent; their volume dilations g=(entry/R)^n define the true open mass plateaux. Membership and count are constant on each plateau. Endpoint g1/G atoms are separately counted using closed membership. Integer comparisons of(count/count0)^8 give exact phase labels conditional on the computed geometric counts. Windows use log2(count/64), never density or logg.

On(l,u) with kappa=count/count0 and amplitude w_B/R_B^n, each receiving source's integrated coefficient is:

| law | plateau coefficient | initial atom | end atom |
|---|---|---|---|
| common | amplitude(1/l−1/u)/(1+lnG) |none|amplitude/[G(1+lnG)]|
| two | amplitude(1/l−1/u)/(2+lnG)|amplitude/(2+lnG)|amplitude/[G(2+lnG)]|
| adaptive | amplitude ln(u/l)/(kappa N)|amplitude/N|amplitude/(kappa_G N)|

Membership at the appropriate source/plateau/endpoint multiplies every coefficient. N=1+sum(u−l)/kappa+G/kappa_G, I=1+sum ln(u/l)/kappa+1/kappa_G. Restored fields divide each parent's complete coefficients by its own eta: common1/(1+lnG),two2/(2+lnG),adaptive I/N **before** summing centers and taking the Gram.

The JSON reports both band-diagonal energy and the actual field summed across bands, with its full additional cross-band Gram. No aggregate comparison silently omits cross-band cost. It also retains old_all, old_bulk, all four branch center volumes/ESS/q0 masses/old prices, and symmetric old-branch Gram attributions. The old-score price uses the frozen training alpha, not a post-deletion field.

## Three stages actually run and normalization pressure

1. Geometry/proposal calibration: direct mass-platform membership checks, unit-ball-volume computation, and4096 shared scale-mixture centers per n/cloud for known identity integral mu K_R/R^n=1,R=.5/1. Runtime.187s; n4 estimates .993–1.022, n8 .918–1.023, n16 .884–1.061 with reported standard errors up to .090. The small-scale high-n error is retained. This is importance-MC validation, not a rigorous normalization interval. The earlier b-only proposal test is also saved but is not used for the main comparison.
2. Initial real product/thin-diagonal comparison T=M256:1.52s total. n4 has mostly0–3 bulk parents per batch, which is a sampling gap; it was not interpreted as no geometric distinction. Exact known-null pressure additionally uses64 coincident atoms (mu=delta0), only as an analytic calibration. For any unit-volume body, shell volumes between fixed grid scales are R_i^n−R_(i−1)^n. True mass/phase remain flat, and all three restored fields equal the old bulk field. Thus both bodies must agree on this calibration. At n4/8/16,G2 the band-diagonal known-null restored costs are1.83722/3.76713/6.22150; full-band costs5.26241/28.48352/92.93469. This is a genuine shape-blind sector of these costs, not an impossibility result for other sources.
3. One expanded comparison T2048,M1024, n8/16, both real clouds:6.20s total. It preserves every band and every source. Largest observed RSS161,693,696 bytes(~154MiB), one main process, BLAS/OMP/MKL threads≤2. No further sampling was performed.

Interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`; Python3.12.14, NumPy2.5.4, SciPy1.18.1. Reproduce the delivered calibrations/main/one expansion:

    OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_numeric.py --all

Default runs calibration/known-null only and overwrites the JSON with that subset. The delivered full JSON includes initial and expanded inputs/results. Derived numerical checks: branch Gram attributions sum to old_all within4.45e−15; constant-eta restoration identities hold within4.00e−15. Floating geometric comparisons and MC training labels remain uncertified.

## Expanded complete-field costs

All numbers are independent evaluation-batch cross energies per W=1. These are numerical estimates conditional on the frozen empirical training field, not certified mother-alpha costs.

|n|cloud|shape|G|raw common|raw two|raw ad|Ceta common|Ceta two|Ceta ad|
|---:|---|---|---:|---:|---:|---:|---:|---:|---:|
|8|product|cube|2|0.4828901|0.768566|0.6330863|1.384324|1.39361|1.394235|
|8|product|cube|4|0.2076518|0.4228917|0.21988|1.182452|1.212324|1.20188|
|8|product|ball|2|0.459411|0.7292191|0.6003648|1.317015|1.322264|1.322717|
|8|product|ball|4|0.1818436|0.3739352|0.1946123|1.03549|1.071978|1.058125|
|8|diagonal|cube|2|0.0008319801|0.002044514|0.001662764|0.002385077|0.003707237|0.00341009|
|8|diagonal|cube|4|1.927204e-05|7.338239e-05|2.916744e-05|0.0001097427|0.0002103688|0.0001515332|
|8|diagonal|ball|2|0.004957892|0.009692422|0.007522901|0.01421303|0.01757489|0.01588425|
|8|diagonal|ball|4|0.0003365205|0.00112585|0.0004629918|0.001916283|0.003227529|0.002354452|
|16|product|cube|2|1.282121|2.027881|1.667116|3.675516|3.677076|3.6772|
|16|product|cube|4|0.5580742|1.108687|0.5694905|3.177898|3.178324|3.178158|
|16|product|ball|2|1.238571|1.959327|1.610845|3.550671|3.552771|3.552933|
|16|product|ball|4|0.5580102|1.111369|0.5715106|3.177533|3.186015|3.182565|
|16|diagonal|cube|2|0.04444503|0.08968365|0.07191315|0.1274127|0.1626198|0.1541351|
|16|diagonal|cube|4|0.008239509|0.0240993|0.01177266|0.04691907|0.06908659|0.05455995|
|16|diagonal|ball|2|0.06391839|0.1417665|0.1083528|0.1832379|0.2570595|0.2271127|
|16|diagonal|ball|4|0.01870377|0.05893673|0.02543746|0.1065068|0.1689567|0.1218784|

The following table restores every cross-band term for the physical summed field; the fee is aggregate minus band-diagonal energy. It is a different quantity from the original band-indexed Hilbert sum, so both are shown.

|n|cloud|shape|G|common Ceta aggregate|common cross-band fee|two Ceta aggregate|ad Ceta aggregate|
|---:|---|---|---:|---:|---:|---:|---:|
|8|product|cube|2|5.453362|4.069038|5.474068|5.475661|
|8|product|cube|4|4.33948|3.157028|4.426062|4.39404|
|8|product|ball|2|4.545054|3.228038|4.554048|4.554785|
|8|product|ball|4|3.162766|2.127276|3.240034|3.21034|
|8|diagonal|cube|2|0.002396289|1.12119e-05|0.003739771|0.00343909|
|8|diagonal|cube|4|0.0001097427|0|0.0002103688|0.0001515332|
|8|diagonal|ball|2|0.0156794|0.001466371|0.01893821|0.01717807|
|8|diagonal|ball|4|0.001916283|-2.168404e-19|0.003227529|0.002354452|
|16|product|cube|2|38.91342|35.23791|38.92529|38.92623|
|16|product|cube|4|30.81474|27.63685|30.85323|30.83804|
|16|product|ball|2|35.93474|32.38407|35.96664|35.96916|
|16|product|ball|4|29.15435|25.97682|29.22831|29.19928|
|16|diagonal|cube|2|1.176311|1.048898|1.423948|1.360443|
|16|diagonal|cube|4|0.3428127|0.2958936|0.4719396|0.3877136|
|16|diagonal|ball|2|1.31119|1.127952|1.990741|1.744739|
|16|diagonal|ball|4|0.5091776|0.4026708|0.8812284|0.6265804|

## Numerical error and branch-price ledger

No band was dropped. Initial n4 bulk counts were mostly0–3 and were not enlarged. Expanded product clouds have many true-flat parents: for n16,G2 cube412/414 and443/443, ball420/427 and441/441; equality of restored selectors in that sector is expected and does not establish geometric indistinguishability elsewhere. Strong-diagonal sources produce fewer flat parents and visibly different candidate fields, but the sampling error prevents a reliable shape-ordering conclusion.

|n|cloud|shape|G|bulk counts (batches)|flat bulk counts|common cross Ceta|common self Ceta (batches)|
|---:|---|---|---:|---|---|---:|---|
|8|product|cube|2|314/310|312/307|1.384324|2.50456/2.680557|
|8|product|ball|2|293/315|289/312|1.317015|2.39992/2.399157|
|8|diagonal|cube|2|5/7|1/4|0.002385077|0.003921649/0.008068243|
|8|diagonal|ball|2|18/18|4/6|0.01421303|0.01730028/0.02324581|
|16|product|cube|2|414/443|412/443|3.675516|12.87966/13.07913|
|16|product|ball|2|427/441|420/441|3.550671|11.86055/11.84941|
|16|diagonal|cube|2|179/153|80/70|0.1274127|0.4889681/0.6312226|
|16|diagonal|ball|2|243/214|30/20|0.1832379|0.5312084/0.5174351|

The self-versus-cross gaps are large and source-localized; two cross batches alone do not provide a reliable confidence interval. They cannot be interpreted as dimension growth or polynomial cube/ball separation. Training max source-field values are especially diagnostic: C=2.386294, whereas n16 product maxima are5.00163(cube),3.88316(ball), and evaluation alpha reaches2.09598/1.45238. Those violations are numerical integration errors, not allowed geometric values. No clipping to[0,1] was applied.

|n|cloud|shape|observed dyadic k range|training bands|untrained eval count (batches)|low-training eval count|alpha>1 count|training max L|
|---:|---|---|---|---:|---|---|---|---:|
|8|product|cube|-6…3|11|0/0|0/0|7/4|2.6041|
|8|product|ball|-6…3|11|0/0|0/0|0/0|2.3371|
|8|diagonal|cube|-6…6|13|0/0|0/0|0/0|0.936297|
|8|diagonal|ball|-6…6|13|0/0|0/0|0/0|0.918406|
|16|product|cube|-6…10|17|0/0|0/0|13/10|5.00163|
|16|product|ball|-6…10|17|0/0|0/0|19/14|3.88316|
|16|diagonal|cube|-6…14|20|0/1|0/1|0/0|1.75136|
|16|diagonal|ball|-6…14|21|0/0|1/4|0/0|1.29275|

Per-band training center counts/weight ESS, bulk weight ESS, center volumes, q0 masses, old-score prices and every deletion share are retained in JSON rather than collapsed into one global favorable band. An untrained or low-sample band remains in the uncertainty ledger; it is never silently merged with a neighboring band. Branch scores use the original training L, and their field attribution sums to the full old energy. Neither the scores nor restored costs settle the mother budget while alpha remains an uncertain integral estimate.

## Proposed next integration method: source stratification — design only

The parent requested a design, **not** a new expanded run. The following method changes numerical integration only; it does not change any selector, body, source, band, window, phase, endpoint, Gram term or recovery factor.

For each of the64 actual sources y separately, use the same four-component normalized proposal centered at y:

    p_y(B)=(p_(y,cube)(B)+p_(y,ball)(B))/2,
    p_(y,K)(B)=1_{rho_K(B−y)≤b}/(2b^n)
      +[max(a,rho_K(B−y))^(−n)−b^(−n)]_+/(2nln(b/a)).

This is a numerical integration proposal for A_y, not a source-dependent action law. It covers the entire contribution to old L_y and every legal bulk candidate F_(B,y), because old scale≤b and bulk candidates have new scale≤b. It needs no conditional truncation to favorable centers, density bands or plateaux. Its normalization is the same exact volume/scale-mixture identity already checked.

### One selector for all source integrations

1. For each y, independent source-centered training samples estimate **all** band functions L_(y,k)(sigma) with weights1/(T_y p_y(B)). Every sampled parent still obtains R_K(B) by the unchanged full33-point search using all64 source atoms. Its source mass and band are calculated from the complete mu. The target y only specifies which component of the old field is being integrated.
2. Freeze the entire resulting vector field {Lhat_(z,k):every real z, every band}. Store exact piecewise-window primitives in sigma. There is no spatial interpolation: the source Hilbert space has exactly64 atoms. A parent with count c0 queries this single frozen vector via

       alphahat_B = sum_(z in oldbody) integral_[log2(c0/64),+1] Lhat_(z,k)/(C c0).

   It is never replaced by only the target-source term, a source average taken before squaring, or an independently refitted alpha for that target.
3. Define one `selector(shape,B,mu,frozen_training)` with **no target-y argument**. It computes the same old R_B, band, alphahat_B, ordered deletions, all64 source-entry jumps, all actual mass plateaux, phases, N,I,eta and pi_B. The same B evaluated in any source integration therefore gives the same pi_B and the same bulk label. A cache, if useful, is keyed by(shape,B coordinates,frozen-training version), never by target source.
4. For each y, two independent evaluation batches from p_y integrate that one selector's source component with weights1/(M_y p_y). Keep every actual window/phase and divide by each actual parent's eta before aggregation. Then calculate the complete source-wise cross energy and sum with the actual source masses1/64:

       Ceta_cross=(1/64)sum_y sum_(k,j) integral Ahat_y^(1) Ahat_y^(2).

   All parent pairs at the same y remain. The Hilbert source integral itself has no y≠z products, so summing source-wise energies is exact; it is not deletion of a parent Gram term. Across-band complete fields and their additional fee are still reported separately.

Changing the evaluation points by source is legitimate importance integration of the **same** source-before-action selector. It would become a different, unauthorized law if R,alpha,bulk or pi were recomputed from only the target source or if target-dependent training selected actions; the proposed interface prevents both.

### Deterministic weight control and finite training queries

Let H=nln(b/a)=nln2≥1. If y is inside a body of scale R∈[a,b], set x=(b/R)^n. The matching body component gives

    p_y(B)≥[b^(−n)+(R^(−n)−b^(−n))/H]/4,
    R^(−n)/p_y(B)≤4H x/(H+x−1)≤4H.

This remains valid for every action's new scale when y is a receiver. Before recovery, each pointwise source-field importance contribution is bounded by4H because pi_B has total mass1; after recovery a safe bound is4H/eta_min(G). It is not necessary to remove any action or source to get this bound. For the current global proposal p=sum_z mu_z p_z, the generic corresponding bound is64·4H. This removes that dilution factor from the deterministic bound; it does **not** promise a universal64-fold variance reduction.

The bound4H is11.09035,22.18071,44.36142 for n4,8,16. A local exact SymPy1.14.0 check using the specified Python verified derivative of4Hx/(H+x−1) is4H(H−1)/(H+x−1)^2 and the gap4H−f is4H(H−1)/(H+x−1). This was one lightweight algebra check, not another geometric batch.

Masses are count/64 with count1…64, so old mass-window query positions belong to a fixed finite set. Each source/band alpha primitive can be represented by its64 unit-window integrals; the old full field can still be retained for energy. If every such training integral has error≤delta, then every alpha_B has error≤delta/C: its source average introduces no extra count or source-mass factor. Actual bounded-importance empirical variances can guide a simultaneous finite-family error budget. A crude Hoeffding/Bernstein bound may be too loose; it should be reported rather than hidden. Alpha must not be clipped to1, nor classified as certainly low merely because a source-band had no training samples.

### Cost and decision gate

A bounded first pilot could use T_y256 and two M_y128 batches per source, for one n16 strongly correlated input and both shapes on shared per-source centers. Total32,768 center evaluations per configuration, versus4,096 in the current global-mixture expansion:8 times as many points, while each resulting field update addresses one receiver instead of scattering to all64. Every point still counts all64 source atoms and searches all33 radii. Based on the measured1–3s/configuration global runs, an initial planning range is10–50s/configuration; this is an estimate, not a timed result. Source/block streaming should keep memory below roughly500MiB, though the actual peak must be measured.

The pilot should report source×band training counts and weighted ESS, true training L cap violations, source-window error/variance, alpha-threshold margins and label changes under independently enlarged training on fixed evaluation points, plus two independent complete-field cross energies. Geometry ordering should be assessed only after those diagnostics improve. Sparse bands remain in the ledger. The next sample allocation should follow measured variances, not a blind dimension scan or selection of favorable q bands.

No source-stratified field run was performed. The current finite data are saved as a sampling-limited diagnostic, and no claim about polynomial cube-versus-ball distinction or a general L1 estimate follows. Work is stopped pending the parent's investment decision.

## Subsequently authorized source-stratified pilot — executed once

After the design-only stop, the parent authorized exactly one paired configuration: n16 thin-diagonal source, both bodies, a.5,b1,G2, all density bands, T_y256 and two M_y128 batches for every one of64 sources. No other source-stratified configuration was run. The following section supersedes the earlier design-only status for this one pair only.

Code was frozen before checks/run at SHA256 `5b4b71d46a1e30fd729a99f2ea24cd67b6ea907a3080c7fba97142d790dc2c00`. A64-point geometric precheck gave maximum old importance39.96990(cube),41.32057(ball), below the proved4H=44.36142. All64 source training fields for both bodies were then built and frozen **before** any evaluation. The selector signature was checked32 times on identical B with a7-fold change in the pure integration weight: old R,band,count,alpha,deletion label,N,I and all plateau phases were identical. There is no target-source parameter in the selector. Target source only selects the field component being integrated.

The actual paired run took4.528s, including.765s training; largest observed RSS177,995,776 bytes(~170MiB). Maximum actual raw action importance44.34049 remained below44.36142. This run used32,768 centers in total, with all64 true atoms counted at each center and all true plateaux/endpoints preserved. No alpha was clipped.

Training cap check: C=2.386294; source/band maximum L was1.260070(cube),1.289386(ball), with **zero** cap violations. This is a useful diagnostic, not a proof that training error is small. Both shapes still have low source×band ESS and some absent training components.

|shape|source-band cells with training receivers|positive ESS 10%|median ESS|90% ESS|max ESS|observed parent-bands with zero training receivers|
|---|---:|---:|---:|---:|---:|---:|
|cube|1224|1.696|4.157|11.47|26.21|45|
|ball|1230|1.888|4.727|13.74|36.28|49|

ESS here uses the actual training importance amplitude R^(−n)/p_y at a receiving source, not an unweighted parent count. All per-source/band counts and ESS remain in JSON. Evaluation alpha queries that required at least one empirically untrained old-source/band were295/7485 and295/7486 for cube,152/6904 and167/6929 for ball. Their balanced parent-center volumes were.55646/.30787(out of14.34147/13.39521) and.32456/.31741(out of6.90963/6.96857). Those labels remain uncertain, not automatically valid low-price deletions.

### Full cross, self and cross-band costs

Every entry below preserves all same-source parent pairs. Independent-batch cross is the main reported estimator. “Aggregate” additionally merges density bands and includes their complete extra Gram. Restored fields are divided by each parent's actual eta before aggregation.

|shape|field|band-diagonal cross|batch1 self|batch2 self|all-band cross|extra cross-band fee|
|---|---|---:|---:|---:|---:|---:|
|cube|old_all|1.2438913|2.1832547|2.2712823|18.725832|17.481941|
|cube|old_bulk|0.32631217|0.5187999|0.72582123|2.4213906|2.0950784|
|cube|common|0.068427562|0.14595797|0.18458719|0.53939722|0.47096965|
|cube|two|0.13213426|0.22443381|0.30078926|1.0242293|0.89209501|
|cube|adaptive|0.10653137|0.18632441|0.24739205|0.82800452|0.72147315|
|cube|common_eta|0.19616453|0.41842463|0.52916483|1.5463156|1.350151|
|cube|two_eta|0.23959383|0.40695694|0.54540926|1.8571944|1.6176006|
|cube|adaptive_eta|0.22824614|0.39877321|0.52982013|1.7811547|1.5529086|
|ball|old_all|1.5597587|2.5258259|2.6366274|23.377917|21.818158|
|ball|old_bulk|0.44572361|0.79935968|0.83897528|3.2892105|2.8434869|
|ball|common|0.057097966|0.16243848|0.16752501|0.37109437|0.3139964|
|ball|two|0.12930371|0.25406577|0.26243783|0.89954357|0.77023986|
|ball|adaptive|0.099015952|0.20769401|0.2118185|0.6781711|0.57915514|
|ball|common_eta|0.16368545|0.46567008|0.48025189|1.0638338|0.90014836|
|ball|two_eta|0.2344613|0.4606874|0.47586813|1.6311068|1.3966455|
|ball|adaptive_eta|0.20796629|0.43607355|0.44527721|1.4207261|1.2127598|

The self/cross gaps remain substantial: for restored common, cube cross.19616 versus self.41842/.52916, ball cross.16369 versus self.46567/.48025. The corresponding full-band cross costs are1.54632 and1.06383, with additional cross-band costs1.35015 and.90015. It would be incorrect either to ignore those fees or to interpret the observed shape ordering as a reliable geometric conclusion. The ordering also differs from the earlier global-mixture training/estimation run, underscoring unresolved numerical/training effects. No claim about polynomial separation is made.

Actual adaptive eta across bulk-parent queries ranges.673287–.762529(cube),.673287–.733194(ball). The common/two constant-eta identities hold within2.23e−16, and old deletion Gram attributions sum to the full old energy within2.00e−15. All raw and restored per-band values remain available.

### Parent-center prices are not sampled with an invalid conditional weight

Source-specific fields correctly use1/(M_y p_y). A source-independent parent price H(B), however, cannot use that weight and then average over target y without accounting for different supports. The branch center volumes/q0 masses/old-score prices therefore use the balanced mixture identity

    sum_y (1/64) integral p_y(B) H(B)/p_global(B) dB = integral H(B)dB.

Their sample weight is1/(64 M_y p_global). This is the same complete mu-mixture density as before, evaluated on the stratified samples. It prevents undercounting branch payments whose parent does not contain the current target source. Source-field Gram attributions remain source-wise and do not use this parent-price replacement.

|shape|batch|branch|balanced center volume|q0 mass|frozen-training old-score price|
|---|---:|---|---:|---:|---:|
|cube|1|low|10.36463|3.618075|0.4541682|
|cube|1|rapid|2.258717|0.9941579|0.2337103|
|cube|1|top|0.8964851|0.04656746|0.01245367|
|cube|1|bulk|0.8216412|1.412764|0.4860545|
|cube|2|low|9.429333|3.587956|0.4454491|
|cube|2|rapid|2.244906|0.9894132|0.2334907|
|cube|2|top|0.7935081|0.04844913|0.01284081|
|cube|2|bulk|0.9274673|1.50205|0.5205281|
|ball|1|low|3.274844|1.934008|0.2825401|
|ball|1|rapid|2.17502|2.244789|0.5400646|
|ball|1|top|0.7382414|0.1126738|0.03178214|
|ball|1|bulk|0.721523|2.228338|0.7408497|
|ball|2|low|3.525949|1.981157|0.2888866|
|ball|2|rapid|2.042283|2.283116|0.5483492|
|ball|2|top|0.7006105|0.1182185|0.03321486|
|ball|2|bulk|0.6997286|2.226319|0.7349143|

Source/band branch counts additionally distinguish all evaluated parents from those actually receiving the target at the terminal scale. Thus no missing source membership or parent payment is hidden in a global count. The full trained vector field, actual coordinates, proposal densities, seeds, cap checks, per-source/band ESS, all-band fees and code hash are saved. No new configuration or larger sample follows this pair. The remaining error target is reliable finite-family training/source integration and threshold-margin control, not deletion of model terms.

Reproduce only this authorized pair, to a chosen path (it starts a new result object if the path does not exist):

    OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_numeric.py --source-pilot --output ./r561_reproduced.json

`--all` now includes the calibrations, initial/one-expanded global comparisons and this sole source-stratified pair. No additional source-stratified dimensions or parameter scan are performed.

## Final archive view and freeze

The complete local JSON is retained (~41.2MB,39.3MiB); no fourth file was created. The compact archive view omits **only** seed-rebuildable input matrices: atom coordinates, sampled center points, their proposal densities, source-centered p_y and balanced p_global arrays. Each omitted array is replaced by its shape,dtype and canonical float64 SHA256. Source-cloud/model parameters, n/M/T, all source/sample seeds and runtime versions remain, so the exact inputs can be regenerated and checked on the recorded environment.

All mathematical decisions and measured data remain: every per-band/source count and ESS, cap/alpha uncertainty, parent deletion prices, endpoint/phase-dependent complete energies, raw/actual-eta restoration, self/cross results, and complete cross-band fee. Equality checks confirmed the compact view preserves the entire source-pilot results, training-cap and training-ledger structures exactly. Estimated size is5.11MB minified (10.56MB pretty-printed), with no expensive computation repeated to obtain it.

The script now accepts `--output PATH` and `--compact`; it writes minified JSON only when compact is requested. From an archive directory:

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python shape_numeric.py --all --compact --output ./r561.reproduced.json

`--source-pilot --output ./pilot.json --compact` reproduces only the already authorized single pair. `compact_view(existing_result)` can also generate a pure archive view in memory without rerunning any model. The latest delivered code SHA256 is `30bfa309a7c9d43f1e9ad34de860c5b1f8a9a07dcd99fe73a721ed5be942f63d`; the earlier SHA stored in the pilot identifies the actual numerical run before CLI/archive-only additions. The selector and field formulas were not changed by those additions.

The authorized paired pilot is complete. No further experiments, dimensions, sample expansions or geometric conclusions are pending from this agent.
