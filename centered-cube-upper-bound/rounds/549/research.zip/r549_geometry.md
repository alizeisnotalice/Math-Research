# R549：真实共同根可逆链与平台成员能量检查点

**结论：未获得新的全局几何预算，未证明目标收缩。** 本轮建立并核验了保留实际根标签的完整共同源表达，区分了标量净流和平台内成员更换。所得能量恒等式没有降低原未付主量，不能作为一般弱型常数的新上界。当前有界结束，不继续扩展局部核或谱工具。

仅使用原最外等高根合同、R545 平方捕获付款、R548 全根归一化桥和标准积分恒等式。本代理只写本文件，没有改其他文件、没有启子代理。

## 1. 合同与真实标记边测度

沿用

\[
\mu=f\,dx,\quad E=\{M_\square f>\lambda\},\quad
\mu(Q_B)=\lambda V_B,\quad V_B=R_B^n,
\]

并保留每个 \(B\) 的最外根条件及原 \(K_+\)。令

\[
D(x)=\int_E1_{Q_B}(x)V_B^{-1}\,dB,\quad
X=\int D\,d\mu=\lambda|E|,\quad
A=\int D^2\,d\mu<\infty.
\]

定义有限测度 \(\pi(dx)=D(x)\mu(dx)\)，总质量为 \(X\)。在 \(D>0\) 上定义

\[
K(x,y)=\int_E\frac{1_{Q_C}(x)1_{Q_C}(y)}{\lambda V_C^2}\,dC,
\qquad
P(x,dy)=\frac{K(x,y)}{D(x)}\,\mu(dy).
\]

\(D=0\) 的取值不影响 \(\pi\)；可任意补成概率核。核的归一化由实际根质量给出：

\[
\int K(x,y)\,d\mu(y)
=\int_E\frac{1_{Q_C}(x)\mu(Q_C)}{\lambda V_C^2}\,dC
=D(x).
\]

本轮始终保留大父标签，使用

\[
d\Gamma(C,x,y)
=\frac{1_{Q_C}(x)1_{Q_C}(y)}{\lambda V_C^2}
\,dC\,d\mu(x)\,d\mu(y).
\tag{1.1}
\]

其 \((x,y)\) 边缘为 \(\pi(dx)P(x,dy)\)，\(x\)、\(y\) 边缘同为 \(\pi\)，总质量为 \(X\)。记

\[
\rho_C(dx)=\frac{1_{Q_C}(x)}{\lambda V_C}\,d\mu(x),
\]

则有完整表达

\[
d\Gamma=\lambda\,dC\,\rho_C(dx)\rho_C(dy).
\tag{1.2}
\]

因此这是在实际大父 \(C\) 内抽两个独立的真实来源；不存在来源独立于根场的额外假设。

交换 \(x,y\) 保持 \(\Gamma\)，所以 \(P\) 关于 \(\pi\) 可逆。对 \(g\in L^2(\pi)\)，

\[
\langle g,Pg\rangle_{L^2(\pi)}
=\lambda\int_E\left|\int g\,d\rho_C\right|^2dC\ge0.
\tag{1.3}
\]

故 \(P\) 还是正半定的自伴压缩。以上均未给出谱隙或任何新负载上界。

## 2. 原未付主量是标记边上的有向成员损失

固定 \(H=\{D>t\}\)，写

\[
b_C(x,y)=\int_E\frac{1_{K_+}(B,C)}{V_B}
1_{Q_B}(x)(1-1_{Q_B}(y))\,dB,
\]

\[
F_C(x)=\int_E\frac{1_{K_+}(B,C)}{V_B}1_{Q_B}(x)\,dB.
\]

保留同一 \(C\) 标签后，R548 完整主量精确为

\[
T_H=2\int 1_H(x)b_C(x,y)\,d\Gamma(C,x,y).
\tag{2.1}
\]

小父排除终点 \(y\notin Q_B\)、实际根对 \(K_+\) 及全部来源重复使用均在 (2.1) 内，没有删除交叉项。

逐点有

\[
b_C(x,y)-b_C(y,x)=F_C(x)-F_C(y),
\tag{2.2}
\]

\[
b_C(x,y)+b_C(y,x)
=\int_E\frac{1_{K_+}(B,C)}{V_B}
|1_{Q_B}(x)-1_{Q_B}(y)|^2\,dB.
\tag{2.3}
\]

令 \(b_C^{\rm rev}=b_C(y,x)\)，可逆性及代数给

\[
\begin{aligned}
T_H={}&\frac12\int(1_H(x)+1_H(y))
(b_C+b_C^{\rm rev})\,d\Gamma\\
&+\frac12\int(1_H(x)-1_H(y))
(F_C(x)-F_C(y))\,d\Gamma.
\end{aligned}
\tag{2.4}
\]

第一项是非负双向负载；第二项是有符号净流。**可逆性平衡流入流出，不消去第一项。** 而且 \(F_C\) 依赖根标签 \(C\)，不能未经证明把第二项认作普通源链上某一个标量函数 \(F(x)\) 的 Dirichlet 配对。

在 \(H\times H\) 上，(2.4) 的净流项逐点为零，第一项仍可非零。这是高负载平台的准确未付部分。

## 3. 成员向量能量可以看见平台内换父

取 Hilbert 空间 \(\mathcal H=L^2(E,dB)\)，定义

\[
\Phi(x)(B)=\frac{1_{Q_B}(x)}{\sqrt{V_B}}.
\tag{3.1}
\]

则 \(\|\Phi(x)\|_{\mathcal H}^2=D(x)\)，并且

\[
\int\|\Phi\|_{\mathcal H}^2\,d\mu=X,
\qquad
\int\|\Phi\|_{\mathcal H}^2\,d\pi=A.
\tag{3.2}
\]

因此 \(A<\infty\) 已足以保证这个向量测试在 \(L^2(\pi;\mathcal H)\) 中合法。定义真实链能量

\[
\mathcal E_P(\Phi)
=\frac12\int\|\Phi(x)-\Phi(y)\|_{\mathcal H}^2\,d\Gamma.
\tag{3.3}
\]

若 \(i_{BC}=\mu(Q_B\cap Q_C)\)，Tonelli 和 (1.2) 给出

\[
\boxed{\quad
\mathcal E_P(\Phi)
=\iint_{E\times E}
\left(\frac{i_{BC}}{V_BV_C}
-\frac{i_{BC}^2}{\lambda V_BV_C^2}\right)dB\,dC.
\quad}
\tag{3.4}
\]

证明是对每个 \(B,C\) 使用 Bernoulli 方差：

\[
\frac\lambda{2V_B}\iint
|1_{Q_B}(x)-1_{Q_B}(y)|^2d\rho_C(x)d\rho_C(y)
=\frac\lambda{V_B}p_{BC}(1-p_{BC}),
\quad p_{BC}=\frac{i_{BC}}{\lambda V_C}.
\]

(3.4) 的非负第二项是 \(\langle\Phi,P\Phi\rangle\)，故当前实际有

\[
0\le\mathcal E_P(\Phi)\le A.
\tag{3.5}
\]

这严格捕捉了标量 \(D\) 不变时的成员更换：即使 \(D(x)=D(y)\)，也可能 \(\Phi(x)\ne\Phi(y)\)。所以不能用 \(|D(x)-D(y)|\) 替代成员距离。

### 核心限制下的精确系数

再定义依赖大父标签的成员场

\[
\Phi_C^+(x)(B)
=\frac{1_{K_+}(B,C)1_{Q_B}(x)}{\sqrt{V_B}}.
\]

令

\[
\mathcal E_+
=\frac12\int\|\Phi_C^+(x)-\Phi_C^+(y)\|_{\mathcal H}^2\,d\Gamma.
\]

此时只是在完整能量里取原核心父对，故 \(0\le\mathcal E_+\le\mathcal E_P(\Phi)\)，并且精确地

\[
T_0=2\mathcal E_+,
\qquad
A_{\rm core}=2\mathcal E_++R_0,
\qquad 0\le R_0\le2qX.
\tag{3.6}
\]

所以得到的是

\[
A_{\rm core}\le2\mathcal E_P(\Phi)+2qX.
\tag{3.7}
\]

**系数 2 必须保留。** 只用 (3.5)，右侧为 \(2A+2qX\)，没有收缩。把 \(\mathcal E_+\) 或 \(\mathcal E_P(\Phi)\) 改称“耗散”不会改变这一点。

平台内的精确量为

\[
T_{H\to H}
:=2\int1_H(x)1_H(y)b_C(x,y)\,d\Gamma
=\int1_H(x)1_H(y)
\|\Phi_C^+(x)-\Phi_C^+(y)\|_{\mathcal H}^2\,d\Gamma.
\tag{3.8}
\]

它可以被成员场观察，但尚未被支付。跨 \(H\) 边界的其余负载也没有因为可逆性而获得统一费用。

## 4. 第一处真正需要新几何的地方

(3.2) 已经把关键量纲分开：

- 根质量合同给成员场相对于来源测度 \(\mu\) 的平方范数为 \(X\)；
- 实际源链的平衡测度是 \(\pi=D\mu\)，其平方范数为 \(A\)；
- 平台内可以在保持 \(\|\Phi\|^2=D\) 的同时大量更换成员，因此标量负载不发生波动并不降低 (3.8)。

尚缺的不是可逆性验证、普通谱隙、或一条对 \(D\) 的标量凸性不等式，而是以下**真实根几何的统一价格**：

> 当同一批高负载来源在许多实际大父内被反复抽样，且每次抽样在原 \(K_+\) 中丢失许多小父成员时，如何同时使用这些小父和大父的根质量、接收中心的 Lebesgue 体积以及最外根条件，把全部成员更换的总费用限制在 \(X\) 的根阶倍数，并保留足够严格的 \(A\) 吸收系数？

当前没有证明这样的估计。对每一个成员或每一个大父分别估计后相加，会再次留下多重使用或尺度深度的费用；本轮没有将这些费用默认为零。源链也没有给出成员再生必须发生在更大尺度上的结论：真实 \(P\) 只保留本次抽中的 \(C\)，新来源可以重新拥有其他小父，不能把它当成此前的单调尺度转移链。

若只知道一个谱隙，它控制的是 \(L^2(\pi)\) 波动和能量的关系，不能直接控制 \(\pi\) 下负载均值 \(A/X\)。即使有成员场的谱信息，也仍需将 \(\pi\) 范数与已知 \(\mu\) 范数联系起来的真实几何预算。现有表示没有完成这一步。

本轮未把“若证明 \(\mathcal E_P(\Phi)\le\theta A/2+K_nX\) 则可闭合”作为新结论；那只是把原所需估计写进能量记号，且在 (3.7) 中必须保持 \(\theta<1\) 和系数 2。

## 5. 可积性、回代与计算核验

没有使用可能要求 \(\int D^3d\mu<\infty\) 的标量 \(D\) 平方能量测试。标量 \(\min(D/t,1)\) 是有界合法测试；\(\sqrt D\in L^2(\pi)\) 以及向量 \(\Phi\in L^2(\pi;\mathcal H)\) 由 \(A<\infty\) 保证。需要有限维构造时可先截取中心域与尺度，使 \(\Phi\) 为有限平方范数场，再用非负积分恢复；不能移动原 \(H\) 或丢失原 \(K_+\)。

R548 原入口仍是

\[
A_{\rm core}\le(t+2q)X+T_H,
\qquad A-A_{\rm core}\le B_nX.
\]

R549 实际新增的是 (2.1)–(3.8) 的精确表示与检查；没有得到 \(T_H\) 的新上界。因此不能从本轮推出目标弱型常数。

实际运行本机

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`

中的 SymPy，核验了 (2.4) 的逐点流分解及 (3.4) 的 Bernoulli 方差代数，两项残差均为严格符号零。这只是恒等式核验，不是一般几何上界的数值证据；没有运行有限输入反例扫描。

**最终状态：** 平台内成员更换已被准确定位，但其联合根几何价格仍未证明。文件作为未闭合检查点交付；交付后停止，不将表示理论计为新的主量付款。
