import sys,time,platform,json,hashlib,functools
from pathlib import Path
import sympy as sp,flint
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0
EMBEDDED_JSON='[{"L0_exact":"1/2 - sqrt(2)/4","N":2,"X_exact":"3/2 - sqrt(2)/4","masses":["1/2","1/2"],"name":"R540_two_source_contact","positions":[["0","0"],["sqrt(2)/4 + 1/2","0"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"1/2"},{"mask":2,"mass":"1/2","w_exact":"1/2"},{"mask":3,"mass":"1","w_exact":"1/2 - sqrt(2)/4"}],"source_capture_label_unique":true,"source_grid_shape":[3,3],"source_occupied_cells":5},{"L0_exact":"-1023*sqrt(15)/100000 - 3069*sqrt(10)/500000 + 123783/500000","N":3,"X_exact":"-sqrt(15)/40 - sqrt(10)/100 + 2033/2000","masses":["2/5","3/10","3/10"],"name":"asymmetric_three_source","positions":[["0","0"],["2/5","1/50"],["9/20","7/100"]],"roots":[{"mask":1,"mass":"2/5","w_exact":"1/5 - sqrt(10)/100"},{"mask":6,"mass":"3/5","w_exact":"61/200 - sqrt(15)/40"},{"mask":7,"mass":"1","w_exact":"1023/2000"}],"source_capture_label_unique":true,"source_grid_shape":[12,12],"source_occupied_cells":121},{"L0_exact":"-60198517*sqrt(3)/84672000 - 861599*sqrt(21)/8467200 - 1908337*sqrt(10)/14112000 - 909217*sqrt(5)/9408000 - 107*sqrt(30)/7200 - sqrt(15)/480 + 551*sqrt(7)/70560 + 2287*sqrt(70)/705600 + sqrt(210)/288 + 29*sqrt(105)/2880 + 7902029*sqrt(6)/169344000 + 11876159*sqrt(14)/169344000 + 14551*sqrt(35)/225792 + 944353/2116800 + 10547503*sqrt(2)/28224000 + 403691*sqrt(42)/3386880","N":4,"X_exact":"-3*sqrt(3)/10 - 3*sqrt(14)/32 - sqrt(5)/8 - sqrt(35)/32 - sqrt(21)/32 - 9*sqrt(6)/160 + 3*sqrt(10)/160 + sqrt(2)/2 + 773/400","masses":["1/2","1/4","1/8","1/8"],"name":"four_source_multiscale","positions":[["0","0"],["13/20","1/20"],["3/4","2/5"],["-1/5","1/2"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"-13*sqrt(10)/160 - sqrt(3)/8 - sqrt(6)/16 - sqrt(5)/16 + sqrt(35)/32 + sqrt(42)/32 + 37/160 + 23*sqrt(2)/80"},{"mask":2,"mass":"1/4","w_exact":"-9*sqrt(6)/80 - 3*sqrt(3)/20 + sqrt(21)/32 + sqrt(42)/32 + 257/800"},{"mask":3,"mass":"3/4","w_exact":"-sqrt(42)/16 - 249/800 + 3*sqrt(3)/80 + 31*sqrt(14)/160"},{"mask":4,"mass":"1/8","w_exact":"-sqrt(3)/16 + 1/16 + 7*sqrt(2)/80"},{"mask":6,"mass":"3/8","w_exact":"-sqrt(21)/16 - 1/25 + 7*sqrt(14)/160 + 19*sqrt(6)/160"},{"mask":7,"mass":"7/8","w_exact":"153/160 - 37*sqrt(14)/160"},{"mask":8,"mass":"1/8","w_exact":"-sqrt(5)/16 + 1/16 + sqrt(2)/8"},{"mask":9,"mass":"5/8","w_exact":"-sqrt(35)/16 - 1/80 + sqrt(14)/16 + sqrt(10)/10"},{"mask":11,"mass":"7/8","w_exact":"51/80 - 13*sqrt(14)/80"},{"mask":15,"mass":"1","w_exact":"1/40"}],"source_capture_label_unique":true,"source_grid_shape":[21,19],"source_occupied_cells":297},{"L0_exact":"-268334161264540289869*sqrt(14)/607162876276320000000 - 585372863301470951423*sqrt(6)/1691382298198320000000 - 446297744832287771*sqrt(3)/1204688246580000000 - 31908195415047044857*sqrt(26)/338276459639664000000 - 8433711942834739367/25693741509089062500 - 109893222787*sqrt(29)/2238531750000 - 503005821529*sqrt(2639)/100286222400000 - 61*sqrt(7917)/21168 - 6572335945051*sqrt(406)/585002964000000 - 4917802709*sqrt(78)/199311840000 - 810804606433*sqrt(42)/34879572000000 - 208202236615777*sqrt(93)/15318641754000000 - 137615187221*sqrt(754)/30085866720000 - 10614197*sqrt(2262)/4120900000 - 233232507301*sqrt(2418)/102124278360000 - 2131949297*sqrt(21)/95823000000 - 8509085269*sqrt(434)/1787174871300 - 11357*sqrt(18879)/19440000 - 155*sqrt(15834)/259584 - 15398060627*sqrt(273)/3487957200000 - 251719321*sqrt(2821)/204248556720 - 6018381*sqrt(6293)/7653100000 - 28125464558293*sqrt(62)/3574349742600000 - 216179*sqrt(1131)/146016000 - 144695081*sqrt(31)/17597925000 - 29132157811*sqrt(12586)/78557137200000 - 40133*sqrt(35061)/201840000 - 150441*sqrt(163618)/1749280000 - 27689*sqrt(1798)/42050000 - 9282625859*sqrt(174)/4450572000000 - 20654771054639*sqrt(899)/23828998284000000 - 970013*sqrt(5278)/3577392000 - 2880347*sqrt(5394)/13624200000 - 9955703*sqrt(806)/19639284300 - 173773603903*sqrt(403)/612745670160000 - 66838909*sqrt(91)/116265240000 - 113*sqrt(1209)/3888000 - sqrt(16926)/126360000 + 1697*sqrt(11687)/20184000 + 132349*sqrt(651)/157950000 + 98219*sqrt(23374)/655980000 + 43971662652363757*sqrt(13)/6443361135993600000 + 91469*sqrt(2697)/168200000 + 39370535237*sqrt(186)/13092856200000 + 87511*sqrt(609)/28224000 + 1643869265083*sqrt(87)/188036667000000 + 330564201089*sqrt(377)/66857481600000 + 41599*sqrt(1302)/12150000 + 37785413231*sqrt(217)/3927856860000 + 361976471*sqrt(1218)/67076100000 + 1004487511*sqrt(546)/93012192000 + 4885372354297704683*sqrt(58)/50596906356360000000 + 1820925011640009937*sqrt(203)/30358143813816000000 + 49302307239957954023*sqrt(39)/338276459639664000000 + 162385847520440099*sqrt(2)/233165467080000000 + 451619674136534463607*sqrt(7)/986639673949020000000 + 3006232688591866711*sqrt(182)/32216805679968000000","N":6,"X_exact":"-5*sqrt(3)/32 - 43*sqrt(14)/640 - 3*sqrt(93)/128 - 3*sqrt(78)/128 - sqrt(42)/32 - sqrt(62)/40 - 31*sqrt(13)/640 - 21*sqrt(6)/320 - 3*sqrt(7)/160 + 3*sqrt(26)/320 + 29*sqrt(2)/160 + 797/320","masses":["1/2","1/4","1/8","1/16","1/32","1/32"],"name":"six_source_multiscale","positions":[["0","0"],["3/5","0"],["4/5","1/10"],["1/10","3/5"],["13/20","2/5"],["9/10","3/5"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"-3*sqrt(3)/20 - sqrt(6)/16 + 13*sqrt(2)/160 + 3*sqrt(13)/64 + sqrt(39)/32 + 39/160"},{"mask":2,"mass":"1/4","w_exact":"-13*sqrt(14)/160 - 199/1600 - 7*sqrt(6)/160 + 3*sqrt(26)/160 + sqrt(39)/64 + 3*sqrt(58)/160 + sqrt(203)/64"},{"mask":3,"mass":"3/4","w_exact":"-1493/3200 - sqrt(42)/32 - sqrt(39)/32 - 7*sqrt(2)/64 - sqrt(13)/160 + 3*sqrt(78)/128 + 5*sqrt(29)/128 + sqrt(203)/64 + sqrt(14)/16 + 91*sqrt(3)/640"},{"mask":4,"mass":"1/8","w_exact":"-19/128 - 3*sqrt(6)/80 - sqrt(26)/80 - sqrt(14)/64 - sqrt(3)/32 + sqrt(2)/20 + sqrt(39)/64 + sqrt(182)/128 + sqrt(7)/16"},{"mask":6,"mass":"3/8","w_exact":"-sqrt(39)/32 + sqrt(26)/80 + sqrt(6)/20 + 51/400"},{"mask":7,"mass":"7/8","w_exact":"-sqrt(203)/32 - sqrt(14)/40 + 79/400 + sqrt(58)/20"},{"mask":8,"mass":"1/16","w_exact":"1/16"},{"mask":9,"mass":"9/16","w_exact":"21/160 - 3*sqrt(13)/160"},{"mask":11,"mass":"13/16","w_exact":"-3*sqrt(78)/64 - sqrt(13)/16 + 9*sqrt(6)/80 + 301/800"},{"mask":16,"mass":"1/32","w_exact":"-3/32 - sqrt(26)/64 - sqrt(14)/128 - sqrt(13)/128 + sqrt(2)/20 + sqrt(7)/32 + sqrt(182)/128"},{"mask":19,"mass":"25/32","w_exact":"-5*sqrt(29)/128 - 15*sqrt(3)/128 - sqrt(58)/80 - 9*sqrt(6)/320 - 27/1600 + 7*sqrt(2)/64 + 3*sqrt(93)/128 + sqrt(899)/128"},{"mask":22,"mass":"13/32","w_exact":"-sqrt(182)/64 - 29/800 + sqrt(26)/160 + 9*sqrt(7)/80"},{"mask":23,"mass":"29/32","w_exact":"-9*sqrt(58)/160 - sqrt(899)/128 + sqrt(62)/40 + 789/1600"},{"mask":27,"mass":"27/32","w_exact":"-3*sqrt(93)/64 - 9*sqrt(6)/160 + 3*sqrt(62)/80 + 531/1600"},{"mask":31,"mass":"31/32","w_exact":"1159/1600 - 7*sqrt(62)/80"},{"mask":32,"mass":"1/32","w_exact":"1/32"},{"mask":54,"mass":"7/16","w_exact":"247/400 - 9*sqrt(7)/40"},{"mask":63,"mass":"1","w_exact":"1/25"}],"source_capture_label_unique":true,"source_grid_shape":[58,54],"source_occupied_cells":2583}]'
PROVENANCE={'source_filename': '/tmp/r546_flow_numeric.json', 'source_sha256': 'e64e82c1b4f49c616d2cce208e0b125f6475870992eb25b8ab0fc4ac780d3ca8', 'embedded_data_sha256': '32dc9e841ef9456dbfc57f1ee22463f1dff577812f721ef22a22d1b70d0d7b9e', 'provenance': 'Exact root-center areas copied from the four R546 complete Lebesgue receiving-grid inputs; no all-grid reconstruction rerun. Source states/root partition already verified there. Embedded inputs make this file self-contained.'}
PROVENANCE["R548_source_script_sha256"]='c82ae8fc278a0b03a7554a0aac799d3912586aa0b0603537e9d95449297f70fd'
DATA=json.loads(EMBEDDED_JSON)
assert hashlib.sha256(EMBEDDED_JSON.encode()).hexdigest()==PROVENANCE["embedded_data_sha256"]
def cmp(a, b):
    global COMPARISONS
    COMPARISONS += 1
    v = ev(a) - ev(b)
    if v > 0:
        return 1
    if v < 0:
        return -1
    if sp.simplify(a - b) == 0:
        return 0
    raise ArithmeticError(str(a - b))

def ev(e):
    e = sp.sympify(e)
    if e.is_Rational:
        return arb(int(e.p)) / int(e.q)
    if e.is_Add:
        return sum((ev(t) for t in e.args), arb(0))
    if e.is_Mul:
        a = arb(1)
        for t in e.args:
            a *= ev(t)
        return a
    if e.is_Pow:
        a, p = e.args
        if p.is_Rational:
            return ev(a).root(int(p.q)) ** int(p.p)
    raise ValueError(str(e))

def ex(v):return sp.expand(v)
def sign(v):
 z=ev(v)
 if z>0:return 1
 if z<0:return -1
 assert sp.simplify(v)==0
 return 0

def cert(v):return dict(exact=str(v),arb256=str(ev(v)),float=float(v),sign=sign(v))
def dot(u,v,m):return sum(m[i]*u[i]*v[i] for i in range(len(m)))

def solve(inp):
 N=inp['N'];m=list(map(sp.Rational,inp['masses']));w={r['mask']:sp.sympify(r['w_exact']) for r in inp['roots']};mass={r['mask']:sp.Rational(r['mass']) for r in inp['roots']};X=ex(sum(w.values()));D=[ex(sum(ws/mass[S] for S,ws in w.items() if S>>i&1)) for i in range(N)];pi=[ex(m[i]*D[i]) for i in range(N)];assert ex(sum(pi)-X)==0;assert all(sign(v)>0 for v in D)
 K=[[ex(sum(ws/mass[S]**2 for S,ws in w.items() if S>>i&1 and S>>j&1)) for j in range(N)] for i in range(N)];P=[[K[i][j]*m[j]/D[i] for j in range(N)] for i in range(N)];rowres=[ex(sum(K[i][j]*m[j] for j in range(N))-D[i]) for i in range(N)];assert all(v==0 for v in rowres)
 bal=[]
 for i in range(N):
  for j in range(N):
   assert ex(K[i][j]-K[j][i])==0
   residual=sp.cancel(pi[i]*P[i][j]-pi[j]*P[j][i]);assert residual==0;bal.append(str(residual))
 E=sp.Integer(0);Vnum=sp.Integer(0)
 for i in range(N):
  for j in range(i):
   delta=ex(D[i]-D[j]);E+=m[i]*m[j]*K[i][j]*delta**2;Vnum+=pi[i]*pi[j]*delta**2
 Var=Vnum/X;A=dot(D,D,m);mean=A/X
 if Vnum==0:assert E==0;ratio=None
 else:assert sign(Var)>0 and sign(E)>=0;ratio=cert(E/Var)
 # The only added platform observable: continuous membership feature Phi.
 feature_pairs=[];Efeature=sp.Integer(0)
 for i in range(N):
  for j in range(i):
   distance=ex(sum(ws/mass[S] for S,ws in w.items() if bool(S>>i&1)!=bool(S>>j&1)));term=m[i]*m[j]*K[i][j]*distance;Efeature+=term;feature_pairs.append(dict(i=i,j=j,squared_feature_distance=cert(distance),Dirichlet_contribution=cert(term)))
 Qall=sp.Integer(0)
 for S in w:
  for T in w:
   intersection=sum(m[i] for i in range(N) if S>>i&1 and T>>i&1);Qall+=w[S]*w[T]*intersection**2/(mass[S]*mass[T]**2)
 feature_residual=ex(Efeature-A+Qall);assert feature_residual==0 and sign(Efeature)>=0
 feature=dict(definition='Phi_i(B)=1{i in Q_B}/sqrt(V_B); E_Phi=sum_i<j mi*mj*Kij*sum_S(wS/mS)*(1S(i)-1S(j))^2',Dirichlet_E_Phi=cert(Efeature),E_Phi_over_X=cert(Efeature/X),all_root_pair_overlap_square_Q=cert(Qall),identity_E_Phi_minus_A_plus_Q_residual_exact=str(feature_residual),source_pair_feature_records=feature_pairs,scope='Complete root-reversible kernel and all S,T in Q, not only scale-separated parent pairs. Finite platform observable; no dimension-uniform or root-order claim.')
 h=(arb(1)/(4*arb(2).sqrt())).exp();pairs=[]
 for S in sorted(w):
  for T in sorted(w):
   if mass[T]<=mass[S]:continue
   margin=ev(sp.sqrt(mass[T]/mass[S]))-h
   if margin<0:continue
   assert margin>0;pairs.append((S,T))
 F={T:[ex(sum(w[S]/mass[S] for S,TT in pairs if TT==T and S>>i&1)) for i in range(N)] for T in sorted(w)};J=[[sp.Integer(0) for j in range(N)] for i in range(N)]
 for S,T in pairs:
  coeff=2*w[S]*w[T]/(mass[S]*mass[T]**2)
  for i in range(N):
   if not(S>>i&1 and T>>i&1):continue
   for j in range(N):
    if T>>j&1 and not S>>j&1:J[i][j]+=coeff*m[i]*m[j]
 J=[[ex(v) for v in row] for row in J];net=[ex(sum(J[i][j]-J[j][i] for j in range(N))) for i in range(N)];assert ex(sum(net))==0;ND=ex(sum(net[i]*D[i] for i in range(N)));covsum=0;local=[]
 for T in sorted(w):
  ids=[i for i in range(N) if T>>i&1];dmean=sum(m[i]*D[i] for i in ids)/mass[T];fmean=sum(m[i]*F[T][i] for i in ids)/mass[T];cov=ex(sum(m[i]*D[i]*F[T][i] for i in ids)/mass[T]-dmean*fmean);charge=ex(2*w[T]*cov);covsum+=charge;local.append(dict(parent_T=T,mass=str(mass[T]),F_T=[cert(v) for v in F[T]],covariance=cert(cov),D_test_contribution=cert(charge)))
 covsum=ex(covsum);assert ex(ND-covsum)==0
 # D coarea: complete strict-threshold prefixes, no tie splitting.
 order=sorted(range(N),key=functools.cmp_to_key(lambda i,j:cmp(D[j],D[i])));groups=[]
 for i in order:
  if not groups or cmp(D[i],D[groups[-1][0]])!=0:groups.append([i])
  else:groups[-1].append(i)
 prefix=[];H=0;coarea=0
 prefix.append(dict(H_mask=0,net_out_minus_in=cert(sp.Integer(0))))
 for k,g in enumerate(groups):
  for i in g:H|=1<<i
  flux=ex(sum(net[i] for i in range(N) if H>>i&1));prefix.append(dict(H_mask=H,net_out_minus_in=cert(flux)))
  if k+1<len(groups):coarea+=flux*(D[g[0]]-D[groups[k+1][0]])
 coarea=ex(coarea);assert ex(coarea-ND)==0
 # One bounded theoretical tester, chosen by the same bottom-load interval rule.
 if len(groups)>1:
  low=D[groups[-1][0]];higher=D[groups[-2][0]];tt=ex((low+higher)/2);bottom=set(groups[-1]);flux=sp.sympify(prefix[-2]['net_out_minus_in']['exact']);phi_test=(1-low/tt)*flux;nums=[low if i in bottom else tt for i in range(N)];phi=[v/tt for v in nums];phi_residual=ex(sum(net[i]*nums[i] for i in range(N))-(tt-low)*flux);assert phi_residual==0
 else:
  tt=D[groups[0][0]];phi=[sp.Integer(1)]*N;phi_test=sp.Integer(0);phi_residual=ex(sum(net));assert phi_residual==0
 assert sign(tt)>0 and all(sign(v)>=0 and sign(1-v)>=0 for v in phi)
 bounded=dict(threshold_t=cert(tt),rule='Midpoint of the two lowest distinct D levels; if D constant, t=D and phi=1.',phi=[cert(v) for v in phi],ordered_phi_test=cert(phi_test),numerator_identity_residual_exact=str(phi_residual),range_guard='0<=phi=min(D/t,1)<=1. This bounded test avoids assuming a general third moment. D tests above are only for this finite model.')
 print(inp['name'],'E',float(E),'Var',float(Var),'Rayleigh',None if ratio is None else ratio['float'],'ND',float(ND),'prefix signs',[p['net_out_minus_in']['sign'] for p in prefix],flush=True)
 return dict(name=inp['name'],N=N,positions=inp['positions'],masses=inp['masses'],roots=inp['roots'],X=cert(X),D_i=[cert(v) for v in D],pi_i=[cert(v) for v in pi],K=[[cert(v) for v in row] for row in K],P=[[cert(v) for v in row] for row in P],reversibility_checks=dict(row_sum_numerator_residuals=[str(v) for v in rowres],row_sums_exact=['1']*N,detailed_balance_residuals=bal,stationary_mass_minus_X_exact=str(ex(sum(pi)-X)),all_pass=True),A_full_load=cert(A),membership_feature_platform_test=feature,bounded_phi_test=bounded,D_pi_mean=cert(mean),Dirichlet_E=cert(E),variance_pi_D=cert(Var),D_Rayleigh_E_over_Var=ratio,variance_zero_exact=Vnum==0,ordered_parent_pair_count=len(pairs),F_parent_records=local,ordered_flow_J=[[cert(v) for v in row] for row in J],ordered_net_out_minus_in=[cert(v) for v in net],ordered_D_test=cert(ND),ordered_D_test_from_F_covariance=cert(covsum),covariance_identity_residual_exact=str(ex(ND-covsum)),ordered_D_test_minus_two_Dirichlet=cert(ex(ND-2*E)),descending_load_tie_groups_zero_based=groups,true_threshold_prefix_net_flows=prefix,D_coarea_reconstruction=cert(coarea),D_coarea_residual_exact=str(ex(coarea-ND)),sign_scope='out-minus-in convention; positive ordered D test means the ordered source flow decreases D on average. It is a signed cross-covariance with parent-dependent F_T, not automatically the nonnegative full-kernel Dirichlet form.')
results=[solve(x) for x in DATA]
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,moment_scope_guard='Untruncated D tests may require third-moment integrability in a general model; only finite inputs are evaluated here. Theoretical comparisons should use bounded phi=min(D/t,1). A constant-D plateau can have E=Var=0 but A_full_load>0, so dissipation does not pay its global platform charge.',input_provenance=PROVENANCE,scope='Four fixed R548 embedded exact continuous-root inputs, no root geometry recomputation or new scan. Exact reversible kernel checks and fixed-observable Rayleigh ratios; no uniform spectral-gap claim. Ordered flow uses same full scale-separated positive envelope, not exact original core.',pre_registered_formula_note='Calculation plan was written to the companion Markdown before execution. Kij=sum wS/mS^2 1i,j in S; Pij=Kij*mj/Di; pi=mi*Di. E=1/2 sum pi_i Pij(Di-Dj)^2; Var uses its equivalent pairwise formula (1/X)sum_i<j pi_i*pi_j(Di-Dj)^2. Ordered D-test=sum Jij(Di-Dj)=2sum_T wT Cov_T(D,F_T).',algebraic_comparisons=COMPARISONS,elapsed_seconds=time.monotonic()-START,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
