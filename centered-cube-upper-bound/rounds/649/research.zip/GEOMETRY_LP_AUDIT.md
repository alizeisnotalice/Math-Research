# R649 independent geometry and source-LP audit — checkpoint

Before reading the author's proof: for finite retained cubes with every alpha_k>0 and load <=1 Lebesgue-a.e., a subset K with sum_K alpha=1 and positive-volume intersection U_K has no positive-volume overlap with any outside cube. Otherwise the load is at least 1+alpha_l on that overlap. Thus its exact membership cell Omega_K equals U_K modulo a finite union of null sets. This uses positivity on EVERY retained outside label. A continuous sum of K-weighted normalized squared infinity distances therefore has essential infimum on Omega_K equal to its minimum on the closed positive-volume intersection rectangle. Boundary-only intersections must still be excluded; outside cubes can meet rectangle faces and cannot be included as admissible positive-volume source cells merely because they meet there.

The geometric observation is not a characterization of realizable incidence matrices, and no general clique/Helly replacement has been invoked. Full source-LP and near-minimizing AC construction audit follows.

## Verdict and exact geometry definitions

The proposed positive-volume saturated-cell simplification is TRUE. The finite source LP, its finite-dimensional weak/strong dual, and existence of arbitrarily near-minimizing ACTUAL AC sources are also valid. None gives a uniform alpha-weighted row-coefficient bound or the required nonzero-error spatial propagation. The author's final ACTUAL_ALPHA.md source-selection section correctly treats its SP5 certificate as conditional.

Work with a finite retained index set J, all alpha_j>0, closed cubes C_j=Q(c_j,rho_j), rho_j>0, and L_alpha^C=sum_J alpha_j 1_Cj<=1 Lebesgue-a.e. For nonempty K subset J put

    U_K=intersection_{k in K} C_k,
    Omega_K=U_K \ union_{l notin K} C_l.

Thus Omega_K is the exact membership-pattern cell, not a chosen connected component of it. Let alpha(K)=sum_K alpha_k. If alpha(K)=1 and |U_K|>0, then for every l outside K,

    |U_K intersect C_l|=0,

since a positive-volume overlap would have load >=1+alpha_l>1 there. Finiteness then implies |U_K\Omega_K|=0. Conversely positive-volume Omega_K implies positive-volume U_K. Positivity of retained outside alpha is essential; zero-weight labels must be removed or ignored in defining the relevant membership patterns. Nonempty intersections with alpha(K)>1 can only have zero Lebesgue measure. A saturated K with zero-volume U_K must be excluded from the source LP.

The rectangle U_K has coordinate lower and upper limits

    L_i=max_{k in K}(c_{k,i}-rho_k),
    H_i=min_{k in K}(c_{k,i}+rho_k).

Positive volume is exactly L_i<H_i for every coordinate. Equality in even one coordinate is a contact-only rectangle of zero n-dimensional volume, not an AC source cell. There is no need to invoke a general Helly theorem: these coordinate inequalities directly verify the intersection. For these axis-parallel boxes, pairwise POSITIVE-volume intersections also imply positive-volume total intersection by considering the extreme lower/upper intervals in each coordinate; merely pairwise nonempty closed intersections can leave a null contact. None of these elementary box facts says that arbitrary prescribed incidence matrices are geometrically realizable. Throughout the LP columns come from the actual fixed cube geometry and its actual saturated positive-volume cells.

## Exact essential cost and convex rectangle minimization

Define normalized distances r_k(y)=||y-c_k||_infinity/rho_k on C_k and

    G(y)=sum_J alpha_k 1_Ck(y) r_k(y)^2.

On Omega_K,

    G(y)=g_K(y):=sum_{k in K} alpha_k
                          ||y-c_k||_infinity^2/rho_k^2.

The function g_K is continuous and convex on all of R^n. For saturated positive-volume K, Omega_K equals the compact full-dimensional rectangle U_K modulo a null set, so

    c_K:=ess inf_{Omega_K}G
        =ess inf_{U_K}g_K
        =min_{y in U_K}g_K(y).

The last equality includes boundary minima: every relative neighborhood of a minimizer in the full-dimensional rectangle has positive Lebesgue volume, and continuity supplies a positive-volume near-minimum set. Removing finitely many outside-cube overlaps of zero volume cannot destroy this property. The minimum exists by compactness, with 0<=c_K<=1 since alpha(K)=1 and each normalized distance is <=1 on U_K.

This gives an exact finite convex program for each c_K. One may minimize sum_K alpha_k z_k^2 with variables y in U_K, z_k>=0, and -rho_k z_k<=y_i-c_{k,i}<=rho_k z_k for every k and coordinate i. This is a convex quadratic objective with linear constraints. A numerical minimizer alone is not an exact coefficient certificate; any exact or interval computation must retain a certified optimization gap.

IMPORTANT boundary qualification: G itself need not equal g_K on every point of the CLOSED rectangle. An outside cube can touch a face without positive-volume overlap; its additional positive indicator term appears in the ambient G at that face. The correct convex objective is g_K, not G evaluated pointwise at the boundary minimizer. No boundary atom is licensed by this essential-infimum identity.

A concrete 1D geometry makes the distinction visible. Take C_1=[0,2], C_2=[19/10,39/10], C_3=[-1/10,19/10], with alpha=(99/100,1/100,1/100). Packing holds a.e. For K={1,2}, U_K=[19/10,2] and Omega_K=(19/10,2]. Its convex cost is

    g_K(x)=(99/100)(x-1)^2+(1/100)(x-29/10)^2,

whose minimum on U_K is 8119/10000 at x=19/10. That point is absent from Omega_K and belongs to C_3, where the ambient G has an extra 1/100. The essential infimum is nevertheless 8119/10000 and can be approached by AC densities on Omega_K. This example illustrates the geometry/cost boundary issue; it is not offered as a critical-branch entropy counterexample.

## Exact finite source LP

Let S be the actual finite family of positive-volume membership cells with alpha(K)=1. Denote the actual next demanded row masses by b_k=m'_k>0. Define the incidence matrix A_{kK}=1_{k in K} for K in S, and let c=(c_K). A genuine actual next AC KKT source exists by the inherited finite entropy construction, so its cell masses provide a feasible vector for

    P(b): minimize c dot z subject to A z=b, z>=0.

All columns are actual geometry-derived saturated cells. In particular alpha dot A_{.K}=1. Therefore any feasible z satisfies

    sum_K z_K=alpha dot b=M'.

The feasible set is a nonempty closed subset of the finite simplex of mass M', hence compact. Its minimum Phi=P(b) is attained and lies in [0,M']. Rank deficiency, redundant moment equations, and zero masses on some columns create no problem. One may choose a minimizer with linearly independent positive columns, hence at most rank(A)<=|J| used cells, by eliminating dependent columns along a cost-flat optimal feasible direction; no claim that every optimal vector has that sparsity is needed.

## Weak and strong finite-dimensional duality, with attainment

The correctly signed unnormalized dual is

    D(b): maximize beta dot b
          over beta in R^J with A^T beta<=c,

or equivalently beta(K)<=c_K for every actual saturated positive-volume cell. Row coefficients beta are unrestricted signed numbers because the row demands are equalities. Weak duality follows directly:

    c dot z-beta dot b=(c-A^T beta) dot z>=0.

Dual beta=0 is feasible since c>=0. Strong duality AND dual attainment follow from a finite Farkas argument, given here to avoid importing an unread general conic/infinite-dimensional theorem.

Take a primal minimizer z*. Let I_+ be its positive coordinates and I_0 its zero coordinates. Seek beta and w such that

    c=A^T beta+w,
    w_{I_+}=0,  w_{I_0}>=0.

The right-hand vectors form the finitely generated cone spanned by the positive/negative columns of A^T and by e_i for i in I_0. If c were not in that cone, the finite alternative gives a vector d with

    A d=0,  d_{I_0}>=0,  c dot d<0.

For sufficiently small epsilon>0, z*+epsilon d remains nonnegative and has the same demands, contradicting optimality. Hence beta,w exist. This beta is dual feasible, and

    c dot z*-beta dot b=w dot z*=0.

For completeness, the finite alternative used here has an elementary proof. A finitely generated cone is closed: each representation can be reduced to linearly independent generators by eliminating a nonnegative coefficient along a dependence; a convergent sequence then has a subsequence using one fixed independent subset, whose coefficients converge by the continuous inverse on its span. If c lies outside the resulting closed convex cone, take its closest point p. The vector d=p-c has nonnegative product with every cone generator and d dot c=-||p-c||^2<0, as follows by testing the nearest-point inequality at 0 and 2p. Applying this to the displayed generators gives exactly the alternative above. This is the finite B01/Farkas workflow, not a claim about arbitrary cones, arbitrary incidence matrices, Slater points, or uniform conditioning.

For the normalized source problem set d*=b/h, h=1+kappa'>0. Its primal mass vectors have total M'/h=Q', its value is Phi/h, and the dual constraints remain beta(K)<=c_K while the objective becomes beta dot d*. This factor is required in SP5.

## Infimum over actual AC sources and near-minimizers

Every actual AC entropy dual nu with row moments b_k, total mass M', and L_alpha^C=1 nu-a.e. is supported, modulo null sets, on the union of cells in S. Its cell masses z_K satisfy the finite LP, and

    integral G dnu>=sum_K c_K z_K>=Phi.

Conversely, fix an optimal mass vector z* and any tau>0. For each used cell define

    E_{K,tau}={y in Omega_K:G(y)<c_K+tau}.

It has positive Lebesgue measure by the definition of essential infimum, and finite measure because the geometry is bounded. The probability density 1_{E_{K,tau}}/|E_{K,tau}| is AC and lives in the EXACT membership cell. Mix these densities with masses z*_K. The resulting nu_tau has precisely the row moments b_k, mass M', and saturation load one nu_tau-a.e., and

    integral G dnu_tau<=Phi+tau M'.

Thus the infimum over actual AC KKT sources equals Phi, although an AC optimizer need not exist. After whole-geometry normalization,

    Z_next<=Phi/h+tau Q'.

All this is exact source selection inside the actual-alpha KKT class. It does not merely approximate row demands, and it places no mass on null contact cells. Densities may become arbitrarily large as tau decreases; there is no uniform density or displacement bound. A convex rectangle optimizer at a boundary point is only a way to compute c_K, not permission to replace nu_tau with an atom. Even if a boundary atomic candidate happens to satisfy some moments, AC admissibility and all physical boundary memberships must still be checked separately.

## Check of the author's SP1–SP5

I read the final spatial-selection section of /tmp/ccu_r648/ACTUAL_ALPHA.md after independently establishing the saturated-cell geometry checkpoint.

SP1 passes: integral G dmu=T_Z+I_Z, with 0<=I_Z<=sum_k alpha_k mu(C_k\A_k)<=S. The last inequality follows by integrating L_alpha^A<=L_alpha^C<=1 against old AC mu and using sum alpha_k mu(A_k)=Q'. It is an invasion bound, not a movement estimate.

SP2 and SP3 pass by the exact AC construction above, including the tau M' and tau Q' factors. No exact AC minimizer is claimed.

SP4 passes with R_sp=[Phi/h-integral G dmu]_+. Since 0<=Phi/h<=Q', one has 0<=R_sp<=Q'. The trivial Q' bound is a per-stage source-mass cost, not a summable bound. If S=0 and E'_grow=0, the deliberately permissible dual mu'=h mu indeed gives Phi/h<=integral G dmu and hence R_sp=0. This does not propagate to nonzero errors automatically.

SP5 is a correct CONDITIONAL sufficient certificate for a normalized optimal dual beta if BOTH proposed properties hold:

    |beta_k|<=C alpha_k,
    sum_k beta_k 1_Ck(x)<=G(x)+C(1-L_alpha^C(x))
                         for old mu-a.e. x.

Indeed, with i_k=mu(C_k\A_k),

    b_k/h-mu(C_k)=m_k(u'_k-kappa')/h-i_k.

Strong duality and the two proposed properties then bound Phi/h-integral G dmu by

    C sum_k alpha_k m_k|u'_k-kappa'|/h
      +C[sum_k alpha_k i_k+integral(1-L_alpha^C)dmu]
    =C sum_k alpha_k m_k|u'_k-kappa'|/h+C S.

The bracket identity is exactly S, so there is no extra unpaid invasion term in the claimed conditional estimate. Weighted Cauchy gives the author's displayed sqrt(eps Q' E'_grow)/h bound. Positive-part application preserves the result. This confirms the algebra of SP5 without proving either uniform geometric premise.

## What duality does NOT certify

Finite dual attainment is not a uniform estimate on beta. Bounds on 0/1 matrix entries and c_K in [0,1] alone do not supply a dimension/label/alpha-uniform conditioning result. In particular a bound on beta must not be inferred from its objective value or from alpha(K)=1. Redundant moment rows can generate arbitrarily large dual representatives: with only one saturated column K={1,2}, equal demanded masses and c_K=0, all beta=(L,-L) are optimal. That example shows that arbitrary optimal representatives are unbounded; it does NOT refute existence of a specially selected bounded representative. The latter stronger existence claim with |beta_k|<=C alpha_k remains unproved in the actual geometry.

The saturated-cell inequalities beta(K)<=c_K also give no required extension to nonsaturated old-source cells, whose loads can approach one. The second proposed SP5 inequality is therefore an additional geometric claim, not a restatement of finite LP dual feasibility. Boundary-only incidence patterns cannot be added as columns to force it. An arbitrary finite matrix counterexample would have to be separately realized by actual feasible cubes/weights before it refuted the geometric certificate; this audit makes no such realization claim.

No statement here gives paid relocation of old source, preservation of independent action laws, a summable growth/mass fee, or the full global target. Delivery is limited to the specified geometry and LP audit.

## Executed local tool evidence and skill scope

Used the already installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. The boundary example derivative was (1000x-1019)/500, its intersection cost infimum was exactly 8119/10000, and the ambient boundary extra term was 1/100. The normalized-demand residual after h=1+kappa' was exactly zero. These are algebra checks; the geometric and finite-cone arguments above are proofs.

Read /Users/zhengzhihao/.codex/skills/math-b01-lagrange-farkas/SKILL.md, references/provenance.md, and references/method.md. Only its finite real-matrix Farkas workflow is used, with the needed finite-cone proof supplied above. No external paper theorem or general infinite-dimensional/conic strong-duality assertion was imported from the skill's bibliography.
