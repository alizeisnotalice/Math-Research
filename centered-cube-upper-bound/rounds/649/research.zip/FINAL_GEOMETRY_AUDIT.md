# R649 final geometry and scalar integration audit

## Frozen source and scope

Audited final source: `/tmp/ccu_r649_final/REPORT.tex`, 227 lines.

**REPORT SHA256:** `7929bd2de8ab4712a5a67d5448366d679eaa0ce6455f76603af86d0beee1786d`

**Verdict: PASS within the assigned scope.** The final source correctly integrates the full-family H terminal, the single weighted-gamma choice, the concrete high-growth Cauchy variable, the restricted sharp scalar coefficient, the low-row debit and residue, the saturated-rectangle cost with its boundary qualifications, and the limited scope of the small models. It does not prove actual-source propagation, uniform net contraction, the complete high-incoming estimate, or the general root-order weak bound.

For the terminal and scalar propositions, I read their final statements before their displayed proofs and compared them with an independent derivation. The preceding independent proof record is `/tmp/ccu_r649/H_GEOMETRY_AUDIT.md`; this final audit checks the actual final text, including its additions. I also cross-read `/tmp/ccu_r649/GEOMETRY_LP_AUDIT.md` for the saturated-cell boundary issue and used the already independent numerical review in `NUMERIC_PLAN.md` §8 as the evidence boundary for the numerical family. I did not re-scan the numerical records or rerun its complete certificate suite.

Only this final audit file was written by this agent. No other files, Git state or PDF outputs were modified. No abandoned quadratic swap/coercivity argument, old unweighted minimizer, or separately paid reload branch was imported into the H branch.

During review I reported, and the parent corrected, the following integration issues: the scalar proof's normalized growth now explicitly means `E_{u>kappa}`; the ambient source-cost cap is marked `dx-a.e.`; the local-source parameter is `0<h<1` and the analytic family explicitly uses `h=theta^2`; `M'=||mu'||=gQ'` is distinguished from normalized `M_next=Q'`; and membership cells explicitly ignore deleted zero-weight labels. These exact corrections were reread before binding the above hash. No remaining defect was found in the assigned scope.

## 1. Full-family H terminal

Lines 49–76 state and prove the correct object:

\[
 h_j=m_j^{-1}\int_{A_j}r_j^2\,d\mu,\quad
 Y=\varepsilon\sum_jv_jh_j,\quad H=(1+\kappa)Y,
 \qquad 0\le H\le\kappa M\le4M.
\]

The independent derivation gives the receiver-weighted annular defect

\[
 T_r^v=\varepsilon\sum_j(v_j/m_j)\mu(A_j\setminus Q(y_j,rs_j))
 \le\frac{H}{(1+\kappa)r^2}.
\]

For a fixed `0<eta<1`, bad rows have total actual piece volume at most `T_r^v/(eps eta)`. Each remaining row's source core has mass at least `(1-eta)m_j>=(1-eta)d_j`. A single decreasing-radius greedy selection over all those rows makes the selected root cores pairwise mu-disjoint. Their total `d_j` is at most `M/(1-eta)`. Every good receiver cube lies inside a root cube enlarged by `2r+1/a`, so

\[
 V\le\frac{T_r^v}{\varepsilon\eta}+\frac{C_rM}{1-\eta},
 \qquad C_r=(2r+1/a)^n.
\]

Optimizing eta, with an endpoint limit when the tail is zero, gives the final theorem

\[
 \sqrt V\le\sqrt{H/[(1+\kappa)\varepsilon r^2]}+\sqrt{C_rM}.
\]

The proof uses the actual disjoint `I_j`, not a fictitious full receiver partition. It needs no positive lower bound on `u_j`, and does not spend a fresh source budget per scale. Positive mu intersection suffices for the geometric center-distance bound, while source-disjoint roots control the sum by one M.

At `r=1/64`, the dimension-uniform bound `C_r<=1/16` is valid for every integer `n>=1`. In the hard band, `V/M>=1/5` and `eps V/M=kappa/(1+kappa)>=7/9`. Therefore reversing the optimized terminal is legitimate and yields

\[
 H/M\ge(1+\kappa)c_*,\qquad
 c_*=\frac1{4096}\frac79(1-\sqrt5/4)^2>0.
\]

The final statement has the required factor `1+kappa`; it has not confused the Y lower bound with the H lower bound.

## 2. One weighted assignment and the complete prototype

Lines 78–121 correctly distinguish actual next source, old-source prototype, and normalized state. Since every next receiver volume is divided by `g=1+kappa'`,

\[
 H_{\rm next}=(1+\kappa')\varepsilon\sum_j(p_j/g)h'_j
 =\varepsilon\sum_jp_jh'_j
\]

holds per action before expectation. No adaptive denominator is extracted from an expectation. The old-source reference remains `H_proto=eps sum p_j k_j`, and its ownership split

\[
 H_{\rm proto}=\sum_ja_ju_jk_j+\varepsilon\sum_j(f_j-o_j)k_j
\]

is exact. The adaptive signed fill-minus-loss term is retained.

The selected gamma minimizes the single bounded finite-row objective `sum int u_jB(u_j)r_j^2 dgamma_j`. Weak-* compactness of the feasible densities `gamma_j=theta_j mu`, their fixed mass/support constraints, and bounded row costs suffice for existence. The Eulerian benchmark is feasible and yields exactly the weighted comparison used in the text. It does not supply the old unweighted `Z_gamma<=Z_lambda`, which the final text expressly disallows.

Writing `b=(t-1)/2` and `sigma=1+b`,

\[
 \|p+bq\|_\infty^2\le(1+b)(\|p\|_\infty^2+b\|q\|_\infty^2)
\]

proves the own-anchor bound with `A=sigma/t^2`, `B=b sigma/t^2=(1-t^{-2})/4`, and `A+B=q(u)^2`. This uses the true own-anchor marginal for the fixed old-row main term. It does not factor p, alpha, or an ownership event. Applying the weighted benchmark only there gives the final master inequality, and algebra gives the signed drift `H-D_H+C_H+eps E sum(f-o)k`.

The balanced-growth special case is correctly called a contraction of the old-source prototype. It is explicitly not a contraction of actual `H_next`. The full source difference remains unpaid.

## 3. Concrete Cauchy variable and high-growth-only coefficient

Final lines 137–147 define the intended nonnegative contribution sum explicitly:

\[
 X=\sum_{u_j>\kappa}v_j(u_j-\kappa)q(u_j)^2h_j\ge0.
\]

It is not the complete signed `C_H/eps`; the text correctly uses `C_H<=eps X`. With `E_+=E_{u>kappa}`, weighted Cauchy gives

\[
 X^2\le E_+\sum_{u>\kappa}v_ju_jq(u_j)^4h_j^2
 \le E_+\left[X+\kappa\sum_jv_jh_j\right].
\]

For `H>0`, set `x=eps X/H`, `e=eps E_+/H`, and `c0=kappa/(1+kappa)`. Then `x^2<=e(x+c0)`, so

\[
 C_H\le\varepsilon E_+
 +\sqrt{c_0\varepsilon E_+H}.
\]

If H vanishes, every positive `v_jh_j` vanishes and the correlation is zero. The final proof uses high growth in both its statement and normalized scalar variable. No paid low growth or new-growth budget is silently inserted into this inequality.

## 4. Low-row debit and the scalar theorem's exact range

For `delta0=1-q(1/2)^2`, monotonicity of q gives

\[
 D_H\ge\delta_0H-(1+\kappa)\delta_0Y_{u<1/2}.
\]

Since `eps v_j=a_j u_j/(1+u_j)` and `h_j<=1`, the low term satisfies `Y_{u<1/2}<=A_L/3`. For `n>=1`, `q(1/2)>=5/6`, hence `delta0<=11/36`. Therefore

\[
 (1+\kappa)\delta_0Y_{u<1/2}\le55A_L/108.
\]

With moment multiplier `1/eps`, deducting this from the actual low-input residual `3A_L/(2eps)` leaves `107A_L/(108eps)`. The final source explicitly reduces the residual, treats a different multiplier as requiring a scaled debit, and does not call this an additional income.

The scalar proposition is correct precisely in its stated relaxation. Over abstract `x,e>=0`, `x^2<=e(x+c0)`, with `0<delta<c0`, the least coefficient for `x<=a e+delta` is

\[
 a_*=(c_0+\delta)^2/(4c_0\delta).
\]

The minimum feasible e for fixed x is `x^2/(x+c0)`. At `a=a_*`, the residual polynomial is exactly

\[
 (a-1)x^2+(\delta-c_0)x+c_0\delta
 =\frac{[(c_0-\delta)x-2c_0\delta]^2}{4c_0\delta}.
\]

Its zero at `x=2c0 delta/(c0-delta)>0` supplies an abstract feasible witness against every smaller coefficient. This proves sufficiency and necessity **for that scalar feasible set**. The final source does not assert that the witness is geometrically realizable. Equality information lost in `q^4h^2<=q^2h`, discarded negative correlation and the full geometric source constraints make such a claim unjustified. The final range `0<delta<c0` is explicit; the formula is not being extended as a sharp claim beyond it.

The resulting Theta(n) cost for delta comparable to `delta0=Theta(1/n)` is correctly described as a difficulty with this separate Cauchy/Young absorption. It is not a lower bound on the cost of every actual geometric argument or a counterexample to the global target.

## 5. Saturated rectangle geometry and essential cost at boundaries

The final source now expressly defines member cells using retained positive-alpha labels only. This is necessary: a deleted zero-alpha cube could otherwise remove positive volume without violating packing. For a retained set K with `alpha(K)=1` and positive-volume intersection

\[
 U_K=\bigcap_{j\in K}C_j,
\]

every outside retained cube has zero-volume intersection with U_K; otherwise its positive alpha would force load greater than one on positive volume. Finiteness implies the exact member cell Omega_K equals U_K modulo null sets. An intersection with zero n-dimensional volume is not an AC cell.

For the H cost, put `chi_j=alpha_j u'_j/(1+u'_j)`. The appropriate continuous convex objective is

\[
 g_K(y)=\sum_{j\in K}\chi_j\|y-c_j\|_\infty^2/(t_j^2s_j^2).
\]

On Omega_K it agrees with the ambient cost almost everywhere. Since U_K is a compact full-dimensional rectangle, its essential cost is exactly

\[
 c_K=\operatorname*{ess\,inf}_{\Omega_K}G_H^{\rm src}
 =\min_{y\in U_K}g_K(y).
\]

A boundary minimizer is legitimate for this finite convex minimization because all its relative neighborhoods within the full-dimensional rectangle have positive volume, so AC sources can approach its value. It is not permission to put source mass on the boundary. An outside cube can touch that face and contribute an additional term to the ambient indicator cost there. The final source explicitly excludes those extra labels from g_K and does not use the pointwise ambient boundary value as the essential infimum. The ambient cap is now stated `dx-a.e.`, exactly the scope supplied by packing; all actual sources in use are AC.

The independent source-LP audit's finite-dimensional argument extends directly from unweighted alpha costs to these bounded nonnegative chi costs. The actual-cell incidence matrix and demands are unchanged. Saturation gives `sum z_K=alpha dot m'=M'=gQ'`, so the feasible set is a nonempty compact finite simplex section. Near-minimum positive-volume subsets of the exact cells give actual AC sources with exact row masses and cost at most `Phi_H+tau M'`. No exact AC optimizer, boundary atom, arbitrary incidence realization, uniform row-dual cap, or extension to nonsaturated cells is assumed.

The displayed actual-state cost identity has no extra `1/g`; it uses `H_next=int G_H^{src} dmu'`. The later diagnostic `R_sp,Y=[Phi_H/g-int G_H^{src}dmu]_+` deliberately has a normalization factor and is explicitly distinguished from the complete source difference. Neither this diagnostic nor LP attainment pays the propagation fee.

## 6. Small-model geometry and limits of the numerical decision

The final proof of `R<=N/a^n` under the full old contract is valid. Indeed `m_j<=M` and `m_j=d_j+eps v_j/lambda_j` imply `d_j<M` and

\[
 Q\ge\varepsilon\sum_j v_jd_j/(M-d_j).
\]

The function `d/(M-d)` is increasing convex on `(0,M)`. With probability weights `v_j/V`, Jensen and `kappa=eps V/Q` give `sum v_jd_j/V<=M/(1+kappa)=Q`. As `d_j>=a^n v_j`, Cauchy gives `Q>=a^n V/N`, hence the bound. For three labels and `a=32n`, this excludes an old hard branch in every `n>=1`. It is a useful exact scope restriction, not a claim against the general target.

The listed local intervals and source pieces are genuine positive-length intervals; `0<h<1` keeps the stated source pieces in the intended geometry. The left saturated cost is the stated convex quadratic. Its unrestricted minimizer is `x*=-24theta/(1+15theta)`; it reaches the admissible endpoint x=-1 at theta=1/9. This proves exactly the two displayed cost formulas. The actual-new-entropy theta expression satisfies its scalar stationarity equation, and the receiver volumes and kappa' formula are consistent with the stated new geometry.

For numerical certificate counts and the seven limits I rely on the already independent review in `NUMERIC_PLAN.md` §8, rather than claiming a fresh complete rerun. That review's analytic family takes `h=theta^2`; the final report now says so explicitly. Thus the quoted unweighted half-unit limit and weighted order-theta diagnostic are not silently quantified over arbitrary fixed h. The final source correctly states that the family relaxes the old actual half-action, old entropy KKT and old critical ratio; critical-next examples do not repair those old-state deficits. It also states that the diagnostic is not the complete actual-H source discrepancy, that a positive weighted error remains, and that no general source-transfer theorem follows. Stage 3 is expressly recorded as unexecuted.

The local numerical evidence therefore supports the claimed decision about this relaxed interface and family only. It does not validate actual critical old states, a dimension asymptotic, a summable recursion or the general weak-type target.

## 7. Executed local symbolic checks and final limits

For the local-mathematics preference, I actually ran the installed interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` with SymPy for the final algebra and model-boundary checks. Results included:

```text
rectangle boundary value: (3*th + 1)/4
rectangle minimizer derivative residual: 0
rectangle interior value: -9*th*(th - 1)/(15*th + 1)
xmin+1: -(9*th - 1)/(15*th + 1)
Jensen f second derivative: -2*M/(-M + d)**3
scalar square certificate residual: 0
low correction: 55/108
low remainder: 107/108
new entropy stationarity residual: 0
```

The Jensen derivative equals `2M/(M-d)^3>0` on the required domain. These actual symbolic checks verify algebra and signs; the full-family geometry, source-null-set argument and scope conclusions rest on the proofs above. No new MATLAB or Arb run, independent scan of all 13 numerical cases, full source-certificate rerun, or PDF compilation is claimed by this audit.

The frozen report's opening and final paragraph preserve the intended stopping point: the same actual H source difference, signed growth correlation and weighted coverage losses must still be settled jointly in the original complete ledger. The report does not mark this missing joint payment as proved or call the new state itself a paid budget.
