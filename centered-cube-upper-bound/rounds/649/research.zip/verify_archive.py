from pathlib import Path
import ast,hashlib,json,re,subprocess,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
assert files==set(manifest['files'])
for name,digest in manifest['files'].items():
 p=root/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
s=(root/'REPORT.tex').read_text();stack=[]
for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
assert all(ord(c)>=32 or c in '\n\t' for c in s)
sha=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ['FINAL_GEOMETRY_AUDIT.md','FINAL_LEDGER_AUDIT.md']:assert sha in (root/name).read_text()
checks=[('repro/check_exact.py',[])]+[('repro/numeric/check.py',[stage]) for stage in ['initial','boundary','expanded']]
for name,args in checks:
 r=subprocess.run([sys.executable,'-B',str(root/name),*args],cwd=root,capture_output=True,text=True,check=True)
 assert r.stdout.strip()
 print('PASS',name,*args)
print(json.dumps({'manifest_files':len(files),'latex_labels':len(labels),'report_sha256':sha,'bounded_replays':len(checks),'scope':'No PDF, no claim of global theorem or actual-source contraction.'},ensure_ascii=False))
