import sys,json,platform,time
from fractions import Fraction as F
import sympy as sp
from flint import arb,ctx
import flint
ctx.prec=256
T,K=sp.symbols('theta kappa',positive=True)
X=sp.symbols('x',real=True)
P=T*(2*X+3)**2+(1-T)*X**2/4
xstar=sp.solve(sp.diff(P,X),X)[0]
assert sp.simplify(xstar+24*T/(1+15*T))==0
assert sp.simplify(P.subs(X,-1)-(1+3*T)/4)==0
assert sp.simplify(P.subs(X,xstar)-9*T*(1-T)/(1+15*T))==0
tau=T*(1-T)/(1-3*T); kp=sp.factor(6*tau/(4-2*T))
assert sp.factor((kp-K)*(4-2*T)*(1-3*T)+6*((1+K)*T**2-(1+sp.Rational(7,3)*K)*T+2*K/3))==0
assert sp.limit(kp,T,0)==0

def st(x): return x.str(35,more=True) if isinstance(x,arb) else str(x)
def ar(x): return x if isinstance(x,arb) else arb(str(x))
def sqrt(x): return x.sqrt() if isinstance(x,arb) else arb(str(x)).sqrt()
def result(th, h, g, epsilon, mode, label):
 Q=4-2*th; S=2*th; kap=g-1
 if (th<=F(1,9) if isinstance(th,F) else th<=arb(1)/9): cost=(1+3*th)/4; branch='boundary'
 else: cost=9*th*(1-th)/(1+15*th); branch='interior'
 if mode=='actual':
  ta=epsilon/32; us=[ta/th,ta/(1-th),ta/th]; mp=[1+us[0],4*(1+us[1]),1+us[2]]
 else:
  mp=[g*Q/2,g*Q,g*Q/2]; us=[mp[0]-1,mp[1]/4-1,mp[2]-1]
 al=[th,1-th,th]; m=[1,4,1]
 phi=(mp[0]+mp[2])*cost; primal=phi; dual=cost*(mp[0]+mp[2])
 if isinstance(th,arb): assert (mp[1]-mp[0]-mp[2]).contains(0)
 else: assert mp[1]==mp[0]+mp[2]
 I=2*th*(1-2*h+4*h*h/3)+2*(1-th)*((F(1,4) if isinstance(h,F) else arb(1)/4)+h/4+h*h/12)+2*(1-th)*h*h/12
 rsp=phi/g-I
 if not rsp>0: raise ArithmeticError('nonpositive Rsp')
 E=sum(al[i]*m[i]*(us[i]-kap)**2/epsilon for i in range(3))
 delta=sum(al[i]*m[i]*abs(us[i]-kap) for i in range(3))/g
 ghost=sqrt(epsilon*Q*E)/ar(g)
 D1=S+delta; D2=ar(S)+ghost
 # Cauchy certificate; Arb intervals enclose any equality.
 diff=ghost-ar(delta)
 if isinstance(diff,arb): assert diff>=0 or diff.contains(0)
 else: assert diff>=0
 A=th*us[0]/(1+us[0]); B=(1-th)*us[1]/(1+us[1])
 if 8*A<=B: cy=A+B/4; ybranch='boundary'
 else: cy=9*A*B/(16*A+B); ybranch='interior'
 Iy=2*A*(1-2*h+4*h*h/3)+2*B*((F(1,4) if isinstance(h,F) else arb(1)/4)+h/4+h*h/12)+2*B*h*h/12
 yraw=(mp[0]+mp[2])*cy/g-Iy
 assert yraw>0
 d={'Y_cell_cost':cy,'Y_branch':ybranch,'Y_normalized_phi':(mp[0]+mp[2])*cy/g,'Y_mu_G':Iy,'Rsp_Y_signed':yraw,'Rsp_Y':yraw,'Y_ratio1':yraw/D1,'Y_ratio2':ar(yraw)/D2,'Y_residual_C1_D1':yraw-D1,'Y_residual_C1_D2':ar(yraw)-D2,'mode':mode,'input':label,'theta':th,'h':h,'epsilon':epsilon,'Q_prime':Q,'kappa_prime':kap,'S':S,'cell_cost':cost,'lp_primal_phi':primal,'lp_dual_phi':dual,'normalized_phi':phi/g,'mu_G':I,'Rsp':rsp,'E_prime':E,'Delta':delta,'sqrt_epsilon_Q_E_over_g':ghost,'D1':D1,'D2':D2,'ratio1':rsp/D1,'ratio2':ar(rsp)/D2,'residual_C1_D1':rsp-D1,'residual_C1_D2':ar(rsp)-D2,'m_prime_leaf':mp[0],'m_prime_middle':mp[1],'cell_branch':branch}
 if mode=='actual':
  # Exact multipliers y12=y23=1+tau/theta and all three KKT residuals.
  y=1+ta/th
  d.update({'tau':ta,'p1':F(1,32),'p2':F(1,8),'p3':F(1,32),'dual_multiplier':y,'kkt_leaf':1+ta/th-y,'kkt_middle':4+4*ta/(1-th)-2*y,'new_mass_residual':mp[1]-mp[0]-mp[2]})
  e2=4*ta*(1-2*th)**2/(32*(2-th)*th*(1-th))
  d['E2_residual']=E-e2
  for key in ['kkt_leaf','kkt_middle','new_mass_residual','E2_residual']:
   v=d[key]; assert v.contains(0) if isinstance(v,arb) else v==0
 return {k:st(v) for k,v in d.items()}

def main(stage):
 rows=[]
 if stage=='initial':
  for t in [F(1,16),F(1,64),F(1,256)]:
   for g in [F(9,2),F(5)]: rows.append(result(t,t*t,g,F(1),'synthetic',f'theta={t},g={g}'))
 elif stage=='boundary':
  for t in [F(1,20),F(1,50)]:
   ta=t*(1-t)/(1-3*t); eps=32*ta; kp=6*ta/(4-2*t)
   rows.append(result(t,t*t,1+kp,eps,'actual',f'theta={t}'))
  for txt in ['1/64','1/256','1/1024']:
   ta=arb(txt); th=2*ta/(1+3*ta+(1+2*ta+9*ta**2).sqrt()); eps=32*ta; kp=6*ta/(4-2*th)
   rows.append(result(th,ta**2,1+kp,eps,'actual',f'tau={txt}'))
 elif stage=='expanded':
  for txt in ['7/2','4']:
   K=arb(txt); b=1+7*K/3; th=(4*K/3)/(b+(b*b-(8*K/3)*(1+K)).sqrt()); ta=th*(1-th)/(1-3*th); eps=32*ta
   rows.append(result(th,arb('1/128'),1+K,eps,'actual',f'kappa_prime={txt}'))
 else: raise ValueError(stage)
 return rows

if __name__=='__main__':
 start=time.perf_counter(); stage=sys.argv[1]
 print(json.dumps({'stage':stage,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,'xstar':str(xstar),'critical_kappa_polynomial':'(1+k)*theta^2-(1+7*k/3)*theta+2*k/3'}))
 rows=main(stage)
 for r in rows: print(json.dumps(r))
 print(json.dumps({'cases':len(rows),'elapsed_seconds':time.perf_counter()-start}))
