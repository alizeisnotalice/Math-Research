% Independent floating minimization of the actual-new-state cell costs.
% This is a three-row relaxation, not the full critical old-half state.
r649_theta = [1/1000, 1/50, 1/20, 1/9, 1/5, 3/10];
r649_out = zeros(numel(r649_theta),5);
for r649_i = 1:numel(r649_theta)
    r649_t = r649_theta(r649_i);
    r649_tau = r649_t*(1-r649_t)/(1-3*r649_t);
    r649_u1 = r649_tau/r649_t;
    r649_u2 = r649_tau/(1-r649_t);
    r649_A = r649_t*r649_u1/(1+r649_u1);
    r649_B = (1-r649_t)*r649_u2/(1+r649_u2);
    r649_fun = @(x) r649_t*(2*x+3).^2+(1-r649_t)*x.^2/4;
    r649_funY = @(x) r649_A*(2*x+3).^2+r649_B*x.^2/4;
    [~,r649_cost] = fminbnd(r649_fun,-2,-1,optimset('TolX',1e-12,'Display','off'));
    [~,r649_costY] = fminbnd(r649_funY,-2,-1,optimset('TolX',1e-12,'Display','off'));
    r649_cost = min([r649_cost,r649_fun(-2),r649_fun(-1)]);
    r649_costY = min([r649_costY,r649_funY(-2),r649_funY(-1)]);
    if r649_t<=1/9
        r649_exact=(1+3*r649_t)/4;
    else
        r649_exact=9*r649_t*(1-r649_t)/(1+15*r649_t);
    end
    if 8*r649_A<=r649_B
        r649_exactY=r649_A+r649_B/4;
    else
        r649_exactY=9*r649_A*r649_B/(16*r649_A+r649_B);
    end
    r649_out(r649_i,:)=[r649_t,r649_cost,r649_costY,r649_cost-r649_exact,r649_costY-r649_exactY];
end
assert(max(abs(r649_out(:,4:5)),[],'all')<1e-10);
fprintf('MATLAB %s; rows theta,cost,costY,residual,residualY\n',version);
disp(r649_out);
fprintf('maximum_abs_residual %.17g\n',max(abs(r649_out(:,4:5)),[],'all'));
