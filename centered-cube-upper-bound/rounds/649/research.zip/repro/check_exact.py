"""Exact R649 ledger identities and the explicitly relaxed AC model limits."""
import sympy as s, json, platform
u,k,q,v,ep,h,g,p,mp,krow,hnew,oi,fi=s.symbols('u k q v ep h g p mp krow hnew oi fi',positive=True)
a=ep*v*(1+u)/u
H=(1+k)*ep*v*h
D=(1+k)*ep*v*(1-q*q)*h
C=ep*v*(u-k)*q*q*h
res={
 'drift':s.expand(H-D+C-a*u*q*q*h),
 'normalization':s.simplify(g*ep*p/g*hnew-ep*p*hnew),
 'ownership':s.expand(ep*((1+u)*v-oi+fi)*krow-a*u*krow-ep*(fi-oi)*krow),
 'source_lost':s.expand((ep*p*hnew-ep*((1+u)*v-oi+fi)*krow)-ep*oi*krow-(ep*p*hnew-a*u*krow-ep*fi*krow)),
 'low_residual':s.Rational(3,2)-s.Rational(55,108)-s.Rational(107,108),
}
x,c0,de=s.symbols('x c0 de',positive=True)
coef=(c0+de)**2/(4*c0*de)
res['sharp_square']=s.factor((coef-1)*x*x+(de-c0)*x+c0*de-((c0-de)*x-2*c0*de)**2/(4*c0*de))
assert all(s.simplify(y)==0 for y in res.values()),res
T=s.symbols('theta',positive=True); X=s.symbols('x',real=True)
width=T*T; tau=T*(1-T)/(1-3*T); eps=32*tau
Q=4-2*T; kap=6*tau/Q; scale=1+kap
u1=tau/T;u2=tau/(1-T);m1=1+u1
cost=(1+3*T)/4
Gleaf=T*(2*X+3)**2+(1-T)*X**2/4
Gcenter=(1-T)*X**2/4
I=2*s.integrate(Gleaf,(X,-1-width,-1))/width+s.integrate(Gcenter,(X,-width,width))/width
rsp=s.factor(2*m1*cost/scale-I)
E=s.factor((2*T*(u1-kap)**2+4*(1-T)*(u2-kap)**2)/eps)
Delta=s.factor((2*T*(u1-kap)+4*(1-T)*(kap-u2))/scale)
AA=T*u1/(1+u1);BB=(1-T)*u2/(1+u2)
assert s.simplify(BB-2*AA)==0
cy=9*AA*BB/(16*AA+BB)
Gy=AA*(2*X+3)**2+BB*X**2/4
Iy=2*s.integrate(Gy,(X,-1-width,-1))/width+s.integrate(BB*X**2/4,(X,-width,width))/width
ry=s.factor(2*m1*cy/scale-Iy)
expressions={'Rsp':(rsp,s.Rational(1,2)),'kappa_over_theta':(kap/T,s.Rational(3,2)),'Eprime':(E,s.Rational(1,16)),'Delta_over_theta':(Delta/T,4),'TV_squared':(eps*Q*E/scale**2,0),'weighted_defect_over_theta':(ry/T,s.Rational(1,2)),'weighted_fee_ratio':(ry/(2*T+Delta),s.Rational(1,12))}
limits={}
for name,(expr,wanted) in expressions.items():
 value=s.limit(expr,T,0,dir='+');assert value==wanted,(name,value,wanted);limits[name]=str(value)
print(json.dumps({'python':platform.python_version(),'sympy':s.__version__,'zero_identities':list(res),'AC_width':'theta^2','exact_limits':limits,'scope':'Finite ledger identities and local relaxed actual-new-KKT family; no full old-half critical realization or global bound.'},ensure_ascii=False,indent=2))
