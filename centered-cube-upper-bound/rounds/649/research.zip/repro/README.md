# 实际复现记录

指定解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
已实际使用 Python3.12.14、SymPy1.14.0、python-flint0.9.0，Arb256位。

解压根目录执行（python替换为指定完整路径）：

```
python -B repro/check_exact.py
python -B repro/numeric/check.py initial
python -B repro/numeric/check.py boundary
python -B repro/numeric/check.py expanded
```

第一条核验6项符号恒等式，并从真实AC区间积分重建7个解析极限；输出在exact_results.json。后三条分别6、5、2个有限模型样例，解析条件与有理/Arb误差边界见numeric/README.md和NUMERIC_PLAN.md。没有把有限结果外推一般维数；这些模型均未实现完整旧临界半动作。

MATLAB实际运行numeric/crosscheck.m，版本R2026a Update4。六组直接浮点极小化与解析公式比较的最大残差为5.5511151231257827e-17；输出摘要在numeric/MATLAB_RESULT.md。这是浮点交叉检查，不是区间证书。归档自动校验不再次启动MATLAB。

verify_archive.py 检查完整清单、LaTeX环境/引用、审计哈希以及上述四条有界命令。它不编译PDF，不认证实际来源传播或一般上界。
