# R649 bounded numeric plan: geometric source-LP transfer

Owner: independent plan/certificate interface audit. Execution owner: existing Terra worker `/root/r647_far_certificate`, files under `/tmp/ccu_r649/numeric/`. This plan changes no completed report or other worker file. No large computation, arbitrary incidence-matrix sweep, PDF, or Git is authorized by this plan.

## 1. First gate: small N cannot be a critical hard state

Under the actual old finite contract, `m_j=mu(A_j)<=M`, and positive `v_j,lambda_j,epsilon` give `d_j<M` and
\[
\lambda_j\ge\frac{\epsilon v_j}{M-d_j}.
\]
Therefore
\[
Q=\sum_jd_j\lambda_j\ge\epsilon\sum_j\frac{v_jd_j}{M-d_j}.
\]
Put `p_j=v_j/V` and `kappa=epsilon V/Q`. Convexity of `d/(M-d)` on `[0,M)` yields
\[
\frac{\sum_jp_jd_j}{M-\sum_jp_jd_j}
\le\sum_jp_j\frac{d_j}{M-d_j}\le\frac1\kappa.
\]
Since `M=(1+kappa)Q`, this proves
\[
Q\ge\frac{\sum_jv_jd_j}{V}
\ge a^n\frac{\sum_jv_j^2}{V}\ge\frac{a^n V}{N}.
\]
The middle inequality is the actual ownership bound `v_j<=|B_j|=d_j/a^n`; the last is Cauchy. Thus
\[
\boxed{R=V/Q\le N/a^n.}
\]
`R>1` requires `N>a^n`. For `a=32n`, the first possible counts are 33 in dimension 1, 4097 in dimension 2, and 884737 in dimension 3. This is stronger than the crude bound with an extra `(1+kappa)` factor. It does not prove those counts suffice, and this plan will not attempt to construct a critical full state at those sizes.

Every N=3 or N=4 experiment below must carry the label **local geometric relaxation, not a complete hard state**. Critical `kappa` alone does not imply critical `R`; choosing epsilon large can keep `kappa` in `[7/2,4]` while `R<<1`.

## 2. Precise source-transfer quantities and decisions

For genuine retained positive weights `alpha` on actual new cubes `C_k=Q(c_k,rho_k)`, compute the full a.e. packing load and all positive-volume membership cells. Let
\[
G(x)=\sum_k\alpha_k1_{C_k}(x)\frac{\|x-c_k\|_\infty^2}{\rho_k^2},
\quad Q'=\sum_k\alpha_km_k,
\quad S=M-Q'.
\]
On each saturated positive-volume cell `Omega_K`, `alpha(K)=1`, and
\[
c_K=\operatorname{essinf}_{\Omega_K}G,
\quad\Phi=\min_{z\ge0}\sum_Kc_Kz_K,
\quad\sum_{K\ni k}z_K=m'_k.
\]
Use true geometric cells only. Null contact cells are never LP columns. The geometry worker separately audits the minimization over the saturated rectangle; execution must preserve that interface rather than replace the incidence with an arbitrary binary matrix.

When actual new ownership is imposed,
\[
u'_k=\frac{\epsilon p_k}{\alpha_km_k},\quad
\kappa'=\frac{\epsilon W}{Q'},\quad g=1+\kappa',\quad
m'_k=m_k(1+u'_k),
\quad E'=\epsilon^{-1}\sum_k\alpha_km_k(u'_k-\kappa')^2.
\]
The tested spatial defect is
\[
R_{\rm sp}=[\Phi/g-\int G\,d\mu]_+.
\]
Record the two distinct candidate payment denominators
\[
D_1=S+\Delta,\qquad
\Delta=\frac1g\sum_k\alpha_km_k|u'_k-\kappa'|,
\]
\[
D_2=S+\frac{\sqrt{\epsilon Q'E'}}g.
\]
Here `Delta <= sqrt(epsilon Q'E')/g` is a verified Cauchy comparison, not an assumption. `E'` itself need not tend to zero when epsilon varies. Do not claim an `S+E'` counterexample merely because `D_2` tends to zero.

The execution should report `R_sp`, `S`, `Delta`, the square-root term, `E'`, `epsilon`, `kappa'`, and both ratios where the denominator is positive. For a proposed fixed C, certify the **signed residual** `R_sp-C D_i`; do not classify a near-zero floating result. A sequence of growing ratios may refute a uniform bound only when a mathematically justified limiting family and retained assumptions are stated. A finite successful grid never proves the full uniform estimate.

## 3. Stage 1: analytic near-saturation obstruction, six rational fixtures

Purpose: determine whether **new packing geometry + AC source + feasible saturated-cell source LP alone** could prove the proposed extension. This is not a counterexample under actual ownership or the old half action.

Take `n=1,a=32` and true intervals
\[
C_1=[-2,-1],\quad C_2=[-2,2],\quad C_3=[1,2],
\quad m=(1,4,1)=|C|.
\]
Let `alpha=(theta,1-theta,theta)`, with `0<theta<1/9`. Actual new packing is valid, saturated positive-volume cells are exactly `12` and `23`, and singleton `2` is unsaturated. Put real AC source mass 1 uniformly on `[-1-h,-1]`, mass 1 on `[1,1+h]`, and mass 2 uniformly on `[-h,h]`, with `0<h<1/4`. Thus `mu(C)=(1,4,1)`, `M=4`, `Q'=4-2theta`, and `S=2theta` exactly.

For the two saturated cells, direct constrained minimization gives
\[
c_{12}=c_{23}=c_\theta=\frac14+\frac34\theta
\quad(0<\theta\le1/9).
\]
For later use, the full formula on `0<theta<1` is
\[
c_\theta=\begin{cases}1/4+3\theta/4,&\theta\le1/9,\\
9\theta(1-\theta)/(1+15\theta),&\theta\ge1/9.
\end{cases}
\]
The unrestricted left-cell minimizer is `x*=-24theta/(1+15theta)`; it reaches `x=-1` at `theta=1/9` and never crosses `x=-2`. This factor and threshold must be independently checked by the executor.

The AC integral is exactly
\[
I_\mu:=\int Gd\mu
=2\theta(1-2h+4h^2/3)
 +2(1-\theta)(1/4+h/4+h^2/12)
 +2(1-\theta)h^2/12.
\tag{I}
\]
Choose synthetic `g in {9/2,5}` and feasible next demands
\[
m'_1=m'_3=gQ'/2,\qquad m'_2=gQ',
\quad u'_k=m'_k/m_k-1.
\]
Then `sum alpha m'=gQ'`, so the weighted mean of `u'` is `kappa'=g-1`. The source LP is forced to `z12=z23=gQ'/2`, hence `Phi/g=Q'c_theta`. As `theta,h->0`, `R_sp->1/2`, while `S` and `Delta` tend to zero. This disproves a uniform extension based only on these relaxed constraints.

Pre-register `theta in {1/16,1/64,1/256}`, `h=theta^2`, and the two g values: six fixtures plus the analytic limit. Use exact Fraction/SymPy rational evaluation; there is no floating tolerance. **Retained:** exact intervals, positive-volume cells, actual packing alpha, real AC source and exact row moments, feasible saturated LP, exact balanced mean next growth. **Relaxed:** old A/KKT/saturation, actual half action, actual new receiver ownership p, and `R>1`. Synthetic `u'` must not be called the actual entropy update.

Stage 1 stop: once the displayed limit and six exact residuals are certified, stop this model. It identifies the missing assumption; more samples add no decision value.

## 4. Stage 2: same geometry with actual new receivers and actual new KKT

This stage is decisive beyond a bare SP5/source-feasibility counterexample. Keep the same C intervals and the same AC source. The real receivers have disjoint interiors and lengths
\[
p=(1,4,1)/a,\qquad W=6/a.
\]
There is no ownership freedom and no deleted label. Solve the real entropy problem on the interval packing polytope. Symmetry and monotonicity give `alpha=(theta,1-theta,theta)`, where `tau=epsilon/a` and
\[
-2+\tau(2/\theta-4/(1-\theta))=0,
\quad\theta^2-(1+3\tau)\theta+\tau=0.
\]
Use the stable small-root formula
\[
\theta=\frac{2\tau}{1+3\tau+\sqrt{1+2\tau+9\tau^2}}.
\]
Equivalently, choose rational `0<theta<1/3` first, then set `tau=theta(1-theta)/(1-3theta)`, producing an entirely rational exact fixture. The full new KKT equations must be checked, including feasibility, active packing constraints, gradient multipliers, and `m'_2=m'_1+m'_3`; do not rely solely on an optimizer's success flag.

The exact actual quantities are
\[
u'_1=u'_3=\tau/\theta,\quad u'_2=\tau/(1-\theta),
\quad \kappa'=\frac{6\tau}{4-2\theta},\quad S=2\theta,
\]
\[
E'=\frac{4\tau(1-2\theta)^2}{a(2-\theta)\theta(1-\theta)}.
\tag{E2}
\]
The source LP again has unique masses, so `Phi/g=Q'c_theta`; use (I) for the AC integral. Along `tau->0`, `theta~tau`, `kappa'~(3/2)theta`, `R_sp->1/2`, `S,Delta,sqrt(epsilon Q'E')/g->0`, but `E'->2/a=1/16`. This is a geometric, actual-new-entropy failure of a uniform spatial bound **without a lower critical bound on kappa' or genuine old-half constraints**.

Pre-register at most seven fixtures:

- Rational-theta fixtures `theta=1/20,1/50` with `h=theta^2` and the rational tau formula.
- `tau=1/64,1/256,1/1024`, `h=tau^2`, with an exact algebraic root enclosure.
- Two critical-next calibration fixtures `kappa'=7/2,4`. Solve the small root of
  `(1+kappa')theta^2-(1+7kappa'/3)theta+2kappa'/3=0`, then compute tau as above. These are in a different regime; `theta` is about 0.3, so the interior branch of c must be used.

Use rational isolating intervals or Arb outward enclosures at 128 bits; if a desired residual sign is unresolved, refine to 256 bits only for that fixture. Root/KKT residuals must be zero symbolically or have an exact algebraic certificate. For integral and LP comparisons retain exact algebraic expressions and outward intervals; target absolute enclosure width `<=2^-80 max(1,M)` at 128 bits. Do not use a floating `1e-12` cell filter.

**Retained:** real cube geometry, actual B' receivers/ownership, actual alpha entropy optimum and saturation, genuine AC mu, exact `mu(C)=m=|C|`, actual new u'/kappa'/E', feasible actual next dual LP. **Relaxed:** a genuine old state `A` with positive old growth, old lambda saturation/KKT, the actual half action, the minimizing-gamma product-law realization, and old critical `R>1`. In particular `A=C` would have old `u=0`; never silently make that identification. Stage 2 is not a complete hard-state counterexample.

## 5. Stage 3: bounded real old-KKT and half-action calibration

Purpose: determine which Stage-2 failure mechanism survives when genuine old KKT and nonidentity half geometry are restored. This is a small local calibration, not an arbitrary matrix search.

Use old intervals
\[
A_2=[-1,1],\quad A_1=[-1,-1/2],\quad
A_3=[1/2,1],\quad A_4=[-1/2,1/2].
\]
The three leaves partition the large interval modulo endpoints. Set old weights `lambda_2=l`, `lambda_1=lambda_3=lambda_4=1-l`. Put AC mu uniformly on short boxes centered at `-3/4,0,3/4`, of halfwidth `h=1/128`, with masses `1,2kappa,1`. Then
\[
d=(1/2,2,1/2,1),\quad
m=(1,2(1+\kappa),1,2\kappa),\quad Q=2,
\quad M=2(1+\kappa),
\]
in the order `1,2,3,4`; old saturation is exact on every source box. Choose
\[
v_j=\lambda_j(m_j-d_j)/\epsilon.
\]
These are actual old entropy KKT data: m, saturation, and nonnegative AC source are a complete supporting-gradient witness. Verify the disjoint owned-piece realizability rather than merely checking volumes. With `epsilon>=256`, a deterministic construction is available: put I1/I3 in their separated tiny receivers; put I4 as a centered interval of length v4 inside B4; choose I2 of length v2 from B2 minus I4 using left-to-right interval pieces. Check every containment, length, and disjointness exactly. Old ownership need not fill the entire old receive union, in accordance with the authoritative R649 contract.

Pre-register no more than eight scalar fixtures: `kappa in {7/2,4}`, `l in {1/2,3/4}`, `epsilon in {256,512}`. Every such fixture has critical kappa but `R=kappa/epsilon<<1`; label it accordingly. Do not vary masses or incidence matrices after seeing a result.

For each fixture initially freeze legal anchors at the three source-box centers, with X2 at 0. Form the **nonidentity** half action from the real `u=m/d-1`; compute C from that formula, not by prescribing C=A. Partition every E_j and B'_j by exact interval endpoints. Use deterministic E-priority ownership, for example fixed label order `(2,4,1,3)` on the E union and then the same order on fill. Delete only truly zero p, then solve the real new entropy alpha and record p, active cells, m', u', kappa', E', S. Compute G, its exact AC integral, and the geometric source LP. Preserve all original E rows in overlap quantities.

The frozen anchors are legal support points of mu and of the corresponding A_j. This does **not** itself certify that they are support points of the center-minimizing gamma_j. Therefore this calibration is pathwise legal-half geometry and does not yet certify an event of the prescribed product law. If, and only if, it exposes a material residual relevant to a proposed bound, a follow-up must certify positive gamma_j mass in explicit small neighborhoods of those anchors, or replace them by certified allowed anchor neighborhoods. The required minimizing assignment can be solved on the three AC boxes by piecewise quadratic price comparisons; do not infer it from old lambda or point sampling. No claim about the full expected target follows from a zero-probability representative tuple.

For these eight cases, floating optimization may nominate a solution, but every retained certificate must include a feasible packing alpha, exact/interval KKT residuals and nonnegative multipliers, an explicit actual ownership partition, AC source data, and source-LP primal/dual witnesses. Any unresolved optimizer or contact issue is **inconclusive**, never a counterexample. An exact analytic symmetric reduction is preferred over increasing the scan count.

## 6. Certificate format and review gate

### Same-fixture receiver-weighted comparison (root's added request)

Without adding fixtures, also compute
\[
G_Y(x)=\sum_k\alpha_k\frac{u'_k}{1+u'_k}1_{C_k}(x)
 \frac{\|x-c_k\|_\infty^2}{\rho_k^2},
\quad c_{K,Y}=\operatorname{essinf}_{\Omega_K}G_Y,
\]
the corresponding source-LP minimum `Phi_Y` with the **same** demands `m'_k`, and diagnostic `R_sp,Y=[Phi_Y/g-int G_Y dmu]_+`. No new global source-transfer theorem or equivalence to the complete target is assumed. Stage-1 u' remains synthetic; Stage-2 u' is the actual entropy update.

For the symmetric three-interval fixture put `A=theta u'_leaf/(1+u'_leaf)` and `B=(1-theta)u'_2/(1+u'_2)`. On the left saturated interval,
\[
G_Y=A(2x+3)^2+B x^2/4,\quad x_*=-24A/(16A+B),
\]
\[
c_Y=\begin{cases}A+B/4,&8A\le B,\\
9AB/(16A+B),&8A\ge B.
\end{cases}
\]
For positive A,B the unconstrained minimizer never reaches x=-2; at 8A=B the two formulas agree. Use the same exact AC interval integration, not a sampling approximation. Record weighted and unweighted defects next to each other. In the small-tau actual-new-KKT family both A and B tend to zero, so the old unweighted constant-cost obstruction may disappear; this is precisely why it must be measured, not a reason to declare the weighted problem solved. The plan author actually checked all three weighted stationary/minimum/boundary identities in local SymPy, with zero residuals.

Each stage records assumptions retained/relaxed, geometry endpoints, receiver intervals, source boxes and densities, zero-volume contacts, p, alpha and KKT witness, all scalar definitions in section 2, source-LP columns and primal/dual values, G minimum branch, actual command/version, and arithmetic error convention. Preserve failures and corrections. The source LP must have primal/dual gap exactly zero or certified overlapping outward bounds of the stated width; a missing feasible dual does not certify a numerical minimum.

For an AC realization of a c_K infimum attained only at a boundary, provide a positive-length interval inside the correct positive-volume saturated cell with `G<c_K+tau_AC`. Use an explicit tolerance such as `tau_AC=2^-40` for fixture construction; it is an approximation of the source selection, not a geometric transfer fee. Never place a source atom on a null boundary or treat c_K as AC-attained without justification.

The execution handoff should first return Stage 1/2 exact certificates and the assumption table. The independent audit owner will filter them before any Stage-3 expansion. Stop once a theorem parameter is shown essential, a proposed ratio is analytically unbounded in its stated relaxed class, or a bounded exact calibration is complete. None of these outcomes proves or disproves the complete critical half-action root bound.

## 7. Actual plan-side checks

The plan author ran the local math Python 3.12.14 / SymPy 1.14.0 on five exact residuals: the G stationary point, interior c value, boundary c value, actual-new-entropy quadratic equation, and formula (E2). All five residuals were zero. The scale thresholds 32,4096,884736 were also actually computed before adding one for strict R>1. No fixture sweep or large computation was performed by the plan author.

## 8. Independent review of completed Stage 1/2 certificates

**Accepted within the explicitly relaxed scopes above.** Terra executed six synthetic fixtures, five actual-new-entropy fixtures, and two critical-next calibrations. Stage 3 was not executed. I read `numeric/check.py`, `numeric/README.md`, and the boundary/expanded records; checked the real interval geometry, AC densities, actual receiver lengths, packing constraints and KKT multipliers; and independently reconstructed the AC integrals by symbolic integration rather than merely reusing the executor's integral formula.

The source LP is certified exactly by primal `z12=m'_1,z23=m'_3` and dual `(c,0,c)`, with `m'_2=m'_1+m'_3`. The same witnesses apply to c_Y. Positive multipliers `y12=y23=1+tau/theta` certify the actual entropy optimum in Stage 2. The approximate AC attainment uses positive-length subintervals in the saturated cells; no boundary atom is used. A derivative cap 6 on those intervals suffices for the stated `2^-40` approximation from interval length `2^-44`.

Independent local SymPy execution reproduced the two exact rational records `theta=1/20,1/50` for `R_sp,R_sp,Y,E',Delta`. It also independently certified seven limits from the actual-new-entropy family with `h=theta^2`:
\[
R_{sp}\to1/2,\quad\kappa'/\theta\to3/2,\quad E'\to1/16,
\quad\Delta/\theta\to4,\quad\epsilon Q'E'/g^2\to0,
\]
\[
R_{sp,Y}/\theta\to1/2,\qquad
R_{sp,Y}/(S+\Delta)\to1/12.
\]
In this family the new coefficients satisfy the exact relation `B=2A`. Thus the weighted diagnostic really removes the constant unweighted defect in this star family, while leaving a positive order-theta defect. This is a decision about this family only, not a uniform weighted source-transfer theorem. The critical-next calibrations have `R_sp,Y` about 0.110662 and 0.111648 and do not invalidate the scope restriction `R'<1`.

Accepted numerical artifact hashes:

- `numeric/check.py`: `d2b624909226bd50acae96940c02ee72a9f34386f38c78935413e1e1568067ea`.
- `numeric/initial.jsonl`: `a234391cd45e8b908306bc367fd7faa1cf585b87045a21c72c97902d26038a86`.
- `numeric/boundary.jsonl`: `5479e31241251ff96628716d45db46b047419c57348cb8c95f6776f56930d9ca`.
- `numeric/expanded.jsonl`: `f6a9e025a735b0dd60f0670f215151c5b05da19694477fbaf7471c4cc85a3c72`.

The README records an earlier plan snapshot hash, predating this review addendum; it is a snapshot identifier rather than the current file hash. The independent checks above were actually executed with the local math Python 3.12.14 / SymPy 1.14.0. They did not rerun an exhaustive scan or produce any actual critical old-half input. The next permitted step is a separate root decision about Stage 3 or a proved weighted-transfer statement, not expansion of this already decisive relaxed family.
