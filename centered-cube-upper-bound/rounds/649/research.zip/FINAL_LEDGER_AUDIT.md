# R649 final ledger and probability audit

**Result: PASS for the integrated ledger/probability scope. The full high-incoming target and an actual contractive recursion remain unproved.**

Bound report: `/tmp/ccu_r649_final/REPORT.tex`

SHA-256: `7929bd2de8ab4712a5a67d5448366d679eaa0ce6455f76603af86d0beee1786d`

Scope: the same complete action/fee ledger, the unified uB-weighted assignment law, actual normalized H versus its old-source prototype, signed source/lost-copy merging, once-only growth/fill/low-residual spending, and the abstract/conclusion limits. Earlier passed proofs/calculations were not rerun. Finite source-LP strong duality and numeric certificates have separate audits; only their ledger interface is checked here.

## 1. Complete target and a single actual branch

The old contract correctly assumes disjoint positive I_j subset B_j without requiring them to cover the full old receiver union. Its V is sum_j v_j. The new E-priority owner partition covers the complete new receiver union, and the actual alpha is recomputed after genuine zero owners are deleted. Every alpha-dependent credit uses that same optimizer/outcome.

The exact old physical/entropy ledger D=E-O+F+RS is unchanged. The complete target is the R647-648 sufficient high-incoming estimate, with the original low-input residual 3A_L/(2eps). Its equivalent capacity form retains -S_L. No H quantity is inserted as free income, no extra copy of J/source credit is added, and historical contact/deletion/general-input restoration is retained.

The gamma selected in section 3 is the single fixed feasible assignment for the entire current product draw, minimizing sum int u_j B(u_j)r_j^2 dgamma_j. This is an explicit replacement of R648's unweighted center minimum. The report correctly abandons both the unweighted Z_gamma<=Z_lambda assertion at varying u and old physical F-optimality/coercivity. The full action ledger and low-input/actual-alpha inequalities require only feasibility and legal half actions, so they remain valid with expectation under this newly fixed product law. Values computed under earlier assignment laws are not reused.

The new objective has fixed finite old row coefficients before sampling; its Eulerian benchmark is feasible. Its existence is the same finite-state weak-star compactness argument. This one-step statement does not silently assert a globally measurable minimizing policy across arbitrary infinite state trajectories.

## 2. Actual successor H and adaptive normalization

H=(1+kappa)eps sum v_j h_j uses genuine current row conditional means mu|Aj/m_j. It is nonnegative and bounded by kappa M<=4M on current critical states. The terminal concerns actual old ownership V and does not require full old-union coverage.

For retained next labels h'_j is the genuine mean against mu'|Cj/m'_j, not an old-source substitute. Common spatial/mass scaling preserves that conditional mean, and normalized owner volume is p_j/g. Therefore H_next=eps sum p_j h'_j holds PATHWISE by cancellation of g=1+kappa', before expectation. No independence of g, p or alpha is assumed. The report uses only retained positive denominators and does not define u'=0/0 on deleted rows.

The old-source prototype H_proto=eps sum p_j k_j has a different conditional source mean. Its exact all-old expansion is

  H_proto=sum_all a_j u_j k_j+eps sum_all(f_j-o_j)k_j.

For a deleted old row p=0, o=ell and f=0, so its positive old a_j u_j k_j is cancelled by its retained negative lost-copy term. It is not erased from the old input account. The signed ownership term remains inside expectation with its true adaptive dependence; it is not factored into an unweighted fill-minus-overlap number.

## 3. Prototype propagation and the precise contraction limit

The nonaveraged own-anchor inequality gives E k_j<=A(u_j)h_j+B(u_j)g_j^anc. Weighted optimality controls exactly sum a_j u_j B(u_j)g_j^anc by the matching old-source quantity, hence the master bound

  E H_proto<=sum a_j u_j q(u_j)^2h_j
               +eps E sum(f_j-o_j)k_j

is valid. This step applies old anchor marginals only to fixed old coefficients; it does not replace the original adaptive signed-Fubini law by frozen-alpha ghost integration.

The split into H-D_H+C_H is exact. C_H remains signed, and only its positive u>kappa part is used in the displayed Cauchy upper bound. All such rows lie outside the already-paid u<=1/2 branch. The balanced formula is correctly labeled a contraction of the old-source prototype, not actual H_next, and retains the entire signed ownership correction. It needs neither kappa'=kappa nor fixed alpha.

The positive-correlation scalar relaxation has the stated sharp coefficient. The locally scaled energy is now explicitly E_{u>kappa}, fixing the notation ambiguity reported before completion. Its O(n) cost at an O(1/n) gap is explicitly an obstruction to this coarse absorption, not a realized geometric lower bound or an available growth budget. No multiple copies of old high growth are spent.

## 4. Low incoming reserve and no double spending

The small-u dissipative correction uses Y_{u<1/2}<=A_L/3 and has source-unit cost at most 55A_L/108. When a moment inequality is used with multiplier 1/eps in the volume ledger, subtracting this from the actual 3A_L/(2eps) residual leaves 107A_L/(108eps). This is a legitimate conditional reservation from an existing positive slack, not an extra variance payment. The report explicitly requires rescaling for any different multiplier and does not keep the old full residual after charging this correction.

The report does not add the older separate U/reload/Psi/next-growth inequalities to this H branch. All owner fill/loss terms are paid once through the single E-priority identity. High growth, low slack and future source propagation are not declared separately exhausted and then reused.

## 5. Actual source cost and signed source/lost-copy merge

The bounded cost G_H^src=sum alpha u'/(1+u') 1_C normalizedradius^2 is the correct integrand for actual H_next. Moment constraints give H_next=int G_H^src dmu', with no remaining 1/g. Its cap by one follows from actual C-packing; it is not a density cap on either source.

The old-source invasion part I_H is nonnegative and at most S. The conditional baseline

  H_proto-g int G_H^src dmu
    =sum a' u'(u'-kappa')k/(1+u')-g I_H

has the correct sign and coefficients. The signed covariance need not vanish under sum a'(u'-kappa')=0. Accordingly the report does not identify H_proto with an old integral of the source cost or infer a small spatial price from unweighted TV.

The retained positive-weight label family is explicit in the LP incidence cells; deleted zero-weight cubes do not impose extra cell membership constraints. M'=||mu'||=gQ' is also explicit and is distinct from M_next=Q'. The source LP is for this H cost, not a formerly normalized Z cost: AC near-minimization yields Phi_H+tau M', not Phi_H/g as actual H_next. Exact AC attainment is not assumed. Its finite-dimensional duality/geometry certificate is separately audited.

The all-old merge is correct:

  (H_next-H_proto)-eps sum o_j k_j
    =H_next-sum_all a_j u_j k_j-eps sum f_j k_j.

Thus the LP comparison that would need pricing is Phi_H-sum_all a_j u_j k_j-eps sum f_j k_j, plus AC tolerance. It retains deleted old rows and does not first spend the lost-copy credit, then spend it again on source motion. The report explicitly labels this merge an identity rather than a budget proof.

The numeric diagnostic R_sp,Y=[Phi_H/g-int G_H^src dmu]_+ has its own normalization and is now explicitly distinguished from the complete actual H source gap. Its asymptotic illustration is not inserted into the main H ledger as a propagation theorem.

## 6. Abstract, numerical scope and final conclusion

The abstract accurately describes a new positive ownership-weighted state with a genuine terminal and a full old-source propagation prototype. It immediately says this is not contraction of the actual source. The conclusion retains the joint task of controlling sourcegap, signed old correlation and coverage loss inside the complete target; it does not claim a summable recurrence or root-order budget.

The relaxed local intervals are explicitly separated from the full old half-action/KKT/hard branch. The small-width model now specifies 0<h<1, and its theta-to-zero claims explicitly use h=theta^2; no fixed-h limit is silently substituted. New-state critical examples are not represented as old critical inputs. No numeric or finite LP example is claimed to refute or prove the general weak-type statement. Independent arithmetic/LP audits own those reported calculation values.

All formulas audited here are therefore compatible within the one uB-weighted gamma/E-priority/actual-alpha branch. The missing source/geometry/growth absorption is left visible rather than hidden in a renamed error. No unresolved double payment or global-closure overclaim was found.
