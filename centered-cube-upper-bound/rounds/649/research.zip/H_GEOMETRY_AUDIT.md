# R649 independent H geometry and scalar audit

## Scope and verdict

**PASS for the H terminal, the single weighted assignment, the H correlation bound, and the stated restricted scalar coefficient claim.** The audit first derived the tail/greedy terminal and scalar rescaling from the supplied definitions, then read the H part of `WEIGHT_TRANSFER.md` and §5 of `JOINT_LEDGER.md`. Only the H branch is certified here. Earlier Z/reload branches are not combined with it, and no abandoned quadratic swap/coercivity argument was used. The actual-source discrepancy and a uniform same-budget contraction remain unproved.

Owned output only: `/tmp/ccu_r649/H_GEOMETRY_AUDIT.md`. No other files were modified; no Git/PDF work or extra agent/large computation was used. A targeted read of R648's already accepted greedy proof, lines 243–276 of `/tmp/ccu_r648_final/REPORT.tex`, checked that the same single all-scale root construction is retained.

Read-source SHA256 bindings at review time:

- `WEIGHT_TRANSFER.md`: `8b5c20466e0a88cb4acdca073504aedec118a5b38bc7d298152bcabdcac7ac7f`
- `JOINT_LEDGER.md`: `dee108bcd4d06342f9ba857713bc4d1a7f99407ad6880f1bdde3b0f16da3b974`
- `TARGET.md`: `e91c0b7f2da3f4c81f1f078bbefa4acda131be0c0145b0e164a5764a85067084`
- R648 `REPORT.tex`: `52f4642140f03d62ee242aac3e8623eba5030229d2ba35e0a70e22e7ba0e75e4`

The first two bindings cover the exact checkpoint versions read, rather than certifying future edits. The mathematical conclusions below also state the defining formulas explicitly.

## 1. Independent receiver-weighted tail and full-family terminal

Let `r_j(x)=||x-y_j||_infty/s_j`, `h_j=m_j^{-1} int_Aj r_j^2 dmu`, `Y=eps sum v_j h_j`, and `H=(1+kappa)Y`. Since the old source is restricted to `A_j`, `0<=h_j<=1`. Hence

\[
 0\le H\le(1+\kappa)\varepsilon V=\kappa M\le4M.
\]

For `0<r<=1`, put `K_j=Q(y_j,r s_j)` and

\[
 T_r^v=\varepsilon\sum_j\frac{v_j}{m_j}\mu(A_j\setminus K_j).
\]

On this annulus `r_j^2>=r^2` up to an irrelevant boundary convention, so directly

\[
 T_r^v\le\frac{\varepsilon}{r^2}\sum_jv_jh_j
 =\frac{H}{(1+\kappa)r^2}.
\]

Fix `0<eta<1`. A bad row has `mu(A_j\setminus K_j)>eta m_j`, and therefore

\[
 \sum_{\rm bad}v_j\le T_r^v/(\varepsilon\eta).
\]

Every good row has `mu(K_j)>=(1-eta)m_j>=(1-eta)d_j`. Run one greedy selection of all good rows in decreasing `s_j`, with a fixed order for ties: assign a row to a previously selected root whose core has positive `mu` intersection, or select it as a new root otherwise. The root cores are pairwise `mu`-disjoint, and

\[
 \sum_{\rm roots}d_p\le M/(1-\eta).
\]

An assigned row has `s_j<=s_p` and `||y_j-y_p||_infty<=r(s_j+s_p)<=2rs_p`. Thus its complete old receiver cube is contained in `Q(y_p,(2r+1/a)s_p)`. As the actual old pieces are disjoint and lie in their receiver cubes,

\[
 \sum_{\rm good}v_j\le C_rM/(1-\eta),\qquad C_r=(2r+1/a)^n.
\]

Roots may overlap in physical volume after enlargement; taking their volume sum is merely an upper bound and does not spend source mass again. The root selection is once over all scales, not a separate budget per layer. No lower bound on `u_j`, no alpha comparison, and no concentration hypothesis beyond the individually defined good rows enter this proof. Consequently

\[
 V\le\frac{T_r^v}{\varepsilon\eta}+\frac{C_rM}{1-\eta},
\]

and minimizing the right side in `eta` gives

\[
 \sqrt V\le\sqrt{T_r^v/\varepsilon}+\sqrt{C_rM}
 \le\sqrt{\frac{H}{(1+\kappa)\varepsilon r^2}}+\sqrt{C_rM}.
\]

The zero-tail case follows by an endpoint limit. These are exactly the H terminal formulas in the reviewed files; no receiver row or actual `v_j` is removed without its defect payment.

At `r=1/64`, `C_r<=1/16` for every integer `n>=1`. In the hard band, `V/M=R/(1+kappa)>=1/5` and `eps V/M=kappa/(1+kappa)>=7/9`. Reversing the optimized root inequality is legitimate because `C_r M/V<=5/16<1`. It yields

\[
 \frac YM\ge\frac1{4096}\frac79\left(1-\frac{\sqrt5}{4}\right)^2=:c_*,
 \qquad \frac HM\ge(1+\kappa)c_*\ge\frac92c_*.
\]

Equivalently, before the numerical uniformization,

\[
 \frac HM\ge r^2\bigl(\sqrt\kappa-
 \sqrt{(1+\kappa)\varepsilon C_r}\bigr)_+^2.
\]

This is a genuine terminal statement for actual full-family receiver volume, conditional on the stated finite-state and hard-band hypotheses. It is not a multistage propagation theorem.

## 2. One feasible weighted assignment and the prototype

For the H branch, select one assignment minimizing

\[
 \sum_j\int_{A_j}u_jB(u_j)r_j(x)^2\,d\gamma_j(x),
 \qquad B(u)=\frac{1-(1+u)^{-2/n}}4.
\]

This is admissible: write `gamma_j=theta_j mu`, where `0<=theta_j<=1`, `sum theta_j=1`, the allowed supports and row masses are fixed, and the feasible set is weak-* compact. There are finitely many rows, and each fixed coefficient `u_jB(u_j)` and bounded row cost is finite. The objective is a continuous linear functional in this topology. The Eulerian benchmark `lambda_j 1_Aj mu` is feasible, so

\[
 \sum_ja_ju_jB(u_j)g_j\le\sum_ja_ju_jB(u_j)h_j,
 \quad g_j=a_j^{-1}\int r_j^2\,d\gamma_j.
\]

This choice does **not** imply the previous unweighted comparison `sum a_j g_j<=sum a_j h_j`. Section 5 explicitly replaces that minimizer and does not use its comparison in (J12)–(J15). The earlier checkpoint's balanced formula remains compatible: if all `u_j=kappa`, the weighted objective is a common positive multiple of the unweighted one. For varying growth, the weighted and unweighted branches must remain distinct.

The geometric pointwise estimate follows from

\[
 x-c_j=(x-y_j)+b_j(X_j-y_j),\qquad
 \|p+bq\|_\infty^2\le(1+b)(\|p\|_\infty^2+b\|q\|_\infty^2).
\]

After division by `t_j^2s_j^2`, its coefficients are

\[
 A(u)=\sigma/t^2,\quad B(u)=b\sigma/t^2,
 \quad A(u)+B(u)=q(u)^2,\quad q(u)=\frac{1+(1+u)^{-1/n}}2.
\]

Thus `E k_j<=A(u_j)h_j+B(u_j)g_j`. Only each own anchor marginal is needed here. There is no factorization of adaptive `p_j`, alpha, fill or loss.

The E-priority ownership identity is exact:

\[
 H_{\rm proto}=\varepsilon\sum_jp_jk_j
 =\sum_ja_ju_jk_j+\varepsilon\sum_j(f_j^{\rm own}-\operatorname{lost}_j)k_j.
\]

Apply the weighted assignment to the deterministic first part only. This proves (J12), and the algebraic identity

\[
 \sum_ja_ju_jq(u_j)^2h_j=H-G_H+C_H
\]

proves (J13) with precisely the stated signed `C_H`. The signed ownership term stays under its actual expectation. A separate reload/fill/new-growth charge cannot be appended as though it were a different cost.

The next-state normalization is also consistent: all next ownership volumes are `p_j/(1+kappa')`, conditional means are unchanged by common spatial/source normalization, and `H_next=eps sum p_j h'_j`. The prototype is an old-source conditional reference. The actual discrepancy `eps sum p_j(h'_j-k_j)` has no proved favorable sign and is not removed by this audit.

## 3. Independent proof of the new high-growth correlation bound

To avoid ambiguity, define the nonnegative **positive contribution sum**

\[
 X:=\sum_{u_j>\kappa}v_j(u_j-\kappa)q(u_j)^2h_j,
 \qquad E_+:=\sum_{u_j>\kappa}v_j\frac{(u_j-\kappa)^2}{u_j}.
\]

The full signed correlation obeys `C_H<=eps X`. This `X` is not an assertion that the low signed terms vanish and is not an identification with the full `C_H/eps`.

Weighted Cauchy and `0<=h_j,q(u_j)<=1` give

\[
 X^2\le E_+\sum_{u>\kappa}v_ju_jq(u_j)^4h_j^2
 \le E_+\sum_{u>\kappa}v_ju_jq(u_j)^2h_j
 \le E_+\left[X+\kappa\sum_jv_jh_j\right].
\]

Put `c0=kappa/(1+kappa)`. For `H>0`, `x=eps X/H` and `y=eps E_+/H` therefore satisfy

\[
 x^2\le y(x+c_0),\qquad x,y\ge0.
\]

Solving this quadratic yields `x<=(y+sqrt(y^2+4c0y))/2<=y+sqrt(c0y)`. Therefore

\[
 C_H\le\varepsilon E_+
 +\sqrt{\frac\kappa{1+\kappa}\varepsilon E_+H},
\]

which is (J14). If `H=0`, every `v_jh_j=0`, so `C_H=X=0` and the inequality remains valid. Only `u>kappa` growth occurs in `E_+`. No low growth or next-growth budget has been used by this bound. Using the inequality as a ledger payment would still spend that high growth, so it cannot be added to a separately spent copy.

## 4. Low-u correction and the exact remaining residue

For fixed `n`, `q(u)` is decreasing in `u`, so `1-q(u)^2` is increasing. With `delta0=1-q(1/2)^2`,

\[
 G_H\ge\delta_0H-(1+\kappa)\delta_0Y_{u<1/2}.
\]

Since `eps v_j=a_ju_j/(1+u_j)` and `h_j<=1`, each `u_j<1/2` contributes at most `a_j/3`; hence `Y_{u<1/2}<=A_L/3`, with `A_L` allowed to include the boundary `u=1/2`.

For `n>=1`, `(3/2)^{-1/n}>=2/3`; therefore `q(1/2)>=5/6` and `delta0<=11/36`. Along with `1+kappa<=5`,

\[
 (1+\kappa)\delta_0Y_{u<1/2}\le\frac{55}{108}A_L.
\]

With moment multiplier `1/eps` in the volume ledger, this is a debit of at most `55 A_L/(108 eps)`. From the actual low-input residual `3 A_L/(2 eps)`, the residue is exactly

\[
 \left(\frac32-\frac{55}{108}\right)\frac{A_L}{\varepsilon}
 =\frac{107}{108}\frac{A_L}{\varepsilon}.
\]

Both constants are valid uniform bounds; the proof does not claim they are globally sharp. This use explicitly reduces the old residue and preserves only one low-growth payment. It cannot also retain the original larger residue, and a different moment multiplier scales the debit. The inherited low-input theorem uses a universal row-score bound, so changing to a different feasible source assignment does not invalidate that rowwise residual.

## 5. Exact scope of the sharp scalar coefficient

Within the relaxed scalar set `x,y>=0`, `x^2<=y(x+c0)`, consider

\[
 x\le a_{\rm growth}y+\delta.
\]

For fixed `x>0`, the least feasible `y` is `x^2/(x+c0)`. Hence the least uniform coefficient is the supremum of `(x-delta)(x+c0)/x^2` over `x>delta`. For `0<delta<c0`, this is attained at

\[
 x_*=\frac{2c_0\delta}{c_0-\delta},\qquad
 y_*=\frac{x_*^2}{x_*+c_0},
\]

and equals

\[
 a_* =\frac{(c_0+\delta)^2}{4c_0\delta}.
\]

Sufficiency follows from the exact nonnegative certificate

\[
 (a_*-1)x^2+(\delta-c_0)x+c_0\delta
 =\frac{[(c_0-\delta)x-2c_0\delta]^2}{4c_0\delta}.
\]

Necessity **within this relaxed scalar domain** follows by testing the displayed feasible pair `(x_*,y_*)`. Thus (J15)'s stated range and its sufficiency/abstract necessity claims are correct. The range matters: if `delta>=c0`, the sharp relaxed coefficient is `1` (a supremum at large `x`, generally not attained); at `delta=0` no finite coefficient works uniformly. The displayed formula should not be called sharp outside `0<delta<c0`.

No result here proves that the extremizing abstract pair is realizable by the full cube/source/assignment geometry. The derivation deliberately loses information through `q^4h^2<=q^2h`, inclusion of all rows in `H`, and discarding low signed correlation. The geometry also supplies constraints absent from the two-variable relaxation. Consequently this is a precise obstruction to the particular scalar Cauchy/Young absorption, not a necessary growth fee for actual geometric configurations and not a counterexample to the global target. The reviewed §5 makes this distinction explicitly.

For `delta` comparable to `delta0=O(1/n)`, `a_*=O(n)` with a positive linear scale, whereas the inherited ledger has a single copy of current growth. This shows why that scalar absorption alone cannot certify the desired same-budget contraction. It does not rule out a stronger joint signed-ownership/source argument.

## 6. Actual local math-tool verification

The existing local interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` was actually run with SymPy for bounded algebraic checks. Outputs included:

```text
H/M bound rescaling residual: 0
A+B-q2: 0
sharp relaxation certificate residual: 0
relaxed sharp equality residual: 0
coefficient supremum derivative: -(-2*c0*delta + c0*x - delta*x)/x**3
q_1(1/2): 5/6
delta0 n=1: 11/36
low correction: 55/108
low residual: 107/108
c* exact: 49/196608 - 7*sqrt(5)/73728
c* decimal: 0.000036926597188333769058373810748712380
```

A bounded illustration at `n=1,2,3,7,16,32` also returned `delta0` below `11/36` and `C_r` below `1/16`; these samples are not the proofs of the uniform inequalities. The exact arguments above prove them. No source-shadowing experiment, geometric realization search, old coercivity calculation, or multistage numerical certification was undertaken.

## Remaining boundary

The H state now has a proved actual-volume terminal and a valid prototype propagation bound for one weighted assignment. What is still needed is a same-action joint payment of the signed correlation, weighted fill-minus-loss, and actual-source discrepancy, with one nonduplicated growth ledger. Neither a strict uniform H contraction nor the general root-order weak bound follows from these audited statements alone.
