# R649 independent audit of the H main branch

**Verdict: PASS for the definitions, terminal-compatible state, exact owner/prototype identities, weighted-assignment expectation and source-cost formulas. The contraction is only a prototype statement; actual H_next propagation remains unpaid.**

I first derived H_next, the ownership identity, the weighted assignment bound, and the source integrand directly from the definitions, then read WEIGHT_TRANSFER.md's H extension and JOINT_LEDGER.md section 5. This audit owns only this file. It does not reopen the saved alternative entropy branch.

The authoritative main-branch assignment for this audit is ONE feasible gamma minimizing

  sum_j integral_Aj u_j B(u_j) r_j(x)^2 dgamma_j(x),
  B(u)=[1-(1+u)^(-2/n)]/4.

The old u_j and costs are fixed before the product draw. Every statement below refers to the resulting actual action, E-priority owner partition and its one reoptimized alpha. Earlier unweighted-center and F-maximizing branches are not simultaneously assumed.

## 1. The actual normalized successor and its conditional means

At a genuine current state define

  h_j=(1/m_j) integral_Aj r_j(x)^2 dmu(x),
  Y=eps sum_j v_j h_j,
  H=(1+kappa)Y.

Then 0<=Y<=eps V and 0<=H<=kappa M, so H<=4M in the current critical band. Each h_j is a mean against the ACTUAL current row restriction mu|Aj/m_j. This is a nonnegative state depending on actual owners and the actual source, not on a freely chosen row statistic.

For retained next labels define

  h'_j=(1/m'_j) integral_Cj ||y-c_j||_infinity^2/rho_j^2 dmu'(y).

Here mu' is a genuine next KKT source, mu'(C_j)=m'_j=m_j(1+u'_j), and h'_j in [0,1]. A common spatial scaling by g^(-1/n), g=1+kappa', leaves the relative-radius integrand unchanged. Source scaling by 1/g multiplies both conditional numerator and denominator by 1/g, so the conditional mean remains h'_j. Actual normalized owner volumes are p_j/g. Therefore, PATHWISE,

  H_next=(1+kappa')eps sum_J (p_j/g)h'_j
        =eps sum_J p_j h'_j.                            (H1)

This cancels adaptive g before expectation; no independence is used. It would be wrong to replace h'_j by an old-source mean or pull g outside an expectation. The next bound H_next<=kappa' M_next is true, but H_next<=4M_next requires the next state actually to remain in its critical band; that is not automatic.

## 2. Exact E-priority ownership, including deleted rows

For EVERY old label, define

  d_j^own=|I'_j intersect E_j|,
  lost_j=ell_j-d_j^own>=0,
  f_j^own=|I'_j\E_j|>=0.

E-priority gives p_j=d_j^own+f_j^own, sum lost_j=O, sum f_j^own=fill. Let

  k_j(Z)=(1/m_j) integral_Aj ||x-c_j||_infinity^2/rho_j^2 dmu(x) in [0,1].

This old-source conditional mean is well defined for every old row, before or after its next deletion. Since eps ell_j=a_j u_j, one has exactly

  H_proto=eps sum_all p_j k_j
         =sum_all a_j u_j k_j
            +eps sum_all(f_j^own-lost_j)k_j.             (H2)

The signed ownership term is fully action-adaptive and remains inside expectation. It cannot be replaced by (fill-O) times a fixed mean, nor can its negative lost-copy component be erased before another payment. For a deleted row, p_j=0, d_j^own=f_j^own=0 and lost_j=ell_j: its old term a_j u_j k_j is exactly cancelled by -eps lost_j k_j. Thus deletion is NOT a free removal of old incoming mass. Actual h'_j,u'_j and source-cost sums are only defined on retained J.

## 3. The new weighted assignment gives precisely the needed prototype bound

For each own anchor X_j, the nonaveraged squared-radius inequality gives

  k_j(Z)<=A(u_j)h_j+B(u_j)r_j(X_j)^2,
  A(u)=sigma(u)/t(u)^2,
  A(u)+B(u)=q(u)^2,
  q(u)=[1+(1+u)^(-1/n)]/2.

The Eulerian benchmark lambda_j 1_Aj mu is feasible for the SAME weighted optimization. Hence, if g_j^anchor=(1/a_j) integral_Aj r_j^2 dgamma_j,

  sum_j a_j u_j B(u_j)g_j^anchor
    <=sum_j a_j u_j B(u_j)h_j.

Taking genuine old anchor marginals after H2, without factoring any owner variable, proves

  E H_proto<=sum_j a_j u_j q(u_j)^2 h_j
              +eps E sum_j(f_j^own-lost_j)k_j.           (H3)

This is the correct new main-branch bound. The weighted minimizer need not satisfy the R648 unweighted comparison Z_gamma<=Z_lambda at varying u, and it does not satisfy the old physical F-optimality/coercivity. Neither property is needed for H3. At a fully balanced state u_j=kappa, u_j B(u_j) is one common positive scalar, so the weighted minimizer ALSO minimizes the unweighted center objective there. Consequently the balanced prototype conclusion

  E H_proto<=q(kappa)^2 H
              +eps E sum_j(f_j^own-lost_j)k_j

is valid under the new branch as well.

The weighted objective has the same legitimate finite-state existence proof as the center objective: fixed finite row coefficients and bounded row integrands on a finite weak-star compact feasible assignment set. The complete R647 action ledger needs only assignment feasibility and remains available under this newly fixed product law. No expectation under an earlier law can be imported.

## 4. Gain/correlation split and low-row budget

To avoid collision with the SOURCE integrand below, call the scalar dissipative term Gain_H. Algebra gives

  sum_j a_j u_j q(u_j)^2 h_j=H-Gain_H+Corr_H,
  Gain_H=(1+kappa)eps sum_j v_j[1-q(u_j)^2]h_j>=0,
  Corr_H=eps sum_j v_j(u_j-kappa)q(u_j)^2 h_j.

Thus JOINT_LEDGER section 5's prototype split is correct. Corr_H is signed; the fact that sum_j v_j(u_j-kappa)/u_j=0 does not make this differently weighted correlation vanish.

Its stated positive-part bound uses ONLY old u>kappa, hence none of the already-paid low incoming growth. With X=sum_(u>kappa) v_j(u_j-kappa)q(u_j)^2 h_j, weighted Cauchy yields

  X^2<=Eold,{u>kappa}[X+kappa H/((1+kappa)eps)].

This proves the displayed Corr_H<=eps Ehigh+sqrt([kappa/(1+kappa)]eps Ehigh H). The sharp scalar Young coefficient in J15 is consistent with x^2<=e(x+c0). It is a relaxation coefficient obstruction, not a geometrically realized counterexample or an available one-copy growth payment.

For u0=1/2, delta0=1-q(1/2)^2,

  Gain_H>=delta0 H-(1+kappa)delta0 Y_{u<1/2}.

Since eps v_j=a_j u_j/(1+u_j), Y_{u<1/2}<=A_L/3. The uniform delta0<=11/36 and 1+kappa<=5 give correction <=55A_L/108 in SOURCE units. Using the moment inequality with multiplier 1/eps in the VOLUME ledger costs <=55A_L/(108eps). Subtracting it from the actual already-established residual 3A_L/(2eps) leaves 107A_L/(108eps). This is a legitimate reservation from that residual, provided it is actually subtracted. Keeping the former full residual as well would double-pay. A different moment multiplier changes this debit.

JOINT_LEDGER explicitly reduces the residual and warns about the multiplier; it does not re-spend the old low variance. The separate reload/Psi/next-growth payments from its earlier branches must NOT be added to H2-H3. The H branch uses the ownership split once and leaves old Corr_H plus the source comparison unpaid.

## 5. Correct actual-source cost, LP scaling, and signed baseline

Define the bounded spatial SOURCE cost (different from Gain_H) by

  G_H^src(y)=sum_J alpha_j [u'_j/(1+u'_j)] 1_Cj(y)
                          ||y-c_j||_infinity^2/rho_j^2.

Actual packing gives 0<=G_H^src<=L_alpha^C<=1 dx-a.e. The moment identities give

  integral G_H^src dmu'
    =sum_J alpha_j m_j u'_j h'_j
    =eps sum_J p_j h'_j=H_next.                         (H4)

Thus G_H^src, called G_Y in WEIGHT_TRANSFER.md, is the correct LP cost for H_next. There is NO remaining 1/g factor in H4.

For the actual positive-volume saturated C-incidence cells Omega_K, alpha(K)=1, put c_K=essinf_(Omega_K)G_H^src. A source LP is

  Phi_H=min sum_K c_K z_K,
  z_K>=0, sum_(K containing j)z_K=m'_j.

The actual source supplies feasibility; every feasible multiplier vector has sum_K z_K=M'=gQ' by saturation. For any positive tolerance tau, selecting AC probability densities within each cell near its essential infimum gives an actual dual mu' with

  H_next<=Phi_H+tau M'=Phi_H+tau gQ'.

A formula Phi_H/g would refer to a differently normalized cost and is not the H_next defined here. If a desired additive error is tau Q', one can choose cell tolerance tau/g explicitly; adaptive g must be accounted for pathwise. No such approximation error is automatically summable just because an arbitrary tolerance can be selected.

The old-source conditional baseline must also retain its real coefficients. Set a'_j=alpha_j m_j and

  I_H=integral G_H^src dmu
       -sum_J a'_j[u'_j/(1+u'_j)]k_j.

This is the weighted C_j\A_j part of the old source, so I_H>=0 and

  I_H<=integral sum_J alpha_j 1_(Cj\Aj) dmu
      <=M-Q'=S.

It follows exactly that

  H_proto-g integral G_H^src dmu
    =sum_J a'_j [u'_j(u'_j-kappa')/(1+u'_j)]k_j-g I_H.  (H5)

This confirms WEIGHT_TRANSFER's conditional baseline formula. The covariance in H5 has no general sign. Its multiplier u'/(1+u') and row k_j prevent the cancellation sum a'(u'-kappa')=0 from zeroing it. The favorable invasion term is -g I_H; one must not reverse that sign or add I_H as a new independent credit.

In particular H_proto is not integral G_H^src against an arbitrary free old source, and the bounded TV coupling does not show h'_j close to k_j or price the spatial discrepancy. The exact missing comparison is

  Delta_source=H_next-H_proto
               =eps sum_J p_j(h'_j-k_j),

with no established sign or paid estimate. It remains when the next source is selected by the actual cost LP.

## 6. Precise conclusion and branch-consistency notes

The most that has been established for the actual next state is the explicit interface

  E H_next
    <=H-Gain_H+Corr_H
       +eps E sum_all(f_j^own-lost_j)k_j
       +E Delta_source.

The last two quantities and the positive Corr_H payment are not disposed of by the prototype contraction. Even in the balanced case, they remain. Therefore none of H3, H4, or the genuine terminal meaning alone proves a contracting actual potential, a summable source-mass/error budget, or the full R647 high-incoming target.

The terminal use of Y is legitimate with merely disjoint old I_j subset B_j: bad own-annular rows cost their ACTUAL v_j, and the greedy root cover pays the remaining receivers. It does not require old I_j to cover the full old union. This audit checked compatibility of the stated terminal with the new H definition; the global geometric root selection is the previously audited terminal mechanism, not a new probability argument.

Two textual branch distinctions should remain explicit when integrating the files:

1. WEIGHT_TRANSFER's earlier varying-u paragraphs retain the old unweighted center-min branch and call the uB-weighted choice a separate possible decision. JOINT_LEDGER section 5 is the NEW authoritative H branch selecting that weighted objective. Earlier unweighted Z_gamma<=Z_lambda or Psi/reload formulas cannot be silently used for its varying-u law. The balanced paragraph remains valid because the weights are then constant.
2. JOINT_LEDGER calls its scalar dissipative quantity G_H, while the source-LP request calls a spatial function G_H(y). They are different objects. This audit writes Gain_H and G_H^src to prevent a false equality.

These distinctions were reported to the parent before completion. They are integration/scope conditions, not a failure of H1-H5.

## 7. Actual local verification

Executed the user's installed math environment /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python, SymPy 1.14.0. Six exact symbolic residuals were zero: adaptive normalization cancellation in H1; the actual source-cost moment identity H4; owner/prototype identity H2; gain/correlation split; old-source baseline H5; and 3/2-55/108=107/108. No dimension/label scan or relaxed-model extrapolation was performed.

The probabilistic inequalities use the genuine fixed weighted-optimal assignment's actual anchor marginals. No frozen-alpha ghost integration is substituted for an adaptive realized anchor, and no old F-optimality is used.
