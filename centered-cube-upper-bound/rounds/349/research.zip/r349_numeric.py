#!/usr/bin/env python3
"""Exact true-interval overlap Schur diagnostics and finite posterior probes."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json,hashlib
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k

def source(mode):
 if mode=='uniform':return [(F(-2),F(2),F(1))]
 period=F(1) if mode=='period1_packet' else F(1,4)
 profile=[(F(0),period/4,F(4)),(period/4,period,F(0))] if mode=='period1_packet' else [(F(0),period/4,F(3)),(period/4,period/2,F(1)),(period/2,period,F(0))]
 return [(a+j*period,b+j*period,d) for j in range(-int(2/period),int(2/period)) for a,b,d in profile]
def fmass(src,a,b):return sum((max(F(0),min(hi,b)-max(lo,a))*d for lo,hi,d in src),F(0))
def cap(e,z):
 a,b,R=e;return max(F(0),min(b,z+R/2)-max(a,z-R/2))
def fixtures():
 return [('initial',[(F(-1,2),F(0),F(1)),(F(1,4),F(1,2),F(2))],'uniform'),('boundary_stress',[(F(-3,4),F(-1,2),F(1)),(F(-1,4),F(0),F(2)),(F(1,4),F(1,2),F(1))],'period1_packet'),('expanded',[(F(-1),F(-3,4),F(1)),(F(-3,4),F(-1,4),F(5,4)),(F(-1,4),F(1,4),F(3,2)),(F(1,4),F(1),F(2))],'period_quarter_two_level')]
def breaks(src,E):return sorted(set([F(-2),F(2)]+[z for a,b,d in src for z in [a,b]]+[z+sgn*R/2 for a,b,R in E for z in [a,b] for sgn in [-1,1]]))
def density(src,z):return next((d for a,b,d in src if a<z<b),F(0))
def product_integral(a,b,fa,fb,ga,gb):return (b-a)*(2*fa*ga+fa*gb+fb*ga+2*fb*gb)/6

def weighted_overlap_segments(src,E,coef):
 points=breaks(src,E);out=[]
 for a,b in zip(points,points[1:]):
  d=density(src,(a+b)/2);ga=d*sum(t*cap(e,a) for e,t in zip(E,coef));gb=d*sum(t*cap(e,b) for e,t in zip(E,coef));out.append((a,b,ga,gb))
 return out

def integrate_segments(seg,lo,hi):
 ans=F(0)
 for a,b,fa,fb in seg:
  left=max(a,lo);right=min(b,hi)
  if left>=right:continue
  slope=(fb-fa)/(b-a);fl=fa+slope*(left-a);fr=fa+slope*(right-a);ans+=(right-left)*(fl+fr)/2
 return ans

def sliding_max(seg,interval,R):
 lo,hi=interval;points=sorted(set([lo,hi]+[z+sgn*R/2 for a,b,fa,fb in seg for z in [a,b] for sgn in [-1,1] if lo<z+sgn*R/2<hi]));best=F(0);witness=lo;pieces=[]
 def value(u):return integrate_segments(seg,u-R/2,u+R/2)
 for a,b in zip(points,points[1:]):
  mid=(a+b)/2;fa=value(a);fb=value(b);fm=value(mid);L=b-a;A=2*(fa+fb-2*fm)/(L*L);B=(fb-fa)/L-A*L
  ck('sliding_quadratic_fit_independent_quarter',value(a+L/4)==fa+B*L/4+A*L*L/16)
  probes=[(a,fa),(b,fb)]
  if A:
   t=-B/(2*A)
   if 0<t<L:probes.append((a+t,fa+B*t+A*t*t))
  for u,v in probes:
   if v>best:best=v;witness=u
  pieces.append(dict(lo=str(a),hi=str(b),value_at_lo=str(fa),linear=str(B),quadratic=str(A)))
 return best,witness,pieces

def posterior(src,u,Ru,w,Rw,profile):
 lo=u-Ru/2;hi=u+Ru/2
 if profile=='indicator':pieces=[(lo,hi,F(1))]
 elif profile=='signed_halves':pieces=[(lo,u,F(1)),(u,hi,F(-1,2))]
 else:pieces=[(u-Ru/4,u+Ru/4,F(1))]
 mean=second=F(0);distribution=[]
 for a,b,Fvalue in pieces:
  m=fmass(src,max(a,w-Rw/2),min(b,w+Rw/2));mean+=Fvalue*m/Rw;second+=Fvalue*Fvalue*m/Rw;distribution.append((Fvalue,m/Rw))
 distribution.append((F(0),1-sum(p for value,p in distribution)))
 double_variance=sum((p*q*(value-other)**2/2 for value,p in distribution for other,q in distribution),F(0))
 return mean,second,double_variance

def model(stage,E,mode):
 before=sum(C.values());src=source(mode);N=len(E);vol=[b-a for a,b,R in E];points=breaks(src,E);W=fmass(src,F(-2),F(2))
 ck('positive_disjoint_receiver_intervals',all(v>0 for v in vol) and all(E[i][1]<=E[i+1][0] for i in range(N-1)))
 for a,b,R in E:
  qpoints=sorted(set([a,b]+[z+sgn*R/2 for lo,hi,d in src for z in [lo,hi] for sgn in [-1,1] if a<z+sgn*R/2<b]))
  for u in qpoints:ck('actual_full_source_q_one',fmass(src,u-R/2,u+R/2)==R)
 overlaps={}
 for i in range(N):
  for j in range(N):
   total=F(0)
   for a,b in zip(points,points[1:]):
    d=density(src,(a+b)/2);total+=d*product_integral(a,b,cap(E[i],a),cap(E[i],b),cap(E[j],a),cap(E[j],b))
   overlaps[i,j]=total
   ck('overlap_true_rectangle_nonnegative',0<=total<=min(E[i][2],E[j][2])*vol[i]*vol[j])
   if (j,i) in overlaps:ck('overlap_rectangle_symmetric',total==overlaps[j,i])
 results=[]
 for K in [F(5,4),F(3,2)]:
  H=[[overlaps[i,j]/(vol[i]*vol[j]*E[j][2]**2) if E[j][2]>K*E[i][2] else F(0) for j in range(N)] for i in range(N)]
  rows=[sum(H[i][j]*vol[j] for j in range(N)) for i in range(N)];cols=[sum(H[i][j]*vol[i] for i in range(N)) for j in range(N)];Rmat=max(rows);Cmat=max(cols);frob=sum(vol[i]*vol[j]*H[i][j]**2 for i in range(N) for j in range(N));Rmax=Cmax=F(0);rowcert=[];colcert=[]
  for i,e in enumerate(E):
   coef=[F(1,f[2]**2) if f[2]>K*e[2] else F(0) for f in E];seg=weighted_overlap_segments(src,E,coef);mx,u,pc=sliding_max(seg,e[:2],e[2]);Rmax=max(Rmax,mx);rowcert.append(dict(receiver=i,max_exact=str(mx),witness=str(u),quadratic_pieces=pc))
   coef=[F(1,e[2]**2) if e[2]>K*f[2] else F(0) for f in E];seg=weighted_overlap_segments(src,E,coef);mx,w,pc=sliding_max(seg,e[:2],e[2]);Cmax=max(Cmax,mx);colcert.append(dict(receiver=i,max_exact=str(mx),witness=str(w),quadratic_pieces=pc))
  for i,cert in enumerate(rowcert):
   integral=sum(((F(p['hi'])-F(p['lo']))*F(p['value_at_lo'])+F(p['linear'])*(F(p['hi'])-F(p['lo']))**2/2+F(p['quadratic'])*(F(p['hi'])-F(p['lo']))**3/3 for p in cert['quadratic_pieces']),F(0))
   ck('continuous_row_integral_matches_Fubini_matrix',integral/vol[i]==rows[i])
  for j,cert in enumerate(colcert):
   integral=sum(((F(p['hi'])-F(p['lo']))*F(p['value_at_lo'])+F(p['linear'])*(F(p['hi'])-F(p['lo']))**2/2+F(p['quadratic'])*(F(p['hi'])-F(p['lo']))**3/3 for p in cert['quadratic_pieces']),F(0))
   ck('continuous_column_integral_matches_Fubini_matrix',integral/vol[j]==cols[j])
  ck('Galerkin_rows_below_continuous_Schur',Rmat<=Rmax and Cmat<=Cmax)
  ck('continuous_row_Schur_individual_bound',Rmax<=2/K)
  ck('continuous_column_Schur_individual_bound',Cmax<=1/K)
  ck('continuous_double_Schur_squared_bound',Rmax*Cmax<=2/(K*K))
  ck('weighted_matrix_squared_norm_upper',min(Rmat*Cmat,frob)<=2/(K*K))
  aggregates=[];probes=[]
  for profile in ['indicator','signed_halves','central_half']:
   S=V=F(0)
   for i,(a,b,Ru) in enumerate(E):
    for j,(c,d,Rw) in enumerate(E):
     if Rw<=K*Ru:continue
     for u in [a,(a+b)/2,b]:
      for w in [c,(c+d)/2,d]:
       mean,second,double_variance=posterior(src,u,Ru,w,Rw,profile);I=fmass(src,max(u-Ru/2,w-Rw/2),min(u+Ru/2,w+Rw/2));variance=second-mean*mean
       ck('posterior_actual_probability_normalization',fmass(src,w-Rw/2,w+Rw/2)/Rw==1)
       ck('posterior_Cauchy_with_actual_overlap',mean*mean<=I/Rw*second<=Ru/Rw*second<=second/K)
       ck('posterior_variance_exit',(1-1/K)*second<=variance<=second)
       ck('actual_two_source_variance_identity',double_variance==variance)
       diagnostic_a=F(1,1+i+j);diagnostic_late=1-Ru/Rw;weight=vol[i]*vol[j]/9*diagnostic_a*diagnostic_late;S+=weight*second;V+=weight*variance
       if len(probes)<6 and second>0:probes.append(dict(profile=profile,i=i,j=j,u=str(u),w=str(w),mean=str(mean),second=str(second),overlap_I=str(I),variance=str(variance),diagnostic_a=str(diagnostic_a),diagnostic_late=str(diagnostic_late)))
   ck('finite_weighted_variance_sum_exit',(1-1/K)*S<=V<=S)
   aggregates.append(dict(profile=profile,S_exact=str(S),V_exact=str(V),V_over_S=str(V/S) if S else None,scope='Finite posterior point probes with positive stated weights; not continuum pair integration or original highpast/late mask.'))
  results.append(dict(K=str(K),upper_receiver_blocks=sum(H[i][j]>0 for i in range(N) for j in range(N)),H_block_average=[[str(v) for v in row] for row in H],matrix_row_sums=list(map(str,rows)),matrix_col_sums=list(map(str,cols)),continuous_row_max=str(Rmax),continuous_col_max=str(Cmax),continuous_L2_norm_squared_Schur_upper=str(Rmax*Cmax),weighted_Galerkin_norm_squared_upper=str(min(Rmat*Cmat,frob)),target_2over_Kq_squared=str(2/(K*K)),row_certificates=rowcert,column_certificates=colcert,variance_aggregates=aggregates,posterior_selected_probes=probes))
 return dict(stage=stage,source_mode=mode,source_intervals=[list(map(str,s)) for s in src],receiver_intervals=[list(map(str,e)) for e in E],actual_q='1',source_W=str(W),overlap_rectangle_integrals={f'{i},{j}':str(v) for (i,j),v in overlaps.items()},results=results,exact_checks=sum(C.values())-before)

def logbounds(x,N=64):
 if x==1:return F(0),F(0)
 if x<1:
  a,b=logbounds(1/x,N);return -b,-a
 k=0
 while x>2:x/=2;k+=1
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));hi=lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 if k:
  a,b=logbounds(F(2),N);lo+=k*a;hi+=k*b
 return lo,hi

def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1000:return str(x)
 a=abs(x.numerator);raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')

def tail_capacity_tests():
 before=sum(C.values());l2,h2=logbounds(F(2));rows=[]
 for N in [4,16,64,128]:
  q=M=F(1);atoms=[(F(2**(i+1)),F(1,2)) for i in range(N)];U=sum(w for m,w in atoms);V=sum(m*w for m,w in atoms)
  for j,(m,w) in enumerate(atoms,1):
   accumulated=F(j,2);ck('abstract_tail_cumulative_cap_all_breakpoints',accumulated<=1+j*l2)
  moment_lower=l2*F(N*(N+1),4);moment_upper=h2*F(N*(N+1),4);rhs=max(F(0),q*U-1)**2/(2*q)
  ck('abstract_tail_log_moment_bound',moment_lower>=rhs)
  lvlo,lvhi=logbounds(V*q/M);ck('abstract_tail_exponential_mass_via_log',q*U>=1 and lvlo>=q*U-1)
  ck('abstract_tail_basic_mass_lower',V>=M*U)
  ck('abstract_tail_original_atom_moments',U==F(N,2) and V==2**N-1)
  rows.append(dict(atom_count=N,q='1',M='1',atoms=[[str(m),str(w)] for m,w in atoms],U=str(U),V=str(V),logmoment_lower=brief(moment_lower),logmoment_upper=brief(moment_upper),logmoment_required=str(rhs),log_Vq_over_M_lower=brief(lvlo),log_Vq_over_M_upper=brief(lvhi),required_log_Vq_over_M=str(q*U-1),scope='Abstract finite capacity model, not actual cubes. Cumulative cap verified at every atom; between atoms F is constant and 1+log(T/M) increases.'))
 return dict(exact_checks=sum(C.values())-before,models=rows,scope='Separate finite tail-capacity examples only, not an extremizer or actual-source realization. No exponential floating-point comparison.')

def main():
 models=[model(*a) for a in fixtures()];capacity=tail_capacity_tests();out=dict(tail_capacity_diagnostic=capacity,status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=models,scope='True 1D positive-L1 sources and positive receiver dx for overlap integrals and continuous Schur extrema. Posterior/variance tests are explicitly finite point probes. H is an overlap operator, not original conservative flow; no full historical/highpast/root claim.')
 (BASE/'r349_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),model_checks=[m['exact_checks'] for m in models],abstract_capacity_checks=capacity['exact_checks']),sort_keys=True))
if __name__=='__main__':main()
