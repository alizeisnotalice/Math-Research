# R344 — A dimension-free occupancy moment pays the clipped-source traffic

## New paid branch and unchanged source field

Use the original hard contract, G_out, and R342 localbad endpoint set

    A={u∈E:m_u<e^{-√n}f(Q_{(1+√n)b}(u))}.

The result below also holds with any measurable large-endpoint subset A. All m_u,q_u,R_u,E_r,J_y(r), the global past Z, the far ratio K, outside-center gate, and physical ell are computed from the original arbitrary nonnegative f∈L¹ and are frozen throughout. Write G_A[g] for the original positive traffic with only its final source factor f(y) replaced by 0≤g(y)≤f(y). This is notation for a positive piece of the same source integral, not a recomputation of the field.

Let C_{4/3} be a dimension-independent strong L^{4/3} norm bound for the centered cubic Hardy–Littlewood maximal operator. For the original

    h=(1+√n)/(εq_-),       0<ε<1,

set

    T=q_- n/(C_{4/3}^4 ε³),
    g_T=min(f,T),       f_T^+=(f-T)_+.

Then

    G_A[g_T]≤εX_q,
    G_out(A)=G_A[g_T]+G_A[f_T^+]
             ≤εX_q+G_A[f_T^+].                                  (1)

Thus a genuine positive portion of the original localbad traffic is paid. There is no assumed density cap on f: the exact excess-source traffic G_A[f_T^+] remains. Its receiver masses, full J, all gates and physical clock are still those of f. In particular the q band is not claimed for a new field built from g_T or f_T^+.

## Verified external theorem and its scope

The external input is the centered cube maximal theorem

    ||M_cube φ||_s≤C_s||φ||_s,       1<s<∞,

with C_s independent of dimension. Bourgain's original paper defines the centered dilation operator in (1.1)–(1.2) on page 1, states the dimension-independent C₂ bound there, and states the all-s>1 cube theorem on page 3. Its cube is [-1/2,1/2]ⁿ, matching the side-length convention here. See [Jean Bourgain, On the Hardy–Littlewood maximal function for the cube, original arXiv PDF, pp. 1–3](https://arxiv.org/pdf/1212.2661).

This note uses only the fixed exponent s=4/3 for (1), and also records the general duality formula below. The numerical value of C_{4/3} is not asserted. No dependence on s as s approaches 1 is inferred, and the theorem is not a dimension-free weak-(1,1) theorem. This is a verified external analytic input, not a theorem proved by the finite checks below.

## Actual receiver duality gives an occupancy moment

Fix 1<p<∞ and p'=p/(p-1). On the actual receiver set E define the linear averaging operator

    (T_R φ)(u)=R_u^{-n}∫_{Q_u}φ(y)dy.

Its selector R_u is the original arbitrary measurable selector. Pointwise |T_Rφ(u)|≤M_cube|φ|(u), so

    ||T_Rφ||_{L^{p'}(E,du)}≤C_{p'}||φ||_{L^{p'}(dy)}.

Its adjoint applied to the actual function 1/q_u is precisely the full original terminal occupancy:

    T_R^*(1/q_u)(y)
       =∫_E 1_{Q_u}(y)/(q_uR_uⁿ)du
       =J_y(b).                                                    (2)

The equality follows by Tonelli against nonnegative tests; standard duality gives the L^p bound. Since E has finite Lebesgue measure and q_u≥q_->0, 1/q_u belongs to L^p(E). Therefore

    ∫J_y(b)^pdy≤C_{p'}^p∫_E q_u^{-p}du
                  ≤C_{p'}^p X_q/q_-^{p+1}.                        (3)

The first inequality is the sharper heterogeneous receipt. Every measure here is actual dy or du. There is no surrogate receiver probability and no assumed Carleson tree structure.

Consequently the high-occupancy source region has genuine Lebesgue capacity

    |{y:J_y(b)>h}|
       ≤C_{p'}^p h^{-p}∫_E q_u^{-p}du
       ≤C_{p'}^p X_q/(q_-^{p+1}h^p).                              (4)

This is a higher-moment bound, stronger than using only ∫fJ=|E| or a pointwise J cap. It is not by itself a bound on the f-mass of that region.

## Original high-past support and the complete physical row bound

Define the nonnegative original source row Γ_A(y) by

    G_A[g]=∫g(y)Γ_A(y)dy,

where Γ_A includes the original ell integration, large endpoints in A, all small endpoints, full J and every original gate. This is a frozen-field representation, so Γ_A is independent of the chosen source component g.

The far ratio K>λ/q_- implies R_v<R_u for every strict small-mass receiver in Z_y(m_u/K-). Whenever u∈E_r, those receivers therefore already belong to E_r. On the original high-past gate,

    J_y(b)≥J_y(r)≥Z_y(m_u/K-)>h.

It follows that Γ_A(y)=0 unless J_y(b)>h.

On a nonzero row, replace m_u-m_v by m_u and bound the gated small-endpoint capture integral by the same full J_y(r). After cancellation, the remaining actual large-center volume at fixed y,r is at most rⁿ, because y∈Q_u and R_u≤r place u in the cube of side r centered at y. Thus

    0≤Γ_A(y)≤A_n 1_{J_y(b)>h},
    A_n=1+n log(b/a).                                              (5)

The constant 1 is exactly the original b atom: b^{-n}bⁿ=1. The continuous clock contributes n∫_a^bdr/r. No physical endpoint is removed or replaced, and the source density is never bounded in deriving (5).

Combine (4),(5). For every actual source component 0≤g≤f with ||g||∞≤T,

    G_A[g]≤T A_n C_{p'}^p h^{-p}∫_E q_u^{-p}du
       ≤[T A_n C_{p'}^p/(q_-^{p+1}h^p)]X_q.                       (6)

Notice that this uses X_q of the full receiver field, because the full original occupancy contains all of E. Replacing it by X_q(A) has not been justified.

## Exponent choices and complete payment

For any target receiver fee δ>0, formula (6) permits the exact threshold

    T_p=δ q_-^{p+1}h^p/(C_{p'}^p A_n).

With the original h this is

    T_p=δ q_-(1+√n)^p/(C_{p'}^p ε^p A_n).                           (7)

The p=2 choice yields, for δ=ε, the safe threshold

    T_2=q_-/(C_2²ε),

because A_n≤(1+√n)². This already uses actual high-past occupancy instead of the direct source-density estimate alone.

For p=4 and δ=ε, (7) gives the exact threshold

    T_4^{exact}=q_-(1+√n)^4/(C_{4/3}^4 ε³ A_n).

Since b/a≤2 and log 2<1,

    nA_n≤n+n²≤(1+√n)^4.

Therefore the simpler threshold T=q_-n/(C_{4/3}^4ε³) is at most T_4^{exact}. Substitution into (6) proves (1). This is a source truncation of an arbitrary L¹ field, not an L∞ hypothesis on that field. The strict high-past support is the essential original gate used in this new payment.

For completeness, the general source-integrated capacity statement is

    G_A[g]≤A_n∫_{J_b>h}g,
    |{J_b>h}|≤C_{p'}^p h^{-p}∫_E q_u^{-p}du.

Large f-mass can still concentrate on that small Lebesgue set. That is why the excess-source term in (1) must remain; the moment estimate does not settle the entire localbad branch.

## Insertion into the current complete hard slot

Retain the R342 local-growth covering fee

    C_cover,n=2[1+3√n+log(8/3)]

and the unchanged R338 coefficient

    C_{ε,n}=(λ/q_-)[(2+3√n+2e^{-√n})/ε+1+√n].

The R342 slot was

    B_H(f,ν)≤G_out(A)+2εX_q+[C_{ε,n}+C_cover,n]W.

Replacing only its current localbad traffic by (1) gives

    B_H(f,ν)≤G_A[(f-T)_+]+3εX_q
                  +[C_{ε,n}+C_cover,n]W.                           (8)

The unchanged entrance consequently has receiver coefficient 6ε after the factor 2 on B_H. With the supplied ε=119/3072 and outer multiplier 128/119, this is 1/4. This is a replacement ledger: the earlier localization fees are not charged again, and every other unpaid slot remains due.

The new residual simultaneously retains the R342 localbad endpoint gate and the exact excess-source factor (f-T)_+, along with all original pair gates and clocks. It has not received a root-order budget. The result is a new paid source component using a verified fixed-exponent maximal theorem, not a general weak-(1,1) closure.

## Actually run local checks

`/tmp/r344_geometry_checks.py` was executed with Fraction arithmetic and passed 268 exact assertions: 1 first-moment identity, 5 actual dx adjoint identities, 6 occupancy-tail inequalities, 128 p=2 threshold scalings, and 128 p=4 threshold scalings. The geometry fixture has f=1_{[-4,4]}, E=[-1,0] with R=1 and E=[0,1] with R=2 (the common boundary is null), so every actual q_u=1. Its exact terminal occupancy has ∫J=2 and ∫J²=19/12. The adjoint tests and tail measures are integrated across all piecewise-linear breakpoints, not sampled receiver centers.

The finite fixture verifies duality and capacity mechanics only; it does not have the R344 high-past configuration and is not a numerical evaluation of G_out. The C_s theorem is supported by the cited primary paper, not by these tests. Reproduce with `python3 /tmp/r344_geometry_checks.py`.
