# R349 final independent audit

**PASS within the stated scope. No new original-flow payment is established this round.** The actual-source two-sided overlap kernel capacity, the exact gain-weighted square bridge, the upper-tail moment lower bounds and the original-amplitude posterior variance identities are valid. The R348 late residual and complete ledger remain due. No substantive correction to the final frozen files is required.

The propositions were independently screened before author reading in `/tmp/r349_audit_pre.md`. This final review read the full geometry, core, main, ledger, numerical note and all three scripts. Only owned audit files were written; no author file, numerical output, old contract or Git state was changed. The primary's full pipelines were not repeated. The historical reduction chain and external literature are not newly certified by this audit.

## 1. Real-du overlap capacity and correct reference measure

For the SAME full-f masses m_u=∫f c_u and any unchanged component 0≤g≤f, the kernel

    H_K^g(u,w)=1_{m_w>Km_u}I_uw^g/m_w²,
    I_uw^g=∫g c_uc_w,

is relative to actual du,dw. The row bound follows by source Tonelli, the actual inverse-mass-square center envelope and ∫g c_u=m_u p_u^g. It is 2p_u^g/(Kq_-). The column bound uses the real volume of centers with m_u<m_w/K capturing the fixed source y: at most m_w/(Kq_-). Source integration then gives p_w^g/(Kq_-). The q lower bound and actual receiver volume are used; no density cap on g or a free source mass distribution is introduced.

Cauchy–Schwarz in H_K^g du dw yields the stated weighted bilinear bound with squared constant 2/(K²q_-²). In particular the unweighted L²(du) operator norm is ≤√2/(Kq_-). Zero captured-g fractions cause zero kernel marginals and present no issue. This is not a norm on dμ receivers or on the original normalized source–receiver traffic. Moving between those measures requires the explicit mass factors below. The small overlap norm alone is not a paid original branch.

## 2. Exact square bridge, gain and sufficient target

The coefficient ζ_y(u) in geometry (1) is the old ηΩ traffic integrated over its original clock and all relative/late/H/small/high-past/outside/far gates. It satisfies 0≤ζ≤q_u and is not a new selector or a recomputed η. The source–u cost is exactly ∫gζρ_y.

For the genuine joint measure

    dΞ=g(y)c_u(y)c_w(y)1_upper dy du dw/m_w²,

its total is at most Y_g/(Kq_-), where Y_g=∫p_w^g dw=∫gJ_b≤X_q/q_-. Multiplying Ξ by ζm_w/(m_uU_y(Km_u)) gives the old flow exactly: the w integral is U_y(Km_u). The multiplier is used only where ζ>0 and U>0, and is assigned zero elsewhere. The same zero convention is inherited by the displayed gain integrands.

Squaring the multiplier in Ξ yields precisely

    E_gain=∫g(y)∫ζ² V_y^+(u)/(m_u U_y(Km_u)²)ρ_y(du)dy,
    V_y^+(u)=∫upper m_wρ_y(dw)=∫upper c_w(y)dw.

Thus G_late²≤Y_g E_gain/(Kq_-)≤X_q E_gain/(Kq_-²). There is no missing m_w, m_u or second source factor. V_y^+ is actual upper-center volume, at most b^n. The conversion to an old a²U-type potential retains the additional factor R_gain/U², with R_gain=V/(m_uU). Deleting it would change the quantity being estimated.

Geometry (16) is also correctly derived: V≤b^n, m_u≥q_-a^n, U>B on nonzero ζ and ζ²≤λζ give E_gain≤[(λ/q_-)(b/a)^n/B²]G_late. Substitution gives exactly the stated generally exponential receiver coefficient. That coarse bound is recorded as a limitation and is NOT charged. The proposed bound (15) on E_gain/(Kq_-²) would be a sufficient source-root route through Cauchy–Schwarz and Young, but is not proved or claimed necessary. No original square/suffix credit is spent to manufacture that missing upper bound.

## 3. Actual tail-moment geometry and normalized guards

At fixed source y and M>0, the real receiver envelope gives ρ_y{M<m≤T}≤[1+log(T/M)]/q_- for T≥M. The strict lower and inclusive upper conventions retain all mass atoms. Layer cake in logarithmic coordinates gives

    ∫_{m>M}log(m/M)ρ_y≥(q_-U-1)_+²/(2q_-).

Layer cake for the first mass moment V=MU+∫_M^∞ρ_y{m>T}dT gives V≥MU if q_-U≤1, and V≥(M/q_-)exp(q_-U-1) if q_-U≥1. The exponential conclusion must be kept in its proper regime; the frozen proof and main do so. Normalized upper-law statements are made only for U>0. On actual nonzero relative/high-past rows, q_-U>1+√n, so the exponential regime applies there.

For M=Km_u, exp(x-1)/x is increasing for x>1, giving R_gain>K²/(1+√n). The secondary bound R_u^n<b^n/K² follows correctly from V≤b^n and the actual q lower bound. These are actual necessary lower-growth/scale conditions, not a simultaneous sharp full-f construction or a paid entropy drop. No source-integrated upper drift budget follows. Main appropriately uses these facts to reject dropping the gain weight, not to declare the old cost paid.

## 4. Posterior exit, true late amplitude and source reuse

The original posterior π_w=f c_w dy/m_w is probability-valued. For m_w>Km_u, π_w(Q_u)=I_uw/m_w≤m_u/m_w<1/K. Cauchy–Schwarz for any square-integrable F supported in Q_u gives |EπF|²≤π_w(Q_u)Eπ|F|², hence the stated two-sided variance comparison and independent-two-source variance identity. No independence under the original common-source traffic is assumed.

Core (5) chooses F_{u,r}=c_u sqrt[(g/f)ηΩχ/U], with zero at f=0 or inactive upper tail. Its nonzero set has U>εJ_b>B, so its second moment is well-defined and bounded. Exact source/witness Fubini yields G_late under du·ell(dr)·dw, with NO dμ(u) factor. The variance therefore satisfies (1-1/K)G_late≤V_late≤G_late. It remains a positive source-change cost, not a negative square in the original ledger.

The separate squared-score S uses F_u=c_u a_y sqrt(g/f)1_relative and the different measure du/m_u·dw. The code and text preserve that distinction. Its variance comparison says the new variance is comparable to the same positive S, rather than bounding it at root scale.

The κ_late column bound is obtained by positively contracting the original pre-routing row, not by applying a fresh a≤λ condition to arrived mass. Resampling its actual receiver marginal gives the exact source density f(z)L(z), L(z)=∫c_w(z)κ_late(w)dw/m_w. Its available bound retains λL_ε f(z)J_b(z). The identity ∫fL=G_late is conservation, not invariance with respect to f dz and not a source-root budget. The unresolved upper estimate for V_late or that weighted marginal is expressly retained.

## 5. Ledger and evidence boundaries

No new receiver or source fee is entered from Schur, the square bridge, the tail moment or the posterior comparison. The ledger is the R348 ledger, including its already paid source soft deduction and arrived-clock fee. Its hard slot still contains G_late[g_ex], [(13/3)ε+γ_eff]X_q, C_{ε,n}W and (D_top,n+C_hit,n)W_ex. The inherited entrance still multiplies the slot by two. Under the same authenticated historical account, the conditional total is 841/2304+2Λγ_eff<853/2304, with no assertion that unallocated room pays other branches.

The ledger preserves the actual late soft ηΩ remainder, general soft/crossing/innovation and hard-contract complements, extreme scales/heights, chronology initialization/deletion/future-deleted-source terms, single-use negative credit and outer/source/layer/limit budgets. Physical terminal atoms do not settle chronological atoms. Main correctly distinguishes the new proved interfaces from the missing general payment and does not rename V_late or E_gain as a paid quantity. The external literature scope paragraph is not used in these elementary estimates; its separate primary verification is not expanded into a literature-proof certification here.

The primary reports fresh successful runs of numeric 1,817 exact rational/outward-rational-log checks, geometry 87 Fraction assertions plus 15 ordinary 70-digit Decimal diagnostics, and core 1,248 Fraction posterior cases plus its stated fixture identities. The numerical JSON was parsed and records PASS, actual-field stages 264/494/831 and separate abstract capacity 228. Both standalone geometry/core scripts were verified byte-for-byte against their unique embedded Python blocks. This reviewer did not repeat the primary pipeline or combine repeated runs/independent scratch checks into its totals.

Numeric's continuous overlap calculations use actual positive receiver intervals, finite nonnegative L¹ source densities, all moving-response breakpoints and q=1 verified at every affine piece endpoint. Quadratic source-overlap integrals are exact. Continuous row/column extrema use complete shifted segment breakpoints and quadratic endpoints/vertices, with an independent quarter-piece check and a separate integral comparison against the Fubini block matrix. The matrix/Galerkin norm bounds are not substituted for a full continuous operator identity.

Posterior tests are explicitly finite receiver-point probes, with exact source integration; the weighted probe sum is not called a continuous receiver pair integral or the original Ω/clock/high-past field. Boundary points are tagged block/one-sided probe cases rather than evidence of a new historical selector. The capacity appendix is a separate abstract atomic class with rational log enclosures, not an actual full-f extremizer. Geometry's 15 Decimal layer-cake checks remain diagnostics. Its actual one-dimensional fixture omits outside and uses diagnostic K; core's fixture checks mass/posterior identities only. None certifies nonempty original root late traffic or general closure.

## 6. Frozen SHA256 bindings
- `/tmp/r349_main.md` — `a76ef2673aa0316f035dc838d253e2a392388dc87e15326fbb605561a594d3db`
- `/tmp/r349_ledger.md` — `3198fc6027c5c2abe9539b878fdca3011e1df2b9ecfbf948cafc05cd4216c4e5`
- `/tmp/r349_geometry.md` — `8af96a5d51d707b31455e3be61b3349e813443d6261faa121e5243501d10003f`
- `/tmp/r349_core.md` — `417b0490f419df19ccebada8398853f72dc1ae509693ccf857ba66fe7ac1034d`
- `/tmp/r349_numeric.md` — `87564af82d1fd4475532297cdeac0ee00558069a1df549787b84fa30869ca7bd`
- `/tmp/r349_geometry_checks.py` — `6eab14ecce2dec2d7ec21b88cda20c703649fcf49e95619d966d1ccb92269cbb`
- `/tmp/r349_core_checks.py` — `e1cc8871e4f96a40b21424d07834aa5d48a4d4bcbb513b0cb58df9b7dd5dd30d`
- `/tmp/r349_numeric.py` — `ca1205ec18592eebbd088eae9bc62829e1457ce53df5efdfa355575d07a64438`
- `/tmp/r349_numeric_result.json` — `2fa73550d29ac140d30aeaa6716ef138185a135cc1b48c65552583b4db023d12`
- `/tmp/r349_audit_pre.md` — `84fd6e198f7b08b1b7378b10c9c4bf9facb2dac017e0700f8aac03b7c22b0e95`
- `/tmp/r348_main.md` — `5de7a7cc1beb60c18523e38b02c193fea38a55995e467472f1429beef6c5fc6e`
- `/tmp/r348_ledger.md` — `cb6429b64aea68cda448feb31ade974045abeda9eb4e0831389ca4bb9388369f`
- `/tmp/r348_geometry.md` — `e86647ca64922f06e3025fca655472a2860e42336506c432251f31a1ab30f137`
- `/tmp/r348_core.md` — `dafedb811ac0719cf7a63502051dd13d2ccf5eb6cd5d695fb6854de509ff8ab3`
- `/tmp/r348_audit.md` — `2709e8b8cc88976a36c269f20e74f8388b2e2dd45ff0fce21ceb2d2668e35df9`
- `/tmp/r347_geometry.md` — `ac4e9b38400df1591d4f77bd289d13b08dc106167e7a173cc5daa0cb04c5d509`
- `/tmp/r347_core.md` — `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r346_geometry.md` — `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r344_geometry.md` — `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`
- `/tmp/r340_core.md` — `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90`

Predecessor bindings preserve the necessary frozen contract and preceding paid slots; they do not signify a fresh full audit of every historical derivation. The preliminary file is preserved as the independent-before-author record. This final receipt binds the current final bytes.
