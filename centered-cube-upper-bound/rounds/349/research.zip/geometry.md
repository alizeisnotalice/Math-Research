# R349 — Actual overlap has a small two-sided kernel, with an explicit mass-gain cost in the old flow

**Scope.** This bounded investigation proves a genuine common-source overlap operator estimate and an exact quadratic bridge for the original late traffic. It also proves a quantitative lower bound on the upper witnesses' mean mass gain. No new payment for the entire old late branch follows: the bridge retains a source-weighted mass-gain square whose root-order bound is unproved. In particular, the small overlap-operator norm is not substituted for the old transport kernel after deleting its inverse mass factor.

## Frozen field and precise old-flow coefficient

Retain the complete R348/R347 field: f≥0 in L¹, actual finite Lebesgue receiver set E, a≤R_u≤b≤2a, m_u=∫Q_u f=q_uR_uⁿ, q_-=3λ/4≤q_u≤λ, c_u(y)=1Q_u(y), ρ_y(du)=c_u(y)du/m_u. Write J_y=ρ_y(E), U_y(t)=ρ_y{m>t}, U_y^r(t)=ρ_y{m>t,R≤r}. The original K=e^(√n), high-past threshold h=(1+√n)/(εq_-), Ω, H, outside-center and far-mass gates, full J_y(r), and ell=b^(-n)δ_b+n r^(-n-1)dr are unchanged.

The R348 fractional mask η_y(u) is the old score mask, computed before the prefix split. Define the actual late-flow coefficient

    ζ_y(u)=1_{U_y(Km_u)>εJ_y} q_u R_uⁿ
      ∫_[R_u,b] η_y(u)Ω_y(u,r)1_{U_y^r(Km_u)≤1/q_-}ell(dr). (1)

Then 0≤ζ≤q_u and, for any fixed outer source 0≤g≤f,

    G_late[g]=∫g(y)∫ζ_y(u)ρ_y(du)dy.                (2)

Formula (1) retains every original old-time gate and its terminal atom. It is a notation for the same late traffic, not a new receiver selector or a recomputation of η. The eventual application uses g=g_ex.

## Candidate screened first: two-sided actual-overlap estimate

For u,w∈E define the real common-source overlap and captured g-fraction by

    I_uw^g=∫g(y)c_u(y)c_w(y)dy,
    p_u^g=∫Q_u g/m_u∈[0,1].

Consider the oriented kernel, relative to actual du and dw,

    H_K^g(u,w)=1_{m_w>Km_u} I_uw^g/m_w².            (3)

For every field in the contract and every g≤f, the following is proved:

    ∫E H_K^g(u,w)dw≤[2/(Kq_-)]p_u^g,
    ∫E H_K^g(u,w)du≤[1/(Kq_-)]p_w^g.              (4)

In particular its unweighted L²(du) operator norm is at most √2/(Kq_-). More precisely, for arbitrary measurable receiver tests F,G for which the right side is finite,

    |∫∫H_K^g(u,w)F(u)G(w)du dw|²
      ≤[2/(K²q_-²)](∫p_u^g|F(u)|²du)
                       (∫p_w^g|G(w)|²dw).         (5)

This is an actual common-source geometry estimate. It does not follow from treating the sourcewise mass distribution as a free abstract measure.

### Proof of both capacities

For fixed u and y∈Q_u, the R348 inverse-mass-square center envelope, with threshold Km_u, gives

    ∫_{m_w>Km_u} c_w(y)dw/m_w²≤2/(Km_u q_-).

Integrate against g(y)c_u(y). Since ∫g c_u=m_up_u^g, this proves the first inequality in (4).

For fixed w and y∈Q_w, every contributing small receiver has m_u<m_w/K and therefore R_uⁿ<m_w/(Kq_-). Capture places its center in the cube about y with that side-volume. Thus

    |{u:y∈Q_u,m_u<m_w/K}|≤m_w/(Kq_-).

Tonelli now gives

    ∫H_K^g(u,w)du
      ≤m_w^(-2)∫g(y)c_w(y)[m_w/(Kq_-)]dy
      =p_w^g/(Kq_-).

This uses actual center volume only to bound a receiver integral. It does not place a density cap on g or infer a small source mass from a small boundary volume. Finally Cauchy–Schwarz in the positive measure H_K^g du dw, followed by its two marginals, gives (5).

## Exact bridge to the original ηΩ late traffic

Write U_y^+(u)=U_y(Km_u) and define the actual upper-center volume

    V_y^+(u)=∫_{m_w>Km_u}m_wρ_y(dw)
             =∫E c_w(y)1_{m_w>Km_u}dw.              (6)

It is at most bⁿ, but this crude bound is not used to assert a root estimate. Define the genuine source–receiver–witness measure

    dΞ=g(y)c_u(y)c_w(y)1_{m_w>Km_u}
                                      dy du dw/m_w². (7)

The same source y remains in all factors. Its total mass is, by the column half of (4),

    Ξ(total)≤Y_g/(Kq_-),
    Y_g=∫p_w^g dw=∫g(y)J_y dy≤X_q/q_-.            (8)

For ζ>0, U_y^+(u)>0. Put the multiplier below equal to zero when ζ=0. The exact old flow satisfies

    G_late[g]=∫ [ζ_y(u)m_w/(m_uU_y^+(u))]dΞ.       (9)

Indeed integrating w in (9) gives U_y^+(u), which cancels the unchanged real upper normalization. Neither Ω nor the physical time is reassigned to w.

Cauchy–Schwarz in Ξ gives the concrete square estimate

    G_late[g]²≤[Y_g/(Kq_-)] E_gain[g]
                 ≤X_q E_gain[g]/(Kq_-²),           (10)

where the squared factor has the exact evaluation

    E_gain[g]
      =∫g(y)∫ ζ_y(u)² V_y^+(u)
                   /[m_u U_y^+(u)²] ρ_y(du)dy.    (11)

If this integral is infinite, (10) remains true but provides no finite bound. In the finite original radius band it is finite under the elementary bounds recorded below. Every old gate and the old prefix restriction remain in ζ².

This explicitly connects the small overlap kernel to the old traffic; it also records the full price of the connection. Let

    R_gain(y,u)=V_y^+(u)/[m_uU_y^+(u)]
               =E_{upper ρ/U}[m_w/m_u].

Then (11) can be written in either form

    E_gain[g]=∫g∫ [ζ²/U]R_gain ρ
             =∫g∫ [ζ²U][R_gain/U²]ρ.              (12)

Thus pairing with the old a²U square requires the extra weight R_gain/U²; it is not the plain a²U square. The identity I/(m_um_w)=(m_w/m_u)H_K makes the same missing mass factor visible at the pair level.

## Actual occupancy forces a large mean upper mass gain

There is a further exact geometric restriction on that factor. For every fixed source y, receiver u, and M=Km_u, write U=ρ_y{m>M} and V=∫_{m>M}mρ_y. If q_-U≤1, the always valid bound is V≥MU. If U≥1/q_-, then

    V≥[M/q_-]exp(q_-U-1).                           (13)

To prove it, the real closed-window envelope used in R347 applies at every ratio T/M≥1 and gives

    ρ_y{M<m≤T}≤[1+log(T/M)]/q_-.

The strict upper tail above T is consequently at least

    [U-(1+log(T/M))/q_-]_+.

Layer cake for the first moment yields

    V=MU+∫_M^∞ρ_y{m>T}dT
      ≥MU+∫_M^{M exp(q_-U-1)}
                       [U-(1+log(T/M))/q_-]dT
      =(M/q_-)exp(q_-U-1).

This proof includes all mass atoms and uses the actual center bound behind the closed window. It is a necessary geometry inequality, not an example with independently assigned mass atoms. The piecewise bound is V≥(M/q_-)Φ(q_-U), where Φ(x)=x for 0≤x≤1 and Φ(x)=exp(x-1) for x≥1. It is a lower envelope implied by capacity; no claim is made that every full-f cube field attains it or that its scalar extremizer is realizable in the original geometry.

There is a corresponding exact logarithmic-drift lower bound. For s≥0, the mass in the logarithmic interval (M,Me^s] is at most (1+s)/q_-. Thus layer cake gives

    ∫_{m>M}log(m/M)ρ_y
       ≥∫_0^∞[U-(1+s)/q_-]_+ ds
       =(q_-U-1)_+²/(2q_-).                         (13a)

For U>0 the normalized real upper-witness law consequently obeys

    E_{upper ρ/U}[log(m_w/m_u)]
       ≥logK+(q_-U-1)_+²/(2q_-U).                   (13b)

This is a lower bound on actual future mass growth, not a paid entropy drop. No source-integrated entropy budget or iteration cost is inferred from it. It includes the case q_-U≤1, when the additional term is zero.

On any nonzero original relative/high-past row, U>εJ_y>B=(1+√n)/q_-. Hence (13) gives

    R_gain≥K exp(q_-U-1)/(q_-U)>K²/(1+√n).          (14)

The final step uses that exp(x-1)/x increases for x>1 and K=e^(√n). Thus the mean mass amplification is not generally of order K with a harmless constant on the target branch. It cannot be dropped from (12) simply because the overlap kernel itself has a 1/K norm.

As a secondary radius guard, V≤bⁿ combined with (13) gives

    m_u≤q_-bⁿ exp(1-q_-U)/K<q_-bⁿ/K²,
    R_uⁿ<bⁿ/K².

This guard is not entered as a new payment. The main useful information is the actual mass-gain factor present in the square bridge.

## Precise remaining geometric assertion and current available fee

A sufficient, genuinely additional source-integrated assertion would be: for all frozen full-f fields and their exact ζ in (1), there exist dimension-independent C_ε and a fixed power A such that

    E_gain[g_ex]/(Kq_-²)
       ≤C_ε(1+√n)log^A(2+n) W.                    (15)

This is unproved here and is not claimed necessary for the desired weak-type target. It is a stronger sufficient route with a concrete observable: squared old-clock traffic multiplied by actual upper-center volume and the exact mass/occupancy normalizations. It is not obtained by replacing g_ex with a new input or by bounding a count of mass windows alone.

If (15) were proved, (10) and Young's inequality would yield, for any ε'>0,

    G_late[g_ex]
       ≤ε'X_q+[C_ε/(4ε')](1+√n)log^A(2+n)W.

At present the elementary positive estimate gives only

    E_gain[g]≤[(λ/q_-)(b/a)ⁿ/B²]G_late[g].          (16)

Indeed V≤bⁿ, m_u≥q_-aⁿ, U>B and ζ²≤λζ. Inserting (16) into (10) gives merely

    G_late[g]≤[(λ/q_-)(b/a)ⁿ/(K(1+√n)²)]X_q,

which can have an exponential dimension cost and is worse than existing capacities. This is the explicit fee incurred by the naive overlap-square conversion; it is not charged to the ledger. A bound such as (15) would have to use additional geometry of ζ and the same-source mass gain, or an independently justified negative credit. The high-past/outside/late masks have not yet supplied that missing bound.

No old fee is changed. The R348 late residual remains unpaid, and no new receiver absorption or source-only payment is recorded from (4), (10), or (13) alone. These are the proved advances and the exact outstanding bridge; bounded exploration stops here.

## Embedded reproducible diagnostics

The embedded code was run locally and passed 87 exact Fraction assertions and 15 separate 70-digit Decimal diagnostics. The Fraction checks cover actual positive-volume capture blocks, overlap capacities, their weighted bilinear form, the preserved old clock, the square bridge and logarithmic layer-cake algebra. Separate Decimal evaluations check the displayed exponential layer-cake algebra at 70-digit precision; they are numerical diagnostics, not exact certificates. The real one-dimensional fixture uses diagnostic K and omits the original outside-center gate, so it is not a root-hard simulation.

```python
from fractions import Fraction as F
from decimal import Decimal, localcontext
N=0; D=0

def ck(x):
    global N
    assert x
    N+=1

packets=[(F(-1,200),F(1,200),F(1)),
         (F(3,5),F(61,100),F(2,5)),
         (F(9,10),F(91,100),F(3,5))]
centers=[(F(-3,100),F(-2,100)),(F(-1,100),F(0)),(F(2,100),F(3,100))]
R=[F(1),F(7,5),F(2)]
inc=[[1,0,0],[1,1,0],[1,1,1]]
du=F(1,100); qmin=F(3,4); lam=F(1); K=F(11,8)
m=[sum((packets[j][2]*inc[i][j] for j in range(3)),F(0)) for i in range(3)]
for i,((l,r),rr) in enumerate(zip(centers,R)):
    ck(r-l==du); ck(m[i]/rr==1)
    for j,(sl,sr,_) in enumerate(packets):
        ck((r-rr/2<=sl and l+rr/2>=sr) if inc[i][j]
           else (r+rr/2<=sl or l-rr/2>=sr))

for gm in ([F(1),F(2,5),F(3,5)], [F(1,2),F(1,10),F(3,10)]):
    p=[sum((gm[j]*inc[i][j] for j in range(3)),F(0))/m[i] for i in range(3)]
    I=[[sum((gm[j]*inc[i][j]*inc[k][j] for j in range(3)),F(0)) for k in range(3)] for i in range(3)]
    H=[[I[i][k]/m[k]**2 if m[k]>K*m[i] else F(0) for k in range(3)] for i in range(3)]
    for i in range(3):ck(du*sum(H[i])<=2*p[i]/(K*qmin))
    for k in range(3):ck(du*sum(H[i][k] for i in range(3))<=p[k]/(K*qmin))
    for ff in ([F(1),F(1),F(1)],[F(-2),F(3),F(1,3)],[F(0),F(1),F(0)]):
        for gg in ([F(1),F(2),F(-1)],[F(3),F(1,5),F(7)]):
            bil=du**2*sum((H[i][k]*ff[i]*gg[k] for i in range(3) for k in range(3)),F(0))
            rhs=2/(K*qmin)**2*(du*sum(p[i]*ff[i]**2 for i in range(3)))*(du*sum(p[k]*gg[k]**2 for k in range(3)))
            ck(bil**2<=rhs)
    ck(du**2*sum(sum(row) for row in H)<=du*sum(p)/(K*qmin))

# Exact late-flow bridge for the middle receiver at the first source packet.
rho=[du/mm for mm in m]
Jpre=rho[0]+rho[1]; J=sum(rho)
ompre=(m[1]-m[0])*rho[0]/(m[1]*Jpre)
omend=(m[1]-m[0])*rho[0]/(m[1]*J)
a=R[1]*(ompre*(1/R[1]-1/R[2])+omend/R[2])
U=rho[2]; tau=F(1,10000); eta=max(F(0),1-tau/(a*U))
zeta=eta*a
ck(U<=1/qmin)  # This diagnostic prefix gate retains the whole old clock.
G=zeta*rho[1]
V=du
Egain=zeta**2*V/(m[1]*U**2)*rho[1]
ck(Egain==zeta**2*(m[2]/m[1])**2)
Xi=F(0); first=F(0); second=F(0)
for i in range(3):
    for k in range(3):
        if m[k]<=K*m[i]:continue
        for j,(_,_,mass) in enumerate(packets):
            base=mass*inc[i][j]*inc[k][j]*du**2/m[k]**2
            Xi+=base
            z=zeta if i==1 and j==0 else F(0)
            up=sum((rho[w]*inc[w][j] for w in range(3) if m[w]>K*m[i]),F(0))
            c=z*m[k]/(m[i]*up) if z else F(0)
            first+=base*c; second+=base*c*c
ck(first==G); ck(second==Egain)
ck(G*G<=Xi*Egain)
Y=3*du
ck(Xi<=Y/(K*qmin))
ck(G*G<=Y/(K*qmin)*Egain)

# Exact logarithmic layer-cake integral, including its zero regime.
for x in (F(0),F(1,2),F(1),F(3,2),F(2),F(5),F(10)):
    for q in (F(1,4),F(3,4),F(1)):
        U=x/q; L=max(F(0),x-1)
        integral=L*(U-1/q)-L*L/(2*q)
        ck(integral==L*L/(2*q))
        if U:ck(integral/U==L*L/(2*x))

# Diagnostic layer-cake algebra, kept separate from exact rational checks.
with localcontext() as ctx:
    ctx.prec=70
    for x in (Decimal(1),Decimal('1.5'),Decimal(2),Decimal(5),Decimal(10)):
        for M in (Decimal('0.25'),Decimal(1),Decimal(3)):
            q=Decimal('0.75'); U=x/q; L=x-1
            integral=M/q*(L.exp()-L-1)
            rhs=M/q*L.exp()
            assert abs(M*U+integral-rhs)<Decimal('1e-60'); D+=1
print(f'PASS: {N} exact Fraction assertions; {D} 70-digit Decimal layer-cake diagnostics. No general hard-traffic budget is claimed.')
```
