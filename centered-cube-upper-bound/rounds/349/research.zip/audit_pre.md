# R349 independent pre-author screen

PASS for both proposed actual-source interfaces, with the integrability/reference-measure qualifications below. These are a genuine dimension-independent L² kernel estimate and an exact posterior second-moment/variance comparison. Neither alone is a new original-flow payment. No R349 author proof has been read.

## 1. Frozen actual-source kernel

Keep f≥0 in L¹, true receiver centers u,w∈E with Lebesgue du,dw, m_u=∫f c_u=q_uR_u^n, q_u≥q_->0, positive bounded radii a≤R_u≤b, and K>1. The hard matched application also retains finite E and the original upper q/clock/full-J contract. Define

    I_uw=∫f(y)c_u(y)c_w(y)dy,
    H(u,w)=1_{m_w>Km_u} I_uw/m_w².

This is a jointly measurable nonnegative kernel. All masses and overlaps come from the SAME full f; no independent source density cap or altered selector is used.

Its actual-du row capacity is

    ∫_E H(u,w)dw
      =∫f(y)c_u(y)[∫_{m_w>Km_u}c_w(y)dw/m_w²]dy
      ≤[2/(Km_uq_-)]∫f c_u=2/(Kq_-).

The inner inequality is the R348 real-center radial inverse-square estimate. It follows directly by integrating 1/max(Km_u,q_-z)² in the volume coordinate z=(2||w-y||∞)^n, even without the physical radius restrictions. It does not require w to lie in an old active clock or make a claim about arrival.

The column capacity is

    ∫_E H(u,w)du
      =m_w^(-2)∫f(y)c_w(y)
                         |{u∈E:m_u<m_w/K,c_u(y)=1}|dy
      ≤m_w^(-2)[m_w/(Kq_-)]∫f c_w=1/(Kq_-).

Indeed m_u<m_w/K and q_u≥q_- imply R_u^n<m_w/(Kq_-). Every such capturing center u lies in the cube centered at y of volume m_w/(Kq_-). This is actual RECEIVER volume; f remains inside its exact integral. Strict mass thresholds and closed geometric cube faces cause no omitted positive term.

For the operator (Hφ)(u)=∫H(u,w)φ(w)dw, weighted Cauchy–Schwarz/Tonelli gives

    ||Hφ||²_L²(du)
      ≤[2/(Kq_-)][1/(Kq_-)]||φ||²_L²(dw),
    ||H||_(L²→L²)≤√2/(Kq_-).

The constants use only q_- and K, not n or source L∞. The reference measures are du,dw, NOT dμ(u),dμ(w) or a source posterior. This small operator norm cannot be inserted as an original traffic fee until an exact factorization into those L² spaces, with its input/output norms and all original J/clock/source weights, has been established. No such factorization or budget is assumed here.

## 2. Actual source posterior and exact second-moment swap

For each actual w let

    π_w(dy)=f(y)c_w(y)dy/m_w.

It is a probability measure because m_w is the actual full-f mass. For any real or complex F_u supported in Q_u and square-integrable under π_w,

    |E_{π_w}F_u|²
      ≤π_w(Q_u) E_{π_w}|F_u|²
      =(I_uw/m_w)E_{π_w}|F_u|².

On m_w>Km_u, I_uw≤m_u gives π_w(Q_u)<1/K. Consequently

    (1-1/K)E_{π_w}|F_u|²
      ≤Var_{π_w}(F_u)≤E_{π_w}|F_u|².

Support is meant π_w-almost everywhere; this is Cauchy–Schwarz on the captured source subset, not an independence assumption. Generic F needs the indicated second moment. One must not use an undefined infinity-minus-infinity variance; the original bounded amplitude below is unproblematic.

For the proposed original squared-score quantity, retain the full field and all old gates in a_y(u), and let χ_rel(y,u)=1_{U_y(Km_u)>εJ_b(y)}. Set

    F_u(y)=a_y(u)sqrt(g(y)/f(y))c_u(y)χ_rel(y,u),

with g/f=0 at f=0. Since 0≤g≤f and 0≤a≤λ in the actual application, F is bounded and measurable. Then the exact original nonnegative quantity

    S=∫g(y)∫ a_y(u)²χ_rel(y,u)
                            U_y(Km_u)ρ_y(du)dy

has the exact actual-source Fubini form

    S=∫_E du/m_u ∫_{m_w>Km_u}dw E_{π_w}|F_u|².

There is NO additional factor 1/m_w outside the posterior expectation, and the source c_u factor is not omitted. The posterior itself already contains c_w/m_w. This verifies the proposed measure normalization precisely.

For

    V=∫_E du/m_u ∫_{m_w>Km_u}dw Var_{π_w}(F_u),

positivity and the pointwise comparison give

    (1-1/K)S≤V≤S.

Under the original finite-E, a>0, q_->0, a_y≤λ contract, S is finite, for instance S≤λ²|E|²/(q_-a^n). The squared-mean term S-V is the square of THIS posterior-resampled amplitude. It is not identified with an original negative capture/Gram/suffix credit. The newly introduced two-source resampling law is auxiliary and cannot be substituted for the original common source in an unrelated term.

## 3. Meaning and limits

The first estimate is a proved real integral kernel capacity, not a finite-incidence surrogate. The second says that this resampling variance is comparable to the same actual positive squared-score cost. It gives no separately established root-order bound on that variance. No source mixture/covariance independence, density cap, free change of q, cancellation of original J or clock, or double subtraction of old square credit is authorized.

Thus these statements are accurate potential interfaces for subsequent arguments. They do not yet pay the R348 late soft residual, establish a new εX+C√nW receipt, alter the absorption ledger, or close any general historical/soft/scale slot.

## 4. Actual bounded checks

A local Python Fraction run passed 37 exact checks on a genuine positive-volume one-dimensional field: three compact source packets of masses 1,2/5,3/5, three receiver intervals of length 1/100 with constant complete capture patterns, actual R/m values 1,7/5,2 and q=1. Full receiver-interval capture/noncapture bounds were checked. At diagnostic K=11/8,3/2,2 the piecewise-constant actual H row/column capacities, exact common-source S swap and posterior variance bounds were checked. The source component had squared rational source fractions, so all posterior amplitudes and moments were rational. This fixture is not original high-past/outside/clock/root traffic, and these checks are not a new global budget or part of a primary run count. The general estimates above are analytic.

## Necessary inherited bindings
- `/tmp/r348_geometry.md` — SHA256 `e86647ca64922f06e3025fca655472a2860e42336506c432251f31a1ab30f137`
- `/tmp/r348_core.md` — SHA256 `dafedb811ac0719cf7a63502051dd13d2ccf5eb6cd5d695fb6854de509ff8ab3`
- `/tmp/r348_audit.md` — SHA256 `2709e8b8cc88976a36c269f20e74f8388b2e2dd45ff0fce21ceb2d2668e35df9`
- `/tmp/r347_geometry.md` — SHA256 `ac4e9b38400df1591d4f77bd289d13b08dc106167e7a173cc5daa0cb04c5d509`
- `/tmp/r346_geometry.md` — SHA256 `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`

## Independent extension: actual upper-tail logarithmic and mass moments

This extension was screened before reading R349 author files. Fix an actual source y, a threshold M>0, upper mass U=ρ_y{m>M}, and q=q_-. The SAME true receiver-volume envelope gives for every T≥M

    ρ_y{M<m≤T}≤[1+log(T/M)]/q.

The endpoint convention is strict at M and inclusive at T. At T=M the left side is zero; the positive upper bound 1/q is deliberately loose. This is not an assumption of source density or a simultaneous extremizer construction for the full f.

For U>0 put x=qU and consider the upper receiver measure in the logarithmic coordinate z=log(m/M)>0. Its cumulative mass up to z is at most (1+z)/q. Therefore its strict remaining tail has the lower bound [U-(1+z)/q]_+. Layer cake gives

    ∫_{m>M}log(m/M)ρ_y(dm)
       ≥(qU-1)_+²/(2q).

The positive-part convention includes x≤1, and all mass atoms stay in the exact strict/inclusive cumulative identities. There is no normalization at U=0.

For the first mass moment use the exact layer formula

    V=∫_{m>M}mρ_y(dm)=MU+∫_M^∞ρ_y{m>t}dt.

If x≤1, this gives V≥MU. If x≥1, integrate the lower remaining-mass bound on [M,M exp(x-1)]:

    V≥MU+(M/q)∫_1^{exp(x-1)}(x-1-log z)dz
      =(M/q)exp(x-1).

This stronger exponential lower bound is obtained by integrating the capacity tail, not by discarding the atom allowance and invoking a stronger Jensen conclusion. With finite actual receiver radii and mass ceiling these moments are finite; the same inequalities also have the usual nonnegative extended-integral meaning.

For M=Km_u, the normalized upper receiver probability ρ_y|{m>M}/U consequently obeys

    E[m_w/m_u]≥K                         if 0<x≤1,
    E[m_w/m_u]≥K exp(x-1)/x             if x≥1,
    E[log(m_w/m_u)]≥logK+(x-1)_+²/(2x) if x>0.

The first-moment exponential expression must be restricted to x≥1. Extending it to x<1 is unjustified and stronger than the stated general moment bound. In the original relative/high-past active application, however, U>εJ and J>B/ε imply qU>qB=1+√n>1, so the exponential branch is valid throughout the relevant original traffic support.

These are genuine lower bounds imposed by actual receiver geometry, not claims that one full f realizes equality for all sources/thresholds. They demonstrate that the normalized actual upper target may have large mass/log drift; they do not pay the original soft late residual, provide a usable source-integrated upper bound on that drift, or authorize treating a mass-compensation factor as constant. No new source/receiver fee or absorption is entered from these identities alone.

An additional local Python run passed 250 exact rational checks on scalar tail-capacity examples, using rational lower log2 enclosures and rational outward exponential upper bounds. It checked the assumed cumulative cap and the derived first/log moment inequalities in that scalar class. It is not an actual cube-sharpness, simultaneous-f, or original root-traffic certificate. This count is separate from the earlier 37 actual-1D mechanics assertions and from primary R349 runs.
