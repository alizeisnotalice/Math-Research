# R347 — Shifted-survival Hardy capacity for the actual upper flow

**Result and scope.** The R346 conservative upper flow, restricted to
\(U_y(Km_u)>\varepsilon J_b(y)\), has incoming receiver density
\[
 \kappa(w)\le \lambda C_\varepsilon\,
 \frac{\int g(y)c_w(y)1_{\{J_b(y)>h\}}\,dy}{m_w},
 \qquad C_\varepsilon=1+\log(1/\varepsilon).                 \tag{1}
\]
For \(0<\varepsilon\le1/2\), one may instead use the smaller
\(C_\varepsilon=1+\log((1-\varepsilon)/\varepsilon)\).
The shifted tail and every mass atom are retained. The gain is from the
crude \(1/\varepsilon\) column factor to a logarithmic factor; it is not an
\(\varepsilon X_q\) absorption or a root-order source payment.

## 1. Frozen original field and the exact column

Let \(n\ge1\), \(f\ge0\) be integrable, and let \(E\) carry actual Lebesgue
receiver measure \(du\). Put
\[
 Q_u=u+[-R_u/2,R_u/2]^n,\quad c_u(y)=1_{Q_u}(y),\quad
 m_u=\int f c_u=q_uR_u^n,\quad
 q_-\le q_u\le\lambda,\quad a\le R_u\le b\le2a,
\]
where \(q_->0\). Define
\[
 d\mu(u)=du/m_u,\quad \rho_y(du)=c_u(y)d\mu(u),\quad
 J_y=J_b(y)=\rho_y(E),\quad
 U_y(t)=\rho_y\{m>t\},\quad V_y(t)=\rho_y\{m\ge t\}.
\]
The total \(J_y\) is finite: the real-center envelope gives
\(J_y\le[1+n\log(b/a)]/q_-\). Use the unchanged physical prefixes
\(E_r=\{R_u\le r\}\), \(J_y(r)=\rho_y(E_r)\), and
\(\ell=b^{-n}\delta_b+n r^{-n-1}dr\) on \([a,b]\).
For the original parameters,
\[
 K=e^{\sqrt n},\qquad h=\frac{1+\sqrt n}{\varepsilon q_-},
 \qquad 0<\varepsilon<1,\qquad K>\lambda/q_- .                \tag{2}
\]
The last inequality holds for the original \(q_-=3\lambda/4\).

Let \(0\le g\le f\) be an outer source component. Every field above is still
computed from full \(f\). In the R346 notation retain the exact old factor
\(\Omega_y(u,r)\), containing the original small receiver, the original
\(1_{J_y(r)\ge H}/J_y(r)\), the lower-past gate, the outside-center gate,
and all other original masks. Set
\[
 \omega_y(u)=R_u^n\int_{[R_u,b]}\Omega_y(u,r)\ell(dr).
\]
As already proved there, \(0\le\omega\le1\). Its lower-past gate implies
\(\omega_y(u)=0\) unless \(J_y>h\). This uses terminal \(J_y\) only as a
consequence of the old gate, without changing the prefix denominator.

On \(U_y(Km_u)>\varepsilon J_y\) the probability routing kernel is exactly
\[
 T_y(u,dw)=\frac{1_{\{m_w>Km_u\}}\rho_y(dw)}{U_y(Km_u)}.
\]
Its original-traffic incoming density relative to **actual \(dw\)** is
\[
 \kappa(w)=\frac1{m_w}\int g(y)c_w(y)
  \int_{\{m_u<m_w/K\}}
   \frac{q_u\omega_y(u)1_{\{U_y(Km_u)>\varepsilon J_y\}}}
        {U_y(Km_u)}\,\rho_y(du)\,dy.                         \tag{3}
\]
Thus \(\int_E\kappa(w)dw=G\), the precise upper-high residual under study.
Equation (3) preserves the source \(y\), \(q_u\omega_y(u)\), the strict
mass gap, and the full old clock. No new prefix or receiver selector is used.

## 2. Sharp closed mass-window capacity from actual receiver volume

For every \(y,t>0\),
\[
 \rho_y\{t\le m_u\le Kt\}\le B_K,\qquad
 B_K=\frac{1+\log K}{q_-}.                                  \tag{4}
\]
Indeed, set \(d=2\|u-y\|_\infty\). On the indicated captured receivers,
\[
 \frac1{m_u}\le\frac1{\max\{t,q_-d^n\}},\qquad
 d^n\le Kt/q_-.
\]
The Lebesgue volume of \(\{u:d^n\le z\}\) is exactly \(z\). Integrating the
displayed majorant over all such centers yields
\[
 \int_0^{Kt/q_-}\frac{dz}{\max\{t,q_-z\}}
   =\frac1{q_-}+\frac{\log K}{q_-}.
\]
Both endpoints of the mass window are included. Restricting the actual
receiver set or its physical radii can only reduce this integral. This is
a real-center estimate for \(c_u\,du/m_u\); it uses no source density bound.
In particular, no factor \(\log(\lambda/q_-)\) is needed in (4).

Consequently
\[
 V_y(m)-U_y(Km)=\rho_y\{m\le m_u\le Km\}\le B_K.              \tag{5}
\]

## 3. Shifted Hardy lemma, including all atoms

Consider any finite positive measure \(\rho\) on positive masses, of total
mass \(J>0\), satisfying the closed-window bound (4) with a constant \(B\).
Let \(U(m)=\rho\{M>m\}\), \(V(m)=\rho\{M\ge m\}\), and
\(a_0=\theta J\), \(0<\theta<1\). For every measurable additional restriction
\(A\),
\[
 \int_A\frac{1_{\{U(KM)>a_0\}}}{U(KM)}\,d\rho
 \le \int_{a_0}^J\frac{dt}{\max\{a_0,t-B\}}
 =F(\theta,B/J),                                          \tag{6}
\]
where
\[
 F(\theta,\beta)=
 \begin{cases}
 \beta/\theta+\log((1-\beta)/\theta),&0\le\beta\le1-\theta,\\
 (1-\theta)/\theta,&\beta\ge1-\theta.
 \end{cases}                                              \tag{7}
\]
The two formulas agree at \(\beta=1-\theta\).

Here is an atom-safe proof. Push \(\rho\) to its mass variable and represent
that distribution by its increasing generalized quantile at Lebesgue
parameter \(s\in(0,J)\); put \(t=J-s\). Almost everywhere the sampled mass
\(M\) obeys \(t\in[U(M),V(M)]\). In particular a mass atom of weight \(d\)
occupies its entire rank interval \((U(M),V(M)]\), of length \(d\).
On an active mass,
\[
 U(M)\ge U(KM)>a_0,\qquad
 U(KM)\ge V(M)-B,
\]
and therefore, throughout its rank interval,
\[
 \frac1{U(KM)}
 \le\frac1{\max\{a_0,V(M)-B\}}
 \le\frac1{\max\{a_0,t-B\}}.
\]
All active ranks lie in \((a_0,J)\). Integrate on their rank set, then enlarge
to this interval. An additional restriction \(A\) merely removes
nonnegative contributions. This proves (6), without splitting or deleting
a physical mass atom. Endpoint choices in the rank variable are null.
The explicit integral gives (7).

The function \(F\) is nondecreasing in \(\beta\). In its first regime its
derivative is \(1/\theta-1/(1-\beta)\ge0\), and then it is constant.
In particular
\[
 F(\theta,\beta)\le\beta/\theta+\log(1/\theta).              \tag{8}
\]
For the second regime, this follows by evaluating the right side at
\(\beta=1-\theta\); its value already exceeds \(F\).
If \(\beta<\theta\) and \(\theta\le1/2\), the stronger bound is
\[
 F(\theta,\beta)\le1+\log((1-\theta)/\theta).                \tag{9}
\]
For all \(0<\theta<1\) with \(\beta<\theta\), (8) gives
\(F\le1+\log(1/\theta)\).

The denominator in (6) remains the genuinely shifted \(U(KM)\). The window
loss \(B\) in its proof includes the atom at \(M\), every intermediate atom,
and the atom at \(KM\).

## 4. Application to the genuine R346 receiver column

For (2), the sharp capacity satisfies
\[
 B_K=(1+\sqrt n)/q_-=\varepsilon h.
\]
Every nonzero row of (3) has \(J_y>h\), hence
\(B_K/J_y<\varepsilon\). Apply (6) with \(\theta=\varepsilon\) and the
unchanged additional restriction \(A=\{m_u<m_w/K\}\). Positively bounding
\(q_u\omega_y(u)\le\lambda\) gives the sharper source-dependent version
\[
 \kappa(w)\le\frac{\lambda}{m_w}
   \int g(y)c_w(y)1_{\{J_y>h\}}
       F(\varepsilon,B_K/J_y)\,dy.                         \tag{10}
\]
Equations (8),(9) give (1). The \(w\)-cutoff was kept on the left of the
Hardy inequality and then enlarged on the right; no extra gain from that
cutoff is claimed. Neither \(q_u\) nor the original \(\omega\) is altered
in the conserved representation (3).

Writing \(X_q=\int_E q_w\,dw\), integration yields the valid ledger
\[
 \begin{split}
 G&\le\lambda\int g(y)1_{\{J_y>h\}}
       F(\varepsilon,B_K/J_y)\,J_y\,dy\\
  &\le\lambda C_\varepsilon\int g(y)1_{\{J_y>h\}}J_y\,dy
   \le\lambda C_\varepsilon |E|
   \le(\lambda/q_-)C_\varepsilon X_q.                     \tag{11}
 \end{split}
\]
The penultimate inequality follows from \(g\le f\) and the exact identity
\(\int f(y)J_y\,dy=\int_E m_w\,dw/m_w=|E|\).
Pointwise \(\int g c_w\le m_w\) also gives
\(\kappa(w)\le\lambda C_\varepsilon\).

This is an improved capacity of the same conservative flow. Its total
coefficient is still not small, and (11) has no source-only
\(C_\varepsilon\sqrt n\,W\) term. Thus it cannot be inserted as an
\(\varepsilon X_q\) payment. Obtaining one would require additional
geometry of the actual \(q_u\omega_y(u)\), the \(w\)-restriction, or the
remaining source-weighted quantity in the first line of (11); none is
asserted here. The upper-low complement already paid elsewhere is not
charged again. All original exterior coefficients multiply these bounds.
No original square, prefix, terminal atom, or old mask has been replaced.

## 5. Reproducible finite checks and stopping point

Actual local execution of /tmp/r347_core_checks.py passed:

- 80 finite atomic measures on masses \(1,2,4,8\), with weights in
  \(\{0,1,2\}\), excluding the zero measure;
- 960 full shifted-Hardy cases, using \(K=3/2,2,3\) and
  \(\theta=1/10,1/4,1/2,3/4\);
- 3,840 restricted \(m_u<m_w/K\) columns;
- 643 exact Fraction active-atom inequalities and 643 corresponding
  rank-integral comparisons;
- 1,680 closed-window endpoint checks and 196 high-occupancy specialization
  checks;
- 18 longer atomic-string cases (16, 32, 64 masses) testing small \(\theta\)
  and exact shifted endpoint atoms.

Fractions handle tail decisions and atoms exactly. Logarithmic comparisons
use 80-digit Decimal arithmetic with tolerance \(10^{-65}\); these are
diagnostics, while §§2–4 are the proof. The finite measures test the Hardy
lemma and its endpoints, not realization of the full original cube field.
The actual-receiver geometric input is proved directly in §2.
Only this note and its check script are authored. Bounded delivery stops
with the improved column estimate; general root closure remains open.
