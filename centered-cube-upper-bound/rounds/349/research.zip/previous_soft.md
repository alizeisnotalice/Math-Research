# R348 — One-shot soft settlement on the complete actual mass axis

**Proved improvement.** The R347 Top-hit payment can be replaced, at the
same source cost and no new receiver fee, by a soft payment on **every**
original relative-upper row. It clears the entire former Top-hit branch
and also deducts positive traffic from the remaining high-score rows.
The exact remainder is retained below. No general root estimate for that
remainder is claimed.

## 1. Frozen field and exact soft payment

Keep the R347 core and geometry contract:
\[
 m_u=\int f c_u=q_uR_u^n,\quad q_-\le q_u\le\lambda,\quad
 a\le R_u\le b\le2a,\quad d\rho_y(u)=c_u(y)du/m_u.
\]
Here \(f\ge0\) is the original integrable source, \(c_u=1_{Q_u}\), and
receiver measure is actual \(du\). All fields use full \(f\), even when
the outer source is \(0\le g\le f\). Write
\[
 J_y=J_b(y),\quad U_y(t)=\rho_y\{m>t\},\quad
 K=e^{\sqrt n},\quad B=(1+\sqrt n)/q_-,\quad h=B/\varepsilon,
 \quad L_\varepsilon=1+\log(1/\varepsilon).
\]
Use \(0<\varepsilon<1\) and the original \(K>\lambda/q_-\).
The original physical clock is
\(\ell=b^{-n}\delta_b+n r^{-n-1}dr\), including its terminal atom.

Let \(\omega_y(u)\in[0,1]\) be the **original** clock-integrated row factor
from R346/R347, with the original full \(J_y(r)\), high-past, far-mass,
outside-center and \(H\) gates. Put
\[
 a_y(u)=q_u\omega_y(u),\quad
 \mathcal A_y=\{u:U_y(Km_u)>\varepsilon J_y\},\quad
 \tau=2\lambda B.
\]
On every nonzero traffic row \(J_y>h\). The exact traffic is
\[
 G_{\rm rel}[g]=\int g(y)\int_{\mathcal A_y}a_y(u)d\rho_y(u)\,dy.
\]
Division below is only on \(\mathcal A_y\), where the denominator is
positive. Define
\[
 p_y(u)=\min\{a_y(u),\tau/U_y(Km_u)\},\qquad
 r_y(u)=(a_y(u)-\tau/U_y(Km_u))_+.
\]
Then, with **no inequality in the decomposition**,
\[
 G_{\rm rel}[g]=P[g]+G_{\rm soft}[g],\quad
 P[g]=\int g\int_{\mathcal A_y}p_y\,d\rho_y,\quad
 G_{\rm soft}[g]=\int g\int_{\mathcal A_y}r_y\,d\rho_y.       \tag{1}
\]
The proved payment is
\[
 P[g]\le 2\lambda B L_\varepsilon\int g.                    \tag{2}
\]
Indeed, the closed-window capacity
\(\rho_y\{t\le m\le Kt\}\le B\), actual high past \(J_y> B/\varepsilon\),
and the atom-safe shifted Hardy lemma give
\[
 \int_{\mathcal A_y}\frac{d\rho_y(u)}{U_y(Km_u)}
 \le L_\varepsilon.
\]
Multiply by \(\tau\). Rows with \(\omega=0\) contribute zero; the estimate
is needed only on high-past source rows. This preserves all original
strict-tail conventions and all original clocks. It does not route a
previously transported density as if it were a new original \(a\le\lambda\)
row.

The source coefficient in (2) is
\[
 C_{\rm soft,n,\varepsilon}
  =2(\lambda/q_-)(1+\sqrt n)[1+\log(1/\varepsilon)].         \tag{3}
\]
In particular \(g=g_{\rm ex}\) costs its actual mass \(W_{\rm ex}\).
There is no additional \(X_q\) charge.

## 2. It replaces the whole old Top-hit payment

Let \(M(y)=\operatorname{ess\,sup}_{\rho_y}m\),
\(\mathrm{Top}_y=\{M(y)/K\le m\le M(y)\}\), and let \(p_{\rm Top}(y,u)\)
denote the fraction of the strict upper tail \(m_w>Km_u\) lying in Top.
R347 proved \(\rho_y(\mathrm{Top}_y)\le B\).

If \(p_{\rm Top}\ge1/2\), then
\[
 U_y(Km_u)\le2\rho_y(\mathrm{Top}_y)\le2B,
 \qquad a_y(u)U_y(Km_u)\le2\lambda B=\tau.
\]
Thus \(r_y(u)=0\) on the entire old paid branch. Everywhere else
\(0\le r_y(u)\le a_y(u)\). Consequently
\[
 G_{\rm soft}[g]\le
 G_{\rm rel,\ p_{\rm Top}<1/2}[g].                         \tag{4}
\]
This is a same-price improvement of the old residual, not a second fee.

The precise extra fully cleared region includes
\[
 U_y(Km_u)>2B,\qquad
 \omega_y(u)\le\frac{2\lambda B}{q_u U_y(Km_u)}.
\]
Such rows necessarily have \(p_{\rm Top}<1/2\). We do not assert that this
additional set has positive measure for every field. Moreover, on **every**
row with \(a_yU_y>\tau\), including those not fully cleared, (1) still
subtracts exactly \(\tau/U_y\). Replacing the new remainder by
\(a_y1_{\{a_yU_y>\tau\}}\) would discard this improvement and is not done.

Rebuild the ledger from the original R346 inequality
\(B_H\le G_{\rm rel}[g_{\rm ex}]+\mathrm{old\ fees}\).
Insert the exact identity (1) and then (2), obtaining
\[
 B_H\le G_{\rm soft}[g_{\rm ex}]
       +C_{\rm soft,n,\varepsilon}W_{\rm ex}
       +\mathrm{old\ fees}.
\]
The price (3) equals the R347 coefficient
\(C_{\rm hit,n,\varepsilon}\); this equality of receipt prices leaves the
other fees, receiver coefficient and exterior multipliers unchanged.
This reconstruction uses the original \(G_{\rm rel}\) ledger, not a
substitution of a smaller remainder into the already established R347
upper bound.

## 3. Exact one-shot target optimization, with a common quantile block

This section specifies what an upper-average target can accomplish; the
payment (2) does not assume the desired target exists.

Fix a nonzero high-past source row and any measurable retained set
\(A\subseteq\mathcal A_y\). Set \(d(u)=a_y(u)/\lambda\in[0,1]\).
Consider nonnegative target densities \(t_y(w)\) with the original
\(\rho_y(dw)\), subject to
\[
 \int_{\{m_w>Km_u\}}t_y(w)d\rho_y(w)
       \ge d(u)U_y(Km_u)\quad\text{for }\rho_y\text{-a.e. }u\in A.
                                                                  \tag{5}
\]
Then the exact optimal total target capacity is
\[
 \inf_{t\ {\rm satisfying}\ (5)}\int t\,d\rho_y
  =M_A(y):=\operatorname{ess\,sup}_{u\in A}
                         d(u)U_y(Km_u).                    \tag{6}
\]
The empty-set value is zero. The lower bound follows directly from each
constraint (5).

Here is an actual common target attaining it, including atoms.
Let \(m_0=q_-a^n\), \(m_1=\lambda b^n\), \(s_y=\varepsilon J_y\), and
\[
 \sigma_y=\inf\{t\in[m_0,m_1]: U_y(t)\le s_y\}.
\]
Strict tails are right-continuous and inclusive tails are their left
limits. Thus
\[
 U_y(\sigma_y)\le s_y\le V_y(\sigma_y),
 \qquad V_y(t)=\rho_y\{m\ge t\}.
\]
Define \(\gamma_y=(s_y-U_y(\sigma_y))/
[V_y(\sigma_y)-U_y(\sigma_y)]\) when this denominator is positive, and
zero otherwise. The top-quantile weight
\[
 \eta_y(w)=1_{\{m_w>\sigma_y\}}
              +\gamma_y1_{\{m_w=\sigma_y\}}
\]
has \(0\le\eta\le1\) and \(\int\eta_y\,d\rho_y=s_y\). For every active
\(u\), \(U_y(Km_u)>s_y\) forces \(Km_u<\sigma_y\). Therefore its strict
upper tail contains the entire support of \(\eta_y\), including the
fractional threshold atom. Set
\[
 t_y(w)=\frac{M_A(y)}{s_y}\eta_y(w).
\]
Its total capacity is \(M_A(y)\), and every upper-tail integral in (5)
equals \(M_A(y)\). This proves attainment of (6).

All these objects can be selected jointly measurably: \(U_y(t)\) is
jointly measurable by Tonelli, the monotone quantile is characterized by
rational thresholds, and
\(\{M_A>z\}=\{\int_A1_{\{dU>z\}}d\rho_y>0\}\).
Zero rows are assigned zero targets. The fractional atom is a density
weight on the existing receivers, not an added receiver or a new field.

For the soft-paid density \(p_y/\lambda\), its score is bounded by
\(\tau/\lambda=2B\), so the same construction supplies a genuine target
of total capacity at most \(2B\), covering **all** paid rows at once.
For full \(a_y\), (6) shows that the actual missing condition for this
particular target class is a bound on \(M_{\mathcal A}\), or its source
integral. That bound has not been proved. Formula (6) is an exact
optimization statement, not itself a new root receipt.

## 4. What the original clock says about the high-score remainder

There is an exact physical-clock factorization for the original G_out
gates, useful for keeping the remaining demand tied to the real field.
Define
\[
 D_y(u)=1_{\{Z_y(m_u/K-)>h\}}
 \int_E c_v(y)(1-m_v/m_u)1_{\{m_v<m_u/K\}}
       1_{\{\|u-v\|_\infty>\alpha R_u/2\}}\,d\mu(v).
\]
Every contributing \(v\) satisfies
\[
 R_v^n=m_v/q_v<m_u/(Kq_-)
       \le[\lambda/(Kq_-)]R_u^n<R_u^n .
\]
Hence all such \(v\) already belong to every original prefix \(E_r\) with
\(r\ge R_u\). No future receiver is inserted in that prefix. Put
\[
 J_0=J_y(R_u),\qquad
 C_y(u)=R_u^n\int_{[R_u,b]}
               \frac{1_{\{J_y(r)\ge H\}}}{J_y(r)}\,\ell(dr).
\]
On a nonzero row, \(J_0>h\), and the original factor is exactly
\[
 \omega_y(u)=D_y(u)C_y(u),\qquad
 0\le D_y(u)\le J_0,\qquad 0\le C_y(u)\le1/J_0.             \tag{7}
\]
The relative-upper and Top gates depend only on \(y,u\) and do not alter
this identity. It is asserted for the original gates displayed above,
not for arbitrary added \(r\)-dependent masks.

Define the exact clock deficit
\[
 \Theta_y(u)=R_u^n\int_{[R_u,b]}
   \left[1-\frac{J_0\,1_{\{J_y(r)\ge H\}}}{J_y(r)}\right]\ell(dr).
\]
Then \(0\le\Theta\le1\), including continuous and atomic clocks, and
\[
 J_0C_y(u)=1-\Theta_y(u),\quad
 a_y(u)U_y(Km_u)
  =\frac{q_uD_y(u)U_y(Km_u)}{J_0}\,[1-\Theta_y(u)].         \tag{8}
\]
This uses the exact inclusive identity \(R_u^n\ell([R_u,b])=1\).

Consequently every nonzero soft remainder has the actual quantitative
constraint
\[
 q_uD_y(u)U_y(Km_u)[1-\Theta_y(u)]>\tau J_0,                \tag{9}
\]
and therefore \(U_y(Km_u)>2B\) and
\(q_uD_y(u)U_y(Km_u)>\tau J_0\).
The new positive-part density remains exactly
\[
 \left(\frac{q_uD_y(u)}{J_0}[1-\Theta_y(u)]
                 -\frac{\tau}{U_y(Km_u)}\right)_+ .
\]
There is no proof here that the common-source product in (9) is small
after source integration. In particular, neither the clock deficit nor
the outside past factor may be replaced by a favorable independent
average.

A further valid quantitative bound, without a claimed payment, is
\[
 G_{\rm soft}[g]\le\frac1{4\tau}
   \int g(y)\int_{\mathcal A_y} a_y(u)^2U_y(Km_u)d\rho_y(u)\,dy. \tag{10}
\]
It follows from \((x-1)_+\le x^2/4\).
The numerator is the genuine common-source upper-pair integral
\[
 \int g(y)\iint q_u^2\omega_y(u)^2
    1_{\mathcal A_y}(u)1_{\{m_w>Km_u\}}
                 d\rho_y(u)d\rho_y(w)\,dy.
\]
The squared \(\omega\) still contains the two original clock integrals
and their original full prefixes through (7). This expression is not
an independently available negative capture-square credit. No additional
source budget for it is established.

## 5. Actual local checks and finite scope

The saved script /tmp/r348_core_checks.py was actually run and passed:

- 144 finite atomic fields and their common top-quantile target constructions;
- 1,396 active-row target constraints, exact soft decompositions and
  rational square inequalities;
- 120 old Top-hit inclusion checks;
- 90 shifted-Hardy soft-payment diagnostics at 70-digit Decimal precision;
- 16 exact physical-clock calculations with continuous pieces and a
  terminal atom, including \(H\)-crossing and never-crossing cases.

Atom decisions, target mass, decompositions and clock calculations use
Fraction arithmetic. Decimal comparisons are diagnostics, not proofs.
These finite atomic distributions test the algebra; they do not assert
realization of the original cube geometry. The geometric window input
and preservation of the actual original clock are analytic facts used
above. No source-density cap, altered full-f field, or free iteration is
introduced.

The new proved budget is (2), replacing the old payment at equal cost
while reducing its exact remainder to (1). The remaining global estimate
is not established. Only this file and its check script are authored;
bounded delivery stops here.
