# R346 — Conservative upper-receiver flow with exact clock migration

**Status.** The normalized upper lift preserves the original traffic and its common source. Actual overlap cancels the pairwise exponential clock ratio, and a real-center envelope gives a polynomial receiver-column bound. The remaining column accumulation is not root-order paid. No future receiver is inserted into the old J, and no claim is made that transported traffic is the original G at its new endpoint.

## Original traffic and conservative lift

Use exactly the R345 geometry contract. In particular ρ_y(du)=c_u(y)du/m_u, U_y(t)=ρ_y{m>t}, q_-≤q_u≤λ, a≤R_u≤b≤2a, and K>λ/q_-. Let g≤f be any nonnegative source component; all fields remain those of full f. Retain the original lower occupancy, far-mass, outside-center and H gates, and optionally any original large-endpoint mask. Restrict to U_y(Km_u)>s with s>0.

Absorb the original small-endpoint integration and all gates into

    Ω_y(u,r)=1_{J_y(r)≥H}/(m_uJ_y(r))
       ×∫_{E_r}c_v(y)(m_u−m_v)
          1_{m_u>K m_v}1_{Z_y(m_u/K−)>h}
          1_{||u-v||∞>αR_u/2}[optional masks]dμ(v),

using zero on zero rows. Thus 0≤Ω≤1. The original residual is exactly

    G=∫g(y)dy∫E c_u(y)du 1_{U_y(Km_u)>s}
                       ∫_[R_u,b] Ω_y(u,r)ell(dr).    (1)

Define on the upper-high branch

    T_y(u,dw)=1_{m_w>K m_u}ρ_y(dw)/U_y(Km_u).         (2)

This is a probability kernel. All functions are measurable by Tonelli; its denominator is strictly larger than s. Hence inserting T into (1) produces a nonnegative common-source triple flow (u,v,w), with total mass exactly G. Terminal upper occupancy is used only for the routing kernel; it is not replaced by a physical-prefix tail.

For a clock-integrated representation set

    ω_y(u)=R_uⁿ∫_[R_u,b]Ω_y(u,r)ell(dr),  0≤ω≤1.

The source–u outgoing flow is g(y)q_uω_y(u)ρ_y(du)dy on U>s. Its incoming density relative to actual dw is

    κ(w)=1/m_w ∫g(y)c_w(y)
       ∫_{m_u<m_w/K} q_uω_y(u)1_{U_y(Km_u)>s}
                    ρ_y(du)/U_y(Km_u) dy,
    ∫E κ(w)dw=G.                                    (3)

The same source y remains in every factor.

## Actual receiver-column bound using overlap

Let I_uw^g=∫g c_uc_w and I_uw=∫f c_uc_w. From (3), g≤f, ω≤1 and U>s,

    κ(w)≤1/(s m_w)∫_{m_u<m_w/K}R_u^(-n)I_uw^g du.  (4)

Put m_0=q_-aⁿ. If m_w/K≤m_0 this column is zero. Otherwise set

    B_w=min{b,(m_w/(Kq_-))^(1/n)},
    A_w=1+n log(B_w/a).

Every contributing u has R_u≤B_w. The real-center radial envelope gives, for every source y,

    ∫_{m_u<m_w/K}c_u(y)R_u^(-n)du≤A_w.             (5)

Indeed capture implies 2||u−y||∞≤R_u, so the density is at most max{a,2||u−y||∞}^(-n), supported in the cube of side B_w centered at y. Its exact integral is 1+n log(B_w/a). This is actual receiver volume, not a source density estimate.

Fubini in (4), followed by ∫g c_w≤m_w, therefore yields

    κ(w)≤(A_w/s) [∫g c_w/m_w]≤A_w/s,
    G≤(1/s)∫E A_w dw≤A_max X_q/(s q_-),              (6)

where A_w=0 for a zero column, and, when λbⁿ>Kq_-aⁿ,

    A_max=1+log(λbⁿ/(Kq_-aⁿ)).

If the last strict inequality fails, there is no mass-separated upper pair and G=0. In the nonempty case A_max is positive. Formula (6) avoids a 2ⁿ receiver enlargement. However at s=√n/q_- it still permits G≤(A_max/√n)X_q=O(√n)X_q. This is not an absorbable εX_q estimate and supplies no new source price.

The lower-high gate remains in ω but was dropped positively in this column bound. No improvement from it is asserted.

## A stronger tilted column, and why it is not the conserved flow

For fixed y,w the mass-tilted incoming kernel obeys

    ∫_{m_u<m_w/K,U_y(Km_u)>s}
          (m_u/m_w)ρ_y(du)/U_y(Km_u)
       ≤1/(Kq_-s).                                  (7)

Proof: m_uρ_y(du)=c_u(y)du. All contributing centers lie in the cube centered at y of side (m_w/(Kq_-))^(1/n). Its volume is m_w/(Kq_-); division by sm_w gives (7). This includes empty columns and uses no independence of source posteriors.

The factor m_u/m_w in (7) is essential. Inserting it into (2) destroys row normalization; the original flow (3) does not carry it. The physical migration below supplies its inverse, so (7) cannot be substituted as an exponential improvement of the conserved traffic without paying that inverse.

## Exact physical-clock migration and pairwise cancellation

On every lifted pair m_w>K m_u, the actual q bounds imply R_w>R_u. Let z=R_w/R_u and define

    r'=min{zr,b}.

For the unweighted original clock this deterministic map has exact pushforward

    (r↦min{zr,b})_# [ell restricted to [R_u,b]]
             = zⁿ [ell restricted to [R_w,b]].       (8)

For r'<b this is the usual change of variable in n r^(-n-1)dr. The entire original tail r≥b/z maps to b, with mass (b/z)^(-n)=zⁿb^(-n), exactly the new terminal atom. This proves (8) also when R_w=b.

For the actual old-row factor Ω, its pushed conditional average is

    Ωbar(r')=Ω(r'/z) for R_w≤r'<b,
    Ωbar(b)=(b/z)ⁿ∫_[b/z,b]Ω(r)ell(dr),

so 0≤Ωbar≤1 and

    ∫_[R_u,b]Ω(r)ell(dr)
       =zⁿ∫_[R_w,b]Ωbar(r')ell(dr').                 (9)

The J and all original gates inside Ωbar are evaluated at their old r, or averaged over the indicated old tail at b. Replacing them by fields at r' is not licensed by (9).

The migration factor is exactly

    zⁿ=(m_w/m_u)(q_u/q_w).                           (10)

The true source overlap gives the useful pairwise cancellation

    zⁿ I_uw^g/m_w
        =(q_u/q_w) I_uw^g/m_u≤λ/q_-.                (11)

Thus the exponential-looking radius ratio need not be paid independently of overlap. But (11) is a per-pair statement. The original denominator U depends on y, and summing all incoming u still has a real capacity cost. Using U>s before source integration and the real-center envelope gives (4)–(6); it does not produce a source-only root receipt. Bounding the remaining u domain merely by the cube of side 2R_w would reintroduce 2ⁿ, which (5) avoids.

Nor is the shifted flow automatically an original w-large traffic term: the old u–v outside-center gate does not imply the corresponding w–u gate, the current denominator is still the original J, and the upper-high condition need not persist at w. These are genuine constraints on any attempted iteration.

## Ledger and finite scope

Equations (1)–(3) are conservative identities for the original two-sided residual and introduce no new fee. Equations (6),(7),(11) are proved capacities with their stated measures and weights. They cannot be combined by deleting the mass tilt or the clock multiplier. The useful remaining object is the actual incoming density (3), with its y-dependent U and exact overlap; its generic bound here is only (6). No root-order source budget or εX_q absorption follows. Any outer coefficient multiplies G and all costs above. The source clipping and future-low payments already made in R345 remain separate and are not charged again.

A saved exact check script verifies the normalized flow and atom migration, including a genuine positive-volume cube fixture at diagnostic thresholds. It is not a simulation of the original n-dimensional root residual. Details follow after execution.

Actual execution: '/tmp/r346_core_checks.py' passed 73 exact Fraction check units: 11 real-cube geometry/mass checks, 3 normalized upper rows, 9 tilted columns, 7 flow/clock-average checks, 40 clock-pushforward tail/atom cases, and 3 overlap cancellations. The positive-volume one-dimensional field has three source packets of masses 1,2/5,3/5 and three receiver intervals of length 1/25, with actual radii and masses 1,7/5,2 and q=1 throughout. At diagnostic K=11/8 and h=s=1/100, the middle receiver at the first source packet has both lower and upper occupancy. Using its real full-J small-pair row, but omitting the outside-center condition for this diagnostic only, the exactly lifted mass is 87/21700 and incoming density relative to dw is 87/868. The future radius is b=2, so this example explicitly checks collapse of the original continuous clock into the terminal atom, with its correct conditional average. Separate clock tests cover dimensions 1,2,4,8. These computations do not satisfy or test the original root outside-center traffic, and no root-budget evidence is inferred. Only this note and its check script were authored; bounded delivery stops here.
