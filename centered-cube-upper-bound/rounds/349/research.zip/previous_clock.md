# R348 — The original physical clock pays already-arrived upper capture

This note proves a new common-source, actual-center clock moment and uses it to pay a positive piece of the soft residual. It does not bound the remaining late-upper traffic. The old small receiver, outside-center gate, H, denominator J, mass gap, source f, and terminal clock atom remain frozen.

## Exact candidate and proved statement

Use the R347/R346 field: f≥0 in L¹, real receiver set E with Lebesgue du, a≤R_u≤b≤2a, m_u=∫Q_u f=q_uR_uⁿ, q_-=3λ/4≤q_u≤λ, c_u(y)=1Q_u(y), dμ=du/m_u, and ρ_y(du)=c_u(y)dμ(u). Let

    J_y(r)=ρ_y{R_u≤r},  J_b(y)=ρ_y(E),
    U_y(t)=ρ_y{m_u>t},
    U_y^r(t)=ρ_y{m_u>t, R_u≤r}.

Use the original K=e^(√n), h=(1+√n)/(εq_-), H, α, and

    ell=b^(-n)δ_b+n r^(-n-1)dr on [a,b],
    ell([R,b])=R^(-n).

The old nonnegative factor Ω_y(u,r) is exactly the original small-endpoint row divided by m_uJ_y(r), including high-past, strict far-mass, outside-center, H and all existing gates. Its established bound is 0≤Ω≤1. Its clock average and score are

    ω_y(u)=R_uⁿ∫_[R_u,b]Ω_y(u,r)ell(dr),
    a_y(u)=q_uω_y(u),   0≤a_y(u)≤q_u.

All quantities are defined by full f. Put

    B=(1+logK)/q_-=(1+√n)/q_-,  τ=2λB,
    η_y(u)=(1-τ/[a_y(u)U_y(Km_u)])_+,

with η=0 when the denominator is zero. Thus 0≤η≤1 is a measurable fractional mask. It multiplies the old Ω without recomputing a, masses, J or physical prefixes.

For 0≤g≤f, the soft residual is exactly

    R[g]=∫g(y)dy∫E c_u(y)du 1_{U_y(Km_u)>εJ_b(y)}
                   ∫_[R_u,b]η_y(u)Ω_y(u,r)ell(dr).     (1)

For t>0 let R_arr(t)[g] be (1) with the additional original-time gate

    U_y^r(Km_u)>t,

and R_late(t)[g] its complementary gate U_y^r(Km_u)≤t. Then

    R[g]=R_arr(t)[g]+R_late(t)[g],                       (2)
    R_arr(t)[g]≤[2λ/(Kq_-t)]∫g(y)J_b(y)dy
                 ≤[2λ/(Kq_-²t)]X_q.                   (3)

The quantified candidate (3) holds for every field in the frozen contract, every such g, every t>0, and every additional mask bounded by one. It is proved below without substituting terminal upper occupancy for prefix occupancy.

At the fixed threshold t=1/q_-, write

    γ_n=2(λ/q_-)e^(-√n).

Then the new payment is

    R_arr(1/q_-)[g]≤γ_n X_q.                           (4)

This is a receiver fee, not a source-only fee. Its smallness at the actual high-past parameter is proved separately below, rather than inferred from informal dimension asymptotics.

## Real inverse-mass-square capacity

Fix a source y, a large receiver u capturing y, and M=Km_u. Since K>λ/q_-, any w with m_w>M satisfies R_w>R_u. The following actual-center capacity is dimension-independent:

    ∫_{m_w>Km_u} (m_u/m_w)ρ_y(dw)≤2/(Kq_-).          (5)

Indeed, for captured w let z=(2||w-y||∞)ⁿ. Then R_wⁿ≥z and

    m_w≥q_-R_wⁿ≥q_-z,    m_w>Km_u=M.

Thus the left side is bounded by the real Lebesgue integral

    m_u∫_{Rⁿ} dw / max{M,q_-(2||w-y||∞)ⁿ}².

The volume of the sublevel set {(2||w-y||∞)ⁿ≤z} equals z. The last integral is therefore exactly

    m_u[∫_0^{M/q_-} dz/M²+∫_{M/q_-}^∞ dz/(q_-z)²]
      =2m_u/(Mq_-)=2/(Kq_-).

Dropping E and the radius bounds only enlarged the integral. This is a density estimate for the actual receiver measure du/m_w², not a bound on source density f. No small boundary volume is converted into small f-mass.

## Full physical clock, including its terminal atom

Define the normalized old clock probability for receiver u by

    dP_u(r)=R_uⁿ1_[R_u,b](r)ell(dr).

Its total mass is exactly one, including R_u=b. Tonelli, R_w>R_u and the inclusive tail give the exact identity

    E_{P_u}[U_y^r(Km_u)]
      =∫_{m_w>Km_u} R_uⁿ ell([R_w,b])ρ_y(dw)
      =∫_{m_w>Km_u}(R_u/R_w)ⁿρ_y(dw).              (6)

For a witness with R_w=b, the right side includes (R_u/b)ⁿρ_y(dw); it is supplied precisely by the old b atom. Such witnesses are not removed or moved to a new atom.

The true mass and average relation gives

    (R_u/R_w)ⁿ=(m_u/m_w)(q_w/q_u).

Hence (5), q_w≤λ and (6) imply

    q_u E_{P_u}[U_y^r(Km_u)]≤2λ/(Kq_-).             (7)

The arbitrary terminal upper capture U_y(Km_u) need not be small. Equation (7) says that its arrival within the actual old clock has a small joint moment. It is the required coupling of the true source, mass-separated upper receivers, center geometry, and the physical tail.

## Source-integrated moment and the arrived branch

More generally, let F_y(u,r) be any measurable factor between zero and one; it may contain every original gate and η. Then (7) gives

    ∫g(y)dy∫E c_u(y)du∫_[R_u,b]
          F_y(u,r)U_y^r(Km_u)ell(dr)
      ≤[2λ/(Kq_-)]∫g(y)J_b(y)dy.                   (8)

To check the measures, c_u du times the old clock equals q_uρ_y(du) times P_u. Thus (8) follows by integrating (7) under g(y)ρ_y(du)dy. Original high-past support may be retained on the right as 1_{J_b>h}, though it is not needed for the stated bound.

Choose F=ηΩ1_{U(Km_u)>εJ_b}. On U_y^r(Km_u)>t, its indicator is bounded by U_y^r(Km_u)/t. This proves the first inequality in (3). The second follows from the exact frozen-source identity

    ∫g(y)J_b(y)dy
      =∫E [∫Q_u g(y)dy/m_u]du
      ≤∫E [∫Q_u f(y)dy/m_u]du
      =|E|≤X_q/q_-.

The full source f is never replaced in m_u. The result uses actual common-source overlap throughout and holds in particular for g_ex=(f-T_clip)_+.

## Effective fee and rigorous smallness at the prescribed ε

The established real-center occupancy bound is J_b≤A_n/q_-, where A_n=1+n log(b/a). If any original high-past traffic is nonzero, then necessarily

    A_n>(1+√n)/ε.                                  (9)

If εA_n≤1+√n, the original traffic, and therefore (1), is zero. Set γ_eff=0 in this case; otherwise set γ_eff=γ_n. This is an exact dimension/radius guard, not a favorable-field assumption.

Whenever (9) holds, put x=√n≥1. Since A_n≤1+n log2<1+n and (1+x²)/(1+x)≤x for x≥1, (9) implies

    x>1/ε.                                         (10)

At the actual ε=119/3072 and λ/q_-=4/3, use e^x>x⁴/24 to obtain

    γ_n=(8/3)e^(-x)<64ε⁴<ε/16.                    (11)

The last strict inequality is the exact rational check 1024ε³<1; no floating-point exponential estimate is needed. Thus in every dimension, either the original high-past traffic is empty or the new fee γ_eff is strictly less than ε/16. We retain γ_eff explicitly in the ledger rather than replacing it by ε or preallocating the unused margin.

## Connection with the soft payment and complete remaining term

The separately proved score payment takes

    a=a_y(u), U=U_y(Km_u), τ=2λB

and splits the original relative-upper integrand exactly as

    a=min(a,τ/U)+ηa

on U>εJ_b. Its paid source coefficient is τL_ε, L_ε=1+log(1/ε), the same coefficient as the R347 top-hit fee. This note does not change that proof. It then splits only the remaining ηΩ traffic using (2).

The final R_late(1/q_-)[g_ex] retains the fractional mask η, the original Ω and full physical clock, source g_ex, U_y(Km_u)>εJ_b, and the new original-time condition

    U_y^r(Km_u)≤1/q_-.                             (12)

In particular, no fresh ω or a is computed after imposing (12). On original high-past support, εJ_b>(1+√n)/q_-, so the terminal upper capture is large whereas its current prefix part is at most 1/q_-. More precisely, the fraction of upper capture already in E_r is less than 1/(1+√n); the complementary terminal witnesses remain genuinely in the future. This records a quantitative delay mechanism, not a budget for it.

With the existing R346 coefficient C_{ε,n} and D_top,n=1+√n+log(4/3), the resulting hard slot is

    B_H≤R_late(1/q_-)[g_ex]
          +[(13/3)ε+γ_eff]X_q+C_{ε,n}W
          +[D_top,n+2λB L_ε]W_ex.                  (13)

The old top-hit payment is replaced by the same-price soft score payment; it is not added a second time. The new arrival fee is then charged once. The source fees correspond to the earlier relative-low branch and the soft relative-high branch.

Under the unchanged entrance and external Λ=128/119, the receiver coefficient is exactly

    13/36+2Λγ_eff.

With the historical CZ fee 1/256 only if it belongs to the same certified ledger, it is 841/2304+2Λγ_eff. Formula (11) implies this is less than 853/2304 whenever traffic is nonempty. This upper bound does not allocate the unused balance to any other unresolved branch. All other historical slots stay unpaid as before.

No estimate ε'X_q+C_{ε'}√n polylog(n)W for the whole late soft residual is proved. Its upper witnesses predominantly lie outside the old physical prefix; using them in the denominator or resetting the clock would discard precisely the remaining delay mechanism.

## Reproducible local checks

The complete Python code below was run locally from this Markdown file and passed 318 exact assertions. It uses Fraction arithmetic only. It tests the inverse-square integral algebra, full inclusive clock moments, the fractional mask identity, a genuine positive-volume one-dimensional overlap fixture at diagnostic parameters, and the rational high-past fee and ledger inequalities. The one-dimensional fixture omits the outside-center gate and does not use the original root high-past parameters; it validates clock and source mechanics, not hard G.

```python
from fractions import Fraction as F
checks = 0

def ck(v):
    global checks
    assert v
    checks += 1

# Exact inverse-square radial-volume envelope, including its infinite tail.
for mu in (F(1,7),F(1),F(9,2)):
    for K in (F(3,2),F(2),F(5),F(11)):
        for q in (F(1,4),F(3,4),F(1),F(3)):
            M=K*mu
            inner=(M/q)/M**2
            tail=1/(q*M)
            ck(mu*(inner+tail)==2/(K*q))

# Exact scalar physical clock with an actual terminal atom.
# Receiver weights here test clock algebra, not geometric realization.
rs=[F(1),F(5,4),F(3,2),F(2)]
weights=[F(1,7),F(2,9),F(3,11),F(1,5)]
for n in (1,2,3,4,8,16):
    for i,Ru in enumerate(rs):
        for K in (F(3,2),F(2),F(3)):
            selected=[j for j,Rw in enumerate(rs) if Rw**n>K*Ru**n]
            rhs=sum((weights[j]*(Ru/rs[j])**n for j in selected),F(0))
            total=rs[-1]**(-n)*sum((weights[j] for j in selected),F(0))
            for l,r in zip(rs[i:],rs[i+1:]):
                prefix=sum((weights[j] for j in selected if rs[j]<=l),F(0))
                total+=(l**(-n)-r**(-n))*prefix
            ck(Ru**n*total==rhs)
            ck(Ru**n*(Ru**(-n)-rs[-1]**(-n)+rs[-1]**(-n))==1)

# Genuine positive-volume 1-D capture blocks, as specified in R347.
packets=[(F(-1,200),F(1,200),F(1)),
         (F(3,5),F(61,100),F(2,5)),
         (F(9,10),F(91,100),F(3,5))]
centers=[(F(-3,100),F(-2,100)),(F(-1,100),F(0)),(F(2,100),F(3,100))]
radii=[F(1),F(7,5),F(2)]
inc=[[1,0,0],[1,1,0],[1,1,1]]
length=F(1,100)
mass=[sum((packets[j][2]*inc[i][j] for j in range(3)),F(0)) for i in range(3)]
for i,((l,r),R) in enumerate(zip(centers,radii)):
    ck(r-l==length); ck(mass[i]/R==1)
    for j,(sl,sr,_) in enumerate(packets):
        ck((r-R/2<=sl and l+R/2>=sr) if inc[i][j]
           else (r+R/2<=sl or l-R/2>=sr))
rho=[length/m for m in mass]
K=F(11,8)
ck(mass[2]>K*mass[1] and radii[2]>radii[1])
normalized_prefix_moment=radii[1]/radii[2]*rho[2]
ck(normalized_prefix_moment==F(7,2000))
ck(normalized_prefix_moment==sum((mass[1]/mass[j]*rho[j]
       for j in range(3) if mass[j]>K*mass[1]),F(0)))
Jpre=rho[0]+rho[1]; Jfull=sum(rho)
ompre=(mass[1]-mass[0])*rho[0]/(mass[1]*Jpre)
omend=(mass[1]-mass[0])*rho[0]/(mass[1]*Jfull)
a=radii[1]*(ompre*(1/radii[1]-1/radii[2])+omend/radii[2])
ck(a==F(87,620))
U=rho[2]; tau=F(1,10000)
eta=max(F(0),1-tau/(a*U))
ck(0<eta<1)
ck(a==min(a,tau/U)+eta*a)
# Diagnostic t: the future large receiver enters only in the b atom.
t=F(1,500)
arr=eta*rho[1]*radii[1]*omend/radii[2]
late=eta*rho[1]*radii[1]*ompre*(1/radii[1]-1/radii[2])
ck(U>t)
ck(arr+late==eta*rho[1]*a)
weighted_upper=eta*rho[1]*radii[1]*omend/radii[2]*U
ck(arr<=weighted_upper/t)
ck(weighted_upper<=rho[1]*normalized_prefix_moment)

# General soft mask identity.
for a in (F(0),F(1,10),F(1,2),F(1)):
    for U in (F(1,10),F(1),F(3),F(10)):
        for tau in (F(1,100),F(1,2),F(2)):
            eta=max(F(0),1-tau/(a*U)) if a else F(0)
            ck(a==min(a,tau/U)+eta*a)
            ck(0<=eta<=1)

# All exponential smallness is analytically reduced to this rational check.
eps=F(119,3072); outer=F(128,119)
ck(1024*eps**3<1)
ck(64*eps**4<eps/16)
ck(F(13,36)+F(1,256)==F(841,2304))
ck(2*outer*eps/16==F(1,192))
ck(F(841,2304)+F(1,192)==F(853,2304))
print(f'PASS: {checks} exact Fraction assertions; no floating-point exponential or hard-traffic simulation.')
```
