# R349 — actual overlap Schur operator and source-posterior exit

The main tests use **true positive-volume receiver intervals and compact positive-L1 sources**. Continuous receiver integrals and Schur extrema are exact. Posterior/variance tests are separately labeled finite receiver-point probes with exact source integration. The final capacity appendix is an abstract atomic model, not cube geometry. No tilted overlap kernel is substituted for the original conservative flow, and no original high-past/clock closure or new root payment is claimed.

## Real source and receiver fields

All inputs are one-dimensional, a=1,b=2. Use s=0,L=R and full original source f on [-2,2].

| Stage | positive receiver intervals and assigned R | source density |
|---|---|---|
|initial|[-1/2,0],R1; [1/4,1/2],R2|uniform1|
|boundary|[-3/4,-1/2],R1; [-1/4,0],R2; [1/4,1/2],R1|period1: density4 on its first quarter,zero elsewhere|
|expanded|[-1,-3/4],R1; [-3/4,-1/4],R5/4; [-1/4,1/4],R3/2; [1/4,1],R2|period1/4: density3 on its first quarter,1 on second quarter,else0|

Each source period has mass equal to its length, total W=4. Every assigned R is an integer multiple of its source period, and every physical hard interval stays inside [-2,2]. The script independently checks every affine piece endpoint of the moving full-source response, certifying actual q=1 and m_u=R_u for all receiver u. No q or mass is reset after changing f. All receiver intervals have positive length and are disjoint.

## Exact continuous overlap operator

For I_uw=integral f c_u c_w, test the actual oriented kernel relative to du,dw:

`H_K(u,w)=1{m_w>K m_u} I_uw/m_w²`, K=5/4 or3/2.

There is at least one nonzero strict-upper block in every case; the expanded case has four such blocks at K5/4 and two at K3/2. These K values are diagnostics, not the original e^sqrt(n).

Let l_i(z)=|E_i intersect [z-R_i/2,z+R_i/2]|. Actual Fubini gives

`integral_Ei integral_Ej I_uw du dw = integral f(z) l_i(z) l_j(z) dz`.

Each l is piecewise affine and f is piecewise constant. Their product is integrated exactly as a quadratic, retaining all source and receiver breakpoints. This yields the exact block-average H matrix. Its weighted L2 matrix in the orthonormal basis 1_Ei/sqrt(|Ei|) has entries sqrt(|Ei||Ej|) H_average(i,j); its squared norm is bounded rationally by either the weighted row/column product or its squared Frobenius norm.

The **continuous**, not merely matrix, marginals are also evaluated. For fixed u, its row is the sliding integral over Q_Ru(u) of `f(z) sum_upper_j l_j(z)/m_j²`. The analogous column uses `f(z) sum_lower_i l_i(z)/m_w²`. Each is continuous piecewise quadratic in the receiver center. The script finds all rational endpoints and quadratic vertices, yielding exact maxima. A separate quarter-point fit check verifies each quadratic piece, and integrating these quadratics independently reproduces the Fubini matrix row/column means.

The actual q=1 capacities `row<=2/K`, `column<=1/K`, and therefore `||H||_2²<=2/K²` are checked exactly. These match the general 2/(Kq) and1/(Kq) capacities in the geometry note for full source (captured full-source fractions are1 here).

| Field | K | continuous row max | continuous column max | continuous Schur squared-norm upper |
|---|---:|---:|---:|---:|
|initial|5/4 or3/2|1/16|15/128|15/2048|
|boundary|5/4 or3/2|1/16|1/8|1/128|
|expanded|5/4|123/512|85/256|10455/131072|
|expanded|3/2|153/1024|151/1024|23103/1048576|

All are below the claimed 2/K². The exact Galerkin squared-norm upper bounds are also stored; e.g. expanded K5/4 gives 2929513/75497472. These are example bounds, not estimates of a sharp general constant.

## Actual posterior and variance probes

For each strict upper block, take endpoint/midpoint receiver pairs (nine per block). These are finite point probes; **their pair sum is not called a continuous receiver integral**. For each, the actual source probability is `pi_w(dy)=f(y)c_w(y)dy/m_w`, normalized exactly by the unchanged actual mass.

Use three real functions F_u supported in Q_u: its indicator; value1 on the left half and -1/2 on the right half; and the central half-interval indicator. Exact source intersections give mean and second moment, and check

`(E F)^2 <= (I_uw/m_w) E F² <= (m_u/m_w) E F² <= K^-1 E F²`.

Variance is additionally evaluated as the independent two-source double integral `1/2 E[(F(y)-F(z))²]`: the exact posterior masses at each F value, including F=0 outside its support, produce the same `E F²-(E F)²`. Thus the test is not merely naming a subtraction variance. Both pointwise exit bounds and their positive weighted sum satisfy

`(1-1/K) S <= V <= S`.

The sum uses explicit diagnostic a=1/(1+i+j), diagnostic late weight1-R_u/R_w, and receiver-point weight |Ei||Ej|/9. These weights are **not original omega, eta, Omega, a physical clock, or a high-past gate**. They are nonnegative tests of the exit inequality only. For example, boundary K3/2 has V/S=1/2 for indicator and signed-halves functions; expanded K5/4 indicator gives 119549/218328. This coercivity does not supply an upper payment for the variance or convert H into the original flow.

## Separate abstract cumulative-capacity appendix

For N=4,16,64,128 use q=M=1, mass locations m_i=2^(i+1), atomic rho weights1/2. These are not actual cubes. At every closed upper breakpoint T=m_j, exact outward log bounds certify

`rho{M<m<=T}=j/2 <=1+log(T/M)`.

Between atoms the left side is constant and the right side increases. With U=N/2 and V=2^N-1, the script certifies

`integral log(m/M) rho >= (qU-1)_+²/(2q)`,

and `log(V q/M)>=qU-1`, hence the stated exponential first-moment lower bound without any floating exponential. The basic V>=MU also holds. All registered cases have qU>1; this is not a separate test of the low-U branch or a claim that the examples are extremizers. Long exact log endpoints use deterministic integer-byte digests and are regenerated by the script.

## Actual run and reproduce

Two fresh independent processes passed **1,817 exact rational/interval checks**: actual-field stages264/494/831 and separate capacity228. No floating-point comparison certifies a bound. Logarithms are outward rational enclosures, not exact log values.

Only `r349_numeric.py`, `r349_numeric_result.json`, and this note are needed. Standard library only, no optimizer or old /tmp imports:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r349_numeric.py
```

The JSON is written beside the script and includes source/receiver intervals, exact overlap rectangle integrals, every continuous marginal's quadratic pieces and maxima, weighted matrix bounds, posterior certificates and the separate atomic capacity tests. The actual geometry is a kernel subclass, while complete original historical qualification remains unimplemented.
