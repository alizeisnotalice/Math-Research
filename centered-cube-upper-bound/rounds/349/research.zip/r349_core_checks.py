from fractions import Fraction as F
from itertools import product
count=0
for K in (F(3,2),F(2),F(4)):
 for den in (8,16,32):
  for j in range(1,den):
   p=F(j,den)
   if p>1/K: continue
   weights=(p/3,2*p/3,1-p)
   for x1,x2 in product((F(0),F(1,3),F(2,3),F(1)),repeat=2):
    vals=(x1,x2,F(0))
    mean=sum(w*x for w,x in zip(weights,vals))
    e2=sum(w*x*x for w,x in zip(weights,vals))
    var=e2-mean*mean
    pair=sum(weights[i]*weights[j]*(vals[i]-vals[j])**2
             for i in range(3) for j in range(3))/2
    assert pair==var
    assert mean*mean<=p*e2<=e2/K
    assert (1-1/K)*e2<=var<=e2
    count+=1
m_u=F(7,5);m_w=F(2);K=F(11,8)
assert m_w>K*m_u
posterior=(F(1,2),F(1,5),F(3,10))
assert sum(posterior)==1 and sum(posterior[:2])==m_u/m_w<1/K
print("PASS",count,"exact posterior-variance cases; fixture mass/posterior checks")
