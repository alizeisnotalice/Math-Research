# R349 — Actual source exit and the late-clock posterior variance

**Finite result.** For a genuine upper pair \(m_w>Km_u\), resampling from
the original source posterior in \(Q_w\) exits \(Q_u\) with probability
at least \(1-1/K\). This yields a quantitative coercivity estimate for
the exact late-clock amplitude, retaining \(\eta\Omega/U\) and all old
gates. It does not supply a new root-order payment: the missing bound is
an upper bound for this source-resampling variance. The known incoming
column capacity, when resampled, still produces the source density
\(fJ_b\), not a constant multiple of \(f\).

## Frozen contract and a geometric one-pair lemma

Use precisely R348 main/core: full \(f\ge0\), actual receiver \(du\),
\(m_u=\int f c_u=q_uR_u^n\), \(q_-\le q_u\le\lambda\),
\(a\le R_u\le b\le2a\), \(c_u=1_{Q_u}\),
\(\rho_y(du)=c_u(y)du/m_u\), original \(J_y(r)\) and
\(\ell=b^{-n}\delta_b+n r^{-n-1}dr\).
Let \(K=e^{\sqrt n}\), \(U_y(t)=\rho_y\{m>t\}\),
\(g=g_{\rm ex}\le f\), and retain every original mask.

For every actual receiver \(w\), define the probability
\[
 \pi_w(dy)=f(y)c_w(y)dy/m_w.
\]
If \(m_w>Km_u\), actual shared source mass gives
\[
 p_{uw}:=\pi_w(Q_u)=\frac{I_{uw}}{m_w}
 \le\frac{m_u}{m_w}<\frac1K,\qquad I_{uw}=\int f c_uc_w.       \tag{1}
\]
This uses mass, not volume. For any square-integrable real \(F\) supported
in \(Q_u\), Cauchy–Schwarz on that actual support gives
\[
 (\mathbb E_{\pi_w}F)^2\le p_{uw}\mathbb E_{\pi_w}F^2.
\]
Consequently
\[
 (1-1/K)\mathbb E_{\pi_w}F^2
 \le \operatorname{Var}_{\pi_w}(F)
 \le \mathbb E_{\pi_w}F^2,                                 \tag{2}
\]
and exactly
\[
 \operatorname{Var}_{\pi_w}(F)
 =\frac12\iint [F(y)-F(z)]^2\pi_w(dy)\pi_w(dz).              \tag{3}
\]
The sharper factor in (2) is \(1-p_{uw}\). No independent posterior or
source-density cap is assumed.

## The original late traffic is an instance of (2)

Use the original R348 quantities
\[
 a_y(u)=q_u\omega_y(u),\quad \tau=2\lambda B,\quad
 \eta_y(u)=(1-\tau/[a_y(u)U_y(Km_u)])_+,
 \qquad B=(1+\sqrt n)/q_-,
\]
with \(\eta=0\) where its original denominator is zero.
Let
\[
 \chi_y(u,r)=1_{\{U_y(Km_u)>\varepsilon J_b(y)\}}
             1_{\{U_y^r(Km_u)\le1/q_-\}}.
\]
The original \(H\), high-past, outside-center, small endpoint and full
\(J_y(r)\) factors stay inside the original \(\Omega_y(u,r)\).
Thus the actual remaining traffic is
\[
 G_{\rm late}
 =\int_Edu\int_{[R_u,b]}\ell(dr)
       \int g(y)c_u(y)\eta_y(u)\Omega_y(u,r)\chi_y(u,r)\,dy. \tag{4}
\]

Define \(g/f=0\) on \(f=0\), and set the following amplitude to zero
whenever the active strict upper tail is zero:
\[
 F_{u,r}(y)=c_u(y)
 \left[
 \frac{g(y)}{f(y)}
 \frac{\eta_y(u)\Omega_y(u,r)\chi_y(u,r)}
      {U_y(Km_u)}
 \right]^{1/2}.                                          \tag{5}
\]
All factors are original frozen fields. In particular this is not an
arrived row to which a fresh bound \(a\le\lambda\) is applied.
On its nonzero set, \(J_b>h=B/\varepsilon\) and \(U>\varepsilon J_b>B\),
so \(F_{u,r}^2\le1/B\). Measurability and integrability follow by Tonelli.

Inserting the original normalized upper kernel, without moving its
physical clock, gives the exact identity
\[
 G_{\rm late}=
 \int_Edu\int_{[R_u,b]}\ell(dr)
   \int_{\{m_w>Km_u\}}dw\ \mathbb E_{\pi_w}F_{u,r}^2.       \tag{6}
\]
Indeed, expanding the posterior expectation produces
\(f(y)c_w(y)/m_w\), and integrating \(w\) gives exactly
\(U_y(Km_u)\), which cancels the denominator in (5).
The source \(y\), old \(r\), and every old gate remain unchanged in
this cancellation. All \(w\) are terminal upper witnesses; none is
inserted into the old prefix.

Let \(\mathcal V_{\rm late}\) be (6) with the second moment replaced by
\(\operatorname{Var}_{\pi_w}(F_{u,r})\), and let
\(\mathcal M_{\rm late}\) use \((\mathbb E_{\pi_w}F_{u,r})^2\).
Then
\[
 G_{\rm late}=\mathcal V_{\rm late}+\mathcal M_{\rm late},
 \qquad
 0\le\mathcal M_{\rm late}\le G_{\rm late}/K,
 \qquad
 G_{\rm late}\le\frac{K}{K-1}\mathcal V_{\rm late}.          \tag{7}
\]
Equations (1)–(3) prove this for the full actual source field, not merely
a finite incidence model. The continuous clock and terminal atom enter
with their original weights throughout.

The variance in (7) is an explicitly positive source-change cost. It is
**not** a negative square already present in the original ledger.
Thus (7) identifies a precise route for a future upper estimate on the
oscillation of the actual amplitude (5); it does not pay that cost.

## The requested \(a^2U\) potential has the same exact structure

For comparison set
\[
 S[g]=\int g(y)\int_{\rm relative}
                    a_y(u)^2U_y(Km_u)d\rho_y(u)\,dy,
 \quad
 F_u(y)=c_u(y)a_y(u)\sqrt{g(y)/f(y)}\,1_{\rm relative}.
\]
Then
\[
 S[g]=\int_E\frac{du}{m_u}\int_{\{m_w>Km_u\}}dw\
                 \mathbb E_{\pi_w}F_u^2.                 \tag{8}
\]
The measure here is \(du/m_u\), unlike \(du\,\ell(dr)\) in (6);
interchanging them would lose the physical-clock normalization.
Replacing the second moment in (8) by the posterior variance defines
\(\mathcal V_S\) and gives
\[
 (1-1/K)S[g]\le\mathcal V_S\le S[g].                       \tag{9}
\]
The original \(a=q\omega\) in (8) retains both old clocks when squared.
The R348 estimate \(G_{\rm soft}\le S/(8\lambda B)\) remains valid,
but (9) supplies no bound of the required scale for \(S\).
It says that a small posterior mean cannot account for its cost; the
source variation must be controlled.

## Exact source-reuse obstruction in the available column estimate

Let \(\kappa_{\rm late}(w)\) be the actual incoming density relative to
\(dw\) obtained by the one-shot upper routing of (4). It conserves
\(G_{\rm late}\). Since the late factor is a positive contraction of the
original pre-routing row, the already proved R347 argument gives
\[
 \kappa_{\rm late}(w)
 \le \frac{\lambda L_\varepsilon}{m_w}
            \int g(y)c_w(y)1_{\{J_b(y)>h\}}\,dy
 \le\lambda L_\varepsilon.                              \tag{10}
\]
This uses the old row before routing, not a renewed hypothesis on the
arrived density.

Now resample a source from \(\pi_w\). The resulting exact source density is
\[
 f(z)\,\mathcal L(z),\qquad
 \mathcal L(z)=\int_E \frac{c_w(z)}{m_w}\kappa_{\rm late}(w)\,dw,
 \quad \int f(z)\mathcal L(z)dz=G_{\rm late}.              \tag{11}
\]
The available bound is only
\[
 \mathcal L(z)\le\lambda L_\varepsilon J_b(z).             \tag{12}
\]
Combining (12) with the full-f mass constraints yields receiver cost,
since \(\int fJ_b=|E|\); it does not yield \(O(\sqrt n)\int f\).
The source-exit probability in (1) remains true in the joint routed
flow, but does not remove \(J_b(z)\) from its incoming marginal (11).
No invariance with respect to \(f(z)dz\) follows from conservation.

Thus the exact unresolved step in this route is an upper estimate for
the original-amplitude variance in (7), or an improvement of the actual
weighted incoming marginal (11) after source exit. Neither follows from
(1) alone, and neither has been proved here. This is not a claim that
the cost must be large or that the route is impossible. No new payment
is added to the R348 ledger.

## Reproducible local check

The following standard-library code was actually run: 1,248 exact
posterior-variance cases passed, together with the indicated mass and
posterior identities from the existing positive-volume R346 fixture.
These tests certify only the scalar variance algebra and mass-gap
application. They do not simulate the original late high-dimensional
traffic, and no such numerical claim is made.

~~~python
from fractions import Fraction as F
from itertools import product
count=0
for K in (F(3,2),F(2),F(4)):
 for den in (8,16,32):
  for j in range(1,den):
   p=F(j,den)
   if p>1/K: continue
   weights=(p/3,2*p/3,1-p)
   for x1,x2 in product((F(0),F(1,3),F(2,3),F(1)),repeat=2):
    vals=(x1,x2,F(0))
    mean=sum(w*x for w,x in zip(weights,vals))
    e2=sum(w*x*x for w,x in zip(weights,vals))
    var=e2-mean*mean
    pair=sum(weights[i]*weights[j]*(vals[i]-vals[j])**2
             for i in range(3) for j in range(3))/2
    assert pair==var
    assert mean*mean<=p*e2<=e2/K
    assert (1-1/K)*e2<=var<=e2
    count+=1
m_u=F(7,5);m_w=F(2);K=F(11,8)
assert m_w>K*m_u
posterior=(F(1,2),F(1,5),F(3,10))
assert sum(posterior)==1 and sum(posterior[:2])==m_u/m_w<1/K
print("PASS",count,"exact posterior-variance cases; fixture mass/posterior checks")
~~~

The fixture has source masses \(1,2/5,3/5\); its larger receiver captures
all three, while the middle receiver captures the first two. This
fixture is only a diagnostic use of actual masses at \(K=11/8\), not an
instance of the prescribed root high-past parameters.

Only this bounded note was authored. No general root estimate or new
receiver absorption has been obtained; the original R348 remainder and
all exterior fees remain due.
