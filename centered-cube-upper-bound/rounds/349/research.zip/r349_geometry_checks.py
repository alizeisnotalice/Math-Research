from fractions import Fraction as F
from decimal import Decimal, localcontext
N=0; D=0

def ck(x):
    global N
    assert x
    N+=1

packets=[(F(-1,200),F(1,200),F(1)),
         (F(3,5),F(61,100),F(2,5)),
         (F(9,10),F(91,100),F(3,5))]
centers=[(F(-3,100),F(-2,100)),(F(-1,100),F(0)),(F(2,100),F(3,100))]
R=[F(1),F(7,5),F(2)]
inc=[[1,0,0],[1,1,0],[1,1,1]]
du=F(1,100); qmin=F(3,4); lam=F(1); K=F(11,8)
m=[sum((packets[j][2]*inc[i][j] for j in range(3)),F(0)) for i in range(3)]
for i,((l,r),rr) in enumerate(zip(centers,R)):
    ck(r-l==du); ck(m[i]/rr==1)
    for j,(sl,sr,_) in enumerate(packets):
        ck((r-rr/2<=sl and l+rr/2>=sr) if inc[i][j]
           else (r+rr/2<=sl or l-rr/2>=sr))

for gm in ([F(1),F(2,5),F(3,5)], [F(1,2),F(1,10),F(3,10)]):
    p=[sum((gm[j]*inc[i][j] for j in range(3)),F(0))/m[i] for i in range(3)]
    I=[[sum((gm[j]*inc[i][j]*inc[k][j] for j in range(3)),F(0)) for k in range(3)] for i in range(3)]
    H=[[I[i][k]/m[k]**2 if m[k]>K*m[i] else F(0) for k in range(3)] for i in range(3)]
    for i in range(3):ck(du*sum(H[i])<=2*p[i]/(K*qmin))
    for k in range(3):ck(du*sum(H[i][k] for i in range(3))<=p[k]/(K*qmin))
    for ff in ([F(1),F(1),F(1)],[F(-2),F(3),F(1,3)],[F(0),F(1),F(0)]):
        for gg in ([F(1),F(2),F(-1)],[F(3),F(1,5),F(7)]):
            bil=du**2*sum((H[i][k]*ff[i]*gg[k] for i in range(3) for k in range(3)),F(0))
            rhs=2/(K*qmin)**2*(du*sum(p[i]*ff[i]**2 for i in range(3)))*(du*sum(p[k]*gg[k]**2 for k in range(3)))
            ck(bil**2<=rhs)
    ck(du**2*sum(sum(row) for row in H)<=du*sum(p)/(K*qmin))

# Exact late-flow bridge for the middle receiver at the first source packet.
rho=[du/mm for mm in m]
Jpre=rho[0]+rho[1]; J=sum(rho)
ompre=(m[1]-m[0])*rho[0]/(m[1]*Jpre)
omend=(m[1]-m[0])*rho[0]/(m[1]*J)
a=R[1]*(ompre*(1/R[1]-1/R[2])+omend/R[2])
U=rho[2]; tau=F(1,10000); eta=max(F(0),1-tau/(a*U))
zeta=eta*a
ck(U<=1/qmin)  # This diagnostic prefix gate retains the whole old clock.
G=zeta*rho[1]
V=du
Egain=zeta**2*V/(m[1]*U**2)*rho[1]
ck(Egain==zeta**2*(m[2]/m[1])**2)
Xi=F(0); first=F(0); second=F(0)
for i in range(3):
    for k in range(3):
        if m[k]<=K*m[i]:continue
        for j,(_,_,mass) in enumerate(packets):
            base=mass*inc[i][j]*inc[k][j]*du**2/m[k]**2
            Xi+=base
            z=zeta if i==1 and j==0 else F(0)
            up=sum((rho[w]*inc[w][j] for w in range(3) if m[w]>K*m[i]),F(0))
            c=z*m[k]/(m[i]*up) if z else F(0)
            first+=base*c; second+=base*c*c
ck(first==G); ck(second==Egain)
ck(G*G<=Xi*Egain)
Y=3*du
ck(Xi<=Y/(K*qmin))
ck(G*G<=Y/(K*qmin)*Egain)

# Exact logarithmic layer-cake integral, including its zero regime.
for x in (F(0),F(1,2),F(1),F(3,2),F(2),F(5),F(10)):
    for q in (F(1,4),F(3,4),F(1)):
        U=x/q; L=max(F(0),x-1)
        integral=L*(U-1/q)-L*L/(2*q)
        ck(integral==L*L/(2*q))
        if U:ck(integral/U==L*L/(2*x))

# Diagnostic layer-cake algebra, kept separate from exact rational checks.
with localcontext() as ctx:
    ctx.prec=70
    for x in (Decimal(1),Decimal('1.5'),Decimal(2),Decimal(5),Decimal(10)):
        for M in (Decimal('0.25'),Decimal(1),Decimal(3)):
            q=Decimal('0.75'); U=x/q; L=x-1
            integral=M/q*(L.exp()-L-1)
            rhs=M/q*L.exp()
            assert abs(M*U+integral-rhs)<Decimal('1e-60'); D+=1
print(f'PASS: {N} exact Fraction assertions; {D} 70-digit Decimal layer-cake diagnostics. No general hard-traffic budget is claimed.')
