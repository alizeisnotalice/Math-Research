#!/usr/bin/env python3
"""Frozen five-alpha four-atom translation supremum by exact event partition."""
import argparse,hashlib,itertools,json,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from pathlib import Path

ALPHAS=[F(1,2),F(1,4),F(1,16),F(1,64),F(1,256)]
def add(x,y):return x[0]+y[0],x[1]+y[1]
def sub(x,y):return x[0]-y[0],x[1]-y[1]
def value(x,t):return x[0]*t+x[1]
def out_line(x):return {'coefficient_t':str(x[0]),'constant':str(x[1])}
def sample(left,right):
 if left is None:return right-1
 if right is None:return left+1
 return (left+right)/2
def inside(x,left,right):return (left is None or x>left) and (right is None or x<right)
def union_intervals(intervals):
 vals=sorted((a,b) for a,b in intervals if a<b)
 if not vals:return F(0)
 a,b=vals[0];length=F(0)
 for c,d in vals[1:]:
  if c<=b:b=max(b,d)
  else:length+=b-a;a,b=c,d
 return length+b-a

def actual_union(points,masses):
 intervals=[]
 for S in range(1,1<<len(points)):
  ids=[i for i in range(len(points)) if S>>i&1];M=sum(masses[i] for i in ids)
  intervals.append((max(points[i] for i in ids)-M/2,min(points[i] for i in ids)+M/2))
 return union_intervals(intervals)

def form_boxes(positions,masses,t):
 boxes=[]
 for S in range(1,1<<len(positions)):
  ids=[i for i in range(len(positions)) if S>>i&1];M=sum(masses[i] for i in ids)
  low=min(ids,key=lambda i:(value(positions[i],t),i));high=max(ids,key=lambda i:(value(positions[i],t),-i))
  boxes.append({'mask':S,'mass':M,'lower':add(positions[high],(F(0),-M/2)),'upper':add(positions[low],(F(0),M/2)),'min_source_owner':low,'max_source_owner':high})
 return boxes

def affine_union(boxes,t):
 positive=[b for b in boxes if value(b['upper'],t)>value(b['lower'],t)];positive.sort(key=lambda b:(value(b['lower'],t),b['mask']))
 if not positive:return (F(0),F(0)),[]
 a,b=positive[0]['lower'],positive[0]['upper'];total=(F(0),F(0))
 for box in positive[1:]:
  if value(box['lower'],t)<=value(b,t):
   if value(box['upper'],t)>value(b,t):b=box['upper']
  else:total=add(total,sub(b,a));a,b=box['lower'],box['upper']
 return add(total,sub(b,a)),[box['mask'] for box in positive]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r595_results.json'));args=ap.parse_args();start=time.perf_counter()
 def timeout(*_):raise TimeoutError('120s guard, no source/subset truncation')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 V=F(5,2);d=F(3,2);cases=[]
 assert actual_union([F(0),d],[F(1),F(1)])==V
 for alpha in ALPHAS:
  beta=1-alpha;positions=[(F(0),F(0)),(F(0),alpha*d),(F(1),F(0)),(F(1),beta*d)];masses=[alpha,alpha,beta,beta];assert sum(masses)==2
  pureA=actual_union([F(0),alpha*d],[alpha,alpha]);pureB=actual_union([F(0),beta*d],[beta,beta]);assert pureA==alpha*V and pureB==beta*V and pureA+pureB==V
  sourceevents={};parallelpairs=[]
  for i,j in itertools.combinations(range(4),2):
   a,b=sub(positions[i],positions[j])
   if a:sourceevents.setdefault(-b/a,[]).append([i,j])
   else:assert b!=0;parallelpairs.append([i,j])
  sourcecuts=sorted(sourceevents);sourcebounds=[None]+sourcecuts+[None];events={t:[{'type':'source_order','source_pairs':sourceevents[t]}] for t in sourcecuts}
  endpoint_pair_checks=0
  for left,right in zip(sourcebounds,sourcebounds[1:]):
   tt=sample(left,right);boxes=form_boxes(positions,masses,tt);ends=[(str(b['mask'])+':'+name,b[name]) for b in boxes for name in ('lower','upper')]
   for (name,f),(name2,g) in itertools.combinations(ends,2):
    endpoint_pair_checks+=1;a,b=sub(f,g)
    if not a:continue
    root=-b/a
    if inside(root,left,right):events.setdefault(root,[]).append({'type':'endpoint_crossing_or_subset_birth','endpoints':[name,name2]})
  cuts=sorted(events);assert len(cuts)<=1000,'Unexpected event explosion; stop rather than truncate'
  bounds=[None]+cuts+[None];segments=[];maxD=F(0);event_values={}
  for t in cuts:
   event_values[t]=actual_union([value(p,t) for p in positions],masses)-V;maxD=max(maxD,event_values[t])
  for left,right in zip(bounds,bounds[1:]):
   tt=sample(left,right);boxes=form_boxes(positions,masses,tt);ends=[b[name] for b in boxes for name in ('lower','upper')]
   for f,g in itertools.combinations(ends,2):
    a,b=sub(f,g)
    if a:assert not inside(-b/a,left,right)
   full,active=affine_union(boxes,tt);D=sub(full,(F(0),V));assert value(full,tt)==actual_union([value(p,tt) for p in positions],masses)
   if left is None or right is None:assert D==(F(0),F(0))
   else:
    assert value(D,left)==event_values[left] and value(D,right)==event_values[right]
   segments.append({'left':None if left is None else str(left),'right':None if right is None else str(right),'union_affine':out_line(full),'D_affine':out_line(D),'active_actual_subsets':active,'all15_subset_boxes':[{'mask':b['mask'],'mass':str(b['mass']),'lower':out_line(b['lower']),'upper':out_line(b['upper']),'min_source_owner':b['min_source_owner'],'max_source_owner':b['max_source_owner']} for b in boxes]})
  # Every piece is affine, so extrema are at endpoints or on a constant piece.
  assert maxD>0
  closed=[]
  for seg in segments:
   line=seg['D_affine']
   if F(line['coefficient_t'])==0 and F(line['constant'])==maxD:
    assert seg['left'] is not None and seg['right'] is not None;closed.append((F(seg['left']),F(seg['right'])))
  for t,v in event_values.items():
   if v==maxD:closed.append((t,t))
  merged=[]
  for a,b in sorted(closed):
   if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],b))
   else:merged.append((a,b))
  assert merged
  for a,b in merged:
   tt=(a+b)/2;assert actual_union([value(p,tt) for p in positions],masses)-V==maxD
  cases.append({'alpha':str(alpha),'beta':str(beta),'source_position_affines':[out_line(p) for p in positions],'source_masses':list(map(str,masses)),'V_original_exact':str(V),'W_exact':'2','pure_child_A_volume_exact':str(pureA),'pure_child_B_volume_exact':str(pureB),'pure_child_price_scaling_verified':True,'parallel_nonintersecting_source_pairs':parallelpairs,
   'workload':{'source_order_chambers':len(sourcebounds)-1,'endpoint_pair_checks_for_event_generation':endpoint_pair_checks,'distinct_breakpoints':len(cuts),'affine_segments':len(segments),'actual_subsets_per_segment':15},
   'events':[{'t':str(t),'generators':events[t],'actual_D_at_event':str(event_values[t])} for t in cuts],'segments':segments,'tails_D_exactly_zero':True,
   'maximum_D_exact':str(maxD),'sup_D_over_alpha_exact':str(maxD/alpha),'complete_maximizer_closed_intervals':[[str(a),str(b)] for a,b in merged],'one_attaining_translation':str(sum(merged[0],F(0))/2),'extremum_certificate':'All open pieces are affine with all order/birth roots excluded from their interiors; event values match adjacent limits, tails zero, all constant maximizer pieces retained.'})
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>128*1024**2:raise MemoryError('128MiB guard')
 signal.alarm(0)
 result={'scope':'Five frozen alpha values, complete full-scale four-atom receiver on the entire translation line. Finite small-alpha comparison only; no general or high-dimensional asymptotic inference.',
 'input':{'n':1,'lambda':1,'original_sources':['0','3/2'],'original_masses':['1','1'],'V_original':'5/2','W':'2','alpha_grid':list(map(str,ALPHAS)),'four_positions':['0','3alpha/2','t','t+3(1-alpha)/2'],'four_masses':['alpha','alpha','1-alpha','1-alpha'],'cube_convention':'r=mS is interval SIDE, halfwidth mS/2'},
 'algorithm':'All source-position crossing chambers, explicitly allowing parallel nonintersecting same-slope positions; all 15 actual subset affine interval endpoints, all valid endpoint intersections and births, exact whole-union affine pieces and all extremizers. No target formula is used to compute maxima.',
 'cases':cases,'arithmetic_error':'0, Fraction exact throughout; no floating arithmetic or sign comparisons','execution':{'interpreter':sys.executable,'python':platform.python_version(),'processes':1,'guard_seconds':120,'guard_bytes':128*1024**2,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':[{'alpha':c['alpha'],'workload':c['workload'],'maxD':c['maximum_D_exact'],'ratio':c['sup_D_over_alpha_exact'],'maximizers':c['complete_maximizer_closed_intervals']} for c in cases],'execution':result['execution']}))
if __name__=='__main__':main()
