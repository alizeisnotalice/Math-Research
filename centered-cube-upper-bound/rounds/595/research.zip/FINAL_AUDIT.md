# R595 严格增益与最终报告独审

**结论：PASS，无必须修复项。严格有限输入增益及其两个非达值推论成立；统一根阶预算仍未证明。**

最终被审报告：`/tmp/ccu_r595_REPORT.tex`。

SHA256：`986de3ff2ae6acb6ded1433fd711bb2e4069aabb38ab6b83fe95379553db229b`。

本阶段先独立构造并检查外露面片/微副本增益，再读作者和最终报告。支持稿版本：`/tmp/ccu_r595_astra.md` SHA256 `57480ab2115bee2d82981722b4dfaaf5f471a4aae3bad7ca0c52e8725039a8f3`；`/tmp/ccu_r595_sol.md` SHA256 `0a8f0e1e70ac6f45bab5c1551850a219ab0f026a03a470aa9b3c94064a44869b`。本审核只认证这些已读字节及下列范围。

## 1. 独立先验检查与完整竞争输入

独立检查确认：可以取一个正体积原 carrier 的最外面片，在大副本外侧保留正横截面，再将微副本的整个纯接收放到更外侧，用实际 mixed 来源捕获两者之间的新条。关键不是任意局部面，而是全部正体积 carrier 的全局最外面；更远的退化 carrier 只能影响零测集。用任一微 atom 已足以构造输入依赖正条；报告使用全部微来源，另以其总质量 W 取得更清楚的半径差，仍完全合法。

两个副本保留真实质量、全部原来源与全部 mixed 子集，总质量 W、标签数至多 2d。各自纯接收为 bE 与 aE+p，价分别为 (1-alpha)V、alpha V；使用全局 `C_n=sup_d C_(n,d)` 上价，未错用原固定 d 的常数。整体平移能转成合同的“小副本不移、大副本平移”形式。原坐标先减去面点 y0 时，对应原合同的实际 t 为 `(a-b)y0-p`，所以选择面点为原点没有偷换允许的动作。

## 2. 正面积、全部来源捕获与 global masking

正体积 carrier 至少有一个，因为单来源盒有正体积。有限个正体积 carrier 中能取到最右面，所选 C_S 的每个横向宽度严格正。故其相对内部可取正 (n-1) 维矩形片 F，并缩至横向坐标绝对值不超过 r/16。n=1 时横截面按零维测度 1 处理；重复位置标签不影响这一步。

有限 D0 同时包住全部来源和完整 E，包括退化部分。报告要求

`0<alpha<min{M/(32W),(r/(16D0))^n}`。

它确使全部微来源与微 pure 集合都处于 p 周围 r/16 的空间邻域。大 pure 的正体积部分位于 x1<=0，小 pure 全部位于 x1>3r/16，因此其交体积为零，总 pure 价完整保留为 V。这里不是把微副本替换成同质量点源。

令 `r'=[((1-alpha)M+alpha W)/lambda]^(1/n)`、`Delta=r'-br`。严格正性来自 `r'^n-(br)^n=alpha W/lambda>0`。最终报告的较紧常数也正确：写 w=W/M>=1，

`r'/r=(1+alpha(w-1))^(1/n)<=1+alpha(w-1)`，

`b>=(1-alpha)`，

故 `0<Delta<=alpha w r<r/32`。没有使用作者较松的 r/16 估计来支持更窄条。

条带 `{bx+s e1:x in F,0<s<Delta/2}` 的法向坐标在 (0,r/64)。大副本 S 的所有来源到条带距离至多 br/2+s<r'/2。全部小副本来源的横向距离小于 r/8，法向距离小于 5r/16；而 `r'/2>=br/2>31r/64`。因此同一个实际 mixed 子集“大 S 加全部小来源”严格捕获整个条带，无需每个 receiver 私选来源或另收父数费。

条带既在大 pure 的正体积部分外，又在小 pure 的全部接收之前，故 fresh 体积至少为 `b^(n-1)|F| Delta/2`。原退化 carrier 即使延伸到更外面，也只造成零测遮罩；其他 mixed 子集只增加 T。这正是完整并的正增益，而非所有 carrier 体积和：

`D(alpha,p)>=lambda b^(n-1)|F| Delta/2>0`。

所有 n>=1、任意有限无界但固定的来源位置、重复点及原 carrier 退化均在此范围内。证明不把原 G/H2 帽迁移到新位置，也不依赖边界无原子假设。

## 3. 推论与一阶量的准确范围

严格改善适用于每个非零有限原子输入及每个正阈值，因此任何这样的输入都不能达到全局 C_n。结合已审固定 d 达值定理，取其至多 d 标签达值输入，竞争输入至多 2d 标签且比值严格更大，得到 `C_(n,2d)>C_(n,d)`。这里不声称 C_n 由某输入达到，也不声称每次加一个标签严格增长，或增长有统一速率。

对已固定且已选择面片的输入，报告的 radius 差确有

`Delta/alpha -> W/(n lambda r^(n-1))`。

故显式条带下界给

`liminf D/(alpha W)>=|F|/(2n r^(n-1))>0`。

这个推导微分的是明确半径差，完整并的出生/接触已由实际条带包含处理，并未假设完整 union 可微。允许步长依赖 M/W 与 D0/r，面片比也无输入一致正下界。因此该一阶正量不能替代 `eta_n V-L_nW` 的统一预算；近极值误差仍是 zeta/alpha，不能因每个输入有正增益就删除它。

## 4. Sol 的完整同步与概率费用

共同 child 边长 r0 变回原输入的两个尺度分别为 r0/a、r0/b，其比为 `exp(h)`，`h=log(alpha/beta)/n`。完整双点对象 P(h) 保留同一个 r，不能各自最优化两侧半径。换元 Jacobian alpha beta、纯侧乘积及完整正负 integrand 给

`I(alpha)=integral D(alpha,t)dt=lambda alpha beta[P(h)-|E|^2]`。

交换两个原 receiver 后重新参数化 r，给 P(h)=P(-h)。实际 finite-source 支持与有界共同尺度区间保证这里的积分合法；没有把粗界 `2^n d^2 W/lambda` 当成免费归一常数。

logistic Jacobian、`alpha beta=1/[4 cosh^2(nh/2)]` 以及 H>0 时的

`Z_H=integral_[-H,H] dh/(alpha beta)=4H+4sinh(nH)/n`

均正确。消掉 alpha beta 的真实 alpha 概率密度确须为 `dalpha/[n Z_H(alpha beta)^2]`。报告保留 Z_H 及随后 t 的概率归一化，未把 Lebesgue 平移积分当成直接可用 gain。

单信用层估计也通过：原 nearmax 上价给 `|E_nu(q lambda)\E|<=((1-q)V+zeta W)/(lambda q)`。固定 qA,qB 且 qA+qB>1 时，单个双层的全部产品体积在 nearmax 极限中的相对系数至多 `(1-qA)(1-qB)/(qA qB)<1`。作者明确这只是一个层的支付限制，非完整 P(h) 的上界。其同步区间来自两个向右 log-radius 区间的差，宽度为 `2 log(qA+qB)/n`；仍须同一个 h，不能每对私选后合并信用。

以上同步、权重和有限层筛查均未支付完整 P 的正预算，与严格增益定理并不矛盾。

## 5. 计算证据、实际检查及精简归档

实际核对脚本 `/tmp/ccu_r595_exact_check.py` 的 SHA256：`a23b3f15b01250a665dad59df2a5677d34b714018a64b95eb39696a7d428c16e`。读取 `/tmp/ccu_r595_results.json`、`/tmp/ccu_r595_replay_check.json` 的实际摘要，并用本机 Python 将原结果与 `/tmp/ccu_r595_root_replay.json` 去除 execution 后比较，全部其余字段相等。没有重新运行该算法，也没有在此重新完整独审代码。

五组 alpha 为 1/2、1/4、1/16、1/64、1/256，完整 15 子集的全实平移最大 D 分别为 1/4、1/4、1/16、1/64、1/256，最大 D/alpha 分别为 1/2、1、1、1、1；断点数为 19、37、76、76、76。原输入 W=2、V=5/2，所有摘要、纯侧缩放及零尾字段与报告吻合。证据只认证这些固定 n=1 参数，不证明任意 alpha 的渐近式或高维一般结论；root 复跑是同码复跑，非第二独立算法。

实际检查精简归档文件 `/tmp/ccu_r595_compact_results.json`：177547 字节，SHA256 `22817b8c7578b7f7aba2b6759abad2182fa77b62244487a5a7e3de368d1391b9`。递归比对原 full JSON 后，全部保留字段完全一致。只删除了 289 个 segment 的 `all15_subset_boxes` 和 284 个 event 的 `generators`，并新增明确 archive_note；全部 event 位置/值、完整 affine union/D pieces、active masks、maximizers 和输入保留。脚本重跑仍生成 full 明细，因此该精简没有更改已报告的数学输出。

本次实际调用本机 Python/SymPy 核验了 radius 差导数及 Z_H 导数，残差为零；此前预审还核验了 nearmax 反馈。一般严格增益依上述确定性捕获及完整集合测度证明，不靠有限数值外推。未扫描新输入、优化新模型、操作仓库/git、spawn 或编译 PDF。

最终报告的停止点准确：有输入依赖的严格有限原子改进、全局有限原子不达值及固定 d 的严格 doubling 推论；尚无 uniform-d/nearmax 的定量 gain 或可求和全程预算，故仍未改善一般弱型维数指数。到此完成最终绑定审核并停止。
