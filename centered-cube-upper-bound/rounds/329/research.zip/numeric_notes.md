# R329 — full-source second moments for actual many-radius shells

Run with standard Python 3; no external package, random sampling or numerical quadrature:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r329_numeric.py
```

Only `/tmp/r329_numeric.py`, `.json`, and `.md` are owned. All checks use exact `Fraction` values. Long fractions are stored in compact JSON as a precisely described signed numerator/denominator digest plus a descriptive decimal. Floating-point values never decide a gate or an assertion.

## Actual geometry and the precise integral computed

For n=1,2,4,8,16,32,64, retain R328: f=β=ν=1_Q4, λ=q=1, s=0, α=1, L=R. Set δ=1/(4n), r_j=1+j/n and s_j=r_j−δ. Receiver E0=Q_s0; Ej=Q_sj minus Q_s(j−1), with physical radius r_j throughout each shell. Every receiver kernel cube is contained in Q4, so its actual full-source hard response is exactly1 and FIRST density is1_E. For every source y∈Qδ the actual row U_y(x)=r_j^(−n) on Ej. Thus these central rows share J, A and F, and form a positive-volume β subset of mass δ^n.

The computation now integrates the **entire hard source ν=1_Q4**, not selected source points. It still does **not** integrate the outer β variable over all Q4: its BH value is per central y, and the exact central-row contribution is δ^n BH. Full Wβ=Wν=4^n is reported without normalization. No whole original-history, winner, lowpe or root-bound conclusion is asserted.

## Exact tensor integration

Let l(s,r;z) be the one-dimensional overlap length of centered side-s interval with the side-r interval centered at z. For nonnegative s,r it is the trapezoid

l(s,r;z)=[(s+r)/2−|z|]_+−[|s−r|/2−|z|]_+.

Each shell column increment is

a_j(z)=r_j^(−n) [ product_i l(s_j,r_j;z_i) − product_i l(s_(j−1),r_j;z_i) ],

where s_−1=0. All supports lie inside Q_(4−δ), so integration over all space is exactly integration against the true ν on Q4.

The script integrates products of two one-dimensional trapezoids by their exact linear endpoint interpolants on the union of breakpoints; their product is quadratic. It independently checks every nonzero cached integral against

K(x,y)=min(x,y)^2 max(x,y)−min(x,y)^3/3,

using the four-term difference of K at the two trapezoids' outer/inner radii. Tensorization then gives each full-ν Gram entry G_ij=∫a_i a_j ν by four signed n-th powers of these one-dimensional integrals. This yields every prefix S_j=∫A_j² ν. For n1/2 a separate spatial-cell algorithm computes A from actual tensor trapezoids, interpolates it as a multilinear polynomial on each cell, and integrates its square directly; it matches every prefix Gram sum.

The exact first moment is M_j=∫A_j ν=s_j^n, independently consistent with actual Tonelli ∫ν(Q_rj(x))U_y(x) dx=|Ej|. Thus F_j=M_j−S_j/J_j.

## Verified budgets and actual values

The representative threshold is H²=(1+n log2)/4, with declared λ=d=1. Forty rational atanh terms plus a rational remainder enclose log2; all gates are unambiguous by exact squared comparisons. All seven dimensions cross H on their positive-volume central source box.

The complete finite ell integral includes its terminal r_n=b atom. It equals the whole initializer r_cross^(−n)F_cross plus **all** later weighted innovations, without removing any radius atom. Exact batch pooling, strict old-prefix predictor loss and its correction are integrated against the full ν:

ΔF=F_batch + Jh/(J+h) ∫(v−p)²ν;

L= h∫[v(1−v)+(v−p)²]ν, C=h²/(J+h)∫(v−p)²ν,

ΔF=L−C, 0≤C≤(h/J)ΔF.

Checks also certify 0≤ΔF≤2 r_j^n h and the complete initializer upper bound r_cross^(−n)F_cross≤J_cross≤H+1. These are inequalities; they are not substituted for the actual moment computation.

|n|BH per central row|initializer|post-cross innovations|central β contribution δ^n BH|
|---|---:|---:|---:|---:|
|1|0.425000|0.187500|0.237500|0.106250|
|2|0.795946|0.502417|0.293529|0.012437|
|4|1.769942|0.670514|1.099428|2.701e−5|
|8|3.172747|0.793084|2.379663|2.886e−12|
|16|6.523812|0.798593|5.725219|8.234e−29|
|32|12.198998|0.800116|11.398882|4.525e−67|
|64|24.487751|0.795344|23.692407|1.826e−153|

This bounded evidence shows a substantial unpaid post-cross contribution in genuine high-J rows; paying their whole initial crossing alone does not account for their complete row cost. It gives no dimension exponent or extremal lower bound: the central β mass is tiny and the full β mass is4^n. Neither selected columns nor a fictitious point-source measure enters the full-ν moments.

## Reproduction record

Two fresh standalone processes passed the same **15,731 exact checks**. Stages: n1/2 independent low-dimensional check94; n4/8/16 initial expansion1,319; n32/64 expanded14,318. Category counts, prefix exact quantities/digests and final budgets are in the deterministic JSON. In particular there are11,437 independent one-dimensional closed-form comparisons,2,928 nonnegative shell Gram checks,134 full-prefix pooling checks and5 independent low-dimensional spatial polynomial integrations. These finite computations do not certify continuous all-input claims.
