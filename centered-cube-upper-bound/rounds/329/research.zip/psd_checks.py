from fractions import Fraction as F
from itertools import product
count=0
# Algebraic Gram fixtures; no claim of an original cube/source model.
V=[[F(1),F(0)],[F(0),F(2)],[F(3,5),F(4,5)]]
A=[[sum(x*y for x,y in zip(v,w)) for w in V] for v in V];roots=[F(1),F(2),F(1)];J=[r*r for r in roots]
for gates in product((False,True),repeat=3):
 for masses in product((F(1,3),F(2)),repeat=3):
  E=sum((masses[i]*masses[j]*A[i][j]**2/J[i] for i in range(3) for j in range(3) if gates[i]),F(0))
  Q=sum((masses[i]*masses[j]*A[i][j]**2/(roots[i]*roots[j]) for i in range(3) for j in range(3) if gates[i] and gates[j]),F(0))
  cross=sum((masses[i]*masses[j]*A[i][j]**2/J[i] for i in range(3) for j in range(3) if gates[i] and not gates[j]),F(0))
  diff=sum((masses[i]*masses[j]*A[i][j]**2*(1/roots[i]-1/roots[j])**2/2 for i in range(3) for j in range(3) if gates[i] and gates[j]),F(0))
  assert E==Q+cross+diff and E>=Q>=0;count+=1
 for z in product((F(-1),F(0),F(2)),repeat=3):
  Q=sum((z[i]*z[j]*A[i][j]**2/(roots[i]*roots[j]) for i in range(3) for j in range(3) if gates[i] and gates[j]),F(0))
  feat=sum((sum(z[i]*V[i][a]*V[i][b]/roots[i] for i in range(3) if gates[i])**2 for a in range(2) for b in range(2)),F(0))
  assert Q==feat>=0;count+=1
print('PASS algebra-only PSD and exact square remainder checks',count)
