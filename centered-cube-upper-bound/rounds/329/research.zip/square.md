# R329 — exact full-hard-source square for the many-radius shell input

**Result.** The entire `ν=1_(Q4)` integral of `A_yz(r)²` is exactly computable by one-dimensional tensor overlap integrals. For every central row `y∈Qδ`, all prefixes, the complete `B_H`, and post-crossing innovations require `O(N²)` Gram evaluations for `N=n+1` physical radii, with exact rational arithmetic. This integrates ALL hard sources `z`, not probes. It does not integrate the outer row source `β` over all `Q4`: the central-row contribution is exactly `δ^n B_H` for a common `H`. A clipped-rectangle formula below supplies every other fixed row, without claiming the remaining outer integration is completed.

Only `/tmp/r329_square.md` is authored. No other agent's files or Git are changed. This uniform input is a computation fixture, not asserted to be extremal or to satisfy the original full-history/lower-hard-band entrance.

## 1. Actual input, actual receiver shells, and the central rows

Let `n≥1`, `δ=1/(4n)`, `r_j=1+j/n` for `j=0,…,n`, and `s_j=r_j−δ`. Use centered cubes of full side length. Put `s_-1=0` (an empty-volume inner cube),

\[
 f=\beta=\nu=1_{Q_4},\qquad E_j=Q_{s_j}\setminus Q_{s_{j-1}},
 \quad E=Q_{2-\delta},\quad R=L=r_j\ \text{on }E_j,
 \quad s_{\rm soft}=0,\quad\alpha=1,\quad\lambda=1.
\]

For `u∈E_j`, the actual cube `Q_(r_j)(u)` lies inside `Q4`: each coordinate has absolute endpoint at most `r_j−δ/2≤2−δ/2`. Thus `q(u)=h_(r_j)*f(u)=1` and original FIRST is `ρ=1_E`. The hard-source cap is exactly `ν(Q_(r_j)(u))=r_j^n`. There is no substituted fixed convolution in the selector.

If `y∈Qδ`, then `c_u(y)=1` on every `E_j`. Hence the original full row is `U_y(u)=r_j^{-n}` on that shell, and is identical for all such `y`. Denote the prefix through shell `m` by

\[
 J_m=\sum_{j=0}^m h_j,\qquad
 h_j=r_j^{-n}(s_j^n-s_{j-1}^n),
\]
\[
 A_m(z)=\sum_{j=0}^m a_j(z),\qquad
 a_j(z)=r_j^{-n}|E_j\cap Q_{r_j}(z)|.                    \tag{1}
\]

All receiver/source cube boundaries are Lebesgue-null. Inclusive physical-prefix conventions still retain each whole positive-volume shell atom.

## 2. One-dimensional closed form and the full tensor Gram matrix

For `a,r≥0` let the interval overlap length be

\[
 l(a,r;t)=|[-a/2,a/2]\cap[t-r/2,t+r/2]|.
\]

With `U=(a+r)/2`, `u=|a−r|/2`, this is the exact trapezoid

\[
 l(a,r;t)=(U-|t|)_+-(u-|t|)_+.                           \tag{2}
\]

Define for `x,y≥0`

\[
 K(x,y)=\int_{\mathbb R}(x-|t|)_+(y-|t|)_+dt
       =m^2M-m^3/3,\quad m=\min(x,y),\ M=\max(x,y).     \tag{3}
\]

To prove (3), integrate `2(x−t)(y−t)` from `0` to `m`. Consequently, with `V=(c+d)/2`, `v=|c−d|/2`,

\[
 I(a,r;c,d):=\int_{\mathbb R}l(a,r;t)l(c,d;t)dt
   =K(U,V)-K(U,v)-K(u,V)+K(u,v).                        \tag{4}
\]

The formula handles zero side lengths: if `a=0` or `c=0`, it vanishes. The diagonal check is `I(a,r;a,r)=min(a,r)²max(a,r)−min(a,r)³/3`.

Let `T(a,r;z)=∏_(i=1)^n l(a,r;z_i)`. Actual shell geometry gives

\[
 a_j(z)=r_j^{-n}[T(s_j,r_j;z)-T(s_{j-1},r_j;z)].         \tag{5}
\]

Every such response is supported in `Q_(s_j+r_j)⊂Q_(4−δ)`. Thus integrating over all `R^n` is EXACTLY integration against the original full hard source `ν=1_(Q4)`. Tensorization and (4) yield

\[
 \boxed{\begin{aligned}
 G_{jk}:=\int_{Q_4}a_j(z)a_k(z)dz
 =\frac{1}{(r_jr_k)^n}\{&I(s_j,r_j;s_k,r_k)^n
  -I(s_j,r_j;s_{k-1},r_k)^n\\
  &-I(s_{j-1},r_j;s_k,r_k)^n
  +I(s_{j-1},r_j;s_{k-1},r_k)^n\}.
 \end{aligned}}                                       \tag{6}
\]

This is a signed algebraic expansion of a nonnegative shell Gram entry; negative terms must not be separately dropped. It is exact in every dimension, not an asymptotic or a point-source approximation.

## 3. All full-source prefix moments, `B_H`, and innovation

The first moment has an independent actual-Tonelli formula:

\[
 M_m:=\int_{Q_4}A_m(z)dz
  =\sum_{j=0}^m r_j^{-n}|E_j|r_j^n=s_m^n.               \tag{7}
\]

Set `S_-1=0` and update the FULL hard-source second moment by

\[
 S_m:=\int_{Q_4}A_m(z)^2dz
  =S_{m-1}+G_{mm}+2\sum_{i<m}G_{im}.
\]
\[
 \boxed{\qquad F_m=M_m-S_m/J_m.\qquad}                  \tag{8}
\]

Thus `0≤S_m≤J_mM_m` and `F_m−F_(m−1)≥0`, as also follows from the original positive block-variance identity. Neither square nor full-ν first moment is replaced by sample values.

For a common actual `H>0`, let `k=min{m:J_m≥H}`. If there is no such index, `B_H=0`. Otherwise `a=1,b=2` and the COMPLETE physical `ell_n` integral per central row is

\[
 B_H^{\rm central\ row}
 =\sum_{m=k}^{n-1}(r_m^{-n}-r_{m+1}^{-n})F_m+r_n^{-n}F_n
 =r_k^{-n}F_k+\sum_{m=k+1}^nr_m^{-n}(F_m-F_{m-1}).       \tag{9}
\]

The last term includes the explicit terminal `b` atom. The `R=a` physical shell is retained through its inclusive prefix; there is no fictitious `ell_n` atom at `a`. Equation (9) gives the whole initializer and actual post-crossing innovation exactly, including equality thresholds and a crossing at `b`.

For `j≥1` write `j_old=J_(j−1)`, `h=h_j`, `C_j=Σ_(i<j)G_ij`, and `S_old=S_(j−1)`. Full-source drift and intrinsic batch variance are

\[
 D_j:=\int_{Q_4}(v-p)^2dz
   =G_{jj}/h^2+S_{\rm old}/j_{\rm old}^2
                            -2C_j/(h j_{\rm old}),
\]
\[
 F_{{\rm batch},j}=|E_j|-G_{jj}/h.
\]

Hence all terms in R327/R328 are computable from the SAME Gram table:

\[
 \Delta F_j=F_{{\rm batch},j}
               +\frac{j_{\rm old}h}{j_{\rm old}+h}D_j,
\]
\[
 L_j=F_{{\rm batch},j}+hD_j,\qquad
 C_{{\rm center},j}=\frac{h^2}{j_{\rm old}+h}D_j,
 \quad\Delta F_j=L_j-C_{{\rm center},j}.                \tag{10}
\]

All `v,p` here use the original full prefixes. At `j=0` the first-block cost is `F_0=|E_0|−G_00/h_0`; no division by an empty old row is made. A large-relative-atom test uses the actual `h_j/J_(j−1)` and its complete weighted `ΔF_j`. This now verifies the **full ν** innovation, which selected capture columns could not verify.

For fixed common `H`, every central row has the same result, so

\[
 \int_{Q_\delta}\beta(dy)B_H(y)
             =\delta^n B_H^{\rm central\ row}.           \tag{11}
\]

The row source remains the complete `β=1_(Q4)` in the original contract, but (11) computes only this specified positive-measure subset of it. If a threshold varies with `y`, its actual indicators must be integrated instead of using (11).

## 4. Exact algorithm, complexity, and cancellation control

For `N=n+1` shells, compute (6) once for each unordered pair. Stream its new column to update `S_m` in (8); maintain `J_m,M_m,F_m` and then (9),(10). This takes `O(N²)` one-dimensional closed-form calls and integer n-th powers, plus `O(N²)` additions. Binary exponentiation uses `O(log n)` multiplications per n-th power. A full Gram cache uses `O(N²)` entries; streaming columns and storing prefix outputs needs only `O(N)` persistent entries. Bit sizes of exact integers matter; these are arithmetic-operation counts, not unit-cost floating-point claims.

All geometric parameters are rational. A convenient integer implementation avoids intermediate Fraction cancellation. Write

`R_j=4(n+j)`, `d_j=R_j−1`, `d_j^-=0` for `j=0`, otherwise `d_j^-=4(n+j−1)−1`.

For integer `x,y≥0` define `k₀(x,y)=3min(x,y)²max(x,y)−min(x,y)³`, and

\[
 Z(A,R;C,S)=k_0(A+R,C+S)-k_0(A+R,|C-S|)
            -k_0(|A-R|,C+S)+k_0(|A-R|,|C-S|).
\]

Then `I(A/(4n),R/(4n);C/(4n),S/(4n))=Z/[3(8n)³]`. Let

\[
 Y_{jk}=Z(d_j,R_j;d_k,R_k)^n-Z(d_j,R_j;d_k^-,R_k)^n
       -Z(d_j^-,R_j;d_k,R_k)^n+Z(d_j^-,R_j;d_k^-,R_k)^n.
\]

The exact shell Gram entry is

\[
 G_{jk}=\frac{Y_{jk}}{[1536n(n+j)(n+k)]^n},\qquad
 h_j=\frac{d_j^n-(d_j^-)^n}{[4(n+j)]^n}.                \tag{12}
\]

With `L=lcm(n,…,2n)`, all Gram entries share denominator `[1536n L²]^n`, and their corresponding numerators are `Y_jk(L/(n+j))^n(L/(n+k))^n`. Likewise `J_m` can use denominator `(4L)^n`. This gives exact integer prefix accumulation. Four nearly equal powers in (6) may have severe floating cancellation; the exact calculation, or properly outward-rounded interval arithmetic, must retain it.

For irrational proposed thresholds such as `H²=(1+n log2)/4`, source moments remain rational, but the comparisons deciding `k` need certified logarithm/square bounds. One must not silently decide equality or a large-atom gate from descriptive decimals. The numerical packet below uses exact rational enclosures of the logarithm.

## 5. Any fixed noncentral row: shifted clipped rectangles

There is also an exact fixed-`y` interface needed before a full outer-row integral. For each shell clip BOTH its outer and inner cubes by the actual row cube:

\[
 B_{j,+}(y)=Q_{s_j}\cap Q_{r_j}(y),\qquad
 B_{j,-}(y)=Q_{s_{j-1}}\cap Q_{r_j}(y).
\]

Each is an axis box (or empty); its coordinate interval has its own center `c_(j,±,i)(y)` and length `d_(j,±,i)(y)`. Inner and outer boxes can have DIFFERENT centers after clipping. With those actual intervals,

\[
 a_{y,j}(z)=r_j^{-n}\sum_{\epsilon\in\{+,-\}}
  \operatorname{sgn}(\epsilon)
   \prod_i l(d_{j,\epsilon,i},r_j;z_i-c_{j,\epsilon,i}). \tag{13}
\]

An empty box contributes zero. Products of two terms in (13) again integrate coordinatewise. Each one-dimensional product is now of two SHIFTED trapezoids. Sort their at most eight breakpoints; between consecutive points both factors are affine, so their product is quadratic. If `f,g` are the two affine factors on `[x₀,x₁]`, its exact integral is

\[
 \frac{x_1-x_0}{6}
 [2f(x_0)g(x_0)+f(x_0)g(x_1)+f(x_1)g(x_0)+2f(x_1)g(x_1)].
                                                               \tag{14}
\]

The full Gram entry is the four signed products of these coordinate integrals, rather than a single identical n-th power. It costs `O(nN²)` bounded-size one-dimensional integrations for any fixed row. `J_y` is the weighted difference of clipped volumes, and the full-source first moment is the sum of clipped shell volumes. Formula (8) then computes exact `F_y`, with zero on an empty row. Supports are still inside `Q4`, since every actual receiver's hard cube is inside it. Rational `y` gives rational arithmetic throughout.

This does NOT finish integration over all `β(dy)=1_(Q4)dy`. The factor `1/J_y`, the threshold `J_y≥H`, and the switching clip regimes must be integrated with their actual dependence on `y`. Tensorization in the hard source `z` does not remove these dependencies. A future spatial partition/integration must certify that outer step; substituting central rows or an arbitrary representative point is invalid.

### 5a. General finite rectangular field, at a fixed source row

The shifted-box algorithm is not restricted to the concentric fixture. The following is an exact finite-field statement, not an approximation theorem for arbitrary selectors.

Fix a source row `y`. Suppose the ORIGINAL receiver field admits the exact representation

\[
 U_y(u)=\sum_{i=1}^N w_i(y)1_{C_i(y)}(u),\qquad
 C_i(y)=B_i\cap Q_{r_i}(y),\qquad w_i(y)\ge0,\quad a\le r_i\le b,
\]

where the `B_i` are axis rectangles, and the capture radius on the corresponding summand is exactly `r_i`. A receiver partition with actual constant `q_i`, constant masks, hard `L=R=r_i` gives such a field with its actual coefficient `w_i`; in particular the factor `1/q_i` must be included. For a general supplied field this exact representation is a hypothesis. It is not licensed by replacing a variable actual `q(u)` or a soft kernel by cell averages. If summands overlap, the stated sum must still equal the actual field with its radius labels.

Let the entire hard source be the finite rectangular density

\[
 \nu(dz)=\sum_{m=1}^{P}\kappa_m1_{D_m}(z)\,dz,
 \qquad \kappa_m\ge0,
\]

with finite bounded axis rectangles `D_m`; overlap is allowed because this is the actual density sum. Write `C_i(y)` as a product of intervals with lengths `d_{i,l}` and centers `c_{i,l}`. Empty rectangles contribute zero. Set

\[
 T_i(z)=\prod_{l=1}^n l(d_{i,l},r_i;z_l-c_{i,l}),\qquad
 A_y(r,z)=\sum_{i:r_i\le r}w_i(y)T_i(z),\quad
 J_y(r)=\sum_{i:r_i\le r}w_i(y)|C_i(y)|.
\]

Then the exact FULL-source square is

\[
 S_y(r)=\sum_{i,j:r_i,r_j\le r}\sum_{m=1}^{P}
 w_i(y)w_j(y)\kappa_m
 \prod_{l=1}^n
 \int_{(D_m)_l}
 l(d_{i,l},r_i;t-c_{i,l})
 l(d_{j,l},r_j;t-c_{j,l})\,dt.                 \tag{15}
\]

This follows directly by expanding the finite square and applying Tonelli coordinatewise. The first moment `M_y(r)` is computed by the analogous single-trapezoid integrals, and `F_y(r)=M_y(r)−S_y(r)/J_y(r)` for positive `J_y(r)` (zero for an empty row). Every one-dimensional integral in (15) is exact: insert the endpoints of `(D_m)_l` into the sorted trapezoid knots and use (14) on the resulting intervals. Source endpoints therefore remain in the calculation, even when the trapezoids extend outside the source.

For rational boxes, radii, fixed `y`, coefficients and source densities, all quantities are rational. Building the full Gram takes `O(nPN²)` bounded-size one-dimensional integrations, followed by `O(N²)` prefix additions. Sorting the distinct physical radii and including all tied indices at once yields every prefix; the same inclusive tail identity as (9), with its explicit `b` atom, computes the exact fixed-row `B_H`, including threshold crossings and ties. No intermediate artificial ordering within a tied physical radius is required.

Formula (15) supplies a reproducible complete source-square calculation for any field satisfying its finite representation. It does not compute the outer integral over arbitrary `β(dy)`, verify a proposed selector's original contract, or prove convergence of finite rectangular approximations to an arbitrary original field. Those are separate tasks. Its role here is to retain the full capture square during exact finite diagnostics, rather than substitute selected source columns or an unproved geometric upper bound.

## 6. Actual full-source computation and reproducibility

The independent numerical packet is frozen at

* `/tmp/r329_numeric.py` SHA256 `fe8a21b3db5772d2c4de2efee84c1d7c401a3e4eafa65d86be96e6dc313cc7a0`;
* `/tmp/r329_numeric.json` SHA256 `5be81c71373795a0264805a7116a98265534be6063eaacc8b1692d3fc6c68d75`;
* `/tmp/r329_numeric.md` SHA256 `62e77deb7bea8eb91981bfddb91100aa6b86b4dbae3562a131ed4539a86ddc96`.

These hashes were checked locally. Its two fresh processes passed **15,731 exact checks** through `n=1,2,4,8,16,32,64`; the parent also reran it successfully. The independently implemented piecewise-linear product integral was checked 11,437 times against (3),(4). Five low-dimensional independent spatial polynomial integrations of `A²` matched the tensor Gram prefixes in `n=1,2`. The complete initializer, full-source innovations and predictable-centering identities use the actual whole `ν`, not selected source probes.

For its declared threshold `H²=(1+n log2)/4`, every listed dimension has a high-J central source box. Representative descriptive values are:

| n | per-central-row `B_H` | initializer | post-cross innovation | actual central β contribution |
|---|---:|---:|---:|---:|
| 1 | 0.425000 | 0.187500 | 0.237500 | 0.106250 |
| 16 | 6.523812 | 0.798593 | 5.725219 | 8.234e−29 |
| 64 | 24.487751 | 0.795344 | 23.692407 | 1.826e−153 |

The full input masses are `Wβ=Wν=4^n`. The central row mass is only `δ^n`; the table is not an extremal lower bound, dimension-exponent claim, or full-β integrated cost. It shows a genuine full-source post-cross innovation not accounted for by the initializer alone. No original-history/lower-hard-band conclusion is inferred.

Reproduce the complete packet with standard Python:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r329_numeric.py
```

For a minimal author-side algebra check, the following independently executed Fraction code passed **42** exact assertions, including the integer common-denominator formula. It does not replace the larger actual full-source packet.

```python
from fractions import Fraction as F
ct=dict(oneD_diagonal=0,integer_Gram=0,nonnegative_Gram=0,
        prefix_bounds=0,innovation=0,n1_exact=0)
def K(x,y):
    m,M=min(x,y),max(x,y)
    return m*m*M-m**3/3
def I(a,r,c,s):
    U,u=(a+r)/2,abs(a-r)/2; V,v=(c+s)/2,abs(c-s)/2
    return K(U,V)-K(U,v)-K(u,V)+K(u,v)
def ki(x,y):
    m,M=min(x,y),max(x,y)
    return 3*m*m*M-m**3
def Z(A,R,C,S):
    return (ki(A+R,C+S)-ki(A+R,abs(C-S))
            -ki(abs(A-R),C+S)+ki(abs(A-R),abs(C-S)))
for n in (1,2):
    r=[F(n+j,n) for j in range(n+1)]
    a=[v-F(1,4*n) for v in r]; an=[F(0)]+a[:-1]; G={}
    for j in range(n+1):
        assert I(a[j],r[j],a[j],r[j])==(min(a[j],r[j])**2
                *max(a[j],r[j])-min(a[j],r[j])**3/3)
        ct['oneD_diagonal']+=1
        for k in range(n+1):
            val=(I(a[j],r[j],a[k],r[k])**n
                 -I(a[j],r[j],an[k],r[k])**n
                 -I(an[j],r[j],a[k],r[k])**n
                 +I(an[j],r[j],an[k],r[k])**n)/(r[j]*r[k])**n
            A,R,C,S=[int(v*4*n) for v in (a[j],r[j],a[k],r[k])]
            Ap,Cp=int(an[j]*4*n),int(an[k]*4*n)
            Y=(Z(A,R,C,S)**n-Z(A,R,Cp,S)**n
               -Z(Ap,R,C,S)**n+Z(Ap,R,Cp,S)**n)
            assert val==F(Y,(1536*n*(n+j)*(n+k))**n)
            ct['integer_Gram']+=1
            assert val>=0; ct['nonnegative_Gram']+=1; G[j,k]=val
    J=F(0); oldF=F(0)
    for m in range(n+1):
        J+=(a[m]**n-an[m]**n)/r[m]**n
        S=sum(G[j,k] for j in range(m+1) for k in range(m+1))
        M=a[m]**n
        assert 0<=S<=J*M; ct['prefix_bounds']+=1
        Fm=M-S/J
        assert Fm>=oldF; ct['innovation']+=1; oldF=Fm
        if n==1 and m==0:
            assert S==F(27,64) and Fm==F(3,16); ct['n1_exact']+=1
print('PASS',ct,'total',sum(ct.values()))
```

The exact deliverable is a full-hard-source tensor square and prefix algorithm, together with the noncentral fixed-row interface. It is not an all-input source-root estimate or an already-completed outer-β integration.
