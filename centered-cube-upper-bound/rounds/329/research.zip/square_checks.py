from fractions import Fraction as F
ct=dict(oneD_diagonal=0,integer_Gram=0,nonnegative_Gram=0,
        prefix_bounds=0,innovation=0,n1_exact=0)
def K(x,y):
    m,M=min(x,y),max(x,y)
    return m*m*M-m**3/3
def I(a,r,c,s):
    U,u=(a+r)/2,abs(a-r)/2; V,v=(c+s)/2,abs(c-s)/2
    return K(U,V)-K(U,v)-K(u,V)+K(u,v)
def ki(x,y):
    m,M=min(x,y),max(x,y)
    return 3*m*m*M-m**3
def Z(A,R,C,S):
    return (ki(A+R,C+S)-ki(A+R,abs(C-S))
            -ki(abs(A-R),C+S)+ki(abs(A-R),abs(C-S)))
for n in (1,2):
    r=[F(n+j,n) for j in range(n+1)]
    a=[v-F(1,4*n) for v in r]; an=[F(0)]+a[:-1]; G={}
    for j in range(n+1):
        assert I(a[j],r[j],a[j],r[j])==(min(a[j],r[j])**2
                *max(a[j],r[j])-min(a[j],r[j])**3/3)
        ct['oneD_diagonal']+=1
        for k in range(n+1):
            val=(I(a[j],r[j],a[k],r[k])**n
                 -I(a[j],r[j],an[k],r[k])**n
                 -I(an[j],r[j],a[k],r[k])**n
                 +I(an[j],r[j],an[k],r[k])**n)/(r[j]*r[k])**n
            A,R,C,S=[int(v*4*n) for v in (a[j],r[j],a[k],r[k])]
            Ap,Cp=int(an[j]*4*n),int(an[k]*4*n)
            Y=(Z(A,R,C,S)**n-Z(A,R,Cp,S)**n
               -Z(Ap,R,C,S)**n+Z(Ap,R,Cp,S)**n)
            assert val==F(Y,(1536*n*(n+j)*(n+k))**n)
            ct['integer_Gram']+=1
            assert val>=0; ct['nonnegative_Gram']+=1; G[j,k]=val
    J=F(0); oldF=F(0)
    for m in range(n+1):
        J+=(a[m]**n-an[m]**n)/r[m]**n
        S=sum(G[j,k] for j in range(m+1) for k in range(m+1))
        M=a[m]**n
        assert 0<=S<=J*M; ct['prefix_bounds']+=1
        Fm=M-S/J
        assert Fm>=oldF; ct['innovation']+=1; oldF=Fm
        if n==1 and m==0:
            assert S==F(27,64) and Fm==F(3,16); ct['n1_exact']+=1
print('PASS',ct,'total',sum(ct.values()))
