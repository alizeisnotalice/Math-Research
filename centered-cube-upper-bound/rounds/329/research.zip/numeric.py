#!/usr/bin/env python3
"""Actual R328 uniform-source shell rows: exact full-nu second moments."""
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
from pathlib import Path
from itertools import product
import json,hashlib
C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1500:return str(x)
 a=abs(x.numerator);raw=(str(x.numerator<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative_flag:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def log2bounds():
 t=F(1,3);v=2*sum((t**(2*i+1)/F(2*i+1) for i in range(40)),F(0));return v,v+2*t**81/(81*(1-t*t))
def trap(s,r,x):return max(F(0),min(s,r,(s+r)/2-abs(x)))
def breaks(s,r):return [F(0),abs(s-r)/2,(s+r)/2] if s else [F(0)]
@lru_cache(None)
def gram(s,r,t,v):
 if not s or not t:return F(0)
 pts=sorted(set(breaks(s,r)+breaks(t,v)));ans=F(0)
 for a,b in zip(pts,pts[1:]):
  mid=(a+b)/2;pa=trap(s,r,a);pb=trap(s,r,b);qa=trap(t,v,a);qb=trap(t,v,b)
  # Independent exact integral of product of linear endpoint interpolants.
  ans+=(b-a)*(2*pa*qa+pa*qb+pb*qa+2*pb*qb)/6
 U,u=(s+r)/2,abs(s-r)/2
 V,v=(t+v)/2,abs(t-v)/2
 def K(a,b):
  small,big=sorted([a,b]);return small*small*big-small**3/3
 ck('independent_closed_form_1D_Gram',2*ans==K(U,V)-K(U,v)-K(u,V)+K(u,v))
 return 2*ans

def lowdim_direct(rs,ss,n,stop):
 """Independent spatial-cell multilinear interpolation and polynomial square."""
 pts=sorted(set(sum((breaks(ss[j],rs[j])+breaks(ss[j-1],rs[j]) if j else breaks(ss[j],rs[j]) for j in range(stop+1)),[])))
 def A(z):
  ans=F(0)
  for j in range(stop+1):
   p=F(1);q=F(1) if j else F(0)
   for x in z:p*=trap(ss[j],rs[j],x);q*=trap(ss[j-1],rs[j],x) if j else 0
   ans+=(p-q)/rs[j]**n
  return ans
 total=F(0)
 for ids in product(range(len(pts)-1),repeat=n):
  lo=[pts[i] for i in ids];width=[pts[i+1]-pts[i] for i in ids]
  coef={bits:A([lo[i]+bits[i]*width[i] for i in range(n)]) for bits in product([0,1],repeat=n)}
  for axis in range(n):
   for bits in list(coef):
    if bits[axis]:other=list(bits);other[axis]=0;coef[bits]-=coef[tuple(other)]
  integral=F(0)
  for p,a in coef.items():
   for q,b in coef.items():
    term=a*b
    for i in range(n):term*=width[i]/(p[i]+q[i]+1)
    integral+=term
  total+=integral
 return 2**n*total

def model(n):
 eta=F(1,4*n);rs=[1+F(j,n) for j in range(n+1)];ss=[r-eta for r in rs]
 vs=[s**n-(ss[j-1]**n if j else 0) for j,s in enumerate(ss)];hs=[v/r**n for v,r in zip(vs,rs)]
 J=M=S=F(0);Js=[];Fs=[];Ss=[];rows=[];G={}
 for j,r in enumerate(rs):
  ck('actual_containment_q_FIRST',ss[j]/2+r/2<=2 and ss[j]/2+eta/2==r/2)
  ck('actual_kernel_atom_bound',0<hs[j]<=1)
  ck('full_nu_support',ss[j]+r<4)
  for i in range(j+1):
   value=F(0)
   for e,sign in [(ss[i],1),(ss[i-1] if i else F(0),-1)]:
    for t,sgn in [(ss[j],1),(ss[j-1] if j else F(0),-1)]:value+=sign*sgn*gram(e,rs[i],t,r)**n
   value/=rs[i]**n*r**n;G[i,j]=value
   ck('full_nu_shell_cross_nonnegative',value>=0)
  cross=sum((G[i,j] for i in range(j)),F(0));sii=G[j,j];h=hs[j]
  oldJ,oldS=J,S;oldF=Fs[-1] if Fs else F(0)
  J+=h;M+=vs[j];S+=2*cross+sii;V=M-S/J
  ck('full_nu_first_moment_telescope',M==ss[j]**n)
  ck('full_nu_second_moment_bounds',0<=S<=J*M)
  batch=vs[j]-sii/h
  between=(h/oldJ*oldS-2*cross+oldJ/h*sii)/(oldJ+h) if oldJ else F(0)
  ck('full_nu_pooling_identity',V-oldF==batch+between and batch>=0 and between>=0)
  ck('full_nu_increment_cap',0<=V-oldF<=2*r**n*h)
  if oldJ:
   loss=vs[j]+h*oldS/oldJ**2-2*cross/oldJ
   correction=(sii-2*h*cross/oldJ+h*h*oldS/oldJ**2)/(oldJ+h)
   ck('integrated_predictable_loss',V-oldF==loss-correction)
   ck('integrated_correction_bound',0<=correction<=h/oldJ*(V-oldF))
  else:loss=V;correction=F(0)
  Js.append(J);Fs.append(V);Ss.append(S);rows.append((loss,correction))
  if n<=2:ck('independent_lowdim_spatial_integral',lowdim_direct(rs,ss,n,j)==S)
 lo,hi=log2bounds();hlo=(1+n*lo)/4;hhi=(1+n*hi)/4
 gates=[]
 for x in Js:
  ck('exact_root_gate',x*x<hlo or x*x>=hhi);gates.append(x*x>=hhi)
 ck('root_high_J_nonempty',gates[-1]);k=gates.index(True)
 ell=[r**(-n)-(rs[i+1]**(-n) if i<n else 0) for i,r in enumerate(rs)]
 B=sum((w*v for w,v,g in zip(ell,Fs,gates) if g),F(0));init=rs[k]**(-n)*Fs[k]
 after=sum((rs[i]**(-n)*(Fs[i]-Fs[i-1]) for i in range(k+1,n+1)),F(0))
 ck('full_nu_BH_endpoint_identity',B==init+after)
 ck('whole_cross_initializer_cap',init<=Js[k] and (Js[k]<=1 or (Js[k]-1)**2<=hlo))
 ck('integrated_post_predictor',sum((rows[i][0]-rows[i][1] for i in range(k+1,n+1)),F(0))==Fs[-1]-Fs[k])
 ck('nontrivial_full_variance',B>0 and after>=0)
 return dict(n=n,central_source_mass=str(eta**n),W_beta=str(4**n),W_nu=str(4**n),J_final=brief(J),M_final=brief(M),second_moment_final=brief(S),F_final=brief(Fs[-1]),BH_per_central_row=brief(B),central_rows_BH=brief(eta**n*B),first_high_radius=str(rs[k]),initializer=brief(init),post_innovations=brief(after),BH_decimal=float(B),initializer_decimal=float(init),post_innovations_decimal=float(after),F_decimal=float(Fs[-1]),central_BH_decimal=float(eta**n*B),prefixes=[dict(radius=str(r),J=brief(j),M=brief(sum(vs[:i+1])),second_moment=brief(s),variance=brief(v)) for i,(r,j,s,v) in enumerate(zip(rs,Js,Ss,Fs))])
def main():
 models=[];stages=[]
 for stage,ns in [('small_independent',[1,2]),('initial_expansion',[4,8,16]),('expanded',[32,64])]:
  before=sum(C.values());models.extend(model(n) for n in ns);stages.append(dict(stage=stage,dimensions=ns,checks=sum(C.values())-before))
 result=dict(status='PASS',total_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='Exact full-nu moments of actual central-y rows in R328 uniform-source physical shells. Full beta outer integral is NOT computed: central-y subset only, mass eta^n; full Wf=4^n reported. No original-history or root-bound assertion.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
