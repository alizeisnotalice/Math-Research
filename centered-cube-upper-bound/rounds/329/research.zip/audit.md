# R329 independent preauthor screen — full actual-source second moments

Ownership: only /tmp/r329_audit.md, no Git or other-author files. The new author proof has not been read. This screen uses the precise R328 actual model f=beta=nu=1_Q4, q=lambda=1, alpha=1, s=0, L=R, and actual receiver shells.

## 1. Exact scope and analytic derivation

Let delta=1/(4n), r_j=1+j/n for j=0,...,n. E_0=Q_(r_0-delta) and E_j=Q_(r_j-delta)\Q_(r_(j-1)-delta) for j>=1. At every actual u in E_j its kernel is h_(r_j), and q(u)=1 because Q_(r_j)(u) is contained in Q4, up to null boundaries. For EVERY y in central Q_delta, all original receiver cubes capture y: |u_i-y_i|<=(r_j-delta)/2+delta/2=r_j/2. Consequently the ORIGINAL U_y(u)=r_j^(-n)1_Ej(u) is identical for all these y. This includes a positive-volume set of actual source rows; it does not represent an average over all beta or assert the formula for arbitrary y.

Define s_(j,+)=r_j-delta and s_(j,-)=r_(j-1)-delta for j>=1, with s_(0,-)=0 and s_(0,+)=r_0-delta. Set ell_(s,r)(z)=|[-s/2,s/2] intersection [z-r/2,z+r/2]|, identically zero for s=0. For a physical prefix k,

 A_k(z)=sum_(j=0)^k r_j^(-n) [ product_i ell_(s_(j,+),r_j)(z_i) - product_i ell_(s_(j,-),r_j)(z_i) ].

This is exact actual dx integration of U_y(u)c_u(z), not shell-centre sampling. Each inner subtraction uses the SAME current radius r_j. Fubini and expansion of the finite square give

 integral_nu A_k(z)^2 = sum_(i,j=0)^k (r_i r_j)^(-n) sum_(sigma,tau in {+,-}) sign(sigma)sign(tau) [integral_R ell_(s_(i,sigma),r_i)(x)ell_(s_(j,tau),r_j)(x)dx]^n.

Every factor is compactly supported inside [-(4-delta)/2,(4-delta)/2], since s_(j,+)+r_j<=4-delta. Thus the full-space source integral is EXACTLY the original nu=1_Q4 integral. Receiver/source cube faces are Lebesgue-null; no density approximation, source truncation or parameter-frozen independent source selector is used. The signs come from expansion of ACTUAL shell differences. The second moment itself is nonnegative, but its signed expansion may have severe cancellation; high precision agreement alone would not replace exact or interval certification.

The full first moment is M_k=sum_(j<=k)|E_j|=(r_k-delta)^n, because nu(Q_(r_j)(u))=r_j^n on every actual receiver. J_k=sum_(j<=k)|E_j|/r_j^n. Therefore F_k=M_k-(integral_nu A_k^2)/J_k is now the true full-nu variance for these central y, not a selected-source probe. The original inclusive layer identity can then evaluate the actual high-J B_H ROW value for these y. Multiplication by beta(Q_delta)=delta^n gives only that positive source-row contribution, not the whole beta-integral/global B_H.

For arbitrary y, U_y additionally restricts each E_j by Q_(r_j)(y). The resulting truncated receiver boxes depend on y and are generally not the centred shell pair above. The displayed formula must not be extended to those rows without an explicit new intersection formula/integration. All source outside the central y region remains in the original global problem.

## 2. Independent exact low-dimensional verification plan

ell_(s,r) is continuous piecewise affine, with knots +/-(s+r)/2 and +/-|s-r|/2; zero-width s=0 contributes zero. Take the common finite knot partition. On each 1D interval integrate each product of two affine factors exactly (a quadratic). Independently form the whole A_k as a tensor polynomial on each common grid cell and integrate its SQUARE directly, rather than expand shell-pair coefficients first. Dimensions1 and2 allow exact rational arithmetic and include nonzero inner subtraction, top b and source-boundary support. Agreement certifies this finite algebra/model implementation only; the all-dimensional formula follows analytically from finite Fubini and product structure.

## 3. Actually executed independent local verification

Reviewer ran the preceding method in a local Python standard-library Fraction process. PASS {'pair_integrals': 34, 'full_second_moments': 5, 'first_moments': 5, 'variance_bounds': 5, 'knot_values': 116}, total 165 counted assertions. Dimensions1 and2, every physical prefix (5 full-prefix evaluations). Pair integrals use exact Simpson integration of quadratic pieces; independent whole-square integrals use multilinear corner coefficients and exact tensor Bernstein Gram factors1/3 or1/6. Exact FIRST moments and full-nu variance positivity were also checked. No author script or arbitrary-y/global source integration was run.

Exact receipts (n,prefix,full second moment,full variance): [(1, 0, '27/64', '3/16'), (1, 1, '87/64', '53/80'), (2, 0, '693889/2359296', '14063/36864'), (2, 1, '20429129/21233664', '30379255/26873856'), (2, 2, '85986017/42467328', '163623583/71000064')]

Initial verdict: PASS for the stated CENTRAL-y exact formula. It advances beyond probes to full nu integration for those rows only. The arbitrary-y beta integral and any claimed general/root estimate remain to be separately proved. Await final author/core scope.

## 4. Final numeric implementation review (no repeated full run)

Read final numeric.py/md in full. PASS. The overlap trapezoid formula is correct including s=0. The union-knot piecewise quadratic Gram integration and four-term triangular closed form K(U,V)-K(U,v)-K(u,V)+K(u,v) are independently valid; its full-line factor2 is correct. Each shell cross Gram entry uses the same current radius for inner subtraction, normalization r_i^n r_j^n and n-th tensor power. Prefix square updates S+=2cross+sii and M telescope are correct. The full-nu batch/mean-prediction identities, strict old-prefix loss/correction and positivity checks are algebraically correct. The low-dimensional multilinear spatial interpolation is separate from shell-pair expansion.

The H gates use exact squared comparisons against rational log2 enclosures. Inclusive ell includes the terminal b atom; B=initializer+weighted ALL post-cross innovations is exact on central y. The initializer check proves the stated inequality rather than replacing computed variance. Source support is inside Q4. Full Wbeta=Wnu=4^n remains; multiplying per-row cost by delta^n gives ONLY central-row contribution. Positive variance growth per row and tiny central beta mass establish neither a dimension exponent nor global lower/upper bound. Numeric choices lambda=d=1 and endpoint s=0 are declared validation fields, not a complete original winner/lowpe/history bridge.

Primary reports a fresh full execution15731 exact assertions:94 n1/2,1319 n4/8/16,14318 n32/64. This reviewer did not repeat that run; the165 independently executed checks in section3 are separate. No additional code files or output JSON were written by the reviewer. Numeric note correctly distinguishes whole nu integration from absent whole beta integration.

Interim hashes:
- /tmp/r329_numeric.py — fe8a21b3db5772d2c4de2efee84c1d7c401a3e4eafa65d86be96e6dc313cc7a0
- /tmp/r329_numeric.md — 62e77deb7bea8eb91981bfddb91100aa6b86b4dbae3562a131ed4539a86ddc96

## 5. Author square and general fixed-y module comparison

Read the complete /tmp/r329_square.md and /tmp/r329_box_gram.py after the independent screen. PASS. The author full-line triangular Gram formula and four shell signs agree with section1; all supported source points remain inside Q4. Full first moment, full prefix second moment, batch variance/drift, predictable correction, inclusive b atom and no-cross/equality/b-crossing conventions are correct. The exact integer formula G_jk=Y_jk/[1536 n(n+j)(n+k)]^n and the proposed LCM denominators follow by cubic scaling of the one-dimensional integrals. Its O(N²) statement is an arithmetic-operation count with exact integer bit complexity explicitly retained, not a floating-point runtime bound.

The noncentral fixed-y extension correctly clips BOTH outer and inner receiver boxes by the SAME actual Q_rj(y). They may have distinct coordinate centres. Shifted trapezoid products integrate by union knots and the exact quadratic endpoint formula; full-source tensor products replace the identical n-th power. Full J_y and first moment use the corresponding weighted clipped volumes. This supplies a formula for any fixed row; it does not remove the y-dependent reciprocal J_y, high-J gate or clip regimes from the outer beta integral. For variable H(y), the central delta^n multiplier is valid only after integrating its actual indicators.

Generic module: under the declared common-dimension, nonnegative finite rational weights/densities, positive radii and valid finite axis-box contract, moments() computes J,M,S exactly for U_y=sum_i w_i 1_(B_i intersection Q_ri(y)) and nu=sum_m d_m 1_Dm. Receiver overlap and source-box overlap are additive; ALL receiver cross terms occur in S. An arbitrary overlapping receiver list is a marked density model and is not automatically one admissible original unique-radius selector. Every component must separately inherit its actual original provenance when this tool is transplanted. The independent direct() function constructs the whole multilinear A on each source cell and integrates its square; it retains cross terms and additive source densities. Empty clipped boxes and face equality give zero-volume contributions. No input validation is provided for invalid dimensions/signs/intervals; those are mathematical input requirements.

Primary reports28 exact checks for this generic module (two dimensions, seven fixed rows, second-moment bound and independent square agreement), in addition to15731 full shell checks. This reviewer inspected code/formulas and did not repeat those complete runs. Author42 local checks are separately reported, not added as new primary execution unless a primary fresh run is recorded.

Verdict remains PASS for a full-nu exact geometric computation engine and fixed-y extension. There is no new general source-root budget at this point. Full-beta integration and original history/lower-hard-band matching remain unperformed. Await any final general core/integration claims before freezing final scope.

SHA256 bindings:
- /tmp/r329_square.md — 246d4c3da3d85bcfeec5e6dc4e371f2b53fb71bfc4186af3be5773145babe234
- /tmp/r329_box_gram.py — 7989a5835526c7e9f99a51e2022b886d6fb28ab67437f0e5545e03456cca3366

Final author version246d4c3da3d85bcfeec5e6dc4e371f2b53fb71bfc4186af3be5773145babe234 includes section5a, now explicitly read and PASS: formula(15) integrates the actual full finite rectangular source density, with source endpoints retained, actual q coefficients and radius labels required, overlapping summands treated only when they equal the original marked field, and all tied radius indices included together. No convergence theorem or all-beta integration is asserted. Its O(nPN²) count is an arithmetic-operation count. No further mathematical correction is requested.

## 6. Independent preauthor screen of the fixed-hard-field Gram dual

The candidate is valid under an explicitly HARD shared contract: alpha=1,s=0,L=R, frozen E,R,q, U_y(u)=1_E c_u(y)/(q(u)R(u)^n), finite nonnegative L1 g with T g=q on E, T g=h_R*g. U,J,A,H and the Y_r={J_y(r)>=H} gate are frozen for this whole feasible class. A_yz(r)=integral_prefix c_u(y)c_u(z)/(q(u)R(u)^n)du is symmetric. This symmetry is not inherited by arbitrary general-soft two-kernel fields. Feasibility does not include original history/lowpe constraints unless separately imposed on the same frozen inputs.

Use positive ell throughout. The first moment is <a,g>, a_y=integral ell1_Y(y) integral_prefix U_y(u)q(u)R(u)^n du, by the ACTUAL identity T g=q before changing g. Write E(g)=integral ell1_Y(y)g(y)g(z)A_yz²/J_y. Its split is EXACT:

 E(g)=Q(g)+Cross(Y,Yc)+1/2 integral ell1_Y(y)1_Y(z)g(y)g(z)A_yz²(1/sqrt(J_y)-1/sqrt(J_z))².

Here Q has kernel integral ell1_Y(y)1_Y(z)A_yz²/sqrt(J_y J_z), and Cross is the original y-high/z-low term. Both omitted terms are nonnegative for nonnegative g. At zero J the high gate H>0 excludes division. A² is a Gram kernel: expand it over two ACTUAL receivers u,w, with feature c_u(y)c_w(y), then multiply each feature by1_Y(y)/sqrt(J_y) and integrate ell. Therefore Q is positive semidefinite for signed finite-energy test functions; no lower Schur/correlation estimate is assumed. B(g)=<a,g>-E(g)<=<a,g>-Q(g) is the claimed concave upper relaxation, not an equality or concavity assertion for the original full B itself.

For any reference g0 of finite Q-energy, positivity of Q(g-g0) yields -Q(g)<=-2<g,Kg0>+Q(g0). A common pointwise/a.e. certificate a-2Kg0<=c+T*psi then gives B(g)<=c||g||1+Q(g0)+integral_E psi q. To apply it to all L1 feasible g the pointwise inequality must hold off one Lebesgue-null set independent of g; not only at a finite tested source set. Require finite <a,g>, Q(g), Q(g0), well-defined bilinear term, and integral_E |psi|q<infinity, so signed Fubini is justified by integral g T*|psi|=integral |psi|q. Infinite-energy subtraction is invalid. A signed reference g0 needs the same absolute/finite-energy construction; nonnegative g0 is sufficient. The frozen field and sources are not recomputed after an optimizer is selected.

The baseline g0=0,c=0,psi=1_E is valid since a<=T*1_E, but only returns integral_E q<=lambda|E|. No root certificate has been constructed by this algebra. The omitted cross/imbalance terms are favorable credits, not an extra E_full available for a second subtraction. This interface is related to a full Gram computation but does not turn the fixed-y box algorithm into whole-source optimization or original-history admission.

## 7. Final core proof and ledger comparison — PASS

Read the complete frozen /tmp/r329_core.md (a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc) after the independent section6 screen. It correctly assumes the hard shared field beta=f,nu<=f,alpha1,s0,L=R and freezes E,R,q,U,J,A,H for the entire feasible class Tg=q. Replacing the positive I_rem(f,nu) by the whole B_H(f,f) is a relaxation, not an addition to its already-paid crossing/large-atom budget. The exact symmetrization, high/low cross credit, clock-imbalance square and two-receiver Gram features are correct. Neither original B itself nor a general-soft field is asserted to have this concavity identity.

The final integrability bounds close the needed interface. Since A_yz<=min(J_y,J_z), A_yz²/sqrt(J_yJ_z)<=A_yz on the high/high gate. Consequently K<=integral ell A<=A_n/(q_-a^n). Also a(y)<=|E|/a^n. Thus every L1 nonnegative g and reference g0 has finite energy and all bilinear pairings are defined. For signed psi in L1(E), integral g T*|psi|=integral |psi|q<=lambda||psi||1 supplies absolute Fubini. Pointwise/a.e. inequality(6), together with the actual receiver bill(7), rigorously gives(8). The trivial psi1 certificate only proves B_H<=X and does not satisfy a prescribed small epsilon bill. Finite optimization does not certify the all-source pointwise inequality, convergence, strong duality or a root c; these remain explicit missing steps.

The separate /tmp/r329_psd_checks.py was read:280 exact algebra-only gate-symmetrization/Schur-square feature tests are correctly scoped. Its arbitrary finite Gram fixtures are not actual cube incidences. The author's extra48 local algebra checks are not included as additional primary runs. No reviewer repetition of either was performed.

Read final checkpoint ledger.md. PASS: central-row full-nu square computation is distinguished from absent outer-beta integration; positive central mass is tiny and per-row growth is not a general exponent/lower-bound claim. The fixed-field optimization is not a new paid contribution. Full J/A includes paid blocks; original square/credits are spent once. Actual H and low-row complement cannot be changed free. General-soft dense-atom C_H-S_H and later I_H, hard I_rem, original time/deletion/future-source atoms, Phi_next/P_suffix, entrance/aspect/wide/outer/all-scale slots remain unresolved. No new general source payment or X loss is claimed. The existing epsilon_original+1/256 etc is not a certified complete absorption bound.

Primary actual evidence as recorded:15731 shell checks+28 general fixed-y boxes+42 minimum formulas+280 algebra PSD=16081 exact checks. Reviewer165 independent low-dimensional checks and author's48 separate local checks remain distinct. No PDF compilation or new full run was made by this reviewer.

Final verdict: PASS for the exact full-nu tensor/box engine, the bounded fixed-hard-field concave/weak-dual interface and the stated limited integration. No general root certificate or complete-beta integrated budget is proved. No correction remains within this bounded task.

## 8. Final SHA256 bindings

- /tmp/r329_square.md — 246d4c3da3d85bcfeec5e6dc4e371f2b53fb71bfc4186af3be5773145babe234
- /tmp/r329_core.md — a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc
- /tmp/r329_numeric.py — fe8a21b3db5772d2c4de2efee84c1d7c401a3e4eafa65d86be96e6dc313cc7a0
- /tmp/r329_numeric.md — 62e77deb7bea8eb91981bfddb91100aa6b86b4dbae3562a131ed4539a86ddc96
- /tmp/r329_box_gram.py — 7989a5835526c7e9f99a51e2022b886d6fb28ab67437f0e5545e03456cca3366
- /tmp/r329_psd_checks.py — 5b674df850b5c98d092e98ed08777508275ddb12d840b59f929bf72516962d60
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/box_gram.py — 7989a5835526c7e9f99a51e2022b886d6fb28ab67437f0e5545e03456cca3366
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/combined.md — 202cd17c0f3a90bbee348ebce9ebffa54d31b19c12f09205203a7e2af64d3e31
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/core.md — a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/ledger.md — 22e3061c81dd6e48437cde043cbe86ab5760839dd219dc44b88d21514a18f64e
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/numeric.py — fe8a21b3db5772d2c4de2efee84c1d7c401a3e4eafa65d86be96e6dc313cc7a0
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/numeric_notes.md — 62e77deb7bea8eb91981bfddb91100aa6b86b4dbae3562a131ed4539a86ddc96
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/numeric_summary.json — 5be81c71373795a0264805a7116a98265534be6063eaacc8b1692d3fc6c68d75
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/psd_checks.py — 5b674df850b5c98d092e98ed08777508275ddb12d840b59f929bf72516962d60
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/research.tex — 22c86b598e71c462aa5729885646d9aa3253414ea041f6bcade9338f5eb26125
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/square.md — 246d4c3da3d85bcfeec5e6dc4e371f2b53fb71bfc4186af3be5773145babe234
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/square_checks.py — 615c017c4b8c36d20d6b97a5efde6fc6a10f054a5b6e591698292310162a4fb9
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round329_20261018_final_checkpoint/verification.txt — 982099155dfd998fc62fb618195369ba2feaad18ff71bb5f310e9730f5107cf1

Frozen after this receipt. Only /tmp/r329_audit.md was written by this reviewer. No Git, other-author edits, repeated final numeric execution or TeX compilation. No later typesetting is certified by this receipt.
