"""Exact full-source moments of finite box receiver fields, fixed y.
No original q/history admissibility or general dimension bound is inferred.
"""
from fractions import Fraction as F
from itertools import product
from math import prod

def overlap(I,r,x):return max(F(0),min(I[1],x+r/2)-max(I[0],x-r/2))
def knots(I,r):return [I[0]-r/2,I[0]+r/2,I[1]-r/2,I[1]+r/2]
def integral(I,r,K,s,D):
    pts=sorted(set([D[0],D[1]]+[x for x in knots(I,r)+knots(K,s) if D[0]<x<D[1]]))
    total=F(0)
    for a,b in zip(pts,pts[1:]):
        p,q=overlap(I,r,a),overlap(I,r,b);v,w=overlap(K,s,a),overlap(K,s,b)
        total+=(b-a)*(2*p*v+p*w+q*v+2*q*w)/6
    return total

def first(I,r,D):
    pts=sorted(set([D[0],D[1]]+[x for x in knots(I,r) if D[0]<x<D[1]]))
    return sum(((b-a)*(overlap(I,r,a)+overlap(I,r,b))/2 for a,b in zip(pts,pts[1:])),F(0))

def clip(B,r,y):
    C=[(max(l,x-r/2),min(u,x+r/2)) for (l,u),x in zip(B,y)]
    return C if all(u>l for l,u in C) else None

def moments(receivers,sources,y):
    # receivers (box,r,weight), sources (box,density); sources may overlap additively.
    atoms=[(C,r,w) for B,r,w in receivers if (C:=clip(B,r,y)) is not None]
    J=sum((w*prod(u-l for l,u in C) for C,r,w in atoms),F(0))
    M=S=F(0)
    for D,d in sources:
        for C,r,w in atoms:
            M+=d*w*prod(first(I,r,T) for I,T in zip(C,D))
            for K,s,v in atoms:
                S+=d*w*v*prod(integral(I,r,V,s,T) for I,V,T in zip(C,K,D))
    return J,M,S

def direct(receivers,sources,y):
    # Independently integrate square of multilinear A on each source cell.
    atoms=[(C,r,w) for B,r,w in receivers if (C:=clip(B,r,y)) is not None];n=len(y);answer=F(0)
    def A(z):return sum((w*prod(overlap(I,r,x) for I,x in zip(C,z)) for C,r,w in atoms),F(0))
    for D,d in sources:
        axes=[sorted(set([a,b]+[t for C,r,w in atoms for t in knots(C[k],r) if a<t<b])) for k,(a,b) in enumerate(D)]
        for idx in product(*(range(len(v)-1) for v in axes)):
            lo=[axes[k][i] for k,i in enumerate(idx)];h=[axes[k][i+1]-axes[k][i] for k,i in enumerate(idx)]
            cs={bits:A([lo[k]+bits[k]*h[k] for k in range(n)]) for bits in product([0,1],repeat=n)}
            for k in range(n):
                for bits in cs:
                    if bits[k]:v=list(bits);v[k]=0;cs[bits]-=cs[tuple(v)]
            answer+=d*sum((a*b*prod(h[k]/(i[k]+j[k]+1) for k in range(n)) for i,a in cs.items() for j,b in cs.items()),F(0))
    return answer

if __name__=='__main__':
    count=0
    for n in (1,2):
        receivers=[([(F(-1),F(0))]*n,F(1),F(2,3)), ([(F(0),F(1))]*n,F(3,2),F(4,5))]
        sources=[([(F(-2),F(2))]*n,F(1)), ([(F(-1,3),F(2,3))]*n,F(1,4))]
        for x in (F(-2),F(-1),F(-1,4),F(0),F(1,3),F(1),F(2)):
            y=[x]*n;J,M,S=moments(receivers,sources,y)
            assert 0<=S<=J*M;count+=1
            assert S==direct(receivers,sources,y);count+=1
    print('PASS generic fixed-y box/source moments',count,'exact assertions')
