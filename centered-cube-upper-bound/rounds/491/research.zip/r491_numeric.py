from pathlib import Path
from fractions import Fraction as F
import sys,platform,json,time
import sympy as s
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384
start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def finite(v):ck(v.is_finite())
def eqzero(v):finite(v);ck(v.contains(0))
def nonneg(v,equal=False):
 finite(v)
 if equal:ck(v.contains(0))
 else:ck(v>=0)
def pw(q,p):
 if q==0:return arb(0)
 return (ar(q).log()*p).exp()
def dot(a,b):return sum((x*y for x,y in zip(a,b)),arb(0))
def mv(A,v):return [dot([ar(x) for x in row],v) for row in A.tolist()]
def avg(v):return sum(v,arb(0))/len(v)
def sq(v):return avg([x*x for x in v])
def exact(v):return [str(x) for x in v]
R=s.Rational
base=s.Matrix([[R(1,2),R(1,8),0],[0,R(1,4),R(1,8)],[R(1,8),0,R(1,2)]])
cases=[('initial_nonsymmetric',s.Matrix([[R(1,2),R(1,8)],[R(1,4),R(1,2)]])),('pressure_constant_killing',R(3,4)*s.eye(2)),('pressure_zero_J',s.zeros(2)),('expanded_three_states',base),('expanded_stronger_J',R(7,5)*base)]
# Symbolic two-point Holder/Young exponents: actual inequalities separately Arb checked.
p=s.symbols('p',positive=True)
a=2*(p-1)/p
ck(s.simplify(a*p/2+(1-a)*p-1)==0)
ck(s.simplify(a*p/2-(p-1))==0)
eta=F(1,8);models=[]
for name,J in cases:
 n=J.rows;one=s.ones(n,1);Q=s.ones(n,n)/n;H=(s.eye(n)+Q)/2;P=J*H;A=H*J.T;e=one-P*one
 b0=max(J.T*one);K=1
 while b0**K>R(1,16):K+=1
 aa=F(1,16*K);ck(b0**K<=R(1,16));ck(K==1 or b0**(K-1)>R(1,16))
 chosen=arb(2).log()/ar(16*K).log();ck(chosen>0);ck(chosen<=1)
 results=[]
 for pname,delta in [('p3/2',ar(F(1,2))),('p5/4',ar(F(1,4))),('p_chosen_from_K',chosen)]:
  pp=1+delta;factor=(-ar(aa).log()*delta).exp()
  if pname=='p_chosen_from_K':eqzero(factor-2)
  q=one;Ap=arb(0);energy=arb(0);stop=F(0);step=[]
  for j in range(K):
   h=J.T*q;qn=A*q
   hp=[pw(z,pp) for z in h];u=[pw(z,pp/2) for z in h]
   qpow=[pw(z,pp) for z in q];qnpow=[pw(z,pp) for z in qn]
   Hhp=mv(H,hp);Hu=mv(H,u)
   const_h=len(set(h))==1
   for k in range(n):
    # H(h^p)-(Hh)^p >= delta[H(h^p)-(H(h^(p/2)))^2].
    nonneg(Hhp[k]-qnpow[k]-delta*(Hhp[k]-Hu[k]*Hu[k]),equal=const_h)
   umean=avg(u);low=[z-umean for z in u];low_energy=ar(F(3,4))*sq(low)
   eqzero(avg(hp)-sq(Hu)-low_energy)
   payment=avg([ar(e[k])*qpow[k] for k in range(n)])
   dec=avg(qpow)-avg(qnpow)
   nonneg(dec-payment-delta*low_energy,equal=all(z==0 for z in q) or name=='pressure_zero_J')
   Ap+=payment;energy+=low_energy
   dd=q-qn;stop+=F(sum(dd),n)
   ck(all(z>=0 for z in dd));ck(F((q.T*e)[0],n)==F(sum(dd),n))
   step.append(dict(j=j,partial_qp_stop=str(Ap),partial_low_energy=str(energy),actual_stop_payment=str(F(sum(dd),n)),joint_increment=str(payment+delta*low_energy)))
   q=qn
  qNpow=avg([pw(z,pp) for z in q]);tail_stop=F(sum(q),n)
  ck(tail_stop<=eta/2);ck(stop+tail_stop==1)
  joint=Ap+delta*energy
  nonneg(1-joint-qNpow,equal=name=='pressure_zero_J')
  Ap_upper=Ap+qNpow
  # Finite lower endpoint alone suffices for the recovery conclusion in these models.
  nonneg(factor*Ap+ar(eta)-1)
  if pname=='p_chosen_from_K':nonneg(2*Ap+ar(eta)-1)
  results.append(dict(p_label=pname,p=str(pp),delta=str(delta),a_inverse_delta=str(factor),p_stop_lower=str(Ap),p_stop_upper=str(Ap_upper),p_stop_tail_upper=str(qNpow),low_energy_partial=str(energy),low_energy_tail_upper=str(qNpow/delta),joint_partial=str(joint),joint_plus_remaining_Lp_bound=str(joint+qNpow),actual_stop_partial=str(stop),actual_stop_tail=str(tail_stop),recovery_RHS_using_Ap_lower=str(factor*Ap+ar(eta)),steps=step))
 models.append(dict(name=name,states=n,J=[[str(x) for x in row] for row in J.tolist()],H=[[str(x) for x in row] for row in H.tolist()],direction='P=JH,Pstar=HJ^T',e=exact(e),b0=str(b0),kappa='1',eta=str(eta),K=K,a=str(aa),V0='0: this abstract H has only eigenvalues 1 and 1/2',results=results))
# Separate scalar Holder and weighted Young pressure: zeros, constant, high concentration.
scalar=[]
for weights,values in [([F(1,3)]*3,[F(0),F(1),F(4)]),([F(1,2)]*2,[F(1),F(1)]),([F(99,100),F(1,100)],[F(0),F(100)])]:
 for pQ in (F(3,2),F(5,4)):
  dd=ar(pQ-1);pp=ar(pQ);B=sum((ar(w)*pw(v,pp) for w,v in zip(weights,values)),arb(0));C=sum((ar(w)*pw(v,pp/2) for w,v in zip(weights,values)),arb(0));C=C*C
  mean=sum(w*v for w,v in zip(weights,values));lhs=pw(mean,pp)
  interp=(B.log()*(1-dd)+C.log()*dd).exp()
  equal=len(set(values))==1
  nonneg(interp-lhs,equal or len(set(v for v in values if v>0))<=1);nonneg((1-dd)*B+dd*C-interp,equal)
  nonneg(B-lhs-dd*(B-C),equal)
  scalar.append(dict(weights=[str(x) for x in weights],values=[str(x) for x in values],p=str(pQ),Holder_gap=str(interp-lhs),Young_gap=str((1-dd)*B+dd*C-interp),Jensen_gap_after_delta=str(B-lhs-dd*(B-C))))
result=dict(scope='Finite abstract same-chain p-energy interface only. Q is not the original high/source projection; no native geometry/history proof.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=s.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r491_numeric.py',seconds=time.perf_counter()-start),checks=checks,models=5,model_p_cases=15,scalar_cases=6,formulas=dict(Holder='(Eh)^p <= (Eh^p)^(2-p) (E h^(p/2))^(2(p-1)) <= (2-p)Eh^p+(p-1)(E h^(p/2))^2',pointwise='Hh^p-(Hh)^p >= delta[Hh^p-(Hu)^2],u=h^(p/2)',joint='sum <q_j^p,e> + delta sum (.75||(I-Q)(J^Tq_j)^(p/2)||^2) <= R=1',recovery='q_j<=b0^j, b0^K<=eta/2,a=eta/(2K); R<=a^(-delta)A_p+eta R; chosen delta=log2/log(2K/eta) gives factor2',tail='Remaining joint energy bounded by <q_K^p,1>; actual stop tail=<q_K,1>'),scalar_checks=scalar,records=models,decision='For the fixed five abstract models, same-chain p-stop and p-Jensen dissipation pass strict interval checks. Choosing p towards1 gives factor2 in stopping recovery; low-energy coefficient is delta=O(1/log K), not a uniform positive constant. Original geometric spectral interface and global cost transfer remain separate proof obligations.',errors='384-bit Arb enclosures for fractional powers and logarithms; rational q chain, K and stop tails exact. Finite sums plus rigorously bounded tails, no floating solver/Monte Carlo. Equality cases identified structurally and finite intervals checked before zero residuals.')
(ROOT/'r491_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;5 models x3 p choices,6 scalar cases;strict same-chain tail certificates')
