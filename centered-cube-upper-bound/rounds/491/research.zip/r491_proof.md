# R491：同一自然链的 p-Jensen 停止账与有限时域近线性恢复

本稿保留 R486 的实际自然参考、成功门和刷新核，不改成旧父链。结论是一个完整恢复工具：以对数级 (1/(p-1)) 代价把 (p) 次停止账恢复为线性总停止质量；尚未提供来源根阶价。

## 1. 参考、不可跨带与终端常数

令 \(\mathsf M\) 为 R486 自然参考，\(R=\mathsf M(1)<\infty\)，\(\mathcal P=JH\)，其中 \(H=H^*\)、\(H1=1\)、\(\mathsf MH=\mathsf M\)，且
\[
 \mathsf MJ\le\mathsf M,\qquad
 \mathsf M_\omega J\le b_0\mathsf M_\omega,
 \quad \mathsf M_\omega=m_A^{-1}\mathsf M,
 \quad b_0=2rS/T\in(0,1).
\]
\(H\) 同时保持 \(\mathsf M_\omega\)。定义
\[
 q_j=(\mathcal P^*)^j1,\quad h_j=J^*q_j,\quad
 e=1-\mathcal P1=1-J1.
\]
由正性及 \(\mathcal P^*1\le1\)，\(0\le q_{j+1}\le q_j\le1\)。所有伴随均相对同一 \(\mathsf M\)。

**原文来源和常数量词。** `/tmp/r479_main.md` §1（当前第13–21行）将所有父分为互不交质量带，对数宽 \(L_b\le L\)，并在带内附 uniform mark 处理质量原子；§4、式(4)后（第98行）明确选择 \(L=\sqrt n\)。`/tmp/r486_main.md`“自然参考、最大父列与新分析链”（第13–35行）规定 \(J\) 仅输出原带内最大父，\(H\) 保父及 mark。故每带 \(E_b\) 对 \(\mathcal P\) 不变，两条参考列界可分别限制到该带。

对正参考质量的带令 \(R_b=\mathsf M(E_b)\)，\(m_{b,-},m_{b,+}\) 为该带父质量的本质下、上界，\(\kappa_b=m_{b,+}/m_{b,-}\)。于是
\[
 \log\kappa_b\le L_b\le L,
 \qquad q_j1_{E_b}\le
 \min\{1,\kappa_b b_0^j\}1_{E_b}. \tag{1}
\]
证明是 \(\mathsf M_b\le m_{b,+}\mathsf M_{\omega,b}\)，迭代后再用
\(\mathsf M_{\omega,b}\le\mathsf M_b/m_{b,-}\)。闭端点、质量原子及成功正限制均不改变这条测度支配。

若只用 R486 全场粗常数，则 \(\log(m_+/m_-)=\log r+n\log(b/a)\)；它不是 \(\sqrt n\)。本稿的 \(\sqrt n\) 来自保留原不可跨带，不能将原带遗忘后仍声称该常数。定义
\[
 R_K:=\int q_Kd\mathsf M
 \le\sum_b\min(1,\kappa_b b_0^K)R_b
 \le e^L b_0^K R. \tag{2}
\]
因此 \(R_K\to0\)，且真实停止恒等式为
\[
 R=\sum_{j\ge0}\int q_je\,d\mathsf M. \tag{3}
\]
零质量带不参加求和；\(R=0\) 时所有结论为零。若 \(b_0=0\)，则 \(J=0\) 在参考测度意义下成立，\(e=1,q_1=0\)，恢复无需截断论证。

## 2. p-Jensen 与两笔不同的凸性缺陷

对任意 \(p>1\) 和非负 \(v\in L^p(\mathsf M)\)，伴随次概率核给
\[
 (J^*v)^p\le(J^*1)^{p-1}J^*(v^p)\le J^*(v^p).
\]
在 \(J^*1=0\) 的纤维两边都为零。刷新核 \(H\) 为保持参考的 Markov 核，所以 \((Hh)^p\le H(h^p)\)。由此有准确非负分解
\[
\begin{aligned}
 \|q_j\|_p^p-\|q_{j+1}\|_p^p
 ={}&\int q_j^p e\,d\mathsf M+\mathcal D_{J,p}(q_j)
       +\mathcal D_{H,p}(h_j),\\
 \mathcal D_{J,p}(v)={}&\int[J^*(v^p)-(J^*v)^p]d\mathsf M\ge0,\\
 \mathcal D_{H,p}(h)={}&\int[H(h^p)-(Hh)^p]d\mathsf M\ge0.
\end{aligned} \tag{4}
\]
故对任意有限 \(K\)，
\[
 A_{p,K}:=\sum_{j<K}\int q_j^p e\,d\mathsf M
 \le R-\|q_K\|_p^p,
 \qquad A_p:=\sum_{j\ge0}\int q_j^p e\,d\mathsf M\le R. \tag{5}
\]
两类凸性缺陷亦可保留在(5)左边。因为 \(q_K^p\le q_K\) 及(2)，无限和时(4)三项之和恰为 \(R\)。这是同一实际链的账，不是把 \(q_je\) 误换成 \(q_j^pe\)，也未宣称 \(p\ne2\) 时仍有 R490 的 \(3/4\) 正交平方系数。

## 3. 有限时域恢复：不需要点态搬运

固定整数 \(K\ge1\) 和 \(a\in(0,1)\)。在 \(q_j\ge a\) 上有
\(q_j\le a^{1-p}q_j^p\)，而在 \(q_j<a\) 上有 \(q_je\le a e\)。将(3)只在前 \(K\) 代这样分割，得到
\[
 \boxed{R\le a^{1-p}A_{p,K}+Ka\,\mathsf M(e)+R_K
 \le a^{1-p}A_{p,K}+(Ka+e^Lb_0^K)R.} \tag{6}
\]
没有移动任何源标签、阶段或配置。低 \(q_j\) 的小量来自有限代数 \(K\)，尾项来自已证双参考支配，两者不能互相代替。可逐带选择 \(K_b,a_b\)，相应误差是
\(\sum_b K_ba_b\mathsf M_b(e)+\sum_b R_{b,K_b}\)；统一选择时不额外乘质量带数。

给定 \(0<\varepsilon<1\)、恢复常数 \(C>1\)，令
\[
 \omega=\log(1/b_0)>0,\quad
 K=\max\left\{1,\left\lceil\frac{L+\log(2/\varepsilon)}{\omega}\right\rceil\right\},
 \quad a=\frac{\varepsilon}{2K},\quad
 p=1+\frac{\log C}{\log(2K/\varepsilon)}. \tag{7}
\]
则 \(Ka=\varepsilon/2\)，\(e^Lb_0^K\le\varepsilon/2\)，且 \(a^{1-p}=C\)，所以
\[
 \boxed{\frac{1-\varepsilon}{C}R\le A_{p,K}\le A_p\le R.} \tag{8}
\]
若后续方法需要 \(1<p\le2\)，把(7)中的 \(p-1\) 改为
\(\min\{1,\log C/\log(2K/\varepsilon)\}\)，恢复因子只会减小，(8)不变。

固定 \(\varepsilon,C,r,S,\tau,\delta_{\rm success}\) 时，原 \(T=1024rS^2/(\tau\delta_{\rm success})\) 给维数无关 \(b_0<1\)；采用原 \(L=\sqrt n\) 得 \(K=O(\sqrt n)\)，因而
\[
 \frac1{p-1}=O(\log(n+2)),
\]
而不是必须取 \(p-1\asymp1/\sqrt n\)。若参数随维数变化，应保留(7)的 \(\omega\) 精确依赖，不默认这条渐近阶数。这里 \(\delta_{\rm success}\) 是原成功参数，不是 \(p-1\)。

## 4. 对母账的效力与限制

若在同一实际链证明
\(A_{p,K}\le \eta X+B(n,p)W\)，则(8)给
\[
 R\le\frac C{1-\varepsilon}\eta X+
       \frac C{1-\varepsilon}B(n,p)W. \tag{9}
\]
这是下一步几何配对可直接调用的完整恢复。若几何常数仅含 \((p-1)^{-m}\)，本工具只增加 \(\log^m(n+2)\)；但本稿**没有**证明这样的几何界，也不能从 \(A_p\le R\) 倒推出来源价。

(4)需要付的是 \(p\)-凸性缺陷的几何配对；R490 的正交 \(L^2\) 预算不能未经证明迁移成这个配对。原全部成功门仍在 \(J\)，原停止原因 \(e=\sum_a e_a\) 亦可在(4)–(6)逐项保留。新分析链重采当前父的记录，不声称旧父历史在新父继续；未使用旧 \(K\) 的行价或跨轮累计价。

## 5. 本机精确复现

下列标准库脚本使用两个非对称、行列均次概率的有限核，验证 \(p=2,3\) 的 Jensen 方向、停止望远镜及有限时域恢复。有限矩阵只核代数，不是原生中心/配置历史实例；任意实数 \(p>1\) 与(7)由上述解析证明。

```python
from fractions import Fraction as F

checks = 0
def check(v):
    global checks
    assert v
    checks += 1

def adj(P, q):
    return [sum(P[i][j]*q[i] for i in range(len(q)))
            for j in range(len(q))]

models = [
    [[F(1,3), F(1,4)], [F(1,5), F(1,2)]],
    [[F(1,4), F(1,6), F(0)],
     [F(1,5), F(1,3), F(1,7)],
     [F(0), F(1,8), F(2,5)]]
]
for P in models:
    n = len(P)
    e = [1-sum(row) for row in P]
    check(all(x >= 0 for x in e))
    check(all(sum(P[i][j] for i in range(n)) <= 1 for j in range(n)))
    for p in (2, 3):
        q = [F(1)]*n
        lin = F(0)
        power = F(0)
        K, a = 7, F(1,20)
        for j in range(K):
            nxt = adj(P, q)
            lifted = adj(P, [x**p for x in q])
            check(all(nxt[i]**p <= lifted[i] for i in range(n)))
            stop = sum(q[i]**p*e[i] for i in range(n))
            check(sum(x**p for x in q)-sum(x**p for x in nxt) >= stop)
            check(all(0 <= nxt[i] <= q[i] <= 1 for i in range(n)))
            lin += sum(q[i]*e[i] for i in range(n))
            power += stop
            q = nxt
        check(lin+sum(q) == n)
        check(power <= n-sum(x**p for x in q))
        check(F(n) <= a**(1-p)*power+K*a*sum(e)+sum(q))
print(f'{checks} exact Fraction assertions PASS; finite-kernel algebra only.')
```

实际执行：从本文唯一 Python fence 提取脚本，在新临时目录用指定本机 Python `-I` 隔离运行；stdout 为 `100 exact Fraction assertions PASS; finite-kernel algebra only.`。未运行或宣称原生几何数值实例。
