# R491 独立终审

FINAL PASS（限定范围）。认证同一实际链的非二次联合耗散、有限时域近线性停止恢复，以及带符号 head 分解和合法非线性来源测试；不认证 A_p 的根阶来源价格、完整停止付款或一般上界闭合。

独立 PRE 在作者阅读前形成并保留。逐式核对主稿一般证明：非负到达密度的 J* 次概率 Jensen 保 ∫q_j^p e；H 的 Hölder 插值与加权 Young 在 1<p≤2 给 (p−1) 倍原正交损失，来源零阶与 low-touch 同账而未重复扣费。零列取零，p=2 直接处理等式，有限 N 尾项 R−∫q_N^p 保留。该结论不是从有限数值外推。

原质量带对 J/H 不变，双参考可逐带限制，故 κ_band≤exp(√n) 合法。主稿统一 η≤1/2、δ=log2/log(2K/η)≤1/2，恢复因子准确为2；前 K 代小 q 及从 K 起的全部真实停止分别计 ηR/2，未把入列缺陷搬作停止位置，亦未逐带增加费用。固定原参数下 δ⁻¹=O(log(n+2))；参数随维数变化时须保精确 K 依赖。近线性恢复确实减少固定平方与真实停止的转换障碍，但 A_p≤R 本身仍无 W 价格。

几何附件的 q_(j+1)^p head 恒等式及 b=Qe0 加权正交分解正确，父基线 B_N、高类 A_N^hi 和负 Jensen 信用 −J_N^head 均保留。high-empty 范围对 h_j 取幂后仍成立；它没有变成父均值付款。来源投影测试有真实平方来源价，配对使用同一 powered 输入，然而未证明其从下控制完整 head 或其余首失败门。原初始、最终停止、旧母账倍率及全尺度费用均保留。

实际独立隔离重放：geometry 16 个接口例（每例3条有理断言）、proof 100 项有理断言、numeric 1770 项精确／Arb 断言通过，stdout 与冻结 replay 一致。numeric JSON 仅删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `f9f1c7a27ab8c590cae0d5357fc84e3733fbba5ed736edef7ee13cee4d210a93`。五个抽象模型的15个 p 参数例及6个标量例不认证原来源/高类投影、真实中心或 history；结构等号与严格区间证据范围已区分。

## 冻结输入 SHA256

- `r491_main.md`: `87d415ec8757de02a4679eba8f480df51cab0108e67794eb4ef4e8ad209dfdd6`
- `r491_geometry.md`: `731e4e6dd29e996ee56cba66e86fe2d974e16376abacbca6c2d506c4f1e3ffa6`
- `r491_proof.md`: `3c4af2465cab34cc7c7f60174a5ebd6eddfaae3877182be8e5a19f4f760d9993`
- `r491_numeric.md`: `cb739c0e65c5610e3f8099d7a2aa0b8d9640857d3c6061bb3cfb6e389e0fb1cc`
- `r491_numeric.py`: `57e442478262a883c313ec1f9ba5676cdfa9105a428303698cb2471e3926ed29`
- `r491_numeric.json`: `bf933c5eeee903b8c5d532b62b5e060e300404af0b269585f367b6c69c174ff3`
- `r491_replay.json`: `33905930ec734a33f9ea4984ca10f17ea9a711f73a829ed29a0299cd14faf62a`
