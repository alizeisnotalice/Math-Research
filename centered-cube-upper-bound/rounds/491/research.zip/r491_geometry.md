# R491：分数到达权下的真实停止头部与父均值

本附件沿同一自然参考 \(\mathsf M\)、实际 \(P=JH\) 和原成功门，检查分数幂能否把完整停止接到已有来源测试。不改变父、质量带、旧记录或 raw 配置；不将旧独立刷新链的费用迁移到这里。结论是：分数幂保留实际 high-empty 范围，但还没有支付下面明确的带符号父基线。本轮完整近线性恢复及联合耗散由主稿给出，此附件不重复将其算作几何付款。

## 1. 同一停止项与非线性范围

记 \(Q\) 为父及 mark 条件均值，\(Z\) 为父、mark、来源条件均值，\(\Pi\) 为再保留高捕获配置的条件均值。三者为嵌套正交投影。令
\[
q_j=(P^*)^j1,\quad h_j=J^*q_j,\quad
u_j=h_j^{p/2},\quad 1<p\le2,\quad \varepsilon_p=p-1.
\]
这里 \(\nu_j\) 是函数，不是原父测度 \(\nu\)。由 \(0\le h_j\le1\)，各函数可积。实际最大父 raw-row 门保证 \(h_j\)，从而 \(\nu_j\)，在高捕获配置非空处为零；取幂不会删除任何历史标签。

前两个互斥首失败之和为
\[
e_0(A,s_A,x)=1_{t(A)<\tau}
 +1_{t(A)\ge\tau}1_{v_A(x,s_A)<\kappa T},
\qquad b=Qe_0.
\tag{1}
\]
它独立于配置，故 \(He_0=b\)。此处 \(\kappa\) 是原 rank 门参数，不是质量跨度。每条实际路径始终在同一原质量带内；该带的质量上下端比至多 \(e^{\sqrt n}\)。这仅用于主稿的近线性恢复，不把每代初始低秩价格重新收费。

## 2. 保留 Jensen 信用的精确头部账

定义逐点非负 Jensen 缺陷
\[
\mathcal J_j=H(h_j^p)-(Hh_j)^p\ge0.
\]
自伴性及 \(q_{j+1}=Hh_j\) 给精确式
\[
\langle q_{j+1}^p,e_0\rangle
=\langle b,\nu_j^2\rangle-\langle e_0,\mathcal J_j\rangle.
\tag{2}
\]
因 \(b\) 仅依父及 mark，加权正交分解合法。设
\[
\begin{aligned}
 B_N&=\sum_{j=0}^{N-2}\langle b,(Q\nu_j)^2\rangle,\\
 L_N&=\sum_{j=0}^{N-2}\langle b,|(I-\Pi)\nu_j|^2\rangle,\\
 Z_N&=\sum_{j=0}^{N-2}\langle b,|(Z-Q)\nu_j|^2\rangle,\\
 A_N^{\rm hi}&=\sum_{j=0}^{N-2}\langle b,|(\Pi-Z)\nu_j|^2\rangle,\\
 J_N^{\rm head}&=\sum_{j=0}^{N-2}\langle e_0,\mathcal J_j\rangle.
\end{aligned}
\]
则空和取零时，对所有有限 \(N\ge1\)，
\[
\boxed{\sum_{j<N}\langle q_j^p,e_0\rangle
=\langle1,e_0\rangle+B_N+L_N+Z_N+A_N^{\rm hi}-J_N^{\rm head}.}
\tag{3}
\]
这保留了实际停止的负 Jensen 信用，没有假定它已经抵消父均值。只有 \(j=0\) 一项直接满足
\[
\langle1,e_0\rangle\le\tau X+\kappa T N_{\rm band}W.
\tag{4}
\]

主稿的非二次耗散给
\[
\sum_j\int\mathcal J_j\,d\mathsf M
\ge\varepsilon_p\sum_j\left[
\tfrac34\|(I-\Pi)\nu_j\|_2^2+
\|(Z-Q)\nu_j\|_2^2\right],
\]
因此 \(L_N+Z_N\le4R/(3\varepsilon_p)\)。这是 \(R\) 价，不是来源价，也不是可直接吸收的小系数。

高类项同样不能省略。令 \(d=8rS/T\)。对固定父、mark、来源，高类 PPP 的空概率 \(p_0\ge e^{-d}\)。写 \(a=\mathbb E_{\rm low}[\nu_j\mid F_{\rm hi}=\varnothing]\)，则
\[
\mathbb E| (\Pi-Z)\nu_j|^2=a^2(p_0-p_0^2)
\le(1-e^{-d})\mathbb E\nu_j^2.
\]
乘 \(b\) 后积分仍成立。结合正交分解，得到合法但未闭合的估计
\[
\sum_{j<N}\langle q_j^p,e_0\rangle
\le\langle1,e_0\rangle+
 e^d\left(B_N+\frac{4R}{3\varepsilon_p}\right).
\tag{5}
\]
其中 \(B_N\) 完整保留；不能声称所有波动均被低类/来源耗散无代价控制。

## 3. 几何测试能控制什么，唯一未接通处是什么

R488 给来源中心化径向函数 \(g\)，满足 \(Zg=g\)、\(Qg=0\)、\(\|g\|_2^2\le SC_nW\)。令 \(d_j=q_j-q_{j+1}\ge0\)，并取明确测试
\[
\phi_j=(Z-Q)(\sqrt{d_j}\,g).
\]
由于 \(\sum_jd_j=1\)，
\[
\sum_j\|\phi_j\|_2^2\le SC_nW,\qquad
\left|\sum_j\langle\phi_j,\nu_j\rangle\right|
\le\sqrt{SC_nWR/\varepsilon_p}
\le aR+\frac{SC_n}{4a\varepsilon_p}W.
\tag{6}
\]
这是实际非线性来源波动的合法有价配对；若 \(\varepsilon_p^{-1}=O(\log n)\)，其来源成本可接受。但 \(\phi_j\perp Q\nu_j\)，没有证明完整停止被该配对从下控制。

需要的几何比较必须保留式 (3) 中的**同一个带符号量**
\[
B_N+A_N^{\rm hi}-J_N^{\rm head},
\tag{7}
\]
并与低类/来源波动一起结算；单独要求 \(B_N\) 小可能过强，直接删负项又会损失潜在信用。当前实际质量匹配、high-empty 门和径向方差尚未给 (7) 的根阶来源价，亦未给完整其余首失败门的测试下界。因此 (6) 不构成停止恢复。此处是本次唯一未接通的几何步骤。

成功输出还满足 \(|F|\ge\lceil\kappa/2\rceil-1\)：原 raw 数至少 \(v_A/(2T)\)，输出删去最大点后保留全部 lower 点。它仅在新来源秩远小于 \(\kappa T\) 时给自然 Poisson 稀有性；不能用该子区替换式 (1) 的完整低秩区，尤其不能略去 \(v_B\) 接近 \(\kappa T\) 的部分。本稿不再新增停止分支。

## 4. 实际本机核验

下列自含代码用指定 Python 环境实际运行，输出 `PASS 16 exact projection/high-empty interface cases; no native geometry claim`。它只验证带来源权的正交分解和 high-empty 系数；不是立方体/完整历史实验，也不验证未证式 (7)。

```python
from fractions import Fraction as F
from itertools import product
checks=0
for w,p0,p1,a in product([F(1,3),F(2,3)],
        [F(3,4),F(7,8)],[F(4,5),F(9,10)],[F(1,4),F(3,4)]):
    vals=[a,F(0),F(1)-a,F(0)]
    weights=[w*p0,w*(1-p0),(1-w)*p1,(1-w)*(1-p1)]
    src=[p0*a,p1*(1-a)]
    mean=sum(t*v for t,v in zip(weights,vals))
    norm=sum(t*v*v for t,v in zip(weights,vals))
    source=w*(src[0]-mean)**2+(1-w)*(src[1]-mean)**2
    high=norm-w*src[0]**2-(1-w)*src[1]**2
    assert norm==mean**2+source+high
    assert high <= (1-min(p0,p1))*norm
    assert norm <= (mean**2+source)/min(p0,p1)
    checks+=1
print(f'PASS {checks} exact projection/high-empty interface cases; '
      'no native geometry claim')
```
