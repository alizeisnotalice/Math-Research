"""Exact fixed-point R623 selector for rational folded coordinates; no batch runs."""
from bisect import bisect_left,bisect_right
from fractions import Fraction
from itertools import groupby
from math import prod

def menu(n):
    if n<1:raise ValueError('n must be positive')
    return sorted({(2**i)*(3**j) for j in range(n+1) for i in range(2*(n-j)+1)})

def ceil_r_power(d,n):
    # m >= (2*d)**n iff m >= this exact integer ceiling.
    x=(2*d)**n
    return -(-x.numerator//x.denominator)

def select(x, spacing=Fraction(21,20)):
    x=tuple(Fraction(y) for y in x);s=Fraction(spacing);n=len(x)
    if not n or s<=0 or any(y<0 or y>s/2 for y in x):raise ValueError('expected coordinates folded to [0,s/2]')
    M=menu(n); events=[]
    for axis,y in enumerate(x):
        for d in (y,s-y,s+y,2*s-y):events.append((d,axis))
    events.sort(); grouped=[(d,[i for _,i in g]) for d,g in groupby(events,key=lambda z:z[0])]
    counts=[0]*n; first=None;last=None
    for k,(d,axes) in enumerate(grouped):
        # Closed balls contain entries at equality; update all simultaneous events.
        for i in axes:counts[i]+=1
        C=prod(counts)
        if not C: continue
        lower=bisect_left(M,ceil_r_power(d,n))
        upper=bisect_right(M,C)
        if k+1<len(grouped):upper=min(upper,bisect_left(M,ceil_r_power(grouped[k+1][0],n)))
        if lower<upper:
            first=M[lower] if first is None else min(first,M[lower])
            last=M[upper-1] if last is None else max(last,M[upper-1])
    return first,last

def brute(x, spacing=Fraction(21,20)):
    x=tuple(Fraction(y) for y in x);s=Fraction(spacing);n=len(x)
    ds=[(y,s-y,s+y,2*s-y) for y in x];out=[]
    for m in menu(n):
        counts=[sum((2*d)**n<=m for d in row) for row in ds]
        if prod(counts)>=m:out.append(m)
    return (min(out),max(out)) if out else (None,None)

if __name__=='__main__':
    from random import Random
    rng=Random(623)
    for n in range(1,6):
        for k in range(200):
            x=[Fraction(rng.randrange(22),40) for _ in range(n)]
            assert select(x)==brute(x)
    # Exact simultaneous events, zero distance, and ties on 2r: 1D r=1/2, x=1/2.
    assert select([Fraction(1,2)])==brute([Fraction(1,2)])
    # Case where the minimum and maximum are different.
    examples=[(x,select(x)) for x in ([Fraction(0)],[Fraction(1,2)],[Fraction(0),Fraction(0)])]
    print('1,000 exact random small cases and ties pass;',examples)
