import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import qmc
import ccu_r623_numeric as old
S=21/20

def task(arg):
 n,rep,prior,deadline=arg;t=time.monotonic();cpu=time.process_time();logs,radii,labels=old.menu(n);rho=np.exp(logs);kap=(1-1/n)**n;hist=np.zeros((2,len(logs)));cone=np.zeros((2,2));hits=0;started=0;stages={};sample_max=np.zeros(2);sob=qmc.Sobol(d=n,scramble=True,seed=623100+n*10+rep)
 if prior:
  p=prior['continuation'];hist=np.array(p['hist']);cone=np.array(p['cone']);hits=p['hits'];started=p['started'];sample_max=np.array(p['sample_max']);stages=prior['stages'].copy();sob.fast_forward(started)
 while started<65536:
  if time.monotonic()>deadline:break
  data=sob.random(4096)*S
  for x in data:
   pair=old.selector(x,logs,radii)
   if pair is None:continue
   hits+=1; fold=np.minimum(x,S-x);s4=2-float(np.maximum(.1-fold,0).sum())/n
   for p,k in enumerate(pair):
    hist[p,k]+=1;sample_max[p]=max(sample_max[p],radii[k]);ratio=radii[k]/2;cone[p,0]+=kap*ratio**n
    if p==1:cone[p,1]+=kap*min(1.,radii[k]/s4)**n
  started+=4096
  if started in (4096,65536):
   qq=np.cumsum(hist*rho[None,:],axis=1)/rho[None,:]*S**n/started;out=[]
   for p in range(2):
    opt=int(np.argmax(qq[p]));out.append({'policy':'r_min' if p==0 else 'r_max','cone_lower':float(cone[p,0]*S**n/started),'cone_upper_S4':None if p==0 else float(cone[p,1]*S**n/started),'q_T_best':float(qq[p,opt]),'T_best':float(radii[opt]),'T_best_menu':[int(z) for z in labels[opt]],'q_T_at_half':float(qq[p,0]),'sample_radius_max':float(sample_max[p]),'hit_at_radius_two':int(hist[p,-1])})
   stages[str(int(math.log2(started)))]={'N':started,'event_hits':hits,'policies':out}
 return {'n':n,'scramble':rep,'seed':623100+n*10+rep,'status':'complete' if started==65536 else 'partial_deadline','stages':stages,'continuation':{'hist':hist.tolist(),'cone':cone.tolist(),'hits':hits,'started':started,'sample_max':sample_max.tolist()},'D4_theory_probability':(17/21)**n,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','full'),required=True);p.add_argument('--workers',type=int,default=1);p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--reference',type=Path,default=Path(__file__).with_name('ccu_r623_numeric.json'));a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);path=a.output_dir/'ccu_r623_cone.json';md=a.output_dir/'ccu_r623_cone.md';idx=a.output_dir/'ccu_r623_cone_index.json';oldpath=a.reference;out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'selector_sha256':hashlib.sha256(Path(old.__file__).read_bytes()).hexdigest(),'old_H_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':a.workers,'phase':a.phase,'results':[],'scope':'finite paired Sobol estimates; T maximum chosen on the same samples, not a certified bound or out-of-sample estimate'}
 prior=json.loads(path.read_text()) if a.phase=='full' and path.exists() else None
 if prior:out['pilot_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();out['pilot_script_sha256']=prior['script_sha256']
 start=time.monotonic();deadline=start+(55 if a.phase=='full' else .001);tasks=[(7,i,None,start+2) for i in (0,1)] if a.phase=='pilot' else [(n,i,next((q for q in prior['results'] if q['n']==n and q['scramble']==i),None) if prior else None,deadline) for n in (7,12,24,48,96) for i in (0,1)]
 def save():
  out['wall_seconds']=time.monotonic()-start;path.write_text(json.dumps(out));L=['# R623 cone and single-threshold diagnostics','','Uses the exact same Sobol seeds and nested prefixes as the old H probe; phase/H is not recomputed. Cone lower is κ∫E(r/2)^n; r_max cone upper uses S4. q_T is the best of individual shared constant-radius certificates, with T selected on the same samples: no summation across thresholds. These are floating estimates, not certified continuous integrals.','','| n | scramble | N | policy | cone lower | S4 cone upper | sampled best q_T | T | q_{1/2} | radius-two hits |','|---:|---:|---:|:---|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda z:(z['n'],z['scramble'])):
   for stage in r['stages'].values():
    for q in stage['policies']:L.append('| %d | %d | %d | %s | %.8g | %s | %.8g | %.8g | %.8g | %d |'%(r['n'],r['scramble'],stage['N'],q['policy'],q['cone_lower'],str(q['cone_upper_S4']),q['q_T_best'],q['T_best'],q['q_T_at_half'],q['hit_at_radius_two']))
  L+=['','The exact r_min certificate at T=1/2 has value 1; its sample estimate is a sanity check. D4 has exact periodic volume fraction (17/21)^n; very rare radius-two seeds can be missed. Threshold search and two-scramble differences should not be interpreted as rigorous uncertainty bounds.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,t) for t in tasks]):
   r=f.result();out['results'].append(r);save();print('done',r['n'],r['scramble'],r['status'],r['continuation']['started'],flush=True)
 save();idx.write_text(json.dumps({'phase':a.phase,'completed':len(out['results']),'full_prefix_cases':sum(q['status']=='complete' for q in out['results']),'wall_seconds':out['wall_seconds'],'workers':a.workers,'cpu_seconds':sum(q['cpu_seconds'] for q in out['results']),'max_worker_rss_bytes':max(q['peak_rss_bytes_macos'] for q in out['results']),'command':out['command'],'script_sha256':out['script_sha256'],'selector_sha256':out['selector_sha256'],'old_H_sha256':out['old_H_sha256']},indent=2))
if __name__=='__main__':main()
