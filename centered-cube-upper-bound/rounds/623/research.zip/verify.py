"""Saved evidence checks and a bounded independent rational/float selector comparison."""
import argparse, hashlib, importlib.util, json, math, random, sys, time
from fractions import Fraction as F
from pathlib import Path

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).parent)
    ap.add_argument('--selector-check',action='store_true');ap.add_argument('--receipt',type=Path)
    args=ap.parse_args();p=args.root;t=time.perf_counter()
    data=json.loads((p/'ccu_r623_numeric.json').read_text())
    cone=json.loads((p/'ccu_r623_cone.json').read_text())
    keys={(n,r) for n in (7,12,24,48,96) for r in (0,1)}
    assert len(data['results'])==len(cone['results'])==10
    assert {(v['n'],v['scramble']) for v in data['results']}==keys
    assert {(v['n'],v['scramble']) for v in cone['results']}==keys
    for v in cone['results']:
        a=next(q for q in data['results'] if (q['n'],q['scramble'])==(v['n'],v['scramble']))
        assert v['status']=='complete' and v['continuation']['started']==65536
        for stage,N in [('12',4096),('16',65536)]:
            assert v['stages'][stage]['N']==a['stages'][stage]['N']==N
            assert v['stages'][stage]['event_hits']==a['stages'][stage]['event_hits']
            assert 0<=a['stages'][stage]['event_hits']<=N
            assert abs(a['stages'][stage]['policies'][1]['H_over_E'][0]-1)<1e-9
        assert abs(sum(v['continuation']['hist'][0])-v['continuation']['hits'])<1e-7
        assert abs(sum(v['continuation']['hist'][1])-v['continuation']['hits'])<1e-7
    cert=json.loads((p/'ccu_r623_cone_certificate.json').read_text())
    assert [r['n'] for r in cert['results']]==[7,12,24,48,96]
    assert F(*map(int,cert['results'][-1]['upper_outward_18_decimal']))<F(139,10000)
    assert F(*map(int,cert['results'][-1]['B_outward_18_decimal']))<F(37983,1000000)
    small=json.loads((p/'ccu_r623_interval.json').read_text())
    assert [r['cases'] for r in small['rows']]==[32,128,512]
    constants=json.loads((p/'ccu_r623_topk_constants.json').read_text());assert len(constants['rows'])==9
    holdout=json.loads((p/'ccu_r623_holdout.json').read_text())
    assert holdout['input_sha256']==hashlib.sha256((p/'ccu_r623_cone.json').read_bytes()).hexdigest()
    assert holdout['selector_sha256']==hashlib.sha256((p/'ccu_r623_numeric.py').read_bytes()).hexdigest()
    assert holdout['script_sha256']==hashlib.sha256((p/'ccu_r623_holdout.py').read_bytes()).hexdigest()
    rows=holdout['results'];assert len(rows)==70
    assert {(v['n'],v['shard']) for v in rows}=={(n,j) for n in (7,12,24,48,96) for j in range(14)}
    assert len({v['seed'] for v in rows})==70
    for v in rows:
        assert v['status']=='complete' and v['N']==262144
        assert len(v['blocks'])==256 and sum(b['N'] for b in v['blocks'])==v['N']
        for key in ('sum_weight','sum_weight2'):
            assert math.isclose(sum(b[key] for b in v['blocks']),v[key],rel_tol=1e-12,abs_tol=1e-8)
        assert 0<=v['sum_weight2']<=v['sum_weight']+1e-8<=v['N']+1e-7
    for out in holdout['summary']:
        a=[v for v in rows if v['n']==out['n']];N=sum(v['N'] for v in a)
        w=sum(v['sum_weight'] for v in a);w2=sum(v['sum_weight2'] for v in a)
        assert math.isclose(out['q'],(21/20)**out['n']*w/N,rel_tol=1e-12)
        assert math.isclose(out['ess'],w*w/w2,rel_tol=1e-12)
    if (p/'MANIFEST.json').exists():
        for name,h in json.loads((p/'MANIFEST.json').read_text()).items():
            assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
    checked=0
    if args.selector_check:
        numerical=module(p/'ccu_r623_numeric.py','probe');exact=module(p/'ccu_r623_selector.py','exact')
        import numpy as np
        rng=random.Random(623777)
        for n in range(1,8):
            logs,radii,labels=numerical.menu(n)
            for _ in range(50):
                x=[F(21,20)*F(rng.randrange(1,9973),9973) for j in range(n)]
                folded=[min(z,F(21,20)-z) for z in x]
                truth=exact.brute(folded);pair=numerical.selector(np.array([float(z) for z in x]),logs,radii)
                got=(None,None) if pair is None else tuple(2**labels[i][0]*3**labels[i][1] for i in pair)
                assert got==truth,(n,x,got,truth)
                assert exact.select(folded)==truth
                checked+=1
    result={'paired_full_runs':10,'matched_nested_hit_counts':20,'rational_selector_cases_in_saved_receipt':672,
            'new_exact_vs_floating_cases':checked,'arb_constant_cases':9,
            'independent_holdout_shards':70,'independent_holdout_samples':sum(v['N'] for v in rows),
            'wall_seconds':time.perf_counter()-t,'python':sys.version,'interpreter':sys.executable,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'scope':'Record consistency and optional bounded point comparison; no certification of finite-phase suprema or large Sobol integrals.'}
    if args.receipt:args.receipt.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':main()
