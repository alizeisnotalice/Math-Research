# R623 reproducibility and evidence guide

## Environment

The recorded interpreter is the local math-tools environment:

- Python 3.12.14, macOS 27.2 arm64.
- Main Sobol diagnostics record NumPy 2.5.4 and SciPy 1.18.1.
- The finite Arb constant checks record `python_flint` 0.9.0 at 256-bit precision.
- Commands below are the commands recorded in the JSON receipts. `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1` was used for the interval and cone-certificate runs.

No command was run while preparing this archival guide.

## Recorded commands and source identity

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r623_numeric.py --phase full --workers 10
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r623_interval.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r623_cone_certificate.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r623_topk_constants.py
```

The original execution paths were under `/tmp`; archived counterparts are in this directory. The numeric run is recorded with SHA-256 `f868cacdaf9746bd577de0395e53e1cd49196d8657be92178f1ccaf508df7bc7`. The interval and cone-certificate archived scripts were changed only to accept a portable output path and then rerun; their pre-archive execution hashes are respectively `c989a4b96b2e0be0775d0228aecc751941fa2dbce4d8ccaafcd7ce7b0f871015` and `ad5f3c9448b5209ade5d64aea288b2f16a14dfecca22a4f161da11d606ffdd2a`. The archived cone diagnostic script has a reference-data path change; its task AST is recorded identical, but its full batch was not rerun. Exact current/archive hashes and output-to-script links are listed in `SOURCES.json` and the per-run JSON receipts.

The saved receipts report: numeric phase 10 completed runs, 15.7400s wall and 89.6999s worker CPU sum; interval finite checks 0.3772s wall / 0.3681s CPU; cone certificate 0.5302s wall / 0.5210s CPU; Arb constant checks 0.00956s wall. These are historical receipt values, not timings measured by this archival step.

## Replay status

- The saved Sobol numeric output is an executed finite diagnostic receipt. It is not rerun during archiving. Finite phase samples, even with independent scrambles, do not certify a supremum or a general theorem.
- The interval script's portable archive version was rerun as recorded; its checks are finite exact-rational tests (including the stated small dimensions/caps), not a high-dimensional exhaustive computation.
- The strict cone-certificate script's portable archive version was rerun as recorded. It evaluates the stated finite list of dimensions using exact rational arithmetic and outward rounding. Its conclusion is limited to the fixed periodic point-source model, fixed source/maximum-selector construction, and untrimmed balanced cone described in the certificate.
- The archived `ccu_r623_cone.py` was not rerun as a full batch after its reference-path adjustment. Do not treat the AST/path portability note as a new execution.
- `ROOT_CHECK.json` records a consistency/optional bounded-point check, including comparison of 350 rational centers for dimensions 1–7 and nine Arb constant cases. It explicitly does not certify finite-phase suprema or large Sobol integrals.
- `ccu_r623_topk_constants.py` records nine finite Arb interval checks of the exact constant formulas. This is a numerical interval cross-check; the general short inequalities are analytic arguments described in the research notes, not established by those nine evaluations alone.

## Evidence levels and limits

1. **Floating-point diagnostics:** Sobol estimates, selector probes, and same-sample maxima are exploratory numerical evidence only. They do not prove a supremum bound, a packing certificate, or an all-input statement.
2. **Exact rational / outward-rounded finite certificate:** the cone certificate rigorously bounds the specified finite periodic model for dimensions 7, 12, 24, 48, and 96, under its stated selector and geometry. Its rational arithmetic does not extend the result to arbitrary finite source families or general (L^1) input.
3. **Arb intervals:** the saved 256-bit Arb intervals enclose the listed finite constants. They check formulas at listed parameter values and are not by themselves a proof of the universal inequalities.
4. **General proof status:** consult `REPORT.tex` and the independent review `AUDIT.md` for the exact proven lemmas and open bridge. In particular, the general exchange/repair condition and a general root-order payment remain unproved there. The fixed periodic certificate cannot close that gap.
5. **Inherited R006 values:** any cited old seven-dimensional R006 values are inherited from their referenced source record and were not recomputed in this R623 package. See `SOURCES.json` for its hash.

## Independent holdout, actual local load, and replay

The threshold was selected from the two old training histograms, frozen once, then evaluated on new independent Sobol scrambles. Final thresholds for n=7,12,24,48,96 are 2,1.5,0.5,0.5,0.5. Each of 14 scrambles per dimension has 262144 points: 18350080 points in total. The initial 8192-point prefixes motivated continuation (n96 ESS was only 1035); they were not recomputed during continuation. The final n96 ESS is 33194. Empirical q values are approximately 0.606443,0.425606,0.356151,0.777181,0.978508. Scramble standard errors are descriptive, not rigorous confidence bounds, and no dimensional order is inferred.

`HOLDOUT_AUDIT.md` independently verifies the frozen thresholds, cumulative weights, and actual fast-forward continuation. `ccu_r623_holdout_pilot.json` is a reconstruction from retained prefix blocks and snapshots: the original pilot byte stream was overwritten before backup. Its recorded original hash does not make the reconstruction byte-identical. Do not claim original pilot CPU/memory records are independently preserved. The final receipt preserves the original prefix summary and prior script hash.

Production continuation ran 14 single-thread workers for 127.52 seconds, with 1317.72 worker CPU seconds. System CPU sampling during continuation averaged about 72.4% (unweighted sample mean) and peaked at 98.6%; tail imbalance reduced occupation after most tasks completed. The initial pilot also recorded 94.4% and 98.8% system samples. These are system-wide observations, not exclusive job CPU percentages. Live worker count includes idle workers. `WORKER_SNAPSHOT.json` independently records a peak-period process snapshot: all 14 workers at 97–100% of one core, summed CPU 1380.4%, summed RSS 1466128 KiB. No claim of continuous full occupancy is made. Next experiments should split expensive shards or schedule them first; no extra calculation was created merely to occupy idle cores.

From an extracted archive directory, using the existing local math interpreter as `PY`, one can run the following. These are portable replay instructions, not additional executed large batches:

```sh
PY=/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python
mkdir -p replay
"$PY" ccu_r623_holdout.py --input ccu_r623_cone.json --output-dir replay --workers 14 --samples-per-shard 8192
"$PY" ccu_r623_holdout.py --input ccu_r623_cone.json --output-dir replay --workers 14 --samples-per-shard 262144 --resume
"$PY" ccu_r623_interval.py --output replay/interval.json
"$PY" ccu_r623_cone_certificate.py --output replay/cone_certificate.json
"$PY" ccu_r623_topk_constants.py --output replay/constants.json
"$PY" verify.py --selector-check
```

The final root check actually ran: 350 independent rational-vs-floating selector cases, saved evidence consistency, 70 unique holdout shards, 256 blocks per shard, all cumulative sums and pooled estimates, input and executed-script hashes. It did not rerun the 18-million-point batch. The final interval and cone-certificate scripts had already been rerun after output-path portability edits. No MATLAB or solver experiment, and no PDF compilation, is claimed for this round.

The holdout `new_segment_top_one_percent_weight_share` concerns only the new 253952 points; the stored old-prefix statistic concerns 8192 points. Neither is the combined full-sample top-1% statistic. The resource log contains pilot and continuation records with elapsed-time clocks restarting; use the final JSON resource samples for continuation-only statistics.
