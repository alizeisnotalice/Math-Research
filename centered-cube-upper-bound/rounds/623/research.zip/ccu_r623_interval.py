import itertools,math,json,sys,time,platform,hashlib,resource
from fractions import Fraction as Q
from pathlib import Path
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r623_interval.json'));args=ap.parse_args()
start=time.perf_counter();cpu=time.process_time();s=Q(21,20)
def menu(n):return sorted({2**i*3**j for j in range(n+1) for i in range(2*(n-j)+1) if (i+1)//2+j<=n})
def dist(x):return (x,s-x,s+x,2*s-x)
def at_radius(m,d,n):return (2*d)**n<=m
def count(c,m,n):return sum(at_radius(m,d,n) for d in dist(c))
def direct(x,cap):
 n=len(x);return [m for m in menu(n) if m<=(2*cap)**n and math.prod(count(c,m,n) for c in x)>=m]
def event(x,cap):
 n=len(x);ends=sorted({d for c in x for d in dist(c) if d<=cap});ans=[]
 for idx,L in enumerate(ends):
  U=ends[idx+1] if idx+1<len(ends) else None
  prod=math.prod(sum(d<=L for d in dist(c)) for c in x)
  for m in menu(n):
   if (2*L)**n<=m and m<=min(prod,(2*cap)**n) and (U is None or m<(2*U)**n):ans.append(m)
 return sorted(set(ans))
# Independent check of c-category feasibility vs explicit vectors of lengths.
def capacity_check(n):
 checks=0
 for caps in itertools.product(range(1,5),repeat=n):
  realized={(sum(1 if v==2 else 2 if v==4 else 0 for v in ls),sum(v==3 for v in ls)) for ls in itertools.product(*(range(1,c+1) for c in caps))}
  for j in range(n+1):
   c2,c3,c4=(caps.count(k) for k in (2,3,4));imax=c2+c3+2*c4-min(j,c3)-2*max(0,j-c3)
   for i in range(2*n+1):
    assert ((i,j) in realized)==(j<=c3+c4 and i<=imax)
    checks+=1
 return checks
rows=[]
for n in (2,3,4):
 nchecks=capacity_check(n);num=ties=no=distinct=0
 for x in itertools.product((Q(0),Q(1,4),Q(1,2),Q(21,40)),repeat=n):
  for cap in (Q(2),Q(2,5)):
   a=direct(x,cap);b=event(x,cap);assert a==b
   if not a:no+=1
   else:
    distinct+=a[0]!=a[-1]
    if cap==2:
     m=a[-1];N=math.prod(count(c,m,n) for c in x);assert N==m
   if any((2*d)**n==m for c in x for d in dist(c) for m in menu(n)):ties+=1
   num+=1
 rows.append({'n':n,'cases':num,'capacity_predicate_checks':nchecks,'no_legal':no,'min_differs_max':distinct,'boundary_tie_cases':ties})
out={'rows':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'closed-radius finite tests; cap 2/5 only exercises no-legal logic; no large scan'}
args.output.write_text(json.dumps(out,indent=2)+'\n');print(rows);print('seconds',out['wall_seconds'],'sha',out['script_sha256'])
