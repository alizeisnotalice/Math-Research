# R623 全局majorant原row packing：独立关键审查

日期：2026-10-28。先独立核验父任务准确命题，再读 `/tmp/ccu_r623_bridge.md`；主作者稿尚待后续必要核验。只写本文件，不改repo、不启动Agent或重计算、不作反例扫描。实际数学工具仅核关键Jacobian与top-k归一代数。

## 1. 对象、可测性与零值

有限原open cubes B_j=B(y_j,r_j)、A_j=aB_j，按固定顺序取真实不交I_j，E=∪B_j，ρ(x)=(a+1)r_j于I_j。令F⊂E为固定Lebesgue可测集，α_i≥0、Σα_i=1、maxα_i<1；因此n≥2，κ=∏(1−α_i)>0。

定义在整个R^n上的

S(x)=[sup_(z∈F){ρ(z)−Σ_iα_i|x_i−z_i|}]_+。

F空时取S=0、所有权0。F非空时S有限、非负、全局weighted-Lipschitz且有界；在F上S≥ρ≥(a+1)min r_j>0，所以积分不在S=0处分母求值。F外零值不影响构造。允许α_i=0并不破坏load证明，但这样的cone可在相应方向无界，不能自动给有限halo体积。

原I_j及ρ应固定具体可测代表；pointwise supremum可因零测generator的增删而变化，不能无说明地视为a.e.等价类不变量。采用原有限row定义完全合法；如改essential supremum，须只要求majorize a.e.并保持相应证明，不得混用。

## 2. 全局map、完整inverse Jacobian与平均：通过

令Lα(v)=Σα_i|v_i|。对u∈(-1,1)^n，有Lα(u)<1。若F_u(x)=x+S(x)u的两个原像相同，则x−x′=(S(x′)−S(x))u及S的Lα-Lipschitz性迫使S(x)=S(x′)，故x=x′。对任意y，标量映射t↦S(y−tu)在[0,sup S]上是Lα(u)-contraction，给全局唯一inverse；相应差分估计也给inverse Lipschitz。只需open u cube，不能在critical边界u上无条件声称injective。

S a.e.可微且|∂_iS|≤α_i，完整rank-one determinant为

J_u(x)=det(I+u⊗∇S(x))=1+u·∇S(x)
       ≥1−Σ_iα_i|u_i|>0。

先换序再逐u全局换元，得到辅助cube load的a.e.表示

W_S(y)=2^(−n)∫_(−1,1)^n 1_F(F_u^(−1)(y))
                /[1+u·∇S(F_u^(−1)(y))]du。

梯度依赖inverse位置，**不能冻结**。统一下界却对全部inverse位置有效，故

W_S≤Cα=∫_[0,1]^n1/(Σ_iα_i t_i)dt。

weighted AM–GM给Σα_i t_i≥∏t_i^(α_i)，因此

Cα≤∏_i∫_0^1 t^(−α_i)dt=κ^(−1)。

maxα<1保证有限；随机独立坐标仅来自cube积分，不是对任意输入source的独立假设。uniform α_i=1/n时κ=(1−1/n)^n≥1/4（n≥2），方向正确。bridge(1)、(5)、(6)与此一致。

## 3. 原finite rows回填与source收费：通过

对x∈F∩I_j，y∈A_j时||y−x||∞<(a+1)r_j=ρ(x)≤S(x)。所以

ψ_j=κ∫_(F∩I_j)(2S(x))^(−n)dx

给原row load≤κW_S≤1 a.e.。有限原open-star load是非负open-indicator和、lower semicontinuous，故a.e.上界提升为每个source位置的上界。辅助halo积分同样l.s.c.，但原row版本已足够；原L1 source仅需a.e.约束。

原objective准确为

q=Σ_jψ_j(2ar_j)^n
 =κ/P∫_F(ρ/S)^n dx，P=((a+1)/a)^n，Q*≥q。

源收费只使用原共同bad-stars：若原ν(A_j)≥η|A_j|，则ηq≤||ν||1。辅助S-cubes从未被要求bad，也不能被当作原source的新合法动作。F与α可以依整个输入共同选择，但在检验原load时必须是一套固定全局对象，不能随source点另选。

q公式是实际可行packing，不只是模型负载。它仍未证明∫_F(ρ/S)^n占完整V的统一根阶份额；trim掉E\F及cone inflation均是未付代价。若另与旧packing混合，overload repair的全部原d_j成本须保留；两个各自可行pieces不能免费相加。

## 4. Whole-row halo修正及bridge的未付项

标准L∞ cone若penalty为L||·||∞，row k的generator遍历F∩I_k，正锥支撑外包是

B(y_k,r_k+ρ_k/L)，ρ_k=(a+1)r_k。

其相对原A_k的volume因子是[(a+1+L)/(aL)]^n。单个point seed的P L^(−n)不能当整row halo上界；不得遗漏Minkowski加I_k。root已接受该修正。

uniform固定α的单point cone是L1 ball，半径nρ；相对ρ-cube体积倍率n^n/n!。整row也必须加I_k，安全上包可用同norm半径ρ_k+r_k=(a+2)r_k。一般含零α方向的cone甚至没有有限全空间体积，不能套这个uniform公式。

bridge指出的主要缺口是Θ_S=V^(−1)∫(ρ/S)^n：局部gradient界不控制跨片jump，pointwise/radial growth探路不等于全局majorant inflation界。只给单生成点体积、逐大star独立领d_k、或将gradient固定后平均都不构成修复。bridge原措辞“已含P L^(−n)”只可读作已有损失提醒；严格whole-row upper须采用上式额外r_k因子。

## 5. 新top-k临界majorant：独立决定性核验通过

令2≤k≤n，d_k(v)为|v|最大k项的平均，取S_k=[sup_(z∈F)(ρ(z)−d_k(x−z))]_+。该S_k全局d_k-Lipschitz；a.e.梯度满足||∇S||_1≤1、||∇S||∞≤1/k，所以对全部inverse点

J≥1−d_k(u)>0，u∈(-1,1)^n。

同一全局inverse及换元论证给

C_(n,k)=E[k/(W_(1)+…+W_(k))]，

其中W_i为cube积分产生的独立Uniform[0,1]，W_(i)为最小顺序统计量。不能误写成固定k个坐标的和而丢掉n依赖。条件T=W_(k)时，下方k−1项等于T乘k−1个iid Uniform的排序，E1/T=n/(k−1)，故

C_(n,k)=kn/(k−1)·E[1/(1+Σ_(i=1)^(k−1)U_i)]。

再写该期望为∫_0^1(∫_0^1t^u du)^(k−1)dt；t^u作为u的凸函数低于端点弦，内积分≤(1+t)/2。因此

E[1/(1+ΣU)]≤2(1−2^(−k))/k，
C_(n,k)≤2n(1−2^(−k))/(k−1)≤2n/(k−1)。

由此原rows可取系数(k−1)/(2n)，objective至少

q_k≥(k−1)/(2nP)∫_F(ρ/S_k)^n dx。

k约√n给O(√n) load。k=1的平均常数发散，不能套本界；n=1须另走subcritical lemma。

## 6. top-k cone体积与仍未证的全族付款

点seed d_k ball半径R的体积准确为

2^n R^n·k^(k−1)/(k−1)!。

证明可在正orthant排序，以第k大坐标t积分：lower n−k coordinates给t^(n−k)/(n−k)!，上方k−1增量的sorted simplex给[k(R−t)]^(k−1)/[(k−1)!]^2；Beta积分后乘2^n n!，得到该式。故倍率确不额外含n；这不是遗漏volume normalization。

但整row outer halo要Minkowski加I_j，critical安全费用为

(1+2/a)^n·k^(k−1)/(k−1)!

相对原star体积。若再加L penalty，半径为r_j+ρ_j/L，费用相应替换。k约√n时point cone已是exp(O(√n))量级；更小halo仍不自动使inflation积分占V的常数。新load引理不能单独宣称根阶全family。

数学venv的SymPy实际核验rank-one determinant、order-statistic因子n/(k−1)、Beta体积因子及convex-chord积分代数，均为exact identities；没有largest-selector或source数值扫描。后续仍须核主作者trim/repair如何支付全halo及真实inflate volume。

## 7. 数值与停止边界（待主作者稿）

有限phase/probe的max通常只是sup的下界；若据此低估S，原row权会偏大，不能称可行q。即使probe-cone本身Lipschitz，未必majorize全部正体积F上的ρ。只有认证global majorization和相应Lipschitz/Jacobian预算，才能回填原row；probe efficiency或min/maxselector H不是这些证书。

当前已核：实际majorant原row packing、完整inverse Jacobian、critical固定α平均、top-k load及point/whole-row halo体积。尚未核：主稿的具体trim/repair边际；尚未证：全族inflation下界及一般root付款。未改repo，不启动新probe或无目的反例。等待必要作者材料再补最终范围。

## 8. 主稿trim与共享repair：末次必要核验通过

现已读 `/tmp/ccu_r623_main.md` 及 `/tmp/ccu_r623_topk.md`。主稿(1)–(3)的F-majorant回填与本审第1–3节相同。删除D⊂F时S_(F\D)≤S_F，按积分域拆分得到(4)的精确差：删除D的旧信用，加剩余receiver的inverse-power恢复。所有积分在存活域S≥ρ>0，空存活域按0；乘κ/P才是实际q增量。有限row-subset菜单最大值的(5)只对允许删除batch成立，作者已正确限制；它不证明J达到统一根阶。

repair(6)为原finite rows的有限cell LP：0≤δ≤λ，删除load覆盖[L+γH−1]_+，0≤γ≤1。δ=λ总可行，因为γH≤1；最优存在。故λ′=λ−δ+γψ非负可行，准确objective差是γq−Σd_jδ_j。所有source cells均须约束，薄正体积cell不可忽略，δ成本也不能由overload区域Lebesgue体积代替。

exchange(7)是一条足够的未证几何引理。若其统一增益成立，可将c缩小为min(c,1/2)，迭代deficit几何收缩；若已超过目标则停止。原packing polytope闭紧，极限给Q*≥V/K_n。作者未声称(7)已证，未把repair定义自身算为改进。

整row halo勘误已正确落实：∞-cone外包r_j+ρ_j/L，balanced/top-k norm外包ρ_j+r_j。旧C(L)=P/[(1−L)L^n]仅是遗漏generator移动的乐观粗模板；其最低线性费用不是原问题或实际packing的下界。新top-k稿的order-stat、Laplace/convex-chord上界、原row公式与gap-coordinate球体积均与本审独立证明一致，没有新的数学错误。

## 9. 固定周期模型的严格cone证书：关键界与范围

已读 `/tmp/ccu_r623_cone_certificate.md/.py`，并读取JSON核对当前脚本SHA和n96的准确端点；没有重跑大样本。模型是格距s=21/20的单位周期点源、r≤2、完整菜单上的最大合法radius selector；E之外radius按0。它不是任意source或任意finite family。

固定r时，Lebesgue-uniform receiver phase的每轴格点数为k或k+1，k=floor(2r/s)，高计数概率p=2r/s−k；这里独立性来自product周期相位，不是对原任意source的假设。最大合法candidate m处若实际N>m，则r_N≥r_m仍合法、N≤4^n，矛盾，故N=m a.e.。正最大候选因此由k=1,2,3及m=k^(n−h)(k+1)^h给出，另有k=0的m=1。代码以准确幂比较筛选其正确区间、去重并遇不同表示即失败，不会静默丢候选。

每个候选的max-selector集合包含于固定r_m的N≥m事件。该事件是Bin(n,p)≥h；代码对m^(1/n)用整数root上端算p_upper，二项尾单调性给安全上界，再用Fraction求和。不同m事件重叠只使所用union上界更粗，不曾冒称selector的精确分布。m=1事件体积准确为1。script无浮点比较参与严格求和和outward rational rounding。

保存的n96有理上端确为

B96=37982198423061843/10^18<0.037983，
相应旧κ系数加权积分的安全上端=13899777046003749/10^18<0.013900。

其中B定义为(19/10)^(−n)∫_E r_max(x)^n dx的上界，积分是一个fundamental cell上的普通Lebesgue量。不要把它与概率平均或带P的原finite-rowobjective混同。0.013900只适用于旧κ系数；若改用精确C_nk^(−1)或别的prefactor，不能自动沿用该数。

对所有未裁剪top-k majorants，d_k≤||·||∞。真实r=2域包含open box(1/10,s−1/10)^n，其closure距任一胞内点的∞距离≤1/10，故由sup和内点逼近，S_k≥2−1/10=1.9。这个closure论证很重要：原子open cubes在端点可能少计格点，不能仅以零测为由任意加入会影响sup的generator；这里由真实正体积内域逼近即可严格修复。因此B也控制全部这些未裁剪S_k的积分∫(r/S_k)^n。

该证书没有认证finite-L1平滑后所有selector/jumps不变，也不是全族upper。删除r=2 seeds、改变F、换admissible action或共同source选择后，S≥1.9前提可以消失。不能拿此固定模型的未裁剪失败反对这些修复或一般目标。有限phase、两scramble与probe max只作探路；probe max不是global sup，更不能据低估的S回填可行q。

## 10. 全k粗模板的线性边界：用的是实际下界

令C_nk=kn/(k−1)·J_(k−1)，J_(k−1)=E[1/(1+ΣU)]。Jensen给J_(k−1)≥2/(k+1)，故实际Jacobian平均常数满足

C_nk≥2kn/(k²−1)。

真实point-cone体积倍率H_k=k^(k−1)/(k−1)!=k^k/k!≥k，因为k!≤k^(k−1)。所以对全部2≤k≤n，

C_nk H_k≥2nk²/(k²−1)>2n。

这是C的**实际下界**乘真实volume，未用C的上界偷换成下界。whole-row额外(1+2/a)^n≥1只增加粗乘积。该结论仅说“把这个Jacobian平均常数与完整cone体积分别相乘付款”的模板最低仍线性；不约束实际receiver shadow、真实inflation积分、最优trim、repair或Q*，也不排除针对特殊S取得更好的联合load/geometry估计。有限Arb常数交叉核验只是补充数据，本审未重复其运行，一般短式由上面的解析不等式成立。

**当前最终通过范围：** majorant原rowpacking；完整inverse Jacobian；critical固定α与top-k平均；whole-row halo勘误；精确trim(4)与共享repair(6)；固定周期模型的strict cone上界及全k粗模板边界。**未证：** 主稿exchange(7)、可保留完整receiver的inflation控制、一般root全族付款。当前没有阻断这些已证结论的数学错误。原子周期诊断与一般L1/finite-family严格区分，未启动新probe或大样本重算，停止。
