import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,ctypes,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import qmc
import ccu_r623_numeric as base
S=21/20

def host_ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');host=lib.mach_host_self();v=(ctypes.c_uint32*4)();count=ctypes.c_uint32(4);rc=lib.host_statistics(host,3,v,ctypes.byref(count));return list(v) if rc==0 else None

def run(task):
 n,shard,Tidx,deadline,target,prior=task;start=time.monotonic();cpu=time.process_time();logs,radii,labels=base.menu(n);seed=623900000+10000*n+shard;sob=qmc.Sobol(d=n,scramble=True,seed=seed);total=0;sw=sw2=0.;event=accepted=0;maxw=0.;stage=[];blocks=[];tops=np.empty(0);oldN=0;oldsum=0.
 if prior:
  total=prior['N'];oldN=total;sw=prior['sum_weight'];oldsum=sw;sw2=prior['sum_weight2'];event=prior['event_hits'];accepted=prior['accepted_hits'];maxw=prior['max_weight'];stage=prior['stages'].copy();blocks=prior['blocks'].copy();sob.fast_forward(total)
 while total<target and time.monotonic()<deadline:
  vals=np.zeros(1024);x=sob.random(1024)*S
  for i,point in enumerate(x):
   pair=base.selector(point,logs,radii)
   if pair is None:continue
   event+=1;k=pair[1]
   if k<=Tidx:vals[i]=math.exp(logs[k]-logs[Tidx]);accepted+=1
  sw+=float(vals.sum());sw2+=float(vals@vals);maxw=max(maxw,float(vals.max()));tops=np.r_[tops,vals];cap=math.ceil(target/100);tops=np.partition(tops,-cap)[-cap:] if len(tops)>cap else tops;total+=len(vals)
  blocks.append({'N':len(vals),'sum_weight':float(vals.sum()),'sum_weight2':float(vals@vals),'max_weight':float(vals.max())})
  if total in (1024,target):stage.append({'N':total,'q':S**n*sw/total,'ESS':sw*sw/sw2 if sw2 else 0.,'event_hits':event,'accepted_hits':accepted})
 topn=max(1,math.ceil((total-oldN)/100));topshare=float(np.partition(tops,-topn)[-topn:].sum()/(sw-oldsum)) if sw>oldsum and len(tops)>=topn else 0.
 return {'n':n,'shard':shard,'seed':seed,'N':total,'sum_weight':sw,'sum_weight2':sw2,'max_weight':maxw,'max_weight_share':maxw/sw if sw else 0.,'new_segment_top_one_percent_weight_share':topshare,'prefix_top_one_percent_weight_share':prior.get('top_one_percent_weight_share',prior.get('new_segment_top_one_percent_weight_share')) if prior else None,'event_hits':event,'accepted_hits':accepted,'stages':stage,'blocks':blocks,'status':'complete' if total==target else 'partial','elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path('/tmp/ccu_r623_cone.json'));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--resume',action='store_true');p.add_argument('--workers',type=int,default=14);p.add_argument('--samples-per-shard',type=int,default=8192);a=p.parse_args();assert 1<=a.workers<=14 and a.samples_per_shard>=1024 and a.samples_per_shard%1024==0;a.output_dir.mkdir(parents=True,exist_ok=True);old=json.loads(a.input.read_text());thresholds={}
 for n in (7,12,24,48,96):
  q=next(q for q in old['paired_summary'] if q['n']==n and q['stage']==16 and q['policy']=='r_max');logs,r,labs=base.menu(n);pair=tuple(q['joint_best_T_exponents']);idx=labs.index(pair);thresholds[n]={'menu_exponents':pair,'T':float(r[idx]),'index':idx,'training_q':q['joint_best_q_mean']}
 path=a.output_dir/'ccu_r623_holdout.json';prior=json.loads(path.read_text()) if a.resume and path.exists() else None;md=a.output_dir/'ccu_r623_holdout.md';resource_log=a.output_dir/'ccu_r623_holdout_resource.log';out={'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'selector_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'thresholds':thresholds,'workers':a.workers,'samples_per_shard':a.samples_per_shard,'seed_rule':'623900000+10000*n+shard; independent of training scrambles','scope':'finite holdout Sobol estimates at one prespecified threshold per dimension; no H or phase recomputation','results':[],'resource_samples':[]};start=time.monotonic();deadline=start+270;out['prior_holdout_sha256']=hashlib.sha256(path.read_bytes()).hexdigest() if prior else None;out['prior_script_sha256']=prior['script_sha256'] if prior else None;out['prior_summary']=prior['summary'] if prior else None;oldmap={(r['n'],r['shard']):r for r in prior['results'] if 'n' in r} if prior else {};tasks=[(n,sh,thresholds[n]['index'],deadline,a.samples_per_shard,oldmap.get((n,sh))) for sh in range(14) for n in (7,12,24,48,96)]
 def summary():
  agg=[]
  for n in (7,12,24,48,96):
   arr=[r for r in out['results'] if r['n']==n and r['N']>0]
   if not arr:continue
   N=sum(r['N'] for r in arr);sw=sum(r['sum_weight'] for r in arr);sw2=sum(r['sum_weight2'] for r in arr);est=S**n*sw/N;means=np.array([S**n*r['sum_weight']/r['N'] for r in arr]);sd=float(means.std(ddof=1)/math.sqrt(len(means))) if len(means)>1 else None
   agg.append({'n':n,'completed_shards':len(arr),'samples':N,'q':est,'shard_mean_standard_error':sd,'ess':sw*sw/sw2 if sw2 else 0.,'largest_single_weight_share':max(r['max_weight'] for r in arr)/sw if sw else 0.,'accepted_hits':sum(r['accepted_hits'] for r in arr),'event_hits':sum(r['event_hits'] for r in arr),'shard_min':float(means.min()),'shard_max':float(means.max()),'pilot_shard_mean':float(np.mean([r['stages'][0]['q'] for r in arr if r['stages']])),'T':thresholds[n]['T'],'training_q':thresholds[n]['training_q']})
  return agg
 def save():
  out['elapsed_seconds']=time.monotonic()-start;out['summary']=summary();path.write_text(json.dumps(out));L=['# R623 frozen-threshold independent holdout','','Thresholds were frozen from the earlier two-scramble training histogram. Each of 14 independently scrambled Sobol shards per dimension uses a fresh seed; its 1,024-point pilot is a prefix of its final sample; if resumed, the Sobol sequence was fast-forwarded past the recorded prefix. q values are floating estimates, not certificates. The standard error uses unweighted variability across 14 scrambles (descriptive only if shard sizes differ) and is not a general asymptotic guarantee.','','| n | frozen T | training q | holdout q | SE across shards | ESS | accepted hits | shard min–max |','|---:|---:|---:|---:|---:|---:|---:|:---|']
  for r in out['summary']:L.append('| %d | %.8g | %.8g | %.8g | %s | %.6g | %d | %.7g–%.7g |'%(r['n'],r['T'],r['training_q'],r['q'],str(r['shard_mean_standard_error']),r['ess'],r['accepted_hits'],r['shard_min'],r['shard_max']))
  L+=['','Weights lie in [0,1] before the fixed cell-volume multiplier; the maximum and top-one-percent share are retained per shard. Sampled CPU percentages are system-wide Mach host tick differences, and worker process counts are measured from the executor; they include any other workloads.'];md.write_text('\n'.join(L)+'\n')
 prev=host_ticks();prevtime=time.monotonic();log=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  futures=[pool.submit(run,t) for t in tasks];pending=set(futures)
  while pending:
   done,pending=concurrent.futures.wait(pending,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    try:out['results'].append(f.result())
    except Exception as e:out['results'].append({'status':'error','error':repr(e)})
   now=time.monotonic()
   if now-prevtime>=1:
    ticks=host_ticks();cpu=None
    if prev is not None and ticks is not None:
     delta=[(ticks[i]-prev[i])%(1<<32) for i in range(4)];tot=sum(delta);cpu=100*(tot-delta[2])/tot if tot else None
    alive=sum(p.is_alive() for p in pool._processes.values());item={'elapsed_seconds':now-start,'live_worker_processes':alive,'host_cpu_percent':cpu,'completed':len(out['results'])};out['resource_samples'].append(item);log.append(json.dumps(item));prev=ticks;prevtime=now;resource_log.open('a').write(json.dumps(item)+'\n')
   if done:save()
 save();out['cpu_seconds_sum']=sum(r.get('cpu_seconds',0) for r in out['results']);out['max_worker_rss_bytes']=max((r.get('peak_rss_bytes_macos',0) for r in out['results']),default=0);save();print('done',len(out['results']),'wall',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
