import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import qmc
S=21/20

def menu(n):
 vals=sorted([(i*math.log(2)+j*math.log(3),i,j) for j in range(n+1) for i in range(2*(n-j)+1) if (i+1)//2+j<=n]);logs=np.array([v[0] for v in vals]);return logs,.5*np.exp(logs/n),[(i,j) for _,i,j in vals]
def selector(x,logs,r):
 n=len(x);fold=np.sort(np.minimum(x,S-x));n1=np.searchsorted(fold,r,side='right');n2=n-np.searchsorted(fold,S-r,side='left');n3=np.searchsorted(fold,r-S,side='right');n4=n-np.searchsorted(fold,2*S-r,side='left');c2=n2-n3;c3=n3-n4;c4=n4;assert np.all(c2>=0) and np.all(c3>=0) and np.all(c4>=0)
 lc=c2*math.log(2)+c3*math.log(3)+c4*math.log(4);valid=(n1==n)&(lc+1e-12>=logs);idx=np.flatnonzero(valid)
 return None if not len(idx) else (int(idx[0]),int(idx[-1]))
def direct(x,r):
 # Genuine all-image integer counts; floating boundaries lie on a null set.
 return np.floor((x+r)/S).astype(int)-np.ceil((x-r)/S).astype(int)+1

def run(arg):
 n,rep,maxexp,prior=arg;t=time.monotonic();cpu=time.process_time();logs,rad,labels=menu(n);rng=np.random.default_rng(623000+n);phases=[np.zeros(n)]+[np.full(n,S*t) for t in (.125,.25,.375,.5)]
 z=np.zeros(n);z[0]=S/2;phases.append(z);z=np.zeros(n);z[:n//2]=S/2;phases.append(z);phases.extend([rng.random(n)*S,rng.random(n)*S]);nph=len(phases)
 sob=qmc.Sobol(d=n,scramble=True,seed=623100+n*10+rep); sums=np.zeros((2,nph));sums2=np.zeros((2,nph));mins=np.full((2,nph),np.inf);maxs=np.zeros((2,nph));hit=0;records={};direct_checks=0;started=0
 if prior:
  z=prior['stages']['12'];hit=z['event_hits'];started=4096;records['12']=z;sob.fast_forward(4096)
  for i,p in enumerate(z['policies']):
   sums[i]=np.array(p['H_over_E'])*hit;ee=np.array(p['ESS']);sums2[i]=np.divide(sums[i]**2,ee,out=np.zeros(nph),where=ee>0);mins[i]=p['sample_weight_min'];maxs[i]=p['sample_weight_max']
 for k in range(((1<<maxexp)-started)//4096):
  data=sob.random(4096)*S
  for x in data:
   pair=selector(x,logs,rad)
   if pair is None:continue
   hit+=1
   if direct_checks<20:
    for p in pair:
     counts=direct(x,rad[p]);directlog=sum(np.log(counts));assert directlog+1e-10>=logs[p]
    direct_checks+=1
   for which,ix in enumerate(pair):
    for z,y in enumerate(phases):
     cnt=np.floor((x+rad[ix]-y)/S)-np.ceil((x-rad[ix]-y)/S)+1
     assert np.all(cnt>0) or z>0
     val=0. if np.any(cnt<=0) else math.exp(float(np.log(cnt).sum()-logs[ix]));
     if which==1 and z==0:assert abs(val-1)<1e-9, (n,val)
     sums[which,z]+=val;sums2[which,z]+=val*val;mins[which,z]=min(mins[which,z],val);maxs[which,z]=max(maxs[which,z],val)
  started+=4096
  if started in (4096,65536):
   ar=[]
   for which in range(2):
    m=sums[which]/started;conditional=sums[which]/hit if hit else np.zeros(nph);ess=np.divide(sums[which]**2,sums2[which],out=np.zeros(nph),where=sums2[which]>0);idx=int(np.argmax(m));ar.append({'policy':'r_min' if which==0 else 'r_max','H_over_E':conditional.tolist(),'H_per_cell':(m*S**n).tolist(),'max_detected_phase':idx,'payoff_detected':float((hit/started)/m[idx]) if m[idx]>0 else None,'sample_weight_min':np.where(np.isfinite(mins[which]),mins[which],0).tolist(),'sample_weight_max':maxs[which].tolist(),'ESS':ess.tolist()})
   records[str(int(math.log2(started)))]={'N':started,'event_hits':hit,'event_probability':hit/started,'event_volume':S**n*hit/started,'policies':ar}
 return {'n':n,'scramble':rep,'seed':623100+n*10+rep,'phase_vectors':[z.tolist() for z in phases],'phase_labels':['zero','all_1/8','all_1/4','all_3/8','all_1/2','first_1/2','half_1/2','seed_vector_1','seed_vector_2'],'menu_count':len(rad),'direct_sample_checks':direct_checks,'stages':records,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','full'),required=True);p.add_argument('--workers',type=int,default=1);p.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);path=a.output_dir/'ccu_r623_numeric.json';md=a.output_dir/'ccu_r623_numeric.md';idx=a.output_dir/'ccu_r623_index.json';start=time.monotonic();out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'command':shlex.join([sys.executable]+sys.argv),'phase':a.phase,'workers':a.workers,'results':[],'selector':'full menu; periodic lattice count >= m, r=m^(1/n)/2; no label-factor realizability restriction','scope':'Sobol finite numerical diagnostics; phases are a finite probe, not supremum'}
 pilot=json.loads(path.read_text()) if a.phase=='full' and path.exists() else None
 if pilot:out['pilot_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();out['pilot_script_sha256']=pilot['script_sha256']
 tasks=[(7,i,12,None) for i in (0,1)] if a.phase=='pilot' else [(n,i,16,next((v for v in pilot['results'] if v['n']==n and v['scramble']==i),None) if pilot else None) for n in (7,12,24,48,96) for i in (0,1)]
 def save():
  comparisons=[]
  for n in (7,12,24,48,96):
   pair=sorted([r for r in out['results'] if r['n']==n],key=lambda r:r['scramble'])
   if len(pair)==2:
    for stage in set(pair[0]['stages'])&set(pair[1]['stages']):
     p0=pair[0]['stages'][stage];p1=pair[1]['stages'][stage]
     for policy in range(2):
      a0=np.array(p0['policies'][policy]['H_over_E']);a1=np.array(p1['policies'][policy]['H_over_E']);avg=(a0+a1)/2;se=np.abs(a0-a1)/2;k=int(np.argmax(avg));comparisons.append({'n':n,'stage':int(stage),'policy':p0['policies'][policy]['policy'],'max_mean_probed_H_over_E':float(avg[k]),'max_mean_phase':k,'two_scramble_SE_at_phase':float(se[k]),'phase_mean':avg.tolist(),'phase_two_scramble_SE':se.tolist()})
  out['scramble_comparisons']=comparisons
  path.write_text(json.dumps(out));L=['# R623 periodic source adjoint load numerical probe','','The selector tests every eligible menu mass against the true periodic-image count, and the adjoint weight multiplies all periodic images. Sampled phases are a finite probe, not a phase supremum. The two scramble difference is a diagnostic, not a certificate.','','| n | scramble | samples | E hits | policy | max probed H/|E| | phase index | detected payoff | min ESS |','|---:|---:|---:|---:|:---|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda t:(t['n'],t['scramble'])):
   for stage in r['stages'].values():
    for p in stage['policies']:
     L.append('| %d | %d | %d | %d | %s | %.8g | %d | %s | %.5g |'%(r['n'],r['scramble'],stage['N'],stage['event_hits'],p['policy'],max(p['H_over_E']),p['max_detected_phase'],str(p['payoff_detected']),min(p['ESS'])))
  L+=['','Full phase vectors, per-phase minima/maxima, ESS, and two independent scramble runs are stored in JSON. At phase 0 the maximal-radius selector is checked against K/m=1 numerically.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(run,t) for t in tasks]):
   r=f.result();out['results'].append(r);save();print('done',r['n'],r['scramble'],r['elapsed_seconds'],flush=True)
 out['wall_seconds']=time.monotonic()-start;save();idx.write_text(json.dumps({'phase':a.phase,'completed':len(out['results']),'wall_seconds':out['wall_seconds'],'cpu_seconds':sum(r['cpu_seconds'] for r in out['results']),'max_worker_rss_bytes':max(r['peak_rss_bytes_macos'] for r in out['results']),'workers':a.workers,'script_sha256':out['script_sha256'],'command':out['command']},indent=2))
if __name__=='__main__':main()
