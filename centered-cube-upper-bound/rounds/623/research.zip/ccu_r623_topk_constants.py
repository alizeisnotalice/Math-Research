"""Finite Arb checks of the exactly derived top-k constants (not a general proof)."""
import argparse, hashlib, json, math, platform, sys, time
from fractions import Fraction
from pathlib import Path
import flint
from flint import arb, ctx

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path('/tmp/ccu_r623_topk_constants.json'))
    args=ap.parse_args();ctx.prec=256;t=time.perf_counter();rows=[]
    for n,k in [(2,2),(3,2),(3,3),(7,4),(12,5),(24,6),(48,8),(96,11),(256,17)]:
        m=k-1
        # m-fold integration of 1/(1+sum u_i); m>=1.
        J=sum((arb((-1)**(m-j)*math.comb(m,j)*(j+1)**(m-1))*arb(j+1).log()
               for j in range(m+1)),arb(0))/math.factorial(m-1)
        C=arb(k*n)*J/(k-1)
        lo=Fraction(2*k*n,k*k-1)
        hi=Fraction(2*n,k-1)*(1-Fraction(1,2**k))
        assert C>arb(lo.numerator)/lo.denominator
        assert C<arb(hi.numerator)/hi.denominator
        if k==2: assert (C-2*n*arb(2).log()).contains(0)
        H=Fraction(k**(k-1),math.factorial(k-1))
        rows.append({'n':n,'k':k,'J_interval':str(J),'C_interval':str(C),
                     'analytic_lower':[lo.numerator,lo.denominator],
                     'analytic_upper':[hi.numerator,hi.denominator],
                     'point_cone_volume_ratio':[H.numerator,H.denominator],
                     'safe_packing_coefficient':[k-1,2*n]})
    out={'rows':rows,'precision_bits':ctx.prec,'python':sys.version,'interpreter':sys.executable,
         'python_flint':flint.__version__,'platform':platform.platform(),
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'command':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-t,
         'scope':'Nine finite Arb interval checks of exact constant formulas; general bounds proved analytically.'}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'checked':len(rows),'precision_bits':ctx.prec,'wall_seconds':out['wall_seconds']}))

if __name__=='__main__':main()
