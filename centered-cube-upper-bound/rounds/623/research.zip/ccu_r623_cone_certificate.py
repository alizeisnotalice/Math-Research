import math,json,sys,time,platform,resource,hashlib
from pathlib import Path
from fractions import Fraction as Q
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r623_cone_certificate.json'));args=ap.parse_args()
start=time.perf_counter();cpu=time.process_time();s=Q(21,20);D=10**12;ns=(7,12,24,48,96)
def rootfloor(m,n):
 lo=D;hi=4*D+1
 while lo+1<hi:
  mid=(lo+hi)//2
  if mid**n<=m*D**n:lo=mid
  else:hi=mid
 assert lo**n<=m*D**n<(lo+1)**n
 return lo
def tailupper(n,h,p):
 if h==0:return Q(1)
 if p==1:return Q(1)
 return sum((Q(math.comb(n,j))*p**j*(1-p)**(n-j) for j in range(h,n+1)),Q())
def get(n):
 candidates={1: {'kind':'m1','event_volume_upper':Q(1),'k':0,'h':n}}
 for k in (1,2,3):
  for h in range(n+1):
   m=k**(n-h)*(k+1)**h
   if not ((k*s)**n<=m<=((k+1)*s)**n and m<=4**n):continue
   q=rootfloor(m,n);ph=min(Q(1),max(Q(),Q(q+1,D)/s-k));pmin=min(Q(1),max(Q(),Q(q,D)/s-k));assert pmin<=ph
   t=tailupper(n,h,ph);rec={'kind':'binomial','event_volume_upper':s**n*t,'k':k,'h':h,'root_floor':q,'p_upper':ph}
   if m in candidates:
    old=candidates[m];assert old['kind']=='binomial' and old['k']==k and old['h']==h, 'duplicate requires separate exact event audit'
   candidates[m]=rec
 total=sum((Q(m,2**n)*r['event_volume_upper'] for m,r in candidates.items()),Q());kappa=Q(n-1,n)**n;B=total/Q(19,10)**n;upper=kappa*B
 # Produce rational outward decimal grid as compact theorem bound.
 rounded=(upper.numerator*10**18//upper.denominator+1);bound=Q(rounded,10**18);assert upper<bound
 return {'n':n,'kappa':[str(kappa.numerator),str(kappa.denominator)],'candidates':[{'m':str(m),'k':r['k'],'h':r['h'],'root_floor':r.get('root_floor'),'p_upper':None if r.get('p_upper') is None else [str(r['p_upper'].numerator),str(r['p_upper'].denominator)]} for m,r in sorted(candidates.items())],'candidate_count':len(candidates),'B_outward_18_decimal':[str((B.numerator*10**18//B.denominator+1)),str(10**18)],'upper_outward_18_decimal':[str(bound.numerator),str(bound.denominator)],'upper_float':float(bound),'upper_lt_one':upper<1}
rows=[get(n) for n in ns]
out={'s':'21/20','root_denominator':D,'dimensions':list(ns),'results':rows,'formula':'q_cone <= ((n-1)/n)^n * (10/19)^n * sum_m (m/2^n)*s^n*binomial_tail_upper','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'untrimmed balanced cone, periodic point model, fixed source and maximum selector; union bound, no Sobol'}
args.output.write_text(json.dumps(out,indent=2)+'\n');print([(r['n'],r['candidate_count'],r['upper_float'],r['upper_lt_one']) for r in rows]);print('wall',out['wall_seconds'],'sha',out['script_sha256'])
