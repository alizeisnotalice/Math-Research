# R623 冻结阈值 holdout 代码独审

检查的 `/tmp/ccu_r623_holdout.py` SHA-256 `eb4c5379ac4da9ca2f50d5f2389498598bf4aad3cb224dd73c47704f03788d11`。旧训练 `/tmp/ccu_r623_cone.json` SHA-256 `a248cf8a4cde018b51791003169f30114e61bcee4f72efef6216a02025994727`；所引用 selector 的当前 SHA-256 与训练文件记录一致，均为 `f868cacdaf9746bd577de0395e53e1cd49196d8657be92178f1ccaf508df7bc7`。本审查只读取代码和旧训练数据，未启动 holdout 实验或更改其他脚本。

独立从旧文件各 n 两个 continuation 的 `hist[1]` 计算 `cumsum(count·m)/m` 并最大化：每组恰有两个 65536 点样本，重新求得的阈值指数与脚本读取的 `paired_summary` 相符。n=7、12、24、48、96 的阈值 (i,j) 分别为 (14,0)、(0,12)、(0,0)、(0,0)、(0,0)。训练摘要中的联合 q 与重算一致到浮点舍入。因两个旧样本大小相等，合并 histogram 与两组 q 等权平均等价。

Holdout 对每维固定此索引，调用同一周期格点 `selector` 的最大合法半径 k，再赋权 `w=1_{k≤Tidx} exp(log m_k−log m_T)`；没有在 holdout 数据上重新选择阈值。菜单按 log m 排序，因此浮点误差范围内 w∈[0,1]；无合法 selector 贡献 0。累计 `q=sⁿ Σw/N` 与目标公式一致，sⁿ 将均匀胞概率转换为真实胞体积；被排除的样本仍保留在 N 中。每 shard 记录 seed、样本数、Σw、Σw²、最大权重、命中数、CPU 时间及峰值 RSS；汇总 ESS 为 `(Σw)²/Σw²`。各 shard 种子为 `623900000+10000n+shard`，与训练 `623100+10n+rep` 不重合；调用独立 scramble，pilot 是同一 shard 最终样本的前缀，并非独立验证集。

资源记录为系统级 Mach CPU 采样及 executor 活进程数，含其他并行工作；报告的 worker 峰值 RSS 是单进程最大值，不是总内存。脚本的 shard 间标准误来自各 shard 均值离散度，仅为经验诊断，不是严格误差保证。若存在不同长度的 partial shards，汇总 q 按 N 加权，但该标准误未按样本数加权，应单独注明，不将其当作加权估计的严格标准误。脚本和结果均基于浮点与有限 Sobol 数值，selector 的边界容差和有限样本不能作严格证书；本审查也不把经验标准误称为置信保证。

## 续跑最终核验

续跑脚本 SHA-256 `a454d2036a1dad9cf8527dc0a7eb1b7108acadbe6371b607b9c2f43f3eb07969` 与最终 JSON 所记相同。初始化重新使用相同的 seed，将旧 N、Σw、Σw²、命中、最大权重和 blocks 接入，再 `fast_forward(旧 N)` 后从下一点开始累计；因此代码路径没有重复累计旧前缀。对 n=7、96 的 shard 0 小型 Sobol 检查，直接生成 9216 点的后 1024 点与 fast-forward 8192 后的 1024 点逐元素完全一致；此检查只针对序列衔接，不重跑 selector 主实验。

最终 JSON 包含 70 个不同 (n,shard)，每个均 complete、N=262144，每维 14 shard、共 3670016 点。每个 shard 有 256 个 1024 点 block，块长之和等于 N；将 block 质量求和与累计 Σw 比较，最大浮点差约 3.64e−11，与不同浮点加法顺序相容。重建 pilot 的 70 条记录，其前 8 个 block 与最终 JSON 各对应 shard 的前 8 个 block 一致。

`new_segment_top_one_percent_weight_share` 只对续跑新增 253952 点计算，`prefix_top_one_percent_weight_share` 单列旧 8192 点；二者都不是整个 262144 点的 top-1% 份额，不能将其误报为全样本 top-1%。各 shard 的最大单个权重比例则用包含前缀的累计最大值和累计总质量。续跑的 CPU 时间和峰值 RSS 为续跑进程统计，不能视为包含旧 pilot 的全程成本。

`/tmp/ccu_r623_holdout_pilot.json` 明示由已保存的块和快照重建；当前文件 SHA-256 `4bd07b3437eaad15fe8e9030ac9b300097a015031c26717e41a53197d68db42f`，不是原 pilot 的字节副本。续跑 JSON 记录的原文件 SHA-256 为 `51db1795a91618bbfd9e73bbc05ac89c1bd7a0155b73f73c42978ff4fc92b05c`；原始 pilot 每 worker 时间和内存不可恢复。资源日志中的 live 14 表示 executor 的 14 个进程仍存活，不证明 14 个均在工作；host CPU 百分比是系统级指标。最终结果仍为有限浮点 Sobol 估计。
