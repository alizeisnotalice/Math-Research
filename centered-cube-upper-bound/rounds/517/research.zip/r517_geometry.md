# R517：按全场窗能量支付可变质量平移，首达增量不再依赖小 α

本轮证明了一个新估计：任意逐父、可随机且共享来源的质量窗平移，若位移绝对值≤h，则对完整原局部场的交叉 score 亏损至多 3hQ_i。它不使用逐父窗帽除以 α，因此向外候选可采用固定质量增量 u=γ^h−1。薄首达壳的费用随之保留原 α 权，不能再把该权过早丢掉。

实际候选平均场的软平方 B_A 仍未完成来源付款；本稿没有把窗平移估计当作首达覆盖或 B_A 已付。

## 1. 冻结局部输入与其真正的一次来源表示

沿 R516 固定已选源格。逐格记真实来源 μ_i、中心 E_i、原 t_B≤S、半径 R_B、m_B=q_BR_B^n、s_B=log_γ m_B，

\[
a_B=t_BR_B^{-n},\quad
L_i(y,\sigma)=\int_{E_i}a_B1_{Q_B}(y)1_{[s_B,s_B+1]}(\sigma)dB,
\quad Q_i=\|L_i\|^2.
\]

所有候选半径仍≤b，故该格来源不逃出原源格。L_i、其 score、α 始终保持固定，不随所保留中心或辅助动作重算。令 Q_g=Σ_iQ_i≥(1−β)²Q，C=S[1+log(γr)]。

对每一个真实来源 y 定义有限正的**质量坐标测度**

\[
\nu_y(ds)=\int_{E_i}a_B1_{Q_B}(y)\delta_{s_B}(ds)dB.
\tag{1}
\]

它是原中心权在 log mass 坐标的推前，不是重新抽样的来源。总质量≤SA_n，A_n=1+nlog(b/a)。有

\[
L_i(y,\sigma)=\int1_{[s,s+1]}(\sigma)\nu_y(ds).
\]

下文先对 ν_y 的两个中心坐标积分，最后仅对同一 μ_i(dy) 积分；没有把 μ² 当 W²。

## 2. 核心三角核估计

置 T(x)=(1−|x|)_+。对任意实数 x，

\[
1_{\{|x|\le1\}}\le T(x)+T(x-1)+T(x+1).\tag{2}
\]

在 |x|≤1 时右边恰为 1，外侧非负。对任意有限正测度 ν，令 F=ν*1_[0,1]，则

\[
\iint T(s-t)d\nu(s)d\nu(t)=\|F\|_2^2.
\]

另外两项分别是 F 与其 ±1 平移的内积，各由 Cauchy 不超过 ||F||²。因此

\[
\boxed{\iint1_{\{|s-t|\le1\}}d\nu(s)d\nu(t)\le3\|F\|_2^2.}\tag{3}
\]

这一步保留原单位质量窗产生的三角核；没有把跨层相遇量用中心数或质量层数控制。

## 3. 子集和随机动作的全场平移亏损

取任意可测 F_i⊂E_i。对 B∈F_i，允许来源抽样前选定的动作概率 π_B；每个动作附带窗位移 δ(B,R)，要求 |δ(B,R)|≤h。动作可依赖 B、μ_i、固定 L_i，但不能依赖某个被抽出的 y 或来源 pair。

暂时只移动窗，冻结原空间盒及原系数，定义

\[
D_i(y,\sigma)=\int_{F_i}a_B1_{Q_B}(y)
\int1_{[s_B+\delta(B,R),s_B+\delta(B,R)+1]}(\sigma)\pi_B(dR)dB.
\]

原被保留中心的交叉 score 为

\[
H_{F_i}=\int_{F_i}\psi_i(B,R_B)dB=\langle L_i,L_{F_i}\rangle.
\]

T 是 1-Lipschitz，且 T(x)=0 于 |x|≥1，所以对 |δ|≤h，

\[
T(x)-T(x+\delta)\le h1_{\{|x|\le1\}}.\tag{4}
\]

这里是单边亏损，不把可能为正的新增窗收益改成绝对值费用。把(4)对动作概率积分，再对原父 B∈F_i 与测试父 C∈E_i 积分。因 ν_(F_i,y)≤ν_y，正性和(3)给

\[
\boxed{H_{F_i}-\langle L_i,D_i\rangle\le3hQ_i.}\tag{5}
\]

所有步骤对每个 y 先成立，再对真实 μ_i 积分。没有要求 F_i=E_i，也没有假设 δ 对不同中心相同。随机动作只需每父概率质量为 1；上述计算已把动作积分保在原中心标签内。

更精确的未简化亏损为

\[
h\int\iint1_{|s-t|\le1}\,\nu_{F_i,y}(ds)\nu_y(dt)d\mu_i(y),
\]

上界 3hQ_i 是统一可吸收版本。未保留中心另按其原 score 记账，不能从(5)中删除。

## 4. 实际向外动作：固定质量比例便有足够总 score

固定

\[
0<h<\min\{1/6,\log_\gamma2\},\qquad1<G\le2.
\tag{6}
\]

对 B∈F_i，π_B 支持真实动作满足

\[
R_B\le R\le\min\{G^{1/n}R_B,b\},\qquad
m_B\le m(B,R)\le\gamma^h m_B.\tag{7}
\]

密度准确为 q(B,R)=q_B[m(B,R)/m_B]/[(R/R_B)^n]，所以

q/2≤q_B/G≤q(B,R)≤γ^h q_B≤2λ。

只用一次扩大带 [q/2,2λ]。真实窗位移 δ=log_γ(m(B,R)/m_B)∈[0,h]。同时新盒包含原盒，新系数至少为 a_B/G。因此实际平均场

\[
A_i=\int_{F_i}\int k_t(B,R)\pi_B(dR)dB
\]

逐点满足 A_i≥D_i/G。L_i≥0 及(5)给

\[
\boxed{\langle L_i,A_i\rangle\ge\frac{H_{F_i}-3hQ_i}{G}.}\tag{8}
\]

新增壳来源的实际正贡献保留在 A_i 中，仅在下界中舍去；没有把它重新计为亏损。此命题无需极值、EX、逐父近最佳门或 α 下界。总亏损是固定比例 3h 的原场能量，而不是 Ct_Bq_Bh 的逐父费用再求和。

## 5. 对完整原 Q 的准确回代

可以继续采用 R516 已付低层 E_low≤CSW。令 F_i 覆盖 high 的一部分，保留真实未覆盖 high score E_miss。则

\[
\sum_iH_{F_i}=Q_g-E_{low}-E_{miss}.
\]

记实际软平方 B_A=Σ_i||A_i||²。由(8)与直和 Cauchy，

\[
(1-3h)Q_g-E_{low}-E_{miss}
\le G\sum_i\langle L_i,A_i\rangle
\le G\sqrt{Q_gB_A}.\tag{9}
\]

若实际构造能使 E_miss≤ηQ_g，且 a_*=1−η−3h>0，则

\[
Q_g\le\frac{G^2B_A}{a_*^2}+\frac{2E_{low}}{a_*}.
\]

最终

\[
\boxed{Q\le\frac1{(1-\beta)^2}
\left[\frac{G^2B_A}{(1-\eta-3h)^2}
+\frac{2CS}{1-\eta-3h}W\right].}\tag{10}
\]

若直接对所有正 score 中心求覆盖，省去 low 划分，且全部未覆盖 score≤ηQ_g，则没有低层加项，严格有

\[
Q\le\frac{G^2B_A}{(1-\beta)^2(1-\eta-3h)^2}.
\]

h、G、η、β 可固定独立 n。实际未知仍是 B_A≤polylog(n)W（或足够小的同一 Q 收缩）和相应覆盖/漏失，不因(8)的门变宽就默认成立。

## 6. 固定增量首达与保 α 的更强壳收据

令 u=γ^h−1∈(0,1)，与 α 和维数均无关。定义实际质量首达

\[
T_B^+=\sup\{R\in[R_B,b]:m(B,R)\le(1+u)m_B\},
\quad U_B=\min\{G^{1/n}R_B,b,T_B^+\}.
\tag{11}
\]

整个 J_B^+=[R_B,U_B] 都满足(7)，所以任何来源前共享、支持其中的概率动作都可直接用于全场估计(8)。这不再要求每一个动作逐父满足旧的相对 score 门。

μ=f dx 保证径向质量连续。若 R_B<b，则 J_B^+ 有正宽度；若 R_B=b，则端点原动作 b 可用。凡 b∈J_B^+ 的中心可统一选 b，该固定半径场满足 ||A_b||²≤S²W（真实中心体积与窗长 1），端点不会成为未记账补集。该端点场与同格其余场并不自动正交：若分开估计，必须保交叉项，例如使用 ||A_rest+A_b||²≤2||A_rest||²+2S²W 后才接回 B_A；或直接将其保留在实际 B_A 中。a=b 时整个问题已有这个固定半径付款。

若正宽度区间因实际质量首达而薄，具体说 U_B=T_B^+<b 且体积帽未先截断，则

\[
\Delta_B=\mu(Q(B,T_B^+)\setminus Q_B)=u m_B.\tag{12}
\]

对任意由此类首达中心组成的未覆盖子集 H_i，仍用固定原局部场定义

\[
\alpha_i(B)=\frac{\psi_i(B,R_B)}{Ct_Bq_B}
\]

（t_B=0 单列）。它们的原交叉 score 精确等于

\[
\boxed{
E_{shell}
=\frac C{u}\int\sum_i\int_{H_i}
\alpha_i(B)t_BR_B^{-n}
1_{Q(B,T_B^+)\setminus Q_B}(y)dB\,d\mu(y).}\tag{13}
\]

这是(12)与 Tonelli 的准确等式。旧阈值 u_B∝α_B 会把 α 抵消；本轮固定 u 则保留了 α 权。不能为简化而立即用 α≤1 丢掉这一真实 score 折扣。特别低 α 的父现在须先捕获固定比例质量，壳费用仍按其原小 score 权计。

α 关联原 L_i 和同一原质量后验；(13)没有重抽历史，也没有在观察外壳来源 y 后选择半径。各源格支持互斥，故跨格不重复付 W；同格内许多父对同一来源的加权重复仍未证明可付。任意覆盖失败中心不一定由质量首达造成，(13)只能用于满足(12)的子集，其余 miss 必须留在(9)。

普通共同 log-volume 测度仍只有线性 n 的覆盖质量；本轮没有用固定 u 冒称该复杂度自动变为多对数。实质改进是：原先逐父门中的 α 困难已改为全场固定比例亏损，剩余几何可在更宽的固定质量首达区间上，保 α 权直接研究 B_A 或壳源重叠。

## 7. 同一窗机制的方差核查（仅冻结空间核）

对完整一格且单向位移 δ∈[0,h]，记冻结空间后的场为 D。它逐点被同一原中心权的长窗 [s,s+1+h] 场支配。对 0≤h≤1，准确的核上界是

\[
(1+h-|x|)_+\le(1+h)T(x)+hT(x-1)+hT(x+1).
\]

在 |x|≤1 两边相等；在 1≤|x|≤1+h 直接比较斜率，其余显然。用 Cauchy 控平移相关，得到

\[
\|D\|^2\le(1+3h)Q_i,
\qquad\|D-L_i\|^2\le9hQ_i.\tag{14}
\]

第二式用(5)的完整场版本。它说明可变小窗移的能量稳定性也不需要逐父 α。必须强调 D 冻结了原空间盒和系数；实际 A_i 含新增壳来源及新系数，不能把(14)直接写成 B_A 的来源付款。

## 8. 本机精确核验

实际运行 Fraction 枚举三角核分段点、不同质量坐标原子权、逐父可变位移以及全部父子集。检验(2)、长窗核界、(5)、单向窗能量与方差界，输出：`PASS 597 exact tent, variable-window, subset and energy checks`。测试不含浮点近似；一般正测度结论由正文逐点核比较、Tonelli 与 Cauchy 给出。

```python
from fractions import Fraction as F
from itertools import product
T=lambda x:max(F(0),1-abs(x))
count=0
for x in [F(i,8) for i in range(-24,25)]:
 assert (1 if abs(x)<=1 else 0)<=T(x)+T(x-1)+T(x+1);count+=1
for h in (F(1,8),F(1,4),F(1,2),F(1)):
 points={F(i,8) for i in range(-24,25)}|{-1-h,-1,F(0),F(1),1+h}
 for x in points:
  assert max(F(0),1+h-abs(x))<=(1+h)*T(x)+h*T(x-1)+h*T(x+1);count+=1
for locations,weights in [([F(0),F(1),F(2)],[F(1),F(2),F(1)]),
                          ([F(0),F(3,4),F(5,4)],[F(1,2),F(1),F(3,2)])]:
 n=len(locations)
 Q=sum(weights[i]*weights[j]*T(locations[i]-locations[j]) for i in range(n) for j in range(n))
 for h in (F(1,8),F(1,4)):
  for shifts in product((F(0),h),repeat=n):
   D=sum(weights[i]*weights[j]*T(locations[i]+shifts[i]-locations[j]) for i in range(n) for j in range(n))
   QD=sum(weights[i]*weights[j]*T(locations[i]+shifts[i]-locations[j]-shifts[j]) for i in range(n) for j in range(n))
   assert D>=(1-3*h)*Q;count+=1
   assert QD<=(1+3*h)*Q;count+=1
   assert Q+QD-2*D<=9*h*Q;count+=1
   for mask in range(1<<n):
    HF=sum(weights[i]*weights[j]*T(locations[i]-locations[j]) for i in range(n) if mask>>i&1 for j in range(n))
    DF=sum(weights[i]*weights[j]*T(locations[i]+shifts[i]-locations[j]) for i in range(n) if mask>>i&1 for j in range(n))
    assert HF-DF<=3*h*Q;count+=1
print('PASS',count,'exact tent, variable-window, subset and energy checks')
```
