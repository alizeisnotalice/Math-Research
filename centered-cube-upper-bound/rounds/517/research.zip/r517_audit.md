FINAL PASS（仅认证本轮确证命题、常数及有限证据范围；一般根阶上界仍未完成）。冻结九输入已核准，无实质修订阻塞。新全场移窗估计不需α下界或极值；实际软平方B_A与未覆盖高层的联合来源预算仍未付。

主定理：对每真实y取原正质量坐标流ν_y，单位窗平方产生tent核。近邻indicator由三个tent平移控制，各相关由Cauchy≤原窗平方，系数3正确。任意子集及逐父可测随机动作、|δ|≤h时，单边tent亏损只需旧近邻支持，故cross损失≤3hQi；ν_y依赖y及其label原子均允许。每父概率总权1，不按候选/层数重复收费；最后仅对同一μ积分。外扩同t、g≤G、新空间源非负，准确给〈Li,Ai〉≥(〈Li,L_Fi〉−3hQi)/G。G≤2、γ^h≤2保证一次真实扩带；无域外EX、重取极值或history重采样。

完整账与首达：固定Li和R516低层CSW只用一次，E_miss≤ηQg、d=1−η−3h>0时，原Q预算的G²B_A/d²、2CSW/d及(1−β)^(−2)全部正确。固定u=γ^h−1首达端点/平台条件正确；壳质量um使坏score精确保α权，原t与原R_B大分母未换。仅质量首达截断子集适用该壳收据，其余miss未删除。b端点固定半径场≤S²W，但同格其余场cross未被当成正交：实际B_A或2B_A,rest+2S²W保留。a=b零宽情形可用固定半径付款。

能量与双向补充：||D||²≤(1+3h)Qi及||D−Li||²≤9hQi只用于完整一格、冻结原空间核、单向δ∈[0,h]、h≤1；长窗三tent上界正确，未写成实际增壳A的付款。内缩正部亏损、双向空间系数守恒、有符号壳差与真实窗修正相符。概率每格固定时完整积分后场的方差负信用正确；没有用单中心核差代替，也未将随B变权或不同构造的有利项拼接。总score门是同一实际动作族的合法放宽，其回代常数正确，仍是条件式。

有限证据范围：三模型的所有源块捕获对整段正Lebesgue中心成立，字段与中心长度积分真实；Fraction/SymPy身份和Arb256具体log式sign可复现。三组均有全E解析soft归属，未认证high预算、极值或一般强制性。有限label原子检查是质量坐标代数，未被当作原子接收模型；它不替代一般tent证明，也不允许把不同空间混合的窗费直接写成3hQold。

实际验证：本人用指定Python-I从冻结geometry提取597项精确检查，完整执行numeric285守卫；numeric唯一JSON写入捕获于进程内存，未改冻结文件。stdout逐字匹配replay，JSON仅去顶层seconds后全部字段一致，canonical SHA256为9f004023e6bc6ba4acfc17bfd5f55ec9e8c45752948ebab71ee08604e67960eb。独立重放不另增成果计数。未使用MATLAB。

原流与保留缺口：main保R_*≤2√(DWQ)及D=1+log_γr+nlog_γ(b/a)，原入口正分母、母账、适用H_*和初始/删除/跳跃/未来来源/宽距/低强度/比例/全尺度极限费用均未省去。仍须同一动作族的多对数B_A（或严格同Q收缩）及miss预算；固定比例捕获并未自动支付同格来源重复。history亦未把486链能量移植为静态付款或重新认证其历史全链。

冻结输入 SHA256：
- `r517_main.md`: `95c43544bddc6088389028b200611c8c6e2dd025499cee98ada322ce9e4a8f6f`
- `r517_proof.md`: `e871ae8e03ce69110db11c4ca181ece230f8fa3dab3d9bda658a8fb5280b79a5`
- `r517_geometry.md`: `3cd5e3fd1507cf1660440d3b9e41e29ee10835c05157d7f89379da9516405c3d`
- `r517_audit_pre.md`: `dcdb3e59584a32cbbf7a5239342cd7dbe83ef3188171b0ff862800ea9ffafab3`
- `r517_numeric.py`: `ee873739b8e05f0cbd107f183da8cc0500047316d524e6244bb4623211f477c0`
- `r517_numeric.json`: `3156af40250760985cbf2ce7332b6bd44a456079445de88cff46b83da1a8864d`
- `r517_numeric.md`: `dc9df1e89edff03c6cc1b5c318777779aa059774134fa5697349dfdb458b1db4`
- `r517_history.md`: `7b9213b5add7387e6220f3430b234a5910ee1c12fd1f9c4a7fa5ffaa8fce044f`
- `r517_replay.json`: `e19236e5659af67847b357a6d00dd5cec4f92291727c2e4d088010d619e809c8`
