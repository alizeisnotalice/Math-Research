#!/usr/bin/env python3
"""R517 signed annular mixture on true L1 sources and finite window algebra."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def ball(x):
 x=sp.sympify(x)
 if x.is_Rational:return arb(int(x.p))/int(x.q)
 if x.func==sp.Add:return sum((ball(y) for y in x.args),arb(0))
 if x.func==sp.Mul:
  z=arb(1)
  for y in x.args:z*=ball(y)
  return z
 if x.func==sp.Pow and x.args[1].is_Integer:return ball(x.args[0])**int(x.args[1])
 if x.func==sp.log:return ball(x.args[0]).log()
 raise ValueError(x)

def st(x):return ball(x).str(35,radius=True)
def rat(x):return sp.Rational(x.numerator,x.denominator) if isinstance(x,F) else sp.Rational(x)

def general_certificates():
 hm,hp=sp.symbols('hm hp',positive=True)
 pm=hm*(hp-1)/(hp-hm);pp=hp*(1-hm)/(hp-hm)
 a=(1-hm)/(hp-hm);b=(hp-1)/(hp-hm)
 for z in [pm+pp-1,pm/hm+pp/hp-1,pp/hp-a,pm/hm-b,a+b-1,a*(hp-1)-b*(1-hm)]:ck(sp.cancel(z)==0)
 # Three spatial regions: inner core, inner annulus, outer annulus.
 ck(sp.cancel(pm/hm+pp/hp-1)==0);ck(sp.cancel(pp/hp-1+b)==0)
 g,delta,tau=sp.symbols('g delta tau',positive=True)
 inward_lhs=1+(1-delta)/g**2-2*(1-delta)*(1-tau)/g
 inward_rhs=delta+(1-delta)*(1-1/g)**2+2*(1-delta)*tau/g
 ck(sp.expand(inward_lhs-inward_rhs)==0)
 sample_hm,sample_hp=F(2,3),F(4,3)
 ck(sample_hm*(sample_hp-1)/(sample_hp-sample_hm)==F(1,3))
 ck(sample_hp*(1-sample_hm)/(sample_hp-sample_hm)==F(2,3))
 return {'assumptions':'0<hminus<1<hplus','pminus':str(pm),'pplus':str(pp),'outer_gain_coefficient':str(a),'inner_loss_coefficient':str(b),'volume_cancellation':'a*(hplus-1)-b*(1-hminus)=0','actual_window_correction':'pminus*S/Rminus^n *1_Qminus*(Wminus-W0) + pplus*S/Rplus^n*1_Qplus*(Wplus-W0)','inward_kernel_identity':{'assumptions':'0<g<=1, 0<=delta<=1, tau=min(log_gamma(m/mprime),1), old mass normalized1','lhs':str(inward_lhs),'rhs':str(inward_rhs),'meaning':'identity only, no new mass/window estimate'},'scope':'exact generic algebra; weighted source annular scores need not cancel'}

def capture(center,R,source):
 a,b=center;l,r=source
 if b-R/2<=l and a+R/2>=r:return 1
 if b+R/2<=l or a-R/2>=r:return 0
 raise AssertionError(('partial source capture',center,R,source))

def model(ratio):
 eps=F(1,1024);U=(-eps,eps);V=(F(7,8)-ratio*eps,F(7,8)+ratio*eps);u=2*eps;v=ratio*u
 blocks=[(F(-1,32),F(1,32)),(F(19,32),F(21,32)),(F(27,32),F(29,32))];masses=[F(3),F(1),F(3)]
 patterns={}
 for name,cent,R,wanted in [('Uminus',U,F(1),[1,0,0]),('Uold',U,F(3,2),[1,1,0]),('Uplus',U,F(2),[1,1,1]),('Vold',V,F(1),[0,1,1])]:
  got=[capture(cent,R,b) for b in blocks];ck(got==wanted)
  mass=sum((m*c for m,c in zip(masses,got)),F(0));density=mass/R
  ck(F(8,3)<=density<=F(16,3));patterns[name]={'radius':R,'mass':mass,'density':density,'captures':got}
 us,vs=rat(u),rat(v);om=1-sp.log(sp.Rational(4,3))/sp.log(4);op=1-sp.log(sp.Rational(7,4))/sp.log(4)
 minus_frozen=sp.Rational(2,3)*us;plus_frozen=sp.Rational(8,9)*us+sp.Rational(4,3)*vs
 old=sp.Rational(16,9)*us+sp.Rational(2,3)*vs
 frozen=minus_frozen+plus_frozen
 outer=vs;inner=sp.Rational(2,9)*us+vs/3
 frozen_gain=frozen-old;ck(sp.expand(frozen_gain-outer+inner)==0)
 correction_minus=(om-1)*minus_frozen;correction_plus=(op-1)*plus_frozen;correction=correction_minus+correction_plus
 actual=om*minus_frozen+op*plus_frozen;gain=actual-old
 ck(sp.expand(gain-frozen_gain-correction)==0);ck(ball(frozen_gain)>0);ck(ball(correction)<0)
 if ratio==1:ck(ball(gain)<0)
 else:ck(ball(gain)>0)
 # Direct source-block old-field integration, all receiver integrals are actual lengths u,v.
 LI=sp.Rational(2,3)*us;LJ=LI+vs;LK=vs
 direct_old=sp.Rational(2,3)*(3*LI+LJ)
 direct_actual=sp.Rational(1,3)*3*LI*om+sp.Rational(1,3)*(3*LI+LJ+3*LK)*op
 ck(sp.expand(old-direct_old)==0);ck(sp.expand(actual-direct_actual)==0)
 Qold=3*LI**2+LJ**2+3*LK**2
 A=sp.Rational(2,3)*om+sp.Rational(8,9)*op-sp.Rational(16,9)
 B=sp.Rational(4,3)*op-sp.Rational(2,3)
 ck(ball(A)<0);ck(ball(B)>0);ck(sp.expand(gain-us*(A+ratio*B))==0)
 C=1+sp.log(8);threshold=1/(1+sp.log(2));Lcap=sp.Rational(2,3)*us+vs
 alphaU=old/(C*sp.Rational(8,3));alphaV=(sp.Rational(2,3)*us+4*vs)/(4*C)
 ck(Lcap<sp.Rational(1,2));ck(ball(Lcap/C)<ball(threshold))
 return {'soft_layer_relevance':{'C':C,'L_infty_exact':Lcap,'alpha_U_exact':alphaU,'alpha_V_exact':alphaV,'alpha_U_arb':st(alphaU),'alpha_V_arb':st(alphaV),'whole_E_alpha_upper_exact':Lcap/C,'whole_E_alpha_upper_arb':st(Lcap/C),'soft_threshold':threshold,'analytic_reason':'alpha<=L_infty/C<L_infty<1/2<1/(1+log2), whole true E; no high-budget validation'},'v_over_u':ratio,'U_center_interval':U,'V_center_interval':V,'u_length':u,'v_length':v,'true_E_measure':u+v,'source_blocks':blocks,'source_masses':masses,'source_densities':[m/(b[1]-b[0]) for m,b in zip(masses,blocks)],'W':7,'radius_window':[1,2],'density_band':[F(8,3),F(16,3)],'band_ratio':2,'patterns':patterns,'Rminus_Rold_Rplus':[1,F(3,2),2],'pminus_pplus':[F(1,3),F(2,3)],'old_mass_window':[1,2],'actual_window_overlap_minus':om,'actual_window_overlap_plus':op,'old_target_score':old,'frozen_mixture_target_score':frozen,'frozen_outer_gain':outer,'frozen_inner_loss':inner,'frozen_net_gain':frozen_gain,'true_window_correction_minus':correction_minus,'true_window_correction_plus':correction_plus,'true_window_correction_total':correction,'actual_mixture_target_score':actual,'actual_net_gain':gain,'actual_net_gain_per_u_arb':st(gain/us),'frozen_net_gain_per_u_exact':sp.factor(frozen_gain/us),'window_correction_per_u_arb':st(correction/us),'actual_score_gain_integral_over_U':us*gain,'original_full_field_Q_exact':Qold,'cross_score_new_field_with_old_L':Qold+us*gain,'gain_threshold_v_over_u_exact':-A/B,'gain_threshold_v_over_u_arb':st(-A/B),'scope':'old L generated by positive-Lebesgue U,V; actual mass windows; not a globally maximal configuration'}

def tent(x):return max(F(0),1-abs(x))
def window_label_algebra():
 starts=[F(0),F(1,3),F(1),F(3,2)];weights=[F(1),F(1,2),F(3,2),F(2,3)];h=F(1,4)
 def corr(shift):return sum((wi*wj*tent(si-sj-shift[j]) for si,wi in zip(starts,weights) for j,(sj,wj) in enumerate(zip(starts,weights))),F(0))
 Q=corr([F(0)]*4)
 near=sum((wi*wj for si,wi in zip(starts,weights) for sj,wj in zip(starts,weights) if abs(si-sj)<=1),F(0))
 cp=sum((wi*wj*tent(si-sj-1) for si,wi in zip(starts,weights) for sj,wj in zip(starts,weights)),F(0))
 cm=sum((wi*wj*tent(si-sj+1) for si,wi in zip(starts,weights) for sj,wj in zip(starts,weights)),F(0))
 ck(near<=Q+cp+cm);ck(cp<=Q and cm<=Q);ck(near<=3*Q)
 for i in range(-24,25):
  x=F(i,8);ck(F(int(abs(x)<=1))<=tent(x)+tent(x-1)+tent(x+1))
 worst=None;best=None
 for shifts in product([-h,F(0),h],repeat=4):
  loss=Q-corr(shifts)
  ck(loss<=h*near);ck(loss<=3*h*Q)
  z=(loss,shifts)
  if worst is None or loss>worst[0]:worst=z
  if best is None or loss<best[0]:best=z
 return {'scope':'finite positive window-weight algebra only; these are not atomic receivers or a substitute for the three true L1 models','starts':starts,'weights':weights,'h':h,'Q':Q,'near_pair_mass_including_boundary':near,'correlation_plus1':cp,'correlation_minus1':cm,'shift_configuration_count':81,'worst_score_loss':worst[0],'worst_shifts':worst[1],'worst_loss_over_hQ':worst[0]/(h*Q),'best_score_loss_may_be_negative':best[0],'best_shifts':best[1],'certified_finite_bound':'Q-<F,F_shift> <=h*Nnear<=3hQ; not an absolute-difference bound','general_mechanism':'positive near-neighbor pair measure <=3Q, then each one-sided tent loss <=h on old near pairs; finite checks do not replace general proof'}

def main():
 start=time.perf_counter();general=general_certificates();models=[model(r) for r in [1,6,12]];window=window_label_algebra()
 for z in models:print('REAL ratio',z['v_over_u'],'frozen gain/u',z['frozen_net_gain_per_u_exact'],'window/u',z['window_correction_per_u_arb'],'actual gain/u',z['actual_net_gain_per_u_arb'],flush=True)
 print('WINDOW finite worst loss/(hQ)',window['worst_loss_over_hQ'],'bound3',flush=True)
 def ser(x):
  if isinstance(x,F):return str(x)
  if isinstance(x,sp.Basic):return str(x)
  raise TypeError(type(x))
 out={'scope':'bounded exact signed-mixture study plus finite independent window-shift algebra; no general extremal/root theorem','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'general_algebra':general,'real_models':models,'finite_window_shift_certificate':window,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r517_numeric.json').write_text(json.dumps(out,default=ser,indent=2)+'\n')
 print('PASS exact annular algebra, three true-L1/Lebesgue models, and finite 3hQ window-loss checks')
if __name__=='__main__':main()
