# R517 来源、计算与研究决策账

起始main a48ea2cf42e3b0f5f8a4749feb6b6a0d4176f1bc，专用clone /Users/zhengzhihao/Math-Research-centered-cube-work，状态干净。前一轮为实质进展：R516证明源格隔离及低score付款，独审并确认远端提交。本轮继续同格高层联合预算，目标未缩小。

沿R513—516真实连续质量窗、原选择器及完整原入口。复用Astra high做几何主证明，Sol high独立先审再核作者，Sol medium做有界精确数值及证书。主代理保同一积分、补双向混合总score门及最终回代；未为凑人数启动Luna。当前无逐Agent实际扣额数据，不猜模型成本。

本轮重读64工具A02，核条件放宽及误差方向；首次在本轮应用F03及其课题接口，核完整场平方的交叉项。只使用正性、Tonelli、Cauchy、有限Hilbert恒等式等直接证明；未引用F03的外部径向Strichartz定理，也未声称该技能提供维数一致HS上界。

本机数学解释器 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python。复现依赖版本在numeric JSON记录。Fraction和SymPy核有理/符号恒等式，python-flint/Arb以256位球算术核具体对数表达式符号。区间证书仅覆盖明确的三个真实模型和所列公式；有限窗label检查只核接口，一般3hQ结论由正文证明。MATLAB本轮未使用，无安装，无PDF编译。

第516轮tensor族全部soft，已停止扩扫。第517轮三个真实中心包用于核两壳收益经过真实质量窗后的符号，不能作为未付hard层预算证明；本轮改变硬层攻坚条件的是一般全场移窗定理。总窗损失只收一次3hQg，不能按候选或分层重收。新固定比例质量首达保α权，实际软平方与同格壳来源重复尚未付。

对第486轮后建议维持已记录边界：逐代能量与累计费、链和静态场不互相无价移植。本轮不重新认证486历史链，也不把此次新静态引理称为那个链的累计付款。

根代理隔离重放正文代码和numeric，JSON规范比对仅排顶层seconds，其他结果字段及stdout均严格匹配；归档解压后再次复现并核SHA清单。实际命令为指定Python运行/tmp/replay_r517.py，归档脚本/tmp/package_r517.py。外部运行脚本只负责抽取与重放，包内保留全部数学计算源码及replay记录。
