from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import combinations,product
from math import factorial
from pathlib import Path
import json

def vol(box):
 z=F(1)
 for a,b in box:z*=max(F(0),b-a)
 return z

def intersection(boxes):return tuple((max(b[j][0] for b in boxes),min(b[j][1] for b in boxes)) for j in range(len(boxes[0])))
def union_volume(boxes):
 boxes=[b for b in boxes if vol(b)>0]
 if not boxes:return F(0)
 if len(boxes[0])==1:
  cuts=sorted({v for b in boxes for v in b[0]});return sum((r-l for l,r in zip(cuts,cuts[1:]) if any(a<=(l+r)/2<=b for ((a,b),) in boxes)),F(0))
 cuts=sorted({v for b in boxes for v in b[0]});return sum(((r-l)*union_volume([b[1:] for b in boxes if b[0][0]<=(l+r)/2<=b[0][1]]) for l,r in zip(cuts,cuts[1:])),F(0))
def ie_volume(boxes):
 return sum(((-1)**(s+1)*vol(intersection(c)) for s in range(1,len(boxes)+1) for c in combinations(boxes,s)),F(0))
def inside(x,box):return all(a<xj<b for xj,(a,b) in zip(x,box))
def direct_hit(x,ys,caps,k):
 entries=[max(F(1),2*max(abs(xj-yj) for xj,yj in zip(x,y))) for y in ys]
 cuts=sorted({F(1),F(2)}|{e for e in entries if 1<=e<=2}|{c for c in caps if 1<=c<=2})
 times=cuts+[(a+b)/2 for a,b in zip(cuts,cuts[1:])]
 return any(sum(e<=t<c for e,c in zip(entries,caps))>=k for t in times)
def geometry():
 rows=[]
 for n in (1,2,3):
  for kind in range(3):
   ys=[tuple(F(((i+1)*(j+2)+kind*i*i)%7-3,5+kind) for j in range(n)) for i in range(5)]
   if kind==0:ys=[(F(0),)*n]*5 # coincident spike
   if kind==2:ys=[tuple(F(i,10) if j==i%n else F(0) for j in range(n)) for i in range(5)]
   caps=[F(6+i,5) for i in range(4)]+[F(11,5)]
   for k in (2,3,4):
    boxes=[]
    for inds in combinations(range(5),k):
     c=min([F(2)]+[caps[i] for i in inds]);box=tuple((max(ys[i][j] for i in inds)-c/2,min(ys[i][j] for i in inds)+c/2) for j in range(n))
     assert vol(box)==__import__('functools').reduce(lambda a,b:a*b,[max(F(0),c-max(ys[i][j] for i in inds)+min(ys[i][j] for i in inds)) for j in range(n)],F(1))
     if vol(box)>0:boxes.append(box)
    uv=union_volume(boxes);assert uv==ie_volume(boxes)
    # Receiver points avoid all witness-box faces, so strict boundaries agree.
    cuts=[sorted({v for b in boxes for v in b[j]}) for j in range(n)]
    pts=[[(a+b)/2 for a,b in zip(c,c[1:])] for c in cuts]
    checked=0
    for x in product(*pts):
     assert any(inside(x,b) for b in boxes)==direct_hit(x,ys,caps,k)
     checked+=1
    rows.append(dict(n=n,family=kind,k=k,union_volume=str(uv),tuple_sum=str(sum(map(vol,boxes),F(0))),receiver_cells=checked))
 return rows

def extrema():
 rows=[]
 for k in (2,3,4,8,16,32,64):
  n=k*k;distinct=F(1)
  for j in range(k):distinct*=F(n-j,n)
  ratio=F(k-1,k)**k
  assert distinct>=F(1,2) and ratio>=F(1,4)
  # k distinct axis locations: removing each uniquely maximal point
  # frees its coordinate by a/k (at k=2 the other coordinate also
  # becomes constant). This checks the actual volume gain.
  remaining=F(1) if k==2 else F(k-1,k)**(k-1)
  gain=remaining-ratio
  assert gain>=F(1,k)*F(k-1,k)**(k-1)>0
  rows.append(dict(n=n,k=k,distinct_probability=str(distinct),intersection_fraction=str(ratio),deletion_gain=str(gain)))
 return rows

def tail(q,k):
 term=(-q).exp()
 for j in range(1,k+1):term*=q/j
 total=term;j=k
 while term>total*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;total+=term
 return total

def analytic_guards(precision):
 with localcontext() as ctx:
  ctx.prec=precision;out=[];mult=[]
  for m in (1,2,4,8,16,64,256,1024):
   k=m+1;fac=D(m)**k/D(factorial(k));assert fac>0
   mult.append(dict(m=m,tuple_factor=format(fac,'.16g'),log_tuple_factor=format(fac.ln(),'.16g')))
  for n in (1024,4096,65536,1048576,16777216):
   nd=D(n);T=nd*D(2).ln();U=2+T
   minm=int((64*U.ln()).to_integral_value(rounding='ROUND_CEILING'))
   choices=sorted({minm,int(nd.sqrt().to_integral_value(rounding='ROUND_CEILING')),4*minm})
   for m in choices:
    if m<minm:continue
    md=D(m);root=md.sqrt();ell=(4*m)//5
    # Worst ends of the actual negative-face axial receiver event.
    qcoeff=D('1.35');theta_max=(1+1/(50*root))/D('1.30')
    theta_width=1/(50*qcoeff*root)
    birth=(D('.5')+D('.01')/root)*(nd/D('.65'))**(1/nd)
    endpoint_birth_log=theta_max.ln()+nd.ln()+(1-nd)*D(2).ln()
    assert theta_max<1 and theta_width>=1/(70*root)
    assert birth<D('.6') and endpoint_birth_log<D('.6').ln()
    survival_error=D('.6')*md*T*D('.75')**(m-ell)
    assert survival_error<D('.125')
    # pi_m(m+sqrt(m)/50)/pi_m(m), and a self-contained mode bound.
    ss=root/50;mode=(-md).exp()*md**m/D(factorial(m))
    ratio=(md*(1+ss/md).ln()-ss).exp()
    assert mode>=3/(20*root) and ratio>=D('.5')
    lower_col=3*T/D(44800000)
    # Box halfwidth R=100*n*b -> interior ratio (1-1/(200n))^n.
    interior=(1-1/(200*nd))**n;pk=tail(md,m+1)
    assert pk>=D(1)/16
    envelope_ratio=(1+T)*interior*pk
    low_noise_bound=(md/(md+1)+md*T)*(-md/8).exp()
    assert low_noise_bound<1
    out.append(dict(n=n,m=m,min_m=minm,T=format(T,'.16g'),theta_width_lower=format(theta_width,'.16g'),birth_upper=format(birth,'.16g'),survival_error=format(survival_error,'.16g'),poisson_mode=format(mode,'.16g'),pivotal_column_lower=format(lower_col,'.16g'),candidate_m_plus_T_over_m=format(md+T/md,'.16g'),envelope_weak_ratio_lower=format(envelope_ratio,'.16g'),true_noise_low_value_bound=format(low_noise_bound,'.16g')))
  large=[]
  for exponent in (24,40,64,80,96):
   n=2**exponent;m=2**(exponent//2);nd=D(n);md=D(m);T=nd*D(2).ln()
   assert md>=64*(2+T).ln()
   lower=3*T/D(44800000);proposal=md+T/md
   large.append(dict(n_power_two=exponent,m_power_two=exponent//2,proven_column_lower=format(lower,'.16g'),candidate_scale=format(proposal,'.16g'),ratio_lower=format(lower/proposal,'.16g'),note='analytical lower-bound arithmetic only; no factorial or probability underflow'))
  assert D(large[-1]['ratio_lower'])>D('1e6')
  return dict(parameter_guards=out,tuple_multiplicity=mult,large_dimension=large)


def priority_checks():
 rows=[]
 for n in (1,2,4):
  for k in (2,3,4):
   # Two disjoint physical-time witness groups, all from actual axial sites.
   ys=[(F(0),)*n]*k+[(F(3,4),)+(F(0),)*(n-1)]*k
   caps=[F(5,4)]*k+[F(11,5)]*k;N=len(ys);x=(F(0),)*n
   hit={mask:direct_hit(x,[y for i,y in enumerate(ys) if mask>>i&1],[c for i,c in enumerate(caps) if mask>>i&1],k) for mask in range(1<<N)}
   deleted={mask:sum(hit[mask] and not hit[mask^(1<<i)] for i in range(N) if mask>>i&1) for mask in hit}
   assert hit[(1<<N)-1] and deleted[(1<<N)-1]==0
   for theta in (F(1,5),F(1,2),F(4,5)):
    prob=derivative=piv=F(0)
    for mask,H in hit.items():
     size=mask.bit_count();w=theta**size*(1-theta)**(N-size)
     prob+=w*H;derivative+=w*H*(size/theta-(N-size)/(1-theta));piv+=w*deleted[mask]
    assert theta*derivative==piv and 0<=piv<=k*prob
    assert prob==1-(1-theta**k)**2
    rows.append(dict(n=n,k=k,theta=str(theta),hit_probability=str(prob),expected_pivotal=str(piv),full_config_pivotal=0))
 return rows

if __name__=='__main__':
 g=geometry();e=extrema();pr=priority_checks();p=analytic_guards(70);assert p==analytic_guards(110)
 result=dict(status='PASS; square-root general bound remains unproved',geometry=g,essential_extrema=e,priority=pr,**p,notes=['All geometric cells and volumes use Fraction; actual finite marks and one shared spatial source per configuration.','Poisson/rate coefficients repeated at Decimal70/110 and recorded at 16 digits, not interval proofs.','Pivotal column constants are rigorous analytical lower bounds; listed finite dimensions do not establish asymptotic growth by fitting.','Homogeneous-envelope example is finite L1; original deterministic maximal set at threshold lambda is empty.','No random sampling; no seeds.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(g),'witness unions;',sum(r['receiver_cells'] for r in g),'receiver cells;',len(e),'extrema;',len(p['parameter_guards']),'parameter guards;',len(p['tuple_multiplicity']),'multiplicity;',len(pr),'priority;',len(p['large_dimension']),'large-dimension checks')
