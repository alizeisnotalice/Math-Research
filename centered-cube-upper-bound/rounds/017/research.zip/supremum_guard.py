"""Exact geometry plus enumerated shared-sign finite-perturbation checks.
Decimal checks are high-precision evidence, not interval certificates.
No observed dimension trend is used to assert a uniform upper bound.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from pathlib import Path
import json
import random


def decimal(q): return D(q.numerator)/D(q.denominator)


def render(q): return '0' if q.is_zero() else format(q,'.25g')


def candidates(atoms,x):
    n=len(x)
    radii=[2*max(abs(a-b) for a,b in zip(y,x)) for y,w in atoms]
    rows=[]
    for r in sorted({F(1),F(2)}|{r for r in radii if 1<=r<=2}):
        S=tuple(i for i,v in enumerate(radii) if v<=r)
        m=sum((atoms[i][1] for i in S),F(0))
        if m: rows.append({'r':r,'S':S,'m':m,'U':m/r**n})
    assert rows
    # Largest maximizing radius, chosen before the random source perturbation.
    R=max(range(len(rows)),key=lambda j:(rows[j]['U'],rows[j]['r']))
    return rows,R


def fixtures():
    for n in [2,4,8,16,32,64]:
      for N in [3,5,8]:
        rr=[F(1)+F(3*j,4*(N-1)) for j in range(N)]
        weights=[rr[0]**n]+[rr[j]**n-rr[j-1]**n for j in range(1,N)]
        atoms=[((r/2,)+(F(0),)*(n-1),w) for r,w in zip(rr,weights)]
        for shift in [F(0),-F(1,10000*n)]:
          x=(shift,)+(F(0),)*(n-1)
          yield f'prefix_n{n}_N{N}_x{shift}',atoms,x,list(range(N))
    # Correlated coordinates, unequal weights, and a repeated physical label.
    for n in [2,4,8]:
      rng=random.Random(17000+n)
      atoms=[(tuple(F(rng.randrange(-8,9),8) for _ in range(n)),F(rng.randrange(1,10),7)) for i in range(5)]
      atoms.append((atoms[0][0],F(2,7)))
      x=atoms[0][0]
      # Coincident source labels share the same physical-cell sign.
      labels=[0,1,2,3,4,0]
      yield f'correlated_n{n}',atoms,x,labels
    n=4;rr=[F(1),F(5,4),F(7,4)]
    atoms=[((r/2,)+(F(0),)*(n-1),r**n-(rr[i-1]**n if i else 0)) for i,r in enumerate(rr)]
    yield 'strict_adaptation',atoms,(-F(1,100000),)+(F(0),)*(n-1),[0,1,2]


def run(precision):
  report={'precision':precision,'rows':[],'sign_cases':0,'eligible_exclusions':0}
  with localcontext() as ctx:
    ctx.prec=precision
    tolerance=D(10)**(-precision+8)
    for name,atoms,x,labels in fixtures():
      for i,(y,w) in enumerate(atoms):
        for j,(z,ww) in enumerate(atoms):
          assert y!=z or labels[i]==labels[j]
      rows,R=candidates(atoms,x);original=rows[R];H=original['U']
      gaps=[decimal(H/u['U']).ln() for u in rows]
      qs=[]
      for u in rows:
        A,B=set(u['S']),set(original['S'])
        assert A<=B or B<=A
        q=min(u['m'],original['m'])/max(u['m'],original['m'])
        qs.append(q)
      count=max(labels)+1
      for tt in [F(1,8),F(1,2),F(3,4)]:
        t=decimal(tt);c=decimal(tt/(1+tt))
        means=[D(0)]*len(rows);adaptive=D(0);minus=D(0);min_residual=D('Infinity')
        exact_gain_sum=D(0)
        for signs in product([-1,1],repeat=count):
          pp=[sum((atoms[i][1]*signs[labels[i]] for i in u['S']),F(0))/u['m'] for u in rows]
          pr=pp[R]
          plusvals=[max(D(0),c*decimal(p-pr)-g) for p,g in zip(pp,gaps)]
          minusvals=[max(D(0),c*decimal(pr-p)-g) for p,g in zip(pp,gaps)]
          gp,gm=max(plusvals),max(minusvals)
          Mplus=max(u['U']*(1+tt*p) for u,p in zip(rows,pp))
          Mminus=max(u['U']*(1-tt*p) for u,p in zip(rows,pp))
          exact_plus=decimal(Mplus/(H*(1+tt*pr))).ln()
          exact_minus=decimal(Mminus/(H*(1-tt*pr))).ln()
          assert exact_plus+tolerance>=gp and exact_minus+tolerance>=gm
          # tau=H/2 at this check point. Retain log_+ clipping exactly.
          lhs=max(D(0),decimal(2*Mplus/H).ln())+max(D(0),decimal(2*Mminus/H).ln())-2*D(2).ln()
          rhs=decimal(1-tt*tt*pr*pr).ln()+gp+gm
          residual=lhs-rhs
          assert residual>=-tolerance
          min_residual=min(min_residual,residual)
          for j,(p,q,g) in enumerate(zip(pp,qs,gaps)):
            assert abs(p-pr)<=2*(1-q)
            if g>=2*c*decimal(1-q)+tolerance:
              assert plusvals[j]<=tolerance and minusvals[j]<=tolerance
              report['eligible_exclusions']+=1
          means=[s+v/(2**count) for s,v in zip(means,plusvals)]
          adaptive+=gp/(2**count);minus+=gm/(2**count)
          exact_gain_sum+=(exact_plus+exact_minus)/(2**count)
          report['sign_cases']+=1
        assert abs(adaptive-minus)<=tolerance
        assert adaptive+tolerance>=max(means)
        if name=='strict_adaptation': assert adaptive>max(means)+D('.001')
        report['rows'].append({'fixture':name,'n':len(x),'source_labels':len(atoms),
          'physical_signs':count,'t':str(tt),'positive_candidates':len(rows),
          'adaptive_one_sided_mean':render(adaptive),
          'best_fixed_one_sided_mean':render(max(means)),
          'strict_improvement':render(adaptive-max(means)),
          'exact_two_sided_log_gain_mean':render(exact_gain_sum)})
    # Bare arrival gate and finite-t optimization are exact algebraic guards.
    report['bare_arrival_checks']=0
    for delta in [F(1,1000000),F(1,100),F(1,4),F(3,4),F(99,100)]:
      for tt in [F(1,100),F(1,8),F(1,2),F(9,10)]:
        assert -decimal(1-delta).ln()>decimal(delta)>decimal(2*tt/(1+tt)*delta)
        report['bare_arrival_checks']+=1
    report['optimization_checks']=0
    for k in range(0,21):
      s=F(1,2**k);a=s*s;t=s/2
      coefficient=(1+t)/t*(a+3*t*t/(1-t*t))
      assert coefficient<=6*s
      report['optimization_checks']+=1
  return report


if __name__=='__main__':
  low,high=run(60),run(90)
  assert low['rows']==high['rows']
  high['precision_check']='60 and 90 digits; all stored 25-significant-digit outputs agree'
  high['status']='finite checks passed; no spatial nearmax lower bound established'
  Path(__file__).with_name('results.json').write_text(json.dumps(high,indent=2)+'\n')
  print(json.dumps({k:high[k] for k in ['sign_cases','eligible_exclusions','bare_arrival_checks','optimization_checks','status']}))
