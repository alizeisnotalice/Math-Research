from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json

def slope(B,A,r,t):
 if A==0:return F(0)
 if B<=t<B+r*A:return 1-r
 if B+r*A<=t<B+A:return -r
 return F(0)
scalar=[]
for A in map(F,['1','3/2','8']):
 count=boundary=0
 for B,r in product(map(F,['0','1/4','1']),map(F,['1/8','1/2','7/8'])):
  mean=B+r*A;top=B+A
  ts={B,mean,top,(B+mean)/2,(mean+top)/2,top+1}
  if B:ts.add(B/2)
  for t in ts:
   if t<=0:continue
   assert slope(B,A,r,t)==F(mean>t)-r*F(top>t)-(1-r)*F(B>t)
   count+=1;boundary+=t in (B,mean,top)
 scalar.append({'A':str(A),'checks':count,'breakpoints':boundary})
rows=[]
models=[]
for n in [1,2,3]:
 points=list(product([F(-1,4),F(1,4)],repeat=n));models.append((f'vertices_n{n}',points,[1]*len(points)))
for n in [1,2,3]:
 points=[tuple(F(((i+1)*(j+2))%7-3,4) for j in range(n)) for i in range(4)]
 assert len(set(points))==4
 models.append((f'correlated_weighted_n{n}',points,[1,2,3,5]))
for name,points,weights in models:
 n=len(points[0]);N=len(points);W=sum(weights);weights=tuple(F(w,W) for w in weights);Ls=[F(1),F(3,2),F(2)]
 cuts=[sorted({y[j]+sign*L/2 for y in points for sign in [-1,1] for L in Ls}) for j in range(n)]
 patterns=defaultdict(F);cells=0
 for ids in product(*(range(len(c)-1) for c in cuts)):
  x=[(cuts[j][k]+cuts[j][k+1])/2 for j,k in enumerate(ids)];vol=F(1)
  for j,k in enumerate(ids):vol*=cuts[j][k+1]-cuts[j][k]
  masks=tuple(tuple(i for i,y in enumerate(points) if all(abs(xx-yy)<L/2 for xx,yy in zip(x,y))) for L in Ls)
  patterns[masks]+=vol;cells+=1
 volume=F(1)
 for c in cuts:volume*=c[-1]-c[0]
 assert sum(patterns.values())==volume
 def response(state,masks,tie):
  vs=tuple(sum((state[i] for i in mask),F(0))/L**n for mask,L in zip(masks,Ls));H=max(vs)
  k=vs.index(H) if tie=='first' else max(i for i,v in enumerate(vs) if v==H)
  return H,k,vs
 for tree,tie in product(['balanced','sequential'],['first','last']):
  ops=[]
  def build(ids):
   if len(ids)==1:return
   k=len(ids)//2 if tree=='balanced' else len(ids)-1
   l,r=ids[:k],ids[k:];build(l);build(r);ops.append((l,r))
  build(list(range(N)))
  for t in map(F,['1/32','1/8','1/2','1']):
   states={weights:F(1)};up=down=gain=F(0);checks=0
   for left,right in ops:
    nxt=defaultdict(F)
    for state,prob in states.items():
     i=next(i for i in left if state[i]);j=next(j for j in right if state[j]);p=state[i]/(state[i]+state[j]);q=1-p
     sy=list(state);sy[i]+=sy[j];sy[j]=0;sy=tuple(sy)
     sz=list(state);sz[j]+=sz[i];sz[i]=0;sz=tuple(sz)
     nxt[sy]+=prob*p;nxt[sz]+=prob*q
     for masks,vol in patterns.items():
      H,k,_=response(state,masks,tie);Hy,_,vy=response(sy,masks,tie);Hz,_,vz=response(sz,masks,tie)
      fy,fz=vy[k],vz[k];B=min(fy,fz);A=abs(fy-fz);r=p if fy>=fz else q
      assert H==p*fy+q*fz and Hy>=fy and Hz>=fz
      s=slope(B,A,r,t);R=p*(int(Hy>t)-int(fy>t))+q*(int(Hz>t)-int(fz>t));assert R>=0
      assert int(H>t)-p*int(Hy>t)-q*int(Hz>t)==s-R
      up+=prob*vol*t*max(s,0);down+=prob*vol*t*max(-s,0);gain+=prob*vol*t*R;checks+=1
    states=dict(nxt);assert sum(states.values())==1
   initial=sum((vol*t*int(response(weights,masks,tie)[0]>t) for masks,vol in patterns.items()),F(0))
   terminal=F(0)
   for st,prob in states.items():
    assert max(st)==1 and sum(st)==1
    i=st.index(1);assert prob==weights[i]
    terminal+=prob*sum((vol*t*int(response(st,masks,tie)[0]>t) for masks,vol in patterns.items()),F(0))
   exact_atom=t*max([L**n for L in Ls if 1/L**n>t],default=F(0));assert terminal==exact_atom
   assert initial-terminal==up-down-gain
   rows.append(dict(model=name,n=n,N=N,tree=tree,tie=tie,threshold=str(t),cells=cells,patterns=len(patterns),checks=checks,initial=str(initial),terminal=str(terminal),up=str(up),down=str(down),reselection=str(gain),deficit=str(initial-terminal)))
for name,_,_ in models:
 for t in ['1/32','1/8','1/2','1']:
  group=[r for r in rows if r['model']==name and r['threshold']==t]
  assert len({r['deficit'] for r in group})==1
plateau=[]
for exponent in [4,12,24]:
 m=F(1,2**exponent)
 for h in [F(1,8),F(1,4),F(1,2)]:
  points=[F(k) for k in range(-2,3)]+[-h/2,h/2]
  base=[1-m/4]*5
  original=base+[m/2,m/2];after_y=base+[m,F(0)];after_z=base+[F(0),m]
  cuts=sorted({y+sgn*F(1,2) for y in points for sgn in [-1,1]})
  def weak(ws):
   ans=F(0)
   for l,r in zip(cuts,cuts[1:]):
    x=(l+r)/2;value=sum((w for y,w in zip(points,ws) if abs(x-y)<F(1,2)),F(0))
    ans+=(r-l)*int(value>1)
   return ans
  before=weak(original);after=(weak(after_y)+weak(after_z))/2
  assert before==1+h and after==1 and before-after==h
  assert sum(original)==5-m/4
  plateau.append({'m':str(m),'h':str(h),'total_mass':str(sum(original)),'before':str(before),'expected_after':str(after),'deficit':str(before-after),'deficit_over_m_distance':str((before-after)/(m*2*h))})
continuous=[]
for exponent in [4,6,8]:
 m=F(1,2**exponent);c=1-m/4;K=32*2**exponent;L=F(7,4);h=F(1,2)
 bg_upper=c+c/K;captured_lower=c-c/K+m/(2*L)
 assert bg_upper<1 and captured_lower>1
 counts=[]
 for phase in [F(0),F(1,6),F(1,3),F(2,3)]:
  x=phase/K;lo=K*(x-L/2)-F(1,3);hi=K*(x+L/2)-F(1,3)
  left=-((-lo.numerator)//lo.denominator);right=hi.numerator//hi.denominator
  count=right-left+1
  assert L*K<=count<=L*K+1
  counts.append(count)
 assert L+h-2==F(1,4)
 continuous.append({'m':str(m),'K':K,'background_atoms':10*K,'source':'(c/K) sum_{k=-5K}^{5K-1} delta_((k+1/3)/K) + (m/2)(delta_-1/4+delta_1/4)','total_mass':str(10*c+m),'background_uniform_upper':str(bg_upper),'fixed_scale':str(L),'captured_uniform_lower':str(captured_lower),'phase_counts':counts,'initial_weak_lower':'9/4','after_weak_upper':'2','continuous_window_deficit_lower':'1/4','scope':'rational verification of analytic uniform count bounds; not numerical integration of the continuous maximum'})
print(json.dumps({'status':'PASS','scope':'full Lebesgue cell integration, finite scales only; no asymptotic inference','scalar_rounds':scalar,'experiments':rows,'plateau_counterexamples':plateau,'continuous_window_certificates':continuous},indent=2))
