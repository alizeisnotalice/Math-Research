# R484：原输入的首次出层消元与跨层质量通量

本稿沿 R483 的实际父状态核 \(K\)：每一步重新抽当前父的原条件记录、人工来源和标记；原场 \(f,m,q,t\) 全部冻结。仅讨论这个合法分析过程的停止总账，不把刷新记录称为旧历史延续。以下给出原输入 \(\nu=t\sigma\) 的准确首次进入公式，并定位原一次对数质量费为何不能直接支付累计跨层通量。没有新增根阶付款。

## 1. 层内消元保留什么

在一个原来不允许跨越的质量带内，按对数质量从高到低分成 \(E_0,\ldots,E_{J-1}\)，层宽至多 \(d>0\)。质量原子整体置于唯一一层，端点采用不交的半开约定。不同原质量带分别处理，最后相加，不在它们之间添加边。

记 \(K_{hi}=1_{E_h}K1_{E_i}\)。质量非增意味着只有 \(i\ge h\) 的块可能非零。采用本轮主几何稿证明的真实窗口界：
\[
D=\operatorname{diag}(K_{ii}),\quad
D1\le c,\quad \nu D\le c\nu,
\qquad c=\frac{rS}{T}(1+d)<1.
\]
这来自实际中心 CDF 与完整匹配，不是对来源切片另假密度帽。置
\[
G=(I-D)^{-1},\qquad F=K-D,\qquad P=GF,
\qquad e=1-K1,\qquad g=Ge. \tag{1}
\]
\(P_{hi}=G_hK_{hi}\) 是**从层 \(h\) 首次成功退出至层 \(i>h\)**的次概率核；它包含任意次同层成功跳转。\(g_h\) 是在退出前实际杀死的概率。因为同层生存概率至多 \(c^j\)，没有漏掉“永远留在该层”的终端，故
\[
g=1-P1,\qquad P^J=0. \tag{2}
\]
每个乘积均可按原 \(K\) 的条件路径展开：层内与退出步各自保留当前原记录接受门。不能用一个未经筛选的退出点给所有中间记录继承资格。零质量层不贡献。

## 2. 从原 \(\nu\) 出发的首入量，及其与压缩参考的区别

令 \(\eta_i\) 为从原 \(\nu\) 出发首次进入层 \(i\) 的有限测度，包含初始就在该层的质量。递推恰为
\[
\boxed{\eta_i=\nu_i+
 \sum_{h<i}\eta_hG_hK_{hi}.} \tag{3}
\]
跨越若干层的边在(3)中直接进入其真实目标层；没有给跳过的层制造中间父。矩阵形式为
\[
\eta=\nu(I-P)^{-1},\qquad
\mathcal V:=\sum_{j\ge0}\nu K^j=\eta G. \tag{4}
\]
证明只需 \(I-K=(I-D)(I-P)\)；右侧 \((I-P)^{-1}\) 是有限和。同层 Green 有界，因此所有这些测度有限。原精确停止账为
\[
R=\sum_i\int g_i\,d\eta_i
  =\int e\,d\mathcal V. \tag{5}
\]

本轮主稿采用的共同压缩参考是
\[
\widetilde\nu=\nu(I-D),\qquad
(1-c)\nu\le\widetilde\nu\le\nu,
\quad \widetilde\nu G=\nu,
\quad\widetilde\nu P\le\widetilde\nu.
\]
其首入量 \(\widetilde\eta=\widetilde\nu(I-P)^{-1}\) 与原首入量并不相等。准确差额和比较是
\[
\boxed{\eta-\widetilde\eta=
 \nu D(I-P)^{-1}\ge0,
\qquad
\widetilde\eta\le\eta\le(1-c)^{-1}\widetilde\eta.} \tag{6}
\]
这是同一个实际 \(P\) 上的初始质量差，而不是重新生成原接受权。尤其
\[
\int g\,d\widetilde\nu=\int e\,d\nu \tag{7}
\]
保证**所有层合并后的一次停止费仍恰为原一次费**，没有按层重收 \(W\)。不过(5)使用的是 \(\eta\)，而不是 \(\widetilde\nu\)。主稿的停止深度界正是在估计这个区别；(7)本身不能消去它。

## 3. 非邻层跳跃的完整 cut 守恒

定义原刷新过程的全部有向边占用
\[
\mathcal T(dA,dB)=\mathcal V(dA)K(A,dB),
\qquad \mathcal S(dA)=e(A)\mathcal V(dA).
\]
\(\mathcal S(E)=R\) 是真实最终停止分布。对任意 \(s>0\)，质量非增给
\[
\boxed{\mathcal T\{m_B\le s<m_A\}
=\nu\{m_A>s\}-\mathcal S\{m_A>s\}.} \tag{8}
\]
证明先在有限时间把指标 \(1_{m>s}\) 逐步相减；右侧还含未停止到达量的高侧质量，取极限该项为零。原子用式中闭/开端点处理，无“跨过质量原子就免费”的例外。

若层边界为 \(s_b\)，从层 \(h\) 跳到 \(i>h\) 在所有 \(i-h\) 个被跨边界中各记一次。于是
\[
\sum_b\mathcal T\{m_B\le s_b<m_A\}
=\sum_b[\nu\{m>s_b\}-\mathcal S\{m>s_b\}]. \tag{9}
\]
这与(3)的“只进入真实目标层一次”并不矛盾：首次进入数和跨 cut 数是不同费用。

对连续质量阈值使用非负 Tonelli，可精确保留真实对数跳距：
\[
\begin{aligned}
\int\log\frac{m_A}{m_B}\,d\mathcal T
&=\int_{m_-}^{m_+}
 [\nu\{m>s\}-\mathcal S\{m>s\}]\frac{ds}{s}\\
&=\int\log\frac m{m_-}\,d\nu
 -\int\log\frac m{m_-}\,d\mathcal S
\le D_mR,
\end{aligned}\tag{10}
\]
其中 \(m_-=qa^n\)、\(m_+=\lambda b^n\)、\(D_m=\log(m_+/m_-)\)。停止项为非负，保留它合法；直接舍去只得到 \(D_mR\)，不是 \(D_mW\)。

## 4. 半径/质量一次费不能直接变成累计费

令原实际一步奖励
\[
j(A)=\int K(A,dB)\log(m_A/m_B)\ge0.
\]
R479 的真实 PPP 层积分可在原参考上给
\(\int j\,d\nu\le TD_mW\)，全部成功正限制保留。消元后这个**一次价**精确保为
\[
\int Gj\,d\widetilde\nu=\int j\,d\nu\le TD_mW. \tag{11}
\]
但完整跨过程奖励是
\[
\int j\,d\mathcal V=\int Gj\,d\eta,
\tag{12}
\]
等于(10)。从(11)到(12)仍需控制原实际首入量在 \(Gj\) 大的父上的集中；\(\eta\) 不是 \(\widetilde\nu\) 的免费常数倍。仅有(6)仍留下 \(\widetilde\eta\) 的跨层 Green。

半径同样保实际 \(q_A\)：
\[
\log\frac{R_A}{R_B}
=\frac1n\left(\log\frac{m_A}{m_B}
 +\log\frac{q_B}{q_A}\right),
\quad
\left(\log\frac{R_A}{R_B}\right)_+
\le\frac1n\log\frac{m_A}{m_B}+\frac{\log r}{n}.
\]
后一个常数须乘真实边占用次数；不能只收一次。沿全路径求有符号半径变化确可望远镜，但它不是原所需的非负错误费用，也不自动抵消停止量。

因此本机制可严谨地消去同层循环并共享一次来源价，却尚不能把原停止配对付成根阶。最窄缺步是：利用原成功几何或接受门，为(5)或(12)中的**实际首入加权积分**提供比层深度上界更好的共同来源预算。单步对数质量费、邻层数量或对非邻层跳只记一次，均未给出这种比较。不另命名一个余项作为新成果。

## 5. 已执行的有理核验

指定本机 Python/SymPy 实跑以下脚本，输出：

```text
PASS 45 exact rational assertions: original-entry recursion, common-reference comparison, stop and cut flux; abstract kernel audit, not native-history simulation.
```

三个有理强度、六状态、三质量层；含同层循环和跨两层直接跳跃。检查首入递推、原/压缩参考差额、停止及逐 cut 守恒。它是有限算子代数核验，不模拟原生完整成功历史，不替代上述测度证明。

```python
import sympy as s
checks=0
for a in [s.Rational(1,40),s.Rational(1,30),s.Rational(1,20)]:
    n=6; one=s.ones(n,1); nu=s.ones(1,n); eye=s.eye(n)
    block=[2,2,1,1,0,0]
    K=s.Matrix(n,n,lambda i,j:a*(1+(i+j)%3) if j<=i else 0)
    assert all(v<=1 for v in K*one); checks+=1
    assert all(v<=1 for v in nu*K); checks+=1
    D=s.Matrix(n,n,lambda i,j:K[i,j] if block[i]==block[j] else 0)
    G=(eye-D).inv(); P=G*(K-D)
    w=nu*(eye-D); e=one-K*one; d=G*e
    assert w*G==nu; checks+=1
    assert all(v>=0 for v in w-w*P); checks+=1
    assert d==one-P*one; checks+=1
    assert (w*d)[0]==(nu*e)[0]; checks+=1
    assert P**3==s.zeros(n); checks+=1
    eta=nu*(eye-P).inv(); occ=nu*(eye-K).inv()
    etaw=w*(eye-P).inv()
    assert eta*G==occ; checks+=1
    assert eta-etaw==nu*D*(eye-P).inv(); checks+=1
    for i in range(3):
        ii=[j for j in range(n) if block[j]==i]
        rhs=nu.extract([0],ii)
        for h in range(i):
            hh=[j for j in range(n) if block[j]==h]
            rhs+=eta.extract([0],hh)*G.extract(hh,hh)*K.extract(hh,ii)
        assert rhs==eta.extract([0],ii); checks+=1
    stop=s.Matrix(1,n,lambda i,j:occ[j]*e[j])
    assert (stop*one)[0]==n; checks+=1
    for k in [0,1]:
        cross=sum(occ[i]*K[i,j] for i in range(n) for j in range(n)
                  if block[i]<=k<block[j])
        diff=sum(nu[i]-stop[i] for i in range(n) if block[i]<=k)
        assert cross==diff; checks+=1
print(f'PASS {checks} exact rational assertions: original-entry recursion, common-reference comparison, stop and cut flux; abstract kernel audit, not native-history simulation.')
```
