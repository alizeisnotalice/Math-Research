# R484 FINAL PASS（仅限质量窗消元与完整停止深度账）

独立预审先于作者稿，终审核对全部七项冻结输入。PASS 认证实际父刷新核的原子安全窗行列帽、首次退出消元、补偿参考及深度停止界；不认证根阶总预算，一般目标仍未闭合。

真实CDF的闭窗积分必须保下端G(a−)，由此原未共轭K的窗行/相对ν列≤(rS/T)(1+L)，没有e^L费用。D为完整同窗块，G=(I−D)⁻¹，首次退出必须P=GF；ν̃=ν(I−D)为正，ν̃G=ν、ν̃P≤ν̃。原初值仍为ν，故恢复须付(1−c)⁻¹。逐原不可跨带从最高窗重新计深度，任意跳窗、同窗循环、终止与质量端点均保留，得到所述加权停止界。

闭prefix的uniform mark完整包含质量原子；原PPP空点e₀的深度层和精确，不能把数值raw-count模型的e当e₀。其现有粗来源价仍含8rS D_mW，非空停止也保深度；一次来源费未被当作累计占用价。互补稿准确区分原首入量、补偿参考及跨cut次数，保最终停止分布的负项。原母账、真实接受门及未付首入/来源费用未被删除，刷新记录不继承上一步旧history。

实际独立复现：指定Python、新临时目录，运行geometry/complement内嵌代码及numeric.py，36、45、597项全部通过，三段stdout与replay逐字一致。numeric JSON仅剔除compute_index.seconds后全字段相同，canonical SHA256：c02dce38ad3bf31a2dfa6387954ea932694adfc78e155f7a5412b8981f4c10b0。数值为连续中心交集的raw-count Galerkin压缩及有限原子/算子代数，不认证max-success精确集总或完整原history；补偿注入量η_inj已与真实首入量明确区分并同步代码/JSON。未编译PDF。

冻结输入 SHA256：

- `r484_main.md`: `65138d08f1a69e761362e1679d56613934a9b48b4fa3b23929b3a1bd9f2a08da`
- `r484_geometry.md`: `c8bddcfdbb119a4c09534de1933bf0801e0f69f7f22536f7feeac1aba84850ce`
- `r484_complement.md`: `e3f1eedb9d86151e44046764b339d3a3c95e67d0d687f709c28bf437a4d2194f`
- `r484_numeric.md`: `639a2c0b61a855cbff8042ac8897ea6c6aa58b73a401e2f21b7e3f137fdda56d`
- `r484_numeric.py`: `69c21f648ae4d6c560161006848905e573ab3960023a762e3a98086e195bca18`
- `r484_numeric.json`: `04ab5fc94c094549cc88754ad79c0911563f0f33bdf486167d2784412bff5b36`
- `r484_replay.json`: `5ecc37555dc9962de51d8d1f73597022e55f03bd5b052b005f1ae625316f09ed`
