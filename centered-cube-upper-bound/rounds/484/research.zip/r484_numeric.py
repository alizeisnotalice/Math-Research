from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def matstr(A):return [[str(z) for z in row] for row in A]
def mult(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def transpose(A):return list(map(list,zip(*A)))
def inverse_exact(A):
 n=len(A);B=[A[i][:]+[F(int(i==j)) for j in range(n)] for i in range(n)]
 for j in range(n):
  ck(B[j][j]!=0);piv=B[j][j];B[j]=[z/piv for z in B[j]]
  for i in range(n):
   if i!=j:
    fac=B[i][j];B[i]=[B[i][k]-fac*B[j][k] for k in range(2*n)]
 return [row[n:] for row in B]
def zeros(n):return [[F(0)]*n for _ in range(n)]
def eye(n):return [[F(int(i==j)) for j in range(n)] for i in range(n)]
def ldl(A):
 n=len(A);L=eye(n);d=[]
 for j in range(n):
  dj=A[j][j]-sum(L[j][k]**2*d[k] for k in range(j));ck(dj>0);d.append(dj)
  for i in range(j+1,n):L[i][j]=(A[i][j]-sum(L[i][k]*L[j][k]*d[k] for k in range(j)))/dj
 diag=zeros(n)
 for i in range(n):diag[i][i]=d[i]
 ck(mult(mult(L,diag),transpose(L))==A)
 return d
# Integral of (A-B+c)_+ over a center rectangle, exact hinge primitive.
def hint(a0,a1,b0,b1,c):
 def f(x):return max(F(0),x)**3/6
 return f(a1-b0+c)-f(a0-b0+c)-f(a1-b1+c)+f(a0-b1+c)
def avgI(ca,la,ra,cb,lb,rb):
 a0,a1=ca-la/2,ca+la/2;b0,b1=cb-lb/2,cb+lb/2
 aa,bb=ra/2,rb/2
 return (hint(a0,a1,b0,b1,aa+bb)-hint(a0,a1,b0,b1,aa-bb)-hint(a0,a1,b0,b1,-aa+bb)+hint(a0,a1,b0,b1,-aa-bb))/(la*lb)
z=sp.symbols('z',positive=True);ck(sp.diff(z**3/6,z,2)==z)
cent=list(map(F,[-1,F(-3,5),F(-1,5),F(1,5),F(3,5),1]));length=[F(1,5)]*6
mass=list(map(F,[2,1,F(3,2),1,2,F(3,2)]));t=list(map(F,[1,F(1,2),F(3,4),1,F(1,4),F(3,4)]))
for i in range(6):
 ck(0<t[i]<=1);ck(cent[i]-length[i]/2-mass[i]/2>=-4);ck(cent[i]+length[i]/2+mass[i]/2<=4)
 for j in range(i):ck(abs(cent[i]-cent[j])>(length[i]+length[j])/2)
I=[[avgI(cent[i],length[i],mass[i],cent[j],length[j],mass[j]) for j in range(6)] for i in range(6)]
for i in range(6):
 ck(I[i][i]==mass[i]-length[i]/3)
 for j in range(6):ck(I[i][j]==I[j][i]);ck(0<=I[i][j]<=min(mass[i],mass[j]))
def mv(A,x):return [sum(A[i][j]*x[j] for j in range(len(x))) for i in range(len(A))]
def vm(x,A):return [sum(x[i]*A[i][j] for i in range(len(x))) for j in range(len(A[0]))]
rows=[]
for N in (2,4,6):
 nu=[t[i]*length[i] for i in range(N)];Dnu=zeros(N)
 for i in range(N):Dnu[i][i]=nu[i]
 levels=sorted(set(mass[:N]),reverse=True);depth=[levels.index(mm)+1 for mm in mass[:N]];J=len(levels)
 for T in (F(4),F(16),F(64)):
  K=[[nu[j]*I[i][j]/(T*mass[i]*mass[j])*(1 if mass[i]>mass[j] else (F(1,2) if mass[i]==mass[j] else 0)) for j in range(N)] for i in range(N)]
  # D is the entire same-mass block, not merely scalar diagonal entries.
  D=[[K[i][j] if mass[i]==mass[j] else F(0) for j in range(N)] for i in range(N)]
  off=[[K[i][j]-D[i][j] for j in range(N)] for i in range(N)]
  ID=[[F(int(i==j))-D[i][j] for j in range(N)] for i in range(N)]
  G=inverse_exact(ID);ck(mult(ID,G)==eye(N));ck(mult(G,ID)==eye(N))
  P=mult(G,off);ntilde=vm(nu,ID);e=[1-z for z in mv(K,[F(1)]*N)];g=mv(G,e)
  ck(vm(ntilde,G)==nu);ck(g==[1-z for z in mv(P,[F(1)]*N)])
  np=vm(ntilde,P);ck(all(0<=np[j]<=ntilde[j] for j in range(N)))
  ck(all(ntilde[j]>0 and 0<g[j]<=1 for j in range(N)))
  for i in range(N):
   for j in range(N):
    ck(P[i][j]>=0)
    if P[i][j]>0:ck(mass[i]>mass[j] and depth[j]>depth[i])
  layer=[]
  for mm in levels:
   idx=[i for i in range(N) if mass[i]==mm]
   a=sum(ntilde[i]*g[i] for i in idx);b=sum(nu[i]*e[i] for i in idx);ck(a==b)
   layer.append(dict(mass=str(mm),depth=levels.index(mm)+1,parent_indices=idx,collapsed_terminal_mass=str(a),original_nu_e_mass=str(b)))
  first=[ntilde[j]-np[j] for j in range(N)];rawfirst=[nu[j]-vm(nu,K)[j] for j in range(N)]
  ck(first==rawfirst);ck(all(z>=0 for z in first))
  Fgreen=eye(N);power=eye(N)
  for step in range(1,J):
   power=mult(power,P);Fgreen=[[Fgreen[i][j]+power[i][j] for j in range(N)] for i in range(N)]
  ck(mult(power,P)==zeros(N));ck(vm(first,Fgreen)==ntilde)
  visits=mv(Fgreen,[F(1)]*N);terminaldepth=mv(Fgreen,[g[i]*depth[i] for i in range(N)])
  ck(all(visits[i]<=terminaldepth[i] for i in range(N)))
  weightedterminal=sum(depth[i]*nu[i]*e[i] for i in range(N));ck(sum(ntilde)<=weightedterminal)
  rowsK=mv(K,[F(1)]*N);colsK=[z/nu[j] for j,z in enumerate(vm(nu,K))]
  c=max(rowsK+colsK);ck(0<c<1)
  ck(all(ntilde[j]>=(1-c)*nu[j] for j in range(N)))
  bound=weightedterminal/(1-c);R=sum(nu);ck(R<=bound)
  gram=mult(mult(transpose(K),Dnu),K)
  psd=[[c*c*Dnu[i][j]-gram[i][j] for j in range(N)] for i in range(N)]
  pivots=ldl(psd)
  skip=[dict(source=i,target=j,P=str(P[i][j])) for i in range(N) for j in range(N) if depth[j]>depth[i]+1 and P[i][j]>0]
  if N>=4:ck(bool(skip))
  rows.append(dict(N=N,T=str(T),phase='initial' if N==2 else ('four_block_tie_pressure' if N==4 else 'six_block_expanded'),mass_levels_descending=list(map(str,levels)),depth=depth,nu=list(map(str,nu)),K=matstr(K),same_mass_block_D=matstr(D),G=matstr(G),P=matstr(P),nu_tilde=list(map(str,ntilde)),e=list(map(str,e)),g=list(map(str,g)),injection_measure=list(map(str,first)),layer_terminal_identity=layer,collapsed_Green_finite=matstr(Fgreen),expected_level_visits=list(map(str,visits)),expected_terminal_depth=list(map(str,terminaldepth)),actual_row_max=str(max(rowsK)),actual_weighted_column_max=str(max(colsK)),c=str(c),Schur_PSD_positive_LDL_pivots=list(map(str,pivots)),original_R=str(R),weighted_terminal=str(weightedterminal),depth_bound=str(bound),skip_middle_edges=skip,scope='Marked raw-count Galerkin compression, not a max-success or exact full marked-chain law'))
# Exact telescoping for empty weights, with depth reverse to ascending rank.
q1,q2,q3,tt=sp.symbols('q1 q2 q3 tt',positive=True)
lo=[0,q1,q2];hi=[q1,q2,q3];depth3=[3,2,1]
lhs=sum(depth3[i]*tt*(sp.exp(-lo[i]/tt)-sp.exp(-hi[i]/tt)) for i in range(3))
rhs=tt*sum(1-sp.exp(-q/tt) for q in (q1,q2,q3))
ck(sp.expand(lhs-rhs)==0)
emptycases=[]
for widths,tt0 in [([F(1,3),F(2,3),F(3,2)],F(1,4)),([F(1,10),F(3,5),F(1,5),F(11,10)],F(1)),([F(2),F(1,4),F(3,4)],F(2,3))]:
 lower=F(0);prefix=[];weighted=arb(0);terms=[];J=len(widths)
 for j,width in enumerate(widths):
  upper=lower+width;dep=J-j
  term=ar(tt0)*((-ar(lower/tt0)).exp()-(-ar(upper/tt0)).exp());ck(term>0)
  weighted+=dep*term;prefix.append(upper);terms.append(dict(lower=str(lower),upper=str(upper),depth=dep,empty_mass=str(term)));lower=upper
 right=ar(tt0)*sum((1-(-ar(u/tt0)).exp() for u in prefix),arb(0))
 ck((weighted-right).contains(0));ck(weighted<ar(J*tt0))
 emptycases.append(dict(widths=list(map(str,widths)),T=str(tt0),terms=terms,prefixes=list(map(str,prefix)),weighted_empty=str(weighted),prefix_rhs=str(right),bound_NT=str(J*tt0),scope='Finite source-rank atom coefficient interface only, not continuous cube/history'))
result=dict(scope='Nine actual continuous marked raw-count Galerkin layer-elimination matrices plus3 finite weightedempty rank identities; not a full-success/history theorem.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r484_numeric.py',seconds=time.perf_counter()-start),checks=checks,geometry=dict(f='1_[-4,4]',W='8',q='1',r='1',S='1',centers=list(map(str,cent)),lengths=list(map(str,length)),R_and_complete_mass=list(map(str,mass)),t=list(map(str,t)),actual_average_I=matstr(I)),formula=dict(D='full same-mass diagonal blocks of K, with equal-mark factor1/2',G='(I-D)^-1',P='G(K-D)',nu_tilde='nu(I-D)',e='1-K1',g='G e=1-P1',layer_identity='nu_tilde_i dot g_i=nu_i dot e_i (block inner product, not parentwise product)',injection_measure='eta_inj=nu_tilde(I-P)=nu(I-K); not original nu(I-P)^-1 first-entry occupation',depth='1 at highest mass, increases to lowest mass; every lower transition retained including skips',bound='R<=1/(1-c)*sum_i depth_i*(nu_i dot e_i)',weightedempty='sum_j depth_j*T*(exp(-lower_j/T)-exp(-upper_j/T))=T*sum_prefix(1-exp(-U_prefix/T)); ascending rank atom depth=N-j'),cases=rows,weightedempty_cases=emptycases,exactness='All cube intersection averages, matrices, inverses, injection and PSD certificates rational exact. Source-rank exponential diagnostics use 256-bit Arb; symbolic telescoping exact. No solver or Monte Carlo.')
(ROOT/'r484_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;9 actual marked block-layer matrices and3 finite weightedempty identities; no success/history claim')
