# R484：真实质量窗内的无权 Green、跨层压缩与停止深度账

## 1. 冻结对象与本轮结果

沿 R483 的同一 parent-only 刷新核：\(\mu=f\,dx\)，\(m_A=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)，\(\sigma=q_A\,dA\)，\(\nu=t\sigma\)，\(0\le t\le S\)。原质量带保持不动，核 \(K\) 在每个原带内转移，满足
\[
 K1\le1,\quad \nu K\le\nu,\quad
 K(A,dB)\le 1_{m_B\le m_A}\frac{I_{AB}}{Tm_Am_B}\nu(dB),
 \qquad I_{AB}=\mu(Q_A\cap Q_B).
\tag{1}
\]
成功条件和原记录接受权在实际 \(K\) 内保留；每步补采的新记录不继承上一步历史。

本轮可证的新局部化是：**对数宽度 \(L\) 的质量窗内，原未共轭核的行、列均不超过 \((rS/T)(1+L)\)**。因此可以压缩窗内所有停留，仍精确保留任意跨窗跳跃。由此得到按实际停止层深度加权的完整账，不再付 \(e^L\) 或全质量比。但该深度加权的来源费仍未达到根阶；下面特别算清原空点部分。

## 2. 含原子的双边质量窗与局部 Green

固定来源 \(x\)，令 \(G_x(u)=\int_{m_A\le u}c_A(x)\nu(dA)\)。真实匹配和中心 Lebesgue 容量给 \(G_x(u)\le rSu\)。对闭窗 \([a_0,b_0]\)，Stieltjes 分部积分为
\[
 \int_{[a_0,b_0]}u^{-1}dG_x(u)
 =\frac{G_x(b_0)}{b_0}-\frac{G_x(a_0-)}{a_0}
   +\int_{a_0}^{b_0}\frac{G_x(u)}{u^2}du
 \le rS\,[1+\log(b_0/a_0)].
\tag{2}
\]
左极限保留下端原子；半开窗是其正限制。这个估计控制真实接收中心，未对来源 \(f\) 加密度帽。

取任意质量窗 \(J\)，对数宽度不超过 \(L\)。由 (1)、(2) 和来源 Tonelli，
\[
 K_J1(A)\le\frac1{Tm_A}\int_{Q_A}\!!d\mu(x)
       \int_J\frac{c_B(x)}{m_B}\nu(dB)\le c,
 \qquad c=\frac{rS}{T}(1+L),
\]
\[
 \frac{d(\nu|_J K_J)}{d(\nu|_J)}(B)
 \le\frac1{Tm_B}\int_{Q_B}\!!d\mu(x)
       \int_J\frac{c_A(x)}{m_A}\nu(dA)\le c.
\tag{3}
\]
原质量方向只使积分更小。若 \(c<1\)，则 \(G_J=(I-K_J)^{-1}\) 的行、列积分均不超过 \((1-c)^{-1}\)。这一结论允许窗内质量比达 \(e^L\)，没有相应指数损失。

## 3. 压缩核与完整停止深度价

在每个原带内按质量从高到低划分 \(J_i\)，宽度至多 \(L\)，\(i=0,\ldots,M-1\)。统一用上端闭、下端开，最底层再包含底端；每个质量原子只落入一个层。定义
\[
 D=\bigoplus_iK_{J_i},\quad F=K-D,\quad G_D=(I-D)^{-1},
 \quad P=G_DF,\quad \widetilde\nu=\nu(I-D).
\tag{4}
\]
这里 \(P\) 是经过零次或多次实际窗内转移后的首次跨窗核，不是把长跨层跳跃拆成相邻跳。由 (3)，
\[
 (1-c)\nu\le\widetilde\nu\le\nu,\qquad
 \widetilde\nu G_D=\nu,\qquad
 \widetilde\nu P=\nu F\le\widetilde\nu.
\tag{5}
\]
令原停止率 \(e=1-K1\)，压缩后的停止率为
\[
 f=G_De=1-P1\ge0.
\]
每个 \(P\) 跳严格进入较低质量层，故带内最多 \(M-1\) 跳。第 \(i\) 层只能在第 \(0,\ldots,i\) 次压缩时刻被访问；再用 \(\widetilde\nu P^j\le\widetilde\nu\)，得到
\[
 \sum_{j\ge0}(\widetilde\nu P^j)|_{J_i}
 \le(i+1)\widetilde\nu|_{J_i}.
\tag{6}
\]
由于 \(G_D\) 不跨层，逐层有 \(\int_{J_i}f\,d\widetilde\nu=\int_{J_i}e\,d\nu\)。全部停止相加遂给
\[
 \boxed{R\le\frac1{1-c}\sum_{\text{原带 }b}\sum_i(i+1)
      \int_{J_{b,i}}e\,d\nu.}
\tag{7}
\]
深度在每个原不可跨的质量带重新从零计数。式 (7) 是实际停止质量分布的上界；它没有假设累计首入量 \(\le\nu\)，也没有给新父继承旧 history。跨层跳跃越远，实际访问层可以越少；(6) 是保守上界，非把中间层当实际停留。

## 4. 原空点部分的精确源账：仍有线性费用

取
\[
 L=\frac{T}{4rS}-1>0,\qquad c=1/4.
\]
原参数保证 \(T\ge8rS\)；\(S=0\) 单列零流。在某个原带，设最高质量 \(m_+\)，层上端为 \(h_i=m_+e^{-iL}\)。定义静态、原场的闭 prefix 秩
\[
 U_i(x)=\int_{\substack{A\text{在该原带}\\m_A\le h_i}}
       \frac{t(A)c_A(x)}{m_A}\sigma(dA).
\]
这里不是在刷新后的路径上强制保持同一个来源。它只计算原参考 \(\nu\) 的一次停止积分。均匀 tie mark 将每个质量原子的秩区间完整展开为 Lebesgue 区间。因此原 raw 空点率 \(e_0\) 满足准确公式
\[
 \boxed{\sum_i(i+1)\int_{J_i}e_0\,d\nu
 =T\int\sum_i(1-e^{-U_i(x)/T})\,d\mu(x).}
\tag{8}
\]
证明是 \(i(A)+1=\sum_j1_{m_A\le h_j}\)，再对每个闭 prefix 积分
\(\int_0^{U_j}e^{-v/T}dv=T(1-e^{-U_j/T})\)。无活跃源、零原子或零秩均贡献零。

若各原带对数宽度为 \(D_b\)，则 \(M_b\le1+D_b/L\)。从 (8) 只能立即得到
\[
 \sum_{b,i}(i+1)\int_{J_{b,i}}e_0\,d\nu
 \le\left[TN+\frac{T}{L}\sum_bD_b\right]W
 \le[TN+8rS D_m]W,
 \quad D_m=\log r+n\log(b/a).
\tag{9}
\]
亦可保留较好的真实层和 \(\int\sum_i\min\{U_i,T\}\,d\mu\)，不外放成 (9)。原中心 CDF 给
\(U_i\le rS[1+\log(h_i/m_{-,b})]\)，但单靠这个上帽没有使该层和成为根阶。

在原参数下，(7) 对空点项额外乘 \(4/3\)。其它停止原因 \(e-e_0\ge0\) 仍须按同一深度收费，不能省略。即使另建全质量单带核并取 \(N=1,T\asymp\sqrt n\)，(9) 仍含显式 \(O(rS nW)\)，而非所需根阶。这个单带比较不是无成本替换冻结的原带成功核。

因此，新增可用工具是 (2)–(7) 的原生质量局部化；完整目标仍缺 (8) 的实际截断 prefix-rank 层和及其它停止分量的共同来源节省。这里没有将新的层和符号当成已付预算，也没有把每层单独的 \(W\) 当成同一笔 \(W\)。

## 5. 有限精确核验

以下代码已在 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 实际运行，输出 `PASS 36 exact assertions`。三组有限次概率核只核压缩与深度代数；三个带原子的秩模型核 (8)，包括零质量段。它们不是原生接收几何或原历史实例。一般中心常数由 (2)–(3) 证明。

```python
import sympy as s
checks=0
for d in (s.Rational(1,16),s.Rational(1,8),s.Rational(1,4)):
 D=s.zeros(6); F=s.zeros(6)
 for b in range(3):D[2*b,2*b+1]=D[2*b+1,2*b]=d
 for i,j,a in [(0,1,s.Rational(1,4)),(0,2,s.Rational(1,8)),
               (1,2,s.Rational(1,4))]:
  for u in range(2):
   for v in range(2):F[2*i+u,2*j+v]=a/2
 K=D+F; G=(s.eye(6)-D).inv(); P=G*F
 nu=s.ones(1,6); one=s.ones(6,1); mu=nu*(s.eye(6)-D)
 e=one-K*one; f=G*e
 assert all(v>=0 for v in mu);checks+=1
 assert mu*G==nu;checks+=1
 assert mu*P==nu*F;checks+=1
 assert all(v>=0 for v in mu-mu*P);checks+=1
 assert f==one-P*one;checks+=1
 assert P**3==s.zeros(6);checks+=1
 for b in range(3):
  assert sum(mu[j]*f[j] for j in range(2*b,2*b+2))==sum(e[j] for j in range(2*b,2*b+2));checks+=1
 assert sum((mu*P**j*f)[0] for j in range(3))==(mu*one)[0];checks+=1
 weighted=sum((j//2+1)*e[j] for j in range(6))
 assert 6<=weighted/(1-d);checks+=1
for weights in [(1,2,3),(s.Rational(1,2),0,s.Rational(3,2)),(0,1,0)]:
 T=s.Rational(2);cum=s.Integer(0); direct=s.Integer(0);prefix=[]
 for k,w in enumerate(weights):
  before=cum;cum+=w;prefix.append(cum)
  direct+=(3-k)*T*(s.exp(-before/T)-s.exp(-cum/T))
 rhs=T*sum(1-s.exp(-u/T) for u in prefix)
 assert s.simplify(direct-rhs)==0;checks+=1
print(f'PASS {checks} exact assertions: 3 blocked substochastic kernels and 3 atomic rank identities; not native-history certification.')
```
