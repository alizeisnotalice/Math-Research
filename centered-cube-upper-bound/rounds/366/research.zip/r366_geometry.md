# R366 — A paid near-containment branch of the original symmetric-difference budget

**Result.** The proposed common-source symmetric-difference identity is exact. A genuine geometric branch of the original hard budget admits a root-order source-linear receipt: orient each pair by its actual side lengths, and retain pairs for which the smaller cube is contained in the larger cube after increasing the latter's SIDE LENGTH by a log(n+2)/(2n). For every epsilon>0 this entire branch is at most

    epsilon X_q + [4/(3 epsilon)] (sqrt(n+2)+1) W.

The complementary protruding pairs are specified below and remain unpaid. There is no assertion that the paid branch contains a fixed fraction of the total. H, the actual receivers, full f, and the original clock are unchanged. The original negative overlap credit is used once, through an exact positive decomposition.

## 1. Definitions and identity

Use the measurable Lebesgue receiver set E of finite measure, a<=R_u<=b<=2a, Q_u the cube centered at u of side R_u, and

    m_u=f(Q_u)=q_u R_u^n,  q_-=3 lambda/4<=q_u<=lambda,
    mu(du)=du/m_u,  c_u(y)=1_(Q_u)(y),  E_r={u in E:R_u<=r},
    J_r(y)=integral_(E_r)c_u(y)mu(du),
    A_r(y,z)=integral_(E_r)c_u(y)c_u(z)mu(du),
    V_r(y)=integral_(E_r)c_u(y)du,
    W=integral f,  X_q=integral_E q_u du.

All source integrations use the same full f>=0. Write I_uv=f(Q_u intersection Q_v). Full matching gives integral f(z)A_r(y,z)dz=V_r(y). The original clock is

    ell(dr)=b^(-n) delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr,
    ell([R,b])=R^(-n),  a<=R<=b.

For J=J_r(y)>0 define

    b(r,y)=V_r(y)-J^(-1) integral f(z)A_r(y,z)^2dz.

Then Tonelli and f(Q_u triangle Q_v)=m_u+m_v-2I_uv give EXACTLY

    b(r,y)=[1/(2J)] integral_(E_r x E_r)
       c_u(y)c_v(y) f(Q_u triangle Q_v) mu(du)mu(dv).    (1)

Indeed the two mass terms, divided by 2J, give V_r(y), while the intersection term gives J^(-1) integral f A_r^2. In particular 0<=b<=V. Therefore

    B_H=integral ell(dr) integral f(y)1_(J_r(y)>=H)b(r,y)dy. (2)

Zero-J expressions are set to zero. In the finite receiver setting these integrals are well-defined by positivity.

Orient every distinct pair so that R_u<=R_v, resolving equal radii by lexicographic order of centers. Denote the resulting measurable set by O. The diagonal contributes zero. Symmetry removes the factor 1/2 in (1): one integrates over O with coefficient 1/J. This orientation is crucial for the constants below.

## 2. Exact scale-versus-displacement separation

Let r0=R_u<=R_v=R0. For a pair with nonempty intersection define

    w_j=clamp(u_j, v_j-(R0-r0)/2, v_j+(R0-r0)/2),
    C=the cube centered at w of side r0.

Coordinatewise interval intersection proves

    C subset Q_v,
    Q_u intersection C = Q_u intersection Q_v,
    |w_j-u_j|=(|u_j-v_j|-(R0-r0)/2)_+.

Consequently Q_v\C is disjoint from Q_u, and the following is a DISJOINT decomposition, with no triangle-inequality loss:

    Q_u triangle Q_v = (Q_u triangle C) disjoint-union (Q_v\C),
    f(Q_u triangle Q_v)=f(Q_u triangle C)+f(Q_v\C).       (3)

Thus the residual center displacement is precisely the coordinate overshoot beyond the room created by the scale increase. C is only a geometric intermediate; it is not an actual receiver, and no matching equation for f(C) is assumed. The receipt below uses only the original u,v and their real masses.

## 3. General near-containment receipt

Fix 0<=eta<=n and put

    s=b/a in [1,2],  h_eta=a eta/n,
    kappa_eta=(s-1+eta/n)^n,
    tau_eta=((s-1+eta/n)/s)^n,
    C_eta=(kappa_eta+tau_eta)/q_-.

Let Q_v^(+h_eta) denote the cube of center v and SIDE LENGTH R_v+h_eta. Retain the oriented geometric branch

    G_eta={(u,v) in O: Q_u subset Q_v^(+h_eta)}
         ={(u,v) in O: 2|u_j-v_j|<=R_v-R_u+h_eta for all j}. (4)

The selected pair still has both original cubes containing the actual source y. No intermediate or enlarged cube is inserted into the matching measure. Define

    b_eta(r,y)=J_r(y)^(-1) integral_(G_eta intersect E_r^2)
       c_u(y)c_v(y) f(Q_u triangle Q_v) mu(du)mu(dv),
    B_eta=integral ell integral f 1_(J>=H)b_eta.

For each fixed actual larger endpoint v, every eligible smaller center u lies in the center cube

    |u_j-v_j| <= (R_v-a+h_eta)/2.

This is an outer envelope for REAL centers only; actual radii remain fixed. Since m_u>=q_-a^n, its volume gives

    integral_(eligible u) mu(du)
       <= (R_v-a+h_eta)^n/(q_-a^n)
       <= kappa_eta/q_-.                                (5)

There is also a distinct bound for the small-endpoint mass contribution:

    (1/m_v) integral_(eligible u)du
       <= (R_v-a+h_eta)^n/(q_-R_v^n)
       <= tau_eta/q_-.                                  (6)

For (6), x -> (x-1+eta/n)/x is increasing on [1,s] because eta/n<=1. Equations (5),(6) hold after any additional actual restrictions E_r, common-source capture, or tie-breaking. They do not estimate source f mass by boundary volume.

Using the exact nonnegative difference and retaining its overlap until this upper-bound step,

    integral_(eligible u)c_u(y) f(Q_u triangle Q_v)mu(du)
      <= m_v integral_(eligible u)mu(du)+integral_(eligible u)du
      <= C_eta m_v.                                     (7)

Here m_u mu(du)=du is the actual matching cancellation. Integrating (7) against c_v(y)mu(dv) on E_r yields

    0<=b_eta(r,y)<=C_eta V_r(y)/J_r(y).

As a positive branch of (1), it also satisfies b_eta<=b<=V. Thus

    b_eta(r,y)<=V_r(y) min(1,C_eta/J_r(y)).               (8)

This is a real common-source receiver-row bound, valid for all mass ratios. It does not require pi_u to have independent coordinates.

## 4. Original-clock payment and root-order tolerance

We use the existing low-clock receipt, with its inclusive endpoint convention:

    integral ell(dr) integral f(y)1_(J_r(y)<T)V_r(y)dy
       <=lambda T W.                                   (9)

For completeness, Tonelli for fixed y bounds the left clock integrand by

    integral_E c_u(y)1_(J_(R_u)(y)<T) R_u^(-n)du
      <=lambda integral_E c_u(y)1_(J_(R_u)(y)<T)mu(du)
      <=lambda T.

The last inequality is the cumulative-mass fact for the radius pushforward of c_u(y)mu(du): only increments whose inclusive cumulative mass remains strictly below T are retained. An entire jump that reaches or crosses T is excluded. The terminal clock atom is included in ell([R_u,b])=R_u^(-n).

Also, exactly by full matching and the original clock,

    integral ell(dr) integral f(y)V_r(y)dy=X_q.          (10)

For C_eta>0 choose the auxiliary clock split T=C_eta/epsilon; this does NOT alter the fixed original hard threshold H. On H<=J<T use b_eta<=V and (9). On J>=max(H,T) use b_eta<=epsilon V and (10). Hence

    B_eta <= epsilon X_q
            + [lambda/(q_- epsilon)](kappa_eta+tau_eta)W. (11)

If C_eta=0 the branch is zero and the same result holds directly. A separate direct estimate is B_eta<=C_eta X_q/H for H>0.

Now take

    eta_n=(1/2) log(n+2),  h_n=a log(n+2)/(2n).

For integers n>=1, log(n+2)<=2n, so 0<eta_n<=n. Since s<=2,

    kappa_(eta_n)<=(1+eta_n/n)^n<=exp(eta_n)=sqrt(n+2),
    tau_(eta_n)<=1.

Therefore the promised root-order receipt is

    B_(eta_n) <= epsilon X_q
               + [4/(3 epsilon)](sqrt(n+2)+1)W.          (12)

The expansion h_n is a SIDE-LENGTH increment; each face moves outward by h_n/2. By (3), the branch includes exactly those oriented pairs whose projected-center displacement is at most h_n/2 in every coordinate. It includes nonnested pairs, not only concentric or contained ones.

The complementary original branch is explicitly

    G_escape={(u,v) in O: some j satisfies
                  2|u_j-v_j|>R_v-R_u+h_n}.

Define B_escape with the same integrand and clock as B_eta, restricted to G_escape. Then

    B_H=B_(eta_n)+B_escape,
    B_H<=epsilon X_q+[4/(3 epsilon)](sqrt(n+2)+1)W+B_escape. (13)

Every common-source pair is in exactly one branch. B_escape remains unpaid: its smaller cube protrudes beyond the permitted expansion in at least one coordinate. No claim of an overall root bound follows without controlling this complementary original f-weighted symmetric difference.

## 5. Optional sharper nested endpoint — not an additional charge

When b=a and eta=0, containment forces identical centers, so only the zero-contribution diagonal can remain; this degenerate branch is exactly zero. At eta=0 the cubes are actually nested. Then f(Q_u triangle Q_v)=m_v-m_u<=m_v, so the second term (6) is unnecessary. This gives the sharper nested-only receipt

    B_nested<=epsilon X_q
                +[lambda/(q_-epsilon)](s-1)^n W.        (14)

Nested pairs are already included in (12); (14) is an alternative sharp endpoint observation and is NOT added as a second fee. Likewise (3) is not a second spending of the negative square.

## 6. Actual local arithmetic check

The Fraction code below was actually executed, including an explicit oriented-pair check with equal-radius ties, returning

    PASS {'projection': 24, 'symmetric_difference': 120,
          'orientation_ties': 120, 'capacity_coefficients': 720,
          'clock': 16} total 1000

The geometry examples use actual cubes and full uniform f on a sufficiently large containing box. Their receiver mu values are finite quadrature weights, so the identity checks are finite algebra diagnostics, not realizations of the original Lebesgue receiver/high-J problem. The capacity-coefficient checks are exact rational tests. The estimates (5)–(14) are proved analytically above; numerical tests are not substitutes.

```python
from fractions import Fraction as F
from itertools import product
counts={'projection':0,'symmetric_difference':0,'orientation_ties':0,'capacity_coefficients':0,'clock':0}
def cube(c,R):return [(x-R/2,x+R/2) for x in c]
def volume(box):
    ans=F(1)
    for lo,hi in box:ans*=max(F(0),hi-lo)
    return ans
def intersect(A,B):return [(max(x[0],y[0]),min(x[1],y[1])) for x,y in zip(A,B)]
def subset(A,B):return all(y[0]<=x[0]<=x[1]<=y[1] for x,y in zip(A,B))
for n in [1,2,3,4]:
    centers=[tuple(F(0) for _ in range(n)),tuple(F(1,8) if j==0 else F(0) for j in range(n)),tuple(F(1,4) for _ in range(n)),tuple(F(1,2) if j==0 else F(1,4) for j in range(n))]
    radii=[F(1),F(1),F(3,2),F(2)]
    boxes=[cube(c,R) for c,R in zip(centers,radii)]
    mass=[R**n for R in radii]
    mu=[F(i+1,20)/mass[i] for i in range(4)]
    for i in range(4):
      for j in range(i+1,4):
        if radii[i]>radii[j]:continue
        ci,cj=centers[i],centers[j];ri,rj=radii[i],radii[j]
        if not volume(intersect(boxes[i],boxes[j])):continue
        w=tuple(min(max(ci[k],cj[k]-(rj-ri)/2),cj[k]+(rj-ri)/2) for k in range(n))
        C=cube(w,ri);I=intersect(boxes[i],boxes[j])
        assert subset(C,boxes[j]) and intersect(boxes[i],C)==I
        assert mass[i]+mass[j]-2*volume(I)==mass[i]+volume(C)-2*volume(intersect(boxes[i],C))+mass[j]-volume(C)
        counts['projection']+=1
    for y in product([F(-1,4),F(0),F(1,4)],repeat=n):
      active=[i for i in range(4) if all(lo<=x<=hi for x,(lo,hi) in zip(y,boxes[i]))]
      J=sum((mu[i] for i in active),F(0))
      if not J:continue
      V=sum(mu[i]*mass[i] for i in active)
      O=sum(mu[i]*mu[j]*volume(intersect(boxes[i],boxes[j])) for i in active for j in active)
      original=V-O/J
      sym=sum(mu[i]*mu[j]*(mass[i]+mass[j]-2*volume(intersect(boxes[i],boxes[j]))) for i in active for j in active)/(2*J)
      assert original==sym>=0
      counts['symmetric_difference']+=1
      # Actual radius ordering, with lexicographic center tie-breaking.
      order=lambda i:(radii[i],centers[i])
      oriented=sum(mu[i]*mu[j]*(mass[i]+mass[j]-2*volume(intersect(boxes[i],boxes[j]))) for i in active for j in active if order(i)<order(j))/J
      assert original==oriented
      counts['orientation_ties']+=1
    levels=sorted(set(radii));clock=[levels[k]**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else F(0)) for k in range(len(levels))]
    for R in radii:
      assert sum(clock[k] for k,r in enumerate(levels) if r>=R)==R**(-n)
      counts['clock']+=1
for n in range(1,25):
  for s in [F(1),F(5,4),F(3,2),F(7,4),F(2)]:
    for eta in [F(0),F(1,4),F(1,2),F(1),F(n,2),F(n)]:
      if eta>n:continue
      kappa=(s-1+eta/n)**n
      tau=((s-1+eta/n)/s)**n
      assert kappa<=(1+eta/n)**n and tau<=1
      for h in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
        v=1+h*(s-1)
        assert (v-1+eta/n)**n<=kappa
        assert ((v-1+eta/n)/v)**n<=tau
      counts['capacity_coefficients']+=1
print('PASS',counts,'total',sum(counts.values()))
```

Only /tmp/r366_geometry.md is written. This report freezes the proof and its exact unpaid complement.
