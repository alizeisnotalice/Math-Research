from fractions import Fraction as F
from decimal import Decimal,getcontext
from pathlib import Path
import json
getcontext().prec=80
checks=0;cases=0;sharp=0;rows=[]
# Exact positive-volume center shells, a=1, q=1, constant source density
# on a sufficiently large finite box. No source or receiver independence assumed.
for n in list(range(1,9))+[16,32]:
 for b in [F(1),F(5,4),F(3,2),F(2)]:
  for eta in [F(0),F(1,4),F(1),F(n,2),F(n)]:
   width=b-1+eta/n
   kappa=width**n;tau=(width/b)**n
   rvlist=sorted({F(1),(1+b)/2,b})
   for rv in rvlist:
    widthv=rv-1+eta/n
    choices=sorted({F(1),(1+rv)/2,rv})
    for mode in range(3):
     cap=vol=F(0)
     for j in range(8):
      lo=widthv*j/8;hi=widthv*(j+1)/8
      ru=choices[0] if mode==0 else choices[-1] if mode==1 else choices[j%len(choices)]
      cutoff=rv-ru+eta/n
      good=max(F(0),min(hi,cutoff)**n-lo**n) if cutoff>=lo else F(0)
      cap+=good/ru**n;vol+=good
     assert cap<=kappa;checks+=1
     assert vol/rv**n<=tau;checks+=1
     assert cap+vol/rv**n<=kappa+tau;checks+=1
     if mode==0:
      assert cap==widthv**n;checks+=1;sharp+=1
     cases+=1
# Root-width choice, finite numerical verification only (not interval arithmetic).
D=Decimal
for n in list(range(1,33))+[64,128,512,2048,10000,100000,1000000]:
 eta=(D(n)+2).ln()/2
 assert 0<eta<=n;checks+=1
 for b in [D(1),D('1.25'),D('1.5'),D(2)]:
  base=b-1+eta/n
  logk=D(n)*base.ln();logt=D(n)*(base/b).ln()
  assert logk<=eta+D('1e-70');checks+=1
  assert logt<=D('1e-70');checks+=1
  if b==2 and n in [1,8,32,128,2048,1000000]:
   rows.append(dict(n=n,eta=str(eta),kappa=str(logk.exp()),root=str((D(n)+2).sqrt()),tau_log=str(logt)))
out=dict(checks=checks,exact_center_assignments=cases,sharp_smallradius_checks=sharp,scope='Actual Lebesgue center-shell volumes and matching uniform compactly supported source test the capacity envelope only. No high-J or full hard-core realization, and no dimensional inference from finite checks. Root-width calculations use 80-digit Decimal, not interval certificates.',root_width_rows=rows)
(Path(__file__).resolve().parent/'r366_capacity_result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
