# R366 bounded history lookup (read-only)

## Radius selector / shifted-cube difference

**No located archive states the proposed physical-radius selector**: take the last/outermost threshold crossing so that `f(Q(u,R_u))=λR_u^n` and `f(Q(u,t))≤λt^n` for every `t≥R_u`, then use this tail cap to price an actual `f`-weighted shifted-cube symmetric difference.

Closest selector items and why they differ:

- R311 is the only exact recent “last-crossing” hit in the project README search. In `rounds/311/research.zip::r311_canonical_first.md:23–34`, it sets `sigma(x)=max{s:G_s(x)≥q}` for a **softness** response, then proves `F(x,p,L')≤q` for `p≥sigma(x)` and all `L'` in the octave. It is not a maximum/last-crossing choice of physical cube radius for `f(Q(u,t))/t^n`. R311 README also says this native selector is not yet identified with the legacy actual selector.
- The frozen R107 actual input only records `P_(s(x),L_s(x))*f(x)=q` and `h_(R(x))*f(x)≤4λ≤(16/3)q`, with `a≤L_s,R≤2a` (`rounds/107/research.zip::proof.md:903–913`). This is a fixed-scale hard cap; that passage does not define `R(x)` as an outermost density crossing or give the all-`t≥R` cap. R302 likewise assumes the original q-band and selectors without adding such a construction (`rounds/302/research.zip::r302_geometry.md:5–13`).
- Recent radius-variation notes retain the selector and charge actual shell mass/clock loss rather than using a post-crossing density bound: R365 `rounds/365/research.zip::r365_selector.md:24–43,47–68` considers candidate same-center radii in the q-band, and explicitly says shell increments are actual source mass; it supplies only an `X_q` certificate, not a small price.

Closest shifted-cube evidence is explicitly not the proposed estimate. R302 `rounds/302/research.zip::r302_geometry.md:161–176` places the symmetric difference in a source boundary layer but says there is no thickness-proportional source-mass bound from the accepted hard caps. R303 `rounds/303/research.zip::r303_geometry.md:148–163` preserves the original-normalization near boundary integral as the unproved geometric remainder. R363 gives the exact matched-hard identity with `f(Q_u symmetric_difference Q_v)` (`rounds/363/research.zip::r363_variance.md:15–29`) and a spatial kernel envelope (`:31–45`), but the text does not pay that actual f-mass by the proposed all-larger-radii cap. These are source-disagreement identities/support localization, not the last-crossing radius mechanism.

## Added nested-original-pair candidate

No inspected recent record has the exact same-original-pair branch `Q_u⊂Q_v` with the stated all-full-mass-ratio bound and same-slot price `εX + λκ/(q_-ε)W`.

Nearby but distinct entries:

- R336–337 already split the original positive pair traffic by mass comparison and charge several full branches (`rounds/336/README.md`, `rounds/337/README.md`), but those are the comparable/far and near/favored mass-ratio partitions, not a gate on geometric nesting of the two original receiver cubes.
- R352 `rounds/352/research.zip::r352_core.md:187–201` uses nested-in-time ancestor/history cubes to define pathwise fresh-source regions. It expressly describes a pathwise source-capture relation in a nonnested family and does not imply disjoint source regions across paths. This is not the same original receiver pair `Q_u⊂Q_v`.
- R358 `rounds/358/research.zip::r358_geometry.md:83–112` has a nested-cube containment lemma for packet/ancestor receiver-volume charging, with packet overlap as an explicit further condition. Its price is `(λ/q_-)D_n^n` times selected receiver masses, not the proposed εX plus λκ/(q_-ε)W term on the original pair slot.

## Bounded search boundary

Searched project README/index text for rounds 300–365, then inspected the most relevant archives: R107, R302–303, R311, R336–339, R352, R358, R363 and R365. Also queried the 300–312 and 350–365 ZIP Markdown/TeX members for last-crossing, all-larger-radius cap, symmetric-difference and containment terms. This is a scoped duplicate check, not a claim that no such statement exists anywhere among all project history.
