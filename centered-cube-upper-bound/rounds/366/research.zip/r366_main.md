# 第366轮：原硬层近包含接收对与联合少失配分支的真实预算

## 结论与范围

本轮新增近包含几何分支预算，并将其直接应用于第337轮此前未付的高质量过去余项。它适用于任意非负L1来源，不限制来源密度或质量比。另证明少失配子片的更小常数，但整个质量可比族早已由第336轮付清，因此该辅助结果不算扩大已付范围。一般一致n^(1/2+o(1))上界仍未闭合。

固定原hard matched合同：W=∫f，m_u=f(Q_u)=q_uR_u^n，q_-=3λ/4≤q_u≤λ，a≤R_u≤b≤2a。真实接收du，μ(du)=du/m_u；E_r={R_u≤r}，c_u=1_Qu，A_r(y,z)=∫Er c_u(y)c_u(z)μ(du)，J_r(y)=A_r(y,y)，V_r(y)=∫Er c_u(y)du，X_q=∫E q_u du。原clock ℓ=b^{-n}δ_b+n r^{-n-1}1_(a,b)dr，原高门J_r≥H>0不变。

## 原平方的精确对称差表示

展开原A(1−A/J)并仅对同一来源下的两个真实接收点作对称化，得到
\[
B_H=\frac12\int\ell(dr)\int\frac{f(y)1_{J_r(y)\ge H}}{J_r(y)}
 \iint_{E_r^2}c_u(y)c_v(y)f(Q_u\triangle Q_v)\,\mu(du)\mu(dv)\,dy.
\]
这仍是原B_H，非再次可用的负平方信用。所有被积量非负。按边长从小到大定向，等边长按中心字典序定向；对角du零测，1/2与两向恰好抵消。

## 一、近包含对：全质量比的根阶预算

取0≤η≤n。令N_η(u,v)是对称谓词：定向后R_u≤R_v，且
\[
2\|u-v\|_\infty\le R_v-R_u+a\eta/n.
\]
即小cube位于大cube各面外扩aη/(2n)的cube内。固定大端v，小端中心全部位于边长R_v−a+aη/n的真实中心cube。于是
\[
\int_{u:N_\eta,u\text{小端}}\mu(du)\le\kappa_\eta/q_-,
\quad \frac1{m_v}\int_{u:N_\eta,u\text{小端}}du\le\tau_\eta/q_-,
\]
\[
\kappa_\eta=(b/a-1+\eta/n)^n,
\qquad \tau_\eta=\left(\frac{b/a-1+\eta/n}{b/a}\right)^n\le1.
\]
这里积分的仅是真实接收中心体积；没有将f的边界质量换为体积。使用f(Q_u△Q_v)≤m_u+m_v，将两项分别与上述两种中心容量配对。在固定原(y,r)层，近包含分支密度同时被
\[
V_r(y),\qquad\frac{\kappa_\eta+\tau_\eta}{q_-J_r(y)}V_r(y)
\]
支配。前者来自它是原正方差的子支，后者来自上述定向积分。

利用原严格low-J时钟收据∫ℓ∫f1_{J<T}V≤λTW，并保留全第一矩∫ℓ∫fV=X_q，在辅助T=(κ+τ)/(q_-ε_1)处拆分，得到
\[
B_N\le\varepsilon_1X_q+\frac{\lambda(\kappa_\eta+\tau_\eta)}{q_-\varepsilon_1}W.
\]
这是积分分支的实际付款。辅助T不改变原H或J，等号归高T，跨阈原子不拆分。κ+τ=0时分支为零，直接处理。

现在取η_n=\tfrac12\log(n+2)。对n≥1有η_n≤n，并且κ≤(1+η_n/n)^n≤e^{η_n}=√(n+2)。所以
\[
\boxed{B_N\le\varepsilon_1X_q+
\frac{4(\sqrt{n+2}+1)}{3\varepsilon_1}W.}
\]
对应的边长外扩为a log(n+2)/(2n)，各面外扩为a log(n+2)/(4n)，二者不能混淆。此结论包含非嵌套接收对；精确嵌套的更好常数是其子结果，不再另付一遍。直接用原H还可得B_N≤(κ+τ)X_q/(q_-H)，不默认H已有任何新选择。

## 二、联合少失配：先积分实际中心，再处理坐标

在原有向式中，u捕获y,z，v捕获y而不捕获z。令k(z;v)为z不在Q_v内的坐标数。取K=e^{√n}，p=ceil log(n+2)，U_u^n=Km_u/q_-。定义L(u,v,y,z)为
\[
K^{-1}\le m_v/m_u\le K,\quad1\le k(z;v)\le p,
\quad\|y-z\|_1\ge4pU_u.
\]
固定u,y,z，可能接收v的半径区间为L_u^n=m_u/(Kλ)至U_u。边长t的捕获y且失配数≤p的中心集合是嵌套的，体积为
\[
t^n\Pr\left\{\sum_i\mathrm{Bern}(\min(|y_i-z_i|/t,1))\le p\right\}.
\]
独立性只表达真实Lebesgue中心cube的乘积体积，绝不用于f的坐标。因为|y_i−z_i|≤R_u≤U_u，总失败率≥||y−z||_1/U_u，指数Markov加真实中心layer积分给
\[
C=\frac{1+2\sqrt n+\log(4/3)}{q_-}
 e^{p-4(1-e^{-1})p}\le\frac3{q_-(n+2)}.
\]
完整推导见face附件。由同一个min(V,CV/J)原clock结算，得到B_L≤ε_2X_q+4W/[ε_2(n+2)]。这是整体联合计数的容量收益，不是把1/k形式分配误认为自动省去坐标总数。

## 三、辅助原式分解：合法但不是优先全账

两种证明来自同一原有向正被积式。先取对称mask N，再在其补集取L：
\[
B_H=B_N+B_{\neg N,L}+B_{\rm rest},
\quad B_{\rm rest}=B_{\neg N,\neg L}\ge0.
\]
face定理允许额外正限制，因此B_{¬N,L}服从上式B_L预算，无须再次支付N。于是
\[
\boxed{B_H\le B_{\rm rest}+(\varepsilon_1+\varepsilon_2)X_q+
\left[\frac{4(\sqrt{n+2}+1)}{3\varepsilon_1}
+\frac4{\varepsilon_2(n+2)}\right]W.}
\]
这条原式分解合法，但它重新留下此前已付的质量可比交通，因此不能作为本轮优先全账。它不与第364轮3λHW及旧path付款相叠；没有再次扣平方。剩余是几何上不近包含的原有向对，且质量比、少失配、距离三个条件至少一个不满足。多失配不能免费再取1/p；近来源和质量不比也未被本轮付清。此明确补集仍可能承担主要难度。

原入口2和外乘Λ保留；完整费用与独立软层、尺度、历史时间等缺口见ledger。一般root界仍未取得。

## 四、真正新增的已付范围：接回第337轮高质量过去

已逐字核读第336、337轮README及第337轮主证明。第336轮整个质量可比族已有根阶预算，不能把上节face子片列成新增付清范围。第337轮给出
\[
B_H(f,\nu)\le G_{K,>h}+\varepsilon_0X_q+F_{\varepsilon_0,K,h}W,\qquad \nu\le f,
\]
\[
F_{\varepsilon_0,K,h}=\frac{\lambda}{q_-\varepsilon_0}(1+2\log K+2/K)
+\lambda h+\frac\lambda{q_-}(1+\log K).
\]
其中G保留原y高J和clock，在有向m_u>Km_v、全局严格质量过去Z_y(m_u/K-)>h上，损失是m_u−m_v；Z_y(s-)=∫E c_v(y)1_{m_v<s}μ(dv)。不得把G误认为普通未加历史门的对称差。

以同一对称几何mask N分割G。对每个无序pair，正质量差≤f(Q_u△Q_v)，且G的质量定向每对只计一次。因此
\[
0\le G_{K,>h,N}\le B_N.
\]
此支不交于第337轮已付P及低过去G；使用B_N作为上界没有重用任何负平方信用。因此得到优先新总账
\[
\boxed{B_H(f,\nu)\le G_{K,>h,\neg N}
+(\varepsilon_0+\varepsilon_1)X_q
+\left[F_{\varepsilon_0,K,h}+\frac{4(\sqrt{n+2}+1)}{3\varepsilon_1}\right]W.}
\]
取K=e^{√n}、h=√n/q_-，新增来源费为O_{ε1}(√n)W，保留旧根阶费用；此时K>λ/q_-，大质量端同时是大边长端。新的余项要求小质量cube至少有一坐标越出大cube的薄外扩。它仍带原高过去门、原物理时钟、原J及完整f；没有重新归一化或丢掉门。

这是真正扩大已付范围的部分，但没有证明新增支在困难域占固定比例，也尚无完整困难域数值实例。不存在这一比例的数值证书不影响解析子支预算，却不允许宣称全部余项显著减少或已闭合。旧path总账另保留，不与上述替代归约相叠。face可改进已付near的一部分常数；本轮不将其再加进优先账收费。

## 本机检验及证据边界

主代理运行capacity脚本5351项：5000项Fraction核验1500种实际正体积中心shell半径场及500个最小半径局部中心外包络等式检查（不称全部定向分支尖锐）；351项80位Decimal检验根宽度常数，维度范围1至10^6。解析一般不等式由上述证明给出，Decimal不是区间证书。中心积分使用均匀紧支撑来源保证q=1，仅检验几何容量；未声称原highpast困难域实现。

主代理另复跑face内嵌5213项：3382项Fraction与1831项65位Decimal，后者不是区间证书。分阶段先查坐标归属与低维体积，再查不同失配数及半径端点，最后扩大维度常数范围至65536。具体重复计数及参数见numeric附件。作者对称差恒等式检查另列，不混作主代理复跑。

历史只作有界去重检索，未发现相同原槽、同容量常数的归档付款，不声称对全部历史作了完备检索。采用A02技能核查正限制与费用方向；没有调用未证密度帽或一般稳定性。保持最多必要Agent，独审先筛命题再读证明。只生成LaTeX源，不编译PDF；没有可归属各模型的扣额数据。
