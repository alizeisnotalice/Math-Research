# R366 — Joint low-failure face capacity for actual comparable-mass receivers

## 1. Result and allocation

Work only in the full-f hard matching slot of R363/R337, with the original real receiver measure dmu(v)=dv/m_v, m_v=f(Q_v)=q_vR_v^n, q_-<=q_v<=lambda, a<=R_v<=b<=2a, original J_y(r), high gate J_y(r)>=H>0 and physical ell including its b atom. No source density or source-coordinate independence is assumed.

For an ordered loss tuple with y,z in Q_u, y in Q_v and z notin Q_v, put

    k(z;v)=sum_(i=1)^n 1_{|z_i-v_i|>R_v/2}.

Cube boundaries may be assigned consistently; all changes there are null in the source integrals for L1 f. Then k>=1 and the EXACT face allocation is

    1_{z notin Q_v}=sum_i 1_{|z_i-v_i|>R_v/2}/k(z;v).      (1)

This identity alone improves no fee. The estimate below integrates the JOINT count event in the actual receiver center variable, before summing faces. Product structure is used only for Lebesgue center boxes, not for the arbitrary source distribution.

Fix K>=1, an integer p>=1 and d>0. For each capturing receiver u define

    L_u^n=m_u/(K lambda),  U_u^n=K m_u/q_-.

Let B_(K,p,d) be the positive subintegral of the ORIGINAL ordered hard variance B_H, retaining exactly these additional predicates inside its y,u,v,z integral:

    K^(-1)<=m_v/m_u<=K,
    1<=k(z;v)<=p,
    ||y-z||_1>=d U_u.                                    (2)

The original y,z capture in Q_u and y capture in Q_v remain. No full J, receiver selector, or physical time is changed. All predicates can equivalently be retained in the summands of (1), and their sum is B_(K,p,d).

Set

    c0=1-exp(-1),
    e_(p,d)=min(1,exp(p-c0*d)),
    C_(K,p,d)=[1+2log K+log(lambda/q_-)] e_(p,d)/q_-.       (3)

For every eps>0, the following is a genuine branch receipt:

    B_(K,p,d)<=eps X_q+(lambda/eps) C_(K,p,d) W.            (4)

There is also the direct high-row bound

    B_(K,p,d)<=C_(K,p,d) X_q/H.                           (5)

For the original root mass ratio K=exp(sqrt(n)), take

    p=ceil(log(n+2)), d=4p, lambda/q_-=4/3.

Then, with an elementary analytic constant bound,

    C_(K,p,4p)<=3/[q_-(n+2)],
    B_(K,p,4p)<=eps X_q+4 W/[eps(n+2)].                   (6)

The piece paid in (6) has few failed coordinates despite large aggregate source separation; the proof shows it has little actual center capacity. In small dimensions where (2) is impossible, the piece is simply zero. This gives a better coefficient on this specified portion than the generic near-mass receipt, not a new bound for the whole near-mass or whole B_H term. Its complement includes near source pairs, pairs with more than p failures, and noncomparable masses.

## 2. True center-count volume, with adaptive radii retained

Fix u,y,z with y,z in Q_u and write d_i=|y_i-z_i|. For a possible side length t define the center set

    S_p(t)={v:y in Q_t(v), at most p coordinates of z fail Q_t(v)}.

The sets S_p(t) increase with t. In each center coordinate, the interval capturing y has length t, its part also capturing z has length (t-d_i)_+, and its failing part has length min(d_i,t). Therefore

    |S_p(t)|=t^n P(sum_i Bernoulli(min(d_i/t,1))<=p).       (7)

Equivalently it is the sum of the coefficients of degrees 0,...,p in

    product_i [(t-d_i)_+ + x min(d_i,t)].

The independent Bernoulli variables in (7) express only the product CENTER-volume calculation. They are not source coordinates sampled from f and do not assert any source independence.

Under the near-mass predicate in (2), actual matching gives

    L_u<=R_v<=U_u,
    1/m_v<=1/(q_-R_v^n).

Moreover R_u<=U_u, so d_i<=R_u<=U_u. For all t<=U_u,

    sum_i min(d_i/t,1)>=sum_i d_i/U_u>=d.

Exponential Markov applied to the center-box count gives

    |S_p(t)|/t^n
      <=exp(p) product_i[1-c0 min(d_i/t,1)]
      <=exp(p-c0 d),                                     (8)

as well as the trivial upper bound 1. This bound is uniform on the WHOLE physical candidate interval [L_u,U_u]; there is no separate source-pair choice of the actual R_v.

Because S_p(t) is nested, the real-center layer envelope obeys

    integral dv sup_(L_u<=t<=U_u) t^(-n)1_{S_p(t)}(v)
      =|S_p(U_u)|/U_u^n
           +n integral_(L_u)^(U_u)|S_p(t)|t^(-n-1)dt
      <=[1+n log(U_u/L_u)] e_(p,d).                       (9)

For example this identity follows by assigning each center its first entry time into S_p, clipped below at L_u, and integrating the exact radial tail. It includes the base S_p(L_u) volume; no boundary atom is omitted. If p>=n, S_p(t)=Q_t(y) and the estimate remains valid (the nontrivial exponential factor cannot be forced by impossible separation).

Dropping the original R_v<=r gate only as a positive upper bound, (9) proves

    integral_{v:near} c_v(y)1_{1<=k(z;v)<=p}dmu(v)
      <=C_(K,p,d)                                       (10)

for source pairs satisfying the distance predicate (2). To use nested S_p in (9), the lower restriction k>=1 was dropped in (10); retaining k<=p is the essential joint geometric restriction. The identity n log(U_u/L_u)=2log K+log(lambda/q_-) gives exactly (3). Radius adaptation and the real Lebesgue receiver measure have both been accounted for.

## 3. Original J and one original-clock payment

At fixed y,r, let D_(K,p,d)(y,r) be the numerator of B_(K,p,d) before division by J_y(r). Integrate v first with (10), then z, using only its actual restriction z in Q_u and f(Q_u)=m_u. This gives

    D_(K,p,d)(y,r)<=C_(K,p,d) V_y(r),
    V_y(r)=integral_(E_r)c_u(y)du.                        (11)

The other useful bound follows without (10): deleting all added predicates and replacing f(Q_u minus Q_v) by m_u gives

    D_(K,p,d)(y,r)/J_y(r)<=V_y(r).                        (12)

Thus on original high rows the branch density is at most

    min(1,C_(K,p,d)/J_y(r)) V_y(r).

The matched first-moment identity and the previously established STRICT low-clock estimate are

    integral f(y)dy integral ell(dr)V_y(r)=X_q,
    integral f(y)dy integral ell(dr)1_{J_y(r)<T}V_y(r)
            <=lambda T W.                               (13)

The latter keeps inclusive J and excludes the whole atom crossing T; the terminal b atom is included. It does not restart J or discard earlier receivers. Split the branch only by J<T versus J>=T, apply (12) to the former and (11) to the latter, and obtain

    B_(K,p,d)<=lambda T W+[C_(K,p,d)/T]X_q.

Take T=C_(K,p,d)/eps to prove (4). When the constant vanishes, the branch is zero; otherwise T>0. The existing original J>=H gate may only decrease these integrals, and directly yields (5). No low-clock estimate is charged separately for each coordinate.

For (6), e>8/3 implies 3-4/e>3/2, so

    exp(p-4c0 p)<=exp(-3p/2)<=(n+2)^(-3/2).

Also log(4/3)<1 and 2+2sqrt(n)<=3sqrt(n+2). Hence

    [1+2sqrt(n)+log(4/3)]e_(p,4p)<=3/(n+2),

which proves the stated constants analytically; numerical rounding is not used.

## 4. Ledger scope and remaining obstacle

This is an actual positive subintegral receipt. Inserting it into a partition of the original B_H is legitimate; it must REPLACE payment of this same subintegral in a generic near-mass bound, not be added as another claimed reduction after paying the whole near-mass term. If used in the original outer entrance its displayed fees are multiplied by the original factor 2 and exterior Lambda. No old square credit is spent again.

The source-independent gain is the joint low-count estimate (8), not the formal reciprocal k in (1). The many-failure branch does not inherit a 1/p saving for free: summing coordinate faces would reintroduce their total number unless a separate additive face budget were proved. No such general budget is shown here. Consequently neither the many-failure complement nor the source-close complement receives a new estimate, and the general root target remains open.

## 5. Actual local checks

The following uses exact rational center-volume polynomials and exact face allocation. The exponential estimates are checked at 65-digit Decimal precision as diagnostics; (8) and the constants in (6) have the analytic proof above. The finite radius-envelope calculation is the exact center integral for its nested grid of candidate radii, not a source-density model or an independently chosen field for each source pair.

~~~python
from fractions import Fraction as F
from decimal import Decimal,getcontext
from itertools import product
getcontext().prec=65
counts={'allocation':0,'volume':0,'nesting':0,'envelope':0,'constants':0}
def ck(ok,k):
    assert ok,k
    counts[k]+=1
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
def volume(ds,t,p):
    coeff=[F(1)]
    for d in ds:
        hit=max(F(0),t-d);miss=min(d,t)
        out=[F(0)]*(len(coeff)+1)
        for j,v in enumerate(coeff):out[j]+=v*hit;out[j+1]+=v*miss
        coeff=out
    return sum(coeff[:p+1],F(0)),sum(coeff,F(0))
for n in range(1,9):
    for bits in product([0,1],repeat=n):
        k=sum(bits)
        if k:ck(sum((F(v,k) for v in bits),F(0))==1,'allocation')
c0=1-(-Decimal(1)).exp()
for n in range(1,13):
    for seed in range(1,9):
        ds=[F((seed*(i+2)+i)%17,10) for i in range(n)]
        L=F(1);U=F(2);radii=[F(1),F(5,4),F(3,2),F(7,4),F(2)]
        d=sum(ds,F(0))/U
        for p in [1,2,min(4,n)]:
            probcap=min(Decimal(1),(Decimal(p)-c0*dec(d)).exp())
            prev=F(0);envelope=F(0)
            for t in radii:
                v,total=volume(ds,t,p)
                ck(total==t**n,'volume')
                ck(v>=prev,'nesting')
                ck(dec(v/t**n)<=probcap+Decimal('1e-56'),'volume')
                envelope+=(v-prev)/t**n;prev=v
            bound=(1+Decimal(n)*(dec(U)/dec(L)).ln())*probcap
            ck(dec(envelope)<=bound+Decimal('1e-56'),'envelope')
for n in list(range(1,101))+[256,1024,65536]:
    N=Decimal(n);p=int((N+2).ln().to_integral_value(rounding='ROUND_CEILING'))
    val=(1+2*N.sqrt()+(Decimal(4)/3).ln())*(Decimal(p)-4*c0*Decimal(p)).exp()
    ck(val<=3/(N+2),'constants')
print('PASS joint-face center checks',counts,'total',sum(counts.values()))
~~~


Actual execution of the final embedded script returned:

~~~text
PASS joint-face center checks {'allocation': 502, 'volume': 2880, 'nesting': 1440, 'envelope': 288, 'constants': 103} total 5213
~~~

Exact arithmetic verifies the allocation, volume and nesting formulas; Decimal evaluation checks the exponential comparisons and displayed constants. These checks do not claim realization of the original full high-J cube field. The actual-field receipt is established by (7)-(13) with the original receiver measure and physical clock.
