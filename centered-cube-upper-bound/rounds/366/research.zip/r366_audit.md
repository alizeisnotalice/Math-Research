# R366 independent audit — pre-proof screen

Status: FINAL PASS for the near-containment receipt, its priority connection to the archived R337 high-past remainder, the auxiliary face estimate, final integration and stated evidence scope. Only this file is reviewer-owned. General B_H closure and a fresh whole-history audit are not claimed. Final bindings refer to the bytes reviewed below.

## Frozen original branch and orientation
Use the real matched hard field, full f in L1, m_u=f(Q_u)=q_uR_u^n with q_->0, a<=R_u<=b<=2a, original E_r and dmu=du/m_u. Both source/receiver occurrences and full J_r are unchanged; H>0 remains the ORIGINAL high-row gate. At each (r,y), the symmetric pair integrand c_u(y)c_v(y) f(Q_u triangle Q_v) is nonnegative. Orient by (R_u,u) preceding (R_v,v), with a measurable lexicographic tie break. The factor1/2 in the full symmetric formula is exactly canceled by the two orientations. No extra factor2 occurs. The diagonal contributes zero; source/history gates are not recomputed.

For nearcontainment 2||u-v||inf<=R_v-R_u+a eta/n with 0<=eta<=n, every small center u lies in the cube about v of side R_v-a+a eta/n. This follows from R_u>=a and does not assert source mass is bounded by volume. The receiver density 1/m_u<=1/(q_-a^n) gives the small-end mu capacity <=kappa_eta/q_-, kappa_eta=(b/a-1+eta/n)^n. Separately, m_u dmu(u)=du and m_v>=q_-R_v^n give the weighted capacity integral_small m_u dmu/m_v <=tau_eta/q_-, tau_eta=[(b/a-1+eta/n)/(b/a)]^n. The monotonicity in R_v used in this second inequality depends on a eta/n<=a; this is why eta<=n is retained. Capturing y, E_r and all original masks only restrict the positive center set.

Using f(symdiff)<=m_u+m_v, the oriented branch at fixed (r,y) is <=(kappa_eta+tau_eta)V_r(y)/(q_-J_r(y)). It is also <=V_r(y), since it is a positive subtraffic of the full original variance M-square and M_r=V_r in the matched contract. These are two bounds for the same branch; no negative square is independently re-spent.

Set the AUXILIARY row threshold T=(kappa_eta+tau_eta)/(q_-epsilon)>0 while retaining original J>=H. The part J<T is bounded by the original strict-low-T first moment, <=lambda T W after physical-clock integration; a whole atom crossing T is excluded, not cut in rank. On J>=T the second bound gives <=epsilon V and then epsilon X_q by the complete matched first moment. Hence B_nearcontain<=epsilon X_q+lambda(kappa_eta+tau_eta)W/(q_-epsilon). Original inclusive ell([R,b])=R^-n includes a and the b atom; no extra radial or chronological-atom fee is dropped. If b=a and eta=0, both capacities vanish and the nearcontainment du-pair branch is zero; handle it directly rather than invoking a T>0 lemma with T=0. Radius/center boundary equalities cause no factor or source-density issue.

For eta=.5 log(n+2), log(n+2)<=2n for n>=1 ensures eta<=n. The octave condition gives kappa_eta<=(1+eta/n)^n<=e^eta=sqrt(n+2), tau_eta<=1. Thus the stated source coefficient is root order for fixed epsilon, across all mass ratios, but applies only to the original geometric subbranch. Its complement retains the same full J and all original sources/prefixes. This is an alternative original-B decomposition and cannot be added to the previously paid path ledger or to another payment of the same pair traffic. It is not a general B_H budget.

## Actual narrow local check
A reviewer-local standard-library Python Fraction exercise actually passed 576 scalar assertions over n=1..8, three octave ratios including1, four eta/n values including0 and1, and three possible big radii. It checked both center-volume monotonicity inequalities and tau<=1, including the zero-capacity endpoint. This is exact scalar algebra only, not a cube-field/high-J realization and not a parent/author pipeline count.

## Second independently screened receipt: joint low-failure face subpiece
Full author proof /tmp/r366_face.md is PASS. In the ORIGINAL ordered hard loss, u captures both y,z and v captures y but misses z. The exact 1/k face allocation holds for k>=1, but alone improves no budget. Restrict original tuples by mu/K<=mv<=Kmu, 1<=k_fail<=p and ||y-z||1>=d Uu, Uu^n=Kmu/q_-. This is a positive restriction with original full J and all original clocks unchanged.

For fixed u,y,z, candidate-center sets S_p(t) capture y and fail z in at most p coordinates. They increase with t. Their volume t^n times a Poisson-binomial lower-tail probability comes solely from product LEBESGUE CENTER intervals; it does not assert any coordinate independence for f or for pi_u. Because y,z in Qu implies di<=Ru<=Uu, every candidate t<=Uu has sum min(di/t,1)>=sum di/Uu>=d. Exponential Markov gives the uniform factor min(1,exp[p-(1-e^-1)d]).

Actual near-mass and q-band constraints place Rv in [Lu,Uu], Lu^n=mu/(Klambda). The nested center envelope integrates to |S_p(U)|/U^n+n integral_L^U |S_p(t)|t^-n-1 dt, including its base block. Therefore its mu-v capacity is <=[1+2logK+log(lambda/q_-)]e_(p,d)/q_-. The lower restriction k>=1 is dropped only for this positive bound; k<=p is retained. Both original and adapted radii are handled by the SAME actual-center envelope, without privately optimizing an actual selector for each source pair.

The branch row is bounded by min(V,CV/J). Original strict-low-T and high-T splitting, keeping original J>=H, yields epsilon X_q+lambda C W/epsilon; direct original-high-J bound is CX_q/H. At K=e^sqrt(n), p=ceil log(n+2), d=4p, e>8/3 gives exponent <=-3p/2, and 1+2sqrt(n)+log4/3<=3sqrt(n+2), giving C<=3/[q_-(n+2)] and source4/[epsilon(n+2)]W. If the distance/count predicates are impossible, the branch is simply zero. No free benefit is given to many failures or to source-close tuples.

For combined use, first delete the symmetric nearcontainment subset of the original ordered positive loss, then apply this face restriction only to its remaining ordered tuples. This gives disjoint receipts and leaves the full complementary original traffic unpriced. A generic payment of all near-mass traffic cannot also be charged for this same subpiece. Original outer entrance factor2 and Lambda apply once to each fee; no whole old-square credit is spent again.

Author-reported 5213 checks comprise 3382 exact Fraction assertions (502 allocation,1440 volume identities,1440 nesting) and1831 ordinary Decimal diagnostics (1440 exponential-volume comparisons,288 envelope,103 constants). In particular the reported volume count2880 mixes exact identities and Decimal comparisons. No full author run was repeated by the reviewer. These are center-volume/scalar checks, not a native high-J/Far realization or a general root budget.

## Primary geometry author proof
Read /tmp/r366_geometry.md in full and checked its final wording correction: E is a measurable Lebesgue set of finite measure, not a finite collection of point receivers. The vague extension via positive truncations is removed; no false monotonicity of A^2/J or pair/J under receiver truncation is asserted. The given finite-band/matching hypotheses supply finite moments directly. The final geometry SHA is8ec9dd5d8b61e97fcea853f5eeb6a3c1e3c775448a27ca5ad318913cf133ee9c.

The clamped-center intermediate cube C in section2 really lies in the big cube and has Qu intersect C=Qu intersect Qv. Thus Qu triangle Qv is the DISJOINT union of Qu triangle C and Qv minus C. This holds in the common-capture case relevant to the original source row, with harmless L1 boundary conventions. C is only a geometric device; no receiver equation, FIRST property or mass cap is transferred to it. The payment uses actual endpoints only. Side-length tolerance h=a log(n+2)/(2n) moves each face by h/2=a log(n+2)/(4n), as the final main states. Zero kappa+tau is handled directly. The nested eta0 improvement is an alternative subcase, not an additional charge.

Geometry author reports1000 Fraction diagnostics (24 projection,120 symdifference,120 ties,720 capacity coefficients,16 clock). These have finite receiver quadrature in the identity examples, not native continuum high-J realization; they are author-reported only in this round's parent totals.

## Priority correction and authoritative R337 connection
The original near-mass family at K=e^sqrt(n) was already paid in R336/R337. Therefore the face subpiece, though its tighter estimate is correct, is only a coefficient improvement on an already paid family; it is NOT evidence of an expanded family and is not added to the priority ledger. The earlier two-receipt direct decomposition remains a valid ALTERNATIVE but must not be used to forget existing near-mass payments.

Independently read /tmp/r337_main.md in full. Also read the authoritative ZIP member main.md in /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/337/research.zip. Its SHA e7ae785f3a751e5fcd9e45521e78b2103b3e79ecee67ba0be17822fb31b98768 is byte-identical to both the tmp proof and its frozen output checkpoint. The archive member is main.md, not r337_main.md. This is a bounded source-contract check, not a re-audit of all archived history.

R337 provides B_H(f,nu)<=G_(K,>h)+epsilon0 X_q+F337 W for nu<=f, using the unchanged original full-f field. Its residual is the POSITIVE mass-difference integral m_u-m_v on m_u>K m_v and global strict past Z_y(m_u/K-)>h, with original J,H,Er,clock and common capture y. It is not the ordinary source-symmetric-difference loss with the past gate forgotten. F337=lambda[1+2logK+2/K]/(q_-epsilon0)+lambda h+(lambda/q_-)(1+logK).

For the symmetric geometric mask N, each residual mass-oriented pair is counted once, and m_large-m_small<=f(Q_large triangle Q_small). The original high-past gate may be dropped only positively. Thus G_(K,>h,N)<=B_N with NO extra factor2. At K=e^sqrt(n)>lambda/q_-, the large mass endpoint is also the large-radius endpoint, consistent with the primary orientation. N is independent of the external source z and symmetric under endpoint exchange, so it respects the original cancellation and the whole-pair comparison. nu<=f is used once as R337's positive domination; the new bound applies to the resulting full-f G and is priced with W=integral f, not W_nu.

Consequently the priority conclusion is B_H(f,nu)<=G_(K,>h,notN)+(epsilon0+epsilon1)X_q+[F337+4(sqrt(n+2)+1)/(3epsilon1)]W. This legitimately retains the old near/favorable/low-past payment and prices only a positive restriction of its formerly unpaid high-past term. Using the full B_N as an upper comparator may include other pairs, but does not spend another negative-square credit; the compared target is wholly inside the remaining G. K=e^sqrt(n),h=sqrt(n)/q_- give the stated root-order source price. No fixed paid proportion or positive-volume realization of all difficult gates is asserted. Remaining G_(K,>h,notN) has the original high-past, high-J and physical-clock qualifications and is unpaid.

## Final integration, numerical scope and fees
Read final /tmp/r366_main.md, /tmp/r366_ledger.md, /tmp/r366_readme.md, /tmp/r366_numeric.md, /tmp/r366_capacity_check.py and /tmp/r366_capacity_result.json in full, including their revised priority/de-duplication and sharpness wording. PASS without an outstanding correction request. The auxiliary exact decomposition B_H=B_N+B_(notN,L)+B_(notN,notL) is sound because N is a SYMMETRIC mask. Its original directed expression agrees with the symmetric-difference N expression, and the face bound tolerates additional positive restrictions. Its two independently split low-clock receipts have separate epsilon1/epsilon2 prices; no union fraction or one epsilon is obtained for free. This alternative is NOT charged in addition to the priority R337 route.

The priority original entrance remains8lambda H W+2d_eff A_n W_nu/H+2B_H. Substitution gives2G_(high,notN),2(epsilon0+epsilon1)X_q and2(F337+C_N)W, followed by the original Lambda=128/119 on EVERYTHING. Relative to R337, only2Lambda epsilon1 and2Lambda C_N are added. If epsilon0=epsilon1=epsilon/2 the slot receiver coefficient is2Lambda epsilon, not a statement that such global absorption room has already been authorized. The R364 coefficient14 route and the old path/head/recapture ledger are retained as alternatives only, not appended. Historical ledger text is preserved in the final file. All soft, threshold, far/lowpe/extreme-scale, chronological atom, source/physical-scale aggregation, H-selection and limit obligations remain explicit.

The capacity script actually integrates real positive-volume infinity-norm center shells with a fixed common radius per shell, choosing Ru in[1,Rv]. The shell intersection cutoffs enforce nearcontainment. Uniform compact source in a sufficiently large box gives exactlym=R^n,q=1 for those tests; this is a geometry diagnostic, not a density assumption on the theorem's arbitrary f or an original high-past realization. Parent reports1500 radius fields and500 equality checks of the UNORIENTED local minimum-radius center OUTER envelope. Equal-radius lex orientation could cut that set, so those checks do not prove sharpness of the full oriented receipt; the revised main/numeric text correctly states this limitation.

Parent reports actual fresh5351 capacity assertions=5000 Fraction+351 ordinary80-digit Decimal root-width checks, and5213 face assertions=3382 Fraction+1831 ordinary65-digit Decimal diagnostics. Combined parent counts are8382 Fraction+2182 Decimal, not10564 exact proofs. Decimal comparisons are not interval certificates. The JSON's5351/1500/500 fields and sample root-width rows match code/notes scope. Parent did not merge the geometry author's1000 checks or the reviewer's576 narrow Fraction scalar checks into these counts. No full pipeline was rerun by the reviewer after reading the final scripts. Finite grids/capacity examples do not certify the remaining G or any dimensional optimum.

The two primary candidate mechanisms from R365 are not now assumed equivalent or sufficient. The present positive branch proof and its R337 connection stand on their explicit actual-center capacities, full matching and the old low-clock lemma. No general weak-type/root closure, full-history novelty search, literature/skill-use claim, TeX/PDF compilation, ZIP packaging integrity or Git state is certified by this audit.

## Final SHA256 bindings

- `/tmp/r366_geometry.md` — `8ec9dd5d8b61e97fcea853f5eeb6a3c1e3c775448a27ca5ad318913cf133ee9c`

- `/tmp/r366_face.md` — `3ea2520be6313593e1de6c7d649b97b7bc1ebd675e023ec916f7069e0e16fa93`

- `/tmp/r366_main.md` — `a0f1dab36bfbf14b678866802aacf9c839c08c7534ec86e7c4dc6b6ca39b2f95`

- `/tmp/r366_ledger.md` — `d5656bab86d7261f82460f51aac82397b098d2435c059be5840fff9427f7219d`

- `/tmp/r366_numeric.md` — `4865f23387843c3de0b0f8d7e4efa202105456f5eb28973a0027ceb8f55a5d5a`

- `/tmp/r366_readme.md` — `aa7a33b0d4878643b6d427a873bf7dde4a9876134bb21312ebc5ba99dd2f0420`

- `/tmp/r366_capacity_check.py` — `a00d3542243e688b9fa7ac441c2b1f755dc772794451a5cc3535773148cce6e1`

- `/tmp/r366_capacity_result.json` — `f6a9659a133d78beca49f6e7a73667f8d8dcc88cf88f883d48dd310025de0f9c`

- `/tmp/r337_main.md` — `e7ae785f3a751e5fcd9e45521e78b2103b3e79ecee67ba0be17822fb31b98768`

- `/tmp/r365_audit.md` — `cb8532fbc66e9818d265aacdf7198bf5a065f30d97c4db3623b2fb56bafdb8c1`

- `/tmp/r365_ledger.md` — `db06cb2d4ed9b17d42113007b1e5f35a5045b2a98c97d3ee8ae2a195e345cc58`

- Authoritative R337 archive `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/337/research.zip` — `e01e2d09d0e695d950222518d4b3b3d871dfbca7619fc66e4c98414e10bc4c00`; member `main.md` SHA256 `e7ae785f3a751e5fcd9e45521e78b2103b3e79ecee67ba0be17822fb31b98768`.
