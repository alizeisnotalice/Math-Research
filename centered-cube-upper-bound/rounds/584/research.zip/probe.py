"""R584: exact cut/flow source routing of locked volume-dual cell masses only."""
from fractions import Fraction as F
from pathlib import Path
from collections import deque
from itertools import product
import argparse,json,hashlib,time,sys,platform,resource,signal,shlex
ap=argparse.ArgumentParser();ap.add_argument('--r583-json',type=Path,default=Path(__file__).resolve().parent/'ccu_r583_probe.json');ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--metadata-only',action='store_true');args=ap.parse_args();start=time.perf_counter()
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('120s routing guard')));signal.alarm(120)
LOCKED='a224dc4a6bfb0ee549d07457cf52a33c1309ec1c791c941b32783360a8e8366c'
MATH_LOCK='6479bb96b7db1906c5a90f0b35df8c725f09d2fb841e9afefedc43682a635ff5'
R583_SCRIPT='eaedc1d51990f19fe1dc6b9de0a556f682c7f9800018e78fdb7e9a27fb2acadd'
raw=args.r583_json.read_bytes();input_raw_sha=hashlib.sha256(raw).hexdigest();baseline=json.loads(raw);del raw
OMIT={'runtime_seconds','peak_rss_bytes','rss_before_solver_bytes','command'}
def canonical_math_hash(value):
 h=hashlib.sha256()
 def emit(v):
  if isinstance(v,dict):
   h.update(b'{');keys=sorted(k for k in v if k not in OMIT)
   for i,k in enumerate(keys):
    if i:h.update(b',')
    h.update(json.dumps(k,ensure_ascii=False,separators=(',',':')).encode());h.update(b':');emit(v[k])
   h.update(b'}')
  elif isinstance(v,list):
   h.update(b'[')
   for i,q in enumerate(v):
    if i:h.update(b',')
    emit(q)
   h.update(b']')
  else:h.update(json.dumps(v,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode())
 emit(value);return h.hexdigest()
input_math_sha=canonical_math_hash(baseline);assert input_math_sha==MATH_LOCK
assert baseline['script_sha256']==R583_SCRIPT and all(c['script_sha256']==R583_SCRIPT for c in baseline['cases'].values())

def routing(case):
 t0=time.perf_counter();weights=list(map(F,case['input']['masses_exact']));N=len(weights);ALL=(1<<N)-1;W=sum(weights)
 def mass(mask):return sum(weights[i] for i in range(N) if mask>>i&1)
 columns=case['columns'];byid={c['column']:c for c in columns};eligible=set(case['eligible_parent_masks']);fullcols={}
 for S,K,j in case['all_parent_core_pair_to_column_mapping']:
  if S==K:
   assert S not in fullcols;fullcols[S]=j
 assert set(fullcols)==eligible
 masks={j:int(c['incidence_cell_row_bitmask_hex'],16) for j,c in byid.items()}
 demands=[]
 for d in case['volume_optimization']['dual_nonzero_cell_masses']:
  row=d['cell_row'];y=F(d['y_exact']);assert y>0
  parents=sorted((S for S,j in fullcols.items() if masks[j]>>row&1),key=lambda S:(mass(S),S));assert parents
  neighborhood=0
  for S in parents:neighborhood|=S
  assert neighborhood and not neighborhood&~ALL
  demands.append({'row':row,'y':y,'parents':parents,'N':neighborhood})
 demands.sort(key=lambda d:d['row']);rho=sum(d['y'] for d in demands);assert rho==F(case['volume_optimization']['dual_objective_lower_rational_exact'])
 # Recheck inherited volume-dual feasibility without geometry/LP recomputation.
 for j,c in byid.items():
  lhs=sum(d['y'] for d in demands if masks[j]>>d['row']&1)
  assert lhs<=F(c['full_volume_lower_rational_exact'])
 naive=[F(0)]*N;naive_routes=[]
 for d in demands:
  S=d['parents'][0];m=mass(S);alloc=[]
  for i in range(N):
   if S>>i&1:
    v=d['y']*weights[i]/m;naive[i]+=v;alloc.append({'source':i,'mass':str(v)})
  assert sum(F(a['mass']) for a in alloc)==d['y'];naive_routes.append({'cell_row':d['row'],'smallest_parent':S,'parent_mass':str(m),'routes':alloc})
 naive_cong=max(v/w for v,w in zip(naive,weights));average=rho/W
 ratios=[];best=F(-1);bestcuts=[];properbest=F(-1);propercuts=[]
 for A in range(1,ALL+1):
  captured=[d for d in demands if not d['N']&~A];demand=sum((d['y'] for d in captured),F(0));m=mass(A);ratio=demand/m
  ratios.append([A,str(demand),str(m),str(ratio)])
  rec={'source_mask':A,'source_mass':str(m),'forced_dual_demand':str(demand),'cut_ratio':str(ratio),'forced_positive_cell_rows':[d['row'] for d in captured]}
  if ratio>best:best=ratio;bestcuts=[rec]
  elif ratio==best:bestcuts.append(rec)
  if A!=ALL:
   if ratio>properbest:properbest=ratio;propercuts=[rec]
   elif ratio==properbest:propercuts.append(rec)
 assert best>=average and naive_cong>=best
 T=best
 # Independent Fraction Edmonds-Karp network. No LP/solver and no infinity arithmetic.
 count=len(demands);src=0;cell0=1;label0=cell0+count;sink=label0+N;nodes=sink+1
 adj=[[] for _ in range(nodes)];cap={};original={}
 def edge(u,v,c):
  assert c>=0 and (u,v) not in original;original[u,v]=c;cap[u,v]=c;cap[v,u]=F(0);adj[u].append(v);adj[v].append(u)
 for d0,d in enumerate(demands):
  edge(src,cell0+d0,d['y'])
  for i in range(N):
   if d['N']>>i&1:edge(cell0+d0,label0+i,rho)
 for i,w in enumerate(weights):edge(label0+i,sink,T*w)
 value=F(0);augmentations=0
 while True:
  parent=[-1]*nodes;parent[src]=src;Q=deque([src])
  while Q and parent[sink]<0:
   u=Q.popleft()
   for v in adj[u]:
    if parent[v]<0 and cap[u,v]>0:parent[v]=u;Q.append(v)
  if parent[sink]<0:break
  v=sink;path=[]
  while v!=src:u=parent[v];path.append((u,v));v=u
  inc=min(cap[u,v] for u,v in path);assert inc>0
  for u,v in path:cap[u,v]-=inc;cap[v,u]+=inc
  value+=inc;augmentations+=1
 assert value==rho
 loads=[F(0)]*N;flowrows=[]
 for d0,d in enumerate(demands):
  items=[]
  for i in range(N):
   if d['N']>>i&1:
    v=original[cell0+d0,label0+i]-cap[cell0+d0,label0+i];assert v>=0
    if v:items.append({'source':i,'mass':str(v)});loads[i]+=v
  assert sum((F(e['mass']) for e in items),F(0))==d['y']
  flowrows.append({'cell_row':d['row'],'routes':items,'all_demand_satisfied_exact':True})
 assert all(v<=T*w for v,w in zip(loads,weights))
 # A maximizing forced-neighborhood cut lower-bounds every possible routing; this feasible flow attains it.
 out={'case':case['case'],'N':N,'W_exact':str(W),'dual_positive_cell_count':count,'dual_mass_rho_exact':str(rho),'rho_over_W_exact':str(average),'minimum_congestion_T_exact':str(T),'T_over_average_exact':str(T/average),'all_nonempty_source_cuts_enumerated':ALL,'empty_source_cut_checked_zero_demand':all(d['N'] for d in demands),'source_cut_table_sha256':hashlib.sha256(json.dumps(ratios,separators=(',',':')).encode()).hexdigest(),'maximizing_source_cuts':bestcuts,'max_proper_cut_ratio_exact':str(properbest),'maximizing_proper_source_cuts':propercuts,'proper_cut_strictly_exceeds_rho_over_W':properbest>average,'T_equals_average':T==average,'naive_policy':'For each actual dual cell choose containing eligible parent of minimum exact mass, ties minimum mask; distribute its y by original source mass/parent mass over that parent.','naive_congestion_exact':str(naive_cong),'naive_over_optimal_congestion_exact':str(naive_cong/T),'shared_routing_strictly_improves_naive':T<naive_cong,'naive_source_loads':[str(v) for v in naive],'naive_source_load_over_original_mass':[str(v/w) for v,w in zip(naive,weights)],'source_weights_exact':[str(w) for w in weights],'actual_full_parent_column_by_mask':[[S,fullcols[S]] for S in sorted(fullcols)],'demand_neighborhoods':[{'cell_row':d['row'],'dual_mass_exact':str(d['y']),'all_containing_actual_full_parent_masks':d['parents'],'source_neighborhood_union_mask':d['N']} for d in demands],'naive_routes':naive_routes,'optimal_rational_routes':flowrows,'optimal_source_loads':[str(v) for v in loads],'optimal_source_capacities_T_times_original_mass':[str(T*w) for w in weights],'optimal_source_loads_over_original_mass':[str(v/w) for v,w in zip(loads,weights)],'all_demands_and_source_capacities_exactly_verified':True,'flow_value_exact':str(value),'flow_augmentations':augmentations,'network_nodes':nodes,'directed_forward_edges':len(original),'inherited_volume_dual_constraints_rechecked_all_columns':len(columns),'proof':'Any routing must send forced demand of N(D) subset A through labels A, so T>=max cut ratio. This actual rational flow has value rho and each source load<=T*m_i, proving matching upper bound. No solver/mincut theorem or numerical tolerance is needed.','runtime_seconds':time.perf_counter()-t0}
 return out

def grid(n):
 # Only the stated analytic grid-classification is inherited; no geometry/parent enumeration here.
 delta=F(1,n*2**n);v=delta**n;corners=list(product((-1,1),repeat=n));sources=list(product((-1,0,1),repeat=n));blocks=[set(product(*((0,s) for s in sig))) for sig in corners]
 rho=2**n*v;W=3**n;target=rho/W;maxratio=F(0);maxcuts=[];table=[]
 for B in range(1,1<<len(corners)):
  U=set();k=B.bit_count()
  for j,K in enumerate(blocks):
   if B>>j&1:U|=K
  ratio=k*v/len(U);assert ratio<=target
  table.append([B,k,len(U),str(ratio)])
  if ratio>maxratio:maxratio=ratio;maxcuts=[B]
  elif ratio==maxratio:maxcuts.append(B)
 assert maxratio==target
 loads={z:F(0) for z in sources};naive={z:F(0) for z in sources};flow=[]
 for j,(sig,K) in enumerate(zip(corners,blocks)):
  total=F(0)
  for z in sorted(K):
   p=F(1)
   for x,s in zip(z,sig):p*=F(1,3) if x==0 else F(2,3)
   y=v*p;total+=y;loads[z]+=y;naive[z]+=v/2**n;flow.append({'corner':j,'source_pattern':list(z),'mass_exact':str(y)})
  assert total==v
 assert all(x==target for x in loads.values()) and max(naive.values())==v and v/target==F(3,2)**n
 return {'n':n,'conditional_neighborhood_model':'Each disjoint residual C_sigma has demand delta^n and source neighborhood product_j{0,sigma_j}; inherited root analytic classification, not numerical geometry certification.','delta_exact':str(delta),'each_corner_dual_mass_exact':str(v),'rho_exact':str(rho),'W_exact':W,'minimum_T_exact':str(target),'equals_rho_over_W':True,'all_nonempty_receiver_corner_subsets_enumerated':len(table),'maximizing_receiver_cut_masks':maxcuts,'receiver_cut_table':table,'product_flow_per_axis':['zero:1/3','sigma:2/3'],'all_source_loads_exact':[{'source_pattern':list(z),'load_exact':str(loads[z])} for z in sources],'actual_product_routes':flow,'uniform_split_zero_source_max_load_exact':str(v),'uniform_split_congestion_over_min_T_exact':str(v/target),'general_scalar_formulas':'T=delta^n*(2/3)^n, zero-source uniform-split congestion=delta^n, ratio=(3/2)^n. Finite n2,n3 calculations checked; root supplies analytic general classification/proof.'}
def graph_diagnostic(case,old_routing):
 weights=list(map(F,case['input']['masses_exact']));N=len(weights)
 def mass(mask):return sum(weights[i] for i in range(N) if mask>>i&1)
 columns=case['columns'];eligible=set(case['eligible_parent_masks']);full={}
 for S,K,j in case['all_parent_core_pair_to_column_mapping']:
  if S==K:full[S]=j
 assert set(full)==eligible
 masks={c['column']:int(c['incidence_cell_row_bitmask_hex'],16) for c in columns};coreunions={}
 for c in columns:
  union=0;M=F(c['parent_mass_M_exact'])
  for S,K in c['all_legal_parent_core_representations']:
   assert not K&~S and mass(S)==M and mass(K)>=M/2
   union|=K
  coreunions[c['column']]=union
 old_neigh={d['cell_row']:d['source_neighborhood_union_mask'] for d in old_routing['demand_neighborhoods']};positive=[]
 for d in case['volume_optimization']['dual_nonzero_cell_masses']:
  row=d['cell_row'];y=F(d['y_exact']);NN=0;GG=0
  for S,j in full.items():
   if masks[j]>>row&1:NN|=S
  for j,bits in masks.items():
   if bits>>row&1:GG|=coreunions[j]
  assert NN==old_neigh[row] and not NN&~GG
  positive.append({'row':row,'y':y,'N':NN,'G':GG,'mN':mass(NN),'mG':mass(GG)})
 changed=[d for d in positive if d['N']!=d['G']];overshoots=[];maximum=F(0);maxcols=[]
 for c in columns:
  M=F(c['parent_mass_M_exact']);j=c['column'];bad=[d for d in positive if masks[j]>>d['row']&1 and d['mN']<M];total=sum((d['y'] for d in bad),F(0))
  row={'column':j,'representative_parent_mask':c['representative_parent_mask'],'representative_core_mask':c['representative_core_mask'],'M_parent_exact':str(M),'overshoot_dual_mass_exact':str(total),'positive_dual_cell_rows_with_mN_lt_M':[d['row'] for d in bad],'original_legal_pair_representations_count':len(c['all_legal_parent_core_representations'])}
  overshoots.append(row)
  if total>maximum:maximum=total;maxcols=[row]
  elif total==maximum:maxcols.append(row)
 for flow in old_routing['optimal_rational_routes']:
  GG=next(d['G'] for d in positive if d['row']==flow['cell_row'])
  assert all(GG>>r['source']&1 for r in flow['routes'])
 return {'positive_dual_cell_count':len(positive),'cells_with_broadened_G_not_equal_fullparent_N':len(changed),'rho_mass_on_changed_cells_exact':str(sum((d['y'] for d in changed),F(0))),'positive_cell_graphs':[{'cell_row':d['row'],'dual_mass_exact':str(d['y']),'N_fullparent_union_mask':d['N'],'G_all_allowed_core_union_mask':d['G'],'mass_N_exact':str(d['mN']),'mass_G_exact':str(d['mG'])} for d in positive],'all_unique_box_M_columns_overshoot':overshoots,'all_original_allowed_parent_core_columns_count':sum(c['original_legal_pair_representations_count'] for c in overshoots),'max_positive_overshoot_dual_mass_exact':str(maximum),'maximizing_overshoot_columns':maxcols if maximum else [],'representative_positive_overshoot_column':maxcols[0] if maximum else None,'N_subset_G_every_positive_cell':True,'old_N_routing_still_legal_in_G_exactly_verified':True,'minimum_G_congestion_same_average_without_new_flow':old_routing['minimum_congestion_T_exact'],'no_new_flow_LP_or_geometry_run_required':True}

if args.metadata_only:
 result=json.loads(args.output.read_text())
 assert result['locked_R583_json_sha256']==LOCKED
else:
 result={'status':'RUNNING','locked_R583_json_sha256':LOCKED,'jobs':{},'grid_calibration':[]}
 for key in ('n2',):result['jobs'][key]=routing(baseline['cases'][key])
 result['grid_calibration']=[grid(2),grid(3)]
 for key in ('n3','n3-confirm'):result['jobs'][key]=routing(baseline['cases'][key])
result['broadened_graph_G_diagnostics']={key:graph_diagnostic(baseline['cases'][key],result['jobs'][key]) for key in ('n2','n3','n3-confirm')}
result.update({'status':'PASS_EXACT_DUAL_ROUTING_AND_BROADER_GRAPH_DIAGNOSTIC','R583_original_raw_sha256_provenance':LOCKED,'R583_actual_input_raw_sha256':input_raw_sha,'R583_canonical_mathematical_content_sha256':input_math_sha,'R583_canonical_hash_rule':{'excluded_keys_recursively':sorted(OMIT),'encoding':'JSON sorted dict keys, compact separators, UTF8 ensure_ascii=False; all other values and array order retained'},'R583_required_script_sha256_each_case_and_top':R583_SCRIPT,'routing_implementation_original_sha256':'f1bb1fca182c1fcd6464486ca1d39e5ad833d541cc3beab76e7f7b9cd7735697','routing_certificate_original_result_sha256':'586f7270fddbb68dc06f522f52d167876edfc266a03baa5011073758279c6c40','routing_and_grid_recomputed_this_run':not args.metadata_only,'arithmetic':'Fraction only; no floats, geometry regeneration, LP, SciPy or optimization solver. Input volume-dual masses are locked rational lower-certificate masses, not exact irrational optimum masses.','metadata_diagnostic_runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'interpreter':sys.executable,'python_version':platform.python_version(),'processes':1,'command':shlex.join([sys.executable]+sys.argv),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Only three locked R583 dual witnesses; N from actual eligible full-parent C_S columns(S,S), G from ALL actual legal halfcore K of all incident carrier columns. No uniform congestion theorem or dimension fit.'})
if not args.metadata_only:result['runtime_seconds']=time.perf_counter()-start
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');signal.alarm(0)
for key,o in result['broadened_graph_G_diagnostics'].items():print(json.dumps({'case':key,'changed_positive_cells':o['cells_with_broadened_G_not_equal_fullparent_N'],'changed_dual_mass':o['rho_mass_on_changed_cells_exact'],'max_overshoot_dual_mass':o['max_positive_overshoot_dual_mass_exact'],'representative_column':o['representative_positive_overshoot_column']},ensure_ascii=False))
print(json.dumps({'status':result['status'],'metadata_runtime_seconds':result['metadata_diagnostic_runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes'],'routing_recomputed':not args.metadata_only}))
