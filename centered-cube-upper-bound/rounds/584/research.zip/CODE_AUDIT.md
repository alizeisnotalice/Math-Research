# R584 independent bounded code/certificate audit

**PASS for the three frozen finite R583 volume-dual witnesses.** No
mathematical repair is required for the stated finite cut/flow claims.
This audit did not run an LP, solve a flow, or rebuild geometric cells.
It read the entire 185-line script and directly checked the supplied
rational certificates using the inherited exact R583 incidence.

## Files and provenance

| File | SHA256 |
|---|---|
| `/tmp/ccu_r584_numeric.py` | `ebab658cad1d5282f79c6c723a27c9846d047d25a19d59e3a8b0243eefc513fd` |
| `/tmp/ccu_r584_numeric.json` | `9b0206e3147404dee9564deefd7e6e21c02a54b62c7458fdd18f7cb84d0c0feb` |
| `/tmp/ccu_r584_root_replay.json` | `90a72390593239d1d32a4a1ecebe87043d5f63733c3d484d500d1a39c71b3dd5` |
| original R583 input | `a224dc4a6bfb0ee549d07457cf52a33c1309ec1c791c941b32783360a8e8366c` |
| root's replayed R583 input | `8d9fe19407483bc89df5d5546af66e814cb13981a5aecd36c86da3d1e9c12573` |

Both R583 input files have independently recomputed canonical
mathematical-content hash
`6479bb96b7db1906c5a90f0b35df8c725f09d2fb841e9afefedc43682a635ff5`.
The only recursively excluded keys are exactly
`runtime_seconds`, `peak_rss_bytes`, `rss_before_solver_bytes`, and
`command`. All other values, array orders, source data, exact
coefficients, incidences, certificates, and script hashes remain in the
canonical hash. Dictionary keys are sorted, JSON is compact UTF-8 with
`ensure_ascii=False` and `allow_nan=False`. The differing raw input
hashes therefore do not conceal a different mathematical certificate.

The R584 code explicitly checks that canonical hash, plus the required
R583 script hash at the top level and in every case. Its `LOCKED` raw
hash is original-file provenance, not an assertion that the independently
replayed file has the same raw bytes. The result separately records the
actual raw input hash; both recorded actual hashes were checked.

## Accurate finite statement

For each positive-mass dual cell `D`, let `y_D` be its saved R583 rational
dual **mass**, and let `rho=sum_D y_D`. The original source masses are
`m_i>0`, with `W=sum_i m_i`. Define

* `N(D)` as the union of all original eligible full-parent masks `S`
  whose actual full column `(S,S)` contains that entire cell;
* `G(D)` as the union of every actual core `K` in **all legal pair
  representations** of every allowed carrier column incident to that
  cell.

These are actual original-label masks. In particular `N` is not the
parent of a single representative column or merely the smallest parent.
`G` is not the union of representative cores alone. The code checks
every representation's `K subset S`, actual parent mass, and half-mass
condition before taking this union. The complete R583 input geometry is
inherited, not regenerated in this job.

For a routing graph with neighborhoods `N(D)`, the minimum congestion is
the smallest `T` permitting nonnegative row allocations with

\[
\sum_i f_{D,i}=y_D,\quad
f_{D,i}=0\ (i\notin N(D)),\quad
\sum_D f_{D,i}\leq Tm_i.
\]

The three supplied certificates prove `T_N=rho/W`. Since every original
full column occurs among the allowed representations, `N(D) subset G(D)`.
The same supplied flow is legal for `G`, while total source capacity
always forces `T_G>=rho/W`. Thus `T_G=T_N=rho/W` for these witnesses.
No flow/min-cut theorem is needed to justify this matching certificate.

## Cuts, network, and rational certificate directions

For each nonempty source mask `A`, the forced demand is
`sum_{D:N(D) subset A} y_D`. It must pass through `A`, so its ratio to
the exact original `m(A)` lower-bounds every congestion. The script
enumerates all `255`/`1023` masks, including the entire source set; an
empty cut has zero forced demand because every positive row has a
nonempty neighborhood. No receiver subsets or source masks are sampled.

The full-run implementation uses Fraction Edmonds–Karp only. Its edges
are source-to-cell capacity `y_D`, cell-to-allowed-label capacity `rho`,
and label-to-sink capacity `T*m_i`. The finite `rho` capacity is ample
because a row's entire demand is at most `rho`; it is not a floating
infinity. Reverse residual edges are exact. Extraction verifies each
row's demand and every source's capacity. A feasible supplied flow with
value `rho` and the maximizing cut prove optimality of this **finite
routing**, not of a new geometric cover.

I directly checked the supplied routes without invoking the algorithm:
every route is nonnegative, uses a permitted original source, respects
the edge bound `<=rho`, and has its row sum exactly `y_D`. Source loads
match the saved rational loads and equal `T*m_i` in these files. Thus
all three achieve the total-capacity lower bound.

The inherited volume dual was also rechecked on **every distinct R583
column** using its whole-cell incidence and outward rational lower
volume cost. This suffices for every raw pair representation because the
R583 box-plus-parent-mass deduplication preserves that column geometry.
No density bound on `rho`, cell-area quadrature weight, or replacement
of the real volume coefficient by parent mass is introduced.

## Overshoot diagnostic has the stated original meaning

For each incident allowed column, the diagnostic compares
`m(N(D)) < M`, where `m(N(D))` is the sum of the original masses of the
full-parent union mask, and `M` is that column's actual original parent
mass. Every representation of a deduplicated box-plus-M column has the
same `M`. It does not compare core mass, synthetic proxy mass, a sampled
point value, or a fitted radius.

I recomputed each positive-row `N` and `G` from the inherited complete
incidence and all pair representations, and checked every stored
overshoot row list and its rational dual-mass total. These diagnostics
are finite facts about the positive dual support only; they do not
describe all receiver cells or all feasible duals.

## Checks actually executed

The actual audit command was a local here-document check, invoked as

```text
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
```

Its body read the four R583/R584 JSON inputs/results listed above,
recursively stripped only the four declared execution keys to recompute
the canonical input hash, compared the complete mathematical result
blocks, and performed the direct Fraction checks described here. It
did not import or execute `ccu_r584_numeric.py`, and did not call any
flow or optimization routine. Python was 3.12.14. Observed output:

```text
canonical exact four-key exclusion PASS;
original/root mathematical fields identical;
provenance flags and actual raw input hashes PASS
n2 PASS: 8 positive dual cells; 255 exact source cuts
n3 PASS: 16 positive dual cells; 1023 exact source cuts
n3-confirm PASS: 21 positive dual cells; 1023 exact source cuts
No flow solve, LP, or geometry reconstruction executed.
```

More precisely, all source-cut ratios were recomputed from the supplied
original `N` masks and rational row masses; every ratio was `<=rho/W`,
and the serialized cut-table hash matched in each case. Whole-column
dual feasibility, `N subset G`, supplied row/edge/source capacities, and
the original-mass overshoot diagnostics all passed. This is lightweight
certificate checking, not another solver run.

## Metadata-only versus actual root replay

The original R584 result honestly records
`routing_and_grid_recomputed_this_run=false` and its command includes
`--metadata-only`. That path retains earlier routing/grid certificates
and recomputes graph diagnostics/metadata; it is **not** a fresh flow
recalculation. Its stored original-routing hashes are provenance fields,
not evidence of a second run.

The root replay records `routing_and_grid_recomputed_this_run=true` and
the full command

```text
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r584_numeric.py --r583-json /tmp/ccu_r583_root_replay.json --output /tmp/ccu_r584_root_replay.json
```

There is no `--metadata-only` switch there. Both results record the
reviewed R584 script hash. The routing job blocks agree exactly after
removing their runtime keys; grid calibration and broadened-graph
diagnostics agree exactly without removing any mathematical field.
Root execution timing is its recorded evidence; this audit independently
validated the supplied finite certificates rather than repeating that
execution.

## Scope limits and conclusion

The grid calibration in the script performs finite rational combinatorics
and product-route checks only for `n=2,3`, conditional on the inherited
analytic geometric classification stated in its own output. It does
not reconstruct that grid's geometric cells or prove a new all-n
classification. General symbolic formulas in that section must be
attributed to the separate analytic proof, not to a numerical dimension
extrapolation.

The result concerns these three locked rational volume-dual witnesses,
not exact irrational optimum duals, all feasible duals, or arbitrary
dimension/input. In particular achieving average congestion for these
examples does not itself bound their total dual mass uniformly, construct
a feasible `Pv` cover, or establish the original weak-(1,1) goal.
Normal Python assertion execution is required; `python -O` is outside
the recorded verification mode. No extra parameter, LP, flow, or geometry
job was launched by this audit. PASS with the above explicit limits;
audit complete and stopped.
