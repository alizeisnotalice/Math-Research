# R216：保留混合门的共同接收几何

已完成R215，main已推送e52ead49d644c0005bf74e49e286b700fe938af3；冻结材料位于/Users/zhengzhihao/Desktop/T/output/centered_cube_round215_20261016_final_checkpoint。一般任意正L1输入的n^(1/2+o(1))一致弱型目标不变。

原剩余域每腿z=v,u满足a_z=L0J_z/(p_yw_t(z))、b_z=K0_z/(κT w_t(z))、a_z+b_z<1。真实dx、原两Π及e_t^-2、共同来源/接收中心、high/FIRST/capture、终端G/B、时钟与窗口、唯一j和剩余负信用全部保留。R214低域已付一次，不再领取。R215原w位移吸收已用的两w不可再当完整Π归一。

本轮不优化已删全部门的MR13指数包络。任务是保真实mixed及capture/goodbad条件，给能实质降低空间费用的新不等式。已有CM5c单一标量常数、JK精确共同矩/协方差、MR权吸收可作为工具，不以重推它们计成果。不能把固定尺度或有限配置结果当完整root。

D02有限Gibbs技能已读，限合法概率Q、0<Z<∞、KL有限和势绝对可积范围；不用无匹配LDP/MDP的形式速率。主代理负责主要约束几何、适用范围、实际本机复跑和最终整合。Astra r166_raw_budget负责constrained_receiver_geometry.md：唯一原预算瓶颈，先准确命题再长证。Sol r166_exact_certificate负责mixed_entropy_geometry.md：互不重复的保logsumexp混合条件的有限变分估计，不能只重命名旧Chernoff。Sol r164_audit负责audit.md：先独筛后全文审。Sol medium r171_numeric_design负责mixed_event_checks.py/json与numeric_notes.md：先明确六行方案，再实际执行真实product receiver下mixed事件/必要分离门对比，非FULL，三阶段且不拟合维数阶。

所有人只写责任文件，不自行Git/PDF/增加Agent/无限扩任务。最终严格区分一般核定理、条件分支、有限数值证据；每个分支保费用及未覆盖区。完成后最终详细LaTeX、复现材料、独审和manifest集中精简归档，每轮单独commit/push；不提交未整理草稿。
