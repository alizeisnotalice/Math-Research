# R216：真实 good 与混合 slack 的接收密度压缩

本稿给出一个保原门后才作正上界的接收估计与费用校准。在明确的原尺度/时钟子域，混合 slack 与同一 target 的 good 门迫使当前接收密度低于边界密度尺度；由此消去 R214–215 逆 K0 矩的 inverse-soft、来源正位移和双 e 来源重用费用。最终给出全软度及自适应 L 的真实来源价，保留其完整维数和时窗成本。但其粗多项式版本不优于已有删门包络，不登记为新一般付款。该价一般不是根阶；原互补域未付，不宣称一般闭合或严格 FULL 新覆盖。

## 1. 来源与准确对象

原定义窄读 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md` 637–667 行、RT4–6；原完整正负泛函见同文件 604–633 行、RT1–3。R215 冻结 `mixed_receiver_estimate.md` MR1–3 已核：固定 (ω,V,j,y,t)，原 ν、Z_t、w_t、e_t、Π_t 独立 x，终端 g、G/B、capture、high、当前 selector 仍依 x。

本文用
\[
 p=P_{s,L}(x-y),\quad J_v=P_{1,b}(x-v),\quad
 K_{0v}=P_{s,\widehat H}(x-v),\quad
 K_{1v}=P_{s,L}(x-v),\quad K_{2v}=P_{s,L^+}(x-v),
\]
\[
 L^+=\min(b,\gamma L),\quad \gamma=1+1/n,\quad
 a_s=1-s+s\varphi(1/2),\quad H_0^nT=a_s^n,
\quad\widehat H=\max(a_{win},\min(b,H_0)).
 \tag{CR1}
\]
这里 a_s 是物理边界高度，不是原捕获 a=TΔ，也不是下面的混合变量。全部实际余项仍使用原 rho0、同一 alpha0、原剩余历史域与负余额。

对每腿 z=v,u，原补域为
\[
 \mathfrak a_z={L_0J_z\over p w_t(z)},\qquad
 \mathfrak b_z={K_{0z}\over\kappa T w_t(z)},\qquad
 \mathfrak a_z+\mathfrak b_z<1.
 \tag{CR2}
\]
只在原正质量/正 p,T,e_t 的行上写商；零行先零。target v 保留实际 good：3p w_g(v)/K≤K1v+K2v+Jv。bad u 不继承这条 target good 门。

历史边界：`rounds/134/research.zip::proof.md:696–734` 已经证明同尺度 good 反向比较及其同 alpha 的 rho 压缩。本稿已实读该段；不把 CR3 的比较重新登记为新结论。R123/124 的共同软度混合，以及 R198 `jeffreys_envelope.md` 的 KL 积分常数，也是已有工具。新增联动是 CR4–6 的混合凸组合去掉时钟 gap 分母，并将其代入 CR11–16 的全参数接收价。

## 2. 混合凸组合给出的密度上界

先限制到真实尺度分支 \(\widehat H\ge L^+\)。f_s 为偶、径向非增，包含闭 hard 核边界。对 H≥L_i 逐坐标有 f_s(r/L_i)≤f_s(r/H)，因此
\[
 K_{1v}+K_{2v}\le C_H K_{0v},\qquad
 C_H=(\widehat H/L)^n+(\widehat H/L^+)^n.
 \tag{CR3}
\]
定义实际时钟比
\[
 r_c={3w_g(v)\over K w_t(v)},\qquad X_c={C_H\kappa T\over p}.
\]
原 good 和 CR2 在同一 x 上给
\[
 r_c\le X_c\mathfrak b_v+\mathfrak a_v/L_0.
 \tag{CR4}
\]
若 \(r_c\ge1/L_0\)，则必 \(X_c>r_c\)。否则 CR4 右端≤r_c(𝔞_v+𝔟_v)<r_c，矛盾。等号 r_c=1/L0 包含在结论中，不需要除以 r_c−1/L0。于是
\[
 \boxed{p<{K\kappa\over3}{w_t(v)\over w_g(v)}C_HT.}
 \tag{CR5}
\]
这比只分别使用 𝔞<1、𝔟<1 后所得的 gap 分母界强；完整 simplex 的严格和在这里实际参与证明。

再交真实 \(\widehat H\le H_0\) 分支，利用 CR1：
\[
 C_HT\le a_s^n[L^{-n}+(L^+)^{-n}].
\]
故在下列明确的原几何域
\[
 \mathcal S=\{L^+\le\widehat H\le H_0,
             \ w_g(v)/w_t(v)\ge K/(3L_0)\}
 \tag{CR6}
\]
上，
\[
 \boxed{p<2\kappa L_0\,a_s^n L^{-n}.}
 \tag{CR7}
\]
未先冻结 g 或 w_g；CR4–7 都是实际同 x 的式子。若 L0<K/3，由 t≤g 和 w_g≤w_t 可知此支为空。下夹断 Hhat>H0 不自动满足 CR6，即使 Hhat≥Lplus 也必须另保。非 lower-clamp 的上下边界相等均合法。

CR7 是实际密度限制；没有用一个任意替换的当前核代 K0。证明没有调用 ν≤β，也没有向 u 腿移植 v 的 capture。

## 3. 保边界高度的分数密度核

取共同预定 0<θ<1，令 q_θ=1−θ。CR7 给逐点正界
\[
 p\,1_{mixed\cap good_v\cap\mathcal S}
 \le (2\kappa L_0)^\theta\,
 L^{-n}a_s^{n\theta}
 \prod_{i=1}^n f_s((x_i-y_i)/L)^{q_\theta}.
 \tag{CR8}
\]
零 f_s 时按 0^{qθ}=0；该式也允许 s=0、1，不引入 K0 负幂。所有其它原门可以保留在左侧；右侧没有假定它们独立。

设 dπ(s)=ds/[π√(s(1−s))]，并记
\[
 M_s(\theta)=a_s^\theta\int_{\mathbb R}f_s(r)^{1-\theta}\,dr,
 \qquad\mathcal M_n(\theta)=\int_0^1M_s(\theta)^n\,d\pi(s).
 \tag{CR9}
\]
这些是显式一维物理核积分，不是待付的来源矩。

适配软度时要保 a_s^{nθ}，不能把固定 s 的 CR9 直接用于 selector。所需已知 KL 混合工具有以下短加权版本。对于非负 affine 因子 F_i(s) 及正权 ω_i、总权 N=n，函数 P(s)=∏F_i(s)^{ω_i} 满足
\[
 \sup_s P(s)\le 2\sqrt n\int P(u)\,d\pi(u).
 \tag{CR10}
\]
理由：在正内部最大点 s*，令 π_i=s*F_i(1)/F_i(s*)，一阶条件给 Σω_iπ_i=ns*。逐因子 Bernoulli-Jensen 相加，得到 P(u)≥P(s*)exp[−n KL(s*||u)]。端点最大值直接用 F_i(u)≥(1−u)F_i(0) 或 uF_i(1)。R198 已证该 KL 积分≥binom(2n,n)/4^n≥1/(2√n)。恒零支先零，端点不作非法求导。

对 CR8 的 n 个 f_s 因子取权 qθ，另一个 a_s 因子取权 nθ，总权恰 n。因此 CR10 完整保留边界高度，而不是将它换为 1 后再声明保留。

尺度适配也需要付费。固定 u 时，令
\[
 G_{u,L}(x)=L^{-n}a_u^{n\theta}\prod_i f_u((x_i-y_i)/L)^{q_\theta}.
\]
L^n G_{u,L} 随 L 非减，包含 hard 面的真实正跳，故
\[
 \sup_{a_{win}\le L\le b}G_{u,L}
 \le G_{u,b}+n\int_{a_{win}}^bG_{u,L}\,{dL\over L}.
\]
积分后 ∫G_{u,L}dx=M_u(θ)^n，得到全软度、全共同尺度 selector 的实际界
\[
 \boxed{\int p_{s(x),L(x)}(x-y)
 1_{mixed\cap good_v\cap\mathcal S}\,dx
 \le\mathcal C_n(\theta),}
\]
\[
 \mathcal C_n(\theta)=
 2\sqrt n\,[1+n\log(b/a_{win})]\,
 (2\kappa L_0)^\theta\mathcal M_n(\theta).
 \tag{CR11}
\]
证明先点态 CR8，再 CR10，再上述尺度正包络，最后正 Tonelli。Hhat、g 仍可随 x，只通过 CR6–7 实际门使用；未把 fixed-scale 价免费当 adaptive 价。

## 4. 一致物理尾与维数费用

CR11 没有 inverse-soft 常数。给一个完全显式的统一说明：0≤f_s≤F=max(h,φ)≤1，F 在核心等于1，核心外满足 F(r)=φ(r)≤exp(1/2−|r|)。故 ∫F^{1/4}≤9。对 q∈[1/2,1]、0≤z≤1，
\[
 z^q\log(1/z)\le(4/e)z^{1/4},
\]
零 z 取连续极限。因此 0≤θ≤1/2 时由积分的参数微分或正 Tonelli，
\[
 \int f_s^{1-\theta}\le1+18\theta,\qquad
 M_s(\theta)\le e^{18\theta},\qquad
 \mathcal M_n(\theta)\le e^{18n\theta}.
 \tag{CR12}
\]
该支配允许 s=0；没有 log s 的无界费用。取 θ_n=min(1/2,1/n) 得
\[
 \mathcal C_n(\theta_n)\le
 2e^{18}\sqrt n[1+n\log2](2\kappa L_0)^{\theta_n}.
 \tag{CR13}
\]
精确 CR9 可比 CR12 更好；本文不猜其指数均值的符号。θ 的优化只对已证明的 CR11 右端进行，不改变任何原参数或历史。CR13 消除了 CM12/MR13 的 inverse-soft 指数与来源指数矩，但其尺度选择费仍 O(n)，不能把整个系数称为根阶。

必须与真正已有基线比较，而不能只同昂贵 CM12 比较。直接删全部门、对归一 p 使用已证软度与尺度包络，已有
\[
 \mathcal C_{old}=2\sqrt n[1+n\log(b/a_{win})].
\]
所以 CR11 可取的准确改善系数仅为
\[
 \min\left\{1,\inf_{0<\theta<1}
 (2\kappa L_0)^\theta\mathcal M_n(\theta)\right\}.
 \tag{CR13a}
\]
由 CR12 的一致支配，theta→0 时该被优化表达式趋于1。本稿没有证明原一般参数下它严格小于1，更没有证明缩小到足以消去尺度 n 的量级。因此 CR13 及下一节的来源归一，不应重新登记为旧界之外的新一般进展；新可保留部分是 CR4–7 的真实共同支持约束及 CR13a 的精确费用比较。


## 5. 原来源、时间与 signed 回代

CR11 对每个固定原 (ω,V,j,y,t,v,u) 的接收积分成立，右端与 v,u 无关。本证明完全没有使用 R215 的 w_vw_u 位移吸收，因而原 Π_t 两份权仍完整。原硬承载一次 16/3、外 2Λ 后，保原所有门再正放，得到
\[
 R^+_{mixed\cap\mathcal S}
 \le {32\Lambda\over3}\mathcal C_n(\theta)
 \mathbb E\sum_{V,j}\int\beta_V(dy)
 \int_{I^0_{j,V,y}}\iint(k_t(v)-k_t(u))_+
 \Pi_t(dv)\Pi_t(du)\,{dt\over t}.
 \tag{CR14}
\]
fixed(j,y,t) 的 Π_t 与 score 独立 x，故顺序合法；rho0≤1 及 actual high/capture/G/B/FA/Ψ 等只作正放，负信用不动。空行 e_t=0 先零。

原同 Π 的 IID score 取值 [0,n]，故 E(k_v−k_u)+≤n/4。可由 layer cake 写 E|X−Y|=2∫P(X≤a)P(X>a)da≤n/2。令
\[
 T_* =\sup_{\omega,V,y}\sum_j\int_{I^0_{j,V,y}}dt/t,
\]
其中每个 I0 仅是 [a_win/cj,bcj] 与原定义域的交集。比例索引的准确窄定位为 `rounds/114/research.zip::proof.md:218–231`、S1–2：j=0,…,J，c_j=γ^(−j)，J=floor(log(b/a_win)/(2logγ))；半开分层及最后闭端点亦在那里明确，R128 RT1/RT4 延续同一唯一比例索引。本处只引用该索引/尺度定义，不继承 R114 同段别处的旧来源支配表述。

因此单个原窗口可以显式取，写 A_win=log(b/a_win)∈[0,log2]，
\[
 T_*\le\sum_{j=0}^{\infty}(A_{win}-2j\log\gamma)_+
 \le A_{win}+{A_{win}^2\over4\log\gamma}
 \le\log2+{n+1\over4}(\log2)^2.
 \tag{CR14a}
\]
中间一步由非增函数 f(x)=(A_win−2xlogγ)+ 的离散和不超过 f(0)+∫_0^∞f(x)dx；最后用 log(1+1/n)≥1/(n+1)。a_win=b 时所有扩窗的 log 长度为0，单点不贡献 dt/t。真实 T* 可更小，仍可沿用。多独立窗口必须分别使用本上界及各自 Wβ/W_A 账，不能不计窗口来源重用而统一复制一份 W_A。这只是已有时间费用的显式上界，不登记新付款。于是
\[
 \boxed{R^+_{mixed\cap\mathcal S}
 \le {8\Lambda\over3}\,nT_*\,\mathcal C_n(\theta)W_\beta
 \le {8\Lambda\over3}\,nT_*\,\mathcal C_n(\theta)W_A.}
 \tag{CR15}
\]
这是该条件支可严格使用的线性来源上界，但未经 CR13a 的非平凡改善不能登记为新付款。原双 e_t^{-2} 通过完整 Π_t² 的合法归一处理，不是把已经消耗过的 w_t 再用一次。unique j 在原式中保留，CR14 正放后真实 j 总和由 T* 支付；不能把每窗 log2 当全局总 log2。可保 CR14 的原 clock 生产量而不用 nT*/4；本文不宣称它有未证明的根阶界。

同一剩余 signed 泛函可先剥离 CR15 的正子支，原可用负余额全部留到互补域一次。R214 已付的 additive-cap 外域不再收费；R215 的位移吸收界与本稿是同一剩余正积分的不同上界，不相加也不共享同一 w 权的两份归一信用。

## 6. 精确补域与当前结论

仍须处理原 mixed 补域中
\[
 \widehat H<L^+,\qquad\widehat H>H_0,
 \qquad\text{或}\quad w_g(v)/w_t(v)<K/(3L_0).
 \tag{CR16}
\]
它们可以按顺序不交分配；本文不给其价。bad u 的全部实际约束仍在剩余问题内，不能由 v 的 good 反向比较替代。原 near-unit capture 的 K0/Δ 缺陷亦没有在 CR15 中免费支付。

历史 R170 的有界 terminal ratio 工具还要求其自己的 signed/covariance/suffix资格；它不自动授予本稿 full rho0 子域的全部历史门。另一方面本文没有证明 CR16 以外存在旧工具未覆盖的 FULL 例子，因此不作严格覆盖扩张声称。

## 7. 密度压缩尚未支付的具体硬面量

这份支持限制不会自动删除正尺度硬面。固定同一 s,L，考察 outer-current 核 p_y 的第 i 个闭 hard 面 r_i=±1/2，r=(x−y)/L。其进入核心的上迹为
\[
 p_y^+=L^{-n}a_s\prod_{j\ne i}f_s(r_j).
\]
因此 CR7 在该上迹至多迫使
\[
 \sum_{j\ne i}\log[f_s(r_j)/a_s]<\log(2\kappa L_0).
 \tag{CR17}
\]
零 f_s 的接收概率质量先零；s0用原乘积不等式解释。固定 s 的物理正尺度硬面测度，两面各系数 (1−s)/2。只保 CR17 后的总质量恰为
\[
 n(1-s)\,\mathbb P_{f_s^{\otimes(n-1)}}
 \left\{\sum_{j=1}^{n-1}\log[f_s(R_j)/a_s]
              <\log(2\kappa L_0)\right\}.
 \tag{CR18}
\]
这里只是固定物理接收核在一个面上的真实坐标概率，不是原 ν/β 的坐标独立性。n1时使用空和0；s1时面费0。闭面上原门若只具单侧迹，应保该真实迹，不能由背景相等值替代；CR18仅说明由密度支持本身所能授予的正包络。

CR18 中是下尾，不是未经证明的罕见上尾。本稿没有证明它具有 O(n^(-1/2)) 压缩。原完整面被积量还必须保 rho0、mixed 两腿、good/bad、capture、high/FIRST、双Π与剩余历史，且原选择器或其它状态的进入交换仍需其自身账。因此不能从固定 s 的 CR18 直接宣布原尺度总正变差被支付，也不能借一维边缘归一消去这些门的相关性。

这是当前最早的具体未证接缝：需要在同一实际 receiver/source 面测度下，将 CR17 下尾及原两腿/capture 资格联合估计，或与原可用负交通作一次合法 signed 结算，使 n(1−s) 的面生产降低；CR4–7 本身不提供该结论。旧 R134 同 alpha 抑制仍可保留，但其支付条件不能凭改写为密度门就自动满足。

综上，本轮证明了 gap-free 的真实 mixed/good 支持式与其全 selector 费用，明确对比了已有删门包络。没有证明 CR13a 在一般原域上的非平凡改善，因而不报告新增一般根阶或线性来源付款。CR16 的低终端时钟比/不合尺度补域也完整保留。到此停止本轮路线，不另造未付小矩条件。

