#!/usr/bin/env python3
"""R216 finite tilted physical log-moment probe; no FULL or interval claim."""
import argparse,hashlib,json,math,time
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
CONFIGS=[('.25','1','.5','0'),('.75','.5','1','0'),('.25','.5','.25','-.25')]
def phi(x):
    x=abs(x);h=mp.mpf('.5')
    return 1-mp.expint(3,h-x)-mp.expint(3,h+x) if x<=h else mp.expint(3,x-h)-mp.expint(3,x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def constants(config):
    s,eta,dv,du=map(mp.mpf,config);eps=mp.mpf('.25');ce=mp.mpf('.2');R=mp.mpf('.5');TH=mp.mpf('.25');A=mp.mpf('1.5')
    delta=A-(1+eps)*(R+TH/eta)
    logb=TH*mp.log(eta)-(R+TH)*mp.log(ce)-TH*mp.log(s)+A/2+(1+eps)*(R+TH)/2
    logb+=(1+eps)*((mp.mpf('.25')+mp.mpf('.125')/eta)*abs(dv)+(mp.mpf('.25')+mp.mpf('.125')/eta)*abs(du))
    c=-3*mp.log(ce)-2*mp.log(s)+abs(mp.log(eta))+(1+eps)*(abs(dv)+abs(dv)/eta+mp.mpf('1.5'))
    d=(1+eps)*(2+1/eta)
    assert delta>0 and c>0 and d>0
    return {'epsilon':eps,'c_epsilon':ce,'delta':delta,'B':mp.exp(logb),'log_B':logb,'Y_absolute_C':c,'Y_absolute_D':d}
def tail_bound(params,Z,j,extra=0):
    # |Y-center|<=C+|center|+D|x|; ∫x^k e^-delta x has this finite exact formula.
    delta=params['delta'];c=params['Y_absolute_C']+abs(extra);d=params['Y_absolute_D']
    polynomial=mp.mpf(0)
    for k in range(j+1):
        primitive=sum((mp.factorial(k)/mp.factorial(k-ell)*Z**(k-ell)/delta**(ell+1) for ell in range(k+1)),mp.mpf(0))
        polynomial+=math.comb(j,k)*c**(j-k)*d**k*primitive
    return 2*params['B']*mp.exp(-delta*Z)*polynomial

def choose_z(config):
    with mp.workdps(60):
        params=constants(config);z=int(mp.ceil((mp.log(2)+params['log_B']-mp.log(params['delta'])+18*mp.log(10))/params['delta']))
        while max(tail_bound(params,mp.mpf(z),j) for j in range(5))>mp.mpf('1e-18'):z+=1
        return z

def evaluate(config,dps,z):
    with mp.workdps(dps):
        s,eta,dv,du=map(mp.mpf,config);params=constants(config);Z=mp.mpf(z)
        cuts=sorted(set([-Z,Z,mp.mpf(0),-mp.mpf('.5'),mp.mpf('.5'),dv,du,dv-eta/2,dv+eta/2,du-eta/2,du+eta/2,dv-mp.mpf('.5'),dv+mp.mpf('.5'),du-mp.mpf('.5'),du+mp.mpf('.5')]))
        cache={}
        def pair(x):
            if x not in cache:
                lp=mp.log(fs(x,s));jv=mp.log(phi(x-dv));ju=mp.log(phi(x-du))
                kv=mp.log(fs((x-dv)/eta,s)/eta);ku=mp.log(fs((x-du)/eta,s)/eta)
                g=mp.exp(mp.mpf('1.5')*lp-mp.mpf('.25')*(jv+ju)-mp.mpf('.125')*(kv+ku))
                y=jv-lp-kv
                assert abs(y)<=params['Y_absolute_C']+params['Y_absolute_D']*abs(x)
                cache[x]=(g,y)
            return cache[x]
        def integrate(power,center=0):
            total=mp.mpf(0);error=mp.mpf(0)
            for a,b in zip(cuts,cuts[1:]):
                value,err=mp.quad(lambda x:pair(x)[0]*(pair(x)[1]-center)**power,[a,b],error=True)
                total+=value;error+=err
            return total,error
        raw=[];errors=[]
        for j in range(5):
            value,err=integrate(j);raw.append(value);errors.append(err)
        mass=raw[0];mean=raw[1]/mass
        central2,err2=integrate(2,mean);central4,err4=integrate(4,mean)
        variance=central2/mass;mu4=central4/mass
        rawvariance=raw[2]/mass-mean**2
        rawmu4=raw[4]/mass-4*mean*raw[3]/mass+6*mean**2*raw[2]/mass-3*mean**4
        assert mass>0 and variance>0 and mu4>0
        bdiff=2*mu4+6*variance**2;omega=mp.sqrt(12*variance/bdiff);vper=variance/2
        r=mp.mpf('.25');theta=mp.mpf('.125');q=r/(r+theta);C=q**r*(1-q)**theta;lf=mp.beta(r,theta)/C
        table=[]
        for n in (4,16,64,256):
            V=n*vper;bound=mp.pi*mp.sqrt(2*mp.pi)/(8*mp.sqrt(V))*(4*mp.pi/omega+lf)
            table.append({'n':n,'V':mp.nstr(V,dps),'unclipped_CB5_rhs':mp.nstr(bound,dps),'CB5_min_one':mp.nstr(min(mp.mpf(1),bound),dps)})
        tails=[tail_bound(params,Z,j) for j in range(5)]
        assert max(tails)<=mp.mpf('1e-18')*(1+mp.mpf('1e-15'))
        return {'dps':dps,'Z':z,'cuts':[mp.nstr(x,dps) for x in cuts],'tail_parameters':{k:mp.nstr(v,dps) for k,v in params.items()},
            'unnormalized_raw_moments':[mp.nstr(x,dps) for x in raw],'raw_abs_moment_tail_bounds':[mp.nstr(x,dps) for x in tails],
            'raw_quad_internal_error_indicators_nonrigorous':[mp.nstr(x,dps) for x in errors],
            'm':mp.nstr(mass,dps),'mean_Y':mp.nstr(mean,dps),'sigma_squared':mp.nstr(variance,dps),'central_mu4':mp.nstr(mu4,dps),
            'raw_formula_variance':mp.nstr(rawvariance,dps),'raw_formula_mu4':mp.nstr(rawmu4,dps),
            'central_vs_raw_variance_abs_difference':mp.nstr(abs(variance-rawvariance),dps),'central_vs_raw_mu4_abs_difference':mp.nstr(abs(mu4-rawmu4),dps),
            'central_crosscheck_tail_bounds_about_computed_mean':{'power2':mp.nstr(tail_bound(params,Z,2,mean),dps),'power4':mp.nstr(tail_bound(params,Z,4,mean),dps)},
            'central_quad_error_indicators_nonrigorous':[mp.nstr(err2,dps),mp.nstr(err4,dps)],
            'Bdiff':mp.nstr(bdiff,dps),'omega0':mp.nstr(omega,dps),'V_per_coordinate':mp.nstr(vper,dps),'q_peak':mp.nstr(q,dps),'C_peak':mp.nstr(C,dps),'L_f_C_inverse_Beta':mp.nstr(lf,dps),
            'homogeneous_repetition_CB5':table,'kernel_cache_size':len(cache)}

def run():
    rows=[]
    for idx,config in enumerate(CONFIGS):
        z=choose_z(config);values=[evaluate(config,dps,z) for dps in (25,40)]
        comparisons=[]
        with mp.workdps(60):
            for key in ('m','mean_Y','sigma_squared','central_mu4','Bdiff','omega0','V_per_coordinate'):
                a=mp.mpf(values[0][key]);b=mp.mpf(values[1][key]);comparisons.append({'quantity':key,'absolute_difference':mp.nstr(abs(a-b),40),'relative_difference':mp.nstr(abs(a-b)/abs(b),40) if b else None})
        rows.append({'case':idx+1,'s':config[0],'lambda':'1','eta':config[1],'d_v':config[2],'d_u':config[3],
            'r':'1/4','tau':'1/4','theta':'1/8','chi':'1/8','precisions':values,'precision_differences':comparisons})
        print('completed tilt case '+str(idx+1),flush=True)
    return {'schema':'R216_tilted_physical_log_moments_v1','inputs':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ('task_contract.md','concentration_bridge.md')},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'counts':{'coordinate_configs':3,'precision_runs':6,'raw_and_central_integrals':42},'cases':rows,
        'scope':['Pstar proportional to same-z actual CM4 physical g; Y=logjv-logp-logkv. Raw0..4 tails have separate polynomial-exponential bounds.',
        'Finite quadrature, normalized moments, tail-bound evaluations and 25/40dps comparisons are not directed interval certificates.',
        'Centered direct moments use the computed finite-window mean; centered tails add its absolute value. They do not certify the exact infinite-law mean/variance.',
        'CB5 tables are conditional formula diagnostics for homogeneous repetitions of the same coordinate tilt, not original FULL/source/selector inputs or dimension-order fits.',
        'No changes to frozen six-configuration direct-MC files; no optimization over additional kernels.']}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'tilted_moment_checks.json');args=ap.parse_args()
    start=time.monotonic();result=run();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'counts':result['counts'],'runtime_console_only':round(time.monotonic()-start,3)},sort_keys=True))
