# R216：局部特征函数到混合前因子的有限桥接

主代理推导。此处改进ME16的使用方式：不必额外证明全高频衰减，就能从真实倾斜概率的局部特征函数获得条件性平方根前因子。仍须证明局部方差总量与共同频率窗在原几何上足够大，并支付原来源、选择器与时钟费用；本稿不宣称一般上界。

## CB1：不依密度的浓度函数界

令D是任意实随机变量，Phi(t)=E exp(itD)，h>0，Q_D(h)=sup_a P(|D-a|≤h/2)。因K(x)=(sin x/x)^2在|x|≤pi/2上至少4/pi²，且

\[
K(x)=\frac14\int_{-2}^2(2-|t|)e^{itx}\,dt,
\]

非负测试及有限区间Fubini给

\[
\begin{split}
Q_D(h)&\le\frac{\pi^2}{16}
\int_{-2}^2(2-|t|)|\Phi(\pi t/h)|\,dt\\
&\le\frac{\pi h}{8}\int_{-2\pi/h}^{2\pi/h}|\Phi(u)|\,du.
\end{split}\tag{CB1}
\]

右侧可与1取min。可有原子，无密度、有界性或非格点假设；Phi的相位平移不改变此界。这里用有限区间Fourier恒等式，不依赖大偏差或未核验的反集中定理。

## CB2：混合曲率函数的浓度付款

若f≥0、f(0)=sup f=1，f在负半轴递增、正半轴递减，且L_f=int_R f<∞，按半开区间[kh,(k+1)h)分割，得到

\[
E f(D)\le Q_D(h)\sum_{k\in\mathbb Z}\sup_{[kh,(k+1)h)}f
\le Q_D(h)(2+L_f/h).\tag{CB2}
\]

最后一步：两侧贴近零的区间各贡献1，正负侧其它端点和分别不超过对应积分除h。可有端点原子，因为每个半开区间仍含于某闭区间长h内。

取ME7实际曲率函数

\[
f(D)=\frac{e^{rD}}{(1-q+qe^D)^{r+\theta}},
\quad q=\frac r{r+\theta},\quad r,\theta>0.
\]

其峰在0且满足上述单调性，ME11的正Beta积分直接给

\[
L_f=C^{-1}B(r,\theta),\qquad C=q^r(1-q)^\theta.
\tag{CB3}
\]

这里无Fourier绝对值积分的高频余项，也不要求D有密度。两个腿保持相关；只用另一腿0<f_u≤1，故原R_mix=E_* f_v(D_v)f_u(D_u)≤E_*f_v(D_v)，可选择任意一腿的合法界，不能把两单腿界相乘。

## CB3：只需局部Gaussian型特征函数界

假设在真实同一倾斜概率下，对某V>0、omega0>0，有

\[
|\Phi(t,0)|\le e^{-Vt^2/2},\qquad |t|\le\omega_0.
\tag{CB4}
\]

选h=2pi/omega0，CB1只使用这个已知有限频率窗。用全线Gaussian积分上放有限窗后，CB2给

\[
\boxed{\mathcal R_{mix}\le
\min\left\{1,\frac{\pi\sqrt{2\pi}}{8\sqrt V}
\left(\frac{4\pi}{\omega_0}+L_f\right)\right\}.}
\tag{CB5}
\]

因此ME16所显示的高频积分并非此用途的独立必需假设。这个结论不反过来保证CB4，也不抹掉L_f、omega0及V的真实参数费用。r或theta趋0时L_f可发散，不能以固定常数替代。

## CB4：如何从真实坐标核核验CB4

在ME10的固定物理参数单项倾斜下，D_v=d_v^*+sum_i Y_i，其中各坐标独立只是因为同一receiver product density被倾斜后仍product；来源测度与原Pi不因此独立。Y_i=log j_vi-log p_lambda-log k_vi。设sigma_i²=Var Y_i，B_i=E(Y_i-Y_i')^4，其中撇号是同一个一维倾斜法的独立代数副本。

cos x≤1-x²/2+x⁴/24给

\[
|\phi_i(t)|^2\le1-t^2\sigma_i^2+t^4B_i/24.
\]

选任意坐标子集I，其sigma_i²>0，且共同窗满足omega0² B_i≤12sigma_i²；则在窗内

\[
|\phi_i(t)|\le e^{-t^2\sigma_i^2/4},\qquad
|\Phi(t,0)|\le e^{-t^2\sum_{i\in I}\sigma_i^2/4}.
\tag{CB6}
\]

其它坐标仅用|phi_i|≤1，不借退化坐标增加方差；可取V=(1/2)sum_I sigma_i²。原严格gap保证这些log矩有限，但没有给一般来源位移、soft/scale端点和共同选择器下的统一sigma_i或B_i。

若能在原实际分支证明sum_I sigma_i²≥c n且omega0≥c'>0、r/theta在固定正紧区间，CB5才产生C/sqrt n的有限前因子。若只能有小方差或缩小频率窗，须按CB5原式保留损失；不能猜阶数。本稿只给从可核验矩到前因子的严格连接，不认证所缺的原几何条件，也不将此与一般弱型上界等同。

## CB5：证据与适用边界

上述结论均为初等积分/代数证明，无外部定理引用。六行既定Monte Carlo没有构造P_*或估计这些方差/四阶矩，故不声称其数值验证了CB4或CB5在原输入上的非退化。原R197固定p下的cap/separation前因子也不能无价转移到P_*；其旧证明只作为历史工具保留。

本轮新可用结果是：一旦真正核验低频矩几何，便不必再为全高频控制开一条独立证明路线。原M、C_vC_u、共同来源和全部selector/window费用仍需一并回代。这改变下一步的待证清单，不宣称已付root。
