#!/usr/bin/env python3
"""R216 finite MC for actual product receiver mixed gates; no FULL input."""
import argparse,hashlib,json,math,time
from pathlib import Path
import numpy as np
import mpmath as mp
HERE=Path(__file__).resolve().parent
N=16384
ORDERS=(96,192)
TOTAL_TESTS=6*2*3
EPS=math.sqrt(math.log(2*TOTAL_TESTS/.01)/(2*N))

def phi_mp(x):
    r=abs(mp.mpf(x));h=mp.mpf('.5')
    return 1-mp.expint(3,h-r)-mp.expint(3,h+r) if r<=h else mp.expint(3,r-h)-mp.expint(3,r+h)

def c_mp(x):
    d=abs(mp.mpf(x))
    return 1-d+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,d)+mp.expint(4,d+1) if d<=1 else mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)

def phi_gauss(x,order):
    nodes,weights=np.polynomial.legendre.leggauss(order);t=(nodes+1)/2;weights=weights/2
    radius=np.abs(np.asarray(x,dtype=float));flat=radius.ravel();out=np.empty_like(flat)
    for begin in range(0,len(flat),4096):
        r=flat[begin:begin+4096,None]
        inside=r<=.5
        # Stable nonnegative scale-integral formulas, split analytically at .5.
        a=np.maximum(.5-r,0)/t;b=(.5+r)/t
        inner=t*(-np.expm1(-a)-np.expm1(-b))
        exterior=t*np.exp(-np.maximum(r-.5,0)/t)*(-np.expm1(-1/t))
        out[begin:begin+4096]=np.sum(np.where(inside,inner,exterior)*weights,axis=1)
    assert np.all(out>0) and np.all(np.isfinite(out))
    return out.reshape(radius.shape)

def fs_from_phi(x,s,ph):return s*ph+(1-s)*(np.abs(x)<=.5)

def configs():
    return [('initial',4,.25,1.,np.full(4,.5),np.zeros(4)),
            ('initial',4,.75,.5,np.r_[1.,np.full(3,.25)],np.zeros(4)),
            ('stress',16,.25,.5,np.r_[np.full(4,.5),np.full(12,.25)],np.full(16,-.25)),
            ('stress',16,.75,1.,np.full(16,.5),np.zeros(16)),
            ('expanded',64,.25,1.,np.r_[np.full(8,.5),np.full(56,.25)],np.full(64,-.25)),
            ('expanded',64,.75,.5,np.r_[1.,np.full(7,.5),np.full(56,.25)],np.zeros(64))]

def interval(count):
    p=count/N
    return [max(0.,p-EPS),min(1.,p+EPS)]

def classify(x,s,eta,v,u,order,constants):
    phi_x=phi_gauss(x,order);py=np.sum(np.log(fs_from_phi(x,s,phi_x)),axis=1)
    jlogs=[];klogs=[]
    for d in (v,u):
        arg=x-d;ph=phi_gauss(arg,order)
        jlogs.append(np.sum(np.log(ph),axis=1))
        scaledphi=ph if eta==1 else phi_gauss(arg/eta,order)
        klogs.append(np.sum(np.log(fs_from_phi(arg/eta,s,scaledphi)),axis=1)-len(v)*math.log(eta))
    av=constants['log_L0']+jlogs[0]-py-constants['log_w_v']
    au=constants['log_L0']+jlogs[1]-py-constants['log_w_u']
    bv=klogs[0]-constants['log_kappa']-constants['log_T']-constants['log_w_v']
    bu=klogs[1]-constants['log_kappa']-constants['log_T']-constants['log_w_u']
    mv=np.logaddexp(av,bv);mu=np.logaddexp(au,bu)
    mixed=(mv<0)&(mu<0);separate=(av<0)&(au<0)&(bv<0)&(bu<0)
    assert np.all(~mixed|separate)
    gap=separate&~mixed
    fields={'log_a_v':av,'log_a_u':au,'log_b_v':bv,'log_b_u':bu,'logsum_v':mv,'logsum_u':mu}
    result={'gauss_scale_order':order,'mixed_strict_count':int(np.sum(mixed)),'four_separate_necessary_count':int(np.sum(separate)),
        'separate_but_not_mixed_count':int(np.sum(gap)),
        'fixed_approximate_gate_99pct_simultaneous_Hoeffding':{'mixed':interval(int(np.sum(mixed))),'separate':interval(int(np.sum(separate))),'gap':interval(int(np.sum(gap)))},
        'mixed_empirical_probability':float(np.mean(mixed)),'separate_empirical_probability':float(np.mean(separate)),
        'mixed_over_separate_empirical':float(np.sum(mixed)/np.sum(separate)) if np.any(separate) else None,
        'near_mixed_log_boundary_1e_minus5_count':int(np.sum((np.abs(mv)<1e-5)|(np.abs(mu)<1e-5))),
        'near_four_separate_log_boundary_1e_minus5_count':int(np.sum(np.min(np.abs(np.column_stack([av,au,bv,bu])),axis=1)<1e-5)),
        'log_field_quantiles':{k:np.quantile(a,[0,.01,.5,.99,1]).tolist() for k,a in fields.items()}}
    return result,{'mixed':mixed,'separate':separate,'gap':gap},fields

def calibrations():
    rows=[]
    with mp.workdps(40):
        mass=2*mp.quad(phi_mp,[0,mp.mpf('.5'),1,4,mp.inf])
        rows.append({'kind':'phi_and_fs_normalization','phi_mass_40dps':mp.nstr(mass,40),'phi_mass_difference_from_one':mp.nstr(abs(mass-1),40),'fs_mixture_mass':{ss:mp.nstr(1-mp.mpf(ss)+mp.mpf(ss)*mass,40) for ss in ('.25','.75')}})
        for rr in ('0','.25','.5','.500001','1','2','8','16'):
            r=mp.mpf(rr)
            if r<=.5:direct=mp.quad(lambda t:t*(2-mp.exp(-(.5-r)/t)-mp.exp(-(.5+r)/t)),[0,1])
            else:direct=mp.quad(lambda t:t*(mp.exp(-(r-.5)/t)-mp.exp(-(r+.5)/t)),[0,1])
            exact=phi_mp(r)
            rows.append({'kind':'phi_E3_vs_scale','r':rr,'E3_40dps':mp.nstr(exact,40),'direct_scale_40dps':mp.nstr(direct,40),
                'mpmath_difference':mp.nstr(abs(exact-direct),40),'Gauss_order_values':[{ 'order':order,'value':float(phi_gauss(np.array([float(r)]),order)[0]),'relative_error_vs_E3':float(abs(mp.mpf(float(phi_gauss(np.array([float(r)]),order)[0]))/exact-1))} for order in ORDERS]})
        for dd in ('0','.25','.5','1'):
            d=mp.mpf(dd);lo=d-.5;hi=d+.5
            cuts=sorted(set([lo,hi]+[z for z in [mp.mpf('-.5'),mp.mpf('0'),mp.mpf('.5')] if lo<z<hi]))
            direct=mp.quad(lambda z:mp.mpf(1) if abs(z)<=.5 else phi_mp(z),cuts)
            rows.append({'kind':'C_E4_vs_h_max_h_phi','d':dd,'E4_40dps':mp.nstr(c_mp(d),40),'direct_40dps':mp.nstr(direct,40),'difference':mp.nstr(abs(c_mp(d)-direct),40)})
    return rows

def run():
    rows=[];independent=[]
    for idx,(stage,n,s,eta,v,u) in enumerate(configs()):
        seed=2026101600+idx
        rng=np.random.Generator(np.random.PCG64(seed))
        x=rng.uniform(-.5,.5,size=(N,n))
        x+=(rng.random((N,n))<s)*np.sqrt(rng.random((N,n)))*rng.laplace(size=(N,n))
        with mp.workdps(40):
            cv=np.array([float(c_mp(str(z))) for z in v]);cu=np.array([float(c_mp(str(z))) for z in u])
            a_s=1-mp.mpf(str(s))+mp.mpf(str(s))*phi_mp(mp.mpf('.5'))
            logt=n*(mp.log(a_s)-mp.log(mp.mpf(str(eta))))
            kap=8*(mp.mpf(128)/119)/(mp.mpf('.1')*mp.sqrt(1+mp.log(n)))
        constants={'log_L0':.5*math.log(n),'log_T':float(logt),'log_kappa':float(mp.log(kap)),
            'log_w_v':float(np.sum(np.minimum(0,np.log(cv)-math.log(.75)))),'log_w_u':float(np.sum(np.minimum(0,np.log(cu)-math.log(.75))))}
        kv=int(np.sum(cv<.75));ku=int(np.sum(cu<.75));assert kv>ku
        values=[];masks=[];fields=[]
        for order in ORDERS:
            val,mask,field=classify(x,s,eta,v,u,order,constants);values.append(val);masks.append(mask);fields.append(field)
        delta={label:int(np.sum(masks[0][label]!=masks[1][label])) for label in masks[0]}
        differences={label:float(np.max(np.abs(fields[0][label]-fields[1][label]))) for label in fields[0]}
        # Independent actual-sample mpmath checks, not just preselected small radii.
        observed=np.abs(x-v).ravel()[::max(1,x.size//8)][:8]
        for rr in observed:
            with mp.workdps(40):exact=float(mp.log(phi_mp(str(float(rr)))))
            approx=[float(np.log(phi_gauss(np.array([rr]),order)[0])) for order in ORDERS]
            independent.append({'case':idx+1,'r':float(rr),'logphi_E3_40dps':exact,'order96_log_error':abs(approx[0]-exact),'order192_log_error':abs(approx[1]-exact)})
        rows.append({'case':idx+1,'stage':stage,'n':n,'s':s,'lambda':1.,'eta':eta,'v':v.tolist(),'u':u.tolist(),'xi':.75,'L0':math.sqrt(n),
            'a_s':float(a_s),'T':float(mp.exp(logt)),'kappa':float(kap),'constants_log_domain':constants,'C_v':cv.tolist(),'C_u':cu.tolist(),
            'k_v':kv,'k_u':ku,'score_difference':kv-ku,'source_C_min_margin_to_xi':float(min(np.min(np.abs(cv-.75)),np.min(np.abs(cu-.75)))),
            'strictsoft_holds':s>1-2**(-1/n),'seed':seed,'receiver_sample_sha256':hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()).hexdigest(),
            'coordinate_mean':float(np.mean(x)),'coordinate_second_moment':float(np.mean(x*x)),'theoretical_coordinate_second_moment':s+1/12,
            'max_abs_scaled_kernel_argument':float(max(np.max(np.abs(x)),np.max(np.abs(x-v))/eta,np.max(np.abs(x-u))/eta)),
            'orders':values,'classifier_changes_between_orders':delta,'max_log_field_change_between_orders':differences,
            'empirical_fraction_mixed_intersection_both_orders':float(np.mean(masks[0]['mixed']&masks[1]['mixed'])),
            'empirical_fraction_mixed_union_both_orders':float(np.mean(masks[0]['mixed']|masks[1]['mixed']))})
        print('completed case '+str(idx+1),flush=True)
    return {'schema':'R216_direct_physical_mixed_MC_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'numpy_version':np.__version__,'mpmath_version':mp.__version__,'numpy_entry_sha256':hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'sampling':{'N_per_case':N,'generator':'PCG64','formula':'x=lambda*(Uniform[-.5,.5]+Bernoulli(s)*sqrt(U)*Laplace(0,1)), independent coordinates','lambda':1,'normalization':'sqrt(U) density2t times Laplace exp(-abs(z)/t)/(2t) gives w; h convolution gives phi; f_s is a normalized mixture.'},
        'counts':{'configs':len(rows),'Gauss_order_runs':2*len(rows)},'cases':rows,'kernel_calibrations':calibrations(),'actual_sample_phi_validation':independent,
        'sampling_uncertainty':{'total_fixed_approximate_gate_tests':TOTAL_TESTS,'family_failure_probability':.01,'Hoeffding_probability_halfwidth':EPS,
            'scope':'Simultaneous99pct only for each fixed Gauss-order numerical classifier (mixed/separate/gap). Quadrature/roundoff are not certified for exact physical events, so these are not exact-event confidence certificates.'},
        'scope':['Physical product receiver and same-x actual p,Jv,Ju,Kv,Ku; no independent leg factorization.',
            'T=(a_s/eta)^n only fixes H0=Hhat in this diagnostic; no original history, capture, high, FIRST, full Pi or FULL input is realized.',
            'w and score are actual C-displacement clocks at xi.75; C values are highprecision numerical rather than interval certificates.',
            'Gauss96/192 agreement and finite mpmath controls are diagnostics, not a uniform numerical error enclosure.',
            'No posterior or original traffic integral is constructed; positive score differences are reported but event probabilities are not a paid signed budget.',
            'No dimension-order fitting or automatic parameter adjustment.']}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'mixed_event_checks.json');args=ap.parse_args()
    start=time.monotonic();result=run();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'counts':result['counts'],'runtime_console_only':round(time.monotonic()-start,3)},sort_keys=True))
