# R216：保mixed门的有限熵身份与共同Fourier前因子

状态：均值/支撑超平面的弱熵对偶只给旧CM5c，本稿不将其重报为新成果。新有限工具是保留inverse-sum mixed势的准确前因子，并将它写为同一倾斜receiver下的共同特征函数积分；不需要新实矩域或未经证明的anti-concentration。另给一个可计算单频严格改善作为保守校验，但不把小常数改善包装成全局进展。统一n阶/实际source/selector预算尚未获得。

已读D02 SKILL、provenance与cube-interface，仅用有限域Gibbs身份；不引用其未读外部文献，不调用LDP/MDP。本文只写责任文件，未读本轮Astra预算草稿，不修改数值材料。

## ME1　真实fixed-receiver模型和mixed事件

固定实际s∈(0,1]、b>0、lambda=Lcur/b、eta=Hhat/b∈[1/2,1]、来源y,v,u及辅助t。p_y=P_s,Lcur(x−y)是归一概率密度，J_z=P1,b(x−z)，K_z=P_s,Hhat(x−z)。原w_z=w_t(y,z)>0在fixed(omega,V,j,y,t)下独立x；原T也只在本fixed参数估计中固定。零w/空域支按原合同先处理，不改原selector。

为避免与source QJ混用，记receiver概率Qrec(dx)=p_y(x)dx。定义真实mixed腿
\[
 a_z=\frac{L_0J_z}{p_yw_z},\qquad
 b_z=\frac{K_z}{\kappa\mathsf T w_z},\qquad
 \mathcal E=\{a_v+b_v<1,\ a_u+b_u<1\}.
 \tag{ME1}
\]
L0、kappa正且共同预选。所有量用同一个x；target另外交原capture，bad不继承该资格。原Hrem/high/FA等实际mask可留在左边；正放删去时只能得到更弱上界。Qrec不是原Pi_t，也不是Jν/QJ。

## ME2　有限Gibbs的资格和旧弱对偶范围

对Qrec-a.e.有限的可测V，若0<Z=E_Qrec e^V<infinity，且P≪Qrec、KL(P||Qrec)<infinity、E_P|V|<infinity，则由密度定义直接展开
\[
 KL(P\|Q_V)=KL(P\|Qrec)-E_PV+\log Z,
 \quad dQ_V=e^VdQrec/Z.
 \tag{ME2}
\]
有限域中KL非负给弱变分不等式。不能在无穷量间相减，也不能以trial P的下界冒充logZ的upper。

若qE=Qrec(E)>0，条件概率Q_E有KL(Q_E||Qrec)=−logqE；固定strictsoft核的loga/logb至多线性增长，Qrec有指数尾，所以Q_E对这些势绝对可积。若qE0则事件价已零，不构造条件概率。

logsumexp的精确有限维表达为
\[
 \log(e^X+e^Y)=\sup_{0\le q\le1}
 \{qX+(1-q)Y-q\log q-(1-q)\log(1-q)\}.
 \tag{ME3}
\]
可由标量微分或Bernoulli KL非负证明，端点用0log0=0。对mixed每腿固定一条支撑超平面，再用Gibbs/Chernoff，所得系数就是CM5c的r^r theta^theta/(r+theta)^(r+theta)。因此只写conditional均值落在logsumexp子水平集及其固定支撑超平面弱对偶，不提供新的核上界；本稿不宣称未经核验的无限维强对偶。

## ME3　有限且保mixed的非线性倾斜

取r,tau,theta,chi>0，beta_v=r+theta、beta_u=tau+chi，Theta=theta+chi。记
\[
 V_{lin}=-r\log a_v-\theta\log b_v
          -\tau\log a_u-\chi\log b_u,
 \quad M=E_{Qrec}e^{V_{lin}},\quad dP_*=e^{V_{lin}}dQrec/M.
 \tag{ME4}
\]
JK精确gap条件delta0=(1+r+tau)/lambda−r−tau−Theta/eta>0确保0<M<infinity，且带任意有限次|x|/log因子的积分有限。M准确为CM5的未乘scalar C的右边：
\[
 M=L_0^{-(r+\tau)}(\kappa\mathsf T)^\Theta
 w_v^{r+\theta}w_u^{\tau+\chi}\,
 b^{n\Theta}\prod_{i=1}^n m_i.
 \tag{ME5}
\]
每个m_i仍是同一坐标receiver的joint积分，不是来源独立化。

保完整mixed的势取
\[
 V_{mix}=-\beta_v\log(a_v+b_v)-\beta_u\log(a_u+b_u),
 \quad Z_{mix}=E_{Qrec}e^{V_{mix}}.
 \tag{ME6}
\]
事件E上Vmix>0，故直接正不等式给qE≤Zmix；也可用ME2和E_QE Vmix≥0得到同一方向。下文scalar上界证明Zmix≤C_vC_uM<infinity；Vmix绝对值至多线性增长，且|Vmix|e^Vmix受严格gap的单项倾斜支配，故两种tilt均满足有限Gibbs资格。未用Z有限但势不可积的形式差式。

## ME4　精确mixed曲率前因子

令q_v=r/beta_v、q_u=tau/beta_u，均在(0,1)。写
\[
 C_v=q_v^r(1-q_v)^\theta,\quad C_u=q_u^\tau(1-q_u)^\chi,
\]
\[
 D_v=\log(a_v/b_v)-\log(r/\theta),\quad
 D_u=\log(a_u/b_u)-\log(\tau/\chi).
\]
对一腿beta>0、q∈(0,1)，定义
\[
 h_q(D)=\log(1-q+qe^D)-qD,
 \qquad f_{beta,q}(D)=e^{-beta h_q(D)}.
 \tag{ME7}
\]
h_q≥0，由Bernoulli KL或凸性可证。直接代数精确给
\[
 (a+b)^{-\beta}=C\,a^{-r}b^{-\theta}f_{\beta,q}(D),
 \qquad C=q^r(1-q)^\theta,\quad\beta=r+\theta.
\]
因此
\[
 \boxed{q_E\le Z_{mix}=C_vC_uM\,\mathcal R_{mix},\qquad
 \mathcal R_{mix}=E_*[f_v(D_v)f_u(D_u)]\in(0,1].}
 \tag{ME8}
\]
旧CM5c只保Rmix≤1。这里没有把(1−a)余量拆成四个独立门，也未重新选择source/gate。Rmix是准确nonlinear修正，不能仅将它命名后说预算已解；下面给其可复算有限表示。

## ME5　共同特征函数，无新增实矩条件

缩x=y+bz后，P*正密度按坐标为g_i(z)/m_i；这是固定product receiver的倾斜事实，不是原source或Pi坐标独立。定义一维实际函数
\[
 \ell_{v,i}(z)=\log j_{v,i}(z)-\log p_\lambda(z)-\log k_{v,i}(z),
\]
\[
 \ell_{u,i}(z)=\log j_{u,i}(z)-\log p_\lambda(z)-\log k_{u,i}(z).

\]
因a_z/b_z=L0 kappa T J_z/(p_yK_z)，原w_z精确消去，故
\[
 D_z=\log(L_0\kappa\mathsf T b^n)-\log(r_z/\theta_z)
       +\sum_i\ell_{z,i}(z_i).
 \tag{ME9}
\]
v腿(rz,thetaz)=(r,theta)，u腿=(tau,chi)。单位b^n不可遗漏。

记Phi(omega,nu)=E_*exp(i omega Dv+i nu Du)，则
\[
 \boxed{\Phi(\omega,\upsilon)=e^{i(\omega d_v^*+\upsilon d_u^*)}
 \prod_i\frac{\int g_i(z)e^{i\omega\ell_{v,i}(z)+i\upsilon\ell_{u,i}(z)}dz}{m_i},}
 \tag{ME10}
\]
dz*=log(L0 kappa T b^n)−log(rz/thetaz)，不是来源位移。每个复积分的模≤m_i，所以无新实矩域或未知高阶source矩；所有同坐标相关保留。

## ME6　Beta Fourier的准确可计算表示

设r,theta>0、beta=r+theta、q=r/beta、T*=log(r/theta)，f=f_beta,q。约定hat f(omega)=∫e^−i omega D f(D)dD。以t=e^(D+T*)代换直接得
\[
 \boxed{\widehat f(\omega)=C^{-1}e^{i\omega T^*}
 B(r-i\omega,\theta+i\omega),}
\]
\[
 B(z,w)=\int_0^\infty t^{z-1}(1+t)^{-(z+w)}dt,
 \qquad\Re z,\Re w>0.
 \tag{ME11}
\]
此Beta积分绝对收敛，不以特殊函数软件或解析延拓代替定义。一般q时hatf可复，不能假作正Fourier权。若需核对特殊r=theta，可定义Gamma(z)=∫0∞t^(z−1)e^−tdt于Re z>0；两个绝对收敛Gamma积分用总半径与比例变量代换，直接给Gamma(z)Gamma(w)=Gamma(z+w)B(z,w)。w为z共轭时Beta为非负|Gamma(z)|²/Gamma(2r)，且T*=0。本稿一般式不依赖这一特殊简化。

f两侧以r/theta的正指数衰减，∥f∥1=C^-1B(r,theta)<infinity。若m0=max(r,theta)，logf导数在[−theta,r]，二阶log导数绝对值≤beta/4，所以
\[
 \|f''\|_1\le(m_0^2+\beta/4)\|f\|_1,
 \quad |\widehat f(\omega)|\le
 \min\{\|f\|_1,\|f''\|_1/\omega^2\}.
 \tag{ME12}
\]
分部积分端点由指数尾消失，故hatf∈L1。Fourier逆变换可先给hatf乘Gaussian频率截断，Fubini等于对f的Gaussian卷积，再由连续f的近似恒等与hatf的L1支配去截断；无需假设未证的分布意义反演。

两腿用ME12合法Fubini，得到
\[
 \boxed{\mathcal R_{mix}=(2\pi)^{-2}\int_{\mathbb R^2}
 \widehat f_v(\omega)\widehat f_u(\upsilon)
 \Phi(\omega,\upsilon)\,d\omega d\upsilon.}
 \tag{ME13}
\]
这是一个共同特征函数的精确积分。绝对值上界可写min(1,(2pi)^−2∫|hatfv hatfu Phi|)，但不能把各腿Phi分解成独立乘积。它用精确m_i/Phi替代CM12粗C^n包络；并不证明原乘积∏m_i本身只有多项式规模。

r或theta0时f某侧不再L1，不能直接套ME11--13或写log0；该腿回到CM5c的边界常数1与f≤1，或取已证明合法的内点极限，不能形式补一份Fourier概率。

## ME7　可核算单频改进：只作有限校验

为避免将未知Rmix仅改名，可给无需anti-concentration的有限上界。h_q''(0)=q(1−q)，且(log h_q'')'=1−2sigma∈[−1,1]，所以
h_q(D)≥a_q min(D²,1)，a_q=q(1−q)/(2e)。用1−e^−cu≥u(1−e^−c)及1−cosD≤2min(D²,1)，得
\[
 f_{\beta,q}(D)\le1-c(1-\cos D),\qquad
 c=\tfrac12(1-e^{-\beta q(1-q)/(2e)})\in(0,1/2).
 \tag{ME14}
\]
两腿乘积Rmix的upper为
\[
 \begin{split}
 \mathcal B={}&(1-c_v)(1-c_u)
 +c_v(1-c_u)\Re\Phi(1,0)
 +c_u(1-c_v)\Re\Phi(0,1)\\
 &+\tfrac12c_vc_u\Re\{\Phi(1,1)+\Phi(1,-1)\}.
 \end{split}\tag{ME15}
\]
B是两个[0,1]实际函数乘积的期望，故0≤B≤1；若只取模，正系数同式给Babs≥B且Babs≤1。所有项是四个joint CF的有限计算，不需新增inverse矩。

在本严格soft、lambda/eta≤1核范围，每个ell_v,i的尾为(1/lambda+1/eta−1)|z|+log|z|+常数+o(1)，正线性系数至少1。其在外尾连续且非恒，tilt密度严格正，因此e^iDv不是a.s.常数，|Phi(1,0)|<1；u同理。这证明内点指数时Babs<1，给同一单项CM5c bound的严格有限改善。若比较经过所有指数优化的旧bound，只有在相应内点选择上应用；不声明处处优于旧全优化包络。

该单频常数不抵消C^n，不自动产生n^−1/2。q→0/1时c退化必须保；数值未获授权运行的CF不能写作通过。主几何接口是ME13，而不是把ME15小常数包装成全局付款。

## ME8　何种真实非退化才会产生根阶前因子

例如先正放另一腿f_u≤1。若真实marginal CF满足|Phi(omega,0)|≤exp(−V omega²/2)于|omega|≤omega0，则ME13的一腿版给
\[
 E_*f_v(D_v)\le
 \frac{\|f_v\|_1}{\sqrt{2\pi V}}
 +\frac1{2\pi}\int_{|\omega|>\omega_0}
 |\widehat f_v(\omega)\Phi(\omega,0)|d\omega.
 \tag{ME16}
\]
这是conditional有限界；若沿ME16本式使用，第二项不能丢。同目录主代理稿concentration_bridge.md的CB1--5另给有限区间浓度桥接：可由同一局部Gaussian条件直接控制曲率前因子，不要求额外高频衰减。因此高频控制不是此用途的独立必需条件；仍须核验真实倾斜下的V、omega0及其参数费用，不能用未证anti-concentration补齐。

局部Gaussian条件可从实际coordinate tilt核验而非假来源独立：若sigma_i²=Var_*(ellvi)、D4_i=E(ellvi−ellvi')^4，独立撇号仅用于同一个一维tilt的代数复制，则
|phi_i(omega)|²≤1−omega²sigma_i²+omega^4D4_i/24。
在omega²D4_i≤12sigma_i²时有|phi_i|≤exp(−omega²sigma_i²/4)，从而V=(1/2)Σsigma_i²。sigma_i0的退化坐标只贡献模1，不借其取得正V或共同频率窗。JK严格gap给这些log矩有限，但不免费给其统一下界、共同omega0或高频收缩。退化方向、来源位移和soft/scale端点均须单列。

因此本稿给可计算的非线性前因子及真正缺的谱条件，不宣称已经获得uniform根阶。任意finite nu和原Pi²/e²不因receiver tilt而取得KL/方差/列帽。

## ME9　原回代与数值范围

以上Qrec/P*是fixed物理product receiver及其单项tilt。若原s,L,H,T/g随receiver变，坐标tensor和有限Gibbs不能直接外提到原selector；须保实际域/盒费用或原CM12全部指数成本。原capture/goodbad、negative余额、β、hard源、唯一j/window和Pi²/e²仍完整保留；两个原w已用于R215权吸收时不能再当完整后验免费使用。

旧工具范围已窄核R216 prior_geometry_index及round197/research.zip::report.md第5--13行：R197确有fixed pair、真实p receiver下的cap反集中，依赖分离坐标数m和来源固定B；其平方根因子不是本轮新结果。但此处参考为两腿monomial tilt P*，变量为logJ−logp−logK，不能将旧log(p/J)的anti-concentration常数无价转移，也不能删旧cap/separation条件。本稿新增的是完整mixed inverse-sum曲率因子的可计算Phi表示，不是重新登记R197的一侧尾工具。ME16保留原Fourier余项公式；结合concentration_bridge.md的CB5--6后，后续真正待证的是实际tilted非退化与共同低频窗、原来源和selector费用，高频余项不再作为独立必需假设。该桥接不保证所缺的原几何条件。

本轮既定六个product-receiver Monte Carlo仅估mixed/separate事件及有限score诊断，非tilted CF/Fourier运行；未运行的新增ME10--16不预报数值通过。MC mixed和separate只少量差异不构成普遍强收缩证据。精确有限身份和前因子可审，原一般来源/receiver付款尚未闭合。
