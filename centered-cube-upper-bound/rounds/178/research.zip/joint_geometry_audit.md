# R178 独立联合几何审查

作者前筛查记录；仅本文件，不数值/Git/spawn/PDF。初读task_contract时尚未落盘，现已实读修正后的合同。原固定(omega,V,j,y,t)的nu/Zt/wt/et/Pit独立receiver x；terminal g/Pig/wg、s/L/R、A/alpha及receiver门不独立。该区别继承原R128 RT4，不是本轮改模型。

## 1. 真实重叠张量及原费用位置

记d_i=(y_i−v_i)/b、lambda=L/b∈[1/2,1]，Ci=C(d_i)。C=h*F，F=max(h,phi)在hard core内为1，外为phi；C(0)=1、0<C≤1，但integral C=integral F>1，不能概率化。

一维真实overlap为

    integral h_L(x−y)phi_b(x−v)dx
      =b^(−1)(h_lambda*phi)(d).

固定s,L,b时令

    I_in(d)=integral_(|X|≤lambda/2) lambda^(−1)b_s(X/lambda)phi(X+d)dX,
    I_out(d)=integral_(|X|>lambda/2) lambda^(−1)b_s(X/lambda)phi(X+d)dX.

对固定y,v的receiver product核，精确有

    integral_(m_L(x−y)≤m0) P_(s,L)(x−y)J_b(x−v)dx
      =b^(−n) sum_(|S|≤m0) product_(i∉S)I_in(d_i)
                               product_(i∈S)I_out(d_i). (A1)

m_L是x−y count，Ci/原k_t是y−v geometry；A1不将它们等同。张量仅来自物理dx/product核，beta/nu/Pi可任意相关。外源求和及两内槽仍按实际测度，不能把坐标当独立来源。

若ξt≤ξg≤1，R_i=wt_i/wg_i的准确值为1、ξg/Ci、ξg/ξt三个区域，且wg_i≥Ci。因此Ci R_i≤wt_i≤1。固定L、任意receiver-dependent ξg(x)≤1时，用wg≥productCi即可保留单份权的补偿；但good平方后的companion可含wt/wg²，不能误当单份wg。在clock ξt≥1/2的最粗坐标预算Ci wt_i/wg_i²≤2，逐坐标使用会有2^n代价，未因此得到polylog。

R173已付J_v(delta+)²Pi²的能量方向固定，不能交换为J_v k_u²而免价；也不能延伸归一Pi到不合法时段后仍引用e_t≥e_g。下述直接raw正支配若不使用e_g，可保留原x-independent Pi，在原构造域外或et0处取零subprobability后正延伸时间；不替换Pig。

## 2. 常数35的adaptive共同尺度overlap：独立核算

0<lambda≤1有h_lambda*w≤F：inside平均≤1，outside w在正半轴凸，其centered平均随半长递增。故h_lambda*phi=h*(h_lambda*w)≤C，无lambda^(−1)损失。current-inside b_s≤1进一步给I_in≤C；outside仅有I_out≤s(phi_lambda*phi)，不能把softcurrent卷积也免费当hard overlap。

强版在lambda∈[1/2,1]令

    r(lambda)=sinh(lambda/2)/(lambda sinh(1/2)).

inside：even decreasing w使h_lambda*w≤h_(1/2)*w(0)≤15/16；用w(t)≤e^(−|t|)≤1−|t|/2于|t|≤1/4。级数ratio≤1/24给sinh(1/2)≤12/23，所以r≥23/24>15/16。outside：每个指数项ratio=sinh(lambda t)/(lambda sinh t)，t=1/(2a)≥1/2；t coth t严格增，故ratio随t不增并≤r(lambda)。于是

    h_lambda*w≤r(lambda)F,
    h_lambda*phi≤r(lambda)C.                           (A2)

又t cosh t−sinh t≥t³/3和sinh t≤24t/23（0≤t≤1/2）给

    (log r)'≥23lambda/288,
    r(lambda)≤exp[−(1−lambda)/17].                     (A3)

后式由积分23(1−lambda²)/576及lambda≥1/2得到，lambda1等号无遗漏。

对共同scalar半径的hard envelope

    E_n(z)=sup_(lambda∈[1/2,1])h_lambda^(tensor n)(z)
          =h_1^(tensor n)(z)+n integral_(1/2)^1
                                  h_lambda^(tensor n)(z)dλ/λ.

这是精确立方体shell身份，不把每坐标尺度独立选择。Tonelli、A2/A3和1/lambda≤2给

    (E_n*phi^(tensor n))(d)
       ≤[1+n integral_(1/2)^1r(lambda)^n dλ/λ]productCi
       ≤35 productCi.                                (A4)

故固定b、fixed y/v时，任意measurable commonL(x)∈[b/2,b]的hardreceiver/J真实dx overlap≤35 b^(−n)productCi。此式真正处理尺度选择，不需把L冻结；不同b/window不在同一35预算中。单份wt/wg可由wg≥productCi补偿，但它本身没有支付et、实际p/Q/alpha等三点乘子。旧单独正尺度envelope的线性L1成本不否定A4，因为此处保留了与J/C的共同空间衰减。

## 3. sparse current-L实际raw候选：独立核算

为核准确新增候选，亲读其所引用的R128 RT11–13窄段：任意长度lambda∈[1/2,1]区间I满足

    lambda^(−1)(integral_I sqrt(phi))²
      ≤rho_* integral_I phi,  rho_*=1−2^(−34).          (A5)

原log斜率≥1/96于r≥1/16及global logphi 4-Lipschitz，取两段各lambda/8给sqrt(phi)差>2^(−14)M，方差块1/64确给2^(−34)。该窄段常数/区间选择可核，不把作者结论本身当证据。

令a_*=rho_*^(1/4)=exp(−d)，d>0。两次CS及I⊂[D−1/2,D+1/2]给currentcore内

    integral_(|X|≤lambda/2) F_lambda(X)^(3/4)
                     [phi(X−D)/C(D)]^(1/4)dX≤a_*.

其中F_lambda=lambda^(−1)F(X/lambda)。外core的全R上界可取B=36：phi(X)≤3e^(−|X|)/(1+|X|)，C(D)≥c0 e^(−|D|)/(1+|D|)，c0=7(1−e^(−1))²/24；triangle给phi(X−D)/C(D)≤(3/c0)(1+|X|)e^|X|，且phi_lambda≤2phi，故积分≤4·6^(3/4)(3/c0)^(1/4)<36。

令T=log(4eB/d)，eta=d/(4T)，m0=floor(eta n)。按真实inside/outside product拆分和binomial entropy，

    integral_(m_L≤m0) product_i
           F_lambda(X_i)^(3/4)[phi(X_i−D_i)/Ci]^(1/4)dX
      ≤e^(−dn)sum_(r≤m0)binom(n,r)(B e^d)^r
      ≤e^(−dn/2).                                    (A6)

准确费用是H(eta)+eta log(B/a_*)≤eta[T+logT+d]≤d/2；用d<1及logT+1≤T，floor和neta<1时也合法。

upward e^(1/n)的L-grid至多n+2节点，p_(s,L)≤eP_(s,L')≤eF_(L') product，且m_L'≤m_L。故任意actual s(x)/L(x)可用无s-menu的e^(3/4)(n+2)A6正包络。

原good与A≤1给

    pA≤(K/3)^(1/4)p^(3/4)(J/wg)^(1/4).

用wg≥productCi及上述真实receiver kernel包络，再在固定(omega,V,j,y,t)的原Pi上Tonelli，score≤n、第二Pi质量≤1、time≤log2。receiver-dependent terminal/good/high/history门仅在完成此点态正支配后丢弃。Pi在et0/原构造域外取零subprobability可正延伸clock；不调用扩展外的e_t≥e_g。保守付j菜单至多n+2，不免费依赖uniquej免此归一。结果为

    RawSparse≤(32Lambda/3)(K/3)^(1/4)e^(3/4)log2
                  n(n+2)²e^(−dn/2)W_beta
      ≤96Lambda(K/3)^(1/4)e^(3/4)log2
                    (5/(ed))^(5/2)sqrt(n)W_beta.       (A7)

吸收用n+2≤3n和max_x x^(5/2)e^(−dx/2)=(5/(ed))^(5/2)。hard16/3及outer2Lambda各一次，完整beta、原来源/clock/窗口保留，不借signed负信用。该候选可只切原未付lowcapture以不交组合。

eta极小（d约为2^(−36)的量级，eta还除以约log(1/d)），不能把sparse current-L支等同R177 lowoverflow全部补集。所有s虽无需soft下界负幂，仍留下m0<m_L<k_delta的一般中段及其他原未付对象。等待作者完整稿，核其原Pi量词与全部外费；不运行数值。


## 4. LG末增低soft支：作者前核算

对actual s≤eta/4，R177原FIRST latent MGF在theta=log2给E2^K≤(1+s)^n≤exp(eta n/4)。m>floor(eta n) implies m>eta n且m≤K，因此

    Pr(m>m0)≤exp(−a0 n), a0=eta(log2−1/4)>0.

按原OT直接raw粗帽，尾价为B0 n exp(−a0n)E integral qdx，其中B0=(32Lambda/3)log2。因为

    n exp(−a0 n)≤2/(a0e) exp(−a0 n/2),

n≥(2/a0)max{1,log[2B0/(a0e epsilon)]}足以使尾价≤epsilon receiver价。与A7稀疏source价合并只支付这个极低soft分支；它没有免费推广所有n/所有s。eta约1.18e−13、soft截止eta/4约3e−14；原strictsoft下界同时成立要n极大。量级说明不参与证明，精确d/eta/a0才是使用的常数。

## 5. source_overlap_identity.md全文后审

已在第1–2节独立筛查之后实读SO1–SO18全稿。指定范围通过，无需修订。SO2–8的r(lambda)、1/17衰减、准确common-radius层蛋糕及35全部与A2–A4一致；它真实处理adaptive L(x)，没有错误交换sup与积分，也不把C/F概率化。SO9–11在current m=0分支、任意s(x)、一份wg分母合法，固定b及源中心条件明确。

SO12–14 triple J overlap只给product min(Cv,Cu)，两份阈值比后仍有product1/max(Cv,Cu)；没有把min伪换为乘积或给原u添加免费J_u。SO15–17固定参数下的lowm系数身份/latent混合准确，m小不推出soft标签少，soft位移卷积保留；不能将这些固定参数系数在adaptive尺度下冻结。SO18精确回代的剩余乘子含rho、Q、wg、et及两源，未付边界正确。

固定原Pi_t可在合法receiver正支配后移出dx，Pig及terminal对象不行；正文修正与原RT4一致。额外b菜单、原窗口/history/来源总费用未省。本工具不是SO11数值常数直接等于原companion W预算，也不自行领取平方energy根价。


## 6. low_overflow_joint_geometry.md全文后审

已先完成第3–4节独立筛查，再实读LG1–LG20全稿。指定范围通过，唯一需补清的共同时窗量词已由父级修正并实读确认：去掉x-dependent far门后仅扩大至fixed j的ξ=c_jt/b∈[1/2,1]，即[b/(2c_j),b/c_j]与原构造域交集，et0/域外取零subprobability；不是声称整个I_(j,V,y)有log2长度。

LG6的已冻结RT13已按其窄段证明实核；LG7两次CS无lambda损失。LG8–10的C/phi尾界及B=36自证正确：C尾≥w、w在e^(−t)/(t+2)与e^(−t)/(1+t)之间，c0>21/200>8/81足够通过严格四次方比较。LG11–12实际product和熵费用正确，不省二项组合数，也不使用来源独立。

LG13–16的s-free F包络、向上L-grid、m_L'≤m_L、good的1/4插值、wg≥Cprod以及原Pi_t换序均合法。两份Pi质量至多1且辅助source不依x；依x的terminal/Pig/g/wg/alpha/history先经具体正支配，不被冻结。time log2、score n、L-grid与安全j各n+2、hard16/3和outer2Lambda均付一次，给A7精确原raw来源价，不由Cauchy能量接口冒领。

LG18–20与第4节一致：s≤eta/4的尾系数是B0 n exp(−a0n)，只有展示的n阈值后才可写epsilon。eta约1.18e−13、soft截止约3e−14，不能描述成一般soft分支；与原strictsoft兼容也需极大维度。一般m0<m_L<k_delta中段仍在，所有原母核份额没有一并支付。

## 7. 主稿与报告整合范围审查

已在两作者全文后审之后实读proof.tex.txt及report.md。主要常数35、1/17、rho_*、B36、eta、C_cur、B0/a0及good插值与LG/SO一致；完整time窗口修订也已同步主稿。固定b的adaptive common-L工具、单份wg补偿与原CJ反核/归一乘子的未付位置明确区分。

主稿真实raw稀疏支与R177尾支按实际事件不交化，仍保留一般中间带；lowsoft覆盖的有限维数条件没有被写成无条件epsilon价。报告将数值的原子、finitefuture、同一外质量与n16失败限制留账，本独审不复核新数值字段，不运行脚本；一般公式依据独立推导与全文后审，而非数值结果。

最终判断：指定理论及整合范围通过，无待修数学问题。新source根阶付款仅覆盖明确稀疏current-L支；常数极保守，一般n^(1/2+o(1))弱型上界及中段联合交通仍未闭合。


## 8. 最终哈希绑定与冻结

| 理论文件 | SHA256 |
| --- | --- |
| source_overlap_identity.md | 97a9687f2335f63e5adb03e03a6e20b8edc26fd8944b332285d7818ce5c213a6 |
| low_overflow_joint_geometry.md | 592f1a0dc5cea796ac812b0e3bb79651e6a66b8783d05a0087556e4f8cd7acaa |
| proof.tex.txt | 9d85f8001c06dcfb6a0d9fdd52f3764878b1ba0c8bdb38d7912db607de2cefbf |

以上准确版本已实读并实算绑定。常数35的共同尺度overlap及稀疏current-L原raw根阶价通过；极小soft截止、维数门与一般中段未付范围完整保留。辅助Pi_t的原x独立性和共同时窗是本次回代成立的必要合同，terminal对象未被偷换。仅本责任文件修改；无数值、Git/spawn/PDF或作者文件编辑。现冻结停止。
