"""Finite diagnostics for analytic SO2--SO7, not a proof of uniform bounds."""
from pathlib import Path
import sys,json
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=40
r=lambda l:m.sinh(l/2)/(l*m.sinh(m.mpf('.5')))
rows=[]
for count in (3,11,101):
    ls=[m.mpf('.5')+m.mpf(i)/(2*(count-1)) for i in range(count)]
    gaps=[-(m.log(r(l))) -(1-l)/17 for l in ls]
    deriv=[m.coth(l/2)/2-1/l-23*l/288 for l in ls]
    assert min(gaps)>=-m.mpf('1e-38') and min(deriv)>0
    rows.append(dict(stage=count,min_exponential_gap=str(min(gaps)),min_derivative_gap=str(min(deriv))))
coeff=[]
for n in (1,2,4,16,64,256,1024):
    v=1+n*m.quad(lambda l:r(l)**n/l,[m.mpf('.5'),m.mpf('.9'),1])
    assert v<=35
    coeff.append(dict(n=n,envelope_coefficient=str(v)))
inside=4*(1-m.exp(-m.mpf('.25')))
assert inside<m.mpf(15)/16<m.mpf(23)/24<=r(m.mpf('.5'))
out=dict(precision=40,stages=rows,coefficients=coeff,inside_upper_bound=str(inside),scope='Finite checks of analytic constants; no exponent fitting, no proof of original traffic budget.')
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
