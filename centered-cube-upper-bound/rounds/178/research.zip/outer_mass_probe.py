#!/usr/bin/env python3
"""R178 one global outer-atom mass, fixed physical inputs and receiver grids."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import importlib.util,json,math,time,hashlib,sys
HERE=Path(__file__).resolve().parent
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round176_20261016_final_checkpoint/receiver_geometry_probe.py')
sp=importlib.util.spec_from_file_location('r176_frozen',DEP);b=importlib.util.module_from_spec(sp);sp.loader.exec_module(b)
OLD=F(1,2**32);I=b.I;ct=b.ct

def row(c,x):
 r=b.plain(c,x);n=c['n'];py=r['p_y'];q0=r['q']-float(OLD)*py;Jn=math.fsum(float(a)*j for a,j in zip(b.NU,r['J']));al0=r['alpha']-float(OLD)*py/Jn
 slope=py*r['J'][0]/(Jn*r['TDelta'][0]);r0=r['rho'][0]+float(OLD)*slope;fac=r['J'][0]/(3*r['Q'][0]);a0=r0*fac;a1=slope*fac;drop=r['posterior_drop'];W1=py*drop*a0;W2=py*drop*a1;facC=py**2/r['J'][0]*drop/n;C1=facC*a0*a0;C2=2*facC*a0*a1;C3=facC*a1*a1
 constraints=[]
 def add(name,A,B,strict=False):constraints.append(dict(name=name,a=A,b=B,strict=strict,form='a*epsilon+b>=0 (strict if marked)'))
 add('epsilon_nonnegative',1.,0.);add('alpha_nonnegative',py/Jn,al0);add('high',-2*py,py*sum(float(a)*w for a,w in zip(b.NU,r['wg']))-2*q0);add('target_rho_positive',-slope,r0,True)
 pos,masses=b.source(c);basepos=[pos[0],pos[1],pos[3]];basemass=[masses[0],masses[1],masses[3]]
 for index,f in enumerate(r['finite_future']):
  ss,ll=F(f['s']),F(f['scale']);name='future_'+str(index)+'_'+str(ss)+'_'+str(ll)
  if ss==b.S and ll==F(r['L']):constraints.append(dict(name=name,symbolic_current_equality=True));continue
  fy=b.fast_kernel(ss,ll,x,c['y']);fbase=math.fsum(float(m)*b.fast_kernel(ss,ll,x,z) for m,z in zip(basemass,basepos));add(name,py-fy,q0-fbase)
 hardbase=sum((m for m,z in zip(basemass,basepos) if all(abs(t-z)<=b.R/2 for t in x)),F(0));hy=int(all(abs(t-c['y'])<=b.R/2 for t in x));add('hard_h_R_16over3',(16/3)*py-hy,(16/3)*q0-float(hardbase))
 lo=0.;hi=math.inf;lop='epsilon_nonnegative';hip=None;infeasible=[]
 for co in constraints:
  if 'a' not in co:continue
  A,B=co['a'],co['b']
  if A>0:
   z=-B/A
   if z>lo:lo=z;lop=co['name']
  elif A<0:
   z=-B/A
   if z<hi:hi=z;hip=co['name']
  elif B<0:infeasible.append(co['name'])
 static={k:v for k,v in r['checks'].items() if k not in ('high','alpha_nonnegative','target_A_positive','finite_future','hard_16over3')};valid=all(static.values()) and not infeasible and lo<hi
 return dict(n=n,x=r['x'],L=r['L'],Lplus=r['Lplus'],j=r['j'],D=r['D'],Hhat=r['Hhat'],physical=r,q_base=q0,p_y=py,Jnu=Jn,alpha_intercept=al0,alpha_slope=py/Jn,rho_intercept=r0,rho_slope=slope,A_intercept=a0,A_slope=a1,original_polynomial=[W1,-W2],companion_polynomial=[C1,-C2,C3],constraints=constraints,epsilon_interval=[lo,hi],lower_limiter=lop,upper_limiter=hip,static_checks=static,valid=valid,infeasible_zero_constraints=infeasible)

def value(coeff,e):return math.fsum(a*e**(i+1) for i,a in enumerate(coeff))
def extrema(coeff,lo,hi):
 cand=[lo,hi]
 if len(coeff)==2:
  if coeff[1]<0:cand.append(-coeff[0]/(2*coeff[1]))
 else:
  C,D,E=coeff;disc=4*D*D-12*E*C
  if disc>=0 and E:
   cand.extend([(-2*D-math.sqrt(disc))/(6*E),(-2*D+math.sqrt(disc))/(6*E)])
 cand=sorted(set(t for t in cand if lo<=t<=hi));best=max(cand,key=lambda e:value(coeff,e));return dict(epsilon=best,value=value(coeff,best),candidates=[dict(epsilon=e,value=value(coeff,e)) for e in cand],boundary=best in (lo,hi),status='closure optimum; strict active endpoints may be unattained')
def aggregate(rows,dx):
 lower=max((r['epsilon_interval'][0],i,r['lower_limiter']) for i,r in enumerate(rows));upper=min((r['epsilon_interval'][1],i,r['upper_limiter']) for i,r in enumerate(rows));lo,hi=lower[0],upper[0];W=[float(dx)*math.fsum(r['original_polynomial'][i] for r in rows) for i in range(2)];C=[float(dx)*math.fsum(r['companion_polynomial'][i] for r in rows) for i in range(3)]
 return dict(evaluated_nodes=len(rows),cell_dx=str(dx),common_interval=[lo,hi],lower_limiter=dict(row=lower[1],constraint=lower[2]),upper_limiter=dict(row=upper[1],constraint=upper[2]),all_static_valid=all(r['valid'] for r in rows),original_polynomial=W,companion_polynomial=C,original_optimum=extrema(W,lo,hi),companion_optimum=extrema(C,lo,hi),old_epsilon_original=value(W,float(OLD)),old_epsilon_companion=value(C,float(OLD)))
def evalrow(r,e):
 p=r['physical'];al=r['alpha_intercept']+r['alpha_slope']*e;rho=max(0,r['rho_intercept']-r['rho_slope']*e);gam=al*r['Jnu'];K0y=b.fast_kernel(b.S,F(p['Hhat']),tuple(F(t) for t in r['x']),b.INPUTS[r['n']]['y'])
 margins=[dict(name=c['name'],margin=c['a']*e+c['b']) for c in r['constraints'] if 'a'in c];passes=all(z['margin']>0 if next(c['strict'] for c in r['constraints'] if c['name']==z['name']) else z['margin']>=0 for z in margins)
 return dict(epsilon=e,feasible=passes and all(r['static_checks'].values()),constraint_margins=margins,q=r['q_base']+e*r['p_y'],alpha=al,rho_target=rho,polynomial_original_outer=value(r['original_polynomial'],e),polynomial_companion_outer=value(r['companion_polynomial'],e),actual_active_original_outer=value(r['original_polynomial'],e) if passes and all(r['static_checks'].values()) else None,actual_active_companion_outer=value(r['companion_polynomial'],e) if passes and all(r['static_checks'].values()) else None,gamma=gam,mu_bad=float(b.NU[1])*p['K0'][1]/gam,tau_outer_y=e*K0y/gam,scope='polynomial objectives only valid while all active gates hold; infeasible values are diagnostic algebra, not an actual integral')

def main():
 start=time.monotonic();cal=[row(b.INPUTS[4],tuple([F(0)]*4)),row(b.INPUTS[16],tuple([F(0)]*16)),row(b.INPUTS[16],tuple([F(1,1000)]+[F(2,1000)]*15))];grids=[]
 for order in (3,5):
  nodes=[F(-1,200)+F(2*i+1,200*order) for i in range(order)];rows=[]
  for x in product(nodes,repeat=4):
   if time.monotonic()-start>120:raise RuntimeError('Prescreen120s cap reached; no expansion')
   rows.append(row(b.INPUTS[4],x))
  dx=F(1,100)**4/order**4;ag=aggregate(rows,dx);grids.append(dict(order=order,summary=ag,rows=rows))
 lo=max(g['summary']['common_interval'][0] for g in grids);hi=min(g['summary']['common_interval'][1] for g in grids);assert lo<hi and all(g['summary']['all_static_valid'] for g in grids)
 obj=grids[-1]['summary']['original_polynomial'];closure=extrema(obj,lo,hi);ideal=closure['epsilon'];chosen=ideal;choice='interior I vertex'
 if ideal<=lo:chosen=lo+.02*(hi-lo);choice='2 percent inside lower bound; closure optimum unattained'
 elif ideal>=hi:chosen=lo+.98*(hi-lo);choice='2 percent inside upper bound; closure optimum unattained'
 epsilon=F(str(chosen)).limit_denominator(10**12);assert lo<float(epsilon)<hi
 for g in grids:
  ag=g['summary'];ag['final_epsilon_original']=value(ag['original_polynomial'],float(epsilon));ag['final_epsilon_companion']=value(ag['companion_polynomial'],float(epsilon));ag['original_gain_over_old']=ag['final_epsilon_original']/ag['old_epsilon_original'];ag['companion_gain_over_old']=ag['final_epsilon_companion']/ag['old_epsilon_companion'];ag['final_all_nodes_feasible']=all(evalrow(r,float(epsilon))['feasible'] for r in g['rows'])
 single=[]
 for r in cal:
  lo1,hi1=r['epsilon_interval'];single.append(dict(coefficients=r,original_optimum=extrema(r['original_polynomial'],lo1,hi1),companion_optimum=extrema(r['companion_polynomial'],lo1,hi1),old=evalrow(r,float(OLD)),final=evalrow(r,float(epsilon))))
 screen=time.monotonic()-start;b.EPS=epsilon;cert=[b.box_certificate(N) for N in (128,256)]
 dependencies=[DEP,b.SEED,b.SEED.with_suffix('.json'),b.p.TOOL,Path(ct.DEP)];out=dict(scope='One globally shared outer mass per fixed atomic input; common finite-node constraints and one fixed receiver box; diagnostic K1, finite future, conditional Zall; no continuumFIRST/history/L1 or global budget.',epsilon_old=str(OLD),epsilon_final=str(epsilon),epsilon_selection=dict(common_interval_both_grids=[lo,hi],closure_optimum=closure,rule=choice,rational_value=float(epsilon),relative_loss_to_closure=1-value(obj,float(epsilon))/closure['value']),physical_inputs={str(n):{k:str(v) for k,v in c.items()} for n,c in b.INPUTS.items()},s=str(b.S),a='1/2',b='1',R='1',selector='same fixed f at every receiver; L(x)=2||x-r||infinity; q=qbase+epsilon*p_y; actual Lplus/j/Hhat recomputed',calibration_and_light=single,grids=grids,box_certificates=cert,budget=dict(n4_grid_nodes=706,light_points=3,global_final_masses=1,receiver_boxes=1,interval_N=[128,256],prescreen_seconds_cap=120),inputs={str(z):hashlib.sha256(z.read_bytes()).hexdigest() for z in dependencies},local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},limitations=['Receiver grid integrals and epsilon constraints are numerical, not continuum receiver enclosures.','One final rational epsilon is shared by all n4 receivers and used in the one certified box.','The same chosen epsilon is also evaluated at two n16 pressure points; infeasibility there is not repaired by a new mass.','Outer atom and completion are atomic, including a current hard face; no L1/history/FIRST transfer.','Polynomial I/Cb formulas are valid only in the common active region; infeasible evaluations are explicitly diagnostic.','No source/completion mass refitting, extra receiver search, or exponent fitting.'],runtime=dict(prescreen_seconds=round(screen,3),total_seconds=round(time.monotonic()-start,3),python=sys.version))
 (HERE/'outer_mass_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(epsilon_final=str(epsilon),selection=out['epsilon_selection'],grids=[dict(order=g['order'],**g['summary']) for g in grids],calibration=[dict(n=z['coefficients']['n'],x=z['coefficients']['x'][:2],interval=z['coefficients']['epsilon_interval'],final_feasible=z['final']['feasible']) for z in single],certificates=[dict(N=z['N'],certified=z['all_requested_gates_certified'],checks=z['checks'],I=z['partial_outer_receiver_integral'],Cb=z['partial_outer_companion_integral']) for z in cert],runtime=out['runtime']),indent=2))
if __name__=='__main__':main()
