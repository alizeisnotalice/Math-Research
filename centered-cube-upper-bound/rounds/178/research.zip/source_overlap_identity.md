# R178：共同接收半径的 source-overlap 身份与常数 35 包络

本稿只证明一个一般输入可用的物理核工具及其原三点接口，不证明原 lowcapture 的总预算。已读 R178 合同、冻结 R175 CJ1–11、R177 OT 与 EF5–11；核常数先独立推导后送审。固定来源中心时的接收坐标积分使用核本身的乘积结构，不假设来源坐标独立。F、C 从不概率化。只修改本文件，不 Git/spawn/PDF。

## SO1. 定义、单位与实际参数范围

h=1[-1/2,1/2]，w(r)=∫₀¹exp(−|r|/a)da，φ=h*w，F=max(h,φ)，C=h*F。此 a 仅是 dummy。h,w,φ 的积分为1；w≤1，所以 φ≤1，F 在闭区间 [-1/2,1/2] 等于1，在外部等于φ。F,C 偶且随 |r| 非增，0<C≤1，C(0)=1；但 ∫F=∫C>1，后文不将它们当概率核。

记 h_λ(r)=λ^(−1)h(r/λ)，φ_λ 同理。对固定 b>0、共同物理 L∈[b/2,b] 置 λ=L/b。原 softreceiver 为 P_{s,L}=∏b_{s,L}，b_{s,L}=(1−s)h_L+sφ_L，s∈[0,1]；原 J_b(x−v)=b^(−n)∏φ((xᵢ−vᵢ)/b)。本稿的主包络允许 L=L(x)、s=s(x)任意可测，但要求 b 和来源中心 y,v 在该次 dx 积分内固定。原 b 若随 x 变化，不能免费适用该结论。

## SO2. 一维收缩 overlap：保留定量 r(λ)<1

定义

\[
r(\lambda)={\sinh(\lambda/2)\over\lambda\sinh(1/2)},
\qquad\tfrac12\le\lambda\le1.
\tag{SO2}
\]

准确比较是

\[
\boxed{h_\lambda*w\le r(\lambda)F,
\qquad q_\lambda:=h_\lambda*\phi\le r(\lambda)C.}
\tag{SO3}
\]

证明分内外，不跨硬面使用错误的光滑导数。

若 |r|≤1/2，偶递减 w 的中心区间平均最大在0，且随窗口长度下降。因此 h_λ*w(r)≤h_{1/2}*w(0)=4∫₀^{1/4}w(t)dt。对 0≤t≤1/4，w(t)≤e^(−t)≤1−t/2（可由 e^(−t)≤1−t+t²/2 得到），故此平均≤15/16。另一方面 sinh(λ/2)≥λ/2；sinh(1/2) 的正级数相邻项比≤1/24，故 sinh(1/2)≤(1/2)/(1−1/24)=12/23。因此 r(λ)≥1/[2sinh(1/2)]≥23/24>15/16。在此区间 F=1，所以 SO3 第一式成立。

若 r>1/2，对每个 0<a≤1，整个平均区间在正半轴，直接积分给

\[
{(h_\lambda*e^{-|\cdot|/a})(r)\over
 (h*e^{-|\cdot|/a})(r)}
={\sinh(\lambda/(2a))\over\lambda\sinh(1/(2a))}
\le r(\lambda).
\tag{SO4}
\]

最后一步：t coth t 严格递增，因为其导数=(sinh t cosh t−t)/sinh²t>0；因此 log[sinh(λt)/(λsinh t)] 对 t 的导数 λcoth(λt)−coth t≤0，而 t=1/(2a)≥1/2。对 a 作非负积分得到 h_λ*w≤r(λ)φ=r(λ)F。负半轴由偶性，闭硬面已由内区间处理。再与 h 卷积，利用 φ=h*w、C=h*F 的 Tonelli/结合律，即得第二式。这里无 λ^(−1) 的粗放大费。

## SO3. r 的严格衰减及全部常数

对 t≤1/2，正级数给 sinh t≤24t/23，而

t cosh t−sinh t=∫₀ᵗu sinh u du≥t³/3。

因此

\[
{d\over d\lambda}\log r(\lambda)
=\tfrac12\coth(\lambda/2)-\lambda^{-1}
\ge{23\lambda\over288}.
\]

因 r(1)=1，

\[
-\log r(\lambda)\ge{23(1-\lambda^2)\over576}
\ge{1-\lambda\over17},
\qquad\tfrac12\le\lambda\le1.
\tag{SO5}
\]

后一不等式用 23(1+λ)/576≥23/384>1/17。没有拟合指数或数值常数认证缺口。

## SO4. 真正支付自适应共同 L(x) 的径向 envelope

令 H_λ^{(n)}(z)=λ^(−n)1_{|z|∞≤λ/2}。其共同半径上包络具有准确 layer-cake：

\[
E_n(z):=\sup_{1/2\le\lambda\le1}H_\lambda^{(n)}(z)
=H_1^{(n)}(z)+n\int_{1/2}^1H_\lambda^{(n)}(z){d\lambda\over\lambda}.
\tag{SO6}
\]

具体在 |z|∞≤1/2 时，令 r₀=max(1/2,2|z|∞)，右端=1+n∫_{r₀}¹λ^(−n−1)dλ=r₀^(−n)，恰为左端；外部均为0。闭面取值不造成漏项。

固定 d∈Rⁿ，非负 Tonelli 和核乘积结构给

\[
\begin{aligned}
\int E_n(z)\prod_i\phi(z_i-d_i)dz
&=\prod_iq_1(d_i)+n\int_{1/2}^1\prod_iq_\lambda(d_i){d\lambda\over\lambda}\\
&\le\left[1+n\int_{1/2}^1r(\lambda)^n{d\lambda\over\lambda}\right]\prod_iC(d_i)\\
&\le35\prod_iC(d_i).
\end{aligned}
\tag{SO7}
\]

最后一步完整计费为 n∫r(λ)^n dλ/λ≤2n∫_{1/2}¹e^(−n(1−λ)/17)dλ≤34。常数35与 n、d 无关；没有先逐坐标选择不同半径，没有使用 ∫sup≤sup∫ 的错误交换，也没有支付 2ⁿ 或 n 个尺度菜单。

恢复物理单位，**任意 measurable L(x)∈[b/2,b]** 均有

\[
\boxed{\int h_{L(x)}^{\otimes n}(x-y)J_b(x-v)dx
\le35b^{-n}\prod_iC((y_i-v_i)/b).}
\tag{SO8}
\]

证明是在 dx 内先用 b^(−n)E_n((x−y)/b) 点态支配 receiver 核，再应用 SO7；不是把 adaptive L 冻结后免费取上确界。所有额外 [0,1] masks、实际唯一 j 的不相交分割只减小该左端。

## SO5. 原 current-hard-core 分支及一份阈值分母

令 m_x(y)=#{i:|xᵢ−yᵢ|>L(x)/2}。在 m_x(y)=0 的真实分支上，因为 b_s≤1，

\[
1_{m_x(y)=0}P_{s(x),L(x)}(x-y)
\le h_{L(x)}^{\otimes n}(x-y).
\tag{SO9}
\]

所以 SO8 对左端换成 1_{m=0}p_y 仍成立，允许任意共同 measurable s(x)，不用软度菜单或输入特殊性。

原阈值单坐标权重记 a_ξ(C)=min(1,C/ξ)，其中 0<ξ≤1；w_t=∏a_{ξ_t}(C_i)。对任意两个合法 ξ_t,ξ_g，允许它们依 x 变化，

\[
C_i{a_{\xi_t}(C_i)\over a_{\xi_g}(C_i)}
\le{C_i\over a_{\xi_g}(C_i)}
=\max(C_i,\xi_g)\le1.
\tag{SO10}
\]

固定 b,y,v 时 C_i=C((yᵢ−vᵢ)/b) 与 x 无关，故 w_t/w_g≤1/∏C_i 点态成立。代入 SO8–9 得一份分母的实际 overlap 预算

\[
\boxed{\int1_{m_x(y)=0}p_yJ_b(x-v)
 {w_t(y,v)\over w_g(y,v)}dx\le35b^{-n}.}
\tag{SO11}
\]

该式准确支付一份 w_g^(−1)；不声称支付 w_g^(−2)，也不将其应用于不同 b(x) 产生的 C_i(x)。R177 k_delta 低overflow补集一般包含 1≤m<k_delta，SO11只涵盖其中 m=0 的明确子支。

## SO6. 两个固定内来源的三点 overlap 与尚缺的乘积容量

因 φ≤1，固定 L,b,y,v,u 时每坐标

\[
\int h_\lambda(r)\phi(r-d_v)\phi(r-d_u)dr
\le r(\lambda)\min(C(d_v),C(d_u)).
\tag{SO12}
\]

先分别丢一份≤1的 φ，再用 SO3 即得。对同一共同半径 envelope 用 SO6，获得真正 adaptive L 的三点上界

\[
\int h_{L(x)}^{\otimes n}(x-y)J_b(x-v)J_b(x-u)dx
\le35b^{-2n}\prod_i\min(C_{vi},C_{ui}).
\tag{SO13}
\]

同样可替 receiver 为 1_{m=0}p_y，允许任意 s(x)。然而乘两份 w_t/w_g 比值至多只能由此推出

\[
35b^{-2n}\prod_i{1\over\max(C_{vi},C_{ui})},
\tag{SO14}
\]

这个剩余因子可很大；SO13 没有同时提供 ∏C_vi C_ui。不能把 min 换为乘积，也不能视来源 u,v 为独立平均后删除 SO14。原 EF10 中甚至只有 J_v，而 u 槽主要通过 w_t、bad/history 和 e_t 相关；因此 SO13不能凭空给它添加一份已归一的 J_u。

## SO7. 低overflow 与 mixed-soft 来源的精确张量接口

为保留 m 而不先枚举异常坐标支付 binomial 菜单，固定本节所有 s,L,b,y,v,u。置 d_vi=(vᵢ−yᵢ)/b，d_ui 同理，p_{s,λ}(r)=λ^(−1)b_s(r/λ)，并定义真实一维积分

\[
A_i=\int_{|r|\le\lambda/2}p_{s,\lambda}(r)\phi(r-d_{vi})\phi(r-d_{ui})dr,
\quad
B_i=\int_{|r|>\lambda/2}p_{s,\lambda}(r)\phi(r-d_{vi})\phi(r-d_{ui})dr.
\tag{SO15}
\]

A_i≤r(λ)min(C_vi,C_ui)；B_i 是 s∫outside φ_λφ_vφ_u，必须保留。对整数 k≥1，准确有限生成函数身份是

\[
\int1_{m_x(y)<k}p_yJ_vJ_udx
=b^{-2n}\sum_{j=0}^{k-1}[z^j]\prod_i(A_i+zB_i).
\tag{SO16}
\]

超过 n 的系数视为0。只取一个内来源时删去 φ_u，右端单位改为 b^(−n)，同一身份成立。它是物理 receiver 乘积积分的恒等式，不是来源坐标独立假设；[z^j]记准确系数，不是把每个异常子集另收一份 uniform 常数后省掉二项式数量。

也可准确复用 R177 latent soft 标签：

P_{s,L}=∑_E s^{|E|}(1−s)^(n−|E|)P_{E,L}，

其中权重总和1；hard坐标不承载 strict overflow，所以在联合 kernel-f 后验支持上 m≤|E|。但是低overflow m<k **不推出** |E|<k，不能只保留小 soft 子集。对正三点积分可先按原权重整体 Tonelli，再保留每个标签的真实 overlap 和 m 门；没有合法依据把权重总和1换成“所有标签统一具有 hard overlap 界”。SO16对 fixed s,L 准确；若 s,L 随 x 变化，不能再将其系数冻结后张量积分，只有 SO8–13 已实际处理了相应 m=0 子支的选择费。

mixed 卷积的另一准确形式是 b_{s,L}=h_L*[(1−s)δ₀+s w_L dz]。故 fixed s,L 的 p_y overlap 是对同一个真实位移概率核 W_{s,L}^{⊗n} 的 hard-center overlap 混合，而

\[
(h_\lambda*\phi)(d)\le r(\lambda)C(d),\quad
(\phi_\lambda*\phi)(d)\le r(\lambda)(w_\lambda*C)(d).
\tag{SO17}
\]

第二式保留 soft 位移卷积，不免费改成 C(d)。当 s,L 自适应时 W 也依 x，不能先把它当固定来源测度再套 SO8；这正是 m≥1 补集仍待联合几何支付的一部分。

## SO8. 精确回代 EF10 的位置与全部原费用

原 EF10 在 growth/baseline 拆分后剩余 p_yρ_v²J_v/(9Q_v²)·w_t(y,v)w_t(y,u)/e_t(y)²，连同全部 same-alpha、bad、good、R_eta、source/history、唯一 j 和原 Pi 支持。SO11 控制的是 core 中 p_yJ_v·w_t/w_g 的实际 dx 积分。把完整 EF10 精确写为这个已估物理因子乘

\[
M\,{\rho_v^2w_g(y,v)\,w_t(y,u)\over9Q_v^2e_t(y)^2}
\tag{SO18}
\]

是允许的，但该剩余乘子依 x,y,u,v,t，含原非线性 same-alpha 与来源归一；尚未证明它在 overlap 积分下有合适总价格。若当前式另带 Duhamel 增长密度 T_j(x−y)、baseline K0_y 或原 CJ1 的第二份 p_y，亦须完整保留，不能把它们当≤1门删去。SO11 的 35b^(−n) 不是原 companion 的 W_beta 预算。

另外，本稿所有主列积分固定 b。若原真实 b=b(x) 或来源中心/窗口选择随 receiver 分支改变，必须保留该参数及实际 j/history。对预定有限 b_j 菜单可逐 j 用 SO8，但准确价是 ∑_j35b_j^(−n)∏C((y−v)/b_j)，不能只因 j(x)唯一而把不同归一核各自的全空间积分免费合成一次35。固定 b 的 unique-j masks可直接并入一个≤1门，这两种情况不同。

原模型的量词依修正后的 R178 合同（已由父级核 R128 RT4）明确如下：固定 (omega,V,j,y,t) 时，nu、Z_t、w_t、e_t 和 Pi_t 均先于 receiver 构造，独立于 x；在对 receiver-dependent gates 作合法正支配后，可以把这些固定来源测度移到 dx 外，不能把它们误称为 x 自适应障碍。Pi_g 则不同：终端 g、w_g、当前 s,L、A、RC alpha 以及接收点相关的原 history/good/rho 门仍依 x，不能一起冻结。SO18 中固定的 w_t/e_t 因子可按此顺序保留在外；真正的分数核、终端乘子和增长密度没有因此得到所需列积分。对共同 ∑_Vβ_V≤f 的使用也须在同一个核与来源条件下先合并；不能逐 V收35后忘记总来源费用。C,F 从未归一，b^(−n)、b^(−2n)和一份/两份阈值分母的差别都保留。

本轮得到真正的 uniform-in-n、已支付 adaptive-common-L 两点/三点物理包络 SO8/SO13，以及任意软度 current-hard-core 的单分母工具 SO11。它不是特殊输入界，也不是新的未知后验矩门。一般 lowoverflow m≥1、原反核/归一乘子及原所有来源槽尚未闭合，不领取原 EJ 的根价，不重复消费既有 εreceiver 或负信用。完成有界证明后停止，全文交独审绑定。
