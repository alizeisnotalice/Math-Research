from pathlib import Path
import argparse,hashlib,json,subprocess,sys,shutil
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args();root=Path(__file__).resolve().parent
for name,digest in json.loads((root/'inventory.json').read_text()).items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('archive inventory verified')
if not a.verify_only:
 if not a.output_dir: p.error('--output-dir required for replay')
 a.output_dir.mkdir(parents=True,exist_ok=True)
 if any(a.output_dir.iterdir()):raise RuntimeError('Replay directory must be empty')
 for name in ('outer_mass_probe.py','overlap_checks.py','task_contract.md'):shutil.copy2(root/name,a.output_dir/name)
 for stem in ('outer_mass_probe','overlap_checks'):
  subprocess.run([sys.executable,str(a.output_dir/(stem+'.py'))],check=True,stdout=(a.output_dir/(stem+'.stdout')).open('w'))
  before=json.loads((root/(stem+'.json')).read_text());after=json.loads((a.output_dir/(stem+'.json')).read_text());before.pop('runtime',None);after.pop('runtime',None)
  assert before==after,stem
  print(stem+': all non-runtime output fields match')
