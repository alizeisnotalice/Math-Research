# R178：当前 L-core 的全软度稀疏越界联合积分与实际付款

本稿证明一个不需软度下界 s0 的原正交通分支：外来源 y 相对当前 L(x)-硬立方体只在少数坐标越界时，保留真实 receiver 积分，原 J-share 正 raw 有显式 C sqrt(n) W_beta 价格。该结论可限制到 R175 low-capture、R_eta 和 R177 OT 尾支的补集，不改 same-alpha 或来源。与 R167 已付的 b-core、s≥s0 分支不同，下面的缺口和常数不依 s0，并且无需 soft 网格。一般中间/稠密越界补集仍未支付。

## 1. 定理及常数

沿原共同窗口 0<a≤L,R≤b≤2a，令

\[
\rho_*=1-2^{-34},\quad A=\rho_*^{1/4},\quad
d=-\log A>0,\quad B=36,\quad
T=\log(4eB/d),\quad \eta={d\over4T},\quad
m_0(n)=\lfloor\eta n\rfloor.
\tag{LG1}
\]

这些是绝对常数，不是原 rho_v、alpha、外 hard 来源或时间窗。仅作量级解释，d 约为 1.46×10^(−11)，eta 约为 1.18×10^(−13)，属于极保守的常数；证明与阈值均使用 LG1 精确值，不依赖这些小数。定义当前尺度的真实越界数

\[
m_L(x,y)=\#\{i:|x_i-y_i|>L(x)/2\},\qquad
\mathcal S_L=\{m_L(x,y)\le m_0(n)\}.
\tag{LG2}
\]

**定理。** 对原输入、任意原合法正截断和原 receiver 软度选择 s(x)，有

\[
\boxed{\operatorname{Raw}^{J,+}[\mathcal S_L]
\le C_{\rm cur}\sqrt n\,W_\beta,}
\tag{LG3}
\]
\[
C_{\rm cur}=96\Lambda(K/3)^{1/4}e^{3/4}\log2
\left({5\over ed}\right)^{5/2},\qquad\Lambda=128/119.
\tag{LG4}
\]

这是很大的显式常数，但与 n、s、来源质量、来源位置及自适应尺度无关。可直接取原 low-capture∩R_eta∩{m_L<k_delta} 与本支交集；对前轮已付支先作不交化即可，价格不变。它没有宣称全部 low-overflow 已落入本支，也没有支付母 raw 的其他 kernel share。

## 2. 原固定辅助时间合同及换序范围

本轮合同已由父级回查原文修正：冻结 R128 proof.md RT4 后约650行明确，固定 (omega,V,j,y,t) 后的 nu_V、Z_(j,V,y,t)、w_t、e_t 与 Pi_t 在接收点前构造，不依 x 或外 hard 来源。R167 exterior_geometry.md §5 已按此原接口核过正上界后的 Tonelli。

不可据此移出的仍是 terminal g(x)、Z_g/D_g/S_g、w_g、原 A、当前 s,L、RC alpha、history 等。下面先对这些依 x 的量作明确正上界，再移动固定辅助 t 的原 Pi_t；从不把 Pi_g 当作固定来源测度，也不改 e_t、Z_t 或 nu。原 e_t>0 的可定义辅助时间域外取零延拓，不创造新的 posterior。

相关冻结定位：

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md，RT4、RT13。
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round167_20261016_final_checkpoint/exterior_geometry.md，X3–X4 与 §5。

本稿的核乘积只来自物理 receiver 核及 Lebesgue dx，不假设 nu、beta 或 Pi 的坐标独立。

## 3. 两个全来源一维积分

归一 b=1，lambda=L/b∈[1/2,1]，X=(x_i−y_i)/b，D=(v_i−y_i)/b。F=max(h,phi)，其中 phi≤1，故 F=h=1 在硬区间内部、F=phi 在外部。置

\[
F_\lambda(X)=\lambda^{-1}F(X/\lambda),\qquad
H_{\lambda,D}(X)=F_\lambda(X)^{3/4}
\left({\phi(X-D)\over C(D)}\right)^{1/4}.
\tag{LG5}
\]

### 当前硬区间内：与 s 无关的严格缺口

冻结 RT13 给任意长度 lambda∈[1/2,1] 的实区间 I：

\[
\lambda^{-1}\left(\int_I\sqrt\phi\right)^2
\le\rho_*\int_I\phi.
\tag{LG6}
\]

其适用范围是任意区间位置，不是有界来源位移。该初等缺口来自 phi 的全局 log-Lipschitz 常数4、远离零时负 log 斜率≥1/96；在 I 内取长度 lambda/8 的两段，sqrt(phi) 的值差至少 2^(−14) 倍其区间最大值，方差公式给缺口 2^(−34)。本稿只使用这个已经核验的物理核引理，不使用 RT128 的 s=0 扩展付款。

在 |X|≤lambda/2 上，F_lambda=1/lambda。令 I 为以 D 为中心、长 lambda 的区间。再作一次 Cauchy 得

\[
\begin{aligned}
\lambda^{-3/4}\int_I\phi^{1/4}
&\le\lambda^{-1/4}\left(\int_I\sqrt\phi\right)^{1/2}\\
&\le\rho_*^{1/4}\left(\int_I\phi\right)^{1/4}
\le A C(D)^{1/4}.
\end{aligned}
\]

最后一步用 I⊂[D−1/2,D+1/2] 和 phi≤F。因此

\[
\boxed{\int_{|X|\le\lambda/2}H_{\lambda,D}(X)dX\le A<1.}
\tag{LG7}
\]

这里严格缺口不来自 soft 质量 s，而来自当前硬区间上的真实 phi 形状。

### 外部坐标：任意距离的统一有限费用

使用全位置物理界（以下也给出其初等核验）

\[
C(D)\ge c_0{e^{-|D|}\over1+|D|},\quad
\phi(X)\le3{e^{-|X|}\over1+|X|},\quad
c_0={7\over24}(1-e^{-1})^2.
\tag{LG8}
\]

三角不等式给

\[
{\phi(X-D)\over C(D)}\le{3\over c_0}(1+|X|)e^{|X|}.
\tag{LG9}
\]

在 current-core 外 F_lambda=phi_lambda，且 lambda≥1/2、lambda≤1、phi 偶单调，故 F_lambda(X)≤2phi(X)。于是

\[
\begin{aligned}
\int_{|X|>\lambda/2}H_{\lambda,D}(X)dX
&\le6^{3/4}(3/c_0)^{1/4}
\int_{\mathbb R}{e^{-|X|/2}\over\sqrt{1+|X|}}dX\\
&\le4\,6^{3/4}(3/c_0)^{1/4}<36=B.
\end{aligned}
\tag{LG10}
\]

最后常数可不用小数：e>5/2 给 c0>21/200>8/81，而四次方比较表明 c0>8/81 足以推出严格 <36。没有对来源位移 D 取未知范数或距离截断。

LG8 的简短自证：w(t)=∫_0^1 exp(−t/a)da 满足 w(t)≤exp(−t)/(1+t)，由对 a exp(−t/a) 积分分部即得；也满足 w(t)≥exp(−t)/(t+2)，由代换 z=1/a−1 后 (1+z)^(−2)≥exp(−2z) 得。phi 在 |X|≥1/2 的尾公式及 a(1−exp(−1/a))≤1−e^(−1) 给 phi(X)≤2sinh(1/2)exp(−|X|)/(|X|+1/2)≤3exp(−|X|)/(1+|X|)；内区间用 phi≤1。C 偶单调，且 C(1)=∫_0^1 a²(1−exp(−1/a))²da≥c0。对 |D|≥1，C(D)=∫_0^1[2a sinh(1/(2a))]²exp(−|D|/a)da≥w(|D|)，足以给 LG8 的 C 下界；|D|≤1 用 C(D)≥C(1)。

## 4. 固定来源的联合 dx 积分与组合费用

对任意固定真实 y,v，将 n 个坐标的 LG7/LG10 乘积积分，恰有 r 个越界坐标的积分至多 A^(n−r)B^r。故

\[
\int_{m_L(x,y)\le m_0}
\prod_iF_L(x_i-y_i)^{3/4}
\left({J_b(x-v)\over\prod_iC((y_i-v_i)/b)}\right)^{1/4}dx
\le A^n\sum_{r=0}^{m_0}{n\choose r}(B/A)^r.
\tag{LG11}
\]

此处 F_L 是相应一维缩放，J_b=P_(1,b)。缩放的核总次数为一，恰与 dx 抵消，不留 b^n。

令 H(eta)=−eta log eta−(1−eta)log(1−eta)。因 m0≤eta n，带权二项和的正生成函数界给

\[
\sum_{r\le m_0}{n\choose r}(B/A)^r
\le\exp\{nH(\eta)+\eta n\log(B/A)\}.
\]

例如取 z=eta/[(B/A)(1−eta)]<1，用 z^r≥z^(eta n) 证明，不漏额外 n 层数。又

\[
H(\eta)+\eta\log(B/A)
\le\eta\log(eBe^d/\eta)
=\eta(T+\log T+d)\le2\eta T=d/2.
\]

这里 0<d<1、T>1，log T+d≤T。因此

\[
\boxed{\text{LG11 左端}\le e^{-dn/2}.}
\tag{LG12}
\]

## 5. 原自适应 L 的真实价格；无需 s 网格

在 [a,b] 取向上相邻比≤exp(1/n) 的网格，含 b 端点，节点数 N_L≤n+2。对原 L 取上节点 L'。物理一维 b_s 偶单调，故

\[
P_{s,L}(x-y)\le eP_{s,L'}(x-y)
\le e\prod_i F_{L'}(x_i-y_i).
\tag{LG13}
\]

同时 m_(L')(x,y)≤m_L(x,y)，所以原稀疏域被对应网格稀疏域包含。LG12 遂给实际选择器的统一联合积分

\[
\int_{\mathcal S_L}
p_y^{3/4}\left({J_b(x-v)\over C_{prod}(y,v)}\right)^{1/4}dx
\le e^{3/4}(n+2)e^{-dn/2}.
\tag{LG14}
\]

左侧 s(x)、L(x) 可以自适应。这里 P_s≤product F 的包络在同一个坐标上区分 current hard/soft 区域，保留了 LG7 的缺口；没有先对倒 K0 或倒 Q 取 supremum。没有 soft 网格、soft 层数或 s0 的费用。

## 6. 接回原 good、Pi、hard 与全部来源

原 J-share A_v=1_good rho_v chiJ_v，chiJ=J/(3Q)。同一个实际 alpha 所定义 rho 保留，正上界只用 0≤rho≤1。good 给 p w_g≤KQ，因而

\[
p_y A_v\le\min\{p_y,KJ_v/(3w_g(y,v))\}
\le(K/3)^{1/4}p_y^{3/4}[J_v/w_g(y,v)]^{1/4}.
\tag{LG15}
\]

原 c_jg/b≤1 且 0<C_i≤1，故 w_g≥C_prod。代入 LG14 后，右侧的 x 积分对每个原固定 y,v 均一致有界。原 bad u、FA、rho、history 以及 terminal 支持门均可正放松；并不是重新选择或独立化这些对象。

先用一次原 q^(−1)∫h_R a_history dnu≤16/3 去掉 hard 来源（本分支只依 x,y）。再用原 delta_+≤n；固定原 omega,V,j,y,t 后，按第2节的原合同移出 Pi_t(dv)Pi_t(du)，先作 x 积分再用两份原 posterior 概率质量≤1。去掉依 x 的 far 门后，实际时间域正扩大至固定 j 的共同窗口 ξ=c_j t/b∈[1/2,1]，即 [b/(2c_j),b/c_j] 与原可定义域的交集；其 dt/t 长度≤log2。并非声称整个 I_(j,V,y) 都有此长度；可定义域外或 e_t=0 时取零 subprobability。这里没有对 Pi_g 换序。

安全 j 菜单数 N_j≤n+2，本稿确实支付它，不把依 j 的放松误当唯一 j 免价。其余原期望、V 和 beta 聚合成 W_beta=E sum_V||beta_V||。于是完整费用为

\[
\operatorname{Raw}^{J,+}[\mathcal S_L]
\le {32\Lambda\over3}(K/3)^{1/4}e^{3/4}\log2\,
n(n+2)^2e^{-dn/2}W_\beta.
\tag{LG16}
\]

hard16/3 与 outer2Lambda 各一次；log2 是实际辅助时间费用，两个 n+2 分别为 L 网格及 j 菜单，另一个 n 来自 score。没有重用负信用。最后 n+2≤3n，且

\[
n^{5/2}e^{-dn/2}\le(5/(ed))^{5/2},
\]

证明 LG3–4。原共同窗口以外的额外块/history 若另有聚合要求，仍沿原账，不能凭本稿免费增加。

## 7. 与原 OT 尾支互补后的真实覆盖

对原 low-capture 交通先用 R177 OT 支付 m_L≥k_delta，再在其补集内支付本稿 m_L≤m0；可与更早已付区域逐次不交化。最后仍保留

\[
m_0(n)<m_L(x,y)<k_\delta(n,s(x)),
\tag{LG17}
\]

以及其他未处理母 kernel share。没有把 m_L 认成原 k_t，也没有宣称 LG17 一般为空。

有一个明确的小软度覆盖推论，不需新 selector：在原 s(x)≤eta/4 的范围，原单侧 FIRST 的 latent mgf 取 theta=log2，给

\[
q^{-1}\int_{m_L>m_0}p_y f(y)dy
\le\exp[-a_0n],\qquad a_0=(\log2-1/4)\eta>0.
\tag{LG18}
\]

因为 m0+1>eta n，而 (1−s+2s)^n≤exp(ns)≤exp(eta n/4)。沿 R177 完整原 raw 的正松弛（A≤1、score≤n、time≤log2、原唯一 j、sum beta≤f），整个这个小软度范围于是有

\[
\operatorname{Raw}^{J,+}[s\le\eta/4]
\le C_{cur}\sqrt n\,W_\beta
 +B_0n e^{-a_0n}\,\mathbb E\int_{\{s\le\eta/4\}}q(x)dx,
\quad B_0={32\Lambda\over3}\log2.
\tag{LG19}
\]

这是原输入的显式费用，不是假定一个未知矩小。特别对任意 epsilon>0，只要

\[
n\ge {2\over a_0}\max\{1,\log[2B_0/(a_0e\epsilon)]\},
\tag{LG20}
\]

第二项系数≤epsilon，因 n exp(−a0n/2)≤2/(a0e)。LG19 在所有 n 均有效，但未满足 LG20 的维数不能把其 receiver 系数写成 epsilon；本稿没有藏入一个未展示的有限维费用。一般 s 范围仍有 LG17 的实际未付中间带。

最终结果是 current-L 稀疏越界这一全软度来源分支的真实根阶付款，以及它与原 OT 的准确互补关系。一般 centered-cube 弱型上界保持未证。完成本轮有界证明后停止，不扩大数值搜索或另造终点模型。
