# R178 shared outer-mass capacity

The original n4 traffic is strongly suppressed by the tiny outer atom mass2^-32. Increasing that one common mass, while retaining the physical coefficients and all finite future tests, increases the sampled original traffic by about3.86 million. The same-alpha response simultaneously reduces rho. The chosen n4 mass is invalid at both n16 pressure points, so this is a fixed-input capacity diagnosis, not a dimension-independent mechanism or global payment.

Run `python3 outer_mass_probe.py` from any directory. The script uses the frozen R176 physical evaluator and directed kernel runtime, records dependency hashes, and writes through HERE. Only epsilon changes. All nu atoms, completion mass/position, y/v/u positions, s=1/4, window[.5,1], R=1 and L(x)=2||x-r||infinity remain fixed. The same globally chosen f is used at every receiver. K=1 and Zall are diagnostic/conditional as before; no original history, continuumFIRST or L1 realization is added.

## Affine coefficients and constraints

At each fixed receiver, current q=qbase+epsilon*p_y. Good, U, Q, J, TDelta, the canonical core, Gamma, d and the sharp/cubic lowcapture threshold are independent of epsilon. Therefore

`alpha=alpha0+epsilon*p_y/Jnu`,
`rho_good=rho0-rho1*epsilon`,
`A_good=A0-A1*epsilon`

on the retained active range. The two-source posterior drop is independent of epsilon because nu and the source thresholds are fixed. The original outer atom traffic and companion are exactly, as algebraic functions of the physical coefficients,

`W_x(epsilon)=epsilon*p_y*drop*(A0-A1*epsilon)`,
`C_x(epsilon)=epsilon*p_y^2*drop/(n*J_good)*(A0-A1*epsilon)^2`.

No free coefficient array is introduced. These polynomial formulas are only used as actual integrals where the active gates hold; infeasible evaluations are separately labeled algebraic diagnostics and actual-integral fields are null.

The program retains each linear constraint from alpha>=0, original high, rho>0, every finite future menu entry including actual Hhat/Lplus, the original h_R hard cap, and epsilon>=0. The exact-current equality is identified symbolically. Coefficient evaluation and finite-grid intersections use floating arithmetic and are numerical evidence; only the final box has directed interval certification. Strict rho endpoints are recorded and optimization on their closure is explicitly marked.

## Three bounded stages

1. n4 x0: derive the quadratic/cubic and their admissible interval directly. Its epsilon upper bound is .00347808551848, imposed by rho>0. The original quadratic vertex is .00173904275924. Two n16 points, x0 and(.001,.002,...,.002), provide lightweight comparisons only.
2. Reuse exactly the original81/625 full Cartesian midpoint nodes on[-.005,.005]^4. The cells have real dx=(.01)^4/order^4. Intersect every node's constraints before optimizing one common mass. The integrated original objective is a concave quadratic, and the companion a cubic; compare their derivative roots and interval endpoints. There are no receiver-dependent choices of f or epsilon.
3. Choose only one final rational mass, from the order5 original-traffic vertex inside both grids' common feasible intervals. Validate this same f on the single predeclared Cartesian box B=[.001,.0011] times[.002,.0021]^3, volume10^-16, at N128/256. No new box or receiver search is used.

The unique final mass is

`epsilon=1048722049/582906503108 ≈ .0017991256632209753`,

about7.72719 million times the old mass. The reported numerical loss relative to the floating vertex rounds to0; this does not certify exact optimality of that rational value. The common grid interval is[0,.00307009222091), with the upper endpoint set by target rho at the positive corner of the order5 grid. Every sampled node is feasible at the chosen mass.

| Grid | Original traffic at old mass | Original at final mass | Gain | Companion at final mass |
|---|---:|---:|---:|---:|
|81 nodes|3.24125715e-21|1.24892053e-14|3.85320e6|2.12467380e-14|
|625 nodes|3.24087833e-21|1.25214354e-14|3.86359e6|2.13662378e-14|

These grid integrals include epsilon and true dx but have no certified receiver discretization error. For comparison, the order5 companion's own numerical optimum is epsilon≈.00120179236712, giving2.52630443e-14. This is only a polynomial optimizer report; no second physical mass or certificate is chosen.

## One-box certificate and actual source budget

Both N128 and N256 certify all requested physical high/good/core/profile/softness/j0/D1/future/h_R/lowcapture gates on B at the final mass. In particular, the second nu atom strictly fails good; the positive pair is the unchanged good-to-bad orientation. The exact FTC clock integral and Cartesian Jacobian1 from R176 are retained, including the completion's closed-current-hard-face selector identity.

At N256,

- epsilon integral_B I dx is in[1.1060049616960207e-22,1.1326162711883728e-22].
- epsilon integral_B Cb dx is in[1.6343654708707746e-22,1.7150273135641460e-22].

JSON preserves full directed endpoints. On B, alpha is in[2.249976,2.254275], good rho in[.1371225,.1400014], same-alpha mu_bad in[.000479657,.000481869], and actual outer tau_y in[.191794,.192426]. The latter was about3.07e-8 at the old mass. The sharp threshold remains M≈[2685.9999,2703.0743], while K0_bad/wg_bad≈[2.22390e-5,2.22921e-5], so the positive pair stays in the lowcapture complement throughout the clock. None of these same-alpha fractions is replaced by an independent source measure.

At x0, alpha rises from1.815656 to2.243307 and rho falls from.312429 to.150818. Thus the outer traffic is not simply multiplied by the mass ratio; the increase is reduced by the original shared-alpha reaction. Nu and its J-weighted source budget remain unchanged.

The same final mass fails the n16 pressure constraints. Their numerical admissible upper bounds are approximately2.7154e-6 and2.8581e-6, set by the s=1/4,H=.75 future test. The final mass also fails original high and positive rho. No n16 actual traffic or certified source-subprobability interpretation is assigned to those infeasible evaluations, and no replacement mass is selected.

The final run used 0.453 seconds of the120s prescreen budget and17.019 seconds overall. This finite experiment resolves the role of the old tiny outer mass on these n4 inputs. It does not integrate the other outer atoms, pay a j sum, extend the finite future menu to continuumFIRST, or overcome the atomic hard-face/history/L1 gaps.
