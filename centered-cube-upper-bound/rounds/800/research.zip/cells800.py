#!/usr/bin/env python3
"""Exact two-dimensional Lebesgue envelopes and one-count weighted peeling."""
import argparse
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import platform


C0=F(3,2)
GRID=F(1,2)
E=F(3,2)


def total(xs):
    return sum(xs,F(0))


def rect(x,u,y,v):
    return (F(x),F(u)),(F(y),F(v))


def gridbox(i,j):
    return rect(i*GRID,(i+1)*GRID,j*GRID,(j+1)*GRID)


def area(B):
    return max(F(0),B[0][1]-B[0][0])*max(F(0),B[1][1]-B[1][0])


def meet(A,B):
    return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B))


def hull(A,B):
    return tuple((min(a,c),max(b,d)) for (a,b),(c,d) in zip(A,B))


def mass(B,boxes):
    return total(area(meet(B,A)) for A in boxes)


def neighborhood(B,s):
    return tuple((a-s,b+s) for a,b in B)


def breakpoints(B,boxes):
    cuts={F(0)}
    for A in boxes:
        for (a,b),(c,d) in zip(B,A):
            for s in (d-b,a-c,c-b,a-d):
                if s>0:
                    cuts.add(s)
    return sorted(cuts)


def side_affine(core,source,sample):
    """The constant and linear coefficients of one true interval overlap."""
    a,b=core
    c,d=source
    upper=(d,F(0)) if d<=b+sample else (b,F(1))
    lower=(c,F(0)) if c>=a-sample else (a,F(-1))
    constant,linear=(u-l for u,l in zip(upper,lower))
    if constant+linear*sample<=0:
        return F(0),F(0)
    return constant,linear


def density_envelope(B,boxes):
    """Maximise every quadratic-over-square branch, including its exact tail."""
    cuts=breakpoints(B,boxes)
    tests=set(cuts)
    stationary=[]
    polynomial=[]
    for lo,hi in zip(cuts,cuts[1:]):
        probe=(lo+hi)/2
        coeff=[F(0),F(0),F(0)]
        for source in boxes:
            (a,b),(c,d)=[side_affine(v,w,probe) for v,w in zip(B,source)]
            coeff[0]+=a*c
            coeff[1]+=a*d+b*c
            coeff[2]+=b*d
        constant,linear,quadratic=coeff
        for s in (lo,hi,probe,(lo+3*hi)/4):
            actual=mass(neighborhood(B,s),boxes)
            calculated=constant+linear*s+quadratic*s*s
            assert actual==calculated
        slope=2*C0*quadratic-linear
        intercept=C0*linear-2*constant
        if slope:
            s=-intercept/slope
            if lo<s<hi:
                tests.add(s)
                stationary.append(s)
                proof=mass(neighborhood(B,s),boxes)
                assert proof==constant+linear*s+quadratic*s*s
        polynomial.append(dict(s_from=lo,s_to=hi,coefficients_constant_linear_quadratic=coeff,
                               derivative_numerator_constant_linear=(intercept,slope)))
    support_mu=total(area(b) for b in boxes)
    assert mass(neighborhood(B,cuts[-1]),boxes)==support_mu
    assert mass(neighborhood(B,cuts[-1]+1),boxes)==support_mu
    tested={s:mass(neighborhood(B,s),boxes)/(C0+s)**2 for s in sorted(tests)}
    prize=max(tested.values())
    witnesses=[s for s,v in tested.items() if v==prize]
    return dict(U=prize,initial=tested[F(0)],maximizing_radii=witnesses,
                maximizing_radii_strictly_inside_a_branch=[s for s in witnesses if s in stationary],
                candidates_with_true_value=[(s,v) for s,v in tested.items()],
                exact_polynomial_before_saturation=polynomial,
                tail_from=cuts[-1],tail_constant_true_numerator=support_mu)


def edge_gap(box,other):
    return max(abs((a+b-c-d)/2) for (a,b),(c,d) in zip(box,other))


def peel(a,edges,limit,denom_name):
    """Each first-deleted unordered edge is charged once, in both directions."""
    def row(active):
        h={i:F(0) for i in sorted(active)}
        for (i,j),D in edges.items():
            if i not in active or j not in active:
                continue
            h[i]+=a[j]/D[denom_name]
            h[j]+=a[i]/D[denom_name]
        return h

    w={(i,j):2*a[i]*a[j]/p[denom_name] for (i,j),p in edges.items()}
    active=set(range(len(a)))
    remaining=set(w)
    charged=set()
    original=total(w.values())
    assert original==total(a[i]*v for i,v in row(active).items())
    rounds=[]
    while True:
        degrees=row(active)
        low={i for i,v in degrees.items() if v<=limit}
        if not low:
            break
        lost={q for q in remaining if low.intersection(q)}
        inner={q for q in lost if set(q)<=low}
        fee=total(w[q] for q in lost)
        counted_from_degrees=2*total(a[i]*degrees[i] for i in low)-total(w[q] for q in inner)
        before_length=total(w[q] for q in remaining)
        after_length=total(w[q] for q in remaining-lost)
        cap=2*limit*total(a[i] for i in low)
        assert fee==counted_from_degrees==before_length-after_length<=cap
        assert not charged.intersection(lost)
        charged|=lost
        remaining-=lost
        active-=low
        rounds.append(dict(d_before=degrees,removed=sorted(low),physical_edges_first_charged=sorted(lost),
                           removed_directed_mass=fee,deleted_node_weight=total(a[i] for i in low),
                           allowed_delete_cost=cap,remaining_mass=after_length))
    remainder=total(w[e] for e in remaining)
    assert remaining|charged==set(w) and not (remaining&charged)
    paid=total(q["removed_directed_mass"] for q in rounds)
    assert paid+remainder==original
    assert remainder==total(a[i]*v for i,v in row(active).items())
    assert all(v>limit for v in row(active).values())
    return dict(K=limit,initial_directed_mass=original,stages=rounds,total_deleted_cost=paid,
                residual_directed_mass=remainder,final_vertices=sorted(active),final_degrees=row(active),
                unique_removed_unordered_edges=len(charged),unpaid_edges=sorted(remaining))


def calculate(name,coords,boxes,ratios,radius,threshold):
    assert all(area(B)>0 for B in boxes)
    assert all(area(meet(A,B))==0 for A,B in combinations(boxes,2))
    cells=[gridbox(*q) for q in coords]
    assert all(area(B)==GRID**2 for B in cells)
    mu=list(mass(B,boxes) for B in cells)
    assert min(mu)>0 and all(0<r<=1 for r in ratios)
    a=[m*r for m,r in zip(mu,ratios)]
    results=[density_envelope(B,boxes) for B in cells]
    edges={}
    near={i:[] for i in range(len(cells))}
    for i,j in combinations(range(len(cells)),2):
        gap=edge_gap(cells[i],cells[j])
        if not 0<gap<=radius:
            continue
        near[i].append(j)
        near[j].append(i)
        X=hull(cells[i],cells[j])
        envelope=density_envelope(X,boxes)
        end=max(results[i]["U"],results[j]["U"])
        with_hull=max(end,envelope["U"]/E)
        assert envelope["U"]>=end>0 and with_hull>=end
        edges[i,j]=dict(axis_aligned_hull=X,physical_center_gap=gap,hull_envelope=envelope,
                        denominator_endpoints=end,denominator_with_hull=with_hull,
                        improves_denominator=with_hull>end)
    assert all(near.values())
    if name in ("initial","pressure"):
        assert any(row["improves_denominator"] for row in edges.values())
    no_hull=[]
    full=[]
    for i in range(len(cells)):
        possible=[(j,edges[min(i,j),max(i,j)]) for j in near[i]]
        raw=total(a[j]/p["denominator_endpoints"] for j,p in possible)
        corrected=total(a[j]/p["denominator_with_hull"] for j,p in possible)
        assert corrected<=raw
        no_hull.append(raw)
        full.append(corrected)
    distinct=[dict(vertices=(i,j),neighbor_counts=[len(near[i]),len(near[j])],weighted_degrees=[full[i],full[j]])
              for i,j in combinations(range(len(cells)),2) if len(near[i])==len(near[j]) and full[i]!=full[j]]
    shared=[dict(vertices=(i,j),common_neighbors=sorted(set(near[i])&set(near[j])))
            for i,j in combinations(range(len(cells)),2) if set(near[i])&set(near[j])]
    reversals=[dict(less_neighbors=i,more_neighbors=j,neighbor_counts=[len(near[i]),len(near[j])],
                    weighted_degrees=[full[i],full[j]])
               for i in range(len(cells)) for j in range(len(cells))
               if len(near[i])<len(near[j]) and full[i]>full[j]]
    chosen_overlap=None
    for i,j in edges:
        radii=[results[v]["maximizing_radii"][0] for v in (i,j)]
        B,D=neighborhood(cells[i],radii[0]),neighborhood(cells[j],radii[1])
        mB,mD,m_inter=mass(B,boxes),mass(D,boxes),mass(meet(B,D),boxes)
        if m_inter>0:
            chosen_overlap=dict(vertices=(i,j),maximizing_radii=radii,
                                true_masses=[mB,mD],physical_overlap_mu=m_inter,
                                physical_union_mu=mB+mD-m_inter)
            break
    results_full=peel(a,edges,threshold,"denominator_with_hull")
    results_endpoint=peel(a,edges,threshold,"denominator_endpoints")
    for i,v in enumerate(full):
        assert v==total(a[j]/edges[min(i,j),max(i,j)]["denominator_with_hull"] for j in near[i])
    if name=="initial":
        assert results[0]["initial"]==F(1,9) and results[0]["U"]==F(1,8)
        assert full==[F(27,16)]*2 and no_hull==[F(2)]*2
        assert results_full["final_vertices"]==[] and results_endpoint["final_vertices"]==[0,1]
    if name=="pressure":
        assert results[0]["maximizing_radii_strictly_inside_a_branch"]==[F(1,2)]
        assert distinct and shared and chosen_overlap is not None
    if name=="expanded":
        assert results_full["final_vertices"] and shared
    return dict(stage=name,sources=boxes,reference_grid_indices=coords,physical_reference_boxes=cells,
                source_mass_each_reference=mu,a=a,reference_fractions_of_true_cell_mass=ratios,
                Chebyshev_center_gate=radius,
                neighborhoods=near,neighbor_counts=[len(near[i]) for i in range(len(cells))],
                actual_weighted_degrees=full,endpoint_only_degree=no_hull,
                same_cardinality_different_degrees=distinct,neighbor_count_order_reversals=reversals,
                overlapping_adjacency_neighborhoods=shared,
                true_overlap_of_maximizing_geometric_neighborhoods=chosen_overlap,
                per_reference_envelope=results,edge_envelopes=[dict(vertices=p,**q) for p,q in edges.items()],
                peel_true_kernel=results_full,peel_without_hull_counterpart=results_endpoint)


def suite():
    return [
      calculate("initial",[(0,0),(1,0)],[rect(0,1,0,"1/2")],[F(1),F(1)],F(1,2),F(7,4)),
      calculate("pressure",[(i,0) for i in range(6)],[rect(0,"11/4",0,"1/2")],
                [F(1,4),F(1,2),F(1),F(3,4),F(1,8),F(1)],F(3,2),F(3,2)),
      calculate("expanded",[(0,0),(1,0),(0,1),(1,1),(2,0),(3,0),(4,0),(5,0),(1,2)],
                [rect(0,1,0,1),rect(1,"11/4",0,"1/2"),rect("1/2",1,1,"11/8")],
                [F(1),F(1),F(1),F(1),F(1,4),F(3,4),F(1,8),F(1),F(1,2)],F(1,2),F(5,4)),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    data=suite()
    first=data[0]
    exact_edges={tuple(row["vertices"]):row for row in first["edge_envelopes"]}
    boundary=peel(first["a"],exact_edges,F(27,16),"denominator_with_hull")
    assert [row["removed"] for row in boundary["stages"]]==[[0,1]]
    assert list(boundary["stages"][0]["d_before"].values())==[boundary["K"]]*2
    assert boundary["final_vertices"]==[] and boundary["residual_directed_mass"]==0
    assert boundary["total_deleted_cost"]==F(27,32)
    record=dict(environment=dict(python=platform.python_version(),architecture=platform.machine()),
                scope=dict(n=2,lattice_side=GRID,denominator_translation=C0,hull_divisor_E=E,
                           sources="Lebesgue restricted to the actual supplied positive-area boxes",
                           a_C="fixed diagnostic fractions of each actual cell mass; not the full historical process",
                           graph="finite square cells at the stated Chebyshev center distances; diagnostic geometry without the historical common-middle and high-dimensional screens",
                           tail="the numerator is constant beyond the last true endpoint; derivative is strictly negative there",
                           fee="freeze the source measure and denominators, then delete vertices with d<=K. Surviving degrees are strictly above K. Each removed physical edge charged once in both directions.",
                           calculation="exact Fraction; all breakpoints and rational stationary points, direct area checks"),
                command="python -B cells800.py --check cells800.json",stages=data,
                equality_removed_two_vertex_regression=boundary)
    out=json.dumps(record,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(out)
    if args.check:
        assert args.check.read_text()==out
    if args.output or args.check:
        for s in data:
            account=s["peel_true_kernel"]
            print(s["stage"],"U(C0)",s["per_reference_envelope"][0]["U"],
                  "rounds",[r["removed"] for r in account["stages"]],
                  "survivors",account["final_vertices"],"full and residual",account["initial_directed_mass"],account["residual_directed_mass"])
        print("equality at K",boundary["K"],"removes both vertices",
              "charged",boundary["total_deleted_cost"])
        if args.check:
            print("byte-identical")
    else:
        print(out,end="")


if __name__=="__main__":
    main()
