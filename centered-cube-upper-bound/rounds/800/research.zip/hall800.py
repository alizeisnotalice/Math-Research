"""R800. Exact source allocation in physical intervals and certified dimension parameters."""
import argparse
import collections
from fractions import Fraction as Q
from itertools import combinations
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx
import sympy as sp


def width(interval):
    return max(Q(0), interval[1] - interval[0])


def intersection(*intervals):
    return max(x[0] for x in intervals), min(x[1] for x in intervals)


def midpoint(interval):
    return sum(interval, Q(0)) / 2


pieces = [(k + lo, k + hi, mass / (hi - lo))
          for k in range(-4, 8)
          for lo, hi, mass in [(Q(1,32), Q(1,16), Q(3,8)),
                               (Q(1,8), Q(5,32), Q(5,8))]]


def mass(interval):
    return sum((density * width(intersection(interval, (a,b)))
                for a,b,density in pieces), Q(0))


def subsets(items):
    for k in range(len(items)+1):
        yield from combinations(items, k)


def maxflow(source_mass, atoms, allowed, B):
    """Rational augmenting paths, with separate source types and Lebesgue cells."""
    m, n = len(source_mass), len(atoms)
    start, end = m+n, m+n+1
    cap = collections.defaultdict(Q)
    adj = [[] for _ in range(end+1)]

    def connect(i, j, value):
        adj[i].append(j)
        adj[j].append(i)
        cap[i,j] = value

    for i, demand in enumerate(source_mass):
        connect(start, i, demand)
    for i, options in enumerate(allowed):
        for j in options:
            connect(i, m+j, sum(source_mass, Q(0))+1)
    for j, a in enumerate(atoms):
        connect(m+j, end, B*width(a))
    while True:
        previous = {start: None}
        queue = collections.deque([start])
        while queue and end not in previous:
            i = queue.popleft()
            for j in adj[i]:
                if j not in previous and cap[i,j] > 0:
                    previous[j] = i
                    queue.append(j)
        if end not in previous:
            break
        path = []
        j = end
        while j != start:
            i = previous[j]
            path.append((i,j))
            j = i
        step = min(cap[e] for e in path)
        for i,j in path:
            cap[i,j] -= step
            cap[j,i] += step
    shipped = [cap[i,start] for i in range(m)]
    for i in range(m):
        assert sum((cap[m+j,i] for j in allowed[i]), Q(0)) == shipped[i]
    assert sum(shipped) == sum((cap[end,m+j] for j in range(n)), Q(0))
    return shipped


def scenario(name, lefts, rights, B):
    big = [(x,x+3) for x in lefts]
    small = [(x-2,x) for x in rights]
    parents = big + small
    b = [Q(1, 4096) * (1 + i % 3) for i in range(len(parents))]
    j = [b[i]*width(p) for i,p in enumerate(parents)]
    # Actual Lebesgue owners have the displayed masses, lie within the contracted parents.
    owners = [(midpoint(p)-j[i]/2,midpoint(p)+j[i]/2) for i,p in enumerate(parents)]
    assert all(width(intersection(p,q))==0 for p,q in combinations(owners,2))
    assert all(width(o)==z and z<=width(p)/32 for o,z,p in zip(owners,j,parents))
    assert all(mass(p)==width(p) for p in parents)
    sb = b[len(big):]
    full = cross = two_rest = two_served = Q(0)
    rows = []
    for index,A in enumerate(big):
        endpoints = sorted({A[0], A[1], *(x for u in small for x in u if A[0]<x<A[1])})
        atoms = list(zip(endpoints,endpoints[1:]))
        types = collections.defaultdict(Q)
        for a in atoms:
            omega = tuple(i for i,u in enumerate(small) if width(intersection(u,a))==width(a))
            if omega and mass(a)>0:
                types[omega] += mass(a)
        labels = sorted(types)
        source_mass = [types[w] for w in labels]
        allowed = [[k for k,a in enumerate(atoms)
                    if all(width(intersection(a, small[i]))==width(a) for i in w)] for w in labels]
        def deficit(indices):
            target = {k for i in indices for k in allowed[i]}
            return sum((source_mass[i] for i in indices),Q(0))-B*sum((width(atoms[k]) for k in target),Q(0))
        delta, worst = max((deficit(indices),indices) for indices in subsets(list(range(len(labels)))))
        shipped = maxflow(source_mass,atoms,allowed,B)
        assert delta==sum(source_mass)-sum(shipped)
        singleton = sum((max(Q(0),deficit([i])) for i in range(len(labels))),Q(0))
        m = width(A)
        active = sorted({u for w in labels for u in w})
        occupancy = sum((sb[u]*width(intersection(A,small[u])) for u in active),Q(0))/m
        assert occupancy>0
        B_local=B*max(1,1/occupancy)
        adapt = sum(source_mass)-sum(maxflow(source_mass,atoms,allowed,B_local))
        exact_adapt=max(sum((source_mass[i] for i in sub),Q(0))-
                        B_local*sum((width(atoms[k]) for k in {j for i in sub for j in allowed[i]}),Q(0))
                        for sub in subsets(list(range(len(labels)))))
        assert 0<=adapt==exact_adapt<=delta and B_local*occupancy==B*max(1,occupancy)
        d = sum((mass(intersection(A,u))*a/m for u,a in zip(parents,b)),Q(0))
        s = sum((shipped[i]*sum(sb[k] for k in w) for i,w in enumerate(labels)),Q(0))/m
        r = sum(((source_mass[i]-shipped[i])*sum(sb[k] for k in w) for i,w in enumerate(labels)),Q(0))/m
        comparison = B*sum((a*width(intersection(A,u)) for a,u in zip(sb,small)),Q(0))/m
        assert 0<=s<=comparison and 0<=r<=sum(sb)*delta/m and s+r<=d
        raw = sum((a*mass(intersection(A,u)) for a,u in zip(sb,small)),Q(0))/m
        assert s+r==raw
        full += j[index]*raw**2/d
        cross += 2*j[index]*s*r/d
        two_served += j[index]*s**2/d
        two_rest += j[index]*r**2/d
        rows.append(dict(t=A,left_class_masses=source_mass, labels=labels, source=sum(source_mass),
                         served=sum(shipped), delta=delta, singleton_shortfalls=singleton,
                         best_family=worst, degree=d, served_leg=s, residual_leg=r,
                         comparison_leg=comparison, eligible_occupancy=occupancy, local_B=B_local,
                         local_B_deficit=adapt, cut_checks=2**len(labels)))
    assert full==two_served+cross+two_rest
    return dict(name=name,B=B,parents=parents,physical_owners=owners,rows=rows,
                entire_original_peak=full,both_served=two_served,both_residual=two_rest,
                mixed_arms=cross, mixed_energy_check=(full<=2*(two_served+two_rest)))


def spike_tests():
    # One real central interval and two small intervals capture exactly the same unit of source.
    # Uniform Lebesgue occupancy is dominated by the broad intersection with the second arm.
    out=[]
    A=(Q(0),Q(3))
    for exponent in (12,16,20,24):
        eps=Q(1,2**exponent)
        source=[(Q(k),Q(k)+eps/2,2/eps) for k in range(-4,8)]
        def local_mass(iv):
            return sum((v*width(intersection((x,y),iv)) for x,y,v in source),Q(0))
        old=[(-2+eps,eps),(Q(-1),Q(1))]
        assert all(local_mass(iv)==width(iv) for iv in [A,*old])
        both=intersection(A,*old)
        assert local_mass(both)==1 and all(local_mass(intersection(A,u))==1 for u in old)
        weight=Q(1,4096)
        occupancy=sum((weight*width(intersection(A,u)) for u in old),Q(0))/width(A)
        B_local=4*max(1,1/occupancy)
        delta=max(Q(0),1-B_local*width(both))
        assert delta==1-sum(maxflow([Q(1)],[both],[[0]],B_local))
        out.append(dict(epsilon=eps,occupancy=occupancy,B_local=B_local,delta=delta))
    assert [row["delta"] for row in out[:3]]==[0,Q(16385,65537),Q(999425,1048577)]
    return out


def coarse_filter():
    A = (Q(0),Q(3))
    small = [(Q(-19,10),Q(1,10)),(Q(-9,5),Q(1,5))]
    all_boxes = [A,*small]
    bs = [Q(1,4096),Q(2,4096),Q(3,4096)]
    degree = sum((b*mass(intersection(A,u))/width(A) for b,u in zip(bs,all_boxes)),Q(0))
    result = []
    for grid in (Q(1,4),Q(1,8),Q(1,16)):
        cells = [(k*grid,(k+1)*grid) for k in range(0, int(1/grid))]
        records = []
        low = high = Q(0)
        for C in cells:
            if mass(C)==0:
                continue
            value=sum((b*mass(intersection(A,u,C))/width(A) for b,u in zip(bs[1:],small)),Q(0))
            if not value:
                continue
            rho=mass(C)/width(C)
            for u in all_boxes:
                if width(intersection(C,u))>0:
                    assert u[0]-grid*width(u)/2<=C[0] and u[1]+grid*width(u)/2>=C[1]
            if rho<=4:
                low+=value
            else:
                high+=value
            records.append(dict(cell=C,source_average=rho,true_one_leg=value))
        total=bs[0]*width(A)*(low+high)**2/degree
        rem=bs[0]*width(A)*high**2/degree
        assert total==bs[0]*width(A)*(sum((b*mass(intersection(A,u))/width(A)
                                         for b,u in zip(bs[1:],small)),Q(0)))**2/degree
        result.append(dict(grid=grid,average_threshold=4,cells=records,all=total,paid=total-rem,residual=rem))
    assert result[0]["residual"]==0 and 0<result[1]["residual"]<result[1]["all"]
    return result


def parameter_checks():
    ctx.prec=768
    t,g,a,b,c=sp.symbols('t g a b c', positive=True)
    polynomial=a*t*t+b*t+c
    num=sp.expand(sp.diff(polynomial,t)*(t+g)-2*polynomial)
    assert sp.simplify(num-((2*a*g-b)*t+b*g-2*c))==0
    u,v=sp.symbols("u v",nonnegative=True)
    assert sp.simplify(2*(u*u+v*v)-(u+v)**2-(u-v)**2)==0
    rows=[]
    for power in (8,20,48,80,128,192,256,384):
        n=arb(2**power)
        ell=(n+2).log()
        J=n.sqrt()*ell**8
        L=n.sqrt()*ell**3
        r=int((n.sqrt()*ell**2).ceil().unique_fmpz())
        b0=arb(int((arb(r)/(65536*ell)).floor().unique_fmpz()))/16
        feasible=J<n*arb(2).log()
        assert feasible or J>n*arb(2).log()
        penalty=n*(1+(ell/16+J/2)/n).log()
        assert penalty<ell/16+J/2
        gain=J+b0/16-penalty-(n+2).log()
        assert gain>J/2+b0/16-ell/16-(n+2).log()
        # Right side of the core is an exact exponential log difference; absolute constants excluded.
        rows.append(dict(n_power_of_two=power,hard_volume_gap_compatible=bool(feasible),
                         distinct_price_cells_forced=bool(b0>ell/16),
                         b0_lower_integer=int(b0.floor().unique_fmpz()),
                         log_growth_over_J=str(gain/J),
                         log_grid_radius_over_R=str((J/(2*n)).log()),
                         direct_growth_comparison_certified=True))
    return dict(arb_precision=ctx.prec,sympy_derivative=str(num),dimensions=rows)


def serial(obj):
    if isinstance(obj,Q):
        return str(obj)
    raise TypeError(str(type(obj)))


def calculate():
    S=[scenario("initial",[Q(0)],[Q(1,10),Q(1,5)],Q(8)),
       scenario("crowded",[Q(0),-Q(1,16)],[Q(1,10),Q(1,5)],Q(4)),
       scenario("expanded",[Q(0),-Q(1,16),Q(1,16),-Q(1,8),Q(1,8)],
                [Q(1,24),Q(1,16),Q(1,10),Q(9,64),Q(5,32),Q(1,5),Q(7,20),Q(7,10)],Q(2))]
    assert S[0]["rows"][0]["delta"]==0 and S[1]["rows"][0]["delta"]==Q(1,5)
    assert S[1]["rows"][0]["singleton_shortfalls"]==0 and S[1]["mixed_arms"]>0
    return dict(physical_stages=S,adaptive_spikes=spike_tests(),coarse_filter=coarse_filter(),parameters=parameter_checks(),
                runtime=dict(python=platform.python_version(),sympy=sp.__version__,flint=flint.__version__),
                scope="Continuous one-dimensional diagnostic inputs, raw two arms with full degree. "
                      "Dimension rows test scalar implications only. The full high-dimensional entrance is not simulated.")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--check",type=Path)
    args=parser.parse_args()
    data=(json.dumps(calculate(),indent=2,sort_keys=True,default=serial)+"\n").encode()
    if args.check:
        assert data==args.check.read_bytes()
        print("hall800 byte-identical")
    else:
        sys.stdout.buffer.write(data)
