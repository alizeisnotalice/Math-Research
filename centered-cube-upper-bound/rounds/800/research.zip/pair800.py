#!/usr/bin/env python3
"""Positive background capture on the genuine two-arm law and a joint path screen."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
C=(F(3,4),F(7,2))
P=(F(7,8),F(13,4))
Q=(F(15,16),F(27,8))
SIDE_GATE=F(1,8)
PRODUCT_GATE=F(1,32)


def screen(a,b):
    """A joint diagnostic event in the two genuine marks, not two one-arm tests."""
    u,half_u,first_u,price_upper_u=a
    g,half_g,first_g,price_upper_g=b
    same_owner_half=(u==g and half_u==half_g)
    narrow_bridge=({u,g}=={0,1} and first_u and first_g and price_upper_u and price_upper_g)
    return same_owner_half or narrow_bridge


def arm_cells(t,T,A,Eold,parts,cells,cell_mu,mu,base):
    """True one-arm measures of total old degree d_t, with exact backgrounds."""
    m_t=base.length(T[t])
    neighbors={}
    for u,leaf in enumerate(A):
        old_int=base.clip(T[t],leaf)
        a=mu(old_int)
        m_u=base.length(leaf)
        if a and m_u<m_t:
            neighbors[u]=old_int,a,a/(m_t*m_u)
    v_old=list(map(base.length,Eold))
    d=base.total(v_old[u]*x[2] for u,x in neighbors.items())
    assert d>0
    data=[]
    p_info=[]
    for u,(I,mass,K) in neighbors.items():
        leaf=A[u]
        raw=[base.clip(leaf,H) for H in (P,Q)]
        ratio=[base.length(B)/base.length(H) for B,H in zip(raw,(P,Q))]
        assert all(F(0)<v<=1 for v in ratio)
        p_info.append(dict(old=u,K=K,old_true_I=I,old_true_mu=mass,
                           own_background_capture_if_full=ratio))
        E=Eold[u]
        h=base.length(E)/parts
        for j in range(parts):
            U=E[0]+j*h,E[0]+(j+1)*h
            upper_half=j>=parts//2
            for a,z in enumerate(cells):
                if not base.inside(z,I):
                    continue
                midpoint=base.point(leaf)
                assert z[1]<=midpoint or z[0]>=midpoint
                upper_price=z[0]>=midpoint
                # The half factor has a physical realisation as the fixed
                # left half of the corresponding positive background overlap.
                local_factors=[F(1) if upper_price==upper_half else F(1,2),
                               F(1) if upper_price!=upper_half else F(1,2)]
                probabilities=[r*q for r,q in zip(ratio,local_factors)]
                for B,H,x,p in zip(raw,(P,Q),local_factors,probabilities):
                    chosen=B[0],B[0]+base.length(B)*x
                    assert base.inside(chosen,base.clip(leaf,H))
                    assert base.length(chosen)/base.length(H)==p>0
                leg_mass=v_old[u]*K*cell_mu[a]/mass*base.length(U)/v_old[u]
                assert leg_mass==cell_mu[a]*base.length(U)/(m_t*base.length(leaf))>0
                signature=(u,upper_half,j==0,upper_price)
                data.append(dict(u=u,price=z,actual_receiver=U,signature=signature,weight=leg_mass,
                                 probabilities=probabilities))
    assert base.total(a["weight"] for a in data)==d
    return d,data,p_info


def test(name,T,A,shares,parts,amp,base):
    E=[base.owner(x,s) for x,s in zip(T,shares)]
    Eold=[base.owner(x,F(1)) for x in A]
    ordered=sorted(E+Eold)
    assert all(a[1]<b[0] for a,b in zip(ordered,ordered[1:]))
    mu=lambda a:base.real_mass(a,amp)
    assert list(map(mu,T+A))==list(map(base.length,T+A))
    for X in T:
        allowed=base.clip(C,X)
        assert all(base.inside(a,allowed) and base.length(a)>0 for a in (P,Q))
    marks=sorted({*base.SOURCE,*(x for I in T+A for x in I),*(base.point(x) for x in A)})
    cells=list(zip(marks,marks[1:]))
    mass=list(map(mu,cells))
    assert min(mass)>0

    per_middle=[]
    clean=F(0)
    clean_pair=F(0)
    marked=F(0)
    marked_pair=F(0)
    marked_wrong=F(0)
    complement=F(0)
    complement_pair=F(0)
    gates=defaultdict(lambda:[F(0),F(0)])
    captured_by_gate=defaultdict(lambda:[F(0),F(0)])
    witness={}
    min_prob=[F(1),F(1)]
    for t,A_t in enumerate(T):
        d,law,old_info=arm_cells(t,T,A,Eold,parts,cells,mass,mu,base)
        m_t=base.length(A_t)
        I=base.length(E[t])
        weight=I/d
        ks=[base.total(a["weight"]*a["probabilities"][i] for a in law) for i in range(2)]
        full_reference=I*ks[0]*ks[1]/d
        direct=F(0)
        clean_v=F(0)
        m_hold,s1,s2,on_hold=F(0),F(0),F(0),F(0)
        partition=defaultdict(lambda:[F(0),F(0)])
        capture=defaultdict(lambda:[F(0),F(0)])
        for i,j in product(range(len(law)),repeat=2):
            a,b=law[i],law[j]
            record=a["weight"]*b["weight"]*weight
            pl,pr=a["probabilities"][0],b["probabilities"][1]
            mark=pl*pr
            direct+=record*mark
            clean_v+=record
            if not screen(a["signature"],b["signature"]):
                continue
            m_hold+=record
            s1+=record*pl
            s2+=record*pr
            on_hold+=record*mark
            pass_left,pass_right=pl>=SIDE_GATE,pr>=SIDE_GATE
            labels=dict(left_only_test=pass_left,right_only_test=pass_right,
                        two_side_thresholds=pass_left and pass_right,
                        product_threshold=mark>=PRODUCT_GATE)
            for key,positive in labels.items():
                side=0 if positive else 1
                partition[key][side]+=record
                capture[key][side]+=record*mark
            if pass_left and not (pass_right or "left_pass_right_fail" in witness):
                witness["left_pass_right_fail"]=dict(t=t,d=d,true_weight=record,left=a,right=b,product=mark)
            if pass_right and not (pass_left or "right_pass_left_fail" in witness):
                witness["right_pass_left_fail"]=dict(t=t,d=d,true_weight=record,left=a,right=b,product=mark)
            if mark>=PRODUCT_GATE and "paid_product_example" not in witness:
                witness["paid_product_example"]=dict(t=t,d=d,true_weight=record,left=a,right=b,product=mark)
            if mark<PRODUCT_GATE and "unpaid_product_example" not in witness:
                witness["unpaid_product_example"]=dict(t=t,d=d,true_weight=record,left=a,right=b,product=mark)
        assert direct==full_reference and clean_v==I*d
        assert 0<m_hold<clean_v and 0<on_hold<direct
        collapsed=defaultdict(lambda:[F(0)]*3)
        for mark in law:
            g=collapsed[mark["signature"]]
            g[0]+=mark["weight"]
            for side,p in enumerate(mark["probabilities"]):
                g[side+1]+=mark["weight"]*p
        weighted=[F(0)]*4
        for (a,p),(b,q) in product(collapsed.items(),repeat=2):
            if screen(a,b):
                for idx,v in enumerate((p[0]*q[0],p[1]*q[0],p[0]*q[2],p[1]*q[2])):
                    weighted[idx]+=weight*v
        assert weighted==[m_hold,s1,s2,on_hold]

        incorrect=s1*s2/m_hold
        per_middle.append(dict(middle=t,absolute_volume_bin=base.volume_bucket(m_t),
                               old_full_d=d,original_middle_volume=m_t,I=I,real_arms=len(law),
                               backgrounds_inside_real_middle=[P,Q],old_arms=old_info,
                               k_left=ks[0],k_right=ks[1],unmarked_original_two_arm_mass=clean_v,
                               unmarked_direct_product_integral=direct,
                               independent_full_middle_factorization=full_reference,
                               marked_original_mass=m_hold, marked_left_capture_integral=s1,
                               marked_right_capture_integral=s2, marked_actual_joint_capture=on_hold,
                               naive_conditionally_independent_product_after_screen=incorrect,
                               discrepancy_after_screen=on_hold-incorrect,
                               actual_marked_joint_capture_probability=on_hold/m_hold,
                               within_marked_conditional_marginals=[s1/m_hold,s2/m_hold],
                               actual_gate_paid_and_remainder_by_middle=dict(partition),
                               product_capture_on_each_gate_and_remainder=dict(capture)))
        clean+=clean_v
        clean_pair+=direct
        marked+=m_hold
        marked_pair+=on_hold
        marked_wrong+=incorrect
        complement+=clean_v-m_hold
        complement_pair+=direct-on_hold
        for key,vals in partition.items():
            assert base.total(vals)==m_hold
            assert base.total(capture[key])==on_hold
            for side,value in enumerate(vals):
                gates[key][side]+=value
                captured_by_gate[key][side]+=capture[key][side]
        for i in range(2):
            min_prob[i]=min(min_prob[i],min(r["probabilities"][i] for r in law))
    assert clean==marked+complement and clean_pair==marked_pair+complement_pair and complement_pair>0
    assert all(v>0 for v in min_prob)
    assert marked_pair!=marked_wrong
    assert all(base.total(v)==marked for v in gates.values())
    assert all(base.total(v)==marked_pair for v in captured_by_gate.values())
    assert all(x>0 for x in gates["product_threshold"])
    assert any(gates[side][0]!=gates["two_side_thresholds"][0]
               for side in ("left_only_test","right_only_test"))
    assert {"paid_product_example","unpaid_product_example"}<=witness.keys()
    return dict(stage=name,actual_middle_parents=T,actual_old_parents=A,actual_middle_owners=E,
                actual_old_owners=Eold,true_source_amplitude=amp,physical_U_strips=parts,
                common_C=C,common_background_Leb_left=P,common_background_Leb_right=Q,
                min_positive_mark_probabilities=min_prob,source_cells= cells,
                minimum_true_phase_density=1-amp,real_middle=per_middle,
                original_clean_mass=clean,unmarked_integral_of_product=clean_pair,
                independently_summed_kleft_kright_over_original_degrees=base.total(
                    v["independent_full_middle_factorization"] for v in per_middle),
                original_screened_path_mass=marked,marked_exact_joint_capture_integral=marked_pair,
                naive_product_of_marked_marginals_by_middle=marked_wrong,
                marked_exact_minus_naive=marked_pair-marked_wrong,
                original_discarded_path_mass=complement,discarded_positive_product_integral=complement_pair,
                true_marked_diagnostic_payments_and_remainders=dict(gates),
                marked_product_capture_on_each_gate_and_remainder=dict(captured_by_gate),
                actual_witnesses=witness)


def suite(base):
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    return [
      test("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],2,F(1,4),base),
      test("pressure",T,U,[F(1),F(3,4),F(1,2)],4,F(1,2),base),
      test("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
           U+[base.iv("1/2",3),base.iv(2,"9/2")],
           [F(1),F(3,4),F(1,2),F(7,8),F(5,8)],4,F(3,4),base),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir",type=Path,default=Path(__file__).resolve().parent)
    action=p.add_mutually_exclusive_group()
    action.add_argument("--output",type=Path)
    action.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=args.rows_dir/"rows798.py"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    cases=suite(base)
    obj=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             dependency={"rows798.py":ROWS_SHA},exact_precision="standard-library Fraction",
             command="python -B pair800.py --check pair800.json",
             scope=dict(source_support=base.SOURCE,source_phase_period=base.PERIOD,
                        old="true two independent old arms conditional on the real middle v, with true old intersection price and actual receiver for each arm",
                        measure="dnu=I_v/d_v times product of the two true unnormalised arms of mass d_v",
                        backgrounds="preassigned uniform Lebesgue on P and Q inside C and each real middle, used as distinct positive one-arm mechanisms",
                        actual_leg_multiplier="one or half depending on that arm actual price half and receiving half, realised as whole or half of the old-parent background overlap",
                        path_screen="retain if both old parents equal and both receiver halves equal, or if old labels are 0 and 1, both receive in first strips, and both prices in upper parent halves",
                        payment_thresholds=dict(single_or_two_arm_threshold=SIDE_GATE,true_double_product_threshold=PRODUCT_GATE),
                        diagnostic_scope="one-dimensional finite diagnostic; the original high-dimensional hard path screens outside this specification",
                        denominators="all exact original d_v used before any screen; the false screened product uses conditional marginals under each accepted middle"),
             stages=cases)
    text=json.dumps(obj,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in cases:
            print(s["stage"],"unmarked:",s["unmarked_integral_of_product"],"screened:",s["marked_exact_joint_capture_integral"],
                  "incorrect screened product:",s["naive_product_of_marked_marginals_by_middle"],
                  "difference:",s["marked_exact_minus_naive"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
