# R521：全动作平价强制的全径向加权捕获

本轮只推一个机制：对真实全动作平价字段，沿完整体积区间积分。跨相位均值跳跃由平价精确消失；连续换窗输运只按真实新增质量收费，不按相位数 J 或 log 质量倍数再收费。所得是一个完整径向刚性恒等式及捕获下界。尚未完成同来源重复的 W 付款。

## 1. 固定合同与命题

保 R520 的完整 bulk、真实 μ=f dx、原 t_B、原 L_i 与 α_i、q≤q_B≤λ、slow 约束；不改源格或历史。允许任意 G>1，特别 G=log^p(n+2)，但保原母账

Q≤(1−β)^−2[G²J B/(1−3h)²+2CS(1+2G)W/(1−3h)].

令 F=(F_ij) 是同一个真实相位 Hilbert 空间中的非负字段，0≤F_ij≤C_*，其中

C_*=S[1+log(G γ^(1+h)r)].

F 不等于原 L_i；本命题不作这种替换。对固定 bulk 中心 B，t_B>0，记

r=R_B,
Q_g=Q(B,r g^(1/n)),
m_g=μ(Q_g),
s_g=log_γ m_g,
j(g)=floor((s_g−s_1)/h),              1≤g≤G,
H_j^s(y)=∫_[s,s+1]F_ij(y,σ)dσ,
c_B(g)=t_B/(r^n g) ∫_(Q_g)H_(j(g))^(s_g)(y)dμ(y).

**全动作平价假设是准确前提：** c_B(g)=c_B 对每个 g∈[1,G] 成立。它适用于 R520 中全支撑概率核的零二抽振幅情形；小二抽振幅不自动满足它。只对最优支持动作平价也不够。零 t_B 父的成本恒为零，直接略去。

对 y∈Q_G\Q_1 定义真实首次进入参数

g_B(y)=(2||y−B||_∞/r)^n∈(1,G].

定义真实进入价格

Capture_B=∫_(Q_G\Q_1)H_(j(g_B(y)))^(s_(g_B(y)))(y)dμ(y),   (1)

以及连续换窗输运

Transport_B=∫_1^G s'_g ∫_(Q_g)
 [F_(i,j(g))(y,s_g+1)−F_(i,j(g))(y,s_g)] dμ(y)dg.            (2)

**主命题：**

(r^n/t_B)c_B(G−1)=Capture_B+Transport_B,                    (3)

0≤Capture_B≤C_*(m_G−m_1),
|Transport_B|≤C_*/lnγ·(m_G−m_1).                           (4)

从而

m_G−m_1≥c_B r^n(G−1)/[t_B C_*(1+1/lnγ)].                  (5)

更强地，对每个 1≤g_1<g_2≤G，同一恒等式在该子区间成立，因此

m_(g_2)−m_(g_1)≥[c_B r^n/(t_B C_*(1+1/lnγ))](g_2−g_1).    (5a)

等价地，m'_g≥c_B r^n/[t_B C_*(1+1/lnγ)] 几乎处处。正价全动作平价父不能在任何正长度体积区间存在质量平台。这个局部下界仍保真实进入来源，未假设径向密度均匀。

式 (3) 保所有实际相位、完整区间和右端点，不要求某个同相位区间有固定长度。式 (4) 的输运费用没有 J 或 log(m_G/m_1) 因子。

## 2. 全路径证明及边界处理

### 径向和换窗的正则性

因为 μ≪Lebesgue，固定正半径区间内的立方体径向质量 m_g 绝对连续；可由 ℓ∞ 径向壳积分及 Fubini 得到。m_g≥m_1≥qa^n>0，因此 s_g 也绝对连续，且几乎处处

s'_g=m'_g/(m_g lnγ)≥0.                                    (6)

对 μ-几乎每个 y，H_j^s(y) 是 s 的 Lipschitz 函数，其几乎处处导数为 F_ij(y,s+1)−F_ij(y,s)。沿绝对连续 s_g 作链式法则，质量平台上 s'_g=0，不要求给平台上的点值赋予额外导数意义。

记

N(g)=∫_(Q_g)H_(j(g))^(s_g)dμ=(r^n/t_B)g c_B(g).

在一个固定相位区间，移动空间边界贡献进入来源 (1)，连续质量窗移动贡献 (2)。这是先对每个真实来源 y 的进入指标 1_{g≥g_B(y)} 作一维乘积积分，再对 μ 积分的 Leibniz 公式；没有将薄壳 Lebesgue 体积当成 μ 质量。

### 相位跳跃如何消失

每个达到的相位阈值用首次达到 m_g=m_1γ^(jh) 的 g_j 标记。实际 floor 标签在 g_j 取较高标签；即使质量此后有平台，标签仍保持较高值。相位过界带来可能的跳跃

Jump_j=∫_(Q_(g_j))[H_j^(s_(g_j))−H_(j−1)^(s_(g_j))]dμ.      (7)

盒对 μ 连续，窗口对 s 连续，所以这是全部跳跃项。全动作成本恒定给 N(g_j−)=(r^n/t_B)g_j c_B=N(g_j)，故每个 Jump_j=0。

**若 g_j=G，仍必须计入终端 Jump_j。** 不能把左侧相位的极限冒作实际终点动作。此处平价也使它为零。立方体边界对 μ 的测度为零，故 (1) 在这个端点没有额外来源原子；存在的是相位标签跳跃，而不是来源质量原子。

把各固定相位区间的积分接起来，含全部 (7)，得

N(G)−N(1)=Capture_B+Transport_B+Σ_j Jump_j.

平价与跳跃为零即给 (3)。这个证明亦显示一般成本必须保留带符号的相位跳跃；本稿没有将小振幅无价换成全路径平价。

### 换窗费用为何只按新增质量结算

0≤F_ij≤C_*，所以同一来源处的两个端点值之差绝对值≤C_*，而不是 2C_*。结合 (6)，

|Transport_B|≤C_*∫_1^G m_g s'_g dg
              =C_*/lnγ∫_1^G m'_g dg
              =C_*/lnγ·(m_G−m_1).

进入价格非负且≤C_*，也给 (4) 第一式。与 (3) 合并得 (5)。把相同证明限制在任意 [g_1,g_2]，并保该区间内所有相位跳跃，即得 (5a)。这里没有逐相位重复支付 m_G，也没有用粗 log(m_G/m_1)·m_G 代替准确积分。

## 3. 与 slow、原 α 和一次真实来源积分的连接

写 β_F(B)=c_B/[C_*t_Bq_B]。它是 F 的真实归一价格，不是原 α_i(B)。式 (5) 与 slow 的 m_G/m_1<K_B 给

β_F(B)≤(1+1/lnγ)(K_B−1)/(G−1),
K_B=max{1+u,A_nα_i(B)}.                                  (8)

因此大的 G 确实强化平价场的真实捕获要求；但是 (8) 仍含 A_nα，不能当成维数无关结论。

对平价中心域 U 积分，定义真实捕获质量账

M_U=∫_U t_B r^(−n)(m_G−m_1)dB.

Tonelli 将 (3) 的进入项写为一次来源积分

S_U=∫dμ(y) Σ_i∫_(U∩E_i) t_B r^(−n)1_(Q_G\Q_1)(y)
       H_(j(g_B(y)))^(s_(g_B(y)))(y)dB.                    (9)

这是 F 的真实旧/新盒联合价格；没有 W²，也没有将每个中心的捕获各自收一次 W。积分恒等式为

(G−1)∫_U c_BdB=S_U+T_U,
|T_U|≤C_*/lnγ·M_U,   0≤S_U≤C_*M_U.                        (10)

若 F 是完整动作最小范数字段且在全部 bulk 全动作平价，则 oracle 身份给 ∫bulk c_BdB=||F||²=P，即

(G−1)P=S_bulk+T_bulk.                                     (11)

这一步不要求最优概率核达到；R519 的闭包最小范数及 oracle 结论已经足够。若只在子集 U 平价，则保 ∫_U c_B，不把它改成整个 P。

原 α 始终来自原 L_i。特别在 K_B=A_nα_i(B) 的部分，slow 只给

M_U<∫_U t_Bq_B(A_nα_i(B)−1)dB
    =A_n/C·∫_U ψ_i(B)dB−∫_U t_Bq_BdB.                    (12)

(12) 有线性 A_n；把它直接代回 (10)，再乘原 G²J 母账，不能吸收。这明确定位了实际缺口：必须对 (9) 中同一来源的进入价格重复结算，或利用 (11) 的有符号输运与共同字段结构；单纯对 H≤C_* 截帽仍不足。

全路径恒等式新增的刚性是：全动作平价不能通过不断切换相位隐藏体积增长所要求的价格捕获，因每个过界均值跳跃被迫为零。它未证明相同来源不会被许多中心重复捕获，也未证明完整低振幅输入都接近这种均匀平价。

## 4. 已证与未证边界

已证：真实全动作平价的完整径向身份、含端点的相位跳跃消失、只按 Δm 计费的换窗输运、强制捕获下界，以及同一个真实来源积分 (9)—(11)。扩大 G 的所有原费用保持。

未证：对 (9) 的同来源重复给出多对数 W 上界，或由有符号 (11) 得足够的同 P/Q 收缩。当前平价字段 F 的帽与 slow 仅给 (12) 的线性费用。近乎平价还需真实的端点/相位价格误差账；小二抽振幅不能替代它。本轮不再新增候选，到此停止。

## 5. 本机数学核验

实际运行 SymPy 和 Fraction。局部真实径向例取 n=1、中心 0、旧边长 r=2、μ(dy)=|y|dy（在包含全部测试盒的有限区间截断），故 m_g=g²。取 γ=e²，则 s_g=ln g。对相关窗令各相位测试函数相同：

F_j(y,σ)=e^(−σ)/(1−e^(−1)),  H_j^(s_g)=1/g.

在所有实际窗外可截断该测试函数，故是有限范数的局部测试。此时 N(g)=g，成本为 t/2，确为所有 g 的常数。SymPy 实际积分得到

Capture=∫_1^G (1/g)d(g²)=2(G−1),
Transport=∫_1^G g² d(1/g)=−(G−1),
Capture+Transport=G−1.

这验证输运项可能为负且不能删除。另作相位拼接与终端误差代数核验，输出 `PASS 23 exact radial/phase/error checks plus symbolic transport identity; local identity only`。该例验证局部真实 μ 恒等式，不声称测试 F 由全局最优实际字段生成，更不认证完整 bulk 预算。

```python
import sympy as s
from fractions import Fraction as F
g,G=s.symbols('g G', positive=True)
m=g**2;H=1/g
capture=s.integrate(H*s.diff(m,g),(g,1,G))
transport=s.integrate(m*s.diff(H,g),(g,1,G))
assert s.simplify(capture+transport-(G-1))==0
print('symbolic actual radial example: capture=',capture,
      ', window transport=',transport,', total=',s.simplify(capture+transport))
checks=0
for G0 in (F(5,4),F(3,2),F(2)):
 cap=2*(G0-1);tr=-(G0-1);dm=G0*G0-1
 assert cap+tr==G0-1;checks+=1
 assert abs(tr)<=dm/2;checks+=1
for phases in (1,2,5,9):
 boundaries=[F(1)+F(k,phases) for k in range(phases+1)]
 c=F(3,2)
 continuous=sum(c*(boundaries[k+1]-boundaries[k]) for k in range(phases))
 assert continuous==c;checks+=1
 e=F(1,100)
 for j in range(1,phases):
  left=(c-e)*boundaries[j];right=(c+e)*boundaries[j]
  assert abs(right-left)==2*e*boundaries[j];checks+=1
print('PASS',checks,'exact radial/phase/error checks plus symbolic transport identity; local identity only')
```
