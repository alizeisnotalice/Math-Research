# R521 独立PRE：带真实源模量与概率底座的完整gap控制

独立先审，仅使用R519/520实际bulk、phase字段、窗帽及基本积分。不读R521作者。下面给出一个超出“近δ不等于近oracle”的可证接口，但保留全部输入模量及概率底座费用，不称一般来源预算已付。

## 1. 精确低值集条件与概率账

令任一非负测试场F满足逐phase 0≤F_ij≤C_*(G)，成本c_B(s)=<F,v(B,s)>；s=(R−R_B)/(V_B−R_B)∈[0,1]。F可以是当前实际字段A，也可以是精确闭包投影A*，两者不可混用。置m_B^F=inf_s c_B(s)，

g_B^F=E_{π_B}c_B−m_B^F,
δ_B^F=(1/2)E_{π_B⊗π_B}|c_B(s)−c_B(t)|。

若同一归一动作参考律ν满足π_B≥κν，且ν{c_B≤m_B^F+τ_B}≥p_B>0，则

δ_B^F≥κp_B(g_B^F−τ_B)_+，
g_B^F≤τ_B+δ_B^F/(κp_B).                                  (1)

证明是δ_B=E(X−Y)_+，只保Y在低值集，再用E(X−Y)_+≥EX−Y；无独立来源假设，两次独立的是动作。若κ或p_B不统一，积分必须保实际倒数权，不能提出一个无价常数。

下面用真实源几何证明一个输入依赖、对B统一的p>0，避免只把低值集假设换名。

## 2. 真实μ模量给同phase统一连续性

固定输入m0=qa^n>0，Kmax=max(1+u,A_n)，定义绝对连续模量

ω_μ(v)=sup{μ(D): D可测，Leb(D)≤v}，ω_μ(v)→0(v↓0)。

仅由μ=f dx∈L1得到此极限，不假定f有密度帽，也不声称整个L1类有同一模量。对同一父的两个半径r≤ρ、归一距离≤d，空间壳Leb体积≤n b^n d，故新增真实质量≤ω_μ(n b^n d)。若两个动作属于同一实际phase，则由真实旧盒/新壳分解、长度1窗的一侧变化及系数稀释，严格有

|c_B(ρ)−c_B(r)|≤H(d)·w_B，  w_B=t_Bq_B，
H(d)=C_*[Kmax·(nb/a)d
       +(1+1/lnγ)ω_μ(n b^n d)/m0].                       (2)

其中t_Bq(B,r)≤Kmax w_B，1−(r/ρ)^n≤n(ρ−r)/a，且log_γ[m(ρ)/m(r)]≤[m(ρ)−m(r)]/[m(r)lnγ]。这同时处理真实新空间壳、旧窗变化及原t_B，未冻结父窗。H(d)→0；跨phase不得直接套(2)。

## 3. phase质量跨度与端点原子给实际p

取固定参考律ν=(Leb_[0,1]+δ_1)/2。任给η>0，可选d0∈(0,1/4]使

H(2d0)≤η，
ω_μ(4n b^n d0)<m0(γ^h−1).                                (3)

固定B，任何不被右端截短的完整phase区间，其质量必须从m_Bγ^(jh)增长至m_Bγ^((j+1)h)，至少增加m0(γ^h−1)。由(3)该区间归一半径宽度>4d0；质量平台不会破坏此下界。phase0从原质量m_B开始，亦同。若V恰在阈值，阈值前区间仍有完整质量跨度，阈值点属于新phase并由δ_1处理。

取成本≤m_B^F+ηw_B的动作（只为点态论证，不要求inf达到）。若其phase区间足够长，可在同phase且距离≤d0处保一侧长d0的区间；否则它必处于右端截短phase，距s=1≤2d0，且右端属同phase。前者由(2)得低值集至少有Leb长度d0，后者由(2)得到端点本身是低值动作。故包括所有平台、端点和相位跳跃，均有

ν{c_B≤m_B^F+2ηw_B}≥d0/2.                                  (4)

t_B=0时所有cost=0，(4)平凡；G=1是单动作退化，δ与gap均为0，不必定义归一半径。

将(4)代入(1)，对任何真实π_B≥κν得

∫g_B^F dB≤2ηX_bulk+2δ_F/(κd0)，
X_bulk=∫_bulk t_Bq_B dB， δ_F=∫_bulk δ_B^F dB.              (5)

特别F=A为当前实际字段时，左端正是完整oracle gap r(A)=||A||²−m(A)，δ_F是R520可执行二winner振幅。因此这是明确有价的小δ→完整gap接口。若δ≤κd0 εB/2，则r(A)≤2ηX_bulk+εB；如何将其用于完整回代仍须计算系数，不能直接当根阶结论。

F=A*时同样成立，但左端为<A*,A_π>−P；对能量近优π_ε，该量已有ε/2投影账，不能把它错写成当前A_ε的oracle gap。

## 4. 与R520实际初始律、迭代费用的连接

R520初始律π0(dg)=[g/(G²−1)]dg+(1/2)δ_G，归一s下连续密度至少n(G^(1/n)−1)/(G²−1)。故其支配上述ν，实际可取

κ0=min{1, 2n(G^(1/n)−1)/(G²−1)}。

二winner混合若η_k<1，π_(k+1)≥(1−η_k)π_k，因而可追踪

κ_k≥κ0 ∏_(l<k)(1−η_l)。                                  (6)

这个乘积可能退化；全支撑本身不提供统一κ。若某步η=1，原核底座不再由此公式保留，须另分析；零平方终止不构成预算遗漏。不能强加固定κ而不支付对算法/可行最优值的改变。

## 5. 已得与未得的决策边界

(2)—(5)利用真实进入质量与phase固定质量跨度，给出了完整oracle的定量可测低值集下界；不是抽象对偶等价重述。代价明确依赖ω_μ、qa^n、n、G、h及κ。任意L1输入没有由W单独控制的统一绝对连续模量，所以d0可能极小；κ_k亦可能很小。因此不能从当前相对δ小就宣称维数一致gap小，不能将d0或κ隐入只依r,S的常数。

即使完整oracle gap已小，最优值P本身仍可能承载未付重复来源；本接口不证明P或近平价场的多对数预算。原Li/alpha、slow及完整母账均未被重置，也未改history。它的实际用途是：对给定输入及保留底座的真实算法，给停止误差/完整oracle替代的可核验门槛；若要一般来源预算，仍须新的模量无关几何付款或允许并明确结算上述费用。

## 6. 本机辅助核验

实际运行/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I，使用Fraction、Random(521)、200组7动作正参考概率与混合π=κν+(1−κ)ρ，逐组核δ≥κp(gap−τ)_+、gap≤τ+δ/(κp)及逐点概率支配，共600项通过。stdout：“PASS 600 Fraction low-sublevel probability-floor and full-gap inequalities; finite probability algebra only”。该计算仅核概率代数，不冒充真实立方体实例；(2)—(4)由上述μ几何证明。未运行MATLAB。

本PRE到此停止，等待作者后审；只写本责任文件。


## 7. 第一阶段作者后审与PRE端点复查

独立结论形成后已读r521_geometry.md全文，尚未读未交付的主proof。未发现全路径身份、常数或(5a)的阻断问题。

固定B，μ≪dx使立方体径向推前对半径Lebesgue绝对连续，故m_g及其正质量下界下的s_g均AC。H_j对s是逐来源Lipschitz函数。链式法则中F(y,s+1)−F(y,s)按σ几乎处处代表解释；沿s_g的积分通过s'_g dg=ds处理，平台上s'_g=0，不能要求平台点值另有导数。有限相位逐来源入场指标乘积公式给capture及transport，所有源边界μ0，无来源原子或遗漏的薄壳质量。

各标签首次达到阈值后取高phase，平台标签也取高phase。N(g)=g(r^n/t)c_B(g)在全动作平价下连续，所以每个实际jump的积分均值为0，包含g_j=G的终端jump；不是声称F逐来源的phase跳跃点态消失。对任意[g1,g2]重复同一入场/输运/终端拼接，Capture≤C_*Δm且|Transport|≤C_*Δm/lnγ，故(5a)及等价m'_g下界成立。输运可为负，必须保符号；仅把F帽与slow合用仍含A_n，不构成同来源重复付款。

PRE(3)—(4)另作边界自查：完整非终端phase从下阈值质量到上阈值质量至少跨m0(γ^h−1)，因此归一宽度严格大于4d0；phase0从m_B精确起步亦同。若下确界仅从某阈值左侧逼近，近inf动作本身在旧phase，可向左取长d0的同phase区间；若它恰是阈值动作，则归新phase。唯一可能很短的截断phase在s=1前，若宽≤2d0，近inf动作与端点同phase且距≤2d0，由H(2d0)控制端点cost。s=1恰是新phase孤立终端点时由δ1直接处理；之前phase仍有完整质量跨度。故无相位端点缺口，无须偷用跨phase连续性或inf达到。t=0支另已处理。

实际执行指定本机Python -I运行geometry唯一Python围栏：SymPy给capture=2G−2、transport=1−G、total=G−1；23项Fraction径向/相位/误差检查通过。仅验证局部真实径向示例及代数，未将其视为一般最优F或来源预算。等主proof交付后再完成作者后审。


## 8. 主proof后审与600项可复现程序（PRE冻结版）

已读r521_proof.md全文，S1保留实际首次阈值处的全部带符号g_jΔc_j，含终端G。固定phase内的AC片段拼接后，ΔN_j=(r_B^n/t_B)g_jΔc_j，故S1符号及系数正确；S2取正部后的界正确。S3由参照价差的精确展开再支付绝对值误差得到，统一全路径e_B条件下的G+1+2GJ_B常数安全，不是从二动作δ推出该条件。所有量在真实t、源格及实际μ上积分，重复来源仍没有额外付款。

有限望远镜仅给Σδ_k²/B_k≤B_0，不给终端零、收敛率、oracle gap或最优值预算；带误差时必须保其部分和。用户新486建议只迁移同参考与累计费用的组织原则，不将Palm链和当前算法认作同律，范围正确。实际指定Python -I运行主proof围栏，364项Fraction符号/终端/稳定/望远镜检查通过。没有新的实质阻断。

下列就是§6已实际执行的600项概率检查，补供归档重放。它只核(1)的概率代数；PRE真实phase几何和μ模量界由§2—3证明，不把有限随机动作表当立方体数据。

```python
from fractions import Fraction as F
from random import Random
rng=Random(521)
checks=0
for _ in range(200):
    cost=[F(rng.randrange(21),7) for i in range(7)]
    nuw=[rng.randrange(1,10) for i in cost]
    rw=[rng.randrange(1,10) for i in cost]
    nu=[F(x,sum(nuw)) for x in nuw]
    rho=[F(x,sum(rw)) for x in rw]
    kap=F(rng.randrange(1,10),10)
    pi=[kap*n+(1-kap)*r for n,r in zip(nu,rho)]
    m=min(cost)
    mean=sum(p*c for p,c in zip(pi,cost))
    gap=mean-m
    delta=sum(pi[i]*pi[j]*abs(cost[i]-cost[j])
              for i in range(7) for j in range(7))/2
    tau=F(rng.randrange(11),7)
    p=sum(n for n,c in zip(nu,cost) if c<=m+tau)
    assert delta>=kap*p*max(gap-tau,F(0));checks+=1
    assert gap<=tau+delta/(kap*p);checks+=1
    assert all(a>=kap*b for a,b in zip(pi,nu));checks+=1
print('PASS',checks,'Fraction low-sublevel probability-floor and full-gap inequalities; finite probability algebra only')
```

PRE至此冻结，不再追加numeric；待最终九输入白名单后只写final audit。当前通过范围是严格身份、输入依赖gap接口及已述有限检查，非一般来源预算或完整根阶闭合。
