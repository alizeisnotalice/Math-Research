# R521 主推导：带符号相位跳跃的稳定捕获账

## 合同与精确身份

沿用本包 geometry 的真实 μ=f dx、全部 bulk 中心、原 t_B、盒 Q_g、质量 m_g、s_g=log_γ m_g、相位 j(g) 与同一有界非负字段 F。写 r_B=R_B，避免与原密度比 r 混淆。所有常数依赖保持；F可以是实际场或精确投影，但不能将两者混用。本文**不假设全动作平价**。t_B=0时全部价格为零，单列处理。

令 c(g)=t_B N(g)/(r_B^n g)，N(g)=∫_(Q_g)H_(j(g))^(s_g)dμ。每一实际相位阈值首次到达点 g_j∈(1,G] 的成本跳跃为

Δc_j=c(g_j)−c(g_j−)。

包括恰在G的阈值，且阈值取高标签。相位数有限。两边成本在每个相位内绝对连续，左极限存在；μ不在任何盒边界放原子。定义同 geometry 的 Capture、Transport，则

\[
\frac{r_B^n}{t_B}\left[G c(G)-c(1)-\sum_{g_j\in(1,G]}g_j\Delta c_j\right]
=\operatorname{Capture}_B+\operatorname{Transport}_B. \tag{S1}
\]

证明：在每一固定相位，先对来源进入指标与H窗口作一维乘积公式，再以μ积分；绝对可积性由C_*帽、有限质量和∫m_g s'_g dg=Δm/lnγ保证。将固定相位段相加，所有内端点精确给ΔN_j=(r_B^n/t_B)g_jΔc_j，末端相位切换同样保留。代入N的定义得(S1)。不需要空间密度帽，不使用边界体积支付μ质量。

由于0≤Capture≤C_*Δm且|Transport|≤C_*Δm/lnγ，令

\[
D_B=G c(G)-c(1)-\sum_jg_j\Delta c_j,\qquad
M_B=t_B r_B^{-n}(m_G-m_1),
\]

有严格稳定预算

\[
(D_B)_+\le C_*(1+1/\ln\gamma)M_B. \tag{S2}
\]

相位跳项的符号在(S1)保留；仅在给定误差界的推论中才可付绝对值。Transport可能为负，不能删除后声称相等。

## 近平价误差必须显式付款

任取参考价格c_0(B)≥0。令

\[
E_B=G|c(G)-c_0|+|c(1)-c_0|+\sum_jg_j|\Delta c_j|.
\]

由(S1)直接得到

\[
(G-1)c_0(B)\le C_*(1+1/\ln\gamma)M_B+E_B. \tag{S3}
\]

也可保更精确的有符号误差，而不取绝对值。若**另已证明**所有g满足|c(g)−c_0|≤e_B，则左极限也满足它，故

E_B≤(G+1+2GJ_B)e_B，

J_B为实际跨过阈值个数（含末端）。此式不是由二抽振幅δ小推得。独立PRE只给保真实μ模量及概率底座的完整oracle误差，仍不提供统一全路径振幅。

对任何可测父域U，Tonelli与有限帽给(S1)的准确来源账

\[
\int_U D_B\,dB=\mathcal S_U+\mathcal T_U,\qquad
|\mathcal T_U|\le C_*/\ln\gamma\int_U M_B\,dB,
\]

其中S_U是geometry式(9)同一真实来源的进入价格。该身份没有把来源重复变成已付预算。slow只给M_B<t_Bq_B(K_B−1)，K_B=max(1+u,A_nα_i(B))；直接截帽仍含A_n，代回原G²J费用不足闭合。

精确平价时E_B=0，所有Δc_j=0，恢复geometry完整径向刚性；支持集上平价不足替代全部动作平价。

## 下降总额与用户新建议的接口

按照N04技能的有限望远镜流程，对R520实际算法，记B_k≥0、δ_k≥0。B_k>0时令d_k=δ_k²/B_k，零平方后保持零。实际已证B_(k+1)≤B_k−d_k，故对每个N

\[
\sum_{k<N}d_k\le B_0-B_N\le B_0.
\]

非负单调收敛仅给Σd_k≤B_0，不给B_N→0，不给完整oracle误差，也不支付最优值P。若算法含认证误差e_k≥0，则右侧须加Σ_(k<N)e_k；只有其部分和一致受控才可取无穷极限。本轮计算使用严格外包球核验实际下降，不假设浮点最优就是证书。

用户第486轮建议中的E1具有相同的**代数求和形式**，但其对象是自然Palm链P=JH、q_j及低捕获投影；并非这里的A_k、B_k。接受这一组织原则，不宣称两过程同律或自动继承停止预算。建议中的B1/B2仍是待构造的真实测试及来源平方费用，不把Cauchy回代模板记为本轮新证明。

## 本机精确代数复现

以下测试只检查相位拼接、含末端的跳项符号、近平价误差包络和有限望远镜，不冒充全几何证明。几何正则性与来源公式见上述解析论证。

```python
from fractions import Fraction as F
from random import Random
rng=Random(521)
checks=0
for count in (1,2,5,9):
 for trial in range(25):
  nodes=[F(1)+F(k,count) for k in range(count+1)]
  # Independent left/right endpoint costs, including a terminal phase jump.
  right=[F(rng.randrange(1,50),20) for _ in nodes]
  left=[right[0]]+[F(rng.randrange(1,50),20) for _ in nodes[1:]]
  continuous=sum(nodes[k+1]*left[k+1]-nodes[k]*right[k] for k in range(count))
  jumps=sum(nodes[k]*(right[k]-left[k]) for k in range(1,count+1))
  assert continuous+jumps==nodes[-1]*right[-1]-right[0];checks+=1
  c0=F(1)
  err=nodes[-1]*abs(right[-1]-c0)+abs(right[0]-c0)+sum(nodes[k]*abs(right[k]-left[k]) for k in range(1,count+1))
  assert (nodes[-1]-1)*c0<=continuous+err;checks+=1
  e=max(abs(v-c0) for v in right+left)
  assert err<=(nodes[-1]+1+2*nodes[-1]*count)*e;checks+=1
B0=B=F(7);total=F(0)
for k in range(1,65):
 delta=B/F(k+2);d=delta*delta/B
 B-=d;total+=d
 assert total==B0-B and B>=0;checks+=1
print('PASS',checks,'Fraction signed phase-jump, terminal, stability and telescoping checks; algebra only')
```
