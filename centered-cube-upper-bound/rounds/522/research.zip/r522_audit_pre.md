# R522 独立PRE冻结版：完整端点phase分组的固定系数桥

独立先审，尚未读R522作者。以R519—521真实μ、Lebesgue中心、原t、源格、固定α及全部bulk为合同；不假设来源密度帽、最优核达到或逆半径绝对连续。根据主代理新候选，当前只保完整端点桥为主结果；早期最优支持有限差分只确认ε/2与带符号jump账，未继续作为另一研究分支。

## 1. 固定全部父，端点目标准确相合

bulk上V_B=G^(1/n)R_B<b，m_B=μQ(B,R_B)>0，U_B=log_γ[μQ(B,V_B)/m_B]，j_B^*=floor(U_B/h)。以终端标签分组E_j={B:j_B^*=j}，不删父。令θ_B(u)=min(u,U_B)，选restricted first/last-hit半径ρ_B(θ)达到真实质量m_Bγ^θ。固定整个过程的系数

a_B=t_B/(G R_B^n)=t_B/V_B^n，
A_j(u)(y,σ)=∫_(E_j) a_B 1_Q(B,ρ_B(θ_B(u)))(y)
                   1_[s_B+θ_B(u),s_B+θ_B(u)+1](σ)dB。

每父全程保留且系数固定。途中空间/窗核是某合法实际动作核乘g_B(u)/G≤1；不能称仍为每父全权selector。按终端j作直和是辅助比较：不同时刻不同终端组可共享同一真实phase，不能将这些中途组无价当实际phase正交。只在终点各组标签与真实endpoint phase一致。

设Q_grp=Σ_j||∫_(E_j)k_B dB||²，B_end为完整真实endpoint动作的分phase平方，则

E(0)=Q_grp/G²， E(U_max)=B_end， E(u)=Σ_j||A_j(u)||²。

不能将Q_grp改成原全部Q。正性只给Q_grp≤Q_bulk，反向比较一般需分组Cauchy的J费用。

## 2. 逆函数BV、初末端点与能量正则性

m_B(R)绝对连续并不保证逆半径AC，逆可有平台跳或奇异连续变化。这里不对ρ求导。质量时钟给

μ(Qρ(θ_2)\Qρ(θ_1))=m_B(γ^θ2−γ^θ1)，

所以空间指示在L1(μ)的变化由一个AC质量函数控制。任意pair的交集质量K_BC(u)=μ(Q_B(u)∩Q_C(u))非减，亦AC（其增量由两个父的质量增量之和控制）。θ_B是Lipschitz，窗tent亦Lipschitz。固定输入的有界半径、有限父测度、有限质量保证pair积分绝对可积，故可逐pair作AC乘积并积分。

平台上first-hit和last-hit盒只差μ零集，固定a使其空间场相同，故没有稀释或能量跳。起点两种命中虽可能ρ(0)>R_B，盒仍与原盒μ-a.e相同且系数是固定a，故上述初值成立。终点first-hit可能ρ(U_B)<V_B，但与V_B盒只差μ零集，质量窗亦相同，故末值确是真实endpoint字段。U_B=0的父全程保留，初末贡献不被活子流删除。θ到达终端只停止，质量/窗连续；无退出项。

## 3. 完整pair能量身份与运输上界

T(x)=(1−|x|)_+。同一终端组内的pair能量为

a_Ba_C K_BC(u)T(d_BC(u))，
d_BC(u)=s_B+min(u,U_B)−s_C−min(u,U_C)。

乘积公式给精确E_end−E_start=C_cap+T_win。其中

C_cap=Σ_j∬_(E_j²) a_Ba_C ∫ T(d_BC(u))dK_BC(u)dBdC≥0，
T_win=Σ_j∬_(E_j²) a_Ba_C ∫ K_BC(u)d[T(d_BC(u))]dBdC。

C_cap是同一真实来源进入两个盒交集的pair价格；来源捕获在两父都进入后发生，可按其pair进入时钟写一次μ积分。此处保有序pair，系数与平方展开一致，不漏或另添2。

同j内|U_B−U_C|<h。d_BC只在两停止时刻之间变化，总变差<h，其终值d_end为两真实endpoint窗起点之差。窗运输非零必有|d_end|<1+h；K_BC(u)≤K_BC,end。因此

|T_win|≤h Σ_j∬ a_Ba_C K_BC,end 1_{|d_end|<1+h}dBdC。

令T_2(x)=(2−|x|)_+为长度2窗的原始重叠核（不是归一化tent），则indicator≤T_2/(1−h)。对每个真实来源y，长度2窗场恰是单位窗场加其平移1，故平方范数≤4倍单位窗平方。再积同一μ及组直和，严格得

|T_win|≤k_h B_end， k_h=4h/(1−h)。                         (P1)

没有额外G²、J或μ模量；所有这些仅在原本已有账及初值里保留。h<1/5使k_h<1，原h<1/6足够。进而

(1−k_h)B_end≤Q_grp/G²+C_cap。                             (P2)

(P1)是本轮可核准的完整endpoint运输吸收。反向亦可保精确有符号身份，但不可把C_cap当负费删除。

## 4. 与原完整目标的边界

该桥不需要F=A*或全动作平价，直接研究端点分组完整字段自身的平方；因此不能将固定F的原score输运也说成自动抵消。所有父已保留，解决了同步活时钟退出合场未计的问题，但新增C_cap的同来源重复仍未付。以帽或slow粗界仍可带A_n，(P2)不能单独宣称多对数B或完整根阶。

初值Q_grp/G²、完整母账的G²J及入口必须共同计算，不能在回代中把G²衰减单列为净收缩。R518中已丢弃的正空间增益若恢复为Credit，是既有正项的精确收据，不应再次当新不等式；尚待作者公式核对其真实来源/端点权。此PRE尚未认证未读作者的Credit定义。

## 5. 可复现代数与证据范围

指定本机Python -I已实际执行下列1008项Fraction检查：同组停止时差的运输幅度、endpoint邻近支持及吸收常数。K(u)取非减线性pair质量，只核pair代数；任意真实μ几何的证明在上文，不把该测试当L1立方体实例。早期另运行720项随机区间/活字段代数，仅为被停止分支的内部检查，不列本冻结PRE的重放计数。未运行MATLAB。

```python
from fractions import Fraction as F
from itertools import product
T=lambda x:max(F(0),1-abs(x))
checks=0
for h,b,c,d0 in product((F(1,12),F(1,8),F(1,6)),
                        (0,1,4,7),(0,1,4,7),
                        [F(k,2) for k in range(-3,4)]):
    U=1+h*F(b,8);V=1+h*F(c,8)
    lo=min(U,V);hi=max(U,V)
    diff=lambda u:d0+min(u,U)-min(u,V)
    nodes={lo,hi}
    if hi>lo:
        slope=F(1) if U>V else F(-1)
        for level in (-1,0,1):
            x=lo+(F(level)-diff(lo))/slope
            if lo<x<hi:nodes.add(x)
    nodes=sorted(nodes);transport=F(0)
    for x,y in zip(nodes,nodes[1:]):
        Kmean=(2+x+y)/(2*(1+hi))
        transport+=Kmean*(T(diff(y))-T(diff(x)))
    de=diff(hi);indicator=F(abs(de)<1+h)
    assert abs(transport)<=h*indicator;checks+=1
    assert indicator<=max(F(0),2-abs(de))/(1-h);checks+=1
    assert F(4)*h/(1-h)<1;checks+=1
print('PASS',checks,'Fraction endpoint-group transport, support and absorption checks; pair algebra only')
```

本PRE冻结，只待作者后审与最终输入绑定。一般capture来源预算、A_n及完整母账仍未闭合。


## 6. 主proof作者后审（PRE最终追加）

独立上述证明后已完整读r522_proof.md；读取时r522_geometry.md尚未出现，故本段不认证未读作者的pair/Credit正文，留最终九输入审查。主proof(1)—(4)及捕获粗界(2)未见阻断，尤其下述量词已核：

每个固定时刻、同一终端组内的实际phase共同；当u<jh全部同步，当u处于终端slab中已停父和未停父仍同phase，之后全部冻结。因此每组实际动作字段有C_*帽，系数降为a只减少正字段。这足以在有限时间分割的每个末时刻使用该帽，不将中途整个终端直和当完整实际场。

对capture上界，Δ(1_QB 1_QC)可被“B新壳×C末盒”与反向项控制。将窗Gram取分割末时刻后，积分另一父得到当前组字段，其与长度1父窗的配对≤C_*；两方向给2C_*∫a_BΔm_B。原连续窗与末窗之差随网格趋0，误差由固定输入的有限总捕获质量控制，所以不需在移动边界上调用一个未经定义的点值导数或μ-a.e帽。这个有限分割论证支持主proof(2)的常数2。

全域可积性另可直接量化：M_B≤μQ(B,b)，∫bulk M_BdB≤b^nW；a_B≤S/(Ga^n)，故∫a_B(M_B−m_B)dB有限。这些a,b,n常数只用于存在及换序，不是维数一致付款。pair交集与tent的AC乘积按有序双积分得到(1)，无需额外2；(3)的长度2原始重叠核及长窗平方4倍常数与独立核一致。h<1/6给κ_h<4/5。对固定F的score不能迁移平方对称性，主稿亦明确保留该限制。

(5)的H=Q_bulk−Q_group仅恢复被正性忽略的旧交集项，本身是恒等式/既有正项，非额外新付款。粗capture界仍有A_n，不能与G²J回代后宣称闭合。未重复主稿10644项代数脚本；本PRE只保其独立1008项pair检查及解析后审。

PRE现冻结。新增来源capture与Credit的联合容量、一般B预算及完整母账仍未付；待最终作者geometry/numeric及九输入冻结后，仅写final audit。
