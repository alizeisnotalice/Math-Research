#!/usr/bin/env python3
"""R522 exact synchronized-window Gram and real L1 inverse-mass paths."""
from fractions import Fraction as F
from pathlib import Path
import json,platform,sys,time
checks=0

def ck(test):
 global checks
 assert test
 checks+=1

def T(x):return max(F(0),1-abs(x))
def gram(starts,weights):return [[weights[i]*weights[j]*T(x-y) for j,y in enumerate(starts)] for i,x in enumerate(starts)]
def phase_gram(starts,weights,labels):
 g=gram(starts,weights)
 return [[g[i][j] if labels[i]==labels[j] else F(0) for j in range(len(labels))] for i in range(len(labels))]
def total(matrix):return sum(map(sum,matrix),F(0))
def shift(starts,deltas):return [s+d for s,d in zip(starts,deltas)]
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,list):return [serial(y) for y in x]
 if isinstance(x,dict):return {str(k):serial(v) for k,v in x.items()}
 return x

def algebra():
 starts=[F(0),F(1,3),F(7,6)];weights=[F(1),F(2,3),F(5,4)];base=gram(starts,weights);rows=[]
 for u in (F(-1,3),F(0),F(1,2),F(7,6)):
  common=gram(shift(starts,[u]*3),weights);ck(common==base)
  h=F(1,3);phase=u//h;aligned=shift(starts,[u-phase*h]*3)
  ck(gram(aligned,weights)==base)
  ck(phase_gram(shift(starts,[u]*3),weights,[phase]*3)==phase_gram(aligned,weights,[0]*3))
  rows.append({'u':u,'h':h,'common_phase':phase,'residual_shift':u-phase*h,'common_gram':common,'aligned_gram':gram(aligned,weights)})
 other=[F(0),F(1,2),F(-1,4)];different=gram(shift(starts,other),weights);ck(different!=base);ck(total(different)!=total(base))
 return {'initial_starts':starts,'unequal_weights':weights,'initial_gram':base,'initial_squared_norm':total(base),'common_shifts':rows,'different_shifts':other,'different_shift_gram':different,'different_shift_squared_norm':total(different)}

SOURCE=[(F(-1),F(1),F(1)),(F(3),F(5),F(1)),(F(7),F(8),F(2))]
def mass_interval(lo,hi):return sum((density*max(F(0),min(hi,right)-max(lo,left)) for left,right,density in SOURCE),F(0))
def mass(c,r):return mass_interval(c-r/2,c+r/2)
def inverse(c,r0,cap,target):
 if target>mass(c,cap):return None
 ck(target>=mass(c,r0))
 breaks=sorted({r0,cap}|{2*abs(edge-c) for left,right,density in SOURCE for edge in (left,right) if r0<=2*abs(edge-c)<=cap})
 roots=[]
 for a,b in zip(breaks,breaks[1:]):
  ma,mb=mass(c,a),mass(c,b);ck(mb>=ma)
  if ma==mb:
   if target==ma:roots.extend((a,b))
  elif ma<=target<=mb:roots.append(a+(b-a)*(target-ma)/(mb-ma))
 ck(bool(roots));lower,upper=min(roots),max(roots);ck(mass(c,lower)==target);ck(mass(c,upper)==target)
 return {'firsthit':lower,'full_equal_mass_interval':[lower,upper],'right_limit_of_firsthit_for_larger_target':upper if target<mass(c,cap) else None}

def geometry():
 centers=[F(0),F(1),F(4)];old=[F(2)]*3;caps=[F(16),F(12),F(8)];weights=[F(1),F(2,3),F(5,4)]
 m0=[mass(c,r) for c,r in zip(centers,old)];starts=[F(1,2),F(0),F(1,2)];ck(m0==[F(2),F(1),F(2)])
 ck(sum((d*(b-a) for a,b,d in SOURCE),F(0))==6)
 rows=[];h=F(1,3)
 for clockstep in range(4):
  u=F(clockstep,2);phase=u//h;ratio=F(2)**clockstep;active=[];radii={};paths=[]
  for i,(c,r0,cap) in enumerate(zip(centers,old,caps)):
   target=m0[i]*ratio;inv=inverse(c,r0,cap,target)
   paths.append({'parent':i,'target_mass':target,'cap_mass':mass(c,cap),'live':inv is not None,'inverse':inv})
   if inv is not None:active.append(i);radii[i]=inv['firsthit']
  source_intersections=[];actual=[];frozen=[];aligned=[];window=[]
  for i in active:
   source_row=[];ar=[];fr=[];al=[];wi=[]
   for j in active:
    intersection=mass_interval(max(centers[i]-radii[i]/2,centers[j]-radii[j]/2),min(centers[i]+radii[i]/2,centers[j]+radii[j]/2))
    spatial=weights[i]*weights[j]*intersection/(radii[i]*radii[j])
    actual_overlap=T((starts[i]+u)-(starts[j]+u));frozen_overlap=T(starts[i]-starts[j]);aligned_overlap=T((starts[i]+u-phase*h)-(starts[j]+u-phase*h))
    ck(actual_overlap==frozen_overlap==aligned_overlap)
    source_row.append(intersection);wi.append(actual_overlap);ar.append(spatial*actual_overlap);fr.append(spatial*frozen_overlap);al.append(spatial*aligned_overlap)
   source_intersections.append(source_row);window.append(wi);actual.append(ar);frozen.append(fr);aligned.append(al)
  ck(actual==frozen==aligned)
  rows.append({'u':u,'target_mass_multiplier':ratio,'h':h,'phase':phase,'residual_common_shift':u-phase*h,'paths':paths,'active_parents':active,'radii':radii,'source_intersection_mass_matrix':source_intersections,'actual_window_overlap_matrix':window,'actual_weighted_gram':actual,'frozen_window_weighted_gram':frozen,'phase_aligned_weighted_gram':aligned,'actual_squared_norm':total(actual)})
 ck(rows[0]['paths'][0]['inverse']['full_equal_mass_interval']==[F(2),F(6)])
 ck(rows[0]['paths'][2]['inverse']['full_equal_mass_interval']==[F(2),F(6)])
 ck(rows[1]['paths'][0]['inverse']['full_equal_mass_interval']==[F(10),F(14)])
 ck(rows[2]['paths'][1]['inverse']['full_equal_mass_interval']==[F(8),F(12)])
 ck(rows[2]['active_parents']==[1]);ck(rows[3]['active_parents']==[])
 return {'source_piecewise_density':[{'left':a,'right':b,'density':d} for a,b,d in SOURCE],'total_source_mass':F(6),'centers':centers,'old_side_lengths':old,'cap_side_lengths':caps,'parent_weights':weights,'initial_masses':m0,'initial_window_starts_log4_mass':starts,'time_rows':rows,'receiver_scope':'three fixed-center geometric paths, not Lebesgue receiver integration or a budget certificate'}

def terminal_group_transport():
 h=F(1,8);kappa=4*h/(1-h);ck(kappa==F(4,7));ck(kappa<1)
 cases=[
  ('probe',[F(1,16),F(3,16)],[F(0),F(3,4)],[F(1),F(2,3)],[F(1),F(2)],[[F(0),F(1,32)],[F(0),F(1,8)]]),
  ('pressure_zero_terminal',[F(0),F(1,8),F(3,16)],[F(0),F(3,4),F(-1,4)],[F(1),F(2,3),F(5,4)],[F(1),F(2),F(1,3)],[[F(0),F(0),None],[F(0),F(1,16),F(1,8)],[F(1,32),None,F(5,32)]]),
  ('expanded_adjacent_phases',[F(0),F(3,16),F(1,4),F(7,16)],[F(0),F(1),F(0),F(-3,4)],[F(1),F(2,3),F(5,4),F(3,2)],[F(1),F(2,3),F(3,2),F(1,4)],[[F(0),F(0),None,None],[F(0),F(1,16),F(1,8),None],[F(0),None,F(1,8),F(1,4)],[F(1,16),F(1,8),F(1,4),F(3,8)]])]
 out=[]
 for name,U,starts,a,sourcew,enter in cases:
  U=[u/2 for u in U];enter=[[None if t is None else t/2 for t in row] for row in enter]
  n=len(U);phases=[u//h for u in U];ends=[s+u for s,u in zip(starts,U)];pairrows=[];transport=variation=unit=longgram=supportsum=F(0)
  for i in range(n):
   ck(all(t is None or F(0)<=t<=U[i] for t in enter[i]))
   for j in range(n):
    if phases[i]!=phases[j]:continue
    ck(abs(U[i]-U[j])<h)
    overlap=lambda t:sum((w for w,x,y in zip(sourcew,enter[i],enter[j]) if x is not None and y is not None and x<=t and y<=t),F(0))
    distance=lambda t:starts[i]-starts[j]+min(t,U[i])-min(t,U[j])
    last=max(U);knots={F(0),last,U[i],U[j]}|{t for row in (enter[i],enter[j]) for t in row if t is not None}
    rough=sorted(knots)
    for left,right in zip(rough,rough[1:]):
     dl,dr=distance(left),distance(right)
     if dl!=dr:
      for kink in (F(-1),F(0),F(1)):
       if min(dl,dr)<kink<max(dl,dr):knots.add(left+(right-left)*(kink-dl)/(dr-dl))
    grid=sorted(knots);signed=tv=F(0)
    for left,right in zip(grid,grid[1:]):
     stepI=overlap((left+right)/2);change=T(distance(right))-T(distance(left));signed+=stepI*change;tv+=stepI*abs(change)
    Iend=overlap(last);dend=ends[i]-ends[j];indicator=F(int(abs(dend)<1+h));L2=max(F(0),2-abs(dend));factor=a[i]*a[j]
    ck(tv<=h*Iend*indicator);ck(indicator<=L2/(1-h));ck(abs(signed)<=tv)
    pairrows.append({'i':i,'j':j,'terminal_phase':phases[i],'terminal_distance':dend,'terminal_intersection':Iend,'signed_transport_without_coefficients':signed,'absolute_variation_without_coefficients':tv,'support_indicator':indicator})
    transport+=factor*signed;variation+=factor*tv;unit+=factor*Iend*T(dend);longgram+=factor*Iend*L2;supportsum+=factor*Iend*indicator
  ck(abs(transport)<=variation);ck(variation<=h*supportsum);ck(supportsum<=longgram/(1-h));ck(longgram<=4*unit);ck(variation<=4*h*unit/(1-h))
  out.append({'stage':name,'h':h,'kappa':kappa,'U':U,'fixed_endpoint_coefficients':a,'initial_window_starts':starts,'terminal_window_starts':ends,'terminal_phase':phases,'source_piece_masses':sourcew,'parent_capture_times':enter,'within_phase_pair_rows':pairrows,'signed_transport':transport,'absolute_transport_variation':variation,'terminal_unit_window_energy':unit,'terminal_length2_window_energy':longgram,'final_upper_4h_over_1minush_Bend':4*h*unit/(1-h),'cross_phase_terms_included':False})
 # Strict support endpoint: even at |dend|=1+h, unequal times in one phase cannot reach overlap.
 UB,UC=F(1,32),F(3,32);dend=1+h;d0=dend-UB+UC
 ck(T(d0)==0 and T(dend)==0);ck(abs(UB-UC)<h)
 return {'scope':'finite positive source pieces and monotone capture sets, fixed endpoint coefficients; exact window/Stieltjes algebra, not a new radial L1 or Lebesgue receiver model','h':h,'kappa':kappa,'strict_absorption_kappa_lt_1':True,'cases':out,'strict_support_boundary_check':{'U':[UB,UC],'d_initial':d0,'d_terminal':dend,'transport':F(0)}}

def main():
 start=time.perf_counter();a=algebra();g=geometry();terminal=terminal_group_transport()
 result={'scope':'exact finite window algebra and actual 1D L1 source/firsthit geometry only, no n-asymptotic or Lebesgue receiver budget','environment':{'executable':sys.executable,'python':platform.python_version(),'arithmetic':'fractions.Fraction, all masses/radii/window overlaps exact'},'algebra':a,'geometry':g,'terminal_group_transport':terminal,'checks':checks,'seconds':time.perf_counter()-start}
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),indent=2)+'\n')
 print('PASS',checks,'exact synchronized Gram, inverse paths and terminal-group Stieltjes checks')
 print('ACTUAL GEOMETRY NORMS',[(str(r['u']),str(r['actual_squared_norm'])) for r in g['time_rows']])
 print('DIFFERENT-SHIFT CONTRAST',a['initial_squared_norm'],a['different_shift_squared_norm'])
 print('ABSORPTION KAPPA',terminal['kappa'],'< 1',terminal['strict_absorption_kappa_lt_1'])
 print('TERMINAL GROUP TRANSPORT',[(r['stage'],str(r['signed_transport']),str(r['absolute_transport_variation']),str(r['final_upper_4h_over_1minush_Bend'])) for r in terminal['cases']])
if __name__=='__main__':main()
