# R522 主证明：同步质量时钟下完整端点字段的换窗费用吸收

## 1. 冻结对象和全父路径

沿用R520/521完整bulk及原来源μ=f dx、原t_B、原α、历史和真实Lebesgue父测度dB。旧边长r_B=R_B，全部bulk的合法端点V_B=G^(1/n)r_B≤b。记m_B=μ(Q_B)>0，M_B=μ(Q(B,V_B))，

\[
U_B=\log_\gamma(M_B/m_B),\quad j_B=\lfloor U_B/h\rfloor,
\quad s_B=\log_\gamma m_B,\quad a_B=\frac{t_B}{G r_B^n}.
\]

U_B在slow合同下统一有限，j_B∈{0,…,J−1}。预先按终端j_B划分真实父，不依赖被积来源点。零t允许并直接给零核。U_B=0父**仍在终端组0内保留**，不被删除。

对u≥0置θ_B(u)=min(u,U_B)。0<u<U_B时取真实质量首次达到m_Bγ^u的半径ρ_B(u)；u≥U_B取V_B，u=0可取r_B。质量连续保证命中，平台两端半径的源盒在μ意义下相同。U_B=0时起点r_B和终点V_B的μ差为零，所以两种约定给同一字段。可测性由有理半径的下确界构造。

不假设ρ_B绝对连续。它可跳跃或含奇异部分，但盒质量始终为m_Bγ^θ；对u<v，

\[
\mu(Q_{\rho_B(v)}\setminus Q_{\rho_B(u)})
=m_B(\gamma^{\theta_B(v)}-\gamma^{\theta_B(u)}).
\]

因此来源盒的L1(μ)变化在u上绝对连续；质量平台的半径跳没有新增源质量。

使用**固定端点系数**a_B，定义辅助直和字段

\[
A_{ij}(u;y,\sigma)=\int_{E_i^{\rm bulk}\cap\{j_B=j\}}
 a_B1_{Q_{\rho_B(u)}}(y)1_{[s_B+\theta_B(u),s_B+\theta_B(u)+1]}(\sigma)\,dB.
\]

同一终端组内，在u<jh时所有父同步；在[jh,(j+1)h)内逐个冻结；此后全部冻结。其当时真实相位相同，所以共同phase变更只重标坐标。不同终端组在中途可能处于同一真实phase，故这里的直和**不是中途完整实际场**。它只用于证明，不将其无价代入原母账。终点所有父冻结后，直和恰为完整合法端点动作场A_end。

途中a_B≤t_B/ρ_B(u)^n，因此每组字段有实际帽C_*；这不等于所有父中途仍保持原满权。原满权在端点恢复。初始

\[
E(0)=G^{-2}Q_{\rm group},\quad
Q_{\rm group}=\sum_{ij}\|L_{ij}^{\rm old}\|_2^2\le Q_{\rm bulk},
\]

其中L_ij^old保原旧核、仅按终端相位分组。终点E(∞)=B_end。没有删除父、无遗漏退出合场。

## 2. 完整平方身份

仅同一源格i、同一终端j的父对参与以下有序双积分。置

\[
I_{BC}(u)=\mu(Q_{\rho_B(u)}\cap Q_{\rho_C(u)}),
\quad d_{BC}(u)=s_B-s_C+\theta_B(u)-\theta_C(u),
\quad \tau(x)=(1-|x|)_+.
\]

I非减且绝对连续，因为其增量不超过两个真实盒质量增量之和；τ(d(u))亦绝对连续。对每父对作乘积公式并积分，得到

\[
B_{\rm end}=G^{-2}Q_{\rm group}+\mathcal C+\mathcal T,\tag{1}
\]

\[
\mathcal C=\sum_{ij}\iint a_Ba_C\int_0^\infty
\tau(d_{BC}(u))\,dI_{BC}(u)\,dB\,dC\ge0,
\quad
\mathcal T=\sum_{ij}\iint a_Ba_C\int_0^\infty
I_{BC}(u)\,d[\tau(d_{BC}(u))]\,dB\,dC.
\]

无额外因子2：这是完整有序父对公式。帐篷在折点不需经典导数，AC乘积及几乎处处导数足够。实际μ无时间进入原子；即使使用Stieltjes表述也不会遗漏半径平台跳。终端phase整体重标不改变组内平方。

所有积分有限：截断父域后公式直接成立，非负捕获可由实际帽和两边新增源质量给上界

\[
\mathcal C\le 2C_*\int_{\rm bulk}a_B(M_B-m_B)\,dB.\tag{2}
\]

可在有限时间分割中将交集新增分成B新壳∩C新盒和反向项，乘当前窗Gram并用每组帽，再取网格极限，得到(2)，不需要空间边界点值。总量有限由∫m_B、∫M_B对dB的Fubini有限性保证；这个有限性允许暂有指数几何常数，仅用于存在，不作为目标预算。下一节给T绝对可积的统一界，故可恢复完整父域。

## 3. 运输费用由同一个端点平方吸收

同终端组内|U_B−U_C|<h。d(u)只在两停止时刻之间变化，斜率绝对值≤1，总变差≤h。且|d(u)−d_end|≤h，其中d_end=(s_B+U_B)−(s_C+U_C)。有非零帐篷导数时|d(u)|<1，故|d_end|<1+h。I(u)≤I_end，因此

\[
|\mathcal T|\le h\sum_{ij}\iint a_Ba_C I_{BC}(\infty)
1_{\{|d_{\rm end}|\le1+h\}}\,dB\,dC.
\]

当0<h<1时，

\[
1_{\{|d|\le1+h\}}\le\frac{(2-|d|)_+}{1-h}.
\]

长度2窗的场等于长度1终端场与其统一平移之和，Hilbert三角不等式给其平方≤4B_end（不丢交叉项）。所以

\[
|\mathcal T|\le\kappa_h B_{\rm end},\qquad
\kappa_h=\frac{4h}{1-h}.\tag{3}
\]

原h<1/6保证κ_h<4/5<1。这里没有G²、J、A_n或输入绝对连续模量。于是对**全部bulk端点父**成立

\[
(1-\kappa_h)B_{\rm end}\le G^{-2}Q_{\rm group}+\mathcal C.\tag{4}
\]

这支付的是换窗运输，尚未支付C。它不依赖最优场、平价或概率底座。对固定投影F的score不能直接使用这种平方对称性，故不移用到R521的任意F输运项。

## 4. 保跨终端相位的原重叠信用

因为原核非负，

\[
\mathcal H=Q_{\rm bulk}-Q_{\rm group}
=\sum_i\sum_{j\ne k}\langle L_{ij}^{old},L_{ik}^{old}\rangle\ge0.
\]

该信用在R518曾通过Q_group≤Q_bulk被放掉；显式恢复并非一个新不等式。与(1)合并为

\[
B_{\rm end}=G^{-2}Q_{\rm bulk}
+\left(\mathcal C-G^{-2}\mathcal H\right)+\mathcal T.\tag{5}
\]

必须共同估计同终端phase新增交集正项与异终端phase旧交集信用；不能各自截帽后称重复收益已利用。geometry稿给C的每父对/每来源仅首次共同进入一次的准确公式，尚不提供跨父对统一容量。

粗用(2)和slow只有

\[
\mathcal C<\frac{2C_*}{G}\int t_Bq_B(K_B-1)\,dB,
\quad K_B=\max(1+u_0,A_n\alpha_i(B)),
\]

仍含A_n，代回原G²J母账不能闭合。本轮没有把这个粗界作为一般根阶付款。

## 5. 精确代数辅助

本机Fraction核帐篷支配、长2窗分解与Gram范数常数；数值稿另给增长真实交集的Stieltjes运输及平台诊断。有限代数不证明接收中心连续预算。

```python
from fractions import Fraction as F
from random import Random
rng=Random(522)
def tau(x,L=F(1)):return max(L-abs(x),F(0))
checks=0
for h in [F(1,32),F(1,16),F(1,8),F(1,6)]:
 for k in range(-80,81):
  d=F(k,32)
  assert (1 if abs(d)<=1+h else 0)<=tau(d,F(2))/(1-h);checks+=1
for trial in range(200):
 s=[F(rng.randrange(-16,17),8) for _ in range(7)]
 w=[F(rng.randrange(1,11),10) for _ in s]
 B=sum(w[i]*w[j]*tau(s[i]-s[j]) for i in range(7) for j in range(7))
 L=sum(w[i]*w[j]*tau(s[i]-s[j],F(2)) for i in range(7) for j in range(7))
 assert L<=4*B;checks+=1
 for i in range(7):
  for j in range(7):
   d=s[i]-s[j]
   assert tau(d,F(2))==2*tau(d)+tau(d-1)+tau(d+1);checks+=1
print('PASS',checks,'Fraction tent domination and complete long-window Gram checks; algebra only')
```
