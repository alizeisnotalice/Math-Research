"""R565 N8 exact interval partition / fractional packing certificate.
The score table is serialized numerical input, not an ideal-geometry certificate.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,hashlib,platform,sys,time,math

def exact_partition_certificate(n,score,chosen_intervals=None,total_bill=None):
    """score[(s,t)] uses half-open source indices [s,t), 0<=s<t<=n."""
    assert len(score)==n*(n+1)//2 and all(v>=0 for v in score.values())
    dp=[F(0)]+[None]*n;pred=[None]*(n+1)
    for t in range(1,n+1):
        for s in range(t):
            value=dp[s]+score[s,t]
            if dp[t] is None or value>dp[t]:dp[t]=value;pred[t]=s
    prices=[dp[t]-dp[t-1] for t in range(1,n+1)]
    assert min(prices)>=0
    for (s,t),value in score.items():assert sum(prices[s:t],F(0))>=value
    intervals=[];t=n
    while t:
        s=pred[t];intervals.append((s,t));t=s
    intervals.reverse();assert sum((score[p] for p in intervals),F(0))==dp[n]
    out=dict(exact_best_score=str(dp[n]),chosen_halfopen_intervals=intervals,prefix_DP=[str(v) for v in dp],atom_dual_prices=[str(v) for v in prices],all_interval_dual_constraints_exact=True,fractional_interval_packing_upper_exact=str(sum(prices,F(0))))
    if chosen_intervals is not None:
        chosen=[tuple(map(int,p)) for p in chosen_intervals]
        assert chosen[0][0]==0 and chosen[-1][1]==n and all(0<=s<t<=n for s,t in chosen) and all(chosen[k][1]==chosen[k+1][0] for k in range(len(chosen)-1))
        value=sum((score[p] for p in chosen),F(0));out.update(author_chosen_score_exact=str(value),author_chosen_regret_exact=str(dp[n]-value),author_chosen_exact_optimal=value==dp[n])
    if total_bill is not None:out.update(total_bill_serialized_exact=str(total_bill),weighted_bad_bill_table_exact=str(total_bill-dp[n]),bad_bill_table_nonnegative=total_bill>=dp[n])
    return out

def sha(path):return hashlib.sha256(open(path,'rb').read()).hexdigest()
def main():
    import numpy as np
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--n7',type=Path,default=Path(__file__).resolve().parent/'n7.json');parser.add_argument('--assembled',type=Path);parser.add_argument('--optimizer',type=Path,default=Path(__file__).resolve().parent/'optimizer.json');parser.add_argument('--n3',type=Path,default=Path(__file__).resolve().parent/'n3.json');args=parser.parse_args();start=time.perf_counter()
    n7=json.load(open(args.n7));assembled=args.assembled or Path(n7['assembled']['path']);z=np.load(assembled);orig=json.load(open(args.optimizer));n3=json.load(open(args.n3))
    assert sha(assembled)==n7['assembled']['sha256'] and sha(args.optimizer)==n7['input_hashes']['optimizer'] and sha(args.n3)==n7['input_hashes']['n3']
    order=list(map(int,z['source_order']));starts=list(map(int,z['starts']));ends=list(map(int,z['ends']));n=len(order)
    assert sorted(order)==list(range(n)) and order==n7['source_order'] and starts==n7['interval_starts'] and ends==n7['interval_ends']
    assert sorted(zip(starts,ends))==[(s,t) for s in range(n) for t in range(s+1,n+1)]
    parents=orig['summary']['frozen_parent_records'];states=orig['summary']['action_states'];P=len(parents);initial={s['parent']:set(s['receiver_atoms']) for s in states if s['kind']=='initial'}
    assert n==64 and P==332 and len(initial)==P
    old=np.array([[j in initial[p] for j in range(n)] for p in range(P)],dtype=np.int64);edges=n7['Li']['edges_integer'];assert edges==sorted({p['old_count'] for p in parents}|{2*p['old_count'] for p in parents})
    # Exact sum of serialized old amplitudes; no training or per-band field.
    Lexact=[[F(0) for _ in edges[:-1]] for _ in range(n)];amps=[]
    for p,parent in enumerate(parents):
        amp=F(float(parent['weight']/parent['R']**16));amps.append(amp)
        for j in initial[p]:
            for k,e in enumerate(edges[:-1]):
                if parent['old_count']<=e<2*parent['old_count']:Lexact[j][k]+=amp
    gamma=P*F(1,2**53)/(1-P*F(1,2**53));tau=F(1,18);maxLerr=F(0);margin=None;positives=0
    for j in range(n):
        for k,v in enumerate(Lexact[j]):
            hat=F(float(n7['Li']['L_values'][j][k]));err=abs(hat-v);maxLerr=max(maxLerr,err);assert err<=gamma*v
            assert (float(hat)>float(tau))==(v>tau)
            if v:positives+=1;margin=abs(v-tau) if margin is None else min(margin,abs(v-tau))
    assert np.all(z['D_high']>=0) and np.all(z['D_low']>=0)
    assert np.all(z['D_high'][old==0]==0) and np.all(z['D_low'][old==0]==0)
    prefix=np.c_[np.zeros(P,dtype=np.int64),np.cumsum(old[:,order],axis=1)];num=prefix[:,ends]-prefix[:,starts];den=np.array([p['old_count'] for p in parents])[:,None];expected_p=num/den
    assert np.array_equal(expected_p,z['p_H']) and np.all(z['D_H'][num==0]==0)
    maxperr=F(0)
    for d in sorted(set(int(p['old_count']) for p in parents)):
        for m in range(d+1):
            exact=F(m,d);rounded=F(float(exact));maxperr=max(maxperr,abs(rounded-exact))
            for eps in [F(1,2),F(1,4),F(1,8)]:assert (rounded>=eps)==(exact>=eps)
    rowaudit={};results={}
    for law,data in n7['results'].items():
        T=z['T_'+law];assert T.shape==(P,n,65) and np.all(np.isfinite(T)) and np.all(T>=0)
        rowexact=[sum((F(float(v)) for v in T[p].ravel() if v),F(0)) for p in range(P)];rowgamma=F(n*65,2**53)/(1-F(n*65,2**53));maxrowerr=F(0);maxr=F(0)
        for p,v in enumerate(rowexact):
            hat=F(float(data['row_mass'][p]));assert abs(hat-v)<=rowgamma*v;maxrowerr=max(maxrowerr,abs(hat-v))
            if v:maxr=max(maxr,v/(F(float(parents[p]['weight']))*F(float(parents[p]['q0']))))
        rowaudit[law]=dict(marked_row_tensor_nonnegative=True,positive_rows=sum(v>0 for v in rowexact),full_Q_normalizes_exactly_by_serialized_row_sum=True,maximum_float_row_sum_error_exact=str(maxrowerr),maximum_r_unit_diagnostic_display=float(maxr),K_unit_is_not_asserted_as_row_upper_bound=True)
        rr={}
        for key,record in data['parameters'].items():
            vals=z['score_'+law+'_'+key];assert np.all(np.isfinite(vals)) and np.all(vals>=0) and np.array_equal(vals,np.array(record['interval_scores']))
            score={(s,t):F(float(v)) for s,t,v in zip(starts,ends,vals)}
            cert=exact_partition_certificate(n,score,record['partition_rank_intervals'],F(float(record['total_weighted_high_bill'])))
            cert.update(c=record['c'],epsilon_serialized_exact=str(F(float(record['epsilon']))),author_float_best=record['paid'],exact_best_display=float(F(cert['exact_best_score'])),table_bad_display=float(F(cert['weighted_bad_bill_table_exact'])),scope='Exact optimum of serialized double score table only; q/D/eligibility and ideal score errors not enclosed.')
            # Each per-parent optimistic partition copies the entire source budget.
            loads=[0]*n
            for p,cut in enumerate(record['parent_optimistic_partitions']):
                assert cut[0][0]==0 and cut[-1][1]==n and all(cut[k][1]==cut[k+1][0] for k in range(len(cut)-1))
                if rowexact[p]>0:
                    for lo,hi in cut:
                        for k in range(lo,hi):loads[k]+=1
            assert loads==list(map(int,record['individual_parent_source_load']))
            duplicated=F(sum(loads),n);assert duplicated==F(float(record['individual_parent_duplicated_W']))
            cert['individual_parent_copied_source_cost_exact']=str(duplicated);cert['individual_parent_optimality_not_independently_certified']=True
            if 'bad_decomposition' in record:
                components={k:F(float(v)) for k,v in record['bad_decomposition'].items()};assert all(v>=0 for v in components.values())
                cert['author_bad_components_nonnegative']=True
                cert['author_bad_components_sum_exact']=str(sum(components.values(),F(0)))
                cert['author_bad_components_minus_exact_table_bad']=str(sum(components.values(),F(0))-F(cert['weighted_bad_bill_table_exact']))
            rr[key]=cert
        results[law]=rr
    out=dict(python=sys.executable,python_version=platform.python_version(),numpy=np.__version__,script_sha256=sha(__file__),input_n7_sha256=sha(args.n7),input_assembled_sha256=sha(assembled),input_optimizer_sha256=sha(args.optimizer),assembly_checks=dict(model=n7['scope'],source_count=n,old_parent_count=P,interval_count=len(starts),K_finite='unit only, not original row bound',tau_exact=str(tau),old_L_exact_nonzero_cells=positives,old_L_float_roundoff_gamma_exact=str(gamma),maximum_old_L_error_exact=str(maxLerr),minimum_positive_L_distance_from_tau_exact=str(margin),all_tau_high_low_classifications_match_exact_rounded_amplitude_field=True,p_H_maximum_rational_rounding_error_exact=str(maxperr),all_p_threshold_classifications_match_exact_source_counts=True,D_zero_off_old_support=True),row_audit=rowaudit,results=results,elapsed_seconds=time.perf_counter()-start,scope='Exact interval partition and fractional packing certificate for serialized scores. Primitive checks certify the stated finite surrogate structure; no original Lebesgue/history Li, Cstar marks, ideal score or root-order theorem.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
