"""R565 parent exact finite protocol checks; not a continuous theorem."""
from fractions import Fraction as F
from random import Random
from pathlib import Path
import json,sys,platform,time,hashlib
import sympy as sp

def check(seed,n,stages):
    rng=Random(seed)
    qw=[rng.randint(1,9) for _ in range(2*n)]
    pw=[rng.randint(1,9) for _ in range(n)]
    Q=[F(v,sum(qw)) for v in qw];P=[F(v,sum(pw)) for v in pw]
    X=[rng.random()<.7 for _ in Q];Z=[rng.random()<.7 for _ in P]
    p0=sum((p for p,z in zip(P,Z) if z),F());q0=sum((q for q,x in zip(Q,X) if x),F())
    delta0=p0*q0
    xi=[p0*q*x for q,x in zip(Q,X)];rho=[q0*p*z for p,z in zip(P,Z)]
    frozen=[[F() for _ in P] for _ in Q]
    eps=F(1,4);admitted=0
    for stage in range(stages):
        cut=sorted(set([0,n]+[rng.randrange(n+1) for _ in range(1+stage%4)]))
        for lo,hi in zip(cut,cut[1:]):
            old=list(range(lo,hi))
            # Same source cell, with an additional mark-dependent mass gate.
            recv=[j for j in range(2*n) if lo<=j%n<hi and hi-lo<=1+j//n+stage%3]
            a=sum((rho[k] for k in old),F());b=sum((xi[j] for j in recv),F())
            if not a or not b or max(a,b)<eps*delta0:continue
            den=max(a,b);admitted+=1
            old_before=rho.copy();recv_before=xi.copy()
            for j in recv:
                for k in old:frozen[j][k]+=recv_before[j]*old_before[k]/den
                xi[j]-=recv_before[j]*a/den
            for k in old:rho[k]-=old_before[k]*b/den
            assert min(xi+rho)>=0 and sum(xi,F())==sum(rho,F())
    delta=sum(xi,F());joint=[row.copy() for row in frozen]
    if delta:
        for j in range(2*n):
            for k in range(n):joint[j][k]+=xi[j]*rho[k]/delta
    for j in range(2*n):assert sum(joint[j],F())==p0*Q[j]*X[j]
    for k in range(n):assert sum((joint[j][k] for j in range(2*n)),F())==q0*P[k]*Z[k]
    maxrn=F()
    for j in range(2*n):
        for k in range(n):
            rn=frozen[j][k]/(Q[j]*P[k]);maxrn=max(maxrn,rn)
            assert rn<=2/eps*X[j]*Z[k]
    Li=[F(1+k,2+k) for k in range(n)]
    for weights in [Li,[1/v for v in Li]]:
        before=sum((Q[j]*P[k]*X[j]*Z[k]*weights[k] for j in range(2*n) for k in range(n)),F())
        after=sum((joint[j][k]*weights[k] for j in range(2*n) for k in range(n)),F())
        assert before==after
    return dict(n=n,stages=stages,seed=seed,blocks=admitted,delta0=str(delta0),terminal=str(delta),max_RN=str(maxrn))

def main():
    start=time.perf_counter()
    cases=[check(565000+100*g+s,n,t) for g,(n,t) in enumerate([(3,4),(6,10),(8,24)]) for s in range(8)]
    A,zeta,a,L,C,W,Q=sp.symbols('A zeta a L C W Q',positive=True)
    # Qg <= A(zeta+a/zeta)Qg + (C+A*L/zeta)W.
    solution=(C+A*L/zeta)*W/(1-A*(zeta+a/zeta))
    residual=sp.factor(solution-A*(zeta+a/zeta)*solution-(C+A*L/zeta)*W)
    assert residual==0
    out=dict(python=sys.executable,python_version=platform.python_version(),sympy=sp.__version__,cases=cases,
             exact_fixed_initial_relative_threshold_RN_and_both_margins=True,
             exact_original_cut_mass_Li_inverse_Li_terminal_preserved=True,
             symbolic_mother_residual=str(residual),seconds=time.perf_counter()-start,
             scope='24 exact finite rational cases plus symbolic algebra. General cumulative RN bound requires the separately audited proof; no U capacity or terminal decay theorem is inferred.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
