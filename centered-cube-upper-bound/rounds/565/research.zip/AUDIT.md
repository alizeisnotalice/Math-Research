# R565 final audit ledger

General root-order theorem remains OPEN. Core final form uses the original cut first, and the fixed initial delta0 threshold; earlier full-high or absolute-threshold versions are valid alternatives, not the final combined route. The 2/epsilon cumulative density estimate is independently audited; union capacity and terminal payment remain unproved. No unreviewed all-action lower-bound draft is used.



---

## audit.md

# R565 独立初审：完整加权余账的多尺度耗尽与递归

本轮仅先读 `/tmp/ccu_r565_contract.md`，使用已独审的 R564 固定共同族 mass-cap 作为输入，不先读作者新稿。目标是原任意非负 L1 方体问题；此文只交审查标准和关键障碍，不声称已构造全局分配。

## 1. 冻结对象和正确收缩量

沿原完整 dM、原 Li、所有 old/new、实际 ordered head/stop/core、phase/σ 窗。常数 a=1/K，K=GC*Λ，Fcap=GC*。低增长 new 与低 Li 已互斥剔除，直接 Cstar 费用≤(K+Fcap)W。剩余 R=Nδ^c∩{Li>τ}，τ=1/Dclk。完整来源费是

 V=K∫_R dM/Li。

原始信用只有 Qfr≤Qg 一份；R 的 Cauchy 信用≤(1/K)∫Li dM≤Qg。后续分析可用来源信息，不能改共享动作或重算 Li/alpha。

固定共同族的 matched-block 坏账必须保留

 K∫r_B [D_B^τ−Σ_{max(p_BH,q_BH)≥ε} min(1,q_BH/p_BH)D_BH^τ]dB

及所有原 R 限制。在已定义精确分支里，p=0 项按0处理；D_BH 包含旧 σ 和原 1/Li。只有该加权积分减少才是所需进展。未匹配概率或 μ 质量减少本身不推出它减少；高 Li 截断仅控制1/Li上界，不给所有来源之间的统一可交换权重。

最弱可用收缩不必逐 B 或逐来源成立。证明全局实际加权不等式即可；逐 B 收缩是较强充分条件，不应作为额外不必要要求。

## 2. 三类足以闭合的准确合同

### 2.1 同一余账的真实分解与收缩

若确实有同一费用的非负恒等式 V=P+Vres，且

 P≤A W， Vres≤ρV， 0≤ρ<1，

则立即 V≤A W/(1−ρ)。这里第二式必须针对包含原 1/Li、全部旧窗和所有不合格/小块的 Vres，不能改成概率收缩。A 与 (1−ρ)⁻¹ 的全部参数要进入母账；只有它们统一满足所需维数阶时才算达到目标。

这一步不需要无限迭代。若作者只给 V=P+Vres、P≤AW、Vres≤V，则收缩系数仍为1，不能闭合。

### 2.2 带折扣的递归

若递归为 V_j≤A_j W_j+ρ_j V_(j+1)+E_j，则对有限 N 必须先证明

 V_0≤Σ_{j<N}(∏_{k<j}ρ_k)(A_j W_j+E_j)+(∏_{k<N}ρ_k)V_N。

所需是整个加权和受控，以及最后一项趋0或有明确可付上界。常数 A、ρ<1、W_j≤W、E_j=0 时几何和支付 A W/(1−ρ)；这种真实折扣可合法处理同一 W。反之，按原始划分 V_j=P_j+V_(j+1) 每层只知道 P_j≤AW，会产生 N AW，没有折扣。

终端不能因“每个点最终被切开/匹配”就删除。需对真实费用使用单调/支配收敛或给显式终端估计；特别保留1/Li、σ范围和无限层归一化。若递归始终是原固定有限时钟费用的正子测度，可以引用同一粗有限上界来控制终端；若对子问题重标尺度或时钟，必须重新支付其 Dclk、qband、action 参数和重标费用。不得把随深度增长的终端当作统一有界。

### 2.3 原信用直接吸收

允许另证原完整剩余 Cstar 的直接估计。若最终得到 2Cstar≤ζQg+L W（加上已明确剔除的直接费用），严格条件为 ζJ/d²<1。分阶段信用预算必须先合并：不能每层重用一整份 Qg 而不把所有 ζ_j 累加。质量型 V 收缩与 score 型直接吸收是不同充分路线，不可交叉省掉未付项。

## 3. 多次 coupling 必须有真实耗尽状态

R564 两边缘保持的完整 relift 对常数 a 的总信用及 V 都不变。若每轮都从完整 P_B,Q_B 重新配对，再把每轮的 paid mass 相加，同一旧来源会被重复计付；这不是耗尽。

合法递进的一种表示是始终维护共同扩展测度上的未处理标记，paid 标记互斥，且来源 score 的总使用边际被原 score 支配。另一表示是每个 B 的残余双边缘次概率 Pbar_j,Qbar_j，具有同一质量 δ_j；matched 部分从两边同时扣除。

若将残余重新独立耦合，正确 joint 为

 Γres=Qbar⊗Pbar/δ，δ>0；δ=0 时 Γres=0。

它总质量为δ且边缘正是Qbar、Pbar。写成归一概率时是δ·(Qbar/δ)⊗(Pbar/δ)，不是无权的两归一概率。相对原 Q⊗P 的密度为 qbar·pbar/δ；这项1/δ及后续 block RN 不可丢失。保留次概率总量并不自动保留 R564 原 product measure 的 capacity 上价；必须证明当前 paid 部分受原可付事件以何种密度支配。

单个 max-match block 的 RN=1/max(p,q)，故 threshold ε 带来1/ε费用。多层 residual 后，threshold 需说明针对原概率还是归一残余概率，密度账也必须按同一基准计算。不能在小剩余里宣布“条件比例很大”却漏掉归一化及旧 σ 相关性。

若来源耗尽状态记为θ_j(B,z,σ)，0≤θ_(j+1)≤θ_j≤1，则真正余账应写成原 k_B/Li 对该状态的积分；只维护按空间 z 的概率而忽略被选 σ 仍不足。完整 credit 也应由原 Li k_B 对全部阶段的用量积分统一控制。

## 4. 共同多尺度族的来源预算和方体机制

R564 mass-cap 允许每次一个共同 μ-互斥族，并以 cLcl(K)ΣμH 付款。固定 j 的族能用一次 W，不意味着所有 j 能各用一次 W。以下任一真实机制才可能完成跨尺度支付：

- 全部被选节点/簇的累计加权质量（含 c、RN、threshold 因子）满足一个一次来源预算；
- 来源互斥的真实 stopping front，每条来源路径只触发总权重可求和的付款；
- 与完整加权来源费相联的势差，所有 merge/recapture/variation 项有可求和预算；
- 第2节的真实统一收缩或原 score 吸收。

若只是全局随机选一个尺度，概率混合Σπ_j=1能保一次W；但 coverage是p_mix=Σπ_jp_j。即使每对在某一尺度被捕获，也不能推出p_mix统一下界。无折扣地逐尺度轮换与概率混合是不同机制，不能互换其预算。

按原父 B 或 receiver 单独挑选“最适合的簇”可能复制相同来源；它不是固定共同族引理的自动适用情形。作为分析选择并非一概禁止，但须提交新的累计来源/中心容量证明，不能直接引用旧 mass-cap。

当前 mass-cap 的中心体积步骤本身仅用同胚放大体积，未提供方体维数改进。决定性新增机制必须确实使用原方体的同时坐标约束、切分相容性或实际 capture/mass 增长与旧 score 的联合关系，并将得到的增益带入完整余账。不能仅把一维体积势改名为 coordinate potential。独立辅助随机坐标不要求真实 μ 坐标独立；反过来，也不能因辅助坐标独立就将真实来源测度因子化。

若使用树势 Φ，必须给实际森林、来源流和真实费之间的 domination，并核

 paid_j≤Φ_j−Φ_(j+1)+merge_j+variation_j+其他已列费用。

仅证明抽象有限树望远镜身份不等于这条domination。Phi初值、终值和所有正补偿项都须受一次W或已分配原信用控制。旧 Li 权重或σ负载如果不在Phi中，必须有另一个已付转换步骤。

## 5. 量词、截断与下轮决定性检查

全部常数应对任意正 L1 输入、全部真实可测半径和允许历史统一；不能隐含坐标独立、来源密度帽、有限深度、父数、输入最小质量、或训练离散点的统一下界。可先有限截断，但应保留原冻结score与动作，证明截断控制和终端过程；不能每个截断重算alpha后把结论传回原对象。

收到具体稿后将只核：实际残余是什么；新 paid fee 与原 mass-cap 的密度/共同族接口；真正缩小的是否完整weighted deficit；所有旧窗、零概率、ineligible mass、merge和terminal；折扣/吸收常数及其母账代价。优先修复决定性缺口，不做泛反例扫描。

当前已完成的是独立审查标准，没有新作者稿已被审阅，也没有多尺度收缩已被证明。现实际等待 core/cover/generator 的具体关键式；不以等待冒充正在证明全局构造。

## 6. 本机辅助计算

指定本机 Python/SymPy 已实跑：单步(1−ρ)V≤AW的吸收残差0；有限折扣和返回(1−ρ^N)/(1−ρ)（ρ=1时返回N）；残余product/δ的总质量返回δ、单边缘因子返回1。仅验证这些准确代数身份，不证明全局几何/加权收缩。

## 7. 正式独审：逐步冻结的累计 RN 界及预截断原余账

按父代理的新明确任务，独立核验概率/次概率命题后，读 proof.tex 的 S7–S16 和 potential.tex 的 P8–P10b；此处只审累计冻结主张及其原母量接口，不把其他命题自动记为通过。

### 7.1 先截原 R 再重配：归一化 PASS

对每个非零原父 B，Q_B、P_B 为原完整 marked 概率。原已剔除直接项后的 R 可写 X_B(x)Z_B(z,σ)：X保原 receiver 的低增长-new补集，Z=1_{Li>τ}。设 q0=Q_BX、p0=P_BZ，δ0=p0q0。

正确初始化为 ξ0=p0 Q_B|X、ρ0=q0 P_B|Z。二者质量都为δ0，且δ0>0时

 ξ0⊗ρ0/δ0=(Q_B|X)⊗(P_B|Z)，

恰为原截断积，未多乘或少乘p0/q0。若p0q0=0，该父在原 R 的全部物理贡献为0，直接略去，不定义0/0。原 physical 总因子仍为 r_BT_B，其中 T_B=t_Bq_B；不是 r_BT_B/δ0。

固定原母量后，R的总质量是r_BT_Bδ0，旧信用是(r_BT_B/K)∫Li dρ0，逆场来源费是Kr_BT_B∫(1/Li)dρ0。以上两个来源积分都在Z上，不能把旧信用误写成整份e_B等式；其值≤(r_B/K)e_B。先以完整Q⊗P重配，再删X会产生S16的mixed covariance；预截断初始化避免了它，不能把两条路线混写。

### 7.2 每步核与累计2/ε：PASS

设残余ξ_s、ρ_s为等质量次概率，都是初始边缘的正子测度。一个共同簇H的receiver资格为E_H（全部真实mark保留），令a=ρ_s(H)、b=ξ_s(E_H)。对a,b>0冻结

 Π_s=(ξ_s|E_H⊗ρ_s|H)/max(a,b)。

其总质量min(a,b)，旧边缘为[min(a,b)/a]ρ_s|H，接收边缘为[min(a,b)/b]ξ_s|E_H。扣除后两侧仍正且等质量。一个front内簇互斥时可同时扣除；任意多个front则按实际剩余边缘顺序处理，不能用旧边缘批量重扣。

令f_s=dξ_s/dQ_B、g_s=dρ_s/dP_B。密度为f_sg_s1_E1_H/max(a,b)。当b≤a，接收侧选中部分被完整移除，故以该侧密度下降Δf_s控制；当a<b，旧侧选中部分完整移除，以Δg_s控制。两类分别望远镜，ΣΔf_s≤f0、ΣΔg_s≤g0。

因此对于绝对阈值max(a,b)≥ε，由f_s,g_s≤1有

 Σ_s dΠ_s/d(Q_B⊗P_B)≤2/ε。

proof S9和potential P10b均正确，两稿a/b命名互换已明示，不影响核或清空侧。只须审查者始终按实际定义判断哪侧被完整移除。

core随后给出的固定初始相对阈值max(a,b)≥εδ0同样有效，而且保留同样最终常数。因为f_s≤p0 1_X、g_s≤q0 1_Z，接收清空类满足RN≤q0 Δf_s/(εδ0)，旧清空类满足RN≤p0 Δg_s/(εδ0)。因此

 Σ_s RN≤[q0 f0(x)1_Z+p0 g0(z,σ)1_X]/(εδ0)
       =2·1_R/ε。

此阈值的δ0必须是该原父的冻结初始cut质量；若替成当前δ_s，分母随s变化，以上望远镜不再给该统一常数。绝对阈值与固定初始相对阈值都是已核版本，不应将后者误写为任意动态relative threshold。

### 7.3 信用、逆场与countable terminal：PASS，消失仍OPEN

任意有限N以Π_term,N=ξ_N⊗ρ_N/δ_N（δ_N>0）补齐，零质量时取0。所有冻结块加终端的边缘精确为ξ0、ρ0，并仍支撑于原X×Z。因此原R的总质量、完整原旧Li信用以及逆场费用全保留；阶段使用的是已移除的旧边缘，不新增score。

对积分后的物理量，精确恒等式为

 Σ_s<N Kr_BT_B∫Li⁻¹ d(旧边缘Π_s)+Kr_BT_B∫Li⁻¹dρ_N
 =Kr_BT_B∫Li⁻¹dρ0，

相应信用将系数改为r_BT_B/K、integrand改为Li。旧逆场费用与信用的系数不同；不能只换integrand。全父积分后信用≤Qg，仍只有一份。

可数步骤的正冻结和有定义。残余ξ_N↓ξ_∞、ρ_N↓ρ_∞，等质量δ_N↓δ_∞；有限初始边缘保证测度连续性。若δ_∞>0，补ξ_∞⊗ρ_∞/δ_∞；若为0取0。冻结和与这个真实终端仍恢复初始cut边缘。Z上1/Li≤1/τ，所以每父逆场终端可直接由有限边缘连续性求极限。全父积分需有限物理支配或正项恒等式/受控耗尽，不能写∞−∞。

保留终端使countable账完整，但尚未证明终端为0或达到uniform付款。原R的受控有限截断上可用其原粗有限费支配；完整L1 passage必须保留原参数和控制尾项。稿中S11–S14及P9–P10a正是这种保留terminal的合法账，不是已证终端消失。

### 7.4 累计密度与联合几何容量严格区分

令U为所有实际冻结资格事件所在的几何union。上述估计仅得

 V_frozen≤(2/ε)∫_{R∩U} K dM/Li。

可以使用比实际support更大的全stage eligible union作为上界，但不能因它是一个union就调用一次“共同互斥H族”mass-cap。不同front的祖先、后代及重叠簇不是单一μ-disjoint family。将每stage的cLclW直接相加仍可能发出每层W。

S10、P10c对该未证接口的说明正确。该累计2/ε是真正的跨步骤密度控制，已消除一个潜在的重复系数费用；它本身不证明U的联合容量，也不证明小block/ineligible terminal耗尽。两者保持OPEN。未由此输入新的完整母账常数或root-order结论。

### 7.5 有限精确工具检查（非几何证据）

指定Python/Fraction实跑一个固定三点概率例，仅核两边缘代数：原cut质量5/12，冻结两个admitted blocks后terminal=1/24；接收/旧边缘残差全部0；Li及1/Li加权账残差均0；累计冻结product RN最大2，固定初始相对ε=1/5的上界为10。未扫描参数，未把该抽象概率例当作真实方体或全局容量证据。

当前proof/potential累计命题已PASS；等待core实际稿落盘核其最终母量/阈值/范围措辞，不扩其他题。

### 7.6 core 实际定稿逐式末审与冻结

已读取落盘 `/tmp/ccu_r565_core.tex` 全文。式(2)–(3)的初始cut次边缘、式(5)的固定εδ0阈值、式(7)的累计原product RN、式(8)–(10)的原R信用/逆场/真实terminal均与独立证明一致，PASS。有效父排除零r_B、零T_B，δ0=0分支单列。所有逆Li表达式按其Z支撑解释，等价于使用1_{Li>τ}/Li并在外部取0；不在Li=0处定义除法。

式(11)两种界各自准确：累计密度给2V_R(U_N)/ε；同一stage的各块支撑互斥，单块RN≤1_R/ε，所以逐stage mass-cap给NcLcl(K)W/ε。作者明确N不能删除，也明确U_N不是一份共同互斥族，未偷用capacity。

式(12)对预截断后的质量带常数也正确。由a≤p0Fcap·μH/(r_Bm_B)、b≤q0μH/m_B和max(a,b)≥εp0q0，得

 μH≥εm_B min(p0,q0r_B/Fcap)。

存在真实eligible mark又给μH≤cM_C(v)<cγM_B(g)≤cγKmaxm_B。此质量带没有被当作跨父、跨旧层的累计预算。

式(13)是尚未证明的充分桥；其aQ_g付款要求2J√a/d²<1，不能只要求a<1。式(14)在a=0下的条件母账系数正确，保留原direct系数K+Fcap、J²来源费放大及原b0和外层Dclk。

最终判定：累计冻结密度命题、原R预截断归一、同一旧信用和countable terminal完整账均PASS，无数学修复项。联合eligible union容量与weighted terminal消失/付款仍OPEN，作者正确未宣称一般目标闭合。本轮审计至此冻结并停止；不重复有限DP，不扩其他研究，不改作者/repo/PDF。


---

## ledger.md

# R565 完整递归的统一费用与可吸收系数

范围：原adaptive动作、原Li/alpha、完整ordered父对及所有stop/core/phase/window均冻结。只审实际完整递归／吸收，不把更多局部分支视为净改善。S=0零流单列。只编辑本文件，不做新求解、repo或PDF操作。

## 1. 冻结的完整母账与实际入口

Fcap=GC*，K=Fcap(2+lnG)，A=J/d²，B=2Brem/d，d=1−3h。先原new低增长N={new,κ−1≤1/(SA_n)}，再N^c低Li≤1/Dclk；完整直接Cstar费≤(K+Fcap)W。余下R=N^c∩{Li>1/Dclk}，原插入dM不变，a=1/K，dV=K1_R dM/Li。唯一原信用为P_R=K^-1∫R Li dM≤Qg。

若沿用R564质量簇front的高p分支，固定同一对(p_c,cLcl)，则已付V部分≤cLcl W/eta，初始待递归量

    V_0=Vrem=∫R 1_{p_c<eta}dV。

Lcl=2GΛgamma³/(gamma−1) S r_band K[4+2h+log_gamma max(gamma^h,A_n)]。c=gamma时包括mass-admissible的部分外旧；wholecell旧规则是替代，不额外叠一份LclW。若作者直接递归整个V_R，则不再另加这笔高p费。两种入口必须二择一。

以下以递归Vrem为固定入口，保留cLcl/eta。原末端Q≤Qg/b0²、R*≤2sqrt(DclkWQ)及入口/初始/删除历史/全尺度/终端费用原样保留。

## 2. 可以验收的统一递归：阶段费用必须带真实pullback

候选须给非负实际加权对象V_j与联合可测原marks，并证明完整一步

    V_j ≤ q_j V_{j+1} + L_j W + ∫b_j(B)dQfr(B) + T_j，    (Rec)

T_j≥0含所有真实transition/merge/recapture/variation及未入主front的补集。q_j不是标记匹配比例的代称，必须是此加权不等式中已证明的系数。令t_0=1，t_j=prod_{l<j}q_l，则严格有限展开为

    V_0≤Σ_{j<N} t_j L_j W
          +∫[Σ_{j<N}t_j b_j(B)]dQfr(B)
          +Σ_{j<N}t_j T_j+t_N V_N。                   (Unroll)

若transition或terminal有source／credit上界，先实际加入对应两项；不能因名字叫误差而删去。只在共同原source容量／原score负载下进行Tonelli，不能每阶段重新把原Qg视为一份独立资源。

完整可付款条件是存在统一L_rec,a_rec，使所有N与输入满足

    Σt_j L_j + source-transition + source-terminal ≤ L_rec，
    Σt_j b_j(B) + credit-transition(B)+credit-terminal(B) ≤ a_rec

对原Qfr几乎处处成立，并且剩余terminal趋0；或直接证明相应全局积分≤a_rec Qg（比逐父条件弱而仍充分）。若仅各stage credit_j≤Qg，则可保证的总系数是Σt_j a_j，不能偷换成max a_j。只有原score密度真实联合分配时才可用max系数。输出source／cluster互斥并不自动分割旧score。

若直接证明同一原费用V_0=Paid+Vres，Paid≤LW且Vres≤qV_0（完整weighted、含所有补集），则立即V_0≤LW/(1−q)，不需无限递归；普通匹配概率的q不能代入。

常用充分情形：q_j≤q<1，L_j≤L，a_j≤a，且所有其他发票亦有同权可和上界，则source费≤L/(1−q)，credit系数≤a/(1−q)。q接近1的损失必须保留；q_n=1−1/n不提供polylog代价。每stage cluster门槛epsilon_j给出的真实费用是c_jLcl/epsilon_j，故应审核Σt_j c_j/epsilon_j，而不是只看q<1。例t_j=q^j、epsilon_j=q^{aj}且c_j统一有界，仅a<1时这一几何级数可和；a≥1不能凭收缩率免去密度债。

## 3. terminal与“普通质量收缩”的区别

原未改插入有完整粗上界Vrem≤K²DclkW；经过条件lift、front重标或放大后，不能自动将此上界原封继承。作者必须证明V_N仍是原正子项（或给明确支配常数）才能使用它。

若确有t_N≤q^N及V_N≤K²DclkW，则可在

    N≥ceil[log_+(K²Dclk/epsilon)/log(1/q)]

后把terminal付为epsilon W。若T_j含跨front合并或者源被反复捕获，terminal也必须保这些原标签；不能只结树叶而遗漏未分配残流。无穷极限采用非负有限展开与实际统一界，不用∞−∞。

若只有原残余的普通mass下降，不能推出V=K∫dM/Li同率下降。高源区域仅知tau<Li≤C0时，粗转换的条件数可达C0/tau=C0Dclk；小匹配概率缺损不是加权缺损。只有证明真实dV残量下降／原旧边际带权支配，才有可用q。匹配RN 1/max(p_BH,q_BH)及原两个质量分母也必须保留。

若作者只有精确分解V_j=Paid_j+V_{j+1}，每阶段Paid_j≤L W，则累计价是NLW，不能写成LW或L/(1−q)；该分解没有(Rec)的q pullback。即使另证真实weighted residual收缩并有限截断到N=O(log n)，也必须显示NL、terminal与每次完整front的实际合法性，才可评价这个有限polylog方案。不可凭每层局部lemma无损重发W。

## 4. source借原score的准确阈值

完整Unroll若最终给

    Vrem≤a Qg+L_rec W，
    L_tot=cLcl/eta+L_rec，

则剩余Cstar桥为

    Cstar≤(K+Fcap)W+sqrt(a Qg²+L_tot QgW)。             (Bridge)

source侧用了Qg也不是免费：它在母账产生二次Qg²项。设C=2A(Kw+K+Fcap)+B，x=Qg/W，则

    x≤C+2A sqrt(a x²+L_tot x)。

统一吸收的严格门槛是

    2A sqrt(a)<1，即a<d⁴/(4J²)。                       (Threshold)

对任意ζ>0，准确Young式为

    x≤[C+A L_tot/ζ]/[1−A(ζ+a/ζ)]，
    A(ζ+a/ζ)<1。                                      (Y)

可行ζ区间由二次式Aζ²−ζ+Aa<0决定；不能仅要求ζ<d²/J而漏a/ζ。若a=0，恢复R564唯一信用桥与J²L_tot/d⁴费用。若a>0，最小信用系数在ζ=sqrt(a)为2A sqrt(a)，正是(Threshold)。

最佳直接二次根为

    x≤[C+2A²L_tot
          +2A sqrt(a C²+C L_tot+A²L_tot²)]/(1−4A²a)。   (Best)

最终Q/W≤b0^-2 x，R*/W≤(2/b0)sqrt(Dclk x)。要保根阶目标，不能只使a落在门槛内而距门槛趋0：还需(1−4A²a)^-1、L_tot及全部冻结参数的总损失符合所需polylog／n^o(1)预算。

若此外某完整正余费直接为c_dir Qg+D_dir W，则C加2A D_dir，严格门槛变为

    2A(c_dir+sqrt(a))<1。

这是只知两个完整Qg比较时的安全统一阈值。若确实证明direct、P及source-credit的原score联合分配，可再按真实分配优化；不能凭source互斥直接把和改为max。母账不另发一份Qg。

## 5. 当前验收与工具

实际本机Python3.12.14/SymPy1.14.0已精确核验：(Best)代入边界二次式残差0；ζ+a/ζ在sqrt(a)导数0且值2sqrt(a)；统一几何递归源和为L(1−q^N)/(1−q)+q^N terminal。计算仅验证代数，未证明任何新的cube weighted contraction。

净改善必须是整个Vrem的统一付款或门槛内完整oldcredit系数，含transition及controlled terminal。只新增匹配正分支、普通mass下降、保持边际恒等或有限forest望远镜均未通过此验收。待core/generator决定性式，只核具体一条组合，不扩大扫描。


## 6. 接generator／proof关键式：当前可回代量与真实缺口

已读 /tmp/ccu_r565_potential.tex。其共同median-coordinate fronts是真实μ互斥族，但固定epsilon下，对每个r_B>0的父，front质量最终小于epsilon m_B min(1,r_B/Fcap)，所有max(p_BH,q_BH)均低于epsilon。因此重新独立评价细front的大块matched deficit最终等于原完整Kr_B D_B^tau，积分终端回到Vhi。它严格否定此特定“细化后terminal自动为0”的做法，不否定全部multiscale构造。

其冻结协议则真实保留残余次概率边际nu_B,k≤Q_B、rho_B,k≤P_B，相同总质量t_B,k；阶段block为

    Pi_B,k,H=nu_B,k|eligible H ⊗ rho_B,k|H / max(a_B,k,H,b_B,k,H)，

余边际同时扣除，terminal为nu_B,N⊗rho_B,N/t_B,N（零mass取0）。所有frozen block加terminal的两边际精确为原Q_B,P_B，故inverse账守恒。实际a=1/K的score总量必须准确写为

    Σstage+terminal [r_B t_Bq_B/K ∫Li d(old marginal)]
        =(r_B/K)e_B≤e_B。

inversefee系数是Kr_Bt_Bq_B；把inverse积分的J替换为Li之后，score系数相差K²，不能只再乘1/K。此归一修复已反馈作者。所有阶段合计只用原Qg；不是每stage重新发Qg。

它提出的准确充分条件是对确定性共同theta_k，同时

    nu_B,k≤theta_k Q_B，rho_B,k≤theta_k P_B，
    max(a_B,k,H,b_B,k,H)≥epsilon theta_k，Σtheta_k<∞。

这样两残余密度相乘除以block门槛，实际RN≤theta_k/epsilon，stage source费用≤(cLcl/epsilon)theta_k W；terminal≤theta_N Vhi。若实际front对所有原截断统一实现该条件，则完整

    Vhi≤Lfreeze W，Lfreeze=(cLcl/epsilon)Σtheta_k。       (Freeze-target)

这会是真净容量进展。theta_k=q^k时Lfreeze=cLcl/[epsilon(1−q)]；没有额外A_n或Dclk因子。若用这个覆盖整个Vhi的较强目标，可只留原低Li直接KW而不必再单付已含在Vhi内的低增长FcapW；若只覆盖原R，则保留(K+Fcap)W。两入口的正确母账均由第4节a=0给出，不能同时重复付款。

目前实际残余只保证总质量小，不保证两边际的逐测度theta支配；未触碰区域的密度仍为1。相对残余mass设门槛epsilon t_B,k时，通用RN界是1/(epsilon t_B,k)，不是t_B,k/epsilon。因此(Freeze-target)只是准确充分目标，不能计为已付Lfreeze。

proof通报的真实merge transition同样必须保。若H合并子块i，D_H=ΣD_i取原frozen inverseLi，实际q_H=Σq_i−e_H（e_H为mass-eligibility退出），则bad-parent减bad-children为

    Kr_B[Σphi_i D_i−phi_H D_H]。                       (Merge)

在无退出的理想聚合，令pi_i=p_i/p_H、d_i=D_i/p_i，其括号精确为

    p_H Cov_pi(phi_i,d_i)+(Σpi_i phi_i−phi_H)D_H。

普通概率聚合的第二项可有利，但posterior协方差没有符号。e_H退出及epsilon门槛跨越还须原样计发票，不能由概率gain注销。该式已独立用SymPy两子块符号核验残差0；RN theta²/(epsilon theta)=theta/epsilon及credit比例r_B/K也实跑确认。

当前未证的就是完整two-margin density contraction（或同强全局weighted bound）及Merge/退出/terminal的联合付款；已实现冻结协议与精确守恒并未降低总V。无已证的新完整a,L可送入第4节，原R564带Vrem的mother继续有效，所有外层费用保留。待core仅核一条实际决定式后封存，不把等待或新增分支当净进展。

### 6.1 已更新的真实累计RN：不再虚报stage数损失

generator/proof随后给出并已独核的更强正结果：在所有max(a,b)≥epsilon的冻结块中，把b≤a的块归到receiver-density decrement，把a<b的块归到old-density decrement。块密度分别≤该递减量/epsilon；固定receiver mark与固定旧(z,σ)的各自递减量总和均≤1。因此

    dΣ_{k,H} Pi_B,k,H / d(Q_B⊗P_B) ≤ 2/epsilon。        (RN-total)

该式不需要(P11)型两margin几何支配，任意stage数均成立；故本账不声称真实累计耦合系数必有N爆炸。第2–3节的NLW只针对逐层局部上价的粗累计，不能拿来反证(RN-total)。

累计冻结费满足

    V_frozen≤(2/epsilon) Vhi(U)，
    U={μ(H_LCA(y,z))≤c M_C(v)}

（忽略product原测度下零测的未分离／对角支）。这个U是全部实际front上mass-eligible samecell事件的并；LCA使每对只有一个最小共同树簇，但不同对的LCA簇仍有祖先／后代重叠，因此U并非一份共同μ互斥族。原Lcl lemma尚未给Vhi(U)≤polylogW。

若后续真正证明Vhi(U)≤L_UW且terminal≤aQg+L_TW，则完整source费是

    aQg+[(2/epsilon)L_U+L_T]W，

只代第4节一次mother；若针对整个Vhi则不另加已在其中的高p或低增长费用。现(RN-total)确实消除了“耦合系数逐stage累积”的缺项，是一个真实的系数改进；尚未支付共同LCA几何支持与terminal，所以未产生新的完整维数阶上界。当前主线缺口比单纯要求两margin均匀变小更准确：可任选证明LCA加权容量+terminal，或原(Freeze-target)的强支配，但两条未证路线的费用不能拼接。

### 6.2 mixed receiver删除不是边际不变量

已进一步读取proof S15–S16。原R含A_B(x)=1_{N^c}(x)和b_B(z,σ)=1_{Li>tau}/Li的乘积。完整recoupling Γ_B只保Q_B,P_B时，其受限source账相对原product的变化为

    K∫r_B t_Bq_B Cov_{Γ_B}(A_B,b_B)dB。

此项无符号。故full Cstar、完整old-only高账及score守恒，不推出删N后的原Vrem也守恒。generator选择更大完整Vhi作majorant正好避开此问题；若回到原R必须保此协方差及其原marks作为另项，不允许重耦合后再次免费删N。这是替代scope，不与fullhi-majorant重复开账。

因此当前最安全的主组合是：若未来LCA容量及真实terminal使完整Vhi≤aQg+Lhi W，则直接用原低Li≤KW、原P≤Qg，且第4节取C=2A(Kw+K)+B、L_tot=Lhi；不另加已含在Vhi内的低增长Fcap或旧高p预算。若只能界原R，则第4节原(K+Fcap)及高p/余项入口保留，并需确证受限对象没有被非法改变。两路线没有可互借的未证费用。

### 6.3 可直接交作者的统一安全数字

例如真正(Rec)若q_j≤1/2，且把所有transition/terminal credit计入后每阶段b_j≤d⁴/(32J²)，则总a≤d⁴/(16J²)。同样把全部source发票计入的统一L_j≤L给Lrec≤2L（再加显式terminal与初始高p费）。此时可取ζ=d²/(2J)：

    1−A(ζ+a/ζ)≥3/8，
    Qg/W≤(8/3)C+(16/3)A²L_tot。

这组常数留出统一余量，避免a趋近严格门槛时把新费用放大；没有直接c_dirQg时适用。有direct旧credit须在同一分母再扣2Ac_dir。若仅有每stage原score负载而没有上述加权总界，不能声明满足这组数。

## 7. core最终顺序修复与唯一主组合

core随后给出避免6.2混合协方差的合法次序，已独立核准。先在原product上冻结R=X(x)Z(z,σ)，其中X=1_{N^c}、Z=1_{Li>tau}。令q0=Q_B(X)、p0=P_B(Z)，取等质量次边际

    xi_B,0=p0 Q_B|X，rho_B,0=q0 P_B|Z，delta_B,0=p0q0。

正delta分支的原joint恰好为

    xi_B,0⊗rho_B,0/delta_B,0=Q_B|X⊗P_B|Z。

零delta时原R账为0。然后才作generator的冻结匹配，始终保持此两次边际。这样C_R、原P_R与V_R精确保留，初始密度≤1，累计RN≤2/epsilon也不变。它不同于“先fullcouple再删R”的错误次序；6.2中的协方差警示仍对后者成立，但不再要求正确次序必须改付完整Vhi。

这里采用递归整个R的入口，不再另加R564高p的cLcl/eta source费。令U为实际所有front上mass-eligible samecell事件的并，terminal保真实rho_B,N。当前完整物理式是

    V_R=V_frozen+V_term，
    V_frozen≤(2/epsilon)V_R(U)。                       (Core-full)

若将来真正证明（现在均未证）

    V_R(U)≤a_U Qg+L_UW，V_term≤a_T Qg+L_TW，

则唯一组合参数为

    a=(2/epsilon)a_U+a_T，L=(2/epsilon)L_U+L_T。

把此a,L代第4节，C=2A(Kw+K+Fcap)+B，唯一最终mother为

    Q/W ≤ b0^(-2) [C+A L/ζ]/[1−A(ζ+a/ζ)]，
    A(ζ+a/ζ)<1  ⇔  a<d⁴/(4J²)存在可行ζ。            (Final-R565)

全阶段P和terminal旧score加起来仍只有一次Qg。U及terminal不能各自先使用完整Qg然后遗漏上述(2/epsilon)倍系数；也不能将尚未证明的L_U或L_T替成Lcl。若a_U=a_T=0，安全半吸收ζ=d²/(2J)给source费系数4J²[(2/epsilon)L_U+L_T]/d⁴，直接费4J(Kw+K+Fcap)/d²及4Brem/d。外层及全部原入口/历史/全尺度/终端槽保持不变。

### 实际terminal的额外A_n不能藏掉

即使另证每父剩余次概率总量delta_B,N≤epsilon，也不能推出rho_B,N≤epsilon P_B或V_term≤epsilon V_R。高源仅给1/Li<1/tau=Dclk，所以可保证的粗总价至多

    V_term≤(K/tau)∫r_Bt_Bq_B delta_B,N dB
           ≤H epsilon W，H=K² S A_n Dclk。

这里显式出现A_n；ineligible残流甚至未保证delta≤epsilon。若只靠这一mass-terminal价并假设已付V_R(U)≤L_UW，source总费用为2L_U/epsilon+H epsilon。无约束最优epsilon=sqrt(2L_U/H)，最小为2sqrt(2H L_U)（epsilon≤1约束可能使之更大）。当A_n和Dclk均为n量级、其余仅polylog时，该价仍n·polylog，不能给所需polylog来源容量。这是对当前粗terminal付法的准确费用判断，不否定更强weighted-terminal或共同credit吸收。

上述product修复、terminal折中的导数及最小值均由指定本机SymPy实跑精确核验。最终状态：顺序和累计RN确已修好，是实际系数进展；真正未付仍是多front/LCA几何U的统一source容量及真实weighted terminal（或满足严格门槛的合并旧credit）。尚无可代入的新完整a,L，因此没有新的完整维数阶上界。当前有限整合完成，停止。


---

## feature_audit.md

# R565 role10：N7 完整有限标记 lift、旧字段与加权 deficit 审计

日期：2026-10-23。只写本文件，不改他人/仓库、不生子 agent、不编译 PDF、不重复全 Gram/优化。先独立规定对象和范围，待主代理批准 surrogate 后再审 N7/N8 对应实现。

## 1. 首先筛原对象能否恢复

**不能从现有有限文件恢复原全部真实 `L_i`。** R562–R564 文件保存有限来源、training/evaluation 父样本与动作、有限经验旧字段/α，以及 physical χ-Gram；不包含原全 Lebesgue 中心积分、完整历史与源格场。有限 training old field 也不是原 `L_i`；不能把其 α 或有限旧 Q 直接当原 Cstar 旧信用。

因此 N7 必须明确是 surrogate，且在运行前由主代理批准。原 `N_delta`、非对称 head/stop/core 等标记亦无法从 χ-Gram 数据恢复；不能静默称有限对象已经限制在原 `R=N_delta^c∩{L_i>τ}`。下面给出一个完全规定、仍保全部有限来源/真实动作窗/phase 的正 lift，其诊断有意义但不是原 Cstar。

## 2. 独立完整 finite χ-lift

来源 `μ=(1/64)Σ_sδ_xs`，同一源格 `C` 含全部 64 atoms，`W_C=1`。冻结 R562 原 332 个 evaluation bulk 父和正权 `ω_B`，全部 q-band 一同进入同一个物理字段，不再按 band 正交化。`t_B=1`，`a_B=1/R_B^16`，`m_B=q0_BR_B^16=c0_B/64=M_B(1)`，`s_B=log2(m_B)`。

冻结旧字段采用该 **332 父 self-old family**：

\[
k_B(z,\sigma_o)=a_B1_{O_B}(z)1_{[s_B,s_B+1]}(\sigma_o),
\quad O_B=Q_B(1),\qquad
L_{\rm fin}=\sum_B\omega_Bk_B. \tag{L1}
\]

它不随 adaptive/optimum 选择改变，亦不用 training α 替换。每父旧来源概率

\[
P_B(dz,d\sigma_o)=\frac{k_B(z,\sigma_o)\mu(dz)d\sigma_o}{q0_B}
\]

确为概率，因为旧窗长度 1 且 `a_B μ(O_B)=q0_B`。其旧信用 `e_B=<Lfin,k_B>` 满足 `Σ_Bω_Be_B=||Lfin||²`，但这只是本有限 self-old 信用，不是原 `Qg`。

### 2.1 带全部必要标记的 receiver row

令 `a=(B,g)`、`b=(C,v)`，动作捕获 `A_a,A_b`、质量 `M_a=c_a/64,M_b=c_b/64`、原真实相位 `j_a,j_b`、原窗 `W_a=[log2 M_a,log2 M_a+1]`。共享每父一个 `ρ_B`。完整正 receiver row 可写为

\[
d\mathcal R_B(a,C,b,y,\sigma_r)
=\rho_{Ba}\omega_C\rho_{Cb}a_Ba_C
1_{j_a=j_b}1_{A_a\cap A_b}(y)
1_{W_a\cap W_b}(\sigma_r)\mu(dy)d\sigma_r. \tag{L2}
\]

这里 receiver 的 `σ_r` 与插入旧来源的 `σ_o` 是两个不同积分变量，不能混用。保留 partner 当前质量 `M_b`；它稍后决定 mass eligibility。真实窗/phase 和有序 B,C 权都在 (L2)，不是把来源数错当全 receiver law。

记 `R_B=\mathcal R_B(全部标记)`，则

\[
E_\chi=\sum_B\omega_BR_B,\quad
r_B=R_B/q0_B,\quad Q_B=\mathcal R_B/R_B\ (R_B>0).
\]

零 row 时 `r_B=0`，`Q_B` 可任取，全部相应贡献为零，不应除零。有限 lift 是

\[
d\mathcal M_{\rm fin}=\sum_B\omega_Br_B
 Q_B(dx)k_B(z,\sigma_o)\mu(dz)d\sigma_o,
\quad \int d\mathcal M_{\rm fin}=E_\chi. \tag{L3}
\]

这与使用 `P_B` 的 `Σω_BR_B Q_BP_B` 等价。旧来源与整套 receiver marks 按该明示正 coupling 独立；它不是原非对称 Cstar lift 的恢复。

### 2.2 可合法压缩的 T tensor

N7 拟保存的 `T[B,y,c_b]` 含外侧 `ω_B`：把 (L2) 乘 `ω_B`，对两动作、partner 父及 `σ_r` 积分，只留下实际 receiver atom y 与 partner 当前质量计数 `c_b`。其精确数值公式是

\[
T_{B,s,c}=\sum_{a,C,b:c_b=c}\omega_B\rho_{Ba}\omega_C\rho_{Cb}
 a_Ba_C\,1_{j_a=j_b}\,
 (1-|\log_2(M_a/M_b)|)_+
 1_{A_a\cap A_b}(x_s)/64. \tag{L4}
\]

记 `rowE_B=Σ_(s,c)T_Bsc`，则 `r_B=rowE_B/(ω_Bq0_B)`、`Q_B(s,c)=T_Bsc/rowE_B`。这与 (L2) 完全等价。因后续 predicate 只看 y 与 `M_b`，在保留真实窗/phase的权后积分掉 `σ_r` 是合法充分统计；不应删 `c_b` 或改成 common-intersection count。

## 3. p、q、真实逆旧字段 D 与有限完整账单

取一个全父共用的来源集合 H，质量 `h_H=|H|/64`。有限 old marginal、完整 marked receiver eligibility 分别为

\[
p_{BH}=\frac{\mu(O_B\cap H)}{m_B},\qquad
q_{BH}=Q_B\{y\in H,\ h_H\le c M_b\}. \tag{L5}
\]

`q` 必须用 partner 外体**真实质量** `c_b/64`，不拿 B 自己质量、旧质量、交集质量或无质量条件的 source mismatch 替代。`q` 不只是一个 y 边缘比例：它包含 mass eligibility 与所有动作/phase/window权。

对于冻结阈值 τ，

\[
D_{BH}^{\tau}=\int_{z\in H,\ L_{\rm fin}(z,\sigma_o)>\tau}
 \frac{k_B(z,\sigma_o)}{L_{\rm fin}(z,\sigma_o)}
 \mu(dz)d\sigma_o,
\quad D_B^\tau=\sum_sD_{B\{x_s\}}^\tau. \tag{L6}
\]

`Lfin` 必须按每个来源原 `s_B,s_B+1` 的全部 σ 事件求和，再在真实旧窗内精确分段积分逆值；不能用窗中心、均值 α、count 或旧字段范数代替 `1/Lfin`。因为 self-old family 含 B 自己，`ω_B>0`，旧 law 支持内 `Lfin≥ω_Ba_B>0`，除 σ 零测端点外没有未定义分母。

定义单位倍数 `Kfin=1` 的账单（仅单位尺度，**不声称 `r_B≤1` 或继承原 K cap**）

\[
V_{\rm tot}=\sum_B\omega_Br_BD_B^\tau
=\sum_B\frac{rowE_B}{q0_B}D_B^\tau,
\]

\[
S_H=\sum_B\frac{rowE_B}{q0_B}
1_{\max(p_{BH},q_{BH})\ge\epsilon}
\min(1,q_{BH}/p_{BH})D_{BH}^\tau. \tag{L7}
\]

当 `p=0` 时 `D_BH=0`，按 zero contribution 定义，避免 `0/0`。若 `q=0<p` 则 score=0。给一个全父共同、μ-不交 partition `P`，完整 finite bad bill 是

\[
V_{\rm bad}=V_{\rm tot}-\sum_{H\in P}S_H\ge0. \tag{L8}
\]

同一父所有 disjoint H 的 (L6) 可加，系数在 `[0,1]`，保证非负。没有每簇/每深度新给一份 W。对全部可能连续 source intervals 的最优共同 partition，score table 可用正 interval DP；其 optimum 仅是该候选族的 finite optimum，不是一般几何最优。

`τ=0`（解释为 `Lfin>0`）与 `τ=1/18` 两表之差提供低旧字段的完整有限互补；`1/18` 来自原参数 clock 的数值选择，不因此把 surrogate 变成原 `Li`。原 N_delta/head/stop/core 不可恢复，不应暗加一个未知筛选使数据更小。若原筛选还依旧来源 z，则 (L5)×(L6) 的因子分解须改为联合源/标记量，不能继续套 (L7)。

## 4. 前置协调与批准状态

numeric 已确认采用上述对象：332 evalbulk self-old Lfin、全 q-band 同场、T 含 ω_B、`r=rowE/(ω_Bq0)`、`Kfin=1` 仅单位尺度、τ `1/18` 同时报 τ0/low 互补；原 N_delta 无法恢复，绝不称原 R/Cstar。来源序固定按 atom 第 1 坐标升序，64 atoms 的 2080 个连续 intervals 全列。参数仅 `c∈{1,2}`、`ε∈{1/2,1/4,1/8}`，adaptive 与旧 optimum，不重新求动作 QP。

该具体 surrogate 在运行前已获主代理明确批准。批准只覆盖静态共同 partition/正 fractional interval packing 的有限诊断，不是原母式；numeric 在该授权后运行。N8 获同一 normalization/字段口径，独立核 primitive 与 DP certificate，不复制全 receiver Gram。未获原完整 Li 数据时始终保持 surrogate 标记。

## 5. N7 最终实现审计：通过

已读 `/tmp/ccu_r565_n7.py`、`.json`、`.md` 与 `_assembled.npz`。最终稳定代码 hash

`abd2017f52915e0fe02c6b24e0a6a04a28e41ecc5bc7a8d71c7010bef8d32116`，

与 JSON 相符；JSON hash 为 `53e9cc17a3b4138a708e66a95ed11d2b60aaa11512c6d42fe48837f8fcb80b15`。本角色没有执行 N7 主函数、没有重建 receiver 全 Gram、没有运行 DP 或 solver。下面是按独立 L1–L8 对实现的核查。

### 5.1 旧 Li、全部旧 sigma 与逆字段

`old_inverse()` 由每父原 `old_count` 与 `2*old_count` 建共同旧窗端点；`windows` 精确对应 `[log2(c0/64),log2(c0/64)+1]` 内的非零长度 σ 段。其

`L=(oldmask.T * (omega/R^16)) @ windows`

是全 332 父、全 q-band 的同一 `Lfin`，没有用 training α、per-band L 或平均窗替换。随后先求每个来源和 σ 段的 `1/Lfin`，分别取 `Lfin>1/18` 与 `0<Lfin≤1/18`，最后在每父真实旧窗积分；`D` 前因子是 `1/(64R_B^16)`，**没有重复乘父权 ω_B**。父权只在外层 `rowE/q0` 出现，符合 (L6)–(L7)。

独立从原 64 来源坐标与每父中心/边长重建旧几何 masks，再用每个旧 σ 段的严格中点测试原 log 窗，重构全部 `Lfin` 网格；与 JSON 的 `L_values` 最大差为 **0**。这没有使用 N7 的初始 mask 或整数 window 判定作为几何依据。来源排序也与独立按第 1 坐标稳定排序完全相同。

只读检查 `D_high,D_low` 非负，且旧体外 D 都为零。更有独立积分自检

\[
\sum_B\omega_B(D_B^{hi}+D_B^{low})
=\int 1_{Lfin>0}\,d\mu d\sigma
=2.275230597880266\ldots,
\]

两边差 `4.44e−16`。这个恒等式核了旧字段分母/父权/来源质量方向，没有把高字段筛选后的对象当成原 R；`tau0` 的全正 Li 量及 low 互补完整保留。

### 5.2 marked T、q 的方向与权

代码 `W_ab=(rho*omega/R^16)_a(rho*omega/R^16)_b *1_samephase*tent/64`，再逐 partner 当前 count 分组，将 `W[:,inds] @ receiver[inds]` 乘自身 action 的 receiver mask，并按自身 parent 相加到 `T[parent,y,partnercount]`。这正是 (L4)：

- 外侧两父权、两 shared action 概率各一次；
- 真 phase 与真质量窗交长各一次；
- 实际共同来源 y 两边捕获均在；
- 来源质量 `1/64` 一次；
- `partnercount` 为 partner 当前 outer mass，不是 old count 或共同交集计数。

所有 q-band 一同进入 W，没有额外 band 正交。按 parent 累加前未去掉有序反方向。对 adaptive/optimum/δ1，stored T 的 row mass 总和分别复现已审 χ 能量 `1.558593568624015`、`1.305992437746717`、`2.1406911181545665`；row 与 JSON 记录逐项差为 0。

`q_H` 从 T 的 partnercount 尾和取 `count≥ceil(|H|/c)`，再求 H 内实际来源边缘并除该父完整 row；这与 `μH≤c M_partner` 完全等价。零 row 用零 q，外权 rowE=0，处理合法。旧 `p_H` 是旧捕获 count/H count 比，独立于动作律；`p=0` 时 matching score 置零且 D_H=0，没有 0/0。

### 5.3 score、共同 partition 与逐父 relaxation

`rowfactor=rowE/q0`，`paidparent=rowfactor*D_H*min(1,q/p)*1_max(p,q)>=eps`，符合 (L7)。`Kfin=1` 在 JSON/MD 明确只是单位倍率，并不宣称 `r≤1` 或原 K row cap。

代码列出全部 2080 `[start,end)` rank intervals。`dp()` 在共同源序上只允许前端点接前一个已覆盖 prefix，所选 intervals 不交且覆盖全部 64 atoms；非负 score 下不强迫付额外负费，也等价于允许空隙后用零/非负 singleton 补齐。N8 独立认证 rounded score 的 Bellman optimum/packing 范围；本角色没有另跑 DP。

逐父 optimistic DP 是同一 D/marks/score 的父分离上界，但每个正 row 的完整 partition 都再次覆盖全源。代码 explicitly 累加每个 atom 的 source load；此输入三种 law 均 332 正 rows，source load 每 atom **332**，所以 duplicated W=332，而非一份 W。N7 MD 没把这个近乎全消失的 optimistic bad 当可用共同预算。

### 5.4 新增完整 bad 三分解

在已选共同 partition 上，令 `b_BH=(rowE_B/q0_B)D_BH`，`g=1_max(p,qeligible)>=eps`，`f=min(1,qeligible/p)`，`fraw=min(1,qraw/p)`。`qraw=Q_B[y∈H]` 从同一 T 但不加 partner mass 门槛得到，所以 `0≤f≤fraw≤1`。实现的三项是

\[
\sum b(1-g),\qquad \sum bg(1-fraw),\qquad \sum bg(fraw-f).
\]

它们分别为 small-block gate、原 receiver mismatch 和 mass-eligibility loss，均非负；与 covered score 合计精确耗尽同一 high total（浮点内校准 `1e−11`）。没有把“不满足 cluster mass”误记为 raw source mismatch，也没有在门外另丢一块质量。low-Li 是此外另一完整明示互补。

## 6. 最终数值范围与实际决定

以下是已经获批的 finite surrogate、单位 K、τ `1/18`，不是原 Cstar 或原 mother：

| law | high Vtot | low-Li 互补 | 最佳共同 interval partition 的 bad，c=2,eps=1/8 | 逐父 optimistic bad | 逐父复制 W |
|---|---:|---:|---:|---:|---:|
| adaptive | 1.179438332112 | 0.032379442169 | 0.055188674024 | 0.001269274861 | 332 |
| optimum | 0.915592608329 | 0.021061110873 | 0.043924106882 | 0.000003055451 | 332 |
| δ1 | 1.832737378898 | 0.063764019477 | 0.092155099272 | 0.000996997227 | 332 |

共同 partition 在此参数上仍留下约 `4.7%–4.8%` 的高字段加权 deficit；逐父极小残差需要 332 倍源预算。这是**该输入、该连续 source interval 候选族**的 common-credit 相容性信息，不是任意可测共同 partition 的下界，也不是一般多尺度递归必需性的证明。fractional packing 同一 interval 族也不能免费突破其 DP optimum；具体证书由 N8 给。

N7 明确 `paid` 只是 matchable score，不是已经证明的最终付款。参数改善还伴随 cluster lemma 相对系数 `c/eps` 从 2 到 16 的变化；不能只比较 residual 百分比就宣称净母账改进。原 heads/stop/core/N_delta/真实 Li 缺失始终显著标注，未由这次有限诊断恢复。

实际工具：指定本机 Python 3.12.14、NumPy 2.5.4，仅只读 JSON/NPZ 并重构旧几何/Lgrid、逆字段总积分自检和 T 保存量求和。没有重算全 receiver tensor、动作 Gram 或 DP，没有调用优化器。N8 的 exact rounded-table 最优性也不能自动认证非线性 `Q/L` assembly 的理想误差或原连续对象。

**最终 verdict：N7 采用了运行前获批的明确 finite χ-lift surrogate；其全旧 Li 选择、真实旧窗逆字段、完整 marked receiver q、所有 shared action/phase/window/ordered/band 权和 matching deficit 方向通过。没有把 surrogate 冒充原 Cstar，没有新增全局付款。角色10完成有界审计并停止。**


---

## screening.md

# R565：mass-coordinate/front 机制的完整费用 scope 独审

## 0. 范围与独立验收线

沿 R565 完整固定 adaptive 对象，原 μ、真实父中心、L_i/α、实际 I/phase/window/head/stop/core、所有旧 σ 层和有序父对均冻结。先独立给判据，再审 generator/partition 的准确候选。不重做单 family mass lemma、旧 margin 不变性、抽象 forest telescope、轴源有限测试或 QP。

要通过的不是“每深度有一个 μ-disjoint front”，而是完整 weighted deficit 被一次源预算或可吸收原信用支付。任何 coordinate/front 改进都须保原 L_i 的倒数和同一个旧/新信用；本审不允许每深度重新发 W。

## 1. 固定完整 deficit：必须比较它而不是 mismatch 概率

对一个共同 front F，沿冻结量定义

    c_BH=1_{max(p_BH,q_BH)≥ε}min(1,q_BH/p_BH)，
    T_F(B)=Σ_(H∈F)c_BH D_BH^τ，
    V_bad(F)=K∫r_B[D_B^τ−T_F(B)]dB。

p_BH=0 时 D_BH^τ=0，对应项取0。这里 D_BH^τ 含同一个原 k_B/L_i、旧 σ 和 Li>τ；它不是 p_BH 的常数倍，不能以匹配概率替换。

共同分割 μ-disjoint 时，p 和 D 对 children 加性。对 H→children(H)，准确的覆盖增量为

    ΔT_B(H)=Σ_child[c_B,child−c_BH]D_B,child^τ。

因此真实 bad bill 的变化必须乘 K r_B 再对原 B 积分。仅有几何分割、质量下降或匹配概率增加，不保证该加权增量为正。候选若宣称收缩，需要证明这个同一原积分的正增益/亏损如何付款。

## 2. mass eligibility 在 refinement 下的真实新增项

`q_BH=Q_B{y∈H,h_H≤cM_C(v)}` 保留实际 receiver marks。父 H 与其 children 的 eligibility 不同，不能默认 q_parent=Σq_child。

更准确地，因 h_child≤h_H，

    Σ_child q_B,child−q_BH
      =Q_B{y∈H，h_child(y)≤cM_C(v)<h_H}≥0。

这里 children 必须 μ-a.e. 覆盖 H；否则未覆盖的 source/receiver 余项仍须保留。这个差是新变得 eligible 的真实 marks。它可以帮助 refinement，但必须用其实际 M、I、phase/window 和 source 价格付款，不是没有成本的新匹配质量。若候选使用条件 source law，原 head/stop/core 和同父质量曲线也不可与坐标标签独立化。

## 3. 一次源预算的三种合法接口及禁止的快捷步

已审 mass lemma 每次只对一个共同、μ-disjoint family 给付款。若在每一深度重复调用，得到的是逐层费用；不能仅因每层 Σh_H≤W 就把所有深度费用合成 W。

可接受的全程接口可以是：

* 一个共同随机 front law，源费用按同一概率权平均且权和1，同时证明剩余 weighted small-coverage tail；
* 真正非复制的 source flow/charging，使各阶段的实际付款系数总和可求和，且 merge/flat/recapture/终端/系数漂移都在账内；
* 对原 V_bad 的收缩/原信用吸收式，源余项可求和，且控制终端。

将原 marked tuples 按首次 admission 分成互斥部分只是必要记账，不足以自动得到一次 W：同一个真实 source 仍可出现在很多 tuple/旧 σ/外父中。付款 lemma 的源容量也必须随这份分解受控。

parent-dependent H=Q_B(g)、按 receiver 自选 front 或分别对每个旧层应用“最佳共同 front”都不属于已证单 family 接口；若要采用，须证明相应全局 fractional capacities 或原 credit 负载，而非只改符号。

## 4. cube 坐标何时真正进入完整费用

对一个共同 coordinate split，必须保同一真实 tuple 的 old-source child、receiver child、原 σ、M/I/phase/head/stop、原 α 以及实际 cube face 位置的联合标记。异 child old/new 质量不可作为没有来源费的扔弃项。

仅使用 `h_H=Σh_child`、概率边缘、mass eligibility、停时存在性或每层质量守恒的论证，对一般可测分割也成立；仅使用同伦中心体积 t^n 的论证对一般同伦凸体也成立。它们没有提供 cube 对一般对称凸体的多项式费用优势。

cube 特有的一步必须是：实际完整坐标 capture/intersection 限制如何控制第1节的 ΔT_B 或同强原 weighted deficit，并在对 old+new 来源、全部 M/σ 层积分后留下可见系数改善。不得把某一坐标的局部1/n、非加权中心体积或 tuple 相对容量，直接当作已证明的完整 contraction。

原 L_i 不能随 front 删除/重标后重算。可在原积分内分析其 conditional law，但若把分母换成当前剩余 L_i^rem，必须另证恢复原字段与 frozen score 的比较及费用；该替换不是免费的阶段记号。

## 5. generator：冻结匹配合法，累计系数有改进，联合几何付款仍未完成

已定点读 `/tmp/ccu_r565_potential.tex`。P1—P7 的量词通过：对每个固定正行 B、固定 ε>0，真实 median front 的 cell 质量最终小于 εm_B min(1,r_B/F_cap)，于是所有 max(p,q)<ε，原 weighted deficit 恢复为 Kr_BD_B^τ。有限 V^hi 下可支配收敛；无限时 Fatou 给无限 liminf。这只排除“每次重新评估 finer front 后免费删终端”，不排除冻结早期匹配、共同随机 front 或原信用付款。

P8—P10a 的冻结协议通过。每块 coupling 为 ν|A⊗ρ|H/max(a,b)，质量 min(a,b)，从两侧同时扣除其准确边缘；共同 front 的互斥使残余保持正，终端 ν_N⊗ρ_N/t_N 恢复两个原边缘。旧 J_B^τ=1_{L_i>τ}/L_i 的 frozen+terminal 账严格等于原 Kr_BD_B^τ。score 账的系数另为 r_Bt_Bq_B/K，累计为 (r_B/K)e_B≤e_B；不能把 inverse-fee 的 integrand 单独换成 L_i 而沿用其系数。实际全文没有重算 L_i，也没有每阶段重发 Q_g。

**新增 P10b 累计 RN≤2/ε 通过，且确实强于逐阶段 1/ε 后无限相加。** 写残余密度 f=dν/dQ_B、g=dρ/dP_B∈[0,1]。若 b≤a，则该块完全移除接收侧在 A 的限制，密度 f g 1_A1_H/a≤ε^{-1}Δf；若 a<b，则≤ε^{-1}Δg。对固定真实接收 mark、旧 source mark，所有相应侧的 density decrements 分别总和≤1。因此累计 coupling 对同一原 Q_B⊗P_B 的密度≤2/ε。它没有发新的 source/score 预算。

此改进给 V_frozen≤(2/ε)V^hi(U)，而不是 V_frozen≤(2cL_cl/ε)W。U 是所有使用的共同 fronts 上 mass-eligible 同 cell 事件的 union；它不再是一个 μ-disjoint family。若 union 遍历完整 median tree 的全部 depths，其几何上包络恰为

    U_tree={h_HLCA(y,z)≤cM_C(v)}。

有限或选定 fronts 的 union 只有包含于 U_tree；实际选定 large blocks 的 support 还可更小。上述精确等式的适用域已发作者，付款所需的包含关系不受影响。不能把 full-tree U 的各层各付一次 W 后宣称只付一次。R564 lemma 尚不控制这个重叠 union 的完整容量。

P10d 的 recoarsening 费用保留真实旧 J 协方差、eligibility exit 与 threshold crossing，准确归一后通过。P11—P14 是合法的充分条件：若对原两个 marked margins 同时有 ν_k≤θ_k Q_B、ρ_k≤θ_kP_B，块阈值为 εθ_k，且 Σθ_k<∞，则块密度≤θ_k/ε、阶段费≤cL_cl θ_kW/ε、原旧边缘终端≤θ_NV^hi。有限截断统一实现后才可取正极限。实际 median fronts 没有证明这种双侧 density 收缩；残余总质量小不能替代它。该条件不得记为已实现的费用改善。

## 6. partition：真实共同 random front 有一次 W，完整小覆盖尾未付

已定点读 `/tmp/ccu_r565_partition.tex`。共同 coordinate-median tree 合法：μ=f dx 使 split hyperplane 无质量，深度 d 的 cell 质量为 2^{-d}W_i。实际两 source 永远未分开的 μ² 质量为 2^{-d}W_i²→0，因此 H_LCA 对 μ²-a.e. pair 存在有限深度。原 dV 对两个 source 绝对连续，故例外集对该真实费用也为零，无需假设 rectangle diameter 缩到零。

P3—P6 通过：所有 coins 共同采样一次、停止概率 β_H 沿每条 source path 总和1。给定真实 tuple，pair 同时进入 eligible front 的概率准确为所有 eligible common ancestors 上 β_H 之和；实际 M、I、phase、head/stop 和两 source 未改变。逐 realized disjoint front 用已审 lemma 再 Tonelli，严格得到

    ∫p_β dV≤cL_clW，
    V{p_β≥η}≤cL_clW/η。

这里没有逐 depth W，也没有将 condition 后 law 重新归一而隐藏 1/p_β。

P7—P9 的 depth law α_d=1/[(d+1)(d+2)]、first eligible a=max(0,ceil(log2(W_i/(cM)))) 与 coverage 1/(a+1)−1/(ℓ+2)（a≤ℓ）通过。相等端点 h_H=cM 包括在 eligible；a>ℓ 的空和为0，未删除这一部分。subevent 下界 p≥1/[2(D+1)] 是正确的有条件付款，D 没有统一维数界。

P10—P12 的真实 critical terminal 通过。若 H*=H 且 h_H≤cM<h_parent，则只有 H 本身是 eligible common ancestor，所以 p_β=β_H。其准确 small-coverage 费为 Σ_{β_H<η}V_H^crit，保留原 L_i^{-1} 与全部 marks。沿嵌套 path Σβ_H≤1 仅限制 front law；并未证明 actual V_H^crit 饱和，也不是目标定理反例。对所有 depths 付款不能由每个 antichain 的一次源费推出。

P13 通过但只作表示：h_H*>cM 时所有共同 ancestors 不 eligible，p_β=0。原支持 y,z∈A=Q_B(g)、y∈D=Q_C(v)，真实 tent 给 μ(A)<γM，所以 c>1+γ 时

    μ(H*\(A∪D))/h_H*>1−(1+γ)/c。

引入第三个真实 source w 的比较代价至多 c/(c−1−γ)，但 triple-source 积分仍未付款；分出 w 也未保证原 y,z 继续同 cell。这里仅用了集合质量，不是 cube 独有定量增益。

P14 保一次原 Q_g 的完整 Cauchy 返回通过：

    Cstar≤(K+F_cap)W+sqrt[Q_g(cL_clW/η+V_bad^β)]。

该式不得删 V_bad^β。母式中的 J/d²、外层 b0^{-2}、其余停止/入口/时钟/终端费用仍按原合同保留；没有把低覆盖结果当作已闭合主结论。

## 7. cube discrimination 与最终验收

**准确状态：局部/记账命题 PASS；完整 cube-specific coefficient 改善未获证。** 两个候选都真正采用了共同、source-adaptive 的 cyclic-coordinate median tree，并保留完整 cube coordinates；但是其已证明付款只用质量加性、边缘、common-front 概率和 R564 general homothetic cluster lemma。P10b 是真实累计耦合系数改进，但同样对一般可测分割成立。

真正还需 cube 坐标支付的是同一个原 inverse-L_i weighted joint demand：generator 的 overlapping U_tree 联合容量/终端，或 partition 的 critical 跨深度与 mass-ineligible LCA tail。不能只控制 source 计数、单 pair 几何或两边总质量，再替代这些费用。原 old+new mass integration、旧 σ 层和接收 marks 的联合约束在两稿中均保留，但未产生一个完成积分后的新 cube 系数。故本轮没有可以写入完整母账的 cube 对一般对称凸体多项式优势，也不把 conditional density 假设当作证明。

这是对当前两个构造的边界，不是对所有 coordinate/front 机制或目标阶的否定。后续若继续，只应证明上述准确 joint weighted term 的一次预算或原信用吸收；重复已证逐层 lemma、换残余 L_i 或清空 terminal 均不能推进该构造。

## 8. 实际工具与冻结

已运行本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`：Python 3.12.14、SymPy 1.14.0。精确符号核验第1节 weighted refinement identity 的 residual 为0，并核验 θ²/(εθ)=θ/ε。它们仅是代数辅助；概率、绝对连续、累计 decrement 与 scope 结论由上文解析证明，不把符号输出当 cube 预算证据。未重跑有限 shape 测试或昂贵扫描。

本稿只修改本文件，不改他人文件、仓库，不 spawn/PDF。验收已交 parent 与两作者；有限任务完成后停止。
