# R565 N7: one common partition of a weighted finite physical chi-lift

**Scope.** The original full Lebesgue/history L_i and the marked asymmetric Cstar cannot be recovered from R562 finite files. Training alpha is not that field. Root explicitly approved this finite surrogate after distribution's formula audit. It uses the original 332 evaluation bulk parents and their weights, all 64 true sources, all action states, true phase/window overlaps, and all qband cross terms. It does not reconstruct original Ndelta/head/stop/core restrictions. There is no new QP, geometry sample or dimension scan.

Freeze Lfin(z,sigma)=sum_p omega_p R_p^-16 1_oldp(z)1_[s_p,s_p+1](sigma). Let the full physical ordered chi row at parent p have energy rowE_p, including omega_p. Its normalized marked law Qp retains both actions, true shared receiver, true phase/window overlap and the partner captured count. Set r_p=rowE_p/(omega_p q0_p). Then dMfin=sum_p omega_p r_p k_p mu(dz)dsigma_old Qp(dx) has total mass Echi. Kfin=1 is only a unit multiplier; no r<=1 or original mother estimate is invoked.

Use tau=1/18, retaining all Lfin>tau old windows in DpH and storing the complete positive-Lfin tau0/low complement separately. For H, pH=pop(oldp∩H)/oldcount_p and qH=Qp[y∈H, |H|<=c partnercount]. DpH is the actual inverse-field integral of k_p/Lfin over old sources in H and Lfin>tau. Thus the interval score is sum_p (rowE_p/q0_p) DpH 1_(max(pH,qH)>=epsilon) min(1,qH/pH). At pH=0 the score is zero. Marks/action law are not changed by receiver or cluster.

The common source order is the first source coordinate in increasing order, with stable ties. All 2080 half-open rank intervals [s,t), 0<=s<t<=64, are considered. The dynamic program finds the best disjoint complete partition, preserving one source budget W=1. With nonnegative interval scores it also attains the optimum of fractional interval packing under per-source capacity<=1; N8 independently certifies this using exact dyadic tables and atom duals. This only covers this interval family, not every measurable common partition in dimension16.

## All requested weighted residuals

High weighted bills are adaptive 1.17943833211180 and optimum 0.915592608329113. Low-Lfin complements are 0.0323794421688336 and 0.0210611108733483, respectively. They remain explicitly stored and are not silently dropped. Full positive-Lfin bills are their sums.

| Law | c | epsilon | Common covered fraction | Common bad bill | Per-parent optimistic bad | c/epsilon |
|---|---:|---:|---:|---:|---:|---:|
| adaptive | 1 | 0.5 | 0.7574416979 | 0.286082559263 | 0.117881110387 | 2 |
| adaptive | 1 | 0.25 | 0.9022614125 | 0.115276636631 | 0.0536194925829 | 4 |
| adaptive | 1 | 0.125 | 0.9149423454 | 0.100320258232 | 0.0516325867236 | 8 |
| adaptive | 2 | 0.5 | 0.8926426403 | 0.126621385307 | 0.00164184304341 | 4 |
| adaptive | 2 | 0.25 | 0.9469659338 | 0.0625504105324 | 0.00130520501237 | 8 |
| adaptive | 2 | 0.125 | 0.9532076646 | 0.0551886740244 | 0.00126927486058 | 16 |
| optimum | 1 | 0.5 | 0.7652009963 | 0.214980232267 | 0.0620570016387 | 2 |
| optimum | 1 | 0.25 | 0.8992746457 | 0.0922233898347 | 0.0277900719607 | 4 |
| optimum | 1 | 0.125 | 0.91103061 | 0.0814597158945 | 0.026415064916 | 8 |
| optimum | 2 | 0.5 | 0.897608958 | 0.0937484812548 | 1.29488617915e-05 | 4 |
| optimum | 2 | 0.25 | 0.9459384969 | 0.0494983126783 | 3.05545084411e-06 | 8 |
| optimum | 2 | 0.125 | 0.952026582 | 0.0439241068817 | 3.05545084411e-06 | 16 |

The label `paid` in the data denotes the matchable weighted score, not a demonstrated final mother payment. The cluster lemma's coefficient still grows as c*Lcl/epsilon; the table's c/epsilon is its relative local-price multiplier, not an evaluated Cstar or finite r-bound. Consequently lower bad fraction at epsilon1/8 carries a larger local-price coefficient. No absorption claim is made.

The decision is materially different from source-count coverage. A single best common partition still leaves roughly 4.7–4.8% of the high weighted bill at c=2,epsilon=1/8. Individual-parent partitions reduce the corresponding bad bill to 0.00126927486058 (adaptive) and 0.00000305545084411 (optimum), but use 332 separate complete source partitions: source load is exactly332 at every atom, duplicating W to332W. This is an optimistic relaxation, not a legal one-budget solution. The gap identifies a common-credit compatibility obstacle rather than a missing LP algorithm: fractional mixing of the same intervals cannot improve the common optimum. It does not prove every multiscale construction must fail or establish a general need for a particular recursion.

For the common c=2,epsilon=1/8 partition, adaptive bad decomposes into small-block gate 0.00178541445248, raw receiver mismatch 0.0433918104699, mass eligibility loss 0.0100114491020. Optimum decomposes into 0.000375890094548, 0.0383594905441, 0.00518872624301. These sum to the complete high bad bills. In particular, after reducing the small-block threshold, most remaining bad bill is genuine old-versus-receiver matching deficit rather than count eligibility alone.

Every parameter record stores this decomposition. It is obtained on the chosen common partition with base=(rowE_p/q0_p)DpH. The gate term is base on max(pH,qeligibleH)<epsilon. On admitted blocks, raw mismatch is base*(1-min(1,qrawH/pH)); eligibility loss is base*(min(1,qrawH/pH)-min(1,qeligibleH/pH)). Here qrawH=Qp[y∈H] retains all partner masses. All three are nonnegative modulo roundoff. Their sum plus covered score exhausts the high weighted total; low-Lfin is an additional explicit complement.

Delta1 pressure was also run on the same object. Its total high weighted bill is 1.83273737889811 and low complement0.0637640194769221; common covered fractions range0.729807820371306 at c1,epsilon1/2 to0.949717236995672 at c2,epsilon1/8. All six records and their copied-source relaxation are retained. The receiver-row mass reproduces the known R563 actual delta1 energy2.14069111815457, while adaptive and optimum reproduce their respective full physical energies to2e-12.

## Assembly and reproduction

Run `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r565_n7.py --optimizer /tmp/ccu_r562_optimizer.json --n3 /tmp/ccu_r563_n3.json --input /tmp/ccu_r562_optimizer_input.json --output /tmp/ccu_r565_n7.json`.

The companion assembled NPZ contains T_LAW[parent,source,partnercount], exact source permutation and half-open interval arrays, D_high/D_low, p_H, D_H, q_H_LAW_c1/c2, and interval score arrays. JSON includes the full old sigma integer edge partition and Lfin values; actual parent weights, masks, radii and the original rho come from SHA-identified frozen R562/N3 inputs. Lfin uses the sum over every one of the332 bulk old parents, all bands together, not a per-band or training field. Source coordinates are rebuilt from the exact frozen seed recipe and verified against the original atom hash. The supplied compact input file is hash-recorded; the atom rebuild is independently checked against optimizer input_hashes.

For each law, T is assembled using each true phase-equal action pair, tent(log2(count_a/count_b)), the exact source membership masks and actual center weights. Source mass1/64 is included before row summation. No receiver marginal replaces this source-resolved marked tensor. Normalizing its row gives Qp; mass eligibility uses the marked partner count, not the common capture count. Old sigma inverse integrals use every actual oldwindow endpoint; Lfin positive range is [0.00523744372332003,4.23533026039205]. The DP uses these weighted scores, not source-count mismatch or N5 overlap admission energies.

All chosen common cuts, individual-parent cuts, optimistic values, source loads, singleton and whole-source baseline scores are serialized. The initial computation ran0.434449s; a same-input report pass added the exhaustive bad decomposition without changing any interval score or optimum. Final cost appears below. N8's scope is the exact optimum of the serialized rounded score table and its fractional interval-packing dual; it does not certify the ideal nonlinear Q/L assembly, original Cstar, or a general Lebesgue result. Distribution separately audits assembly and the approved surrogate's scope.

Final report pass: 0.447113 s, peak RSS 229474304 bytes (218.8 MiB), one process with BLAS<=2 and zero solver calls. Versions {'python': '3.12.14', 'numpy': '2.5.4'}. SHA256 input/code/assembled references are stored in JSON. No further computation is planned.


---

# R565 N8：有限组装轻审与全局 interval partition 的精确证书

## 1. 冻结对象与决定性结论

本任务采用主代理明确批准的 **finite physical χ-lift surrogate**。它不是原全 Lebesgue/history 的 L_i，不含不可恢复的 Nδ、asymmetric head/stop/core；K_finite=1只是单位尺度，不能调用原r_B≤K或母式。distribution角色独立审计物理有序mark及窗口解释；N8不重复组装完整action Gram。

结果：3个law（adaptive、既有optimum、delta1压力）×6组(c,ε)共18个序列化score表，N7给出的chosen partitions均通过 Fraction **准确全局最优**核验，18项regret全部准确为0。完整Bellman/atom-dual证书同时证明：在同一2080个interval、相同每source容量约束下，任何非负 fractional interval packing 或随机partition混合都不能超过该值，无额外LP。

最有利的本次参数 c=2、ε=1/8：

| law | exact-table最优paid（显示值） | 完整table坏账（显示值） |
|---|---:|---:|
| adaptive | 1.124249658087392 | .05518867402440776 |
| optimum | .8716685014474396 | .04392410688167324 |
| delta1 | 1.7405822796258064 | .09215509927230725 |

这是真实的有限单共同interval族残差：不能靠同表上的更好DP或fractional interval packing将其消掉。它不排除非contiguous共同簇、不同coordinate结构或合法多阶段机制；也不是一般维数率。每父各选partition的乐观对照复制来源预算准确为 **332W**，不能把其近零残差当作一份W的可付款。

严格最优性只对序列化double score table成立。q_H、D_H、eligibility/ε门与inverse-L计算对理想有限score的联合误差没有整体区间证书；没有把这一层静默升级为连续几何或原Cstar的严格最优。

## 2. 被核的有限组装定义

源仍是原冻结64个等质量原子，按第1坐标稳定排序；候选为全部半开rank interval `[s,t)`，0≤s<t≤64，共2080个。source order、interval starts/ends与N7 JSON和NPZ逐项相同，order是0,…,63的permutation。

旧family为332个冻结evaluation bulk父，所有qband一同进入

`L_fin(z,σ)=Σ_B ω_B R_B^(−16) 1_oldB(z)1_[log2 mB,log2 mB+1](σ)`。

N7marked row tensor `T[B,y,partner_count]` 保留双方actions、实际phase及窗重叠、receiver与partner质量，row总量为rowE_B。正row的Q_B由该完整marked row归一；`r_B=rowE_B/(ω_Bq0_B)`。p_BH由旧source计数得到；q_BH只计y∈H且 `|H|≤c·partner_count` 的marks。D_BH包含旧窗上的 `1_(L>τ)/L`，τ=1/18。score为

`Σ_B(rowE_B/q0_B) 1_[max(p_BH,q_BH)≥ε] min(1,q_BH/p_BH) D_BH`，

p=0时D也为0、score取0。law与全部原α/bulk固定，没有按receiver改变action。

N8只做以下轻量独立检查，不重T的action-pair来源实验。

### 旧L及τ

从原optimizer states重建每父初始source set，并用原parent metadata重新计算已舍入的amp=`float(ω_B/R_B^16)`；将每amp转准确dyadic Fraction，按真实旧窗整数端点count、2count准确相加。全部332父、所有band均进入同一个L，未改用training field或band-local L。

旧窗分段为64来源×15σ段，其中573个准确L值为正。对N7存的浮点L，独立核

`|L_hat−L_exact|≤γ_332 L_exact`，`γ_332=83/2251799813685165`。

最大实际绝对差约 `1.12930498286e−15`；准确正L距离τ=1/18的最小margin约 `.00201398398198`。所有high/low分类与这个准确rounded-amp field完全相同。因此本次τ分类没有被舍入翻转。这里仍以rounded amp定义有限标量场；未认证其对理想 `ω/R^16` 几何表达式的总误差。

### 原source概率、D支撑和完整Q归一

p_H的分子为准确整数旧source计数；p_H数组逐值等于该有理数的nearest double。所有可出现计数分母及ε=1/2,1/4,1/8，p_H阈值分类都与准确有理分类相同。最大p舍入误差为 `1/20266198323167232`。

D_high、D_low非负且在旧source集合外准确为0；所有p_H=0的interval上D_H也准确为0。没有用来源计数代替inverse-L权。

3个marked T全部非负。每个row的序列化T项按Fraction准确求和，定义完整Q的分母；正row共有332，Q总概率于是准确为1。N7存的float row_mass与该准确和的差全部在标准正和 `γ_(64·65)`界内。此检查不把eligibility删选后的q_H称作归一概率：被筛掉的marked质量仍是显式补集。

实际r最大值显示为：adaptive `4.1764941764`、optimum `4.0986983833`、delta1 `4.2115790422`，全部大于1。这再次证明本次K_finite=1仅是单位约定，不能冒充原row bound或据此调用母预算。

## 3. exact DP与dual价格证明

将每个序列化double S_[s,t)转换为准确dyadic Fraction；没有把N7浮点argmax当作证明。非负score下，定义

`V_0=0`，`V_t=max_(0≤s<t)[V_s+S_[s,t)]`。

N8准确计算全部65个prefix值及pred，再重建覆盖全64来源的互不相交interval partition。其准确score和等于V_64。

定义source atom dual价格

`π_k=V_(k+1)−V_k≥0`。

非负性来自singleton可选且score≥0。对每个interval，Bellman约束准确给

`Σ_(k=s)^(t−1)π_k=V_t−V_s≥S_[s,t)`。

所以对任何θ_H≥0、且每source `Σ_(H∋k)θ_H≤1` 的fractional interval packing，

`Σ_H θ_H S_H ≤Σ_kπ_k=V_64`。

DP partition达到此上界，故既是disjoint common partition最优，也是该正fractional packing最优。对于等质量source μ{k}=1/64，可令物理dual密度为64π_k，则其一份来源预算积分仍为Σπ；没有复制来源容量。随机共同partition混合的线性score也不可能超过此值。

这个证明直接给primal/dual witness，不依赖TU库、浮点LP status或整数优化包。JSON逐项保存全部prefix、atom价格、准确最优值、chosen intervals及旧N7chosen准确score/regret，便于独立复核2080个约束。

## 4. 全参数结果与费用口径

下表显示exact table坏账 `float(total_high_bill)−exact_best_score`。该total仍是冻结serialized scalar，不是理想积分的区间值；完整有理分数在JSON。

| c | ε | adaptive坏账 | optimum坏账 | delta1坏账 |
|---:|---:|---:|---:|---:|
| 1 | 1/2 | .28608255926314125 | .2149802322672321 | .4951913070914605 |
| 1 | 1/4 | .11527663663137443 | .09222338983466619 | .21356734198857455 |
| 1 | 1/8 | .100320258232355 | .08145971589446468 | .18426750100795958 |
| 2 | 1/2 | .12662138530667694 | .09374848125476863 | .20827171292812047 |
| 2 | 1/4 | .06255041053242574 | .04949831267832047 | .10610112590256907 |
| 2 | 1/8 | .05518867402440776 | .04392410688167324 | .09215509927230725 |

全部18个DP最优partition与N7给定chosen partition的准确score相同；没有近整数/浮点tie导致的非零regret。N8自选tie规则可能不必输出同一cut表示，但此输入的chosen值均达到准确最优。

每个parentwise乐观partition也逐一核是覆盖全部64来源的真partition。332个正row各用一整份来源，实际per-source load数组每项都是332，复制W准确为332；未认证其单父浮点DP最优性，因为N8没有重跑332份局部scoretable。该乐观对照不能作为common packing的合法payer。

N7新增的坏账三项（small_block_gate、raw_receiver_mismatch、mass_eligibility_loss）序列化值全非负，其准确和与本exact-table坏账的最大差约 `2.43e−16`。这是浮点总账一致性检查，不是对三项理想积分的独立区间证明。c/ε价格、low-L补集、τ=0全正L账也不能因partition paid比例高而删除；本证书不将它们合并成原母式常数。

## 5. 缺少的理想score误差界

确切有限DP不自动认证理想score。若以后能提供每interval严格界 `S_H^−≤S_H^ideal≤S_H^+`，对物理非负score先把负下界截为0，再用同样的Fraction DP分别计算上下表，即得理想最优值夹逼；某个chosen partition的ideal regret可由 `DP(S^+)−Σchosen S_H^−` 控制。

若只有统一绝对误差ε_score，则因每partition最多64簇，最优值误差至多64ε_score、table-optimal partition的ideal regret至多128ε_score。这里没有这样的联合误差输入；尤其q_H阈值、D_H的log/inverse-L与row marks相关，不能把单独L的稳定性检查当作全部score误差。原全μ/history/head/stop等更不在该有限模型内。

## 6. 实跑、复现与停止点

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r565_n8.py --n7 /tmp/ccu_r565_n7.json --assembled /tmp/ccu_r565_n7_assembled.npz --optimizer /tmp/ccu_r562_optimizer.json --n3 /tmp/ccu_r563_n3.json > /tmp/ccu_r565_n8.json
```

Python3.12.14，标准库Fraction，NumPy仅用于读取/轻核共享数组。单进程约 `.601` 秒，无QP、无重T/Gram实验、无新source或维度。

脚本 SHA256：`c905d5cb017dd077143db43411ca0ce1f25b0ee11d7754b03fd0c7a59e728152`。

N7 JSON SHA256：`53e9cc17a3b4138a708e66a95ed11d2b60aaa11512c6d42fe48837f8fcb80b15`。

共享assembled NPZ SHA256：`1d6052fd39d4f44e6ed7e106a80af2d23fb06eaa673ae1aa206aa4812660d383`。

归档命名为n8.py/n7.json/n7_assembled.npz/optimizer.json/n3.json时可用相对路径运行：

```
python n8.py --n7 n7.json --assembled n7_assembled.npz --optimizer optimizer.json --n3 n3.json > n8.json
```

仅写本角色三个文件，没有改N7、repo或PDF。新定量信息是此固定interval packing的不可再提高值及其完整剩余，并非一般根阶付款。完成停止。
