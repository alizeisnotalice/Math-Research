"""R565 N7 finite physical chi-lift partition diagnostic. No optimizer."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='2'
import argparse,json,time,math,hashlib,resource,platform
from pathlib import Path
import numpy as np
from scipy import sparse

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dp(scores,starts,ends,n=64):
 scores=np.atleast_2d(scores);v=np.zeros((len(scores),n+1));choice=np.zeros((len(scores),n+1),dtype=np.int16)
 for end in range(1,n+1):
  inds=np.flatnonzero(ends==end);cand=v[:,starts[inds]]+scores[:,inds];best=np.argmax(cand,axis=1);v[:,end]=cand[np.arange(len(scores)),best];choice[:,end]=starts[inds][best]
 cuts=[]
 for row in range(len(scores)):
  end=n;cc=[]
  while end:begin=int(choice[row,end]);cc.append([begin,end]);end=begin
  cuts.append(cc[::-1])
 return v[:,-1],cuts

def old_inverse(parents,masks,tau):
 counts=np.array([p['old_count'] for p in parents]);edges=np.array(sorted(set(counts)|set(2*counts)));left=np.log2(edges[:-1]/64);width=np.log2(edges[1:]/edges[:-1]);windows=(edges[:-1][None,:]>=counts[:,None])&(edges[:-1][None,:]<2*counts[:,None]);amp=np.array([p['weight']/p['R']**16 for p in parents]);L=(masks.T*amp)@windows
 inv=np.zeros_like(L);np.divide(1,L,out=inv,where=L>0);high=inv*(L>tau);low=inv*((L>0)&(L<=tau));base=np.array([1/p['R']**16/64 for p in parents])[:,None]
 D=base*masks*((windows*width)@high.T);Dlow=base*masks*((windows*width)@low.T)
 return D,Dlow,dict(edges_integer=edges.tolist(),L_values=L.tolist(),tau=tau,positive_L_range=[float(L[L>0].min()),float(L.max())],old_parent_weighted_D_high=float(sum(p['weight']*d.sum() for p,d in zip(parents,D))),old_parent_weighted_D_low=float(sum(p['weight']*d.sum() for p,d in zip(parents,Dlow))))

def run(args):
 start=time.perf_counter();x=json.load(open(args.optimizer));n3=json.load(open(args.n3));inp=json.load(open(args.input));pp=x['summary']['frozen_parent_records'];ss=x['summary']['action_states'];nv=len(ss);P=len(pp);parent=np.array([s['parent'] for s in ss]);count=np.array([s['count'] for s in ss]);phase=np.array([s['phase'] for s in ss]);receiver=np.zeros((nv,64))
 for i,s in enumerate(ss):receiver[i,s['receiver_atoms']]=1
 old=np.array([receiver[x['offsets'][p]] for p in range(P)]);amp=np.array([pp[p]['weight']/pp[p]['R']**16 for p in parent]);kernel=(phase[:,None]==phase[None,:])*np.maximum(1-abs(np.log2(count[:,None]/count[None,:])),0)/64
 # Atom rebuilding is the frozen original diagonal source recipe, hash checked.
 rng=np.random.default_rng(56116);atoms=rng.uniform(-.5,.5,size=(64,1))+.02*rng.uniform(-.5,.5,size=(64,16))
 ah=hashlib.sha256(json.dumps(list(atoms.shape),separators=(',',':')).encode()+np.asarray(atoms,dtype='<f8').tobytes()).hexdigest();assert ah==x['summary']['input_hashes']['atoms'];order=np.argsort(atoms[:,0],kind='stable');starts=np.array([i for j in range(1,65) for i in range(j)]);ends=np.array([j for j in range(1,65) for i in range(j)]);sizes=ends-starts
 D,Dlow,Li=old_inverse(pp,old,1/18);Dpref=np.c_[np.zeros(P),np.cumsum(D[:,order],axis=1)];DH=Dpref[:,ends]-Dpref[:,starts];oldpref=np.c_[np.zeros(P),np.cumsum(old[:,order],axis=1)];pH=(oldpref[:,ends]-oldpref[:,starts])/np.array([p['old_count'] for p in pp])[:,None]
 interval_index={(int(i),int(j)):k for k,(i,j) in enumerate(zip(starts,ends))};q0=np.array([p['q0'] for p in pp]);results={};saved=dict(source_order=order,starts=starts,ends=ends,D_high=D,D_low=Dlow,p_H=pH,D_H=DH)
 for law in ['adaptive','optimum','delta1']:
  rho=np.array(n3['rhos'][law]);weighted=rho*amp;W=weighted[:,None]*weighted[None,:]*kernel;T=np.zeros((P,64,65))
  for c in np.unique(count):
   inds=np.flatnonzero(count==c);contribution=(W[:,inds]@receiver[inds])*receiver;np.add.at(T[:,:,c],parent,contribution)
  row=T.sum((1,2));assert abs(sum(row)-n3['results'][law]['total'])<2e-12
  positive=row>0;tail=np.cumsum(T[:,:,::-1],axis=2)[:,:,::-1];rawprefix=np.c_[np.zeros(P),np.cumsum(T.sum(2)[:,order],axis=1)];qrawH=np.divide(rawprefix[:,ends]-rawprefix[:,starts],row[:,None],out=np.zeros_like(pH),where=row[:,None]>0);rowfactor=np.divide(row,q0);total=float(rowfactor@D.sum(1));lowbill=float(rowfactor@Dlow.sum(1));saved['T_'+law]=T;rr={}
  for c in [1,2]:
   # For H of size k, eligibility is partner count >=ceil(k/c).
   qH=np.zeros_like(pH)
   for size in range(1,65):
    inds=np.flatnonzero(sizes==size);eligible=tail[:,:,math.ceil(size/c)];prefix=np.c_[np.zeros(P),np.cumsum(eligible[:,order],axis=1)];num=prefix[:,ends[inds]]-prefix[:,starts[inds]];qH[:,inds]=np.divide(num,row[:,None],out=np.zeros_like(num),where=row[:,None]>0)
   for eps in [.5,.25,.125]:
    match=np.divide(qH,pH,out=np.zeros_like(qH),where=pH>0);admit=np.maximum(pH,qH)>=eps;paidparent=rowfactor[:,None]*DH*np.minimum(1,match)*admit;score=paidparent.sum(0);best,cuts=dp(score,starts,ends);optimistic,pcuts=dp(paidparent,starts,ends)
    key=f'c{c}_eps{eps:g}';singleton=np.flatnonzero(sizes==1);whole=np.flatnonzero(sizes==64)[0];paid=float(best[0]);bad=total-paid
    selected=np.array([interval_index[tuple(cut)] for cut in cuts[0]]);base=rowfactor[:,None]*DH[:,selected];gate=admit[:,selected];frac=np.minimum(1,match[:,selected]);rawfrac=np.minimum(1,np.divide(qrawH[:,selected],pH[:,selected],out=np.zeros_like(base),where=pH[:,selected]>0));badparts=dict(small_block_gate=float((base*(~gate)).sum()),raw_receiver_mismatch=float((base*gate*(1-rawfrac)).sum()),mass_eligibility_loss=float((base*gate*(rawfrac-frac)).sum()));assert abs(sum(badparts.values())-bad)<1e-11
    source_load=np.zeros(64)
    for p,cc in enumerate(pcuts):
     if positive[p]:
      for lo,hi in cc:source_load[lo:hi]+=1
    rr[key]=dict(c=c,epsilon=eps,total_weighted_high_bill=total,paid=paid,bad=bad,bad_decomposition=badparts,local_price_multiplier_c_over_epsilon=c/eps,paid_fraction=paid/total if total else None,partition_rank_intervals=cuts[0],interval_scores=score.tolist(),singleton_paid=float(sum(score[singleton])),whole_source_paid=float(score[whole]),individual_parent_optimistic_paid=float(sum(optimistic)),individual_parent_optimistic_bad=float(total-sum(optimistic)),individual_parent_source_load=source_load.tolist(),individual_parent_duplicated_W=float(source_load.mean()),individual_parent_max_source_load=float(max(source_load)),parent_optimistic_values=optimistic.tolist(),parent_optimistic_partitions=pcuts)
    saved['score_'+law+'_'+key]=score
   saved['q_H_'+law+f'_c{c}']=qH
  results[law]=dict(complete_chi_energy=float(row.sum()),row_mass=row.tolist(),total_high_weighted_bill=total,low_Li_weighted_complement=lowbill,full_positive_Li_weighted_bill=total+lowbill,positive_parent_rows=int(sum(positive)),parameters=rr)
 path=Path(args.output);npz=path.with_name(path.stem+'_assembled.npz');np.savez_compressed(npz,**saved)
 result=dict(schema='R565.N7.1',scope='Finite physical chi-lift surrogate only; original full Lebesgue/history Li, Ndelta, Cstar asymmetric head/stop unavailable',definition=dict(oldfamily='332 frozen evaluation bulk parents, original weights, all qbands collapsed',Lfin='sum parent weight * R^-16 oldmask(y) oldwindow(sigma)',Q_parent='normalize true ordered chi row with both actions, receiver, true phase/window overlap and partner captured mass marked',r_parent='row_energy/(parent_weight*q0)',K_finite=1,tau=1/18,marked_lift_total_mass='complete chi energy',score='sum(row_energy/q0)*1_max(pH,qH)>=eps*min(1,qH/pH)*D_H_tau',p_zero='zero matching score',ordering='source first coordinate increasing, stable ties',fractional_interval_packing='equivalent to integral disjoint interval partition DP by interval matrix total unimodularity; no additional LP run',optimistic='separate partition per parent duplicates source budget; not payable by one W'),input_hashes=dict(optimizer=sha(args.optimizer),n3=sha(args.n3),optimizer_input=sha(args.input)),code_sha256=sha(__file__),source_order=order.tolist(),interval_starts=starts.tolist(),interval_ends=ends.tolist(),Li=Li,results=results,assembled=dict(path=str(npz),sha256=sha(npz),bytes=npz.stat().st_size),cost=dict(total_seconds=time.perf_counter()-start,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,solver_calls=0),versions=dict(python=platform.python_version(),numpy=np.__version__))
 path.write_text(json.dumps(result,indent=2));print(json.dumps(dict(cost=result['cost'],summary={law:{k:{a:v[a] for a in ['paid_fraction','bad','individual_parent_optimistic_bad','individual_parent_duplicated_W']} for k,v in r['parameters'].items()} for law,r in results.items()}),indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--optimizer',default='/tmp/ccu_r562_optimizer.json');ap.add_argument('--n3',default='/tmp/ccu_r563_n3.json');ap.add_argument('--input',default='/tmp/ccu_r562_optimizer_input.json');ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();run(args)
