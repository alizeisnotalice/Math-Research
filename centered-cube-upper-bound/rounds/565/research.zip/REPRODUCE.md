# R565 portable reproduction — no optimizer or PDF

Interpreter: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`.
Python3.12.14, NumPy2.5.4, SciPy1.18.1, SymPy1.14.0; exact standard-library Fraction for the certificate. No Arb enclosure of ideal score assembly is claimed.

Extract `optimizer.json` and `optimizer_input.json` from committed `centered-cube-upper-bound/rounds/562/research.zip` (commit5437711af449b8a8132a866334fd323562fbe9d6), and `n3.py` from `rounds/563/research.zip` (commitce025dc55748ef1e8985bc468a7b6cd4ed40615b). Put them beside this package's n7.py, n8.py, verify.py. Input hashes are in verification.json. No optimizer is rerun.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n3.py --optimizer optimizer.json --output n3.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n7.py --optimizer optimizer.json --n3 n3.json --input optimizer_input.json --output n7.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n8.py --n7 n7.json --assembled n7_assembled.npz --optimizer optimizer.json --n3 n3.json > n8.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py > exact_checks.json
```

Parent actually executed these operations in /tmp/ccu_r565_repro (verify.py was run from its original /tmp/ccu_r565_verify.py path). N7 results and Li; N8 results, assembly_checks and row_audit matched the authors' outputs exactly. Runtime, enclosing hashes and paths change; mathematical results do not. N3 JSON includes execution-dependent fields, so its full-file hash can change even when all mathematical values match; N7/N8 validate the actual file hashes from that run.

The full 2.6MB N7 JSON and 1.8MB tensor are regenerable and deliberately not duplicated in Git. numerics_summary.json retains every parameter's decision totals, exact_certificate.json stores all 18 precise DP/atom-dual witnesses; n8.py regenerates and checks all2080 constraints per table. The exact certificate interprets serialized doubles as exact dyadics. It does not enclose ideal nonlinear row probabilities, inverse-field integrals or score gates; the separate assembly audit checks the stated finite surrogate, not the original continuous Cstar.

verify.py runs24 finite rational protocol cases in three stages (4/10/24 transitions), preserving the original product cut, both margins, Li and inverseLi costs, and actual terminal; symbolic mother residual is zero. The general theorem is supplied by the separately audited proof, not inferred from these cases.

No general input/dimension extension, software install, MATLAB run, repeated QP, or PDF compilation is part of this reproduction.
