"""R758 exact all-length path and source-overlap budget checks."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version

from flint import arb, ctx, __version__ as flint_version


def interval(y,r):
    return y-r,y+r


def meet(X,Y):
    return max(X[0],Y[0]),min(X[1],Y[1])


def length(X):
    return max(Q(0),X[1]-X[0])


def union_length(intervals):
    nonempty = [I for I in intervals if length(I)]
    endpoints = sorted({x for I in nonempty for x in I})
    return sum((r-l for l,r in zip(endpoints,endpoints[1:])
                if any(a <= (l+r)/2 <= b for a,b in nonempty)),Q(0))


def matmul(A,B):
    return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]


def descendants(pi,D):
    """All positive path prefixes, with their unweighted path mass."""
    def visit(path,weight):
        yield path,weight
        j = path[-1]
        for t in range(j):
            if D[j][t]:
                yield from visit(path+(t,),weight*D[j][t])
    for j,p in enumerate(pi):
        yield from visit((j,),p)


def geometry(name):
    L,shrink = Q(3,2),32
    if name == "chain":
        centers = tuple(Q(j,2) for j in range(4))
        T_radii = (Q(3,8),Q(1,2),Q(3,4),Q(7,4))
        connections = [(1,0),(2,1),(3,2)]
    elif name == "cross_layers":
        centers = (Q(0),Q(1,2),Q(1),Q(-3,8),Q(3,2),Q(1,4))
        T_radii = (Q(3,8),Q(1,2),Q(3,4),Q(1),Q(5,4),Q(3,2))
        connections = [(1,0),(2,1),(3,0),(3,1),(4,1),(4,2),(5,0),(5,2),(5,3),(5,4)]
    else:
        centers = tuple(Q(j,2) for j in range(9))
        T_radii = tuple(Q(j+1,3) for j in range(9))
        connections = [(j,t) for j in range(9) for t in range(j)
                       if j-t in (1,2,4) and abs(centers[j]-centers[t]) < (T_radii[j]+T_radii[t])/L]
    n = len(centers)
    labels = range(n)
    s = [r/L for r in T_radii]
    A = [interval(y,r) for y,r in zip(centers,s)]
    T = [interval(y,r) for y,r in zip(centers,T_radii)]
    E = [interval(y,r/shrink) for y,r in zip(centers,s)]
    pi = [length(I) for I in E]
    assert all(p>0 for p in pi)
    assert all(length(meet(X,Y))==0 for X,Y in combinations(E,2))
    assert all(meet(A[j],E[j])==E[j] and length(T[j])==L*length(A[j]) for j in labels)
    assert all(length(A[j]) < length(A[j+1]) for j in range(n-1))
    assert all(j>t and length(meet(A[j],A[t]))>0 for j,t in connections)
    theta = [[length(meet(T[j],E[t]))/pi[t] for t in labels] for j in labels]
    for j in labels:
        owner_length = sum(pi[t]*theta[j][t] for t in labels)
        assert owner_length == union_length(meet(T[j],I) for I in E) <= length(T[j])

    a = [pi[j]/length(A[j]) for j in labels]
    K,G_upper = Q(4),2+Q(1,shrink)
    c = K/G_upper
    links = [[Q(0) for _ in labels] for _ in labels]
    for j,t in connections:
        edge_use = Q(1+(j+2*t)%4,4)
        links[j][t] = links[t][j] = c*a[j]*pi[t]*edge_use
    C = [[links[j][t]/pi[j] for t in labels] for j in labels]
    D = [[C[j][t] if j>t else Q(0) for t in labels] for j in labels]
    assert all(sum(row)<=1 for row in C)
    assert all(pi[j]*C[j][t]==pi[t]*C[t][j] for j,t in product(labels,labels))
    piD = [sum(pi[j]*D[j][t] for j in labels) for t in labels]
    assert all(piD[t]<=pi[t] for t in labels)
    assert all(pi[j]*D[j][t] <= c*a[j]*pi[t] for j,t in product(labels,labels))
    assert any(pi[j]*D[j][t] == c*a[j]*pi[t] for j,t in connections)
    return {
        "name":name,"L":str(L),"centers":list(map(str,centers)),"s":list(map(str,s)),
        "owner_lengths_pi":list(map(str,pi)),"G_upper":str(G_upper),"K":str(K),
        "a":list(map(str,a)),"max_piD_over_pi":str(max(piD[j]/pi[j] for j in labels)),
        "edges_early_late_D": [[j,t,str(D[j][t])] for j,t in connections],
        "theta_positive_decreasing": [[j,t,str(theta[j][t])] for j in labels for t in range(j) if theta[j][t]],
        "checks":[path_and_matrix(D,pi,E,T,theta,c,a,L,q) for q in (Q(1),Q(17,16))],
    }


def path_and_matrix(D,pi,E,T,theta,c,a,L,q):
    n = len(pi)
    labels = range(n)
    identity = [[Q(j==t) for t in labels] for j in labels]
    powers = [identity]
    for _ in labels:
        powers.append(matmul(powers[-1],D))
    assert not any(map(any,powers[-1]))
    pre = [matmul([pi],P)[0] for P in powers]
    post = [[sum(row) for row in P] for P in powers]

    exact_pairs = defaultdict(Q)
    exact_union, exact_path_mass, counts = defaultdict(Q),defaultdict(Q),defaultdict(int)
    repeat_witness = None
    for path,weight in descendants(pi,D):
        k = len(path)-1
        weighted = weight*q**k
        exact_path_mass[k] += weighted
        counts[k] += 1
        for l in range(1,k+1):
            t = path[l]
            clipped = [meet(E[t],T[j]) for j in path[:l]]
            union = union_length(clipped)/pi[t]
            pair_sum = Q(0)
            for i,j in enumerate(path[:l]):
                individual = length(clipped[i])/pi[t]
                assert individual == theta[j][t]
                pair_sum += individual
                exact_pairs[k,i,l] += weighted*individual
            assert union<=pair_sum
            exact_union[k] += weighted*union
            if l>=2 and union<pair_sum and repeat_witness is None:
                repeat_witness = {"path":path,"late_index":l,
                                  "early_hit_fractions":list(map(str,(length(I)/pi[t] for I in clipped))),
                                  "union":str(union),"pair_sum":str(pair_sum)}
    assert repeat_witness is not None
    pair_checks = 0
    for k in labels:
        for l in range(1,k+1):
            for i in range(l):
                factorized = q**k*sum(pre[i][j]*powers[l-i][j][t]*theta[j][t]*post[k-l][t]
                                      for j,t in product(labels,labels))
                assert exact_pairs[k,i,l] == factorized
                pair_checks += 1
        assert exact_path_mass[k] == q**k*sum(pi[j]*post[k][j] for j in labels)

    R = [[sum(q**h*powers[h][j][t] for h in labels) for t in labels] for j in labels]
    R_diff = [[R[j][t]-identity[j][t] for t in labels] for j in labels]
    assert R_diff == matmul([[q*x for x in row] for row in D],R)
    prefix = matmul([pi],R)[0]
    A = [prefix[j]/pi[j] for j in labels]
    B = [sum(row) for row in R]
    assert sum(exact_path_mass.values()) == sum(pi[j]*B[j] for j in labels)
    pair_total = sum(exact_pairs.values())
    matrix_total = sum(prefix[j]*R_diff[j][t]*theta[j][t]*B[t] for j,t in product(labels,labels))
    assert pair_total == matrix_total
    assert all(R_diff[j][t] <= q*c*a[j]*prefix[t]/pi[j] for j,t in product(labels,labels))
    three_potentials = q*c*sum(a[j]*A[j]*A[t]*B[t]*length(meet(T[j],E[t]))
                               for j in labels for t in range(j))
    geometric_max = q*c*L*max(A[t]*B[t] for t in labels)*sum(pi[j]*A[j] for j in labels)
    union_total = sum(exact_union.values())
    assert 0 < union_total < pair_total <= three_potentials <= geometric_max
    nonadjacent = sum(mass for (_,i,l),mass in exact_pairs.items() if l-i>1)
    assert nonadjacent > 0
    return {
        "q":str(q),"all_lengths_path_counts":[counts[k] for k in labels],
        "all_lengths_path_mass":[str(exact_path_mass[k]) for k in labels],
        "verified_length_time_pairs":pair_checks,
        "path_pair_total":str(pair_total),"matrix_pair_total":str(matrix_total),
        "path_union_total":str(union_total),"nonadjacent_pair_mass":str(nonadjacent),
        "three_potential_bound":str(three_potentials),"geometric_max_bound":str(geometric_max),
        "overlap_witness":repeat_witness,
    }


def collision_scalar():
    ctx.prec = 256
    exponent = arb(2)/5+arb(1).exp()/32
    assert exponent < arb(1)/2
    rows = []
    for n in (16,256,65536,2**40):
        power = (arb(n).log()*2/5).exp()
        log_n2 = arb(n+2).log()
        U = power+2*log_n2
        sigma = log_n2/64
        factor = 2*(1+U)*(arb(1)/32+2*(U/n).exp()*sigma).exp()
        envelope = 2*(1+U)*(arb(1)/32+2*arb(1).exp()*sigma).exp()
        assert U<arb(n) and factor<envelope
        rows.append({"n":n,"U":U.str(13),"sigma":sigma.str(13),"factor":factor.str(13),
                     "factor_over_sqrt_n":(factor/arb(n).sqrt()).str(13)})
    return {"precision_bits":ctx.prec,"exponent":exponent.str(30),"sample_checks":rows}


def report():
    return {
        "scope":(
            "Actual Euclidean parent intervals, expanded intervals and pairwise disjoint full owners. "
            "The reversible graph weights are finite test kernels subject to the cap. "
            "The graph is not identified with an upstream filtered Euclidean flow."
        ),
        "scale":(
            "B=[-3/2,3/2]. A descending disjoint-family packing covers every shrunken owner "
            "with the (2+1/32)-dilated selected originals, providing the test upper bound G_upper."
        ),
        "python":python_version(),"python_flint":flint_version,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "models":[geometry(name) for name in ("chain","cross_layers","nine_nodes")],
        "collision_scalar":collision_scalar(),
    }


def main():
    cli = argparse.ArgumentParser()
    group = cli.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = cli.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for model in result["models"]:
        for row in model["checks"]:
            print(f"{model['name']} q={row['q']} paths={sum(row['all_lengths_path_counts'])} "
                  f"length-time pairs={row['verified_length_time_pairs']}")


if __name__ == "__main__":
    main()

