"""Reproducible finite persistence and real-cube interface guards.

All geometry, count probabilities and polynomial identities use Fraction.
Decimal logarithms/exponentials are repeated at 70/110 digits; those checks
are numerical stability checks, not outward-rounded certificates.
No dimensional-order fit, weak-bound proof, or mixed-probability MGF claim.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from math import comb
from pathlib import Path
import json


def dec(q):
    return D(q.numerator) / D(q.denominator)


def show(x):
    return format(x, '.17g')


def union_intervals(intervals):
    ans = []
    for lo, hi in sorted(intervals):
        if lo >= hi:
            continue
        if ans and lo <= ans[-1][1]:
            ans[-1] = (ans[-1][0], max(ans[-1][1], hi))
        else:
            ans.append((lo, hi))
    return ans


def interval_product(intervals):
    ans = F(1)
    for lo, hi in intervals:
        ans *= hi / lo
    return ans


def persistence_case(points, caps, x, n, a, b, k, label):
    """Active iff entry<=L<cap: at equal scales death precedes entry.

    An entry at b with cap>b counts for first hit, but has zero occupation.
    """
    r = k // 2
    radii = [max(a, 2 * max(abs(y - z) for y, z in zip(p, x)))
             for p in points]
    valid = [(j, e, cap) for j, (e, cap) in enumerate(zip(radii, caps))
             if e <= b and cap > e]
    events = {a: [[], []], b: [[], []]}
    for j, entry, cap in valid:
        events.setdefault(entry, [[], []])[1].append(j)
        if cap <= b:
            events.setdefault(cap, [[], []])[0].append(j)
    scales = sorted(events)
    live = set()
    first = None
    pieces = []
    counts = []
    for z, L in enumerate(scales):
        deaths, entries = events[L]
        live.difference_update(deaths)
        live.update(entries)
        # Independent direct membership, including both endpoints.
        direct = {j for j, e, cap in valid if e <= L < cap}
        assert live == direct
        counts.append((L, len(live)))
        if first is None and len(live) >= k:
            first = L
        if z + 1 < len(scales) and len(live) >= r:
            pieces.append((L, scales[z + 1]))
    event_product = interval_product(pieces)
    # A second implementation enumerates intersections of actual source
    # intervals, then takes their union; no event-count process is used.
    subset_pieces = []
    for sub in combinations(valid, r):
        lo = max(z[1] for z in sub)
        hi = min(b, min(z[2] for z in sub))
        if lo < hi:
            subset_pieces.append((lo, hi))
    merged = union_intervals(subset_pieces)
    subset_product = interval_product(merged)
    assert event_product == subset_product
    candidate_hits = []
    for sub in combinations(valid, k):
        lo = max(z[1] for z in sub)
        if lo <= b and min(z[2] for z in sub) > lo:
            candidate_hits.append(lo)
    independent_first = min(candidate_hits) if candidate_hits else None
    assert first == independent_first
    T = D(n) * dec(b / a).ln()
    O = D(n) * dec(event_product).ln()
    event_length = sum((D(n) * dec(hi / lo).ln() for lo, hi in pieces), D(0))
    subset_length = sum((D(n) * dec(hi / lo).ln() for lo, hi in merged), D(0))
    tol = D('1e-35')
    assert abs(event_length - subset_length) < tol
    assert abs(O - event_length) < tol
    hit = first is not None
    # Exact log comparisons avoid an artificial boundary flip due to rounding.
    zero_horizon = a == b
    long = None if zero_horizon else event_product ** (k - 1) >= b / a
    late = None if zero_horizon else hit and (first / a) ** (k - 1) > (b / a) ** (k - 2)
    early_short = None if zero_horizon else hit and not late and not long
    if not zero_horizon:
        assert not hit or long or late or early_short
    return dict(label=label, n=n, sources=len(points), a=str(a), b=str(b), k=k, r=r,
                common_receiver=[str(z) for z in x],
                common_positions=[[str(z) for z in y] for y in points],
                caps=[str(z) for z in caps], capture_scales=[str(z) for z in radii],
                first_hit_scale=str(first) if hit else None,
                first_hit_time=show(D(n) * dec(first / a).ln()) if hit else None,
                horizon=show(T), d_and_v=show(T / (k - 1)), occupation=show(O),
                occupation_scale_product=str(event_product), long=long, late=late,
                early_short=early_short, hit=hit,
                invalid_death_before_or_at_entry=sum(cap <= e for e, cap in zip(radii, caps)),
                entry_at_terminal_alive=sum(e == b and cap > b for e, cap in zip(radii, caps)),
                zero_horizon=zero_horizon,
                branches_not_applicable_zero_horizon=zero_horizon,
                all_caps_strictly_above_start=all(cap > a for cap in caps),
                input_role=('illegal_cap_at_start_filter_test' if
                            label == 'zero_horizon_death_first' else 'positive_height_prm_geometry'),
                event_counts=[[str(L), count] for L, count in counts])


def geometry_stage(precision):
    stages = []
    with localcontext() as ctx:
        ctx.prec = precision
        for phase, N in enumerate([7, 9, 12], 1):
            rows = []
            for n in [1, 2, 4, 8, 16]:
                x = tuple(F(phase, 16) * (-1 if j % 2 else 1) for j in range(n))
                points, caps = [], []
                for i in range(N):
                    entry = F(4 + ((3 * i + phase) % 10), 4)
                    cap = F(4 + ((5 * i + 2 * phase) % 13), 4)
                    if i % 5 == 0:
                        cap = entry
                    # Deliberately cover all three persistence regimes in each
                    # stage using actual cube positions, not synthetic counts.
                    if n in [2, 4, 8]:
                        entry, cap = ((F(1), F(11, 10)) if n == 2 else
                                      (F(5, 2), F(4)) if n == 4 else
                                      (F(1), F(4))) if i < 4 else (F(4), F(5))
                    if cap <= 1:
                        cap = F(9, 8)
                    assert cap > 1
                    points.append(tuple(x[j] + (-1 if (i + j) % 2 else 1) *
                                        entry / 2 * (1 - F(j % 3, 4))
                                        for j in range(n)))
                    caps.append(cap)
                for k in [2, 3, 4]:
                    rows.append(persistence_case(points, caps, x, n, F(1), F(3), k,
                                                 'correlated_geometry'))
            stages.append(dict(stage=phase, rows=rows))
        explicit = []
        for name, entry, cap, a, b in [
                ('long', F(1), F(4), F(1), F(3)),
                ('late', F(5, 2), F(4), F(1), F(3)),
                ('early_short', F(1), F(11, 10), F(1), F(3)),
                ('terminal_entry', F(3), F(4), F(1), F(3)),
                ('death_at_entry', F(3, 2), F(3, 2), F(1), F(3)),
                ('zero_horizon_alive', F(1), F(2), F(1), F(1)),
                ('zero_horizon_death_first', F(1), F(1), F(1), F(1))]:
            for k in [2, 3, 4]:
                points = [(entry / 2,)] * k + [(F(2),)] * (7 - k)
                caps = [cap] * k + [F(5)] * (7 - k)
                row = persistence_case(points, caps, (F(0),), 1, a, b, k, name)
                if name == 'long':
                    assert row['hit'] and row['long']
                elif name in ('late', 'terminal_entry'):
                    assert row['hit'] and row['late'] and not row['long']
                elif name == 'early_short':
                    assert row['early_short']
                elif name in ('death_at_entry', 'zero_horizon_death_first'):
                    assert not row['hit']
                elif name == 'zero_horizon_alive':
                    assert row['hit'] and row['first_hit_time'] == '0'
                explicit.append(row)
    return dict(stages=stages, explicit_endpoints=explicit,
                scope='One common deterministic source-position/cap configuration per case; '
                      'real continuous cube capture, t=n log(L/a). Formal-stage caps>a. '
                      'The explicit cap=a zero-horizon case is an illegal-boundary '
                      'filter test, not a positive-height PRM sample. Zero T has no '
                      'long/late/early-short branch. Caps are fixed histories, '
                      'not independent receiver resampling or a stochastic probability estimate.')


def binomial_tail(k, r, p):
    return sum((F(comb(k, j)) * p ** j * (1 - p) ** (k - j)
                for j in range(r, k + 1)), F(0))


def pure_death_coefficients(k):
    """Solve P'_j=-j P_j+(j+1)P_{j+1}, P_j(0)=1{j=k}.

    Coefficient l multiplies exp(-l t); distinct generator rates suffice.
    """
    states = {k: {k: F(1)}}
    for j in range(k - 1, -1, -1):
        coeff = {l: -F(j + 1, l - j) * v for l, v in states[j + 1].items()}
        coeff[j] = -sum(coeff.values(), F(0))
        states[j] = coeff
    return states


def integral_polynomial(k, r, p, second=False):
    return sum((F(comb(k, j) * comb(k - j, ell) * (-1) ** ell) *
                (F(2, (j + ell) ** 2) if second else
                 (1 - p ** (j + ell)) / (j + ell))
                for j in range(r, k + 1) for ell in range(k - j + 1)), F(0))


def death_exact():
    stages = []
    for phase, kvals in enumerate([[2, 3, 4], [8, 12, 16], [24, 32, 64]], 1):
        rows = []
        for k in kvals:
            r = max(1, k // 2)
            mean = sum((F(1, j) for j in range(r, k + 1)), F(0))
            var = sum((F(1, j * j) for j in range(r, k + 1)), F(0))
            assert r * mean <= k
            assert integral_polynomial(k, r, F(0)) == mean
            assert integral_polynomial(k, r, F(0), second=True) == mean * mean + var
            coefficients = pure_death_coefficients(k)
            for p in [F(1, 2), F(1, 4), F(1, 16)]:
                tail = binomial_tail(k, r, p)
                transition = sum((v * p ** l for j in range(r, k + 1)
                                  for l, v in coefficients[j].items()), F(0))
                assert tail == transition
                integ = integral_polynomial(k, r, p)
                ode_integral = sum((v * (1 - p ** l) / l
                                    for j in range(r, k + 1)
                                    for l, v in coefficients[j].items()), F(0))
                assert integ == ode_integral
                if k <= 8:
                    enumeration = sum((p ** sum(bits) * (1 - p) ** (k - sum(bits))
                                       for bits in product([0, 1], repeat=k)
                                       if sum(bits) >= r), F(0))
                    assert tail == enumeration
                rows.append(dict(k=k, r=r, p=str(p), tail=str(tail),
                                 integral_to_minus_log_p=str(integ), mean_duration=str(mean),
                                 variance_duration=str(var), r_times_mean=str(r * mean)))
        stages.append(dict(stage=phase, rows=rows))
    optimized = []
    for k in [4, 8, 16, 32, 64, 128, 256]:
        scores = {r: r * sum((F(1, j) for j in range(r, k + 1)), F(0))
                  for r in range(1, k + 1)}
        ranges = {'all': range(1, k + 1), 'lower_half': range(1, k // 2 + 1),
                  'upper_half': range((k + 1) // 2, k + 1)}
        for label, allowed in ranges.items():
            best = max(scores[r] for r in allowed)
            winners = [r for r in allowed if scores[r] == best]
            assert best <= k
            optimized.append(dict(k=k, range=label, best_r=winners, maximum_r_mean=str(best),
                                  maximum_over_k=str(best / k),
                                  all_range_minimum=str(min(scores.values()))))
    return dict(stages=stages, exact_optimization=optimized,
                scope='Independent Exp(1) pure-death process starting at k, stopping below r; '
                      'exact generator/positive binomial/polynomial-integral identities. '
                      'r E D<=k is a linear duration interface, not a sqrt(T) bound.')


def death_tails(precision):
    rows = []
    with localcontext() as ctx:
        ctx.prec = precision
        for m in [8, 16, 32, 64]:
            k, r = m + 1, (m + 1) // 2
            p = (-D(m)).exp()
            terms = [D(comb(k, j)) * p ** j * (1 - p) ** (k - j)
                     for j in range(r, k + 1)]
            tail = sum(terms, D(0))
            bound = D(2) ** k * (-D(m * r)).exp()
            assert 0 < tail <= bound
            rows.append(dict(m=m, k=k, r=r, duration=str(m),
                             positive_binomial_tail=show(tail),
                             union_bound=show(bound), log_tail=show(tail.ln())))
    return rows


def overlap_stage():
    stages = []
    for phase, N in enumerate([3, 4, 5], 1):
        rows = []
        a, b = [(F(1), F(3, 2)), (F(5, 4), F(2)), (F(3, 2), F(5, 2))][phase - 1]
        lam, m = F(phase, 2), F(phase + 1)
        for n in [1, 2, 3]:
            points = [tuple(F(((i + 1) * (j + 2) + phase) % 7 - 3, 4)
                            + F(i, 16) for j in range(n)) for i in range(N)]
            weights = [F(i + 1, N * (N + 1) // 2) for i in range(N)]
            W = sum(weights, F(0))
            hs, ht = m / (lam * a ** n), m / (lam * b ** n)
            axes = [sorted({y[j] + sign * L / 2 for y in points
                            for sign in [-1, 1] for L in [a, b]}) for j in range(n)]
            cells = product(*[list(zip(axis, axis[1:])) for axis in axes])
            sums = {name: F(0) for name in ['A', 'B', 'covariance', 'qs', 'qt', 'difference_variance']}
            count = 0
            for box in cells:
                x = tuple((lo + hi) / 2 for lo, hi in box)
                vol = F(1)
                for lo, hi in box:
                    vol *= hi - lo
                ms = sum((w for y, w in zip(points, weights)
                          if all(abs(y[j] - x[j]) <= a / 2 for j in range(n))), F(0))
                mt = sum((w for y, w in zip(points, weights)
                          if all(abs(y[j] - x[j]) <= b / 2 for j in range(n))), F(0))
                qs, qt, cov = hs * ms, ht * mt, ht * ms
                A, B = qt - cov, qs - cov
                assert A >= 0 and B >= 0 and mt >= ms
                assert A + B == qs + qt - 2 * cov
                for name, value in [('A', A), ('B', B), ('covariance', cov),
                                    ('qs', qs), ('qt', qt), ('difference_variance', A + B)]:
                    sums[name] += vol * value
                count += 1
            overlap = (a / b) ** n
            assert lam * sums['A'] == m * W * (1 - overlap)
            assert lam * sums['B'] == m * W * (1 - overlap)
            assert lam * sums['covariance'] == m * W * overlap
            assert lam * sums['qs'] == lam * sums['qt'] == m * W
            rows.append(dict(n=n, sources=N, points=[[str(z) for z in y] for y in points],
                             weights=[str(z) for z in weights], a=str(a), b=str(b),
                             lam=str(lam), m=str(m), W=str(W), hs=str(hs), ht=str(ht),
                             exp_minus_delta=str(overlap), spatial_rectangles=count,
                             integrals={name: str(lam * value) for name, value in sums.items()}))
        stages.append(dict(stage=phase, rows=rows))
    return dict(stages=stages,
                scope='Actual finite atomic sources and full Lebesgue rectangle partition '
                      'of nested centered cubes in dimensions 1,2,3. q_s=h_s mu(Q_a), '
                      'q_t=h_t mu(Q_b), cov=h_t mu(Q_a). A+B is the independent '
                      'Poisson difference-variance decomposition. Integrated log-MGF '
                      'is not interpreted as the log-MGF of a mixed receiver law.')


def poisson_tail_moments(mean, threshold):
    """Tail probability and first/second raw moments; no count cutoff.

    Small finite thresholds allow complementary finite CDFs at high precision.
    These Decimal evaluations are numerical, not directed certificates.
    """
    def tail(j):
        if j <= 0:
            return D(1)
        p = (-mean).exp()
        cumulative = p
        for ell in range(1, j):
            p *= mean / ell
            cumulative += p
        return 1 - cumulative
    p0 = tail(threshold)
    p1 = mean * tail(threshold - 1)
    p2 = mean * mean * tail(threshold - 2) + p1
    return p0, p1, p2


def stopped_batch_death(precision):
    stages = []
    with localcontext() as ctx:
        ctx.prec = precision
        tolerance = D('1e-35')
        for phase, k in enumerate([3, 6, 12], 1):
            rows = []
            betas = [F(1, 2), F(2), F(8)]
            betas = betas[phase - 1:] + betas[:phase - 1]
            for qinitial in [F(1, 2), F(2), F(8)]:
                q0 = dec(qinitial)
                m = k - 1
                alive = []
                prob = (-q0).exp()
                for i in range(k):
                    if i:
                        prob *= q0 / i
                    alive.append(prob)
                tp, t1, t2 = poisson_tail_moments(q0, k)
                absorbed = t2 - 2 * q0 * t1 + q0 * q0 * tp
                hit_probability = tp
                low_hit = tp if q0 <= D(m) / 2 else D(0)
                occupation = death_bracket = birth_bracket = D(0)
                q = q0
                L = F(1)
                # Dimension one: t=log L and each p is the exact scale ratio.
                source = [dict(position='0', mass=str(qinitial / m), birth_scale='1')]
                transitions = []
                for survival, beta in zip([F(1, 2), F(1, 4), F(3, 4)], betas):
                    p = dec(survival)
                    step_occ = sum((weight * (D(i) * (1 - p) +
                                   ((D(i) - q) ** 2 - i) * (1 - p * p) / 2)
                                    for i, weight in enumerate(alive)), D(0))
                    step_death = sum((weight * i * (1 - p)
                                      for i, weight in enumerate(alive)), D(0))
                    assert step_occ >= -tolerance
                    occupation += step_occ
                    death_bracket += step_death
                    new_alive = [sum((alive[i] * D(comb(i, j)) * p ** j *
                                      (1 - p) ** (i - j) for i in range(j, k)), D(0))
                                 for j in range(k)]
                    assert abs(sum(new_alive, D(0)) - sum(alive, D(0))) < tolerance
                    alive = new_alive
                    q *= p
                    L /= survival
                    beta_d = dec(beta)
                    before_mass = sum(alive, D(0))
                    birth_bracket += beta_d * before_mass
                    after_q = q + beta_d
                    retained = [D(0)] * k
                    birth_probs = [(-beta_d).exp()]
                    for ell in range(1, k):
                        birth_probs.append(birth_probs[-1] * beta_d / ell)
                    batch_hit = batch_square = D(0)
                    for j, weight in enumerate(alive):
                        tail_p, tail_1, tail_2 = poisson_tail_moments(beta_d, k - j)
                        square = tail_2 + 2 * (D(j) - after_q) * tail_1 + \
                                 (D(j) - after_q) ** 2 * tail_p
                        assert square >= -tolerance
                        batch_hit += weight * tail_p
                        batch_square += weight * square
                        for ell in range(k - j):
                            retained[j + ell] += weight * birth_probs[ell]
                    assert abs(sum(retained, D(0)) + batch_hit - before_mass) < tolerance
                    absorbed += batch_square
                    hit_probability += batch_hit
                    if after_q <= D(m) / 2:
                        low_hit += batch_hit
                    transitions.append(dict(survival=str(survival), duration=show(-p.ln()),
                                            beta=str(beta), birth_scale=str(L),
                                            q_after=show(after_q),
                                            alive_probability=show(sum(retained, D(0))),
                                            batch_first_hit_probability=show(batch_hit)))
                    source.append(dict(position=str(L / 2), mass=str(beta * L / m),
                                       birth_scale=str(L)))
                    alive, q = retained, after_q
                terminal_square = sum((weight * (D(i) - q) ** 2
                                       for i, weight in enumerate(alive)), D(0))
                stopped_square = absorbed + terminal_square
                lhs = stopped_square + 2 * occupation
                rhs = q0 + birth_bracket + death_bracket
                assert abs(lhs - rhs) < tolerance
                assert abs(hit_probability + sum(alive, D(0)) - 1) < tolerance
                low_bound = stopped_square / (D(m) / 2) ** 2
                assert low_hit <= low_bound + tolerance
                rows.append(dict(k=k, m=m, initial_q=str(qinitial),
                                 stopped_centered_square=show(stopped_square),
                                 centered_square_occupation=show(occupation),
                                 initial_bracket=str(qinitial), birth_bracket=show(birth_bracket),
                                 death_bracket=show(death_bracket), lhs=show(lhs), rhs=show(rhs),
                                 identity_absolute_residual_below_1e_35=True,
                                 first_hit_probability=show(hit_probability),
                                 first_hit_with_q_at_most_m_over_2=show(low_hit),
                                 low_mean_markov_upper=show(low_bound),
                                 terminal_no_hit_probability=show(sum(alive, D(0))),
                                 transitions=transitions, actual_dimension_one_source=source,
                                 terminal_scale=str(L)))
            stages.append(dict(stage=phase, rows=rows))
    return dict(stages=stages,
                scope='Fixed receiver x=0, dimension one, lambda=1, L0=1. Initial '
                      'source at 0 has mass q0/m; deterministic birth at L_j uses '
                      'source y_j=L_j/2 with mass beta_j L_j/m. The same full source '
                      'generates q=m mu(Q_L)/L. Natural first-hit stopping at N>=k; '
                      'birth tails use Poisson moments without a count truncation. '
                      'This certifies finite-state numerical identities at one receiver, '
                      'not a Lebesgue-space budget or general weak bound.')


def main():
    geo70, geo110 = geometry_stage(70), geometry_stage(110)
    assert geo70 == geo110
    death = death_exact()
    tail70, tail110 = death_tails(70), death_tails(110)
    assert tail70 == tail110
    overlap = overlap_stage()
    stopped70, stopped110 = stopped_batch_death(70), stopped_batch_death(110)
    assert stopped70 == stopped110
    out = dict(status='PASS finite persistence guards', geometry=geo70,
               pure_death=death, large_death_tails=tail70, two_time_cube_overlap=overlap,
               stopped_birth_death=stopped70,
               scope='Three increasing finite source/count stages; no random seeds, no '
                     'dimensional-order fit, no general weak-bound closure, no good-jitter '
                     'environment or high-weak-event certification, and no conversion '
                     'of integrated log-MGF into mixed probability. Decimal 70/110 '
                     'agreement is not interval arithmetic.')
    Path(__file__).with_name('results.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(dict(status=out['status'], geometry_cases=45,
                         explicit_endpoint_cases=21, exact_death_rows=27,
                         optimization_rows=21, large_tail_rows=4, cube_overlap_rows=9,
                         stopped_birth_death_rows=9)))


if __name__ == '__main__':
    main()
