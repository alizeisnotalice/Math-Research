from fractions import Fraction as F
from pathlib import Path
import json

def run():
    checks=0; empty=0; degenerate=0
    for n in [1,2,3,16,64,256]:
      for a in [F(1),F(3,2)]:
       for b in [a,a*F(5,4),2*a,8*a]:
        for d in [a/256,a/16,a/4,a,3*a]:
         for r in [a/2,a,a+d/2,a+d,a+2*d,b,b+d,b+2*d]:
          m=r**n; u=F(1)
          assert m/u==r**n
          if r<=a:
            assert m/a**n<=u
            empty+=1
            continue
          A=max(a,r-d); B=min(b,r)
          if A>B:
            empty+=1; continue
          assert B/A<=1+d/a
          assert B-A<=d
          if A==B: degenerate+=1
          for R in [a,b,A,B,(A+B)/2]:
            if a<=R<=b and r-d<R<r:
              assert A<=R<=B
          checks+=1
    return dict(kind="exact rational window checks; not FULL or general numerical proof",checks=checks,empty=empty,degenerate=degenerate,dimensions=[1,2,3,16,64,256])
if __name__=="__main__":
 p=Path(__file__).with_suffix(".json"); p.write_text(json.dumps(run(),ensure_ascii=False,sort_keys=True,indent=2)+"\n"); print(p.read_text())
