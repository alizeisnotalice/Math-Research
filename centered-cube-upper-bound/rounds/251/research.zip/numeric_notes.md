# R251：单包有限L1几何、原始捕获与短窗口

最终实际完成9个真实L1盒模型（初探3、压力3、扩大3），72个level records、37个source pieces、2460项缓存一维交长核验、206200项逐source/R/receiver whole-cell bounds。另有32个精确标量窗口（24个低维、8个高维）；不包含或重复计入主代理window_checks.py的另套检查。没有QP、蒙特卡洛、L1点源外推或维数阶拟合。

原先只探C(1+nd/a)，父级随后给出并独审通过精确价c_d=2+n log(1+d/a)。以下有限level下界与价的对比只是实现一致性；真正任意L1上界来自主稿证明，不能以所有有限样本低于价作为数值证明。

## 运行前菜单和真实来源

全部a=1,b=2、总mass=1，支持在中心为0的Q_d。uniform为该整个正体积cube上的常密度1/d^n。corner mixture含2^n个互不相交正体积小cube，side=d/8，center各坐标为±7d/16。等质量时每piece质量2^-n；非均匀时按lexicographic corner顺序用weights1,...,2^n并归一。所有density有限正、所有piece参数都保JSON。

|阶段/模型|n,d|原始piece数|receiver cell side|
|---|---|---:|---:|
|初探uniform|1,1|1|1/32|
|初探uniform|2,1/2|1|1/8|
|初探uniform|3,1/3|1|1/4|
|压力corners equal|1,1|2|1/32|
|压力corners equal|2,1|4|1/8|
|压力corners equal|3,1|8|1/4|
|扩大corners nonuniform|2,1/2|4|1/8|
|扩大corners nonuniform|3,1/2|8|1/4|
|扩大corners nonuniform|3,1|8|1/4|

因此包含d=1/n、1/ceil(sqrt(n))及d=1的低维资格；不同模型的总质量不能累加当作一个原来源。

## 严格levelset体积下界与连续尺度比较

receiver cells无重叠地铺满[-3/2,3/2]^n。任何R<=2的正响应都位于Q_{2+d}中，d<=1，故此外盒覆盖全部可能正响应；不是未经说明截断无限receiver域。三维每模型外盒1728 cells，一/二维分别96/576。几何上严格没有响应的cells可先跳过。

R网格={1,5/4,3/2,7/4,2}。逐source的receiver-cell坐标交长下界取两个端点的最小值，上界取端点与source中心投影处的最大值；乘各坐标交长和原density，正求和得到whole-cell质量上下界。计算完全Fraction，使用的是同一个receiver center变量，不把来源独立化。

L_cell=max_grid lower_mass(R)/R^n。只有L_cell>u的整cell才计入严格levelset测度下界；阈值u={1/32,1/16,1/8,1/4,1/2,3/4,1,3/2}。有限尺度见证足以给真实sup的下界，但绝不声称grid最大等于连续sup。

可选连续尺度upper：对R in [R_j,R_{j+1}]，mass单调给response<=upper_mass(R_{j+1})/R_j^n，取最大得到U_cell。由U_cell>u的cells覆盖真实严格levelset，得到其体积上界夹逼。它只作几何范围比较，没有把该粗enclosure的松紧当普遍定理。每个level保存Fraction体积下/上界、u体积/mass、原(1+nd)归一比。

## 有限数据与新价

每模型以下选取其菜单中最大lower/c_d的level：

|模型|u|u·levelset体积下界/mass|c_d|lower/c_d|
|---|---:|---:|---:|---:|
|n1 d1 uniform|1/4|31/64|2.69314718|0.179855|
|n2 d1/2 uniform|1/4|25/64|2.81093022|0.138966|
|n3 d1/3 uniform|1/8|13/32|2.86304622|0.141894|
|n1 d1 corners equal|1/4|5/8|2.69314718|0.232070|
|n2 d1 corners equal|1/8|19/32|3.38629436|0.175339|
|n3 d1 corners equal|1/16|67/128|4.07944154|0.128311|
|n2 d1/2 nonuniform|1/4|141/256|2.81093022|0.195943|
|n3 d1/2 nonuniform|1/16|91/256|3.21639532|0.110518|
|n3 d1 nonuniform|1/16|7/16|4.07944154|0.107245|

最大有限lower/newprice约0.2320704953；原(1+nd)归一lower最大5/16。u>=1时严格levelset在这些mass1,a1模型中为空，保零分支。粗胞/有限R会漏掉许多实际水平集点，这些数值不是极值搜索、sharp constant估计或高维规律。

## 来源包的实际捕获信息

对每个被whole-cell计入的receivercell，选其最大L_cell的见证R。另在该cell中心，以原各piece精确盒交计算真实capture mass、各piece捕获比例、hit数和full数；中心诊断不代替任何levelset体积。输出每level的capture范围/均值、原始piece数、hit/full范围，以及仅用总质量上界1会多付的最大差。

这一步不可把原source包总mass当成已经捕获的质量。在三维非均匀d1模型、u=1/32时，某些counted cell的中心实际只捕获总mass的1/18。一个更清晰的误差例为：

- receivercell中心x=(-5/8,-3/8,-3/8)，见证R=2；
- whole-cell响应下界5/144>1/32，所以它对levelset的正体积贡献已独立成立；
- 原8个source pieces中仅前4个被捕获，分别mass=1/36,1/18,1/12,1/9，合计5/18；各自capture fraction为1，其余4个为0；
- 若人为把同一总mass1均匀铺在整个支撑C，capture估计为7/8，误差43/72。

uniform-C计算只是展示丢失包内非均匀性的人工proxy，不是合法正支配、也不是替换原来源的计划。原始hit数可从1到8变化；source包计数1不能代表其中多少真实pieces或多少质量被接收cube取到。这些信息不反驳主稿单包弱界，反而说明它为何必须对任意原L1密度证明，不能靠包中心或总质量捕获假设。

## 精确窗口端点检查

自身32个标量菜单：n1/d1、n2/d1/2、n3/d1/3各8个r值；另n512/d1/512和n1e6/d1/1000各4个r值。高维只做窗口算术，不生成高维L1输入或receiver几何。

用精确rational r定义概念阈值u=mass/r^n，低/高端点A=max(a,r-d)、B=min(b,r)。核非退化窗ratio B/A<=1+d/a，所有32例通过；高维不构造r^n巨整数。覆盖r<=a、r>b+d、cross a/b和端点相等。r<=a时原严格levelset确为空；r>b+d只说明外区无见证，不能删掉内部Qr的质量价。

JSON nondegenerate_external_window只表示正长度窗口，不能把false统称空。A=B若端点有序，一般可为合法单尺度窗口，其硬column有常数1而非0；例如a=b的情况需另按单尺度处理。本脚本a1,b2，未测试a=b。windowratio的零log只记录无正长度的log部分，不能据它把单尺度column漏掉。主代理另套退化窗口检查不计入本文件32例。

主稿证明中的内部Qr体积成本m，加外部短窗column的1+n log(B/A)，给2+n log(1+d/a)。本文件仅核有限端点/价格数值，未借数值替代该证明。

## 精度、复现和边界

几何、阈值、捕获和窗口ratio用Fraction；对数价格及比值用mp40/70独立计算，enc50保实际工作精度差。最大字段差/max(1,abs(high))=8.4449618681e-39，主要包含高维标量日志；普通mpmath不是directed interval error。实际完成初版9模型运行及在合同最终冻结、窗口标签修正后的正式完整运行，没有额外timing replay。

本机Python3.12.14、mpmath1.3.0，仅标准库+vendor mpmath，无numpy/scipy/MATLAB需求。解压后在同目录执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 cluster_checks.py --contract task_contract.md --output replay.json
cmp cluster_checks.json replay.json
```

CLI默认相邻cluster_checks.json和task_contract.md，也支持--output/--contract迁移。JSON无时间戳、runtime或绝对路径；绑定source和冻结合同SHA。只包含本文件实际运行结果，不导入主代理window_checks结果。整个有限试验不认证FULL/history、多个source包的无价聚合或一般root预算。

冻结source SHA256：73e163cafd0975c24433bfe7affdb01c68f29a4a05a08675f71933a7fe130982；JSON178182字节、SHA256：3268cc31148bce01fb6c41150de0a5d5955ee9e0c14cc66fa566af73bec06723；合同SHA256：6759167f64b71eb906c93bd2eb3fa4e65f4a8eeb151c209c25c6fa1dd703938a。
