#!/usr/bin/env python3
"""R251 finite L1 cluster evidence; exact geometry, non-interval log prices."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from math import prod,isqrt
import argparse,hashlib,json
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fm(x):return mp.mpf(x.numerator)/x.denominator
def enc(x):return mp.nstr(x,50)
def length(z,side,x,R):return max(F(),min(z+side/2,x+R/2)-max(z-side/2,x-R/2))
def models():
    return [('initial',1,F(1),'uniform'),('initial',2,F(1,2),'uniform'),('initial',3,F(1,3),'uniform'),('pressure',1,F(1),'corners_equal'),('pressure',2,F(1),'corners_equal'),('pressure',3,F(1),'corners_equal'),('expanded',2,F(1,2),'corners_nonuniform'),('expanded',3,F(1,2),'corners_nonuniform'),('expanded',3,F(1),'corners_nonuniform')]
def sources(n,d,kind):
    if kind=='uniform':return [{'center':(F(),)*n,'side':d,'mass':F(1),'density':1/d**n}]
    side=d/8;cs=list(product([-1,1],repeat=n));weights=[1]*len(cs) if kind=='corners_equal' else list(range(1,len(cs)+1));den=sum(weights)
    return [{'center':tuple(sign*(d-side)/2 for sign in c),'side':side,'mass':F(w,den),'density':F(w,den)/side**n} for c,w in zip(cs,weights)]

def geometry(spec):
    phase,n,d,kind=spec;ps=sources(n,d,kind);h={1:F(1,32),2:F(1,8),3:F(1,4)}[n];Rgrid=[F(1),F(5,4),F(3,2),F(7,4),F(2)];us=[F(1,32),F(1,16),F(1,8),F(1,4),F(1,2),F(3,4),F(1),F(3,2)]
    coords=[F(-3,2)+(F(i)+F(1,2))*h for i in range(int(3/h))]
    cache={};oneDchecks=0
    for z,side in {(z,p['side']) for p in ps for z in p['center']}:
        for ix,x in enumerate(coords):
            for j,R in enumerate(Rgrid):
                left,right=x-h/2,x+h/2;low=min(length(z,side,left,R),length(z,side,right,R));high=max(length(z,side,left,R),length(z,side,right,R),length(z,side,min(right,max(left,z)),R));center=length(z,side,x,R)
                assert low<=center<=high;cache[(z,side,ix,j)]=(low,high,center);oneDchecks+=1
    acc=[{'u':u,'lower_count':0,'upper_count':0,'capture_sum':F(),'capture_min':None,'capture_max':F(),'hit_min':None,'hit_max':0,'full_min':None,'full_max':0,'max_uniform_error':F(),'max_total_mass_slack':F(),'witness_R_counts':[0]*len(Rgrid),'example':None} for u in us]
    per_source_bounds=0;nonzero_cells=0
    for idx in product(range(len(coords)),repeat=n):
        center=tuple(coords[i] for i in idx)
        # The outer receiver box contains every possible positive response;
        # skip only cells with no possible intersection even at the largest R.
        if any(abs(x)-h/2>=(2+d)/2 for x in center):continue
        lows=[];ups=[]
        for j,R in enumerate(Rgrid):
            lower=upper=F()
            for p in ps:
                vals=[cache[(z,p['side'],ix,j)] for z,ix in zip(p['center'],idx)]
                lower+=p['density']*prod(v[0] for v in vals);upper+=p['density']*prod(v[1] for v in vals);per_source_bounds+=1
            assert 0<=lower<=upper<=1;lows.append(lower);ups.append(upper)
        response=[v/R**n for v,R in zip(lows,Rgrid)];jstar=max(range(len(Rgrid)),key=lambda j:response[j]);L=response[jstar];U=max(ups[j+1]/Rgrid[j]**n for j in range(len(Rgrid)-1));assert L<=U
        nonzero_cells+=U>0
        if L>us[0]:
            R=Rgrid[jstar];captured=[p['density']*prod(cache[(z,p['side'],ix,jstar)][2] for z,ix in zip(p['center'],idx)) for p in ps];cap=sum(captured,F());assert lows[jstar]<=cap<=ups[jstar]
            fractions=[v/p['mass'] for v,p in zip(captured,ps)];hits=sum(v>0 for v in captured);full=sum(v==p['mass'] for v,p in zip(captured,ps));uniform=prod(length(F(),d,x,R) for x in center)/d**n;err=abs(cap-uniform)
        for a in acc:
            u=a['u'];a['upper_count']+=U>u
            if L<=u:continue
            a['lower_count']+=1;a['capture_sum']+=cap;a['capture_min']=cap if a['capture_min'] is None else min(a['capture_min'],cap);a['capture_max']=max(a['capture_max'],cap);a['hit_min']=hits if a['hit_min'] is None else min(a['hit_min'],hits);a['hit_max']=max(a['hit_max'],hits);a['full_min']=full if a['full_min'] is None else min(a['full_min'],full);a['full_max']=max(a['full_max'],full);a['max_total_mass_slack']=max(a['max_total_mass_slack'],1-cap);a['witness_R_counts'][jstar]+=1
            if a['example'] is None or err>a['max_uniform_error']:
                a['max_uniform_error']=err;a['example']={'receiver_cell_center':[str(x) for x in center],'witness_R':str(R),'whole_cell_response_lower':str(L),'center_capture_total':str(cap),'original_piece_captured_mass':[str(v) for v in captured],'original_piece_capture_fractions':[str(v) for v in fractions],'pieces_hit':hits,'pieces_fully_captured':full,'artificial_uniform_C_capture':str(uniform),'uniform_proxy_abs_error':str(err)}
    records=[]
    for a in acc:
        count=a['lower_count'];lo=count*h**n;up=a['upper_count']*h**n;assert lo<=up
        records.append({'u':str(a['u']),'levelset_volume_lower_exact':str(lo),'levelset_volume_upper_continuum_exact':str(up),'u_volume_lower_over_mass_exact':str(a['u']*lo),'u_volume_upper_over_mass_exact':str(a['u']*up),'lower_over_1_plus_nd_exact':str(a['u']*lo/(1+n*d)),'whole_cells_lower':count,'whole_cells_upper':a['upper_count'],'capture_at_witness_cell_centers':None if not count else {'minimum_total_fraction':str(a['capture_min']),'maximum_total_fraction':str(a['capture_max']),'mean_total_fraction':str(a['capture_sum']/count),'original_source_piece_count':len(ps),'pieces_hit_range':[a['hit_min'],a['hit_max']],'pieces_fully_captured_range':[a['full_min'],a['full_max']],'max_loss_from_total_mass_only_bound':str(a['max_total_mass_slack']),'max_artificial_uniform_C_error':str(a['max_uniform_error']),'witness_R_counts':a['witness_R_counts'],'max_error_example':a['example']}})
    return {'phase':phase,'name':f'n{n}_d{d}_{kind}','n':n,'support_side_d':str(d),'a':'1','b':'2','source_mass':'1','sources':[{'center':[str(z) for z in p['center']],'side':str(p['side']),'mass':str(p['mass']),'density':str(p['density'])} for p in ps],'receiver_outer_box':'[-3/2,3/2]^n, covers all possible positive responses','receiver_cell_side':str(h),'receiver_cells_in_outer_box':len(coords)**n,'receiver_cells_positive_upper':nonzero_cells,'R_grid':[str(R) for R in Rgrid],'levels':records,'counts':{'cached_axis_bounds':oneDchecks,'per_source_R_cell_bounds':per_source_bounds},'capture_scope':'Cell centers are exact additional capture diagnostics only; levelset lower uses entire cells and finite-R witnesses, never center point counting.'}

def prices(row,dps):
    with mp.workdps(dps):
        n=row['n'];d=F(row['support_side_d']);price=2+n*mp.log1p(fm(d));values=[]
        for r in row['levels']:
            lower=fm(F(r['u_volume_lower_over_mass_exact']));upper=fm(F(r['u_volume_upper_over_mass_exact']));ratio=lower/price
            assert ratio<=1
            values.append({'u':r['u'],'lower_over_candidate_price':enc(ratio),'upper_enclosure_over_candidate_price':enc(upper/price)})
        return {'candidate_c_d':enc(price),'levels':values}

def windows():
    specs=[]
    for n,d in [(1,F(1)),(2,F(1,2)),(3,F(1,3))]:
        for r in [F(1,2),F(1),1+d/2,2-d/2,F(2),2+d/2,2+d,3+d]:specs.append((n,d,r))
    for n,d in [(512,F(1,512)),(1000000,F(1,1000))]:
        for r in [1+d/2,2+d/2,2+d,3+d]:specs.append((n,d,r))
    out=[]
    for n,d,r in specs:
        lo=max(F(1),r-d);hi=min(F(2),r);active=lo<hi and r>1;ratio=hi/lo if active else F(1);assert ratio<=1+d
        # u=m/r^n is conceptual for huge n: do not construct giant integers.
        vals={}
        for prec in [40,70]:
            with mp.workdps(prec):vals[f'mp{prec}']={'n_log_window_ratio':enc(n*mp.log(fm(ratio))),'n_log_one_plus_d':enc(n*mp.log1p(fm(d))),'candidate_c_d':enc(2+n*mp.log1p(fm(d)))}
        out.append({'n':n,'d':str(d),'r':str(r),'u_relation':'mass/r^n; mass=1','lower_endpoint':str(lo),'upper_endpoint':str(hi),'nondegenerate_external_window':active,'endpoints_ordered':lo<=hi,'endpoints_equal':lo==hi,'r_le_a_empty_level':r<=1,'r_gt_b_plus_d_empty_external':r>2+d,'window_ratio_exact':str(ratio),'ratio_cap_exact':str(1+d),**vals})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));args=ap.parse_args()
    rows=[];maxdiff=mp.mpf(0)
    for spec in models():
        row=geometry(spec);a,b=prices(row,40),prices(row,70)
        with mp.workdps(100):
            pairs=[(a['candidate_c_d'],b['candidate_c_d'])]+[(x[k],y[k]) for x,y in zip(a['levels'],b['levels']) for k in ['lower_over_candidate_price','upper_enclosure_over_candidate_price']];delta=max(abs(mp.mpf(x)-mp.mpf(y))/max(1,abs(mp.mpf(y))) for x,y in pairs);assert delta<mp.mpf('1e-25');maxdiff=max(maxdiff,delta)
        row.update({'mp40':a,'mp70':b,'max_scaled_precision_difference':enc(delta)});rows.append(row);print(row['name'],max(float(F(x['u_volume_lower_over_mass_exact'])) for x in row['levels']),flush=True)
    ws=windows()
    for w in ws:
        with mp.workdps(100):
            delta=max(abs(mp.mpf(w['mp40'][k])-mp.mpf(w['mp70'][k]))/max(1,abs(mp.mpf(w['mp70'][k]))) for k in w['mp40']);assert delta<mp.mpf('1e-25');maxdiff=max(maxdiff,delta)
    out={'scope':'Finite positive-Lebesgue L1 boxes. Exact whole-cell finite-R lower witnesses and continuum-R upper enclosures; no finite grid=sup identification. Candidate log price sampled, not numerical proof of a universal bound or dimension order. High dimensions only rational scalar window checks.','source_sha256':sha(__file__),'contract_sha256':sha(args.contract),'dependencies':{'python':'3.12.14','mpmath':mp.__version__},'cases':rows,'window_cases':ws,'window_scope':'nondegenerate flag means positive window length only; ordered equal endpoints can be a legitimate single-scale window, not generically an empty window. Main-author window suite is separate and not counted here.','counts':{'geometry_models':len(rows),'initial':3,'pressure':3,'expanded':3,'level_records':sum(len(r['levels']) for r in rows),'source_pieces':sum(len(r['sources']) for r in rows),'scalar_windows':len(ws),'cached_axis_bounds':sum(r['counts']['cached_axis_bounds'] for r in rows),'per_source_R_cell_bounds':sum(r['counts']['per_source_R_cell_bounds'] for r in rows)},'precision_summary':{'max_scaled_difference':enc(maxdiff),'scope':'enc50 mp40/mp70 ordinary logarithm comparison, no directed interval error'}}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(out['counts'])
if __name__=='__main__':main()
