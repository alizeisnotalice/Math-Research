# R251: signed normalized scale flux and its actual source costs

This note concerns only the common hard scale. It does not replace the
original source, receiver set, or either posterior. The scale identities
below are tools, not a new general root estimate. In particular, the
positive variation of a dominated function need not be dominated by the
positive variation of its pointwise majorant.

## SV1. Exact conventions and an L1 formula without boundary regularity

Let mu=f dy be finite, f>=0 in L1(R^n), and let

    Q_R(x)=x+[-R/2,R/2]^n, h_R=R^-n 1_Q_R(0),
    M_x(R)=mu(Q_R(x)), H_R(x)=R^-n M_x(R),
    0<a<=b<=2a, L=log(b/a).

For every x, M_x is absolutely continuous on [a,b]. Indeed, the
pushforward of f dy under y -> 2||y-x||_infinity is absolutely
continuous: preimages of one-dimensional null sets have Lebesgue
measure zero, as is also seen by partitioning according to the unique
maximal coordinate. The radial change of variables gives, for almost
every R,

    M'_x(R)=1/2 integral_{partial Q_R(x)} f(y)dS(y),
    B_R(x)=R M'_x(R)/R^n,
    partial_logR H_R(x)=B_R(x)-nH_R(x).             (SV1)

Faces are counted once; their intersections have surface measure zero.
Boundary representatives of f do not change the almost-everywhere
formula. Equivalently,

    H_v-H_u=integral_u^v B_R dR/R
                       -n integral_u^v H_R dR/R. (SV2)

This holds for every a<=u<=v<=b, with the absolutely continuous
representative. There is no missing negative bulk term.

For a general finite measure the precise Stieltjes version is

    dH_R=R^-n dM_x(R)-nH_R dR/R.                  (SV3)

Here closed cubes make M_x right continuous, and increments are on
(u,v]. Singular boundary arrivals belong to the first term. Writing
dM_x=M'_ac dR+dM_s, its positive variation is

    dH_R^+=R^-n dM_s
                    +(R^-n M'_ac-nH_R/R)_+ dR.   (SV4)

The remaining sections use the actual L1 source, so dM_s=0.

## SV2. True receiver/source interchange and its full price

Keep the actual measurable receiver E of finite measure, with the
original all-R band H_R(x)<=4lambda for x in E and a<=R<=b, lambda>0. Put
X=lambda|E|. Define

    V_+(x)=integral_a^b (B_R(x)-nH_R(x))_+ dR/R,
    S_E(y)=1/2 integral_a^b R^-n
                       integral_partialQ_R(y) 1_E(x)dS(x)dR.

Nonnegative Tonelli gives exactly

    integral_E integral_a^b B_R dR/R dx
                          =integral S_E(y)mu(dy),
    0<=S_E(y)<=nL.                                (SV5)

The surface integral and S_E are defined almost everywhere in y; any
choice on the resulting source-null set has the same L1 integral.
In particular all displayed positive fluxes are finite in L1(E).
The signed identity, now also integrable, is

    integral_E (H_b-H_a)dx
      =integral S_E dmu-n integral_a^b integral_E H_R dx dR/R.
                                                       (SV6)

The genuine positive-growth bound is

    integral_E V_+ dx <=integral S_E dmu<=nL||mu||. (SV7)

The all-R cap bounds the bulk term from above by 4nLX. It supplies
neither a lower bound on that term nor an instantaneous bound on B_R.
Thus it cannot be used with the opposite sign to improve SV7. Nor
can the positive part be moved through the y integral in SV6: the
surface and bulk parts cancel only after the same source is averaged.
SV7 retains the actual source occupation S_E, but no small bound for
that occupation is being asserted as a new result.

## SV3. A first crossing retains the same negative term

Let F(x)=max_{a<=R<=b}H_R(x), and fix u>0. On

    A_u={x in E:H_a(x)<u<F(x)},

let tau_u(x) be the first R with H_R(x)=u. Continuity gives a
measurable tau_u in (a,b), and the exact identity is

    u-H_a(x)=integral_a^tau_u(x) B_R(x)dR/R
                    -n integral_a^tau_u(x) H_R(x)dR/R. (SV8)

Tonelli expresses its incoming term as integral K_{E,u}(y)mu(dy),
where

    K_{E,u}(y)=1/2 integral_a^b R^-n
        integral_partialQ_R(y)
                    1_{A_u}(x)1_{R<=tau_u(x)}dS(x)dR.

Consequently

    integral_A_u (u-H_a)dx
       =integral K_{E,u}dmu
          -n integral_A_u integral_a^tau_u H_R dR/R dx,
    0<=K_{E,u}<=S_E<=nL.                           (SV9)

This is a whole-source stopping formula. It does not assert that a
separate source piece has the same first crossing, or that the
stopping indicator is independent of the source. The same tau_u must
remain inside both terms. Since mu and E are fixed, all boundary and
bulk integrals in SV9 are actual Lebesgue integrals. SV9 alone is not
a paid weak bound or a root improvement.

## SV4. What the already available L2 tool genuinely pays

R248 transport_cost.md TC2--4, with one empty type, already gives the
dimension-independent multiplier estimate

    ||partial_logR(h_R*g)||_2<=42||g||_2.

Thus, for an actual source density g in L1 intersect L2,

    ||V_+(g)||_2<=42L||g||_2,
    integral_E V_+(g)<=42L sqrt(|E|)||g||_2.       (SV10)

This is a direct application of the old tool, not a new R251 theorem.
The AC identity in SV1 and Minkowski justify it for rough L2 sources
by approximation or by the distributional derivative multiplier.

For a genuine additive decomposition mu=g dy+mu_r, with g>=0,
mu_r>=0 both actual sources, positive-part subadditivity gives

    integral_E V_+(mu)
      <=42L sqrt(|E|)||g||_2+integral S_E dmu_r
      <=epsilon X+(42L)^2||g||_2^2/(4epsilon lambda)
                                      +integral S_E dmu_r. (SV11)

Here epsilon>0, and the residual can retain its exact signed positive
variation instead of its shell majorant if that is separately paid.
If g<=A then ||g||_2^2<=A||g||_1. SV11 records all source costs and
the one receiver error. It makes no claim that the general residual
shell term is bounded by W with a root coefficient.

The R248/R249 transported profile comparison is instead a pointwise
majorization at each R. It can pay F and therefore a first crossing
of F. It cannot, solely from that majorization, replace the actual g
in SV10 or control V_+(mu). For real functions U<=V at every scale,
U may oscillate below a constant V. This logical distinction prevents
reusing an already paid maximal budget as a new variation budget.

## SV5. Exact remaining geometric input

Beyond an actual L2 part, SV9 needs a source/receiver bound on the
stopped incoming flux *minus its own bulk occupation*. The original
all-R cap alone does not supply that sign. Dropping the negative
term gives the old nL shell price; declaring a sourcewise first hit
would change the shared-scale problem. Any improvement from coherent
source geometry must therefore bound the same K_{E,u}, retain its
coupled negative occupation, or directly bound the original first
crossing set. Such a geometric estimate is not assumed in this note.

The scope is finite: these formulas do not crop a posterior, invoke
old negative traffic credit, assign hard rank to beta, or turn
q|E| into W. No general unpaid traffic has been declared paid.

## SV6. New single-package threshold localization and linear support price

Here there is an actual improvement over the old exponential support
enlargement. Suppose the same arbitrary nonnegative L1 source mu is
supported in C=Q_d(c), with 0<d<=a, and put m=mu(C). The density inside
C can be arbitrarily nonuniform. For every u>0,

    u |{x in R^n:max_{a<=R<=b}H_R(x)>u}|
          <=[2+n log(1+d/a)]m <=(2+nd/a)m.        (SV12)

No receiver cap, source rank, product-source hypothesis, or additional
source selector is used in SV12. This is a full-package estimate; it
does not sum separate suprema of its constituent source pieces.

Proof. If m=0, or m<=ua^n, the strict superlevel set is empty, since
H_R<=m/a^n<=u. Otherwise let

    r=(m/u)^(1/n)>a, A=max(a,r-d), B=min(b,r).

Charge the part inside Q_r(c) by its volume:

    u |Q_r(c)|=m.                                (SV13)

If x outside Q_r(c) has H_R(x)>u for an original R, then its window
intersects C in positive source mass and uR^n<m. The support inclusion
Q_R(x) intersect C nonempty implies x in Q_{R+d}(c). Therefore

    r-d<R<r, a<=R<=b.                            (SV14)

Thus every exterior response is witnessed within the one common
closed window [A,B]. If A>B, there are no such receivers. If A=B,
the following estimate uses just that single scale and has zero
integrated flux; it remains valid. When A<=B, SV2 applied to the
original *whole* source, before any positive majorization, gives

    H_R=H_A+integral_A^R B_t dt/t
                            -n integral_A^R H_t dt/t,
    sup_{A<=R<=B}H_R<=H_A+integral_A^B B_t dt/t.

On integrating first in the true receiver x, the full normalized
initial column is m and the boundary column is exactly n m:

    integral_R^n H_A dx=m,
    integral_R^n B_t dx=nm for almost every t.

These identities follow either directly from the normalized cube
and its 2n faces, or from SV5 with the full receiver space. Nonnegative
Tonelli is legitimate for the actual L1 source. Consequently

    u |{max H_R>u} outside Q_r(c)|
       <= integral_{outside Q_r(c)}sup_{A<=R<=B}H_R dx
       <=[1+n log(B/A)]m.                        (SV15)

The negative internal-mass term was retained in the exact identity
and then discarded with its correct sign. No separate source first
hit or posterior normalization was substituted. Finally B<=r,
A>=r-d, and A>=a imply

    0<=B-A<=d, log(B/A)<=log(1+d/a).

Together with SV13 this proves SV12, including r>b and degenerate
windows. Cube boundaries have zero receiver measure. In particular
there is no outer-volume factor (1+d/a)^n.

The actual paid boundary contribution is nm times this *threshold-
localized* logarithmic window, not nm log(b/a). The localization
depends only on the whole-package m and the output u, before the
receiver integral; its use does not incur a threshold menu fee.

## SV7. Actual receiver budget and exact replacement scope

If this whole source also satisfies the original band on E, put
C_d=2+n log(1+d/a). Since F<=4lambda on E, for 0<epsilon<4,

    integral_E F dx
      <=epsilon X+C_d m log(4/epsilon),
    integral_E F dx
      <=epsilon X+(4C_d/epsilon)m.                (SV16)

Both are genuine source-priced bounds with the same one receiver
error, by layer cake or by a single cutoff. Their minimum can be
taken without paying twice. In particular d<=a/sqrt(n) gives
C_d<=2+sqrt(n), so SV16 is a paid root-price branch for an actually
supported single package. It is not a claim that arbitrary original
sources have such support or can be split into packages for free.

For comparison the same package has the old support-volume weak
price (1+d/a)^n m and the old whole-octave strong-column weak price
[1+n log(b/a)]m. SV12 can replace these by the minimum of all three
scalar coefficients. At d=a/n this merely recovers an already known
absolute price. Its new useful range is intermediate d, where
nd/a can be much smaller than both the exponential support factor
and the full n log 2 scale price.

More generally, suppose actual additive packages mu_i have this same
support side d, masses m_i, and a fixed graph covering all simultaneous
nonzero response pairs. R249 LG1 applies with a_i=C_d m_i and
A_i=C_d M_i, M_i=sum_neighbor m_j. Hence the complete weak-sum price is

    C_d[(3+2log2)sum_i m_i
                    +2sum_i m_i log(M_i/m_i)].   (SV17)

Thus SV12 replaces the old block weak coefficient inside a legitimate
package summation. It does not erase the graph entropy, assert a cap
on the sum of separately maximized responses, or replace true beta,
nu, and the full posterior by package-specific ones. The original
R249 bounded-density and certified profile-plan prices remain intact;
SV16 or SV17 is available only for the actual residual/package to
which its stated support and mass conditions apply. General source
settlement beyond these quantities is still unproved here.

## SV8. Bounded exact arithmetic check

The following Python Fraction code was actually run locally. It checks
12 genuine one-dimensional constant-density source/receiver paths on
[1,2], with 15 exact affine radial-mass pieces. On each piece
M(R)=alpha R+beta, so the boundary alpha term cancels the same alpha
in nH and the signed increment is beta(1/r-1/l). The uniform plateau
has positive variation zero despite positive incoming and bulk flux.
Output was `PASS 12 paths; 15 pieces`. This is a formula diagnostic,
not evidence for an unproved high-dimensional flux budget.

```python
from fractions import Fraction as F
sources=[[(F(-2),F(2),F(3))],
         [(F(-1,4),F(1,4),F(2))],
         [(F(-3,4),F(-1,2),F(3)),(F(1,4),F(3,4),F(1))]]
xs=[F(0),F(1,4),F(3,4),F(3,2)]
a,b=F(1),F(2)
checks=paths=0
for src in sources:
 def mass(R,x):
  return sum(c*max(F(0),min(hi,x+R/2)-max(lo,x-R/2))
             for lo,hi,c in src)
 for x in xs:
  cuts=sorted({a,b}|{2*abs(y-x) for lo,hi,c in src for y in (lo,hi)
                     if a<2*abs(y-x)<b})
  signed=positive=F(0)
  for l,r in zip(cuts,cuts[1:]):
   mid=(l+r)/2
   alpha=sum(c*(F(int(lo<x+mid/2<hi),2)+
                F(int(lo<x-mid/2<hi),2)) for lo,hi,c in src)
   beta=mass(mid,x)-alpha*mid
   assert mass(l,x)==alpha*l+beta and mass(r,x)==alpha*r+beta
   delta=beta*(1/r-1/l)
   assert delta==mass(r,x)/r-mass(l,x)/l
   signed+=delta; positive+=max(F(0),delta); checks+=1
  assert signed==mass(b,x)/b-mass(a,x)/a
  assert positive>=max(F(0),signed)
  if src==sources[0] and x==0: assert positive==0
  paths+=1
print('PASS',paths,'paths;',checks,'pieces')
```
