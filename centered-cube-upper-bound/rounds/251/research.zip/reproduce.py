from pathlib import Path
import hashlib,json,subprocess,sys
w=Path(__file__).resolve().parent
manifest=json.loads((w/'manifest.json').read_text())
def verify():
 for name,digest in manifest.items():
  assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
verify()
for script,output in [('window_checks.py','window_checks.json'),('cluster_checks.py','cluster_checks.json')]:
 before=(w/output).read_bytes()
 subprocess.run([sys.executable,str(w/script)],check=True,cwd=w)
 assert before==(w/output).read_bytes(),output
verify()
print(json.dumps({'manifest_files':len(manifest),'exact_replay_outputs':2,'status':'PASS'},sort_keys=True))
