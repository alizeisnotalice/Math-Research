# R251：共同硬尺度筛查与小立方体来源的短窗弱型

SG1–SG4 记录原共同尺度抵消路线的有界未闭合筛查。后续 SG5–SG8 得到新的正向结果：支持于边长 \(d\) 立方体内的任意非负 L1 来源，其硬 octave maximal 弱型常数至多 \(2+n\log(1+d/a)\)。特别 \(d=a/\sqrt n\) 时为根阶，不是点源外推。多簇合并仍保全部真实交叠费用，一般问题没有因此闭合。

## SG1　原对象与候选

固定 \(0\le\mu\le f\,dx\)、真实 \(E\) 和原可测选择器 \(R(x)\in[a,b]\)，\(0<a\le b\le2a\)，保
\[
 \sup_{a\le t\le b}h_t*f(x)\le4\lambda\quad(x\in E).
\]
目标中的硬响应是 \(\int_E h_{R(x)}*\mu(x)dx\)。本稿不改变 \(\beta,\nu\)、完整 \(\Pi_t\)、原 FIRST 或任何母账负信用。R249 CB1 的分析用部分流仍须按它自己的实际几何费用结算；这里没有构造更便宜的新流。

记 \(A_tg=h_t*g\)，并定义正面核
\[
 B_tg(x)=\frac{t^{1-n}}2\sum_{i=1}^n\sum_{\pm}
 \int_{y_i=x_i\pm t/2,\ |y_k-x_k|\le t/2\ (k\ne i)}
        g(y)\,d\mathcal H^{n-1}(y).
\]
对 L1 来源只在几乎处处的 \((x,t)\) 使用该 trace。它满足
\[
 \partial_{\log t}A_tg=B_tg-nA_tg,
 \qquad \int B_tg\,dx=n\|g\|_1.
 \tag{1}
\]
令 \(\chi_t(x)=\mathbf1_E(x)\mathbf1_{t\le R(x)}\)。精确保留同一选择器的 FTC/Tonelli 给
\[
\begin{split}
 \int_E A_{R(x)}\mu(x)dx
 ={}&\int_E A_a\mu(x)dx\\
 &+\int_a^b\int\big[B_t\chi_t(y)-nA_t\chi_t(y)\big]
                    \mu(dy)\,\frac{dt}{t}.
 \tag{2}
\end{split}
\]
这里 \(B_t\) 是偶核，故交换合法。正面部分和体积部分分别可积，均由 \(n\log(b/a)\|\mu\|_1\) 控制。对几乎处处 \(x\)，\(A_t\mu(x)\) 在整段上绝对连续，故可在该 \(x\) 的实际 \(R(x)\) 使用 FTC；不是在选择器图上擅自使用某个 a.e. 导数值。

若没有接收/选择器门，即 \(\chi_t\equiv1\)，则两项精确相消。原 \(\chi_t\) 依赖 \(x\)，不能把两个全空间积分各为 \(n\|\mu\|_1\) 的事实当作带门的抵消。正放后至多回到
\[
 \int_E A_{R(x)}\mu\le[1+n\log(b/a)]\|\mu\|_1,
 \tag{3}
\]
即 R250 已明确的线性包络费用。(2) 保共同尺度，但它本身不是新估计或付款。

## SG2　首次接触并未补齐原资格

若另外在完整 \(f\) 的硬水平集上选择首次到达 \(\lambda\) 的尺度，只有在 \(A_af<\lambda\) 且区间内确实到达该水平时，连续性才给该接触值为 \(\lambda\)。起点已超阈的行须单独保留。此选择一般不同于原给定 \(R(x)\)；原母账其他选择器和门不能跟着无价改变。对 \(\mu<f\) 也不能从 \(A_{R(x)}f\ge\lambda\) 推得 \(A_{R(x)}\mu\ge\lambda\)。

对原 L1 输入，(1) 的 a.e. \((x,t)\) 导数资格不自动覆盖首次接触图 \(t=t_*(x)\)。即使先平滑并在可微接触点得到非负穿越导数，这也只是点上的符号信息，没有提供接触面流入按原来源质量求和的上界。因而本稿没有在该图上使用未经认证的 trace 或首接触输运。

## SG3　原 cut 接入时的明确尺度损失

R237 `source_ledger.md` SL1 所核的实际 cut 为：残余 \(\beta\) 载于 \(S\)，\(H_{r,a,V}(S)\subset N\)，且每个原接收立方体满足
\[
 Q_{R(x)}(x)\subset V,\qquad
 |N\cap Q_{R(x)}(x)|<R(x)^n/\ell.
 \tag{4}
\]
在 (2) 的有效 \(t\le R(x)\) 上，集合包含确实保 \(Q_t(x)\subset V\)，但 (4) 只直接推出
\[
 \frac{|N\cap Q_t(x)|}{t^n}
 \le\min\left\{1,\frac{(R(x)/t)^n}{\ell}\right\}.
 \tag{5}
\]
因此不能把同一个 \(1/\ell\) 低占比应用到整段共同尺度。原 octave 中该比例损失可达 \(2^n\)；只有明确保靠近实际终点的尺度窗，才能限制它，而窗外仍须另付。更重要的是，(4)–(5) 是体积信息，不给 \(B_t\chi_t\) 或来源密度的超平面 trace 上帽。

原 \(\nu\) rank 仅限真实 birth piece 质量，既不授块内密度/面帽，也不是 \(\beta\) 的 rank。饱和计划的源是提取 \(\eta^A\)，不是残余 \(\beta\) 或 \(\nu\)。这些原资格均不足以在本稿已给出的推导中替换缺失的带门面—体积平衡；本稿不声称已证明它们逻辑上不可能导出更强结果。

本路线停在具体一步：需要对 (2) 的**同一个** \(\chi_t\)、同一来源和整个有效尺度段证明正面流入与负体积项的联合 source-priced 控制。all-scale 上帽只控制 \(A_tf\)，cut 只控制实际终点的 (4)；把它们直接用于该联合项会遗漏 (5) 及面 trace 费用。未得此控制，不能将共同尺度抵消宣布为 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)W\)。

## SG4　最小核查与停止范围

本机 Python `fractions.Fraction` 对 \(n=1,2,16,512\)、\(c=0,1/7\) 实际核查了 8 个面—体积归一化恒等式。使用局部多项式 \(g(y)=1+c\sum y_i^2\)，其支撑可在所测立方体外截断：
\[
 A_tg=1+c\sum x_i^2+cn t^2/12,
 \quad B_tg=n(1+c\sum x_i^2)+cn(n+2)t^2/12,
\]
\[
 B_tg-nA_tg=cn t^2/6=\partial_{\log t}A_tg.
\]
核查取 \(t=3/2\)、\(\sum x_i^2=n/9\)，全部为精确有理算术。这只检查 (1) 的常数与平坦响应的抵消，不是 FULL 实例、接触面预算或新付款证据。SG1–SG4 路线没有新的正向交通预算；下面的新增结果使用另一项共同尺度定位。

## SG5　任意块内形状：阈值决定的共同短尺度窗

**定理。** 设 \(\mu\ge0\) 为有限 L1 来源，支持于 \(C=Q_d(z)\)，\(d>0\)，质量 \(m\)，\(0<a\le b\le2a\)。对于每个 \(u>0\)，
\[
 u|\{M_{[a,b]}\mu>u\}|
 \le \left[2+n\log(1+d/a)\right]m.
 \tag{6}
\]
不要求块内均匀、密度帽、FIRST、接收 lower band 或来源 rank。它特别给
\[
 d\le a/\sqrt n\quad\Longrightarrow\quad
 u|\{M_{[a,b]}\mu>u\}|\le(2+\sqrt n)m.
 \tag{7}
\]
可与原单块外包盒价 \((1+d/a)^n m\) 及全包络价 \([1+n\log(b/a)]m\) 取较小者。\(d=a/n\) 已有常数外包盒价，(6) 的新改善在更宽的集中来源范围。

**证明。** \(m=0\) 或 \(u\ge m/a^n\) 时严格超水平集为空。其余令
\[
 r=(m/u)^{1/n}>a.
\]
\(Q_r(z)\) 内的超水平集直接以体积计费：\(u|Q_r(z)|=m\)。对于外部超水平点 \(x\)，存在 \(R\in[a,b]\) 使 \(\mu(Q_R(x))>uR^n\)。于是
\[
 R<r,
 \qquad R\ge2\|x-z\|_\infty-d>r-d.
 \tag{8}
\]
第二式只用 \(Q_R(x)\) 与来源支撑相交。因而全部这些外部点的见证尺度都落在**同一个**区间
\[
 [A,B]=[\max(a,r-d),\ \min(b,r)].
 \tag{9}
\]
此窗只依 \(m,u,a,b,d\)，不依接收点或来源点。若 \(A>B\)，外部超水平集为空。若 \(A\le B\)，定义正包络核
\[
 K_{A,B}(w)=\sup_{A\le R\le B}h_R(w),
 \qquad \int K_{A,B}=1+n\log(B/A).
 \tag{10}
\]
退化窗 \(A=B\) 是单尺度核，积分为一，不能一律判空。对 (8) 的外部点用 \(M_{[A,B]}\mu\le K_{A,B}*\mu\)，随后只做一次 Tonelli/Markov：
\[
 u|\{M_{[a,b]}\mu>u\}\setminus Q_r(z)|
 \le [1+n\log(B/A)]m.
 \tag{11}
\]
最后
\[
 \frac BA\le\frac r{\max(a,r-d)}\le1+\frac da.
 \tag{12}
\]
当 \(r\le a+d\) 时分母为 \(a\)，当 \(r>a+d\) 时比值为 \(1+d/(r-d)\le1+d/a\)。加上内部的 \(m\) 得 (6)；\(\log(1+x)\le x\) 给 (7)。这既不使用自由选择的来源半径，也不对每个来源分别领取 octave 的 \(n\log2\) 费用。

该短窗加强由父级/compare 提出，本稿独立核查了 (8)–(12)，尤其保留了单尺度窗边界。短窗证明无需薄壳论证中的 \(d\le a/4\) 限制，且在本轮目标 \(d=a/\sqrt n\) 下价格较优；两项合法价格始终可取较小者。

## SG6　独立薄壳证明：\(1+8nd/a\) 价

在 \(0<d\le a/4\) 下，仍令 \(r=(m/u)^{1/n}>a\)。整个超水平集包含于 \(Q_{r+d}(z)\)。内部 \(Q_{r-d}(z)\) 的费用至多 \(m\)。对余下薄壳
\[
 \mathcal A=Q_{r+d}(z)\setminus Q_{r-d}(z),
\]
任意 \(y\in Q_d(z)\) 和 \(x\in\mathcal A\) 都满足
\[
 r-2d\le2\|x-y\|_\infty\le r+2d.
\]
只在这个壳上放松为原 \(K_{a,b}*\mu\)。以 \(q=2\|x-y\|_\infty\) 积分，\(q<a\) 时
\(nq^{n-1}a^{-n}\le n/q\)，\(a\le q\le b\) 时密度恰为 \(n/q\)，\(q>b\) 时核为零。因此
\[
 \int_{\mathcal A}K_{a,b}(x-y)dx
 \le n\log\frac{r+2d}{r-2d}
 \le\frac{4nd}{r-2d}\le\frac{8nd}{a}.
\]
Tonelli 对来源只积分一次，得
\[
 u|\{M_{[a,b]}\mu>u\}|\le(1+8nd/a)m.
 \tag{13}
\]
当 \(d\ge a/4\) 时，原全包络 \(1+n\log2\) 也不超过 (13) 的常数。因此 (13) 可保为全 \(d>0\) 的独立较弱验证；主结论使用 (6)。

## SG7　原真实接收付款及多簇费用

若还满足 SG1 的 \(\mu\le f\) 与实际上帽，则 \(M\mu\le4\lambda\) 于 \(E\)。将 (6) 用于截断 \(u=\varepsilon\lambda\)，得到
\[
 \int_E M\mu\,dx\le\varepsilon X_E+
 \frac4\varepsilon[2+n\log(1+d/a)]m.
 \tag{14}
\]
所以任意支撑在 \(Q_{a/\sqrt n}(z)\) 内的原来源子测度都有 \(\varepsilon X_E+4(2+\sqrt n)m/\varepsilon\) 的真实硬响应预算；“子来源”指原测度的正限制/分配，不指点质量。原外乘系数仍须完整相乘，(14) 不能无接口地替代整个双后验交通。

对于一般分解 \(\mu=\sum_i\mu_i\)，必须保持测度等式与质量只计一次。若 \(\mu_i\) 支撑于 \(Q_{d_i}(z_i)\)，可取
\[
 a_i=[2+n\log(1+d_i/a)]\|\mu_i\|,
 \quad S_i=E\cap Q_{b+d_i}(z_i).
\]
R249 LG1 的共同支持邻接图及 \(A_i=\sum_{j\sim i}a_j\) 给完整合并费
\[
 \int_E M\mu\le\varepsilon X_E+
 \frac4\varepsilon\sum_i a_i
       [3+2\log2+2\log(A_i/a_i)].
 \tag{15}
\]
零项删除，可数族按原 Tonelli 资格。邻接至少覆盖所有实际 \(S_i\cap S_j\)，不能按便利性删边。

例如若所有 \(d_i\le a/\sqrt n\)，且一个来源冻结后可检查的合法邻接图最大度数为 \(D\)，选择共同上界 \(a_i=(2+\sqrt n)\|\mu_i\|\)，则 Jensen 给 (15) 的来源费至多
\[
 \frac{4(2+\sqrt n)}\varepsilon
 [3+2\log2+2\log D]\|\mu\|.
 \tag{16}
\]
这给多簇的实际有价分支；原全部来源不自动具有多项式 \(D\) 的此种覆盖。对任意输入直接使用边长 \(a/\sqrt n\) 全网格，粗邻接度数仍指数大，故不能据 (16) 宣称一般闭合。没有免费逐簇弱型相加、没有重新裁剪 \(\Pi_t\)、没有新 cut 或复用负信用。

## SG8　短窗边界的本机核查与停止范围

另实际运行 Python `Fraction` 检查了 \(a=1\)、\(b\in\{1,3/2,2\}\)、\(d\in\{0,1/4,1/2,2\}\)、\(r\in\{1,5/4,3/2,2,3\}\) 的 60 组 (9)–(12) 有理端点，其中 18 个正宽窗、25 个单点窗。初次检查把单点窗也判空时失败，修正为仅 \(A>B\) 判空后全部通过；最终证明采用 (10) 的单尺度积分一。该检查不替代连续证明，不是 FULL 数值实例。

本次正向交付是 (6)、(14) 以及保全合并费的 (15)。它把 \(d=a/\sqrt n\) 的单簇外膨胀指数价改成根阶，并适用于任意块内 L1 形状。一般多簇的交叠费用与原完整余交通仍未解决。停止本次有界任务。
