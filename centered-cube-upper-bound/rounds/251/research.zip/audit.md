# R251 独立审核

## 先审命题（未读两作者证明）

准确对象为fullside-d立方体内任意非负有限L1来源、真实dx、连续R∈[a,b]且a≤b≤2a；无FIRST或receiver cap。m=0时全零，u≥m/a^n时严格超level为空。其余R0=(m/u)^(1/n)>a，任一超level点必有Q_R(x)碰到C且R<R0，故包含在Q_{R0+d}(z)。仅此support体积给(1+d/R0)^n价，是旧指数价，不能冒充所提线性局部费。全octave核L1给1+nlog(b/a)，也不能单独导出小d的线性费用。

初步可核的安全路线是将Q_{R0+d}分为core Q_{R0−d}及厚度d的外壳，只在外壳使用旧K_ab逐源sup：core以体积计费≤m；外壳对每y∈Q_d有2||x−y||∞∈[R0−2d,R0+2d]，d≤a/4时K径向积分≤nlog((R0+2d)/(R0−2d))≤8nd/a。d≥a/4时旧全octave价被1+8nd/a覆盖。因此存在C(1+nd/a)在允许工具内可证明，仍须审完整论证及边界。更尖候选2+nlog(1+d/a)的系数不能从这条粗外壳证明直接认定；待作者给确切推导再审，不能以d=a/n特殊值或数值拟合替代。

与R249接入：若局部弱常数已证，可将各同来源块的ai替换为C(1+nd/a)mi，仍需完整support-local weak summation/实际Mµ上帽。多簇weak价不自动按质量线性求和，d=a/√n只是一簇O√n工具，不证明所有簇/原双后验的一般root预算。来源分解属于正估计，不裁剪原Π，不借R223连续N_del或已消费N_Z。

## 作者稿后审：更尖局部弱型已证

**signed_variation SV6–7 PASS。** 独筛的粗壳价不是最优；作者使用whole-package阈值局部化给出了所提更尖常数，证明没有使用额外来源或FIRST假设。具体核验如下。

m>ua^n时r=(m/u)^(1/n)>a。中心Q_r(c)以真实体积付m；任一外部超level的原见证R，因H_R>u而R<r，又因正来源相交而x∈Q_{R+d}(c)，所以R>r−d。因此所有外部点共用[A=max(a,r−d), B=min(b,r)]。若A>B外部为空；A=B可按单尺度处理。A≤B时signed FTC对同一完整µ给sup H_R≤H_A+∫B_t dt/t，归一单尺度列积分m、面列积分nm，经Tonelli得外部weak费用[1+nlog(B/A)]m。B−A≤d且A≥a给log(B/A)≤log(1+d/a)。合core得

`u|{M_[a,b]µ>u}|≤[2+nlog(1+d/a)]m≤(2+nd/a)m`。

这是任意块内非均匀L1密度、真实dx、全部连续尺度的严格结论。无需sourcewise首次接触；window只依整包m、u，先于receiver积分冻结。µ=0、u≥m/a^n的strictempty、r>b及截窗等号都被覆盖。signed bulk只按正确负号舍去，未借原母账负信用。

SV16使用实际E上F=Mµ≤4λ，得到同一εX下C_d m log(4/ε)与4C_d m/ε两价，可取min；SV17以ai=C_d mi接回R249完整support-local熵，未删除多包叠加费用。d≤a/√n是实际单包支持条件下的root-price工具，不认证一般多簇来源或双Π交通闭合。

SV1–3的AC/Stieltjes、1/2面归一、正确负bulk与whole-source first crossing公式逐项通过。有限L1在固定x的max-norm径向推前绝对连续可由唯一最大坐标分区/coarea直接证明；surface代表仅a.e.使用。SV4–5是已归档L2工具的辅助应用与旧缺口定位，非新局部弱型的必要依赖，未将pointwise运输majorant的variation当原variation。

**shared_scale_geometry SG1–3 PASS（辅助失败路线）。** B_t总列质量n、同一χ_t=1E1_{t≤R(x)}的FTC/source交换系数正确；a.e.(x,t)导数并未免费用于首次接触图。原lowN在实际R的占比只推至较小t的min(1,(R/t)^n/ell)，无面迹帽，也未归还原连续N_del/已用N_Z。该路线未付费的定位与SV6新single-package结果不冲突。

实际本机独立运行：从signed_variation.md提取SV8内嵌Fraction脚本，输出`PASS 12 paths; 15 pieces`。另144组Fraction短窗参数覆盖a=b、截b、d=a/512至a、r近a及r>b，逐项核A≤B时B−A≤d、B/A≤1+d/a，全PASS。后者仅端点/窗算术诊断，不作为解析定理或FULL数值证明。

## 主整合、修订与最终结论

**PASS，无待修数学阻断。** 主proof CW1–4已完整审核。CW1用旧K_[A,B]的精确L1价证明短窗结果，不依赖辅助面trace预算；推广任意b≥a、d>0亦成立，因为r>a、A≥a和B−A≤d均不需octave或d≤a。项目内应用仍按合同原参数。三种ci=min{旧外膨胀、新短窗、旧全窗L1}各自为合法弱价；variable-d_i支持交图、Ai=sum邻居ai、零项与可数正极限正确。CW4只对实际M(sumµ_i)使用上帽，εX及所有source/原外乘费保留，R249 CB1替换的是同一残余槽而非直接双Π支付。

shared_scale_geometry最终SG5–8已核。短窗证明通过，薄壳独立弱价1+8nd/a也通过；发现并修复一处过强比较措辞：2+nlog(1+d/a)不对所有极小d都小于1+8nd/a。最终仅称目标d=a/√n范围短窗较优，两合法价可取min。SG7最大度D的Jensen费用保留logD，没有把任意网格的指数邻接度数当多项式。主报告保留一般分组/soft/双后验缺口，无一般维数阶闭合声称。

## 数值、复现与执行归属

已静审最终cluster_checks.py、numeric_notes.md及两JSON。9个真实L1盒模型、37pieces、72levels、206200项Fraction source/R/receivercell界均与报告匹配。整个外接收盒覆盖所有可能正响应；lower以finite-R whole-cell见证给出，upper以质量单调upper_mass(Rhi)/Rlo^n覆盖连续R，不把网格sup当连续sup。中心捕获另列，仅诊断包内实际质量；5/18与人工均匀7/8、差43/72的报告值已直接从JSON复核。普通mp40/70 log比较最大scaled差8.44496e−39，非区间，也不认证高维L1实例。最大有限lower/c_d=.2320704952597701只是实现一致性。

window_checks的1920配置=1044有效（内含384退化单尺度）+876空，已与stored JSON逐项口径复核；cluster另32个标量窗口、作者SG另60个端点检查不合并计数。A=B不得普遍判空的限定在代码标签/notes/解析证明一致。

本独审实际运行SV8内嵌12paths/15pieces Fraction检查、144组临时短窗参数算术及源码/合同自绑定校验；未重跑cluster完整JSON。144组只是本轮临时诊断，没有独立归档脚本，不列正式receipt；正式窗口程序保存在window_checks.py。作者SG60与主代理1920、numeric9模型的执行归属各自保留，不冒称均由本审计运行。主代理已报告包外preflight完整两JSON字节重放及manifest核通过；最终冻结包的完整回执由主代理另存，后续不修改本审计的执行归属。

reproduce.py静审PASS：读取flat manifest并先核，实际运行两脚本、逐字节比较两JSON，再核全部manifest。该驱动在包外副本执行；没有把finite lower当定理或更改原来源测度。report数字/范围和proof一致。

## 冻结受审SHA256

不绑定audit自身；以下受审文件停止变动后由主代理生成最终manifest与归档回执。

|文件|SHA256|
|---|---|
|task_contract.md|`6759167f64b71eb906c93bd2eb3fa4e65f4a8eeb151c209c25c6fa1dd703938a`|
|proof.tex.txt|`37300de07237ddd2b951cccce1929c3c7aedb46c33e16f0d04b150d81a885479`|
|shared_scale_geometry.md|`9f3fc17c1814c54ba4efef5a8f883090e896dc1574a323e2c6fb854f1377b06b`|
|signed_variation.md|`388c715cd3e15c38d32224a660e5484714682c31b3196ac38c7fb34275b77fa9`|
|report.md|`9613f39a4cc915169a6c3fbc8cd47b8e919d203af2b9b0cfdcf0ea1a0b6c30c2`|
|reproduce.py|`7183311388afc24d5e8327849c083d980c52a6b335b6ded6198d3626297de4d7`|
|cluster_checks.py|`73e163cafd0975c24433bfe7affdb01c68f29a4a05a08675f71933a7fe130982`|
|cluster_checks.json|`3268cc31148bce01fb6c41150de0a5d5955ee9e0c14cc66fa566af73bec06723`|
|numeric_notes.md|`73c09cbe2fe9fdbcff7bb883adb297fc93f73ecf43cc4f5e41b6894cbb7e627a`|
|window_checks.py|`91c539d6602a2e9d2082e5b7392a229727cf34511be1aea0e526f338ff8e15ac`|
|window_checks.json|`d4dc9789be76f0905fc157c84ed9159540f4bd4eebd784ebcfb007606dfd125e`|

本轮审核完成，audit.md至此冻结并停止写入。
