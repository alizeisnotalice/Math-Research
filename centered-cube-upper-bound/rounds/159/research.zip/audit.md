# R159 独立盲审检查点

审查范围：先不读作者稿。只写本文件；共享文件不改、不Git。待审命题是固定加权来源的接收核工具，不是原交通费用已付。

## 1. 准确量词与零支

固定整数n≥1、0<a≤b≤2a、y∈R^n、q∈(1,∞)和概率Borel来源ν。J_v(x)=P_{1,b}(x−v)，Q(x)=∫J_v(x)ν(dv)是固定概率密度。r(x,v)≥0联合可测，允许依x、v，但必须在整个s,L上确界中为同一个函数；不因正在选择的s,L、receiver参数或时间而重选模型。设
\[
 R(x)=\int r(x,v)J_v(x)\nu(dv),\qquad
 H_q=\left(\int\!\int r(x,v)^qJ_v(x)\,dx\,\nu(dv)\right)^{1/q}.
\]
若H_q=∞，有限价结论没有内容；以下要求H_q<∞。H_q=0时r=0在同一J_v dxν测度下几乎处处，Tonelli给R=0几乎处处，目标零。Q处处正，故以下f=R/Q定义没有零分母。

## 2. 一般相关来源下的准确矩转移

对每个x，以J_v(x)ν(dv)/Q(x)作条件概率。条件Jensen给
\[
 f(x)^q\le\int r(x,v)^q\frac{J_v(x)}{Q(x)}\nu(dv),
 \qquad \int f^qQ\,dx\le H_q^q.
\tag{RA1}
\]
这一步使用q>1的凸性，方向正确；不是把平方根凹性反用。于是对任意可测事件E，令κ_q=1−1/q，
\[
 \int_E R\,dx=\int_E fQ\,dx
 \le H_q\,Q(E)^{\kappa_q},\qquad \int R\,dx\le H_q.
\tag{RA2}
\]
来源坐标不要求独立，ν也不要求离散或有密度。

## 3. 独立固定参数分离及selector费用

沿R158统一事件，β=∫_{−1/2}^{1/2}φ，g=(1−s)(1−β)，
\[
 E=\left\{\sum_i1_{\{|x_i-y_i|\le b/2\}}\ge n(\beta+g/2)\right\}.
\]
P=P_{s,L}(x−y)下命中指标独立且均值≥β+g；每个固定v的J_v下指标独立且均值≤β。故Hoeffding先在固定v条件层成立，再混合来源：
\[
 P(E^c)\le e^{-ng^2/2},\qquad Q(E)\le e^{-ng^2/2}.
\]
非整数阈值及s=1边界均同R158处理。分别在E/E^c作CS，再用RA2：
\[
 \begin{aligned}
 \int\sqrt{PR}
 &\le\sqrt{P(E)R(E)}+\sqrt{P(E^c)R(E^c)}\\
 &\le\sqrt{H_q}\bigl[e^{-\kappa_qng^2/4}+e^{-ng^2/4}\bigr]\\
 &\le2\sqrt{H_q}\exp[-\kappa_q n(1-s)^2/1024].
 \end{aligned}
\tag{RA3}
\]
最后使用1−β≥e^{-2}/2和e^{-4}/16≥1/1024。r依x不妨碍此论证；关键是同一个R和有限H_q。

远soft带s≤1−d仍用R158保d网格：每段[s0,s1]令δ≤1/n、u=s1/(1+δ)，有p_s≤(1+δ)p_u且u≤1−d；向上尺度网格倍率e^{1/n}。总点数≤n(n+1)、几何平均倍率≤e。因此
\[
 \int\sup_{\substack{s\le1-d\\a\le L\le b}}\sqrt{P_{s,L}R}\,dx
 \le4en^2\sqrt{H_q}\exp[-\kappa_qnd^2/1024].
\tag{RA4}
\]
硬端点、退化soft区间和L=b显式端点保留；连续sup用soft稠密参数和从上方逼近L的可数稠密尺度实现。r不得在各格点重新选择。

## 4. 合法q依赖及全selector界

因∫R≤H_q，R158的近soft质量帽和裸质量帽仍可用普通CS，分别给
\[
 \int\sup_{\rm near}\sqrt{P_{s,L}R}
 \le\sqrt{32}\sqrt{H_q}\,n^{1/4}(1+\sqrt n\,d),
\]
以及全参数裸帽≤C_0 sqrt(H_q)n^{3/4}，C_0=sqrt(15(1+π/2))<7。取
\[
 d_*^2=\frac{4096\log(n+2)}{\kappa_qn}.
\]
d*<1/2时套近/远帽，远项<sqrt(H_q)，近项所需常数小于391/√κ_q。d*≥1/2（含等号）时改用裸帽，n≤16384log(n+2)/κ_q，所需常数小于896/√κ_q。故统一可取
\[
 \boxed{\int\sup_{\substack{s\in[0,1]\\a\le L\le b}}
 \sqrt{P_{s,L}(x-y)R(x)}dx
 \le1024\sqrt{\frac q{q-1}}\,
       \sqrt{H_q}\,n^{1/4}\sqrt{\log(n+2)}.}
\tag{RA5}
\]
这是一个有效q依赖，不主张最优。q固定时具有所述n阶；若q=q_n→1，必须保留显示因子，不能称统一常数。q的选择只能在完整同一模型积分结束后比较整个合法上帽，不能逐x、逐源或逐格点免费选q。

若原ν只有有限质量m>0而非概率，归一化后准确额外因子为m^{(q−1)/(2q)}，其中H_q按原未归一化ν计算。不能把来源质量默认为1；m=0为零分支。

## 5. q=1端点不能免费延拓

取ν=δ_0、b=2a、y=0，令
\[
 F(x)=\sup_{a\le L\le b}h_L(x),\quad A=\int F=1+n\log2,\quad
 R(x)=F(x)/A,\quad r(x,0)=R(x)/J_0(x).
\]
J_0处处正，r可测且与实际s,L选择无关，H_1=∫R=1。硬核尺度壳积分直接给上式A。目标却满足
\[
 \int\sup_{s,L}\sqrt{P_{s,L}R}\,dx
 \ge\int\sqrt{FR}\,dx=\sqrt{1+n\log2}.
\]
因此q=1下不存在所提n^{1/4}sqrt(log(n+2))阶的维数一致常数；不能只用L1源权质量代替某个q>1矩。

## 6. 原实际r=b_vρ的接口筛查

原b_v含
\[
 b_v=\frac{w_t(v)}{e_tw_g(v)}
       \int\delta(v,u)\mathcal M\,d\Pi_t(u),\qquad0\le\mathcal M\le1.
\]
原合同至多立即给δ≤n、ρ≤1等点态粗界，
\(r\le n\,w_t/(e_tw_g)\)。它没有给e_t、w_g的统一正下界，也没有给该逆权在J_v dxν下的q>1矩控制。∫Jν≤q_source、共同α余额或sourcewise good门不是H_q上界；这里q_source与本审计矩指数q是不同对象，不可混同。

此外，实际ρ、good/删除/score/time和b_v通常依正在选择的s,L及原共同α。RA5虽允许固定r依x，但没有支付r_{s,L,t}(x,v)这一额外参数选择。应用时须另证：固定同一个r或可测上包络支配实际权；其H_q有限且具有明确可支付的质量和维数预算；原ν/α及负账未被重选。有限离散样例逐行矩有限不等于统一H_q控制。

盲审结论：RA5条件引理通过；实际r=b_vρ尚无合同内的可用统一H_q，也未自动满足selector独立性。等待作者稿后仅作对应绑定，不因此新增来源交通付款。


## 7. adaptive_affinity.md 实读后审

已实读作者全部证明并计算SHA256：
a476ad1a0387f1bc5bfb05a9dc56cb45a083739f5b7ccd0feec1177bb66786a2。

作者(1)–(11)与RA1–5一致：概率ν下直接在J_v dxν上Hölder，不反用平方根Jensen；尾界先固定源、再混合；q'=q/(q−1)、远soft网格、小维裸CS、d*=1/2及1024√q'常数正确。可测sup与共同满测集的profile要求明确，没有把逐参数矩界偷换为共同上包络。作者(12)优化检验阈值也正确：t=1/(1+√θ)使θt²=(1−t)²=1/(1+√q')²；主公式未依赖该可选改进。作者未主张quarter-power的q依赖或实际矩预算已支付，无须修正。

## 8. 新min桥的独立盲核检查点

固定实际合法行，保持原删除后验Π_t和同一个e_t。设r=b_vρ_v只在原存活有效good来源上使用；当外层积分仍写原ν时，必须在r/支持中保留1_{Z_{j,t}}或其由terminal-survival推出的资格。则
\[
 B(x)=\int r(x,v)w_g(v)\nu(dv)
 \le\iint[k(v)-k(u)]_+\,d\Pi_t(v)d\Pi_t(u)\le n/4.
\tag{RA6}
\]
最后一步对a,b∈[0,n]用(a−b)_+≤a(n−b)/n；同一个Π的双积分给E[k](n−E[k])/n≤n/4。不需Π的坐标独立。若把outer v的删除资格漏掉，w_tν/e_t不再是同一个概率，RA6没有依据。

令χ_J=J/(K_1+K_2+J)，原J责任行
\[
 F_J(x)=p(x)\int r(x,v)w_g(v)\chi_J(x,v)\nu(dv)
\]
满足
\[
 F_J(x)\le\min\{p(x)B(x),(K/3)R(x)\},\qquad R(x)=\int r(x,v)J_v(x)\nu(dv).
\tag{RA7}
\]
第二项只用原good门p w_g≤KQ_v与χ_JQ_v=J_v/3，K仍是原固定门常数。p=0或ρ=0时不作除法。r可依实际selector；本点态比较不要求冻结r。

对全部farsoft s≤1−d用同一个事件
\[
 E_d=\{T\ge n(\beta+\kappa d/2)\},\qquad\kappa=1-\beta\ge1/16.
\]
每个固定源J_v(E_d)≤exp(−nd²/512)。在所有farsoft节点P_{u,H}下，成功率≥β+κd，故P_{u,H}(E_d^c)同帽。保d的有限参数网格给
\[
 \int_{E_d^c}\sup_{\rm far}p\,dx
 \le e^2n(n+1)e^{-nd^2/512}.
\]
因此对实际selector依赖的R，准确有
\[
 \int F_Jdx
 \le\frac K3\int_{E_d}R\,dx
 +\frac n4e^2n(n+1)e^{-nd^2/512}.
\tag{RA8}
\]
只需要core积分；没有要求先证明∫R的全局预算。关键是E_d固定不依selector，并在其补集先用n/4消去R，而非将selector依赖权冻结后套RA5。

若原固定有限ν总质量M>0，定义Q_0=Jν/M为概率密度。对实际边缘profile f=R/Q_0，若
\(H_q^{\rm marg}=(\int f^qQ_0dx)^{1/q}<\infty\)，则
\[
 \int_{E_d}R\,dx\le H_q^{\rm marg}
              e^{-(1-1/q)nd^2/512}.
\tag{RA9}
\]
这个归一化没有额外M因子，因为M已在f内。若改用未归一化Q=Jν下的norm，则须乘M^{1−1/q}；两种符号不能混用。联合J_v dxν/M下Mr的Lq范数是H_q^{marg}的一个Jensen上界。原实际H_q仍未自动得到控制。

RA6–9是逐行陈述。接回唯一j、时间及外hard时，必须保留原a_ω/history与v存活资格到合法聚合步骤，保持原z=c_jt/b和原时间窗；不能仅凭row帽自动删去j和时间积分。若已有原合同允许唯一j拼成z∈[a/b,1]，且所用上帽在该聚合中有效，才有时间费≤log2与原hard系数32Λ/3。core积分及其可能随j/time/外标签变化的预算仍需原样保留。


## 9. adaptive_budget.md 最终有界后审

已在盲核后实读AB1–23，最终SHA256：
67d5e9d35f2099ed105a8014461535858a7a48978a9866dc39c7e6a0bd904690。

AB1显式保留outer v的Z_{j,t}、terminal有效支持和原e_t；AB3/4的同Π n/4帽及AB8共同事件分割与RA6–8一致。AB10为仅E_d内的边缘Lq矩，Q₀=Jν/M为概率，故AB11无额外M因子；AB12的Mr联合矩归一化准确。AB13的局部弱Lq尾与事件质量同时取min后layer cake给q/(q−1)常数，不要求强q矩有限。AB15严格尾等价由Mr=Mb[1−(DK₀+αJ)/A]_+直接得到，Mb>λ分支才除以Mb；α=0不除α，原无效源排除。原共同余额本身未被当成此接收局部尾界的证明。

已实际读取R157 research.zip内 exterior_joint.md EJ4–EJ5，核对AB7引用的同一聚合合同：逐原j换z=c_jt/b，保留唯一1_{j(x)=j}后才拼接、扩公共窗[a/b,1]；外β及原标签质量仍是Wβ，非ν也非新概率。AB7中实际r_z保留全部j/time/selector依赖，所以局部core不会被冒充共同固定来源权。时间费log2、原hard一次16/3、外2Λ给32Λ/3。

据此AB18/19的core系数32ΛK/9及误差8e²Λ n²(n+1)log2/3正确，未额外花η或j数。ζ≥(5/2)log(n+2)时，n²(n+1)/(n+2)^{5/2}≤sqrt n，AB20条件下总价<32Λsqrt nWβ。AB22的局部聚合矩条件正确；H=0最终已澄清只令log_+项为零，仍保留(5/2)log条件。若所需d>1不得声称存在非空far带。

AB23在固定原ν、Π、α下仅截非负交通，E_d内Mr≤H₀部分的core质量≤H₀e^{-ζ}，与E_d^c部分严格互斥。其完整部分价及所列H₀充分条件常数通过；剩余为E_d内Mr>H₀原流，未被删去或称空。故这是明确条件/部分付款，不等于一般全交通闭合。近soft、其它责任、未知X包含和原负账仍未由本轮支付。

本节不认证数值文件或未运行复现。下一步仅待主稿逐式对应及最终SHA绑定。


## 10. 主稿最终对应、数值范围及冻结绑定

已实读最终 research.tex 并读回两处域限定：
“从此处起”将r交实际s(x)≤1−d，F_J、R均为同一far交通、near为零；Q₀明确写M^{-1}∫_{B₀}J_vdν。这样式(5)–(7)没有把far尾帽误用于near，局部矩也保留同一真实far权及来源域。

主稿式(1)–(7)与RA6–9/AB1–AB12一致，存活域及原e_t均保留；共同事件和两个min端控制同一实际交通。原精确窗口写为z∈[a/b,c_j²]⊂[a/b,1]，无效处取零、保原唯一j后聚合；式(9)的32ΛK/9及8e²Λ/3、式(10)条件根阶价均正确。式(11)是固定原r/Π/α下的实际低r部分付款，补集仍为E_d内Mr>H₀；式(12)严格α尾资格和随后弱尾layer-cake的q/(q−1)均正确。辅助式(8)保留共同固定profile量词，与允许实际selector的式(5)没有混淆。主稿未声称一般core预算或其它补集已付。

数值仅做代码、JSON与说明的静态核对，本审计没有调用producer。已核：
- 17个合成有限概率模型按6/8/3分阶段；76个q=2 profile、228个事件平方Hölder证书。
- 其它q的420个profile/exponent及1260事件为binary64、容差1e−11，明确非严格证书；JSON最大相对超差6.66e−16与说明相符。
- 同Π部分80个精确检查及648个min参数例为有限代数；不同Π反例保存，没有冒充原Π实例。
- root采用isqrt有理向外端点，exp采用Fraction的128项正Taylor和上余项后倒数；方向正确，指数调用域≤8。Cauchy比例/零支与一般向外区间分开。160位仅指绝对十进制网格，不是所有极小量的相对精度。
- JSON源码与辅助作者hash匹配；0新kernel、0原receiver、0原dx积分，不能据此认证实际α/ρ或统一H_q。执行次数字段只是producer所存元数据，本审计未独立追认运行历史或代替主级复现。

最终实际读取SHA256：

- adaptive_affinity.md：a476ad1a0387f1bc5bfb05a9dc56cb45a083739f5b7ccd0feec1177bb66786a2
- adaptive_budget.md：67d5e9d35f2099ed105a8014461535858a7a48978a9866dc39c7e6a0bd904690
- research.tex：54c7b264c00547ed8b9e2fbcfc0dd117ce56a004d409c012b76e5c0946cd8a3a
- numeric.py：4a05409f4d0a7c929de7af41993bc7916973bb010063b006aee48654d8515cf9
- numeric.json：31e0a854dc5f54e78dfe3c30492b3a833cf99f0020a082a4587d86a16878d6b8
- numeric.md：f9f0ae4816bb3ad9054d39d1ae94f26f0d7481a5a4cef447c207232fc8ed114c

结论：所审固定profile有限矩引理、实际min桥、完整条件外价及明确低r部分付款通过；一般来源core预算、near及全部互补分支和最终闭合仍未证明。只修改本audit.md，至此冻结并停止，不扩展研究。




