# R159：实际自适应 J 交通的局部检验预算

本轮证明一个直接作用于原交通的 min 桥及完整远 soft 条件付款：无需把接收依赖来源权当成固定混合测度，也无需它在整个接收空间可积。共同 core-count 事件外的原交通由显式指数项支付；事件内只留下原实际权的局部预算。给出局部 Lq、联合来源尾及局部截断的充分付款条件，全部保留原 α、来源、删除后验、time、唯一 j 和外 β。尚未证明原 good/共同余额自动满足这些局部条件，不声称一般闭合。

## AB1. 先筛准确命题与原支持

沿 R158 原定义 p=P_{s,L}(x-y)、J_v=P_{1,b}(x-v)、Q_v=(K₁+K₂+J_v)/3、χ_J=J_v/(3Q_v)，a≤L≤b、b/a≤2。K>0 是原给定 good 常数，good 条件为 p w_g(v)≤KQ_v。

固定原合法行及时间，写实际非负权
\[
 b_v=1_{Z_{j,t}}(v)1_{G\cap E}(v)
 \frac{w_t(v)}{e_tw_g(v)}
 \int\delta(v,u)\mathcal M(x,j,y,t,v,u)d\Pi_{j,t}(u),
 \qquad r_v=b_v\rho_v,
\tag{AB1}
\]
其中 e_t=∫_{Z_{j,t}}w_t dν 是原删除分母，δ=(k_v-k_u)_+，0≤k_v,k_u≤n，0≤mathcal M≤1 保留原 bad/history 等正门。E 是当前实际尚未付来源支；所有支持及权允许依 x、s,L、原 α。ρ=[1−(DK₀+αJ)/(TΔ)]_+ 沿原值，0≤ρ≤1。涉及已经放松的外 hard 来源的额外正门可先删去，但原 hard 帽的资格仍保留。零 e_t 行无正交通，不定义0/0。

AB1 中 outer v 的 Z_{j,t} 及原 terminal 资格必须保留；不能加回 ν 全域后仍使用后验概率帽。原
\[
 d\Pi_{j,t}=1_{Z_{j,t}}w_t\,d\nu/e_t
\]
不替换成独立于 j 的概率。

定义
\[
 B(x)=\int r_vw_g(v)d\nu(v),\quad
 R(x)=\int r_vJ_v(x)d\nu(v),\quad
 T_J(x)=p\int r_vw_g(v)\chi_J(v)d\nu(v).
\tag{AB2}
\]
本轮起点是准确的实际 min 桥
\[
 \boxed{T_J(x)\le\min\{(n/4)p(x-y),(K/3)R(x)\}.}
\tag{AB3}
\]
后文将用同一个接收事件控制第二项，不把 rν 当作固定测度。

## AB2. n/4 帽及 min 桥证明

对 0≤a,b≤n，有 (a−b)_+≤a(n−b)/n。以同一原后验 Π 的两份乘积积分，令 m=∫k dΠ，则
\[
 \iint(k_v-k_u)_+d\Pi(v)d\Pi(u)
 \le m(n-m)/n\le n/4.
\tag{AB4}
\]
这只用 pair 后验乘积，不要求 ν 的坐标独立。由 AB1 的支持、ρ≤1、mathcal M≤1，B≤n/4；χ_J≤1 给 T_J≤pB。在实际 good 支持上，p w_gχ_J=p w_g J/(3Q_v)≤KJ/3，故 T_J≤KR/3。两项都是同一个实际 T_J 的上界，因而得到 AB3。未先将两项的来源分别重选，也没有冻结 α。

## AB3. 一个共同接收检验事件

沿 R158 已审核记
\[
 \beta_*=\int_{-1/2}^{1/2}\phi(u)du,\qquad
 \kappa=1-\beta_*\ge1/16.
\]
这里 β_* 是一维数值，与外测度 β 无关。固定 0≤d≤1，定义与所有当前 selector 无关的事件
\[
 E_d(y)=\left\{x:\sum_{i=1}^n1_{\{|x_i-y_i|\le b/2\}}
 \ge n(\beta_*+\kappa d/2)\right\},\qquad
 \zeta=nd^2/512.
\tag{AB5}
\]
对每个固定来源 v，J_v 下这些指示变量独立，每个成功率≤β_*；对任意 s≤1−d、L≤b，在 P_{s,L}(x-y) 下它们独立且每个成功率≥β_*+κd。因此已审 Bernoulli 矩母函数界给
\[
 \int_{E_d}J_vdx\le e^{-\zeta}\quad\text{对全部 }v,
 \qquad \int_{E_d^c}P_{s,L}(x-y)dx\le e^{-\zeta}.
\tag{AB6}
\]
固定事件用同一 d，不按所选 s 改阈值；d=0 只是合法平凡帽。非整数阈值按实际事件处理。

固定参数尾不能直接用于自适应接收 p。把 [0,1−d] 分成至多 n 个长≤1/n 的区间 [s₀,s₁]，δ_s=s₁−s₀，u=s₁/(1+δ_s)。逐点 p_s≤(1+δ_s)p_u，故 n 维 P_s≤eP_u，且 u≤1−d。零长度全区间单列 s=0。尺度取向上公比 e^{1/n} 网格并含终点 b，点数≤n+1；每个 L 有 H≥L、H/L≤e^{1/n}，P_{u,L}≤eP_{u,H}。于是
\[
 \int_{E_d^c}\sup_{\substack{0\le s\le1-d\\a\le L\le b}}
 P_{s,L}(x-y)dx
 \le e^2n(n+1)e^{-\zeta}.
\tag{AB7}
\]
上确界可用 R158 已审的可数逼近实现。事件本身固定，实际 r(x,v) 无需有任何参数连续性。

## AB4. 只要求 E_d 内的实际预算

由 AB3，在 E_d 用 KR/3，在补集用 np/4，再用 AB7，得到
\[
 \boxed{\int_{\mathbb R^n}T_J(x)1_{\{s(x)\le1-d\}}dx
 \le\frac K3\int_{E_d}R_{\rm far}(x)dx
 +\frac{e^2}{4}n^2(n+1)e^{-\zeta}.}
\tag{AB8}
\]
R_far 由 AB1 的原权再交实际 far soft 门；以下略写 R。它可自由依赖实际 x,s,L、共同 α、原 j,time。AB8 不要求 ∫Rdx 有限，也不要求 E_d 外的任何 R 矩。若局部项无限，该式为合法扩展正数不等式但不给付款。

这比直接将固定混合亲和度套到 rν 更强：原交通在 E_d^c 已付一个明确指数项，不需要在那里控制自适应来源权。尚需控制的是固定 core-count 检验事件内的实际 J 加权正流，而不是整个接收空间的未加权或固定来源质量。

## AB5. 真正局部的 Lq 与来源尾充分条件

固定原 ν，令 M=ν(B₀)，B₀ 为原共同未删来源底集。M=0 行无交通。否则
\[
 Q_0(x)=J_\nu(x)/M,\qquad J_\nu(x)=\int_{B_0}J_v(x)d\nu(v)
\tag{AB9}
\]
是固定概率密度，不依接收 selector；各来源坐标可相关。R 使用真实 r，故 θ(x)=R(x)/Q₀(x) 仍可任意依 x。对 q>1，定义仅在 E_d 上的局部矩
\[
 H_{q,d}:=\left(\int_{E_d}\left(\frac R{Q_0}\right)^qQ_0dx\right)^{1/q},
 \qquad \vartheta_q=1-1/q.
\tag{AB10}
\]
Q₀>0，由 AB6 混合后 Q₀(E_d)≤e^{-ζ}，Hölder 给
\[
 \int_{E_d}Rdx\le H_{q,d}e^{-\vartheta_q\zeta}.
\tag{AB11}
\]
未出现额外 M 因子。这里没有将 θ 当成固定来源测度，也未要求 θ 在 E_d^c 可积。

若希望直接检查原源权，可用固定联合概率
\[
 d\mathbb Q(x,v)=J_v(x)dx\,d\nu(v)/M.
\]
Jensen 仅在条件来源概率 J_vν/J_ν 下使用，得到
\[
 H_{q,d}\le
 \left(\int_{E_d\times B_0}(Mr_v)^q d\mathbb Q\right)^{1/q}.
\tag{AB12}
\]
因此自适应 r 只出现在真实 J 加权局部联合矩中。归一化 Mr 正好消除来源总质量的缩放，不能漏掉它。

更弱的局部尾证书也足够：若某 A_{q,d}≥0 满足对所有 λ>0
\[
 \mathbb Q\{x\in E_d,\ Mr_v>\lambda\}
 \le(A_{q,d}/\lambda)^q,
\tag{AB13}
\]
则同时该尾≤Q₀(E_d)≤e^{-ζ}。层析精确积分 min(e^{-ζ},(A/λ)^q) 给
\[
 \int_{E_d}Rdx\le\frac q{q-1}A_{q,d}e^{-\vartheta_q\zeta}.
\tag{AB14}
\]
这不要求 q 阶矩有限。AB10、AB12 或 AB13 均为充分预算，不声称原合同已自动给出。

## AB6. 原 α 对局部尾给出的准确资格

令 A_v=TΔ_v，局部权 r_v=b_vρ_v。对 b_v>0、A_v>0 和 λ>0，有精确等价
\[
 Mr_v>\lambda
 \Longleftrightarrow
 \left\{Mb_v>\lambda,\quad
 DK_{0,v}+\alpha J_v
 <A_v\left(1-\frac{\lambda}{Mb_v}\right)\right\}.
\tag{AB15}
\]
b_v=0 或原无效来源不进入尾。α=0 也由同一式处理，不除以 α。因而 AB13 可逐项写成
\[
 \frac1M\int_{E_d}\int J_v(x)
 1_{\{Mb_v>\lambda\}}
 1_{\{DK_{0,v}+\alpha J_v<A_v(1-\lambda/(Mb_v))\}}
 d\nu(v)dx\le(A_{q,d}/\lambda)^q.
\tag{AB16}
\]
全部 K₀,J、原 Δ、共同 α 及 b_v 的 bad-score/来源归一权都在这个具体接收局部化条件中。支持及权可以依 α，不能先冻结它们再优化 α。

原共同余额 αQ_J≥D∫bad K₀ν 是同一 x 的未加权 bad 来源容量；它本身没有给出 AB16 的 E_d 接收局部化、J 权或 b_v 高尾。本文没有把该余额当成 AB16 的证明。下一项确切待证连接是：沿原真实 α producer 和其共同 good/bad 几何，证明 AB16 的 A_{q,d} 在原外层聚合后至多多项式；或者直接证明 AB8 中 ∫_{E_d}R 的相应预算。其外费在下一节完整列出。

## AB7. 唯一 j、共同时间及原外价

在原合法窗口 a/c_j≤t≤bc_j 内，逐 j 换 z=c_jt/b，公共 z∈[a/b,1]。先保留原 history 下唯一 1_{j(x)=j} 及实际窗口，把实际 r_{j,bz/c_j} 按这个唯一选择拼为 r_z(x,v)，无有效行处取0。此时 r_z 仍完全自适应，AB8–AB16 正允许这种依赖。不能先删除使 j 唯一的选择资格后另对每个 j 领取一份接收预算。原额外正门若放松，应在此资格保留的上界中进行。

以 dΓ 表示除当前 dx、dz/z 外的原预先标签及 dβ(y) 聚合，其总质量为原 W_β；这里继承 R157 已审 exterior_joint.md EJ4–EJ5 的同一标签/外测度聚合合同，不另把标签计数当作免费概率。原 hard 仅用一次16/3，外2Λ后为32Λ/3。记
\[
 \mathcal C_d=\int d\Gamma\int_{a/b}^1\frac{dz}{z}
 \int_{E_d(y)}R_z(x)dx,
 \qquad
 \mathcal H_{q,d}=\int d\Gamma\int_{a/b}^1H_{q,d,z}\frac{dz}{z}.
\tag{AB17}
\]
定义保持原 β，不替换为 ν。则真正的完整费用为
\[
 \boxed{2\Lambda P_{J,\mathrm{far},d}
 \le\frac{32\Lambda K}{9}\mathcal C_d
 +\frac{8e^2\Lambda}{3}\,n^2(n+1)\log2\,e^{-\zeta}W_\beta,}
\tag{AB18}
\]
以及条件矩版本
\[
 \boxed{2\Lambda P_{J,\mathrm{far},d}
 \le\frac{32\Lambda}{3}
 \left[\frac K3e^{-\vartheta_q\zeta}\mathcal H_{q,d}
 +\frac{e^2}{4}n^2(n+1)\log2\,e^{-\zeta}W_\beta\right].}
\tag{AB19}
\]
AB18 第一系数与 R158 JB16 的32ΛK/9一致；没有再支付第二次 hard。原删除后验一直保留，故本式不需要附加 η 门或额外 η⁻¹。z 时间窗只花一次 log2，未把原 t 窗和公共 z 窗混淆。

## AB8. 明确的根阶付款条件及可支付部分

假设 0≤d≤1 且
\[
 \zeta\ge\tfrac52\log(n+2),\qquad
 \mathcal C_d\le(3/K)\sqrt n\,W_\beta.
\tag{AB20}
\]
第一条件即 d²≥1280 log(n+2)/n。因为 n²(n+1)/(n+2)^{5/2}≤√n，AB18 给
\[
 2\Lambda P_{J,\mathrm{far},d}
 \le\frac{32\Lambda}{3}(1+e^2\log2/4)\sqrt nW_\beta
 <32\Lambda\sqrt nW_\beta.
\tag{AB21}
\]
若所需 d>1，则此充分条件不给非空 far soft 带；不可延长到非法 d。对于任意实际 d，始终保留 AB18 的准确费用。

局部矩条件只需多项式大小，而非统一微小：若 mathcal H_{q,d}≤H W_β，则令
\[
 \zeta\ge\max\left\{\tfrac52\log(n+2),\quad
 \vartheta_q^{-1}\log_+\frac{KH}{3\sqrt n}\right\}
\tag{AB22}
\]
即可由 AB19 得同一 AB21。log_+u=max(0,log u)；H=0 时仅将 log_+ 项取0，仍保留 (5/2)log(n+2) 条件。固定 q>1、K 与 H 为 n 的多项式时，只需 d²=O(log(n+2)/n)；所有实际 time/j/外层费用已含在 mathcal H，不再隐含按层重复领取。局部弱尾使用 mathcal H 替换为 q/(q−1) 的聚合 A 预算即可。

还可不假设整个局部高尾已付，而明确支付一个实际截断部分。对给定固定 H₀≥0，保持原 r、Π、α 不重算，仅将 E_d 内的来源交 Mr_v≤H₀。该部分的局部预算≤H₀e^{-ζ} 逐行；与 E_d^c 的已付部分互斥相加得
\[
 2\Lambda P_{J,\mathrm{far},d}^{\mathrm{outside}\ E_d\ \cup\ \mathrm{low}\ r}
 \le\frac{32\Lambda}{3}\log2\,e^{-\zeta}
 \left[KH_0/3+e^2n^2(n+1)/4\right]W_\beta.
\tag{AB23}
\]
例如 ζ≥(5/2)log(n+2) 且 H₀≤3e^ζ√n/(K log2)，其价也小于32Λ√nW_β。剩余准确为 E_d 内 Mr_v>H₀ 的原来源交通，尾资格正是 AB15；没有宣称它为空或免费。AB23 是具体部分付款，非把整个原剩余改名。

## AB9. 本轮边界

新证明是 AB3 的原 min 桥、AB8 的固定检验事件分割及 AB18–23 的完整条件价。固定混合亲和度不被错误应用到 rν；其接收检验思想直接用于同一实际 traffic，所以 selector 依赖已被允许并支付。原 α 在所有权和尾资格中保持，原 good 门只用于合法责任比较。

尚未获得一般输入下 AB20 或 AB22 的自动预算；AB16 是下一步明确的核/来源/共同余额连接。近 soft 补集不能仅凭 CS10 宣称已付：若只有 B≤n/4，乘 CS10 仍会多一个 n。只有此前各自已审且满足完整源时合同的近 soft 分支可继续使用。本轮不处理其余责任、低 score、历史负项或全局 X 的未知包含关系，不声称 FULL 根阶闭合。有限交付到此停止。
