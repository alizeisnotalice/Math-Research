#!/usr/bin/env python3
"""R159 synthetic finite joint certificates. No original kernels or transport."""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
import argparse,hashlib,itertools,json,math,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def enc(v):
    if isinstance(v,F):return f'{v.numerator}/{v.denominator}'
    if isinstance(v,dict):return {str(k):enc(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [enc(x) for x in v]
    return v

def root(q,digits=80):
    assert q>=0;scale=10**digits;k=math.isqrt(q.numerator*scale*scale//q.denominator);lo=F(k,scale);hi=lo if lo*lo==q else F(k+1,scale);assert lo*lo<=q<=hi*hi;return lo,hi
@lru_cache(None)
def expminus(x,N=128):
    assert 0<=x<=8;t=a=F(1)
    for j in range(1,N+1):t*=x/j;a+=t
    rem=t*x/(N+1)/(1-x/F(N+2));return 1/(a+rem),1/a

def joint(n,beta,s,compressed=False):
    p=beta+(1-s)*(1-beta)
    if compressed:
        nu=[F(1,2),F(1,2)];probs=[[beta]*n,[beta/4]*n];obs=list(range(n+1));ones=obs
        def binomdist(b):return [F(math.comb(n,k))*b**k*(1-b)**(n-k) for k in obs]
        cond=[binomdist(beta),binomdist(beta/4)];P=binomdist(p)
    else:
        nu=[F(1,2),F(1,3),F(1,6)];probs=[[beta]*n,[beta/4]*n,[beta*F(i+1,n+1) for i in range(n)]];obs=list(range(2**n));ones=[mask.bit_count() for mask in obs]
        cond=[[math.prod((ps[i] if mask&(1<<i) else 1-ps[i] for i in range(n)),start=F(1)) for mask in obs] for ps in probs];P=[p**k*(1-p)**(n-k) for k in ones]
    Q=[[nu[v]*cond[v][i] for v in range(len(nu))] for i in range(len(obs))];assert sum(P)==1 and sum(map(sum,Q))==1
    threshold=n*(beta+(1-s)*(1-beta)/2);cut=(threshold.numerator+threshold.denominator-1)//threshold.denominator;event=[i for i,k in enumerate(ones) if k>=cut];rare=[len(obs)-1]
    return dict(n=n,beta=beta,s=s,compressed=compressed,nu=nu,probs=probs,P=P,Q=Q,ones=ones,event=event,rare=rare)

def profiles(model):
    Q=model['Q'];N=len(Q);V=len(Q[0]);n=model['n'];rare=model['rare'][0];qa=Q[rare][0];qr=sum(Q[rare]);assert qa>0 and qr>0
    if model['compressed']:
        return [('one',[[F(1)]*V for _ in Q]),('rare_receiver_normalized',[[1/qr if i==rare else F(0) for v in range(V)] for i in range(N)])]
    return [('zero',[[F(0)]*V for _ in Q]),('one',[[F(1)]*V for _ in Q]),('receiver_source',[[1+F(model['ones'][i],n)+F(v,2) for v in range(V)] for i in range(N)]),('rare_atom_normalized',[[1/qa if i==rare and v==0 else F(0) for v in range(V)] for i in range(N)]),('rare_receiver_normalized',[[1/qr if i==rare else F(0) for v in range(V)] for i in range(N)])]

def cauchy_part(P,R,indices):
    ps=sum(P[i] for i in indices);rs=sum(R[i] for i in indices)
    if ps==0 or rs==0:return dict(status='EXACT_ZERO',actual=[F(0),F(0)],product=ps*rs,root_digits=0)
    j=next(i for i in indices if P[i]>0);proportional=all(P[i]*R[j]==R[i]*P[j] for i in indices)
    if proportional:return dict(status='EXACT_PROPORTIONALITY',actual=root(ps*rs),product=ps*rs,root_digits=80)
    for digits in [80,160,320,640,1280]:
        boxes=[root(P[i]*R[i],digits) for i in indices if P[i]*R[i]];lo=sum(x[0] for x in boxes);hi=sum(x[1] for x in boxes)
        if hi*hi<=ps*rs:return dict(status='PASS_SQUARED_INTERVAL',actual=[lo,hi],product=ps*rs,root_digits=digits)
    raise AssertionError('Cauchy part unresolved')

def exact_case(model,name,r):
    Q,P=model['Q'],model['P'];N=len(Q);R=[sum(q*a for q,a in zip(Q[i],r[i])) for i in range(N)];M2=sum(Q[i][v]*r[i][v]**2 for i in range(N) for v in range(len(Q[i])));mass=sum(R);assert mass*mass<=M2
    E=model['event'];Ec=[i for i in range(N) if i not in set(E)];holder=[]
    for label,idx in [('E',E),('Ec',Ec),('rare',model['rare'])]:
        qe=sum(sum(Q[i]) for i in idx);re=sum(R[i] for i in idx);assert re*re<=M2*qe
        holder.append(dict(event=label,Q_probability=qe,R_mass=re,lhs_square=re*re,rhs_square=M2*qe))
    parts=[cauchy_part(P,R,idx) for idx in [E,Ec]];Bupper=sum(root(part['product'])[1] for part in parts)
    # q=2: (2 sqrt(H2) exp(-n(1-s)^2/2048))^4 =16 M2 exp(-n(1-s)^2/512).
    X=F(model['n'],512)*(1-model['s'])**2;expbox=expminus(X);assert Bupper**4<=16*M2*expbox[0]
    return dict(profile=name,M2=M2,H2=root(M2),R_total=mass,holder=holder,cauchy_parts=parts,two_event_upper=Bupper,fixed_affinity_fourth_lhs=Bupper**4,fixed_affinity_fourth_rhs_lower=16*M2*expbox[0],q=2,a=F(1,2),exact_status='PASS')

def float_case(model,name,r,q):
    # Deliberately numeric: noninteger powers below are binary64, not interval certificates.
    Q,P=model['Q'],model['P'];N=len(Q);a=float(1-1/q);qf=float(q);M=sum(float(Q[i][v])*float(r[i][v])**qf for i in range(N) for v in range(len(Q[i])));H=M**(1/qf) if M else 0.;R=[sum(float(Q[i][v])*float(r[i][v]) for v in range(len(Q[i]))) for i in range(N)];errors=[]
    for idx in [model['event'],[i for i in range(N) if i not in set(model['event'])],model['rare']]:
        qe=float(sum(sum(Q[i]) for i in idx));re=sum(R[i] for i in idx);bound=H*qe**a;assert re<=bound+1e-11*max(1,re,bound);errors.append(max(0.,re-bound)/max(1.,re,bound))
    pe=sum(float(P[i]) for i in model['event']);re=sum(R[i] for i in model['event']);mass=sum(R);B=math.sqrt(max(0,pe*re))+math.sqrt(max(0,(1-pe)*(mass-re)))
    target=2*math.sqrt(H)*math.exp(-a*model['n']*float((1-model['s'])**2)/1024) if H else 0.;assert B<=target+1e-11*max(1,B,target)
    return dict(profile=name,q=q,a=1-1/q,Hq_numeric=H,two_event_numeric=B,affinity_bound_numeric=target,max_holder_relative_excess=max(errors),status='NUMERIC_PASS_NOT_CERTIFIED')

def common_profile_test(model):
    Q=model['Q'];ps=profiles(model)[2:];bar=[[max(r[i][v] for _nm,r in ps) for v in range(len(Q[i]))] for i in range(len(Q))];B2=sum(Q[i][v]*bar[i][v]**2 for i in range(len(Q)) for v in range(len(Q[i])));checks=0
    for name,r in ps:
        assert all(r[i][v]<=bar[i][v] for i in range(len(Q)) for v in range(len(Q[i])))
        assert sum(Q[i][v]*r[i][v]**2 for i in range(len(Q)) for v in range(len(Q[i])))<=B2
        for idx in [model['event'],model['rare']]:
            re=sum(Q[i][v]*r[i][v] for i in idx for v in range(len(Q[i])));qe=sum(sum(Q[i]) for i in idx);assert re*re<=B2*qe;checks+=1
    # Explicit finite counterexample to replacing moment(max r) by max moment(r).
    qatoms=[F(1,2),F(1,2)];families=[[F(2),F(0)],[F(0),F(2)]];max_individual=max(sum(q*x*x for q,x in zip(qatoms,r)) for r in families);bar2=sum(q*max(r[i] for r in families)**2 for i,q in enumerate(qatoms));assert bar2==4>max_individual==2
    return dict(status='PASS',profile_count=len(ps),dominating_M2=B2,event_checks=checks,counterexample=dict(Q=qatoms,profiles=families,max_individual_M2=max_individual,common_max_profile_M2=bar2),meaning='A common pointwise profile and its own moment are required for selector-varying weights; max separate moments is not substituted')

def primary_common_event():
    stages={};delta_tests=0;min_tests=0;witness=None
    for stage,ns in [('initial',[1,2,4,8]),('stress',[16,64]),('expanded',[1024,10**6])]:
        records=[]
        for n in ns:
            systems=[([0,n],[F(1,2),F(1,2)]),([0,n//2,n],[F(1,4),F(1,2),F(1,4)]),([0,n//3,2*n//3,n],[F(1,10),F(2,10),F(3,10),F(4,10)]),([0,n//2,n],[F(1),F(0),F(0)]),([n//2,n//2],[F(1,3),F(2,3)])]
            delta_rows=[]
            for k,pi in systems:
                N=len(k);assert sum(pi)==1 and all(0<=x<=n for x in k)
                unweighted=sum(pi[i]*pi[j]*max(k[i]-k[j],0) for i in range(N) for j in range(N));assert unweighted<=F(n,4)
                rho=[F(i%3,2) for i in range(N)];M=[[F((3*i+2*j)%5,4) for j in range(N)] for i in range(N)]
                weighted=sum(pi[i]*pi[j]*rho[i]*M[i][j]*max(k[i]-k[j],0) for i in range(N) for j in range(N));assert weighted<=unweighted;delta_tests+=2
                delta_rows.append(dict(k=k,Pi=pi,E_delta=unweighted,quarter_bound=F(n,4),rho=rho,M=M,weighted_B=weighted))
            pp=[F(1,7),F(2,7),F(4,7)];E=[0,1];rhs_by_case={}
            for K,B,inside,exponent in itertools.product([F(1,4),F(1),F(64)],[F(0),F(n,8),F(n,4)],[(F(0),F(0)),(F(1,7),F(1,11)),(F(100),F(2))],[0,12,2000]):
                R=[*inside,F(10**exponent)];left=[min(p*B,K*r/3) for p,r in zip(pp,R)];right=[K*R[i]/3 if i in E else B*pp[i] for i in range(3)];assert all(a<=b for a,b in zip(left,right));min_tests+=1
                key=(K,B,inside)
                if key in rhs_by_case:assert rhs_by_case[key]==sum(right)
                rhs_by_case[key]=sum(right)
                if exponent==2000 and K==1 and B==F(n,4) and inside==(F(1,7),F(1,11)) and witness is None:witness=dict(n=n,p=pp,E=E,K=K,B=B,R_inside=list(inside),R_outside='10^2000',left_sum=sum(left),common_event_bound=sum(right),R_inside_mass=sum(inside),global_R_mass_uncontrolled=True)
            records.append(dict(n=n,delta=delta_rows,far_prefactor_without_common_e_squared=dict(left=F(n*n*(n+1),4),right=F(n**3,2),check=n+1<=2*n),min_cases=81))
        stages[stage]=records
    assert F(1)>F(1,4)
    return dict(status='PASS_EXACT_SYNTHETIC_ONLY',stages=stages,delta_checks=delta_tests,min_common_event_cases=min_tests,outside_concentration_witness=witness,distinct_posterior_counterexample=dict(n=1,k=[0,1],Pi_v=[0,1],Pi_u=[1,0],E_delta=1,invalid_quarter=F(1,4)),far_contract='B<=n/4 times e^2 n(n+1) exp(-nd^2/512) gives <=(e^2/2)n^3 exp(-nd^2/512); exponent cancels in exact prefactor comparison',no_global_R_mass_needed=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'numeric.json');args=ap.parse_args();stages={};qother=list(map(F,['5/4','3/2','3','11/10','101/100','1001/1000']))
    menus=dict(initial=[(n,F(1,2),s,False) for n in [2,4] for s in [F(0),F(1,2),F(1)]],rare_threshold=[(8,b,s,False) for b in [F(1,2),F(7,8)] for s in [F(0),F(1,4),F(3,4),F(1)]],expanded_count_space=[(n,F(1,2),F(0),True) for n in [64,1024,4096]])
    exact_count=float_count=0;largest_root=0;common=None
    for stage,menu in menus.items():
        data=[]
        for n,b,s,compressed in menu:
            model=joint(n,b,s,compressed);exact=[];numeric=[]
            for name,r in profiles(model):
                row=exact_case(model,name,r);exact.append(row);exact_count+=1;largest_root=max(largest_root,max(x['root_digits'] for x in row['cauchy_parts']))
                if not compressed:
                    for q in qother:numeric.append(float_case(model,name,r,q));float_count+=1
            if common is None:common=common_profile_test(model)
            if not compressed:
                ps=model['probs'];nu=model['nu'];cov=sum(w*p[0]*p[1] for w,p in zip(nu,ps))-sum(w*p[0] for w,p in zip(nu,ps))*sum(w*p[1] for w,p in zip(nu,ps));assert cov!=0
            else:cov=None
            data.append(dict(n=n,beta_surrogate=b,s=s,compressed_count_space=compressed,source_weights=model['nu'],conditional_coordinate_probabilities='beta; beta/4; beta*(i+1)/(n+1)' if not compressed else 'beta; beta/4',observation_states=len(model['Q']),event='ones >= ceil(n*(beta+(1-s)*(1-beta)/2))',rare_event='all ones, fixed independently of s',unconditional_coordinate_covariance=cov,exact_q2=exact,numeric_other_q=numeric))
        stages[stage]=data
    penalties=[]
    for q in map(F,['2','5/4','11/10','101/100','1001/1000','1000001/1000000']):
        a=1-1/q;penalty=root(1/a);penalties.append(dict(q=q,a=a,penalty_interval=penalty,C_interval=[1024*penalty[0],1024*penalty[1]],certified=True))
    authors={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['adaptive_affinity.md'] if (ROOT/f).exists()}
    result=dict(status='PASS',scope='Synthetic finite correlated Bernoulli Q and adaptive receiver/source weights only; no original transport Hq proof or kernels',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),author_files_sha256=authors,execution=dict(producer_invocations=2,new_kernel_evaluations=0,new_receiver_points=0),seed=None,stages=stages,counts=dict(models=sum(map(len,menus.values())),exact_q2_profiles=exact_count,exact_holder_event_checks=3*exact_count,numeric_other_q_profiles=float_count,numeric_holder_event_checks=3*float_count,max_cauchy_root_digits=largest_root),primary_common_event=primary_common_event(),common_profile=common,q_to_one_penalty=penalties,constant_contract=dict(a='1-1/q',fixed='2 sqrt(Hq) exp(-a n(1-s)^2/1024)',far='4e n^2 sqrt(Hq) exp(-a n d^2/1024)',full='1024/sqrt(a) n^(1/4) sqrt(log(n+2)) sqrt(Hq)',q_optimality_claimed=False),certification=dict(q2='Exact event squared Holder and rational outward-root Cauchy/fourth-power exponential bound',other_q='binary64 powers, relative/absolute tolerance1e-11; explicitly not certified',roots='isqrt outward decimal grids80 then160/320/640/1280 as needed',exp='Fraction Taylor N128 with explicit tail for exponent<=8'),limitations=['Q has conditional coordinate independence but is correlated after source mixing','All synthetic r and rare-event normalizations remain fixed across each selector s family; per-selector profiles require a common dominating profile','No original alpha/rho/source Hq bound is manufactured','No general geometry/FULL or original selector/source payment certified'])
    args.output.write_text(json.dumps(enc(result),ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='PASS',counts=result['counts'],stage_models={k:len(v) for k,v in stages.items()})))
if __name__=='__main__':main()
