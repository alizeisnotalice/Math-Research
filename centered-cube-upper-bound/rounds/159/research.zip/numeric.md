# R159 有限相关混合、适应权与共同事件证书

结果：numeric.json status=PASS。只有确定性有限概率/标量模型，0新kernel、0新原receiver、0原dx积分。没有制造原交通Hq预算或原行计算；共同alpha、rho、good、history和实际来源权的profile存在性仍未证。

## 1. 三阶段数据，来源相关性与权重固定性

Q是(x,v)上的概率联合表，Q(x,v)=nu_v Q_v(x)。每个固定v条件下坐标独立，混合后坐标相关。前两阶段三来源nu=(1/2,1/3,1/6)，条件成功概率分别全beta、全beta/4、beta*(i+1)/(n+1)。P的成功概率全取beta+(1−s)(1−beta)，共同事件E={ones>=ceil[n(beta+(1−s)(1−beta)/2)]}。beta只是有理概率代数替身，不是实际phi积分数值。

- 初探：n∈{2,4}、beta=1/2、s∈{0,1/2,1}，6模型。
- rare/阈值压力：n8、beta∈{1/2,7/8}、s∈{0,1/4,3/4,1}，8模型。
- 扩大：n∈{64,1024,4096}、beta=1/2、s0，用计数空间0..n及两个齐次条件来源beta、beta/4各权1/2，共3模型。不枚举2^4096模式。

小模型完整枚举2^n二元观测，逐例精确核Q、P归一化，并核混合后前两坐标协方差非零。大模型由二项分布精确计数压缩，保同一个合法有限联合Q；它不是原空间网格或高维kernel测量。

前两阶段每模型5个profile：r=0、r=1、r=1+ones/n+v/2、集中于(all-ones,v0)并归一化R总质量1、集中于all-ones receiver并归一化R总质量1。r可同时依x与v；all-ones稀有事件和它在Q下的归一化均固定于该n/beta族，**不**随s或其共同检验E改变。大模型取r=1和all-ones归一化两个profile。总17模型、76个profile，包含零权和稀有事件极端集中。

## 2. q=2严格证书与其他q数值标签

对r>=0，M2=ΣQ r²、H2=sqrt(M2)、R_x=Σ_vQ(x,v)r(x,v)。每profile分别对E、Ec、固定rare三事件精确核

    R(F)² <= M2 Q(F),  (ΣR)²<=M2.

共228事件平方检查。两事件Cauchy按各部分P、R有限向量独立检验：零分支直接为0；比例相等分支以精确比例身份登记等号；其余用有理向外根式和检查实际affinity部分的上端平方<=P(F)R(F)。根式从80位十进制格增至160/320/640/1280，实际最大160位；它是绝对网格精度，不声称所有极小概率都达到160位相对精度。

设两事件上帽B=Σ_(F=E,Ec)sqrt(P(F)R(F))。q2的a=1/2，固定affinity候选的四次幂是

    [2 sqrt(H2) exp(−n(1−s)²/2048)]^4
       =16 M2 exp(−n(1−s)²/512).

76profile逐个用B的严格根式上端、exp的严格下端核该不等式。因此q2的Hölder和两事件affinity比较是有限有理/区间证书，包含r=0的精确零支。没有以浮点误差容忍接受。

另外q∈{5/4,3/2,3,11/10,101/100,1001/1000}仅在前两阶段小模型计算，共420个profile/exponent、1260个事件Hölder比较。使用binary64非整数幂与相对/绝对1e−11容差，明确为NUMERIC_PASS_NOT_CERTIFIED；最大Hölder数值相对超差约6.66e−16。它们不能冒充严格Hq区间。大模型不做易溢出的浮点高次矩。

## 3. q下降至1与共同dominating profile

作者已确认辅助统一常数为1024 sqrt(q/(q−1))，固定式为2 sqrt(Hq) exp[−(1−1/q)n(1−s)²/1024]。不宣称q依赖最优，也不把quarter power写成已证。绑定adaptive_affinity.md SHA `a476ad1a0387f1bc5bfb05a9dc56cb45a083739f5b7ccd0feec1177bb66786a2`。

对q=2、5/4、11/10、101/100、1001/1000、1000001/1000000，a=(q−1)/q精确有理，sqrt(1/a)向外根式证书均保存；显示约1.4142、2.2361、3.3166、10.0499、31.6386、1000.0005。最后一个只测常数penalty，不冒记为浮点Hölder已测q。这体现q→1的费用发散，不由有限点拟合其最优阶。

对于selector可能改变r的情形，测试同一Q上的三个profile之逐点最大bar_r：严格核每个r_s<=bar_r及其M2<=bar_M2，且各事件R_s(F)²<=bar_M2 Q(F)。不能用max_s||r_s||代替共同profile的矩。最小反例：Q两原子各1/2，r0=(2,0)、r1=(0,2)，分别M2=2，共同max profile=(2,2)的M2=4>2。它不否定其他可能的selector估计，只说明本定理的共同domination假设不能省略或换成各自矩帽。

## 4. 主引理：同Π的n/4、共同事件min，不需要全局R质量

此部分与上述Hq路线分开。三个阶段n∈{1,2,4,8}、{16,64}、{1024,10^6}，每n有5个共同Π模型：0/n端点各半、0/中/n三点、四点非均匀Π、零来源质量、score恒定。k均在[0,n]，每例精确核

    B0=ΣΠ_iΠ_j(k_i−k_j)_+ <=n/4,
    B=ΣΠ_iΠ_j rho_i Mij(k_i−k_j)_+ <=B0,

其中rho_i=(i mod3)/2、Mij=((3i+2j) mod5)/4均在[0,1]。80个精确检查通过；端点各半的无门模型精确饱和n/4。不同Π不能偷换：Pi_v集中n、Pi_u集中0时Edelta=n>n/4，保存n1反例。它只是共同后验的有限必要代数，不认证原Π实际构造。

共同事件min检查每个n取K∈{1/4,1,64}、B∈{0,n/8,n/4}、三种固定R_inside、R_outside=10^e（e=0,12,2000），总648个参数例，三个receiver原子p=(1/7,2/7,4/7)、同一E={0,1}。逐原子精确核

    min(pB,KR/3) <= KR 1_E/3 + Bp 1_Ec.

R可按参数改变，没有共同profile或Hq要求；R_outside可极大而右端只依R(E)及P(Ec)。每组inside/K/B固定时，右端在三个outside指数间精确相同。保存10^2000集中于Ec的见证，其global R质量不受控而该上帽仍成立；没有偷偷以R总质量支付。此处是有限原子上的精确逐点不等式，不是实际原行R组装或一般接收证明。

父级给定共同检验far-P价e² n(n+1) exp(−nd²/512)，结合B<=n/4，有限证书核其prefactor

    n²(n+1)/4 <= n³/2,

故far项可写(e²/2)n³ exp(−nd²/512)。比较中同一正exp及e²被消去，大n未评价极小指数，也没有将它误混成辅助Hq路线的4e n²网格价。薄壳、time/j、原共同来源量和最终费用仍依主级数学合同。

## 5. 复现、真实执行与界线

仅标准库Fraction/math/JSON，实际解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置：

    /opt/homebrew/opt/python@3.14/bin/python3.14 numeric.py

--output可另存。q2所有接受均精确整数/Fraction或严格根式/exp区间；exp用128项Taylor及显式几何余项，只在指数<=8调用。无随机seed。输出约651KB，保存必要profile生成定义、q2/数值分类、矩阵见证和参数菜单，不输出完整大联合数组。

实际完整调用2次，均exit0/PASS，无失败：第一次完成辅助Hq菜单；收到父级新增主引理后，第二次加入n/4、min和far prefactor检查并绑定最终辅助作者文件。没有重跑旧kernel实验或原网格。代码不修改其他作者文件，无Git。

冻结SHA256：

- numeric.py：`4a05409f4d0a7c929de7af41993bc7916973bb010063b006aee48654d8515cf9`
- numeric.json：`31e0a854dc5f54e78dfe3c30492b3a833cf99f0020a082a4587d86a16878d6b8`

synthetic Hq有限、共同profile存在或min的有限正确性都不证明原运输profile有预算；没有原alpha/rho/Hq或原dx新证据，不宣称FULL或主目标闭合。完成后停止。
