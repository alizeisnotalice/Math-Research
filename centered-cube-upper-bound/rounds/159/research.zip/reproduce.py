#!/usr/bin/env python3
"""Reproduce the finite R159 certificates. Python >=3.11, standard library only."""
import argparse, ast, hashlib, json, pathlib, re, shutil, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser(); ap.add_argument('--destination',type=pathlib.Path,required=True); args=ap.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for p in root.glob('*.py'): ast.parse(p.read_text())
stack=[]
for kind,name in re.findall(r'\\(begin|end)\{([^}]+)\}',(root/'research.tex').read_text()):
    if kind=='begin': stack.append(name)
    else: assert stack and stack.pop()==name,(kind,name)
assert not stack
args.destination.mkdir(parents=True,exist_ok=False)
for name in ['numeric.py','adaptive_affinity.md']: shutil.copy2(root/name,args.destination/name)
subprocess.run([sys.executable,str(args.destination/'numeric.py'),'--output',str(args.destination/'numeric.json')],check=True)
assert (args.destination/'numeric.json').read_bytes()==(root/'numeric.json').read_bytes(),'JSON mismatch'
print(json.dumps({'status':'PASS','json_byte_identical':True,'manifest_hashes':len(manifest['sha256']),'latex_environment_balance':True,'pdf_compiled':False}))
