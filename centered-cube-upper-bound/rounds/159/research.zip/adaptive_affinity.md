# R159：共同接收适应 profile 的有限矩接收界

筛查结论：命题成立。对每个 \(q>1\)，可以显式取
\[
\boxed{C(q)=1024\sqrt{\frac q{q-1}}.}
\]
这里允许权重同时依赖接收点和源点，但要求整个接收参数族由**同一个**有限矩 profile 控制。本证明不建立原交通中的 profile 存在性或其矩预算。下面只使用初等条件尾界、Hölder、有限网格，以及 R158 已有的质量包络输入；不使用反向 Jensen。

## 1. 精确对象及统一结论

设 \(n\ge1\) 为整数，\(0<a\le b\le2a\)，\(y\in\mathbb R^n\)，并定义
\[
h=\mathbf1_{[-1/2,1/2]},\quad
w(u)=\int_0^1e^{-|u|/t}\,dt,\quad
\varphi=h*w,\quad p_s=(1-s)h+s\varphi,
\]
\[
P_{s,L}(x-y)=L^{-n}\prod_{i=1}^np_s((x_i-y_i)/L),
\qquad J_v(x)=b^{-n}\prod_{i=1}^n\varphi((x_i-v_i)/b).
\]
其中 \(0\le s\le1\)、\(a\le L\le b\)。有 \(\int w=\int_0^1 2t\,dt=1\)，各核为概率密度，且 \(\varphi,p_s\) 偶并在正半轴非增。

令 \(\nu\) 为任意固定的概率 Borel 测度，允许其各坐标任意相关。在乘积变量空间上定义概率测度
\[
d\mu(x,v)=J_v(x)\,dx\,\nu(dv).
\]
给定非负可测函数 \(r(x,v)\)，要求它固定于整个 \((s,L)\) 上确界，并满足
\[
H_q=\left(\int r(x,v)^q\,d\mu(x,v)\right)^{1/q}<\infty,
\qquad q>1.
\]
设
\[
R(x)=\int r(x,v)J_v(x)\,\nu(dv),\quad
m=\int R(x)\,dx,\quad
\theta=1-1/q,\quad q'=\frac1\theta=\frac q{q-1}.
\]
Tonelli 和 Hölder 给出
\[
m=\int r\,d\mu\le H_q. \tag{1}
\]
若 \(H_q=0\)，则 \(R=0\) 几乎处处，以下结论平凡。否则，对所有上述对象统一有
\[
\boxed{
\int_{\mathbb R^n}\sup_{\substack{0\le s\le1\\a\le L\le b}}
\sqrt{P_{s,L}(x-y)R(x)}\,dx
\le1024\sqrt{q'}\,\sqrt{H_q}\,
n^{1/4}\sqrt{\log(n+2)}.
} \tag{2}
\]
因此所需的源质量费用是 \(\sqrt{H_q}\)，不存在支持数或源坐标相关性的额外费用。\(R\) 是固定函数，虽然定义它的 \(r\) 可以依赖 \(x\)。核的参数上确界可用可数稠密 soft 参数、从上方逼近的可数稠密尺度并加入端点 \(b\) 实现；硬盒取闭盒时此逼近保留边界值。因此这些上确界可测。

## 2. 共同 Bernoulli 检验与加权事件质量

记
\[
\beta=\int_{-1/2}^{1/2}\varphi(u)\,du,\qquad
\kappa=1-\beta,\qquad \varepsilon=1-s.
\]
有明确下界 \(\kappa\ge1/16\)。事实上，令 \(U\sim h,W\sim w\) 独立，\(U+W\sim\varphi\)；\(|W|>1\) 蕴含 \(|U+W|>1/2\)，除去零测边界。因此
\[
\kappa\ge\int_0^1 2t e^{-1/t}\,dt
\ge\tfrac12e^{-2}\ge\tfrac1{16}.
\]
最后一步可由 \(e<11/4\)，故 \(e^2<8\)，验证。

使用与 \(v\) 无关的统计量
\[
T(x)=\sum_{i=1}^n\mathbf1_{\{|x_i-y_i|\le b/2\}}.
\]
在 \(P_{s,L}(x-y)\,dx\) 下，各坐标指示量独立，成功概率至少
\[
(1-s)+s\int_{-b/(2L)}^{b/(2L)}\varphi
\ge\varepsilon+(1-\varepsilon)\beta
=\beta+\kappa\varepsilon. \tag{3}
\]
这是因为 \(L\le b\)，硬核在检验区间内的质量为 1。

对每个固定 \(v\)，在 \(J_v(x)\,dx\) 下这些指示量也独立，成功概率各自不超过 \(\beta\)。确实，各概率是 \(\varphi\) 在长度为 1 的某个区间上的积分；由偶单调性，中心区间使该积分最大。可用 layer-cake 逐个比较任意区间与中心超水平区间的交长，得到这个全局结论。

为保留自足的尾界：对任意 Bernoulli 变量 \(B\)，中心化对数矩母函数的二阶导数为一个倾斜 Bernoulli 分布的方差，至多 \(1/4\)，其在 0 的值和一阶导数均为 0，故
\[
\log\mathbb E e^{\lambda(B-\mathbb EB)}\le\lambda^2/8.
\]
独立求和并优化 Markov 界，得到每侧
\[
\mathbb P\!\left(\sum_i(B_i-\mathbb EB_i)\ge nt\right)\le e^{-2nt^2},
\qquad
\mathbb P\!\left(\sum_i(B_i-\mathbb EB_i)\le-nt\right)\le e^{-2nt^2}.
\tag{4}
\]
不要求各 Bernoulli 参数相同。

固定 \(s,L\)，取
\[
E=\left\{T(x)\ge n\left(\beta+\frac{\kappa\varepsilon}{2}\right)\right\},
\qquad B=\frac{n\kappa^2\varepsilon^2}{2}.
\]
由 (3)、(4) 和固定源下的成功概率上界，
\[
P_{s,L}(E^c)\le e^{-B},
\qquad J_v(E)\le e^{-B}\quad\text{对每个 }v.
\tag{5}
\]
阈值不必是整数；\(E^c\) 包含于相应的非严格下尾事件，\(E\) 包含于相应的上尾事件。\(\varepsilon=0\) 时右侧为 1，同样合法。

先对源统一，再由 Tonelli 混合，得到
\[
\mu(E\times\mathbb R^n)=\int J_v(E)\,\nu(dv)\le e^{-B}.
\]
虽然混合后各坐标通常不独立，这一步仍然成立。现在对固定的 \(r\) 使用 Hölder：
\[
\int_E R(x)\,dx
=\int\mathbf1_E(x)r(x,v)\,d\mu(x,v)
\le H_q\,\mu(E\times\mathbb R^n)^\theta
\le H_qe^{-\theta B}.
\tag{6}
\]
这正是允许接收适应权重时额外需要支付的 \(q\) 费用；不能用未加权的 \(J_\nu(E)\) 直接代替左边。

在 \(E,E^c\) 上分别 Cauchy，结合 (1)、(5)、(6)：
\[
\begin{aligned}
\int\sqrt{P_{s,L}R}
&\le\sqrt{P_{s,L}(E)R(E)}
+\sqrt{P_{s,L}(E^c)R(E^c)}\\
&\le\sqrt{H_q}\,e^{-\theta B/2}+\sqrt m\,e^{-B/2}\\
&\le2\sqrt{H_q}\,e^{-\theta B/2}.
\end{aligned}
\]
由于 \(\kappa^2/4\ge1/1024\)，得到固定参数的完整界
\[
\boxed{\quad
\int\sqrt{P_{s,L}(x-y)R(x)}\,dx
\le2\sqrt{H_q}\exp\!\left(-\frac{\theta n(1-s)^2}{1024}\right).
\quad} \tag{7}
\]

## 3. 连续参数网格的全部费用

对 \(0\le d\le1\)，把 \([0,S]\)、\(S=1-d\)，分成至多 \(n\) 段，每段 \([s_0,s_1]\) 的长度 \(\delta\le1/n\)。令
\[
u=\frac{s_1}{1+\delta}.
\]
对该段内全部 \(s\)，
\[
p_s\le(1-s_0)h+s_1\varphi=(1+\delta)p_u,
\qquad P_{s,L}\le eP_{u,L}.
\]
所有格点 \(u\le S\)，因而保留 \(1-u\ge d\)。\(S=0\) 时单用格点 0。

从 \(a\) 开始取相邻比 \(e^{1/n}\) 的尺度，最后截在 \(b\)。尺度格点数至多
\[
\lceil n\log(b/a)\rceil+1\le n+1.
\]
对任意 \(L\)，向上最近格点 \(H\) 满足 \(H/L\le e^{1/n}\)。偶单调性给出
\[
P_{u,L}(x-y)\le(H/L)^nP_{u,H}(x-y)\le eP_{u,H}(x-y).
\]
由于是同一个固定 \(R\)，逐点有
\[
\sup_{s\le1-d,L}\sqrt{P_{s,L}R}
\le e\sum_{u,H}\sqrt{P_{u,H}R}.
\]
使用 (7)，先保留准确的网格计数，再粗化，得到
\[
\boxed{\quad
\int\sup_{s\le1-d,L}\sqrt{P_{s,L}R}
\le2en(n+1)\sqrt{H_q}\,e^{-\theta nd^2/1024}
\le4en^2\sqrt{H_q}\,e^{-\theta nd^2/1024}.
\quad} \tag{8}
\]
特别地，\(1-s\ge D/\sqrt n\) 的整个连续族费用至多
\[
4en^2\sqrt{H_q}\,e^{-\theta D^2/1024},\qquad0\le D\le\sqrt n.
\]
这里没有把固定参数积分直接当成 selector 积分。

## 4. CS10 近 soft 输入及所有维数的拼接

本节使用 R158 已核验的两项质量包络。裸包络为
\[
\int\sup_{s,L}P_{s,L}\le3(2n+3)(1+\pi\sqrt n/2).
\tag{9}
\]
CS10 对 \(0\le d<1/2\) 给
\[
\begin{aligned}
\int\sup_{s\ge1-d,L}P_{s,L}
\le{}&1+10\sqrt n d+\log2\bigl[2nd+\sqrt{28n}\\
&+d\{10\sqrt n\sqrt{28n+n^2d^2}+6n+10nd\sqrt n\}\bigr]\\
\le{}&32\sqrt n(1+\sqrt n d)^2.
\end{aligned} \tag{10}
\]
最后一行是 R158 的逐项粗化；本文件不把 (10) 用到 \(d\ge1/2\)。

对固定 \(R\)，由 Cauchy 和 (1)、(10)，近 soft 部分满足
\[
\int\sup_{s\ge1-d,L}\sqrt{P_{s,L}R}
\le\sqrt{32}\,n^{1/4}(1+\sqrt n d)\sqrt m
\le\sqrt{32}\,n^{1/4}(1+\sqrt n d)\sqrt{H_q}.
\]
与 (8) 相加，得到有效的可优化表达式
\[
\boxed{\quad
\int\sup_{s,L}\sqrt{P_{s,L}R}
\le\sqrt{H_q}\left[
\sqrt{32}\,n^{1/4}(1+\sqrt n d)
+4en^2e^{-\theta nd^2/1024}\right],
\quad0\le d<1/2.
\quad} \tag{11}
\]

取
\[
A_q=\frac{4096}{\theta}=4096q',\qquad
d_*=\sqrt{\frac{A_q\log(n+2)}n},\qquad
C_0=\sqrt{15(1+\pi/2)}<7.
\]
若 \(d_*<1/2\)，在 (11) 使用 \(d=d_*\)。远项为
\[
4en^2(n+2)^{-4}\le e/16<1,
\]
因为 \((n+2)^2\ge8n\)。近项中 \(\sqrt n d_*=64\sqrt{q'\log(n+2)}\)。由 \(q'\ge1\)、\(\log(n+2)>1\)，整个括号至多
\[
\left[\sqrt{32}(1+64)+1\right]
\sqrt{q'}\,n^{1/4}\sqrt{\log(n+2)}
<391\sqrt{q'}\,n^{1/4}\sqrt{\log(n+2)}.
\]

若 \(d_*\ge1/2\)，由 (9) 直接 Cauchy 得
\[
\int\sup_{s,L}\sqrt{P_{s,L}R}
\le C_0n^{3/4}\sqrt{H_q}.
\]
此时
\[
n\le4A_q\log(n+2)=16384q'\log(n+2),
\]
故右边不超过
\[
128C_0\sqrt{q'}\,n^{1/4}\sqrt{\log(n+2)}\sqrt{H_q}
<896\sqrt{q'}\,n^{1/4}\sqrt{\log(n+2)}\sqrt{H_q}.
\]
这包括等号 \(d_*=1/2\)。两分支统一被常数 \(1024\sqrt{q'}\) 支配，得到 (2)。

## 5. 可选的固定参数常数改进与 \(q\) 依赖口径

固定参数的共同检验阈值也可取
\[
E_t=\{T\ge n(\beta+t\kappa\varepsilon)\},\qquad
t=\frac1{1+\sqrt\theta}.
\]
此时源上尾为 \(e^{-2n t^2\kappa^2\varepsilon^2}\)，接收下尾为
\(e^{-2n(1-t)^2\kappa^2\varepsilon^2}\)。重复 Hölder/Cauchy，两项的指数正好相等，得到稍强的固定参数式
\[
\int\sqrt{P_{s,L}R}
\le2\sqrt{H_q}
\exp\!\left[-\frac{n\kappa^2(1-s)^2}{(1+\sqrt{q'})^2}\right]
\le2\sqrt{H_q}
\exp\!\left[-\frac{n(1-s)^2}{256(1+\sqrt{q'})^2}\right].
\tag{12}
\]
主公式继续使用更简单且已核验的 (7)—(11)。两者的 \(q\downarrow1\) 阶相同。

**已证明的统一常数增长是 \(O((q')^{1/2})\)，不是 \(O((q')^{1/4})\)。** 已给 CS10 粗化后，近 soft 费用正比于 \(1+\sqrt n d\)，而远 soft 的安全指数只有 \(\theta nd^2\)；以这两项拼接，\(d\) 的尺度为 \(\sqrt{q'\log(n+2)/n}\)，因此不能从这些式子直接写出 quarter power。本文件不声称 half power 最优，也不把 quarter power 当成已证结论。

## 6. 参数选择与原矩预算的精确接口

1. 定理允许 \(r\) 依赖 \(x\) 和 \(v\)。它对整个上确界固定，这是 R158 固定源测度结果的严格扩展；不能将 \(r(x,v)\nu(dv)\) 称为一个不依赖 \(x\) 的固定源测度。
2. 若实际接收权重是 \(r_{s,L}(x,v)\)，一个充分条件是存在**同一个**可测 profile \(r(x,v)\)，在一个共同的 \(\mu\)-满测集上同时对所有 \((s,L)\) 满足 \(r_{s,L}\le r\)，且这个共同 profile 的 \(H_q\) 有所需预算。于是相应的 \(R_{s,L}(x)\le R(x)\) 可在一个共同的 \(x\)-满测集上成立，(2) 逐点支配实际 selector。
3. 不能把每个参数各自成立的 \(\|r_{s,L}\|_{L^q(\mu)}\le B\) 偷换成共同 profile 预算；也不能只给每个参数各自的零测例外集，再任意选择依赖 \(x\) 的参数。共同支配或足够的可数可测版本必须单独认证。
4. 原时间、共同 \(\alpha\)、`good` 门及来源权产生的 profile 若不随 \((s,L)\) 改变，可以在固定外参数后使用本结论，但外参数的积分、上确界及其矩预算仍须保留。若时间也被接收器选择，必须再有对该选择共同有效的 profile，不能免费加入时间上确界。
5. 本文件没有证明原 \(b_{v,\rho}\rho_v\) 或任何实际权重被这样的 \(r\) 支配，也没有证明所需 \(H_q\) 能由原负账/总预算支付。因此 (2) 不等于一般中心立方体弱型主目标闭合。

