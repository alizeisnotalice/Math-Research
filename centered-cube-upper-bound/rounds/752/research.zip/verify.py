from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256
RADII = (F(1, 16), F(1, 2), F(1))
W_VALUES = (F(-1), F(-3, 4), F(-1, 3), F(0), F(1, 5), F(3, 4), F(1))


def ball(x):
    x = F(x)
    return arb(fmpq(x.numerator, x.denominator))


def interval(x):
    return x.str(23)


def exact_sum(items):
    return sum(items, F(0))


def overlap_length(a, sa, b, sb):
    return max(F(0), min(a+sa, b+sb)-max(a-sa, b-sb))


def length_fraction(r, u, w):
    return min(F(1), max(F(0), (1+r-abs(u-r*w))/(2*r)))


def conditional_segments(r, w):
    breaks = sorted({
        F(-1), F(1),
        *(z for z in (r*w-(1-r), r*w, r*w+(1-r)) if -1 <= z <= 1),
    })
    densities = []
    atom = F(0)
    for u, v in zip(breaks, breaks[1:]):
        lo, hi = sorted((length_fraction(r, u, w), length_fraction(r, v, w)))
        assert length_fraction(r, (u+v)/2, w) == (lo+hi)/2
        for x in (u, (u+v)/2, v):
            assert overlap_length(x, F(1), r*w, r) == 2*r*length_fraction(r, x, w)
        if lo == hi:
            assert lo == 1
            atom += (v-u)/2
        else:
            densities.append((lo, hi, (v-u)/(2*(hi-lo))))
    a = (1+w)/2
    assert atom == 1-r
    assert sorted(densities) == sorted((lo, F(1), r) for lo in (a, 1-a) if lo < 1)
    return atom, densities


def moment_primitive(x):
    return ball(x) * (1-ball(x).log()) if x else arb(0)


def entropy_mean(r, w):
    a = (1+w)/2
    return ball(r) * (1 + exact_ball_xlogx(a) + exact_ball_xlogx(1-a))


def exact_ball_xlogx(x):
    return ball(x)*ball(x).log() if x else arb(0)


def conditional_tail(r, a, x):
    return r*(max(F(0), x-a)+max(F(0), x-(1-a)))


def scalar_geometry():
    constructions = []
    unconditional = []
    for r, w in product(RADII, W_VALUES):
        atom, densities = conditional_segments(r, w)
        mean_from_segments = sum(ball(height)*(moment_primitive(hi)-moment_primitive(lo))
                                 for lo, hi, height in densities)
        formula = entropy_mean(r, w)
        assert mean_from_segments.overlaps(formula)
        a = (1+w)/2
        for x in (F(0), F(1, 16), F(1, 2), F(3, 4), F(1)):
            assert conditional_tail(r, a, x) <= r*x
        clipped = {}
        for n in (16, 64):
            x = F(1, n)
            L = arb(n).log()
            mean_clip = sum(
                ball(height) * (
                    ball(max(F(0), min(x, hi)-lo))*L
                    + moment_primitive(hi)-moment_primitive(max(lo, min(hi, x)))
                )
                for lo, hi, height in densities
            )
            lost = formula-mean_clip
            if min(a, 1-a) >= x:
                assert lost.contains(0)
            elif a in (0, 1):
                assert lost.contains(ball(r/n))
            else:
                assert 0 < lost < ball(r/n)
            clipped[str(n)] = {
                "conditional_tail": str(conditional_tail(r, a, x)),
                "clipped_conditional_mean": interval(mean_clip),
            }
        constructions.append({
            "r": str(r), "w": str(w), "atom_at_ell_1": str(atom),
            "ell_density_intervals_with_multiplicity": [list(map(str, q)) for q in densities],
            "mean_Y_divided_by_r": interval(formula/ball(r)),
            "log_n_clipping": clipped,
        })

    for r, x in product(RADII, (F(0), F(1, 64), F(1, 4), F(1, 2), F(3, 4), F(1))):
        breaks = sorted({F(0), x, 1-x, F(1)})
        integrated = exact_sum(
            (v-u)*(conditional_tail(r, u, x)+conditional_tail(r, v, x))/2
            for u, v in zip(breaks, breaks[1:])
        )
        assert integrated == r*x**2
        unconditional.append({"r": str(r), "x_in_ell_tail": str(x), "probability": str(integrated)})
    return {
        "conditional_geometries": constructions,
        "unconditional_exact_trapezoid_checks": unconditional,
        "scope": "U uniform conditional on w, and the second list additionally integrates independent uniform W",
    }


@dataclass(frozen=True)
class Box:
    bounds: tuple

    def contains(self, z):
        return all(lo < x < hi for (lo, hi), x in zip(self.bounds, z))

    @property
    def volume(self):
        return prod(hi-lo for lo, hi in self.bounds)


def box(center, radius):
    return Box(tuple((x-radius, x+radius) for x in center))


def intersection(*boxes):
    return prod(
        max(F(0), min(hi for _, hi in axis)-max(lo for lo, _ in axis))
        for axis in zip(*(q.bounds for q in boxes))
    )


def shared_cell_prices(boxes, price_pieces):
    axes = []
    for axis in zip(*(b.bounds for b in boxes+[b for b, _ in price_pieces])):
        cuts = sorted({end for pair in axis for end in pair})
        axes.append(list(zip(cuts, cuts[1:])))
    cells = []
    for cell in product(*axes):
        z = tuple((lo+hi)/2 for lo, hi in cell)
        active = tuple(i for i, b in enumerate(boxes) if b.contains(z))
        if active:
            volume = prod(hi-lo for lo, hi in cell)
            density = exact_sum(value for b, value in price_pieces if b.contains(z))
            cells.append((active, volume, density))
    return cells


def full_owned_bin():
    radii = (F(1), *(F(1, 2) for _ in range(5)))
    centers = ((F(0), F(0)), (F(1), F(0)), (F(5, 4), F(1, 4)),
               (F(1), F(-3, 4)), (F(3, 2), F(0)), (F(1, 2), F(1, 2)))
    parents = [box(c, r) for c, r in zip(centers, radii)]
    owners = [box(c, r/64) for c, r in zip(centers, radii)]
    assert all(not intersection(a, b) for a, b in combinations(owners, 2))
    d = [b.volume for b in parents]
    v = [b.volume for b in owners]
    prices = [(box((F(0), F(0)), F(3)), F(1)),
              (Box(((F(3, 4), F(1)), (F(-1, 4), F(1, 4)))), F(4))]
    cells = shared_cell_prices(parents, prices)
    m = [exact_sum(volume*density for members, volume, density in cells if i in members)
         for i in range(len(centers))]
    assert all(y >= x for x, y in zip(d, m)) and any(y > x for x, y in zip(d, m))
    lam = [vi/(mi*(2 if i == 0 else 4)) for i, (vi, mi) in enumerate(zip(v, m))]
    assert all(exact_sum(lam[i] for i in members) <= 1 for members, _, _ in cells)
    assert all(lam[i]*m[i] <= v[i]/2 for i in range(len(centers)))
    output = []
    for j in range(1, len(centers)):
        I = intersection(parents[0], parents[j])
        mu = exact_sum(density*intersection(parents[0], parents[j], region) for region, density in prices)
        joint_cells = [(volume, density) for members, volume, density in cells if 0 in members and j in members]
        assert I == exact_sum(vol for vol, _ in joint_cells)
        assert mu == exact_sum(vol*den for vol, den in joint_cells)
        forward = lam[0]*v[j]*mu/m[j]
        reverse = lam[j]*v[0]*mu/m[0]
        assert forward == exact_sum(lam[0]*v[j]*vol*den/m[j] for vol, den in joint_cells)
        assert reverse == exact_sum(lam[j]*v[0]*vol*den/m[0] for vol, den in joint_cells)
        if I:
            z = [(max(a, c)+min(b, e))/2 for (a, b), (c, e) in zip(parents[0].bounds, parents[j].bounds)]
            axis_fraction = [
                length_fraction(radii[j], centers[0][k]-z[k], (centers[j][k]-z[k])/radii[j])
                for k in range(2)
            ]
            assert prod(axis_fraction) == I/d[j]
        else:
            assert not mu
            axis_fraction = None
        output.append({
            "small_label": j, "intersection_volume": str(I), "shared_price": str(mu),
            "p_true_price": str(mu/m[j]), "q_geometric": str(I/d[j]),
            "axis_fractions_for_chosen_common_point": list(map(str, axis_fraction)) if axis_fraction else None,
            "Pi_big_to_small": str(forward), "Pi_small_to_big": str(reverse),
        })
    forward = exact_sum(F(x["Pi_big_to_small"]) for x in output)
    reverse = exact_sum(F(x["Pi_small_to_big"]) for x in output)
    assert forward == 2*reverse > 0
    return {
        "dimension": 2,
        "centers": [list(map(str, x)) for x in centers],
        "radii": list(map(str, radii)),
        "all_small_sources_in_one_volume_bin": len(centers)-1,
        "positively_sized_price_arrangement_cells": len(cells),
        "actual_owner_volumes": list(map(str, v)),
        "parent_volumes": list(map(str, d)),
        "m": list(map(str, m)),
        "lambda": list(map(str, lam)),
        "pair_records": output,
        "total_Pi_big_to_small": str(forward),
        "total_Pi_small_to_big": str(reverse),
    }


def diagonal_price_case(n, r):
    big = box((F(0),)*n, F(1))
    small = box((F(1),)*n, r)
    own_big = box((F(0),)*n, F(1, 32*n))
    own_small = box((F(1),)*n, r/(32*n))
    assert not intersection(own_big, own_small)
    support = [box((1-h*r,)*n, r/16) for h in (F(1, 4), F(3, 4))]
    assert not intersection(*support)
    for region in support:
        assert intersection(region, big, small) == region.volume
        assert all(
            (1-lo)/r <= F(13, 16) and hi < 1
            for lo, hi in region.bounds
        )
    assert 1-arb(n+2).log()/n > ball(F(13, 16))
    # Half the price is uniform on each support cube. Both cubes are interior to the parents.
    price = big.volume
    m_big = sum((price/2)*intersection(region, big)/region.volume for region in support)
    m_small = sum((price/2)*intersection(region, small)/region.volume for region in support)
    shared = sum((price/2)*intersection(region, small, big)/region.volume for region in support)
    assert m_big == m_small == shared == price
    assert m_small > small.volume
    q = intersection(big, small)/small.volume
    assert q == F(1, 2**n)
    lam_big = own_big.volume/(2*m_big)
    lam_small = own_small.volume/(4*m_small)
    assert lam_big+lam_small < 1
    forward = lam_big*own_small.volume*shared/m_small
    reverse = lam_small*own_big.volume*shared/m_big
    assert forward == 2*reverse and reverse > 0
    initial_variance = F(1, 16)
    within_variance = F(1, 16)**2/3
    assert initial_variance/(initial_variance+within_variance) == F(48, 49)
    return {
        "dimension": n, "r": str(r), "one_axis_actual_overlap_fraction": "1/2",
        "p": "1", "q": str(q), "p_over_q": str(2**n),
        "m_big_in_units_of_d_big": "1", "m_small_in_units_of_d_small": str(1/r**n),
        "m_total_matches_P0": str(price),
        "small_axis_distance_to_center_divided_by_r_at_most": "13/16",
        "cross_coordinate_W_correlation_under_true_price": "48/49",
        "Pi_big_to_small": str(forward), "Pi_small_to_big": str(reverse),
    }


def coincident_w_reference():
    checks = []
    for n, k in product((16, 64, 256), (2, 4)):
        r, x = F(1, 2), F(1, n)
        correlated = 2*r**k*x**(k+1)/(k+1)
        independent = (r*x*x)**k
        assert correlated/independent == F(2*n**(k-1), k+1)
        checks.append({
            "n": n, "coordinates_k": k, "r": str(r),
            "probability_all_k_Y_gt_log_n_same_W": str(correlated),
            "probability_all_k_Y_gt_log_n_independent_W": str(independent),
            "amplification": str(correlated/independent),
        })
    return checks


def excluded_faces():
    records = []
    for n, r in product((6, 16, 128, 1024), RADII):
        cutoff = arb(n+2).log()/n
        assert cutoff > ball(F(2, n))
        ell = F(1, 2*n)
        s_center = 1 + r - 2*r*ell
        z_min = s_center-r
        assert overlap_length(F(0), F(1), s_center, r) == 2*r*ell
        # Over the whole overlap [z_min, 1], these are the smallest normalized distances.
        big_distance, small_distance = z_min, (s_center-1)/r
        assert ball(big_distance) > 1-cutoff and ball(small_distance) > 1-cutoff
        records.append({
            "n": n, "r": str(r), "ell": str(ell),
            "min_big_normalized_center_distance": str(big_distance),
            "min_small_normalized_center_distance": str(small_distance),
        })
    return records


def conditional_mgf(r, w, theta):
    a = (1+w)/2
    power = ball(1-theta)
    integral = sum((1-(ball(x).log()*power).exp())/power if x else 1/power
                   for x in (a, 1-a))
    return ball(1-r)+ball(r)*integral


def conditional_bounds():
    cases = 0
    for r, w, theta in product((F(1, 16), F(1), F(1, 2**30)), W_VALUES, (F(1, 8), F(1, 2), F(7, 8))):
        mean = entropy_mean(r, w)
        upward = conditional_mgf(r, w, theta).log()-ball(theta)*mean
        downward = conditional_mgf(r, w, -theta).log()+ball(theta)*mean
        assert upward < ball(r*theta**2/(1-theta))
        assert downward < ball(r*theta**2)
        cases += 1
    return cases


def mixed_tail(n, r, threshold):
    # A positive gamma-shape mixture, evaluated with interval arithmetic rather than sampling.
    t = ball(threshold)*2
    poisson = (-t).exp()
    poisson_cumulative = poisson
    if r == 1:
        for k in range(1, n):
            poisson *= t/k
            poisson_cumulative += poisson
        return poisson_cumulative
    weight = ball(1-r)**n
    answer = arb(0)
    odds = ball(r/(1-r))
    for k in range(1, n+1):
        weight *= odds*(n-k+1)/k
        answer += weight*poisson_cumulative
        poisson *= t/k
        poisson_cumulative += poisson
    return answer


def product_tails():
    checks = []
    for n, r, u in ((32, F(1), F(4)), (128, F(1, 2), F(4)),
                    (256, F(1, 16), F(2)), (1024, F(1, 2**24), F(1, 2)),
                    (256, F(1, 2**80), F(1, 8))):
        nr = n*r
        mean = nr/2
        theta = 2*u/(nr+u)
        upper = mixed_tail(n, r, mean+u)
        up_chernoff = (ball(1+r*theta/(2-theta)).log()*n-ball(theta*(mean+u))).exp()
        up_bernstein = (-ball(u*u/(nr+u))).exp()
        assert 0 < upper < up_chernoff < up_bernstein
        low = nr/4
        lower = 1-mixed_tail(n, r, low)
        low_chernoff = (ball(low)+n*ball(1-r/3).log()).exp()
        assert 0 < lower < low_chernoff < (-ball(nr/12)).exp()
        checks.append({
            "n": n, "r": str(r), "deviation_u": str(u), "right_chernoff_parameter": str(theta),
            "true_mixture_upper_tail": interval(upper), "right_chernoff": interval(up_chernoff),
            "right_bernstein": interval(up_bernstein),
            "true_mixture_lower_tail_at_nr_over_4": interval(lower),
            "left_chernoff_parameter_1": interval(low_chernoff),
        })
    return checks


def deterministic_scales():
    results = []
    for n, r in ((16, F(1)), (256, F(1, 16)), (1024, F(1, 2**30)),
                 (2**24, F(1, 2**48)), (2**60, F(1, 2**90))):
        L = arb(n).log()
        x = F(1, n)
        lmean = ball(r/2*(1-x*x))
        independent_integral = (
            ball(2*r)*(ball(F(1, 4)) - ball(x*x)*(ball(F(1, 4))+L/2))
            + ball(r*x*x)*L
        )
        assert lmean.overlaps(independent_integral)
        clipping_tail = ball(r*x*x)
        maximum_upper = ball(r/n)
        # log1p/expm1 preserve the tiny scales in this expression.
        maximum_actual = -((-clipping_tail).log1p()*n).expm1()
        assert 0 < maximum_actual < maximum_upper
        bernstein = []
        for rho in (F(1, 4), F(1), F(2)):
            theta = ball(rho)/L
            power = 2-theta
            truncated_mgf = (1-ball(r)) + 2*ball(r)*(-( -L*power).expm1())/power + ball(r)*(-L*power).exp()
            centered = (truncated_mgf-1).log1p()-theta*lmean
            upper = ball(r/2)*theta**2/(2*(1-theta*L/3))
            assert 0 < theta*L < 3 and centered < upper
            bernstein.append({"theta_times_log_n": str(rho), "centered_log_mgf": interval(centered),
                              "bernstein_upper": interval(upper)})
        results.append({
            "n": n, "r": str(r), "clipped_mean": interval(lmean),
            "probability_any_truncation_independent": interval(maximum_actual),
            "r_over_n": interval(maximum_upper),
            "bounded_bernstein_checks": bernstein,
        })
    return results



def exact_radial_tail(n, r, w, shift, x):
    # x=e^{-t}. At x=1/n it is the left-limit tail at the clipping level.
    c = r*w
    threshold = 1+r-2*r*x-shift
    if threshold <= 0:
        return F(1)
    clipped = max(F(0), min(F(1), c+threshold)-max(F(-1), c-threshold))
    tail = 1-clipped/2
    independent = (max(F(0), min(2, 1+c-threshold))
                   +max(F(0), min(2, 1-c-threshold)))/2
    assert tail == independent
    return tail


def spline_knots(n, r, w, shift):
    c = abs(r*w)
    return {
        x for x in (F(1,n), F(1), *((1+r-shift-y)/(2*r) for y in (0, 1-c, 1+c)))
        if F(1,n) <= x <= 1
    }


def clipped_tail_integral(n, r, w, shift, cuts):
    value = arb(0)
    for l, h in zip(cuts, cuts[1:]):
        f_l, f_h = (exact_radial_tail(n,r,w,shift,x) for x in (l,h))
        a = (f_h-f_l)/(h-l)
        b = f_l-a*l
        assert exact_radial_tail(n,r,w,shift,(l+h)/2) == a*(l+h)/2+b
        value += ball(a*(h-l)) + ball(b)*ball(h/l).log()
    return value


def close_dyadic(delta):
    r = F(1)
    while ball(r) > delta:
        r /= 2
    assert ball(r) < delta < ball(2*r)
    return r


def bin_perturbation():
    report = []
    inspected_segments = 0
    ratio_geometry_checks = 0
    for n in (16,64,256,1024,2**20,2**40,2**60):
        logn = arb(n).log()
        delta = (logn/n).sqrt()/64
        dyadic = close_dyadic(delta)
        ratio_ceiling = (arb(2).log()/n).exp()
        assert ball(1+F(1,2*n)) < ratio_ceiling < ball(1+F(1,n))
        allowance = F(8,n)
        inspected = 0
        exact_point_checks = 0
        selective = []
        for r in sorted({dyadic,2*dyadic,F(1,16),F(1,2),F(1)}):
            for w in (F(-1), -1+F(1,n), F(0), 1-F(1,n), F(1)):
                shifts = (-allowance,F(0),allowance)
                cuts = sorted(set.union(*(spline_knots(n,r,w,shift) for shift in shifts)))
                assert cuts[0] == F(1,n) and cuts[-1] == 1
                for x in cuts:
                    lo, orig, hi = (exact_radial_tail(n,r,w,shift,x) for shift in shifts)
                    a = (1+w)/2
                    assert orig == conditional_tail(r,a,x)
                    assert 0 <= lo <= orig <= hi <= 1
                    assert orig-lo <= allowance and hi-orig <= allowance
                    assert hi <= r*x+allowance <= 2*r*x+allowance
                    exact_point_checks += 1
                values = [clipped_tail_integral(n,r,w,shift,cuts) for shift in shifts]
                base = entropy_mean(r,w)
                clipping_penalty = ball(r/n)
                error_bound = ball(allowance)*logn+clipping_penalty
                assert all(abs(value-base)<error_bound for value in values)
                assert all(abs(value-values[1])<ball(allowance)*logn for value in values)
                if (r in (dyadic,F(1)) and w in (F(0),F(1))):
                    selective.append({
                        "r0":str(r), "w":str(w),
                        "knots_u":list(map(str,cuts)),
                        "negative_zero_positive_shift_clipped_means": list(map(interval,values)),
                        "unperturbed_unclipped_mean":interval(base),
                        "error_allowance":interval(error_bound),
                    })
                for u in (F(-1),F(-3,4),F(0),F(3,4),F(1)):
                    r_true = min(F(1),r*(1+F(1,2*n)))
                    old_dist = abs(u-r*w)
                    D = abs(u-r_true*w)
                    corrected = 1 + (r/r_true)*(D-1)
                    true_fraction = min(F(1),max(F(0),(1+r_true-D)/(2*r_true)))
                    reconstructed = min(F(1),max(F(0),(1+r-corrected)/(2*r)))
                    assert reconstructed == true_fraction
                    assert abs(corrected-old_dist) <= F(2,n) < allowance
                    ratio_geometry_checks+=1
                inspected_segments += 3*(len(cuts)-1)
                inspected += 1
        report.append({
            "n":n, "delta_n":interval(delta), "nearest_dyadic_below_delta":str(dyadic),
            "nearest_dyadic_above_delta":str(2*dyadic), "volume_bin_ratio_ceiling":interval(ratio_ceiling),
            "r0_w_pairs":inspected, "exact_knots_compared":exact_point_checks,
            "selected_interval_brackets":selective,
        })
    return {
        "n_cases":len(report),
        "affine_tail_segments_integrated":inspected_segments,
        "exact_radius_reparameterization_probes":ratio_geometry_checks,
        "conclusion":"0 <= t < log(n): perturbed tail <= r0*exp(-t)+8/n; mean error <= 8*log(n)/n+r0/n",
        "scope":"Samples at u=1/n check the one-sided limiting tail; the event X>log(n) itself is empty.",
        "per_dimension":report,
    }


def normalized_low_price():
    n, r = 4, F(1,256)
    a = 32*n
    G, K = F(2), F(1)
    large_center = (F(0),)*n
    small_center = (F(1),F(0),F(0),F(0))
    large = box(large_center,F(1))
    small = box(small_center,r)
    large_owner, small_owner = box(large_center,F(1,a)),box(small_center,r/a)
    assert intersection(large_owner,small_owner)==0
    A = box(large_center,F(2))
    overlap = Box(((1-r,F(1)),*((-r,r) for _ in range(n-1))))
    excess_patch = box((1+r/2,F(0),F(0),F(0)),r/4)
    assert not intersection(excess_patch,large)
    assert intersection(excess_patch,small) == excess_patch.volume
    d_L,d_s = large.volume, small.volume
    v_L,v_s = large_owner.volume,small_owner.volume
    I = intersection(large,small)
    assert I == overlap.volume and I/d_s==F(1,2)
    assert ball(r) < (arb(n).log()/n).sqrt()/64
    out = []
    for multiple in (F(64),F(4),F(3)):
        extra = ((multiple-1)*d_s-3*I)/excess_patch.volume
        assert extra >= 0
        price = ((A,F(1)),(overlap,F(3)),(excess_patch,extra))
        m_L = exact_sum(w*intersection(large,region) for region,w in price)
        m_s = exact_sum(w*intersection(small,region) for region,w in price)
        shared = exact_sum(w*intersection(large,small,region) for region,w in price)
        assert m_L >= d_L and m_s==multiple*d_s>d_s and shared==4*I
        p,q = shared/m_s,I/d_s
        beta_L = K*v_L/(G*m_L)
        beta_s = F(7,8)*K*v_s/(G*m_s)
        assert beta_L+beta_s<1 and beta_L*m_L==K*v_L/G and beta_s*m_s<=K*v_s/G
        big_to_small = beta_L*v_s*shared/m_s
        small_to_big = beta_s*v_L*shared/m_L
        budget = (K/G)*(v_s/d_s)*(v_L/d_L)*I
        assert small_to_big == F(7,8)*big_to_small > 0
        assert small_to_big == (beta_s*m_s)*(v_L/m_L)*p
        assert shared/d_s > q
        if p<=q:
            assert big_to_small<=budget and small_to_big<=budget
        else:
            assert big_to_small>budget and small_to_big>budget
        out.append({
            "m_small_divided_by_d_small":str(multiple), "m_big_divided_by_d_big":str(m_L/d_L),
            "absolute_shared_price_density":str(shared/I),
            "p_true":str(p), "q":str(q), "wrong_price_normalized_by_d_small":str(shared/d_s),
            "p_at_most_q":p<=q, "forward_original_flow":str(big_to_small),
            "reverse_original_flow":str(small_to_big),
            "target_volume_based_budget":str(budget),
            "forward_divided_by_target":str(big_to_small/budget),
            "reverse_divided_by_target":str(small_to_big/budget),
        })
    return {
        "dimension":n, "r":str(r), "source_cap_K":str(K), "source_cap_G":str(G),
        "full_original_shrunk_owners":True, "price_is_absolutely_continuous":True,
        "fixtures":out,
    }


def cascading_group_example():
    # These are exact abstract incidences on labeled price cells, not a simulated continuous geometry.
    edges = (
      ("s0","t0","z0",F(1)),
      ("s0","t1","z0",F(3,4)),
      ("s0","t1","z1",F(3,2)),
      ("s1","t1","z0",F(3)),
      ("s2","t1","z1",F(3,4)),
      ("s2","t1","z2",F(3,2)),
      ("s2","t2","z1",F(3)),
    )
    group = {}
    threshold = {}
    for i,(s,t,z,_) in enumerate(edges):
        keys = (("pair",s,t),("local_source",s,z,"target_scale2"),("local_target",t,z,"source_scale1"))
        for key in keys:
            group.setdefault(key,set()).add(i)
            threshold[key] = F(2) if key[0]=="pair" else F(3,2)
    initial = frozenset(range(len(edges)))
    def mass(state):
        return exact_sum(edges[i][3] for i in state)
    def active_low(state):
        return sorted((g, state & ids) for g,ids in group.items()
                      if 0 < mass(state & ids) < threshold[g])
    state = initial
    all_triggers, expense = set(), F(0)
    sequence = []
    while low := active_low(state):
        removed = frozenset().union(*(items for _,items in low))
        marks = []
        unmatched = set(removed)
        for g,items in low:
            assert g not in all_triggers
            all_triggers.add(g)
            billed = items & unmatched
            unmatched -= billed
            assert mass(billed) <= mass(items) < threshold[g]
            marks.append({"group":list(g), "positive_load":str(mass(items)), "charged":str(mass(billed))})
        assert not unmatched
        after = state-removed
        assert mass(state)-mass(after) == mass(removed)
        expense += mass(removed)
        sequence.append({"removed_edges":sorted(removed), "trigger_groups":marks,
                         "mass_before":str(mass(state)), "mass_after":str(mass(after))})
        state = after
    assert expense == mass(initial)-mass(state) == F(11,2)
    assert state == {3,6} and len(sequence)==5
    stack = [initial]
    visited, terminals = set(), set()
    while stack:
        start = stack.pop()
        if start in visited:
            continue
        visited.add(start)
        moves = active_low(start)
        if not moves:
            terminals.add(start)
        stack.extend(start-items for _,items in moves)
    assert terminals == {state}
    for cardinality in range(len(edges)+1):
        for selected in combinations(initial,cardinality):
            subset = frozenset(selected)
            if not active_low(subset):
                assert subset <= state
    return {
        "scope":"pure finite graph accounting with rational actual-cell weights; no continuous geometry claim",
        "edges":[[s,t,z,str(v)] for s,t,z,v in edges],
        "pair_cut":"2","local_price_scale_group_cut":"3/2",
        "rounds":sequence,"all_sequential_legal_orders_terminal_states":len(terminals),
        "all_subsets_checked_for_greatest_stable_core":2**len(edges),
        "fixed_point_edges":sorted(state),"fixed_point_mass":str(mass(state)),
        "actual_telescoping_paid_mass":str(expense),
    }


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    return {
        "schema": "r752-entropy-bin-robustness-verification-v1",
        "runtime": {
            "python": platform.python_version(), "python_flint": flint.__version__,
            "python_executable": sys.executable, "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable, "-B", script.name, "--out", "verify.json"],
            "rerun_command": [sys.executable, "-B", script.name, "--check", "verify.json"],
        },
        "scalar_reference_geometry": scalar_geometry(),
        "actual_complete_small_scale_bin": full_owned_bin(),
        "actual_two_blob_price_pressure": [
            diagonal_price_case(n, r) for n, r in ((16, F(1, 16)), (64, F(1, 2)), (256, F(1, 16)))
        ],
        "shared_W_ideal_reference_pressure": coincident_w_reference(),
        "axis_face_exclusion": excluded_faces(),
        "conditional_fixed_W_mgf_checks": conditional_bounds(),
        "independent_unclipped_mixture_chernoff": product_tails(),
        "independent_truncation_and_bernstein_scalar_only": deterministic_scales(),
        "dyadic_radial_perturbation": bin_perturbation(),
        "normalized_low_price_two_directions": normalized_low_price(),
        "finite_synchronous_group_pruning": cascading_group_example(),
        "scope": [
            "U and W in the scalar law are independently uniform. The tensor product tails require independence of the coordinate pairs.",
            "Sharing a random W retains each marginal law and changes joint truncation probabilities.",
            "The actual prices in the diagonal example are absolutely continuous mixtures of two tiny interior cubes. Their owners are genuinely disjoint and their price is optimal for the two parents.",
            "Upper conditional mgf uses theta in [0,1); upper unconditional mgf uses theta in [0,2); bounded Bernstein uses theta*log(n) in [0,3). The pointwise face screening does not require independence.",
            "Dimensions above 1024 in scalar tables are not explicit high-dimensional geometry. No Monte Carlo is used.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--out", type=Path)
    target.add_argument("--check", type=Path)
    args = parser.parse_args()
    result = json.dumps(report(), indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(result, encoding="utf-8")
        print(f"wrote {args.out} ({len(result)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != result:
            raise SystemExit("rerun differs from saved output")
        print(f"identical rerun of {args.check} ({len(result)} bytes)")


if __name__ == "__main__":
    main()
