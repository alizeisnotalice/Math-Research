from fractions import Fraction as F
from itertools import product

# Uniform full source on a sufficiently large finite box; selected child radius r.
# Exact 1D overlap antiderivative. Tensorization below is a calculation in this
# chosen uniform native model, not an independence assumption on general f.
def overlap(x,R,r):
    L=(R+r)/2; p=(R-r)/2
    return max(F(0),min(r,L-abs(x)))
def primitive(x,R,r):
    L=(R+r)/2; p=(R-r)/2
    total=F(0)
    for lo,hi,slope,intercept in ((-L,-p,F(1),L),(-p,p,F(0),r),(p,L,F(-1),L)):
        end=min(x,hi)
        if end>lo:
            total+=slope*(end*end-lo*lo)/2+intercept*(end-lo)
    return total
def joint(R,r,alpha):
    L=(R+r)/2; p=(R-r)/2; d=alpha*r/2
    points=sorted(set([-L,L,-p,p]+[v+sgn*d for v in (-L,-p,p,L) for sgn in (-1,1)]))
    points=sorted(set([-L,L]+[x for x in points if -L<x<L]))
    def integrand(t):
        return overlap(t,R,r)*(primitive(t+d,R,r)-primitive(t-d,R,r))
    return sum(((b-a)*(integrand(a)+4*integrand((a+b)/2)+integrand(b))/6
                for a,b in zip(points,points[1:])),F(0))

n1=0
for r,alpha in product((F(1),F(5,4),F(3,2)),(F(1),F(5,4),F(3,2))):
    R=F(2); J=joint(R,r,alpha)
    # First exact cancellation bound before strict-mass restriction:
    # integral I(t) int_{w in alpha Qt}I(w)dw <= alpha r^2 * int I(t)dt.
    assert 0<J<=alpha*R*r**3
    n1+=1
print('Stage 1 PASS:',n1,'native 1D polynomial center integrals')

n2=0
for n,r,alpha in product((4,9,16,64),(F(1),F(5,4),F(3,2)),(F(1),F(5,4),F(3,2))):
    root={4:2,9:3,16:4,64:8}[n]; R=F(2); K=F(3)**root
    if (R/r)**n<=K:
        continue
    # e^sqrt(n)<3^sqrt(n)=K; the test uses an even stronger strict-mass cutoff.
    M=(joint(R,r,alpha)/(R**2*r**2))**n
    assert M<=alpha**n/K
    n2+=1
print('Stage 2 PASS:',n2,'tensor native matched center moments, n through 64')

n3=0
for n in (64,81,100):
    R=F(2); r=F(3,2); root={64:8,81:9,100:10}[n]
    assert (R/r)**n>F(3)**root
    # Native positive-volume center blocks around (1.1,+/-0.2,0,...).
    center1=F(11,10); csep=F(2,5)
    halfblock=r/(32*n)
    y1=center1-r/2+r/(8*n)
    # The source is in the small cube but outside its prescribed alpha-inner cube.
    collar_ratio=1-F(5,16*n)
    assert collar_ratio**(2*n)>F(1,n+2)
    assert center1-halfblock>R/2
    assert abs(center1-y1)+halfblock<r/2
    assert (abs(center1-y1)-halfblock)/(r/2)==collar_ratio
    assert csep+2*halfblock<r/2 # both centers inside the other's unexpanded cube
    # y2=-.9, z2=.9: each initial child captures one and excludes the other.
    assert F(7,10)+halfblock<r/2
    assert F(11,10)-halfblock>r/2
    assert abs(y1)<R/2 and F(9,10)<R/2
    assert F(9,5)>F(1) # source infinity-distance exceeds the R404 near radius
    n3+=1
print('Stage 3 PASS:',n3,'positive native center-block geometry certificates')
print('Scope: stages 1-2 are exact actual-du uniform-f conditional moments; stage 3 certifies matched strict-far/exclusive/collar/outside/sibling inclusion geometry only, NOT own-past, dynamic D, original clock/history or a full R414 instance.')
