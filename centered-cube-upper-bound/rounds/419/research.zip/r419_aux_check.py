from fractions import Fraction as F
from itertools import product
from math import isqrt

def box(center,side): return tuple((x-side/2,x+side/2) for x in center)
def relation(source,centers,R):
    inside=all(lo>=b-R/2 and hi<=a+R/2 for (lo,hi),(a,b) in zip(source,centers))
    outside=any(hi<=a-R/2 or lo>=b+R/2 for (lo,hi),(a,b) in zip(source,centers))
    assert inside or outside, 'nonconstant incidence'
    return int(inside)
def volume(B):
    out=F(1)
    for a,b in B: out*=b-a
    return out
def positive(x): return max(F(0),x)
def band_area(U,V,r):
    a,b=U;c,d=V
    def cdf(t):
        return (positive(t-a+d)**2-positive(t-b+d)**2-positive(t-a+c)**2+positive(t-b+c)**2)/2
    return cdf(r)-cdf(-r)
def pair_volume(U,V,r):
    out=F(1)
    for I,J in zip(U,V):out*=band_area(I,J,r)
    return out

def model(n,Rt,qw,qt,l,overlap,alpha,outer=False):
    M=F(2**n); mw=qw; mt=qt*Rt**n
    k=isqrt(n)+(isqrt(n)**2<n); K=F(3**k) # e^sqrt(n)<3^ceil sqrt(n)
    assert M>K*max(mw,mt)
    wc=(F(-3,10),)+(F(0),)*(n-1)
    tc=(F(1,2) if outer else F(3,10),)+(F(0),)*(n-1)
    groups=[(box(wc,l),F(1)),(box(tc,F(1,16) if outer else l),Rt)]
    parent=box((F(0),)*n,F(1,32)); Rp=F(2)
    outmass=mt/4 if outer else F(0)
    common=overlap*min(mw,mt-outmass)
    source=[]
    def add(c,side,mass):
        if mass:source.append((box(c,side),mass))
    add((F(0),)*n,F(1,16),common)
    add((F(-5,8),)+(F(0),)*(n-1),F(1,16),mw-common)
    add((F(5,8),)+(F(0),)*(n-1),F(1,16),mt-outmass-common)
    add((F(7,8),)*n,F(1,16),M-(mw+mt-outmass-common))
    if outer:add((F(17,16),)+(F(0),)*(n-1),F(1,128),outmass)
    # Full f is source mass / box volume on disjoint boxes, zero elsewhere.
    assert all(mass>0 for _,mass in source)
    def mass(B,R):return sum(m*relation(C,B,R) for C,m in source)
    assert mass(parent,Rp)==M
    ms=[mass(B,R) for B,R in groups]
    assert ms==[mw,mt]
    qminus=min(F(1),qw,qt)
    assert F(3,4)<=qminus and max(qw,qt)<=1
    Is=[sum(m*relation(C,parent,Rp)*relation(C,B,R) for C,m in source) for B,R in groups]
    direct=reverse=both=union=F(0)
    for i,(U,Ru) in enumerate(groups):
        for j,(V,Rv) in enumerate(groups):
            factor=Is[i]*Is[j]/(M*M*ms[i]*ms[j])
            direct+=factor*pair_volume(U,V,alpha*Rv/2)
            reverse+=factor*pair_volume(U,V,alpha*Ru/2)
            both+=factor*pair_volume(U,V,alpha*min(Ru,Rv)/2)
            union+=factor*pair_volume(U,V,alpha*max(Ru,Rv)/2)
    cap=alpha**n/(K*qminus*qminus)
    assert direct<=cap and reverse<=cap
    assert union==direct+reverse-both
    assert 0<=both<=min(direct,reverse) and union<=2*cap
    # Independent elementary per-pair integration cancellation when QA includes all captured sources.
    if not outer:
        plain=sum(pair_volume(U,V,alpha*Rv/2) for U,Ru in groups for V,Rv in groups)/(M*M)
        assert plain==direct
    else:
        assert Is[1]<ms[1] and Is[0]==ms[0]
    return int(direct>0),int(both<min(direct,reverse)),int(outer)

counts={}; features=[0,0,0]
configs=[('initial',[(4,F(1),F(1),F(1),l,c,a,False) for l,c,a in product([F(1,8),F(1,4)],[F(0),F(1,2)],[F(1),F(5,4)])]),
 ('overlap_mass',[(9,F(5,4),qw,F(1),F(1,4),c,a,False) for qw,c,a in product([F(3,4),F(1)],[F(0),F(1,2),F(1)],[F(1),F(5,4),F(3,2)])]),
 ('expanded_outer',[(n,F(5,4),F(3,4),F(1),F(1,8),c,a,True) for n,c,a in product([9,16],[F(0),F(1,2),F(1)],[F(1),F(5,4),F(3,2)])])]
for name,rows in configs:
    for row in rows:
        ff=model(*row)
        features=[x+y for x,y in zip(features,ff)]
    counts[name]=len(rows)
print('PASS',counts,'total',sum(counts.values()))
print('features positive_direct, strict_union_subtraction, outside_parent_source:',features)
print('Exact Fraction full L1 source boxes and Lebesgue center blocks; q in [3/4,1], octave R in [1,2], native far certified by e<3. Original R414 stage/rank/history not simulated.')
