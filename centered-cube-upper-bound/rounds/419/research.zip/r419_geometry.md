# R419：两个真实小质量见证的互中心包含预算

2026-10-20。本轮取得一个新的原积分正分支预算：在原 R414 同一个双 exclusive 提升上，支付至少一个见证中心落入另一个见证的扩张立方体的事件。该分支允许两中心都在原父盒外。一般目标及其补集仍未闭合。

## 1. 准确几何定理：匹配先消一份质量，再积分真实中心

固定实际父 A，m_A=f(Q_A)>0。完整 f≥0 属于 L1，所有实际见证 w,t 都使用真实 Lebesgue 中心 dw,dt 和其选定边长，m_v=f(Q_v)=q_vR_v^n，q_v≥q_->0。记 μ(dv)=dv/m_v、π_A=f1_QA/m_A。只取
\[
\mathcal E_A=\{v\in E:m_v<m_A/K\},\qquad K>1.
\]
对任意扩张系数 α_sib≥1，α_sib Q_t 表示以 t 为中心、边长 α_sib R_t 的盒。定义未归一矩
\[
\mathcal M_A^{\to}(\alpha_{\rm sib})
 =\int\pi_A(dy)\pi_A(dz)
   \int_{\mathcal E_A^2}c_w(y)c_t(z)
            1_{w\in\alpha_{\rm sib}Q_t}\mu(dw)\mu(dt).
\]
则对任意可测实际选择器、任意完整 f，
\[
\boxed{\mathcal M_A^{\to}(\alpha_{\rm sib})
       \le\frac{\alpha_{\rm sib}^n}{Kq_-^2}.}             \tag{1}
\]
交换 w,t 得到另一个方向；故 whole union 矩≤2α_sib^n/(Kq_-²)。双 exclusive 因子或任何其他正门只减小这些上界。

证明。记 I_Av=f(Q_A∩Q_v)。Tonelli 首先给出精确式
\[
\mathcal M_A^{\to}
 =\frac1{m_A^2}\int_{\mathcal E_A}\frac{I_{At}}{m_t}dt
     \int_{\mathcal E_A\cap\alpha_{\rm sib}Q_t}
                         \frac{I_{Aw}}{m_w}dw.
\]
用完整 matching 的 I_Aw≤m_w，内层真正的中心积分≤|α_sib Q_t|=α_sib^nR_t^n。因此
\[
\mathcal M_A^{\to}
 \le\frac{\alpha_{\rm sib}^n}{m_A^2}
            \int_{\mathcal E_A}\frac{I_{At}}{q_t}dt
 \le\frac{\alpha_{\rm sib}^n}{q_-m_A^2}
            \int_{\mathcal E_A}I_{At}dt.                 \tag{2}
\]
令 r_*=(m_A/(Kq_-))^(1/n)。严格小质量和实际 q_t≥q_- 同时给 R_t<r_*。于是对固定 z，捕获 z 的可行真实 t 中心均在以 z 为中心、边长 r_* 的盒中，不论其选择器边长如何变化。因此
\[
\begin{aligned}
\int_{\mathcal E_A}I_{At}dt
 &=\int f(z)c_A(z)\int_{\mathcal E_A}c_t(z)dt\,dz\\
 &\le m_A r_*^n=\frac{m_A^2}{Kq_-}.                     \tag{3}
\end{aligned}
\]
将 (3) 代入 (2) 证得 (1)。若原 octave 下 r_*≤a，则 E_A 为空，实际矩为零。所有质量原子仍按严格门排除。

这里没有把任意来源质量按薄边界体积控制，也没有将 R_t 当独立积分变量；(2) 消掉的是实际 f(Q_w) 分母，(3) 控制的是实际 dt。没有引入不存在的接收者；将 E 的子集上积分放大到中心盒体积仅为正上界。扩张只用于事件，不修改任何 Q_t、m_t、q_t 或历史。

## 2. 回到原双 exclusive lift，保留全部原标签

取原 R414 的同一费用空间：旧来源 y、新来源 z、父端 A=u 或 v、阶段 i、b_i、early/首次删除、原 physical clock/history、所有 relative/current-high/重尾门、初始双 outside/own-high/collar，以及后续固定来源路径和终端门全部保持。初始见证核仍是
\[
Q_y(dw)=\frac{c_w(y)(1-c_w(z))1_{\mathcal E_A}(w)}{Z_A(y)-C_A(y,z)}\mu(dw),
\quad
Q_z(dt)=\frac{c_t(z)(1-c_t(y))1_{\mathcal E_A}(t)}{Z_A(z)-C_A(y,z)}\mu(dt).
\]
soft 为 ψ_A=(1−C_A/h)_+，没有重复使用负捕获信用。

定义实际事件
\[
\mathsf S_\alpha
 =\{w\in\alpha_{\rm sib}Q_t\ \text{或}\ t\in\alpha_{\rm sib}Q_w\}.
\]
本轮只分 R414=P_sib(α_sib)+R419(α_sib)，其中两项为同一实际测度的事件及补事件限制，均不重新归一化。

核算原分母。若 C<h、Z_y>ah、Z_z>bh，且 1/a+1/b≤1，则
\[
\frac{(1-C/h)}{(Z_y-C)(Z_z-C)}
 \le\frac1{Z_yZ_z}\le\frac1{ab h^2}.                    \tag{4}
\]
第一不等式等价于 Z_yZ_z/h≥Z_y+Z_z−C，保持所有正分母。大端原输入可取 a=2,b=L；小端可取 a=2−ε_0,b=L−ε_0。对 L≥4、ε_0≤1/2，后者也满足1/a+1/b≤2/3+2/7<1。

原逐旧来源大端上界 β、小端上界 C_col，结合 (4) 得到冻结的
\[
B_L=\frac\beta{2L}
   +\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}.
\]
只在正上界中删除其余门，保留完整父 π_A(dy)π_A(dz)；同一个 A,z 上先用 Σ_i b_i(z)≤1。固定原场的见证核不随阶段重算，后续路径概率及正限制≤1。因此 (1) 的 union 版本给
\[
\boxed{P_{\rm sib}(\alpha_{\rm sib})
 \le\Delta_{419}(\alpha_{\rm sib})X_q,\qquad
\Delta_{419}(\alpha_{\rm sib})
 =\frac{2\alpha_{\rm sib}^n B_L}{Kq_-^2h^2}.}            \tag{5}
\]
这里没有额外 λ/q_- 或 τ^(-1)：使用的是原逐旧来源 β/C_col，而不是先经高 stage 后验包络放大。whole union 可重复估其交集，但实际费用只删除一次。

## 3. 主选择与单占用层价格

不修改 K=e^(√n)，选择
\[
\alpha_{\rm sib}=K^{1/n}=e^{1/\sqrt n}.
\]
于是扩大后的同一几何事件仍有
\[
\boxed{\Delta_{419}
 =\frac{2B_L}{q_-^2h^2}
 =\frac{2\varepsilon_0^2B_L}{(1+\sqrt n)^2}.}             \tag{6}
\]
这给显式 O(1/n) 的 X_q 价格，前提是冻结的 B_L、ε_0 维度一致。未宣称全部旧 X 余额已经吸收。也可保留 α_sib=e^{c/√n} 的一般价格2ε_0²B_L e^{−(1−c)√n}/s²，但主选择取 c=1，不为较小系数而保留较弱事件。

对原实际占用层 2^k s<D_i(z)≤2^(k+1)s，令 P_sib,k 为其中的同一正支。层标签不改变 (5)。更重要的是
\[
\sum_kP_{\rm sib,k}\le\Delta_{419}X_q,                  \tag{7}
\]
是所有占用层合计一次收费，不能把 (5) 当每层独立新增的价格。整个 R414_k 的 P 型预算仍未证明。

完整补集 R419 保留 R414 的全部源、时钟、历史、删除和路径标签，并增加
\[
w\notin\alpha_{\rm sib}Q_t,\qquad
 t\notin\alpha_{\rm sib}Q_w.                             \tag{8}
\]
初始双方仍在父 Q_A 外，终端双方仍在父外。本轮付款是两个初始真实见证之间的中心关系，区别于 R411 的“初始见证中心进入父盒”和 R412 的“终端中心返回父盒”。没有宣称去掉固定正比例，也没有将 (8) 自动当作新的历史资格。

## 4. 原账回代：只新增一笔 X 价格

保持 Fhat=(1−32δ−16η)^(-1) 及 C413、V413 所有旧分支。主选择 (6) 下
\[
G_0\le16\widehat F\{R419+(C413+\Delta_{419})X_q+V413W\},
\]
\[
B_H\le32\widehat F R419+
 [E387+32\widehat F(C413+\Delta_{419})]X_q
 +[S390+8s+32\widehat F V413]W.
\]
原入口仅将 R414 换成 R419，并新增64ΛFhat Δ419 X_q。原 A_entrance,n、H、外部 E387/S390 及所有来源价均不变；无新增 W 价，无旧收据退款。原低维完整 core 路线不与此高维账混加。

## 5. 非空范围与本机精确检查

一般证明适用于原 R414 的任何正限制，不要求构造完整原历史实例。为检验该事件不是被已有几何条件排除，脚本给出真实正体积中心块模型：n=64、81、100，完整 f=1_{[-4,4]^n}，父边长2，初始两见证边长3/2，中心块分别围绕(1.1,−0.2,0,…)、(1.1,0.2,0,…)。中心块半宽为 r/(32n)，父中心可在0附近小块内变化；完整匹配 q=1。

取 y,z 的第二坐标分别−0.9、0.9，第一坐标同为1.1−r/2+r/(8n)，其余为0。两见证中心都在父外、彼此位于对方未扩张盒内，各自捕获一来源并排斥另一来源；两来源在各自实际 child collar 中，且满足原来源远域的两个距离下界。这些严格条件可同时对来源点的小邻域成立。质量比(4/3)^n>3^(√n)>e^(√n)，所以原 K 的严格小质量门成立。该例说明“父外”并不排除互中心包含，不将其作为完整 R414 非空证明：没有认证 own-past、原 Γ/current-D、重尾、完整历史或终端门，后者仍须来自原输入。

实际执行 `/tmp/r419_geometry_check.py`：

- 阶段1：9个一维 native 中心双积分，用 overlap 梯形的分段多项式精确积分；
- 阶段2：27个 tensor native uniform-f 条件矩，维数至64，检验 (1)，并用 e<3 的安全严格 far 证书；
- 阶段3：3个上述正体积中心块几何证书，维数64、81、100。

全部使用 Fraction，共39项通过。阶段1–2是所选均匀完整来源模型的真实中心积分；张量计算仅在这些明确乘积模型使用，不把任意 π_A 当独立坐标。阶段3只认证所列几何/匹配条件，不认证完整原历史流。一般收费结论依靠 (1)–(5) 的解析证明，而不是有限样本比例。

本轮取得 (5) 的真实全阶段正分支预算；补集 (8) 及整个层一致 P 仍未支付。到此停止。
