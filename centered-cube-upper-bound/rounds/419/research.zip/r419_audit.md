# R419 independent audit — frozen

FINAL PASS for the stated native joint-center capacity and its once-only positive-branch payment on original R414. Independent derivation preceded R419 author reading. Final main/README, both proofs and scripts reviewed; both scripts independently rerun with delivered stdout byte-identical. Price is Δ419=2ε0² B_L/s², with no extra S, τ^-1 or λ/q_-; entrance increment64ΛFhatΔ419 X_q. No general root bound, P, fixed covered fraction or complete-history nonempty fixture is certified. Only this audit file edited.

## Independent native moment proof

Fix a true parent with0<m_A<∞ and actual witness field m_v=f(Q_v)=q_vR_v^n>0, q_v≥q_->0. Put I_Av=f(Q_A∩Q_v), and retain both strict m_w,m_t<m_A/K gates. Positive Tonelli, using the SAME full f, gives

M_A^α=m_A^-2 ∫_{far t}(I_At/m_t)dt ∫_{far w,w∈αQ_t}(I_Aw/m_w)dw.

Since I_Aw≤m_w, the inner integral is≤|αQ_t|=α^n m_t/q_t. Thus M_A^α≤α^n/(q_-m_A²)∫_{far t}I_At dt. Strict far and matching give R_t<r_*=(m_A/(Kq_-))^(1/n). For a fixed source z, capturing centers t lie in the box centered at z of side r_*, whose volume is m_A/(Kq_-). A second positive Tonelli exchange therefore gives

∫_{far t}I_At dt=∫_{Q_A}f(z)|{t:far,c_t(z)=1}|dz≤m_A²/(Kq_-),
M_A^α≤α^n/(Kq_-²).

The first volume bound concerns actual w CENTERS after cancelling their actual source-mass denominator; the second concerns actual t CENTERS after a selected-side upper bound. No arbitrary f mass is bounded by boundary volume; no independence of source coordinates or selector side is used. In fact the inner w-far gate need not be used for that upper bound. All events are measurable for measurable selected cubes; positive truncation/Tonelli handles possible initially infinite intermediate integrals, and the bound proves finiteness. Zero parent mass has zero original cost; zero witness masses are outside the valid matched field. Strict mass atoms at m_A/K stay excluded. Under the octave, r_*≤a makes the far family empty, including equality.

For α≥1 the reverse event has the same bound after swapping w,t. The actual OR is at most their sum,2α^n/(Kq_-²); its intersection is not charged twice in the actual split. Closed center-box boundaries are included consistently in the paid event. This uses Lebesgue center measure, not an arbitrary weighted finite incidence measure. The inequality has the correct q^-2/source-mass homogeneity and no upper-q input is needed in this lemma.

## Exact current-lift interface and constant

Reviewed r411_aux, r411_main, r413_main and r414_main for the current contract. On C_A<h the original Q_y⊗Q_z is a probability lift of the original two-source cost. It retains initial w,t through all later relative/current/early/cubic-density and terminal restrictions. For the event N_α={w∈αQ_t or t∈αQ_w}, define its raw exclusive numerator U_A^α by integrating the SAME μ(dw)μ(dt), both far gates and the two capture/exclusion indicators. This numerator depends only on frozen A,y,z,w,t, not on a rebuilt stage flow. Dropping the two exclusions and other positive restrictions bounds its π_A² average by the raw OR moment above.

The retained soft is used once. On external rank support Z_y>2h,Z_z>Lh it obeys ψ/[(Z_y−C)(Z_z−C)]≤1/(2Lh²). On the small-end support use (2−ε0,L−ε0). The inequality follows from

(A−c)(B−c)−AB(1−c)=c(AB−A−B)+c²≥0,

with c=C/h∈[0,1), A+B≤AB. The frozen L≥4, ε0≤1/2 meet this condition, including the smallest small-end constants. All denominators are positive on the actual soft support; no paths outside that support are invented.

Apply the original joint early/first-deletion stage inequality in r411_aux(5) on common old-edge/new-z labels, then use the original sourcewise outgoing β / incoming C_col caps. Additional R414 conditions and later conditional path probabilities are dropped only for a positive upper bound. Their total probability mass is≤1, so this step does not require filtered posterior independence or its τ^-1 domination. The same-z Σ_i b_i(z)≤1 is used once. Consequently

P419(α)≤(B_L/h²)∫σ(dA)E_{π_A²}U_A^α
≤[2α^n B_L/(Kq_-²h²)]X_q,
B_L=β/(2L)+C_col/[(2−ε0)(L−ε0)].

B_L ALREADY contains both endpoint caps. Multiplying it again by S would be unnecessary; multiplying by τ^-1 would use a weaker unrelated projection. No λ/q_- is lost in the native lemma. Summing disjoint occupation-layer restrictions is a single partition of this paid positive measure, hence costs this bound once, not once per layer.

## Event ownership and final accounting

This payment is defined INSIDE current R414, after all current paid branches have been removed. Initial-center inclusion in the other witness's expanded cube differs from R411 initial-center inclusion in the PARENT and R412 terminal return to the parent. Neither previous formal complement says w and t must be outside each other's cubes. The three partial geometry certificates show those initial geometric conditions can coexist, but do not prove a complete original-history R414 branch is nonempty. No exhaustive historical-first claim or coverage fraction is made.

Take α_*=K^(1/n)=exp(1/sqrt(n)), so α_*^n/K=1 exactly. Then

Δ419=2B_L/(q_-²h²)=2ε0²B_L/(1+sqrt(n))².

It is O(1/n) when the displayed frozen ε0,B_L are dimension-consistent. No h,L,stage,field or other paid-price parameter changes. The exact split is R414=P419+R419 on the SAME lift, without resampling or normalization. R419 adds only w outside α_*Q_t AND t outside α_*Q_w to all old labels; this does not imply disjoint cubes or new history eligibility.

Substitution in the R414 mother replaces C413 by C413+Δ419. Fhat,V413 and all old W fees stay unchanged; no prior clip/soft/negative-square credit is refunded. The resulting coefficients are16Fhat at G0,32Fhat at BH,64ΛFhat at the original entrance. Outside E387,S390,H,A_entrance terms keep their original coefficients. The old low-dimensional complete-core alternative is not added to the high-dimensional current-flow equation. Neither the total X absorption nor the whole residual has been solved.

## Actual computation and evidence limits

Both delivered scripts were independently rerun and their output matched the supplied .result.txt files byte-for-byte:

- geometry39 Fraction records:9 exact one-dimensional overlap/trapezoid center integrals;27 tensor uniform-f fixed-parent conditional moments through n64;3 positive-volume center-block certificates in n64/81/100. Simpson integration is exact here after all breakpoints: overlap is affine on each piece and the shifted overlap primitive is quadratic, so the integrand is cubic. Tensorization is used only in the explicitly uniform product model. Fixed-parent tests are not a positive-measure original parent flow. The geometry certificates verify matching/far/exclusive/source-collar/parent-outside/mutual-center relations only; they omit own-past, dynamic D, original clock/history and final terminals.
- aux44 Fraction configurations:[8,18,18]. Full nonuniform L1 sources are masses on disjoint cells, zero on their entire complement; all incidences are constant across disjoint continuous center blocks and checked by endpoint containment/exclusion. Actual q lies in[3/4,1], all selected sides in[1,2]. The parent captures all intended internal cells and excludes the exterior cell; the18 exterior-source cases genuinely have I_At<m_t. The strip-area formula computes actual Lebesgue pair volumes; products arise from center boxes, not independent source coordinates. Directed/reverse events at each pair are nested by their common sup-distance threshold, so the max/min side formulas give exact OR/intersection volumes. All44 directed moments are positive,30 strict union subtractions,18 exterior-source cases. Native far mass is certified by e<3 and integer powers; arbitrary rational α tests do not numerically certify the irrational α_* choice, which is justified analytically.

These finite examples do not realize complete R414 rank/stage/history conditions and are not used to infer the general theorem or nonzero original cost. There are no floating numerical certificates in these two scripts. Parent's final side-length terminology patch changes no mathematics/code/output and has been included in the hash binding.

Before author reading, reviewer executed144 extra Fraction symmetry-compressed true continuous-center/full-f raw-moment configurations,132 positive. Those use constant full f and equal child sides with centers inside the parent, rational K/α; they are not an R414 nonempty fixture. This was temporary reviewer execution without an archived standalone script, and is not added to delivered counts.

Final main/README and proof scope are consistent. No substantive correction remains. P and the general marked root budget remain open. Workflow-skill labels supply no external theorem in this audit.

## SHA-256 bindings

Final reviewed bytes follow. Later TeX/manifest/archive bytes are not bound here.

- `r419_main.md`: `5c7655b9bb430c5e2c473434664490f4c4d2db8de4201b5705d88c00b08ea04a`
- `r419_readme.md`: `83d00af8454bc12c7a2b26700defdf40e676edf9e5dbd20c973c0121c73ff8d3`
- `r419_geometry.md`: `ee0a199c48b5c1074ec2b56068f142e69a3a0c85d6875934edfefa6b2b6072cc`
- `r419_aux.md`: `46830686ff5ad46d0055968cf2c948bdc5a864a874280f34a98e355f00015ae4`
- `r419_geometry_check.py`: `c26c5b135bac8f61d7359556f3513a26d6a80ce0f48a10c5eeb53cc201864de3`
- `r419_aux_check.py`: `33bbedf7f02147942e686b270ea1ae442ec5cf292ea80a8a65f1ee2967967b93`
- `r419_geometry.result.txt`: `27a3d455176922eaf6c4dc6e12b4ac6a56b23c5d2f41240f74cc0456c03dd0b9`
- `r419_aux.result.txt`: `0032b39244d18055d82f65c0a4a60d0d4a81f0d9f919058358b2432f931d6ebf`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`

Frozen bounded result: one current-lift positive branch paid at the stated X_q price; the full remaining geometric budget is unproved.
