#!/usr/bin/env python3
"""Round 49. Position stress, compact reduction and insertion guards.
Finite-difference checks concern listed finite inputs only. No exponent fitting,
global weight optimization claim, external packages, or randomized sampling.
"""
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from pathlib import Path
import json
from math import isqrt

class I:
    def __init__(self, lo, hi=None):
        self.lo=F(lo); self.hi=F(lo if hi is None else hi); assert self.lo<=self.hi
    def __add__(self,o):
        if not isinstance(o,I): o=I(o)
        return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,o): return self+-o if isinstance(o,I) else self+I(-o)
    def __mul__(self,o):
        if not isinstance(o,I): o=I(o)
        vals=[x*y for x in (self.lo,self.hi) for y in (o.lo,o.hi)]
        return I(min(vals),max(vals))
    __rmul__=__mul__
    def __truediv__(self,q):
        q=F(q); assert q!=0
        return self*I(1/q)
    def data(self): return [str(self.lo),str(self.hi)]
    def contains_zero(self): return self.lo<=0<=self.hi

@lru_cache(None)
def root(q,n,bits):
    q=F(q); assert q>0
    if n==1: return I(q)
    h=F(1)
    while h**n<q: h*=2
    if h**n==q: return I(h)
    l=F(0) if h==1 else h/2
    for _ in range(bits):
        mid=(l+h)/2
        if mid**n==q:return I(mid)
        if mid**n<q:l=mid
        else:h=mid
    assert l**n<=q<=h**n
    return I(l,h)

def family(points,weights):
    n=len(points[0]); out=[]
    for mask in range(1,1<<len(points)):
        ids=[j for j in range(len(points)) if mask>>j&1]
        m=sum((weights[j] for j in ids),F(0))
        lo=tuple(min(points[j][i] for j in ids) for i in range(n))
        hi=tuple(max(points[j][i] for j in ids) for i in range(n))
        out.append((mask,m,lo,hi))
    return out

class Geometry:
    def __init__(self,points,weights,lam,bits):
        self.n=len(points[0]); self.N=len(points);self.lam=lam
        self.items={}; self.vals=[{} for _ in range(self.n)]
        boxes=[]; self.birth_ties=[]
        for mask,m,lo,hi in family(points,weights):
            gap=m-lam*max(h-l for l,h in zip(lo,hi))**self.n
            if gap==0:self.birth_ties.append(mask)
            if gap<=0:continue
            rr=root(m/lam,self.n,bits); self.items[mask]=(m,rr)
            for i in range(self.n):
                self.vals[i][(mask,-1)]=I(hi[i])-rr/2
                self.vals[i][(mask,1)]=I(lo[i])+rr/2
            boxes.append(tuple(((mask,-1),(mask,1)) for _ in range(self.n)))
        self.ranks=[];self.order=[]
        for axis in range(self.n):
            vv=self.vals[axis]; order=sorted(vv,key=lambda k:vv[k].lo+vv[k].hi)
            # Certify parallel endpoints of nonempty boxes; births are guarded separately.
            for a,b in zip(order,order[1:]):
                assert vv[a].hi<vv[b].lo, ('not certified generic',axis,a,b)
            self.order.append(tuple(order)); self.ranks.append({k:j for j,k in enumerate(order)})
        self.boxes=tuple(boxes)
        self.signature=(tuple(sorted(self.items)),tuple(self.order))
        self._cache={}
    def volume(self, boxes, axes):
        boxes=tuple(sorted(set(boxes))); key=(boxes,axes)
        if key in self._cache:return self._cache[key]
        if not boxes:return I(0)
        if not axes:return I(1)
        a=axes[0];rank=self.ranks[a]; cuts=sorted({p for b in boxes for p in b[0]},key=rank.get)
        total=I(0)
        for l,h in zip(cuts,cuts[1:]):
            active=tuple(b[1:] for b in boxes if rank[b[0][0]]<=rank[l] and rank[h]<=rank[b[0][1]])
            if active: total+=(self.vals[a][h]-self.vals[a][l])*self.volume(active,axes[1:])
        self._cache[key]=total
        return total
    def cost(self):return self.volume(self.boxes,tuple(range(self.n)))*self.lam
    def derivatives(self):
        assert not self.birth_ties, ('birth equality: use one-sided directional formula',self.birth_ties)
        V=self.volume(self.boxes,tuple(range(self.n)))
        omega=I(0); ga=[I(0) for _ in range(self.N)]; faces=[]
        for b in self.boxes:
            mask=b[0][0][0]; m,rr=self.items[mask]
            for axis in range(self.n):
                axes=tuple(i for i in range(self.n) if i!=axis)
                rect=tuple(b[i] for i in axes)
                for side in (0,1):
                    plane=b[axis][side]; rank=self.ranks[axis]; blockers=[]
                    for other in self.boxes:
                        if not rank[other[axis][0]]<rank[plane]<rank[other[axis][1]]:continue
                        clipped=[]; good=True
                        for i in axes:
                            r=self.ranks[i]
                            l=max((b[i][0],other[i][0]),key=r.get)
                            h=min((b[i][1],other[i][1]),key=r.get)
                            if r[l]>=r[h]:good=False;break
                            clipped.append((l,h))
                        if good:blockers.append(tuple(clipped))
                    full=self.volume((rect,),axes); covered=self.volume(tuple(blockers),axes)
                    diff=full-covered;assert diff.hi>=0
                    area=I(max(F(0),diff.lo),max(F(0),diff.hi))
                    w=area*rr*(self.lam/F(2*self.n));omega+=w
                    for j in range(self.N):
                        if mask>>j&1:ga[j]+=w/m
                    faces.append((mask,axis,side,area,w))
        gl=V-omega/self.lam
        return ga,gl,omega,faces

def one_dim(points,weights,lam,with_faces=False):
    # Scaled intervals lambda*B_S have linear endpoints in (weights,lambda).
    intervals=[];N=len(points)
    for mask,m,lo,hi in family(tuple((x,) for x in points),weights):
        l=lam*hi[0]-m/2; h=lam*lo[0]+m/2
        if l<h: intervals.append((l,h,mask))
    intervals.sort(); unions=[]
    for l,h,mask in intervals:
        if not unions or l>unions[-1][1]:unions.append([l,h,mask,mask])
        elif h>unions[-1][1]:unions[-1][1]=h;unions[-1][3]=mask
    cost=sum((h-l for l,h,_,_ in unions),F(0))
    if not with_faces:return cost
    grad=[F(0)]*(N+1);faces=[]
    for l,h,lmask,hmask in unions:
        for mask,side in ((lmask,-1),(hmask,1)):
            ids=[j for j in range(N) if mask>>j&1]
            for j in ids:grad[j]+=F(1,2)
            grad[-1]+=min(points[j] for j in ids) if side==1 else -max(points[j] for j in ids)
            faces.append((mask,side))
    return cost,tuple(grad),faces


def union_volume(boxes):
    boxes=tuple(sorted(set(b for b in boxes if all(l<h for l,h in b))))
    if not boxes:return F(0)
    cuts=sorted({x for b in boxes for x in b[0]});total=F(0)
    for l,h in zip(cuts,cuts[1:]):
        active=[b[1:] for b in boxes if b[0][0]<=l and h<=b[0][1]]
        if active:total+=(h-l)*(F(1) if not active[0] else union_volume(active))
    return total

def cost_enclosure(points,weights,lam,bits=48):
    n=len(points[0]);inner=[];outer=[]
    for mask,m,lo,hi in family(points,weights):
        if not m:continue
        rr=root(m/lam,n,bits)
        for target,r in ((inner,rr.lo),(outer,rr.hi)):
            target.append(tuple((hi[i]-r/2,lo[i]+r/2) for i in range(n)))
    return I(lam*union_volume(inner),lam*union_volume(outer))

def components(points,weights,lam):
    n=len(points[0]);parents=list(range(len(points)))
    def find(j):
        while parents[j]!=j:j=parents[j]
        return j
    for mask,m,lo,hi in family(points,weights):
        if m>lam*max(h-l for l,h in zip(lo,hi))**n:
            ids=[j for j in range(len(points)) if mask>>j&1 and weights[j]>0]
            for j in ids[1:]:parents[find(j)]=find(ids[0])
    groups={}
    for j,w in enumerate(weights):
        if w:groups.setdefault(find(j),[]).append(j)
    return list(groups.values())

def position_derivatives(g,points):
    ga,gl,omega,faces=g.derivatives();gy=[[I(0) for i in range(g.n)] for j in range(g.N)]
    axisflux=[I(0) for _ in range(g.n)];div=[I(0) for _ in range(g.n)]
    for mask,i,side,area,w in faces:
        ids=[j for j in range(g.N) if mask>>j&1]
        coords=[points[j][i] for j in ids]
        assert len(coords)==len(set(coords)), 'position order tie: use branch limits'
        owner=min(ids,key=lambda j:points[j][i]) if side else max(ids,key=lambda j:points[j][i])
        sign=1 if side else -1
        gy[owner][i]+=area*(g.lam*sign);axisflux[i]+=w
        plane=g.vals[i][(mask,sign)]
        div[i]+=area*plane*(g.lam*sign)
    return gy,axisflux,div

def main():
    records=[]
    # Stage 1: exact one-dimensional split/escape/tiny-mass normalizations.
    for N in (2,3,4,5,6):
        for spacing in (F(1,20),F(1,3),F(3),F(100),F(1000000)):
            for power in (1,4,12,32):
                raw=[F(1,2**power)]+[F(1)]*(N-1);mass=sum(raw);ws=tuple(w/mass for w in raw)
                pts=tuple((j*spacing,) for j in range(N));lam=F(1)
                total=cost_enclosure(pts,ws,lam);assert total.lo==total.hi
                groups=components(pts,ws,lam);parts=[]
                for ids in groups:
                    pp=tuple(pts[j] for j in ids);ww=tuple(ws[j] for j in ids);m=sum(ww)
                    v=cost_enclosure(pp,ww,lam);assert v.lo==v.hi
                    normalized=tuple(((q[0]-pp[0][0])/m,) for q in pp)
                    wnorm=tuple(w/m for w in ww);nv=cost_enclosure(normalized,wnorm,F(1))
                    assert nv.lo==nv.hi==v.lo/m
                    assert all(abs(q[0])<=len(ids)-1 for q in normalized)
                    parts.append((v.lo,m,nv.lo))
                assert sum(p[0] for p in parts)==total.lo
                best=max(p[2] for p in parts);assert best>=total.lo
                records.append(dict(stage='compact_reduction',n=1,N=N,spacing=str(spacing),tiny_power=power,
                    cost=str(total.lo),components=groups,best_normalized=str(best)))
    # Stage 2: correlated/bent genuine multi-dimensional sources and position derivatives.
    for n in (1,2,3,4,5,6):
        for N in ((2,3,4) if n<=4 else (2,3)):
            ws=tuple(F(2**j,2**N-1) for j in range(N))
            for kind in ('correlated','curved'):
                raw=tuple(tuple(F(j*(i+1)+(j*j if kind=='curved' else 0)) for i in range(n)) for j in range(N))
                D=max(max(q[i] for q in raw)-min(q[i] for q in raw) for i in range(n))
                pts=tuple(tuple(z*F(2,3)/D for z in q) for q in raw)
                for lam in (F(5,7),F(17,13),F(31,11)):
                    previous=None
                    for bits in (48,64):
                        g=Geometry(pts,ws,lam,bits);gy,axisflux,div=position_derivatives(g,pts);cost=g.cost()
                        residuals=[]
                        for i in range(n):
                            translation=sum((gy[j][i] for j in range(N)),I(0))
                            anisotropic=sum((gy[j][i]*pts[j][i] for j in range(N)),I(0))-cost+axisflux[i]*n
                            assert translation.contains_zero() and anisotropic.contains_zero() and (div[i]-cost).contains_zero()
                            residuals.append(dict(translation=translation.data(),anisotropic=anisotropic.data(),divergence=(div[i]-cost).data()))
                        if previous:assert previous.lo<=cost.lo<=cost.hi<=previous.hi
                        previous=cost
                        records.append(dict(stage='position_identity',n=n,N=N,kind=kind,lam=str(lam),bits=bits,cost=cost.data(),residuals=residuals))
                    for h in (F(1,10000),F(1,1000000)):
                        for j,i in product(range(N),range(n)):
                            used_h=h
                            for halvings in range(30):
                                pp=[list(q) for q in pts];pm=[list(q) for q in pts];pp[j][i]+=used_h;pm[j][i]-=used_h
                                gp=Geometry(tuple(map(tuple,pp)),ws,lam,64);gm=Geometry(tuple(map(tuple,pm)),ws,lam,64)
                                owner_order_stable=all(
                                    all((pp[a][k]-pp[b][k])*(pts[a][k]-pts[b][k])>0 and
                                        (pm[a][k]-pm[b][k])*(pts[a][k]-pts[b][k])>0
                                        for a,b in combinations(range(N),2)) for k in range(n))
                                if gp.signature==gm.signature==g.signature and owner_order_stable:break
                                used_h/=2
                            else:raise AssertionError('failed to stay inside ordering chamber')
                            err=(gp.cost()-gm.cost())/(2*used_h)-gy[j][i]
                            assert max(abs(err.lo),abs(err.hi))<F(1,1000)
                            records.append(dict(stage='position_difference',n=n,N=N,kind=kind,lam=str(lam),j=j,i=i,h=str(used_h),requested_h=str(h),halvings=halvings,error=err.data()))
                    groups=components(pts,ws,lam);sumcost=I(0)
                    for ids in groups:
                        pp=tuple(pts[j] for j in ids);ww=tuple(ws[j] for j in ids);m=sum(ww)
                        D=max(max(q[i] for q in pp)-min(q[i] for q in pp) for i in range(n))
                        assert lam*D**n<=F((len(ids)-1)**n)*m
                        sumcost+=cost_enclosure(pp,ww,lam)
                    assert (sumcost-cost).contains_zero()
                    records.append(dict(stage='multidim_components',n=n,N=N,kind=kind,lam=str(lam),groups=groups,residual=(sumcost-cost).data()))
    # Stage 3: zero mass/collision continuity and old tied branches versus new insertion.
    for eps in (F(0),F(1,4),F(1,16),F(1,256),F(1,65536)):
        pts=((F(0),),(eps,));ws=(F(1,3),F(2,3));cost=cost_enclosure(pts,ws,F(1))
        assert cost.lo==cost.hi and abs(cost.lo-1)<=3*eps
        records.append(dict(stage='collision',eps=str(eps),cost=str(cost.lo)))
    for n in (1,2,3,4):
        base=((F(0),)*n,);ws=(F(1),);v=cost_enclosure(base,ws,F(1))
        padded=base+((F(100),)*n,);pv=cost_enclosure(padded,(F(1),F(0)),F(1))
        assert v.lo==v.hi==pv.lo==pv.hi==1
        records.append(dict(stage='zero_padding',n=n,cost='1'))
    # At the 1D joint kink, mixtures A/B have opposite position gradients.
    basepoints=(F(0),F(1));weights=(F(1,2),F(1,2));lam=F(3,4)
    for h in (F(1,64),F(1,256),F(1,1024)):
        for delta in (-h,h):
            cost,grad,faces=one_dim(basepoints,weights,lam+delta,True)
            gy=[F(0),F(0)];kernel=F(0);flux=F(0)
            for mask,sign in faces:
                ids=[j for j in range(2) if mask>>j&1];m=sum(weights[j] for j in ids);R=m/lam
                owner=min(ids,key=lambda j:basepoints[j]) if sign==1 else max(ids,key=lambda j:basepoints[j])
                gy[owner]+=sign*lam
                plane=basepoints[owner]+sign*R/2
                flux+=m/2
                if abs(F(1,2)-plane)<=R/2:kernel+=F(1,2)
            expected=(F(-3,4),F(3,4)) if delta<0 else (F(3,4),F(-3,4))
            assert tuple(gy)==expected
            assert kernel==(2 if delta>0 else 0)
            records.append(dict(stage='kink_position_branch',delta=str(delta),position_gradient=list(map(str,gy)),insertion_kernel=str(kernel),flux=str(flux)))
    for eps in (F(1,1000000),F(1,1024),F(1,64),F(1,16),F(1,8),F(1,4),F(3,4),F(1),F(2),F(16),F(1000000)):
        inserted=one_dim((F(0),F(1,2),F(1)),(F(1,2),eps,F(1,2)),lam)
        assert inserted==max(F(5,4),F(1,2)+eps)
        derivative=(inserted-F(5,4))/eps
        if eps<=F(3,4):assert derivative==0
        records.append(dict(stage='insertion_obstruction',eps=str(eps),cost=str(inserted),difference=str(derivative),old_mixture_kernel='1'))
    for eps in (F(1,1000000),F(1,1024),F(1,64),F(1,16),F(1,8),F(1,4)):
        value=one_dim((F(0),F(10)),(F(1),eps),F(1))
        assert value==1+eps
        records.append(dict(stage='new_component_insertion',eps=str(eps),cost=str(value),derivative='1',old_contact_kernel='0'))
    result=dict(round=49,status='PASS',cases=len(records),counts={},records=records,random_seed=None,
        proof_status='fixed-N attainment and joint position stress proved; N-independent square-root budget unproved')
    for r in records:result['counts'][r['stage']]=result['counts'].get(r['stage'],0)+1
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k] for k in ('status','cases','counts')},sort_keys=True))
if __name__=='__main__':main()
