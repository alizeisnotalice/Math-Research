# R400 independent audit — FINAL PASS

FINAL PASS for the actual outgoing two-source marked receipt, its exact combination with R399, full positive remainder and ledger substitution. General root-order closure is not certified. Only this audit file was edited; author files and repository were not modified.

Only /tmp/r400_audit.md is edited. This independent screen precedes reading any R400 author proof. It uses the frozen exact actual kernel in R390, the R398 switching measure and the audited R399 native two-posterior lemma. General closure remains open.

## 1. Actual sourcewise outgoing capacity

The frozen actual kernel, including original physical-clock average, losses and every source/target/history/fractional mark, is

    gamma0(du,dv,dy)
       =sigma(du) pi_u(dy) c_v(y) chi0(y,u,v) mu(dv)/T_u(y),
    sigma(du)=q_u du, pi_u(dy)=f(y)c_u(y)dy/m_u,
    mu(dv)=dv/m_v, 0<=chi0<=1.

Its retained middle strip includes T_v(y)<beta T_u(y), with the original beta<1, and strict far mass m_u>K m_v. A live original denominator T_u(y)>0 is guaranteed by the old support; define zero off that support. Stage gamma_i is the same kernel restricted to A_i at both endpoints, not a new flow.

For each fixed u,y, set

    l_i(u,y)=1_Ai(u) integral 1_Ai(v)c_v(y)
                       chi0(y,u,v) mu(dv)/T_u(y).

Then 0<=l_i<=l_0<=beta before averaging over pi_u. In fact the actual inclusive mass CDF T_y(m_v) has the native rank-sublevel property

    integral c_v(y)1_{T_y(m_v)<a}mu(dv)<=a.

Use a=beta T_u(y) and drop only positive marks. Complete crossing atoms are excluded if their inclusive endpoint violates the strict gate; there is no first-crossing overshoot term here. This is the outgoing initial rank segment, unlike the R390 incoming strip integral. The lower strip bound alpha and the mass-far gate only decrease the integral. Hence the required sourcewise beta bound is stronger than the averaged outgoing-row bound and follows directly from the original exact definitions.

There is no q_u/q_v factor in this outgoing disintegration. Such a ratio occurs on reversing the receiver integration for the incoming column, not here. Full matching is already in pi_u and mu_v, so no extra mass factor is introduced.

## 2. Exact external marked component and dropping its v dependence

R398 has

    H_ext=sum_i integral gamma_i(du,dv,dy)
          integral pi_u(dz)b_i(z)(1-c_v(z))1_{Z_u(z)>Lh}.

Here y is the original traffic source and z is the full-f additional switching witness, with a product of their posteriors only conditional on u and the actual old labels. Keep all fields fixed and put

    C_u(y,z)=integral_{m_w<m_u/K}c_w(y)c_w(z)mu(dw),
    phi_u(y,z)=min(1,C_u(y,z)/h).

Define H_ext^phi and H_ext^(1-phi) by inserting phi and 1-phi in this exact old expression. These are nonnegative and sum exactly to H_ext. The external factor 1-c_v(z) genuinely depends on the old small endpoint v. It is NOT factored out as independent of v. For the upper estimate only, drop it and the positive high-Z witness gate, then integrate v to obtain l_i(u,y). The latter is bounded sourcewise by beta. Summing the same global b_i(z) first, with sum_i b_i(z)<=1 and nested restrictions, gives

    H_ext^phi <= beta/h integral sigma(du)
                                E_(pi_u tensor pi_u) C_u(y,z).

This remains valid for infinitely many stages by positive monotone convergence. It has no separate per-stage W fee, nor a newly constructed w history.

## 3. Relabelled native joint moment and exact price

The R399 native lemma applies with u as its large endpoint:

    integral sigma(du) E_(pi_u tensor pi_u) C_u
       = integral mu(dw) integral_{m_u>K m_w}
                               q_u I_uw^2 du/m_u^2
       <=2lambda |E|/(q_-K)
       <=2lambda X_q/(q_-^2 K).

The exact square is of full-source intersection mass I_uw, not the integral of f squared. I_uw<=m_w and the native actual-center squared-mass tail provide its bound. The original strict cutoff and mass atoms do not invalidate that positive envelope. Every denominator is positive on the live support.

Consequently the candidate receipt is valid:

    H_ext^phi <= eta_ext,n X_q,
    eta_ext,n=2lambda beta/(q_-^2 K h)
             =2(lambda/q_-)beta epsilon0/[K(1+sqrt(n))].

This substitutes beta for C_col in the R399 moment price, with no additional q ratio. It pays the exact phi-marked component of the original H_ext switching bill, not automatically a component of the original gamma0/core flow. No original negative BH square is used.

## 4. Joint remainder and ledger boundary

Together with R399, a valid exact residual is

    R_400=H_ext^(1-phi)+H_small^(1-psi),
    R_L=H_ext^phi+H_small^psi+R_400.

Thus the high-dimensional R398 residual substitution, if adopted, uses total new coefficient

    eta_joint,n=2lambda(beta+C_col)/(q_-^2 K h).

The original entrance increment is 64Lambda eta_joint,n X_q when starting from R398; or 64Lambda eta_ext,n X_q in addition to the already displayed R399 increment. These are the same complete expression, not two independent charges for the same branch. Original source prices and all unpriced terms remain. Absorption must reserve the corresponding global balance. Low dimensions can use the whole-core alternative rather than stacking switching charges.

Positive external residual implies C_u(y,z)<h while its old current source and new high-Z witness retain their original individual ranks. This gives no uniform positive paid fraction, no spatial separation, and no new eligible outgoing row at w. The complementary external and small-end bills remain unproved at root order.

## 5. Actual local arithmetic

Before reading a new R400 proof, reviewer executed 49 Fraction checks: 45 inclusive atomic-CDF outgoing row bounds with strict endpoint gates, and four synthetic cumulative two-source soft-mark inequalities retaining a v-dependent external restriction. These are finite algebra diagnostics, not native synchronized high-history realizations; no separate script was saved. The general claim is established by the analytic derivation above, not their number.

Independent screen: PASS. The final author and report review below now completes the bounded audit.

## Screen dependencies bound by SHA-256

- `/tmp/r390_aux.md`: `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36`
- `/tmp/r398_bridge.md`: `359cb19f6ff267eb8b88e618f67313d7f386c330281cae49a8d40f526e16bd00`
- `/tmp/r399_geometry.md`: `84e9b4885011479d3da8a4bd7959389e1cf299a41a383d977ff087fbed6cba33`


## Interim code and auxiliary review

Reviewer read and actually reran `/tmp/r400_check.py`: exit 0, `PASS {'sourcewise_rows': 24, 'marked_external': 216} total 240 positive_paid_cases 117`. The script retains the actual v-dependent external witness exclusion, full conditional two-source factors and nested endpoint restrictions in the finite diagnostic. Its non-strict upper rank endpoint is an enlargement of the original strict endpoint gate and still obeys the inclusive-CDF bound. This finite interval/source-cell matching with positive receiver quadrature, rational K and synthetic stage marks is not a native continuum high-history realization or a replacement for the analytic proof. These are the same 240 parent-script cases, not 240 additional independent experiments due to reviewer rerunning.

The short frozen auxiliary `/tmp/r400_aux.md` was read. Its normalization E=Z-C>(1-epsilon0)h follows on the R399 positive small-end remainder; the exact route integrates to one without assigning w old eligibility. Its complete-posterior cost is I_vw(m_v-I_vw)/m_v^2, and its far-mass bounds (1-1/K)J_one<=F_ex<=J_one are valid. The native first-moment envelope leaves a logarithmic mass span. It is correctly marked unpriced and is not added to the main ledger. Reviewer independently reproduced its one scalar exclusive-posterior value 17/45 with Fraction arithmetic; this is not a native core test. Its discussion of R399 H_ext being unchanged belongs to that auxiliary R399 contract and does not undo or double-count the separate R400 external phi split screened above.

Interim additional byte bindings:
- `/tmp/r400_check.py`: `174d808a01dd6047c4588e13d813935d53f579a1b9d85118fbea1d05fee2fb79`
- `/tmp/r400_aux.md`: `8a2d6114103a289b3b5c6b7db7d61a8a081831335503de2d3bccca6053888d8e`


## Final author proof, execution and report review

Read the complete frozen `/tmp/r400_geometry.md` and standalone script after completing the independent screen. The exact source-labeled formula (6) and disintegration (8) agree with the original kernel: sigma pi_u already equals q_u f c_u dmu(u)dy, so there is no additional q or mass ratio. The inclusive-CDF proof gives the required sourcewise outgoing beta capacity, rather than attempting to deduce it from an averaged row bound.

The external exclusion 1-c_v(z) and high-Z witness gate remain in the actual paid/complement measures. They are dropped only upwards in the estimate. The common-past mark is independent of the integrated small endpoint v once the actual u,y,z labels are fixed, which is exactly what permits the outgoing capacity and sum_i b_i(z)<=1 to be combined. The R399 native joint-moment lemma then applies by renaming its large endpoint u. No original source square, negative BH credit, or earlier positive payment is reused.

The old-y-conditional lift identity (12) is valid, including its E_uv/Z_u factor. With L>0 a retained new source has positive Z; if no such external source exists the corresponding term is zero. The phi_u(y,z) factor must remain inside the original y integration. It cannot be inserted into an already marginalized unlabeled gamma as a function of u,v,z alone. The author and final report state this restriction correctly.

On positive external complement, strict m_u>K m_v ensures every m_w<=m_v is strictly below m_u/K, including complete mass atoms. Hence Z_u(y)>=T_v(y)>2h is valid at the original source. The complementary witness has Z_u(z)>Lh and C_u(y,z)<h. These are source-occupation conditions, not distance separation or transferred history eligibility.

Author equations (15)-(19), final main and readme pass: the combined coefficient is

    zeta_n=2(lambda/q_-)(beta+C_col)epsilon0/[K(1+sqrt(n))].

This REPLACES the R399 small-end coefficient in the complete display; from the R399 ledger only the new outgoing portion is incremental. The original entrance coefficient is 64Lambda zeta_n. P_L and all old source/outer fees remain. With uniform S and lambda/q_- the stated finite cutoff follows from epsilon0<=1/2; no mid-field parameter reset is used. Low dimensions directly replace the entire old G0 slot by S(1+N_delta log2)W/2, withdrawing the high-dimensional switching replacement there. Both low-dimensional coefficients in main are correct. No available global absorption balance is assumed without a reserved allowance.

Reviewer actually reran `/tmp/r400_geometry_check.py` to exit 0:

    PASS {'atomic_rows': 324, 'actual_marked_algebra': 96,
          'native_tail_and_price': 57} total 477
    features {'positive_paid': 36, 'positive_complement': 48,
              'positive_lift_checks': 1098, 'rank_equalities': 111}

These are Fraction checks. They include exact old-source disintegration and the conditional external lift, positive paid and complement costs, strict rank-atom boundaries, native scalar radial integrals and combined coefficient arithmetic. The feature counters are not additional independent checks. Stage 2 is finite interval/source-cell incidence with receiver quadrature, rational far gaps and diagnostic marks; it is not a realization of all original synchronized continuum core/history gates. The native radial scalar formula does not certify a full native core fixture. The analytic proof establishes the general actual-du claim.

The parent 240-check script and author 477-check script have both been read and actually run by this reviewer; reruns are not new independent parameter sets. The final main/readme correctly separate their scope, the auxiliary scalar check, and prior-round MATLAB evidence. No new MATLAB execution is asserted here. The full R400 complement, all original unpriced outer slots and general absorption remain unresolved. No uniform positive proportion paid is established.

## Final frozen byte bindings

SHA-256 binds the exact reviewed R400 files; subsequent edits require updating this audit.

- `/tmp/r400_main.md`: `1e0fb7906923a1442a5b1988407e41e400810f9a6748b571a32904181e90d304`
- `/tmp/r400_readme.md`: `c01ea53612a916e36347178d764bc93ec2e621af5d41f5e876607eadc9f14a73`
- `/tmp/r400_geometry.md`: `041cec14e395f8e79fe23fd87e16b3aedabb6ca91d734b3326501dd080080e8c`
- `/tmp/r400_geometry_check.py`: `e884129f33792b8c888a15d05352213f1ceb205119d76fd36db01a8bdff46175`
- `/tmp/r400_geometry.result.txt`: `a6b5e4d4e4b53d148c8000eb7812c271ddf1a75d0b165822fd42760eeaca5c60`
- `/tmp/r400_aux.md`: `8a2d6114103a289b3b5c6b7db7d61a8a081831335503de2d3bccca6053888d8e`
- `/tmp/r400_check.py`: `174d808a01dd6047c4588e13d813935d53f579a1b9d85118fbea1d05fee2fb79`
- `/tmp/r400_check.result.txt`: `14ab632b5c07c1fdfdf922b77f7a6c24bdba74eb89395531dfb00f4075017be3`


The necessary old sourcewise kernel, switching decomposition and native moment contracts are bound above. Their general historical reductions were not reaudited wholesale in this round.

FINAL PASS: the stated actual external fraction and its combined two-endpoint accounting are valid. Freeze this audit; the remaining general core budget is open. No further research or duplicate numerical pipeline is required for this review.
