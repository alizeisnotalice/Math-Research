from fractions import Fraction as F
from itertools import product
counts={'atomic_rows':0,'actual_marked_algebra':0,'native_tail_and_price':0}
features={'positive_paid':0,'positive_complement':0,'positive_lift_checks':0,'rank_equalities':0}
# Inclusive rank atoms; the actual outgoing gate has a strict upper rank cut.
for atoms in product([F(1,3),F(1),F(2)],repeat=4):
    pref=[]
    for x in atoms: pref.append(x+(pref[-1] if pref else 0))
    total=pref[-1]
    for beta in [F(1,3),F(1,2),F(3,4),pref[1]/total]:
        row=sum(x/total for x,t in zip(atoms,pref) if t<beta*total)
        assert row<=beta
        features['rank_equalities']+=sum(t==beta*total for t in pref)
        counts['atomic_rows']+=1
assert sum([],F(0))==0  # zero-rank rows are assigned zero

Q=[set(range(8)),set(range(6)),set(range(2,8))]
Q += [set(range(i,i+2)) for i in range(7)]
rw=[F(i+1,20) for i in range(len(Q))]
for k,Kgap,beta in product(range(1,5),[F(3,2),F(2),F(3)],[F(1,2),F(3,4)]):
    f=[F(1+(k*z)%3) for z in range(8)]
    m=[sum(f[z] for z in q) for q in Q]
    q=[m[v]/len(Q[v]) for v in range(len(Q))]
    mu=[rw[v]/m[v] for v in range(len(Q))]
    sig=[q[v]*rw[v] for v in range(len(Q))]
    T=[[sum(mu[w] for w in range(len(Q)) if m[w]<=m[u] and y in Q[w]) for y in range(8)] for u in range(len(Q))]
    Z=[[sum(mu[w] for w in range(len(Q)) if m[w]<m[u]/Kgap and y in Q[w]) for y in range(8)] for u in range(len(Q))]
    C=[[[sum(mu[w] for w in range(len(Q)) if m[w]<m[u]/Kgap and y in Q[w] and z in Q[w]) for z in range(8)] for y in range(8)] for u in range(len(Q))]
    coeff={}
    for u,v in product(range(len(Q)),repeat=2):
        if m[u]<=Kgap*m[v]: continue
        for y in Q[u]&Q[v]:
            if not F(1,20)*T[u][y]<T[v][y]<beta*T[u][y]: continue
            chi=F(1+(u+v+y)%3,3)
            ell=mu[v]*chi/T[u][y]
            original=f[y]*q[u]*mu[u]*mu[v]*chi/T[u][y]
            assert original==sig[u]*f[y]/m[u]*ell
            coeff[u,v,y]=ell
    for u in range(len(Q)):
        for y in Q[u]:
            assert sum(val for (uu,v,yy),val in coeff.items() if uu==u and yy==y)<=beta
    thresholds=[F(0),F(1,2),F(1),F(2),F(4)]
    bs=[]
    for i in range(1,5):
        bs.append([(min(f[z],thresholds[i])-min(f[z],thresholds[i-1]))/f[z]
                   *max(F(0),1-F(1)/(F(10+z,2+i))) for z in range(8)])
    assert all(sum(b[z] for b in bs)<=1 for z in range(8))
    J2=sum(sig[u]*f[y]*f[z]*C[u][y][z]/m[u]**2
           for u in range(len(Q)) for y in Q[u] for z in Q[u])
    for h,L in product([F(1,10),F(1,2)],[F(0),F(1,2)]):
        paid=remaining=total=F(0)
        for i,bi in enumerate(bs):
            A=set(range(len(Q)-i))
            for (u,v,y),ell in coeff.items():
                if u not in A or v not in A: continue
                pair=F(0)
                lifted=F(0)
                E=sum(f[z]*Z[u][z]/m[u] for z in Q[u]-Q[v])
                for z in Q[u]-Q[v]:
                    if not Z[u][z]>L*h: continue
                    phi=min(F(1),C[u][y][z]/h)
                    base=sig[u]*f[y]/m[u]*ell*f[z]/m[u]*bi[z]
                    paid+=base*phi
                    remaining+=base*(1-phi)
                    total+=base
                    pair+=f[z]/m[u]*bi[z]*phi
                    if E:
                        nu=f[z]*Z[u][z]/(m[u]*E)
                        lifted+=E*bi[z]*phi/Z[u][z]*nu
                assert pair==lifted
                if pair: features['positive_lift_checks']+=1
        assert paid+remaining==total
        assert paid<=beta*J2/h
        features['positive_paid']+=paid>0
        features['positive_complement']+=remaining>0
        counts['actual_marked_algebra']+=1

for q0,M in product([F(1,3),F(3,4),F(1),F(2),F(5)],repeat=2):
    x0=M/q0
    assert x0/M**2+1/(q0*q0*x0)==2/(q0*M)
    counts['native_tail_and_price']+=1
for q0,lam,beta,Ccol,eps,s,Kgap in product([F(3,4)],[F(1)],[F(1,2),F(3,4)], [F(1),F(2)],[F(1,8),F(1,2)],[F(4),F(5)],[F(8),F(16)]):
    h=s/(eps*q0)
    big=2*lam*beta/(q0*q0*Kgap*h)
    small=2*lam*Ccol/(q0*q0*Kgap*h)
    combined=2*(lam/q0)*(beta+Ccol)*eps/(Kgap*s)
    assert big+small==combined
    assert 4*16*combined==64*combined
    counts['native_tail_and_price']+=1
assert all(features.values())
print('PASS',counts,'total',sum(counts.values()))
print('features',features)
