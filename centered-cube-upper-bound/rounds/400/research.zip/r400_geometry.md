# R400 — An actual outgoing double-source receipt for the external switching bill

## 1. Exact new payment

Keep the entire R398–399 contract: f, actual Lebesgue receiver set E, selected cubes, complete matched masses m_u=q_uR_u^n, μ(du)=du/m_u, σ(du)=q_udu, π_u(dy)=f(y)c_u(y)dy/m_u, all clocks and historical/spatial/rank marks. The density stages are the actual decreasing endpoint restrictions γ_i with marks b_i≥0 satisfying ∑_i b_i(z)≤1. No original field is recomputed.

Write K=exp(√n), s=1+√n and h=s/(ε_0q_-). Define the common strict far-past at the **large** endpoint:

 C_u(y,z)=∫_E c_w(y)c_w(z)1_{m_w<m_u/K}μ(dw),
 φ_u(y,z)=min{1,C_u(y,z)/h}.                              (1)

This is the same geometric occupation functional as R399, now used on the two sources belonging to u. It is not an assertion that the actual external cost was originally a product π_u⊗π_v; its correct disintegration is proved below.

Let dΓ_i(y,u,v) retain the actual original source y. The exact marked external cost and its paid part are

 H_ext=∑_i∫dΓ_i(y,u,v)π_u(dz)
                   b_i(z)(1−c_v(z))1_{Z_u(z)>Lh},
 H_ext^φ=∑_i∫dΓ_i(y,u,v)π_u(dz)
                   b_i(z)(1−c_v(z))1_{Z_u(z)>Lh}φ_u(y,z).
                                                               (2)

Then

 H_ext^φ≤η_out,n X_q,
 η_out,n=2λβ/(q_-²Kh)
         =2(λ/q_-)βε_0/[K(1+√n)].                       (3)

The complementary cost H_ext^(1−φ) is defined by inserting 1−φ in exactly (2). Thus H_ext=H_ext^φ+H_ext^(1−φ), with all original positive factors retained in both pieces. The full branch C_u(y,z)≥h is paid, together with the specified soft fraction below h. No lower bound on the proportion paid is claimed.

Combining with the already proved R399 small-end fraction, set

 S=β+C_col,
 R_400=H_ext^(1−φ)+H_small^(1−ψ),
 η_tot,n=η_out,n+η_in,n
        =2λS/(q_-²Kh)=2(λ/q_-)Sε_0/[K(1+√n)].           (4)

The exact split of the R398 high-rank bill and its receipt are

 R_L=H_ext^φ+H_small^ψ+R_400,
 H_ext^φ+H_small^ψ≤η_tot,n X_q.                           (5)

This adds a payment for a distinct component of the original external endpoint bill. It does not charge R399's small-end fraction again.

## 2. The original-source disintegration and its pointwise outgoing bound

The actual source-labeled cost has the form

 dΓ_0(y,u,v)= f(y)q_u c_u(y)c_v(y)
                χ_0(y,u,v)dy μ(du)μ(dv)/T_u(y),         (6)

where χ_0∈[0,1] contains every original physical-clock average, source/target loss, spatial condition, fractional retention and original core restriction. In particular its live support has

 m_u>K m_v,
 α<T_v(y)/T_u(y)<β,
 T_v(y)>2h, 
 0<α<β<1.                                               (7)

The stage restriction multiplies (6) by 1_{A_i}(u)1_{A_i}(v). Since σ(du)π_u(dy)=q_u f(y)c_u(y)μ(du)dy, it follows **exactly** that

 dΓ_i(y,u,v)=σ(du)π_u(dy)ℓ_i(u,y,dv),
 ℓ_i(u,y,dv)=1_{A_i}(u)1_{A_i}(v)c_v(y)
                    χ_0(y,u,v)μ(dv)/T_u(y).             (8)

Zero-rank rows have no live contribution and are assigned zero. For T_u(y)>0, the original middle-rank gate implies

 ℓ_i(u,y,E)
 ≤[∫c_v(y)1_{T_v(y)<βT_u(y)}μ(dv)]/T_u(y)
 ≤β.                                                    (9)

For the last inequality apply the inclusive-CDF sublevel capacity to the actual mass distribution ρ_y(dv)=c_v(y)μ(dv): the total measure of the set whose **right** rank T_v(y) is below a is at most a. Atoms crossing a are excluded in full; equality at a is also excluded by the original strict gate. One can equivalently spread each atom over its rank interval and include only complete intervals with right endpoint below a. Thus (9) holds with arbitrary mass atoms, including at the cut, and needs no comparison of source densities.

This proves the sourcewise bound required here, rather than assuming that an averaged row bound holds pointwise. In contrast with an attempt to transfer the small-end posterior to an external source, both y and z in (8),(2) are now drawn from the same complete π_u; the v-dependence is retained in the actual kernel ℓ_i until an explicit positive upper bound is taken.

## 3. The joint moment and the marked bound

The R399 native squared-mass-tail lemma, valid for arbitrary selected radii and every z,M>0, is

 ∫_E q_uc_u(z)1_{m_u>M}du/m_u²≤2λ/(q_-M).                (10)

Its proof uses capture m_u≥q_-(2||u−z||_∞)^n and the exact center-volume variable t=(2||u−z||_∞)^n:

 λ∫_0^∞dt/max(M,q_-t)²=2λ/(q_-M).

It does not replace receiver integration by independent radius integration and does not impose a source density cap. Full matching, I_uw=f(Q_u∩Q_w)≤m_w, and positive Tonelli then give

 ∫σ(du)E_(π_u⊗π_u) C_u
 =∫μ(dw)∫_{m_u>K m_w}q_u I_uw²du/m_u²
 ≤∫μ(dw)m_w∫f(z)c_w(z)
                  [∫q_uc_u(z)1_{m_u>K m_w}du/m_u²]dz
 ≤2λ|E|/(q_-K)
 ≤2λX_q/(q_-²K).                                       (11)

This is the already proved joint-moment lemma applied to the actual large endpoint. It is the square of an intersection mass, not an f² integral. The cancellation against μ(dw) is performed after the full simultaneous center/source integration, so the same w is not charged separately for each original edge.

Insert (8) into (2). Drop only the nonnegative restrictions (1−c_v(z)) and 1_{Z_u(z)>Lh} for an upper bound, use (9), and keep the stage marks at the same source z:

 H_ext^φ
 ≤∫σ(du)π_u(dy)π_u(dz)φ_u(y,z)
                          ∑_i b_i(z)ℓ_i(u,y,E)
 ≤β∫σ(du)π_u(dy)π_u(dz)φ_u(y,z)
 ≤(β/h)∫σ(du)E_(π_u⊗π_u)C_u.

Equation (11) proves (3). For finite stage sums these are positive integrals; monotone convergence proves the full result. No stage count is paid. No new witness receiver w receives an original χ or a history qualification, and no old negative capture square is subtracted again.

## 4. Exact compatibility with the external normalization

The actual R390 external source law remains

 E_uv=π_u[(1−c_v)Z_u],
 ν_uv^z(dz)=(1−c_v(z))Z_u(z)π_u(dz)/E_uv.

For each fixed old labeled triple (y,u,v), on the present E_uv>0 support and L>0,

 π_u[b_i(1−c_v)1_{Z_u>Lh}φ_u(y,·)]
 =E_uv∫ b_i(z)φ_u(y,z)1_{Z_u(z)>Lh}/Z_u(z) ν_uv^z(dz).
                                                               (12)

Integrating (12) against dΓ_i and summing gives the exact lift representation of H_ext^φ. The same identity holds with 1−φ for its complement. In particular E_uv/Z_u is not omitted or bounded by one. The proof in §3 estimates the original posterior expression directly; it does not need a new bound on this ratio or a column bound for the extra receiver w.

The ν law is only a law in z. The original y integral must remain outside (12): φ_u(y,z) depends on y, so it cannot be inserted after forgetting that original label. Equation (8) and the conditional identity (12) keep precisely this distinction. No source-exact new transport plan is claimed.

## 5. Full remaining structure and accounting

On the positive external remainder H_ext^(1−φ), one has

 C_u(y,z)<h,
 Z_u(z)>Lh,
 Z_u(y)≥T_v(y)>2h.                                     (13)

The last implication is legitimate at every mass atom: m_w≤m_v and m_v<m_u/K imply m_w<m_u/K. It is obtained at the original old source y, not inherited at z or w. On the positive small-end remainder the R399 conditions remain

 C_v(y,z)<h,
 T_v(y)>2h,
 T_v(z)>Lh.                                             (14)

Thus both endpoint bills now retain only a low-common-far-past double-source component, while the indicated individual ranks are high. These are occupation conditions only; no additional geometric distance separation or history propagation is deduced. H_ext^(1−φ) still carries its exact (12) reweighting if represented through ν, and all stages remain in R_400.

For n≥9 the established R398 clearing estimate and (5) give

 G_0≤16R_400+16η_tot,nX_q+16(s+P_L)W,
 P_L=λh[β(L+ε_0)+C_col L].                              (15)

The original BH slot is therefore

 BH≤32R_400+(E387+32η_tot,n)X_q
                   +[S390+40s+32P_L]W.                 (16)

At the original entrance this is

 Λ{8λHW+2d_eff A_nW_ν/H+64R_400
       +(2E387+64η_tot,n)X_q+[2S390+80s+64P_L]W}.         (17)

Starting instead from the R399 ledger adds only 32η_out,nX_q in BH and 64Λη_out,nX_q at the entrance; the η_in,n part was already in that ledger. Formulae (16)–(17) display the combined coefficient once.

For a prescribed small δ>0, a dimension-uniform choice using only ε_0≤1/2 is

 A_*=(λ/q_-)S,
 N_δ=ceil(max{3,log_+(A_*/δ)}²).                         (18)

If the frozen rank parameters have the uniform constants stipulated here, n>N_δ implies η_tot,n≤δ. This does not substitute an n-dependent ε_0 into a purported fixed dimension threshold. If ε_0 itself is fixed, 2(λ/q_-)Sε_0 can replace A_*; if S is allowed to vary with n, a uniform bound for it is required before asserting a fixed N_δ.

For the entire complementary range n≤N_δ, directly use

 G_0≤S(1+N_δlog2)W/2,                                   (19)

from 2G_0=∫fD_0 and the actual center envelope D_0≤S A_n. Substitute this into the old R392 core slot instead of applying the switching replacement there. In the large-dimensional branch the new entrance absorption is at most 64Λδ; an available global balance κ_rem must satisfy 64Λδ≤κ_rem. No assertion of already-available global absorption is made.

The general root-order budget for R_400 remains unproved. The advance is the specifically priced actual external fraction (3), complementing R399, with the exact single combined absorption (4). No source fee is added in the large-dimensional branch, and no earlier receipt is counted twice.

## 6. Actual local checks

Executed:

    python3 /tmp/r400_geometry_check.py
    PASS {'atomic_rows': 324, 'actual_marked_algebra': 96,
          'native_tail_and_price': 57} total 477
    features {'positive_paid': 36, 'positive_complement': 48,
              'positive_lift_checks': 1098, 'rank_equalities': 111}

All computations use Fraction. Stage 1 stresses the actual strict upper middle-rank row estimate with inclusive CDF atoms and exact threshold equalities. Stage 2 constructs full source-cell masses and actual interval incidences with rational far ratios, directly checks the two expressions in (8), retains original-source rational χ marks, nested endpoint restrictions and density-stage b_i, and verifies the paid/complement split, the β joint-moment bound and the old-y-conditional equality (12). Its finite receiver integration is quadrature and its marks are diagnostics, not the complete synchronized original history or a native core. Positive paid/complement examples only refer to that diagnostic scope.

Stage 3 exactly checks the native center radial integral in (10) at 25 rational parameter pairs and checks the combined η arithmetic at 32 parameter choices. The center-volume integral is native Lebesgue geometry, but is not claimed to be a full core example. Rational K values test algebra rather than exp(√n); the exponential dimension threshold is proved analytically in §5. No test count is used as evidence for the unproved general remainder budget.

Status: the stated actual external component is paid; (13)–(14) and R_400 are retained completely. No further route is opened in this note.
