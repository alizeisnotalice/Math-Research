from fractions import Fraction as F
from itertools import product
Q=[set(range(8)),set(range(6)),set(range(2,8))]+[set(range(i,i+2)) for i in range(7)]
rw=[F(i+1,20) for i in range(len(Q))]
counts={'sourcewise_rows':0,'marked_external':0};positive=0
for seed,K,beta in product(range(1,5),[F(3,2),F(2),F(3)],[F(1,2),F(3,4)]):
 f=[F(1+(seed*z)%5) for z in range(8)]
 m=[sum(f[z] for z in q) for q in Q];mu=[rw[u]/m[u] for u in range(len(Q))]
 sig=[rw[u]*m[u]/len(Q[u]) for u in range(len(Q))]
 T=[[sum(mu[w] for w in range(len(Q)) if m[w]<=m[u] and y in Q[w]) for y in range(8)] for u in range(len(Q))]
 C=[[[sum(mu[w] for w in range(len(Q)) if m[w]<m[u]/K and y in Q[w] and z in Q[w]) for z in range(8)] for y in range(8)] for u in range(len(Q))]
 edges=[]
 for u in range(len(Q)):
  for y in Q[u]:
   row=F(0)
   for v in range(len(Q)):
    if y in Q[v] and m[u]>K*m[v] and F(1,8)*T[u][y]<T[v][y]<=beta*T[u][y]:
     ell=mu[v]/T[u][y];row+=ell;edges.append((u,v,y,ell))
   assert row<=beta
 counts['sourcewise_rows']+=1
 J=sum(sig[u]*f[y]*f[z]*C[u][y][z]/m[u]**2 for u in range(len(Q)) for y in Q[u] for z in Q[u])
 for h,cut in product([F(1,20),F(1,5),F(1)],[F(0),F(1,10),F(1,2)]):
  paid=res=whole=F(0)
  thresholds=[F(0),F(1),F(2),F(4),F(6)]
  bs=[[ (min(f[z],thresholds[i])-min(f[z],thresholds[i-1]))/f[z]*max(F(0),1-F(i+1,8+z)) for z in range(8)] for i in range(1,len(thresholds))]
  assert all(sum(b[z] for b in bs)<=1 for z in range(8))
  for i,b in enumerate(bs):
   for u,v,y,ell in edges:
    # Decreasing actual endpoint restrictions in this finite diagnostic.
    if u%4<i or v%4<i: continue
    for z in Q[u]-Q[v]:
     Z=sum(mu[w] for w in range(len(Q)) if m[w]<m[u]/K and z in Q[w])
     wt=sig[u]*f[y]/m[u]*ell*f[z]/m[u]*b[z]*(Z>cut)
     phi=min(F(1),C[u][y][z]/h)
     paid+=wt*phi;res+=wt*(1-phi);whole+=wt
  assert paid+res==whole and paid<=beta*J/h
  positive+=paid>0
  counts['marked_external']+=1
assert positive>0
print('PASS',counts,'total',sum(counts.values()),'positive_paid_cases',positive)
