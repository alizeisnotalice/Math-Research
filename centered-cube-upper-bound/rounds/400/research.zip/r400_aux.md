# R400 — exact exclusive-past routing, and its unpriced first-moment tail

**Outcome.** The current H_small^(1−ψ) has a legitimate source-preserving route through actual smaller receivers which capture the old source but miss the new source. Its normalizing rank is uniformly positive. However, the complete-source cost of this route contains a first-moment mass tail, not R399's squared-overlap tail. The estimate below is not a new root receipt and is not inserted in the ledger.

## 1. Candidate and actual source conditions

Freeze all fields, marks and measures of `/tmp/r399_geometry.md`. Write ε=ε0, assume 0<ε<1, and set K=e^sqrt(n), h=(1+sqrt(n))/(εq_-). For a small endpoint v and its two actual sources y,z, put

Z_v(y)=∫c_w(y)1_{m_w<m_v/K} μ(dw),
C_v(y,z)=∫c_w(y)c_w(z)1_{m_w<m_v/K} μ(dw),
E_v(y,z)=Z_v(y)−C_v(y,z)
         =∫c_w(y)(1−c_w(z))1_{m_w<m_v/K} μ(dw).

Here μ(dw)=dw/m_w and every m_w=f(Q_w)=q_wR_w^n is the original full matched mass. All integrations over receiver centers use real dw. The native closed mass-window bound gives

T_v(y)−Z_v(y)≤(1+log K)/q_-=εh.

On the positive actual remaining traffic, the original mark k_i(v,y) entails T_v(y)>2h, and 1−ψ_v>0 entails C_v(y,z)<h. Consequently

E_v(y,z)>(1−ε)h.                                         (1)

The new source also satisfies T_v(z)>Lh. If L>1+ε, the reverse exclusive rank Z_v(z)−C_v(y,z)>(L−1−ε)h follows. It is not needed for the one-sided route below; it is not discarded from the original traffic. No original clock or history qualification is inferred for w or transferred from y to z.

The screened candidate is to use (1) to route the remainder and pay the resulting actual exclusive-capture moment by native center capacity. The precise calculation in §3 shows why the available capacity does not yet provide the requested budget.

## 2. Exact positive route retaining the original marks

Let

A_i(v,y,z)=k_i(v,y)b_i(z)1_{T_v(z)>Lh}(1−C_v(y,z)/h)_+.

Thus H_rem=Σ_i∫σ(dv)π_v(dy)π_v(dz)A_i is exactly the R399 remainder H_small^(1−ψ). Define the positive marked measure

dΞ_i=σ(dv)π_v(dy)π_v(dz) A_i(v,y,z)
       ·[c_w(y)(1−c_w(z))1_{m_w<m_v/K}/E_v(y,z)] μ(dw),    (2)

with zero integrand off the live support. Equation (1) makes the denominator safe. Its w-marginal integrates to one for every live (v,y,z), so

Σ_i Ξ_i(total)=H_rem.                                    (3)

All old labels may be retained before the disintegration defining k_i; the extra w kernel depends only on their displayed v,y,z and does not alter their measure. In particular (2) neither renormalizes f nor restarts an old qualified transition.

Since k_i≤C_col, Σ_i b_i(z)≤1, and all additional factors are positive restrictions, (1)–(3) imply

H_rem≤ C_col/[(1−ε)h] · F_ex,
F_ex=∫σ(dv) E_{π_v⊗π_v} E_v(y,z).                       (4)

This is a bound, not a claim that deleting the marks preserves equality.

## 3. Full-source integration and the remaining cost

Put I_vw=f(Q_v∩Q_w). The exact posterior calculation is

F_ex=∫ μ(dw)∫_{m_v>K m_w} q_v
                    I_vw(m_v−I_vw)/m_v² dv.              (5)

It uses the complete full-f mass m_v for the new source integral over Q_v\Q_w. Arbitrary concentration of f is allowed. In particular this is a mass product, never a boundary-volume estimate.

To see the distinction from the R399 paid moment, define

J_one=∫ μ(dw)∫_{m_v>K m_w}q_v I_vw/m_v dv,
J_two=∫ μ(dw)∫_{m_v>K m_w}q_v I_vw²/m_v² dv.

Both are finite in this bounded-radius finite-center setting, and F_ex=J_one−J_two. J_two is exactly the joint common-past moment used in R399. Its previous positive receipt is not subtracted a second time from the original BH. In (5) the complementary mass is m_v−I_vw, which cannot be bounded by m_w: the actual far gate gives I_vw≤m_w<m_v/K, hence the complementary mass is at least (1−1/K)m_v. Thus the cancellation removes at most a 1/K fraction of the first-moment integrand:

(1−1/K)J_one≤F_ex≤J_one.                                 (6)

This explains the missing decay without introducing any source-density hypothesis or a counterexample family.

Here is the native price currently available for J_one. Set m_+=λb^n and

ℓ(M)=1+log(m_+/M) if 0<M<m_+, and ℓ(M)=0 if M≥m_+.

For every source z, actual capture and matching imply

∫q_v c_v(z)1_{m_v>M} dv/m_v≤(λ/q_-)ℓ(M).                 (7)

For M<m_+, dominate by λ/max(M,q_-t), supported on t≤m_+/q_-, with t=(2||v−z||∞)^n and real center-volume measure dt. Its integral is exactly the right side. For M≥m_+ the original integral vanishes. The strict cutoff, arbitrary mass atoms, and the endpoint at m_+ are therefore all retained safely.

Using I_vw=∫f(z)c_w(z)c_v(z)dz, (7) and ∫fc_w=m_w gives

F_ex≤J_one≤(λ/q_-)∫_E ℓ(Km_w) dw.                        (8)

Thus (4) yields the explicit, but generally nonabsorbing, bound

H_rem≤ [C_col λ/((1−ε)q_-h)]∫_E ℓ(Km_w) dw.              (9)

The largest possible logarithm is log(λ/q_-)+n log(b/a)−sqrt(n), when positive. After dividing by h, its crude X_q coefficient is O(ε sqrt(n)), not a dimension-uniform arbitrarily small constant. Formula (9) is not claimed to be the optimal bound, nor to imply the actual traffic is large. It identifies the specific unpaid first-moment tail created by this proposed route.

The unused high-rank condition T_v(z)>Lh and the complete original k_i,b_i could only improve (4); a new joint geometric estimate exploiting them would be required to avoid (8). No such estimate is proved here. Both the full H_rem and the separate H_ext therefore remain in the R399 ledger unchanged. This note does not add a conditional special family, another cluster-spectrum reduction, or any fee to that ledger.

## 4. Minimal local algebra check

A standard-library Python Fraction check was actually run with posterior source masses (1/6,1/3,1/2), three receiver capture indicators (1,1,0), (0,1,0), (1,0,1), and occupation weights (2/3,3/4,1/5). Direct double-source summation of exclusive capture and the single-receiver formula p_w(1−p_w) both equal 17/45. This only checks the exact mass-product identity in (5); it is not a native core/high-history realization. The analytic argument above supplies the real-center and atomic threshold justification. No further numerical exploration was performed.
