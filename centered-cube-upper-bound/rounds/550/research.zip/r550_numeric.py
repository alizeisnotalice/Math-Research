import sys,time,platform,json,hashlib,functools
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy,sympy as sp,flint
from scipy.optimize import linprog
from flint import arb,ctx
ctx.prec=256;START=time.monotonic();COMPARISONS=0
EMBEDDED_JSON='[{"L0_exact":"-60198517*sqrt(3)/84672000 - 861599*sqrt(21)/8467200 - 1908337*sqrt(10)/14112000 - 909217*sqrt(5)/9408000 - 107*sqrt(30)/7200 - sqrt(15)/480 + 551*sqrt(7)/70560 + 2287*sqrt(70)/705600 + sqrt(210)/288 + 29*sqrt(105)/2880 + 7902029*sqrt(6)/169344000 + 11876159*sqrt(14)/169344000 + 14551*sqrt(35)/225792 + 944353/2116800 + 10547503*sqrt(2)/28224000 + 403691*sqrt(42)/3386880","N":4,"X_exact":"-3*sqrt(3)/10 - 3*sqrt(14)/32 - sqrt(5)/8 - sqrt(35)/32 - sqrt(21)/32 - 9*sqrt(6)/160 + 3*sqrt(10)/160 + sqrt(2)/2 + 773/400","masses":["1/2","1/4","1/8","1/8"],"name":"four_source_multiscale","positions":[["0","0"],["13/20","1/20"],["3/4","2/5"],["-1/5","1/2"]],"roots":[{"mask":1,"mass":"1/2","w_exact":"-13*sqrt(10)/160 - sqrt(3)/8 - sqrt(6)/16 - sqrt(5)/16 + sqrt(35)/32 + sqrt(42)/32 + 37/160 + 23*sqrt(2)/80"},{"mask":2,"mass":"1/4","w_exact":"-9*sqrt(6)/80 - 3*sqrt(3)/20 + sqrt(21)/32 + sqrt(42)/32 + 257/800"},{"mask":3,"mass":"3/4","w_exact":"-sqrt(42)/16 - 249/800 + 3*sqrt(3)/80 + 31*sqrt(14)/160"},{"mask":4,"mass":"1/8","w_exact":"-sqrt(3)/16 + 1/16 + 7*sqrt(2)/80"},{"mask":6,"mass":"3/8","w_exact":"-sqrt(21)/16 - 1/25 + 7*sqrt(14)/160 + 19*sqrt(6)/160"},{"mask":7,"mass":"7/8","w_exact":"153/160 - 37*sqrt(14)/160"},{"mask":8,"mass":"1/8","w_exact":"-sqrt(5)/16 + 1/16 + sqrt(2)/8"},{"mask":9,"mass":"5/8","w_exact":"-sqrt(35)/16 - 1/80 + sqrt(14)/16 + sqrt(10)/10"},{"mask":11,"mass":"7/8","w_exact":"51/80 - 13*sqrt(14)/80"},{"mask":15,"mass":"1","w_exact":"1/40"}],"source_capture_label_unique":true,"source_grid_shape":[21,19],"source_occupied_cells":297}]'
PROVENANCE={'source_filename': '/tmp/r546_flow_numeric.json', 'source_sha256': 'e64e82c1b4f49c616d2cce208e0b125f6475870992eb25b8ab0fc4ac780d3ca8', 'embedded_data_sha256': '3232def3df5f53a50c87d3864a422b89aad5dd6eeeb89ec0a3abd104bb7f9010', 'provenance': 'Only the actually used N4 exact root-area input is embedded. Root areas originate from the R546 verified complete Lebesgue receiving grid; the source-file hash and original R548 four-input embedded hash are retained. This script reconstructs only N4 necessary endpoints.', 'original_four_input_embedded_sha256': '32dc9e841ef9456dbfc57f1ee22463f1dff577812f721ef22a22d1b70d0d7b9e', 'single_N4_normalized_sha256': '28df33026b995fae94953a1b91fef6fb5d5e94afaf65863da16ea6b913a14e86'}
DATA=json.loads(EMBEDDED_JSON)
assert hashlib.sha256(EMBEDDED_JSON.encode()).hexdigest()==PROVENANCE["embedded_data_sha256"]

def ev(e):
 e=sp.sympify(e)
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ev(v) for v in e.args),arb(0))
 if e.is_Mul:
  z=arb(1)
  for v in e.args:z*=ev(v)
  return z
 if e.is_Pow:
  a,b=e.args
  if b.is_Rational:return ev(a).root(int(b.q))**int(b.p)
 raise ValueError(str(e))
def cmp(a,b):
 global COMPARISONS
 COMPARISONS+=1;d=ev(a)-ev(b)
 if d>0:return 1
 if d<0:return -1
 exact=sp.simplify(a-b)
 if exact==0:return 0
 if exact.is_positive:return 1
 if exact.is_negative:return -1
 # No tolerance is permitted; unresolved algebraic ordering aborts.
 raise ArithmeticError('Uncertified algebraic ordering '+str(exact))
def unique(v):
 out=[]
 for a in sorted(v,key=functools.cmp_to_key(cmp)):
  if not out or cmp(a,out[-1])!=0:out.append(a)
 return out
def frac(q):return F(int(q.p),int(q.q))
def cexpr(e):return dict(exact=str(e),arb256=str(ev(e)),float=float(e))

inp=next(x for x in DATA if x['N']==4);N=4;x=[[sp.sympify(v) for v in p] for p in inp['positions']];m=list(map(sp.Rational,inp['masses']));mass={};boxes=[]
for S in range(1,1<<N):
 ids=[i for i in range(N) if S>>i&1];mass[S]=sum(m[i] for i in ids);half=sp.sqrt(mass[S])/2;lo=[max([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))-half for j in range(2)];hi=[min([x[i][j] for i in ids],key=functools.cmp_to_key(cmp))+half for j in range(2)];sg=[cmp(hi[j],lo[j]) for j in range(2)]
 if min(sg)>=0:boxes.append((S,lo,hi,min(sg)>0))
edges=[unique([b[k][j] for b in boxes for k in (1,2)]) for j in range(2)]
def rank(v,ed):return next(i for i,e in enumerate(ed) if cmp(v,e)==0)
ranks=[(S,[rank(lo[j],edges[j]) for j in range(2)],[rank(hi[j],edges[j]) for j in range(2)],positive) for S,lo,hi,positive in boxes];cells=[];areas={}
for ix in range(len(edges[0])-1):
 for iy in range(len(edges[1])-1):
  active=[S for S,lo,hi,positive in ranks if positive and lo[0]<=ix<hi[0] and lo[1]<=iy<hi[1]]
  if not active:continue
  best=max(active,key=lambda S:mass[S]);assert sum(mass[S]==mass[best] for S in active)==1
  area=(edges[0][ix+1]-edges[0][ix])*(edges[1][iy+1]-edges[1][iy]);areas[best]=areas.get(best,0)+area;cells.append((ix,iy,best))
areas={S:sp.expand(v) for S,v in areas.items()};reference={r['mask']:sp.sympify(r['w_exact']) for r in inp['roots']};assert set(areas)==set(reference)
assert all(sp.expand(areas[S]-reference[S])==0 for S in areas);X=sp.expand(sum(areas.values()));assert sp.expand(X-sp.sympify(inp['X_exact']))==0
count=32;selected_indices=[((2*k+1)*len(cells))//(2*count) for k in range(count)];assert len(set(selected_indices))==count;cubes=[]
for idx in selected_indices:
 ix,iy,S=cells[idx];y=[(edges[0][ix]+edges[0][ix+1])/2,(edges[1][iy]+edges[1][iy+1])/2];r=sp.sqrt(mass[S]);half=r/2;captured=[]
 for i in range(N):
  if all(cmp(abs(x[i][j]-y[j]),half)<=0 for j in range(2)):captured.append(i)
 label=sum(1<<i for i in captured);assert label==S and sum(m[i] for i in captured)==mass[S]
 all_witnesses=[SS for SS,lo,hi,_ in boxes if all(cmp(y[j],lo[j])>=0 and cmp(hi[j],y[j])>=0 for j in range(2))];assert max(mass[SS] for SS in all_witnesses)==mass[S]
 cubes.append(dict(cell_index=idx,cell_grid_index=[ix,iy],cell_intervals=[[edges[0][ix],edges[0][ix+1]],[edges[1][iy],edges[1][iy+1]]],center=y,root=r,volume=mass[S],capture_mask=S,lo=[v-half for v in y],hi=[v+half for v in y]))
# Closed incidence includes every endpoint, face and open rectangle mode.
ce=[unique([c[k][j] for c in cubes for k in ['lo','hi']]) for j in range(2)];cr=[([rank(c['lo'][j],ce[j]) for j in range(2)],[rank(c['hi'][j],ce[j]) for j in range(2)]) for c in cubes]
axisbits=[]
for axis in range(2):
 axisbits.append([sum(1<<j for j,(lo,hi) in enumerate(cr) if 2*lo[axis]<=mode<=2*hi[axis]) for mode in range(2*len(ce[axis])-1)])
signature_modes={};zero_modes=0
for ix,bx in enumerate(axisbits[0]):
 for iy,by in enumerate(axisbits[1]):
  sig=bx&by
  if sig:signature_modes.setdefault(sig,(ix,iy))
  else:zero_modes+=1
signatures=sorted(signature_modes);A=np.array([[int(sig>>j&1) for j in range(count)] for sig in signatures],dtype=int);vol=[frac(c['volume']) for c in cubes]
# Original source masses give a guaranteed dual cover, including source boundaries.
source_dual=[F(0)]*len(signatures)
for i in range(N):
 sig=sum(1<<j for j,c in enumerate(cubes) if all(cmp(x[i][a],c['lo'][a])>=0 and cmp(c['hi'][a],x[i][a])>=0 for a in range(2)));assert sig in signature_modes
 source_dual[signatures.index(sig)]+=frac(m[i])
assert all(sum(int(A[k,j])*source_dual[k] for k in range(len(A)))==vol[j] for j in range(count))
LP_CALLS=1;res=linprog(-np.array([float(v) for v in vol]),A_ub=A,b_ub=np.ones(len(A)),bounds=(0,None),method='highs');assert res.success
raw_a=[F(float(v)).limit_denominator(10**7) for v in res.x];raw_y=[F(float(-v)).limit_denominator(10**7) for v in res.ineqlin.marginals];a=[max(F(0),v) for v in raw_a];y=[max(F(0),v) for v in raw_y]
raw_crowd=[sum(int(row[j])*a[j] for j in range(count)) for row in A];scale=min(F(1),1/max(raw_crowd));a=[v*scale for v in a]
cover=[sum(int(A[k,j])*y[k] for k in range(len(A))) for j in range(count)];repair=max([F(0)]+[(vol[j]-cover[j])/vol[j] for j in range(count)]);y=[y[k]+repair*source_dual[k] for k in range(len(A))]
crowd=[sum(int(row[j])*a[j] for j in range(count)) for row in A];cover=[sum(int(A[k,j])*y[k] for k in range(len(A))) for j in range(count)];assert all(v>=0 for v in a+y) and all(v<=1 for v in crowd) and all(cover[j]>=vol[j] for j in range(count));primal=sum(v*w for v,w in zip(a,vol));dual=sum(y);gap=dual-primal;assert gap>=0

def mode_record(axis,mode):
 if mode%2==0:return dict(type='endpoint',coordinate=str(ce[axis][mode//2]))
 k=mode//2;return dict(type='open_interval',interval=[str(ce[axis][k]),str(ce[axis][k+1])],representative=str((ce[axis][k]+ce[axis][k+1])/2))
constraint_records=[]
for k,sig in enumerate(signatures):
 ix,iy=signature_modes[sig];constraint_records.append(dict(index=k,cube_indices=[j for j in range(count) if sig>>j&1],representative_modes=[mode_record(0,ix),mode_record(1,iy)],exact_primal_incidence_sum=str(crowd[k]),dual_cover_weight=str(y[k])))
cube_records=[dict(index=j,original_cell_index=c['cell_index'],cell_grid_index=c['cell_grid_index'],original_cell_intervals=[[str(v) for v in inter] for inter in c['cell_intervals']],center=[str(v) for v in c['center']],root_radius=str(c['root']),volume=str(c['volume']),capture_mask=c['capture_mask'],cube_lo=[str(v) for v in c['lo']],cube_hi=[str(v) for v in c['hi']],captured_mass_equals_volume=True,root_is_outermost_all_closed_witnesses=True,packing_weight=str(a[j]),dual_cover_value_for_cube=str(cover[j]),dual_cover_slack=str(cover[j]-vol[j])) for j,c in enumerate(cubes)]
input_hash=hashlib.sha256(json.dumps(inp,sort_keys=True,separators=(',',':')).encode()).hexdigest()
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sympy=sp.__version__,python_flint=flint.__version__),precision_bits=256,seed=None,input_provenance=PROVENANCE,N4_embedded_input_sha256=input_hash,input=dict(name=inp['name'],positions=inp['positions'],masses=inp['masses']),scope='One N4 input only, 32 deterministic real receiving-grid midpoint centers, one HiGHS optimization. Finite-family packing/dual-cover certificate, not the continuous-center wS model or the optimum over all roots; no general dimension or coverage assertion.',reconstruction=dict(reason='R548 embedded areas lack cell endpoints, so N4 receiving grid alone was minimally reconstructed from saved exact positions/masses.',nonempty_closed_receiving_boxes=len(boxes),positive_receiving_boxes=sum(b[3] for b in boxes),grid_shape=[len(e)-1 for e in edges],occupied_open_cells=len(cells),all_original_root_area_residuals_exact_zero=True,selection_rule='Index floor((2k+1)*occupied_cells/(2*32)), k=0..31, in lexicographic (x-cell,y-cell) order.',selected_cell_indices=selected_indices),closed_incidence=dict(axis_endpoint_counts=[len(e) for e in ce],axis_mode_counts=[len(v) for v in axisbits],total_point_face_open_modes=len(axisbits[0])*len(axisbits[1]),distinct_nonempty_patterns=len(signatures),zero_incidence_modes=zero_modes,outside_global_extent_incidence='zero',proof='For each axis, modes alternate exact endpoints and intervening open intervals. Closed cube containment is 2*lo_rank<=mode<=2*hi_rank. Product modes therefore exhaust all closed spatial incidence, including corner and face intersections.'),optimization=dict(HiGHS_calls=LP_CALLS,float_status=str(res.message),float_packing_objective=float(-res.fun),rational_reconstruction_max_denominator=10**7,primal_downscale_factor=str(scale),dual_source_cover_repair_multiplier=str(repair),raw_rational_primal_weights=[str(v) for v in raw_a],raw_rational_dual_weights=[str(v) for v in raw_y],exact_primal_objective=str(primal),exact_dual_objective=str(dual),strict_rational_gap=str(gap),finite_family_optimum_certified=gap==0,all_closed_incidence_constraints_exactly_checked=True,all_dual_cube_constraints_exactly_checked=True),comparison=dict(known_E_area=cexpr(X),packing_gain_over_E=cexpr(sp.Rational(primal.numerator,primal.denominator)/X),best_single_selected_parent_volume=str(max(vol)),gain_above_best_single_parent=str(primal-max(vol)),original_source_atomic_dual_cover_cost='1',note='Root criticality and closed pointwise packing imply objective<=mu(total)=1; the original atomic masses are an explicit feasible dual cover. Comparing packing value with |E| is only this requested finite diagnostic, not a coverage theorem for E.'),selected_cubes=cube_records,incidence_constraints=constraint_records,elapsed_seconds=time.monotonic()-START,algebraic_comparisons=COMPARISONS)
# Keep only the sparse dual certificate; full incidence is regenerated above.
full_records=out.pop('incidence_constraints')
out['sparse_dual_prices']=[r for r in full_records if r['dual_cover_weight']!='0']
out['incidence_verification_summary']=dict(checked_pattern_count=len(full_records),max_exact_primal_incidence=str(max(F(r['exact_primal_incidence_sum']) for r in full_records)),pattern_signature_sha256=hashlib.sha256(','.join(str(sum(1<<j for j in r['cube_indices'])) for r in full_records).encode()).hexdigest(),full_table_storage='Omitted; deterministic code regenerates every closed incidence pattern and checks exact feasibility.')
out['optimization']['raw_rational_dual_weights']=[dict(index=i,weight=v) for i,v in enumerate(out['optimization']['raw_rational_dual_weights']) if v!='0']
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(dict(cubes=count,occupied_cells=len(cells),patterns=len(A),packing=str(primal),cover=str(dual),gap=str(gap),best_single=str(max(vol)),ratio=float(sp.Rational(primal.numerator,primal.denominator)/X),elapsed=out['elapsed_seconds']),indent=2))
