# R374 independent audit — FINAL PASS

Status: FINAL PASS for the row-centered common plan, its target-cap2 receipt, exact mean-load gain, actual-geometric zero-credit equivalence, final ledger and bounded numerical/code review. The independent screen below preceded author proofs. No unresolved correction remains. Only this audit file was edited; no repository/other author file was changed. No uniform credit ratio, net improvement after changed fees/parameters, or general closure is certified.

## Row-centered plan and exact gain
Freeze R373 full-f actual hard fields and original omega/J/past/clock/receivers. Retain its shared actual-u reward0<=K_v(y,z)<=B=A_clock/h, L_v(y)>=K_v(y,z), with P_v=mu_v^+/d_v,U_v uniform Qv. At d_v=0 set the plan and contribution0. Write r(y)=E_U K(y,Z),col(z)=E_P K(Y,z),mean=E_PU K. Then

tau_row=d_v[1+(K-r)/B]P_v tensor U_v

is nonnegative, bounded by twice the product plan, and has source marginal d_vP_v=mu_v^+. Its target marginal is d_v[1+(col-mean)/B]U_v, which has total mass d_v and density in[0,2d_v] relative to U_v. It is generally NOT the old exact d_v U_v target. The joint construction is measurable from bounded parameterized kernels; no optimizer or independent per-u plan is involved. Original marks remain on source y and all source-derived fields are frozen.

The captured reward improves by

Xi_v=d_v E_P Var_U K/B.

This follows from E[K(K-r)]=E K^2-E r^2. With R373 doublecenter D=K-r-col+mean, orthogonality gives E_P Var_U K=E D^2+Var_U col. Thus Xi_v=2Delta_v+(d_v/B)Var_U col>=2Delta_v. The first marginal leaves the total old-source reward unchanged; L-K>=0 proves exact new bad=Gjoint-Xi>=0 and0<=Xi<=Gjoint, not just a comparison of signed objectives. All units are unchanged: B is a source-density reward, d dimensionless and integration dv gives the mass units of G. This gain is not old source-square credit.

## Correct changed price and ledger
At each actual pair the floor a<=min(p,1-d_v). The new captured-good integral is bounded both by its source mass d_v and by target cap2d_v p. Hence

a+good<=min(p,1-d_v)+min(d_v,2d_v p)<=3p-2p^2<=3p.

For p<=1/2 the maximum occurs at d=1-p and equals3p-2p^2; for p>=1/2 the stronger elementary bound is1, which is<=3p-2p^2. The uniform3Gamma template therefore replaces the R3732Gamma fee. It is not same-fee and not appended to another floor bill. The hard coefficient is epsilon0[2+(Cplus_n+3Gamma_n)/(1+sqrt(n))]. Reallocating epsilon0 with this denominator must simultaneously change h* and C338 and the precise original gates. Xi>=2Delta compares ONLY the same full fields, same h and same original masks; it does not compare different parameter specializations or prove a smaller full right-hand side after the extra Gamma cost. The original entrance2,outerLambda and independent fees remain.

## Genuine receiver-Lebesgue geometry: zero credit iff zero original remainder
For EACH fixed actual receiver u, its cube boundary has zero f(y)dy mass because f is L1. Tonelli against actual finite du then gives: for f-almost every y, y lies off the boundary of Qu for du-almost every u. This is exactly the required quantifier order, independent of v. For such y, c_u(z)->c_u(y) for du-a.e u as z->y. Since a>0,E has finite measure and A,omega are bounded, DCT gives K_v(y,z)->L_v(y) for every fixed v. The source mark may be irregular in y; it is FIXED during this z limit, so no continuity of J/past/omega in y is asserted.

For d_v>0,P_v is absolutely continuous with respect to fdy and is supported inside Qv apart from its null boundary. Thus P_v-a.e y has the above limit and is an INTERIOR point of Qv. If Var_U K_v(y,.)=0, the row is constant U_v-a.e. A full-Lebesgue-measure subset of Qv approaches any interior y, so the constant must equal the limit L_v(y). Its old product bad row is therefore0. Conversely product bad row0 and0<=K<=L imply K=L U-a.e and variance0. Integrating nonnegative quantities against P and actual dv (and omitting d=0) proves

Xi=0 iff Gjoint=0.

This uses actual cube continuity and absolute continuity of the source, not arbitrary finite incidence matrices or an independence hypothesis. It yields strict Xi>0 whenever Gjoint>0 at fixed parameters, but no uniform rate or fraction; small variance may coexist with a relatively large bad row. It is insufficient for the root-order budget.

## Reviewer-local arithmetic scope
A local standard-library Fraction calculation actually passed162 scalar cases:81 row-centered plans checked source/target marginals, positivity, target cap and the Xi=2Delta+column-variance identity;81(p,d) cases checked the3p-2p^2 envelope. These are finite algebra diagnostics, not a proof of geometric strictness or a native hard field, and are separate from author/parent counts. No author proof was read before this initial screen; final author review and byte binding follow below.

## Auxiliary shell-flow screen and bounded author review
Independently checked the shell identity and divergence price before reading /tmp/r374_source.md in full. PASS within its explicit assumptions, not a main payment. For actual parent/child masses mp>=mc, parent-only source mass equals(mp-mc)+child-only overhang. Nested edges have zero overhang; on mp>=K mc, child-only<=mc<=(mp-mc)/(K-1). Integrating one COMPLETE edge measure and its divergence gives Cmass=integral mI-integral mO, so Cshell<=K Cmass/(K-1)+Enear<=K integral mI/(K-1)+Enear. This is one global cancellation before bounds, not per-path repeated saving.

The final source note explicitly assumes actual-du absolutely continuous marginals, integral(mp+mc)dPi<infinity and finite inlet/outlet matched-mass integrals. These justify every signed equality; no infinite-flow potential cancellation is assumed. The pointwise correction(cp-cc)+cc(1-cp)=cp(1-cc) is exact, and Enear remains a genuine f-weighted source-entry count, not geometric volume or an inlet-only bill. The sufficient pointwise target cover and its finite small aggregate price are separate unproved requirements. On the original contributing common-source support cp=cc=1, this direct edge shell is exactly0, so the note correctly refuses to claim payment of the existing core. It neither reconstructs original history nor reuses the R373 coupling square. Its144 Fraction checks were actually rerun by the parent in the final record and use finite receiver path/quadrature diagnostics, not real-du cover existence. No correction found.


## Final principal theorem author review
Read /tmp/r374_geometry.md in full and its entire embedded code. PASS. One zero-mass wording clarification was requested and incorporated: d_v=0 zeroes its coupling/gain CONTRIBUTIONS; the raw K_v,L_v and global B need not vanish. The final reviewed hash is384a4ae6f3a1c6611b3ddeb81cd7a4a6c4b5a9b24b0f0ce48d3a0bfd63b2406d. The code and mathematical estimates did not change.

The actual center envelope bounds BOTH K and L by B=A_clock/h. Row centering preserves mu_v^+, not the old exact uniform target. The new target formula and density cap2d_vU_v are exact and are used in the changed template price. The reward gain is(d_v/B)E_P Var_U K. Orthogonal row/column decomposition yields exactly widehatDelta=2Delta+M, with M the uniform variance of E_P K. All marks stay on the original y and all actual-u rewards are combined before constructing the single v plan. Original fixed-target Delta has the SAME B,h,fields in this identity. No optimizer, independent per-u plan or new source input is involved.

The positive new bad integrand L-K gives widehatG=Gjoint-widehatDelta>=0 before any relaxed ledger is inserted. The floor bounds, source mass bound and target cap give min(1,3p-2p^2)<=3p, with the actual selector template paying3Gamma_n|E|/h. This REPLACES the previous2Gamma fee and old gain; one may compare complete old/new bounds but may not combine the stronger gain with the cheaper old template or use T2/old negative-square credit again. The author explicitly preserves this priority.

The zero-credit theorem is proved with the correct real geometry, not product-null diagonal evaluation. Actual cube boundaries have zero Lebesgue source volume for each u; Tonelli gives one Lebesgue-null y exception set for du-almost every u. For each remaining y, varying z to y holds omega_u(y) fixed, and finite-E/a>0 domination gives K_v(y,z)->L_v(y). P_v is absolutely continuous and supported inside Qv apart from its null boundary. A U_v-a.e constant row therefore has that SAME L value via an approaching full-measure sequence inside Qv. Conversely zero product-bad row forces K=L almost everywhere. Integrating nonnegative row measures gives widehatDelta=0 iff Gjoint=0, including d=0/empty contributions. No regularity of omega in y, source independence or quantitative coercivity is inferred. No lower bound for the relevant neighborhood's U mass or dimension-uniform ratio has been established.

The560 aggregate Fraction cases use actual interval/cell captures, nonconstant bounded diagnostic marks, finite quadrature,zero-surplus and mean-only cases. Their discrete diagonal/contact property is explicitly part of those captures; it is not offered as a proof for arbitrary unrelated kernels. Parent reports47 strict gains,4 mean-only strict cases. The theorem's true-dx proof above supplies the general strictness argument.

## Numeric common-transport LP audit
Read /tmp/r374_numeric.md, the complete numeric.py and MATLAB script, frozen input/output/result JSON and row-check script. PASS within the stated finite scope. The three source inputs are the previous exact SIGNED-primal matching sources, not the relaxed nested-shell lower sources. Full matching remains q=1; actual total W values are4,4,33/4, and the last is not silently reset to its former cap16. Every receiver cube and every positive-volume Cartesian source cell, including target cells where f=0, is retained.

The numeric constructor rebuilds full J,global strict past and omega from the same matching data and exact radius-clock interval weights plus terminal atom. In these q=1 fixtures m_u=R_u^n, so its h*m_u factor and mu_u/h coefficient are the correct h R_u^n and w_u/(h R_u^n). All-u aggregation precedes transport for each v. The exact entry reconciliation against old g dot x is checked, as are floor/surplus accounting and unchanged outer receiver weights. It is not a direct nonlinear source-reoptimization of Gjoint.

The finite canonical B=max K is a certified bound on these fixtures, not the theorem's real-du A_clock/h. The matrix plans define actual absolutely continuous measures on source/target product cells, while RECEIVER integration remains QUADRATURE. Fixed-target and target-cap2 are distinct feasible classes. Source rows remain equalities in both; cap2 target columns are UPPER constraints2dU. The MATLAB row-major/transposed flattening and Kronecker margin matrices match the Python indexing. Solver output is only a candidate.

Exact reconstruction keeps source rows, fixed target columns or detected saturated cap2 columns and then explicitly verifies ALL exact nonnegativity/margin/cap conditions. Any approximate-support/saturation choice can only pass if the resulting exact certificate is valid. Tight-support potentials and component-offset difference inequalities give alpha_i+beta_j<=cost_ij on EVERY cell pair. For cap2, beta_j<=0 has the correct lower-dual direction: used columns<=caps implies sum beta*used>=sum beta*caps. Slack columns require beta_j=0. The code explicitly checks these signs,slack complementarity,full weak-dual inequality and equality with the feasible primal value. Thus the20 zero gaps are finite rational optimality certificates, not solver statuses. All margin corrections are0 on supplied candidates. Cost-zero v cases have trivial product-feasible0 optimum and are not fabricated solver calls.

The final result JSON has141 construction+619 verification=760 grouped exact assertions and20 certificates. The recorded fixed-target optimal fractions of original G are1/4,1/4,39121/60288; cap2 fractions are0,0,661/1884. The positive2D cap2 lower bound applies ONLY to its frozen finite class. Old fixed-target lower bounds are not imported into cap2. Decimal fractions in notes are displays of saved exact rationals. No result supplies a native high-dimensional hard-field qualification,general exponent,uniform residual contraction or whole-source upper bound.

The622 parent row cases (81 initial,10 mean-only,90 larger nonuniform,441 envelope cases) are scalar finite algebra. Their row-max contact is IMPOSED for the nullspace diagnostic; it is not inferred for arbitrary measurable kernels. Source-flow144 cases verify only its conditional cost identity, not actual-du target coverage. The source/geometry standalone scripts match their unique final embedded blocks after stripping outer whitespace.

## Final ledger and complete evidence boundary
Read final main,ledger and README in full. PASS. The main formula is the complete replacement

BH<=Gjoint-widehatDelta+epsilon0[2+(Cplus_n+3Gamma_n)/(1+sqrt(n))]Xq+C338 W.

L_n allocation,epsilon0,h and C338 are synchronized with the3Gamma budget, with O_eta(sqrt(n log(n+2)))W source price. The original8lambda H W,2d_eff A_clock Wnu/H,entrance2 and outerLambda128/119 remain. Accordingly the credit is2Lambda widehatDelta, once. The comparison widehatDelta=2Delta+M is restricted to the same original fields/parameters; changing h changes the actual gates and gain. No claim that the whole new right side is always smaller despite the extra template price is made.

The parent reports actual successful local reruns of geometry560,source144,numeric prepare141 with unchanged input hash and verify619,plus the earlier row622. The intervening failed orchestration indentation attempt is not recorded as successful evidence. Reviewer162 scalar cases are separate and not added to parent counts. No full optimizer/check pipeline was redundantly rerun by this reviewer. Counted grouped assertions are not native hard-input samples or theorem counts. The final input provenance matches the bound R373 data below.

The unresolved object is still the exact positive widehatG. Qualitative strictness does not give a uniform ratio,iteration rate or bounded cumulative fee. The auxiliary actual shell-flow theorem has no constructed pointwise cover and no root inlet/near-overhang budget, so it is NOT inserted into the main ledger. General soft/crossing/entry,contract-exterior heavy/distance/low-pe/scale/threshold regimes,historical initial/deletion/future-source time atoms,H choice,source and physical-scale aggregation,outer integration,truncation and limiting obligations remain. No archive/Git,PDF compilation or publication is audited. No outstanding requested correction; final bounded disposition PASS.

## Frozen final byte bindings
SHA256 applies to the exact reviewed bytes; the audit is hashed separately after saving.

- `/tmp/r374_main.md` — `70e45352dee59ca6bb2989be5fef188ca074c481c372e52858856ad5a35b0e64`
- `/tmp/r374_ledger.md` — `f23edd4d1f99dd6eafd8e029c4758484d57dbc5de228dfff21c04a20b6777231`
- `/tmp/r374_readme.md` — `b9549c9468d79f3d55013241c566bd51a228cce4fbcf4f5cb6c9d124fc98b166`
- `/tmp/r374_geometry.md` — `384a4ae6f3a1c6611b3ddeb81cd7a4a6c4b5a9b24b0f0ce48d3a0bfd63b2406d`
- `/tmp/r374_source.md` — `e91799288fafd910cf9ab4c9fdaedf8bd6903849a6e3ab8770d159260dd5f6ac`
- `/tmp/r374_numeric.md` — `518c45e534f2e726e67a3b35575d8f76f6b611f943d09a3da37acee47eef5ee7`
- `/tmp/r374_geometry_check.py` — `cbe6d364f7e2d99be0ffda0c376f626148de795b8734b24aa3bfca940348d776`
- `/tmp/r374_source_check.py` — `f4b3b4d5358b768e393b0fdf437113001a139fbffb17902690e57f90c1850ec5`
- `/tmp/r374_row_check.py` — `e9dcef5916d6c0e2a8069c39669ec2835a0fb547f0070d3447eb1e2e71380cda`
- `/tmp/r374_numeric.py` — `38f8f6fa1712528b36c2355af1a94ecf3a0f875b97c002c7a2b645e666c750c4`
- `/tmp/r374_lp.m` — `d8618d6118bc66d808190649e6b866898b766e43a910b48b9ee3654e5340972e`
- `/tmp/r374_input.json` — `1d1cc4c717b8b30b479dde15ea40b03f7fff1bd1fc3e034f38d94539f51bc0c4`
- `/tmp/r374_output.json` — `c5e2c67f683c48403c92adea53950499ad014f05772fcc04ba7cedad5f3770a0`
- `/tmp/r374_result.json` — `18a6c0483c26838b04ce79a35a2e56aeb7405d1fb68659ce6b5b8d0e2778ba80`

Necessary inherited contracts and numeric provenance (bounded dependence review, not a full-history rerun):

- `/tmp/r373_source.md` — `beae8a77dc6f4fbcbf06d1b6747c46365cb7754011064be220d59d6e8f3c237a`
- `/tmp/r373_main.md` — `525c767a678882369118f23f8175878bbfcbd5d58adf2ff40a8f942ddfc8adfd`
- `/tmp/r373_ledger.md` — `55230deac9288f647b39c78022c39ebbe0564c1f7fe4fc6b4577f2c38075b66d`
- `/tmp/r373_audit.md` — `15ec23f2c80e7c18d80d07cb3f1366d65eae34cb9733efc90bff55288bf01496`
- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`
- `/tmp/r373_lp_input.json` — `00277b5dbeae37484787da6f622ced7a51ac04aee6f4d7d3edbbb170adda226d`
- `/tmp/r373_verified.json` — `af40ccbe75a92d88ca5b645d15e462cb0d47baefde3e8331c5dba1cf96c4113e`

Frozen FINAL PASS. Subsequent mathematical/byte changes require renewed review/binding. No further bounded task work remains.
