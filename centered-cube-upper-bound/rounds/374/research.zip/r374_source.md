# R374 — A shared shell-flow bill with explicit nonnested source overhang

## Outcome and scope

A globally additive cost estimate is available for a real receiver edge flow: its signed matching bill telescopes through the FULL divergence, while far-mass nonnested edges incur at most a 1/(K−1) fraction of that bill in actual source overhang. Nested edges incur none. This avoids multiplying the shell cost by the number of mass-rank steps or by the number of paths sharing an edge. Near-mass nonnested overhang remains an explicit actual-source cost.

The missing step is pointwise coverage of the R373 additive/common-source load. In particular, directly orienting the original common-capture receiver pair as a shell edge gives zero shell value at its common source, so the cost theorem alone cannot be inserted as payment of that load. No general root bound or new unconditional ledger receipt is claimed.

## 1. Frozen actual field and edge-flow assumptions

Use the same actual receiver field as R373: f≥0 is L1, Q_u is the cube with actual side a≤R_u≤b≤2a, m_u=f(Q_u)=q_uR_u^n with q_-≤q_u≤λ. All f-dependent J, strict past, clock and the R373 common coupling remain fixed. The following construction is for a proposed additional source-kernel cover; it does not replace those marks by receiver-only constants.

Let Π(dp,dc) be a nonnegative measure on ACTUAL receiver pairs, oriented parent to child, satisfying

    m_p≥m_c,
    ∫(m_p+m_c) dΠ<∞.

Assume the two marginals are absolutely continuous relative to real receiver Lebesgue measure. Let I and O be nonnegative actual receiver measures with finite matched-mass integrals and

    Π_first−Π_second=I−O                              (1)

as signed measures. No condition that I and O be disjoint is needed. This is a shared divergence identity for the complete flow, not a separate budget imposed on each path. It can be verified directly for a finite proposed certificate; no existence of such a useful flow is asserted.

The actual shell defect for an edge is

    o(p,c)=f(Q_c\Q_p),
    s(p,c)=f(Q_p\Q_c)=m_p−m_c+o(p,c).                (2)

These are source masses, never source-layer volumes. Define

    C_mass=∫(m_p−m_c)dΠ,
    C_shell=∫s(p,c)dΠ.

All quantities below are finite under the stated assumption, and

    C_mass=∫m dI−∫m dO≥0.                            (3)

This is the exact full matching bill. Shared interior receiver prices cancel before taking any upper bound.

## 2. General nonnested correction and its quantitative price

For any K>1 partition the edge measure, in this priority order, into

    N: Q_c⊂Q_p up to null sets;
    F: not N and m_p≥K m_c;
    M: the remaining edges (nonnested and m_p<K m_c).

Put E_near=∫_M o(p,c)dΠ. Then

    C_shell=C_mass+∫_F o dΠ+E_near
       ≤ [K/(K−1)] C_mass+E_near
       ≤ [K/(K−1)]∫m dI+E_near.                    (4)

Proof. On N, o=0. On F, regardless of center positions,

    o(p,c)≤m_c≤(m_p−m_c)/(K−1).                     (5)

Integrate (5), use nonnegativity of every edge mass difference, and then (3). This uses the matching masses of the same full f. It does not infer geometric containment from mass order.

For the original K=exp(√n), the extra far-edge factor is 1+1/(exp(√n)−1). In particular the entire far overhang cost is small relative to the global matching bill. No √n path-length multiplier is introduced. This is a quantitative extension of the nested-shell bill to nonnested far-mass edges, not an assertion that far edges automatically cover the original source load.

A more adaptive exact estimate, useful when the edge ratios vary, is

    ∫_F o dΠ≤∫_F (m_p−m_c)/(m_p/m_c−1) dΠ.

It can be sharper than replacing every ratio by K. Near-mass nonnested edges have no such uniform small multiplier; their actual E_near is retained in (4).

## 3. Pointwise positive correction and source meaning of the unpaid near cost

Define the signed divergence kernel and its nonnested correction by

    H(y)=∫[c_p(y)−c_c(y)]dΠ,
    R(y)=∫c_c(y)(1−c_p(y))dΠ.

Then exactly, almost everywhere,

    Ψ(y)=H(y)+R(y)=∫c_p(y)(1−c_c(y))dΠ≥0.            (6)

Moreover

    ∫fH=C_mass,
    ∫fR=∫o dΠ,
    ∫fΨ=C_shell.                                    (7)

The integral identities follow from Tonelli for the nonnegative pieces; the assumed matched-mass integrability makes the signed difference meaningful. By (1), H is the actual receiver price density I−O integrated against the corresponding cube captures. Thus (6) is the precise correction needed when a signed receiver-flow cover is made positive without actual containment.

For the remaining near edges,

    E_near=∫f(y) [∫_M c_c(y)(1−c_p(y))dΠ]dy.         (8)

This is a weighted count of actual source entries into a child that its parent misses. A thin geometric overhang does not bound (8), because f may concentrate there. The bound E_near≤∫_M m_c dΠ is valid but may charge every intermediate edge and hence need not inherit the telescoping gain of (3). It is not silently replaced by an inlet-only budget.

For a proposed nonnegative target kernel L(y), if one actually proves a pointwise cover

    L(y)≤c+∫α(u)c_u(y)du+Ψ(y),  c,α≥0,              (9)

then (4) gives the rigorous price

    ∫fL≤cW+∫αm du+[K/(K−1)]∫m dI+E_near.           (10)

All edge families, marginals and source corrections in (9) must be the same ones used in (10). This is a usable certificate with a fully additive bill, not an assumed certificate for the current L. It still needs root-quality bounds on its inlet price and on E_near, as well as the actual cover (9).

## 4. Why the original far-pair flow is not already such a cover

The original positive receiver-pair integrand retained by R373 contains c_u(y)c_v(y), with the strict-past and reciprocal-J weights at y. If it is assigned the direct edge p=u, c=v, then on its source support

    c_p(y)=c_c(y)=1,
    c_p(y)(1−c_c(y))=0.                              (11)

Thus this direct edge contributes NOTHING to Ψ at the very common source carrying the original load. This is an exact pointwise support fact, not an availability example or an assertion that no other edge family can work. It explains why the inexpensive far overhang in (4) alone cannot settle the additive/common-source load left by the R373 double-centering.

A successful use of (10) therefore needs OTHER actual receiver shells covering those common-source locations, with their full shared divergence accounted for. The finite R373 certificates did exactly this: their useful concentric shells were additional actual constraints, not automatically the original contributing pair. If the actual selector does not provide nested shells, equations (2),(6),(8) retain the genuine f-overhang cost rather than adding a fictitious intersection rectangle or a new cube average.

No construction has been proved here that both covers the general R373 remaining marked kernel and makes the right side of (10) ≤εX_q+C_ε√n polylog(n+2)W. The exact next geometric requirement is shared coverage by actual shells whose inlet matched-mass price and near-nonnested source-entry count are controlled. The R373 ledger is therefore unchanged. Its ω/J/past marks, new quadratic coupling credit, previous floor price and every old clock contribution remain intact; none is spent again in (4).

## 5. Exact local checks

The script builds complete source cells from actual interval endpoints, uses a single positive piecewise-constant L1 source for every mass and overhang, and aggregates many decreasing-mass paths into ONE shared flow before computing its divergence. It checks all cancellations, the pointwise corrected kernel, and (4) for several K. The uniform-source cases satisfy q=1 on every diagnostic cube. Nonuniform cases are exact source-algebra tests and are not asserted to satisfy the original narrow q-band/high-past branch. Receiver path weights are finite quadrature; they are not a replacement for real du in the theorem.

~~~python
from fractions import Fraction as F
from itertools import combinations

checks=0
cubes=[(c-r/2,c+r/2) for c in (F(-1,2),F(0),F(1,2)) for r in (F(1),F(3,2),F(2))]
ends=sorted(set([F(-2),F(2)]+[x for Q in cubes for x in Q]))
cells=list(zip(ends,ends[1:]))
mid=[(l+r)/2 for l,r in cells]
cap=[[int(l<=x<=r) for x in mid] for l,r in cubes]
for profile in range(3):
    source=[(r-l)*(F(1) if profile==0 else F(1+(i*(profile+1))%3)) for i,(l,r) in enumerate(cells)]
    mass=[sum(source[j]*cap[i][j] for j in range(len(cells))) for i in range(len(cubes))]
    over=[[sum(source[j]*cap[c][j]*(1-cap[p][j]) for j in range(len(cells))) for c in range(len(cubes))] for p in range(len(cubes))]
    for longest in (2,3,4):
        edge={}; inlet=[F(0)]*len(cubes); outlet=[F(0)]*len(cubes)
        for length in range(2,longest+1):
            for nodes in combinations(range(len(cubes)),length):
                path=sorted(nodes,key=lambda i:(-mass[i],i))
                if any(mass[p]<=mass[c] for p,c in zip(path,path[1:])): continue
                w=F(1,1+sum(nodes)+length)
                inlet[path[0]]+=w; outlet[path[-1]]+=w
                for p,c in zip(path,path[1:]): edge[p,c]=edge.get((p,c),F(0))+w
        first=[F(0)]*len(cubes); second=[F(0)]*len(cubes)
        for (p,c),w in edge.items(): first[p]+=w; second[c]+=w
        assert [first[i]-second[i] for i in range(len(cubes))]==[inlet[i]-outlet[i] for i in range(len(cubes))]; checks+=1
        cm=sum(w*(mass[p]-mass[c]) for (p,c),w in edge.items())
        root=sum(mass[i]*inlet[i] for i in range(len(cubes)))
        exitbill=sum(mass[i]*outlet[i] for i in range(len(cubes)))
        assert cm==root-exitbill>=0; checks+=1
        shell=sum(w*sum(source[j]*cap[p][j]*(1-cap[c][j]) for j in range(len(cells))) for (p,c),w in edge.items())
        returns=sum(w*over[p][c] for (p,c),w in edge.items())
        assert shell==cm+returns; checks+=1
        integrated=F(0)
        for j in range(len(cells)):
            div=sum(w*(cap[p][j]-cap[c][j]) for (p,c),w in edge.items())
            ret=sum(w*cap[c][j]*(1-cap[p][j]) for (p,c),w in edge.items())
            pos=sum(w*cap[p][j]*(1-cap[c][j]) for (p,c),w in edge.items())
            assert div+ret==pos>=0
            integrated+=source[j]*pos
        assert integrated==shell; checks+=1
        for K in (F(5,4),F(3,2),F(2),F(3)):
            far=F(0); near=F(0)
            for (p,c),w in edge.items():
                nested=cubes[p][0]<=cubes[c][0] and cubes[c][1]<=cubes[p][1]
                if nested: assert over[p][c]==0
                elif mass[p]>=K*mass[c]:
                    assert over[p][c]<=mass[c]<=(mass[p]-mass[c])/(K-1)
                    far+=w*over[p][c]
                else: near+=w*over[p][c]
            assert returns==far+near; checks+=1
            assert far<=cm/(K-1); checks+=1
            assert shell<=K*cm/(K-1)+near<=K*root/(K-1)+near; checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
~~~

Execution record: the embedded script was actually run with local Python 3 and returned `PASS 144 exact Fraction aggregate checks` (exit status 0). Per-cell and per-edge assertions inside aggregate checks are not separately counted.
