from fractions import Fraction as F
from itertools import combinations

checks=0
cubes=[(c-r/2,c+r/2) for c in (F(-1,2),F(0),F(1,2)) for r in (F(1),F(3,2),F(2))]
ends=sorted(set([F(-2),F(2)]+[x for Q in cubes for x in Q]))
cells=list(zip(ends,ends[1:]))
mid=[(l+r)/2 for l,r in cells]
cap=[[int(l<=x<=r) for x in mid] for l,r in cubes]
for profile in range(3):
    source=[(r-l)*(F(1) if profile==0 else F(1+(i*(profile+1))%3)) for i,(l,r) in enumerate(cells)]
    mass=[sum(source[j]*cap[i][j] for j in range(len(cells))) for i in range(len(cubes))]
    over=[[sum(source[j]*cap[c][j]*(1-cap[p][j]) for j in range(len(cells))) for c in range(len(cubes))] for p in range(len(cubes))]
    for longest in (2,3,4):
        edge={}; inlet=[F(0)]*len(cubes); outlet=[F(0)]*len(cubes)
        for length in range(2,longest+1):
            for nodes in combinations(range(len(cubes)),length):
                path=sorted(nodes,key=lambda i:(-mass[i],i))
                if any(mass[p]<=mass[c] for p,c in zip(path,path[1:])): continue
                w=F(1,1+sum(nodes)+length)
                inlet[path[0]]+=w; outlet[path[-1]]+=w
                for p,c in zip(path,path[1:]): edge[p,c]=edge.get((p,c),F(0))+w
        first=[F(0)]*len(cubes); second=[F(0)]*len(cubes)
        for (p,c),w in edge.items(): first[p]+=w; second[c]+=w
        assert [first[i]-second[i] for i in range(len(cubes))]==[inlet[i]-outlet[i] for i in range(len(cubes))]; checks+=1
        cm=sum(w*(mass[p]-mass[c]) for (p,c),w in edge.items())
        root=sum(mass[i]*inlet[i] for i in range(len(cubes)))
        exitbill=sum(mass[i]*outlet[i] for i in range(len(cubes)))
        assert cm==root-exitbill>=0; checks+=1
        shell=sum(w*sum(source[j]*cap[p][j]*(1-cap[c][j]) for j in range(len(cells))) for (p,c),w in edge.items())
        returns=sum(w*over[p][c] for (p,c),w in edge.items())
        assert shell==cm+returns; checks+=1
        integrated=F(0)
        for j in range(len(cells)):
            div=sum(w*(cap[p][j]-cap[c][j]) for (p,c),w in edge.items())
            ret=sum(w*cap[c][j]*(1-cap[p][j]) for (p,c),w in edge.items())
            pos=sum(w*cap[p][j]*(1-cap[c][j]) for (p,c),w in edge.items())
            assert div+ret==pos>=0
            integrated+=source[j]*pos
        assert integrated==shell; checks+=1
        for K in (F(5,4),F(3,2),F(2),F(3)):
            far=F(0); near=F(0)
            for (p,c),w in edge.items():
                nested=cubes[p][0]<=cubes[c][0] and cubes[c][1]<=cubes[p][1]
                if nested: assert over[p][c]==0
                elif mass[p]>=K*mass[c]:
                    assert over[p][c]<=mass[c]<=(mass[p]-mass[c])/(K-1)
                    far+=w*over[p][c]
                else: near+=w*over[p][c]
            assert returns==far+near; checks+=1
            assert far<=cm/(K-1); checks+=1
            assert shell<=K*cm/(K-1)+near<=K*root/(K-1)+near; checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
