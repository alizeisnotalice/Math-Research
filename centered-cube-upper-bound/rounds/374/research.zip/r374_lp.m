% Each v has ONE common transport objective summing ALL u and original marks.
r374_base=fileparts(mfilename('fullpath'));
r374_data=jsondecode(fileread(fullfile(r374_base,'r374_input.json')));
r374_options=optimoptions('linprog','Display','none');r374_results={};r374_count=0;
for r374_i=1:numel(r374_data.cases)
 r374_case=r374_data.cases(r374_i);
 for r374_j=1:numel(r374_case.plans)
  r374_p=r374_case.plans(r374_j);
  if ~r374_p.nonzero_cost,continue;end
  r374_cost=double(r374_p.cost_numeric);r374_rows=double(r374_p.row_numeric(:));r374_cols=double(r374_p.col_numeric(:));r374_nr=numel(r374_rows);r374_nc=numel(r374_cols);
  % Python uses row-major storage; reshape transpose before vectorizing.
  r374_f=reshape(r374_cost',[],1);
  r374_Aeq=[kron(speye(r374_nr),ones(1,r374_nc));kron(ones(1,r374_nr),speye(r374_nc))];
  [r374_x,r374_val,r374_flag,r374_info,r374_mult]=linprog(r374_f,[],[],r374_Aeq,[r374_rows;r374_cols],zeros(numel(r374_f),1),[],r374_options);
  r374_res=struct('name',r374_case.name,'v',r374_p.v,'mode','fixed','plan',r374_x,'dual_eqlin',r374_mult.eqlin,'exitflag',r374_flag,'value',r374_val);
  r374_count=r374_count+1;r374_results{r374_count}=r374_res;
  [r374_x,r374_val,r374_flag,r374_info,r374_mult]=linprog(r374_f,r374_Aeq(r374_nr+1:end,:),2*r374_cols,r374_Aeq(1:r374_nr,:),r374_rows,zeros(numel(r374_f),1),[],r374_options);
  r374_res=struct('name',r374_case.name,'v',r374_p.v,'mode','cap2','plan',r374_x,'dual_eqlin',r374_mult.eqlin,'exitflag',r374_flag,'value',r374_val);
  r374_count=r374_count+1;r374_results{r374_count}=r374_res;
 end
end
r374_fid=fopen(fullfile(r374_base,'r374_output.json'),'w');fwrite(r374_fid,jsonencode(struct('plans',[r374_results{:}])),'char');fclose(r374_fid);
fprintf('R374 completed %d common transport candidate LPs.\n',r374_count);
