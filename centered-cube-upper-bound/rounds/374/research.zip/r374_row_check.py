from fractions import Fraction as F
from itertools import product
import random
rng=random.Random(374)
counts={'initial':0,'mean_only':0,'expanded':0,'envelope':0}
def test(K,P,U,d,stage):
    B=max(max(row) for row in K) or F(1)
    rows=[sum(u*k for u,k in zip(U,row)) for row in K]
    cols=[sum(P[i]*K[i][j] for i in range(len(P))) for j in range(len(U))]
    mean=sum(p*r for p,r in zip(P,rows))
    D=[[K[i][j]-rows[i]-cols[j]+mean for j in range(len(U))] for i in range(len(P))]
    T=[[d*P[i]*U[j]*(1+(K[i][j]-rows[i])/B) for j in range(len(U))] for i in range(len(P))]
    assert all(t>=0 for row in T for t in row)
    assert [sum(row) for row in T]==[d*p for p in P]
    assert all(sum(T[i][j] for i in range(len(P)))==d*U[j]*(1+(cols[j]-mean)/B)<=2*d*U[j] for j in range(len(U)))
    oldreward=d*mean
    newreward=sum(T[i][j]*K[i][j] for i in range(len(P)) for j in range(len(U)))
    var=sum(P[i]*U[j]*(K[i][j]-rows[i])**2 for i in range(len(P)) for j in range(len(U)))
    dsq=sum(P[i]*U[j]*D[i][j]**2 for i in range(len(P)) for j in range(len(U)))
    cvar=sum(U[j]*(cols[j]-mean)**2 for j in range(len(U)))
    assert var==dsq+cvar and newreward-oldreward==d*var/B>=0
    L=[max(row) for row in K]; total=sum(d*p*l for p,l in zip(P,L))
    assert 0<=total-newreward<=total-oldreward
    # Essential-maximum contact imposed here as L=max row K; positive U.
    assert (d*var==0)==(total-oldreward==0)
    counts[stage]+=1
    return dsq,d*var/B
for vals in product([F(0),F(1,2),F(1)],repeat=4):
    test([list(vals[:2]),list(vals[2:])],[F(1,3),F(2,3)],[F(3,4),F(1,4)],F(2,5),'initial')
for j in range(1,11):
    dsq,gain=test([[F(0),F(j,10)]]*3,[F(1,6),F(1,3),F(1,2)],[F(2,5),F(3,5)],F(j,10),'mean_only')
    assert dsq==0 and gain>0
for nr,nc in [(2,4),(3,5),(5,7)]:
    for _ in range(30):
        p=[rng.randrange(1,10) for i in range(nr)];u=[rng.randrange(1,10) for j in range(nc)]
        P=[F(x,sum(p)) for x in p];U=[F(x,sum(u)) for x in u]
        K=[[F(rng.randrange(11),10) for j in range(nc)] for i in range(nr)]
        test(K,P,U,F(rng.randrange(11),10),'expanded')
for p,d in product([F(i,20) for i in range(21)],repeat=2):
    assert min(p,1-d)+min(d,2*d*p)<=3*p-2*p*p<=3*p
    counts['envelope']+=1
print('PASS',counts,'total',sum(counts.values()))
print('Exact finite algebra; no native hard-field or uniform coercivity claim.')
