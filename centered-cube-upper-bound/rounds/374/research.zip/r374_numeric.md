# R374 — common surplus transport, fixed target versus target-cap2

## Decision evidence

**The target constraint changes the result.** With the exact original finite diagnostic marks and the three frozen full-matching sources, fixed-target optimal coupling leaves substantial bad cost. Allowing target marginal **≤2dU_v** eliminates that cost in both 1D examples and substantially reduces it in 2D. Fixed-target lower certificates are NOT lower bounds for the new target-cap2 class.

| Stage | Original diagnostic G | Product bad / G | Canonical fixed-target bad / G | Fixed-target optimal bad / G | Row-tilt bad / G | Target-cap2 optimal bad / G |
|---|---:|---:|---:|---:|---:|---:|
| Equal 15 intervals | 41/4224 | .382453 | .358021 | 1/4 | .302490 | 0 |
| Weighted 15 intervals | 143287/11128320 | .380944 | .359940 | 1/4 | .314887 | 0 |
| Twelve 2D cubes | 1099/310080 | .789129 | .764792 | 39121/60288 ≈ .648902 | .680815 | 661/1884 ≈ .350849 |

Every decimal is only a display approximation to the saved exact rational. The fixed-target optima retain 738/1129, 859722/1310023, 39121/47575 of product G_joint. The target-cap2 optima instead retain 0, 0, 21152/47575. Thus the new marginal freedom is substantive in these samples; merely tuning a fixed-marginal coupling would have missed it. A strictly positive target-cap2 lower certificate remains for this 2D sample. Neither pattern is extrapolated to other dimensions or sources.

The invariant min(f,q) floor fractions of original G are respectively 1/2, 1/2, 533/10048. This floor is the already separated paid component, not itself an unpaid obstruction.

## Same actual sources and original finite marks

The input uses the three exact signed-primal sources certified in R373, with their same complete source cells, receiver cubes, quadrature weights and all matching equations. Source density on a cell is its certified source mass divided by its positive cell volume. These are genuine compact piecewise-constant L1 sources, not arbitrary source marks. Every actual receiver mass stays m_u=R_u^n, hence q_u=1. Their actual total source masses are 4, 4, and 33/4. The last is below its former total-mass cap 16 and is not reset to 16.

The first two fields have fifteen intervals and sixteen complete source cells. The expanded field has twelve 2D cubes and 208 complete source cells. We retain κ=6/5, H=h=1/16 in 1D, H=h=1/64 in 2D, the outside condition 2||u−v||∞>R_u, every physical prefix, strict global past, and the terminal clock atom from R373. These are **finite receiver quadrature diagnostic gates**, not the original high-dimensional native hard gate or full historical qualification. No arbitrary ω is inserted.

For each cell y the script reconstructs

    J_y(r)=Σ_{R_u≤r} w_u c_u(y)/m_u,
    Z_y(m_u/κ−)=Σ_{m_t<m_u/κ} w_t c_t(y)/m_t,
    ω_u(y)=h R_u^n Σ_{r≥R_u} ell_r 1{J_y(r)≥H}1{Z_y(m_u/κ−)>h}/J_y(r).

It verifies 0≤ω≤1. With the original pair mask S and A_uv=S(1−m_v/m_u), it builds the complete shared rewards

    K_v(y,z)=Σ_u [w_u/(h R_u^n)] A_uv ω_u(y)c_u(y)c_u(z),
    L_v(y)=Σ_u [w_u/(h R_u^n)] A_uv ω_u(y)c_u(y).

Every u is summed **before** transport optimization. Both receiver weights w_u and outer w_v remain. The exact entry reconciliation

    Σ_v w_v ∫ [f c_v/m_v] L_v = saved R373 g·x = G

passed for all three cases. The floor-plus-surplus decomposition also passed per v and globally.

## Original marginals and canonical fixed-target candidate

For every v,

    μ_v^+(dy)=(f−1)_+ c_v dy/m_v,
    d_v=μ_v^+(Q_v),     U_v(dz)=c_v(z)dz/R_v^n.

No v had d_v=0 here; the implementation skips such v if present. Source rows are the positive-surplus original cells. Target columns include **all** complete cells inside Q_v, even where f=0. The cost is L_v(y)−K_v(y,z). A rational matrix plan defines an absolutely continuous coupling by constant density on each positive-volume source/target product cell. These are exact continuum source/target-cell integrals; receiver integration remains quadrature.

The canonical tilt uses one explicitly computed finite bound per fixture, B=max_{v,y,z}K_v(y,z): 35/792, 71/1104, 21/272. This is **not** the general theorem's A_n/h. Finite receiver quadrature does not automatically inherit the actual-dx A_n envelope. Under P_v=μ_v^+/d_v, let r_v(y)=E_U K, c_v(z)=E_P K, and D_v=K−r_v−c_v+E K. The fixed-target tilt

    τ=d P_v⊗U_v [1+D_v/(2B)]

has both exact marginals and gain Δ=Σ_v w_v d_v E[D_v²]/(2B). Nonnegativity, zero conditional means and exact gain are verified. The three exact credits are

    17309/72990720,
    3371365903/12465886003200,
    29192821/338446614528.

The fixed-target optimal bad costs are 41/16896, 143287/44513280, 14413/6266880.

## New row tilt and genuinely relaxed target constraint

The row tilt is built on the SAME K and finite B:

    τ_row=d P_v⊗U_v [1+(K_v−r_v(y))/B].

It preserves source μ_v^+ exactly and has target marginal ≤2d_vU_v. It need not preserve the old target marginal. Every cellwise nonnegativity and cap inequality is checked. Its exact gain satisfies

    Gain_row = (d_v/B) E_P Var_U K_v
             = 2Δ_v + (d_v/B) Var_U c_v.

The extra column-mean credits, after summing outer weights, are respectively

    11017/36495360,
    44390838169/143357689036800,
    214622695/1015339843584.

This tests the newly available mean credit as well as the double-centred credit. The resulting row-tilt bad fractions are exactly 5953/19680, 96872615257/307642920480, 9358255/13745664.

The new target-cap2 LP retains source rows μ_v^+ and permits target columns ≤2d_vU_v. All v share neither a plan nor source marginal with other v; **within each v, one plan serves every u**. The ten nonzero-cost v are four, four and two across the stages. The other 32 have identically zero cost and trivial optimum. Ten fixed-target and ten target-cap2 LPs were actually run; no per-u optimizer was used.

Target-cap2 optimal bad costs are exactly

    0, 0, 4627/3720960.

These are lower than the fixed-target optima and no worse than the feasible row tilt. The result does not itself certify the general theorem's 3Γ template price; it tests the new feasible class on frozen real-source fields.

## Exact optimality and positive accounts

Python reconstructs plans over their positive supports and solves exact rational margin equations. All margin corrections are zero in this run. For fixed targets it constructs unrestricted row/column potentials with α_i+β_j≤cost. For target-cap2 it additionally verifies β_j≤0, equality β_j=0 on every slack target column, and the weak-dual value

    Σ_i row_i α_i + Σ_j (2 target_j) β_j.

The potentials are constructed from exact tight support and rational component difference constraints. Every pairwise inequality is checked. Feasible plan and dual values agree exactly for all twenty LPs. This proves finite optimality independently of solver status and floating tolerances.

For product, canonical fixed-target tilt, fixed-target optimum, row tilt, and target-cap2 optimum the complete positive account is

    G = invariant floor + transported paid surplus + bad.

It is incorrect to carry the old fixed-target lower bounds into the new class: the zero 1D target-cap2 optima explicitly show why. The 2D target-cap2 dual proves a positive unavoidable cost only within its present relaxed class and frozen fields.

## Actual execution and minimal reproduction

The final pipeline was prepare → MATLAB **20 LPs** → exact Python verify, followed by a fresh full rerun. It passed **141 construction + 619 verification = 760 exact grouped assertions**. Grouped vector checks count as one; tight-support equalities are separately counted. Float displays and solver flags are not included in this count.

- `r374_numeric.py`: standard-library construction and exact verification.
- `r374_lp.m`: MATLAB candidate generation; portable paths, no global clear/path reset.
- `r374_input.json`: necessary standalone frozen-field/marginal/cost snapshot.
- `r374_output.json`: twenty actual solver candidates.
- `r374_result.json`: exact plans, exact duals, decompositions and summary.

Copy these to one directory, run its MATLAB script, then:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r374_numeric.py

Optional `prepare` regenerates the snapshot from the frozen `r373_lp_input.json` and `r373_verified.json`, whose SHA256 provenance is recorded. Verify itself reads neither old scripts nor old R373 data. Nothing modifies R373.

Scope: genuine positive-volume L1 source/target cells, actual matching and the entire frozen finite ω/J/past/clock interface. This does not replace receiver quadrature by dx, supply native hard history, bound general full traffic, or establish a dimension exponent. It gives a concrete reason to prefer investigating target-cap relaxation over more fixed-target tuning, while retaining the positive 2D residual as an unresolved fixed-field diagnostic.
