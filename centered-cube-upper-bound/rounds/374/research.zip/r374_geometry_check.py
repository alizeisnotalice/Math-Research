from fractions import Fraction as F
from itertools import product

xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
U=[F(1,8)]*8
profiles=((4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),
          (0,0,1,3,0,0,1,3),(1,1,1,1,1,1,1,1),
          (4,4,0,0,0,0,0,0))
receivers=((F(-3,4),F(3,2)),(F(3,4),F(3,2)),
           (F(0),F(2)),(F(1,2),F(5,4)))
cap=[[F(int(abs(x-c)<=R/2)) for x in xs] for c,R in receivers]
weight_cases=((F(1),F(1),F(1),F(1)),
              (F(1,3),F(2,5),F(1,7),F(3,4)),
              (F(1),F(1),F(0),F(0)),
              (F(1),F(0),F(0),F(0)))
checks=strict=mean_only=0
for raw in profiles:
 f=list(map(F,raw));q=sum(U[i]*f[i] for i in range(8))
 plus=[U[i]*max(f[i]-q,F(0))/q for i in range(8)]
 dv=sum(plus);P=[x/dv for x in plus] if dv else U[:]
 for weights in weight_cases:
  B=sum(weights)
  for mode in range(4):
   om=[[F(1) if mode==0 else (F(0) if mode==1 else
        F((i+2*k+mode)%5,4)) for i in range(8)] for k in range(4)]
   aa=[[om[k][i]*cap[k][i] for i in range(8)] for k in range(4)]
   K=[[sum(weights[k]*aa[k][i]*cap[k][j] for k in range(4))
       for j in range(8)] for i in range(8)]
   L=[sum(weights[k]*aa[k][i] for k in range(4)) for i in range(8)]
   assert all(0<=K[i][j]<=L[i]<=B for i,j in product(range(8),repeat=2))
   assert all(K[i][i]==L[i] for i in range(8));checks+=1
   row=[sum(U[j]*K[i][j] for j in range(8)) for i in range(8)]
   col=[sum(P[i]*K[i][j] for i in range(8)) for j in range(8)]
   mean=sum(P[i]*row[i] for i in range(8))
   D=[[K[i][j]-row[i]-col[j]+mean for j in range(8)] for i in range(8)]
   T=[[dv*P[i]*U[j]*(1+(K[i][j]-row[i])/B)
       for j in range(8)] for i in range(8)]
   assert all(t>=0 for rr in T for t in rr)
   assert [sum(rr) for rr in T]==plus;checks+=1
   target=[sum(T[i][j] for i in range(8)) for j in range(8)]
   assert target==[dv*U[j]*(1+(col[j]-mean)/B) for j in range(8)]
   assert all(0<=target[j]<=2*dv*U[j] for j in range(8));checks+=1
   energy=sum(P[i]*U[j]*(K[i][j]-row[i])**2
              for i,j in product(range(8),repeat=2))
   gain=dv*energy/B
   delta=dv*sum(P[i]*U[j]*D[i][j]**2
                for i,j in product(range(8),repeat=2))/(2*B)
   mean_gain=dv*sum(U[j]*(col[j]-mean)**2 for j in range(8))/B
   assert gain==2*delta+mean_gain;checks+=1
   reward=sum(T[i][j]*K[i][j] for i,j in product(range(8),repeat=2))
   assert reward==dv*mean+gain;checks+=1
   old=sum(dv*P[i]*U[j]*(L[i]-K[i][j])
           for i,j in product(range(8),repeat=2))
   new=sum(T[i][j]*(L[i]-K[i][j])
           for i,j in product(range(8),repeat=2))
   assert 0<=new==old-gain
   assert (gain==0)==(old==0);checks+=1
   for k in range(4):
    p=sum(U[j]*cap[k][j] for j in range(8))
    floor=sum(U[i]*min(f[i],q)*aa[k][i]/q for i in range(8))
    good=sum(T[i][j]*aa[k][i]*cap[k][j]
             for i,j in product(range(8),repeat=2))
    assert floor+good<=3*p
    assert floor+good<=min(F(1),3*p-2*p*p)
   checks+=1
   strict+=gain>0
   mean_only+=gain>0 and delta==0
assert strict>0 and mean_only>0
print('PASS',checks,'aggregate Fraction checks;',strict,
      'strict gains;',mean_only,'mean-only strict gains')
