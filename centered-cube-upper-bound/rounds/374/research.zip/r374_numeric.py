#!/usr/bin/env python3
"""Original finite marked fields, ONE common surplus plan per small receiver."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,deque
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def rat(v):return F(0) if abs(v)<1e-10 else F(str(v)).limit_denominator(10**9)
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 old=read('r373_lp_input.json')['cases'];verified=read('r373_verified.json')['cases'];out=[]
 for case,sol in zip(old,verified):
  ck('frozen_case_identity',case['name']==sol['name']);n=case['n'];A=case['A'];N=len(A);vol=list(map(F,case['x0']));x=list(map(F,sol['signed']['source']));density=[a/b for a,b in zip(x,vol)];m=list(map(F,case['m']));rec=case['receivers'];w=[F(r['weight']) for r in rec];R=[F(r['R']) for r in rec];centers=[list(map(F,r['center'])) for r in rec];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(case['h']);H=F(case['H']);kap=F(case['kappa']);Q=len(vol)
  ck('actual_source_matching_every_receiver',all(dot(row,x)==rhs for row,rhs in zip(A,m)))
  # Reconstruct original omega, retaining FULL source-dependent prefix J and strict past.
  omega=[[F(0)]*Q for _ in range(N)]
  for u in range(N):
   for y in range(Q):
    past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
    if past<=h:continue
    for l,r in enumerate(radii):
     if r<R[u]:continue
     J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
     if J>=H:
      ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
      omega[u][y]+=h*m[u]*ell/J
  ck('actual_reconstructed_marks_in_unit_interval',all(0<=a<=1 for row in omega for a in row))
  plans=[];floor=F(0);surplus=F(0);diag=F(0);B=F(0);all_d=[]
  for v in range(N):
   target=[j for j in range(Q) if A[v][j]];U=[vol[j]/m[v] for j in target]
   plus=[j for j in target if density[j]>1];rows=[vol[j]*(density[j]-1)/m[v] for j in plus];d=sum(rows);all_d.append(d)
   ck('actual_surplus_mass_at_most_one',0<=d<=1)
   L=[F(0)]*Q;K=[[F(0) for j in target] for i in plus]
   for u in range(N):
    if not(m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]):continue
    coef=mu[u]*(1-m[v]/m[u])/h
    for y in target:L[y]+=coef*omega[u][y]*A[u][y]
    for i,y in enumerate(plus):
     for j,z in enumerate(target):K[i][j]+=coef*omega[u][y]*A[u][y]*A[u][z]
   fv=sum(vol[j]*min(density[j],F(1))/m[v]*L[j] for j in target);sv=sum(a*L[j] for a,j in zip(rows,plus));dv=sum(x[j]/m[v]*L[j] for j in target)
   ck('per_v_actual_floor_surplus_identity',fv+sv==dv)
   floor+=w[v]*fv;surplus+=w[v]*sv;diag+=w[v]*dv
   if not d:continue
   col=[d*a for a in U];lv=[L[y] for y in plus];cost=[[lv[i]-z for z in row] for i,row in enumerate(K)]
   ck('actual_common_reward_and_bad_nonnegative',all(0<=z<=lv[i] for i,row in enumerate(K) for z in row))
   B=max([B]+[z for row in K for z in row])
   plans.append(dict(v=v,weight=str(w[v]),d=str(d),source_cells=plus,target_cells=target,row=list(map(str,rows)),col=list(map(str,col)),U=list(map(str,U)),L=list(map(str,lv)),K=[list(map(str,row)) for row in K],cost=[list(map(str,row)) for row in cost],cost_numeric=[[float(z) for z in row] for row in cost],row_numeric=list(map(float,rows)),col_numeric=list(map(float,col)),nonzero_cost=any(z for row in cost for z in row)))
  original=dot(list(map(F,case['g'])),x)
  ck('entry_reconciliation_exact_original_g_source',diag==original)
  ck('global_floor_surplus_identity',floor+surplus==diag)
  out.append(dict(stage=case['stage'],name=case['name'],n=n,receivers=rec,A=A,volumes=list(map(str,vol)),source_mass=list(map(str,x)),source_density=list(map(str,density)),actual_W=str(sum(x)),W_constraint=case['W'],cells=case['cells'],omega=[list(map(str,row)) for row in omega],H=str(H),h=str(h),kappa=str(kap),B=str(B),floor=str(floor),surplus_diagonal=str(surplus),original_diagonal=str(diag),original_g_source=str(original),zero_d_receivers=sum(d==0 for d in all_d),plans=plans))
 data=dict(cases=out,provenance={p:sha(p) for p in ['r373_lp_input.json','r373_verified.json']},construction_checks=sum(COUNTS.values()),construction_check_counts=dict(COUNTS),scope='Full original finite diagnostic marks, exact full-matching sources. Positive-volume L1 source cells; finite receiver quadrature, not native hard branch. Fixed-target and target-cap2 common transport are separate classes. Both tilts use finite global B=max K, not general An/h.')
 (BASE/'r374_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PREPARED',exact_checks=sum(COUNTS.values()),cases=[dict(name=c['name'],plans=len(c['plans']),nonzero_cost_plans=sum(p['nonzero_cost'] for p in c['plans']),B=c['B'],floor=c['floor'],original=c['original_diagonal']) for c in out]),indent=2))
def solve_equalities(A,b):
 M=[list(map(F,row))+[F(v)] for row,v in zip(A,b)];nr=len(M);nc=len(M[0])-1;i=0;piv=[]
 for j in range(nc):
  k=next((k for k in range(i,nr) if M[k][j]),None)
  if k is None:continue
  M[i],M[k]=M[k],M[i];v=M[i][j];M[i]=[x/v for x in M[i]]
  for k in range(nr):
   if k!=i:
    v=M[k][j]
    if v:M[k]=[x-v*y for x,y in zip(M[k],M[i])]
  piv.append(j);i+=1
  if i==nr:break
 assert all(any(row[:nc]) or row[nc]==0 for row in M),'inconsistent support margin reconstruction'
 x=[F(0)]*nc
 for k,j in enumerate(piv):x[j]=M[k][-1]
 return x

def rational_transport(p,raw,cap2=False):
 rows=list(map(F,p['row']));cols=list(map(F,p['col']));cost=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols)
 vals=[rat(x) for x in raw['plan']];edges=[(i,j) for i in range(nr) for j in range(nc) if vals[i*nc+j]>0]
 eq=[[int(a==i) for a,b in edges] for i in range(nr)]+[[int(b==j) for a,b in edges] for j in range(nc)]
 vv=[vals[i*nc+j] for i,j in edges];rhs=rows+cols
 if cap2:
  approxcol=[sum(vals[i*nc+j] for i in range(nr)) for j in range(nc)];sat=[j for j in range(nc) if abs(float(approxcol[j]-2*cols[j]))<1e-9]
  eq=eq[:nr]+[eq[nr+j] for j in sat];rhs=rows+[2*cols[j] for j in sat]
 res=[b-dot(a,vv) for a,b in zip(eq,rhs)];corr=solve_equalities(eq,res);vv=[a+b for a,b in zip(vv,corr)];T=[[F(0)]*nc for i in range(nr)]
 for (i,j),a in zip(edges,vv):T[i][j]=a
 ck('optimal_plan_nonnegative',all(a>=0 for row in T for a in row));colused=[sum(T[i][j] for i in range(nr)) for j in range(nc)]
 ck('cap2_exact_source_and_column_upper' if cap2 else 'optimal_plan_both_exact_marginals',[sum(row) for row in T]==rows and (all(a<=2*b for a,b in zip(colused,cols)) if cap2 else colused==cols))
 # Exact weak-dual certificate from positive support: component offsets solve difference inequalities.
 adj=[[] for _ in range(nr+nc)]
 for i in range(nr):
  for j in range(nc):
   if T[i][j]>0:adj[i].append((nr+j,cost[i][j]));adj[nr+j].append((i,cost[i][j]))
 comp=[None]*(nr+nc);base=[F(0)]*(nr+nc);cc=0
 for start in range(nr+nc):
  if comp[start] is not None:continue
  comp[start]=cc;q=deque([start])
  while q:
   u=q.popleft()
   for v,c in adj[u]:
    if comp[v] is None:comp[v]=cc;base[v]=c-base[u];q.append(v)
    else:ck('dual_tight_support_consistency',base[u]+base[v]==c)
  cc+=1
 constraints=[(comp[i],comp[nr+j],cost[i][j]-base[i]-base[nr+j]) for i in range(nr) for j in range(nc)]
 if cap2:
  root=cc;cc+=1
  for j in range(nc):
   constraints.append((root,comp[nr+j],-base[nr+j])) # beta_j<=0
   if colused[j]<2*cols[j]:constraints.append((comp[nr+j],root,base[nr+j])) # slack implies beta_j=0
 offset=[F(0)]*cc
 for _ in range(cc):
  changed=False
  for a,b,c in constraints:
   if offset[a]>offset[b]+c:offset[a]=offset[b]+c;changed=True
  if not changed:break
 ck('dual_component_difference_constraints',all(offset[a]-offset[b]<=c for a,b,c in constraints))
 if cap2:
  anchor=offset[root];offset=[v-anchor for v in offset]
 rp=[base[i]+offset[comp[i]] for i in range(nr)];cp=[base[nr+j]-offset[comp[nr+j]] for j in range(nc)]
 if cap2:ck('cap2_dual_columns_nonpositive_and_slack_complementary',all(b<=0 for b in cp) and all(b==0 or u==2*c for b,u,c in zip(cp,colused,cols)))
 ck('exact_transport_dual_all_cell_pairs',all(rp[i]+cp[j]<=cost[i][j] for i in range(nr) for j in range(nc)))
 primal=sum(T[i][j]*cost[i][j] for i in range(nr) for j in range(nc));dual=dot(rows,rp)+dot([2*c for c in cols] if cap2 else cols,cp);ck('cap2_exact_primal_dual_zero_gap' if cap2 else 'exact_transport_primal_dual_zero_gap',primal==dual)
 return primal,dict(v=p['v'],mode='cap2' if cap2 else 'fixed',plan=[list(map(str,row)) for row in T],row_potential=list(map(str,rp)),column_potential=list(map(str,cp)),value=str(primal),margin_repair_nonzero=any(corr),exitflag=raw['exitflag'])
def verify():
 data=read('r374_input.json');raw=read('r374_output.json')['plans'];raw=[raw] if isinstance(raw,dict) else raw;lookup={(a['name'],a['v'],a['mode']):a for a in raw};summ=[];certs=[]
 for c in data['cases']:
  B=F(c['B']);productbad=F(0);gain=F(0);optbad=F(0);rowgain=F(0);capbad=F(0);per=[]
  for p in c['plans']:
   rows=list(map(F,p['row']));cols=list(map(F,p['col']));U=list(map(F,p['U']));L=list(map(F,p['L']));K=[list(map(F,row)) for row in p['K']];cost=[list(map(F,row)) for row in p['cost']];d=F(p['d']);P=[a/d for a in rows];nr=len(rows);nc=len(cols);wv=F(p['weight'])
   old=sum(rows[i]*U[j]*cost[i][j] for i in range(nr) for j in range(nc))
   if B:
    rmean=[dot(U,row) for row in K];cmean=[sum(P[i]*K[i][j] for i in range(nr)) for j in range(nc)];mean=dot(P,rmean);D=[[K[i][j]-rmean[i]-cmean[j]+mean for j in range(nc)] for i in range(nr)];T=[[rows[i]*U[j]*(1+D[i][j]/(2*B)) for j in range(nc)] for i in range(nr)]
    ck('canonical_zero_conditional_means',all(dot(U,row)==0 for row in D) and all(sum(P[i]*D[i][j] for i in range(nr))==0 for j in range(nc)))
    ck('canonical_plan_nonnegative_and_exact_both_marginals',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==rows and [sum(T[i][j] for i in range(nr)) for j in range(nc)]==cols)
    dv=d*sum(P[i]*U[j]*D[i][j]**2 for i in range(nr) for j in range(nc))/(2*B)
    new=sum(T[i][j]*cost[i][j] for i in range(nr) for j in range(nc));ck('canonical_exact_quadratic_gain',new==old-dv and new>=0)
    RT=[[rows[i]*U[j]*(1+(K[i][j]-rmean[i])/B) for j in range(nc)] for i in range(nr)]
    rcol=[sum(RT[i][j] for i in range(nr)) for j in range(nc)]
    ck('rowtilt_source_exact_target_cap2',all(a>=0 for row in RT for a in row) and [sum(row) for row in RT]==rows and all(a<=2*b for a,b in zip(rcol,cols)))
    rv=d*sum(P[i]*sum(U[j]*(K[i][j]-rmean[i])**2 for j in range(nc)) for i in range(nr))/B
    mc=d*sum(U[j]*(cmean[j]-mean)**2 for j in range(nc))/B
    rn=sum(RT[i][j]*cost[i][j] for i in range(nr) for j in range(nc))
    ck('rowtilt_exact_gain_and_column_mean_credit',rn==old-rv and rv==2*dv+mc and 0<=rn<=new)
   else:dv=rv=F(0);new=old;ck('zero_reward_zero_credit',all(z==0 for row in K for z in row))
   if p['nonzero_cost']:
    ob,cert=rational_transport(p,lookup[(c['name'],p['v'],'fixed')]);cert['name']=c['name'];certs.append(cert)
    cb,ccert=rational_transport(p,lookup[(c['name'],p['v'],'cap2')],cap2=True);ccert['name']=c['name'];certs.append(ccert)
   else:ob=cb=F(0);ck('zero_cost_plan_trivial_optimum',old==0)
   ck('common_optimal_no_worse_than_canonical_no_worse_than_product',0<=ob<=new<=old)
   ck('cap2_optimum_below_fixed_and_rowtilt',0<=cb<=ob and cb<=old-rv)
   productbad+=wv*old;gain+=wv*dv;optbad+=wv*ob;rowgain+=wv*rv;capbad+=wv*cb;per.append(dict(v=p['v'],d=str(d),product_bad=str(old),canonical_gain=str(dv),optimal_bad=str(ob),rowtilt_gain=str(rv),cap2_optimal_bad=str(cb)))
  floor=F(c['floor']);S=F(c['surplus_diagonal']);G=F(c['original_diagonal']);ck('all_three_positive_decompositions',G==floor+(S-productbad)+productbad==floor+(S-productbad+gain)+(productbad-gain)==floor+(S-optbad)+optbad)
  ck('global_credit_and_common_optimum_order',0<=optbad<=productbad-gain<=productbad<=G)
  ck('cap2_global_positive_decompositions',G==floor+(S-productbad+rowgain)+(productbad-rowgain)==floor+(S-capbad)+capbad)
  summ.append(dict(stage=c['stage'],name=c['name'],n=c['n'],receiver_count=len(c['receivers']),source_cells=len(c['volumes']),actual_source_W=c['actual_W'],constraint_W=c['W_constraint'],original_diagonal=str(G),floor=str(floor),surplus_diagonal=str(S),product_Gjoint=str(productbad),canonical_Delta=str(gain),canonical_bad=str(productbad-gain),optimal_common_bad=str(optbad),rowtilt_gain=str(rowgain),rowtilt_bad=str(productbad-rowgain),rowtilt_bad_fraction=str((productbad-rowgain)/G) if G else None,column_mean_credit=str(rowgain-2*gain),cap2_optimal_bad=str(capbad),cap2_optimal_bad_fraction=str(capbad/G) if G else None,cap2_optimal_fraction_of_product_bad=str(capbad/productbad) if productbad else None,product_paid_surplus=str(S-productbad),optimal_paid_surplus=str(S-optbad),floor_fraction=str(floor/G) if G else None,product_bad_fraction=str(productbad/G) if G else None,canonical_bad_fraction=str((productbad-gain)/G) if G else None,optimal_bad_fraction=str(optbad/G) if G else None,optimal_fraction_of_product_bad=str(optbad/productbad) if productbad else None,finite_canonical_B=c['B'],zero_d_receivers=c['zero_d_receivers'],per_receiver=per))
 result=dict(status='PASS',construction_exact_checks=data['construction_checks'],verification_exact_checks=sum(COUNTS.values()),total_exact_grouped_checks=data['construction_checks']+sum(COUNTS.values()),verification_check_counts=dict(COUNTS),summary=summ,optimal_transport_certificates=certs,scope=data['scope'],provenance=data['provenance'])
 (BASE/'r374_result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='optimal_transport_certificates'}|{'summary':[{k:v for k,v in c.items() if k!='per_receiver'} for c in summ]},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
