# 第373轮：共同耦合二次信用与完整总账

同一完整 f、真实 Lebesgue 接收集 E、原半径选择器、m/q、J、strict past、全部原门及物理时钟（含末端原子）固定。沿用第371轮符号。令
\[
\mu_v^+(dy)=\frac{(f(y)-q_v)_+1_{Q_v}(y)}{m_v}\,dy,
\quad d_v=\mu_v^+(Q_v),\quad P_v=\mu_v^+/d_v,
\quad U_v=1_{Q_v}dy/R_v^n.
\]
d_v=0时以下对应贡献为0。不要把新d_v与入口d_eff混同。

令A_uv=S(u,v)(1-m_v/m_u)，h=h_*，保留原omega_u(y)，并定义
\[
K_v(y,z)=\frac1h\int_E\frac{du}{R_u^n}A_{uv}\omega_u(y)1_{Q_u}(y)1_{Q_u}(z).
\]
取A_n=1+n log(b/a)，B=A_n/h>0。D_v为K_v在P_v和U_v下的双中心化：减去两个条件平均，加回总平均。新信用
\[
\Delta=\frac1{2B}\int_E d_v\iint D_v(y,z)^2P_v(dy)U_v(dz)\,dv\ge0.
\]
对应真实共同耦合为d_v[1+D_v/(2B)]P_v⊗U_v。它对所有u共用，第一边缘为mu_v^+，第二边缘为d_v U_v，不改变完整来源或任何原门。

从原G重新分解，精确新剩余为G_joint−Delta≥0；已付项联合界仍为2T0−T2≤2Gamma_n |E|/h。因此优先硬槽式为
\[
B_H(f,\nu)\le G_{joint}-\Delta+
\varepsilon_0\left[2+\frac{C_n^++2\Gamma_n}{1+\sqrt n}\right]X_q+C_{338}W.
\]
所有常数与第371轮相同，C_n^+<72，
\[
C_{338}=\frac\lambda{q_-}\{(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon_0+1+\sqrt n\},
\quad\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+
2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
新Delta只在这次重建后扣一次。它不是历史原捕获平方、路径回捕或已付T2的第二次信用；不在已扣Delta的新剩余之外再支付一次Delta。

设L_n=2+(72+2Gamma_n)/(1+sqrt(n))，仍取epsilon_0=eta/L_n，并同步h与C338。此硬槽系数仍至多eta，来源费O_eta(sqrt(n log(n+2)))W。没有额外耦合费，也没有把受限输入当作全体输入。

原入口仍为
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
+2(G_{joint}-\Delta)
+2\varepsilon_0[2+(C_n^++2\Gamma_n)/(1+\sqrt n)]X_q+2C_{338}W.
\]
全式再乘Lambda=128/119；新信用为2Lambda Delta，硬槽接收系数至多2Lambda eta。总吸收仍未经认证。

**独立缺口不变。** 未证明G_joint−Delta的根阶预算或Delta占剩余的统一比例；一般soft、crossing、原始入口连接、硬合同外重尾、宽距离/低pe/尺度比例与阈值补集、初始/删除跳跃/未来被删来源、H选择、来源及物理尺度聚合、外积分、截断和极限仍须各自解决。膨胀模板/其他候选耦合仅为替代加强，本优先式使用t=0的明确耦合，不混入其额外常数。
