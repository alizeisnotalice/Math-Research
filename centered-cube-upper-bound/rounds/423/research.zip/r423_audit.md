# R423 independent final audit

FINAL PASS — for the same-label all-generation cross-affinity positive receipt, its pathwise joint Gram consequence, the auxiliary Green tools, and the stated full account. No mixed-path W budget, general root-order closure, fixed paid fraction, history transfer, or automatic X-absorption balance is certified. Independent screening preceded all R423 author reading. This supersedes PRE for the frozen delivered statements; only reviewer audit files were edited.

## 1. Actual path law and complete-label payment

The original R413 support gives old Z_A(y)>(4−ε_0)h and new Z_A(z)>(L−ε_0)h, with ε_0≤1/2, L≥4 and C_A<h. Thus both initial exclusive denominators exceed h. The initial laws are probability measures dominated by ρ_y/h and ρ_z/h; they are not replaced by normalized versions of these envelopes. Every subsequent existing-node law is a subprobability: integrating an active transition of density at most ρ_x/h against its actual previous subprobability of mass at most 1 gives the same bound. Stopped nodes count once and contribute zero at later generations. Strict mass descent gives m_j<m_A/K^(j+1), including j=0.

The two paths are independent at generation under the original unconditioned conditional kernels on the full base ticket. Future/initial-pair restrictions of the final measure can destroy that independence; the proof retains them in the actual fee and drops them only for the upper bound before using product domination. It does not renormalize on a surviving event or give descendants new source/history qualifications. These distinctions are correctly present in main and geometry.

## 2. Native two-cut affinity moment and stage accounting

Independently derived the central estimate before author reading. Capture plus actual m_v≥q_-R_v^n implies, with center volume coordinate u=(2||v−x||∞)^n,
∫_{m_v<M}c_v(x)dv/√m_v≤∫_0^{M/q_-}(q_-u)^(-1/2)du=2√M/q_-.
The integrable center-origin singularity and strict cutoff cause no mass-atom problem. This is an actual selector envelope, not an independent side-length integration or a cap on f.

After full-f Tonelli, the raw moment equals m_A^(-2)∫IAw IAt Iwt/(m_w^(3/2)m_t^(3/2))dw dt. Using IAt≤m_t, the first center integral is at most 2m_w√M2/q_-. The remaining ∫IAw/√m_w dw is at most 2m_A√M1/q_- by parent matching. Hence the bound is exactly 4√(M1M2)/(m_Aq_-²). Full intersection Iwt, including source outside Q_A, is retained. There is no W/m_A substitution, extra λ, assumed posterior independence, or independent selected-radius choice.

All j,k≥0 sum to 1/[K(1−K^(-1/2))²]. The path-generating kernel and V depend on frozen A,y,z and the field, so after deleting positive stage-specific restrictions the SAME-z Σ_i b_i(z)≤1 and original a_i^e≤B_e give S=β+C_col once. No path length, stage/layer count, union factor 2, B_L, or τ^(-1) is added. This is an application of the original full-source endpoint envelope, not of a postfiltered normalized law.

On the SAME Π421, V is the finite measurable sum of all cross-chain affinities. The exact split χ=min(1,8V), 1−χ gives
P423≤Δ423 X_q,  Δ423=32S/[h²q_-²K(1−K^(-1/2))²].
The initial R421 soft fraction and every other actual label remain. The alternative single cross-capture candidate in PRE is not additionally charged or included in this delivered account.

## 3. Remaining joint frame, Green tool and account

On positive R423, V<1/8 and the retained soft weight is (1−8V)_+. Chain-internal absolute off-diagonal row sums are at most 2ρ/(1−ρ), ρ=K^(-1/2); a cross-chain row sum is at most V. Expansion for complex coefficients gives spectrum within 1±[2ρ/(1−ρ)+1/8]. For n≥9, the cubic Taylor lower sum for e^(3/2) is 67/16>4, so ρ<1/4. Thus [5/24,43/24] is valid. This applies to one actual combined pair of paths, not an arbitrary union of paths or different-parent families. The upper bound on a direct integral still carries its actual path-traffic measure; source-dependent point evaluation is not a free L²(f) test. The mixed W budget remains open.

The auxiliary's stronger Green measure bound with CLOSED rank T(m_b) passes. For a target atom, stop on B0∪{m≤m_b}; this absorbs at least max(h,T(m_b)) mass and contains the entire target atom. A target visit occurs only once; first-hit induction gives the claimed density. Nonatomic parts follow by fine bands of ratio<K and strict lower-rank limits; atoms are restored using the atom proof. Active starts only; the origin Dirac is excluded from G. The expected descendant count is ≤1+log(Z_v/h) by the decreasing right-rank integral, not a pathwise depth claim. The nonnormalized initial occupation bound (5) retains J(x); initial inactive rows, zero flow, whole atoms and terminal mass are correctly treated. These are tools, not a second receipt.

Read main/geometry/aux/README. C423=C421+Δ423, with Fhat and V413 unchanged, yields exactly the displayed G0/BH/entrance coefficients 16/32/64. The new entrance price is 64ΛFhatΔ423 X_q. All old source, entrance and external terms remain once; there is no new W fee, old-square refund or unverified absorption claim. README's execution wording was corrected to distinguish completed isolated replay from future final-ZIP extraction verification.

## 4. Actual independent replay and limits

Read all three delivered scripts, then copied and executed each in an isolated temporary directory. All stdout matched the supplied final results byte for byte (geometry's final .result.txt also matches its author stdout); the generated aux JSON matched exactly. Parent: 72 continuous-center/full-source raw-moment parameter bounds (12/24/36; 48 positive) and 24 soft-split/entrance algebra configurations. Aux: 60 atomic kernel models, 488 active starts, 337 multi-descendant starts, 11424 atom comparisons and 11 zero-active models. Geometry: 36 generation-subprobability models, 18 analytic native radial-envelope evaluations and 24 finite-source dual-chain Gram models. These are distinct evidence types, not a pooled sample total or a full original R421/history fixture.

The continuous parent models have exact nonuniform full-f matching and center-block integrals, including parent-exterior source pressure, but do not generate the original full path/stage/history conditions. Aux is mass-axis arithmetic. Finite Gram tests use real coefficients; the analytic complex-coefficient conclusion follows from the quadratic-form proof, not from those samples. Reviewer's temporary PRE 36 configurations/756 target checks are separate arithmetic and not added to author/parent counts. No final ZIP extraction, PDF compilation or Git operation was performed by this auditor.

## 5. Final byte bindings (SHA-256)

- `r423_main.md`: `e52bfc72017e1531968661bf6319760a665c9fa2046c0d306b803786dd8b4caf`
- `r423_readme.md`: `a5d76444a54209dc0ce1894f21884fc88ef61b85f5be50e84735f7fad84c237c`
- `r423_geometry.md`: `2acec9f4cf5a4efac4041efe0fbc2ec6a329570a2009aca3b45f11b2eb2b41d0`
- `r423_aux.md`: `0a9953e757529273b8a29075257c5878283566e08bb2848eb13019595d00a0e8`
- `r423_parent_check.py`: `26be26ef4159f48cea09fc10f28e62e4da9a6ca0f5792d68564d26178071b85e`
- `r423_aux_check.py`: `7ededa07452a866ba9acb1dd43279b13c8d7c7280909ed6e90a314a795a2d172`
- `r423_geometry_check.py`: `f0b9127d5f17eea64aed94b87856f8c1463b17946d436ddf7fda3888fdaa0681`
- `r423_parent.result.txt`: `7ea885fb77df8de1b8fd3dcc1b7455f831d4f1c53fe93328fa5db167dfe9f6cf`
- `r423_aux.result.txt`: `e43ad7c091fb73ef49a1589e56ab3fbf279cb8e986b3c07b4b6a725ebcc3c258`
- `r423_geometry.result.txt`: `89f7cfea1046ba03e3da624336a7ea81282a97035f0ad9df373820dafe644127`
- `r423_aux_result.json`: `833743d6f00ba1dba465f2eade703b8f65a11eee8230e3b5002a69562c2bb499`
- `r421_main.md`: `edb53a0ba24542b06ad7d8562480dd0346ff5256cd105227fb13ee0a9f135ab7`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
