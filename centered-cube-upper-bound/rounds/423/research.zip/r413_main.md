# 第413轮：双相对秩与当前来源密度预算

2026-10-20。一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未完成。本轮直接核验新附路线建议中的相对旧秩门，并推导新来源侧的对应闭秩门。两门前置后，原双见证两侧列界对维数一致，费用参数的增长仅为log(1/t)。另以可任意小的X价格取得当前端点条件密度的多项式控制，并一次性支付旧来源当前占用低的分支。这使411–412两轮的来源付款可在同一原场上重算为根阶；但真实占用层中未付联合费用的2^k因子尚未去掉，候选P未证明。

## 1. 冻结对象与准确计价范围

沿用完整f≥0、W=∫f、真实接收中心dA、a≤R_A≤b≤2a、m_A=f(Q_A)=q_AR_A^n、0<q_-≤q_A≤λ。记μ=dA/m_A、σ=q_AdA、π_A=f1_QA/m_A、X_q=∫σ，J(x)=∫c_A(x)μ(dA)，∫fJ=|E|≤X_q/q_-；r=λ/q_-，S=β+C_col。

K=e^(√n)，s=1+√n，h=s/(ε_0q_-)，0<ε_0≤1/2，L≥4，B0=ε_0h，A_n=1+nlog(b/a)。T_A(x)为闭质量CDF，Z_A(x)为严格m_b<m_A/K的过去，有0≤T_A−Z_A≤B0。所有原旧来源y、新来源z、原u/v端点、父端A、阶段、首次删除、时钟、来源远域、soft和历史标签均保留。

输入取R408完整实际early费用Θ。它已经保留R406的T_v(y)>4h+√(hJ(y))，不是抽象边流。原每条边全部阶段两端标记累计≤2；逐旧来源入列容量C_col，完整父两来源累计包络≤Sσ(dA)π_A(dy)π_A(dz)。包络只用于上界，不替换实际Θ。

## 2. 两个相对门及一次性价格

对0<κ_y,κ_z<1，在原Θ上按顺序保留
\[
G_y=\{T_v(y)>\kappa_yJ(y)\},\qquad
G_z=\{T_A(z)>\kappa_zJ(z)\}.
\]
G_z中的父A含原端点类型标签，两端使用各自闭CDF。未改变原场或阈值表。

由原逐旧来源入列与闭CDF子水平容量，
\[
R408[G_y^c]\le2C_{\rm col}\lambda\kappa_y\int fJ
\le2C_{\rm col}r\kappa_yX_q.
\]
这在任意可测κ_yJ≥0下直接用底层CDF证明，不把406定理的c≥4条件误移到此处。有限阶段保留原尚存边，按原清空结论取极限。原平方根门仍保留，新增门单独计价。

对新来源，在第一门之后使用共同阶段求和和父包络，并积分完整旧来源π_A概率：
\[
\begin{split}
R408[G_y\cap G_z^c]
&\le S\int f(z)\int q_Ac_A(z)1_{T_A(z)\le\kappa_zJ(z)}\mu(dA)dz\\
&\le S\lambda\kappa_z\int fJ
\le Sr\kappa_zX_q.
\end{split}
\]
这里S已包括两个父端，不再乘2。闭CDF包含等号整块原子，跨阈值原子不纳入子水平；零来源不贡献。若C_col=0，则原非负边流由入列容量为零而为空；单独作零流处理。以下为非零流。

定义Θ_rel=Θ1_Gy1_Gz，两个被移除支互斥。令
\[
\eta_{\rm gate}=2C_{\rm col}r\kappa_y+Sr\kappa_z.
\]
严格有R408≤|Θ_rel|+η_gate X_q。仅增加两门不意味着移除了固定正比例费用。

## 3. 两侧列界：保留严格过去以处理原子

在Θ_rel上构造与411完全相同的双exclusive概率核：旧侧w捕获y排斥z、新侧t捕获z排斥y，严格m_w,m_t<m_A/K，分母Z_A(y)−C_A(y,z)及Z_A(z)−C_A(y,z)。原soft正支C_A<h。原新来源门Z_A(z)>(L−ε_0)h保持。

旧侧由原Tv>4h与新增Tv>κ_yJ得到两种父均有
\[
Z_A(y)>(1-\varepsilon_0/4)\kappa_yJ(y),\qquad
\frac{T_A(y)}{Z_A(y)-h}\le\frac4{3-\varepsilon_0}.
\]
小端用Z_v≥T_v−ε_0h；大端Z_u≥T_v，且T_u−Z_u≤ε_0h，系数(4+ε_0)/3≤4/(3−ε_0)。完整推导见aux，旧/新来源不互换。

新侧设a_z=(L−ε_0)h。由T_A≤Z_A+B0≤[L/(L−ε_0)]Z_A及G_z，
\[
Z_A(z)>\theta_zJ(z),\quad \theta_z=\kappa_z(L-\varepsilon_0)/L,
\quad \frac{T_A(z)}{Z_A(z)-h}\le\frac{L}{L-\varepsilon_0-1}.
\]
对x=y或z，若Z_A(x)>θ_xJ(x)，严格far集包含于父质量原子的严格左侧，故闭CDF左秩>θ_xJ(x)。展开秩原子区间，
\[
\int\frac{c_A(x)}{T_A(x)}1_{Z_A(x)>\theta_xJ(x)}\mu(dA)
\le\log(1/\theta_x).
\]
没有漏掉首个跨越原子；若只保留闭T高门而不使用Z与左秩关系，则这一步不能无条件省略原子项。

按411原证明先共同阶段求和，保留源x并积分另一源及另一见证概率，最后换真实目标σπ测度，得到两侧整份列界
\[
\begin{split}
C_y^{\rm rel}&=Sr\frac4{3-\varepsilon_0}\log\frac1{(1-\varepsilon_0/4)\kappa_y},\\
C_z^{\rm rel}&=Sr\frac{L}{L-\varepsilon_0-1}\log\frac{L}{(L-\varepsilon_0)\kappa_z},\\
d\Lambda_x&\le C_x^{\rm rel}\sigma(dw)\pi_w(dx).
\end{split}
\]
常数不含维数、阶段数或占用层编号。它们仍是支配而非相等，也不是当前D_i(x)后验的密度界。全部原历史/来源联合标签在构造中保持。

## 3b. 当前端点密度与旧来源当前低占用的两步付款

对原方向e=u或v，以原Γ_i的逐端旧来源投影定义
\[
d\Gamma_i^e(A,y)=\sigma(dA)a_i^e(A,y)\pi_A(dy),\quad
0\le a_i^e\le B_e,\quad B_u=\beta,\ B_v=C_{\rm col},\quad
s_i^e(A)=\int a_i^e(A,y)\pi_A(dy).
\]
这些始终由原Γ_i定义；不因新增门或删支重算。原s_i=s_i^u+s_i^v递减，D_i(x)=∫σ(dA)s_i(A)c_A(x)/m_A。

取0<τ<1。先在原stage/父方向标签上删除s_i^e(A)≤τB_e。原early和首次删除求和上放到Γ_i，积分旧y得到s_i^e，然后按同一个A,z求和Σ_i b_i(z)≤1：
\[
P_{\rm marg,low}\le\sum_e\sum_i\int\sigma(dA)s_i^e(A)1_{s_i^e\le\tau B_e}\pi_A(b_i)
\le\tau SX_q.
\]
零B_e方向无费用。此费用无阶段数因子。高补集上a_i^e/s_i^e≤1/τ，故实际双来源费用可被
\[
\tau^{-1}\sum_i M_i(dy,dz)b_i(z),\qquad
M_i(dy,dz)=\sum_e\int\sigma(dA)s_i^e(A)\pi_A(dy)\pi_A(dz)
\]
支配。这里仅为上界删除其他正门；原费用空间中所有门仍在。原M_i为递减的对称正核，边缘恰为f(y)D_i(y)dy。由此确实获得当前旧来源密度相对fD_i的τ^{-1}控制，而不仅是全场J列界；它仍不等于原费用或授权来源刷新。

再支付同一stage实际费用中D_i(y)≤s的支。对固定y，令j(y)为该条件首次出现的阶段；不存在则该源没有此支。原D_i递减，故所有相关i≥j(y)。M_i的显式正积分定义给共同可测版本的source核M_i(y,dz)≤M_j(y)(y,dz)。于是先对同一z使用Σ_i b_i(z)≤1，再积分z：
\[
P_{\rm old,current\,low}\le\tau^{-1}\int f(y)D_{j(y)}(y)dy\le\frac{s}{\tau}W.
\]
这里M_i(y,dz)按f(y)dy分解；零来源直接置零。这是一次累计预算，不是每阶段sW。有限阶段先使用首次低值及完整原尚存边上界，后按原清空G_N↓0处理；源依赖j只是正积分分组，不是新的历史存活测试。剩余实际费用同时具有D_i(y)>s和D_i(z)>s，后者来自b_i(z)>0。详细核和数值范围见geometry附件。

## 4. 必须前置重算的分拆与总账

不能只在已删完其他分支的R412末尾加门，然后追溯减少旧支的价格。本轮从原R408先删除两低相对秩支，先支付上述stage低边缘支τSX_q及旧来源当前低占用支sW/τ，再对剩余依次重做原411–412同一分拆：

1. 初始双见证至少一中心在父内，仍≤Δin X_q；
2. 剩余中至少一见证自身过去≤h，≤P_low_rel W；
3. 剩余中至少一来源进入初始见证内缩盒，≤P_inner_rel W；
4. 剩余中固定来源降质量的终端中心返回原父，仍≤Δreturn X_q；
5. 最后完整余项R413。

所有核、α=(n+2)^(-1/(2n))及原场不变。两相对门、stage高边缘门和当前旧来源高占用门均是原标签事件，故与这些正限制和条件概率扩充可交换；最后R413等于原R412的这四个门的正限制，但前四支的重算均明确仅在Θ_rel上发生。完整账是替代分拆，不再加旧P_low/P_inner。

令D_rel=C_y_rel+C_z_rel，则
\[
P_{\rm low,rel}=\lambda(h+B0)D_{\rm rel},\quad
P_{\rm inner,rel}=r\frac{A_n}{\sqrt{n+2}}D_{\rm rel},\quad
\Delta_{\rm return}=\frac{2S}{q_-h}.
\]
Δin沿用411显式价格2A_nB_L/(q_-²h²)。同一原场下严格有
\[
R408\le R413+(\eta_{\rm gate}+\tau S+\Delta_{\rm in}+\Delta_{\rm return})X_q
 +(s/\tau+P_{\rm low,rel}+P_{\rm inner,rel})W.
\]
冻结κ_y,κ_z后两来源价格均为O(√n)，不再含log n。更重要的是门费用可调时的依赖是明确的：取0<t<t0=min(1,2C_col r,Sr)，κ_y=t/(4C_col r)、κ_z=t/(2Sr)，则η_gate=t，D_rel≤C(1+log(1/t))，常数仅依赖冻结参数。若再取τ=t/S且t<S，stage低边缘另付tX_q，当前旧源低占用付(S/t)sW；新增门总X价格为2t，所有新来源系数至多多项式t^(-1)。如需总门价格恰为tX_q，将此参数统一换成t/2。仍未证明整个R408或R413的预算，也未去除原占用层2^k。

设
\[
C_{413}=C406+\eta_{\rm gate}+\tau S+\Delta_{\rm in}+\Delta_{\rm return},\qquad
V_{413}=V406+s/\tau+P_{\rm low,rel}+P_{\rm inner,rel}.
\]
Fδ=(1−32δ)^−1，C406=χ_n+Δ404+η_1、V406=s+P_L+D_η1 s。n≥9时完整回代：
\[
G_0\le16F_\delta R413+16F_\delta C_{413}X_q+16F_\delta V_{413}W,
\]
\[
B_H\le32F_\delta R413+[E387+32F_\delta C_{413}]X_q
+[S390+8s+32F_\delta V_{413}]W,
\]
\[
\begin{split}
\mathrm{入口}\le\Lambda\{&8\lambda HW+2d_{\rm eff}A_{\rm entrance,n}W_\nu/H+64F_\delta R413\\
&+[2E387+64F_\delta C_{413}]X_q+[2S390+16s+64F_\delta V_{413}]W\},\quad\Lambda=128/119.
\end{split}
\]
低维完整core替换保留且不叠加。旧source-near Δ404不是初始见证Δin，两者各一次；外部E387/S390/H等保持原系数。没有宣称全部X系数已吸收或各其他旧槽已付。

## 5. 占用层主攻仍缺的估计

在实际原标签上按费用发生时2^k s<D_i(z)≤2^{k+1}s分层；D_i≤S A_n，故层数至多ceil(log2(SA_n/s))，当SA_n≤s时切换费用为零。首次删除及early分数仍是同一实际边标签，不把大阈值跳内部的密度点当作曾通过的存活测试。

所有新增门与概率核只是正限制，所以粗界仍为R413,k≤2^{k+1}sW。已付分支的根阶源价和双列维数一致性不能把这一不等式升级为tX_q+C t^(−p)sW。stage低边缘付款已经补上原旧来源条件密度到当前后验的τ^{-1}支配；仍需要利用原双来源的共同捕获、远位移和完整来源匹配，在这个当前对称核上去掉2^k。仅有密度支配仍给τ^{-1}2^{k+1}sW，而非P。

本轮Astra专门检查该桥；其有界结论见geometry附件。候选P及任何含固定p的全层一致改进均未证明，不代入正式账。剩余R413仍有原双来源远位移、低共同捕获、初始双外侧/高秩/双collar，以及终端双外侧低秩，现另有双相对秩、当前高边缘与旧新双当前高占用门；不能刷新终端来源、继承原历史或反向使用已付BH信用。

其他未付事项原样保留：H入口兼容、soft/crossing/entry、重尾/宽距离/低pe/极端尺度比、原历史初始/删除跳跃/未来被删来源、全尺度拼接、截断极限和总X吸收与W复用。

## 6. 来源与本机证据

本轮依据新附410后建议的§4–7推进，原文件SHA256为37da7e3fa86ac5eae101661f8ad00372c169af645b5dabf60a7df3d3f06afeab。该文件是建议而非已证输入；新增两门及重算在本稿和aux中证明。64项工具L03的有理证书边界与共同测度/终端核验流程继续使用，无外部未经核验定理。

主代理本机运行216个Fraction原子配置，三阶段各72，162个配置有选中高门支；核闭CDF低门、严格左秩、分母系数及维数一致新侧列界，使用有理log下界而非浮点拟合。另运行18个共同后验核配置核验当前低边缘与旧来源低占用的累计预算。权值、质量轴和当前核只是诊断，不认证原生中心/完整历史或一般极值；一般结论依靠上述证明。主代理另实际重跑aux的78项及geometry的146条模型/分层记录，均通过；三脚本合计458条记录，非458个一般连续实例。geometry新增36个累计付款配置中有1个正的当前旧源低占用费用，有限证据范围据实保留。实际输出随附，最终另作解压复现。保留LaTeX源、不编译PDF；没有实际模型扣额数据。
