# R411：原远域早期费用中，辅助见证中心入父盒的一次付款

2026-10-19。新收据支付当前 R408 远域早期实际联合流的一个正分支，不重卖来源近域。分支是在同一 exclusive 双见证law中，至少一个见证的实际中心位于其父盒内。价格为 Δ_in X_q，无新 W 项；补集严格保留两个辅助中心都在父盒外及全部原标记。一般目标仍未闭合。

## 1. 原费用与唯一联合lift

冻结 full f、真实du、m_A=f(Q_A)=q_AR_A^n、q_-≤q_A≤λ、a≤R_A≤b≤2a，μ=dA/m，σ=q_AdA，π_A=f c_A/m_A，X_q=σ(E)。令 A_n=1+n log(b/a)、K=e^(√n)、s=1+√n、h=s/(ε_0q_-)，0<ε_0≤1/2，L≥4。

当前费用 R408 已保留 R404 双范数远域 F、R406 高旧来源门、R408 early 密度标记，以及原 Γ 的全部物理clock/J/H、来源、空间、质量秩、历史与分数权。外端父 A=u，小端父 A=v。分别仍有旧/新严格过去秩下界

 外端：Z_u(y)>2h，Z_u(z)>Lh；
 小端：Z_v(y)>(2−ε_0)h，Z_v(z)>(L−ε_0)h。

这里仅使用现有门的较弱后果，未重选阈值。小端来自 T−Z≤ε_0h。两端均保留 (1−C_A(y,z)/h)_+，其中

 Z_A(y)=∫c_w(y)1_{m_w<m_A/K}μ(dw)，
 C_A(y,z)=∫c_w(y)c_w(z)1_{m_w<m_A/K}μ(dw)，
 E_A(y,z)=Z_A(y)−C_A(y,z)。

用 Θ_ext、Θ_small 表示 R408 原完整的两源正测度，包括 early 标记与上述soft因子；其总质量之和为 R408。没有以 σπ_A² 替换这些原测度。soft为正的支上 C_A<h，两个方向 E_A 均严格正。只在此支定义

 Q_A^{y→z}(dw)=c_w(y)(1−c_w(z))1_{m_w<m_A/K}μ(dw)/E_A(y,z)，
 Q_A^{z→y}(dt)=c_t(z)(1−c_t(y))1_{m_t<m_A/K}μ(dt)/E_A(z,y)。     (1)

将每份 Θ 乘同一条件产品law Q_A^{y→z}⊗Q_A^{z→y}，得精确正lift \widehat Θ。无贡献的零soft支不需定义law。w捕获y而不捕获z，t捕获z而不捕获y；两个方向不交换，不赋予w或t原u、v的历史资格。

令 B_A={w∈E：中心w∈Q_A}。在这个同一lift中定义

 P_in=\widehat Θ{w∈B_A 或 t∈B_A}，
 R_out=\widehat Θ{w∉B_A 且 t∉B_A}。

于是 R408=P_in+R_out 精确，且均为非负。等价标量分数为 p+q−pq 与 (1−p)(1−q)，p=Q_A^{y→z}(B_A)、q=Q_A^{z→y}(B_A)；它们来自已经固定的同一产品law，不是在付过其他标签后重采样。

## 2. 来源质量先消去，再用实际中心体积

定义 E_in,A(y,z)=∫_{B_A}c_w(y)(1−c_w(z))1_far μ(dw)。双见证的未归一union量为

 U_A(y,z)=E_in,A(y,z)E_A(z,y)+E_A(y,z)E_in,A(z,y)
                         −E_in,A(y,z)E_in,A(z,y)。        (2)

它非负，且 union概率=U_A/[E_A(y,z)E_A(z,y)]。令

 J_in=∫σ(dA)π_A(dy)π_A(dz) U_A(y,z)。

下面仅为上界丢弃源远域F，原 P_in 中F始终保留。实际中心包络给每个源的 Z_A≤A_n/q_-。因此一个有方向项满足

 ∫π_A² E_in,A(y,z)E_A(z,y)
 ≤(A_n/q_-)∫π_A(dy) Z_in,A(y)，
 Z_in,A(y)=∫_{B_A}c_w(y)1_far μ(dw)。

完整匹配和Tonelli恰给

 ∫π_A Z_in,A
 =m_A^−1∫_{B_A,m_w<m_A/K} f(Q_A∩Q_w)/m_w dw
 ≤|Q_A|/m_A=1/q_A。                                     (3)

这里只用 f(Q_A∩Q_w)≤m_w，把来源质量与它的真实分母先抵消。之后才使用实际中心集合 B_A⊂Q_A 的Lebesgue体积。没有假设f有密度帽，也没有从薄体积推出小来源质量。另一方向相同，所以

 0≤J_in≤2A_n∫σ(dA)/(q_-q_A)≤2A_n X_q/q_-²。             (4)

union虽在上界中被两个方向之和控制，实际分拆仍只收费一次。可比较的更强子分支界是“双中心都在父盒内”的矩≤∫σ/q_A²≤X_q/q_-²：交换w,t及两来源后，来源质量为

 f(Q_A∩Q_w\Q_t) f(Q_A∩Q_t\Q_w)≤m_wm_t，

中心对体积≤|Q_A|²。此子分支包含在已付union中，不另行收费。

## 3. 回到原Θ：soft分母、两端容量、early阶段

在外端，原双秩下界与 C<h 给

 (1−C/h)/[E_A(y,z)E_A(z,y)]≤1/(2Lh²)。

小端同理≤1/[(2−ε_0)(L−ε_0)h²]。例如设x=C/h，a,b为两个原秩除h，则

 (1−x)/[(a−x)(b−x)]≤1/(ab)，a,b>1、ab≥a+b、0≤x≤1，

因为交叉相乘后的差为x(ab−a−b+x)≥0。外端a≥2、b≥4满足此条件；小端a≥3/2、b≥7/2也满足，最小ab−a−b=1/4。故乘上union概率后，原soft被相应常数乘 U_A 控制。

不能逐stage分别收费。按 R408 的首次撤流标签j，有 b_i^{early,j}(z)≤b_i(z)，Σ_i b_i(z)≤1，且原阶段 Γ_i 嵌套。对每个共同旧边标签及新z，

 Σ_j Σ_{i≤j} d(Γ_j−Γ_{j+1}) b_i^{early,j}(z)
 ≤Σ_i dΓ_i b_i(z)≤dΓ_0。                                (5)

此式在完整原标签空间成立；在终端未消失的有限截断下也是正上界。先用(5)，再去掉其余≤1标记，外端积分v用原逐来源外出容量 βσ(du)π_u(dy)，小端积分u用原逐来源入列容量 C_col σ(dv)π_v(dy)。U_A只依赖父A及y,z，故两端用同一个 J_in，无新的history或独立来源假设。

因此，令 B_L=β/(2L)+C_col/[(2−ε_0)(L−ε_0)]，得到

 P_in≤(B_L/h²)J_in≤Δ_in X_q，
 Δ_in=2A_n B_L/(h²q_-²)=2ε_0²A_nB_L/s²。                 (6)

这是真实原远域 early 费用的正分支付款。旧near价格与它数值相同，并不意味着同一支重复付款：此处的Θ已在near补集F内。

在ε_0≤1/2、L≥4下，A_n/s²≤1，B_L≤16S/(21L)，故 Δ_in≤S/(2L)。若要预设任意小X系数，仍须把ε_0或L的选择与原母账相容；改变L必须重建R398高/低新来源分拆及P_L。本文只交显示价格，不声称现有吸收余额已自动足够。

## 4. 历史范围与完整新账

已窄核归档：

- `402/research.zip::r402_main.md` §1、§3及其余项段，明确diag/inner均限于||y−z||∞≤d0，far原样保留；`r402_geometry.md` 第43行亦明确far补集。
- `403/research.zip::r403_main.md` §1及五项分拆段，第9、65、75行，所有共享方向、inner及软计数付款仍只near，far不变。
- `404/research.zip::r404_main.md` §4、第95、105行，用完整source-near并集替换402–403，保far且不附near的failure/collar/count门。该near判据是y−z位移，不是辅助w或t的中心位置。

因此上述文件没有支付“far来源且辅助中心入父盒”这一支。R338原边中心inside也不是本稿的双辅助见证事件；本稿不以原边inside价格为依据。

R408母账有 F_late=(1−32δ_late)^−1。将 R408=R_out+P_in 代入，不改其他费用，得到

 G0≤16F_late R_out+16F_late(C406+Δ_in)X_q+16F_late V406W，
 BH≤32F_late R_out+[E387+32F_late(C406+Δ_in)]X_q
                       +[S390+8s+32F_late V406]W。

原入口新增的唯一费用为64ΛF_late Δ_in X_q，原未付槽改成64ΛF_late R_out；其余H项、W项、旧source-near与共同捕获费用各留一次。不能遗漏先前晚期反馈倍率F_late。本文不新增W项、不重复使用BH负square，也不声称一般目标闭合。

中间余项R_out保留同一个实际双见证law，要求中心w,t都在父盒外，并且各自捕获相应来源、不捕获另一来源、严格m_w,m_t<m_A/K。原两来源far、old-high、early、high-new/low-common、时钟和历史全部保留；w,t没有成为原历史节点。

整合说明：本文只证明 inside 收据，R_out是本稿的中间余项。主稿随后在R_out中另付 P_low W，并将最终两中心均在父盒外且两见证各自 own-past 都大于h的余项记为R411；该后续付款不由本文证明，不在本文母账中重复加入。

## 5. 本机三阶段精确检查

`/tmp/r411_aux_check.py` 实际运行：

```
PASS {'initial_joint_and_source': 6, 'boundary_pressure': 12, 'expanded_cubes': 8} total 26
All Fraction; actual full-f cube masses and source volumes, finite receiver quadrature only.
Native exponential far follows K=exp(sqrt(3))<6; original history/rank/clock gates not certified.
```

初步阶段核同一双见证概率分拆，并以独立矩形来源分割核对实际两源积分与交换后的差集质量乘积。压力阶段使用16个真实三维小cube、均匀或0.75背景加0.25局部packet的完整L1来源、移动父盒与两组正中心权，精确匹配q∈[0.75,1]；扩大阶段使用64个小cube。父边长2、子边长1，精确质量满足m_A>6m_w；脚本另以有理Taylor尾证 e^(√3)<6。所有模型的inside与bothoutside矩均正。

来源体积与质量完全精确，但接收积分是有限正quadrature，不是原native连续选择器，也未实现原high-rank/clock/history资格。26项为上述分拆和质量消去的本机核验，严格一般证明为(1)–(6)，不以有限模型声称残余一般正比例或维数渐近。
