from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

def verify(mass,a,K,h):
    n=len(mass);J=sum(a)
    z=[sum(a[k] for k in range(n) if mass[k]*K<mass[j]) for j in range(n)]
    active=[zj>h for zj in z]
    left=[sum(a[k] for k in range(n) if mass[k]<mass[j]) for j in range(n)]
    closed=[sum(a[k] for k in range(n) if mass[k]<=mass[j]) for j in range(n)]
    P=[[a[k]/z[j] if active[j] and mass[k]*K<mass[j] else F(0) for k in range(n)] for j in range(n)]
    order=sorted(range(n),key=lambda j:mass[j],reverse=True)
    G=[];active_starts=0;multi=0;atom_checks=0
    for initial in range(n):
        visit=[F(int(k==initial)) for k in range(n)]
        for j in order:
            for k in range(n):visit[k]+=visit[j]*P[j][k]
        green=[visit[k]-int(k==initial) for k in range(n)]
        G.append(green)
        if not active[initial]:
            assert sum(green)==0
            continue
        active_starts+=1;multi+=int(sum(green)>1)
        assert sum(green[k] for k in range(n) if not active[k])==1
        for k in range(n):
            if not mass[k]*K<mass[initial]:assert green[k]==0
            assert green[k]<=a[k]/max(h,left[k])
            assert green[k]<=a[k]/max(h,closed[k])
            atom_checks+=1
        # Independent generation-by-generation sum, terminal included once.
        level=[F(int(k==initial)) for k in range(n)];summed=[F(0)]*n
        for step in range(1,n+1):
            level=[sum(level[j]*P[j][k] for j in range(n)) for k in range(n)]
            for k in range(n):
                summed[k]+=level[k]
                if level[k]:assert mass[k]*K**step<mass[initial]
        assert not any(level) and summed==green
    # Marked, non-normalized initial measure; no replacing its mass by one.
    ell=[a[j]*F((j%3)+1,3) if active[j] else F(0) for j in range(n)]
    M=sum(ell)
    occ=[ell[k]+sum(ell[j]*G[j][k] for j in range(n)) for k in range(n)]
    assert all(occ[k]<=J*a[k]/max(h,closed[k]) for k in range(n))
    terminal=[F(int(not active[k])) for k in range(n)]
    assert sum(occ[k]*terminal[k] for k in range(n))==M
    # A second path-cover weight: 1/2 at every vertex. Every active-start path has >=2 vertices.
    assert sum(occ)/2>=M
    return {'atoms':n,'active_starts':active_starts,'multi_visit_starts':multi,'atom_checks':atom_checks,'initial_mass':str(M),'terminal_mass':str(sum(occ[k] for k in range(n) if not active[k]))}

stages={
'initial':[(list(map(F,[1,3,9,27,81])),list(a),F(K),F(h)) for a,K,h in product([(F(1),)*5,(F(1,2),F(3,2),F(1,3),F(2),F(1))],[2,3],[F(1,2),F(1),F(2)])],
'atoms_boundaries':[(list(map(F,[1,1,2,4,4,8,16,16,32])),[F((j+shift)%4+1,3) for j in range(9)],F(K),F(h)) for shift,K,h in product([0,1,2],[2,4],[F(1,3),F(2),F(5),F(100)])],
'expanded':[(list(map(F,[2**(j//2) for j in range(N)])),[F((j*j+shift)%7+1,5) for j in range(N)],F(K),F(h)) for N,shift,K,h in product([16,24,32],[0,3],[2,3],[F(3,2),F(4)])]
}
results={name:[verify(*args) for args in rows] for name,rows in stages.items()}
flat=[r for rows in results.values() for r in rows]
summary={'counts':{k:len(v) for k,v in results.items()},'total':len(flat),'active_starts':sum(r['active_starts'] for r in flat),'multi_visit_starts':sum(r['multi_visit_starts'] for r in flat),'atom_checks':sum(r['atom_checks'] for r in flat),'zero_active_models':sum(r['active_starts']==0 for r in flat)}
Path(__file__).with_name('r423_aux_result.json').write_text(json.dumps({'summary':summary,'results':results},indent=2)+'\n')
print('PASS',summary)
print('Exact finite mass-axis Markov kernels, strict gaps, repeated mass atoms, terminal and initial Dirac terms. Not native cube/history realizations.')
print('r423_aux_result.json')
