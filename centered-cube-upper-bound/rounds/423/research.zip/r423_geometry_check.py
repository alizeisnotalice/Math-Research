from fractions import Fraction as F
from random import Random
rng=Random(423)
counts={'source_retaining_step_laws':0,'native_radius_envelopes':0,'joint_chain_gram':0}
# Stage 1: exact subprobability laws, no density substitution in the induction.
for length in [5,8,12]:
 for trial in range(12):
  masses=[F(2)**j for j in range(length)]
  rho=[F(rng.randint(1,6),4) for j in range(length)]
  h=F(1);K=F(3)
  Z=[sum(rho[j] for j in range(length) if masses[j]<masses[i]/K) for i in range(length)]
  start=length-1
  if Z[start]<=h:continue
  p=[F(int(j==start)) for j in range(length)]
  for step in range(1,length+1):
   p=[sum(p[i]*rho[j]/Z[i] for i in range(length) if Z[i]>h and masses[j]<masses[i]/K) for j in range(length)]
   assert sum(p)<=1
   for j in range(length):
    assert p[j]<=rho[j]/h
    if p[j]>0:assert masses[j]<masses[start]/K**step
  counts['source_retaining_step_laws']+=1
# Stage 2: native selectable-side-length field for uniform full source q=1.
# R(v)=max(a,2||v||infty), centers in Q_b, a<=b<=2a.
# Exact center integral of m(v)^(-1/2): 2*b^(n/2)-a^(n/2).
for n in [2,4,16,36,64,100]:
 for a,b in [(F(1),F(2)),(F(1),F(3,2)),(F(2,3),F(1))]:
  exact=2*b**(n//2)-a**(n//2)
  assert 0<exact<=2*b**(n//2)
  # Two-stage multiplication used in the affinity moment bound.
  exact2=2*b**(n//2)-(a/2)**(n//2)
  assert exact*exact2<=4*b**n
  counts['native_radius_envelopes']+=1
# Stage 3: actual subsets and full uniform source, geometric mean affinities.
# Each path has masses 4096,64,1, so strict factor49 and rho=1/7 valid.
for trial in range(24):
 common={100000}
 chain=[]
 for side in range(2):
  pool=list(range(side*10000,side*10000+6000))
  big=set(rng.sample(pool,4095))|common
  mid=set(rng.sample(pool,63))|common
  small={pool[-1]}
  chain.append([big,mid,small])
 roots=[F(64),F(8),F(1)]
 E=chain[0]+chain[1];root=roots+roots
 gram=[[F(len(E[i]&E[j]),1)/(root[i]*root[j]) for j in range(6)] for i in range(6)]
 V=sum(gram[i][j] for i in range(3) for j in range(3,6))
 assert V<F(1,8)
 eps=F(1,3)+V # within-chain bound for strict mass factor49.
 for i in range(6):assert sum(gram[i][j] for j in range(6) if i!=j)<=eps
 for test in range(8):
  coef=[F(rng.randint(-5,5)) for _ in range(6)]
  norm=sum(x*x for x in coef)
  quad=sum(coef[i]*coef[j]*gram[i][j] for i in range(6) for j in range(6))
  assert (1-eps)*norm<=quad<=(1+eps)*norm
 # Exact clipping identity for the chosen cross sum.
 theta=F(1,8);chi=min(F(1),V/theta)
 assert chi+(1-chi)==1 and chi<=V/theta
 counts['joint_chain_gram']+=1
# Dimension-independent n>=9 Riesz certificate using e^(3/2)>4.
assert 1+F(3,2)+F(3,2)**2/2+F(3,2)**3/6==F(67,16)>4
assert 1-F(2,3)-F(1,8)==F(5,24)>0
print('PASS',counts,'total',sum(counts.values()))
print('Fraction kernel/frame checks and analytic native radius integrals only; no full original rank/stage/history instance is asserted.')
