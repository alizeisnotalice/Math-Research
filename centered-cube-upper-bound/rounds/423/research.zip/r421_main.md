# 第421轮：共享来源质量的双见证容量与实际软分支付款

2026-10-20。一般中心立方体 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮处理第420轮明确留下的问题：几何交叠很小仍可承载集中的来源。本轮不限制f密度，而直接估计两见证的共享来源质量，取得可代入原母账的一次性正分数预算。剩余硬层仍未获根阶预算。

## 1. 保持原积分与定义

f≥0属于L1，W=∫f。实际Lebesgue中心v有原选定中心立方体Q_v，边长a≤R_v≤b≤2a，m_v=f(Q_v)=q_vR_v^n，q_-≤q_v≤λ。记μ(dv)=dv/m_v，σ(dA)=q_A dA，π_A=f1_QA/m_A，X_q=∫σ，A_n=1+nlog(b/a)，K=e^(√n)，s=1+√n，h=s/(ε_0q_-)。

R420是原同一次双exclusive提升及其后续路径上的正费用，保留所有旧新来源、父A、物理时钟、首次删除、阶段b_i、early、秩门、重尾和终端标签。初始见证w,t满足m_w,m_t<m_A/K；先前取得的互中心外侧及小几何交叠条件继续保留。以下共享质量始终用完整f：
\[
I_{wt}=f(Q_w\cap Q_t),\quad
\omega_{\min}(w,t)=\frac{I_{wt}}{\min(m_w,m_t)},\quad
\omega_{\max}(w,t)=\frac{I_{wt}}{\max(m_w,m_t)}.
\]
二者都在[0,1]，但归一化不同。本轮正式收费使用ω_min，不能将两个版本另加两次收据。原有效场质量为正；零父质量无费用。

## 2. 两个真实中心容量输入

固定来源x时，捕获x的中心v满足R_v≥2||v−x||_∞，且m_v≥q_-R_v^n。因此
\[
J(x)=\int c_v(x)\mu(dv)
\le\frac1{q_-}\int_0^{b^n}\frac{du}{\max(a^n,u)}
=\frac{A_n}{q_-}.\tag{1}
\]
u=(2||v−x||∞)^n是中心盒体积变量，不是来源变量。上界将真实中心集合放大，不构造新接收者。

固定父A，令M=m_A/K、E_A={v:m_v<M}、I_Av=f(Q_A∩Q_v)。远质量与q_-给R_v<(M/q_-)^(1/n)。再交换完整来源与中心，得到
\[
\int_{E_A}I_{Av}\,dv
=\int_{Q_A}f(x)|\{v\in E_A:x\in Q_v\}|\,dx
\le\frac{m_AM}{q_-}.\tag{2}
\]
两式都不要求f有密度上界。

## 3. 共享来源的较小质量归一矩

定义原始双见证矩
\[
\mathcal S_A^{\min}
=\int\pi_A(dy)\pi_A(dz)
\int_{E_A^2}c_w(y)c_t(z)\omega_{\min}(w,t)\mu(dw)\mu(dt).
\]
完整来源Tonelli给
\[
\mathcal S_A^{\min}
=m_A^{-2}\int_{E_A^2}\frac{I_{Aw}I_{At}}{m_wm_t}
\frac{I_{wt}}{\min(m_w,m_t)}\,dw\,dt.
\]
由1/min(m_w,m_t)≤1/m_w+1/m_t，估计其中Iwt/m_t的一项。先用I_At≤m_t，再保留完整共享来源，有
\[
\int_{E_A}\frac{I_{wt}}{m_t}\,dt
=\int_{Q_w}f(x)\int_{E_A}c_t(x)\mu(dt)\,dx
\le\frac{A_n m_w}{q_-}.
\]
此式不是几何体积交叠的估计。于是该项由(2)控制为
\[
\frac{A_n}{q_-m_A^2}\int_{E_A}I_{Aw}\,dw
\le\frac{A_n}{Kq_-^2}.
\]
另一项交换w,t同价，得到一般结论
\[
\boxed{\mathcal S_A^{\min}\le\frac{2A_n}{Kq_-^2}.}\tag{3}
\]
没有来源刷新、独立坐标假设或隐藏阶段数。π_A(dy)π_A(dz)来自原已证正包络；实际费用仍保留全部原条件。

## 4. 较大质量归一的补充工具

同样定义S_A^max，将ω_min换成ω_max。固定w，实际中心径向包络给
\[
\int_{E_A}\frac{c_t(x)}{\max(m_w,m_t)}dt
\le\int_0^{M/q_-}\frac{du}{\max(m_w,q_-u)}
=\frac{1+\log(M/m_w)}{q_-}.
\]
先用I_At≤m_t，积分完整I_wt后，
\[
\mathcal S_A^{\max}\le\frac1{q_-m_A^2}
\int_{E_A}I_{Aw}[1+\log(M/m_w)]dw.
\]
对每个x∈Q_A，捕获x的w有m_w≥q_-(2||w−x||∞)^n。中心体积积分为
\[
\int_0^{M/q_-}[1+\log(M/(q_-u))]du=2M/q_-.
\]
故
\[
\boxed{\mathcal S_A^{\max}\le2/(Kq_-^2).}\tag{4}
\]
原点处的对数奇性可积。此版不需要(1)中的A_n，但其来源交叠归一更弱，不能不经说明替代(3)。本轮只将其作为工具与数值交叉核验，不另计付款。

## 5. 同一次原提升上的软分数付款

以Θ420表示R420对应的完整标签正测度，R420=|Θ420|。取θ_s=2A_n/K，定义同一原标签上的
\[
\chi(w,t)=\min(1,\omega_{\min}(w,t)/\theta_s),
\quad P_{421}=\int\chi\,d\Theta_{420},
\quad R_{421}=\int(1-\chi)\,d\Theta_{420}.
\]
这是精确正分拆R420=P421+R421，不重新归一化或抽样。对于n≥9，θ_s<1：令x=√n≥3，用log2<7/10得2A_n/K≤(2+7x²/5)e^(−x)；该函数在x≥3严格递减，且x=3时≤(73/5)/(5/2)^3<1，使用e>5/2。低维仍沿原core替代，不叠加本高维账。

χ≤ω_min/θ_s，故(3)给其未归一矩≤1/q_-²。沿用原R411的共同early/首次删除标签求和、Σ_i b_i(z)≤1、逐来源β与C_col，以及soft/双exclusive分母，得到
\[
B_L=\frac\beta{2L}+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)},
\qquad
\boxed{P_{421}\le\Delta_{421}X_q,
\quad\Delta_{421}=\frac{B_L}{q_-^2h^2}
=\frac{\varepsilon_0^2B_L}{s^2}.}\tag{5}
\]
B_L已经包含两父端，不额外乘2、S、τ^(-1)或λ/q_-。其余原限制及后续概率路径只在上界中删除，实际R421仍保留。所有阶段与占用层合计收(5)一次；不另收硬事件{ω_min≥θ_s}，也不再收max版本。原有限终端仍按旧清空合同处理。

剩余实际费用保留因子(1−ω_min/θ_s)_+，在其正支上严格有
\[
f(Q_w\cap Q_t)<\theta_s\min(m_w,m_t).\tag{6}
\]
因此两个真实来源后验f1_Qw/m_w、f1_Qt/m_t均给对方盒小于θ_s的概率；其Hellinger亲和I_wt/√(m_wm_t)也小于θ_s。这是(6)的直接后果，不是额外付款，更不能据此将后验重新独立抽样或断言全族有界重叠。

## 6. 完整母账与缺口

保留Δ419=2ε_0²B_L/s²及第420轮Δ420=ε_0²B_LD_n/(Ks²)，D_n=(51/(22√n))^n，Fhat=(1−32δ−16η)^(-1)，Λ=128/119。令
C421=C413+Δ419+Δ420+Δ421，则
\[
G_0\le16\widehat F R_{421}+16\widehat F C_{421}X_q+16\widehat F V_{413}W,
\]
\[
B_H\le32\widehat F R_{421}+[E_{387}+32\widehat F C_{421}]X_q
+[S_{390}+8s+32\widehat F V_{413}]W,
\]
\[
\begin{split}
\mathrm{入口}\le\Lambda\{&8\lambda HW+2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
+64\widehat F R_{421}\\
&+[2E_{387}+64\widehat F C_{421}]X_q
+[2S_{390}+16s+64\widehat F V_{413}]W\}.
\end{split}
\]
新增入口费用64ΛFhatΔ421X_q，无新增W费，反馈与旧费不改，不退款。尚未核准全局吸收余额，未证明R421层一致预算或整个一般弱型上界。

下一步应使用(6)这一真实来源结构结算剩余跨父重复交通，而非把小几何体积直接当小来源质量。条件只对实际剩余的见证对成立，不对任意两盒成立；不能由此声称整个来源族正交、全局Carleson预算或任意树源刷新成立。原其他未付槽、初始/跳跃/终端、全尺度及最终极限均保持。

## 7. 核验与协作范围

一般结论由上述非负Tonelli、真实中心包络和原收费合同证明；主代理实际复跑geometry的116项Fraction记录（96个有限正中心代数、18个连续张量中心积分、2个参数/正几何证书），以及aux的56个连续中心/完整非均匀来源模型（集中8、父外来源12、扩大36）。后者56例矩为正，30例min矩严格大于max矩，48个有向跨块对满足低几何交叠但来源交叠/minmass≥1/2。有限代数、连续模型和完整原历史资格分别记录，不混称全合同验证。两脚本、实际stdout、auxJSON及独审随包；解压运行 python3 r421_geometry_check.py 与 python3 r421_aux_check.py，后者重建同目录JSON。使用64项工具的同测度收费与精确/数值证据分离规则，不调用未认证的通用稳定性或区间API。有限连续模型不能认证原完整历史，也不证明每个输入都有新正费用或固定比例减少。保留LaTeX源，不编译PDF。复用一名Astra和两名Sol，未取得实际额度扣除数据，不猜测模型成本比例。
