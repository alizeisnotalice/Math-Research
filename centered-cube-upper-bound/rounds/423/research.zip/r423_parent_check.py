from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json

def box(c,s): return tuple((x-s/2,x+s/2) for x in c)
def vol(B):
    r=F(1)
    for a,b in B:r*=b-a
    return r
def incidence(C,B,R):
    yes=all(l>=v-R/2 and r<=u+R/2 for (l,r),(u,v) in zip(C,B))
    no=any(r<=u-R/2 or l>=v+R/2 for (l,r),(u,v) in zip(C,B))
    assert yes or no,'source incidence changes on center block'
    return int(yes)
def disjoint(C,D):return any(b<=c or d<=a for (a,b),(c,d) in zip(C,D))
def geom_upper(U,R,V,S):
    p=F(1)
    for (a,b),(c,d) in zip(U,V):
        dist=max(F(0),c-b,a-d)
        p*=max(F(0),min(R,S,(R+S)/2-dist))
    return p/max(R,S)**len(U)

def model(n,Rt,qw,qt,l,overlap,outer=False,diagonal=False):
    M=F(2**n); mw=qw; mt=qt*Rt**n
    k=isqrt(n)+(isqrt(n)**2<n); K=F(3**k)
    assert M>K*max(mw,mt)
    c=F(9,20) if diagonal else F(3,10)
    wc=(-c,)*n if diagonal else (-c,)+(F(0),)*(n-1)
    tc=(c,)*n if diagonal else ((F(1,2) if outer else c),)+(F(0),)*(n-1)
    groups=[(box(wc,l),F(1)),(box(tc,F(1,16) if outer else l),Rt)]
    parent=box((F(0),)*n,F(1,32)); Rp=F(2)
    outmass=mt/4 if outer else F(0)
    common=overlap*min(mw,mt-outmass); src=[]
    def add(c,s,m):
        if m:src.append((box(c,s),m))
    side=F(1,64) if diagonal else F(1,16)
    add((F(0),)*n,side,common)
    lc=(F(-5,8),)*n if diagonal else (F(-5,8),)+(F(0),)*(n-1)
    rc=(F(5,8),)*n if diagonal else (F(5,8),)+(F(0),)*(n-1)
    add(lc,side,mw-common);add(rc,side,mt-outmass-common)
    ballast=(F(-7,8),F(7,8))+(F(0),)*(n-2) if diagonal else (F(7,8),)*n
    add(ballast,F(1,16),M-(mw+mt-outmass-common))
    if outer:add((F(17,16),)+(F(0),)*(n-1),F(1,128),outmass)
    assert all(disjoint(C,D) for i,(C,_) in enumerate(src) for D,_ in src[i+1:])
    assert all(disjoint(U,V) for i,(U,_) in enumerate(groups+[(parent,Rp)]) for V,_ in (groups+[(parent,Rp)])[i+1:])
    def mass(B,R):return sum(m*incidence(C,B,R) for C,m in src)
    assert mass(parent,Rp)==M
    ms=[mass(B,R) for B,R in groups];assert ms==[mw,mt]
    q=min(F(1),qw,qt);assert F(3,4)<=q and max(qw,qt)<=1
    Is=[sum(m*incidence(C,parent,Rp)*incidence(C,B,R) for C,m in src) for B,R in groups]
    def root(x):
        a=isqrt(x.numerator);b=isqrt(x.denominator)
        assert a*a==x.numerator and b*b==x.denominator
        return F(a,b)
    rows=[]
    for ca,cb in [(F(1,4),F(4)),(F(4),F(1,4)),(F(4),F(4)),(F(9),F(4))]:
        M1=ca*mw;M2=cb*mt;raw=F(0)
        for i,(U,R) in enumerate(groups):
            for j,(V,S) in enumerate(groups):
                if ms[i]>=M1 or ms[j]>=M2:continue
                I=sum(m*incidence(C,U,R)*incidence(C,V,S) for C,m in src)
                raw+=vol(U)*vol(V)*Is[i]*Is[j]*I/(M*M*ms[i]*ms[j]*root(ms[i]*ms[j]))
        cap=4*root(M1*M2)/(M*q*q)
        assert 0<=raw<=cap
        rows.append((str(raw),str(cap)))
    return rows

stages={'initial':[(16,F(1),False)],'full_source_pressure':[(16,F(5,4),True),(36,F(5,4),True)],'expanded':[(64,F(1),False),(100,F(5,4),True),(144,F(5,4),False)]}
counts={}
for stage,configs in stages.items():
    total=positive=0
    for n,R,outer in configs:
        for overlap in [F(0),F(1,4),F(3,4)]:
            for raw,cap in model(n,R,F(1),F(1),F(1,16),overlap,outer,False):
                total+=1;positive+=F(raw)>0
    counts[stage]={'bounds':total,'positive':positive}
print('PASS',counts)
# Exact common-ledger substitution and soft fraction on finite positive labels.
for p in range(1,25):
    values=[F(p,100),F(p,1000),F(0),F(p,8)]
    weights=[F(1,3),F(2,7),F(3,5),F(7,11)]
    total=sum(weights);paid=sum(w*min(F(1),8*v) for w,v in zip(weights,values))
    residual=sum(w*max(F(0),1-8*v) for w,v in zip(weights,values))
    assert paid+residual==total
    assert paid<=8*sum(w*v for w,v in zip(weights,values))
    assert all(v<F(1,8) for v in values if max(F(0),1-8*v)>0)
    fac=F(8,5);lam=F(128,119);C=F(5,17);budget=8*sum(w*v for w,v in zip(weights,values))
    assert 64*lam*fac*total+64*lam*fac*C<=64*lam*fac*residual+64*lam*fac*(C+budget)
print('PASS soft split and full entrance algebra 24')
print('Continuous full-source/center-block raw affinity integrals; no original path/history certification. Finite ledger checks do not prove global absorption.')
