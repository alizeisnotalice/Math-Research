import argparse,json,hashlib,sys,time,platform,resource
from pathlib import Path
from fractions import Fraction as Q
start=time.perf_counter();cpu=time.process_time();p=argparse.ArgumentParser();p.add_argument('--input',type=Path);p.add_argument('--base',type=Path);p.add_argument('--base-only',action='store_true');p.add_argument('--bundle',type=Path);p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));p.add_argument('--toy',action='store_true');a=p.parse_args();assert sum((bool(a.input),a.toy,a.base_only,bool(a.bundle)))==1
if a.base_only or a.bundle:assert a.base
if a.base_only:
 b=json.loads(a.base.read_text()); cubes=b['cubes_quarter_units'];assert b['n']==2 and b['a']==2 and b['N']==len(cubes)
 stars=[(Q(x-2*r,4),Q(x+2*r,4),Q(y-2*r,4),Q(y+2*r,4)) for r,x,y in cubes]
 occupied=set()
 for r,x,y in cubes:occupied.update((i,j) for i in range(x-r,x+r) for j in range(y-r,y+r))
 V=Q(len(occupied),16);assert V==Q(*b['V']);src=[(*map(Q,c[:4]),Q(c[4])) for c in b['source_cells']];assert all(c[0]<c[1] and c[2]<c[3] and c[4]>=0 for c in src)
 area=lambda r:(r[1]-r[0])*(r[3]-r[2])
 inter=lambda r,c:max(Q(),min(r[1],c[1])-max(r[0],c[0]))*max(Q(),min(r[3],c[3])-max(r[2],c[2]))
 covers=[sum((c[4]*inter(r,c)/area(c) for c in src),Q()) for r in stars];targets=list(map(area,stars));assert all(x>=y for x,y in zip(covers,targets));assert [[x.numerator,x.denominator] for x in covers]==b['source_row_masses'];assert [[(x/y).numerator,(x/y).denominator] for x,y in zip(covers,targets)]==b['source_row_h']
 dual=list(map(Q,b['Qstar']['dual_weights']));assert len(dual)==len(stars) and all(z>=0 for z in dual);xs=sorted({v for r in stars for v in r[:2]});ys=sorted({v for r in stars for v in r[2:]});mx=Q()
 for x0,x1 in zip(xs,xs[1:]):
  for y0,y1 in zip(ys,ys[1:]):
   xx=(x0+x1)/2;yy=(y0+y1)/2;load=sum((w for r,w in zip(stars,dual) if r[0]<xx<r[1] and r[2]<yy<r[3]),Q());mx=max(mx,load)
 assert mx<=1;P=sum((c[4] for c in src),Q());D=sum((z*t for z,t in zip(dual,targets)),Q());assert P==D==Q(b['Qstar']['primal_upper'])==Q(b['Qstar']['dual_lower'])
 fmt=lambda x:[str(x.numerator),str(x.denominator)]
 out={'scope':'base complete source primal and dual; geometry bad rows not checked','base_sha256':hashlib.sha256(a.base.read_bytes()).hexdigest(),'V':fmt(V),'source_total':fmt(P),'dual_objective':fmt(D),'h_values':list(map(fmt,[x/y for x,y in zip(covers,targets)])),'source_cover':list(map(fmt,covers)),'max_dual_load':fmt(mx),'arrangement_cells':(len(xs)-1)*(len(ys)-1),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};a.output.write_text(json.dumps(out,indent=2)+'\n');print('base V',V,'source and dual',P,'dualcells',out['arrangement_cells']);sys.exit()
if a.bundle:
 from collections import defaultdict
 b=json.loads(a.base.read_text());bundle=json.loads(a.bundle.read_text());cubes=b['cubes_quarter_units'];n=len(cubes);assert n==59 and b['a']==2
 sources=[(*map(Q,c[:4]),Q(c[4])) for c in b['source_cells']];mass=[z[4] for z in sources]
 stars=[(Q(x-2*r,4),Q(x+2*r,4),Q(y-2*r,4),Q(y+2*r,4)) for r,x,y in cubes]
 area=lambda r:(r[1]-r[0])*(r[3]-r[2])
 inter=lambda r,c:max(Q(),min(r[1],c[1])-max(r[0],c[0]))*max(Q(),min(r[3],c[3])-max(r[2],c[2]))
 cover=[sum((c[4]*inter(r,c)/area(c) for c in sources),Q()) for r in stars];assert all(cover[i]>=area(stars[i]) and [Q(*b['source_row_h'][i])]==[cover[i]/area(stars[i])] for i in range(n))
 dual=list(map(Q,b['Qstar']['dual_weights']));xs=sorted({v for r in stars for v in r[:2]});ys=sorted({v for r in stars for v in r[2:]});assert len(dual)==n and all(x>=0 for x in dual)
 assert all(sum((w for r,w in zip(stars,dual) if r[0]<(x0+x1)/2<r[1] and r[2]<(y0+y1)/2<r[3]),Q())<=1 for x0,x1 in zip(xs,xs[1:]) for y0,y1 in zip(ys,ys[1:]))
 assert sum(mass,Q())==sum((v*area(r) for v,r in zip(dual,stars)),Q())==273
 owner={}
 for j in sorted(range(n),key=lambda i:(cubes[i][0],i)):
  r,x,y=cubes[j]
  for u in range(x-r,x+r):
   for v in range(y-r,y+r):owner.setdefault((u,v),j)
 assert Q(len(owner),16)==Q(*b['V']);essential=set(owner.values());assert sorted(essential)==b['essential_indices'];seeds=defaultdict(list)
 for cell,j in owner.items():seeds[j].append(cell)
 pairs=defaultdict(Q);bad=b['certified_bad_full_cells'];assert len(bad)==16
 for z in bad:
  i=z['i'];j=z['j_lower_witness'];a0,a1,b0,b1=map(Q,z['cell']);assert a1-a0==b1-b0==Q(1,4);u=int(4*a0);v=int(4*b0);assert Q(u,4)==a0 and Q(v,4)==b0 and (u,v) in owner and j in essential
  covering=[k for k,(r,x,y) in enumerate(cubes) if k in essential and x-r<=u<x+r and y-r<=v<y+r];assert covering and cubes[i][0]==max(cubes[k][0] for k in covering) and i in covering
  assert cover[i]/area(stars[i])<=2 and Q(*z['hi'])==cover[i]/area(stars[i]);R=cubes[j][0];r=cubes[i][0]
  def far(q0,q1,t):return max(0,t-q0,q0-(t+1),t-q1,q1-(t+1))
  # Quarter-grid units: 8*T_lower = 10*R - maxdist_grid; 8*(10*r_i)=20*r_i.
  assert any(10*R-far(u,u+1,sx)-far(v,v+1,sy)>20*r for sx,sy in seeds[j]);pairs[(i,j)]+=Q(1,16)
 assert sum(pairs.values(),Q())==Q(1)
 outputs={};f=lambda x:[str(x.numerator),str(x.denominator)]
 for kind,rec in bundle['adjacency'].items():
  assert kind in ('fresh','local','joint') and list(map(Q,rec['mass']))==mass;rows=rec['rows'];assert len(rows)==len(pairs);assert {(z['i'],z['j']) for z in rows}==set(pairs)
  for row in rows:
   i,j=row['i'],row['j'];assert Q(row['demand_lower'])==Q(row['demand_upper'])==pairs[(i,j)]
   expected=[]
   for k,c in enumerate(sources):
    ai=inter(stars[i],c);aj=inter(stars[j],c);A=area(c);assert ai in (Q(),A) and aj in (Q(),A)
    if (kind=='fresh' and aj==A and ai==0) or (kind=='local' and ai==A) or (kind=='joint' and (ai==A or aj==A)):expected.append(k)
   assert row['cells']==expected
  gamma=Q(rec['gamma']);rl=[Q() for _ in rows];cl=[Q() for _ in mass]
  for i,k,val in rec['flow']:
   v=Q(val);assert v>=0 and k in rows[i]['cells'];rl[i]+=v;cl[k]+=v
  assert all(rl[i]==pairs[(row['i'],row['j'])] for i,row in enumerate(rows));assert all(x<=gamma*y for x,y in zip(cl,mass))
  cut=rec['cut_rows'];assert len(set(cut))==len(cut) and all(0<=x<len(rows) for x in cut);U=set().union(*(set(rows[i]['cells']) for i in cut));den=sum((mass[k] for k in U),Q());assert den>0;lower=sum((pairs[(rows[i]['i'],rows[i]['j'])] for i in cut),Q())/den;assert lower==gamma
  outputs[kind]={'gamma':f(gamma),'flow_row_load':list(map(f,rl)),'flow_source_load':list(map(f,cl)),'cut_rows':cut,'cut_neighborhood':sorted(U),'cut_lower':f(lower),'exact':True}
 out={'scope':'fixed single-witness 16-cell subset, not complete bad set or global winner','base_sha256':hashlib.sha256(a.base.read_bytes()).hexdigest(),'bundle_sha256':hashlib.sha256(a.bundle.read_bytes()).hexdigest(),'V':f(Q(*b['V'])),'source_and_dual':f(Q(273)),'bad_subset_area':f(Q(1)),'pairs':[[i,j,f(v)] for (i,j),v in sorted(pairs.items())],'adjacency':outputs,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime':{'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
 a.output.write_text(json.dumps(out,indent=2)+'\n');print('verified',[(k,Q(*map(int,v['gamma']))) for k,v in outputs.items()],'seconds',out['runtime']['wall_seconds']);sys.exit()
if a.toy:
 d={'mass':['1','2'],'rows':[{'demand':'2','cells':[0]},{'demand':'1','cells':[0,1]}],'gamma':'2','flow':[[0,0,'2'],[1,1,'1']],'cut_rows':[0],'metadata':{'scope':'artificial toy only'}}
else:d=json.loads(a.input.read_text())
ms=list(map(Q,d['mass']));rows=d['rows'];w=[Q(v.get('demand_upper',v.get('demand'))) for v in rows];wlow=[Q(v.get('demand_lower',v.get('demand'))) for v in rows];neigh=[set(r['cells']) for r in rows];gamma=Q(d['gamma']);assert all(z>=0 for z in ms) and all(0<=lo<=up and up>0 for lo,up in zip(wlow,w)) and gamma>=0 and all(all(type(s)==int and 0<=s<len(ms) for s in z) for z in neigh)
flow=d['flow'];rowload=[Q() for _ in rows];cellload=[Q() for _ in ms];invalid=[];visited=set()
for i,s,v in flow:
 assert type(i)==type(s)==int and 0<=i<len(rows) and 0<=s<len(ms) and (i,s) not in visited;visited.add((i,s));t=Q(v);assert t>=0
 if s not in neigh[i] and t>0:invalid.append([i,s])
 rowload[i]+=t;cellload[s]+=t
row_residual=[rowload[i]-w[i] for i in range(len(rows))];cell_slack=[gamma*ms[i]-cellload[i] for i in range(len(ms))];feasible=not invalid and all(v==0 for v in row_residual) and all(v>=0 for v in cell_slack)
cut=d['cut_rows'];assert len(set(cut))==len(cut) and all(type(i)==int and 0<=i<len(rows) for i in cut);U=set().union(*(neigh[i] for i in cut)) if cut else set();demand=sum((wlow[i] for i in cut),Q());mass=sum((ms[i] for i in U),Q());infinite=bool(demand>0 and mass==0);lower=(demand/mass if mass else Q());exact=feasible and not infinite and lower==gamma
if a.toy:assert exact and lower==2
f=lambda x:[str(x.numerator),str(x.denominator)]
out={'scope':'exact upper-demand flow and lower-demand cut; source/geometry metadata and its claimed provenance are not independently verified','toy':a.toy,'row_count':len(rows),'cell_count':len(ms),'edge_count':len(flow),'gamma':f(gamma),'demand_lower':list(map(f,wlow)),'demand_upper':list(map(f,w)),'row_residuals':list(map(f,row_residual)),'cell_slacks':list(map(f,cell_slack)),'invalid_flow_edges':invalid,'flow_feasible':feasible,'cut_rows':cut,'cut_neighborhood':sorted(U),'cut_demand':f(demand),'cut_mass':f(mass),'cut_lower_infinite':infinite,'cut_lower':None if infinite else f(lower),'proven_exact_optimum':exact,'metadata':d.get('metadata',{}),'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest() if a.input else None,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime':{'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
a.output.write_text(json.dumps(out,indent=2)+'\n');print('flow_feasible',feasible,'cut_lower',('infinite' if infinite else lower),'gamma',gamma,'exact',exact,'sha',out['script_sha256'])
