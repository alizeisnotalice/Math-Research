import numpy as np
from scipy.optimize import linprog
from fractions import Fraction as F
A=2

def arrangement(cubes):
 arr=np.array(cubes,np.int64);R=arr[:,0];xy=arr[:,1:];lo=xy-A*R[:,None];hi=xy+A*R[:,None];edges=[np.unique(np.r_[lo[:,k],hi[:,k]]) for k in (0,1)];low=np.stack([np.searchsorted(edges[k],lo[:,k]) for k in (0,1)],axis=1);high=np.stack([np.searchsorted(edges[k],hi[:,k]) for k in (0,1)],axis=1);shape=(len(edges[0]),len(edges[1]));return R,xy,lo,hi,edges,low,high,shape

def field(low,high,shape,w):
 z=np.zeros(shape,dtype=w.dtype);a,b=low[:,0],low[:,1];c,d=high[:,0],high[:,1];np.add.at(z,(a,b),w);np.add.at(z,(c,b),-w);np.add.at(z,(a,d),-w);np.add.at(z,(c,d),w);np.cumsum(z,axis=0,out=z);np.cumsum(z,axis=1,out=z);return z

def lp(R,xy,lo,hi,edges,low,high,shape):
 n=len(R);points=[];mp={};own=[]
 for z in xy:
  point=tuple(min(max(np.searchsorted(edges[k],z[k],side='right')-1,0),shape[k]-2) for k in (0,1))
  if point not in mp:mp[point]=len(points);points.append(point)
  own.append(mp[point])
 def incidence(pts):
  p=np.array(pts);return (low[:,0,None]<=p[None,:,0])&(p[None,:,0]<high[:,0,None])&(low[:,1,None]<=p[None,:,1])&(p[None,:,1]<high[:,1,None])
 volumes=(A*R/2)**2;iterations=0;sol=None
 while iterations<200:
  M=incidence(points);sol=linprog(np.ones(len(points)),A_ub=-M.astype(float),b_ub=-volumes,bounds=(0,None),method='highs');assert sol.success
  dual=np.maximum(-sol.ineqlin.marginals,0);v=field(low,high,shape,dual)[:-1,:-1];k=np.unravel_index(int(np.argmax(v)),v.shape);iterations+=1
  if v[k]<=1+1e-9:break
  k=tuple(map(int,k))
  if k in mp:break
  mp[k]=len(points);points.append(k)
 assert len(points)==len(sol.x);scale=1<<30;pr=np.ceil(np.maximum(sol.x,0)*scale).astype(np.int64);covered=M.astype(np.int64)@pr;ivol=np.rint(volumes*4).astype(int) # volumes may quarters; exact in 1/4 units.
 for i in range(n):
  lack=max(0,(int(ivol[i])*scale+3)//4-int(covered[i]))
  if lack:pr[own[i]]+=lack;covered+=M[:,own[i]].astype(np.int64)*lack
 assert np.all(4*covered>=ivol*scale)
 dq=1<<38;dy=np.floor(dual*dq).astype(np.int64);f=field(low,high,shape,dy);md=int(np.max(f[:-1,:-1]));dq=max(dq,md);L=sum((F(int(v)*int(d),4*dq) for v,d in zip(dy,ivol)),F());U=F(int(pr.sum()),scale)
 assert L<=U
 cells=[]
 for k in np.flatnonzero(pr):
  i,j=points[k];cells.append([str(F(int(edges[0][i]),4)),str(F(int(edges[0][i+1]),4)),str(F(int(edges[1][j]),4)),str(F(int(edges[1][j+1]),4)),str(F(int(pr[k]),scale))])
 return {'dual_lower':str(L),'primal_upper':str(U),'relative_gap':float((U-L)/U),'iterations':iterations,'patterns_used':len(points),'source_cells':cells,'dual_weights':[str(F(int(v),dq)) for v in dy],'pricing_cells':int((shape[0]-1)*(shape[1]-1))}
