"""Independent archive checks. No PDF compilation or unrestricted search."""
import argparse, concurrent.futures, hashlib, json, os, platform, re
import subprocess, sys, tempfile, time
from fractions import Fraction as F
from pathlib import Path
import sympy as sp

p=argparse.ArgumentParser()
p.add_argument('--all-case-dir', type=Path)
p.add_argument('--workers', type=int, default=12)
p.add_argument('--output', type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parent
started=time.monotonic()
assert 1<=a.workers<=15
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
data=json.loads((root/'case03.json').read_text())
bundle=json.loads((root/'case03_flow.json').read_text())
bad=data['certified_bad_full_cells']
assert len({tuple(z['cell']) for z in bad})==len(bad)==16
assert all(F(c[4])>=0 for c in data['source_cells'])
for z in bad:
    i=z['i']; x0,x1,y0,y1=map(F,z['cell'])
    available=[]
    for j in data['essential_indices']:
        r,x,y=data['cubes_quarter_units'][j]
        if F(x-r,4)<=x0 and x1<=F(x+r,4) and F(y-r,4)<=y0 and y1<=F(y+r,4):
            available.append(j)
    expected=min(available,key=lambda j:(-data['cubes_quarter_units'][j][0],j))
    assert i==expected
uniform={}
for kind,rec in bundle['adjacency'].items():
    ms=list(map(F,rec['mass']))
    load=[F() for _ in ms]
    for row in rec['rows']:
        w=F(row['demand_upper']); assert w==F(row['demand_lower'])
        den=sum((ms[s] for s in row['cells']),F()); assert den>0
        for s in row['cells']:load[s]+=w/den
    uniform[kind]=str(max(v for v,m in zip(load,ms) if m>0))
    assert F(uniform[kind])==F(rec['gamma'])
H,sigma,b=sp.symbols('H sigma b', positive=True)
margin=1-1/H-1/(1+sigma)
assert sp.simplify(margin-(sigma*(H-1)-1)/(H*(1+sigma)))==0
assert margin.subs({H:3,sigma:2})==sp.Rational(1,3)
assert margin.subs({H:2,sigma:1})==0
L,h,o,sj,d=sp.symbols('L h o sj d')
assert sp.expand(h-sj*d-(h-o)-(o-sj*d))==0
tex=(root/'REPORT.tex').read_text()
assert sorted(re.findall(r'\\begin\{([^}]+)\}',tex))==sorted(re.findall(r'\\end\{([^}]+)\}',tex))
assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex))<=set(re.findall(r'\\label\{([^}]+)\}',tex))
manifest=root/'MANIFEST.json'
if manifest.exists():
    for name,sha in json.loads(manifest.read_text())['sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name

with tempfile.TemporaryDirectory(prefix='r625-verification-') as tmp:
    td=Path(tmp)
    cmd=[sys.executable,str(root/'certificate.py'),'--bundle',str(root/'case03_flow.json'),
         '--base',str(root/'case03.json'),'--output',str(td/'case03-certificate.json')]
    result=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True)
    receipt=json.loads((td/'case03-certificate.json').read_text())
    all_receipts=[]
    if a.all_case_dir:
        cases=sorted(a.all_case_dir.glob('case[0-9][0-9].json'))
        assert len(cases)==12
        summary=json.loads((root/'BATCH_SUMMARY.json').read_text())
        expected={z['case']:z for z in summary['results']}
        def check_case(path):
            inp=json.loads(path.read_text()); cid=inp['case']; exp=expected[cid]
            for key in ('V','N','n','a','certified_bad_area'):assert inp[key]==exp[key],(cid,key)
            assert inp['Qstar']['primal_upper']==exp['Q_upper']
            assert inp['Qstar']['dual_lower']==exp['Q_lower']
            output=td/f'base-{cid}.json'
            cp=[sys.executable,str(root/'certificate.py'),'--base-only','--base',str(path),'--output',str(output)]
            subprocess.run(cp,env=env,capture_output=True,text=True,check=True)
            rec=json.loads(output.read_text())
            return {'case':cid,'V':rec['V'],'source_total':rec['source_total'],
                    'dual_objective':rec['dual_objective'],'max_dual_load':rec['max_dual_load'],
                    'cpu_seconds':rec['cpu_seconds'],'wall_seconds':rec['wall_seconds'],
                    'peak_rss_bytes':rec['peak_rss_bytes'],
                    'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(a.workers,len(cases))) as pool:
            all_receipts=list(pool.map(check_case,cases))
    out={'status':'PASS','scope':'exact source/packing, fixed subset flows, symbolic identities, and archive integrity; no general upper bound',
         'python':sys.version,'executable':sys.executable,'sympy':sp.__version__,'platform':platform.platform(),
         'command':[sys.executable]+sys.argv,'uniform_Bmax':uniform,'case03_certificate':receipt,
         'all_case_source_checks':all_receipts,'certificate_process_limit':min(a.workers,len(all_receipts)) if all_receipts else 1,
         'wall_seconds':time.monotonic()-started,
         'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if a.output:a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'case03_uniform':uniform,'independent_source_cases':len(all_receipts),
                      'wall_seconds':out['wall_seconds']},ensure_ascii=False))
