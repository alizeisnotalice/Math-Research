# R625 共同fresh-source分配：独立合同预审

日期：2026-10-28。只读R624最终报告第1、4–6节旧合同，未读R625新作者稿；不改repo、不启动Agent、不运行数值或实例扫描。本文只核必要充分合同、可用辅助式及完整族回代，不把有限Hall等价当作新的根阶估计。

## 1. 冻结对象与判断

固定全部原B_j、A_j=aB_j，a≥n≥2，d_j=|A_j|，E=∪B_j，V=|E|，以及完整packing/source LP值Q*。先选择一次完整最优L1来源μ，满足μ(R^n)=Q*、μ(A_j)≥d_j对全部原rows成立。保留原合同中零receiver增量row的source约束。μ可以从完整最优面中择优，但不能在每个cut、pair、修剪子族上分别改选。

固定R624合法T及最大essential原row代表、winning-seed tie rule，并将低h坏receiver真实不交地分成G_p，p=(i,j)，w_p=|G_p|，D_p=A_j\A_i。这里h_i=μ(A_i)/d_i≤2、r_j>(1+2/n)r_i、x∉B_j于G_p。只保留w_p>0的有限pair集合P。总需求W=Σ_pw_p是低h坏receiver体积，绝非Σ|B_i|或逐seed重复的halo体积。

允许在每个D_p内自由选择收费分布，确实严格放松了R624的固定uniform收费。其准确最佳费用是下面的cut比值。当前已有逐pair增长只保证费用有限；没有给出与N、半径跨度无关的根阶上界。

## 2. 精确有限流及必要充分cut

用全部原A_j边界形成正体积source arrangement cells H。令z_h=μ(h)，M_ph=1当且仅当h⊂D_p。取μ为L1使边界零质量；零质量cell不可提供容量。若最优来源原先任意分布，把每cell质量均匀摊开保持全部μ(A_j)、μ(D_p)、h_i及本合同不变，因此有限cell化不额外限制可选最优来源。

对Γ≥0，要求存在f_ph≥0满足

Σ_h f_ph=w_p；f_ph=0若M_ph=0；Σ_p f_ph≤Γz_h。

这等价于存在收费测度ν_p，满足ν_p(D_p^c)=0、ν_p(R^n)=w_p，且Σ_pν_p≤Γμ。这里是测度集中于D_p，不要求拓扑support包含于开集合D_p。流可在z_h>0的cell上以密度f_ph/z_h相对μ实现；Γ>1时这是带明确倍率的收费预算，不是把原μ无倍率拆成多个合法bad来源。

有限max-flow/min-cut给准确必要充分条件：对每个pair子集S⊂P，

W(S):=Σ_(p∈S)w_p ≤ Γ μ(U(S))，U(S):=∪_(p∈S)D_p。   (C)

必要性直接对Σ_(p∈S)ν_p积分；充分性来自需求端p到可用cell的二部容量流。重复或相同D_p不允许重复计算右端质量。因此

Γ_opt(μ)=max_(∅≠S⊂P) W(S)/μ(U(S))。

有正需求而分母零时比值为∞；P为空时费用取0。本旧合同下μ(D_p)>0，有限多个pairs使全部非空cut分母正，所以最大值有限且流最优达到。它仍可能很大。

等价的加权cut形式是：对任意t_p≥0，

Σ_pw_pt_p ≤ Γ∫ max_(p:y∈D_p)t_p dμ(y)，

空max取0。它由(C)对{p:t_p>s}逐层积分得到，取t为indicator也恢复(C)。这提供合法可检验对偶，不增加pair数或cell数因子。

## 3. cut外来源、量词与有限几何

源在U(S)外的质量不能服务cut S。W(S)≤ΓQ*只是一条更弱的必要条件，因为μ(U(S))≤Q*；不能用它替代(C)。同样，单独验证每个pair的w_p≤Γμ(D_p)，或验证W≤ΓQ*，均不足以验证全部cuts。最终用W≤ΓQ*时，是在完整流已经可行之后对总容量求和；此时允许cut外容量闲置，没有忽略任何需求或重复领取来源。

合法全局量词是：对每个完整有限family，存在一个完整最优μ及一组共同冻结的几何/修剪/代表选择，使全部cuts同时满足同一个Γ_n。逐cut存在不同最优μ的陈述远弱于此，不足够。若先优化μ，再按其h_i划分low/high，必须使用新划分的真实w_p重新检验全部cuts。不能平均两份μ后沿用其中一份的low/high分类或流证书。若对最优面上的Γ取inf，h_i=2处的分类变化也使“inf自动由某一μ达到”并非免费；存在任意统一误差的近优共同选择足以在最终常数中取极限，但每一选择必须自身满足完整合同。

实际G_p不必是原source cells的并。这不妨碍有限流：源侧只需要D_p的有限incidence，receiver侧进入的是有限个真实数w_p。R624用有限receiver arrangement cells、cell到矩形的d_k距离、有限max及固定tie构造T；这些距离为分段仿射，进一步有限refinement后G_p可作有限多面体区域的并（忽略边界）。这不是说仅用原cube边界已经给出G_p的全部体积。若以后允许任意可测F，则G_p仍须可测，但未必多面体；有限pair的流合同仍成立，精确求w_p可能另需证明或证书。有限probe胜者、bin中心或phase样本不能替代真实w_p。

## 4. 已证辅助界与可修复的cut桥

记b_n=(1+2/n)^n≥4。低h合同比单纯μ(D_p)≥μ(A_i)还给

μ(D_p)≥d_j−μ(A_i)≥d_j−2d_i
          ≥(1−2/b_n)d_j≥d_j/2，

以及μ(D_p)≥(b_n−2)d_i≥2d_i。严格半径差可使相应中间不等式严格；本处只需要弱界。这些是同一μ下的真实质量估计。

一个可供新证明使用的cut辅助结论如下。对任意S，令J(S)为其seed j集合，ν_S=μ|U(S)。每个j∈J(S)至少有一条pair边，故ν_S(A_j)≥d_j/2。因此seed子族的原packing值满足

Q*_(J(S)) ≤ 2 μ(U(S))。                         (A)

若另能对每个cut证明其真实需求W(S)≤L_n Q*_(J(S))，则(C)以Γ=2L_n成立。这是一个充分的几何桥，尚非已证结论。G_ij的点恰在B_j之外，不能把W(S)当成∪_(j∈J(S))B_j的体积，也不能直接把完整receiver常数应用于这些外部shadows。ν_S/其常数倍对seed stars有阈值控制，不保证对owner stars A_i有同一阈值；D_ij本来就排除了A_i。忽略这点会重新引入免费halo或循环使用待证的root估计。

有限且无几何收益的基线也可明确写出。令I(S)为cut中的不同owner i；因G_p互不交且G_ij⊂B_i，

W(S)≤a^(−n)Σ_(i∈I(S))d_i，
μ(U(S))≥(b_n−2)max_(i∈I(S))d_i。

所以Γ_opt≤N/[a^n(b_n−2)]。这只重现N/a^n类easy门槛，不能算N无关的推进。更直接，固定uniform流给

Γ_opt≤esssup_μ Σ_p [w_p/μ(D_p)]1_(D_p)，

即R624旧费；优化流只能不增这一值。若能证明D_p的μ-a.e.重叠次数≤L，则上式及w_p≤d_i/a^n给Γ_opt≤L/[a^n(b_n−2)]，但本轮没有这种重叠界，不得默认它。

还可保留最优LP的共同互补松弛：对任一原最优packing λ，μ-a.e.原load为1，且λ_j>0⇒μ(A_j)=d_j。因此对任意可测U，μ(U)=Σ_jλ_jμ(A_j∩U)。这是同一份来源在cut内的精确账，不能将右端的受限质量擅自换成完整μ(A_j)，或对每个cut独立发一份Q*。

## 5. 根阶Γ若得证时的完整吸收与原输入恢复

设共同修剪删去s个窄bands，删除费≤sPeQ*；good域体积≤e²C_nkP_3Q*；低h坏域由上述流得到W≤Γ_nQ*。高h>2的所选receiver属于全部高h原rows的union，同一个μ/2使这些原stars严格满足原阈值。令D_n(a)=sup完整V/Q*，已由R624独立O(n log n)基线知道有限，则高h部分≤D_n(a)Q*/2。

因此每个适用family有

V/Q*≤e²C_nkP_3+sPe+Γ_n+D_n(a)/2。

若其它easy分支由K_easy支付，且上述共同选择对所有其余完整families统一有效，则取sup并吸收得

D_n(a)≤max{K_easy, 2[e²C_nkP_3+s_nPe+Γ_n]}。

a≥n及k≈√n使P≤e、P_3≤e³、C_nk=O(√n)。故若s_n与Γ_n均为O(√n polylog n)，确可闭合完整根阶付款；不修剪则s_n=0。high分支里的D_n(a)只以严格小于1的系数1/2出现，而且已有独立有限粗界，这一吸收不循环。相反，若在证明cut容量时再把D_n(a)不带收缩地调用一次，则必须重新列完整系数，不能藏在Γ_n中宣称吸收。

这里几项是同一个Q*的解析上界之和，不是把good packing、cut收费和high子族的来源实际并列合成一份无倍率source。每项系数都已显示。若换用非最优来源质量M，最多先得V≤K M；除非另有M≤cQ*的已付界，不能直接回代完整Q*。log-barrier来源M=Q+εV也不是本文的精确最优μ，需另保留ε并做吸收。

一旦得到对所有完整有限families的V≤K_nQ*，对真实原输入f∈L1的同水平bad stars用原packing弱对偶有ηQ*≤||f||_1。对超水平紧集用相应1/a小cubes取有限覆盖，再以内正则性恢复全部尺度。a=a(n)须在处理任意family前固定；μ是证明用的几何最优来源，不必等于原f，也不允许每个cut更换。此完整族回代没有新增Ccov或丢掉零receiver增量row的费用。

## 6. 当前结论与禁止步骤

通过的是自由收费与有限流/全部cuts的精确等价、共同最优来源量词、真实receiver体积的有限索引处理、辅助seed子族界(A)，以及条件性根阶Γ的完整high-h吸收。没有证明Γ_opt的N及半径跨度无关上界，也没有证明新的统一shadow估计。

新稿若出现下列步骤应拒绝：以总source质量替代每个cut可达质量；由逐pair增长断言全部Hall cuts；逐cut改选μ；将G_ij当B_j内receiver；将fractional收费测度当作新的原阈值bad来源；把有限source-cell流等价或有限实例可行性称为一般root进展。可修复方向是同一μ上逐cut的真实shadow/seed信用比较，或另一个显式可求和的共享质量机制，而不是省略cut外来源或重命名Hall条件。

本次独立有界预审完成，等待作者候选后再核未付几何步；到此停止。

## 7. 参数独审：t=4、H=3、σ=2及两种可用source集合

新增核验只读根代理保存的`/tmp/ccu_r625_final/PARAMETERS.json`，未自行运行计算。JSON明确只是符号参数账、不是coalition expansion定理；以下结论由解析式独立推出。

将good阈值改为T≤(1+t/n)(a+3)r_i，t>0，则good费为e^t C_nkP_3。因为实数s>0上的s log(1+t/s)递增（导数log(1+t/s)−t/(s+t)>0），n≥2时

b_n(t)=(1+t/n)^n≥(1+t/2)^2。

低h阈值h_i≤H时，bad pair有μ(A_j)/μ(A_i)≥b_n(t)/H，且μ(A_j\A_i)≥(1−H/b_n(t))μ(A_j)。t=4、H=3给b_n≥9、质量比≥3、fresh占seed质量至少2/3；高h>3部分同源吸收费为D_n(a)/3。等号边界不妨碍这些弱界，高h分支仍严格满足μ/3上的原阈值。

联合cut须明确flow eligibility。令X(S)=∪_(i,j∈S)A_i，Y(S)=∪_(i,j∈S)A_j。若对所有cuts同时有

μ(Y(S)\X(S))≥σ μ(X(S))，                       (UE)

则μ(X(S)∪Y(S))≥(1+σ)μ(X(S))。由于μ|X(S)对owner子族仍保持全部原阈值，W(S)≤|∪owner B_i|≤D_n(a)μ(X(S))。因此若允许每pair的收费邻域扩大为A_i∪A_j，联合cut邻域正是X(S)∪Y(S)，Hall可给Γ_joint≤D_n(a)/(1+σ)。这项收费只作为完整receiver体积账，无须将联合邻域误称fresh来源。

若仍坚持§2的原fresh-only邻域D_ij=A_j\A_i，则只能直接使用Y(S)\X(S)⊂∪_SD_ij，从(UE)推出Γ_fresh≤D_n(a)/σ；不能保留同一个Γ=D/(1+σ)。两种流都可合法收费，但须分别列清邻域。

联合流的完整收缩条件为1/H+1/(1+σ)<1，等价于σ>1/(H−1)。t=4、H=3、σ=2使总系数2/3、余量1/3，参数无误；若无其它删除费用，条件性回代是D_n(a)≤3e^4C_nkP_3（easy分支另取max）。fresh-only流在同一σ=2下亦可吸收，但系数为1/3+1/2=5/6、余量1/6，相应常数为6而非3。额外删带或其它显式费用须一并乘最终吸收因子。

**尚未认证的核心：** 单pair的μ(A_j)≥3μ(A_i)，甚至μ(A_j\A_i)≥2μ(A_i)，不推出所有cuts的(UE)。某pair的fresh部分可落在其它owner A_l内；联合后必须在整个X(S)之外再算质量，不能逐pair相加。有限参数符号式或逐pair质量增长均不填补这个union expansion缺口。只有(UE)对同一个完整最优μ及同一全部pair系统同时成立，或给出另一个可吸收的精确cut界，上述一般回代才闭合。等待作者稿核对其实际eligibility与此未证条件，不提前认证(UE)。

## 8. Bridge稿独审：合法merge、凸平均及whole-row修复费

现已只读`/tmp/ccu_r625_bridge.md`，逐式核验其(1)–(7)及两row实例；没有运行计算。冻结原finite rows，L、H均为其全部权合成的pointwise packing loads≤1。s_j=esssup_(A_j)H、δ_j=γλ_js_j给0≤δ≤λ，且删除load≥γHL。因此新load≤L+γH−γHL=1−(1−L)(1−γH)≤1。这是每个实际source位置上的同一可行packing；有限open rows也使esssup能控制其内部全部点。不能只验证incoming各piece分别可行后把总H相加。

准确objective差是γ[q_ψ−Σ_jλ_jd_js_j]，展开即稿中γ[∫H(1−L)−Osc_λ(H)]。Osc≥0，对H是sup项减线性项，故凸；固定同一个λ时先平均incoming profile再修复，Osc(EH)≤E Osc(H)，费用方向正确。相交indicator上界给稿(3)，它只是该具体merge费用的上界，不是任意可行repair必须支付的下界。平均profile可行不等于不同bins逐outcome仍disjoint，桥稿已保留该区别。

incoming为权1的disjoint原stars时，H为其union indicator，s_j恰标记是否与该open union相交。Osc因此等于在seed union外连带丢失的旧row目标(5)。若far row指定相交seed k且r_j≤ηr_k/n，则A_j⊂(1+2η/n)A_k；在seed union外使用旧packing load≤1及collar体积次可加，得Ω_F≤[(1+2η/n)^n−1]S。它控制的是Lebesgue objective，未假设原source在collar内质量小。令γ=1，并仅对此一次完整candidate用Q*−Q≤εV，严格得到(7)的free-volume≤far collar+near Osc+εV；不能逐piece重复领εV。

两row例也符合完整真实合同。n≥2、a≥n时center间距ar≥2r使小open receivers不交；原stars交体积d/2。λ=(1/2,1/2)在交内饱和，交内常密L1来源总量d+2εd/a^n满足两row同一barrier需求。全量插入第二row使交内旧两权必须同时删满，repair成本d；overload积分为3d/4，extra whole-row费为d/4，Osc与free term各d/4，实际gain为0。此例只认证near修复确可有真实whole-row成本；V/Q=2/a^n本已很小，不能当一般root目标或平均化机制的反例。

本bridge通过范围限于实际可行merge、固定旧packing下的凸平均、远尺度collar及该有限实例。没有证明累计near Osc的可求和root界，没有把mean load当pathwise disjoint seeds，也没有新的全局维数阶数。R625主REPORT尚未到达，待其落盘只复核联合cut参数和未证expansion范围。

## 9. 主REPORT最终复核与停止结论

现已阅读`/tmp/ccu_r625_REPORT.tex`，本节只核关键合同、参数及证据scope，不重跑有限case证书。主稿明确使用local L_p=A_i、fresh F_p=A_j\A_i及joint J_p=A_i∪A_j三种不同邻域；其(2.2)各自按全部cuts取真实可达union质量，(3.3)的D/(1+σ)只给joint，(3.4)的D/σ只给fresh。式(3.5)正确保留fresh被其它locals吞回的cross-term，与本审计§7的区别一致。

主稿新增local质量band工具亦通过：在s≤μ(A_i)<2s且h_i≤H的同一band内，s/H≤d_i<2s；在任意source点y，相关实际不交G_i全落在半径(a+1)r_max的cube内。因此Σw_i/d_i≤2HP，给(2.5)。其可加收费把K明确乘回receiver需求，未调用降低阈值的弱型估计；多个bands仍须付band数，稿件没有宣称常数local费控制全部尺度。

主稿(4.1)–(4.5)完整保留good费、删带费、high-h的D/H及joint或直接流费。t=4、H=3、b_n≥9及全部cuts另满足σ≥2时，总系数至多2/3，故条件性D≤3[e^4C_nkP_3+sPe]成立。若直接证明共同Γ_n，吸收因子H/(H−1)也正确。一个非实质文字点：(4.3)在仅知σ≥b/H−1时，1/H+H/b是总系数的“上界/至多”，不必是实际系数的相等式。该点不影响示例参数或条件结论。

**一般回代尚未闭合。** 主稿明确未证明存在同一个完整最优μ，使全部真实coalitions同时有σ≥2；没有把单pair质量比≥3、Hall等价、参数JSON或有限流实例升级为这个未证几何命题。固定参数可以修好临界系数，不能修好共同union扩张。若以后有一般expansion或替代收费证明，再按已核参数回代即可；本稿目前不能据此替换原母账。

case03所述总面积1、固定9个witness的有限子集，被明确限制为旧参数下的真实低h坏子集，未声称全坏域、全局最大seed或新参数分类。所列source质量17+239+16+1=273，fresh/local/joint全需求cut分母255/1/256及总source外的17之区别，和“uniform与optimized相等、local已付所以停止扩展”的scope一致。本次不独立认证其flow可行端点或真实几何，仅核稿件证据边界。P=9/4下(V/Q*)/P=2213/2457的算术正确；它区分有限packing比与原弱型比。严格超水平解释可取水平从下方趋近1/P，不将原B内每点当成原阈值bad点。

最终通过范围：精确容量cut合同、共同来源量词、local band工具、joint/fresh不同费用、t4/H3/σ2条件性完整吸收，以及bridge的合法merge/mean convexity/远collar和有限two-row成本。仍未证的是全部cuts的union expansion或另一个根阶共同预算；本轮没有新的全局维数上界。只更新本审计文件，无计算或新Agent。审查完成，停止。

## 10. 根归档版的量词修正

最后定点核对`/tmp/ccu_r625_final/REPORT.tex`：收费条件已写为ν_p(R_p^c)=0，正确表示测度集中于可达集合；不再要求拓扑support包含于可能开放的R_p。全族D_n(a)递推前已明确固定同一组参数，并要求对全部有限族统一的删带数上限s（无修剪s=0）。每个family各自有有限s、或各自有限尺度跨度，均不足以带过全族sup；此修正与本审计的uniform s_n条件一致。

归档版也已将σ≥所导出的收缩系数写为“至多”，并仅保留local/fresh付款选择，不声称local是母目标必需机制。项目12个有限候选的实际计算范围由项目陈述承担；本独审未重算这些候选或独立认证其全部有限证书。以上修正不改变参数合法、union expansion仍未证及一般回代未闭合的最终判断。归档量词核对完成，停止。
