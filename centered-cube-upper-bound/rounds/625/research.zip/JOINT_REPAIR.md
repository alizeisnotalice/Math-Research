# R625：近尺度packing合并的exact cross-term与合法平均

**范围。** 本稿给完整可行的fractional合并、实际overlap-saving费用及平均化不增费；没有取得新的全局阶数，也不作为根阶改善。R624远尺度拼接已经付款；本轮未付的是近尺度whole-row冲突的共同receiver/source收费，不能只用intersection体积替代。

## 1. 同一原family上的完整合并

原stars A_j、d_j=|A_j|全部冻结。当前packing λ的load为L≤1，incoming packing ψ的load为H≤1。H必须是全部incoming rows合计后的真实pointwise可行profile；不能只分别核每个piece。

定义

`s_j=ess sup_{y∈A_j} H(y)`，
`δ_j=γ λ_j s_j`，`0<=γ<=1`，
`λ'=λ−δ+γψ`。

因s_j≤1，δ≤λ；每个y的删除load至少γH(y)L(y)，故

`L_{λ'}(y)<=L(y)+γH(y)−γH(y)L(y)<=1`。              (1)

open stars的finite loads为lower semicontinuous，ess sup可控制所有A_j内点。因此这是原rows上合法的实际packing，而不是仅期望可行。

记

`Osc_λ(H)=Σ_jλ_j[d_js_j−∫_{A_j}H(y)dy]>=0`。

完整objective增量准确为

`Q(λ')−Q(λ)=γ[∫ H(1−L)dy−Osc_λ(H)]`。             (2)

实际pair overlap明确保留：

`Osc_λ(H)<=Σ_{j,k}λ_jψ_k[d_j1_{A_j∩A_k≠∅}−|A_j∩A_k|]`。 (3)

(3)的右侧只是上界，不能把它当最小repair的必要值；(2)则是此具体合并的exact费用。反向合并可得到另一种实际可行候选，但不能先独立优化两方向后把收益相加。

## 2. mean convexity合法；不能混成pathwise不交

固定λ时，Osc_λ(H)对H凸。因此对可积随机incoming profiles，

`Osc_λ(E H_ω)<=E Osc_λ(H_ω)`。                      (4)

若H_ω来自R624窄bin的pathwise disjoint seed律，则平均原row权`ψbar=Eψω`确实是一个fractional packing；其目标为平均目标。可以先平均再用(1)，费用不增；这是合法的overlap smoothing。

这不意味着不同bins的random outputs合起来仍pathwise不交，也不意味着每bin各自H≤1可推出其总和≤1。R624递归删低rows需要每个outcome真实不交，不能免费把mean packing代入该步骤。若只随机选一个bin后平均，虽可行，仍可能保留原近尺度class损失。本稿没有证明跨bins共享选择能消掉此损失。

## 3. disjoint seeds的几何费与远/近定位

若incoming ψ是一套disjoint原seed stars的权1，记H=1_H、`S=|H|=Σ_seed d_k`。此时

`Osc_λ(H)=Ω=∫_{H^c}Σ_{j:A_j∩H≠∅}λ_j1_Aj(y)dy`。    (5)

这是整row因source冲突被删除时，在seed union外连带丢掉的真实packing objective。

将冲突rows分为F、N：F中的每row可指定一个相交seed k使`r_j<=ηr_k/n`；其余为N。由原cubes几何，F-row的A_j在`(1+2η/n)A_k`内。packingload≤1给

`Ω_F<=B_η S`，`B_η=(1+2η/n)^n−1`。                 (6)

这是Lebesgue objective的边界费，绝未推μ边界质量小。若当前λ是完整barrier且`Q*−Q<=εV`，任何一次joint seed插入的objective提升≤εV，故由(2)

`∫_H(1−L)dy<=B_η S+Ω_N+εV`。                      (7)

εV只可对此次global candidate使用，不能在每piece独立领一次。取固定小η可使B_η<1，但(7)未带来新全局维数收益：disjoint seeds本身已满足S≤Q*。它的有用内容是把local free-volume/repair亏损准确拆为已可付far collar与尚未控制的near cross-term Ω_N。

## 4. near whole-row费用有真实强制下界

若当前packing在source cell C饱和，`Σ_{j∈C}λ_j=1`，incoming单位seed覆盖C，则加满该seed时任何合法删除`0<=δ<=λ`都必须

`Σ_{j∈C}δ_j>=1`。

因此全部正λ_j（j∈C）都必须删满，必付`Σ_{j∈C}λ_jd_j`，包括这些rows在incoming star外的objective。只按source cell或intersection的体积计费会漏掉该whole-row成本。

一个完全真实且同barrier兼容的最小核验：取n≥2、a≥n、两个等半径原B，中心相距ar e_1。原stars体积同为d，交体积d/2；小receivers不交，`v_1=v_2=d/a^n`。当前`λ=(1/2,1/2)`。将质量

`M=d+2εd/a^n`

的L1 source放在star交内，则每row满足`μ(A_j)=d+εv_j/λ_j`，正source cell饱和，`M=Q+εV`。

incoming ψ为第二row权1。合法全量插入必须删除两项旧权，最小repair费R=d；实际overload积分仅3d/4，额外whole-row费为d/4，恰等于(5)的Osc；free term也为d/4，所以objective增量0。

本例只证明该near费用不总是上界算法的伪影；它并不证明全族必须损n log n。事实上其`V/Q=2/a^n`很小，原packing早已足够支付receiver。一般问题恰需要把这种“旧packing已能支付”的credit与所有近尺度receiver共同配对，而不是对每次插入重新记一份来源。

## 5. 本轮判断与停止

未证明近尺度平均profile的Osc_N可root收费，也未证明共同marks能使累计forced-clique deletion有可求和收缩。逐次套(2)会留下重复的near cross-term，若按classes分别付仍回到R624损失；不能把它写成新root机制。

本稿保留的可用结论是(1)–(4)的完整可行合并/mean convexity与(5)–(7)的明确near费用定位。研究venv SymPy实际核验了exact fee、两row的sharp额外repair及barrier总质量；没有扫描、重计算、LP或新agent。完成停止。
