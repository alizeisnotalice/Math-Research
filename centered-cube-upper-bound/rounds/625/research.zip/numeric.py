import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,ctypes,hashlib,json,platform,resource,shlex,sys,time
from pathlib import Path
from fractions import Fraction as F
import numpy as np,scipy
import numeric_base as base

def build(k):
 distance=[44,48,52,56,60,64][k%6];shift=0 if k<6 else 6;cubes=[]
 for R,ox,oy in [(16,0,0),(4,22,shift),(1,distance,shift)]:
  vals=sorted(set((-2*R+1,-R,0,R,2*R-1)))
  for x in vals:
   for y in vals:cubes.append((R,ox+x,oy+y))
 return cubes

def task(k):
 start=time.monotonic();cpu=time.process_time();cubes=build(k);R,xy,lo,hi,edges,low,high,shape=base.arrangement(cubes);Q=base.lp(R,xy,lo,hi,edges,low,high,shape);z=Q['source_cells'];rowmass=[]
 for i in range(len(R)):
  sx0,sx1,sy0,sy1=[F(int(v),4) for v in (lo[i,0],hi[i,0],lo[i,1],hi[i,1])];mass=F()
  for raw in z:
   a,b,c,d,m=map(F,raw)
   if sx0<=a and b<=sx1 and sy0<=c and d<=sy1:mass+=m
  rowmass.append(mass)
 vol=[F(int(r*r)) for r in R];h=[u/v for u,v in zip(rowmass,vol)];n=len(cubes)
 origin=(xy-R[:,None]).min(0);end=(xy+R[:,None]).max(0);gshape=tuple((end-origin).tolist());owner=np.full(gshape,-1,np.int32)
 for j in np.argsort(R,kind='stable'):
  x,y=xy[j];r=R[j];block=owner[x-r-origin[0]:x+r-origin[0],y-r-origin[1]:y+r-origin[1]];block[block<0]=j
 counts=np.bincount(owner[owner>=0],minlength=n);ess=counts>0;V=F(int(counts.sum()),16)
 # Max-essential receiver row, max radius and then original index.
 imax=np.full(gshape,-1,np.int32)
 for j in np.argsort(-R,kind='stable'):
  if not ess[j]:continue
  x,y=xy[j];r=R[j];block=imax[x-r-origin[0]:x+r-origin[0],y-r-origin[1]:y+r-origin[1]];block[block<0]=j
 loc=np.argwhere(owner>=0);uv=loc+origin;centers8=2*uv+1;best=np.full(len(loc),-10**9,np.int64);win=np.full(len(loc),-1,np.int32)
 # Each min-owner unit cell is a true source seed; evaluate a valid cone lower envelope at centers.
 # In eighth-units, 16*T=20*R−dist_8; this lower envelope is pointwise <= true T.
 seeduv=uv;seedrow=owner[loc[:,0],loc[:,1]];eligible_seed=np.flatnonzero(ess)
 for j in eligible_seed:
  seeds=seeduv[seedrow==j]; jl=2*seeds;ju=jl+2
  for startrow in range(0,len(loc),256):
   pts=centers8[startrow:startrow+256];dx=np.maximum(np.maximum(jl[None,:,0]-pts[:,None,0],pts[:,None,0]-ju[None,:,0]),0);dy=np.maximum(np.maximum(jl[None,:,1]-pts[:,None,1],pts[:,None,1]-ju[None,:,1]),0);vals=20*int(R[j])-np.min(dx+dy,axis=1);sl=slice(startrow,startrow+len(pts));mask=vals>best[sl];best[sl][mask]=vals[mask];win[sl][mask]=j
 chosen=imax[loc[:,0],loc[:,1]];assert np.all(chosen>=0);hiok=np.array([h[i]<=2 for i in chosen]);margin=best-40*R[chosen]
 # center bound > threshold+1/8: Lipschitz T in L1/2 certifies the entire quarter-grid square.
 bad=(margin>2)&hiok;records=[]
 for pos in np.flatnonzero(bad):
  u,v=map(int,uv[pos]);i=int(chosen[pos]);j=int(win[pos]);records.append({'i':i,'j_lower_witness':j,'cell':[str(F(u,4)),str(F(u+1,4)),str(F(v,4)),str(F(v+1,4))],'witness_center_margin_sixteenths':int(margin[pos]),'hi':[h[i].numerator,h[i].denominator]})
 # Receiver cell list retained so geometry can reconstruct genuine owner seed regions.
 seed_cells=[]
 for j in eligible_seed:
  sq=seeduv[seedrow==j];seed_cells.append({'j':int(j),'R':int(R[j]),'cells_quarter_units':sq.tolist()})
 return {'case':k,'n':2,'a':2,'N':n,'status':'complete','cubes_quarter_units':cubes,'source_cells':z,'Qstar':Q,'V':[V.numerator,V.denominator],'V_over_Q_upper_certificate':str(V/F(Q['primal_upper'])),'gate_V_over_Q_gt_1':V>F(Q['primal_upper']),'source_row_masses':[[v.numerator,v.denominator] for v in rowmass],'source_row_h':[[v.numerator,v.denominator] for v in h],'essential_indices':eligible_seed.tolist(),'essential_scales':sorted(set(int(R[j]) for j in eligible_seed)),'seed_cells':seed_cells,'certified_bad_full_cells':records,'certified_bad_area':[len(records),16],'bad_construction_note':'Every listed full quarter-grid cell has h_i<=2 and T>10*rmaxess from a single legitimate seed cone, via a strict center margin and L1/2 Lipschitz radius; witness is lower-bound seed, not necessarily global winner.','elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');v=(ctypes.c_uint32*4)();c=ctypes.c_uint32(4);return list(v) if lib.host_statistics(lib.mach_host_self(),3,v,ctypes.byref(c))==0 else None

def exact_flow_subset(r):
 from collections import defaultdict,deque
 cubes=r['cubes_quarter_units'];src=[list(map(F,v)) for v in r['source_cells']];mass=[z[-1] for z in src];pairs=defaultdict(F)
 for z in r['certified_bad_full_cells']:
  a,b,c,d=map(F,z['cell']);pairs[(z['i'],z['j_lower_witness'])]+=(b-a)*(d-c)
 rows=[]
 def contained(index,cell):
  R,x,y=cubes[index];lo0=F(x-2*R,4);hi0=F(x+2*R,4);lo1=F(y-2*R,4);hi1=F(y+2*R,4)
  return lo0<=cell[0] and cell[1]<=hi0 and lo1<=cell[2] and cell[3]<=hi1
 for (i,j),w in sorted(pairs.items()):
  Ai=[contained(i,z) for z in src];Aj=[contained(j,z) for z in src];rows.append({'i':i,'j':j,'demand':w,'fresh':[s for s in range(len(src)) if Aj[s] and not Ai[s]],'local':[s for s in range(len(src)) if Ai[s]],'joint':[s for s in range(len(src)) if Ai[s] or Aj[s]]})
 result={}
 for kind in ('fresh','local','joint'):
  N=len(rows);best=F();bestset=[]
  for mask in range(1,1<<N):
   selected=[i for i in range(N) if mask&(1<<i)];neighbors=set(s for i in selected for s in rows[i][kind]);den=sum((mass[s] for s in neighbors),F());num=sum((rows[i]['demand'] for i in selected),F())
   if den==0:raise RuntimeError('unsupported demand')
   ratio=num/den
   if ratio>best:best=ratio;bestset=selected
  b=[]
  for s0 in range(len(src)):
   val=F()
   for row in rows:
    denom=sum((mass[s] for s in row[kind]),F())
    if s0 in row[kind]:val+=row['demand']/denom
   b.append(val)
  B=max(b);adj=[[] for _ in range(2+N+len(src))];source=0;sink=len(adj)-1
  def edge(u,v,cap):adj[u].append([v,len(adj[v]),cap]);adj[v].append([u,len(adj[u])-1,F()])
  for i,row in enumerate(rows):
   edge(source,1+i,row['demand'])
   for s0 in row[kind]:edge(1+i,1+N+s0,F(1000))
  for s0,m in enumerate(mass):edge(1+N+s0,sink,best*m)
  flow=F()
  while True:
   parent=[None]*len(adj);parent[source]=(-1,-1);q=deque([source])
   while q and parent[sink] is None:
    u=q.popleft()
    for e,(v,rev,cap) in enumerate(adj[u]):
     if cap>0 and parent[v] is None:parent[v]=(u,e);q.append(v)
   if parent[sink] is None:break
   d=F(1000);v=sink
   while v!=source:u,e=parent[v];d=min(d,adj[u][e][2]);v=u
   v=sink
   while v!=source:u,e=parent[v];item=adj[u][e];item[2]-=d;adj[v][item[1]][2]+=d;v=u
   flow+=d
  demand=sum((row['demand'] for row in rows),F());assert flow==demand
  flowrows=[]
  for i,row in enumerate(rows):
   for v,rev,cap in adj[1+i]:
    if 1+N<=v<1+N+len(src):
     got=adj[v][rev][2]
     if got:flowrows.append([i,v-(1+N),str(got)])
  result[kind]={'gamma':str(best),'uniform_Bmax':str(B),'cut_rows':bestset,'mass':[str(x) for x in mass],'rows':[{'demand_lower':str(row['demand']),'demand_upper':str(row['demand']),'cells':row[kind],'i':row['i'],'j':row['j']} for row in rows],'flow':flowrows,'proof_scope':'exact fixed-witness certified bad subset; gamma is maximum finite bipartite cut ratio and flow is exact'}
 return {'case':r['case'],'subset_area':str(sum(pairs.values(),F())),'source_mass_total':str(sum(mass,F())),'paired_rows':len(rows),'adjacency':result}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','batch','flow'),required=True);p.add_argument('--workers',type=int,default=12);p.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);cp=a.output_dir/'ccu_r625_compute';cp.mkdir(exist_ok=True);path=a.output_dir/'ccu_r625_numeric.json';md=a.output_dir/'ccu_r625_numeric.md'
 if a.phase=='flow':
  r=json.loads((cp/'case03.json').read_text());x=exact_flow_subset(r);(cp/'case03_flow.json').write_text(json.dumps(x,indent=2));print(json.dumps({k:{'gamma':v['gamma'],'Bmax':v['uniform_Bmax']} for k,v in x['adjacency'].items()}));return
 if a.phase=='pilot':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'results':[],'resource_samples':[]};cases=[0]
 else:out=json.loads(path.read_text());cases=list(range(1,12))
 out['commands'].append(shlex.join([sys.executable]+sys.argv));start=time.monotonic();prev=ticks();last=time.monotonic()
 def save():
  path.write_text(json.dumps(out));lines=['# R625 finite original-menu source/bad-domain candidates','','Each case uses all original receiver cubes and a single feasible source for their full star LP. Min-owner cells, largest-radius essential receiver row with deterministic index tie, and source averages are computed from the actual family. Listed bad cells are rigorously interior-certified by one seed cone and rational source averages; global winner identities and Gamma still require geometric audit.','','| case | N | V | Q* lower | Q* upper | V/Q upper-certificate | positive bad area lower | essential scales |','|---:|---:|---:|---:|---:|---:|---:|:---|']
  for r in sorted(out['results'],key=lambda z:z['case']):lines.append('| %d | %d | %s/%s | %s | %s | %s | %d/16 | %s |'%(r['case'],r['N'],*r['V'],r['Qstar']['dual_lower'],r['Qstar']['primal_upper'],r['V_over_Q_upper_certificate'],r['certified_bad_area'][0],str(r['essential_scales'])))
  lines+=['','Full source primal and dual, original cubes, min-owner cells, bad-cells and their witness margins are in JSON. Easy separated components may satisfy the gate without resolving source-reuse. No general-dimensional conclusion.'];md.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  futs={pool.submit(task,k):k for k in cases};pending=set(futs)
  while pending:
   done,pending=concurrent.futures.wait(pending,timeout=1,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    r=f.result();out['results'].append(r);(cp/('case%02d.json'%r['case'])).write_text(json.dumps(r));save();print('done',r['case'],'gate',r['gate_V_over_Q_gt_1'],'bad',len(r['certified_bad_full_cells']),flush=True)
   now=time.monotonic()
   if now-last>=1:
    t=ticks();dd=[(t[i]-prev[i])%(1<<32) for i in range(4)];out['resource_samples'].append({'phase':a.phase,'elapsed_seconds':now-start,'live_workers':sum(p.is_alive() for p in pool._processes.values()),'host_cpu_percent':100*(sum(dd)-dd[2])/sum(dd) if sum(dd) else None});prev=t;last=now
 out['last_wall_seconds']=time.monotonic()-start;out['max_worker_rss_bytes']=max(r['peak_rss_bytes_macos'] for r in out['results']);out['worker_cpu_sum_seconds']=sum(r['cpu_seconds'] for r in out['results']);save()
if __name__=='__main__':main()
