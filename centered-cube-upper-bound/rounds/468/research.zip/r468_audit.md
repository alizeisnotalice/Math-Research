# R468 FINAL PASS（限定已证结论）

独立 PRE 先于作者文件，后审最终十输入。PASS 限于保质量条件附源、完整跨度三来源核、真实/虚拟 selector 的积分区分和明确列明的 native 静态/own-low 构造及复现。**完整来源/终端外层的根阶价格、原阶段/history 实现及一般目标均未认证，母账不变。**

在同一实际记录上 \(B_A=\mu(Q_A\setminus(Q_u\cup Q_v))>d_*m_A\)、\(d_*=1-2/K^2>0\)，条件附源保持 \(P(1)\)，密度上放只收一次 \(d_*^{-1}\)。主账没有再叠加另一种先附源后删除的 \(2R/K^2\) 费用。实际三后验父权 \(q_A/m_A^3=q_A^{-2}R_A^{-3n}\)，外部双终端分母 \(m_um_v\)、\(S/(\zeta h^2d_*q^2)\) 及全部显示几何门正确；新源没有旧 history。

完整跨度中心体积 \(V(t)=\prod(t-d_i)_+\) 的分部积分保 \(b\) 端 base，给 \(b^{-2n}P_d(b)+3n\int t^{-2n-1}P_d(t)\)。用单调 \(P_d\) 得 \(P_d(b)[(3/2)t_0^{-2n}-(1/2)b^{-2n}]\)，指数界方向正确。排除中心在 required boxhull 内时必捕获，\(\chi\) 只作零支持；没有额外付款。strict mass 空域、\(L=b\) 非空 base 与跨度等于 \(b\) 的零体积情形已区分。

同一实际 selector/不依新 \(x\) 的接受标记下，\(\int fK_3=K_2\)、\(\omega=HK_3/K_2\le1\) 和 \(\int f\omega=H\) 正确；外部质量版仍保 \(d_*\)。纯包络逐 \(x\) 最大化不能交换积分。局部有限 uniform 源的 \(3L^{-n}-2U^{-n}\) 与 \(2L^{-n}-U^{-n}\) 差式，以及虚拟父能捕获实际 receiver 并集外来源的例子，均只辨别归一口径，不否定原目标。质量层饼上端 base 未丢；第三源轮廓 \(\mathcal H(t)\) 保完整 \(f\)，没有对虚拟父插入实际 q-band。

native 构造已逐式核查：两连续 shell 与父块互不冲突，所有实际 cubes 位于同一 \(f=1_{[-4,4]^n}\) 支撑中，精确 \(m=R^n,q=1\)。shell 捕获整个对应来源盒且排斥另一盒；累计导数给真实 \(G_n\)，无遗漏来源半宽。\(Z_u=G_n(se^{-1/\sqrt n})\)、unique cutoff、\(h+c_n\sqrt n\) 至 \(h+\sqrt n\) 的 own-low 质量带成立。显式 \(U_\pm\) 有正体积、处于最低 \(h\) 份 canonical 核、中心在每个实际父 cube 外；两端 crossavoid 与严格质量门成立。原父绝对 high-rank 及零 common 门在列明维度有证书。

范围保持保守：\(Z_A/J>0.9\) 只给对应相对阈值范围，未自动比较所有原 \(L_{\rm rank},\theta\) 或其他 hard 阈值；\(T_G,T_{\rm loc}\) 只是文中量化上界。没有 stage、clock、early、删除、proper/future 筛选及实际 \(P\) 正质量实现；极小正终端质量不是维度一致下界，也不是近极值性。

指定 Python 在隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r468_audit_pnnuxyb2`
重放两个 geometry 代码块、complement 代码块、numeric/native 脚本。stdout 全部与 replay 逐字一致；numeric JSON 仅 seconds 不同，native JSON 完全一致。geometry 54分为51有理项与3普通浮点诊断；complement34为体积多项式，numeric576含21点配置/5来源参数、Arb256指数界，native48为三个列明维度的 Fraction/Arb256证书。数值量不作为一般参数覆盖，普通浮点不认证质量临界门；后者由 native 区间证书单独支持。PRE临时核验不计归档统计。未改作者/仓库，未编译 PDF。

最终十输入 SHA256：

- `r468_main.md`: `ee0dbdd1e1f951250693afaa45d728cb04346370bc6fc6f30af32aba3ae575fa`
- `r468_geometry.md`: `f1d078a1a71a4b8d33c45d4b777ab48cd909478530b1eca79c0834d42e37832c`
- `r468_complement.md`: `c5580838aae782bd640fb2f13235134467f233c18e028456e68f0b2c1543752d`
- `r468_numeric.md`: `2270fe6fc27df23cf0af799151b09f5be1d94f3ff066b96f9408e6576ea0aca3`
- `r468_numeric.py`: `445ed49fc69705a68ef1b421fd9e528f23892264dfdb1884fce5af818ccf1b8c`
- `r468_numeric.json`: `6183f88f46c48bf4232fa39e74be346cf707240ac19173a47dcbc9e6910932d0`
- `r468_native.md`: `a987bfe33c196fa2e1c1aa9b8913bd68dbbdbf34c2a569a91c4c83582fa8f867`
- `r468_native.py`: `bb21f3d9dfe050006b7b1f9afc6dc75e60c4a9fd43232cb6b6355ea1af19222f`
- `r468_native.json`: `fa1bf25e51d5cab3e5c22c2c0952847184a9ecd86dd235fbc8598d1838b1ce03`
- `r468_replay.json`: `12623b100b50fcc11f49cd92851f24f4ec2a8916343f5600b81543d3bbad0417`
