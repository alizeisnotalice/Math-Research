from flint import arb,ctx
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform,importlib.metadata
ctx.prec=256
checks=0;rows=[]
def ck(x):
 global checks
 assert x
 checks+=1
def pos(x):ck(x.lower()>0)
for n in [1024,4096,16384]:
 delta=arb(1)/(100*n*n);a=arb(1)/2;b=arb(33)/50;eps=arb(1)/2;eta=arb(1)/100
 root=arb(n).sqrt();h=(1+root)/eps
 c=(1-2*delta)**(n-1)
 Glo=c*n*(b/a).log();Ghi=n*(b/a).log()
 pos(Glo-(4-eps)*h)
 pos(n*(1/b).log()-2*root)
 # G(b exp(-1/sqrt(n))) > h gives a unique s0 and c*=exp(1/sqrt(n))*s0 < b.
 pos(c*n*((b/a).log()-1/root)-h)
 s0lo=a*(h/n).exp();s0hi=a*(h/(c*n)).exp()
 cutlo=s0lo*(1/root).exp();cuthi=s0hi*(1/root).exp()
 pos(b-cuthi)
 betalow=h+c*root;betahi=h+root
 pos(betalow-h);pos((1+eps)*h-betahi)
 slo=a+1/(4*root);shi=a+1/(2*root)
 pos(a-shi*(-1/root).exp()) # whole explicit terminal slab has Z=0
 pos(h-n*(shi/a).log()) # slab lies inside lowest h mass tranche
 pos(arb(7)/10+slo-delta-(1+eta)) # terminal centers outside every actual parent
 pos(b-shi)
 mass=(2*eta)**(n-1)*(arb(2)**(-n))*(slo**(1-n)-shi**(1-n))/(n-1)
 pos(mass)
 pos(Glo/(Ghi+eta**n)-arb(9)/10)
 # Source box capture and disjointness are exact rational inequalities.
 de=F(1,100*n*n)
 ck(2*(F(33,50)-de)<F(7,5))
 ck(F(33,25)<F(7,5)-2*de)
 ck(F(7,10)+de+F(1,100)<1)
 ck(F(7,10)-F(1,100)>F(33,50)-de)
 rows.append(dict(n=n,delta=str(delta),h=str(h),G_lower=str(Glo),G_upper=str(Ghi),
  canonical_cut_lower=str(cutlo),canonical_cut_upper=str(cuthi),
  beta_low_lower=str(betalow),beta_low_upper=str(betahi),
  explicit_terminal_mass_log10=str(mass.log()/arb(10).log()),
  pair_TG_upper=str((arb(7)/10+n*delta).exp()),
  pair_Tloc_upper=str((arb(7)/10+n*delta).exp()*arb(2)**(-n))))
out=dict(scope='Corrected positive-measure native cube fixture: own-low canonical and original static high-rank/low-common gates; no original stage/history/P realization',
 python=platform.python_version(),executable=sys.executable,python_flint=importlib.metadata.version('python-flint'),precision_bits=ctx.prec,
 checks=checks,inputs=dict(n=[1024,4096,16384],delta='1/(100n^2)',a='1/2',b='33/50',eps0='1/2',eta='1/100'),rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',checks,'exact rational / Arb256 certified inequalities; 3 native fields, no history claim')
for x in rows:print('n',x['n'],'canonical mass bounds',x['beta_low_lower'],x['beta_low_upper'],'terminal log10 mass',x['explicit_terminal_mass_log10'])
