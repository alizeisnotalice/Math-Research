from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
import json,sys,platform,time
import sympy as s
ROOT=Path(__file__).resolve().parent
t=s.Symbol('t', positive=True); a=s.Symbol('a', real=True)
checks=0;start=time.perf_counter()
def ck(v):
 global checks
 assert v
 checks+=1
def Q(x): return s.Rational(x.numerator,x.denominator) if isinstance(x,F) else s.Rational(x)
def span(points,k):return max(x[k] for x in points)-min(x[k] for x in points)
def subsets(Z):
 for r in range(len(Z)+1):
  for T in combinations(Z,r):yield T
def ieV(Y,Z,L):
 return sum(((-1)**len(T)*prod(max(F(0),L-span(Y+list(T),k)) for k in range(len(Y[0]))) for T in subsets(Z)),F(0))
def prod(xs):
 v=F(1)
 for x in xs:v*=x
 return v
def rect_measure(lo,hi,Z,tau,normal=None):
 # Partition at every cube boundary; a tangential midpoint identifies coverage exactly.
 dims=len(lo)
 if any(x>=y for x,y in zip(lo,hi)):return F(0)
 endpoints=[sorted({lo[k],hi[k],*[b for z in Z for b in (z[k]-tau/2,z[k]+tau/2) if lo[k]<b<hi[k]]}) for k in range(dims)]
 ans=F(0)
 intervals=[list(zip(e,e[1:])) for e in endpoints]
 for cell in product(*intervals):
  mid=[(x+y)/2 for x,y in cell]
  covered=any(all(abs(mid[k]-z[k])<=tau/2 for k in range(dims)) for z in Z)
  if not covered:ans+=prod(y-x for x,y in cell)
 return ans
def gridV(Y,Z,L):
 n=len(Y[0]);lo=[max(y[k] for y in Y)-L/2 for k in range(n)];hi=[min(y[k] for y in Y)+L/2 for k in range(n)]
 return rect_measure(lo,hi,Z,L)
def ieS(Y,Z,tau):
 n=len(Y[0]);d=max(span(Y,k) for k in range(n))
 if tau<=d:return F(0)
 ans=F(0)
 for i in range(n):
  al=max(y[i] for y in Y);be=min(y[i] for y in Y)
  for sign in (-1,1):
   for T in subsets(Z):
    good=all((be<=z[i]<=be+tau) if sign==1 else (al-tau<=z[i]<=al) for z in T)
    if good:ans+=F((-1)**len(T),2)*prod(max(F(0),tau-span(Y+list(T),k)) for k in range(n) if k!=i)
 return ans
def gridS(Y,Z,tau):
 n=len(Y[0]);lo=[max(y[k] for y in Y)-tau/2 for k in range(n)];hi=[min(y[k] for y in Y)+tau/2 for k in range(n)]
 if any(x>=y for x,y in zip(lo,hi)):return F(0)
 ans=F(0)
 for i in range(n):
  for face in (lo[i],hi[i]):
   Zi=[tuple(z[k] for k in range(n) if k!=i) for z in Z if abs(face-z[i])<=tau/2]
   ans+=rect_measure([lo[k] for k in range(n) if k!=i],[hi[k] for k in range(n) if k!=i],Zi,tau)/2
 return ans
def breaks(Y,Z,L,U):
 n=len(Y[0]);bs={L,U}
 for T in subsets(Z):
  for k in range(n):bs.add(span(Y+list(T),k))
 for k in range(n):
  al=max(y[k] for y in Y);be=min(y[k] for y in Y)
  for z in Z:bs.update((z[k]-be,al-z[k]))
 return sorted(x for x in bs if L<=x<=U)
def exactint(poly,p,l,u):
 ans=0
 for (k,),coef in s.Poly(poly,t).terms():
  e=k-p
  ans+=coef*s.log(Q(u)/Q(l)) if e==-1 else coef*(Q(u)**(e+1)-Q(l)**(e+1))/(e+1)
 return s.expand_log(s.expand(ans),force=True)
def direct1(Y,Z,L,U,p):
 al=max(y[0] for y in Y);be=min(y[0] for y in Y)
 lo=al-U/2;hi=be+U/2
 if lo>=hi:return s.Integer(0)
 bs={lo,hi,al-L/2,be+L/2,(al+be)/2}
 for (z,) in Z:bs.update((z,z-L/2,z+L/2,(z+al)/2,(z+be)/2))
 bs=sorted(x for x in bs if lo<=x<=hi);ans=0
 for l,u in zip(bs,bs[1:]):
  mid=(l+u)/2;rr=max(L,2*(al-mid),2*(mid-be))
  if rr>U or any(rr>=2*abs(mid-z[0]) for z in Z):continue
  if rr==L:ans+=Q(u-l)*Q(L)**(-p)
  else:
   expr=2*(Q(al)-a) if 2*(al-mid)>L else 2*(a-Q(be))
   ans+=s.integrate(expr**(-p),(a,Q(l),Q(u)))
 return s.expand_log(s.simplify(ans),force=True)
def pts(rows):return [tuple(F(x) for x in row) for row in rows]
from flint import arb,ctx
ctx.prec=256

def envelope(Y,Z,L,U,p,independent=False,structured=False):
 n=len(Y[0]);Z=list(dict.fromkeys(Z));ds=[span(Y,k) for k in range(n)]
 if max(ds)>=U:return s.Rational(0),[]
 V=ieV(Y,Z,L)
 if independent:ck(V==gridV(Y,Z,L))
 if L==U:return Q(V)/Q(L)**p,[]
 bs=breaks(Y,Z,L,U);pieces=[]
 for lo,hi in zip(bs,bs[1:]):
  if structured:
   ck(not Z)
   VP=s.prod(t-Q(d) for d in ds)
   poly=s.diff(VP,t) if (lo+hi)/2>max(ds) else s.Integer(0)
  else:
   nodes=[lo+(hi-lo)*F(k+1,n+1) for k in range(n)]
   points=[]
   for tau in nodes:
    val=ieS(Y,Z,tau);ck(val>=0)
    if independent:ck(val==gridS(Y,Z,tau))
    points.append((Q(tau),Q(val)))
   poly=s.expand(s.interpolate(points,t));ck(poly==0 or s.degree(poly,t)<=n-1)
   tau=lo+(hi-lo)*F(1,2*n+3);ck(poly.subs(t,Q(tau))==Q(ieS(Y,Z,tau)))
   if independent:ck(ieS(Y,Z,tau)==gridS(Y,Z,tau))
  pieces.append((lo,hi,s.expand(poly)))
 E=Q(V)/Q(L)**p+sum((exactint(pol,p,l,u) for l,u,pol in pieces),s.Rational(0))
 return s.factor(E),pieces

def span_envelope(ds,L,U,p):
 n=len(ds);t0=max([L]+ds)
 if max(ds)>=U:return s.Rational(0)
 VP=s.prod(t-Q(d) for d in ds)
 return s.factor(Q(U)**(-p)*VP.subs(t,Q(U))+p*exactint(s.expand(VP),p+1,t0,U))
def toarb(x):
 x=s.Rational(x);return arb(int(x.p))/arb(int(x.q))
def row(name,n,y,z,x,ex,L=F(1,2),U=F(2),structured=False):
 Y=[tuple(map(F,y)),tuple(map(F,z)),tuple(map(F,x))];Z=[tuple(map(F,v)) for v in ex]
 E,pieces=envelope(Y,Z,L,U,3*n,n<=3,structured)
 ds=[span(Y,k) for k in range(n)];noexcluded=span_envelope(ds,L,U,3*n)
 ck(E>=0);ck(E<=noexcluded)
 if not Z:ck(E==noexcluded)
 hull=[v for v in Z if all(min(y[k] for y in Y)<=v[k]<=max(y[k] for y in Y) for k in range(n))]
 if hull:ck(E==0)
 if max(ds)>=U:ck(E==0)
 t0=max([L]+ds)
 if t0>U:upper=arb(0);bound_text='0: span>U'
 else:
  pref=s.Rational(3,2)*Q(t0)**(-2*n)-s.Rational(1,2)*Q(U)**(-2*n)
  exponent=sum(ds,F(0))/U
  upper=toarb(pref)*(-toarb(exponent)).exp();bound_text=str(upper)
  if exponent==0:ck(noexcluded<=pref)
  else:ck(upper-toarb(noexcluded)>0 or noexcluded==0)
 Epair,_=envelope(Y[:2],Z,L,U,3*n,False,structured)
 ck(E<=Epair)
 return dict(name=name,n=n,Y=Y,Z=Z,L=L,U=U,spans=ds,t0=t0,E3n=str(E),pair_E3n=str(Epair),third_source_ratio=str(s.factor(E/Epair)) if Epair else None,
 span_exact=str(noexcluded),excluded_ratio=str(s.factor(E/noexcluded)) if noexcluded else None,
 hull_excluded=hull,exp_upper_arb=bound_text,E3n_decimal=str(s.N(E,18)),
 method='structured polynomial, no excluded points' if structured else 'IE face interpolation plus independent rectangle partition for n<=3',
 pieces=[dict(lo=l,hi=u,S=str(pol)) for l,u,pol in pieces])

def vec(n,a):return [F(a)]*n
rows=[]
# Initial / span and endpoint pressure: 6 one-dimensional fixtures.
rows.append(row('1d_hull_x',1,[-F(1,4)],[F(1,4)],[0],[[1],[-1]]))
rows.append(row('1d_expanded_x',1,[-F(1,4)],[F(1,4)],[F(3,4)],[[F(5,4)],[-F(5,4)]]))
rows.append(row('1d_span_equals_U',1,[-F(1,4)],[F(1,4)],[F(7,4)],[[3]]))
rows.append(row('1d_span_above_U',1,[-F(1,4)],[F(1,4)],[2],[[3]]))
rows.append(row('1d_source_equals_excluded',1,[-F(1,4)],[F(1,4)],[F(3,4)],[[F(3,4)]]))
rows.append(row('1d_fixed_side',1,[-F(1,4)],[F(1,4)],[F(1,2)],[[F(3,2)]],F(1),F(1)))
# Two excluded points on the same coordinate hyperplane, and hull witness zero.
rows.append(row('2d_hull_x',2,[-F(1,4)]*2,[F(1,4)]*2,[0,0],[]))
rows.append(row('2d_coplanar_excluded',2,[-F(1,4)]*2,[F(1,4)]*2,[F(3,4),0],[[F(5,4),F(3,4)],[F(5,4),-F(3,4)]]))
rows.append(row('2d_excluded_in_coordhull',2,[-F(1,4)]*2,[F(1,4)]*2,[F(3,4),0],[[F(1,2),0]]))
rows.append(row('2d_fixed_side_coplanar',2,[-F(1,4)]*2,[F(1,4)]*2,[F(1,2),0],[[F(3,2),F(3,4)],[F(3,2),-F(3,4)]],F(1),F(1)))
rows.append(row('3d_balanced',3,[-F(1,4)]*3,[F(1,4)]*3,[0]*3,[[1,0,0],[-1,0,0]]))
rows.append(row('3d_expanded_x',3,[-F(1,4)]*3,[F(1,4)]*3,[F(3,4)]*3,[[F(5,4),0,0],[-F(5,4),0,0]]))
rows.append(row('3d_span_near_U',3,[0]*3,[F(1,4)]*3,[F(199,100),0,0],[[F(5,2),0,0],[F(5,2),1,0]]))
for n in (4,5,6):
 rows.append(row(str(n)+'d_span_only',n,vec(n,0),vec(n,F(1,4)),vec(n,F(3,4)),[]))
 ex1=[F(5,4)]+[F(0)]*(n-1);ex2=[F(5,4),F(1)]+[F(0)]*(n-2)
 rows.append(row(str(n)+'d_excluded_witness',n,vec(n,0),vec(n,F(1,4)),vec(n,F(3,4)),[ex1,ex2]))
rows.append(row('16d_zero_span',16,vec(16,0),vec(16,0),vec(16,0),[],F(1),F(2),True))
rows.append(row('64d_diagonal_span',64,vec(64,0),vec(64,0),vec(64,F(1,2)),[],F(1),F(2),True))
ck(len(rows)==21)
# Source integration vs pointwise selector supremum: symbolic inner coarea primitive.
N=s.Symbol('N',positive=True);rr=s.Symbol('rr',positive=True);tt=s.Symbol('tt',positive=True)
ck(s.simplify(s.diff(-s.Rational(1,2)*tt**(-2*N),tt)-N*tt**(-2*N-1))==0)
# Inner x integral at a fixed A: (3/2)r0^-2n -(1/2)U^-2n.
LL,UU=s.symbols('LL UU',positive=True)
E2=2*LL**(-N)-UU**(-N)
supint=s.Rational(3,2)*E2-s.Rational(1,2)*UU**(-2*N)*UU**N
ck(s.simplify(supint-(3*LL**(-N)-2*UU**(-N)))==0)
# Truly independent n=1 x integration of the no-exclusion span primitive.
z=s.Symbol('z',positive=True)
VV=t-z
lowE=s.factor(s.Rational(1,8)*(2-z)+3*exactint(VV,4,F(1),F(2)))
# For z>=L=1, lower endpoint equals z, use direct antiderivative.
highE=s.factor(s.Rational(1,8)*(2-z)+3*s.integrate((t-z)*t**(-4),(t,z,2)))
independent_x=s.integrate(2*lowE,(z,0,1))+s.integrate(2*highE,(z,1,2))
ck(independent_x==2);ck(s.Rational(2)/s.Rational(3,2)==s.Rational(4,3))
integration=[]
for n in (1,2,6,16,64):
 L=F(1);U=F(2);e2=2*L**(-n)-U**(-n);e3int=3*L**(-n)-2*U**(-n)
 ck(e3int>e2);ck(e3int/e2<F(3,2))
 integration.append(dict(n=n,L=L,U=U,integrated_pointwise_E3n=e3int,E2n=e2,ratio=e3int/e2,
 fixed_side_identity='L=U: both equal L^-n'))
out=dict(scope='21 finite E3n/span/excluded point configurations and uniform local-f source-integral diagnostics; no hard/history/source-price theorem',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,arb_precision_bits=ctx.prec,checks=checks,configurations=rows,
 source_integration=dict(general='int dx E3n({0,x},empty;L,U)=3 L^-n-2 U^-n > E2n({0})=2 L^-n-U^-n for L<U',
 inner_coarea='At fixed A with r0=max(L,2||A||inf), int dx r(A,x)^-3n=(3/2)r0^-2n-(1/2)U^-2n',
 bounded_uniform_f='Take f=1 on [-U,U]^n; all relevant parent cubes and x are inside this finite box. This is local uniform geometry, not original hard/history',
 actual_fixed_field='For the same fixed actual parent selector, int mu(dx)cA(x) qA/mA^3=qA/mA^2. Pointwise envelope may choose a different selector for each x',
 independent_1d_x_integral=str(independent_x),cases=integration),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r468_numeric.py',
 arithmetic='Fraction geometry, SymPy exact polynomial integration, Arb256 exponential upper bounds; decimals diagnostics only',seconds=time.perf_counter()-start))
(ROOT/'r468_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',s.__version__)
for r in rows:print(r['name'],'E3',r['E3n_decimal'],'thirdratio',r['third_source_ratio'],'excludedratio',r['excluded_ratio'])
print('independent n1 x integral',independent_x,'E2=3/2; ratio=4/3')
print('PASS',checks,'assertions;',len(rows),'point configurations; 5 source-integral parameter evaluations')
