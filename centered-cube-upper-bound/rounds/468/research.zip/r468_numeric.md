# R468：三来源span包络与sup/source积分的有限证书

21个预设点配置、5个source积分参数通过576项精确断言。span增长可强烈压低E_3n；但第三点留在原coordhull时完全不减，所测外部excluded witness的额外信用常接近1。更关键：积分逐x的sup包络并不恢复E_2n；恢复身份只属于同一固定实际父场。未得原全局source价格或history预算。

## 对象、方法与边界

核为q_A/m_A³≤q^-2 E_3n(Y={y,z,x},Z={u,v};L,U)。本轮只算右侧几何包络，没有把点配置伪造为原流。对d_i=coordspan(Y)、t0=max(L,maxd_i)，精确无排除span式为

Espan=U^-2n∏(1−d_i/U)_+ +3n∫_L^U t^-2n−1∏(1−d_i/t)_+dt。

核实际排除E≤Espan，且

Espan≤exp(−Σd_i/U)[(3/2)t0^-2n−(1/2)U^-2n]。

maxspan≥U时E=0；L=U但span<U时保留fixed-side base，不能判空。任何excluded点位于required coordhull时，任何捕获required的cube都捕获该点，所以E=0。

初步与压力覆盖1–3D的hull内第三点、扩span、跨度等于/超过U、source=excluded、两排除共面、excluded在coordhull、L=U。扩大为n=4,5,6各两例，以及n=16零span、n=64对角span的结构化无排除例，共21例。不作随机或维数扫描；大多数小配置取[L,U]=[1/2,2]，它们是一般outer-envelope测试，不冒称原octave场。

n≤6复用IE新增face分段算法，次数≤n−1，用有理节点插值、额外节点核验、精确积分；n≤3另用独立face tangential rectangle分割及完整base体积分割交叉核。高维两个无排除例只用结构化volume多项式导数，无指数枚举，不声称独立验证所有高维配置。指数粗界用Arb256bit严格比较；其余是Fraction/SymPy精确有理。

## 有判别力的数值

thirdratio比较同p=3n、同Z/L/U下新增x前后；excludedratio比较新增x后的E与无排除spanexact。decimal仅显示，JSON保有理式。

| 配置 | thirdratio | excludedratio |
|---|---:|---:|
| 1D第三点在原hull | 1 | 112/125 |
| 1D扩span | 47/256 | 47/54 |
| 2D第三点在原hull | 1 | 1 |
| 3D扩span | 500971/42470375 | 2504855/2873718 |
| 4D扩span+外witness | 约7.02e−4 | 约0.910 |
| 6D扩span+外witness | 约1.46e−5 | 约0.929 |
| 16D零span | 1 | 1 |
| 64D对角span | 约1.05e−19 | 1 |

上述6D无排除thirdratio约1.57e−5；外witness只给额外约.929因子。hull witness使E精确为0；固定side1的一维、二维例分别E_3=1/4、E_6=1/8，确认base未被遗漏。span贴U时下降很强，但没有证明实际原source权会迫使这种span分布，不能由有限衰减推出可积根价。

## 固定父身份与sup积分损失

固定同一实际selector时，∫μ(dx)c_A(x)q_A/m_A³=q_A/m_A²是精确Fubini。逐x取sup则selector可能随x变化，不能交换。

取无排除、旧来源0，均匀f局部有限化为1_{[-U,U]^n}。所有有关父cube和x都在此有限支撑内。在固定A处r0=max(L,2||A||∞)，对x的距离coarea给

∫dx r(A,x)^-3n=(3/2)r0^-2n−(1/2)U^-2n。

再对A∈[-U/2,U/2]^n积分，利用E_2n({0})=2L^-n−U^-n，得到

∫dx E_3n({0,x},∅;L,U)=3L^-n−2U^-n。

SymPy核内层原函数及一般化简。另n=1直接对x的两个span区间积分，独立得L=1,U=2时2，而E_2=3/2，比为4/3。n=1,2,6,16,64的有理参数值亦核验；U/L=2、n增大时比值趋3/2。L=U时两式均L^-n，才有fixed-side恢复。此局部uniform来源仅辨别sup积分口径，不认证原hard/high-rank/history。

## 执行与冻结

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r468_numeric.py
```

Python3.12.14、SymPy1.14.0、Arb256bit；wall约.32秒。576为代数/几何/界限断言总数，非独立配置数。数学判定无浮点误差；decimal与计时仅元数据。脚本自含，输出到自身目录，未重跑R461旧实验或依赖旧输出。

冻结白名单：r468_numeric.py、r468_numeric.json、r468_numeric.md。完成停止。原三来源整体source结算、span分布及可支付几何机制仍未由本证书证明。
