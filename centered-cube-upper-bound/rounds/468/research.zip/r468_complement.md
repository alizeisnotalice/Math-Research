# R468：三来源父中心包络与真实背景跨度

本稿证明一个带全坐标跨度的父核上界，并将第三来源保留为真实质量积分；未得到原完整余项的根阶来源预算。cube 参数均为边长。沿用 \(q\le q_A\le\lambda\)、\(m_A=q_AR_A^n\)、\(a\le R_A\le b\le2a\)，真实父中心测度为 \(dA\)。

## 1. 质量分母及精确适用范围

固定来源 \(Y=\{y,z,x\}\) 和终端中心 \(Z=\{u,v\}\)，令
\[
 H=K^2\max(m_u,m_v),\qquad
 L=\max\{a,(H/\lambda)^{1/n}\}.
\]
若 \(H\ge\lambda b^n\)，实际严格质量门为空。否则，对于同一实际选择器及任意正限制，
\[
 \int_{\substack{Y\subset Q_A,\ u,v\notin Q_A\\m_A>H}}
       \frac{q_A}{m_A^3}\,dA
 \le q^{-2}E_{3n}(Y,Z;L,b).                         \tag{1}
\]
因为 \(q_A/m_A^3=q_A^{-2}R_A^{-3n}\)，且实际边长大于质量阈值。下端点纳入只为正上放，不断言实际选择器端点零测。

若第三来源是从 \(Q_A\setminus(Q_u\cup Q_v)\) 的原 \(f\) 条件抽样，记其质量 \(B_A\)。严格终端质量给
\[
 B_A\ge m_A-m_u-m_v>(1-2/K^2)m_A=:d_*m_A.
\]
仅在 \(d_*>0\) 时，可将真实密度 \(q_A/(m_A^2B_A)\) 上放为
\(d_*^{-1}q_A/m_A^3\)。这个额外 \(d_*^{-1}\) 必须计入；不能把 \(B_A\) 无代价换成 \(m_A\)。原历史和接受权保留在实际上，(1) 是几何外包络。

## 2. 全跨度及两个排除中心

设
\[
 d_i=\max_{w\in Y}w_i-\min_{w\in Y}w_i,\quad
 d_\infty=\max_i d_i,\quad d_1=\sum_i d_i,\quad
 P(t)=\prod_i(1-d_i/t)_+.
\]
定义
\[
 \chi(Y;u,v)=1_{\{u,v\notin \operatorname{boxhull}(Y)\}}.
\]
若 \(\chi=0\)，任何轴平行 cube 捕获全部 \(Y\) 必捕获至少一个被排除中心，所以 \(E_{3n}=0\)。这只是原父外事件的自动支持条件，不是新支付分支。

若 \(d_\infty>b\)，包络亦为零。其余令 \(t_0=\max(L,d_\infty)\)。丢掉排除条件后的最大包络恰为
\[
 F(Y;L,b)=b^{-2n}P(b)
       +3n\int_{t_0}^b t^{-2n-1}P(t)\,dt.           \tag{2}
\]
因此
\[
\boxed{
 E_{3n}(Y,Z;L,b)
 \le\chi F
 \le\chi P(b)\left(\frac32t_0^{-2n}
                         -\frac12b^{-2n}\right)
 \le\chi e^{-d_1/b}\left(\frac32t_0^{-2n}
                         -\frac12b^{-2n}\right).
}                                                       \tag{3}
\]
当 \(L=b\)，(2) 保留固定边长的 \(b^{-2n}P(b)\)；当
\(d_\infty=b\)，右侧为零，退化中心集合只有 Lebesgue 零测。
\(L=b,d_\infty<b\) 不得置零。

证明：要求捕获 \(Y\) 的父中心盒体积为
\(V(t)=\prod_i(t-d_i)_+=t^nP(t)\)。最小可行边长产生
\(L^{-3n}V(L)+\int_L^b t^{-3n}\,dV(t)\)；分部积分得到 (2)，无边界原子遗漏。\(P(t)\) 随 \(t\) 非减，故换成 \(P(b)\) 后积分为 (3) 的括号。最后逐坐标 \(1-r\le e^{-r}\)。排除门只用于支持 \(\chi\)；若还需精细排除，可取 (3) 与 R461 的真实面入流公式之最小值，不把排除后的体积导数误当入流。

## 3. 第三来源先积分：可计算的真实质量轮廓

固定 \(y,z,u,v\)，令
\[
 \mathcal H(t)=\int_{\mathbb R^n\setminus(Q_u\cup Q_v)}
 f(x)\,\chi(\{y,z,x\};u,v)\,
 \prod_i\left(1-\frac{\operatorname{span}(y_i,z_i,x_i)}t\right)_+dx.
\]
Tonelli 与 (2) 给
\[
 \int_{(Q_u\cup Q_v)^c}f(x)E_{3n}(\{y,z,x\},Z;L,b)\,dx
 \le b^{-2n}\mathcal H(b)
       +3n\int_L^b t^{-2n-1}\mathcal H(t)\,dt.       \tag{4}
\]
特别该量不超过
\[
 \left(\frac32L^{-2n}-\frac12b^{-2n}\right)\mathcal H(b). \tag{5}
\]
这里每一份来源质量均按其实际三点跨度计权；没有来源坐标独立、密度帽或体积到 \(f\)-质量的推断。\(\mathcal H(t)\le W\)，但取此粗界会丢掉本稿几何信息。

这项轮廓可以完全通过真实交叠表达。若暂不加 \(\chi\)，则
\[
 \int_{(Q_u\cup Q_v)^c}f(x)P_{y,z,x}(t)\,dx
 =t^{-n}\int_{B_{\{y,z\}}(t)}
 f\!\left(Q_t(A)\setminus(Q_u\cup Q_v)\right)dA.     \tag{6}
\]
(6) 是 Fubini 等式，右侧中心与边长 \(t\) 通常不是原实际选择器；因此不能在该右侧插入 \(f(Q_t(A))\le\lambda t^n\)。这正是当前未能把 (4) 结算成一次共享 \(W\) 费用的步骤。

对原 R462 正上放双端流附第三来源，完整可用价格是 (4) 乘
\(S/(\zeta h^2d_*q^2)\)，再积分原
\[
 \frac{f(y)f(z)c_u(y)c_v(z)\chi_u(y)\chi_v(z)}
 {m_um_v}\,1_{\{c_u(z)=c_v(y)=0\}}\,dy\,dz\,du\,dv.
\]
它仍保真实终端质量分母和 own-low；该外层积分没有在本稿中获得根阶估计。固定跨度的指数衰减不是总体付款，也不使原接受权可刷新。结论是一个更强且可计算的三来源几何核；尚缺上述外层来源/终端重复的联合结算。

## 4. 实际本机精确核验

以下 Fraction 脚本已实际执行：三阶段分别 9、10、15 项，共 34 项精确断言通过。它在三阶段检验真实 required-center 盒的体积多项式、两种积分公式一致、(3) 的有理乘积界、固定边长与零体积端点。所有输入跨度可由三点 \(0,d,d/2\) 实现。它不是原匹配场或完整历史的模拟，也不依赖浮点积分证明公式。

~~~python
from fractions import Fraction as F
checks=0
def mul(poly, d):
    out=[F(0)]*(len(poly)+1)
    for j,c in enumerate(poly):
        out[j]-=d*c
        out[j+1]+=c
    return out
def val(poly,x):
    return sum(c*x**j for j,c in enumerate(poly))
def integ(poly,p,lo,hi,derivative=False):
    ans=F(0)
    for j,c in enumerate(poly):
        if derivative:
            if j==0: continue
            exponent=j-1-p
            coefficient=j*c
        else:
            exponent=j-p-1
            coefficient=c
        assert exponent != -1
        ans+=coefficient*(hi**(exponent+1)-lo**(exponent+1))/F(exponent+1)
    return ans
stages=[
 [(1,[F(0)],F(1),F(2)),(1,[F(1,2)],F(1),F(2)),
  (2,[F(1,4),F(3,4)],F(1),F(2))],
 [(1,[F(0)],F(1),F(1)),(2,[F(1,2),F(1,4)],F(1),F(1)),
  (2,[F(2),F(1,2)],F(1),F(2)),(2,[F(3),F(0)],F(1),F(2))],
 [(n,[F((i%4),4) for i in range(n)],F(1),F(2))
  for n in [2,3,4,8,16]]
]
for phase, cases in enumerate(stages,1):
    count=0
    for n,ds,L,b in cases:
        p=3*n
        if max(ds)>b:
            assert all(max(ds)>t for t in [L,b])
            checks+=1;count+=1;continue
        t0=max(L,max(ds))
        poly=[F(1)]
        for d in ds:poly=mul(poly,d)
        base=val(poly,L) if max(ds)<=L else F(0)
        direct=L**(-p)*base+integ(poly,p,t0,b,True)
        byparts=b**(-p)*val(poly,b)+p*integ(poly,p,t0,b)
        Pb=val(poly,b)/b**n
        bound=Pb*(F(3,2)*t0**(-2*n)-F(1,2)*b**(-2*n))
        assert direct==byparts
        assert F(0)<=direct<=bound
        assert bound<=F(3,2)*L**(-2*n)-F(1,2)*b**(-2*n)
        checks+=3;count+=3
    print("phase",phase,"PASS",count)
print("total PASS",checks,"exact geometric polynomial assertions; no native-history claim")
~~~
