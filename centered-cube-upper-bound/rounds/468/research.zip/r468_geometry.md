# R468：三来源父核的真实归一权与有符号中心包络

**范围。** 检查一个机制：保第三来源及父外面的有符号中心体积，寻求来源可积的父尾衰减。得到真实核的准确归一权，并定位其不能直接替换为纯几何包络的步骤；未证明新的根阶总预算。原接受权留在 \(P\)，所有 active/own-low 掩码仍按 R462。新增 \(x\) 没有旧历史。

## 1. 候选核及真实质量层

固定原 \(y,z,u,v\)，置 \(H=K^2\max(m_u,m_v)\)。以下所有父满足实际 \(A\in E\)、\(m_A>H\)、\(u,v\notin Q_A\)。写
\[
 K_2=\int\frac{q_Ac_A(y)c_A(z)}{m_A^2}\,dA,
 \qquad K_3(x)=\int\frac{q_Ac_A(y)c_A(z)c_A(x)}{m_A^3}\,dA.
\tag{1}
\]
源与终端的其他门保留在外部积分。若在 (1) 中保留额外接受标记，该标记必须不依赖人工第三来源 \(x\)。

令 \(V_t(x)=\int_{H<m_A\le t}q_Ac_A(y)c_A(z)c_A(x)1_{u,v\notin Q_A}\,dA\)。非负层饼严格给
\[
 K_3(x)=3\int_H^\infty V_t(x)t^{-4}\,dt.
\tag{2}
\]
选 \(T\ge\lambda b^n\) 时右侧等于
\(V_T(x)T^{-3}+3\int_H^T V_t(x)t^{-4}dt\)；不能丢掉上端基项。严格下界 \(m_A>H\) 排除等号原子。

记三点每坐标跨度为 \(d_j\)。正放掉父外限制、再用真实匹配 \(R_A^n\le t/q\)，可证
\[
 K_3(x)\le3\lambda\int_H^\infty t^{-4}
 \prod_j((t/q)^{1/n}-d_j)_+dt
 \le\frac{3\lambda}{2qH^2}.
\tag{3}
\]
但 (3) 的额外质量分母不能单独当成全来源节省。

## 2. 自然归一权：确实可积，但尚无跨父列价

在 \(K_2>0\) 上，定义
\[
 \omega(x)=H K_3(x)/K_2.
\]
由 \(m_A>H\)，\(0\le\omega\le1\)。真实完整匹配给
\[
 \boxed{\int f(x)\omega(x)dx=H.}
\tag{4}
\]
证明是 \(\int f c_A=m_A\)，故 \(\int fK_3=K_2\)。更具体地，\(f(x)\omega(x)dx/H\) 是以 \(q_Ac_A(y)c_A(z)/m_A^2\) 为父权的真实 \(\pi_A\) 混合，并非任意空间密度。

令 \(O_{uv}=(Q_u\cup Q_v)^c\)。因为
\(f(Q_A\cap(Q_u\cup Q_v))\le m_u+m_v<2m_A/K^2\)，
\[
 H(1-2/K^2)\le\int_{O_{uv}}f\omega\le H.
\tag{5}
\]
因此所要求的点态比较可以精确写成
\(K_3(x)=K_2\omega(x)/H\)，且其来源归一完全合法。但不同 \((y,z,u,v)\) 的混合父分布不同，(4) 不给这些权对同一来源的累计列帽。先用 (4) 积分恰恢复 \(K_2\)，没有根阶费用。

对实际 \(P\) 附 \(x\sim\pi_A\) 后限制 \(O_{uv}\)，删除量至多
\(2R/K^2\le2SA_nW/K^2\)。对 R462 上包络作同样限制，则其改变至多
\(2S(1+\varepsilon_0)^2A_nW/(\zeta K^2)\)。两者是各自不同测度上的比较，不能相加收费；这里不更新母账，也不把附源操作计为新付款。

## 3. 有符号面见证为何没有自动给来源归一

固定**同一边长** \(R\)，令 \(V_R(F)=\prod_j(R-\operatorname{span}_jF)_+\)。捕获 \(y,z,x\) 且不捕获中心 \(u,v\) 的中心体积精确为
\[
 V_R(y,z,x)-V_R(y,z,x,u)-V_R(y,z,x,v)+V_R(y,z,x,u,v).
\tag{6}
\]
这保留两面排斥的负交叠。变边长 actual selector 不能直接把 (6) 放到最大允许边长：扩大立方体可能新捕获 \(u,v\)。所以 (2) 的实际父集仍须保留，或另用合法的变尺度包络。

即使固定边长，纯几何包络相对 \(K_2\) 的比值也不自动满足 (4)。一个有限原生范围检查：\(n=9,16,25\)，actual 父中心为0附近半边长 \(10^{-3}\) 的盒、边长2；双 child 中心在 \(\pm1.1e_1\) 附近、边长1。来源小盒在 \(\pm.8e_1,0\)，质量 \(1,1,2^n-2\)，所有这些接收者完整匹配 \(q_A=1\)。点 \(x_0=1.04e_2\) 附近的小包不被任何 actual receiver 捕获，故添加任意该包质量不改变匹配。

然而虚拟父中心 \(.05e_2\)、边长2捕获 \(\pm.8e_1,x_0\)，仍排除双 child 中心；\(x_0\) 也在双 child cube 外。(6) 在这些点的值为 \((24/125)2^{n-2}>0\)，且正性在小邻域保持。因此若丢 actual 父集，给 (6) 包络的 \(x\)-权乘上完整 \(f\) 后，不能仅凭原父质量 \(H\) 归一。这不是原目标反例：该小中心场 active/high-rank 资格失败，实际 masked canonical 流为零。

**唯一未付步骤。** 必须保实际父集/接受权，利用 (6) 的空间节省控制 (4) 中混合权跨全部双终端、双来源的累计来源列。纯几何面见证只给支撑限制；它不能给任意集中 \(f\) 的跨度分布。保真实匹配则有 (4)，但将它逐对使用恢复二源未知积分。本次尝试没有证明二者之间额外的联合节省，故不声称三来源尾解决了全局预算。

## 4. 本机证据

实际运行两段小核验：第一段27项 Fraction质量层饼/上端基项恒等式、6项真实小包源积分恒等式，另3项普通浮点严格质量差诊断；第二段18项 Fraction有符号固定边长中心体积/外包位置检查。全部通过。后者源码如下；无原active历史认证。

```python
from fractions import Fraction as F
checks=0
for n in (9,16,25):
 def pt(a=0,b=0):return [F(a),F(b)]+[F(0)]*(n-2)
 y=pt(F(-4,5));z=pt(F(4,5));x=pt(0,F(26,25));u=pt(F(-11,10));v=pt(F(11,10));V=pt(0,F(1,20))
 def capture(c,R,p):return all(abs(a-b)<=R/2 for a,b in zip(c,p))
 def vol(points):
  out=F(1)
  for j in range(n):out*=max(F(0),2-max(p[j] for p in points)+min(p[j] for p in points))
  return out
 ie=vol([y,z,x])-vol([y,z,x,u])-vol([y,z,x,v])+vol([y,z,x,u,v])
 assert ie==F(24,125)*2**(n-2);checks+=1
 assert all(capture(V,F(2),p) for p in (y,z,x));checks+=1
 assert not any(capture(V,F(2),p) for p in (u,v));checks+=1
 assert not any(capture(c,F(1),x) for c in (u,v));checks+=1
 assert x[1]-F(1,1000)>1+F(1,1000);checks+=1
 assert all(abs(p[0])<1-F(1,1000) for p in (y,z));checks+=1
print('PASS',checks,'Fraction fixed-side signed-center and external-packet checks; original active/history not certified.')
```

第一段的可复现代码：

```python
from fractions import Fraction as F
from math import exp,sqrt
checks=0
atoms=[(F(4),F(2)),(F(8),F(3)),(F(16),F(5))]
for H in (F(0),F(4),F(8)):
 for T in (F(16),F(20),F(32)):
  chosen=[(m,v) for m,v in atoms if m>H]
  lo=min(m for m,v in chosen);knots=sorted(set([lo,T]+[m for m,v in chosen]))
  for power in (2,3):
   total=sum(v/m**power for m,v in chosen)
   integral=sum(v for m,v in chosen)/T**power
   for a,b in zip(knots,knots[1:]):
    mass=sum(v for m,v in chosen if m<=a)
    integral+=mass*(a**(-power)-b**(-power))
   assert total==integral;checks+=1
  assert sum(v*m/m**3 for m,v in chosen)==sum(v/m**2 for m,v in chosen);checks+=1
for n in (9,16,25):
 m=F(2)**n;vol=F(1,500)**n
 k2=vol/m**2;k3=vol/m**3
 assert k3*(m-2)==k2*(1-2/m);checks+=1
 assert (k2-k3*(m-2))/k2==2/m;checks+=1
 assert float(m)>exp(2*sqrt(n));checks+=1
print('PASS',checks,'checks: 27 exact mass-layer identities, 6 exact native packet identities, 3 floating strict-gap diagnostics; native active mask fails.')
```
