"""True greedy prices and first-hit integral for two nearly touching parents."""
import json
from math import isqrt,comb
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=256
def run(n,eta):
    a=32*n
    root=isqrt(n)
    K=4096*root*a**n
    ell=arb(2).log()/K
    delta=-(-ell).expm1()
    vt=arb(1)/a**n
    rh=vt*ell.expm1()/2
    u=F(1,2)*(1+F(1,a))
    x=F(49,100)
    core=F(1,2*a)
    assert x-core+1-eta>1+F(6,n)
    assert x+core-u<=eta and -x-core-u>=-2+eta
    raw=arb(2*eta.numerator)/eta.denominator
    raw=raw**n
    kt=arb(4)**n/comb(2*n,n)
    assert 0<rh and rh<vt/4 and rh<arb(2)**n/kt
    assert kt<=2*arb(n).sqrt()
    first_log=n*arb(32*n).log()+(K-4)*n*arb(4).log()+delta.log()
    assert first_log>(3*arb(2)**n+1).log()
    return dict(n=n,eta=str(eta),R_high=str(rh),V_T=str(vt),
                log_ratio_to_sqrt_n_raw_lens=str((rh/(root*raw)).log()),
                raw_threshold_pays=bool(root*raw>=rh),
                new_symmetric_predicted_capacity=str(arb(2)**n/kt),
                logD_over_K_lower=str(first_log/K),
                logD_over_K_upper=str((first_log+arb(3).log())/K),
                excess_eta_one_quarter=0)
print(json.dumps([run(n,eta) for n in [64,256,1024]
                  for eta in [F(1,8),F(1,(32*n)**2),F(1,(32*n)**4)]],indent=2))
