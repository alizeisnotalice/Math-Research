#!/usr/bin/env python3
"""Exact shifted-cube intersection and unshifted-packing audit."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,math,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
DIMS=(4,16,64,256,1024)

def overlap(a,b,z):return max(F(0),min(b,z+1)-max(a,z))
def segmented(a,b,delta,law):
    if delta==0:return overlap(a,b,F(0))
    if law=='sign':return (overlap(a,b,-delta)+overlap(a,b,delta))/2
    knots=sorted({-delta,delta}|{v for v in (a-1,a,b-1,b) if -delta<v<delta})
    return sum(((v-u)*(overlap(a,b,u)+overlap(a,b,v))/2 for u,v in zip(knots,knots[1:])),F(0))/(2*delta)
def hinge(a,b,delta,law):
    def positive(x):return max(F(0),x)
    def e(c):
        if delta==0:return positive(c)
        if law=='sign':return (positive(c-delta)+positive(c+delta))/2
        return (positive(c+delta)**2-positive(c-delta)**2)/(4*delta)
    return e(1-a)-e(-a)-e(1-b)+e(-b)
def prod(seq):
    ans=F(1)
    for v in seq:ans*=v
    return ans

def geometry_rows(method):
    rows=[]
    for n in DIMS:
        root=math.isqrt(n);assert root*root==n
        eps=F(1,128*n);L=1+eps;thin=F(1,64*n)
        cases={'thin_all':[(thin-L,thin)]*n,
               'flush_full':[(F(0),L)]*n,
               'deep_contained':[(F(-1),F(2))]*n,
               'mixed_half_thin':[(thin-L,thin)]*(n//2)+[(F(0),L)]*(n//2),
               'mixed_one_thin':[(thin-L,thin)]+[(F(0),L)]*(n-1),
               'tangent':[( -L,F(0))]*n}
        for dname,delta in [('zero',F(0)),('inverse_n',F(1,n)),('inverse_sqrt_n',F(1,root))]:
            for name,intervals in cases.items():
                side=intervals[0][1]-intervals[0][0]
                assert all(b-a==side and side>=1 for a,b in intervals)
                widths=[overlap(a,b,F(0)) for a,b in intervals];original=prod(widths)
                for law in ('sign','uniform'):
                    coordinate=[method(a,b,delta,law) for a,b in intervals];C=prod(coordinate)
                    assert all(0<=v<=1 for v in coordinate)
                    if delta==0:assert C==original
                    rows.append({'dimension':n,'case':name,'delta_kind':dname,'delta_exact':str(delta),'law':law,
                                 'small_source_side_exact':'1','large_source_side_exact':str(side),
                                 'physical_nonnegative_translation_exact':str(side+1),
                                 'physical_small_interval_all_axes':[str(side+1),str(side+2)],
                                 'physical_large_interval_runs':[{'axes':intervals.count(item),'a':str(item[0]+side+1),'b':str(item[1]+side+1)} for item in dict.fromkeys(intervals)],
                                 'interval_runs':[{ 'axes':n,'a':str(intervals[0][0]),'b':str(intervals[0][1])}]
                                  if len(set(intervals))==1 else [
                                      {'axes':intervals.count(item),'a':str(item[0]),'b':str(item[1])} for item in dict.fromkeys(intervals)],
                                 'initial_intersection_exact':str(original),'expected_intersection_exact':str(C),
                                 'C_over_initial_exact':str(C/original) if original else None,
                                 'comparison':('greater' if C>original else 'less' if C<original else 'equal'),
                                 'coordinate_mean_runs':[{'axes':coordinate.count(q),'value':str(q)} for q in dict.fromkeys(coordinate)]})
    return rows

def packing_fixture(n,method):
    sides=[F(4),F(2),F(1),F(1)]
    centers=[[F(3)]*n for _ in sides];centers[2][0]=F(5);centers[3][0]=F(11,2)
    theta=[F(1,2)]*4
    bounds=[[(x-s/2,x+s/2) for x in c] for c,s in zip(centers,sides)]
    # Exact compressed arrangement of half-open cubes: mask -> true cell volume.
    states={(1<<4)-1:F(1)}
    for axis in range(n):
        edges=sorted({v for row in bounds for v in row[axis]});nxt={}
        for a,b in zip(edges,edges[1:]):
            mid=(a+b)/2;mask=sum(1<<i for i in range(4) if bounds[i][axis][0]<mid<bounds[i][axis][1])
            for old,vol in states.items():
                key=old&mask;nxt[key]=nxt.get(key,F(0))+vol*(b-a)
        states=nxt
    maxload=max(sum((theta[i] for i in range(4) if mask>>i&1),F(0)) for mask in states)
    D=sum((theta[i]*sides[i]**n for i in range(4)),F(0))
    integrated=sum((vol*sum((theta[i] for i in range(4) if mask>>i&1),F(0)) for mask,vol in states.items()),F(0))
    assert integrated==D and maxload<=1
    rows=[]
    for dname,delta in [('zero',F(0)),('inverse_n',F(1,n)),('inverse_sqrt_n',F(1,math.isqrt(n)))]:
        for law in ('sign','uniform'):
            total=F(0);initially_positive=F(0);pairs=[];column=[]
            for h in range(4):
                source_sum=F(0)
                for i in range(h): # sides are ordered, tie labels fixed
                    sh=sides[h];ch=centers[h]
                    normalized=[((bounds[i][a][0]-(ch[a]-sh/2))/sh,
                                 (bounds[i][a][1]-(ch[a]-sh/2))/sh) for a in range(n)]
                    C=sh**n*prod(method(a,b,delta,law) for a,b in normalized)
                    old=sh**n*prod(overlap(a,b,F(0)) for a,b in normalized)
                    source_sum+=theta[i]*C;total+=theta[i]*theta[h]*C
                    if old>0:initially_positive+=theta[i]*theta[h]*C
                    pairs.append({'large_i':i,'small_h':h,'initial_intersection_exact':str(old),'expected_intersection_exact':str(C)})
                assert source_sum<=sides[h]**n
                column.append(str(source_sum))
            assert initially_positive<=total<=D
            rows.append({'delta_kind':dname,'delta_exact':str(delta),'law':law,'all_oriented_pair_payment_exact':str(total),
                         'initially_positive_pairs_payment_exact':str(initially_positive),'payment_over_D_exact':str(total/D),
                         'unweighted_by_theta_h_column_sums':column,'pairs':pairs})
    return {'dimension':n,'source_sides':[str(s) for s in sides],
            'source_centers':[[str(x) for x in c] for c in centers],'theta':[str(q) for q in theta],
            'max_pointwise_load_exact':str(maxload),'D_exact':str(D),
            'arrangement_nonzero_masks':sum(mask>0 for mask in states),'rows':rows}

def exact_data(method):
    geometry=geometry_rows(method);packing=[packing_fixture(n,method) for n in (4,16,64)]
    negative=[]
    for law in ('sign','uniform'):
        q=method(F(0),F(1),F(1,4),law)**4
        total=28*q;assert total>8
        negative.append({'dimension':4,'sources':8,'all_source_cubes_identical':True,'theta_each':'1',
                         'pointwise_packing_load':'8','delta_exact':'1/4','law':law,
                         'pair_payment_exact':str(total),'D_exact':'8','violates_payment_le_D':True})
    return {'geometry':geometry,'packing':packing,'negative_controls':negative}

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
if '--remote' in sys.argv:
    d=exact_data(hinge)
    print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                      'method':'independent positive-part primitive, no segmented-overlap quadrature',
                      'exact_data_sha256':hashlib.sha256(canonical(d)).hexdigest(),
                      'geometry_count':len(d['geometry']),'packing_count':len(d['packing'])}));sys.exit(0)

def main():
    data=exact_data(segmented)
    # Local independent primitive is cheap; remote repeats it without remote files.
    independent=exact_data(hinge);assert data==independent
    exactsha=hashlib.sha256(canonical(data)).hexdigest()
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            remote['result']=json.loads(run.stdout);assert remote['result']['exact_data_sha256']==exactsha
            remote['all_exact_data_match']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    for row in data['geometry']:
        q=F(row['C_over_initial_exact']) if row['C_over_initial_exact'] else None
        row['log_C_over_initial_approx']=math.log(q.numerator)-math.log(q.denominator) if q else None
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'canonical_exact_data_sha256_before_approximate_logs':exactsha,**data,'remote':remote,
            'packing_identity':['Assume the original, unshifted large-source family has f(x)=sum_i theta_i 1_Ai(x)<=1 almost everywhere and theta_i>=0. For every fixed smallh and every translationZh, sum_{i<h} theta_i |Ai intersection(Ah+Zh)|<=|Ah|. Expectation is allowed separately for eachh, with arbitrary h-dependent shift laws.',
                                'Thus sum_h theta_h sum_{i<h} theta_i E|Ai intersection(Ah+Zh)|<=sum_h theta_h|Ah|=D. Restricting to initially intersecting pairs only decreases the nonnegative sum.',
                                'No claim is made that the translated family itself satisfies packing. The payment follows from the unshifted family inside each small-source column.'],
            'scope':['Physical axis-aligned cubes with nonnegative overlap lengths. Small source normalized to[0,1]^n; all larger test cubes have strictly larger side. Nonnegative physical intervals are explicitly retained by a common translation, alongside normalized intervals.',
                     'Independent coordinate shifts are either symmetric signs +/-delta or uniform[-delta,delta]. Products of exact one-coordinate means give the true expected intersection volume, not an envelope product of maxima.',
                     'All interval means are exact rational: local segmented trapezoid integration is compared with an independent positive-part primitive. MacBook recomputes the exact canonical data when reachable.',
                     'Dimensions4,16,64,256,1024; delta0,1/n,1/sqrt(n) are rational at these square dimensions. Includes all-thin, near-full flush, strictly contained, wide/thin mixtures and initially tangent geometry.',
                     'Packing fixtures use actual cell arrangements compressed by source masks, with maxload1 and total theta2; this is stronger than trivial sumtheta<=1. Boundaries use half-open representatives and do not affect Lebesgue integrals.',
                     'These are exact finite geometric models, not newly constructed chronological greedy histories. The global-payment identity applies only when its stated original-family packing hypothesis is available.']}
    (BASE/'cap.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'exact_match':remote.get('all_exact_data_match'),
                      'geometry_rows':len(data['geometry']),'packing_fixtures':len(data['packing']),
                      'geometry_comparisons':{k:sum(r['comparison']==k for r in data['geometry']) for k in ('greater','less','equal')}},indent=2))
if __name__=='__main__':main()
