"""Independent endpoint flow/cut check with integer capacities, also LP dual."""
from itertools import product
from fractions import Fraction
from collections import deque
from random import Random
from scipy.optimize import linprog
import numpy as np,json
def run(seed,n):
    rand=Random(seed)
    edges=[(a,b,rand.randint(1,11)) for a,b in product(range(n),repeat=2) if rand.randrange(4)==0]
    caps=[rand.randint(1,14) for _ in range(n)]
    edges.append((0,0,3))
    source=len(edges)+n
    sink=source+1
    residual=[{} for _ in range(sink+1)]
    def add(i,j,c):
        residual[i][j]=residual[i].get(j,0)+c
        residual[j].setdefault(i,0)
    total=sum(w for _,_,w in edges)
    for j,(a,b,w) in enumerate(edges):
        add(source,j,w)
        for v in {a,b}:add(j,len(edges)+v,total+1)
    for v,c in enumerate(caps):add(len(edges)+v,sink,c)
    flow=0
    while True:
        prev={source:None}
        q=deque([source])
        while q and sink not in prev:
            i=q.popleft()
            for j,c in residual[i].items():
                if c and j not in prev:
                    prev[j]=i;q.append(j)
        if sink not in prev:break
        chain=[];j=sink
        while j!=source:
            i=prev[j];chain.append((i,j));j=i
        c=min(residual[i][j] for i,j in chain)
        for i,j in chain:
            residual[i][j]-=c;residual[j][i]+=c
        flow+=c
    cut=max(sum(w for a,b,w in edges if (s>>a)&(s>>b)&1)
            -sum(c for v,c in enumerate(caps) if (s>>v)&1) for s in range(1<<n))
    assert total-flow==cut
    # Joint LP: discrete positive-volume cells represented by integer intervals,
    # scaled tag/source masses one. Compare independently formed primal, dual.
    left=[rand.randrange(5) for _ in range(n)]
    cells=[[l<=x<l+4 for x in range(8)] for l in left]
    E=len(edges); C=8
    P=n*C; F=P+2*E; dims=F+E
    constraints=[];rhs=[]
    def row():return np.zeros(dims)
    for j,(a,b,w) in enumerate(edges):
        r=row();r[b*C:b*C+C]=-np.array(cells[a],dtype=int)
        r[P+2*j:P+2*j+2]=-1;r[F+j]=-1;constraints.append(r);rhs.append(-w)
    for h in range(n):
        r=row();r[h*C:(h+1)*C]=1;constraints.append(r);rhs.append(1)
        r=row()
        for j,(a,b,w) in enumerate(edges):
            if a==h:r[P+2*j]=1
            if b==h:r[P+2*j+1]=1
        constraints.append(r);rhs.append(caps[h])
    c=row();c[F:]=1
    primal=linprog(c,A_ub=constraints,b_ub=rhs,method='highs')
    dualrows=[]
    for h in range(n):
        for x in range(C):
            r=np.zeros(E+2*n);r[E+h]=-1
            for j,(a,b,w) in enumerate(edges):
                if b==h and cells[a][x]:r[j]=1
            dualrows.append(r)
        for j,(a,b,w) in enumerate(edges):
            if h in (a,b):
                r=np.zeros(E+2*n);r[j]=1;r[E+n+h]=-1;dualrows.append(r)
    dc=[-w for a,b,w in edges]+[1]*n+caps
    dual=linprog(dc,A_ub=dualrows,b_ub=[0]*len(dualrows),
                bounds=[(0,1)]*E+[(0,None)]*(2*n),method='highs')
    assert primal.success and dual.success and abs(primal.fun+dual.fun)<1e-8
    return dict(seed=seed,n=n,arcs=edges,caps=caps,left=left,exact_unpaid=cut,
                joint_primal=primal.fun,joint_dual=-dual.fun)
print(json.dumps([run(59*n+s,n) for n in [3,6,10] for s in range(4)],indent=2))
