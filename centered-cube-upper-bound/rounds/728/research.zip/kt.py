#!/usr/bin/env python3
"""Arcsine/Beta capacity audit for one shared pairwise mixing parameter."""
from fractions import Fraction as F
from math import comb,isqrt
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
sys.set_int_max_str_digits(1000000)
BASE=Path(__file__).resolve().parent
SMALL=list(range(1,65))+[96,128,192,256]
LARGE=[512,1024,4096,16384]

def B(k,j):return F(comb(2*j,j)*comb(2*(k-j),k-j),4**k*comb(k,j))
def mle(k,j):return F(j,k)**j*F(k-j,k)**(k-j)
def exact_summary(direct=False):
    rows=[]
    for k in SMALL:
        c=F(4**k,comb(2*k,k));assert c*c<=4*k
        bj=1/c;worst=F(0);where=[]
        for j in range(k+1):
            q=B(k,j) if direct else bj
            r=mle(k,j)/q
            assert r<=c
            if r>worst:worst=r;where=[j]
            elif r==worst:where.append(j)
            if j<k:bj*=F(2*j+1,2*k-2*j-1)
        assert worst==c and where==[0,k]
        rows.append({'k':k,'c_k_exact':str(c),'max_ratio_exact':str(worst),'maximizers_j':where,'c_k_squared_le_4k':True})
    large=[]
    for k in LARGE:
        c=F(4**k,comb(2*k,k));assert c*c<=4*k
        checks=[]
        for j in (0,1,k//4,k//2,k-1,k):
            r=mle(k,j)/B(k,j);assert r<=c
            checks.append({'j':j,'ratio_over_endpoint_exact':str(r/c)})
        large.append({'k':k,'c_k_exact':str(c),'c_k_squared_le_4k':True,'selected_exact_ratios':checks})
    return {'small_exhaustive':rows,'large_selected_exact':large}

def overlap(a,b,z):return max(F(0),min(b,z+1)-max(a,z))
def law_mean(a,b,interval):
    lo,hi=interval
    if lo==hi:return overlap(a,b,lo)
    knots=sorted({lo,hi}|{v for v in (a-1,a,b-1,b) if lo<v<hi})
    return sum(((v-u)*(overlap(a,b,u)+overlap(a,b,v))/2 for u,v in zip(knots,knots[1:])),F(0))/(hi-lo)
def mixture_capacity(a,b):
    k=len(a);coeff=[F(1)]
    for aa,bb in zip(a,b):
        new=[F(0)]*(len(coeff)+1)
        for j,v in enumerate(coeff):new[j]+=v*bb;new[j+1]+=v*aa
        coeff=new
    return sum((v*B(k,j) for j,v in enumerate(coeff)),F(0)),coeff
def evaluate(a,b,p):
    v=F(1)
    for aa,bb in zip(a,b):v*=p*aa+(1-p)*bb
    return v

def geometry():
    out=[];eps=F(1,2**20);delta=F(1,4);L=1+eps
    for k in (4,16,64,256):
        for kind in ('two_endpoints','two_uniform_intervals'):
            laws=[(-delta,-delta),(delta,delta)] if kind=='two_endpoints' else [(-2*delta,-delta),(delta,2*delta)]
            q=eps+delta if kind=='two_endpoints' else eps+3*delta/2
            for j in (0,k//2):
                intervals=[(eps-L,eps)]*j+[(1-eps,1-eps+L)]*(k-j)
                a=[law_mean(x,y,laws[0]) for x,y in intervals];b=[law_mean(x,y,laws[1]) for x,y in intervals]
                assert a==[q]*j+[F(0)]*(k-j) and b==[F(0)]*j+[q]*(k-j)
                cap=q**k*B(k,j);best=q**k*mle(k,j);original=eps**k;c=F(4**k,comb(2*k,k))
                assert evaluate(a,b,F(j,k))==best and best<=c*cap
                out.append({'k':k,'case':'thin_opposite_faces','j_negative_shift_axes':j,'law_kind':kind,
                            'laws':[[str(x),str(y)] for x,y in laws],
                            'large_side_exact':str(L),'small_side_exact':'1','initial_lens_width_all_axes':str(eps),
                            'normalized_large_interval_runs':[{'count':j,'interval':[str(eps-L),str(eps)]},
                                                               {'count':k-j,'interval':[str(1-eps),str(1-eps+L)]}],
                            'shared_optimal_p_exact':str(F(j,k)),'initial_intersection_exact':str(original),
                            'actual_best_expected_intersection_exact':str(best),'arcsine_capacity_exact':str(cap),
                            'best_over_capacity_exact':str(best/cap),'capacity_over_original_exact':str(cap/original),
                            'root_capacity_payment_holds':True})
            # Near-full lens: both laws lose volume equally, and everyp is allowed.
            a0=-eps/2;b0=1+eps/2;qa=law_mean(a0,b0,laws[0]);qb=law_mean(a0,b0,laws[1]);assert qa==qb<1
            cap=qa**k
            out.append({'k':k,'case':'near_full_loss','law_kind':kind,'laws':[[str(x),str(y)] for x,y in laws],
                        'large_side_exact':str(L),'small_side_exact':'1','normalized_large_interval_all_axes':[str(a0),str(b0)],
                        'initial_intersection_exact':'1','actual_best_expected_intersection_exact':str(cap),
                        'arcsine_capacity_exact':str(cap),'best_over_capacity_exact':'1',
                        'capacity_over_original_exact':str(cap),'root_capacity_payment_holds':True,
                        'actual_receiving_intersection_note':'Every sharedp has the same exact expected receiving intersection. Capacity is exponentially small relative to the original full lens, yet pays the actual expected intersection exactly.'})
    # A genuine nonmonomial nonnegative product, checked term byterm for everyp.
    k=12;laws=[(-delta,-delta),(delta,delta)]
    intervals=[(-F(3,4),F(1,2))]*4+[(F(1,8),F(11,8))]*4+[(-F(1,8),F(9,8))]*4
    a=[law_mean(x,y,laws[0]) for x,y in intervals];b=[law_mean(x,y,laws[1]) for x,y in intervals]
    cap,coeff=mixture_capacity(a,b);c=F(4**k,comb(2*k,k))
    samples=[]
    for pp in range(33):
        p=F(pp,32);v=evaluate(a,b,p);assert v<=c*cap
        assert all(p**j*(1-p)**(k-j)<=c*B(k,j) for j in range(k+1))
        samples.append({'p':str(p),'actual_expected_intersection_exact':str(v),'over_capacity_exact':str(v/cap)})
    out.append({'k':k,'case':'nonmonomial_real_intervals','laws':[[str(x),str(y)] for x,y in laws],
                'normalized_large_intervals':[[str(x),str(y)] for x,y in intervals],
                'coordinate_law_A_means':[str(v) for v in a],'coordinate_law_B_means':[str(v) for v in b],
                'nonnegative_Bernstein_coefficients':[str(v) for v in coeff],
                'arcsine_capacity_exact':str(cap),'exact_p_grid':samples,
                'all_p_certificate':'Every coefficient is nonnegative and every monomial satisfies likelihood<=c_k B_kj; summing proves the inequality for all realp in[0,1].'})
    # Counterexample to allowing a separate p on every coordinate.
    k=64;j=k//2;ratio=1/B(k,j);c=F(4**k,comb(2*k,k));assert ratio>c
    negative={'k':k,'j':j,'coordinate_specific_p_can_make_monomial_product':'1',
              'coordinate_specific_best_over_common_arcsine_capacity_exact':str(ratio),
              'common_p_endpoint_bound_exact':str(c),'violates_root_common_p_bound':True}
    return {'fixtures':out,'coordinatewise_p_negative_control':negative}

def canonical(data):return json.dumps(data,sort_keys=True,separators=(',',':')).encode()
if '--remote' in sys.argv:
    data={'exact':exact_summary(True),'geometry':geometry()}
    print(json.dumps({'host':socket.gethostname(),'python':platform.python_version(),
                      'method':'direct central-binomial Beta formula vs local Beta recurrence',
                      'exact_digest':hashlib.sha256(canonical(data)).hexdigest()}));sys.exit(0)

from flint import arb,ctx

def large_exhaustive():
    out=[]
    for k in LARGE:
        checks=[]
        for bits in (256,384):
            ctx.prec=bits;c=F(4**k,comb(2*k,k));lc=(arb(c.numerator)/c.denominator).log();lb=-lc
            min_gap=None
            for j in range(k+1):
                if j not in (0,k):
                    lm=j*(arb(j)/k).log()+(k-j)*(arb(k-j)/k).log()
                    gap=lc-(lm-lb);assert gap>0
                    if min_gap is None or gap<min_gap:min_gap=gap
                if j<k:lb+=(arb(2*j+1)/(2*k-2*j-1)).log()
            checks.append(min_gap)
        assert checks[0].overlaps(checks[1])
        out.append({'k':k,'all_j_checked':k+1,'exact_endpoint_maximizers':[0,k],
                    'minimum_interior_log_gap_below_endpoint':checks[1].str(40),'precision_bits':[256,384]})
    return out

def main():
    data={'exact':exact_summary(),'geometry':geometry()};digest=hashlib.sha256(canonical(data)).hexdigest()
    large=large_exhaustive()
    cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    try:
        run=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':cmd,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:
            remote['result']=json.loads(run.stdout);assert remote['result']['exact_digest']==digest;remote['all_exact_data_match']=True
    except subprocess.TimeoutExpired:remote={'command':cmd,'timeout_seconds':45}
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'exact_data_digest':digest,**data,'large_exhaustive_arb':large,'remote':remote,
            'conclusion':['For k>=1, all testedj have max_{p in[0,1]}p^j(1-p)^(k-j)/B_kj<=c_k=4^k/binom(2k,k)<=2sqrt(k), with worstj exactly0,k. k0 hasc0=1 and is excluded from2sqrt(k).',
                          'For actual coordinate law meansa_l,b_l>=0, C(p)=product_l[p a_l+(1-p)b_l] has nonnegative homogeneous Bernstein coefficients. The monomial bound therefore gives C(p)<=c_k integralC(q)dArcsine(q) for every shared realp, independently chosen for each pair.',
                          'A single pair must use the same mixing parameter across itsk active coordinates. Allowing each coordinate its own optimizer can cost exponentially more; the exact64-coordinate negative control records this.'],
            'scope':['Finite exact interval geometry, not a chronological greedy history. All initial lens widths are nonnegative, and actual source sides and translation laws are retained.',
                     'Two laws are either actual negative/positive endpoint translations or uniform translations on disjoint negative/positive intervals. Coordinates are independent conditional on the commonp. Arcsine capacity first integrates this commonp with the Beta(1/2,1/2) law.',
                     'Near-full lenses demonstrate capacities exponentially smaller than initial intersection but still exactly paying the actual expected receiving overlap. Thin opposite-face lenses demonstrate that the capacity need not track the initial lens.',
                     'Exact allj checks k1..64 and k96,128,192,256; expanded allj Arb256/384 checks k512,1024,4096,16384, plus exact selectedj on both machines. Local recurrence and remote direct central-binomial formulas independently generate the same exact canonical data.',
                     'No quadrature approximation or optimization heuristic is used. Onlykt.py/json are written; frozen cap.py/json are untouched.']}
    (BASE/'kt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'remote_exit':remote.get('exit_code'),'exact_match':remote.get('all_exact_data_match'),
                      'exact_small_k_count':len(SMALL),'expanded_k':LARGE,'geometry_count':len(data['geometry']['fixtures'])},indent=2))
if __name__=='__main__':main()
