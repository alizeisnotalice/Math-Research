# R195: actual reciprocal source-pair localization, uniform in softness

This proves a source-priced portion of the original reciprocal positive traffic. It does not bound the remaining close-pair core and does not establish the general weak estimate. Unlike R194's y-v near-displacement condition, this uses original reciprocal y-u current-density comparability. All original sources, real receivers, windows and the fixed positive flow measure are retained.

## RL1. Uniform one-dimensional translated affinity

Let h=1_[-1/2,1/2], w(r)=integral_0^1 exp(-|r|/t)dt, phi=h*w, f_s=(1-s)h+s phi, 0<=s<=1. These are even probability densities, with phi nonincreasing in |r|. Write m0=phi(1/2). For |r|<=1/2, f_s(r)>=m0, for every s including both endpoints.

For d>=0, compare the probabilities with densities f_s(x) and f_s(x-d) on the event (-infinity,d/2]. Their mass difference is exactly integral_[-d/2,d/2] f_s. It is at least m0 min(d,1). Because total masses agree, the full L1 distance is at least twice that event difference. Hence

    ||f_s-f_s(.−d)||_1 >=2m0 min(d,1).

Cauchy gives ||f-g||_1²<=8(1-integral sqrt(fg)) for probability densities. Therefore

    Aff_s(d):=integral sqrt(f_s(x)f_s(x-d))dx
       <=1-(m0²/2)min(d²,1).

Moreover phi(1/2)=integral_0^1w(r)dr, and w(r)>=1/2 exp(-2r). Thus m0>=(1-exp(-2))/4>=1/8. In particular the explicit uniform estimate

    Aff_s(d)<=exp[-c0 min(d²,1)], c0=1/128            (RL1)

holds for all real d and all s. This is an analytic inequality, not a fitted constant. It needs no hard-jump lower bound and remains valid at s=1.

## RL2. The actual reciprocal mask before enlarging the receiver set

On the original reciprocal bad source u, w_g(y,u)>kappa and

    kappa/w_g(y,u)<p_y/p_u<w_g(y,u)/kappa,
    kappa=K(1+gamma^(-n))/3, gamma=1+1/n.

Since w_g<=1, at these actual points p_y<=kappa^(-1/2)sqrt(p_y p_u). Zero-density slots are removed before taking a ratio; original strictsoft has positive kernels. If kappa>=1 the strict reciprocal region is empty. No comparison between beta and nu is assumed.

With b fixed in the original window, define the fixed-source distance

    D2(y,u)=sum_i min(|y_i-u_i|²/b²,1).

For fixed s,L with a<=L<=b, product receiver integration and RL1 yield

    integral sqrt(P_(s,L)(x-y)P_(s,L)(x-u))dx
       =product_i Aff_s((y_i-u_i)/L)
       <=exp[-c0 D2(y,u)].                            (RL2)

Only the receiver kernel is tensorized after sources are fixed. No product law for the original source measures is introduced.

## RL3. Complete adaptive softness and scale fees

Set G_s,L(x)=sqrt(P_s,L(x-y)P_s,L(x-u)). For any s in [0,1], the interval

    I_s=[ns/(n+1),(ns+1)/(n+1)]

has length1/(n+1), lies in [0,1], and every t in I_s satisfies both t>=ns/(n+1) and 1-t>=n(1-s)/(n+1). Thus f_t>=n f_s/(n+1) pointwise, and

    G_t,L>=(n/(n+1))^n G_s,L>=exp(-1)G_s,L.

Integrating t on I_s and enlarging to [0,1] proves the pointwise envelope

    sup_s G_s,L <= exp(1)(n+1)integral_0^1G_t,L dt.    (RL3)

This uses one common parameter t for both kernels and all coordinates. There is no per-coordinate soft selection and no exclusion of endpoints.

Since f_s is radial nonincreasing, L^nG_s,L is pointwise nondecreasing and right-continuous in L. The supremum in s preserves this property (the compact parameter dependence is continuous). Weighted Stieltjes variation on [a,b] therefore gives

    integral sup_(s,L) G_s,L dx
       <=exp(1)(n+1)[1+n log(b/a)]exp(-c0 D2)
       <=exp(1)(n+1)(1+n log2)exp(-c0 D2).            (RL4)

To see the scale fee explicitly, put F_L=sup_sG_s,L. Then sup_LF_L<=F_b+n integral_a^b F_L dL/L. Apply RL3 and RL2 at each fixed L before integrating L. Moving hard faces remain Stieltjes atoms; no adaptive-face null-set argument is used.

## RL4. Original positive traffic and actual source price

Use precisely the previously verified R186 fixed positive flow measure Gamma_V^+ written in R194 geometry_cost.md GC1–4. It is independent of receiver x and includes original j and t; its total expected mass is at most Lstar Wbeta<=Lstar W_A, with

    Tstar<=log2+(n+1)log²2/4, Lstar=(n/4)Tstar.

Independent windows retain the original total ledger; Tstar is the original whole-window supremum. If Lstar=0 the traffic is zero. We do not use the original unique j to discard the reference j cost a second time.

Start with the original reciprocal mask R and all high/good/capture/history/late/tiny/low-tree and R194 complement masks in H. Only on R apply p_y<=kappa^(-1/2)sqrt(p_y p_u). Then A,H<=1 may be positively dropped while keeping any desired fixed-source distance event. RL4 implies for each fixed r>=0,

    Raw_original^+[R;D2>=r]
       <=(32Lambda/3) B_n exp(-c0 r) W_A,             (RL5)
    B_n=kappa^(-1/2)Lstar exp(1)(n+1)(1+n log2).

One factor16/3 and the original outer2Lambda occur exactly once. This is an actual receiver integral, not an abstract pair capacity. No new current threshold, posterior, forest or capture is selected.

For B_n>0 define

    r_n=128 log_+(B_n/sqrt(n)).                       (RL6)

Then RL5 yields the explicit root source price

    Raw_original^+[R;D2>=r_n]
       <=(32Lambda/3)sqrt(n) W_A.                    (RL7)

If B_n<=sqrt(n), r_n=0 and the estimate pays the whole original reciprocal positive portion in that parameter situation. If r_n>n, the displayed distance branch is empty, since D2<=n; this must not be described as nonempty coverage. Equality at r_n is included. With actual K=1, kappa is bounded above and below by absolute positive constants, so B_n=O(n^4) and r_n=O(log(n+2)). If K is varied, the kappa factor remains explicit.

## RL5. What the unpaid core now actually implies

On the complement of the paid distance branch,

    sum_i min(|y_i-u_i|²/b²,1)<r_n.                   (RL8)

In particular the number of coordinates with |y_i-u_i|>=b is less than r_n. For any 0<delta<=1, the number with |y_i-u_i|>delta b is at most r_n/delta². On coordinates with |y_i-u_i|<=b, Cauchy gives sum of their displacements <=b sqrt(n r_n). There is NO bound on the untruncated lengths of the exceptional coordinates from RL8 alone; any further bound must use the original carrier. Even the small-coordinate L1 bound has a real sqrt(n) loss.

These statements may now be combined with R194 SD/GC complements, but the pair types differ. A non-sparse y-v pair and a small truncated y-u distance do not automatically meet the many-short-u-v-current-face gate. The residual integral still retains p_y A, real x, same alpha, low K0/w, eligible nu and source reuse. This round does not mark that remainder paid or merely assign it a new norm. Strict enlargement of all historical FULL coverage is not asserted without an actual realization comparison.

## RL6. Numerical scope

The local script checks finitely many exact-hard and high-precision mixed/soft translated densities, the midpoint witness, and finite pointwise soft-envelope samples. It does not certify general geometry, original FULL or the asymptotic order; those claims must rest on RL1–7 and the already audited original reference contract. Two-precision quadrature is not interval arithmetic. No PDF is compiled.
