# R195: actual target suppression and the remaining weighted receiver displacement

This is a bounded checkpoint on the original remaining reciprocal core. It proves an additive source estimate and an elementary physical translation bound. It does **not** prove a root bound for the entire core. The unpaid term below retains the original capture, posterior, receiver and source measures; it is not declared paid by naming it.

## CG1. Original variables and domain

Work in one original common window, and then use the original window ledger. Its current selector is `(s(x),L(x))`, with `a<=L<=b<=2a`, and its common FIRST threshold is q. Write

    p_y=P_(s,L)(x-y), p_v=P_(s,L)(x-v),
    pplus_v=P_(s,Lplus)(x-v), J_v=P_(1,b)(x-v),
    Lplus=min(b,gamma L), gamma=1+1/n,
    Q_v=(p_v+pplus_v+J_v)/3,
    A_y(v)=1_good rho_y(v) J_v/(3Q_v).

All rho, alpha and capture variables are the original ones. In particular no alpha is recomputed after a split. Put `a_n=1+gamma^(-n)`. Radial monotonicity and `Lplus/L<=gamma` give `pplus_v>=gamma^(-n)p_v`, including the closed hard faces. Original strictsoft makes the kernels positive. More generally all zero target slots are set to zero before dividing by J or Q.

Let H be the product of the original nonnegative masks, with `0<=H<=1`: receiver membership, high, reciprocal bad, time/history, the late/tiny/low-tree gates and any already retained R194/R195 complement masks. The original unique-j indicator stays inside H until a positive upper bound explicitly enlarges it. Every dx integral initially ranges over the original receiver set E. No negative credit is used.

The original common-parent budget is denoted W_A. We only use `W_beta<=W_A` and `W_nu<=W_A`; there is no ordering between beta and nu.

## CG2. Exact target suppression, before discarding same-alpha information

On good target slots the defining identity is

    (rho-A)J_v=A(p_v+pplus_v).

It follows that

    a_n p_v A <= (rho-A)J_v <= (1-A)J_v.             (CG1)

Outside good, A=0, so the inequality remains valid with its left side zero. This identity uses the actual rho, hence the original common alpha and capture; it is not an estimate in which rho is independently chosen.

The useful primary gate is `rho-A<=eta`, with `0<eta<1`. The high-A gate `A>1-eta` implies this primary gate, since rho<=1. The primary gate does not require rho close to one. On either gate,

    p_y A/sqrt(J_v)
      <= eta/a_n sqrt(J_v)
         + A (p_y-p_v)_+/sqrt(J_v).                 (CG2)

More precisely eta can be replaced pointwise by rho-A in the first term. The pointwise proof is just `p_y<=p_v+(p_y-p_v)_+` followed by CG1. No terminal overlap inverse has been introduced.

## CG3. The actual companion and its additive source fee

Use the following **same original positive measure** for both factors:

    dM = E sum_V sum_j 1_E(x) H(x,y,v,u,j,t)
         dx beta_V(dy) dt/t Pi_(y,j,t)(dv) Pi_(y,j,t)(du).

Here H includes the gate under consideration from CG2. The original scores remain `k_t(y,v)` and `k_t(y,u)`, and `delta_+=(k_t(y,v)-k_t(y,u))_+`. Set

    C_core = integral p_y^2 A^2/J_v dM,
    Z_J    = integral J_v dM,
    C_shift= integral A^2 (p_y-p_v)_+^2/J_v dM.       (CG3)

These are extended nonnegative integrals. Finite restrictions give the estimates below first; monotone limits preserve them. Minkowski, applied to CG2 in this very same measure, gives

    sqrt(C_core) <= eta/a_n sqrt(Z_J)+sqrt(C_shift). (CG4)

The rightmost term retains the actual y-dependent A, all original u-dependent masks, and the original posterior. In particular it is not an unweighted translation distance.

For fixed `(omega,V,j,y,t)`, the original `nu,Z_t,w_t,e_t,Pi_t` are independent of x, as in R186 FL and R194 GC. The terminal quantities and H generally are not independent of x. Positively dropping H after writing CG3, enlarging each original actual time set only into its original x-independent auxiliary interval `[a/c_j,b c_j]`, and using `integral J_v dx=1`, gives

    Z_J <= Tstar W_beta,                            (CG5)
    Tstar = sup_original_windows sum_j
               log_+(b c_j^2/a)
           <= log 2+(n+1)(log 2)^2/4.

An empty time interval has zero contribution, and e_t=0 rows are zero. The two posterior measures have mass at most one. This is where Tonelli is legitimate. In particular **the j cost in Tstar is retained**; the original unique-j identity does not identify the different frozen posterior measures after the receiver gate has been dropped. Additional independent windows retain their original source ledger, rather than receiving another free copy of W_A.

The previously proved original one-slot energy, with the repaired source budget, is

    E_J := integral J_v delta_+^2 dM
         <= n/(2K) W_nu.                            (CG6)

Its provenance is R173 mass_energy_audit sections 2.1--2.2 and the R181 common-parent correction W_nu<=W_A. The old W_beta conclusion from an unproved source ordering is not used.

After the single original hard bound 16/3 and outer factor 2 Lambda, Cauchy and CG4--6 yield the actual original positive estimate

    Raw_core^+
      <= (32 Lambda/3) [
           eta/a_n sqrt(n Tstar/(2K)) sqrt(W_beta W_nu)
           + sqrt(n W_nu C_shift/(2K)) ]
      <= (32 Lambda/3) [
           eta/a_n sqrt(n Tstar/(2K)) W_A
           + sqrt(n W_A C_shift/(2K)) ].            (CG7)

Thus the **first additive contribution** is at root scale if

    0<eta<1, eta <= a_n/sqrt(Tstar),                 (CG8)

with Tstar=0 handled as zero traffic. This does not pay the second contribution or assert that a new entire physical branch has been settled. For fixed eta the first fee is of order n, because Tstar=O(n). For the high-A core one may use its already chosen eta; no new free small parameter is silently inserted into that core. The stronger `rho-A<=eta` version is also valid without high A.

## CG4. What a fixed-parameter physical translation bound actually controls

For comparison, the ordinary displacement admits a useful elementary bound. Let

    f_s=(1-s)h+s phi, h=1_[-1/2,1/2],
    P_(s,L)(x)=L^(-n) product_i f_s(x_i/L),
    L_phi=2/(1-exp(-1)).

Use the audited scalar log-Lipschitz estimate `|phi'|<=L_phi phi` almost everywhere. For fixed s,L and fixed y,v,

    TV(P_(s,L)(.-y),P_(s,L)(.-v))
      <= min(1,
          L_phi sqrt(s)/(2L) ||y-v||_2
          +(1-s)/L ||y-v||_1).                    (CG9)

TV here is half the L1 distance. This is an unconditional bound for the physical mixed kernel, including s=0 and s=1.

Proof: write d=y-v and translate the product density along the segment v+r d. In the absolutely continuous part of its spatial derivative, the one-coordinate score is `s phi'/f_s`. Its mean is zero, since `integral phi'=0`, and its second moment is at most

    integral s^2 phi'^2/f_s <= s integral phi'^2/phi
                            <= s L_phi^2.

Under the product **receiver density**, the coordinate scores have zero cross terms. Hence the L1 norm of the absolutely continuous directional derivative is at most `L_phi sqrt(s)||d||_2/L`. Each coordinate contributes two hard-face derivative measures; their total variation is `2(1-s)|d_i|/L`, because all other factors have integral one. Integrate this bound along r in [0,1] and divide by two. At s=0 the ac term is absent. The hard-face measures were counted, rather than discarded as receiver-null sets.

This proof uses product structure of the receiver kernel only. The sources are neither independent nor product distributed. It involves no derivative in softness or scale.

For a fixed parameter pair, the simpler pointwise inequality `p_y A<=p_v A+(p_y-p_v)_+`, together with CG1, gives

    integral_[rho-A<=eta] p_y A dx
       <= eta/a_n + TV(P_(s,L)(.-y),P_(s,L)(.-v)).   (CG10)

The capture and history may be additionally restricted on the left; positive restriction does not hurt this statement. But CG9--10 are **not** estimates of C_shift: they concern a first-power unweighted translation, while CG3 has its original square, inverse J and posterior/mask weights. They also do not allow a different `(s,L)` to be chosen at each receiver at no cost. The actual manuscript uses CG5, not CG10, for the genuinely adaptive additive source fee.

## CG5. The first unpaid integral after the new suppression

For the original R194 core, intersected if desired with the new R195 reciprocal localization complements, the missing estimate in this route is an upper bound for the explicit integral

    E sum_V sum_j integral_E dx integral beta_V(dy) integral dt/t
      integral Pi_t(dv)Pi_t(du)
       H A_y(v)^2 (P_(s(x),L(x))(x-y)
                  -P_(s(x),L(x))(x-v))_+^2/J_b(x-v).       (CG11)

No weight, support or normalization in CG11 is changed from CG3. In particular `Z_t(y)` remains the original one, the terminal good and same-alpha gate remains in A, and the extra history and source-pair gates remain in H. A polylogarithmic W_A bound on CG11 would give the corresponding root-polylog source price in CG7; no such bound is proved here.

The new parent localization controls the **outer--bad** pair y,u:

    sum_i min(|y_i-u_i|^2/b^2,1)=O(log(n+2)),

and on its additional complement a joint bound for `(1-s(x))^2 sum_i min(|y_i-u_i|/b,1)`. CG11 instead contains the **outer--target** displacement y,v, with target weight A and inverse J_v. R194's sparse-displacement complement specifically allows many non-microscopic y-v coordinates. There is no valid replacement of v by u in CG11. Neither those pair bounds, the fact that current source mass is at most q, nor CG9 removes its inverse J and adaptive-selector dependence.

The high-A target-current test itself is explicit:

    p_v/J_v < eta/[(1-eta)a_n]                     (CG12)

on A>1-eta. It gives `integral_[highA] p_v nu(dv) <= eta q/[(1-eta)a_n]` using the same legal J FIRST bound. This is current-weighted target capacity. The original posterior instead has density `1_Zt w_t nu/e_t`; changing between them introduces `w_t/(e_t p_v)`, which is precisely not controlled by CG12. Therefore CG12 is not a small-posterior or small-traffic conclusion.

The useful gain of CG1--7 is the exact compensation of the target's own current contribution by the original share deficit rho-A, with a fully specified additive source fee. The first unresolved geometric step is the target-weighted receiver displacement CG11. This checkpoint supplies no all-input root closure, no replacement for the parent's newly paid outer--bad localization, and no second payment for the already treated R194 branches.
