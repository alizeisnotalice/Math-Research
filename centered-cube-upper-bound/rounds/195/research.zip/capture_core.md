# R195：同一 capture 下的剩余供给与来源缺失单次收费

本稿给出一个实际 capture/空间接口。先从原 neutral 扣除已经用于同点匹配的质量，再用 R194 的物理捕获率下界处理剩余 target。供给不足所需的 μ−ν 与 E 外来源合成同一个测度，只按其真实空间占用收取一次同 α 预算。这个接口不重证 OC 的 LP/弱对偶，也不把小 A 片登记为新付款。一般 core 的空间占用费仍未得到根阶上界。

## CC1. 固定实际行及不改变的对象

固定原 `(ω,V,x,j,y)`、原 q/window、ell≤h<g、e=e_g(y)>0、current/FIRST、唯一 j(x)、全部 history/Pi/删除。采用冻结 R194 SC 与 R193 TD 记号

\[
 w(z)=w_\ell(y,z),\quad k_z=DK_{0,z},\quad K_0=P_{s,\widehat H},
 \quad t_z=T\Delta_z,\quad \Delta_z=w_{\tau_0}(y,z)-w_h(y,z),
\]
\[
 \chi=1_E\min(1,t/k)\nu,\quad \Theta=A\nu,\quad
 A=1_{\rm good}\rho J/(p+p^++J),\quad
 \rho=[1-(k+\alpha J)/t]_+.
\]

原 strictsoft s>0 保证 k>0；s=1 可用。保持

\[
 0\le\Theta\le\chi\le\nu\le\mu=\mu_{\rm hi},\quad
 \operatorname{supp}\chi\subset Z_g(y),\quad
 R=\alpha QJ=Dq-\int k\,d\chi,\quad
 \int k\,d(\mu-\chi)\le R.
 \tag{CC1}
\]

不使用 ν≤β，不把 h(P) 变为 ν 质量。下文所有供给选择沿辅助时间固定，不能依正在积分的 target 或时刻重选。

将两个物理来源缺失合成

\[
 L=\mu-1_E\nu=(\mu-\nu)+1_{E^c}\nu\ge0,
 \qquad L\le\mu-\chi,\quad \int k\,dL\le R.
 \tag{CC2}
\]

E 内未饱和 capture 尚未计入 L；它由后面的实际捕获率控制。这样 μ−ν 与 E 外 ν 不再按每个 ancestor 各领一次 R，也没有被当成两份可独立消费的预算。

## CC2. 先扣掉已消费的同点供给

固定 c>0。R194 SC2 证明 A>0⇒χ 在该处密度 1，故可取

\[
 A_m=\min(A,(1-A)/c),\quad
 A_d={[(c+1)A-1]_+\over c},\quad N_{\rm diag}=cA_m\nu.
\]

为避免空间匹配再次使用这份 neutral，定义

\[
 \boxed{\Theta_c=\Theta+N_{\rm diag}
          =\min((c+1)A,1)\nu\le\chi,\qquad
          N^{\rm res}=\chi-\Theta_c\ge0.}
 \tag{CC3}
\]

A=0 时两边 protected 密度都为零。原 target 为 A_m+A_d=A，同点方案仅消费 N_diag；后面的空间方案只能使用 N_res。不能继续用完整 χ−Θ 的局部质量给 A_d 匹配。

特别，在 A_d>0 的实际 target 点，Θ_c 的 ν 密度为 1。这些点的同点 neutral 已全部被消费；后续供给必须来自别处或另一个未消费部分。该约束不能从 nominal 块质量中删去。

## CC3. 被匹配缺口的真实 future loss

写 r_v=(p_v+p_v^+)/J_v≥0。在原有效 good/capture 且 Δ_v>0 的槽，R194 SC10 给

\[
 A_d(v)={[(c-r_v)-(c+1)(k_v+\alpha J_v)/(T\Delta_v)]_+
                 \over c(1+r_v)},
\]
\[
 \Delta_v A_d(v)
 ={[(c-r_v)\Delta_v-(c+1)(k_v+\alpha J_v)/T]_+
                 \over c(1+r_v)}.
 \tag{CC4}
\]

域外 A_d=0。该式保留原同 α，不能把正部中的三项分别取最坏值后当作无费预算。

以下 cell/target 家族均为有限或可数；若方案依 u，全部集合、系数和判定均须与 u 联合可测。将 A_d 按互斥可测 target 片 T_i 分解：A_i=A_d1_{T_i}，令

\[
 M_i=\int w A_i\,d\nu>0,\quad
 D_i=\int(w_\ell-w_g)A_i\,d\nu,\quad f_i=D_i/M_i\in[0,1].
 \tag{CC5}
\]

零 M_i 片先删去；未纳入的 A_out=A_d−Σ_iA_i≥0 保留为剩余 target。D_i 使用 CC4 的实际 target 密度，等价为

\[
 D_i=\int_{T_i}[1-e^{-\Omega(v)}]w(v)A_d(v)\,d\nu(v),
 \quad\Omega(v)=\log(w_\ell(v)/w_g(v)).
\]

它不是裸 target 质量。后续的 f_i≤1 是正上界；如果实际 f_i 更小可保留，不从 G_A(g)/e≤1/6 反推正 lower。

## CC4. 实际物理捕获率认证

给每个 T_i 分配物理来源集 C_i。R194 SC16–24 给出如下可计算的 sufficient certificate。假设 T_i 非空且其实际原 target 满足

\[
 A_v\ge a_i\in(0,1),\qquad \Omega(v)\ge u_0+\eta_i,\quad\eta_i>0.
\]

对相关 z∈C_i、v∈T_i，有 ||z−v||_1≤d_i^*，且原闭 Hhat 硬面计数满足

\[
 N_{\widehat H}(z)-N_{\widehat H}(v)\le m_i^+.
\]

这里 m_i^+≥0 是已认证上界，保 signed 原计数而非免费归零。置

\[
 D_i^*=18d_i^*/b,\quad
 \Gamma_i=L_\phi d_i^*/\widehat H+j_s m_i^+,\quad
 \beta(D,\eta)=e^{-D}\left[1-{e^{2D}-1\over e^\eta-1}\right]_+,
\]
\[
 \boxed{b_i^{\rm cap}=\min\left(1,
 {\beta(D_i^*,\eta_i)e^{-\Gamma_i}\over1-a_i}\right).}
 \tag{CC6}
\]

取 b_i^cap>0 的 cells；否则没有正捕获保证，其 target 留在未认证部分。式中 u0、T、Δ、Hhat 的 clamp 全为同一原行。其证明是 L_τ0h(v)≥(Ω(v)−u0)+，Δ_z≥βΔ_v，K0_z/K0_v≤e^Γi，以及 A_v≥a_i⇒TΔ_v/k_v≥1/(1−a_i)。因此

\[
 \chi|_{C_i\cap E}\ge b_i^{\rm cap}\nu|_{C_i\cap E}.
 \tag{CC7}
\]

此结论不是 E 的空间正则性，也不创造 C_i 中的 ν 质量。

## CC5. 原供给不足必须消耗哪一份来源缺失

设 w 加权的完整父来源量为 B_i^mu=∫Ci w dμ，已保护质量为 B_i^prot=∫Ci w dΘ_c。由 CC7 和 CC2，

\[
 \begin{aligned}
 S_i:=\int_{C_i}w\,dN^{\rm res}
 &\ge b_i^{\rm cap}\int_{C_i\cap E}w\,d\nu-B_i^{\rm prot}\\
 &=b_i^{\rm cap}B_i^\mu-B_i^{\rm prot}
        -b_i^{\rm cap}\int_{C_i}w\,dL.
 \end{aligned}
 \tag{CC8}
\]

这是 actual χ 的下界，未重构一个最坏 capture。假设认证了正的 nominal 余量

\[
 b_i^{\rm cap}B_i^\mu-B_i^{\rm prot}
       \ge(c+\zeta_i)M_i,\qquad\zeta_i>0.
 \tag{CC9}
\]

定义实际失败索引 F={i:S_i<cM_i}。则每个失败片必有

\[
 b_i^{\rm cap}\int_{C_i}w\,dL>\zeta_iM_i.
 \tag{CC10}
\]

CC9 必须用真实 weighted μ、Θ_c 检验。原 heavy h(P) 只有无权质量，不自动给它。若 Ci⊂P_u∩B_born，V/carrier/born 和实际 order 截断的质量都不能由 h(P_u) 代替。

## CC6. 互斥 packing 给一个共同合法匹配

要求每个固定 u 的来源 cells C_i 两两互斥，target 片 T_i 也互斥，且同一原 sorted-threshold law 在每个 C_i×T_i 上有

\[
 b_{(l)}(z)\ge b_{(l)}(v),\qquad l=1,\ldots,n.
 \tag{CC11}
\]

CC11 是额外真实几何资格，不由短距离或 CC6 自动推出。对成功 i∉F，按比例取 N_i≤N_res|Ci，使 ∫w dN_i=cM_i；source 与 target 的乘积 coupling 由 CC11 给全时钟支配 G_Ni(t)≥cG_Ai(t)。所有 N_i 可同时相加，因为 Ci 互斥。与 N_diag 合并后仍满足

\[
 N_{\rm diag}+\sum_{i\notin F}N_i\le\chi-\Theta,
\]

故它是一个共同合法方案；没有重复供给。原匹配 target 为 A_m+Σ成功Ai，缺口为

\[
 A_{\rm def}=A_{\rm out}+\sum_{i\in F}A_i,
 \qquad D_{\rm def}=D_{\rm out}+\sum_{i\in F}D_i.
 \tag{CC12}
\]

所有分割、成功判定和 c 在该原 u 的时间积分前固定、可测。可以依 u，但不能在运行 t 或 target 积分中反复更换供给。没有 CC11 或共同供给 disjointness 的方案不能直接使用 CC12 的 FTC。

## CC7. 单次缺失预算：精确保留空间重用

由 CC10、D_i=f_iM_i，实际失败 future loss 满足

\[
 \boxed{\sum_{i\in F}D_i
 \le\int k_z\,L(dz)\,\mathcal O_F(z),\qquad
 \mathcal O_F(z)={w(z)\over k_z}
       \sum_{i\in F}{f_i b_i^{\rm cap}\over\zeta_i}1_{C_i}(z).}
 \tag{CC13}
\]

这是对 actual L 的积分，不把不同 cut 的最坏来源各自实现后求和。若 R>0 且有已认证的有限点态上界 O_F≤B，则

\[
 \sum_{i\in F}D_i\le B\alpha QJ.
 \tag{CC14}
\]

来源 cells 互斥时，可取

\[
 B=\sup_i{f_i b_i^{\rm cap}\over\zeta_i\underline m_i},
 \quad\underline m_i\le\operatorname*{essinf}_{C_i,L}{k_z\over w(z)}>0.
 \tag{CC15}
\]

这里是一次 max，不是每个 ancestor 各支付一次 αQJ。保留 O_F 的实际积分通常更强；CC15 的低 k/w 价格可能很大。

如果原 Ci 重叠，CC13 仍为真，但不能删除 O_F 的求和。只有证实其 pointwise 加权重叠界后才能收费。把每个来源点分给 first-hit cell 会产生互斥 cells，但 CC8–9 的 nominal 质量必须在这些新 cells 上重新计算；不能保留旧整父块质量、同时享受新 disjointness。

对同一 y 祖先链 P0⊂…⊂PN，令 S0=P0、Sj=Pj\Pj−1，精确有

\[
 \sum_i a_i\int_{P_i}w\,dL
 =\sum_j\left(\sum_{i\ge j}a_i\right)\int_{S_j}w\,dL.
 \tag{CC16}
\]

所以真正价格是 suffix 的累计权重；嵌套本身不把它变成 1。这也说明本稿没有免费 Bellman/Carleson 跨层结论。

## CC8. 核比值与全维数费用仍在单次价中

可从冻结 SC19 给一个实际 reference v_i 的比值界。若 Ci 的来源与 v_i 距离≤d_i^*，且 N_Hhat(z)−N_Hhat(v_i)≥−m_i^-，则

\[
 \underline m_i=
 {k_{v_i}\over w(v_i)}
 \exp\!\left[-L_\phi d_i^*/\widehat H-18d_i^*/b-j_s m_i^-\right]
 \tag{CC17}
\]

是一个合法的保守下界。actual k_v/w(v) 不能归一为 1。高 A 给 k_v/(TΔ_v) 的上界，不能反过来下界 CC17。若相邻边长 S cubes 只知 d_i^*≤2nS，则 CC6、CC17 仍带 nS/Hhat、36nS/b 和两向 hard crossing 费用；这些不因 CC13 只收一次 reserve 而消失。

父本轮已付 reciprocal (y,u) 大截断平方位移，余域 D2(y,u)=Σmin(|y_i−u_i|²/b²,1)≤L 可与本稿相交，但它不证明 Ci 对 target v 的短半径。即使另保实际载体坐标帽 |y_i−u_i|/b≤R_*，也只能推出

\[
 \|y-u\|_1/b\le\sqrt{nL}+R_*L,
 \tag{CC18}
\]

由小坐标 Cauchy 与大坐标数≤L 得到；这不是无维度 l1 近。v 与 y 的原 SD 补集也保留，不能把 v 平移回 y 获得有利 beta。

若另保父 hard-jump 路线的更强实际剩余条件 `(1−s)^2 D1(y,u)<r1`，其中 D1=Σmin(|y_i−u_i|/b,1)，则 s<1 时同一坐标帽直接给完整 l1 界 `||y−u||1/b≤max(1,R_*)r1/(1−s)^2`。中央 soft 下这可为 polylog 量；近全 soft 时分母仍退化。该条件只控制实际 pair y,u，不控制 Ci×Ti 的 z,v 半径，更不把 u 附近填满整个 Pu 的合格 ν。CC6/17 的物理条件仍须逐项认证。

## CC9. 原 bad 测度积分：不再按 u/ancestor 另领 reserve

每个 fixed u 可有上面的共同合法、时间固定方案。保留实际 reciprocal bad 初始测度

\[
 P_R(du)={1_{R_y}(u)w(u)\nu(du)\over e},\qquad
 \|P_R\|\le{1\over2K\kappa}.
\]

P_R 是有此质量界的有限测度，一般不是 subprobability；1/(2Kκ) 可超过 1。

由 Tonelli，所有 failed future losses 的真实平均满足

\[
 \int P_R(du)\sum_{i\in F(u)}D_i(u)
 \le\int k_z\,L(dz)\,\mathcal O(z),
\]
\[
 \mathcal O(z)={w(z)\over k_z}
  \int P_R(du)\sum_{i\in F(u)}
    {f_i(u)b_i^{\rm cap}(u)\over\zeta_i(u)}1_{C_i(u)}(z).
 \tag{CC19}
\]

这里 μ、ν、χ、L、α 为同一固定原 row；只是合法方案依 u，未让 source 独立于 u、receiver 或森林。若对每个 u 认证其内加权占用≤B k_z/w(z)，则 O≤B/(2Kκ)，于是

\[
 \int P_R\sum_{i\in F(u)}D_i(u)
       \le {B\alpha QJ\over2K\kappa}.
 \tag{CC20}
\]

这没有另加 LCA 层数；B 本身的物理资格及可能维数费用不可删。原 μ−ν 与 E 外质量始终是 CC2 中同一 L，不按 u 重新选择。

## CC10. 原 raw 回代与第一个未付积分

由 CC12 的一个共同匹配方案，R193 TD7 在原 mask 下给

\[
 \mathrm{Raw}^+
 \le C_{\rm rec}\,\mathbb E\sum_V\int_{E_{\rm rec}}q\,dx
 \int\min\{\psi_A,2/(1+c)+D_{\rm def}(u)/(e+D_{\rm def}(u))\}\,d\lambda.
 \tag{CC21}
\]

λ 保留原 unique-j 与全部原窗口。用 ψ_def≤D_def/e，并将 λ 的原公式

\[
 d\lambda={2K\kappa\over q}\,p_y\,\beta_V(dy)P_R(du)
\]

代入，failed-cells 的缺口部分得到一个明确上界

\[
 \boxed{{32\Lambda\over3}\,
 \mathbb E\sum_V\int_{E_{\rm rec}}dx\int\beta_V(dy)
 {p_y\over e}\int k_z\,L(dz)\,\mathcal O(z).}
 \tag{CC22}
\]

必须另保 A_out 的真实 future-loss 部分；CC22 不包含它。式中 receiver 仍是 Lebesgue dx，outer β 仍是原来源，不归一为新的 fixed reference，也不换成 ν。

若使用 CC20 的 B，则 CC22 可再上放为

\[
 C_{\rm rec}\,\mathbb E\sum_V\int_{E_{\rm rec}}dx
 \int\beta_V(dy)\,{p_y\over e}\,B\alpha QJ.
 \tag{CC23}
\]

CC22 比按每个 ancestor/每个 u 重复收 reserve 更准确；但一般尚无将其压到 ε receiver 加 rootpolylog 线性父来源的定理。原 high 只给 QJ/e≤p_y/(2K) 等方向，不能上界 Bαp_y，更不能把低 k/w 的 B 当成无维常数。SC10/CC4 保留了 α 对 target 的抑制；本文没有把它与 B 分别取极值来虚报付款。

## CC11. 零支与有限检查点

α=0 时，CC2 给 ∫kL=0；原 strictsoft k>0 导致 L=0。于是任何满足 CC9 且 M_i>0 的 cell 不可能失败；不使用 1/α。QJ=0 时原 Aν=0，交通先取零。零 e、零时间或零 target mass 先按原 high/时间/正交通资格处理。若要扩展到纯硬 k=0 的来源，wL 在该集合不受 kL 预算控制，必须另留，不允许在 CC13/17 中作 0×∞ 消去；本稿没有这种扩展。

本稿新增的是：一个不重复消费同点 neutral 的实际剩余方案，以及将物理 capture 保证下的来源不足统一收在同一 L 的单次加权 packing。全维数 beta/硬面、真实 μ−ν/E 缺失、order 几何、source overlap occupation、未覆盖 target 和 receiver/window 费用均保留。一般 core 的 CC22 仍未付款；不登记新一般接收分支，不宣称全目标闭合。到此停止。
