# R195: a joint hard-weight/linear-displacement source price

This strengthens the reciprocal localization in middle softness. It uses the same actual reciprocal mask and source reference as ratio_localization.md; it does not cover the resulting close-pair core.

## HL1. Exact geometric affinity gap

Let I=[-1/2,1/2], f_s=(1-s)1_I+s phi, with phi even, radial nonincreasing and bounded by1. The symmetric difference of I and I+d has length2min(|d|,1). At each point of that difference the density whose hard interval contains the point has its phi argument of absolute value<=1/2, whereas the other argument has absolute value>1/2. The smooth difference therefore has the same sign as the hard difference. Consequently

    |f_s(x)-f_s(x-d)|>=1-s on I symmetricdifference (I+d).

Both densities are at most1, so wherever this applies

    (sqrt(f_s(x))-sqrt(f_s(x-d)))²
       =(f_s(x)-f_s(x-d))²/(sqrt(f_s(x))+sqrt(f_s(x-d)))²
       >=(1-s)²/4.

When both densities vanish the point is irrelevant; for s=1 the lower bound is zero. Integrating and using 1-Aff=half the squared Hellinger distance gives the uniform sharp-enough inequality

    Aff_s(d)<=1-(1-s)²min(|d|,1)/4
              <=exp[-(1-s)²min(|d|,1)/4].             (HL1)

This includes d>=1 without an extrapolation argument; their hard intervals are disjoint up to endpoints. Fixed boundary points have no effect on this density integral. No guessed small-displacement order is used.

## HL2. A receiver-dependent gate with a fixed-source envelope

Put D1(y,u)=sum_i min(|y_i-u_i|/b,1), so 0<=D1<=n. At fixed s,L, product integration and L<=b give

    integral sqrt(P_s,L(x-y)P_s,L(x-u))dx
       <=exp[-(1-s)²D1/4].                            (HL2)

Consider the actual joint event

    (1-s(x))²D1(y,u)>=r, r>=1.                       (HL3)

At each fixed source pair with D1>=r, it restricts s to the deterministic interval [0,1-eta_pair], where eta_pair=sqrt(r/D1). If D1<r the event is empty. Thus its dependence on the original receiver selector is handled before taking a parameter supremum, not dropped.

Write G_s,L=sqrt(P_s,L(x-y)P_s,L(x-u)). Since (1-s)^(-n)G_s,L is increasing and continuous, the same weighted Stieltjes argument as R194 gives the integrated soft supremum cost1+nlog(1/eta_pair). It is at most1+(n/2)log n because r>=1 and D1<=n. If D1=r, the interval consists only of s=0; the algebraic envelope is valid, but the original strictsoft model has no such traffic. At fixed allowed s, HL2 is at most exp(-r/4).

The scale envelope L^nG_s,L is increasing and right-continuous, including its hard-face jumps. Its cost is1+nlog2. Therefore at every fixed source pair,

    integral sup_(s,L)[G_s,L 1_{(1-s)²D1>=r}]dx
      <=[1+(n/2)log n](1+nlog2)exp(-r/4),             (HL4)

with an empty left side when D1<r. This is one common soft parameter and one common scale, not coordinatewise selection.

## HL3. Exact original source budget

Apply p_y<=kappa^(-1/2)sqrt(p_y p_u) on the original reciprocal mask first, then use HL4 in the fixed Gamma_+ representation. Retain all the original source/time/window costs Lstar Wbeta<=Lstar W_A. Set

    B1_n=kappa^(-1/2)Lstar[1+(n/2)log n](1+nlog2),
    r1_n=max(1,4log_+(B1_n/sqrt(n))).                 (HL5)

For positive Lstar and kappa<1, the original positive portion satisfies

    Raw_original^+[reciprocal;(1-s(x))²D1>=r1_n]
       <=(32Lambda/3)sqrt(n)W_A.                     (HL6)

If Lstar=0 or kappa>=1 the underlying traffic is zero. If r1_n>n the displayed event is empty; at r1_n=n it can only contain D1=n and s=0, so is empty in the strictsoft original model. No empty case is counted as positive coverage. With actual K=1 and its kappa bounded away from0, B1_n=O(n^4 log(n+2)) and r1_n=O(log(n+2)). The prefactor32Lambda/3 is not included a second time in B1_n.

HL6 and RL7 can be applied in disjoint order on the previous residual. Their two source budgets add. There is no claim that their union pays all traffic.

## HL4. The stronger actual remaining geometry

On the unpaid complement,

    (1-s(x))² D1(y,u)<r1_n.                           (HL7)

The original bad source u belongs to the actual D_V(y) carrier, with |y_i-u_i|/b<=R_n=5log n+1/2. Set Rbar_n=max(1,R_n). Pointwise |y_i-u_i|/b<=Rbar_n min(|y_i-u_i|/b,1), and hence for s<1,

    ||y-u||_1/b < Rbar_n r1_n/(1-s(x))².              (HL8)

In a prescribed middle-soft range 1-s>=1/log^a(n+2), this is a genuine O(log^(2+2a)(n+2)) bound on the full, not just truncated, distance. It follows from the original carrier and a paid source branch, not an assumption about source concentration. At s=1 there is no division and HL7 is vacuous; RL8 still supplies its separate quadratic localization.

This does not make the original LCA block small, does not force eligible nu mass near y, and does not make the K0/w ratio uniformly bounded. In particular exponentiating the polylog distance can still create exp(polylog(n)) losses; these cannot be called n^{o(1)} without checking their actual logarithmic exponent. It cannot be substituted for a full neighborhood of unweighted parent mass. The actual long target displacement, low K0/w and E/nu occupancy remain to be estimated jointly.

## HL5. Finite verification boundary

A derived finite check reuses only the actual frozen reciprocal_affinity_checks.json values and separately verifies the exact rational hard symmetric-difference lengths. A conservative rational threshold certificate checks the prefactor and empty/nonempty arithmetic for selected dimensions. These checks do not imply actual FULL realizability, do not prove the general asymptotic bound, and do not replace the analytic proof HL1–6.
