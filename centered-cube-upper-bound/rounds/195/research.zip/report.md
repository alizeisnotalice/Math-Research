# 第195轮：互反来源对的全软度与硬权定位

2026-10-16。进入本轮时main为5bc4e19af8191c3567f7b5704fdecb012eb5c1a9，工作区干净、远端正确。上一轮已推送经过核验的实质成果。本轮继续一般n^(1/2+o(1))一致弱型目标；未将来源对定位等同于一般闭合。

## 实质结果

- **全软参数截断平方距离定位。** 原互反p_y/p_u可比性接入两平移current核的几何平均。中点事件给统一affinity gap，所有s∈[0,1]均适用；共同soft包络e(n+1)、尺度Stieltjes费用1+nlog2和Γ+全部j/time费用均计入。大D2来源对取得真实根阶价格，余域D2=O(log n)。详见ratio_localization.md。
- **实际硬权与线性距离的联合定位。** 两个hard intervals对称差上的smooth差同号，给1−Aff≥(1−s)²min(d,1)/4。按固定source pair先限制实际s，再付完整参数选择费，取得(1−s(x))²D1较大区域的根阶来源价。结合原bad-source载体，中央soft余域有完整polylog L1近距离，而不是无依据的无维L1近。详见hard_shift_localization.md。
- **保留共同capture预算。** 从neutral中先扣已消费同点供给，μ−ν与E外缺失合并成同一实际测度，只按空间加权占用收一次同α预算。原raw的CC22仍未付，不能将此接口登记为新的全局价格。详见capture_core.md。

- **保留原目标份额的加性补偿。** a_n p_v A≤(ρ−A)J给原companion的Minkowski拆分，首项具有完整来源价格；逆J加权的实际y-v位移平方仍未付。固定参数TV界不能代替这一原加权积分，也不能免费传给自适应选择器。详见core_geometry.md；此项不登记整支根阶付款。

两定位分支可在前轮余域上按不交顺序使用，两个根阶来源预算相加；不重复消耗负信用，也不改变原q、window、forest或posterior。当前剩余是真实near-bad-pair/distant-target联合区域；近y-u不直接使y-v近，不使父块填满合格ν，低K0/w与capture eligibility仍保留。exp(polylog n)一般不能直接称n^{o(1)}。

## 实际数值与证据边界

reciprocal_affinity_checks.py实际检查9个平移核例（s=0,1/2,1；d=1/10,1/2,2）及135个soft包络点，每项25/40位。纯hard采用精确交叠，中点硬质量精确；混合/纯soft核分缝积分。最大相关精度差<7.3e-27，包络点精度差约2.17e-26。它们不是区间算术，不认证FULL或一般阶数。

hard_shift_checks.py复用冻结9例的实际核数值，另以Fraction严格检查hard symmetric-difference长度；新增三阶段精确有理prefactor/threshold证书：n=16,128,4096的保守r=32,60,112。n16门为空；n128/4096仅表示算术条件未强迫空，不声称有实际FULL实例。采用κ≥1/3、log2<.7、exp(-1)<3/8，平方比较根阶价格。数值affinity比较有显式1e-20容差，未误称精确核证书。

父代理实际执行两脚本，分别输出/tmp/r195_parent_affinity.json及/tmp/r195_parent_hard_shift.json，并cmp冻结JSON，退出码均0、完整bytes一致。最终manifest总driver在audit冻结后再运行，结果写外层README。

复现需已安装mpmath1.3.0，本机PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor。派生hard脚本仅stdlib，但需要同目录已冻结affinity JSON。reproduce.py先验证哈希，再重跑两个脚本并完整比较输出。未编译PDF。

## 技能、审核与下一步

沿用F01关于明确核、归一化和覆盖范围的审核要求，不使用未定义GP-BRANCH。阅读N04的尺度/误差费用条件，仅用于防止重复来源和无依据可和主张；本轮没有声称建立新的熵递减或无限望远镜定理。所有主新估计为显式直接证明，Γ+与原核合同沿用已冻结已审工具。

审查者先独筛再全文审；两主数学稿、补充稿、数值脚本及最终LaTeX在audit.md逐项记录。复用1 Astra high、2 Sol high、1 Sol medium；无实际逐模型扣额数据，不猜成本比例。

下一步须使用已付款得出的真实bad-pair近距离，与target-current差、同α捕获和空间占用联合，控制保留全部mask/原dx的near-pair core。不得把新的近距离条件当作来源密度条件，也不以固定source例替代任意L1覆盖。一般目标仍未完成。
