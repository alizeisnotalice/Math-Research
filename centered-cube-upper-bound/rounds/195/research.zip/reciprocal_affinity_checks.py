#!/usr/bin/env python3
"""Finite scalar reciprocal-affinity and soft-envelope diagnostics."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import time
import mpmath as mp
HERE=Path(__file__).resolve().parent


def runtime(dps):
    mp.mp.dps=dps
    half=mp.mpf(1)/2
    def val(q):return mp.mpf(q.numerator)/q.denominator
    def out(x):return mp.nstr(x,dps+5)
    @lru_cache(maxsize=65536)
    def phi(x):
        r=abs(x)
        if r<=half:return 1-mp.expint(3,half-r)-mp.expint(3,half+r)
        return mp.expint(3,r-half)-mp.expint(3,r+half)
    m0=phi(half)
    assert m0>=mp.mpf(1)/8
    def density(x,s):return (1-s)*(abs(x)<=half)+s*phi(x)
    def affinity(sq,dq):
        s,d=val(sq),val(dq)
        seams=sorted(set([-half,mp.mpf(0),half,d-half,d,d+half]))
        if sq==0:
            exact_aff=max(F(0),1-dq)
            exact_mid=min(dq,F(1))
            aff,mid=val(exact_aff),val(exact_mid)
        else:
            exact_aff=exact_mid=None
            aff=mp.quad(lambda x:mp.sqrt(density(x,s)*density(x-d,s)),[-mp.inf]+seams+[mp.inf])
            # Integrate the symmetric midpoint event. Hard part has exact mass;
            # phi part is split at its seam when the event crosses the core.
            upper=d/2
            mid_cuts=[mp.mpf(0)]+([half] if upper>half else [])+[upper]
            phi_mid=2*mp.quad(phi,sorted(set(mid_cuts)))
            mid=(1-s)*val(min(dq,F(1)))+s*phi_mid
        lower=m0*val(min(dq,F(1)))
        upper_aff=mp.exp(-val(min(dq*dq,F(1)))/128)
        checks={'midpoint_mass_lower':mid>=lower,'affinity_upper':aff<=upper_aff}
        assert all(checks.values())
        return {'dps':dps,'m0':out(m0),'midpoint_event_mass':out(mid),
            'midpoint_mass_lower':out(lower),'L1_lower_from_midpoint_event':out(2*mid),
            'universal_L1_lower':out(2*lower),'affinity':out(aff),'affinity_upper':out(upper_aff),
            'pure_hard_exact_affinity':str(exact_aff) if exact_aff is not None else None,
            'pure_hard_exact_midpoint_mass':str(exact_mid) if exact_mid is not None else None,
            'finite_seams':[out(x) for x in seams],'checks':checks}
    def envelopes():
        rows=[]
        for n in (2,8,32):
            c=F(n,n+1)
            for sq in (F(0),F(1,2),F(1)):
                lo=F(n)*sq/(n+1);hi=(F(n)*sq+1)/(n+1)
                for label,tq in [('lower',lo),('midpoint',(lo+hi)/2),('upper',hi)]:
                    # Exact coefficient domination holds for any nonnegative h,phi.
                    hard_coeff=(1-tq)-c*(1-sq);soft_coeff=tq-c*sq
                    assert hard_coeff>=0 and soft_coeff>=0
                    for xq in (F(-1),F(-1,2),F(0),F(1,2),F(1)):
                        x,s,t=val(xq),val(sq),val(tq)
                        fs,ft=density(x,s),density(x,t)
                        diff=ft-val(c)*fs
                        # Algebraic coefficients separately avoid rounding a true
                        # equality into a false negative at interval endpoints.
                        coeff_diff=val(hard_coeff)*(abs(x)<=half)+val(soft_coeff)*phi(x)
                        assert coeff_diff>=0 and abs(diff-coeff_diff)<mp.mpf(10)**(-dps+3)
                        ratio=ft/fs if fs>0 else None
                        rows.append({'n':n,'s':str(sq),'t':str(tq),'t_position':label,'x':str(xq),
                            'hard_coefficient_slack':str(hard_coeff),'soft_coefficient_slack':str(soft_coeff),
                            'fs':out(fs),'ft':out(ft),'direct_difference':out(diff),
                            'nonnegative_coefficient_difference':out(coeff_diff),
                            'ratio':out(ratio) if ratio is not None else None,
                            'zero_reference_density':fs==0,'status':'PASS'})
        return {'dps':dps,'point_count':len(rows),'points':rows}
    return affinity,envelopes


def run():
    specs=[(stage,s,d) for stage,s in [('initial',F(0)),('stress',F(1,2)),('expanded',F(1))] for d in (F(1,10),F(1,2),F(2))]
    rows=[{'stage':stage,'s':str(s),'d':str(d),'runs':[]} for stage,s,d in specs]
    env=[]
    for dps in (25,40):
        aff,envelopes=runtime(dps)
        for row,(_,s,d) in zip(rows,specs):row['runs'].append(aff(s,d))
        env.append(envelopes())
    for row in rows:
        low,high=row['runs']
        diffs={k:abs(mp.mpf(low[k])-mp.mpf(high[k])) for k in ('m0','midpoint_event_mass','affinity')}
        assert all(v<mp.mpf('1e-18') for v in diffs.values())
        row['absolute_precision_differences']={k:mp.nstr(v,12) for k,v in diffs.items()}
        row['precision_consistent_1e_minus_18']=True
    env_diffs=[]
    for low,high in zip(env[0]['points'],env[1]['points']):
        assert all(low[k]==high[k] for k in ('n','s','t','x','t_position'))
        for key in ('fs','ft','nonnegative_coefficient_difference','ratio'):
            if low[key] is None:
                assert high[key] is None
            else:
                env_diffs.append(abs(mp.mpf(low[key])-mp.mpf(high[key])))
    env_max=max(env_diffs)
    assert env_max<mp.mpf('1e-18')
    return {'schema':'r195_reciprocal_affinity_v1',
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'formulas':{'density':'f_s=(1-s) h+s phi; h=1_{|x|<=1/2}; phi=h*w, w=E2(abs x)',
            'affinity':'integral sqrt(f_s(x) f_s(x-d)) dx',
            'midpoint_event':'[-d/2,d/2] under f_s; its mass is the signed shifted half-line event difference',
            'L1_lower':'L1 >= 2 midpoint_mass >= 2 phi(1/2) min(d,1)',
            'affinity_upper':'exp(-min(d^2,1)/128)',
            'soft_envelope':'t in [n s/(n+1),(n s+1)/(n+1)] implies f_t >= n/(n+1) f_s'},
        'precision_dps':[25,40],'affinity_case_count':9,'stage_counts':{'initial':3,'stress':3,'expanded':3},
        'affinity_cases':rows,'soft_envelope_runs':env,'soft_envelope_precision_max_difference':mp.nstr(env_max,12),'status':'PASS',
        'limitations':['Finite scalar physical density diagnostics, not original reciprocal/current/selector/FIRST/history or FULL instances.',
            's=0 is an exact hard-kernel boundary control, not an actual strict-soft input.',
            'Infinite mpmath quadrature and precision comparison are numerical, not directed interval certification.',
            'L1 is bounded through the midpoint event; no absolute-difference root quadrature is used.',
            'Finite soft-envelope values are numerical; nonnegative coefficient slacks are independently checked with Fraction.',
            'Tensor consequences and a uniform theorem are not inferred from these finite cases.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'reciprocal_affinity_checks.json');args=ap.parse_args()
    start=time.monotonic();r=run();args.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print('PASS: 9 affinity cases, 135 envelope points at each of 25/40 dps; seconds='+str(round(time.monotonic()-start,3)))
