# R195 reciprocal affinity diagnostics

Nine scalar cases passed at both 25 and 40 decimal digits. The three stages use s=0, 1/2, 1 respectively, each with d=1/10, 1/2, 2. The script computes actual one-dimensional density affinities, not an original reciprocal/current/FIRST/history instance or a multidimensional FULL construction.

The inherited E3 representation of phi=h*w is used directly. For s>0, whole-line integration is split at both density hard faces, their shifted copies, and both centers. For s=0, affinity max(1-d,0) and midpoint-event mass min(d,1) are exact Fraction formulas, with their rational values retained in JSON. This hard boundary is a tool control, not a strict-soft input.

The midpoint event is [-d/2,d/2] under f_s. Its hard contribution is exact and its phi contribution is integrated symmetrically, splitting at 1/2 if necessary. Its mass is the signed difference of the two shifted half-line probabilities, hence gives an L1 lower bound twice that mass without absolute-difference root quadrature. All cases pass midpoint_mass >= phi(1/2) min(d,1), and phi(1/2) >= 1/8. All pass affinity <= exp(-min(d^2,1)/128). Among these nine points the largest affinity is approximately 0.9979895826 at s=1,d=1/10. No finite-grid maximum is used as a general bound.

The soft envelope uses n=2,8,32; s=0,1/2,1; the lower endpoint, midpoint and upper endpoint of [ns/(n+1),(ns+1)/(n+1)]; and x=-1,-1/2,0,1/2,1. There are 135 points at each precision. Two nonnegative Fraction coefficients independently verify the algebra behind f_t-[n/(n+1)]f_s for arbitrary nonnegative h and phi. The actual kernel values and ratios are also evaluated. Zero reference densities (s=0 outside the hard core) are marked and no ratio is formed. Closed hard-face membership is explicit. A direct floating subtraction at a true equality may round through zero; the recorded nonnegative coefficient expression is used for the inequality, with a numerical residual check against direct subtraction.

The maximum observed 25/40 difference for affinity, midpoint mass or phi(1/2) is below 7.3e-27. The envelope comparison (densities, nonnegative differences and nonzero-reference ratios) has maximum difference about 2.17e-26. The script requires differences below 1e-18. These are empirical precision comparisons, not directed interval error bounds. The finite evaluations do not prove uniform constants or tensor consequences and do not simulate FULL.

Reproduce using Python 3 and existing mpmath 1.3.0, without installing dependencies:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 reciprocal_affinity_checks.py --output reciprocal_affinity_checks.json
```

Copy the script and task_contract.md together to relocate it. The JSON records the local contract using a filename hash key and records mpmath version and entry-file SHA. Standard import mpmath is used; the vendor path belongs only to the local execution command. A complete run took about 1.8 seconds. Runtime is printed rather than embedded in deterministic JSON. An isolated temporary-directory copy was run once and its complete output matched the work JSON byte-for-byte. Only the assigned R195 numerical files were written.
