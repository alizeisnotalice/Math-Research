# R195 独立审计

本文件独占维护，先读 task_contract.md、准确候选消息，未读本轮作者证明。无 Git/spawn/他人编辑，不重跑旧检查。一般原中间层目标仍未闭合。

## 1. 原 reciprocal 比率与实际 receiver 积分：独立筛查

在原 reciprocal bad 门内，w_g(y,u)>κ 且 κ/w_g<p_y/p_u<w_g/κ。因此 |log(p_y/p_u)|<log(1/κ)，并逐点有 p_y≤κ^(−1/2)√(p_y p_u)。方向正确：要上界 p_y 使用的是 p_y/p_u 的上界。可先保原 R 门应用此关系，再以 A,H≤1 正放宽；不能将其用于 R 外来源。这个比较没有 w_g(y,v) 的倒数，不能与 R194 y−v overlap 变量混同。

固定实际 sources y,u、固定共同 s,L 的 product 核给精确 receiver 恒等式

∫√(P_{s,L}(x−y)P_{s,L}(x−u))dx=∏_i Aff_s((y_i−u_i)/L)。

这里只张量化 x 核；β、ν 及 FULL/history 的 source 坐标无需且不能独立化。若父证明全 s∈[0,1] 的 Aff_s(d)≤exp[−c min(d²,1)]，由 L≤b 即得到 exp(−cD2)，D2=Σmin(|y_i−u_i|²/b²,1)。共同 f_s 的二阶矩为 1/12+s≤13/12，适合父级统一 characteristic-function 路线；本独审不重复其长证明，也不先认证未交付常数。

## 2. 从固定参数到原自适应选择须付的完整费用

共同 softness 可沿用正混合窗口：δ=1/(n+1)，t∈[(1−δ)s,(1−δ)s+δ] 时 f_t≥(1−δ)f_s，故同核双槽 G_t=√(P_t(y)P_t(u))≥(1−δ)^nG_s。由窗口长度 δ 可得 sup_sG_s≤e(n+1)∫_0^1G_tdt，覆盖 s=0/1，非 source 独立性。scale 单调量是 L^nG_L，a≤L≤b≤2a 的正 Stieltjes 包络需 1+nlog2；adaptive closed face 的跳不能以固定面零测为由删去。

固定原 (ω,V,j,y,t) 的 Γ+ 独立 x，质量≤L*W_A，L*=(n/4)T* 为原全窗口上界，完整参考 j/time 费不得再用 unique-j 免费删去。若上述 uniform fixed-parameter affinity 成立，实际 source-fixed D2≥d 子支应满足

Raw≤[32Λ/(3√κ)] L* e(n+1)(1+nlog2)e^(−cd)W_A。

几何指示 D2 用原 fixed b 和 source pair y/u，先于 x 积分。独立 window/source 重用仍沿原总账；没有把 Π 或 λ 换成自由 product。选择 d≥c^−1 log_+(L*e(n+1)(1+nlog2)/√n) 才是明确 root 支；若阈值>n，该示例为空，不等于一般覆盖。仅条件 affinity 或改名范数不得算全局进展。

## 3. 待后审与未付对象

等待父级 uniform affinity 完整证明及两作者准确几何/capture 候选。剩余 D2 小的 pair 不因 L1 位移或 R194 两支补集而自动取得价格；n 个小位移可相关累积。必须继续保原同 α、实际 K0、捕获资格/低核来源缺失、真实 dx、全部 window 与原历史。一般闭合、FULL 严格覆盖扩大均未认证。


## 4. 父级新 CDF 命题的独立筛查（未读其全文）

无需 characteristic function。f_s 偶，且在 |r|≤1/2 有 f_s(r)≥m0=φ(1/2)。两个相移概率在事件 (−∞,d/2] 上的差恰为 ∫_{−d/2}^{d/2}f_s≥m0 min(d,1)，故 TV≥该差，L1≥2该差。由 L1²≤8(1−aff)，得到 aff_s(d)≤1−(m0²/2)min(d²,1)≤exp[−c0 min(d²,1)]。w(r)≥(1/2)e^(−2r)（积分 a∈[1/2,1]）给 m0=∫_0^1w≥(1−e^(−2))/4≥1/8，因此 c0=1/128 安全，全部 s=0/1 边界均合法。这里概率是 receiver 的一维 kernel；来源没有独立化。

soft 窗 I_s=[ns/(n+1),(ns+1)/(n+1)] 内 f_t≥n/(n+1)f_s；双 product 的 G_t≥[n/(n+1)]^nG_s≥e^(−1)G_s，窗口长度1/(n+1)。故 §2 全参数费用成立。令 B_n=κ^(−1/2)L*e(n+1)(1+nlog2)，原 D2≥128log_+(B_n/√n) 子支付 (32Λ/3)√nW_A，外系数不重复进 B_n。L*=0/κ≥1 先零/空；若所需阈值>n 则几何支为空；门失败仅 D2 小，不能改说未截断 L1 或 infinity 位移小。待作者全文/整合绑定。


## 5. RL 全文与有限数值静态审

已实读 ratio_localization.md 全文。RL1–7 的 CDF/TV 常数、同一 soft-window 包络、scale 指数 n、原 reciprocal 门先用后放大、Γ+ Wβ≤W_A、B_n/r_n 与 K/L*=0/阈值>n 等分支均通过。紧 soft 参数与有限 product 的右连续性保 moving hardface；scale 费没有被少付。RL8 对余域只给截断平方和/有限坐标数及小坐标 L1 的 √n 损失，不控制例外坐标未截断位移，scope 正确。

已全文静态读 reciprocal_affinity_checks.py 与 numerical_review.md，包括新增 envelope 跨精度段。s=0 exact affinity/midmass、s>0 seam 分段、midpoint 硬质量 exact、Fraction 两个非负系数、zero reference density 先不除、同标签 25/40dps residual 检查一致。9 scalar affinity 与每精度 135 envelope 点被明确标为有限非区间诊断，不证明 FULL、uniform constant 或 tensor；本独审不运行。

## 6. 新 hard-shift 联合门独立筛查（未读全文）

两个 hard intervals 的对称差上，inside 点的 |r|≤1/2 而 shifted outside |r−d|>1/2，φ 差与 hard 差同号，故 |f_s(r)−f_s(r−d)|≥1−s。两密度≤1，所以 sqrt 差平方≥(1−s)²/4；对称差长度2min(|d|,1)，于是 1−Aff_s(d)≥(1−s)²min(|d|,1)/4。tensor 给 exp[−(1−s)²D1/4]，D1=Σmin(|yu|/b,1)。

原联合门 (1−s(x))²D1≥r≥1 中，每 fixed source D1≥r，允许 softness 为 s≤1−η_pair、η_pair=√(r/D1)。这是 source-fixed cutoff，正 Stieltjes 单调量 (1−s)^(−n)G 的费用≤1+(n/2)logn；scale 仍1+nlog2。令 B1=κ^(−1/2)L*[1+(n/2)logn](1+nlog2)，r1=max(1,4log_+(B1/√n)) 给 (32Λ/3)√nW_A 支，外系数不重算。D1=r 只有纯 hard helper s=0；原 strictsoft 该端支空，r1>n 也空。余域在实际 bad carrier 下 ||yu||1≤b max(1,Rn)r1/(1−s)²；middle softgap 的 polylog 下界才给 polylog 近，而非无条件 Euclidean/全源付款。

## 7. Sol 一次缺失 charge 候选独立筛查

固定 c，diag supply cA_mν 后保护量 Θ_c=Θ+cA_mν=min((c+1)A,1)ν≤χ；余供给 N_res=χ−Θ_c 与 diag 在预算意义相加不重复，但一般非互相奇异。把 residual A_d 按时间固定的互斥 target 片分解，source cells 互斥且每 cell 全时钟支配自己的 target，可用同一 c 组成共同计划。eligible 缺失 L=μ−1_Eν≥0、L≤μ−χ，有一次 kL≤αQJ。物理捕获率 b_i 给 N_res(C_i)≥b_i∫Ci wμ−∫Ci wΘ_c−b_i∫Ci wL；nominal 余量≥(c+ζ_i)m_i 而实际失败时，真实未来损失 d_i=(d_i/m_i)m_i 可一次 charge 到 ∫kL O。

逐 u Tonelli 的 O 保留实际相关性，指标/方案须 joint measurable 且沿 t 固定；m_i=0 先零。P_R=well ν_R/e 一般不是 subprob，仅为质量≤1/(2Kκ)的有限测度，已请作者修称谓。k>0 用原 strictsoft；α=0 时 kL=0 先隔离，不能写0×∞。有限 O 或具体 B 的物理预算才可代入，BαQJ/e 未有全局价，不能把条件性一次 charge 当一般 root。


## 8. HL 全文与派生脚本后审

已实读 hard_shift_localization.md 全文。HL1–6 的 strip 长度、同号 φ 差、1/4 affinity gap、source-fixed η_pair、正 Stieltjes 费、B1/r1 原 root 回代通过；D1=r/r1=n 在原 strictsoft 空、r1>n 空、s=1 不除0的范围完整。HL8 保留原 carrier，middle gap 才推出 O(log^(2+2a)) 完整 L1 距离，未将 exp(polylog n) 冒称 n^{o(1)}。与 RL7 的两份 root 价只可在不交顺序相加，不认证全覆盖。

已读 hard_shift_checks.py：用 exact Fraction 对称差分区检查 strip 长度，复用旧9个 numerical affinity 值时显式1e−20经验容差；3个 rational threshold 证书用 κ^(−1)≤3、logn≤ceil(log2 n)·7/10、T* 上界和 exp(−1)<3/8 安全放大 B1²，以 r=4k 判 root 平方成本。空/nonempty 仅算术资格，不是实际 FULL；未运行。

## 9. CC 全文后审与 target-test 新候选

已实读 capture_core.md 全文。CC3 保护后剩余供给、CC8–13 同一实际 L 的单次 charge、可数互斥 cell 匹配、CC19 逐 u Tonelli、CC22/23 常数正确。P_R 有限质量而非 subprob 与 α0 禁止0×∞已明确。nominal/order/物理捕获率仍是须认证的实际条件；CC22 首个 weighted receiver/source 积分未付，不登记新一般分支。

Astra 新 target-test 准确式独筛通过：a_n=1+γ^(−n)，a_n p_vA≤(ρ−A)J≤(1−A)J。原 high A>1−η 内 p_yA/√J≤η√J/a_n+A(p_y−p_v)_+/√J。对同一原 H 正测度用 Minkowski，Z_J≤T*Wβ（fixed(j,t)Π 独立 x，∫J=1后完整 j/time），原 E_J≤nWν/(2K)，故 additive 首项价为 (32Λ/3)(η/a_n)√(nT*/(2K))W_A。η≤a_n/√T* 才使此项 root；C_shift=∫H A²(p_y−p_v)_+²/J Π² 仍未付。fixed-parameter TV 或已付 y−u 近均不能免费控制该含1/J的平方项。等待该稿全文。


## 10. CG 全文与旧能量窄定位复核

已实读 core_geometry.md 全文。CG1 的 ρ−A 强式、primary gate ρ−A≤η（high A 只是充分）、同一 H 正测度下 Minkowski、Z_J 完整 T*Wβ、CG7 的 √WβWν≤W_A 与 K 系数正确；η 缩小仅支付首个 additive contribution，不支付 C_shift。CG9 的固定参数 translation BV 中 ac score 均值零、Var≤sLφ²、product receiver 交叉项零以及两 hardfaces 费用正确，CG10 被明确限制为 fixed-parameter first-power 结论。

为确认 CG6 仅使用已审接口，窄读 R173 冻结 mass_energy_audit.md §§2.1–2.2：原 eligible 时间先用 e_t≥e_g 去分母，再扩未归一 clock；high/FIRST、唯一 j 和固定 J 的 dx 归一给单后验 k_v² 能量，D_+²≤k_v² 后第二 Π 仅质量1。旧稿最后来源 Wβ 不成立的步骤已由 R181 修为 Wν；CG 明确只用 repaired Wν。CG 的 H 保留所需原 high/eligible/uniquej 资格，未将归一 posterior 扩时钟。

CG11 的实际 inverse-J 平方 receiver displacement、CG12 current容量≠posterior容量及 y−u≠y−v 均保留未付。父级当前 tex/report/driver 已窄核通过既有 RL/HL/CC 段；待加入 CG 最终段后只核一致性和最终字节绑定。总 driver 尚待 manifest，不提前声明运行；父已报告两个单脚本全 JSON bytes 重放一致，本独审不复跑。


## 11. 最终整合与冻结绑定

已复读最终 proof.tex.txt 的 CG 追加段、report.md 和 reproduce.py。CG 精确等号已实际限定在原 good target 槽；good 外只需对应不等式且 A=0。主 RL/HL 的真实 receiver/source 回代、两 root 价不交相加、CC 仅一次 reserve 接口、CG 首 additive 项有价而 C_shift 未付，均与详细稿一致。报告的9核例/每精度135点、派生复用9例+3有理门证书标签正确，阈值32/60/112及空支已与 JSON 静态核对。

父已报告两单脚本真实重跑且完整 JSON bytes 一致；本独审不重复运行。总 driver 仍待 manifest 后父级执行，没有在此提前认证。driver 先哈希再双脚本 fresh output、全 JSON 比较；派生脚本读取冻结 affinity JSON，而前一步已验证重跑 affinity 输出与其字节相同。未编译 PDF。

**严格通过范围：** 原 reciprocal 正 J-share 的全软度大 D2 来源支及实际 hard-weight·D1 联合门来源支，保全部参数选择、Γ+ j/time、共同父来源和窗口费用；同 α capture 缺失与 target-share 补偿按其明确接口通过。它们不改 source/α/Π/删除/原 q，不消费 signed 负信用。

**一般未付范围：** 两定位补集的 near-outer/bad、distant-target、high-A/late/tiny/low-tree 原联合核心；CC22 实际 kL 加权 receiver 占用和 CG11 inverse-J 平方 displacement 均未支付。polylog 距离不等于合格来源密度，不允许将 exp(polylog n) 免费称 n^{o(1)}。未认证一般弱型/all-mother 闭合或 FULL 严格覆盖扩大。

以下最终 SHA256 由字节实算；排除 audit.md 自身及未来 manifest，避免循环。审计现冻结停止。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `c9d8d93b8a0f957365520b692c2743df84542cfbb04bd77caa74952121ffcaec` |
| ratio_localization.md | `e37bfe501c319efbc55dc7737a5a94abfa770496b416be9b0620a5dd2cbfd5eb` |
| hard_shift_localization.md | `023dd9d75361f660b9be04b06e0a56b6bb069327d8744d7b0e443235b82fd20c` |
| capture_core.md | `3fb4522351bf8ca9604798aacd74ab30d6e3a2b2322000beb25acb99263019ba` |
| core_geometry.md | `e1fde137727a9e6c452949fff526354e171001a68ccb5421b86fed56ea1a65e4` |
| proof.tex.txt | `d16b90fd05349d67febba1f8d80456a8db45d5f21cb010d5356cc127a62989ab` |
| report.md | `edba8d1139e9ab60061e3b87cecf9f056d3a3a9b56f33a6f8873c0e6a0f67bb2` |
| reciprocal_affinity_checks.py | `c9743d288a6426deb55aa3f2a4f1c3a9e5181e63c11fe4da60a8cd08ea3196d1` |
| reciprocal_affinity_checks.json | `d75b8803dc98b143c0d56de62541c12654e77737db01762e7aaacb7397eb3548` |
| hard_shift_checks.py | `e9d3e1a7ec59b88941c8b45941f90761f1de95b38c6f98ff50cdbcc9f41c0c79` |
| hard_shift_checks.json | `2e4f7f7662d7253e78c7dd383d272abfcc1fdccea52e5545dbe8701e586f550d` |
| numerical_review.md | `21b11108f8ce7f252a8c023b5a1c1d9820f46bf583c72cdf09ec6b97cbe6d541` |
| reproduce.py | `a02fd870034a0d4ed13b260ff34239f07292a471ec3a5d7122cff698f6a98bcd` |
