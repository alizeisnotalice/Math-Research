#!/usr/bin/env python3
"""Finite exact strip/threshold arithmetic plus checks against existing numerical affinities."""
import argparse,json,hashlib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'hard_shift_checks.json');a=p.parse_args()
source=ROOT/'reciprocal_affinity_checks.json';d=json.loads(source.read_text());rows=[]
for row in d['affinity_cases']:
 s,shift=F(row['s']),abs(F(row['d']));ends=sorted({-F(1,2),F(1,2),shift-F(1,2),shift+F(1,2)})
 length=F(0)
 for l,r in zip(ends,ends[1:]):
  x=(l+r)/2
  if (abs(x)<F(1,2))!=(abs(x-shift)<F(1,2)):length+=r-l
 assert length==2*min(shift,1)
 upper=1-(1-s)**2*min(shift,1)/4
 checks=[]
 for run in row['runs']:
  observed=F(run['affinity']);tol=F(1,10**20)
  assert observed<=upper+tol
  checks.append({'dps':run['dps'],'approximate_affinity':run['affinity'],'passed_with_tolerance':'1e-20'})
 rows.append({'stage':row['stage'],'s':str(s),'d':str(shift),'exact_strip_length':str(length),'exact_affinity_upper':str(upper),'numerical_checks':checks})
cert=[]
for stage,n in [('initial',16),('stress',128),('expanded',4096)]:
 logn_upper=F(7,10)*(n-1).bit_length()
 lbar=F(n,4)*(F(7,10)+F(49*(n+1),400))
 bsq=3*lbar*lbar*(1+F(n,2)*logn_upper)**2*(1+F(7*n,10))**2
 k=1
 while bsq*F(3,8)**(2*k)>n:k+=1
 assert bsq*F(3,8)**(2*k)<=n
 if k>1:assert bsq*F(3,8)**(2*(k-1))>n
 cert.append({'stage':stage,'n':n,'B1_squared_upper':str(bsq),'k':k,'r_conservative':4*k,'strictsoft_gate_may_be_nonempty':4*k<n,'exact_cost_squared_upper':str(bsq*F(3,8)**(2*k))})
out={'schema':'r195-hard-shift-v1','input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'strip_cases':rows,'threshold_cases':cert,'status':'PASS','scope':['Exact Fraction symmetric-difference lengths and conservative source-threshold arithmetic.','Affinity values reused from two-precision quadrature; tolerance is not an interval certificate.','Threshold uses K=1, kappa>=1/3, log2<7/10, logn<=ceil(log2 n)*7/10 and exp(-1)<3/8.','No FULL realization, joint coverage or general core closure is inferred.']}
a.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'strip_cases':len(rows),'threshold_cases':cert,'status':'PASS'}))
