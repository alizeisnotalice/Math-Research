# R195: preserve actual joint geometry on the remaining core

Start main5bc4e19af8191c3567f7b5704fdecb012eb5c1a9, clean correct remote. R194 is verified progress, general goal still open. Frozen checkpoints /Users/zhengzhihao/Desktop/T/output/centered_cube_round19{1,2,3,4}_20261016_final_checkpoint.

Exact remaining core retains original positive traffic and all original current/FIRST, reciprocal, good, same alpha, actual capture, FULL/history, late/tiny/lowFtree masks, plus complements of R194 SD6 and GC14. SD geometry concerns y-v; GC concerns short u-v coordinates and current receiver hard faces. Neither complement implies the other. Do not rename this as a newly paid norm.

Primary target: use joint high-A capture, reciprocal p_y/p_u relation, source positions and real receiving measure to obtain sqrt(n) polylog W_A or an absorbable epsilon integral qdx on this core, with all n/scale/j/source fees retained. No source-coordinate independence, nu<=beta, replacement of h(P) by weighted eligible nu, or changing q within a window.

Parent investigates preserving reciprocal current ratios in a fixed-source receiver estimate (tilted product density and signed hard-face count jointly). Astra owns core_geometry.md for one concrete core-budget theorem, Sol high owns capture_core.md for an independent capture/space bridge needed by it, Sol high audit owns audit.md; numeric tasks only after precise candidates, reuse Sol medium. No child Git/spawn or edits to others; bounded deliverable, stop after delivery. Actual finite evidence must be identified as such, no claim all-input closure from a local example. No PDF compilation.
