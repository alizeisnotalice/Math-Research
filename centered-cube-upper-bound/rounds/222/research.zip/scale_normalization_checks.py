#!/usr/bin/env python3
"""Finite exact algebraic normalization checks, not actual-source realizability or root payment."""
import argparse,hashlib,json
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent

def rat(x):return f'{x.numerator}/{x.denominator}'
def frac_hash(x):
    # Hex integers are canonical and avoid Python's huge decimal-string limit.
    return hashlib.sha256((format(x.numerator,'x')+'/'+format(x.denominator,'x')).encode()).hexdigest()
def summary(x,small=False):
    out={'sha256_hex_numerator_slash_denominator':frac_hash(x),'numerator_bit_length':x.numerator.bit_length(),'denominator_bit_length':x.denominator.bit_length(),'positive':x>0}
    if small:out['exact_fraction']=rat(x)
    return out

def lambdas(n,t,name):
    eps=F(1,10000*n)
    return {'half':[F(1,2)],'one':[F(1)],'two':[F(2)],'mixed':[F(1,4),F(1),F(3,2),F(2)],'threshold':[1-eps,F(1),1+eps,t-eps,t,t+eps],'all_t':[t],'below_above':[F(1,2),F(2)]}[name]
def normalization(n,t,name):
    cycle=lambdas(n,t,name);counts=Counter(cycle[i%len(cycle)] for i in range(n));w=F(1);wt=F(1)
    for lam,count in counts.items():
        assert lam>0;w*=min(F(1),lam)**count;wt*=min(F(1),lam/t)**count
    lower_w=t**(-n)*w;ratio_squared=t**(-2*n)*w/wt;lower_ratio=t**(-2*n);upper_ratio=t**(-n)
    checks={'n_positive':n>=1,'t_range':1<=t<=1+F(1,n),'all_lambda_positive':all(x>0 for x in cycle),'t_minus_n_w_le_wt':lower_w<=wt,'wt_le_w':wt<=w,'ratio_squared_lower_bound':lower_ratio<=ratio_squared,'ratio_squared_upper_bound':ratio_squared<=upper_ratio,'ratio_squared_le_one':ratio_squared<=1}
    assert all(checks.values())
    recipe={'n':n,'t':rat(t),'cycle_name':name,'lambda_cycle':[rat(x) for x in cycle]};recipe_bytes=json.dumps(recipe,sort_keys=True,separators=(',',':')).encode()
    vals={'w':w,'w_t':wt,'t_minus_n_times_w':lower_w,'Kc_over_Kexact_squared':ratio_squared,'ratio_squared_lower_t_minus_2n':lower_ratio,'ratio_squared_upper_t_minus_n':upper_ratio,'ratio_squared_divided_by_upper':ratio_squared/upper_ratio}
    return {'recipe':recipe,'recipe_sha256':hashlib.sha256(recipe_bytes).hexdigest(),'lambda_multiplicities':[{'lambda':rat(x),'count':count} for x,count in sorted(counts.items())],'values':{k:summary(v,n<=16) for k,v in vals.items()},'checks':checks}

def real_scale(n,b,L,R,t):
    m=min(L,R);M=max(L,R);g2=L*R;a=t/M;c2=a*a*g2
    checks={'scale_ranges':b/2<=L<=b and b/2<=R<=b,'t_range':1<=t<=1+F(1,n),'t_squared_equals_c_squared_g_squared_over_m_squared':t*t==c2*g2/(m*m),'a_equals_c_over_g_squared_identity':a*a==c2/g2}
    ratio_base=a*R;ratio=ratio_base**n
    if R>=L:checks['original_prefactor_ratio_equals_t_power']=ratio==t**n
    else:checks['original_prefactor_ratio_equals_t_R_over_L_power']=ratio==(t*R/L)**n
    replacement_base=R/L;replacement=replacement_base**n;worst=(b/L)**n
    checks['replacement_le_b_over_L_power']=replacement<=worst
    if R==b:checks['replacement_equals_b_over_L_power']=replacement==worst
    if L==b/2 and R==b:checks['replacement_exact_two_to_n']=replacement==F(2)**n
    assert all(checks.values())
    vals={'b':b,'L':L,'R':R,'m':m,'M':M,'g_squared':g2,'t':t,'a_c_over_g':a,'c_squared':c2,'original_prefactor_ratio_base_aR':ratio_base,'replacement_ratio_base_R_over_L':replacement_base,'worst_replacement_base_b_over_L':b/L}
    return {'n':n,'branch':'R_ge_L' if R>=L else 'R_lt_L','rational_parameters':{k:rat(v) for k,v in vals.items()},'original_a_power_over_R_minus_n':summary(ratio,n<=16),'replace_R_minus_n_by_L_minus_n_factor':summary(replacement,n<=16),'worst_replacement_b_over_L_power':summary(worst,n<=16),'checks':checks,'cost_warning':'When R=b and L=b/2 the coarse replacement factor is exactly 2^n; a normalized envelope is not a root budget.'}

def scale_weight(n,cycle,multiplier):
    counts=Counter(cycle[i%len(cycle)] for i in range(n));value=F(1)
    for lam,count in counts.items():value*=min(F(1),lam*multiplier)**count
    return value

def settlement(n,L,R,t,q,pattern,scenario):
    gamma=1+F(1,n);m=min(L,R);cycle=lambdas(n,t,pattern)
    wm=scale_weight(n,cycle,F(1));wL=scale_weight(n,cycle,m/L);wg=scale_weight(n,cycle,1/t)
    Hcap=F(16,3)*q;fraction=F(0) if scenario=='H_zero' else F(1,2) if scenario=='mixed' else F(1);targetH=Hcap*fraction
    gates=(F(0),)*3 if scenario=='gate_zero' else (F(1,4),F(1,2),F(1)) if scenario=='mixed' else (F(1),)*3
    sources=[];H=F(0);G=F(0)
    for i,(strength,gate) in enumerate(zip((F(1),F(2),F(1)),gates)):
        if targetH:
            coord=(F(0),R/4,-R/4)[i];hard=R**(-n);mass=targetH*strength/4/hard
        else:
            coord=(R,2*R,-R)[i];hard=F(0);mass=strength
        assert (hard==R**(-n))==(abs(coord)<=R/2)
        weighted=hard*mass;H+=weighted;G+=weighted*gate
        sources.append({'source':i,'first_coordinate_z':rat(coord),'remaining_coordinates':'0 repeated n-1 times','hard_R_value':summary(hard,n<=16),'nu_mass':summary(mass,n<=16),'gate_aM_rho':rat(gate),'hR_times_nu':summary(weighted,n<=16)})
    sources.append({'source':3,'first_coordinate_z':rat(R),'remaining_coordinates':'0 repeated n-1 times','hard_R_value':summary(F(0),n<=16),'nu_mass':summary(F(1),n<=16),'gate_aM_rho':'1/1','hR_times_nu':summary(F(0),n<=16)})
    eta=G/H if H else F(0);left=G*G/(q*q*wg);right=F(16,3)**2*gamma**n*eta*eta/wL
    checks={'scale_ranges':F(1,2)<=L<=1 and F(1,2)<=R<=1,'t_range':1<=t<=gamma,'q_positive':q>0,'same_x_hard_source_realization':True,'H_le_16q_over_3':H<=Hcap,'gates_between_zero_and_one':all(0<=gate<=1 for gate in gates),'eta_range':0<=eta<=1,'H_zero_eta_zero_branch':H!=0 or eta==0,'gate_mass_equals_eta_H':G==eta*H,'wm_ge_wL':wm>=wL,'wg_ge_gamma_minus_n_wm':wg>=gamma**(-n)*wm,'inverse_weight_squared_bound':1/wg<=gamma**n/wL,'settlement_squared':left<=right}
    radius=None
    if R<=L:
        rv=2*R if R==L else (R+L)/2;S=min(L,rv);wS=scale_weight(n,cycle,m/S)
        assert rv>R>=F(1,2) and wm>=wS
        radius={'r_v':rat(rv),'min_L_rv':rat(S),'w_min_L_rv':summary(wS,n<=16),'r_v_gt_R_ge_a':True,'w_m_ge_w_min_L_rv':True}
    assert H==targetH and all(checks.values())
    recipe={'n':n,'L':rat(L),'R':rat(R),'t':rat(t),'q':rat(q),'pattern':pattern,'lambda_m_cycle':[rat(x) for x in cycle],'scenario':scenario,'x':'zero vector'}
    vals={'wbar_m':wm,'wbar_L':wL,'wg_wbar_tm':wg,'H':H,'Hcap':Hcap,'gate_mass_G':G,'eta':eta,'squared_left_G_over_q_sqrt_wg':left,'squared_right_16_over_3_gamma_half_eta_over_sqrt_wL':right,'squared_slack':right-left}
    return {'recipe':recipe,'recipe_sha256':hashlib.sha256(json.dumps(recipe,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'sources':sources,'values':{k:summary(v,n<=16) for k,v in vals.items()},'eta_exact':rat(eta),'H_zero_branch':H==0,'eta_zero_branch':eta==0,'checks':checks,'R_le_L_radius_check':radius,'scope':'Finite same-x hard-atom algebra simulation; gates and lambda weights do not certify actual joint geometry, histories, or posteriors.'}

def settlement_stages():
    stages=[]
    for name,ns,scales,ts,q,pattern in [('initial',(1,4),[(F(1,2),F(1)),(F(1),F(1,2))],('edge',),F(2,3),'mixed'),('boundary',(16,128),[(F(1),F(1)),(F(1),F(1,2))],('one','edge'),F(1),'half'),('expanded',(1000,10000),[(F(1,2),F(1)),(F(1),F(1,2))],('edge',),F(3,2),'threshold')]:
        rows=[settlement(n,L,R,F(1) if tk=='one' else 1+F(1,n),q,pattern,scenario) for n in ns for L,R in scales for tk in ts for scenario in ('H_zero','gate_zero','mixed','full')]
        stages.append({'stage':name,'case_count':len(rows),'cases':rows})
    return stages

def main(output):
    stages=[]
    menus=[('initial',(1,2,4,16),('one','half','two','mixed'),('one','halfway','edge')),('pressure',(3,8,64,128),('threshold','one','all_t','below_above'),('tiny','edge')),('expanded',(1000,10000),('threshold','half','one','two'),('one','halfway','edge'))]
    for stage,ns,patterns,ts in menus:
        rows=[]
        for n in ns:
          for tk in ts:
            t={'one':F(1),'halfway':1+F(1,2*n),'edge':1+F(1,n),'tiny':1+F(1,1000*n)}[tk]
            rows.extend(normalization(n,t,pattern) for pattern in patterns)
        stages.append({'stage':stage,'case_count':len(rows),'cases':rows});print(stage,len(rows),'exact cases passed',flush=True)
    real=[real_scale(n,b,b*l,b*r,t) for n in (1,4,128,10000) for b in (F(1),F(3,2)) for l,r in [(F(1,2),F(1)),(F(1),F(1,2)),(F(3,4),F(1)),(F(1),F(3,4)),(F(1),F(1))] for t in (F(1),1+F(1,2*n),1+F(1,n))]
    result={'schema':'R222_scale_normalization_exact_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Fraction and arbitrary-precision integers only; no floating point','normalization_definition':{'w':'product min(1,lambda_i)','w_t':'product min(1,lambda_i/t)','ratio_squared':'(K_c/K_exact)^2=t^(-2n)*w/w_t','squared_range':'t^(-2n)<=ratio_squared<=t^(-n)<=1','unsquared_range':'t^(-n)<=K_c/K_exact<=t^(-n/2)<=1','lambda_source_interpretation':'lambda_i=b*C_i/m; arbitrary positive algebraic lambda samples are not asserted to be realizable actual sources'},'normalization_stages':stages,'finite_hard_settlement_stages':settlement_stages(),'finite_hard_settlement_case_count':64,'hard_settlement_definition':{'H':'sum_z h_R(x-z)*nu_z','eta':'sum_z h_R(x-z)*nu_z*gate_z/H if H>0, else 0','weight_chain':'wbar_m>=wbar_L and wg=wbar_(tm)>=gamma^(-n)*wbar_m','settlement':'G/(q*sqrt(wg))<=(16/3)*gamma^(n/2)*eta/sqrt(wbar_L), checked after squaring','source_hard_geometry':'x=0; source first coordinates 0,+/-R/4 inside or +/-R outside; all remaining coordinates zero'},'normalization_case_count':sum(st['case_count'] for st in stages),'real_scale_case_count':len(real),'real_scale_cases':real,'large_value_encoding':'For n>16 only bit lengths and SHA256 of canonical lowercase hex numerator/denominator are stored; regenerate exact Fractions from recipes.','scope':['Finite exact algebra-domain verification, not independent certification of the universal lemma.','No arbitrary lambda array is claimed to arise from an actual source or original physical kernel.','Original prefactor remains a^n; when R>=L its ratio to R^(-n) is exactly t^n.','Coarse physical-scale replacement can cost (b/L)^n=2^n, so normalized envelope control is not a root payment.','No counterexample search, dimension-order fit, source budget, or global FULL closure.','Appended hard-settlement atoms realize h_R at the same x, but arbitrary gates and lambda recipes do not certify actual joint geometry or posterior/history constraints.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'scale_normalization_checks.json');args=ap.parse_args();main(args.output)
