# R222：原 aω 的 RN 定义、量纲与可用支配

**结论。** 原 `aω(x,y,z)` 是原实际联合软来源核相对于 `q^−1p_y(x)β_V(dy)` 的 Radon–Nikodym 密度，具有可选的联合可测版本 `0≤aω≤1`，量纲为1；不是一个未知、可能很大的外权。它保留原接受/历史门，不活跃行取零。此结论有直接原文和逐集合核支配两层证据，不依赖 `ν≤β`。因此原 SS7 的正上界可以直接去掉 aω，无需另付其上确界；同一固定物理状态下，R221 SS9 的胞合并也可用于原实际权 `aωMρ0`，因为它至多1。剩余问题是跨实际物理状态的共同占用、两后验与 δ/clock，不能继续把 aω 本身列为未认证权障碍。

## WC1 原文引用链与准确对象

只沿 R128 RT1 所继承的 R117/R116 规范交通及其 R112/R113 逐来源支配定位，没有重读无关历史。原外标量始终为共同 `q∈[3λ/4,λ]`，`p_y(x)=P_{s(x),L(x)}(x−y)`；测试核 `Q_x^*` 与它不同。

| 原文 | 直接内容及本稿用途 |
|---|---|
| [R128 proof.md:604–611](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604)，RT1 | `dT=1_I1_{j(x)=j} q^−1 p_y h_R(x−z) aω(x,y,z) dx β_V(dy)ν_V(dz)`。完整实际行包含原 history；β、hard ν 的标签不互换。 |
| [R128 proof.md:647–650](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:647) | 固定 `(ω,V,j,y,t)` 后原 Π、e_t、Z_t、w_t 独立 x 和 hard z；当前尺度、history 等仍依 x。此冻结不改变 a 的定义。 |
| [R117 joint_geometry.md:47–54](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:47)，JG5 | 明文“把原所有门合在原 RN 因子 aω∈[0,1] 中”；所估是同一 R116 高 pe 交通，保 FULL/FIRST/CP/GP/deep、失败币、种子及新旧删除门；不把任意 a 当新的 FULL 实例。 |
| [R116 astra_first.md:141–148](/Users/zhengzhihao/Desktop/T/output/centered_cube_round116_20261014/astra_first.md:141)，F16 后 | 明文给规范 RN 表示 `q^−1p h_R aω dxβν`、`0≤aω≤1`、“完整联合门均保留在 aω 内，不活跃行取零”。这是最短直接定义证据。 |
| [R112 proof.tex.txt:520–535](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:520)，J2–3 | 实际软核 Γ 保原联合历史，逐 x,z,ω,V、逐软来源集合满足 `Γ(dy)≤q^−1p_y(x)α_V(dy)`。不是只给 Γ 总质量上帽。 |
| [R113 proof.tex.txt:48–66](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:48)，B3–4 | 软提取删除后的实际核满足 `Γ^{bi,ov}(dy)≤q^−1p_y(x)β_V(dy)`；这里 β 是该实际软余源，不是 ν。 |
| [R113 proof.tex.txt:578–603](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:578)，I1–2 | 若采用后附耦合软流，必须同步使用它自己的 β^c 与实际 Γ_F^c。相同逐集合支配随这一新构造成立；不能把旧任意流和新 β^c 混合。下文对两版本都只用它们各自的 Γ≤q^−1pβ，不使用 ν≤β。 |
| [R114 ratio_settlement.md:9](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:9) | 进入 R116 前的实际核 Γ_F^c 仍由 `q^−1P_{s,L}(x−y)β_V(dy)` 支配。比例/新正门只进一步限制该核。 |

本轮不需要恢复并重写 a 的每个原始历史因子的乘积：逐集合实际核支配及规范 RN 身份已经唯一确定它在基准测度下的等价类。a 可以包含历史积分后的条件接受概率，因此不要求它仅取0、1，也不能把它分解成独立软、硬两个权。

## WC2 自足 RN 推导及量纲

固定原 ω,V 和实际 x,z，设 `Γ_{x,z,ω,V}(dy)` 为同一原联合历史积分后的当前软来源子测度核，令

\[
 m_{x,\omega,V}(dy)=\frac{p_y(x)}q\,\beta_V(dy).
\]

原逐集合支配是 `0≤Γ≤m`。因此 RN 定理给

\[
 \Gamma_{x,z,\omega,V}(dy)=a_\omega(x,y,z)\,m_{x,\omega,V}(dy),
 \qquad0\le a_\omega\le1\quad m\text{-a.e.} \tag{WC1}
\]

在原有限截断/标准 Borel 可测核框架中，可取联合可测的核 RN 密度；也可直接对整个非负外测度相对其支配测度取 RN 密度，再分解。把该版本截到 [0,1]、在不活跃行及未定义零基准处取0，不改变实际交通，便有处处有界的代表。逐集合支配不是由“总质量≤1”推出来的，方向不能反转。

若 `[length]=l`、`[mass]=m`，则 `p,h_R` 的量纲为 `l^−n`，`q` 为 `m l^−n`，`β,ν` 为 m。故 `m_{x,ω,V}` 与 Γ 都是无量纲子概率，a 无量纲；而

\[
 \frac1q p_y h_R a_\omega\,dx\,\beta_V(dy)\nu_V(dz)
\]

量纲为 m，正是原交通质量。a 不含额外 q、体积或来源质量分母；外 `2Λ` 和两份 Π 的归一化也不藏在 a 里。

WC1 在严格 soft>0 时没有 p 的零点问题；即便研究边界 s=0，支配仍迫使 Γ 在 p=0 处为零，按上述零版本处理即可。不以该边界模型解除原 strictsoft 门。

## WC3 真正可用的边际与 FIRST 的作用

原 β 是预冻结的真实软子源，`β_V≤f dx`；hard `ν_V≤f dx`。这两条分别使用，不推 ν≤β。共同 FIRST 在实际 x 给 `∫p_y(x)β_V(dy)≤q`。由 WC1，对每个实际 x,z，

\[
 \int a_\omega(x,y,z)\frac{p_y(x)}q\,\beta_V(dy)
 =\Gamma_{x,z,\omega,V}(\mathbb R^n)\le1. \tag{WC2}
\]

它是保历史的软端子概率；不声称为1，不把归一化后的条件源重新作 FIRST 输入。去掉 a 后仍有相同的上帽，因为使用的是原完整输入的同一合法 current 核。

对每个实际 x,y，原 hard band 与 `q≥3λ/4` 又给

\[
 \frac1q\int a_\omega(x,y,z)h_{R(x)}(x-z)\nu_V(dz)
 \le\frac1q(h_{R(x)}*f)(x)\le\frac{16}{3}. \tag{WC3}
\]

此式直接付硬来源，且不需要 a 对 z 常量。两边际方向都由 a≤1 及各自原来源上帽得到；它们不使两端独立。仅写 `∫a dβ` 或 `∫a dν`，没有 p/q 或 h_R/q，不能声称是概率或统一常数。

对原正行的实际 receiver 密度，先用 WC2 再积 hard 来源，亦有

\[
 r(x)=\int h_{R(x)}(x-z)\nu_V(dz)
          \int a_\omega(x,y,z)\frac{p_y(x)}q\beta_V(dy)
 \le(h_{R(x)}*f)(x)\le4\lambda. \tag{WC4}
\]

唯一叶和原接收域仍保留。这只是原 `T_small≤4X` 一类总量上帽，不是根阶来源列。

对固定的实际 x,z，`aω(x,·,z)β_V` 是 β_V 的子测度，故同一实际行全部合法 future 核响应仍≤q；固定 x,y 时，`aω(x,y,·)ν_V` 也同理。它们一般依 x 和另一来源标签，不能移出 receiver 积分当成一份新的预冻结来源；归一化后更不能继承 q。原 FIRST 的等式资格只属于原完整输入，不被 a 删除或重建。

## WC4 对 R221 SS7/9 的直接修订

R221 SS7 是

\[
\begin{aligned}
 \mathfrak J_a={}&\mathbb E\sum_{V,j}\int
 \delta_t(v,u)\,\beta_V(dy)\nu_V(dz)\Pi_t(dv)\Pi_t(du)\frac{dt}{t}\\
 &\quad\times\int\frac{a_\omega}q M\rho_0(v)
 \frac{h_{R(x)}(x-z)\sqrt{p_y(x)K_a(x-v)}}{\sqrt{w_{g(x)}(y,v)}}\,dx.
\end{aligned} \tag{WC5}
\]

所有因子非负。因此 **在全部原自适应状态上**，可直接把 aω 换成1得到合法上界，而保其余 M、ρ0、两份 Π、δ、来源测度、真实 dx 与时间窗。此步无需先固定 L,R，也不买 a 的 sup/积分费用。若 hardband/actual 接收域原编码在 a 中，则 a→1 后调用 WC3、WC4 或 SL1 时仍须显式保留原接收域 E 或其指示；不得先扩大 x 域，再对新增接收点授予原 hardband 上帽。它可能丢失原门带来的有益抑制，但不是未授权的权放大问题；所得上界不被宣称为另一份 FULL 交通。

进一步固定一个真正的物理状态 θ（不能先对原连续选择器免费条件化），令 R221 SS9 的子概率核为

\[
 d\mathcal K_{\theta;y,v,z}(x)
 =\frac{1_{\{B(v)=0\}}h_R(x-z)\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)}}
 {(c_j/g)^n\sqrt{w_g(y,v)}}\,dx.
\]

其总质量由 R220/SS3 不超过
`Λθ(y,v,z)=min(1,sqrt(w_g(y,z)w_g(v,z)/w_g(y,v)))≤1`。原 capture `ρ0≤1_{B=0}`、`0≤M≤1`，所以对任意有限/可数不交接收胞 U_i，

\[
 \sum_i\int_{U_i}a_\omega M\rho_0\,d\mathcal K_\theta
 \le\sum_i\mathcal K_\theta(U_i)
 =\mathcal K_\theta(\cup_iU_i)
 \le\Lambda_\theta(y,v,z). \tag{WC6}
\]

在 B=0 的核中重复保ρ仅是更小的正权，未改变捕获资格。若从原未带 B 的核开始，则先用 `aMρ≤1_{B=0}`，得到相同结论。该界明确消除了 R221 SS10/SS12 中 **a 本身可能无统一上界** 的疑虑；固定状态胞合计不另买 a 的价格。R221 SS9 的“未假定 a≤1”是该稿保守的证据状态，不是原定义缺少此支配。R116/JG5 原文现已恢复。

原 SS11 的小胞来源价也可直接使用：固定合法尺度及真实 hardband 锚点 x0，`U⊂Q_ell(x0)`、`R+ell≤b`、`ell≤κR/n` 时，aMρ 不增加 `(16/3)e^(1+κ)` 的价格；若只对共同 soft 核取上确界，仍付真实 `4|S_n|`。端点 R=b 的正胞缺口不被 a≤1 消除，须沿原已证有价边界接口处理。

## WC5 本次已消除的权费用与仍保留的条件

本次消除的是一个真实而可核验的证据缺口：原 aω 有无量纲 [0,1] 版本，WC2/3 为它的合法边际；在 SS7 正上界和固定状态 SS9 合计中不必再为 a 立未知费用。原两来源关系、FIRST 和来源总质量均未改写。

仍须保留：

* SS7 的实际物理 L/R/s/g 与 history 随 x 变化。对不同 θ_i 的不同核，WC6 不给 `Σ_i K_θi(U_i)≤1`；没有免费跨尺度包络。
* 两份 Π 已含两个 e_t 分母，只在固定原 `(ω,V,j,y,t)` 后独立 x,z。它们一般依 y，不能把 WC2 与整个带 Π/δ 的 y 积分随意相乘，也不能按来源坐标独立化。
* WC3 消 hard z 是一条正上放，可与保 z 的几何路线选用；对同量不能另领一次16/3。不得将 hard z 换为辅助 v/u 或限制 Z_g。
* 去掉正项的 a 不允许去掉反向、删除、suffix 或边界费用。signed 母账中负项的原 a 与原资格按原定义保持，所有负信用只消费一次；R218 已付带不重领。

故 a 不是新增未知障碍；跨实际尺度、共同来源占用与原正 score 交通仍是所需结算。本文不以 a→1 的上界改变原 actual/FIRST 身份，也不声称该放松后的无门包络本身具有根阶界。

本机实际用 Python Fraction 对8组非负有限核/权矩阵核对 WC1 的重构与 WC2/3 的两边际上放方向；这只检查代数实现，测度结论由上述逐集合支配与自足证明承担，不是原 FULL/history 数值模拟。
