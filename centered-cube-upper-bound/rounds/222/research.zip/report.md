# 第222轮：实际硬来源与可变半径的统一结算

目标仍为一般中心立方体弱型 n^(1/2+o(1)) 上界，未闭合。本轮直接处理原正交通里的硬来源及R(x)，不以固定尺度或单胞覆盖替代全域接口。

## 已核推导

恢复原aω的规范Radon–Nikodym身份：同一原软核逐集合受q^-1pβ支配，故0≤aω≤1且无量纲。R221未使用该上界是证据状态，不是原权需要新费用。删a时仍保原接收域E，不能在扩域后重用hardband。

令m=min(L,R)、M=max(L,R)、t0=cjg/m∈[1,γ]及wbar_r=∏min(1,bC/r)，则wg=wbar_t0m≥γ^-n wbar_m≥γ^-n wbar_L。实际同一x的R对所有hardz共同，定义H=∫hRν及η=∫hR aMρν/H（H=0时η=0）。原hardband给H/q≤16/3，故每腿外hard来源积分由(16/3)√e η sqrt(pK)/√wbar_L支配。这覆盖全部实际连续R，包括R=b；无R菜单、无sup hR或全ν/q替代。原clock/过程支持指示明确保在η内，两份Π和score不动。

R≤L还保r_v=2||x−v||∞>R≥a的hard排除，分母可增强为sqrt(wbar_min(L,r_v))。两分支不重计。完整P回代保2Λ√(K/3)、三腿、β、两Π、δ及dt/t。

辅助几何：exact-min归一核和原归一核之比介于t0^-n与t0^-n/2。R≥L的exact归一核随R嵌套，其积分内sup无R费；但恢复未归一核时R^-n不能丢，粗替换可能付2^n。实际source结算在同x先积分，避免这一体积放大。

## 尚未证明

新的统一hard-source接口不等于原正剩余已有根阶付款。L/soft选择、wbar_L的几何分母、依y的两后验、正score/clock及全部标签的联合预算仍无root界。η虽≤1，但删掉可能丢high/capture/history所需抑制。R221保hardz位置的路线仍可与本轮接口择优结合，不能两次领16/3。原负信用和已付浮动带均保持。

## 本机验证与复现

scale_normalization_checks.py仅Python标准库，104归一化、120尺度关系、64有限hard-atom模型全部用Fraction/整数。n至10000；H0共16例，η0共32例。大有理数用可复现配方和规范哈希记录。有限原子只核代数，不模拟原正L1输入的全部几何和历史，也不认证一般上界。主代理实际运行并cmp全JSON一致；最终冻结后由reproduce.py迁移运行与manifest前后校验。

使用64项工具M03的严格适用边界：读取SKILL、方法、课题接口及来源索引开头；没有获得或援引通用近极值稳定性定理，未把索引论文当已读。近极值到几何结构的定量界仍须实证。扣额数据不可获得，不猜模型成本。本轮复用Astra主推、Sol辅助/独审/计算，任务完成停等。

详细LaTeX与独审保存，不编译PDF。解压后python3 reproduce.py --verify-only；全复现python3 reproduce.py --output-dir <新的包外目录>。
