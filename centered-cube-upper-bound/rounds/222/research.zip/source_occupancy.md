# R222：真实全域硬来源结算与无额外 R 菜单的上界

本稿证明一个直接适用于原全局正交通的有价支配：保持同一实际接收点的 $R(x)$ 对全部硬来源共同，先积分该硬来源，再比较原比例带权，可用固定因子 $(16/3)\sqrt e$ 支付显式硬来源密度及 $R$ 核选择。此结论允许全部实际自适应 $L,R,s$，覆盖 $R=b$，不需要小胞、胞数或物理 $R$ 菜单。原 $R,g$、时钟及历史仍准确留在条件平均内；剩余双后验、正变差与 $L$/soft 接收费用没有被宣布付款。

## 1. 原权与明确候选

采用 R221 SS2/SS7 的同一个原剩余。外分母是共同 $q\in[3\lambda/4,\lambda]$，不是 $Q_x^*$。原来源满足 $\nu_V\le f$。本轮 `weight_contract.md` 已恢复原规范 RN 权 $0\le a_\omega\le1$（R116 `astra_first.md:147`、R117 `joint_geometry.md:47–54`），所以这里不另付未知的 $a_\omega$ 上确界。

把原允许接收点的 hardband 明写为 $E$；在 $E$ 上，实际尺度 $R(x)\in[a,b]$ 满足

\[
H_R(x):=\int h_{R(x)}(x-z)\,\nu_V(dz)
\le(h_{R(x)}*f)(x)\le4\lambda\le\frac{16}{3}q.
\tag{SOCC1}
\]

若 hardband 原先编码在 $a_\omega$ 或原截断门内，这里先写成显式 $1_E$，因为原正量在其外为零；不向不合法接收点外推 SOCC1。

对每个实际 $x$，设 $m(x)=\min(L(x),R(x))$、$g(x)=\sqrt{L(x)R(x)}$。定义物理尺度形式的共同来源权

\[
\bar w_r(y,v)=\prod_{i=1}^n\min\left\{1,\frac{bC(|y_i-v_i|/b)}r\right\},\qquad r>0.
\tag{SOCC2}
\]

于是原 $w_g(y,v)=\bar w_{c_jg}(y,v)$，而实际唯一比例带给

\[
m\le c_jg\le\gamma m,\qquad\gamma=1+1/n.
\tag{SOCC3}
\]

准确候选是：在保原全部门的真实硬来源积分中，将 $q^{-1}h_R\nu$ 以 SOCC1 结算，并将 $w_g^{-1/2}$ 比较到只含 $L$ 的 $\bar w_L^{-1/2}$；在 $R\le L$ 支进一步利用原 $B=0$ 缩小这个比较尺度。下面证明该候选，无需冻结实际物理参数。

## 2. 先定义真实硬来源条件平均

先固定 $(\omega,V,j,y,t)$，再固定辅助来源 $v,u$ 与接收点 $x$。原 $\Pi_t$、$\delta_t(v,u)=(k_t(v)-k_t(u))_+$ 独立硬来源 $z$；实际 $p_y(x)$、$K_a(x-v)$、$R(x)$、$g(x)$ 也不依赖这个硬来源积分变量。它们仍可依赖 $x$，此处没有将其冻结到全空间积分之外。

将原 $1_{\{j(x)=j\}}$、$1_{\{t\in J_{far}(x,y)\}}$、high、good×bad、mixed、FA、后缀、history、当前浮动带外及原截断统一明写在 $M$ 内。令

\[
\eta(x,y,v,u,t)=
\begin{cases}
\displaystyle\frac{\int h_R(x-z)a_\omega(x,y,z)M(x,y,z,v,u,t)\rho_0(v)\,\nu_V(dz)}{H_R(x)},&x\in E,\ H_R(x)>0,\\[6pt]
0,&\text{其他情形}.
\end{cases}
\tag{SOCC4}
\]

若 $\rho_0$ 还通过完整原历史依赖 $z$，就在该积分内按原值保留；公式不将其冻结为别的权。因为 $0\le a_\omega,M,\rho_0\le1$，有 $0\le\eta\le1$。这是原硬来源后验下的真实条件平均，未用新的自由选择器替代原历史。

当 $H_R=0$ 时，非负积分及有界权使 SOCC4 的原分子也为零，因此零分支严格等于原硬来源贡献，不发生除零。原唯一 $j$ 与真实时钟资格仍由 $\eta$ 保留，不能删去后再把多比例带、多时间窗当成一次。

分成互斥两支

\[
\eta_+=1_{\{R>L\}}\eta,\qquad
\eta_-=1_{\{R\le L\}}\eta,\qquad
\eta_++\eta_-=\eta\le1.
\tag{SOCC5}
\]

$R=L$ 只归入负下标支，不重复计费。

## 3. 权比较与原硬捕获的改进

对任意 $\xi>0$、$r>0$、$1\le\zeta\le\gamma$，

\[
\min(1,\xi/(\zeta r))\ge\gamma^{-1}\min(1,\xi/r).
\]

逐坐标相乘，用 SOCC3 和 $m\le L$，得到

\[
w_g=\bar w_{c_jg}\ge\gamma^{-n}\bar w_m\ge\gamma^{-n}\bar w_L.
\tag{SOCC6}
\]

因此 $w_g^{-1/2}\le\gamma^{n/2}\bar w_L^{-1/2}$，其中 $\gamma^{n/2}\le\sqrt e$。全部有限来源位移上 $C>0$，所以这里的倒数合法。

在 $R\le L$ 支，原硬门准确为 $B(v)=1_{Q_R(x)}(v)$，闭核心上 $\rho_0=0$。令

\[
r_v(x)=2\|x-v\|_\infty.
\]

于是 $\eta_->0$ 必须有 $r_v(x)>R(x)\ge a$。在这部分 $m=R$，并且

\[
R\le\min\{L,r_v(x)\}.
\]

由 $r\mapsto\bar w_r$ 非增，SOCC6 可加强为

\[
\eta_-w_g^{-1/2}
\le\gamma^{n/2}\eta_-
\frac{1_{\{r_v>a\}}}{\sqrt{\bar w_{\min(L,r_v)}(y,v)}}.
\tag{SOCC7}
\]

右侧在 $r_v\le a$ 时定义为零，不在该支求任何零尺度权。该式保原 $Q_R(v)$ 排除的真实收益；没有假设排除整个 $Q_L(v)$。在 $R>L$ 支只使用

\[
\eta_+w_g^{-1/2}\le\gamma^{n/2}\eta_+\bar w_L^{-1/2}.
\tag{SOCC8}
\]

## 4. 无需固定状态的全域来源支配

对每一条实际目标腿 $K_a$，因为 $\sqrt{p_yK_a}/\sqrt{w_g}$ 独立硬来源 $z$，SOCC4 给精确恒等式

\[
\begin{split}
&\frac1q\int h_R(x-z)a_\omega M\rho_0
\frac{\sqrt{p_y(x)K_a(x-v)}}{\sqrt{w_g(y,v)}}\,\nu_V(dz)\\
&\qquad=\frac{H_R(x)}q\eta(x,y,v,u,t)
\frac{\sqrt{p_y(x)K_a(x-v)}}{\sqrt{w_g(y,v)}}.
\end{split}
\tag{SOCC9}
\]

对右侧只用一次 SOCC1，再用 SOCC7–8，得到真实逐点上界

\[
\boxed{\quad
\text{SOCC9 左侧}\le\frac{16}{3}\gamma^{n/2}
\sqrt{p_y(x)K_a(x-v)}\left[
\frac{\eta_+}{\sqrt{\bar w_L(y,v)}}+
\frac{\eta_-1_{\{r_v>a\}}}{\sqrt{\bar w_{\min(L,r_v)}(y,v)}}
\right].\quad}
\tag{SOCC10}
\]

这是对实际 $x$、实际 $L(x),R(x),s(x)$ 的支配。先积同一个实际 $R(x)$ 下的全硬来源，再用原 hardband；没有把 $\int\sup_R h_R\,d\nu$ 当成 $\sup_R\int h_R\,d\nu$。因此没有产生硬径向最大核通常携带的线性 $n$ 费用，也没有 $\|\nu_V\|/q$ 或接收胞数。

记括号为 $\mathcal B(x,y,v,u,t)$。原 good 转半密度已证

\[
P\le2\Lambda\sqrt{K/3}\sum_{a=1}^3\mathfrak J_a.
\]

将 SOCC10 代入完整 SS7，并仅作非负 Tonelli，得到本稿全域定理

\[
\boxed{\begin{split}
P\le{}&\frac{32\Lambda}{3}\sqrt{K/3}\,\gamma^{n/2}
\sum_{a=1}^3\mathbb E\sum_{V,j}\int
\delta_t(v,u)\,\beta_V(dy)\Pi_t(dv)\Pi_t(du)\frac{dt}{t}\\
&\hspace{28mm}\times\int_E
\sqrt{p_y(x)K_a(x-v)}\,
\mathcal B(x,y,v,u,t)\,dx.
\end{split}}
\tag{SOCC11}
\]

可将唯一显式维数因子 $\gamma^{n/2}$ 换成 $\sqrt e$。三腿之和仍在式内，不另暗乘或少乘一个三。实际时间资格与唯一比例带在 $\eta$ 中保留；也可将 $dt/t$ 的外积分理解为原公共允许域并将 $\eta$ 在不合资格处置零。

SOCC11 没有要求 $L,R,s$ 是有限状态，覆盖整个原尺度窗与端点 $R=b$。原 $R,g$ 仍会改变 $\eta$ 中的 terminal/capture/history/clock 资格，但 $0\le\eta\le1$ 是已证真实权界；其变化不需要为显式硬来源密度再付菜单费。不能把这句话解读为原时钟或捕获交通已结算。

## 5. 已支付的结构与尚未支付的联合项

SOCC11 确实付掉了：全硬来源 $\nu_V(dz)$ 的显式密度、其共同 $q$ 归一化，以及从实际 $R$ 和 $c_jg$ 比较到位置尺度权的费用，价格是一次 $(16/3)\gamma^{n/2}\le(16/3)\sqrt e$。它在原 $dx$ 积分之前成立，因此既不需要单胞常数求和，也不需要未知的全局占用常数。只用了原 hardband 和原 RN 权界，不用了 $\nu\le\beta$、$z\in Z_g$ 或 $\bar e_g=e_g$。

另一方面，SOCC11 仍准确保留：

- $\beta_V(dy)$ 与依赖同一个 $y$ 的两份 $\Pi_t$；不能用 FIRST 把它们拆成独立积分。
- 原 $\delta_t=(k_t(v)-k_t(u))_+$、bad 端及其它历史通过 $\eta$ 的共同限制；没有假定每行 variance 为根阶。
- 接收点依赖的 $L,s$，三腿核与位置相关的 $\bar w_L$、$\bar w_{\min(L,r_v)}$。固定参数的核归一化不等于这些真实自适应半密度的积分归一化。
- 原时钟范围、唯一 $j$、capture 和当前浮动带之外的资格。$\eta_++\eta_-\le1$ 是逐点事实；如果删掉 $\eta$，必须另外保留或结算它承载的比例带与时钟重数。

本次来源结算已经使用一次 hardband 帽 $16/3$。剩余表达式不再有原硬核 $h_R$；不能对它再套一次 R220 的共同硬核定理而声称其假设仍在，也不能重复领取同一 hard 来源信用。R220 的共同核/min 三来源路线仍可作为保留硬来源的另一支上界，但必须先在真实原对象上组织比较。

最早未付的具体对象现在是 SOCC11 右侧的双后验加权半密度积分，而不是原硬来源密度或每胞的局部质量。要得到最终 $\varepsilon X+C_\varepsilon\sqrt n\,\mathrm{polylog}(n)W_A$，需要把这里的实际 $\delta_t$、$\eta$、$L$/soft 选择及来源列共同结算。本稿没有把该联合项换成一个假定有界的 $C_*$，也没有宣布原剩余已获根阶付款。已付浮动带与负信用均保持原账。

## 6. 实际本机核对与交付范围

实际运行本机 Python `fractions.Fraction`：$n\in\{1,2,4,8\}$，$m\in\{1/2,3/4,1\}$，$\zeta\in\{1,1+1/n\}$，坐标正数 $\xi_i=(i+1)/(n+2)$，比较尺度 $\ell\in\{m,1\}$。逐项验证

\[
\bar w_{\zeta m}\ge\gamma^{-n}\bar w_m,\qquad
\bar w_m\ge\bar w_\ell,\qquad
1/\bar w_{\zeta m}\le\gamma^n/\bar w_\ell.
\]

48个有理比较全部通过。这里只检查权比较代数，不把该有限菜单当作原来源模型或全局交通证书；一般证明是第三节的逐坐标不等式。

交付结论：SOCC11 是实际全域、明确常数的硬来源结算，包含原全部状态与 $R=b$，避免额外 $R$ 核菜单费用。原完整正剩余的根阶预算仍未闭合。
