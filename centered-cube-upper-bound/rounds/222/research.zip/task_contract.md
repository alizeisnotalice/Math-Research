# R222：跨实际尺度的共同来源占用

前轮已完成并远端验证：1da050f2a8725e57a869b4dabe80ada217253f40；本轮起始工作区干净。目标仍一般n^(1/2+o(1))弱型，不以单胞定理结束总体目标。

固定上下文：R221最终checkpoint为/Users/zhengzhihao/Desktop/T/output/centered_cube_round221_20261016_final_checkpoint。优先读source_settlement.md SS2/7/9/12和proof.tex.txt，勿通读全史。原外分母共同q∈[3λ/4,λ]，Q_x^*另为三腿核。一般实际L,R∈[a,b],b≤2a，g²=LR，cjg/γ≤min(L,R)≤cjg，γ=1+1/n。R220固定参数共同核积分归一≤1，结合旧分离界可保min(1,√(wyz wvz/wyv))。原hardband在真实锚点对所有B∈[a,b]给ν(Q_B)≤(16/3)qB^n。R221小胞ell≤κR/n且R+ell≤b真实source价≤(16/3)e^(1+κ)，R=b不被其正胞覆盖；J提供指数备选但非root。同一固定核下有限/可数不交胞先合并实际积分不付胞数；跨参数不自动有此性质。

原P≤2Λ√(K/3)Σa J_a，J_a的完整aω、M、ρ0、δt、β(dy)ν(dz)Πt(dv)Πt(du)dt/t dx必须保留；Πt在固定ω,V,j,y,t后独立x,z，实际L/R/s/g等仍依x。原aω不凭名字假定≤1。不可ν≤β、hardz限Zg或全ν权换原eg。strictsoft s>1−2^(−1/n)，浮动带外条件ρ0(wt−h0)>L0J/p，L0=K√n；已付浮动带不重领，负账一次。

本轮唯一主瓶颈：对真实跨物理尺度共同来源占用寻找可证明的新上界，与两后验交通耦合支付；不重复未知C*桥、不反复造强反例、不只重写余项。允许先推出真正可用的尺度包络/原权结构，但所有费用显式，不能算已闭合。

责任：peak/Astra源几何主推source_occupancy.md；compare/Sol恢复aω真实定义/量纲与可用支配weight_contract.md；audit/Sol先独立审主命题再读作者audit.md；numeric/Sol仅在准确候选后启动。你们并非独占代码库，不覆盖他人文件。不得自行扩展/spawn/Git/PDF。交付准确命题、证明、费用与最早未付步骤；完成停等。
