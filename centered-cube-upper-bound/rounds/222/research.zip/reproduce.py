#!/usr/bin/env python3
"""Verify archive hashes; replay a copied driver outside this package."""
import argparse, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    for name, expected in manifest.items():
        assert digest(ROOT/name)==expected, name
    return len(manifest)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args()
    count=verify()
    if args.verify_only:
        print('verified',count,'manifest hashes');return
    if args.output_dir is None: ap.error('--output-dir is required for replay')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents: ap.error('output must be outside the package')
    out.mkdir(parents=True,exist_ok=False)
    script=out/'scale_normalization_checks.py';shutil.copyfile(ROOT/script.name,script)
    result=out/'scale_normalization_checks.json';start=time.monotonic()
    subprocess.run([sys.executable,str(script),'--output',str(result)],check=True)
    elapsed=time.monotonic()-start
    assert result.read_bytes()==(ROOT/result.name).read_bytes(), 'complete JSON differs'
    assert verify()==count
    receipt={'manifest_hashes_before_and_after':count,'complete_json_byte_identical':True,'output_sha256':digest(result),'relocated_script_sha256':digest(script),'elapsed_seconds':elapsed,'python':sys.executable}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
