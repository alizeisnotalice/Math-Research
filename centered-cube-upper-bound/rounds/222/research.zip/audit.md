# R222 独立审查

## 作者稿前：准确原目标与尺度取整

先读R222 task_contract.md；沿R221已审SS2/7/9/12及proof接口保共同q、真实β/ν、twoΠ与原剩余。未读本轮作者新稿，不重复核D全域或搜史。目标仍是原SS7联合source/root预算；固定kernel包络即使可用，也不预报一般付款。

原外q为共同标量；Q_x^*为同接收点三腿测试核。Π_t只在固定(ω,V,j,y,t)后独立x,z；L,R,s,g、终端与捕获等仍依x。原score、浮动带外、负账一次保持。不能把固定核Lebesgue积分定理套给按原实际状态条件化后的任意接收测度。

### 1. 向上尺度取整的点态支配及显式费用

先固定soft。对坐标径向非增f_s，若L≤L'≤rL，r=1+ε/n，则f_s((x_i−y_i)/L)≤f_s((x_i−y_i)/L')，所以P_s,L≤(L'/L)^nP_s,L'≤r^nP_s,L'。hard_R同理：R≤R'≤rR给h_R≤r^nh_R'，闭支持边界也包含。该式不要求新节点继承原FIRST/good/history。

第一腿A=L，第二腿A=min(b,γL)，上取整后取A'=min(b,γL')，有A≤A'≤rA；J腿A=b、σ=1始终固定。因此两条共同soft半密度乘hard费用至多r^(2n)≤e^(2ε)；J腿只有current半密度变化，费用r^(3n/2)≤e^(3ε/2)。不能漏半次幂或hard归一费用。若同时改soft，须先另证其公共节点包络并显式付费。

### 2. w_g分母可合法上放，但原比例带不能自动重算

g'=√(L'R')≥g，同一原cj下w_g'≤w_g，故1/√w_g≤1/√w_g'；替换为更小w的分母是正确正上界，无额外损失。但一般非同比例取整可能增大min(L',R')/g'，从而破坏min(L',R')≤cjg'。仅有分母方向不能授权对新参数用原cj套R220。

一个合法的比较参数选择是

    θ'=min(L',R')/g'，c*=max(cj,θ')。

它只依固定网格节点和原j，不是重选原比例j；原Π、Z_t、clock或history不改。R220全参数核定理容许任意c≥θ'，故可用c*。因c*g'≥cjg，比较w_*≤原w_g，点态分母仍无额外损失。记θ=min(L,R)/g，θ/√r≤θ'≤√rθ，因此c*/θ'≤√rγ、c*/cj≤√r。若恢复原局部source/尺度前因子，必须显式保这些价格；不能把c*叫原原始条带或使用未证明的原γ下向带。若取整设计本已保持min(L',R')≤cjg'，可直接用cj而无需该修正。

所有原gate/capture/test核均按原实际参数保留，取整节点只替换其核的非负上界。连续尺度至网格的节点数、误差和合计仍须收费，不因点态支配就成为root预算。

## 新exact-min候选：独立先行筛查

收到主代理准确新命题后先独立核验，仍未读作者稿。置m=min(L,R)、M=max(L,R)，

    w_m(y,v)=∏i min{1,bC(|y_i−v_i|/b)/m}，
    H=h_R(x−z)√[P_s,L(x−y)Pσ,A(x−v)]，
    K_exact=M^n H/√w_m。

R220取比较参数c=m/√LR（恰等于允许下界θ）时，g/c=M、cg=m，故其全域定理直接给∫K_exact dx≤1。这是有单位的归一receiver核，未修改原j或后验。

### 3. 与原cj带的精确转换

令r0=cjg/m，原完整比例带给1≤r0≤γ。逐坐标min比较给

    w_m≥w_g≥r0^(−n)w_m，
    H/√w_g≤r0^(n/2)M^(−n)K_exact≤γ^(n/2)M^(−n)K_exact。

因此γ^n是安全但较粗的还原价。更完整地，原归一D核D_old=(g/cj)^n H/√w_g满足

    D_old/K_exact=r0^(−n)√(w_m/w_g)≤r0^(−n/2)≤1。

此处D_old表示归一被积核而非其坐标积分，二者单位相同。该pointwise比较不免费删除原source前因子：将原H/√w_g还原时仍有实际M^(−n)（或原(cj/g)^n）及q^−1。这个因子有长度的−n次方单位，不能混同为1。

已用本机Python/Fraction实际核63组抽象正坐标和r0∈[1,γ]的两项w比较及D_old/K_exact平方界，全部通过；只核有理min代数，不是physical source实验或一般预算证明。

### 4. R≥L分支的真正无网格归一包络

固定L、A、s、σ、y,v,z且L≤R≤b时，m=L、M=R，准确有

    K_exact,R=1_{Q_R(z)}(x)√[P_s,L(x−y)Pσ,A(x−v)]/√w_L(y,v)。

除hard支持外其余因子独立R，支持随R嵌套，所以pointwise sup_{L≤R≤b}K_exact,R=K_exact,b，进而∫sup_R K_exact,R dx≤1。此命题通过，确无归一kernel的R节点费。原R=L的B扣除可删作正上界，不在新端点重算捕获或其他gate。固定L时K2的A=min(b,γL)、J的A=b/σ1均不随R变化，故实际三腿也适用；独立soft在本句是固定参数，不授联合soft选择。

范围与未付条件：上述无费的是归一kernel，原H/√w_g还原后有M^(−n)=R^(−n)。若用端点R=b的未归一h_b核代替，则必须保(b/R)^n或其他经证预算，不能把该前因子一同免费删去。若L、A或soft也随x/R变化，须各自的合法包络；R<L补域尚未由此单调性覆盖。原Π仍按原cj,y,t，不能换成端点g或exact-min后的另一份后验。

## aω原RN单位上界：已窄核直接接口，等待来源链绑定

主代理提供确切原文后，已独立读取R116 astra_first.md:137–155及R117 joint_geometry.md:40–58。R116 F16明确原规范RN表示为q^−1 p h_R aω dx β_V(dy)ν_V(dz)、0≤aω≤1，完整联合门在aω内，不活跃行零；R117 JG5再次合原门为aω∈[0,1]，允许正上界放松门但不将任意aω当新FULL实例。因此不再把aω单位上界列为未知；它是原交通RN版本的已有资格，非凭名字假定。

compare专责恢复集合/核支配到该RN的来源链，本审计不重复搜史；待weight_contract版本交付后绑定。使用0≤aω≤1时仍需先在原good资格上完成相应点态上放，再删正门，不能反向让新网格/端点状态继承原FIRST/history，也不能据删门恢复一份旧负信用。当前只完成命题先筛，等待作者准确稿件；未预认跨参数共同source占用已付。

## weight_contract.md 作者稿后审核

已通读全文。原R112逐集合Γ≤q^−1pα、R113删除后Γ≤q^−1pβ的接口在R221窄核已实际读过；本轮另读R114 ratio_settlement.md:1–13，明确进入后续的是耦合版本Γ_F^c及其自己的β=β^c，保同一核支配。R116 F16与R117 JG5的aω∈[0,1]规范RN直接定义亦已独立实读。因此该来源链成立；没有借ν≤β，不混旧任意流与新β。

WC1的RN推导方向正确，依据是逐集合正核支配而非仅总质量≤1；有限截断/标准可测核框架中可取联合可测版本，再截入[0,1]、零基准处置零，不改原交通。a可含原历史积分后的条件接受概率，不要求逐项0/1或来源独立。p/q·β及Γ无量纲，外q^−1p h_R dx βν有质量单位；a不藏额外q、体积或后验分母。

WC2、WC3均保实际同点资格：WC2以当前合法p及β≤f给软端子概率，WC3用同x的hardband及ν≤f给硬端16/3，不能将没有p/q或h_R/q的裸∫a当统一概率。WC4只重获原r≤4λ量级，不是root来源列。对a加权的子源可以保原合法future上帽，但它依x及另一来源，不能改为新预冻结来源或归一后继承原q。

WC5在原SS7非负正项上a→1合法且不需先冻结实际尺度。WC6在同一固定物理核下，aMρ≤1_{B=0}，所以有限/可数不交胞可先按真实Kθ质量合并，上界Λθ≤1；原R221保守留下的a未知费用由此消除。跨不同θ_i、两Π的y依赖、δ/clock及原负账均未由此结算。

已要求一句明确资格说明：若hardband/actual receiver域曾只在a中编码，则a→1并扩大x域后，不能对新增点重用WC3/WC4/SL1；使用这些帽时须显式保原接收域E或对应指示。删a是正上放，不产生新的FULL/FIRST/hardband实例。此澄清不影响RN及同核胞合并本身。

## exact-min归一比较的两端界补核

令t=cg/m≥1，比较R220归一被积核K_c=(g/c)^nH/√w_(cg)与K_exact=M^nH/√w_m。按同一正核位置（零核处按直接不等式理解），

    K_c/K_exact=t^−n √[w_m/w_(tm)]∈[t^−n,t^−n/2]⊂(0,1]。

下界来自w_m≥w_(tm)，上界来自w_(tm)≥t^−n w_m。两端均通过，允许一般c≥m/g；原cj对应t∈[1,γ]。该式不把比较c变成新原j，不改Π、score或clock，亦不删除还原SS7时M^−n/q的真实来源权。等待主作者准确稿和数值交付后继续审核，当前不冻结整轮。

## weight_contract资格澄清终修核验

已实际核WC5新增原receiver域E/指示澄清，文字准确，weight_contract.md当前SHA256=fb0cdad4d1a0ba5a3c12f328ac30bed7d2febfb41bd4997898178b33d07d94be。对a→1的正上放、调用同点hardband的资格与扩域之间已分清；无待修阻断。

## 原全域hard来源列候选：作者稿前独立筛查

先固定原ω,V,j,x,y,v,u,t全部实际标签，x须在原hardband域E；L,R,s,g等保持该点真实值。令H_Rν(x)=∫h_R(x−z)ν_V(dz)，并设

    η=H_Rν(x)^−1∫h_R(x−z)aω(x,y,z)Mρ0(v)ν_V(dz)，

当H_Rν=0时η=0。由原RN单位界与原M/ρ范围，η∈[0,1]；它是对真实hard来源的条件平均，仍含原R/g/捕获/history，未变成新的预冻结来源、后验或独立概率。

原p_y、K_a、w_g在这些标签下不依hardz，因此每条good半密度腿的hardz积分精确为

    [H_Rν(x)/q] η √(p_yK_a)/√w_g。

在同一实际x使用H_Rν/q≤16/3，无需取sup h_R、冻结连续L/R或购买R网格。置m=min(L,R)、t0=cjg/m∈[1,γ]，避免与原辅助时间t混记，则

    w_g=wbar_(t0 m)≥γ^−n wbar_m≥γ^−n wbar_L，
    上式≤(16/3)γ^(n/2)η√(p_yK_a)/√wbar_L
         ≤(16/3)√e η√(p_yK_a)/√wbar_L。

这里wbar_r=∏min(1,bC/r)。全部方向通过；原hard来源为全ν，不限Z_g，不用ν≤β、坐标独立或ē_g→e_g。R=b亦覆盖，因为硬帽在原实际R而非越窗R+ell上使用。该式确实给实际hard来源列上界并消去显式h_R，但并不消去η所携R/状态、适应性L、β与两Π/δ联合来源预算。

对R≤L分支，若η>0，则有正贡献的ρ0>0，而闭硬门B=1_{R≤L}1_{Q_R(x)}(v)迫使r_v=2||x−v||∞>R≥a。因此可保1_{r_v>a}，并令d=min(L,r_v)≥R=m，得到wbar_m≥wbar_d；同一上界可用wbar_d替代wbar_L。η=0及H=0时均按零项理解，不从0/0提出额外资格。R>L没有该硬排斥，不将refine扩展到此支。

若重排t与x积分或扩成公共clock区间，原Jfar(x)、process支持与其他时间门必须仍在M/η或原域中。此次硬来源上放不提供免费的clock长度，不消费负账或重领浮动带。该准确全域候选通过先行筛查；尚待读source_occupancy作者整稿和最终数值，不将其登记为原一般root已付。

## proof.tex.txt 作者稿后全文理论审核

已完整通读当前作者稿。共同q、显式hardband域E、原核逐集合支配到RN、wbar比较、exact-min归一与R≥L嵌套、实际hard来源条件平均、B-refinement及P全测度回代均与先行独审一致。没有以归一kernel的无费R包络删除还原的R^−n；全域source定理则改在同一实际x先对真实hard来源用原硬帽，避免该前因子替代。

P回代保外2Λ、good√(K/3)、hard16/3及γ^(n/2)，三腿显式求和；ν硬源已被同点条件均值η处理，β与Π_τ⊗Π_τ、δ、dτ/τ、真实dx仍保留，没有二次除e_τ²。η≤1只允许正上放，不授放松后family新的FULL身份，亦未借它完成root预算。R≤L及R>L两支互斥，r_v=a与闭QR边界原正项为零，分母只在r_v>a处取值，零域约定正确。

已要求最终把公共τ显示积分的“clock domain may be retained”明确为η实际含1_{τ∈Jfar(x)}及原process支持，而非可选处理。其余理论无阻断。作者主稿/最终数值尚待一起绑定，本段不预报全轮审核完成。

## source_occupancy.md 全文作者稿后审核

已完整通读SOCC1–11及费用/本机检查说明。SOCC1显式保实际hardband域E，SOCC4的M含1_{j(x)=j}、1_{t∈Jfar(x,y)}、原截断及其余原全部正门；η在非E/H=0处零，实际ρ若经history依hardz仍在z积分内，均准确。条件平均是精确原积分的归一书写，不重建FIRST或来源独立性。

SOCC6逐坐标权比较、SOCC7闭核心上的R≤L改进、SOCC8互斥补支均与先筛一致。SOCC9先精确抽出不依hardz的半密度与w，再在同一实际x用hardband；SOCC10只付一次16/3。SOCC11的外常数(32Λ/3)√(K/3)γ^(n/2)准确，三腿之和仍显式保留，不暗乘或少乘三；β与Π_t⊗Π_t、δ、dt/t及dx_E全部保持，无额外e_t^−2。

因此本稿确给整个原实际尺度窗（含R=b）的hard来源列有价支配，非仅有限菜单或单胞条件桥。它没有把∫sup_R h_R替成sup_R∫h_R，也没有令各胞重复领取总来源费。支付掉的是显式ν(dz)/q·h_R及其几何权比较，R/g仍经η约束terminal/capture/clock/history；L/soft选择、与同y相关的两Π、score和原来源列的root合计仍未证。

作者明确同量不能再领hard16/3，剩余无h_R式不能直接再套R220共同硬核定理；保hardz/min定位路线可作为原量的另一上界，但需重新在同一原对象组织比较。48项Fraction仅核权代数，不称physical/full实验。全文未见阻断性错误，等待最终统一SHA和数值交付。

## 最终数值源码、全JSON与独立实际复跑

已完整审scale_normalization_checks.py最终99行及JSON全部结构。全部运算为Fraction与任意精度整数，无sqrt/float近似。归一配方λ_i>0、1≤t≤1+1/n给w=∏min(1,λ_i)、w_t=∏min(1,λ_i/t)，代码正确核t^−n w≤w_t≤w及(K_c/K_exact)^2∈[t^−2n,t^−n]。104组分48/32/24三阶段，含t=1、近1、上端、min阈值两侧及n10000。大有理数仅以规范小写hex分子/分母SHA与bit length保存，recipe及坐标重数可完全重建，非丢失失败数据。

120组尺度关系保持g²=LR、m/M及a=c/g的单位，检查原a^n与R^−n的比；R=b,L=b/2时粗替换恰2^n，不掩盖还原价格。这里L/R确在物理范围，连续t/c比较参数则是有理代数包络，不声称每组就是原离散j/history实例。

新增64组同一x=0的hard原子（16/32/16三阶段）实际按hard立方体内外设置坐标与h_R值，构造满足H≤(16/3)q的正质量及[0,1]门；精确核G=ηH、H=0约定、w_m≥w_L、w_g≥γ^−n w_m与平方source界。H0共16项，η0共32项，其余η=9/16或1。R≤L的r_v及min(L,r_v)只作为对应权代数检查。任意λ/gate及原子质量不认证实际C几何、绝对连续正L1、完整history或后验；代码/证明/报告均明确这一界限。

已用本机python3独立实际输出/tmp/r222_audit_scale_normalization_checks.json，进程exit0；与交付完整JSON逐字节一致（1,152,208 bytes），无活跃session。另核全部104+64 recipe SHA、全部check标志、全部阶段及总数量、120尺度检查、16/32零分支和η分布，核各归一配方坐标重数与n一致。脚本SHA绑定与JSON内记录相符。此为有限精确代数实现证据；全域定理由逐坐标min比较、原RN/hardband及同点精确恒等式承担，不以有限样本授一般预算。

## 最终全文整合、报告与复现静态审核

proof.tex.txt此前全文已完整通读，现203行最终增补已实读：公共τ外域的Jfar与原process支持指示实际保在η中，在共同允许clock域作零延拓；两份Π仅按原过程使用，无假造后验或额外e_τ分母。新增104/120/64及H0/η0段与实际源码/JSON完全一致，并明确原子不模拟正L1/FULL/history。10个label互异、4个ref/eqref均有定义，环境嵌套配对通过；未编译PDF。

report已全文读过，准确区分RN权恢复、exact核归一/原尺度前因子、全实际hard来源支配与仍未付的L/soft+双Π根阶总价。没有声称原一般weak目标闭合，没有在无h_R余式上重套R220或重复16/3。reproduce.py静态检查：按最终manifest成员核哈希，复制自包含标准库脚本到包外新目录执行，比较整份JSON，前后再次verify并写包外回执。最终manifest生成、父级整包迁移driver及归档/Git操作尚不由本审计预报，另记轮次README/实际回执。

最终受审文件绑定如下：

|文件|SHA256|
|---|---|
|task_contract.md|1c72b0159d930cd11eb823011ff699cb83c9980a4cb2a0d7cc2d47e860b78dec|
|weight_contract.md|fb0cdad4d1a0ba5a3c12f328ac30bed7d2febfb41bd4997898178b33d07d94be|
|source_occupancy.md|64c479aa13872fd8984ecbb3cae203883a038ece9de0e95f7531d565de946e32|
|proof.tex.txt|718d04415c7daff8fef659bc294cb8538849429cc55bc044139f2c64f9f95f2a|
|scale_normalization_checks.py|366cbf54956a66cde7b7ae07faa9ec718c58e547b8de649b8a79f158429050b6|
|scale_normalization_checks.json|2f5a8fa1d95081272615b047686daec422aaa23834c894b677d30db83acb0f4d|
|report.md|4150d5a7730a63b46ce3d3d7ad3434fc2ec12e6492e7787f3d7f2d7728ae20c1|
|reproduce.py|5e09146cb4c7cbf97e60894a1b703a2502a84fcdfd8454d786372f168e12a020|

**冻结结论。** RN单位上界与来源链、exact-min归一/嵌套、原全域hard来源支配、闭硬门改进及完整P回代均在准确范围通过；本轮不再把aω或显式hard来源列/可变R核菜单列为未知费用。原实际R/g仍在η的history/clock/捕获资格中，L/soft、位置权、三腿/j及两份同y后验的正score联合root预算仍未证。未登记原完整正剩余已获n^(1/2+o(1))来源价；R218已付带和全部负信用原账保持。独立完整JSON复跑已完成、无活跃session或待解决错误。审计至此冻结，父级后续manifest/迁移归档回执无需回头修改本文件。
