# R146 exact channel diagnostics

Completed all 24 frozen cases using standard-library Fraction arithmetic. Tested dimensions n=1,2,4,6; receiver weights unit/product/spike; source priors diagonal/general/balanced; masks all/correlated/sparse, in the combinations listed below. Every mass, second moment and covariance in JSON is an exact rational number; decimals are display values only. No original-C/FULL or root-order conclusion is asserted.

The finite cyclic channel has q(0)=1/2, q(1)=q(2)=1/4 and K(y−v)=∏q(y_i−v_i), with receiver counting measure. Each fixed source therefore has normalized K-mass1, mean score n/2 and independent centered coordinate scores a_i=1{y_i≠v_i}−1/2. The priors are probability measures and can be correlated. The R135 comparison script used the unnormalized local weights (1,1/2,1/2); division by2^n here makes the channel normalization explicit.

For arbitrary deletion Z and receiver weight r, the retained mass is M_Z=Σ_y r(y)e_Z(y), not necessarily1. All 24 cases exactly verified

`E_Z = B_Z − P_Z ≤ B_Z ≤ B_full`,

where E_Z=Σr e_Z VarΠ k, B_Z=ΣrνKZ(k−n/2)^2, B_full uses Z=1, and P_Z=Σr e_Z(EΠk−n/2)^2≥0. This is the valid source-center second-moment bridge, including its original receiver weight and full retained-mass normalization.

Two different matrix decompositions were also checked exactly:

`B_Z = nM_Z/4 + 2Σ_{i<j} A_ij`,

`E_Z = Σ_i C_ii + 2Σ_{i<j} C_ij`,

with A_ij=ΣrνKZ a_i a_j and C_ij the integrated posterior covariance. JSON includes full retained/full A matrices and posterior C matrices. These are distinct matrices: unweighted full source A offdiagonals vanish even for correlated ν, but unweighted posterior C offdiagonals generally do not vanish.

The diagonal-only proposal E_Z≤nM_Z/4 failed in exactly five cases, ids 6,13,19,22,24. Thus a proof cannot discard the cross terms merely because the underlying unweighted fixed-source channel is a product. All tested product receiver weights happened to satisfy that diagonal energy inequality; the counterexamples use a receiver spike. This is a finite necessity example, not a claim that every nonconstant receiver weight causes a violation.

## Small exact cancellation failure

Case6 has n=2, diagonal sources 0²,1²,2² with weights(1,2,3)/6, no deletion, and r(y)=1+144·1{y=0²}. The following equalities are exact:

- M=29/2, diagonal source moment D=nM/4=29/4.
- Source cross term 2ΣA_ij=27/4, so B=14.
- Posterior diagonal ΣC_ii=14039/1980.
- Posterior cross term 2ΣC_ij=7889/1188>0.
- Energy E=40781/2970, hence E/D=81562/43065≈1.89392778.

Consequently the fully normalized energy E/M≈.94696389 exceeds n/4=.5; dividing by the weighted mass does not restore the missing cancellation. With the same source prior and unit receiver weight (case5), full source cross=0, while posterior cross=−31/1188 and E≈.39764310. The spike changes which receiver fibers are emphasized; it does not change the product kernel.

For this n=2 prior, even a single source v=0² already shows the cancellation failure: under K its centered cross expectation is0, but weighting the y=0² atom adds `144 K(0²)(−1/2)^2=9` before averaging over source masses. The weighted receiver integral of the fixed centered product is therefore not zero. This directly identifies the lost factorization step: r(y) remains inside the receiver integral. A nonproduct spike cannot be removed by source normalization.

## General correlated mixtures and deletion

The general prior is the merged four-atom mixture 0_n,1_n,alternating(0,1),periodic(0,2,1), weights(1,2,3,4)/10. It is not restricted to a single diagonal common shift. At n=4, full source cross is0 under unit r (case9), and −9/128 after the correlated deletion (case10), showing deletion alone can remove the full-channel cancellation. The valid B_Z≤B_full comparison still holds.

For n=4 general prior and product receiver weight, no deletion (case11), full/retained mass is1.011083984375, source cross is801/20480=.039111328125 and posterior cross is about.016595669. This r has uniform-counting mean1, yet M≠1. Uniform receiver averaging and νK-weighted receiver averaging are different normalizations.

The strongest tested violation is case24: n=6 balanced correlated prior, spike receiver weight and sparse deletion. M_Z≈1085.35919331, E_Z/M_Z≈7.99768519, source diagonal per mass is n/4=1.5, and E_Z/D≈5.33179012. Source cross≈8137.74473 and posterior cross≈7233.42070 remain positive. Its exact rational values and full matrices are in JSON.

Deletion must not be treated as preserving the weighted variance. At n=4 balanced prior with spike r, changing mask all (case19) to correlated (case20) reduces E/M from3.52984448 to.00221088744; source cross remains positive while posterior cross changes sign. The exact identity with centering penalty P_Z handles this effect. Merely bounding the positive source cross is insufficient to predict the final energy.

## All tested cases

Ratios below are E/(nM_Z/4), rounded for display. Every row passed all exact bridge and matrix identities.

|id|stage|n|source|receiver|mask|E/diagonal|
|---:|---|---:|---|---|---|---:|
|1|initial|1|diagonal|unit|all|0.904762|
|2|initial|1|diagonal|spike|all|0.835979|
|3|initial|1|general|unit|all|0.444444|
|4|initial|1|general|spike|all|0.402778|
|5|initial|2|diagonal|unit|all|0.795286|
|6|initial|2|diagonal|spike|all|1.893928|
|7|initial|2|general|unit|all|0.623480|
|8|initial|2|general|spike|all|0.582288|
|9|pressure|4|general|unit|all|0.553498|
|10|pressure|4|general|unit|correlated|0.391889|
|11|pressure|4|general|product|all|0.597902|
|12|pressure|4|general|product|correlated|0.427317|
|13|pressure|4|general|spike|all|1.192991|
|14|pressure|4|general|spike|correlated|0.489226|
|15|pressure|4|balanced|unit|all|0.500612|
|16|pressure|4|balanced|unit|correlated|0.263715|
|17|pressure|4|balanced|product|all|0.653187|
|18|pressure|4|balanced|product|correlated|0.401969|
|19|pressure|4|balanced|spike|all|3.529844|
|20|pressure|4|balanced|spike|correlated|0.002211|
|21|expanded|6|general|product|sparse|0.714041|
|22|expanded|6|general|spike|sparse|2.121681|
|23|expanded|6|balanced|product|sparse|0.521762|
|24|expanded|6|balanced|spike|sparse|5.331790|

The script is deterministic, standard-library only and completed its single full run in about.65 seconds. It writes only its JSON. Plan, script and R135 comparison-file SHA256 values are saved. No assertions failed, no cases were added after inspecting the results, and no old receiver records were sampled or recomputed.

These finite masks are arbitrary functions of(y,v), not actual time-monotone Z_t, and the spike weights are synthetic receiver weights, not a claimed representation of p·h_R/e² or another original outer weight. The result establishes the exact bridge algebra and a specific cancellation failure. A real bridge must retain or control the weighted cross terms and the centering penalty; this experiment does not supply that control or a root-order budget. Work stops at this four-file delivery.
