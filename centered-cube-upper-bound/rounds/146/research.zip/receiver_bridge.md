# R146：SC 空间能量到原接收权的精确桥检验

结论：未证明新的原接收加权方差付款。已明确该桥的最优测度支配常数、若该常数可控时的完整原价，以及原 good/high/FIRST/low 尚须给出的具体密度补偿。R140 的共同来源关系允许把 SC 的总来源质量收为 Wβ；不能把这一已解决部分继续列作未知。未重证 SC1–4，不以奇异 β 作为原 L1 类的反例。

## 1. 量词修正与准确候选

先读 R135 `source_channel.md`、R140 `joint_transport.md` 和 R145 `source_tail.md`，再按主代理指示核对 R140 `beta_source_contract.md`。实际来源链是

\[
\nu_V\le\beta_V\le\alpha_V\le f\,dy.
\tag{RB1}
\]

因此任意正 L1 输入的 β_V 绝对连续，写 b_V=dβ_V/dy。其来源质量满足 N_V=||ν_V||≤||β_V||，从而 EΣ_V N_V≤Wβ。扩展有限测度版本可以含奇异 β，但它不是原 L1 类的反例。

固定 ω,V,j,t，保留原 ν、Z_t、w_t、e_t、Π_t。δ(v,u)=[k_t(v)−k_t(u)]_+ 不依接收 x。定义真实 pair 接收系数

\[
\begin{aligned}
A_{j,t,y}(v,u)=\int dx\,\frac{p_x(x-y)}{q(x)}
\int h_{R(x)}(x-z)a_\omega(x,y,z)
\chi_{orig}(x,y,z,v,u,t)\rho_v(x)
1_{\{c_x(v,u)<\eta_n\}}d\nu_V(z).
\end{aligned}
\tag{RB2}
\]

χ_orig 包括原唯一 j(x) 指示、实际完整时间窗、旧已付补集、terminal good／D0、Ψ、FA、high 及其余正资格。c 和 η_n 沿 R145 ST1，所有核与共同容量均在实际接收点取值。不把 hard z 与内来源 u 混同，不冻结自适应参数。δ=0 的 pair 系数可置零。

固定同行的 Π_t²-essential supremum 记为 A*_{j,t}(y)。它可由原可测核的本质上确界定义，所有以下积分均按非负扩展值理解。原 low 正交通准确写成

\[
2\Lambda P_{low}=2\Lambda\mathbb E\sum_{V,j}
\int_a^b\frac{dt}{t}\int d\beta_V(y)
\iint\delta(v,u)A_{j,t,y}(v,u)d\Pi_t(v)d\Pi_t(u),
\tag{RB3}
\]

因为实际窗指示已在 RB2 内。先取 A* 只是一项明确正放松；不会声称保留 pair 与接收系数的全部关联。

**先筛候选。** SC 的信道测度是 λ_t(dy)=e_t(y)dy/z_t^n。若欲直接用 SC3 支付 RB3 的 A* 放松，所需候选应是

\[
\boxed{\frac{z_t^n b_V(y)A^*_{j,t}(y)}{e_t(y)}
\le\kappa_{V,j,t}\quad\text{a.e. on }\{e_t>0\}.}
\tag{RB4}
\]

z_t 是 SC 原一维归一化常数。该式无量纲。e_t=0 行按原零交通定义置零，不作商。本文没有将 RB4 宣称为原门已蕴含的结论。

## 2. 已证明的桥定理及完整原价

对任意 κ≥0，RB4 与非负测度支配

\[
A^*_{j,t}(y)d\beta_V(y)\le\kappa\,e_t(y)dy/z_t^n
\tag{RB5}
\]

等价。证明仅为 Radon–Nikodym 密度比较。因此

\[
\kappa^*_{V,j,t}=\operatorname*{ess\,sup}_{e_t>0}
\frac{z_t^n b_V A^*_{j,t}}{e_t}
\tag{RB6}
\]

是**对全部非负测试函数作 SC 测度转移的最小常数**；这比只指定一个未知能量更具体。它不声称是某一个特定方差函数的最小积分常数。

引用 SC1、SC3，而不重证它们，得到完整同行估计

\[
\int A^*_{j,t}\operatorname{Var}_{\Pi_t}k_t\,d\beta_V
\le\kappa^*_{V,j,t}N_V n\vartheta_t(1-\vartheta_t)
\le\tfrac n4\kappa^*_{V,j,t}N_V,
\tag{RB7}
\]

\[
\int A^*_{j,t}\mathbb E_{\Pi_t^2}\delta_t\,d\beta_V
\le\kappa^*_{V,j,t}N_V\sqrt{n/8}.
\tag{RB8}
\]

ϑ_t 为 SC 原一维 Bernoulli 参数。故对原全层级，已证明的精确费用是

\[
\boxed{2\Lambda P_{low}\le
\frac{\Lambda}{\sqrt2}\sqrt n\,
\mathbb E\sum_V N_V
\sum_j\int_a^b\kappa^*_{V,j,t}\frac{dt}{t}.}
\tag{RB9}
\]

若能另证统一预算 Σ_j∫κ*dt/t≤L_bridge，则 RB1 确实给

\[
2\Lambda P_{low}\le
(\Lambda L_{bridge}/\sqrt2)\sqrt n\,W_\beta.
\tag{RB10}
\]

这是所需常数及其确切依赖；**L_bridge 尚未得到实际输入类的统一帽，所以 RB10 不是本轮已付款**。q、hard ν、ρ、good/high/low、实际 dx 和接收选择器全部留在 RB2；两份 e_t 在原 Π_t² 内，β 未换 ν。所有 j 与 dt/t 在 RB9 明列，未先合并。RB4 在来源消去前依赖 y、ν、j、t，不符合 JT14 的“共同数值行帽”量词，故不能用 JT14 免费删掉 RB9 的 j 和时间费用。

在扩展的奇异 β 合同中，RB5 另外要求 A*β 的奇异部分为零；dx 积分只产生 A*(y)，不会自动平滑 y。此观察仅限定扩展合同，不能代替原 L1 类的 RB4 检验。

## 3. 为什么现有门尚未认证 RB4

原实际 hard 帽与 JT13 至多给

\[
A^*_{j,t}(y)\le \frac{16}{3}\,3(2n+3)D_n,
\qquad D_n\le3\sqrt n.
\tag{RB11}
\]

这是合法的第一行接收质量帽，但 RB6 还含 z_t^n b_V/e_t。β≤f 是测度支配，不给后者统一帽。即使先完全不论接收门，这一点也可在 L1 类的来源合同中明确检验：固定非零有限有界密度 ν、Z_t 全保留，取

\[
\beta_\epsilon=\nu+m\epsilon^{-n}1_{Q_\epsilon(y_0)}dy,
\qquad f_\epsilon=d\beta_\epsilon/dy.
\tag{RB12}
\]

则 ν≤β_ε≤f_εdy、||β_ε||=N+m 固定，而 e_t≤N；所以 b_ε/e_t 在该小盒内至少为 m/(Nε^n)。这证明 **来源支配和固定 L1 总质量本身**不能控制所需密度比。没有声称 RB12 同时满足全部原 forest／FIRST／high；它不是 FULL 反例。

若实际门足以修复这一集中，它须使相应实际 A*_ε 在该小盒上满足

\[
A^*_\epsilon(y)\le
\frac{\kappa e_t(y)}{z_t^n b_\epsilon(y)}=O(\epsilon^n),
\tag{RB13}
\]

或另给能直接控制特定 score 函数的非密度型估计。RB13 是这个 SC 测度桥所需的明确接收补偿；不能仅报“第一行 Schur 有界”。

现有 high/FIRST 给 QJ/e_t≤p_x/(2K)，不含 b_V。good 与实际 low 合用确实给

\[
2DK_u(x)w_g(v)<\eta_nTA_vw_t(u)\delta(v,u),
\tag{RB14}
\]

但它约束 K_u/w_t(u)，同样没有 b_V。它不能直接推出 RB13。β 的密度可能通过原 q、history 和合法接收域间接影响 A*；本稿没有证明这种影响无效，也没有证明它提供 ε^n 补偿。因此结论是“RB4 未由这些已读不等式推出”，不是“原输入类不存在任何桥”。

## 4. 不经密度帽时必须通过的具体 pair 接收测试

避免 RB4 的强测度支配是允许的，但不能只把方差换一个名称。一个可直接验证的必要几何测试如下。固定合法同行，在两个来源组 U、V 上有 k_t(v)−k_t(u)=Δ>0；令后验组质量 p_U、p_V>0，并令

\[
\overline A_{UV}(y)=\frac1{p_Up_V}
\int_V\int_U A_{j,t,y}(v,u)d\Pi_t(u)d\Pi_t(v).
\tag{RB15}
\]

原正 score 与加权二次 score 在这一个真实组对上的贡献分别**恰为**

\[
p_Up_V\Delta\,\overline A_{UV}(y),
\qquad p_Up_V\Delta^2\,\overline A_{UV}(y).
\tag{RB16}
\]

所以若在接收后的 β 权下，试图把该二次量按 Cn 每单位 β 质量支付，则在后验组质量有正下界、Δ≈n 且 β 集中于该区域的场景，必须取得平均接收交叠 \(\overline A_{UV}\lesssim C/n\)，或者有明确可用的 εX 支付该组对。只为原一次 score 取得纯 C√n 每单位 β 的价格，也至少需要相应交叠 ≲C/√n。RB15 含完整 good/high/FIRST/low/ρ、q、hard 来源和实际 dx，因而这个检验针对真实接收几何，而非无门的抽象后验反例。

本文没有声称这些两组场景已在 FULL 中实现。它说明：SC 在 Lebesgue y 下产生的坐标交叉项抵消，若不通过 RB4 转移，就必须由原接收域对高 score 分离组对的交叠抑制替代。第一行质量帽 RB11、ν≤β 及后验概率归一化均未给 RB15 所需的维数下降。把 Π 坐标当独立 Bernoulli 会直接跳过这一步。

## 5. 覆盖、余部与停止结论

初探已给 RB4 的精确量词；压力核查将奇异测度与原 L1 来源区分，并通过 RB12 排除“L1 总质量／共同支配自动给密度帽”的推断；扩大到实际原核后，已把需求缩成 RB13 的密度补偿，或 RB15–16 的带门 pair 接收交叠估计。两者均未在本次限定阅读中获得所需价格。

因此本稿新增的是完整桥检验与真实费用定位，**不是新实际付款**。RB9 保留全部未付费用；没有以待证 L_bridge 回报成功，没有消费 N_Z、futurebad、Ndel 或原 Ψ 负项，也没有重新领取已付 high-c/core 子支。原 low 的全部未覆盖交通仍保留。

仅写本文件；未修改其他代理文件，未运行 Git/PDF。完成有界任务后停止。
