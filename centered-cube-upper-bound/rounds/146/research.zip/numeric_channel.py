#!/usr/bin/env python3
"""Exact finite cyclic product-channel covariance diagnostics. Standard library only."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from collections import defaultdict
import json,hashlib,time,datetime
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'numeric_channel.json'
OLD=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/channel_numeric.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def enc(x):
 if isinstance(x,F):return {'numerator':str(x.numerator),'denominator':str(x.denominator),'decimal':format(float(x),'.16g')}
 if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x
def prior(n,mode):
 if mode=='diagonal':raw=[((j,)*n,F(j+1,6)) for j in range(3)]
 elif mode=='general':raw=[((0,)*n,F(1,10)),((1,)*n,F(2,10)),(tuple(i%2 for i in range(n)),F(3,10)),(tuple([0,2,1][i%3] for i in range(n)),F(4,10))]
 else:
  assert mode=='balanced';a=2**n;raw=[((j,)*n,F(1 if j==0 else a,1+2*a)) for j in range(3)]
 ans=defaultdict(F)
 for v,w in raw:ans[v]+=w
 assert sum(ans.values())==1
 return sorted(ans.items())
def weight(y,mode):
 if mode=='unit':return F(1)
 if mode=='spike':return F(1+12**len(y)*int(all(z==0 for z in y)))
 z=F(1)
 for a in y:z*=F([3,1,2][a],2)
 return z
def keep(y,v,mode):
 if mode=='all':return True
 if mode=='correlated':return (sum(y)+2*sum(v))%3!=0
 assert mode=='sparse';return (sum((i+1)*z for i,z in enumerate(y))+sum(v))%3==0

def menu():
 out=[]
 for n in [1,2]:
  for src,r in product(['diagonal','general'],['unit','spike']):out.append(dict(stage='initial',n=n,source=src,receiver=r,mask='all'))
 for src,r,z in product(['general','balanced'],['unit','product','spike'],['all','correlated']):out.append(dict(stage='pressure',n=4,source=src,receiver=r,mask=z))
 for src,r in product(['general','balanced'],['product','spike']):out.append(dict(stage='expanded',n=6,source=src,receiver=r,mask='sparse'))
 for i,c in enumerate(out,1):c['id']=i
 assert len(out)==24
 return out

def run(c):
 started=time.monotonic();n=c['n'];sources=prior(n,c['source']);M=F(0);Mfull=F(0);B=F(0);Bfull=F(0);P=F(0);E=F(0);A=[[F(0) for j in range(n)] for i in range(n)];AF=[[F(0) for j in range(n)] for i in range(n)];Cov=[[F(0) for j in range(n)] for i in range(n)];empty=0;active_hist=defaultdict(int);r_sum=F(0)
 for y in product(range(3),repeat=n):
  r=weight(y,c['receiver']);r_sum+=r;terms=[]
  for v,nu in sources:
   bits=[int(a!=b) for a,b in zip(y,v)];k=sum(bits);a=[F(2*z-1,2) for z in bits];q=nu/F(2**(n+k));Mfull+=r*q;Bfull+=r*q*sum(a)**2
   for i in range(n):
    for j in range(n):AF[i][j]+=r*q*a[i]*a[j]
   if keep(y,v,c['mask']):terms.append((q,a))
  active_hist[len(terms)]+=1;e=sum((q for q,a in terms),F(0))
  if not e:empty+=1;continue
  M+=r*e;first=[sum((q*a[i] for q,a in terms),F(0)) for i in range(n)];localB=sum((q*sum(a)**2 for q,a in terms),F(0));centerfirst=sum(first);B+=r*localB;P+=r*centerfirst**2/e;E+=r*(localB-centerfirst**2/e)
  for i in range(n):
   for j in range(n):
    sec=sum((q*a[i]*a[j] for q,a in terms),F(0));A[i][j]+=r*sec;Cov[i][j]+=r*(sec-first[i]*first[j]/e)
 D=F(n,4)*M;O=2*sum(A[i][j] for i in range(n) for j in range(i+1,n));OF=2*sum(AF[i][j] for i in range(n) for j in range(i+1,n));postD=sum(Cov[i][i] for i in range(n));postO=2*sum(Cov[i][j] for i in range(n) for j in range(i+1,n));assert E==B-P and E>=0 and P>=0 and E<=B<=Bfull;assert B==D+O and E==postD+postO;assert Bfull==F(n,4)*Mfull+OF;assert all(Cov[i][i]>=0 for i in range(n));assert all(A[i][i]==M/4 for i in range(n))
 if c['receiver']=='unit':assert Mfull==1 and Bfull==F(n,4) and all(AF[i][j]==0 for i in range(n) for j in range(n) if i!=j)
 return dict(**c,source_atoms=[dict(position=v,mass=w) for v,w in sources],receiver_state_count=3**n,receiver_counting_weight_sum=r_sum,receiver_counting_weight_mean=r_sum/3**n,receiver_weight_is_probability_density=False,weighted_full_mass=Mfull,weighted_retained_mass=M,retained_mass_fraction=M/Mfull,zero_e_receiver_sites=empty,active_source_count_histogram=dict(active_hist),energy=E,source_center_second_moment_retained=B,source_center_second_moment_full=Bfull,posterior_centering_penalty=P,source_diagonal=D,source_offdiagonal_twice_sum=O,source_full_offdiagonal_twice_sum=OF,posterior_diagonal=postD,posterior_offdiagonal_twice_sum=postO,source_center_matrix=A,source_center_full_matrix=AF,posterior_covariance_matrix=Cov,energy_per_weighted_mass=E/M if M else None,source_retained_second_moment_per_mass=B/M if M else None,energy_over_diagonal_only_bound=E/D if D else None,source_offdiagonal_over_diagonal=O/D if D else None,posterior_offdiagonal_over_diagonal=postO/postD if postD else None,diagonal_only_energy_bound_holds=E<=D,diagonal_only_source_bound_holds=B<=D,exact_identities_pass=True,unweighted_source_cancellation_verified=c['receiver']=='unit',elapsed_seconds=time.monotonic()-started)
def main():
 started=time.monotonic();cases=[]
 for c in menu():
  r=run(c);cases.append(r);print(c['id'],c['n'],c['source'],c['receiver'],c['mask'],'E/D',str(r['energy_over_diagonal_only_bound']),'sourceCross',str(r['source_offdiagonal_twice_sum']),'postCross',str(r['posterior_offdiagonal_twice_sum']),flush=True)
 out=dict(status='completed_exact',scope='Finite rational cyclic product channel, correlated source mixtures, arbitrary deletion, nonconstant receiver weights; not original C/FULL/history',script_sha256=sha(Path(__file__)),plan_sha256=sha(ROOT/'numeric_channel_plan.md'),comparison_source_sha256=sha(OLD),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started,cases=cases,summary=dict(case_count=len(cases),dimensions=sorted(set(c['n'] for c in cases)),masks=sorted(set(c['mask'] for c in cases)),receiver_weights=sorted(set(c['receiver'] for c in cases)),source_priors=sorted(set(c['source'] for c in cases)),identity_failures=0,diagonal_only_energy_bound_failures=[c['id'] for c in cases if not c['diagonal_only_energy_bound_holds']],source_cross_nonzero=[c['id'] for c in cases if c['source_offdiagonal_twice_sum']!=0],posterior_cross_nonzero=[c['id'] for c in cases if c['posterior_offdiagonal_twice_sum']!=0],max_energy_over_diagonal=max(c['energy_over_diagonal_only_bound'] for c in cases if c['energy_over_diagonal_only_bound'] is not None),root_order_conclusion=False))
 OUT.write_text(json.dumps(enc(out),ensure_ascii=False,indent=2)+'\n');print('SUMMARY',enc(out['summary']),flush=True)
if __name__=='__main__':main()
