#!/usr/bin/env python3
"""Frozen Q-full-gate band diagnostic, saved scalars only; no kernel or integral calls."""
import json,math,hashlib,time,datetime,argparse
from pathlib import Path
from decimal import Decimal as D,localcontext
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output');args=ap.parse_args();BASE=Path(args.input_root)
SPECS={'receiver':(BASE/'centered_cube_round142_20261015/numeric_receiver.json','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'),'source':(BASE/'centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'),'screen':(BASE/'centered_cube_round144_20261015/numeric_geometry.json','98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517'),'score':(ROOT/'numeric_score.json','6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879')}
LAMBDAS=[.01,.1,1,2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def quant(v):
 v=sorted(v)
 if not v:return {'N':0}
 out={'N':len(v)}
 for p in [0,.1,.5,.9,.99,1]:
  a=(len(v)-1)*p;i=int(a);out[str(p)]=v[i]+(v[min(i+1,len(v)-1)]-v[i])*(a-i)
 return out
def ratio(a,b):return a/b if b else None
def clean(x):
 if isinstance(x,D):return format(x,'.32g')
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
start=time.monotonic();data={};hashes={}
for k,(p,expected) in SPECS.items():
 hashes[k]=sha(p);assert hashes[k]==expected,(k,hashes[k]);data[k]=json.loads(p.read_text())
source={c['id']:c for c in data['source']['cases']};dedup={}
for p in data['screen']['posthoc_capacity_split_screen']['pair_segment_records']:
 key=(p['case'],p['id'],p['v'],p['u'])
 if key not in dedup:dedup[key]={'record':p,'segments':[]}
 dedup[key]['segments'].append(p['segment'])
wanted={(key[0],key[1]) for key in dedup};receiver={}
for cid,c in data['receiver']['cases'].items():
 for r in c['records']:
  if (cid,r['id']) in wanted:receiver[(cid,r['id'])]=r
assert len(wanted)==179
checks={'dedup_pair_N':len(dedup),'receivers':len(receiver),'max_Q_abs_error':0.,'max_Q_relative_error':0.,'Q_relative_error_gt_1e_minus12':[],'missing_or_nonpositive_fields':[],'good_bad_label_failures':[],'a_negative':[],'b_nonpositive':[],'max_log_identity_abs_residual':0.,'max_80_vs120_abs_change':0.}
with localcontext() as ctx:
 ctx.prec=80
 for (cid,rid),r in receiver.items():
  for i in range(6):
   q=D(str(r['Q'][i]));mean=sum(D(str(r[k][i])) for k in ['K1','K2','J'])/3;err=abs(q-mean);rel=err/abs(q) if q else D('Infinity');checks['max_Q_abs_error']=max(checks['max_Q_abs_error'],float(err));checks['max_Q_relative_error']=max(checks['max_Q_relative_error'],float(rel))
   if rel>D('1e-12'):checks['Q_relative_error_gt_1e_minus12'].append([cid,rid,i,str(rel)])

def band(key,precision):
 cid,rid,v,u=key;r=receiver[(cid,rid)];src=source[cid]
 with localcontext() as ctx:
  ctx.prec=precision;p=D(str(r['p']));qv=D(str(r['Q'][v]));qu=D(str(r['Q'][u]));wv=D(src['atoms'][v]['wg']);wu=D(src['atoms'][u]['wg']);K=D(src['parameters']['K'])
  if min(p,qv,qu,wv,wu,K)<=0:return None
  b=(p*wu/(K*qu)).ln();a=(K*qv/(p*wv)).ln();width=(qv*wu/(qu*wv)).ln();return {'a':a,'b':b,'width':width,'identity_residual':a+b-width,'p':p,'Q_v':qv,'Q_u':qu,'wg_v':wv,'wg_u':wu,'K':K,'lower_likelihood':K*qu/wu,'upper_likelihood':K*qv/wv}
rows=[];key_to_pid={}
for key,item in dedup.items():
 cid,rid,v,u=key;r=receiver[(cid,rid)];p=item['record'];lo=band(key,80);hi=band(key,120)
 if lo is None:checks['missing_or_nonpositive_fields'].append(list(key));continue
 if not(r['good'][v] and r['bad'][u]):checks['good_bad_label_failures'].append(list(key))
 if lo['a']<0:checks['a_negative'].append([*key,str(lo['a'])])
 if lo['b']<=0:checks['b_nonpositive'].append([*key,str(lo['b'])])
 checks['max_log_identity_abs_residual']=max(checks['max_log_identity_abs_residual'],float(abs(lo['identity_residual'])))
 for metric in ['a','b','width']:checks['max_80_vs120_abs_change']=max(checks['max_80_vs120_abs_change'],float(abs(lo[metric]-hi[metric])))
 row={'pair_id':len(rows),'case':cid,'id':rid,'stage':p['stage'],'distribution':p['distribution'],'v':v,'u':u,'v_name':p['v_name'],'u_name':p['u_name'],'original_segments':sorted(set(item['segments'])),'good_v':r['good'][v],'bad_u':r['bad'][u],**lo,'b_le_lambda':{str(l):lo['b']<=D(str(l)) for l in LAMBDAS},'width_le_lambda':{str(l):lo['width']<=D(str(l)) for l in LAMBDAS}}
 key_to_pid[key]=len(rows);rows.append(row)
samples=[];time_byid={r['time_id']:r for r in data['score']['time_models']}
for s in data['score']['samples']:
 key=(s['case'],s['id'],s['v'],s['u']);pid=key_to_pid[key];tm=time_byid[s['time_id']]
 samples.append({'pair_id':pid,'time_id':s['time_id'],'label':tm['label'],'t':tm['t'],'scoreweight':D(s['scoreweight']),'rho_scoreweight':D(s['rho_scoreweight']),'saved_low_c_over_eta':s['saved_low_c_over_eta'],'original_FA_closed':s['saved_FA_closed'],'original_FA_strict_interior':s['saved_FA_strict_interior'],'printed_time_saved_cap_closed':s['actual_saved_cap_closed'],'printed_time_saved_cap_strict_interior':s['actual_saved_cap_strict_interior']})
assert len(samples)==2070
masks={'all':lambda s:True,'original_FA_closed':lambda s:s['original_FA_closed'],'original_FA_strict_interior':lambda s:s['original_FA_strict_interior'],'printed_time_saved_cap_closed':lambda s:s['printed_time_saved_cap_closed'],'printed_time_saved_cap_strict_interior':lambda s:s['printed_time_saved_cap_strict_interior']}
def summarize(rs):
 out={'pair_N':len(rs),'receiver_N':len({(r['case'],r['id']) for r in rs})}
 if not rs:return out
 out['quantiles']={k:quant([float(r[k]) for r in rs]) for k in ['a','b','width']};byrec=defaultdict(list)
 for r in rs:byrec[(r['case'],r['id'])].append(r)
 out['coverage']={}
 for lam in LAMBDAS:
  bandkey=str(lam);pairhits=sum(r['b_le_lambda'][bandkey] for r in rs);anyhit=sum(any(r['b_le_lambda'][bandkey] for r in rr) for rr in byrec.values());allhit=sum(all(r['b_le_lambda'][bandkey] for r in rr) for rr in byrec.values());narrow=sum(r['width_le_lambda'][bandkey] for r in rs)
  out['coverage'][bandkey]={'b_pair_N':pairhits,'b_pair_fraction':pairhits/len(rs),'b_receiver_any_N':anyhit,'b_receiver_any_fraction':anyhit/len(byrec),'b_receiver_all_N':allhit,'b_receiver_all_fraction':allhit/len(byrec),'whole_width_pair_N':narrow,'whole_width_pair_fraction':narrow/len(rs)}
 pairids={r['pair_id'] for r in rs};ss=[s for s in samples if s['pair_id'] in pairids];out['score_sample_descriptions']={}
 for name,predicate in masks.items():
  selected=[s for s in ss if predicate(s)];weighttotals={w:sum((s[w] for s in selected),D(0)) for w in ['scoreweight','rho_scoreweight']};entry={'sample_N':len(selected),'point_weight_sums':weighttotals,'coverage':{}}
  for lam in LAMBDAS:
   mark=str(lam);hits=[s for s in selected if rows[s['pair_id']]['b_le_lambda'][mark]];entry['coverage'][mark]={'sample_fraction':len(hits)/len(selected) if selected else None,**{w+'_fraction':float(sum((s[w] for s in hits),D(0))/total) if total else None for w,total in weighttotals.items()}}
  out['score_sample_descriptions'][name]=entry
 return out
strata={stage:{cid:summarize([r for r in rows if r['stage']==stage and r['case']==cid]) for cid in ['I1','P1']} for stage in ['initial','pressure','expanded']};source_strata={cid+'/'+name:summarize([r for r in rows if r['case']==cid and r['v_name']==name]) for cid in ['I1','P1'] for name in sorted({r['v_name'] for r in rows if r['case']==cid})};distributions={cid+'/'+dist:summarize([r for r in rows if r['case']==cid and r['distribution']==dist]) for cid in ['I1','P1'] for dist in sorted({r['distribution'] for r in rows if r['case']==cid})}
out={'status':'completed_full_Q_likelihood_band','producer_execution_count':2,'execution_history':'Initial run followed by rerun bound to audit-revised numeric_score input; same pairs, Q, point scoreweights and menu, no new kernel or sampling.','executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashes,'plan_sha256':sha(ROOT/'likelihood_band_plan.md'),'script_sha256':sha(Path(__file__)),'scope':'Same179 necessary receivers and deduplicated existing good-v/bad-u pairs; Q=(K1+K2+J)/3, no J substitution, new kernels, integration, FULL or exponent fit.','checks':checks,'quantile_definition':'Linear empirical quantiles at (N-1)p, each deduplicated receiver/source pair counted once.','FA_semantics':'Original flags retained from R144 separately from printed-time saved-cap closed/interior membership computed in numeric_score. Closed endpoint differences are not claimed as original exact FA recovery.','scoreweight_semantics':'Sums of existing pointwise delta Pi_vPi_u or rho multiples, no time or dx integration weights; only finite-menu descriptions.','strata':strata,'source_strata':source_strata,'distributions':distributions,'pairs':rows,'sample_references':samples,'elapsed_seconds':time.monotonic()-start}
(ROOT/'likelihood_band.json').write_text(json.dumps(clean(out),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'checks':checks,'elapsed_seconds':out['elapsed_seconds']},ensure_ascii=False))
