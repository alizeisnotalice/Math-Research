#!/usr/bin/env python3
"""Replay frozen R146 calculations using prior archives, never overwrite frozen outputs."""
import argparse, ast, hashlib, json, runpy, shutil, subprocess, sys, zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True);a=ap.parse_args()
d=a.destination.resolve();d.mkdir(parents=True,exist_ok=False)
for stem in ('numeric_channel','numeric_score','likelihood_band'):
 for ext in ('.py','_plan.md'):
  shutil.copy2(P/(stem+ext),d/(stem+ext))
inputs=[(135,'channel_numeric.py','centered_cube_round135_20261014/channel_numeric.py'),(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json'),(144,'numeric_geometry.json','centered_cube_round144_20261015/numeric_geometry.json')]
for n,member,rel in inputs:
 with zipfile.ZipFile(a.rounds/str(n)/'research.zip') as z:
  q=d/'inputs'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(member))
ns=runpy.run_path(str(d/'numeric_channel.py'))
ns['main'].__globals__['OLD']=d/'inputs/centered_cube_round135_20261014/channel_numeric.py'
ns['main']()
for stem in ('numeric_score','likelihood_band'):
 if stem=='likelihood_band':
  shutil.copy2(d/'numeric_score.json',d/'numeric_score.replayed.json')
  shutil.copy2(P/'numeric_score.json',d/'numeric_score.json')
 subprocess.run([sys.executable,str(d/(stem+'.py')),'--input-root',str(d/'inputs')],check=True)
def norm(x):
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if k not in {'elapsed_seconds','executed_utc','finished_utc','started_utc'}}
 if isinstance(x,list):return [norm(v) for v in x]
 return x
for stem in ('numeric_channel','numeric_score','likelihood_band'):
 assert norm(json.loads((P/(stem+'.json')).read_text()))==norm(json.loads((d/(stem+('.replayed.json' if stem=='numeric_score' else '.json'))).read_text())),stem
print('PASS: all three deterministic results agree after excluding execution timestamps/durations')
