# R146：真实 good/bad 似然区间与接收 score 的未付比较

状态：核准了原双门的准确共同核，得到任意自适应选择器下有效的窄带／大似然差分解，并明确其完整来源费用；尚未证明该分解降低一般低门的总价。纯来源协方差路线经压力筛查不足；没有把 β 换成 dy，没有重复 H 插值，没有新增面积权或根阶付款声明。

## 1. 输入核准与先行候选

固定原 ξ=(ω,V,j,y,t)、原共同 ν、e_t、Π_t；固定外 hard 来源 z 和原内来源 u,v。接收参数 s(x),L(x),R(x),H(x),g(x) 保持实际可测选择器。原 soft 核严格正；零 e、零交通行按原约定处理。读入 R135 source_channel.md 后确认：SC1–4 的乘积积分变量是 y 的 Lebesgue 测度，不能用于本任务的 p(x−y)dx dβ(y)。R145 的实际零阶质量也没有已经付款的帽。

先核定义，来源为 R117 joint_geometry.md JG3–4 及 R128 joint_receiver_tail.md RT4：

\[
Q_x^*(u)=\frac{P_{s,L}(x-u)+P_{s,L^+}(x-u)+J_b(x-u)}3,
\qquad D_g=\{u\in Z_g:p_xw_g(u)>KQ_x^*(u)\}.
\tag{SJ1}
\]

S_g 是 Z_g 内的补集，故实际 good/bad pair 满足

\[
\boxed{\frac{KQ_x^*(u)}{w_g(u)}<p_x\le\frac{KQ_x^*(v)}{w_g(v)}.}
\tag{SJ2}
\]

所有核和 w_g 均在同一实际 x、同一参数处评价。bad **不是** p_xw_g(u)>KJ_u。结合 Q_u^*≥J_u/3 及原 good 的 C_J≤3 推论，只能得到较弱区间

\[
\frac{KJ_u}{3w_g(u)}<p_x\le\frac{KJ_v}{w_g(v)},\qquad
\frac{J_v}{J_u}>\frac{w_g(v)}{3w_g(u)}.
\tag{SJ3}
\]

一般域不能删除因子3。R142 JR2/JR7 保留 good 的 J 下界与低 K 余量，但在来源回代中删掉 bad 门；它没有给 SJ2 的完整混合核窄带估计。也不能把 Q* 当成逐坐标混合的乘积：它是三个 n 维乘积核之和。

定义实际对数边际

\[
B_u(x)=\log\frac{p_xw_g(u)}{KQ_x^*(u)},\qquad
L_{vu}(x)=\log\frac{Q_x^*(v)w_g(u)}{Q_x^*(u)w_g(v)}.
\tag{SJ4}
\]

**准确候选与已证结论：** 对任意事先选定 λ>0、σ≥0，常数均为1，任意实际选择器及任意 u,v 有

\[
1_{\{u\in D_g,v\in S_g\}}
\le 1_{\{0<B_u\le λ\}}
+e^{-σλ}\left[\frac{Q_x^*(v)w_g(u)}{Q_x^*(u)w_g(v)}\right]^σ
1_{\{B_u>λ\}}.
\tag{SJ5}
\]

还可在右端两项保留原共同来源资格 Z_g；为简明未写。这里没有声称 λ 或 σ 的某个选择已经产生维数节约。命题先经过下述压力筛查，再记录短证明，不展开未证条件路线。

## 2. 压力筛查：什么不能由接收乘积独立推出

**初探：纯协方差。** 令 d_i=1_{\{a_i(v)<t\}}−1_{\{a_i(u)<t\}}，δ=(Σ_i d_i)_+。若在真实正接收测度 μ 下能够证明 ∫(Σ_i d_i)^2dμ≤CΣ_i∫d_i²dμ，才可能把相应 n 级 score 换成 √n。但对任何仅承载同步差 d=(1,…,1) 的有向 pair，左右比精确为 n；任意 x 依赖 gate 只给该 pair 同一个接收权，不能把比值改成常数。这是对拟议相对协方差证明的代数压力，不是已构造的 FULL 两源反例。来源坐标不独立，p_x 的接收乘积结构本身不使这些 d_i 独立。

**既有压力：score 跳变与似然连续。** 选非退化阈值 r_t 使 bC(r_t/b)/c_j=t，令两来源在 n 个坐标分别位于阈值两侧 r_t−ε、r_t+ε，可有 δ=n，而来源坐标、w_g 及固定参数的 soft 核比随 ε 连续趋同。在避开 hard 跳面的紧接收区域，L_{vu} 可趋0。SJ2 此时迫使实际 good/bad 交通进入窄带 0<B_u≤L_{vu}，这确实是比删门更强的几何信息；但尚须估计该窄带的真实接收质量。此观察没有认证近阈值两源同时满足全部 terminal/history/ρ 条件，不能充作一般反例。

**扩大到自适应参数后的限制。** 不能假设

\[
\int p_x1_{\{0<B_u(x)\le λ\}}dx\lesssim λ
\tag{SJ6?}
\]

具有统一常数。首先 p_xdx 的自适应总质量不等于1；其次对数似然可有平台或极小变化率。比如固定核的 s=1、L=b、u=y 给 p_x=Q_x^*(u)，对数比恒定；这个平台位于 −logK，不在 bad 边界0，本稿**不**把它冒作 SJ6? 或 FULL 的反例。真正需要排除的是原允许参数范围内位于0附近的平台，或选择器随 x 跟踪边界 B_u=0；现有读入估计没有提供相应反集中模量。纯硬核的平台也不能代替原严格 soft 下门的分析。

因此本轮没有证明 SJ6?，也没有证明它在完整原域上不可能。若用 s,L 网格冻结，必须同时控制比值的上下误差及实际单元域，不能只把 p 作单向上包络；其总菜单费仍须支付。这里停止长证明，保留准确窄带候选。

## 3. 短证明、score 关系与完整回代

SJ2 等价于 0<B_u≤L_{vu}。分成 B_u≤λ 与 B_u>λ；后一支有 L_{vu}>λ，所以 1≤exp(σ(L_{vu}−λ))，即得 SJ5。这一证明使用真实 dx 上的逐点门，不用 β 的密度，也不用来源独立性。

权重阈值必须原样保留。由于 t≤g，原权重恒等式给

\[
L_{vu}(x)=\log\frac{Q_x^*(v)}{Q_x^*(u)}
+\log\frac{w_t(u)}{w_t(v)}
+\int_t^{g(x)}[k_r(v)-k_r(u)]\frac{dr}{r}.
\tag{SJ7}
\]

最后一项对持续正 score 差是正号；它并不自动产生 score 衰减。低核门另为

\[
K_uJ_v<\frac{\eta_nT A_vQ_Jw_t(u)\delta}{De_t},\qquad
\eta_n=\frac{4(n+1)^2}{3n}.
\tag{SJ8}
\]

SJ8 不把 SJ7 的似然差或窄带接收质量界成常数。R144 已付 high 部分继续保留其原结论，不在此重复付款。

令 a_ω 为原 hard 帽资格，χ_rest≤1 收集除 good/bad 之外的原正门，仍含原 Ψ、FA、原低门 SJ8、terminal 来源资格、完整窗口、history、已付补集与实际唯一 j 指示。定义原非负基测度

\[
\begin{aligned}
d\mathfrak M={}&\mathbb E\sum_{V,j}d\beta_V(y)\frac{dt}{t}\,dx\,
\frac{p_xh_{R(x)}(x-z)}{q(x)}
a_ω\chi_{rest}\rho_v(x)\,d\nu_V(z)\\
&\quad\cdot\frac{1_{Z_t}(u)1_{Z_t}(v)w_t(u)w_t(v)}{e_t(y)^2}
d\nu_V(u)d\nu_V(v).
\end{aligned}
\tag{SJ9}
\]

若原 ρ 在 good 外定义为零，SJ9 中使用这个原零延拓即可；SJ5 的右端仍是合法上界。共同 α=R_x/Q_J(x) 保留在 ρ，未重分配。原低门正交通有

\[
\boxed{P_{low}\le
\int\delta1_{\{0<B_u\le λ\}}d\mathfrak M
+e^{-σλ}\int\delta
\left[\frac{Q_x^*(v)w_g(u)}{Q_x^*(u)w_g(v)}\right]^σ
1_{\{B_u>λ\}}d\mathfrak M.}
\tag{SJ10}
\]

外 ν、两 e 分母、q、β、所有尺度与原 j 都在 SJ9；没有一个来源或核矩被当作统一常数。σ=0 仅回到删 good 门后的粗正上界。σ>0 的第二项有真实 inverse-Q 与 w_g 比价，不能只登记 e^{-σλ} 的好处。signed 母式另乘 2Λ；原 Ψ 内负项、futurebad、N_del 与 β−ν 各保留原账一次。

原 c_j=γ^{-j}≤1，τ_j≥a、h≤bc_j≤b，所以共同 [a,b] 时间扩张合法；但来源和 j 依赖仍在 SJ10，尚不能提前用唯一 j 合并。没有把某个固定 λ 层级的 q_- 当成跨层常数。

## 4. 为什么仅得到 √n score 仍不足

R140 JT14 的已证回代是：三来源在原实际行消尽、得到同一数值帽 I_j≤B 后，

\[
2ΛP\le6ΛB\log2\,(2n+3)D_nW_β,
\qquad D_n\le3\sqrt n.
\tag{SJ11}
\]

因此即使得到 B=O(√n)，按该菜单回代也只有 O(n²)W_β，而非根阶。要经此接口达到根阶 polylog，需实际共同行帽 B=O(polylog(n)/n)，或直接在 SJ10 的真实接收积分中证明更便宜的联合总价。将方差改写为 √n 而仍逐菜单支付，不能称完成本任务的总价目标。

当前具体未证比较是：对原完整合法域，存在可审核的 λ,σ 及统一费用，使 SJ10 的**窄带项与带权似然尾之和**在原 ν/e²/q、β、j 与全部自适应选择器下达到可吸收 εX 加根阶 polylog Wβ，或至少严格改善原完整 n 级 score 的接收总价。下节实际有限记录表明本批压力点全部位于宽比值支，故近期应优先估计第二项的完整三来源平均；反集中不能解释本批正交通。两项均未付款。

一个可直接核验的固定参数端点如下，记 K_{1,v}=P_{s,L}(x-v)、K_{2,v}=P_{s,L^+}(x-v)、K_{3,v}=J_v。对 0<σ≤1，由 Q_u^*≥J_u/3 及幂的次可加性，

\[
\left(\frac{Q_v^*}{Q_u^*}\right)^σ
\le\frac{(K_{1,v}+K_{2,v}+K_{3,v})^σ}{J_u^σ}
\le\sum_{m=1}^3\left(\frac{K_{m,v}}{J_u}\right)^σ.
\tag{SJ12}
\]

固定 s,L,R,g 与来源 y,z,u,v 后，删除相应正门并用 q≥q_-，SJ10 宽支的固定 pair 接收系数至多

\[
\frac{e^{-σλ}}{q_-}\left(\frac{w_g(u)}{w_g(v)}\right)^σ
\sum_{m=1}^3\prod_{i=1}^n\left\{\frac1R
\int_{z_i-R/2}^{z_i+R/2}p_{s,L}(x_i-y_i)
\left[\frac{k_{m,i}(x_i-v_i)}{b^{-1}\phi((x_i-u_i)/b)}\right]^σdx_i\right\}.
\tag{SJ13}
\]

这是三个完整乘积项，不是 3^n；有限 hard 盒与严格正 J 保证固定来源系数有限。SJ13 舍去的 ρ、low 等正门仍在 SJ10 原式中，不能把其削减另记容量。R138 receiver_source_geometry.md RS3、RS5–7 已有“先形成核比再作固定接收乘积积分”的方法，且已说明实际选择器不能免费冻结；本式是不同 Q 三分量上的可用代数端点，不登记为新的核比理论或付款。自适应参数下只能先用 SJ12 的逐点式，或另付合法单元包络与菜单。w_g(u)/w_g(v)、各来源位移和 Π_t² 平均、外 ν/q 全部仍需付费。

## 5. 现有数据能检查什么

已只读检查 R142 numeric_receiver.json 的字段及其生成器，未新增数值实验或改写数据：完整 Q 已保存，且生成器明确使用 Q=(K1+K2+J)/3，K0 是另一个捕获核。每个接收记录保存 x,p,K0,K1,K2,J,Q,q,QJ,alpha,good,bad,rho,CJ,gates,good_margins；traffic 另含 pair_contributions 与 FA_caps 中的来源、时间段、δ。原 w_g、来源位置、固定参数及 score 段保存在 R136 active_traffic_v2.json 的 atoms/parameters/derived/score_segments。R144 numeric_geometry.json 的 positive_rows 可按 case,id 回连原记录，不能单用其汇总量替代 Q。

后续最小可检字段为：case/id、u/v、原实际 s,L,L⁺,H,g,j、p,Q_u,Q_v,w_g(u),w_g(v)、B_u、L_vu、SJ2 的两端残差、δ、ρ_v、原 low c/η_n、原 Ψ/FA 和外 p·hardmass/q、e_t 与真实 pair 时间贡献。固定 λ 后应同时报窄带贡献与 e^{-σλ}exp(σL_vu) 的全价，且给边界不确定记录；不能只报命中率。

随后数值代理已实际运行本轮 likelihood_band.py，本文读取其 likelihood_band_notes.md 与冻结结果说明：179 个原 receiver 的去重 pair 共690条，全部 B_u>2，预设 λ=.01,.1,1,2 的窄侧覆盖均为0。I1 的 B_u 约5.292–5.592、L_vu约5.457–6.321；P1 initial 最小 B_u约2.22768，L_vu 中位约17.8098；expanded 中位约18.0537；压力点 B_u约15.64–15.79、L_vu约18.84–19.41。因此本批难例是**宽比值／深 bad 支**，不能据 full good/bad 夹带猜其必窄。若 λ=2，所有这些 pair 的 e^{σ(L_vu−λ)}≥1，任何正 σ 都不能把 SJ10 的门罚自身说成点态衰减；只能争取其来源平均或另一个联合比较。

该诊断只读原保存核与来源权，未重算核、未新增抽样；数据的 score 点权没有 dt/t、receiver dx 或采样密度归一化，不是总体积分。本文未另跑实验；有限记录没有一般维数结论，也没有自适应参数连续族的反集中证书。

结论：本轮核准并保留了旧 JR 放松所丢失的完整 Q* 同点夹带；SJ10 与固定参数端点 SJ13 保留其真实费用。有限压力记录把下一步定位到**全 Q 宽比值门的真实三来源平均**，而非窄带反集中。一般低门上的实际 score/receiver 节约尚未证明。任务按明确缺口交付后停止。
