# R146 numeric_score frozen protocol

Owner writes only numeric_score_plan.md, numeric_score.py/json/notes.md in this work directory, no Git or edits to other agents' work. Diagnostic only; no sampling/kernel/quadrature, FULL or empirical exponent claim.

## Inputs and finite model

Use the existing2070 R144 posthoc_capacity_split_screen samples and actual179 necessary-gate receiver IDs. Bind R144 numeric_geometry.json SHA98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517, R142 numeric_receiver.json SHAc46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55, R136 active_traffic_v2.json SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de. Files currently under /Users/zhengzhihao/Desktop/T/output. R143 is unnecessary once the posterior can be recovered from the same exact R142 nu and R136 coordinate thresholds.

R136 stores each atom's n coordinate thresholds and original score segments; R142 stores the same finite model's exact nu, and per receiver good/bad/rho/FA gates. Recover at each saved float time t interpreted as its printed decimal: q_i(t)=1_{threshold_i<t} (strict), k=sum q_i, w=product min(1,threshold_i/t), e=sum nu w and posterior Pi=nu w/e. No coordinate independence assumed. This is the true posterior for the saved finite threshold/nu model, not a certification of true receiver kernels or a general continuous nu/forest. Compare against saved segment-side k and c*t^(-k) weights and report endpoint/rounding discrepancies rather than silently changing labels.

## Exact quantities and inequalities

For independent V,U drawn from the same posterior, compute E_delta=sum Pi_v Pi_u (k_v-k_u)+, mean/variance of k, E[(k_v-k_u)^2]=2Var, and verify E_delta^2<=Var/2. Coordinate marginals p_i=E q_i, diagonal variance Sdiag=sum p_i(1-p_i), off-diagonal aggregate Coff=2sum_{i<j}Cov(q_i,q_j), Var=Sdiag+Coff. Report Var/n, Var/n² and Var/Sdiag (null onzero), Coff/Var, and the actual posterior score mass distribution. Coordinates are recoverable; no surrogate independent product is introduced.

Root benchmark is explicitly the independent-coordinate variance cap Var<=n/4, implying E_delta<=sqrt(n/8). A failure of this cap or benchmark at an existing necessary-gate point is a failure of that pointwise shortcut, not a proof against every constant-times-sqrt(n) estimate and not an asymptotic lower bound from n4/n16. Also report E_delta/sqrt(n), E_delta/n, and gate-specific values.

Compute nested unnormalised posterior contributions: Hgb=sum good(v) bad(u) delta Pi_vPi_u; Hrho adds rho_v; HPsi adds originalPsi; HFA adds actual saved FA cap qualification at t, independently of sample label. All remain submeasures of Pi², never renormalise to conditional iid laws. Require 0<=HFA<=HPsi<=Hrho<=Hgb<=E_delta. For a saved sample's own pair, retain scoreweight delta Pi_vPi_u, rho contribution and original c/eta and FA flags separately; do not infer a low-c distribution for unrecorded pairs from the2070 pair-specific values.

## Three stages, compact output and checks

Preserve original initial/pressure/expanded and uniform/p/pressure labels.2070 samples repeat receiver/time points across source pairs, so compute posterior once per distinct(case,segment,label,t), gated aggregates once per(receiver,time); map all2070 sample identities to compact time model and receiver-time IDs. Summarise by stage/case, by saved FA strict-interior and source where appropriate, with no integration weights. Report both source-sample counts and distinct receiver-time counts, and unweighted finite-menu quantiles only. Existing outer p,hardmass/q may be reported as values/correlations, never invented quadrature.

Use decimal80 for posterior weights/moments and square inequality checks; coordinate bits from exact decimal thresholds, nu as exact numerator/denominator converted at80digits. Recompute at120digits on all distinct time models (small fixed set) to report arithmetic stability. No kernel re-evaluation or full old6951 processing: select179 receiver IDs before any per-row calculations. Record actual input SHA, plan/script SHA, execution status, endpoint discrepancies, max residuals and missing-field limitations. Endpoints use actual strict thresholds for main results; saved one-sided scores and original low-c annotations remain explicit secondary metadata.


## 授权审计修订（第二次producer运行，2026-10-15）

主代理授权最小解冻：直接独立求Eabs=ΣPi_vPi_u|kv−ku|，核E_delta−Eabs/2残差；添加printed-time saved-cap closed语义，兼容旧JSON key但不再将其称为原高精度端点FA的完全恢复。原2070样本/179receiver/6time模型不变。第二次producer替代第一版输出，不新增菜单、核、积分；四文件随后重新冻结。
