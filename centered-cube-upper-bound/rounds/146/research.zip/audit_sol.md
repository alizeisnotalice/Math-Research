# R146 Sol 独立先审：score 能量与实际接收测度

状态：仅审先行候选的接受合同，未读本轮作者稿。已读指定 R135 `source_channel.md`、R145 `source_tail.md` 的 ST9–10 及原费用边界、R140 JT13–14。历史文件取自既有 Desktop/T 输出；本轮只写本文件，不运行 Git，不改他人文件。

## 1. 不依赖来源独立性的准确标量接口

固定原 \(\omega,V,j,y,t\) 后，\(\Pi_t\) 是同一原 \(\nu\) 的概率后验；来源坐标不独立。令 \(k=\sum_i\chi_i\)。两份独立**来源抽样**下，始终有
\[
\mathbb E_{\Pi_t^2}(k_v-k_u)^2=2\operatorname{Var}_{\Pi_t}k,
\qquad
\mathbb E_{\Pi_t^2}(k_v-k_u)_+
\le\sqrt{\operatorname{Var}_{\Pi_t}k/2}.
\]
这些不要求 \(\Pi_t\) 的坐标独立，但也不证明 \(\operatorname{Var}k=O(n)\)。展开方差时所有跨坐标协方差仍在。任意共同 \(\nu\) 和删源下，仅凭 \(0\le k\le n\) 可有 \(O(n^2)\) 方差；这只是一般后验压力，尚不宣称实际全部 good/high/low 门能实现这种极端相关。

若实际 pair 权 \(W(v,u)\ge0\) 不对称，不能再把 \(\int W\delta\) 认成 \(\frac12\int W|k_v-k_u|\)。安全接口是同一实际权上的 Cauchy：
\[
\int W\delta\,d\Pi_t^2
\le\Big(\int Wd\Pi_t^2\Big)^{1/2}
\Big(\int W\delta^2d\Pi_t^2\Big)^{1/2}.
\]
必要时可将 \(\delta^2\le(k_v-k_u)^2\)，但不得删除 W 后继续声称保留了其 low/\(\rho\)/history 收益。若作交换或对称化，须交换整个原权，包括 good/bad、\(\Psi\)、FA、\(\rho\)、hard 支持和 history；交换后的权未必等于原权。

## 2. R135 SC 的乘积结构究竟在哪里

SC2 是逐 \(y\) 的准确概率恒等式上界：
\[
e_t(y)\operatorname{Var}_{\Pi_{y,t}}k
\le\int1_Z(y,v)w_t(y,v)[k_t(y,v)-n\vartheta_t]^2d\nu(v).
\]
删去非负资格 \(1_Z\) 后，**固定来源 v、固定 b,c,t** 的 \(w_t(y,v)dy/z_t^n\) 才是坐标乘积概率，\(\chi_i\) 才是独立 Bernoulli。由此得 SC1/SC4，积分测度明确是 \(e_t(y)dy/z_t^n\)，不是 \(d\beta(y)\)，也不是接收 \(dx\)。删源可以任意，证明没有因此让后验坐标独立。

因此新稿如调用 SC，至少须展示下列一种真实连接：

1. 在保持原 source/receiver 量词后，实际 y/time 边际被有价支配为 SC 的 \(e_t(y)dy/z_t^n\)，并为支配常数、\(\|\nu\|\)、各 j 和层级总和付款；或
2. 直接在原 \(dx\,d\beta(y)\) 测度上证明新的接收加权中心二阶矩，列出其实际来源权与总价。

一般 \(\beta\) 可为原子测度，不能假定存在被 \(e_tdy/z_t^n\) 支配的密度。先对固定来源做 Lebesgue 乘积积分再回到 \(\beta\)，也必须给出这个连接。若接收参数、中心、\(b,c\) 或来源选择器随该积分变量变化，原固定参数的乘积概率证明不能直接套用；须共同包络或重新证明实际加权版本。

## 3. low＋good＋high 目前提供什么二阶信息

R145 已证明同一实际 high/good/low 行的必要门
\[
\frac{J_ve_t}{Q_J}\ge2w_g(v),\qquad
2DK_u(x)w_g(v)<\eta_nTA_vw_t(u)\delta(v,u).
\]
第二式控制 \(K_u/w_t(u)\) 的上尾，等价于对给定其余核量提出一个**score 下阈值**；它不是 \(\delta\) 的上界，也不是跨坐标协方差估计。上述三个门本身未给出 \(\int W\delta^2\) 的根阶改善，更未允许将实际 W 换成独立坐标概率。任何新的改善须以同一实际测度中的联合核/中心能量不等式证明，不能从这条必要门直接宣称得到。

门幂方向同样固定：\(c<\eta_n\) 上 \(G=(\eta_n/c)^\theta\ge1\)。它是上界费用，其倒数不是 score 或二阶矩收益。对 low 指示作正放松后，所得无门二阶矩不再自动保持 low 的几何减少。

## 4. 新 pair-energy／receiver 估计的接受与付款测试

定义原非负交通测度（固定所有原层级，符号下略）
\[
d\mathfrak m=
2\Lambda\,\mathbb E\sum_{V,j}
\frac{p_xh_{R(x)}(x-z)}{q(x)}
a_\omega\chi_{orig}\rho_v1_{low}
\,dx\,d\beta_V(y)\,d\nu_V(z)\,d\Pi_t(u)d\Pi_t(v)\,\frac{dt}{t}.
\]
\(\chi_{orig}\) 包含实际 terminal good／\(D_0\)、原 \(\Psi\)、FA、history、旧已付补集、窗口和唯一 j 指示；其依 z 的部分留在该积分内。一般目标正部是 \(P=\int\delta\,d\mathfrak m\)。新估计的最小接受条件如下。

- **测度一致。** 质量 \(A=\int d\mathfrak m\) 与能量 \(E=\int\delta^2d\mathfrak m\) 必须来自同一原权，或每一次正放松均说明。\(P\le\sqrt{AE}\) 仅是接口；A、E 或新命名的 receiver energy 仍须实际支付。
- **直接接收预算。** 例如同一完整外层下证明 \(A\le C_AW_\beta\)、\(E\le C_En\operatorname{polylog}^2(n)W_\beta\)，才得到根阶正价。允许 \(\varepsilon X\) 分拆，但须列其真实吸收系数及所有剩余项。量纲、原 \(q^{-1}\)、外 hard 来源、两份 e 分母、\(\beta\)、j/time 与层级不能藏到“概率”里。
- **若走 JT14。** 先在每个实际 \(\omega,V,j,x,y,t\) 消尽外 hard 来源和两份 posterior，得到不含 p 的共同数值帽 \(I_j\le B\)，且 B 不依未付来源及 \(j,x,y,t,V\)，此后才能合并唯一 j。原 \(c_j\le1\) 给共同时间窗 \([a,b]\) 和 \(\log2\)。JT14 价格是 \(6\Lambda B\log2(2n+3)D_nW_\beta\)，约为 \(B n^{3/2}W_\beta\)。所以只证逐行 score \(O(\sqrt n)\) 并不产生根阶全局价；若不改进接收包络，须有 \(B=O(\operatorname{polylog}(n)/n)\)。
- **自适应及完整余部。** 核参数在接收点内自适应时，独立坐标能量必须先在真实接收权上成立，或完整付其共同包络/单元费。删除/交换 \(\Psi\) 不创造原负预算；futurebad、\(N_{del}\)、\(D_0\) 外来源、原 \(\Psi\) 内负项及全部未覆盖域仍保留一次，不返还已消费 \(N_Z\)。

上述条件并非断言实际低尾不可能得到二阶改善，而是区分已证 SC、现有门信息与本轮必须新增的同测度不等式。先审结束，等待分配的作者候选；不扩展历史或运行数值。

## 5. pair_energy 作者稿绑定审计

已逐式阅读 `pair_energy.md`，绑定 SHA-256：
`ffc39d525fe1e4f66cfe3258c1ab6df6677597da64c4890fd9af53ab8ad47675`。

**声明范围通过。** PE2 先将正方向 \(\Delta>0\) 纳入 a，再转置**整个 a**，因此 \(P_x=\int W|\Delta|d\Pi^2\) 正确；没有对原不对称 A 直接套半绝对值公式。正负 score 方向互斥，故 \(W\le1/2\)，PE4 的 \(M\le1/2\)、\(D\le\sum m_i(1-m_i)\le n/4\) 系数准确。\(C\) 为非负加权 Gram 矩阵，\(D+F=\int W\Delta^2\ge0\)，但 F 不必非正；中心化本身没有删除跨坐标项。

\(\mathbb E(k-k')_+\le n/4\) 的离散尾分解也正确。作者把 \(F\le CD\) 仅列为尚需证明的条件，并保留一般 \(D+F\le nD\) 的线性障碍，没有把其假设登记为付款。PE5 正确识别：固定 y,u,v,t 的 \(d_id_j\) 不依接收 x，乘积接收核不会自动令它消失。PE6 的 low 门随正 score 增大而放宽，不提供逆 score 稀疏性。

PE7 保留原 \(q^{-1}\)、外 hard 来源、\(d\beta\)、两份 \(\Pi_t\) 的 e 分母、原门和全部外层。它是合法代入接口；作者明确没有证明右侧总价，亦没有把逐行根阶称作全局根阶。原负项、futurebad、\(N_{del}\) 及已付 high 均未改账。SC 的 dy 与原 \(\beta\) 区别正确，无数学更正。

## 6. numeric_score 实现的独立代码核查

本次先读脚本、计划和 JSON，再追到原 R142 `numeric_receiver.py` 的 Model/traffic 实现；没有以作者说明代替实现审核。

**原有限模型恢复正确。** 脚本使用 R142 `nu_exact` 而非 R136 初始 atom.nu；这是必要的，因为 R142 同位置模型已经修改过来源质量。原 producer 的 Model 确实沿用同 case 的 R136 六源位置、thresholds、score segments，R142 的 \(\Psi\) 用这些相同 score 段重建并核对原 36 个标签。脚本按原六源次序对 threshold 作严格 \(a_i<t\)、直接乘积恢复 w，再以 \(\nu_iw_i/e\) 归一，未引入坐标独立性。这里沿用六源全窗口模型；没有恢复一般 forest 或额外 \(Z_t\) 删除机制，不能将结果外推至那些对象。

**门嵌套正确但须分清端点语义。** good/bad、\(\rho\) 来自同一 R142 receiver；\(\Psi\) 来自相同来源几何；FA caps 由原 producer 在同一 good/bad/\(\rho\)/\(\Psi\) 正方向生成。脚本所有阶段均为原 \(\Pi_t^2\) 的非负子测度，没有将 gated 来源条件归一。未门化的半绝对值／方差界没有被误套给 gated 量。本审计另扫实际正 good→bad 贡献的 CJ：所审 receiver-time 中没有 \(\rho_v>0\)、正 score 且 CJ>3 的 contributor；脚本的 raw 资格在这些实际贡献上没有暗中加入坏 CJ 贡献。

发现并要求作者修正两点：

1. 初稿代码仅检查 \((\mathbb E\delta)^2\le\operatorname{Var}k/2\) 及 \(\mathbb E(k-k')^2=2\operatorname{Var}k\)，没有显式计算要求核验的 \(\mathbb E\delta=\frac12\mathbb E|k-k'|\)。应新增直接绝对值矩及恒等式残差。
2. `qualifies` 对打印 decimal t 与保存 R142 cap 作闭区间包含判断，与 R144 先用高精度段端点后打印的旧 flag 在 257 个 hi_left source-samples 不一致（I1 33、P1 224）。因此该输出是 **printed-time saved-cap closed** 诊断，不是完全恢复原高精度 endpoint flag；字段语义与说明须明确区分。strict interior 的原/新 flag 无差异。不能把闭端点差异当成正时间质量或原 FA 收益。

这两项均已发给作者，主代理随后授权最小解冻修订；待最终重跑绑定。

## 7. 独立精确复核与统计口径

本审计实际用标准库 Fraction 对六个时间模型重算：R136 保存 decimal thresholds、保存打印 decimal t 均精确转有理数，R142 `nu_exact` 原样转有理数，逐坐标计算 bits/w，再算同一 posterior 的矩。六例全部**精确**满足
\[
\mathbb E\delta=\tfrac12\mathbb E|k-k'|,\quad
\mathbb E(k-k')^2=2\operatorname{Var}k,\quad
(\mathbb E\delta)^2\le\operatorname{Var}k/2.
\]
同时核对来源数、坐标长度、\(n\)、严格 score、原 \(\nu\) 质量 1 与正性。e、Var、\(\mathbb E\delta\) 和 JSON 的 32 位输出最大相对舍入差约 \(3.58\times10^{-32}\)。这是所存 decimal 有限模型的精确代数验证，不是真实 kernel/FA 标签的区间认证。

统计口径已从代码与数据独立核对：两种来源配置 I1/P1，各三个固定时间，总共 **6 个 posterior time-models**；179 个 receiver，共 **537 个 receiver-times**；2070 是重复映射到这些对象的 pair/segment/time 保存记录，不是 2070 个独立来源抽样或接收样本。I1 的 33 个 variance-cap 失败 receiver-times 只重复三个共同 posterior 模型。n=4/16、既有必要门、冻结阈值来源与旧核误差不足以证明或否定一般维数渐近式。

## 8. numeric_score 最小修订的最终绑定

作者经主代理授权完成两项最小修订并第二次执行同一 producer。本次仅核修订代码、输出及语义，不重复第 7 节的 Fraction 计算，不重跑 kernel 或扩样。

最终 SHA-256：

- `numeric_score_plan.md`：`b7031c9b1d2494619dcc4d79cc52da427fda9867e7876dcf5d9553fe79955800`
- `numeric_score.py`：`e1d3a15f71d9f0b2183d84398397333f1995e5f74f848f05699120942b56339b`
- `numeric_score.json`：`6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879`
- `numeric_score_notes.md`：`92ddb6b328809294c2663e39e04c443e17196a3ac5a0d221e7965db7d0ef0caf`

已核 JSON 内 plan/script SHA 对应实际文件。代码直接独立求绝对差矩，没有以 \(2\mathbb E\delta\) 赋值；最大 \(|\mathbb E\delta-\mathbb E|k-k'|/2|=4\times10^{-80}\)，正确 iid 平方界及门嵌套无正超额。`FA_closed_semantics` 明确兼容旧字段仅代表打印时间的保存 cap 闭区间包含，旧原 FA flags 另存；说明已改为同一明确口径。257 个 closed 与 0 个 strict-interior 差异继续真实报告，没有用端点差异修改旧样本或推断时间质量。

**最终通过。** 两项实际审查问题均已修复；第 5 节 pair-energy 绑定稿与本节数值四文件均在声明范围通过。结果认证有限模型代数及门诊断，不认证一般 receiver/FULL、一般维度根阶或原总付款。仅写本审计文件，无 Git、无他人文件修改；分配范围结束。
