# R146 numeric_score：后验score方差与原门

已按冻结协议执行初版一次，并按主代理授权执行审计修订版第二次；两次均exit0，原菜单不变，第一版输出由经审修订版替代。只读R136阈值、R142同一份精确nu与179个指定receiver标签，以及R144既有2070个source/time记录；无新接收点、核值、积分或旧6951行统计。2070个source-sample对应537个receiver-time，仅6个不同后验时间模型。所有输出位于本work四文件，不改他人文件、无Git。

主要结果是：I1实际必要门点已经不能使用“后验坐标独立、Var k≤n/4”的捷径，但正确的同一后验两次iid抽取界Eδ≤sqrt(Var k/2)仍全部成立。原good/bad/rho门又把I1的贡献降到无门值约1.2%—1.4%。所以不能把无门方差障碍直接算成原正交通，更不能从两个维数外推否定任意C sqrt(n)预算。

## 1. 恢复对象与数值合法性

对R144打印保存时间t作精确十进制解释，逐atom、逐坐标从R136阈值a_i恢复q_i=1_{a_i<t}、k=sum q_i、w=product min(1,a_i/t)，再用R142 nu_exact恢复e=sum nu w、Pi=nu w/e。严格阈值与保存one-sided score在6个时间模型上完全一致；直接乘积w与保存segment coefficient表达的最大相对差4.89e−79。本模型全部六源沿用既有有限窗口，没有补造一般forest或Z删除机制。

坐标bits可完整恢复，所以没有以独立Bernoulli替代真实Pi。Var k由中心二阶矩计算，同时独立计算Sdiag=sum Var(q_i)与Coff=2sum_{i<j}Cov(q_i,q_j)。原good/bad/rho和FA标签来自保存接收行，仅是旧数值标签，不是新真核区间证书。

## 2. 六个真实后验时间模型

I1 n=4，score只取0和4，所有坐标bits在每个atom上相同，形成完全相关。下表每行对应一个不同时间模型，按原stage重复遇到它并不增加独立信息。

| case/time | posterior score质量摘要 | Eδ | Var k | Sdiag | Coff |
|---|---|---:|---:|---:|---:|
| I1 t=.5 | P(k4)=.5292683 | .9965735 | 3.986294 | .9965735 | 2.989720 |
| I1 几何中点 .56037264 | P(k4)=.4161087 | .9718490 | 3.887396 | .9718490 | 2.915547 |
| I1 hi左侧 .62803499 | P(k4)=.3111510 | .8573442 | 3.429377 | .8573442 | 2.572032 |
| P1 t=.5 | P(k8)=.9999997614 | 1.908499e−6 | 1.526799e−5 | 1.908499e−6 | 1.335949e−5 |
| P1 几何中点 .62821035 | P(k8)=.9999999585 | 3.322352e−7 | 2.657882e−6 | 3.322352e−7 | 2.325646e−6 |
| P1 hi左侧 .78929649 | P(k8)=.9999999740 | 2.081307e−7 | 1.665045e−6 | 2.081307e−7 | 1.456915e−6 |

I1 Var/Sdiag恰4，Coff占总方差75%，Var/n=.8573—.9966而非≤.25。故独立坐标帽sqrt(n/8)=.707107失效：三个Eδ/该帽分别1.40937、1.37440、1.21247。无门iid界sqrt(Var/2)没有失败，Eδ/该正确界约.7059、.6971、.6547。

P1 n=16的score是0、8、16，但Pi几乎集中在G4的k8；P(k16)从2.38048e−7降至6.17309e−9，P(k0)从5.14578e−10升至1.98432e−8。Var/Sdiag约8，Coff占87.5%，坐标相关仍在；只是绝对方差很小。其Eδ/sqrt(n/8)仅1.47e−7至1.35e−6，因此现有P1点不构成根阶帽压力，不能从“相关”单独推出交通大。

I1的Eδ/sqrt(n)约.4287—.4983，仍小于1；n4与n16不是能检验渐近指数的序列。本诊断严格否定的是独立坐标n/4方差替换及其指定常数的帽，并未否定所有普适常数C的C sqrt(n)后验估计。

## 3. 三阶段保留原门，始终不作条件归一化

定义无门Eδ=sum Pi_v Pi_u(k_v−k_u)+。顺次保留good(v)bad(u)、rho_v、原Psi、原FA cap及strict interior，所有量都是同一Pi²的非负子测度。脚本逐项核对

H_FA,interior ≤ H_FA,closed ≤ H_Psi ≤ H_rho ≤ H_goodbad ≤ Eδ。

没有把选中的good/bad来源重归一成新的iid后验。下表的分位只对有限receiver-time点计数，无积分权。

| 原阶段/case | 不同receiver | receiver-time | Var帽及指定根帽失败数 | H_rho/Eδ范围 |
|---|---:|---:|---:|---:|
| initial I1 | 2 | 6 | 6 / 6 | .0129007—.0141146 |
| initial P1 | 25 | 75 | 0 / 0 | .236470—.996995 |
| pressure I1 | 0 | 0 | — | — |
| pressure P1 | 5 | 15 | 0 / 0 | .236861—.996441 |
| expanded I1 | 9 | 27 | 27 / 27 | .0121431—.0137959 |
| expanded P1 | 138 | 414 | 0 / 0 | .236422—.997374 |

I1的H_goodbad/Eδ在全部33 receiver-time上固定约.01796998，rho再削减到上表。H_rho绝对值约.01041—.01407；本轮打印时间saved-cap闭端点约定下，I1三个时间的closed值不再削减，strict interior只保留几何中点，端点不当作正时间质量。I1无门Eδ主要来自bad far B→bad G4，单看无门posterior会把与原good→bad正项无关的交通也算进来。

P1的H_rho绝对值约4.92e−8—1.90e−6。三个时间的H_goodbad/Eδ分别约.997843、.923056、.237278，体现末端无门交通逐渐由G4→CORE承担，而该方向不在原good→bad正项内。部分FA截窗在几何中点前结束，closed/strict两种结果及其零值如实保留；不能把有限点零值推成整个段交通为零。

## 4. 原scoreweight与low c保持两份记录

2070条原pair记录均保存：实际delta、delta Pi_vPi_u、rho乘积、原c/eta以及原/当前打印时间的FA标记。没有把c小解释为大scoreweight，也没有再用倒数门收益。

P1 G1的原点scoreweight范围约4.94e−8—1.90e−6，而far B约3.95e−24—1.52e−22；far B的c/eta反而更极低（中位约1.54e−18，G1约1.16e−13）。因此极低c尾与主要posterior交通不是同一来源。source摘要分开报告scoreweight和low c，而不发明二者的积分耦合。

所有实际delta与保存source段delta一致。257条closed FA标记与R144原标记不同，全发生hi_left打印点（I1 33条、P1 224条）：旧R144内部曾以高精度段端点作资格比较后再打印float，本轮按打印decimal重建，闭端点包含关系在舍入尺度改变。strict interior标记0差异。代码同时保留两个版本，未覆盖旧low-c值或据此改变原样本集合；主posterior模型score和w没有相应实质差异。

## 5. 对后续估计的含义与误差账

真实任意nu可以让坐标bits高度相关；乘积w倾斜不会自动让Pi坐标独立。要仅靠posterior score做点上根阶控制，必须另证总协方差或整个Var的约束，不能免费使用sum坐标方差≤n/4。本菜单I1在真实必要门点上已经展示该捷径失败。

但原门保留后I1交通很小，且P1 posterior本身几乎单score集中。因此目前不能断言接收积分一定要修复一个已证线性下界。需要在原good/bad/rho/Psi/FA与接收外权下控制相关来源的平均贡献；丢门后再尝试无门根阶帽会损失本例中98%以上的实际选择。上述33个I1 receiver-time失败仅来自3个共同时间模型，不能当作33个独立反例或一般维度证据。

数值检查：Pi归一残差最大2e−80；Var−Sdiag−Coff最大1.08e−78；E[(k−k')²]−2Var最大4e−79；Eδ²≤Var/2及所有门嵌套检查均无正超额。80/120位比较最大相对变化6.49e−73。保存阈值/质量的高精度算术不等于真实核区间认证；接收门仍继承R142的既有核误差范围。

交付只含冻结计划、最终脚本、紧凑JSON和本说明。脚本支持--input-root指定旧数据根目录，默认原output路径，先核三个输入SHA；不依赖R143或外部科学计算包。最终代码实际执行第二次producer，非仅AST检查。完成停止。


## 授权审计修订与最终版本

审计要求的绝对差恒等式现直接独立求和Eabs=ΣPi_vPi_u|kv−ku|，而非从2Eδ赋值；JSON保存E_abs_score_difference和abs_identity_residual，检查Eδ=Eabs/2。兼容JSON旧key FA_closed_rho_good_bad与actual_saved_cap_closed明确只表示printed-time saved-cap closed membership，不保证原高精度端点FA恢复；原标记另存。主代理授权后仅作这两项最小修复，并重跑同一producer作为第二次运行，未扩大实验。最终残差与文件SHA由交付消息绑定。


第二次producer的直接绝对差身份残差max|Eδ−Eabs/2|=4e−80，正确iid界与门嵌套仍零正超额；模型数、stage统计和原数值结论未变。
