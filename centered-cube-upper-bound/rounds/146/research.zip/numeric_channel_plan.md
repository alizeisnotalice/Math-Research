# R146 finite rational product-channel protocol (frozen before execution)

Own only numeric_channel.py/json/plan.md/notes.md in this directory; no Git, PDF, old receiver samples, original-C or FULL claims. The finite channel follows R135 channel_numeric.py but makes receiver weights and source mixtures explicit. Standard library only, exact Fraction arithmetic, no random search or numerical quadrature.

Space: y,v∈(Z/3Z)^n, counting receiver measure. q(0)=1/2, q(1)=q(2)=1/4; K(y−v)=∏q(y_i−v_i), so Σ_yK=1. Score k(y,v)=Σ_i 1{y_i≠v_i}; a_i=1{y_i≠v_i}−1/2, Σa_i=k−n/2. At fixed v under K each a_i is centered, independent, variance1/4. Source probabilities need not factor.

Source priors: diagonal three atoms v=j1_n, weights(1,2,3)/6; general mixture four atoms 0_n,1_n, alternating(0,1), periodic(0,2,1), weights(1,2,3,4)/10 (merge duplicate atoms); balanced correlated prior on j1_n with weights (1,2^n,2^n)/(1+2^(n+1)). All probabilities are exact.

Receiver weights: unit r=1; product r=∏[3,1,2]_{y_i}/2; spike r=1+12^n 1{y=0_n}. Each is fixed as a function of y only. Deletion Z(y,v): all; correlated 1{(Σy+2Σv) mod3≠0}; sparse 1{(Σ(i+1)y_i+Σv_i) mod3=0}. These are arbitrary deterministic deletions, not monotone real-time Z or actual original geometry.

Frozen 24 cases, three stages:
1. Initial: n=1,2 × source diagonal/general × receiver unit/spike × mask all =8.
2. Pressure: n=4 × source general/balanced × receiver unit/product/spike × mask all/correlated =12.
3. Expanded: n=6 × source general/balanced × receiver product/spike × mask sparse =4.

For e_Z(y)=ΣνKZ and Π_Z=νKZ/e_Z (zero-e sites contribute0), compute weighted mass M_Z=Σr e_Z separately, energy E_Z=Σr e_Z VarΠ k, retained fixed-center B_Z=ΣrΣνKZ(k−n/2)^2, full B_full similarly without Z, and centering penalty P_Z=Σr e_Z(EΠk−n/2)^2. Verify exactly E_Z=B_Z−P_Z≤B_Z≤B_full. No divide by M before proving these raw-mass identities; normalized values are reported separately.

Compute source-center cross matrices A_ij=ΣrΣνKZ a_i a_j and posterior covariance matrices C_ij=Σr[ΣνKZ a_i a_j−(ΣνKZ a_i)(ΣνKZ a_j)/e_Z]. Verify B_Z=n M_Z/4+2Σi<jA_ij and E_Z=Σ_iC_ii+2Σi<jC_ij. The full undeleted source matrix under unit r must have A_ij=0 for i≠j even for correlated ν. With receiver weighting/deletion these entries need not vanish. Test, do not assume, diagonal-only bound E_Z≤nM_Z/4; report every violation and all masks/dimensions. Also report covariance signs, ratios, retained mass fraction, source/receiver normalizers, and complete matrices so cancellations can be audited.

Intended conclusion is exact algebra and concrete cancellation failure in this finite channel only. Weighted r(y) cannot be dropped, and source normalization Σν=1 does not imply M_Z=1. No root-order or original centered-C conclusion will be drawn. Stop after four-file delivery.
