# R146 likelihood_band 独立冻结协议

仅新增likelihood_band_plan.md、likelihood_band.py/json/notes.md，原numeric_score四文件冻结不改。只读R142 numeric_receiver.json（SHA c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55）、R136 active_traffic_v2.json（SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de）、R144 numeric_geometry.json（SHA98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517）和同work原numeric_score.json（SHA6e103db84e39cdd9bc8a874083f83a83bb1d5797ab180f4b86c1482940821879）。不重算核/接收点/原6951统计、不求积、不Git、不改他人文件。

## 准确对象

从R144既有pair-segment按(case,receiver id,v,u)去重复，保留原stage/distribution；以R142同一receiver的p、Q_v,Q_u和R136原wg_v,wg_u,K计算
b=log[p wg_u/(K Q_u)]>0，a=log[K Q_v/(p wg_v)]>=0，width=a+b=log[(Q_v/wg_v)/(Q_u/wg_u)]。
这恰是full双门KQ_u/wg_u<p<=KQ_v/wg_v。Q始终为原(K1+K2+J)/3，不以J替代。K如按case不同则逐case保留。wg=0、Q=0、非正p或缺字段保留失败/null，不除零、不悄悄删行；本菜单能否出现由实际核查决定。

## 固定统计

原initial/pressure/expanded、case、good来源和uniform/p/pressure分层，给pair去重计数与179receiver计数、a/b/width的min,10%,median,90%,99%,max（线性经验分位）。固定lambda=.01,.1,1,2，报告b<=lambda的pair比例、至少一个pair命中的receiver比例、全部已有pair命中的receiver比例。另报告width<=lambda的pair比例，将bad侧窄带与整个双门区间窄带区分，不因见到b小就说width小。

保留pair记录对应原三个t的closed/interior标记，pair分布不按时间复制。使用已算numeric_score.json的delta Pi_vPi_u和rho乘积，仅在同一2070点菜单内作sum-weight覆盖描述；分全点、原saved FA_closed/strict、当前打印时间actual FA_closed/strict分别统计，以明确端点舍入资格差别。无时间长度、接收dx或流抽样归一化权，不称原交通积分/概率。权为0时分母null。

## 校核与输出

使用decimal80对保存十进制字段计算全部a,b,width和核Q算术，120位复核去重pair（只标量log）并报告最大差。核Q保存值与(K1+K2+J)/3的绝对/相对舍入误差逐row/source汇总，负小margin不截零；逐pair核good_v、bad_u、a/b符号及log宽度恒等式。source wg与K来自原模型，不推定角色永远good。

一次脚本从绑定SHA输入生成全部JSON；完整去重pair记录及2070点资格/权的compact引用保留，UTC/elapsed非确定。只判断现有必要门菜单落在窄bad带还是较宽比值支，不作反集中、一般尾概率、维数阶或FULL结论。完成停止。


## 输入绑定更新

主代理随后授权numeric_score两项最小审计修订，其第二版输出仅补绝对差身份和FA语义。likelihood_band在数值初跑后更新为绑定该最终numeric_score SHA再运行一次；原pair、Q核、样本权和菜单不变。第一版band输出被最终经审输入绑定版本替代，不新增实验。
