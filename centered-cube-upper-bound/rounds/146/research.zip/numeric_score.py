#!/usr/bin/env python3
"""Frozen posterior score diagnostic on existing R144 sample times. No kernels/quadrature."""
import json,hashlib,math,time,datetime,argparse
from pathlib import Path
from decimal import Decimal as D,localcontext
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output');args=parser.parse_args();BASE=Path(args.input_root)
INPUTS={'screen':('centered_cube_round144_20261015/numeric_geometry.json','98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517'),'receiver':('centered_cube_round142_20261015/numeric_receiver.json','c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'),'source':('centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def st(x):return format(x,'.32g') if isinstance(x,D) else x
def rat(a,b):return float(a/b) if b else None
def quant(v):
 v=sorted(x for x in v if x is not None)
 if not v:return {'N':0}
 out={'N':len(v)}
 for p in [0,.1,.5,.9,.99,1]:
  u=(len(v)-1)*p;i=int(u);out[str(p)]=v[i]+(v[min(i+1,len(v)-1)]-v[i])*(u-i)
 return out
start=time.monotonic();data={};hashes={}
for k,(rel,expected) in INPUTS.items():
 p=BASE/rel;actual=sha(p);assert actual==expected,(k,actual);hashes[k]=actual;data[k]=json.loads(p.read_text())
sources={c['id']:c for c in data['source']['cases']};pairs=data['screen']['posthoc_capacity_split_screen']['pair_segment_records'];assert len(pairs)==690
wanted={(p['case'],p['id']) for p in pairs};receivers={}
for cid,c in data['receiver']['cases'].items():
 for r in c['records']:
  if (cid,r['id']) in wanted:receivers[(cid,r['id'])]=r
assert len(receivers)==179
specs={}
for p in pairs:
 for s in p['samples']:
  key=(p['case'],p['segment'],s['label'],str(s['t']));specs[key]=len(specs) if key not in specs else specs[key]

def posterior(spec,precision):
 cid,si,label,ttext=spec;src=sources[cid];case=data['receiver']['cases'][cid];n=case['n']
 with localcontext() as ctx:
  ctx.prec=precision;t=D(ttext);thresholds=[[D(x) for x in a['thresholds']] for a in src['atoms']];nu=[D(x['numerator'])/D(x['denominator']) for x in case['nu_exact']];bits=[[int(a<t) for a in aa] for aa in thresholds];ks=list(map(sum,bits));w=[]
  for aa in thresholds:
   v=D(1)
   for a in aa:v*=min(D(1),a/t)
   w.append(v)
  e=sum(nu[i]*w[i] for i in range(6));pi=[nu[i]*w[i]/e for i in range(6)];mean=sum(pi[i]*ks[i] for i in range(6));var=sum(pi[i]*(D(ks[i])-mean)**2 for i in range(6));ed=sum(pi[v]*pi[u]*max(ks[v]-ks[u],0) for v in range(6) for u in range(6));eabs=sum(pi[v]*pi[u]*abs(ks[v]-ks[u]) for v in range(6) for u in range(6));second=sum(pi[v]*pi[u]*(ks[v]-ks[u])**2 for v in range(6) for u in range(6));coord=[sum(pi[v]*bits[v][j] for v in range(6)) for j in range(n)];diag=sum(x*(1-x) for x in coord);covs=[]
  for j in range(n):
   for k in range(j+1,n):covs.append(sum(pi[v]*bits[v][j]*bits[v][k] for v in range(6))-coord[j]*coord[k])
  off=2*sum(covs);covmin=min(covs) if covs else D(0);covmax=max(covs) if covs else D(0);bound=(var/2).sqrt();root=(D(n)/8).sqrt();scoremass=defaultdict(lambda:D(0))
  for i in range(6):scoremass[ks[i]]+=pi[i]
  savedseg=src['score_segments'][si];segw=[D(savedseg['c'][i])*t**(-savedseg['k'][i]) for i in range(6)]
  return {'case':cid,'n':n,'segment':si,'label':label,'t':ttext,'score':ks,'coordinate_bits':bits,'w':w,'e':e,'pi':pi,'score_mass':dict(scoremass),'mean_k':mean,'var_k':var,'E_delta':ed,'E_abs_score_difference':eabs,'abs_identity_residual':ed-eabs/2,'E_delta_bound':bound,'root_independent_coordinate_benchmark':root,'diag_coordinate_variance':diag,'offdiag_covariance_aggregate':off,'pair_covariance_min':covmin,'pair_covariance_max':covmax,'coordinate_marginals':coord,'var_identity_residual':var-diag-off,'second_moment_identity_residual':second-2*var,'iid_square_inequality_residual':ed*ed-var/2,'segment_score_disagreement':ks!=savedseg['k'],'max_relative_w_vs_saved_segment':max(abs(w[i]-segw[i])/w[i] for i in range(6)),'posterior_mass_residual':sum(pi)-1,'var_over_n':var/n,'var_over_n_squared':var/(n*n),'var_over_diag':var/diag if diag else None,'offdiag_fraction':off/var if var else None,'E_delta_over_sqrt_n':ed/D(n).sqrt(),'E_delta_over_n':ed/n,'E_delta_over_root_benchmark':ed/root,'E_delta_over_variance_bound':ed/bound if bound else None,'var_cap_n_over4_fails':var>D(n)/4,'root_benchmark_fails':ed>root}
models={};checks={'distinct_time_models':len(specs),'max_posterior_mass_residual':0.,'max_var_identity_residual':0.,'max_second_identity_residual':0.,'max_abs_identity_residual':0.,'max_iid_square_inequality_positive_excess':0.,'max_precision_relative_change':0.,'segment_score_disagreements':0,'max_w_vs_saved_segment_relative':0.,'max_nested_gate_positive_excess':0.,'own_FA_vs_original_flag_disagreements':0,'own_strict_FA_vs_original_flag_disagreements':0}
for spec,index in specs.items():
 m=posterior(spec,80);hi=posterior(spec,120)
 for key in ['mean_k','var_k','E_delta','E_abs_score_difference','diag_coordinate_variance','offdiag_covariance_aggregate']:
  if hi[key]:checks['max_precision_relative_change']=max(checks['max_precision_relative_change'],float(abs(m[key]-hi[key])/abs(hi[key])))
 checks['max_posterior_mass_residual']=max(checks['max_posterior_mass_residual'],float(abs(m['posterior_mass_residual'])));checks['max_var_identity_residual']=max(checks['max_var_identity_residual'],float(abs(m['var_identity_residual'])));checks['max_abs_identity_residual']=max(checks['max_abs_identity_residual'],float(abs(m['abs_identity_residual'])));checks['max_second_identity_residual']=max(checks['max_second_identity_residual'],float(abs(m['second_moment_identity_residual'])));checks['max_iid_square_inequality_positive_excess']=max(checks['max_iid_square_inequality_positive_excess'],float(max(m['iid_square_inequality_residual'],D(0))));checks['segment_score_disagreements']+=m['segment_score_disagreement'];checks['max_w_vs_saved_segment_relative']=max(checks['max_w_vs_saved_segment_relative'],float(m['max_relative_w_vs_saved_segment']));m['time_id']=index;models[index]=m
rt={};sample_records=[]
with localcontext() as ctx:
 ctx.prec=80
 for p in pairs:
  cid=p['case'];r=receivers[(cid,p['id'])];src=sources[cid]
  assert all(r['gates'].values()) and r['traffic']['positive_raw'] and not r['uncertain']
  assert all(0<=rho<=1 for rho in r['rho'])
  for s in p['samples']:
   spec=(cid,p['segment'],s['label'],str(s['t']));tid=specs[spec];m=models[tid];pi=m['pi'];ks=m['score'];t=D(str(s['t']));rtkey=(cid,r['id'],tid)
   def qualifies(v,u,strict=False):
    cap=next((z for z in r['traffic']['FA_caps'] if z['segment']==p['segment'] and z['v']==v and z['bad']==u),None)
    if not cap:return False
    return D(str(cap['lo']))<t<D(str(cap['hi'])) if strict else D(str(cap['lo']))<=t<=D(str(cap['hi']))
   if rtkey not in rt:
    gb=rho=ps=fa=interior=D(0)
    for v in range(6):
     for u in range(6):
      delta=max(ks[v]-ks[u],0);weight=pi[v]*pi[u]*delta
      if not(r['good'][v] and r['bad'][u]):continue
      gb+=weight;rr=weight*D(str(r['rho'][v]));rho+=rr
      if not src['pairs'][v*6+u]['Psi']:continue
      ps+=rr
      if qualifies(v,u):fa+=rr
      if qualifies(v,u,True):interior+=rr
    seq=[m['E_delta'],gb,rho,ps,fa,interior];checks['max_nested_gate_positive_excess']=max(checks['max_nested_gate_positive_excess'],max(float(max(b-a,D(0))) for a,b in zip(seq,seq[1:])))
    rt[rtkey]={'receiver_time_id':len(rt),'case':cid,'id':r['id'],'stage':r['stage'],'distribution':r['distribution'],'time_id':tid,'p':r['p'],'hardmass_over_q':r['hardmass']/r['q'],'good':r['good'],'bad':r['bad'],'rho':r['rho'],'good_bad':gb,'rho_good_bad':rho,'Psi_rho_good_bad':ps,'FA_closed_rho_good_bad':fa,'FA_strict_interior_rho_good_bad':interior,'good_bad_over_ungated':rat(gb,m['E_delta']),'rho_over_ungated':rat(rho,m['E_delta']),'FA_closed_over_ungated':rat(fa,m['E_delta']),'FA_interior_over_ungated':rat(interior,m['E_delta'])}
   v=p['v'];u=p['u'];delta=max(ks[v]-ks[u],0);own=pi[v]*pi[u]*delta;actual_fa=qualifies(v,u);actual_inner=qualifies(v,u,True);checks['own_FA_vs_original_flag_disagreements']+=actual_fa!=s['FA_closed'];checks['own_strict_FA_vs_original_flag_disagreements']+=actual_inner!=s['FA_strict_interior'];sample_records.append({'receiver_time_id':rt[rtkey]['receiver_time_id'],'case':cid,'id':r['id'],'time_id':tid,'v':v,'u':u,'v_name':p['v_name'],'u_name':p['u_name'],'actual_delta':delta,'saved_delta':p['delta'],'scoreweight':own,'rho_scoreweight':own*D(str(r['rho'][v])),'saved_low_c_over_eta':s['c_over_eta'],'saved_Psi':s['Psi'],'saved_FA_closed':s['FA_closed'],'saved_FA_strict_interior':s['FA_strict_interior'],'actual_saved_cap_closed':actual_fa,'actual_saved_cap_strict_interior':actual_inner})
assert len(sample_records)==2070
rtrows=list(rt.values())
def summarise(rs):
 out={'receiver_time_N':len(rs),'receiver_N':len({(r['case'],r['id']) for r in rs}),'time_model_N':len({r['time_id'] for r in rs})}
 if not rs:return out
 out['timepoint_variance_cap_failures']=sum(models[r['time_id']]['var_cap_n_over4_fails'] for r in rs);out['timepoint_root_benchmark_failures']=sum(models[r['time_id']]['root_benchmark_fails'] for r in rs)
 metrics=['E_delta','var_k','diag_coordinate_variance','offdiag_covariance_aggregate','var_over_n','var_over_n_squared','var_over_diag','offdiag_fraction','E_delta_over_sqrt_n','E_delta_over_n','E_delta_over_root_benchmark','E_delta_over_variance_bound']
 out['posterior']={k:quant([float(models[r['time_id']][k]) if models[r['time_id']][k] is not None else None for r in rs]) for k in metrics}
 out['gated']={k:quant([float(r[k]) for r in rs]) for k in ['good_bad','rho_good_bad','Psi_rho_good_bad','FA_closed_rho_good_bad','FA_strict_interior_rho_good_bad','good_bad_over_ungated','rho_over_ungated','FA_closed_over_ungated','FA_interior_over_ungated']}
 return out
strata={stage:{cid:summarise([r for r in rtrows if r['stage']==stage and r['case']==cid]) for cid in ['I1','P1']} for stage in ['initial','pressure','expanded']}
source_summaries={}
for cid in ['I1','P1']:
 for name in sorted({r['v_name'] for r in sample_records if r['case']==cid}):
  rs=[r for r in sample_records if r['case']==cid and r['v_name']==name];source_summaries[cid+'/'+name]={'sample_N':len(rs),'own_scoreweight':quant([float(r['scoreweight']) for r in rs]),'own_rho_scoreweight':quant([float(r['rho_scoreweight']) for r in rs]),'low_c_over_eta_separate':quant([r['saved_low_c_over_eta'] for r in rs]),'scope':'Separate point values, no multiplication by invented time/receiver integration weights.'}
def clean(x):
 if isinstance(x,D):return st(x)
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
out={'status':'completed_saved_posterior_diagnostic','producer_execution_count':2,'execution_history':'Initial producer output superseded by audit-authorized second run adding direct absolute-difference identity and explicit printed-time saved-cap FA semantics; same menu, no kernel or sample expansion.','FA_closed_semantics':'Compatibility keys FA_closed_rho_good_bad and actual_saved_cap_closed mean printed-time saved-cap closed membership only, not exact recovery of original high-precision endpoint FA. Original saved_FA_closed flags remain separate; strict interior checked separately.','executed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashes,'plan_sha256':sha(ROOT/'numeric_score_plan.md'),'script_sha256':sha(Path(__file__)),'scope':'Exact saved finite threshold/nu posterior at2070 existing screen observations,80/120 digit arithmetic; no kernels/quadrature/sampling/FULL/dimension fit. Conditional gates are submeasures and never renormalised.','checks':checks,'selected_receivers':len(receivers),'sample_N':len(sample_records),'receiver_time_N':len(rtrows),'time_models':[models[k] for k in sorted(models)],'strata':strata,'source_scoreweight_and_low_c_separate':source_summaries,'receiver_times':rtrows,'samples':sample_records,'unavailable_or_unproved':['No true-kernel interval certificate for receiver good/rho/FA labels','No general continuous nu or forest/deletion representation beyond frozen six-source model','Three sampled times are not time integration or probability weights','Only n4 and n16 do not test asymptotic exponent or refute every C sqrt(n) bound','Original low-c values used exact segment-side endpoint internals while printed times are rounded; saved annotations retained separately'],'elapsed_seconds':time.monotonic()-start}
(ROOT/'numeric_score.json').write_text(json.dumps(clean(out),ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'checks':checks,'samples':len(sample_records),'receiver_times':len(rtrows),'elapsed_seconds':out['elapsed_seconds']},ensure_ascii=False))
