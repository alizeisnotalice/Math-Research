# R146：原接收门下的中心化坐标配对能量

结论：获得可直接代回 RT2 的精确门加权平方能量界，但没有证明一般的严格次线性价格。根阶部分确实只涉及坐标对角项；尚未支付的交叉项在真实接收积分后仍存在，不能由乘积核自动消失。本稿不把它改名登记为进展，不展开人工接收 score 的位移残差路线。只写本文件；未 Git，未修改他人文件。

## 1. 准确命题：同一原 ν、实际门与中心化坐标

固定原 \(\omega,V,j,y,t\) 及实际接收点 \(x\)、外 hard 来源 \(z\)。原
\[
 w_t(v)=\prod_i\min(1,a_i(y,v)/t),\quad
 e_t=\int_{Z_t}w_t(v)d\nu(v),\quad d\Pi_t=1_{Z_t}w_t\,d\nu/e_t
\]
均沿原合同。只在 \(e_t>0\) 的有限正商行形成概率；零交通行按零处理。\(\nu\) 可任意相关，\(Z_t\) 可任意按原合同删除。置
\[
 \chi_i(v)=1_{\{a_i(y,v)<t\}},\quad
 m_i=\int\chi_i\,d\Pi_t,\quad b_i(v)=\chi_i(v)-m_i,
\]
\[
 d_i(v,u)=b_i(v)-b_i(u)=\chi_i(v)-\chi_i(u),\qquad
 \Delta(v,u)=\sum_i d_i(v,u)=k_t(v)-k_t(u).
\tag{PE1}
\]
中心化不要求来源坐标独立；\(\Pi_t^2\) 只是同一原概率的两份抽样。

令 \(0\le A_x(v,u)\le1\) 为完整原正门，包含 \(\rho_v,\Psi,\chi_{FA}\)、terminal \(G\times D_0\)、原尚未付分支（可含 good∩low）、history 与任何依 \(z\) 的资格。它只附给正项。定义
\[
 a(v,u)=A_x(v,u)1_{\{\Delta>0\}},\qquad
 W(v,u)=\tfrac12[a(v,u)+a(u,v)].
\tag{PE2}
\]
此处转置只交换内部两个来源，原 \(x,y,z,t,\nu\) 与外权都固定。\(W\) 对称，且正 score 方向互斥，故 \(0\le W\le1/2\)。记
\[
 P_x=\iint A_x\Delta_+d\Pi_t^2,\quad
 M_x=\iint Wd\Pi_t^2,\quad
 C_{ij}(x)=\iint Wd_id_jd\Pi_t^2,
\]
\[
 D_x=\sum_iC_{ii},\qquad F_x=2\sum_{i<j}C_{ij}.
\tag{PE3}
\]
则对原实际行有
\[
\boxed{P_x\le\min\left\{\frac n4,\sqrt{M_x(D_x+F_x)}\right\},
\qquad M_x\le\frac12,\quad D_x\le\frac n4.}
\tag{PE4}
\]
\(C\) 为半正定矩阵，\(D+F\ge0\)，但 \(F\) 未知符号。

证明：对称化给 \(P_x=\iint W|\Delta|d\Pi_t^2\)，Cauchy 给平方界。由 \(W\le1/2\)，
\[
D_x\le\tfrac12\sum_i\iint(\chi_i(v)-\chi_i(u))^2d\Pi_t^2
=\sum_i m_i(1-m_i)\le n/4.
\]
对任意取值 \(0,\ldots,n\) 的 score，\(\mathbb E(k-k')_+=\sum_{r=0}^{n-1}\mathbb P(k\le r)\mathbb P(k>r)\le n/4\)，删正门只减小它。上述逐行证明不需要接收尺度冻结，也不需要改变原 \(\beta\) 密度。

若另有真实几何证明 \(F_x\le C D_x\)，PE4 才给 \(P_x\le\sqrt{(1+C)n/8}\)。这是所需交叉项控制的准确位置，**不是本稿已验证的新分支或付款**。目前仅有一般 \(D+F\le nD\)，不能因此取得严格次线性上界。

## 2. 真正的接收乘积核为何尚未支付 F

对于固定原 \(y,v,u,t\)，\(d_i(v,u)\) 完全不依 \(x\)。即使在一个确已固定合法参数的接收积分中保留真实联合乘积核，例如 \(p_{s,L}(x-y)h_R(x-z)\)，也只有
\[
\int p_{s,L}(x-y)h_R(x-z)A_x(v,u)d_id_j\,dx
=d_i d_j\int p_{s,L}(x-y)h_R(x-z)A_x(v,u)\,dx.
\tag{PE5}
\]
将 \(J_v,K_u\) 的真实乘积因子一并留在核中，也不改变该事实。坐标间的来源 score 相关不会由于对另一个变量 \(x\) 作乘积积分而消失；完整 good∩low 门一般也不是坐标乘积门。实际参数自适应时更不能先把接收核当成固定乘积概率。

因此本路线真正需要的是 good∩low 与其他原资格使 PE5 的**实际接收质量**在同号、多坐标差异的来源对上足够小，进而控制 \(F\) 或直接控制 \(P\)。目前两门
\[
 p_xw_g(v)\le K_{\rm good}J_v,
 \qquad K_uJ_v<\eta_nTA_vQ_Jw_t(u)\Delta_+/(De_t)
\tag{PE6}
\]
未给出这样的质量帽。第二个门还随 \(\Delta_+\) 增大而放宽，不能从该门本身领取逆 score 的稀疏性。

R145 的另一尝试将 PE6 化为正几何裕量 \(E>0\) 时的位移覆盖，但恢复的 2070 个既有低尾样本全部 \(E<0\)，FA 内部也无正裕量。故本稿不再次借用该覆盖支付 \(F\)。这只是已有实际压力，不据此声称所有接收几何路线不可能。

R135 SC1--4 的根阶界依赖固定来源后在 \(y\) 的真实 Lebesgue 乘积信道。原 L¹ 合同为 \(\nu\le\beta\le\alpha_{\rm leaf}\le f\,dy\)，故原 \(\beta=r_\beta(y)dy\) 绝对连续；问题是这个实际密度通常不保持所需的反射对称或乘积结构，且尚无足够的 \(r_\beta/e_t\) 密度比预算将原外权转到 SC 信道，不能迁移其正交性。扩展测度类可以允许奇异 \(\beta\)，但不能把这种扩展类当作原 L¹ 输入类的反例。另核 R128 DB10 的坐标非正交检查，其 \((n+2)/3\) 比率属于不同边界算子；本稿没有把它当作原 PE4 的反例，也没有重新推导该旧归约。它仅提醒：乘积形式本身不是交叉项预算。

## 3. RT2 的合法代入与停止边界

令 \(P_{\rm terminal}^{\rm rem}\) 表示尚未乘 \(2\Lambda\) 的原 terminal 正交通；\(\mathfrak O\) 包含 \(\mathbb E\sum_{V,j}\) 及尚未显式写出的 history、\(s,L,R,g,T\) 层级与资格，不包含 \(2\Lambda\) 或下式已显示的 \(dt/t\)。统一计量后，本稿得到的代入是
\[
 2\Lambda P_{\rm terminal}^{\rm rem}\le
2\Lambda\mathfrak O\!\left[
\int q^{-1}p(x,y)h_R(x-z)
\min\{n/4,\sqrt{M_x(D_x+F_x)}\}
\,dx\,d\beta(y)d\nu(z)\frac{dt}{t}\right].
\tag{PE7}
\]
原内部 \(w_t(v)w_t(u)/e_t^2\) 在 PE3 的两份 \(\Pi_t\) 中完整保留；\(q\)、外 hard 来源 \(\nu(dz)\)、原 \(\beta\) 未转换。所有依 \(z\) 的正门仍在 \(A_x\)，没有先全盒积分后再重复调用 hard 帽。来源尚未消尽，不能免费合并唯一 \(j\) 或参数菜单。

要成为实际根阶付款，仍须直接证明 PE7 的右侧不超过
\[
\varepsilon X+C_\varepsilon\sqrt n\log^A(2+n)W_\beta.
\]
仅证明逐行 \(F\le C D\) 也尚须这笔完整外账，不能把逐行 \(\sqrt n\) 乘原外质量误作所求 \(\sqrt n W_\beta\)。本稿既没有完成交叉项的接收几何控制，也没有完成该外账。

这是有界筛查的停止点：PE4 仅是准确且有原门的代数上界，不登记为新进展；未获得一般严格优于已知 \(n/4\) 的价格。没有制造未付“新能量”作为进展，没有将人工 receiver score 的位移残差假装免费，没有改变原 Ψ 或共同 α。原 signed 负项、futurebad、\(N_{\rm del}\) 各按原身份保留一次，旧 high 付款不重复领取。完成后停止。
