# R146 likelihood_band：原Q双门是宽比值支

已实际运行，最终输出绑定经审修订numeric_score.json，exit0，约0.362秒。原179receiver和既有source pair按(case,id,v,u)去重后690条：I1 33、P1 657；对应原2070个时间点引用，不将三点复制为三个pair。无新kernel、抽样、积分、旧6951统计或一般阶数拟合。

结论：本菜单所有pair的b都大于2。因此lambda=.01,.1,1,2下，b窄带的pair覆盖、receiver任一/全部覆盖、各FA closed/interior菜单的score点权覆盖全部为0。whole width<=lambda覆盖也全0。这些现有必要门样本处在宽比值/深bad支，不支持以“原双门应很窄”为依据直接选择反集中路线。有限菜单没有命中窄带不等于一般情形窄带为空。

## 1. 原核与双门定义

完整使用R142保存Q=(K1+K2+J)/3与p，R136原K和wg。每个good v、bad u分别恢复

b=log[p wg_u/(K Q_u)]>0，a=log[K Q_v/(p wg_v)]>=0，width=a+b。

这正对应KQ_u/wg_u<p<=KQ_v/wg_v，width等于log[(Q_v/wg_v)/(Q_u/wg_u)]。没有用J替代Q。全部字段正、没有缺项；原good_v/bad_u标签与a/b符号全部一致。

## 2. 原三阶段的去重pair分布

| 阶段/case | receiver / pair | b最小 / 中位 / 最大 | width最小 / 中位 / 最大 |
|---|---:|---:|---:|
| initial I1 | 2 / 6 | 5.29195 / 5.39497 / 5.49800 | 5.45671 / 5.73438 / 6.05246 |
| initial P1 | 25 / 99 | 2.22768 / 4.91370 / 10.47331 | 7.71453 / 17.80976 / 20.20301 |
| pressure I1 | 0 / 0 | — | — |
| pressure P1 | 5 / 15 | 15.63923 / 15.63923 / 15.79157 | 18.84073 / 19.09053 / 19.41035 |
| expanded I1 | 9 / 27 | 5.32585 / 5.44089 / 5.59162 | 5.56547 / 5.86533 / 6.32062 |
| expanded P1 | 138 / 543 | 2.25734 / 4.85170 / 11.95683 | 7.68439 / 18.05366 / 20.71681 |

所有行均在四个预设lambda之外。P1 source B的good侧a确实可接近0（最小.06177），但bad侧b仍较大；不能把a小误称整个双门区间窄。P1主来源G1的width中位18.88195（范围17.00406—20.71681），G2中位18.33985、G3中位18.60694；far B中位8.01755（范围7.68439—8.58349）。I1 G1/G2/G3的width中位分别5.98616/5.80745/5.93695。

P1压力点比随机uniform点更深入bad侧：pressure b≈15.64—15.79；uniform整体b中位4.85348，最小2.22768。I1 uniform与p流b中位约5.49241和5.38433。JSON完整保留原stage/distribution，未混成体积统计。

## 3. score点权与FA语义

likelihood_band.json保留690个pair的a/b/width，以及2070个对numeric_score后验时间模型的引用和点scoreweight、rho_scoreweight。按全点、原R144 saved FA_closed、原strict interior、本轮printed-time saved-cap closed、其strict interior五个版本分别汇总。

这些版本对lambda=.01,.1,1,2的b窄带覆盖仍全为0，因为pair层已经没有命中。它们只是现有菜单的等点计数或delta Pi_vPi_u（及rho乘积）点权描述，没有dt/t、receiver dx、p流抽样或time长度归一化，不是原F积分或总体尾概率。

原closed和打印时间closed分开保留：numeric_score发现的257个hi_left端点资格差异不能静默视作原FA恢复；strict interior零差异。新JSON的FA_semantics字段明确两种约定，未改原R144标记。闭端点集合不提供正时间占用的证据。

## 4. 校核和执行账

逐179receiver的六源核对Q平均：最大绝对舍入差1.16667e−16、相对差2.64856e−16，无一超过1e−12。该检查是保存核值的代数平均核对，不是重新计算真实kernel。a>=0、b>0、原good/bad标签无失败；width−(a+b)最大绝对残差1e−78，80/120位标量log最大差5.33363e−79。负小margin没有截零，实际没有负a或非正b。

执行两次：先按原冻结score输出计算；主代理授权numeric_score最小审计修订后，绑定其第二版SHA重跑本band脚本。pair、Q、点权和菜单均未变化，第一版band输出由最终输入绑定版替代。协议/脚本/输入SHA已写JSON；最终代码已实际运行，不只静态检查。所有生成逻辑在单次脚本内，支持--input-root指定旧数据根目录，原score.json来自同work冻结文件。

路线含义限于这批已保存的必要门点：窄似然带没有解释其正项，若尝试用反集中，尚须先有另外覆盖宽支的估计或证明真正付费后能限制到窄支。本诊断不从宽带本身推出无法全局付款，也不猜维数阶。完成停止。
