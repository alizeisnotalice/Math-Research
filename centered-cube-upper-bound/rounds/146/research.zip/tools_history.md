# R146 工具与限定历史：接收加权 score、pair 抵消及双侧 Schur

结论：R135 SC1–4 已经证明来源中心 Lebesgue 信道中的根阶 score 界，不是本轮新命题；尚缺把原 β、实际 dx、两份 e 分母和全 history 接入该信道的统一费用。有限检索未定位到已为原实际核建立的双侧 Schur 证书。F05 提供的是双侧行列条件下的 L² 构件，不能补上尚未验证的一侧或跨测度条件。

## 1. 实际阅读及来源等级

已读安装的 `math-f05-l2-spectral-parameter-schur-test/SKILL.md`、`references/provenance.md`、`method.md`、`cube-interface.md`、`source-access.md`。检查 `/Users/zhengzhihao/.codex/math-skill-evidence-roots.json`，唯一 `math64-20261007` 登记的包根当前不存在；这只是已配置 resolver 路径失效，不能据此断言源 PDF 不可访问。

**追加单源恢复核验：** 按用户给定的原始包 [64项训练清单文献库 ZIP](/Users/zhengzhihao/Desktop/中心立方体极大算子_64项训练清单文献库_20261005.zip)，只读取成员 `64项训练清单文献库/F05_L² 谱参数与 Schur 估计/35_Dym_2007_Contributions of Issai Schur to Analysis.pdf` 到内存，没有解压整包或另写来源文件。该成员为 **965932 bytes**，SHA-256 为 `3da1b59567d35c369b08b47af042b7ab0a2b8ae98e4198d35d6edddb3f922118`，与安装技能 `handoff-evidence-index.csv` 的 E2982 完全相同。PDF 共99页，首页题名为 *Contributions of Issai Schur to Analysis*，作者 Harry Dym、Victor Katsnelson；首页 arXiv 标记为 0706.1868v1，2007-06-13，页面另印 2018-11-01 日期。本轮实际核读了 PDF p.1、§3 的 p.13–19，并检查 p.20–21 以区分 §4 的逐项乘子；没有声称本轮全文99页核读。output 下的定向文件清单未找到这份原 PDF 的已解压副本，但不影响原ZIP成员的可读性。

§3 p.14 (3.7)–(3.8) 直接给两侧绝对行列和的 Schur 界，p.15 (3.10) 实际展示 Cauchy–Schwarz 证明；p.17 (3.14)–(3.15) 给严格正权序列的双侧加权版本。下文不同底测度、两权的 H2 保持所写 Cauchy–Schwarz/Tonelli 独立证明，不将其冒称为原文已明写的积分核扩展。此处没有核读 Schur 1911 原论文，也不引用未读的 Bennett、Peller 或 Birman–Solomyak 深层定理。PSD 逐项 Schur 乘子、双算子积分和绝对行列 Schur 检验是三个不同对象，本模型目前没有前两者所需的 Gram/谱测度证书。未修改全局注册、安装或其他文件。

历史仅对 R128–145 的 score/variance、channel、source/receiver、pair ratio、β bridge、Schur 等关键词定向检索，并读取下列命中必要片段。未通读全史；“未定位”不表示全库不存在。未运行新数值；单源追加核验只恢复来源可访问性，不算证明进展。

## 2. 定理与历史映射

| 对象 | 精确既有位置/公式 | 已证内容与尚缺条件 |
|---|---|---|
| 来源后验 score 粗界 | [R131 source_integrability.md:109](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/source_integrability.md:109)，SI9 | 两份同 Π 独立抽样给 \(D=\tfrac12E|k-k'|=\sum_{r=0}^{n-1}F_r(1-F_r)\le n/4\)，且 \(D\le\sqrt{\operatorname{Var}_\Pi(k)/2}\)。独立的是两份来源抽样，不是 Π 内各坐标；没有任意相关 ν 下的点态 Var=O(n)。 |
| 接收加权方差的确切旧成果 | [R135 source_channel.md:5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/source_channel.md:5)，SC1–4；[score_injection_audit.md:138](/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/score_injection_audit.md:138)，SIA8 及 SC 后审 | 固定 b,c,t；\(a_t=\min(1,\alpha/t)\)、\(z_t=\int a_t\in(0,\infty)\)、\(\theta_t=z_t^{-1}\int a_t1_{\alpha<t}\)。任意有限 ν、任意共同可测非乘积删源，\(\int e_t\operatorname{Var}_{\Pi_t}k_t\,dy\le z_t^n\|\nu\|n\theta_t(1-\theta_t)\)，继而 \(\int e_tE\delta\,dy\le z_t^n\|\nu\|\sqrt{n/8}\)。时间版用 \(e_tdy/z_t^n\)，对有限对数窗付其长度。不能换成原 β 或 dx。 |
| 通道交叉项为什么消失 | 同 SC2 证明、SIA8 | 先以常数 nθ 比较条件方差，再删除资格；固定 v 后，\(z_t^{-n}w_t(y,v)dy\) 才是接收坐标乘积概率，异坐标中心化交叉项为0。它没有证明 \(\Pi_{y,t}\) 是产品概率，也没有在原带 \(e_t^{-2}\)、β、good/bad 门的积分内直接消交叉项。 |
| 时间方差不是免费耗散 | [R131 score_energy_history.md:34](/Users/zhengzhihao/Desktop/T/output/centered_cube_round131_20261014/score_energy_history.md:34)；[R135 score_injection_audit.md:20](/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/score_injection_audit.md:20)，SIA1–5 | \(dm=dC-\operatorname{Var}(k)d\log t+dM_{del}\)。穿越量 C 未付；删除均值的幅度有 \(n r_u/e_{u-}\)。每个来源最多 n 次穿越不推出漂移概率加权 C≤n。过滤门另添门变化/协方差项，不能把原 Var 余额乘门当身份。 |
| 同核 pair 尾抵消 | [R138 receiver_source_geometry.md:22](/Users/zhengzhihao/Desktop/T/output/centered_cube_round138_20261015/receiver_source_geometry.md:22)，RS3、RS5–7；[pair_ratio_audit.md:52](/Users/zhengzhihao/Desktop/T/output/centered_cube_round138_20261015/pair_ratio_audit.md:52)，PRA3–5 | 先乘实际 bad 容量和逆核矩，出现 \(K(x-a)/K(x-u)\)，共同 \(H^{-n}\) 与共同尾深度抵消。固定乘积 p 下 RS6 保留每坐标 \(1+(G_s-1)P_i^+-(1-G_s^{-1})P_i^-\)。仍付 \(e^{L_\phi\|a-u\|_1/H}\)、硬边界概率及实际两来源平均；参数依 x 时只保留点态 RS5，不能免费张量积分。 |
| β 与 e dy 的桥 | [R140 beta_source_contract.md:7](/Users/zhengzhihao/Desktop/T/output/centered_cube_round140_20261015/beta_source_contract.md:7)，来源支配及第6–7项原合同定位 | 已知共同结构是 \(\nu\le\beta^c\le\alpha\)，并保留原 RT1 的 \(q^{-1}ph_R dx\,d\beta(y)d\nu(z)\)。这是测度支配，方向不提供 \(d\beta/e_t\) 的统一质量；即使 β 有 Lebesgue 密度，也没有所需能量权密度帽。β 不能换成 ν，辅助来源亦不继承 hard z 捕获门。 |
| “有边际”不等于 Schur 已付 | [R143 source_responsibility.md:65](/Users/zhengzhihao/Desktop/T/output/centered_cube_round143_20261015/source_responsibility.md:65)，SR6–10 | 未加交通权的储备耦合有输出≤容量；乘实际 \(\lambda=b_t\sigma_t1_{good}/(TA)\) 后的来源边际是 SR10，\(c_x\le1\) 不推出 \(\kappa_x\le1\)。这尚不是具有统一 R,C 的行列核证书。 |

R137 的负权来源矩插值、R144–145 的小幂/低核门只减少其各自核价；在本次必要片段中未发现它们补齐了上表的 β→信道桥或原核的双侧 Schur 条件。

## 3. pair 坐标抵消的准确边界

除上表 RS 比值抵消外，本轮限定检索未定位到在**原实际全权**下已证的 pair-score 异坐标交叉项为0定理。一个可独立核验的裸边界是：固定两来源 u,v，a、χ 为原偶一维函数，置
\[
b_i=\int a(y_i-v_i)a(y_i-u_i)dy_i>0,\quad
X_i=\chi(y_i-v_i)-\chi(y_i-u_i).
\]
反射 \(y_i\mapsto u_i+v_i-y_i\) 保持这份一维权而令 Xi 变号，故 \(E X_i=0\)。在归一化的裸乘积 pair 权 \(w(y,v)w(y,u)dy/\prod b_i\) 下，
\[
E(\sum_iX_i)^2=\sum_iEX_i^2\le n.
\tag{H1}
\]
这只是直接代数边界检查，不登记为新预算。原 \(e_t(y)^{-2}\)、β 密度、删源、ρ、FA、Ψ、good/bad 或自适应参数一般不保持每坐标反射或乘积结构，不能带着这些权继续引用 H1。若要应用，必须证明其实际加权交叉项的控制，或先合法去门并支付改变权重的费用。SC1 的办法是以固定中心平方误差去掉删源，不是直接对原 pair 分母作上述反射。

完整图的 signed 抵消也有不同限制：[R143 score_flux_budget.md:57](/Users/zhengzhihao/Desktop/T/output/centered_cube_round143_20261015/score_flux_budget.md:57) SF143.6–10 的 cut/covariance 恒等式必须带 Ψ 缺边和加权 good 内项；不能将完整图负边补回原 Ψ 图充作免费方差收益。

## 4. F05 此处真正可用的双侧构件

固定两 σ 有限测度空间 \((Y,m)\)、\((V,\nu)\)，可测核 A(y,v)，以及有限严格正权 p(y)、q(v)。若对几乎处处 y、v 同时成立
\[
\int |A(y,v)|q(v)d\nu(v)\le R p(y),\qquad
\int |A(y,v)|p(y)dm(y)\le C q(v),
\tag{H2}
\]
其中 R,C 有限，则在可积测试函数上先用
\[
|Af(y)|^2\le Rp(y)\int|A(y,v)||f(v)|^2/q(v)d\nu(v),
\]
再用 Tonelli 与第二侧，得到 \(\|A\|_{L^2(\nu)\to L^2(m)}\le\sqrt{RC}\)，随后密度延拓。这是自足证明；其有限矩阵特例与本轮已核原文 §3 (3.8)、(3.15) 一致。参数权可以依固定列标签，但 R,C 必须在要总和/取上确界的参数范围统一；单个参数核的 Schur 界不支付最大化、菜单或 history。

映射到本模型时，m 必须直接包含要付款的 β、真实接收 dx、时间/种子/history，A 中须准确带原 w、Z、两份 e 分母及所保留门；或先明确作一次合法正上界。R135 只提供 e dy 的信道列积分，并没有给 H2 第二式的原 β/dx 列积分。FIRST 的同 x 来源核质量帽可帮助某一行，但不自动给另一侧。Schur 的 L² 结论还需测试函数 L² 范数与外测度总质量的付款，才能变成原 L¹ 弱型账。

一种把缺口写得可审的充分桥如下。合法正放松并先积分 x,z 后，若原行变为 \(\int\sqrt{\operatorname{Var}}d\mu_t\)，令 \(d\gamma_t=e_tdy/z_t^n\)。需要证 \(\mu_t\ll\gamma_t\) 及 \(h_t=d\mu_t/d\gamma_t\) 的真实费用；Cauchy 只给
\[
\int\sqrt{\operatorname{Var}}d\mu_t
\le\sqrt{\|\nu\|n\theta_t(1-\theta_t)}
\left(\int h_t^2d\gamma_t\right)^{1/2}.
\tag{H3}
\]
必须把后一项、ν 质量、所有 j/time/history 总和支付到 Wβ/既有 εX 槽。它是清楚的缺失条件，不是已证密度帽；若不能合法形成上述放松，保持原联合核，改直接证明 H2 的两侧实际条件。

## 5. 必须保留的压力与停止点

- [R128 dimensional_boundary_route.md:87](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/dimensional_boundary_route.md:87)，DB9–10：真实 cube 坐标边界增量对宽正 Gaussian 的平方和比趋于 \((n+2)/3\)。因此没有普遍的常数/polylog 正交帽；DB8 的正单尺度边界弱型费用≥21n/64。它们不反驳原最大算子的目标，也不反驳在正确权下另证联合抵消。
- [R143 score_flux_budget.md:230](/Users/zhengzhihao/Desktop/T/output/centered_cube_round143_20261015/score_flux_budget.md:230) 的裸同阈值压力使正 score 时间积分趋于 \(n\log(b/a)/4\)。这是删除真实几何门后的核级反例，不是原 FULL 反例；它阻止将任意相关 ν 的裸 score 当作根阶。
- 单侧 Schur 本身不足：N行1列的全1矩阵每行绝对和1，算子范数却为√N；缺列界不能靠名称补齐。此为独立有限代数检查。

下一实质证明应给 H2 的两侧实际证书，或 H3 的跨测度费用，或在保留原联合权时证明可累计的 pair 交叉项预算。现有 SC1–4、RS 比值恒等式与 F05 基础构件都不能代替这一条件。本稿只写指定文件，不操作 Git 或其他文件，完成停止。
