# R350 — Actual q-weighted capture rank routing and a whole-branch payment

This note proves a new routing of the original late traffic. Its incoming density is at most q_w, without the uniform upper-witness Hardy factor. Combining it with the already audited fixed-exponent adjoint moment pays an entire marked receiver branch. The remaining concentrated branch is explicit and is not globally bounded here.

## 1. Frozen contract and precise statement

Let f≥0 be integrable, W=∫f, and let E be the actual finite Lebesgue receiver set. For u∈E, Q_u is the centered cube of side R_u∈[a,b], b≤2a; c_u=1_{Q_u}, m_u=∫fc_u=q_uR_u^n, and q_-=3λ/4≤q_u≤λ. Write dμ=du/m_u, ρ_y(du)=c_u(y)dμ(u), J_y(r)=ρ_y{R≤r}, J_y=J_y(b), U_y(t)=ρ_y{m>t}, U_y^r(t)=ρ_y{m>t,R≤r}, and X_q=∫_E q_u du. Every field uses full f throughout.

Set K=e^{√n}, B=(1+√n)/q_-, and retain the original ε, high-past, outside-center, small endpoint, strict mass gap, H, and full J_y(r) denominator inside the original row Ω_y(u,r). The established bound is 0≤Ω≤1. The physical clock is

    ell=b^{-n}δ_b+n r^{-n-1}dr,  ell([R,b])=R^{-n}.

Define the previously frozen full-clock quantities

    ω_y(u)=R_u^n∫_[R_u,b] Ω_y(u,r)ell(dr),  a_y(u)=q_uω_y(u),
    η_y(u)=(1−2λB/[a_y(u)U_y(Km_u)])_+,

with η=0 if its denominator is zero. In particular 0≤ω≤1 and a≤q_u≤λ. For the old source component 0≤g≤f (in the ledger g=g_ex), the original late measure is

    dF(y,u,r)=g(y)c_u(y)η_y(u)Ω_y(u,r)
       1_{U_y(Km_u)>εJ_y}1_{U_y^r(Km_u)≤1/q_-}
       1_{r∈[R_u,b]} dy du ell(dr).                         (1)

Its total is G_late[g]. Define

    t_y(u)=R_u^n∫_[R_u,b]η_y(u)Ω_y(u,r)
          1_{U_y(Km_u)>εJ_y}1_{U_y^r(Km_u)≤1/q_-}ell(dr),
    ν_y(du)=q_uρ_y(du)=c_u(y)R_u^{-n}du,
    D(y)=ν_y(E).

Then 0≤t≤1 and exactly G_late[g]=∫g(y)∫t_y(u)ν_y(du)dy. This clock contraction retains the terminal atom. Positive t implies η>0, hence

    U_y(Km_u)>2B,  ν_y{m>Km_u}>2q_-B.                    (2)

The theorem is that there exists a measurable actual receiver kernel Q_y(u,dw), depending only on (y,u), such that it is a probability on the positive rows of (1), every routed witness captures the same y and satisfies m_w>Km_u, and

    ∫ν_y(du)Q_y(u,dw)≤ν_y(dw).                           (3)

Consequently the incoming marginal κ(w)dw of dF Q satisfies

    κ(w)≤q_w p_w^g≤q_w,
    p_w^g=(1/m_w)∫g(y)c_w(y)dy,
    ∫κ(w)dw=G_late[g].                                  (4)

Neither (3) nor (4) asserts that a routed w satisfies the original old-time prefix. It is a terminal witness; the original prefix remains attached to (y,u,r).

## 2. Actual-center qρ mass-window capacity

For every y and t>0,

    ν_y{t≤m≤Kt}≤D0:=1+log K+log(λ/q_-).                 (5)

Indeed the indicated receivers have radii A=(t/λ)^{1/n}≤R≤C=(Kt/q_-)^{1/n}. Since they capture y, 2||u−y||∞≤R. Their actual density R^{-n} is at most max(A,2||u−y||∞)^{-n}, with support in the cube of side C. The integral of this envelope is

    1+n log(C/A)=1+log K+log(λ/q_-).

The identity follows by integrating shell volume d(r^n) for A<r<C. Dropping the original radius interval or E only increases the integral. This is a bound on actual receiver density; it places no cap on f and uses no conversion of boundary volume into source mass.

Choose the single shift

    Δ=2(1+√n)=2q_-B.

For n≥1, Δ>D0 because 1+√n>log(4/3). By (2), every positive row has strict upper ν-mass greater than Δ.

## 3. Atom-safe increasing-mass rank translation

For fixed y write A_y=D(y),

    F_y^-(m)=ν_y{m_v<m},   F_y(m)=ν_y{m_v≤m}.

Give u a randomized rank s: if m_u is an atom of the mass pushforward, use uniform Lebesgue probability on (F_y^-(m_u),F_y(m_u)]; otherwise use the Dirac probability at F_y(m_u). Denote this kernel by R_y(u,ds). The distributional transform gives

    ∫ν_y(du)R_y(u,ds)=1_{(0,A_y)}(s)ds.                 (6)

It also gives, for its joint measure, F_y^-(m_u)≤s≤F_y(m_u). Disintegrate this same actual joint measure in the other direction:

    ν_y(du)R_y(u,ds)=ds H_y(s,du).                       (7)

Here H_y(s,·) is a probability for almost every s∈(0,A_y), supported on actual receivers capturing y and on the mass quantile corresponding to s. In particular s≤F_y(t) implies m≤t for almost all such ranks except immaterial quantile endpoints. Conversely, m≤t implies s≤F_y(t). The second implication is sufficient for the strict-gap argument below.

All fields admit Borel versions on the standard Borel receiver/source spaces. The kernels in (6) are measurable in y by parameter integration. To obtain jointly measurable H, disintegrate dy ν_y(du)R_y(u,ds); this is a finite measure because

    ∫D(y)dy=∫_E R_u^{-n}|Q_u|du=|E|<∞.

Its (y,s) marginal is dy 1_{0<s<A_y}ds. This supplies one jointly measurable version of (7), with only dy-null exceptional source sections. Such sections also have zero g(y)dy mass. Thus no pointwise nonmeasurable choice or private posterior is used.

Use the linear, noncyclic shift

    Q_y(u,dw)=∫1_{0<s≤A_y−Δ}H_y(s+Δ,dw)R_y(u,ds),       (8)

and Q=0 when A_y≤Δ. The top ranks are discarded, never wrapped. On a positive old row, ν_y{m>Km_u}>Δ implies

    s≤F_y(m_u)≤F_y(Km_u)<A_y−Δ.

Thus no rank is discarded and Q is a probability there.

If a pair produced by (8) had m_w≤Km_u, the rank support yields

    Δ≤F_y(Km_u)−F_y^-(m_u)=ν_y{m_u≤m≤Km_u}≤D0,

a contradiction. Therefore m_w>Km_u strictly, including mass atoms. Translating a Lebesgue null set of bad target ranks stays null. Equation (6) now proves

    ∫ν_y(du)Q_y(u,dw)=∫_Δ^{A_y}H_y(s,dw)ds≤ν_y(dw).

This establishes (3). Multiplying the input by any 0≤t≤1 preserves domination.

## 4. Preserve all original marks and derive the true incoming column

Insert (8) into (1). Since Q has row mass one on its support, dF(y,u,r)Q_y(u,dw) has the same total G_late[g]. The selection of w only depends on (y,u); the old clock r, old small endpoint underlying Ω, high-past and outside gates, η, full J and source g are not recomputed. If the small endpoint is displayed explicitly rather than integrated into Ω, the identical probability insertion preserves that label too.

After integrating only the old marks, (3) yields

    κ(w)dw=∫g(y)∫t_y(u)ν_y(du)Q_y(u,dw)dy
       ≤∫g(y)ν_y(dw)dy
       =q_w [∫g(y)c_w(y)dy/m_w]dw.

This proves (4) and its normalization. The proof does not reuse the uniform-witness Hardy column bound; (8) is a different kernel whose full column estimate was derived above.

## 5. New-source defect and payment of an entire diffuse-witness branch

Now append the genuine full-f posterior

    π_w(dz)=f(z)c_w(z)dz/m_w

to the preceding joint measure, retaining all old marks. Put

    L(z)=∫c_w(z)κ(w)dw/m_w.

The exact new-source marginal is f(z)L(z)dz, with

    L(z)≤D(z),   ∫f(z)L(z)dz=G_late[g].                 (9)

In particular the source factor f is retained. The already audited dimension-free fixed L^{4/3} maximal constant C supplies

    ∫D(z)^4dz≤C^4|E|≤C^4 X_q/q_-.                     (10)

Indeed D=T_R^*1_E for T_Rφ(w)=R_w^{-n}∫_{Q_w}φ; duality gives (10). No numerical value of C is asserted here.

Fix s>0, β>0, and 0<θ<1. Set

    T=βθ q_- s^3/C^4,
    e(z)=1_{D(z)>s}(1−T/f(z))_+,
    p_w=∫e(z)π_w(dz),                                 (11)

where e=0 on f=0. All fields in (11) still use full f, not the old source g. The exact defect is

    ∫κ(w)(1−p_w)dw
     =∫_{D≤s}fL+∫_{D>s}min(f,T)L
     ≤sW+T s^{-3}∫D^4
     ≤sW+βθ X_q.                                      (12)

This yields a whole original marked-witness branch, not only a fractional z split. Define

    G_diff=∫κ(w)1_{p_w≤1−θ}dw,
    G_conc=∫κ(w)1_{p_w>1−θ}dw.

Exactly G_late[g]=G_diff+G_conc. On the first branch 1−p_w≥θ, so

    G_diff≤β X_q+(s/θ)W,
    G_late[g]≤G_conc+β X_q+(s/θ)W.                    (13)

Choose s=1+√n and θ=1/4. Then

    G_late[g]≤G_conc+βX_q+4(1+√n)W,
    T=β q_-(1+√n)^3/(4C^4).                          (14)

On every retained w, p_w>3/4 forces

    π_w{D>s, f>2T}>1/2.                              (15)

To prove this, on the complement of S={D>s,f>2T}, e≤1/2; everywhere e≤1. Hence p_w≤(1+π_w(S))/2. More generally p_w>1−θ implies π_w(S)>1−2θ.

Equation (13) genuinely pays the whole diffuse-witness portion. It does not claim diffuse witnesses always carry a positive uniform fraction. The remaining traffic keeps all old marks and the actual selected w with (15). No new old-row bound is asserted at z or w, and neither (3) nor (12) is iterated without a separate capacity proof.

## 6. Full hard-slot ledger and remaining mechanism

Using the R348/R349 ledger, denote C_top=1+√n+log(4/3), L_ε=1+log(1/ε), and C_hit=2λB L_ε. For g=g_ex and W_ex=∫g_ex, substitute (13) exactly once:

    B_H≤G_conc+[(13/3)ε+γ_eff+β]X_q
        +[C_{ε,n}+s/θ]W+(C_top+C_hit)W_ex.             (16)

Here γ_eff is the previously proved actual-clock coefficient: zero if the original high-past gate is empty, otherwise 2(λ/q_-)e^{-√n}. No old Top-hit, source clipping or soft payment is added again. The new source cost is full W, not W_ex, because π_w uses full f. All exterior multipliers apply to the new terms: entrance factor two and Λ=128/119 add 2Λβ to the old receiver coefficient. With the historical CZ slot included this is

    841/2304+2Λγ_eff+2Λβ.

The residual G_conc has original source y, original old-time late upper capture, and a strict upper witness w that captures y and places >1/2 of its true source mass in the high-D/high-f set in (15), for θ=1/4. This concentration condition is new; a budget for all such concentrated witnesses is not proved here. In particular the source repeats encoded by fD have not been declared free.

## 7. Executed exact algebra/rank diagnostic

The following Python code was run with fractions.Fraction and passed: 8 active mass atoms, 12 target atoms, row conservation, strict gap, column domination, and 36 exact threshold substitutions. This is a finite abstract test of the rank mechanics and algebra, not a realization of all cube or high-past assumptions. The proof above establishes those geometric inputs separately.

```python
from fractions import Fraction as F
N=12; shift=F(5,2); cap=F(2); L=1
weights=[F((i%4)+1,4) for i in range(N)]
rows=[]
for i in range(N):
 if N-i-2>shift:
  row=[max(F(0),min(F(i+1)+shift,F(j+1))-max(F(i)+shift,F(j)))
       for j in range(N)]
  assert sum(row)==1
  assert all(x==0 or j-i>L for j,x in enumerate(row))
  rows.append((i,row))
cols=[sum(weights[i]*row[j] for i,row in rows) for j in range(N)]
assert all(x<=1 for x in cols)
assert sum(cols)==sum(weights[i] for i,_ in rows)
count=0
for q in [F(3,4),F(3,2),F(5,4)]:
 for s in [F(2),F(3),F(7,2)]:
  for beta in [F(1,100),F(1,16)]:
   for theta in [F(1,4),F(1,2)]:
    C4=F(81); T=beta*theta*q*s**3/C4
    assert T*C4/(q*s**3)==beta*theta
    assert (T*C4/(q*s**3))/theta==beta
    count+=1
print('PASS: exact rational rank routing',len(rows),'active atoms,',N,
      'target atoms; row conservation, strict far gate, column cap;',
      'threshold identities',count)
```

Only /tmp/r350_geometry.md was authored for this delivery. No general weak-(1,1) root theorem or complete remaining-traffic payment is claimed.
