from fractions import Fraction as F
N=12; shift=F(5,2); cap=F(2); L=1
weights=[F((i%4)+1,4) for i in range(N)]
rows=[]
for i in range(N):
 if N-i-2>shift:
  row=[max(F(0),min(F(i+1)+shift,F(j+1))-max(F(i)+shift,F(j)))
       for j in range(N)]
  assert sum(row)==1
  assert all(x==0 or j-i>L for j,x in enumerate(row))
  rows.append((i,row))
cols=[sum(weights[i]*row[j] for i,row in rows) for j in range(N)]
assert all(x<=1 for x in cols)
assert sum(cols)==sum(weights[i] for i,_ in rows)
count=0
for q in [F(3,4),F(3,2),F(5,4)]:
 for s in [F(2),F(3),F(7,2)]:
  for beta in [F(1,100),F(1,16)]:
   for theta in [F(1,4),F(1,2)]:
    C4=F(81); T=beta*theta*q*s**3/C4
    assert T*C4/(q*s**3)==beta*theta
    assert (T*C4/(q*s**3))/theta==beta
    count+=1
print('PASS: exact rational rank routing',len(rows),'active atoms,',N,
      'target atoms; row conservation, strict far gate, column cap;',
      'threshold identities',count)
