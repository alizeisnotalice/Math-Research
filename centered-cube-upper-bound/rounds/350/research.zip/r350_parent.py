from fractions import Fraction as F
import json
count=0
for den in (4,8,16):
 for j in range(1,den):
  theta=F(j,den)
  for k in range(1,9):
   T=F(k,4)
   fs=[F(0),F(1,4),F(1),F(2),F(8)]
   weights=[F(i+1,15) for i in range(5)]
   for mask in range(32):
    defects=[1-(max(F(0),1-T/f) if f and (mask>>i)&1 else F(0)) for i,f in enumerate(fs)]
    deficit=sum(w*d for w,d in zip(weights,defects))
    for eta in (F(1,4),F(1,2),F(3,4)):
     outside=sum(w for i,(w,f) in enumerate(zip(weights,fs)) if not ((mask>>i)&1 and f>T/eta))
     assert eta*outside<=deficit
     if deficit<theta: assert outside<theta/eta
     count+=1
# weighted witness-level diffuse whole-flow payment, using an exact defect identity
for N in (3,9,27):
 for j in range(1,16):
  theta=F(j,16)
  kap=[F((i*7)%11,13) for i in range(N)]
  p=[F((i*5)%17,17) for i in range(N)]
  G=sum(kap);R=sum(k*v for k,v in zip(kap,p))
  diffuse=sum(k for k,v in zip(kap,p) if v<=1-theta)
  assert theta*diffuse<=G-R
  assert G<=sum(k for k,v in zip(kap,p) if v>1-theta)+(G-R)/theta
  count+=2
out={'exact_assertion_cases':count,'scope':'finite weighted algebra for the positive defect payment and witness concentration; not full cube hard-flow simulation'}
print(json.dumps(out,ensure_ascii=False,indent=2))
eps=F(119,3072); external=F(128,119); beta=eps/16
assert 2*external*beta==F(1,192)
assert F(13,36)+F(1,256)+2*external*beta==F(853,2304)
assert F(853,2304)+2*external*eps/16==F(865,2304)
assert 1-F(865,2304)==F(1439,2304)
print('PASS: four additional exact ledger coefficient checks')
