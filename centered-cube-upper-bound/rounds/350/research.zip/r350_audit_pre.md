# R350 independent pre-author screen

This is the bounded independent screen before reading any R350 author file. The exact finite-flow and posterior-variance identities below are valid interfaces, not payments by themselves. The subsequently proposed source marking gives a payment; its stronger capacity-preserving rank route and whole-quality payment are independently screened in §§6–7. The earlier uniform-source clipping proposal in §4 is retained as an alternative, not a cumulative bill. No general root-order closure follows. Only this owned audit file is written; no author file or Git state is changed.

## 1. Original cost lift and finite potential identity

Keep the complete frozen R348/R349 hard field: actual finite receiver E with du, f≥0 in L¹, m_u=f(Q_u)=q_uR_u^n, q_-=3λ/4≤q_u≤λ, a≤R_u≤b≤2a, and all original sources, prefixes, J, gates and physical ell. After its OLD clock is integrated, the exact late cost at fixed original source y is

    I_y(du)=ζ_y(u)ρ_y(du),   0≤ζ≤q_u,
    G_late[g]=∫g(y)I_y(E)dy.

The original source remains exterior here. On its support the normalized terminal-upper kernel is P_y(u,dw)=1_{m_w>Km_u}ρ_y(dw)/U_y(Km_u). A one-step edge measure I_y(du)P_y(u,dw) has source-u marginal I_y and source-w marginal I_yP_y. For φ(u)=log(m_u/m0), m0=q_-a^n, its EXACT drift is

    D_y=∫edge[φ(w)-φ(u)]
       =∫φ d(I_yP_y)-∫φ dI_y.

Every edge has drift >logK; the R349 lower bound further gives the conditional mean drift

    E_P log(m_w/m_u)
      ≥logK+(q_-U_y(Km_u)-1)_+²/[2q_-U_y(Km_u)].

The normalization is only on U>0. The stronger bound is pointwise in the same source y and does not replace the exact outgoing/incoming marginals. Because both marginals carry total original cost I_y(E), the finite range of φ alone controls drift relative to this same unknown cost; it does not bound the absolute traffic by a source budget.

A precise finite continuation statement is useful. Let c_y(u)∈[0,1] be a specified measurable continuation rule, zero where the chosen upper law does not exist, and set Q_y=c_yP_y. Let

    O_y=∑_{k=0}^{N-1} I_y Q_y^k,
    T_y=(1-c_y)O_y,    F_y(du,dw)=O_y(du)Q_y(u,dw).

Every continuing edge increases mass by more than K. Since m0≤m≤m1=λb^n, the safe integer N=floor(log(m1/m0)/logK)+1 gives Q_y^N=0. Hence

    O_y=I_y+O_yQ_y,
    T_y(E)=I_y(E),
    ∫F_y[φ(w)-φ(u)]=∫φ dT_y-∫φ dI_y.

These are true finite flow conservation and telescoping identities. They preserve all stopped mass. If continuation stops because an original outside/H/prefix/history qualification is lost, that stopped part is NOT automatically a lowfuture/Top paid terminal. Either it must be retained as an exit or continuation must be honestly defined on a larger auxiliary state space. Transported tokens are not thereby new original qualified traffic.

If every initial token makes at least one upward step, the total edge cost is at least the initial cost. The potential range L=log(m1/m0) gives edge cost at most L/logK times initial cost. Even a known terminal root fee multiplied through this bound may incur L/logK≈√n; it must not be collapsed for free. On source rows where all continuation is relative-high, the stronger conditional drift can sharpen this occupation ratio, but still does not upper-bound the initial cost itself.

## 2. Actual incoming and reset costs that cannot disappear

For a same-source occupation density b_y(u) with respect to ρ_y, the exact incoming density is

    (P_y^*b_y)(w)=∫_{m_u<m_w/K} b_y(u)ρ_y(du)/U_y(Km_u),

with the continuation masks included where applicable. Row normalization does not bound this column by q_w. To use an old sourcewise lowfuture terminal receipt one sufficient checkable condition would be a domination T_y≤Cq_wρ_y on a genuinely paid lowfuture terminal set. Then the terminal cost can be priced by the corresponding actual first moment. C must be proved uniformly or with its own source-integrated budget; arbitrary iterated incoming densities do not inherit the original ζ≤q multiplier.

Source resampling z~π_w=f(z)c_w(z)dz/m_w after one upper route has the exact marginal f(z)ℒ(z),

    ℒ(z)=∫_E c_w(z)κ_late(w)dw/m_w,
    ∫fℒ=G_late.

The presently established bound is ℒ≤λL_ε J_b, not a constant or an invariant-source assertion. Replacing this marginal by f would discard a genuine entry/reuse cost. The new payment in §4 uses this weighted marginal explicitly instead.

For any source-dependent potential Φ(y,u), a lift y,u→y,w followed by a reset y→z has the exact total increment

    [Φ(y,w)-Φ(y,u)]+[Φ(z,w)-Φ(y,w)].

The reset term is signed and must be retained. A desired upper bound on positive lift drift therefore also owes the negative-reset cost, or a proved compensator estimate. For log m alone reset drift is zero, but source-capacity domination still remains unproved. Restoring a new physical time also incurs the old clock migration/normalization costs; original upper witnesses cannot be inserted into the old J or assigned a fresh Ω.

## 3. What a genuine variance route would have to prove

R349's original amplitude is

    F_{u,r}(y)=c_u(y)sqrt[(g/f)ηΩχ/U_y(Km_u)],

with original late/relative gates in χ, zero conventions, and all full-f fields unchanged. Under actual π_w and upper m_w>Km_u,

    (1-1/K)G_late≤V_late≤G_late,

where V_late is the full du·ell·dw integral of Var_{π_w}(F_{u,r}). A sufficient target is a joint bound V_late≤δ'X_q+C_{δ'}√n log^A(2+n)W for EVERY original frozen admissible field and its actual amplitude. Choosing δ'=δ(K-1)/K yields the desired receiver coefficient after G_late≤K V_late/(K-1); the source factor also gets the same explicit multiplier. K≥e makes that multiplier dimension-independent, not zero.

The variance is positive source-change cost, not an already present negative Gram/suffix credit. Its upper bound by the same original second moment is circular for payment. The conditional posterior π_w need not have independent coordinates or a density cap; hard cube tensors do not confer these properties on arbitrary f. Any Poincaré/oscillation assertion needs its own hypotheses and a bound on the ACTUAL g/f, η, Ω, J and clock dependent amplitude. Positive variance comparability alone supplies no global upper budget.

## 4. Newly screened real marked-subtraffic payment

The additional primary proposal is valid. Start with the actual original late traffic, route to its real terminal upper w under the SAME source, then append the genuine source mark z~π_w. This joint positive law retains every original y,u,r,w label, old g_ex(y), physical clock and full-f gate. Its total mass is exactly G_late, and its new-source marginal is exactly f(z)ℒ(z). It is not a restarted G with input f(z)ℒ(z).

Fix s>0 and use the established one-shot bound ℒ(z)≤λL_ε J_b(z). The part marked by J_b(z)≤s is paid by

    ∫_{J_b≤s} fℒ≤λL_ε sW.

On J_b(z)>s, split ONLY the new source density f(z)=min(f(z),T')+(f(z)-T')_+, preserving all the ancestral labels. The clipped part is bounded by

    λL_ε T'∫_{J_b>s}J_b(z)dz
      ≤λL_ε T' s^(-3)∫J_b^4.

The inherited fixed-exponent R344 adjoint bound is ∫J_b^4≤C_{4/3}^4 X_q/q_-^5. Therefore

    marked high-J clipped cost
      ≤[λL_ε C_{4/3}^4 T'/(q_-^5 s^3)]X_q.

The power is s^(-3), NOT s^(-4), because the source marginal contains the extra J_b factor. Selecting

    T'=δ q_-^5 s^3/[λL_ε C_{4/3}^4]

pays this part by δX_q. With s=√n/q_-, the low-new-J fee is (λ/q_-)L_ε√n W and

    T'=δ q_-² n^(3/2)/[λL_ε C_{4/3}^4].

The fixed-exponent constant is inherited and its numerical value is not assumed. No n-dependent exponent or weak-(1,1) theorem is used.

This is a genuine positive FRACTION of the original marked flow: its conditional probability, or clipped posterior weight, integrates back to a measurable [0,1] mask on the original y,u,r integrand. It is not a new source input satisfying freshly asserted q/selector conditions. New-source f is full f, so its source price is W, not W_ex. The old original-y excess restriction g_ex stays inside every remaining ancestral label. The exact remaining marked law has J_b(z)>s and new-source density (f(z)-T')_+, in addition to ALL old late/relative/soft/outside/H/past/source/clock labels.

This split is sequential INSIDE the previously unpaid G_late. It does not duplicate the earlier original-y clipping bill: it pays a new-source-mark subbranch of what remained. Nevertheless its NEW receiver fee δX_q must be multiplied by the original entrance factor 2 and all authentic outer coefficients (2Λδ in the existing account). One cannot retain the R348 numerical absorption total unchanged after adding this payment. The pre-screen leaves δ symbolic; final parameter allocation and all other unpaid slots must be stated explicitly. The low-new-J source fee and this δ receiver fee still do not close the tagged residual.

## 5. Necessary quantifiers and actually executed checks

All capacities and variance claims must retain actual du, original full-f masses, measurable selectors and gates, zero-J/zero-U conventions, true source labels and exact ell with b atom. A continued flow requires an explicit continuation/stopping rule, genuine column/terminal price, and any reset/clock migration terms. A proposed global estimate must quantify over the original arbitrary L¹ f and the same joint field; it may not prove an inequality for a freely optimized posterior or an independently selected source geometry.

A local Python Fraction run passed 80 exact checks on finite labelled-flow conservation/telescoping with a nonzero reset-potential term, the s^(-3) fourth-moment tail comparison and exact T' coefficient algebra. These are finite mechanics, not original cube/highpast traffic or general root certificates. They are separate from all primary R350 counts. The analytic marked-flow receipt above depends on the explicitly inherited true-selector L4 bound, not on those tests.

No R350 author proof or pipeline has been read in this preliminary screen. The intended final audit must separately bind final source/receiver parameter choices and the additional receiver bill.

## Necessary inherited bindings
- `/tmp/r349_core.md` — SHA256 `417b0490f419df19ccebada8398853f72dc1ae509693ccf857ba66fe7ac1034d`
- `/tmp/r349_geometry.md` — SHA256 `8af96a5d51d707b31455e3be61b3349e813443d6261faa121e5243501d10003f`
- `/tmp/r349_audit.md` — SHA256 `22f9fcc3a0e2e4632cee0994451d2abb5652563f2dedcc9beee5dbd9cc8ca070`
- `/tmp/r348_geometry.md` — SHA256 `e86647ca64922f06e3025fca655472a2860e42336506c432251f31a1ab30f137`
- `/tmp/r348_ledger.md` — SHA256 `cb6429b64aea68cda448feb31ade974045abeda9eb4e0831389ca4bb9388369f`
- `/tmp/r347_core.md` — SHA256 `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r344_geometry.md` — SHA256 `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`

## 6. Strengthened independent screen: a capacity-preserving actual upper rank kernel

This last extension was screened before reading the new R350 files. It is stronger than the uniform-upper source split in §4 and is an ALTERNATIVE replacement, not an extra bill to stack with that proposal.

For each source y use the same actual receiver measure

    ξ_y(du)=q_uρ_y(du)=c_u(y)du/R_u^n,
    D(y)=ξ_y(E)=T_R^*1_E(y).

For t>0 the actual closed window t≤m_u≤Kt forces R_u^n∈[t/λ,Kt/q_-]. Its real receiver-center/radius envelope gives

    ξ_y{t≤m≤Kt}≤D0=1+logK+log(λ/q_-).

No new q or source density bound is asserted at auxiliary radii. The original late flow after the old clock is integrated has measure g(y)ζ_y(u)ρ_y(du)dy≤g(y)ξ_y(du)dy. Any positive soft-residual input has a_y(u)U_y(Km_u)>2λB, hence U_y(Km_u)>2B. Consequently

    ξ_y{m_w>Km_u}≥q_-U_y(Km_u)>Δ,
    Δ=2(1+logK)>D0.

Using Δ rather than an exactly D0 shift cleanly enforces the STRICT original upper mass gate without any abstract equality-endpoint assumption.

Spread a mass atom uniformly over its descending ξ-rank interval [U_ξ(m),V_ξ(m)]. This common randomized-rank transform pushes ξ_y to Lebesgue measure on (0,D(y)). Original input, being dominated by ξ_y, has rank density at most one. Each active input rank r is above Δ because the strict upper tail itself has ξ-mass >Δ. Translate to r-Δ. The translated rank is strictly below U_ξ(Km_u), since

    r-Δ≤V_ξ(m_u)-Δ<V_ξ(m_u)-D0≤U_ξ(Km_u).

Thus the destination mass satisfies m_w>Km_u. The target rank law remains dominated by Lebesgue measure; disintegrating the unchanged ξ_y over its rank maps it back to a true receiver marginal dominated by ξ_y. The route is probability-valued for every original active input up to the natural null sets, not merely a subnormalized mass tilt.

Measurability needs a genuine joint rank construction and conditional kernel. All fields are measurable on standard Borel source/receiver spaces. A uniform atom mark makes the rank transform jointly measurable; the finite measure f(y)dy·ξ_y(du) (total ∫fD=X_q) provides a common disintegration base on (y,rank). Its rank marginal is f(y)dy·1_(0,D(y))dr. Every original g≤f input and its translated rank are dominated by this base, so target-kernel null sets do not affect the original traffic. This supplies the required measurable actual-receiver coupling; it is not an independent favorable source choice. The original u and old r labels can be retained through this coupling even though the marginal capacity statement is made after their clock is integrated.

After integrating source y the resulting actual dw density satisfies

    κ(w)≤∫g(y)c_w(y)dy/R_w^n
          =q_w p_w^g≤q_w.

This new rank route is NOT the old uniform ρ_y/U_y upper law. One may retain each edge's strict mass gain >K, but cannot transfer R349's stronger mean drift for the uniform upper law to the new rank law without a new argument. Its capacity proof does not need that drift, the old L_ε column factor, or a renewed a≤λ hypothesis on arrived tokens.

Appending the real posterior mark z~π_w gives new source marginal f(z)ℒ(z) with

    ℒ(z)=∫c_w(z)κ(w)dw/m_w≤D(z).

The inherited actual-selector fixed-exponent adjoint bound is now

    ∫D^4≤C_{4/3}^4|E|≤C_{4/3}^4X_q/q_-.

There is no q_-^5 or λL_ε in this strengthened D-bound. A direct low-D/high-D-clipped marked split would therefore cost sW+δX_q with T'=δq_-s³/C_{4/3}^4; it must not be added as a separate fee to the stronger whole-quality branch below.

## 7. Entire marked quality branch is paid once

Fix s>0, a receiver allocation β>0 and purity threshold 0<θ<1. Define using the ORIGINAL full f and D

    T=βθq_-s³/C_{4/3}^4,
    g_*=1_{D>s}(f-T)_+,
    p_w=∫Q_w g_*/m_w∈[0,1].

The exact lost-posterior mass of the new rank flow is

    Loss=∫κ(w)(1-p_w)dw=∫(f-g_*)(z)ℒ(z)dz.

Using ℒ≤D, low D and the fourth-moment tail gives

    Loss≤sW+T∫_{D>s}D
         ≤sW+(TC_{4/3}^4/(q_-s³))X_q
         =sW+βθX_q.

Hence the ENTIRE old-marked traffic on destination quality p_w≤1-θ is paid by

    G_bad-quality≤Loss/θ≤βX_q+sW/θ.

This is not just the dropped posterior portion and is not a renaming of the original residue. The exact original rank-tagged flow splits into this paid whole branch and its p_w>1-θ complement. Its original y,u,r and rank-w qualifications remain untouched. The intermediate low-D/source-clipping loss is a bound used to pay this branch; charging those two pieces AGAIN would double count.

On the complement, for any θ<η0≤1 let A={D>s,f>T/η0}. Outside A the posterior loss 1-g_*/f is at least η0 (with f=0 irrelevant under π_w). Since 1-p_w<θ,

    π_w(A)>1-θ/η0.

The condition η0≤1 is essential; for η0>1 the loss on D≤s is only one and the stated conclusion need not hold. The primary's fixed θ=1/4 and η0=1/2 are valid and imply that MORE THAN HALF of the true full-f source posterior lies in {D>s,f>2T}.

For s=1+√n and β=ε/16 the paid whole branch costs

    (ε/16)X_q+4(1+√n)W,
    T=εq_-(1+√n)^3/[64C_{4/3}^4].

The source bill is full W, not W_ex. It replaces the tentative uniform-source/low-D/clipped alternatives, while the earlier R348 source soft and arrival fees remain once. The new receiver allocation β is an additional cost: it is multiplied by 2 at the entrance and then by the authentic exterior Λ. With the existing ε, 2Λβ=1/192. The conditional total including old CZ and explicit old γ_eff is

    841/2304+2Λγ_eff+1/192<865/2304,

so more than 1439/2304 remains unallocated. This accounting does not certify other unpaid terms. The new marked concentration complement remains a genuine unpriced original subflow; it cannot be restarted as an independently qualified G with input g_*.

An additional local Python Fraction run passed 1,522 exact scalar rank-shift/column/strict-upper and whole-quality-posterior assertions, with 277 nonzero scalar rank edges. These verify the finite coupling and concentration mechanics, not geometric realization of arbitrary scalar rank inputs. They are separate from the 80 earlier independent checks and from every primary R350 count. The new actual-source proof requires the real ξ-window and original input domination derived above.

At this updated pre-screen's closure no R350 author proof has been read. Later final review must compare its actual rank construction, stopping/zero-row conventions and concentration/complement accounting with this independent derivation.
