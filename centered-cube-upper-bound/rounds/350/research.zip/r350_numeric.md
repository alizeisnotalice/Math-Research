# R350 — marked source resampling and a separate rank-shift certificate

There are two independent modules. The first integrates a **diagnostic uniform-upper route** on true one-dimensional receiver intervals and a real common source. The second tests the new **noncyclic rank-shift kernel on abstract atomic xi**. They are not identified with one another. Neither module implements the original high-past/clock selector or certifies a complete high-dimensional hard branch.

## 1. True continuous marked transport: achievable scope

The actual source/receiver fields reproduce R349's physical construction, copied self-contained. Source f is compact on [-2,2], W=4; all hard responses have actual q=1 and m_u=R_u, verified at every moving-response breakpoint.

| Stage | positive receiver intervals and assigned R | source |
|---|---|---|
|initial|[-1/2,0],R1; [1/4,1/2],R2|uniform density1|
|stress|[-3/4,-1/2],R1; [-1/4,0],R2; [1/4,1/2],R1|period1: density4 on first quarter,else0|
|expanded|[-1,-3/4],R1; [-3/4,-1/4],R5/4; [-1/4,1/4],R3/2; [1/4,1],R2|period1/4: density3 on first quarter,1 on second quarter,else0|

Every R is an integer multiple of its source period; every receiver's hard interval stays inside source support. All receiver measures here are actual du, not quadrature weights. K=5/4 and3/2 are finite diagnostics.

Freeze the entire field. Write `U_y(i)=sum_{R_j>K R_i} length_j(y)/R_j`, where length_j(y) is the actual captured receiver length. Choose the explicit diagnostic row

`zeta_y(u)=gamma_i U_y(i)` on E_i,

`gamma_i=1/[(i+1) max(1,Jmax)]`.

Then 0<=zeta<=q=1 everywhere, and zeta=0 wherever its upper tail is zero. This is **not** original omega, eta, Omega, or a high-past qualification. The original source is not altered to enforce the row cap.

Route a nonzero row by the original uniform-upper probability `c_w(y)dw/[m_w U_y(i)]`. The resulting joint marked measure simplifies exactly to

`f(y)c_u(y)c_w(y) gamma_i dy du dw/(m_u m_w)` on m_w>K m_u.

This cancellation is the reason exact low-degree polynomial integration is possible. The incoming density kappa(w), relative to actual dw, is

`kappa_j(w)=1/m_j integral f(y)c_w(y) sum_{m_j>K m_i} gamma_i length_i(y)/m_i dy`.

The script evaluates it as a continuous piecewise quadratic in w, finding all endpoints and rational vertices for kappa_max. The old total G, computed directly from the source-y row integral, equals integral kappa exactly.

Now keep w and resample **one new source** from the actual full posterior `pi_w(dz)=f(z)c_w(z)dz/m_w`. The new source density relative to dz is `f(z)L(z)`, where

`L(z)=sum_j integral_Ej kappa_j(w)c_w(z)dw/m_j`.

Full resampling gives `integral f(z)L(z)dz=integral kappa=G` exactly. No new source selector, radius, q, or denominator is substituted. For a piecewise-constant new source component h(z), this integral is computed by integrating kappa's quadratic pieces against the affine overlap of h with Q_Rj(w), an exact cubic integral. No source or receiver sampling replaces these integrals.

### New-source clipping and low-J split

For T=1/2,2,4, split the **new z source** as g=min(f,T) and e=(f-T)_+. Kappa still comes from original full f(y), and the posterior denominators remain original m_w. Each component is a subprobability of the old posterior; it is **not renormalized** by its own captured mass. Exact integrals verify G_g+G_e=G and W_g+W_e=W.

At s=0,1/8,1/4,1/2,Jmax, split z space at every exact crossing J_b(z)=s, with the original full-field J. The low/high new source integrals add to G. Exact calculations verify

`G_new,low <= kappa_max integral_{J<=s} f J <= kappa_max s W`.

The same statements hold for new g and e separately with their own masses and the **same original** J and kappa. The s=0 contribution is exactly0. Pointwise `L<=kappa_max J` follows analytically from the computed continuous kappa bound; a separate finite z-grid checks it too, but those grid checks are not the proof of continuous source integrals.

### Actual examples

| Field | K | old G = incoming = new full-source total | exact kappa_max |
|---|---:|---:|---:|
|initial|5/4 or3/2|41/768|15/64|
|stress|5/4 or3/2|1/24|1/6|
|expanded|5/4|68711/612864|1797/8512|
|expanded|3/2|407/9728|1167/8512|

In the initial field, s=1/8 gives low new-source flow571/24576, bounded by15/128. In the concentrated stress field, the low new-J flow is zero at both s1/8 and1/4: all new-source flow1/24 remains above that cutoff. Thus low-new-J payment is real but is not claimed to pay the entire flow. At T2 the stress flow splits exactly1/48+1/48 between new clip and excess. Expanded K5/4 at s1/4 has low new-source flow486991/78446592; its bound is1797/8512.

This is a uniform-router diagnostic; its computed kappa_max is an instance value, not an inference that a transported old flow automatically satisfies the old receiver cap.

## 2. Separate abstract increasing-rank shift

The new rank module follows the geometry author's definition on finite **xi atoms**, with rational logmass levels l_i and weights. It is not the zeta above and is not an actual-cube realization.

Sort increasing levels and group equal levels. Each level atom occupies its entire ascending rank interval `(Fminus(l),F(l)]`, with uniform rank conditional on the atom. Let A=xi(total), let D0 be the exact largest **closed** level-window mass of length L, and choose rational shift d=D0+1>D0. Send rank s to s+d only when s+d<=A. The upper end is discarded, never wrapped to the bottom. Target rank is disintegrated uniformly back within its target mass atom.

For every nonzero rank block the target satisfies `target_level>source_level+L`. Indeed a rank displacement remaining in a closed L-window could not exceed D0. Every row with strict upper xi-mass beyond level+L greater than d has its **entire** rank interval retained and row probability1. Other rows are only subrows and may lose mass at the top; no conservation of discarded input is asserted.

Input density t is either1 or varies through0,1/3,2/3,1 on the original atoms, so 0<=t<=1. Repeated-level input densities are averaged using their original xi weights, exactly corresponding to uniform conditional rank. The shifted source rank intervals are disjoint, so the output is a xi-submeasure. The code verifies column density<=1 at **every original target atom**, not just after total integration. Retained outgoing equals incoming. For t=1, the total is exactly max(A-d,0).

| Abstract model | A | D0 | d | strict-active level count | retained total at t=1 |
|---|---:|---:|---:|---:|---:|
|uniform8, separated levels|8|1|2|5|6|
|single heavy atom|3|3|4|0|0|
|middle-heavy16|25|12|13|5|12|
|repeated levels16|16|2|3|11|13|
|unequal64|319/4|21/4|25/4|55|147/2|
|unequal256|1279/4|21/4|25/4|247|627/2|

The total in this table includes all retained subrows, not only the strict-active subset. Active rows lose none; restricting input to that subset would only reduce columns. The latest actual proof's root shift is not replaced by these abstract diagnostic d values.

## Counts, reproducibility, and limits

Two fresh independent processes passed **3,471 exact rational checks**, separated as:

- 949 continuous source/receiver integral, cap, and polynomial-extremum checks;
- 140 finite z-grid pointwise diagnostics, explicitly not continuous-integral evidence;
- 2,382 abstract rank checks (initial59, stress213, expanded2,110).

The continuous-model totals including their grid checks are183/225/681. All comparisons use Fraction; no floating estimate or optimizer status certifies a claim. General conservation/low-J/rank propositions are analytic facts being tested on these inputs, not established for the original full theorem by finite computation.

Only `r350_numeric.py`, `r350_numeric_result.json`, and this note are needed. Standard library, no old /tmp imports:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r350_numeric.py
```

The JSON is written beside the script and records original source/receiver intervals, incoming quadratic pieces, exact new-source clip and low-J integrals, the finite z grid, and abstract rank inputs/columns. Both modules retain their independent scopes; neither claims original high-past or clock realization.
