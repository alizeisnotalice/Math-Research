# R350 final independent audit

**PASS for the frozen statements and their stated scope.** The actual q-weighted capture rank route is probability-valued on the original positive late input and has the asserted dominated column. It supplies a genuine whole diffuse-witness branch payment. The concentrated marked complement and the general weak-type target remain unpaid.

The candidate identities, strict-rank issue and whole-branch estimate were independently derived before author reading in `/tmp/r350_audit_pre.md`. This final review read the complete geometry, core, main, ledger, numerical note and all four scripts. Only owned audit files were written. No author file, numerical result or Git state was changed, and the primary's full pipelines were not repeated. Historical reductions and the prior external maximal theorem are inherited interfaces, not comprehensively recertified here.

## 1. True q-weighted window and positive original input

The original late measure retains full f, actual du, source g=g_ex≤f, physical ell with b atom, and every old η/Ω/relative/late/H/high-past/outside/small-endpoint gate. After integrating only the old clock its density is exactly g(y)t_y(u)ξ_y(du)dy, where

    ξ_y=q_uρ_y=c_u(y)du/R_u^n,   0≤t_y≤1.

This is domination of the original input, not a new row bound asserted after transport. Positive t implies the OLD score mask η>0, hence U_y(Km_u)>2B and ξ_y{m>Km_u}>Δ=2(1+√n).

The real closed mass-window cap is D0=1+logK+log(λ/q_-). On t≤m_u≤Kt the actual radii lie between (t/λ)^(1/n) and (Kt/q_-)^(1/n); integrating the centered receiver density envelope R_u^(-n) gives precisely D0. It is actual center volume, not a source density cap or a free abstract mass model. Closed mass atoms are included. The chosen uniform shift Δ strictly exceeds D0 and is strictly smaller than the upper ξ-mass on every positive input row. These two strict inequalities resolve the mass-ratio endpoint problem.

## 2. Rank probability, measurability and actual column

The increasing-mass rank transform spreads a mass atom uniformly on its entire rank interval and uses its distributional-transform Dirac convention on the nonatomic part. It sends ξ_y to Lebesgue rank measure on (0,D(y)), D(y)=ξ_y(E). The joint source/rank/receiver disintegration is legitimate on standard Borel versions. In particular its base measure dy·ξ_y is finite, with total |E|, since ∫D(y)dy=|E|. Thus a jointly measurable conditional target kernel exists. The usual conditional null sets have no original g(y)dy input mass; translation preserves target-rank null sets. All probability/support assertions are used in this natural joint almost-everywhere sense. Zero and discarded rows cause no lost actual traffic.

The map s→s+Δ is linear and NONCYCLIC. On a positive old row, every starting rank lies strictly below D(y)-Δ, because the upper mass beyond Km_u is >Δ. Therefore no rank from that input is discarded and its row integral is one. If a produced witness had m_w≤Km_u, rank compatibility would force

    Δ≤ξ_y{m_u≤m≤Km_u}≤D0,

a contradiction. The resulting witness strictly satisfies m_w>Km_u, including all mass atoms. For the whole reference measure the route is only a sub-Markov kernel: high ranks are discarded. Integrating its translated rank interval gives a column submeasure ≤ξ_y. There is no claim of conservation or invariance on all ξ_y inputs; conservation holds for the actual positive input supported where upper availability was proved.

Contracting the old clock by t_y≤1 and then source-integrating gives the exact incoming density relative to real dw:

    κ(w)≤∫g(y)c_w(y)dy/R_w^n=q_w p_w^g≤q_w,
    ∫κ=G_late[g].

Original y,u,r and, if displayed, the old small-endpoint label remain in the joint measure. A selected w is a terminal witness, not an original qualified row at a new physical time. The proof does not replace current J or reset a/η. The kernel differs from the old uniform ρ/U route, so its old average drift, variance formula and E_gain estimate are not automatically inherited. Main makes this distinction explicit.

## 3. Source marking, fourth-moment factor and whole branch payment

Appending the genuine posterior π_w=f(z)c_w(z)dz/m_w preserves total original cost and gives the exact new-source marginal f(z)L(z), with

    L(z)=∫c_w(z)κ(w)dw/m_w≤D(z),
    D=T_R^*1_E=∫c_w(z)dw/R_w^n.

D is not J_b. The inherited fixed-exponent centered-cube maximal bound gives ∫D^4≤C^4|E|≤C^4X_q/q_-. The power is q_-^(-1); q_-^(-5) belongs to the old J fourth moment and is used only in the separate uniform fallback. C remains a fixed dimension-independent constant of unspecified numerical value.

Core's low-D/new-source-clipped split is exact and preserves all ancestral labels. It gives a valid alternative receipt with source sW and receiver δX_q, T=δq_-s³/C^4. Its tagged residual is not a restarted original G. The final main uses a stronger WHOLE-witness allocation from the same defect; it does not add the core alternative's bills again.

Specifically let T=βθq_-s³/C^4, e=1_{D>s}(1-T/f)_+ (zero on f=0), and p_w=E_{π_w}e. The exact defect is

    Loss=∫κ(1-p)=∫(f-g_*)L≤sW+βθX_q,
    g_*=1_{D>s}(f-T)_+.

The s^(-3) fourth-moment tail is correct because the integrand contains D. On p_w≤1-θ the loss is at least θ times the WHOLE marked-witness cost, hence

    G_diff≤βX_q+(s/θ)W,
    G_late=G_diff+G_conc.

The final proof uses this exact disjoint split rather than replacing a previous upper-bound residual by a smaller one. It pays more than only the clipped/new-source defect fraction. There is no guarantee that a favorable witness branch must have positive mass for every input, but its stated whole positive branch has a genuine general receipt.

On p_w>1-θ, for θ<η0<1 the set A={D>s,f>T/η0} has π_w-mass >1-θ/η0, since outside it the retained posterior defect is ≥η0. The restriction η0≤1 is essential and is respected in the final main. At θ=1/4, η0=1/2, every remaining w has more than half of its TRUE full-f source mass in {D>s,f>2T}. This is a source mass condition, not a volume assertion or an assumed density cap.

For s=1+√n, β=ε/16, T=εq_-(1+√n)^3/(64C^4), the new source fee is full 4(1+√n)W and the new receiver fee is βX_q. W_ex cannot replace W here because the NEW posterior source uses full f, although old g_ex(y) and every old gate remain in the marked input. No new mass/q/receiver field is computed from g_*. The concentrated complement cannot be iterated as a fresh qualified G without a separate capacity argument.

## 4. Complete ledger and still-unpaid geometry

The slot is reconstructed at the original R348 G_late entry and replaced exactly once:

    B_H≤G_conc+[(13/3)ε+γ_eff+β]X_q
           +[C_{ε,n}+4(1+√n)]W
           +(D_top,n+C_hit,n)W_ex.

The original soft payment, relative-low fee and arrived-clock fee remain once. The new low-D/clip defect estimates and the uniform fallback are internal or alternative arguments, not additional fees. The entrance doubles all terms; the new entrance source fee is 8(1+√n)W, and any authentic outer Λ also multiplies it.

With Λ=128/119, ε=119/3072 and β=ε/16, the new receiver allocation is 2Λβ=1/192. If the old CZ 1/256 is in the same authenticated X account, the total is

    853/2304+2Λγ_eff<865/2304,

with more than 1439/2304 unallocated. The inherited γ_eff guard is retained: zero on dimensions/radius bands where original high-past traffic is forced empty, otherwise <ε/16. Unallocated space is not payment for the other slots and does not authenticate arbitrary leaf-volume/source aggregation.

The ledger explicitly retains G_conc with old late/high-past/outside/soft/source/clock labels; general soft/crossing/innovation and hard-contract complements; wide/extreme scales and height/threshold complements; chronology initialization/deletion/future-deleted-source terms; H/layer/source/scale/outer/limit costs; and single-use negative credit. Physical b atoms are preserved and do not replace chronological atoms. Main does not claim general root-order closure or that only constants/logarithms remain.

## 5. Evidence, code scope and executed records

The primary reports fresh successful runs of numeric 3,471 exact checks, parent 19,290 finite rational cases plus four separate ledger checks, the embedded core parameter/fixture checks and the embedded geometry rank/threshold checks. This reviewer read all four scripts, parsed the saved numeric JSON and confirmed both standalone geometry/core scripts are byte-for-byte their unique embedded Python blocks. The full pipelines were not repeated, and independent pre-screen diagnostics are not added to primary totals.

The numeric JSON records PASS: continuous-model counts 183/225/681 (1,089 including grid), of which 140 are separately named finite z-grid checks, leaving 949 actual continuous integral/cap/polynomial-extremum checks; the independent abstract rank module has 2,382. These sum to 3,471. The continuous module uses true positive-volume 1D receivers and full compact nonnegative L¹ sources with q=1 verified at complete moving-response breakpoints. Its row ζ=γ_i U is deliberately diagnostic and its router is the OLD uniform-upper law, not the new rank kernel or original root high-past/clock field.

Continuous old-flow/incoming/new-source mass conservation uses exact piecewise quadratic and cubic integration. Incoming maxima include every relevant shifted breakpoint and vertex. New-source J cutoffs include their exact affine crossing points and plateau/equality convention; all new min/excess splits keep the old source-y field, κ and posterior m denominators unchanged. Grid pointwise checks are not used as evidence for those continuous integrals. The numeric note correctly separates these uniform-router examples from the new theoretical D-bound/rank theorem.

The abstract rank module uses grouped logmass atoms, closed window capacity, a larger noncyclic shift, atom-conditional uniform ranks and every original target column. Active rows retain probability one; unqualified higher rows may lose mass, which the note does not count as original conserved input. Repeated-level input densities are averaged with their original ξ weights; their [0,1] cap ensures the target column cap. This is finite rank mechanics, not a cube realization or simultaneous-full-f extremizer.

Parent's 19,290 cases verify defect/concentration algebra and whole witness fees; its four final Fraction assertions verify the actual same-account fractions. Core's 108 strong and 324 fallback parameter substitutions use formal positive C^4 values, not claimed numerical maximal constants. Its real marked fixture has actual source/capture/clock and source-split identities but diagnostic parameters and omitted outside; it is not a general rank or root-hard traffic simulation. Geometry's eight active atoms, twelve targets and thirty-six substitutions are abstract rank/algebra units, not an inflated count of original geometry models. All these distinctions are consistent with the final notes. The general result rests on the analytic real ξ-window, measurable probability coupling and inherited L4 input.

## 6. Frozen SHA256 bindings
- `/tmp/r350_main.md` — `10145c9409bbdfefd1efeccc9180123ff2c48ceb350eb42a291412bc4224bc85`
- `/tmp/r350_ledger.md` — `5d7634654dae1fef93db81e5bd9d354b3a917cf54467e65f9ad597ee50a1bf97`
- `/tmp/r350_geometry.md` — `eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20`
- `/tmp/r350_core.md` — `133d639819177b06cf4c5078cd6471bfbb9c37a27f9669fdd235e4b353804064`
- `/tmp/r350_numeric.md` — `9d725176cc91ff43a3f81bdcedd010f1a8083a1be77a85827a32b0ffdf676981`
- `/tmp/r350_geometry_checks.py` — `9a7b5635ca1fe1f6fa513048fcb78136831a980894c966a27d110503e8b87aa1`
- `/tmp/r350_core_checks.py` — `4ee9682be664283a20d905d4e2e4642c18cfa739c08797ef9832dd1fdb9378c9`
- `/tmp/r350_numeric.py` — `fe28c0624c880907eb4894ed8ed0dd038829abb8a7cc3e9744c66620bbc7352d`
- `/tmp/r350_numeric_result.json` — `0dd49fe9b660b6062cf0566170c127060121ab5cc974ba3063d28831ed4027de`
- `/tmp/r350_parent.py` — `49d1bf6cdf8a23e170e47d91d672a59728c8b5885734e62b52cff5a9271918de`
- `/tmp/r350_audit_pre.md` — `95249d4c6a2cce9b33449ca4b75f60d20ecc3baeb73e4df50f6603009ec6451c`
- `/tmp/r349_geometry.md` — `8af96a5d51d707b31455e3be61b3349e813443d6261faa121e5243501d10003f`
- `/tmp/r349_core.md` — `417b0490f419df19ccebada8398853f72dc1ae509693ccf857ba66fe7ac1034d`
- `/tmp/r349_audit.md` — `22f9fcc3a0e2e4632cee0994451d2abb5652563f2dedcc9beee5dbd9cc8ca070`
- `/tmp/r348_geometry.md` — `e86647ca64922f06e3025fca655472a2860e42336506c432251f31a1ab30f137`
- `/tmp/r348_core.md` — `dafedb811ac0719cf7a63502051dd13d2ccf5eb6cd5d695fb6854de509ff8ab3`
- `/tmp/r348_ledger.md` — `cb6429b64aea68cda448feb31ade974045abeda9eb4e0831389ca4bb9388369f`
- `/tmp/r347_core.md` — `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r344_geometry.md` — `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`
- `/tmp/r340_core.md` — `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90`

Earlier files are bound as the necessary inherited interfaces, not as a fresh comprehensive review of history. The preliminary audit remains the independent-before-author record. This final receipt binds current final bytes; packaging prior interfaces by links rather than duplicated files does not change their mathematical scope. No TeX/PDF compilation or independent line-by-line review of a later primary TeX artifact is certified here.
