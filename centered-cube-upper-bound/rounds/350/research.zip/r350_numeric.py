#!/usr/bin/env python3
"""True continuous uniform-upper diagnostic and marked-source resampling."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k

def sources(mode):
 if mode=='uniform':return [(F(-2),F(2),F(1))]
 period=F(1) if mode=='packet' else F(1,4)
 profile=[(F(0),period/4,F(4)),(period/4,period,F(0))] if mode=='packet' else [(F(0),period/4,F(3)),(period/4,period/2,F(1)),(period/2,period,F(0))]
 return [(a+j*period,b+j*period,d) for j in range(-int(2/period),int(2/period)) for a,b,d in profile]
def fixtures():
 return [('initial',[(F(-1,2),F(0),F(1)),(F(1,4),F(1,2),F(2))],'uniform'),('boundary_stress',[(F(-3,4),F(-1,2),F(1)),(F(-1,4),F(0),F(2)),(F(1,4),F(1,2),F(1))],'packet'),('expanded',[(F(-1),F(-3,4),F(1)),(F(-3,4),F(-1,4),F(5,4)),(F(-1,4),F(1,4),F(3,2)),(F(1,4),F(1),F(2))],'two_level_quarter')]
def mass(src,lo,hi):return sum((max(F(0),min(b,hi)-max(a,lo))*d for a,b,d in src),F(0))
def cap(e,y):
 a,b,R=e;return max(F(0),min(b,y+R/2)-max(a,y-R/2))
def J(E,y):return sum((cap(e,y)/e[2] for e in E),F(0))
def zbreaks(src,E):return sorted(set([F(-2),F(2)]+[z for a,b,d in src for z in [a,b]]+[z+s*R/2 for a,b,R in E for z in [a,b] for s in [-1,1]]))
def density(src,y):return next((d for a,b,d in src if a<y<b),F(0))
def prodint(a,b,fa,fb,ga,gb):return (b-a)*(2*fa*ga+fa*gb+fb*ga+2*fb*gb)/6

def weighted_segments(src,E,coef):
 points=zbreaks(src,E);out=[]
 for a,b in zip(points,points[1:]):
  d=density(src,(a+b)/2);out.append((a,b,d*sum(t*cap(e,a) for e,t in zip(E,coef)),d*sum(t*cap(e,b) for e,t in zip(E,coef))))
 return out

def integrate_linear(seg,lo,hi):
 out=F(0)
 for a,b,fa,fb in seg:
  left=max(a,lo);right=min(b,hi)
  if left>=right:continue
  slope=(fb-fa)/(b-a);out+=(right-left)*(2*fa+slope*(left+right-2*a))/2
 return out

def incoming_quads(seg,E_j):
 lo,hi,R=E_j;points=sorted(set([lo,hi]+[z+s*R/2 for a,b,fa,fb in seg for z in [a,b] for s in [-1,1] if lo<z+s*R/2<hi]));out=[];maximum=F(0)
 def value(w):return integrate_linear(seg,w-R/2,w+R/2)
 for a,b in zip(points,points[1:]):
  L=b-a;fa=value(a);fb=value(b);fm=value((a+b)/2);A=2*(fa+fb-2*fm)/(L*L);B=(fb-fa)/L-A*L;out.append((a,b,fa,B,A));probes=[fa,fb]
  ck('integral_incoming_quadratic_quarter_check',value(a+L/4)==fa+B*L/4+A*L*L/16)
  if A:
   t=-B/(2*A)
   if 0<t<L:probes.append(fa+B*t+A*t*t)
  maximum=max(maximum,*probes)
 return out,maximum

def quad_integral(polys,lo=None,hi=None):
 out=F(0)
 for a,b,fa,B,A in polys:
  left=max(a,lo) if lo is not None else a;right=min(b,hi) if hi is not None else b
  if left>=right:continue
  x=left-a;y=right-a;out+=fa*(y-x)+B*(y*y-x*x)/2+A*(y**3-x**3)/3
 return out

def marked_source_integral(polys,E_j,source_z):
 # Integral kappa(w)/m_w * integral_source_z c_w(z) dz dw.
 R=E_j[2];ans=F(0);src=[s for s in source_z if s[2]]
 for a,b,fa,B,A in polys:
  points=sorted(set([a,b]+[z+s*R/2 for lo,hi,d in src for z in [lo,hi] for s in [-1,1] if a<z+s*R/2<b]))
  for left,right in zip(points,points[1:]):
   L=right-left;t=left-a;coeff=[fa+B*t+A*t*t,B+2*A*t,A];ga=mass(src,left-R/2,left+R/2);gb=mass(src,right-R/2,right+R/2);slope=(gb-ga)/L
   ans+=sum((c*(ga*L**(j+1)/F(j+1)+slope*L**(j+2)/F(j+2)) for j,c in enumerate(coeff)),F(0))/R
 return ans

def split_source_by_J(src,E,s):
 base=zbreaks(src,E);points=set(base)
 for a,b in zip(base,base[1:]):
  ja=J(E,a);jb=J(E,b)
  if (ja-s)*(jb-s)<0:points.add(a+(s-ja)*(b-a)/(jb-ja))
 points=sorted(points);low=[];high=[];Jlow=F(0)
 for a,b in zip(points,points[1:]):
  y=(a+b)/2;d=density(src,y);target=low if J(E,y)<=s else high;target.append((a,b,d))
  if J(E,y)<=s:Jlow+=d*(b-a)*(J(E,a)+J(E,b))/2
 return low,high,Jlow

def model(name,E,mode):
 before=sum(C.values());src=sources(mode);points=zbreaks(src,E);N=len(E);W=mass(src,F(-2),F(2));Jmax=max(J(E,y) for y in points);gamma=[1/(max(F(1),Jmax)*F(i+1)) for i in range(N)]
 ck('integral_positive_disjoint_receiver_fields',all(b>a for a,b,R in E) and all(E[i][1]<=E[i+1][0] for i in range(N-1)))
 for a,b,R in E:
  qpoints=sorted(set([a,b]+[z+sgn*R/2 for lo,hi,d in src for z in [lo,hi] for sgn in [-1,1] if a<z+sgn*R/2<b]))
  for u in qpoints:ck('integral_actual_full_source_q_one',mass(src,u-R/2,u+R/2)==R)
 results=[]
 for K in [F(5,4),F(3,2)]:
  flow=F(0)
  for a,b in zip(points,points[1:]):
   d=density(src,(a+b)/2)
   for i,e in enumerate(E):
    upper=[f for f in E if f[2]>K*e[2]];Ua=sum(cap(f,a)/f[2] for f in upper);Ub=sum(cap(f,b)/f[2] for f in upper)
    ck('integral_diagnostic_zeta_cap',0<=gamma[i]*Ua<=1 and 0<=gamma[i]*Ub<=1)
    flow+=d*gamma[i]/e[2]*prodint(a,b,cap(e,a),cap(e,b),Ua,Ub)
  kappas=[];kmax=F(0)
  for j,e in enumerate(E):
   coef=[gamma[i]/(f[2]*e[2]) if e[2]>K*f[2] else F(0) for i,f in enumerate(E)];seg=weighted_segments(src,E,coef);polys,mx=incoming_quads(seg,e);kappas.append(polys);kmax=max(kmax,mx)
  incoming=sum((quad_integral(p) for p in kappas),F(0));newfull=sum((marked_source_integral(p,e,src) for p,e in zip(kappas,E)),F(0))
  ck('integral_original_upper_incoming_conservation',flow==incoming)
  ck('integral_uniform_resampling_full_source_conservation',newfull==flow)
  # Exact finite z-grid diagnostics are separately counted, not used as integral proofs.
  grid=[]
  for z in points:
   Lz=sum((quad_integral(p,z-e[2]/2,z+e[2]/2)/e[2] for p,e in zip(kappas,E)),F(0));ck('grid_new_source_density_below_kmax_J',0<=Lz<=kmax*J(E,z))
   if len(grid)<6:grid.append(dict(z=str(z),L=str(Lz),original_J=str(J(E,z))))
  clips=[]
  for T in [F(1,2),F(2),F(4)]:
   gz=[(a,b,min(d,T)) for a,b,d in src];ez=[(a,b,max(F(0),d-T)) for a,b,d in src];gflow=sum((marked_source_integral(p,e,gz) for p,e in zip(kappas,E)),F(0));eflow=sum((marked_source_integral(p,e,ez) for p,e in zip(kappas,E)),F(0));Wg=mass(gz,F(-2),F(2));We=mass(ez,F(-2),F(2))
   ck('integral_new_source_clip_excess_conservation',gflow+eflow==flow and Wg+We==W)
   clips.append(dict(T=str(T),g_new_source_flow=str(gflow),excess_new_source_flow=str(eflow),g_source_mass=str(Wg),excess_source_mass=str(We)))
  lowrows=[]
  for s in sorted(set([F(0),F(1,8),F(1,4),F(1,2),Jmax])):
   lo,hi,Jlow=split_source_by_J(src,E,s);lowflow=sum((marked_source_integral(p,e,lo) for p,e in zip(kappas,E)),F(0));highflow=sum((marked_source_integral(p,e,hi) for p,e in zip(kappas,E)),F(0))
   ck('integral_new_source_low_high_conservation',lowflow+highflow==flow)
   ck('integral_new_low_J_mass_bound',lowflow<=kmax*Jlow<=kmax*s*W)
   if s==0:ck('integral_zero_new_J_no_flow',lowflow==0)
   part=[]
   for T in [F(1,2),F(2),F(4)]:
    g_low=[(a,b,min(d,T)) for a,b,d in lo];e_low=[(a,b,max(F(0),d-T)) for a,b,d in lo];gl=sum((marked_source_integral(p,e,g_low) for p,e in zip(kappas,E)),F(0));el=sum((marked_source_integral(p,e,e_low) for p,e in zip(kappas,E)),F(0));gJ=eJ=F(0)
    for a,b,d in lo:
     base=(b-a)*(J(E,a)+J(E,b))/2;gJ+=min(d,T)*base;eJ+=max(F(0),d-T)*base
    Wg=sum((b-a)*min(d,T) for a,b,d in src);We=W-Wg
    ck('integral_new_low_clip_excess_conservation',gl+el==lowflow)
    ck('integral_new_low_clip_bound',gl<=kmax*gJ<=kmax*s*Wg)
    ck('integral_new_low_excess_bound',el<=kmax*eJ<=kmax*s*We)
    part.append(dict(T=str(T),g_low_flow=str(gl),excess_low_flow=str(el)))
   lowrows.append(dict(s=str(s),low_new_source_flow=str(lowflow),high_new_source_flow=str(highflow),actual_low_fJ=str(Jlow),kappa_max_times_sW=str(kmax*s*W),clip_excess=part))
  results.append(dict(K=str(K),diagnostic_gamma=list(map(str,gamma)),original_flow=str(flow),incoming_total=str(incoming),new_source_total=str(newfull),kappa_max=str(kmax),kappa_quadratic_pieces=[[[str(v) for v in piece] for piece in p] for p in kappas],new_source_clip_excess=clips,new_source_low_J=lowrows,z_grid_diagnostic=grid,scope='Uniform-upper router with diagnostic zeta=gamma_i U, not the new rank-shift router and not original eta/Omega/highpast. All source clipping is at NEW z; original y field and kappa stay frozen.'))
 return dict(stage=name,source_mode=mode,source_intervals=[list(map(str,s)) for s in src],receiver_intervals=[list(map(str,e)) for e in E],q_original='1',W=str(W),Jmax=str(Jmax),results=results,exact_checks=sum(C.values())-before)

def abstract_rank_tests():
 before=sum(C.values());configs=[('initial','uniform8',[(F(3*i),F(1)) for i in range(8)],F(1)),('initial','singleheavy',[(F(0),F(3))],F(1)),('boundary_stress','middleheavy16',[(F(i),F(10) if i==7 else F(1)) for i in range(16)],F(2)),('boundary_stress','repeated_levels16',[(F(i//2),F(1,2)) for i in range(32)],F(1)),('expanded','unequal64',[(F(i),F(1)+F(i%3,4)) for i in range(64)],F(3)),('expanded','unequal256',[(F(i),F(1)+F(i%3,4)) for i in range(256)],F(3))];records=[];stage_counts={}
 for stage,name,atoms,L in configs:
  start=sum(C.values());groups={}
  for level,w in atoms:groups[level]=groups.get(level,F(0))+w
  levels=sorted(groups);A=sum(groups.values());critical=set(levels)|{z-L for z in levels};D0=max(sum((w for level,w in groups.items() if a<=level<=a+L),F(0)) for a in critical);d=D0+1;ck('rank_strict_shift_above_closed_window_capacity',d>D0)
  spans={};acc=F(0)
  for level in levels:spans[level]=(acc,acc+groups[level]);acc+=groups[level]
  E={};rowsum={level:F(0) for level in levels};incoming_unweighted={level:F(0) for level in levels}
  for u in levels:
   for w in levels:
    a,b=spans[u];c,e=spans[w];length=max(F(0),min(b+d,e,A)-max(a+d,c,d));E[u,w]=length;rowsum[u]+=length/groups[u];incoming_unweighted[w]+=length
    if length:ck('rank_strict_logmass_gap_every_target',w>u+L)
  active_levels=[]
  for u in levels:
   ck('rank_nonwrapping_subrow_probability',0<=rowsum[u]<=1)
   upper=sum((w for level,w in groups.items() if level>u+L),F(0))
   if upper>d:
    active_levels.append(u);ck('rank_active_entire_atom_row_probability_one',rowsum[u]==1)
  for w in levels:
   lo,hi=spans[w];expected=max(F(0),min(hi,A)-max(lo,d));ck('rank_unweighted_column_exact_shifted_submeasure',incoming_unweighted[w]==expected<=groups[w])
  modes=[]
  for mode in ['one','varying_zero_to_one']:
   original_t=[F(1) if mode=='one' else F(i%4,3) for i in range(len(atoms))];tbar={level:sum(w*t for (ell,w),t in zip(atoms,original_t) if ell==level)/groups[level] for level in levels}
   ck('rank_original_input_densities_unit_bound',all(0<=t<=1 for t in original_t))
   column={w:sum((tbar[u]*E[u,w] for u in levels),F(0))/groups[w] for w in levels};outgoing=sum(w*t*rowsum[level] for (level,w),t in zip(atoms,original_t));incoming=sum(groups[w]*column[w] for w in levels)
   ck('rank_original_weighted_mass_conservation',outgoing==incoming)
   for level,w in atoms:ck('rank_every_original_target_column_dominated',0<=column[level]<=1)
   if mode=='one':ck('rank_no_wrap_total_mass',outgoing==max(F(0),A-d))
   modes.append(dict(input_density_mode=mode,input_density_original=list(map(str,original_t)),total_outgoing=str(outgoing),total_incoming=str(incoming),column_density_relative_xi={str(z):str(v) for z,v in column.items()},max_column_density=str(max(column.values())),scope='Abstract xi rank certificate only; not the continuous diagnostic zeta and not original geometric traffic.'))
  checks=sum(C.values())-start;stage_counts[stage]=stage_counts.get(stage,0)+checks;records.append(dict(stage=stage,name=name,atoms_logmasslevel_weight=[list(map(str,a)) for a in atoms],logmass_window_length=str(L),total_xi=str(A),closed_window_cap_D0=str(D0),noncyclic_shift_d=str(d),row_probability={str(z):str(v) for z,v in rowsum.items()},nonzero_rank_blocks=sum(v>0 for v in E.values()),active_source_levels=list(map(str,active_levels)),active_source_measure=str(sum(groups[u] for u in active_levels)),modes=modes,exact_checks=checks))
 return dict(exact_checks=sum(C.values())-before,stage_counts=stage_counts,models=records,scope='Independent abstract atom-safe ascending-rank linear shift s->s+d, truncated at total A, never cyclic. Mass atoms occupy full rank intervals. Logmass levels are exact rational labels; positive flow has targetlevel-sourcelevel>L. No actual-cube realization claimed.')

def main():
 models=[model(*f) for f in fixtures()];rank=abstract_rank_tests();out=dict(abstract_rank_certificate=rank,status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=models,scope='Exact continuous 1D diagnostic marked transport/source integrals; finite z-grid checks separately named. No original highpast/root realization; abstract rank-shift module is separate from continuous diagnostic uniform routing. General conservation and low-J facts are analytic inputs tested only on these fields.')
 (BASE/'r350_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),model_checks=[m['exact_checks'] for m in models],abstract_rank_checks=rank['exact_checks'],abstract_rank_stages=rank['stage_counts']),sort_keys=True))
if __name__=='__main__':main()
