# R350 — New-source capacity payment after the actual rank routing

**Theorem.** Use the full R348 late flow and the R350 actual-rank routing
lemma, with all fields frozen from the original \(f\). For every
\(s,\delta>0\), source resampling gives an exact marked residual
\(\mathcal R_{s,T}\) such that
\[
 G_{\rm late}\le\mathcal R_{s,T}+\delta X_q+sW,
 \qquad T=\frac{\delta q_-s^3}{C^4}.                       \tag{1}
\]
Here \(W=\int f\) and \(C\) is the audited dimension-independent
\(L^{4/3}\) centered-cube maximal constant from R344; no numerical value
of \(C\) is asserted. In particular,
\[
 G_{\rm late}\le\mathcal R_{1+\sqrt n,T}
          +\delta X_q+(1+\sqrt n)W,\qquad
 T=\frac{\delta q_-(1+\sqrt n)^3}{C^4}.                    \tag{2}
\]
This is a genuine new-source branch payment. The residual is a portion
of the full original marked flow, not a new original traffic operator.
A general budget for that residual is not established.

## 1. Original labels and the capacity-preserving upper kernel

Keep \(m_u=\int f c_u=q_uR_u^n\), \(q_-\le q_u\le\lambda\),
\(a\le R_u\le b\le2a\), actual receiver measure \(du\), and
\[
 \rho_y(du)=c_u(y)du/m_u,\quad
 \xi_y(du)=q_u\rho_y(du),\quad
 J_y(r)=\rho_y\{R_u\le r\},\quad
 U_y(t)=\rho_y\{m>t\}.
\]
All these fields use full \(f\), even though the original outer source is
\(g=g_{\rm ex}\le f\). The clock remains
\(\ell=b^{-n}\delta_b+n r^{-n-1}dr\).

Use exactly the original R348 quantities
\[
 a_y(u)=q_u\omega_y(u),\quad B=(1+\sqrt n)/q_-,\quad
 \eta_y(u)=(1-2\lambda B/[a_y(u)U_y(Km_u)])_+,\quad
 K=e^{\sqrt n},
\]
with the original zero convention, and
\[
 \chi_y(u,r)=1_{\{U_y(Km_u)>\varepsilon J_y(b)\}}
             1_{\{U_y^r(Km_u)\le1/q_-\}}.
\]
The complete original \(\Omega_y(u,r)\) retains the old small receiver,
outside-center, high-past, far-mass, \(H\), and full \(J_y(r)\) factors.
For \(r\in[R_u,b]\), define the unchanged pre-routing measure
\[
 dF(y,u,r)=g(y)c_u(y)\eta_y(u)\Omega_y(u,r)\chi_y(u,r)
                                    \,dy\,du\,\ell(dr).
 \qquad |F|=G_{\rm late}.                                \tag{3}
\]

We use the following precise R350 geometry lemma, whose rank construction
and measurable atom treatment are supplied in /tmp/r350_geometry.md.
There is a jointly measurable probability kernel \(P_y(u,dw)\) on
\(\mathcal A_y=\{u:\eta_y(u)>0\}\), supported on actual receivers with
\(m_w>Km_u\), satisfying
\[
 \int_{\mathcal A_y}\xi_y(du)P_y(u,dw)\le\xi_y(dw).         \tag{4}
\]
For provenance of its hypotheses, the real closed mass-window bound is
\[
 \xi_y\{t\le m\le Kt\}\le
 D_0=1+\log K+\log(\lambda/q_-).
\]
On the actual soft-active set, \(aU>2\lambda B\) and \(a\le\lambda\),
so the strict upper \(\xi\)-tail is greater than
\(\Delta=2q_-B=2(1+\sqrt n)\). The geometry lemma uses this same
noncyclic rank shift \(\Delta\). Under the original
\(q_-=3\lambda/4\), \(n\ge1\), its size strictly exceeds
\(D_0=1+\sqrt n+\log(4/3)\), while the available strict upper tail
is larger than \(\Delta\). These are the actual conditions of (4), including its strict
upper mass gap. This note uses that proved kernel contract, rather
than inferring it from a generic Schur bound.

Contracting the **old** clock gives
\[
 \widetilde\omega_y(u)=R_u^n
 \int_{[R_u,b]}\eta_y(u)\Omega_y(u,r)\chi_y(u,r)\ell(dr),
 \qquad0\le\widetilde\omega_y(u)\le1.
\]
Its support is contained in \(\mathcal A_y\). The original clock-integrated
source–receiver measure from (3) is exactly
\(g(y)\widetilde\omega_y(u)\xi_y(du)dy\).
Thus (4), with this positive contraction, bounds its incoming receiver
density relative to actual \(dw\) by
\[
 \kappa(w)\le\frac{q_w}{m_w}\int g(y)c_w(y)dy\le q_w.       \tag{5}
\]
This does not reuse an old row bound for an arrived density. It applies
the column domination (4) once to the original labelled measure (3).

## 2. Full marked resampling and its exact new-source marginal

Use the original source posterior
\[
 \pi_w(dz)=f(z)c_w(z)dz/m_w.
\]
The full joint measure is
\[
 d\Xi(y,u,r,w,z)=dF(y,u,r)P_y(u,dw)\pi_w(dz).               \tag{6}
\]
Both kernels are probabilities on the contributing domain, so
\(|\Xi|=G_{\rm late}\). All original clock atoms and original labels
\(y,u,r\) remain in (6). In particular \(z\) is not substituted for \(y\)
inside \(\eta,\Omega,J_y(r)\), or any old mask.

Define the original weighted terminal capture field
\[
 D(z)=\int_E q_w\,d\rho_z(w)
     =\int_E\frac{c_w(z)}{R_w^n}dw.
\]
The exact \(z\)-marginal of (6) is
\[
 f(z)\mathcal L(z)dz,\quad
 \mathcal L(z)=\int_E\frac{c_w(z)}{m_w}\kappa(w)dw,\quad
 \int f\mathcal L=G_{\rm late}.                           \tag{7}
\]
Equation (5) gives the useful pointwise estimate
\[
 0\le\mathcal L(z)\le D(z).                               \tag{8}
\]
This is the capacity delivered by the R350 rank kernel. It does not
claim that full \(f\,dz\) is an invariant measure of the marked flow.

## 3. Exact split, moment input and dimension factors

For arbitrary \(s,T>0\) set
\[
 \begin{aligned}
 G_{\rm low}&=\int_{\{D(z)\le s\}} f(z)\mathcal L(z)dz,\\
 G_{\rm clip}&=\int_{\{D(z)>s\}}\min(f(z),T)\mathcal L(z)dz,\\
 \mathcal R_{s,T}&=\int_{\{D(z)>s\}}(f(z)-T)_+\mathcal L(z)dz .
 \end{aligned}
\]
Then exactly
\[
 G_{\rm late}=G_{\rm low}+G_{\rm clip}+\mathcal R_{s,T}.    \tag{9}
\]
Equivalently these are the weights
\(1_{\{D(z)\le s\}}\),
\(1_{\{D(z)>s\}}\min(1,T/f(z))\), and
\(1_{\{D(z)>s\}}(1-T/f(z))_+\) on (6).
Any zero convention on \(f(z)=0\) is harmless since it has no joint mass.

The first payment is
\[
 G_{\rm low}\le s\int_{\{D(z)\le s\}}f(z)dz\le sW.         \tag{10}
\]
The source price is full \(W\), not \(W_{\rm ex}\): the new posterior
uses full \(f\).

For the second payment use the same audited fixed-exponent maximal
theorem as R344. If
\(T_R\phi(w)=R_w^{-n}\int_{Q_w}\phi\), then
\(\|T_R\|_{4/3\to4/3}\le C\), hence its adjoint has \(L^4\) norm at most
\(C\). Here \(D=T_R^*1_E\), rather than \(J=T_R^*(1_E/q)\). Therefore
\[
 \int D(z)^4dz\le C^4|E|\le C^4X_q/q_-,
 \qquad X_q=\int_Eq_wdw.                                 \tag{11}
\]
This is on the same actual receiver set and scale field. In particular
the power here is \(q_-^{-1}\), not the \(q_-^{-5}\) for the old \(J^4\)
moment. No source density cap is assumed.

Using \(D\le D^4/s^3\) on \(D>s\) and (8),
\[
 G_{\rm clip}\le T\int_{\{D>s\}}D
              \le\frac{TC^4}{q_-s^3}X_q.                 \tag{12}
\]
Taking \(T=\delta q_-s^3/C^4\) proves (1)–(2).
The unknown constant \(C\) is fixed and independent of dimension; its
appearance in the chosen truncation level is retained explicitly.

## 4. Exact residual, source consistency and ledger

The unpaid term is exactly (6) multiplied by
\[
 1_{\{D(z)>s\}}(1-T/f(z))_+.                              \tag{13}
\]
It retains the original excess source \(g(y)\), the original
\(\eta_y(u)\Omega_y(u,r)\), full \(J_y(r)\), the original late gate,
and a genuinely mass-separated upper witness \(w\). The added high
capture and excess conditions are on the **new** source \(z\).
No mass, \(q\), receiver set, or scale is recomputed after either source
factor is split.

The old source has \(J_b(y)>h\), hence \(D(y)\ge q_-h\).
A new source \(z\) can have \(D(z)\le s\). Thus (10) pays a different
marked portion unavailable from the old high-past gate alone; it does
not assert a uniform positive fraction of such sources for every input.

The source exit estimate \(\pi_w(Q_u)=I_{uw}/m_w<1/K\) remains true.
It is not needed for (10)–(12), and does not imply independence between
exit and the new-source gates. In particular (13) is not an original
\(G_{\rm late}\) with source \((f-T)_+\), and the rank-kernel column
contract (4) cannot be iterated on its arrived density without a new
proof retaining that density.

For ledger use, substitute (9) into the existing R348 inequality at
its original \(G_{\rm late}\) entry, then apply (10),(12). Add only the
single new receiver fee \(\delta X_q\) and source fee \(sW\). Do not add
another copy of the R344 original-source clipping, R347 Top-hit or R348
soft payment. All original exterior multipliers act on these new fees.
The general bound for (13) remains unproved.

## 5. Independent uniform-route fallback

The source-splitting argument does not require the rank construction
as a logical matter. With the old normalized upper kernel instead,
R347 gives \(\kappa(w)\le\lambda L_\varepsilon\), and therefore
\(\mathcal L(z)\le\lambda L_\varepsilon J_b(z)\).
The audited old moment is
\(\int J_b^4\le C^4X_q/q_-^5\). The same exact marked split, now at
\(J_b(z)=s_J\), yields
\[
 G_{\rm late}\le\mathcal R^{\rm uniform}_{s_J,T_J}
       +\delta X_q+\lambda L_\varepsilon s_JW,\qquad
 T_J=\frac{\delta q_-^5s_J^3}
           {\lambda L_\varepsilon C^4}.
\]
Taking \(s_J=(1+\sqrt n)/q_-\) is still root-order in \(W\).
This is an independent fallback with its own routed residual, not a
second charge and not an identification of the two residuals. The main
theorem (1) uses only the stronger rank version.

## 6. Executed exact checks

The embedded code was actually run: 108 exact substitutions verify the
strong \(q_-^{-1}\) formula, and 324 verify the independent fallback's
\(q_-^{-5}\) formula. The supplied positive numbers for \(C^4\) are
formal algebra tests, not asserted analytic constants.

The positive-volume R346 fixture verifies the actual source/receiver
masses, old clock contraction, and marked new-source split. Its late
traffic is \(1/2800\); new low-capture traffic is \(3/28000\), clipped
new-source traffic is \(1/14000\), and the residual is \(1/5600\).
The diagnostic route uses its only upper witness and satisfies the
incoming bound \(\kappa\le q_w=1\). It is not a test of the general rank
construction, which is checked in the geometry work. This fixture omits
the outside gate and uses diagnostic \(K,h,\tau,s,T\), not the original
root parameters. It does not certify the original root residual.

~~~python
from fractions import Fraction as F
from itertools import product
count=0
for lam,L,C4,delta,k in product(
    (F(1),F(2),F(5,3)),(F(1),F(2),F(5)),
    (F(1),F(16),F(81)),(F(1,100),F(1,10),F(1,4)),(1,2,4,8)):
    q=3*lam/4
    s=F(1+k)/q
    threshold=delta*q**5*s**3/(lam*L*C4)
    assert lam*L*threshold*C4/(q**5*s**3)==delta
    assert threshold==delta*q*q*F(1+k)**3/(lam*L*C4)
    assert lam*L*s==(lam/q)*L*(1+k)
    count+=1
assert count==324
strong_count=0
for q,C4,delta,k in product(
    (F(3,4),F(3,2),F(5,4)),(F(1),F(16),F(81)),
    (F(1,100),F(1,10),F(1,4)),(1,2,4,8)):
    s=F(1+k)
    threshold=delta*q*s**3/C4
    assert threshold*C4/(q*s**3)==delta
    strong_count+=1
assert strong_count==108

source=[(-F(1,100),F(1,100),F(50)),
        (F(59,100),F(61,100),F(20)),
        (F(104,100),F(106,100),F(30))]
receivers=[(-F(12,100),-F(8,100)),
           (F(18,100),F(22,100)),(F(38,100),F(42,100))]
R=[F(1),F(7,5),F(2)]
capture=[[1,0,0],[1,1,0],[1,1,1]]
mass=[(b-a)*d for a,b,d in source]
vol=[b-a for a,b in receivers]
for u,(left,right) in enumerate(receivers):
 for z,(lo,hi,dens) in enumerate(source):
  if capture[u][z]:
   assert right-R[u]/2<=lo and hi<=left+R[u]/2
  else:
   assert hi<=left-R[u]/2 or lo>=right+R[u]/2
m=[sum(mass[z]*capture[u][z] for z in range(3)) for u in range(3)]
assert m==R and all(v==F(1,25) for v in vol)
rho=[[capture[u][z]*vol[u]/m[u] for u in range(3)] for z in range(3)]
J=[sum(row) for row in rho]
K=F(11,8)
U=sum(rho[0][w] for w in range(3) if m[w]>K*m[1])
Jbefore=rho[0][0]+rho[0][1]
D=(1-m[0]/m[1])*rho[0][0]
Obefore=D/Jbefore
Oterminal=D/J[0]
assert Obefore==F(1,6) and Oterminal==F(4,31)
fullclock=Obefore*(1/R[1]-1/R[2])+Oterminal/R[2]
a=R[1]*fullclock
tau=a*U/2
eta=1-tau/(a*U)
assert eta==F(1,2)
assert U>J[0]/10 and rho[0][0]>F(1,100)
# Diagnostic arrival cap 1/100 excludes the terminal atom but no r<2.
assert U==F(1,50)>F(1,100)
lateclock=Obefore*(1/R[1]-1/R[2])
old_excess_mass=(source[0][1]-source[0][0])*(source[0][2]-25)
G=old_excess_mass*vol[1]*eta*lateclock
assert G==F(1,2800)
posterior=[mass[z]/m[2] for z in range(3)]
s=F(3,100);T=F(10)
low=sum(G*posterior[z] for z in range(3) if J[z]<=s)
clip=sum(G*posterior[z]*min(F(1),T/source[z][2])
         for z in range(3) if J[z]>s)
res=sum(G*posterior[z]*max(F(0),1-T/source[z][2])
        for z in range(3) if J[z]>s)
assert low==F(3,28000) and clip==F(1,14000) and res==F(1,5600)
assert low+clip+res==G
kappa=G/vol[2]
Lsource=kappa*vol[2]/m[2]
assert kappa<=1
assert sum(mass)*Lsource==G
assert all(Lsource<=J[z] for z in range(3))
assert sum(mass[z]*Lsource for z in range(3) if J[z]<=s)==low
assert low<=kappa*s*sum(mass)
print("PASS",count,"backup and",strong_count,
      "strong parameter identities; real marked split",G,low,clip,res)
~~~

Only this note was authored. The new proved payment is (1), using the
R350 rank-kernel lemma, with the explicit marked residual (13).
The full general root goal remains open.
