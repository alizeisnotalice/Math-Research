from fractions import Fraction as F
from itertools import product
count=0
for lam,L,C4,delta,k in product(
    (F(1),F(2),F(5,3)),(F(1),F(2),F(5)),
    (F(1),F(16),F(81)),(F(1,100),F(1,10),F(1,4)),(1,2,4,8)):
    q=3*lam/4
    s=F(1+k)/q
    threshold=delta*q**5*s**3/(lam*L*C4)
    assert lam*L*threshold*C4/(q**5*s**3)==delta
    assert threshold==delta*q*q*F(1+k)**3/(lam*L*C4)
    assert lam*L*s==(lam/q)*L*(1+k)
    count+=1
assert count==324
strong_count=0
for q,C4,delta,k in product(
    (F(3,4),F(3,2),F(5,4)),(F(1),F(16),F(81)),
    (F(1,100),F(1,10),F(1,4)),(1,2,4,8)):
    s=F(1+k)
    threshold=delta*q*s**3/C4
    assert threshold*C4/(q*s**3)==delta
    strong_count+=1
assert strong_count==108

source=[(-F(1,100),F(1,100),F(50)),
        (F(59,100),F(61,100),F(20)),
        (F(104,100),F(106,100),F(30))]
receivers=[(-F(12,100),-F(8,100)),
           (F(18,100),F(22,100)),(F(38,100),F(42,100))]
R=[F(1),F(7,5),F(2)]
capture=[[1,0,0],[1,1,0],[1,1,1]]
mass=[(b-a)*d for a,b,d in source]
vol=[b-a for a,b in receivers]
for u,(left,right) in enumerate(receivers):
 for z,(lo,hi,dens) in enumerate(source):
  if capture[u][z]:
   assert right-R[u]/2<=lo and hi<=left+R[u]/2
  else:
   assert hi<=left-R[u]/2 or lo>=right+R[u]/2
m=[sum(mass[z]*capture[u][z] for z in range(3)) for u in range(3)]
assert m==R and all(v==F(1,25) for v in vol)
rho=[[capture[u][z]*vol[u]/m[u] for u in range(3)] for z in range(3)]
J=[sum(row) for row in rho]
K=F(11,8)
U=sum(rho[0][w] for w in range(3) if m[w]>K*m[1])
Jbefore=rho[0][0]+rho[0][1]
D=(1-m[0]/m[1])*rho[0][0]
Obefore=D/Jbefore
Oterminal=D/J[0]
assert Obefore==F(1,6) and Oterminal==F(4,31)
fullclock=Obefore*(1/R[1]-1/R[2])+Oterminal/R[2]
a=R[1]*fullclock
tau=a*U/2
eta=1-tau/(a*U)
assert eta==F(1,2)
assert U>J[0]/10 and rho[0][0]>F(1,100)
# Diagnostic arrival cap 1/100 excludes the terminal atom but no r<2.
assert U==F(1,50)>F(1,100)
lateclock=Obefore*(1/R[1]-1/R[2])
old_excess_mass=(source[0][1]-source[0][0])*(source[0][2]-25)
G=old_excess_mass*vol[1]*eta*lateclock
assert G==F(1,2800)
posterior=[mass[z]/m[2] for z in range(3)]
s=F(3,100);T=F(10)
low=sum(G*posterior[z] for z in range(3) if J[z]<=s)
clip=sum(G*posterior[z]*min(F(1),T/source[z][2])
         for z in range(3) if J[z]>s)
res=sum(G*posterior[z]*max(F(0),1-T/source[z][2])
        for z in range(3) if J[z]>s)
assert low==F(3,28000) and clip==F(1,14000) and res==F(1,5600)
assert low+clip+res==G
kappa=G/vol[2]
Lsource=kappa*vol[2]/m[2]
assert kappa<=1
assert sum(mass)*Lsource==G
assert all(Lsource<=J[z] for z in range(3))
assert sum(mass[z]*Lsource for z in range(3) if J[z]<=s)==low
assert low<=kappa*s*sum(mass)
print("PASS",count,"backup and",strong_count,
      "strong parameter identities; real marked split",G,low,clip,res)
