"""Integer lower bound for sectional cube capture. Run with python3 masks.py."""
from itertools import product
from random import Random
rng=Random(715)
for m in (0,1,2,4,8,12,16):
    # Grid [-16,16] has 32 equally weighted midpoint cells. For each donor a
    # length-64 interval contains zero, so at least 16 cells hit on each axis.
    rows=[([rng.randint(-32,32) for _ in range(m)],rng.randrange(1,101)) for _ in range(40)]
    rows.extend([([(-1)**(a+i)*32 for a in range(m)],1) for i in range(2)])
    exact=sum(w*__import__('math').prod(sum(abs(v-2*c)<=64 for v in range(-31,32,2)) for c in center) for center,w in rows)
    bound=16**m*sum(w for _,w in rows)
    assert exact>=bound
    if m<=2:
        assert exact==sum(w for v in product(range(-31,32,2),repeat=m) for cs,w in rows if all(abs(x-2*c)<=64 for x,c in zip(v,cs)))
    assert sum(abs(v-64)<=64 for v in range(-31,32,2))**m==16**m
    print(m,len(rows),exact,bound)
