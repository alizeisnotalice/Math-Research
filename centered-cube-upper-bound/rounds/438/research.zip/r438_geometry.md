# R438 bounded checkpoint: a directed spatial price with affordable matching cost

**Status.** The candidate below has a proved native geometric matching-cost bound and a proved upper bound on its sourcewise strength. The source comparison needed to pay the integrated cut is not proved. It therefore makes **no change to the original R433 ledger** and is not a new payment of the original flow. No further counterexample search is included.

## 1. Actual field and the single candidate

Let E be the actual measurable Lebesgue receiver set of finite measure. Its cubes Q_A have center A and side R_A in [a,b], b/a≤2. Write c_A=1_{Q_A}, m_A=∫f c_A=q_A R_A^n, q≤q_A≤λ, r=λ/q, W=∫f, and

\[
 J(y)=\int_E \frac{c_A(y)}{m_A}\,dA,
 \qquad A_n=1+n\log(b/a).
\]

We use the proved native bounds J≤A_n/q and ∫fJ=|E|. All centers and cubes below belong to this field. In particular c_u(A) is a genuine center-in-cube test, distinct from common-source capture.

For t>0 set

\[
 h_t(v)=q\,1_{m_v<t}\int_{m_u>t}\frac{c_u(v)}{m_u^2}\,du
 -q\,1_{m_v>t}m_v^{-3}\int_{m_A<t}m_Ac_A(v)\,dA.
 \tag{1}
\]

For m_A<m_u let k(A,u)=m_A/m_u². The source potential V_t(y)=∫h_t(v)c_v(y)dv is

\[
 V_t(y)=q\iint_{m_A<t<m_u}k(A,u)
 \left[\frac{c_u(A)c_A(y)}{m_A}
       -\frac{c_A(u)c_u(y)}{m_u}\right]dAdu.
 \tag{2}
\]

Full matching, without any source density bound, gives

\[
 \int fV_t=\int_E h_t(v)m_v\,dv
 =q\iint_{m_A<t<m_u}k(A,u)[c_u(A)-c_A(u)]\,dAdu.
 \tag{3}
\]

This is not generally a nonpositive price. The next section pays its positive matching cost explicitly.

## 2. Integrated matching cost: a native geometric bound

Let Δ=log(m_u/m_A)>0. Integrating the two nonnegative components of (1) against dt/t gives

\[
 \bar h_+(A)=q\int_{m_u>m_A}\frac{\Delta c_u(A)}{m_u^2}\,du,
 \qquad
 \bar h_-(u)=\frac q{m_u^3}\int_{m_A<m_u}m_A\Delta c_A(u)\,dA,
 \tag{4}
\]

and \bar h=\bar h_+−\bar h_-. Mass atoms require no correction: the t-integral of 1_{m_A<t<m_u} is exactly Δ, including when either endpoint is an atom.

The respective matching costs are

\[
 P_+=q\iint_{m_A<m_u}\frac{\Delta e^{-\Delta}}{m_u}c_u(A)\,dAdu,
 \quad
 P_-=q\iint_{m_A<m_u}\frac{\Delta e^{-\Delta}}{m_u}c_A(u)\,dAdu.
\]

Since Δe^{-Δ}≤1/e and actual centers A captured by Q_u have Lebesgue volume at most R_u^n,

\[
 P_+\le\frac q e\int_E\frac{R_u^n}{m_u}\,du
 =\frac q e\int_E\frac{du}{q_u}\le\frac{|E|}{e}.
 \tag{5}
\]

For the other direction use m_u>m_A, then integrate the centers u in the actual cube Q_A:

\[
 P_-\le\frac q e\int_E\frac{1}{m_A}
       \int_Ec_A(u)\,du\,dA
 \le\frac q e\int_E\frac{R_A^n}{m_A}\,dA
 \le\frac{|E|}{e}.
 \tag{6}
\]

Thus the signed potential \bar V(y)=∫\bar h(A)c_A(y)dA satisfies

\[
 \boxed{\int f\bar V=P_+-P_-\le\frac{|E|}{e}
       \le\frac{A_n}{eq}W.}
 \tag{7}
\]

Moreover ∫|\bar h|m≤P_++P_-≤2|E|/e, and ∫f|\bar V|≤2|E|/e. These bounds justify the signed exchanges; all intermediate positive-component exchanges use Tonelli.

**Radius-order exception.** If m_u/m_A≥r, then R_u≥R_A, and c_A(u)≤c_u(A); hence the integrand in (3) is nonnegative there. For 1<m_u/m_A<r, side order can reverse and the defect can have either sign. Equations (5)–(7) do not require side order and keep this signed contribution. If r=1 there is no exception. No radius-interpolated or virtual receiver has been introduced.

## 3. The same price has only a proved upper strength bound

For every spatial x and M>0, the actual squared-mass tail obeys

\[
 \begin{aligned}
 \int_{m_u>M}\frac{c_u(x)}{m_u^2}\,du
 &=\int_M^\infty 2s^{-3}
   |\{u\in E:M<m_u\le s,\ x\in Q_u\}|\,ds\\
 &\le\int_M^\infty 2s^{-3}\frac{s}{q}\,ds
 =\frac{2}{qM}.
 \end{aligned}
 \tag{8}
\]

Indeed m_u≤s implies R_u≤(s/q)^{1/n}; every center capturing x then lies in the cube about x of that side. This is a bound on **center volume**, not on source mass. The layer-cake identity is valid for arbitrary selected sides and mass atoms; it does not integrate the selector as an independent radius variable.

Using log(m_u/m_A)=∫_{m_A}^{m_u}dt/t and (8),

\[
 \bar h_+(A)
 =q\int_{m_A}^\infty\frac{dt}{t}
       \int_{m_u>t}\frac{c_u(A)}{m_u^2}\,du
 \le\frac{2}{m_A}.
\]

Consequently

\[
 \boxed{\bar V(y)\le2J(y).}
 \tag{9}
\]

This is an upper bound on the candidate's strength, not the lower comparison needed for a dual certificate. In particular (7) cannot be used to pay a source residual merely because its matching cost is affordable.

## 4. Exact remaining comparison; no claimed closure

At each cut let L_y(t)=∫c_A(y)1_{m_A<t}dA/m_A and H_y(t)=∫c_A(y)1_{m_A>t}dA/m_A. Put

\[
 G(y)=\int_0^\infty\frac{L_y(t)H_y(t)}{J(y)}\,\frac{dt}{t},
\]

with value zero when J=0. A sufficient use of this particular candidate would be a source comparison

\[
 G(y)\le B_n/q+\bar V(y)
 \quad (f\,dy\text{-almost everywhere}),
 \tag{10}
\]

with B_n=O_r(n\operatorname{polylog}(n+2)). Then (7) would yield ∫C(t)dt/t≤(B_n+A_n/e)W/q. An integrated comparison or a comparison retaining the original acceptance marks could be weaker and sufficient; (10) is **not asserted necessary** for the original target.

No such comparison has been obtained. The exact unresolved contribution for this candidate is ∫f(G−\bar V): the directed center-overlap price has controlled cost, but no proved domination of the long mass-span source load. Bound (9) does not provide that domination. Neither a reverse positive flow nor the full matching identity supplies a signed cancellation of this residual. The candidate is closed here without assigning any new credit to BH or the original marked flow.

## 5. Executed verification and scope

`/tmp/r438_geometry_check.py` was actually executed; stdout is `/tmp/r438_geometry.result.txt`:

```text
PASS 24 Fraction coefficient and matching-pairing identities.
Algebra only: no new native geometry/history model and no test of the missing source inequality.
```

These exact rational checks verify the coefficient normalization in (1)–(3), including all four directional center-indicator combinations. Equations (5)–(9) are analytic proofs. The checks do not certify (10), a new native historical flow instance, or a general root-scale budget. No additional finite fitting or counterexample scan was undertaken.
