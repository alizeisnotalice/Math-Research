from fractions import Fraction as F

def mass(x,R,bump):
    overlap=max(F(0),min(x+R/2,F(1))-max(x-R/2,F(0)))
    return R+bump*overlap

def int_min_mass(lo,hi,R,bump,ma):
    if hi<=lo:return F(0)
    knots=sorted({lo,hi,*[x for x in [-R/2,R/2,1-R/2,1+R/2] if lo<x<hi]})
    val=F(0)
    for l,h in zip(knots,knots[1:]):
        ml,mh=mass(l,R,bump),mass(h,R,bump)
        if ml==mh:val+=(h-l)*min(ma,ml);continue
        x=l+(ma-ml)*(h-l)/(mh-ml)
        split=[l,x,h] if l<x<h else [l,h]
        for a,b in zip(split,split[1:]):
            val+=(b-a)*(min(ma,mass(a,R,bump))+min(ma,mass(b,R,bump)))/2
    return val

# Full f = 1_[-4,4] + bump 1_[0,1]; actual disjoint positive center blocks.
blocks=[(F(-1),F(-1,2),F(1)),(F(-1,4),F(1,4),F(3,2)),(F(1,2),F(1),F(2))]
ct=0
for bump in [F(0),F(1,8),F(1,4)]:
    lam=1+bump
    for lo,hi,RA in blocks:
        A=(lo+hi)/2;ma=mass(A,RA,bump)
        assert 1<=ma/RA<=lam and 1>=3*lam/4
        row=weighted=F(0)
        for l,h,Ru in blocks:
            small=min(RA,Ru);left=max(l,A-small/2);right=min(h,A+small/2)
            if right<=left:continue
            row+=(right-left)/small
            weighted+=int_min_mass(left,right,Ru,bump,ma)/small
        # Exact weaker row test sufficient for these fixtures; theorem uses 1+log(RA/a).
        assert row<=1
        assert weighted<=lam*RA<=lam*ma
        ct+=1
        print(f'case {ct}: bump={bump}, parent_R={RA}, m={ma}, row={row}, weighted_row={weighted}, bound={lam*RA}')
print('PASS 9 native positive-Lebesgue center/full-source models, exact variable-mass integrals, stages 3/3/3.')
print('No original high-dimensional stage/clock/history claim; no global residual estimate inferred.')
