from fractions import Fraction as F
count=0
for low,high in [(F(1),F(2)),(F(1),F(4)),(F(3,2),F(7,3)),(F(5),F(11))]:
 k=low/high**2
 assert k/low==1/high**2; count+=1
 assert k/high==low/high**3; count+=1
 for big_captures_small,small_captures_big in [(0,0),(0,1),(1,0),(1,1)]:
  positive=big_captures_small*k/low
  negative=-small_captures_big*k/high
  assert low*positive+high*negative==k*(big_captures_small-small_captures_big); count+=1
print('PASS',count,'Fraction coefficient and matching-pairing identities.')
print('Algebra only: no new native geometry/history model and no test of the missing source inequality.')
