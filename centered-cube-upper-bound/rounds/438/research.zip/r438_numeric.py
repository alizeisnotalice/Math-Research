"""Exact Minkowski polynomial; 12 prescribed records and four crossover brackets.
No geometry samples, LPs or original-history certification.
"""
from fractions import Fraction as F
from math import comb,isqrt
from decimal import Decimal as D,localcontext,ROUND_FLOOR
from pathlib import Path
import json,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def V(n,a):
    term=total=F(1)
    for k in range(1,n+1):
        term*=F(n-k+1,k*k)*2*a;total+=term
    return total

def expb(x,N=256):
    term=total=F(1)
    for k in range(1,N+1):term*=F(x,k);total+=term
    first=term*F(x,N+1)
    return total,total+first/(1-F(x,N+2))
def dec(a):return D(a.numerator)/D(a.denominator)
def VD(n,a):
    term=total=D(1)
    for k in range(1,n+1):term*=D(n-k+1)*2*a/D(k*k);total+=term
    return total

# Coefficient verification by counting active exterior coordinate sets and signs.
# Independent direct polynomial vs recurrence for all small n up to 8.
for n in range(1,9):
    for a in [F(1,32),F(1,8),F(1,2)]:
        fac=1;direct=F(0)
        for k in range(n+1):
            if k:fac*=k
            direct+=F(comb(n,k),fac)*(2*a)**k
        assert direct==V(n,a)
print('PASS: independent coefficient-sum / recurrence checks, n=1..8 at three prescribed alpha.')
rows=[];roots=[]
with localcontext() as ctx:
    ctx.prec=100
    for n in [16,64,256,1024]:
        sn=isqrt(n);assert sn*sn==n
        elo,ehi=expb(sn)
        for a in [F(1,32),F(1,8),F(1,2)]:
            vv=V(n,a);lv=dec(vv).ln();envelope=2*(D(2*n)*dec(a)).sqrt()
            assert vv<elo or vv>ehi
            rows.append({'n':n,'alpha':str(a),'V_exact':str(vv),
              'logV_Decimal_diagnostic':str(lv),
              'log_exp_minus_sqrt_n_V_Decimal_diagnostic':str(lv-D(sn)),
              'exp_minus_sqrt_n_V_Decimal_diagnostic':str((lv-D(sn)).exp()),
              'envelope_log_upper_analytic_display':str(envelope),
              'below_exp_sqrt_n_exact':vv<elo})
            print('n',n,'alpha',a,'logV=',format(lv,'.12f'),
                  'e^-sqrt(n)V=',format((lv-D(sn)).exp(),'.12E'), 'below=',vv<elo)
        # Finite root is unique: all nonconstant polynomial coefficients positive.
        left,right=D(0),D(1)
        assert VD(n,left)<D(sn).exp()<VD(n,right)
        for _ in range(60):
            mid=(left+right)/2
            if VD(n,mid).ln()<sn:left=mid
            else:right=mid
        scale=10**14
        k=int((left*scale).to_integral_value(rounding=ROUND_FLOOR))
        al,ar=F(k,scale),F(k+1,scale)
        vl,vr=V(n,al),V(n,ar)
        assert vl<elo and vr>ehi
        roots.append({'n':n,'alpha_left_exact':str(al),'alpha_right_exact':str(ar),
           'left_V_below_exp_lower_exact':True,'right_V_above_exp_upper_exact':True,
           'width':str(ar-al),'method':'Decimal bisection discovery; final Fraction V and rational exp bounds certify bracket.'})
        print('root n',n,'strict rational bracket',al,ar)
report={'records':rows,'crossovers':roots,
        'precision':'100-digit Decimal diagnostics; Fraction V and final threshold comparisons exact',
        'scope':'Minkowski polynomial and finite highrank-distance factor only; no original flow/history or generic closure.'}
(ROOT/'r438_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 12 exact records and four strict crossover brackets; no additional scan.')
