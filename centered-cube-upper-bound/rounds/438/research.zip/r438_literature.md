# R438 文献核验：中心立方体重叠容量

**结论。** 第一篇已读原文 §2 定理及覆盖引理证明；第二篇仅核验原文首页定义与主结论，未读其证明。找到一个“增量质量相对扩张接收球”的覆盖重叠账，但不能把它迁移为 R438 所需的跨质量 cut / receiver-capacity 不等式。它没有给可用的、优于源端维数线性量级的跨质量机制；这只是本次有界检索结论，不意味着领域内不存在其他结果。

1. **E. M. Stein & J.-O. Strömberg, “Behavior of maximal functions in \(\mathbb R^n\) for large \(n\),” Arkiv för Matematik 21 (1983), 259–269.** [原文 PDF](https://archive.ymsc.tsinghua.edu.cn/pacm_download/116/7398-11512_2006_Article_BF02384314.pdf)。已读原文 §2 Theorem 1 及引理证明（PDF pp.260–263）。对有界、开、凸、对称的 \(B\subset\mathbb R^n\)，其平移膨胀平均算子满足
\[
\lambda\,|\{x:M_Bf(x)>\lambda\}|\le C n\log n\,\|f\|_1,
\]
常数与 \(B,n\) 无关。证明对有限个所选球 \(B_j\) 定义互不交增量 \(I_j=B_j\setminus\bigcup_{i<j}B_i\)，贪心筛选后得到覆盖/增量控制，并有
\[
\sum_j \frac{|I_j|}{|B_j^*|}\,\mathbf1_{B_j^*}(x)\le C n\log n,
\]
这里 \(B_j^*\) 半径为 \(nr_j\)。证明另在贪心中心测试中使用 \(B_j^{**}\)（半径 \((n+1)r_j\)），在未选球的几何转移中使用 \(B_j^{***}\)（半径 \((n+2)r_j\)）；这些不能混写成重叠结论的指示集。引理用逐层半径比 \((1+1/n)^k\) 和体积估计求和。这确实是空间接收容量：在**同一选定球族、以 Lebesgue 体积作分母、增量由既有覆盖差分定义**时，密度加权的扩张球占用有 \(O(n\log n)\) 上界。R438 的 \(g_t(y)=L H/J\) 则以 \(\rho_y\) 的质量阈值切成低/高两端，核含实际 \(c_A(y)c_u(y)/(m_Am_uJ(y))\)，要求控制跨质量乘积，且所有 \(m_A\) 落在 \([q_A R_A^n,\lambda R_A^n]\)。文中既没有该核的阈值分层，也没有匹配实际 \(m_A\) 的容量分母或 signed center price。因此这是可借鉴的证明形状，不是可代入的不等式；其维数代价仍是 \(n\log n\)，没有改善目标账本。

2. **A. S. Iakovlev & J.-O. Strömberg, “Lower bounds for the weak type (1,1) estimate for the maximal function associated to cubes in high dimensions,” Math. Res. Lett. 20 (2013), 907–918.** [原始出版页/PDF](https://intlpress.com/api/bgcloud-front/resource/pdf/volume/1806603729623216130-1806603729623216130-88dbe922fef07a892fbe2fa55c340767.pdf)，DOI [10.4310/MRL.2013.v20.n5.a7](https://doi.org/10.4310/MRL.2013.v20.n5.a7)。仅核原文首页定义和摘要主结论（PDF p.907；出版方全文下载在本次网页工具返回 403，故证明细节未核）。对 Lebesgue \(\mathbb R^d\) 上轴平行中心立方体，若 \(A_d\) 是最佳弱-(1,1) 常数，则作者证明存在绝对 \(c>0\) 使 \(A_d\ge c d^{1/4}\)。该结论是对任意 \(L^1\) 弱型常数的下界，不是上界或 overlap 容量；不支持对 R438 作压缩。原文首页摘要/定理是本项的阅读范围，未据其未读取证明声称更细机制。

**适用判断。** Stein–Strömberg 给出的只是当前核验到的经典上界级别 \(O(n\log n)\)（一般对称凸体），而立方体最佳弱型常数至少 \(\Omega(n^{1/4})\)。两项是不同方向的全局算子估计，不能替代 R438 中逐质量尺度的 \(C(t)\) 或原 \(\Pi_{433}\) 接受流估计。要迁移第一篇，至少还须证明：在由真实几何产生的球族上，阈值核能被其增量密度项逐点或整体支配；Lebesgue 扩张容量可替换为带实际 \(m_A,c_A\) 的容量且仍有受控代价；贪心选择/增量不会丢失 R433 原始路径与门控。当前未验证这些条件，故无已核实的全局桥接式。
