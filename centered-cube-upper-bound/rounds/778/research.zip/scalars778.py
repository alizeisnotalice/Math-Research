"""Exact checks for the weak sum, swept boxes and the large-dimension budget."""
from fractions import Fraction
from itertools import product
from math import comb
import json
import sys

import flint
from flint import arb, ctx


def cross(origin, p, q):
    return (p[0]-origin[0])*(q[1]-origin[1]) - (p[1]-origin[1])*(q[0]-origin[0])


def polygon_area(points):
    def chain(ordered):
        part = []
        for p in ordered:
            while len(part) >= 2 and cross(part[-2], part[-1], p) <= 0:
                part.pop()
            part.append(p)
        return part
    ordered = sorted(set(points))
    hull = chain(ordered)[:-1] + chain(reversed(ordered))[:-1]
    return abs(sum(p[0]*q[1]-p[1]*q[0] for p, q in zip(hull,hull[1:]+hull[:1])))/2


def square_tubes():
    widths = [(1,1), (1,6), (6,1), (6,6)]
    candidates = [(0,0), (2,0), (2,-1), (3,3), (Fraction(-3,2),Fraction(1,4))]
    examples = []
    for (wx,wy), (dx,dy) in product(widths, candidates):
        w, h = Fraction(wx), Fraction(wy)
        vertices = [(sx*w+t*dx,sy*h+t*dy) for sx,sy,t in product((-1,1), repeat=3)]
        measured = polygon_area(vertices)
        predicted = 4*w*h*(1+abs(dx)/w+abs(dy)/h)
        assert measured == predicted
        examples.append((wx,wy,dx,dy,measured))
    return examples


def weak_sums():
    out = []
    for n in (4,16,64,256):
        column = [Fraction(1,j) for j in range(1,n+1)]
        column_weak = max(Fraction(i,n)*x for i,x in enumerate(column,1))
        row_sums = [sum(column[(i+j)%n] for j in range(n)) for i in range(n)]
        harmonic = sum(column)
        assert column_weak == Fraction(1,n) and set(row_sums) == {harmonic}
        out.append({"columns":n,"sum_individual_weak":n*column_weak,"joint_weak":harmonic})
    return out


def reference_coordinate():
    checks = 0
    for n in (2,8,32,128):
        a = 32*n
        for ratio in (Fraction(1,2),Fraction(5,8),Fraction(3,4),Fraction(1)):
            height = ratio*(1+Fraction(1,a))
            level = 1-ratio/a
            for dx in (Fraction(i,8) for i in range(-48,49)):
                length = max(0,min(height,dx+level)-max(-height,dx-level))
                p = 1-length/(2*height)
                assert 0<=p<=1 and p<=2*min(1,abs(dx))+Fraction(2,a)
                checks += 1
    return checks


def stratified_source():
    # One source point in each stratum of the lower model. The nonnegative
    # continuous background can only add to the separated-quarter event.
    rows = []
    for K in (48,96,192):
        assert K%4==0
        atom_weight=Fraction(K,K+20)
        one=atom_weight**2/8
        for n in (64,256,1024):
            mean=n*one
            threshold=max(1,mean.numerator//(2*mean.denominator))
            low=sum(Fraction(comb(n,j))*one**j*(1-one)**(n-j) for j in range(threshold))
            success=1-low
            den=10**12
            out=success*den
            below=out.numerator//out.denominator
            above=-((-out.numerator)//out.denominator)
            assert Fraction(below,den)<=success<=Fraction(above,den)
            assert success>Fraction(9,10)
            rows.append({"strata":K,"n":n,"one_axis_lower_bound":one,
                         "at_least_separated_axes":threshold,
                         "lower_probability_bracket":[Fraction(below,den),Fraction(above,den)]})
    return rows


def unique_integer(ball):
    i = ball.unique_fmpz()
    assert i is not None
    return int(i)


def dimension_bounds():
    ctx.prec = 256
    out = []
    for power in (20,28,40,64,80):
        n = 2**power
        ell = arb(n+2).log()
        r = unique_integer((arb(n).sqrt()*ell**2).ceil())
        d = r//65536
        k = unique_integer((arb(r)/(65536*ell)).floor())
        upper_log_F = arb(r)/65536+(d+2*k)*arb(6).log()+2*k*arb(n+1).log()
        assert upper_log_F < arb(r)/8192
        assert arb(r)/2048-upper_log_F > arb(r)/4096
        shape_gain = arb(k)/100
        out.append({"dimension_power_of_two":power, "r":r,"d":d,"k":k,
                    "upper_log_F_over_r":(upper_log_F/r).str(14),
                    "log_endpoint_reference_gain":str(Fraction(k,100)),
                    "gain_decimal":shape_gain.exp().str(12) if k<10000 else "recorded on the logarithmic scale"})
    return out


if __name__ == "__main__":
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint.__version__,
                      "prec_bits":256,"weak_sum":weak_sums(),"swept_area":square_tubes(),
                      "coordinate_inequalities":reference_coordinate(),"lower_model_separation":stratified_source(),
                      "large_dimensions":dimension_bounds()},sort_keys=True,indent=2,default=str))
