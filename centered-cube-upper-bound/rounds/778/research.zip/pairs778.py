#!/usr/bin/env python3
"""R778 exact marked two-price change, owner probes and receiving-cube products."""

from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(xs):
    return sum(xs,F(0))


def prod(xs):
    out=F(1)
    for x in xs:
        out*=x
    return out


def size(q):
    return max(F(0),q[1]-q[0])


def inter(*qs):
    return max(q[0] for q in qs),min(q[1] for q in qs)


def meet(*boxes):
    return tuple(inter(*qs) for qs in zip(*boxes))


def contains(outer,inner):
    return all(a<=c<=d<=b for (a,b),(c,d) in zip(outer,inner))


def q(c,r):
    return tuple((x-r,x+r) for x in c)


def leb(box):
    return prod(map(size,box))


def displacement(a,b):
    left,right=b[0]-a[1],b[1]-a[0]
    lo=F(0) if left<=0<=right else min(abs(left),abs(right))
    return lo,max(abs(left),abs(right))


def all_centers_cover(box,r):
    return tuple((b-r,a+r) for a,b in box)


def midpoint(box):
    return tuple((a+b)/2 for a,b in box)


def interval_text(x, digits=13):
    if not x:
        return ["0","0"]
    value=F(x)
    exponent=0
    while value<1:
        value*=10
        exponent-=1
    while value>=10:
        value/=10
        exponent+=1
    scale=10**digits
    a,r=divmod(value.numerator*scale,value.denominator)

    def render(k):
        return f"{k//scale}.{k%scale:0{digits}d}e{exponent:+d}"

    return [render(a),render(a+bool(r))]


def certify(n):
    a=32*n
    h=1+F(1,a)
    R_s,R_b=F(1),F(2)
    tube_r=h*R_s
    c=[(s,)*n for s in map(F,("0","1/2","5/4","-3/4"))]
    s=[F(1),2-F(1,4*n),F(5,4),2-F(1,8*n)]
    A=[q(ci,r) for ci,r in zip(c,s)]
    E=[q(ci,r/a) for ci,r in zip(c,s)]
    C=list(A)
    C[1]=tuple((lo,hi-F(1,8*n)) for lo,hi in C[1])
    period=F(1,4*n)

    def mu1(lo,hi):
        lo,hi=inter((lo,hi),(F(-6),F(6)))
        if lo>=hi:
            return F(0)

        def Fcum(x):
            j=x//period
            rem=x-j*period
            return j*period+rem/2+max(F(0),rem-period/2)

        return Fcum(hi)-Fcum(lo)

    def mu(box):
        return prod(mu1(lo,hi) for lo,hi in box)

    m=list(map(mu,A))
    assert m==list(map(leb,A)) and all(m)
    assert all(contains(A[i],owner) for i,owner in enumerate(E))
    assert all(not leb(meet(a1,b1)) for i,a1 in enumerate(E) for b1 in E[:i])
    assert all(F(1)<=radius<2 for radius in s)
    assert s[0]==R_s==1 and m[0]==(2*R_s)**n  # The declared diagnostic singleton includes equality.
    assert (2*R_b)**n/2<=m[1]<(2*R_b)**n and s[1]<R_b
    actual_volume_ratio=m[1]/m[0]
    assert actual_volume_ratio==(s[1]/s[0])**n and 1<actual_volume_ratio<2**n
    I=list(map(leb,E))
    labels=range(4)
    marks={(i,j):mu(meet(C[i],C[j])) for i,j in product(labels,repeat=2)}
    K={(i,j):marks[i,j]/(m[i]*m[j]) if i!=j else F(0) for i,j in product(labels,repeat=2)}
    d=ss(K[1,j]*I[j] for j in labels)
    assert d==ss(marks[1,j]*I[j]/(m[1]*m[j]) for j in labels if j!=1)>0
    lower=[j for j in labels if m[j]<m[1] and K[1,j]]
    assert lower==[0,2] and K[1,3]>0
    p_low=ss(K[1,j]*I[j] for j in lower)/d
    assert 0<p_low<1
    initial_edge=I[0]*I[1]*K[0,1]
    coeff={j:I[j]/m[j] for j in lower}

    def exact_price_laws(left,right):
        source=initial_edge*mu(meet(left,C[0],C[1]))/marks[0,1]
        # Original paths with independent true intersection prices and the full d(v).
        original=ss(source*I[g]*K[1,g]/d*mu(meet(right,C[g],C[1]))/marks[1,g]
                    for g in lower)

        # Disjoint price memberships under rho_v; summation has no old endpoint fields.
        within=meet(right,C[1],A[1])
        shared=mu(meet(within,C[0],C[2]))
        just_u=mu(meet(within,C[0]))-shared
        just_g=mu(meet(within,C[2]))-shared
        neither=mu(within)-shared-just_u-just_g
        assert min(just_u,just_g,shared,neither)>=0
        integral=(coeff[0]*just_u+coeff[2]*just_g+(coeff[0]+coeff[2])*shared)/(d*m[1])
        assert original==source*integral

        by_cells=None
        if n==2:
            cuts=[sorted({x for obj in [within,C[0],C[1],C[2],A[1]] for x in obj[j]})
                  for j in range(2)]
            by_cells=F(0)
            for cell in product(*(list(zip(x,x[1:])) for x in cuts)):
                if not contains(within,cell):
                    continue
                t=ss(coeff[g] for g in lower if contains(C[g],cell))
                by_cells+=mu(cell)*t/(d*m[1])
            assert source*by_cells==original
        omit_t=source*mu(within)/m[1]
        omit_t_and_mark=source*mu(meet(right,A[1]))/m[1]
        return original,omit_t,omit_t_and_mark,(just_u,just_g,shared,neither)

    whole,wrong,wrong2,_=exact_price_laws(A[0],A[1])
    assert whole==initial_edge*p_low and 0<whole<wrong2
    assert wrong!=whole
    eps=F(1,128*n)
    near,far=F(1,4),F(17,8)
    Y=q((near,)*n,eps)
    assert contains(meet(C[0],C[1]),Y)
    assert contains(all_centers_cover(Y,tube_r),E[0])
    assert contains(all_centers_cover(Y,h*R_b),E[1])

    threshold=s[1]-R_s/a
    s_star=s[1]
    kappa=F(1,2)
    dcases=[]
    passing=failed=F(0)
    for k in sorted({0,1,2,n//2,n}):
        Z=q((far,)*k+(near,)*(n-k),eps)
        assert contains(meet(C[1],C[2]),Z)
        assert contains(all_centers_cover(Z,h*R_b),E[1])
        actual,ignore_t,ignore_t_and_C,splits=exact_price_laws(Y,Z)
        assert actual>0
        y,z=midpoint(Y),midpoint(Z)
        reference_axis=[]; reference_bounds=[]
        probe_axis=[]; gate=[]
        central_lens=[]
        for dim,(y0,z0) in enumerate(zip(y,z)):
            dist_min,dist_max=displacement(Y[dim],Z[dim])
            f=lambda shift:1-size(inter((-tube_r,tube_r),(shift-threshold,shift+threshold)))/(2*tube_r)
            reference_axis.append(f(abs(z0-y0)))
            reference_bounds.append((f(dist_min),f(dist_max)))
            assert 0<=reference_bounds[-1][0]<=reference_axis[-1]<=reference_bounds[-1][1]<=1
            E_slice=E[0][dim]
            probe=1-size(inter(E_slice,(z0-threshold,z0+threshold)))/size(E_slice)
            probe_axis.append(probe)
            near_c,far_c=displacement((c[0][dim],c[0][dim]),Z[dim])
            if near_c>s_star:
                gate.append(dim)
                assert displacement(E_slice,Z[dim])[0]>threshold
            else:
                assert far_c<=s_star and displacement(E_slice,Z[dim])[1]<=threshold
            central_lens.append((max(F(0),1-dist_max/(2*h*R_b)),max(F(0),1-dist_min/(2*h*R_b))))
        assert gate==list(range(k)) and probe_axis==[F(1)]*k+[F(0)]*(n-k)
        normalized_lens=leb(meet(q(y,h*R_b),q(z,h*R_b)))/(2*h*R_b)**n
        assert normalized_lens==prod(1-abs(a0-b0)/(2*h*R_b) for a0,b0 in zip(y,z))
        L,U=prod(t[0] for t in central_lens),prod(t[1] for t in central_lens)
        assert L<=normalized_lens<=U
        if L>=kappa:
            gate_result="entire real product price box passes"
            passing+=actual
        elif U<kappa:
            gate_result="entire real product price box fails"
            failed+=actual
        else:
            raise AssertionError("ambiguous chosen price interval")
        prefix_prob=prod(reference_axis[d] for d in gate)
        assert all(reference_axis[d]==0 for d in range(k,n))
        assert all(0<reference_axis[d]<1 for d in gate)
        example_axis=0 if k else n-1
        dcases.append({"different_coordinate_count":k,
                       "positive_old_two_price_mass":interval_text(actual),
                       "wrong_drop_t_over_actual_mass":interval_text(ignore_t/actual),
                       "real_owner_outside_coordinate_count":k,
                       "one_chosen_coordinate":{"reference_probability_at_centers":reference_axis[example_axis],
                                                "reference_probability_over_price_box":reference_bounds[example_axis],
                                                "actual_Eu_outside_probability":probe_axis[example_axis]},
                       "reference_probability_all_k_displaced_axes_outside":interval_text(prefix_prob),
                       "lens_fraction_at_centers":interval_text(normalized_lens),
                       "lens_fraction_certified_range":[interval_text(L)[0],interval_text(U)[1]],
                       "gate":gate_result})
    assert 0<passing and 0<failed and passing+failed<=whole
    return {"n":n,"a":a,"period_in_each_coordinate":period,"owner_and_parent_centers_on_diagonal":[x[0] for x in c],
            "true_parent_radii":s,"m_equals_the_actual_parent_volume":True,
            "actual_C_v_upper_end_each_axis":C[1][0][1],"Rs":R_s,"Rb":R_b,
            "physical_radius_octave":"[1,2), upper endpoint excluded",
            "small_radius_diagnostic_bin":"singleton [1,1], equality at Rs allowed",
            "receiving_center_volume_bin":"[(2*Rb)^n/2, (2*Rb)^n)",
            "s_star_exact_for_singleton_ratio_bin":s_star,"centre_to_small_volume_ratio":actual_volume_ratio,
            "h":h,"containment_verified":"Eu in every Q(y,h Rs), Ev in every Q(y,h Rb) intersect Q(z,h Rb) on the actual price boxes",
            "uniform_reference_outside_distance_threshold":threshold,
            "marks_order":"u,v,g,w with w contributing to original degree d(v), but outside the two downward branches",
            "actual_down_probability":interval_text(p_low),"true_d_v":interval_text(d),
            "whole_actual_two_price_mass":interval_text(whole),
            "whole_wrong_mass_omit_t_keep_Cv":interval_text(wrong),
            "whole_wrong_mass_omit_t_and_Cv":interval_text(wrong2),
            "two_dimensional_exact_whole_row":({"d":d,"p_down":p_low,"actual":whole,
                                              "omit_t":wrong,"omit_t_and_Cv":wrong2} if n==2 else None),
            "checked_independent_2d_price_cells":n==2,"true_anchor_y_centers":near,
            "true_z_centers_on_displaced_axes":far,"actual_probe_half_side":eps,
            "volume_overlap_gate":kappa,"certified_positive_pass_mass":interval_text(passing),
            "certified_positive_failure_mass":interval_text(failed),
            "cases":dcases}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B pairs778.py",
                      "scope":"genuine product measure and disjoint shrunken owners; only the stated finite probes and fixed ratio, no upstream high-dimensional screens",
                      "models":[certify(n) for n in (2,4,8,16,32)]},
                     sort_keys=True,indent=2,default=str))
