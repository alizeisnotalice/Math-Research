#!/usr/bin/env python3
"""R778 exact tube-mixed source prediction on real squares and unscreened upward paths."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(seq):
    return sum(seq,F(0))


def interval(lo,hi):
    return F(lo),F(hi)


def box(xlo,xhi,ylo,yhi):
    return interval(xlo,xhi),interval(ylo,yhi)


def q(c,r):
    return tuple((z-r,z+r) for z in c)


def meet(*regions):
    return tuple((max(a for a,b in axis),min(b for a,b in axis)) for axis in zip(*regions))


def inside(region,point):
    return all(a<=x<=b for (a,b),x in zip(region,point))


def lengths(region):
    return tuple(max(F(0),b-a) for a,b in region)


def leb(region):
    x,y=lengths(region)
    return x*y


SUPPORT=box(-6,6,-6,6)


def mu(region):
    (a,b),(c,d)=meet(region,SUPPORT)
    if not (a<b and c<d):
        return F(0)

    def primitive(x):
        p=x//F(1,4)
        rem=x-p*F(1,4)
        return p*F(1,4)+rem/2+max(F(0),rem-F(1,8))

    return (primitive(b)-primitive(a))*(d-c)


def certify():
    n=2
    a=32*n
    # Precisely u -> e -> v, with a denominator taken over every real neighbor.
    names=("u","e0","e1","v_H","v_V")
    center=((F(-3,8),F(-1,4)),(F(0),F(0)),(F(1,4),F(1,8)),
            (F(2),F(0)),(F(0),F(2)))
    radii=(F(3,4),F(1),F(1),F(5,4),F(5,4))
    A=tuple(q(c,r) for c,r in zip(center,radii))
    E=tuple(q(c,r/a) for c,r in zip(center,radii))
    assert all(meet(small,p)==small and leb(small)>0 for small,p in zip(E,A))
    assert all(not leb(meet(small,other)) for i,small in enumerate(E) for other in E[:i])
    I=tuple(map(leb,E))
    m=tuple(map(mu,A))
    assert all(mi==leb(cube) for mi,cube in zip(m,A))
    keys=range(len(A))
    S={(e,v):mu(meet(A[e],A[v])) for e,v in product(keys,repeat=2)}
    K={(e,v):S[e,v]/(m[e]*m[v]) if e!=v else F(0) for e,v in product(keys,repeat=2)}
    degree=tuple(ss(I[j]*K[i,j] for j in keys) for i in keys)
    edges=tuple(product((1,2),(3,4)))
    J={}
    for e,v in edges:
        assert m[0]<m[e]<m[v] and K[0,e]*K[e,v]>0
        assert F(3,2)<=m[v]/m[e]<2
        path=I[0]*I[e]*K[0,e]*I[v]*K[e,v]/degree[e]
        two_true_marks=I[0]*I[e]*I[v]*S[0,e]*S[e,v]/(m[0]*m[e]**2*m[v]*degree[e])
        assert path==two_true_marks
        J[e,v]=path
    total_J=ss(J.values())
    assert total_J>0

    K_dim={"H":(F(4),F(1)),"V":(F(1),F(4))}
    assert all(min(r)>=1 for r in K_dim.values())
    tube={(e,d):tuple((c-radii[e]*w,c+radii[e]*w) for c,w in zip(center[e],r))
          for e in (1,2) for d,r in K_dim.items()}

    def vertical_strip(lo,hi):
        return box(lo,hi,-6,6)

    high=vertical_strip("3/2",6)
    low=vertical_strip(-6,"3/2")
    low_exclusive=vertical_strip(-6,"7/8")
    overlap=vertical_strip("7/8","3/2")
    allocations={
        "single_H":(("H",SUPPORT,F(1)),),
        "single_V":(("V",SUPPORT,F(1)),),
        "partition":(("H",high,F(1)),("V",low,F(1))),
        "correct_overlap":(("H",high,F(1)),("V",low_exclusive,F(1)),
                           ("H",overlap,F(1,2)),("V",overlap,F(1,2))),
        "invalid_double_overlap":(("H",vertical_strip("7/8",6),F(1)),("V",low,F(1))),
    }
    predictions={}
    audited_positive_cells=0
    for name,pieces in allocations.items():
        restricted={(e,i):meet(tube[e,d],src) for e in (1,2) for i,(d,src,p) in enumerate(pieces)}
        direct={(e,i,v):w*mu(meet(restricted[e,i],A[v])) if v else w*mu(restricted[e,i])
                for e,i,v in product((1,2),range(len(pieces)),(0,3,4))
                for d,src,w in [pieces[i]]}

        all_rects=[*A,*tube.values(),*(src for _,src,_ in pieces),SUPPORT]
        x=sorted({x for region in all_rects for x in region[0]})
        y=sorted({z for region in all_rects for z in region[1]})
        by_position=defaultdict(F)
        overbook=F(0)
        for (lo,hi),(a0,b0) in product(zip(x,x[1:]),zip(y,y[1:])):
            cell=((lo,hi),(a0,b0))
            mass=mu(cell)
            if not mass:
                continue
            audited_positive_cells+=1
            mark=(lo+hi)/2,(a0+b0)/2
            rho=ss(w for _,src,w in pieces if inside(src,mark))
            overbook+=max(F(0),rho-1)*mass
            for (e,i),query in restricted.items():
                if inside(query,mark):
                    w=pieces[i][2]
                    by_position[e,i,0]+=w*mass
                    for v in (3,4):
                        if inside(A[v],mark):
                            by_position[e,i,v]+=w*mass
        assert all(row==by_position[k] for k,row in direct.items())
        if name=="invalid_double_overlap":
            assert overbook==mu(overlap)>0
        else:
            assert not overbook
        pred={}
        for e in (1,2):
            Z=ss(direct[e,i,0] for i in range(len(pieces)))
            assert Z>0
            rows={}
            for v in (3,4):
                value=ss(direct[e,i,v] for i in range(len(pieces)))
                actual_groups=[ss(direct[e,i,v] for i,piece in enumerate(pieces) if piece[0]==d)
                               for d in K_dim]
                normalize=value/Z
                weight_groups=[ss(direct[e,i,0] for i,piece in enumerate(pieces) if piece[0]==d)
                               for d in K_dim]
                assert normalize==ss(z/Z*w/z for z,w in zip(weight_groups,actual_groups) if z)
                volume_charge=m[e]/m[v]
                assert volume_charge==F(16,25)
                assert value/m[v]==volume_charge*(Z/m[e])*normalize
                assert volume_charge*value/(volume_charge*Z)==normalize
                if not overbook:
                    assert value<=m[v] and 0<=normalize<=1
                rows[v]={"weighted_volume_fraction":value/m[v],"actual_probability":normalize,
                         "component_volume_fractions":[w/m[v] for w in actual_groups],
                         "component_predictor_masses":weight_groups}
            pred[e]={"total_probability_normalizer":Z,"targets":rows}
        predictions[name]={"roots":pred,"global_source_budget_excess":overbook}

    def row(name,e,v):
        return predictions[name]["roots"][e]["targets"][v]

    for e,v in edges:
        assert row("invalid_double_overlap",e,v)["weighted_volume_fraction"]>=row("correct_overlap",e,v)["weighted_volume_fraction"]
    assert any(row("invalid_double_overlap",e,v)["weighted_volume_fraction"]>row("correct_overlap",e,v)["weighted_volume_fraction"]
               for e,v in edges)

    def payoff(values,name):
        return ss(J[e,v]*values(row(name,e,v)) for e,v in edges)

    def root_oracle(values):
        return ss(max(ss(J[e,v]*values(row(case,e,v)) for v in (3,4))
                      for case in ("single_H","single_V")) for e in (1,2))

    thresholds=[]
    for kappa in map(F,("1/2","3/5","2/3","3/4")):
        def hard(r):
            return int(r["weighted_volume_fraction"]>=kappa)

        def soft(r):
            return min(F(1),r["weighted_volume_fraction"]/kappa)

        mixed=payoff(hard,"partition")
        single_dir=max(payoff(hard,case) for case in ("single_H","single_V"))
        oracle=root_oracle(hard)
        group_one=payoff(lambda r:int(max(r["component_volume_fractions"])>=kappa),"partition")
        assert group_one<=mixed and single_dir<=oracle
        thresholds.append({"kappa":kappa,"best_single_fixed_direction_hard":single_dir,
                           "rootwise_oracle_single_direction_hard":oracle,
                           "per_edge_best_one_component_hard":group_one,
                           "after_aggregation_hard":mixed,
                           "rootwise_oracle_single_direction_partial":root_oracle(soft),
                           "after_aggregation_partial":payoff(soft,"partition"),
                           "corrected_overlap_hard":payoff(hard,"correct_overlap"),
                           "corrected_overlap_partial":payoff(soft,"correct_overlap"),
                           "invalid_overbooked_hard_for_comparison":payoff(hard,"invalid_double_overlap")})
        r=thresholds[-1]
        r["exact_paid_shares_of_J"]={name:w/total_J for name,w in r.items() if name!="kappa"}
    central=thresholds[1]
    assert central["after_aggregation_hard"]==total_J
    assert central["rootwise_oracle_single_direction_hard"]<total_J
    assert central["per_edge_best_one_component_hard"]<total_J
    assert central["rootwise_oracle_single_direction_partial"]<central["after_aggregation_partial"]

    prob=lambda r:r["actual_probability"]
    gain={}
    for e in (1,2):
        W=ss(J[e,v] for v in (3,4))
        mixed=ss(J[e,v]*prob(row("partition",e,v)) for v in (3,4))/W
        oracle=max(ss(J[e,v]*prob(row(case,e,v)) for v in (3,4))
                   for case in ("single_H","single_V"))/W
        assert mixed>oracle
        gain[e]={"mixed_probability":mixed,"best_single_direction_given_e_probability":oracle}
    claim="unscreened real u-e-v path, strictly increasing volume, same uphill ratio 25/16; R777 coupling and high-dimensional hard masks are outside scope"
    return {"dimension":n,"mu":"supported on [-6,6]^2; x-period 1/4 of densities 1/2 then 3/2, y-density 1",
            "physical_parents":dict(zip(names,A)),"disjoint_true_owners":dict(zip(names,E)),
            "m":dict(zip(names,m)),"direction_boxes":K_dim,
            "weights":{"uphill_ratio":F(25,16),"g":"log(25/16)","e_minus_g":F(16,25),"full_degrees":degree,
                       "one_test_bucket":"all four tested e-to-v rises have the same ratio 25/16; other original neighbors remain in d",
                       "normalizer":"a positive common factor for the one prescribed bucket cancels in U_e(A_v)/U_e(1), retained for the volume charge U_e(A_v)/m_v",
                       "J_by_e_v":{str(pair):w for pair,w in J.items()},"sum_J":total_J,"scope":claim},
            "same_real_source_partitions":allocations,
            "source_assignment":"measurable in actual source location; base split at first coordinate 3/2; overlap case splits the common strip 1/2 and 1/2",
            "single_base":"choose one of H and V per known e with all of mu; choice is fixed across that root's unseen v",
            "audit_positive_cells_across_modes":audited_positive_cells,
            "predictors":predictions,"actual_hit_probabilities_per_root":gain,
            "unnormalized_and_partial_gate_comparisons":thresholds}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction","command":"python -B mixed778.py",
                      "certificate":certify()},sort_keys=True,indent=2,default=str))
