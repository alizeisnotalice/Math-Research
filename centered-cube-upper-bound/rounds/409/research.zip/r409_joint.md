# R409：原完整信用的逐接收对结算与仍未付的正项

2026-10-19。只读恢复自 rounds/396/research.zip::r396_reference_scope.md，并对照 R408 当前总账。本稿未得到新付款；作用是核准原信用已精确抵消哪些项，防止再次用同一信用支付当前正流。不是新等价目标或测试数量构成的研究进展。

## 1. 同一原积分上的母式

范围为 hard-matched、full-source 的 BH(f,f)：m_u=f(Q_u)=q_uR_u^n，真实du，μ=du/m，a≤R≤b≤2a，E_r={R≤r}，J_y(r)=∫_{E_r}c_u(y)μ(du)，Y_r={J_y(r)≥H}。物理 ℓ=nr^(−n−1)dr+b^(−n)δ_b 不变。所有下述接收对积分统一用

 dξ=ℓ(dr)1_{E_r²}μ(du)μ(dv)。

定义 I=∫f c_uc_v，I_H=∫f1_Y c_uc_v，I_L=I−I_H，

 S_H=∫f1_Y c_uc_v/J，S_L=∫f1_{0<J<H}c_uc_v/J，
 G_H=∫f1_Y c_uc_v/√J，S_G=S_H+S_L，
 M=(√m_u+√m_v)²/4，S_*=G_H²/M，\bar m=(m_u+m_v)/2。

J=0积分取0。零J来源与真实捕获对同时出现的集合在 dξ fdy 下零测，由 Tonelli 的 ∫c_u(y)c_v(y)μuμv=J_y² 即得；包含终点原子。完整匹配给 ∫S_G μ(dv)=m_u，于是 ∫\bar m S_G dξ=X_q。所有涉及的正项有限，允许下述相减。

R396 母式为

 BH=L_*+D_*−L_low−R_cross−R_clock，
 L_*=∫\bar m(S_G−S_*)dξ，
 D_*=∫S_*(√m_u−√m_v)²/4 dξ。

这里 L_* 用接收对对称化后的等价表达。由于 \bar m−(√m_u−√m_v)²/4=M，

 L_*+D_*=∫[\bar m S_G−G_H²]dξ。                 (1)

## 2. 三笔信用各自抵消什么

低行第一矩满足精确式

 L_low=∫\bar m S_L dξ。                                  (2)

证明：积分v时 ∫c_v(y)μ(dv)=J_y，故 S_L 的行质量正好是该接收u捕获的低行源质量；接收对对称化不改变积分。这是原负号信用，不另加 λHW 完成费。

令 A_yz(r)=∫_{E_r}c_u(y)c_u(z)μ(du)。原高低交叉信用经 Tonelli 为

 R_cross=∫f(y)1_Y(y)f(z)1_{Y^c}(z)A_yz²/J_y dy dz ℓ(dr)
        =∫I_L S_H dξ。                                  (3)

原高高不等秩信用为

 R_clock=(1/2)∫f(y)1_Y(y)f(z)1_Y(z)A_yz²
                  (1/√J_y−1/√J_z)² dy dz ℓ(dr)
        =∫[I_H S_H−G_H²]dξ。                             (4)

式(4)被积函数非负，恰为共同交集来源的 J^(−1/2) 方差。此处“clock”沿用母式名称；没有换物理时钟或交换不同prefix。它已经是原被保留的负信用，不能把该方差再抽作另一笔付款。

将(2)–(4)一次代入(1)，全部 G_H² 与低交质量准确消去，得到

 BH(f,f)=∫(\bar m−I)S_H dξ
        =(1/2)∫f(Q_u Δ Q_v)S_H dξ。                     (5)

这是此前实际variance恒等式的接收对形式，不算新几何估计。对 ν≤f 仅有 BH(f,ν)≤BH(f,f)；本稿不把full-source等式冒充原ν的等式。

## 3. 未付正项与当前原Γ的绑定

仍用同一full f，有

 f(Q_u Δ Q_v)=|m_u−m_v|+2[min(m_u,m_v)−I]。

所以(5)分成两个非负真实量：

 M_H=∫_{m_u>m_v}(m_u−m_v)S_H dξ，
 C_H=∫[min(m_u,m_v)−I]S_H dξ，
 BH(f,f)=M_H+C_H。                                       (6)

半系数由对称性消去，没有把strict far门额外赋给所有接收对。

本段已经实际核读以下归档定义，依据不是从 R400 的 q_u/T_u 投影反推。档案根为 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/`：

- `389/research.zip::r389_geometry.md` §1式(1)，第12–17行，明确原 dΓ 的高J门、(m_u−m_v)、1/J、θ∈[0,1]和原prefix/strict-far支持；式(2)，第19–23行，保留比例 min(1,J/T_u)，故保留分母为 max(J,T_u)。
- 同文件 §5式(15a)–(15b)，第131–141行，明确 θ_bar_actual=R_u^n∫ell 1_{J≥H}θ·T_u/max(J,T_u)，以及 G_order 的 q_u/T_u·(1−m_v/m_u)·θ_bar_actual 精确等式。此处平均内的 T_u/max(J,T_u)=min(1,T_u/J)，与上一步保留比例 min(1,J/T_u) 不同，不能混写。
- `389/research.zip::r389_aux.md` §5，第121–130行，给出把这些因子全部放入 χ_actual 的显式定义（含 1_{v∈E_r}、高J、质量亏损和上述平均内比例），及式(9a)的实际成本等式。
- `390/research.zip::r390_aux.md` §1第13–18行继承该精确 χ；§3式(6)及第78–82行说明 G_cold 仅将原完整标记测度乘 (1−F_v/t)_+。`391/research.zip::r391_geometry.md` §1第5–11、20–22行明确 γ 是该 cold 流的原端点投影，后续 γ_A=1_{A×A}γ。故本段所用当前原核心是上述时钟测度的正限制，而非质量前缀上包络 G_prefix。

据此，R406恢复的原Γ_0在真实时钟平均之前具有因子

 ℓ(dr) f(y)1_{J_y(r)≥H} c_u(y)c_v(y)
 ·(m_u−m_v)/max(J_y(r),T_u(y)) ·θ_saved(r,y,u,v) μdu μdv dy，

其中0≤θ_saved≤1，保原prefix、严格m_u>K m_v、所有空间/历史/分数标记。时钟平均的 R_u^n 与 q_u 合起来为 m_u，故此式与 R406 的 q_uχ_0/T_u 表达完全一致；没有重置J。因此直接正比较给

 G_0≤M_H≤BH(f,f)。                                       (7)

这只绑定所恢复的同槽Γ_0归一化；不得把外入口系数或ν≠f的不同量自动代入。(7)不是所求上界，也不新增母账费用。它说明当前远质量正流不是任意参考拟合误差：它确实被原full-source正质量差项容纳。

现有I≤min(m_u,m_v)仅保证 C_H≥0；即使一对实际盒的较小来源质量完全落在较大盒内，使该对 C_H=0，仍未缩小该对 M_H。要直接结算(6)，尚需对同一实际选择器、原S_H/物理时钟下的质量差项和边界项给全局来源价格。局部匹配与上述信用恒等式没有提供这一估计。用已在(3)(4)消耗的信用再减 M_H 会重复扣款。

所以本轮没有向 R408 原母账加入新收据，亦不撤回任何正余项。后续几何可以从(5)整体建立新不等式；不能将其精确展开自身当作付款。

## 4. 必要本机复现

`/tmp/r409_joint_check.py` 已实际以标准库Fraction运行：

```
PASS exact finite-incidence cases 45 mixed 27 positive_filtered 8
Physical inclusive tail weights 1/m; finite algebra fixture, not native cube/history realization.
```

使用两接收类型、三个来源incidence类型、真实有限模型质量与有理√J；逐prefix核(1)–(6)，并核带额外strict质量比及≤1标记的filtered流≤M_H。物理前缀权为1/m的差及终点1/m（对应q=1、R^n=m的代数时钟）。它不是原实际中心cube选择器或全历史认证，45项仅核公式与方向；一般证明为上文Tonelli与正比较。
