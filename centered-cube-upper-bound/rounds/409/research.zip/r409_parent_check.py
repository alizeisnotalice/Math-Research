from fractions import Fraction as F
from itertools import product
counts={}
for phase,Ms,fs in [('initial',[2,4],[1,3]),('threshold_pressure',[1,3,9],[F(1,10),1,4,9]),('expanded',[16,64,256],[F(1,100),2,100,10000])]:
 c=0
 for M,s,f,delta in product(map(F,Ms),[F(1),F(3)],map(F,fs),[F(1,128),F(1,4)]):
  ts=[F(1,4),F(1),F(4),F(9)]
  ds=[M,M/2,M/4,M/8];cut=max(ts[0],(1-delta)*ts[-1]);early=F(0)
  for i in range(1,4):
   a=max(F(0),1-s/ds[i]);length=max(F(0),min(f,ts[i],cut)-ts[i-1]);early+=length*a/f
  for deathD in [F(0),ds[-1]]:
   defect=1-(max(F(0),1-ts[-1]/f) if deathD>s else 0)
   kappa=min(F(1),s/M)
   assert defect-early>=kappa*defect
   c+=1
 counts[phase]=c
print('PASS exact net-defect kappa checks',counts,'total',sum(counts.values()))
print('Finite scalar bounds only; no new geometric root payment.')
