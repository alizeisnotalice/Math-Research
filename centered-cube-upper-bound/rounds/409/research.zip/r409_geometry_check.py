from fractions import Fraction as F
from itertools import product, combinations
counts=[0,0]
# Exact net defect, arbitrary threshold jumps and all source/death boundary cases.
for ts,f,s,delta in product([[F(1,4),F(1,3),F(4),F(9)], [F(1),F(17,16),F(3),F(100)]], [F(1,10),F(1),F(3),F(4),F(9),F(100)], [F(0),F(1),F(3)], [F(1,64),F(1,8),F(1,2)]):
  ds=[F(10),F(7),F(3),F(1)]
  for j in range(1,4):
    cut=max(ts[0],(1-delta)*ts[j])
    early=harmonic=F(0)
    for i in range(1,j+1):
      length=max(F(0),min(f,ts[i],cut)-ts[i-1])
      a=max(F(0),1-s/ds[i])
      early+=length*a/f
      harmonic+=length*(1-a)/f
    for deathD in [F(0),ds[j]/2,ds[j]]:
      e=(max(F(0),1-ts[j]/f) if deathD>s else F(0))
      defect=1-e
      occ=defect-min(f,ts[j])/f
      band=(min(f,ts[j])-min(f,cut))/f
      base=min(f,ts[0])/f
      assert defect-early==occ+band+base+harmonic
      assert min(occ,band,base,harmonic,defect-early)>=0
      counts[0]+=1
# Full-mass finite source incidence: shared large-end domination, including nonnested sets.
for fv in [(F(1),F(2),F(4)),(F(3),F(1),F(2))]:
  sets=[set(c) for k in range(1,4) for c in combinations(range(3),k)]
  for u,v,a in product(sets,sets,product([F(0),F(1,3),F(1)],repeat=3)):
    mu=sum(fv[y] for y in u);mv=sum(fv[y] for y in v)
    shared=sum(fv[y]*a[y] for y in u&v)/mu
    small=sum(fv[y]*a[y] for y in v)/mv
    assert shared<=mv/mu*small
    counts[1]+=1
print('PASS net/shared:',*counts,'total:',sum(counts))
