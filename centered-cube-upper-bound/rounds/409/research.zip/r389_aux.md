# R389 — Atomic truncated Hardy compression on the actual matched receiver field

**Proved:** a strict L^p contraction for a frozen-field source-resampling kernel, with all measure conversions and the q-band factor explicit. **Not proved:** a source-W budget for the original residual. Iterating this auxiliary kernel is mathematically legitimate, but does not by itself realize the original target/history process or pay its forcing and terminal terms.

## 1. Actual field and operator

Keep full f≥0 integrable, the real Lebesgue receiver set E, actual cubes Q_u, and

m_u=∫f c_u=q_uR_u^n,  q_-≤q_u≤λ,  a≤R_u≤b≤2a,

μ(du)=du/m_u,   π_u(dy)=f(y)c_u(y)dy/m_u,
T_u(y)=∫_E c_v(y)1_{m_v≤m_u}μ(dv).

All ranks are inclusive and use the original full field. Write d>0 for the already chosen R387 close-rank parameter, and set

β=1/(1+d)∈(0,1),   L=log(1+d),   r_q=λ/q_-.

Let 0≤χ(y,u,v)≤1 be any jointly measurable frozen mark supported on

T_v(y)<β T_u(y).                                             (1)

It may retain strict far mass, the lower middle-rank gate, regularity, surplus, clock-averaged fractional retention and all other actual admissible marks. In particular the proposed middle support is

m_u>K m_v,  T_u>(1+d)T_v,  T_v>τ Z_u,  T_u<2Z_u,

with the original parameters; no lower gate is needed in the norm proof. Define

(Bg)(u)=∫π_u(dy) [1/T_u(y)]∫c_v(y)χ(y,u,v)g(v)μ(dv).          (2)

Zero-rank terms are set to zero. Such terms have zero joint source/receiver measure, since the inclusive mass-rank-zero set has zero μ_y measure for every fixed y.

For every 1<p<∞,

||B||_{L^p(du)→L^p(du)}≤p' β^(1−1/p),   p'=p/(p−1),          (3)

and

||B||_{L^p(q_u du)→L^p(q_u du)}
≤r_q^(1/p) p' β^(1−1/p)=:c_p.                               (4)

The mark χ need not be symmetric or factor into separate receiver functions. Positivity gives |Bg|≤B|g|, so the assertions cover signed functions as well.

## 2. Closed-atom sourcewise Hardy proof

Fix a source y. Let ρ_y(du)=c_u(y)μ(du), let J=ρ_y(E), and let T be its inclusive CDF under u↦m_u. J is finite by the actual-center envelope. If J=0 there is nothing to prove.

For any nonnegative g∈L^p(ρ_y), let g* be its decreasing rearrangement on (0,J), extended by zero beyond J. For every measurable set A of ρ_y-measure at most s,

∫_A g dρ_y≤∫_0^s g*(t)dt.                                  (5)

One direct proof is layer cake: ∫_A g=∫_0^∞ρ_y(A∩{g>a})da≤∫_0^∞min(s,ρ_y{g>a})da. Thus (5) also handles a receiver mass atom whose internal g-values vary.

The inclusive-rank capacity is

ρ_y{v:T_v<β T_u}≤β T_u.                                     (6)

An atom crossing the rank cutoff is excluded; one ending below it is included. This is the same generalized-inverse rank statement used in R387. Using (5) and (6), the sourcewise operator in (2) is bounded by

F(T_u),   F(t)=(1/t)∫_0^{βt}g*(s)ds.

Since g* is decreasing, F is decreasing. Under generalized-inverse ranks s∈(0,J), the mass endpoint satisfies T_u≥s almost everywhere. Therefore

∫|B_y g(u)|^pρ_y(du)≤∫_0^J F(s)^pds.                         (7)

This is the necessary atom correction. It would generally be invalid to replace T_u by the current internal atom rank directly inside the original truncated domain. Rearrangement first makes the comparison monotone and valid.

Writing Hφ(t)=t^(−1)∫_0^tφ, one has F(s)=β H(g*)(βs), so

∫_0^J F(s)^pds≤β^(p−1)∫_0^∞H(g*)(t)^pdt
≤(p')^p β^(p−1)∫_0^J g*(t)^pdt.                             (8)

For completeness, the final Hardy inequality follows by integration by parts for V(t)=∫_0^tφ:

∫(V/t)^pdt≤p'∫φ(t)(V(t)/t)^(p−1)dt,

followed by Hölder. The lower boundary vanishes because V(t)^p/t^(p−1)≤∫_0^tφ^p→0; φ here has finite support and belongs to L^p, so the upper boundary vanishes as well. Truncation and monotone convergence handle unbounded φ. This proves (8), then (3) sourcewise, without assuming atomlessness or regular rank density.

## 3. The exact lift and conditional compression

The joint measure is

η(du,dy)=f(y)c_u(y)dy μ(du)=du π_u(dy).                       (9)

The equality uses the same full-f matching m_u=∫f c_u. Hence the lift Ig(u,y)=g(u) is an isometry:

∫|Ig|^p dη=∫_E|g(u)|^pdu.

Conditional averaging E_π h(u)=∫h(u,y)π_u(dy) is an L^p contraction by Jensen. Apply the sourcewise estimate (8), integrate with f(y)dy, and use these two maps to prove (3). No m_u du reversibility, uniform source density or independent-source assumption appears.

Finally q_-≤q_u≤λ gives

||Bg||_{L^p(qdu)}≤λ^(1/p)||Bg||_{L^p(du)}
≤r_q^(1/p)p'β^(1−1/p)||g||_{L^p(qdu)},

which proves (4). Omitting r_q^(1/p) would be unjustified for variable q.

The kernel is jointly measurable by the original capture/rank measurability and nonnegative integration. Rearrangements in §2 are used separately to prove a numerical norm inequality for each source; no jointly measurable choice of a rearrangement or source-dependent optimizer is required for defining B.

## 4. Explicit contraction and the lawful auxiliary resampling interpretation

For p≥2, log p'≤2/p. Thus

log c_p≤−L+[2+L+log r_q]/p.

The explicit choice

p≥max{2, 2[2+log(1+d)+log r_q]/log(1+d)}                     (10)

ensures c_p≤exp(−L/2)=(1+d)^(−1/2)<1. The bound retains the actual fixed d and q ratio; it does not retune the original h or receiver field.

Moreover B1≤β pointwise: (6) applies before the π_u average. Accordingly (2) defines a genuine subprobability kernel. It can be realized as follows: at u, draw a new source y according to the true π_u, then use the subprobability measure χ(y,u,v)ρ_y(dv)/T_u(y), with the missing mass killed. This is an auxiliary resampling construction on the frozen original field; arbitrary frozen marks χ only reduce its mass. It does not require nested cubes.

Finite powers and the Neumann resolvent are therefore mathematically well-defined. On L^p(qdu),

||(I−B)^−1||≤1/(1−c_p).                                     (11)

This is an operator statement, not an original-history realization. If the original marked edge keeps its current source or target/history labels, refreshing y with π_u changes that joint law. A comparison of first-step kernels does not certify that all later actual arrivals are governed by the same B. Even for the auxiliary process, a receiver injection evolves under the adjoint and need not remain bounded by q_u du pointwise.

## 5. Connection to the new clock payment, with all unpaid quantities visible

The parent clock correction removes the positive wrong-order contribution (1−J_y(r)/T_u(y))_+ at its stated source price. After that positive split, the retained original reciprocal clock has denominator max(J_y(r),T_u(y)). Let Θ(r,y,u,v)∈[0,1] denote all its old marks except the displayed high-J indicator and mass-loss factor. Define the original physical probability ν_u(dr)=R_u^n1_[R_u,b](r)ell(dr) and the **exact** averaged mark

χ_actual(y,u,v)=∫ν_u(dr) 1_{v∈E_r}1_{J_y(r)≥H}Θ(r,y,u,v)
                 (1−m_v/m_u) T_u(y)/max(J_y(r),T_u(y)).

Its support remains strict far mass and all the original middle-rank restrictions, and 0≤χ_actual≤1. Zero-rank terms are zero. Take K_actual to be (2) with this χ_actual. The identities q_uR_u^n=m_u and π_u=f c_u dy/m_u give, without a domination loss,

G_order=∫q_u (K_actual 1)(u)du.                              (9a)

The ratio T_u/max(J,T_u) is retained in χ_actual; it is not dropped when identifying the actual row cost. Thus the Hardy norm applies directly to the exact frozen cost kernel K_actual. This is the kernel used in the conditional bridge below.

The norm proof permits every such actual mark. It neither re-proves nor spends the parent's clock receipt a second time. Under that receipt, its displayed price

(λ/q_-) log(λ/q_-) log_+(J_max/h) W

stays in the original ledger with the original outer multiplier. This file introduces no further claimed W payment and no negative capture credit.

In particular (11) does not bound an arbitrary forcing term or terminal functional by W. For example an L^p forcing norm controlled only by the receiver measure yields a receiver-volume budget, not the desired source budget. A proposed renewal equation must still identify the actual forcing, establish its comparison with the original labeled cost, and provide a source-W estimate for the forcing and terminal pairing. No such estimate is supplied here. The independent strict mass/rank conditions make the auxiliary kernel meaningful, but do not by themselves complete this missing budget.

## 6. Initial mass-band audit: why the simpler block bound stopped

For completeness, the initial kernel of this task is

K(u,v)=∫f(y)c_u(y)c_v(y)dy/(m_um_v).

For a receiver mass band I=[L_0,U_0], actual center integration gives

J_I(y)=∫_{m_v∈I}c_v(y)dv/m_v≤B_I:=[1+log(U_0/L_0)]/q_-.

Indeed capture implies m_v≥q_-(2||v−y||∞)^n; integrate the actual-center bound 1_{x≤U_0}/max(L_0,x) with dv=dx/q_-.

Thus a block K_ij:E_j→E_i has real-du row capacity B_j and column capacity B_i. Cauchy followed by integration gives the lawful Schur bound ||K_ij||≤√(B_iB_j). This uses actual row and column inequalities, not PSD or a diagonal-to-spectrum inference. Also ∫fJ_iJ_j=∫_{E_i×E_j}K, exactly.

However the resulting block-majorant matrix is (√B_i√B_j), whose best positive diagonal-weight Schur bound is Σ_iB_i. To see this, put s_i=√B_i and weights w_i>0. Its weighted row ratios are s_i(Σ_js_jw_j)/w_i; averaging with probabilities s_iw_i/(Σ_js_jw_j) gives exactly Σ_iB_i. Equality is attained at w_i=s_i. For a contiguous partition of the entire allowed mass interval, Σ_iB_i=[N+log(λ/q_-)+n log(b/a)]/q_-. This summation therefore retains a generally linear dimension loss. It does not show that the true kernel has a linear norm; it shows why that separate-capacity majorant cannot establish a new root estimate. The Hardy argument above uses additional ordered rank truncation that this majorant discarded.

## 7. Actual local computation and limits

`/tmp/r389_aux_check.py` was actually executed with standard-library Fraction arithmetic:

`PASS {'native_energy': 78, 'block_schur': 1225, 'weighted_majorant': 1485} total 2788`

`PASS Hardy {'atomic_lp': 3888, 'compressed_lp': 2592, 'lift': 1296} total 7776 all_total 10564`

The first group computes exact **native real-center** one-dimensional intersection integrals for piecewise-constant actual radius and f=1 on a bounded interval. Independent source integration verifies the joint energy identity. Its Galerkin and weight tests concern only the stated block inequalities.

The Hardy group checks varying values inside equal-mass atoms, strict truncated rank endpoints and the p-th-power form of (8), so no irrational constant is approximated. The compression tests use exact actual cube/source incidences with full-f masses and variable q in its band, and check the lift identity and both du and qdu inequalities for signed vectors. Their receiver integration is finite positive quadrature, not a native continuum receiver field. These tests do not certify (10) by sampled p values or establish a source-W price. The general atomic and continuum proofs are §§2–4.

## 8. Why the row-cost Bellman condition does not add a new mechanism

For the exact same-plan kernel K=K_actual, put a=K1. The proved row cap gives 0≤a≤β<1. Positivity therefore implies

Ka≤βK1=βa,   a−Ka≥(1−β)a.                                  (12)

Consequently the proposed additional assertion a≤Ka+DF, with the full-f witness F∈[0,1], would directly give

a≤D F/(1−β).                                                 (13)

This merely enlarges the old witness coefficient; it does not need the L^p estimate or establish a new geometric payment. The assertion itself remains unproved for the actual residual. It must not be presented as a new root-budget breakthrough.

Keeping the actual defect e=(a−Ka−DF)_+ gives 0≤e≤1 and

e≥[(1−β)a−DF]_+,   a≤(DF+e)/(1−β).                          (14)

Thus the defect retains at least this same witness shortage. No bound for ∫q_u e_u du is established here, and setting e=0 is not justified. The old source price for ∫q_uF_u du cannot be charged twice; any further use must pay its actual multiplier or rebuild an alternative ledger.

For clarity, the general positive-operator implication is still valid: on finite σ=qdu, if ||K||_Lp(σ)≤r<1, then iteration of a≤Ka+DF+e and K^N a→0 in L^p yields

a≤(I−K)^−1(DF+e),
∫a dσ≤X^(1−1/p)||DF+e||_p/(1−r).

If e=0, this is at most A X^(1−1/p)(∫F dσ)^(1/p), A=D/(1−r), and scalar Young gives εX+C∫F dσ with

C=[((p−1)/p)^(p−1) A^p]/[p ε^(p−1)].

These conditional formulas are correct, but for this task's a=K1 they do not improve the elementary pointwise consequence (13). For a different forcing function, the Neumann operator remains valid; identifying and paying such a forcing with the original geometry is still missing. The genuinely proved new analytic interface in this file is the actual-kernel atomic Hardy contraction, not this conditional bridge.

Additional local checks for this section: the same script actually ran 242 exact assertions for the Young optimizer and a finite positive nilpotent-kernel defect/resolvent implication. The cumulative executed count is **10,806**. These checks verify the conditional algebra, not its applicability or a new source payment.
