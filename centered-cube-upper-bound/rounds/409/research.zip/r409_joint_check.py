from fractions import Fraction as F
from itertools import product
mu=[F(9,25),F(16,25)]
pat=[(1,0),(0,1),(1,1)]
rootJ={F(0):F(0),F(9,25):F(3,5),F(16,25):F(4,5),F(1):F(1)}
count=mixed=positive_filtered=0
for ru,rv,H in product((F(1),F(2),F(3)),(F(1),F(2),F(3)),(F(1,4),F(1,2),F(3,4),F(1),F(5,4))):
    mass=[ru*ru,rv*rv]; roots=[ru,rv]
    fw=[mass[0]-F(1,2),mass[1]-F(1,2),F(1,2)]
    levels=sorted(set(mass)); totals=[F(0)]*10
    hasmixed=False
    for k,lev in enumerate(levels):
        active=[u for u in range(2) if mass[u]<=lev]
        clock=1/lev-(1/levels[k+1] if k+1<len(levels) else 0)
        J=[sum(mu[u]*pat[y][u] for u in active) for y in range(3)]
        high=[j>=H for j in J]
        hasmixed |= any(high) and any(j>0 and not hi for j,hi in zip(J,high))
        X=LH=Q=RC=RK=L=D=MASS=BOUNDARY=FILTER=F(0)
        for u in active: X+=mu[u]*mass[u]**2
        for y in range(3):
            if high[y]: LH+=fw[y]*sum(mu[u]*mass[u]*pat[y][u] for u in active)
        for u,v in product(active,repeat=2):
            I=sum(fw[y]*pat[y][u]*pat[y][v] for y in range(3))
            IH=sum(fw[y]*pat[y][u]*pat[y][v] for y in range(3) if high[y])
            SG=sum(fw[y]*pat[y][u]*pat[y][v]/J[y] for y in range(3) if J[y])
            SH=sum(fw[y]*pat[y][u]*pat[y][v]/J[y] for y in range(3) if high[y])
            GH=sum(fw[y]*pat[y][u]*pat[y][v]/rootJ[J[y]] for y in range(3) if high[y])
            M=(roots[u]+roots[v])**2/4; Sstar=GH**2/M
            weight=mu[u]*mu[v]
            Q+=weight*GH**2
            L+=weight*mass[u]*(SG-Sstar)
            D+=weight*Sstar*(roots[u]-roots[v])**2/4
            RC+=weight*(I-IH)*SH
            RK+=weight*(IH*SH-GH**2)
            MASS+=weight*abs(mass[u]-mass[v])*SH/2
            BOUNDARY+=weight*(min(mass[u],mass[v])-I)*SH
            if mass[u]>8*mass[v]: FILTER+=weight*(mass[u]-mass[v])*SH/F(6)
        BH=F(0)
        for y,z in product(range(3),repeat=2):
            if not high[y]: continue
            A=sum(mu[u]*pat[y][u]*pat[z][u] for u in active)
            BH+=fw[y]*fw[z]*A*(1-A/J[y])
        assert L+D==X-Q
        assert RC>=0 and RK>=0 and MASS>=0 and BOUNDARY>=0
        assert BH==L+D-(X-LH)-RC-RK==MASS+BOUNDARY
        assert FILTER<=MASS<=BH
        values=[BH,L,D,X-LH,RC,RK,MASS,BOUNDARY,FILTER,Q]
        totals=[a+clock*b for a,b in zip(totals,values)]
    assert totals[0]==totals[1]+totals[2]-totals[3]-totals[4]-totals[5]
    assert totals[0]==totals[6]+totals[7]
    count+=1; mixed+=hasmixed; positive_filtered+=totals[8]>0
print('PASS exact finite-incidence cases',count,'mixed',mixed,'positive_filtered',positive_filtered)
print('Physical inclusive tail weights 1/m; finite algebra fixture, not native cube/history realization.')
