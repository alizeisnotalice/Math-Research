# R409 independent audit — FINAL PASS (exact net/credit scope; no new root payment)

FINAL PASS for the original BH full-source identity, the clock-restored current-core domination, and the explicit lossy net-deletion bound. R408's complete budget remains unchanged. Neither the early marked remainder nor a general root-order weak-type bound is certified. Only this audit file was edited; no author/repository files were changed. Independent derivations preceded reading R409 author proofs, followed by the bounded post-review and actual checks below.

## 1. Independent derivation of the original high-source identity

Read the frozen R396 definition for the hard-matched full field, actual du, mu(du)=du/m_u, E_r={R_u<=r}, J_y(r)=integral_Er c_u(y)mu(du), H>0 and the unchanged physical ell including b^(-n)delta_b. Define

    A_r(y,z)=integral_Er c_u(y)c_u(z)mu(du),
    I_uv=integral f c_u c_v,
    S_H(r,u,v)=integral f(y)1_{J_y(r)>=H}c_u(y)c_v(y)/J_y(r)dy.

Zero-J terms are zero. At each prefix the original source formula is

    BH_r(f,f)=integral f(y)f(z)1_high(y)
                              A_r(y,z)[1-A_r(y,z)/J_y(r)]dy dz.

Expanding only positive integrals gives integral f(z)A_r(y,z)dz=integral_Er c_u(y)du. Its first term also equals the receiver-pair integral of (m_u+m_v)S_H/2: one of the source capture sums cancels J_y and receiver-pair symmetry averages the two identical expressions. The quadratic second term is integral mu(du)mu(dv) I_uv S_H. Therefore exactly

    BH(f,f)=integral ell mu(du)mu(dv)1_Er² S_H[(m_u+m_v)/2-I_uv]
           =1/2 integral ell mu(du)mu(dv)1_Er²
                                      S_H f(Q_u symmetric-difference Q_v).

The high gate is on the same old source and same physical prefix throughout. It is not exchanged with a different time, rank field, source law or endpoint gate. Actual full matching is required for m_u,m_v,I; using an unrelated or truncated target source would not preserve this equality.

All terms are finite: the full un-gated first moment integrates to Xq using the inclusive physical tail ell([R_u,b])=R_u^(-n). The high first moment is <=Xq; I_uv<=min(m_u,m_v) makes the quadratic and difference expressions nonnegative. Empty prefixes give0, H>0 removes live J=0 denominators, and the remaining zero-J capture null sets follow by Tonelli. No low-J completion fee is needed to derive this exact high-source identity. The b atom is retained; no boundary clock term is discarded.

For a dominated target nu<=f, only BH(f,nu)<=BH(f,f) follows from the original positive source kernel. The full-source symmetric-difference equality must not be stated as equality for the different nu cost.

## 2. Exact use of the old credits and mass decomposition

Independently from R396, let I=I_H+I_L, G_H=integral f high c_uc_v/sqrt(J), and S_G=S_H+S_L. The old quantities satisfy

    L_*+D_*=integral [mbar S_G-G_H^2],
    L_low=integral mbar S_L,
    R_cross=integral I_L S_H,
    R_clock=integral [I_H S_H-G_H^2].

The last integrand is nonnegative by weighted Cauchy on the common high-source intersection. These expressions contain the same full clock and pair measure. Subtracting each old credit ONCE leaves exactly integral (mbar-I)S_H above. In particular G_H^2 cancels in the accounting; the old high-source J variance cannot be subtracted again to pay a newly named positive term.

The full-f set identity

    f(Q_u symmetric-difference Q_v)
       =|m_u-m_v|+2[min(m_u,m_v)-I_uv]

then yields

    BH(f,f)=M_H+C_H,
    M_H=integral_{m_u>m_v}(m_u-m_v)S_H dxi,
    C_H=integral [min(m_u,m_v)-I_uv]S_H dxi>=0.

The half factor in the first term is removed by receiver-pair symmetry. Equal-mass receiver pairs remain in C_H; omitting them by imposing a strict ordering on both terms would be wrong. This decomposition alone gives no new global source bound for M_H or C_H. Their pointwise nonnegativity does not pay either one. A strict-far overhang comparison can be algebraically bounded by its mass-difference term, but it would still require its correct already-entering reduction, absorption and non-reuse audit; no new such receipt is asserted here.

## 3. Clock-restored G0<=M_H: independent archive verification

Did not infer the claim merely from the R400 q_u/T_u receiver projection. Read the authoritative R389 archive's geometry original dGamma and its exact actual-clock formulas, and auxiliary explicit chi_actual; also verified the R390 cold positive restriction and R391 current endpoint/core definition.

Before the clock average, the actual retained original ordered cost is exactly a positive restriction of

    ell(dr) f(y)1_{J_y(r)>=H}c_u(y)c_v(y)
       (m_u-m_v)/max(J_y(r),T_u(y))
       vartheta(r,y,u,v)dy mu(du)mu(dv),
    0<=vartheta<=1,

with u,v in the same E_r, original strict m_u>K m_v, and all saved source/space/history/fractional marks. The true probability R_u^n ell|_[R_u,b] is used once; multiplication by q_u gives m_u. Hence restoring this expression from the precise chi_actual loses no m or q factor. The retention ratio min(1,J/T_u) before restoration and the ratio T_u/max(J,T_u) inside the averaged mark are different factors and are not conflated.

Since max(J,T_u)>=J on live high-J terms, dropping only vartheta and extra positive restrictions gives

    G0<=M_H,far<=M_H<=BH(f,f).

The R390 cold multiplication and R391 core are genuine positive restrictions of that same original flow. Their inequality coefficients in later mother bounds do not redefine or rescale G0. The domination is therefore valid for the unscaled current G0, not automatically for64Lambda G0, a whole switching bill, arbitrary projected qdu kernels, or BH(f,nu) in the reverse direction. Same f, same H/J, clock and receiver normalizations are essential. This is accurate placement of the existing positive core in the original net quantity, not a root upper estimate or a new paid fee.

## 4. Independent net-deletion screen

At an actual deletion use d^d=1-e^d and early density integral A_j from the same original thresholds and dynamic occupations. The author's exact positive expansion of g_j=d^d-A_j is obtained simply by adding/subtracting q_j=min(f,T_j)/f and the initial q_0. The deleted-density contribution, initial layer, late interval and early occupancy remainder are all nonnegative; no old initial or terminal source cost is silently dropped. Values at f=0 are irrelevant to the original posterior/source integrals and use the original zero convention.

With M=S A_n and kappa_s=min(1,s/M), every original a_i=(1-s/D_i)_+ is <=1-kappa_s. Consequently

    A_j<= (1-kappa_s)q_j<= (1-kappa_s)d^d,
    g_j>=kappa_s d^d.

The two-endpoint weak defect is at least theta; thus the net deleted contribution has lower bound kappa_s theta on the counted edge measure. Initial no-switch deletions and finite survivor/terminal terms must remain separately indexed; the proof correctly uses G1-G_N for j>=1 and does not relabel it G0-G_N for free.

In a fixed nondegenerate octave at worst M proportional to n, this factor is only of order1/sqrt(n). It cannot absorb a previously fixed positive rho theta G0 term. Reducing the initial density/cascade parameter would require a complete corresponding reconstruction and gives a source scale s/kappa_s of order n, not the target root scale. If b=a or M<=s, kappa_s need not have that asymptotic loss; the final text now qualifies the worst nondegenerate scale correctly.

The shared large-end part is bounded by

    pi_u(c_v A_j)<= (m_v/m_u)pi_v(A_j)<=K^(-1)pi_v(A_j).

The last comparison is strict only if pi_v(A_j)>0; zero target contribution must give0<=0. This final endpoint wording was corrected in main/geometry. The remaining external large-end and entire small-end early costs still require a joint budget. The shared comparison is the old R398 ingredient, not new credit. Nor may a schedule-free cutoff inside a large density jump be assigned the survival qualification of a threshold never tested. The R408 late proof did not use such a qualification and remains valid.

## 5. Frozen author/report post-review and unchanged ledger

Read complete final r409_joint.md, r409_geometry.md, r409_main.md and r409_readme.md. PASS within the above scope. The joint note's original-definition citations have been checked against archive bytes, including the corrected R390 section3 Eq(6), lines78-82. The two old clock ratios, high source H, strict mass support and endpoint restrictions are explicit. No equality between the original cost and a larger mass-prefix envelope is used to prove the domination.

The geometry note's exact net expansion, zero-death occupation, source-density jump crossing, first/inner deletion indexing, finite terminal potential and survivor fee are consistent. Its uniform kappa_s lower bound is proved analytically; the geometry script itself did not test that inequality, and the separate parent scalar224 checks only its stated algebra. Selecting a weak owner does not remove the non-owner charge. No source field or stage table is replaced to claim an unearned threshold qualification.

Main/README correctly report no new root payment. The complete R408 feedback is unchanged: G0 coefficients16F_delta, BH coefficients32F_delta, entrance64F_delta, full C406/V406 mother fees multiplied by F_delta, outer E387/S390 and H/entry terms kept in their existing slots, with F_delta=(1-32delta)^(-1). The high/near/common/negative-square and deletion prices are not withdrawn or used twice. All early, entrance, geometric, historical, scale-limit and global absorption gaps remain explicit. No statement here certifies a general n^(1/2+o(1)) bound. PDF/skill/history-reading provenance in the report is not an independent reviewer verification of every old reduction.

## 6. Actual local mathematical checks and evidence limits

Before reading R409 authors, executed300 Fraction assertions over45 independently defined interval-source cases with exact continuous-source capture masses, actual physical-prefix tail weights including terminal atom, receiver quadrature, equal receiver masses and mixed high gates. They checked the direct source BH formula, symmetric-difference/mass-boundary identity, a fully clock-restored positive mark bounded by the far mass-difference term, and total first-moment domination. This reviewer fixture is NOT native Lebesgue receiver integration or a complete original-history example; its counts are not pooled with delivered evidence. No separate reviewer script was saved.

Read all three delivered scripts and actually reran them locally, all PASS:

- parent224 Fraction cases, phases32/96/96, scalar net-defect kappa inequality including zero deletion occupation and varying source thresholds;
- geometry3618 Fraction cases,972 exact net expansion/nonnegativity and2646 full-source incidence shared comparisons, including nonnested captures; not native cube/history qualification;
- joint45 finite-incidence clock cases,27 mixed high/low and8 positive filtered costs, with exact rational square roots of ranks and inclusive tail weights. The algebraic choice q=1,R^n=m permits these clock weights; it does not make the arbitrary source incidence a true cube-selector field.

Delivered total is3887 exact Fraction cases/assertion groups. Reruns by parent/reviewer are the same delivered cases, not additional experiments. No finite test proves an unestablished geometric source payment, and no number of exact identities upgrades a reformulation to a root theorem.

FINAL PASS for this bounded scope: the net-defect identities and their lossy lower bound, original BH credit restoration, and exact current-core positive domination are correct with final zero/degenerate cases qualified. They expose the missing joint source estimate but do not provide it. R408 total budget is unchanged. No author, script, result or repository file was edited by this reviewer. Audit is frozen at the bindings below.

## Final current file SHA-256 bindings
- `/tmp/r409_main.md`: `be4a446aa62bdb2d389ba925c58e9ffd7891a6b0d8aa7a024df5cbc26699bb4e`
- `/tmp/r409_readme.md`: `31b02356d92c84ce0b3f04b6175d3326434561180e02cb8faaf45a628c90e06d`
- `/tmp/r409_joint.md`: `737b488fb34578a00ff8cdd84fc2afb8c9ba2fbca74467ec767016c09928c14e`
- `/tmp/r409_geometry.md`: `cf818aa7206d1139016ad8fd53c5a18698e373163a7ab6206517640827e15686`
- `/tmp/r409_parent_check.py`: `2de2dcf1def9ac5cd03658d6f81ccf3c5efbbf23338d7187cae01edd0b5448aa`
- `/tmp/r409_parent.result.txt`: `2eb5fe6e916128473359f3571b348c673769e3a976c478d1126300743e8396ab`
- `/tmp/r409_joint_check.py`: `2667b09e4f93a09dc9f7f2944af69b878800de3defd845519557aa147cde29da`
- `/tmp/r409_joint.result.txt`: `46a9ae0c774ed70843d7751052448432dcfde7641b09f40c137f992b1b267834`
- `/tmp/r409_geometry_check.py`: `b79325810c5829f646550bf1da0a36f5e37c3e3a8bb44e0099880f54de826f33`
- `/tmp/r409_geometry.result.txt`: `c52f495175befb40a5b9bbe01a2c05617a42b874360bc83e506df0d0437c6f6b`
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`
- `/tmp/r396_reference_scope.md`: `9f3c15e5b97edbe4657fd8c87116fb01525b13861159f243f17cf55fa186c550`

## Authoritative original-definition member bindings (read without extraction/editing)
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/389/research.zip::r389_geometry.md`: `e007b0a5fca2af7e19fd8f7574c110c2ce1029de5d46d056c837fdecb22f2985`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/389/research.zip::r389_aux.md`: `a9886d08238803e049faa6f34085d823fa888cfede624756f10b3d962ad07fc4`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/390/research.zip::r390_aux.md`: `9b32a470d47ca8c874bb7e1aed1a62dc6b56a31a0e296f6e1de7e9337270dd36`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/391/research.zip::r391_geometry.md`: `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23`
