# R389 — Paying the actual radius/mass ordering error in the original clock

## 1. Precise receipt

Start with the actual G_smooth left by R388. Keep full f, the original Lebesgue receiver field E, all selected radii, matched masses m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, the original h/H, complete physical clock, and every previous source, spatial, target, rank and fractional mark. In particular the R388 coefficient D and the old R385 coefficient C_0 are unchanged. Write

 μ(du)=du/m_u, c_u=1_{Q_u},
 T_u(y)=T_y(m_u)=∫c_w(y)1_{m_w≤m_u}μ(dw),
 J_y(r)=∫_{R_w≤r}c_w(y)μ(dw),
 J_b(y)≤J_max=A_n/q_-,  A_n=1+n log(b/a).

The current positive cost has the original source-exact disintegrated form

 dΓ=ell(dr)f(y)dy [1_{J_y(r)≥H}/J_y(r)]
     θ(r,y,u,v)c_u(y)c_v(y)(m_u−m_v)μ(du)μ(dv),             (1)

with 0≤θ≤1 and support R_u,R_v≤r, m_u>K m_v, and Z_y(m_u/K−)>h. It includes the R387 middle-rank support and the actual R388 retained factors. No new plan is substituted into θ.

On every live term retain the fraction

                       p(r,u,y)=min(1,J_y(r)/T_u(y)).       (2)

Let P_order be the actual cost of the complementary fraction 1−p, and G_order the retained actual cost. Then

 G_smooth=P_order+G_order,
 P_order≤(λ/q_-)log(λ/q_-)∫f(y)log_+(J_b(y)/h)dy
        ≤(λ/q_-)log(λ/q_-)log_+(J_max/h)W.                 (3)

The retained original integrand has denominator exactly

                            max(J_y(r),T_u(y)).            (4)

Thus it is dominated by the same original marked traffic with denominator T_u(y). This is a priced change to the original kernel, not a new posterior witness. The cost in (3) has no additional X_q term and is dimension-free apart from its displayed logarithm.

The actual ordering error is identically zero if q_u is constant on E, since mass order then agrees with radius order. In general (3) is an error budget, not a root-order estimate of all of G_order or of its mass-prefix upper bound.

## 2. A true center-capacity bound for the ordering defect

Fix u,y and r≥R_u. The positive defect

                 Δ_u(r,y)=[T_u(y)−J_y(r)]_+

is bounded by the actual receivers with m_w≤m_u and R_w>r. Such a receiver obeys

 R_w≤s_u:=(m_u/q_-)^(1/n).

Consequently the defect is zero if r≥s_u. If r<s_u, set ρ=2||w−y||_∞. Capture c_w(y)=1 implies ρ≤R_w. Therefore, pointwise in the actual center w,

 c_w(y)1_{m_w≤m_u,R_w>r}/m_w
 ≤1_{ρ≤s_u}/[q_- max(r,ρ)^n].                              (5)

Integrating in genuine Lebesgue dw, the inner center cube contributes 1/q_- and the outer radial shells contribute n log(s_u/r)/q_-. Hence

 Δ_u(r,y)≤[1+log(m_u/(q_-r^n))]/q_-   for R_u≤r<s_u,
 Δ_u(r,y)=0                           for r≥s_u.            (6)

This estimates center capacity, never source mass by a volume times a density bound. The source f remains untouched. Non-nested selected cubes cause no problem: (5) is a pointwise envelope for the actual selected radius at each center.

There is a separate terminal fact: E_b=E, so

                      Δ_u(b,y)=0                           (7)

for every u,y. This is essential when s_u>b; the terminal atom is not charged using the positive envelope in (6).

## 3. Integrating the defect against the complete original clock

Let s=q_u/q_-≥1. Since s_u=R_u s^(1/n), (6), (7), and positivity give

 ∫_[R_u,b]ell(dr)Δ_u(r,y)
 ≤(1/q_-)∫_[R_u,s_u]nr^(−n−1)
                [1+log(m_u/(q_-r^n))]dr
 =1/(q_-R_u^n)∫_1^s[1+log(s/x)]dx/x²
 =log(q_u/q_-)/(q_-R_u^n).                                (8)

Here x=(r/R_u)^n. If s_u>b, extending the continuous integral to s_u is a positive bound; the actual terminal contribution is zero by (7). If s_u≤b, the defect vanishes after s_u. If s=1, both sides in (8) are zero. The exact antiderivative is −log(s/x)/x, so the integrated constant 1 disappears, leaving log s.

This is where the real clock improves the pointwise center bound. Replacing the defect by its largest constant before clock integration would lose this cancellation. Nothing is integrated as an independent selector-radius variable.

## 4. Source-exact payment and mass-rank atoms

For fixed (r,u,y), define the actual outgoing normalized mass

 V(r,u,y)=∫_{E_r}θ(r,y,u,v)c_v(y)(1−m_v/m_u)μ(dv).

Its original far support and 0≤θ≤1 imply 0≤V≤J_y(r). After using (m_u−m_v)μ(du)=du(1−m_v/m_u), the paid row in (1) is bounded by

 ell(dr)f(y)c_u(y)du dy · [V/J_y(r)] [1−J_y(r)/T_u(y)]_+
 ≤ell(dr)f(y)c_u(y)du dy · Δ_u(r,y)/T_u(y).                 (9)

A live source has T_u≥Z_y(m_u/K−)>h, so no live division by zero occurs. Define the contribution as zero when J or T_u is zero. The original H-gate also stays in the actual measure. It may be dropped only in this positive upper bound.

Integrating (9), applying (8), and using du/R_u^n=q_u μ(du) gives

 P_order≤∫f(y)dy ∫c_u(y)μ(du)
       [q_u log(q_u/q_-)/(q_-T_u(y))]
       1_{Z_y(m_u/K−)>h}.                                (10)

The strict far threshold uses K>1, so

             T_y(m_u−)≥Z_y(m_u/K−)>h.                     (11)

For an arbitrary finite inclusive mass CDF T,

 ∫1_{T(t−)>h}dT(t)/T(t)≤log_+(T(+∞)/h).                    (12)

At an atom whose rank rises from a>h to b, its contribution (b−a)/b is at most log(b/a). Occupied rank intervals are disjoint subsets of (h,T(+∞)], and the continuous part integrates 1/t over its occupied ranks. This includes singular continuous parts. An atom jumping from rank ≤h to rank >h is excluded by the strict left-rank condition; no uncharged initial-jump constant appears. If T(+∞)≤h the integral vanishes.

Since q_u log(q_u/q_-)≤λlog(λ/q_-), (10)–(12) prove (3). The source integration is exactly against full f. All quantities are nonnegative until the actual positive split (2); no old capture square or negative return credit has been used.

## 5. What the retained kernel now permits, and what remains unpaid

Multiplying (1) by (2) gives exactly 1/max(J,T_u) in place of 1/J. Thus, retaining all the original marks,

 G_order≤G_prefix,
 G_prefix:=∫ell(dr)f(y)dy ∫_{E_r²}
       [1_{J_y(r)≥H}θ(r,y,u,v)c_u(y)c_v(y)/T_u(y)]
       (m_u−m_v)μ(du)μ(dv).                               (13)

This upper bound does not assert G_prefix is already paid. It isolates the original spatial/target interaction over a global mass-prefix denominator, with the original order-mismatch error explicitly settled.

For reference, far matching gives R_v<R_u. Define the lawful clock average

 θ_bar(u,v,y)=R_u^n∫_[R_u,b]ell(dr)
                  1_{J_y(r)≥H}θ(r,y,u,v),                 (14)

with all original membership and other gates understood in θ. The physical tail identity gives 0≤θ_bar≤1. Equation (13) is then exactly

 G_prefix=∫f(y)dy∫c_u(y)c_v(y)μ(du)μ(dv)
       [q_u/T_u(y)](1−m_v/m_u)θ_bar(u,v,y).                (15)

There is also an exact mass-prefix representation of the retained actual cost. On live terms define

 θ_bar_actual(u,v,y)=R_u^n∫_[R_u,b]ell(dr)
       1_{J_y(r)≥H}θ(r,y,u,v) T_u(y)/max(J_y(r),T_u(y)).    (15a)

Set its integrand to zero if T_u=0. The extra ratio lies in [0,1], so 0≤θ_bar_actual≤1. Here R_u^n ell(dr) is the normalized clock measure; it is used once, with no additional normalization factor. Directly from (4),

 G_order=∫f(y)dy∫c_u(y)c_v(y)μ(du)μ(dv)
       [q_u/T_u(y)](1−m_v/m_u)θ_bar_actual(u,v,y).          (15b)

Thus (15b), unlike the upper bound (15), preserves the actual retained receiver and source costs exactly. Its rows may be used without replacing them by the larger G_prefix rows. The original θ_bar without the ratio still defines G_prefix and its domination in (13). Both averages retain all original clock gates; neither creates a source-exact conditional target plan or licenses inherited history.

The G_prefix expression is a domination of the original cost with frozen clock-averaged marks, not a reconstructed source-exact plan or a transition with inherited history. The R387 intermediate rank ratio and R388 high-posterior receiver support remain in those marks. Dropping them to estimate the whole rank prefix would return a linear receiver budget; that step is not a root-order conclusion.

If the entering ledger is BH≤G_smooth+E_388 X_q+S_388, the proved update is

 BH≤G_order+E_388 X_q+S_388
       +(λ/q_-)log(λ/q_-)log_+(J_max/h)W.                  (16)

The same bound holds with G_prefix replacing G_order. The original outer multiplier 2Λ applies to this slot and its added price. With the original h=(1+√n)/(ε_0q_-), the logarithm is exactly

                   log_+[ε_0 A_n/(1+√n)].                (17)

No D, C_0, h, historical mark or former source fee is retuned. Under q_-=3λ/4, the coefficient before the logarithm in (16) is (4/3)log(4/3).

Status: a generally valid piece of the actual clock traffic has been paid, and the retained denominator has been improved to a global mass-prefix denominator at a stated source cost. The remaining general geometric problem is to couple the actual mass-ordered overlap in (15) with its high-posterior and middle-rank marks. This note does not establish the full εX_q plus root-order W bound for that kernel.

## 6. Actual checks and limitations

Executed locally:

    python3 /tmp/r389_geometry_check.py

    PASS {'clock_integral': 24, 'native_center_capacity': 1740,
          'native_terminal': 348, 'inverse_rank': 324,
          'exact_split': 48} total 2484

All assertions use Fraction and certified rational logarithm bounds from the positive atanh series. Stage 1 places the continuous clock integral between exact monotone Riemann bounds and checks the claimed log endpoint value against that interval. The antiderivative proof itself is analytic in §3. An attempted optional SymPy check was unavailable because that Python environment has no sympy package; no symbolic-tool result is claimed.

Stage 2 uses genuine one-dimensional Lebesgue receiver intervals, not receiver quadrature. The full source is density 3/4 on [-4,4], plus mass 1/5 on [-3/5,−59/100]. One center interval has cubes capturing the packet, and a translated center interval has slightly larger cubes excluding it. Their exactly matched q-values lie in [3/4,1], producing actual radius/mass inversions. Center capture lengths are integrated exactly. The stage checks (6), the integrated defect bound (8), and zero terminal defect. These examples validate the native geometric mechanism but do not assert a nonzero original exponential-far/history-qualified G_smooth.

Stage 3 checks strict-left inverse-rank bounds with atoms and the exact positive splitting denominator, including zero denominators and equality cases. It does not assign terminal budgets or use numerical evidence to assert a general bound for (15).
