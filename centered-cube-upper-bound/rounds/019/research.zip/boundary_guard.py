#!/usr/bin/env python3
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
from math import comb
from functools import lru_cache
from pathlib import Path
import json

@lru_cache(None)
def pair(a,b,d):
    if a[0]=='D' and b[0]=='D':return max(F(0),1-abs(a[1]-b[1])/d)
    if a[0]=='P' and b[0]=='D':return pair(b,a,d)
    def ih(k):return d**(k+1)/((k+1)*(k+2))
    if a[0]=='D':
        e=a[1];p=b[1];sgn=-1 if e>0 else 1
        return sum((F(comb(p,k))*e**(p-k)*sgn**k*ih(k) for k in range(p+1)),F(0))
    p,q=a[1],b[1];lo=F(-1,2);hi=F(1,2);s=F(0)
    for pp,qq in ((p,q),(q,p)):
        for k in range(qq+1):
            power=pp+k+1;base=F(comb(qq,k),power);e=qq-k
            s-=base*lo**power*ih(e)
            for j in range(power+1):s+=base*comb(power,j)*hi**(power-j)*(-1)**j*ih(e+j)
    return s

def integral(kind):
    if kind[0]=='D':return F(1)
    p=kind[1];return F(0) if p%2 else F(1,2**p*(p+1))

def prod(xs):
    a=F(1)
    for x in xs:a*=x
    return a

def energy(terms,d):
    return sum((ca*cb*prod(pair(a,b,d) for a,b in zip(ta,tb)) for ta,ca in terms.items() for tb,cb in terms.items()),F(0))

def regular_fixture(n,d):
    f={tuple([('P',0)]*n):F(1)}
    for i in range(n):
        for p,c in ((2,F(6,n)),(4,F(-20,n))):
            ts=[('P',0)]*n;ts[i]=('P',p);f[tuple(ts)]=c
    m=sum(c*prod(integral(a) for a in t) for t,c in f.items());assert m==F(5,4)
    nu={t:-n*c/m for t,c in f.items()}
    surface=F(0);sigmass=F(0)
    for i in range(n):
        for endpoint in (F(-1,2),F(1,2)):
            for t,c in f.items():
                val=c*endpoint**t[i][1]/2
                ts=list(t);ts[i]=('D',endpoint);ts=tuple(ts)
                nu[ts]=nu.get(ts,F(0))+val/m
                sigmass+=val*prod(integral(a) for j,a in enumerate(t) if j!=i)
            for ta,ca in f.items():
                for tb,cb in f.items():
                    surface+=ca*cb*endpoint**(ta[i][1]+tb[i][1])*prod(integral(('P',a[1]+b[1])) for j,(a,b) in enumerate(zip(ta,tb)) if j!=i)
    assert sigmass==n*m
    bulk=sum(ca*cb*prod(integral(('P',a[1]+b[1])) for a,b in zip(ta,tb)) for ta,ca in f.items() for tb,cb in f.items())/m**2
    J=energy(nu,d);chi=energy({t:c/m for t,c in f.items()},d);A=surface/(4*m**2)
    assert J>=0 and chi>=0 and A>=F(n,2)
    # U_L=1+L^2/2-L^4/4, so full window [1/2,6/5] has unique winner R=1.
    # f >= 71/125 >0 on Q_(6/5); kappa=8/5.
    return {'n':n,'d':str(d),'J':str(J),'chi':str(chi),'surface_limit':str(A),'bulk_limit':str(bulk),
            'surface_scaled':float(J/d**(n-1)),'bulk_scaled':float(chi/d**n),
            'signal_curvature_ratio':float(J/F(8,5)/chi)}

def shift_identity(n,d):
    points=[tuple(F((j+1)*(i+2)%5,7) for i in range(n)) for j in range(3)]
    weights=[F(1),F(-3,2),F(2,3)]
    axes=[]
    for i in range(n):
        breaks=sorted(set([F(0),d]+[p[i]%d for p in points]));axes.append([(u,v) for u,v in zip(breaks,breaks[1:]) if u<v])
    avg=F(0);count=0
    for box in product(*axes):
        u=[(v+w)/2 for v,w in box];prob=prod((w-v)/d for v,w in box);cells={}
        for p,w in zip(points,weights):
            cell=tuple((p[i]-u[i])//d for i in range(n));cells[cell]=cells.get(cell,F(0))+w
        avg+=prob*sum(v*v for v in cells.values());count+=1
    direct=sum(w*v*prod(max(F(0),1-abs(a-b)/d) for a,b in zip(p,q)) for p,w in zip(points,weights) for q,v in zip(points,weights))
    assert avg==direct and avg>=0
    return {'n':n,'d':str(d),'shift_boxes':count,'energy':str(avg)}

def constant_guard(n,d):
    a=d-d*d/3;b=d/2
    J=F(n,2)*a**(n-1)-2*n*n*b*a**(n-1)+n*n*a**n
    if n>1:J+=n*(n-1)*b*b*a**(n-2)
    chi=a**n
    assert J>=0
    # Constant density tests only the signed boundary kernel, not kappa>0.
    return {'n':n,'d':str(d),'scaled_ratio_to_limit':float(J/d**(n-1)/F(n,2)),'bulk_ratio':float(chi/d**n)}

def finite_gain(d,t,precision):
    u=d/3;cells=list(range(int((-F(3,5)-u)//d),int((F(3,5)-u)//d)+1))
    def primitive(y):return y+2*y**3-4*y**5
    def capture(L):
        return [max(F(0),primitive(min(L/2,u+(j+1)*d))-primitive(max(-L/2,u+j*d))) if max(-L/2,u+j*d)<min(L/2,u+(j+1)*d) else F(0) for j in cells]
    mass=F(5,4);base=capture(F(1));sigma=[]
    for j in cells:
        sigma.append(sum((F(5,8) for y in (F(-1,2),F(1,2)) if u+j*d<=y<u+(j+1)*d),F(0)))
    vs=[(a-b)/mass for a,b in zip(sigma,base)];J=sum(v*v for v in vs);kappa=F(8,5)
    r=F(5,4)*t;wg=wp=100*r;V0=F(2)
    remainder=2*wg*V0**2/kappa**2+2*wp*V0/kappa+2*t*V0*(V0+wp)/((1-t)*kappa)
    assert r<=min(F(1,10),d/2)
    with localcontext() as ctx:
        ctx.prec=precision
        def dec(v):return Decimal(v.numerator)/Decimal(v.denominator)
        avg=Decimal(0)
        # Remove zero coordinates; all coordinates with potential nearby capture are retained.
        active=[i for i in range(len(cells)) if base[i] or sigma[i]]
        for small in product((-1,1),repeat=len(active)):
            signs=[0]*len(cells)
            for i,v in zip(active,small):signs[i]=v
            V=sum(s*v for s,v in zip(signs,vs));pR=sum(s*v for s,v in zip(signs,base))/mass
            for pm in (-1,1):
                L=1+pm*t*V/kappa;row=capture(L);m=sum(row);Z=sum(s*v for s,v in zip(signs,row))
                ratio=(m+pm*t*Z)/L/(mass*(1+pm*t*pR))
                avg+=max(Decimal(0),dec(ratio).ln())/(2**len(active))
        val=avg/dec(t*t);assert val>=dec(J/kappa-remainder)
        return {'d':str(d),'t':str(t),'signs':2**len(active),'gain_over_t2':format(val,'.24g'),
                'target_J_over_kappa':str(J/kappa),'remainder':str(remainder)}

def main():
    initial=[shift_identity(n,F(1,k)) for n in (1,2) for k in (2,4,16)]
    stress=[regular_fixture(n,F(1,k)) for n in (1,2,3) for k in (4,8,32,128)]
    expanded=[constant_guard(n,F(1,k*n)) for n in (4,8,16,32,64,256) for k in (4,16,64,256)]
    shift_stress=[shift_identity(n,F(1,2)) for n in (4,8)]
    finite=[finite_gain(F(1,k),F(1,k*h),70) for k in (2,4,8) for h in (128,1024,8192)]
    repeated=[finite_gain(F(1,k),F(1,k*h),110) for k in (2,4,8) for h in (128,1024,8192)]
    assert finite==repeated
    data={'finite_gain':finite,'arithmetic':'Fraction for geometry and kernels; Decimal 70/110 for logarithms; floats only final displays','seed':None,'status':'all assertions passed',
          'initial_signed_measure_identity':initial,'regular_true_winner':stress,
          'expanded_boundary_kernel':expanded,'signed_shift_stress':shift_stress,
          'scope':'No space-volume or nearmax certification; no fitted exponent.'}
    Path(__file__).with_name('results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'identity_boxes':sum(r['shift_boxes'] for r in initial+shift_stress),'regular_cases':len(stress),'expanded_cases':len(expanded),'regular_last':[r for r in stress if r['d']=='1/128']},ensure_ascii=False))
if __name__=='__main__':main()
