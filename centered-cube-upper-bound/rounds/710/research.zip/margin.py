"""Stronger high-loss and minimum-witness-displacement certificate on same history."""
import json
from flint import arb,ctx
from family import compute,floor_unique
ctx.prec=384
C=65536
z=arb(1)/8
slope=((1+4*arb(C))**(arb(3)/4)-1)/4
coef=384/slope+((1+z)**3+27/(1+C*z**2)**(arb(3)/4))/2
assert coef<arb('.92')
out=[]
for b in [32,48,56,64,72,80]:
    raw=compute(b,384);n=1<<b;a=32*n;k=1<<(b//2);m=b//4
    A=arb;L=A(n).log();h=1+A(1)/a;R=A(raw['R']);d=A(raw['d'])
    T=k/A(2).log();J=int(raw['full_layer_count_J']);Wp=A(raw['W_prime']);W=A(raw['W'])
    pad=h*R*(L/n).sqrt()/64
    nf=max(0,floor_unique(A(a)/2*((d-A(1)/a-pad)/R-A(6)/n)-1));p=A(nf)/a
    B=k//2;threshold=3*b//16+1
    mass=(B*(-p).log1p()).exp();tail0=mass
    for j in range(1,threshold):
        mass*=A(B+1-j)/j*p/(1-p);tail0+=mass
    assert tail0>=0 and tail0<=1
    complement=-((n-k)*(-A(2)/a).log1p()).expm1()
    # Inactive boundary independent of favorable active axes, sign folding preserves boundary.
    lower=(-(-J*Wp/T).expm1())*(-Wp/T).exp()*(complement/W)*(1-tail0)**2
    later=(A(k//2)*A(2).log()-n*A(a).log()).exp()/T
    missing_upper=later+(-n*A(a).log()).exp()/T
    lower_any=lower-missing_upper
    assert lower_any>0
    upperprod=A(raw['auxiliary_log_product_upper'])
    rho=(-L/6).exp()*L**(A(1)/3)
    assert (-upperprod).exp()*(1-missing_upper/lower_any)>rho
    out.append(dict(b=b,lower_H_any_qualified_menu=lower_any.str(26),
        mean_favorable=(B*p).str(17),R709_exclusion_margin=pad.str(17),
        auxiliary_mass_fraction_lower=((-upperprod).exp()*(1-missing_upper/lower_any)).str(22),
        required_mass_fraction=rho.str(22)))
print(json.dumps(dict(precision=384,contraction_variance_coefficient=coef.str(30),rows=out),indent=2))
