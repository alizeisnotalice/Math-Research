"""Sample a sufficient high-loss event, retaining the shell boundary conditioning."""
import json,math,random,socket,sys,os
from multiprocessing import get_context

def binomial_rare(rng,k,p):
    if p<=0:return 0
    gap=math.log1p(-p);idx=-1;count=0
    while True:
        idx+=1+int(math.log1p(-rng.random())/gap)
        if idx>=k:return count
        count+=1

def chance(a,s,n,lo,hi):
    # With X uniform [lo,hi], count all midpoint digits forcing X>y+s*(1+6/n).
    # At most one additional digit can contribute since 2s/a>hi-lo.
    u=max(0,min(a,int(math.floor(((lo/s-6/n)*a-1)/2))+1))
    th=s*((2*u+1)/a+6/n)
    return (u+(max(0,min(1,(hi-th)/(hi-lo))) if u<a else 0))/a

def trial(job):
    b,j=job;n=1<<b;a=32*n;k=1<<(b//2);d=2/(256*math.sqrt(k))
    g=math.log1p(-2/a);W=-math.expm1(n*g);thin=math.ldexp(W,-(b//4));t=k/math.log(2)
    # Using sqrt(n) in place of sqrt(n)-a^-n for the last incomplete layer.
    J=math.floor(k/thin);R=2*math.exp(-(J+1)*g)
    rng=random.Random(731710+99991*b+j)
    ell=int(-t*math.log1p(rng.random()*math.expm1(-J*thin/t))/thin)
    s=R*math.exp(ell*g);out=[]
    for lo,hi in [(d-1/a,d+1/a),(d+0.5/a,d+1/a)]:
        # Compute jitter relative to d separately for large b where hi-lo may round away.
        if hi==lo:
            p=max(0,math.floor(((d/s-6/n)*a-1)/2)+1)/a
        else:p=chance(a,s,n,lo,hi)
        assert 0<p<.5 and d-1/a>s*(1/a+6/n)
        first=binomial_rare(rng,k//2,p);second=binomial_rare(rng,k//2,p)
        count=first+second
        lognone=(n-k)*g+count*math.log1p(-1/(a*p))+(k-count)*math.log1p(-1/(a*(1-p)))
        wt=-math.expm1(lognone)/W
        out.append([first,second,wt,int(min(first,second)>3*b//16)])
    return [b,j,out,os.getpid()]
if __name__=='__main__':
    parity,w,nrep=map(int,sys.argv[1:4]);bs=list(map(int,sys.argv[4:]))
    jobs=[(b,j) for b in bs for j in range(parity,nrep,2)]
    with get_context('fork').Pool(w) as pp:rows=pp.map(trial,jobs,1)
    print(json.dumps(dict(args=sys.argv[1:],python=sys.version,host=socket.gethostname(),
        workers=len(set(r[-1] for r in rows)),rows=[r[:-1] for r in rows])))
