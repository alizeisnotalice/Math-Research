"""R710 compressed real finite-history Arb bounds; no giant label arrays.

PYTHONPATH=/Volumes/data/CodexTemp/cache/uv/archive-v0/C-cIC_VTqeqO2X1K \
/Users/zzh/.venvs/main/bin/python family.py
Only family.json is written. Counts whose bit length is astronomical remain
symbolic; all floors actually needed are uniquely certified by Arb intervals.
"""
from pathlib import Path
import hashlib
import json
import platform
import sys
from flint import arb, ctx


def out(x):
    return x.str(45)


def floor_unique(x):
    answer=x.floor().unique_fmpz()
    assert answer is not None, 'floor not certified at current precision'
    return int(answer)


def compute(b,bits):
    ctx.prec=bits
    n=1<<b
    sqrt_n=k=1<<(b//2)
    m=b//4
    a=32*n
    C=65536
    A=arb
    log2=A(2).log()
    beta=(-A(n)*A(a).log()).exp()
    t=A(sqrt_n)/log2
    rho=1-A(2)/a
    logrho=(-A(2)/a).log1p()
    W=-(A(n)*logrho).expm1()
    Wp=W/(1<<m)
    J=floor_unique((sqrt_n-beta)/Wp)
    e=sqrt_n-beta-J*Wp
    assert e>0 and e<Wp
    R=2*(-(J+1)*logrho).exp()
    h=1+A(1)/a
    d=2/(A(C)*k).sqrt()
    # Formulas are for D/2^n and V_T/2^n, retaining raw volume in labels.
    logP=A(n)*logrho-Wp/t
    early=(-(-Wp/t).expm1())*(-(J*logP).expm1())/(-logP.expm1())
    early+=((J*logP).exp())*(-(-e/t).expm1())
    early*= (A(n)*R.log()).exp()
    trigger=(A(n)*log2-(sqrt_n-beta)/t).exp()*(-(-beta/t).expm1())
    logNrec=A(k//2)*log2
    logVnorm=beta.log()+logNrec
    Nrec_beta=logVnorm.exp()
    receiving=A('0.5')*(-(-Nrec_beta/t).expm1())
    Dnorm=early+trigger+receiving
    logDoverV=Dnorm.log()-logVnorm
    log10upper=(-logDoverV-A(4*sqrt_n).log())/A(10).log()
    raw_count=A(a)/2*((d-A(1)/a)/R-A(6)/n)-1
    favorable=max(0,floor_unique(raw_count))
    p0=A(favorable)/a
    mu=A(k//2)*p0
    threshold=3*b//16+1
    assert threshold>A(3*b)/16
    if mu>threshold-1:
        fail=(-(mu-threshold+1)**2/(2*mu)).exp()
    else:
        fail=A(1)
    correction=1-2*(Wp/t).exp()*fail/W
    if correction>0:
        Hlower=(-(-J*Wp/t).expm1())*correction
    else:
        Hlower=A(0)
    auxiliary=A(C)/(2*(2*h)**2)*(k*(d+A(1)/a)**2+A(n)/(A(a)**2))
    bin_scale=(log2/n).exp()*h*R
    mandatory=A('0.5')-A(1)/a
    original_lower=A(m)/2*(A(C)*mandatory**2/bin_scale**2).log1p()
    # True-history and geometry certificates, valid for every actual owner point.
    assert R>2 and R*rho**J>2
    assert (R*rho**(J+1)-2).contains(0)
    assert d>A(1)/a and d+A(1)/a<1
    assert A(3)/4+A(1)/a<1
    assert A(7)/4-A(2)/a>1
    assert k+m<=n
    assert R<2*h*n/A(n).log()  # entire source pool is in original near range
    assert 2**(b//4)==int(A(k).sqrt().unique_fmpz())
    # Preclock and trigger are on opposite sides of the first-hit threshold.
    pre_remaining=(-(sqrt_n-beta)/t).exp()
    assert pre_remaining>A('0.5') or (pre_remaining-A('0.5')).contains(0)
    # The strict comparison is analytic: beta/t>0. Numerical enclosure may
    # overlap 1/2 because the excess is astronomically below working precision.
    firsthit_remaining=(-(A(sqrt_n))/t).exp()
    assert (firsthit_remaining-A('0.5')).contains(0)
    assert early>0 and trigger>0 and receiving>0 and Dnorm>0
    assert Hlower>=0 and Hlower<A('0.5')
    assert all(x.is_finite() for x in [logDoverV,log10upper,auxiliary,original_lower])
    return {'b':b,'n_symbolic':f'2^{b}','precision_bits':bits,'a':str(a),
            'sqrt_n_k':str(k),'passive_m':m,'Nrec_symbolic':f'2^{k//2}',
            'early_label_count_symbolic':'sqrt(n)*a^n - 1',
            'full_layer_count_J':str(J),'partial_raw_clock_e':out(e),
            'W':out(W),'W_prime':out(Wp),'R':out(R),'d':out(d),
            'log_D_over_VT':out(logDoverV),
            'log10_VT_over_4sqrt_n_D':out(log10upper),
            'favorable_digits':str(favorable),'mu':out(mu),'m0':threshold,
            'failure_bound_per_sign':out(fail),'H_lower_all_actual_owner_points':out(Hlower),
            'H_lower_exceeds_quarter':bool(Hlower>A('0.25')),
            'auxiliary_log_product_upper':out(auxiliary),
            'original_mandatory_log_product_lower':out(original_lower),
            'max_bin_scale':out(bin_scale),
            'common_u':out(h),
            'floors_certified':True,
            '_values':(logDoverV,log10upper,Hlower,auxiliary,original_lower)}


def main():
    # A compressed miniature with only about 10^3 shells permits an independent
    # direct layer sum, catching errors in geometric-series signs and factors.
    ctx.prec=256
    small=compute(8,256)
    n=256;a=32*n;root=16;m=2
    beta=(-arb(n)*arb(a).log()).exp();t=arb(root)/arb(2).log()
    g=(-arb(2)/a).log1p();W=-(n*g).expm1();Wp=W/(1<<m)
    J=int(small['full_layer_count_J']);e=root-beta-J*Wp
    logR=arb(2).log()-(J+1)*g
    direct=arb(0)
    for l in range(J):
        direct+=(n*(logR+l*g)-l*Wp/t).exp()*(-(-Wp/t).expm1())
    direct+=(n*(logR+J*g)-J*Wp/t).exp()*(-(-e/t).expm1())
    direct+=(n*arb(2).log()-(root-beta)/t).exp()*(-(-beta/t).expm1())
    receiving_clock=(arb(root//2)*arb(2).log()+beta.log()).exp()
    direct+=arb('0.5')*(-(-receiving_clock/t).expm1())
    independently_computed_logratio=direct.log()-(beta.log()+arb(root//2)*arb(2).log())
    assert independently_computed_logratio.overlaps(small['_values'][0])
    rows=[]
    for b in [32,48,56,64,72,80]:
        low=compute(b,256)
        high=compute(b,384)
        assert low['full_layer_count_J']==high['full_layer_count_J']
        assert low['favorable_digits']==high['favorable_digits']
        for x,y in zip(low['_values'],high['_values']):
            assert x.overlaps(y)
        del low['_values'];del high['_values']
        high['precision_crosscheck']='256-bit and 384-bit enclosures overlap; both floors identical'
        rows.append(high)
    result={'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'independent_miniature':{'b':8,'direct_layer_count':J,
                                     'log_D_over_VT':out(independently_computed_logratio),
                                     'direct_layer_sum_overlaps_closed_form':True},
            'rows':rows,
            'history_verification':[
                'Shell digit grids are restricted to the positive half on m passive coordinates. Their total raw owner clock per full layer is W/2^m; each full core has raw clock beta0=a^-n.',
                'Boundary tiny cores tile pairwise disjoint successive shells. Early minimum inner radius is R*rho^(J+1)=2; trigger and receiver tiny cores lie strictly inside this cavity.',
                'Every parent contains a common positive-volume origin cell. Thus ess sup load on every remaining parent equals total selected theta, independently of its location.',
                'All early radii exceed 2, trigger radius is 2 and receiver radii are 1; priorities therefore give the actual shell/lex history, trigger, then receivers.',
                'N=sqrt(n)*a^n is an integer symbolic count. Early count N-1 gives pre-residual (1/2)exp(beta0/t)>1/2 exactly. Trigger is the Nth update and gives residual exactly1/2. Every receiver is bad.',
                'The actual first-hit menu can be pre-fixed at z=0; its pool is all early labels and trigger. Receiver centers have one +d and one -d per active pair, and +3/4 on passive coordinates.',
                'Every first-hit witness must belong to trigger because earlier total coefficient is less than1/2; its passive coordinates are <=1/4. Thus every actual receiver owner point has mandatory passive displacement at least1/2-1/a.',
                'Early cores, trigger core and receiver cores are mutually disjoint; active paired sign patterns have coordinate separation2d>2/a. Therefore all owners may be their full tiny cores.',
                'The partial raw clock e/beta0 is an integer by e/beta0=N-1-J*(a^n-(a-2)^n)/2^m. The sign-restricted shell count is integral since a and a-2 are even and n>=m.',
            ],
            'high_loss_bound_verification':[
                'At every owner point at least k/2 active coordinates are >=d-1/a and k/2 are <=-d+1/a. The floor count is conservative uniformly over all early scales <=R.',
                'Before boundary conditioning, the two active outside counts are independent Binomial(k/2,p0); a union bound costs2*fail. Passive half restriction retains boundary probability W.',
                'Boundary conditioning costs at most1/W, and actual theta tilt within a full layer costs at most exp(W_prime/t). Partial last layer and trigger are omitted only in this lower bound.',
                'If both counts reach m0=floor(3b/16)+1, disjoint prefix/suffix conflict pairs give B>=2*m0*log2>(3/8)*log(n). This is the original high mask with epsilon1/8 and common u=h.',
                'The original near-radius upper includes every early source, as certified by R<2*h*n/log(n). The lower mask therefore bounds the original H at the fixed legal origin menu, for every actual receiver point.',
            ],
            'scope':[
                'Finite families have astronomically many labels and are represented symbolically; no finite array or sampling replaces them.',
                'D formula includes full early history, trigger and all receivers. VT is the entire receiving volume, with factors2^n canceled only in D/VT.',
                'The normalized reported value is the requested upper VT/(4 sqrt(n) D), not a claimed lower bound for the unknown general theorem.',
                'Strict pre-hit comparison follows exactly from beta0>0; a 384-bit interval cannot resolve its tiny difference from1/2.',
                'No files other than family.py and family.json were written by this program.'
            ]}
    output=Path(__file__).with_name('family.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'rows':[{k:r[k] for k in ['b','R','mu','H_lower_all_actual_owner_points','log_D_over_VT','log10_VT_over_4sqrt_n_D','auxiliary_log_product_upper','original_mandatory_log_product_lower']} for r in rows]},indent=2))


if __name__=='__main__':
    main()
