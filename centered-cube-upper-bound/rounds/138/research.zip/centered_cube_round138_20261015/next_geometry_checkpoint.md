# R138 短检查点：分簇不收费于簇数，但仍需容量尾衰减

状态：冻结，供下一步筛查。R138主稿保持不动。本页只用RS1–12、原RC与high/good门；不设ν独立、聚团或距离矩有限。

**1. 可测分簇的准确收益。** 固定实际x,t,v，沿用f(u)=1_Dg·δ(v,u)χ_FAΨ、K_u=K₀(x−u)。任意可数可测划分{E_i}覆盖{f>0}，定义

\[
 c_i=\int_{E_i}K_u\,d\nu(u),\quad
 b_i=\int_{E_i}f(u)^2w_t(u)^2/K_u\,d\nu(u),\quad
 C=\sum_i c_i\le\alpha Q_J/D.
\]

则

\[
 \rho\int f\,d\Pi_t\le\frac\rho{e_t}\sum_i\sqrt{c_i b_i}
 \le\frac\rho{e_t}\sqrt{C\sum_i b_i}. \tag{NG1}
\]

第一式只含同簇(a,u)对，已删除RS12中所有跨簇交叉项；第二式证明没有簇数粗因子。每一簇可用RS5–7的实际近距/硬边界价格。共同ρ保持原值，所有c_i合计只消费一份原容量。代价是：为了用C控制第一式，仍须控制b_i/c_i的容量加权平均；仅把所有簇取得很小，NG1会趋近原∫fwtν/e_t，并不会自动把原score费用变小。

**2. 一项真正可付款的原子支。** 不要求空间聚团，令

\[
 L_\zeta(x,v,t)=\frac{4D\,e_tJ(x-v)}{TA(v)Q_J}\,\zeta,
 \qquad E_{\rm low}=\{f>0:\ f(u)w_t(u)/K_u\le L_\zeta\}.
\]

在A(v)>0、Q_J>0的实际good行，写a_v=(1−DK₀(x−v)/(TA(v)))₊。同一RC给ρ=(a_v−αJ/(TA))₊，因此

\[
 \rho\int_{E_{\rm low}}f\,d\Pi_t
 \le\frac{L_\zeta Q_J}{De_t}\,\rho\alpha
 \le\frac{L_\zeta Q_J}{De_t}\frac{a_v^2TA}{4J}
 =\zeta a_v^2\le\zeta. \tag{NG2}
\]

这是真实低-score、ρFAΨ原子支的点态付款，不是假定其质量小；可将所有满足同一likelihood帽的簇合并一次应用NG2，簇数不出现。它允许任意A/w_g和共同深尾，并非A/w_g窄条带。零行按零处理。积分good Π_t、使用∫_τ^h dt/t≤log2，再用原raw外质量T_small≤4X，signed价格至多8Λζ(log2)X。若计入既有ε账，可令ζ≤ε_slot/(8Λlog2)；本页不另开ε槽、不重复领取硬帽。

NG2的门是实际可测来源likelihood帽。现有几何尚未证明其覆盖正交通的大部分，故它不是全类闭合。

**3. 精确下一命题。** 对余下高likelihood来源，空间近簇本身不足。可先按
ℓ(u)=f(u)wt(u)/K_u的dyadic层E_j={2^jL_ζ<ℓ≤2^{j+1}L_ζ}划分，再在每层内部细分近距簇。若能由原same-x good C_J≤3、H<L₊、inactive及FAΨ证明

\[
 \sum_{E_i\subset E_j}c_i
 \le\frac{\alpha Q_J}{D}\,
 \frac{B\,2^{-j}}{(1+j)^2}\qquad(j\ge0), \tag{NG3}
\]

则逐层直接用∫_{E_j}fwtν≤2^{j+1}L_ζ∑c_i，再一次使用ρ α≤a_v²TA/(4J)，得该高支≤2Bζa_v²∑_{j≥0}(1+j)^{-2}。这是非平凡可求和增益的明确量词与充分结论；容量没有按j复用，因为每层实际c_i互不重叠，NG3控制的是其真实分配。B须有实际外预算，不能当新常数。

当前门尚未给出NG3的容量分配率。inactive只约束低-score坏源的非活动坐标；活动坐标的深度仍可任意大，H<b时wt/K₀在该方向具有正尾指数。C_J(v)≤3约束good端接收硬支持计数，原high只控制整体归一化；二者都没有现成的“bad核容量落在高likelihood层的比例”界。这里不宣称构造了满足全部历史合同的反例，只明确现有推导缺少这项数量联系。

因此近距分簇已严格去掉跨簇假交叉费，NG2已支付一个真实原子支；余下唯一待证是类似NG3的容量加权尾衰减，或其在完整β、time/j/history上的积分版本。未证此项前不把分簇当根阶预算。保留所有原负项身份，到此停止。
