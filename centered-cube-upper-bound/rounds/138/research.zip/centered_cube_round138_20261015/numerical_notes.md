# R138 数值检验笔记

本笔记区分严格保存系数证书与有限浮点核积分，不以有限测试证明一般参数或FULL。

## 核比探针实际结果

|案例|阶段|截断积分（90位计算，表中舍入）|B/(I+尾界)|全部判据|
|---|---|---:|---:|---|
|I1|initial|1.0000000000|1.0000000000|PASS_FLOATING_POINT_PROBE|
|I2|initial|1.0227118535|1.1447817420|PASS_FLOATING_POINT_PROBE|
|I3|initial|2.0555947512|23.247491728|PASS_FLOATING_POINT_PROBE|
|I4|initial|2.0555947512|23.247491728|PASS_FLOATING_POINT_PROBE|
|P1|pressure|625.24889476|8659.0791079|FAIL_OR_UNRESOLVED|
|P2|pressure|669.82067551|12398.693004|PASS_FLOATING_POINT_PROBE|
|P3|pressure|625.24889476|8659.0791079|PASS_FLOATING_POINT_PROBE|
|P4|pressure|669.82067551|12398.693004|FAIL_OR_UNRESOLVED|
|E1|expanded|1.1527924229|3.3768852636|PASS_FLOATING_POINT_PROBE|
|E2|expanded|2.0339465240|3.5797811936|PASS_FLOATING_POINT_PROBE|
|E3|expanded|1.1448542104|3.4002998281|PASS_FLOATING_POINT_PROBE|
|E4|expanded|1.2326701683|6.2309548223|PASS_FLOATING_POINT_PROBE|

固定12例，60/90位，R=128及R+10L；所有核尺度含x/h，积分在硬界和φ分支分段。I1另以精确全质量1核验，未错误要求粗尾上界恰好等于真实尾。解析尾公式来自已证包络；其数值计算及quad误差估计并非向外舍入。

P1/P4仅失败于截断稳定性阈值，差约1.257e−88；浮点误差估计没有覆盖所有算术舍入。两例上界比仍约8659与12399。记录为FAIL_OR_UNRESOLVED，未改门限、未替换案例、未重跑。其余10例通过。最大60/90绝对差7.319e−59，不能将此差称作认证误差。

首次启动缺mpmath，在main之前退出；加入本机既有vendor后启动一次完整数学producer。没有声称首次启动成功。

## 容量模型与独立复核

一次有理producer核验12例、108个赢家cell，72个可行。全部输入是冻结十进制转Fraction，不覆盖原超越系数误差。独立verify_capacity_certificate.py逐cell重建交，验证576条内点约束与质量上确界/可取性。最小输入I1复算与原输出整条相同。

I1上确界可取；另外11例不可取，rho在极限消失。m的极值不是最终正交通极值；硬前因子仍需乘真实rho、来源归一化、时间和接收体积。完整表见capacity_summary.json，精确证书见core_capacity_probe.json。

## 对下一步的实际影响

共同深尾抵消得到证明且有有限检验支持；小soft跨硬界仍可使真实核比积分达到数百，不能删去边界费用。允许CORE质量远大于原10^-300，但严格rho门决定了大多数端点。下一步应保留这个门优化真实交通，不能把最大CORE质量的极限当正流量配置。
