#!/usr/bin/env python3
"""One-shot floating-point probe for the frozen R138 pair-kernel menu."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

VENDOR = Path("/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor")
sys.path.insert(0, str(VENDOR))
import mpmath as mp

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "pair_kernel_probe.json"
PROTOCOL = ROOT / "pair_kernel_protocol.md"
R135_PHI_SOURCE = Path("/Users/zhengzhihao/Desktop/T/output/centered_cube_round135_20261014/real_joint_numeric.py")
PROTOCOL_SHA256 = "25f2ae10763a7088398505b863e9dd627b5c29f16ae98db6f04363d6d8c8aefe"
mp.mp.dps = 100
R = mp.mpf(128)
TAIL_TARGET = mp.mpf("1e-35")
A0 = 2 * mp.sqrt(mp.e)
L_PHI = 15 * mp.e / 4

MENU = [
    ("initial", "I1", ".50", ".75", ".75", "0", "0"),
    ("initial", "I2", ".50", ".75", ".75", "0", ".01"),
    ("initial", "I3", ".50", ".75", ".75", "0", ".25"),
    ("initial", "I4", ".50", ".75", ".75", "0", "-.25"),
    ("pressure", "P1", ".01", ".50", ".50", "0", ".49"),
    ("pressure", "P2", ".01", ".50", ".50", "0", ".51"),
    ("pressure", "P3", ".01", ".50", ".50", "0", "-.49"),
    ("pressure", "P4", ".01", ".50", ".50", "0", "-.51"),
    ("expanded", "E1", ".25", ".75", ".75", "10", "10.1"),
    ("expanded", "E2", ".25", ".75", ".75", "0", ".1"),
    ("expanded", "E3", ".25", ".75", ".75", "50", "50.1"),
    ("expanded", "E4", ".25", "1", ".5", "-10", "-10.1"),
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def enc(x):
    if isinstance(x, mp.mpf):
        return mp.nstr(x, n=mp.mp.dps)
    if isinstance(x, dict):
        return {str(k): enc(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)):
        return [enc(v) for v in x]
    return x


def expint(k: int, z: mp.mpf) -> mp.mpf:
    if z == 0:
        return mp.mpf(1) / (k - 1)
    return mp.expint(k, z)


# Transcribed from R135 real_joint_numeric.py:17-24; not imported as a module.
def phi(x: mp.mpf) -> mp.mpf:
    r = abs(mp.mpf(x))
    half = mp.mpf(".5")
    if r <= half:
        return 1 - expint(3, half - r) - expint(3, half + r)
    return expint(3, r - half) - expint(3, r + half)


# Transcribed from R135 real_joint_numeric.py:25-29.
def phi_primitive(x: mp.mpf) -> mp.mpf:
    x = mp.mpf(x)
    if x < 0:
        return -phi_primitive(-x)
    half = mp.mpf(".5")
    if x <= half:
        return x - expint(4, half - x) + expint(4, half + x)
    return half - expint(4, x - half) + expint(4, x + half)


def phi_mass(a: mp.mpf, b: mp.mpf) -> mp.mpf:
    return phi_primitive(b) - phi_primitive(a)


def p_density(s: mp.mpf, scale: mp.mpf, x: mp.mpf) -> mp.mpf:
    r = x / scale
    hard = 1 if abs(r) <= mp.mpf(".5") else 0
    return ((1 - s) * hard + s * phi(r)) / scale


def p_mass(s: mp.mpf, scale: mp.mpf, a: mp.mpf, b: mp.mpf) -> mp.mpf:
    lo, hi = min(a, b), max(a, b)
    hard_len = max(mp.mpf(0), min(hi, scale / 2) - max(lo, -scale / 2))
    return (1 - s) * hard_len / scale + s * phi_mass(lo / scale, hi / scale)


def kernel(s: mp.mpf, scale: mp.mpf, x: mp.mpf) -> mp.mpf:
    return p_density(s, scale, x)


def set_difference_mass(s: mp.mpf, L: mp.mpf, A, U) -> tuple[mp.mpf, mp.mpf]:
    a0, a1 = A
    u0, u1 = U
    il, ir = max(a0, u0), min(a1, u1)
    overlap = p_mass(s, L, il, ir) if il < ir else mp.mpf(0)
    return p_mass(s, L, a0, a1) - overlap, p_mass(s, L, u0, u1) - overlap


def breakpoints(L: mp.mpf, H: mp.mpf, a: mp.mpf, u: mp.mpf, Rloc: mp.mpf):
    pts = {-Rloc, Rloc}
    for x in (-L / 2, L / 2, a - H / 2, a + H / 2, u - H / 2, u + H / 2):
        if -Rloc < x < Rloc:
            pts.add(x)
    return sorted(pts)


def integrate_case(s, L, H, a, u, Rloc, dps):
    mp.mp.dps = dps
    pts = breakpoints(L, H, a, u, Rloc)

    def f(x):
        p = p_density(s, L, x)
        ka = kernel(s, H, x - a)
        ku = kernel(s, H, x - u)
        return p * ka / ku

    total = mp.mpf(0)
    reported_err = mp.mpf(0)
    for left, right in zip(pts[:-1], pts[1:]):
        val, err = mp.quad(f, [left, right], error=True)
        total += val
        reported_err += abs(err)
    return total, reported_err


def tail_bound(s, L, H, a, u, Rloc):
    exponent = L_PHI * abs(a - u) / H
    return mp.exp(exponent) * 2 * s * A0 * mp.exp(-Rloc / L) / (1 + Rloc / L)


def sampled_ratio_range(s, L, H, a, u, Rloc):
    points = set(breakpoints(L, H, a, u, Rloc))
    # Diagnostic grid only; it is not used to certify the integral.
    count = 2001
    for i in range(count + 1):
        points.add(-Rloc + 2 * Rloc * i / count)
    vals = []
    for x in points:
        ku = kernel(s, H, x - u)
        vals.append(kernel(s, H, x - a) / ku)
    return min(vals), max(vals)


def write_state(state):
    OUT.write_text(json.dumps(enc(state), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    if OUT.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {OUT}")
    protocol_hash = sha256(PROTOCOL)
    if protocol_hash != PROTOCOL_SHA256:
        raise RuntimeError(f"frozen protocol hash mismatch: expected {PROTOCOL_SHA256}, got {protocol_hash}")
    source_hash = sha256(R135_PHI_SOURCE)
    state = {
        "status": "running",
        "run_count": 1,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "scope": "12 fixed one-dimensional pair-kernel cases only; numerical evidence, no lemma certification",
        "protocol_sha256": protocol_hash,
        "r135_phi_source_sha256": source_hash,
        "phi_source_path": str(R135_PHI_SOURCE),
        "python_mpmath": mp.__version__,
        "precision_dps": [60, 90],
        "R": "128",
        "tail_threshold": "1e-35",
        "quadrature_error_note": "mpmath quad(error=True) estimates are heuristic and are not certified error bounds",
        "startup_failures_before_producer": [
            {
                "attempt": 1,
                "command": "python3 output/centered_cube_round138_20261015/pair_kernel_probe.py",
                "error": "ModuleNotFoundError: No module named 'mpmath'",
                "note": "Interpreter failed before main() and before creating the result artifact; rerun uses the existing R135 vendor dependency path.",
            }
        ],
        "cases": [],
        "exceptions": [],
    }
    write_state(state)
    for stage, cid, st, Lt, Ht, at, ut in MENU:
        case = {"stage": stage, "id": cid, "input": {"y": "0", "s": st, "L": Lt, "H": Ht, "a": at, "u": ut}}
        try:
            # Derive all case quantities at 90 dps before the two requested integration passes.
            mp.mp.dps = 90
            s, L, H, a, u = map(mp.mpf, (st, Lt, Ht, at, ut))
            RA = (a - H / 2, a + H / 2)
            RU = (u - H / 2, u + H / 2)
            pplus, pminus = set_difference_mass(s, L, RA, RU)
            phi_half = phi(mp.mpf(".5"))
            G = 1 + (1 - s) / (s * phi_half)
            bracket = 1 + (G - 1) * pplus - (1 - 1 / G) * pminus
            rhs = mp.exp(L_PHI * abs(a - u) / H) * bracket
            tail_R = tail_bound(s, L, H, a, u, R)
            R2 = R + 10 * L
            tail_R2 = tail_bound(s, L, H, a, u, R2)
            p_mass_R = p_mass(s, L, -R, R)
            exact_p_tail_R = 1 - p_mass_R
            tail_ok = tail_R <= TAIL_TARGET and tail_R2 <= TAIL_TARGET

            if cid == "I1" and a != u:
                raise AssertionError("I1 is not the frozen zero-distance case")
            if not tail_ok:
                raise AssertionError("fixed protocol truncation tail bound exceeds 1e-35")

            ints = {}
            for Rname, Rloc in (("R", R), ("R_plus_10L", R2)):
                ints[Rname] = {}
                for dps in (60, 90):
                    value, qerr = integrate_case(s, L, H, a, u, Rloc, dps)
                    ints[Rname][str(dps)] = {"integral": value, "quadrature_error_estimate": qerr}

            mp.mp.dps = 90
            ratio_min, ratio_max = sampled_ratio_range(s, L, H, a, u, R)
            val60 = ints["R"]["60"]["integral"]
            val90 = ints["R"]["90"]["integral"]
            err60 = ints["R"]["60"]["quadrature_error_estimate"]
            err90 = ints["R"]["90"]["quadrature_error_estimate"]
            val_plus = ints["R_plus_10L"]["90"]["integral"]
            err_plus = ints["R_plus_10L"]["90"]["quadrature_error_estimate"]
            precision_diff = abs(val90 - val60)
            stability_diff = abs(val_plus - val90)
            scale = max(mp.mpf(1), abs(val90))
            precision_tol = max(mp.mpf("1e-45") * scale, 10 * (err60 + err90))
            stability_tol = tail_R + tail_R2 + 10 * (err90 + err_plus)
            ratio_lo = rhs / (val90 + tail_R)
            ratio_with_err = rhs / (val90 + tail_R + err90)

            if cid == "I1":
                # I1 is checked against the exact full normalization, never by I_R+T_R <= 1.
                normalization_diff = abs(val90 - p_mass_R)
                exact_tail_in_bound = (exact_p_tail_R >= 0 and exact_p_tail_R <= tail_R)
                compare_ok = exact_tail_in_bound and normalization_diff <= max(10 * err90, mp.mpf("1e-45"))
                zero_identity = {"integrand_ratio_identically_one": True, "exact_full_integral": "1", "exact_rhs": "1"}
            else:
                normalization_diff = None
                exact_tail_in_bound = None
                compare_ok = val90 + tail_R + err90 <= rhs
                zero_identity = None

            p_nonnegative = pplus >= 0 and pminus >= 0
            bracket_positive = bracket > 0
            precision_ok = precision_diff <= precision_tol
            stability_ok = stability_diff <= stability_tol
            passed = bool(tail_ok and p_nonnegative and bracket_positive and precision_ok and stability_ok and compare_ok)
            case.update({
                "phi_half": phi_half,
                "G": G,
                "Pplus": pplus,
                "Pminus": pminus,
                "bracket": bracket,
                "rhs_bound": rhs,
                "tail_bound_R": tail_R,
                "tail_bound_R_plus_10L": tail_R2,
                "tail_target_met": tail_ok,
                "p_mass_R": p_mass_R,
                "exact_p_tail_mass_R": exact_p_tail_R,
                "integrals": ints,
                "precision_difference_R": precision_diff,
                "precision_tolerance_heuristic": precision_tol,
                "stability_difference_90dps": stability_diff,
                "stability_tolerance_heuristic": stability_tol,
                "mpmath_quadrature_errors_certified": False,
                "ratio_sample_diagnostic_only": {"min": ratio_min, "max": ratio_max},
                "bound_to_integral_ratio": ratio_lo,
                "bound_to_integral_plus_error_ratio": ratio_with_err,
                "normalization_difference_I1_only": normalization_diff,
                "exact_tail_in_analytic_bound_I1_only": exact_tail_in_bound,
                "zero_distance_identity_I1_only": zero_identity,
                "checks": {
                    "Pplus_Pminus_nonnegative": p_nonnegative,
                    "bracket_positive": bracket_positive,
                    "tail_bound_at_most_1e-35": tail_ok,
                    "60_90_precision_consistency_heuristic": precision_ok,
                    "R_Rplus10L_stability_heuristic": stability_ok,
                    "comparison": compare_ok,
                },
                "status": "PASS_FLOATING_POINT_PROBE" if passed else "FAIL_OR_UNRESOLVED",
            })
        except Exception as exc:  # Preserve every failed case in the single result artifact.
            case["status"] = "EXCEPTION"
            case["exception"] = f"{type(exc).__name__}: {exc}"
            state["exceptions"].append({"id": cid, "exception": case["exception"]})
        state["cases"].append(case)
        state["completed_cases"] = len(state["cases"])
        write_state(state)
        print(f"{cid}: {case['status']}", flush=True)

    statuses = [case["status"] for case in state["cases"]]
    state["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    state["status"] = "COMPLETE_WITHOUT_CASE_FAILURES" if len(statuses) == 12 and all(s == "PASS_FLOATING_POINT_PROBE" for s in statuses) else "COMPLETE_WITH_FAILURES_OR_UNRESOLVED"
    state["summary"] = {"cases": len(statuses), "passed": sum(s == "PASS_FLOATING_POINT_PROBE" for s in statuses), "failed_or_unresolved": len(statuses) - sum(s == "PASS_FLOATING_POINT_PROBE" for s in statuses)}
    write_state(state)
    print(json.dumps(state["summary"], ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
