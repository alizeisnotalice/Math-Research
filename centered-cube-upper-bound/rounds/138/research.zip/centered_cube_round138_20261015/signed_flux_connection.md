# R138：保留 Ψ 的 signed 通量连接与差项

状态：先写准确命题，再推导。只读 R128 RT1--4 与 R122 后缀原定义；不将 pair Ψ 改为 source 门，不复用已消费 N_Z，不改其他文件、不操作 Git/PDF。目标仍为原中间硬层的统一外预算。

## 1. 准确对象与候选

固定完整实际行 r、实际 g、终端存活分割 \(Z_g=S_g\sqcup D_g\) 与**完整原后缀窗** J=[τ,h]。原 \(Z_g\subset Z_t\)，\(e_t=\int_{Z_t}w_t\nu>0\)，\(d\Pi_t=1_{Z_t}w_t\nu/e_t\)，且 \(k_t=-d\log w_t/d\log t\)。ν 可任意相关，各坐标阈值不同。若另有删取子窗，必须保留原窗指示及端点，且不能继续断言 SF6 的 L_Z 非负；逐子窗重新定义 Ψ 会改变原门，本稿不这样做。

对 \((v,u)\in S_g\times D_g\)，固定原 pair 门
\[
 F_{v,u}(r')=\int_{r'}^h(k_t(v)-k_t(u))w_t(v)w_t(u)\frac{dt}{t},
 \qquad \Psi(v,u)=1_{\{\exists r':F_{v,u}(r')>0\}}.
\tag{SF1}
\]
这是未归一后缀，不含 e_t、ρ 或 FA。正端因子为 \(b_t(v,u)=\rho_r(v)\chi_{FA}(t;v,u)\in[0,1]\)，负端原样保留。行内存活 signed 余项为
\[
 T_r=\int_J\iint_{S_g\times D_g}\Psi
 \{b_t(k_v-k_u)_+-(k_u-k_v)_+\}\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}.
\tag{SF2}
\]
其实际 signed 母式还减原 \(N_{del,r}\)，并乘 \(2\Lambda\) 与完整原外行测度。

候选：不含 Ψ 的全存活通量能由 bad 后验占比的端点差计价；含 Ψ 时必须另保留已删非正后缀区域的失去抵消量，以及未来删源与正门抑制的差项。是否这些差项能由原 RC/FA 共同支付，是本稿要检验的连接，不能预先假定。

## 2. 精确后验通量：删源贡献必须在内

适用的有限/BV条件明确为：ν 有限，原 \(0<w_t\le1\)，\(0<\tau<h<\infty\)，e_t≥e_g>0，Z_t 随时间非增并取相容右连续版本；来源/外行截断不得把完整后缀窗擅自剪成任意时间子集。于是 e_t 与其倒数在该窗为有限 BV 函数，终端来源质量 W_D/W_S 为 AC；固定行 score≤n、时间对数长度有限，使本稿各 signed 来源积分绝对可积，换序与 BV 乘积式合法。若不具备这些条件，只能保留原截断代数，不声称完整窗符号或端点预算。

令 \(U_t=Z_t\setminus Z_g\)，并写
\[
 W_D(t)=\int_{D_g}w_t\nu,\quad W_S(t)=\int_{S_g}w_t\nu,
 \quad W_U(t)=\int_{U_t}w_t\nu,
\]
\[
 K_D(t)=\int_{D_g}k_tw_t\nu,\quad
 K_S(t)=\int_{S_g}k_tw_t\nu,\quad
 K_U(t)=\int_{U_t}k_tw_t\nu.
\]
于是 e_t=W_D+W_S+W_U。D_g/S_g 为终端存活来源，W_D/W_S 连续且几乎处处 \(dW_D=-K_Dd\log t\)。原删源资格非增；在合法有限截断的 BV/右连续版本，定义倒数归一化的删除增量
\[
 d\Gamma_{del}(t):=d(e_t^{-1})
 -\frac{K_D+K_S+K_U}{e_t^2}d\log t\ge0.
\tag{SF3}
\]
该非负测度包含删除的连续/奇异部分；跳时含 \(e_{t+}^{-1}-e_{t-}^{-1}\)。只用连续导数而漏掉这些跳项不成立。令实际 bad 后验占比 \(d_t=W_D(t)/e_t=\Pi_t(D_g)\in[0,1]\)。乘积法则给
\[
 dd_t=(C_{SD}(t)+C_{UD}(t))d\log t+W_D(t)d\Gamma_{del}(t),
\tag{SF4}
\]
其中
\[
 C_{SD}=\iint_{S_g\times D_g}(k_v-k_u)d\Pi_t(v)d\Pi_t(u)
 =\frac{W_DK_S-W_SK_D}{e_t^2},
\]
\[
 C_{UD}=\iint_{U_t\times D_g}(k_v-k_u)d\Pi_t(v)d\Pi_t(u)
 =\frac{W_DK_U-W_UK_D}{e_t^2}.
\]
这些等式对任意相关 ν 成立：分解的是同一两份 Π_t 的线性积分，不是来源坐标张量化。积分后
\[
 \boxed{\int_\tau^h C_{SD}(t)\frac{dt}{t}
 =d_h-d_\tau-J_{del}-\int_\tau^h C_{UD}(t)\frac{dt}{t},}
 \qquad J_{del}=\int_{(\tau,h]}W_Dd\Gamma_{del}\ge0.
\tag{SF5}
\]
端点与右连续版本一致。无未来删源时 U=∅、Γ=0，才得到端点差；如果 e_t 含未来删除来源，不能直接把存活 good 占比导数当成完整 C_SD。

这里没有重复证明或套用一个总变差预算。SF5 是单一完整行的准确 signed 恒等式，端点差本身至多1；它还带有原未来配对项。若 J 是非初始任意子窗，应保留所有子窗端点和 Γ 积分，不能免费合并成一个至多1的端点。

## 3. 真实 Ψ 与正门的精确差项

记 \(C_\Psi(t)=\iint_{S_g\times D_g}\Psi(k_v-k_u)d\Pi_t^2\)，并定义
\[
 L_Z:=-\int_\tau^h\iint_{S_g\times D_g}
 (1-\Psi)(k_v-k_u)d\Pi_t^2\frac{dt}{t},
\]
\[
 G_{\rho FA}:=\int_\tau^h\iint_{S_g\times D_g}
 \Psi(1-\rho\chi_{FA})(k_v-k_u)_+
 d\Pi_t^2\frac{dt}{t}\ge0.
\tag{SF6}
\]
对每个 \(1-\Psi=1\) 的 pair，原全部未归一后缀 F≤0；e_t^{-2}非减，R122 的 Stieltjes 等式给该 pair 的全 signed 积分≤0。对 ν² 积分得到 L_Z≥0。真实正端抑制则恰给

此 L_Z≥0 的结论仅对完整 \([\tau,h]\) 成立。沿任意删取子窗积分时，即使保留相同 pair 与原 Ψ，也不能保持这个符号；不能以原后缀全非正推断每个子窗 signed 积分非正。若逐子窗重新定义 Ψ，则已不是原门，不能用于当前负项账。
\[
 \boxed{T_r=\int_\tau^h C_{SD}\frac{dt}{t}+L_Z-G_{\rho FA}.}
\tag{SF7}
\]
如果当前正项还删去先前已付的不交子支，实际 T_r 只会更小，SF7 对本节定义对象仍准确并给实际对象合法上界。

L_Z 是移除非正后缀 pair 后失去的抵消，而不是新可消费负项。已经用于丢弃原 Z 区域的 N_Z 不能为了 SF7 再放回来。\(\Psi\) 依赖两个来源及整段未来后缀，不能将其改成 source 门、或从 \(\delta_t>0\) 推断它等于1。

R134 的低面积付款与 R137 的 high/FIRST 分数幂接口可以合法用于上界某些实际正项；它们没有自动给 \(L_Z\le G_{\rho FA}\)。这个连接需要控制**跨 pair 域**的失去抵消与真实正门抑制。给 G 的正项一个上界也不是这项连接所需的下界。

## 4. 与原 N_del 的配对范围及一次性负账

把未来来源的完整未截门 signed 流写成
\[
 P_U^+=\int_J\iint_{U_t\times D_g}(k_v-k_u)_+d\Pi_t^2\frac{dt}{t},
\]
\[
 N_U^-=\int_J\iint_{U_t\times D_g}(k_u-k_v)_+d\Pi_t^2\frac{dt}{t}.
\tag{SF8}
\]
则 \(\int C_{UD}d\log t=P_U^+-N_U^-\)。结合 SF5--7，行内原槽具有明确差项表达
\[
 \boxed{T_r-N_{del,r}
 =d_h-d_\tau-J_{del}-P_U^+
 +L_Z-G_{\rho FA}+(N_U^--N_{del,r}).}
\tag{SF9}
\]
若原 N_del 恰与 SF8 的完整未来 pair 域、窗口及 history 资格相同，可在 SF9 中只抵消一次；若其资格更小或不同，必须保留括号中的域差项。RT2 仅引用 N_del 的原定义而未写其全公式，本稿不凭名称推断域一致，也没有给它追加 ρ、FA 或 Ψ。

SF9 是诊断恒等式，不作为已付新预算。剩余域匹配义务包括原未来来源 U_t、同一 D_g、完整后缀时间窗、两份 Π_t、原 history/删源资格与原 signed 外系数逐项一致；该义务未在本稿中解除。

尤其，不能先用 N_del 得到无 Ψ 的端点支付，再把 N_del 作为额外负项减第二次。也不能以 SF9 的 L_Z 名称领取原 N_Z；当前存活负项 N_Zc 已在 SF2 中完整出现一次，未来删除负项也仅保留原 N_del 一次。

在已确认未来负域匹配的情形，删除增量 J_del 与 P_U^+ 均非负且在上界中可合法舍去，故
\[
 T_r-N_{del,r}\le(d_h-d_\tau)+L_Z-G_{\rho FA}.
\tag{SF10}
\]
它将无门 signed 时间部分的 score 费用转为一个端点差；但实际 Ψ 流的剩余是 L_Z−G，不是免费常数。此无门端点事实属于已有基本 flux，不登记为新预算；本稿新增核对是当前 Ψ/ρFA/删源账中的具体差项。

## 5. 真实外测度与能减少费用的连接义务

所有 SF 身份逐个实际行成立。恢复原 raw 外测度
\[
 d\mathcal T_I=q^{-1}p(x,y)h_R(x-z)
 a_{history}\,dx\,d\beta(y)d\nu(z)
\]
及期望、唯一 j/种子/history 后，SF9 给
\[
\begin{split}
 2\Lambda(P_I^{rem}-N_{I,Z^c}-N_{I,del})
 \le2\Lambda\mathbb E\sum_{V,j}\int1_{A_{hi}}d\mathcal T_I\,
 \{d_h-d_\tau-J_{del}-P_U^+
 +L_Z-G_{\rho FA}+N_U^--N_{del,r}\}.
\end{split}
\tag{SF11}
\]
当本节 SF2 正项与原当前余项完全相同时为等式；先前正子支已不交删除时为上述上界。真实 x、s/L/R/g 选择器、硬 z、β−ν、q、时间及全部原资格未替换。若走 SI5 的硬来源先积分形式才带其16/3，不能与这里 raw 外测度叠加收费。

仅把端点差用1上界，再套 \(T_{small}\le4X\)，给的是 \(8\Lambda X\) 粗价格，不能当作允许的任意 \(\varepsilon X\)，也不是 \(\sqrt n\operatorname{polylog}(n)W_\beta\)。要让 SF11 真正减少本轮实际费用，至少需要一个已验证的共同连接：原实际核/history 使 \(L_Z-G_{\rho FA}\)（以及未匹配的未来负域差）有可吸收外价，或使端点增量与这些差项联合运输到 Wβ。该连接需要在同一个真实外积分中证明，不能分别按不同删门对象领取 α/FIRST 或 N_Z。

原 RC 容量控制已付捕获部分的**上界**，不直接提供 G_ρFA 在另一 pair 域抵消 L_Z 的下界。R137 的 \(Q_J/e_t\le p/(2K)\) 可以支付正项估计里的来源整体分数幂，但不能使 pair-dependent Ψ 变成源 cut，不能控制 L_Z，也不能证明端点增量小。R134 FT 的已付低面积子层若从正项删除，只是改变 SF6 的正端抑制量；未消费负项仍原位，不能同时再领取同一个低面积或负项额度。

## 6. 具体障碍与结论

本次获得的合法连接是 SF9--11：score 的完整 signed 时间费准确分为 bad 后验端点、删除的有利增量、未来来源通量、Ψ 失去的抵消和原正门抑制。它让未来负项的匹配范围及需比较的 pair 域具体可查；没有以一个未付矩的新名称宣称一般进展。

没有得到新的统一付款，原因具体为：

- Ψ 由固定 pair 的全部未归一后缀决定，不能代入单个 source 占比导数；它新增的 L_Z 是已经丢弃的非正 pair 流的大小，原 N_Z 已消费。
- G_ρFA 处于 Ψ pair 域而 L_Z 处于其补域；已知正门或捕获容量没有证明跨域配对支配。只给它们分别上界不能产生所需抵消。
- 真正删除使归一化和未来来源通量共同变化；只有核对原 N_del 的全部域后才能一次抵消 SF8 的未来负部，不可省略此条件。
- 端点粗价仍乘原 X。没有新的接收/β 几何把它和残留差项支付为允许 εX 与根阶 Wβ，也没有免费连续参数或跨 j 望远镜。

因此这里的精确 flux 检查不闭合一般中间硬层。原负项 N_Zc/Ndel 各一次且不附正门，旧费不返还；未构造反例菜单、未新增数值或重复历史总变差定理。交付后停止。
