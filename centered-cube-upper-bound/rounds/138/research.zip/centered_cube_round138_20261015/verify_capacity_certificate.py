#!/usr/bin/env python3
"""Independent verifier of saved affine rational certificates (not kernel enclosures)."""
from pathlib import Path
from fractions import Fraction as F
import json, sys
sys.set_int_max_str_digits(0)
def q(z): return F(int(z['numerator']),int(z['denominator']))
def verify(path):
 d=json.loads(Path(path).read_text()); counts={'cases':0,'cells':0,'feasible':0,'endpoint_constraints':0}
 for row in d['cases']:
  assert row['status']=='certified_saved_coefficients'
  constraints=row['constraints']; uppers=[]; attained=[]
  for cell in row['winner_cells']:
   counts['cells']+=1
   lows=[]; highs=[]; impossible=False
   for name in cell['constraint_names']:
    c=constraints[name]; a,b=q(c['slope']),q(c['intercept']); strict=c['strict']
    if a==0:
     impossible |= b<0 or (strict and b==0)
    elif a>0: lows.append((-b/a,strict))
    else: highs.append((-b/a,strict))
   lo=max(x[0] for x in lows); hi=min(x[0] for x in highs)
   lop=any(s for x,s in lows if x==lo); hip=any(s for x,s in highs if x==hi)
   possible=not impossible and (lo<hi or lo==hi and not lop and not hip)
   assert (lo,hi,lop,hip,possible)==(q(cell['lower']),q(cell['upper']),cell['lower_open'],cell['upper_open'],cell['feasible'])
   if possible:
    counts['feasible']+=1; uppers.append(hi); attained.append((hi,not hip))
    p=q(cell['interior_point'])
    for name in cell['constraint_names']:
     c=constraints[name]; val=q(c['slope'])*p+q(c['intercept'])
     assert val>0 if c['strict'] else val>=0
     counts['endpoint_constraints']+=1
  sup=max(uppers); assert sup==q(row['mass_supremum'])
  assert any(v==sup and closed for v,closed in attained)==row['supremum_attained']
  for field in ['feasible_interior','supremum_limit','reference']:
   point=row[field]; m=q(point['m']); tests={}
   for name in ['Q0','QJ','Qstar']:
    a=row['affine_coefficients'][name]; tests[name]=q(a['slope'])*m+q(a['intercept'])
   Q=max(tests.values()); assert Q==q(point['q'])>0
   assert m/Q==q(point['m_over_q'])
   assert q(row['parameters']['p'])*m/Q==q(point['p_m_over_q'])
  counts['cases']+=1
 assert counts['cases']==12 and counts['cells']==108 and counts['feasible']==72
 return {'status':'PASS','scope':'exact stored-coefficient half-line intersections only; not transcendental or FULL certification',**counts}
if __name__=='__main__':
 p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('core_capacity_probe.json')
 print(json.dumps(verify(p),indent=2))
