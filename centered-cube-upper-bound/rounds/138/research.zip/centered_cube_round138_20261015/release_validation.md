# R138 复现、核验与归档边界

环境：Python 3；mpmath 1.3.0（本机已有vendor）。Python标准库Fraction负责容量证书，mpmath只用于显示；新核积分采用mpmath高精度浮点，非向外舍入库。

解压后可执行：

```
python3 verify_capacity_certificate.py
python3 replay.py capacity /一个尚不存在的输出目录
python3 replay.py kernel /另一个尚不存在的输出目录
```

需保证当前Python可导入mpmath。producer保留原运行时路径与SHA，便携入口仅重设最小输入/来源文件位置和输出，不改公式/菜单。输入最小化只删未读取字段，全部保留值与R136原120位存储值相同。完整原输入SHA记录在capacity_input_minimal.json。便携重跑的input SHA会对应这个精简文件，历史producer记录仍绑定完整原输入。

主代理实际完成：独立验证全部108个容量cell及576条可行内点约束；最小输入I1整条case与原完整输入producer输出完全相同；数学作者稿与LaTeX经独审。未重跑旧R136核积分；未编译PDF。

新核producer首次启动缺少mpmath、未进入main；补现有vendor后才开始数学计算。原始协议判据不在结果出现后修改，失败照录。解析尾上界仅控制截断外部分；mpmath quad误差估计不控制所有浮点舍入，多精度一致也非严格数值证书。

包内详细证明、审计、协议、必要代码/完整容量证书/核探针数据与最小输入为本轮白名单；旧用户参考文本已在R137包中，不重复上传。使用SHA清单检查字节身份不等于数学验收。没有已付槽重复领取，没有通过有限数据认定一般阶数。

归档完成时另记CRC、manifest、Python语法、LaTeX显示数学配对、文件大小及Git同步状态。

最终归档核验：所有Python文件AST解析通过；LaTeX显示数学及proof环境配对检查通过；未编译PDF。全部白名单文件以SHA-256列入manifest，压缩包成员CRC与manifest逐项核验。Git提交/推送状态以本轮仓库README及主线程确认结果为准。
