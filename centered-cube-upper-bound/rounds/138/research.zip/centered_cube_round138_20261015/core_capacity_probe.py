#!/usr/bin/env python3
"""Exact affine interval certificates for saved coefficients, no old producer."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,datetime,traceback
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
OUT=ROOT/'core_capacity_probe.json'
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=90
REFERENCE=F(1,10**300)
LABELS=['Q0','QJ','Qstar']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def frac(x):return F(str(x))
def fj(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
def ff(x):return mp.mpf(x.numerator)/x.denominator
def display(x):return mp.nstr(ff(x),15)
def affine_json(line):return dict(slope=fj(line[0]),intercept=fj(line[1]))
def plus(a,b):return (a[0]+b[0],a[1]+b[1])
def times(x,a):return (x*a[0],x*a[1])
def subtract(a,b):return plus(a,times(F(-1),b))
def at(line,m):return line[0]*m+line[1]
def save(x):OUT.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def intersect(named):
 lo=None;hi=None;lo_open=False;hi_open=False;constant_fail=[];flat=[];bounds=[]
 for name,(a,b,strict) in named:
  if a==0:
   if b<0 or (b==0 and strict):constant_fail.append(name)
   if b==0 and not strict:flat.append(name)
   continue
  root=-b/a;kind='lower' if a>0 else 'upper';bounds.append((name,kind,root,strict))
  if a>0:
   if lo is None or root>lo:lo=root;lo_open=strict
   elif root==lo:lo_open=lo_open or strict
  else:
   if hi is None or root<hi:hi=root;hi_open=strict
   elif root==hi:hi_open=hi_open or strict
 assert lo is not None and hi is not None
 empty=bool(constant_fail) or lo>hi or (lo==hi and (lo_open or hi_open))
 record=dict(feasible=not empty,lower=fj(lo),upper=fj(hi),lower_open=lo_open,upper_open=hi_open,lower_display=display(lo),upper_display=display(hi),lower_active=[name for name,kind,r,s in bounds if kind=='lower' and r==lo],upper_active=[name for name,kind,r,s in bounds if kind=='upper' and r==hi],flat_equalities=flat,constant_failure=constant_fail,empty_reason='constant constraint contradiction' if constant_fail else 'reversed bounds' if lo>hi else 'excluded singleton' if empty else None,constraint_names=[name for name,_ in named])
 if not empty:
  point=(lo+hi)/2
  assert all(a*point+b>0 if strict else a*point+b>=0 for _,(a,b,strict) in named)
  record['interior_point']=fj(point)
 return record,lo,hi,lo_open,hi_open,empty

def calc(case):
 atoms=case['atoms'];assert [a['name'] for a in atoms]==['G1','G2','G3','G4','B','CORE']
 dt=case['derived'];pa=case['parameters'];n=case['n'];assert n%2==0
 p,K,D,T,ell,cj,g=[frac(x) for x in [dt['p'],pa['K'],pa['D'],dt['T'],dt['ell'],dt['cj'],dt['g']]]
 fixed=[frac(a['nu']) for a in atoms[:4]];f0=1-sum(fixed)
 U=[];kernels={};Udiff=[]
 for a in atoms:
  A=frac(a['A']);k0=frac(a['K0']);uv=min(T*A,D*k0) if a['good'] and A>0 else F(0)
  U.append(uv);Udiff.append(dict(name=a['name'],rebuilt=fj(uv),saved=fj(frac(a['U'])),difference=fj(uv-frac(a['U']))))
 def line(values):return (values[5]-values[4],sum(fixed[i]*values[i] for i in range(4))+f0*values[4])
 for label,field in [('Q0','K0'),('QJ','J'),('Qstar','Q')]:kernels[label]=line([frac(a[field]) for a in atoms])
 eg=line([frac(a['wg']) for a in atoms]);utotal=line(U)
 W=ell*cj**(-n//2)*g**n
 # All noncore positions must be outside the R=1 hard carrier.
 assert all(any(abs(frac(x))>F(1,2) for x in a['position']) for a in atoms[:5])
 assert all(frac(x)==0 for x in atoms[5]['position'])
 candidates=[];excluded=[]
 for i,a in enumerate(atoms):
  A=frac(a['A']);remainder=T*A-U[i]
  witness=[]
  for si,seg in enumerate(case['score_segments']):
   lo,hi=frac(seg['lo']),frac(seg['hi'])
   if lo>=hi:continue
   kv=sum(frac(al)**2<lo*hi for al in a['thresholds'])
   for j,z in enumerate(atoms):
    if not z['bad']:continue
    kz=sum(frac(al)**2<lo*hi for al in z['thresholds'])
    if kv>kz:
     positive_mass=(j<4 and fixed[j]>0) or j==4 or j==5
     if positive_mass:
      prior=next((q for q in case['pairs'] if q['v']==a['name'] and q['z_prime']==z['name']),None)
      witness.append(dict(segment_index=si,lo=fj(lo),hi=fj(hi),kv=kv,kz=kz,delta=kv-kz,bad=z['name'],bad_mass_condition='fixed positive' if j<4 else 'far positive constraint' if j==4 else 'core positive constraint',prior_FA_Psi_pair_positive=bool(prior and frac(prior['integrals']['rho_FA_Psi_delta'])>0)))
  # In this frozen menu candidate good endpoints have fixed eps mass.
  qualifies=a['good'] and A>0 and remainder>0 and bool(witness) and i<4 and fixed[i]>0
  if qualifies:candidates.append(dict(index=i,name=a['name'],C=(remainder/frac(a['J'])),witness=witness))
  else:excluded.append(dict(name=a['name'],good=a['good'],A_positive=A>0,TA_minus_U_positive=remainder>0,has_delta_witness=bool(witness),fixed_eps_good=i<4))
 constraints={'m_positive':(F(1),F(0),True),'far_positive':(F(-1),f0,True)}
 for winner in LABELS:
  Qi=kernels[winner]
  for other in LABELS:
   if other!=winner:
    a,b=subtract(Qi,kernels[other]);constraints[f'{winner}>={other}']=(a,b,False)
  a,b=subtract(times(p,eg),times(2*K,Qi));constraints[f'{winner}:high']=(a,b,False)
  a,b=subtract(eg,times(W,Qi));constraints[f'{winner}:heavy']=(a,b,True)
  a,b=plus(times(4,Qi),(F(-1),F(0)));constraints[f'{winner}:hard_cap']=(a,b,False)
  for cand in candidates:
   a,b=plus(subtract(times(cand['C'],kernels['QJ']),times(D,Qi)),utotal)
   constraints[f'{winner}:rho:{cand["name"]}']=(a,b,True)
 cells=[];feasible=[]
 for winner in LABELS:
  common=['m_positive','far_positive']+[f'{winner}>={other}' for other in LABELS if other!=winner]+[f'{winner}:high',f'{winner}:heavy',f'{winner}:hard_cap']
  for cand in candidates:
   refs=common+[f'{winner}:rho:{cand["name"]}'];named=[(name,constraints[name]) for name in refs]
   record,lo,hi,lop,hip,empty=intersect(named)
   record.update(winner=winner,good_endpoint=cand['name']);cells.append(record)
   if not empty:feasible.append((len(cells)-1,lo,hi,lop,hip))
 def direct(m):
  tests={lab:at(kernels[lab],m) for lab in LABELS};q=max(tests.values());egm=at(eg,m);QJ=tests['QJ'];Utot=at(utotal,m);alpha=(D*q-Utot)/QJ
  goodpositives=[];rho_values={}
  for cand in candidates:
   i=cand['index'];a=atoms[i];A=frac(a['A']);J=frac(a['J']);rho=max(1-(U[i]+alpha*J)/(T*A),F(0));rho_values[cand['name']]=fj(rho)
   if rho>0:goodpositives.append(cand['name'])
  gates=dict(m_positive=m>0,far_positive=f0-m>0,high=p*egm>=2*K*q,heavy=egm>W*q,hard_cap=m<=4*q,q_positive=q>0,QJ_positive=QJ>0,alpha_nonnegative=alpha>=0,has_good_delta_positive_rho=bool(goodpositives))
  return dict(m=fj(m),m_display=display(m),q=fj(q),q_display=display(q),q_winners=[label for label,val in tests.items() if val==q],eg=fj(egm),QJ=fj(QJ),Utotal=fj(Utot),alpha=fj(alpha),rho_by_candidate=rho_values,positive_good_endpoints=goodpositives,gates=gates,all_gates_pass=all(gates.values()),m_over_q=fj(m/q),m_over_q_display=display(m/q),p_m_over_q=fj(p*m/q),p_m_over_q_display=display(p*m/q))
 output=dict(id=case['id'],stage=case['stage'],n=n,parameters=dict(p=fj(p),K=fj(K),D=fj(D),T=fj(T),ell=fj(ell),cj=fj(cj),g=fj(g),fixed_eps=[fj(a) for a in fixed],far_zero_core_mass=fj(f0)),affine_coefficients={label:affine_json(value) for label,value in dict(**kernels,eg=eg,Utotal=utotal).items()},heavy_saved_rational_coefficient=fj(W),rebuilt_U_audit=Udiff,candidate_good_endpoints=[dict(name=c['name'],rho_QJ_coefficient=fj(c['C']),score_witnesses=c['witness']) for c in candidates],excluded_good_candidates=excluded,constraints={label:dict(**affine_json((a,b)),strict=strict) for label,(a,b,strict) in constraints.items()},winner_cells=cells,all_q_intercepts_positive=all(line[1]>0 for line in kernels.values()),reference=direct(REFERENCE),FULL_certified=False,real_dx_volume_certified=False)
 if not feasible:
  output.update(status='infeasible',mass_supremum=None)
  return output
 sup=max(item[2] for item in feasible);top=[item for item in feasible if item[2]==sup]
 attained=any(not item[4] for item in top)
 chosen=top[0];inside=(chosen[1]+chosen[2])/2
 inner=direct(inside);assert inner['all_gates_pass']
 supcheck=direct(sup);assert supcheck['all_gates_pass']==attained
 ref=output['reference'];qref=F(int(ref['q']['numerator']),int(ref['q']['denominator']));qsup=F(int(supcheck['q']['numerator']),int(supcheck['q']['denominator']))
 gain=(sup/qsup)/(REFERENCE/qref)
 output.update(status='certified_saved_coefficients',mass_supremum=fj(sup),mass_supremum_display=display(sup),supremum_attained=attained,supremum_active_constraints=sorted(set(name for item in top for name in cells[item[0]]['upper_active'])),supremum_cell_indices=[item[0] for item in top],supremum_limit=supcheck,feasible_interior=inner,interior_cell_index=chosen[0],reference_to_sup_prefactor_gain=fj(gain),reference_to_sup_prefactor_gain_display=display(gain),reference_to_sup_prefactor_gain_log10=mp.nstr(mp.log10(ff(gain)),30),saved_rational_certificate_pass=True)
 return output

def main():
 if OUT.exists():raise SystemExit('Refuse another capacity producer run')
 original=json.loads(INPUT.read_text());assert len(original['cases'])==12
 sources=[ROOT/'core_capacity_protocol.md',Path(__file__),INPUT]
 data=dict(status='running',run_count=1,started_utc=utc(),input_sha256=sha(INPUT),sha256={str(p):sha(p) for p in sources},arithmetic='Fraction exact for saved decimal coefficients; mp display only',scope='Finite affine necessary-gate certificates for variable core mass, not exact transcendental kernels/FULL/continuous source/dx/global order',cases=[],exceptions=[])
 save(data)
 for case in original['cases']:
  try:
   row=calc(case);data['cases'].append(row)
   print(case['id'],row['status'],'sup',row.get('mass_supremum_display'),'attained',row.get('supremum_attained'),'limits',row.get('supremum_active_constraints'),'gain10',row.get('reference_to_sup_prefactor_gain_log10'),flush=True)
  except Exception as exc:
   rec=dict(id=case['id'],status='exception',exception=repr(exc),traceback=traceback.format_exc());data['cases'].append(rec);data['exceptions'].append(rec);print(rec,flush=True)
  save(data)
 valid=[c for c in data['cases'] if c['status']=='certified_saved_coefficients']
 data['summary']=dict(case_count=len(data['cases']),saved_coefficient_certificates_passed=len(valid),infeasible_ids=[c['id'] for c in data['cases'] if c['status']=='infeasible'],exception_ids=[c['id'] for c in data['cases'] if c['status']=='exception'],winner_cell_count=sum(len(c.get('winner_cells',[])) for c in data['cases']),feasible_cell_count=sum(a['feasible'] for c in data['cases'] for a in c.get('winner_cells',[])),strict_supremum_ids=[c['id'] for c in valid if not c['supremum_attained']],attained_supremum_ids=[c['id'] for c in valid if c['supremum_attained']],interpretation='Maximum permitted positive hard core mass under exactly the listed stored-coefficient necessary gates, with all q-winner cells and strict endpoint semantics. No old integration rerun and no FULL/real dx volume/global order certification.',FULL_certified=False,real_dx_volume_certified=False)
 data['status']='completed_with_exceptions' if data['exceptions'] else 'completed_saved_coefficient_certificates';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
