#!/usr/bin/env python3
"""Portable optional replay; outputs are written to a new directory."""
from pathlib import Path
import argparse,importlib.util
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('mode',choices=['capacity','kernel']);p.add_argument('destination',type=Path);a=p.parse_args()
a.destination.mkdir(parents=True,exist_ok=False)
name='core_capacity_probe' if a.mode=='capacity' else 'pair_kernel_probe'
spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.OUT=a.destination/(name+'.json')
if a.mode=='capacity':m.INPUT=root/'capacity_input_minimal.json'
else:m.R135_PHI_SOURCE=root/'dependencies'/'real_joint_numeric.py'
m.main()
