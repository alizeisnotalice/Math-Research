# R138 核心硬载体最大质量：保存系数的有理区间协议（运行前冻结）

目标：将R136 finite model的任意CORE质量10^-300替换为在明确必要门下的最大允许质量上确界。只新增本协议、core_capacity_probe.py/json，不调用旧积分/核producer。输入为R136 active_traffic_v2.json原12例（三阶段、位置/核/score不变），输入SHA绑定JSON。全部120位存储十进制转Fraction；证书只认证这些保存有理系数，不重新认证原超越核/常数，不授予FULL、连续来源、真实dx体积或总体阶数。

## 质量模型与仿射系数

G1–G4各原eps质量保持输入不变；f0=1−∑四固定质量。CORE质量m、far B质量f0−m，限制0<m<f0（far严格正，避免零质量bad假资格）。每个测试X∈{K0,J,Q*}，以及eg的wg、总U，均为X(m)=b_X+a_X m，其中b_X=∑四固定νX+f0 X_far，a_X=X_core−X_far。q(m)=max(Q0,QJ,Q*)。所有核/权重来自保存值；terminal good/bad及source阈值冻结。

每来源U_v按保存T,A,K0用Fraction精确重建：good且A>0时min(TA,DK0)，其余0；旧硬B=0沿原R>L接口。尤其CORE若min=TA，则TA−U_core精确为0，不把独立保存U舍入误差制造成正余量。并记录重建U与原保存U的差。

heavy系数W=ell c_j^(−n/2)g^n，用保存ell,cj,g的有理式计算；原例n均偶数。不得用sqrtell/T的另一个保存舍入身份替换它。HG/high及ρ条件同时保留存储T的原值，明确这不是重新认证原解析参数关系。

## 精确有限cell可行性

首先在原score开段中点以α²<lo hi精确确定各score。good候选须A>0、TA−U_v>0、自身固定正质量，并在至少一个开段与terminal bad有严格δ>0；记录bad身份与质量。原source部分均有固定G4配对，far额外严格正约束仍保留。core可有m正质量，但TA−U=0不列候选。

对每个q赢家i∈{Q0,QJ,Q*}、每个上述good v，取以下有理半直线交：

- m>0与f0−m>0；
- Qi−Qj≥0，j为另两个测试（赢家tie两侧均保留）；
- p eg−2KQi≥0（high，非严格）；
- eg−WQi>0（heavy，严格）；
- 4Qi−m≥0（hard帽，非严格）；
- (TA_v−U_v)QJ/J_v−DQi+Utotal>0（ρ_v>0，严格）。

每条a m+b≥0/>0精确转为有理下/上界；a=0单独处理。所有3×候选cell照录，包括空cell、零常数约束、winner切换与闭单点。并集的最大上界给sup m；若严格边界则不可取，必须记录open及不达到。给可行cell中点和直接逐条Fraction再验收；不以浮点搜索代替有理证书。

q始终正，因为m∈[0,f0]是正核值的质量混合且四个固定eps来源正。m/q在每个winner分支导数为b_i/q_i²>0，因此在质量sup取极限可报告其上确界；这种单调性及b_i>0也将逐例记录。真实有限硬来源因子∫h_Rν=m（R=1，其他原子全在硬盒外），模型外前因子为p m/q，未包含原β、dx、history/选择器。报告可行内点与sup极限，和旧10^-300参考质量同canonical系数下的p m/q比值，不能把sup强行当可取值。

## 一次运行与全记录

沿原12例不扩菜单。一次producer，保存输入/协议/脚本SHA、全部仿射有理系数、heavy有理系数、约束系数、全部赢家cell开闭端点、空cell原因、score配对证据、sup/内点/限制门/赢家tie、精确direct检查及对旧core的前因子变化。有理字段以分子/分母字符串存储，科学小数仅作显示。所有失败或不可行例原样保留，不替换不无限重试。完成停止。
