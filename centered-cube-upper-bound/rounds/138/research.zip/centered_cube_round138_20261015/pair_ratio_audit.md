# R138 同核bad配对比值独立先审

本稿先核主代理给定候选，不读取作者新稿。仅写本文件，无git/PDF，不扩展搜索/数值任务。结果是固定核真实配对比值界，不登记来源根阶付款。

## PRA1. 一维分支、soft log收缩与单侧越界

固定0<s≤1，r=1−s≥0，q_s(t)=r1_{|t|≤1/2}+sφ(t)。真实φ>0、φ≤1、偶且在正半轴非增，且已给|logφ(t)−logφ(t′)|≤4|t−t′|。因此q_s>0、q_s≤1，G_s=1+r/[sφ(1/2)]有限。

比较H⁻¹q_s((x−a)/H)与H⁻¹q_s((x−u)/H)，归一化因子H⁻¹相消。两位置同在hard窗内时，映射t↦log(r+s e^t)的导数s e^t/(r+s e^t)∈[0,1]，故其log比受soft log差控制；同在窗外时比值就是φ比。分子outside、分母hard时，分母≥sφ，故比≤φ比，也无额外G。

只有分子hard、分母outside时，多付1+r/[sφ((x−a)/H)]≤G_s。因此逐点有

\[
\frac{K_H(x-a)}{K_H(x-u)}
\le e^{4|a-u|/H}
\left[1+(G_s-1)1_{I_a\setminus I_u}(x)\right],
\tag{PRA1}
\]

I_a=[a−H/2,a+H/2]、I_u同定义。硬端点采用≤，同hard端点也适用log收缩；闭窗差的单侧越界域包括分子hard/分母非hard的准确情形。端点在真实dx下零测，但为任意固定源位置的点态证明仍按此约定保留。

I_a\I_u长度是min(H,|a−u|)，不是两窗对称差2min(H,|a−u|)。这里不因对称交换源位置而重复支付两份G。

## PRA2. 固定归一乘积p积分及量词

固定同一s、L,H>0、y∈Rⁿ；p(x)=P_(s,L)(x−y)是归一乘积概率核，K=P_(s,H)。每个p一维密度≤1/L，故对单侧越界域

\[
\int p_{s,L}(x-y)1_{I_a\setminus I_u}dx
\le\min\{1,\min(H,|a-u|)/L\}
\le\min\{1,|a-u|/L\}.
\]

对PRA1逐坐标乘积，以p产品积分，准确得

\[
\boxed{\int_{R^n}p(x)\frac{K(x-a)}{K(x-u)}dx
\le e^{4\|a-u\|_1/H}
\prod_i\left[1+(G_s-1)\min\{1,|a_i-u_i|/L\}\right].}\tag{PRA2}
\]

可保留更尖的min(1,H/L,|a_i−u_i|/L)；候选较松但对所有L,H>0正确，不要求H≥L或H≥L⁺。y,a,u任意，右侧虽与y无关，仍保留bad配对真实位移a−u，不能取成输入无关常数。

s=1时G_s=1，纯soft比界成立；s=0不能用G_s分母，原实际soft门也排除它。a=u时比值积分准确为1，右侧亦为1，无伪衰减。固定源位置的比值由PRA1统一有限帽控制，因此真实接收积分合法，无额外尾假设。来源ν不要求乘积，但此积分的p、K参数必须共同固定；自适应s,L,H(x)不能借此产品积分身份免费处理。

**候选核比值初审：PASS。** 单侧越界、hard端点、log收缩、指数4/H、所有常数及全尺度量词正确；没有给任意来源配对指数距离的统一矩预算。

## PRA3. r=2的C_bad B2展开、Tonelli与删门费用

固定合法(y,t)来源层与good来源v，δ_v(u)=[k_t(v)−k_t(u)]_+不依接收x。记D(x)=原同x终端bad集合，并保留D(x)⊂Z_g⊂Z_t在原贡献域的资格。定义

\[
C_{bad}(x)=\int_{D(x)}K(x-a)d\nu(a),
\quad B_2(x,v)=\int_{D(x)}\delta_v(u)^2
\frac{w_t(y,u)^2}{K(x-u)}d\nu(u).
\]

真实s>0、K>0使比合法，所有量可先取扩展非负值。非负Tonelli准确展开

\[
\boxed{C_{bad}(x)B_2(x,v)=\iint
1_{D(x)}(a)1_{D(x)}(u)\,\delta_v(u)^2w_t(y,u)^2
\frac{K(x-a)}{K(x-u)}d\nu(a)d\nu(u).}\tag{PRA3}
\]

严格δ>0也可显式列{kt(u)<kt(v)}，因为δ²已令其补集为0。若C_bad=0，K>0给ν(D)=0，B2亦0；不以0·∞定义乘积。外硬来源z与这里的两个bad数学拷贝a,u不同，不能将a偷换成外hard z或给它继承hard捕获资格。

对裸固定概率核接收积分，Tonelli合法给

\[
\int p(x)C_{bad}(x)B_2(x,v)dx
=\iint\delta_v(u)^2w_t(y,u)^2
\mathcal R_D(a,u)d\nu(a)d\nu(u),
\]

\[
\mathcal R_D(a,u)=\int p(x)1_{D(x)}(a)1_{D(x)}(u)
K(x-a)/K(x-u)dx.
\tag{PRA4}
\]

这是两个actual bad门在同一x的联合核，不能先把D(x)提出dx。仅在正上界中删两bad门，便有R_D≤R(a,u)，R由PRA2显式给。若来源Z_t固定可仍保留两端Z_t；若终端Z_g随接收选择器变化，不能冒用固定Z_g。门放松后原FIRST的C_bad≤q或α余额只能在原actual贡献域调用，不能为任意新增来源/接收位置继续免费使用。

因此新增待付价是

\[
\iint\delta_v(u)^2w_t(y,u)^2
 e^{4\|a-u\|_1/H}
\prod_i[1+(G_s-1)\min(1,|a_i-u_i|/L)]
\,d\nu(a)d\nu(u)
\tag{PRA5}
\]

或更尖的R_D实际联合核积分。它不由有限ν自动有维数一致帽；每对源的接收比有限不代表来源二重距离矩免费可积。新增a来源拷贝是展开C_bad的数学容量因子，未归一化为新的Π，也不是第二份独立αQ_J预算。

r=2的裸CS为L_v²≤C_bad B2/e_t²。若再用固定归一p对平方根作Jensen，可得∫p√(C_bad B2)≤√(∫p C_bad B2)，此方向合法；若ρ、good等接收门保留，也只能作为真实非负权或先在允许正上界中放松。母式其他T/Q_J、逆J、q⁻¹h_R、history等乘子不属于裸p概率，不能由PRA2或此Jensen顺便删除。应另给加权接收矩/帽及其总质量，或按原SI2次序一次收费。

**r=2展开初审：PASS（准确恒等式与非负交换）。** 来源的两份bad门在R_D中同x保留，删门后的配对指数距离、G_s硬边界费用和两份ν均明确留账；原两e_t、good来源、β−ν、真实dx、hard z、q、唯一j、history、参数选择与signed2Λ仍保留。负项原门不变，N_Z不返还、N_Zc/Ndel各一次。此先审不认证来源根阶价格；等作者确切冻结稿后追加实读后审。

## PRA4. 冻结RS作者实读后审：RS1–7带符号硬跳

PRA1–3独立先行完整保存后才读取 `receiver_source_geometry.md`，实读SHA-256=`d09795acde4f3b21500436fe48d370d51f0c08a3f03e7af232be6a59968f327d`，与冻结通知一致。后审只追加本文件，未改作者。

**RS1–3 PASS。** 作者比先行更尖，C_v只积分{f_x(v,a)>0}的真实低score bad容量；它仍≤原bad容量，DC_v≤αQ_J仅在actual同行用一次。f包含原FA、Ψ，B_v含f²；Cauchy的第一因子是K的support容量，而非错误把f权再复制进去。{f>0}⊂A_v，因此RS3的A_v²域及support indicator准确；裸Π bad端给1/e_t。k=0、C_v=0及零源行先列零，不把0·∞当身份。两个bad来源a,u是实际ν的数学容量拷贝，不是独立来源坐标，也不能与外hard z合并。

**RS4常数 PASS。** R136已核a0=2/(5√e)、w(r)≤e⁻ʳ/(1+r)。0≤r≤1/2时|φ′|≤1、φ≥a0 e⁻¹/²/(3/2)，比≤(3/2)√e/a0=15e/4。r≥1/2时|φ′|≤w(r−1/2)≤√e e⁻ʳ/(r+1/2)，除以φ下界后同样≤(3/2)√e/a0。负r由偶φ及奇φ′给相同界。故全线Lφ有限，粗显式15e/4正确；原已用logφ的4-Lipschitz接口允许更小常数，但当前较粗取值不构成错误。

在r=±1/2，closed hard值q_s=(1−s)+sφ(1/2)=G_s sφ(1/2)。因此

\[
\ell_s=\log q_s-\log G_s1_{|r|\le1/2}
\]

边界值及两侧极限都等于log[sφ(1/2)]，准确连续。hard内部导数sφ′/[(1−s)+sφ]、外部φ′/φ均≤Lφ；连续分段绝对连续且导数界给全线Lφ-Lipschitz。这里没有把未减跳的logq_s误称连续，s=1时G=1亦直接成立。

**RS5–7 PASS。** K ratio的H⁻ⁿ相消，ell_s差给exp(Lφ‖a−u‖₁/H)，余硬跳保留G_s^(m_a−m_u)的符号。a=u时准确1；分母hard/分子outside的负指数不是可以任意裁掉后再领第二份收益。固定概率乘积p积分得到每坐标E[G^(1_Ia−1_Iu)]=1+(G−1)P⁺−(1−G⁻¹)P⁻，RS6括号正，未由来源独立性假设取得。丢负P⁻只放大上界，P⁺的单侧区间长度min(H,|a−u|)及密度cap1/L给RS7候选。若s,L,H随x改变，RS5逐点仍合法，但RS6固定核张量积分不可沿用；作者明确保留该边界。

## PRA5. RS8–9的inactive局部性与可付分支

两个源a,u均严格低score，|I_t(a)|,|I_t(u)|≤k−1。将尺度下端记为a_scale以区别源位置a，原t≥a_scale/c_j及a_scale/b≥1/2给每个共同inactive坐标|a_i−y_i|<b、|u_i−y_i|<b，所以并集E的大小≤min(n,2(k−1))，E外|a_i−u_i|<2b。RS8的严格界及整数计数正确。它没有限制E内尾深度，也没有把n个局部坐标总距离当常数。

RS9由log(1+x)≤x及RS7直接给二源裸接收价格≤e^B；B的位移与硬越界计数费用完整保留。该条件只定义原交通可测分支，不证明全类B=O(log n)。共同尾位置的深度已从ratio被积式消去，但源间分离价仍实在存在；不能据零距离归一化宣称任意来源聚簇预算已付。

## PRA6. RS10–12的真实ρ测度、两e分母与原外账

固定合法来源列(y,t,j,history,外hard z)，保持Z_t,w_t,k_t,ν不随x改变。作者定义W_v保留原q⁻¹h_R、history、actual good、H<L⁺、C_J(x,v)≤3及其余外接收域；FA与Ψ依内源u，继续留在f。γ_v=p_xW_vρ_x(v)dx是非负**实际接收测度**，不假设归一。它可依good源v及原整份ν/共同α，但应不依新增bad配对a,u；任何额外原pair门都须继续放在f/Γ，而不能误塞成外γ常数。

从原正交通的good dΠ_t(v)=w_vν(v)/e_t及bad dΠ_t(u)=w_uν(u)/e_t，RS2准确给

\[
P_{col}^{branch}\le e_t^{-2}\int_{Z_t}w_vd\nu(v)
\int\sqrt{C_v(x)B_v(x)}d\gamma_v(x).
\]

因此γ含ρ**一次**恰好对应原正权，不是把ρ平方或提前删除。接收CS是

\[
(\int\sqrt{C_vB_v}d\gamma_v)^2
\le M_v\int C_vB_vd\gamma_v,
\quad M_v=\int d\gamma_v.
\]

乘积中两处γ共同恢复原一次ρ的上界，例如constantρ时平方根只给一次ρ；没有再额外申请RC容量。M_v不是1或输入独立帽，必须保留。

RS3的非负Tonelli后，f(v,u)²将δ_u²留在根内，D_g(u)χ_FA²Ψ²及capacity-source support{f(v,a)>0}合成作者Γ_v。RS5的带符号比在同一个实际x、同一个H(x),s(x)上逐点适用，得到RS11的L_v(a,u)。它包括原γ_v与全部同x门，选择器并未使用RS6的固定p概率张量法。hard端点≤的signed分离是逐点正确的，即便选择器使某边界有正接收测度，也无需依赖“固定边界零测”偷删它。

于是RS12的完整右端

\[
e_t^{-2}\int_{Z_t}w_vd\nu(v)
\left[M_v\iint_{A_v^2}\delta_v(u)^2w_u^2
L_v(a,u)d\nu(a)d\nu(u)\right]^{1/2}
\]

全部正确：两份e_t保留，source支持/严格score保留，ρ在M_v与L_v的同一γ中，外hard z与新增bad a不混同。M_v=0直接零；无限量按作者非负有限截断解释，不将∞·0写成有限身份。恢复β(dy)、外hard ν(dz)、dt/t、唯一本来j、种子/history、期望及signed2Λ均原位；不能将β换ν或再领SI2的硬帽。

**RS10–12 PASS。** 准确改善是容量与逆K在接收比前相乘，去掉共同尾深度，保留源间距离及signed硬边界；未付量是RS12在真实外账中的source-separation/边界联合能量。C_J≤3与H<L⁺分支都在actual W_v内，未在证明开头声明后丢弃；一般根阶预算尚未证明。

## PRA7. research.tex核心(1)–(4)的一致性核对

按主代理追加要求，只读本轮 `research.tex` 的核心提取，不重新推导或审其另一个signed诊断章节。实读SHA-256=`469d47fa783665a276ffd42c8f577cbdbaefd3f124dfd73d1ee003a44dbbafba`。

- (1)与RS5一致，包含signed m_H差；TeX取Lφ=15e/4这一已核粗显式常数，属于作者允许的取值。连续ell_s的证明与RS4相同，closed hard端点保留。
- (2)与RS6一致，P⁺、P⁻两个单侧越界概率及负项−(1−G⁻¹)P⁻正确；密度帽与单侧长度叙述一致。
- (3)与RS3一致，capacity源a的support indicator与bad u的f²、wt²、同K ratio均完整保留，a没有被重命名为外hard z。
- (4)与RS12一致，外e_t⁻²、M_v、A_v²、δ_u²w_u²L_v及good wtν均在。TeXγ_v包含实际ρ(v)，其x依赖应按原完整actual行理解；M_v=∫γ_v没有被当归一概率。

**核心TeX一致性 PASS。** 未编译PDF，也未认证本节任务之外的signed时间诊断。

**本轮最终冻结判定：RS1–12及TeX核心(1)–(4) PASS。** 未发现需修改的数学公式错误。先行核比与r=2配对展开保留，作者signed硬跳加强及实际ρ加权接口准确；来源分离/边界联合外层价格仍未付，不登记一般根阶闭合。未重审主代理负责的数值缩放/零距协议，未扩展任务。完成停。

## PRA8. NG2实际low-likelihood子支与新增TeX节后审

在RS后审完成后，按主代理新增短检查点要求读取 `next_geometry_checkpoint.md`，实读SHA-256=`4579c08bb4db543c59acf2a012c80930018bd8a11c77dfa66d546f749b2b89fe`。仅审NG2的明确子支及NG3的条件代数，不展开新路线。

固定非零actual good行、A(v)>0、Q_J>0、e_t>0，f原样包含严格低score bad、FA和Ψ，K0、J>0。Lζ=4De_tJζ/(TAQ_J)有限可测。E_low={f>0:fwt/K0≤Lζ}是原正交通的可测新增指示，不需要空间聚团或来源独立。因为其support⊂原actual bad，准确有

\[
\rho\int_{E_{low}}f\,d\Pi_t
=\frac\rho{e_t}\int_{E_{low}}fwt\,d\nu
\le\frac{\rho L_\zeta}{e_t}\int_{E_{low}}K_0\,d\nu
\le\frac{\rho L_\zeta\alpha Q_J}{D e_t}.
\]

原ρ=(a_v−b_vα)_+，a_v=(1−DK0/(TA))_+∈[0,1]、b_v=J/(TA)>0。对实际共同α≥0，α(a_v−b_vα)_+≤a_v²/(4b_v)，只是标量上界，不按v重新选择α。代入Lζ得ζa_v²≤ζ，NG2系数4、D、J、TA、Q_J和e_t全部正确相消。A=0、硬捕获B=1、a_v=0以及零源/e_t/Q_J行直接列零，不计算相应比值；s>0确保likelihood分母K0严格正。

对good端原Π_t积分至多ζ；原实际非空far时间窗⊂[τ,h]且τ=a_scale/c_j、h≤g≤b，已有比例域给h/τ≤2，所以时间价≤ζlog2。用一次raw Tsmall≤4X及signed外2Λ，准确得8Λζlog2 X。若以既有ε_slot吸收，必须先在当前余项中与历史已付子支不交并实际分配ζ≤ε_slot/(8Λlog2)；本检查点没有自行创造新的未消费槽，也没有重复使用Dq或SI2硬帽。

**NG2 PASS（真实可付款子支，带既有误差槽条件）。** 它允许任意A/wg及共同深尾，不是旧A/wg窄条带的改写；没有证明其覆盖正交通的大部分。原负项不附E_low，N_Z不返还，N_Zc/Ndel各一次。

NG3只作条件性充分推论。若每个dyadic高likelihood层的实际容量真满足所列B2^(−j)/(1+j)²分配率，则∫层fwtν≤2^(j+1)Lζ c_j，再用同一次ρα二次帽给每层≤2Bζa_v²/(1+j)²，可求和。该尾分配率当前未证，B也需真实外预算；本审没有将NG3登记为新一般定理或已付尾。NG1的分簇CS不产生簇数粗因子，但也不自动付款NG3，符合作者边界。

最后读取 `research.tex` 新增low-likelihood节，并复核核心(1)–(4)未改变。本次最终源实读SHA-256=`c709834340db0e4cfd1c9ec52550ea71f9ef26fb090aab7199c0e9c9b0b2b92a`。新增节的Lζ、E_low、ρα帽、ζ行价、8Λζlog2 X以及既有slot/不交要求均与NG2一致；分簇CS及“无免费capacity-tail”边界也一致。原PRA7的核心审结继续适用；未编译PDF或重审其signed诊断。

**最后交付判定：NG2与新增TeX节 PASS；NG3仅条件性。** 本轮RS/核比/原积分接口及明确low-likelihood付款子支全部通过当前冻结文本，无需数学公式勘误。一般来源分离与高likelihood容量尾的真实外层根阶预算仍未证明。未重复主代理数值审查，未扩展任务。完成停。
