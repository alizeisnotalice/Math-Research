# R138：实际bad容量与逆核的联合接收几何

状态：推导冻结，待独审。目标限定为原RT2中Hhat<L₊、C_J(v)≤3的正交通；本稿不强制支付NC26的更大正放松。只读R135 JG135.10–19、R136 AB9与实核定义，以及R137已审接口。任意相关ν、同一Π_t、真实ρFAΨ、共同α、外硬z与β均保留。结果是一个消除共同来源尾深度费用的两来源核比估计及其原积分接口；一般根阶付款尚未闭合。

## RS1：保留实际低-score bad容量，先乘再比较

固定实际行、t、good来源v，记k=k_t(v)、w_u=w_t(y,u)、H=Hhat、K_u=K₀(x−u)。令

\[
 f_x(v,u)=\mathbf1_{D_g(x)}(u)[k-k_t(u)]_+
 \chi_{FA}(x,v,u)\Psi(x,v,u),\qquad
 A_v=Z_t(y)\cap\{k_t(u)<k\},
\]
\[
 C_v(x)=\int_{\{f_x(v,a)>0\}}K_a\,d\nu(a),\qquad
 B_v(x)=\int_{A_v}f_x(v,u)^2\frac{w_u^2}{K_u}d\nu(u).
 \tag{RS1}
\]

C_v是实际活跃低-score bad来源的核质量，不以αQ_J/D替代；但同一原余额仍保证DC_v≤αQ_J。用CS只一次，

\[
 \rho(v)\int f_x(v,u)d\Pi_t(u)
 \le\frac{\rho(v)}{e_t}\sqrt{C_v(x)B_v(x)}.
 \tag{RS2}
\]

所有FA、Ψ及ρ仍是原值。关键展开是

\[
 C_vB_v=\iint_{A_v^2}\mathbf1_{\{f_x(v,a)>0\}}
 f_x(v,u)^2w_u^2\frac{K_0(x-a)}{K_0(x-u)}
 d\nu(a)d\nu(u).
 \tag{RS3}
\]

于是接收估计面对的是同尺度**核比**，不再是单独的逆K₀。没有假定两个来源独立；双积分只是同一ν乘积上的非负Tonelli。容量由实际C_v使用，原α及其对good剩余的限制仍全部留在ρ里，不另领Dq。

## RS2：混合核的硬跳分离及零距离归一化

记一维实核

\[
 q_s(r)=(1-s)\mathbf1_{|r|\le1/2}+s\phi(r),\qquad
 G_s=1+\frac{1-s}{s\phi(1/2)}.
\]

令L_φ=sup_r|φ′(r)|/φ(r)。它有限，且由R136 FK1的a₀=2/(5√e)可显式取

\[
 L_\phi\le15e/4.
 \tag{RS4}
\]

证明：φ′(r)=w(r+1/2)−w(r−1/2)，用偶性理解右边。0≤r≤1/2时|φ′|≤1，φ≥a₀e^{-1/2}/(3/2)。r≥1/2时|φ′|≤w(r−1/2)≤e^{-r+1/2}/(r+1/2)，再除以φ≥a₀e^{-r}/(1+r)，同得(3/2)√e/a₀=15e/4。可用真实更小L_φ替代粗显式值。

函数

\[
 \ell_s(r)=\log q_s(r)-\log G_s\,\mathbf1_{|r|\le1/2}
\]

在±1/2连续；区间内外的导数绝对值均≤L_φ。因此全线L_φ-Lipschitz。对任意来源a,u、接收x和同一H，得到**带符号硬跳**核比

\[
 \boxed{\frac{K_0(x-a)}{K_0(x-u)}
 \le \exp\!\left(\frac{L_\phi}{H}\|a-u\|_1\right)
 G_s^{m_H(x,a)-m_H(x,u)},}
 \tag{RS5}
\]

m_H(x,a)=#{i:|x_i−a_i|≤H/2}。尺度H^{-n}准确抵消。RS5保留负的硬跳指数，未替成G_sⁿ。a=u时右端严格为1；共同平移两个来源到任意深尾不会改变距离项，硬跳最多在实际边界穿越处付费。这个性质不同于分别对容量核和逆核取sup，后者丢失了共同尾的抵消。

## RS3：固定接收概率核下的可积二来源价格

固定s∈(0,1]、L,H∈[a,b]，p=P_{s,L}(x−y)。设一维硬区间I_H(a_i)=[a_i−H/2,a_i+H/2]，定义真实接收概率

\[
 P_i^+=\int_{I_H(a_i)\setminus I_H(u_i)}p_{s,L}(x_i-y_i)dx_i,
 \quad
 P_i^-=\int_{I_H(u_i)\setminus I_H(a_i)}p_{s,L}(x_i-y_i)dx_i.
\]

由RS5及接收核乘积结构（不是来源独立性），

\[
 \boxed{\int p(x-y)\frac{K_0(x-a)}{K_0(x-u)}dx
 \le e^{L_\phi\|a-u\|_1/H}
 \prod_i\bigl[1+(G_s-1)P_i^+-(1-G_s^{-1})P_i^-\bigr].}
 \tag{RS6}
\]

每个括号是正量，即E[G_s^{1_{I(a)}−1_{I(u)}}]。再用p_{s,L}≤1/L及两个等长区间差的长度，得较粗而可直接核验的价格

\[
 \boxed{\int p\,K_a/K_u\le
 e^{L_\phi\|a-u\|_1/H}
 \prod_i\left[1+(G_s-1)
 \min\{1,|a_i-u_i|/L\}\right].}
 \tag{RS7}
\]

这没有逐维大于1的零距离基价；源间距离趋零时右端趋1。所有s、维数与距离费用均显式保留。RS6–7在r=2的C_vB_v接口中已可用，且没有R136独立逆核包络的接收尾临界问题：全接收积分由来源之间的距离控制，而非由|x−y|的正指数控制。

固定核条件不可删。若s,L,H随x变化，RS5逐点仍成立，但不能把其右端按固定p张量积分为RS6。下节直接保留实际加权dx，覆盖这些选择器。

## RS4：inactive坏坐标提供的真实而有限几何信息

原t≥τ=a/c_j及inactive条件α_i(y,u)≥t给C(|y_i−u_i|/b)≥a/b≥1/2；C(1)<1/2，所以

\[
 i\notin I_t(u):=\{i:\alpha_i(y,u)<t\}
 \Longrightarrow |u_i-y_i|<b.
\]

RS3中的a,u都严格低score，故|I_t(a)|,|I_t(u)|≤k−1。令E=I_t(a)∪I_t(u)，则

\[
 |E|\le\min(n,2(k-1)),\qquad
 i\notin E\Longrightarrow |a_i-u_i|<2b.
 \tag{RS8}
\]

因此RS6–7的无界来源分离仅可能出现在至多2(k−1)个坐标；其余坐标有真实局部界。仍须保留这些局部坐标的实际距离和硬边界概率，不能因各自<2b就把n个费用当常数。例如RS7给的可检查近云条件

\[
 \frac{L_\phi}{H}\|a-u\|_1+
 (G_s-1)\sum_i\min\{1,|a_i-u_i|/L\}\le B
 \tag{RS9}
\]

蕴含二来源接收价格≤e^B，且不依共同尾深度。RS9是可测几何分支，不是全类新增假设；inactive本身没有证明B=O(log n)。本稿没有用此分支替代剩余全类。

## RS5：同Π、真实dx、ρFAΨ与外硬来源的原积分接口

固定来源列y,t,j,history及外硬来源z，使Z_t,w_t,k_t不随x改变；核尺度及原接收选择器可仍随x变化。将原good域及本任务分支直接保留在

\[
 W_v(x)=q(x)^{-1}h_{R(x)}(x-z)a_{history}(x)
 \mathbf1_{\{v\in S_g(x),\ H(x)<L_+(x),\ C_J(x,v)\le3\}}
 \mathbf1_{\text{原其余接收门}}(x),
\]
\[
 d\gamma_v(x)=p_x(x-y)W_v(x)\rho_x(v)dx,\qquad
 M_v=\int d\gamma_v.
 \tag{RS10}
\]

原FA及Ψ不放进W_v，因为它们依内来源u，继续留在f_x。定义

\[
 \Gamma_v(x;a,u)=\mathbf1_{\{f_x(v,a)>0\}}
 \mathbf1_{D_g(x)}(u)\chi_{FA}(x,v,u)^2\Psi(x,v,u)^2,
\]
\[
 \mathcal L_v(a,u)=\int d\gamma_v(x)\,\Gamma_v(x;a,u)
 \exp\!\left[\frac{L_\phi}{H(x)}\|a-u\|_1\right]
 G_{s(x)}^{m_{H(x)}(x,a)-m_{H(x)}(x,u)}.
 \tag{RS11}
\]

RS11是显式距离/硬边界积分，已不含逆K₀或来源核尾比。它保留原same-x good/bad与共同ρ、全部FA/Ψ以及真实接收载体。特别C_J(v)≤3和H<L₊是实际域，不是仅在证明开头声明后又丢掉。

由RS2–3、RS5，在正测度γ_v上使用CS，当前列的原正交通满足

\[
 \boxed{P_{t,y,z}^{\rm branch}\le
 \frac1{e_t(y)^2}\int_{Z_t}w_v\,d\nu(v)
 \left[M_v\iint_{A_v^2}
 [k_t(v)-k_t(u)]^2w_u^2\,
 \mathcal L_v(a,u)\,d\nu(a)d\nu(u)\right]^{1/2}.}
 \tag{RS12}
\]

证明中的接收步骤为(∫√(C_vB_v)dγ_v)²≤M_v∫C_vB_vdγ_v，再对非负二来源积分Tonelli；方向合法。M_v=0时该列为零。无限量通过非负截断解释，不预先声明有限。

两份e_t分母与同一ν全部显式保留；没有来源独立性假设，也没有ν质量/e_t帽。新增a是实际低-score bad容量的来源，与原外硬来源z不同；不能将两者合并。恢复β(dy)、外ν(dz)、dt/t、原唯一j、种子/history和期望，RS12右端乘signed2Λ即是该分支的完整新上界。β不替为ν。原不能固定Z_t的列可保留最初逐行RS2–5，不直接授予RS12的固定来源列Fubini形式。

## RS6：这项联合价格实际改善了什么

1. **共同尾抵消。** 若实际活跃bad来源只在同一位置a=u取值，RS3的核比严格为1，容量和逆核精确消去；这不依位置离y多远，也不要求H≥L₊。RS5、RS6和RS11保留此零距离归一化。相反，先分别上界容量与逆核会引入共同深尾位置费用。此为实际被积式恒等，不是抽象反例或FULL数值配置声明。
2. **接收尾在r=2时可支付。** 固定核下，RS6–7以明确源间距离和硬边界概率支付整个Lebesgue接收积分，没有单独逆K₀带来的接收位移指数或临界可积性缺口。若相关来源对满足RS9，核价格≤e^B；进入RS12平方根后的该核费为e^{B/2}。原外乘子、ρ及门可保留在RS11，或在有明确帽时另外付费，不能免费消去。
3. **inactive约束的真实用途。** RS8把无界分离局限于两个低-score bad来源活动坐标的并集。共同inactive坐标的硬边界穿越概率可按RS6直接积分；不需要把每个坐标都付G_s。原ν相关不影响此固定二来源、接收乘积核的计算。

这些改善有明确范围：RS9不是全类已证事实，RS6要求固定接收参数。实际自适应核继续用RS11的真实加权积分；不以固定核概率归一替代它。若需要纯统一上界，可从RS5保留H≥b/2、s≥s₀并只取正硬跳，但其G_{s₀}和距离费用仍须支付，不能说核选择器免费。

## RS7：具体停止点与唯一未付几何步骤

本轮没有证明一般εX+C√n polylog(n)Wβ。准确未付的一步是：**在原same-x ρFAΨ、good C_J≤3分支及真实外接收载体下，支付RS12中两个严格低-score bad来源的分离/硬边界联合能量。** 现有inactive事实仅给RS8，不能给RS9的B=O(log n)，也不能独立控制RS11的β/time/j/history积分。将各共同inactive坐标的粗距离界相乘仍会产生指数维数费用，因此未作这种伪付款。

该步骤比此前NC26的全正放松更贴近原积分：ρ、FA、Ψ和同x门都未删除，共同α未被优化成独立常数，真实C_v和B_v已在逆核比较前相乘。它也没有通过缩小θ来掩盖score。若后续能从原同x资格控制上述来源对距离或实际硬边界概率，RS6/RS12就是直接接入点；在此以前不登记根阶价格。

N_Z不返回，N_Zc和N_del仍按原负门各一次；没有追加ε槽，没有重领RC容量或原硬帽。未作数值扩展、git或PDF。只修改本文件，到此停止。
