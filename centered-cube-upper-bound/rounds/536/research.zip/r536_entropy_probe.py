from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform
import sympy as sp
from flint import arb,ctx
import flint
ctx.prec=160
a0,b0=sp.symbols("a0 b0",positive=True)
assert sp.expand(2*b0*(1+b0-a0)-(b0-a0)**2-(2*b0+b0*b0-a0*a0))==0
# Input is an explicit finite incidence model, not a continuous-center theorem.
data=json.loads(Path(__file__).with_name('r536_input.json').read_text())
def add(out,c,z):
 if not c or z==1:return
 assert z>0
 for p,e in sp.factorint(z.numerator).items():out[int(p)]=out.get(int(p),Q(0))+c*int(e)
 for p,e in sp.factorint(z.denominator).items():out[int(p)]=out.get(int(p),Q(0))-c*int(e)
def clean(d):return {p:v for p,v in d.items() if v}
def minus(*args):
 d={}
 for sign,a in args:
  for p,v in a.items():d[p]=d.get(p,Q(0))+sign*v
 return clean(d)
def ball(d):
 y=arb(0)
 for p,c in d.items():y+=arb(c.numerator)/c.denominator*arb(p).log()
 return y
results=[]
for r in data:
 V=list(map(Q,r['volumes']));w=list(map(Q,r['weights']));a=[wi/vi for wi,vi in zip(w,V)];bits=r['patterns'];m=list(map(Q,r['masses']));N=len(V)
 assert all(sum(ms for bs,ms in zip(bits,m) if bs[i])==V[i] for i in range(N))
 es={k:{} for k in ['Ef','Er','Elog','Sf','Sr','If','Ir']}
 for reverse in [False,True]:
  sk,ik,ek=('Sr','Ir','Er') if reverse else ('Sf','If','Ef')
  for c in range(N):
   ids=[b for b in range(N) if (b>c if reverse else b<c)]
   overlaps={b:sum(ms for bs,ms in zip(bits,m) if bs[b] and bs[c]) for b in ids}
   ps={b:overlaps[b]/V[c] for b in ids}
   L=sum(a[b]*ps[b] for b in ids)
   if not L:continue
   for b in ids:
    if ps[b]:add(es[ek],2*w[c]*a[b]*ps[b],1/ps[b])
   for bs,ms in zip(bits,m):
    if not bs[c] or not ms:continue
    h=sum(a[b] for b in ids if bs[b])
    if not h:continue
    add(es[sk],2*w[c]*ms/V[c]*h,h/L)
    for b in ids:
     if bs[b]:add(es[ik],2*w[c]*ms/V[c]*a[b],L/(ps[b]*h))
 for b in range(N):
  for c in range(b+1,N):
   I=sum(ms for bs,ms in zip(bits,m) if bs[b] and bs[c])
   add(es['Elog'],2*a[b]*a[c]*I,V[c]/V[b])
 assert not minus((1,es['Ef']),(-1,es['Sf']),(-1,es['If']))
 assert not minus((1,es['Er']),(-1,es['Sr']),(-1,es['Ir']))
 assert not minus((1,es['Elog']),(-1,es['Ef']),(1,es['Er']))
 vals={k:str(ball(v)) for k,v in es.items()}
 for k in ['Ef','Er','Sf','Sr','If','Ir']:assert not (ball(es[k])<0)
 results.append({'name':r['name'],'exact_log_prime_coefficients':{k:{str(p):str(v) for p,v in clean(d).items()} for k,d in es.items()},'arb_160':vals,'three_exact_identities':True})
 print(r['name'],vals)
out={'scope':'Five finite incidence models, atomic weighted receiving centers. Exact prime-log coefficient identities and Arb enclosures only; no continuum or all-n entropy bound.','executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'flint':flint.__version__,'precision_bits':160,'results':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
