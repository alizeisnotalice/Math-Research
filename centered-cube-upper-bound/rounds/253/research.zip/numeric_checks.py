#!/usr/bin/env python3
"""R253 exact extraction diagnostics and genuine uniform-interval quadrature."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import isqrt,prod
import argparse,hashlib,json
import mpmath as mp

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fm(q):return mp.mpf(q.numerator)/q.denominator
def enc(x):return mp.nstr(x,50)
def vec(v):return [str(x) for x in v]
def energy(K,v):return sum((v[i]*K[i][j]*v[j] for i in range(len(v)) for j in range(len(v))),F())
def dot(v,w):return sum((a*b for a,b in zip(v,w)),F())
def matvec(K,v):return [dot(row,v) for row in K]

def rational_L1():
    p=lambda x:F(1,2)+x-x*x
    xmin=F(1,2)/p(F(1,16));ymax=F(1,2)/p(F(7,16));checks=[]
    def check(v):assert v;checks.append(True)
    check(xmin>=F(8,9));check(ymax==F(128,191));check(F(8,9)-F(128,191)>F(1,5))
    Kmin=1-F(9,16);S=Kmin*F(1,16)*F(1,8)/25;check(S==F(7,51200))
    t=F(1,16384);check(t*t+2*t<S);rbound=F(1,8)*(1-F(128,191));check(rbound>F(1,32));check(t/F(32)==F(1,524288));check(F(1,3)+F(1,3)==F(2,3))
    return {'source':'mu=1_[0,1] dx, n=d=a=1, b=2, tau=1/2','X':['0','1/16'],'Y':['7/16','9/16'],'theta_X_lower_exact':str(xmin),'theta_Y_upper_exact':str(ymax),'conservative_theta_difference_lower':'1/5','K_on_XY_lower_exact':str(Kmin),'slack_lower_exact':str(S),'residual_A_upper':'1','residual_B_upper':'2','rational_update_t':str(t),'quadratic_increase_upper_exact':str(t*t+2*t),'remaining_slack_lower_exact':str(S-t*t-2*t),'residual_mass_lower_strict':str(rbound),'mass_gain_lower_strict':'1/524288','original_energy_exact':'2/3','exact_arithmetic_checks':len(checks),'scope':'Genuine positive-volume L1 certificate from CE7 rectangles, not a point-source limit. Original mass is enlarged strictly with energy budget retained; no optimality/FULL/history/hereditary-after-enlargement claim.'}

def fixtures():
    P=lambda *xs:tuple(map(F,xs))
    return [
      ('initial','overlap_n1',1,F(1),[P(0),P('1/4'),P('3/4')],[F(1,2),F(1,3),F(1,6)],F(1,4)),
      ('initial','constant_theta_n2',2,F(1),[P(0,0),P('1/2',0),P(0,'1/2'),P('1/2','1/2')],[F(1,4)]*4,F(1,2)),
      ('initial','correlated_n3',3,F(1),[P(0,0,0),P('1/4','1/2','3/4'),P('1/2','1/2',0)],[F(1,7),F(2,7),F(4,7)],F(1,5)),
      ('pressure','zero_source',1,F(1),[P(0),P(2)],[F(),F()],F(1,2)),
      ('pressure','zero_tau',2,F(1),[P(0,0),P('1/4','1/4')],[F(1,3),F(2,3)],F()),
      ('pressure','full_source_zero_residual',1,F(1),[P(0),P('1/4')],[F(1,2)]*2,F(2)),
      ('pressure','full_feasible_nonzero_residual',1,F(1),[P(0),P(2)],[F(1,10),F(1)],F(19,20)),
      ('expanded','thin_and_zero_masses',1,F(1),[P(0),P('1/4'),P(2),P('9/4')],[F(1,1000),F(1),F(1,2),F()],F(1,4)),
      ('expanded','tensor_n4_dhalf',4,F(1,2),[P(0,0,0,0),P('1/8','1/8','1/8','1/8'),P('1/4','1/8',0,'3/8'),P(1,1,1,1)],[F(1),F(1,10),F(3,7),F(1,100)],F(1,2)),
      ('expanded','tensor_n8',8,F(1),[tuple(F((i*(j+1))%5,8) for j in range(8)) for i in range(6)],[F(1),F(1,2),F(1,3),F(1,4),F(),F(1,7)],F(1,5))]

def feasible_root(A,B,S):
    q=lambda t:A*t*t+B*t-S
    assert A>=0 and S>=0
    if A==0:
        t=min(F(1),S/B) if B>0 else F(1)
        assert q(t)<=0
        return t,t,'linear_or_zero_A'
    disc=B*B+4*A*S;rn,rd=isqrt(disc.numerator),isqrt(disc.denominator)
    if rn*rn==disc.numerator and rd*rd==disc.denominator:
        t=min(F(1),(-B+F(rn,rd))/(2*A));assert 0<=t<=1 and q(t)<=0
        return t,t,'exact_rational_root_or_clamp'
    if q(F(1))<=0:return F(1),F(1),'full_update_feasible'
    lo,hi=F(),F(1)
    for _ in range(192):
        mid=(lo+hi)/2
        if q(mid)<=0:lo=mid
        else:hi=mid
    assert q(lo)<=0<q(hi)
    return lo,hi,'exact_sign_bracket'

def numeric_root(A,B,S,dps):
    with mp.workdps(dps):
        a,b,s=fm(A),fm(B),fm(S)
        if not a:t=min(mp.mpf(1),s/b) if b>0 else mp.mpf(1)
        elif not s and b>=0:t=mp.mpf(0)
        else:
            root=mp.sqrt(b*b+4*a*s)
            t=min(mp.mpf(1),2*s/(b+root) if b>=0 else (-b+root)/(2*a))
        value=a*t*t+b*t-s;tol=mp.mpf(10)**(-dps+7);assert value<=tol
        if t<1:assert abs(value)<tol
        return {'t_star':enc(t),'quadratic_value':enc(value)}

def discrete(spec):
    phase,name,n,d,points,masses,tau=spec;N=len(masses)
    K=[[prod(max(F(),1-abs(x-y)/d) for x,y in zip(p,q))/d**n for q in points] for p in points]
    p=matvec(K,masses);theta=[min(F(1),tau/v) if v else F(1) for v in p];sigma=[x*y for x,y in zip(theta,masses)];r=[x-y for x,y in zip(masses,sigma)];E=energy(K,sigma);W=sum(sigma,F());S=tau*W-E
    schur=sum((m*t*(tau-t*v) for m,t,v in zip(masses,theta,p)),F());pair=sum((K[i][j]*(theta[i]-theta[j])**2*masses[i]*masses[j]/2 for i in range(N) for j in range(N)),F())
    assert all(0<=t<=1 and t*v<=tau for t,v in zip(theta,p)) and S==schur+pair and min(S,schur,pair)>=0
    maskchecks=0
    masks=list(product([F(),F(1)],repeat=N))+[(F(1,2),)*N,tuple(F(1+(i%2),3) for i in range(N))]
    for mask in masks:
        sub=[t*x for t,x in zip(mask,sigma)];assert energy(K,sub)<=tau*sum(sub,F());maskchecks+=1
    A=energy(K,r);C=dot(sigma,matvec(K,r));B=2*C-tau*sum(r,F());tl,th,branch=feasible_root(A,B,S);enlarged=[x+tl*y for x,y in zip(sigma,r)];newE=energy(K,enlarged);newW=sum(enlarged,F());q=A*tl*tl+B*tl-S
    assert newE-tau*newW==q and q<=0 and all(a<=b<=m for a,b,m in zip(sigma,enlarged,masses))
    if not any(r):assert A==B==0
    low,high=numeric_root(A,B,S,40),numeric_root(A,B,S,70)
    with mp.workdps(100):delta=max(abs(mp.mpf(low[k])-mp.mpf(high[k]))/max(1,abs(mp.mpf(high[k]))) for k in low);assert delta<mp.mpf('1e-25')
    return {'phase':phase,'name':name,'scope':'Finite atomic tent-kernel algebra only, not L1 evidence. Initial hereditary masks checked; enlarged source not asserted hereditary.','outside_tau_positive_theorem':tau==0,'zero_measure_diagnostic':sum(masses,F())==0,'n':n,'d':str(d),'tau':str(tau),'points':[vec(x) for x in points],'source_masses':vec(masses),'K_exact':[vec(row) for row in K],'p_exact':vec(p),'theta_exact':vec(theta),'sigma_exact':vec(sigma),'residual_exact':vec(r),'W0_exact':str(W),'E0_exact':str(E),'slack_exact':str(S),'slack_decomposition':{'schur':str(schur),'pair_difference':str(pair)},'A_exact':str(A),'cross_C_exact':str(C),'B_exact':str(B),'feasible_t_lower_exact':str(tl),'root_upper_exact':str(th),'root_branch':branch,'new_sigma_rational_exact':vec(enlarged),'new_mass_exact':str(newW),'new_energy_exact':str(newE),'new_budget_slack_exact':str(-q),'initial_hereditary_mask_checks':maskchecks,'mp40':low,'mp70':high,'max_scaled_precision_difference':enc(delta)}

def uniform(tau_s,dps):
    with mp.workdps(dps):
        tau=mp.mpf(tau_s);a=mp.sqrt(mp.mpf('.75'));c=mp.atanh(mp.mpf('.5')/a)
        G=(lambda x:x) if tau>=mp.mpf('.75') else (lambda x:tau/a*(mp.atanh((x-mp.mpf('.5'))/a)+c))
        E=lambda H,Z:Z*Z-2*mp.quad(lambda x:H(x)*(Z-H(x)),[0,mp.mpf('.5'),1])
        W=G(1);Wr=1-W;Eg=E(G,W)
        if Wr==0:Er=C=mp.mpf(0)
        else:
            Er=E(lambda x:x-G(x),Wr);C=(mp.mpf(2)/3-Eg-Er)/2
        S=tau*W-Eg;B=2*C-tau*Wr;tol=mp.mpf(10)**(-dps+7)
        assert S>=-tol and Er>=-tol
        if Wr==0:t=mp.mpf(1);branch='full_source_zero_residual'
        elif Er==0:t=min(1,S/B) if B>0 else mp.mpf(1);branch='linear_A_zero'
        elif S==0 and B>=0:t=mp.mpf(0);branch='zero_root'
        else:
            root=mp.sqrt(B*B+4*Er*S);t=min(1,2*S/(B+root) if B>=0 else (-B+root)/(2*Er));branch='root_or_full_update'
        W1=W+t*Wr;E1=Eg+2*t*C+t*t*Er;terminal=E1-tau*W1
        assert 0<=t<=1 and W<=W1<=1+tol and terminal<=tol
        if Wr and t<1:assert abs(terminal)<tol
        if Wr and S>0:assert t>0 and W1>W
        # Full source is feasible at tau=.75; its terminal slack is not zero.
        if Wr==0:assert abs(Eg-mp.mpf(2)/3)<tol
        return {'branch':branch,**{k:enc(v) for k,v in {'tau':tau,'W0':W,'residual_mass':Wr,'E0':Eg,'slack':S,'A_residual_energy':Er,'cross_C':C,'B':B,'t_star':t,'W1':W1,'E1':E1,'terminal_E_minus_tauW':terminal,'mass_gain':W1-W}.items()}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));args=ap.parse_args();cert=rational_L1();ds=[discrete(c) for c in fixtures()];us=[];maximum=mp.mpf(0)
    for t in ['.1','.25','.5','.75']:
        lo,hi=uniform(t,40),uniform(t,70)
        with mp.workdps(100):delta=max(abs(mp.mpf(lo[k])-mp.mpf(hi[k]))/max(1,abs(mp.mpf(hi[k]))) for k in lo if k!='branch');assert delta<mp.mpf('1e-25');maximum=max(maximum,delta)
        us.append({'tau':t,'source':'mu=1_[0,1]dx; n=d=1, genuine L1','mp40':lo,'mp70':hi,'max_scaled_precision_difference':enc(delta)});print(t,hi['W0'],hi['t_star'],hi['W1'],flush=True)
    with mp.workdps(100):maximum=max([maximum]+[mp.mpf(x['max_scaled_precision_difference']) for x in ds])
    out={'source_sha256':sha(__file__),'contract_sha256':sha(args.contract),'dependencies':{'python':'3.12.14','mpmath':mp.__version__},'scope':'One exact rational genuine L1 enlargement certificate, finite atomic positive-kernel algebra diagnostics and ordinary non-interval uniform-interval quadrature. Initial hereditary budget is not automatically inherited after enlargement. No optimal extraction, FULL, residual payment or dimension-order inference.','rational_L1_certificate':cert,'discrete_cases':ds,'uniform_interval_cases':us,'counts':{'rational_L1_certificates':1,'rational_certificate_arithmetic_checks':cert['exact_arithmetic_checks'],'finite_atomic_cases':len(ds),'atomic_initial':3,'atomic_pressure':4,'atomic_expanded':3,'initial_hereditary_mask_checks':sum(d['initial_hereditary_mask_checks'] for d in ds),'exact_quadratic_updates':len(ds),'uniform_L1_quadrature_cases':len(us)},'precision_summary':{'max_scaled_difference':enc(maximum),'normalizer':'max(1,abs(high)); enc50 mp40/mp70, not a directed error enclosure'}}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(out['counts']);print(out['precision_summary'])
if __name__=='__main__':main()
