# R253：连续抽取的核查与共同尺度增量的剩余缺口

## RG1　范围与本轮结论

本稿保留原非负有限 (L^1) 来源 (\mu\le f\)、真实接收域 (E\)、共同选择器 (R(x)\in[a,b]\)、(0<a\le b\le2a\)，以及 (X=\lambda|E|\)。原硬帽只施于 (M_{[a,b]}f\) 或其真正子来源，不施于分别取最大值后的来源和。

本轮核查通过主代理提出的连续抽取接口；继而证明任意互不交尺度区间的、**与区间个数无关但仍为线性 (n)** 的平方增量基线。大尺度窗部分可按根阶支付；小尺度窗仍需共同重叠抵消。未证明所希望的统一 (C\sqrt n\) 增量界，也未获得高质量残余的普遍根阶付款。以下费用不作为已闭合的新根阶理论。

## RG2　平移平均及一次连续抽取

令 (d>0\)，(K_d=h_d*h_d\)，
\[
 \eta_d(1+\eta_d)=32d^2/a^2,\qquad S_d=(1+\eta_d)^n,
 \qquad \mathscr E(\mu)=\|h_d*\mu\|_2^2.
\]
对边长 (d\) 网格的平移在 ([0,d)^n\) 中均匀平均，两个点落在同一胞的概率为
\(\prod_i(1-|y_i-z_i|/d)_+\)。因此 R252 的胞能量精确平均为
\[
 \mathbb E_{\rm shift}\sum_C\mu(C)^2/d^n
 =\iint K_d(y-z)\,d\mu(y)d\mu(z)=\mathscr E(\mu).
\]
由 R252 全尺度界逐平移成立，
\[
 \|M_{[a,b]}\mu\|_2^2\le3e^2nS_d\mathscr E(\mu).\tag{RG2.1}
\]
所有积分非负，Tonelli 合法；这不是给实际来源重选分布。

令 (p=K_d*\mu\)，(\tau=\lambda/(\sqrt nS_d)\)，
\(\vartheta=\min(1,\tau/p)\)，在 (p=0\) 时约定 (\vartheta=1\)。设置 (\nu=\vartheta\mu\)。对称核及 (2uv\le u^2+v^2\) 给
\[
 \mathscr E(\nu)\le\int\vartheta(y)^2p(y)d\mu(y)
 \le\tau\|\nu\|_1.
\]
故
\[
 \int_Eh_{R(x)}*\nu\le\varepsilon X+
 \frac{3e^2}{4\varepsilon}\sqrt n\|\nu\|_1.\tag{RG2.2}
\]
这一结论由主代理提出并负责主稿证明；此处仅独立核验。对原后验等额外结构没有重新授予 cut 或 rank 资格。

## RG3　重复抽取的准确短账：不授几何衰减

若使用同一 (d,\tau\) 重复该抽取，记
\[
 \mu_{k+1}=(1-\vartheta_k)\mu_k,\quad
 \nu_k=\vartheta_k\mu_k,\quad a_k=\|\nu_k\|_1,
 \quad W_k=\|\mu_k\|_1,\quad E_k=\mathscr E(\mu_k).
\]
核非负且 (\nu_k\le\mu_k\)，故
\[
 E_k-E_{k+1}
 =2\langle\nu_k,K_d*\mu_k\rangle-\mathscr E(\nu_k)
 \ge\langle\nu_k,K_d*\mu_k\rangle
 \ge\tau W_{k+1}.
\]
最后一步逐点成立：若 (p_k>\tau\)，则 \(\vartheta_kp_k=\tau\ge\tau(1-\vartheta_k)\)；其余点的剩余来源为零。于是
\[
 \sum_{k=0}^{L-1}W_{k+1}\le E_0/\tau,\qquad
 W_L\le E_0/(\tau L).\tag{RG3.1}
\]
这不是几何衰减。累计抽取 (\sigma_L=\sum_{k<L}\nu_k=\mu_0-\mu_L\) 的能量，由 Hilbert 空间三角不等式得
\[
 \mathscr E(\sigma_L)
 \le\tau\Big(\sum_{k<L}\sqrt{a_k}\Big)^2
 \le\tau L(W_0-W_L).
\]
可只付一次接收误差：
\[
 \int_Eh_{R(x)}*\sigma_L\le\varepsilon X+
 \frac{3e^2\sqrt n}{4\varepsilon}
 \Big(\sum_{k<L}\sqrt{a_k}\Big)^2.\tag{RG3.2}
\]
不能把最后的平方和免费换成 (W_0\)。即使 RG3.1 确有能量下降，它也没有同时偿还 RG3.2 的轮数费用。

若原 \(E\) 上 \(M_{[a,b]}f\le4\lambda\)，对 (\mu_L\) 使用固定粗胞的 R251 单簇及 R249 局部弱和，所有胞仍为原来源限制。设质量向量为 (m^L\)，邻居质量为 (M_i^L\)，余价准确为
\[
 \frac{4c_d}{\varepsilon_h}\sum_i m_i^L
 [3+2\log2+2\log(M_i^L/m_i^L)],\qquad
 c_d=2+n\log(1+d/a),
\]
并再付 (\varepsilon_hX\)。局部熵 (\sum_i m_i\log(M_i/m_i)\) 是质量向量的非负、凹、一次齐次函数，故对正拆分 (m=u+v\)，其值至少为两部分之和；余熵确实不增。但这不把余熵变成常数倍来源质量。本稿不继续展开这一未闭合递归。

## RG4　真正待提升的共同尺度命题

以下不涉及改变来源。固定一个边长 (d\) 网格，记
\(\mathcal E_d=\sum_C\mu(C)^2/d^n\)。R252 给所有 (R\in[a,b]\) 的统一界
\[
 E(R):=\|h_R*\mu\|_2^2\le S_d\mathcal E_d.\tag{RG4.1}
\]
目标是对任意有限组互不交区间 ([s_j,t_j]\subset[a,b]\) 证明
\[
 \sum_j\|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le C\sqrt n\,S_d\mathcal E_d.\tag{RG4.2, 未证}
\]
允许区间端点相接；相等端点的零区间可删。这个命题弱于任意符号增量 multiplier 界，且比逐窗固定尺度控制强。它若成立，结合 R252 的 dyadic prefix 分解与合法 (e^{1/n}\) 网格，确会给 (O(\sqrt n\log^2(n+2))\) 的全尺度平方范数费。不能因单尺度已证而授予 RG4.2。

## RG5　无区间数费用的严格线性基线

对于 (s\le t\)，令 (q_{s,t}=(s/t)^n\)。原正核满足
\(h_t*\mu\ge q_{s,t}h_s*\mu\)。因此
\[
 \|(h_t-h_s)*\mu\|_2^2
 \le E(t)-E(s)+2(1-q_{s,t})E(s).\tag{RG5.1}
\]
给任意互不交区间补齐 ([a,b]\) 内的空隙，所得完整有限分割的平方增量和只会增大。对这个分割将 RG5.1 相加；能量差 telescopes，且
\(1-(s/t)^n\le n\log(t/s)\)。得到
\[
 \boxed{\sum_j\|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le[1+2n\log(b/a)]S_d\mathcal E_d.}\tag{RG5.2}
\]
此界不依赖窗数或最小窗长，不需要对尺度求面导数。也可平移平均右边，换为 (S_d\mathscr E(\mu)\)。但它仍是线性 (n\)，不足以达 RG4.2。

还有一个已完全支付的组成部分：长度满足 \(\log(t_j/s_j)\ge n^{-1/2}\) 的窗数至多 \(\lfloor\sqrt n\log(b/a)\rfloor\)。因两个响应均非负，单窗平方差不超过 (E(s_j)+E(t_j)\)。故
\[
 \sum_{\log(t_j/s_j)\ge n^{-1/2}}
 \|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le2\sqrt n\log2\,S_d\mathcal E_d.\tag{RG5.3}
\]
这里没有将余下的小窗免费丢掉；RG5.3 不是整个原交通的新根阶付款。

## RG6　短窗的精确共同来源缺口

定义不改变任何来源的共同重叠剩余
\[
 L_{s,t}(\mu)=\langle h_s*\mu,h_t*\mu\rangle
                 -(s/t)^nE(s)\ge0.
\]
有精确恒等式
\[
 \|(h_t-h_s)*\mu\|_2^2
 =E(t)-E(s)+2(1-(s/t)^n)E(s)-2L_{s,t}(\mu).\tag{RG6.1}
\]
对于完整分割，端点能量差已按 (S_d\mathcal E_d\) 支付。要从 RG5.2 降到根阶，需要证明真实 cross overlap 至少抵消
\(\sum(1-(s/t)^n)E(s)\) 中除 (O(\sqrt nS_d\mathcal E_d)\) 外的部分。不能在 RG6.1 中删去最后一项后声称获得该抵消。

该对象可直接由两槽几何计算。对 (v=y-z\)，
\[
 (h_s*h_t)(v)=\prod_{i=1}^n
 \frac{\min\{s,t,((s+t)/2-|v_i|)_+\}}{st},
\]
且
\[
 E(R)=\iint\prod_i\frac{(R-|y_i-z_i|)_+}{R^2}
                  \,d\mu(y)d\mu(z).
\]
这些公式保留同一实际来源对；cross 不是两个独立最坏包络。单个自卷积核随 (R\) 的单峰性并不直接给 RG6.1 所需的 cross 下界。平缓响应需要 cross 抵消，迅速衰减响应则可由端点能量变化支付；本轮尚未统一这两个机制。最早缺口正是该短窗联合重叠下界，而不是未定义的抽象最优值、免费来源熵或新的 posterior。

## RG7　本机核验与停止范围

实际执行 Python Fraction 检查：

1. 三个有限对称非负三角核数据，每个做四轮连续抽取；分别检查单轮能量帽、能量下降、累计能量及来源守恒，共 48 条有理断言通过。该检查核验代数，不是原 FULL 的数值实例。
2. 原 cube pair-overlap 公式在维数 (n=1,2,4\)，三点位置 (y^{(j)}_i=j(i+1)/11\)、质量 (1,2,3/2\)、连续尺度 (1,5/4,3/2,2\) 下，检查 (L_{s,t}\ge0\)、平方差非负、RG6.1 及分割求和恒等式，共 30 条有理断言通过。有限原子用于核验连续核公式，不据此授予原 (L^1\) 交通的全部资格。

一般证明见 RG2–6；有限检查不替代证明。本轮未新增原一般根阶预算。已证工具是连续抽取的精确残量账、区间数无关的线性增量基线及大窗根阶部分；短窗 cross 抵消仍未证，递归误差与高剩余局部熵也没有被宣布免费。到此停止，不另建假设或展开反例搜索。


## RG8　RG7 的完整最小复现代码

以下是 RG7 实际所用的三组抽取数据及三个维数的 pair 核检查，不扩大检查范围。只使用 Python 标准库；两个计数分别为 48 和 30。

```python
from fractions import Fraction as F

cases = [
    ([F(0), F(1, 4), F(1, 2)], [F(3), F(1), F(2)], F(1)),
    ([F(0), F(1, 2), F(2)], [F(1, 4), F(4), F(1)], F(1, 2)),
    ([F(0), F(1, 3), F(2, 3), F(1)],
     [F(1), F(2), F(3), F(4)], F(2)),
]
checks = 0
for ci, (x, m, tau) in enumerate(cases):
    K = [[max(F(0), 1 - abs(u - v)) for v in x] for u in x]
    def energy(a):
        return sum(a[i] * K[i][j] * a[j]
                   for i in range(len(a)) for j in range(len(a)))
    initial = m[:]
    removed = [F(0)] * len(m)
    for step in range(1, 5):
        p = [sum(K[i][j] * m[j] for j in range(len(m)))
             for i in range(len(m))]
        theta = [min(F(1), tau / v) if v else F(1) for v in p]
        cut = [theta[i] * m[i] for i in range(len(m))]
        nxt = [m[i] - cut[i] for i in range(len(m))]
        removed = [removed[i] + cut[i] for i in range(len(m))]
        assert energy(cut) <= tau * sum(cut)
        checks += 1
        assert energy(m) - energy(nxt) >= tau * sum(nxt)
        checks += 1
        assert energy(removed) <= step * tau * sum(removed)
        checks += 1
        assert all(initial[i] == removed[i] + nxt[i]
                   for i in range(len(m)))
        checks += 1
        m = nxt
    print("finite symmetric-kernel case", ci + 1, "4 rounds PASS")
print("extraction exact rational assertions", checks)

scales = [F(1), F(5, 4), F(3, 2), F(2)]
checks = 0
for n in (1, 2, 4):
    pts = [tuple(F(j * (i + 1), 11) for i in range(n))
           for j in range(3)]
    mass = [F(1), F(2), F(3, 2)]
    def inner(s, t):
        ans = F(0)
        for y, my in zip(pts, mass):
            for z, mz in zip(pts, mass):
                val = F(1)
                for yi, zi in zip(y, z):
                    length = max(F(0), min(s, t, (s + t) / 2 - abs(yi - zi)))
                    val *= length / (s * t)
                ans += my * mz * val
        return ans
    total = F(0)
    compensation = F(0)
    for s, t in zip(scales, scales[1:]):
        Es, Et, cross = inner(s, s), inner(t, t), inner(s, t)
        q = (s / t) ** n
        surplus = cross - q * Es
        increment = Es + Et - 2 * cross
        assert surplus >= 0
        checks += 1
        assert increment >= 0
        checks += 1
        assert increment == Et - Es + 2 * (1 - q) * Es - 2 * surplus
        checks += 1
        total += increment
        compensation += 2 * ((1 - q) * Es - surplus)
    assert total == (inner(scales[-1], scales[-1])
                     - inner(scales[0], scales[0]) + compensation)
    checks += 1
    print("cube pair kernel", n, "PASS")
print("pair-kernel exact rational assertions", checks)
```
