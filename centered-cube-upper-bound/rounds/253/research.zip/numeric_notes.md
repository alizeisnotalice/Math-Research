# R253：有理L1放大证书、有限正核代数及真实区间求积

实际完成：1个真正L1的CE7有理证书（8项算术检查）；10个离散tent-kernel模型（初探3、压力4、扩大3），164个初始hereditary mask检查及10个exact quadratic更新；同一真实uniform interval的4个tau，以mp40/70求积。源码独立，不读取旧轮脚本或结果。成功仅为严格有理小例与可复现诊断，未付残余、未证明一般维数阶、FULL/history或最优提取。

## 初探：真正L1证书

mu=1_[0,1]dx，n=d=a=1,b=2,tau=1/2。K_1(x-y)=1-|x-y|在此source support上非负，p(x)=1/2+x-x²，theta0=(1/2)/p。

X=[0,1/16]上p递增，所以theta>=128/143>=8/9。Y=[7/16,9/16]上p最小值191/256，所以theta<=128/191。Fraction核

8/9-128/191>1/5，K|X×Y>=7/16。

初始Schur条件饱和，slack的pair-difference项在X×Y及Y×X上给S>=7/51200。两个对称矩形恰抵消1/2因子。r=(1-theta0)mu，原K<=1、sigma/r质量<=1，故可用保守A<=1、B<=2。显式t=1/16384满足

t²+2t<7/51200<=S。

因此sigma0+t r仍是原mu的正子来源，并严格满足同一energy/mass预算。另r质量>= (1/8)(1-128/191)>1/32，所以mass严格增加超过1/524288。程序同时核原uniform energy=1/3+1/3=2/3。证书是有限有理不等式加此实际区间几何，不依赖后面的浮点求积或点源极限。

JSON保存X/Y界、K界、slack lower、rational t、剩余slack lower及mass gain bound。它证明一个严格放大，不证明全残余已付、固定方向外的优化或放大后hereditary。

## 压力及扩大：有限离散代数

K_ij=d^-n product_l(1-|x_il-x_jl|/d)_+，即真实tensor tent的有限atomic kernel。输入虽有几何坐标，但这些finite atoms不是正L1来源证据；扩大n4/n8也只是有限代数，不据其拟合维数阶。

初探3例为n1重叠、n2 constant-theta、n3相关点。压力4例包括zero source、tau=0、full source且r=0，以及原全来源已满足energy budget但初始r非零。扩大3例包含稀薄/零mass点、n4 d1/2异质点、n8相关点。全部坐标、mass、tau、d及K逐项保JSON。

对每例精确计算theta=min(1,tau/p)，p=Kmu。p=0定义theta=1（zero-mass槽无影响）。核0<=theta<=1及theta p<=tau，并核slack分解

S=tau W0-E(sigma0)
 =sum_i mi theta_i(tau-theta_i p_i)
  +(1/2)sum_ij Kij(theta_i-theta_j)^2 mi mj。

两项均Fraction非负。枚举binary masks，另加half和1/3、2/3 masks，共164项，核初始子来源eta<=sigma0的E(eta)<=tau mass(eta)。有限枚举不替代一般hereditary证明。

残余r=mu-sigma0，A=E(r)、C=<sigma0,Kr>、B=2C-tau mass(r)。用q(t)=At²+Bt-S核放大：perfect rational discriminant直接开方；否则q(1)<=0取1；其余以192次Fraction二分保存q(tlow)<=0<q(thigh)的精确根括号。实际有理更新用tlow，逐项核sigma0<=sigma_new<=mu，以及

E(sigma_new)-tau mass(sigma_new)=q(tlow)<=0。

这个exact sign bracket不是普通浮点区间库的认证声明。mp40/70另外求完整quadratic root：interior/zero root核equality误差，full/clamp分支只要求inequality。

退化口径：tau=0明确标outside_tau_positive_theorem，不能作为tau>0定理实例。zero_source也标zero_measure_diagnostic。constant-theta_n2有S=0但r非零，tstar=0，未强称处处严格增益；r=0时A=B=0，tstar=1仅为无影响约定。full_feasible_nonzero_residual取tstar=1、mass增1/20，说明clamp分支未被当root equality。

放大后的总energy可行不自动hereditary：既有full_feasible_nonzero_residual例取两点0、2、原masses1/10和1、tau19/20。更新至原全来源，energy可行；但只取mass1的第二点子来源，E=1>19/20，超额1/20。此既有数据的额外Fraction核验也实际执行，未新增模型或并入164项初始mask数。它只是离散代数说明，不能当连续原理论反例。

## 扩大：真实uniform interval的40/70位求积

四个tau为0.1、0.25、0.5、0.75；tau0.5与上面CE7是同一个物理来源，不把它重复当另一严格L1证明。p(x)=3/4-(x-1/2)²，tau<=1/2时累计函数为

G_tau(x)=tau/sqrt(3/4) * [atanh((x-1/2)/sqrt(3/4))+atanh((1/2)/sqrt(3/4))]。

用CE8精确identity E(g)=Z²-2 integral_0^1 G(x)(Z-G(x))dx，在0,1/2,1处分片实际求积；同法算residual energy，polarization算cross项。没有无限尾截断。root公式按符号采用稳定等价表达以避免小slack消减。

|tau|W0|S0|tstar|W1|
|---:|---:|---:|---:|---:|
|0.1|0.152069199260|0.000194174116031|0.00225088610002|0.153977794913|
|0.25|0.380172998150|0.00121358822519|0.00761502418371|0.384892995759|
|0.5|0.760345996301|0.00485435290077|0.0370305617186|0.769220518676|
|0.75|1|1/12|1|1|

前三例初始残余非零、slack正，实际root给正mass增量；终端E1-tau W1在40/70位输出均打印0，这是ordinary rounding，不是精确equality证明。tau0.75时theta=1几乎处处，r=0、A=C=B=0；累计函数G=x，全source energy=2/3<=3/4。此分支终端slack为1/12，E1-tau W1=-1/12，不要求零误差。它不能用有残余的root除法处理。

浮点最大字段差/max(1,abs(high))=1.237671156e-41，enc50保实际工作精度差。quad为普通mpmath而非directed interval；严格L1增益来自前面的有理矩形证书，不来自数字一致性，也不由这4点推任何阶数或全局优化结论。

## 实际运行、依赖与完整复现

本机实际完成独立脚本完整运行，并对既有放大离散例的非hereditary子来源另核1/20超额。父级已实际运行当前代码至包外临时JSON；最终冻结后还将由父级完整归档重放。不为timing重复执行。

仅Python标准库+mpmath；Python3.12.14使用bundled executable，mpmath1.3.0来自vendor。无numpy/scipy/MATLAB/QP依赖。在解压后的同一目录（numeric_checks.py与task_contract.md）执行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json
cmp numeric_checks.json replay.json
```

CLI默认相邻numeric_checks.json和task_contract.md，支持--output/--contract迁移。JSON无runtime、时间戳或绝对路径；绑定源码及合同SHA，完整source/kernel及精确root账可独立检查。counts：rational_L1_certificates1、rational_certificate_arithmetic_checks8、finite_atomic_cases10（3/4/3）、initial_hereditary_mask_checks164、exact_quadratic_updates10、uniform_L1_quadrature_cases4。

冻结source SHA256：209b2ed1d89c439c8226503ee9109c00b10fa6b0858900fe93f4cb9fe002dd37；JSON39828字节、SHA256：3e5d312b1a82169e0c69ddfdc1aca0c0af68512498672f21cb5d2102357f5172；合同SHA256：0e3ea53cfb18c234479fd0728b2c296e23529b03b9b6d23a760efc7976ab2492。
