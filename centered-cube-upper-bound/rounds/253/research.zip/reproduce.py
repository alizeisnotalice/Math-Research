#!/usr/bin/env python3
"""Verify every frozen member, rerun diagnostics, and compare exact JSON bytes."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,re
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,expected in manifest['sha256'].items():
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==expected,(name,actual,expected)
print('manifest PASS',len(manifest['sha256']))
with tempfile.TemporaryDirectory(prefix='cube-r253-replay-') as tmp:
    output=Path(tmp)/'numeric_checks.json'
    subprocess.run([sys.executable,str(root/'numeric_checks.py'),'--output',str(output)],check=True)
    assert output.read_bytes()==(root/'numeric_checks.json').read_bytes(),'numeric JSON differs'
    print('numeric JSON byte-identical PASS')
    for name in ['continuous_extraction.md','residual_geometry.md']:
        blocks=re.findall(r'```python\n(.*?)```',(root/name).read_text(),re.S)
        assert blocks,('missing embedded reproduction',name)
        for i,block in enumerate(blocks):
            script=Path(tmp)/(name+'.'+str(i)+'.py')
            script.write_text(block)
            subprocess.run([sys.executable,str(script)],check=True)
        print('embedded checks PASS',name,len(blocks))
for name,expected in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
print('post-replay hashes PASS; no PDF compilation')
