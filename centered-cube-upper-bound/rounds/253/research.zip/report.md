# 第253轮：平移平均与连续来源增抽

## 新增证明与适用范围
任意有限非负L1原来源、任意0<a<=b<=2a、任意d>0，R252网格采样能量的平移平均恰为三角核自交能量。定义原来源势p=K_d*mu，用theta=min(1,tau/p)连续提取；初始证书对所有原始子来源zeta<=mu可遗传。该提取可接已有合法正硬响应槽，价格为epsilon X+3e² sqrt(n) mass/(4epsilon)，完整尺度费已计入tau。
精确pair-difference余量允许显式二次根扩大提取，而不重复支付接收误差。这里同价指同一tau和单位质量系数，最终来源费用仍按扩大后的质量计算。实际L1区间来源给严格有理增量>1/524288；这证明构造确有严格增益，不表示一般高残余已付。扩大后的证书不自动遗传，共同beta/nu须各自认证同一更新并取最小根。

## 原积分接入与剩余式
只对已合法支配的正硬响应，有 integral_E h_R*mu <= epsilon X+3e²sqrt(n)||sigma'||/(4epsilon)+integral_E h_R*(mu-sigma')。最后一项未付。原实际dx、选择器、来源比例、门和历史不改变。
R222 SOCC11显式硬来源已付，不再对其额外收费；这里保硬核路线是另一个工具接口。R223 signed恢复、边界和储备仍须同原测度合并，不借用或重领原负信用。来源父账到完整输入质量桥未由本轮新授。

## 一般尺度几何的下一准确缺口
对任意不交[s_j,t_j]，已证窗数无关O(n)平方增量界；log(t_j/s_j)>=1/sqrt(n)的长窗有O(sqrt(n))界。短窗保留真实cross surplus L_st=<h_s*mu,h_t*mu>-(s/t)^n||h_s*mu||²。缺少它与端点能量变化联合抵消线性bulk到根阶的统一估计。此处未用反例否定路线，未把未付矩命名为预算。

## 限制与失败记录
固定d重复抽取确有能量下降和尾质量O(1/L)，但总接收费用含(sum sqrt(W_j))²；跨d有限J项可产生J费用。不能免费声称几何收缩、无限提取或仅对数层数。初始势提取与后续总能量扩大的遗传性质不同。所有数值只认证所列范围，不猜渐近阶。

## 建议材料与工具
用户明确材料可调整。已读TXT及PDF全部8页文本提取（公式字形缺失，不据提取猜公式），状态从其R223更新至R252；优先新增实际来源预算，保持其原signed信用限制。未编译PDF。使用本机Python Fraction及mpmath；N04技能用于有限求和和误差预算核查，未借技能名假定新定理。
- /Users/zhengzhihao/Library/Containers/com.tencent.xinWeChat/Data/Documents/xwechat_files/wxid_2ypj2h60ogms22_45c1/msg/file/2026-10/Pro续研提示词_余下攻坚建议_20261016(1).txt: SHA256 6e4b8f7eaea723f14a47ea81af498acae23e38d7545f42c53bafc0e5ec371e86
- /Users/zhengzhihao/Library/Containers/com.tencent.xinWeChat/Data/Documents/xwechat_files/wxid_2ypj2h60ogms22_45c1/msg/file/2026-10/中心立方体上界_余下攻坚路线建议_20261016(1).pdf: SHA256 66b1b8940564023958b06fb785443f1fdd071f244f5f83fd3422e5d3d420098b

## 复现与审核
最终计算范围、实际结果见numeric_notes.md及numeric_checks.json；证明独审见audit.md。reproduce.py验证归档哈希并重跑数值生成相同JSON。普通高精度积分不是区间证书；有理有限核模型不是FULL历史实例。无实际逐Agent扣额数据，不估计成本比。复用4个已存在Agent，未为凑人数启动额外Agent。

## 总状态
本轮是可严格支付的来源分数扩大和尺度几何接口推进。一般n^(1/2+o(1))一致弱型上界未闭合。高剩余来源、双后验/soft、共同历史总价、所有尺度及来源桥仍须完整结合；不宣称最终定理成立。
