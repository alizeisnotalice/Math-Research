# R253: continuous-shift energy and certified enlargement of a source fraction

Only the original positive source is fractionally extracted. No source
mass is moved or made uniform. The result pays an explicit extracted
part of a hard response; it does not pay the remaining high source or
the original double-posterior traffic without its own domination step.

## CE1. Continuous-shift identity and the real scale fee

Let mu be a finite nonnegative L1 source on R^n, W=||mu||, d>0,
0<a<=b<=2a, and lambda>0. Cubes have full side length d. Define

    h_d=d^-n 1_Q_d, K_d=h_d*h_d
       =d^-n product_i(1-|x_i|/d)_+,
    E_d(mu)=integral K_d(x-y)mu(dx)mu(dy)=||h_d*mu||_2^2.

For a half-open d-grid translated by s in [0,d)^n, write m_C(s)=mu(C).
The exact normalized shift identity is

    (1/d^n)integral_[0,d)^n sum_C m_C(s)^2/d^n ds=E_d(mu). (CE1)

For two fixed source points x,y, the probability of being in the same
shifted cell is product_i(1-|x_i-y_i|/d)_+. Expanding the square and
nonnegative Tonelli proves CE1. In particular every density inside a
cell is retained; a source that depends on the shift cannot be inserted
into CE1 as if it were fixed.

Put eta_d=(sqrt(1+128d^2/a^2)-1)/2 and S_d=(1+eta_d)^n.
R252's proved fixed-grid sampling inequality ([frozen proof S1--S2](/Users/zhengzhihao/Desktop/T/output/centered_cube_round252_20261017_final_checkpoint/proof.tex.txt:4)) applies to every shift,
with its exact factor at R>=a bounded by S_d. Its legal upward scale
grid has at most 3n nodes and comparison factor e. Consequently CE1
gives

    ||M_[a,b]mu||_2^2<=3e^2 n S_d E_d(mu).              (CE2)

This uses the established sampling theorem, not a new assertion that
the supremum has dimension-independent L2 cost. All 3n/e^2 scale
fees are retained. The fixed source may depend on mu,d and other
already fixed outer data, but not on this averaged shift.

## CE2. A measurable actual source fraction and its hereditary budget

The potential p=K_d*mu is nonnegative, bounded by d^-n W, and continuous:
K_d is bounded and uniformly continuous and mu is finite. Set

    tau=lambda/(sqrt(n) S_d),
    theta_0(x)=min(1,tau/p(x)) if p(x)>0,
    theta_0(x)=1 if p(x)=0,
    sigma_0=theta_0 mu, W_0=||sigma_0||.                (CE3)

Thus theta_0 is measurable, 0<=theta_0<=1, and theta_0 p<=tau
everywhere. The p=0 convention never divides by zero and gives zero
in theta_0^2 p. Symmetry and 2uv<=u^2+v^2 yield

    E_d(sigma_0)<=integral theta_0(x)^2 p(x)mu(dx)
                             <=tau W_0.               (CE4)

Combining CE2--4 gives the actual root-priced extracted source:

    ||M sigma_0||_2^2<=3e^2 lambda sqrt(n) W_0,
    integral_E (h_{R(x)}*sigma_0)(x)dx
        <=epsilon X+(3e^2/(4epsilon))sqrt(n) W_0,       (CE5)

for every measurable finite E, X=lambda|E|, epsilon>0 and actual
measurable R(x) in [a,b]. Young's scalar inequality and CE2 give
the bound without assuming a receiver cap. The original source
decomposes exactly as sigma_0+(1-theta_0)mu. These are analysis
components of the original source: an original posterior built from
the whole source is not rebuilt from sigma_0. Application to a traffic
slot still requires its true positive hard-response domination.

An important stronger qualification holds: for every positive measure
zeta<=mu the same fraction satisfies

    E_d(theta_0 zeta)<=tau||theta_0 zeta||.              (CE6)

Indeed K_d*zeta<=p, and the proof of CE4 applies with zeta. Hence a
common fraction computed from an actual dominating beta can be applied
to nu<=beta and beta simultaneously, preserving both inequalities and
their pointwise coupling. This does not assert a new relation between
unrelated source histories.

## CE3. Exact unused energy slack and an explicit larger fraction

Write K=K_d and define its bilinear form by
<alpha,K gamma>=integral K(x-y)alpha(dx)gamma(dy).
There is an exact, nonnegative slack decomposition

    S_0:=tau W_0-E_d(sigma_0)
      =integral theta_0(tau-theta_0 p)dmu
         +(1/2)integral K(x-y)(theta_0(x)-theta_0(y))^2
                                                  mu(dx)mu(dy). (CE7)

This is intrinsic slack in the new kernel-energy certificate, not
negative credit from old traffic. Expanding the square proves CE7.
It is strictly positive when either displayed nonnegative term has
positive integral. No numerical sign is needed for this assertion.

Take any explicitly chosen residual subsource r<=mu-sigma_0, such as
the whole residual or its restriction to a fixed measurable patch.
Set

    A=E_d(r), B=2<sigma_0,K r>-tau||r||.

If r=0 do nothing. Otherwise A>0: a positive-mass cube of side less
than d contains positive r mass, and K is bounded below by a positive
constant on differences within that cube. Define

    t_* =min(1,(-B+sqrt(B^2+4A S_0))/(2A)),
    sigma_1=sigma_0+t_* r.                              (CE8)

All these quantities are finite. The formula includes S_0=0: it gives
zero for B>=0 and min(1,-B/A) for B<0. Direct quadratic expansion gives

    E_d(sigma_0+t r)-tau||sigma_0+t r||
                         =-S_0+B t+A t^2<=0,
                              0<=t<=t_*.               (CE9)

Thus sigma_1 remains an original positive subsource and has the same
root-price CE5 with its own larger mass. For the whole residual,
sigma_1=[theta_0+t_*(1-theta_0)]mu. If S_0>0 and the residual is nonzero,
t_*>0 and its extracted mass is strictly larger. This is an explicit
construction, not an infimum or an appeal to strong duality.

The argument can be iterated finitely, using the current slack and
current residual each time. Only the final total energy certificate
is inserted into CE2; previous extraction stages are not separately
charged or separately granted the same receiver error.

## CE4. A local source-potential augmentation and coupling limitation

Even when the current sigma<=mu has zero energy slack, a physical
residual patch with weak interaction can be added. Suppose

    E_d(sigma)<=tau||sigma||,
    r<=mu-sigma, K_d*sigma<=(tau-delta)/2 r-a.e., delta>0.

If r=0 do nothing. Otherwise B<=-delta||r||. Taking

    t=min(1,delta||r||/E_d(r))

gives E_d(sigma+t r)<=tau||sigma+t r||. The explicit measurable choice
r=(mu-sigma)|{K_d*sigma<=(tau-delta)/2} is allowed. It uses the true
source interaction, not independent coordinates or a new receiver gate.
The full quadratic root CE8 can be larger and is always available.

Unlike CE3's initial Schur condition, a total-energy enlargement is
not automatically hereditary for every zeta<=mu. To preserve a finite
list of actual coupled sources with a common fraction, compute their
individual slacks and quadratic roots for the same fractional update
and use the minimum root. Each source then has its own valid energy
certificate; if one root is zero there is no asserted common gain.
The common pointwise fraction preserves nu<=beta. This simultaneous
test cannot be omitted merely because the initial extraction had CE6.

## CE5. Exact physical threshold and what parameter optimization means

K_d is supported on Q_{2d}, so

    p(x)<=d^-n mu(Q_{2d}(x)).

In particular full retention is certified at every x satisfying

    mu(Q_{2d}(x))<=tau d^n
       =lambda/sqrt(n) [kappa(d)]^n,
    kappa(d)=d/(1+eta_d).                              (CE10)

The exact quantities satisfy

    kappa(d)^2=(a^2/32)eta_d/(1+eta_d),
    kappa'(d)=1/[(1+eta_d)(1+2eta_d)]>0,
    lim_{d->infinity}kappa(d)=a/sqrt(32).              (CE11)

Thus the old exponential relaxation of S_d can obscure the exact
local-mass threshold. However Q_{2d}(x) also grows with d. Neither
monotonicity of kappa nor its supremum makes the original source
qualify for CE10, and neither pays the high residual.

## CE6. Finite different scales: construction and nonfree aggregation

One may apply CE3 sequentially to actual residuals at any finite list
d_1,...,d_J, producing disjoint fractional sources sigma_j, masses W_j,
and E_dj(sigma_j)<=lambda W_j/[sqrt(n)S_dj]. Their pointwise fractions
sum to at most one. Thus the positive source is used once, but the
maximal receiver price for their sum is not automatically the sum of
their squared bounds. Minkowski and CE5 give the honest cost

    integral_E M(sum_j sigma_j)
       <=epsilon X+(3e^2/(4epsilon))sqrt(n)
                                           (sum_j sqrt(W_j))^2
       <=epsilon X+(3e^2 J/(4epsilon))sqrt(n)sum_j W_j. (CE12)

The displayed square can be strictly less than J sum W_j; neither
term is silently replaced by sum W_j. Alternatively keep one common
fraction and verify its total energy at one chosen d; CE8 then improves
that same certificate with no scale aggregation fee. These procedures
give explicit paid partial extractions, not a general conclusion that
all high-source mass can be exhausted at a bounded total price.
Summation over different outer histories or seeds also still requires
their original source-mass ledger; CE12 grants no new global mass cap.

## CE7. Strict enlargement for a genuine L1 source, with a rational certificate

Take n=1, d=a=1, b=2, mu=1_[0,1]dx, and tau=1/2. This corresponds
to the actual CE3 choice lambda=(1+sqrt(129))/4. On the source interval,

    p(x)=1/2+x-x^2, theta_0(x)=(1/2)/p(x).

The initial Schur condition is saturated there, so the slack in CE7
is exactly its nonnegative pair-difference integral. It is strictly
positive with the following elementary lower bound. On
X_0=[0,1/16] one has theta_0>=8/9. On Y_0=[7/16,9/16] one has
theta_0<=128/191. Their difference exceeds 1/5, and K_1(x-y)>=7/16
on X_0 times Y_0. Including the symmetric rectangle cancels the
factor 1/2 in CE7. Thus

    S_0>=(7/16)|X_0||Y_0|/25=7/51200.                (CE13)

Let r=(1-theta_0)mu. Since K_1<=1, its A<=1 and B<=2 are valid
conservative bounds. The explicit rational t=1/16384 satisfies

    A t^2+B t<=t^2+2t<7/51200<=S_0.

Hence sigma_0+t r has the same certified root energy, strictly. Also
||r||>=|Y_0|(1-128/191)>1/32, so this concrete update increases the
extracted original mass by more than 1/524288. This is a proved
strict gain, not a point-source limit or a numerical feasibility claim.
It illustrates the construction, not optimal extraction or a FULL
history instance. The full residual has not been declared paid.

## CE8. Bounded actual arithmetic checks and reproducibility

The exact rational inequalities in CE13 were checked with Python
Fraction. The same genuine L1 example was also evaluated locally in
mpmath 1.3.0 at 40 and 70 decimal digits. With the full quadratic-root
update CE8, both runs agreed on

    W_0 =0.760345996300946347531094,
    S_0 =0.00485435290076852015902867,
    t_* =0.0370305617186103735542831,
    W_1 =0.769220518676036232573073.

The terminal equality error |E_d(sigma_1)-tau W_1| was below 6e-42
at 40 digits and printed zero at 70 digits. These quadrature values
are ordinary finite numerical evidence. The actual proof of the
strict gain is CE13; no interval certification is claimed.

For a source density g supported in [0,1], with cumulative G and
mass Z, the exact identity used for the calculation is

    E_1(g)=Z^2-2 integral_0^1 G(x)(Z-G(x))dx.

It follows by writing K_1(x-y)=1-|x-y| on this source support. For
the uniform original source this equals 2/3, also the exact shift
average integral_0^1[s^2+(1-s)^2]ds in CE1. The code below reproduces
both the rational certificate and the numerical diagnostic.

```python
from fractions import Fraction as F
import mpmath as m
assert F(8,9)-F(128,191)>F(1,5)
Sbound=F(7,16)*F(1,16)*F(1,8)*F(1,25)
assert Sbound==F(7,51200)
t=F(1,16384)
assert t*t+2*t<Sbound
assert F(1,8)*(1-F(128,191))>F(1,32)
assert t/F(32)==F(1,524288)
assert F(1,3)+F(1,3)==F(2,3)
print('PASS 6 rational certificate checks')
for prec in (40,70):
 m.mp.dps=prec
 tau=m.mpf('0.5'); a=m.sqrt(m.mpf('0.75'))
 c=m.atanh(m.mpf('0.5')/a)
 G=lambda x:(m.atanh((x-m.mpf('0.5'))/a)+c)/(2*a)
 W=G(1); Wr=1-W
 E=lambda H,Z:Z*Z-2*m.quad(lambda x:H(x)*(Z-H(x)),
                              [0,m.mpf('.5'),1])
 Eg=E(G,W); Er=E(lambda x:x-G(x),Wr)
 C=(m.mpf(2)/3-Eg-Er)/2
 S=tau*W-Eg; B=2*C-tau*Wr
 tstar=min(1,(-B+m.sqrt(B*B+4*Er*S))/(2*Er))
 Wnew=W+tstar*Wr; Enew=Eg+2*tstar*C+tstar*tstar*Er
 assert S>0 and 0<tstar<1 and Wnew>W
 assert abs(Enew-tau*Wnew)<m.mpf(10)**(-prec+8)
 print('dps',prec,'W0',m.nstr(W,24),'slack',m.nstr(S,24),
       't',m.nstr(tstar,24),'Wnew',m.nstr(Wnew,24),
       'identityerr',m.nstr(abs(Enew-tau*Wnew),5))
```
