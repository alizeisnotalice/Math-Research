# R253 独立审核

## 命题先行筛查（目录/作者稿尚未出现）

在读取作者文件前按主代理准确命题独立推导。只负责audit.md，不改其他文件，不Git/PDF/spawn。n≥1，0<a≤b≤2a，d>0，µ为同一任意有限非负L1来源；λ>0、实际有限可测E和X=λ|E|在回代时保留。

### 1. 平均shift的能量恒等式：PASS

R252每个固定平移网格都合法。记平移s∈[0,d)^n，以ds/d^n归一平均，E_grid(s)=Σ_C µ(C_s)^2/d^n。两点y,z落入同胞的shift比例恰为∏(1−|y_i−z_i|/d)_+。正Tonelli给

`average_s E_grid(s)=∫∫K_d(y−z)µ(dy)µ(dz)=||h_d*µ||_2²=:E_d(µ)`，

其中K_d=h_d*h_d=d^(−n)∏(1−|v_i|/d)_+。d^n单位与归一shift均不可漏。由于M_[a,b]µ不依gridshift，对每shift的R252全尺度界积分即可得

`||M_[a,b]µ||²≤3e²n S_d E_d(µ)`，

S_d=(1+η)^n，η(1+η)=32d²/a²。节点上η_R≤η_a，故可保此S_d，不需替成exp上界。共同来源/共同R和已支付3n尺度数保留；没有为µ的各signed部分任意自由替换或推出新无价max。

### 2. 势抽取的同源分解：PASS

p=K_d*µ为非负有界可测函数（实际上连续），τ=λ/(√n S_d)>0。定义θ=min(1,τ/p)，p0处θ1；µ0=θµ，µh=(1−θ)µ均为真实原正子测度且µ0+µh=µ。权在receiver x和尺度前冻结，作为估计内分解，不裁剪原Π或算法来源。

仅用K对称非负及2θyθz≤θy²+θz²：

`E_d(µ0)≤∫θ²p dµ≤τ∫θ dµ=τW0`。

所以`||Mµ0||²≤3e²λ√n W0`，逐点F≤ελ+F²/(4ελ)给任意实际E/原R(x)下εX+3e²√nW0/(4ε)。high残余原样保留，无FIRST或接收帽新假设；只可接已授权由该正硬响应支配的原槽。

### 3. 准确下降方向：PASS

令Lθ=(1/2)∫∫K_d(y−z)(θy−θz)²µ(dy)µ(dz)≥0。有更精确恒等式

`E_d(µ0)=∫θ²p dµ−Lθ`，
`E_d(µ)−E_d(µh)=∫(2θ−θ²)p dµ+Lθ`。

因此主候选下界方向正确。在p≤τ时θ1，该单积分为p；在p>τ时为2τ−τ²/p≥τ，给

`Eµ−Eµh≥∫_{p≤τ}p dµ+τ µ{p>τ}`。

p0亦被正确覆盖。所有量有限：K_d≤d^−n、µ有限、θ∈[0,1]。这是新正能量账的下降，不是原N_del/N_Z信用退款，也不自动支付high来源。反复抽取若要覆盖全部来源，必须另付每轮ε_j X、来源重复计数和迭代总价，不能凭下降不等式就宣称一般root闭合。

本机实际运行25组有限正K矩阵Fraction诊断（5种源点数×5阈值），精确检查两个含Lθ的恒等式、E0≤τW0及分层drop下界，全PASS。它只核同一对称非负核上的代数，不是L1/FULL实例或解析证明替代。等待作者完整证明、主稿与最终数值范围。

## continuous_extraction.md 完整作者稿后审

受审SHA256：`e1a844f47a28d9abf0f6e6a8a36905c8f5f0ff568ef94c7076a5a314b7ce3869`。**CE1–8 PASS，无待修数学阻断。** 初始statement-screen已在读本稿前落盘；本节不等于本轮整体冻结，等待主稿及另一作者整合。

CE1归一shift identity与真实3n尺度费准确；固定source不能依被平均的shift。CE2 p有界连续、p0守卫、同一θ0对每ζ≤µ的hereditary E(θ0ζ)≤τ||θ0ζ||都成立；共同θ可保真实ν≤β的点态耦合，但不授不同历史的新关系或重建posterior。

CE3 slack两项非负且与独筛精确恒等式一致。r为任意实际residual子测度；r非零时E_d(r)>0由一小cube内正质量及K下界证明，二次根分母合法。S0=0时B两种符号、r0分支均正确；root区间完整，t*=min1(root)确保σ0+t*r≤µ且只最终总证书领一次εX。有限迭代不自动保持hereditary，但CE4已明确此限制。若要共同β/ν等多个原源继续增抽，必须对同一个fractional更新分别核slack与root并取min；一个root0则未授共同增益。

CE4 local patch门给B≤−δ||r||，t=min1(δ||r||/E r)使At²+Bt≤0，方向准确；δ>τ时正r一般不存在也不影响r0守卫。CE5 p≤d^−n µ(Q_2d)及full-retention资格正确。由η(1+η)=32d²/a²，κ²=(a²/32)η/(1+η)，且κ'=1/[(1+η)(1+2η)]，极限a/√32均准确。κ增并不抵消Q_2d扩大的实际mass要求。

CE6多d/外历史不能仅按W相加平方费用；本稿对同一最终sumsource使用Minkowski，保(sum√W_j)²≤JΣW_j，并只用一次整体Young误差，系数3e²/(4ε)√n准确。来源只使用一次不意味着跨尺度max或receiver误差免费。

CE7严格L1增抽例是解析有理证书：p=.5+x−x²≥τ=.5，故初始slack仅pair-difference项。X/Y两矩形的θ差>1/5、K≥7/16及对称抵消1/2给S0≥7/51200；A≤1、B≤2为保守上界，t=1/16384满足At²+Bt<S0。residual mass>1/32，所以实际原质量增益>1/524288。λ=(1+√129)/4恰使τ=λ/Sd=.5，不是另换阈值。此例未认证原FULL历史或high全付。

本独审实际从CE8抽取全部代码运行，输出`PASS 6 rational certificate checks`；mp40/70两次quad均得W0=.760345996300946347531094、S0=.00485435290076852015902867、t*=.0370305617186103735542831、W1=.769220518676036232573073。终端等式误差mp40为5.7397e−42、mp70打印0，匹配作者。有限quad不是区间证书；严格增益依CE7，不靠这些小数。CE8累计函数及E(g)=Z²−2∫G(Z−G)的归一系数正确。

## residual_geometry 与主P1–P6后审

residual_geometry受审SHA256：`802e28876a7b5d525c4a3492322df8502922d3c3fb552e01cdc2efa2c037f2ba`。**RG2–6与当前主稿P1–P6全部PASS。**

RG3中E_k−E_k+1=2<νk,Kµk>−Eνk≥<νk,Kµk>≥τW_k+1，正核及真实subsource给两次方向正确。W递减故W_L≤E0/(τL)。累计σ_L费用保(sum√a_k)²及一次整体Young误差，不由下降直接领几何/无价迭代。固定支持图下Σmi log(Mi/mi)为非负凹一次齐次函数，因此superadditive，正残余的局部熵不增；并未由此得质量线性价。

RG5对原正来源F_t≥(s/t)^nF_s，所以increment²≤E(t)−E(s)+2[1−(s/t)^n]E(s)。给任意有限不交区间补gap（不拆原interval）后平方和只增，能量差telescopes；以uniform固定尺度S_d Egrid及1−exp(−nlog(t/s))≤nlog(t/s)，得[1+2nlog(b/a)]S_dEgrid。interval/来源必须独立被平均shift时才能再换成continuous E_d；实际固定区间满足该资格。

长窗log(t/s)≥1/√n的数目≤floor(√nlog(b/a))，原响应非负给单窗increment²≤E(s)+E(t)，所以2√nlog2基线正确；小窗没有被删除。b=a退化窗零、接触端点和补gap情形均覆盖。RG6 exact surplus、两cube pair-overlap min公式及自卷积归一正确。该非负surplus仍需真实共同来源的下界，作者没有从其名字或单峰性取得新付款。

主P1保3n/e²费用；P2 hereditary与原ν≤β资格；P3 quadratic增抽/P4纯有理严格增益；P5 κ derivative及多d/递归费；P6实际硬响应+原残余等式方向均正确。所有原doubleΠ/soft/历史与负信用保持未授权状态，下一sqrt n增量界明确标问号。文中“同价扩大”只能理解为同τ与同单位质量系数；最终CE5/P6仍按扩大后的质量收费，不是旧绝对source费用不变。

RG7作者48+30有限检查仅记录为作者报告，不冒称本人运行；本独审已经运行CE8六有理与两精度L1算例，未额外展开模型或重复大数值。等待最终数值/报告/driver冻结后统一绑定hash。

## 最终整合结论与执行归属

**PASS，可按所列范围冻结；无待修数学阻断。** 最终main P1–P6、CE1–8和RG2–6一致，严格证明平移平均、初始hereditary来源抽取、同一能量阈值下的显式总能量增抽、纯有理L1严格增益、正确跨d/迭代费和窗数无关线性增量基线。root单位系数3e²/(4ε)保完整尺度价。high残余、短窗cross统一下界、soft、双后验与历史/来源总账仍未付，不认证一般根阶闭合。

最终窄修已实读接受：main/report把“同价”明确为同τ和单位质量系数，最终费用按扩大质量计；RG3 residual capped entropy价明确要求原E上M_[a,b]f≤4λ，不能由任意finite E凭空使用；RG8新增的完整代码不改变RG2–6数学。

正式numeric源码/notes已完整静审。1项真实L1有理证书含8算术、10 finite atomic模型(3/4/3)、164初始hereditary masks与10 exact quadratic updates、4 uniform interval quad的counts已直接从JSON核对。tau0显式域外、µ0/r0/linear分支有守卫，exact rational root或192次sign-bracket的实际t_lower有严格q≤0证书；mp根是独立ordinary40/70诊断。uniform只测τ=.1,.25,.5,.75，其CDF公式分别在≤.5或全保留≥.75域正确，不把它泛化到需截断的中间τ。tau.75的终端slack1/12保留，未误要求root equality；前三例两精度显示0只是舍入，不是精确证明。最大scaled差约1.237671156e−41，非区间。

既有full-feasible atomic例显示增抽后某重子来源E−τmass=1/20，已核其代数方向：全来源可行不代表hereditary。它只是有限离散说明，不标作L1/原理论反例，也不新增模型数。真正L1 strictgain依CE7解析有理矩形。

本独审实际执行：前screen25个Fraction正核恒等式/下降诊断（临时无独立归档程序，不列正式模型receipt）；从CE8提取6有理检查与40/70两次L1 quad；在最终RG8代码落盘后又实际提取运行48项抽取账和30项pair-kernel断言，全部PASS。因此早先checkpoint“未运行RG7”由本次归档代码重放更新。未重跑正式numeric全套，不冒称numeric作者或父级完整重放为本人执行。最终Python/合同JSON自绑定PASS；正式包外numeric全文重算、嵌入代码及manifest前后回执由主代理另存。

report最终范围通过。reproduce.py先验manifest['sha256']，把numeric输出写外临时目录与原完整JSON逐字节比较，提取两作者所有python块实际运行，最后再次核全部manifest；最终RG现有一个有效代码块，缺块不再是运行阻断。driver不重新归一来源/改变µ，也不把运行通过冒充一般定理或FULL。未编译PDF/未Git/未改其他文件。

## 冻结受审SHA256

不绑定audit自身；以下最终版本的后续变更需重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`0e3ea53cfb18c234479fd0728b2c296e23529b03b9b6d23a760efc7976ab2492`|
|proof.tex.txt|`9b19269c2a1c05b2f35d862d6abe87aef23616f9d98a315516a2351a2318c5fa`|
|continuous_extraction.md|`e1a844f47a28d9abf0f6e6a8a36905c8f5f0ff568ef94c7076a5a314b7ce3869`|
|residual_geometry.md|`92091bb4f747a106c23d07ead33e6008f9eafd0afb1b35d045e3d4e8e53ae9a1`|
|report.md|`a02cc3f4355d83a1abb8eff70e3147495c118a88cefdec8be7c87d4154975141`|
|reproduce.py|`25bb4ae0340efe19af2c5de7bea95fd71a91fbdcaca6ab46a3179931f550ead5`|
|numeric_checks.py|`209b2ed1d89c439c8226503ee9109c00b10fa6b0858900fe93f4cb9fe002dd37`|
|numeric_checks.json|`3e5d312b1a82169e0c69ddfdc1aca0c0af68512498672f21cb5d2102357f5172`|
|numeric_notes.md|`35c15dea11e4934ced05b0149a2f47fdad536ebb7afae5184944bddf9dc0fe92`|

R253审核完成，audit.md至此冻结并停止写入。
