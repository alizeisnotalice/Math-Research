"""R94 neutral actual multidimensional/diffuse all-scale energy certificates.
Only declared finite probability laws; no original Fnew qualification.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import inf, log, sqrt
import argparse
import json
import time

BITS = 44
DEN = 1 << BITS

def floorq(x):
    return x.numerator // x.denominator

def ceilq(x):
    return -floorq(-x)

def series_log(q):
    assert 1 <= q <= 2
    t = (q - 1) / (q + 1)
    s = F(0)
    p = t
    for j in range(40):
        s += 2 * p / (2*j + 1)
        p *= t*t
    tail = 2*p / (81*(1-t*t))
    return s, s+tail

LOG2 = series_log(F(2))

@lru_cache(None)
def log_bounds(q):
    assert q > 0
    k = 0
    z = q
    while z >= 2:
        z /= 2
        k += 1
    while z < 1:
        z *= 2
        k -= 1
    d56 = 1 << 56
    zl = F(floorq(z*d56), d56)
    zh = F(ceilq(z*d56), d56)
    lo = series_log(zl)[0]
    hi = series_log(zh)[1]
    if k >= 0:
        lo, hi = lo+k*LOG2[0], hi+k*LOG2[1]
    else:
        lo, hi = lo+k*LOG2[1], hi+k*LOG2[0]
    return F(floorq(lo*DEN), DEN), F(ceilq(hi*DEN), DEN)

@lru_cache(None)
def energy(n, arrivals):
    """Integral (sum mass 1_{L>=r}/L**n - 1)_+**2 dL/L.
    arrivals is sorted tuple (full-side distance, mass), mass sums to one.
    Returns rigorous fixed-dyadic bounds or None for +infinity.
    """
    grouped = {}
    for r, m in arrivals:
        grouped[r] = grouped.get(r, F(0)) + m
    points = sorted(grouped)
    if points[0] == 0:
        return None
    total = F(0)
    elo = ehi = F(0)
    for i, r in enumerate(points):
        total += grouped[r]
        u0 = r**n
        u1 = min(total, points[i+1]**n) if i+1 < len(points) else total
        if u0 >= u1:
            continue
        rational = total*total*(1/u0**2-1/u1**2)/(2*n) - 2*total*(1/u0-1/u1)/n
        l0, h0 = log_bounds(u0)
        l1, h1 = log_bounds(u1)
        elo += rational+(l1-h0)/n
        ehi += rational+(h1-l0)/n
    return max(F(0), F(floorq(elo*DEN), DEN)), max(F(0), F(ceilq(ehi*DEN), DEN))


from pathlib import Path
import hashlib
import base64
import zlib

def rational(x):
    return str(x)

def interval(lo, hi):
    assert 0 <= lo <= hi
    return {'lower':str(lo),'upper':str(hi),
            'display_only':[float(lo),float(hi)]}

def trim_bound(cells,budget,key):
    """Fractional density sorting is exact for the piecewise constant envelope."""
    assert budget>=0
    ordered=sorted(cells,key=lambda c:(c[key] is None,
                   F(0) if c[key] is None else c[key],str(c['id'])),reverse=True)
    remaining=budget; deleted=F(0); value=F(0); singular_remaining=False
    full=[];partial=None
    for c in ordered:
        take=min(remaining,c['volume'])
        remaining-=take;deleted+=take
        if take==c['volume']:full.append(c['id'])
        elif take>0:
            assert partial is None
            partial={'cell':c['id'],'deleted_volume':str(take),
                     'first_coordinate_slice_fraction':str(take/c['volume'])}
        kept=c['volume']-take
        if kept and c[key] is None:singular_remaining=True
        elif kept:value+=kept*c[key]
    assert deleted<=budget
    payload=json.dumps(full,separators=(',',':')).encode()
    return None if singular_remaining else value,{
        'actual_cap_volume':str(deleted),
        'fully_deleted_cells_zlib_base85':base64.b85encode(zlib.compress(payload,9)).decode(),
        'fully_deleted_cell_count':len(full),
        'fully_deleted_cell_ids_sha256':hashlib.sha256(payload).hexdigest(),
        'witness_codec':'base85(zlib(UTF8 compact JSON list of exact histogram/direct-cell IDs))',
        'partial_cell':partial,'single_cap_independent_of_scale':True,
        'partial_realization':'same left first-coordinate slice fraction in each disjoint Cartesian component of the histogram orbit',
        'singular_upper_cells_remaining':singular_remaining}

BUDGETS=(F(1,16),F(1,4),F(1,2),F(1))

def dylo(x,bits=60):return F(floorq(x*(1<<bits)),1<<bits)
def dyhi(x,bits=60):return F(ceilq(x*(1<<bits)),1<<bits)

def compositions(n,k):
    if k==1:
        yield (n,);return
    for i in range(n+1):
        for tail in compositions(n-i,k-1):yield (i,)+tail

def multinomial(counts):
    from math import comb
    left=sum(counts);v=1
    for k in counts:
        v*=comb(left,k);left-=k
    assert left==0
    return v

def overlap(x,L,c,eps):
    if eps==0:return F(int(abs(x-c)<=L/2))
    return max(F(0),min(c+eps,x+L/2)-max(c-eps,x-L/2))/(2*eps)

def step_arrivals(n,factors):
    """Cumulative mass product of full near/far step probabilities."""
    stops=sorted({r for events,count in factors if count for r,m in events})
    previous=F(0);out=[]
    for r in stops:
        mass=F(1)
        for events,count in factors:
            if count:mass*=sum((m for t,m in events if t<=r),F(0))**count
        assert mass>=previous
        if mass>previous:out.append((r,mass-previous))
        previous=mass
    assert previous==1
    return tuple(out)

def raw_step(n,arrivals):
    total=F(0);v=F(0)
    for r,m in arrivals:
        if r==0:return None
        v+=((total+m)**2-total**2)/(2*n*r**(2*n))
        total+=m
    assert total==1
    return v

def scalar_steps(lo,hi,a,eps,p):
    near=[];far=[]
    for c,m in [(-a,p),(a,1-p)]:
        near.append((2*max(lo-(c+eps),(c-eps)-hi,F(0)),m))
        far.append((2*max(abs(lo-(c+eps)),abs(hi-(c-eps))),m))
    return tuple(near),tuple(far)

def tensor_cells(n,a,eps,p,mesh,R=F(3,4)):
    assert 0<p<1 and 0<=eps<a and R>=a+eps+F(1,2)
    h=F(1,mesh);assert (R/h).denominator==1
    folded=p==F(1,2)
    bins=[(i*h,(i+1)*h) for i in range(0 if folded else -int(R/h),int(R/h))]
    steps=[scalar_steps(lo,hi,a,eps,p) for lo,hi in bins]
    cells=[]
    for counts in compositions(n,len(bins)):
        vol=multinomial(counts)*(2*h if folded else h)**n
        near=step_arrivals(n,[(steps[j][0],c) for j,c in enumerate(counts)])
        far=step_arrivals(n,[(steps[j][1],c) for j,c in enumerate(counts)])
        elo=energy(n,far);ehi=energy(n,near)
        assert elo is not None
        if ehi is not None:assert elo[0]<=ehi[1]
        cells.append({'id':list(counts),'volume':vol,'energy_lower':elo[0],
            'energy_upper':None if ehi is None else ehi[1],
            'raw_lower':raw_step(n,far),'raw_upper':raw_step(n,near)})
    assert sum(c['volume'] for c in cells)==(2*R)**n
    return cells,{'kind':'tensor_uniform_intervals' if eps else 'tensor_atomic',
        'n':n,'a':str(a),'halfwidth':str(eps),'negative_peak_probability':str(p),
        'conceptual_components':2**n,'components_enumerated':False,
        'source_support_radius':str(a+eps),'receiver_R':str(R),'mesh':mesh,
        'folded_reflection':folded,'bin_edges':[[str(x),str(y)] for x,y in bins],
        'actual_receiver_domain_volume':str((2*R)**n),
        'orbit_volume':'multinomial(counts)*(2h)^n' if folded else 'multinomial(counts)*h^n'}

def correlated_cells():
    n=2;eps=F(1,256);mesh=16;h=F(1,mesh);R=F(17,16)
    sources=[((F(0),F(0)),F(1,2)),((F(1,4),F(0)),F(1,4)),
             ((F(0),F(1,4)),F(1,8)),((F(1,2),F(1,2)),F(1,8))]
    cells=[]
    for i,j in product(range(-17,17),repeat=2):
        lows=[i*h,j*h];near=[];far=[]
        for center,m in sources:
            near.append((2*max(max(lows[t]-center[t]-eps,center[t]-eps-lows[t]-h,F(0)) for t in range(n)),m))
            far.append((2*max(max(abs(lows[t]-center[t]-eps),abs(lows[t]+h-center[t]+eps)) for t in range(n)),m))
        # Group equal arrivals through energy; raw needs grouping also.
        near=tuple(sorted(near));far=tuple(sorted(far))
        el=energy(n,far);eh=energy(n,near)
        assert el is not None
        cells.append({'id':[i,j],'volume':h*h,'energy_lower':el[0],
              'energy_upper':None if eh is None else eh[1],
              'raw_lower':raw_step(n,far),'raw_upper':raw_step(n,near)})
    assert sum(c['volume'] for c in cells)==(2*R)**n
    return cells,{'kind':'correlated_uniform_boxes','n':n,'halfwidth':str(eps),
        'sources':[[[str(z) for z in center],str(m)] for center,m in sources],
        'source_support_radius':str(F(1,2)+eps),'receiver_R':str(R),'mesh':mesh,
        'actual_receiver_domain_volume':str((2*R)**n),'orbit_volume':'h^2, direct 2D cells'}

def raw_outside_tail(n,b,R):
    from math import comb
    assert R>b
    return sum((F(comb(n-1,k))*b**k/((n+k)*(R-b)**(n+k)) for k in range(n)),F(0))/2**(n+1)

def selected_remainder(cells,cap,key):
    ids=json.loads(zlib.decompress(base64.b85decode(cap['fully_deleted_cells_zlib_base85'])))
    gone={tuple(i) for i in ids};part=cap['partial_cell'];v=F(0)
    for c in cells:
        if tuple(c['id']) in gone:continue
        kept=c['volume']
        if part and c['id']==part['cell']:kept-=F(part['deleted_volume'])
        if kept and c[key] is None:return None
        v+=kept*c[key]
    return v

def histogram_case(name,cells,spec):
    encoded=[{'id':c['id'],'v':str(c['volume']),
              'el':str(c['energy_lower']),'eu':None if c['energy_upper'] is None else str(c['energy_upper']),
              'rl':str(c['raw_lower']),'ru':None if c['raw_upper'] is None else str(c['raw_upper'])} for c in cells]
    tail=raw_outside_tail(spec['n'],F(spec['source_support_radius']),F(spec['receiver_R']))
    curves=[]
    for budget in BUDGETS:
        low,_=trim_bound(cells,budget,'energy_lower')
        high,cap=trim_bound(cells,budget,'energy_upper')
        rl=selected_remainder(cells,cap,'raw_lower');ru=selected_remainder(cells,cap,'raw_upper')
        assert rl is not None
        if high is not None:assert low<=high
        if ru is not None:assert rl<=ru+tail
        curves.append({'budget':str(budget),'arbitrary_measurable_cap_optimum_lower':str(low),
            'selected_single_cap_excess_upper':None if high is None else str(high),
            'same_selected_cap_raw_lower':str(rl),
            'same_selected_cap_raw_upper_including_receiver_tail':None if ru is None else str(ru+tail),
            'status':'FINITE_SELECTED_UPPER' if high is not None else 'UNKNOWN_INFINITE_ENVELOPE_UNREMOVED',
            'display_only':[float(low),None if high is None else float(high)],'selected_cap':cap})
    return {'name':name,'source':spec,'compressed_receiver_cells':len(cells),
        'cell_payload_sha256':hashlib.sha256(json.dumps(encoded,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        'full_domain_volume':str(sum(c['volume'] for c in cells)),
        'excess_outside_domain':'exactly zero','excess_L_ge_1':'exactly zero',
        'raw_outside_domain_upper':str(tail),
        'infinite_upper_cell_volume':str(sum((c['volume'] for c in cells if c['energy_upper'] is None),F(0))),
        'curves':curves}

def pair_kernel(d):
    """Ordered actual all-space pair kernel at a nonzero difference."""
    r=max(d)
    if r==0:return None
    es=[F(1)]
    for x in d:
        es.append(F(0))
        for k in range(len(es)-1,0,-1):es[k]+=x*es[k-1]
    return sum(((-1)**k*es[k]/((len(d)+k)*r**(len(d)+k)) for k in range(len(es))),F(0))

def hamming_kernel(n,m,r,z):
    from math import comb,factorial
    assert 1<=m<=n and 0<=z<=r and r>0
    return sum((F(comb(n-m,k))*(-z/r)**k*F(factorial(n+k-1)*factorial(m),factorial(n+k+m)) for k in range(n-m+1)),F(0))/r**n

def tensor_pairs(n,a,eps,p):
    from math import comb
    t=2*p*(1-p);s=p*p+(1-p)**2;lo=hi=F(0);rows=[]
    for m in range(1,n+1):
        weight=comb(n,m)*t**m*s**(n-m)
        kl=hamming_kernel(n,m,2*a+2*eps,2*eps)
        kh=hamming_kernel(n,m,2*a-2*eps,F(0))
        if n<=4:
            assert kl==pair_kernel([2*a+2*eps]*m+[2*eps]*(n-m))
            assert kh==pair_kernel([2*a-2*eps]*m+[F(0)]*(n-m))
        assert 0<=kl<=kh
        lo+=weight*kl;hi+=weight*kh
        rows.append([m,str(weight),str(kl),str(kh)])
    assert sum(F(row[1]) for row in rows)==1-s**n
    return {'n':n,'a':str(a),'halfwidth':str(eps),'p':str(p),
        'ordered_cross_component_mass':str(1-s**n),
        'ordered_unrestricted_cross_component_pair_price':interval(lo,hi),
        'hamming_rows':rows,'same_component_omitted':True,
        'not_total_raw_upper':'same-label raw all-space contribution is infinite; this is only ordered cross-label interaction'}

@lru_cache(None)
def scalar_square(L,a,eps,p,r):
    def q(x):return p*overlap(x,L,-a,eps)+(1-p)*overlap(x,L,a,eps)
    points={-a-eps-L/2,a+eps+L/2,-r,r}
    for c in [-a,a]:
        for endpoint in [c-eps,c+eps]:
            points.update([endpoint-L/2,endpoint+L/2])
    points=sorted(points);X=C=F(0)
    for u,v in zip(points,points[1:]):
        if eps:
            qu,qv=q(u),q(v);value=(v-u)*(qu*qu+qu*qv+qv*qv)/3
        else:value=(v-u)*q((u+v)/2)**2
        X+=value
        if u>=-r and v<=r:C+=value
    assert 0<=C<=X
    return X,C

def root_radius(A,n,bits=24):
    # r=dyadic floor of A^(1/n)/2, exact integer comparison.
    lo=0;hi=1<<bits
    while hi-lo>1:
        mid=(lo+hi)//2
        if F(2*mid,1<<bits)**n<=A:lo=mid
        else:hi=mid
    r=F(lo,1<<bits)
    assert (2*r)**n<=A<F(2*(lo+1),1<<bits)**n
    return r

def cube_raw(n,a,eps,p,A,scale_steps):
    from math import comb
    b=a+eps;r=root_radius(A,n)
    capvol=(2*r)**n
    out={'n':n,'a':str(a),'halfwidth':str(eps),'p':str(p),'budget':str(A),
        'cap_halfside':str(r),'actual_cap_volume':str(capvol),
        'radius_rounding_bits':24,'scale_steps':scale_steps}
    if r<=b:
        out.update(status='UNKNOWN_THIS_CAP_DOES_NOT_CONTAIN_SOURCE',restricted_raw_interval=None);return out
    assert 0<=eps<a
    L0=2*(r-b);L1=2*(r+b);s=(2*eps/F(3))*(p*p+(1-p)**2)+4*a*p*(1-p)
    tail=sum((F(comb(n,k))*(-s)**k/((n+k)*L1**(n+k)) for k in range(n+1)),F(0))-capvol/(2*n*L1**(2*n))
    assert tail>=0
    lower=upper=F(0);payload=[];lastN=F(0)
    for j in range(scale_steps):
        l=L0+(L1-L0)*j/scale_steps;h=L0+(L1-L0)*(j+1)/scale_steps
        if j==0:X,C=scalar_square(l,a,eps,p,r);lastN=X**n-C**n;assert lastN==0
        X,C=scalar_square(h,a,eps,p,r);nextN=X**n-C**n
        assert nextN>=lastN
        kernel=(l**(-2*n)-h**(-2*n))/(2*n)
        tl=dylo(lastN*kernel);tu=dyhi(nextN*kernel)
        lower+=tl;upper+=tu
        payload.append([str(l),str(h),str(lastN),str(nextN),str(tl),str(tu)])
        lastN=nextN
    # At L1 every source point captured throughout the cap; X=L1-s.
    X,C=scalar_square(L1,a,eps,p,r)
    assert X==L1-s and C==2*r
    lower+=dylo(tail);upper+=dyhi(tail)
    out.update(status='FINITE_ACTUAL_TENSOR_RAW_CERTIFICATE',
       restricted_raw_interval=interval(lower,upper),excess_upper=str(upper),
       zero_scale_prefix=str(L0),exact_tail_from=str(L1),exact_tail=str(tail),
       expected_abs_1D_source_pair_distance=str(s),
       endpoint_payload_sha256=hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest(),
       per_interval_rounding_bits=60,source_contained_in_cap=True,
       actual_overlap_not_surrogate=True)
    return out


def scalar_identity_checks():
    """Independent closed forms for the actual q-square, not quadrature."""
    rows=[];a=F(1,8);eps=F(1,128)
    for p in [F(1,2),F(2,3)]:
        for L in [F(1,1024),eps,2*eps]:
            X,_=scalar_square(L,a,eps,p,F(1))
            expected=(p*p+(1-p)**2)*(L*L/(2*eps)-L**3/(12*eps*eps))
            assert L<=2*eps and L<2*a-2*eps and X==expected
            rows.append({'kind':'diffuse_small_scale_exact', 'p':str(p),'L':str(L),'X':str(X)})
        for L in [F(1,16),F(1,4),F(1,2)]:
            X,_=scalar_square(L,a,F(0),p,F(1))
            expected=(p*p+(1-p)**2)*L+2*p*(1-p)*max(F(0),L-2*a)
            assert X==expected
            rows.append({'kind':'atomic_pair_overlap_exact','p':str(p),'L':str(L),'X':str(X)})
    return rows


def run(stage_limit='expanded'):
    a=F(1,8);eps=F(1,128);p=F(1,2)
    specifications=[('pilot',[
        ('unequal_tensor_atomic',2,F(0),F(2,3),8),
        ('unequal_tensor_diffuse',2,eps,F(2,3),8)], [2,4]),
        ('stress',[
        ('even_tensor_diffuse',4,eps,p,8),
        ('genuinely_correlated_2D',None,None,None,None)], [8,16]),
        ('expanded',[
        ('even_tensor_diffuse',8,eps,p,4),
        ('even_tensor_diffuse_refined',8,eps,p,8),
        ('even_tensor_diffuse',16,eps,p,4)], [64,128])]
    stages=[]
    for stage,specs,ns in specifications:
        hist=[]
        for name,n,e,pp,mesh in specs:
            cells,source=correlated_cells() if n is None else tensor_cells(n,a,e,pp,mesh)
            hist.append(histogram_case(name,cells,source))
        cube=[];pairs=[]
        for n in ns:
            pair=tensor_pairs(n,a,eps,p);pairs.append(pair)
            for A in BUDGETS:
                record=cube_raw(n,a,eps,p,A,max(64,8*n))
                if record['restricted_raw_interval']:
                    gap=F(pair['ordered_unrestricted_cross_component_pair_price']['lower'])-F(record['restricted_raw_interval']['upper'])
                    record['unrestricted_cross_lower_exceeds_this_same_cap_total_raw_upper']=gap>0
                    record['strict_cross_lower_minus_selected_total_raw_upper']=str(gap)
                cube.append(record)
        stage_record={'stage':stage,'histogram_energy_cases':hist,
                      'actual_tensor_cube_cap_certificates':cube,'ordered_pair_enclosures':pairs}
        if stage=='expanded':
            coarse=cube[-1]
            fine=cube_raw(128,a,eps,p,F(1),2048)
            cl=F(coarse['restricted_raw_interval']['lower']);cu=F(coarse['restricted_raw_interval']['upper'])
            fl=F(fine['restricted_raw_interval']['lower']);fu=F(fine['restricted_raw_interval']['upper'])
            assert coarse['cap_halfside']==fine['cap_halfside'] and cl<=fl<=fu<=cu
            stage_record['same_source_same_cap_scale_refinement']={
                'not_a_new_physical_input':True,'coarse_steps':coarse['scale_steps'],
                'fine_certificate':fine,'strict_upper_improvement':str(cu-fu)}
        stages.append(stage_record)
        print(json.dumps({'stage':stage,'new_histogram_cells':sum(c['compressed_receiver_cells'] for c in hist),'cube_caps':len(cube)}),flush=True)
        if stage==stage_limit:break
    return {'schema':'R94-actual-tensor-diffuse-onecap-allscale-v1','mass':'1','kappa':'1',
        'public_neutral_tests':True,'original_Fnew_gates_claimed':False,
        'all_receiver_volumes':'true Lebesgue; no sampling, profile measure or source representative replacement',
        'log_certificate':'40-term rational atanh; exact power-of-two range reduction; outward dyadic56 normalized argument and dyadic44 output',
        'optimization_direction':'arbitrary measurable cap optimum lower vs separately declared selected ONE cap upper',
        'independent_1D_square_closed_form_checks':scalar_identity_checks(),
        'stages':stages,'general_uniform_cap_energy_bound':'UNPROVED; no asymptotic fitted order or atomic-to-diffuse energy limit',
        'raw_diagonal_status':'all-space total raw is infinite for atomic and for nonzero diffuse densities; cross-component pair price is partial interaction only'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(Path(__file__).with_name('energy_results.json')))
    parser.add_argument('--stage-limit',choices=['pilot','stress','expanded'],default='expanded')
    args=parser.parse_args();start=time.perf_counter();result=run(args.stage_limit)
    Path(args.output).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'output':args.output,'seconds_diagnostic':time.perf_counter()-start}),flush=True)
