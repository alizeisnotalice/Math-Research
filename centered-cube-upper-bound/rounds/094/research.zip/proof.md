# 中心立方体第94轮：薄环剩余费用与共同删集转换

2026-10-12。一般非负 L1 输入、真实勒贝格接收测度上的 n^(1/2+o(1)) 一致弱型上界仍未证明；保留 O(n log n) 一般基准。八个角色沿用三名 Astra high 路线、Astra high 与 Sol high 独审、两名 Sol high 数值及一名 Sol high 文献与更新技能的配置。所有新命题先交独立审计检查量词和潜在反例，再审完整证明。

部分需求路线取得新的实际支付：全部低尺度和深层环流的累计费用已到根阶乘对数，适用于原递推中的真实来源与接收集合，不限于低负载特殊状态。修正势保留全部子分类、来源退出和终项。剩余项是明确定义的外部薄环累计流，仍须在完整原门条件下支付。厚度小本身不提供来源容量。

另一项一般工具是实际立方体取消尺度差分的维数无关 L2 平方范数界1645/144<12。直接的全局 sinc 证明付清所有频率和尺度。它与新的一般正 L1 桥接不等式结合：同一密度删集之外的正超额能量，由带细尺度 log² 权重的取消平方能量控制。两个端点基线已付，细尺度加权尾仍未付；没有把不加权 L2 定理当成弱型端点闭合。

覆盖路线保留实际删集和阈值扣除，并以向有界密度参考源的真实运输支付长尺度正超额。近尺度的共同删集和相互作用仍须另估。内部压力测试直接使用真正正 L1 输入，区分过强交互证书失败、某个固定删集失败与一般弱型命题；私人重建配方和量化下界结论不公开。

新的数值工作使用真实多维来源和连续接收测度。原完整周期硬见证类还获得一个正体积子集，通过整个尺度窗口的原平滑上门；其似然、全部维度与联合事件费用均保留。原粗门和完整余集资格仍未知。所有有限证据、浮点诊断、解析定理和条件性回代分别记录，不据有限检验推断一般维数指数。

详细 LaTeX 只作为文本保存并作静态检查，不编译 PDF。本轮独立归档、逐轮提交，保留原全尺度和分层费用；一般目标继续开放。


## 第94轮保留主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；第90轮薄片分支及本轮有限浓缩轮廓均未证明覆盖并支付整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮保留工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。

### 第93轮新递推替代及剩余几何费用

旧全需求方案的beta^(-i)加权占用依旧不能假定可付；第93轮改用部分需求运输，不再依赖该假设。每个继续接收行只先付(1−beta)lambda_i，其余lambda_(i+1)留给子状态。子分类异常必须按父阈值足额支付A_old W_(i+1)/beta。真实删源只退出一次，真实嵌套环对每对(x,y)只出现一次。

令u=1−epsilon，a_part=2/c−1，b_part=2/c，K=2 A_old u/[beta(1−beta)]，psi(z)=max(1,2||z||inf)^(-n)1_{||z||inf<=1}，其积分H_n=1+nlog2。真实势Psi_i=∫mu_i(dy)∫B_i psi(x−y)1_Qi(y)dx，P_i=b_part K W_i+a_part Psi_i。严格证明 .5(D_i−D_(i+1))<=P_i−P_(i+1)，在无限活跃链上D_m、P_m都趋零；若有限步接收集为空，则D_terminal=0，可能非零的P_terminal以正确符号丢弃，故D_0<=2(b_part K+a_part H_n)W_0。A_old为原全部已付分类费用，原全尺度和分层返回另行保留。

这真正支付了原来源质量下的阈值漂移、源退出、子分类和终项，不再把D_0占用账当作W_0预算。但其几何项仍为线性H_n。精确恒等式Psi_i=D_i+n∫B_i∫1^L_i T_s mu_i ds/s dx说明Psi_i本身包含需求；把初始Psi替换为根阶上界仍需新的几何证明，不能视作现成弱于目标的条件。只有改善真实累积环流容量或构造有已付缺陷的新势，才能得到目标收益。

### 第93轮一般能量路线的精确接口

原全尺度共同删集条件不变：对每个来源nu及kappa，有一个独立于L的Omega，体积<=A W/kappa、外部正超额平方能量<=B kappa W，则弱常数<=4A+2sqrt(2nAB)。对子阈值输入、弱极限及任意L1的合法传递只用已证条件，不能由有限证书推出A、B子幂。

真实共同接收交叠核K_n(d)=∫_{||d||inf}^∞ L^(-2n−1)∏(L−|d_j|)dL给出全部尺度交叉能量。其逐点界为||d||inf^(-n)/[n(n+1)]，多坐标最大位移有beta积分折扣；但其完整环域积分恰为log(b/a)，不因n变小。不得把逐点折扣直接称作一般来源对总量的降维费用。

若nu=Σnu_j且每个真实簇支持在Q(c_j,epsilon(W_j/kappa)^(1/n))，同一Omega=∪Q(c_j,(W_j/kappa)^(1/n))体积<=W/kappa，外部能量<=kappa W b_n(epsilon)/n+2Σ_{i<j}∬K_n(y−z)dnu_i dnu_j。所有自身项已付；交互项和任意输入的合法分解尚未统一。有限原子可取单原子分解，但交互费用可能很大；一般有界密度还受C epsilon^n>=1的必要条件约束，不能假定浓缩分解总存在。来源中心的小簇上界可改进自身项，不消去任意来源交互。

Phi_a(e)=inf_|Omega|<=a∫Omega^c e 的精确阈值对偶、扩展无穷情形和尺度预算分配已直接证明。带尺度标签空间会重复计接收体积；其最优预算分配只给原空间上界，不等于原空间最优费用。没有作未合法的sup/inf交换或由凸矩极点替代非线性能量目标。

实际方体尺度差分S_L=A_L−A_(2L)具有L2(dx dL/L)平方范数上界18+2logn。但标准抵消平方函数端点包含2^n与R^n费用，原正超额与抵消能量之间尚无共同删集支配。文献定理和此新L2工具不能自动填补这一缺口。

### 第93轮数值资格范围

新中性有限原子测试保留7520连续区域的真实体积、32共同删集预算，31有限上界及1网格UNKNOWN；20项分离族闭式校准不代表一般高维输入。完整周期Haar检验保留有限乘积似然和全部n个区间宽度，证得正体积固定节点硬见证及每坐标完整投影；原全窗平滑上门、粗门仍UNKNOWN，不能声称Fnew体积、主割负担、完整覆盖或根阶上界。私人来源和新构造反例只留本地。总目标继续开放。


### 第94轮：部分需求递推的根阶已付部分与精确薄环缺口

第93轮全体环流由线性 H_n 势支付。第94轮构造 Xi_i=Psi_i−D_i 的非负、随实际限制和嵌套而递减的真实前缀势；这不是从旧下降式免费减去需求。对深环对 psi>=M L_i^(-n)，势损失至少(M−1)倍真实旧硬核，故全部阶段深环累计<=H_n W_0/(M−1)。同时对旧尺度L_i<=M^(1/n)的环流，截断包络U_i的根预算为(1+logM)W_0。

低尺度、其余深环和其余薄环按次序分成不交三类。最后一类满足 L_i>M^(1/n) 且 L_i/M^(1/n)<2||x−y||inf<=L_i，外层相对厚度小于logM/n。令 C_M=bK+a(1+logM)+aH_n/(M−1)，修正势 P_i^M=bKW_i+aU_i+aXi_i/(M−1)。按真实运输重新推导得

(D_i−D_(i+1))/2 <= P_i^M−P_(i+1)^M+aJ_i^thin。

K、父阈值子分类、源退出等沿用完整第93轮费用。无限活跃链终项趋零；有限接收空集停止只丢弃非负终项；未完成有限前缀保留D_m−2P_m^M。于是完整初始局部事件<= (A_old+2C_M)W_0+2aΣJ_i^thin。取M=1+sqrt(n)，所有显式系数为根阶乘对数；ΣJ_i^thin尚只有线性包络。它须在真实完整原条件的递推上支付，不能用未通过原接触/门条件的几何压力模型否定或证明。全尺度与原kappa分层费用仍在。

### 第94轮：取消平方函数与正超额的实际连接

实际立方体 S_L=A_L−A_(2L) 的全尺度L2平方范数可改进为 C_*=1645/144<12，维数无关；证明直接从sinc乘子给出，不假定尺度增量正交。对0<=g<=Mκ，整个取消能量<=C_* MκW。其弱型端点的2^n好函数密度、R^n共同膨胀等几何费用没有消失。

对任意非负L1输入，以同一Omega={f>κ}和R=(W/κ)^(1/n)，已证明实际正超额能量<=4∫Omega^c∫_0^(R/2)log_2(R/L)^2 |S_L f|² dL/L dx。两个端点的基线已付：小尺度用微分定理和实际密度删集，大尺度用总质量。细尺度log²权重保持，不能由不加权L2界丢掉。固定对数带可支付，全部细尺度尾及改良共同删集仍需来源质量预算。变差文献仅p>1、r>2，有限跨越数量不支付尺度持续长度。

### 第94轮：证据与覆盖资格更新

本轮私人交互压力直接构造真正正L1来源，无能量弱极限交换；只排除指定的过强交互证书，不能称作弱型下界或最佳删集障碍。原子的7项价格/19项上包络与新增21项弥散配置/57项上包络分开记录。包络积分下端点不是实际能量下界。

本轮公开数值合计9个不同物理来源律。2923个连续单元对应28项网格删集预算（26有限、2粗包络UNKNOWN）；另24项固定方体删集预算（23有限、1该删集UNKNOWN），最高维同帽加密不计新输入。守卫独立重建全部单元和删集体积，以及2项固定帽全尺度RAW能量；不声称独立重建全部网格能量。全周期软门新增资格详见下节。未知门和覆盖补集不置零，没有有限检验被用来推断一般指数，主目标继续未证明。

### 第94轮：真实运输支付长尺度与共同删集近交互

对任意正来源ν，若同质量参考测度σ=s dz满足0<=s<=κ，并有同一个真实耦合支持于||y−z||inf<=d，则对任何同一接收删集Ω及R>=2nd>0，全部L>=R的正超额能量<=κW(2nd/R)^2。d0时来源本身密度<=κ，超额全为零。证明使用实际扩大捕获cube、质量恒等式∫T_Lν=W和阈值保留；不是未扣阈值的原始平方比较。

令q_j=T_Lν_j，q=Σq_j，Dκ(t)=t²−(t−κ)+²。精确相互作用Cκ=(q−κ)+²−Σ(q_j−κ)+²非负，并至多[1−(κ/q)²]+·2Σi<j q_iq_j（q0另定义0）。这一扣除先在同一(x,L)执行，再积分；不能作∞−∞。屏蔽后的共同域核依赖总来源与κ，其长尺度交互也可付<=3κW·2nd/R。

因此浓缩来源簇若另满足质量尺度cap内点互不交，可将远相互作用全部替换成κW费用，剩余只在L<R、同一Ω外且总平均越阈的交互。cap不交、合法分解及足够小的运输位移都不是任意输入自动满足的条件。粗网格确能给密度参考，但R可能超过总质量的零超额截断，因而没有收益。一般细尺度耦合和共同近交互仍缺。

### 第94轮：原全周期验证的新增资格

保持第93轮同一来源、阈值、硬带和完整周期提议测度，新增事件明确定义为原硬带与全窗口原P1平滑上门的交集。定心Fourier矩和全n尾在提议测度下支付失败概率，再用同一硬带的完整似然转换回Haar体积。初探截断不足而UNKNOWN；预先指定的加密版本得到正体积下界。没有将提议测度失败概率直接从Haar下界相减，没有推出新交集仍有各坐标全投影。原粗门、完整Fnew、首触精确位置和高负载均未获认证。原中门及包指数0<p<=n的保留域没有因此扩大，域外仍未知。


## 1. Scope and outcome

Let \(n\ge2\), \(Q(x,L)=x+[-L/2,L/2]^n\), and
\[
 T_L\nu(x)=L^{-n}\nu(Q(x,L)),\qquad
 \phi_\kappa(t)=(t-\kappa)_+^2.
\]
Here \(\nu\) is any finite positive Borel source measure, \(W=\nu(\mathbb R^n)<\infty\), and \(\kappa>0\). In particular the results apply to arbitrary positive \(L^1\) sources and to finite atomic measures. Receiver measure is actual Lebesgue measure. For a measurable set \(\Omega\), fixed independently of \(L\), write
\[
 \mathcal E_\kappa(\nu;\Omega)
 =\int_{\Omega^c}\int_0^\infty\phi_\kappa(T_L\nu(x))\,\frac{dL}{L}\,dx. \tag{1}
\]
All nonnegative integrals may be infinite.

The new quantitative result pays the entire long-scale part of (1) whenever the source has a bounded-distance transport to a density at most \(\kappa\). The cost has no source-block count or diameter logarithm. Together with a threshold-debited interaction formula, this replaces the unrestricted far-pair sum in the retained concentrated-packet assembly by a finite, uniformly paid term. It leaves an explicit short-scale interaction and common-cap problem. Existence of a sufficiently fine transport, or a suitable packet decomposition, is not asserted for arbitrary input.

This does **not** prove the general cube weak bound. The retained implication from a common cap of volume at most \(AW/\kappa\) and energy at most \(B\kappa W\) to weak constant \(4A+2\sqrt{2nAB}\) still requires such \(A,B\) for every input.

## 2. Actual restricted interactions and the threshold debit

For any fixed measurable \(\Omega\), define
\[
 K_\Omega(y,z)=\int_0^\infty
 \frac{|(Q(y,L)\cap Q(z,L))\setminus\Omega|}{L^{2n}}\,
 \frac{dL}{L}. \tag{2}
\]
This is an extended measurable nonnegative kernel. Tonelli, applied to the actual cube indicators, gives
\[
 \int_{\Omega^c}\int_0^\infty T_L\nu_i(x)T_L\nu_j(x)\,\frac{dL}{L}\,dx
 =\iint K_\Omega(y,z)\,d\nu_i(y)d\nu_j(z). \tag{3}
\]
Thus (2) removes exactly the erased receivers, using the same \(\Omega\) at every scale. It need not have a finite or useful source-pair integral. In particular, if \(f>0\) on a positive-measure subset of \(\Omega^c\), Lebesgue differentiation implies that the raw square integral is infinite there. This remains possible when \(f\le\kappa\), in which case (1) is zero. The raw square and positive excess cannot be interchanged.

The correct algebraic subtraction is local in the same \((x,L)\). Set
\[
 D_\kappa(t)=t^2-\phi_\kappa(t)
 =\begin{cases}t^2,&0\le t\le\kappa,\\2\kappa t-\kappa^2,&t\ge\kappa.\end{cases} \tag{4}
\]
For nonnegative \(q_j\) with finite \(q=\sum_jq_j\), let
\[
 C_\kappa(q_j)=\phi_\kappa(q)-\sum_j\phi_\kappa(q_j).
\]
Then
\[
 0\le C_\kappa(q_j)
 =2\sum_{i<j}q_iq_j-
 \left[D_\kappa(q)-\sum_jD_\kappa(q_j)\right]
 \le w_\kappa(q)\,2\sum_{i<j}q_iq_j, \tag{5}
\]
where \(w_\kappa(q)=[1-(\kappa/q)^2]_+\) for \(q>0\), and \(w_\kappa(0)=0\).

Here is a direct proof of the quantitative last inequality. The case \(q\le\kappa\) is zero. Otherwise normalize \(p_j=q_j/q\), \(t=\kappa/q\in(0,1)\). For every \(p\in[0,1]\),
\[
 D_t(p)\le 2t(1-t)p+t^2p^2. \tag{6}
\]
For \(p\le t\), the difference between the right side and \(p^2\) is
\((1-t)p[2t-(1+t)p]\ge0\).
For \(p\ge t\), the difference is \(t^2(1-p)^2\).
Summing (6) and using \(\sum p_j=1\) gives
\[
 D_t(1)-\sum_jD_t(p_j)\ge t^2(1-\sum_jp_j^2).
\]
This is precisely (5). The first inequality follows from superadditivity of the convex function \(\phi_\kappa\), whose value at zero is zero: alternatively integrate its increasing derivative over the added intervals. Countable sums follow by monotone limits of the individual nonnegative terms and continuity at the finite total \(q\).

For a source decomposition \(\nu=\sum_j\nu_j\), set \(q_j=T_L\nu_j(x)\), \(q=T_L\nu(x)\). These are finite at almost every spacetime point: on each compact positive scale interval, \(\int q\,dx=W\), and Tonelli applies. Equation (5) is used pointwise before integration; it never subtracts two infinite integrated quantities.

The corresponding screened kernel is
\[
 K_{\Omega,\kappa,\nu}^{I}(y,z)
 =\int_I\int_{\Omega^c}
 \frac{1_{Q(y,L)}(x)1_{Q(z,L)}(x)}{L^{2n}}\,
 w_\kappa(T_L\nu(x))\,dx\,\frac{dL}{L}. \tag{7}
\]
Unlike (2), this kernel depends on the total source and threshold. It vanishes on every receiver-scale pair whose total average is at most \(\kappa\). Equations (5)–(7) yield
\[
 \mathcal E_\kappa^I(\nu;\Omega)
 \le\sum_j\mathcal E_\kappa^I(\nu_j;\Omega)
 +2\sum_{i<j}\iint K_{\Omega,\kappa,\nu}^{I}\,d\nu_i\,d\nu_j. \tag{8}
\]
This is a valid threshold-renormalized assembly, not a bound on its last term. The exact debit is what removes subthreshold interactions; simply discarding it recovers the failed raw-pair certificate.

## 3. Quantitative payment from a common bounded-density transport

**Transport-tail theorem.** Suppose \(\sigma=s(z)\,dz\) has mass \(W\), \(0\le s\le\kappa\), and there is an actual coupling \(\pi(dy,dz)\) of \(\nu,\sigma\) supported on
\(\|y-z\|_\infty\le d\), where \(d\ge0\). Then for every \(R>0\) with \(R\ge2nd\), and every measurable \(\Omega\),
\[
 \mathcal E_\kappa^{[R,\infty)}(\nu;\Omega)
 \le \kappa W\left(\frac{2nd}{R}\right)^2. \tag{9}
\]
The same \(\Omega\) is used throughout. No volume enlargement, source independence, packet count, or \(L^2\) hypothesis is required. In fact the proof bounds the energy over the entire receiver space.

If \(d=0\), the coupling implies \(\nu=\sigma\), so the energy is zero at all scales. Suppose \(d>0\). For each cube, the common coupling gives the geometric inclusion estimate
\[
 \nu(Q(x,L))\le\sigma(Q(x,L+2d))
 \le\kappa(L+2d)^n. \tag{10}
\]
There is no selection of a different coupling at different scales. Put
\(C_L=(1+2d/L)^n\) and \(u=2nd/L\). Thus \(q=T_L\nu\le\kappa C_L\), while exactly
\(\int_{\mathbb R^n}q(x)\,dx=W\).
For \(0\le q\le\kappa C_L\),
\[
 \frac{\phi_\kappa(q)}q
 \le\kappa(C_L+C_L^{-1}-2)
 \le2\kappa(\cosh u-1)
 \le2\kappa u^2,\qquad 0\le u\le1. \tag{11}
\]
The ratio at \(q=0\) is defined as zero. For \(q>\kappa\), its derivative is \(1-\kappa^2/q^2\ge0\), which proves the first inequality; for smaller \(q\) it is zero. Next \(1\le C_L\le e^u\), and \(c+c^{-1}-2\) increases for \(c\ge1\). Finally the power series for \(\cosh\) gives
\(\cosh u-1\le u^2(\cosh1-1)\le u^2\).
For example \(\cosh1<2\) follows directly from its factorial series.
Integrating (11) against \(q\,dx\), then \(dL/L\), proves
\[
 \int_R^\infty2\kappa W(2nd/L)^2\,\frac{dL}{L}
 =\kappa W(2nd/R)^2.
\]
This proves (9), including singular sources.

There is also a direct payment for the screened interactions in (8). For every countable positive decomposition of the same source,
\[
 2\sum_{i<j}\iint K_{\Omega,\kappa,\nu}^{[R,\infty)}
 \,d\nu_i\,d\nu_j
 \le3\kappa W\frac{2nd}{R}. \tag{12}
\]
Indeed \(2\sum_{i<j}q_iq_j\le q^2\), and
\[
 \frac{w_\kappa(q)q^2}{q}
 =(q-\kappa^2/q)_+
 \le\kappa(C_L-C_L^{-1})
 \le2\kappa\sinh u\le3\kappa u.
\]
The final inequality follows from the factorial series for \(\sinh\) on \(0\le u\le1\). Integrating \(u\,dL/L\) gives (12). The sharper quadratic tail (9), rather than (12), should be used when assembling the total energy.

An explicitly checkable source class supplies the coupling. Fix a single half-open grid of side \(h>0\), and assume
\[
 \nu(C)\le\kappa h^n \quad\hbox{for every grid cell }C. \tag{13}
\]
Define
\(\sigma=\sum_C \nu(C)h^{-n}1_C\,dz\).
On each cell use the product coupling of \(\nu|_C\) with normalized Lebesgue measure on \(C\). Its target is exactly \(\sigma\), its total mass is \(W\), and its displacement is at most \(h\). Therefore (9) applies with \(d=h\). This construction permits arbitrary source correlations and infinitely many occupied cells.

Condition (13) is a real local capacity condition, not a consequence of small packet labels. At a very coarse resolution it is automatic, but then \(2nh\) may exceed the global mass cutoff \((W/\kappa)^{1/n}\), beyond which the energy already vanishes. Such a choice gives no new information. A useful fine \(d\) must be established from the input, and no refinement-invariant claim is made.

## 4. A corrected finite-range cluster assembly

Here is a concise application showing how (9) removes the far-interaction overcharge in the retained R93 formula. Suppose
\[
 \nu=\sum_j\nu_j,\quad W_j>0,\quad
 r_j=(W_j/\kappa)^{1/n},\quad
 \operatorname{supp}\nu_j\subset Q(c_j,\varepsilon r_j),
 \qquad0\le\varepsilon\le1/(4n), \tag{14}
\]
and the mass-sized cubes \(D_j=Q(c_j,r_j)\) have pairwise disjoint interiors. These hypotheses are substantive and are not supplied for arbitrary input. Set
\[
 \Omega=\bigcup_jD_j,\quad
 r_{\max}=\sup_jr_j,\quad
 R=n(1+\varepsilon)r_{\max}.
\]
For a nonzero finite source, \(0<r_{\max}\le(W/\kappa)^{1/n}<\infty\), and \(|\Omega|=W/\kappa\). The target density \(\sigma=\kappa1_\Omega\) has mass \(W\). Couple each \(\nu_j\) to uniform density \(\kappa\) on \(D_j\); displacement is at most \((1+\varepsilon)r_j/2\), hence at most \(d=(1+\varepsilon)r_{\max}/2\). Thus \(R=2nd\).

For completeness, the retained self estimate is
\[
 \sum_j\mathcal E_\kappa(\nu_j;\Omega)
 \le\frac{\kappa W}{n}b_n(\varepsilon),\qquad
 b_n(\varepsilon)=(1-\varepsilon)^{-n}-(1-\varepsilon)^n
 +2n\log(1-\varepsilon)\le\frac43. \tag{15}
\]
Outside \(D_j\), no source from \(\nu_j\) can be captured for \(L<(1-\varepsilon)r_j\); for \(L\ge r_j\), its average is at most \(\kappa\). Jensen against \(\nu_j/W_j\), followed by integration in the actual receiver variable, bounds its remaining scale integral by
\[
 \int_{(1-\varepsilon)r_j}^{r_j}
 L^n(W_jL^{-n}-\kappa)^2\,\frac{dL}{L}
 =\frac{\kappa W_j}{n}b_n(\varepsilon).
\]
Bernoulli gives \((1-\varepsilon)^n\ge1-n\varepsilon\ge3/4\); dropping the negative terms in \(b_n\) gives the displayed bound. For \(\varepsilon=0\), the integral and \(b_n\) are zero.

Apply (8) only below \(R\) and (9) above it. The result is
\[
 \mathcal E_\kappa(\nu;\Omega)
 \le\left(1+\frac{b_n(\varepsilon)}n\right)\kappa W
 +2\sum_{i<j}\iint K_{\Omega,\kappa,\nu}^{(0,R)}
 \,d\nu_i\,d\nu_j. \tag{16}
\]
All receiver erasure and all threshold screening are retained inside the remaining kernel. No all-space pair sum is substituted. Countable decompositions are legitimate by nonnegative Tonelli; the full common cap and full total-source screen are fixed throughout. There is no finite-subfamily change of cap or threshold.

As a brief fully paid class, if additionally
\[
 \operatorname{dist}_\infty(\operatorname{supp}\nu_i,
 \operatorname{supp}\nu_j)\ge R\quad(i\ne j), \tag{17}
\]
then two such supports cannot both enter a cube of side \(L<R\). The interaction in (16) vanishes, and
\[
 |\Omega|=W/\kappa,\qquad
 \mathcal E_\kappa(\nu;\Omega)\le(1+4/(3n))\kappa W. \tag{18}
\]
This permits any finite or countable number of clusters, arbitrary correlations inside each cluster, and unbounded overall diameter. It is a many-source check of the repair, not an arbitrary-source decomposition theorem.

## 5. What is paid and what remains

For any established bounded-distance reference, the exact general reduction is
\[
 \mathcal E_\kappa(\nu;\Omega)
 \le\mathcal E_\kappa^{(0,R)}(\nu;\Omega)
 +\kappa W(2nd/R)^2,\qquad R\ge2nd. \tag{19}
\]
The new paid term uses actual cube geometry and a common source transport. It resolves long-range accumulation without a pair-count fee. The short-scale term uses the same \(\Omega\) and has not been paid generally. In (16), this becomes a precisely localized, threshold-screened interaction problem, together with the existence and volume cost of the stipulated decomposition/reference.

The scalar debit (5) is necessary for the method but is not itself a dimension gain. The screened kernel depends on the total input, so its remaining bound cannot be inferred from a pointwise bound for \(K_n(y-z)\), the dimension-independent shell mass of that kernel, or source independence. Neither the transport reference nor cap disjointness is inherited automatically under the original stopped-row source restrictions.

A separate bounded background \(f_0\le(1-\beta)\kappa\), \(0<\beta<1\), may be removed only with the explicit threshold change
\[
 \mathcal E_\kappa(f_0\,dx+\nu;\Omega)
 \le\mathcal E_{\beta\kappa}(\nu;\Omega).
 \tag{20}
\]
If the tail theorem is then applied to \(\nu\), its reference must have density at most \(\beta\kappa\). The old threshold cannot silently be kept.

The general common-cap energy hypothesis, the general principal-cut bound, and the original full-residual weak inequality remain open. No full-gated lower construction or weak-operator counterexample is asserted here.

## 6. Verification and evidence scope

The precise statements of (5), (9), (12), and (16)–(18), and the private raw-interaction pressure statement, were sent to both independent auditors before the proofs. Both auditors passed these statement checks. Subsequently Astra and the replacement Sol auditor independently read the complete Markdown and matching TeX, including the private proof, and passed all mathematical and scope claims (1)–(20) and (P1)–(P6). These are full-proof/static-consistency receipts; they are not independent replays of the author arithmetic run.

Three new author stages used exact rational arithmetic: dimensions \(2,3,4\) for pilot, \(8,16,32\) for pressure, and \(64,128,256\) for expansion. The neutral checks comprise 90 exact comparisons of the cube-density factor with the two tail bounds, and 180 threshold-screen comparisons, including unequal shares, many small shares, total capture below threshold, at threshold, and far above threshold. These are algebra checks, not sampled receiver or gate certificates.

Nine actual positive-density multicluster families were checked through their exact support, cap volume, transport radius, and common support-separation inequalities. Twenty-seven private mesh-pressure parameters checked the quantified raw-interaction obstruction. Their concrete sources and lower conclusions remain in the private section. The proofs give the continuum scale and receiver statements; finite arithmetic checks do not replace them.

The separate tensor numerical work belongs to its numerical author. Its author reports that the current concentrated fixtures do not provide a fine bounded-density transport at a useful scale: the necessary transport displacement is comparable to the mass radius. No improvement to those numerical bounds, or unrun principal-cut measurement, is claimed here.

## 1. Result and exact remaining term

On the actual R93 partial-demand recursion, all cumulative low-scale and deep annular traffic admits a root-order source budget. This uses a nonnegative geometric potential, not a free subtraction of the current demand. After the original child-classification costs are absorbed, the corrected potential has initial size O(A_n+sqrt(n)+log(n+2))W_0 and its terminal vanishes on an infinite active chain. At a finite receiver-empty stop its favorable nonnegative terminal is retained or discarded in the upper bound. The only added error is an explicitly defined cumulative thin annular flow, measured with the old hard kernel, the actual child source, and the actual continuing receivers. Its total root-order estimate is not proved.

The result holds without a low-coordinate-count hypothesis, so it remains applicable when the R92 low-profile branch is empty. It neither assumes a normalized source modulus nor restores beta^(-i) source occupation. The general root-order weak theorem remains OPEN; this round isolates and pays two actual geometric parts of its remaining recursive cost.

## 2. Actual recursion and complete child payment

Fix n>=2 and define

    alpha=epsilon0=1/[10 log(n+2)], c=1-alpha-epsilon0,
    u=1-epsilon0, beta=c/2, H_n=1+n log2,
    a=(1-beta)/(c-beta)=2/c-1, b=2/c.                       (1)

Let mu_i=mu_0|Z_i=f_i dy, W_i=mu_i(R^n), lambda_i=beta^i lambda_0. The current receiver B_i is a measurable subset of the freshly recomputed WHOLE original Fnew for (mu_i,lambda_i). Its actual earliest side L_i is in [1,2], Q_i(x)=Q(x,L_i(x)), and

    mu_i(Q_i(x))=lambda_i L_i(x)^n, D_i=lambda_i|B_i|.
    0<=k_i(x,y)<=L_i(x)^(-n)1_Qi(x)(y),
    c lambda_i<d_i(x):=∫k_i(x,y)dmu_i(y)<=u lambda_i,
    q_i(y)=∫_Bi k_i(x,y)dx.                                (2)

Here k_i is the original captured-stop kernel, with its original selector. All products and integrals use the common original source space and actual Lebesgue receivers. Empty source/receiver branches stop. The elementary full-window bound D_0<=H_nW_0 ensures finiteness; it supplies no root estimate.

Choose K>0, S_i={q_i>K}, mu_{i+1}=mu_i|S_i, and e_i(x)=∫_(S_i^c)k_i dmu_i. Set G_i={e_i>=d_i/2}. On B_i\G_i the retained stop mass is strictly greater than beta lambda_i, hence the old cube is a strict child hard witness. Apply the COMPLETE original classification to this child source and threshold. Write

    B_i=G_i disjoint-union E_i disjoint-union B_{i+1},
    lambda_{i+1}|E_i|<=A_n W_{i+1}.                        (3)

The final child anchor and old strict witness imply L_{i+1}(x)<L_i(x) on B_{i+1}. Thus actual continuing cubes are nested. No child cube is assigned to E_i. E_i is paid its FULL parent demand: lambda_i|E_i|<=(A_n/beta)W_{i+1}.

For completeness, the local partial-demand proof is retained. Good rows use lambda_i k_i1_(S_i^c)/e_i, with multiplier at most b. Continuing rows use

    l_i=k_i[1_(S_i^c)+1_(S_i)1_(Q_i\Q_{i+1})].

Its row mass satisfies

    ell_i=d_i-∫_(S_i∩Q_{i+1})k_i dmu_i
       >c lambda_i-beta lambda_i(L_{i+1}/L_i)^n
       >=(c-beta)lambda_i.                                (4)

Multiplication by (1-beta)lambda_i/ell_i<=a pays exactly the lost demand, leaving lambda_{i+1} to the child. Good and continuing source-exit columns have disjoint receiver supports, so their combined column is at most b q_i<=bK on S_i^c. Consequently, with

    J_i=∫_(B_{i+1})∫ L_i(x)^(-n)
                 1_(Q_i(x)\Q_{i+1}(x))(y)dmu_{i+1}(y)dx,

we have the exact demand partition and its upper payment:

    D_i-D_{i+1}=lambda_i|G_i|+lambda_i|E_i|
                        +(1-beta)lambda_i|B_{i+1}|,
    D_i-D_{i+1}<=bK(W_i-W_{i+1})+aJ_i
                                      +(A_n/beta)W_{i+1}. (5)

In particular J_i has NO beta^(-i) multiplier. The source exits are disjoint across stages.

## 3. A monotone prefix excess pays deep actual annuli

Define

    psi(z)=max(1,2||z||_infinity)^(-n)1_{2||z||_infinity<=2},
    Psi_i=∫dmu_i(y)∫_Bi psi(x-y)1_Qi(x)(y)dx,
    g_L(x,y)=[psi(x-y)-L^(-n)]1_Q(x,L)(y),
    Xi_i=∫dmu_i(y)∫_Bi g_Li(x)(x,y)dx=Psi_i-D_i.           (6)

The radial envelope has integral H_n. The function g_L is nonnegative and increasing in L in [1,2]. To check this pointwise, if y is already in the smaller cube, increasing L decreases the subtracted L^(-n); if it enters the larger cube, the new value is nonnegative because psi>=L^(-n) there. At the first-entry boundary the new value is zero, except the harmless constant inner region whose value is also nonnegative. Thus source restriction, receiver deletion and continuing-cube shrinkage give

    0<=Xi_{i+1}<=Xi_i<=H_nW_i.                             (7)

This also equals the exact precontact integral n∫_Bi∫_1^Li T_s mu_i(x) ds/s dx. Its positivity alone does not allow replacement of the R93 potential; the following restricted loss estimate is the new ingredient.

Fix 1<M<=2^n. An actual annular pair is called deep if psi(x-y)>=M L_i(x)^(-n). Let J_i^deep be J_i restricted to these pairs. On a removed deep pair g_Li>=(M-1)L_i^(-n). Keeping only continuing receivers and surviving sources in the potential difference, every other contribution has nonnegative sign. Therefore, for every finite m,

    Xi_i-Xi_{i+1}>=(M-1)J_i^deep,
    Σ_(i<m)J_i^deep <= [Xi_0-Xi_m]/(M-1)
                           <=H_nW_0/(M-1).                (8)

This is a bound on actual cumulative annuli, not on independently selected fixed-scale surrogates. For M=1+sqrt(n), its coefficient is H_n/sqrt(n)=O(sqrt(n)).

## 4. Remove the small-side exception and identify a genuine thin shell

Put L_*=M^(1/n) and psi_*(z)=psi(z)1_{2||z||_infinity<=L_*}. Its integral is

    ∫psi_*=1+n log L_*=1+log M.

Define U_i=∫dmu_i(y)∫_Bi psi_*(x-y)1_Qi(x)(y)dx. This is another nonnegative decreasing reservoir, with U_i<=(1+log M)W_i. Partition each actual annulus into three DISJOINT classes, in this order:

- low: L_i<=L_*;
- deep: L_i>L_* and psi>=M L_i^(-n);
- thin: L_i>L_* and psi<M L_i^(-n).

Use J_i^low,J_i^deep,high,J_i^thin for the corresponding old-hard-kernel integrals. On every low pair psi_*>=L_i^(-n), so

    U_i-U_{i+1}>=J_i^low,
    Xi_i-Xi_{i+1}>=(M-1)J_i^deep,high.                     (9)

The potentials may overpay some pairs, but the charged annular classes are disjoint. No union is counted twice in J_i.

For a remaining thin pair set r=||x-y||_infinity. Since y∈Q_i,

    1< L_i/M^(1/n)<2r<=L_i,
    0<=log[L_i/(2r)]<log M/n,
    (L_i-2r)/L_i<1-M^(-1/n)<=log M/n.                     (10)

Thus the exact unpriced flow really is in an outer relative shell of width O(log(n+2)/n) for M=1+sqrt(n). Without the low-side payment, the same statement would be false when L_i<=L_*, because of the constant central part of psi. Thin shell width alone is not a source-column estimate: source concentration and selector dependence are retained.

## 5. Corrected finite potential, original fees, exits and terminal

Set

    C_M=bK+a(1+log M)+aH_n/(M-1),
    P_i^M=bK W_i+aU_i+aXi_i/(M-1),
    0<=P_i^M<=C_M W_i.                                   (11)

Combining (5) and (9), rather than subtracting a multiple of D from an old descent, proves

    D_i-D_{i+1}<=P_i^M-P_{i+1}^M+aJ_i^thin
                                         +(A_n/beta)W_{i+1}.

The actual high-q restriction gives K W_{i+1}<=uD_i and nested receivers give D_{i+1}<=beta D_i. Hence the child exception is at most theta(D_i-D_{i+1}), with theta=A_n u/[beta K(1-beta)]. Choose

    K=2A_n u/[beta(1-beta)], theta=1/2.

The complete finite inequality is

    (D_i-D_{i+1})/2<=P_i^M-P_{i+1}^M+aJ_i^thin,
    (D_0-D_m)/2<=P_0^M-P_m^M+aΣ_(i<m)J_i^thin.            (12)

The right error is nonnegative, and its partial sums have NOT been proved root-bounded. N04 therefore permits the finite identity, not a free error deletion. Independently, actual nested annuli are unique for every fixed (x,y), so ΣJ_i^thin<=H_nW_0; this retained linear bound ensures the infinite sum exists but does not establish the sought improvement.

For m>=1,

    D_m<=beta^m D_0,
    W_m<=u beta^(m-1)D_0/K,
    P_m^M<=C_M u beta^(m-1)D_0/K.                          (13)

Both terminal quantities vanish on an infinite active chain. At a finite receiver-empty stop D_m=0 while P_m^M may be positive; discard only the favorable nonnegative terminal. At an arbitrary unfinished horizon the upper bound retains +D_m-2P_m^M. All early source-empty cases have zero receiver demand by contact. Therefore the original initial event before its paid classification obeys

    lambda_0|E_init| <= (A_n+2C_M)W_0
                               +2aΣ_(i>=0)J_i^thin.       (14)

For a finite unfinished prefix use its finite sum and add D_m-2P_m^M. If B_0 is empty use the already-paid A_nW_0 bound alone.

With M=1+sqrt(n), A_n=O_p(sqrt(n)log^2(n+2)), every explicit coefficient in (14) is root-polylog. The only unresolved quantity is the actual cumulative thin flow. Proving ΣJ_i^thin<=sqrt(n)n^{o(1)}W_0 would complete this local route, but (14) is not offered as a proof of that premise. The new independent result is the unconditional geometric payment (8)–(9) and the fully settled correction (12), with no high-r or band assumption.

## 6. Retained original classification ledger and scope

Every restricted source recomputes the anchor, all-L original P1 upper gate, strict later witness, earliest contact, original exp(-s_n)/2 middle lower, noise theta_noise=log^(-2)(n+2), dominant-packet and physical collision/entropy branches, and any original kappa layer used. Whole Fnew=Fdiff∩{C_h*<3/4,Hbar_h*>sqrt(n)}; B_i is only its current subset. No whole-event posterior variance is inherited by restriction.

For h*=1/(16n^(3/2)), a0=n^(-p), rho0=n^(-1/2), fixed p>0, retain

    B_base=4+2(log2)sqrt(7n/3), B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta_noise^(-1)+4theta_noise/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*), B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt(n)],
    A_n=B_base+B_ext+T_soft/alpha+P_dom+P_phys.              (15)

The physical union is paid once. Any additional layer classification must be included in A_n or charged separately. All-scale return retains C_loc log(n+2) and separate J_n=O(log n) if the kappa-layer route is used. No all-scale factor, original gate or extra source normalization is omitted.

The proof uses only the explicitly verified finite telescoping part of N04. No entropy, martingale or external descent theorem supplies the missing thin-flow budget. The refined reservoirs are on the common original physical source and receiver space. Positivity and nesting do not by themselves justify deleting the shallow error; the internal physical pressure distinguishes this limitation from a counterexample to the original fully gated recursion. Concrete private recipes and quantified lower conclusions are excluded here.

Validation stages: pilot verifies pointwise g_L monotonicity and the actual low/deep split; pressure checks a positive-L1, positive-volume geometric realization near a cube face and explicitly tests its missing recursion qualifications; enlargement varies dimension, boundary thickness, source/receiver continuum volumes and the finite coefficient identities. Finite arithmetic is validation of these stated inequalities, not numerical evidence of a qualified high-r chain or a fitted asymptotic law.

The arbitrary-input root-order weak bound remains unproved. This note gives a general quantitative conversion from the actual cancelled cube square to positive-excess energy on one common cap complement. The price is an explicit squared logarithmic weight at fine scales. The available unweighted square estimate pays any fixed logarithmic band but does not pay the remaining tail. Actual pressure on a proposed unweighted conversion is recorded privately; no lower recipe or quantitative lower conclusion is published here.

## 1. A general one-cap inequality

Let $n\ge1$, let $f\ge0$ belong to $L^1(\mathbb R^n)$ with mass $W>0$, and fix $\kappa>0$. Use full-side centered cube averages
\[
 A_Lf(x)=L^{-n}\int_{Q(x,L)}f(y)\,dy,\qquad
 S_Lf=A_Lf-A_{2L}f.
\]
Choose one measurable receiver cap and one mass-controlled large-scale anchor:
\[
 \Omega=\{x:f(x)>\kappa\},\qquad
 R=(W/\kappa)^{1/n}.
 \tag{1}
\]
Then $|\Omega|\le W/\kappa$, and
\[
 E_\kappa(f;\Omega):=\int_{\Omega^c}\int_0^\infty
       (A_Lf(x)-\kappa)_+^2\,\frac{dL}{L}\,dx
 \le4\int_{\Omega^c}\int_0^{R/2}
       \left(\log_2\frac RL\right)^2|S_Lf(x)|^2\,\frac{dL}{L}\,dx.
 \tag{2}
\]
The inequality is understood in the extended nonnegative reals; no finiteness of the right side and no $L^2$ hypothesis on $f$ is assumed. It holds directly for arbitrary nonnegative $L^1$ inputs, without an atomic approximation or a claim of cap-energy convergence. Any larger choice of $R$ satisfying $W/R^n\le\kappa$ also works.

The cap in (1) is independent of scale and has a paid volume. The small-scale baseline is paid by removing the actual density superlevel set, and the large-scale baseline is paid by the total source mass. Neither baseline asserts that all intermediate averages are below threshold.

## 2. Tail Hardy inequality and complete proof

We first prove the scalar inequality needed for (2). If $u_j\ge0$ and $u_j\to0$, then
\[
 \sum_{j\ge1}u_j^2
 \le4\sum_{j\ge1}j^2(u_{j+1}-u_j)^2.
 \tag{3}
\]
If the right side is infinite, there is nothing to prove. Otherwise let $D=\sum_{j\ge1}j^2(u_{j+1}-u_j)^2<\infty$. Cauchy--Schwarz makes each tail of the differences absolutely summable and gives
\[
 N u_{N+1}^2
 \le\sum_{j\ge N+1}j^2(u_{j+1}-u_j)^2\longrightarrow0,
\]
since $\sum_{j\ge N+1}j^{-2}\le1/N$ and the prescribed limit of $u_j$ is zero. For $A_N=\sum_{j=1}^Nu_j^2$, exact summation by parts gives
\[
 A_N=\sum_{j=1}^N j(u_j^2-u_{j+1}^2)+N u_{N+1}^2
 \le\sqrt D\sqrt{4A_N+2u_{N+1}^2}+N u_{N+1}^2.
\]
These finite inequalities first imply that $A_N$ is bounded uniformly in $N$: a linear left side cannot exceed the displayed square-root expression plus a bounded remainder if $A_N$ tends to infinity. Passing to the limit gives $A\le2\sqrt{DA}$, hence $A\le4D$. The case $D=0$ is immediate. This proves (3) without assuming the left side finite or dropping a terminal term.

Now fix a receiver outside $\Omega$ at which cube differentiation holds. The set of excluded receivers is null, and the differentiation statement holds as $L\downarrow0$, not merely along one phase. For $a\in[R,2R)$ set
\[
 u_j=\bigl(A_{a2^{-j}}f(x)-\kappa\bigr)_+,
 \qquad j\ge1.
\]
Since $f(x)\le\kappa$, differentiation gives $u_j\to0$. The positive-part map is one-Lipschitz, so
\[
 |u_{j+1}-u_j|
 \le|S_{a2^{-(j+1)}}f(x)|.
\]
Apply (3), then integrate the phase $a$ against $da/a$ on $[R,2R)$. The left dyadic intervals partition $(0,R)$. On the right, $j\ge1$ yields $L=a2^{-(j+1)}\in(0,R/2)$ and
\[
 j\le\log_2(R/L).
\]
Tonelli proves the pointwise-in-receiver version of (2) on $(0,R)$. The mass bound $A_Lf\le W/L^n\le\kappa$ for $L\ge R$ pays the entire omitted large-scale range. Integrating over the same fixed $\Omega^c$ proves (2). No martingale independence, scale stopping law, receiver transport, or per-scale deletion set enters this proof. The case $W=0$ has zero energy and can use the empty cap.

## 3. The part that an unweighted square estimate actually pays

For $0<\ell<R/2$, retain the fine-scale remainder
\[
 \mathcal T_\ell(f;\Omega)
 =4\int_{\Omega^c}\int_0^\ell
      \left(\log_2\frac RL\right)^2|S_Lf(x)|^2\,\frac{dL}{L}\,dx.
 \tag{4}
\]
If $f\in L^1\cap L^2$ and the actual all-space square bound is
\[
 \int_{\mathbb R^n}\int_0^\infty|S_Lf|^2\,\frac{dL}{L}\,dx
 \le C_\square(n)\|f\|_2^2,
\]
then (2) gives the fully quantified decomposition
\[
 E_\kappa(f;\Omega)
 \le4C_\square(n)\left(\log_2\frac R\ell\right)^2\|f\|_2^2
       +\mathcal T_\ell(f;\Omega).
 \tag{5}
\]
In particular, if $0\le f\le D\kappa$ a.e., the first term is at most
$4C_\square(n)D\kappa W(\log_2(R/\ell))^2$. This is a true payment for a fixed logarithmic band, with its source bound and logarithmic cost displayed. The R94 sources role has separately proved and fully dual-audited $C_\square=1645/144<12$ for the actual cube square, uniformly in dimension. Thus the coefficient $4C_\square$ in (5) is $1645/36<48$. This imports that proved square theorem, not a cap or a weighted-tail estimate.

Equation (5) is not obtained by setting $\mathcal T_\ell$ to zero. Its integrand is nonnegative and can have arbitrarily fine-scale contributions; the fact that the unweighted square is finite does not give a uniform logarithmic moment. Nor does finite scalar variation control the length of a scale interval on which the averages stay above threshold. A general uniform bound for the weighted tail on a suitably chosen common cap is missing.

## 4. Verification and remaining general payment

The precise all-input weighted bridge and the separate private pressure statement were sent to both auditors before their proofs. Both independent auditors passed the complete mathematical Markdown and matching TeX proofs. The subsequent display-delimiter correction and insertion of the separately dual-audited square constant do not change the bridge or tail scope. Newly executed pilot, obstruction-stress, and expanded rational checks passed: 48 scalar Hardy sequences, eight terminal-omission traps, and 1,344 phase-index cases. Distinct actual-cube checks and their reproducibility records are retained privately; these finite checks supplement the proof and are not continuum energy certificates or original-event qualification.

The result pays the common cap volume and both endpoint baselines for all nonnegative $L^1$ inputs. It exposes a specific additional fine-scale logarithmic cost, rather than declaring the unweighted cancelled square to dominate positive excess. The sources role's cube-square estimate is a separate analytic theorem; its constant does not remove this weight. An improved source-sensitive cap, a genuinely paid crossing-duration estimate, or another mechanism controlling the weighted remainder is still needed for a subpower energy constant. The root-order weak bound and all retained original gate, scale and layer expenses remain unresolved.

## S1. One primary source, with a genuinely new reading scope

[Bourgain–Mirek–Stein–Wróbel, *On dimension-free variational inequalities for averaging operators in R^d*, arXiv:1708.04639v2](https://arxiv.org/pdf/1708.04639v2), dated 27 December 2017. Earlier project reading covered introductory definitions and theorem statements only. New reading: printed p.5, isotropic normalization and Proposition 1.1; printed pp.13–14, the full §3 long-variation proof, equations (3.2)–(3.11), including its interpolation and Fourier steps. No full §4 proof or independent reading of its external dependencies is claimed.

Theorem 1.2 gives, for every symmetric convex body, p>1 and r>2, dyadic r-variation Lp norm at most C_p,r||f||p independently of dimension. Proposition 1.1 states isotropic radial multiplier bounds with a universal unspecified constant and cites Bourgain's equations (10)–(12). Section 3 compares averages with Poisson averages, using a square function, frequency decomposition and interpolation. Its dependencies include Poisson variation, Littlewood–Paley bounds and lacunary maximal bounds; those original external proofs were not reread. No p=1 or r=2 endpoint is supplied. The explicit cube constants below are our proof, not constants printed in this paper. R93 BCP reading is retained, not new.

## S2. Explicit global sinc majorant, avoiding an unread constant

For every real v, with sinc(0)=1,

    sinc(v)^2 <= 1/(1+v²/10).                                  (1)

Proof. Both sides are even. For 0<=v<=2, sinc lies in [0,1], and the alternating sine series, whose successive terms decrease on this interval, gives

    sinc(v) <= 1−v²/6+v^4/120 <= 1−2v²/15.

With x=v² in [0,4],

    (1−2x/15)(1+x/10)=1−x/30−x²/75 <= 1.

The upper polynomial is nonnegative on this interval, so sinc(v)^2<=sinc(v)<=1/(1+v²/10). For v>=2, sinc(v)^2<=1/v²<=1/(1+v²/10), since v²>=4>=10/9. At zero equality holds. This proves (1) including sign changes outside the small interval; no positivity of sinc at large v is assumed.

Let Q=[−1/2,1/2]^n, A_Lf=f*(L^−n 1_{LQ}) and use the 2π Fourier convention. The exact multiplier is

    m(Lξ)=∏_{j=1}^n sinc(πLξ_j).

Product positivity and (1) give

    |m(Lξ)|² <= ∏_j(1+π²L²ξ_j²/10)^−1
                <= (1+π²L²||ξ||2²/10)^−1.                     (2)

The second inequality follows by expanding the product denominator: all its higher-order terms are nonnegative. Thus the dimension-free high-frequency radial bound is |m(Lξ)|<=sqrt(10)/(πL||ξ||2) for ξ nonzero. The cube has volume one and isotropic covariance integral_Q x_i x_j dx=delta_ij/12, so its isotropic constant is 1/sqrt(12), independent of n. Choosing this Q makes L the full side; replacing the source paper's half-side cube by Q only relabels the parameter and introduces no dimensional volume factor. No general convex-body radial theorem or Ball slicing result is needed for (2).

## S3. Uniform all-scale cancelled L2 theorem

For every n>=1 and scalar f in L2(R^n), define Sf(x)(L)=A_Lf(x)−A_{2L}f(x). Then

    ∫_Rn ∫_0^infinity |Sf(x)(L)|² dL/L dx
        <= C_* ||f||2²,
    C_* = 1645/144 < 12.                                       (3)

For ξ nonzero put s=πL||ξ||2. Globally,

    |1−sinc(v)| <= v²/6,

because sinc(v)=∫_0^1 cos(tv)dt and 0<=1−cos(tv)<=t²v²/2. Product telescoping with |sinc|<=1 therefore gives

    |1−m(Lξ)| <= π²L²||ξ||2²/6.

The two scales yield

    |m(Lξ)−m(2Lξ)| <= 5s²/6.                                  (4)

From (2), the absolute values at L and 2L are at most sqrt(10)/s and sqrt(10)/(2s). Hence

    |m(Lξ)−m(2Lξ)| <= 3sqrt(10)/(2s).                           (5)

Split the squared multiplier integral at s=1. Equations (4)–(5) give

    ∫_0^infinity |m(Lξ)−m(2Lξ)|² dL/L
      <= (25/36)∫_0^1 s^3 ds + (90/4)∫_1^infinity s^−3 ds
      =25/144+45/4=1645/144.

At ξ=0 the difference is zero. Tonelli and Plancherel prove (3), first on a dense class and then on all L2. Convolution by these probability kernels is strongly measurable in L; the product-measure norm is consequently well-defined. This is actual full-scale cube energy with true Lebesgue receivers. It improves R93's 18+2log n input bound to an absolute constant without asserting orthogonality or independence.

A useful bounded-source corollary is: if kappa>0, 0<=M<infinity, and 0<=g<=M kappa is integrable with mass W, then

    ∫∫ |A_Lg−A_{2L}g|² dL/L dx <= C_* M kappa W.               (6)

It holds on the whole receiver space and hence on every measurable restriction. A restriction cannot turn this cancelled energy into positive-excess energy. The uncapped remainder f−min(f,M kappa) still needs its own actual budget.

## S4. Exact endpoint and variation boundaries

In R93's proved cancelled-square endpoint, (3) may replace its L2 input. The resulting displayed weak-(1,1) constant, for every R>1, is

    2^(n+2) C_* + R^n + 16n exp(n/(R−1))/sqrt(R−1).             (7)

The 2^n good-density factor and common enlarged-cube volume R^n remain. The new L2 estimate removes the logarithmic multiplier cost but does not remove the geometric endpoint costs. This is a bound for the cancelled square function, not a cube maximal improvement or a positive-excess cap theorem. No BCP proof was recounted as new literature.

For a separate qualified application of S1, fix r>2 and let V_r be the dyadic cube variation. Define N_h(x), h>0, as the supremum of the number of finite chronological integer pairs

    k1<l1<=k2<l2<=...<=km<lm,
    |A_(2^lj)f(x)−A_(2^kj)f(x)|>h.

The contributing pairs form an increasing subsequence (with shared endpoints counted once), so h N_h^(1/r)<=V_r. Applying the source theorem at p=2 and Chebyshev gives, for integer m>=1,

    |{N_h>=m}| <= C_(2,r)^2 ||f||2²/[h² m^(2/r)].               (8)

For 0<=f<=M kappa this is at most C_(2,r)^2 M kappa W/[h² m^(2/r)]. The constant is dimension-free for fixed r, but is not numerically specified here; its r→2 behavior and any p→1 rate are unpaid. Definition measurability follows from the countable collection of finite integer pairs. This controls the receiver volume of many separated dyadic changes. Since 2/r<1, (8) alone does not provide an integrable expected count. It supplies neither continuous-logscale duration nor a positive-excess occupation estimate. No conditioned-source Markov law or martingale is inferred.

The alternative author's cap-baseline receiver-hole pressure is privately owned and is not repeated here. Its relevant interface is that long positive plateaus can require a separate source-mass-paid duration term even when the pointwise source density is zero at retained receivers. An oscillation/count estimate cannot silently pay that term. Common Ω, all scales, actual threshold shifts and terminal/source fees remain necessary.

## S5. Pilot, obstruction stress, expanded checks and exact ledger

Pilot: derive the scalar (1), then product (2) and (3), retaining the actual full-side/2π normalization. Stress: the dense-frequency vector (1/sqrt n,...,1/sqrt n) avoids the old infinity-frequency overcharge; the rigorous product denominator handles arbitrarily many small factors. R93 raw-density divergence and endpoint volume inflation remain valid; no all-scale excess bridge is deduced. Expanded: the proof of (1) is global, and (2)–(6) hold for all n and all scales, not merely a selected grid. The finite checks below concern only new assertions.

Author inline Python Fraction guard EXACT PASS 156: x=j/16 for j=0,...,64 checks 1−x/6+x²/120<=1−2x/15 and (1−2x/15)(1+x/10)<=1 (65 each). For n=(1,2,4,16,64,256), four nonnegative squared-frequency vectors were (1/n repeated n), (4/n repeated n), (1/100 repeated n−1 with final 100), and (zero repeated n−1 with final 7). Their product denominators satisfy ∏(1+x_j/10)>=1+∑x_j/10 (24 checks). One exact check verifies 25/144+45/4=1645/144<12; one verifies the cube coordinate second moment 2(1/2)^3/3=1/12. These rational checks do not establish the global transcendental inequality; the preceding analytic proof does. They are not source/gate certificates or recycled R93 assertions.

Separately, FLOAT diagnostics used actual cube multipliers m_n(s)=(sinc(s/sqrt n))^n for the same six dimensions. At 2001 log-grid values s=exp(−10+20j/2000), radial and difference bounds passed with tolerances 1e−12 and 1e−11 (24,012 FLOAT comparisons). Simpson integration on log s in [−12,12], 8000 panels, gave approximate cancelled multiplier energies:

| n | FLOAT truncated energy |
|---:|---:|
| 1 | 0.39243606 |
| 2 | 0.24208057 |
| 4 | 0.23317725 |
| 16 | 0.22545605 |
| 64 | 0.22370989 |
| 256 | 0.22328442 |

These are deterministic Fourier diagnostics; no quadrature error or all-scale numerical certificate is claimed. They are not positive-source receiver experiments, probability simulations or exponent fits. The rigorous all-scale theorem is (3). The exact guard literal parameters and formulas permit independent reconstruction without an extra owned file.

R94 improves the cancelled L2 input to an absolute constant and gives the qualified crossing-count interface (8). The all-input common-cap positive-excess premise, cap-restricted interaction assembly, partial-demand high-source potential and root-order endpoint remain open. Source proof reading and reviewers' own-transfer verification are separate receipts.

## Why erased interactions cannot be charged again

R93's all-space positive pair kernel is an exact formula, but its use in a common-cap upper estimate enlarges the receiver integration domain. R94 separately tests this enlargement, rather than treating every large interaction certificate as a large maximal operator. The internal actual-source construction proves that the prescribed concentrated-packet/raw-pair certificate can have no uniform bound even at a fixed dimension, while a single admissible cap has a small all-scale positive-excess budget. The construction is only an obstruction to that sufficient certificate. It does not refute the common-cap energy premise, the retained weak-bound return, or the desired general root-order upper bound.

This distinction dictates the next estimate: retain the actual shared deleted region and the threshold debit. A raw restricted square alone also need not be finite for diffuse input; the independent auditors identified that issue before author manuscripts. The coverage route owns the quantitative repair. Source decompositions, threshold shifts, all-scale tails and exact receiver volumes must be paid in the repaired theorem.

The parent ran three stages of exact arithmetic on 7 actual pair-potential cases and 19 all-scale envelope profiles, then directly extended the argument to positive L1 sources with 21 diffuse configurations and 57 additional envelope profiles. The profiles bound the energy from above; a lower rational endpoint for the value of an upper-envelope integral is not a lower bound on the actual energy. Counts refer to different objects and are not summed. No weak-type exponent or general input coverage is inferred. Private parameters, formulas that reconstruct the private family, and the corresponding executable remain local.

The L02 adversarial-input workflow was used to distinguish the actual source from an abstract parameter proxy and to reconstruct its exact objective; the N04 bookkeeping scope was checked for finite versus infinite telescoping. These are methodological uses. Skill provenance tables were inspected but partly truncated in tool output; no new original-paper reading is claimed by the parent on that basis.

# R94：实际张量、弥散来源与一个共同帽的连续能量证书

这轮验证九个不同的有限维来源律，含一个原子律及八个真正的正 L1 密度律。七个网格案例包含一次同来源的网格加密；另有六个维数的固定立方体帽计算，部分来源与网格案例相同。所有接收体积都是实际 Lebesgue 体积，所有帽独立于尺度。没有采样、指数拟合、原 Fnew 门资格或一般维数界的结论。

结果是有限输入的定量比较：23 项固定立方体帽的总 RAW 平方成本上界，严格小于同来源的全空间、不同来源分量之间的交互成本下界。这个差距说明全空间交互项在这些输入中包含可被一个帽实际擦除的成本。它不证明一般来源的共同帽预算，也不是算子弱型下界。高维固定帽 RAW 成本本身增长明显，未得到统一维数改善。

质量与阈值均为 W = kappa = 1。定义如下：

```text
Q(x,L) = x + [-L/2,L/2]^n
T_L(x) = nu(Q(x,L)) / L^n
e(x) = integral_0^infinity (T_L(x)-1)_+^2 dL/L
E*(A) = inf_{measurable Omega, |Omega| <= A} integral_{Omega^c} e(x) dx
RAW(Omega) = integral_{Omega^c} integral_0^infinity T_L(x)^2 dL/L dx
```

下界对任意可测帽成立；网格上界与固定立方体上界各自使用明确的一个帽。两种帽不混作“同一个帽”。同帽 excess 不超过 RAW，但二者不相等。

## 1. 新来源及三阶段

张量来源的一维因子是中心在 ±a 的两分量概率律，其中 a = 1/8。弥散半宽 eps = 1/128，两区间不相交；负中心的概率为 p。n 维来源是这一个实际一维律的独立乘积。eps = 0 的原子案例与 eps > 0 的密度案例是不同输入，没有使用能量在平滑下收敛的假设。每个乘积来源虽有 2^n 个分量，代码不枚举它们。

另一真正相关的二维来源由四个边平行正方形组成，中心为 (0,0)、(1/4,0)、(0,1/4)、(1/2,1/2)，质量依次为 1/2、1/4、1/8、1/8，半宽为 1/256。这是四个实际均匀盒的混合，没有以中心原子替换其捕获概率。

| 阶段 | 新网格案例 | 压缩接收单元数 | 实际张量固定帽维数 |
|---|---|---:|---|
| 初探 | n=2，p=2/3，原子与弥散分别计算 | 78 + 78 | 2、4 |
| 压力 | n=4 偶对称弥散张量；二维相关混合 | 126 + 1156 | 8、16 |
| 扩展 | n=8 粗网格及加密；n=16 偶对称张量 | 45 + 1287 + 153 | 64、128 |

合计 2923 个新接收单元、28 项网格能量预算、24 项固定立方体帽预算。网格中 26 项得到有限上界；两项二维最小预算的上包络仍有未完全删除的无限单元，保留 UNKNOWN。24 项固定帽中 23 项得到有限实际 RAW 上下界；n=2、A=1/16 的这个特定立方体未包含来源，代码不给有限证书。这不判断该预算下其他帽的最优能量。

固定立方体系列六个维数均使用 p=1/2 的同类实际弥散张量律。七个网格案例是六个不同来源律；固定立方体系列的 n=4、8、16 已包含在网格来源中，n=2、64、128 另增三个，故跨两系列共有九个不同来源律。

预算均为 A = 1/16、1/4、1/2、1。扩展阶段另在 n=128、A=1 的同来源、同帽上把尺度分段从 1024 加密至 2048；这是精度检查，不是新输入。十二项一维平方积分恒等式分别检查弥散小尺度及原子来源的独立闭式。

## 2. 全接收体积与任意帽的能量下界

把每个接收坐标划为等长区间。张量来源关于坐标置换不变；仅在 p=1/2 时还关于每个坐标的独立反射不变。具有计数向量 k 的整个置换盒并集体积为

```text
volume(k) = n! / product_j(k_j!) * h^n                     (不反射折叠)
volume(k) = n! / product_j(k_j!) * (2h)^n                  (偶对称来源)
sum_j k_j = n
```

第二行包括全部正负正交象限；零坐标边界只有零体积。它没有把 n 维接收者降为一维或计数空间上的替代测度。各轨道总和严格等于 (2R)^n。相关二维来源直接使用 h^2 的矩形体积。

对接收区间 I 及一个真实来源区间 J，近到达距离为 2 dist(I,J)，远到达距离为 2 max{|x-y|: x in I, y in J}。近阶跃把整个来源分量过早计入，因此支配真实部分捕获；远阶跃直到整个来源分量被所有接收点捕获才计入，因此受真实捕获支配。张量捕获是这些真实一维概率的乘积。对各近、远阶跃的乘积形成累积捕获质量 M(L)，全尺度分段精确积分，得到每个整个接收单元上的能量下、上包络。二维相关来源使用各来源盒的全近、全远到达距离，方向相同。

积分不是尺度网格求和。若 M 在一个尺度段内固定，以 u = L^n 换元：

```text
integral (M/L^n-1)_+^2 dL/L
 = [ M^2/(2n) * (1/u0^2 - 1/u1^2)
     - 2M/n * (1/u0 - 1/u1)
     + (log u1 - log u0)/n ],
 u1 = min(M, 下一到达距离^n), 且仅在 u0 < u1 时计入。
```

对下包络按密度排序，允许删除任意单元内的任意体积，给任意可测帽最优成本的下界。对上包络排序实际选择一个帽：完整删除若干轨道，并至多部分删除一个轨道。在该轨道的每个互不相交的 Cartesian 盒内，沿第一坐标从左切相同比例。这是可测的全 n 维集合，确切实现保存的删除体积。帽与 L 无关；JSON 保存完整单元 ID 的压缩列表、校验哈希、部分切片比例和真实体积。

近到达为零的上包络可能为无限。这样的单元必须完全删除才可给有限上界；部分删除后仍有未删无限包络，程序明确 UNKNOWN，不以代表点或有限截断掩盖。

来源质量为一，故 L >= 1 的 excess 精确为零。来源在 [-b,b]^n 内；接收域 [-R,R]^n 取 R >= b+1/2，其外所有 excess 也精确为零。这两条只用于 excess，不能用于 RAW。

## 3. 同一个网格帽的 RAW 与外接收尾

对累积捕获质量的阶跃，用其平方的增量积分 RAW：

```text
RAW step primitive = sum_j (M_j^2-M_(j-1)^2)/(2n * arrival_j^(2n)).
```

这不是 sum_j(delta M_j)^2。程序用网格 excess 所选择的完全相同帽计算域内 RAW 上下界，并给域外加一个实际全尺度尾上界。对 maxnorm(x)=t >= R，捕获只能从 L >= 2(t-b) 开始，由质量一得到

```text
RAW outside [-R,R]^n
 <= 2^(-n-1) * sum_{k=0}^{n-1}
      binom(n-1,k) b^k / ((n+k)(R-b)^(n+k)).
```

这个尾由实际径向 Lebesgue 壳体积 n*2^n*t^(n-1) dt 积分得到，没有把 RAW 在域外误设为零。域外 RAW 下界可丢弃，仍是合法下界。

## 4. 实际弥散张量的固定立方体帽

另一明确的共同帽是 Omega_r = [-r,r]^n。r 是 A^(1/n)/2 向下舍入到 24 位 dyadic 的值；代码以整数比较证明 (2r)^n <= A。只在 r > b 时给有限 RAW 证书。

一维 q_L(x) 是真实来源区间与 [x-L/2,x+L/2] 的重叠概率。定义

```text
X(L) = integral_R q_L(x)^2 dx
C(L) = integral_[-r,r] q_L(x)^2 dx
N(L) = X(L)^n - C(L)^n
RAW(Omega_r) = integral_0^infinity N(L) L^(-2n-1) dL.
```

固定 L 时 q_L 是连续分段仿射函数；所有来源端点 ±L/2 和帽端点都加入分段。每段 [u,v] 的平方积分准确为

```text
(v-u) * [q(u)^2 + q(u)q(v) + q(v)^2] / 3.
```

原子对照的阶跃段按常值准确积分。这项计算保留真实弥散密度，不是来源原子的代理模型。

N(L) 是固定帽外非负捕获平方的积分。q_L 对 L 逐点非减，因此 N 非减；不是仅由 X 和 C 各自非减来推断其差非减。每个尺度段 [lo,hi] 由 N(lo)、N(hi) 乘准确的正核积分夹住：

```text
kernel integral = (lo^(-2n)-hi^(-2n))/(2n).
```

L <= 2(r-b) 时帽外捕获为零。L >= L1 = 2(r+b) 时帽内完全捕获，且

```text
X(L) = L-s,  C(L) = 2r,
s = E|Y-Y'| = (2eps/3)[p^2+(1-p)^2] + 4a p(1-p),
RAW tail from L1
 = sum_{k=0}^n binom(n,k)(-s)^k / [(n+k)L1^(n+k)]
   - (2r)^n / [2n L1^(2n)].
```

s 的公式要求 a >= eps，即两来源区间不相交；代码更严格检查 eps < a。尾为准确有理数，没有有限尺度截断。各段贡献向外舍入到 dyadic60 后求和，以有限误差包络控制分母大小。JSON 的上下界覆盖这全部舍入，不把尺度端点计算称为精确积分值。

以下是 A=1 的实际 RAW 区间的十进制近似，仅作展示；严格分数端点在 JSON。

| n | 固定同帽 RAW 区间，显示近似 | 不同分量全空间交互下界，显示近似 |
|---:|---:|---:|
| 2 | [0.21709, 0.21964] | 1.44162 |
| 4 | [0.10956, 0.11491] | 3.79336 |
| 8 | [0.07454, 0.08588] | 30.80639 |
| 16 | [0.08489, 0.09966] | 2467.66108 |
| 64 | [2.62918, 3.12431] | 1.55888e15 |
| 128 | [1001.83656, 1194.18889] | 1.22301e31 |

最后一行的同帽尺度加密把区间缩至约 [1045.78090, 1141.76960]。这不是对随维数增长的阶进行拟合。原始上包络宽度在扩维时可能很大：例如 n=8 的 A=1 网格能量上界由粗网格约 5.39484 降到加密网格约 0.35959，而固定立方体 RAW 上界约 0.08588。它们是不同帽或不同包络，报告各自的费用，不交换同帽字段。

## 5. 不受帽限制的交互价与擦除差距

不同分量的真实来源点差距在每坐标满足 nominal difference ±2eps。核 K_n 对每个绝对差距坐标非增，因此向外、向内距离端点给真实不同盒交互的下、上界。张量来源的 Hamming 距离 m 权重为

```text
binom(n,m) * [2p(1-p)]^m * [p^2+(1-p)^2]^(n-m),  m >= 1.
```

它是有序来源对的权重，等于 2 sum_(i<j)，没有漏乘二或再除二。权重和严格为 1-[p^2+(1-p)^2]^n。同分量被明确省略。全空间总 RAW 对原子来源及非零弥散密度都无限；这里的不同分量交互是有限的部分成本，从不称为总 RAW 上界。

对 m 个坐标等于 r、其余 n-m 个坐标等于 z，0 <= z <= r，真实核还可准确压缩为

```text
K = r^(-n) sum_{k=0}^{n-m} binom(n-m,k)(-z/r)^k
                 * (n+k-1)! m! / (n+k+m)!.
```

这是实际 n 维交叠体积的 beta 积分，不是 Hamming 维数上的替代核。n <= 4 时代码同时和一般 elementary-symmetric 多项式核公式逐项核对。

所有 23 项有限固定帽记录都保存严格有理差距“不同分量交互下界 − 同帽总 RAW 上界”，且差距为正。因 RAW 已包括同帽外的所有来源及所有尺度，这项不等式真正量化了全空间交互的过价；它只适用于这些公开中性的具体来源与帽。没有推导未公开来源结构、一般子幂费用或原算子的新下界。

## 6. 重放与结论范围

程序 stdlib、自包含，无旧轮导入，确定性输出。运行：

```text
python3 energy_probe.py
```

最终生产执行约 3.9 秒，运行时只在 stdout 作为诊断，不写入 JSON。全部严格算术是 Fraction：对数用 40 项 atanh 有理级数和几何余项，准确二进制范围归约、归一化实参向外 dyadic56、最终向外 dyadic44。Mixed-sign 系数以正确端点传播。十二项独立一维闭式检查覆盖弥散小尺度平方积分及原子 pair-overlap 恒等式。加密检查保留同一来源、同一个帽。

有限证书没有遗漏 excess 的空间或尺度补集；RAW 的外域尾及大尺度尾都显式保留。UNKNOWN 指当前具体包络或具体帽不能给有限上界，不指最优能量为无限。任意正 L1 来源的统一共同帽能量费用仍未证明。

The full-period receiver probe now certifies a positive-volume subset that satisfies the original smooth upper gate throughout its scale window. The proof uses centered moments under an explicitly normalized receiver law and pays the full likelihood when converting to Haar volume. The original coarse gate remains unresolved, so no full residual-volume, high-load or general weak-bound conclusion follows.

## Independent Astra audit

Full matching Markdown and TeX proof review passed for coverage, adaptive, alternative, sources and the parent note. Precise statements and counterpressure were checked before author proofs. The audit preserves one common cap for all scales, actual Lebesgue receiver volume, the original common source, and the distinction between cancelled-square, raw-square and positive-excess costs.

The proved gains have specific remaining costs. Coverage pays the long-scale excess by an actual bounded-distance coupling and obtains an A=1, B<=1+4/(3n) cap for the stated separated packet class; arbitrary inputs and short-range screened interactions remain open. Adaptive pays low and deep annular traffic at root-polylog order but retains the exact shallow traffic, initial branch fees, child-threshold absorption and finite/infinite terminal distinctions. Alternative proves the all-input one-cap logarithmically weighted cancelled-square comparison; its fine-scale weight is unpaid. Sources proves the explicit dimension-free cancelled L2 constant 1645/144; endpoint geometry and the qualified dyadic count tail do not supply the missing excess budget. No general root bound is claimed.

The neutral energy report and self-contained producer passed full review and an independent isolated replay. Its JSON matched byte-for-byte. Nine distinct laws give 2923 actual receiver cells, 28 histogram budgets and 24 fixed-cube budgets; two histogram envelopes and one specified cube remain UNKNOWN. All 23 finite fixed-cube comparisons have a positive exact gap between unrestricted cross-component lower cost and the same cap's total raw upper cost. Refinements are not new physical inputs, and the fixed finite certificates are not an asymptotic or general-input bound.

Private parent and phase certificates were also independently replayed with exact mathematical output agreement. The phase result certifies a positive-volume subset satisfying the original whole-window smooth upper gate, while coarse/full-residual qualification remains unknown. Private source recipes, lower constructions and quantitative outcomes stay outside this public summary. Author finite checks, this auditor's executions and the Sol auditor's separate guard are distinct evidence. The only independently browsed primary item claimed here is the stated dyadic-variation theorem; author proof-reading provenance is not attributed to this auditor.

## R94 independent audit — final mathematical review

The general root-order centered-cube weak estimate remains UNPROVED. Sol read the full round contract and issued independent target/quantifier diagnostics before new proofs. Review requires one cap for every scale, actual receiver volumes, original source mass and fully paid threshold, child, exit and terminal terms. Cap-restricted interaction, cancelled-square transfer and diffuse approximation each retain their own unproved prerequisites. Prior-round checks are not new evidence. Full Markdown and matching TeX review has accepted the new uniform cube cancelled-square bound, all-input weighted common-cap bridge, and paid low/deep adaptive traffic with its thin-flow defect retained. Private grid and smooth-qualification numerical replays match every mathematical field under the stated runtime exclusions. Coverage assembly has also passed full dual-format review, with its short-scale capacity retained. Public tensor full code/report and a frozen isolated byte-exact JSON replay pass. The standalone independent guard passes with2923 actual cell-volume reconstructions,28 cap-volume witnesses and two independently rebuilt all-scale fixed-cube RAW continuum certificates; it does not claim2923 histogram energy reconstructions. Generic algebra, source/receiver certificate rebuilds and producer replays are separately attributed. Private construction recipes stay outside the published text and guard. Guard and replay units are attributed separately; no arbitrary-source root estimate is claimed.

## 第94轮实际验证和复现边界

新命题先提交两位独立审计检查量词和潜在反例，再完整读取 Markdown 及对应 LaTeX。两审通过覆盖的阈值扣除/运输尾、部分需求的低深环支付、一般加权桥接、统一取消平方函数及主代理真实L1压力证明。一般根号阶结论未被认证。主代理完整审读新结果并重放最终程序；作者执行、审计重放和主代理重放分别记录，同一确定性程序重跑不增加实验数。

公开能量程序三阶段覆盖9个不同物理来源律（1原子、8正密度）。7项网格报告对应6个不同来源律，合计2923个真实连续接收单元、28项预算，其中26项有限上界、2项粗包络UNKNOWN。6个维度的固定方体删集给出24项预算，其中23有限、1项该删集UNKNOWN；其中3个来源律与网格报告重合。另对最高维同一来源、同一删集作1024到2048尺度单元加密，不计新输入。23个严格有理差距比较全空间异来源交互下界与该同一删集的完整RAW上界，只说明指定证书过价，不能称作一般弱型下界。全部体积、部分单元切片、无限空间与尺度尾保留；12个一维闭式检查另计。

最终生产3.826662625秒，主代理隔离执行3.645216250秒，两审独立隔离执行分别3.634135125和3.857961292秒（外部墙钟）。主代理比较全部解析JSON字段，两审确认结果文件逐字一致，无字段排除。生产JSON没有运行时间字段；重复运行不增加实验数。没有从这些有限维度删集证书拟合一般指数。

部分需求作者三阶段894项精确检查（162/366/366）验证物理连续几何公式、有限点核与父阈值费用系数；私人几何没有满足子接触与完整原门条件，不能称作合资格递推反例。主代理从最终冻结文本提取唯一私人程序隔离执行0.018648292秒，894项通过。最后的审计状态文字更新未改变执行代码。低尺度和深环的一般证明覆盖全部真实递推，不靠有限检查作渐近外推。

替代路线新程序验证48个一般Hardy序列、8个终项陷阱、1344个尺度相位索引。私人真实来源检查含972个方体平均轮廓、15768个尺度节点、1539个区间平均检验及14个整洞层；这些单位不相加为断言数，也不是连续任意输入能量的数值积分。主代理提取完整私人程序，隔离运行0.324576916秒，所有断言及三条阶段JSON与作者记录精确相等。原代码块体哈希与添加最终换行后的执行文件哈希分别记录，差别仅是结尾换行。

覆盖作者三阶段执行90个运输尾精确代数比较、180个阈值屏蔽比较、9个真实正密度多簇几何族和27项私人压力参数。主代理阅读完整证明，独立公开守卫另检验新不等式。可数分解、同一删集、来源依赖屏蔽以及有界位移假设全部保留。作者参数检查与审核者程序不重复计为新物理实验。

来源作者针对全局sinc证明执行156项新Fraction断言。另24012项实际立方体乘子比较与6项截断Simpson积分只是FLOAT诊断，没有积分误差证书；统一全尺度常数1645/144由解析证明承担。新原文阅读为Bourgain–Mirek–Stein–Wróbel arXiv1708.04639v2印刷p5及§3 pp13–14的所述证明范围；其外引Poisson变差/LP等证明未重新阅读。两审自行核对了原文Thm1.2声明，不能说成两审也完整重读§3。p>1、r>2以及未给出的端点常数均保留。

主代理的私人交互程序先有原子版本，再直接延伸到真正正L1来源，未假设能量弱极限连续。最终三阶段原子7项实际交互/19项上包络，加上21项弥散配置/57项上包络；包络积分的下端点不是实际能量下界。最终生产1.092662916秒，主代理隔离1.113736500秒，两审隔离分别1.119412542、1.217745625秒（均外部实测墙钟）。全部数学JSON仅删除顶层runtime_seconds后精确一致。先前原子版本的执行作为历史版本，不重复计实验或替代最终版本检验。

私人完整周期检验只用冻结的同一硬带与提议法，新增两个预先批准的Fourier截断级别，分别以64和128个无间隙尺度单元包围整个原窗口；全部n尾、定心均值和方差及完整似然被支付。初探预算不足为UNKNOWN，加密后得到正体积硬带与原全窗P1上门交集。原粗门仍UNKNOWN，没有全余集、主割容量或高负载结论。新交集未被推断具有旧带的完整坐标投影。中间非物理Rademacher、定心均值及错误Haar减Q费用检查仅是精确代数压力，不算实际来源确认。

私人程序生产2.169433500秒，主代理完整隔离2.762685292秒，两审独立执行分别2.133902959、2.163606458秒。全部数学JSON精确一致，递归仅删除runtime_seconds与runtime_seconds_diagnostic，保留192个全尺度均值区间、真实箱内Fourier积分、所有有理尾/半径/似然端点、代码和六项前轮依赖哈希。二进浮点计算均使用已审定向区间，打印小数仅为显示；真正体积下界使用有理对数第一端点。无物理抽样、Monte Carlo、CLT、未证明的中偏差替代或额外粗门搜索。

独立公开守卫只依赖自身与energy_results.json，重新构造全部2923个实际单元体积和28项同一删集体积见证；没有独立重建全部网格能量包络。它另以独立CDF及分段精确Simpson积分重建2个全尺度固定帽RAW证书：n=2、预算1/4的64个尺度单元，以及n=128、预算1的1024个尺度单元，均含零前缀及解析无穷尾。其他检查为3个一般Hardy序列、9个实际径向分区模型、3个阈值扣除参数及统一多项式/阶乘/积分证明支持，不是实际合资格递推链。Sol首次独立守卫运行0.663771042秒通过；主代理和最终归档提取重放的实测回执另记于清单及轮次README。不同检查单位不相加为“总断言数”。

更新64项技能的入口字节快照只记录版本，不代表所有数学内容重新验收。主代理实际读取L02、N04入口、方法、课题接口和当前有限望远镜范围；来源组实际读取F05/F06相关入口、方法、接口、账本声明及出处边界，使用获授权的只读完整证据根目录。F05不提供一次Schur到尺度上确界的自动转移，F06正交前提不自动适用于cube尺度增量。未修改技能注册表，未把哈希或技能名称作为证明。

公开复现材料只含报告、详细LaTeX文本、必要能量程序与结果、清单；从proof.md唯一Python代码块提取audit_guard.py，与公开结果同目录运行。私人程序、原始PDF、重复草稿和新下界配方不入归档。LaTeX只静态检查环境、括号、标签和控制字符，不编译、不生成PDF。一般目标仍开放：真实薄环累计费用、一般来源的细尺度共同删集/屏蔽交互、或加权平方函数细尺度尾尚缺统一根阶或子幂预算。


## 独立公开审核程序

```python
"""R94 independent public exact guard; standard library, no producer imports.
Scope: NEW exact theory algebra, actual tensor cap volumes and independently
rebuilt fixed-cube raw continuum certificates. No private construction or endpoint claim.
"""
from fractions import Fraction as F
import json
from math import factorial


def multiply(a,b):
    c=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c


def uniform_multiplier_certificate():
    # These polynomial identities plus their domain signs prove the scalar
    # comparisons used after the analytic alternating-sine Taylor remainder.
    taylor=[F(1),-F(1,6),F(1,120)]
    linear=[F(1),-F(2,15)]
    delta=[taylor[i]-(linear[i] if i<len(linear) else 0) for i in range(3)]
    assert delta==[F(0),-F(1,30),F(1,120)] # t(t-4)/120 <=0 on [0,4]
    cross=multiply(linear,[F(1),F(1,10)]);cross[0]-=1
    assert cross==[F(0),-F(1,30),-F(1,75)] # <=0 for t>=0
    assert F(4)>=F(10,9) # high-side 1/t <=1/(1+t/10)
    low_integral=F(25,36)*F(1,4)
    high_integral=F(90,4)*F(1,2)
    assert low_integral+high_integral==F(1645,144)<12
    return {'analytic_support':'Alternating sine remainder and |sin|<=1 are proved in text; guard checks exact polynomial/scale-integral algebra.',
            'uniform_cancelled_L2_squared_bound':str(low_integral+high_integral),
            'endpoint_or_excess_transfer':'NOT CLAIMED'}


def hardy_and_radial_checks():
    fields=0; radial=0
    # Generic finite sequences; they do not assert a realized cube orbit.
    for values in ([F(1)]*3,[F(1,j) for j in range(1,9)],
                   [F(0),F(2),F(1),F(3),F(1,2)]+[F(0)]*11):
        tail=list(values)+[F(0)]
        lhs=sum(u*u for u in values)
        rhs=4*sum(F(j*j)*(tail[j]-tail[j-1])**2 for j in range(1,len(tail)))
        assert lhs<=rhs; fields+=1
    # Actual cube radial kernel algebra for rational full-side arrival radii.
    # No physical source recipe or gated recursion is inferred.
    for n,root in [(4,2),(16,4),(64,8)]:
        M=1+root
        for old,child,arrival in [(F(3,2),F(1),F(11,10)),
                                  (F(3,2),F(5,4),F(7,5)),
                                  (F(9,8),F(1),F(17,16))]:
            assert child<arrival<old
            psi=max(F(1),arrival)**(-n)
            xi=psi-old**(-n); assert xi>=0
            if old**n<=M:
                assert arrival**n<=M # psi_* retains this lost pair
                assert psi>=old**(-n)
            elif psi>=M*old**(-n):
                assert xi>=(M-1)*old**(-n)
            else:
                assert arrival>1 and arrival**n>old**n/M
            radial+=1
    return fields,radial

def screened_transport_certificate():
    # Universal two-branch debit identities, written as coefficient vectors in p.
    # If p<=t, sign uses 2t-(1+t)p>=t(1-t)>=0.
    # If p>=t, sign is the displayed exact square t^2(1-p)^2.
    for t in (F(1,4),F(1,2),F(3,4)):
        major=[F(0),2*t*(1-t),t*t]
        low=[major[0],major[1],major[2]-1]
        factored=[F(0),2*t*(1-t),-(1-t)*(1+t)]
        assert low==factored
        high=[major[0]+t*t,major[1]-2*t,major[2]]
        assert high==[t*t,-2*t*t,t*t]
        assert 2*t-(1+t)*t==t*(1-t)>0
    # Positive factorial-series ratio majorants prove the analytic constants
    # for ALL u in [0,1], rather than checking a float grid.
    cosh_minus1_upper=F(1,2)+F(1,24)/(1-F(1,30))
    sinh_upper=1+F(1,6)/(1-F(1,20))
    assert cosh_minus1_upper<1 and 2*sinh_upper<3
    assert 2*F(1,2)==1 # integral_R^inf 2(2nd/L)^2 dL/L
    return {'debit_polynomial_thresholds':3,
            'cosh_minus_one_series_upper':str(cosh_minus1_upper),
            'twice_sinh_series_upper':str(2*sinh_upper),
            'transport_tail_constant':1,
            'scope':'Exact scalar proof-support algebra; common physical coupling existence remains a hypothesis.'}


def cell_volume(spec, identity):
    n=spec['n']; h=F(1,spec['mesh'])
    if spec['kind']=='correlated_uniform_boxes':
        assert len(identity)==2
        R=F(spec['receiver_R']); N=int(R/h)
        assert all(-N<=j<N for j in identity)
        return h*h
    assert len(identity)==len(spec['bin_edges']) and sum(identity)==n
    assert all(isinstance(j,int) and j>=0 for j in identity)
    mult=factorial(n)
    for j in identity: mult//=factorial(j)
    return mult*(h*(2 if spec['folded_reflection'] else 1))**n


def weak_compositions(n,k):
    if k==1:
        yield [n]
    else:
        for j in range(n+1):
            for tail in weak_compositions(n-j,k-1): yield [j]+tail


def tensor_witness_volumes(data):
    import base64,zlib,hashlib
    from itertools import product
    cells_count=caps_count=0
    for stage in data['stages']:
        for case in stage['histogram_energy_cases']:
            spec=case['source'];n=spec['n'];R=F(spec['receiver_R']);h=F(1,spec['mesh'])
            assert (R/h).denominator==1
            assert R>=F(spec['source_support_radius'])+F(1,2)
            if spec['kind']=='correlated_uniform_boxes':
                N=int(R/h);ids=product(range(-N,N),repeat=2)
            else:
                ids=weak_compositions(n,len(spec['bin_edges']))
                assert spec['folded_reflection']==(F(spec['negative_peak_probability'])==F(1,2))
                N=int(R/h);start=0 if spec['folded_reflection'] else -N
                assert spec['bin_edges']==[[str(j*h),str((j+1)*h)] for j in range(start,N)]
            volumes={tuple(i):cell_volume(spec,i) for i in ids}
            assert len(volumes)==case['compressed_receiver_cells']
            assert sum(volumes.values())==F(case['full_domain_volume'])==(2*R)**n
            cells_count+=len(volumes)
            for row in case['curves']:
                cap=row['selected_cap'];payload=zlib.decompress(base64.b85decode(cap['fully_deleted_cells_zlib_base85']))
                assert hashlib.sha256(payload).hexdigest()==cap['fully_deleted_cell_ids_sha256']
                gone=json.loads(payload);keys=[tuple(i) for i in gone]
                assert len(keys)==len(set(keys))==cap['fully_deleted_cell_count']
                v=sum((volumes[k] for k in keys),F(0))
                part=cap['partial_cell']
                if part:
                    key=tuple(part['cell']);assert key not in keys
                    deletion=F(part['deleted_volume']);fraction=F(part['first_coordinate_slice_fraction'])
                    assert 0<deletion<volumes[key] and deletion==fraction*volumes[key]
                    v+=deletion
                assert v==F(cap['actual_cap_volume'])<=F(row['budget'])
                assert cap['single_cap_independent_of_scale'] is True
                if row['selected_single_cap_excess_upper'] is None:
                    assert cap['singular_upper_cells_remaining'] is True
                else:
                    assert cap['singular_upper_cells_remaining'] is False
                caps_count+=1
    return {'new_actual_histogram_cell_volumes':cells_count,'decoded_single_cap_volumes':caps_count,
            'scope':'Independent exact true cell/orbit volume, disjoint full IDs and partial slices; not reconstruction of histogram energy envelopes.'}


def dyadic_floor(x,bits):
    return F((x*(1<<bits)).numerator//(x*(1<<bits)).denominator,1<<bits)


def dyadic_ceil(x,bits):
    return -dyadic_floor(-x,bits)


def capture_square(L,a,e,p,r):
    # Independent exact integration: CDF differences and Simpson on each
    # affine-capture interval. Simpson is exact for the resulting quadratics.
    def cdf(t,c):
        if e==0:return F(int(t>=c))
        return max(F(0),min(F(1),(t-c+e)/(2*e)))
    def q(x):
        return sum((w*(cdf(x+L/2,c)-cdf(x-L/2,c)) for c,w in [(-a,p),(a,1-p)]),F(0))
    cuts={-r,r}
    for c in [-a,a]:
        for z in [c-e,c+e]:cuts.update([z-L/2,z+L/2])
    cuts=sorted(cuts);total=inside=F(0)
    for l,u in zip(cuts,cuts[1:]):
        if e: integral=(u-l)*(q(l)**2+4*q((l+u)/2)**2+q(u)**2)/6
        else:integral=(u-l)*q((l+u)/2)**2
        total+=integral
        if -r<=l and u<=r:inside+=integral
    return total,inside


def fixed_cube_raw_rebuild(data):
    from math import comb
    rebuilt=[]
    # One pilot and the largest expanded dimension validate two genuinely
    # different all-scale continuum certificates, not a test-count target.
    for stage_name,n,budget in [('pilot',2,F(1,4)),('expanded',128,F(1))]:
        stage=next(s for s in data['stages'] if s['stage']==stage_name)
        row=next(r for r in stage['actual_tensor_cube_cap_certificates'] if r['n']==n and F(r['budget'])==budget)
        assert row['status']=='FINITE_ACTUAL_TENSOR_RAW_CERTIFICATE'
        a=F(row['a']);e=F(row['halfwidth']);p=F(row['p']);r=F(row['cap_halfside'])
        b=a+e;assert 0<e<a<r and (2*r)**n==F(row['actual_cap_volume'])<=budget
        assert (2*(r+F(1,1<<row['radius_rounding_bits'])))**n>budget
        low=2*(r-b);high=2*(r+b);s=2*e*(p*p+(1-p)**2)/3+4*a*p*(1-p)
        tail=sum((F(comb(n,k))*(-s)**k/((n+k)*high**(n+k)) for k in range(n+1)),F(0))-(2*r)**n/(2*n*high**(2*n))
        assert tail==F(row['exact_tail'])>=0
        lower=dyadic_floor(tail,60);upper=dyadic_ceil(tail,60)
        intervals=row['scale_steps']; X,C=capture_square(low,a,e,p,r);prev=X**n-C**n;assert prev==0
        for j in range(intervals):
            l=low+(high-low)*j/intervals;u=low+(high-low)*(j+1)/intervals
            X,C=capture_square(u,a,e,p,r);nxt=X**n-C**n;assert nxt>=prev
            weight=(l**(-2*n)-u**(-2*n))/(2*n)
            lower+=dyadic_floor(prev*weight,60);upper+=dyadic_ceil(nxt*weight,60);prev=nxt
        assert X==high-s and C==2*r
        assert lower==F(row['restricted_raw_interval']['lower']) and upper==F(row['restricted_raw_interval']['upper'])
        assert upper==F(row['excess_upper'])
        rebuilt.append({'stage':stage_name,'n':n,'budget':str(budget),'scale_intervals':intervals})
    return {'independent_actual_fixed_cube_raw_certificates':rebuilt,
            'scope':'Exact source CDF/Simpson integration, whole outside-cap tensor receiver integral, zero prefix and infinite-scale analytic tail; excess upper only for this same cap.'}


def numeric_guard():
    from pathlib import Path
    data=json.loads(Path(__file__).with_name('energy_results.json').read_text())
    assert data['schema']=='R94-actual-tensor-diffuse-onecap-allscale-v1'
    assert data['mass']==data['kappa']=='1' and data['original_Fnew_gates_claimed'] is False
    return {'volumes':tensor_witness_volumes(data),'raw':fixed_cube_raw_rebuild(data)}


if __name__=='__main__':
    fields,radial=hardy_and_radial_checks()
    print(json.dumps({'status':'PASS','generic_finite_Hardy_sequences':fields,'actual_radial_partition_models':radial,'uniform_multiplier_certificate':uniform_multiplier_certificate(),'screened_transport_certificate':screened_transport_certificate(),'new_numeric_guard':numeric_guard(),
        'scope':'New exact scalar/radial algebra and actual continuum numeric witnesses, separately attributed; no private recipe, FLOAT, old-round test or artificial assertion target.'},sort_keys=True))
```
