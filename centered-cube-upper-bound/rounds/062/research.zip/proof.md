# Round 62: an exponential obstruction to local allocation, and the actual halo

2026-10-11. The core objective remains **UNPROVED**: the retained fully general
weak-type upper bound is O(n log n), not sqrt(n)n^{o(1)}. This round changes
the proof strategy by disproving a proposed general local allocation
interface. It does not replace the general problem by a restricted upper bound.

The previous goal-turn skill reload verified all 64 current main-file hashes
and 437 direct local links. No new skill version appeared relative to the
Round 55 full-reading baseline. Relevant current skill and method interfaces
were read as used; no claim that all external papers were reread is made.

Round 61's valid 3^n local allocation and global signed projection tools are
retained. Its hope of improving the SAME local supports to polynomial height
is now rigorously refuted. The true good set, all tied cube arrivals, and
the total target density are kept throughout. Large target density norms or
transport displacement are not called signed-energy or weak-type lower bounds.

The numerical program began with a continuum-cube pressure pilot, then moved
to the actual atomic obstruction. Uniform angle sampling was supplemented by
importance mixtures and a positive finite recursion for the entire halo
volume. This is a multi-stage test of the general interface and of its repair,
not evidence for a fitted dimension exponent.

# Round 62: exponential obstruction to source-distance Hall allocation

2026-10-11. The local capacity conjecture is false: \(\Gamma_n\ge(4/3)^n\). Combined with Round 61, \(\max\{2,(4/3)^n\}\le\Gamma_n\le3^n\). Thus \(O(n\,\mathrm{polylog}(n))\) height is impossible for the original source-distance cubes. This does not refute the desired centered-cube weak bound or all longer-displacement replacement routes.

## Current skill interfaces

The disk versions of D01, N01 and L03, including each method.md and cube-interface.md under /Users/zhengzhihao/.codex/skills, were re-read. The proof uses only a static positive equal-mass coupling and direct cube geometry. No general transport strong duality, ellipsoid theorem, numerical interval API, or exterior literature theorem is transferred. L03 distinguishes exact rational checks from illustrative decimals.

## Exact subset reduction

For finite positive atomic \(\mu=\sum_i p_i\delta_{y_i}\), \(H>0\), put
\[
G_\mu=\{M\mu\le H\},\quad r_i(\mu)=\operatorname{dist}_\infty(y_i,G_\mu),\quad
S_i(\mu)=y_i+(-r_i(\mu),r_i(\mu))^n,\quad U_\mu=\bigcup_i S_i(\mu).
\]
Use closed centered cubes for the maximal averages. The Round 61 boundary audit ensures \(G_\mu\) is closed and nonempty, each \(r_i>0\) is finite with an attained nearest good point, and the allowed cubes are open.

The proper-subset supremum equals the full-source supremum **with core-union denominator**:
\[
\Gamma_n=\sup_{\mu,H}\frac{\mu(\mathbb R^n)}{H|U_\mu|}. \tag{1}
\]
For \(\nu=\sum_{i\in I}p_i\delta_{y_i}\), positivity gives \(M\nu\le M\mu\), hence \(G_\nu\supseteq G_\mu\), \(r_i(\nu)\le r_i(\mu)\), and
\(U_\nu\subseteq\bigcup_{i\in I}S_i(\mu)\).
Every subset ratio is therefore at most the full-source ratio of \(\nu\). Conversely full subsets are allowed. This reduction does not replace \(U_\nu\) by the generally larger halo \(\Omega_\nu\); ordinary halo reverse-weak estimates do not transfer for free.

## Exact vertex source and original distances

Fix \(d,H>0\). At each of the \(2^n\) vertices \(y_\varepsilon=d\varepsilon\), \(\varepsilon\in\{-1,1\}^n\), put mass \(p=H(4d)^n\). Then \(W=2^np=H(8d)^n\).

Every source distance is exactly \(r_\varepsilon=2d\). Indeed, any receiver at sup-norm distance less than \(2d\) from this atom has a single-atom average exceeding \(H\), including the infinite pole value. Thus \(r_\varepsilon\ge2d\).

For the upper bound choose \(g_\varepsilon=3d\varepsilon\). Its distance to its own vertex is \(2d\). Every other vertex has at least one opposite-sign coordinate, of distance \(4d\), while agreeing coordinates have distance \(2d\). Thus every other vertex is at sup-norm distance exactly \(4d\). For all radii,
\[
\mu Q(g_\varepsilon,r)=
\begin{cases}
0,&0<r<2d,\\
p,&2d\le r<4d,\\
2^np,&r\ge4d.
\end{cases} \tag{2}
\]
All averages are at most \(H\): \(p/(4d)^n=H\) and \(2^np/(8d)^n=H\). Both closed-boundary ties are exactly \(H\), and there is no intermediate subset capture. Hence \(g_\varepsilon\in G_\mu\), proving \(r_\varepsilon=2d\).

Finite Cartesian-product distribution now gives
\[
U_\mu=\bigcup_\varepsilon[d\varepsilon+(-2d,2d)^n]
=\left((-3d,d)\cup(-d,3d)\right)^n=(-3d,3d)^n.
\]
Consequently
\[
\boxed{\frac{W}{H|U_\mu|}=(4/3)^n.} \tag{3}
\]
This is exact finite atomic geometry, with no approximation or cap convergence. A particularly simple rational normalization is \(H=W=1\), \(d=1/8\): atoms at \(\{\pm1/8\}^n\), each mass \(2^{-n}\), source distances \(1/4\), good witnesses at \(\{\pm3/8\}^n\), and \(U=(-3/8,3/8)^n\), of volume \((3/4)^n\).

## Exact optimal height and inflation

The lower height \(\beta=(4/3)^n\) is attained. Partition \(U\), up to null coordinate hyperplanes, into sign orthants and assign to source \(d\varepsilon\) the density \(\beta H\) on its matching orthant. Its mass is \(\beta H(3d)^n=p\), and every coordinate displacement from the source is less than \(2d\) away from null boundary faces. Thus \(f_\varepsilon\) is supported in \(S_\varepsilon\), \(\sum_\varepsilon f_\varepsilon=\beta H\mathbf1_U\) almost everywhere, and the actual coupling is \(\sum_\varepsilon\delta_{d\varepsilon}(dy)f_\varepsilon(z)\,dz\). The original local allocation's minimum height is exactly \((4/3)^nH\); all proper-subset Hall tests hold at that height.

For enlarged displacement sets
\(S_\varepsilon^\alpha=d\varepsilon+(-2\alpha d,2\alpha d)^n\), the exact minimum height factor is
\[
b_n(\alpha)=
\begin{cases}
\alpha^{-n},&0<\alpha\le1/2,\\
[4/(1+2\alpha)]^n,&\alpha\ge1/2.
\end{cases} \tag{4}
\]
When \(\alpha>1/2\), the union is exactly \((-D,D)^n\), \(D=d+2\alpha d\). At \(\alpha=1/2\) coordinate hyperplanes are missing, but the same volume formula holds. For \(\alpha<1/2\) the cubes are disjoint. Their full Hall ratios give (4). Those lower bounds are attained: uniformly fill each cube in the disjoint regime; otherwise assign each source its matching sign orthant in \((-D,D)^n\), at height \(b_n(\alpha)H\). The orthant mass is \(b_n(\alpha)HD^n=p\), and its coordinate displacement is at most \(\max(d,D-d)=2\alpha d\), with only null endpoint boundaries.

Thus every fixed \(\alpha<3/2\) forces exponential height. For \(\alpha\ge1/2\), height \(\beta H\) requires
\[
\alpha\ge\frac{4\beta^{-1/n}-1}{2}
=\frac32-\frac{2\log\beta}{n}
+O((\log\beta)^2/n^2)\quad\text{if }\log\beta=o(n).
\]
Polynomial height requires inflation approaching at least \(3/2\), rather than \(1+O(\log n/n)\). At \(\alpha=3/2\), the explicit orthant construction has height \(H\) on \((-4d,4d)^n\). For \(\alpha>1\), this construction need not stay in the original bad set: it includes good receivers near its outer corners. Formula (4) is an exact result for enlarged displacement sets; intersecting them with \(\Omega\) retains the lower bound, but not necessarily the explicit upper construction. No general longer-displacement or signed-energy theorem is claimed.

## Independent rational checks

A standard-library Fraction run used \(H=7/5\), \(d=3/7\). In dimensions \(1,\ldots,10\), every vertex was enumerated and its distance to \(g=(3d,\ldots,3d)\) computed. Exactly one distance was \(2d\), the other \(2^n-1\) were \(4d\). At radius multipliers \(1,2,5/2,3,4,5,8\), all 70 captured-mass checks matched (2) and were at most \(H\); both ties were exactly \(H\).

Two one-dimensional intervals were merged using Fraction endpoints to obtain inflated union volume. For \(\alpha=1/4,1/2,3/4,1,5/4,3/2,2\), dimensions \(1,\ldots,10,16,32,64,128,256,1024\), all 112 exact product-volume/ratio checks passed. The high-dimensional checks use the proved Cartesian-product formula and do not enumerate \(2^n\) sources. These are finite reproducibility checks accompanying an analytic all-\(n\) proof, not an interval certificate. Illustratively only, \((4/3)^{32}\approx9954.9612\), \((4/3)^{128}\approx9.82106\cdot10^{15}\).

The affordable radius-one Hall route is rigorously obstructed. The general centered-cube weak upper objective remains unproved; more generous displacement geometry and its total signed-error payment remain open.

## Standalone exact reproduction

```python
from fractions import Fraction as F
from itertools import product
import json
H,d=F(7,5),F(3,7)
small=list(range(1,11))
large=[16,32,64,128,256,1024]
scales=[F(1),F(2),F(5,2),F(3),F(4),F(5),F(8)]
alphas=[F(1,4),F(1,2),F(3,4),F(1),F(5,4),F(3,2),F(2)]
capture_checks=0
for n in small:
    vertices=[tuple(d*s for s in signs)
              for signs in product([-1,1],repeat=n)]
    p=H*(4*d)**n
    g=(3*d,)*n
    distances=[max(abs(x-y) for x,y in zip(g,v)) for v in vertices]
    assert distances.count(2*d)==1
    assert distances.count(4*d)==2**n-1
    for t in scales:
        r=t*d
        count=sum(a<=r for a in distances)
        actual=F(count)*p/(2*r)**n
        expected=F(0) if t<2 else (
            p/(2*r)**n if t<4 else 2**n*p/(2*r)**n)
        assert actual==expected and actual<=H
        capture_checks+=1
    assert p/(4*d)**n==H and 2**n*p/(8*d)**n==H
volume_checks=0
for n in small+large:
    W=2**n*H*(4*d)**n
    for a in alphas:
        r=2*a*d
        intervals=sorted([(-d-r,-d+r),(d-r,d+r)])
        length=intervals[0][1]-intervals[0][0]
        length+=max(F(0),intervals[1][1]
                    -max(intervals[1][0],intervals[0][1]))
        actual=W/(H*length**n)
        expected=a**(-n) if a<F(1,2) else (4/(1+2*a))**n
        assert actual==expected
        volume_checks+=1
    assert W/(H*(6*d)**n)==F(4,3)**n
print(json.dumps({'actual_capture_checks':capture_checks,
       'exact_inflation_volume_checks':volume_checks,
       'closed_boundary_ties':'both exact H',
       'enumerated_dimensions':small,'tensor_dimensions':large},
       sort_keys=True))
```

## Exact total-density norm consequence

For the inflated supports of the vertex example, the same constant-density
allocation also minimizes total L2 norm squared: the value is
b_n(alpha) H W. Cauchy--Schwarz gives the lower bound W^2/|U_alpha|;
the explicit constant-on-union allocation attains it. Thus the original
local supports force both exponential height and exponential total L2 cost.
The retained spectral inequality is one-sided and cannot convert this
density norm lower bound into a signed-energy lower bound.

## 3. Any coupling must move almost all mass outside the local scale

A general elementary necessary condition is useful. Let a finite atomic source have mass \(W\), let \(S_i\) be allowed destination sets, and let \(\pi\) be any positive coupling with target marginal \(F\,dz\), \(0\le F\le\beta H\). Then
\[
 \pi\{(y_i,z):z\in S_i\}
 \le\int_{\cup_iS_i}F(z)\,dz
 \le\beta H\left|\bigcup_iS_i\right|.
\]
The first inequality holds because each allowed pair has its destination in the union; it does not assume the coupling has any particular construction. If the allowed sets have null boundaries, the same argument applies to their closures.

Apply this to the vertex source and closed displacement balls of radius \(2\alpha d\). For \(\alpha\ge1/2\), every such coupling satisfies
\[
 \boxed{\frac1W\pi\{\|y-z\|_\infty>2\alpha d\}
 \ge\left[1-\beta\left(\frac{1+2\alpha}{4}\right)^n\right]_+.}
\]
For smaller \(\alpha\), replace the exponential factor by \(\alpha^n\). The target is absolutely continuous, so union boundaries do not contribute. At any fixed \(\alpha<3/2\), polynomial \(\beta\) makes the right side tend to one as \(n\to\infty\). Hence an affordable-height construction cannot repair the original local support by allowing only a small exceptional mass: almost all mass must escape any fixed subcritical inflation. This is a coupling-level necessary condition for arbitrary target choices and arbitrary positive plans. It is not a signed-energy lower bound.

## 4. A distinct-atom demonstration of the diagonal overlap loss

At the original radius, the individually affordable densities \(f_y=H\mathbf1_{S_y}\) each have mass \(p\), height \(H\), and \(\|f_y\|_2^2=Hp\). The source points are all distinct. Nevertheless their sum has
\[
 \|F\|_\infty=2^nH,\qquad
 \sum_y\|f_y\|_2^2=HW,\qquad
 \|F\|_2^2=(3/2)^n HW.
\]
Indeed in one coordinate the two intervals have lengths \(4d\) and overlap length \(2d\). Thus \(\int(\mathbf1_{I_-}+\mathbf1_{I_+})^2=12d\), and tensorization gives \(\|F\|_2^2=H^2(12d)^n\). The peak occurs on \((-d,d)^n\). This example exhibits exponential total-density overlap despite an exact diagonal budget, without splitting one atom into duplicate pieces. Even optimizing all the local pieces cannot reduce the total norm below \((4/3)^nHW\), by Section 2.

These are density Gram calculations, not signed error Gram lower bounds. The inequality \(\|DF\|_2^2\le\kappa_n\|F\|_2^2\) is an upper bound and cannot be reversed. In particular a large density norm alone does not prove large error on \(G\).

## 5. Exact remaining alternatives

The original cap-distance-support route cannot supply the height \(O(n\,\mathrm{polylog}(n))H\) or the corresponding affordable total-density \(L^2\) budget for all finite positive atomic sources. That failure is independent of absolute transport columns and of martingale drift.

A general positive bounded-density signed bridge remains possible only after relaxing these destination restrictions or changing the representation. Its missing statements are concrete:

1. An actual general-source target and coupling allowing the necessary nonlocal movement, with a proved total height or total \(L^2\) budget. The explicit \(3/2\)-inflated orthant construction above is only a diagnostic repair for the vertex family.
2. A source-uniform bound for the full signed error on the original good receivers. Coupling mass escape is not such a bound: the full signed quadratic depends only on the marginals, and displacement has not been related to a lower or upper signed budget here.

The local obstruction alone does not determine the full bad-set volume or obstruct allocation anywhere in that larger set. The next section derives its actual volume interface. The distinction is real already for the vertex source when \(n\ge2\): take \(x=((3+\varepsilon)d,d,\ldots,d)\), with \(0<\varepsilon<2\cdot2^{(n-1)/n}-2\). The centered cube of radius \((2+\varepsilon)d\) captures exactly the \(2^{n-1}\) vertices on the positive first-coordinate face and has average greater than \(H\). Thus \(x\in\Omega\setminus U_1\). Replacing the support union by \(\Omega\) changes the problem. The general weak bound \(C_n\le\sqrt n\,n^{o(1)}\) remains unproved.


# Exact vertex halo geometry and finite positive recursion

This section concerns the actual counterexample input, not an assumption on
general sources. Normalize d=H=1: mu assigns mass 4^n to every point of
{-1,1}^n, so W=8^n. Set R_k=2*2^(k/n), 0<=k<=n.

For x in the positive orthant put b_i=|x_i|, ordered as
b_(1)<=...<=b_(n). At averaging radius s each coordinate contributes zero,
one, or two captured vertices. At least one is captured in every coordinate
exactly when s>=max_i |b_i-1|; at least k coordinates contribute two when
s>=1+b_(k). If exactly j coordinates contribute two, the average is
2^j (2/s)^n and exceeds 1 exactly when s<R_j. It follows, in both directions,
that the strict bad set in this orthant is the union, k=0,...,n, of

    E_k={ b_(n)<1+R_k, b_(k)<R_k-1 },

where the second condition is omitted for k=0. To prove the reverse
implication, take an s strictly between the two required entry radii and
R_k; if additional coordinates are doubled, the average only increases.
The lower inequalities b_i>1-R_k are automatic since R_k>=2 and b_i>=0.
The closed-cube entry convention and strict level inequality therefore
produce exactly the stated strict conditions. The cases k=0 and k=n both
give the cube b_(n)<3.

Each E_k is coordinatewise decreasing, so the union is star shaped about
zero. On a positive cube facet write theta=(1,U_1,...,U_{n-1}), with the
remaining coordinates independent uniform [0,1]. Its radial boundary is

    B(theta)=max(3, max_{1<=k<=n-1}
                    min(1+R_k,(R_k-1)/theta_(k))).

Here theta_(k) are the sorted coordinates including the coordinate 1;
division by zero is interpreted as infinity. Thus 3<=B<=5 and cube polar
integration, including the 2^n signs and n choices of facet, gives

    |Omega|/8^n = E[(B/4)^n]
                = (3/4)^n + integral_3^5 n r^(n-1)/4^n P(B>r) dr.    (D)

This identity retains Lebesgue observation measure: the angular probability
is a parameterization of volume, not sampling by source mass.

For fixed 3<r<5, the event B>r is the union over eligible
k in {1,...,n-1} satisfying r<1+R_k of

    N(t_k)>=k,  t_k=(R_k-1)/r,

where N(t) counts the n-1 independent uniform coordinates <=t. All t_k
are strictly increasing and lie in (0,1). Equality events in the uniforms
have probability zero. Process the thresholds in increasing k. Conditional
on j coordinates being below the previous threshold v, the remaining
n-1-j coordinates are independent uniforms on (v,1). Their new count below
t_k is binomial with success probability (t_k-v)/(1-v). Multiply the
nonnegative current state weights by these binomial probabilities. At an
eligible threshold, remove states with new count >=k and add their weights
to the killed probability. At an ineligible threshold retain all states.
The removed weights sum to P(B>r), without subtracting an almost-one
survival probability from one. This finite recursion is exact in exact
arithmetic; its floating implementation still requires roundoff checks.

## Why event-aligned Gauss quadrature has finite exactness here

Partition (3,5) at the finitely many points 1+R_k. On any resulting open
interval the eligible index set is fixed. Partition the angular cube by
counts in the bins with endpoints 0,t_1,...,t_{n-1},1. Each multinomial
cell has probability

    multinomial(N_1,...,N_n)
       product_{i<n} ((c_i-c_(i-1))/r)^N_i
       (1-c_(n-1)/r)^N_n,

where c_k=R_k-1, c_0=0, and sum N_i=n-1. The tail event selects a fixed
subset of these count vectors on the current radial interval. Therefore
its probability is a polynomial in 1/r of degree at most n-1. Multiplying
by n r^(n-1)/4^n makes the integrand in (D) a polynomial in r of degree at
most n-1.

Consequently, event-aligned Gauss-Legendre quadrature of order
q>=ceil(n/2) has no quadrature truncation error in exact arithmetic. This
does not certify floating nodes, weights, algebraic breakpoints, powers,
or the finite recursion. Comparing q and 2q checks the implementation but
is not an outward-rounded numerical error certificate. Using lower q at
large n is only an exploratory approximation.

For n=1 there are no angular variables or interior thresholds: B=3 and
|Omega|/W=3/4 exactly.

## Independent deterministic volume envelopes

The orthant volume of E_k is

    V_k=sum_{j=k}^n binom(n,j) (R_k-1)^j 2^(n-j),

with V_0=3^n. The interval of large coordinate values has length 2.
Thus max_k V_k/4^n <= |Omega|/8^n <= sum_k V_k/4^n. Duplicated endpoint
sets can be removed to sharpen the upper bound. These are general-n
analytic inequalities for this input; evaluating the algebraic numbers
with ordinary floating point does not turn their numerical endpoints into
rigorous intervals. Neither these envelopes nor the finite recursion give
an arbitrary-source upper estimate.


The main finite pressure result concerns the actual positive atomic vertex source μ=4^n Σ_{y∈{−1,1}^n}δ_y, H=1, W=8^n. Its true centered-cube maximal halo has much more volume than the core cube [−3,3]^n. The computed necessary global capacity W/|{Mμ>1}| is about1.20790 in n64, whereas the core-only capacity is(4/3)^64. This source therefore exposes the inadequacy of that core support without numerically obstructing an affordable replacement supported on its entire halo. It gives no upper bound for general positive sources.

The all-scale geometry uses real centered cubes, not a scale grid or a source-weighted receiver integral. On a cube facet θ=(1,U2,…,Un), let θ_(k) be ascending coordinates and R_k=2·2^(k/n). The boundary radius is

r*(θ)=max(3, max_{1≤k≤n} min(1+R_k,(R_k−1)/θ_(k))).

The halo contains every ray up to radius3. Outside that cube, r≥3, the first vertex arrivals in every coordinate have occurred by halfside r−1; each later coordinate arrival doubles its vertex count. Thus the displayed finite formula follows from the exact arrival maximum. It also proves a single outer boundary and3≤r*≤5. Symmetry and Lebesgue cube-cone coordinates give |Ω|/W=E[(r*/4)^n]. Multiplicities are retained; the2^n vertices are never explicitly enumerated in the high-dimensional computation.

An independent positive probability recursion avoids relying on rare angular samples. For r∈(3,5), r*>r if some eligible k≤n−1 has R_k>r−1 and the count of n−1 uniform coordinates below t_k=(R_k−1)/r is at least k. Increasing t_k thresholds induce conditional binomial transitions. States crossing the eligible threshold are removed and their probabilities added directly; the code does not subtract a near-one survival probability. Integrating this tail gives

|Ω|/W=(3/4)^n+∫_3^5 n r^(n−1)4^(−n) P(r*>r) dr.

Radial quadrature is split at every1+R_k. On each interval the eligibility set is fixed and the tail probability is a polynomial in1/r of degree at most n−1. The weighted integrand is a polynomial in r of degree at most n−1, so Gauss order ceil(n/2) is sufficient in exact arithmetic. The actual program uses q=max(8,ceil(n/2)) and2q. Their differences are at most4.45×10^−16 across n1,2,3,4,8,16,32,64. This is a floating calculation, including its algebraic interval endpoints and binomial probabilities; it is not an outward-rounded volume certificate.

| n | actual halo volume/W | necessary capacity W/halo |
|---:|---:|---:|
|1|.750000000000|1.333333333333|
|2|.751839828220|1.330070531602|
|3|.762712215827|1.311110507015|
|4|.772696849622|1.294168599871|
|8|.797038611405|1.254644361881|
|16|.814214217177|1.228178013726|
|32|.823406222550|1.214467382700|
|64|.827884644996|1.207897750061|

The n2 value agrees with the independent closed expression(29−12√2)/16. Deterministic facet midpoint grids additionally check n2 at256/512 points and n3 at64²/128² points. These grid estimates are approximately consistent and need not converge monotonically. For each dimension the exact branch union inequalities max_k V_k≤|Ω|≤Σ_k V_k are checked with floating branch volumes V_k/W; n64 gives .20167≤.82788≤2.55902. These are consistency checks rather than an interval proof.

Sampling uses three uniform seeds and three fixed angular-mixture seeds per dimension n1,2,4,8,16,32,64. There are16384 draws per case below n32 and65536 draws in n32/64:42 cases and1,277,952 directions. The mixture uses α=(.5,.7,.85,1), weights(.2,.3,.25,.25), with independent free-coordinate density αθ^(α−1). Each component integrates to one by the one-dimensional power integral, and the full mixture density is evaluated for every draw. Parameters were fixed following the pilot before the final independent seeds; no fitted density is used. Uniform samples use different seeds. The pilot is not pooled into the final estimates.

Rare angular contributions remain visible. At n64, uniform volume estimates across the three seeds are .80265±.05091, .75110±.02980, .76270±.03267 (sample standard errors); mixtures give .81207±.02378, .81265±.02814, .79538±.02416. The highest1% of sampled contributions supplies about57–60% of uniform total and45–46% of mixture total. Contribution ESS is only248–629 uniformly and823–1146 for mixtures. The independent positive recursion, rather than these fluctuating samples, supports the reported finite volume. Sample SE and delta-method ratio SE are diagnostics, not certified confidence intervals. The score is bounded by(5/4)^n uniformly or4(5/4)^n for this mixture, since its uniform component has weight1/4. Hoeffding95% halfwidths in n64 are roughly8451 and33806 for a mean near .83, so the rigorous concentration bound is useless here.

The original continuum-cube pilot is retained separately: f=aH1_[−1,1]^n, n1,2,4,8,16 and a1.5,2,4,16,128 angles per case. Its all-scale maximum is computed from exact-form coordinate overlap fractions max(0,min(s,[1+(1−|x_i|)s]/2,1)), s=1/R. On the positive domain their log product is globally concave; derivative-sign bisection finds its maximum. Coordinatewise decrease proves a star-shaped halo. For every n and1<a≤2 the halo is precisely the source cube up to null boundary, since one outside coordinate has interval maximal average below1/2. Thus capacity=a exactly. In n1 the radius is max(1,a−1), matching the requested closed calibration. Four n2 midpoint refinements at512/1024 angles give capacity about2.400000 for a4 and1.777778 for a16. These limited continuum results were not expanded into a general claim.

There are63 implementation checks:25 continuous all-event maxima versus the global-concavity routine,31 exact Fraction explicit-vertex maxima versus compressed arrivals, and7 boundary sign checks through n64. The maximum numerical discrepancy is8.89×10^−16. Twenty-one retained top-scoring angular receivers are stored verbatim and checked at Decimal80/120 precision, including complete importance density and score. Maximum float radius relative error is1.40×10^−16, unweighted volume score error7.11×10^−15, complete importance score error7.33×10^−15, and Decimal80/120 radius difference3.49×10^−80. This cross-check uses nearest rounding and is not an interval certificate. The current L01/L02/L03 skills, method/provenance files and actual centered-cube interface warnings were reread. Finite geometry identities, floating integration, sampling uncertainty and unresolved general capacity are kept distinct; no exponent fit is made.

Reproduce the final run without --pilot, using the existing Python3.12.14/NumPy2.3.5 runtime:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round062_20261011/capacity_probe.py
```

The self-contained script writes results.json beside itself, contains no absolute import paths, sets its process BLAS threads to one, and records no runtime inside deterministic JSON. The pilot flag deliberately writes a smaller result to the same filename and is not the archived final run. The final default run actually completed in8.7382005seconds. The parent independently replayed the final program from a temporary directory; the complete JSON was byte-identical, as recorded below.


## Independent parent verification

The main script was copied to a fresh temporary directory and run without
the exploratory --pilot option. Its entire JSON matched byte for byte.
The standalone Fraction reproduction embedded in the capacity section was
independently executed, as was the additional exact guard below. No solver
installation, LaTeX compilation, or PDF generation was performed.

The following complete standard-library program can be saved as
vertex_exact_guard.py and run with Python 3. It writes a deterministic
vertex_exact_results.json. Small-dimensional checks enumerate actual atoms;
high-dimensional checks use the analytically proved coordinate factorization.

```python
"""Exact rational checks for Round 62; no floating asymptotic inference."""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path


def atom_max(points, masses, x):
    events = {}
    for y, p in zip(points, masses):
        r = max(abs(a-b) for a,b in zip(x,y))
        events[r] = events.get(r,F(0)) + p
    total=F(0); best=F(0)
    for r,p in sorted(events.items()):
        total += p
        if r==0:
            return None
        best=max(best,total/(2*r)**len(x))
    return best


def main():
    rows=[]
    for n in range(1,9):
        for d,H in [(F(1),F(1)),(F(2,3),F(5,7))]:
            points=list(product([-d,d],repeat=n))
            p=H*(4*d)**n
            # Check every good corner and all tied event groups in small n.
            check_points=points if n<=5 else points[::max(1,len(points)//16)]
            for y in check_points:
                g=tuple(3*z for z in y)
                assert atom_max(points,[p]*len(points),g)==H
                for inward in [F(1,100),F(1,4),F(1,2)]:
                    x=tuple(z*(3-inward) for z in y)
                    assert atom_max(points,[p]*len(points),x)>H
            W=H*(8*d)**n
            assert W/(H*(6*d)**n)==F(4,3)**n
            rows.append({'n':n,'d':str(d),'H':str(H),
                         'good_corners_checked':len(check_points),
                         'core_ratio':str(F(4,3)**n)})
    high=[]
    for n in [1,2,4,8,16,32,64,128,256,512,1024,4096]:
        # Coordinate-count factorization: no 2^n atom enumeration here.
        for r in [F(1),F(3,2),F(2),F(5,2),F(399,100),F(4),F(5),F(10)]:
            count=0 if r<2 else (1 if r<4 else 2)
            average=(F(2*count)/r)**n
            assert average<=1
            if r in [F(2),F(4)]: assert average==1
        for alpha in [F(1,4),F(1,2),F(3,4),F(1),F(5,4),F(3,2),F(2)]:
            ratio=alpha**(-n) if alpha<F(1,2) else (F(4)/(1+2*alpha))**n
            if alpha<F(3,2): assert ratio>1
            if alpha==F(3,2): assert ratio==1
            high.append({'n':n,'alpha':str(alpha),'ratio_nth_power_base':
                         str(1/alpha if alpha<F(1,2) else F(4)/(1+2*alpha)),
                         'numerator_bits':ratio.numerator.bit_length(),
                         'denominator_bits':ratio.denominator.bit_length()})
        # Exact density-overlap and minimum-norm identities, not energy bounds.
        d=F(2,3); H=F(5,7); W=H*(8*d)**n
        assert H**2*(12*d)**n/(H*W)==F(3,2)**n
        assert W**2/(6*d)**n/(H*W)==F(4,3)**n
        escaped=max(F(0),1-n*F(3,4)**n)
        assert 0<=escaped<=1
    # Uniform height-H target on [-4d,4d]^n partitioned by coordinate signs.
    # Each orthant box has exactly each source mass and displacement <=3d.
    for n in [1,2,4,8,32,256]:
        d=F(2,3); H=F(5,7)
        assert H*(4*d)**n * 2**n == H*(8*d)**n
        assert max(abs(F(0)-d),abs(4*d-d))==3*d
    result={'status':'all exact rational assertions passed',
            'small_dimension_explicit_atom_rows':rows,
            'high_dimension_factorized_rows':high,
            'scope':'finite checks of identities; general proof separately supplied',
            'floating_point_used':False}
    Path(__file__).with_name('vertex_exact_results.json').write_text(
        json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'explicit_cases':len(rows),'inflation_cases':len(high),
                      'status':result['status']}))


if __name__=='__main__': main()
```

### Actual replay receipt

```json
{
  "Python_AST": true,
  "agent_fraction_guard_exit_code": 0,
  "agent_fraction_guard_stdout": "{\"actual_capture_checks\": 70, \"closed_boundary_ties\": \"both exact H\", \"enumerated_dimensions\": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], \"exact_inflation_volume_checks\": 112, \"tensor_dimensions\": [16, 32, 64, 128, 256, 1024]}\n",
  "counts_checked": {
    "continuous_low_d_refinements": 4,
    "continuum_pilot": 20,
    "deterministic_vertex_rows": 16,
    "high_precision_extremes": 21,
    "implementation_guards": 63,
    "vertex_cases": 42,
    "vertex_receiver_samples": 1277952
  },
  "independent_replay_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round062-replay-9g3m8w85",
  "interpreter": "/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
  "main_replay_byte_identical": true,
  "main_replay_seconds": 8.761177291999047,
  "main_results_sha256": "adfc3314adc22770b0c60b68ca52629ecbdfa919bcd62cc1f06c0a392b9964ec",
  "main_script_sha256": "4ea69cabf576de13bcf90abc56d929521ca97e329fb8e646c60af71ff2acce90",
  "main_stderr": "",
  "main_stdout": "vertex 1 DP 0.75 capacity 1.3333333333333333\nvertex 2 DP 0.7518398282201788 capacity 1.3300705316015085\nvertex 4 DP 0.7726968496221833 capacity 1.2941685998706458\nvertex 8 DP 0.7970386114045418 capacity 1.2546443618807872\nvertex 16 DP 0.8142142171773941 capacity 1.2281780137255065\nvertex 32 DP 0.8234062225504174 capacity 1.2144673827003654\nvertex 64 DP 0.8278846449957051 capacity 1.2078977500605628\nruntime_seconds 8.712845041001856\n",
  "parent_exact_guard_results_identical": true,
  "parent_exact_guard_stdout": "{\"explicit_cases\": 16, \"inflation_cases\": 84, \"status\": \"all exact rational assertions passed\"}\n",
  "scope": "Finite exact guards and floating implementation replay; no general upper proof or interval-certified halo volume."
}
```

## Remaining proof requirements and route adjustment

Do not continue trying to prove polynomial height on the original
cap-distance supports: the exact counterexample rules it out. It also rules
out treating the forced nonlocal movement as a small exceptional mass.
Admit genuinely longer displacement or use the unrestricted bounded-density
projection, and prove a source-uniform bound on its full signed mixed error
on the ORIGINAL good receivers. An alpha=3/2 allocation theorem for arbitrary
sources has NOT been proved; the explicit construction here repairs only the
counterexample family. Even such a general allocation would not pay the
signed error automatically. The original general weak-type and all-scale
recovery still require complete proofs. No completion claim is made.
