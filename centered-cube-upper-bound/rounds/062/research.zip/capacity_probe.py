#!/usr/bin/env python3
"""Actual centered-cube capacity for constant density cubes and atomic vertices. Floating exploration."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,json,math,time
from pathlib import Path
from decimal import Decimal,localcontext
import numpy as np

def max_log_average(x,steps=38,return_radius=False):
    """Global maximizer: concavity of log overlap product in s=1/R."""
    b=np.abs(np.asarray(x,dtype=float)); b=np.atleast_2d(b)
    t=b.max(axis=1); inside=t<1
    lo=np.log(np.maximum(t-1,1e-300)); hi=np.log(t+1)
    for _ in range(steps):
        mid=(lo+hi)/2
        R=np.exp(mid)[:,None]
        partial=(R>np.abs(1-b)) & (R<1+b)
        den=np.maximum(R+1-b,1e-300)
        derivative=np.where(partial,(b-1)/den,np.where(R>=1+b,-1.,0.)).sum(axis=1)
        positive=derivative>0
        lo=np.where(positive,mid,lo)
        hi=np.where(positive,hi,mid)
    R=np.exp((lo+hi)/2)
    overlap=np.maximum(0,np.minimum(np.minimum(1/R[:,None],(1+(1-b)/R[:,None])/2),1))
    with np.errstate(divide='ignore'): value=np.log(overlap).sum(axis=1)
    value=np.where(inside,0.,value)
    if return_radius:return value,R
    return value

def boundary(theta,a,steps=34,max_steps=38):
    theta=np.atleast_2d(theta); N,n=theta.shape
    if a<=2:return np.ones(N)
    lo=np.zeros(N); hi=np.full(N,math.log(a-1))
    # theta first coordinate equals1: M <= 1/(r+1), hence r<=a-1.
    target=-math.log(a)
    for _ in range(steps):
        mid=(lo+hi)/2
        val=max_log_average(np.exp(mid)[:,None]*theta,max_steps)
        ok=val>target
        lo=np.where(ok,mid,lo); hi=np.where(ok,hi,mid)
    return np.exp((lo+hi)/2)

def run_case(n,a,samples,seed,steps=34,max_steps=38):
    rng=np.random.default_rng(seed)
    theta=np.ones((samples,n)); theta[:,1:]=rng.random((samples,n-1))
    R=boundary(theta,a,steps,max_steps); scores=R**n
    mean=float(scores.mean()); se=float(scores.std(ddof=1)/math.sqrt(samples)) if samples>1 else 0
    top=np.argsort(scores)[-3:][::-1]
    return dict(n=n,a=a,samples=samples,seed=seed,proposal='uniform facet',volume_over_2n=mean,SE_volume_over_2n=se,capacity_ratio=a/mean,delta_SE_ratio=a*se/mean**2,max_score=float(scores.max()),top_1percent_fraction=float(np.sort(scores)[-max(1,samples//100):].sum()/scores.sum()),ESS_contribution=float(scores.sum()**2/np.dot(scores,scores)),radius_min=float(R.min()),radius_max=float(R.max()),top_receivers=[dict(theta=theta[i].tolist(),radius=float(R[i]),score=float(scores[i])) for i in top],theoretical_score_upper=max(1,a-1)**n,hoeffding_95_halfwidth=(max(1,a-1)**n-1)*math.sqrt(math.log(40)/(2*samples)))

# Atomic vertex source: each vertex ±1 has mass4^n, W=8^n,H=1.
def vertex_boundary(theta):
    z=np.sort(np.atleast_2d(theta),axis=1);n=z.shape[1]
    radii=2*np.exp2(np.arange(1,n+1)/n)
    with np.errstate(divide='ignore'): candidates=np.minimum(1+radii,(radii-1)/z)
    return np.maximum(3,candidates.max(axis=1))

def vertex_max_log(x):
    b=np.abs(np.atleast_2d(x));n=b.shape[1]
    floor=np.max(np.abs(b-1),axis=1)
    second=np.sort(b+1,axis=1)
    k=np.arange(1,n+1)
    events=np.maximum(second,floor[:,None])
    # All last tie indices occur; intermediate tie batches cannot increase max.
    logs=n*np.log(2/events)+k*math.log(2)
    count=(second<=floor[:,None]).sum(axis=1)
    with np.errstate(divide='ignore'): first=n*np.log(2/floor)+count*math.log(2)
    return np.maximum(first,logs.max(axis=1))

def vertex_case(n,samples,seed,alphas=(1.,),weights=None):
    weights=np.array(weights if weights is not None else np.ones(len(alphas))/len(alphas))
    rng=np.random.default_rng(seed); comps=rng.choice(len(alphas),samples,p=weights)
    theta=np.ones((samples,n));U=rng.random((samples,n-1));U=np.maximum(U,np.nextafter(0.,1.))
    theta[:,1:]=U**(1/np.array(alphas)[comps,None])
    logprod=np.log(theta[:,1:]).sum(axis=1)
    logs=np.array([math.log(w)+(n-1)*math.log(a)+(a-1)*logprod for a,w in zip(alphas,weights)])
    mx=logs.max(axis=0);logdensity=mx+np.log(np.exp(logs-mx).sum(axis=0))
    R=vertex_boundary(theta);score=np.exp(n*np.log(R/4)-logdensity)
    mean=float(score.mean());se=float(score.std(ddof=1)/math.sqrt(samples));top=np.argsort(score)[-3:][::-1]
    baseline=sum(w for a,w in zip(alphas,weights) if a==1)
    bound=(5/4)**n/baseline
    return dict(n=n,samples=samples,seed=seed,proposal_alphas=list(alphas),proposal_weights=weights.tolist(),volume_over_W=mean,SE_volume_over_W=se,capacity_ratio=1/mean,delta_SE_ratio=se/mean**2,score_bound=bound,hoeffding95_halfwidth=bound*math.sqrt(math.log(40)/(2*samples)),core_volume_over_W=(3/4)**n,core_capacity_ratio=(4/3)**n,ESS_contribution=float(score.sum()**2/np.dot(score,score)),top_1percent_fraction=float(np.sort(score)[-max(1,samples//100):].sum()/score.sum()),score_max=float(score.max()),top_receivers=[dict(theta=theta[i].tolist(),radius=float(R[i]),score=float(score[i]),component=int(comps[i]),log_proposal_density=float(logdensity[i])) for i in top])

def vertex_tail_probability(n,r):
    """Positive killed multinomial recursion; no subtraction from1."""
    r=np.asarray(r);d=n-1;M=len(r)
    if d==0:return np.zeros(M)
    j=np.arange(d+1)[:,None];h=np.arange(d+1)[None,:];delta=h-j
    mask=delta>=0
    coef=np.zeros((d+1,d+1))
    for a in range(d+1):
        for b in range(a,d+1):coef[a,b]=math.comb(d-a,b-a)
    with np.errstate(divide='ignore'):logcoef=np.log(coef)
    dp=np.zeros((M,d+1));dp[:,0]=1;kill=np.zeros(M);prev=np.zeros(M)
    for k in range(1,n):
        Rk=2*2**(k/n);t=(Rk-1)/r;p=(t-prev)/(1-prev)
        with np.errstate(divide='ignore',invalid='ignore'):
            trans=np.exp(logcoef[None,:,:]+delta[None,:,:]*np.log(p)[:,None,None]+(d-h)[None,:,:]*np.log1p(-p)[:,None,None])
        trans[:,~mask]=0
        dp=np.einsum('mi,mij->mj',dp,trans,optimize=False)
        eligible=Rk>r-1
        kill+=np.where(eligible,dp[:,k:].sum(axis=1),0)
        dp[eligible,k:]=0
        prev=t
    return kill

def vertex_deterministic(n,order):
    if n==1:return dict(n=n,order=order,volume_over_W=.75,capacity_ratio=4/3)
    cuts=np.unique(np.r_[3.,1+2*np.exp2(np.arange(1,n)/n),5.]);cuts=cuts[(cuts>=3)&(cuts<=5)]
    nodes,weights=np.polynomial.legendre.leggauss(order)
    r=np.concatenate([(l+h)/2+(h-l)/2*nodes for l,h in zip(cuts[:-1],cuts[1:])]); w=np.concatenate([(h-l)/2*weights for l,h in zip(cuts[:-1],cuts[1:])])
    # Bounded batches avoid quadratic memory at higher n.
    prob=np.concatenate([vertex_tail_probability(n,r[i:i+32]) for i in range(0,len(r),32)])
    tail=float(np.dot(w, n*np.exp((n-1)*np.log(r)-n*math.log(4))*prob))
    value=(3/4)**n+tail
    return dict(n=n,order=order,radial_nodes=len(r),volume_over_W=value,capacity_ratio=1/value,tail_integral=tail,min_tail_probability=float(prob.min()),max_tail_probability=float(prob.max()))

def event_max_reference(x):
    b=np.abs(np.asarray(x));
    if b.max()<1:return 0.
    events=sorted(set(float(v) for v in np.r_[np.abs(1-b),1+b] if v>0))
    best=-math.inf
    def value(s):
        p=np.maximum(0,np.minimum(np.minimum(s,(1+(1-b)*s)/2),1))
        return float(np.log(p).sum()) if np.all(p>0) else -math.inf
    def deriv(s):
        vals=np.stack([np.full(len(b),s),(1+(1-b)*s)/2,np.ones(len(b))]);index=vals.argmin(axis=0)
        chosen=vals.min(axis=0)
        if np.any(chosen<=0):return -math.inf
        slope=np.where(index==0,1,np.where(index==1,(1-b)/2,0))
        with np.errstate(over='ignore',divide='ignore'):
            return float((slope/chosen).sum())
    edges=sorted(set([0.]+[1/t for t in events]+[1/(b.max()-1)]))
    for l,h in zip(edges[:-1],edges[1:]):
        mid=(l+h)/2
        if not math.isfinite(value(mid)):continue
        best=max(best,value(l),value(h))
        dl=deriv(np.nextafter(l,h));dh=deriv(np.nextafter(h,l))
        if dl>0>dh:
            low,high=l,h
            for _ in range(64):
                mid=(low+high)/2
                if deriv(mid)>0:low=mid
                else:high=mid
            best=max(best,value((low+high)/2))
    return best

def implementation_guards():
    from fractions import Fraction as F
    from itertools import product
    rows=[]; rng=np.random.default_rng(622001)
    for n in [1,2,3,4,8]:
        for _ in range(5):
            x=rng.uniform(0,4,n);x[0]=rng.uniform(1.001,4)
            actual=float(max_log_average(x,steps=56)[0]);ref=event_max_reference(x)
            rows.append(dict(kind='continuous all-event versus global concavity',n=n,x=x.tolist(),global_logmax=actual,event_logmax=ref,error=abs(actual-ref)))
    for n in [1,2,3,4]:
        for j in range(8):
            x=[F(int(v),8) for v in rng.integers(0,41,n)] if j else [F(0)]*n
            atoms=list(product([-1,1],repeat=n));events=sorted({max(abs(y_i-x_i) for y_i,x_i in zip(y,x)) for y in atoms})
            exact=F(0)
            for R in events:
                if R==0:exact=None;break
                count=sum(max(abs(y_i-x_i) for y_i,x_i in zip(y,x))<=R for y in atoms)
                exact=max(exact,F(4**n*count)/(2*R)**n)
            if exact is None:continue
            compressed=math.exp(float(vertex_max_log(np.array([float(t) for t in x]))[0]))
            error=abs(compressed-float(exact))/max(1,float(exact))
            rows.append(dict(kind='vertex exact Fraction explicit atoms versus compressed arrival',n=n,x=[str(t) for t in x],exact_max=str(exact),compressed_max=compressed,error=error))
    for n in [1,2,4,8,16,32,64]:
        theta=np.r_[1.,rng.random(n-1)]
        R=float(vertex_boundary(theta)[0]);epsilon=1e-8
        lower=float(vertex_max_log((R-epsilon)*theta)[0]);upper=float(vertex_max_log((R+epsilon)*theta)[0])
        assert lower>0 and upper<0
        rows.append(dict(kind='vertex radial boundary actual arrival signs',n=n,theta=theta.tolist(),radius=R,epsilon=epsilon,below_logmax=lower,above_logmax=upper,error=0))
    return rows

def decimal_vertex(theta,precision):
    with localcontext() as ctx:
        ctx.prec=precision;n=len(theta);z=sorted(Decimal.from_float(float(t)) for t in theta);log2=Decimal(2).ln();best=Decimal(3)
        for k,u in enumerate(z,1):
            R=2*(log2*Decimal(k)/n).exp()
            val=min(1+R,(R-1)/u) if u else 1+R
            best=max(best,val)
        score=(best/4)**n
        return best,score

def high_precision_guards(cases):
    rows=[]
    for n in sorted(set(c['n'] for c in cases)):
        tops=sorted(((c,t) for c in cases if c['n']==n for t in c['top_receivers']),key=lambda item:item[1]['score'],reverse=True)[:3]
        for c,t in tops:
            r80,s80=decimal_vertex(t['theta'],80);r120,s120=decimal_vertex(t['theta'],120)
            with localcontext() as ctx:
                ctx.prec=120
                relative=abs(Decimal.from_float(t['radius'])-r120)/r120
                precision=abs(r80-r120)/r120
                scorefloat=(t['radius']/4)**n
                scorerel=abs(Decimal.from_float(scorefloat)-s120)/s120
                angular_log=sum(Decimal.from_float(float(u)).ln() for u in t['theta'][1:])
                density=sum(Decimal(str(w))*(Decimal(str(a)).ln()*(n-1)+(Decimal(str(a))-1)*angular_log).exp() for a,w in zip(c['proposal_alphas'],c['proposal_weights']))
                weighted=s120/density
                weighted_relative=abs(Decimal.from_float(t['score'])-weighted)/weighted
            rows.append(dict(n=n,theta=t['theta'],float_radius=t['radius'],decimal120_radius=str(r120),decimal80_120_relative=str(precision),float_radius_relative=str(relative),float_unweighted_volume_score_relative=str(scorerel),float_complete_importance_score_relative=str(weighted_relative),proposal_alphas=c['proposal_alphas'],proposal_weights=c['proposal_weights'],scope='Decimal precision cross-check of radius and complete proposal score, no outward-rounded interval certificate.'))
    return rows

def branch_bounds(n):
    values=[]
    for k in range(n+1):
        R=2*2**(k/n);small=R-1
        volume=sum(math.comb(n,j)*small**j*2**(n-j) for j in range(k,n+1))/4**n
        values.append(volume)
    return dict(n=n,individual_branch_volumes_over_W=values,union_lower=max(values),union_upper=sum(values),core_volume_over_W=(3/4)**n,scope='Analytic branch inequality evaluated in float, not interval certified.')

def final_main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args();start=time.perf_counter()
    continuum=[run_case(n,a,128,620000+n*100+int(a)) for n in [1,2,4,8,16] for a in [1.5,2,4,16]]
    deterministic=[];cases=[]
    dims=[1,2,4,8,16,32,64]
    for n in dims:
        q=max(8,(n+1)//2)
        for order in [q,2*q]:deterministic.append(vertex_deterministic(n,order))
        samples=1024 if args.pilot else (16384 if n<32 else 65536)
        for seed in [623000+n,624000+n,625000+n]:
            cases.append(vertex_case(n,samples,seed))
            cases.append(vertex_case(n,samples,seed+10000,alphas=(.5,.7,.85,1.),weights=(.2,.3,.25,.25)))
        print('vertex',n,'DP',deterministic[-1]['volume_over_W'],'capacity',deterministic[-1]['capacity_ratio'],flush=True)
    deterministic.extend(vertex_deterministic(3,q) for q in [8,16])
    guards=implementation_guards();high=high_precision_guards(cases)
    with localcontext() as ctx:
        ctx.prec=100;exactn2=(Decimal(29)-12*Decimal(2).sqrt())/16
    low_angle=[]
    for n,N in [(2,256),(2,512),(3,64),(3,128)]:
        if n==2:theta=np.c_[np.ones(N),(np.arange(N)+.5)/N]
        else:
            u=(np.arange(N)+.5)/N;x,y=np.meshgrid(u,u,indexing='ij');theta=np.c_[np.ones(N*N),x.ravel(),y.ravel()]
        value=float(np.mean((vertex_boundary(theta)/4)**n));low_angle.append(dict(n=n,grid_per_free_coordinate=N,facet_nodes=len(theta),volume_over_W=value,capacity_ratio=1/value,scope='Deterministic midpoint angle refinement, no certified error bound.'))
    continuous_refinements=[]
    for a in [4,16]:
        for N in [512,1024]:
            theta=np.c_[np.ones(N),(np.arange(N)+.5)/N]
            radii=boundary(theta,a,steps=42,max_steps=48);v=float(np.mean(radii**2));continuous_refinements.append(dict(n=2,a=a,facet_midpoints=N,volume_over_2n=v,capacity_ratio=a/v))
    data=dict(scope='Necessary global capacity tests for actual positive continuum cube and atomic vertex sources; no general affordable-Hall theorem or restricted upper progress.',normalization=dict(continuous='f=aH1[-1,1]^n,H1,W=a2^n,capacity=a/E[r^n]',vertices='μ=4^nΣverticesδy,H1,W8^n,capacity=1/E[(r/4)^n]',strict_level='Ω={Mμ>H}; boundary null in volume',facet='θ=(1,U2,…,Un); signs/faces reduce by symmetry, Lebesgue radial cone volume.'),continuum_pilot=continuum,continuum_low_dimension_refinements=continuous_refinements,vertex_cases=cases,vertex_deterministic=deterministic,vertex_branch_bounds=[branch_bounds(n) for n in dims],low_dimension_facet_midpoints=low_angle,exact_n2_vertex_volume_over_W=str(exactn2),implementation_guards=guards,high_precision_extreme_guards=high,limitations=['All recorded arithmetic and quadrature is floating or Decimal nearest rounding; no interval certification.','Sample SE and delta-method ratio SE diagnose sampling, not a rigorous confidence interval.','Hoeffding uses the known baseline mixture weight and finite score bound; it is often useless in high dimension.','Angular mixture parameters fixed from analytic mechanism and pilot; independent final seeds; no fitted density or exponent.','Positive DP probabilities avoid cancellation from1−CDF; exact-arithmetic radial integrand polynomial degree≤n−1 means Gauss order ceil(n/2) suffices. Floating coefficients and algebraic cut endpoints remain uncertified.','Continuous cube is one source family; atomic vertex core exponential inflation does not imply its fullhalo has exponential inflation.'],counts=dict(continuum_pilot=20,continuous_low_d_refinements=4,vertex_cases=len(cases),vertex_receiver_samples=sum(c['samples'] for c in cases),deterministic_vertex_rows=len(deterministic),implementation_guards=len(guards),high_precision_extremes=len(high)))
    for n in dims:
        a,b=[r for r in deterministic if r['n']==n];v=b['volume_over_W'];bounds=next(r for r in data['vertex_branch_bounds'] if r['n']==n)
        assert bounds['union_lower']<=v*(1+1e-12) and v<=bounds['union_upper']*(1+1e-12)
    assert max(g['error'] for g in guards)<1e-10
    Path(__file__).with_name('results.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print('runtime_seconds',time.perf_counter()-start,flush=True)
if __name__=='__main__':final_main()
