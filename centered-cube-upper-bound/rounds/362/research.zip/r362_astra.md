# R362 — First-hit terminal matching and thick fresh-shell innovations

**Result and scope.** No new geometric payment for the high-D-count terminal tail is established. Two precise auxiliary statements follow from the existing strict mass gap. They locate the outstanding source correlation issue; they do not increase the old recapture fee or spend original capture-square credit again. The R361 payment for D counts at most ceil(log(n+2)) is unchanged.

## 1. Native-weighted first-hit restriction differs by at most the old recapture allowance

At an actual alive nonrich history h with current receiver v=w_j, put

    A_h=Q_(old v) union Q_(old u) union union_(i<j) Q_(w_i),
    K=exp(sqrt(n)).

The ORIGINAL entrance inequalities m_(w_0)>K m_(old u)>K^2 m_(old v), together with every real subsequent strict mass gap, imply

    pi_v(A_h)<= [m_(old v)+m_(old u)+sum_(i<j)m_(w_i)]/m_v
              <1/(K-1).                                  (1)

This is full f, not volume or a density cap. Let e_h(z) in [0,1] retain any of the actual current shell, low-face and terminal direction-source restrictions, and put

    t_h(z)=e_h(z) bbar_z(v),

where bbar_z is the genuine native missing-rank probability. Equivalently one can use any actual source-disintegrated normal-terminal acceptance 0<=t_h<=bbar_z. Omitting only the last-visit ancestor test, on the same actual preterminal history, gives

    0<=integral pi_v(dz)t_h(z)
          -integral_(z notin A_h) pi_v(dz)t_h(z)
      <=pi_v(A_h)<1/(K-1).                                (2)

The counterfactual last-visit native draw in the omitted-test version is defined by the unchanged kernel; no accepted posterior is renormalized. All earlier history restrictions remain intact.

Let H_j be the actual alive preterminal-history measure, optionally restricted to more than L D edges. Its receiver marginal is at most sigma. Summing (2) gives

    0<=T_relaxed-T_fresh
       <=(1/(K-1)) sum_(j<N)|H_j|
       <=N I(E)/(K-1)<=alpha_rec X_q.                     (3)

Here I is the real initial entrance and alpha_rec=N/(K-1). The middle inequality also follows from total alive mass decreasing from I(E). This is exactly the previously allocated recapture scale, not a new fee. The two masses in (3) are coupled on the same actual preterminal histories. Equation (3) does NOT identify the relaxed version with a newly run unrestricted process.

For a fixed eventual terminal source z, z notin A_h means the terminal receiver is the first visited path receiver in

    E_z={v:z in Q_v},

and z also avoids the old u,v. Thus (2)–(3) apply to the proposed first-hit interpretation with its true terminal source and true bbar_z weight. Their implication is limited but exact: the source-averaged first-hit restriction by itself removes at most the old, exponentially small recapture allowance. A useful first-hit estimate must therefore exploit the dependence of its hitting flux on bbar_z, rather than infer a discount merely from freshness and mass growth.

## 2. Correct canonical first-hit envelope; no new capacity bound

For fixed z let M_o and M_i multiply receiver functions by 1_(E outside E_z) and 1_(E_z), respectively. The full canonical Pbar is substochastic, has sigma Pbar<=sigma, and retains strict mass growth. Define

    K_z=M_o Pbar M_o,
    Gamma_z=I M_o (Id+K_z+...+K_z^(N-1)) Pbar M_i.          (4)

This is a finite first-hit flux, not all occupation in E_z. Actual paths with more than L D edges have positive length. Their terminal histories, all of whose earlier receivers avoid E_z, are positively dominated by the source-labelled word expansion in (4); dropping the old u,v exclusion and other history acceptance only enlarges it. Consequently

    F_(>L,disp)
      <=integral f(z)dz integral Gamma_z(dv) bbar_z(v)/m_v. (5)

One can retain the D count and all marks in that upper envelope; dropping them here makes only the first-hit interface explicit. Formula (5) is not a payment and is not presented as new progress on its own.

For each fixed z, first-hit path mass is at most I(E). That row fact does not imply Gamma_z<=C sigma, nor does it match the known source capacity integral xi_z(dv)bbar_z(v)<=b_*. The missing assertion is an adequate SOURCE-AVERAGED comparison between the z-dependent first-hit receiver flux in (5) and that native xi_z-weighted terminal capacity. The initial core/high-past/clock qualification is attached to w_0 and its original source, not to this eventual z or every later receiver; it cannot be inserted into Gamma_z without an explicit joint-source argument.

## 3. Short auxiliary innovation structure

For one fixed actual receiver history define

    S_j=(Q_(w_j) outside alpha Q_(w_j)) outside A_(h_j),
    c_K=3/4-1/(K-1).

All S_j are pairwise disjoint, since every later one excludes each earlier full cube. Nonrichness and (1) give, whenever c_K>0,

    c_K m_j<=f(S_j)<=m_j.                                 (6)

Thus e_j=1_(S_j)/sqrt(m_j) are orthogonal in L2(f), with squared norms in [c_K,1]. In particular

    integral f |sum_j a_j e_j|^2
       =sum_j |a_j|^2 f(S_j)/m_j,
    sum_j |integral f h e_j|^2<=integral f|h|^2.            (7)

These are full-f same-history statements. Actual normal-terminal sources form positive restrictions of S_j. Their rank/face masks can remove its lower norm bound. For masks r_j(z) in [0,1], the exact masked identity is

    integral f |sum_j a_j r_j e_j|^2
      =sum_j |a_j|^2 [f(S_j)-Delta_j]/m_j,
    Delta_j=integral_(S_j) f(z)(1-r_j(z)^2)dz>=0.          (8)

No bound paying Delta_j is available from these premises: a native continuation is not an already paid stopping event. In addition, innovations from DIFFERENT histories need not be disjoint. Neither (7) nor (8) controls their shared-source aggregation.

The corresponding multiple-core estimate is only

    sum_(i<=j) f(alpha Q_(w_i))
       <(1/4) sum_(i<=j)m_i
       <=[K/(4(K-1))]m_j.                                (9)

Strict mass growth prevents (9) from accumulating one comparable mass contribution per D edge. It gives no k-dependent depletion of the terminal fresh shell. The low-face disjoint-coordinate condition concerns the incoming common source on a D edge; the next full-f source draw has a different face set. No persistence of those coordinate labels is inferred.

Equations (1)–(9) retain the real f, receiver measures and history law. They add no W receipt and no X_q absorption. The precise outstanding issue is the cross-source correlation between initial qualifications, first-hit flux and terminal native rank loss. Work stops here.

## 4. Executed arithmetic diagnostics and reproduction

Two inline Python runs were actually performed. They returned 10,704 elementary fresh-shell/core/orthogonality checks and 37,044 native-weighted first-hit defect checks. Their code is preserved below. The interval fixture checks only the diagonal square identity; it is not a one-octave centered-cube hard-branch realization. No numerical search or counterexample campaign was performed, and these diagnostics are not evidence of a new terminal bound.

```python
from fractions import Fraction as F
checks={'fresh_shell':0,'core_sum':0,'orthogonality':0}
for K in [F(4),F(8),F(16),F(64)]:
  theta=F(1,4); c=1-theta-1/(K-1)
  for j in range(20):
    past=sum((K**(-r) for r in range(1,j+3)),F(0))
    for ic in range(5):
      core=theta*F(ic,4)
      for ip in range(5):
        anc=past*F(ip,4)
        for io in range(5):
          overlap=min(core,anc)*F(io,4)
          fresh=1-core-anc+overlap
          assert fresh>=c>0
          checks['fresh_shell']+=1
    cores=sum((theta*K**(-r) for r in range(j+3)),F(0))
    assert cores<=theta*K/(K-1)
    checks['core_sum']+=1
  # Exact interval-incidence diagnostic for the square identity only.
  # This is not a one-octave centered-cube hard-branch realization.
  intervals=[]
  for j in range(12):
    mass=K**j
    old=K**(j-1)
    intervals.append((max(theta*mass,old),mass,mass))
  for i,(lo,hi,mi) in enumerate(intervals):
    assert c*mi<=hi-lo<=mi
    checks['orthogonality']+=1
    for j,(lj,hj,mj) in enumerate(intervals):
      intersection=max(F(0),min(hi,hj)-max(lo,lj))
      assert intersection==(hi-lo if i==j else 0)
      checks['orthogonality']+=1
print('PASS',checks,'total',sum(checks.values()))
```

```text
PASS {'fresh_shell': 10000, 'core_sum': 80, 'orthogonality': 624} total 10704
```

```python
from fractions import Fraction as F
checks=0
for K in [F(4),F(8),F(16),F(64)]:
  eps=1/(K-1)
  for ia in range(21):
    a=eps*F(ia,20)
    for ix in range(21):
      x=F(ix,20)
      for iy in range(21):
        y=F(iy,20)
        full=a*x+(1-a)*y
        fresh=(1-a)*y
        assert 0<=full-fresh<=a<=eps
        checks+=1
print('PASS',checks,'exact native-weighted first-hit defect inequalities')
```

```text
PASS 37044 exact native-weighted first-hit defect inequalities
```
