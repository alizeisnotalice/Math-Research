# R362 independent audit — entrance slack and initial-target rank profile

Status: FINAL PASS for the original entrance-rank profile, near-initial-top terminal receipt, auxiliary first-hit scope and final accounting. The independent screen below preceded author review; final file-level findings and byte bindings follow. Only this file is modified; no author or Git files changed. The original difficult budget remains unresolved.

## Independent derivation and quantified scope

Freeze the original full-f hard-matched field and all original entrance/source/old-small/physical-clock/history marks. Let xi_y be the original q-weighted capturing receiver measure, D(y)=xi_y(E), and original strict upper xi mass V_y(m_u)=xi_y{m_v>K m_u}. Original U is the rho-tail, not xi-tail. Original a_y(u)<=lambda is used ONLY on that original entrance; it is not a bound for a later arrival amplitude. With Delta=2q_-B, the correct chain is

    eta=(1-2lambda B/(aU))_+
        <=(1-2B/U)_+ <=(1-Delta/V)_+
        <=(1-Delta/(D-s))_+,

where s is the randomized initial full-xi mass rank. Zero denominators use eta=0. The second inequality uses V>=q_-U, i.e. U<=V/q_-; its direction is crucial. Rank support s<=F(m_u)<=F(Km_u) implies V=D-F(Km_u)<=D-s. It is valid for EVERY relevant randomized rank of a positive equal-mass atom, not a deterministic receiver-id tie order. The contribution vanishes unless s<D-Delta.

The clock-integrated ORIGINAL input is bounded as a labelled measure by g_ex(y)eta_y(u)xi_y(du)dy, retaining original marks conditionally. Apply the actual disintegration xi_y(du)R_y(u,ds)=ds H_y(s,du), and draw h uniformly in (D0,Delta) independently of the old physical time. At target rank t=s+h, integration of the initial u/s/h leaves the upper projection

    g_ex(y) Psi_D(t)dy dt H_y(t,dw_0),
    Psi_D(t)=(1/w)int_(D0,Delta)
       1{0<=t-h<D-Delta}(1-Delta/(D-t+h)) dh,
    w=Delta-D0>0.

All target-rank/horizon/capture support and equal-mass target disintegration remain from the same source measure; no conditional re-normalization is inserted. In particular the initial origin constraint t>=h cannot be dropped in an exact formula, though it may be dropped positively for a later upper bound. D and ranks are from the original source y and full field, not a later resampled source or terminal posterior.

## Exact full capacity and near-top cost

Integrating t first, each h<Delta admits the SAME initial range 0<=s<D-Delta when D>Delta, because D-h>D-Delta. Hence the exact reference profile capacity is piecewise

    int Psi_D(t)dt = 0, D<=Delta;
                     D-Delta-Delta log(D/Delta), D>Delta.

At D=0 this is defined as zero without evaluating a logarithm. A bare positive part of D-Delta-Delta log(D/Delta) is NOT a substitute for the D>Delta condition: the expression is positive again for 0<D<Delta. The actual entrance is then zero. This is a capacity of the positive upper projection, not necessarily equality with original accepted traffic.

Write ell_rank=D-t>=0. For 0<=ell_rank<=w, positivity of eta requires h>Delta-ell_rank. Retaining or dropping the additional condition h<=t only decreases/increases respectively. With v=ell_rank+h-Delta,

    Psi_D(t) <=(1/w)int_0^ell_rank v/(Delta+v)dv
              <=ell_rank^2/(2Delta w).

Thus the initial marked near-top branch 0<=D-t<=w has total <=w^2/(6Delta)W_ex. More generally a fixed smaller width a in [0,w] has the sharper a^3/(6Delta w)W_ex (and hence the looser a^2/(6Delta)W_ex). Endpoint inequalities are harmless because the target rank marginal is Lebesgue, including fractional physical receiver mass atoms. No source-density bound, fixed-radius volume fraction, or target receiver atom deletion is used.

Keep the actual initial target rank as a path mark. Any selected normally terminated descendant of an initial near-top input has mass <=that input branch, by genuine subprobability conservation. Therefore on the R361 count>L normal terminal residual, removing this labelled branch costs the same w^2/(6Delta)W_ex ONCE, not per generation. The actual old excess source g_ex accounts for W_ex here; new full-f draws do not turn this particular initial-mark price into a full-W copy.

The valid terminal priority is: first the R361 D-count head, then the remaining near-initial-top terminal paths, then freshly recompute terminal source direction columns on the rest. Existing head and direction fees are not charged twice. Old within-source ratios cannot be inherited after a path-based near-top deletion. Original old y/u/v/time/J/H qualifications remain attached, with all later full-f posteriors unchanged. This narrows a real marked terminal branch but does not prove a positive covered fraction, budget deep initial rank or the high-D suffix, or close soft/time/outer complements. Entrance two and Lambda apply to the new W_ex price; there is no X_q addition.

## Local tool evidence

Python Fraction actually executed 393 exact assertions checking the pointwise rational majorant v/(Delta+v)<=v/Delta over three parameter sets, zero/endpoint cases, and integrated polynomial constants. These are elementary rational checks, not proof of the log identity (derived analytically above), a native cube realization or a parent pipeline count. No author file or full old pipeline was run.

Preliminary waiting status superseded by the author and final integration reviews below.

## Entrance author proof file-level review

Read /tmp/r362_entrance.md in full AFTER the independent screen. PASS, with no mathematical correction requested. The precise finite-target profile (1a)--(1b) includes t>=h and the positive sender range; the relaxed Psi(ell) is only used as an upper measure. C_eta is correctly PIECEWISE zero for D<=Delta, avoiding the bare-positive-part pitfall noted in the screen. The near quadratic profile, integrated cubic A(d), join at ell=width and general deep-rank profile (8) are correct. All original clock factors, terminal atom and original source/old-small/rank marks are retained.

The exact source conditional capacity refers to the new upper reference profile, not equality with the actual accepted old traffic; the file makes this distinction. Every initial source-rank/target label is attached to the same unnormalized marked witness law, and descendants have conditional total mass<=1. Thus the selected >L-D NORMAL terminals can use the initial near-top price once. This does not condition or re-normalize a later posterior, reset rank axes at a later source, or require a claim about target-boundary f mass. The new source fee is original W_ex, with outer multiplier 2Lambda.

The file explicitly applies priority R361 count head, then initial-near-top, then newly computed terminal direction-source set. It does not duplicate count0/head prices or inherit a source direction ratio after pathwise deletion. Its stated remaining bridge is genuinely missing: later D jumps involve different source axes, so high D count does not force small initial ell0. The deep profile tends to1 and cannot be used as a uniformly small entrance cap. Also, the mere bounded initial rank window already has an elementary root-order price from its length; the file correctly claims its new result as a quantitative eta/profile improvement, not a previously unknown general bounded-window mechanism or closure.

Read the embedded numerical script for scope without rerunning it. The 2766 recorded checks are MIXED evidence, not all rigorous rational/log interval certificates. The 324 clock_upper assertions are exact Fraction inequalities. Block intersections and monotone Riemann endpoints are rational, but most profile/primitive comparisons use 65-digit Decimal logarithms and explicit tolerances; these are high-precision diagnostics, not outward interval enclosures. The piecewise-zero source tests are algebraic branches; the D>Delta source-capacity comparison still evaluates its log primitive in Decimal. Counts909 atom_profile,306 closed_profile,303 cubic_bill,909 truncated_profile,15 source_capacity do not turn into exact analytic certificates merely because one side is Fraction. No original high-past/full receiver-du realization or deep-complement budget is tested. Parent notified of this reporting boundary.

Binding at author review:

- /tmp/r362_entrance.md: `da4522549a7655257038f826198c04aeeaa0ed043ad54359c1bb183bf8f0f305`

Interim waiting status superseded by the final integration freeze below. The independent 393 Fraction pointwise/constant checks above are separate from the author's2766 recorded mixed checks.

## Auxiliary first-hit and same-path innovation review

The auxiliary statement was independently checked from its source/hazard definitions before completing the rest of the author note: at the SAME actual preterminal history, retaining any fixed t_h(z)<=bbar_z(v), removing only the last ancestor test changes normal weight by exactly int pi_v(dz)t_h(z)1_Ah. It is nonnegative and <=pi_v(Ah)<1/(K-1). Summing true alive history masses gives at most N I(E)/(K-1)<=alpha_rec X_q, precisely the old recapture scale. This comparison does not couple two newly rerun processes or normalize the accepted posterior. It is not a new fee or an extra discount to subtract from the current ledger.

Read /tmp/r362_astra.md in full and both embedded codes. PASS for the declared auxiliary statements. For fixed prospective terminal source z, the finite canonical first-hit envelope Gamma_z=I M_o sum_j(M_o Pbar M_o)^j Pbar M_i keeps the source-specific outside-prefix and the full normal weight f(z)bbar_z(v)/m_v. A generic first-hit law would also contain I M_i; that term is correctly unnecessary for this >L-D normal tail because it has positive length and its terminal source avoids ALL earlier receiver cubes, including the initial witness. The final note explicitly uses this positive-length qualification. It must not be reused unqualified for zero-length/no-D terminals. Old u/v exclusion and other history acceptance are only positively dropped.

The sourcewise first-hit mass <=I(E) does not give Gamma_z<=C sigma or a source-averaged native normal-capacity comparison. Its common-source/terminal-loss bridge remains unproved. The same-history fresh-shell sets S_j are indeed disjoint, have f-mass between c_K m_j and m_j, and produce the stated diagonal/Bessel identities. Their masked norm deficit uses 1-r_j^2 exactly. The lower norm bound is not retained after arbitrary rank masks, and different histories need not share disjoint innovations. The multiple-inner-core sum is a geometric mass bound, not a depletion growing with D count. These statements produce no W or X_q addition and do not spend old B_H square credit.

Author reports 10704 exact fresh-shell/core/interval diagonal and37044 exact first-hit-defect checks (47748 total). This reviewer read their reproducible embedded source, but did not run them and does not treat them as parent executions or original one-octave/high-past cube realizations. The parent explicitly reports only the 2766 entrance mixed checks in this round.

## Final main/ledger/readme audit and freeze — 2026-10-18

Final conclusion: PASS. Read /tmp/r362_main.md, /tmp/r362_ledger.md and /tmp/r362_readme.md in their final bytes, with the entrance and auxiliary proofs and the extracted entrance code. No mathematical correction remains. Only this audit file was edited; no author/repository/Git files were modified, and no unnecessary existing pipeline was repeated. This review is bounded to the stated R362 and certified hard-matched interfaces, not the full historical reduction or final TeX/ZIP layout.

1. The full field, true receiver du, q/m/J/H, original excess source y and original physical ell including its b atom are frozen. Original a<=lambda and eta are used ONLY on the old entrance. The upper-tail inequalities are in the right direction, and every equal-mass sender rank is handled via the common full atom. Smoothed source/target disintegration preserves the old source and rank marks; the sender t>=h condition remains in the exact Psi_D. Piecewise C_eta(D) is zero for D<=Delta, correct for D>Delta, and never declared an equality with all accepted old traffic. D=0 is defined without a logarithm.

2. Near initial target remainder ell0<=w gives the exact relaxed quadratic profile and cubic cumulative majorant. The adopted price C_init=w^2/(6Delta) multiplies ORIGINAL W_ex, not a later full-f or terminal-source density cap. It is a once-only payment of terminal descendants classified by the retained initial rank, not a per-visit source fee. The deep profile approaches1 and does not supply a uniform small density or root budget. A bounded rank window already has an elementary root price; the claimed new use is the quantitative eta deficit/profile improvement, as the author note explicitly qualifies. No covered fraction or cross-source rank persistence is assumed.

3. The priority is exactly inherited R361 head k<=L, then the >L normal near-initial-top branch, then NEW direction-source columns on the >L deep-initial normal remainder. Consequently final terminal direction ratios are valid without an unproved normalized-ratio inheritance after path deletion. Old no-D/count-head and direction prices are each used once. Later source/rank axes are never identified with the initial source y axis; more than L D jumps do not force ell0 small. The surviving high-D/deep-initial branch is correctly left unpaid.

4. In the high-dimensional hard branch, the inherited head C_terminal=(L+1)b_*/(1-c_col), C_path=2N C_m and C_dir^eff=C_dir remain unchanged. Only C_init is added to the W_ex coefficient. For n<2^32, the existing whole-normal fee remains, F_deep=0, C_dir^eff=0 and C_init=0; the near-rank branch is not charged again. Empty original high-past input has zero relevant effective flow/branch costs. Final appended definitions of b_*,r_p,Lambda_p match R360 and introduce no source cap or new coupled-source hypothesis. C_eta is retained as an optional same-input upper profile, not separately charged or silently substituted for the unbudgeted flow.

5. The new exterior source cost is precisely 2Lambda C_init W_ex. Entrance two and exterior Lambda act on every inherited price. There is no new X_q absorption; the old <889/2304 comparison retains the explicit SAME certified-X condition on historical CZ1/256. The >1415/2304 balance is not a budget for any remaining integral. Conditional future energy/Young costs are stated with correct factors and are not currently inserted. Auxiliary first-hit difference uses the existing alpha_rec budget only, with no repeated recapture fee.

6. All original general soft C_H-S_H, threshold crossing I_H, hard-contract exterior, width/distance/low-pe/extreme-scale and threshold complements, chronological initial/deletion/future-source time atoms, H/source/layer/physical-scale/outer-integration/truncation/limit fees remain independently unpaid. Rank/source terminal accounting is not a chronological time-atom settlement. General B_H and the dimension-uniform weak-type target remain open.

### Computation evidence and reproduction scope

Parent reports actual fresh execution PASS2766 MIXED checks, correctly described in main/readme/ledger: exact Fraction block geometry, endpoint/clock inequalities and rational Riemann endpoints, alongside65-digit Decimal logarithmic comparisons with explicit tolerance. These are not all strict rational inequalities, not outward interval certificates and not proof of a native continuum difficult field. The extracted r362_entrance_check.py matches the unique embedded code up to outer whitespace. The analytic measure and calculus proofs, not the Decimal tolerance tests, establish the general profile. Author auxiliary47748 exact finite arithmetic checks are separately attributed and not merged with the parent's execution. The reviewer's actual393 Fraction pointwise/polynomial checks are separately recorded and not merged with either count. No claims are based on unrun MATLAB, optimizer, general input family realization or asymptotic fitting.

### Final frozen SHA256 bindings

- /tmp/r362_main.md: `b7f8a5e59eb6418f4b3347640d175a19cd22f8d0ea0dc85d441fe68b040a99f4`
- /tmp/r362_ledger.md: `5993727cb5c38834dd7e6287fef7e5743823243c71510dae9c5e0325bef54552`
- /tmp/r362_readme.md: `4927af7c1df6744dad0c5b3cd421269427bb4eca4400ebe3891bc2d992f1904f`
- /tmp/r362_entrance.md: `da4522549a7655257038f826198c04aeeaa0ed043ad54359c1bb183bf8f0f305`
- /tmp/r362_entrance_check.py: `596b66ef622ee454ce91ac0a3c340e4a8f1a5f144a6d34e5233338e0ff88b7f4`
- /tmp/r362_astra.md: `a44e93a1c311a39c050576dd313b84b0c5741c5cf865bdb6707b79826885d4df`

Necessary prior-interface bindings (identity only; no new complete-history audit asserted):

- /tmp/r361_core.md: `8d323e4000ff3e2abe0f7e097de9a10096937ae7b3b423e12f5c8de8abb36bc9`
- /tmp/r361_renewal.md: `73b3cd4461d5e9e94fd30fadbf0d318870061c190a1be9b96b44ed0f7aa67d1e`
- /tmp/r361_ledger.md: `4e928e6855a1f7d4d0ed01fda81baa1c30914b6862cfde621e3731e52625fe6d`
- /tmp/r361_audit_screen.md: `6da3ab54383e6b13fcdf6d0f3ee6c8cdd4dcf8843f44b6f6b00321c2b4d2f064`
- /tmp/r360_migration.md: `7b9698771028ee001e4a6757c14ae9085fbd8115b2914b62f602cacd4f408028`
- /tmp/r360_terminal.md: `2508e306d6cae0b50e9e9b1bf2b9de5ecb07ef1632ea8250a726f1e9f9ce967b`
- /tmp/r360_geometry.md: `6f316f449e90ec229b2ce9e89a43728b3a9e5eb49cf4e9d8b54b9a8a45e2a3ec`
- /tmp/r359_migration.md: `be3c0ab278c6553c004d1ec263b39514cbc80afdddf1cbde5c8531d337cb617f`
- /tmp/r358_smoothing.md: `666c186f1459c53f236f863a2bea5b3c2e3cd9f3e91b7889f4a1e2c66beebc93`

Final freeze complete. No outstanding correction or further experiment is required within this bounded audit.
