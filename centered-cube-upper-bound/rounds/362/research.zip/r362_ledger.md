# 第362轮完整总账：原入口质量秩衰减与高次数终端分拆

本账对应原始 \(B_H\)。继承第360轮完整迁移、全路径高面停止及费用。令 L=ceil(log(n+2))。沿用第361轮先支付D次数0至L的路径；随后仅在次数大于L的实际正常终端中，按初始旧来源的target剩余秩ell0是否≤w分拆，支付近顶端部分，最后在深秩部分重算方向来源列。高维剩余 F_{>L,deep} 仍未付。
设 \(x=\sqrt n,s=1+x,W=\int f,W_{ex}=\int g_{ex},X_q=\int_Eq\le X=\lambda|E|\)，\(\varepsilon=119/3072,\Lambda=128/119,\beta=\varepsilon/16,q_-=3\lambda/4\)。
\[
B_H\le F_{>L,deep}+
[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+8s+C_{dir}^{eff}+C_{path}+C_{terminal}]W
+(D_{top}+C_{hit}+s+C_{init})W_{ex}.
\]
这里
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3x+2e^{-x}}\varepsilon+1+x\right],\quad
D_{top}=s+\log(4/3),\quad C_{hit}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
保留 \(A_n=1+n\log(b/a)\)、\(N=\max(1,\lceil\log[(\lambda/q_-)(b/a)^n]/x\rceil)\)、\(\alpha^n=\min(1,s/(NA_n))\)、\(L_n=\log(n+2)\)，
\[
C_{dir}=N[(1-\alpha)+(n(1-\alpha)+\alpha)\log(b/a)]L_n,
\]
\[
C_{path}=2NC_m,\quad C_m=\Pr\{\operatorname{Bin}(n,1-\alpha)\ge m\}
+n\log(b/a)\Pr\{\operatorname{Bin}(n-1,1-\alpha)\ge m-1\},
\quad m=1+\lceil8L_n\rceil.
\]
这些binomial项来自真实接收体积，不是实际来源独立性。非空原highpast分支上，
\[
\gamma_{eff}=2(\lambda/q_-)e^{-x}<\varepsilon/16,\quad
c_{eff}=(\lambda/q_-)e^{-x}\max(1,A_n/s)<\varepsilon/16,\quad
\alpha_{rec}=N/(e^x-1)<\varepsilon/16,
\]
且 \(C_{dir}\le3\sqrt n L_n^2\)，\(C_{path}\le2\sqrt n\)。原必要条件使入口为空时相应新流与这些有效分支系数置零，不给后续新来源重新授予原资格。

终端费用采用分段定义：n≥2^32 时，C_terminal=(L+1)b_*/(1−c_col)≤(8/5)(L+1)b_*，c_col=1/4+r_p≤3/8，C_dir^eff=C_dir；n<2^32 时，C_terminal=N b_*≤786432√n，C_dir^eff=0，F_{>L,deep}=0。原困难入口为空则新增实际分支费用为零。有限维付款仅限本硬余项。

高维十一项实际正分解及费用：

|新流部分|费用|
|---|---|
|级联删除|β X_q+4sW|
|初始旧clock近端|c_eff X_q|
|初始旧来源inner|s W_ex|
|首次rich或实际inner来源联合停止|4sW|
|首次当前来源高面|N C_m W|
|首次祖先回捕|α_rec X_q|
|首次成功目标高面|N C_m W|
|D续跳次数0至L的正常终端|C_terminal W|
|D次数大于L且初始旧来源剩余秩≤w的正常终端|C_init W_ex|
|D次数大于L且初始剩余秩>w后，重新计算的方向来源删除|C_dir W|
|剩余正常终端|F_{>L,deep}，未付|

本轮不增加接收吸收系数。不逐代再收费正常终止；首次D之后不能重新授予原入口或重复已有来源预算。C+B 的L2预解是估计工具，不能冒充全部相关路径的实际付款。

原始入口与外乘不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
入口2和外乘 \(\Lambda\) 作用于全体新旧费用。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
仅当历史CZ项 \(1/256\) 属于同一认证 \(X\) 账时，合计才有
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
其余 \(1415/2304\) 以上的吸收空间不是任何未付积分的预算。若未来以 \(F_{>L,deep}\le\delta X_q+b_*W/(2\gamma\delta)\) 回代，新增接收系数将是 \(2\Lambda\delta\)，新增来源费是 \(\Lambda b_*W/(\gamma\delta)\)；本轮仍没有证明条件 \(\gamma>0\) 对实际来源平方成立，因此没有插入该项。

独立未付槽：一般软层 \(C_H-S_H\)、越阈 \(I_H\)、硬层合同之外的质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；原初始时间原子、删除跳跃、未来被删来源；H选择、来源及物理尺度分层、外积分、截断和极限。旧物理时钟末端原子完整保留，新秩核正常终止不替代任何历史时间原子。

一般一致弱型上界与整个 \(B_H\) 仍未闭合。

继承第361轮的高维总head费为(L+1)b_*W/(1−c_col)，其中k=0是第360轮已有付款，不叠加旧noD费；第361轮净新增k=1至L的预算为L b_*W/(1−c_col)。原入口及外乘后总head费为2Λ C_terminal W。低维处理不变。共同列容量给每个k同一预算，但对所有k求和仍可能产生路径长度N费用，不能把有限head付款说成一般闭合。

本轮新增 C_init=w²/(6Δ)（n≥2^32），其中w=Δ−D0，Δ=2(1+√n)，D0=1+√n+log(4/3)。n<2^32已由原整支费用支付，故C_init=0；原入口为空同样置零。此费专属原来源g_ex，不是后续终端来源f的密度帽，且W_ex≤W。回代新增来源费2Λ C_init W_ex。初始rank mark在整条真实历史保留，不能用后续source rank替代；初始深秩补集未付。

原入口source capacity现在可保留更强的分段函数C_eta(D)：D≤Δ为0，D>Δ为D−Δ−Δlog(D/Δ)。这是同一原注入的上界，并不另加费用或替换本总账中的未付流；D大时仍可达线性阶。近顶端费先于最终方向筛选，避免删流后借用旧比例。本轮辅助first-hit差估计仅重述已有recapture控制，不收第二次recapture费。

其中b_*=(D0+Δ)/2；r_p=min(1,Λ_p/w)，p=min(n,m−1)，Λ_p=1−α^p+[n−(n−p)α^p]log(b/a)。这些为第360轮已审真实接收容量常数，未另引来源密度帽。
