# R362 — The original late-amplitude gives an entrance-rank deficit

## Result and exact scope

Keep the hard-matched full field and original pre-witness measure of R359 §§1–4. The original source is denoted by y throughout this note. The result concerns that source and the INITIAL witness w0; it does not impose a new condition on subsequent resampled sources or receivers.

Write

    Delta=2(1+sqrt(n)), D0=1+sqrt(n)+log(4/3),
    width=Delta-D0>0, D_y=xi_y(E), g=g_ex<=f.

The original marked late flow, extended by the R358 smoothed rank witness, admits an initial target-rank mark t in [0,D_y]. Set ell0=D_y-t. Its (y,t,w0) marginal is bounded by

    g(y) Psi(ell0) dy dt H_y(t,dw0),                         (1)

The sharper bound keeps the finite-rank endpoint: replace Psi(D_y-t) in (1) by

    Psi_D(t)=1/width integral_(D0)^min(Delta,t)
                             (1-Delta/(D-t+h))_+ dh.         (1a)

Here an integral with upper endpoint below D0 is zero. Thus the sender condition t>=h is retained exactly in (1a), and only positively relaxed in (1). Writing ell=D-t, h0=max(D0,Delta-ell), h1=min(Delta,t), one has Psi_D(t)=0 if h1<=h0, and otherwise

    Psi_D(t)=[h1-h0-Delta log((ell+h1)/(ell+h0))]/width.      (1b)

The resulting source-conditional total entrance capacity is

    integral_0^D Psi_D(t)dt = C_eta(D),
    C_eta(D)=0 for D<=Delta,
    C_eta(D)=D-Delta-Delta log(D/Delta) for D>Delta.          (1c)

Accordingly the retained entrance mass at original source y is at most g(y) C_eta(D_y)dy. This is a genuine deficit from g(y)D_y, but is still of linear dimensional size when D_y is of that size. It is not a root bound for the whole entrance.

In these formulae H_y is the genuine receiver disintegration of xi_y by randomized mass rank, and

    Psi(ell)=1/width integral_(D0)^Delta
                         (1-Delta/(ell+h))_+ dh.             (2)

In particular, for 0<=ell<=width,

    Psi(ell)=[ell-Delta log(1+ell/Delta)]/width
             <=ell^2/(2 Delta width).                       (3)

This is an improvement of the entrance density cap 1 which uses the ORIGINAL eta, not only source-column subinvariance. Keeping the initial rank as a label on the full subsequent history, every terminal subevent has mass on {ell0<=d} bounded by

    G_terminal[ell0<=d]
       <= A(d) W_ex <= d^3/(6 Delta width) W_ex,
          0<=d<=width,                                     (4)
    A(d)=[d^2/2-Delta((Delta+d)log(1+d/Delta)-d)]/width.

The subevent can be normal termination with more than L=ceil(log(n+2)) genuine D continuations. Thus the true high-D branch with ell0<=width costs at most

    width^2/(6 Delta) W_ex = O(sqrt(n)) W_ex.                (5)

There is no new X_q fee. The surviving high-D branch with ell0>width is not estimated here. Formula (5) is a branch receipt, not a proof that it captures a fixed fraction of the remaining traffic. The sharp new quantitative input is (1)–(4); the fact that a bounded initial rank window alone has a root-order price is not claimed as a new general mechanism.

## Proof with the original clock and all mass atoms

Use the exact original quantities from R359:

    U_y(Km_u)=rho_y{m>Km_u}, xi_y=q_u rho_y,
    omega_y(u)=R_u^n integral Omega_y(u,r) ell(dr),
    a_y(u)=q_u omega_y(u)<=lambda,
    eta_y(u)=(1-2lambda B/[a_y(u)U_y(Km_u)])_+,
    B=(1+sqrt(n))/q_-, Delta=2q_-B.

Here the integral defining omega has its original [R_u,b] restriction, physical ell and b atom. Zero-denominator conventions remain those of the original entrance. The other original predicates, including the relative upper tail, its far-time restriction, full J, old v and high-past qualifications, stay in the marked flow. Dropping a positive predicate in this proof is only an upper bound, not a change of the field or of the process.

Let V_y(u)=xi_y{m>Km_u}. Since V_y(u)>=q_-U_y(Km_u),

    eta_y(u)<=(1-2B/U_y(Km_u))_+
             <=(1-Delta/V_y(u))_+.                         (6)

The clock-contracted entrance weight is the actual

    t_y(u)=R_u^n integral eta_y(u) Omega_y(u,r)
                              chi_y(u,r) ell(dr).

The inclusive identity ell([R_u,b])=R_u^(-n) gives t_y(u)<=eta_y(u). No clock is moved to w0. The original source-receiver measure after contracting the clock is g(y)dy t_y(u)xi_y(du).

Randomize rank uniformly within each mass atom of xi_y, in increasing actual mass m. Its lift is xi_y(du)R_y(u,ds), with rank marginal ds on [0,D_y]. Its reverse disintegration is ds H_y(s,du). All upper-tail receivers with mass greater than K m_u lie after the WHOLE sender mass atom. Consequently, for every sender rank s except null endpoints,

    V_y(u)<=D_y-s,
    t_y(u)<=(1-Delta/(D_y-s))_+.                            (7)

The finite D_y follows from the actual centered-cube envelope D_y<=1+n log(b/a); no assumption on the density of f is involved. The rank lift/disintegration is the same measurable one used in the original smoothing construction; atoms are not sorted into privately chosen receiver orders.

Choose h uniformly in (D0,Delta), send s to t=s+h when t<=D_y, and then use H_y(t,dw0). On positive late rows this witness is complete, as established in R359 §2, so its insertion preserves the original marked mass. For bounding the projected measure, the density at t is at most

    1/width integral_(D0)^Delta 1_{h<=t}
                           (1-Delta/(D_y-t+h))_+ dh.

Keeping 1_{h<=t} proves (1a), and integration on its positive interval gives (1b). Dropping only that indicator proves (1)–(2). For (1c), use Fubini in sender rank s. Its weight (1-Delta/(D-s))_+ is positive only for s<D-Delta. Every shift h<=Delta then survives, so the total is exactly integral_0^(D-Delta) [1-Delta/(D-s)]ds when D>Delta, and zero otherwise. The origin/target ranks and shift may be appended as labels even when a receiver lies in a mass atom. The core restriction, old clock-crossing test and all later stopping rules are positive restrictions of this same marked law.

If 0<=ell<=width, the positive part in (2) restricts h to (Delta-ell,Delta). Substitution v=ell+h-Delta gives

    Psi(ell)=1/width integral_0^ell v/(Delta+v) dv.

This proves the exact formula (3), and v/(Delta+v)<=v/Delta proves its upper bound without a numerical approximation. Integrate ell over [0,min(d,D_y)] and use that H_y(t,E)=1. All later terminal outcomes have total conditional probability at most one, even with history-dependent deletions. Their initial labels therefore obey (4), by the tower property for the ORIGINAL unnormalized marked law. No posterior conditional on future survival has been substituted. The displayed formula for A(d) follows by elementary integration; its cubic bound follows directly from (3).

For general ell>=width, the exact majorant, useful for auditing the unpaid portion, is

    Psi(ell)=1-(Delta/width)
                     log[(ell+Delta)/(ell+D0)].              (8)

It tends to 1. Thus (1) does not provide a uniformly small density on the deep-rank entrance complement.

## Exact use in the high-D ledger and the missing bridge

Let F_(>L,raw) be the actual normal-terminal law in R361 before its newly computed direction deletion, and retain its initial y,t labels. There is an exact positive split

    F_(>L,raw)=F_(>L,top-initial)+F_(>L,deep-initial),
    F_(>L,top-initial)<=width^2 W_ex/(6 Delta).               (9)

The disjoint order relative to R361 is explicitly

    F_norm = F_0 + F_(1:L)
                  + F_(>L,top-initial) + F_(>L,deep-initial).

Only the third piece receives the new price (5). Thus neither the old no-D nor the R361 count-head receipt is charged again. This is not a resampling or restarting of qualified late rows. In particular, the initial y may differ from every later sampled source, and neither (6) nor the initial core/time/shell conditions are transferred to a later receiver.

For a ledger retaining terminal directional dispersion, apply the existing direction-source deletion AFTER the split (9), recomputing it on F_(>L,deep-initial). The same one-face bound and C_dir W price remain valid because this is a positive submeasure at every generation. Its direction ratio must not be inherited without recomputation. The R361 count fees and every previously paid stop remain unchanged. Only the new source price (5) is added; after the original entrance factor two and exterior Lambda it is

    2 Lambda width^2 W_ex/(6 Delta).

Alternatively (4) bounds the corresponding positive subevent of an already direction-deleted terminal law, but that restriction alone does not preserve its old source direction ratio on the remainder.

The precise unresolved step is a comparison between the INITIAL source's remaining mass rank ell0 and the later succession of genuine D transitions after full-f source changes. The original availability, far-clock and core conditions do not supply such a comparison in the proofs read here. In particular, D-count at least L+1 does not itself imply ell0<=width: its rank windows are measured on different actual source axes. No bound for F_(>L,deep-initial) is obtained. The row envelope (8) cannot replace this missing cross-source comparison, and paying its full initial rank length would revert to an O(n) source envelope.

## Local arithmetic checks

The script below verifies the exact block-rank domination with mass atoms, the positive-part and clock-weight directions, and both analytic profile formulae. It is an interface check, not a construction of the original high-past cube flow. The proof above establishes the general measure statement.

~~~python
from fractions import Fraction as F
from decimal import Decimal, getcontext
getcontext().prec=65
counts={'atom_profile':0,'closed_profile':0,'cubic_bill':0,'clock_upper':0,'truncated_profile':0,'source_capacity':0}
def ck(ok,k):
    assert ok, k
    counts[k]+=1
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
def profile(l,lo,hi):
    z,d,w=map(dec,(l,hi,hi-lo))
    if l<=hi-lo:return (z-d*(1+z/d).ln())/w
    return 1-d/w*((z+d)/(z+dec(lo))).ln()
def truncated(total,t,lo,hi):
    ell=total-t;l=max(lo,hi-ell);r=min(hi,t)
    if r<=l:return Decimal(0)
    return (dec(r-l)-dec(hi)*(dec((ell+r)/(ell+l))).ln())/dec(hi-lo)
for lo,hi in [(F(3),F(5)),(F(5,2),F(6)),(F(7,3),F(13,3))]:
    width=hi-lo
    for total in [hi*2,hi*3,hi*5]:
        # Unequal mass-atom rank intervals, a fixed sender weight per atom.
        cuts=[F(0),total/7,total*3/7,total*4/7,total]
        atoms=[]
        for l,r in zip(cuts,cuts[1:]):
            upper=total-r
            wt=max(F(0),1-hi/upper) if upper else F(0)
            atoms.append((l,r,wt))
            for j in range(9):
                s=l+(r-l)*j/8
                envelope=max(F(0),1-hi/(total-s)) if s<total else F(0)
                ck(wt<=envelope,'clock_upper')
        for j in range(101):
            t=total*j/100
            density=sum((wt*max(F(0),min(r,t-lo)-max(l,t-hi))/width
                         for l,r,wt in atoms),F(0))
            exact=truncated(total,t,lo,hi)
            ck(dec(density)<=exact+Decimal('1e-58'),'atom_profile')
            ck(0<=exact<=profile(total-t,lo,hi)+Decimal('1e-58'),'truncated_profile')
    for j in range(101):
        l=width*j/100
        val=profile(l,lo,hi)
        ck(-Decimal('1e-58')<=val<=dec(l*l/(2*hi*width))+Decimal('1e-58'),'closed_profile')
        d=dec(l);H=dec(hi);W=dec(width)
        exact=(d*d/2-H*((H+d)*(1+d/H).ln()-d))/W
        ck(-Decimal('1e-56')<=exact<=dec(l**3/(6*hi*width))+Decimal('1e-56'),'cubic_bill')
    # Total source capacity: bracket the sender integral by exact rational
    # monotone Riemann sums, independently of its logarithmic primitive.
    for total in [hi/2,hi,hi*F(3,2),hi*2,hi*5]:
        length=max(F(0),total-hi)
        if not length:
            ck(all(truncated(total,total*j/20,lo,hi)==0 for j in range(21)),'source_capacity')
            continue
        cells=400;step=length/cells
        vals=[1-hi/(total-step*j) for j in range(cells+1)]
        lower=step*sum(vals[1:],F(0));upper=step*sum(vals[:-1],F(0))
        cap=dec(total-hi)-dec(hi)*dec(total/hi).ln()
        ck(dec(lower)<=cap<=dec(upper),'source_capacity')
    # Continuity at the join, using both exact formulae.
    d,w,l=map(dec,(hi,width,lo))
    left=(w-d*(1+w/d).ln())/w
    right=1-d/w*((w+d)/(w+l)).ln()
    ck(abs(left-right)<Decimal('1e-58'),'closed_profile')
print('PASS entrance-rank checks',counts,'total',sum(counts.values()))
~~~


Actual local execution of the final embedded script returned:

~~~text
PASS entrance-rank checks {'atom_profile': 909, 'closed_profile': 306, 'cubic_bill': 303, 'clock_upper': 324, 'truncated_profile': 909, 'source_capacity': 15} total 2766
~~~

The block intersections and monotone source-capacity brackets use exact `Fraction` arithmetic; logarithmic closed profiles use 65-digit `Decimal` arithmetic. This numerical output is validation of the finite formula interfaces, not a substitute for the continuum proof or evidence of closure of the deep-initial high-D complement.
