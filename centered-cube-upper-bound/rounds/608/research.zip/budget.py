"""R608: formula-only nonabsorption certificate, no actual-input/kernel experiment."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,sys,time,resource,hashlib,platform
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
x,y,z,w,h,U,V=sp.symbols('x y z w h U V',nonnegative=True)
d=1+y+z
# U=exp(x)-1>0, V=exp(h*y)-1>0. xi = 256/225*(1+U)*(1+V)*(1+w)*(d+x+h*y)/d.
N=sp.expand(256*(1+U)*(1+V)*(1+w)*(d+x+h*y)-225*d)
positive_form=31*d+256*(d*(U+V+w+U*V+U*w+V*w+U*V*w)+(x+h*y)*(1+U)*(1+V)*(1+w))
assert sp.expand(N-positive_form)==0
poly=sp.Poly(N,U,V,w,x,h,y,z)
assert all(c>0 for c in poly.coeffs()) and poly.coeff_monomial(1)==31
# Exact algebra independently confirms Cstar/C=1+(x+h*y)/(1+y+z).
assert sp.cancel((1+x+(1+h)*y+z)/d-(1+(x+h*y)/d))==0
symbolic={'variables':'x=lnG>0,y=lngamma>0,z=lnr>=0,w=n ln(b/a)>=0,h>0; U=exp(x)-1>0,V=exp(hy)-1>0',
 'xi':'(256/225) exp(x+hy) (1+w) (1+(x+hy)/(1+y+z))',
 'positive_scaled_numerator':'225(1+y+z)(xi-1)=31(1+y+z)+256[(1+y+z)(U+V+w+UV+Uw+Vw+UVw)+(x+hy)(1+U)(1+V)(1+w)]',
 'fully_expanded_polynomial':str(N),'positive_monomials':len(poly.terms()),'all_coefficients_strictly_positive':True,'identity_residual':'0',
 'conclusion':'xi>256/225>1; J>=1 and 0<(1-beta)^2(1-3h)^2<1 imply rho>xi>1. No admissible parameter can make this stated sufficient upper bound absorb.',
 'scope':'Nonabsorption of this specific stated bound; no assertion that an actual kernel attains it, no counterexample to the target inequality or general theorem.'}
def A(v):
 v=Q(v);return arb(v.numerator)/v.denominator
def iv(v):return {'lo_exact':str(v.lower().fmpq()),'hi_exact':str(v.upper().fmpq()),'display':v.str(30)}
def floorq(v):v=Q(str(v));return v.numerator//v.denominator
configs=[
 ('initial',1,Q(3,2),Q(1,16),Q(1,8)),
 ('initial',2,Q(2),Q(1,16),Q(1,8)),
 ('initial',8,Q(16),Q(1,12),Q(1,4)),
 ('boundary_pressure',1,Q(1000001,1000000),Q(1,1000000),Q(1,1000000)),
 ('boundary_pressure',1,Q(1999999,1000000),Q(1,6)-Q(1,1000000),Q(1,8)),
 ('boundary_pressure',2,Q(2),Q(1,16),Q(1,2)-Q(1,1000000)),
 ('boundary_pressure',2,Q(2),Q(1,6)-Q(1,1000000),Q(1,1000000)),
 ('expanded_dimension',16,Q(16),Q(1,16),Q(1,8)),
 ('expanded_dimension',32,Q(256),Q(1,16),Q(1,8)),
 ('expanded_dimension',128,Q(65536),Q(1,16),Q(1,8)),
 ('expanded_dimension',512,Q(2**32),Q(1,16),Q(1,8)),
 ('expanded_dimension',2048,Q(2**64),Q(1,16),Q(1,8))]
rows=[]
for stage,n,G,hh,beta in configs:
 assert 1<G<2**n and 0<hh<Q(1,6) and 0<beta<Q(1,2)
 yy=arb(2).log();xx=A(G).log();C=1+yy;Cs=1+xx+(1+A(hh))*yy;An=1+n*yy;gh=(A(hh)*yy).exp()
 assert A(hh)<arb(2).log()/yy and An>gh
 arg=An.log()/(A(hh)*yy)
 flo,fhi=floorq(arg.lower().fmpq()),floorq(arg.upper().fmpq())
 assert flo==fhi
 J=1+flo
 F=Cs*gh*An/(C*A(G));xi=A(G)**2*A(Q(256,225))*F
 xi_independent=A(Q(256,225))*(Cs/C)*gh*An*A(G)
 assert (xi-xi_independent).contains(0) and xi>1
 rho=xi*J/((1-A(beta))**2*(1-3*A(hh))**2)
 assert rho>1
 rows.append({'stage':stage,'inputs':{'n':n,'G':str(G),'gamma':'2','r':'1','b_over_a':'2','S':'1','h':str(hh),'beta':str(beta)},'bulk_nonempty_scale_necessary_guard':'G<2^n exact Fraction PASS; this is not an actual bulk construction','constraints_exact_pass':True,'An':iv(An),'C':iv(C),'Cstar':iv(Cs),'phase_max_branch':'An>gamma^h certified','phase_floor_argument':iv(arg),'floor_certified':flo,'J':J,'xi':iv(xi),'xi_minus_1':iv(xi-1),'rho':iv(rho),'rho_minus_1':iv(rho-1),'identity_xi_difference_contains_zero':True,'decision':'NO_ABSORPTION_FOR_THIS_BOUND'})
out={'status':'PASS_SYMBOLIC_AND_12_FORMULA_ROWS_NO_ABSORPTION','symbolic':symbolic,'rows':rows,'error_policy':'Fraction exact input and guards, SymPy exact zero identities/positive coefficients, Arb256 outward enclosures for logs/exponentials and formula evaluations. floor certified only when endpoint rational floors agree. No floating sign or floor used.','evidence_boundary':'Formula tests only; no actual source/center input, no Gram kernel, no lower bound on true optimized E, no geometric or general-goal counterexample. P bound contributes an additive W term and cannot alter the already-failed Q absorption coefficient.','versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'BLAS_threads':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r608_budget.json')
output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'positive_monomials':symbolic['positive_monomials'],'rows':[{'stage':r['stage'],'n':r['inputs']['n'],'J':r['J'],'xi':r['xi']['display'],'rho':r['rho']['display']} for r in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
