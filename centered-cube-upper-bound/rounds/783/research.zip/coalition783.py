"""All geometry and square budgets are exact Fractions. Arb checks the final square roots."""
from fractions import Fraction as F
from itertools import product
from math import comb, factorial
import json
import sys
from flint import arb, ctx, __version__ as flint_version
from ranks783 import mu1

ctx.prec = 256
def ball(q):
    return arb(q.numerator) / arb(q.denominator)
def add(xs):
    return sum(xs, F(0))
def block_tree(keys):
    nodes = []
    def split(seq, depth):
        if len(seq) == 1:
            return depth
        k = len(seq) // 2
        left, right = seq[:k], seq[k:]
        nodes.append((set(left), set(right)))
        return max(split(left, depth + 1), split(right, depth + 1))
    return nodes, split(list(keys), 0)
def exact(n, eta, cut, pieces, fixture="standard"):
    radii = [F(x,8) for x in (8,9,10,11,12,13,14,15,15)]
    centers = [F(x,8) for x in (-12,9,-7,11,-10,7,-14,10,4)]
    if fixture in ("separated_centers","reflection_centers"):
        radii = [F(x,16) for x in (16,22,22,23,30)]
        first_axis = (0,-44,44,-45,59) if fixture == "separated_centers" else (0,-42,44,-44,60)
        centers = [F(x,32) for x in first_axis]
    ids = range(len(radii))
    m = [(2*r)**n for r in radii]
    sq = [(2*r)**(n//2) for r in radii]
    assert all(a*a == b for a,b in zip(sq,m))
    ends = [(c-r,c+r) for c,r in zip(centers,radii)]
    assert all(abs(centers[i]-centers[j]) > (radii[i]+radii[j])/(32*n)
               for i in ids for j in ids if i<j)
    reflection = all((16*c).denominator==1 and abs(c)+r<=8 for c,r in zip(centers,radii))
    if reflection:
        # At each possible change of either reflected density examine its value via the two affine endpoints.
        for c,r in zip(centers,radii):
            test = {F(0),r,*[F(j,16) for j in range(1,int(16*r)+1)]}
            assert all(mu1((c-t,c+t))==2*t for t in test)
        assert all(mu1((-r,r))==2*r for r in radii)
    I = [z/(32*n)**n for z in m]
    a = [z/t for z,t in zip(I,m)]
    bins = [(int(t.numerator).bit_length() - int(t.denominator).bit_length()) for t in m]
    for i in ids:
        if F(2)**bins[i] > m[i]:
            bins[i] -= 1
        assert F(2)**bins[i] <= m[i] < F(2)**(bins[i]+1)
    keys = range(min(bins),max(bins)+1)
    nodes, depth = block_tree(keys)
    partition = [F(-4)+F(8*k,pieces) for k in range(pieces+1)]
    xcuts = sorted(set(partition + [t for p in ends for t in p]))
    rcuts = sorted({F(0),*radii})
    cells = []
    for lo,hi in zip(xcuts,xcuts[1:]):
        p = sum(edge <= (lo+hi)/2 for edge in partition)-1
        for r0,r1 in zip(rcuts,rcuts[1:]):
            labels = tuple(i for i in ids if ends[i][0]<=lo and hi<=ends[i][1] and r1<=radii[i])
            if not labels:
                continue
            mass = mu1((lo,hi))*(mu1((-r1,r1))**(n-1)-mu1((-r0,r0))**(n-1))
            cells.append((p,mass,labels))
    both = {(i,j):add(w for _,w,labels in cells if i in labels and j in labels)
            for i,j in product(ids,repeat=2)}
    assert [both[i,i] for i in ids] == m
    good = {(i,j):i!=j and bins[i]!=bins[j] and 0<both[i,j]<=eta*min(m[i],m[j])
            for i,j in product(ids,repeat=2)}
    K = {(i,j):both[i,j]/(m[i]*m[j]) if good[i,j] else F(0)
         for i,j in product(ids,repeat=2)}
    d = [add(K[i,j]*I[j] for j in ids) for i in ids]
    down = [add(K[i,j]*I[j] for j in ids if m[j]<m[i]) for i in ids]
    pexit = [c/b if b else F(0) for b,c in zip(d,down)]
    peak = add(I[i]*down[i]*pexit[i] for i in ids)
    Z = add(w*add(a[i] for i in labels)**2 for _,w,labels in cells)
    assert peak > 0
    for j,v in product(ids,repeat=2):
        if good[j,v] and m[j]<m[v]:
            assert sum(bins[j] in B and bins[v] in up for B,up in nodes)==1
    zsum = softsum = actual = hard_all = F(0)
    diagonal = [F(0) for i in ids]
    manual_pairs = F(0)
    touched = [len({p for p,w,labels in cells if w and i in labels}) for i in ids]
    factors = [F(0), F(0)]
    rhs_left = arb(0)
    selected = active_groups = 0
    theta = eta/F(2)**cut
    close = {(i,j):max(m[i],m[j])<=F(2)**(2*cut)*min(m[i],m[j])
             for i,j in product(ids,repeat=2)}
    near_global = add(w*add(a[i]*a[j] for i,j in product(labels,repeat=2) if close[i,j])
                      for _,w,labels in cells)
    close_counted = F(0)
    for B,up in nodes:
        mids = [i for i in ids if bins[i] in up]
        for P in range(pieces):
            M = {i:F(0) for i in mids}
            legal = M.copy()
            arm_by_small = {i:{} for i in mids}
            zbp = F(0)
            local = []
            for cell,w,labels in cells:
                if cell != P:
                    continue
                small = [i for i in labels if bins[i] in B]
                hb = add(a[i] for i in small)
                if not hb:
                    continue
                h = add(a[i] for i in labels)
                zbp += w*h*hb
                mids_y = [i for i in mids if i in labels]
                local.append((w,hb/h,mids_y))
                for i in mids_y:
                    M[i] += w*hb
                    legal[i] += w*add(a[j] for j in small if good[i,j])
                    for j in small:
                        if good[i,j]:
                            arm_by_small[i][j] = arm_by_small[i].get(j,F(0))+w*a[j]
            orig = add(a[i]*pexit[i]*legal[i] for i in mids)
            actual += orig
            for i in mids:
                if not d[i]:
                    continue
                assert add(arm_by_small[i].values())==legal[i]
                diagonal[i] += I[i]/d[i]*(legal[i]/m[i])**2
                manual_pairs += I[i]/(d[i]*m[i]**2)*add(x*y for x,y in
                    product(arm_by_small[i].values(),repeat=2))
            zsum += zbp
            if not zbp:
                continue
            active_groups += bool(orig)
            picked = [i for i in mids if M[i]**2>theta*m[i]*zbp]
            selected += sum(legal[i]*pexit[i]>0 for i in picked)
            mu_total = add(a[i]*pexit[i]*M[i] for i in picked)
            t = add(pexit[i]*I[i]/sq[i] for i in picked)
            e = [F(0),F(0)]
            for w,factor,ys in local:
                close_counted += w*factor*add(a[i]*a[j] for i,j in product(ys,repeat=2) if close[i,j])
                for i,j in product([i for i in ys if i in picked],repeat=2):
                    high = both[i,j]>eta*min(m[i],m[j])
                    hard = not high and not close[i,j]
                    e[int(hard)] += w*factor*a[i]*a[j]*pexit[i]*pexit[j]
            assert mu_total**2 <= zbp*sum(e)
            assert e[1] <= theta*t*t
            softsum += e[0]
            hard_all += e[1]
            rhs_left += add_arb(ball(a[i]*pexit[i]*legal[i])*
                              (1-(ball(theta*m[i]*zbp)).sqrt()/ball(M[i])) for i in picked)
            factors[0] += int(bool(e[0]))
            factors[1] += int(bool(e[1]))
    assert actual==peak and zsum<=depth*Z and close_counted<=near_global
    diag = add(diagonal)
    assert manual_pairs == diag and 0 < diag <= peak
    weights = [I[i]*down[i]*pexit[i] for i in ids]
    assert all(weights[i] <= depth*touched[i]*diagonal[i] for i in ids)
    assert peak**2 <= depth*diag*add(weights[i]*touched[i] for i in ids)
    bound = ball(zsum*softsum).sqrt()
    assert rhs_left<=bound or (bound-rhs_left).contains(0)
    return {"fixture":fixture,"dimension":n,"eta":str(eta),"s_over_log2":2*cut,"source_partition_count":pieces,
            "physical_source_cells":len(cells),"depth":depth,"nonempty_peak_groups":active_groups,
            "selected_true_middle_group_pairs":selected,"true_peak":str(peak),
            "diagonal_over_original":str(diag/peak),"reflection_all_subradii":reflection,
            "last_two_parent_overlap_relative_to_smaller":str(both[len(radii)-2,len(radii)-1]/min(m[-2:])),
            "last_two_volume_ratio":str(max(m[-2:])/min(m[-2:])),
            "positive_far_hard_energy":hard_all>0,"selected_group_square_counts":list(map(int,factors)),
            "positive_part_over_peak_arb":str(rhs_left/ball(peak)),
            "bound_over_peak_arb":str(bound/ball(peak))}
def add_arb(values):
    return sum(values, arb(0))
def geometry():
    result=[]
    for n in (2,8,32,128,256):
        d=F(1,16)
        ratio=add(F(comb(n,j),factorial(j))*(2*d)**j for j in range(n+1))
        estimate=(2*ball(2*n*d).sqrt()).exp()
        assert ball(ratio) < estimate
        result.append({"n":n,"normalized_radius":"1/16","exact_polynomial_arb":str(ball(ratio)),
                       "envelope_arb":str(estimate)})
    return result
def profile():
    rows=[]
    for n in (256,1024,4096,2**16,2**24,2**40,2**80):
        an=arb(n)
        ell=arb(n+2).log()
        L=an.sqrt()*ell**3
        r_int=(an.sqrt()*ell**2).ceil().unique_fmpz()
        assert r_int is not None
        r=arb(r_int)
        k_raw=(3*an/(74*an.log())).sqrt()-20
        k_integer=(k_raw+arb(1)/2).floor().unique_fmpz()
        assert k_integer is not None
        k=max(48,int(k_integer))
        charge=(L/2+r/256)/(arb(k+20).log())
        floor=charge.floor().unique_fmpz()
        assert floor is not None and arb(int(floor))<charge<arb(int(floor)+1)
        rows.append({"n":n,"K":k,"log_volume_window_L_inside_octave":L<an*arb(2).log(),
                     "floor_of_log_threshold_over_log_K_plus_20":int(floor)})
    return rows
if __name__ == "__main__":
    cases=[(2,F(3,4),0,1), (4,F(1,2),0,1), (4,F(1,2),1,4),
           (8,F(3,4),1,2),(8,F(1,2),2,8),(16,F(1,2),3,12),
           (4,F(1,2),3,1),(6,F(1,40),1,1,"separated_centers"),
           (6,F(1,40),1,2,"separated_centers"),(6,F(1,32),1,2,"separated_centers"),
           (6,F(1,48),1,1,"reflection_centers"),(6,F(1,48),1,2,"reflection_centers")]
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint_version,"arb_bits":ctx.prec,
                      "models":[exact(*args) for args in cases],"l1_envelopes":geometry(),
                      "wide_window_scalar":profile()},indent=2,sort_keys=True))
