#!/usr/bin/env python3
"""R783 exact ranked two-peak joint budget with a true shared left price grid."""

from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(items):
    return sum(items,F(0))


def prod(items):
    r=F(1)
    for t in items:
        r*=t
    return r


def width(a):
    return max(F(0),a[1]-a[0])


def section(*ranges):
    return max(i[0] for i in ranges),min(i[1] for i in ranges)


def meet(*boxes):
    return tuple(section(*axis) for axis in zip(*boxes))


def contains(p,q):
    return all(a<=x<=y<=b for (a,b),(x,y) in zip(p,q))


def cube(c,r):
    return tuple((x-r,x+r) for x in c)


def volume(q):
    return prod(map(width,q))


def mu1(i):
    lo,hi=section(i,(F(-8),F(8)))
    period=F(1,8)

    def primitive(t):
        k=t//period
        q=t-k*period
        return k*period+q/2+max(F(0),q-period/2)

    return primitive(hi)-primitive(lo) if hi>lo else F(0)


def mu(q):
    return prod(map(mu1,q))


def bin_left(d):
    b=1
    while 2*b<=d:
        b*=2
    while d<b:
        b=F(b,2)
    return b


def certify(n):
    a=32*n
    h=1+F(1,a)
    radii=tuple(map(F,("1","9/8","9/8","5/4","11/8","3/2","13/8","7/4","15/8")))
    first=tuple(map(F,("0","-1/2","1/2","-1","-9/8","-5/4","11/8","3/2","13/8")))
    centers=[(t,)+(F(0),)*(n-1) for t in first]
    A=[cube(c,r) for c,r in zip(centers,radii)]
    E=[cube(c,r/a) for c,r in zip(centers,radii)]
    assert all(1<=r<2 for r in radii)
    assert all(contains(p,e) for p,e in zip(A,E))
    assert all(not volume(meet(e,f)) for i,e in enumerate(E) for f in E[:i])
    I=list(map(volume,E))
    m=list(map(mu,A))
    assert m==list(map(volume,A))
    ks=range(len(A))
    mids=tuple(range(3,len(A)))
    u,exit_pool=0,(0,1,2)
    Y=cube((F(0),)*n,F(1,8))
    assert all(contains(p,Y) for p in A)
    s={(i,j):mu(meet(A[i],A[j])) for i,j in product(ks,repeat=2)}
    K={(i,j):v/(m[i]*m[j]) if i!=j else F(0) for (i,j),v in s.items()}
    d={i:ss(K[i,j]*I[j] for j in ks) for i in mids}
    p={i:ss(K[i,j]*I[j] for j in exit_pool)/d[i] for i in mids}
    assert all(0<v<1 for v in p.values())
    assert all(m[u]<m[i] and K[u,i]>0 for i in mids)
    incoming=I[u]/m[u]
    H=ss(I[i]/m[i] for i in ks)
    h0={i:I[i]/m[i] for i in mids}
    f={i:h0[i]*p[i] for i in mids}
    T=ss(f.values())
    pi={i:f[i]/T for i in mids}

    z_slabs=[((lo,hi),)+((F(-8),F(8)),)*(n-1) for lo,hi in (
        (F(-8),F(-1,8)),(F(-1,8),F(1,8)),(F(1,8),F(8)))]
    old_right={}
    for i in mids:
        legs=[]
        for g in exit_pool:
            assert m[g]<m[i]
            old=I[u]*I[i]*K[u,i]*I[g]*K[i,g]/d[i]
            for j,slab in enumerate(z_slabs):
                right_price=mu(meet(A[i],A[g],slab))/s[i,g]
                if right_price:
                    left_mark=mu(Y)/s[u,i]
                    normalized=old*left_mark*right_price/(incoming*mu(Y))
                    legs.append((g,j,normalized))
        assert ss(q for _,_,q in legs)==f[i]
        old_right[i]=legs

    intervals={}
    tail=F(0)
    for i in mids:
        intervals[i]=tail,tail+pi[i]
        tail+=pi[i]
    assert tail==1
    rank_cut=F(3,4)
    U=min(m[i] for i in mids if intervals[i][1]>=rank_cut)
    above=[i for i in mids if m[i]>U]
    assert above and all(intervals[i][0]>rank_cut for i in above)
    full_tail=ss(pi[i] for i in above)
    assert 0<full_tail<F(1,4)
    old_above=incoming*mu(Y)*ss(w for i in above for _,_,w in old_right[i])
    assert old_above==incoming*mu(Y)*T*full_tail>0

    eta=F(1,4)
    selected=[]
    for label,left_rank,right_rank in [
            ("outer_quartiles",(F(0),F(1,4)),(F(3,4),F(1))),
            ("middle_pressure",(F(0),F(1,4)),(F(1,2),F(3,4)))]:
        low={i:width(section(r,left_rank))/pi[i] for i,r in intervals.items()}
        high={i:width(section(r,right_rank))/pi[i] for i,r in intervals.items()}
        candidate={(i,j):low[i]*high[j] for i,j in product(mids,repeat=2)
                   if low[i] and high[j]}
        assert candidate and all(i!=j and m[i]<m[j] for i,j in candidate)
        assert ss(pi[i]*v for i,v in low.items())==width(left_rank)
        assert ss(pi[i]*v for i,v in high.items())==width(right_rank)
        overlap_ratio={pair:s[pair]/min(m[pair[0]],m[pair[1]]) for pair in candidate}
        hard={pair for pair,ratio in overlap_ratio.items() if ratio<=eta}
        if label=="outer_quartiles":
            assert hard==set(candidate) and max(overlap_ratio.values())==F(1,5)
        else:
            assert 0<len(hard)<len(candidate)
        hard_under_U={pair for pair in hard if m[pair[0]]<=U and m[pair[1]]<=U}
        hard_above_U=hard-hard_under_U

        by_sum={key:F(0) for key in ("all","hard","hard_under_U","hard_above_U","hard_different_right_slab")}
        by_path=dict.fromkeys(by_sum,F(0))
        for (i,j),w in candidate.items():
            mass=f[i]*f[j]*w
            by_sum["all"]+=mass
            if (i,j) in hard:
                by_sum["hard"]+=mass
                by_sum["hard_under_U" if (i,j) in hard_under_U else "hard_above_U"]+=mass
                individual_slabs=[ss(m0 for _,z,m0 in old_right[v] if z==k)
                                  for v,k in product((i,j),range(3))]
                by_sum["hard_different_right_slab"]+=w*(f[i]*f[j]-
                    ss(individual_slabs[k]*individual_slabs[3+k] for k in range(3)))
            for (_,x,first_mass),(_,z,second_mass) in product(old_right[i],old_right[j]):
                term=first_mass*second_mass*w
                by_path["all"]+=term
                if (i,j) in hard:
                    by_path["hard"]+=term
                    by_path["hard_under_U" if (i,j) in hard_under_U else "hard_above_U"]+=term
                    if x!=z:
                        by_path["hard_different_right_slab"]+=term
        assert by_sum==by_path
        assert by_sum["all"]==T**2*width(left_rank)*width(right_rank)
        assert 0<by_sum["hard_different_right_slab"]<=by_sum["hard"]
        if label=="outer_quartiles":
            assert 0<by_sum["hard_above_U"]<by_sum["hard"]

        volumes={i:bin_left(m[i]) for i in mids}
        assert all(volumes[i]<=m[i]<2*volumes[i] for i in mids)
        for i,j in candidate:
            assert volumes[i]<=volumes[j] and m[j]/m[i]>F(volumes[j],2*volumes[i])
        min_step=min(F(volumes[j],volumes[i]) for i,j in candidate)
        if n==2 and label=="outer_quartiles":
            assert min_step==2
        # Localize the same first left mark by an actual price grid.
        grids={}
        for bins in (1,2,4):
            step=F(1,4*bins)
            pieces=[(F(-1,8)+k*step,F(-1,8)+(k+1)*step) for k in range(bins)]
            cells=list(product(pieces,repeat=n))
            assert ss(map(mu,cells))==mu(Y)
            outer=outer_at_U=outer_with_rank_fractions=F(0)
            whole_parent_repeated=F(0)
            for C in cells:
                center=tuple((l+r)/2 for l,r in C)
                lc={i:volume(meet(E[i],cube(center,h*radii[i]+step/2)))/m[i] for i in mids}
                assert all(lc[i]==I[i]/m[i] for i in mids)
                for i,j in hard:
                    physical=mu(meet(C,A[i],A[j]))
                    assert physical==mu(C)>eta*mu(C)  # hard globally, complete overlap on the first price cell.
                    bound=lc[i]*lc[j]*physical
                    outer+=bound
                    outer_with_rank_fractions+=candidate[i,j]*bound
                    if (i,j) in hard_under_U:
                        outer_at_U+=bound
                    whole_parent_repeated+=lc[i]*lc[j]*s[i,j]
            pair_first=ss(h0[i]*h0[j]*mu(meet(Y,A[i],A[j])) for i,j in hard)
            assert outer==pair_first
            assert incoming*mu(Y)*by_sum["hard"]/H<=outer_with_rank_fractions<=outer
            assert incoming*mu(Y)*by_sum["hard_under_U"]/H<=outer_at_U
            assert ss(incoming*mu(C)*by_path["hard"]/H for C in cells)==incoming*mu(Y)*by_sum["hard"]/H
            base=(1 if bins>1 else 0)
            focus=tuple(pieces[base] for _ in range(n))
            neighbors=[C for C in cells if all(max(lo,a0)<=min(hi,b0)
                        for (lo,hi),(a0,b0) in zip(C,focus))]
            grids[bins]={"left_price_grid_cells":len(cells),"correct_localized_geometry_upper":outer,
                         "geometry_upper_both_m_at_most_U":outer_at_U,
                         "geometry_upper_with_actual_fractional_rank_cuts":outer_with_rank_fractions,
                         "repeated_unlocalized_parent_cost":whole_parent_repeated,
                         "one_fine_cell_mu":mu(focus),"neighbor_touching_cell_count":len(neighbors),
                         "true_neighbor_cell_union_mu":ss(map(mu,neighbors))}
        selected.append({"name":label,"left_rank":left_rank,"right_rank":right_rank,
                         "physical_middle_labels_in_low":sorted({i for i,j in candidate}),
                         "physical_middle_labels_in_high":sorted({j for i,j in candidate}),
                         "unnormalized_T2_pair_conditional_at_a":by_sum,
                         "same_left_price_integrals_times_lambda_over_H":
                            {k:incoming*mu(Y)*w/H for k,w in by_sum.items()},
                         "all_ordered_different_middle_pairs":len(candidate),"hard_pairs":len(hard),
                         "hard_both_at_m_at_most_U_pairs":len(hard_under_U),
                         "minimum_m_high_over_m_low":min(m[j]/m[i] for i,j in candidate),
                         "minimum_dyadic_left_bucket_ratio":min_step,"left_price_grids":grids})
    return {"n":n,"physical_radius_octave":"[1,2)","actual_radius":radii,"parent_centers":centers,
            "actual_owner_boxes":E,"original_m_equals_Lebesgue":m,"original_I":I,
            "true_d":d,"kind":"actual same-u left price and original two independent right price marks",
            "same_Y":Y,"mu_Y":mu(Y),"eta_hard_parent_overlap":eta,
            "preordered_prior":pi,"prior_absolute_volume_bucket_left":{i:bin_left(m[i]) for i in mids},
            "T":T,"H":H,"quantile_3_over_4":{"U":U,"positive_old_middle_above_U":above,
                "actual_true_m_above_U":{i:m[i] for i in above},
                "actual_prior_strictly_above":full_tail,"actual_unconditional_Q0_above_U":old_above},
            "joint_and_geometry":selected,
            "scope":"finite actual real geometry, same physical radius octave and a fixed low arm pool; no upstream high-dimensional hard gates"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B ranks783.py",
                      "source":"product period 1/8 of densities 1/2 then 3/2 in each coordinate, cut to [-8,8]^n",
                      "dimensions":[certify(n) for n in (1,2)]},
                     indent=2,sort_keys=True,default=str))
