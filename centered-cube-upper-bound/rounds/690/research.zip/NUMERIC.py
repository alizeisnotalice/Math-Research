#!/usr/bin/env python3
"""R690 actual all-source filter scalar optimization; no historical input generation."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import json,hashlib,sys,time,platform
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;tick=time.time();ctx.prec=384

def run(power,stage):
 n=2**power;root=isqrt(n);assert root*root==n
 tau=16384*root;c0=1+arb(1)/(32*n)
 # Exact tau/8 is a power of2, supplying an independent log identity.
 L=arb(tau//8).log();assert L.overlaps((11+power//2)*arb(2).log())
 y=L/n;den=y.expm1();Rcrit=c0/den;ratio=Rcrit/root
 logfee_root=arb(8).log()+n*(1+c0/root).log()-arb(tau).log()
 logfee_old=arb(8).log()+n*(1+c0/n).log()-arb(tau).log()
 logfee_critical=arb(8).log()+n*(1+c0/Rcrit).log()-arb(tau).log()
 root_lower=root-arb(1)/2-L
 assert root_lower>0 and logfee_root>root_lower
 assert logfee_root>0 and ratio>1 and logfee_old<0 and logfee_critical.contains(0)
 oldfee=logfee_old.exp();leading=c0*n/L;asymratio=Rcrit/leading
 assert asymratio<1 and asymratio>(-y).exp()
 return {'stage':stage,'n':'2^'+str(power),'n_exact':str(n),'sqrt_n_exact':str(root),'tau_exact':str(tau),'c0_upper_exact':str(1+F(1,32*n)),'log_tau_over8':str(L),'small_expm1_argument':str(y),'Rcrit':str(Rcrit),'Rcrit_over_sqrt_n':str(ratio),'Rcrit_minus_sqrt_n':str(Rcrit-root),'R_sqrt_n_log_fee':str(logfee_root),'R_sqrt_n_log_fee_lower_for_any_c0_ge1':str(root_lower),'root_fee_lower_positive_independently_of_worst_c0':True,'R_sqrt_n_fee_le1':False,'R_n_log_fee':str(logfee_old),'R_n_fee':str(oldfee),'R_n_fee_le1':True,'critical_log_fee_contains_zero':str(logfee_critical),'leading_asymptotic_c0_n_over_log_tau_over8':str(leading),'Rcrit_over_leading_asymptotic':str(asymratio),'asymptotic_sandwich_exp_minus_y_to1_passed':True}
rows=[]
for stage,powers in ((1,(8,16)),(2,(20,32)),(3,(40,64,128))):
 for power in powers:rows.append(run(power,stage))
 print('stage',stage,'completed',len(powers),'dimensions',flush=True)
# Targeted previous-round availability inspection was read-only; no old scripts are executed.
# Frozen provenance hashes from the earlier actual read-only inspection.
# Replays do not access these historical absolute paths or claim a fresh read.
references={'/Volumes/data/CodexTemp/centered-cube-r684-20261116/A1.md': '1d0ae6574b3c03418a7e4e1b38b35bf642ef3f0d4902f491e27a004b6492e5b5', '/Volumes/data/CodexTemp/centered-cube-r684-20261116/S3.md': '810dd9ee75ccb658245fcf7143ab545bb3de996f1e4a1a6742cef57839cf7e6f', '/Volumes/data/CodexTemp/centered-cube-r684-20261116/NUMERIC.py': 'df41cbe1c29c399561ddc9f2d98b47eb91c97dc4b2dc5eba4e02bd2411206907', '/Volumes/data/CodexTemp/centered-cube-r684-20261116/verify.py': '8b2c5fe25fb0b72543b662f809dc82f2c171bf211526f5bf78130a743f33dfa5', '/Volumes/data/CodexTemp/centered-cube-r688-20261116/NUMERIC.py': 'f203023f0ac8a1141c33db0186cbe87e5aa4c0af84e262efacd6fe24da72a4cd'}
out={'scope':'Scalar optimization of the independently proved actual all-source remaining-receiver dilation filter fee8(1+c0/R)^n U/tau. This is a threshold for this sufficient fee bound, not a necessary geometric radius scale or a counterexample. No original history generator, toy LP, owner family or broad scan is run.','python':sys.version,'platform':platform.platform(),'python_flint_version':flint.__version__,'precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'formula':{'tau':'16384sqrt(n)','c0_worst':'1+1/(32n), actual larger a decreases c0','fee_coefficient_of_U':'F_n(R)=8(1+c0/R)^n/tau','Rcrit':'c0/expm1(log(tau/8)/n)','equivalence':'F_n(R)<=1 iff R>=Rcrit, since tau/8>1 and F_n decreases in R','leading_asymptotic':'Rcrit~c0*n/log(tau/8), log(tau/8)=log2048+(1/2)logn','relative_sandwich':'exp(-y)<Rcrit/[c0*n/log(tau/8)]<1, y=log(tau/8)/n>0','root_scale_asymptotic':'Rcrit/sqrt(n)~sqrt(n)/[log2048+(1/2)logn] -> infinity','interpretation':'Allowing orderU rather thanU/tau compresses the sufficient R threshold from n to aboutn/logn, but the specified finite checks do not permit R=sqrt(n) with fee<=U.'},'checks':rows,'history_interface_inspection':{'executed':'Frozen record of the prior actual read-only R684/R688 inspection; this replay does not read those historical paths','findings':'R684 A1/S3 give a reviewed analytic actual original-tau construction for square n>=2^40, using raw w admission, true disjoint shell owners and exact saturation clipping. Existing scripts certify scalars/normalization; they do not enumerate that huge history. R688 scripts are local geometry/graph certificates and entropy scalar checks, not raw-history generators.','frozen_candidate_required':'Any subsequent finite source/receiver replay must preserve raw w separately from clipped q, exact original owners and real receiver measures, all q0 original labels, parent ordering, complete positive cells and historical routing. No reduced-tau fixture is called an original-tau history.','read_source_sha256':references},'summary':{'dimension_count':len(rows),'all_Rcrit_greater_than_sqrt_n':True,'all_root_scale_fee_checks_fail_le1':True,'all_old_R_n_fee_checks_pass_le1':True,'all_critical_equation_and_asymptotic_checks_passed':True},'elapsed_seconds':time.time()-tick,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'checks':rows},indent=2))
