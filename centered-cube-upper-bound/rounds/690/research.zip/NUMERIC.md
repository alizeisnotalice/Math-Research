# R690 actual all-source filter constant optimization

## Decision

Allowing a payment of order U rather than U/tau improves this sufficient dilation radius from n to about n/log(n). It does not reduce this particular filter's threshold to sqrt(n). At all seven requested dimensions the exact critical radius exceeds sqrt(n), while the older R=n fee is below U.

This is a calculation for the independently proved actual all-source filter constant. It is not a necessary geometric radius bound, a general counterexample, an original-history generator, or a new deletion LP.

## Exact threshold and stable computation

For `tau=16384sqrt(n)` and the specified conservative `c0=1+1/(32n)`, the filter fee is

`F_n(R) U`, `F_n(R)=8(1+c0/R)^n/tau`.

Since F decreases in R and tau/8>1, its unit-U threshold is exactly

`Rcrit=c0/expm1(log(tau/8)/n)`.

Thus `F_n(R)<=1` iff `R>=Rcrit` for this expression. The actual much larger a decreases c0 slightly and improves the threshold. The code uses 384-bit Arb and stable expm1, not subtraction of nearly equal exponentials. At every computed critical radius the certified log-fee ball contains zero. Exact tau/8 powers of two independently check the logarithm.

The computation proceeds in three bounded stages: n=256,65536; old-radius comparisons at n=2^20,2^32; then expansion only to the frozen n=2^40,2^64,2^128. Full certified intervals, margins and inputs are in RESULT.json. Displayed centers below are approximate.

| n | Rcrit | Rcrit/sqrt(n) | log F_n(sqrt(n)) | F_n(n) |
|---|---:|---:|---:|---:|
| 2^8 | 24.12832 | 1.508020 | 5.124534 | 0.00008280400 |
| 2^16 | 4975.737 | 19.43647 | 242.3316 | 0.000005184674 |
| 2^20 | 72036.43 | 70.34807 | 1008.944 | 0.000001296177 |
| 2^32 | 2.294936e+8 | 3501.795 | 65516.79 | 2.025278e-8 |
| 2^40 | 5.116968e+10 | 48799.21 | 1048554 | 1.265799e-9 |
| 2^64 | 6.189076e+17 | 1.441007e+8 | 4.294967e+9 | 3.090329e-13 |
| 2^128 | 6.545649e+36 | 3.548403e+17 | 1.844674e+19 | 7.195232e-23 |

Every root-radius log-fee is strictly positive, so its unit-U test fails. Every old-radius log-fee is strictly negative, so R=n passes. The large root-radius fee itself is never exponentiated; only its logarithm is stored.

Failure at the conservative upper c0 alone would not prove failure at the actual smaller c0. The code therefore also checks the analytic lower bound valid for every c0>=1:

`log F_n(sqrt(n))>=sqrt(n)−1/2−log(tau/8)`.

This follows from `log(1+x)>=x−x²/2`. The lower bound is already about5.102792 at n=256 and is positive at every requested dimension. Its derivative as a function of n is `1/(2sqrt(n))−1/(2n)>0` for n>1, so the elementary scalar argument also explains the persistent obstruction for this fee expression. This says nothing about a sharper geometric filter or another proof of the original bound.

## Analytic scale and interpretation

Write `L=log(tau/8)=log2048+(1/2)logn` and `y=L/n`. Then

`Rcrit/[c0 n/L]=y/expm1(y)`.

The exact analytic bounds

`exp(−y)<y/expm1(y)<1`

follow by integrating exp(t) from0 to y. They are also checked at every requested dimension. Hence

`Rcrit~c0 n/[log2048+(1/2)logn]`,

`Rcrit/sqrt(n)~sqrt(n)/[log2048+(1/2)logn]`.

The latter ratio grows without bound. For any other fixed positive coefficient A, once A tau/8>1 the threshold formula changes L only to `log(A tau/8)` and retains the n/log(n) asymptotic scale. These are analytic consequences of this sufficient fee formula, not extrapolations from seven points and not necessary conditions on the actual geometry.

The calculation supports optimizing the existing filter when an O(U) payment is affordable, but does not support jumping directly to a sqrt(n) radius split on the strength of this bound alone.

## Targeted historical interface inspection before the scalar task

Only the directed R684/R688 materials were inspected, together with the current R689 definitions. R684 A1/S3 describe a reviewed analytic actual-original-tau finite construction at square n>=2^40, with raw w=a^−n admission, disjoint shell-cell owners and exact saturation-prefix clipping. Its existing NUMERIC.py/verify.py check scalar inequalities and normalization algebra; they do not enumerate that enormous original history. R688's scripts provide finite geometry/conflict certificates and entropy scalar checks, not a raw-admission/clipping generator.

A reusable future source/receiver ledger must keep raw w separate from clipped q; exact original raw/selected owner measures; all original labels including q=0; descending radii; full positive-cell prefix and final fields; actual receiver-piece masses; group witnesses and routing; and the all-source screening flags. Existing Fraction arrangements and certificate tools can audit a frozen finite instance after authors provide it. A reduced-tau small history must not be called an original-tau history. No such model or generic generator was run in this task.

The previously observed read-source hashes are frozen as a dictionary in NUMERIC.py. They record that earlier actual inspection; replays do not read the historical absolute paths or claim a fresh inspection. The scalar script therefore runs from an extracted current-round archive without those old files. No backup, migration or unrelated historical search was attempted.

## Reproducibility

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r690-20261116/NUMERIC.py
```

Python/platform/python-flint versions, precision384, exact n/tau/c0 inputs, source hash, stage labels, full intervals and errors are retained in RESULT.json. The final bounded run took about0.022seconds, all threshold/asymptotic/old-radius/lower-endpoint checks passed, errors are empty, and the Python process exited with code zero.

Source SHA-256: `8a0a5859adc134130115af14c13e6f82465ce717dcdb404d70163b452254c394`. Result SHA-256: `b374517f210817ecbf8a93156e85c73d7ee672cba44ece117c6a11066044eca6`.

Only the three owned R690 files were written. No expensive history generation, new toy LP, arbitrary scan, MATLAB, package installation, PDF, Git or subagent was used. Computation is stopped pending the authors' next frozen geometric formula.
