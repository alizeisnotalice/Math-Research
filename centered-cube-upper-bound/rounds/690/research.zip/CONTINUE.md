# R690 — next work must bridge coverage and charging

Original arbitrary-L1/all-scale/Lebesgue C_n<=Ksqrt(n) goal remains OPEN. No new general upper order is proved. Preserve raw admission versus clipped q, genuine disjoint Fi and Xh, all original labels including q0, all cells, and true history. Final g is not assumed small on owners/receivers.

Actual original bill after far/up was Cadm{[1+(Kfar+Kup)/tau]U+Vpre}. Replace the R689 allsource split directly from Vpre with conservative Rn=(1+1/(32n))/expm1(log(tau/8)/n): qualifying T_Rn>=tau/8 class costs<=U, contains previous R=n class. New complete bill Cadm{[2+(Kfar+Kup)/tau]U+Vdagger}; do NOT add Kall again. Rn~n/logn, still much larger than sqrt n. This is existing formula optimized, not an independently new geometric theorem. More tuning of this same scalar dilation does not reach the root scale.

New actual global mass flow: S={g=tau}; on Fi, g_<=i<=b0=1+a^-n. Kij=1j>i/µi integral_Fi∩S(qj1Aj/g_>i), zero mass rows zero. Row sum is owner tight fraction, µK<=µ/(tau-b0). For nonnegative ν<=λµ, future total cost<=λU/(tau-b0-1). This is rigorous finite actual-owner contraction and source-use accounting.

Critical direction mismatch: oldbirth Sj has zero overlap with every later positive source. Any further deletion on that old cell must use earlier active sources; K moves forward. An already legal deletion can be represented as owner density δ_i/qi<=1/tau, but that fact does not prove its all-parent coverage or couple later obligations to K. Whole-parent rollback can lose objective without releasing a still-shared source constraint; a target may precede and be larger than a laterbirth. Do not assume either monotone small-radius cascade or average-to-esssup lifting.

The next meaningful proof target is a joint action selecting/retiring whole original parents while maintaining ALL cell constraints, bounding whole-parent rollback loss and backward coverage cost by a true paid mass budget. It must pay entire Vdagger or a uniform gain sufficient for original P0. Reproving K contraction, generic LP duality, positive initial slopes, or toy exchanges does not solve that step.

S2's common dual-mass-block payment is valid only when each block lies in all its assigned parents, block mass pays their maximum volume, and blocks share one dual capacity. No such full covering selection is proved; atom refinement alone is not progress. Do not launch more atom/density branches in place of joint selection.

Local computation: 7 frozen dimensions through2^128, Arb384; independent verifier512. These are scalar fee decisions, not actual high-tau history simulations. Old true history is analytically compressed and has no small executable replay. NUMERIC.py now contains frozen provenance and reruns standalone. No MATLAB, PDF, installation, or broad scans. Model cap remains one Astra and three GPT-6.1 Sol; all have bounded ownership, no children.

Keep the signed SAME-h bill from REPORT: (7tau/8)Vdagger <= sum µ_i m_i + [sum qi m_i ri + integral hF(tau-g) -(7tau/8)sum target w_h r_h]. All r_i use one actual optimal dual h; target favorable slack must not be silently discarded. The weaker +LDelta is valid but not the preferred joint object. No uniform estimate of this signed object is proved, and bounding its pieces independently may be too strong.
