from pathlib import Path
import json,hashlib
from flint import arb,ctx
p=Path(__file__).resolve().parent;r=json.loads((p/'RESULT.json').read_text());ctx.prec=512
assert r['script_sha256']==hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()
assert len(r['checks'])==7
for row,power in zip(r['checks'],(8,16,20,32,40,64,128)):
 n=2**power;s=2**(power//2);tau=16384*s
 assert int(row['n_exact'])==n and int(row['sqrt_n_exact'])==s and int(row['tau_exact'])==tau
 c=1+arb(1)/(32*n);L=(11+power//2)*arb(2).log();y=L/n
 R=c/y.expm1();v=y/y.expm1()
 assert R>s and R<n and v>(-y).exp() and v<1
 lower=s-arb(1)/2-L;root=n*(1+c/s).log()-L;old=n*(1+c/n).log()-L
 assert lower>0 and root>lower and old<0
 assert arb(row['Rcrit']).contains(R) or arb(row['Rcrit']).overlaps(R)
 assert arb(row['Rcrit_over_sqrt_n']).overlaps(R/s)
 assert arb(row['R_sqrt_n_log_fee']).overlaps(root)
 assert arb(row['R_n_log_fee']).overlaps(old)
 assert (n*(1+c/R).log()-L).contains(0)
# Analytic n=256 endpoint certified independently; monotonicity is proved in report.
assert arb(16)-arb(1)/2-15*arb(2).log()>5
if (p/'MANIFEST.json').exists():
 for name,digest in json.loads((p/'MANIFEST.json').read_text())['sha256'].items():
  assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: 7 scalar cases independently checked at 512 bits; critical equations, asymptotic bounds and stored balls; general geometry not certified numerically.')
