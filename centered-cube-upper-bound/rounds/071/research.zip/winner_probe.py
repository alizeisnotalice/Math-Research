#!/usr/bin/env python3
"""Actual weak-threshold and smallest-volume complete-batch winner probes.
Positive common sources; full-space full-mixture receiver density; finite exploration.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse, hashlib, itertools, json, math, time
from pathlib import Path
from fractions import Fraction as F
import numpy as np


def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])

def integer_masses(src):
    masses=[F(p)/F(src['W']) for p in src['weights']];den=math.lcm(*(p.denominator for p in masses));assert den<2**60
    integers=np.array([p.numerator*(den//p.denominator) for p in masses],dtype=np.int64)
    return den,integers

def pack(coords,weights,family):
    merged={};weights=[F(p) for p in weights];W=sum(weights)
    for y,p in zip(coords,weights):merged[tuple(float(z) for z in y)]=merged.get(tuple(float(z) for z in y),F(0))+p/W
    return dict(family=family,n=len(coords[0]),N_requested=len(coords),N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W='1')

def binary_geometry(x,coords):
    xr=[float(z).as_integer_ratio() for z in x];yr=[[float(z).as_integer_ratio() for z in y] for y in coords]
    B=max(t.bit_length()-1 for u,t in xr+sum(yr,[]));xi=[u<<(B-(t.bit_length()-1)) for u,t in xr]
    ds=[max(abs(z-(u<<(B-(t.bit_length()-1)))) for z,(u,t) in zip(xi,row)) for row in yr]
    return ds,B

def exact_winner(x,src,H):
    ds,B=binary_geometry(x,src['coords']);den,ints=integer_masses(src);order=sorted(range(src['N']),key=lambda i:ds[i])
    cum=0;bestnum=0;bestden=1;best=-1
    for j,i in enumerate(order):
        cum+=int(ints[i])
        if j+1<len(order) and ds[i]==ds[order[j+1]]:continue
        d=ds[i]**src['n']
        if d==0:raise ValueError('Receiver coincides with an atom; null-set sample unsupported')
        if cum*bestden>bestnum*d:bestnum,bestden,best=cum,d,j
    M=F(bestnum,bestden)*F(src['W'])/den/F(2)**(src['n']*(1-B))
    capture=np.zeros(src['N'],dtype=bool);capture[order[:best+1]]=True
    return capture,M,H<M<=2*H,order,best

def summary(z,bound):
    sm=float(z.sum());ss=float(z@z);S=len(z)
    return dict(mean=float(z.mean()),sample_SE=float(z.std(ddof=1)/math.sqrt(S)),maximum=float(z.max()),ideal_score_bound=bound,formal_Hoeffding95_radius=bound*math.sqrt(math.log(40)/(2*S)),nonnegative_score_ESS=sm*sm/ss if ss else 0,top_one_percent_score_fraction=float(np.sort(z)[-max(1,S//100):].sum()/sm) if sm else 0)

def actual_volumes(x,src,H):
    ds,B=binary_geometry(x,src['coords']);V=F(src['W'])/F(H);factor=F(2)**(src['n']*(1-B))/V
    return [d**src['n']*factor for d in ds],[F(p)/F(src['W']) for p in src['weights']]

def structured_source(kind,n,N,seed):
    rng=np.random.default_rng(seed)
    if kind=='binary':
        if N<=2**n:
            labels=rng.choice(2**n,size=N,replace=False)
            y=np.array([[2*((int(j)>>k)&1)-1 for k in range(n)] for j in labels],float)
        else:
            y=rng.choice([-1.,1.],size=(N,n))+rng.integers(-8,9,size=(N,n))/64
        weights=[1]*N
    elif kind=='hierarchical':
        depth=max(1,(N-1).bit_length())
        code=rng.integers(0,2,size=(depth,n))*2-1
        y=np.array([sum((((j>>k)&1)*2-1)*2.**(-k)*code[k] for k in range(depth)) for j in range(N)])
        y/=max(1.,float(abs(y).max()));weights=[1]*N
    elif kind=='correlated':
        t=np.linspace(-1,1,N)[:,None]
        y=t+rng.integers(-4,5,size=(N,n))/128;weights=[1]*N
    elif kind=='unequal_cloud':
        y=rng.integers(-64,65,size=(N,n))/64;weights=[1+(j%8)**2 for j in range(N)]
    elif kind=='multi_cluster':
        centers=rng.choice([-1.,1.],size=(4,n));y=np.array([centers[j%4]+rng.integers(-8,9,size=n)*2.**(-4-j//4) for j in range(N)])
        weights=[1+3*(j%4==0) for j in range(N)]
    else:raise ValueError(kind)
    return pack(y.tolist(),[F(p) for p in weights],kind)

def digest(src,H):
    return hashlib.sha256(json.dumps(dict(source=src,H=str(H)),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def mutate(src,H,rng,j):
    y=np.array(src['coords'],float);a=[F(p)/F(src['W']) for p in src['weights']];n=src['n'];N=src['N'];op=j%6
    p=list(a)
    if op==0:
        i=int(rng.integers(N));y[i]+=rng.integers(-8,9,size=n)/64;name='one_site_dyadic_perturbation'
    elif op==1:
        k=int(rng.integers(n));y[:,k]*=float(rng.choice([F(7,8),F(9,8)]));name='coordinate_stretch'
    elif op==2:
        k=int(rng.integers(n));shift=int(rng.choice([-1,1]))/8;y[y[:,k]>np.median(y[:,k]),k]+=shift;name='half_source_shift'
    elif op==3:
        p=[F(max(1,min(64,round(float(t/max(a))*32)))) for t in a];i=int(rng.integers(N));p[i]=F(int(rng.integers(1,65)));name='positive_integer_mass_reallocation'
    elif op==4:
        y+=rng.integers(-1,2,size=(N,n))/64;name='all_site_dyadic_perturbation'
    else:
        H*=F.from_float(2.**(int(rng.choice([-1,1]))*n/8));name='threshold_log_root_step'
        return src,H,name
    return pack(y.tolist(),p,src['family']),H,name

RETAINED_R70=[{'chain': 0, 'initial': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[-0.109375], [0.5625], [0.703125], [0.90625], [0.65625], [0.640625], [-0.703125], [-0.359375], [0.78125], [-0.84375], [-0.03125], [-0.890625], [-0.453125], [0.125], [-0.328125], [0.171875]], 'family': 'unequal_cloud', 'n': 1, 'weights': ['1/296', '1/148', '5/296', '5/148', '17/296', '13/148', '1/8', '25/148', '1/296', '1/148', '5/296', '5/148', '17/296', '13/148', '1/8', '25/148']}, 'initial_H': '1/4', 'selected': {'N': 13, 'N_labels': 13, 'N_requested': 13, 'W': '1', 'coords': [[-0.123046875], [0.369140625], [0.4921875], [0.720703125], [0.439453125], [0.404296875], [-0.7734375], [-0.38671875], [0.59765625], [-0.0703125], [-1.01953125], [-0.4921875], [-0.10546875]], 'family': 'unequal_cloud', 'n': 1, 'weights': ['18/211', '4/211', '3/211', '6/211', '29/211', '17/211', '25/211', '56/211', '1/211', '3/211', '6/211', '11/211', '32/211']}, 'selected_H': '8259638134547591/36028797018963968'}, {'chain': 1, 'initial': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[1.0, 1.0, -1.0, -1.0], [1.0, 1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, 1.0], [1.0, 1.0, -1.0, 1.0], [1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, 1.0], [1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, -1.0], [1.0, -1.0, -1.0, 1.0], [1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, -1.0, -1.0], [1.0, -1.0, -1.0, -1.0]], 'family': 'binary', 'n': 4, 'weights': ['1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16']}, 'initial_H': '1/64', 'selected': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[0.875, 1.0, -1.0, -0.875], [0.875, 1.0, 1.125, 0.75], [-0.875, 1.0, 1.125, 0.75], [0.875, 1.0, -1.0, 0.75], [0.875, 1.0, 1.125, -0.875], [-0.875, -1.0, -1.0, 0.75], [-0.875, 1.0, -1.0, 0.75], [0.875, -1.0, 1.125, -0.875], [-0.875, 1.0, 1.125, -0.875], [-0.875, -1.0, 1.125, 0.75], [-0.875, 1.0, -1.0, -0.875], [-0.875, -1.0, 1.125, -0.875], [0.875, -1.0, -1.0, 0.75], [0.875, -1.0, 1.125, 0.75], [-0.875, -1.0, -1.0, -0.875], [0.875, -1.0, -1.0, -0.875]], 'family': 'binary', 'n': 4, 'weights': ['1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16']}, 'selected_H': '1/64'}, {'chain': 2, 'initial': {'N': 32, 'N_labels': 32, 'N_requested': 32, 'W': '1', 'coords': [[1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0], [1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0], [1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0], [1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0]], 'family': 'binary', 'n': 8, 'weights': ['1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32']}, 'initial_H': '1/4096', 'selected': {'N': 32, 'N_labels': 32, 'N_requested': 32, 'W': '1', 'coords': [[1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0], [1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0], [1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0], [1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0]], 'family': 'binary', 'n': 8, 'weights': ['1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32']}, 'selected_H': '1/4096'}, {'chain': 3, 'initial': {'N': 64, 'N_labels': 64, 'N_requested': 64, 'W': '1', 'coords': [[-1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0], [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0], [1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0], [1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0], [1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0], [1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0], [-1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0], [1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0], [1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, -1.0, -1.0], [1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0], [-1.0, 1.0, 1.0, -1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0], [1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0, -1.0, 1.0]], 'family': 'binary', 'n': 16, 'weights': ['1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64', '1/64']}, 'initial_H': '1/65536', 'selected': {'N': 64, 'N_labels': 64, 'N_requested': 64, 'W': '1', 'coords': [[-1.015625, 1.015625, 1.015625, 1.0, -0.984375, 0.984375, 1.015625, 1.109375, 0.984375, -0.984375, -1.0, -1.0, 1.0, -1.015625, 1.265625, -1.015625], [-1.0, 0.984375, 0.984375, -0.984375, -0.984375, 1.015625, 0.984375, 1.140625, -1.015625, 0.984375, 1.0, -1.0, -1.0, 0.984375, 1.25, 1.0], [1.0, -1.0, -1.015625, 0.984375, -1.0, 1.015625, 0.984375, -1.0, -1.015625, -0.984375, 0.984375, -0.984375, -1.015625, 1.0, -1.125, 0.984375], [-0.984375, 1.0, 1.015625, 1.0, 1.015625, 0.984375, 1.0, 1.109375, -1.0, 1.0, 1.015625, 0.890625, 1.015625, -0.984375, 1.28125, -0.984375], [-0.984375, 1.0, -1.0, -1.0, -1.0, 0.984375, -1.0, 1.125, 0.984375, -0.984375, -0.984375, -1.015625, 1.015625, -1.015625, 1.28125, -0.984375], [-0.984375, -0.984375, 0.984375, -0.984375, 1.0, 1.015625, 0.984375, -1.015625, -1.015625, -1.015625, -0.984375, -1.015625, -1.0, -0.984375, -1.125, 0.984375], [-0.984375, 1.0, 1.0, -1.0, 0.984375, 0.984375, -1.0, 1.125, 1.015625, -1.015625, -1.0, 0.875, 1.0, -1.015625, -1.125, -0.984375], [-1.0, -1.0, 1.0, 1.0, 0.984375, -1.015625, -1.015625, -1.015625, 1.015625, -0.984375, -1.015625, -1.0, -0.984375, -0.984375, 1.265625, 1.015625], [0.984375, 0.984375, 1.015625, 1.015625, 1.015625, -1.015625, -1.0, -0.984375, 0.984375, 0.984375, -1.015625, -0.984375, -1.0, -1.0, 1.25, 1.0], [-1.125, -0.90625, -1.078125, -0.953125, 0.96875, 0.984375, -1.046875, -0.859375, -0.9375, -0.953125, 0.9375, -1.015625, -1.03125, -1.140625, 1.158203125, 1.046875], [-1.0, 1.015625, 0.984375, -0.984375, -0.984375, 1.015625, 1.015625, -0.984375, -1.0, -1.0, -1.0, 0.875, -1.0, 0.984375, 1.28125, -1.015625], [-1.015625, 1.0, 0.984375, -1.0, 1.015625, 1.015625, 1.015625, -0.984375, -0.984375, -0.984375, 0.984375, 0.859375, 0.984375, 1.015625, 1.28125, 0.984375], [-0.984375, -0.984375, 1.0, -0.984375, -1.0, -1.015625, 1.015625, -1.015625, -1.015625, -1.015625, 0.984375, 0.859375, -1.015625, 1.0, -1.140625, 1.015625], [-1.015625, 1.015625, -1.0, 1.015625, 0.984375, 1.015625, 1.0, 1.125, 1.015625, -1.0, -1.0, -1.0, 0.984375, 1.015625, 1.265625, 1.015625], [-0.984375, 0.984375, -0.984375, -1.0, -0.984375, -1.015625, -1.015625, 1.140625, -0.984375, 1.0, 1.015625, -0.984375, 0.984375, 1.015625, -1.109375, -1.0], [-0.984375, -0.984375, -0.984375, 1.0, 1.0, -1.015625, -0.984375, -1.0, 1.0, -1.015625, 1.015625, -1.0, 0.984375, 0.984375, 1.265625, -1.0], [1.015625, -1.015625, -0.984375, -1.015625, 1.0, 1.0, 1.0, -1.015625, -0.984375, 1.015625, 1.0, 0.875, -0.984375, 1.0, -1.140625, -0.984375], [-0.984375, 0.984375, 1.015625, -1.0, 0.984375, 1.015625, -0.984375, -1.015625, -0.984375, -1.015625, -1.0, 0.875, 1.0, -0.984375, 1.25, -0.984375], [1.0, 0.984375, 0.984375, 1.0, 0.984375, 0.984375, -0.984375, 1.140625, -1.0, -0.984375, 1.015625, 0.890625, 1.0, -1.015625, -1.125, -1.015625], [1.015625, 1.015625, 1.0, -1.015625, -1.0, -1.015625, 1.015625, -1.0, 0.984375, -1.015625, 0.984375, -1.0, -0.984375, -0.984375, -1.125, 1.0], [-1.015625, 1.0, -1.015625, -1.0, 1.0, 0.984375, -1.015625, 1.109375, -0.984375, 1.015625, 1.0, 0.875, 0.984375, 0.984375, -1.140625, -1.015625], [0.984375, -1.015625, 1.015625, -1.0, -1.015625, 0.984375, -0.984375, 1.125, 0.984375, -1.015625, 0.984375, 0.890625, 1.0, -1.0, -1.125, 0.984375], [1.015625, 1.0, 1.015625, 1.0, -0.984375, 0.984375, 1.015625, 1.125, -0.984375, 1.015625, -1.0, -1.015625, 0.984375, -1.015625, -1.125, -1.0], [-1.015625, 0.984375, 0.984375, 1.015625, 1.0, -1.0, 1.0, -1.0, 1.015625, 1.015625, 1.0, -1.015625, -1.0, -1.015625, -1.140625, 1.015625], [-0.984375, 0.984375, -1.0, -1.0, -1.015625, -0.984375, 1.0, 1.140625, 1.0, 1.0, -1.0, -1.015625, -1.015625, 1.015625, -1.125, -0.984375], [-1.0, 1.015625, -1.0, 0.984375, 0.984375, 1.0, 0.984375, -0.984375, 0.984375, -1.0, -1.0, -0.984375, -1.015625, 1.015625, -1.125, -1.015625], [-1.015625, 1.015625, 1.0, -1.015625, 1.0, -1.0, -1.015625, -0.984375, 0.984375, -1.0, 1.0, 0.875, 1.015625, 1.0, -1.125, 1.0], [-0.984375, 0.984375, 0.984375, 1.0, -0.984375, -0.984375, -1.015625, 1.140625, 1.0, -1.0, -1.0, 0.875, -1.015625, 0.984375, -1.140625, -0.984375], [-1.0, -1.015625, 0.984375, -1.015625, -1.0, 1.015625, 1.015625, -1.0, -0.984375, -1.0, -1.0, -0.984375, -0.984375, 1.015625, 1.25, 0.984375], [-1.015625, -1.0, 1.0, -1.0, -0.984375, -1.0, -1.0, -0.984375, -0.984375, 0.984375, 0.984375, 0.890625, -1.015625, -0.984375, -1.140625, 1.0], [-1.015625, 0.984375, -1.015625, 1.015625, -0.984375, 0.984375, 0.984375, -0.984375, 0.984375, 1.015625, -0.984375, 0.859375, -0.984375, -0.984375, -1.140625, 0.984375], [0.90625, 1.0, 0.9375, -1.046875, -1.078125, -0.875, 1.125, -0.96875, -0.859375, 0.890625, -1.125, 1.0, -0.96875, -1.046875, 1.3515625, 0.96875], [1.0, 1.0, -1.015625, -1.015625, 1.015625, 1.015625, -1.015625, -1.0, -1.015625, 1.0, -1.015625, -0.984375, -1.0, 0.984375, -1.125, -1.015625], [1.0, -1.0, -1.0, -1.015625, 1.0, -1.0, 1.015625, 1.125, -1.015625, -1.0, 1.0, -1.015625, -0.984375, 1.0, -1.125, 1.0], [1.0, -1.015625, -0.984375, -0.984375, 1.015625, -0.984375, -1.0, -1.0, 1.015625, 0.984375, 1.015625, 0.890625, -1.015625, -0.984375, -1.109375, 1.0], [1.0, 0.984375, -1.0, 0.984375, 1.0, -1.015625, 0.984375, -1.015625, 0.984375, 1.0, 0.984375, -1.0, 1.0, 0.984375, 1.265625, -0.984375], [-0.984375, -1.0, 1.015625, 0.984375, 1.015625, -0.984375, -0.984375, 1.125, -1.0, 1.015625, -1.0, -1.015625, 1.0, 0.984375, -1.140625, 1.0], [-1.015625, 1.0, 0.984375, -0.984375, 0.984375, 1.015625, 1.0, -0.984375, 1.015625, -1.015625, -1.0, 0.859375, 1.015625, -1.015625, 1.265625, -1.015625], [-1.015625, -1.015625, 1.015625, 1.015625, -1.015625, 0.984375, 1.0, -1.0, -1.015625, 1.0, -1.015625, 0.890625, 1.015625, 0.984375, -1.140625, -1.015625], [-1.015625, -1.0, 0.984375, 1.0, 1.0, -1.0, 0.984375, -0.984375, 1.015625, 0.984375, 1.015625, 0.859375, 1.015625, 0.984375, 1.25, -0.984375], [-0.984375, 1.015625, 1.015625, 1.015625, 1.015625, -1.0, -0.984375, -1.0, 1.015625, 1.0, 1.0, -1.0, -1.0, -0.984375, -1.109375, -1.0], [-0.984375, -1.0, -1.015625, -1.015625, 1.015625, -1.015625, 1.0, -0.984375, 1.0, -1.0, -1.015625, -1.0, 1.015625, -1.0, -1.140625, -1.015625], [-1.015625, -1.015625, -1.015625, 0.984375, 1.0, 1.015625, -1.0, -0.984375, -1.015625, 0.984375, 1.0, 0.875, -1.015625, 1.015625, -1.140625, -1.0], [-1.0, -0.984375, -1.015625, -0.984375, -1.015625, -1.0, 0.984375, 1.109375, -0.984375, -1.0, -1.015625, -1.015625, -0.984375, 0.984375, -1.140625, 1.0], [-0.984375, -1.0, 1.0, -1.0, 1.0, -0.984375, 0.984375, 1.109375, -1.015625, 1.0, -0.984375, -1.0, -1.015625, -1.0, 1.28125, -0.984375], [1.015625, -1.0, 0.984375, 1.0, 1.0, -0.984375, -1.015625, 1.109375, 1.015625, 0.984375, -0.984375, -1.0, -1.015625, 0.984375, -1.109375, -1.015625], [-0.984375, -1.015625, 1.015625, 1.015625, 0.984375, -1.0, -1.0, -1.0, -0.984375, -1.0, 0.984375, -1.015625, -1.015625, 1.015625, 1.265625, 1.0], [-1.0, -1.0, -1.0, -1.0, 1.0, 1.015625, 1.015625, -0.984375, -0.984375, -1.0, -0.984375, -1.0, 1.015625, -0.984375, 1.25, -1.015625], [-1.0, -1.015625, 0.984375, -1.015625, 1.015625, 1.0, 1.015625, -0.984375, -0.984375, -1.0, 1.0, 0.859375, 0.984375, 1.015625, 1.265625, -1.015625], [-1.015625, 1.015625, 1.0, 1.015625, 1.0, -1.0, -1.0, 1.109375, -1.015625, -0.984375, 1.0, 0.859375, -1.015625, 0.984375, -1.109375, 0.984375], [1.0, -0.984375, -1.0, -0.984375, 0.984375, -0.984375, 1.015625, 1.109375, 0.984375, 0.984375, 0.984375, -1.015625, -0.984375, 1.0, -1.109375, 0.984375], [-1.0, 0.984375, -1.0, -0.984375, 1.0, -1.015625, -1.015625, 1.125, 1.0, -0.984375, 0.984375, -1.0, 1.015625, -1.0, -1.140625, 1.015625], [-1.015625, -0.984375, -1.015625, 1.0, -1.015625, 1.015625, -0.984375, 1.140625, -0.984375, -1.015625, 1.0, 0.875, 1.015625, 1.0, 1.28125, -1.0], [-1.015625, -1.015625, -0.984375, 0.984375, 0.984375, 1.0, 1.0, -0.984375, -0.984375, -1.015625, -0.984375, -0.984375, -0.984375, 1.0, 1.265625, 1.0], [1.015625, 1.0, -0.984375, -0.984375, -1.015625, 1.015625, 0.984375, -0.984375, -1.015625, -1.015625, 0.984375, -0.984375, -1.015625, -0.984375, 1.28125, 1.0], [-0.984375, 1.0, 1.0, 1.015625, 1.0, -1.015625, 1.015625, -0.984375, -1.0, 1.0, 0.984375, 0.859375, 1.015625, 0.984375, 1.25, -1.0], [-1.015625, 0.984375, 1.015625, -1.0, -1.015625, -1.0, -0.984375, -1.015625, 0.984375, -1.015625, 1.015625, -1.0, 0.984375, -0.984375, -1.109375, 0.984375], [1.0, -0.984375, 1.0, 0.984375, -1.0, 0.984375, -1.0, -1.0, 1.015625, 1.015625, 1.015625, -1.0, 1.0, 1.015625, -1.140625, 0.984375], [-0.984375, 1.0, 0.984375, -0.984375, 0.984375, -0.984375, 0.984375, -1.015625, 1.015625, 1.0, -0.984375, 0.875, 1.0, 1.015625, -1.125, -0.984375], [0.984375, -1.0, -1.0, 1.015625, 1.015625, -1.0, -1.015625, -1.015625, 1.015625, 0.984375, -1.0, -1.0, 0.984375, -1.015625, 1.265625, 1.0], [-1.015625, -1.015625, 1.0, -1.0, -0.984375, -1.0, -1.015625, -0.984375, 1.015625, -1.0, -1.015625, -0.984375, 1.015625, -1.0, 1.25, 0.984375], [-0.984375, 0.984375, 1.015625, -0.984375, 1.0, -0.984375, 0.984375, 1.125, 1.0, 1.0, -1.015625, 0.859375, 1.0, 1.015625, 1.25, -0.984375], [1.0, 0.984375, 1.0, -1.0, 1.0, 1.0, 1.015625, 1.140625, -0.984375, 1.015625, 0.984375, -1.0, -1.015625, 0.984375, -1.140625, -1.0], [-0.984375, -0.984375, -0.984375, -1.015625, -1.0, 0.984375, 1.015625, -0.984375, 0.984375, -1.015625, -1.015625, 0.875, 1.0, 1.0, -1.109375, 1.015625]], 'family': 'binary', 'n': 16, 'weights': ['32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '5/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '32/2007', '2/223', '32/2007', '32/2007', '32/2007']}, 'selected_H': '1/4194304'}]


def draw_winner(src,lam,S,seed):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/lam)
    component=rng.choice(3,size=S,p=[.5,.25,.25]);unif=rng.integers(src['N'],size=S);mass=rng.choice(src['N'],size=S,p=a);center=np.where(component==0,unif,mass)
    U=np.maximum(rng.random(S),np.nextafter(0.,1.));inner=rng.integers(0,2,size=S)==0
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))+np.where(component==2,np.log(a[center]),0)
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1;theta[np.arange(S),face]=sign
    return y[center]+(.5*np.exp(lv/n))[:,None]*theta,component,center,U,inner,face,sign


def winner_batch(x,src,lam):
    y,a=arrays(src);S=len(x);n=src['n'];N=src['N'];den,ints=integer_masses(src);V=float(F(src['W'])/lam)
    delta=x[:,None,:]-y[None,:,:];dist=np.max(abs(delta),axis=2)
    if np.any(dist==0):raise ValueError('Null-set atom receiver coincidence unsupported')
    L=n*np.log(2*dist)-math.log(V)
    t=np.exp(-2*np.maximum(L,0));q=t.sum(axis=1)/(4*N)+(t*a[None,:]).sum(axis=1)/8+np.exp(-2*np.maximum(L-np.log(a)[None,:],0)).sum(axis=1)/8
    order=np.argsort(L,axis=1,kind='stable');sl=np.take_along_axis(L,order,axis=1)
    ends=np.concatenate([sl[:,1:]!=sl[:,:-1],np.ones((S,1),bool)],axis=1);fix=0;falsegroups=0
    near=np.any(abs(sl[:,1:]-sl[:,:-1])<=64*np.finfo(float).eps*(np.max(abs(sl),axis=1)[:,None]+2),axis=1)
    for r in np.flatnonzero(near):
        ds,B=binary_geometry(x[r],src['coords']);oi=sorted(range(N),key=lambda i:ds[i]);order[r]=oi;sl[r]=L[r,oi]
        en=np.array([ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True]);falsegroups+=int(np.sum(en & ~np.concatenate([sl[r,1:]!=sl[r,:-1],[True]])));ends[r]=en;fix+=1
    cum=np.cumsum(ints[order],axis=1);arr=np.where(ends,cum/den*np.exp(-sl),0);best=np.argmax(arr,axis=1);M=np.max(arr,axis=1)
    # Smallest-volume maximizing complete batch, with exact fallback for close winners.
    runner=np.partition(arr,-2,axis=1)[:,-2] if N>1 else np.zeros(S)
    exact=np.flatnonzero((M-runner<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-1)<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-2)<=128*np.finfo(float).eps*np.maximum(M,1)))
    exactmeta={}
    for r in exact:
        capture,mm,_,oi,bj=exact_winner(x[r],src,lam);order[r]=oi;sl[r]=L[r,oi];best[r]=bj;M[r]=float(mm/lam)
        ds,B=binary_geometry(x[r],src['coords']);ends[r]=[ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True];exactmeta[r]=(capture,mm)
    cum=np.cumsum(ints[order],axis=1);Fstar=cum[np.arange(S),best]/den;count=best+1
    tau=np.exp(sl[np.arange(S),best]);rank=np.empty((S,N),int);np.put_along_axis(rank,order,np.broadcast_to(np.arange(N),(S,N)),axis=1);capture=rank<=best[:,None]
    weak=M>1;band=(M>1)&(M<=2)
    for r,(cp,mm) in exactmeta.items():
        capture[r]=cp;count[r]=int(cp.sum());Fstar[r]=float(F(int(ints[cp].sum()),den));tau[r]=Fstar[r]/float(mm/lam);weak[r]=mm>lam;band[r]=lam<mm<=2*lam
    single=count==1;majority=(~single)&(cum[np.arange(S),best]*2>den);residual=~single & ~majority
    inv=q**-1;weakscore=weak*inv;bandscore=band*M*inv;bandvolume=band*inv
    loads=band[:,None]*capture/(tau*q)[:,None];weightedloads=loads*a[None,:]
    assert np.max(abs(weightedloads.sum(axis=1)-bandscore))<2e-9
    assert np.max(weakscore)<=4*N*(1+1e-10) and np.max(bandscore)<=8*N*(1+1e-10)
    assert np.max(weightedloads)<=8*N*(1+1e-10)
    eff=Fstar**2/np.sum(capture*a[None,:]**2,axis=1)
    posterior=capture*a[None,:]/Fstar[:,None];entropy=-np.sum(posterior*np.log(np.maximum(posterior,1e-300)),axis=1)
    # Common-source active-face diagnostics, not paid budgets.
    prev=np.maximum.accumulate(np.where(ends,np.arange(N),-1),axis=1);start=np.concatenate([np.zeros((S,1),int),prev[:,:-1]+1],axis=1)[np.arange(S),best]
    boundary=np.min(np.where((np.arange(N)>=start[:,None])&(np.arange(N)<=best[:,None]),order,N),axis=1)
    bd=delta[np.arange(S),boundary];active=np.argmax(abs(bd),axis=1);sgn=np.sign(bd[np.arange(S),active]);radius=np.max(abs(bd),axis=1)
    bary=(capture*a[None,:])@y/Fstar[:,None];yb=y[boundary,active];zeta=n*sgn*(bary[np.arange(S),active]-yb)/radius
    inward=sgn[:,None]*(y[:,active].T-yb[:,None]);face1=np.sum(capture*a[None,:]*(inward<=radius[:,None]/n),axis=1)/Fstar;facesqrt=np.sum(capture*a[None,:]*(inward<=radius[:,None]/math.sqrt(n)),axis=1)/Fstar
    assert zeta.min()>-1e-8;zeta=np.maximum(zeta,0)
    return dict(M=M,q=q,weak=weak,band=band,weakscore=weakscore,bandscore=bandscore,bandvolume=bandvolume,Fstar=Fstar,count=count,eff=eff,posterior=posterior,entropy=entropy,tau=tau,capture=capture,single=single,majority=majority,residual=residual,loads=loads,weightedloads=weightedloads,boundary=boundary,active=active,sgn=sgn,zeta=zeta,face1=face1,facesqrt=facesqrt,geometry_fallback=fix,falsegroups=falsegroups,exact_winner_rows=len(exact))


def winner_probe(src,lam,S,seed,stage):
    x,component,center,U,inner,face,sign=draw_winner(src,lam,S,seed);N=src['N'];a=arrays(src)[1]
    chunks=[winner_batch(x[j:j+128],src,lam) for j in range(0,S,128)];ks=[k for k in chunks[0] if k not in ['geometry_fallback','falsegroups','exact_winner_rows']];d={k:np.concatenate([z[k] for z in chunks]) for k in ks}
    def stats(z,b):return summary(z,b)
    def saved(i):return dict(receiver=x[i].tolist(),M_lambda=float(d['M'][i]),weak=bool(d['weak'][i]),band=bool(d['band'][i]),qcore=float(d['q'][i]),winner_tau=float(d['tau'][i]),winner_fraction=float(d['Fstar'][i]),captured_indices=np.flatnonzero(d['capture'][i]).tolist(),winner_count=int(d['count'][i]),effective_count=float(d['eff'][i]),weak_score=float(d['weakscore'][i]),band_score=float(d['bandscore'][i]),boundary_atom=int(d['boundary'][i]),active_coordinate=int(d['active'][i]),active_sign=int(d['sgn'][i]),zeta=float(d['zeta'][i]),component=int(component[i]),selected_center=int(center[i]),U=float(U[i]),radial_inner=bool(inner[i]),face=int(face[i]),sign=int(sign[i]))
    extremes=[saved(int(i)) for i in dict.fromkeys(list(np.argsort(d['weakscore'])[-2:][::-1])+list(np.argsort(d['bandscore'])[-2:][::-1]))]
    gates=[]
    for threshold in [1,2]:
        for above in [False,True]:
            ids=np.flatnonzero((d['M']>threshold)==above)
            if len(ids):gates.append(dict(threshold=threshold,above=above,**saved(int(ids[np.argmin(abs(np.log(d['M'][ids]/threshold)))]))))
    classes={name:dict(weak_volume=stats(d['weakscore']*d[name],4*N),band_M=stats(d['bandscore']*d[name],8*N)) for name in ['single','majority','residual']}
    bins=[]
    for lo,hi in [(0,.125),(.125,.25),(.25,.5),(.5,.75),(.75,1)]:
        mask=(d['Fstar']>lo)&(d['Fstar']<=hi);bins.append(dict(lower_open=lo,upper_closed=hi,weak_volume=stats(d['weakscore']*mask,4*N),band_M=stats(d['bandscore']*mask,8*N)))
    columns=[]
    for i in range(N):
        columns.append(dict(source_index=i,mass_fraction=float(a[i]),load=stats(d['loads'][:,i],8*N/a[i]),weighted_load=stats(d['weightedloads'][:,i],8*N),weighted_residual_load=stats(d['weightedloads'][:,i]*d['residual'],8*N)))
    heavy=[dict(eta=eta,estimate=stats(d['bandscore']*np.sum(d['posterior']*(d['posterior']>=eta),axis=1),8*N),analytic_bound=1+math.log(2/eta)) for eta in sorted(set([.5,.25,.0625,1/math.sqrt(src['n']),1/src['n']]))]
    powers=[dict(alpha=alpha,estimate=stats(d['bandscore']*np.sum(d['posterior']**alpha,axis=1),8*N),analytic_bound=1+math.log(2)+1/(alpha-1)) for alpha in [1.25,1.5,2]]
    entropy_cutoffs=[dict(cutoff=h,estimate=stats(d['bandscore']*(d['entropy']<=h),8*N),residual_estimate=stats(d['bandscore']*d['residual']*(d['entropy']<=h),8*N),analytic_bound=math.e*(2+math.log(2)+h)) for h in [math.sqrt(src['n']),math.sqrt(src['n'])*math.log(src['n']+2)]]
    entropy_strata=[]
    for lo,hi in [(-1e-10,math.log(2)),(math.log(2),math.log(4)),(math.log(4),math.log(16)),(math.log(16),math.log(64)),(math.log(64),math.inf)]:
        mask=(d['entropy']>lo)&(d['entropy']<=hi);entropy_strata.append(dict(lower_open=lo,upper_closed=hi if math.isfinite(hi) else None,band_M=stats(d['bandscore']*mask,8*N)))
    bsum=d['bandscore'].sum();wsum=d['weakscore'].sum();diag={}
    for name in ['weakscore','bandscore']:
        weights=d[name];sm=weights.sum();diag[name]=dict(weighted_mean_mass_fraction=float(weights@d['Fstar']/sm) if sm else None,weighted_mean_site_count=float(weights@d['count']/sm) if sm else None,weighted_mean_effective_count=float(weights@d['eff']/sm) if sm else None,weighted_mean_posterior_entropy=float(weights@d['entropy']/sm) if sm else None)
    residual=d['bandscore']*d['residual'];descriptors=dict(zeta_less_one=stats(residual*(d['zeta']<1),8*N),zeta_less_sqrt_n=stats(residual*(d['zeta']<math.sqrt(src['n'])),8*N),face_mass_r_over_n=stats(residual*d['face1'],8*N),face_mass_r_over_sqrt_n=stats(residual*d['facesqrt'],8*N))
    return dict(source=src,lambda_value=str(lam),samples=S,seed=seed,stage=stage,weak_hits=int(d['weak'].sum()),band_hits=int(d['band'].sum()),weak_volume=stats(d['weakscore'],4*N),band_M=stats(d['bandscore'],8*N),band_volume=stats(d['bandvolume'],4*N),classes=classes,mass_strata=bins,winner_diagnostics=diag,columns=columns,estimated_peak_column=max(range(N),key=lambda i:columns[i]['load']['mean']),column_sum_mean=float(sum(z['weighted_load']['mean'] for z in columns)),column_pointwise_max_discrepancy=float(np.max(abs(d['weightedloads'].sum(axis=1)-d['bandscore']))),descriptors=descriptors,heavy_posterior_traffic=heavy,power_posterior_traffic=powers,entropy_strata=entropy_strata,entropy_cutoffs=entropy_cutoffs,extremes=extremes,closest_gates=gates,minimum_gate_log_margin=float(min(abs(np.log(d['M'])).min(),abs(np.log(d['M']/2)).min())),exact_binary_geometry_rows=sum(z['geometry_fallback'] for z in chunks),false_log_groups_corrected=sum(z['falsegroups'] for z in chunks),exact_winner_rows=sum(z['exact_winner_rows'] for z in chunks))


def exact_guard(z,src,lam):
    x=z['receiver'];vols,a=actual_volumes(x,src,lam);groups={}
    for i,v in enumerate(vols):groups.setdefault(v,[]).append(i)
    cum=F(0);M=F(0);winner=None;capture=[];allcapture=[]
    for v,ids in sorted(groups.items()):
        allcapture+=ids;cum+=sum((a[i] for i in ids),F(0));value=cum/v
        if value>M:M=value;winner=v;capture=list(allcapture)
    fg=sum((a[i] for i in capture),F(0));t=[min(F(1),1/v**2) for v in vols]
    # Each positive term rounded outward on a fixed rational grid avoids enormous common denominators.
    Q=10**80;terms=[ti/(4*src['N']) for ti in t]+[ai*ti/8 for ai,ti in zip(a,t)]+[min(F(1),(ai/v)**2)/8 for ai,v in zip(a,vols)]
    qlo=F(sum(t.numerator*Q//t.denominator for t in terms),Q);qhi=F(sum(-(-t.numerator*Q//t.denominator) for t in terms),Q);assert qlo>0
    weak=M>1;band=1<M<=2;load=[F(int(band and i in capture),1)/winner for i in range(src['N'])]
    assert sum((ai*li for ai,li in zip(a,load)),F(0))==(M if band else 0)
    assert weak==z['weak'] and band==z['band'] and sorted(capture)==z['captured_indices']
    y=src['coords']
    # Exact rational active-face selection at the chosen boundary atom.
    boundary=min(groups[winner]);diff=[F(float(xx))-F(float(yy)) for xx,yy in zip(x,y[boundary])];radius=max(map(abs,diff));active=next(k for k,t in enumerate(diff) if abs(t)==radius);sgn=1 if diff[active]>0 else -1
    bary=sum((a[i]*F(float(y[i][active])) for i in capture),F(0))/fg;zeta=src['n']*sgn*(bary-F(float(y[boundary][active])))/radius
    assert zeta>=0
    return dict(receiver=x,M_lambda=str(M),winner_tau=str(winner),winner_fraction=str(fg),captured_indices=sorted(capture),weak=weak,band=band,qcore_enclosure=[str(qlo),str(qhi)],qcore_relative_width=float((qhi-qlo)/qlo),weighted_column_sum=str(sum((ai*li for ai,li in zip(a,load)),F(0))),boundary_atom=boundary,active_coordinate=active,active_sign=sgn,zeta=str(zeta),float_M_relative_discrepancy=abs(z['M_lambda']-float(M))/float(M),float_q_relative_discrepancy=float(max(abs(F(z['qcore'])-qlo),abs(F(z['qcore'])-qhi))/qlo),float_tau_relative_discrepancy=abs(z['winner_tau']-float(winner))/float(winner),float_zeta_absolute_discrepancy=abs(z['zeta']-float(zeta)),active_face_agrees=(boundary==z['boundary_atom'] and active==z['active_coordinate'] and sgn==z['active_sign']),scope='Exact Fraction complete-batch maxima, smallest-volume winner, proposal density and attribution at retained machine-coordinate receiver. No space-integral certificate.')


STRATA=[(1,16),(2,8),(4,16),(8,32)]

def pilot_rows():
    rows=[]
    for j,(n,N) in enumerate(STRATA):
        for k,kind in enumerate(['binary','hierarchical','correlated']):
            src=structured_source(kind,n,N,710101+1009*j+37*k)
            for root in [1,1.5,2]:
                lam=F.from_float(2.**(-n*root));r=winner_probe(src,lam,512,710201+1009*j+37*k,'pilot');r['threshold_log2_root']=root;rows.append(r)
                print('pilot',n,N,kind,root,r['weak_volume']['mean'],r['band_M']['mean'],flush=True)
    return rows


def merit(r):return r['weak_volume']['mean']-.5*r['weak_volume']['sample_SE']

def optimize(pilots):
    traces=[];chosen=[]
    for j,(n,N) in enumerate(STRATA):
        base=max((r for r in pilots if r['source']['n']==n and r['source']['N_requested']==N),key=merit)
        src=base['source'];lam=F(base['lambda_value']);seed=710701+1009*j;rng=np.random.default_rng(710801+1009*j)
        initial=winner_probe(src,lam,512,seed,'search_CRN');cur=initial;trace=[dict(iteration=-1,operation='initial',source_digest=digest(src,lam),weak_mean=initial['weak_volume']['mean'],weak_SE=initial['weak_volume']['sample_SE'],accepted=True)]
        for k in range(16):
            new,th,op=mutate(cur['source'],F(cur['lambda_value']),rng,k);trial=winner_probe(new,th,512,seed,'search_CRN');accept=merit(trial)>merit(cur)
            trace.append(dict(iteration=k,operation=op,source_digest=digest(new,th),weak_mean=trial['weak_volume']['mean'],weak_SE=trial['weak_volume']['sample_SE'],accepted=accept))
            if accept:cur=trial
        traces.append(dict(chain=j,n=n,N_requested=N,receiver_seed=seed,samples_per_evaluation=512,objective='Weak mean minus 0.5 sample SE, heuristic only',initial=initial,selected=cur,trace=trace));chosen.append((initial,cur))
        print('search',j,initial['weak_volume']['mean'],cur['weak_volume']['mean'],cur['weak_volume']['sample_SE'],flush=True)
    return traces,chosen


def lowdim_controls():
    return [pack(list(itertools.product([-1.,1.],repeat=2)),[F(1,4)]*4,'certificate_four_vertices'),pack(list(itertools.product([-.75,-.25,.25,.75],repeat=2)),[F(1,16)]*16,'certificate_product_grid16'),pack([[.75*sx+.125*t,.75*sy] for sx in [-1,1] for sy in [-1,1] for t in [-1,1]],[F(1,8)]*8,'certificate_two_scale8')]


def heldout(chosen):
    rows=[]
    for j,(initial,winner) in enumerate(chosen):
        for role,r in [('initial',initial),('selected',winner)]:
            for k in range(2):
                z=winner_probe(r['source'],F(r['lambda_value']),4096,711001+1009*j+97*(role=='selected')+k,'heldout_search');z.update(chain=j,role=role);rows.append(z)
            print('heldout_search',j,role,rows[-1]['weak_volume']['mean'],rows[-1]['band_M']['mean'],flush=True)
    for n in [2,8,32]:
        for N in [8,32,64]:
            for kind in ['binary','hierarchical']:
                src=structured_source(kind,n,N,712001+1009*n+37*N+(kind=='hierarchical'));lam=F.from_float(2.**(-n*(1.5 if kind=='binary' else 1)))
                for k in range(2):rows.append(winner_probe(src,lam,2048,713001+1009*n+37*N+211*(kind=='hierarchical')+k,'heldout_expanded'))
    for n in [4,16]:
        for N in [8,64]:
            src=structured_source('correlated',n,N,714001+1009*n+37*N)
            for k in range(2):rows.append(winner_probe(src,F(1,2**n),2048,714201+1009*n+37*N+k,'heldout_correlated'))
    for t in RETAINED_R70:
        for role in ['initial','selected']:
            for k in range(2):
                z=winner_probe(t[role],F(t[role+'_H']),2048,715001+1009*t['chain']+97*(role=='selected')+k,'retained_R70');z.update(chain=t['chain'],role=role);rows.append(z)
    for n in [4,8]:
        src=pack(list(itertools.product([-1.,1.],repeat=n)),[F(1)]*(2**n),'full_vertices')
        for root in [F(n+n//2+1,n),F(2)]:
            lam=F.from_float(2.**(-float(n*root)))
            for k in range(2):rows.append(winner_probe(src,lam,2048,716001+1009*n+17*int(lam.denominator.bit_length())+k,'vertices_pressure'))
    for j,src in enumerate(lowdim_controls()):
        for k in range(2):rows.append(winner_probe(src,F(1,4),8192,717001+1009*j+k,'certified_control'))
    for n in [1,2,8,32]:
        src=dict(family='single',n=n,N_requested=1,N_labels=1,N=1,coords=[[.25]*n],weights=['3'],W='3')
        z=winner_probe(src,F(7,3),4096,718001+1009*n,'one_atom_calibration');z.update(analytic_weak_reference=1,analytic_band_M_reference=math.log(2));rows.append(z)
    return rows


def all_guards(rows):
    extremes=[];gates=[]
    for j,r in enumerate(rows):
        if r['stage']=='pilot':continue
        for z in r['extremes']:extremes.append(dict(row=j,guard=exact_guard(z,r['source'],F(r['lambda_value']))))
        for z in r['closest_gates']:gates.append(dict(row=j,threshold=z['threshold'],above=z['above'],guard=exact_guard(z,r['source'],F(r['lambda_value']))))
    return dict(extremes=extremes,gates=gates,scope='Exact rational retained-point checks only; space integrals remain estimates.')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args();start=time.perf_counter();pilots=pilot_rows();traces,chosen=optimize(pilots);rows=pilots if args.pilot else pilots+heldout(chosen);g={} if args.pilot else all_guards(rows)
    result=dict(round=71,status='PILOT' if args.pilot else 'FINAL',numpy_version=np.__version__,scope='Actual positive finite common source; strict weak threshold and true band; all-space receiver integration; complete tied batches and smallest-volume maximizer. Source columns use the same actual winner, not independent inputs. Finite evidence only.',proposal='Half source-uniform global radial + quarter mass-weighted global + quarter mass-weighted individual. Full density at all receivers. Ideal weak score <=4N and band-M score <=8N.',counts=dict(rows=len(rows),receiver_draws=sum(r['samples'] for r in rows),search_evaluations=sum(len(t['trace']) for t in traces),search_draws=sum(len(t['trace'])*512 for t in traces),total_draws=sum(r['samples'] for r in rows)+sum(len(t['trace'])*512 for t in traces),extreme_guards=len(g.get('extremes',[])),gate_guards=len(g.get('gates',[]))),search=traces,rows=rows,guards=g)
    Path(__file__).with_name('winner_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print('runtime',time.perf_counter()-start,flush=True)


if __name__=='__main__':main()
