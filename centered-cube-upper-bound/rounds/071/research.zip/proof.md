# Round 71: actual-winner posterior traffic and paid terminal stopping

2026-10-11. **The general sqrt(n)n^{o(1)} upper bound remains UNPROVED.**
The retained unconditional general benchmark is O(n log n).

## General results and the exact missing interface

For every finite positive atomic input, its actual smallest-volume maximizing
cube defines a common captured posterior pi. In the original global band
lambda<M<=beta lambda, this round proves

    integral M sum_i pi_i 1_(pi_i>=eta) <= log(beta/eta) W,
    integral M sum_i pi_i^(1+t) <= (log beta+1/t) W,   t>0,
    integral_(H_cap<=h) M <= exp(h/(1+h))(1+log beta+h) W.

These estimates charge original source mass once and do not depend on atom
count, smallest weight or source depth. They pay the low captured-entropy
part of the actual winner, not the entire weak level set. The remaining
high-entropy occupation has no proved sqrt(n)n^{o(1)} budget.

A fixed source packet partition permits partial capture and pays geometric
inflation sum_k (1+2d_k/a)^n w_k. One common grid yields an arbitrary-input
finite-window bound, but its n log(s b/a+2) entropy gives only O(n log n)
on the standard physical window. Receiver-dependent regrouping is not free.

The independent probability route proves an actual two-replica Doob
martingale by conditioning on one fixed terminal payoff. On {Mf<=H}, its
first-crossing and bounded-payoff stopped-square budgets are at most HW.
Earlier mean crossings still incur exponential terminal lag. Choosing the
terminal scale by receiver requires an unpaid spatial selector estimate.
A finite periodic indicator construction disproves a subpower budget for
the different proxy that stops at the first positive joint path visit.
It does not disprove mean stopping, complete signed energy, or the weak goal.

## Numerical evidence and independent certification

The direct weak/winner experiment uses 323584 receiver draws across pilot,
search, independent candidate evaluation and enlarged dimension/source-count
tests. Complete arrival ties, original source weights and full-space proposal
density are retained. The independent parent replay exited zero and reproduced
the JSON byte for byte in 14.05 seconds. All 739 retained-point guards passed;
finite-point agreement and sample standard errors do not certify integrals.

A separate integer sweep computes whole planar halo inner/outer areas,
cross-checked against an independent arrangement-cell oracle. It passed
43 guards and 12 enlarged configurations. Three prescribed controls have
weak ratios 1, 17/8-3sqrt(2)/4, and a certified interval around
0.9411585037300683. The second analytic value independently checks the sweep.
Their true band integrals are enclosed using 16,64,256 monotone Riemann panels.
The parent replay was byte-identical in 1.26 seconds. These are finite-instance
certificates, not evidence of a universal extremizing source.

Two embedded exact guards were independently run: posterior/stopping identities
and scalar/winner/grid traffic. The latter uses exact rational geometry and
80/140-digit logarithms; its precision comparison is not outward certification.
The written proofs, not sampled inequalities, establish the general lemmas.
The numerical report retains a single-atom n=32 band fluctuation about 3.18
sample standard errors from log(2), without hiding it or resampling.

## Reproduction and evidence inventory

Extract the five archive members into a temporary directory. Preserve the
archived results before running `python3 -B winner_probe.py`; it writes
winner_results.json beside the script. Tested: Python 3.12.14, NumPy 2.3.5.
Do not pass --pilot for final replay. Parameters, seeds and sources are retained.
The two mathematical guards and halo_certificate.py are embedded below as
Python blocks; extract each to a separate file and run with standard Python.
The halo script writes halo_certificate_results.json; its reference JSON and
replay receipts are embedded in inventory.json. No previous-round runtime
dependency is needed. The LaTeX source is saved as .tex.txt, without compilation
or PDF generation, as requested.

The current 64 canonical skill entrances were reloaded and hash-compared:
277108 bytes, unchanged against Round70, with all 437 direct references present.
The shared claims resolver passed. This confirms file availability only;
applicable theorem hypotheses are checked separately in each proof.



---

# Round71: source-conserving posterior traffic of the actual winner

Status: the logarithmic heavy-share bound, all positive posterior-power bounds, the captured-entropy cutoff, and a fixed-packet finite-window benchmark below are proved for every finite positive atomic source. They do not prove the requested general sqrt(n)n^{o(1)} weak bound. The remaining charge is the actual occupation of diffuse captured posteriors, or the cost of compressing those posteriors by one source partition with controlled geometry. No source-count, minimum-weight or tree-depth factor occurs in the stated paid bounds.

## 1. Actual common winner and occupation

Let mu=sum_i p_i delta_{y_i}, p_i>0, W=sum_i p_i, with coincident sites merged. Cubes Q(x,L) have full side L and volume L^n. Write M(x)=sup_{L>0} mu(Q(x,L))/L^n. Off the finitely many source sites, choose the smallest-side maximizing cube Q*(x), taking the complete arrival batch on its boundary. Set

    L*=side(Q*), V*=(L*)^n, F*=mu(Q*), M=F*/V*,
    Omega={lambda<M<=beta lambda}, beta>1,
    pi_i=p_i 1_{y_i in Q*}/F*.

The selection is Borel: each arrival side 2||x-y_i||_infinity is continuous, its complete captured mass is Borel, and there are finitely many candidate averages and finite tie comparisons. Between consecutive arrivals the average decreases, and beyond the final arrival it tends to zero, so these candidates realize M. Sources form a null receiver set. The same argument works for the restricted-window maximal function M_[a,b], with candidates a and the arrivals in [a,b]. The results below also apply to any Borel cube selection whose actual selected average lies in the stated band; they never replace the original source or its cap set.

The posterior is a probability vector on the captured sources. Thus

    integral_Omega M dx = sum_i p_i integral_Omega 1_{y_i in Q*}/V* dx.       (1)

This is the retained true-winner occupation identity, not a paid budget. The source marginal on the right is weighted by its actual occupation and need not be proportional to p_i. Each integral is finite for this finite source and positive threshold: on incidence V*>=p_i/(beta lambda), while V*<W/lambda implies the band is contained in a bounded union of source-centered cubes. We will dominate restricted parts of this joint measure while charging each p_i only once.

## 2. A logarithmic heavy-posterior traffic bound

For 0<eta<=1 define D_eta(x)=sum_i pi_i(x) 1_{pi_i(x)>=eta}. This is a captured MASS fraction, not the number of heavy sources and not the indicator that a heavy source exists. Then

    integral_Omega M D_eta dx <= [1+log(beta/eta)] W.                       (2)

Proof. Put v_i(x)=(2||x-y_i||_infinity)^n. On a heavy captured incidence, v_i<=V*, F*<=p_i/eta and lambda<F*/V*, so v_i<p_i/(eta lambda). Also

    M pi_i=p_i/V* <= min(beta lambda,p_i/v_i).

Lebesgue measure pushes forward under x->v_i(x) to dv: the sublevel set {v_i<=v} is a cube of volume v. Consequently the entire spatial charge of this one incidence is at most

    integral_0^{p_i/(eta lambda)} min(beta lambda,p_i/v) dv
      =p_i+p_i log(beta/eta).

Sum over i once. The upper envelope may include receivers outside the actual band, but only as a positive majorant with an explicitly paid radial integral. There is no uniform bound asserted for the unrestricted individual occupation column in (1).

The exact residual split is

    integral_Omega M <= [1+log(beta/eta)]W
                       + integral_Omega M(1-D_eta).                       (3)

If the M-weighted average of D_eta is at least kappa>0, (2) pays all this band with constant [1+log(beta/eta)]/kappa. This aggregate coverage requirement is weaker than demanding a large captured source at every receiver. It remains unproved uniformly for arbitrary sources. With eta=n^{-c}, the paid traffic is O(log(n+2))W; the diffuse remainder cannot be discarded.

## 3. Posterior powers and captured entropy

For every t>0,

    integral_Omega M sum_i pi_i^{1+t} dx
      <= [1+log beta+1/t]W.                                                (4)

Proof. For a captured source, V*>=v_i and F*>=p_i give

    pi_i <= min(1,p_i/(M v_i)).

For a fixed radial value v, maximize z min(1,p_i/(zv))^{1+t} over lambda<=z<=beta lambda. The exact scalar envelope is

    beta lambda,                         0<v<=p_i/(beta lambda),
    p_i/v,                               p_i/(beta lambda)<=v<=p_i/lambda,
    lambda^{-t}p_i^{1+t}v^{-1-t},         v>=p_i/lambda.

Its radial integral is p_i[1+log beta+1/t]. Sum the source masses once. This scalar optimization is exact; no claim is made that one actual source attains all pieces of the envelope simultaneously. In particular t cannot be sent to zero for free. The divergence 1/t is the unpaid endpoint of the moment estimate.

Let H_cap(x)=-sum_i pi_i log pi_i, with 0 log0=0. For every h>=0,

    integral_{Omega intersect {H_cap<=h}} M dx
       <= e[2+log beta+h]W.                                                (5)

Indeed Jensen, applied with weights pi_i, gives sum_i pi_i^{1+t}>=exp(-t H_cap). On H_cap<=h take t=1/(1+h); then exp(th)<=e and (4) proves (5). A sharper displayed constant is exp(h/(1+h))[2+log beta+h]. Since M>lambda, the same right side bounds lambda times the volume of this entropy-truncated band.

This pays all actual winners with captured entropy at most sqrt(n) times any prescribed subpower factor, irrespective of total N or the entropy of the whole source prior. Having at most exp(h) captured sites is sufficient for H_cap<=h, but not necessary. This is different from a full-source entropy bound: only the posterior of the ACTUAL common winning cube is used. The event H_cap>h still carries its genuine Lebesgue receiver volume and is not controlled by (5).

For the ORIGINAL GLOBAL maximal function the constants improve further. Its actual band has v_i(x)>=p_i/(beta lambda) for every i, since M(x)>=p_i/v_i(x) by the atom's own centered cube. Thus the first radial interval of the preceding majorants is absent, giving

    integral_Omega M D_eta <=log(beta/eta)W,                               (5a)
    integral_Omega M sum_i pi_i^{1+t} <=[log beta+1/t]W,                    (5b)
    integral_{Omega intersect {H_cap<=h}} M
       <=exp(h/(1+h))[1+log beta+h]W.                                     (5c)

These are actual global-cap consequences, not constants to be transferred freely to a restricted-window cap or packet representative. Equations (2), (4), (5) were stated in the broader selected-cube form so that their packet and local-window extensions remain compatible. The staged actual-source guard checks the stronger (5a)--(5c).

## 4. One fixed source partition, including partial packet capture

Fix positive submeasures mu_k before selecting receivers, with sum_k mu_k<=mu. Let w_k=mu_k(R^n), and suppose supp(mu_k) lies within distance d_k of a fixed representative c_k. Restrict to a measurable part E of the actual band where L*>=a>0. Define captured packet mass a_k(x)=mu_k(Q*(x)) and pi_k(x)=a_k(x)/F*(x). Set

    gamma_k=(1+2d_k/a)^n,  G_mass=sum_k gamma_k w_k.

Then

    integral_E M sum_k pi_k 1_{pi_k>=eta} <=[1+log(beta/eta)]G_mass,          (6)
    integral_E M sum_k pi_k^{1+t} <=[1+log beta+1/t]G_mass.                  (7)

Proof. A positive packet capture contains some source point y in Q*. Therefore 2||x-c_k||_infinity<=L*+2d_k and v_k=(2||x-c_k||_infinity)^n<=gamma_k V*. On pi_k>=eta, F*<=w_k/eta and v_k<gamma_k w_k/(eta lambda). Moreover M pi_k=a_k/V*<=min(beta lambda,gamma_k w_k/v_k). The proof of (2) now applies with p_i replaced by gamma_k w_k. For (7), pi_k<=min(1,gamma_k w_k/(M v_k)), and the same exact scalar optimization applies.

Partial capture is permitted; a packet need not be wholly inside Q*. The original winner and its captured total F* remain unchanged. Packets are chosen from the common input once. With sum_k mu_k=mu, sum_k pi_k=1, and their packet entropy satisfies the analog of (5) with W replaced by G_mass. With a subpartition, one must include the unallocated source as additional packets or retain its unpaid traffic; a subprobability vector alone cannot be substituted into that entropy corollary.

There is no free union over receiver-dependent partitions, scales, tree levels or shifted grids. Such a union must pay its actual mass multiplicity and geometric factors in G_mass. The special case d_k=0 and singleton packets recovers (2)--(5) with G_mass=W.

## 5. A complete general finite-window benchmark

This packet estimate does give a general upper bound, at the retained O(n log n) order on the standard physical window; it therefore specifies what entropy compression would need to improve.

Fix 0<a<=b and s>0. Partition ALL source space into the half-open grid cubes of full side d=a/s, using their centers as representatives. Restrict the maximal operator to L in [a,b]. This is one partition independent of all receivers and thresholds, and every source mass belongs to exactly one cell. Each representative is at distance at most d/2 from its sources, so the sharper common factor is

    gamma=(1+1/s)^n.

A winning cube of side L<=b can meet at most (s b/a+2)^n grid cells: in one coordinate an interval of length L meets no more than L/d+2 half-open cells. Thus its captured packet posterior has support size at most this quantity and entropy at most

    h=n log(s b/a+2).

Use (5) and (7) for the ACTUAL band Omega_[a,b]={lambda<M_[a,b]<=beta lambda}. They give the fully paid bound

    integral_{Omega_[a,b]} M_[a,b] dx
       <=e gamma[2+log beta+n log(s b/a+2)]W.                              (8)

No global cap indicator has been inserted in this restricted-window statement. In particular, for beta=2, the disjoint bands with thresholds 2^j lambda partition {M_[a,b]>lambda}. Their volume costs sum with factors 2^{-j}; hence

    lambda |{M_[a,b]>lambda}|
       <=2e(1+1/s)^n[2+log2+n log(s b/a+2)]W.                              (9)

For s=n the geometric factor is at most e. On b/a=max(n,2), (9) is O(n log(n+2)), uniformly in N, p_min, the positions and geometric depth. This is an actual arbitrary-input finite-window theorem, not a special-source estimate. It does not improve the retained general order. A claim of sqrt(n) based on this construction would have to remove its n log(s b/a+2) captured-entropy expense while keeping a common source partition and a controlled gamma-weighted mass. Shrinking cells to control gamma makes this expense visible; treating it as a dimension-free constant would be false.

The arguments (6)--(9) also work directly for any finite positive Borel measure. Here is the measurable-selector and band-loss justification. Enumerate D={a,b} union (Q intersect (a,b)). The averages at its fixed sides are Borel in x. For any L in [a,b), approach L from above by sides in D; continuity from above of the finite measure on the decreasing closed cubes implies that their averages converge to the average at L. The side b is explicitly included, so sup_D A_L=M_[a,b]. For 0<epsilon<1, on M_[a,b]>0 choose the first enumerated L with A_L>(1-epsilon)M_[a,b]; this is a Borel selected cube. On the original band E={lambda<M_[a,b]<=beta lambda}, its selected average belongs to the band with lambda'=(1-epsilon)lambda and beta'=beta/(1-epsilon). The partial-packet proof applies on E, all selected sides remain in [a,b], and M_[a,b]<=A_L/(1-epsilon). Its bound is therefore (1-epsilon)^{-1}e gamma[2+log(beta/(1-epsilon))+h]W. Let epsilon decrease to zero to obtain exactly (8), then the disjoint band decomposition gives (9). A bounded cube meets finitely many grid cells even for an unbounded source; the sum of their source masses is still W, so Tonelli pays the countable grid once. The executable exact checks remain in the finite-atomic setting. No transfer of global cap ENERGY by approximation is used or claimed.

## 6. Paid and unpaid parts of the direct weak target

The retained single-source winner and strict-majority winner branches already have lambda-volume budgets W each. Within the remaining true-winner band (at least two distinct captured sites, F*<=W/2), (2)--(5) apply without changing its source. They pay its heavy posterior traffic and its low-entropy receivers. They do not pay the high-entropy remainder.

For example, set beta=2 and h_n=sqrt(n) ell_n with ell_n=n^{o(1)}. Let R_n(lambda,mu) denote the ACTUAL residual-band occupation restricted to H_cap>h_n. If a general bound R_n<=sqrt(n)n^{o(1)}W is proved, then (5), the already paid two branches and the retained dyadic threshold decomposition close the requested weak order. This is a precise remaining interface, not an assertion that the new moment estimate controls R_n. Alternatively, one fixed input partition with G_mass<=n^{o(1)}W and M-weighted low packet-entropy coverage could pay it; the finite-window grid in Section 5 reaches only the existing O(n log n) order.

Prior-note audit: the barycenter divergence/signed winner-switch route proposed early in this round is already in the Round14--16 notes and is not counted as a new result here. The fixed-packet dominance extension (20261007) paid whole receivers with an eta^{-1} charge, whereas (2) pays captured mass traffic with a logarithmic charge. The retained conditional collision notes already paid a second posterior moment in a finite window; (4) records the exact band-optimized envelope for every positive exponent and the resulting captured-entropy cutoff. None of these moment bounds controls the exponent-zero total occupation automatically.

## 7. Current skills and numerical audit boundary

Read current canonical E01 occupation-measure-flow-LP, M04 measurable-supremum-selection, D01 Kantorovich-duality and L03 rational-and-interval-certificates entrances, methods, cube interfaces and provenance indices from disk. E01/M04/D01 entry-method-interface files were read again after the latest user reload request; L03 was freshly read immediately before that request. Their applicable requirements are enforced: the selector is proved by finite Borel comparisons; the positive joint occupation retains its true source and receiver marginals; positive flow/transport terminology does not import a Markov generator, a realizability theorem, a stopping estimate or transport duality. L03 does not certify a generic floating interval API; this guard uses exact Fraction algebra and labels Decimal replay only as a precision check. No external theorem from a provenance index is used. These current files introduce no applicability change relative to the retained earlier-round audit boundaries; a byte/hash check is not mathematical certification.

Current SHA-256 values (entry / method / cube-interface / provenance):

    E01 0a5f11101bee3a6b8c0fbb960b5959e4cf78cfb6f011ac5d15f6add087286896
        ee83644b0338db4deefd846f9a39147cefbd90a4556f4308d3608ff121b0fce6
        96197f4dbe1189b5b6f3f7c3024168c72566debd801ee795509b32ee7b03eedf
        9cac41e7ee8eb156f900d157da7a366e58a800b97ac4b50246b0b24e1b9a52a1
    M04 94d345413090478f55cf675d0db8127ae997d44aba919888f958306dfff5e293
        db1b8ce51951359a9f38abb019f70e965184bed66efdd3e54af2d18f06c69552
        abf544fe9c4d8fa5d928f21f2f6eab1b1c2cfd81313b7828f8b271e79b46696a
        dc2c43cb4a28d9981cacc5834e51d6acd182b797c44ff99dad9816af26185183
    D01 b22e62feedb13eaf91ab66f5f056403de1375e76d2e8ae5b6dacb114d3e9a3ac
        053b2626b821ac75a15364dadbcb89c4620065393b4113453556d98920874be1
        222795f337ee39c75cdfc9190bab674464cbb7a2964e8579c3cf9cf201d24067
        82aa1e8aad29f042dd2c6782a11d8bb0064bc17f83396d4fc3965639a05ac569
    L03 0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c
        9a76bd1959a2b623dbe7951684ce55428bbd9e9ddaa4a3516688ca785b31508c
        764b98f99801a38b35ebeab5b3a934d5f8b31842ad3f94ff68da3b4844fe64a6
        ced0d588ce52a592b3142a8b5d4f09e37d3ebb9f6a922e1fc76e8e089b9ad5ab

The embedded guard below checks exact rational scalar envelopes, complete actual one-dimensional winners and band endpoints, independently enumerated subset maxima, exact grid-incidence algebra, and 80/140-digit evaluations of the actual band integrals. Decimal replay is a precision check, not outward interval certification. The proofs above supply the uniform inequalities; no finite sample is used to certify a supremum over sources.

```python
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import combinations, product
import json

def dec(x):
    x=F(x)
    return D(x.numerator)/D(x.denominator)

def winner(x,ys,ps):
    batches={}
    for i,y in enumerate(ys):batches.setdefault(abs(x-y),[]).append(i)
    mass=F(0);best=None;capture=[]
    for r,ids in sorted(batches.items()):
        mass+=sum((ps[i] for i in ids),F(0));capture+=ids
        if not r:continue
        val=mass/(2*r)
        if best is None or val>best[0]:
            best=(val,r,mass,tuple(sorted(capture)))
    return best

def exact_cells(ys,ps,lam):
    W=sum(ps,F(0));lo=min(ys)-W/(2*lam);hi=max(ys)+W/(2*lam)
    cuts={lo,hi,*ys}
    cuts.update((a+b)/2 for a,b in combinations(ys,2))
    coarse=sorted(c for c in cuts if lo<=c<=hi)
    for a,b in zip(coarse,coarse[1:]):
        x=(a+b)/2;ids=sorted(range(len(ys)),key=lambda i:abs(x-ys[i]))
        candidates=[];mass=F(0)
        for i in ids:
            mass+=ps[i];s=1 if x>ys[i] else -1
            candidates.append((mass,s,-s*ys[i]))
        for m,s,z in candidates:
            for level in [lam,2*lam]:
                root=(m/(2*level)-z)/s
                if a<root<b:cuts.add(root)
        for (m,s,z),(v,t,w) in combinations(candidates,2):
            den=m*t-v*s
            if den:
                root=(v*z-m*w)/den
                if a<root<b:cuts.add(root)
    cells=[];cuts=sorted(cuts)
    for a,b in zip(cuts,cuts[1:]):
        x=(a+b)/2;val,r,mass,ids=winner(x,ys,ps)
        # Independently enumerate every captured subset for small real sources.
        if len(ys)<=6:
            oracle=max(sum((ps[i] for i in ids2),F(0))/(2*max(abs(x-ys[i]) for i in ids2))
                       for k in range(1,len(ys)+1) for ids2 in combinations(range(len(ys)),k))
            assert val==oracle
        if lam<val<=2*lam:
            edge=min(i for i in ids if abs(x-ys[i])==r)
            s=1 if x>ys[edge] else -1
            # Exact band/winner invariance at two additional rational interior points.
            for q in [(2*a+b)/3,(a+2*b)/3]:
                v2,r2,m2,i2=winner(q,ys,ps)
                assert lam<v2<=2*lam and i2==ids and m2==mass
            cells.append((a,b,s,-s*ys[edge],mass,tuple(ps[i]/mass for i in ids)))
    return cells

def integrals(cells,precision):
    with localcontext() as ctx:
        ctx.prec=precision
        etas=[F(1),F(1,2),F(1,4),F(1,16)]
        powers=[F(2),F(3),F(6,5)]
        hs=[D(0),D('0.5'),D(1),D(2)]
        heavy=[D(0)]*len(etas);mom=[D(0)]*len(powers);ent=[D(0)]*len(hs)
        total=D(0)
        for a,b,s,z,mass,pis in cells:
            integral=dec(mass)/(2*s)*(dec((s*b+z)/(s*a+z))).ln()
            assert integral>0;total+=integral
            pd=[dec(p) for p in pis];entropy=-sum((p*p.ln() for p in pd),D(0))
            for j,eta in enumerate(etas):
                heavy[j]+=integral*dec(sum((p for p in pis if p>=eta),F(0)))
            for j,alpha in enumerate(powers):
                mom[j]+=integral*sum(((dec(alpha)*p.ln()).exp() for p in pd),D(0))
            for j,h in enumerate(hs):
                if entropy<=h:ent[j]+=integral
        return total,heavy,mom,ent

def main():
    scalar=0;grid=0;geometry=0
    # Stage 1: exact scalar optimizer and heavy-incidence envelope, including endpoints.
    for p,lam,v,z,alpha in product([F(1,7),F(1),F(5,2)],
                                  [F(1,3),F(1),F(3)],
                                  [F(1,20),F(1,3),F(1),F(9)],
                                  [F(1),F(3,2),F(2)], [2,3]):
        M=z*lam
        actual=M*min(F(1),p/(M*v))**alpha
        if v<=p/(2*lam):bound=2*lam
        elif v<=p/lam:bound=p/v
        else:bound=lam**(1-alpha)*p**alpha/v**alpha
        assert actual<=bound;scalar+=1
        for eta in [F(1),F(1,2),F(1,4)]:
            share=min(F(1),p/(M*v))
            if share>=eta:
                assert v<=p/(eta*lam)
                assert M*share<=min(2*lam,p/v)
            scalar+=1
    # Stage 2: source-to-grid-center volume inflation and incidence count, rational.
    for n,s,B in product([1,2,3],[1,2,4],[F(1),F(2),F(5,2)]):
        a=F(1);d=a/s
        for center,L in product([F(-7,6),F(0),F(5,8)],[a,(a+B)/2,B]):
            left=center-L/2;right=center+L/2
            # Closed winner endpoints may hit the next half-open cell.
            first=left//d;last=right//d
            count=last-first+1
            assert count<=L/d+2<=s*B+2
            for j in range(first,last+1):
                celllo=j*d;cellhi=(j+1)*d;c=(j+F(1,2))*d
                if max(left,celllo)<=min(right,cellhi):
                    assert 2*abs(center-c)<=L+d
                    assert (2*abs(center-c))**n <= (1+F(1,s))**n*L**n
                    grid+=1
    # Stage 3: exact winner and band geometry for distinct actual atomic sources.
    sources=[([F(0)],[F(1)]),
             ([F(-1),F(1)],[F(1,2),F(1,2)]),
             ([F(-1),F(0),F(3,2)],[F(1,7),F(2,7),F(4,7)]),
             ([F(j,4) for j in range(5)],[F(1,5)]*5),
             ([F(-2),F(-1,8),F(1,16),F(1),F(3)],[F(1,31),F(2,31),F(4,31),F(8,31),F(16,31)]),
             ([F(2*j+1,16) for j in range(8)],[F(1,8)]*8)]
    records=[];checks=0
    for ys,ps in sources:
      for lam in [F(1,16),F(1,4),F(1),F(4)]:
        cells=exact_cells(ys,ps,lam);geometry+=len(cells)
        vals=[integrals(cells,p) for p in [80,140]]
        with localcontext() as ctx:
            ctx.prec=140;W=dec(sum(ps,F(0)));total,heavy,mom,ent=vals[-1]
            flat0=[vals[0][0],*vals[0][1],*vals[0][2],*vals[0][3]]
            flat1=[vals[1][0],*vals[1][1],*vals[1][2],*vals[1][3]]
            assert max(abs(x-y) for x,y in zip(flat0,flat1))<D('1e-70')
            for eta,val in zip([F(1),F(1,2),F(1,4),F(1,16)],heavy):
                assert val<=dec(2/eta).ln()*W+D('1e-100');checks+=1
            for alpha,val in zip([F(2),F(3),F(6,5)],mom):
                assert val<=(D(2).ln()+1/(dec(alpha)-1))*W+D('1e-100');checks+=1
            for h,val in zip([D(0),D('0.5'),D(1),D(2)],ent):
                bound=(h/(1+h)).exp()*(1+D(2).ln()+h)*W
                assert val<=bound+D('1e-100');checks+=1
            records.append(dict(N=len(ys),threshold=str(lam),cells=len(cells),band_occupation=str(total),alpha2=str(mom[0])))
    print(json.dumps(dict(exact_scalar_checks=scalar,exact_grid_checks=grid,exact_band_cells=geometry,
                         actual_integral_inequality_checks=checks,precision_pair=[80,140],
                         precision_tolerance='1e-70',cases=len(records),records=records),sort_keys=True))

if __name__=='__main__':main()
```

Executed the embedded guard twice, including once after the global-cap sharpening: exit 0. The final run passed 864 exact scalar checks, 1047 exact grid checks, 321 exact actual-band cells in 24 source/threshold cases, and 264 inequalities for their true band integrals. The 80/140-digit results agree to better than 1e-70. The one-atom band occupation independently returns W log2. The embedded-code SHA-256, without the surrounding Markdown fences or an added terminal newline, is d35c188737dca6c65fa0ec34d889b371de951056f4e9fdea9c744cd2c2ce26be. The separate English TeX deliverable is an ASCII fragment; it was not compiled.


---

# Round71: a paid terminal-posterior stopping lemma and its transfer loss

The central positive result is a genuine source-mass-conserving two-replica stopping budget. Fix ONE terminal volume time v. The product of the two terminal-payoff Doob martingales has integrated initial mass at most HW on the ORIGINAL cap. Its true threshold first crossing is paid uniformly, and for 0<=f<=1 its stopped squared increments are paid by HW as well. This is valid for arbitrary sources in the stated function class and has no dimension, source-count, minimum-mass, grid-depth, or horizon factor.

The transfer to first crossing of the original deterministic mean profile still loses exponentially in volume-time horizon. Selecting the terminal scale adaptively would destroy the presently proved conserved mass budget unless a separate selector estimate is paid. A genuinely stopped positive-current-payoff proxy is also shown to have exponential dimension pressure at the retained indicator threshold. These are distinct processes and stopping rules. The desired general weak upper and indicator cap-energy estimate remain unproved.

## 1. Fixed terminal posterior: exact general construction

Use the proved whole-point shell-reset process from Round70, with volume time u=n log L. Its physical state is Y_u, its marginal is uniform on the cube Q_u of volume e^u, and
\[
 K_{u,v}(y,dz)=e^{u-v}\delta_y(dz)
                  +e^{-v}1_{Q_v\setminus Q_u}(z)\,dz .
\]
Fix a finite grid u_0<...<u_m=v, two independent complete copies of that process, and the joint natural history through each grid time. Initial positions are uniform on Q_{u_0}; all future clocks and marks are independent of those initial positions. Let f>=0 be in L1, W=||f||_1, and write a_u(x)=A_u f(x), F_u^{(j)}=f(x+Y_u^{(j)}).

The actual terminal-payoff conditional expectation is
\[
 m_i^{(j)}(x)=E[F_v^{(j)}\mid {\cal F}_{u_i}^{(j)}]
  =e^{u_i-v}F_{u_i}^{(j)}+
                  a_v-e^{u_i-v}a_{u_i}.                 \tag{1}
\]
The deterministic offset is NONNEGATIVE by nested-cube mass monotonicity. Conditioning independent future clocks shows
\[
 M_i(x)=m_i^{(1)}m_i^{(2)}
   =E[F_v^{(1)}F_v^{(2)}\mid {\cal F}_{u_i}^{(1,2)}].     \tag{2}
\]
This is a nonnegative martingale. Independence is between replicas, not between source coordinates or source pieces.

For almost every x on the ORIGINAL cap G_H={Mf<=H}, terminal product integrability follows from
\[
 E[F_v^{(1)}F_v^{(2)}]=a_v(x)^2\le H a_v(x).
\]
Integrating in the SAME receiver Lebesgue measure gives
\[
 \int_{G_H}E M_i(x)\,dx=\int_{G_H}a_v(x)^2\,dx\le HW.     \tag{3}
\]
No source-prior measure is substituted. Pointwise formulas and finite-grid conditioning are legitimate for L1 functions at almost every receiver and sampled state; atomic measures are not ordinary point payoffs.

## 2. Uniform true-stopping payment

For r>0 define sigma_r as the first grid index with M_i>=r, or m if there is no crossing; separately retain the event C_r that a crossing actually occurred. This is a stopping time in the JOINT clock/history filtration. Finite discrete optional sampling is elementary: expanding the stopped martingale increments gives E M_sigma=E M_0=a_v^2. Thus
\[
 r\int_{G_H}P(C_r)\,dx
       \le\int_{G_H}E M_{\sigma_r}\,dx\le HW.             \tag{4}
\]
This holds for arbitrary nonnegative L1 sources on every finite grid. There is no n,N,p_min,T, or depth factor.

If 0<=f<=1, then 0<=M_i<=1. For ANY joint-history stopping index sigma<=m, conditional orthogonality of martingale increments gives
\[
 \begin{split}
 \int_{G_H}E\sum_{i=1}^m
       1_{\{\sigma\ge i\}}(M_i-M_{i-1})^2\,dx
 &=\int_{G_H}(E M_\sigma^2-E M_0^2)\,dx\\
 &\le\int_{G_H}E M_\sigma\,dx
 \le HW.                                                \tag{5}
 \end{split}
\]
The indicator {sigma>=i} is measurable at time i-1, so the stopped increments really are martingale differences. Initial square mass is retained, not thrown away in an equality. For f<=B the corresponding bound is B^2 HW; for an unbounded L1 source, no square-integrability assertion is made.

For finite indicator unions the explicit posterior process is right-continuous on finite intervals, but this note needs only finite grids and imports no continuous-time Snell theorem. Deterministic mean crossing indices, once the receiver x and source are fixed, are initial-information-measurable indices; they are NOT crossings of the random path payoff or of M. They can be used as stopping indices, but cannot be identified with sigma_r.

## 3. Threshold-selective detection and the exact horizon loss

Take an indicator f=1_V, a finite grid in [v-T,v], lambda>0, R>=1, and the ORIGINAL cap G_{R lambda}. Let
\[
 E=\{x\in G_{R\lambda}:\max_i a_{u_i}(x)>\lambda\}.
\]
For each x in E choose its earliest deterministic mean crossing i(x). This is fixed at time zero in the clock probability space. At that index the two current indicator payoffs both equal one with probability a_{u_i}^2>lambda^2. On that event, (1) and offset positivity imply
\[
 M_{i(x)}\ge e^{2(u_{i(x)}-v)}\ge e^{-2T}.
\]
Consequently
\[
 \lambda^2 |E|
 \le \int_{G_{R\lambda}}P(\max_iM_i\ge e^{-2T})\,dx
 \le e^{2T}R\lambda W,
\]
and
\[
 \lambda|E|\le R e^{2T}W.                               \tag{6}
\]
This is a valid general indicator finite-window consequence, but exponential in VOLUME-TIME horizon T=n log(L_max/L_min). It is not a target weak estimate. Indeed plain nested-cube endpoint domination already gives the better benchmark lambda|{max_i a_i>lambda}|<=e^T W. The positive result here is the paid posterior martingale construction (4)--(5), not an improved weak constant.

For general L1 f, the posterior lemma still holds, but a large mean does not ensure a prescribed probability of both point payoffs being large. Therefore (6)'s detection step is not asserted for unbounded f.

A terminal matched to each mean crossing (for example v(x)=u_{i(x)}+1) would eliminate the factor e^{2T}. The source budget then becomes
\[
 \int_{G_H} [A_{v(x)}f(x)]^2\,dx,
\]
and (3) no longer applies because the terminal scale is receiver-dependent. Paying a family of such posteriors without one independent HW charge per terminal/window is exactly the missing selector/interface. This note neither presumes its boundedness nor asserts it equivalent to the desired energy. The fixed-terminal martingales do NOT make u->a_u(x) a martingale, and their expected increments are zero rather than the original mean increments D a.

The terminal-age attenuation is exact even with one source component, whose source-label posterior entropy is zero. If the entire source is captured by Q_u and all later capture cubes, then a_v=e^{u-v}a_u and the offset in (1) vanishes. Thus m_u=e^{u-v}F_u and M_u=e^{2(u-v)}F_u^{(1)}F_u^{(2)} exactly. Source-posterior entropy bounds may support a separate adaptive-selector argument, but do not by themselves remove this terminal-age coefficient. This does not contradict or negate the separately developed aggregate entropy-traffic bound.

## 4. Truly stopped current-payoff hits: exact killing flow

For comparison, define B_i=F_{u_i}^{(1)}F_{u_i}^{(2)} for an indicator and stop at the first B_i=1. This is a different, genuine stopping time in the same joint natural filtration. It stops a positive current-payoff hit, not a deterministic profile crossing and not the terminal posterior.

In continuous volume time let s_u(x)=S_u1_V(x), the cone-surface source occupancy. With joint states 00, exactly-one, and absorbed-at-first-11, the survival probabilities satisfy, on finite windows,
\[
 r_0'=(1-s_u)r_1-2s_u r_0,\quad
 r_1'=2s_u r_0-r_1,\quad
 k'=s_u r_1.                                            \tag{7}
\]
Initial first-hit mass is a_{u_0}^2, not zero unless separately chosen. Formula (7) follows by the actual two independent rate-one clocks: 00 enters exactly-one at rate 2s, exactly-one leaves to00 at rate1-s or is killed at rate s. Self-holding events do not change these probabilities. Total mass r_0+r_1+k is conserved.

For a generic bounded joint-history stopping time the product payoff has the signed optional-compensation identity
\[
 E B_\sigma=E B_{u_0}
   +E\int_{u_0}^{\sigma}
     [s_u(F_u^{(1)}+F_u^{(2)})-2B_u]\,du.                \tag{8}
\]
At FIRST positive joint visit, B is zero before absorption, leaving a positive hazard. The original mean cap cannot be substituted for these survival-conditioned state probabilities. Formula (8) is finite-window bounded compensation; no all-time signed interchange is assumed.

## 5. Quantitative first-hit obstruction with explicit finite depth

For n>=1 set P=16n^2, rho=(4n^2)^{-n}, and let N be a sufficiently large multiple of four. Put
\[
 J_N=\bigcup_{j=0}^{N-1}[jP-1/2,jP+1/2],\quad
 V_N=J_N^n,\quad W=N^n,
\]
\[
 X_N=\left(\bigcup_{j=N/4}^{3N/4-1}
             [jP+P/4,jP+3P/4]\right)^n,\quad
 |X_N|=(NP/4)^n .
\]
The source is a finite union of unit cubes in a translated binary grid. Its product structure is used only for this falsification, not as an assumption in the positive lemmas.

The one-dimensional infinite periodic indicator has discrepancy at most one on every interval. For every coordinate of x in X_N, a nonzero capture requires L>=P/2-1; hence the coordinate average is at most
\[
 g_P=1/P+1/(P/2-1)<4/P.
\]
A centered-cube average factors for this particular source. Therefore
\[
 M1_{V_N}(x)\le g_P^n<(4/P)^n=\rho.                     \tag{9}
\]
This verifies the ORIGINAL strict global cap for every receiver in X_N. Its deterministic mean never crosses rho.

Take L_0=16nP and volume-time samples L_k=L_0 exp(k/n), k=0,...,K, with all L_k<=NP/24. All their capture cubes are inside the finite periodic region. If d=1/P, periodic discrepancy gives for every receiver and every such L
\[
 (15/16)d^n\le A_L1_{V_N}\le(16/15)d^n.                 \tag{10}
\]
Indeed each coordinate average is between d(1-P/L) and d(1+P/L); P/L<=1/(16n), Bernoulli gives the lower bound, and the geometric-series upper bound gives (1+1/(16n))^n<=16/15.

For an adjacent VOLUME step the shell average is
\[
 b_k={e a_{k+1}-a_k\over e-1}\ge d^n/2.                 \tag{11}
\]
Use (10), e>2, and
2*(15/16)-16/15=97/120>1/2.
The reset probability c=1-e^{-1}>1/2. Conditional on ANY earlier joint history, both replicas freshly resetting and drawing a source point at the next sampled endpoint has probability at least
\[
 \epsilon={d^{2n}\over16}.                              \tag{12}
\]
These events need not be independent across samples; their uniform conditional lower bound suffices:
\[
 P(\hbox{no positive joint sampled hit by }K)
        \le(1-\epsilon)^K.
\]
Choose the explicit integer K=16P^{2n}=1/epsilon and any multiple-of-four N with
\[
 N\ge384n\exp(K/n).
\]
Then L_K<=NP/24 and (1-1/K)^K<=1/2, by the reciprocal Bernoulli bound. Thus the FIRST-hit probability is at least one half on every receiver in X_N, while its deterministic mean never crosses rho. Its Lebesgue mass satisfies
\[
 {\int_{X_N}P(\hbox{first joint hit by }K)\,dx\over\rho W}
      \ge {1\over2}(16n^4)^n.                           \tag{13}
\]
This explicitly refutes a subpower source-mass payment for this stopped positive-visit proxy. The depth and required array size are enormous but finite and are exposed, not hidden in an independence assumption or an asymptotic numerical claim. It does not refute stopping ONLY at an actual deterministic mean crossing, the paid terminal-posterior lemma, or the desired cap energy.

## 6. Current skills and guard scope

Current E04/I02/J02/J04 entries, methods, cube interfaces and provenance were reread from the installed disk paths. E04 supports the finite-discrete stopping audit only; no continuous Snell or randomized-stopping equivalence was used. I02 requires the stated natural filtration, actual conditional projections and integrability. J02 is used to distinguish absorbed first visits from ordinary resets and retain killed/initial mass. J04 checks finite-window predictable compensation; its general stochastic-Fubini interface is not imported.

Entry SHA256:
- E04: 7b8c0a03b4e78520f5dccf3f9d661d48c729c241800bbfd8c01b4a4a4d41fbbe
- I02: cdf12aaf5336cc68f33dfe5a16b922932de4c5d0679c4d61f5ad68c3fecbbabe
- J02: 14985825b1c906b3eed529c023bc216d5b7bbed037462b4886121de457b8639b
- J04: 99ac118256ab02b75adb01ea1c9c16d74655b16b14dca24c57e80606f5c68954

The embedded standard-library guard enumerates the actual four-state replica Markov chain for multi-stage arbitrary overlapping rectangle indicators in dimensions 1,2,3,4. Their capture profiles are computed from exact rectangle intersections, not invented Bernoulli coefficients. It checks posterior martingale conditional means, true threshold stopping, conserved terminal mass, stopped squared increments and the finite-grid mean-crossing detection. A second family audits actual periodic cube captures, strict cap envelopes, shell lower bounds, and exact dimension-pressure constants. The enormous depth K in (13) is proved algebraically; finite guards are not claimed to simulate that depth or its gigantic N.

Actual replay on 2026-10-11: PASS. There are 64 actual source profiles, 1024 conditional posterior state-mean checks, 256 stopped-martingale tests (each also checks conserved mean and square payment), 109 actual mean-crossing detections, 16 exact one-component terminal-lag checks, 16 periodic-source geometry checks, 30 shell-floor/fresh-hit checks, and eight exact dimension-pressure checks at n=1,2,3,4,8,16,32,64. All arithmetic is Fraction/integer; no claim to enumerate all source geometries or run the gigantic theoretical first-hit depth is made.

```python
from fractions import Fraction as F
from itertools import product
import random,json

states=list(product((0,1),repeat=2))
def overlap(a,b):
    return max(F(0),min(a[1],b[1])-max(a[0],b[0]))
def capture_union(rects,x,L):
    ans=F(0);n=len(x)
    for mask in range(1,1<<len(rects)):
        rs=[r for j,r in enumerate(rects) if (mask>>j)&1]
        volume=F(1)
        for i in range(n):
            cell=(max(r[i][0] for r in rs),min(r[i][1] for r in rs))
            volume*=overlap(cell,(x[i]-L/2,x[i]+L/2))
        ans+=volume if mask.bit_count()%2 else -volume
    return ans/L**n
def bernoulli_pair(a):
    return {s:(a if s[0] else 1-a)*(a if s[1] else 1-a) for s in states}
def pair_transition(old,new,beta,b):
    out=F(1)
    for i in (0,1):
        prob=beta*old[i]+(1-beta)*b
        out*=prob if new[i] else 1-prob
    return out
def posterior(a,Ls,n,i,state):
    beta=(Ls[i]/Ls[-1])**n
    return (a[-1]-beta*a[i]+beta*state[0])*\
           (a[-1]-beta*a[i]+beta*state[1])
def stopped_test(a,Ls,n,r):
    m=len(a)-1
    initial=bernoulli_pair(a[0])
    active={};hit=F(0);ev=F(0);esq=F(0);qv=F(0)
    initial_sq=sum(p*posterior(a,Ls,n,0,s)**2 for s,p in initial.items())
    for s,p in initial.items():
        value=posterior(a,Ls,n,0,s)
        if value>=r:
            hit+=p;ev+=p*value;esq+=p*value**2
        else:active[s]=p
    for i in range(1,m+1):
        beta=(Ls[i-1]/Ls[i])**n
        b=(a[i]-beta*a[i-1])/(1-beta)
        nxt={s:F(0) for s in states}
        for old,p in active.items():
            oldvalue=posterior(a,Ls,n,i-1,old)
            conditional=F(0)
            for new in states:
                weight=pair_transition(old,new,beta,b)
                value=posterior(a,Ls,n,i,new)
                conditional+=weight*value
                qv+=p*weight*(value-oldvalue)**2
                prob=p*weight
                if value>=r:
                    hit+=prob;ev+=prob*value;esq+=prob*value**2
                elif i==m:
                    ev+=prob*value;esq+=prob*value**2
                else:
                    nxt[new]+=prob
            assert conditional==oldvalue
        active=nxt
    assert ev==a[-1]**2
    assert qv==esq-initial_sq
    assert qv<=a[-1]**2
    assert r*hit<=a[-1]**2
    return hit

def primitive(t,P):
    z=t+F(1,2);k=z//P
    return F(k)+min(z-k*P,F(1))
def interval_mass(left,right,N,P):
    left=max(left,-F(1,2));right=min(right,(N-1)*P+F(1,2))
    return F(0) if left>=right else primitive(right,P)-primitive(left,P)
def periodic_capture(x,L,N,P):
    ans=F(1)
    for xi in x:
        ans*=interval_mass(xi-L/2,xi+L/2,N,P)/L
    return ans

def stopped_guards():
    rng=random.Random(710602)
    counts={"source_profiles":0,"posterior_state_means":0,
            "true_stopping":0,"mean_detection":0,"periodic_geometry":0,
            "shell_floor":0,"pressure":0,"exact_terminal_lag":0}
    for n in (1,2,3,4):
        for trial in range(16):
            rects=[]
            for j in range(3):
                rr=[]
                for unused in range(n):
                    lo=F(rng.randrange(-8,3),4)
                    rr.append((lo,lo+F(rng.randrange(2,9),4)))
                rects.append(rr)
            x=[F(rng.randrange(-4,5),4) for unused in range(n)]
            Ls=[F(1),F(3,2),F(2),F(3),F(4)]
            a=[capture_union(rects,x,L) for L in Ls]
            counts["source_profiles"]+=1
            for i in range(1,len(a)):
                beta=(Ls[i-1]/Ls[i])**n
                b=(a[i]-beta*a[i-1])/(1-beta)
                assert 0<=b<=1
                for old in states:
                    conditional=sum(pair_transition(old,new,beta,b)*
                                    posterior(a,Ls,n,i,new) for new in states)
                    assert conditional==posterior(a,Ls,n,i-1,old)
                    counts["posterior_state_means"]+=1
            for r in (F(1,16),F(1,4),F(1,2),F(3,4)):
                stopped_test(a,Ls,n,r)
                counts["true_stopping"]+=1
            for lam in (F(1,16),F(1,4),F(1,2)):
                crossings=[i for i,ai in enumerate(a) if ai>lam]
                if crossings:
                    i=crossings[0]
                    threshold=(Ls[0]/Ls[-1])**(2*n)
                    # Both present payoffs one detects a true posterior crossing.
                    assert posterior(a,Ls,n,i,(1,1))>=threshold
                    assert a[i]**2>lam**2
                    counts["mean_detection"]+=1
    # Actual one-interval source: x=2, full capture at side 5.
    # Its global maximal value is 1/5<delta_1, and posterior entropy is zero.
    for Q in (F(2),F(4),F(16),F(256)):
        a=[F(1,5),F(1,5)/Q]
        Ls=[F(5),F(5)*Q]
        beta=1/Q
        for state in states:
            assert posterior(a,Ls,1,0,state)==beta**2*state[0]*state[1]
            counts["exact_terminal_lag"]+=1
    for n in (1,2,3,4,8,16,32,64):
        P=F(16*n*n);rho=F(1,(4*n*n)**n);d=1/P
        N=1536*n
        x=[(N//4+rng.randrange(0,N//2))*P+
           rng.choice((F(1,4),F(1,2),F(3,4)))*P for unused in range(n)]
        g=1/P+1/(P/2-1)
        assert g**n<rho
        assert F(N)*P/4==F(N//2)*P/2
        L0=16*n*P
        for L in (L0,2*L0):
            a=periodic_capture(x,L,N,P)
            assert F(15,16)*d**n<=a<=F(16,15)*d**n
            counts["periodic_geometry"]+=1
            for q in (F(2),F(3,2)) if n>=2 else (F(2),):
                assert q**n>=2
                new=periodic_capture(x,q*L,N,P)
                b=(q**n*new-a)/(q**n-1)
                assert b>=d**n/2
                c=1-q**(-n)
                assert (c*b)**2>=d**(2*n)/16
                counts["shell_floor"]+=1
        K=16*int(P)**(2*n)
        epsilon=d**(2*n)/16
        assert K*epsilon==1
        pressure=(P/4)**n/(2*rho)
        assert pressure==F(1,2)*(16*n**4)**n
        counts["pressure"]+=1
    return {"passed":True,"checks":counts,
            "scope":"finite exact audits; no simulation at the enormous theoretical K"}
if __name__=="__main__":
    print(json.dumps(stopped_guards(),sort_keys=True,separators=(",",":")))
```


---

# Round71: exact whole-halo certificates for finite planar atomic inputs

Status: the finite-source geometry representation and rational inner/outer volume algorithm are proved. The recorded computations certify entire receiver-space weak ratios for their particular sources. They do not prove a dimension-uniform upper bound or an optimal finite-source configuration. Their role is to audit the direct-winner numerical strategy independently of Monte Carlo pointwise guards.

## Exact geometric representation

Let mu=sum_i (w_i/B) delta_{y_i} on R^2, with positive integer w_i and B=sum_i w_i, so W=1. Coordinates y_i are rational and lambda>0 is rational. Coincident labelled sites are allowed: their integer weights simply add. Define

    r_k=(1/2)sqrt(k/(B lambda)),  1<=k<=B,
    D_k(x)=sum_i w_i 1_{||x-y_i||_infinity<r_k}.

Then, with OPEN squares,

    {M mu>lambda}=union_{k=1}^B {D_k>=k}.                 (H1)

Proof of forward inclusion: at a witnessing side L, the captured integer weight is m>0 and m/(B L^2)>lambda. Therefore every captured point has distance at most L/2<r_m, so D_m>=m. Conversely if D_k>=k, finitely many capturing sites lie strictly inside radius r_k; choose a slightly smaller radius still capturing weight at least k. Its cube average is strictly greater than lambda. This also settles complete tied arrivals without imposing an artificial scale mesh. The upper range B is the integer total weight, not the number of distinct sites; rational weights with large denominator can make the algorithm expensive, and no polynomial complexity in bit length is asserted.

Each {D_k>=k} is a depth superlevel set for axis-parallel squares. This is an exact finite reduction of the original all-scale maximal function. Its boundaries lie in finitely many coordinate lines. Whether those square boundaries are retained cannot change planar Lebesgue area.

For any fixed finite positive source, the level set {M mu=lambda} has Lebesgue measure zero. Indeed at a maximizing arrival it lies on the boundary of a source-centered square with radius determined by one of finitely many captured subset masses. This also justifies the strict/inclusive endpoint choices in the band formula below.

## Rational enclosure and sweep invariant

Set D=2^b times the least common multiple of the source coordinate denominators. All source coordinates times D are integers. If lambda=a/c in lowest terms, let

    l_k=isqrt(floor(k c D^2/(4 B a))),
    u_k=l_k if 4 B a l_k^2=k c D^2, otherwise l_k+1.

The integer square root and comparison prove l_k/D<=r_k<=u_k/D. There is no floating square root and no assumed interval-arithmetic library. Replace every square in (H1) by its lower-radius and upper-radius versions. Monotonicity of all positive-weight depth conditions gives

    E_lower subset {M mu>lambda} subset E_upper

up to square boundaries of area zero. The square radii differ by at most 1/D.

For either version, collect every integer x endpoint and every integer y endpoint of all N B squares. Sweep x in sorted order. For each k and y strip, maintain its integer covering weight, and maintain the number of levels k for which this weight is at least k. At an x endpoint apply ALL starts/ends at that coordinate before charging the next open x strip. A start/end updates the k-row by +/-w_i on its y interval, changing the overall coverage count only when the depth crosses k. Covered strip length is exactly the sum of integer y widths having a positive overall count. Multiplying by the integer x width and summing gives the exact integer area, divided by D^2. The terminal invariant is that every depth and every coverage count returns to zero. Zero-width squares contribute nothing.

This computes the union over all levels, not a sum with overlap duplication. All receiver space is included because the finite union has endpoints among those swept. The independent brute-force oracle instead enumerates all resulting x/y cells, evaluates each square at the rational midpoint and checks all depth levels; it is used for small pilot cases only.

Convergence is also explicit. A membership difference between lower and upper unions must belong to some individual square difference. Therefore

    |E_upper|-|E_lower|
      <=sum_{i,k} 4[(u_k/D)^2-(l_k/D)^2].                 (H2)

The right side tends to zero with b for fixed source and lambda. This is a finite-instance convergence statement; N and B are visible, so it is not a uniform arbitrary-source theorem.

## A certified true band integral

Write V(t)=|{M mu>t}|. The layer-cake identity gives

    integral_{lambda<M mu<=2lambda} M mu dx
      =lambda V(lambda)-2lambda V(2lambda)
         +integral_lambda^{2lambda} V(t)dt.              (H3)

The identity follows pointwise for each nonnegative maximal value and then by Tonelli (or by subtracting bounded integrals after restricting to M>lambda). All terms are finite for the fixed finite source. Since V is decreasing, right-endpoint and left-endpoint Riemann sums bound the last integral from below and above. Use the certified lower V at all right endpoints and upper V at all left endpoints, also respecting the negative sign on -2lambda V(2lambda). Thus (H3) yields a rigorous band-integral interval; no quadrature smoothness or floating error estimate is assumed. Nested partitions with 16,64,256 equal subintervals are checked for enclosure refinement.

## Actual staged checks and controls

The final program uses a standard-library exact Fraction/int implementation. Seed 710311 fixes the pilot source generation. Sixteen tiny configurations (including unequal integer weights, possible coincident sites and non-dyadic rational coordinates) compare the sweep exactly with independent cell enumeration. Twenty-seven single-site, coincident-site and widely separated two-site calibrations at three precisions and three thresholds enclose their analytically exact weak ratio 1. Thus 43 oracle/calibration guards pass. Twelve enlarged grid/threshold cases and three prescribed direct-winner controls are also computed.

The prescribed controls all have W=1 and lambda=1/4:

1. Four equal vertices (+/-1,+/-1).
2. Sixteen equal grid points with each coordinate in {-3/4,-1/4,1/4,3/4}.
3. Eight equal two-scale points (3 sx/4+t/8,3 sy/4), sx,sy,t in {-1,1}.

Halo certificates use b=12,32,80 and satisfy nested enclosure tests. The first ratio is exactly 1. The other two are approximately 1.0643398282201788 and 0.9411585037300683, each enclosed by the exact rational endpoints saved in JSON. These are numerical evaluations of finite-source quantities, not fitted dimensional trends. The final band intervals use 256 panels and outward geometric enclosures at b=48; their widths are about 0.00195,0.00186,0.00184 respectively. The leading decimal midpoints alone are not the certificate; the rational bounds and reproducible integer arithmetic are.

Current L03 method and cube interface were read. The outward direction is proved for every radius, every set inclusion, every area accumulation and every signed term of (H3). No external theorem or solver optimality certificate is invoked. The code writes halo_certificate_results.json beside itself; run it in a fresh directory or preserve the archived JSON before replay.

## Independent analytic calibration of the sixteen-site grid

The second control has the exact weak ratio 17/8-3 sqrt(2)/4. This is a calibration, not a claim of extremality. To verify it, write a captured grid block as a consecutive a-by-b block, 1<=a,b<=4. Its mass is ab/16, and its threshold radius at lambda=1/4 is sqrt(ab)/4. The admissible receiver rectangle has widths (sqrt(ab)-a+1)/2 and (sqrt(ab)-b+1)/2, centered at the block midpoint; negative widths mean an empty rectangle. Every actual capture set is such a consecutive product block, and conversely these rectangles are contained in the halo up to boundary lines by the strict-threshold argument (H1).

The a=b=1 rectangles tile [-1,1]^2 up to boundaries. For a=b>=2 all rectangles remain inside that square. Among a!=b, only (1,2) and (2,1) extend outside: (1,3),(1,4),(2,4) and their transposes have a nonpositive width; (2,3),(3,4) and transposes lie inside [-1,1]^2 by their explicit midpoint ranges. Put d=(sqrt(2)-1)/4. On each of the four sides, three disjoint exterior flaps have width d and length 2d. They do not overlap flaps on another side. Total halo area is therefore 4+24d^2=17/2-3 sqrt(2), giving lambda times area 17/8-3 sqrt(2)/4. This analytically checks the nontrivial complete area returned by the integer sweep.

## Remaining mathematical task

A certificate for each fixed source cannot control the supremum over all inputs, dimensions, mass denominators or geometric depths. This work strengthens numerical verification of the actual weak objective; it does not pay the diffuse-winner transport budget or the desired sqrt(n)n^{o(1)} upper bound.


---

# Round71: actual weak threshold and common-source winner occupancy

This round directly tests λ|{Mμ>λ}|/W and W^−1∫_{λ<Mμ≤2λ}Mμ dx. It does not use cap energy or positive arrivals as a replacement objective. The strongest held-out weak estimates are about 1.258 for a one-dimensional optimized hierarchical source and 1.375 for the full eight-dimensional Boolean vertex source at λ=1/65536. These finite values do not establish dimensional growth, optimality, or a general upper bound. In the Boolean case the residual band contributes about 0.690 of the total 1.066. The unpaid residual depends materially on the threshold and source geometry.

## Actual winner and attribution

Every input is one common positive finite atomic measure μ=Σp_iδ_(y_i), with W=Σp_i. Duplicates are merged. At receiver x, physical arrivals v_i=(2||x−y_i||∞)^n are sorted and entire equal-distance batches are captured. The maximal value M is the maximum cumulative mass divided by its arrival volume. Among maximizing volumes the smallest volume is selected. Thus the winning cube Q* and its capture set come from the original source, not separately optimized columns or independent inputs. Strict weak gates are M>λ; the band gate is λ<M≤2λ.

Set a_i=p_i/W, V=W/λ and τ*=v*/V. The program records winning mass fraction F*/W, distinct captured site count, and effective captured count (Σcaptured a_i)²/Σcaptured a_i². The full source-column load is

L_i = ∫_{λ<M≤2λ} 1_{y_i∈Q*}/v* dx.

Mass-weighted columns a_iL_i sum exactly to the normalized band-M integral. Every sampled row verifies this equality using the same receiver and winner. Its largest floating pointwise discrepancy is 7.106×10^−15; exact rational retained-point audits also verify the identity. The equality is algebraic, not independent empirical evidence for an upper bound.

Winner categories are disjoint: single captured site; at least two sites and strictly more than W/2 captured mass; and at least two sites with captured mass ≤W/2. The last is the residual, including equality at W/2. Both the whole weak volume and the band-M integral are split by these categories. Mass-fraction strata are (0,1/8],(1/8,1/4],(1/4,1/2],(1/2,3/4],(3/4,1]. Their reported means are importance-weighted receiver volumes or band-M traffic, not unweighted receiver frequencies.

## Full-space proposal and finite envelopes

The receiver proposal has three components: probability 1/2 chooses a source center uniformly at global radial scale V; probability 1/4 chooses a center by a_i at global scale V; probability 1/4 chooses by a_i at individual scale a_iV. At scale b it draws volume bU or b/U with probability 1/2 each. Cube-cone face, sign and free coordinates are uniform. U=0 is replaced by the least positive machine float.

The radial density is 1/(2b) for v≤b and b/(2v²) for v>b; each branch integrates to 1/2. With normalized cone angle, dx=dv dσ. The **complete** spatial density is q=(λ/W)q_core, where τ_i=v_i/V and

q_core = Σ_i min(1,τ_i^−2)/(4N)
         + Σ_i a_i min(1,τ_i^−2)/8
         + Σ_i min(1,(a_i/τ_i)²)/8.

Every center and every component is included in the denominator. This proposal has full-space and tail support; no receiver box or radial cutoff is imposed.

On M>λ the winning normalized volume is τ*<F*/W≤1, and at least one source lies within it. The source-uniform global component therefore gives q_core≥1/(4N). Consequently the ideal weak score 1_{M>λ}/q_core is bounded by 4N, and the band-M score 1_band(M/λ)/q_core by 8N. The column score is 1_band1_capture/(τ*q_core). On the band τ*≥(F*/W)/2≥a_i/2 for a captured i, so its finite envelope is 8N/a_i; a mass-weighted column score is bounded by 8N. These are proposal-score bounds, not source-independent bounds on the column integrals.

Sample SE and per-row ideal IID Hoeffding 95% radii are saved. Weak SEs in final rows range from 0.01209 to 0.05887, and weak Hoeffding radii from 0.08488 to 30.73033. The corresponding band radius is twice the weak radius. These generally wide ranges are not simultaneous bounds over search/columns and do not certify floating arithmetic or pseudorandom sampling. Full support does not rule out missed rare angular or coherent configurations.

## Staging, feasible search, and replay counts

| Stage | Rows/evaluations | Draws |
|---|---:|---:|
| Pilot: three families, four strata, three thresholds | 36 | 18,432 |
| Four CRN chains: initial plus 16 trial mutations | 68 | 34,816 |
| Independent search candidate/control comparisons | 16 | 65,536 |
| Expanded independent n-versus-N matrix | 36 | 73,728 |
| Correlated controls | 8 | 16,384 |
| Frozen Round70 geometries and their controls | 16 | 32,768 |
| Full Boolean vertex pressure | 8 | 16,384 |
| Three planar certificate controls, two seeds each | 6 | 49,152 |
| One-atom calibrations | 4 | 16,384 |
| Total | 130 receiver rows plus 68 search evaluations | 323,584 |

The final program contains 288,768 ordinary receiver draws and 34,816 additional search draws. A preliminary pilot and the failed first final audit run precede this registered replay and are not pooled into its evidence.

Pilot strata are (n, requested N)=(1,16),(2,8),(4,16),(8,32), with binary, hierarchical and correlated inputs at log2(1/λ)/n∈{1,1.5,2}. Threshold comparisons for a fixed source share random numbers. Within each stratum the search starts from the largest pilot mean minus 0.5 SE; each 512-draw CRN chain cycles through site perturbations, coordinate stretches, half-source shifts, strictly positive integer mass reallocations, whole-source perturbations and threshold steps. Coordinate mutations preserve masses; mass mutations renormalize positive rational weights. Collisions are allowed and merged. All source positions, weights and thresholds in selected and initial configurations are archived; trial digests and acceptance decisions are reproducible from the seeded program.

This is a finite noisy greedy search with no local/global optimality certificate. It does not cover all positive inputs. Candidate configuration selection precedes all final receiver seeds. Final seeds are pairwise distinct and disjoint from pilot/search seeds. The enlarged sources are newly generated fixed configurations, not optimized solutions in their new dimensions. The main matrix varies n∈{2,8,32} and requested N∈{8,32,64} independently for binary and hierarchical sources; correlated controls separately use n=4,16 and N=8,64. Binary requested N=32,64 at n=2 merge to 31,62 sites; actual N is always used in bounds. The full Boolean branch has N=2^n and is identified separately.

The retained Round70 candidates were chosen for cap energy, not this weak objective. Their weak/band results are fresh direct measurements on independent receivers, not a transfer from their previous energy scores.

## Held-out findings

Two independent seeds per source are combined by averaging means, with combined SE sqrt(SE₁²+SE₂²)/2. These ± values are sample errors, not certificates.

| Stratum | Initial weak ratio | Selected weak ratio | Selected band-M |
|---|---:|---:|---:|
| n=1,N=16 | 1.07313±0.01002 | 1.25794±0.01143 | 1.03795±0.01567 |
| n=2,N=8 | 0.98504±0.01222 | 1.00855±0.01304 | 0.78631±0.01746 |
| n=4,N=16 | 1.18617±0.01796 | 1.20942±0.01814 | 0.89844±0.02174 |
| n=8,N=32 | 1.04850±0.02362 | 1.00524±0.02176 | 0.67897±0.02467 |

The n=1 selected source is hierarchical; its threshold changes from 1/2 to about 0.54525 and its geometry changes while all 16 sites remain distinct. Its normalized band is mostly low global captured mass: 0.54391 in fraction≤1/8 and 0.45915 in (1/8,1/4]. This does not make all that traffic residual: residual band-M is 0.52169, while single-winner band-M is 0.51626. Treating all small mass as unpaid would double count the paid single branch. Its band-M weighted effective count is only 1.664 and posterior entropy 0.410.

The n=4 source's selected residual band-M is 0.39746 versus 0.48685 initially; its weak ratio improves only modestly. The n=8 search increase fails independent evaluation. No fitted order is extracted from these changes.

In the expanded matrix, weak ratios for binary sources at requested N=64 are 0.79190±0.02240 (n=2), 1.05195±0.04019 (n=8), and 0.99813±0.04024 (n=32). Their residual band-M estimates are respectively 0.56453,0.00308 and 0. This finite regime is predominantly single-winner in large dimension; it cannot pressure the entire diffuse-source supremum. Hierarchical N=64 instead gives weak ratios 0.51780,0.47653,0.59860 and residual band-M 0.27975,0.32425,0.16366 at n=2,8,32. Thus ordinary configuration enlargement does not produce a monotone adverse trend.

Full vertices show stronger threshold sensitivity. At n=8,N=256, λ=1/8192 gives weak 1.04287±0.04028 and residual band-M 0.00579. At λ=1/65536 it gives weak 1.37489±0.04020, total band-M 1.06613±0.04824 and residual band-M 0.69029. For the latter, 1.03612 of band-M has global captured fraction≤1/8, yet band-M weighted effective count is 6.515 and entropy is 1.008. This illustrates why global small captured mass and diffuse within-winner posterior are different descriptors.

## Shared columns, entropy and geometry descriptors

The largest individual final-row load estimate is 5.75968 with SE 2.93567, at one column of the symmetric n=8 Boolean source. It is a maximum over noisy column estimates, not a certified true maximum. For a complete equal Boolean source, sign-reflection symmetry makes all true column loads equal; their common value is the normalized band-M integral. The observed large maxima therefore provide a direct warning against interpreting sampled individual peaks as a general per-source obstruction. The arbitrary-source column question remains open here.

Captured posterior weights are π_i=a_i/(F*/W) on captured sites. The program records Shannon entropy −Σπ_i logπ_i, entropy strata, and actual band traffic for heavy posterior thresholds η=.5,.25,.0625,1/√n,1/n and powers α=1.25,1.5,2. Duplicate thresholds are listed once. The analytic companion bounds are saved as references: ∫band MΣπ_i1_{π_i≥η}/W≤1+log(2/η), and ∫band MΣπ_i^α/W≤1+log2+1/(α−1). These are aggregate traffic statements for the shared source, not individual column bounds; the sample comparisons are not proofs of them.

For full n=8 vertices at λ=1/65536, heavy traffic η=1/8 is 0.91942 and α=2 traffic 0.58262. Entropy≤√8 covers band-M 1.00937 and residual 0.63353, leaving about 0.05676 band traffic uncovered in these samples. No final row's heavy/power mean exceeds its companion reference, but the finite tests do not close an arbitrary-N diffuse-entropy remainder.

A supplementary active-face diagnostic chooses the least-index boundary source and least active coordinate, then computes ζ=nσ(b_k−y_boundary,k)/r*, with b the captured barycenter. It also measures winner mass in inward thickness r*/n and r*/√n. Only their M-weighted residual occupancies are reported. For the full n=8 Boolean case, ζ<1 occupancy is 0.16719 while residual total is 0.69029; inward-face traffic is 0.42874. These are common-source geometric descriptors with no paid-budget assertion. Floating descriptors agree with all retained exact rational active-face audits; no full-receiver descriptor certification is claimed.

## Independent planar ground truth and finite-point guards

Three prescribed n=2,W=1,λ=1/4 controls use equal positive masses: four vertices (±1,±1); the 16-point product grid with coordinates −3/4,−1/4,1/4,3/4; and eight two-scale sites (3s_x/4+t/8,3s_y/4). The separate parent-owned `halo_certificate.py` computes entire-space rational inner/outer halo area certificates for these actual sources. Its certified weak references are 1, approximately 1.0643398282201788, and 0.9411585037300683. The corresponding Monte Carlo results are 1.01747±0.01401,1.07338±0.00856,0.95559±0.01067.

The same independent certificate gives 256-panel band-M intervals centered at approximately 0.693148,0.754666,0.642793 with widths about 0.00195,0.00186,0.00184. Our Monte Carlo band estimates are 0.69959±0.01504,0.76855±0.01142,0.65157±0.01225. The whole-halo certificates are evidence for those three fixed instances; they are not generated by `winner_probe.py` and do not extend to its other sources or the general supremum.

Single atoms have exact weak ratio 1 and band-M ratio log2 in every dimension and mass/threshold normalization. At n=1,2,8,32 the weak estimates are 1.00928,0.99805,1.01172,1.02734 with SE≈0.01563. Band estimates are 0.72363,0.67591,0.69755,0.75635 with SE≈0.019–0.020. The last is about 3.18 sample SE above log2; this variation is reported rather than hidden or resampled. The much wider finite Hoeffding bound includes the reference. These calibrations do not certify all random samples or their arithmetic.

For 363 retained weak/band extrema and 376 closest points on either side of the two gates, exact Fraction calculations recompute all physical volumes, grouped maxima, smallest-volume winners, capture sets, active faces and mass-weighted column sums. Every retained winner, capture set and gate classification agrees. Each full-density term is enclosed outward on the integer grid 10^−80 before summation; the maximum relative density enclosure width is 2.079×10^−76. Maximum float discrepancies are 4.655×10^−15 for M,8.218×10^−15 for complete q,4.648×10^−15 for winning volume, and 2.221×10^−15 absolute for ζ. These are finite-point checks, not a receiver-integral certificate.

Ordinary rows use exact binary-coordinate grouping at 178,258 near-tie receivers. None needed correction of a falsely merged distinct log group; none activated the near-maximizer or near-gate Fraction fallback in this replay. The smallest ordinary |log(M/threshold)| gate margin is 7.361×10^−6. This does not certify all ordinary floating comparisons. The first full audit run failed when serializing an enormous rational density sum; the repair changed only the density certificate representation to outward termwise rational intervals. It did not change source configurations, seeds, objectives, or sampled classifications.

Current L01/L02 entrances and methods/interfaces were reread, and current L03 entrance/method was reread for certificate arithmetic. The applicable boundaries are true feasible common sources, strict original gates, heuristic search versus independent evaluation, and explicit integer outward rounding for the finite density enclosure. No discrete-to-continuous theorem, general solver certificate, or uniform column theorem is imported from a skill name.

## Frozen replay

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round071_20261011/winner_probe.py
```

The standalone script writes adjacent `winner_results.json`. `--pilot` deliberately overwrites that path with pilot-only output. No previous-round runtime imports or installations are required; the retained Round70 sources are embedded. Environment: Python3.12.14 and NumPy2.3.5. The completed final run exited0 in14.1202 seconds, with no live session remaining. Runtime is printed and not serialized.

Script SHA256: `3088e5ebde89a99c537463d377897a5ff207c4e88783c7639a9a1304fd99e033`.

Data SHA256: `f56a27e664f4be09578d09b9d1ad6c25f93cf17245cef90ad79cd643a1ee714e`.

The script and data are frozen. The arbitrary-source winner budget and requested dimensional upper bound remain unproved.


## Complete standalone halo certificate code

```python
"""Exact rational inner/outer whole-halo area for finite 2D integer-mass sources.
No floating geometry, libraries or gridded-radius maximal proxy are used.
"""
from fractions import Fraction as F
from math import isqrt,lcm
from itertools import product
from collections import defaultdict
from pathlib import Path
import json,random,time

def area_sweep(boxes,levels):
    # box (xlo,xhi,ylo,yhi,level,integer mass), all coordinates integer.
    ys=sorted({v for a,b,c,d,k,w in boxes for v in (c,d)})
    if len(ys)<2:return 0
    yi={y:i for i,y in enumerate(ys)};events=defaultdict(list)
    for a,b,c,d,k,w in boxes:
        if a>=b or c>=d:continue
        events[a].append((k,yi[c],yi[d],w));events[b].append((k,yi[c],yi[d],-w))
    xs=sorted(events);counts=[[0]*(len(ys)-1) for _ in range(levels)]
    coverage=[0]*(len(ys)-1);widths=[b-a for a,b in zip(ys,ys[1:])];out=0
    for i,x in enumerate(xs):
        for k,a,b,w in events[x]:
            row=counts[k-1]
            for j in range(a,b):
                old=row[j]>=k;row[j]+=w;new=row[j]>=k
                coverage[j]+=int(new)-int(old)
        if i+1<len(xs):out+=(xs[i+1]-x)*sum(d for d,c in zip(widths,coverage) if c>0)
    assert all(c==0 for row in counts for c in row)
    assert not any(coverage)
    return out

def area_brute(boxes,levels):
    xs=sorted({v for a,b,c,d,k,w in boxes for v in (a,b)})
    ys=sorted({v for a,b,c,d,k,w in boxes for v in (c,d)})
    total=0
    for a,b in zip(xs,xs[1:]):
      for c,d in zip(ys,ys[1:]):
        depth=[0]*levels
        for xl,xh,yl,yh,k,w in boxes:
          if 2*xl<a+b<2*xh and 2*yl<c+d<2*yh:depth[k-1]+=w
        if any(v>=i+1 for i,v in enumerate(depth)):total+=(b-a)*(d-c)
    return total

def boxes_for(coords,masses,lam,bits,upper):
    den=2**bits*lcm(*(F(v).denominator for point in coords for v in point));total=sum(masses);out=[];radii=[]
    ints=[]
    for point in coords:
        p=[F(v)*den for v in point];assert all(v.denominator==1 for v in p)
        ints.append([v.numerator for v in p])
    for k in range(1,total+1):
        num=k*lam.denominator*den**2;div=4*total*lam.numerator
        r=isqrt(num//div);exact=r*r*div==num
        assert r*r*div<=num<(r+1)**2*div
        if upper and not exact:r+=1
        radii.append(r)
        for (x,y),w in zip(ints,masses):out.append((x-r,x+r,y-r,y+r,k,w))
    return out,total,radii,den

def certificate(coords,masses,lam,bits,brute=False):
    assert lam>0 and all(isinstance(w,int) and w>0 for w in masses)
    areas=[];grids=[]
    for upper in (False,True):
        boxes,B,radii,den=boxes_for(coords,masses,lam,bits,upper)
        area=area_sweep(boxes,B)
        if brute:assert area==area_brute(boxes,B)
        areas.append(F(area,den**2))
        grids.append(dict(xcuts=len({z for a,b,c,d,k,w in boxes for z in (a,b)}),ycuts=len({z for a,b,c,d,k,w in boxes for z in (c,d)})))
    assert areas[0]<=areas[1]
    weak=[lam*a for a in areas]
    return dict(bits=bits,coordinate_denominator=den,area_lower=str(areas[0]),area_upper=str(areas[1]),weak_lower=str(weak[0]),weak_upper=str(weak[1]),weak_mid_float=float(sum(weak)/2),weak_width=str(weak[1]-weak[0]),grids=grids)

def controls():
    return [('four_vertices',list(product([-1,1],repeat=2)),[1]*4,F(1,4)),
            ('product_grid16',list(product([F(-3,4),F(-1,4),F(1,4),F(3,4)],repeat=2)),[1]*16,F(1,4)),
            ('two_scale8',[(F(3*sx,4)+F(t,8),F(3*sy,4)) for sx,sy,t in product([-1,1],repeat=3)],[1]*8,F(1,4))]

def band_certificate(coords,masses,lam,bits,panels):
    # Tail formula: integral_{lam<M<=2lam}M = lam V(lam)-2lam V(2lam)+integral_lam^{2lam}V(t)dt.
    vals=[certificate(coords,masses,lam*(1+F(j,panels)),bits) for j in range(panels+1)]
    low=[F(r['area_lower']) for r in vals];high=[F(r['area_upper']) for r in vals]
    step=lam/panels
    lo=lam*low[0]-2*lam*high[-1]+step*sum(low[1:])
    hi=lam*high[0]-2*lam*low[-1]+step*sum(high[:-1])
    assert lo<=hi
    return dict(panels=panels,bits=bits,band_lower=str(max(F(0),lo)),band_upper=str(hi),band_mid_float=float((lo+hi)/2),band_width=str(hi-lo))

def main():
    rng=random.Random(710311);guards=0
    # Pilot: independent cell-by-cell exact oracle, including unequal masses and coincident sites.
    for N in [1,2,3,4]:
      for trial in range(4):
        coords=[(F(rng.randrange(-3,4),[2,3,5,8][trial]),F(rng.randrange(-3,4),[2,3,5,8][trial])) for _ in range(N)]
        masses=[rng.randrange(1,3) for _ in range(N)]
        certificate(coords,masses,F(rng.randrange(1,9),4),4,True);guards+=1
    # Known exact full-halo calibrations, not only finite points.
    for bits in [8,20,48]:
      for lam in [F(1,4),F(1),F(3,7)]:
        for coords,masses in [([(0,0)],[1]), ([(0,0)]*3,[1,2,4]),([(-100,0),(100,0)],[1,1])]:
          r=certificate(coords,masses,lam,bits)
          assert F(r['weak_lower'])<=1<=F(r['weak_upper']);guards+=1
    rows=[]
    for name,coords,masses,lam in controls():
      seq=[]
      for bits in [12,32,80]:
        r=certificate(coords,masses,lam,bits)
        if seq:
          assert F(seq[-1]['weak_lower'])<=F(r['weak_lower'])<=F(r['weak_upper'])<=F(seq[-1]['weak_upper'])
        seq.append(r)
      rows.append(dict(name=name,coords=[[str(x),str(y)] for x,y in coords],integer_masses=masses,lambda_value=str(lam),certificates=seq))
    # Expanded exact mass/geometry controls with finer threshold ranges, bounded computational cost.
    expanded=[]
    for N in [4,8,16]:
      coords=[(F(j%4,2),F(j//4,2)) for j in range(N)]
      for lam in [F(1,16),F(1,4),F(1),F(4)]:
        r=certificate(coords,[1]*N,lam,40)
        expanded.append(dict(N=N,lambda_value=str(lam),result=r))
    bands=[]
    for name,coords,masses,lam in controls():
        seq=[band_certificate(coords,masses,lam,48,k) for k in [16,64,256]]
        for a,b in zip(seq,seq[1:]):
            assert F(a['band_lower'])<=F(b['band_lower'])<=F(b['band_upper'])<=F(a['band_upper'])
        bands.append(dict(name=name,certificates=seq))
    result=dict(bands=bands,scope='Certified whole receiver-space weak-halo area only for recorded finite 2D sources. No uniform bound or optimization certificate.',seed=710311,exact_oracle_and_analytic_guards=guards,controls=rows,expanded=expanded)
    Path(__file__).with_name('halo_certificate_results.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(guards=guards,controls=[dict(name=r['name'],mid=r['certificates'][-1]['weak_mid_float'],width=r['certificates'][-1]['weak_width']) for r in rows],expanded=len(expanded),bands=[dict(name=r['name'],mid=r['certificates'][-1]['band_mid_float'],width=float(F(r['certificates'][-1]['band_width']))) for r in bands])))
if __name__=='__main__':main()
```

The numerical experiment retained the broader +1 posterior reference constants. The global-cap sharpening in the proof above is stronger; the frozen numerical data have not been relabelled as tests of a different bound.
