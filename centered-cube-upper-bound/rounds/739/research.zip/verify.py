from fractions import Fraction as F
from itertools import product
from pathlib import Path
import platform,sys,subprocess,json

def interval(a,b,c,d):
    return max(F(0),min(b,d)-max(a,c))
def cases(remote):
    results=[]
    for n,scale in [(3,1),(8,2),(16,3)]:
        # Exact volume integration on the moved axes, including clipped cells and holes.
        w=F(scale,n);base=F(2);rad=w/16
        for edge,sgn in [(F(1,2),1),(F(1,32),-1),(F(0),1)]:
            # Actual 2D slice is a square with a quadrant removed.
            center=(base+w*edge,sgn*(base+w*(1-edge)))
            cs=[center[0],abs(center[1])]
            bins=[[z-rad,z,z+rad] for z in cs]
            if remote:
                cuts=[sorted({base,base+w,*[y for y in side if base<=y<=base+w]}) for side in bins]
                area=F(0)
                for x,y in product(range(len(cuts[0])-1),range(len(cuts[1])-1)):
                    a,b=cuts[0][x:x+2];c,d=cuts[1][y:y+2];p=(a+b)/2;q=(c+d)/2
                    if abs(p-cs[0])<rad and abs(q-cs[1])<rad and not(p>cs[0] and q>cs[1]):area+=(b-a)*(d-c)
            else:
                lo=[interval(base,base+w,z-rad,z+rad) for z in cs]
                hi=[interval(base,base+w,z,z+rad) for z in cs]
                area=lo[0]*lo[1]-hi[0]*hi[1]
            probability=area/w**2
            assert 0<=probability<=3*rad**2/w**2
            results.append([n,str(edge),sgn,str(probability)])
    for n,k in ((4,1),(7,2),(9,3)):
        mask=(1<<k)-1;pool={v for v in range(1<<n) if v%7 in (0,1,3)}
        start=len(pool);groups=0
        for a in range(k,n):
            for b in range(a+1,n):
                while True:
                    rep={}
                    for v in sorted(pool):rep.setdefault((v>>a&1,v>>b&1),v)
                    if len(rep)<4:break
                    pool.difference_update(rep.values());groups+=1
        assert len(pool)<=2**k*(1+n-k) and groups*4+len(pool)==start
        # Direct enumeration of the exactly weighted possible varying axes.
        prob=F(1,4)
        avg=sum(prob**v.bit_count()*(1-prob)**(n-v.bit_count())*2**((v&mask).bit_count())*(1+(v&~mask).bit_count()) for v in range(1<<n))
        assert avg==(1+prob)**k*(1+(n-k)*prob)
        results.append([n,k,start,groups,len(pool),str(avg)])
    return results
if '--mac' in sys.argv:
 print(json.dumps([platform.python_version(),cases(True)]));sys.exit()
ls=cases(False)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --mac']
p=subprocess.run(cmd,input=Path(__file__).read_text(),capture_output=True,text=True,check=True,timeout=100);v,remote=json.loads(p.stdout);assert remote==ls
from flint import arb,ctx
from math import isqrt
ctx.prec=256
hist=[]
for n in [256,1024,4096]:
 a=32*n;h=1+arb(1)/a;b=arb(2)**(arb(1)/n);K=4096*isqrt(n)*a**n
 ell=arb(2).log()/K
 for m in (1,2):
    r=arb(m)/isqrt(n);A=arb(1) if m==1 else arb(n).log()/4
    w=2*h*b*A/n
    V=4*(2*r/a)**n;R=V*ell.expm1()/2
    lg=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    corewidth=2*r/a
    # Expected four-lift overlap for translated receivers in R738;
    # each axis overlap = (corewidth-jitter)_+.
    assert corewidth<w
    frac=(corewidth/(2*w))**2
    assert frac>0 and frac<(r/(32*h*b*A))**2 and 0<R and R<V/4
    assert lg>(4*arb(8)**n+4).log()
    hist.append(dict(n=n,m=m,mean_fourfold_fraction=str(frac),V=str(V),R=str(R),logD_div_K=[str(lg/K),str((lg+arb(3).log())/K)]))
print(json.dumps(dict(local=sys.executable,version=platform.python_version(),remote=v,cmd=cmd,slices=ls,histories=hist),indent=2))
