from fractions import Fraction as F
from decimal import Decimal, getcontext
import json
getcontext().prec=70
def dec(x):
    x=F(x); return Decimal(x.numerator)/Decimal(x.denominator)
counts={"atomic_fields":0,"common_quantile_targets":0,"active_row_checks":0,
        "soft_splits":0,"old_hit_inclusions":0,"square_checks":0,
        "hardy_payment_diagnostics":0,"clock_atom_cases":0}
for N in (4,8,16,32):
  ms=[F(2)**i for i in range(N)]
  for seed in range(6):
    ws=[F(1+(i+seed)%3) for i in range(N)]
    ds=[F((3*i+seed)%11,10) for i in range(N)]
    J=sum(ws); lam=F(3,2)
    for K in (F(3,2),F(2)):
      B=max(sum(w for m,w in zip(ms,ws) if t<=m<=K*t) for t in ms)
      U=lambda t:sum(w for m,w in zip(ms,ws) if m>t)
      top=[m>=ms[-1]/K for m in ms]
      topmass=sum(w for w,on in zip(ws,top) if on)
      assert topmass<=B
      for eps in (F(1,10),F(1,4),F(1,2)):
        active=[U(K*m)>eps*J for m in ms]
        tau=2*lam*B
        targetmass=eps*J
        eta=[F(0)]*N
        left=targetmass
        for i in reversed(range(N)):
          take=min(left,ws[i]); eta[i]=take/ws[i]; left-=take
        assert left==0
        M=max([ds[i]*U(K*ms[i]) for i in range(N) if active[i]]+[F(0)])
        ts=[M/targetmass*x for x in eta]
        assert sum(t*w for t,w in zip(ts,ws))==M
        counts["common_quantile_targets"]+=1
        original=paid=rem=F(0)
        hardy=F(0)
        for i in range(N):
          if not active[i]: continue
          tail=U(K*ms[i]); a=lam*ds[i]
          assert sum(t*w for t,w,m in zip(ts,ws,ms) if m>K*ms[i])==M
          assert M>=ds[i]*tail
          counts["active_row_checks"]+=1
          p=sum(w for w,m,on in zip(ws,ms,top) if on and m>K*ms[i])/tail
          cut=min(a,tau/tail); residual=max(F(0),a-tau/tail)
          assert a==cut+residual
          assert residual<=a*a*tail/(4*tau)
          counts["soft_splits"]+=1;counts["square_checks"]+=1
          if p>=F(1,2):
            assert tail<=2*B and residual==0
            counts["old_hit_inclusions"]+=1
          original+=a*ws[i];paid+=cut*ws[i];rem+=residual*ws[i]
          hardy+=ws[i]/tail
        assert original==paid+rem and paid<=tau*hardy
        if B<eps*J:
          L=Decimal(1)+(Decimal(1)/dec(eps)).ln()
          assert dec(hardy)<=L+Decimal("1e-55")
          assert dec(paid)<=dec(tau)*L+Decimal("1e-55")
          counts["hardy_payment_diagnostics"]+=1
        counts["atomic_fields"]+=1

# Exact physical-clock identity with two continuous pieces and terminal atom.
for n in (1,2,4,8):
  Ru=F(1); mid=F(3,2); b=F(2); D=F(2); J0=F(3)
  pieces=[(Ru**(-n)-mid**(-n),F(3)),
          (mid**(-n)-b**(-n),F(5)),(b**(-n),F(7))]
  assert sum(w for w,j in pieces)==Ru**(-n)
  for H in (F(1),F(4),F(6),F(8)):
    C=Ru**n*sum((w/j for w,j in pieces if j>=H),F(0))
    omega=D*C
    deficit=Ru**n*sum(w*(1-(J0/j if j>=H else F(0))) for w,j in pieces)
    assert J0*C+deficit==1
    assert 0<=deficit<=1 and 0<=omega<=D/J0
    counts["clock_atom_cases"]+=1
print(json.dumps({"status":"PASS","counts":counts,"decimal_precision":70},indent=2))
