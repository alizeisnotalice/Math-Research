# R348 final independent audit

**PASS for the frozen statements and ledger, after the two wording/normalization corrections recorded below.** The complete original relative-upper traffic admits the stated same-price soft deduction. Its complementary actual-clock arrived-upper part has the new small receiver fee. The common-tail LP identity is valid with almost-everywhere constraints. The remaining late soft traffic and the general problem are not closed.

This reviewer derived the candidate estimates before reading R348 author files, recorded them in `/tmp/r348_audit_pre.md`, then read the complete final core, geometry, main, ledger, numerical note and all three scripts. No author file, numerical output, old contract or Git state was modified. The primary's full pipelines were not repeated. This audit binds current final bytes and does not comprehensively reauthenticate the historical reductions.

## 1. Exact soft payment and correct reconstruction

Use the same full-f hard field, actual du, original source component g≤f, ρ_y=c_u du/m_u, terminal J_b, strict upper U_y(Km_u), and original clock-integrated a_y(u)=q_uω_y(u), 0≤a≤λ. The original ω contains every old small endpoint, high-past/outside/H/far and current full-J/clock factor. On its nonzero source support J_b>h=B/ε, the R347 actual closed-window/atom-safe Hardy estimate applies. Neither source splitting nor the new score gate changes these fields.

On every original relative-active row U>εJ_b, the equality

    a=min(a,τ/U)+(a-τ/U)_+,  τ=2λB,

is exact. The paid part is bounded by τL_ε per source, with L_ε=1+log(1/ε), so the price is the same C_hit W_ex as in R347. The old Top-hit branch satisfies U≤2B and is fully cleared. Higher-score rows retain a positive payment τ/U rather than being returned as the whole a. The fractional remainder can be represented on the original clock by η=(1-τ/(aU))_+, zero at a=0. Thus aη=(a-τ/U)_+ with η measurable, source–u dependent and bounded by one. This representation is valid without recomputing ω after any later clock split.

An earlier core sentence proposed merely replacing the old upper-bound remainder by a smaller remainder. That implication would not follow from an upper bound alone. The final core §2 now explicitly reconstructs from the R346 bound with original G_rel, substitutes the exact G_rel=P+G_soft equality, and pays P≤C_hit W_ex. This resolves the logical wording issue. The old Top receipt is not charged again, and the other R346 source/receiver fees remain once.

The optional inequality (a-τ/U)_+≤a²U/(4τ) is correct. The retained a² contains the actual old ω and two old clock factors. It is not an independently available negative square credit or a proved general source budget.

## 2. Common-tail target LP and units

The core uses normalized demand d=a/λ. With nonnegative target density t and constraints ∫_{m_w>Km_u}tρ_y≥d(u)U_y(Km_u) for ρ_y-almost every retained active u, its exact minimum is M_A=esssup_A dU. The constraints must be almost everywhere to match the essential supremum; null rows do not affect the original traffic. The empty active problem and zero-J problem have price zero.

For δ=εJ>0, the strict-tail quantile has U(σ)≤δ≤V(σ). The common top-rank density v=1_{m>σ}+fraction·1_{m=σ} has total δ and lies inside EVERY active upper tail, because U(Km_u)>δ forces Km_u<σ. Hence t=(M_A/δ)v attains cost M_A and satisfies all active constraints at once. The atom fraction is a weight on the existing mass level, not a modified physical radius/cube or a new receiver. There is no constraint t≤1; imposing one would invalidate some stated witnesses. Joint measurability follows from Tonelli, rational quantile thresholds and sourcewise essential-supremum level sets.

The unnormalized demand aU has minimum λM_A=esssup aU. Main now states this convention separately from the core's dU convention. Numeric uses λ=1, so its demand aU agrees with either normalization. Core checks use λ=3/2 and the explicitly normalized d. This resolves the main/core units wording issue. The exact LP optimum is not itself the original traffic cost or a root estimate: applying it still incurs the Hardy column estimate. No general source-integrated bound on the untruncated optimum is proved.

## 3. New original-clock payment

For the SAME captured source and actual upper receivers m_w>Km_u, real receiver-center volume yields

    ∫upper (m_u/m_w)ρ_y(dw)≤2/(Kq_-).

The proof integrates m_u/max(Km_u,q_-z)^2 in the exact volume coordinate z=(2||w-y||∞)^n on [0,∞). Each side of z=Km_u/q_- contributes 1/(Kq_-). This is a true du/m_w² envelope, not a cap on f or source boundary mass. Dropping E and radius restrictions enlarges it legitimately.

K>λ/q_- implies R_w>R_u. The normalized ORIGINAL clock R_u^n ell restricted to [R_u,b] is probability-valued, and Tonelli gives

    E_clock U_y^r(Km_u)=∫upper(R_u/R_w)^nρ_y(dw).

The true mass relation supplies (R_u/R_w)^n=(m_u/m_w)(q_w/q_u), so q_u times this moment is at most 2λ/(Kq_-). This identity explicitly includes witnesses at b through the existing terminal b atom. It does not substitute terminal occupancy for the prefix variable.

For any original integrand factor F∈[0,1], source integration gives the moment bound (8) in geometry. Markov's inequality on the original-time event U_y^r(Km_u)>t then yields

    R_arr(t)[g]≤[2λ/(Kq_-t)]∫gJ_b
                ≤[2λ/(Kq_-²t)]X_q.

Here ∫gJ_b≤|E|≤X_q/q_- uses the full-f masses and true common source; it is not a selector reset. At t=1/q_-, the fee is γ_n X_q, γ_n=(8/3)exp(-√n). It applies in particular to the already soft-deducted factor ηΩ, while all old gates remain present. This pays an additional positive branch, not a transported surrogate or a repeated soft-source charge.

Smallness is conditional on the original high-past dimension guard, and that guard is explicit. If εA_n≤1+√n, original traffic is zero; take γ_eff=0. Otherwise A_n≤1+nlog2 implies √n>1/ε. At ε=119/3072, the fourth-order exponential lower bound and exact rational 1024ε³<1 yield γ_n<64ε⁴<ε/16. The alternative cubic estimate used in main also yields the stated ε/16 bound because this ε<1/16. No claim γ_n<ε/16 for every bare n is made; low dimensions are handled by the empty-traffic case.

The exact complementary clock event is U_y^r(Km_u)≤1/q_-. It retains the SAME soft η and original a/ω, rather than recomputing them on the restricted clock. Main's stricter quantitative late-fraction statement also follows: nonzero soft remainder has U>2B, so the undelivered upper mass is >U[1-1/(2(1+√n))]. This is a genuine delayed-occupancy condition, not a payment for that complement.

## 4. Complete slot and conditional outer accounting

The valid sequential account is: reconstruct from original G_rel; pay the soft portion at the SAME R347 source price; split only the remaining ηΩ traffic at the actual-clock arrived gate; pay that part once. The hard slot is

    B_H≤G_late[g_ex]+[(13/3)ε+γ_eff]X_q+C_{ε,n}W
                       +(D_top,n+C_hit,n)W_ex.

The earlier relative-low and current soft-relative-high fees correspond to different original positive pieces. Old Top, receiver covering and absolute-future alternatives are not additionally billed. The entrance multiplies every slot contribution by two. Its supplied historical outer multiplier gives

    13/36+2Λγ_eff,

or, only when the old CZ 1/256 belongs to the same authenticated X account,

    841/2304+2Λγ_eff<853/2304,

leaving more than 1451/2304 unallocated. This is a conditional same-account coefficient calculation, not certification of the rest of the historical aggregation or permission to treat the other slots as paid.

Core's D·C/Θ factorization preserves the original reciprocal-J clock and small/outside past factor. It is stated for the original gates before the added r-dependent arrival mask; no illegitimate later refactorization is used. The ledger correctly leaves G_late, general soft/crossing/innovation and hard-contract complements, extreme scales/heights, chronology initialization/deletion/future-deleted-source terms, outer/layer/source/limit fees and single-use negative credits outstanding. The physical b atom does not settle chronological atoms. General root-order closure is not claimed.

## 5. Actual evidence and code scope

The primary reports fresh successful execution of numeric 29,583 exact rational/outward-rational-log checks, geometry 318 Fraction assertions, core's listed finite checks including 90 ordinary 70-digit Decimal diagnostics, and a separate six Fraction ledger/smallness checks. This reviewer read all three full scripts, checked the saved numeric result, and verified that geometry_checks.py is byte-for-byte the unique Python block in geometry.md. Full pipelines were not repeated.

The saved numeric JSON records PASS and stages 1,712+5,324+22,547=29,583. Its repeated-mass grouping preserves original positive-atom constraints, strict future and relative thresholds. It preserves the chosen original row a across ε and computes all old/new totals from the same ρ. Soft-paid plus remainder equals original; the LP witness has nonnegative unbounded t, common fractional top-δ mass and a matching maximal-row lower bound. Logarithms are enclosed by rational atanh series and exact remainders; float conversions are display only. The finite-instance τL budget observed outside the small-window contract is explicitly not generalized.

These 11 numeric fixtures are abstract atomic measures, not receiver dx, original cube fields or nonempty root high-past traffic. Their strict residual reduction is evidence about the stated finite mechanics, not about geometric realization in every actual input. Core's 144 fields/1,396 row checks/old-hit/clock categories mix exact rational algebra with 90 Decimal comparisons and are not reported as one all-exact total. Geometry's positive-volume 1D example verifies actual capture, q, source/clock mechanics, but omits outside and uses diagnostic thresholds; it is not full root-hard traffic evidence. The primary's separate six assertions and the independent preliminary scratch diagnostics are not duplicate-run additions to numeric 29,583.

## 6. Frozen SHA256 bindings
- `/tmp/r348_main.md` — `5de7a7cc1beb60c18523e38b02c193fea38a55995e467472f1429beef6c5fc6e`
- `/tmp/r348_ledger.md` — `cb6429b64aea68cda448feb31ade974045abeda9eb4e0831389ca4bb9388369f`
- `/tmp/r348_core.md` — `dafedb811ac0719cf7a63502051dd13d2ccf5eb6cd5d695fb6854de509ff8ab3`
- `/tmp/r348_geometry.md` — `e86647ca64922f06e3025fca655472a2860e42336506c432251f31a1ab30f137`
- `/tmp/r348_numeric.md` — `3bc97972c46683a3d0dc748c955ece337c207f7a271a5bbe5802166105ed9d1d`
- `/tmp/r348_core_checks.py` — `2bf3e1dc823e67bc60bb7f5beaa36a26e198e680755050109a1909ee532273cd`
- `/tmp/r348_geometry_checks.py` — `524ce1d1218e96e9d32057d6f568a471c90cc51d3236283a8311616ced5f4189`
- `/tmp/r348_numeric.py` — `e03d51d4fd586546251ce3bd5754ec3e03320001d59ef9d0307cc4ae13a51fdf`
- `/tmp/r348_numeric_result.json` — `0bec117d11e9a0d39c3597d9dda548be9f7c5a8668a2a7ef13167347f2412819`
- `/tmp/r348_audit_pre.md` — `4364388d44a5100daec74790771cdfb72a61ee60e315d33f1832a0c777f0b634`
- `/tmp/r347_geometry.md` — `ac4e9b38400df1591d4f77bd289d13b08dc106167e7a173cc5daa0cb04c5d509`
- `/tmp/r347_core.md` — `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r347_audit.md` — `446bd80338554b547149d650da24fc24593df6d74aa49e537958ca1720a70f9d`
- `/tmp/r346_geometry.md` — `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r346_core.md` — `6536c1eccf98ab90e7160022f3140e83f505d23010987421fa95cd1c54e604ed`
- `/tmp/r344_geometry.md` — `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a`
- `/tmp/r340_core.md` — `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90`

The old contract and preceding clipping/rank/source-slot files are inherited interface bindings, not a fresh complete review of their historical derivations. The preliminary audit remains the independent-before-author record. This final receipt binds current final bytes and resolves the two wording issues described above.
