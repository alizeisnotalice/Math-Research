from fractions import Fraction as F
checks = 0

def ck(v):
    global checks
    assert v
    checks += 1

# Exact inverse-square radial-volume envelope, including its infinite tail.
for mu in (F(1,7),F(1),F(9,2)):
    for K in (F(3,2),F(2),F(5),F(11)):
        for q in (F(1,4),F(3,4),F(1),F(3)):
            M=K*mu
            inner=(M/q)/M**2
            tail=1/(q*M)
            ck(mu*(inner+tail)==2/(K*q))

# Exact scalar physical clock with an actual terminal atom.
# Receiver weights here test clock algebra, not geometric realization.
rs=[F(1),F(5,4),F(3,2),F(2)]
weights=[F(1,7),F(2,9),F(3,11),F(1,5)]
for n in (1,2,3,4,8,16):
    for i,Ru in enumerate(rs):
        for K in (F(3,2),F(2),F(3)):
            selected=[j for j,Rw in enumerate(rs) if Rw**n>K*Ru**n]
            rhs=sum((weights[j]*(Ru/rs[j])**n for j in selected),F(0))
            total=rs[-1]**(-n)*sum((weights[j] for j in selected),F(0))
            for l,r in zip(rs[i:],rs[i+1:]):
                prefix=sum((weights[j] for j in selected if rs[j]<=l),F(0))
                total+=(l**(-n)-r**(-n))*prefix
            ck(Ru**n*total==rhs)
            ck(Ru**n*(Ru**(-n)-rs[-1]**(-n)+rs[-1]**(-n))==1)

# Genuine positive-volume 1-D capture blocks, as specified in R347.
packets=[(F(-1,200),F(1,200),F(1)),
         (F(3,5),F(61,100),F(2,5)),
         (F(9,10),F(91,100),F(3,5))]
centers=[(F(-3,100),F(-2,100)),(F(-1,100),F(0)),(F(2,100),F(3,100))]
radii=[F(1),F(7,5),F(2)]
inc=[[1,0,0],[1,1,0],[1,1,1]]
length=F(1,100)
mass=[sum((packets[j][2]*inc[i][j] for j in range(3)),F(0)) for i in range(3)]
for i,((l,r),R) in enumerate(zip(centers,radii)):
    ck(r-l==length); ck(mass[i]/R==1)
    for j,(sl,sr,_) in enumerate(packets):
        ck((r-R/2<=sl and l+R/2>=sr) if inc[i][j]
           else (r+R/2<=sl or l-R/2>=sr))
rho=[length/m for m in mass]
K=F(11,8)
ck(mass[2]>K*mass[1] and radii[2]>radii[1])
normalized_prefix_moment=radii[1]/radii[2]*rho[2]
ck(normalized_prefix_moment==F(7,2000))
ck(normalized_prefix_moment==sum((mass[1]/mass[j]*rho[j]
       for j in range(3) if mass[j]>K*mass[1]),F(0)))
Jpre=rho[0]+rho[1]; Jfull=sum(rho)
ompre=(mass[1]-mass[0])*rho[0]/(mass[1]*Jpre)
omend=(mass[1]-mass[0])*rho[0]/(mass[1]*Jfull)
a=radii[1]*(ompre*(1/radii[1]-1/radii[2])+omend/radii[2])
ck(a==F(87,620))
U=rho[2]; tau=F(1,10000)
eta=max(F(0),1-tau/(a*U))
ck(0<eta<1)
ck(a==min(a,tau/U)+eta*a)
# Diagnostic t: the future large receiver enters only in the b atom.
t=F(1,500)
arr=eta*rho[1]*radii[1]*omend/radii[2]
late=eta*rho[1]*radii[1]*ompre*(1/radii[1]-1/radii[2])
ck(U>t)
ck(arr+late==eta*rho[1]*a)
weighted_upper=eta*rho[1]*radii[1]*omend/radii[2]*U
ck(arr<=weighted_upper/t)
ck(weighted_upper<=rho[1]*normalized_prefix_moment)

# General soft mask identity.
for a in (F(0),F(1,10),F(1,2),F(1)):
    for U in (F(1,10),F(1),F(3),F(10)):
        for tau in (F(1,100),F(1,2),F(2)):
            eta=max(F(0),1-tau/(a*U)) if a else F(0)
            ck(a==min(a,tau/U)+eta*a)
            ck(0<=eta<=1)

# All exponential smallness is analytically reduced to this rational check.
eps=F(119,3072); outer=F(128,119)
ck(1024*eps**3<1)
ck(64*eps**4<eps/16)
ck(F(13,36)+F(1,256)==F(841,2304))
ck(2*outer*eps/16==F(1,192))
ck(F(841,2304)+F(1,192)==F(853,2304))
print(f'PASS: {checks} exact Fraction assertions; no floating-point exponential or hard-traffic simulation.')
