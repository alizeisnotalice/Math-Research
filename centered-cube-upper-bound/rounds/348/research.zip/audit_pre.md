# R348 independent pre-author screen

PASS for the scored payment, its stronger soft truncation, the common-upper-tail pricing identity with the almost-everywhere quantifier below, and the subsequently screened complementary actual-clock payment at the end. No R348 author proof has been read. The soft truncation replaces the old source fee; the clock extension adds a separately stated small receiver charge. The unpriced complements remain open.

## 1. Frozen real measure and actual traffic multiplier

Use precisely R346/R347's full-f hard field and actual receiver du. At fixed source y, ρ_y(du)=c_u(y)du/m_u, J=J_b(y), U_y(t)=ρ_y{m>t}. Write U_u=U_y(Km_u), K=exp(√n), B=(1+logK)/q_-=(1+√n)/q_-, h=B/ε. The exact original clock-integrated multiplier is a_y(u)=q_uω_y(u), 0≤a≤λ; ω retains every old physical clock, small endpoint, full-J denominator, high-past/outside/far and other original gate. It is zero unless the original source row has J>h.

The unchanged R347 residual has the exact form

    G_rel[g]=∫g(y)∫a_y(u)1_{U_u>εJ}ρ_y(du)dy,
    0≤g≤f.

All m,q,J,U,ω and source fields are still those of full f. On nonzero rows the proven atom-safe R347 estimate is

    ∫_{U_u>εJ}ρ_y(du)/U_u≤L_ε=1+log(1/ε).

Every denominator U_u below is evaluated only on that active domain. Zero rows are assigned zero.

## 2. Genuine score payment and the stronger full soft split

Let τ_score=2λB. The entire positive original branch satisfying a_y(u)U_u≤τ_score is paid by

    ∫a1_{active,aU≤τ_score}ρ_y
       ≤τ_score∫active ρ_y/U_u≤τ_score L_ε.

This is a measurable source–large-endpoint restriction of the original positive traffic. It is not a change to the original selector, source, clock or prefix fields. On the previous R347 Top-hit branch, p_top≥1/2 and U_top≤ρ_y(Top_y)≤B imply U_u≤2B. Since a≤λ, its score is at most τ_score. Thus the new score branch contains that old paid branch, with the same source price. Strict enlargement is possible but is not guaranteed for every input.

More strongly, on ALL relative-active input define

    a_paid=min(a,τ_score/U_u),
    a_rem=(a-τ_score/U_u)_+.

Then a=a_paid+a_rem exactly and

    ∫active a_paidρ_y≤τ_score L_ε.

It follows that, for the exact residual after this soft deduction,

    G_rel[g]=G_paid[g]+G_soft-rem[g],
    G_paid[g]≤2λB L_ε∫g.

One may realize the split as the same source–u fractional mask a_paid/a, with zero-cost convention when a=0, multiplying the original integrand at every old clock value. It is not a recomputation of ω or a replacement of the current J. The remainder must retain the soft deduction a_rem; enlarging it to a1_{aU>τ_score} is valid but loses the stated strengthening. In particular all former Top-hit input has a_rem=0, while every higher-score input also receives a partial deduction.

For g=g_ex this replaces the R347 fee by the identical

    2(λ/q_-)(1+√n)L_ε W_ex=C_hit W_ex.

It is not added on top of the R347 Top-hit or hard-score fee. No receiver absorption term is added. On nonzero residual input aU>2λB implies U>2B and therefore p_top≤B/U<1/2; every original relative-upper, high-past, outside/H/full-J/clock/source restriction still remains. The soft remainder is pointwise no larger than the old R347 remainder.

The optional pointwise quadratic estimate is valid:

    (a-τ_score/U)_+≤a²U/(4τ_score).

Set z=aU/τ_score and use (z-1)_+≤z²/4. This inequality does not establish a source-integrated bound on a²U, so it cannot be counted as a second payment or closure.

## 3. Exact common-tail price, atoms and quantifiers

At fixed y with J>0 put δ=εJ and let A_y denote the active relative-upper input (possibly with additional original masks). Consider nonnegative measurable prices t(w) with constraints

    ∫_{m_w>Km_u}t(w)ρ_y(dw)≥a_y(u)U_u

for ρ_y-almost every u∈A_y. The qualification is essential: an essential supremum does not control arbitrarily assigned values at isolated zero-measure receiver points. Literal pointwise constraints would require a pointwise supremum or another precise representative convention. The original traffic requires only the almost-everywhere formulation.

With M_price(y)=esssup_{u∈A_y}a_y(u)U_u (zero on an empty active set), the exact infimum is

    inf_t ∫t(w)ρ_y(dw)=M_price(y).

The lower bound follows because every constrained tail integral is at most the full nonnegative cost. A common fractional top-rank block supplies an attained upper bound. Define a mass quantile z_y by U_y(z_y)≤δ≤V_y(z_y), V_y(t)=ρ_y{m≥t}. Set

    v_y(w)=1_{m_w>z_y}+r_y1_{m_w=z_y},
    r_y=(δ-U_y(z_y))/(V_y(z_y)-U_y(z_y))

when the denominator is positive; take r_y=0 when both numerator and denominator vanish. Then 0≤v≤1 and ∫vρ_y=δ. If an atom is crossed, the same fractional value is used on its whole mass level; no physical receiver cube or selector atom is cut or moved. If active U_y(Km_u)>δ, necessarily Km_u<z_y. Hence this SAME v is entirely inside every active strict upper tail, and its integral there is δ. The price

    t_y(w)=M_price(y)v_y(w)/δ

is feasible simultaneously for almost every active input and has cost exactly M_price. Because a≤λ and U≤J, 0≤M_price≤λJ; this price may be taken bounded by λ/ε. If J=0 there is no active traffic; set M_price=t=0 without division.

All quantities can be selected jointly measurably. U,V and J are jointly measurable by Tonelli. The mass quantile is determined by rational sublevel sets of U. The essential supremum is measurable since {M_price>s} is detected by a positive ρ_y integral of 1_{active,aU>s}. The fractional atom coefficient is a measurable quotient with the stated zero convention. No receiver-dependent favorable source law or private new field is introduced.

This pricing identity alone is not a bound on the original cost by M_price. Applying any feasible price to the original traffic requires the upper-column integral:

    ∫active aρ_y
       ≤∫t(w)[∫active,m_u<m_w/K ρ_y(du)/U_u]ρ_y(dw)
       ≤L_ε∫tρ_y.

Thus it yields G_y≤L_ε M_price, not an unsupported G_y≤M_price. For the soft-paid multiplier, esssup a_paid U≤τ_score, recovering the established same source fee. No general estimate of the untruncated M_price or the remaining soft cost has been proved. A common-tail LP identity is not by itself additional root progress beyond its verified use with that bound.

## 4. Ledger and evidence boundary

For the soft replacement ALONE, the R347 residual is replaced by the full soft decomposition above with the SAME C_hit W_ex and no extra X. Its conditional receiver coefficient remains 13/36 and, with the same authenticated CZ account, 841/2304. The later actual-clock extension at the end of this file adds its explicitly stated independent receiver charge; these earlier coefficients are not the final combined total after that extension. This screen does not reauthenticate all historical outer aggregation or price the soft/general/history/extreme-scale complements. The remaining original soft-scored traffic still requires a general joint budget.

Actual local Python Fraction diagnostics executed for this screen: 878 common-tail/score assertions with 177 abstract score-only input terms, and 96 exact soft-split/quadratic assertions. They checked atom-fractional top-rank mass, strict-tail support, simultaneous price feasibility, price cost, old-hit containment and soft algebra. These 974 assertions are finite scalar mechanics, not actual cube/history traffic or a general existence/strict-progress certificate. They are separate from all primary runs and no R348 author pipeline has been read or rerun.

## Necessary inherited bindings
- `/tmp/r347_geometry.md` — SHA256 `ac4e9b38400df1591d4f77bd289d13b08dc106167e7a173cc5daa0cb04c5d509`
- `/tmp/r347_core.md` — SHA256 `d176f8b75bbfe4a28ed41ce942ad5e51b7dbd109a8a299a62e61b89fe36184a1`
- `/tmp/r347_audit.md` — SHA256 `446bd80338554b547149d650da24fc24593df6d74aa49e537958ca1720a70f9d`
- `/tmp/r346_geometry.md` — SHA256 `54c86eed5a889c94fc6568c455dd43ffd979894b82acf1c2b9772def18d26570`
- `/tmp/r346_core.md` — SHA256 `6536c1eccf98ab90e7160022f3140e83f505d23010987421fa95cd1c54e604ed`

## Independent extension screen: original-clock prefix-upper absorption

This extension was screened before reading any R348 author proof. It is a new, complementary actual-clock payment, rather than another proof of the soft source deduction.

At fixed source y and large endpoint u, let U_u=ρ_y{m_w>Km_u}. The actual receiver-volume estimate

    ∫_{m_w>Km_u}(m_u/m_w)ρ_y(dw)≤2/(Kq_-)

is valid. Set z=(2||w-y||∞)^n. Capture and the upper mass condition bound the integrand density by m_u/max(Km_u,q_-z)^2 over actual dw. Integrating this envelope on z∈[0,∞) yields 1/(Kq_-) on either side of z=Km_u/q_-. Original receiver/radius restrictions only reduce it. This estimates a true mass-tilted receiver integral, with no source density cap.

Define the genuine physical-prefix upper occupancy

    U_y^r(Km_u)=ρ_y{m_w>Km_u,R_w≤r}.

Since K>λ/q_-, all such w have R_w>R_u. The probability measure R_u^n ell restricted to [R_u,b] has total mass one and gives probability (R_u/R_w)^n to r≥R_w, including R_w=b and the original terminal atom. Tonelli therefore gives

    E_clock[U_y^r(Km_u)]
       =∫upper (R_u/R_w)^nρ_y(dw)
       ≤(λ/q_u)∫upper(m_u/m_w)ρ_y(dw)
       ≤2λ/(q_uKq_-).

Markov's inequality at the actual threshold 1/q_- yields

    P_clock{U_y^r(Km_u)>1/q_-}≤2λ/(q_uK).

Keep every original gate in Ω and any measurable 0≤η(y,u)≤1. Positively using Ωη≤1, then integrating any unchanged exterior source 0≤g≤f, bounds the original traffic restricted to this clock event by

    ∫_E du R_u^(-n) [2λ/(q_uK)]∫Q_u g
       ≤2λ|E|/K≤γ_nX_q,
    γ_n=2λ/(q_-K)=(8/3)exp(-√n).

This bound pays an original positive clock subbranch, not transported traffic at an altered time or a mass-tilted surrogate. Source integration uses the original identity m_u=q_uR_u^n. No terminal atom is dropped and no artificial clock atom is inserted at the threshold.

It may be applied after the soft source deduction. Where a>0 let η=(1-τ_score/(aU))_+, and put η=0 at a=0. Multiplying the OLD original clock integrand by this source–u factor realizes aη=(a-τ_score/U)_+ exactly. Its part with prefix upper occupancy >1/q_- receives the γ_nX_q fee. Its complementary clock event U_y^r(Km_u)≤1/q_- remains fully present, with the soft deduction, full current J, original source, old endpoints and all other gates. The source-paid part and this residual-clock payment are disjoint in this sequential accounting.

Smallness of γ_n requires the original high-past support; it is NOT a numerical inequality in every dimension. A nonzero original high-past row has

    A_n> (1+√n)/ε,
    A_n=1+nlog(b/a)≤1+n.

Writing x=√n, if εx≤1, then ε(1+x²)≤ε+x<1+x, a contradiction. Thus nonempty original traffic forces x>1/ε. At the prescribed ε=119/3072, let t=1/ε>25. The elementary positive exponential series gives exp(t)>t^4/24, hence on these nonempty dimensions

    γ_n<(8/3)exp(-t)<64/t^4<ε/16,

where the last inequality is the exact rational statement t³>1024. In lower dimensions the original high-past traffic is empty, so this branch costs zero even when the bare formula γ_n is not small. It is safe to use εX_q/16 as a uniform ledger allocation with this dichotomy. Alternatively retain γ_n only on the actual nonempty dimension range. No source or current-prefix field may be recomputed to obtain that dichotomy.

Accordingly this extension, unlike the earlier soft replacement alone, adds a small independent receiver fee. A final ledger must explicitly replace the relevant residual with its clock split and add the resulting outer-multiplied γ_n (or ε/16 allocation); the R346/R347 receiver total is no longer the entire account after this added payment. It still does not price the complementary residual or close the general problem.

An actual local Fraction run passed 44 exact checks for the two-piece radial integral, inclusive clock-tail/Fubini identity and rational exponential-majorant arithmetic. These are analytic/mechanics diagnostics, not a nonempty original root G simulation. They are additional independent checks, separate from all primary runs.
