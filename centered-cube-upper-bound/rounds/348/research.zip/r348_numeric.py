#!/usr/bin/env python3
"""R348 soft paid truncation and common-tail LP: abstract atomic diagnostics."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def logbounds(x,N=64):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=logbounds(1/x,N);return -hi,-lo
 k=0
 while x>2:x/=2;k+=1
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));hi=lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 if k:
  a,b=logbounds(F(2),N);lo+=k*a;hi+=k*b
 return lo,hi

def fixtures():
 return [('initial','zero_measure',F(3,2),[(F(1),F(0))]),('initial','one_atom',F(1),[(F(1),F(3))]),('initial','small_unequal',F(3,2),[(F(1),F(1)),(F(3,2),F(1,2)),(F(2),F(3,2)),(F(4),F(1))]),('initial','separated32',F(3,2),[(F(2**i),F(1)) for i in range(32)]),('boundary_stress','repeated64_exact_K_edge',F(2),[(F(2**i),w) for i in range(64) for w in [F(1,3),F(2,3)]]),('boundary_stress','integral_branch_equality',F(1),[(F(1),F(1)),(F(3),F(3))]),('boundary_stress','heavy_atom',F(2),[(F(2**i),F(100) if i==8 else F(1)) for i in range(16)]),('boundary_stress','exact_K_ratios',F(3,2),[(F(3,2)**i,F(1)) for i in range(32)]),('expanded','separated128',F(3,2),[(F(2**i),F(1)) for i in range(128)]),('expanded','wide256',F(100),[(F(10**i),F(1)) for i in range(256)]),('expanded','unequal128',F(8),[(F(2**i),F(1+i%3,8)) for i in range(128)]+[(F(1),F(0)),(F(2**129),F(0))])]

def prepare(stage,name,K,atoms):
 before=sum(C.values());groups={}
 ck('positive_locations_nonnegative_original_weights',all(m>0 and w>=0 for m,w in atoms))
 for m,w in atoms:
  if w:groups[m]=groups.get(m,F(0))+w
 masses=sorted(groups);J=sum(groups.values(),F(0));critical=set(masses)|{m/K for m in masses};B=max((sum((w for m,w in groups.items() if t<=m<=K*t),F(0)) for t in critical),default=F(0));Top=[m for m in masses if m>=masses[-1]/K] if masses else [];topmass=sum((groups[m] for m in Top),F(0));ck('closed_Top_capacity',topmass<=B)
 future={m:sum((w for x,w in groups.items() if x>K*m),F(0)) for m in masses};Utop={m:sum((groups[x] for x in Top if x>K*m),F(0)) for m in masses};Lambda=F(1);tau=2*Lambda*B;rows=[]
 for eps in [F(119,3072),F(1,8),F(1,4)]:
  delta=eps*J;active=[m for m in masses if future[m]>delta];hardy=sum((groups[m]/future[m] for m in active),F(0));Llo,Lhi=logbounds(1/eps);Llo+=1;Lhi+=1
  if not J:Ilo=Ihi=F(0)
  elif B<=(1-eps)*J:
   a,b=logbounds((J-B)/delta);Ilo=B/delta+a;Ihi=B/delta+b
  else:Ilo=Ihi=(1-eps)/eps
  ck('frozen_original_Hardy_column',hardy<=Ilo<=Ihi)
  small=bool(J and B<=delta)
  if small:ck('small_window_log_bound',Ihi<=Llo)
  # Top delta submeasure, with at most one partially selected mass location.
  remain=delta;sigma={m:F(0) for m in masses}
  for m in reversed(masses):
   take=min(remain,groups[m]);sigma[m]=take;remain-=take
  ck('common_tail_candidate_total',remain==0 and sum(sigma.values(),F(0))==delta)
  ck('common_tail_candidate_dominated',all(0<=sigma[m]<=groups[m] for m in masses))
  ck('common_tail_at_most_one_fractional_block',sum(0<sigma[m]<groups[m] for m in masses)<=1)
  for m in active:ck('common_tail_every_active_row_hit_exactly_delta',sum((sigma[x] for x in masses if x>K*m),F(0))==delta)
  for mode in ['one','varying_small']:
   oldpaid=oldres=softpaid=softres=original=square=F(0);stats=Counter();certs=[];allrows={}
   for index,m in enumerate(masses):
    a=Lambda if mode=='one' else F(1,8+index%3)
    ck('frozen_row_a_within_lambda',0<=a<=Lambda)
    if m not in active:continue
    U=future[m];ptop=Utop[m]/U;pay=min(a,tau/U);res=a-pay;opay=a if ptop>=F(1,2) else F(0);ores=a-opay;bound=a*a*U/(4*tau);score=a*U/tau
    ck('soft_row_exact_split',pay+res==a and 0<=pay<=a and res>=0)
    ck('soft_row_square_residual',res<=bound)
    ck('soft_paid_below_Hardy_row',pay<=tau/U)
    ck('soft_dominates_old_Top_payment',pay>=opay and res<=ores)
    if ptop>=F(1,2):ck('old_Top_hit_has_zero_new_residual',U<=2*Utop[m]<=2*B and res==0)
    if opay==0 and pay==a and a>0:stats['new_full_paid_nonTop_rows']+=1
    if score>1:
     ck('high_score_strict_soft_reduction',0<pay<a and 0<res<a);stats['partial_high_score_rows']+=1
    if score==2:ck('square_bound_exact_at_score2',res==bound)
    w=groups[m];original+=w*a;oldpaid+=w*opay;oldres+=w*ores;softpaid+=w*pay;softres+=w*res;square+=w*bound
    allrows[m]=(a,pay,res)
    if len(certs)<4 and (opay==0 or score==2):certs.append(dict(m=str(m),rho_weight=str(w),a=str(a),U_Km=str(U),pTop=str(ptop),score=str(score),old_paid=str(opay),soft_paid=str(pay),soft_residual=str(res),square_upper=str(bound)))
   # Verify at every original positive-weight atom, not merely after aggregation.
   for m,w in atoms:
    if w>0 and m in active:
     a,pay,res=allrows[m];ck('original_positive_atom_split_a_e',pay+res==a and res<=a*a*future[m]/(4*tau))
   ck('aggregate_old_and_soft_conservation',original==oldpaid+oldres==softpaid+softres)
   ck('aggregate_residual_improvement',softres<=oldres and softres<=square)
   ck('aggregate_paid_Hardy_integral_budget',softpaid<=tau*hardy<=tau*Ilo)
   # Exact finite-instance check even outside the original small-window contract.
   ck('finite_instance_tau_Log_budget',softpaid<=tau*Llo)
   if small:ck('small_window_analytic_payment_contract',softpaid<=tau*Llo)
   # Actual common-tail LP: t>=0 has NO upper-density constraint.
   optimum=max([F(0)]+[allrows[m][0]*future[m] for m in active])
   z={m:(optimum/delta*sigma[m] if delta else F(0)) for m in masses}
   density={m:z[m]/groups[m] for m in masses}
   ck('common_LP_nonnegative_unbounded_density',all(t>=0 for t in density.values()))
   ck('common_LP_objective_exact',sum(z.values(),F(0))==optimum)
   for m,w in atoms:
    if w>0 and m in active:
     hit=sum((z[x] for x in masses if x>K*m),F(0))
     ck('common_LP_every_original_positive_atom',hit==optimum and hit>=allrows[m][0]*future[m])
   witness=next((m for m in active if allrows[m][0]*future[m]==optimum),None)
   if witness is not None:ck('common_LP_matching_max_row_lower_bound',sum(z.values(),F(0))==allrows[witness][0]*future[witness])
   else:ck('common_LP_empty_active_optimum_zero',optimum==0)
   rows.append(dict(epsilon=str(eps),omega_mode=mode,lambda_='1',tau=str(tau),J=str(J),closed_window_B=str(B),small_window_contract=small,active_blocks=len(active),original_total=str(original),old_Top_paid=str(oldpaid),old_Top_residual=str(oldres),new_soft_paid=str(softpaid),new_soft_residual=str(softres),new_soft_residual_decimal=float(softres),old_Top_residual_decimal=float(oldres),paid_gain=str(softpaid-oldpaid),square_residual_upper=str(square),tau_HardyI_lower=str(tau*Ilo),tau_L_lower=str(tau*Llo),stats=dict(stats),selected_row_certificates=certs,common_tail_LP=dict(delta=str(delta),base_v_submeasure={str(m):str(z) for m,z in sigma.items() if z},optimal_value=str(optimum),matching_max_requirement_row=str(witness) if witness is not None else None,t_density={str(m):str(t) for m,t in density.items() if t},target_measure={str(m):str(z) for m,z in z.items() if z},max_t_density=str(max(density.values(),default=F(0))),has_density_above_one=any(t>1 for t in density.values()),active_empty=not bool(active),base_v_fractional_blocks=[str(m) for m in masses if 0<sigma[m]<groups[m]],scope='min integral t rho, t>=0 WITHOUT t<=1, each active upper tail integral t rho>=a_u U_u. Exact optimum=max aU, t=(M/delta)v using common top-delta v; maximal row supplies matching lower bound. Empty active optimum0.')))
 return dict(stage=stage,name=name,K=str(K),atoms=[[str(m),str(w)] for m,w in atoms],J=str(J),B=str(B),rows=rows,exact_checks=sum(C.values())-before,scope='Pure finite atomic rho, not actual cubes/du or original highpast/clock. Row a=q omega is diagnostic q1 and frozen omega; no geometric realization claimed.')

def main():
 models=[];stages=[]
 for stage in ['initial','boundary_stress','expanded']:
  before=sum(C.values())
  for args in fixtures():
   if args[0]==stage:models.append(prepare(*args))
  stages.append(dict(name=stage,exact_checks=sum(C.values())-before))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='R348 paid soft truncation and common-tail LP only; previous unweighted target-set optimization was superseded and is not implemented. Atomic evidence and exact rational/log interval checks, no cube/root/history claim; display decimals diagnostic.')
 (BASE/'r348_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),stages=stages),sort_keys=True))
if __name__=='__main__':main()
