# R348 — soft paid truncation and the common-tail LP

This is the replacement R348 task. The earlier proposed unweighted target-set optimization is **not implemented**. All 11 models are finite atomic measures, not actual cube receiver fields, receiver dx, original high-past traffic, or a physical clock. The calculation preserves diagnostic row weights instead of inferring a geometric bound from atoms.

## Frozen model and new receipt

For each model, rho is a finite positive measure on positive masses, J=rho(E), `U_u=rho{m>K m_u}`, and B is the exact supremum of the **closed** K-window rho[t,Kt]. B is recomputed at every critical endpoint m_i or m_i/K. The fixtures reproduce the R347 atomic inputs self-contained: zero measure, one atom, unequal small atoms, separated32, repeated64 with an exact K boundary, integral-branch equality, heavy atom, exact K-ratios, separated128, wide256, and unequal128. Repeated mass locations are grouped for arithmetic, then every original positive-weight atom is checked separately.

Use epsilon=119/3072,1/8,1/4 and the strict active condition U_u>epsilon J. Lambda=q=1 diagnostically. For each model the row a=q omega is fixed across epsilons, either a=1 or the varying small `a=1/(8+rank mod3)`. It is not recomputed after routing. Let

`tau=2 Lambda B`, `paid_u=min(a_u,tau/U_u)`, `residual_u=(a_u-tau/U_u)_+`.

All original totals use rho-weighted rows. The code verifies, at every original positive-weight active atom:

- paid+residual=a exactly;
- paid<=tau/U, and `residual<=a² U/(4tau)`;
- on score `aU/tau>1`, the payment is strictly positive and strictly smaller than a, while residual is strictly below a;
- at score2 the quadratic residual bound is exact.

The square bound is equivalent to `(aU/tau-2)^2>=0` in the positive-residual regime. Zero measure and inactive zero-future rows are handled without dividing by zero.

The old Top set is closed, `Top={m>=Mmax/K}`, and has rho-mass at most B. The old route pays a full row when pTop=rho(Top intersect upper_u)/U_u>=1/2. Such a row has U_u<=2rho(Top)<=2B, so tau/U_u>=Lambda>=a_u: its new residual is zero. Hence the new soft payment dominates the old Top payment **row by row**, not merely after summing.

For the paid total the script checks `P<=tau C<=tau I`, where C is the unchanged atomic Hardy column and I its certified shifted-survival integral. On B<=epsilon J it also uses the analytic `I<=L_epsilon=1+log(1/epsilon)`. A direct outward-rational check P<=tau L_epsilon additionally passes every registered finite example outside that small-window condition; that observation is not promoted into a new general theorem. No float inequality certifies these comparisons.

## Correct common-tail LP (no t<=1 constraint)

The LP tested here is the actual core version:

`min integral t rho`, subject to `t>=0` and

`integral_{m>K m_u} t rho >= a_u U_u` for every active positive-weight row.

**There is no upper bound t<=1.** Put delta=epsilon J and `M=max_active a_u U_u`. A descending quantile construction provides a base density v in [0,1] of total rho-mass delta, with at most one partially used mass atom. Because every active upper tail has mass strictly greater than delta, this entire base v lies in each such upper tail. Thus

`t=(M/delta)v`

has total objective M and every active upper-tail integral exactly M, which is at least its required aU. A row attaining the maximum M supplies the matching lower bound on any feasible nonnegative t, so this is an exact finite primal/lower-bound optimality certificate. The empty active problem has optimum0 and t=0; the zero-J case needs no division. The base v<=1 is only an intermediate construction and is **not** a constraint on the final LP density.

The script verifies all constraints at every original positive-weight atom, including repeated locations. Large final densities actually occur: separated32 at the primary epsilon and a=1 has M=31 and `max t=2976/119>1`; capping t at1 would invalidate this certificate. The JSON stores v as its rho-submeasure, t as its density, and t rho as its target measure, with explicit field names.

## Three stages and actual results

Two fresh independent processes passed **29,583 exact rational/interval checks**: initial1,712, boundary5,324, expanded22,547. These include exact source/row arithmetic and outward rational log comparisons; logarithms are not claimed to be evaluated exactly. Decimal values below are ordinary display conversions.

At epsilon=119/3072:

| Model | a | old Top residual | new soft residual | new paid | original total |
|---|---|---:|---:|---:|---:|
|separated32|1|29|23.945509609|6.054490391|30|
|separated32|varying small|3.261111111|0.405170210|2.955940901|3.361111111|
|repeated64|1|58|47.483761782|12.516238218|60|
|repeated64|varying small|6.511111111|0.786943624|5.935278598|6.722222222|
|separated128|1|123|116.315997481|6.684002519|123|
|wide256|1|244|224.298328706|19.701671294|244|
|unequal128|varying small|3.117708333|0.211674618|2.986936494|3.198611111|

Newly paid rows are nonempty. With varying-small a, separated32 has 17 formerly nonTop rows newly paid in full and12 high-score rows paid partially. Unequal128 has73 new full rows and43 partial high-score rows. With a=1, all29 nonTop active rows in separated32 receive a positive partial payment. The heavy-atom model pays every active row fully under the new truncation, while the old Top route pays none there; it has large B and is not presented as an actual small-window/root case.

The common-tail LP also changes with a while keeping rho unchanged:

| Model | M at a=1 | M at varying-small a |
|---|---:|---:|
|separated32|31|31/8|
|repeated64|62|31/4|
|separated128|127|127/8|
|wide256|253|253/8|
|unequal128|31|31/8|

The data support the new receipt positively: it pays old Top rows and additional rows, and clips even high scores. They also show why dropping the original a is costly: with the same mass measure, the remaining weighted high-score expense differs substantially. The exact LP value M records a maximum weighted tail requirement, not a geometric root budget. No dimension exponent is fitted and no finite-atomic result is claimed to realize the original cube geometry.

## Reproduce

Only `r348_numeric.py`, `r348_numeric_result.json`, and this note are needed. Standard library only, no optimizer or historical /tmp imports:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r348_numeric.py
```

The JSON is written beside the script and includes all atomic inputs, original/old/new totals, quadratic bounds, selected row certificates, and exact common-tail LP witnesses. Runtime is under a second on the local bundled Python.
