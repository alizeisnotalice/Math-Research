# R367 independent final audit

Status: FINAL PASS for the actual G union-capacity receipt, native physical-clock identity, positive-volume witness in the stated alternative route, final integration and evidence scope. Only this audit file is reviewer-owned. General weak-type/root closure, a fresh whole-history audit, and first-ever coverage across every historical alternative are NOT certified.

## 1. Independent proposition screen and exact contract
Freeze the real measurable finite-Lebesgue-measure receiver E, full f>=0 in L1, actual R in[a,b], b<=2a, m=f(Q)=qR^n and q_-=3lambda/4<=q<=lambda. Keep original Er, mu=du/m, full J, original J>=H, global strict mass past Z_y(m_u/K-)>sqrt(n)/q_- and inclusive physical clock ell, with K=e^sqrt(n). The remainder G has ordered loss m_u-m_v on m_u>K m_v. Since K>lambda/q_-, its large mass endpoint is also its strictly larger radius endpoint. This positive mass-difference is the actual object paid below, NOT the full symmetric-difference variance.

Define e_j=(2|u_j-v_j|-(R_u-R_v))_+, h_N=a log(n+2)/(2n), t_n=a log(n+2)^2/(16n). N has max e<=h_N; A has sum e<=t_n, including equalities. For fixed large u, R_v>=a implies (2|u_j-v_j|-(R_u-a))_+<=e_j. Therefore eligible small centers lie in the cube of side L=R_u-a plus an l1 ball of radius t/2. Partitioning centers by the k coordinates outside the cube and their signs gives EXACT volume sum binom(n,k)L^(n-k)t^k/k!. This handles L=0,t=0; no arbitrary source f mass is estimated by volume. All coordinates and all sign choices are already included, so no dimension factor or combinatorial cost may be omitted or appended.

With 0<=L/a<=1, divide only by the actual receiver mass lower bound q_-a^n. The capacity polynomial is <=sum (nt/a)^k/(k!)^2<=exp(2sqrt(nt/a)), because the positive square of the exponential series contains every diagonal term. At t=t_n this is sqrt(n+2). Thus A small-end mu capacity is <=sqrt(n+2)/q_-. The N capacity has the same bound by the R366 center cube. These are true center-du estimates, not product assumptions on f.

## 2. Direct G receipt and union replacement
In G, m_u-m_v<=m_u. Integrating the small endpoint capacity, then using m_u mu(du)=du at the LARGE endpoint, gives row<=CV/J with C=sqrt(n+2)/q_- for A or 2sqrt(n+2)/q_- for N union A. Independently the same restricted positive G row is <=V because the small endpoint's full capture integral is J. No weighted-volume tau term is required: that term belongs to a bound on the full symmetric difference m_u+m_v, whereas this receipt directly bounds the one-sided mass difference by m_u. The receipt here does not expand the original square again.

Start from original G_high BEFORE the previous N split and use the exact positive partition G_high=G_union+G_tail, with tail notN AND notA. Union capacity may double-bound overlap in an upper estimate, but the original union integral counts each tuple only once. One auxiliary threshold T=2sqrt(n+2)/(q_-epsilon1), retaining the original H and full J, yields G_union<=epsilon1 X_q+8sqrt(n+2)W/(3epsilon1). The strict-low-T clock lemma charges lambda T W once; equality belongs high, an entire radius atom crossing T is excluded, and the original b atom is retained in the full first moment. No original threshold, source or history qualification is reset.

This union receipt REPLACES the R366 N epsilon/source line. The standalone A-minus-N receipt epsilon X_q+4sqrt(n+2)W/(3epsilon) is a different sequential accounting choice and is not added to the union receipt. Nor may a smaller newly bounded remainder simply replace an old upper-bound remainder without rebuilding the original positive partition; the author explicitly rebuilds from G_high. The final tail retains all original masks plus max e>h_N and sum e>t_n. No uniform covered fraction is proved.

When log(n+2)<=8, t_n<=h_N and A subset N, so the new route coverage is empty. When log(n+2)>8, single-coordinate excess strictly between these thresholds yields an open A-minus-N geometric region. The general scalar fact log(n+2)<2sqrt(n) for n>=1 makes t_n<a/4, so the displayed large/small cube realization can have positive intersection. Positive original high-J/high-past traffic requires the additional shared-f verification below; geometry alone is not sufficient.

## 3. Author proof review and native clock auxiliary
Read /tmp/r367_geometry.md and /tmp/r367_transport.md in full after the independent screen. PASS. The geometry proof preserves full actual m,q,J and source y, strict mass/past gates and physical r. It uses no density cap, source-coordinate independence or private pairwise selector.

For transport D_r^chi symmetric in its two actual receivers, P_r(u,dv)=D_r(u,v)mu(dv)/m_u satisfies du P_r=D_r mu(du)mu(dv), so du is reversible and subinvariant. Full row mass is g_r(Q_u)/m_u<=1. A symmetric y-dependent high-past/notN restriction preserves row SUBprobability and du detailed balance but not the full row equality or PSD automatically. The exact original G is one half of integral |m_u-m_v| against the restricted conductance; no orientation factor is lost. The auxiliary note analyzes the pre-union notN residual; a further symmetric notA restriction would preserve the algebra, but no new payment is asserted.

For L_r(u)=log(lambda r^n/m_u), substitute t=n log(r/R_u) in the original normalized clock including its terminal atom: its total mass is1 and its first t moment is1-(R_u/b)^n. Hence integral_[R_u,b] m_u L_r ell=q_u[log(lambda/q_u)+1-(R_u/b)^n], including R_u=b. Native integrated cost is <=[1+log(lambda/q_-)]X_q, with no n factor. All quantities are finite from the finite band and row cap. Entropy dissipation equals C_cross-S_native, not their sum or reverse difference. The proved native upper bound cannot pay the POSITIVE unproved cross potential. Reversibility for du does not imply subinvariance of m_u du. The square-root energy is comparable to the same unpaid G and creates no receipt. The coarse optional clock estimate(13) and the stronger bounded-L estimate are honestly labeled receiver bounds, not source-root prices.

## 4. Actual positive-volume witness
Read /tmp/r367_witness.md, final witness script and result JSON in full. PASS for n=10000,a=1,b=2,lambda=4/3,q_-=1,f=1_[-3,3]^n. The continuum baseline R0=max(1,2||w||inf+2delta) on E=[-.75+delta,.75-delta]^n lies in[1,1.5]. Its replacement R=2 on the tiny U box preserves measurable actual radii, full-f masses R^n and q=1; every selected cube lies inside the support. Every y in Y is captured by ALL receivers, including U. Both U,V have positive volume and baseline R0=1, while actual R=2 on U and1 on V.

Their first-coordinate excess is e0 plus/minus4rho and all other excesses vanish. Rational exponential-series bounds certify9<log10002<19/2; the rational margins give h_N<e0-4rho and e0+4rho<t_n on the entire product U times V. The e-series lower8/3 and upper87/32<11/4 are valid (tail from the1/24 term bounded by the geometric ratio1/5), and the stated integer powers certify the log bracket without floating-point decisions. Thus the geometry is strictly A-minus-N with room for whole-box perturbations.

The baseline radius pushforward has a radius1 block and exact density n(r-2delta)^(n-1) on[1,1.5]. Its weighted capacity is >=n(1-2delta)^(n-1)log(1.5)>49n/150. Removing U costs |U|<1 because its baseline radius is1. Every receiver outside U has m<=1.5^n<2^n/e^100, using (4/3)^4>3>e. Therefore these receivers belong to the STRICT global mass past of U, giving Z>49n/150-1=9797/3>h_past=100 and >H=310272/119. At r=b, J>=Z>H, so the high-J/past, strict mass gap, actual common-source capture and both receiver geometric gates all hold on Y times U times V. A finite radius-menu diagnostic has not been substituted for this continuum field.

The upper J<=1+n log2<1+n gives exactly the displayed lower bound from the b atom: 2^-n |Y||U||V|(2^n-1)/[2^n(1+n)]>0. Both factors2^-n are required: one is clock mass and the other is1/m_large in the receiver measure. No full-beta exterior integral or missing source atom is approximated. This is a genuine positive-volume witness for the original G branch within the337→366→367 ALTERNATIVE route, not merely an incidence diagram. It is not an R355 Fshell/path witness, a useful uniform fraction, a general upper bound or first-ever payment across the union of all historical alternatives. The added main/witness limitation is correct: an older finite-dimensional route may already control this dimension's hard slot at a larger constant, and cannot be added to this route.

## 5. Final integration, evidence and remaining obligations
Read /tmp/r367_main.md, /tmp/r367_ledger.md and /tmp/r367_numeric.md in full. The final priority bound is B_H(f,nu)<=G_tail+(epsilon0+epsilon1)X_q+[F337+8sqrt(n+2)/(3epsilon1)]W, nu<=f, with unchanged F337 and h=sqrt(n)/q_-. Original entrance8lambda H W+2d_eff A_n W_nu/H+2B_H supplies factor2 on every new term, then outerLambda=128/119 on the whole bound. The receive coefficient is2Lambda(epsilon0+epsilon1), with no asserted global absorption room. The oldN fee and standalone newA fee are not appended. All original H/d_eff costs, soft/crossing, extreme-scale/lowpe, historical initial/deletion/future source atoms, source/physical-scale/outer aggregation and limit obligations remain. The historical ledger is preserved as alternatives only. General G_tail and weak-type/root closure remain unproved.

Read the final geometry/transport standalone scripts and confirmed each matches its author embedded code up to whitespace. Parent reports actual fresh geometry2000 Fraction checks, transport516 checks=360 Fraction detailed-balance/row assertions plus156 ordinary65-digit Decimal clock/entropy/square-root diagnostics, and witness17 Fraction checks. Total parent asserted checks2533=2377 Fraction+156 Decimal. The witness's11-dimension70-digit Decimal sweep is separate diagnostic output, not an outward-rounded certificate or an extra set of rigorous inequalities. The final witness output path uses its own script directory and the parent reports an actual rerun after that portability change. No full pipeline was needlessly rerun by the reviewer.

The geometry2000 checks verify actual-center inclusion and finite mixed-volume coefficients, not the full high-past field. Transport matrices verify reversible algebra only, not an actual cube/source geometry realization. The witness's real continuum proof and finite rational margins, rather than Decimal sweep fitting, certify its actual difficult gates. No numerical result is promoted into a general geometric estimate.

Final PASS does not independently certify the main's PDF/skill-reading records, comprehensive historical novelty, TeX compilation, ZIP packaging integrity or Git state. No other author or repository file was modified.

## Final SHA256 bindings

- `/tmp/r367_geometry.md` — `a06bf047a10a94095b7882decf1397380dd5563c2ff4957a2685c7655963c550`

- `/tmp/r367_transport.md` — `3a8d0ec4127a1dfb7026b29f0795d900924b9716ab57e050dad56361537493a1`

- `/tmp/r367_witness.md` — `e678583557cd4e1841010396eaf4e602da01aa94eac1afcd6388c0dce3ec23c5`

- `/tmp/r367_main.md` — `cb175d54e8248ffa7d0c322ed8b05e2f161d0c42e4581b1710c3057793f54371`

- `/tmp/r367_ledger.md` — `530c22b9e009f333f51b3b62c74dfecca366310e75386f047a3cee2102fea470`

- `/tmp/r367_numeric.md` — `e03f69369a12b9aa23632b8130b63b8059ec6c1f8455f2b6fa2d259939f82e20`

- `/tmp/r367_geometry_check.py` — `032e85ff5bcef40239abb6b561b40bc8bc84a9101645728d24f89dcbf2c27509`

- `/tmp/r367_transport_check.py` — `cf7f3929024bcf2ca632f198809a9e56f11961e1084cc22bff43e6ac0bbaa4f6`

- `/tmp/r367_witness_check.py` — `deb0734ee7d55ccc254a66a69293199efa9fb1c29a8f438f6d83406ddf149d2f`

- `/tmp/r367_witness_result.json` — `7c95d644bd2c15543d3b68169ef550eeb2f62c67d92b775e75be716b2b933604`

- `/tmp/r366_audit.md` — `f03540c25fce39b3ade54253b884621b76a88c486525ddb487afa647b5f86536`

- `/tmp/r366_ledger.md` — `d5656bab86d7261f82460f51aac82397b098d2435c059be5840fff9427f7219d`

- `/tmp/r337_main.md` — `e7ae785f3a751e5fcd9e45521e78b2103b3e79ecee67ba0be17822fb31b98768`
