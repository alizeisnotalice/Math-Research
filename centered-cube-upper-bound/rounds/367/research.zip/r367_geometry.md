# R367 — A joint-coordinate sparse-protrusion branch of the true high-past remainder

**Result.** A new branch of the exact R366 remainder is payable. The preferred ledger receipt pays N union A together inside the original high-past G, with one low-clock split: G_union <= epsilon X_q + 8 sqrt(n+2)W/(3 epsilon). This replaces the R366 N receipt rather than being added to it. Section 4A states the exact union accounting. Separately, the new branch constrains the SUM of coordinate protrusions, rather than increasing the old uniform coordinate tolerance. A cube-plus-crosspolytope center envelope gives the precise capacity polynomial. For every epsilon>0 the newly retained branch satisfies

    G_new <= epsilon X_q + 4 sqrt(n+2) W/(3 epsilon).

This branch is intersected with the complement of the already-paid N, so no old pair is charged again. For log(n+2)>8 its geometric predicate reaches outside N on an open set; no fixed fraction of the difficult integral, and no complete global bound, is asserted. For log(n+2)<=8 the new branch is empty. The remaining original integral is specified exactly below.

## 1. Exact contract and screened claim

Use the same measurable Lebesgue receiver set E of finite measure, full f>=0 in L1, actual cubes Q_u with SIDE LENGTH a<=R_u<=b<=2a, and

    m_u=f(Q_u)=q_u R_u^n, q_-=3lambda/4<=q_u<=lambda,
    mu(du)=du/m_u, c_u(y)=1_(Q_u)(y), E_r={u:R_u<=r},
    J_r(y)=integral_(E_r)c_u(y)mu(du),
    V_r(y)=integral_(E_r)c_u(y)du,
    W=integral f, X_q=integral_E q_u du.

The unchanged clock is ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr, including its terminal atom. Let

    K=exp(sqrt(n)), h_past=sqrt(n)/q_-,
    Z_y(s-)=integral_E c_v(y)1_(m_v<s)mu(dv).

The exact current remainder is

    G_rem=integral ell(dr) integral f(y)1_(J_r(y)>=H)/J_r(y)
      integral_(E_r^2) c_u(y)c_v(y)(m_u-m_v)
        1_(m_u>K m_v) 1_(Z_y(m_u/K-)>h_past)
        1_(not N(u,v)) mu(du)mu(dv)dy.                  (1)

J=0 rows are zero. Since K>lambda/q_-, m_u>K m_v implies R_u>R_v, so u is also the actual larger-radius endpoint. Define its coordinate protrusion excesses by

    e_j(u,v)=(2|u_j-v_j|-(R_u-R_v))_+.

The frozen R366 geometric mask is

    N(u,v) iff max_j e_j(u,v)<=h_N,
    h_N=a log(n+2)/(2n).

This report screens and proves the following DIFFERENT joint-coordinate claim: for any t>=0, the actual smaller-receiver mu capacity under sum_j e_j<=t is controlled by the mixed-volume polynomial in (4), uniformly in the same larger endpoint u. This is a deterministic geometry bound for real receiver centers. It assumes neither independent f coordinates nor a source-density cap. It will be applied only to (1), including all its original gates.

## 2. Exact joint center envelope and volume

For fixed u let L=R_u-a>=0. If R_v>=a, then

    (2|u_j-v_j|-L)_+ <= e_j(u,v).

Hence sum_j e_j<=t implies v lies in

    C(u;L,t)={v: sum_j(2|v_j-u_j|-L)_+<=t}
            =u+[-L/2,L/2]^n+(t/2) B_1^n.             (2)

Here B_1^n is the unit l1 ball, and + is Minkowski sum. Equation (2) is an outer envelope only: it does not change any actual R_v, and the intermediate centers are not treated as receivers. Dropping the actual source-capture and mass-history restrictions enlarges this center domain, which is legitimate for the positive upper bound.

The exact Lebesgue volume is

    |C(u;L,t)|=sum_(k=0)^n binom(n,k)L^(n-k)t^k/k!.      (3)

Proof: partition almost every point by the subset of k coordinates lying outside the base cube and by their 2^k signs. The inside coordinates contribute L^(n-k). The nonnegative outside distances have sum<=t/2, a k-simplex of volume (t/2)^k/k!. Summing the disjoint pieces yields (3). The formula also covers L=0 or t=0 by continuity/direct interpretation. This is where all-coordinate geometry enters; union-bounding the exceptional coordinates loses the factorial gain.

By m_v>=q_-a^n, real Lebesgue receiver integration gives

    integral_(E: R_v<R_u, sum e_j<=t)c_v(y)mu(dv)
       <= P_n(L/a,t/a)/q_-,
    P_n(l,z)=sum_(k=0)^n binom(n,k)l^(n-k)z^k/k!.        (4)

One may retain any further actual positive restrictions in the left side. Since 0<=L/a<=1,

    P_n(L/a,t/a)
       <=sum_(k=0)^n (nt/a)^k/(k!)^2
       <=exp(2 sqrt(nt/a)).                             (5)

The first inequality uses binom(n,k)<=n^k/k!. For the second, the diagonal terms of the positive double series

    [sum_(k>=0) (sqrt(nt/a))^k/k!]^2

are the displayed infinite single series. Thus (5) is an analytic bound, not a numerical fit.

Unlike a coordinatewise expansion, this estimate permits the excess to be concentrated in a few coordinates and pays for the number of exceptional-coordinate configurations through the simplex-volume factor 1/k!. No source f mass was bounded by a geometric volume: only the REAL receiver-center measure dv was bounded before division by its actual mass lower bound.

## 3. Exact new branch and its payment

Fix

    t_n=a log(n+2)^2/(16n),
    A_n(u,v) iff sum_j e_j(u,v)<=t_n.

Define G_new by taking the original integrand (1) and adding 1_(A_n). Thus G_new retains not N, strict m_u>K m_v, strict global past, the same high-J gate, full f, and the original clock. It is not an independently reset or normalized transport.

Write g_new(r,y) for its inner pair integral divided by J_r(y), excluding f(y) and the high-J indicator. On this branch m_u-m_v<=m_u. Equations (4),(5) give, with

    C_n=sqrt(n+2)/q_-,

    g_new(r,y)
      <=(1/J_r(y)) integral_(E_r)c_u(y)m_u mu(du) C_n
      = C_n V_r(y)/J_r(y).                              (6)

The equality uses actual matching m_u mu(du)=du. There is NO +1 term needed here: the current remainder has positive mass-difference loss, and it is bounded directly by its larger-endpoint mass. We do not return to the symmetric difference to spend the old square again.

Independently, dropping all the smaller-endpoint restrictions after m_u-m_v<=m_u gives

    0<=g_new(r,y)<=V_r(y),                              (7)

because integral_(E_r)c_v(y)mu(dv)/J_r(y)=1 on J>0. Combining (6),(7),

    g_new<=V min(1,C_n/J).                              (8)

Apply the original low-clock lemma

    integral ell integral f 1_(J<T)V<=lambda T W,
    integral ell integral f V=X_q.                      (9)

For clarity, the first identity uses inclusive tail ell([R_u,b])=R_u^(-n), then q_u<=lambda and the cumulative radius mass retained by J_(R_u)<T being at most T. The entire atom crossing T is excluded. This is the existing lemma, not a new payment mechanism.

Choose the auxiliary clock threshold T=C_n/epsilon. On H<=J<T use (7),(9), and on J>=max(H,T) use (6),(9). The original H is unchanged. This proves

    G_new<=epsilon X_q+(lambda/q_-)sqrt(n+2)W/epsilon
          =epsilon X_q+4sqrt(n+2)W/(3epsilon).           (10)

This is one receipt for a previously uncharged subset of G_rem. It has no additional low-past charge and no near-mass charge.

## 4. New coverage and exact complement

The predicates N and A_n are different:

    N controls max e_j by h_N;
    A_n controls sum e_j by t_n;
    t_n/h_N=log(n+2)/8.

If log(n+2)<=8, A_n implies N, so G_new=0. If log(n+2)>8, choose excess vector (e,0,...,0) with h_N<e<t_n. This lies outside N and strictly inside A_n. Such inequalities are stable under small perturbations and are realized by actual cube pairs: take R_u=2a, R_v=a and center displacement ((a+e)/2,0,...,0), with a slight perturbation if desired. Because log(n+2)^2<4n for n>=1, t_n<a/4, so these cubes have positive intersection. Uniform full f on a containing box gives m_u/m_v=2^n>K for the dimensions under discussion.

This verifies genuine new geometric and mass-gap coverage, not an actual realization of every high-J/high-past gate or a lower bound on the fraction of G_rem covered. The payment (10) is valid whether or not a particular input f has mass in the new branch. No hard-domain realization is asserted without checking those source-dependent gates.

Let G_tail be exactly (1) with the additional indicator sum_j e_j>t_n. Then the full positive decomposition is

    G_rem=G_new+G_tail,
    G_rem<=G_tail+epsilon X_q+4sqrt(n+2)W/(3epsilon).      (11)

The remaining pairs satisfy BOTH max_j e_j>h_N AND sum_j e_j>t_n, as well as every original mass, past, common-source and high-J condition. G_tail is unpaid. This report does not derive the desired global budget for it.

If inserted after the frozen R366 receipt, (10) adds just its own epsilon X_q and 4sqrt(n+2)W/(3epsilon). It does not repeat the N charge, the R337 near-mass charge, or the old low-past charge. All independent original ledger interfaces remain as before.

## 4A. Preferred single union receipt — replace the prior N fee

For the final ledger, start from the original G_high=G_(K,>h) before the R366 N split. Define G_union by its exact original positive integrand with the geometric indicator 1_(N union A_n). Keep all original hard, common-source, strict mass and strict-past gates. Define G_tail by the complementary indicator 1_(not N and not A_n), agreeing exactly with the tail in (11). Thus

    G_high=G_union+G_tail.                              (12)

For fixed larger endpoint u, the N center capacity is already

    integral_(small v with N)c_v(y)mu(dv)
      <=[(b/a-1+h_N/a)^n]/q_-
      <=sqrt(n+2)/q_-.

The A_n capacity is (4),(5), also at most sqrt(n+2)/q_-. Their union therefore has capacity at most 2sqrt(n+2)/q_-. Overlap is simply upper-bounded twice at the capacity-estimation step; the original union integral itself counts each pair only once. No separate charge for the overlap is imposed.

Exactly as in (6)–(8), the union row obeys

    0<=g_union(r,y)<=V_r(y) min(1,2sqrt(n+2)/(q_-J_r(y))).

Use ONE low-clock split T=2sqrt(n+2)/(q_-epsilon) in (9). This proves

    G_union<=epsilon X_q+8sqrt(n+2)W/(3epsilon),
    G_high<=G_tail+epsilon X_q+8sqrt(n+2)W/(3epsilon).    (13)

The preferred substitution into the frozen R337 theorem is therefore

    B_H(f,nu)<=G_tail+(epsilon_0+epsilon)X_q
                   +[F_(337,epsilon_0,K,h_past)
                       +8sqrt(n+2)/(3epsilon)]W.        (14)

Here nu<=f and F_337 is exactly the inherited fee, unchanged. Formula (14) REPLACES the R366 near-containment line: do not append its old epsilon_1 X_q or its old N source fee. Likewise do not add the standalone new-branch fee (10) to (13). The standalone decomposition (11) and the preferred union decomposition (13) are alternative accounting choices. Geometry parameters h_N and t_n are fixed as above.

The genuinely enlarged geometric scope is A_n minus N; the final unpaid scope is not N AND not A_n, with all original source-dependent gates retained. Nothing in the union estimate asserts a fixed covered proportion of high-past G.

## 5. Actual local exact-arithmetic checks

The following code was actually executed and returned

    PASS {'center_envelope': 800, 'face_volume_polynomial': 160,
          'coefficient_bound': 1040} total 2000

These are deterministic seeded Fraction checks of the center inclusion and the finite face-volume/combinatorial algebra. They do not check an original high-past difficult input and do not replace the proofs above. The code is preserved here, with no separate file written.

```python
from fractions import Fraction as F
from math import comb,factorial
from itertools import product
from random import Random
rng=Random(367)
counts={'center_envelope':0,'face_volume_polynomial':0,'coefficient_bound':0}
for n in range(1,9):
  for z in range(100):
    a=F(1); large=F(rng.randrange(4,9),4)
    small=F(rng.randrange(4,int(4*large)+1),4)
    t=F(rng.randrange(0,9),16)
    v=tuple(F(rng.randrange(-20,21),16) for _ in range(n))
    exact=sum(max(F(0),2*abs(x)-(large-small)) for x in v)
    envelope=sum(max(F(0),2*abs(x)-(large-a)) for x in v)
    assert envelope<=exact
    if exact<=t:assert envelope<=t
    counts['center_envelope']+=1
for n in range(1,11):
  for L,t in product([F(0),F(1,4),F(1,2),F(1)],[F(0),F(1,8),F(1,4),F(1,2)]):
    face_sum=F(0)
    for bits in product([0,1],repeat=n):
      k=sum(bits)
      face_sum+=2**k*L**(n-k)*(t/2)**k/factorial(k)
    polynomial=sum(F(comb(n,k))*L**(n-k)*t**k/factorial(k) for k in range(n+1))
    assert face_sum==polynomial
    counts['face_volume_polynomial']+=1
    for k in range(n+1):
      assert F(comb(n,k))*L**(n-k)/factorial(k)<=F(n**k,factorial(k)**2)
      counts['coefficient_bound']+=1
print('PASS',counts,'total',sum(counts.values()))
```

Only /tmp/r367_geometry.md is written. Work stops after this precise paid branch and its unpaid complement.
