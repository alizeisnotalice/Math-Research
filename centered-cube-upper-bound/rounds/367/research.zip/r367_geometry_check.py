from fractions import Fraction as F
from math import comb,factorial
from itertools import product
from random import Random
rng=Random(367)
counts={'center_envelope':0,'face_volume_polynomial':0,'coefficient_bound':0}
for n in range(1,9):
  for z in range(100):
    a=F(1); large=F(rng.randrange(4,9),4)
    small=F(rng.randrange(4,int(4*large)+1),4)
    t=F(rng.randrange(0,9),16)
    v=tuple(F(rng.randrange(-20,21),16) for _ in range(n))
    exact=sum(max(F(0),2*abs(x)-(large-small)) for x in v)
    envelope=sum(max(F(0),2*abs(x)-(large-a)) for x in v)
    assert envelope<=exact
    if exact<=t:assert envelope<=t
    counts['center_envelope']+=1
for n in range(1,11):
  for L,t in product([F(0),F(1,4),F(1,2),F(1)],[F(0),F(1,8),F(1,4),F(1,2)]):
    face_sum=F(0)
    for bits in product([0,1],repeat=n):
      k=sum(bits)
      face_sum+=2**k*L**(n-k)*(t/2)**k/factorial(k)
    polynomial=sum(F(comb(n,k))*L**(n-k)*t**k/factorial(k) for k in range(n+1))
    assert face_sum==polynomial
    counts['face_volume_polynomial']+=1
    for k in range(n+1):
      assert F(comb(n,k))*L**(n-k)/factorial(k)<=F(n**k,factorial(k)**2)
      counts['coefficient_bound']+=1
print('PASS',counts,'total',sum(counts.values()))
