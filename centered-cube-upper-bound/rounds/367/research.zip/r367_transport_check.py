from fractions import Fraction as F
from decimal import Decimal,getcontext
getcontext().prec=65
cnt={'clock':0,'balance':0,'row':0,'entropy':0,'sqrt':0}
def ck(x,k):
    assert x,k
    cnt[k]+=1
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
for n in range(1,11):
  for R in [F(1),F(5,4),F(3,2),F(2)]:
    for q in [F(3,4),F(7,8),F(1)]:
      b=F(2);T=Decimal(n)*(dec(b)/dec(R)).ln();l=-dec(q).ln()
      # Independent integral primitive plus the original endpoint atom.
      primitive=l*(1-(-T).exp())+1-(T+1)*(-T).exp()
      atom=(l+T)*(-T).exp()
      exact=l+1-dec((R/b)**n)
      ck(abs(primitive+atom-exact)<Decimal('1e-58'),'clock')
for seed in range(1,19):
    f=[F(1+(seed+3*y)%7,3) for y in range(5)]
    cells=[F(1+u,7) for u in range(4)]
    C=[[int((seed+u*2+y*y+y)%7<4) for y in range(5)] for u in range(4)]
    C=[row if any(row) else [1,0,0,0,0] for row in C]
    m=[sum((f[y]*C[u][y] for y in range(5)),F(0)) for u in range(4)]
    mu=[cells[u]/m[u] for u in range(4)]
    J=[sum((C[u][y]*mu[u] for u in range(4)),F(0)) for y in range(5)]
    high=[j>=F(1,5) for j in J]
    # Full kernel, then an actual symmetric source-dependent positive mask.
    D=[[sum((f[y]*C[u][y]*C[v][y]/J[y] for y in range(5) if high[y]),F(0))
        for v in range(4)] for u in range(4)]
    chiD=[[sum((f[y]*C[u][y]*C[v][y]/J[y]
               for y in range(5) if high[y] and (u+v+y+seed)%3!=0
               and max(m[u],m[v])>F(3,2)*min(m[u],m[v])),F(0))
        for v in range(4)] for u in range(4)]
    P=[[D[u][v]*mu[v]/m[u] for v in range(4)] for u in range(4)]
    Q=[[chiD[u][v]*mu[v]/m[u] for v in range(4)] for u in range(4)]
    for u in range(4):
        row=sum(P[u]);target=sum((f[y]*C[u][y] for y in range(5) if high[y]),F(0))/m[u]
        ck(row==target and sum(Q[u])<=row<=1,'row')
        for v in range(4):ck(cells[u]*Q[u][v]==cells[v]*Q[v][u],'balance')
    upper=max(m)*2
    L=[(dec(upper)/dec(x)).ln() for x in m]
    cross=sum((dec(cells[u]*m[u]*Q[u][v])*L[v] for u in range(4) for v in range(4)),Decimal(0))
    native=sum((dec(cells[u]*m[u]*sum(Q[u]))*L[u] for u in range(4)),Decimal(0))
    energy=G=Es=Decimal(0)
    for u in range(4):
      for v in range(4):
        conduct=dec(cells[u]*Q[u][v])/2
        x=dec(m[u]);y=dec(m[v])
        G+=conduct*abs(x-y)
        energy+=conduct*(x-y)*(x/y).ln()
        Es+=conduct*(x.sqrt()-y.sqrt())**2
    ck(abs(cross-native-energy)<Decimal('1e-55') and energy+Decimal('1e-55')>=dec(F(3,2)).ln()*G,'entropy')
    root=dec(F(3,2)).sqrt();factor=(root-1)/(root+1)
    ck(factor*G-Decimal('1e-55')<=Es<=G+Decimal('1e-55'),'sqrt')
print('PASS reversible-clock checks',cnt,'total',sum(cnt.values()))
