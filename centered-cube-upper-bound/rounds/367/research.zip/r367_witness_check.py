from fractions import Fraction as F
from decimal import Decimal, localcontext
import json
n=10000;delta=F(1,100*n);rho=F(1,10**7);e0=F(1,2000)
checks={}
def ck(k,b):
 assert b,k
 checks[k]=bool(b)
ck('exp9_upper',F(11,4)**9<10002)
ck('exp9p5_lower',F(8,3)**19>10002**2)
ck('exp1_upper_series',F(8,3)+F(5,96)<F(11,4))
ck('outside_N_whole_boxes',e0-4*rho>F(19,4*n))
ck('inside_A_whole_boxes',e0+4*rho<F(81,16*n))
ck('other_coordinates_zero',4*rho<1)
v=F(1,2)-delta-2*rho;u=v-(1+e0)/2
ck('V_radius_one',2*(v+rho)+2*delta<1)
ck('U_baseline_radius_one',2*(abs(u)+rho)+2*delta<1)
ck('disjoint_U_V',v-u>2*rho)
ck('boxes_inside_E',max(abs(u),abs(v))+rho<F(3,4)-delta)
ck('source_capture_small',delta+v+rho<F(1,2))
ck('source_capture_big',delta+abs(u)+rho<1)
ck('mass_gap_base',F(4,3)**4>3)
ck('mass_gap_exponent',n//4>100 and n%4==0)
ck('removed_mass_below_one',0<2*rho<1)
Zlower=F(49*n,150)-1;H=F(101*3072,119)
ck('original_high_clock',Zlower>H)
ck('strict_high_past',Zlower>100)
# Stage 3 diagnostic: expanded dimensions and perturbation margins; Decimal is not an outward-rounded certificate.
rows=[]
with localcontext() as ctx:
 ctx.prec=70
 for d in [1024,2048,2978,2979,4096,8192,10000,16384,32768,65536,1000000]:
  l=Decimal(d+2).ln();h=l/(2*d);t=l*l/(16*d)
  rows.append({'n':d,'h':str(h),'t':str(t),'A_extends_N':bool(t>h)})
result={'exact_checks':checks,'exact_count':len(checks),'Z_lower':str(Zlower),'H':str(H),'log_n_plus_2_enclosure':['9','19/2'],'diagnostic_only_decimal_sweep':rows,'scope':'positive-volume actual hard/highpast G branch witness, not Fshell witness nor global budget'}
open(__file__.rsplit('/',1)[0]+'/r367_witness_result.json','w').write(json.dumps(result,indent=2))
print('PASS exact witness checks',len(checks),'diagnostic dimensions',len(rows),'Zlower',Zlower,'H',H)
