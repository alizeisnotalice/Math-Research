# R367 — The actual reversible receiver kernel and a physical-clock reference potential

## Outcome

The proposed kernel is indeed reversible and sub-Markov on REAL Lebesgue receiver measure du. Its symmetric restriction retains the original high-past source mark and the complement of the specified receiver-containment gate. A clock-adapted mass reference has an exact dimension-independent X_q budget, proved below. Its sign in the dissipation identity is subtractive; the corresponding cross-receiver potential is not paid. No new bound for G_(K,>h,not N) and no extra source fee are claimed.

This note deliberately does not turn a square-root-mass energy comparison into a purported new receipt. The precise missing input is a source-linear or small-X estimate for the cross potential with the ORIGINAL source-labelled kernel.

## 1. Correct reference measure and all retained marks

Keep full f, m_u=f(Q_u)=q_u R_u^n, q_-<=q_u<=lambda, a<=R_u<=b, E_r, c_u(y), mu(du)=du/m_u, J_y(r), and the original inclusive physical clock ell. At a fixed physical r set

    D_r(u,v)=integral f(y)1_{J_y(r)>=H}
                                  c_u(y)c_v(y)/J_y(r)dy,
    P_r(u,dv)=D_r(u,v)mu(dv)/m_u, u,v in E_r.             (1)

There is no division on a zero J row. Symmetry of D gives

    du P_r(u,dv)=D_r(u,v)mu(du)mu(dv),                    (2)

so the actual invariant reference is du, NOT mu and not m_u du. Moreover

    P_r 1(u)=g_r(Q_u)/m_u<=1,
    g_r=f1_{J_r>=H}.                                     (3)

To verify (3), integrate v first: its capture integral is exactly J_y(r), cancelling the unchanged denominator. It follows that du P_r<=du by symmetry. No renormalization of deficient rows is performed.

For the requested remaining slot use the symmetric source-labelled gate

    chi_r(y,u,v)=1_{max(m_u,m_v)>K min(m_u,m_v)}
       *1_{Z_y(max(m_u,m_v)/K-)>h}*1_{not N(u,v)}.         (4)

Here Z is the original GLOBAL strict mass past, retaining y. Order the two receivers by radius as s (small) and l (large), and use exactly

    N(u,v)={2||s-l||_infinity
                   <=R_l-R_s+a log(n+2)/(2n)}.

For K>lambda/q_-, the far-mass gate ensures that larger mass also means larger radius, so the orientation agrees with the original G. Put D_r^chi equal to (1) with the additional chi inside the y integral, and P_r^chi=D_r^chi mu(dv)/m_u. Then

    0<=P_r^chi<=P_r, du P_r^chi is symmetric,
    P_r^chi 1<=P_r1<=1.                                  (5)

The exact row identity (3) is replaced by this inequality after restriction. The y-dependent high-past gate must NOT be pulled outside the source integral. This construction keeps it without claiming independence of source and receivers.

Write C_r^chi(du,dv)=du P_r^chi(u,dv). Then the original remaining scalar slot is EXACTLY

    G=1/2 integral ell(dr) integral |m_u-m_v| C_r^chi(du,dv).
                                                               (6)

Each original ordered large-to-small pair is counted twice in the symmetric integral, accounting for the factor 1/2. No near-mass piece is added or re-paid.

## 2. A genuinely physical-clock reference with a finite bill

For u in E_r define the nonnegative potential

    L_r(u)=log(lambda r^n/m_u)
           =log(lambda/q_u)+n log(r/R_u).                 (7)

For each actual receiver u, let T_u=n log(b/R_u). Direct integration of the unchanged clock gives the EXACT formula

    integral_[R_u,b] m_u L_r(u)ell(dr)
       =q_u[log(lambda/q_u)+1-(R_u/b)^n].                 (8)

Indeed under t=n log(r/R_u), the normalized clock R_u^n ell has density e^(-t)dt on [0,T_u) and an atom e^(-T_u) at T_u. Its total mass is 1 and its mean t is 1-e^(-T_u). This proves (8), including R_u=b and all actual radius atoms.

Consequently the complete native reference budget is

    S=integral ell(dr) integral_(E_r) m_u L_r(u)du
      =integral_E q_u[log(lambda/q_u)+1-(R_u/b)^n]du
      <=[1+log(lambda/q_-)]X_q.                           (9)

This uses matching at the SAME receiver and the actual physical clock. It has no n factor. With the real restricted kernel, the native term

    S_chi=integral ell(dr) integral m_u L_r(u)
                                      P_r^chi1(u)du

satisfies 0<=S_chi<=S. This is a proved auxiliary budget; its placement in the next identity prevents it from being used as payment of G by itself.

## 3. Entropy dissipation: exact sign and the unpaid cross term

Define

    E_log=1/2 integral ell(dr) integral
              (m_u-m_v)(log m_u-log m_v) C_r^chi(du,dv),
    C_cross=integral ell(dr) integral m_u P_r^chi L_r(u)du.

The notation P_r^chi L_r(u) means integral L_r(v)P_r^chi(u,dv); the source mark and all predicates (4) remain inside the kernel. By symmetry and because log m_u-log m_v=L_r(v)-L_r(u),

    E_log=C_cross-S_chi.                                  (10)

All quantities are finite on the original finite radius band: L_r is bounded by log(lambda/q_-)+n log(b/a), and matching plus the original tail bounds the integrated m-weight by X_q. Thus (10) does not subtract undefined infinite quantities.

On the strict far-mass domain,

    (log K)G<=E_log.                                      (11)

An estimate of the form

    C_cross<=eps (log K)X_q
                 +C_eps n polylog(n+2)W                  (12)

would therefore give the desired root source scale when log K=sqrt(n). But (12) has NOT been proved. Equations (9)-(10) do not imply it: (9) bounds the SUBTRACTED native term, not the positive cross term. Dropping S_chi in (10) only gives G<=C_cross/log K, which still requires (12).

In particular reversibility allows the exact rewrite

    C_cross=integral ell(dr) integral L_r(u)P_r^chi m(u)du,

but does not justify replacing P_r^chi m by m. Subinvariance is for du; the weighted measure m_u du is not known to be subinvariant. Without a new estimate, the pointwise bound is merely

    P_r^chi m(u)<=lambda r^n P_r^chi1(u)<=lambda r^n.

Using it loses the useful physical-clock cancellation of (8). For transparency, its resulting upper estimate is

    C_cross<=lambda integral_E
       [l_u(1+T_u)+T_u+T_u^2/2]du,
    l_u=log(lambda/q_u), T_u=n log(b/R_u).                (13)

Formula (13) follows by integrating (l_u+t) against dt plus its terminal endpoint, rather than against the decaying normalized clock in (8). It can be quadratic in the dimension times X_q and is needlessly weaker than the simple bounded-potential estimate C_cross<=[log(lambda/q_-)+n log(b/a)]X_q. Neither is a root source payment; the already known G<=X_q is stronger than the resulting general receiver bound. Formula (13) is recorded only to expose the loss incurred by the unjustified weighted-invariance replacement, not as the preferred estimate. This quantifies the exact lost clock weight without alleging that the true C_cross must attain that crude bound.

## 4. Why the square-root variant does not close the slot

Let

    E_sqrt=1/2 integral ell(dr) integral
                   (sqrt(m_u)-sqrt(m_v))^2 C_r^chi(du,dv).

For the same far domain,

    [(sqrt(K)-1)/(sqrt(K)+1)]G<=E_sqrt<=G.                 (14)

This follows from the scalar ratio

    (sqrt(a)-sqrt(b))^2/|a-b|
                  =|sqrt(a)-sqrt(b)|/(sqrt(a)+sqrt(b)).

Thus for root K this energy is quantitatively comparable to the very same unpaid G. Its elementary row-cap bound by X_q does not add a receipt. The unmasked source-Gram kernel has additional positivity, but a general symmetric restriction (4) need not preserve positive-semidefiniteness; no spectral claim for P^chi is made from symmetry alone. No arbitrary weighted L2 contraction is assumed.

A genuinely useful next estimate must use the actual cube overlap and source matching to control P_r^chi m in the L_r-weighted integral, or control C_cross directly while retaining the source high-past gate and not-N geometry. The current calculation verifies the correct reference measure and gives the explicit native clock budget, but does not provide that geometric comparison. All previous fees and the unpriced slot remain unchanged. Work stops here without expanding another family of examples.

## 5. Local verification

The embedded checks verify the exact clock formula, source-Gram detailed balance, row deficiency, the signs in (10), and the entropy/square-root comparison on symmetric gated source marks. They are finite algebra checks, not actual cube realizations or evidence for (12).

~~~python
from fractions import Fraction as F
from decimal import Decimal,getcontext
getcontext().prec=65
cnt={'clock':0,'balance':0,'row':0,'entropy':0,'sqrt':0}
def ck(x,k):
    assert x,k
    cnt[k]+=1
def dec(x):return Decimal(x.numerator)/Decimal(x.denominator)
for n in range(1,11):
  for R in [F(1),F(5,4),F(3,2),F(2)]:
    for q in [F(3,4),F(7,8),F(1)]:
      b=F(2);T=Decimal(n)*(dec(b)/dec(R)).ln();l=-dec(q).ln()
      # Independent integral primitive plus the original endpoint atom.
      primitive=l*(1-(-T).exp())+1-(T+1)*(-T).exp()
      atom=(l+T)*(-T).exp()
      exact=l+1-dec((R/b)**n)
      ck(abs(primitive+atom-exact)<Decimal('1e-58'),'clock')
for seed in range(1,19):
    f=[F(1+(seed+3*y)%7,3) for y in range(5)]
    cells=[F(1+u,7) for u in range(4)]
    C=[[int((seed+u*2+y*y+y)%7<4) for y in range(5)] for u in range(4)]
    C=[row if any(row) else [1,0,0,0,0] for row in C]
    m=[sum((f[y]*C[u][y] for y in range(5)),F(0)) for u in range(4)]
    mu=[cells[u]/m[u] for u in range(4)]
    J=[sum((C[u][y]*mu[u] for u in range(4)),F(0)) for y in range(5)]
    high=[j>=F(1,5) for j in J]
    # Full kernel, then an actual symmetric source-dependent positive mask.
    D=[[sum((f[y]*C[u][y]*C[v][y]/J[y] for y in range(5) if high[y]),F(0))
        for v in range(4)] for u in range(4)]
    chiD=[[sum((f[y]*C[u][y]*C[v][y]/J[y]
               for y in range(5) if high[y] and (u+v+y+seed)%3!=0
               and max(m[u],m[v])>F(3,2)*min(m[u],m[v])),F(0))
        for v in range(4)] for u in range(4)]
    P=[[D[u][v]*mu[v]/m[u] for v in range(4)] for u in range(4)]
    Q=[[chiD[u][v]*mu[v]/m[u] for v in range(4)] for u in range(4)]
    for u in range(4):
        row=sum(P[u]);target=sum((f[y]*C[u][y] for y in range(5) if high[y]),F(0))/m[u]
        ck(row==target and sum(Q[u])<=row<=1,'row')
        for v in range(4):ck(cells[u]*Q[u][v]==cells[v]*Q[v][u],'balance')
    upper=max(m)*2
    L=[(dec(upper)/dec(x)).ln() for x in m]
    cross=sum((dec(cells[u]*m[u]*Q[u][v])*L[v] for u in range(4) for v in range(4)),Decimal(0))
    native=sum((dec(cells[u]*m[u]*sum(Q[u]))*L[u] for u in range(4)),Decimal(0))
    energy=G=Es=Decimal(0)
    for u in range(4):
      for v in range(4):
        conduct=dec(cells[u]*Q[u][v])/2
        x=dec(m[u]);y=dec(m[v])
        G+=conduct*abs(x-y)
        energy+=conduct*(x-y)*(x/y).ln()
        Es+=conduct*(x.sqrt()-y.sqrt())**2
    ck(abs(cross-native-energy)<Decimal('1e-55') and energy+Decimal('1e-55')>=dec(F(3,2)).ln()*G,'entropy')
    root=dec(F(3,2)).sqrt();factor=(root-1)/(root+1)
    ck(factor*G-Decimal('1e-55')<=Es<=G+Decimal('1e-55'),'sqrt')
print('PASS reversible-clock checks',cnt,'total',sum(cnt.values()))
~~~


Actual local execution of the final embedded script returned:

~~~text
PASS reversible-clock checks {'clock': 120, 'balance': 288, 'row': 72, 'entropy': 18, 'sqrt': 18} total 516
~~~

Detailed balance and row capacities use exact Fraction arithmetic. Logarithmic clock and energy comparisons use 65-digit Decimal arithmetic. These are finite formula checks; the original continuum field and exact high-past/not-N geometry are handled by the analytic positive-kernel argument, not asserted to be realized by the test matrices.
