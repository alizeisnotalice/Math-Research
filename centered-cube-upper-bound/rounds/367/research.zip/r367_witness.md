# R367: Positive-volume realization of the newly paid original G branch

This is a strict nonemptiness certificate for the actual full-input high-J/high-mass-past G branch A minus N. It is NOT a realization of the additional R355 terminal-shell path predicates, a quantitative covered fraction, or a proof of the general upper bound. A continuum radius selector, rather than a small global radius menu, is essential here.

Set n=10000, a=1, b=2, lambda=4/3, q_-=1, f=1_{[-3,3]^n}; W=6^n is finite. Let delta=1/(100n)=10^-6, rho=10^-7, e=1/2000 and

    E=[-3/4+delta,3/4-delta]^n,
    R0(w)=max(1,2||w||_infinity+2delta),
    Y=[-delta,delta]^n,
    v0=(1/2-delta-2rho,0,...,0),
    u0=v0-((1+e)/2,0,...,0),
    U=u0+[-rho,rho]^n, V=v0+[-rho,rho]^n.

U,V are disjoint positive-volume boxes contained in E, on both of which R0=1. Define the actual measurable selector R=2 on U, and R=R0 elsewhere in E. Thus 1<=R<=2; all actual cubes lie in [-3,3]^n and hence m_w=R_w^n, q_w=1. Every y in Y belongs to every selected cube: outside U this follows from ||w-y||_infinity<=||w||_infinity+delta<=R0(w)/2, while on U it follows directly from ||u||_infinity+delta<1. In particular capture is genuine, with no atomic receiver approximation.

For u in U and v in V the radii are 2 and 1. Their first-coordinate protrusion is between e-4rho and e+4rho; all other protrusions vanish since 4rho<1. We certify 9<log(10002)<19/2 without floating-point logarithms. The series gives 8/3<exp(1)<8/3+5/96=87/32<11/4; exact rational checks give (11/4)^9<10002 and (8/3)^19>10002^2. Consequently

    h_N=log(10002)/(2n)<19/(4n)<e-4rho,
    t_n=log(10002)^2/(16n)>81/(16n)>e+4rho.

Every pair in U times V is therefore strictly outside N and inside A, uniformly over the boxes.

The strict far-mass and global-past conditions also hold. K=exp(sqrt(n))=exp(100). Every receiver outside U has R<=3/2, so m_w<2^n/K: indeed (4/3)^4>3>exp(1), and (4/3)^10000>3^2500>exp(100). The same proves the far-mass condition for V. All of E minus U is thus included in Z_y(2^n/K-) for every y in Y.

The baseline receiver capacity has an exact radial formula, with its radius-1 atom:

    integral_E R0(w)^(-n)dw
      =(1-2delta)^n+n integral_1^(3/2) (r-2delta)^(n-1)r^(-n)dr
      >=n(1-2delta)^(n-1)log(3/2)
      >49n/150.

Here Bernoulli gives (1-1/(50n))^(n-1)>49/50 and log(3/2)>=1/3 follows by integrating 1/r on [1,3/2]. Removing U costs exactly |U|=(2rho)^n<1, because R0=1 on U. Therefore

    Z_y(2^n/K-)>49n/150-1=9797/3.

This exceeds both h_past=sqrt(n)/q_-=100 and the stronger historical threshold

    H=(1+sqrt(n))/(119/3072)=310272/119.

At the terminal clock atom r=b, J_b(y)>=Z_y(2^n/K-)>H. Thus all the original G gates used in this round hold on Y times U times V. Other H values are not asserted; the theorem itself is uniform in H, while this witness uses the stated H.

For completeness, J_b(y)<=1+n log2<1+n for every y. One proof bounds R(w)^(-n) by max(1,2||w-y||_infinity)^(-n) on the captured centers, integrates over ||w-y||_infinity<=1, and uses q=1. The original terminal atom has mass 2^(-n). Consequently its contribution alone gives the rigorous positive lower bound

    G_(high,A minus N)
      >=2^(-n)|Y||U||V|(2^n-1)/(2^n(1+n))>0.

All displayed volumes are actual positive Lebesgue volumes. This lower bound is extremely small compared with W; it makes no assertion about a uniform useful fraction of the difficult traffic.

## Verification scope

The standalone local Python Fraction script checks 17 exact rational parameter inequalities. It also explores h_N,t_n in 11 dimensions from 1024 to 10^6 using 70-digit Decimal; that sweep is diagnostic only, not an outward-rounded certificate or an asymptotic exponent fit. The mixed-volume algebra is separately tested in 2000 exact checks. Thus the stages are: exact envelope algebra, screening against the original high-gate/menu obstruction via the analytic continuum construction above, and enlarged-dimension diagnostic plus a rigorous whole-box perturbation margin at n=10000. No finite test is substituted for the geometric proof.

范围补充：此见证证明的是本轮第337→366→367替代账中几何门覆盖的严格扩大，不声称在所有历史备选账的并集中仍首次收费。尤其旧路径有限维处理可能已用较大常数控制该维数的相应硬槽；两套账不叠加。
