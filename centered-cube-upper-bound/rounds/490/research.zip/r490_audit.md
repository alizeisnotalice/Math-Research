# R490 独立终审

FINAL PASS（限定范围）。认证 E1/H2、同参考联合平方账、显式测试的一次平方预算及准确首失败停止分解；不认证 B1、完整累计停止价格或一般根阶目标闭合。本轮没有可新增到母账的完整根阶付款。

独立 PRE 在作者稿阅读前形成并保留。终审核对七项输入：D_J(q_j)、来源零阶 V0(h_j) 与 low-touch 的 3/4 系数属于同一正交耗散，可联合支付而未重复；Cauchy 给 D_J(v)≥∫|v|²e，故控制的是 q_j²e，真实停止是 q_je。q_j↓0 另用 R486 双参考终端界，不能单凭次不变性。d_j=P*^j(1−P*1) 的平方分割合法，但不是点态 q_je，也不确定实际停止位置。

高捕获质量窗、含 G(a−) 的闭窗 Stieltjes 公式及 full latent 强度 H2 正确，原参数给 c_hi<1/1024。自然参考一次罕见不能直接变成累计价。两类测试的中心化不同且均合法：proof 用 φ−Qφ 的真实来源方差，geometry 用 φ−1/12 的全中心二次矩；低投影及 H 的顺序与范数系数正确。其平方预算没有给停止量的下界，B1 仍缺。

八门与十一门采用不同首失败顺序，但最终成功交集一致：全 raw no-hit 使原最大父及命中计数门冗余；数量门在正秩入口后确保最大父存在。完整停止测度保 q_jF_a、Ve_a，head 正补偿包含未付累计父到达权，未删除 baseline。Astra 一次 F_once 的两份 2rS²X/T 分别来自原双中心外置与 R482 全 raw old-hit；proof 的 H_pair=S/τ≥1 保守 old-hit 价也有正上放依据。二者是可替代的一次界，未叠加收费，亦未免费用于各代。

独立隔离重放 geometry 3、proof 19、numeric 433 项，共 455 项精确断言通过；stdout 与冻结 replay 一致。numeric JSON 仅删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `9381421ae1350723a1eac93049f09e330036bfee22d8836d47945daa2cd92e68`。五个有理算子模型及精确 Lyapunov 无限平方和只认证抽象接口；其 Q 不等于原 Π_hi，不作原几何/history 反例。原入口倍率及旧费用、全尺度账均保留。

## 冻结输入 SHA256

- `r490_main.md`: `f97b1c99c56dbee2c3145b007c462594a94363a71b746a67b17222f8c0d1cf55`
- `r490_geometry.md`: `18f745b30aa2c0829e6838e7ae94544d25fbb0568139201a3fc3ad189013bc9f`
- `r490_proof.md`: `927b5010b89ac915ec447cb531ca91caafee1b45826dc556b2c6bf038e2e6f2a`
- `r490_numeric.md`: `ca7619f573be82dc0c428e7e3edc12cf6f280d3bb5651f0ba6db0df83ae75eb2`
- `r490_numeric.py`: `0bf64300782dfcbcd1e14bee15be0d2f5a3738508bd14bf05ba3b1aadaaf0984`
- `r490_numeric.json`: `9ded94c8d7270a3ba4b5b7bde979ffdbdb0959b1e0410030ff797350a8b85eb1`
- `r490_replay.json`: `0bd6d2ddbddfe0821531465785effa8c1123b130445ec2bf83ef7e79e3a4c7e9`
