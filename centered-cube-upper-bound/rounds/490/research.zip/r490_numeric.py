from pathlib import Path
from itertools import combinations
import sys,platform,json,time
import sympy as s
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def eq(x):
 if isinstance(x,s.MatrixBase):ck(all(s.simplify(z)==0 for z in x))
 else:ck(s.simplify(x)==0)
def nsq(v):return (v.T*v)[0]/v.rows
def psd(A):
 ck(A==A.T)
 for k in range(1,A.rows+1):
  for sub in combinations(range(A.rows),k):ck(A.extract(sub,sub).det()>=0)
def mat(A):return [[str(x) for x in row] for row in A.tolist()]
R=s.Rational
cases=[('initial_nonsymmetric',s.Matrix([[R(1,2),R(1,8)],[R(1,4),R(1,2)]])),('pressure_constant_killing',R(3,4)*s.eye(2)),('pressure_zero_J',s.zeros(2)),('expanded_three_states',s.Matrix([[R(1,2),R(1,8),0],[0,R(1,4),R(1,8)],[R(1,8),0,R(1,2)]])),('expanded_stronger_J',R(7,5)*s.Matrix([[R(1,2),R(1,8),0],[0,R(1,4),R(1,8)],[R(1,8),0,R(1,2)]]))]
records=[]
for name,J in cases:
 n=J.rows;I=s.eye(n);one=s.ones(n,1);Q=s.ones(n,n)/n;H=(I+Q)/2
 P=J*H;A=H*J.T;B=J*(I-Q)*J.T
 e=one-P*one
 ck(all(z>=0 for z in e))
 if name=='initial_nonsymmetric':ck(one-A*one!=e)
 row=list(J*one);col=list(J.T*one)
 ck(all(z>=0 for z in J));ck(max(row)<1);ck(max(col)<1)
 ck(H==H.T);eq(H*one-one);psd(H);psd(I-J*J.T)
 eq(I-H*H-R(3,4)*(I-Q))
 # Infinite exact square-energy sum: S=sum_j q_j q_j^T solves S=11^T+A S A^T.
 vec=(s.eye(n*n)-s.kronecker_product(A,A)).inv()*s.ones(n*n,1)
 S=s.Matrix(n,n,list(vec));eq(S-one*one.T-A*S*A.T)
 totalell=s.trace(B*S)/n
 totalinputloss=s.trace((I-J*J.T)*S)/n
 eq(totalinputloss+R(3,4)*totalell-1)
 ck(totalell>=0);ck(totalell<=R(4,3))
 total_qsquare_e=sum(e[k]*S[k,k] for k in range(n))/n
 ck(total_qsquare_e+R(3,4)*totalell<=1)
 total_q_e=(e.T*(I-A).inv()*one)[0]/n
 eq(total_q_e-1);ck(total_qsquare_e<=total_q_e)
 g=s.Matrix(range(1,n+1));q=one;N=8;death=s.zeros(n,1);sqspent=0;pairexpr=0
 step=[];partial_qsquare_e=0;partial_q_e=0
 for j in range(N):
  h=J.T*q;ell=(I-Q)*h;qn=A*q;d=q-qn
  ck(all(x>=0 for x in d));ck(all(x>=0 for x in qn))
  q_e=(q.T*e)[0]/n
  qsquare_e=sum(q[k]**2*e[k] for k in range(n))/n
  eq(sum(d)/n-q_e)
  ck(qsquare_e+R(3,4)*nsq(ell)<=nsq(q)-nsq(qn))
  partial_qsquare_e+=qsquare_e;partial_q_e+=q_e
  eq(nsq(q)-nsq(qn)-(nsq(q)-nsq(h))-R(3,4)*nsq(ell))
  ck(nsq(q)-nsq(h)>=0)
  # phi_j=sqrt(d_j)*g: square and signed pairing checked without numeric roots.
  phi=s.Matrix([s.sqrt(d[k])*g[k] for k in range(n)])
  normphi=nsq(phi);eq(normphi-sum(d[k]*g[k]**2 for k in range(n))/n)
  pair=(phi.T*ell)[0]/n
  sqspent+=normphi;pairexpr+=pair;death+=d
  step.append(dict(j=j,forward_stop_pairing=str(q_e),energy_stop_payment=str(qsquare_e),q=[str(x) for x in q],death=[str(x) for x in d],ell=[str(x) for x in ell],ell_square=str(nsq(ell)),phi_square=str(normphi),pairing_exact=str(pair)))
  q=qn
 eq(death+q-one)
 eq(partial_q_e-sum(death)/n)
 ck(partial_qsquare_e+R(3,4)*sum(s.Rational(z['ell_square']) for z in step)<=1)
 eq(sqspent+sum(q[k]*g[k]**2 for k in range(n))/n-nsq(g))
 # Since ||A||infty<=maxcolumn(J)<1, q_N->0. These are infinite identities.
 terminal_stop=1;phi_total=nsq(g)
 if name in ('pressure_constant_killing','pressure_zero_J'):
  eq(totalell);eq(pairexpr);ck(terminal_stop>0)
 records.append(dict(name=name,states=n,measure='uniform probability nu; R=||1||nu^2=1',J=mat(J),H=mat(H),P=mat(P),Pstar=mat(A),Q=mat(Q),forward_e=[str(x) for x in e],initial_death=[str(x) for x in one-A*one],infinite_q_e=str(total_q_e),infinite_qsquare_e=str(total_qsquare_e),infinite_joint_payment=str(total_qsquare_e+R(3,4)*totalell),stop_minus_square_payment=str(total_q_e-total_qsquare_e),partial_q_e=str(partial_q_e),partial_qsquare_e=str(partial_qsquare_e),max_J_row=str(max(row)),max_J_column=str(max(col)),spectral_radius_certificate='||Pstar||infty <= max_column(J) <1',total_death_mass='1',total_ell_square=str(totalell),total_J_contraction_loss=str(totalinputloss),exact_energy_identity='total_J_contraction_loss + 3/4 total_ell_square = 1',g=[str(x) for x in g],total_phi_square=str(phi_total),g_square=str(nsq(g)),N=N,partial_death_mass=str(sum(death)/n),remaining_death_mass=str(sum(q)/n),partial_phi_square=str(sqspent),remaining_phi_square=str(sum(q[k]*g[k]**2 for k in range(n))/n),partial_pairing_exact=str(pairexpr),steps=step))
result=dict(scope='Finite abstract substochastic J and self-adjoint positive Markov H interface. Q is abstract mean projection, NOT the original high/source-state projection. No geometric/history counterexample.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=s.__version__,command='"'+sys.executable+'" r490_numeric.py',seconds=time.perf_counter()-start),checks=checks,models=len(records),finite_generations_per_model=8,formulas=dict(P='J H',Pstar='H J^T',H='(I+Q)/2',q_j='(Pstar)^j 1',ell_j='(I-Q)J^T q_j',death='d_j=q_j-q_(j+1)>=0; sum_j d_j=1 by strict contraction',energy='||qj||^2-||qj1||^2=(||qj||^2-||J^Tqj||^2)+3/4||ellj||^2',joint_payment='sum_j <q_j^2,e> + 3/4 sum_j ||ell_j||^2 <= R; e=1-P1; <d_j,1>=<q_j,e>',once_square='phi_j=sqrt(d_j)g; sum_j ||phi_j||^2=||g||^2',pairing_gap='Total stopping mass is sum_j <d_j,1>, not sum_j <sqrt(d_j)g,ell_j>. An additional actual-geometric lower bound connecting these quantities is missing.'),records=records,decision='The death increments provide a valid single square budget. In constant-killing examples ell_j=0 and stopping mass=1: this only shows the abstract low-component pairing does not automatically represent stopping; it does not refute the actual geometric route or supply its missing lower bound.',errors='All assertions and outputs rational or exact SymPy radicals; no floating solver, truncation error, Monte Carlo, or general theorem inferred from samples. Infinite sums are certified by exact Lyapunov equations and strict norm contraction.')
(ROOT/'r490_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact assertions;5 abstract operator models,8 finite generations each;infinite square sums via rational Lyapunov identity')
