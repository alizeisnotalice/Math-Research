# R490：同参考逐代平方账、互斥停止核与一个有来源价的几何测试

本稿独立核建议 §§4–6 的 E1、H2，并在 R486 同一自然参考上写实际停止 RN。所有平方账一次合并；真实停止的一次密度与平方密度严格区分。仍未得到原完整剩余的根阶预算。

## 1. 逐代能量和停止：同一实际链

保持 R486 的 \(\mathsf M,J,H,\mathcal P=JH\)，\(\mathsf M(1)=R\)。定义
\[
 q_j=(\mathcal P^*)^j1,\quad h_j=J^*q_j,
 \quad \ell_j=(I-\Pi_{\rm hi})h_j,\quad e=1-J1.
\]
这里 \(\Pi_{\rm hi}=E[\cdot\mid A,s_A,x,F_{\rm hi}]\)，阈值为 \(\pi_A(Q_C)>1/2\)。不是父均值投影，也不是高配置非空指示。

由 \(\mathcal P^*1\le1\) 及正性，\(0\le q_{j+1}\le q_j\le1\)。R486 的正交混沌分解逐项给
\[
 \|q_j\|^2-\|q_{j+1}\|^2
 \ge D_J(q_j)+\tfrac34\|\ell_j\|^2+V_0(h_j),
 \quad V_0(h)=\|(Z-Q)h\|^2, \tag{1}
\]
其中 \(D_J(v)=\|v\|^2-\|J^*v\|^2\ge0\)。这保来源零阶与 low-touch 的正交性，未重复扣同一平方信用。

更具体，设 \(j_0=J^*1\le1\)。伴随核 Cauchy 给 \(|J^*v|^2\le j_0J^*|v|^2\le J^*|v|^2\)，所以
\[
 D_J(v)\ge\int |v|^2e\,d\mathsf M.
\]
对任意有限 \(N\)，从(1)望远镜得联合预算
\[
 \boxed{\sum_{j<N}\int q_j^2e\,d\mathsf M
 +\tfrac34\sum_{j<N}\|\ell_j\|^2
 +\sum_{j<N}V_0(h_j)
 \le R-\|q_N\|^2.} \tag{2}
\]
特别 \(\sum_j\|\ell_j\|^2\le4R/3\)。单凭此结论不能控制 \(\|\sum_j\ell_j\|^2\)。

另一方面，真实停止质量精确为
\[
 R_N=\sum_{j<N}\int q_je\,d\mathsf M
 =R-\int q_Nd\mathsf M. \tag{3}
\]
R486 双参考列界给 \(q_N\le\min\{1,(m_+/m_-)b_0^N\}\)，故 \(q_N\to0\)、\(R_N\uparrow R\)，(2)可由非负单调收敛取无限和。质量比前因子只用于极限合法性，没有移入根阶常数。

## 2. 含原子的高捕获 latent 总强度

固定增广父 \(\widehat B\)，候选强度仍为
\[
 \Lambda_B(d\widehat C)=T^{-1}1_{\widehat C\prec\widehat B}
 \nu(dC)ds_C/m_C,
 \quad p_B(C)=I_{BC}/m_B.
\]
同带条件保在真实核中。对 \(0<\theta<1\)，\(p_B(C)>\theta\) 蕴含 \(\theta m_B<m_C\le m_B\)。实际中心 CDF
\(G_x(u)=\int_{m_C\le u}t(C)c_C(x)\sigma(dC)\le rSu\)
给闭窗公式
\[
 \int_{[a,b]}\frac{dG_x(u)}u
 =\frac{G_x(b)}b-\frac{G_x(a-)}a+
 \int_a^b\frac{G_x(u)}{u^2}du
 \le rS[1+\log(b/a)]. \tag{4}
\]
下端必须是 \(G_x(a-)\)；阈值原子并未漏掉。用 \(1_{p_B>\theta}\le I_{BC}/(\theta m_B)\)，只在正上界中放宽同带／mark，Tonelli 得
\[
\begin{aligned}
 \Lambda_B\{p_B>\theta\}
 &\le\frac1{T\theta m_B}\int_{Q_B}\mu(dx)
 \int_{\theta m_B\le m_C\le m_B}
 t(C)c_C(x)\sigma(dC)/m_C\\
 &\le\boxed{\frac{rS}{T\theta}[1+\log(1/\theta)]}. \tag{5}
\end{aligned}
\]
这控制完整 latent 强度，比仅控制某个 \(x\) 的可见高类强度更强。\(\theta=1/2\) 时记
\(c_{\rm hi}=2rS(1+\log2)/T\)。沿原 \(T=1024rS^2/(\tau\delta)\)、\(\tau\le S,\delta\le1/4\)，有 \(c_{\rm hi}<1/1024\)。观察到的高类强度也不超过它。

R487 的实际输出高类空支持仍成立：成功最大父对**全部 raw 其余点**的 Gram 行和不超过 \(1/2\)，且 \(m_C\le m_B\) 使 \(p_B(C)\le\gamma_{BC}\)。但(5)或 \(\mathsf M(F_{\rm hi}\ne\varnothing)\le c_{\rm hi}R\) 不是累计高类费用；不能在求和时省掉 \(q_j\) 或累计访问次数。

## 3. 实际首次失败互斥分解与完整 RN

状态 \(\xi=(A,s_A,x,F)\) 已含全部 raw 配置。给定当前父，按原条件记录律 \(C_A(d\omega)\) 附旧 pair、原阶段／时钟等标签；这是 R486 所定义当前步的核，不是让旧路径标签自动成为新父历史。记
\(\widehat{\mathsf M}(d\xi,d\omega)=\mathsf M(d\xi)C_A(d\omega)\)。

取下列固定检测顺序。它只把原成功交集划成互斥失败，不改变成功条件：

1. \(t(A)\ge\tau\)；
2. 当前增广秩 \(v_A(x)\ge\kappa T\)；
3. raw 配置非空；
4. raw 数量 \(N_F\ge v_A(x)/(2T)\)；
5. 有向非对角 Gram 总和 \(O\le v_A(x)/(16T)\)；
6. raw 最大父行和 \(\le1/2\)；
7. raw 最大父不捕获旧 \(y,z\)；
8. 旧 pair 的 raw 命中数量 \(\le v_A(x)/(8T)\)；
9. 全 raw 父与原父双向中心外置；
10. 最大父为 R481 长边；
11. R482 全 raw 族均不捕获旧 \(y,z\)。

其中第3–4项合起来就是原数量门；第11项会使若干较早 old-hit 门在最终成功交集上冗余，但其首次失败事件仍合法。空配置以后的最大父量可任意补定义，前缀已失败，不影响任何测度。依据是 R479 main §3–4、R481 §2–3、R482 全 raw no-hit 与 R486 geometry §1 所保同一原成功门。

令 \(G_a\in\{0,1\}\) 为这些门，\(F_a=(\prod_{b<a}G_b)(1-G_a)\)、\(G=\prod_aG_a\)。逐记录
\[
 \sum_aF_a+G=1,\qquad
 e_a(\xi)=\int F_a(\xi,\omega)C_A(d\omega),\quad
 \sum_ae_a=e. \tag{6}
\]
第 \(j\) 代第 \(a\) 类停止的完整记录测度为
\[
 d\mathcal S_{j,a}=q_j(\xi)F_a(\xi,\omega)
 d\widehat{\mathsf M},
\]
其输入状态 RN 为 **\(q_je_a\)**；累计 RN 为 \(Ve_a\)。成功记录按原输出映射推前的 RN 为 \(h_j=J^*q_j\)，再经 \(H\) 后才是 \(q_{j+1}\)。因此
\[
 R_N=\sum_a\sum_{j<N}|\mathcal S_{j,a}|,
 \qquad
 \sum_{j,a}\int q_j^2e_a\,d\mathsf M
 +\tfrac34\sum_j\|\ell_j\|^2+\sum_jV_0(h_j)\le R. \tag{7}
\]
(7)里平方停止密度与实际停止密度相差一个 \(q_j\)，不能互换。

一次 \(\mathsf M e\) 可沿原完整失败预算估计。一个不利用进一步锐化的安全上界是
\[
 \mathsf M e\le\left[\tau+\delta S+\frac{2rS^2}{T}
 +\frac{S^2b_n}{T}+\frac{2rS^2H_{\rm pair}}T\right]X
 +\kappa TNW,\quad H_{\rm pair}=S/\tau.
\]
各项依次来自原输入／几何门、内部中心、短边、全 raw old-hit 的一次正上界；\(2rS^2H_{\rm pair}/T=\delta S/512\)。更锐的已审原一次账可替代此保守界。这里不是额外再收一次母账。\(q_j\le1\) 只能给每一代各自不超过这份一次价格，不能无损跨代求和；当前状态下的配置也不因自然参考是 PPP 就在实际到达权下重新独立。

## 4. 不同于停止中心化的几何测试：来源平方价已可求和，停止比较仍缺

定义真正的入列损失
\[
 d_j=q_j-q_{j+1}=(\mathcal P^*)^j(1-\mathcal P^*1)\ge0.
\]
R486 终端消失给 \(\sum_jd_j=1\) 几乎处处。仅次 Markov 性不足以给等号。一般 **\(d_j\ne q_je\)**：二者积分相等，但前者是入列缺陷，后者是出行停止 RN，空间位置不同。

令 \(\phi=|x-A|^2/(nR_A^2)\)、\(\phi_0=\phi-Q\phi\)。R488 真中心方差预算是 \(\|\phi_0\|_{\mathsf M}^2\le SC_{\rm oct}W\)。一个由实际停止率与几何直接定义的测试为
\[
 \varphi_j=(I-\Pi_{\rm hi})[\sqrt{d_j}\,e\,\phi_0]. \tag{8}
\]
它没有未知 \(R\) 归一化，保当前实际 \(e\) 及全部门。投影收缩、\(e\le1\) 和 \(\sum d_j=1\) 给真实一次来源平方预算
\[
 \boxed{\sum_j\|\varphi_j\|^2\le SC_{\rm oct}W.} \tag{9}
\]
由于 \(\phi_0\) 对 \(\Pi_{\rm hi}\) 可测，配对也有准确含义：
\[
 \langle\varphi_j,\ell_j\rangle
 =\int\phi_0\operatorname{Cov}
 (h_j,e\sqrt{d_j}\mid A,s_A,x,F_{\rm hi})d\mathsf M. \tag{10}
\]
故由(2)，\(\sum_j|\langle\varphi_j,\ell_j\rangle|
 \le\sqrt{(4R/3)SC_{\rm oct}W}\)。这验证了一个有几何来源价的测试类，但没有证明它从下方控制停止量。

准确未证步骤是用同一真实门把 \(\sum_j\int q_je\) 比较到(10)，同时支付不能由 low-touch 配对看到的父／high-only 部分。尤其可能在某状态 \(d_j=0\) 而 \(q_je>0\)，不能把停止 RN 免费搬到(8)的平方权。没有该比较，(9)只是 B2 型已证预算，不能推建议 B1，也不能直接支付原 \(R\)。本稿不重复另一作者的停止中心化测试，不以新测试定义代替根阶结论。

## 5. 短本机代数核验

以下脚本实际输出 `19 exact Fraction assertions PASS; first-failure partition and weighted RN bookkeeping only.` 它核十一门条件记录的互斥分配和逐代 RN 加权；是有限代数，非原生场／history 实例。E1/H2 的一般证明在正文，不靠这些实例外推。

```python
from fractions import Fraction as F
weights=[F(1,2),F(1,3),F(1,6)]
gate_count=11
rows=[];checks=0
for state in range(4):
 ea=[F(0)]*gate_count;survival=F(0)
 for record,p in enumerate(weights):
  gates=[1]*gate_count
  if record or state%2:
   first=(2*state+record)%gate_count
   gates[first]=0
   if first+2<gate_count:gates[first+2]=0
  alive=1;events=[]
  for good in gates:
   events.append(alive*(1-good));alive*=good
  assert sum(events)+alive==1;checks+=1
  for a,failure in enumerate(events):ea[a]+=p*failure
  survival+=p*alive
 assert sum(ea)+survival==1;checks+=1
 rows.append((ea,survival))
for generation in range(3):
 total_by_class=F(0);total_by_row=F(0)
 for state,(ea,survival) in enumerate(rows):
  q=[F(1),F(4-state,5),F(4-state,10)][generation]
  total_by_class+=sum(q*x/4 for x in ea)
  total_by_row+=q*(1-survival)/4
 assert total_by_class==total_by_row;checks+=1
print(f'{checks} exact Fraction assertions PASS; first-failure partition and weighted RN bookkeeping only.')
```
