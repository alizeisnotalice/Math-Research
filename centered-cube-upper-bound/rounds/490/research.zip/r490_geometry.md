# R490：真实首失败分解与一次停止测试的未付父列

本稿只尝试一个机制：把实际停止函数在同一自然参考中按高捕获信息作条件中心化，以得到与逐代低捕获能量直接配对的测试。它没有产生新的来源付款；精确未付项如下。采用用户建议的逐代能量结论，不重证它，也不将模板本身列为进展。

## 1. 真正互斥的第一失败事件

沿 R486—R487，自然状态为 \(s=(A,s_A,x,F)\)，\(F\) 是原带内全部 raw PPP。给定父另外抽原条件记录；原历史只作为该记录的标签。记 \(v=v_A(x,s_A)\)，\(N_F=|F|\)，\(O_F\) 为有向非对角总亲和。对原实际 \(J\) 的成功条件采用以下检查顺序：

1. \(t(A)\ge\tau\)；
2. \(v\ge\kappa T\)；
3. \(N_F\ge v/(2T)\)；
4. \(O_F\le v/(16T)\)；
5. 最大父对全部 raw 点的亲和行和 \(\le1/2\)；
6. 全部 raw 父与 \(A\) 的中心双向外置；
7. 最大父满足原长边门；
8. 全部 raw 父均不捕获原旧 \(y,z\)。

第3项通过后最大父存在；此前不定义最大父的表达任意填零。第8项通过时，原最大父 old-hit 和 old-hit 数量门自动通过，故将这些冗余门省去不改变原 \(J\)。原质量带、mark 次序、原记录及其历史没有改变。

令 \(G_a\) 是第 \(a\) 项通过事件，定义
\[
e_a(s)=\mathbb E[1_{G_1\cap\cdots\cap G_{a-1}}1_{G_a^c}\mid s],
\qquad \sum_{a=1}^8e_a=e=1-J1.
\tag{1}
\]
这里只对原记录作条件平均；不假设成功后配置仍为 PPP。所有累计费必须写成 \(\sum_j\int q_je_a\,d\mathsf M\)，不是重复 union 价。

唯一可以直接沿用的一次输入价是
\[
\langle1,e\rangle\le F_{\rm once}:=
\left[\tau+\delta S+\frac{4rS^2}{T}+\frac{S^2b_n}{T}\right]X
 +\kappa T N_{\rm band}W,
\quad b_n\le3^{-n},
\tag{2}
\]
其中 \(T,\kappa\) 保原参数。两份 \(2rS^2/T\) 分别是整配置双中心外置和全 raw old-hit；这是 R482 初始 \(\Omega_0\) 的费用。带宽 \(\sqrt n\) 时，固定参数下最后一项为根阶。本稿没有将 (2) 转授任意后代到达密度。

## 2. 显式停止测试及其准确恒等式

设 \(E=\Pi_{\rm hi}\) 是给定父、mark、来源及高捕获配置的条件期望。沿已审定义
\[
q_j=(\mathcal P^*)^j1,\quad h_j=J^*q_j,
\quad \ell_j=(I-E)h_j,\quad \mathcal P=JH.
\]
\(H\) 自伴并与 \(E\) 对易。取这个具体、未归一化的测试
\[
\boxed{\varphi=H(I-E)e.}\tag{3}
\]
对 \(j\ge1\)，\(q_j=Hh_{j-1}\)，所以
\[
\langle q_j,e\rangle
=\langle\ell_{j-1},\varphi\rangle
 +\langle Eh_{j-1},HEe\rangle.
\]
因此任意有限 \(N\ge1\) 有
\[
\boxed{R_N=\langle1,e\rangle
 +\sum_{j=0}^{N-2}\langle\varphi,\ell_j\rangle
 +\sum_{j=0}^{N-2}\langle Eh_j,HEe\rangle.}\tag{4}
\]
空和取零。最后一项非负，因为 \(h_j,e\ge0\)，且 \(E,H\) 保正；不能将它当作有利抵消删除。由含低类混沌的谱帽，
\[
\|\varphi\|^2\le\tfrac14\|(I-E)e\|^2\le\tfrac14R.
\tag{5}
\]
这不是来源价。若在所有代使用同一 \(\varphi\)，平方费用是 \((N-1)\|\varphi\|^2\)，不能据逐代能量的一次结算而删掉 \(N\)。

## 3. 正补偿中包含哪一笔实际完整费用

前两个互斥停止项之和恰为
\[
e_{\rm head}(A,s_A,x)
=1_{t(A)<\tau}+1_{t(A)\ge\tau}1_{v_A(x,s_A)<\kappa T}.
\tag{6}
\]
它与配置无关，但不必与来源无关。自然 \(H\) 对来源零阶分量取父与 mark 均值，故
\[
Ee_{\rm head}=e_{\rm head},\qquad
He_{\rm head}=Qe_{\rm head},\qquad
H(I-E)e_{\rm head}=0.
\tag{7}
\]
令 \(a_j=Qq_j\)。对每个 \(j\)，真实 \(q_j\) 的来源边缘为 \(a_j(A,s_A)\pi_A\)；因此这部分累计费用精确为
\[
\boxed{\sum_{j<N}\langle q_j,e_{\rm head}\rangle
=\sum_{j<N}\int a_j(A,s_A)
 \left[1_{t<\tau}+1_{t\ge\tau}
 \pi_A\{x:v_A(x,s_A)<\kappa T\}\right]\nu(dA)ds_A.}
\tag{8}
\]
式 (4) 的最后一项包含 (8) 中全部 \(j\ge1\) 的费用；其 \(j=0\) 部分才由原 \(\tau X+\kappa TN_{\rm band}W\) 支付。来源仍是同一个实际 \(\mu\)，但实际到达权 \(a_j\) 不能重置为1。\(q_j\le1\) 只给逐代一次价，不能给跨代来源可加性。

R487 的波动块严格收缩并不控制这些父均值。式 (7) 也不证明低捕获能量永远无法间接支付 (8)：它只证明这次直接条件中心化测试没有完成所需几何桥。下一步若沿这条路线，必须从真实质量、中心与接受结构推导 **(8) 的累计父/来源列相对于能量的有价比较**，而不是再次引用原一次低秩容量。

## 4. 为什么廉价平方测试尚未补上缺口

已知 \(d_j=q_j-q_{j+1}\ge0\)、\(\sum_jd_j=1\)。用 R488 的真实来源几何函数 \(g=\phi-1/12\)，可显式写
\[
\widetilde\varphi_j=H(I-E)(\sqrt{d_j}\,g),\qquad
\sum_j\|\widetilde\varphi_j\|^2
\le\tfrac14\|g\|^2\le\tfrac14SC_{\rm ang}W.
\tag{9}
\]
但 (9) 没有与实际首失败事件的下界。将它代替 (3) 时，(4) 还保留全部正补偿以及 \(\sum\langle\varphi-\widetilde\varphi_j,\ell_j\rangle\)，二者均没有上述来源价。本稿不将这个形式上的平方预算作为进展，也不按未知 \(R\) 倒推测试归一化。

**本轮停止点：** 真正受控的完整项只有初始一次停止费 (2)；实际累计 head 费 (8) 已精确进入未付正补偿。本次测试没有给用户要求的 B1，故不宣称完整停止量或一般根阶弱型界已付。

## 5. 本机记账核验

以下 SymPy 代码实际运行输出 `PASS 3 symbolic identities: first-failure partition and source-only orthogonality`。只核首失败乘积展开及条件中心化正交记账，不是原生几何或完整历史证据。

```python
import sympy as s
z=s.symbols('z0:8')
first=[];alive=s.Integer(1)
for p in z:
    first.append(alive*(1-p));alive*=p
assert s.expand(sum(first)-(1-s.prod(z)))==0
p,a0,a1,l0,l1,b0,b1=s.symbols('p a0 a1 l0 l1 b0 b1')
# Conditional Poisson means E[N_x]=l_x.
lowmean=s.expand(p*a0*(l0-l0)*b0+(1-p)*a1*(l1-l1)*b1)
assert lowmean==0
Hhead=p*b0+(1-p)*b1
assert s.expand(p*a0*(l0-l0)*Hhead
                +(1-p)*a1*(l1-l1)*Hhead)==0
print('PASS 3 symbolic identities: first-failure partition '
      'and source-only orthogonality')
```
