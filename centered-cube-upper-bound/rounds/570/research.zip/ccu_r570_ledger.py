#!/usr/bin/env python3
"""R570 whole-clock ledger: exact symbolic algebra and three rational comparison checks."""
import argparse, hashlib, json, platform
from pathlib import Path
import sympy as s
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
args=parser.parse_args()
A,C,L,K,D,G,S,Lam,H,gamma,r=s.symbols('A C L K D G S Lam H gamma r',positive=True)
q=s.symbols('q',real=True)
Kdef=G*S*Lam*H
Lold=K**2*D
Lclock=2*G*S*gamma**2*r*K*Lam*D
ratio=s.factor((Lclock/Lold).subs(K,Kdef))
assert s.simplify(ratio-2*gamma**2*r/H)==0
Lbest=G**2*S**2*Lam**2*D*H*s.Min(H,2*gamma**2*r)
F=(A*s.sqrt(L)+s.sqrt(C+A**2*L))**2
assert s.simplify((q**2-(2*C+4*A**2*L)*q+C**2).subs(q,F))==0
assert s.simplify(F-(C+2*A**2*L+2*A*s.sqrt(C*L+A**2*L**2)))==0
# The inherited far invoice is never preferable once the same full V is bounded.
far=4*C+8*A**2*L
assert s.simplify((2*C+4*A**2*L)-(far/2))==0
# D*L=P*D^2, exposing the retained outer clock.
P=G**2*S**2*Lam**2*H*s.Min(H,2*gamma**2*r)
assert s.simplify(D*Lbest-P*D**2)==0
rows=[]
for hv in [s.Rational(4),s.Rational(9,2),s.Rational(8)]:
    rv=s.factor(ratio.subs({gamma:s.Rational(3,2),r:1,H:hv}))
    rows.append({'gamma':'3/2','rband':'1','Hcap':str(hv),'Lclock_over_Lold':str(rv),'decision':'clock strictly improves' if rv<1 else ('equal' if rv==1 else 'clock is dominated by inherited cap')})
result={'scope':'Full original finite-cutoff V_G; algebraic substitution of independently audited whole-clock inequality. No numerical cube experiment or claimed uniform cutoff bound.','python':platform.python_version(),'sympy':s.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':{'comparison_ratio':True,'full_a_zero_root':True,'far_never_better_for_same_full_bound':True,'outer_clock_squared_in_DL':True},'formulae':{'K':str(Kdef),'Lclock':str(s.factor(Lclock.subs(K,Kdef))),'Lold':str(s.factor(Lold.subs(K,Kdef))),'ratio':str(ratio),'Lbest':str(Lbest),'full_Qg_over_W':str(F),'physical_Q_over_W':'F/b0**2','Rstar_over_W_Qg_convention':'2*sqrt(D*F)','Rstar_over_W_archive_Q_convention':'2*sqrt(D*F)/b0','scalar_upper_bound_F':'2*C+4*A**2*L','scalar_lower_bound_F':'C+4*A**2*L','target_dependency':'D*C+A**2*P*D**2, P=G**2*S**2*Lambda**2*H*min(H,2*gamma**2*r)'},'rational_coefficient_comparisons':rows}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'python':result['python'],'sympy':result['sympy'],'script_sha256':result['script_sha256'],'checks':'PASS','rational_coefficient_comparisons':rows},ensure_ascii=False,indent=2))
