"""R570 exact primitive continuous-center/source integrals, including k4 clipping."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import argparse,json,hashlib,time,resource,platform
import sympy as sp

R=sp.Rational
eps=sp.symbols('epsilon',positive=True);p,q,z,h,d,u=sp.symbols('p q z h d u',real=True)
def clean(x):return sp.simplify(sp.expand_log(x,force=True))
def enc(v):
 if isinstance(v,sp.Basic):return str(v)
 if isinstance(v,dict):return {str(k):enc(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [enc(x) for x in v]
 return v

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();st=time.perf_counter()
 # kappa(h)=h follows only after the source-support bounds checked below.
 I=1+sp.integrate(h**-2,(h,1,2))+R(1,2);rho1=1/I;rho2=1/(2*I);rhoint=sp.integrate(1/(I*h*h),(h,1,2));assert I==2 and rho1+rho2+rhoint==1
 # On all selected cases u=z/eps>=1, p=P/eps in[-1/8,1/8],
 # hence capture threshold d=2(u-p)>1; keep h2 atom and full density.
 tail=clean(rho2+sp.integrate(1/(I*h*h),(h,d,2)));assert clean(tail-1/(2*d))==0
 # v=u-p ranges from u-1/8>0 to1, so the real log has no branch ambiguity.
 v=sp.symbols('v',positive=True)
 beta_u=clean(sp.integrate(1/(4*v),(v,u-R(1,8),1)))
 # Actual original small old field: plateau1/4 on |z|<=3eps/8,
 # and triangular tails5/8-|z|/eps, supported on |z|<=5eps/8.
 Q_source=clean(eps*(2*sp.integrate(R(1,4)**2,(u,0,R(3,8)))+2*sp.integrate((R(5,8)-u)**2,(u,R(3,8),R(5,8)))))
 Q_center=clean(2/eps**2*sp.integrate(sp.integrate(eps-(p-q),(q,-eps/8,p)),(p,-eps/8,eps/8)))
 assert clean(Q_source-Q_center)==0
 cases=[];large=(R(1,8),R(1,4));Z=(R(1,16),R(1,8));sigma=(R(1,4),R(3,4));large_length=large[1]-large[0];zlen=Z[1]-Z[0];sigmalen=sigma[1]-sigma[0]
 for k in [4,5,8,16,32,64,128]:
  e=R(1,2**k);small=(-e/8,e/8);y=small;center_length=small[1]-small[0];small_total_rate=center_length/e;large_total_rate=large_length;Ay=small_total_rate+large_total_rate
  # All source and center conditions are actual rational inequalities.
  checks=dict(center_families_disjoint=small[1]<large[0],all_small_expansions_inside_source=(-2<-9*e/8 and 9*e/8<2),all_large_expansions_inside_source=(-2<large[0]-1 and large[1]+1<2),small_all_capture_y=(e/4<=e/2),large_all_capture_y=(large[1]+e/8<R(1,2)),large_all_capture_z=(large[1]-Z[0]<R(1,2)),old_sigma_selected_large=(0<sigma[0]<sigma[1]<1),old_small_sigma_disjoint_selected=(1-k<sigma[0]),old_small_sigma_disjoint_large=(1-k<0),small_all_early=(2*e<R(1,2) and sigma[0]>0),large_not_early=(sigma[1]<1),small_pair_centers_overlap=(center_length<e),prefix_contains_all_proposals=(2<4),small_oldfield_support_inside_source=(5*e/8<2))
  assert all(checks.values())
  # Selected true L has zero small-window term and the complete large center length.
  L_selected=large_length
  dlo=Z[0]/e;dhi=Z[1]/e;lo=max(dlo,R(1));hi=min(dhi,R(9,8));beta_z=clean(e*sp.integrate(beta_u,(u,lo,hi))) if lo<hi else sp.Integer(0)
  beta_avg=clean(beta_z/zlen);Javg=clean(large_total_rate+beta_avg);U=Ay;hitavg=clean(Javg/U);different=clean(1-hitavg)
  # Original endpoint tuple fee: dnuC*dnuB/mB, old-window/source integral /L.
  factor_without_z=clean(large_length**2*rho1**2*(y[1]-y[0])*sigmalen/L_selected)
  selected=clean(factor_without_z*zlen);diff=clean(factor_without_z*(zlen-(large_total_rate*zlen+beta_z)/U));Q=clean(Q_source.subs(eps,e));Q2=clean(Q_center.subs(eps,e));assert Q==Q2
  hypothesis_selected=e/R(4096);hypothesis_diff=e/R(6144);hypothesis_Q=11*e/R(192);assert clean(selected-hypothesis_selected)==0 and clean(Q-hypothesis_Q)==0
  cutoff_power=max(k,8);a=R(1,2**cutoff_power);b=sp.Integer(2);D=cutoff_power+2;tau=R(1,D);supper=R(1,D**2);assert a<=e<=b/2 and tau<L_selected and supper<R(1,8)
  cases.append(dict(k=k,epsilon=e,small_centers=small,large_centers=large,selected_source_y=y,selected_source_z=Z,selected_sigma=sigma,small_original_sigma=[-k,1-k],large_original_sigma=[0,1],support_checks=checks,cutoff=dict(a=a,b=b,gamma=2,G=2,rband=1,q=1,lambda_band=1,S=1,hwin=R(1,8),Dclk=D,tau=tau,tau_strictly_below_selected_L=True,actual_startup_sstar_upper=supper,startup_guard='K>=1, Lambda>=1, CZ=K^2 Lambda Dclk^2, CY>=0 imply sstar<=Dclk^-2<1/8; no free threshold',history_bulk_alpha_head_firststop_not_constructed=True),selected_old_L=L_selected,old_small_window_contribution=0,small_y_rate=small_total_rate,large_both_rate=large_total_rate,union_rate=U,dimensionless_z_interval=[dlo,dhi],small_shared_capture_z_support=[lo,hi] if lo<hi else [],small_shared_capture_z_integral=beta_z,small_shared_capture_z_average=beta_avg,average_hit=hitavg,average_different=different,exclusive_rate_average=clean(small_total_rate-beta_avg),exclusive_is_all_early=True,selected_endpoint_factors=dict(B_center_length=large_length,C_center_length=large_length,rho_g1=rho1,rho_v1=rho1,old_mB=1,y_length=y[1]-y[0],z_length=zlen,sigma_length=sigmalen,old_inverse_L=1/L_selected),selected_fee_over_K=selected,selected_diff_fee_over_K=diff,small_old_Q_source_integral=Q,small_old_Q_center_integral=Q2,small_old_Q_hypothesis_residual=clean(Q-hypothesis_Q),selected_diff_hypothesis_residual=clean(diff-hypothesis_diff),selected_diff_over_KQsmall=clean(diff/Q),max_small_proposal_mass_over_M=2*e,diff_display=str(sp.N(diff,40)),ratio_display=str(sp.N(diff/Q,40)),constant_hit_hypothesis_valid=bool(9*e/8<Z[0])))
 # Uniform symbolic branch is stated only after checking every inequality at eps<=1/32.
 general=dict(epsilon_range='0<epsilon<=1/32',support_upper_epsilon=R(1,32),small_expanded_max_upper=R(9,256),z_min=Z[0],small_expanded_strictly_below_z=(R(9,256)<Z[0]),old_small_window_upper='log2(epsilon)+1<=-4<0',all_selected_center_source_bounds='same rational monotone inequalities verified at epsilon=1/32',Qsmall_source=Q_source,Qsmall_center=Q_center,selected_over_K=eps/R(4096),selected_diff_over_K=eps/R(6144),diff_over_KQsmall=clean((eps/R(6144))/Q_source),max_mass_ratio=2*eps,decision='No extra vanishing mp/M factor toward the small proposal family own original old score follows from this primitive geometry alone; large-family credit and full-history gates remain possible payers.')
 payload=enc(dict(schema='R570.numeric.1',scope='Exact one-dimensional continuous source/center primitive; all unconstructed history/head/firststop/bulk-alpha marks set to primitive1, not a full-history/general-goal counterexample',input=dict(source_density='1 on [-2,2]',t=1,q=1,physical_endpoint_g=1,physical_endpoint_v=1,auxiliary_h_range=[1,2],prefix_u=4,old_Ei='exactly the two disjoint continuous center families with fixed radii',stages=['k4 actual support pressure and logarithmic correction','k5 support repair','k8/16/32/64/128 same proved support regime']),rho=dict(kappa='h from actual source-contained expanded intervals',I=I,g1_atom=rho1,g2_atom=rho2,continuous_density='1/(2h^2)',continuous_total_mass=rhoint,total_probability=rho1+rho2+rhoint,capture_tail_for_1_lt_d_le_2=tail,capture_tail_at_d1=sp.Integer(1),capture_tail_at_d2=R(1,4)),small_shared_capture_rate_dimensionless=dict(u_range=[1,R(9,8)],formula=beta_u,zero_for='u>9/8',derivation='rho tail CDF integrated in center p from u-1 to1/8; v=u-p in[u-1/8,1] is positive; full h2 atom retained'),cases=cases,general_symbolic_branch=general,cost=dict(seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,processes=1,LP_calls=0,MC_samples=0),versions=dict(python=platform.python_version(),sympy=sp.__version__),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()));Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(dict(cost=payload['cost'],cases=[dict(k=c['k'],diff=c['selected_diff_fee_over_K'],hypothesis_residual=c['selected_diff_hypothesis_residual'],Q=c['small_old_Q_source_integral'],ratio=c['ratio_display'],tau=c['cutoff']['tau']) for c in payload['cases']]),indent=2))
if __name__=='__main__':main()
