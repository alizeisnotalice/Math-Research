% R570 actual continuous-center primitive: bounded deterministic MATLAB check.
% No Python execution, grid scan, Monte Carlo, or history certificate.
clear;
startedAt = tic;
artifactDirectory = fileparts(mfilename('fullpath'));
absoluteTolerance = 1e-13;
relativeTolerance = 1e-11;
kValues = [4,5,8];
largeCenters = [1/8,1/4];
zInterval = [1/16,1/8];
sigmaInterval = [1/4,3/4];
physicalEndpointProbability = 1/2;
rhoEndpoint = [1/2,1/4];
rhoDensity = @(h) 1./(2*h.^2);
rhoMass = sum(rhoEndpoint) + integral(rhoDensity,1,2,...
    'AbsTol',absoluteTolerance,'RelTol',relativeTolerance);
assert(abs(rhoMass-1)<1e-12);
results = struct([]);
for ki = 1:numel(kValues)
    k = kValues(ki);
    epsilon = 2^(-k);
    yInterval = epsilon*[-1/8,1/8];
    smallCenters = epsilon*[-1/8,1/8];
    smallOldWindow = [-k,1-k];
    assert(smallOldWindow(2)<sigmaInterval(1));
    % Every selected y is in every small old interval, hence every expanded one.
    assert(max(abs(yInterval'-smallCenters),[],'all')<=epsilon/2);
    % Every large old interval captures all selected y,z; expansions preserve it.
    assert(max(abs([yInterval,zInterval]'-largeCenters),[],'all')<=1/2);
    % L on selected z,sigma: integrate actual large center capture, not a lookup.
    largeOldField = @(z) intervalOverlap(largeCenters(1),largeCenters(2),z-1/2,z+1/2);
    liEndpoints = largeOldField(zInterval);
    liMid = largeOldField(mean(zInterval));
    assert(all(liEndpoints==diff(largeCenters)) && liMid==diff(largeCenters));
    Li = liMid; % no small old-window contribution on the selected sigma interval
    smallRate = diff(smallCenters)/epsilon;
    largeRate = diff(largeCenters);
    unionRate = smallRate+largeRate; % all proposals capture y, so U is constant
    a = zInterval(1)/epsilon;
    b = zInterval(2)/epsilon;
    captureAtH = @(h) integratedCenterSourceOverlap(h,a,b);
    % Center p and source z integrals are exact interval antiderivatives.
    % The remaining actual h integral is adaptive deterministic quadrature.
    breakpoints = 2*[a-1/8,a+1/8,b-1/8,b+1/8];
    breakpoints = unique(breakpoints(breakpoints>1 & breakpoints<2));
    captureContinuous = integral(@(h) captureAtH(h).*rhoDensity(h),1,2,...
        'Waypoints',breakpoints,'AbsTol',absoluteTolerance,'RelTol',relativeTolerance);
    captureEndpoint = rhoEndpoint.*[captureAtH(1),captureAtH(2)];
    captureDimensionless = sum(captureEndpoint)+captureContinuous;
    integratedSmallCapture = epsilon*captureDimensionless;
    % Both physical parents retain their Lebesgue center measures and g=v=1 atoms.
    outerFactor = diff(largeCenters)^2*physicalEndpointProbability^2*...
        diff(yInterval)*diff(sigmaInterval)/Li;
    selectedOverK = outerFactor*diff(zInterval);
    integratedExclusiveProbability = (smallRate*diff(zInterval)-integratedSmallCapture)/unionRate;
    diffOverK = outerFactor*integratedExclusiveProbability;
    % Original small credit, with old sigma-window length one. Independently
    % integrate source-field square and the two-center convolution identity.
    smallField = @(w) intervalOverlap(-1/8,1/8,w-1/2,w+1/2);
    qSourceDimensionless = integral(@(w) smallField(w).^2,-5/8,5/8,...
        'Waypoints',[-3/8,3/8],'AbsTol',absoluteTolerance,'RelTol',relativeTolerance);
    qCenterDimensionless = 2*integral(@(d) (1/4-d).*(1-d),0,1/4,...
        'AbsTol',absoluteTolerance,'RelTol',relativeTolerance);
    Qsmall = epsilon*qSourceDimensionless;
    ratioOverK = diffOverK/Qsmall;
    if k==4
        expectedCaptureDimensionless = (1-7*log(8/7))/32;
    else
        expectedCaptureDimensionless = 0;
    end
    expectedSelected = epsilon/4096;
    expectedDiff = epsilon/6144-epsilon^2*expectedCaptureDimensionless/96;
    expectedQ = 11*epsilon/192;
    expectedRatio = 1/352-2*epsilon*expectedCaptureDimensionless/11;
    relativeErrors = abs([selectedOverK/expectedSelected-1,...
        diffOverK/expectedDiff-1,Qsmall/expectedQ-1,ratioOverK/expectedRatio-1]);
    assert(max(relativeErrors)<1e-10);
    assert(abs(captureDimensionless-expectedCaptureDimensionless)<1e-12);
    assert(abs(qSourceDimensionless-qCenterDimensionless)<1e-12);
    results(ki).k = k;
    results(ki).epsilon = epsilon;
    results(ki).dimensionless_z_interval = [a,b];
    results(ki).h_quadrature_waypoints = breakpoints;
    results(ki).Li_from_actual_center_integral = [liEndpoints,liMid];
    results(ki).rates_small_large_union = [smallRate,largeRate,unionRate];
    results(ki).capture_endpoint_contributions = captureEndpoint;
    results(ki).capture_continuous_contribution = captureContinuous;
    results(ki).capture_dimensionless = captureDimensionless;
    results(ki).capture_dimensionless_closed_formula = expectedCaptureDimensionless;
    results(ki).integrated_z_small_capture = integratedSmallCapture;
    results(ki).selected_over_K = selectedOverK;
    results(ki).diff_over_K = diffOverK;
    results(ki).Q_small_source_integral = Qsmall;
    results(ki).Q_small_center_integral = epsilon*qCenterDimensionless;
    results(ki).diff_over_KQsmall = ratioOverK;
    results(ki).closed_formula_ratio = expectedRatio;
    results(ki).relative_errors_selected_diff_Q_ratio = relativeErrors;
    fprintf('k=%d eps=%.17g capture=%.17g Vselected/K=%.17g Vdiff/K=%.17g Qsmall=%.17g ratio/K=%.17g maxrel=%.3g\n',...
        k,epsilon,captureDimensionless,selectedOverK,diffOverK,Qsmall,ratioOverK,max(relativeErrors));
end
out.schema = 'R570.actual_continuous_primitive.MATLAB.float.1';
out.scope = 'Finite continuous-center/source/action primitive with remaining history gates set to one; floating check, not a full-history or mother-budget certificate';
out.matlab_version = version;
out.matlab_release = version('-release');
out.execution_directory = artifactDirectory;
out.command = sprintf('mcp__matlab__run_matlab_file({script_path:%s})',fullfile(artifactDirectory,'ccu_r570_matlab.m'));
out.script_sha256 = fileHash(fullfile(artifactDirectory,'ccu_r570_matlab.m'));
out.core_snapshot_sha256 = fileHash(fullfile(artifactDirectory,'ccu_r570_core.tex'));
out.parameters = struct('k_values',kValues,'large_centers',largeCenters,'z_interval',zInterval,...
    'sigma_interval',sigmaInterval,'physical_endpoint_probability',physicalEndpointProbability,...
    'rho_endpoint_probabilities',rhoEndpoint,'rho_continuous_density','1/(2*h^2), 1<h<2',...
    'absolute_tolerance_dimensionless',absoluteTolerance,'relative_tolerance',relativeTolerance);
out.rho_total_mass = rhoMass;
out.results = results;
out.seconds = toc(startedAt);
fid = fopen(fullfile(artifactDirectory,'ccu_r570_matlab.json'),'w');
assert(fid>=0);
fprintf(fid,'%s\n',jsonencode(out,PrettyPrint=true));
fclose(fid);
fprintf('MATLAB_VERSION=%s\nSCRIPT_SHA256=%s\nCORE_SNAPSHOT_SHA256=%s\nSECONDS=%.6f\n',...
    out.matlab_version,out.script_sha256,out.core_snapshot_sha256,out.seconds);

function v = intervalOverlap(a,b,c,d)
v = max(0,min(b,d)-max(a,c));
end

function v = integratedCenterSourceOverlap(h,a,b)
% Integral over p in [-1/8,1/8] of length([a,b] intersect [p-h/2,p+h/2]).
primitive = @(c) (max(1/8+c,0).^2-max(-1/8+c,0).^2)/2;
v = primitive(h/2-a)-primitive(-h/2-a)-primitive(h/2-b)+primitive(-h/2-b);
end

function h = fileHash(path)
fid = fopen(path,'rb');
assert(fid>=0);
bytes = fread(fid,Inf,'*uint8');
fclose(fid);
md = java.security.MessageDigest.getInstance('SHA-256');
md.update(bytes);
h = lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
