#!/usr/bin/env python3
"""R570 portable, sequential, isolated replay of three frozen Python artifacts.

Default inputs are sibling basenames. No draft /tmp path is a runtime input.
MATLAB is never executed here; its saved actual-tool transcript is checked.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import sympy as sp

FROZEN = {
    'numeric': 'b80965911146d2a974bfeb7661fbb9aab05a535c4fa1ad9ae9864347ded3246c',
    'certificate': 'b4e1ca67e2e2b7587de763804868fb047191350283495723459c58897385d71f',
    'ledger': 'f5f28e3fc1ec4923acbb30bbe94999b06605fecd98f7106bb39860eb83b6b4b6',
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def semantic(x):
    if isinstance(x, dict):
        return {k: semantic(v) for k,v in x.items()
                if 'sha256' not in k.lower()
                and not k.lower().endswith(('_path','_directory'))
                and k not in {'seconds','elapsed_seconds','runtime_seconds',
                              'wall_time_seconds','maxrss_bytes','peak_rss_bytes',
                              'command','python_executable'}}
    if isinstance(x,list): return [semantic(v) for v in x]
    return x

def diff(a,b,path=''):
    if type(a) is not type(b): return [path+':type']
    if isinstance(a,dict):
        return [p for k in sorted(set(a)|set(b)) for p in
                ([path+'/'+k+':missing'] if k not in a or k not in b
                 else diff(a[k],b[k],path+'/'+k))]
    if isinstance(a,list):
        if len(a)!=len(b):return [path+':length']
        return [p for i,(u,v) in enumerate(zip(a,b)) for p in diff(u,v,path+'/'+str(i))]
    return [] if a==b else [path]

def interval(x):
    lo,hi=F(x['lower_exact']),F(x['upper_exact'])
    assert lo<=hi
    return lo,hi

def expression(x):
    return sp.Rational(x['rational'])+sum(
        (sp.Rational(t['coefficient'])*sp.log(sp.Rational(t['argument']))
         for t in x['natural_log_terms']),sp.S.Zero)

def equal(a,b):
    return sp.simplify(sp.expand_log(a-b,force=True))==0

def independent_checks(numeric,cert,ledger):
    assert cert['requested_k']==[4,5,8,16,32,64,128]
    assert cert['all_geometric_and_algebraic_checks_pass'] is True
    assert cert['hypotheses_valid_for_all_requested_k'] is False
    assert F(numeric['rho']['g1_atom'])+F(numeric['rho']['g2_atom'])+F(numeric['rho']['continuous_total_mass'])==1
    rows=[]
    for n,c in zip(numeric['cases'],cert['results'],strict=True):
        k=n['k'];eps=F(1,2**k)
        assert c['k']==k and F(c['epsilon'])==eps
        # Actual source-contained cube extremes and selected old-window separation.
        assert 9*eps/8<2 and F(1,4)+1<2
        assert 5*eps/8<F(1,16) and 1-k<F(1,4)
        excluded=9*eps/8<F(1,16)
        assert excluded==(k>=5)==c['all_small_exclusive_strict']==n['constant_hit_hypothesis_valid']
        assert F(c['old_small_score'])==11*eps/192
        assert F(c['old_large_score'])==F(23,1536)
        assert F(c['selected_fee_over_K'])==eps/4096
        assert F(c['selected_old_field'])==F(n['selected_old_L'])==F(1,8)
        assert F(c['prefix_union_rate'])==F(3,8)
        assert sum(F(p['square_integral']) for p in c['small_old_field_pieces'])==11*eps/192
        g=c['cutoff_guards'];a=F(g['a']);D=g['Dclk']
        assert a<=eps<=1 and F(g['b'])==2 and D==max(k,8)+2
        assert F(g['tau'])==F(1,D)<F(1,8)
        assert F(g['startup_s_star_upper'])==F(1,D*D)<F(1,8)
        assert g['old_field_gate_strict'] and g['both_startup_gates_strict']
        if k==4:
            capture=(1-7*sp.log(sp.Rational(8,7)))/512
            actual_diff=7*(1+sp.log(sp.Rational(8,7)))/786432
            actual_ratio=7*(1+sp.log(sp.Rational(8,7)))/2816
            assert equal(expression(c['small_shared_capture_z_integral']),capture)
            assert equal(expression(c['selected_different_fee_over_K']),actual_diff)
            assert equal(expression(c['different_to_Qsmall_over_K']),actual_ratio)
            assert equal(sp.sympify(n['selected_diff_fee_over_K']),actual_diff)
            assert equal(sp.sympify(n['selected_diff_over_KQsmall']),actual_ratio)
            for key in ('hypothesis_diff','hypothesis_ratio'):
                h=c[key];lo,hi=interval(h['difference_interval'])
                assert lo<hi<0 and h['equal'] is False and h['direction']=='less'
            dlo,dhi=interval(c['selected_different_interval'])
            rlo,rhi=interval(c['ratio_interval'])
            assert 0<dlo<dhi<eps/6144 and 0<rlo<rhi<F(1,352)
            result='FAIL_simple_hypothesis_EXPECTED_corrected_log_PASS'
        else:
            assert expression(c['small_shared_capture_z_integral'])==0
            assert expression(c['selected_different_fee_over_K'])==sp.Rational(eps.numerator,eps.denominator)/6144
            assert expression(c['different_to_Qsmall_over_K'])==sp.Rational(1,352)
            for key in ('hypothesis_diff','hypothesis_ratio'):
                h=c[key];assert h['equal'] and interval(h['difference_interval'])==(F(0),F(0))
            assert interval(c['ratio_interval'])==(F(1,352),F(1,352))
            result='PASS_exact_formula'
        rows.append({'k':k,'epsilon':str(eps),'status':result,
                     'tau':g['tau'],'startup_upper':g['startup_s_star_upper']})
    # Independently check scalar algebra, with the retained D^2 dependency.
    A,C,L=sp.symbols('A C L',positive=True)
    root=(A*sp.sqrt(L)+sp.sqrt(C+A*A*L))**2
    assert sp.simplify(root**2-(2*C+4*A*A*L)*root+C*C)==0
    assert sp.expand((C+2*A*A*L)**2-4*A*A*(C*L+A*A*L*L))==C*C
    assert all(ledger['checks'].values())
    assert [F(x['Lclock_over_Lold']) for x in ledger['rational_coefficient_comparisons']]==[F(9,8),F(1),F(9,16)]
    assert 'D**2' in ledger['formulae']['target_dependency']
    return {'status':'PASS','cases':rows,'endpoint_method':'Fraction reads exact Arb lower/upper endpoints; no float sign decisions',
            'ledger':'Exact scalar polynomial/root and coefficient checks; outer clock D^2 retained',
            'limitations':['Primitive n=1 continuous source/center/action calculation; no complete history/head/first-stop/bulk-alpha construction.',
                           'The k>=5 own-small-score ratio is exact; it does not disprove a bound using large-parent credit or a full original history.',
                           'Tau and startup are bounds from actual cutoff parameters, not independent freely chosen thresholds.']}

def matlab_check(directory):
    data=json.loads((directory/'ccu_r570_matlab.json').read_text())
    note=(directory/'ccu_r570_matlab.md').read_text()
    match=re.search(r'```text\n(k=4 eps=.*?)\n```',note,re.S)
    assert match
    log=match.group(1)+'\n';logsha=hashlib.sha256(log.encode()).hexdigest()
    assert logsha=='a1dc926a77ca4db156143d1cd4e75869a356bc690d3792fd7eef324f4cc0c603'
    msha=sha(directory/'ccu_r570_matlab.m')
    assert msha==data['script_sha256']=='728636da0e7378171c4f64dea776121cf77b7f30c6e9ea90f4f9ad9bc59ce840'
    assert 'SCRIPT_SHA256='+msha in log
    assert 'CORE_SNAPSHOT_SHA256='+data['core_snapshot_sha256'] in log
    assert data['post_execution_cutoff_guard_metadata']['added_without_numerical_rerun']
    assert [r['k'] for r in data['results']]==[4,5,8]
    error=max(e for r in data['results'] for e in r['relative_errors_selected_diff_Q_ratio'])
    return {'status':'PASS_saved_actual_tool_log_hash','not_rerun':True,
            'script_sha256':msha,'json_sha256':sha(directory/'ccu_r570_matlab.json'),
            'saved_tool_log_sha256':logsha,'matlab_version':data['matlab_version'],
            'historical_core_snapshot_sha256':data['core_snapshot_sha256'],
            'maximum_reported_relative_error':error,'requested_tolerances':{'absolute':1e-13,'relative':1e-11},
            'error_label':'Double quadrature cross-check; requested tolerances and observed residuals are not rigorous error enclosures.',
            'cutoff_metadata':'Added after the sole MATLAB run; not additional numerical evidence.',
            'snapshot_scope':'Historical hash retained; current edited core is not asserted to match this run snapshot.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=parser.parse_args();directory=args.directory.resolve()
    # Fail before any job if a freeze hash or sibling input is missing.
    for name,expected in FROZEN.items():
        assert sha(directory/f'ccu_r570_{name}.py')==expected, 'Frozen hash changed: '+name
        assert (directory/f'ccu_r570_{name}.json').exists()
    work=Path(tempfile.mkdtemp(prefix='ccu_r570_repro_'))
    for name in FROZEN:shutil.copy2(directory/f'ccu_r570_{name}.py',work)
    assert sorted(x.name for x in work.iterdir())==sorted(f'ccu_r570_{n}.py' for n in FROZEN)
    jobs=[];observed={}
    for name in FROZEN:
        script=work/f'ccu_r570_{name}.py';output=script.with_suffix('.json')
        command=[sys.executable,str(script),'--output',str(output)]
        env=os.environ.copy()
        for var in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[var]='1'
        start=time.perf_counter()
        proc=subprocess.run(command,cwd=work,env=env,text=True,capture_output=True,timeout=300)
        elapsed=time.perf_counter()-start
        (work/f'{name}_stdout.txt').write_text(proc.stdout)
        (work/f'{name}_stderr.txt').write_text(proc.stderr)
        assert proc.returncode==0, name+': '+proc.stderr
        reference=directory/f'ccu_r570_{name}.json'
        got=json.loads(output.read_text());ref=json.loads(reference.read_text())
        differences=diff(semantic(got),semantic(ref))
        observed[name]=got
        jobs.append({'name':name,'command':command,'elapsed_seconds':elapsed,
                     'exit_code':proc.returncode,'stderr':proc.stderr,
                     'script_sha256':sha(script),'reference_sha256':sha(reference),
                     'replay_json_sha256':sha(output),'semantic_match':not differences,
                     'difference_paths':differences,'versions':got.get('versions',{k:got[k] for k in ('python','sympy','flint') if k in got})})
    checks=independent_checks(observed['numeric'],observed['certificate'],observed['ledger'])
    payload={'schema':'R570.independent.clean_repro.1','status':'PASS' if all(j['semantic_match'] for j in jobs) else 'MISMATCH',
             'independent_directory':str(work),'versions':{'python':platform.python_version(),'sympy':sp.__version__,'executable':sys.executable},
             'repro_script_sha256':sha(__file__),'jobs':jobs,'independent_checks':checks,
             'matlab_saved_evidence':matlab_check(directory),
             'comparison_policy':'Ignore SHA/path/runtime/RSS metadata only; retain mathematical fields, failure flags, precision and versions.',
             'isolation':'Exactly three Python scripts copied before execution; no source JSON or draft history copied; all jobs self-contained.'}
    args.output.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':payload['status'],'independent_directory':str(work),
                      'mathematical_matches':{j['name']:j['semantic_match'] for j in jobs},
                      'k4':checks['cases'][0]['status']},ensure_ascii=False))

if __name__=='__main__':main()
