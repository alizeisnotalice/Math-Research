#!/usr/bin/env python3
"""Verify saved R570 evidence and report structure; does not compile PDF."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,re,platform
import sympy as sp

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def formula(obj):
    if isinstance(obj,str):return sp.sympify(obj)
    return sp.Rational(obj['rational'])+sum((sp.Rational(t['coefficient'])*sp.log(sp.Rational(t['argument'])) for t in obj['natural_log_terms']),sp.S.Zero)

def run(root):
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for name,record in manifest['files'].items():
        p=root/name
        assert p.is_file() and p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],name
    assert not list(root.glob('*.pdf'))
    tex=(root/'REPORT.tex').read_text()
    clean=re.sub(r'(?<!\\)%[^\n]*','',tex)
    braces=re.findall(r'(?<!\\)[{}]',clean);balance=0
    for b in braces:
        balance+=1 if b=='{' else -1
        assert balance>=0
    assert balance==0
    stack=[]
    for action,env in re.findall(r'\\(begin|end)\{([^{}]+)\}',clean):
        if action=='begin':stack.append(env)
        else:assert stack and stack.pop()==env
    assert not stack
    assert '一般中心轴平行立方体极大算子的 $n^{1/2+o(1)}$ 一致弱型上界仍未证明' in tex
    assert sha(root/'REPORT.tex') in (root/'AUDIT.md').read_text()
    num=json.loads((root/'ccu_r570_numeric.json').read_text())
    cert=json.loads((root/'ccu_r570_certificate.json').read_text())
    pairs=[('selected_fee_over_K','selected_fee_over_K'),('selected_diff_fee_over_K','selected_different_fee_over_K'),('small_old_Q_source_integral','old_small_score'),('selected_old_L','selected_old_field'),('union_rate','prefix_union_rate'),('average_different','average_different_probability'),('selected_diff_over_KQsmall','different_to_Qsmall_over_K'),('small_shared_capture_z_average','small_shared_capture_z_average')]
    count=0
    for a,b in zip(num['cases'],cert['results'],strict=True):
        assert a['k']==b['k']
        for x,y in pairs:
            assert sp.simplify(sp.expand_log(formula(a[x])-formula(b[y]),force=True))==0,(a['k'],x)
            count+=1
    for b in cert['results']:
        for key in ['hypothesis_diff','hypothesis_ratio']:
            item=b[key];interval=item['difference_interval']
            lo=Fraction(interval['lower_exact']);hi=Fraction(interval['upper_exact'])
            assert lo<=hi
            if b['k']==4:assert hi<0 and not item['equal']
            else:assert lo==hi==0 and item['equal']
    replay=json.loads((root/'ccu_r570_repro.json').read_text())
    assert replay['status']=='PASS' and all(x['semantic_match'] for x in replay['jobs'])
    for x in replay['jobs']:
        assert x['script_sha256']==sha(root/f"ccu_r570_{x['name']}.py")
        assert x['reference_sha256']==sha(root/f"ccu_r570_{x['name']}.json")
    assert replay['matlab_saved_evidence']['not_rerun']
    return {'status':'PASS','python':platform.python_version(),'sympy':sp.__version__,'manifest_files':len(manifest['files']),'exact_cross_implementation_equalities':count,'k4_simple_hypothesis':'EXPECTED_FAIL; corrected formula retained','other_six_cases':'exact PASS','report_sha256':sha(root/'REPORT.tex'),'tex_braces_and_environments':'PASS, not compiled','strict_arb_residual_endpoints':'PASS','prior_isolated_replay':'three scripts PASS; not repeated here','matlab':'saved actual run evidence; not rerun','pdf_generated':False,'scope':'Evidence and structural checks only; general weak type bound remains unproved.'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);args=ap.parse_args()
    result=run(Path(__file__).resolve().parent)
    if args.output:args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
