# R570 实际连续几何 primitive 的 MATLAB 独立交叉核验

已实际运行通过，仅核验指定的 `k=4,5,8`。`k=4` 的全辅助动作会部分捕获旧源 z，故比值不能直接使用 `K/352`；`k=5,8` 的捕获修正为零，支持修复后的该公式。最大相对解析误差为 **2.220446049250313e-16**。这是浮点交叉核验，不是严格证书，也不是完整算法历史或完整母式预算的反例/证明。

## 已冻结的实际输入

与 numeric 直接核对 integrand 后才实现，未读取其计算结果，未运行 Python 计算。背景为 `n=1`、`mu=1_[-2,2] dx`、`epsilon=2^-k`、`gamma=G=2`。small 中心区间为 `epsilon[-1/8,1/8]`、半径参数 `R=epsilon`；large 中心区间为 `[1/8,1/4]`、`R=1`，两族 `t=q=1`。所有实际扩展仍在源支撑内，故 `kappa(h)=h,I=2`。

辅助动作完整概率为

`rho(dh)=delta_1/2 + delta_2/4 + 1_(1,2)(h) dh/(2h^2)`。

物理 `B,C` 都按 Lebesgue 中心 measure 积分，各保留其 `g=v=1` 原子概率 `1/2`。选定 `y∈epsilon[-1/8,1/8]`、`z∈[1/16,1/8]`、`sigma∈[1/4,3/4]`。small 旧窗口为 `[-k,1-k]`，与此 sigma 区间及 large 旧窗口 `[0,1]` 分离。代码以实际区间相交长度核得选定 z 上 `Li=1/8`；没有将 small 原旧场误加到此窗口。

small 的每个扩展均捕获所有选定 y；large 的每个扩展均同时捕获全部选定 y,z。这些判断由实际中心/源区间的极端距离核验。因此 `U=1/4+1/8=3/8` 恒定，而 `J(z)=1/8+b_epsilon(z)` 必须保留实际 small 捕获项。

Root 经 numeric 补充的 cutoff 守卫（仅增加元数据，未重跑数值）：取 `b=2,a=2^-max(k,8),gamma=G=2,rband=q=lambda=S=n=1,hwin=1/8`，`Dclk=max(k,8)+2`。本次三例均有 `Dclk=10,tau=0.1<Li=0.125`，`Rlarge=1=b/G,Rsmall=epsilon>=a`。实际 R569 启动阈值满足 `s_star<=Dclk^-2<=0.01<1/8`，因为 `K,Lambda>=1,CZ>=Dclk^2`；这里不是另选自由 s 或 tau。该守卫不构造 head、first-stop、bulk alpha 或完整历史，因此不改变本报告的 primitive 范围。

## 保留中心与源积分的降维

设 `p=P/epsilon`、`a=2^(k-4)`、`b=2^(k-3)`。实际项是

`∫_[1/16,1/8] b_epsilon(z) dz = epsilon C_k`，

其中

`C_k = ∫ rho(dh) ∫_[-1/8,1/8] length([a,b] ∩ [p-h/2,p+h/2]) dp`。

代码以正部平方原函数精确完成 p 与 z 的区间积分，然后对 h 作 MATLAB adaptive `integral`。两端点分别单列；k4 内部断点 `h=7/4` 单列为 waypoint。没有张量网格或蒙特卡洛，中心与源没有被替换为独立抽样。

另外，原 small 信用以两种实际一维积分核对：源场平方

`Qsmall/epsilon = ∫_[-5/8,5/8] length([-1/8,1/8]∩[w-1/2,w+1/2])^2 dw`

与中心差卷积

`Qsmall/epsilon = 2∫_0^(1/4) (1/4-d)(1-d) dd = 11/192`。

源场的两个内部折点 `±3/8` 单列。sigma 的真实旧窗口长度为一；没有把第三来源概率额外当作一份免费源质量。

原始物理系数全部保留为

`outer = |P_l|^2 (1/2)^2 |y| |sigma|/Li = epsilon/256`。

因此比较的解析式为

`Vselected/K = epsilon/4096`，

`Vdiff/K = epsilon/6144 - epsilon^2 C_k/96`，

`Vdiff/(K Qsmall) = 1/352 - 2epsilon C_k/11`。

独立求得 k4 的闭式 `C_4=(1-7 log(8/7))/32`；k≥5 因实际区间不交有 `C_k=0`。代码并未强制将 k5/8 的实际积分置零，而是先积分实际相交长度，再与零比较。

## 实际结果及容差

| k | C_k 实际积分 | Vdiff/K | Qsmall | Vdiff/(K Qsmall) |
|---|---:|---:|---:|---:|
| 4 | 0.0020400078633856763 | 1.0089517909204685e-5 | 0.0035807291666666665 | 0.0028177271833706176 |
| 5 | 0 | 5.0862630208333331e-6 | 0.0017903645833333333 | 0.002840909090909091 |
| 8 | 0 | 6.3578287760416663e-7 | 0.00022379557291666666 | 0.002840909090909091 |

k4 的 `h=1` 原子贡献为零，`h=2` 原子贡献为 `0.001953125`，连续 h 部分为 `0.00008688286338567617`，故不能漏掉 `h=2` 原子。rho 全质量实际积分为一。

所有 quadrature 均先作无量纲缩放，`AbsTol=1e-13, RelTol=1e-11`；MATLAB 的这两个设定是请求容差，不是严格误差证书。所得源场/中心卷积与解析式一致。最大相对误差涵盖 selected、diff、Qsmall 与 ratio，为 `2.220446049250313e-16`；k5/8 这四项的 double 对照残差均为零。

## 实际执行与归档

只执行了一次本脚本：

```text
mcp__matlab__run_matlab_file({"script_path":"/tmp/ccu_r570_matlab.m"})
```

工具实际返回的完整文字输出：

```text
k=4 eps=0.0625 capture=0.0020400078633856763 Vselected/K=1.52587890625e-05 Vdiff/K=1.0089517909204685e-05 Qsmall=0.0035807291666666665 ratio/K=0.0028177271833706176 maxrel=2.22e-16
k=5 eps=0.03125 capture=0 Vselected/K=7.62939453125e-06 Vdiff/K=5.0862630208333331e-06 Qsmall=0.0017903645833333333 ratio/K=0.002840909090909091 maxrel=0
k=8 eps=0.00390625 capture=0 Vselected/K=9.5367431640625e-07 Vdiff/K=6.3578287760416663e-07 Qsmall=0.00022379557291666666 ratio/K=0.002840909090909091 maxrel=0
MATLAB_VERSION=26.1.0.3312084 (R2026a) Update 4
SCRIPT_SHA256=728636da0e7378171c4f64dea776121cf77b7f30c6e9ea90f4f9ad9bc59ce840
CORE_SNAPSHOT_SHA256=4974cdedfac525d197f7faa26a7dad43ef582728c82b53bd6d7e148255085390
SECONDS=0.350902
```

- `.m` SHA-256: `728636da0e7378171c4f64dea776121cf77b7f30c6e9ea90f4f9ad9bc59ce840`
- MATLAB 原始执行 `.json` SHA-256: `e6321837af82e7362291d9d998b33eb458181c122e77527b5457850c9fcb1bc8`
- 增补上述 cutoff 元数据后交付 `.json` SHA-256: `421434fc4a922b418731f276cf0c1e44721422ce42adc3b4d701d59e0c3bc3f9`；数值、版本、运行快照及命令输出均未更改，增补区显著标记为 `post_execution_cutoff_guard_metadata`，并保留原始执行 JSON 哈希。
- 运行时相邻 core 快照 SHA-256: `4974cdedfac525d197f7faa26a7dad43ef582728c82b53bd6d7e148255085390`
- 上述命令文字输出（末行含换行）SHA-256: `a1dc926a77ca4db156143d1cd4e75869a356bc690d3792fd7eef324f4cc0c603`

所有脚本输入/输出/哈希位置以 `fileparts(mfilename('fullpath'))` 定位，保持相邻 basename 即可归档迁移。实际 MATLAB 规范目录为 `/private/tmp`。只写本角色的 `.m/.json/.md`，已把结果与执行事实发 numeric 用于 compute index，未更改他人文件、仓库或重算其 Python。已完成指定一次核验，停止计算。
