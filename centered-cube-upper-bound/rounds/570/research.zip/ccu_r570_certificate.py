#!/usr/bin/env python3
"""Independent exact Lebesgue-center geometry; only the k=4 log needs Arb."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import argparse,json,platform

KS=[4,5,8,16,32,64,128]

class LogAffine:
    def __init__(self,c=F(0),terms=None):
        self.c=F(c);self.terms={F(r):F(a) for r,a in (terms or {}).items() if a and F(r)!=1}
    def add(self,other):
        if not isinstance(other,LogAffine):other=LogAffine(other)
        terms=dict(self.terms)
        for r,a in other.terms.items():terms[r]=terms.get(r,F(0))+a
        return LogAffine(self.c+other.c,terms)
    def scale(self,a):return LogAffine(self.c*a,{r:v*a for r,v in self.terms.items()})
    def data(self):return dict(rational=str(self.c),natural_log_terms=[dict(argument=str(r),coefficient=str(a)) for r,a in sorted(self.terms.items())])
    def enclosure(self):
        if not self.terms:return dict(lower_exact=str(self.c),upper_exact=str(self.c),arithmetic='Fraction exact',approximate_display=float(self.c))
        from flint import arb,ctx
        ctx.prec=192
        value=arb(self.c.numerator)/self.c.denominator
        for r,a in self.terms.items():value+=(arb(a.numerator)/a.denominator)*(arb(r.numerator)/r.denominator).log()
        lo=F(str(value.lower().fmpq()));hi=F(str(value.upper().fmpq()))
        return dict(lower_exact=str(lo),upper_exact=str(hi),arithmetic='Arb192 outward rational endpoints',approximate_display=float(value.mid()))
    def compare(self,expected):
        delta=self.add(-F(expected));enc=delta.enclosure();lo=F(enc['lower_exact']);hi=F(enc['upper_exact'])
        if not delta.terms:return dict(equal=delta.c==0,direction='equal' if delta.c==0 else ('less' if delta.c<0 else 'greater'),difference=delta.data(),difference_interval=enc)
        assert hi<0 or lo>0
        return dict(equal=False,direction='less' if hi<0 else 'greater',difference=delta.data(),difference_interval=enc)


def overlap(a,b,c,d):return max(F(0),min(b,d)-max(a,c))
def field(z,lo,hi,R):return overlap(lo,hi,z-R/2,z+R/2)/R

def square_field_integral(lo,hi,R):
    cuts=sorted({F(-2),F(2),*[v for v in [lo-R/2,hi-R/2,lo+R/2,hi+R/2] if -2<v<2]})
    result=F(0);pieces=[]
    for a,b in zip(cuts,cuts[1:]):
        va=field(a,lo,hi,R);vb=field(b,lo,hi,R)
        integral=(b-a)*(va*va+va*vb+vb*vb)/3
        result+=integral;pieces.append(dict(z_interval=[str(a),str(b)],L_left=str(va),L_right=str(vb),square_integral=str(integral)))
    # Independent center-pair overlap integral. Here width<=old side R.
    width=hi-lo;assert 0<width<=R
    pair_result=width*width/R-width**3/(3*R*R)
    assert result==pair_result
    return result,pieces


def integrated_small_shared(eps):
    # Integrate z first and then the REAL Lebesgue parent center p.
    # On the rigorously checked support, left cell edges and z_upper never
    # clip, and the lower p edge gives zero positive part. Thus the p,z
    # capture area is (eps*h/2+eps/8-zlo)_+^2/2.
    zlo=F(1,16);a=eps/2;b=eps/8-zlo
    assert b<0
    # Restored rho atoms: 1/2 at h1, 1/4 at h2.
    constant=sum((weight*max(F(0),a*h+b)**2/(2*eps) for h,weight in [(F(1),F(1,2)),(F(2),F(1,4))]),F(0))
    start=max(F(1),-b/a)
    if start>=2:return LogAffine(constant),dict(continuous_start=str(start),active_continuous_part=False)
    # rho_continuous=dh/(2h^2). Primitive of (a*h+b)^2/h^2
    # is a^2*h + 2ab*ln(h) - b^2/h.
    constant+=(a*a*(2-start)+b*b*(1/start-F(1,2)))/(4*eps)
    log_coefficient=2*a*b/(4*eps)
    return LogAffine(constant,{F(2)/start:log_coefficient}),dict(continuous_start=str(start),active_continuous_part=True,primitive_polynomial_coefficients=[str(a*a),str(2*a*b),str(b*b)])


def universal_support_guards():
    # Each gap is affine in epsilon. Endpoint positivity is a rigorous
    # certificate on the ENTIRE closed interval, not a sampled inference.
    specs=[
        ('small expanded source support',F(2),F(-9,8),True),
        ('old small cannot capture selected z',F(1,16),F(-5,8),True),
        ('every small old cube captures selected y',F(0),F(1,4),False),
        ('large old lower edge below selected y',F(1,4),F(-1,8),True),
        ('large old upper edge above selected y',F(5,8),F(-1,8),True),
        ('small left endpoint below selected z',F(1,16),F(3,8),True),
        ('selected z upper bound never clips small capture',F(1,8),F(-9,8),True),
        ('lower small parent never reaches selected z',F(1,16),F(-7,8),True),
        ('small mass below coarse early threshold one half',F(1,2),F(-2),True),
    ]
    out=[]
    for name,c,a,strict in specs:
        vals=[c,c+a*F(1,16)]
        assert min(vals)>0 if strict else min(vals)>=0
        out.append(dict(name=name,gap_constant=str(c),gap_epsilon_coefficient=str(a),endpoint_values=list(map(str,vals)),strict=strict))
    exclusion_root=F(1,16)/F(9,8)
    assert exclusion_root==F(1,18)
    return dict(epsilon_interval='0<epsilon<=1/16',method='exact affine endpoint certificate',guards=out,all_small_exclusive_strict_requires='epsilon<1/18',exclusion_boundary=str(exclusion_root))


def one(k):
    eps=F(1,2**k);assert 0<eps<=F(1,16)
    slo,shi=-eps/8,eps/8;llo,lhi=F(1,8),F(1,4)
    ylo,yhi=-eps/8,eps/8;zlo,zhi=F(1,16),F(1,8)
    # Real support guards; these prove no omitted source-boundary clipping.
    assert slo-eps>=-2 and shi+eps<=2
    assert llo-1>=-2 and lhi+1<=2
    assert shi+eps/2<zlo and yhi-slo<=eps/2 and shi-ylo<=eps/2
    assert lhi-F(1,2)<=ylo<=yhi<=llo+F(1,2)
    assert lhi-F(1,2)<=zlo<zhi<=llo+F(1,2)
    # Guards for the positive-part-square Fubini reduction at all h in[1,2].
    assert shi-eps/2<zlo and shi+eps<zhi and slo+eps<zlo
    Qsmall,smallpieces=square_field_integral(slo,shi,eps)
    Qlarge,largepieces=square_field_integral(llo,lhi,F(1))
    assert Qsmall==11*eps/192 and Qlarge==F(23,1536)
    selected_L=field(zlo,llo,lhi,F(1));assert selected_L==field(zhi,llo,lhi,F(1))==F(1,8)
    # Uniform-source expanded mass=hR gives kappa=h and I=1+1/2+1/2=2.
    I=F(1)+F(1,2)+F(1,2);assert I==2
    rho_mass=F(1,2)+F(1,4)+F(1,4);assert rho_mass==1
    small_rate=(shi-slo)/eps*rho_mass;large_rate=(lhi-llo)*rho_mass
    union=small_rate+large_rate;assert union==F(3,8)
    # Physical selected g=v=1 each has endpoint rate1/2. Parent mass mB=1.
    fee=(lhi-llo)**2*F(1,2)**2*(yhi-ylo)*(zhi-zlo)*F(1,2)/selected_L
    assert fee==eps/4096
    shared_int,method=integrated_small_shared(eps)
    shared_mean=shared_int.scale(1/(zhi-zlo))
    different=LogAffine(small_rate/union).add(shared_mean.scale(-1/union))
    common=LogAffine(1).add(different.scale(-1))
    diff=different.scale(fee);ratio=diff.scale(1/Qsmall)
    if k>=5:assert not shared_int.terms and shared_int.c==0
    for expr in [shared_int,shared_mean,common,different,diff,ratio]:
        enc=expr.enclosure();assert F(enc['lower_exact'])>=0
    expected_diff=diff.compare(eps/6144);expected_ratio=ratio.compare(F(1,352))
    assert expected_diff['equal']==expected_ratio['equal']==(k>=5)
    a_cutoff=F(1,2**max(k,8));b_cutoff=F(2);Dclk=max(k,8)+2
    tau=F(1,Dclk);startup_upper=F(1,Dclk**2)
    assert a_cutoff<=eps and 1<=b_cutoff/2 and tau<=F(1,10)<selected_L
    assert startup_upper<=F(1,100)<large_rate
    cutoff=dict(a=str(a_cutoff),b=str(b_cutoff),n=1,gamma=2,G=2,S=1,q=1,lambda_band=1,rband=1,hwin='1/8',Dclk=Dclk,tau=str(tau),startup_s_star_upper=str(startup_upper),actual_startup_formula='s_star=1/[Lambda*(K^2*Dclk^2+K*S*An*Dclk)]',bound_reason='K>=1, Lambda>=1, CY>=0; hence s_star<=Dclk^-2',old_field_gate_strict=True,both_startup_gates_strict=True)
    return dict(cutoff_guards=cutoff,k=k,epsilon=str(eps),source_support=['-2','2'],small_parent_centers=[str(slo),str(shi)],large_parent_centers=[str(llo),str(lhi)],old_windows=dict(small=[-k,1-k],large=[0,1],selected_sigma=['1/4','3/4']),small_old_field_pieces=smallpieces,large_old_field_pieces=largepieces,old_small_score=str(Qsmall),old_large_score=str(Qlarge),selected_old_field=str(selected_L),I=str(I),rho_atom_h1='1/2',rho_continuous='dh/(2h^2), 1<h<2',rho_atom_h2='1/4',rho_total_mass=str(rho_mass),small_full_proposal_rate=str(small_rate),large_full_proposal_rate=str(large_rate),prefix_union_rate=str(union),all_small_exclusive_strict=shi+eps<zlo,selected_fee_over_K=str(fee),small_shared_capture_z_integral=shared_int.data(),small_shared_capture_z_average=shared_mean.data(),capture_integration=method,average_common_probability=common.data(),average_common_interval=common.enclosure(),average_different_probability=different.data(),average_different_interval=different.enclosure(),selected_different_fee_over_K=diff.data(),selected_different_interval=diff.enclosure(),different_to_Qsmall_over_K=ratio.data(),ratio_interval=ratio.enclosure(),hypothesis_diff=expected_diff,hypothesis_ratio=expected_ratio)


def run():
    support=universal_support_guards()
    results=[one(k) for k in KS]
    import flint
    return dict(scope='Exact primitive Lebesgue-parent/uniform-source integrals; remaining head/stop/history gates set to one, not constructed full original history or global weighted theorem',python=platform.python_version(),arithmetic='Fraction for all geometry and scores; Arb192 only for the genuine k4 logarithm',flint=flint.__version__,requested_k=KS,universal_support_certificate=support,all_geometric_and_algebraic_checks_pass=True,hypotheses_valid_for_all_requested_k=False,discrepancy='k4 full restored action law has nonzero small shared capture; k>=5 repairs exclusion',code_sha256=sha256(Path(__file__).resolve().read_bytes()).hexdigest(),results=results)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path);args=ap.parse_args()
    text=json.dumps(run(),indent=2)+'\n'
    if args.output:args.output.write_text(text)
    print(text,end='')
