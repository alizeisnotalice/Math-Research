# R570 源账：旧 cap、实际母账与本轮外父积分的范围

**决定：本轮 whole-scope 粗界是另一完整常数，可与旧 \(K^2D_{\rm clk}W\) 取较小者；没有一般维数阶改善。** 只检索 R565–R569 REPORT 的相关段及本轮两份指定文件。没有网络、全历史、PDF、子代理或仓库修改。

## 1. 最早允许引用什么：区分“原文已印”与“由已印式直接推得”

**在限定的 R565–R569 范围内，最早完整证明链已在 R565。** R565 REPORT:55–59 定义并冻结全 \(E_i\) 的 \(L_i\)，:85–104 给真实 \(d\mathcal M\)、行帽 \(r_B\le K\) 与原 stop/head/phase 范围；:240–242 的式(9) 精确写出
\[
 V_R=K\int_{\rm bulk}r_Bq_0\int_{L_i>\tau}\frac{k_B}{L_i}\,d\mu_i d\sigma\,dB,
 \qquad 0\le q_0\le1.
\]
因此同一原测度的任何正子支 \(G\subseteq R\) 都有
\[
 V_G\le K^2\sum_i\int_{L_i>\tau}\frac{L_i^{\rm bulk}(z,\sigma)}{L_i(z,\sigma)}d\mu_i d\sigma
 \le K^2D_{\rm clk}W.
\tag{old-cap}
\]
末步是 \(L_i^{\rm bulk}\le L_i\)，且所有 bulk 旧窗都在
\([\log_\gamma(qa^n),\log_\gamma(\lambda_{\rm band}b^n)+1]\)
内，长度 \(D_{\rm clk}=1+\log_\gamma r_{\rm band}+n\log_\gamma(b/a)\)；实际上限 \(b/G^{1/n}\) 只会缩小此范围。源格互斥，只收一次 \(W\)。无需 \(1/\tau\)、父质量 \(SA_nW\) 或新的 source normalization。

**引用措辞应为“由 R565 式(9)、行帽和旧窗范围立即得”，不能称 R565 已有该原样 display。** 本轮定点检索中，R568 REPORT:97、R569 REPORT:95–97 印的是较松 \(K^2SA_nD_{\rm clk}W\)，不是上式。R569 REPORT:217–223 的 (P7) 明确再次使用同一个 \(K^2\int L_i^b/L_i\) 积分，是锐 cap 的直接佐证。R569 REPORT:22 说明更早 R562 已有 posterior/clock 粗预算；本次未读 R562，故不认证其最早历史位置。

## 2. 旧 cap 与本轮 whole-scope 各需哪些真实条件

| 对象 | 可以使用的实际假设 | 不可外推 |
|---|---|---|
| old-cap | 原完整 \(E_i\) 上冻结的 \(L_i\)，内父只取原 bulk；原行帽 \(r_B\le K\)；原 receiver 核为概率/子概率；旧单位窗；互斥 \(C_i\)。 | \(r_B\le K\) 已依赖原合法动作和 phase/head/core/first-stop 构造，不给新 actions 自动继承。不能删除旧父后重算 \(L_i\)，或归一化 bulk 当成概率。 |
| 外父 \(C\) 合并 | R569 REPORT:227–237 (P8) 的精确系数及 **先合并实际 stop 反链** 后 \(\sum_T\mathfrak b\le1\)；其余实际 gate 均在 \([0,1]\)。必须保 \(y\in Q_C(v)\)、真实双向帐篷窗 \(N/\gamma<M_C(v)<\gamma N\)。 | 单向 head 不给该双边窗。不能逐 \(T\) 或相位分别求同样中心体积后忘记累加；合法反链合并无需额外相位数 \(J\)。 |
| 整序 action 矩 | 恢复概率恰为 \(\rho_B=\omega/(I_B\kappa_B)\)，故 \(\int\kappa_B\rho_B=\Lambda/I_B\)。原 \(I_BI_C\) 均来自实际恢复。 | 不保留 \(N_BN_C\) 折扣；不把未归一化新 action measure 换进同一矩公式。 |

R570 order:37–49 的外父 cap 有完整必要条件：固定真实 \((B,g,y)\)、\(N=M_B(g)\)，
\[
 \int 1_{y\in Q_C(v)}1_{N/\gamma<M_C(v)<\gamma N}\,d\nu(C,v)
 \le 2GS\gamma^2r_{\rm band}=C_{\rm out}.
\]
固定 \(v\) 时，\(R_C^n\le\gamma N/q\) 约束实际中心域体积，原密度帽为 \(S\lambda_{\rm band}\gamma/N\)；不是额外独立 \(dR_C\) 积分。两端 action 原子由 \(\int v\omega(dv)=2G\) 保留。相位可在原非零窗已确定后作为非负 gate 放宽，不能先丢掉质量窗仍使用该 cap。

order:104–137 的 whole-scope 推导保真实 \(y\) 质量积分，再用 action 矩，确实得到
\[
 V_G\le K C_{\rm out}\Lambda\int\frac{L_i^{(I)}}{L_i}d\mu_i d\sigma
 \le L_{\rm clock}W,
 \qquad L_{\rm clock}=2GS\gamma^2r_{\rm band}K\Lambda D_{\rm clk}.
\tag{new-cap}
\]
这里 order:116 的 \(\Sigma_B\) 必须读为 **原旧单位窗 \([s_B,s_B+1]\)**；不能混同 R569 REPORT:85–86 的外父扩展支持 \(\Sigma_C\)，后者长度为 \(3+2h\)。whole-scope 无需 early 身份：在合并外父前就放宽竞争比率为 1 即可。因此不能把 (new-cap) 记为 early 独有收益，也不能说其已支付更强 prefix 比率相对旧 score 的衰减。

## 3. 实际母账出处及无维数阶改善的精确含义

**最早母账：** R565 REPORT:124–147（继承母式、\(a<d^4/(4J^2)\)、全部外费保留），:281–296（原信用 Cauchy 与 \(a=0\) 条件回代）。R566 REPORT:124–147 重印通用式 (M1)。**最新精确标量正根：** R569 REPORT:499–542，(M1) 为 full，(M2) 为已付 near 后的 far；:539–542 明确保留入口、删除、时间原子及 cutoff。

令 \(A_0=J/d^2\)、\(C_{\rm mother}=2A_0(K_w+K+F_{\rm cap})+2B_{\rm rem}/d\)。直接整账路线可取
\[
 a=0,\quad L=\min\{K^2D_{\rm clk},L_{\rm clock}\}.
\]
不使用 startup/records 分解，**不另加 \(B_0\)**。原母式选 \(\zeta=1/(2A_0)\) 即给足够的明确粗回代
\[
 Q/W\le b_0^{-2}(2C_{\rm mother}+4A_0^2L),\qquad
 R_*/W\le2b_0^{-1}\sqrt{D_{\rm clk}(2C_{\rm mother}+4A_0^2L)}.
\]
若 \(G=\mathrm{far}\)，near 只计原来一次，并用 far 的实际母账；不得拼 full 的较松门槛与 far 的较小剩余。

两帽的精确比是
\[
 \frac{L_{\rm clock}}{K^2D_{\rm clk}}
 =\frac{2\gamma^2r_{\rm band}}{1+\ln(G\gamma^{1+h}r_{\rm band})}.
\]
故不存在参数全域的统一更强关系；可以有常数或对数收益，但未去掉 clock。即使其余参数有界，\(L\) 仍正比 \(D_{\rm clk}\)，外层另有 \(\sqrt{D_{\rm clk}}\)，这条回代给的是 clock 线性规模。\(\log(b/a)\)、\(G\)、密度带及相位数的截断依赖未受新界控制，所以不能据此宣称 \(n^{1/2+o(1)}\) 或一般维数阶提升。

## 4. 版本与证据等级

基线 commit 由 R570 合同指定为 `272f6048dedda262cd6088eadd74ceab7dfa5d7e`；此处不修改/重验仓库。实际读取文件 SHA-256：

| 文件 | SHA-256 |
|---|---|
| `/tmp/ccu_r565_archive/REPORT.tex` | `de0128c6c06b19b06d47ef81f4f5bfb23ec340f974bd28e1259a8ebf5206bb79` |
| `/tmp/ccu_r566_archive/REPORT.tex` | `79fdc05b943b20e6ed16d98ab6f3b3a9ea8c48d64a466af136c2f843ebd91454` |
| `/tmp/ccu_r569_archive/REPORT.tex` | `7b894e3dadc61eb790cd6b06088ce62c7448f419dc731a97dc2e2ed076cd8f4e`，与合同一致 |
| `/tmp/ccu_r570_order.tex` | `fa18fe3e75bb48db7167af8288ec159a73cc79f729531fec211843b8facec9df` |
| `/tmp/ccu_r570_contract.md` | `7e1194d72a4d44b57fd166bda2038f5392203d6c7e4ddf846e03bc33fb962cb6` |

已读 **L03**：本轮只用其“明确残差、区分候选与证明”的核验规范；不从任意来源索引取解析/Fubini/几何定理，不声称通用区间 API 已认证。实际本机 SymPy 仅核比值恰为 \(2\gamma^2r_{\rm band}/\ell\)（\(\ell=1+\ln(G\gamma^{1+h}r_{\rm band})\)）及 \(a=0,\zeta=1/(2A_0)\) 的母式恰化为 \(2C+4A_0^2L\)。这两项为精确代数佐证，不替代上述真实测度和 stop 条件。

**停止状态：** 已完成定点去重和来源 ledger；允许引用的是完整 cutoff 粗界及其条件母账，不是全 prefix 结构的终端收缩或一般根阶结论。


## 归档补充：技能、外部规范及依赖

本轮实际重读更新64项技能中的 L03 `/Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md` 及 provenance；其旧认证范围不直接认证本轮 Arb 结果。本轮实际调用 python-flint 并输出严格有理端点。I02 在延续时重读，但本轮没有调用其通用投影/补偿定理，也不据它认证新随机过程。

仓库规模规范已于2026-10-24实际读取 GitHub 官方页面：[Repository limits](https://docs.github.com/en/repositories/creating-and-managing-repositories/repository-limits)。当前页面区分100 MB单对象及2 GB单推送硬限制，和单目录3000条目等建议；不是仓库总文件数上限。本轮仅两份轮次文件加项目索引更新，不新增PDF、原始资料副本或模型全量扫描。

早期来源表保留原本实际阅读的 `/tmp` 路径与快照哈希，属于出处记录，不是运行依赖。历史数学依据在本仓库相应轮次 `research.zip` 内；本轮代码与报告运行不读取这些临时路径。最终报告哈希见最终独审记录和 MANIFEST.json。
