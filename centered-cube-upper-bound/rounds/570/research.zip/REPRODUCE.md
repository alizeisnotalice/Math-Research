# 第570轮复现

在独立目录解压 research.zip。报告自包含；不编译PDF。Python代码只读取自身或同目录归档，历史 /tmp 路径仅为来源记录。

实际环境为 Python3.12.14、SymPy1.14.0、python-flint0.9.0，解释器：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`

从解压目录执行（替换python为上面的解释器）：

```sh
python verify.py
python ccu_r570_repro.py
```

独立运行某一路时应把结果写到新位置，以保原始证据：

```sh
python ccu_r570_numeric.py --output /tmp/r570_numeric_replayed.json
python ccu_r570_certificate.py --output /tmp/r570_certificate_replayed.json
python ccu_r570_ledger.py --output /tmp/r570_ledger_replayed.json
```

主代码及证书没有数据输入依赖；证书未给--output时打印JSON到stdout。repro脚本复制冻结脚本到新目录执行并比较数学字段，不使用原生成目录里的帮助代码。具体真实命令和隔离目录见repro结果。verify检查固定文件哈希、LaTeX结构、精确两路结果与严格端点，不将结构检查等同TeX编译。

MATLAB可从脚本所在目录运行 `ccu_r570_matlab`，输出同目录JSON。脚本按mfilename定位，不依赖历史 /tmp。原记录是一次真实运行；Python隔离回放没有再次运行MATLAB，也不声称复现过未运行的软件。MATLAB脚本会重建数值字段；JSON中注明的事后cutoff元数据属于解析补充，可能不由原脚本自动重建。

期望状态：k4原简单different假设失败且修正公式通过；k5/8/16/32/64/128精确式通过。全部守卫与primitive范围必须保留。重跑得到不同运行时间不是数学差异；源代码哈希、精确费用、支撑判定或证书方向不同则须调查。没有一般维数证明。
