# R570 独立命题筛查：早提案回到其旧信用时的唯一关键负载

仅阅读 R570 contract，未读任何 R570 作者稿。以下聚焦一个可修复的 scope 问题：把 early proposal 的旧窗改到它自己的合法旧窗，究竟能向原 Qg 收取什么。共同质量层级、滑动竞赛若采用此转移，必须在同一公式下累计，不能按层重发信用。

固定原 dV_G（full R 或已付 near 后的原 far），S 为 R569 双启动事件，u=γ²M，U=A_y+A_z−J。用完整 early-exclusive 账定义有限正入流

 dη(p)=∫ 1_S · 1_{m_p≤u,m_p<γ^(σ−1)}
              ·|1_Cp(y)−1_Cp(z)|/U ·dV_G ·dν(p)。

因此 η(total)=V_early，所有原 Li(z,σ)⁻¹、IBIC、旧窗及 stops 仍藏在此真实积分中；不是无权 proposal 计数。由 Tonelli，η(dp)=ell(p)ν(dp)，取 ellbar(P)=∫ell(P,h)ρ_P(dh)，a_P=t_P/R_P^n，则按原父投影的入流是

 η_P(dP)=a_P ellbar(P)dP。

这是后续任何 old-window 信用映射首先必须接受的母量。early 定义已确保 k_P(·,σ)=0；不能继续使用旧 σ 假装得到 P 的信用。

## 可修复的唯一转移：使用原信用偏置核，而非普通旧概率

若只是改抽 (w,τ)∼k_P(w,τ)μ_i(dw)dτ/(t_Pq_P)，相对于原信用测度

 dC(P,w,τ)=L_i(w,τ)k_P(w,τ)dP μ_i(dw)dτ，
 ∫dC=Qfr≤Qg，

推送入流的 RN 恰为 ellbar(P)/[m_P L_i(w,τ)]。因此“合法旧窗+概率归一”没有支付新位置的旧场倒数；这正是最可能被遗漏的 scope。

一种严格可行的分析修复是改用现有冻结信用的条件概率

 C_P(dw,dτ)=L_i(w,τ)k_P(w,τ)μ_i(dw)dτ/e_P，
 e_P=C0t_Pq_Pα_P。

在 e_P>0 的原 bulk 上它归一、自动落在 P 的真实 oldcube/oldwindow，并且不改原 Li、α 或动作。此时推送入流对 dC 的 RN 简化为

 a_P ellbar(P)/e_P=ellbar(P)/(C0 m_P α_P)。

所以准确且可验证的新几何目标是按原父的**加权入流容量**

 a_P ellbar(P)≤a e_P  （dP-a.e.），

或相应 aggregate/容量分配后的版本。若成立，就有 V_early≤aQfr≤aQg；它不需要对目标 old Li 给额外点值下界。这里 C_P 是证明中的信用分配核，绝不是新物理 action；若作者要据它生成动作，仍须另证原 nonanticipative/source-before 规则，当前公式不授权这种替换。

## 同一来源、同一信用、真实 terminal 的三项合并关系

若质量层级或滑动旧窗给分支 j，每一支均须从原费作正分配：Σ_j dV_j≤dV_G，余下原 terminal 明列。其入流 ellbar_j(P) 累加以后只能消费一次原信用：

 Σ_j a_P ellbar_j(P)≤a e_P；

若用份额 θ_j(P)，则 Σ_jθ_j(P)≤1 且各支≤aθ_j(P)e_P。不能对每个旧 σ 或每个质量层分别用一遍 e_P。若只作按父容量截断，取 L(P)=Σ_j a_P ellbar_j(P)，按 min(1,a e_P/L(P)) 薄化入流，未付费用准确为

 V_excess=∫[L(P)−a e_P]_+dP。

这个 excess 留在原分配的未付部分，不能因后移到合法旧窗就丢弃；再使用历史改耦合时还须真实旧边际桥。该式可作作者第一项决定性诊断：能否在完整 geometry 下压住加权入流，而不只是降低 early proposal 的概率。

来源 W 账独立地仍须共享。若各层调用固定簇 H 的资格价，则全族实际来源价格为 Π=Σ_{j,H}θ_{j,H}μ_i(H)，只可用已证明的 Π≤BW，而非“每个 σ 都有一份 BrecW”。一个共同 seed 不自动给后者的统一价；滑动窗口删除早提案破坏 R569 的 nested-prefix 结构，须证明所得全窗口共同字典的实际覆盖重数/总质量，或留作此 Π。原 tuple 查询已固定的总字典合法；用 seed 替换实际 B,C 后再套原父 payer 不合法。

最终消耗应以同一完整正分解写成 V_G≤aQg+cLclΠ+V_terminal（或将已付 R569 startup/hit 与原 Vdiff 分支保留后写对应式）。若 near 已付，所有这些 a 的总和而非每支各自须满足 far 门槛 1/(8A0²)；full R 对应 1/(4A0²)。任何新报价必须把已有 B0W 与仍在原账外的费用保留。

**先验判定：** 信用偏置核给出合法且更可修复的 old-window 接口；核心待证量是累计 a_P ellbar(P) 对原 e_P 的负载，而非概率归一或窗内支持。尚无完整几何界、共同滑动字典新价格或 terminal 消失主张。指定本机 SymPy 实跑核两种 RN 的代数残差均为 0；未扫描、未重做历史 record 证明、未改他人文件。此首交后停止，等待主代理指定实际作者候选。

## R570 新 whole-object 候选独立审查及作者稿对照

先按 contract 的原 dV_G 独立推导，再读取 `/tmp/ccu_r570_order.tex`。所读 SHA-256：`fa18fe3e75bb48db7167af8288ec159a73cc79f729531fec211843b8facec9df`。定点结论 **PASS**：

 V_G≤L_clock W，
 L_clock=2GSγ²rband KΛDclk。

该范围为完整原 G（full R 或其固定正限制），不是仅 early；它是完整 cutoff 粗界，没有一般维数收益。以下给出决定性独核，不复审作者的额外分档候选。

### 外父中心容量与几何归一

固定原 B,g,N=M_B(g),y。先对每个 B,g,C,v,y 合并实际 first-stop 反链，保留 y∈Q_C(v) 和双向 tent N/γ<M_C(v)<γN，其余正门方可删除。固定 v 时，由 M_C(v)≥m_C=q_CR_C^n≥qR_C^n，有 R_C^n<γN/q。含 y 的实际中心 C 因而落入以 y 为中心、边长 (vγN/q)^(1/n) 的盒，Lebesgue 体积≤vγN/q。这里 R_C 是原可测父函数，不新增独立半径积分；以半边长作为中心距离给恰好这个体积，没有 2^n 因子。

另一方面，原外父率 t_Cq_C/(I_CM_C(v))≤Sλband γ/N。因此每个固定 v 的容量≤Sγ²rband v；原动作的两个端点完整保留，∫vω(dv)=1+(G−1)+G=2G。于是

 ∫dν_i(C,v)1_{y∈Q_C(v)}1_{N/γ<M_C(v)<γN}
 ≤Cout=2GSγ²rband。

限制为实际 Ei/bulk/source cell 只减小这个积分；放大至整个中心盒没有将 μ-source 改成体积。I_C≥1 只正放松一次。

### y、恢复动作和原旧场同链消去

将完整原 G 及其正门上界后，外父容量留下

 K Cout∫ν_i(dB,dg)/m_B ∫_{Q_B(g)}μ_i(dy)
       ∫_{Q_B(1)}μ_i(dz)∫_[s_B,s_B+1]1_{Li>τ}/Li(z,σ)dσ。

y 积分给 N，随后 N/m_B=κ_B(g)，恰有 ∫κ_Bρ_B=Λ/I_B。此处原 g 与 oldσ 分离是删除正门之后的上界，不是改变动作或来源相关性。定义

 L_i^(I)(z,σ)=∫bulk k_B(z,σ)/I_B dB。

即可得到更精确的中间上界

 V_G≤K CoutΛ Pclock，
 Pclock=Σ_i∫_{Li>τ} L_i^(I)(z,σ)/Li(z,σ) μ_i(dz)dσ。

原 I_B 留到该式，L_i^(I)≤Lbulk≤原完整Li。每个 i 的 numerator 旧σ支持包含在同一 bulk 旧窗总跨度内，长度≤Dclk；不是把各父单位窗的数量相加。Ci 互斥，故 Σ_i μ_i=μ、最终总来源质量恰 W，没有胞数因子。于是 Pclock≤Dclk W。此步不使用 1/τ、s⁻¹ 或 SA_n 的父 L1 入口；两个来源的 μ 积分和原 oldσ 均未漏。

本证明既不需要 early 条件，也不需要 proposal 的任意 κ 上界。因此作者将 whole-scope 单独列出正确；其 early 等式本身不能删除 late，但完整正放松已经同时覆盖两者。

### 与既有行帽比较及准确剩余限制

原 row factor r_B≤K 本来直接给

 V_G≤K²Σ_i∫Lbulk/Li μ_i(dz)dσ≤K²Dclk W。

此旧上界无需再乘 SA_n；不能只与较松的 K²SA_nDclkW 比而声称新的一致收益。因此两条合法 cutoff 上界可合并为

 V_G≤KΛDclk·min{Cout,K/Λ}W。

令 H=1+ln(Gγ^(1+h)rband)，K=GS HΛ，则新旧系数比恰为

 L_clock/(K²Dclk)=2γ²rband/H。

它随参数可大可小；只有 H>2γ²rband 时新界严格更小，并无统一严格改进。作者最后一节已准确允许取 min，未夸大为 target 收缩。

这条 direct whole-object 路线取 a=0、L=L_clock（或上述 min 系数），不调用 R569 startup/record，故不再加 B0W。它已支付当前有限 primitive 的全部 V_G，没有遗漏一个必须另外重收的 early/late 正支。尚未解决的是 Pclock 的 cutoff-clock 平台及原外层 R*≤2sqrt(DclkWQ) 对目标参数的影响；若转而保持 prefix 比率寻求更强界，完整 Vdiff 的 early+late 共同加权估计仍未证。不能把有限 cutoff 的全费用上界称为一致 L(n) 或一般维数改善。

指定本机 SymPy 实跑独立核 ∫vω=2G、外容量乘积 Sγ²λband v/q 及新旧比 2γ²rband/H。仅为常数代数核验，不以工具结果代替上述中心体积与正积分证明。未改作者稿、未作新反例或数值扫描。定点审查完成，停止。


---

# R570 final independent integration audit

**Scoped PASS; no blocking integration error found.** This audit checks the complete positive integral, its direct mother-account substitution, and coherence of the assembled report. It does not recertify all inherited algorithm history or replace the independently audited primitive certificate.

Audited file: `/tmp/ccu_r570_archive/REPORT.tex`, 500 lines, SHA256 `4426bc94bd22a29cfb615fb61eca7a62a5075619dd5577bdc8a65a876236cdb0`.

## 1. Complete original integral and the two valid bounds

I reconstructed the estimate from the specified original integral. The necessary scope is the actual Lebesgue parent measure, positive finite cutoffs, the true bidirectional mass window, all original old-source and phase/window gates, and the already verified merging of actual first-stop terms to a factor at most one. The old field is the full original `L_i`; it is not recomputed on the bulk.

Fix the inner parent/action `(B,g)` and `N=M_B(g)`. For each fixed outer action `v`, the true window gives

\[
 N/\gamma<M_C(v)<\gamma N,
 \qquad R_C^n\le M_C(v)/q<\gamma N/q.
\]

Together with `y∈Q_C(v)`, this places the actual outer centers in a box of volume at most `vγN/q`. Their density is at most `S λ_band γ/N`, using `I_C≥1`. Therefore the outer-parent integral is at most

\[
 S\gamma^2r_{\rm band}\int v\,\omega(dv)
 =2GS\gamma^2r_{\rm band}=:C_{\rm out}.
\]

Both endpoint atoms matter: `1+(G−1)+G=2G`. This estimate would fail from a single one-sided head condition alone. It does not integrate an additional free radius or replace source mass by spatial volume.

After this bound, the actual `y` integral gives `N`. The surviving inner factor is exactly

\[
 \int a_B\rho_B(dg)\frac{N}{m_B}
 =\frac{a_B\Lambda}{I_B}.
\]

The old `z∈Q_B(1)` and unit `σ` window are retained. Hence

\[
 V_{\mathsf G}\le K C_{\rm out}\Lambda
 \sum_i\int\frac{1_{L_i>\tau}L_i^{(I)}}{L_i}\,d\mu_i\,d\sigma
 \le 2GS\gamma^2r_{\rm band}K\Lambda D W.
\]

The final time support is the inner bulk window union, of length at most `D`; no `1/τ` or extra `SA_n` is needed. Where the numerator is zero the ratio is zero. On the retained set the denominator is strictly positive. This is a bound for the entire original remaining branch and also, by positivity, for an original far restriction.

Independently, the inherited complete row cap gives

\[
 V_{\mathsf G}\le K^2\sum_i\int
 1_{L_i>\tau}\frac{L_i^{\rm b}}{L_i}\,d\mu_i\,d\sigma
 \le K^2DW.
\]

The bulk is a subprobability restriction of the full original field; no bulk renormalization is made. Thus the assembled minimum is valid:

\[
 V_{\mathsf G}\le L_{\rm best}W,
 \qquad L_{\rm best}=D\min\{K^2,2GS\gamma^2r_{\rm band}K\Lambda\}.
\]

The report compares the new cap against this sharper inherited bound, rather than presenting removal of the looser `SA_n` as a new geometric gain. PASS.

## 2. Direct full mother and physical normalization

For `A=A_0`, `C=C_mother`, and `q_g=Q_g/W`, substituting a complete source bound with `a=0` gives precisely

\[
 q_g\le C+2A\sqrt{L_{\rm best}q_g}.
\]

Writing `x=√q_g` gives the positive root

\[
 F_0=[A\sqrt{L_{\rm best}}+\sqrt{C+A^2L_{\rm best}}]^2,
 \qquad q_g\le F_0.
\]

The physical quantity remains `Q/W≤b_0^{-2}F_0`. Combining with the inherited `R_*≤2√(DWQ)` gives `R_*/W≤2b_0^{-1}√(DF_0)`. The factor `b_0^{-1}` cannot be dropped by silently replacing physical `Q` with `Q_g`.

There is **no additional record/startup `B_0` in this direct whole-branch route** and no separate unfilled `V_diff`: that would duplicate a decomposition not used here. Conversely, reverting to the R569 record route does require `B_0+L_diff` and its complete weighted terminal. The report keeps those routes separate. A far-only application must still respect the once-paid near credit; the report does not collect that credit twice.

I checked the mother and the retained external slots against the precise M1–M2 passage in the R569 archive. `K_w`, `B_rem`, `K+F_cap`, entry/deletion/future-deletion/time/history and all-scale charges remain inherited in the stated mother; the new capacity estimate is not represented as paying those slots independently. No hidden removal of an outer fee was found.

The ratio `L_clock/(K²D)=2γ²r_band/H_cap`, its equality boundary, and the expanded coefficient `L_best=PD` are correct. The full/far invoice comparison follows from

\[
 C+4A^2L\le[A\sqrt L+\sqrt{C+A^2L}]^2\le2C+4A^2L.
\]

The displayed target condition retains `DC+A²PD²`, `b_0^{-1}`, and external entrance scope. It is a requirement for this upper-bound expression to reach the target, not an operator lower bound. The report states this distinction correctly.

## 3. Third-source credit lift and zero branch

The lift keeps the original `(B,C,y,z,σ)` and uses the proposal's genuine old source/window. Its density identity is correct:

\[
 d\nu(P,h)dS_P
 =\frac{\rho_P(dh)}{C_0m_P\alpha_P}\,dQ_{\rm fr}.
\]

It introduces no additional inverse old field. It is nevertheless only a representation; the report does not claim that its credit row has been paid. The early and late complementary pieces both remain in the full target.

For completeness, the probability `S_P` is used on `e_P>0`. Any zero-score parent branch is null for the required positive parent contribution: if a measurable positive parent subset had `e_P=0`, its generated subfield `L_A≤L_i` would satisfy `∫L_i L_A=0`, hence `L_A=0` almost everywhere and `∫_A t_Pq_P=0`. Thus restricting to the score-positive support, or declaring the zero branch irrelevant, gives the same identity. This is a harmless null-set convention, not a blocking error.

## 4. Actual dimension-one primitive and certificate scope

The primitive is internally consistent as an actual continuous-source, actual-center, one-dimensional diagnostic. It is explicitly not a construction of the original complete head/first-stop/bulk history.

For `k≥5`, the uniform source gives `κ(h)=h`, `I=2`, and the endpoint mass `ρ({1})=1/2`. The actual small/large rates are respectively `1/4` and `1/8`. The strict exclusion condition is `9ε/8<1/16`, equivalently `ε<1/18`; the revised `ε≤1/32` satisfies it. The selected old field is `L=1/8`, and `u=4` therefore gives `J/U=1/3` for these ranges.

The physical cutoffs are compatible: `a=2^{-max(k,8)}`, `b=2`, `G=2`, so both real side lengths are in `[a,b/G]`, `D=max(k,8)+2`, and the actual `τ≤1/10<1/8`. The actual inherited startup threshold obeys `s_*≤D^{-2}≤1/100`; it has not been replaced by an arbitrary experimental threshold.

Spot-checking the retained selected measures gives `V_selected/K=ε/4096`, the different-winner factor `2/3` gives `ε/6144`, and the genuine small-parent credit is `11ε/192`. Their ratio is `K/352`. Here `K` is fixed with respect to this ε family; the small mass ratio tends to zero. This diagnoses the proposed extra small-mass multiplier for the proposal's own credit row under the listed primitive information. It does not refute global cross-parent credit, the full history, or the general weak-type target.

The initial `k=4` failure is correctly disclosed and excluded from the fixed-ratio claim. The correction in equation (8) is algebraically compatible with the unchanged base fee and credit. Its strict inequality follows from `ln(8/7)<1/7`. I did not rerun the independently audited k-list computation or primitive certificate. The report properly distinguishes rational/SymPy/Arb/MATLAB evidence and does not use finite examples to certify general L1 history.

## 5. Limits, assembled coherence, and tool evidence

The report consistently retains finite physical cutoffs. Its dependence on `D`, `A_n`, and input scale ratios is not passed to a general-input uniform estimate. Zero `W`, zero `S`, and empty bulk are isolated. The two estimates apply to the same positive integral, so taking their minimum is legitimate; neither an absorbed quadratic credit nor a stopping terminal is silently added or deleted.

No new root-order conclusion, free third-source budget, or complete recursive contraction is asserted. The additional exploratory sections preserve their unpaid excess/late branches and are not counted in the complete source estimate.

Actual local check used `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`, Python 3.12.14 / SymPy 1.14.0. Symbolic residuals were zero for the full mother root, the cap ratio, the physical `L8` substitution, and the two primitive coefficient ratios. This was a bounded theory spot-check, not a rerun of the numeric primitive scan. No PDF was compiled, no repository or other author's file was changed, and no child agent was started.

**Final status: PASS within the stated frozen original-integral/first-stop premises and finite-cutoff scope. The general dimension target and input-uniform recovery remain open.**

## Final delta audit: zero-score parent convention

PASS for the sole added zero-score paragraph (REPORT lines 166–170). For Z0={P:e_P=0}, Tonelli gives ∫L_iF=∫Z0 e_P dP=0 with F=∫Z0 k_P dP≤L_i; hence ∫F²=0 and F=0 almost everywhere. Integrating F yields ∫Z0 t_Pq_P dP=0. Since the frozen bulk weight t_Pq_P is strictly positive, Z0 is null for original parent Lebesgue measure, and therefore also null for its absolutely continuous proposal measure. The probability kernel may be assigned a fixed arbitrary measurable value there without changing any integral. The displayed F=0 is read almost everywhere. No other report section was reaudited or changed by this delta check.

Final REPORT SHA256: `6d60146a8a65af6956a6ad631e132ac6d35d416cd64b4467a973429d112b990f`. This supersedes the earlier report hash for the added null-branch convention only; the original scoped PASS is preserved.
