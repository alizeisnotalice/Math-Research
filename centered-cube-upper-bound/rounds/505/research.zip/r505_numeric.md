# R505：有限非乘积鞅与全局gate的精确证书

完成183项证书断言：9个非乘积概率二叉鞅、18组独立标量输入、6个JS混合表。全树共1638条边的局部条件也由聚合断言逐项核验；它们不是1638个独立模型。所有树的条件均值、完整φ增量、能量与L1费用使用Fraction；对数用精确有理常数加prime-log系数保存，严格正性用Arb384。没有抽样、浮点求解器或误差截断。

结论限于有限鞅和混合代数：完整gate与鞅平方预算相容，且把总gate移到各component会破坏JS账。没有认证连续来源、cube对角转移、原history或一般几何付款。

## 环境与复现

```text
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r505_numeric.py
```

Python3.12.14、SymPy1.14.0、python-flint0.9.0，Arb384bits。脚本写自身目录的`r505_numeric.json`。除`compute_index.seconds`外没有动态字段。

实际stdout首行为：

```text
PASS 183 certificate assertions;9 nonproduct martingales,18 scalar pairs,6 globally gated JS tables;finite-only
```

183的构成：2个SymPy primitive恒等式；18标量输入各3项；9个鞅各12项；6个JS表各3项；1个错误gate残差非零守卫。精确零通过有理及prime-log系数逐项为零识别，不以跨零Arb区间冒充等式。

## 标量函数与独立积分

q=1、λ=2，φ完整定义为：s≤1/2时0；1/2<s<1时2s−1；1≤s≤2时s；s>2时2。采用

`F(s)=∫_[1/2,2](s−t)_+ dt/t`，

其分段为0、`slog(2s)−s+1/2`、`slog4−3/2`。D方向为新值u、旧条件均值v：`D_F(u,v)=F(u)−F(v)−F'(v)(u−v)`，已与作者确认。

每对输入同时核

`(φ(u)−φ(v))²/(u+v)≤8D_F(u,v)`，`F(u)≤log4·u`。

u=v=0的商定义0。18对覆盖零、1/2、1、2、饱和区、u=v与两个方向的不等值。独立Hessian积分是：u≥v时积分`(u−t)/t`，u<v时积分`(t−u)/t`，均截至t∈[1/2,2]；空区间为0。与Bregman差的精确系数逐项相等。此法亦用于全部树边，防止近零消去或线性区被误判为正耗散。

## 三阶段非乘积概率鞅

初探n=2，集中/零耗散压力n=4，扩大n=8；各有single spike、parity、two unequal spikes，共9棵树。每个终端位串i有正权

`w_i=1+(7i+3 mod11)+3·1_(firstbit=lastbit)+5·1_(popcount=n/2)`，

先归一成概率。实际核首尾两位2×2联合表不满足乘积条件；完整概率并非独立坐标。终端raw数组分别为单个位置0上的1、奇parity上的1、位置0/末位置上的3/1，其他0；再除其概率均值，故终端g≥0、E g=1=W。

对每个prefix直接从完整终端权求条件均值；不是把来源坐标当独立，也不按gate更改条件平均。记

`E_sq=Σ E[(Δφ)²/(g_child+g_parent)]`，

`L1=Σ E|Δφ|`。

逐模型精确核：

- 条件均值守恒；全部局部scalar界和独立D积分。
- `Σ E D_F(g_child,g_parent)=E F(g_terminal)−F(1)`，精确gap0。
- `E_sq≤8Σ E D≤8log4`；terminal F期望≤log4。
- `Σ E(g_child+g_parent)=2n`，`L1²≤2n E_sq≤16nlog4`。

|n|pattern|E_sq（精确分数见JSON）|L1（精确分数见JSON）|
|---|---|---:|---:|
|2|single spike|1.25920831|1.61081654|
|2|parity|0.37312881|0.66838358|
|2|two unequal spikes|1.03537445|1.52024665|
|4|single spike|1.33478316|1.90796243|
|4|parity|0.68904881|1.48116027|
|4|two unequal spikes|1.10763129|1.90701501|
|8|single spike|1.33789466|1.99296394|
|8|parity|0.72491902|1.79926853|
|8|two unequal spikes|1.25306608|2.32037521|

最大E_sq约1.338，理论通用上限8log4约11.090；n8的L1上限约13.321。有限模型没有显示常数锐性，也不据这些宽松余量修改一般常数。

## 六个JS表及同一个总gate

采用非归一JS质量函数

`j(b,g)=b log[2b/(b+g)]+g log[2g/(b+g)]`。

b=g=0时j=0；零乘对数项为0。令b=Σb_i、g=Σg_i，r_i=b_i/b、p_i=g_i/g、s_i=(b_i+g_i)/(b+g)。b=0或g=0时对应的质量乘KL定义0，不创建未定义的概率向量。

精确核

`Σ_i j(b_i,g_i)−j(b,g)=b KL(r||s)+g KL(p||s)`。

再把**同一个**χ=φ'(g)乘在等式全部项上。χ在1/2<g<1时2、1≤g≤2时1，其余0；有限表端点采用已列明约定。这只是混合代数中的共同标量，不声称在原连续导数的原子端点唯一。

|表|b_i|g_i|总χ|未乘χ的KL付款约值|
|---|---|---|---:|---:|
|positive|(1/4,3/4)|(3/4,1/4)|1|0.26162407|
|disjoint zeros|(1,0)|(0,1)|1|1.38629436|
|partial，含空atom|(1,0,1/2,0)|(0,1/4,1/2,0)|2|0.73900970|
|zero b|(0,0)|(1/4,1/2)|2|0|
|global gate off|(1/2,1/2)|(1,2)|0|0.04356327|
|zero g|(1/3,2/3)|(0,0)|0|0|

6表原始及全局gate后gap均精确0，KL付款用Arb核非负或精确零。JSON另记录错误替换`Σφ'(g_i)j_i−φ'(g)j_total−φ'(g)KL_payment`：例如global gate off表残差约+0.56681141，disjoint zeros表约−0.69314718。故不能把总gate分配给各分量后仍沿用同一JS付款式；正负残差都实际存在。

## 适用范围与决策

本轮核验支持采用真实有限鞅的加权平方账：概率相关性本身不妨碍条件均值望远镜，完整φ和零项纪律均可精确保留。剩余关键是把这些辅助鞅变化与原连续cube/来源对角量合法连接；本报告没有实现该连接，也不把9个有限表解释成原几何或history证明。

白名单仅`/tmp/r505_numeric.py`、`/tmp/r505_numeric.json`、`/tmp/r505_numeric.md`。完成后停止。
