# R505：全来源密度带下的后验 score 与有限混合信用

目标仍是 R504 的同一量
\[
\mathcal V=n\int_a^b\!\int\chi(B,R)(b_R-g_R)_+\,dB\,\frac{dR}{R},
\qquad \chi=\varphi'(g_R),\quad0\le\chi\le2,
\]
其中 \(g_R=f*h_R\)、\(b_R=RU'/(nR^n)\)，\(\int g_R=\int b_R=W\)。\(\varphi\) 是 R504 原密度带函数，不改变完整 \(f\)、实际父质量或选择器。

本附件给出一条始终有限、无标签数费用的混合信用公式及其对完整 \(\mathcal V\) 的准确比较。尚未证明信用足够大，因而没有一般根阶付款。使用 D04 技能仅核条件参考和有限性；下列式子均作自含推导，不援引未核的外部几何定理。

## 1. 实际后验的 score 恒等式及其范围

令 \(f=\sum_{i=1}^m f_i\)，\(f_i\ge0\)，删去零质量成分，\(\alpha_i=\int f_i/W>0\)。记 \(g_i=f_i*h_R\)、\(b_i\) 为对应归一面平均，\(g=\sum g_i\)、\(b=\sum b_i\)，以及
\[
p_i=g_i/g,\qquad r_i=b_i/b,\qquad
D_p=\mathrm{KL}(p\|\alpha),\quad D_r=\mathrm{KL}(r\|\alpha).
\]
为严证导数，可先以 \(f_i^{\epsilon}=(1-\epsilon)f_i+\epsilon\alpha_i f\) 正则标签。总 \(f,g,b\) 及原 \(\chi\) 完全不变，且 \(p_i^\epsilon,r_i^\epsilon\ge\epsilon\alpha_i\)。在本节省略上标：所有导数式先指 \(\epsilon>0\)，或未正则时另满足所需对数可积性。

写 \(\dot{}=(R/n)\partial_R\)。由 \(\dot g_i=b_i-g_i\)，有限求和、展开对数直接给
\[
\dot{(gD_p)}
=bD_r-gD_p-b\,\mathrm{KL}(r\|p).
\tag{1}
\]
R504 的 L1 径向绝对连续性和有界正则对数允许积分与导数交换。令 \(I_g=\int gD_p\)、\(I_b=\int bD_r\)，则
\[
\frac Rn I_g'=I_b-I_g-\int b\,\mathrm{KL}(r\|p).
\tag{2}
\]
在同一个原带权下也有精确式
\[
\frac Rn\frac d{dR}\int\varphi(g)D_p
=\int\varphi'(g)(b-g)D_p
+\int\frac{\varphi(g)b}{g}
 [D_r-D_p-\mathrm{KL}(r\|p)].
\tag{3}
\]
\(\varphi(g)/g\le1\)，所以正则版本各项有限。式 (3) 没有把原 \(\varphi'(g)\) 移给某个成分。它控制的是 KL 加权的有符号 score，不能直接上界目标中的无 KL 权正 score。

即使暂时丢带权，式 (2) 直接可得的预算也只是
\[
\int_a^b\frac nR\int b\,\mathrm{KL}(r\|p)\,dB\,dR
\le[1+n\log(b/a)]\,W H(\alpha),
\tag{4}
\]
因为 \(0\le I_g,I_b\le WH(\alpha)\)。不得假设标签熵有统一上界；二标签虽避免此问题，式 (4) 仍是维数级价。没有对未正则版本作 \(\infty-\infty\) 消去。

## 2. 无标签熵费用的有限交叉信用

定义非负、连续延拓至零的标量量
\[
j(b,g)=b\log\frac{2b}{b+g}+g\log\frac{2g}{b+g},
\qquad 0\le j(b,g)\le(b+g)\log2.
\]
本节直接用未正则原成分。令 \(s_i=(b_i+g_i)/(b+g)\)。逐点展开对数得
\[
\boxed{\sum_i j(b_i,g_i)-j(b,g)
=b\,\mathrm{KL}(r\|s)+g\,\mathrm{KL}(p\|s).}
\tag{5}
\]
这是同一中心、半径的两个真实后验之间的信用。\(b=0\) 或 \(g=0\) 时零权条件核可任意定义；总式连续成立。右侧有限且至多 \((b+g)\log2\)，没有标签数或 \(H(\alpha)\) 费用。

将式 (5) 乘**同一个** \(\chi=\varphi'(g)\)，并按 \(dB\,dR/R\) 积分。记
\[
\mathcal C_{\rm comp}=\int\chi\sum_i j(b_i,g_i),\qquad
\mathcal C_{\rm post}=\int\chi[b\mathrm{KL}(r\|s)+g\mathrm{KL}(p\|s)].
\]
则
\[
\mathcal J_\chi:=\int\chi j(b,g)
=\mathcal C_{\rm comp}-\mathcal C_{\rm post}\ge0,
\qquad
0\le\mathcal C_{\rm post}\le\mathcal C_{\rm comp}
\le4(\log2)W\log(b/a).
\tag{6}
\]
这是有限实数相减，不是形式熵差；保了完整来源密度带和所有混合抵消。

## 3. 对完整正通量的比较及唯一未付步骤

令 \(z=(b-g)/(b+g)\)。函数
\((1+z)\log(1+z)+(1-z)\log(1-z)-z^2\)
在零处值和导数为零，二阶导为 \(2z^2/(1-z^2)\ge0\)。故
\[
j(b,g)\ge\frac{(b-g)^2}{2(b+g)}.
\]
同一正测度上的 Cauchy 以及 \(\int\chi(b+g)\le4W\log(b/a)\) 给完整目标的有效比较
\[
\boxed{\mathcal V\le
n\sqrt{8W\log(b/a)\,
(\mathcal C_{\rm comp}-\mathcal C_{\rm post})}.}
\tag{7}
\]
\(a=b\) 时两边为零。该式不丢原全密度门，不替换父后验，也不按每个成分另选阈值。若另外能证明
\[
\mathcal C_{\rm comp}-\mathcal C_{\rm post}
\le \frac{C_r}{n}\log^A(n+2)W,
\tag{8}
\]
便得到 \(\mathcal V\le C'_r\sqrt n\log^{A/2}(n+2)W\)，可经 R504 同流接口回代。式 (8) 是一个充分的几何条件，**本附件未证明**；没有假定它与原目标等价。

唯一缺口是实际全密度带下，边界与内部后验信用能否抵消成分代价至式 (8) 的量级。式 (1)–(4) 只给标签变化，不能控制共同模式的正 score；例如比例拆分 \(f_i=\alpha_i f\) 时 \(p=r=s=\alpha\)，所有后验信用均为零，而原 \(\mathcal V\) 完全不变。这是拆分不改变原目标的代数检查，不是几何目标的反例。选空间标签或加细标签本身也不改变 \(\mathcal J_\chi\)；需要真实立方体几何证明信用足够，而不能把定义或熵链式当作这一步。

当前仅有式 (6) 的通用大小界，代入式 (7) 仍为 \(O(nW)\)。因此本轮不计新增根阶付款，不将有限混合公式或产品来源计算外推到任意来源；按有界任务停止。

## 4. 实际运行的局部符号核验

指定本机 Python 环境实际运行下列代码，输出 `3 symbolic checks PASS: score, finite JS chain, scalar curvature.` 只检查代数接口，不证明式 (8) 或任何原历史实例。

```python
import sympy as s
g1,g2,b1,b2,a1,a2=s.symbols('g1 g2 b1 b2 a1 a2', positive=True)
g,b=g1+g2,b1+b2
p=[g1/g,g2/g]; r=[b1/b,b2/b]; aa=[a1,a2]
D=lambda x,y:sum(v*s.log(v/w) for v,w in zip(x,y))
Ip=g*D(p,aa)
dot=s.diff(Ip,g1)*(b1-g1)+s.diff(Ip,g2)*(b2-g2)
rhs=b*D(r,aa)-g*D(p,aa)-b*D(r,p)
assert s.simplify(s.expand_log(dot-rhs,force=True))==0
j=lambda x,y:x*s.log(2*x/(x+y))+y*s.log(2*y/(x+y))
mid=[(b1+g1)/(b+g),(b2+g2)/(b+g)]
res=j(b1,g1)+j(b2,g2)-j(b,g)-b*D(r,mid)-g*D(p,mid)
assert s.simplify(s.expand_log(res,force=True))==0
z=s.symbols('z',real=True)
f=(1+z)*s.log(1+z)+(1-z)*s.log(1-z)-z*z
assert s.simplify(s.diff(f,z,2)-2*z*z/(1-z*z))==0
print('3 symbolic checks PASS: score, finite JS chain, scalar curvature.')
```
