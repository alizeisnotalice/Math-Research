#!/usr/bin/env python3
"""Exact rational/log finite martingale and globally gated JS checks."""
from pathlib import Path
from fractions import Fraction as Q
from dataclasses import dataclass,field
import sys,platform,json,time
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=384
ROOT=Path(__file__).resolve().parent
checks=0

def ck(flag):
 global checks
 assert bool(flag)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

@dataclass
class E:
 const: Q=Q(0)
 logs: dict=field(default_factory=dict)
 def __add__(self,other):
  if not isinstance(other,E):other=E(Q(other))
  out=E(self.const+other.const,self.logs.copy())
  for p,c in other.logs.items():
   out.logs[p]=out.logs.get(p,Q(0))+c
   if out.logs[p]==0:del out.logs[p]
  return out
 __radd__=__add__
 def __neg__(self):return self.scale(-1)
 def __sub__(self,other):return self+(-other if isinstance(other,E) else -Q(other))
 def scale(self,c):
  c=Q(c)
  return E(self.const*c,{p:a*c for p,a in self.logs.items() if a*c})
 def ball(self):
  out=aa(self.const)
  for p,c in sorted(self.logs.items()):out+=aa(c)*arb(p).log()
  return out
 def zero(self):return self.const==0 and not self.logs
 def json(self):return {'rational':str(self.const),'prime_log_coefficients':{str(p):str(c) for p,c in sorted(self.logs.items())},'arb':str(self.ball())}

def logq(q):
 q=Q(q);assert q>0
 out={}
 for v,sign in [(q.numerator,1),(q.denominator,-1)]:
  for p,k in sp.factorint(v).items():out[int(p)]=out.get(int(p),Q(0))+sign*int(k)
 return E(Q(0),{p:c for p,c in out.items() if c})

def nonneg(x):
 if x.zero():return True
 b=x.ball();return b.is_finite() and b>=0

def phi(x):
 x=Q(x)
 if x<=Q(1,2):return Q(0)
 if x<1:return 2*x-1
 return min(x,Q(2))

def gate(x):
 x=Q(x)
 return Q(2) if Q(1,2)<x<1 else (Q(1) if 1<=x<=2 else Q(0))

def F(x):
 x=Q(x)
 if x<=Q(1,2):return E()
 if x<2:return logq(2*x).scale(x)+Q(1,2)-x
 return logq(4).scale(x)-Q(3,2)

def Fp(x):
 return logq(2*min(Q(2),max(Q(1,2),Q(x))))

def DF(u,v):return F(u)-F(v)-Fp(v).scale(u-v)

def DF_integral(u,v):
 # Independent Hessian integral, F''(t)=1/t on(.5,2), zero otherwise.
 lo=max(min(u,v),Q(1,2));hi=min(max(u,v),Q(2))
 if lo>=hi:return E()
 if u>=v:return logq(hi/lo).scale(u)-(hi-lo)
 return E(hi-lo)-logq(hi/lo).scale(u)

def scalar_checks():
 s,t=sp.symbols('s t',positive=True)
 ck(sp.simplify(sp.integrate((s-t)/t,(t,sp.Rational(1,2),s))-(s*sp.log(2*s)-s+sp.Rational(1,2)))==0)
 ck(sp.simplify(sp.integrate((s-t)/t,(t,sp.Rational(1,2),2))-(s*sp.log(4)-sp.Rational(3,2)))==0)
 pairs=[(Q(0),Q(0)),(Q(0),Q(1,2)),(Q(1,2),Q(0)),(Q(0),Q(1)),(Q(1),Q(0)),(Q(1,2),Q(1)),(Q(1),Q(1,2)),(Q(3,4),Q(7,8)),(Q(7,8),Q(3,4)),(Q(1),Q(2)),(Q(2),Q(1)),(Q(2),Q(4)),(Q(4),Q(2)),(Q(4),Q(0)),(Q(1,4),Q(8)),(Q(8),Q(1,4)),(Q(2),Q(2)),(Q(3,4),Q(3,4))]
 out=[]
 for u,v in pairs:
  cost=(phi(u)-phi(v))**2/(u+v) if u+v else Q(0)
  margin=DF(u,v).scale(8)-cost
  ck((DF(u,v)-DF_integral(u,v)).zero())
  ck(nonneg(margin))
  ck(nonneg(logq(4).scale(u)-F(u)))
  out.append({'u':str(u),'v':str(v),'weighted_square':str(cost),'bregman':DF(u,v).json(),'margin_8D_minus_cost':margin.json()})
 return out

def martingale(n,pattern):
 size=2**n
 bits=[tuple((i>>(n-1-j))&1 for j in range(n)) for i in range(size)]
 weights=[1+(7*i+3)%11+3*(b[0]==b[-1])+5*(sum(b)==n//2) for i,b in enumerate(bits)]
 probs=[Q(w,sum(weights)) for w in weights]
 raw=[(1 if i==0 else 0) if pattern=='single_spike' else ((sum(bits[i])%2) if pattern=='parity' else (3 if i==0 else (1 if i==size-1 else 0))) for i in range(size)]
 normalizer=sum((p*x for p,x in zip(probs,raw)),Q(0))
 terminal=[Q(x)/normalizer for x in raw]
 table={}
 for depth in range(n+1):
  for prefix in range(2**depth):
   indices=range(prefix*2**(n-depth),(prefix+1)*2**(n-depth))
   mass=sum((probs[i] for i in indices),Q(0))
   mean=sum((probs[i]*terminal[i] for i in indices),Q(0))/mass
   table[(depth,prefix)]=(mass,mean)
 ck(table[(0,0)][1]==1)
 joint=[[sum((p for p,b in zip(probs,bits) if b[0]==x and b[-1]==y),Q(0)) for y in [0,1]] for x in [0,1]]
 ck(joint[0][0]*joint[1][1]!=joint[0][1]*joint[1][0])
 energy=Q(0);l1=Q(0);denom=Q(0);sumD=E();perstage=[];scalar_flags=[];integral_flags=[];mart_flags=[];equal=0
 for depth in range(n):
  ed=Q(0);ld=Q(0);dd=E()
  for prefix in range(2**depth):
   mass,parent=table[(depth,prefix)]
   children=[table[(depth+1,2*prefix+c)] for c in [0,1]]
   mart_flags.append(sum((p*x for p,x in children),Q(0))==mass*parent)
   for p,child in children:
    diff=phi(child)-phi(parent)
    val=diff**2/(child+parent) if child+parent else Q(0)
    D=DF(child,parent)
    integral_flags.append((D-DF_integral(child,parent)).zero())
    scalar_flags.append(nonneg(D.scale(8)-val))
    if D.zero():equal+=1
    ed+=p*val;ld+=p*abs(diff);dd=dd+D.scale(p);denom+=p*(child+parent)
  energy+=ed;l1+=ld;sumD=sumD+dd
  perstage.append({'stage':depth+1,'energy':str(ed),'L1':str(ld),'bregman_expectation':dd.json()})
 terminalF=sum((F(x).scale(p) for x,p in zip(terminal,probs)),E())
 ck(all(mart_flags));ck(all(scalar_flags));ck(all(integral_flags))
 ck((sumD-(terminalF-F(1))).zero())
 ck(nonneg(sumD.scale(8)-energy))
 ck(nonneg(logq(4).scale(8)-energy))
 ck(denom==2*n)
 ck(l1*l1<=energy*2*n)
 ck(nonneg(logq(4).scale(16*n)-l1*l1))
 ck(nonneg(logq(4)-terminalF))
 return {'n':n,'pattern':pattern,'terminal_state_count':size,'probability_weights':weights,'terminal_values':[str(x) for x in terminal],'W':'1','root_g':'1','nonproduct_first_last_joint':[[str(x) for x in row] for row in joint],'weighted_square_total':str(energy),'path_L1_total':str(l1),'denominator_total':str(denom),'bregman_total':sumD.json(),'terminal_F':terminalF.json(),'energy_upper_arb':str(8*arb(4).log()),'L1_upper_arb':str(4*(n*arb(4).log()).sqrt()),'edge_count':2**(n+1)-2,'exact_zero_Bregman_edges':equal,'stages':perstage}

def j(b,g):
 b,g=Q(b),Q(g)
 if b+g==0:return E()
 return (logq(2*b/(b+g)).scale(b) if b else E())+(logq(2*g/(b+g)).scale(g) if g else E())

def KL(p,s):
 out=E()
 for a,b in zip(p,s):
  if a:
   assert b>0
   out=out+logq(a/b).scale(a)
 return out

def js_tables():
 fixtures=[('positive',[Q(1,4),Q(3,4)],[Q(3,4),Q(1,4)]),('disjoint_zeros',[Q(1),Q(0)],[Q(0),Q(1)]),('partial_gate_with_empty_atom',[Q(1),Q(0),Q(1,2),Q(0)],[Q(0),Q(1,4),Q(1,2),Q(0)]),('zero_b',[Q(0),Q(0)],[Q(1,4),Q(1,2)]),('global_gate_off',[Q(1,2),Q(1,2)],[Q(1),Q(2)]),('zero_g',[Q(1,3),Q(2,3)],[Q(0),Q(0)])]
 rows=[]
 for name,bi,gi in fixtures:
  b,g=sum(bi),sum(gi);s=[(x+y)/(b+g) for x,y in zip(bi,gi)]
  rhs=(KL([x/b for x in bi],s).scale(b) if b else E())+(KL([y/g for y in gi],s).scale(g) if g else E())
  lhs=sum((j(x,y) for x,y in zip(bi,gi)),E())-j(b,g)
  globalgate=gate(g)
  ck((lhs-rhs).zero());ck(nonneg(rhs));ck((lhs.scale(globalgate)-rhs.scale(globalgate)).zero())
  wrong=sum((j(x,y).scale(gate(y)) for x,y in zip(bi,gi)),E())-j(b,g).scale(globalgate)-rhs.scale(globalgate)
  rows.append({'name':name,'b_i':[str(x) for x in bi],'g_i':[str(x) for x in gi],'total_b':str(b),'total_g':str(g),'global_phi_prime_gate':str(globalgate),'JS_chain_gap':(lhs-rhs).json(),'nonnegative_KL_payment':rhs.json(),'gated_identity_gap':(lhs-rhs).scale(globalgate).json(),'wrong_component_gate_residual':wrong.json(),'scope':'finite mixture algebra, same total gate applied to every term'})
 ck(any(not Q(row['global_phi_prime_gate']) and not E(Q(row['wrong_component_gate_residual']['rational']),{int(p):Q(c) for p,c in row['wrong_component_gate_residual']['prime_log_coefficients'].items()}).zero() for row in rows))
 return rows

def main():
 start=time.perf_counter();scalars=scalar_checks()
 models=[martingale(n,pattern) for n in [2,4,8] for pattern in ['single_spike','parity','two_unequal_spikes']]
 mixtures=js_tables()
 out={'scope':'exact finite binary martingale with arbitrary correlated positive terminal probabilities; finite globally gated JS identity; no continuous cube/source diagonal transfer or original history','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r505_numeric.py','checks':checks,'count_meaning':'aggregate model and scalar/table certificate assertions; all tree edge scalar margins checked internally, not counted as independent experiments','scalar_pairs':scalars,'martingale_models':models,'JS_tables':mixtures,'compute_index':{'seconds':time.perf_counter()-start}}
 (ROOT/'r505_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print(f'PASS {checks} certificate assertions;9 nonproduct martingales,18 scalar pairs,6 globally gated JS tables;finite-only')
 for m in models:print(m['n'],m['pattern'],'energy',float(Q(m['weighted_square_total'])),'L1',float(Q(m['path_L1_total'])))
if __name__=='__main__':main()
