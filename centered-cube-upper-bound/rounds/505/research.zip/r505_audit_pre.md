# R505 独立预审：标签熵、尺度 score 与二倍立方体

本稿先于任何 R505 作者证明。目标仍为 R504 的完整来源通量 \(\mathcal V=\int\varphi'(g_R)(R\partial_Rg_R)_+\,dB\,dR/R\) 根阶价，不以固定尺度的熵恒等式代替该目标。

## 1. 可用的真实 KL 参考及导数

设 \(f=\sum_i f_i\)，非负有限或可数分解全场固定，不随中心、半径或历史重选；\(M_i=\int f_i\)、\(W=\sum M_i\in(0,\infty)\)，零质量标签删去。对同一个固定 R，\(g_i=f_i*k_R\)、\(g=\sum g_i\)、\(p_i=g_i/g\)、\(\alpha_i=M_i/W\)。g=0 的项置零。联合概率是 \(g_i(B)dB/W\)，其真实标签边缘恰为 α，故
\[
\mathcal I(R)=\int g\,D(p\|\alpha)\,dB\ge0.
\]
这是有定义的扩展值 KL；输入—输出链式／log-sum 给 \(\mathcal I(R)\le W H(\alpha)\)。若 \(H(\alpha)<\infty\)，则
\[
WH(\alpha)=\mathcal I(R)+\int g H(p)\,dB.
\tag{1}
\]
无有限熵条件不可作 ∞−∞。标签分割任意细时，H(α)没有独立于标签数的帽；仅有 L1 假设也不使这个静态信息量具有统一常数帽。不能改用未检查可积性的 \(\int g\log g\)：任意 L1 在无界中心域的微分熵仍可能含无限项。

记点表示 \(R\partial_R\)，\(z_i=\dot g_i/g_i\)、\(z=\dot g/g=\sum p_i z_i\)。在相应对数通量绝对可积、可交换求和/积分/导数时，准确有
\[
\dot{\mathcal I}=\int\sum_i\dot g_i\log\frac{p_i}{\alpha_i},
\qquad
\frac d{d\log R}\int gH(p)=-\int\sum_i\dot g_i\log p_i.
\tag{2}
\]
质量导数项抵消，来自 \(\int\dot g_i=0\)，不是把每点 score 当作零。L1 径向 AC 本身不足以自动保证含 log 的链式积分 AC；应先截断日志/标签/中心域并控制 \(\sum|\dot g_i\log(p_i/\alpha_i)|\) 的可积性或一致可积性，才得到 (2)。固定有限标签使静态 KL 有限，也不自动给所需总变差帽。

真实平方 score 分解为
\[
\sum_i g_i z_i^2-gz^2=g\sum_i p_i(z_i-z)^2\ge0.
\tag{3}
\]
必须先确保平方项可积，或保非负扩展值而不作 ∞−∞。R504 已核均匀小盒的单边缘逆交长二阶矩无穷，因此不能从 L1 或固定尺度全质量守恒直接取得统一平方 score 价。标签后验 Fisher 项也不自动控制全平均 score z 的零阶部分。

若熵乘的是全密度带输出 \(\varphi(g)\)，额外乘积项不可丢。对 \(D=D(p\|\alpha)\)，点态准确式为
\[
\partial_{\log R}[\varphi(g)D]
=\frac{\varphi(g)}g\sum_i\dot g_i\log\frac{p_i}{\alpha_i}
+\left[\varphi'(g)-\frac{\varphi(g)}g\right]\dot g\,D.
\tag{4}
\]
折点按 AC 链式法则处理。这里仍是同一全 g 的密度带；不可改成各个 \(\varphi(g_i)\)。对原父权 t、选中半径或历史再加权时，标签边缘通常不再等于 α；须保实际加权边缘及 RN／乘积导数费用，不能直接移用固定尺度概率链。

## 2. 二倍尺度是准确正工具：只控制端点信息差

以边长为 R 的中心立方体，有 a.e. 恒等式
\[
k_{2R}(x)=2^{-n}\sum_{\epsilon\in\{-1,1\}^n}
k_R(x-\epsilon R/2).
\tag{5}
\]
这是把边长2R的盒分成2ⁿ个边长R的盒，移位是每坐标 ±R/2，权为2⁻ⁿ。故先取旧输出再加独立离散移位，确为同标签联合概率的 Markov 退化。

更精确地，设 \(s_\epsilon=\epsilon R/2\)，
\(\omega_\epsilon(B)=g_R(B-s_\epsilon)/(2^n g_{2R}(B))\)，
\(p^\epsilon_i(B)=p_{i,R}(B-s_\epsilon)\)。零权项置零。则
\[
\mathcal I(R)=\mathcal I(2R)+\mathcal D_R,
\quad
\mathcal D_R=\int g_{2R}\sum_\epsilon\omega_\epsilon
D(p^\epsilon\|p_{2R})\,dB,
\quad 0\le\mathcal D_R\le nW\log2.
\tag{6}
\]
最后一界来自条件互信息 \(I(\text{label};\epsilon\mid B)\le H(\epsilon)\)，独立于标签数和来源集中程度。它确实给有限端点损失；两边 KL 若同为∞，用定义的有限 \(\mathcal D_R\) 与扩展值链式等式理解，不能写未定义的差。W=0全部单列为零。

对矩形核可每次只将一个坐标宽度加倍，逐步各有 Bernoulli 移位的同型公式和 ≤W log2 的损失，合计仍至多 nW log2。这个坐标路径的中间核是矩形，不是原共同 isotropic 半径；离散移位的连续插值也一般不等于连续变宽的均匀盒。

因此 (6) 不证明一般 R→s 的卷积退化，更不证明所有中间半径的信息量单调。端点有界净变化不能控制 \(\int(\dot{\mathcal I})_+\)，更不能单独控制 \(\mathcal V\) 的全平均正通量。若利用坐标插值，须证明中间所有矩形／混合核的费用、初末端与 isotropic 通量间的真实比较，不能把路径替换当成免费步骤。

可建设性使用的最小接口是：(a) 在同一全密度带下证明 (2)/(4) 的有符号熵流与目标正通量的逐点或积分比较，保 g 的零阶及所有负项；(b) 独立控制该流的正变差或每个尺度上穿的重复收费。仅有 (1)、(3) 或二倍端点 (6)，还没有这一比较和根阶总预算。不得由新输出概率刷新原 J 的来源或历史。

本机指定 Python 实际运行3项 SymPy 精确恒等式检查：KL 点态导数、平方 score 分解、全密度带乘积式 (4)。仅核代数，不认证通量可积性或几何阶数。独立预审交付后等待作者。
