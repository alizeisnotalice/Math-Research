# R505：带截断坐标鞅的根阶周期价与连续尺度迁移界限

本稿得到一个一般 \(L^1\) 来源的真实辅助根阶估计：精确倍增所产生的随机坐标鞅，其一整个周期的密度带变差为 \(O(\sqrt{n\log(2r)}W)\)。该鞅同时移动中心，尚不能支付 R504 的连续、同中心正通量。下文把这两种量严格区分，并排除一个自然但不合法的连续卷积刷新方案。

## 1. 冻结目标与精确辅助概率空间

令 \(\mu=f\,dx\)、\(f\ge0\)、\(W<\infty\)，\(k_R=R^{-n}1_{[-R/2,R/2]^n}\)、\(g_R=f*k_R\)。原场仍满足 \(a\le R_A\le b\le2a\)、\(m_A=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(d\nu=tq_A\,dA\)、\(t\le S\)，\(r=\lambda/q\)。采用 R504 同一输出函数
\[
\varphi(s)=\begin{cases}
0&s\le q/2,\\2s-q&q/2<s<q,\\s&q\le s\le\lambda,\\
\lambda&s\ge\lambda.
\end{cases}
\]
原完整父量的既有入口为
\[
R_\tau\le S[W+\mathcal V_{q,\lambda}(f)],\qquad
\mathcal V_{q,\lambda}(f)=\int_a^b\int
(\partial_R\varphi(g_R(A)))_+\,dA\,dR.\tag{1}
\]
以下不更改 \(\mu\)、\(q_A\) 或实际接受权。

固定 \(R>0\)，取辅助符号 \(\epsilon_i\) 独立均匀于 \(\{-1,1\}\)。准确恒等式是
\[
k_{2R}=\mathbb E\,k_R(\,\cdot-(R/2)\epsilon),\qquad
M_j(A,\epsilon)=\mathbb E\left[
 g_R\left(A+\frac R2\sum_{i=1}^n\epsilon_ie_i\right)
 \middle|A,\epsilon_1,\ldots,\epsilon_j\right].\tag{2}
\]
于是 \(M_0=g_{2R}(A)\)，\(M_n=g_R(A+R\epsilon/2)\)，且 \(M_j\) 是非负鞅。中心使用真实 Lebesgue 积分；辅助符号使用有限概率空间。条件期望只在符号纤维上计算，无需把无限 Lebesgue 测度归一化。平移不变性给
\[
\int\mathbb E M_j\,dA=W\quad(0\le j\le n).\tag{3}
\]
第 \(j\) 个中间函数是边长前 \(j\) 坐标为 \(R\)、其余为 \(2R\) 的矩形平均，中心移到 \(A+(R/2)\sum_{i\le j}\epsilon_ie_i\)。这些是辅助矩形，不是原接收场。只对辅助符号作独立性假设，完整 \(f\) 可任意依赖所有坐标，来源后验也未拆成乘积。

## 2. 带截断熵给整周期根阶价

定义凸函数及其 Bregman 差
\[
\mathcal E(s)=\int_{q/2}^{\lambda}\frac{(s-u)_+}{u}\,du,
\qquad D_{\mathcal E}(u,v)=\mathcal E(u)-\mathcal E(v)-\mathcal E'(v)(u-v).
\]
有 \(0\le\mathcal E(s)\le\log(2r)s\)，\(\mathcal E'\) 有界，且几乎处处
\(\mathcal E''(s)=1_{q/2<s<\lambda}/s\)。对所有 \(u,v\ge0\)，
\[
\frac{[\varphi(u)-\varphi(v)]^2}{u+v}
\le8D_{\mathcal E}(u,v),\tag{4}
\]
\(u=v=0\) 时左侧取0。证明：令 \(h\) 为两端之间与 \([q/2,\lambda]\) 交集的长度，则 \(|\varphi(u)-\varphi(v)|\le2h\)。Bregman 的积分余项在这个交集上具有到端点的线性权，故
\[
D_{\mathcal E}(u,v)\ge\frac{h^2}{2\max(u,v)}
\ge\frac{[\varphi(u)-\varphi(v)]^2}{8(u+v)}.
\]
若交集为空，两边差为零；不涉及在零点除法。

鞅条件均值使线性项的积分准确为零。因此
\[
\begin{aligned}
\sum_{j=1}^n\int\mathbb E D_{\mathcal E}(M_j,M_{j-1})\,dA
&=\int\mathcal E(g_R)\,dA-\int\mathcal E(g_{2R})\,dA\\
&\le\log(2r)W.\tag{5}
\end{aligned}
\]
所有项均可积，不是两个无穷熵相减。结合 (3)、(4) 与 Cauchy–Schwarz 得
\[
\boxed{\sum_{j=1}^n\int\mathbb E
|\varphi(M_j)-\varphi(M_{j-1})|\,dA
\le4\sqrt{n\log(2r)}\,W.}\tag{6}
\]
任何一个方向的正变差也受此界。若附加原某个 \([0,S]\) 的正限制，该辅助积分至多乘 \(S\)；但这并不识别它与 (1) 的关系。特别是不能把中间矩形或符号路径赋予原 rank、void 或接受 history。

这里使用**输出带**的凸熵，未把输入 \(f\) 截断。使用全 \(s\log s\) 只能给可能含 \(n\log2\) 的熵差；(5) 通过有界斜率避免这一损失。这是本稿已证的改进，范围准确限于 (2) 的随机周期。

## 3. 不能免费的连续迁移，以及真正未证的一步

原 \(\mathcal V\) 是同一个中心 \(A\) 上 \(R\mapsto\varphi(g_R(A))\) 的连续正变差；(6) 则在随机移动的中心上揭示坐标。即使 \(b=2a\)，两者只共享一个粗尺度端点，不能把原连续曲线的所有正增量代入这一个鞅周期。\(b<2a\) 时，倍增的另一端更不等于原窗的末端。有限固定中心尺度分割的正变差趋于 (1)，而逐分割点重复 (6) 会付分割数倍的费用。

一种可能修补是要求每个中间倍率都具有与来源无关的平移刷新：
\[
k_s=k_R*\eta_{R,s},\qquad R<s<2R,
\tag{7}
\]
其中 \(\eta\) 为概率测度。**这一要求不成立，甚至有限有符号卷积测度也不行。** 沿一个坐标取频率 \(2\pi/R\)，\(\widehat k_R\) 为零，故 (7) 的右侧为零；左侧为
\[
\widehat k_s(2\pi e_1/R)=\frac{\sin(\pi s/R)}{\pi s/R}\ne0.
\tag{8}
\]
这只是初等盒积分，不依赖来源的特殊形状，也不假设一般非平移 Markov 核不存在。它精确排除了将 (2) 按任意小尺度步长继续作同类卷积刷新、再免费使用鞅望远镜的做法。把大盒切成不同大小子矩形虽可形成另一鞅，但子尺度及中心已变；仍需新的比较才能恢复原同中心通量。

本路线要支付原 (1)，还须证明同中心的连续正变差能由上述**一次或有可求和总权**的随机周期变差及已付端点控制，且常数不再含 \(\sqrt n\) 或分割数。现有倍增恒等式、条件 Jensen 和质量守恒不提供这一比较。没有作此未经证明的迁移，故本稿不宣称 \(\mathcal V\) 或原完整 \(R_\tau\) 已获根阶价；端点来源费 \(SW\) 仍保留。

## 4. 有界本机核验与范围

下面核验四个非对称 Bregman 方向、一个三代二元条件均值模型、能量望远镜和 Fourier 非零值。使用 Fraction、Arb 160-bit 向外区间与 SymPy，实际运行16项检查通过。这是鞅代数的有限测试，既不是来源坐标独立模型，也不认证原连续通量或历史。一般不等式由以上解析证明给出。

```python
from fractions import Fraction as F
from flint import arb,ctx
import sympy as sp
ctx.prec=160
q,h=F(1),F(2); lo=q/2
A=lambda x:arb(x.numerator)/arb(x.denominator)
def ent(x):
    if x<=lo:return arb(0)
    if x<=h:return A(x)*(A(x)/A(lo)).log()-A(x)+A(lo)
    return A(x)*(A(h)/A(lo)).log()-A(h)+A(lo)
def der(x):
    if x<=lo:return arb(0)
    return (A(min(x,h))/A(lo)).log()
def phi(x):
    if x<=lo:return F(0)
    if x<q:return 2*x-q
    return min(x,h)
checks=0
for u,v in [(F(0),F(1)),(F(1),F(4)),(F(3),F(1,4)),(F(3,4),F(3,2))]:
    D=ent(u)-ent(v)-der(v)*A(u-v)
    assert 8*D>A((phi(u)-phi(v))**2/(u+v));checks+=1
leaves=[F(0),F(1,4),F(1,2),F(3,4),F(1),F(3,2),F(3),F(8)]
N=len(leaves);W=sum(leaves)/N
energy=F(0);var=F(0);dsum=arb(0)
for j in range(1,4):
    width=N//(2**j)
    for k in range(2**j):
        u=sum(leaves[k*width:(k+1)*width])/width
        p0=(k//2)*2*width
        v=sum(leaves[p0:p0+2*width])/(2*width)
        if k%2==0:
            u2=sum(leaves[(k+1)*width:(k+2)*width])/width
            assert (u+u2)/2==v;checks+=1
        prob=F(1,2**j)
        if u+v:energy+=prob*(phi(u)-phi(v))**2/(u+v)
        var+=prob*abs(phi(u)-phi(v))
        dsum+=A(prob)*(ent(u)-ent(v)-der(v)*A(u-v))
end=sum((ent(x) for x in leaves),arb(0))/N-ent(W)
assert (dsum-end).contains(0);checks+=1
assert A(energy)<8*end;checks+=1
assert end<A(W)*arb(4).log();checks+=1
assert A(var)<4*A(W)*(3*arb(4).log()).sqrt();checks+=1
assert sp.simplify(sp.sin(3*sp.pi/2)/(3*sp.pi/2)+2/(3*sp.pi))==0;checks+=1
print(f'{checks} checks PASS; exact conditional means, Arb160 entropy inequalities, symbolic Fourier obstruction.')
print('finite binary variation=',var,'weighted square=',energy)
```

实际 stdout：

```text
16 checks PASS; exact conditional means, Arb160 entropy inequalities, symbolic Fourier obstruction.
finite binary variation= 11/8 weighted square= 463703/547008
```

结论范围：已得到带截断随机坐标周期的根阶来源价格；未取得从原连续同中心通量到该周期的无损或有价比较。停止于这一明确迁移缺口，不把辅助价格直接代回母账。
