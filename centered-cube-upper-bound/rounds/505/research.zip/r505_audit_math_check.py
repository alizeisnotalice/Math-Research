import sympy as s

x=s.symbols('x0:3',positive=True)
z=s.symbols('z0:3',real=True)
a=s.symbols('a0:3',positive=True)
g=sum(x)
dg=sum(x[i]*z[i] for i in range(3))
p=[v/g for v in x]
D=sum(p[i]*s.log(p[i]/a[i]) for i in range(3))
I=g*D
der=lambda f:sum(s.diff(f,x[i])*x[i]*z[i] for i in range(3))
assert s.simplify(der(I)-sum(x[i]*z[i]*s.log(p[i]/a[i])
                           for i in range(3)))==0
zb=dg/g
assert s.simplify(sum(x[i]*z[i]**2 for i in range(3))-g*zb**2
                  -g*sum(p[i]*(z[i]-zb)**2 for i in range(3)))==0
phi=s.Function('phi')
u=s.Symbol('u')
phiprime=s.Subs(s.diff(phi(u),u),u,g)
rhs=(phi(g)/g*sum(x[i]*z[i]*s.log(p[i]/a[i]) for i in range(3))
     +(phiprime-phi(g)/g)*dg*D)
assert s.simplify(der(phi(g)*D)-rhs)==0
print('PASS 3 exact KL-derivative, square-score and full-band product-rule identities; no geometric flux estimate')
