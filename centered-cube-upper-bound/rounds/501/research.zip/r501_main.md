# 第501轮：共同质量约束与保void的双来源比较

日期2026-10-21；继承已推送R500（15c3adc9a928ed5d4657a7d1509201d8da2e0264）。本轮有新的共同质量不等式和保原时钟的比较工具，但没有新增完整原余项的根阶付款；一般目标保持未闭合。

## 1. 冻结目标、完整账与研究决策

保任意正L1来源 $\mu=f\,dx$、$W=\|f\|_1$，同一个可测中心立方体选择器，$a\le R_A\le b\le2a$，$m_A=\mu(Q_A)=q_AR_A^n$，$q\le q_A\le\lambda$，$r=\lambda/q$。真实接收测度 $\nu=tq_A\,dA|_{t\ge\tau}$，$0<\tau\le S$，$t\le S$，均匀mark给 $\widehat\nu$；质量与mark共同全序。来源 $\pi_A=1_{Q_A}\mu/m_A$，$\rho_x=c_A(x)\widehat\nu/m_A$，$v_x(\widehat B)=\rho_x\{\widehat C\prec\widehat B\}$。质量原子不能删去mark。

使用R495–500实际T、$K=\kappa T$、$G=\sum_j(K_0^*)^j1\le\Phi_{\max}=e^{c/T}(1+cL/T)$，$c=rS$、$L=\log r+n\log(b/a)$。记 $h_B(z)=1_{v_z(B)<K}$、$\zeta=1-n^{-1/2}$、$\chi_\partial(A,x)=1_{2\|A-x\|_\infty>\zeta R_A}$，n=1沿既有固定参数界单列。原边界祖先量为
\[
\frac1T\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)h_B(z)
\int_{A\succ B}\frac{G(A)c_A(x)}{m_A}\chi_\partial(A,x)
1_{v_x(A)\ge K}e^{-(v_x(A)-v_x(B))/T}\widehat\nu(dA).
\]
R500已在这个域上付极近全pair和远inside两部分。令 $d_n=a\log\log(n+e)/(2n)$、$D_0=\log[\Phi_{\max}(1+n\log(b/a))]$，剩余mask是
\[
M(A,B,x,z)=1_{\|x-z\|_1>d_n}
\left(1_{z\notin Q_A}+1_{z\in Q_A,\ \|x-z\|_1<bD_0}\right).
\]
两项互斥，若bD0≤dn则内部中距为空。整个未付目标 $J$ 就是在上式插入M；不另选有利子流。完整账仍为
\[
R_\tau\le (K+C_{\rm deep}+C_{\rm empty}
+4Sr\Phi_{\max}\log(n+e)+S\kappa)W+J.
\]
目标仍是 $J\le\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W$ 或具有可求和费用、统一收缩及受控终端的真实递推。本轮没有证明这一步。

研究决策：固定全局矩形网格的逐pair正包络无法廉价跨过中距，不能继续靠优化网格常数推进。下一几何构造须保整个来源集群的共同质量，或直接支付原时钟下的双来源比较误差。这里不排除来源适配分割，更不声称给出原困难流反例。

## 2. 共同质量不等式及其真实使用范围

对同一固定矩形网格的两个不同格子C,D，令M_C=μ(C)、M_D=μ(D)、$V_h=\prod_i(1+h_i/a)$。同父后验概率满足 $p_C+p_D\le1$。真实匹配和中心体积给
\[
\nu\{p_C>s,p_D>t\}\le SrV_h\min(M_C/s,M_D/t),\quad s+t<1,
\]
而s+t≥1事件为空。三角形上的层蛋糕积分得到
\[
\int p_Cp_D\,d\nu\le SrV_h\left[M_C\log(1+M_D/M_C)+M_D\log(1+M_C/M_D)\right].
\]
零质量按连续延拓另列。平衡质量时系数2M log2，确实优于不使用共同质量的2M。这是一般不等式，但跨格求和还会重复收同一来源质量，尚不是J预算。

geometry稿还给固定共同位移窗内的合法inside费用，不将逐pair最优网格直接代入同一积分。对固定正网格混合覆盖 $p_b(d)=\prod_i(1-d_i/b)_+$，必需成本至少
\[
p_b(d)\prod_i(\sqrt{1+d_i/a}+\sqrt{d_i/a})^2.
\]
在 $n\ge2$、$d_i=a/n$ 时至少 $\exp(\sqrt{2n}-2)$。这个结论仅限现有网格碰撞价格的逐点非负混合机制，不是原量J的下界。若来源集中于边长a/n的小立方体，自适应对齐为一个格子却只需 $(1+1/n)^n\le e$；因此不得把前述结论外推成来源适配几何的不可能性。

## 3. 原秩和void为何必须与几何共同保留

独审先于作者推导核对：对于同一全序cut，$\delta(A)=v_x(A)-v_z(A)$ 的来源差积分保真实 $tR^{-n}(c_x-c_z)$，同质量层保mark部分。区间 $J_{BA}=(B,A)$ 上的共同与独占时钟都非负；原x-void可以拆为共同与x独占两个指数。但若改成z-void，准确乘子是
\[
\exp\left(-\frac{\delta(A)-\delta(B)}T\right),
\]
它可能大于1。原门只给
\[
v_x(A)-v_x(B)+\delta(B)\ge K-v_z(B),
\]
不能删除δ(B)。薄来源体积不能替代这个有符号实际秩差。

proof稿以同一共同PPP和两侧独占PPP构造双来源第一点比较。比较时必须对两侧使用同一个冻结函数
\[
F_{B,x,z}(A)=G(A)\chi_\partial(A,x)M(A,B,x,z),\quad 0\le F\le\Phi_{\max};
\]
不能同时换来源和改变mask。共同首点的rank门不一致也要收费，不能只保独占候选费用。其两项竞争误差及对角量的精确公式、有限原子端点约定见proof。使用这个比较仍需证明完整来源加权误差的根阶价格；单独把失败概率记为一个新符号不算付款。

## 4. 母账、技能及停止范围

R495已付非rank费用、一次τX截断和R500已付子域保留；无新的吸收收益可相加。原入口倍率 $64(128/119)/(1-32\delta_{\rm old}-16\eta_{\rm old})$ 及初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例和全尺度拼接照旧。R498有符号谱接口为备选，不与本次正比较重复抵扣。

沿用64项工具E03的真实到达测度、有限停止及终端纪律，L03的精确/区间证据区分；不援引未核的外部Bellman定理或常数，不假设非嵌套立方体是树。Astra负责共同质量与几何，Sol分别构造时钟比较、独审和计算；只复用有明确任务的Agent，不为满员启用Luna。

本轮不扩展无目的反例扫描。固定网格候选已经给出足以改变下一步的定量决策，停止继续调常数。后续主攻一个来源适配的共同质量结算，或对proof保原void的耦合误差给真实源价；必须直接改善同一J，而不是增加局部分支。

## 5. 实际计算与复现

指定本机Python3.12.14，SymPy1.14.0、python-flint0.9.0；原解释器 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。root执行 `/tmp/replay_r501.py` 在临时目录以 `-I` 重放geometry/proof内嵌代码与numeric.py，297项报告核验单位通过（3项符号恒等式、24项160-bit Arb、270项精确/384-bit Arb），stdout一致，numeric仅排除动态秒数后逐字段相同。规范结果SHA256为 `f3cddd7bafa8ab3343adcf970ad6c6a285b387c6ca926bb2762096f2bd1e5b5d`。

数值范围是12个分段常率连续秩接口模型，以及24个固定pair诊断：n=2,8,64,512，距离a/(2n)、a/2、a，各作balanced/sparse两分布。不是297个独立模型，也不认证原L1接收中心、matching或hard history。先核单坐标公式，再核零坐标与集中位移，最后扩大维数；没有随机扫描。n=8、均匀位移a/8的最优网格边a/2给全有理代价256；这一精确例只解释网格机制。一般正混合成本界与共同质量公式由解析证明给出，Arb含零仅核验已知符号恒等式相容，不把含零当等式证明。

本轮归档详细LaTeX、独审和必要复现，不编译PDF。保原根阶目标，明确没有付掉J，也没有证明当前耦合必然成功。
