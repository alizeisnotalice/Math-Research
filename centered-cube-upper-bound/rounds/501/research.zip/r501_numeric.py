from pathlib import Path
from fractions import Fraction as F
import sys,platform,time,json
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def zero(x):ck(x.is_finite());ck(x.contains(0))
x,y,N,D=sp.symbols('x y N D',positive=True)
f=y*(1+y)/(y-x);rad=sp.sqrt(x*x+x);opt=x+rad;minimum=1+2*x+2*rad
ck(sp.factor(sp.diff(f,y)-(y*y-2*x*y-x)/(y-x)**2)==0)
ck(sp.simplify(f.subs(y,opt)-minimum)==0)
ck(sp.simplify((sp.sqrt(1+x)+sp.sqrt(x))**2-minimum)==0)
ck(sp.simplify((y-x-rad)*(y-x+rad)-(y*y-2*x*y-x))==0)
ck(sp.limit(2*sp.sqrt(N)*sp.asinh(sp.sqrt(D/N)),N,sp.oo)==2*sp.sqrt(D))
ck(sp.limit((1-D/(2*N))**N,N,sp.oo)==sp.exp(-D/2))
ck(sp.limit(2*N*sp.asinh(1/(sp.sqrt(2)*N)),N,sp.oo)==sp.sqrt(2))
# Positive mixture lower bound is a linear consequence C_h>=Fopt P_h.
for q in (F(1,16),F(1,2),F(1),F(2)):
 xx=ar(q);yy=xx+(xx*xx+xx).sqrt();ff=1+2*xx+2*(xx*xx+xx).sqrt()
 zero(yy*(1+yy)/(yy-xx)-ff);ck(yy>xx)
 zero(ff.log()-2*xx.sqrt().asinh())
ck(sp.limit((1+y),y,0,dir='+')==1)
qx=F(1,8);qy=F(1,2)
ck(qy*qy-2*qx*qy-qx==0)
ck((qy*(1+qy)/(qy-qx))**8==256)
records=[]
for nn in (2,8,64,512):
 for distance in (F(1,2*nn),F(1,2),F(1)):
  for scheme in ('balanced','sparse'):
   q=distance/nn if scheme=='balanced' else distance
   active=nn if scheme=='balanced' else 1
   xx=ar(q);yy=xx+(xx*(1+xx)).sqrt();rho=1+2*xx+2*(xx*(1+xx)).sqrt()
   grid=rho**active;collision=(1-xx/yy)**active;enlargement=(1+yy)**active
   zero(enlargement/collision-grid)
   pbq=(1-q/2)**active;pb=ar(pbq)
   ck(pbq>=1-distance/2);ck(pbq>0)
   paircost=grid*pb
   ck(paircost.is_finite());ck(paircost>0)
   zero(grid.log()-2*active*xx.sqrt().asinh())
   # The exponential common-center estimate is an upper bound, not an extra discount.
   ck(pb<(-ar(distance/2)).exp())
   records.append(dict(n=nn,total_L1_over_a=str(distance),scheme=scheme,positive_coordinate_count=active,positive_coordinate_d_over_a=str(q),zero_coordinate_count=nn-active,a='1',b='2',hstar_over_a_positive_coordinates=str(yy),minimum_attained=scheme=='balanced',zero_coordinate_scope='No zero mesh: inactive-coordinate infimum1 approached as h_i decreases to0.' if scheme=='sparse' else 'All optimal h_i strictly positive.',optimal_C_over_P=str(grid),log_optimal_C_over_P=str(grid.log()),collision_at_positive_optimum=str(collision),enlargement_at_positive_optimum=str(enlargement),p_b_exact=str(pbq),p_b=str(pb),optimistic_product_Fopt_pb=str(paircost),log_product=str(paircost.log()),product_over_sqrt_n=str(paircost/arb(nn).sqrt()),product_scope='Algebraic product diagnostic / positive-grid-mixture necessary coverage cost, NOT a proved bound on the original source integral.'))
# Fixed-distance balanced/sparse comparisons, exact geometric infima evaluated by Arb.
for nn in (2,8,64,512):
 for distance in (F(1,2*nn),F(1,2),F(1)):
  pair=[r for r in records if r['n']==nn and r['total_L1_over_a']==str(distance)]
  bal,sparse=pair
  ck(arb(bal['optimal_C_over_P'])>arb(sparse['optimal_C_over_P']))
  ck(arb(bal['optimistic_product_Fopt_pb'])>arb(sparse['optimistic_product_Fopt_pb']))
result=dict(scope='Finite scalar rectangular-grid kernel optimization and pairwise coverage-cost diagnostic. Not original f/history/flow certification or permission to choose a separate grid per pair.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r501_numeric.py',seconds=time.perf_counter()-start),checks=checks,finite_pair_cases=24,formulas=dict(collision='P_h(d)=prod_i(1-di/hi)_+',enlargement='C_h=prod_i(1+hi/a)',optimum='For x=di/a>0,y=hi/a>x:ystar=x+sqrt(x*x+x),min factor=(sqrt(1+x)+sqrt(x))^2;di0 has infimum1 as hi goes to0,not a legal zero mesh.',Fopt='exp(2 sum_i asinh(sqrt(di/a)))',positive_mixture='For every fixed h,C_h>=Fopt(d)P_h(d). If omega>=0 and integral omega P_h(d)>=p_b(d),then integral omega C_h>=Fopt(d)p_b(d). This is a necessary cost for that kernel-coverage strategy only.',balanced_limits='For fixedD/a>0,logFopt/sqrt n tends2sqrt(D/a),p_b tends exp(-D/b). ForD/a=1/(2n),logFopt tends sqrt2.',scope='Astra fixed displacement window estimate requires one common h>window upperdi. Point-pair adaptive hstar is not an integrated estimate.'),records=records,decision='At balanced intermediate distanceD~a,the best pairwise rectangular-grid cost grows exp(2sqrt(nD/a)),whilep_b remains order1. Thus simple pointwise cancellation/positive rectangle-grid kernel coverage does not extend the near-square route to that middle scale. This does not exclude geometry/source correlations or other integral uses of rectangular grids.',errors='Exact SymPy derivative/minimum/limits;384-bit Arb algebraic minima and Fraction p_b. No optimizer,random scan,quadrature or native model claim.')
(ROOT/'r501_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;24 balanced/sparse pair diagnostics;no original integral bound claimed')
