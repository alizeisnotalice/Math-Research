# R501 独立终审

FINAL PASS（限定范围）。同父两格的共同质量尾界及熵式、固定窗费用接口、原时钟保 void 的双来源第一点比较成立。网格正混合成本仅是该机制的必要代价。本轮**没有新增原剩余 J 的根阶付款**，一般目标与原母账仍未闭合。

独立 PRE 先核 rank 差、质量原子和 void 分解，再审白名单全部七件。主稿已按终审补上网格指数下界的局部 n≥2 限定；其余无需修补。

- **共同质量工具。** 两个不同网格满足 p_C+p_D≤1。真实 matching 与相同接收中心膨胀盒给 SrV_h min(M/s,N/t) 联合尾；triangle层饼严格得 Mlog(1+N/M)+Nlog(1+M/N)，包括零格连续延拓。固定全局位移窗的 ancestor 正上放保 Φ_max/T、S、实际 π_B² 及碰撞分母，式(4)系数正确；跨格独立求和尚会重复收费，未假装消去同父共同质量约束。
- **网格机制范围。** 矩形单坐标最优、零坐标仅有下确界、乘积值及非负字典成本方向正确。n≥2、d_i=a/n 下的 exp(√(2n)−2) 下界保 p_b≥e^(−2) 与 asinh估计；不适用于未限定的一维端点。它不是原流下界，也不排除来源适配的共同划分。逐pair最优h不能代入一个共同网格的积分。
- **真实来源与耦合。** rank 差保同一质量/mark前缀，改用z-void的signed因子可能>1。证明的共同及两侧独占PPP总强度没有双计共同点；两个源各取第一点，若未过其绝对rank门立即墓地，不继续找后点，故期望确为各自V核。第一union exclusive与共同点gate异号事件互斥并覆盖输出不同，其概率保正确union void，E+J≤1。比较两侧使用同一个F=G·boundary·remaining-mask；没有同时改变来源和mask，也没把辅助核赋予原成功历史。
- **整体回代。** outside分支的V_zF确为零；inside中距仍在。对角上放得到(e^κ−1)E_empty准确，但放大后仅恢复旧A_*TW线性宽度账。直接以概率≤1上放误差只得Φ_max R_τ；两者都没有可吸收系数。主稿剩余mask与R500四域账一致，n=1单列已有固定参数帽；本轮未宣称耦合成功占固定比例。

**独立实际复现。** 指定 Python `-I` 临时隔离重放 geometry3、proof24、numeric270，共297项报告核验单位，全部stdout与冻结replay一致。numeric JSON只去compute_index.seconds后逐字段一致，规范SHA256为 `f3cddd7bafa8ab3343adcf970ad6c6a285b387c6ca926bb2762096f2bd1e5b5d`。12个连续秩clock模型仅核比较代数；24个balanced/sparse点对与精确/Arb384位计算仅核网格函数，非真实L¹接收中心、原matching或hard历史认证。几何/成本的一般结论来自自含解析证明，区间含零不单独证明等式。数值没有被用来排除原几何路线。

原一次τX、既有非rank与R500已付子域、入口倍率及所有未付槽保留；R498谱接口不与本次正比较重复抵扣。尚缺同一J上的共同来源/时钟误差总预算；本报告不认证完整根阶结论。

## 最终输入绑定

- `r501_main.md`: `3fb4455877281c503f9f0e168aa744d67af9c621bc65b079f7a82a7b5921c4b7`
- `r501_geometry.md`: `9ff65edc93de5eda99966dc63eedc28aa680d4cbd3443b90223b2634514f9d85`
- `r501_proof.md`: `798050cf8eb59e2355dab8575917bd6fdf56eae9e8883b8b2f485058f1677944`
- `r501_numeric.md`: `c42e3169ba5313aa6a18f5eeef9834930238711d5c76c70eac1c58beb635c9f1`
- `r501_numeric.py`: `5c5df7a9e8629aa4ba0680ade203f66c23d1207769c4e4696b74abd54c342df1`
- `r501_numeric.json`: `229ee7ddda4addc6e0591a24d6ef30a7629a216c3877e31fa552ffe74ed426c2`
- `r501_replay.json`: `a54f99759e01bc2b80df7e6ab2cda8fabdd5d018629205e211034a766f17ef47`
