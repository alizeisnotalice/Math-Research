# R501：同一质量／mark 顺序上的双来源第一点耦合

本稿保持 R500 完整合同与两项未付积分
\(I_{\rm middle,in}+I_{\rm nonnear,out}\)。结果是一个保留原 void 的定量比较；没有得到新的根阶付款。尤其不把 R496 已知对角账、一般来源交换或下面定义的失败概率当成已支付费用。

## 1. 原积分及唯一比较对象

对有效 \((\widehat B,x,z)\)，\(x,z\in Q_B\)，令
\[
\rho_x(d\widehat A)=\frac{c_A(x)}{m_A}\widehat\nu(d\widehat A),
\quad \omega(d\widehat A)=\frac{\widehat\nu(d\widehat A)}{m_A},
\quad v_x(\widehat A)=\rho_x\{\widehat C\prec\widehat A\}.
\]
\(\prec\) 是原质量加连续 mark 的顺序。同质量的 mark 区间可有正秩增量，不能删去。所有来源使用同一真实中心及边长选择器。秩可在父不捕获该来源时仍按 prefix 定义。

记原剩余域指示为 \(\chi_{\rm rem}(A,B,x,z)\)，严格沿 R500 的中距内部与非近外部两个互斥集合。固定这三个标签后，比较函数为
\[
F_{B,x,z}(A)=G(A)\chi_\partial(A,x)\chi_{\rm rem}(A,B,x,z),
\qquad 0\le F_{B,x,z}\le\Phi_{\max}.
\tag{1}
\]
这里两核使用**同一个** \(F_{B,x,z}\)，不交换来源、边界指示或剩余 mask。准确有
\[
I_{\rm rem}=\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)
1_{v_z(B)<K}\,(V_xF_{B,x,z})(B),
\tag{2}
\]
\[
(V_xF)(B)=\frac1T\int_{A\succ B}F(A)1_{v_x(A)\ge K}
e^{-[v_x(A)-v_x(B)]/T}\rho_x(dA).
\]
这仍是原 max-only 标量核的祖先表达，不给辅助父新增原成功历史资格。

## 2. rank 增量先分共同与分离捕获

在同一顺序上置
\(\rho_\cap=c_A(x)c_A(z)\omega\)、
\(\rho_{x\setminus z}=c_A(x)(1-c_A(z))\omega\)、
\(\rho_{z\setminus x}=c_A(z)(1-c_A(x))\omega\)。因此
\[
v_x(B)-v_z(B)
=\rho_{x\setminus z}(({-\infty},B))-
\rho_{z\setminus x}(({-\infty},B))=:\Delta_B.
\]
沿任一原 \(x\)-祖先边，令 \(a_x=\rho_x((B,A))\)。原门强制
\[
a_x\ge [K-v_z(B)-\Delta_B]_+ .\tag{3}
\]
这里忽略积分端点只因连续 mark 推前无原子，并非把相等质量视为零区间。式(3)说明 rank 跨门并不只由共同增量承担：父之前的 signed exclusive 差 \(\Delta_B\) 可以先提供它。变量半径下，来源距离不能直接变成此差的薄层质量帽。

## 3. 保留实际指数 void 的定量耦合

在 \((B,\infty)\) 上，独立生成强度分别为
\(\rho_\cap/T,\rho_{x\setminus z}/T,\rho_{z\setminus x}/T\)
的三个 PPP。它们的总强度有限：\(\rho_x(E),\rho_z(E)\le SA_n\)。共同点加 \(x\)-exclusive 点形成 \(x\) 的过程，另一个同理。各自取顺序第一点；若没有点，或第一点未通过其原绝对 rank 门 \(v_\xi(A)\ge K\)，输出墓地。令墓地上的 \(F\) 为零。其期望恰为 \(V_\xi F\)：**不是**继续寻找第一个过门点。

写
\[
U_{xz}(B,A)=(\rho_\cap+\rho_{x\setminus z}+\rho_{z\setminus x})((B,A)).
\]
下列两个互斥事件足以覆盖两输出不同：第一 union 点是 exclusive；或第一 union 点是共同点，但两绝对 rank 门异号。其概率分别准确为
\[
\mathcal E_B(x,z)=\frac1T\int_{A\succ B}
e^{-U_{xz}(B,A)/T}|c_A(x)-c_A(z)|\,\omega(dA),\tag{4}
\]
\[
\mathcal J_B(x,z)=\frac1T\int_{A\succ B}
e^{-U_{xz}(B,A)/T}c_A(x)c_A(z)
|1_{v_x(A)\ge K}-1_{v_z(A)\ge K}|\,\omega(dA).\tag{5}
\]
因此 \(0\le\mathcal E_B+\mathcal J_B\le1\)。若 union 第一点评价为共同且两门同号，两输出都相同（包括同时被杀死）；没有 union 点也同时为墓地。由同一 \(F\) 可得
\[
\boxed{|V_xF_{B,x,z}-V_zF_{B,x,z}|
\le\Phi_{\max}(\mathcal E_B+\mathcal J_B).}\tag{6}
\]
这保留共同／分离竞争的真实指数，而非把 void 丢为1。一般只有概率上界，不能把第一 union 的 exclusive 点说成原 \(x\)-核实际选中的祖先。

存在完全 signed 的耦合表达
\(V_xF-V_zF=\mathbb E[(F(X)-F(Z))1_{\rm outputs\ differ}]\)；(6)只是其正上界，未宣称负项不重要。构造及所有量可测，有限 PPP 的顺序第一点由原可测质量／mark 排序取得；零来源行与零总强度按墓地处理。

## 4. 整体回代与真实尚缺的价格

将 (6) 积入 (2)，得到
\[
I_{\rm rem}\le
\underbrace{\int\widehat\nu\pi_B^2\,1_{v_z(B)<K}\,
V_zF_{B,x,z}}_{\mathcal D_F}
+\Phi_{\max}\int\widehat\nu\pi_B^2\,1_{v_z(B)<K}
(\mathcal E_B+\mathcal J_B).
\tag{7}
\]
非近外部部分的 \(V_zF\) 恒为零，因为其 mask 要求 \(z\notin Q_A\)；内部中距则不能如此删除。若正上放 \(F\le G\)，用实际来源秩交换积分，已有对角式为
\[
\mathcal D_F\le
\int\widehat\nu\pi_B(dz)1_{v_z(B)<K}V_zG(B)
=(e^{K/T}-1)E_{\rm empty}.
\tag{8}
\]
证明是对每来源先积分 \(0\le w<K\) 与 \(v\ge K\)：
\(T^{-1}\int_0^K e^{-(v-w)/T}dw=(e^{K/T}-1)e^{-v/T}\)。
\(G\) 在同一来源秩 fiber 上取实际条件均值；不存在唯一父的假设。

R496 已证 \(E_{\rm empty}\le A_*Te^{-\kappa}W\)，故 (8) 仅给
\(A_*T(1-e^{-\kappa})W\)，而 \(A_*T\le3T+8rSL\)。这是旧线性宽度账，**不是本轮新付款**。同样，把 (7) 的概率直接放成1只给 \(\Phi_{\max}R_\tau\)，不能吸收。

故本机制的明确停止点是：需要在同一个接受积分上联合控制保留中距 mask 的 \(\mathcal D_F\) 与竞争／门错位的 signed 交换，或证明 (7) 右侧本身有小于1的 \(R_\tau\) 系数和根阶来源价。目前 CDF、head、格平方及共同捕获包络都没有给此比较。共同捕获包络是上界，并不下界第一 union 点为共同且 gate 同号的概率；近格平方只支付 R500 已删的近来源部分。不能再收一次这些费用或把 (4)–(5) 的定义本身作为进展。

## 5. 实际小型 clock 检验

以下12个分段常率、连续 rank 例核验 (6) 与失败概率不超过1。来源捕获类型为共同、\(x\)-exclusive、\(z\)-exclusive，初始两 prefix 可不同，保绝对 gate。它们是原 kernel 的有限 clock 代数检查，不是实际 Lebesgue 中心／matching 或完整 history 模型。每个积分段保指数且在 gate 跨点处分段，160-bit Arb 实际通过24条断言。

```python
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=160
def A(q): return arb(q.numerator)/q.denominator
def interval(pre,rate,lo,hi):
    return (-A(pre)).exp()*((-A(rate*lo)).exp()-(-A(rate*hi)).exp())
patterns=[[(1,1),(1,0),(0,1),(1,1)],
          [(1,0),(1,1),(1,1),(0,1)],
          [(0,1),(1,0),(1,1),(1,0)]]
rates=[F(1,2),F(1),F(3,2),F(1)]
weights=[F(1,4),F(3,4),F(1,2),F(1)]
K=F(1); checks=0
for pattern in patterns:
    for sx,sz in [(F(0),F(1,3)),(F(1,4),F(3,4)),
                  (F(3,2),F(0)),(F(0),F(3,2))]:
        px=pz=pu=F(0); vx=vz=arb(0); bad=arb(0)
        for (cx,cz),r,g in zip(pattern,rates,weights):
            cuts={F(0),F(1)}
            for flag,pref,s0 in [(cx,px,sx),(cz,pz,sz)]:
                if flag:
                    cross=(K-s0-pref)/r
                    if 0<cross<1: cuts.add(cross)
            cuts=sorted(cuts)
            for lo,hi in zip(cuts,cuts[1:]):
                mid=(lo+hi)/2
                gx=bool(cx and sx+px+r*mid>=K)
                gz=bool(cz and sz+pz+r*mid>=K)
                if gx: vx+=A(g)*interval(px,r,lo,hi)
                if gz: vz+=A(g)*interval(pz,r,lo,hi)
                if cx!=cz or (cx and cz and gx!=gz):
                    bad+=interval(pu,r,lo,hi)
            px+=cx*r; pz+=cz*r; pu+=r
        assert bad-abs(vx-vz)>0
        assert bad<1
        checks+=2
print(f'{checks} Arb assertions PASS on 12 ordered continuous-rank '
      'algebra models; not native centers/history.')
```

实际 stdout：`24 Arb assertions PASS on 12 ordered continuous-rank algebra models; not native centers/history.`
