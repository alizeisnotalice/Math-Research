# R501：矩形网格的最优碰撞—膨胀代价

已运行 270 项 exact/Arb 断言，固定 24 个 balanced/sparse pair 诊断。结论：在 ℓ1 距离 D 与 a 可比且 spread balanced 时，即使允许逐点对挑选最有利矩形网格，最优代价与共同中心 p_b 的乘积仍增长很快；p_b 不抵消该膨胀。a/n 尺度则保持常数量级。

这不是原 I 的上界或反例。尤其 h*(d) 是点对自适应值，不能直接放回一个共同网格积分。它排除的是简单正网格 kernel-cover 的低成本期待，不否定所有可能用真实来源/中心相关性的矩形方法。

## 单坐标精确最优

令 x=d/a≥0、y=h/a>x。碰撞 P_h(d)=(1−d/h)_+，膨胀因子1+h/a，其比为

f_x(y)=y(1+y)/(y−x)。

x>0 时

f'_x(y)=[y²−2xy−x]/(y−x)²，

y*=x+√(x²+x)，min f=(√(1+x)+√x)²。

另一个驻点 x−√(x²+x)<0；f 在 y↓x 或 y→∞ 时发散，所以这是全局最小，不是局部 optimizer 输出。SymPy 核导数、因式分解、临界值恒等式；x=1/16,1/2,1,2 再作 Arb algebraic/log 身份压力检查。

x=0 时 inf f=1，只在 h↓0 极限达到；实际网格始终要求 h>0。sparse 例的零坐标因此只有 infimum，不把 h=0 写成合法网格。

多坐标可分离，故

Fopt(d)=inf_h C_h/P_h(d)
=∏_i(√(1+d_i/a)+√(d_i/a))²
=exp[2Σ_i asinh√(d_i/a)]。

balanced 所有 d_i>0，最小值实达；sparse 中零坐标为极限。

## 固定 24 个输入

n=2,8,64,512；总 D/a 仅取1/(2n)、1/2、1。每组比较

balanced：各 d_i=D/n；sparse：d=(D,0,…,0)。

a=1、b=2，全部坐标差严格小于 b，没有利用共同中心为空的退化输入制造改善。p_b=∏(1−d_i/b) 是精确 Fraction，p_b≥1−D/b≥1/2；指数式 exp(−D/b) 是它的上界，不能再误作额外折扣。

三个阶段对应单坐标解析基础、零坐标/集中 spread 压力、四维数下三个预定距离的扩大。没有随机 scan、来源密度或历史模型。

## 共同中心衰减不足以逐点抵消中距膨胀

D=a 的摘要（严格 Arb 值见 JSON）：

| n | balanced Fopt | balanced p_b | balanced Fopt·p_b | sparse Fopt·p_b |
|---|---:|---:|---:|---:|
| 2 | 13.92820 | .5625 | 7.83461 | 2.91421 |
| 8 | 256 | .596719 | 152.76019 | 2.91421 |
| 64 | 8.52594×10^6 | .605341 | 5.16110×10^6 | 2.91421 |
| 512 | 4.44153×10^19 | .606383 | 2.69327×10^19 | 2.91421 |

n=8 balanced 有完全有理的最优 witness：d_i=a/8、h_i*=a/2，单坐标比恰2，总 Fopt=256；p_b=(15/16)^8。脚本独立 Fraction 核其驻点方程和最小代价。

反之 D=a/(2n)、n=512 时，balanced Fopt·p_b约4.11124，sparse约1.06396。微距可控与中距高代价并不矛盾。

一般 scalar 极限由 SymPy 实际核验：固定 D/a>0，balanced 有

log Fopt/√n→2√(D/a)，p_b→exp(−D/b)；

而 D/a=1/(2n) 时 log Fopt→√2。

这些是明确函数的解析极限，不从四个 n 猜阶数。因共同中心 J≥p_b，若期待简单相乘来抵消网格膨胀，使用更完整 J 也不会比 p_b 给出更小的该代价。

## 正网格字典的必要成本：适用及限制

对每个固定合法矩形 h，有 C_h≥Fopt(d)P_h(d)；若某坐标 h_i≤d_i，P_h=0 时同样成立。于是对非负字典权 ω，若

∫ω(dh)P_h(d)≥p_b(d)，

则必有 ∫ω(dh)C_h≥p_b(d)Fopt(d)。

这说明正矩形 grid-mixture 的点态 kernel-cover 策略，不能在 balanced 中距 pair 上以小总膨胀成本覆盖 p_b。它不是原积分下界：原流可能给这些 pair 很小权重，或有其他来源/center 关联可用；本轮没有对此采样或假定。

Astra 的实际共同-grid 窗口预算要求一个固定 h 大于整个位移窗的坐标上端；本表的逐 pair h*不能替代该条件。下一步若要覆盖完整 R500 中距，需新增真实权重/相关性机制，或超出这个简单正 factorized kernel cover；仅优化 h、再乘共同中心衰减不足。没有宣称所有矩形积分方法均不可能。

## 复现与误差

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r501_numeric.py`

实际 Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb384 bits。导数/最优式/极限为符号计算；p_b为Fraction；最优 h、代价、对数和比较为严格 Arb 包围。不使用浮点 optimizer、quadrature、Monte Carlo 或实际 f 流认证。

固定 stdout：`PASS 270 exact/Arb assertions;24 balanced/sparse pair diagnostics;no original integral bound claimed`。

compute_index.seconds 为唯一动态 JSON 字段，重放比较删该字段。断言数包含恒等式、有限性和比较，不是270个独立模型。输出在脚本自身目录；白名单仅 `/tmp/r501_numeric.py`、`/tmp/r501_numeric.json`、`/tmp/r501_numeric.md`。完成限定任务后停止。
