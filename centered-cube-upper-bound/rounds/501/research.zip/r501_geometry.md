# R501：共同来源质量的两格尾界与固定网格机制边界

目标仍是 R500 同一 \(I_\partial\) 的 middle-in 与 nonnear-out 联合根阶费用。本稿检验一个机制：用共同质量约束加强 posterior cell-square，并同时保留共同捕获的各坐标乘积。得到一个合法的两格 mixed-moment 界，但没有获得原完整积分的新费用。

## 1. 准确的共同质量尾界

保真实 \(\mu=f\,dx\)、\(m_B=\mu(Q_B)=q_BR_B^n\)、
\(a\le R_B\le b\le2a\)、\(q\le q_B\le\lambda\)、\(r=\lambda/q\)，
\(d\nu=t(B)q_BdB\)、\(t\le S\)。所有 mark 积分保持原定义。
取一个固定矩形网格，各边长为 \(h_i>0\)，置
\(V_h=\prod_i(1+h_i/a)\)。对两个不同的格子 \(C,D\)，记
\[
 M=\mu(C),\quad N=\mu(D),\qquad
 p_C(B)=\pi_B(C),\quad p_D(B)=\pi_B(D).
\]
它们是同一真实父的 posterior，故 \(p_C+p_D\le1\)。对 \(s,t>0\)，
\[
 \nu\{p_C>s,p_D>t\}
 \le SrV_h\min(M/s,N/t),
 \qquad \{p_C>s,p_D>t\}=\varnothing\quad(s+t\ge1). \tag{1}
\]
证明：事件上 \(m_B<\min(M/s,N/t)=m_*\)，且父须捕获两个格子的正来源质量。
若事件非空，\(R_*=(m_*/q)^{1/n}\ge a\)；中心属于任一格子的
\(Q_{R_*}\) 扩张，其体积至多
\(R_*^nV_h\)。乘真实中心密度上界 \(S\lambda\) 得 (1)。
只对接收中心使用 Lebesgue 体积，没有来源密度帽。

层蛋糕及 \(s+t<1\) 给出
\[
 \boxed{\int p_C(B)p_D(B)\,\nu(dB)
 \le SrV_h\,\mathcal E(M,N),}\qquad
 \mathcal E(M,N)=M\log(1+N/M)+N\log(1+M/N). \tag{2}
\]
零质量格取连续延拓 \(\mathcal E(0,N)=0\)。为核常数，令
\(s=\ell z,t=\ell(1-z)\)，\(0<\ell,z<1\)，Jacobian 为 \(\ell\)。则
\[
 \int_{s+t<1}\min(M/s,N/t)\,ds\,dt
 =\int_0^1\min\{M/z,N/(1-z)\}\,dz
 =\mathcal E(M,N). \tag{3}
\]
交点 \(z=M/(M+N)\) 保两侧完整积分。特别 \(M=N\) 时，准确系数为
\(2M\log2\)，而不使用共同质量约束的正方形尾积分为 \(2M\)。
这是同一真实父的量化改进，不是独立来源假设。

## 2. 为什么尚不能代入完整根阶账

在原 inside 祖先域中仍保 \(G(A)\)、head、void、质量序及真实 \(\pi_B(dx)\pi_B(dz)\)。
R500 共同中心包络为
\[
 U_2(x,z)\le S\mathcal P(d),\qquad
 \mathcal P(d)=p_b(d)+n\int_a^b p_s(d)\frac{ds}{s},
 \quad p_s(d)=\prod_i(1-d_i/s)_+.
\]
例如固定全局位移窗 \(l_i\le|x_i-z_i|\le u_i<h_i\) 上，可以严格得到
\[
 I_{\partial,\mathrm{in,window}}
 \le\frac{2S^2r\Phi_{\max}}T\,
 \mathcal P(l)\prod_i\frac{1+h_i/a}{1-u_i/h_i}\,W. \tag{4}
\]
这是先将祖先正核用 \(G\le\Phi_{\max}\) 与 \(U_2\) 上放，再对同一固定全局网格碰撞应用 cell-square；上界中才删 head。它未获得完整 middle 的根阶价，不作为本轮新付款。

改用 (2) 可以保不相交格子的共同质量，而非逐 pair 碰撞概率；但若将 (2) 对所有相邻格对独立求和，同一 \(M\) 会随邻格反复出现。完整 matching 中“同一个 \(m_B\) 同时容纳所有被捕获格子”的约束尚未在该求和中结算。因此 (2) 不能被写成已经支付原 \(I_\partial\)，也不能把 \(G\) 或 head 分母删后声称利用了原历史。

对 outside 部分，原 \(z\notin Q_A\) 缺第二个祖先捕获因子；R498 的人工来源输运不保 \(z\) 的原 head。上述网格公式不为其补上这个因子。

## 3. 固定正混合的精确范围，不否定来源适配分割

固定矩形网格的全局平移碰撞核为
\(q_h(d)=\prod_i(1-d_i/h_i)_+\)，其现有来源代价系数是 \(V_h\)。逐坐标优化给
\[
 \inf_{h_i>d_i}\frac{1+h_i/a}{1-d_i/h_i}
 =\left(\sqrt{1+d_i/a}+\sqrt{d_i/a}\right)^2,
 \quad h_i^*=d_i+\sqrt{d_i^2+ad_i}. \tag{5}
\]
\(d_i=0\) 时下确界为 1，以 \(h_i\downarrow0\) 逼近，不使用零边长格子。

因此如果仅用固定全局网格的非负混合来逐点上包络 \(p_b\)，即
\(\int q_h(d)\,\omega(dh)\ge p_b(d)\)，其总现有代价必须满足
\[
 \int V_h\,\omega(dh)
 \ge p_b(d)\prod_i
 \left(\sqrt{1+d_i/a}+\sqrt{d_i/a}\right)^2. \tag{6}
\]
这是由 \(q_h(d)\le V_h/F_*(d)\) 直接积分得到，不是假定可将逐 pair 最优网格代入原 cell-square 定理。
对 \(n\ge2\)、\(d_i=a/n\)、\(b\ge a\)，右端至少
\[
 \exp(\sqrt{2n}-2).
\]
因为 \(p_b\ge(1-1/n)^n\ge e^{-2}\)，且
\(2n\operatorname{arsinh}(n^{-1/2})\ge2n/\sqrt{n+1}\ge\sqrt{2n}\)。
这只说明依靠现有固定网格碰撞价的逐点正混合，不能自动抵消 spread 位移的代价；它不是原积分下界，也不是完整真实场反例。

尤其不能据此排除来源适配分割。若 \(\mu\) 集中于边长 \(a/n\) 的小立方体，可将其对齐为一个共同格子；其真实 posterior 平方价格只含
\((1+1/n)^n\le e\)。这保住整个来源集群，随机平移逐 pair 的 (6) 则会丢掉该优势。
下一构造所缺的准确步骤，是在一个共同来源适配划分中同时保全部捕获质量与同一接收 selector，使 (2) 的跨格收费不重复，并保留原 ancestor 权。当前没有证明该步骤，未获得完整 middle-in 与 nonnear-out 的联合根阶费。

## 4. 实际本机核验

以下代码在指定本机 Python 环境实际运行，三项符号恒等式通过。它核 (3)、(5) 的代数，不认证全局预算或成功历史。维数诊断由独立 numeric 附件负责，本稿不重复扫描。

```python
import sympy as s
M,N,a,u=s.symbols('M N a u', positive=True)
z=s.symbols('z', real=True)
z0=M/(M+N)
val=s.integrate(N/(1-z),(z,0,z0))+s.integrate(M/z,(z,z0,1))
want=M*s.log(1+N/M)+N*s.log(1+M/N)
assert s.simplify(s.expand_log(val-want,force=True))==0
h=u+s.sqrt(u*(u+a))
assert s.simplify(h*h-2*u*h-a*u)==0
factor=h*(a+h)/(a*(h-u))
opt=(s.sqrt(a+u)+s.sqrt(u))**2/a
assert s.simplify(factor-opt)==0
print('3 symbolic identities PASS: joint-tail entropy, grid optimizer, optimizer value.')
```

本轮交付到此停止。(2) 是有效一般几何工具，但未产生原完整预算的新付款；既有 R500 费用及未付范围保持原样。
