# R191：原共同祖先储备的加权 companion 付款

本稿给出一个实际正子支的来源预算：用同一 alpha 的完整未捕获储备在原 LCA 块上的质量，除以同一块的 current 来源容量。其后验一阶矩按原有限树的层数支付；在原 companion 内消去 rho² 后，得到 O(sqrt(n log(n+2))) 的来源价格。这不是一般剩余域的闭合，也不把大 h(LCA) 自动换成大 K0 加权储备。最后保留该转换中具体的捕获侧与硬面费用。

## LJ1. 原对象、量词和来源

固定原窗口 (omega,V,a,b,q)，a≤L,R≤b≤2a，共同 q>0。所有 dx 先在原接收域 E_rec（或其原有限截断）上。保持原 s,L、唯一 j(x)、真实原森林、全部删除和 history。记

    p_z=P_(s,L)(x-z), J_z=P_(1,b)(x-z),
    gamma=1+1/n, Lplus=min(b,gamma L),
    Q_z=(p_z+P_(s,Lplus)(x-z)+J_z)/3,
    QJ=∫J_z nu_V(dz), k_z=D K0_z,
    a_y(z)=T Delta_y(z).

K0=P_(s,Hhat) 使用原实际 Hhat，不以 expanded-current 核替换。D、T、Delta、原 capture E_y、alpha_y 和 rho_y 都保持原定义。原严格软资格 s>1-2^(-1/n)>0 仅保证 K0、p、J 在有限点严格正，不表示 s 接近 1。

nu_V、beta_V 分别受原共同父来源支配；可用 nu_V≤mu_hi≤f dx 及原 current 容量，但不假设 nu_V≤beta_V。下文只使用

    ∫p_z nu_V(dz)≤q,  ∫p_y beta_V(dy)≤q,
    ∫K0_z mu_hi(dz)≤q,
    Wnu=E_omega Σ_V||nu_V||≤W_A.                         (LJ1)

其中 mu_hi 是当前原来源块的真实高来源测度；允许用更大的、同 FIRST 合法的原 mu_hi，但不能换成未经支配的质量帽。对独立重复窗口，最终 Wnu 仍须按原总账求和。

原 RC 公式与绝对 good/bad 门给

    U_y=1_Ey min(a_y,k),
    alpha_y QJ=Dq-∫U_y dnu,
    E_y⊂原 terminal good,
    rho_y(z)=[1-(k_z+alpha_y J_z)/a_y(z)]_+ on E_y,
    A_y(z)=1_good rho_y(z)J_z/(3Q_z).                    (LJ2)

a=0 或非原 target 资格时 A=0。capture⊂good 的原定位为 R128 proof.md RT5–RT6（约652–667）：RT5 是 p_y w_g>KQ 的绝对 bad 门，RT6 的 E=S_g∩{B=0,Delta>0}。这里只继承该定义，不继承旧稿后来修复的 nu≤beta 断言。

原 high、good 及后验为

    p_y e_g(y)≥2Kq,
    p_y w_g(y,v)≤KQ_v on target good,
    Pi_y,t(dz)=1_Zy,t(z) w_t(y,z)nu(dz)/e_y,t,
    e_y,t≥e_g(y),  0<w_g≤w_t≤1 on actual far.          (LJ3)

实际 K=1；保留 K 只追踪常数。写 kappa=K(1+gamma^(-n))/3；若 kappa≥1，互反域空。其余假设 kappa<1。原 reciprocal bad 集 R_y 保留原 bad 及反向基本 bad，因而

    kappa/w_g(y,u)<p_y/p_u<w_g(y,u)/kappa,
    1_Ry Pi_y,t≤(2K kappa)^(-1) p_u nu(du)/q.          (LJ4)

LJ4 只在原 bad 子域成立。它不更换 Z、不重归一 Pi、不赋予交换后点以原 high/history 资格。

## LJ2. 完整 fractional capture 与同 alpha 储备

在上述严格正核范围内定义

    chi_y(dz)=1_Ey(z) min(1,a_y(z)/k_z)nu(dz).

则逐点 k chi=U nu，0≤chi≤nu≤mu_hi。A>0 强制 E_y、a_y>k+alpha J，故该点 chi 的 nu 密度为1，从而 A nu≤chi。这里实际 A 包含 J/(3Q)≤1。

由同一个原 alpha，

    ∫k_z(mu_hi-chi_y)(dz)
      =D∫K0_z mu_hi(dz)-∫U_y dnu
      ≤alpha_y QJ.                                    (LJ5)

因此在 alpha QJ>0 的行，

    S_y(dz)=k_z(mu_hi-chi_y)(dz)/(alpha_y QJ),
    P_x(dz)=p_z nu_V(dz)/q                             (LJ6)

都是 subprobability，不补成概率。S 同时保留 mu_hi-nu 与 nu 中未捕获的部分，二者只领取 LJ5 一次预算。S 不是 h 的无权归一化，也不依赖 nu≤beta。

QJ=0 时严格正 J 给 nu=0。alpha=0 时 LJ5 及严格正 K0 给 mu_hi=chi；由于 chi 支持 good，而原 bad 与 good 不交，原 bad 的 nu 质量为零。故本稿交通在这些零支先定义为0，不形成0乘无穷。rho_v=0 的 target 也先取原被积式0，再在其余 active 槽定义后文权重。本稿无需扩展到 s=0；若仅讨论 capture 三接口，k=0,a>0,E 内可取 chi 密度1，但这不授予本稿 alpha=0 消 bad 的严格正核推论。

## LJ3. 原 LCA 选择与有限层来源估计

原森林最细尺度 d0=a/n，顶层深度

    J_tree=ceil(log_2(2G_n/d0)),
    G_n=O(a n log(n+2)),  N_tree=J_tree+1.              (LJ7)

这里沿用原实际维数范围及 G_n 常数。每个 top 是深度 J_tree 的半开 dyadic 树；所有层共同使用原平移，未新造森林。原出处及先后顺序已经 R189 grid_boundary_budget.md GB1 窄核；LCA 与初始 alive 的接缝是 R190 small_block_joint_budget.md SC1–SC3。

固定 y，对初始 alive 的 u∈R_y∩Z_ell(y)，令

    Q_yu=LCA_omega(y,u).

原支持保证二点位于同一 top 且不在同一最细 fallback cell；LCA 存在。对后来已删的 u，定义仍使用该初始 LCA，不重算树或停止块。Pi_t 的支持在 Z_ell 内。定义

    L_tree(y,u)=S_y(Q_yu)/P_x(Q_yu)                    (LJ8)

当分母正；分母零时取0，非该初始域亦取0。有限个原节点且 u 属于所选节点，P(Q)=0 的所有这些选择事件为 P-null，由 LJ4 也为原 bad 后验零集。分子≤1，正分母处比值有限；所有选择和比值可测。

关键是保留真实块质量而不取点态 inverse K0 上确界。对每一层 l，记 U_Q={u∈R_y∩Z_ell:Q_yu=Q}。它满足 U_Q⊂Q，且该层节点不交。因此

    ∫_{level(Q_yu)=l} L_tree(y,u) P_x(du)
      =Σ_(Q at l,P(Q)>0) S_y(Q)P_x(U_Q)/P_x(Q)
      ≤Σ_(Q at l)S_y(Q)≤1.

固定 y 实际每层至多一个相关祖先；上述写法也明确同层求和没有重复储备。按原 N_tree 层相加，再用 LJ4，得到

    ∫_Ry L_tree dP_x≤N_tree,
    ∫_Ry L_tree(y,u)Pi_y,t(du)
       ≤N_tree/(2K kappa).                            (LJ9)

这是无额外假设的原来源估计；显式的 N_tree 费用不可删。它允许 S、P、所选节点依 x,y,omega，甚至实际 target/time 的原参数；估计逐行完成，未把这些对象当成固定于 dx 的参考测度。

## LJ4. 原加权 companion 与实际来源付款

在 rho_v>0 的 active target 上定义

    F_tree(x,y,v,u)=w_g(y,v)^2 L_tree(y,u)/rho_y(v)^2. (LJ10)

它是对原正被积式的乘子，不更改 alpha、rho、Pi 或 score。令 H∈[0,1] 保留全部原剩余 pair 门，包含 reciprocal bad、good/capture、history、初始小块、近 outer-bad、tiny good、中央时钟、低 Fcal，以及 R190 晚并块 F(d,σ_u)>eta 等。依 u 的门始终在积分内，随后仅作正放大。定义

    C[F]=E Σ_(V,j)∫_Erec 1_{j(x)=j}dx
       ∫_high beta(dy)∫_actualfar dt/t
       ∬H [p_y^2 rho_v^2 J_v/(9Q_v^2)]
                          F Pi_y,t(dv)Pi_y,t(du).

则

    C[F_tree]≤N_tree log2/(36 kappa) Wnu.              (LJ11)

证明在同一个原行的 active 槽，先在实际被积式内消去 rho²，保持 good-v，然后用 LJ9：

    ∫H [p_y²rho_v²J_v/(9Q_v²)]F_tree Pi(du)
       ≤p_y²w_g(y,v)²J_v N_tree/(18K kappa Q_v²)
       ≤K N_tree J_v/(18 kappa).                      (LJ12)

没有将 alpha、K0、rho 的倒数分别取上确界。新树比值的 u 积分由同一 alpha 的 LJ5 和原有限层支付。接着原 high 给

    ∫_high beta(dy)∫J_v Pi_y,t(dv)
       ≤(J*nu_V)(x)∫_high beta(dy)/e_g(y)
       ≤(J*nu_V)(x)/(2Kq)∫p_y beta(dy)
       ≤(J*nu_V)(x)/(2K).                             (LJ13)

此处保留原 t 行至 high 估计；不声称从 beta 向 nu 换外槽。原 actual far 在 xi=c_jt/b∈[1/2,1] 与原可定义域的交集，dt/t=d xi/xi；域外及零 e 行取0。LJ12–13 后上界不依 t,j，才扩到该共同 xi 区间、收 log2 并用 Σ_j1_{j(x)=j}≤1。N_tree 是原森林统一深度，未另把 j 的个数乘入。最后同窗口固定 b 的 J 是概率核，

    ∫_Erec(J*nu_V)(x)dx≤∫_(R^n)(J*nu_V)(x)dx=||nu_V||.

于是得 LJ11。若原窗口有不同深度，原样保留 EΣ_V N_tree,V||nu_V||，或使用已证明的共同上界；若 b 或其他窗口重复，则按原总账分别付来源，不宣称重复窗口免费。

对预先给定 theta>0，只对此前未付的正交通使用 F_tree≥theta。原固定 J 能量为

    E_J≤n Wnu/(2K).

它含同一 Pi、同一原 score (k_t(y,v)-k_t(y,u))_+，不是静态 k=DK0。Cauchy 的两个因子保留同一正切片，LJ11 及一次 hard 帽16/3、一次外系数2Lambda 给

    Raw^+[H;F_tree≥theta]
      ≤(32Lambda/3)
        sqrt[n N_tree log2/(72K kappa theta)] Wnu
      ≤(32Lambda/3)
        sqrt[n N_tree log2/(72K kappa theta)] W_A.      (LJ14)

能量的精确旧出处为 R173 final_checkpoint/mass_energy_audit.md §2.1–2.2（约48–82行）的 E_pair,J；只继承其 n/(2K)Σ||nu|| 证明，不继承旧 Wbeta 尾句。来源修复采用 R181 common_parent_budget.md CP15–16 的 Wnu≤W_A。在同一原测度上，Cauchy 两因子具体为 sqrt(H 1_gate J_v)(score差)_+ 与 sqrt(H 1_gate)p_y A_y(v)/sqrt(J_v)，后者的平方积分恰由 LJ11/theta 控制。

所以固定 theta 时是 O(sqrt(n log(n+2))) 来源价。theta 若随 n 变小，完整代价 theta^(-1/2) 保留。没有接收误差、冻结误差、soft/scale 菜单，未动任何负信用。该结论直接作用于 R191 指定的原剩余域，不需先证明 near-saturation。

LJ14 是已证明的实际条件子支价格，不是把未知小矩列为假设：其全域加权矩 LJ11 已由原同 alpha 和原有限树无条件支付。但本稿未认证该门相对旧 Fcal 的 FULL 严格覆盖扩大，也不声称所有晚并块点均满足该门。旧点似然与此祖先平均没有自动逐点大小关系；应先扣旧已付域，再支付本门一次。

## LJ5. 低树权重剩余的实际捕获与位置约束

在 active pair、P_x(Q_yu)>0 且 F_tree<theta 时，原同一个 Q=Q_yu 满足

    S_y(Q)/P_x(Q)<theta rho_v²/w_g(y,v)²,

    D∫_Q K0_z(mu_hi-chi_y)(dz)
       <alpha_y QJ theta rho_v² P_x(Q)/w_g(y,v)².      (LJ15)

P_x(Q)=0 的节点已在 LJ3 证明为原 bad 后验零集；LJ15 不在该零集强行给出分子结论。这不是无权 h(Q) 的上界，也不由 tiny w_g 下的右端推得小质量。准确分解是

    D∫_Q K0_z mu_hi(dz)
       =D∫_Q K0_z chi_y(dz)+alpha_y QJ S_y(Q).        (LJ16)

因此大 h(Q) 仍可位于真实 captured-good 一侧，或者被实际 K0 衰减；不能从晚并块的无权祖先质量直接推出 F_tree 大。对 h 的应用必须保原 h(Q)=mu_hi(Q∩B)，不可将其偷换成 nu(Q)。

可进一步把 captured-good 一侧的位置具体化。固定当前实际 bad u，定义正 margin

    m_y(u)=log[p_y w_g(y,u)/(KQ_u)]>0,
    j_s=log[(1-s+s phi(1/2))/(s phi(1/2))],
    N_H(z)=#{i:|x_i-z_i|≤H/2},
    DeltaN_H(z,u)=N_H(z)-N_H(u),
    Lphi=2/(1-e^(-1)),
    B_yu(z)=(Lphi/L+18/b)||z-u||_1
             +j_s max(DeltaN_L(z,u),DeltaN_Lplus(z,u),0).

这里 j_s 是标量硬跳幅度，与原比例条带标签 j 无关；s=1 时 j_s=0。所有硬面使用原闭面约定。则 captured-good z 必须满足

    m_y(u)≤B_yu(z).                                   (LJ17)

证明：将每个标量 current 核的硬跳 j_s 去掉后，其对位置的 log-Lipschitz 常数≤Lphi/H；故三个分量 p、pplus、J 分别给上界 Lphi||z-u||_1/L 加其有符号硬面差（J 无硬跳）。Q_z/Q_u 是以三个在 u 点的原正核值为权的凸组合，得

    log(Q_z/Q_u)≤Lphi||z-u||_1/L
                +j_s max(DeltaN_L,DeltaN_Lplus,0).

同一原 y,g,j,b 的物理 w_g 对来源位置满足 log-Lipschitz 常数18/b，因而

    log[p_y w_g(y,z)/(KQ_z)]≥m_y(u)-B_yu(z).

good 使左侧≤0，得到 LJ17。没有将 u 的辅助权改成另一接收行，亦未用坐标独立性。上述物理 log-Lipschitz 工具及闭面保留是已审 R181 NB 与 R186 HG 的原工具。

令 T_yu={z:B_yu(z)<m_y(u)}。在严格 bad-stable 区 T 上 chi_y=0，所以对同一 P=Q_yu，

    D∫_(P∩B∩T_yu)K0_z mu_hi(dz)≤alpha_y QJ.          (LJ18)

若原 target A_y(v)>1-eta，则原同 alpha 强制

    k_v+alpha_y J_v<eta a_y(v).

于是 LJ18 还给同一 u,v,P 的必要关系

    D J_v∫_(P∩B∩T_yu)K0_z mu_hi(dz)
       <QJ[eta a_y(v)-k_v].                           (LJ19)

右侧在该 active 高 A 域正。LJ19 没有用 target 的尺度代替原 K0，也没有忽略原 alpha 项。

对任意 tau>0，原祖先无权质量有准确的进一步上界

    h(P)≤mu_hi(P∩B∩{K0<tau})+alpha_y QJ/(D tau)
          +mu_hi(P∩B∩{K0≥tau}∩T_yu^c).               (LJ20)

证明只把 P∩B 分成低 K0、较高 K0 的严格 bad-stable 区、其补集，并在第二项使用 LJ18。它不提供免费的 tau 选择或新的来源密度帽。

## LJ6. 当前已付范围和最早尚缺的积分

LJ11–14 是本稿新增实际加权估计与原 raw 回代；LJ15–20 是余域的几何接口，不另登记付款。原 R190 F(d,σ_u)>eta 给的大 h(LCA) 必要条件仍完整保留。在此晚并块域中，先付旧来源/接收支，再付 F_tree≥theta；其余保留 F_tree<theta 与所有原门。

该剩余域尚缺的是：在原 beta(dy)、Pi_y,t(dv)Pi_y,t(du)、实际 dx 与 history 权重下，支付 LJ20 的低 K0 质量及 T_yu^c 上的 captured-good/硬面质量，并把它同原 target 未来损失联系。T_yu^c 允许真实位移，也允许有符号 current 或 Lplus 硬面穿越；仅有其支持描述不能推导小的加权界面占用。chi 中未成为 A nu 的部分仍是实际非负 neutral capture，不能凭 A nu≤chi 反向支付它。

原 mu_hi、chi、S、P 及该界面全依原 x,y 和森林；本稿的可积结论来自先逐行 LJ9，再 LJ12–13 的 high/FIRST 消元和固定 J 的 dx 积分，未把这些来源当作固定于接收点的概率。Sol 的原祖先壳 prefix 聚合可进一步避免重复领取 LJ5，但不自动消去上述低 K0、neutral capture 或界面费用。本稿不据此声称一般 sqrt(n)n^{o(1)} 弱型已闭合。
