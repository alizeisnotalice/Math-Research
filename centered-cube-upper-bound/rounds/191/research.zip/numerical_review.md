# R191 normalized source-target overlap probe

The implemented quantity is the actual one-dimensional Hellinger integral

`F_s(lambda,d)=∫sqrt({[(1−s)h(x/lambda)+s phi(x/lambda)]/lambda} phi(x−d)) dx / sqrt(C(d))`,

with b=1 and xi=1. The initial block uses lambda=1. It was evaluated on the prescribed 6×6 grid at 20 dps, with only six selected values refined at 35 dps. A later constructive pressure extension adds eight specified points at 20 dps and refines only its highest and closest-to-one values at 35 dps. No further optimization, source-history search, variance surrogate, or dimension fit was performed.

## Kernels, seams, and numerical scope

The implementation uses the given E3 formulas for phi and E4 formulas for C. C(0)=1 and the two C branches agree at d=1. The source density has its actual lambda^-1 normalization and hard interval [−lambda/2,lambda/2]. All integrations split source hard/soft seams, source center 0, and target seams d−1/2,d,d+1/2. At s=0 the integral is restricted exactly to the source hard support; at s>0 it uses infinite endpoints, without presenting a finite tail cutoff as exact. The denominator remains the original b=1 C(d), not a separately optimized variance or scale.

These are genuine kernel integrals but not a construction of original current/good/bad/alpha/selector/FIRST/history or receiving measures. Working precision, residuals and agreement are empirical controls, **not directed interval error bounds or a uniform theorem**. Pure-hard s=0 is a kernel-boundary diagnostic. A grid maximum is not a global maximum.

## Initial fixed grid

The initial s values are 0,1/100,1/10,1/2,9/10,1 and d values 0,1/2,1,2,4,8. The 20-dps screen has 36 rows and 23 values above 1+1e-8. Selected 35-dps checks were the finite-grid maximum, the smallest observed excess, existing-grid neighbors of the maximum, a pure-hard centered control, and the s=1,d=0 equality control. Examples:

| s | d | F at 35 dps (rounded) |
|---|---:|---:|
| 1 | 8 | 6.3810459088288721 |
| 9/10 | 8 | 6.1234130372129868 |
| 1 | 4 | 4.2039097571629309 |
| 1/100 | 1 | 1.0985451308739007 |
| 0 | 0 | 0.7101189252676951 |
| 1 | 0 | 1 |

The selected 20/35-dps differences are at most 2.37e-21. Thus this grid does not support a strong uniform upper bound 1 for general positive s. The pure-hard grid values remain below 1, and at s≤1/10,d≤1/2 the evaluated values are also below 1; these are finite observations only. The task then moved to the constructive weaker strategy rather than expanding a search against the strong statement.

## Preserved initial block and constructive extension

The initial 36+6 block was preserved unchanged, including all numerical values and metadata. Its canonical JSON SHA256 is `28e8dfbf30c84c1a5a57a2ec4727805704a3497b49d4739e4fb9411b669c948d`. The added `pressure_extension` explicitly limits the inherited `L_equals_b=True` label to that initial block; the extension permits source lambda=1/2 or 1 and retains b=1,xi=1.

The six near-hard pressure inputs are lambda∈{1/2,1}, d∈{1,8,32}, and **soft weight** s=10^-6/(1+d), not softgap 1−s. Two controls are s=0,lambda=1/2,d=32 and s=1,lambda=1,d=32. All six small-soft-weight observations are below one:

| lambda | d | s | F at 20 dps (rounded) |
|---|---:|---|---:|
| 1/2 | 1 | 1/2000000 | 0.6717849819 |
| 1/2 | 8 | 1/9000000 | 0.6921582308 |
| 1/2 | 32 | 1/33000000 | 0.6939706753 |
| 1 | 1 | 1/2000000 | 0.9758782121 |
| 1 | 8 | 1/9000000 | 0.9894779144 |
| 1 | 32 | 1/33000000 | 0.9916123173 |

The compact pure-hard tail control gives F_0(1/2,32)≈0.6936961280569316. Only two extension points were refined:

- Highest: F_1(1,32)=14.6521783251265825463; F_1/sqrt(33)=2.55061685748291821774. Its 20/35-dps difference is about 2.01e-15.
- Closest to one: F_(1/33000000)(1,32)=0.991612317337734363667, with difference about 3.49e-19.

The extension precision-control threshold is 1e-14. In particular, 20-dps working precision is not claimed to give 20 accurate digits for the far-tail integral. These data are compatible with pursuing a uniform hard-source gap and a weaker soft-source sqrt(1+d) envelope, but they neither prove such statements nor identify their best constants. No rho or C is fitted or declared a proof constant. No comparison has been proved between these s values and the theoretical threshold c0/(1+R_n): c0 there is an unspecified theorem constant and may be much smaller. These are directional pressure tests, not certified members of that theoretical paid band, and they do not establish the parent's full sbar band or spatial budget.

## Runtime and reproducibility

The extension-only production computation took 1.137 seconds on this machine. The final bounded extension replay took 1.123 seconds. These are actual observed elapsed times; they are printed to stdout and omitted from JSON so deterministic numeric output can be compared. The initial-grid run did not instrument elapsed time, and no runtime for it is invented. The old 36-point grid was not rerun during the extension.

The script uses standard import with existing mpmath 1.3.0, supplied externally:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 normalized_overlap_probe.py --reuse-existing normalized_overlap_probe.json --output /tmp/replayed_overlap.json
```

This bounded mode extracts the frozen initial block, checks its stored canonical hash when present, and recomputes only the eight new points and two refinements. Without `--reuse-existing`, a full-from-scratch mode is available for the initial grid plus extension; that mode was not needlessly rerun during this extension task. The actual initial computation already executed all 36+6 initial evaluations.

The final isolated replay in `/tmp/r191_overlap_review/` copied only the script, adjacent task contract and frozen JSON input. It used `--reuse-existing frozen_input.json --output replayed_output.json`; the complete final JSON bytes matched the production file, and removing the extension recovered the original initial JSON object exactly. The dependency version/source hash and filename-only task-contract hash are recorded. No absolute runtime path or nondeterministic timing enters the JSON; no software was installed.

The finite probe and its requested extension are complete. The authored weak bound and its general source/receiver/selector costs remain mathematical tasks outside this numerical artifact.
