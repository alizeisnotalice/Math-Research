# R191：终端祖先壳、同一 reserve 的一次聚合与真实 target 损失

本稿给出一个联合 source/层级恒等式：把所有 terminal-surviving bad 来源的祖先质量超额，写成同一原 target 槽、同一 α 的一次 reserve 和三个显式正缺口。它不逐父块重复领取 reserve，不产生树深或 `1/α` 费用。缺口尚未取得全局价格，因此不登记一般 root 付款，也不重复 R190 的指数体积覆盖。

## TT1．固定原行及必须保留的两个来源版本

固定原 `(ω,V,x,j,y)` 完整行，初始 ell、终端 g，`ell≤g`、`e=e_g(y)>0`。沿 R190 SC/CC 使用原

\[
 Z_t(y)=D_V(y)\cap[T_0(y)\setminus A_{j,t}(y)],\qquad
 H_j(t)=q t^n\max\{1,\sqrt n c_{j+1}^n,\sqrt n(t/b)^n\}.
\]

原 `h(P)=μ_hi(P∩B)`、原半开树、出生 B 和全部 current/FIRST 参数保持。固定行后 h、森林、α、capture、good、ρ、Q、target A 均不随辅助 t 改变。q>0、D≥1、`K0=P_{s,Hhat}` 是同一 x 上合法 future，故 `K0 μ_hi≤q`。ν 指本行原 ν_V，只有 `ν≤μ_hi`，不假定 `ν≤β`，也不将全 ν 当成 h。

原 target 权及未来损失为

\[
 A(v)=1_{\rm good}(v)\rho_y(v){J_v\over3Q_v},\qquad
 0\le A\le1,\quad\operatorname{supp} A\subset Z_g(y),
\]
\[
 D_A=\int A(v)[w_\ell(y,v)-w_g(y,v)]\,d\nu(v).       \tag{TT1}
\]

所有 pair-dependent history 和 low-Fcal 等门仍在原交通中，不并入一个 u-dependent target A。本文恒等式使用原 terminal-good A；可保留已经合法的时间固定单 target 限制，但不重新计算 α 或捕获。

原 bad 集 `R_y⊂Z_ell(y)` 可包含后来删除的来源。以下取任意时间固定子集

\[
 R_*\subset R_y\cap Z_g(y),\qquad
 m(du)={1_{R_*}(u)w_\ell(y,u)\over e}\nu(du),\qquad b=\|m\|.
                                                                  \tag{TT2}
\]

可在 R_* 中保留所需 large-r 和此前原限制。它只覆盖 terminal-surviving late bad；`R_y\setminus Z_g` 的原交通仍按 R190 逐来源时钟/完整删除处理，未被丢弃。实际 reciprocal/high/current 容量给

\[
 b\le{\nu(R_*)\over e}
 \le {q\over\kappa p_y e}\le{1\over2K\kappa}.        \tag{TT3}
\]

m 是保留原初始权及原终端分母的行内有限测度，未必为概率，也不是不依 x 的固定参考 Γ。b=0 时下文所有联合量均为0，先作该零支处理。

## TT2．同一祖先链及真实三点顺序

令 y 路径的原节点为 `Q_0⊂Q_1⊂…⊂Q_J=T_0(y)`，Q_0 是原最细格。令

\[
 E_i=Q_i\setminus Q_{i-1}\quad(1\le i\le J),\qquad
 A_g:=A_{j,g}(y)=Q_k.
\]

这些 E_i 互不交，不是重新选择的来源分割。对原初始在场 z，唯一 `P_z=LCA(y,z)=Q_{i_z}` 存在，且 z∈E_{i_z}。R190 精确 coalescence 身份给

\[
 z\in Z_g(y)\ \Longleftrightarrow\ H_j(g)<h(P_z),
 \quad\text{在原 }D_V(y)\text{及初始资格内}.          \tag{TT4}
\]

因此 R_* 中的 u 及 A>0 的 target v 都有 `i_u,i_v>k`，P_u、P_v 是同一路径的可比较节点。如果 `i_u<i_v`，则 u 与 y 同处 P_v 的 y 孩子、v 在该孩子外，所以 `LCA(u,v)=P_v`；反向严格不等时相应为 P_u。若 `i_u=i_v`，两点可能位于同一个非 y 孩子，不能断言它们自己的 LCA 就等于该节点。本文只使用准确条件

\[
 v\in P_u\setminus A_g\ \Longleftrightarrow\ i_v\le i_u
 \qquad(v\in Z_g).                                 \tag{TT5}
\]

终端块若为 light，有 `h(A_g)≤H_j(g)`。若无 light 而为 heavy fallback，A_g=Q_0，其质量可能大于终端阈值。下文始终保留实际 `h(A_g)`；如需统一写法，可用
`h(A_g)≤H_j(g)+[h(A_g)−H_j(g)]_+`，正余量只可能来自 heavy fallback。不能忽略它。

## TT3．所有 bad 父块共享一个有界前缀权

定义原联合层级权

\[
 \tau(z)=\int1_{P_u\setminus A_g}(z)\,m(du).
\]

在 terminal 壳 `E_i,i>k` 上，它恰为 bad 的同一路径尾量：

\[
 \tau|_{E_i}=m\{u:i_u\ge i\},\qquad0\le\tau\le b.   \tag{TT6}
\]

固定行上的 Tonelli 给出真正的联合质量身份

\[
 X:=\int[h(P_u)-h(A_g)]\,m(du)
       =\int\tau\,d\mathfrak h,
 \qquad d\mathfrak h=1_B\,d\mu_{\rm hi}.             \tag{TT7}
\]

没有把 `h(P_u)` 逐个当成独立来源收费。TT6 是把所有嵌套父块合并成一次权 τ 的关键；若分别对每个父块使用完整 reserve 再求和，将恢复不合法的层数/重复来源费用。

令 `S_y=Z_g(y)∩B`。由于 τ 支持于 `T_0(y)\A_g`，其余 h 质量准确是原距离/来源域排除项

\[
 O:=\int_{D_V(y)^c}\tau\,d\mathfrak h
   =\int h((P_u\setminus A_g)\setminus D_V(y))\,m(du),
 \qquad X=O+\int_{S_y}\tau\,d\mu_{\rm hi}.          \tag{TT8}
\]

D_V(y) 包含 V、原 l1 与 linfty 距离帽；P_u 不一定包含于 V 或 D_V(y)。O 不能自动置零。这里也没有将原 h 限制为当前 ν 或其存活部分。

## TT4．fractional capture 接口与同一个 α

沿本轮 Astra 的 fractional-capture 接口，写

\[
 a(z)=T\Delta_y(z),\quad k(z)=DK_0(x-z),\quad
 U=1_{\mathcal E}\min(a,k),\quad
 \alpha Q_J=Dq-\int U\,d\nu,\quad Q_J=\int J\,d\nu.
\]

E 是原 capture 集，不是来源壳 E_i。为避免混淆下文记它为 `mathcal E`。取

\[
 \chi(dz)=c_{\rm cap}(z)\nu(dz),\qquad
 c_{\rm cap}=1_{\mathcal E}\min(1,a/k).
\]

在 k=0,a>0 且属于 capture 时取该密度1，在 a=k=0 时取0；此约定满足 `kχ=U`。实际 strictsoft 时 K0>0，无此硬端点歧义。原 A>0（即有效 terminal-good target）必有 `a>k+αJ` 且属于 capture，因此

\[
 0\le A\nu\le\chi\le\nu\le\mu_{\rm hi},\qquad
 \int k\,d(\mu_{\rm hi}-\chi)
       =D K_0\mu_{\rm hi}-\int U\,d\nu\le\alpha Q_J. \tag{TT9}
\]

TT9 在此列出是聚合所需的精确接口；本轮另一稿负责其局部 capture 几何。它同时包含缺失来源、非 capture 和部分 capture 的余额，不可将这几项各自再领一份 αQ_J。`χ−Aν` 为正，但不等于原 bad 测度；尤其 capture 内 ρ=0、J/(3Q) 小及其他合法 target 限制仍可有质量。

若 Q_J=0，则原正 e_g 行在严格正 J 下不存在，联合交通先置零。α=0 时 TT9 的非负积分为0，后文直接使用这一事实，始终不除 α。

## TT5．归一到初始阈值的一次 reserve 容量

置 `H_0=H_j(ell)>0`，定义实际归一储备利用率

\[
 \eta_\alpha={\alpha Q_J\over Dq}\in[0,1].
\]

上界只用 U≥0。任选以下一个原物理权：

\[
 f_{\rm surv}(z)=\min\{w_g(y,z),H_0K_0(x-z)/q\},\qquad
 f_{\rm loss}(z)=\min\{w_\ell(y,z)-w_g(y,z),H_0K_0(x-z)/q\}.
                                                                  \tag{TT10}
\]

均满足 `0≤f≤1` 及 `f≤H_0 k/(Dq)`。由 τ≤b 及 TT9，所有父块的共同缺源项一次满足

\[
 \int_{S_y}\tau f\,d(\mu_{\rm hi}-\chi)
                 \le bH_0\eta_\alpha\le bH_0.       \tag{TT11}
\]

该不等式没有层数或 `1/α`，并保留原同一 k、α、q；不能用一个不同合法 future 核替代 K0 来取得同一 reserve。归一因子 `H_0/q` 有体积量纲，f 是无量纲权。没有把 K0 或 w 当成来源概率。

定义非负、可直接核算的实际量

\[
\begin{split}
 \operatorname{Att}_f&=\int_{S_y}\tau(1-f)\,d\mu_{\rm hi},\\
 T_f&=\int_{S_y}\tau f A\,d\nu,\\
 N_f&=\int_{S_y}\tau f\,d(\chi-A\nu),\\
 L_f&=bH_0\eta_\alpha
          -\int_{S_y}\tau f\,d(\mu_{\rm hi}-\chi)\ge0.
\end{split}
\]

则 TT7–11 给出本稿主恒等式

\[
 \boxed{X=O+\operatorname{Att}_f+T_f+N_f
                     +bH_0\eta_\alpha-L_f.}         \tag{TT12}
\]

证明只需在 TT8 的 S_y 项中先拆 `1=(1−f)+f`，再拆固定正测度
`μ_hi=Aν+(χ−Aν)+(μ_hi−χ)`；最后代入 L_f。所有正项均属于同一原行，有限 source mass 和 τ≤b 保证有限，未出现无穷量相减。L_f 是此次 reserve 的未使用部分，不是原 signed suffix 或已消费的负信用。

## TT6．真实 surviving/未来损失 target 槽及 large-r 压力

TT5 的 target 项可以保持完整三点来源关系：

\[
 T_f=\int m(du)\int_{S_y\cap(P_u\setminus A_g)}f(v)A(v)\,d\nu(v).
                                                                  \tag{TT13}
\]

TT5 并未把这种相关联合来源换成独立槽。对 survival 版本，`f≤w_g`，所以

\[
 T_{\rm surv}\le b e\,\Pi_g A.
\]

更明确地，正 wg 域可将 TT13 的内槽写成
`e A(v)[f(v)/w_g(y,v)]Π_g(dv)`，仍保留 `i_v≤i_u` 指示。对 loss 版本，`f≤w_ell−w_g`，得到

\[
 T_{\rm loss}\le bD_A,\qquad
 X\le O+\operatorname{Att}_{\rm loss}+N_{\rm loss}
                              +bD_A+bH_0\eta_\alpha. \tag{TT14}
\]

这些是原 terminal posterior 或原 same-alpha future loss 的真实槽；它们不自动等于原时间积分中两份 Π_t 的正 score 交通。

例如取 `R_*⊂{r_y(u)>r_0}∩Z_g`、`r_y(u)=h(P_u)/H_0`。b>0 时

\[
 X>b[r_0H_0-h(A_g)],
\]
\[
 b[r_0H_0-h(A_g)-D_A-H_0\eta_\alpha]
       <O+\operatorname{Att}_{\rm loss}+N_{\rm loss}. \tag{TT15}
\]

这是真正的联合质量压力：大量 late bad 祖先超额不能同时逃过原 target 损失、同一 reserve 和三项明确物理缺陷。不是无条件声称 D_A 大。fallback 仍使用实际 h(A_g)。若要与 R190 的 `d_y=D_A/e_g` 直接比较，还须保留 `D_A/H_0=(e_g/H_0)d_y`；本稿没有免费消掉原 normalizer 与初始阈值之比。

## TT7．准确补集、来源复用及尚未支付的接口

TT12 避免了最直接的非法重复：每个 P_u 领完整 αQ_J 后对父层相加。本稿先合并成 τ≤b，reserve 在整行只用一次，并且没有逆 K0、逆 α 或逐点全空间上确界。

然而 O、Att 和 N 都尚有实际含义与未付费用。O 包含当前 V/距离集外的原 h；Att 保留真实 K0 和 overlap/未来损失较小所造成的衰减；N 保留 fractional capture 中没有进入实际 A 的 neutral 质量。没有原继承定理使这些项同时小。晚存活 bad 与实际 target 的反向祖先顺序 `i_v>i_u` 也没有因 TT13 而消失，不能把该正交通列为已经付款。后来删除的 bad 补集仍归原完整时钟处理；特别不能将 TT15 对 surviving 子集的压力冒充所有 large-r 来源的结论。

所有式子目前是固定真实 `(ω,V,x,j,y)` 的 source 恒等式/容量约束。若乘原 `p_yβ_V(dy)dx` 回代，β 与 ν 仅共同父支配，所有 receiver 依赖、窗口和来源复用仍保留；行内的 `bH_0η_α` 并不因此自动成为全局线性 W_A 价格。本文未构造不依 x 的新参考或重选树，也不将未知物理缺陷改名为已付矩门。

本轮取得的新接口是 TT12–15 的一次 reserve 祖先聚合和真实 target-loss 连接。到一般 `ε receiver+√n polylog source` 仍缺上述三项或其与原正交通的共同付款。到此停止本稿范围，不重复 HP 的指数体积价，不宣称一般目标闭合。
