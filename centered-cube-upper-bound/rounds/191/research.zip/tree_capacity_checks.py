#!/usr/bin/env python3
"""Exact finite LCA likelihood capacity checks, not an original-history certificate."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
HERE=Path(__file__).resolve().parent
Z=F(0)
def sm(xs):return sum(xs,Z)
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 return x

def uniform(N,mass=F(1)):return [F(mass)/N]*N
def point(N,i,mass=F(1)):return [F(mass) if j==i else Z for j in range(N)]
def triangular(N):return [F(i+1,N*(N+1)//2) for i in range(N)]
def check(name,stage,J,anchor,P,S,bad):
 N=2**J;P,S=list(map(F,P)),list(map(F,S));bad=sorted(set(bad));assert len(P)==len(S)==N and 0<=anchor<N and all(0<=u<N for u in bad)
 assert all(x>=0 for x in P+S) and sm(P)<=1 and sm(S)<=1
 def lca_xor(u):return J-(anchor^u).bit_length()
 def lca_prefix(u):
  a,b=format(anchor,'0'+str(J)+'b'),format(u,'0'+str(J)+'b');ell=0
  for x,y in zip(a,b):
   if x!=y:break
   ell+=1
  return ell
 groups={ell:[] for ell in range(J+1)};leaf_rows=[];direct=Z
 for u in bad:
  ell=lca_xor(u);assert ell==lca_prefix(u);prefix=anchor>>(J-ell);lo=prefix*2**(J-ell);hi=(prefix+1)*2**(J-ell);assert lo<=anchor<hi and lo<=u<hi
  if ell<J:assert anchor>>(J-ell-1)!=u>>(J-ell-1)
  else:assert u==anchor
  pnode=sm(P[lo:hi]);snode=sm(S[lo:hi]);likelihood=snode/pnode if pnode>0 else None
  if pnode==0:assert P[u]==0;term=Z
  else:term=P[u]*likelihood
  direct+=term;groups[ell].append(u);leaf_rows.append(dict(u=u,lca_depth=ell,node_leaf_interval=[lo,hi],P_leaf=P[u],P_node=pnode,S_node=snode,ell=likelihood,term=term))
 layers=[];grouped=budget=Z
 for ell in range(J+1):
  prefix=anchor>>(J-ell);lo=prefix*2**(J-ell);hi=(prefix+1)*2**(J-ell);pnode=sm(P[lo:hi]);snode=sm(S[lo:hi]);pshell=sm(P[u] for u in groups[ell]);assert pshell<=pnode
  if pnode==0:assert pshell==0;term=Z;ratio=None
  else:ratio=pshell/pnode;term=ratio*snode
  assert term<=snode
  grouped+=term
  if groups[ell]:budget+=snode
  layers.append(dict(lca_depth=ell,node_leaf_interval=[lo,hi],bad_leaves=groups[ell],P_bad_shell=pshell,P_node=pnode,S_node=snode,shell_fraction=ratio,integral_term=term,layer_budget=snode,active=bool(groups[ell]),zero_P_dispatched=pnode==0))
 massP,massS=sm(P),sm(S);checks=dict(independent_LCA=True,leaf_grouped_agree=direct==grouped,all_bad_assigned_once=sorted(u for g in groups.values() for u in g)==bad,layer_payment=all(r['integral_term']<=r['layer_budget'] for r in layers),retained_active_layer_budget=direct<=budget,subprob_layer_count=budget<=(J+1)*massS<=J+1)
 assert all(checks.values())
 return dict(name=name,stage=stage,depth_J=J,anchor=anchor,P=P,S=S,bad=bad,mass_P=massP,mass_S=massS,P_dominated_by_S=all(p<=s for p,s in zip(P,S)),S_dominated_by_P=all(s<=p for p,s in zip(P,S)),leaf_rows=leaf_rows,layers=layers,integral=direct,active_layer_S_budget=budget,full_layer_mass_bound=(J+1)*massS,J_plus_one=J+1,exceeds_free_one=direct>1,checks=checks,scope='Finite dyadic leaf likelihood algebra, no normalization of subprobabilities and no original FULL/tree-history payment claim')

def run():
 rows=[]
 rows.append(check('small_all','initial',1,0,uniform(2),point(2,0),range(2)))
 rows.append(check('small_bad_excludes_anchor','initial',2,1,uniform(4),point(4,1),[0,2,3]))
 rows.append(check('reserve_reused_three_levels','initial',3,3,uniform(8),point(8,3),[u for u in range(8) if u!=3]))
 rows.append(check('zero_P_nodes','stress',3,7,point(8,0),point(8,7),[6,7]))
 rows.append(check('P_source_missing','stress',3,4,[Z]*8,point(8,4),range(8)))
 rows.append(check('S_source_missing','stress',3,2,uniform(8),[Z]*8,range(8)))
 rows.append(check('underfilled_subprobabilities','stress',2,1,uniform(4,F(1,3)),point(4,1,F(2,5)),range(4)))
 sparse=[F(1,6) if u%3==0 else Z for u in range(16)]
 rows.append(check('sparse_P_concentrated_S','stress',4,5,sparse,point(16,5),[u for u in range(12) if u!=5]))
 for J in range(2,9):
  N=2**J;anchor=(N-1)//3 if J%2==0 else N-1
  P=uniform(N) if J%2==0 else triangular(N);S=point(N,anchor,F(2,3));S[(anchor+N//2)%N]+=F(1,3)
  if J==8:P=uniform(N);S=point(N,anchor);bad=[u for u in range(N) if u!=anchor];mode='all_except_anchor'
  elif J%3==0:bad=[u for u in range(N) if 0<(u^anchor)<N//2];mode='anchor_half_excludes_anchor'
  elif J%3==1:bad=[u for u in range(3*N//4) if u!=anchor];mode='index_truncation'
  else:bad=[u for u in range(N) if u!=anchor and u%2==0];mode='alternating_leaf_truncation'
  r=check('expanded_depth_'+str(J),'expanded',J,anchor,P,S,bad);r['bad_truncation']=mode;rows.append(r)
 assert rows[2]['integral']==F(3,2)>1
 assert rows[-1]['integral']==4>1 and rows[-1]['mass_S']==1 and not rows[-1]['P_dominated_by_S'] and not rows[-1]['S_dominated_by_P']
 return enc(dict(schema='r191_tree_capacity_v1',arithmetic='fractions.Fraction; finite leaf enumeration only',cases=rows,summary=dict(cases=len(rows),initial_cases=3,stress_cases=5,expanded_cases=7,expanded_depths=list(range(2,9)),maximum_leaf_count=256,all_exact_pass=True,reserve_reuse_example=dict(depth=8,integral=F(4),mass_S=F(1),J_plus_one=9)),limitations=['LCA refers to the finite prescribed dyadic tree and fixed anchor; no original forest/history or FULL qualification is certified','P and S remain unnormalized subprobabilities without a domination assumption','ell is undefined on P(Q)=0; such nodes have zero P shell mass and are dispatched before division','The same S reserve may be counted at multiple ancestor levels; no layer count is dropped','This checks the rational payment interface, not the general lemma or a dimension-order fit']))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'tree_capacity_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
