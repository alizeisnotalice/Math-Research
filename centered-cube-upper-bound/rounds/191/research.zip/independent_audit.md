# R191 独立前筛检查点

只写本文件，不Git/spawn/数值/PDF/他人编辑。首次读取时task_contract.md尚未落盘；先按主代理准确命题独立筛，未读任何R191作者稿。一般剩余目标沿R190，未闭合；常数改善本身不计一般root付款。

## 1. 原terminal-good质量界

固定同一合法原窗口与有效high行。q>0、K>0，原high给p_y e_g≥2Kq，故p_y,e_g均正。保留原terminal target

    A_y(v)=1_good(v)ρ_y(v)J_v/(3Q_v),
    supp A_y⊂Z_g, 0≤A_y≤1,
    G_g=∫A_y(v)w_g(y,v)ν_V(dv)。

good门是同一p_y w_g≤KQ_v，因此逐target

    p_y A_y(v)w_g(y,v)≤(K/3)1_good(v)ρ_y(v)J_v。

积分并定义原未归一捕获份额

    θ_y=(1/q)∫1_good(v)ρ_y(v)J_vν_V(dv)

得到p_yG_g≤Kqθ_y/3。原ρ∈[0,1]及同一合法future J的FIRST Jν_V≤q给0≤θ_y≤1。再除原high的正界，得到准确强版

    v_y=G_g/e_g≤θ_y/6≤1/6。

两处K/q/p_y归一完全相消，没有遗漏3或2。该界不使用ν≤β，不重选α/来源，不假输入独立。θ_y不是概率归一后的新posterior，也不能视为与receiver独立的数。

## 2. 门、端点与后续使用限制

若A再乘固定终端单target门，可在θ内保同一门得到同样强界。pair-u依赖low-F、history等仍留原H，不能直接并入一个与u无关G_g。必须保持原terminal good与Z_g支持；不能用另一时刻good或未限制source质量代替。q0/无high/eg0等原零行先处理，不除0。实际有限来源使G_g及Jν有限。

Jν≤q在本轮是明确的同window合法J-FIRST资格；仅有current核容量并不能自动推出它。若改核、改窗或按source各选J，须重新核容量及菜单费用。真实dx积分中θ_y可变，其付款需原high列与固定J质量归一，不能以θ≤1就称获得新来源总价。

R190的G_g≤e_g可据此改成G_g/e_g≤θ/6，改善逐u未来亏损端点。但要形成实际J-source尾付款，仍须说明同一A/α、sourcewise deadline、列归一、真实Lebesgue及窗口/j费用。当前只认证上述终端质量界，等待准确联合命题再审。

## 3. 合同补核与capture实定义的窄核

合同落盘后已读，保持本轮晚合并/大祖先质量实际剩余及全部原费用。为回答作者资格问题，只窄读R128冻结proof.md RT5–6（约652–667）与R170 final_checkpoint/task_contract.md:9：RT6 E=S_g∩{B=0,∆>0}，RT5 B=bad绝对门；后者明确U=1_good,∆>0 min(T∆,DK0)。因此capture E⊂物理good，且原terminal A>0时a>k+αJ≥k、U=k。未继承R170旧ν≤β句，该来源排序已被后轮修复。

定义k=DK0、a=T∆。严格soft的k>0处χ=(U/k)ν≤ν≤μhi，原αQJ=Dq−∫k dχ，FIRST给

    ∫k d(μhi−χ)≤αQJ。

任意集合可正限制且无需除α，safe-set上χ0时控制的是实际K0加权μhi。若扩到hard零核，k0,a>0,E处χdensity取1，其余k0取0；可保χ≤ν、kχ=U及Aν≤χ。k0统一取χ0则不能声称最后一条，作者已被提示。α0分支直接非负储备差为0，不除α。

作者same-row物理separator先筛通过：Q三个核去同soft hard跳后log-Lip均≤Lφ/L，Q比为同u三个核值的非负凸组合。配合logwg的18/b-Lip，任意bad u、good z必有

    log[p_y wg(y,u)/(KQ_u)]
      ≤(Lφ/L+18/b)||z−u||1
        +j_s max(N_L(z)−N_L(u),N_Lplus(z)−N_Lplus(u),0)。

反向严格safe域无χ；j_s有限须s>0，hard端点不能把∞硬跳当有限误差。源点门、sameα、K0均原样，必要分离非root付款。

## 4. 终端壳prefix与单次储备：先筛

仅对terminal-surviving bad u取m=1_R w_ellν/e_g、b=||m||，deletedbad另留。其LCA P_u包含A_g，τ(z)=∫1_{z∈P_u\A_g}m(du)≤b；同y树壳上τ等于后缀m质量。h=μhi|B、S=Z_g∩B，按outside D_y和S准确拆祖先差。

令F_c=min(θ,c k)，θ=w_g或δw，χ按§3三接口。单次储备∫SτF_c d(μhi−χ)≤cbαQJ；目标项TA=∫SτF_c Aν在θ=δw时≤bD_A。余χ−Aν非负但未付。取c=H0/(Dq)、ηα=αQJ/(Dq)∈[0,1]，令O为outside D_y壳质量、Att=∫Sτ(1−F_c)dh、Neutral=∫SτF_c(dχ−Aν)、Slack=bH0ηα−∫SτF_c d(μhi−χ)≥0，则

    X=∫[h(P_u)−h(A_g)]m(du)
      =O+Att+TA+Neutral+bH0ηα−Slack。

这是精确有限质量代数，无层数或1/α。b0整joint0；大r的严格X>b(r0H0−h(A_g))仅b>0使用。fallback不能h(A_g)换H_g。outside、attenuation及neutral均无全局付款，不能由身份本身报root。

## 5. 新空间重叠路线：先独筛，未读父证明

父准确F0/F1候选在所述范围数学可行，具体数值ρ未认证。F0(λ,d)逐点<1由C≥长度λ窗φ积分及严格CS；λ∈[1/2,1]、d有限的连续紧域给严格上界。φ尾的均匀有界平移渐近给d→∞一致极限

    λ^(−1/2)4sinh(λ/4)/sqrt(2sinh(1/2))。

λ=1的平方为4tanh(1/4)<1；λ区间整体极限也严格小于1，因此可紧化得到某绝对ρ<1。需父正文给出统一尾/连续性细节，有限扫描不替证明。

φ≤Cψ、C≥cψ，ψ=e^(−|r|)/(1+|r|)，可给F1≤C'√(1+d)，常数对λ∈[1/2,1]一致：中段beta积分≤π，两个外段各≤1。原target v∈Z_t⊂D_y才有d_i≤5log n+1/2；不能换成另一对源点的距离帽。ξ_g≤1及C≤1给w_g≥∏C。固定h+sbarφ先点态支配全部adaptive s≤sbar，不付soft菜单；L^(n/2)G_L单调Stieltjes包络收1+(n/2)log2。若解析选sbar=c/(1+log n)足够小，使ρ+√sbar C'√(1+R_n)≤ρ'<1，则R186固定Γ+及good给整个该参数带

    Raw≤(32Λ/3)√(K/3)L_n[1+(n/2)log2](ρ')^n W_A。

Γ+必须确为原固定score参考，保真实j/time总质量L_n及原窗口费用；之后指数吸收为C√n常数可行。当前只先筛接口，不把它当父未成稿的定理通过；中间s补集仍开，非原任意输入闭合。

## 6. terminal树与父空间稿全文后审

已全文读terminal_tree_geometry.md，TT1–15数学通过。TT4唯一必需措辞已修为“A>0有效terminal-good target”才用capture资格，最终cb77e…版窄读通过；不能将任意E外旧ρ余权也自动纳入capture。终端survivor范围、同层壳顺序、τ≤b、hard k0延拓、单次储备、fallback h(A_g)和e/H0费用均准确。TT12身份与TT15压力未支付三物理缺陷，后者只b>0用严格不等式。

已全文读normalized_overlap_geometry.md (1)–(6)，通过。w/ψ宽松上下界、φ与C常数l/U/c_C正确；F1中段beta及外尾积分足额。F0用w尾的一致平移渐近给φ系数cφ、C系数cφ²和正确λ一致极限，结合有限紧域严格CS，确实构造存在性绝对ρ<1，不依数值扫描。ρ的数值及最优gap未认证。固定fbar先去adaptive s，再Stieltjes真实收scale费，硬面跳亦在正测度内；(6)Γ+引用完整L_n原j/time质量，无Pi_g固定化、无inverse overlap遗漏。n³(ρ')^n由sup n^(5/2)(ρ')^n有限吸收到√n方向正确。该小soft参数带对任意原输入成立，中间s补集仍未付。

旧覆盖只窄索引R178冻结low_overflow_joint_geometry.md LG1/LG18–20：η_old=d/[4log(4e·36/d)]，d=−log[(1−2^(−34))^(1/4)]；原s≤η_old/4有source根价加B0 n exp(−a0n)receiver余项，a0=(log2−1/4)η_old，后者另需LG20维数下界才≤ε。当前稿明确不证明相对全部旧支有非空FULL差集，范围准确，不将新的c0/(1+log n)自动称严格覆盖扩大。

## 7. 新LCA储备/current比率付款：先筛

Astra准确候选先独推，未读其新完整稿。αQJ>0时S_y=k(μhi−χ)/(αQJ)是原全μhi上的subprob，P_x=pν/q亦subprob。原bad初始u的Q_u=LCA(y,u)，定义l_tree(u)=S_y(Q_u)/P_x(Q_u)，P(Q)=0取0。按原每一层，赋给该节点的U_Q⊂Q，故ratio×P(U_Q)≤S(Q)；零P节点无P质量。有限原FULL深度N=Jtree+1给∫bad l_tree dP≤N。Π_rec≤P/(2Kκ)，原companion乘w_g(v)^2 l_tree(u)/ρ_v²时在activeρ>0先消ρ²，good及high列依次给

    C_tree≤N log2/(36κ)Wν,
    Raw_{Ftree≥θ}≤(32Λ/3)√[nNlog2/(72Kκθ)]Wν。

N是实际原FULL统一深度或显式sup，不能使用另ξ森林；不同窗口仍按源总账。此为有价权重门而非免费Carleson。α0时“bad质量0”仅在strictsoft k>0有依据，hard k0坏源未必零；作者已被提示可定义该weight0并保留补集，或明限s>0。ρ0/QJ0及非法行先零，不能构造0∞。

## 8. 当前有限重叠代码静态范围

已读normalized_overlap_probe.py/json标签及numerical_review.md，未执行。E3 φ、E4 C两段和λ^(-1) source归一正确；source/target seams与hard compact/soft∞积分域保留。36初始+6选点精化与追加8压力+2精化属于有限核诊断；40位等更高精度没有被该脚本虚构。实际20/35dps差只经验控制、非interval；tiny s=10^-6/(1+d)没有证明落入未知解析c0门，notes已明确。依赖/合同哈希可移植，runtime不入JSON。没有原FULL/source/α/selector/receiving实例，也未用有限最大值认证ρ或一般raw。

## 9. LCA权重完整付款与能量旧出处后审

已全文读late_joint_geometry.md LJ1–20及最终LJ14引用补充（2db247…），通过。该稿明限原strictsoft s>1−2^(−1/n)>0，因而α0消bad可用，不扩到hard k0；TT的零核延拓不被误当此结论。LJ3保P(Q)0守卫，LJ15也只在P(Q)>0作分子推论，零P原bad后验集合不被强推S(Q)=0。LJ7原G_n、LJ13共同ξ窗/uniquej/固定b的实际dx费用完整。LJ15–20低K0/captured-good及signed硬面接口仍未付。

为应父要求，窄读R173冻结mass_energy_audit.md §2.1–2.2（约48–82行）及R181 common_parent_budget.md CP15–16：能量是J挂在good源v的D_+²，D_+=(score_v−score_u)+，准确价nWν/(2K)≤nW_A/(2K)。旧R173末句Wβ不继承。原能量证明先在eligible时刻用e_t≥e_g去分母，再扩未归一w_t积分≤n；不扩归一Π到不合法行。

同原正测度上Cauchy精确取f=√(H1gate J_v)D_+、g=√(H1gate)p_y A_v/√J_v，能量因子≤E_pair,J，第二因子≤C[Ftree]/θ，无score倒数或u端J调换。原hard帽和outer系数只用一次，给LJ14的72常数。tree_depth变窗时逐源N或共同sup已显式保留；不存在ν≤β使用。

新tree_capacity_checks.py已静态读，15 Fraction case=3initial+5stress+7depth，独立XOR与prefix LCA、leaf/grouped求和、零P及subprob不重归一均正确。depth8例积分4>1确说明不能免费删层费；包含anchor的有限例只检一般节点代数，非原initialalive实现。未运行脚本；等待最终notes/整合字节后绑定。

## 10. 最终整合窄核与字节冻结

已全文读proof.tex.txt、report.md、reproduce.py、parent_verification.md。主空间(1)–(6)、TT正测度分解、LJ加权companion及72常数与详细稿一致。最后TeX已加remaining active pairs的P_x(P_u)>0守卫，source零集不强推分子；空间稿已明确fixed-L零面不可推广adaptive-L，而closed/right-continuous Stieltjes确已计跳。两处均窄读通过。原source/window/j/time/real dx与sameα保留，旧ν≤β或Wν≤Wβ不继承。

父记录的完整52次overlap计算（36+6+8+2）及树15例逐byte重放，按parent_verification作为实际执行记录；本审计只静态核代码和证据标签，不重跑、不声明自己执行。mpmath为非interval，树二叉例不认证原n维FULL，父记录已明确。driver先核后造manifest，再复制合同和两脚本到新目录执行并逐byte比较输出；依赖环境已明示。未编译PDF。不存在以临时manifest循环绑定本审计。

最终实算SHA256如下，绑定13个其他最终文件，不绑定自身或尚未生成manifest。哈希只绑定本审查范围，不把有限诊断升级一般证明。

| 文件 | SHA256 |
|---|---|
| late_joint_geometry.md | 2db24734da5618f0d2e54c72a06105772a3fd637ecea81dd511068d991488365 |
| normalized_overlap_geometry.md | dc4299f10f422c6fd9d51b2366fff024edef64b2859554d6747fa19b3916ed30 |
| normalized_overlap_probe.json | 6a5d4d4e5cf49159124e0051c5ef069a09a495c5fd5676cba45c1340f3805b32 |
| normalized_overlap_probe.py | dfc3e6538990c6fe95e3d36a6c764321592017c27ca2228c38806e32a4ab7157 |
| numerical_review.md | 965d2cfedfb3943dd3f538cffa06ab2cdf8ea703cf8e0c3e6bc146c77893aca1 |
| parent_verification.md | 73c70669cbf8a6bc5d8c0756066fe33866714b29ad4b64f8592a929c9a749e47 |
| proof.tex.txt | 5a8f938dafc01b9b48a2583dd91efd5d5a54ff94d88d0a59e7a483580e134817 |
| report.md | 2c750a4068f7a2a843269855d67096ccb1dbc21ebfda936a2b97db53f34a490b |
| reproduce.py | 5d3617f68c1227660af6769126ae0c6d47c9102dbfdfdad1539213bb12b08a1f |
| task_contract.md | a30eb62aa618c4113260c4fdbf9ddeb360c0911569951b3bd1171f560f5111b5 |
| terminal_tree_geometry.md | cb77e0219cba96183bfde4dcc0aa4c37cdafb42d9e96c52a90bf216118232338 |
| tree_capacity_checks.json | 616926b6601bd8cc61c6ab1b88124aeffa17563123392db2f4493c0e4ab56f27 |
| tree_capacity_checks.py | abb52414573ae8e240172e4db542f2518afba922ac9e99c74d2301f687590f8f |

冻结结论：F_tree指定正支的√(n log(n+2))来源价与s≤s_n整片归一化空间纯来源根价通过；TT一次reserve为准确但未全局支付的约束。尚未证明严格扩大全部旧FULL已付域，中间soft/低树权重/低K0与neutral-hardface联合余域仍开，一般HB16未闭合。停止本轮审计。
