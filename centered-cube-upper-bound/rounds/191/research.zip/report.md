# 第191轮：共同祖先储备容量与归一化空间重叠

目标保持一般中心立方体极大算子n^(1/2+o(1))一致弱型上界。本轮没有闭合一般目标。起点第190轮a7759785bf72675327720663c1c71f9b5a5bc24a；原材料、所有来源、same-alpha、真实Lebesgue接收域及窗口费用均沿用，未改输入函数类。

## 已完成的估计及其准确范围

1. **原LCA储备容量。** 以原未捕获储备S=DK0(μhi−χ)/(αQJ)和current容量P=pν/q构造ell_tree=S(LCA)/P(LCA)。两者仅为subprob，无相互支配。原有限树逐层给∫ell_tree dP≤N_tree，N_tree=O(log(n+2))，zero-P先处理。把F_tree=wg_target² ell_tree/ρ_target²放入原companion，整域矩有真实来源价N_tree log2 Wν/(36κ)。对预定θ>0，F_tree≥θ的原正交通费用为(32Λ/3)√[nN_tree log2/(72Kκθ)]W_A。包括全部真实dx、原唯一j、time、高行及current容量，使用已审单向J能量。该条件支实际有价；未证明它相对全部旧门有严格新增FULL实例，也未证明余域都落此门。
2. **归一化空间重叠。** 直接证明F0(λ,d)≤ρ<1及F1(λ,d)≤C*√(1+d)，一致于λ∈[1/2,1]、d≥0。严格CS加一致尾紧化提供ρ；不是有限数据猜测。原target距离帽、wg≥∏C以及h+s_nφ包络给s≤c0/(1+5logn+1/2)整片的指数空间收缩，真实全尺度价为1+(n/2)log2。代回原固定Γ+的L_n=O(n²)费用，得到纯来源CΛ√n W_A，无good overlap下帽。此带并不等于中间硬层；R178已有极小常数soft支，故不宣称严格覆盖扩大。存在性常数c0未经数值最优化，测试tinysoft不认证理论门。
3. **祖先超额的一次reserve精确分解。** 终端surviving bad的所有父块合并为τ≤b，得到X=O+Att+T+Neutral+bH0ηα−Slack，T≤bD_A。不逐父重复reserve、不付1/α。三个物理缺陷及deletedbad、反向祖先序、fallback质量、e_g/H0仍全部保留，身份本身不登记新全局来源价。

主细节见normalized_overlap_geometry.md；Astra完整付款与实际分离界面见late_joint_geometry.md；祖先聚合见terminal_tree_geometry.md。详细LaTeX记录在proof.tex.txt，仅文本、不编译PDF。independent_audit.md先独立筛查命题再审全文与常数回代。

## 数值分析和实际执行

- 本机已有mpmath1.3.0：36个初步核积分、6个35位复核；一般强型F≤1数值不成立，随即转向有证明的弱式，未继续大规模否路线。
- 扩大位移/scale的正向压力：8个指定点与2个35位复核。六tinysoft点均<1；pure-soft d32比值14.6521783，除√33为2.55061686。非区间精度比较不能证明误差界、ρ、C或一般阶数。
- 父级完整从零重放全部上述数据2.528秒，JSON逐字节一致；代理另有extension-only生产1.137秒、隔离重放1.123秒。初始单独生产未记运行时间，不估算。
- 标准库Fraction树容量：3基础+5压力+7扩深，共15例，深度2..8，最多256叶。双实现LCA、零P节点、缺失来源、非相互支配、不同bad截断与逐层预算均精确通过。深度8的同储备重用积分=4>1，层预算9保留，说明不得删除层数。父级完整重放字节一致。
- 有限核数值和有限树算术没有认证原FULL/history/alpha实例；一般结论来自解析证明和原工具资格，未拟合维度阶数。

## 仍需攻坚的准确接口

扣除所有旧付款并按不交所有权使用本轮两片后，保留原晚并块/大h质量、near outerbad、tinygood和F_tree<θ。此时S(Pu)/P(Pu)<θρ_v²/wg_v²；tinygood使右端可大，K0与current核也不可互换。共同祖先的大无权质量可以由captured χ、低K0部分或neutral χ−Aν承担。

本轮给出捕获侧的真实位置必要条件：bad margin≤(Lφ/L+18/b)||z−u||1+j_s max(ΔN_L,ΔN_Lplus,0)。其严格反侧没有χ且受同α reserve控制。下一步必须在原联合交通下支付低K0质量、captured-neutral质量及有符号硬面跨越界面，并联系真实target未来损失；不能只把这些项重命名或用行内分解替代全局dx预算。窗口重用、other mother分支仍需最终总账核验。

## 复现、规模与额度

使用已有本机依赖：
`PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 reproduce.py --output-dir <不存在的新目录>`。
`python3 reproduce.py --verify-only`只验归档哈希，不冒充数值运行。完整模式重跑两个脚本并逐字节比较JSON。数学工具优先偏好已在全局AGENTS.md保存。

代理：1 Astra high攻当前瓶颈、1 Sol high祖先辅助、1 Sol high独审、1 Sol medium数值。复用既有上下文，不凑满员。无可获得的实际扣额数据，不猜测模型成本比例。只提交本轮README与紧凑ZIP，更新项目索引；展开文件备份仓库外，既不编译PDF也不改他人项目。
