# R191：晚合并的大祖先质量与真实捕获联合预算

起点main a7759785bf72675327720663c1c71f9b5a5bc24a，R190已独立审查、归档、推送；本轮开始干净。一般上界未闭合。目标继续为中间硬层剩余实际正交通的ε receiver+√n polylog source预算，不只重复低费用切分。

准确域：R190 F(d_y,σ_u)>η、小初始块、near outerbad、tinygood及全部原mask；F必要条件中的a0,b0和r_u、σg保留。允许R183完整删除/四缺口、R188 current-product λ、R189原grid/current顺序/Rκ、大块吸收、R190 exactLCA时钟及逐u futureloss。所有原sameα、K0、来源及true dx、窗口费用不改。

分工：Astra late_joint_geometry.md攻fractional捕获/真实weightedh接口；Sol terminal_tree_geometry.md攻terminal祖先壳与一次reserve聚合；Sol independent_audit.md先筛后审。主负责整体推导及归一化空间重叠的本机数值探路，明确未验证命题不当工具。数值代理在具体脚本方案后启用。无子代理Git/spawn，不互改，有界交付即停。

已知费用：h不是ν或β；小source current不支付target未来放大；parent expanded-current只能L+2d≤b且逆系数可指数大，不替代actualK0；heavycover体积价指数大。不得以重复归约/余项改名当根阶付款。完整轮次核验后精简提交，详细LaTeX文本，不编译PDF。
