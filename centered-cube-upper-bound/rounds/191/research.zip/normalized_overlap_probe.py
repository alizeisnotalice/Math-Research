#!/usr/bin/env python3
"""Bounded scalar normalized Hellinger overlap probe; no general certification."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import argparse,hashlib,json,time
import mpmath as mp
HERE=Path(__file__).resolve().parent
S=[F(0),F(1,100),F(1,10),F(1,2),F(9,10),F(1)]
D=[F(0),F(1,2),F(1),F(2),F(4),F(8)]

def kernel_runtime(dps):
 mp.mp.dps=dps;half=mp.mpf('.5')
 @lru_cache(maxsize=65536)
 def phi(x):
  x=abs(x)
  return 1-mp.expint(3,half-x)-mp.expint(3,half+x) if x<=half else mp.expint(3,x-half)-mp.expint(3,x+half)
 def C(d):
  d=abs(d)
  if d<=1:return 1-d+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,d)+mp.expint(4,d+1)
  return mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
 def val(q):return mp.mpf(q.numerator)/q.denominator
 def evaluate(sq,dq,lamq=F(1)):
  s,d,lam=val(sq),val(dq),val(lamq);source_half=lam*half
  def integrand(x):
   p=((1-s)*(1 if abs(x)<=source_half else 0)+s*phi(x/lam))/lam;j=phi(x-d)
   assert p>=0 and j>=0
   return mp.sqrt(p*j)
  seams=sorted(set([-source_half,mp.mpf(0),source_half,d-half,d,d+half]))
  cuts=[-source_half]+[x for x in seams if -source_half<x<source_half]+[source_half] if sq==0 else [-mp.inf]+seams+[mp.inf]
  affinity=mp.quad(integrand,cuts);den=C(d);assert affinity>=0 and 0<den<=1
  ratio=affinity/mp.sqrt(den)
  return dict(s=str(sq),d=str(dq),dps=dps,affinity=mp.nstr(affinity,dps+5),C=mp.nstr(den,dps+5),normalized_F=mp.nstr(ratio,dps+5),excess_over_one=mp.nstr(ratio-1,dps+5),observed_above_one=ratio>1+mp.mpf('1e-8'),pure_hard_boundary=sq==0,integration_domain=('exact compact [-1/2,1/2]' if lamq==1 else 'exact compact [-lambda/2,lambda/2]') if sq==0 else 'whole real line with infinite endpoints',finite_seams=[mp.nstr(x,20) for x in cuts if not mp.isinf(x)])
 return evaluate

def run_initial():
 initial=kernel_runtime(20);rows=[initial(s,d) for s in S for d in D]
 maximum=max(rows,key=lambda r:mp.mpf(r['normalized_F']));crossers=[r for r in rows if r['observed_above_one']];closest=min(crossers,key=lambda r:mp.mpf(r['normalized_F'])) if crossers else None
 selected=[];reasons={}
 def add(s,d,reason):
  key=(s,d)
  if key not in selected:selected.append(key);reasons[key]=[]
  reasons[key].append(reason)
 ms,md=F(maximum['s']),F(maximum['d']);add(ms,md,'maximum on the prescribed low-precision grid')
 if closest:add(F(closest['s']),F(closest['d']),'smallest observed excess above one on that grid')
 si,di=S.index(ms),D.index(md)
 if si>0:add(S[si-1],md,'existing-grid softness neighbor of maximum')
 if di>0:add(ms,D[di-1],'existing-grid displacement neighbor of maximum')
 add(F(0),F(0),'pure-hard centered control');add(F(1),F(0),'normalized equality control')
 assert len(selected)<=6
 high=kernel_runtime(35);refined=[]
 for s,d in selected:
  r=high(s,d);low=next(x for x in rows if x['s']==str(s) and x['d']==str(d));diff=abs(mp.mpf(r['normalized_F'])-mp.mpf(low['normalized_F']));r['absolute_precision_difference']=mp.nstr(diff,12);r['selection_reasons']=reasons[(s,d)];r['precision_consistent_1e_minus_14']=diff<mp.mpf('1e-14');assert r['precision_consistent_1e_minus_14'];refined.append(r)
 # Kernel identities at seams are numerical controls, not intervals.
 assert abs(mp.mpf(next(r for r in refined if r['s']=='1' and r['d']=='0')['normalized_F'])-1)<mp.mpf('1e-25')
 root=Path(mp.__file__).resolve().parent;sha=hashlib.sha256()
 for p in sorted(root.rglob('*.py')):sha.update(p.relative_to(root).as_posix().encode());sha.update(p.read_bytes())
 return dict(schema='r191_normalized_overlap_probe_v1',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependencies=dict(mpmath_version=mp.__version__,mpmath_source_tree_sha256=sha.hexdigest()),fixed_scales=dict(L_equals_b=True,xi=1),initial_dps=20,initial_grid=rows,refined_dps=35,refinements=refined,summary=dict(initial_cases=len(rows),refined_cases=len(refined),initial_observed_above_one=len(crossers),initial_grid_maximum=maximum,all_precision_controls_pass=True),limitations=['Real one-dimensional kernels only: no original selector, common-source, alpha, receiver or FIRST/history instance is constructed','mpmath infinite quadrature and precision comparisons are numerical, not interval error bounds or general theorem certification','Grid maximum is a finite-grid statistic, not a global extremum','Only selected crossers and existing-grid neighbors are refined, not the entire grid','s=0 is a pure-hard boundary diagnostic, not actual strictsoft qualification','No fitted dimension order or independent replacement of original good/bad geometry is inferred'])
def run(reuse=None):
 if reuse:
  base=json.loads(reuse.read_text());assert base['schema']=='r191_normalized_overlap_probe_v1'
  previous_extension=base.pop('pressure_extension',None)
  if previous_extension:assert hashlib.sha256((json.dumps(base,indent=2,sort_keys=True)+'\n').encode()).hexdigest()==previous_extension['initial_block_sha256']
  assert base['summary']['initial_cases']==36 and base['summary']['refined_cases']==6
  assert base['inputs']['task_contract.md']==hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()
 else:base=run_initial()
 inherited_sha=hashlib.sha256((json.dumps(base,indent=2,sort_keys=True)+'\n').encode()).hexdigest()
 specs=[(F(1,10**6)/(1+d),d,lam,'tiny_soft_weight_pressure') for lam in [F(1,2),F(1)] for d in [F(1),F(8),F(32)]]
 specs += [(F(0),F(32),F(1,2),'hard_compact_tail'),(F(1),F(32),F(1),'pure_soft_tail_growth_control')]
 low_eval=kernel_runtime(20);rows=[]
 for s,d,lam,label in specs:
  r=low_eval(s,d,lam);r['lambda']=str(lam);r['case_label']=label
  if s==1:r['F1_over_sqrt_1_plus_d']=mp.nstr(mp.mpf(r['normalized_F'])/mp.sqrt(1+mp.mpf(d.numerator)/d.denominator),25)
  rows.append(r)
 highest=max(rows,key=lambda x:mp.mpf(x['normalized_F']));closest=min(rows,key=lambda x:abs(mp.mpf(x['normalized_F'])-1));chosen=[highest]+([] if highest is closest else [closest]);high_eval=kernel_runtime(35);refined=[]
 for old in chosen:
  sq,dq,lq=map(F,(old['s'],old['d'],old['lambda']));r=high_eval(sq,dq,lq);r['lambda']=old['lambda'];r['case_label']=old['case_label'];r['selection_reason']='highest extension value' if old is highest else 'closest extension value to one'
  diff=abs(mp.mpf(r['normalized_F'])-mp.mpf(old['normalized_F']));assert diff<mp.mpf('1e-14');r['absolute_precision_difference']=mp.nstr(diff,12)
  if sq==1:r['F1_over_sqrt_1_plus_d']=mp.nstr(mp.mpf(r['normalized_F'])/mp.sqrt(1+mp.mpf(dq.numerator)/dq.denominator),40)
  refined.append(r)
 base['pressure_extension']=dict(initial_block_sha256=inherited_sha,inherited_fixed_scales_apply_only_to_initial_block=True,fixed_scales=dict(b=1,source_lambda_values=['1/2','1'],xi=1),source_density='[(1-s)h(x/lambda)+s phi(x/lambda)]/lambda; target phi(x-d); denominator sqrt(C(d)) at b=1',initial_dps=20,cases=rows,refined_dps=35,refinements=refined,summary=dict(initial_cases=len(rows),refined_cases=len(refined),tiny_soft_rows_below_one=all(mp.mpf(r['normalized_F'])<1 for r in rows if r['case_label']=='tiny_soft_weight_pressure')),limitations=['Finite pressure tests only, not a proof of uniform rho<1 or an optimal C in F1<=C sqrt(1+d)','No fit of a general order; only the requested d=1,8,32 points','The inherited initial JSON block is retained unchanged'])
 return base

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'normalized_overlap_probe.json');p.add_argument('--reuse-existing',type=Path,help='Reuse the unchanged initial 36+6 block and compute only the requested extension');a=p.parse_args();start=time.monotonic();r=run(a.reuse_existing);a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(initial_summary={k:v for k,v in r['summary'].items() if k!='initial_grid_maximum'},extension_summary=r['pressure_extension']['summary'],elapsed_seconds=round(time.monotonic()-start,3)),sort_keys=True))
