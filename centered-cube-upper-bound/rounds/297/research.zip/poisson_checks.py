#!/usr/bin/env python3
"""Finite Poisson witness-cover diagnostics; no interval or FULL kernel certificate."""
import sys,json,random
from pathlib import Path
from fractions import Fraction as F
from itertools import product
try:import mpmath as mp
except ModuleNotFoundError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
R=random.Random(29720261019)
def mm(q):return mp.mpf(q.numerator)/q.denominator

def cases(B):
 cs=[
 ('disjoint_zero_probability',[F(1),F(0),F(0)],[F(1),F(2),F(3)],[[1,0,0,0],[0,1,0,0],[0,0,1,0]],False),
 ('full_overlap_domination',[F(1,3)]*3,[F(1)]*3,[[1,1,1,0]]*3,False),
 ('nested_overlap',[F(1,2),F(1,3),F(1,6)],[F(1),F(3,2),F(4)],[[1,1,1,0],[0,1,1,0],[0,0,1,0]],False),
 ('all_uncaptured',[F(0),F(1,4),F(3,4)],[F(1),F(2),F(5)],[[0,0,0]]*3,False)]
 # Genuine one-dimensional closed centered cube incidence, with exact boundary atoms.
 centers=[F(0),F(1,2),F(2)];widths=[F(1),F(3,2),F(2)];points=[F(-1,2),F(0),F(1,2),F(5,4),F(3),F(4)]
 incidence=[[int(abs(z-x)<=w/2) for z in points] for x,w in zip(centers,widths)]
 cs.append(('one_dimensional_cube_boundaries',[F(1,2),F(1,3),F(1,6)],widths,incidence,True))
 with mp.workdps(100):
  threshold=4*mp.log(4)/B;den=10**8;k=int(mp.floor(threshold*den))
 for sign in [-1,1]:
  p=F(k+(1 if sign>0 else 0),den);assert 0<p<1
  cs.append(('capacity_threshold_'+('above' if sign>0 else 'below'),[p,1-p,F(0)],[F(1)]*3,[[1,0],[0,0],[0,0]],False))
 return cs

def prepare(B,case):
 name,pi,cost,A,real=case;assert sum(pi)==1 and all(p>=0 for p in pi) and all(c>=1 for c in cost)
 nz=len(A[0]);assert all(len(row)==nz for row in A)
 nu=[F(R.randint(1,10),R.randint(1,10)) for _ in range(nz)]
 rowmass=[sum(nu[z]*row[z] for z in range(nz)) for row in A]
 Q=max([F(1)]+[F(3,16)*m/c for m,c in zip(rowmass,cost)])
 assert all(m<=F(16,3)*Q*c for m,c in zip(rowmass,cost))
 mu=[B*p/(4*c) for p,c in zip(pi,cost)];assert sum(c*m for c,m in zip(cost,mu))==F(B,4)
 Pi=[sum(pi[i]*A[i][z]/cost[i] for i in range(3)) for z in range(nz)]
 Z=F(3,2);avol=F(7,5);J=[Z*p/avol for p in Pi]
 K=[j*(F(1) if 'threshold' in name else F(R.randint(0,10),10)) for j in J];assert all(k<=j for k,j in zip(K,J))
 legal=[];bounds=[int(F(B)/c) for c in cost]
 for ks in product(*(range(k+1) for k in bounds)):
  spent=sum(c*k for c,k in zip(cost,ks))
  if spent>B:continue
  capture=tuple(any(ks[i] and A[i][z] for i in range(3)) for z in range(nz))
  mass=sum(nu[z] for z,h in enumerate(capture) if h)
  assert mass<=sum(k*m for k,m in zip(ks,rowmass))<=F(16,3)*Q*spent<=F(16,3)*Q*B
  legal.append((ks,capture))
 return name,pi,cost,A,real,nu,Q,mu,Pi,K,Z,avol,legal,bounds

def evaluate(B,data,dp):
 name,pi,cost,A,real,nu,Q,mu,Pi,K,Z,avol,legal,bounds=data
 with mp.workdps(dp):
  pmfs=[]
  for m,limit in zip(mu,bounds):
   x=mm(m);row=[mp.exp(-x)]
   for k in range(1,limit+1):row.append(row[-1]*x/k)
   pmfs.append(row)
  mass=mp.mpf(0);omega=[mp.mpf(0)]*len(nu)
  for ks,capture in legal:
   p=mp.fprod(pmfs[i][ks[i]] for i in range(3));mass+=p
   for z,h in enumerate(capture):
    if h:omega[z]+=p
  discard=1-mass;tol=mp.mpf('1e-30');assert -tol<=discard<=mp.mpf('.25')+tol
  high_count=0;minsaving=mp.inf
  threshold=4*mp.log(4)/B
  for p,w in zip(Pi,omega):
   low=1-mp.exp(-B*mm(p)/4)-mp.mpf('.25')
   assert w+tol>=low
   if mm(p)>=threshold:assert w+tol>=mp.mpf('.5');high_count+=1
   if not p:assert abs(w)<tol
  paidmass=sum(mm(v)*w for v,w in zip(nu,omega));sourcecap=mp.mpf(16)/3*mm(Q)*B;assert paidmass<=sourcecap+tol*max(1,sourcecap)
  Kthreshold=mm(Z/avol)*threshold;Thigh=mp.mpf(0);Tw=sum(mm(v*k)*w for v,k,w in zip(nu,K,omega))
  for v,k,p in zip(nu,K,Pi):
   if mm(k)>=Kthreshold:
    assert mm(p)>=threshold;Thigh+=mm(v*k)
  assert Thigh<=2*Tw+tol*max(1,Tw)
  return {'budget_probability':+mass,'discard_probability':+discard,'omega':[+w for w in omega],'paid_source_fraction':+(paidmass/sourcecap),'Thigh':+Thigh,'Tomega':+Tw,'high_Pi_columns':high_count}

stages=[]
for B in [8,16,32]:
 rows=[];pe=mp.mpf(0);maxdiscard=mp.mpf(0);maxsource=mp.mpf(0);count=0;highcols=0
 for case in cases(B):
  data=prepare(B,case);low=evaluate(B,data,40);hi=evaluate(B,data,60)
  with mp.workdps(90):
   fields=[(low[k],hi[k]) for k in ['budget_probability','discard_probability','paid_source_fraction','Thigh','Tomega']]+list(zip(low['omega'],hi['omega']))
   err=max(abs(x-y)/max(1,abs(y)) for x,y in fields);assert err<mp.mpf('1e-30');pe=max(pe,err);maxdiscard=max(maxdiscard,hi['discard_probability']);maxsource=max(maxsource,hi['paid_source_fraction']);count+=len(data[-2]);highcols+=hi['high_Pi_columns']
   rows.append({'name':data[0],'legal_count_configurations':len(data[-2]),'genuine_one_dimensional_cube_incidence':data[4],'discard_probability':mp.nstr(hi['discard_probability'],25),'omega':[mp.nstr(x,25) for x in hi['omega']],'Pi':[str(x) for x in data[8]],'high_Pi_columns':hi['high_Pi_columns'],'Thigh':mp.nstr(hi['Thigh'],25),'Tomega':mp.nstr(hi['Tomega'],25),'max_normalized_40_vs_60_error':mp.nstr(err,12)})
  print('PASS',B,data[0],flush=True)
 stages.append({'B':B,'cases':len(rows),'precision_runs':2*len(rows),'legal_count_configurations':count,'high_capacity_columns':highcols,'max_discard_probability':mp.nstr(maxdiscard,25),'max_paid_source_fraction':mp.nstr(maxsource,25),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_violation':'0','rows':rows})
out={'status':'PASS','seed':29720261019,'scope':'Exact Fraction finite witness/cost/incidence/capacity algebra and exhaustive within-budget independent Poisson count sums at40/60 digits. Discard probability is the complement of the exact finite budget event, not a truncated infinite tail. Ordinary precision refinement, not outward intervals. Abstract incidences are not FULL/high-dimensional kernel constructions; designated one-dimensional examples use closed centered intervals with finite boundary atoms.','definitions':{'mu_i':'B*pi_i/(4*c_i)','expected_cost':'B/4 exactly','Pi_z':'sum_i pi_i A_iz/c_i','omega_z':'Pr(sum_i c_i N_i<=B and some N_i A_iz>0)','capture_lower':'omega_z>=1-exp(-B Pi_z/4)-1/4','capacity_threshold':'Pi_z>=4log(4)/B => omega_z>=1/2','K_high':'K_z<=Z Pi_z/a^n, high if K_z>=Z/a^n*4log(4)/B','source_budget':'sum_z nu_z omega_z<=(16/3) Q B'},'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':sum(s['cases'] for s in stages),'legal_configs':sum(s['legal_count_configurations'] for s in stages),'max_error':max(float(s['max_normalized_40_vs_60_error']) for s in stages)}))
