#!/usr/bin/env python3
"""R297 frozen source-row scale capacity: exact volume algebra and spatial menus."""
import json,random
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
R=random.Random(29720261018)
def dd(x):return D(x.numerator)/D(x.denominator)
def fmt(x):
 with localcontext() as c:c.prec=60;return format(dd(x),'.24E')
def menu_integral(rroot,broot):
 rs=sorted(set([rroot,(2*rroot+broot)/3,(rroot+2*broot)/3,broot]));value=1/(rroot*rroot);prev=rroot*rroot
 for rr in rs[1:]:value+=(rr*rr-prev)/(rroot*rr**3);prev=rr*rr
 sharp=(3-2*rroot/broot)/(rroot*rroot)
 shell=2/rroot*(1/rroot-1/broot)
 assert 1/(rroot*rroot)+shell==sharp
 coarse=1/(rroot*rroot)+(broot*broot-rroot*rroot)/(rroot*broot**3)
 assert coarse<=value<=sharp<=3/(rroot*rroot)
 return value,sharp

def model(n,spread):
 assert n%2==0
 aroot=F(1);broot=F(2)**(n//2);rmid=(aroot+broot)/2
 rroots=[aroot,rmid,broot,(2*aroot+broot)/3]
 beta=[F(R.randint(0,20),R.randint(1,20))*F(10)**R.randint(-spread,spread) for _ in rroots]
 nu=[F(R.randint(0,20),R.randint(1,20))*F(10)**R.randint(-spread,spread) for _ in range(5)]
 omega=[[F(R.randint(0,10),10) for z in nu] for y in beta];omega[-1]=[F(0)]*len(nu)
 lam=F(R.randint(1,10),R.randint(1,10))*F(10)**R.randint(-spread,spread);qm=3*lam/4;kappa=F(10)**R.randint(-spread,spread)
 masses=[sum(omega[y][z]*nu[z] for z in range(len(nu))) for y in range(len(beta))]
 C=[mass/(qm*rr*rr)*F(R.randint(1,5),1) if mass else F(0) for mass,rr in zip(masses,rroots)]
 assert all(mass<=cy*qm*rr*rr for mass,cy,rr in zip(masses,C,rroots))
 # Finite receiver matrices check selected-scale/FIRST and gate implications ONLY.
 selected=excluded=pairchecks=0
 for i in range(9):
  Lroot=[aroot,rmid,broot][i%3];Rroot=[aroot,rmid,broot][i//3]
  q=lam*[F(3,4),F(7,8),F(1)][i%3]
  raw=[F(R.randint(0,20),R.randint(1,20)) for _ in beta];total=sum(x*w for x,w in zip(raw,beta))
  ps=[min(x*q/(1+total),kappa/(Lroot*Rroot))*F(3,4) for x in raw]
  assert sum(p*w for p,w in zip(ps,beta))<=q
  for y,rr in enumerate(rroots):
   gate=Lroot>=rr and Rroot>=rr
   if gate:
    selected+=1;assert ps[y]<=kappa/(Lroot*Rroot)<=kappa/(rr*Rroot)
    for z in range(len(nu)):
     hard=F(R.randrange(2),1)/(Rroot*Rroot)
     actual=omega[y][z]*ps[y]/q*hard
     upper=omega[y][z]*kappa/qm/(rr*Rroot**3)
     assert actual<=upper;pairchecks+=1
   else:
    excluded+=1;assert (ps[y] if gate else F(0))==0
 # Independent true radial cube-volume finite spatial envelope per frozen row.
 finite=F(0);continuous=F(0);capacity=F(0);coarse3=F(0)
 for y,rr in enumerate(rroots):
  env,envsharp=menu_integral(rr,broot)
  finite+=kappa/qm*beta[y]*masses[y]*env
  continuous+=kappa/qm*beta[y]*masses[y]*envsharp
  capacity+=kappa*beta[y]*C[y]*(3-2*rr/broot)
  coarse3+=3*kappa*beta[y]*C[y]
 assert finite<=continuous<=capacity<=coarse3
 return {'height_selected':selected,'height_excluded':excluded,'pairchecks':pairchecks,'finite':finite,'continuous':continuous,'capacity':capacity,'three':coarse3}

def sharp_fourth(n):
 assert n%4==0
 gamma=F(n+1,n);G=gamma**(n//2);B4=F(2)**(n//4);maxpsi=F(0)
 rows=[]
 for r4 in [F(1),(1+B4)/2,B4]:
  S=(B4/r4)**4
  if S<=G**4:psi=3-2*(r4/B4)**2
  else:psi=3-F(2,3)/(G*G)-F(4,3)*G*(r4/B4)**3
  limit=3-F(2,3)/(gamma**n);raw=3-2*(r4/B4)**2;large=2-1/S
  assert 1<=psi<=raw<=3 and psi<=limit and 1<=large<=raw
  roots=sorted(set([r4,(2*r4+B4)/3,(r4+2*B4)/3,B4]));prev=r4**4
  env=1/r4**4
  for r in roots[1:]:
   coeff=min(1/(r4**2*r**6),G/(r4*r**7));env+=(r**4-prev)*coeff;prev=r**4
  assert r4**4*env<=psi
  maxpsi=max(maxpsi,psi)
  rows.append({'S':fmt(S),'Psi_G':fmt(psi),'raw_Psi':fmt(raw),'large_L_Psi':fmt(large)})
 return maxpsi,limit,rows

def stage(ns,count,spread):
 selected=excluded=pairchecks=0;maxratio=F(0);maxcap=F(0);zero=0
 for j in range(count):
  out=model(ns[j%len(ns)],spread);selected+=out['height_selected'];excluded+=out['height_excluded'];pairchecks+=out['pairchecks']
  if out['three']:maxratio=max(maxratio,out['finite']/out['three']);maxcap=max(maxcap,out['capacity']/out['three'])
  else:zero+=1
 maxsharp=F(0);maxlimit=F(0);examples=[]
 for n in ns:
  p,lim,rows=sharp_fourth(n);maxsharp=max(maxsharp,p);maxlimit=max(maxlimit,lim)
  examples.append({'n':n,'exact_limit_3_minus_2_over_3gamma_n':fmt(lim),'profiles':rows})
 # Precision refinement pertains only to scalar rendering/limit comparison, not Fraction proofs.
 vals=[]
 for dp in [40,60]:
  with localcontext() as c:
   c.prec=dp;bound=3-D(2)/(3*D(1).exp());value=dd(maxlimit);assert value<bound;vals.append(+value)
 with localcontext() as c:c.prec=90;err=abs(vals[0]-vals[1])/max(D(1),abs(vals[1]));assert err<D('1e-35')
 return {'source_models':count,'dimensions':ns,'selected_scale_height_checks':selected,'excluded_by_required_scale_gate':excluded,'finite_matrix_pair_height_checks':pairchecks,'frozen_row_mass_caps':4*count,'independent_radial_menu_envelopes':4*count,'exact_multirow_aggregate_checks':count,'max_finite_pair_budget_to_3kappa_Cbeta_ratio':fmt(maxratio),'max_sharp_row_capacity_to_3kappa_Cbeta_ratio':fmt(maxcap),'max_sharp_Psi_G':fmt(maxsharp),'max_normalized_decimal_40_vs_60_error':str(err),'sharp_fourth_power_examples':examples,'max_exact_violation':'0'}
settings=[('initial',[4,16,64],12,2),('scale_gate_rowcap_stress',[16,64,256],24,12),('expanded',[64,1024,10000],36,40)]
stages=[dict(name=name,**stage(ns,count,spread)) for name,ns,count,spread in settings]
out={'status':'PASS','seed':29720261018,'scope':'Exact Fraction frozen row-cap and selected-scale algebra, independently calibrated real cube-volume nested hard-menu integrals, source-ledger aggregation and optional sharp coefficient envelopes. Abstract finite matrices are not a simultaneous genuine high-dimensional kernel construction; arbitrary matrix dx weights are never used to infer a spatial integral. Formatted decimals can round strict inequalities to equality; Fraction assertions precede rendering. No FULL/source closure.','volume_variables':'rroot=sqrt(r^n), Lroot=sqrt(L^n), Rroot=sqrt(R^n), broot=sqrt(b^n); sharp module uses fourth roots.','height':'kappa0/sqrt(L^n R^n)<=kappa0/sqrt(r^n R^n) only under actual L,R>=r','continuous_envelope':'r^-n*(3-2*(r/b)^(n/2))','row_capacity':'sum_z omega(y,z)nu(z)<=C(y)q_minus r(y)^n','source_receipt':'finite spatial pair budget<=3*kappa0*sum_y C(y)beta(y)','sharp_G':'G=gamma^(n/2); Psi_G(S)=3-2S^-1/2 if S<=G^4, else3-2/(3G²)-(4/3)G S^-3/4','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
