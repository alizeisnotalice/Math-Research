# R297 — one exact ledger for spatial tails, own-scale witnesses, and constructive capture

## 1. Fixed original field and admissibility

Fix the original outer data and one measurable receiver field s(x),L(x),R(x),q(x). The positive L1 sources beta and nu remain the original ones, a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda. Let I0(x,y,z) in [0,1] be the complete original accepted, history, forbidden, low-pe and m>M mask. No replacement of e_g, m or q is used. Write kappa0=2K/(ell M), G=gamma^(n/2), gamma=1+1/n, Q=q_-a^n. The raw traffic is

    T=integral I0 p_y h_R(x-z)/q(x) dx beta(dy)nu(dz).

The following combines the independently proved R296 tail receipt and the two R297 constructive results on the SAME original traffic. It is not an assertion that the complementary traffic vanishes.

Choose a row mask Irow(x,y) in [0,1], jointly measurable, with I0<=Irow and supported on original accepted receivers where all original caps hold. It may retain the original low/high and other row-only qualifications; dropping all source-dependent masks is also legitimate. Put

    U_y(x)=Irow(x,y)p_y/q(x), Z_y=integral U_y(x)dx,
    J(y,z)=integral U_y(x)h_R(x-z)dx.

The original common-soft scale envelope gives Z_y<=S/q_-<infinity, S=(1+n log(b/a))Csoft_n. On Z_y=0 define all normalized quantities and covered traffic to be zero. Otherwise define

    P(y,z)=a^n J(y,z)/Z_y in [0,1].

These quantities are defined from the fixed full receiver field, then held fixed during each receiver integral. This is a pathwise generalization of R296's stronger frozen-data premise; the beta FIRST/height proof is re-established for each fixed field, not invoked as a new FIRST condition. No outer clock sum or seed integral is silently paid by this construction.

## 2. Three-way disjoint accounting

Choose epsilon in (0,1], and set D=1+log[(16/9)S n/epsilon]. Let N(y,z)=1{|y-z|_infinity<=Db}. R296 pays the entire original (1-N) traffic by epsilon W_beta.

Next choose any legitimate frozen source weights omega_k>=0 and own scales r_k(y) in [a,b], with sum_k omega_k<=1. Define

    B(x,y,z)=sum_k omega_k(y,z)1{min(L(x),R(x))>=r_k(y)}.

Then 0<=B<=1. No assumption is made that B=1 on all original traffic. Introduce the nonnegative scale fee

    L_scale=(kappa0/q_-) integral beta(dy)sum_k
      r_k(y)^(-n)Psi_G((b/r_k(y))^n)
                         integral omega_k(y,z)nu(dz),

where Psi_G is the exact R297 row-scale envelope. The original I0 N B traffic is bounded by L_scale, because it is a suballocation of the original I0 B traffic. Source overlap across rows and all within-row multiplicity remain inside this displayed fee.

For H>=0 put rho_H=4 log(4) exp(-H). The remaining near traffic splits EXACTLY into

    I0 N(1-B)1{P>=rho_H},
    I0 N(1-B)1{P<rho_H}.

On Z_y=0 both have zero traffic; the threshold equality belongs to the first piece. Together with the far and own-scale pieces these masks add to I0. No subtractive credit or independently re-used source budget is introduced.

## 3. Constructive bounded witness cover pays the high-capture part

For Z_y>0 the R297 Poisson construction uses the finite intensity

    mu_y(dx)=(exp(H)/4)(a/R(x))^n U_y(x)dx/Z_y.

Every sampled cube is centered at an ORIGINAL accepted receiver, at its own legal selected R. Its expected total normalized volume sum(R/a)^n is exp(H)/4. Retain only realizations whose total volume is at most exp(H), and average their union indicators to form omega_H(y,z). The proof gives

    0<=omega_H<=1,
    integral omega_H(y,z)nu(dz)<=(16/3)Q exp(H),
    omega_H(y,z)>=1/2 whenever P(y,z)>=rho_H.

The last inequality is actual traffic domination on that fixed pair branch, not an assertion that average coverage equals full coverage. The explicit finite-Poisson integral formula makes omega_H jointly measurable without choosing an argmax witness.

Apply the fixed-field R296 beta FIRST/height argument to the ORIGINAL residual allocation I0 N(1-B) times omega_H. Its masks remain at most one and retain all original low/high gates, so its source price is bounded by the same source receipt as the entire original allocation. With kappa_*=G kappa0 and C=(16/3)exp(H),

    T_(near,residual,highcapture)
      <=2[1+(4/3)log_+((4/3)kappa_* C)](W_beta+W_nu)
      =2[1+(4/3)log_+((64/9)kappa_* exp(H))](W_beta+W_nu). (1)

No factor S appears in the normalized capture threshold or in (1). Choosing H of root-polylog size makes this a root-polylog source price when the original log-parameter costs satisfy that size. This is a proved payment for a concretely defined original traffic portion, not a new premise that P is uniformly large.

## 4. Exact combined estimate and unresolved term

Define

    R_weak=integral I0 N(1-B)1{P<rho_H}
                       (p_y/q)h_R(x-z) dx beta(dy)nu(dz).

The preceding disjoint allocation proves

    T<=epsilon W_beta+L_scale
       +2[1+(4/3)log_+((64/9)G kappa0 exp(H))](W_beta+W_nu)
       +R_weak.                                          (2)

The original outside Lambda multiplies this raw estimate once. Costs of varying outer data or integrating clocks must use their ORIGINAL source ledger; (2) alone does not prove that those accumulated fees are root-order.

For completeness, the weak part has the honest but generally insufficient bound

    R_weak<=rho_H a^(-n) integral Z_y nu(Q_(2Db)(y))beta(dy)
           <=rho_H S W_beta W_nu/Q.                     (3)

Indeed its integrated actual pair kernel is at most J=Z_y P/a^n, and N is a fixed near relation. This is a product-mass bound and is NOT declared a general source-linear payment. Replacing it by a root budget requires further original geometry, not simply taking H arbitrarily large: the paid coefficient (1) also grows with H.

A genuine use of (2) is that L_scale treats an own-scale witness without the exponential (r/a)^n fee, even when r is close to b. The normalized P criterion alone can be small solely because its kernel contains (a/R)^n; the own-scale branch avoids paying for that normalization if its witness and minimum-scale gate are valid. After this exact allocation, the remaining R_weak consists of weak normalized capture not already handled by the actual own-scale witnesses. No claim is made that these two mechanisms cover all traffic.

## 5. Verification and scope

All ingredients preserve the true receiver dx and original source masses. The scale proof works for nonconstant row lengths and all orientations/softness; its finite-menu source partition has an exact complementary mask. The randomized geometric construction has a deterministic fractional output, a deterministic row capacity, and a quantitative capture domination. Its unretained outcomes and weak capture are not discarded from the ledger.

Independent audit must bind both component proofs and this combined accounting. Finite local computations check exact source ledgers, radial envelopes, finite Poisson count sums and retained-cover inequalities. They do not establish that R_weak has the target root budget or that all original outer terms have been paid. The general centered-cube weak endpoint remains open.
