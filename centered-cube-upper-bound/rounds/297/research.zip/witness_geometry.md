# R297: a normalized receiver-weighted witness cover with proved traffic domination

## 1. Precise constructive payment

Fix one complete original outer-data/clock instance. Keep its finite positive L1 sources beta,nu, actual measurable receiver field s(x),L(x),R(x),q(x), physical scales a<=L,R<=b<=2a, and q_-=3lambda/4<=q<=lambda. Let E be the ORIGINAL accepted receiver set on which FIRST and the full hard cap hold. In particular, for every receiver used below,

    integral P_(s,L)(x-y)beta(dy)<=q(x),
    nu(Q_(R(x))(x))<=4lambda R(x)^n.

All original source, history, forbidden and terminal masks remain on the traffic. Fix M>0. The target T is the original positive low,m>M traffic, both orientations and all bands; the main intermediate-traffic target is M=1. Its original complete e_g is not changed. Write Q=q_-a^n, ell=1+log n, gamma=1+1/n, and

    kappa=2K gamma^(n/2)/(ell M).

This is precisely the all-orientation point-height constant used in R296.

For each soft source y define the ACTUAL accepted receiver weight and its mass

    U_y(x)=1_E(x) P_(s(x),L(x))(x-y)/q(x),
    I_y=integral U_y(x)dx.

One may retain additional original nonnegative masks depending only on x,y in U, provided the actual pair kernel below remains bounded by the resulting witness kernel. The stated choice needs no such extra qualification. If I_y>0, let pi_y(dx)=U_y(x)dx/I_y, and define the normalized geometric capture

    P_y(z)=integral (a/R(x))^n 1_(Q_(R(x))(x))(z)pi_y(dx).
                                                               (W1)

Set P_y(z)=0 if I_y=0. Then 0<=P_y(z)<=1. It is an average with respect to a TRUE receiver probability, including the actual factor (a/R)^n. No coverage statement has yet been inferred from this average.

For every H>=0 there is an explicit measurable fractional pair allocation omega_H(y,z) in [0,1], constructed in section 3 from finite unions of ACTUAL accepted receiver cubes, with these two properties:

    integral omega_H(y,z)nu(dz)<=(16/3)e^H Q,            (W2)
    P_y(z)>=4 log(4)e^(-H)  implies omega_H(y,z)>=1/2.  (W3)

Each retained witness configuration itself obeys the normalized volume budget

    sum_k (R(x_k)/a)^n<=e^H.                            (W4)

Therefore the actual original traffic on the frozen capture branch has the source-linear payment

    T_{P>=4 log(4)e^(-H)}
       <=2[1+(4/3)log_+((64/9)kappa e^H)](W_beta+W_nu). (W5)

The outside original low-raw fee Lambda multiplies (W5) once. If H is root-polylog size and log_+kappa has the corresponding bound, this is a genuine root-polylog payment. If the threshold in (W3) exceeds one, that branch is empty; no coverage is asserted in that case.

Equation (W5) pays a definite part of the original traffic using a common receiver-weighted fractional witness cover. It does not cover the entire original low,m>M branch. Section 6 retains the exact weak-capture part and the available error bounds. In particular, average coverage is not called full coverage.

## 2. The actual kernel and the finiteness of receiver normalization

Write the original retained pair kernel as

    K_actual(y,z)=integral U_y(x)h_(R(x))(x-z)b(x,y,z)dx,

where 0<=b<=1 contains every remaining original low,m>M, forbidden-source, history and terminal qualification. Then

    T=integral K_actual(y,z)beta(dy)nu(dz).

The positive witness kernel is

    J(y,z)=integral U_y(x)h_(R(x))(x-z)dx,
    0<=K_actual<=J,
    J(y,z)=I_y P_y(z)/a^n                    when I_y>0. (W6)

Using J is only a positive cover construction. The original low gate still uses its full e_g, and the original traffic still uses K_actual, not J.

Let A_n=1+n log(b/a), and let Csoft_n be the full common-soft binomial coefficient sum, with Csoft_n<=1+(pi/2)sqrt(n). The ray-decreasing positive full-soft envelope yields

    I_y<=A_n Csoft_n/q_-<infinity.                       (W7)

This bound proves normalization is legitimate. It is NOT inserted into the capture threshold (W3). If I_y=0, nonnegative Tonelli gives K_actual(y,z)=J(y,z)=0 for nu-almost every z, so that source row has zero traffic. On these rows define all intensities and omega_H to be zero.

All kernels can be chosen Borel after changes on the original null sets, or their completed-measure versions can be used directly in Tonelli. Since all sampling intensities below are absolutely continuous with respect to the true receiver dx, an exceptional receiver null set is never granted a hard cap by sampling.

## 3. An explicit Poisson-series construction and its bounded realizations

Put B_H=e^H and c_H=B_H/4. For I_y>0 define the finite receiver intensity measure

    eta_y(dx)=c_H (a/R(x))^n pi_y(dx),
    mu_y=eta_y(R^n)<=c_H.

Every point in its support is an ACTUAL accepted receiver. A finite receiver configuration x_1,...,x_m has normalized witness volume

    V(x_1,...,x_m)=sum_(i=1)^m (R(x_i)/a)^n

and source union Z(x_1,...,x_m)=union_i Q_(R(x_i))(x_i). Define omega_H by the following nonnegative series, rather than by an unspecified measurable selection:

    omega_H(y,z)=exp(-mu_y) sum_(m=1)^(floor(B_H)) (1/m!)
       integral 1_{V<=B_H} 1_{z in Z(x_1,...,x_m)}
                                   product_(i=1)^m eta_y(dx_i). (W8)

The zero configuration contributes zero. Because each radius is at least a, any retained configuration has m<=floor(B_H); hence the displayed series is finite. Its nonnegative integral formula proves joint measurability directly. It also shows 0<=omega_H<=1. No finite discretization of the accepted receiver set is assumed.

For verification, regard the same formula without the volume restriction as a Poisson distribution of finite configurations. The elementary exponential series gives total probability one, and

    expected V=integral (R(x)/a)^n eta_y(dx)=c_H=B_H/4. (W9)

Indeed the factors (a/R)^n and (R/a)^n cancel exactly, leaving the mass of pi_y. This is the useful row normalization: it removes the coarse A_n Csoft_n factor from the geometric capture test. The configuration's count may vary, but its expected normalized witness volume is exactly B_H/4 on every nonzero row.

Markov's inequality gives probability{V>B_H}<=1/4. On the other hand the untruncated probability that z is not in the union equals

    exp[-eta_y({x:z in Q_(R(x))(x)})]
       =exp[-c_H P_y(z)].                              (W10)

This follows by summing configurations with every point outside that measurable receiver set. Consequently

    omega_H(y,z)>=1-exp[-c_H P_y(z)]-1/4.               (W11)

If P_y(z)>=4 log(4)/B_H, the exponential is at most 1/4. Thus omega_H>=1/2, proving (W3). The volume truncation and its loss are explicit; no assertion is made that every random draw covers the strong-capture branch.

## 4. Actual source capacity and genuine traffic domination

For EACH retained configuration, every witness is capped at its SAME actual selected radius. The original hard cap therefore gives

    nu(Z)<=sum_i nu(Q_(R(x_i))(x_i))
          <=4lambda a^n V
          <=4lambda a^n B_H=(16/3)Q B_H.               (W12)

Integrate (W12) against the configuration measure in (W8). Since its total retained probability is at most one, this proves (W2). Source overlap only reduces the union mass. There is no claim that nu has a bounded density or that a different source-center cube inherits a receiver cap. One can retain the sharper expected-volume row bound, but (W2) is sufficient and matches the explicit per-realization budget.

The R296 mixed-source theorem applies ONCE to the total allocation omega_H. Its row capacity is C=(16/3)e^H, theta=3/4, and the all-orientation height constant is kappa above. Hence

    T_(omega_H)
       <=[1+(4/3)log_+((4/3)kappa C)](W_beta+W_nu).

All original low,m>M qualifications remain on this traffic. No new FIRST for a smoothed or exchanged source is used. Columns may concentrate arbitrarily; the aggregate row capacity and the common allocation are what feed the mixed-source inequality.

Pointwise on the strong-capture source pair set, (W3) proves

    1_{P_y(z)>=4 log(4)e^(-H)}<=2 omega_H(y,z).

Multiplying by the ORIGINAL nonnegative pair traffic and integrating proves T_strong<=2T_(omega_H), and hence (W5). This inequality is the required traffic domination. It is stronger than merely reporting an average probability of coverage; it states exactly which original edges are dominated and at what factor.

## 5. Dependence on the receiver field, outer data, and clock

The allocation is computed from the entire fixed original receiver field and then held fixed as a function of (y,z) inside the receiver integral. In (W8), the dummy witness coordinates x_i are not the receiver x of the traffic being bounded. Thus the proof never chooses a fresh favorable source allocation separately for each traffic receiver.

A small extension of the wording of the R296 frozen-mask interface is worth making explicit. For any fixed measurable original field, its FIRST/height proof holds for EVERY measurable pair mask omega(y,z)<=1. That mask may have been computed from the fixed field: at each receiver, integral omega p beta<=integral p beta still holds, and the source mass b_omega(z) is independent of that receiver variable. All subsequent positive envelopes and Tonelli are unchanged. No probabilistic independence from the already fixed field is needed for this deterministic statement.

If the field itself depends on an original outer variable or clock parameter xi, the construction and estimate can be applied conditionally at each xi. Its joint measurability follows from the integral/finite-series formulas. The corresponding outer ledger is explicitly

    integral Lambda(xi) c(H(xi),kappa(xi))
                          [W_beta(xi)+W_nu(xi)] dmu(xi),
    c(H,kappa)=2[1+(4/3)log_+((64/9)kappa e^H)].

It is not automatically a single source charge across multiple clock slices. Any pre-existing source/clock conservation needed to reduce this displayed outer integral must still be used and paid. The construction is not inserted into an earlier signed derivative or posterior identity that requires its mask to be clock-independent. Its result concerns the original positive raw low traffic after that reduction. Thus no future witness, clock derivative, or new posterior certification is silently assumed.

## 6. Exact weak-capture gap and available error receipts

Let h_H=4 log(4)e^(-H). The source pair sets {P>=h_H} and {P<h_H} partition the original traffic, with equality assigned to the paid side. Consequently

    T <= c(H,kappa)(W_beta+W_nu)+T_(P<h_H),             (W13)
    T_(P<h_H)=integral 1_{P_y(z)<h_H}
                           K_actual(y,z)beta(dy)nu(dz). (W14)

The full original masks remain in K_actual. In particular (W14) is not allowed to use a locally substituted e_g. The normalized capture keeps the real factor (a/R)^n; a large legal R can make it small. Neither the existence of the witness cover nor its bounded expected volume proves that all original edges satisfy the paid threshold.

There is a valid but potentially expensive quantitative bound. From (W6),

    T_(P<h_H)<=[h_H/a^n] integral I_y
                    nu({z:P_y(z)<h_H, K_actual(y,z)>0}) beta(dy)
       <=[h_H W_nu/a^n] integral I_y beta(dy)
       <=h_H A_n Csoft_n W_beta W_nu/Q.                (W15)

The last fee is bilinear in source masses, not a root linear budget. It must not be dropped or declared small solely because h_H is exponentially small in sqrt(n). No relation between W_beta,W_nu and Q is assumed.

There is also an exact untruncated Poisson error, useful for a future sharper estimate. Without the volume discard, the uncovered original traffic is

    integral K_actual(y,z) exp[-(e^H/4)P_y(z)] beta(dy)nu(dz).

Using P exp(-cP)<=1/(ec) gives the upper bound

    [4e^(-H)/(e a^n)] W_nu integral I_y beta(dy).

This retains the same concentration issue and does not account for discarded configurations by itself; the rigorous strong-branch domination already pays that discard through (W11). For any source-region restriction, the first line of (W15) can retain its actual restricted nu mass, rather than replacing it by W_nu.

The concrete remaining geometric problem is to pay the ORIGINAL weak normalized-capture traffic (W14) at a linear root budget, or to construct a different common family of actual capped witnesses that covers it with a controlled normalized-volume cost. A bound only on expected coverage, or the trivial product-mass error (W15), does not complete that step.

The new proved contribution is a normalized actual-receiver witness construction with per-realization volume control, a deterministic fractional row capacity, and explicit traffic domination/payment (W5). It is not a general root closure. No further extraction is asserted in this bounded deliverable.

## 7. Actual finite verification and final scope

A local Python calculation was actually run in three stages, with dimensions 1; 2,8; and 64,256, normalized volume budgets 4,8,16, three actual witness locations, and two rational receiver probability choices. It exhaustively enumerated all retained finite Poisson count configurations. Exact Fraction arithmetic verified the original finite hard-cap normalization, the identity expected witness volume=B_H/4, and the count/intensity normalizations. Floating-point exponential weights then checked the retained probability, exact union probability, Markov loss, fractional source capacity, and strong-capture traffic domination.

All 22 configurations passed, including 30 pair checks meeting the strong-capture threshold. The smallest retained probability was 0.9816475766531965; the largest ratio of computed row mass to the conservative bound 4lambda a^n B_H was 0.1441250290053278. These are finite discrete geometric diagnostics, not simulations of a complete original L1 soft-kernel history or a proof that the weak-capture part is small.

An independent reproducible verification artifact is also available at /tmp/r297_poisson_checks.py with results /tmp/r297_poisson_checks.json; the parent reported its completed rerun with exit code zero. The analytic proof here is the finite Poisson-series construction and inequalities (W9)-(W12), not a numerical extrapolation. Only /tmp/r297_witness_geometry.md was written by this author. No other author file or Git state was changed.
