# R297 — row-scale cancellation with a single original-source ledger

## 1. A new actual estimate, with nonconstant row scales

Let I0(x,y,z) be the complete original low-pe, high-m (m>M), accepted, forbidden and history mask. Retain the original q, p_y, h_R, e_g, m, FIRST and unique band. Write

    kappa0=2K/(ell M), gamma=1+1/n, G=gamma^(n/2),
    a<=L(x),R(x)<=b<=2a, q(x)>=q_->0.

Choose a measurable FROZEN row length r(y) in [a,b] and a measurable frozen pair weight 0<=omega(y,z)<=1. Define the ACTUAL suballocation

    dT_(r,omega)=I0(x,y,z)omega(y,z)
        1{L(x)>=r(y),R(x)>=r(y)}
        p_y h_(R(x))(x-z)/q(x) dx beta(dy)nu(dz).        (1)

This is a positive portion of arbitrary original traffic, not a claim that all traffic satisfies its new scale gate. The gate uses the original selected L,R. No e_g, m, softness, posterior or source measure is recomputed.

Put

    m_omega(y)=integral omega(y,z)nu(dz),
    C_r(y)=m_omega(y)/(q_- r(y)^n),
    S_y=(b/r(y))^n.

Define the explicit function, for S>=1,

    Psi_G(S)=3-2 S^(-1/2),                         1<=S<=G^4;
    Psi_G(S)=3-2/(3G^2)-(4/3)G S^(-3/4),           S>=G^4. (2)

Then the general scale-weighted source theorem is

    T_(r,omega)
       <=kappa0 integral C_r(y)Psi_G(S_y)beta(dy)
       <=[3-2/(3gamma^n)]kappa0 integral C_r(y)beta(dy). (3)

This is one source integral over ALL row scales simultaneously. It contains no W_nu fee per scale and no (r(y)/a)^n normalization. Since gamma^n<=e,

    3-2/(3gamma^n)<=3-2/(3e)=2.75474703921903845... .    (4)

The simpler fully sufficient bound is 3 kappa0 integral C_r beta. If only the large-soft orientation L>R is being paid, the sharper result is

    T_(r,omega,L>R)
       <=kappa0 integral C_r(y)[2-S_y^(-1)]beta(dy)
       <=2 kappa0 integral C_r beta.                    (5)

These statements allow arbitrary L1 sources and nonconstant, even continuously varying, frozen r(y). All integrals use original dy and dz source masses. The exact capacity-weighted integral in (3) is the price; no uniform bound on C_r is silently assumed.

## 2. Original point heights and the exact envelope proof

The original low and high inequalities, with the SAME full e_g, imply

    p_y<kappa0 c_j^(n/2)g^(-n), g=sqrt(LR).

On the suballocation (1), L,R>=r. Dropping c_j<=1 gives

    p_y<=kappa0 r^(-n/2)R^(-n/2).                       (6)

If L<=R, the original band implies c_j<=gamma L/g, giving

    p_y<=kappa0 G L^(-n/4)R^(-3n/4)
        <=kappa0 G r^(-n/4)R^(-3n/4).                  (7)

If L>R, the even stronger p_y<=kappa0 R^(-n) implies (7) too, since R>=r and G>=1. Thus (6) and (7) hold simultaneously on BOTH orientations. They are actual gate consequences, not moment bounds on a substituted soft profile. They hold for all actual s in [0,1].

Fix the original y,z, so r=r(y) is fixed before the receiver integral. For w=(R/r)^n>=1, combine (6)-(7) as

    p_y<=kappa0 r^(-n)min(w^(-1/2),G w^(-3/4)).          (8)

The hard kernel contributes a further R^(-n) and its cube indicator. The scale coefficient is decreasing in R, so its hard-cube envelope is attained at R=r inside Q_r(z), and at R=2|x-z|_infinity in its outer shell, up to b. Positive radial integration gives EXACTLY

    integral_x sup_(r<=R<=b)
       R^(-n)1_(Q_R(z))(x) r^(-n)
       min((R/r)^(-n/2),G(R/r)^(-3n/4))
       =r^(-n)[1+integral_1^S
                     min(w^(-3/2),G w^(-7/4))dw]
       =r^(-n)Psi_G(S), S=(b/r)^n.                    (9)

The crossover is w=G^4. Evaluating the two elementary power integrals proves (2), including S=1 and equality at the crossover. The infinite-scale integral gives (4); no physical cap is granted beyond b. The infinite limit is used only to bound the positive envelope.

Use q>=q_-, retain the original masks until (8) is applied, then extend the receiver integration positively in (9). Positive Tonelli yields

    T_(r,omega)
       <=(kappa0/q_-) integral beta(dy) r(y)^(-n)
                              Psi_G(S_y) m_omega(y),

which is (3). For L>R use p_y<=kappa0 R^(-n) instead. Its exact envelope is r^(-n)[2-(r/b)^n], proving (5).

The argument does not exchange a receiver-dependent source with a source fixed beforehand. The y-dependent lower endpoint is frozen when integrating each source column, and r(y)>=a>0. Every expression is measurable. Bounded finite-scale kernels and finite original source masses justify the integrations on infinite domains; positive Tonelli also covers any intermediate infinite upper bound. No endpoint convolution theorem is used.

## 3. General height version and why the scale powers cancel

For clarity, suppose one has an actual gate height

    p_y<=kappa r(y)^(-n(1-theta))R(x)^(-n theta),
    R(x)>=r(y), 0<theta<=1.

Then the same calculation gives

    T_(r,omega)
       <=kappa integral C_r(y)
            [1+(1/theta)(1-S_y^(-theta))]beta(dy).       (10)

The envelope before the row source integral is exactly

    r(y)^(-n)[1+(1/theta)(1-S_y^(-theta))].

The r(y)^n in the OWN-scale row capacity cancels this normalization. Thus a physical witness close to b does not cost (r(y)/a)^n merely because a is much smaller. This is an actual integration improvement over substituting a into the earlier fixed-a Jensen bound. It is not a renamed source tail.

The remaining within-row mismatch is explicit: if the available witness has side t(y)>r(y), the elementary cap supplies C_r<=(16/3)(t(y)/r(y))^n, not 16/3. The theorem does not erase a witness larger than the actual minimum scale on the suballocation.

## 4. Several source blocks per row: the complete dy/dz price

Let r_k(y) in [a,b] and omega_k(y,z)>=0 be frozen measurable data, finite or countable, with

    sum_k omega_k(y,z)<=1.

Define a SINGLE covered original allocation by multiplying I0 by

    H_cov(x,y,z)=sum_k omega_k(y,z)
                         1{L(x)>=r_k(y),R(x)>=r_k(y)}.  (11)

Then 0<=H_cov<=1. Sum the proved positive source integrals, rather than paying W_nu afresh, to obtain

    T_cov <=(kappa0/q_-) integral beta(dy) sum_k
        [r_k(y)^(-n) Psi_G((b/r_k(y))^n)
                         integral omega_k(y,z)nu(dz)].  (12)

In particular

    T_cov <=[3-2/(3gamma^n)]kappa0 integral beta(dy)
          sum_k [integral omega_k(y,z)nu(dz)]
                                      /(q_- r_k(y)^n). (13)

This is the full scale-weighted row capacity, with BOTH original dy and dz fees present. Pair disjointness prevents traffic duplication but does not by itself bound the normalized sum in (13). A hard-source point used at many different beta rows is still integrated in the displayed row-source charge. There is no claim that disjoint z pieces have disjoint beta mass or zero total cost.

If the whole sum of normalized row masses is <=C(y), (13) costs only integral C(y)beta(dy). Conversely applying a separate constant capacity to each k costs their actual sum on each row. A countably infinite family needs a finite integral of that sum for a useful uniform source budget; finiteness is not inferred from countability or from sum omega_k<=1 alone.

## 5. True witness caps, and an automatic source-partition construction

For each y,k suppose omega_k(y,.) is supported in a genuine source cube

    Q_(r_k(y))(x_k(y)),

where x_k(y) is an original accepted receiver carrying the hard cap at THAT SAME legal radius r_k(y) in [a,b]:

    nu(Q_(r_k(y))(x_k(y)))<=4lambda r_k(y)^n.             (14)

The witness maps must be frozen and measurable. If the original maximal hard cap is known at that receiver, it supplies every legal chosen radius. A cap only at another selected radius cannot be substituted. Equation (14) then gives

    integral omega_k(y,z)nu(dz)/(q_- r_k(y)^n)<=16/3.     (15)

One witness per beta row therefore gives the new all-scale source receipt

    T_cov <=(16/3)[3-2/(3gamma^n)]kappa0 W_beta
          <(16/3)(2.754748)kappa0 W_beta,               (16)

regardless of how many different r(y) occur across beta. For the large-soft orientation the factor 2.754748 is replaced by 2. Multiple witnesses per row cost the exact normalized sum in (13), bounded crudely by (16/3) times their number. Fractional row weights or disjoint source blocks may reduce this sum; the reduction must be calculated, not assumed.

Here is a concrete allocation requiring NO assumption that its scale gate holds on all old traffic. Partition the ORIGINAL beta source into measurable sets Y_k. For each row y in Y_k fix one valid witness x_k(y),r_k(y), and set

    omega_k(y,z)=1_(Y_k)(y)1_(Q_(r_k(y))(x_k(y)))(z).

These frozen source weights have sum<=1. Insert the actual gate in (11). This defines a legal original suballocation on arbitrary input, and its support AUTOMATICALLY satisfies the scale hypothesis of the theorem. The exact complementary traffic is I0 times

    1-sum_k 1_(Y_k)(y)1_(Q_(r_k(y))(x_k(y)))(z)
                               1{min(L(x),R(x))>=r_k(y)}. (17)

Original e_g and m are unchanged on both parts. The source partition ensures every beta row is charged once in (16), even if the Y_k represent infinitely many different physical scales. All retained source mass is original; nu has not been split and recharged once per physical window. In particular there is no sqrt(n)-window W_nu repetition hidden in (16).

One can use several witnesses more efficiently with an explicit pair partition. For a FINITE measurable witness menu on each row, assign each z in its union to the containing cube with SMALLEST radius, breaking ties by index. The resulting disjoint frozen source pieces D_k(y) lie in their corresponding cubes, and omega_k=1_(D_k(y)) has sum<=1. Define

    r_min(y,z)=min{r_k(y):z in the kth witness cube}.

Then (11) covers EXACTLY the old traffic for which z lies in that witness union and min(L,R)>=r_min(y,z); the scale gate is automatic for the assigned source piece. All other original traffic remains in the complement. For countable menus one may use a specified attained measurable minimum or a given measurable disjoint source partition; the existence of an unattained minimizing radius is not treated as an actual witness.

The finite-menu construction proves a concrete covered branch and its exact fee (12). It does not assume all traffic is covered, and does not silently claim that every original source pair has an affordable witness. The largest feasible witness can sometimes lower the weighted fee, but choosing it anew for each actual receiver would not be a frozen source partition and is not part of this theorem.

## 6. Relation to FIRST and the precise remaining branch

Original FIRST remains an actual qualification and may independently be used BEFORE receiver extension. For the SAME covered traffic, it gives the single global baseline

    T_cov<=[1+n log(b/a)]W_nu.                           (18)

Therefore one may take the minimum of (12) and (18). Equation (18) is applied once to the aggregate covered allocation, whose mask is <=1. It is not applied separately and added over k. The new proof (3) itself consumes the actual low/high height and witness source capacity; it needs no additional FIRST, future-scale cap or softness moment.

When kappa0=2K/(ell M) and the normalized aggregate row capacity in (13) are polylog, (13) is a polylog source-linear payment, and hence fits a root-polylog budget. This includes a single OWN-scale witness per beta row at any physical radius, even r(y) close to b. Arbitrary source concentration and arbitrary distance from y to its witness are allowed.

For the whole remaining original traffic to be paid this way, one still needs an affordable witness-source partition for which the complement (17), or its multi-witness analogue, is empty or paid by another genuine argument. In particular sources paired to witnesses larger than their actual min(L,R), sources outside all chosen witness cubes, and excessive within-row multiplicity remain explicit. The theorem does not turn existence of some witness into a general root cover. It eliminates the artificial global-a normalization on the concrete above-witness-scale branch, not every geometric coverage problem.

## 7. Actual bounded verification and reproducibility

A local Python/mpmath run at 45 digits passed 28 exact-envelope quadrature/formula comparisons for n=1,2,3,16,64,1024,1000000 and b/r=1,1.001,1.1,2. It also passed 240 actual-band log-height comparisons over both orientations through n=10^6. The computed universal constant was 2.754747039219038452269651. These finite checks support, but do not replace, the analytic proof and do not certify a global witness cover.

The exact code used is retained below so this single-file deliverable is reproducible. It writes no files. If mpmath is already importable, the fallback local vendor path is unused.

```python
import sys, random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps = 45
count = 0
for n in [1, 2, 3, 16, 64, 1024, 1000000]:
    G = mp.exp(mp.mpf(n)*mp.log1p(mp.mpf(1)/n)/2)
    cross = 4*mp.log(G)
    for ratio in map(mp.mpf, ['1', '1.001', '1.1', '2']):
        x = n*mp.log(ratio)
        pts = sorted(set([mp.mpf(0), min(x, cross), x]))
        integral = sum(mp.quad(lambda t: min(mp.exp(-t/2), G*mp.exp(-3*t/4)), [p, q])
                       for p, q in zip(pts, pts[1:]))
        psi = (3-2*mp.exp(-x/2) if x <= cross else
               3-mp.mpf(2)/(3*G**2)-mp.mpf(4)*G*mp.exp(-3*x/4)/3)
        assert abs(1+integral-psi) < mp.mpf('1e-35')
        assert psi <= 3-mp.mpf(2)/(3*mp.e)+mp.mpf('1e-35')
        count += 1
rng = random.Random(297)
heights = 0
for n in [1, 2, 3, 16, 1024, 1000000]:
    lg = mp.log1p(mp.mpf(1)/n)
    logG = n*lg/2
    for k in range(40):
        r = 1+mp.mpf(rng.randint(0, 100))/100
        L = r+(2-r)*mp.mpf(rng.randint(0, 100))/100
        R = r+(2-r)*mp.mpf(rng.randint(0, 100))/100
        j = mp.floor(abs(mp.log(L/R))/(2*lg))
        logp = -n*j*lg/2-n*(mp.log(L)+mp.log(R))/2
        bound1 = -n*(mp.log(r)+mp.log(R))/2
        bound2 = logG-n*mp.log(r)/4-3*n*mp.log(R)/4
        assert logp <= min(bound1, bound2)+mp.mpf('1e-30')
        if L > R:
            assert logp <= -n*mp.log(R)+mp.mpf('1e-30')
        heights += 1
print('PASS exact-envelope quadrature/formula comparisons=', count)
print('PASS actual-band all-orientation log-height comparisons=', heights)
print('Uniform all-orientation cost upper=', mp.nstr(3-mp.mpf(2)/(3*mp.e), 25))
```

Only /tmp/r297_scale_budget.md was written. No other author file or Git state was changed.
