import sys, random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps = 45
count = 0
for n in [1, 2, 3, 16, 64, 1024, 1000000]:
    G = mp.exp(mp.mpf(n)*mp.log1p(mp.mpf(1)/n)/2)
    cross = 4*mp.log(G)
    for ratio in map(mp.mpf, ['1', '1.001', '1.1', '2']):
        x = n*mp.log(ratio)
        pts = sorted(set([mp.mpf(0), min(x, cross), x]))
        integral = sum(mp.quad(lambda t: min(mp.exp(-t/2), G*mp.exp(-3*t/4)), [p, q])
                       for p, q in zip(pts, pts[1:]))
        psi = (3-2*mp.exp(-x/2) if x <= cross else
               3-mp.mpf(2)/(3*G**2)-mp.mpf(4)*G*mp.exp(-3*x/4)/3)
        assert abs(1+integral-psi) < mp.mpf('1e-35')
        assert psi <= 3-mp.mpf(2)/(3*mp.e)+mp.mpf('1e-35')
        count += 1
rng = random.Random(297)
heights = 0
for n in [1, 2, 3, 16, 1024, 1000000]:
    lg = mp.log1p(mp.mpf(1)/n)
    logG = n*lg/2
    for k in range(40):
        r = 1+mp.mpf(rng.randint(0, 100))/100
        L = r+(2-r)*mp.mpf(rng.randint(0, 100))/100
        R = r+(2-r)*mp.mpf(rng.randint(0, 100))/100
        j = mp.floor(abs(mp.log(L/R))/(2*lg))
        logp = -n*j*lg/2-n*(mp.log(L)+mp.log(R))/2
        bound1 = -n*(mp.log(r)+mp.log(R))/2
        bound2 = logG-n*mp.log(r)/4-3*n*mp.log(R)/4
        assert logp <= min(bound1, bound2)+mp.mpf('1e-30')
        if L > R:
            assert logp <= -n*mp.log(R)+mp.mpf('1e-30')
        heights += 1
print('PASS exact-envelope quadrature/formula comparisons=', count)
print('PASS actual-band all-orientation log-height comparisons=', heights)
print('Uniform all-orientation cost upper=', mp.nstr(3-mp.mpf(2)/(3*mp.e), 25))
