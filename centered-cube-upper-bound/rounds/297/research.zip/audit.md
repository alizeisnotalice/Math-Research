# R297 independent preauthor audit

## Scope

Written before reading any R297 author proof. Fix original outer/source data, a positive physical window0<a<=b, n>=1, A=(b/a)^n, an original measurable receiver set E, and measurable actual common hard selector R:E->[a,b]. FIRST and hard-source caps are used only at their documented original receivers. Every formula below is for each fixed source z and height u>=0; source-dependent u(z) may subsequently be integrated with its ACTUAL source measure, not replaced by a Lebesgue budget. No history is scanned or source ordering assumed.

## 1. Exact restricted geometric hard envelope

Let r_v=a v^(1/n), 1<=v<=A, and define
 V_z(v)=a^-n Leb(E intersect Q_(r_v)(z)),
 alpha_z=V_z(1).
Then V_z is nondecreasing and1-Lipschitz, because the increment in E's cube volume is bounded by the full shell volume a^n(v'-v). Therefore V_z is absolutely continuous, with shell occupancy eta_z(v)=V_z'(v) in[0,1] almost everywhere. The exact restricted SUPREMUM envelope is
 I_E^sup(z,u)=integral_E sup_(a<=r<=b) h_r(x-z)
                            min(1,u(a/r)^(n theta))dx
 =alpha_z min(1,u)
      +integral_(1,A] v^-1 min(1,u v^-theta)dV_z(v)
 =alpha_z min(1,u)+integral_1^A min(1,u v^-theta)eta_z(v)dv/v.
This holds for every theta>0, including a=b by the first term only. It follows by optimizing the decreasing hard coefficient at r=max(a,2||x-z||_infinity) whenever this is <=b; the core Q_a creates the endpoint atom.

Equivalently let the nondecreasing weighted radial measure have cumulative function
 G_E,z(v)=V_z(1)+integral_(1,v] s^-1 dV_z(s)
          =V_z(v)/v+integral_1^v V_z(s)ds/s².
Its Stieltjes measure is alpha_z delta_1+eta_z(v)dv/v, with initial value zero to the left of1. Then I_E^sup=integral_[1,A] min(1,u v^-theta)dG_E,z(v).

The naive unweighted cube-volume function V_z alone requires the factor1/v in its Stieltjes integrand. Omitting the atom at1 or that factor is incorrect. Only for the FULL receiver space does V_z(v)=v, alpha_z=1, eta_z=1 recover F_(A,theta)(u). For arbitrary E the exact occupancy is retained and yields an upper bound by F, not an automatic equality to it. Fixed hard faces are included; the proof uses actual cube geometry and does not dismiss arbitrary selector graphs as null. The cumulative-volume formula gives joint measurability.

## 2. Exact occupation measure retaining ACTUAL R(x)

Define the genuinely selected-radius cumulative measure
 G_act,z(v)=integral_{{x in E:(R(x)/a)^n<=v}} h_(R(x))(x-z)dx,
again zero to the left of1. It can have atoms at ANY selected radius. Positive pushforward integration gives EXACTLY
 I_act(z,u)=integral_E h_(R(x))(x-z)
                       min(1,u(a/R(x))^(n theta))dx
           =integral_[1,A] min(1,u v^-theta)dG_act,z(v).
This is distinct from G_E,z, which drops the actual selector and uses the least capturing scale. Pointwise selected-kernel domination gives G_act,z(v)<=G_E,z(v) for everyv. Since the height factor is nonnegative nonincreasing in v, the corresponding integrals obey I_act<=I_E^sup<=F_(A,theta)(u). This preserves the actual radius gate before the positive geometric relaxation.

A genuine original-cap identity remains available:
 integral nu(dz)G_act,z(v)
  =integral_{{x in E:R(x)<=r_v}}(h_(R(x))*nu)(x)dx
  <=4lambda Leb{{x in E:R(x)<=r_v}}.
This is actual source occupation conservation by positive Tonelli and the SAME actual hard cap. It does not grant caps to a supremum or to other radii. Its receiver-volume right side is explicit and is not itself a source-linear root budget. If u depends on z, its weight cannot be pulled out without a further proved estimate.

## 3. A normalized averaged witness gives a valid ROW capacity

For each soft source y, let pi_y be a fixed measurable subprobability measure on original accepted receivers with the original cap at their chosen legal radius R(x). It must be chosen independently of the current hard source z and current integrated receiver. The source-only fractional mask
 omega_bar(y,z)=a^n integral h_(R(x))(x-z)pi_y(dx)
 lies in[0,1], because R>=a and pi_y has mass<=1. Its true row budget is
 integral omega_bar(y,z)nu(dz)
 <=4lambda a^n pi_y(E)<=(16/3)Q, Q=q_-a^n.
Thus normalization by each actual hard volume indeed removes the individual(r/a)^n witness-volume fee for THIS fractional allocation. It is valid to apply R296 to the ORIGINAL traffic multiplied by this fixed mask. No pointwise source density cap is needed.

This averaging does not prove coverage. If pi is allowed to depend separately on z, the cap cannot be integrated as one row without an additional domination/occupation proof: choosing a different witness for each hard source is exactly the quantifier the fixed-pi row bound avoids. Mere average radius or average original cap is not a uniform row property for arbitrary pair-dependent choices.

## 4. Pair-kernel domination and exact needed coverage

Let K(y,z)=integral_E q(x)^-1 p_y(x) h_(R(x))(x-z) a_original(x,y,z)dx be the integrated ORIGINAL pair kernel, with all current low/high/history/source masks retained. Then the original traffic is T=integral K beta nu. For any fixed omega in[0,1], R296 bounds ONLY
 T_omega=integral K(y,z)omega(y,z)beta(dy)nu(dz).
A proved row cap on omega does not identify T_omega with T. Full coverage requires K(1-omega)=0 for beta-product-nu almost every pair, equivalently omega=1 on the positive pair-kernel support up to traffic-null sets. More generally omega>=eta>0 on that support yields T<=eta^-1 T_omega; the weakest integrated capture sufficient for this conclusion is the separately proved inequality integral K omega>=eta integral K. The reciprocal capture price must remain. A family of masks must have aggregate capacity and aggregate capture proved; positive row bounds cannot be averaged into full coverage.

If instead a new averaged pair kernel Ktilde is introduced, one must prove K<=C0 Ktilde almost everywhere under the ORIGINAL pair source measure (or an integrated comparison with explicit constants), AND show the source theorem actually applies to Ktilde with its original response/cap qualifications. A row cap on an unrelated averaging mask supplies neither statement. Choosing omega=K/H or a normalized version of K generally changes the traffic to a quadratic weighted integral, not the old integral K.

Likewise an actual pair posterior on receivers may depend on both y,z. Its probability normalization is not a common source-row witness distribution pi_y. To use a y-only averaging law, every pair-dependent restriction must remain in the kernel or be positively majorized, and the resulting source-row normalization factor must be paid.

## Initial verdict

Both small propositions admit exact constructive formulas: actual and geometric shell occupation measures preserve the receiver restriction; normalized fixed-row witness averages give a real constant row capacity without an individual radius-volume fee. The unproved step is quantitative capture/domination of the SAME original traffic by those averages (or a usable joint source-weighted bound for actual occupation). Neither result alone supplies full-source coverage or general centered-cube weak-type closure. Only this owned temporary audit was written; no repository or Git action is taken.

## Independent actual scale-threshold row theorem screen

PASS before reading its new author proof. Let fixed measurable r(y) in[a,b] and omega(y,z) in[0,1] obey integral omega(y,z)nu(dz)<=C(y)q_-r(y)^n. Restrict the SAME original low,m>M traffic to actual L(x),R(x)>=r(y). With kappa0=2K/(ell M), original low/high yields p_y<=kappa0 c_j^(n/2)g^-n<=kappa0 g^-n. Therefore
 p_y<=kappa0 r(y)^(-n/2)R(x)^(-n/2).
Using q>=q_- and the same pair mask, integrate the actual hard source-pair column by its legal hard scale envelope:
 integral dx sup_(r<=R<=b) R^(-3n/2)1_QR(z)(x)
 =r^(-n/2)[3-2(r/b)^(n/2)].
The core is r^-n/2; the radial shell integral is2(r^-n/2-b^-n/2). Consequently
 T_(omega,L,R>=r)<=kappa0 integral C(y)[3-2(r(y)/b)^(n/2)]beta(dy)
 <=3kappa0 integral C beta.
This is a genuine original-traffic mixed-source payment and needs no FIRST at a new source, no beta density cap, and no W_nu fee. The row normalization is at r(y), not the fixed lower a, so no(r/a)^n remains. Its source-dependent lower gate is a REAL retained actual L,R qualification; it is not automatically true at every proposed witness radius.

For a family omega_k,r_k, every piece must keep its own actual L,R>=r_k gate, and the ORIGINAL pair/receiver allocation must have total weight<=1 to avoid duplicated traffic. If each row mass is controlled at its r_k, sum_k r_k(y)^-n integral omega_k(y,z)nu(dz) is the explicit normalized row cost. Combining fixed source blocks does not prove that those gated pieces cover all original traffic.

An independently derived sharper constant uses BOTH valid pointwise heights:
 p_y<=kappa0 r^-n/2R^-n/2,
 p_y<=kappa0 gamma^(n/2)r^-n/4R^-3n/4.
The second is the R296 all-orientation height with a replaced by the ACTUAL retained lower r. Set B=(b/r)^n. The exact normalized envelope coefficient is
 C_n(B)=1+integral_1^B min(v^-3/2,gamma^(n/2)v^-7/4)dv.
Its crossover is B0=gamma^(2n). Hence
 C_n(B)=3-2B^-1/2, B<=B0;
 C_n(B)=3-2/(3gamma^n)-(4/3)gamma^(n/2)B^-3/4, B>=B0.
In particular C_n(B)<=3-2/(3gamma^n)<3. The same normalized row proof gives kappa0 integral C(y)C_n((b/r(y))^n)beta(dy). All gamma and physical-boundary terms are explicit. This improvement remains conditional on the same frozen row capacity and actual scale gate, not a source-cover existence theorem.

## Executed local geometric diagnostics

mpmath at40 digits checked 15 one-dimensional restricted receiver envelopes on a three-interval measurable E, three fixed sources z and five heights u. Direct receiver integration matched the exact core-plus-shell-occupancy formula, maximum difference 1.1479e-41; a two-valued actual selector had its two pushforward atoms and stayed below the restricted envelope. Another20 cases verified the refined scale-threshold coefficient by log-radius quadrature against its crossover formula, through n=10000 and physical ratio2, maximum error 2.2959e-41. These finite diagnostics supplement the exact measure and radial proofs; no original FULL/history realization or global coverage is asserted. No R297 author proof has been read at this point.

## Independent Poisson witness/actual-overlap screen

PASS before reading the author proof. Fix an entire original receiver field. Let U_y(x)>=0 retain actual p_y/q and every current x,y qualification, dropping only z-dependent masks. Define J(y,z)=integral U_y(x)h_(R(x))(x-z)dx, so the actual integrated pair kernel K(y,z)<=J(y,z). The physical fixed-source point envelope gives Z_y=integral U_y dx<=A_n Csoft_n/q_-<infinity. If Z_y=0, J=K=0 and all new row objects may be zero.

The unnormalized construction omega_t=1-exp(-tQJ), Q=q_-a^n, is a real fixed-field source-only mask. It is the Poisson coverage probability for accepted cubes with intensity tQ U_y(x)R(x)^-n dx. The intensity is finite, and
 integral omega_t nu<=tQ integral J nu
 <=(16/3)t A_n Csoft_n Q.
The EXACT current-traffic remainder is integral K exp(-tQJ)beta nu. On J>=h/(tQ), omega_t>=1-exp(-h), giving the corresponding reciprocal capture payment. For delta>0, exp(-x)<=(delta/e)^delta x^-delta gives the stated negative-overlap-moment remainder with KJ^-delta=0 at J=0; no favorable bound on that moment follows automatically.

The strengthened normalized construction is also valid and removes A_n Csoft_n from its capture threshold. For Z_y>0 define pi_y(dx)=U_y(x)dx/Z_y and Poisson intensity
 eta_y(dx)=(exp(H)/4)(a/R(x))^n pi_y(dx).
Its total intensity is at most exp(H)/4, while its expected normalized witness volume sum(R/a)^n is EXACTLY exp(H)/4. The dimensionless original overlap
 P(y,z)=integral(a/R(x))^n1_QR(x)(z)pi_y(dx)=a^nJ(y,z)/Z_y
 lies in[0,1], and noncoverage is exp(-exp(H)P/4). Discard configurations whose total normalized volume exceeds exp(H). Markov bounds the discard probability by1/4. The retained-union expectation omega_H has true row capacity(16/3)exp(H)Q, and
 P>=4log(4)exp(-H) implies omega_H>=1/2.
Hence the SAME original P-high traffic is at most2 T_(omega_H), with no source-density condition, and can use the R296 joint row fee. With kappa_star=2K gamma^(n/2)/(ell M), a safe raw price is
 2[1+(4/3)log_+((64/9)kappa_star exp(H))](W_beta+W_nu).
The exact weaker-P original kernel remains. P retains the real(a/R)^n scale penalty; it is not automatically large on every contributing pair.

Joint measurability requires no argmax or simultaneous sample process across uncountably many rows: the Poisson expectation can be defined by exp(-eta_y(E))sum_(m>=0)1/m! times the m-fold intensity integral of the measurable retained-volume indicator and union-coverage indicator. Every term is nonnegative and jointly measurable in(y,z), so the series defines a measurable probability kernel.

The new masks depend on the FULL original field but not the CURRENT integrated receiver x. R296's fixed-field FIRST/height proof remains valid under exactly this weaker frozen-mask requirement: omega<=1 for FIRST and its fixed beta column mass for the height estimate. This must be stated as a fixed-field extension rather than silently relying on the older stronger field-independence phrasing. Integrating across an external clock/seed is a separate bookkeeping obligation: joint measurability, original fieldwise caps and the actual weighted source ledger must be proved. The Poisson decomposition does not alter original e,m or gates and does not supply those outer budgets.

## Scale-budget author file review

PASS for /tmp/r297_scale_budget.md SHA256 cd1fd4c3823c3c5be7b2e0472cd319989b7c80bfacf6a0a975db560718f9ddff. Equations1--18 match the independent own-scale row proof and refined coefficient above. The original low/high point height is used before positive receiver extension, both orientations share the min of two actual heights, and the exact finite hard envelope has crossover G^4 and the stated Psi_G branches. The universal3-2/(3e) constant and large-orientation2 bound are correct. No FIRST at a new source or future scale is used.

The nonconstant frozen r(y) is legal and measured at its OWN row capacity; the actual original L,R>=r(y) gate remains on the left. The multi-block theorem sums the full r_k^-n nu(omega_k) beta source price and requires aggregate source weights<=1. A witness at a larger radius than the actual retained minimum scale is not granted unit capacity for free. The single-witness beta partition creates a genuine covered branch and retains the exact complement. The finite minimal-radius source partition covers precisely the pairs in its witness union whose actual min(L,R) permits at least one witness; countable unattained minima are explicitly not used as witnesses.

Original FIRST may independently pay the SAME aggregate allocation once; the stated minimum with the own-scale source price is valid. All source reuse, witness existence/measurability, physical scales, original e,m and source/history qualifications remain explicit. The proof does not claim general cover existence or outer-clock closure. No correction requested.

## Normalized witness author proof review

PASS for /tmp/r297_witness_geometry.md at current SHA256 564e64418f5b9ae4a8c273f6b2c4a77ca2403a2b28a9785b44395ab106b9863b. W1--W15 match the independent normalized Poisson proof above. I_y is finite by the full actual common-soft point envelope; zero-I rows carry zero original pair traffic. The finite intensity has expected normalized volume exactly e^H/4, and its total mass is at most that. W8's finite Poisson series includes every retained configuration because each witness volume is at least1. Joint measurability follows termwise and no argmax selection is required. Original receiver null exceptions are harmless because every sampling intensity is absolutely continuous in the real dx.

Each realization's same-radius original hard cap gives the stated row budget; union overlap cannot increase it. Markov discard<=1/4 and exact uncovered probability exp(-e^H P/4) yield omega>=1/2 on the explicitly normalized P-high branch. The R296 mixed-source coefficient uses C=(16/3)e^H, so its log argument is(64/9)kappa e^H and the capture factor is2. No coarse S enters that capture threshold.

The proof explicitly re-establishes R296 for a mask formed from the fixed entire field but held independent of the current receiver variable. It does not rely on probabilistic field independence, does not rebuild original e/m, and retains the actual clock-dependent source fee in its outer integral. The weak-P original kernel remains; W15 and the untruncated Poisson error have their correct product-mass costs and do not pay it for free. No correction requested.

## Combined original-traffic accounting review

PASS for /tmp/r297_integration.md at current SHA256 aeacb5cf91de5f4c67d2eec6f1a0ff706eda9f5a63147039534bdb17f239a4d1. The fixed original Irow dominates I0 and retains the true accepted-receiver support/caps. The disjoint algebra is exact: (1-N)+NB+N(1-B)1_high+N(1-B)1_weak=1, with high/weak threshold equality assigned high. On Z_y=0 the actual original row traffic is zero rather than an ignored positive term. Own-scale NB is a positive suballocation of B and may use its full explicit source fee without a negative credit.

For the residual allocation, I0 N(1-B) is still between0 and1 and keeps original low/high. Hence beta FIRST and the same pointwise height apply before any receiver extension, even though B contains actual scale gates. The Poisson mask itself is independent of the current receiver. High capture is pointwise dominated by twice that weighted residual; the combined coefficient64/9 and G kappa0 are correct.

The component witness note uses M=1 in its displayed traffic, but its probability/capacity construction W1--W4 is independent of M. The main's m>M application is justified by using the general original R296 height with kappa*=G(2K/(ell M)); no constant or threshold loss is introduced.

Equation3 follows from actual residual pair kernel<=J=ZP/a^n, fixed near source relation and P<rho_H, giving the local nu(Q_(2Db)(y)) expression and then rho_H S W_beta W_nu/Q. It remains bilinear, with no favorable source-mass relation assumed. Lambda is applied once and actual varying outer/source/clock fees remain explicit. The integrated result is a constructive payment of three actual pieces plus an exact unpaid weak-capture remainder, not a claim of general coverage or a mere new name as a paid bound. No correction requested.

## Final normalized-witness scope update

The final witness file now explicitly uses original m>M for every M>0 and kappa=2K gamma^(n/2)/(ell M), agreeing with the already audited integration theorem. This removes the earlier presentation difference M=1 without changing the probability construction or source proof. Its final evidence section distinguishes the author's local finite examples from the independent reproducible Poisson checks. Mathematical PASS remains unchanged.

## Final README and frozen integration receipt

PASS. The final README matches all three mathematical files. It defines ell,gamma,G,q_- and raw low normalization, states that original Lambda is multiplied once and varying outer fees require their original ledger, and now makes the root-polylog capture price conditional on BOTH H and log_+kappa_* being root-polylog. The own-scale theorem retains actual min(L,R)>=r(y), frozen witnesses, exact normalized row cost, and its complement. The normalized Poisson theorem constructs a measurable common fractional cover and proves pointwise domination only on the stated P-high branch. The combination is exactly far, own-scale, high-capture and weak remainder in that order, with source costs added and no repeated/negative credits.

R_weak is the SAME original near traffic not covered by the own-scale allocation and below the normalized capture threshold. Its honest product-mass bound still contains W_beta W_nu/Q; neither exponential smallness of the threshold nor average witness coverage pays it automatically. The real(a/R)^n penalty, per-row source reuse, all original gates and fixed-field versus outer-clock distinctions remain. No full-source or general weak-type closure is claimed.

Final numerical records were read after the parent's actual exit0 reruns. Main JSON SHA2565679d34ccdeb4e23423ca86794fc7ed21b2c905cbe97e0208ae7fc5eaea3dd33 and Poisson JSON SHA256340934bd9de04aaedc2707d37375532829eaae77f66437275045cb21399421a7 match the frozen reports. The scale log records28 envelope comparisons and240 actual-band checks PASS. README counts agree with the recorded stage totals; finite matrices and ordinary high-precision values are not asserted to realize full original soft histories or interval certificates. This audit's independent15 shell-occupancy and20 own-scale coefficient computations are additional local diagnostics. No new final rerun was required.

Final proof/report hash bindings:
- /tmp/r297_integration.md: SHA256 aeacb5cf91de5f4c67d2eec6f1a0ff706eda9f5a63147039534bdb17f239a4d1
- /tmp/r297_scale_budget.md: SHA256 cd1fd4c3823c3c5be7b2e0472cd319989b7c80bfacf6a0a975db560718f9ddff
- /tmp/r297_witness_geometry.md: SHA256 622d3d0780c4bae7792d44f9b65678d664ff5664a42e88d4837e0a9e78d3f301
- /tmp/r297_README.md: SHA256 910cc83f7a8ae8772016bc5cbc9f35e756c736ccd7bdc219a657b373bed4fd0b

Final unresolved work is a root-compatible bound for R_weak or another common source allocation paying it, together with all remaining original continuous high-score, initial/jump/deletion and outer/source/clock ledgers. The normalized cover and own-scale source budget are proved constructive tools with explicit captured traffic; they do not establish existence of an affordable cover of every remaining edge.

Final verdict PASS; audit frozen. Only this owned temporary audit was edited, with no repository, Git, PDF, upstream author edit or further research.

Historical-scope clarification: the earlier sentence “The component witness note uses M=1” describes ONLY the early witness draft SHA256564e64418f5b9ae4a8c273f6b2c4a77ca2403a2b28a9785b44395ab106b9863b. It is superseded by the final witness SHA256622d3d0780c4bae7792d44f9b65678d664ff5664a42e88d4837e0a9e78d3f301, which uniformly states original m>M for M>0 with kappa=2K gamma^(n/2)/(ell M). The final binding and PASS apply to that generalized final version. No pending M=1 limitation or proof correction remains.
