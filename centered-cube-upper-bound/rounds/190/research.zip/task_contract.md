# R190：小初始停止块与目标未来放大的联合预算

上一轮为进展：R189独审、数值重放与紧凑归档已推送1581d42bdf627223d62f9f30e264f542dec1c32d；本轮开始main工作区干净。

原目标仍是任意正L1输入的一般n^(1/2+o(1))弱型上界，未闭合。当前准确剩余：R189近outer–bad来源但初始停止块较小、good目标重叠极小的原正J-share交通。目标为HB16或保留原四缺口的同等弱式：EΣV∫q dx∫ψλ ≤ ε∫qdx+Cε√n polylog(n)WA。

允许工具：R183完整行删除与四非负缺口，R188实际λ current-product支配及outerbad分离付款，R189原FULL网格law、preθ current、任意小大初始块吸收、Rκ与精确target未来损失JG14和同钟转移JG17。原冻结备份在output/centered_cube_round189_20261016_final_checkpoint。

小块只推同一初始阈值下的S祖先heavy；不得换成β/ν质量或终端阈值。light有h帽，heavy fallback没有；不得假互支配、来源与网格独立、目标current小即未来损失小，或把S^n/H及指数放大漏掉。所有来源、真实dx、窗口、尺度和极限费用保留。

分工：Astra r166_raw_budget独占small_block_joint_budget.md，攻目标未来放大与小块联合几何；Sol r166_exact_certificate独占heavy_parent_budget.md，攻原祖先阈值和来源费用；Sol r164_audit独占independent_audit.md，先独筛后读作者稿；主推导、实际本机数值、整合与Git。不要互改文件、不子代理Git/spawn，有界任务完成后停止。

使用E03技能核质量传递、平均/路径区别及终端项，不引用未经迁移核验的Bellman常数。若需要数值，将先给准确命题，初探、已有边界压力和扩大范围三阶段；数值不替代一般证明。完成一轮才精简归档并独立提交推送，无PDF。
