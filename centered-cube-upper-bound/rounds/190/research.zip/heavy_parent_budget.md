# R190：小初始停止块的重祖先、current 响应与准确来源价

本稿将原小块必要条件接到同一输入的 current/FIRST，给出全混合软核、自适应物理尺度下的一个实际线性来源预算公式。其几何系数一般指数大，未达到 root 价；不能用比例带可求和性掩盖该系数。原 target/same-alpha 的进一步削减由本轮另一稿处理，本稿不重复其储备论证。

## HP1．原对象、初始支持及来源范围

固定一个合法共同窗口及原概率空间。沿已审 R189 GB1–3，FULL 网格层为 `S_k=2^k d_0,d_0=a/n,0≤k≤J_tree`，同一原 θ 平移，顶边长 D_top。原 current

\[
 p_x(z)=P_{s(x),L(x)}(x-z),\qquad \int p_x\,d\mu_{\rm hi}\le q
\]

及完整 f、q、接收域在该 θ 之前固定。原阈值质量是

\[
 h(Q)=\mu_{\rm hi}(Q\cap B),\quad
 d\mathfrak h=1_B\,d\mu_{\rm hi}\le f(z)dz,
 \quad M_h=\|\mathfrak h\|.                         \tag{HP1}
\]

B 使用原出生网格及原出生标签，不随本稿重新选择。h 不是 β、ν 或当前 V 内的 captured mass。其总来源预算记为 `W_h=E M_h≤W_hi≤||f||_1`；若不能另证原 h 限制在当前共同父来源上，不能把 W_h 自动改成较小的 W_A。原 `W_β≤W_A≤||f||_1` 仍可用于下文尾项。

固定比例带 j，`γ=1+1/n,c_j=γ^{-j}`，原初始时刻记为 ell，终端 `g=√(LR)`。R117 JG1–2、R128 RT4 及 R183 RCG1 的准确资格是

\[
 a/c_j\le\ell\le g\le bc_j,\qquad
 R_y\subset Z_\ell(y)
 =D_V(y)\cap(T_0(y)\setminus A_{j,\ell}(y)).          \tag{HP2}
\]

后者是初始块支持，不能对稍后删除的 bad u 自动换成终端块支持。辅助时间积分中 ell 和这一初始块沿完整行冻结。阈值为

\[
 H_j(t)=q\max\{t^n,\sqrt n\,c_{j+1}^nt^n,
                                      \sqrt n(t^2/b)^n\}.        \tag{HP3}
\]

其定位为 R114 `proof.md` S1–S4（221–250 行），以及 R117 JG1–2（29–52 行）。light 判据是 `h(A)≤H_j(t)`，等号归 light；无 light 的原最细 heavy fallback 保留。读 E03 技能后，本稿只使用同层格的真实质量守恒，不调用其未迁移的 Bellman 势或跨层望远镜常数。

## HP2．确定祖先确为同一初始阈值下的重格

固定原确定层 `S>d_0`。若

\[
 \operatorname{side}(A_{j,\ell}(y))<S,
\]

则该路径上的 S 格 `Q_S(y)` 满足

\[
 h(Q_S(y))>H_j(\ell).                               \tag{HP4}
\]

若此祖先为 light，它就是一个边长至少 S 的可选 light 节点，原最粗 light 不可能更细，矛盾。fallback 情形沿整条路径没有 light，故也满足 HP4；没有用一个不存在的 fallback light 质量帽。对 S>d_0，反向也成立：若 S 格 heavy，则其全部祖先质量更大，选中的 light 或最细 fallback 必在 S 层之下。S=d_0 时小块事件为空，不使用这个反向说法。

HP4 使用 `H_j(ell)`，不能换成更大的终端 `H_j(g)`。S 必须是同一原 FULL 层，不是另一套独立终端叶的侧长；半开边界均按原唯一归属处理。

## HP3．原时钟和物理尺度的精确阈值价格

由 HP2 及 HP3 的单调性，原行无条件只有

\[
 H_j(\ell)\ge H_j(a/c_j)=q a^n B_j,
\quad B_j=\max\{c_j^{-n},\sqrt n\,\gamma^{-n},
                  \sqrt n(a/b)^nc_j^{-2n}\}.         \tag{HP5}
\]

第二项中的 `γ^{-n}` 来自 `c_{j+1}^n c_j^{-n}`，不得漏掉。这个下界独立于 θ、当前 y 和停止规则，可以在固定 j 下使用。

更精确地令 `m=min(L,R)`、`η=ell/g`、`z_j=c_{j+1}g/m`。原半开比例带和最后闭带给

\[
 \gamma^{-1}\le z_j\le1,\qquad
 {a\over c_jg}\le\eta\le1,
\]
\[
 {H_j(\ell)\over q}
 =\max\{(\eta g)^n,\sqrt n(\eta z_jm)^n,
                         \sqrt n(\eta^2g^2/b)^n\}.   \tag{HP6}
\]

所以任意待支付 receiver 长度 d 的准确必要价格包括

\[
 {q d^n\over H_j(\ell)}
 ={d^n\over\max\{\ell^n,\sqrt n(c_{j+1}\ell)^n,
                                  \sqrt n(\ell^2/b)^n\}},
\quad
 {q L^n\over H_j(\ell)}
 \le {\gamma^n\over\sqrt n}\eta^{-n}(L/m)^n.         \tag{HP7}
\]

这不是宣称右侧小。若 L 是较大尺度，`(L/m)^n` 是实际比例损失；若初始时刻远于终端，`η^{-n}` 同样不可删掉。只有另加实际初始钟比、同尺度和 receiver 尺度资格，才能把 HP7 特化为小常数。原物理窗的 `b/a≤2` 仍允许 `(b/a)^n`，并不提供维数无关的同尺度比较。

## HP4．重祖先与同 current 响应的直接必要式

设 Q 是实际重 S 格。记其闭包坐标端点 `q_i^-,q_i^+`，并定义

\[
 D_i(x,Q,L)={\max\{|x_i-q_i^-|,|x_i-q_i^+|\}\over L},
 \quad b_s(r)=(1-s)1_{[-1/2,1/2]}(r)+s\phi(r).
\]

原 b_s 偶且在正半轴不增；闭硬面按原定义保留。因此对全部 z∈Q，

\[
 p_x(z)\ge L^{-n}\prod_i b_s(D_i).
\]

结合 `h(Q)>H_j(ell)`、`mathfrak h≤f dz` 和同一个 FIRST，若该乘积正则有

\[
 {H_j(\ell)\over L^n}\prod_i b_s(D_i)<q.             \tag{HP8}
\]

乘积为零时只得平凡的零下界，不作除法。该式完整保留硬面 crossing 与 soft 衰减，没有用 logconcavity 或将 y 的 current 值无损搬到整个 Q。特别若 Q 全在 current 闭核心中，则 `prod b_s(D_i)≥m_s^n`，`m_s=1-s+sφ(1/2)`，故必须 `H_j(ell)m_s^n<qL^n`。这里的 `m_s^n` 也不可免费删除。HP8 是真实共同输入几何约束，本身尚不是接收积分付款。

## HP5．一个包含全部软度和自适应尺度的尾包络

为给重格的 receiver 价一个可直接积分的完整版本，使用以下自含正包络；宁保留可见的多项式选择费，不使用固定尺度积分代替自适应积分。

令 `A_{k,L}(z)` 为所有含 k 个 soft φ 因子、其余 hard h 因子的尺度 L 产品核的平均。它是概率密度，且

\[
 P_{s,L}=\sum_{k=0}^n {n\choose k}s^k(1-s)^{n-k}A_{k,L}
                        \le\sum_{k=0}^n A_{k,L}.
\]

每个 `L^n A_{k,L}(z)` 随 L 非减，包括 hard 跳点。正的 Stieltjes 分部积分给

\[
 \sup_{a\le L\le b}A_{k,L}(z)
 \le A_{k,b}(z)+n\int_a^b A_{k,t}(z){dt\over t}.
\]

因此

\[
 \mathcal M_{a,b}(z)=\sum_{k=0}^n\left[A_{k,b}(z)
                    +n\int_a^b A_{k,t}(z){dt\over t}\right]
 \ge\sup_{s\in[0,1],\,L\in[a,b]}P_{s,L}(z),
\quad \int\mathcal M_{a,b}\le(n+1)(1+n\log(b/a)).    \tag{HP9}
\]

只是在核展开中用张量，未假定输入 f 或来源坐标独立。对 `R_0≥b/2`，hard 因子无尾。写原 `φ=h*w`，`w(r)=∫_0^1e^{-|r|/t}dt`，则对 `v≥1/2`

\[
 \int_{|r|>v}\phi(r)dr
 \le\int_{|r|>v-1/2}w(r)dr
 =2\int_0^1 t e^{-(v-1/2)/t}dt\le e^{1/2-v}.
\]

逐核坐标并集界及 t≤b 给完整尾费

\[
 \int_{\|z\|_\infty>R_0}\mathcal M_{a,b}(z)dz
 \le E_n(R_0):=(n+1)(1+n\log(b/a))n e^{1/2-R_0/b}.   \tag{HP10}
\]

HP10 保留了 softness 的 n+1 菜单、径向 scale 费用和 n 个尾坐标；不是把 soft 部分当 hard 核。端点和硬面点态由 HP9 控制，Lebesgue 尾积分中的面不另收费。

## HP6．重祖先实际 receiver 积分的线性来源价

固定 j、确定原层 S>d_0 和确定 `H_0>0`，并将原完整行限制到
`side A_initial<S` 且 `H_j(ell)≥H_0`。最初坏集合、同 α、ψ、high、history 均仍原位。该限制沿完整辅助时间行固定，可先在 R183 的较小 bad/整行上应用完整删除界，再使用 HB 的 λ；不是在某个时刻假装整个时间行都有小块资格。

令 U_ω 为该 S 网格所有 `h(Q)>H_0` 的格的并。HP4 保证这些原 y 在 U_ω 中。同一层的格不交，故

\[
 \#\{Q:h(Q)>H_0\}\le M_h/H_0,\qquad
 |U_\omega+[-R_0,R_0]^n|
              \le{(S+2R_0)^n\over H_0}M_h.           \tag{HP11}
\]

这里是原完整 h 的一次同层质量账，未将同一个重格对每个 V 重复领质量。此估计逐 θ 成立，不需要在停止后重新假设均匀相位。

HB11–12 给 `Σ_V||λ_{x,V}||≤1` 以及 y 边缘 `λ(dy,R^n)≤p_x(y)β_V(dy)/q`。在 x 属于 HP11 扩张集时用前者；在其外而 y∈U_ω 时，`||x-y||∞>R_0`，用后者及 HP9–10。于是原真实 dx 上

\[
 \mathbb E\sum_V\int_{E_j}q\,dx
        \int1_{\rm small,\,H\ge H_0}\psi_y\,d\lambda_{x,V}
 \le {q(S+2R_0)^n\over H_0}W_h+E_n(R_0)W_\beta.     \tag{HP12}
\]

扩张集内没有使用 β 密度帽；扩张集外没有对 current s(x),L(x) 固定尺度后免费积分。原 fixed-current product 和 same-alpha 均保持合法，只在已审 λ 容量及 `ψ≤1` 中正向放松。乘 HB13 系数 `C_rec=16Λ/(3Kκ)` 即是此原正 raw 子支的完整来源付款。

特别取 HP5 的合法 `H_0=q a^n B_j`，得到

\[
 \operatorname{Raw}_{{\rm small},j,S}
 \le C_{\rm rec}\left[
       {((S+2R_0)/a)^n\over B_j}W_h
                         +E_n(R_0)W_\beta\right].    \tag{HP13}
\]

可把 R_0 取大而使尾费任意小，但同时扩大首项的 `(S+2R_0)^n`。这笔权衡不能丢掉任一项。HP13 对原任意正 L1 输入成立，提供准确的线性完整来源价；不声称该价格有目标维数阶。

## HP7．比例带、网格菜单与原父质量重复费

若全部 j 使用同一 S、R_0，首项的准确重复价为 `Σ_j B_j^{-1}`。令

\[
 C=\sqrt n\,\gamma^{-n},\qquad
 j_0=\max\{0,\lceil\log C/(n\log\gamma)\rceil\}.
\]

由 `B_j≥max(γ^{nj},C)`，分 `j<j_0` 与其余几何尾得

\[
 \sum_{j\ge0}B_j^{-1}
 \le{\gamma^n\over\sqrt n}
        \left[j_0+{1\over1-\gamma^{-n}}\right]
 =O(\log(n+2)/\sqrt n).                             \tag{HP14}
\]

有限实际比例带只会减小该和。若 current j(x) 在每个 receiver 唯一、β_V 是同一原冻结来源且 R_0 统一，尾项可以只收一次 `E_n W_β`：保留 `1_{j(x)=j}` 到尾部已变成同一个条件 `||x-y||∞>R_0` 后再求和。首项的不同 heavy 集空间覆盖仍须支付 HP14，不能同样删去 j 求和。若这些共同资格不在，安全版本是分别相加全部 HP13，包括尾费。

若 receiver 预选不同 S 层，来源覆盖的安全价还需对其确定层取值相加：与 R189 的逐点 receiver 小系数不同，不能以“每个 x 只选一层”消去这些不同重格扩张区域的来源总价。不同 birthcarrier、原窗口或重新运行森林也须按各自原总账收费，不能各自使用完整 W_h/W_β 而不累加。h 总量可受完整 f 控制，但原 source budget 并不提供每窗新的 `λb^n` 质量帽。

## HP8．本稿取得的付款与首个尚未解决之处

HP4–8 给准确的初始重祖先事件及其同 current 响应限制；HP12–14 给保留全部混合、receiver 和菜单费用的真实线性来源公式。即使比例带和为 `O(log n/√n)`，首项仍含 `((S+2R_0)/a)^n`；按原 ell/g 或 L/R 作较细分层时，HP6–7 的指数钟比和比例价格也必须登记。原小块祖先并未保证 receiver 所需体积与 H 的物理长度相匹配。

因此没有从本稿得到 R189 所留整个小块近对的 root 价，也没有把未付量换名为免费树能量。建设性剩余桥是：利用原实际 current/FIRST 与 target 的 same-alpha 几何，同时减少 HP12 的 receiver 覆盖体积或其真实权重，而不恢复被丢掉的指数/层数成本；本稿没有证明这一步。heavy fallback 已完整包含，原负 suffix 信用和四删除缺口未被重新借用。到此冻结本路线范围。
