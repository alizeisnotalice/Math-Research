from fractions import Fraction as F
from pathlib import Path
import json
rows=[]; gates=0
for d in [F(0),F(1,100),F(1),F(100),F(10**6)]:
 for w in [F(1),F(101,100),F(2),F(16),F(2**20)]:
  phi=min(d,w-1)/(1+d)
  for v in [F(0),F(1,2),F(1)]:
   z=max(F(0),(d+v)/w-v)
   exact=1/(1+z)-1/(1+d)
   assert F(0)<=exact<=phi<=d/(1+d)
   for eta in [F(1,100),F(1,4),F(9,10)]:
    assert (phi>eta)==(d>eta/(1-eta) and w>1+eta*(1+d))
    gates+=1
   rows.append({'d':str(d),'exp_sigma':str(w),'Gg_over_e':str(v),'z_lower':str(z),'endpoint_difference':str(exact),'F_bound':str(phi)})
Path(__file__).with_suffix('.json').write_text(json.dumps({'cases':len(rows),'gate_checks':gates,'rows':rows,'scope':'Finite exact scalar endpoint-envelope and residual-gate algebra; not construction of original coalescence, alpha or FULL input.'},indent=2)+'\n')
print({'cases':len(rows),'gate_checks':gates})
