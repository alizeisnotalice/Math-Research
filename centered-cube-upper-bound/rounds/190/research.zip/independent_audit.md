# R190 独立前筛检查点

只写本文件，不Git/spawn/实验/改他人文件。先按主代理准确消息独立筛查，未读本轮作者稿；首次读取时task_contract.md尚未落盘，待其补齐只核scope。目标是R189剩余small-initial-cell近outerbad/tinygood的HB16，原一般√n来源+εreceiver账尚未闭合。

## 1. 小初始停止块的heavy祖先：准确成立范围

固定一个原有效行的同一h、j、初始辅助时刻ell_y及其H_j(ell_y)>0。S必须是同一原FULL嵌套树的合法层，S≤D_top。若原最粗light节点A_{j,ell_y}(y)边长<S，则Q_S(y)为该路径祖先。假如h(Q_S(y))≤H_j(ell_y)，它是light，最粗light选择不可能比S更细，矛盾。因此

    side A_initial(y)<S ⇒ h(Q_S(y))>H_j(ell_y)。

等阈值归light，故上式为严格>。没有任何light时原最细fallback同样满足每个祖先heavy；不需要fallback本身享light质量帽。S=d0时严格small支为空；S>D_top时不允许臆造原祖先。side A=S本身不提供上述heavy推论。半开节点给唯一原路径，边界不破坏包含。

该结论是逐样本逻辑，ell_y、j、停止块可依原随机性；但必须使用实际初始时刻及同一原h。不能换终端g、另一个时钟行、ν或β质量，不能把A∩V仍称为同边长网格节点。原q>0、ell_y>0、有限合法窗口先限定；零分母/无交通行先置零，不靠除0获得heavy信息。

## 2. 真实可用的质量界与其费用

heavy祖先只给质量下界。对固定同一出生carrier的h及固定阈值H>0，同层格不交，得到heavy格数≤h(全域)/H，及其Lebesgue并集体积≤S^n h(全域)/H。这是体积界，不是β或ν的质量/边界密度帽。任意正L1输入无上密度，不能将该体积价直接当current加权来源价。若阈值随y/初始时刻变化，须保留实际阈值或先明确正下界；不同出生carrier/窗口不可未经原总账重复合并此计数。

若有合法固定下界H_j(ell_y)≥H_*>0，因原h(Q)≤μ_hi(Q)，可逐样本正放

    1_small ≤1_heavy ≤H_*^(-1)∫1_{z∈Q_S(y)} μ_hi(dz)。

接入HB的product支配后，这引入真实第三来源及inverse H_*，并保留same-cell(y,z)与cross-cell(y,u)的同一随机相位联合事件。不能将这两个事件当独立，也不能条件化heavy后继续假uniform。丢same-cell再积分z会留下||μ_hi||/H_*，未给目标预算；S^n/H的大价亦不得隐藏。没有ν≤β、leaf密度帽或免费Carleson/root可替此费用。

## 3. 原积分和时间资格

R189已证current/接收域/q先于原FULL平移固定、μ_hi及两来源共父支配；正Tonelli允许按实际dx和固定pair平均。S(x)若在θ前从原有限层中可测选取，逐x逻辑仍成立，无选层数费；使用θ后的heavy质量挑S则不能直接套固定层概率。

实际目标仍是EΣV∫q dx∫ψλ。λ、ψ和same-alpha原终端target不可因heavy推论改成固定参考。若对子交通应用R183完整删除/饱和行，须先固定该行的初始small指示和bad子集，再做完整时间积分；瞬时A_{j,t}的小块指示不能无账搬过FTC。Rκ仅在原reciprocal、ξ_g≥1/2的同一物理窗口使用，||y−u||1≤bRκD_b不控制good未来放大。

## 4. 独立阶段结论

所给heavy祖先逻辑通过，且包括heavy fallback；它提供真实原质量信息，但尚不构成HB16付款。首个待证量仍是该heavy祖先约束与small-block/未来target损失在同一λ、同α、真实q dx下的联合预算。当前不把未知增量或三来源价另命名为已付。等待合同与准确作者命题后一次后审，不扩反例搜索或重复作者攻坚。

## 5. 合同补核及E03使用范围

随后已读落盘task_contract.md，scope与上述独筛一致。按合同读取E03的SKILL.md、provenance.md、cube-interface.md，仅使用其树质量/逐路径与平均/终端项的资格核验流程。本轮未迁移引用任何外部Bellman常数，未访问PDF或将普通树势自动用于原来源交通。heavy祖先的路径逻辑不自动给平均层预算；若后续拟望远镜，必须先给到达质量m(child)=m(parent)p、节点费及终端项符号。

## 6. 作者准确parent-kernel候选：先筛未读稿

收到Astra精确消息后独推：非top原A的parent P未light，h(P)>H_j(ell)。设d=side(P)，y,z∈P，有|z_i−y_i|≤d。若L'=L+2d≤b，则原hard支持在新尺度包含；soft用偶递减及原logφ的Lφ-Lip得到

    f_s(|x_i−z_i|/L')≥exp(−Lφ d/L') f_s(|x_i−y_i|/L)。

含s=0及closed hard face。故同s的合法future核满足

    inf_(z∈P) P_{s,L'}(x−z)≥c p_y,
    c=(L/L')^n exp(−Lφ n d/L')。

原FIRST和h载体≤f给q≥∫P P_{s,L'} dh>c p_y H；high正行p_y>0遂p_y<q/(cH)、e_g>2KcH。H=q ell^n M_j时给作者相同归一。top、L'>b及无有效parent分支另留；极小c的逆费不能省。fallback只用其未light父，不套fallback light帽。

后续reserve分拆须保h(P)=μ_hi(P∩B)的真实carrier，不可直接减去未限B的ν(P)。同P∩B上的ν及μ_hi−ν分拆合法。原K0 FIRST与ν≤μ_hi给αQJ≥D K0(μ_hi−ν)，但把上述parent质量接入此式还需要实际K0在同P上的下界；新future核P_{s,L'}不能代替K0。此候选提供有条件准确约束，尚未支付原remaining branch。

## 7. 新实际删除截止付款：先筛

作者及主代理准确消息的有价子支通过。固定整行初始heavy祖先P及u∈R_y∩P，r=h(P)/H_j(ell)>1。H_j(t)=q max(A_j t^n,B t^(2n))，其中A_j=max(1,√n c_(j+1)^n)、B=√n/b^n。写σ=nlog(t/ell)、αbar=qA_jell^n/H_j(ell)、βbar=qBell^(2n)/H_j(ell)，max(αbar,βbar)=1，则

    σ_hit=min(log(r/αbar), (1/2)log(r/βbar))≤log r。

原常数均正；若推广零系数须将该项候选时间取∞，不能除0。P在hit时已light（等号计light），最粗light包含P，因此P内来源从Z中全删；实际dt积分终止在min(g,t_hit)。同刻阈值/删除的单点不产生dt费用。同原Π的双槽score取值[0,n]，E(kv−ku)+=∫_0^n p_a(1−p_a)da≤n/4；正放A与历史门后可用，得到

    I[A,R_P]≤min(nlog(g/ell),σ_hit)/4≤log r/4。

故原一次32Λ/3回代给Raw≤(8Λ/3)log r∫qdx；log r≤3ε/(8Λ)可付该明确子支εreceiver。唯一j先保留至逐行统一界，不收层数/time菜单，也不消费负信用。r大、u不在P、top/无共同祖先资格补集仍保留。若所用bad版本只含Z_g来源，hit≤g的P内支本来空，不能报严格新增coverage。

作者的精确剩余target窗口亦通过：z(t)=G_A(t)−G_A(g)递减，e_t≥e_g+z(t)，N_R≤N_ell，故以t_P=min(g,t_hit)

    I≤N_ell[1/(e_g+z(t_P))−1/(e_g+D_A)]。

端点差非负；来自ell..t_P上−dG_A/(e_g+z)^2，不扣补集或额外缺口。

canonical LCA强化先筛通过：在原固定D_y、同T0且u初始alive的范围，P=LCA(y,u)半开唯一；初始alive保证双点不在同一个最细fallback格。于是

    u∈Z_t(y) ⇔ H_j(t)<h(P)。

若h(P)>H则所有含双点祖先均heavy，light选择或fallback均排除u；若h(P)≤H则P已light，coarsest包含u。原R_{r0}={u∈R_y:h(LCA(y,u))≤r0H_j(ell)}沿整行固定，全部在共同hit(r0)前消失，可直接用上述n/4和future差，不按LCA层求和。并非依time重新条件化后验。

## 8. 辅助阈值/体积与尾包络：先筛

Sol精确候选通过：ell≥a/c_j给

    H_j(ell)≥q a^n max(c_j^(−n),√n γ^(−n),√n(a/b)^n c_j^(−2n))。

第二项来自c_(j+1)=c_j/γ，不可漏γ^(−n)。令g=√(LR)、m=min(L,R)、η=ell/g、z_j=c_(j+1)g/m，则作者H/q的三个max项(ηg)^n、√n(ηz_jm)^n、√n(η²g²/b)^n为精确代入；无η≈1资格。

固定同h与H0正下界，heavy S格扩R0邻域体积≤(S+2R0)^n||h||/H0。inside用λmass≤1，outside用实际y边缘≤pβ/q，R0≥b/2时可付

    q(S+2R0)^n||h||/H0
      +(n+1)(1+nlog(b/a))n exp(1/2−R0/b)Wβ。

(n+1)为非负Bernstein系数的soft平均包络，scale用原径向单调层包络；φ尾由h*w概率混合给e^(1/2−R0/L)，hard尾在该R0为零。此保留真实adaptive s/L费用，属于准确但一般很大的价。所有原carrier/j/S/window的质量和重复费另计；不能把它登记为一般√n付款。等待准确成稿后再作全文核验。

## 9. 主稿与重祖先稿全文后审

已读coalescence_clock_budget.md CC1–6全文，与§7独筛一致，通过。CC2另有σ_hit≥(1/2)log r：由a0,b0≤1知max(a0e^σ,b0e^(2σ))≤e^(2σ)，方向正确。实际8Λ/3及统一log r门先逐完整行后uniquej，未偷消菜单。CC6保留同A/同R的未来窗口，不消费补集缺口。

已全文读heavy_parent_budget.md HP1–14，通过。HP2反向仅S>d0使用正确；HP5–7尺度价、HP8闭核心约束、HP9–10自含正包络及HP12真实Lebesgue inside/outside预算与§8一致。HP14按j的几何尾界正确；只有共同冻结来源/同R0/uniquej才尾费一次，heavy覆盖仍逐j累计。W_h没有被误认为较小W_A，指数体积项完整，不能由比例带可和就报root。

## 10. 作者精确future缺口推论：先筛

固定同一R_P或R_{r0}及其共同截止t*，置σ*=nlog(t*/ell)、d=D_A/e_g。0≤score≤n且A支持Zg给G_A(t*)≥e^(−σ*)G_A(ell)，G_A(g)≤e_g，所以

    z(t*)/e_g≥[e^(−σ*)(1+d)−1]+。

代回CC6得I≤(N_ell/e_g)min(d,e^(σ*)−1)/(1+d)，仍兼I≤σ*/4。d=0时I=0；I/U≤min(1,(e^σ*−1)/d)只在d>0使用。若所用R确在t*前全删，N单调从N_ell降0，而φ(t)=1/e_g−1/(e_g+z(t))递减，则同一R的L_R=∫φ(−dN)≥N_ell z(t*)/[e_g(e_g+z(t*))]。hit>g仅有z*=0的平凡式；不可借其他R或补集的L_R。此精确加强先筛通过，等待作者实际成稿后核范围。

## 11. 作者全文与整合最终后审

已全文读small_block_joint_budget.md SC1–18及主proof.tex.txt/report.md/reproduce.py，通过。SC3只在initialalive范围写支持等价，SC7–9实际8Λ/3接收费、SC10–13同R的Stieltjes亏损与显式min界、SC14–18保expanded-current与actual K0差别，均与独筛一致。唯一必需措辞修订已落实：ν_P本已支持V，只可能已删除/不在D_y/不具原bad-good资格；最终0b3aaa…版已窄读。SC8明确不反推未减亏损的q∫ψλ小，terminal-surviving空支资格完整，无一般新增FULL覆盖认证。

两数值脚本及numerical_review.md已静态读，未重跑。60个扩尺度系数例中32合法，log-domain/tolerance非区间；12个Fraction双槽例含n=1实值中间score，只检bounded IID不冒称全为原整数score；80个clock例在40/60位共160评估，正系数max=1、r>1、截断σg=0和branch tie处理准确。clock row_bound是证明上界公式，不是实际交通实测；保存末精度结果、独立review重放记录及非physical标签一致。

reproduce.py读取后造manifest并核哈希，将两个脚本复制到新目录执行，逐byte比较完整JSON，失败非零；mpmath环境需求已报告。本审计未执行数值、未编译PDF、未Git、未动他人文件。最终归档driver另由主代理处理，不与本审计形成循环。

## 12. 主代理末次精确Tonelli加强：先筛

主代理在最终回执前送来一个明确逐u加强，先独推后待整合窄核。对原每个initialalive u，t_u=min(g,t_hit(r_y(u)))、σ_u=nlog(t_u/ell)；同一原A固定。N(t)≤∫R w_ell(u)1_{t<t_u}ν(du)，正Tonelli给

    I_H[A,R]≤∫R w_ell(u)[1/(e+z(t_u))−1/(e+D_A)]ν(du)
             ≤(1/e)∫R w_ell(u)F(d_A,σ_u)ν(du),
    F(d,σ)=min(d,e^σ−1)/(1+d)。

逐u使用§10的G下界合法，不要求σ_u独立或按LCA层分组。F≤η（0<η<1）是整行固定的bad子集，先保此子集、同A/α/d再应用上述界；actual HB λ回代给Raw≤Crec E∫q∫F dλ，故该子支≤Crecη E∫qdx。不是断言未减ψ势小。

剩余F>η严格迫使d>η/(1−η)、σ_g>log R，以及r_y(u)>max(a0R,b0R²)，其中R=1+η(1+d)。推导只用σ_u>logR及准确hit反函数，方向正确；等号归已付≤η支。d=0或σ_u=0时F=0。此为实际同R未来亏损的分布级接口，不含ν≤β或重归一。待主CC7/tex最终字节后重新绑定，原作者稿不需修改。

## 13. 末次整合窄核与最终冻结

已读主CC7–9、tex新增逐u段、report及reproduce最终修订；与§12独筛一致，通过。F只作为整行固定bad正门，不重算A/α/d；原32Λ/3到Crec归一正确，Σλ≤1与真实q dx给Crecη费用，重叠CC5/CC8先不交分割。剩余r>max(a0R,b0R²)及σg>logR是必要条件，二次项系数未省，不宣称一般root。

新source_deadline_checks.py静态通过：75个Fraction端点例及225次gate断言，后者只有75种独特(d,w,η)各随3种v重复。z选原下界、endpoint差取最坏允许值的方向正确，d0/w1/严格门及高动态范围正确；数值review已准确标非physical/FULL。未执行脚本。driver最终三脚本逐byte比较，原mpmath依赖和新目录要求保留；本审计不认证尚未运行的归档driver。

以下实算绑定14个其他最终文件；不绑定自身或尚未生成manifest，也不循环等待归档。原作者最终0b3aaa…保持冻结。

| 文件 | SHA256 |
|---|---|
| coalescence_clock_budget.md | d8dbfe66db24248b410341ebd02ab23374941c42619fb53d75db1ab8a69d5634 |
| heavy_parent_budget.md | 02e3809ef0430c0aa8d6dd754b2d3ef13928ff8088eba7fe1cf7ea0f9e26540d |
| numerical_review.md | 30569e1197a4c3e17d4930c05c286a6488259c55478a50f361dd286d4e30928d |
| parent_expansion_probe.json | ae5a73b729d17d337a717683a4ed9d75232bc4983c068b3a876fac6cd92325a2 |
| parent_expansion_probe.py | d20da5453ef27ce4beaadbd1cd2381075caf5a4986564b1e2382dfd08e43706b |
| proof.tex.txt | 05936df4a178a6f70492b5c01393cb7bcc37d33243232d79e2b74082d921b96a |
| report.md | 8535755078473a47665515f2ca478ab616875e3ab4220fd9be4f21f0d6ac4f17 |
| reproduce.py | 2f0f47b0d51c0c7216ed0a17aeb0e03d5efd6f889ebe9e7a4a43c96d8ac9399d |
| small_block_joint_budget.md | 0b3aaaacdf9495121c71c483150ab8076dcdfa718bd545c57fd68c6cbd09e382 |
| source_deadline_checks.json | ae4358ea03d98d3f138d5801a95292f9d3720f2ce9b4d49eeb68943f655cbaa7 |
| source_deadline_checks.py | c4977b87b5ca941efbd6c8b4293c1a87fd73cc3eb47c7726cc06c9db45553fa3 |
| task_contract.md | bbb817055b3f46a13f733f87a4d99838c92e01885a79602f44ac845d092720c0 |
| threshold_clock_checks.json | dea5dd340695e883017f1588e234daa6774623e299a9bed8c139cf9882cdad4d |
| threshold_clock_checks.py | 5ca5876bd56eeaf752fd4deca2621a83415a3ecafe424e4d1db9e3f75d7700ef |

冻结结论：原LCA有界质量超额的实际ε接收费及逐来源deadline/future-loss联合吸收通过。HP指数价格不计第二root；大超额、晚并块与tiny-good剩余仍未获得一般预算，HB16未闭合。没有Git/spawn/数值重跑/PDF/他人编辑。停止本轮审计。
