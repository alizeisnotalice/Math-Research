# R190：原共同祖先的并块时钟与保留 target 未来损失的正交通付款

本稿的主结果是原森林给出的实际删除时钟。对初始在场的 bad 来源 u，outer y 与 u 的原最小共同祖先质量决定两点何时被同一个 light 停止块包含，从而决定该来源何时退出原 Z_t(y)。共同祖先相对初始阈值的质量超额足够小时，原正 J-share 获得任意预定的小接收费；不需要按祖先层数求和。

同一时钟还强制原完整删除亏损中的一项下界，保留 same-alpha good target 在删源之后尚有的未来损失。由此得到一个实际非线性行界，而不是把未来损失另立为未知小矩。大质量超额、较晚并块的小初始停止块仍未获得一般根阶来源价。

本稿只编辑本责任文件。依据 R189 已核原 FULL 森林 law/停止规则，R183 完整删除身份，R186 IID 正 score 界，R188 HB 原费用回代。无 ν≤β、每叶密度帽、重选森林、独立后验假设或旧负信用。

## 1. 原行、原停止规则和合法的 pair 标签

固定原 (ω,V,j,x,y) 行，原初始 ell、终端 g，ell≤g，e=e_g(y)>0。所有当前/终端门、原 α_y、ρ_y、good 及终端 target 权在 t 积分前固定。写

    p_y=P_{s,L}(x−y),
    A_y(v)=1_good(v)ρ_y(v)J_v/(3Q_v),
    0≤A_y≤1,  supp A_y⊂Z_g(y),
    Π_t(dz)=1_{Z_t(y)}(z)w_t(y,z)ν_V(dz)/e_t(y).

可在 A 上保留原固定单 target 限制，例如 high-A、tiny-good。pair-dependent low-Fcal、history 与时钟限制留在原正乘子 H 中，不将其混入 A。score 满足

    −d w_t(z)=k_t(z)w_t(z)dt/t,  0≤k_t≤n.

原 support 及 mass-light 阈值为

    Z_t(y)=D_V(y)∩[T_0(y)\A_{j,t}(y)],
    h(P)=μ_hi(P∩B),
    H_j(t)=q t^n max{1,√n c_{j+1}^n,√n(t/b)^n}.    (SC1)

沿原 y 路径，A_{j,t}(y) 是最粗 h(P)≤H_j(t) 的节点；若没有 light 节点，取原最细格。等号归 light。h 与同一行的森林在整个时钟内固定，h 随包含关系单调。原格半开，同一最细层与每个祖先归属唯一。

以下只对 u∈Z_ell(y) 定义共同祖先。两点在同一 T_0 树，且不能在同一最细格：否则该格包含于 A_{j,ell}(y)，与 u 初始在场矛盾。令

    P(y,u)=LCA_ω(y,u),
    r_y(u)=h(P(y,u))/H_j(ell).                      (SC2)

P 是原树节点，不能换成截断后的 P∩V 或新网格。初始在场必有 r_y(u)>1。

## 2. 精确共同祖先时钟

对任一原合法 t∈[ell,g] 和初始在场 u，有准确支持身份

    1_{Z_t(y)}(u)=1_{H_j(t)<h(P(y,u))}.             (SC3)

右侧只在已经固定 u∈Z_ell(y) 的范围内写；一般全空间还须保 D_V(y)、同 T_0 及初始资格。

证明：任何同时含 y,u 的节点恰为 P 及其祖先。若 H_j(t)<h(P)，这些节点全未 light，原停止节点只能严格位于 P 以下；即使 fallback，也在原最细层，仍不含 u。若 H_j(t)≥h(P)，P 已 light，最粗 light 停止节点是 P 或其祖先，包含 u；于是 u 被原 Z 排除。h 的单调性给出两向结论。阈值等号时已经删除。其他来源的并发删除、原接受门及 good 权重不改变这一 support 身份。

固定 r_0>1，取原 bad 集的时间固定子集

    R^{≤r_0}_y={u∈R_y:r_y(u)≤r_0}.                (SC4)

它可保留所有其他原 pair/source 限制，但不重新归一 Π。每个 u 有各自共同祖先，SC4 仍只有一个共同删除上界，不按 LCA 层数收费。

为给出准确上界，写

    a_j=max(1,√n c_{j+1}^n), b_j=√n/b^n,
    H_j(t)=q max(a_jt^n,b_jt^{2n}),
    a_0=q a_j ell^n/H_j(ell),
    b_0=q b_j ell^{2n}/H_j(ell),
    0<a_0,b_0≤1, max(a_0,b_0)=1.

令

    σ_hit(r_0)=min{log(r_0/a_0),(1/2)log(r_0/b_0)},
    σ_*=min{n log(g/ell),σ_hit(r_0)},
    t_*=ell exp(σ_*/n).                             (SC5)

直接代入可得 H_j(ell exp(σ/n))/H_j(ell)=max(a_0e^σ,b_0e^{2σ})。故若未截断的 hit 位于 [ell,g]，SC4 的全部来源最迟在 hit 被删除；若 hit>g，则仅用原终端 g。特别

    0≤σ_*≤σ_hit(r_0)≤log r_0.                      (SC6)

最后一个不等式用 max(a_0,b_0)=1：a_0=1 时第一项为 log r_0，b_0=1 时第二项为半个 log r_0。

## 3. 原正通量的实际小接收费

保持原 A、H、两槽 Π 和 score。其 SC4 子支正通量满足

    I_H[A,R^{≤r_0}]≤σ_*/4≤(log r_0)/4.            (SC7)

理由是 t_* 之后该 bad 子集已不在场，或 t_* 已为 g；在剩余时间先仅以正性放大 0≤H A1_R≤1。对于同一概率 Π 下的 IID X=k_t(v)、Y=k_t(u)，0≤X,Y≤n，有

    E(X−Y)_+=∫_0^n P(X>z)P(Y≤z) dz≤n/4.

这是 R186 已用的正 score 质量界，也可由以上一行直接自证。删源时 Π 改变，但每个连续时刻仍为同一个完整原概率，故逐 t 有同一界。原 dt/t 不给单个删除时刻额外原子费用。积分到 t_* 即得 SC7。

只用一次 hard 帽16/3及外因子2Λ，并先在每个原唯一 j 行完成 SC7，再合并 1_{j(x)=j}。同一原窗口的 FIRST 给 Σ_V∫p_yβ_V(dy)≤q，因此

    Raw_core^{≤r_0}
      ≤(8Λ/3)(log r_0) E_ω∫_{E_rec}q dx.           (SC8)

这对原 small-initial-block、近 outer-bad、tiny-good、high-A、low-Fcal、中央时钟等任意此前剩余正限制都成立。它无需把这些门独立化，也不需要 β≤ν。给定一次预分配 ε>0，取

    r_0=exp(3ε/(8Λ)),                               (SC9)

便得到 SC4 实际子支的 ε 接收付款。没有额外 j、时间窗、祖先层或 soft/scale 菜单费。不同独立原窗口仍按主总账收费，不各领免费的同一 ε。

SC8 支付的是原正 traffic；不能反过来声称 HB 的未减亏损势 q∫ψλ 也自动小。下一节给出为什么同一原势会在早并块时丢失足够的真实亏损。这里未证明 r_y(u)≤r_0 覆盖全部剩余来源，也未认证比全部旧已付域严格更大的 FULL 物理集合。

如果实际采用的 bad 版本另要求 R_y⊂Z_g(y)，则 hit≤g 的 SC4 部分本来为空；非空部分必须有真实共同祖先阈值超过 H_j(g)。SC8 对它仍成立，但小 r_0 此时可能只反映原整窗很短。不得把已删来源当成该更强 terminal-surviving 版本的新实际覆盖。允许 later-deleted bad 的原正上放版本则直接使用 SC3。

## 4. 早并块强制同 α target 的未来损失亏损

以下所有 N、I 和 L_R 都针对同一个 SC4 截断 bad 集；不能借用补集的亏损。定义

    G(t)=∫A_y(v)w_t(y,v)ν_V(dv),
    N(t)=∫_{R^{≤r_0}_y∩Z_t(y)}w_t(y,u)ν_V(du),
    D_A=G(ell)−G(g), z(t)=G(t)−G(g), e=e_g(y),
    N_ell=N(ell), z_*=z(t_*).

G 无 target 删除、连续非增，N 含原全部衰减及删除。R183 保留实际分母给 e_t≥e+z(t)。由 SC3，正通量只需积分到 t_*，因此

    I_H[A,R^{≤r_0}]
      ≤N_ell [1/(e+z_*)−1/(e+D_A)].                (SC10)

证明不改原分母：将 (k_v−k_u)_+≤k_v，N(t)≤N_ell，且 −dG=∫A k_tw_tν dt/t；于是积分被 N_ell∫_{ell}^{t_*}(−dG)/(e+z)^2 支配，直接换变量得到 SC10。

同一行的完整端点势和删除亏损为

    U=N_ell D_A/[e(e+D_A)],
    φ(t)=1/e−1/(e+z(t)),
    L_R=∫_{(ell,g]}φ(t)(−dN(t)).

若 hit≤g，SC4 的 N 在 t_* 后为0，而 φ 在 [ell,t_*] 上至少为 φ(t_*)，故

    L_R≥N_ell z_*/[e(e+z_*)].                      (SC11)

若 hit>g，则 t_*=g、z_*=0，SC11 仅为平凡非负界。原 Stieltjes 删除按并发批次计一次，末端 φ(g)=0。将 SC11 放回

    I_H=U−L_R−M_sc−L_den−L_mask

即再次得到 SC10。这是原停止质量强制的同次 positive-flux 亏损，不是以前已使用的负 suffix 信用。

还可不用假定 z_* 占未来损失的比例，直接由 0≤k_t≤n 得

    G(t_*)≥e^{−σ_*}G(ell),  G(g)≤e.

置 d_A=D_A/e≥0，便有

    z_*/e≥[e^{−σ_*}(d_A+1)−1]_+,

    I_H≤min{σ_*/4,
            (N_ell/e) min(d_A,e^{σ_*}−1)/(1+d_A)}.  (SC12)

第二项由 SC10 直接代入：1/(1+z_*/e)≤min(1,e^{σ_*}/(1+d_A))。d_A=0 时原通量为0；N_ell=0 同样为0。仅当 U>0 时可写比例结论

    I_H/U≤min{1,(e^{σ_*}−1)/d_A}.                  (SC13)

它量化了“bad 很早并块，但 good 仍有很多损失在后面”时实际通量相对于 HB 势的削减。D_A 中的原 ρ、α、Q、w_ell−w_g 全部保留，没有把 JG14 的 target 放大另假设为小。互反及 high 给 N_ell/e≤1/(2Kκ)，可将 SC12 按同一原 p_yβ(dy)dx 积分；但若 σ_* 大、d_A 不更大，SC12 仍不提供任意小量。

## 5. 小未 light 父块的 current 与 reserve 接口及全部成本

这部分是必要几何接口，不另登记付款。设 A_initial 非顶层，P 为其原父块，边长 d_P。由最粗 light 规则或最细 heavy fallback，均有 h(P)>H_j(ell)；fallback 本身没有 light 质量帽。令

    L'=L+2d_P≤b,
    c_P=(L/L')^n exp[−L_φ n d_P/L'],
    L_φ=2/(1−e^(−1)).

则对 z∈P，有合法同 soft 未来核比较

    P_{s,L'}(x−z)≥c_P p_y.                         (SC14)

证明：|z_i−y_i|≤d_P。L' 的 hard 面覆盖原 L 面平移 d_P 后的位置；soft 部分用 φ 的径向单调及 L_φ-log-Lipschitz。每坐标先乘 exp(−L_φd_P/L')，再乘尺度因子 L/L'，得到 SC14。对原 h(P)=μ_hi(P∩B) 积分并用真正 FIRST，得

    q>c_P p_y H_j(ell),
    p_y<1/[c_P ell^n max{1,√n c_{j+1}^n,√n(ell/b)^n}],
    e_g>2Kc_P H_j(ell).                             (SC15)

这一步不可把 L' 换成 actual Hhat。L'>b 时 SC14–15 本路线不适用，原端点剩余保留。精确成本为

    log(1/c_P)=n log(1+2d_P/L)+L_φ n d_P/(L+2d_P)
              ≤(2+L_φ)n d_P/L.                    (SC16)

故 d_P=O(L/n) 才给这一比较的统一常数；d_P≈L/√n 已可能有 exp(Θ(√n)) 的倒数费用。不能用“父块小于剩余几何尺度”就忽略该成本。

同 α 的 reserve 可合法作用于 μ_hi−ν_V，因为 ν_V≤μ_hi；这里仍没有 ν≤β。取 τ_P=μ_hi|_{P∩B}、ν_P=ν_V|_{P∩B}，二者的差非负。原实际 K0=P_{s,Hhat} 满足

    α_y Q_J≥D(q−K0ν_V)
             ≥D K0(μ_hi−ν_V)
             ≥D K0(τ_P−ν_P).                      (SC17)

同时 K0τ_P=K0ν_P+K0(τ_P−ν_P)。在原 high-A target v 上，α_yJ_v<η TΔ_y(v)−DK0_v，因此

    D J_v K0(τ_P−ν_P)
       <Q_J[η TΔ_y(v)−DK0_v].                      (SC18)

此式要求同一实际 K0、α、v 与父块；不能用 SC14 的另一个合法核 p' 替代 K0。高 A 活跃支保证右侧正，Q_J=0 的无来源零支先除去。式中 h(P) 的分拆必须同在 P∩B，不能直接从 h(P) 减未限 B 的 ν(P)。

SC17–18 将未 light 父质量分成真正 ν 质量与 reserve，但 h(P)>H 只给未加权质量信息；尚无一般同价 K0 下界把它转成足够的 target 抑制。ν_P 已支持于 V，但仍可能已被删除、不在 D_y 内或不满足原 bad/good 资格，不能自动当成 surviving bad 或 good。此处保留的是下一步需要联合比较的真实量。

## 6. 实际覆盖、剩余和有界结论

本轮 SC8–9 是原正交通上的实际接收付款，条件是原 canonical 共同祖先质量超额有可计算上界。原大初始块吸收、soft 尾、outer-bad 分离及校准来源支应先去掉，SC8 只用于此前未支付的正部分，不重复领取额度。

新的剩余包含小 initial 停止块、近 outer-bad、tiny-good，以及较大的 r_y(u)，或真实并块时刻很晚的来源。SC12–13 对此仍保留 same-alpha target 未来损失的非线性削减；它们没有证明该削减在所有剩余输入上足够大。SC15 的 expanded-current 成本与 SC17 的 actual K0 reserve 也不能免费合并。

最早尚未付的一步因此具体为：在较大共同祖先质量超额、较晚原并块时钟下，控制 SC12 的实际 p_yβ(dy)dx 积分，或用同一四亏损证明足够弱的 HB16 形式。原 h 质量、K0 加权 reserve、未来 target 损失及 source 支持必须在这个比较中一起保留。一般 ε 接收加 sqrt(n)polylog(n)W_A 结论仍未闭合；本稿不改名剩余，也不追加未证小矩假设。到此停止本轮任务范围。
