import json,math
from pathlib import Path
# Algebraic diagnostic of the proposed legal expanded-kernel coefficient.
# No original source or receiving geometry is generated.
Lphi=2/(1-math.exp(-1))
rows=[]
for n in [2,16,256,4096,1000000]:
 for delta in [1/n,1/math.sqrt(n),.1,1.0]:
  logc=-n*math.log1p(2*delta)-Lphi*n*delta/(1+2*delta)
  limit=-(2+Lphi)*n*delta
  assert logc>=limit-1e-9*max(1,abs(limit))
  for ratio in [1.05,1.5,2.0]:
   legal=1+2*delta<=ratio
   rows.append({'n':n,'d_over_L':delta,'b_over_L':ratio,'legal_expansion':legal,'log_c':logc,'lower_log_bound':limit,'scope':'coefficient only; no root budget'})
Path(__file__).with_suffix('.json').write_text(json.dumps({'cases':len(rows),'L_phi':Lphi,'rows':rows,'method':'double precision log domain; not interval arithmetic','finding':'Keeping n*d/L bounded controls coefficient, but legal upper scale remains essential.'},indent=2)+'\n')
print({'cases':len(rows),'legal':sum(r['legal_expansion'] for r in rows)})
