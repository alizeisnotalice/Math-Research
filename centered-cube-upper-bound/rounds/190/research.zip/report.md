# 第190轮：共同祖先的精确合并时钟与有界超额质量吸收

一般n^(1/2+o(1))一致弱型上界尚未闭合。本轮主进展是原森林中的精确合并几何：初始存活的bad来源u与y的共同祖先P一旦满足h(P)≤H_j(t)，u便退出原来源支撑。按h(P)/H_j(ell)分组，可以直接限制实际交通持续的时间，无需逐祖先层另收费。

## 实际新增估计

对同一原完整行及时间固定bad集合，原支持等价于H_j(t)<h(LCA(y,u))。阈值为q max(A0 t^n,B0 t^{2n})，所以用σ=nlog(t/ell)后，质量比r的准确hit时钟为min(log(r/a0),半log(r/b0))，其中max(a0,b0)=1。再用原g截断。

同Π的两个独立score槽在[0,n]中，正差平均≤n/4；这是两槽分布的精确不等式，不需要来源坐标独立。原A、mask和bad子集正放大后，质量比≤r的整行交通满足I≤logr/4。保留原hard帽及外系数，最终

 Raw_r ≤ (8Λ/3)logr · E∫E q dx。

取r=exp(3ε/(8Λ))，得到一次ε接收吸收，无time/j/LCA深度菜单费。可以与保留z(t*)的截断目标未来损失界取小者，但不能把两界当两次预算。

逐来源使用各自准确hit截止，再正Tonelli，进一步得到实际通量的联合界Raw≤Crec E∫q dx∫F(d_y,σ_u)λ，其中d_y=D_A/e，F=min(d_y,e^{σ_u}−1)/(1+d_y)。F≤η支可吸收Crecη，无质量分层费；未付支必须同时具有较大目标损失、较晚合并，且r_u>max(a0Rη,b0Rη²)，Rη=1+η(1+d_y)。二次项系数完整保留。这不是说未减亏损的ψ势也小，也不重复领取重叠分支预算。

## 未闭合部分和辅助路线的真实费用

小初始停止块不意味着LCA质量比小；大质量比、极小good重叠的未来放大仍未支付，其他原mother分支也未全闭。若某版本要求bad一直存活到Zg，则hit≤g的那部分本来为空；本轮未数值认证严格新增FULL构型。窗口之间仍按原总账分配ε。

辅助稿精确证明小块推出同初始阈值下的重祖先，保留fallback；来源覆盖公式虽有可求和的比例带因子O(logn/√n)，仍带((S+2R0)/a)^n体积价，不能叫根阶结论。合法expanded-current比较也保留exp(−常数·nd/L)和L+2d≤b资格；没有用它代替原K0。辅助材料只防止下一轮重复遗漏费用，不计为第二个改进预算。

## 数值探路和复现

本机实际运行：扩尺度系数60行、32行满足合法尺度；12个Fraction score例（含n/4等号）；80个精确时钟参数在40/60位下共160次评估；另75个Fraction逐来源端点包络例及225个剩余门等价检查。初探、小质量超额/切换端点/截断压力和扩大质量比分别保留。扩尺度结果说明nd/L有界才保持该最坏系数稳定，合法扩大到L/√n仍可能有指数损失；不是一般阶数拟合。

数值代理独立读代码并各隔离重放一次完整JSON，结果一致。Fraction是有限精确算术；double及mpmath均非区间证书。有限score包括实值分布模型，非全部原整数score实例；未构造原FULL/history/alpha。一般结论来自证明及原来源条件，不来自样本。

主证明coalescence_clock_budget.md和详细proof.tex.txt；Astra完整行/target接口small_block_joint_budget.md；准确昂贵来源价heavy_parent_budget.md。E03技能仅用于质量传递、预算类型和终端项资格，未引用未迁移的Bellman常数。1 Astra high、2 Sol high、1 Sol medium各自有界任务；无可获得扣额明细。

不编译PDF。解压后python3 reproduce.py --verify-only核哈希；已有mpmath环境下python3 reproduce.py --output-dir <不存在的新目录>重放。实际本机PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor。每轮独立紧凑归档、提交并推送。
