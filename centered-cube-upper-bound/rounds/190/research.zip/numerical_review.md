# R190 independent expansion-coefficient review

`parent_expansion_probe.py` and its existing JSON were independently read. No formula, count, or scope correction was found. The retained evidence is a finite coefficient diagnostic in double-precision logarithms, not interval arithmetic, an original FULL/FIRST/source/receiver construction, or a general root-budget certificate.

## Formula and legal-domain audit

The script implements exactly

`log c=−n log(1+2δ)−Lφ nδ/(1+2δ)`, `Lφ=2/(1−e^-1)`,

using `log1p(2δ)`. This is the logarithm of the stated coefficient (1+2δ)^(-n) exp[−Lφ nδ/(1+2δ)]. Its checked lower expression −(2+Lφ)nδ has the correct direction: log(1+2δ)≤2δ and δ/(1+2δ)≤δ. The relative tolerance in that diagnostic is a floating-point consistency allowance, not a certified error enclosure.

The legal expansion flag is exactly 1+2δ≤b/L. It is retained separately from the computed coefficient, so illegal rows do not acquire an application claim. Ratios are 1.05,1.5,2.0. Equality cases at n=2,δ=1/n,b/L=2 and n=16,δ=1/sqrt(n),b/L=1.5 are represented exactly by the binary arithmetic used. Other prescribed legal/illegal decisions are separated from the boundary; no inference from an unmeasured near-boundary tolerance is used.

## Count and three stages

There are five n values, four δ specifications (1/n,1/sqrt(n),0.1,1), and three b/L values, hence 5·4·3=60 rows. The legal counts by dimension are:

| Stage | n | Legal / total |
|---|---:|---:|
| initial | 2 | 3/12 |
| initial | 16 | 6/12 |
| pressure | 256 | 7/12 |
| pressure | 4096 | 8/12 |
| expanded | 1000000 | 8/12 |

The sum is 32 legal rows. Every δ=1 row is illegal under b/L≤2, since the proposed expansion factor is 3. These coefficient values are therefore only algebraic diagnostics, not usable legal expanded kernels.

## What is and is not stable

For δ=1/n the exact lower formula gives log c≥−(2+Lφ), retaining a positive dimension-independent coefficient whenever the scale is legal. The finite log values are about −2.96827,−4.69693,−5.13165,−5.16192,−5.16395 as n increases through the menu. This agrees with the directly stated bounded-nδ criterion; it is not an exponent fit.

The wider menu choices lose that constant stability in the observed formulas. At n=1000000, δ=1/sqrt(n) has log c≈−5155.64, and δ=0.1 has log c≈−445984.34, despite both becoming legal for the listed larger scale ratios. Thus legality alone is not a constant coefficient guarantee. The most negative diagnostic, δ=1, has log c≈−2153263.43 but is illegal throughout. Logs are retained rather than exponentiating to a machine zero, so numerical underflow is not presented as exact vanishing.

No additional precision script was necessary for this bounded classification: the conclusion uses the algebraic lower expression, explicit scale flags, and well-separated logarithmic magnitudes. Absolute high-precision error bounds for the displayed double values were not measured or claimed. None of this establishes the original geometric premise, source integration, receiving price, or a general centered-cube bound.

## One isolated replay

Only the reviewed script was copied to `/tmp/r190_expansion_review/`. The actual standard-library-only command was:

```sh
python3 /tmp/r190_expansion_review/parent_expansion_probe.py
```

It exited zero, printed `cases: 60, legal: 32`, and the complete JSON bytes matched the main output via `read_bytes()` equality. The legal counts above were independently tallied from that output. No main file was edited, no sample was added, and no mpmath or software installation was required.

Reviewed SHA256:

- `parent_expansion_probe.py`: `d20da5453ef27ce4beaadbd1cd2381075caf5a4986564b1e2382dfd08e43706b`
- `parent_expansion_probe.json`: `ae5a73b729d17d337a717683a4ed9d75232bc4983c068b3a876fac6cd92325a2`

Review and replay complete; no further numerical expansion is implied.

## Additional threshold-clock independent review

The parent's `threshold_clock_checks.py/json` was independently read, without rerunning the expansion probe. The score menu has 4 n values times 3 normalized rational IID distributions, hence 12 Fraction checks. Their supports lie in [0,n], and endpoint masses 1/2,0,1/2 attain n/4. At n=1 the middle score 1/2 is a bounded-real score, so that row is the general bounded IID inequality rather than an assertion of an original integer score process.

All five clock parameter pairs have positive alpha,beta≤1 and max(alpha,beta)=1; all four r values exceed one, and all four terminal sigma_g values are nonnegative. Therefore H/H_initial=max(alpha exp(sigma),beta exp(2sigma)) starts at one and is increasing. The first hit of r is exactly min(log(r/alpha),log(r/beta)/2), as implemented. The script checks the hit equation and (log r)/2≤sigma_hit≤log r, then clips the endpoint by sigma_g before dividing by 4. It includes empty sigma_g=0 and branch-switch ties (alpha,beta,r)=(1,1/2,2) and (1,1/16,16).

The reported row_bound is the scalar upper formula sigma_end/4. No actual source-clock positive-flux integral is generated or asserted equal to that upper formula; connecting the bounded-score estimate to the original normalized clock remains the separate analytic argument. The r>1, normalized-max, and terminal-clipping qualifications are essential and are not inferred from arbitrary illegal inputs.

The clock count is 5 parameter pairs × 4 r values × 4 terminal values=80, each executed at 40 and 60 dps, for 160 numerical evaluations. The saved clock rows are the final 60-dps values, with a hit-value cross-precision assertion at 1e-34. Finite residuals and agreement are not directed intervals, a uniform theorem, or physical FULL/history certification.

Exactly one new isolated replay copied only the threshold script into `/tmp/r190_threshold_clock_review/` and ran:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 /tmp/r190_threshold_clock_review/threshold_clock_checks.py
```

It exited zero, printed 12/80/160, and its complete JSON bytes equalled the main output. The existing local mpmath was used with standard import; nothing was installed. No old expansion case was rerun, no sample was added, and no parent-owned source file was modified. No substantive issue was found.

Additional reviewed SHA256:

- `threshold_clock_checks.py`: `5ca5876bd56eeaf752fd4deca2621a83415a3ecafe424e4d1db9e3f75d7700ef`

- `threshold_clock_checks.json`: `dea5dd340695e883017f1588e234daa6774623e299a9bed8c139cf9882cdad4d`

## Additional source-deadline endpoint review

The parent's `source_deadline_checks.py/json` was statically reviewed. No substantive issue was found. It uses exact Fraction arithmetic with d≥0, w≥1, v∈[0,1] and chooses z at its lower envelope max(0,(d+v)/w−v). This choice maximizes 1/(1+z)−1/(1+d) among all admissible z, so checking the upper envelope at that endpoint is the correct worst-case scalar test. The nonnegative lower assertion is specific to this chosen z≤d; an arbitrary larger admissible z can give a negative difference, and the script does not claim otherwise.

The proposed bound F=min(d,w−1)/(1+d) is correct. Indeed v=1 minimizes the allowed z; when w−1≥d the difference is d/(1+d), and otherwise it is (w−1)/(1+d). This also explains the sharp endpoint rows. Since 1+d>0 and 0<eta<1, F>eta is exactly the conjunction d>eta/(1−eta) and w>1+eta(1+d); the script retains strict comparisons and does not include excluded eta endpoints.

There are five d values (0,1/100,1,100,1000000), five w values (1,101/100,2,16,2^20), and three v values (0,1/2,1), hence 75 endpoint cases. The three eta values give 225 gate-assertion executions. Because the gate is independent of v, these are 75 distinct (d,w,eta) settings, each checked in the three v rows; the count is not presented as 225 independent parameter settings. Zero d, w=1, near-one w, and high dynamic range are retained. These finite scalar arrays do not construct original coalescence, alpha, a source/history realization, or FULL inputs, and do not themselves certify the authored Tonelli deadline integration.

Exactly one isolated standard-library replay copied only this new script into `/tmp/r190_source_deadline_review/` and ran:

```sh
python3 /tmp/r190_source_deadline_review/source_deadline_checks.py
```

It exited zero, printed 75 cases and 225 gate checks, and its complete JSON bytes matched the main output. No old expansion or threshold-clock script was rerun, no sample was added, and no parent-owned file was modified.

Additional reviewed SHA256:

- `source_deadline_checks.py`: `c4977b87b5ca941efbd6c8b4293c1a87fd73cc3eb47c7726cc06c9db45553fa3`

- `source_deadline_checks.json`: `ae4358ea03d98d3f138d5801a95292f9d3720f2ce9b4d49eeb68943f655cbaa7`
