from pathlib import Path
from fractions import Fraction as F
import json
import mpmath as mp
# Exact bounded-score iid check, including sharp equality.
score_rows=[]
for n in [1,2,16,256]:
 for masses in [[F(1,2),F(0),F(1,2)],[F(1,3)]*3,[F(1,10),F(4,5),F(1,10)]]:
  scores=[F(0),F(n,2),F(n)]
  positive=sum(masses[i]*masses[j]*max(F(0),scores[i]-scores[j]) for i in range(3) for j in range(3))
  assert positive<=F(n,4)
  score_rows.append({'n':n,'masses':[str(p) for p in masses],'positive':str(positive),'bound':str(F(n,4))})
rows=[]
for alpha,beta in [(1,1),(1,F(1,2)),(1,F(1,16)),(F(1,2),1),(F(1,16),1)]:
 for r in [F(101,100),F(2),F(16),F(2**20)]:
  for g in [F(0),F(1,100),F(1),F(16)]:
   outcomes=[]
   for precision in [40,60]:
    mp.mp.dps=precision
    val=lambda z:mp.mpf(z.numerator)/z.denominator if isinstance(z,F) else mp.mpf(z)
    a,b,rr,gg=map(val,[alpha,beta,r,g])
    hit=min(mp.log(rr/a),mp.log(rr/b)/2)
    end=min(hit,gg)
    assert abs(max(a*mp.exp(hit),b*mp.exp(2*hit))/rr-1)<mp.mpf(10)**(-precision+5)
    assert mp.log(rr)/2-mp.mpf('1e-35')<=hit<=mp.log(rr)+mp.mpf('1e-35')
    assert end/4<=mp.log(rr)/4+mp.mpf('1e-35')
    outcomes.append(hit)
   assert abs(outcomes[0]-outcomes[1])<mp.mpf('1e-34')
   rows.append({'alpha':str(alpha),'beta':str(beta),'r':str(r),'sigma_g':str(g),'sigma_hit':mp.nstr(hit,30),'sigma_end':mp.nstr(end,30),'row_bound':mp.nstr(end/4,30)})
result={'score_cases':len(score_rows),'score_rows':score_rows,'clock_cases':len(rows),'precision_evaluations':2*len(rows),'precisions':[40,60],'clock_rows':rows,'scope':'Fraction score identity and finite high precision scalar threshold clocks. Not interval enclosures or physical FULL realization; r>1 required, zero sigma_g is empty time branch.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print({'score_cases':len(score_rows),'clock_cases':len(rows),'precision_evaluations':2*len(rows)})
