#!/usr/bin/env python3
"""R786 exact double descent and true branch overlap on frozen real marked cubes."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(xs):
    return sum(xs,F(0))


def prod(xs):
    out=F(1)
    for v in xs:
        out*=v
    return out


def mu1(q):
    lo,hi=q
    if lo>=hi:
        return F(0)
    period=F(1,8)

    def cumulative(x):
        j=x//period
        u=x-j*period
        return j*period+u/2+max(F(0),u-period/2)
    return cumulative(hi)-cumulative(lo)


def volume_bin(m):
    b=m.numerator.bit_length()-m.denominator.bit_length()
    return b-1 if F(2)**b>m else b


def setup(name,n):
    if name=="reflection":
        r=[F(k,16) for k in (16,22,22,23,30)]
        centers=[(F(k,32),) for k in (0,-42,44,-44,60)]
        eta=F(1,48)
        bit_cut=F(1,32)
        mids=(3,4)
    elif name=="biaxial":
        r=[F(1),F(3,2),F(15,8)]
        centers=[(F(0),F(0)),(F(9,4),F(0)),(F(0),F(11,4))]
        eta=F(1,8)
        bit_cut=F(7,8)
        mids=(1,2)
    else:
        assert name=="third_face"
        r=[F(1),F(3,2),F(15,8),F(3,2)]
        centers=[(F(0),F(0),F(0)),(F(9,4),F(0),F(0)),
                 (F(0),F(11,4),F(0)),(F(0),F(0),F(9,4))]
        eta=F(1,8)
        bit_cut=F(7,8)
        mids=(1,2,3)
    axes=len(centers[0])
    a=32*n
    ids=range(len(r))
    m=[(2*s)**n for s in r]
    I=[M/a**n for M in m]
    h=[I[i]/m[i] for i in ids]
    ends=[tuple((c-s,c+s) for c in center) for center,s in zip(centers,r)]
    for i in ids:
        assert 1<=r[i]<2
        assert prod(mu1(q) for q in ends[i])*mu1((-r[i],r[i]))**(n-axes)==m[i]
        for j in range(i):
            assert any(abs(x-y)>(r[i]+r[j])/a for x,y in zip(centers[i],centers[j]))

    def mu_inter(indices):
        s=min(r[i] for i in indices)
        active=prod(mu1((max(ends[i][l][0] for i in indices),min(ends[i][l][1] for i in indices)))
                    for l in range(axes))
        return active*mu1((-s,s))**(n-axes)

    overlap={(v,w):mu_inter((v,w)) for v,w in product(ids,repeat=2)}
    bins=[volume_bin(x) for x in m]
    keys=tuple(range(min(bins),max(bins)+1))
    B,U=keys[:len(keys)//2],keys[len(keys)//2:]
    assert all(bins[v] in U for v in mids)
    lower=[u for u in ids if bins[u] in B]
    good={(v,w) for v,w in overlap if v!=w and bins[v]!=bins[w]
          and 0<overlap[v,w]<=eta*min(m[v],m[w])}
    K={(i,j):overlap[i,j]/(m[i]*m[j]) if (i,j) in good else F(0)
       for i,j in overlap}
    degree={v:ss(I[j]*K[v,j] for j in ids) for v in mids}
    assert all(degree.values())
    far={(v,w) for v,w in product(mids,repeat=2) if max(m[v],m[w])>4*min(m[v],m[w])
         and 0<overlap[v,w]<=eta*min(m[v],m[w])}
    assert far
    # Known horizontal source cell P is all [-4,4]. Finite slabs/shells refine it.
    cuts=[]
    for l in range(axes):
        points={t for q in ends for t in q[l]}
        if not l:
            points.update((F(-4),F(4),bit_cut))
        co=sorted(points)
        cuts.append(list(zip(co,co[1:])))
    steps=sorted({F(0),*r})
    tau={}
    truth={v:{} for v in mids}
    marks={}
    for Q in product(*cuts):
        if Q[0][0]<-4 or Q[0][1]>4:
            continue
        p=prod(mu1(q) for q in Q)
        if not p:
            continue
        for s0,s1 in zip(steps,steps[1:]):
            members=[i for i in ids if s1<=r[i] and
                     all(lo<=l<hh<=hi for (lo,hi),(l,hh) in zip(ends[i],Q))]
            if not any(u in members for u in lower):
                continue
            mass=p*(mu1((-s1,s1))**(n-axes)-mu1((-s0,s0))**(n-axes))
            H=ss(h[i] for i in members)
            for u in lower:
                if u not in members:
                    continue
                mark=(u,Q,s0,s1)
                tau[mark]=H*h[u]*mass
                marks[mark]=int(Q[0][0]>=bit_cut)
                for v in mids:
                    if v in members and (u,v) in good:
                        truth[v][mark]=h[u]*mass
    x={v:ss(truth[v].values())/m[v] for v in mids}
    assert all(x[v]==ss(I[u]*K[v,u] for u in lower)>0 for v in mids)
    original_W={v:I[v]*x[v]**2/degree[v] for v in mids}
    gated={}
    accepts={}
    for v in mids:
        norm=ss(truth[v].values())
        nu={a:w/norm for a,w in truth[v].items()}
        assert ss(nu.values())==1 and len({marks[t] for t in nu})==2
        for a1,a2 in product(nu,repeat=2):
            u,g=a1[0],a2[0]
            mu_left=truth[v][a1]/h[u]
            mu_right=truth[v][a2]/h[g]
            old=(I[u]*I[v]*K[u,v])*(I[g]*K[v,g]/degree[v])*mu_left*mu_right/(overlap[u,v]*overlap[v,g])
            assert old==original_W[v]*nu[a1]*nu[a2]
            if marks[a1]<=marks[a2]:
                gated[v,a1,a2]=old
        prob0=ss(w for t,w in nu.items() if not marks[t])
        accepts[v]=1-prob0*(1-prob0)
    M={v:ss(w for row,w in gated.items() if row[0]==v) for v in mids}
    assert all(M[v]==original_W[v]*accepts[v] for v in mids)
    return mids,r,centers,eta,degree,m,I,tau,marks,gated,far,accepts,x,original_W,overlap


def margins(data):
    out=defaultdict(F)
    for (v,a,b),w in data.items():
        out[0,v,a]+=w
        out[1,v,b]+=w
    return out


def true_source_cells(n,r,centers):
    d=len(centers[0])
    bounds=[tuple((x-s,x+s) for x in c) for c,s in zip(centers,r)]
    assembled=[]
    for j in range(d):
        endpoints=sorted({x for c in bounds for x in c[j]})
        assembled.append(list(zip(endpoints,endpoints[1:])))
    radial=sorted({F(0),*r})
    out=[]
    for Q in product(*assembled):
        face=prod(mu1(q) for q in Q)
        for lo,hi in zip(radial,radial[1:]):
            active={i for i,axes in enumerate(bounds) if hi<=r[i]
                    and all(a<=l<b<=z for (l,b),(a,z) in zip(Q,axes))}
            if active:
                mass=face*(mu1((-hi,hi))**(n-d)-mu1((-lo,lo))**(n-d))
                assert mass>0
                out.append((active,mass))
    return out


def stable_subset(records,mids,tau,far,t):
    D=dict(records)
    passes=0
    while True:
        M=margins(D)
        live={rec:w for rec,w in D.items()
              if all(ss(M[e,v,rec[e+1]] for v in mids if (rec[0],v) in far)>=t*tau[rec[e+1]]
                     for e in (0,1))}
        if D==live:
            break
        D=live
        passes+=1
    return D,passes


def branch_check(n,mids,records,m,I,far,source_cells,overlap):
    D=margins(records)
    pi={}
    cohort=ss(records.values())
    for e,_,a in D:
        if (e,a) in pi:
            continue
        mass=ss(D.get((e,v,a),F(0)) for v in mids)
        assert mass>0
        pi[e,a]={v:D.get((e,v,a),F(0))/mass for v in mids}
        assert ss(pi[e,a].values())==1

    matrix=defaultdict(F)
    low_left=defaultdict(F)
    low_right=defaultdict(F)
    terminal_mass=defaultdict(F)
    rate_left=rate_right=rate_both=F(0)
    source_cell_overlap=F(0)
    real_records=0
    witness=None
    for (v,a,b),old in records.items():
        terminal_mass[v]+=old
        left={w:p for w,p in pi[0,a].items() if p and (v,w) in far and m[w]<m[v]}
        right={w:p for w,p in pi[1,b].items() if p and (v,w) in far and m[w]<m[v]}
        PL,PR=ss(left.values()),ss(right.values())
        assert PL<=1 and PR<=1
        rate_left+=old*PL
        rate_right+=old*PR
        rate_both+=old*PL*PR
        for w,p in left.items():
            low_left[v,w]+=old*p
        for w,p in right.items():
            low_right[v,w]+=old*p
        total=F(0)
        for (w,L),(w2,R) in product(left.items(),right.items()):
            true=old*L*R
            matrix[v,w,w2]+=true
            total+=true
            if witness is None and w!=w2 and overlap[w,w2]:
                witness={"terminal_v":v,"left_mark":a,"right_mark":b,
                         "distinct_descending_parents":[w,w2],"terminal_record_mass":old,
                         "full_true_left_and_right_posterior_weights":[L,R],
                         "raw_positive_joint_branch_mass":true,
                         "true_source_intersection_fraction":overlap[w,w2]/m[v],
                         "true_owner_intersection_volume":F(0)}
        assert total==old*PL*PR
        if PL*PR:
            real_records+=1
            local=ss(s*ss(p for w,p in left.items() if w in lab)*
                     ss(p for w,p in right.items() if w in lab)
                     for lab,s in source_cells)
            source_cell_overlap+=old*local/m[v]
    assert ss(matrix.values())==rate_both
    assert rate_both<=min(rate_left,rate_right)<=max(rate_left,rate_right)<=cohort
    parent_overlap=ss(weight*overlap[w,w2]/m[v] for (v,w,w2),weight in matrix.items())
    assert parent_overlap==source_cell_overlap
    sameW=ss(weight for (v,w,w2),weight in matrix.items() if w==w2)
    assert sameW<=rate_both
    same_source=ss(weight*m[w]/m[v] for (v,w,w2),weight in matrix.items() if w==w2)
    distinct_source=ss(weight*overlap[w,w2]/m[v] for (v,w,w2),weight in matrix.items() if w!=w2)
    assert same_source+distinct_source==parent_overlap
    owner_overlap=ss(weight*I[w]/m[v] for (v,w,w2),weight in matrix.items() if w==w2)

    fake={}
    for v,w,w2 in product(terminal_mass,mids,mids):
        if low_left[v,w] and low_right[v,w2]:
            fake[v,w,w2]=low_left[v,w]*low_right[v,w2]/terminal_mass[v]
    artificial_both=ss(fake.values())
    artificial_overlap=ss(w*overlap[A,B]/m[v] for (v,A,B),w in fake.items())
    L_source=ss(w*overlap[v,i]/m[v] for (v,i),w in low_left.items())
    R_source=ss(w*overlap[v,i]/m[v] for (v,i),w in low_right.items())
    inside=ss(weight*ss(z for labels,z in source_cells if {v,w,w2}<=labels)/m[v]
              for (v,w,w2),weight in matrix.items())
    assert 0<=inside<=parent_overlap
    each_v={v:{"terminal_mass":total,
                "double_down_mass":ss(w for (i,_,_),w in matrix.items() if i==v),
                "true_source_overlap_given_v_cohort_unnormalized":
                    ss(w*overlap[w1,w2]/m[v] for (i,w1,w2),w in matrix.items() if i==v)}
            for v,total in terminal_mass.items()}
    assert ss(row["double_down_mass"] for row in each_v.values())==rate_both
    return {"cohort_terminal_mass_before_double_drop":cohort,
            "terminal_mass_by_actual_central":terminal_mass,
            "cohort_and_raw_branch_masses_at_each_fixed_v":each_v,
            "number_of_records_with_both_lower_options":real_records,
            "actual_left_right_one_branch_masses":[rate_left,rate_right],
            "actual_left_right_source_masses_with_intersection_Av":[L_source,R_source],
            "actual_double_down_mass_without_success_normalization":rate_both,
            "artificial_double_down_after_discarding_record":artificial_both,
            "actual_two_branch_parent_source_overlap_divided_by_mv":parent_overlap,
            "wrong_two_branch_parent_overlap_after_discarding_record":artificial_overlap,
            "actual_source_overlap_same_and_different_lower_parents":[same_source,distinct_source],
            "same_lower_parent_mass_without_success_normalization":sameW,
            "actual_two_branch_owner_volume_overlap_divided_by_mv":owner_overlap,
            "actual_two_branch_source_overlap_also_restricted_to_terminal_Av":inside,
            "actual_overlap_conditioned_on_both_lower":parent_overlap/rate_both if rate_both else None,
            "actual_overlap_matrix_keys_v_left_w_right_w":{str(key):w for key,w in sorted(matrix.items())},
            "wrong_marginal_product_matrix":{str(key):w for key,w in sorted(fake.items())},
            "positive_distinct_parent_overlap_witness":witness}


def profile(name,n):
    mids,r,centers,eta,degree,m,I,tau,marks,gated,far,accepts,x,W,overlap=setup(name,n)
    cells=true_source_cells(n,r,centers)
    assert all(ss(w for labels,w in cells if i in labels and j in labels)==z for (i,j),z in overlap.items())
    first=branch_check(n,mids,gated,m,I,far,cells,overlap)
    if name=="reflection":
        assert first["actual_double_down_mass_without_success_normalization"]==0
    else:
        assert first["actual_double_down_mass_without_success_normalization"]>0
        assert first["same_lower_parent_mass_without_success_normalization"]>0
        assert first["actual_two_branch_parent_source_overlap_divided_by_mv"]>0
    separate=None
    if name=="third_face":
        assert first["positive_distinct_parent_overlap_witness"] is not None
        assert first["actual_source_overlap_same_and_different_lower_parents"][1]>0
        assert first["actual_two_branch_parent_source_overlap_divided_by_mv"]!=first["wrong_two_branch_parent_overlap_after_discarding_record"]
        if n==8:
            t=F(28,99951)
            live,rounds=stable_subset(gated,mids,tau,far,t)
            assert len(live)==33 and len(live)<len(gated) and rounds
            outcome=branch_check(n,mids,live,m,I,far,cells,overlap)
            assert outcome["actual_double_down_mass_without_success_normalization"]>0
            separate={"t_from_R785":t,"live_records":len(live),"synchronous_pruning_rounds":rounds,
                      "conditional_reference_check":outcome}
    return {"shape":name,"n":n,"eta":eta,"actual_r":r,"true_parent_volumes":m,"I_equals_true_disjoint_owner_volumes":I,
            "physical_centers_on_active_axes":centers,"old_degree_by_terminal":degree,
            "old_peak_by_c_v":W,"gated_acceptance_by_v":accepts,"tau_count":len(tau),
            "number_of_actual_source_cells":len(cells),"diagnostic_far_cut":"m_high/m_low>4 and true mu intersection <= eta min",
            "full_gated_actual_q_reference_draws":first,"one_fixed_core_reference_check":separate}


def audit():
    return {"python":sys.version.split()[0],"arithmetic":"Fraction","command":"python -B branches786.py --check branches786.json",
            "source":"frozen R785 geometry setup copied here; period 1/8 product measure with half densities 1/2 and 3/2",
            "gate":"actual left bit <= actual right bit, bit uses only the first true price coordinate",
            "sampling":"condition on the entire true record; independent full posteriors followed by two downward/far-small tests",
            "scope":"finite physical reference draws; the order-selected inverse kernel and the original L screen are outside the fixture",
            "models":[profile(name,n) for name,n in (("reflection",6),("biaxial",8),("third_face",8),("third_face",12))]}


def main():
    import argparse
    from pathlib import Path

    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    result=json.dumps(audit(),indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(result)
    elif args.check:
        assert args.check.read_text()==result, "exact certificate differs"
        print("branches786: four physical reference models agree byte for byte")
    else:
        print(result,end="")


if __name__=="__main__":
    main()
