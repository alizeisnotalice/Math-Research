"""Exact diagnostic cubes with coincident source prices and distinct receiving owners."""
import argparse
import json
import sys
from fractions import Fraction as Q
from itertools import product
from pathlib import Path


def bin_number(m):
    b = m.numerator.bit_length() - m.denominator.bit_length()
    return b - (Q(2)**b > m)


def family(p, clones, n, depth):
    delta = Q(1, 16)
    assert 2*p + clones <= n and 2*depth < p
    small = [frozenset([i]) for i in range(2*p)]
    states = list(product(range(p), range(p), range(clones)))

    def tags(w):
        i, j, l = w
        return frozenset((i, p+j, 2*p+l))

    def rank(w):
        return (w[0]+w[1]) % p

    radii = [Q(3, 2) + Q(3*k, 8*(p-1)) for k in range(p)]
    masses = [(2*s)**n for s in radii]
    cap = Q(1, (32*n)**n)
    tag_mass = delta**n
    bins = [bin_number(m) for m in masses]
    assert len(set(bins)) == p
    assert all(masses[i+1] > 4*masses[i] for i in range(p-1))
    assert n < n + (max(bins)-n+1)//2 <= min(bins)

    def intersection(u, su, v, sv):
        diff = len(u ^ v)
        return (2*min(su, sv))**(n-diff)*(2*delta)**diff

    def coordinate_intersection(u, su, v, sv):
        m = (2*min(su, sv))**(n-2*p-clones)
        for h in range(2*p+clones):
            cu = (su-delta) * (1 if h in u else -1)
            cv = (sv-delta) * (1 if h in v else -1)
            m *= max(Q(0), min(cu+su, cv+sv) - max(cu-su, cv-sv))
            if (h in u) != (h in v):
                assert abs(cu-cv) > (su+sv)/(32*n)
        return m

    # Cyclic translation of i,-j and a permutation of clone tags preserve all
    # coefficients at fixed rank. Check all distinct geometric patterns directly.
    configurations = [(u, Q(1), n) for u in small]
    configurations += [(tags(w), radii[rank(w)], bins[rank(w)]) for w in states]
    x, W, tag_probability, raw = [], [], [], []
    checked = set()
    for k in range(p):
        tag, s, m = tags((0,k,0)), radii[k], masses[k]
        arm = Q(0)
        degree = Q(0)
        for u, su, b in configurations:
            geom = intersection(tag, s, u, su)
            key = (s, su, len(tag ^ u))
            if key not in checked:
                assert coordinate_intersection(tag, s, u, su) == geom
                checked.add(key)
            if b != bins[k]:
                assert geom <= min(m,(2*su)**n)/8
                degree += cap*geom/m
                if len(u) == 1:
                    arm += cap*geom/m
        w = m*cap*arm**2/degree
        prob = cap*tag_mass/(m*arm)
        assert w*prob**2 == cap**3*tag_mass**2/(m*degree)
        x.append(arm)
        W.append(w)
        tag_probability.append(prob)
        raw.append(w*prob**2)
    retained = min(raw)
    # Each arm uses its designated small cube and its true price box. Thinning
    # by the actual uniform receiving coordinate produces equal retained weights.
    assert all(0 < retained/value <= 1 for value in raw)
    absolute_mark_density = p*clones*retained/(cap*tag_mass)
    absolute_acceptance = [x[k]*retained/(W[k]*tag_probability[k]) for k in range(p)]
    assert max(x + absolute_acceptance + [absolute_mark_density]) < Q(1,1000)
    for u in configurations:
        labels,s,_ = u
        for t in range(2*p):
            center = [(s-delta)*(1 if h in labels else -1) for h in range(2*p+clones)]
            ds = [abs(Q(int(h == t))-z) for h,z in enumerate(center)]
            assert (max(ds)+delta/2<=s) == (t in labels)
            if t not in labels:
                assert max(ds)-delta/2>s

    # At fixed starting source y in the left tag, the initial rank is uniform.
    # Each next lower rank is obtained from the cyclic predecessor.
    def move(w, side, sign, clone):
        i,j,_ = w
        if side == 0:
            return (i, (j+sign) % p, clone)
        return ((i+sign) % p, j, clone)

    success = 0
    for w in states:
        back, forward = w, w
        old, future = [], []
        for j in range(depth):
            back = move(back, 1-j%2, -1, 0)
            forward = move(forward, j%2, 1, 0)
            old.append(back)
            future.append(forward)
        path = old[::-1]+[w]+future
        if all(rank(u)<rank(v) for u,v in zip(path,path[1:])):
            success += 1
            for q,(u,v) in enumerate(zip(path,path[1:])):
                shared = tags(u) & tags(v) & set(range(2*p))
                assert len(shared) == 1
                new_price = (tags(v) & set(range(2*p))) - shared
                assert len(new_price) == 1
                assert all(not new_price.intersection(tags(a)) for a in path[:q+1])
    assert Q(success,len(states)) == 1-Q(2*depth,p)

    # Same y, same root bin D and same old bin d. The two clone variables in
    # distinct copies are independent. All destination prices are nevertheless
    # in both final physical parents, even for different clone labels.
    root = (0, depth, 0)
    base = root
    for j in range(depth):
        base = move(base,1-j%2,-1,0)
    assert rank(base) == 0
    final = [(base[0],base[1],l) for l in range(clones)]
    total_overlap = Q(0)
    shared_price = same_owner = Q(0)
    for u,v in product(final,repeat=2):
        total_overlap += intersection(tags(u),radii[0],tags(v),radii[0])/masses[0]/clones**2
        shared_price += Q((tags(u)&set(range(2*p))) <= tags(v), clones**2)
        same_owner += Q(u==v,clones**2)
    exact_overlap = Q(1,clones)+(1-Q(1,clones))*(delta/radii[0])**2
    assert total_overlap == exact_overlap and shared_price == 1
    assert same_owner == Q(1,clones)
    return {"p":p,"clones":clones,"n":n,"depth_each_side":depth,
            "true_middle_parents":len(states),"positive_equal_thinned_peak_per_middle":str(retained),
            "tested_distinct_intersection_patterns":len(checked),
            "global_two_sided_success_fraction":str(Q(success,len(states))),
            "single_anchor_and_bin_path_probability":str(Q(1,p)),
            "root_to_old_actual_mass_ratio":str(masses[depth]/masses[0]),
            "probability_same_root_or_same_old_label_each":str(same_owner),
            "normalized_true_source_parent_overlap":str(total_overlap),
            "fraction_of_real_old_price_also_in_other_parent":str(shared_price),
            "normalized_true_owner_overlap":str(same_owner),
            "both_absolute_density_thresholds_fail_at_one_over_1000":True}


def shift_test(k,r):
    # One seeded realization of the lower note's stratified atomic component.
    # Grid period is one; use exact Fubini and an independent breakpoint integral.
    pts=[(j+Q((17*j+3) % (2*k+1), 2*k+1))/k for j in range(k)]
    breaks=sorted({Q(0),Q(1),*((z+e*r)%1 for z in pts for e in (-1,1))})
    counts=[]
    avg=Q(0)
    for lo,hi in zip(breaks,breaks[1:]):
        t=(lo+hi)/2
        mult=sum(sum(t+j-r<=z<t+j+1+r for j in (-2,-1,0,1)) for z in pts)
        counts.append(Q(mult,k))
        avg+=(hi-lo)*counts[-1]
    assert avg==1+2*r and min(counts)<=avg<=max(counts)
    return {"K":k,"padding_over_cell":str(r),"exact_mean":str(avg),
            "min":str(min(counts)),"max":str(max(counts)),"integration_pieces":len(counts)}


def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument("--check", type=Path)
    opts=arg.parse_args()
    rows=[family(*args) for args in ((3,2,32,1),(5,4,64,2),(9,8,128,3))]
    data={"python":sys.version.split()[0],"arithmetic":"Fraction",
          "families":rows,
          "grid_average_on_original_lower_note_atom_component":[shift_test(k,r) for k in (8,32,128) for r in (Q(1,32),Q(1,9),Q(1,4))]}
    value=json.dumps(data,indent=2,sort_keys=True)+"\n"
    if opts.check:
        assert opts.check.read_text()==value
        print("groups786: exact shared-source families and shifted-grid integrals agree")
    else:
        print(value,end="")


if __name__=="__main__":
    main()
