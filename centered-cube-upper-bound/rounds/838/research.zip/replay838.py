"""Certified nested dyadic fork charges on positive-width L1 source densities."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from math import isqrt, prod
import sys


PREC_BITS = 80
LOG_TERMS = 30
RHO = F(1, 4)
RHO_STAR = F(1, 2)
DEPTHS = (4, 16, 64)
N = 8
WIDTH = F(1, 65536)


def add_bounds(items):
    low = high = F(0)
    for a, b in items:
        assert a <= b
        low += a
        high += b
    return low, high


def scale_bounds(bounds, q):
    assert q >= 0
    lo, hi = bounds
    return q*lo, q*hi


def mul_bounds(first, second):
    assert min(*first, *second) >= 0
    return first[0]*second[0], first[1]*second[1]


def output(bounds):
    lo, hi = bounds
    assert lo <= hi
    with localcontext() as ctx:
        ctx.prec = 17
        ctx.rounding = ROUND_FLOOR
        dlow = Decimal(lo.numerator) / Decimal(lo.denominator)
        ctx.rounding = ROUND_CEILING
        dhigh = Decimal(hi.numerator) / Decimal(hi.denominator)
    return f"[{dlow}, {dhigh}]"


def unit_log(value):
    assert 1 <= value <= 2
    t = (value - 1)/(value + 1)
    low = 2*sum(t**(2*j+1)/(2*j+1) for j in range(LOG_TERMS))
    tail = 2*t**(2*LOG_TERMS+1)/((2*LOG_TERMS+1)*(1-t*t))
    return low, low + tail


LOG2 = unit_log(F(2))


def log_bounds(value):
    assert value >= 1
    k = value.numerator.bit_length() - value.denominator.bit_length()
    k -= value < F(2)**k
    base = unit_log(value/(F(2)**k))
    raw = add_bounds((scale_bounds(LOG2, k), base))
    factor = 1 << PREC_BITS
    lo = F(raw[0]*factor//1, factor)
    hi = F(-(-raw[1]*factor//1), factor)
    assert lo <= raw[0] <= raw[1] <= hi
    return lo, hi


def phi(S, A):
    assert 0 < A <= S
    lo, hi = log_bounds(S/A)
    return 1/(A*(2+hi)**2), 1/(A*(2+lo)**2)


def primitive(S, A):
    if A == 0:
        return F(0), F(0)
    lo, hi = log_bounds(S/A)
    return 1/(2+hi), 1/(2+lo)


def root4(value):
    assert value >= 0
    z = isqrt(isqrt((value.numerator << (4*PREC_BITS))//value.denominator))
    lo = F(z, 1 << PREC_BITS)
    hi = lo if lo**4 == value else F(z+1, 1 << PREC_BITS)
    assert lo**4 <= value <= hi**4
    return lo, hi


@dataclass(frozen=True)
class Box:
    axes: tuple
    mass: F

    def __post_init__(self):
        assert self.mass > 0 and all(lo < hi for lo, hi in self.axes)

    def amount(self, axes):
        return self.mass*prod(max(F(0), min(hi, b)-max(lo, a))/(hi-lo)
                              for (lo, hi), (a, b) in zip(self.axes, axes, strict=True))


def box_at_origin(side, fractions):
    return tuple((side*lo, side*hi) for lo, hi in fractions)


def q_cube(side, n):
    return tuple((F(0), side) for _ in range(n))


def chain_packet(side, bits, offset, mass):
    span = tuple((offset+F(b, 2), offset+F(b, 2)+F(1, 32)) for b in bits)
    return Box(box_at_origin(side, span), mass)


def cell_coordinates(packet, side):
    indexes = tuple(lo//side for lo, _ in packet.axes)
    assert all((k+1)*side > hi for k, (_, hi) in zip(indexes, packet.axes, strict=True))
    return indexes


def chain_instance(depth):
    left, right = [], []
    counts = (1, 2, 4, N)
    for j in range(depth):
        side = F(1, 1 << j)
        h = counts[j % len(counts)]
        left_bits = tuple(int(i < h) for i in range(N))
        right_bits = tuple(int(i >= N-h) for i in range(N))
        left.append(chain_packet(side, left_bits, F(1, 16), F(1)))
        right.append(chain_packet(side, right_bits, F(1, 8), F(1, 1 << (j+1))))
    side = F(1, 1 << depth)
    left.append(chain_packet(side, (0,)*N, F(1, 16), F(1)))
    right.append(chain_packet(side, (0,)*N, F(1, 8), F(1, 1 << depth)))
    # Strictly positive widths, no atoms, and distinct packets throughout.
    assert all(a.amount(b.axes) == 0 for i, a in enumerate(left + right)
               for b in (left + right)[i+1:])
    return left, right


def total_chain(source, depth):
    return [sum(p.amount(q_cube(F(1, 1 << j), N)) for p in source)
            for j in range(depth+1)]


def charge_chain(total, masses):
    charges = []
    for parent, child in zip(masses[:-1], masses[1:], strict=True):
        assert 0 <= child <= parent
        charges.append(scale_bounds(phi(total, parent), parent-child) if parent else (F(0), F(0)))
    cost = add_bounds(charges)
    top, end = primitive(total, masses[0]), primitive(total, masses[-1])
    assert cost[1] <= top[0] - end[1] <= F(1, 2)
    no_bump = sum((p-c)/p for p, c in zip(masses[:-1], masses[1:], strict=True) if p)
    return charges, cost, no_bump, end


def verify_depth(depth):
    left, right = chain_instance(depth)
    q = right[-1]
    a, b = total_chain(left, depth), total_chain(right, depth)
    S_left, S_right = sum(p.mass for p in left), sum(p.mass for p in right)
    assert a == [F(depth + 1 - j) for j in range(depth+1)]
    assert b == [F(1, 1 << j) for j in range(depth+1)]
    left_charge, LEFT, left_harmonic, LEFT_END = charge_chain(S_left, a)
    _, RIGHT, right_harmonic, RIGHT_END = charge_chain(S_right, b)
    assert left_harmonic == sum(F(1, j) for j in range(2, depth+2))
    assert right_harmonic == F(depth, 2)
    second_parent = F(1, 4)
    second_level_pattern = cell_coordinates(left[1], second_parent)
    assert second_level_pattern[:2] == (1, 1)
    assert all(cell_coordinates(p, second_parent)[:2] == (0, 0) for p in left[2:])
    print("chain depth", depth, "dimension", N, "source totals", S_left, S_right)
    print("  nonproduct child law: second parent has both diagonal bit pairs, neither mixed pair")
    for name, bump, harmonic, terminal in (("left", LEFT, left_harmonic, LEFT_END),
                                           ("right", RIGHT, right_harmonic, RIGHT_END)):
        print(" ", name, "log bump", output(bump), "unbumped", output((harmonic, harmonic)),
              "remaining terminal budget <=", output((F(0), terminal[1])))
    fork_data = []
    for j in range(depth):
        parent_side, child_side = F(1, 1 << j), F(1, 1 << (j+1))
        z = left[j]
        parent_z, parent_q = cell_coordinates(z, parent_side), cell_coordinates(q, parent_side)
        child_z, child_q = cell_coordinates(z, child_side), cell_coordinates(q, child_side)
        assert parent_z == parent_q == (0,)*N and child_z != child_q
        assert all(cell_coordinates(z, F(1, 1 << k)) == cell_coordinates(q, F(1, 1 << k))
                   for k in range(j+1))
        # Distinct children stay distinct at every finer dyadic scale.
        H = sum(z_index != q_index for z_index, q_index in zip(child_z, child_q, strict=True))
        assert H == (1, 2, 4, N)[j % 4]
        relative_mass = ((a[j]-a[j+1])/a[j])*(b[j+1]/b[j])
        # Alpha and beta are actual parent-conditioned child masses.
        kernel = scale_bounds(root4(relative_mass**3), RHO**H)
        fork_data.append((H, z.mass/S_left, mul_bounds(left_charge[j], kernel)))
    assert sum(w for _, w, _ in fork_data) == 1 - left[-1].mass/S_left
    rho_star_norm = F(9, 8)**(N//2)
    print("  q in last true packet, mass", q.mass, "conditional fork masses by H",
          {h: sum(w for hh, w, _ in fork_data if h == hh) for h in (1, 2, 4, 8)})
    for threshold in (1, 4, 8):
        tail = sum(w for h, w, _ in fork_data if h >= threshold)
        raw = sum(w*RHO**h for h, w, _ in fork_data if h >= threshold)
        assert raw <= tail*RHO**threshold
        aggregated = add_bounds(weight for h, _, weight in fork_data if h >= threshold)
        bound = LEFT[1]*(RHO/RHO_STAR)**threshold*rho_star_norm
        assert aggregated[1] <= bound
        print("  H >=", threshold, "Ptail", tail, "raw weighted", raw,
              "fork log-bumped L18 tail", output(aggregated), "L18 upper", output((bound, bound)))


def one_packet(at, mass):
    return Box(((at, at + WIDTH),), F(mass))


def exact_true_scale():
    z1 = one_packet(F(681, 4), 24)
    z2 = one_packet(F(505, 4), 48)
    q = one_packet(F(773, 4), 24)
    all_packets = (z2, z1, q)
    source_volume = sum(p.mass for p in all_packets)
    assert source_volume == 96
    X32 = (F(381, 2), F(191))
    X64 = (F(171), F(343, 2))
    X64_same = (F(343, 2), F(172))
    assert X64[1] <= X64_same[0] and X64_same[1] < X32[0]
    assert all(Box(((lo, hi),), F(1)).amount(p.axes) == 0
               for lo, hi in (X32, X64, X64_same) for p in all_packets)
    assert max(X32[1]-24, z2.axes[0][1]) < z1.axes[0][0]
    assert X32[0]+24 > q.axes[0][1]
    assert X32[0]-z2.axes[0][1] > 48
    assert X64_same[1]-48 < z2.axes[0][0] and X64[0]+48 > q.axes[0][1]
    assert sum(p.mass for p in (z1, q)) == 2*24 and source_volume == 2*48
    # Thus for the small root, before reaching z2 the mass is <=48, and
    # the first r reaching z2 is >48. For the large root all mass is 96.
    print("actual original f packets z1,z2,q", (z1, z2, q))
    print("  lambda=1; disjoint receiver cores X32", X32, "X64-H1", X64,
          "X64-H0", X64_same, "last radii 24,48,48")
    print("  small core earliest possible far packet touch r >=",
          X32[0]-z2.axes[0][1], ">48; any r>48 sees total at most 96")
    fork_data = []
    all_rows = ((z1, X32, 48, 32, 128), (z2, X64, 96, 64, 256),
                (z1, X64_same, 96, 64, 128))
    total_left = z1.mass + z2.mass
    for z, (low, high), m, D, fork in all_rows:
        a = 2*D
        assert D <= m < 2*D and z.axes[0][1] < low < high < q.axes[0][0]
        assert cell_coordinates(z, 2*a) == cell_coordinates(q, 2*a)
        H = int(cell_coordinates(z, a) != cell_coordinates(q, a))
        assert cell_coordinates(z, fork) == cell_coordinates(q, fork)
        assert cell_coordinates(z, fork//2) != cell_coordinates(q, fork//2)
        assert H == int(fork == 2*a)
        ci = cell_coordinates(q, fork)[0]
        actual_parent = ((F(ci*fork), F((ci+1)*fork)),)
        child_index = cell_coordinates(q, fork//2)[0]
        actual_child = ((F(child_index*fork//2), F((child_index+1)*fork//2)),)
        A = sum(p.amount(actual_parent) for p in (z1, z2))
        childA = sum(p.amount(actual_child) for p in (z1, z2))
        assert A-childA == z.mass
        B = q.amount(actual_parent)
        childB = q.amount(actual_child)
        assert B == childB == q.mass
        tau = (high-low)*z.mass*q.mass/m**2
        print("  row D", D, "m_x", m, "a_D", a, "H", H, "first fork", actual_parent,
              "q child", actual_child, "A/child", (A, childA), "B/child", (B, childB),
              "tau", tau, "tau/D", tau/D)
        fork_data.append((H, tau, D, phi(total_left, A)))
    trace_left = [total_left, z1.mass, F(0)]
    _, actual_charge, no_bump, end = charge_chain(total_left, trace_left)
    assert end == (0, 0)
    print("  fixed q physical left-fork log charge", output(actual_charge), "unbumped", no_bump)
    print("  fixed q physical right-fork charge 0; fixing either left packet gives right charge 1/4")
    first = [r for r in fork_data if r[0] == 1]
    tau = sum(r[1] for r in first)
    tau_D = sum(w/D for _, w, D, _ in first)
    assert tau == F(3, 16) and tau_D == F(5, 1024)
    print("  first forks only: tau", tau, "original sum tau/D", tau_D,
          "K_rho weighted original sum", RHO*tau_D, "unbinned K_rho weighted tau", RHO*tau)
    bump = add_bounds(scale_bounds(interval, w*RHO) for _, w, _, interval in first)
    print("  first-fork log-weighted tau*K_rho", output(bump),
          "H=0 supplemental tau", sum(w for h, w, _, _ in fork_data if h == 0))
    print("  full tested tau", sum(w for _, w, _, _ in fork_data),
          "full tested sum tau/D", sum(w/D for _, w, D, _ in fork_data))
    return q, all_rows


def check_absolute_bins():
    for dimension, side in ((1, F(64)), (2, F(4)), (8, F(1, 2))):
        grid = [F(2)**k for k in range(-32, 32)]
        absolute = [D for D in grid if side**dimension <= 2*D <= (2*side)**dimension]
        assert len(absolute) == dimension+1
        print("closed length-doubling interval, n", dimension, "side", side,
              "admissible bands", absolute, "count", len(absolute))


def verify_joint_projection(q, rows):
    print("Actual joint conditional library; Xi = ((m_x/P_D)*tau_D) projected to (z,q), divided by 2.")
    print("  theta(z,q) = |X|/(2*m_x*P_D), P_D = 1 - |q-z|/a_D, lambda = 1.")
    libraries = []
    unweighted = supplemental_tau = F(0)
    qlo, qhi = q.axes[0]
    h = 1
    for z, (xlo, xhi), m, D, fork in rows:
        a = F(2*D)
        zlo, zhi = z.axes[0]
        assert zhi < qlo
        endpoints = tuple(1 - abs(qp-zp)/a for qp in (qlo, qhi) for zp in (zlo, zhi))
        p_min, p_max = min(endpoints), max(endpoints)
        assert 0 < p_min < p_max < 1
        scale = (xhi-xlo)/(2*m)
        bounds = scale/p_max, scale/p_min
        assert 0 <= bounds[0] <= bounds[1] <= 1
        H = int(fork == 2*a)
        print("  D", D, "H", H, "P exact endpoints", (p_min, p_max),
              "theta exact endpoints", bounds, "theta decimal", output(bounds))
        if H == h:
            # Monotone in q, so endpoints of the q-packet give uniform fixed-q bounds.
            mass_density = z.mass/(zhi-zlo)
            lows, highs = (log_bounds((a-qp+zhi)/(a-qp+zlo)) for qp in (qlo, qhi))
            library = scale_bounds((lows[0], highs[1]), scale*a*mass_density)
            crude = scale_bounds(bounds, z.mass)
            assert crude[0] <= library[0] <= library[1] <= crude[1] < z.mass
            libraries.append(library)
            unweighted += z.mass
            print("    fixed-q L with rho^(H-h)=1: exact endpoints", library,
                  "decimal", output(library), "unweighted left mass", z.mass)
        else:
            tau = (xhi-xlo)*z.mass*q.mass/m**2
            supplemental_tau += tau
            print("    H=0 supplement retains original tau", tau)
    assert len(libraries) == 2 and unweighted == 72 and supplemental_tau == F(1, 32)
    print("  sum of H=1 true conditional libraries", output(add_bounds(libraries)),
          "unweighted left partner mass", unweighted, "separate H=0 tau", supplemental_tau)


def terminal_log_prefactor(n):
    # On F, U_C >= exp(kappa*b/2)*m_t >= m_g.  The two-sided
    # phi_theta uses |ln(U_C/m_g)| = ln(U_C/m_g) in this range.
    assert n > 0
    length_log = add_bounds(((F(2), F(2)), log_bounds(F(256)),
                             scale_bounds(log_bounds(F(40)), n)))
    exterior_charge = F(1, 2)/length_log[1]**2, F(1, 2)/length_log[0]**2
    ln_pref = add_bounds((log_bounds(F(2*n)),
                         (2*log_bounds(length_log[0])[0], 2*log_bounds(length_log[1])[1])))
    ln2_lo, ln2_hi = log_bounds(F(2))
    return (ln_pref[0]/ln2_hi, ln_pref[1]/ln2_lo), exterior_charge


def terminal_log_coefficient(pref, b):
    lo, hi = b
    assert 0 <= lo <= hi
    h = lo//16
    assert hi//16 == h
    return h, (pref[0]-h+lo/64, pref[1]-h+hi/64)


def classify_sign(bounds, h):
    if h == 0:
        assert bounds[0] > 0
        return "h=0: no tail attenuation"
    assert bounds[0] > 0 or bounds[1] < 0
    return "above 1" if bounds[0] > 0 else "below 1"


def integer_terminal_threshold(pref, safety_bits):
    shifted = pref[0]+safety_bits, pref[1]+safety_bits
    step = F(3, 4)
    k = 1 + shifted[1]//step
    assert (k-1)*step <= shifted[0] <= shifted[1] < k*step
    last_of_block = shifted[0]-k*step+F(15, 64), shifted[1]-k*step+F(15, 64)
    assert last_of_block[0] >= 0 or last_of_block[1] < 0
    eventual = 16*k if last_of_block[1] < 0 else 16*(k+1)
    return 16*k, eventual


def verify_terminal_coefficient():
    print("Independent terminal coefficient certificate; unknown absolute multiplier omitted.")
    print("  phi_theta(x)=1/[x*(2+abs(ln(x/theta)))^2]; on F: U_C >= m_t >= m_g.")
    print("  U_C/m_g <= 256*40^n and U_ext >= U_C/2, so charge >= 1/[2*(2+ln256+n*ln40)^2].")
    print("  K=2*n*(2+ln256+n*ln40)^2*2^(-floor(b/16)+b/64).")
    print("  diagnostics b=sqrt(n)*ln(n+2)/16, not fixed problem constants:")
    roots = (1, 4, 16, 32, 64, 256, 1024, 1400, 1500, 1580, 1590, 1600, 2048, 4096, 65536)
    for root in roots:
        n = root**2
        pref, charge = terminal_log_prefactor(n)
        b = scale_bounds(log_bounds(F(n+2)), F(root, 16))
        h, coeff = terminal_log_coefficient(pref, b)
        print("  n", n, "b", output(b), "h", h,
              "log2(K)", output(coeff), classify_sign(coeff, h),
              "lower-charge constant", output(charge))
    print("  integer b stresses, first below cutoff and first b after which all integers are below cutoff:")
    for n in (1024, 4096, 65536):
        pref, _ = terminal_log_prefactor(n)
        first, eventual = integer_terminal_threshold(pref, 0)
        first_32, eventual_32 = integer_terminal_threshold(pref, 32)
        print("  n", n, "log2(prefactor)", output(pref), "K<1", (first, eventual),
              "K<2^-32", (first_32, eventual_32))
        for b in sorted({0, 15, 16, first-1, first, first+15, eventual, eventual_32}):
            h, coeff = terminal_log_coefficient(pref, (F(b), F(b)))
            label = classify_sign(coeff, h)
            print("    b", b, "h", h, "log2(K)", output(coeff), label)
    print("  for any real b>=0, log2(K) lies in [log2(prefactor)-3b/64,")
    print("    log2(prefactor)-3b/64+1); attenuation of K alone assumes no unknown multiplier.")


def main():
    print("Python", sys.version.split()[0], sys.executable)
    print("Exact Fraction; log series terms", LOG_TERMS, "dyadic endpoint bits", PREC_BITS)
    for depth in DEPTHS:
        verify_depth(depth)
    check_absolute_bins()
    q, rows = exact_true_scale()
    verify_joint_projection(q, rows)
    verify_terminal_coefficient()
    print("Scope: nested physical forks and the stated score geometry; no full R813 history eligibility.")
    print("PASS")


if __name__ == "__main__":
    main()
