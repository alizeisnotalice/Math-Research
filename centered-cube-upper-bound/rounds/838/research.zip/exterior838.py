#!/usr/bin/env python3
"""Exact finite positive-box replay of the two exterior source routes.

Tree labels are bit masks for dyadic children. Each leaf's source box is the
middle half of its dyadic interval along every coordinate. A coefficient s
selects the leftmost s fraction of the actual external box along coordinate 0.
The input measures and every route restriction are deterministic and rational.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from pathlib import Path
import argparse
import platform

TOTAL = {"mu": F(25), "+": F(9), "-": F(4)}
FIELDS = tuple(TOTAL)
SQ_TOTAL = {"+": F(15), "-": F(10)}
LOG_TERMS = 20
SQRT_BITS = 64


def child_distance(x: int, y: int) -> int:
    return (x ^ y).bit_count()


def fixture(dim: int, depth: int, fan: int, asymmetric: bool):
    """Return positive measures on genuine boxes of volume 2^(-dim*(depth+1))."""
    mask = (1 << dim) - 1
    alternate = sum(1 << i for i in range(0, dim, 2))
    jumps = (0, mask, alternate, mask ^ alternate)
    frontier = [()]
    for layer in range(depth):
        new = []
        for path in frontier:
            seed = (sum(((i + 1) * p) ^ (p << 1) for i, p in enumerate(path))
                    ^ (layer * 3 + (1 if asymmetric else 0))) & mask
            new.extend((*path, seed ^ jump) for jump in jumps[:fan])
        frontier = new
    assert len(frontier) == len(set(frontier)) == fan**depth
    raw = {s: {} for s in FIELDS}
    for p in frontier:
        layers = sum((i + 1) * c for i, c in enumerate(p))
        # Agreement of distant bits and cross-level parity create dependence.
        cross = (p[0] ^ p[-1]).bit_count()
        agreement = int(all(((c & 1) == ((c >> 1) & 1)) for c in p))
        if asymmetric:
            raw["mu"][p] = 1 + (3 + layers * 7) % 13 + 47 * agreement
            raw["+"][p] = 1 + (5 + layers * 11 + cross * 3) % 23 + 53 * (1 - agreement)
            raw["-"][p] = 1 + (9 + layers * 5 + cross * 7) % 17 + 41 * (cross % 2)
        else:
            raw["mu"][p] = 1 + layers % 3
            raw["+"][p] = 1 + (layers + cross) % 3
            raw["-"][p] = 1 + (layers + 2 * cross) % 3
    normalized = {}
    for s in FIELDS:
        raw_sum = sum(raw[s].values())
        normalized[s] = {p: TOTAL[s] * F(m, raw_sum) for p, m in raw[s].items()}
        assert sum(normalized[s].values()) == TOTAL[s]
    return normalized


def coarse_table(measures):
    nodes = {}
    for s, box_masses in measures.items():
        for path, mass in box_masses.items():
            for level, label in enumerate(path):
                C = path[:level]
                if C not in nodes:
                    nodes[C] = {source: defaultdict(F) for source in FIELDS}
                nodes[C][s][label] += mass
    return nodes


def parent_ring(w, anchor):
    for level, (wi, ai) in enumerate(zip(w, anchor)):
        if wi != ai:
            return w[:level]
    return None


def external_slice(C, z, q, w, partial):
    if not partial:
        return F(1)
    code = 13 * (len(C) + 1) + sum((i + 1) * c for i, c in enumerate(C))
    pick = (code + 3 * z + 5 * q + 7 * w + child_distance(z, w)) % 8
    return (F(0), F(1, 4), F(1, 2), F(3, 4), F(1), F(0), F(1, 3), F(1))[pick]


@lru_cache(maxsize=None)
def log_small_bounds(x):
    assert F(1) <= x <= F(2)
    y = (x - 1) / (x + 1)
    y2 = y * y
    power = y
    lower = F(0)
    for j in range(LOG_TERMS):
        lower += 2 * power / (2 * j + 1)
        power *= y2
    tail = 2 * power / ((2 * LOG_TERMS + 1) * (1 - y2))
    return lower, lower + tail


@lru_cache(maxsize=None)
def log_bounds(x):
    assert x >= 1
    level = 0
    while x >= 2:
        x /= 2
        level += 1
    lo, hi = log_small_bounds(x)
    lo2, hi2 = log_small_bounds(F(2))
    return lo + level * lo2, hi + level * hi2


def sqrt_bounds(x):
    assert x >= 0
    scale = 1 << SQRT_BITS
    scaled_numerator = x.numerator * scale**2
    lower = isqrt(scaled_numerator // x.denominator)
    upper = lower + (lower**2 * x.denominator != scaled_numerator)
    return F(lower, scale), F(upper, scale)


@lru_cache(maxsize=None)
def phi_bounds(total, mass):
    assert 0 < mass <= total
    lower_log, upper_log = log_bounds(total / mass)
    return 1 / (mass * (2 + upper_log)**2), 1 / (mass * (2 + lower_log)**2)


def quote_bounds(mu_mass, side_mass, side, version):
    if version == "constant":
        return (1 / SQ_TOTAL[side],) * 2
    ml, mh = phi_bounds(TOTAL["mu"], mu_mass)
    sl, sh = phi_bounds(TOTAL[side], side_mass)
    return sqrt_bounds(ml * sl)[0], sqrt_bounds(mh * sh)[1]


def summarize_fixture(name, dim, depth, fan, h, rho, asymmetric, allow_partial):
    measures = fixture(dim, depth, fan, asymmetric)
    nodes = coarse_table(measures)
    leaves = tuple(measures["mu"])
    eligible_scale = rho**h
    ring = {a: defaultdict(F) for a in ("+", "-")}
    # Independent pair enumeration. Each ordered physical price pair has one
    # exterior annulus, regardless of how many z partners route to its anchor.
    for w in leaves:
        for price in leaves:
            C = parent_ring(w, price)
            if C is not None:
                for a in ring:
                    ring[a][C] += measures["mu"][w] * measures[a][price]
    chosen = {a: defaultdict(F) for a in ring}
    whole = {a: defaultdict(F) for a in ring}
    route_count = defaultdict(int)
    w_coarse_usage = defaultdict(set)
    skipped_by_slice = 0
    proper_slices = 0
    full_slices = 0
    anchor_proofs = 0
    physical_ring_rows = 0
    for C, data in nodes.items():
        for side in ring:
            grouped_ring = sum(wm * am for w, wm in data["mu"].items()
                               for a, am in data[side].items() if w != a)
            assert grouped_ring == ring[side][C]

        left_library = {
            q: sum((zm * rho**(d - h)
                    for z, zm in data["-"].items() if (d := child_distance(z, q)) >= h), F())
            for q in data["+"]
        }
        right_library = {
            z: sum((qm * rho**(d - h)
                    for q, qm in data["+"].items() if (d := child_distance(z, q)) >= h), F())
            for z in data["-"]
        }
        # Complete anchored far library, before the external routing or cuts.
        for side, anchors, far in (("+", left_library, data["-"]),
                                    ("-", right_library, data["+"])):
            for a, library in anchors.items():
                if library == 0:
                    continue
                lhs = sum((mass * rho**d / library for far_label, mass in far.items()
                           if (d := child_distance(a, far_label)) >= h), F())
                assert lhs == eligible_scale, (side, C, a, lhs, eligible_scale)
                anchor_proofs += 1

        load_full = defaultdict(F)
        load_slice = defaultdict(F)
        for z, zm in data["-"].items():
            for q, qm in data["+"].items():
                d = child_distance(z, q)
                if d < h:
                    continue
                for w, wm in data["mu"].items():
                    route = "+" if child_distance(q, w) >= child_distance(z, w) else "-"
                    a = q if route == "+" else z
                    assert a != w
                    far_bin_mass = zm if route == "+" else qm
                    library = left_library[q] if route == "+" else right_library[z]
                    assert library > 0
                    speed = far_bin_mass * rho**d / library
                    key = (route, a, w)
                    load_full[key] += speed
                    cut = external_slice(C, z, q, w, allow_partial)
                    load_slice[key] += cut * speed
                    if cut == 0:
                        skipped_by_slice += 1
                    elif cut < 1:
                        proper_slices += 1
                    else:
                        full_slices += 1
                    if cut:
                        route_count[(C, w)] += 1
                        for box in leaves:
                            if box[:len(C) + 1] == (*C, w):
                                w_coarse_usage[box].add(C)

        for (side, a, w), value in load_full.items():
            physical_ring_rows += 1
            assert 0 <= load_slice[side, a, w] <= value <= eligible_scale
            mass = data["mu"][w] * data[side][a]
            whole[side][C] += value * mass
            chosen[side][C] += load_slice[side, a, w] * mass
        for side in ring:
            assert chosen[side][C] <= whole[side][C] <= eligible_scale * ring[side][C]
    assert all(sum(chosen[side].values()) > 0 for side in ring)
    assert any(len(ancestors) > 1 for ancestors in w_coarse_usage.values())
    if allow_partial:
        assert skipped_by_slice and proper_slices and full_slices
        assert any(sum(chosen[side].values()) < sum(whole[side].values()) for side in ring)

    print(f"{name}: dim={dim}, depth={depth}, h={h}, rho={rho}, boxes={len(leaves)}, coarse_cells={len(nodes)}")
    print(f"  positive-box volume=2^(-{dim * (depth + 1)}), totals (mu,+,-)=({TOTAL['mu']},{TOTAL['+']},{TOTAL['-']})")
    print(f"  normalized anchors={anchor_proofs}, routed oriented coarse rows={physical_ring_rows}")
    print(f"  exclusive physical annuli independently enumerated, external boxes used at >=2 coarse ancestors={sum(len(a)>1 for a in w_coarse_usage.values())}")
    print(f"  max positive routed triples sharing a coarse external child={max(route_count.values())}, external cut (zero,proper,full)=({skipped_by_slice},{proper_slices},{full_slices})")
    for version in ("constant", "log"):
        combined_hi = F()
        combined_limit = F()
        for side in ("+", "-"):
            fee_lo = fee_hi = full_fee_hi = ring_fee_hi = F()
            for C, data in nodes.items():
                mu_mass = sum(data["mu"].values())
                side_mass = sum(data[side].values())
                lo, hi = quote_bounds(mu_mass, side_mass, side, version)
                fee_lo += chosen[side][C] * lo
                fee_hi += chosen[side][C] * hi
                full_fee_hi += whole[side][C] * hi
                ring_fee_hi += eligible_scale * ring[side][C] * hi
            limit = eligible_scale * SQ_TOTAL[side] / (1 if version == "constant" else 2)
            assert fee_lo <= fee_hi <= full_fee_hi <= ring_fee_hi <= limit
            combined_hi += fee_hi
            combined_limit += limit
            print(f"  {version} {side}: selected fee in [{float(fee_lo):.12g},{float(fee_hi):.12g}], "
                  f"full-routed upper={float(full_fee_hi):.12g}, exclusive-ring upper={float(ring_fee_hi):.12g}, "
                  f"bound={float(limit):.12g}, all inequalities exact")
        assert combined_hi <= combined_limit
        print(f"  {version} combined selected upper={float(combined_hi):.12g} <= {float(combined_limit):.12g}")
    print()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".txt"))
    args = parser.parse_args()
    from contextlib import redirect_stdout
    from io import StringIO

    report = StringIO()
    with redirect_stdout(report):
        print("Replay: python -B exterior838.py")
        print("Python:", platform.python_version())
        print("No randomness; rational masses, exact route loads and directed rational logarithm/square root intervals.")
        print("Printed decimal endpoints are rounded for display; assertions compare the exact rational bounds.")
        print("Constant control: phi_S=1/S (side factor 1). Log control: phi_S(t)=1/[t(2+ln(S/t))^2] (side factor 1/2).")
        print(f"Log enclosure uses {LOG_TERMS} positive atanh terms after dyadic reduction; sqrt grid 2^(-{SQRT_BITS}).")
        print()
        summarize_fixture("initial", 2, 2, 4, 1, F(1, 4), False, False)
        summarize_fixture("correlated selective", 4, 3, 4, 2, F(2, 5), True, True)
        summarize_fixture("deeper higher-dimensional selective", 9, 5, 3, 4, F(1, 3), True, True)
        print("The selected tests use finite positive source boxes, not actual R813 histories.")
        print("Selective fixtures cut actual external boxes; passing them does not give the unselected geometry full history eligibility.")
        print("All assertions passed.")
    args.output.write_text(report.getvalue(), encoding="utf-8")
    print(report.getvalue(), end="")


if __name__ == "__main__":
    main()
