"""Exact accounting checks; no sign assertion for the full geometric budget."""
import sympy as s,json
v,m,lam,z,u,eps=s.symbols('v m lam z u eps',positive=True)
checks={}
checks['cell_matching']=s.cancel(v*lam*z/(lam*m)-v*z/m)
d=s.symbols('d',positive=True)
checks['lost_cap_scale']=s.cancel(eps*(1+u)*v/u-lam*(1+u)*d).subs(v,lam*u*d/eps).cancel()
x,y,b=s.symbols('x y b',real=True)
checks['scalar_mixing_numerator']=s.expand((1+b)*(x*x+b*y*y)-(x+b*y)**2-b*(x-y)**2)
H,DH,CH,J,kf,ko,L,E,O,F,R,M,S,X=s.symbols('H DH CH J kf ko L E O F R M S X')
proto=H-DH+CH-J+eps*(kf-ko)
Phi=proto+X;Qp=M-S;D=E-O+F+R*S
target=E+L*DH-L*CH+L*J+F-O-L*eps*(kf-ko)+(R-L*H/M)*S-L*X
checks['full_euler_ledger']=s.expand(D+L*Qp/M*H-L*Phi-target)
H0,eta=s.symbols('H0 eta')
checks['source_score_gap']=s.expand((R-L*H0/M)-(R-L*H/M)-L*(H-H0)/M)
assert all(val==0 for val in checks.values()),checks
print(json.dumps({'residuals':{k:str(val) for k,val in checks.items()},'sympy':s.__version__,'scope':'Algebra only; not a positive Gamma certificate.'}))
