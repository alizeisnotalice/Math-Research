% R651: independent double numerical product-law quadrature (not a proof).
r=1/16; delta=1/32; b=7/4; h=1/256; w=1/1024; sig=11/4; ep=56; eta=1/4096;
funA=@(u,v) ep*r*(delta-b*h*(v-u)).^3./(r+delta-b*h*(v-u))/4;
funB=@(u,v) (ep*r/2)*(sig*delta-b*w*(u+v)).^2;
a=integral2(funA,-1,1,-1,1,'AbsTol',1e-15,'RelTol',1e-13);
bb=integral2(funB,0,1,0,1,'AbsTol',1e-15,'RelTol',1e-13);
A=18333/262144; B=145341/4194304; fa=ep*(r+delta)*eta^2/3; fb=ep*2*r*eta^2/3;
slope=(B-bb)-(A-a); slopeAC=slope+fa-fb; cross=-1/32/slope; crossAC=-1/32/slopeAC;
refA=0.0012157744822145494509647527480308958; refB=4999393/402653184;
fprintf('MATLAB %s\n',version);
fprintf('integral2 AbsTol=1e-15 RelTol=1e-13; A %.17g B %.17g\n',a,bb);
fprintf('A_vs_Arb_center %.17g B_vs_rational %.17g\n',a-refA,bb-refB);
fprintf('slope %.17g crossing %.17g actual_slope %.17g actual_crossing %.17g\n',slope,cross,slopeAC,crossAC);
fprintf('AC fees A %.17g B %.17g\n',fa,fb);
