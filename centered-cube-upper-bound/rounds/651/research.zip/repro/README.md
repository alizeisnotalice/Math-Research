# R651 reproduction

Actual Python: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (3.12.14), SymPy 1.14.0, python-flint 0.9.0, Arb 256-bit. Floating quadrature uses the installed NumPy; its output does not independently pin a library version. MATLAB R2026a Update 4 was actually run through the connected tool; the raw output is preserved, not rerun by the archive verifier.

Commands from this directory:

```
python -B check_old.py
python -B check_expectation.py
python -B action_quad.py
python -B check_rectangle.py
python -B check_cover.py
python -B check_ledger.py
```

The first two emit JSON and are compared to archived exact outputs. `check_expectation.py` proves its two-source integral identities symbolically and evaluates rationals/logarithms directly with Arb, never through binary float. The printed decimal radii are outward representations of the balls. `action_quad.py` performs orders 16/32/64/128 and five actual-action checks per source; it is diagnostic, without a quadrature error certificate. The independent MATLAB script is `crosscheck.m`.

These two-source experiments use the OLD minimizing-assignment branch, with each source's assignment recomputed. They do NOT certify expectations for the new Eulerian branch. They cover the full frozen independent anchor laws, but only n=1 and old R=1/16; no hard-state or global theorem is inferred.

`check_rectangle.py` checks 1048 exact rational points in eight symmetric cell examples at n=1,2,7,32. It includes flat directions and a weak center row of weight 2^-20; the modulus loss is retained. The proof in REPORT, not these finite points, establishes the general minimum-set theorem.

`check_cover.py` checks the finite fractional-cover construction on 130 rational distributions over universes of size 1 through 8, including an intersecting seven-point family and disjoint singleton patterns. It also symbolically checks the near-tie obstruction. These are abstract set/row-law checks, not actual old KKT cube families. Regenerable rectangle/cover JSON outputs are omitted from the archive.

`check_ledger.py` checks five exact accounting identities. No script asserts a positive global Gamma. Experiments were small and bounded, with no parameter expansion outside the frozen tasks and no artificial CPU load. No PDF was compiled.

The archive verifier executes copies in a temporary directory, checks the exact outputs and the report/audit hashes, and leaves archived evidence untouched. Replaying under different library versions may change serialized ball strings; any difference must be inspected rather than silently treated as a mathematical failure or success.
