"""R651 §1–2 exact AC-old-source certificate; no source atoms or scans."""
from fractions import Fraction as F
import json,platform
import sympy as sp

k=F(7,2); t=F(9,2); s=F(2,9); b=F(7,4); sigma=F(11,4); eps=F(56); a=F(32)
delta=F(1,32); h=F(1,256); w=F(1,1024)
y1=-delta/2; y2=delta/2; d=2*s; v=d/a; lam=F(1,2)
M=F(2); m=F(2); Q=2*lam*d; V=2*v
assert y1+s<y2+s and y2-s<y1+s
assert y1+s/a < y2-s/a
assert d+eps*v/lam==m and 2*lam*m==M
assert eps*V/Q==k and V/Q==F(1,16)
# Both closed support intervals lie in the open common old intersection.
common=(y2-s,y1+s)
A1=(y1-h,y1+h); A2=(y2-h,y2+h); B=(-w,w)
assert common[0]<A1[0]<A1[1]<0<A2[0]<A2[1]<common[1]
assert common[0]<B[0]<0<B[1]<common[1]
# Each A component has mass 1 with density 1/(2h); B has total mass 2 with density 1/w.
assert 2*h*(1/(2*h))==1 and 2*w*(1/w)==2
x=sp.symbols('x',real=True)
def S(v): return sp.Rational(v.numerator,v.denominator)
def frac(v):
 v=sp.cancel(v)
 assert v.is_Rational
 return F(int(v.p),int(v.q))
def integrate(f,left,right,density):
 return frac(sp.integrate(f,(x,S(left),S(right)))*S(density))
G=S(k*t*t)*(x*x+S(delta*delta/4))
phi=2*frac(G.subs(x,0))
HA=sum((integrate(G,*box,1/(2*h)) for box in (A1,A2)),F(0))
HB=integrate(G,*B,1/w)
assert phi==F(567,16384) and HA==F(18333,262144)
assert HB==F(145341,4194304)
assert HA/phi==F(97,48) and HA-phi==F(9261,262144) and HB-phi==F(189,4194304)
# The unique old saturated membership K={1,2}: primal z=2, dual (G(0),0).
old_dual=(phi/2,F(0)); assert sum(old_dual)*M==phi
# Pointwise r1²-r2²=(2 delta/s²)x; common row price k*B(k)>0.
r1=(x-S(y1))**2/S(s*s); r2=(x-S(y2))**2/S(s*s)
assert sp.expand(r1-r2-2*S(delta)*x/S(s*s))==0
B_k=(1-1/t**2)/4; price=k*B_k; assert price>0
# Exact integration of each candidate assignment over the genuine positive-width supports.
assignedA=price*(integrate(r1,*A1,1/(2*h))+integrate(r2,*A2,1/(2*h)))
reverseA=price*(integrate(r2,*A1,1/(2*h))+integrate(r1,*A2,1/(2*h)))
assignedB=price*(integrate(r1,-w,F(0),1/w)+integrate(r2,F(0),w,1/w))
reverseB=price*(integrate(r2,-w,F(0),1/w)+integrate(r1,F(0),w,1/w))
assert reverseA-assignedA==price*2*delta*delta/(s*s)
assert reverseB-assignedB==price*2*delta*w/(s*s)
assert reverseA>assignedA and reverseB>assignedB
# Independent draws from each normalized assigned row measure.
A_range=(delta-2*b*h,delta+2*b*h)
B_range=(sigma*delta-2*b*w,sigma*delta)
r=2/a
assert A_range==(F(9,512),F(23,512)) and 0<A_range[0]<A_range[1]<r
assert B_range==(F(169,2048),F(11,128)) and r<B_range[0]<B_range[1]<2

def st(x): return str(x)
result={
 'scope':'exact one-dimensional AC old sources, no hard-state R>1',
 'python':platform.python_version(),'sympy':sp.__version__,
 'geometry':{'A1':[st(y1-s),st(y1+s)],'A2':[st(y2-s),st(y2+s)],'old_common':list(map(st,common)),'old_piece_radius':st(s/a),'d':st(d),'v':st(v),'lambda':st(lam),'M':st(M),'Q':st(Q),'V':st(V),'R':st(V/Q),'epsilon':st(eps),'kappa':st(k)},
 'lp_old':{'cell':[1,2],'z':st(M),'dual':list(map(st,old_dual)),'G_min':st(phi/2),'Phi':st(phi),'infimum_attained_by_AC':False},
 'A':{'support_1':list(map(st,A1)),'support_2':list(map(st,A2)),'density_each':st(1/(2*h)),'row_masses':['1','1'],'H':st(HA),'gap':st(HA-phi),'H_over_Phi':st(HA/phi),'optimal_weighted_cost':st(assignedA),'reverse_weighted_cost':st(reverseA),'weighted_cost_difference':st(reverseA-assignedA),'delta_range':list(map(st,A_range))},
 'B':{'support':list(map(st,B)),'density':st(1/w),'row_masses':['1','1'],'H':st(HB),'gap':st(HB-phi),'optimal_weighted_cost':st(assignedB),'reverse_weighted_cost':st(reverseB),'weighted_cost_difference':st(reverseB-assignedB),'delta_range':list(map(st,B_range))},
 'weight_factor':st(price),'radius_new':'1','receiver_pair_overlap_threshold':st(r),'anchor_laws':'independent draws from the normalized optimal row-restricted measures'
}
print(json.dumps(result,ensure_ascii=False,indent=2))
