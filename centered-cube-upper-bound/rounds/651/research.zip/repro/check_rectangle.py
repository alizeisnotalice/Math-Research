"""Finite exact stress checks for the proved rectangle lemma; no global bound."""
from fractions import Fraction as F
from itertools import product
import json,random
from pathlib import Path

def test(n,small_center):
    d=F(1,4)
    centers=[[-d]+[F(0)]*(n-1),[d]+[F(0)]*(n-1)]
    weights=[F(1),F(1)]
    radii=[d,d]
    if small_center:
        centers.append([F(0)]*n);weights.append(F(1,2**20));radii.append(F(0))
    lo=[max(c[i]-1 for c in centers) for i in range(n)]
    hi=[min(c[i]+1 for c in centers) for i in range(n)]
    zl=[max([lo[i]]+[c[i]-r for c,r in zip(centers,radii)]) for i in range(n)]
    zh=[min([hi[i]]+[c[i]+r for c,r in zip(centers,radii)]) for i in range(n)]
    opt=sum(w*r*r for w,r in zip(weights,radii))
    points=[]
    rng=random.Random(651+n+100*small_center)
    for _ in range(128):
        points.append([lo[i]+(hi[i]-lo[i])*F(rng.randrange(257),256) for i in range(n)])
    points.extend([lo,hi,[(a+b)/2 for a,b in zip(zl,zh)]])
    for x in points:
        distances=[max(abs(xx-cc) for xx,cc in zip(x,c)) for c in centers]
        cost=sum(w*t*t for w,t in zip(weights,distances))
        assert cost-opt>=sum(w*(t-r)**2 for w,t,r in zip(weights,distances,radii))
        actual=max(max(a-xx,xx-b,F(0)) for xx,a,b in zip(x,zl,zh))
        formula=max([F(0)]+[t-r for t,r in zip(distances,radii)])
        assert actual==formula
        assert actual*actual<=max(1/w for w in weights)*(cost-opt)
    for c,r in zip(centers,radii):
        assert any(a==b and abs(a-cc)==r for a,b,cc in zip(zl,zh,c))
    return {'n':n,'small_center_weight':str(weights[-1]) if small_center else None,'points':len(points),'collapsed_coordinates':sum(a==b for a,b in zip(zl,zh))}

records=[test(n,k) for n,k in product([1,2,7,32],[False,True])]
# Exact degeneration: in the centered weak-row case along an otherwise flat axis.
weak=F(1,2**20);y=F(1,8)
gap=weak*y*y
assert y*y/gap==2**20
out={'cases':records,'total_points':sum(r['points'] for r in records),'weak_weight_modulus_ratio':2**20,'scope':'Exact finite tests of radius-gap, distance and contact identities. Not arbitrary-dimensional/global-budget certification.'}
Path(__file__).with_name('rectangle_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
