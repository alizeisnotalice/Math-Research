"""R651 frozen endpoint product-law expectation; exact algebra + 256-bit Arb."""
import json, platform
from fractions import Fraction as F
import sympy as S
from flint import arb, ctx
import flint
ctx.prec=256
r,delta,q,eps=S.Rational(1,16),S.Rational(1,32),S.Rational(7,512),S.Integer(56)
h,w,b,sigma=S.Rational(1,256),S.Rational(1,1024),S.Rational(7,4),S.Rational(11,4)
A=r+delta
# For triangular density t in [-q,q], integrate the two halves using
# exact antiderivatives, then verify them by differentiation.
t=S.symbols('t',real=True)
Fleft=t+(q-A)*S.log(A+t)
Fright=-t+(q+A)*S.log(A+t)
assert S.simplify(S.diff(Fleft,t)-(q+t)/(A+t))==0
assert S.simplify(S.diff(Fright,t)-(q-t)/(A+t))==0
J=S.expand_log(S.simplify((Fleft.subs(t,0)-Fleft.subs(t,-q)+Fright.subs(t,q)-Fright.subs(t,0))/q**2),force=True)
Jtarget=S.Rational(512,49)*(55*S.log(S.Rational(55,48))+41*S.log(S.Rational(41,48)))
assert S.simplify(S.expand_log(J-Jtarget,force=True))==0
# Polynomial division is checked algebraically before expectation is applied.
x=S.symbols('x',positive=True)
assert S.cancel(x**3/(r+x)-(x*x-r*x+r*r-r**3/(r+x)))==0
Ea=S.expand(eps*r*(delta**2+q**2/6-r*delta+r**2-r**3*Jtarget))
Eb=eps*r/2*(sigma**2*delta**2-2*sigma*b*delta*w+S.Rational(7,6)*b*b*w*w)
assert Eb==S.Rational(4999393,402653184)
HA=S.Rational(18333,262144); HB=S.Rational(145341,4194304)
assert HB-Eb==S.Rational(8953343,402653184)
feeA=S.Rational(7,67108864); feeB=S.Rational(7,50331648)
assert feeA==eps*(r+delta)*S.Rational(1,4096)**2/3
assert feeB==eps*(2*r)*S.Rational(1,4096)**2/3
# Weighted center lies between centers; eta stays inside their common C intersection.
eta=S.Rational(1,4096)
a_range=(delta-q,delta+q); b_range=(sigma*delta-2*b*w,sigma*delta)
assert a_range==(S.Rational(9,512),S.Rational(23,512))
assert b_range==(S.Rational(169,2048),S.Rational(11,128))
assert max(a_range[1],b_range[1])+eta < 1
# Convert rational and logs directly to ball arithmetic, never through float.
def ar(z):
 z=S.Rational(z); return arb(str(z.p))/arb(str(z.q))
Ja=ar(S.Rational(512,49))*(arb(55)*(arb(55)/48).log()+arb(41)*(arb(41)/48).log())
epa=ar(eps*r)*(ar(delta**2+q**2/6-r*delta+r**2)-ar(r**3)*Ja)
ca=ar(HA)-epa; cb=ar(HB-Eb); slope=cb-ca
actual_slope=(cb-ar(feeB))-(ca-ar(feeA))
cross=-ar(S.Rational(1,32))/slope
actual_cross=-ar(S.Rational(1,32))/actual_slope
assert slope<0 and actual_slope<0 and cross>0 and actual_cross>0
fmt=lambda z:z.str(45,more=True)
out={'precision_bits':ctx.prec,'python':platform.python_version(),'sympy':S.__version__,'python_flint':flint.__version__,'input':{'r':str(r),'delta':str(delta),'q':str(q),'epsilon':str(eps),'h':str(h),'w':str(w),'eta':'1/4096','separation_A':[str(v) for v in a_range],'separation_B':[str(v) for v in b_range]},'exact':{'J':str(Jtarget),'E_phi_A':str(Ea),'E_phi_B':str(Eb),'H_A':str(HA),'H_B':str(HB),'B_slope':str(HB-Eb),'A_fee':str(feeA),'B_fee':str(feeB),'difference':'1/32 + L*(B_slope - (H_A-E_phi_A))','actual_difference':'1/32 + L*((B_slope-B_fee) - (H_A-E_phi_A-A_fee))'},'arb':{'J':fmt(Ja),'E_phi_A':fmt(epa),'A_slope':fmt(ca),'B_slope':fmt(cb),'difference_slope':fmt(slope),'crossing':fmt(cross),'actual_A_slope':fmt(ca-ar(feeA)),'actual_B_slope':fmt(cb-ar(feeB)),'actual_difference_slope':fmt(actual_slope),'actual_crossing':fmt(actual_cross)}}
print(json.dumps(out,indent=2,ensure_ascii=False))
