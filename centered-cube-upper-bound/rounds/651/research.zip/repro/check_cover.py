"""Exact finite tests of the contact-cover construction, not cube-budget evidence."""
from fractions import Fraction as F
from math import isqrt
import random,json
from pathlib import Path
import sympy as s

def verify(m,sets,counts):
 total=sum(counts);p=[F(c,total) for c in counts]
 delta=sum((a*b for A,a in zip(sets,p) for B,b in zip(sets,p) if A.isdisjoint(B)),F(0))
 small=[i for i,A in enumerate(sets) if len(A)**2<=m]
 mass=sum((p[i] for i in small),F(0))
 if mass*mass<=delta:
  missed=mass
  branch='uniform_1_over_sqrt_m'
  # Large sets have |A|/sqrt(m)>1; exact integer comparison.
  assert all(len(A)**2>m for i,A in enumerate(sets) if i not in small)
 else:
  bad={i:sum((p[j] for j,B in enumerate(sets) if sets[i].isdisjoint(B)),F(0)) for i in small}
  i=min(bad,key=bad.get);missed=bad[i];branch='small_set_indicator'
  assert len(sets[i])**2<=m and missed<=delta/mass
 assert missed*missed<=delta
 return {'m':m,'patterns':len(sets),'delta':str(delta),'missed':str(missed),'branch':branch}

rng=random.Random(651)
cases=[]
for m in range(1,9):
 masks=list(range(1,2**m))
 for _ in range(16):
  chosen=rng.sample(masks,min(len(masks),16))
  sets=[frozenset(i for i in range(m) if mask>>i&1) for mask in chosen]
  cases.append(verify(m,sets,[rng.randrange(1,21) for A in sets]))
fano=[frozenset((i+j)%7 for j in [0,1,3]) for i in range(7)]
assert all(len(A&B)==1 for i,A in enumerate(fano) for j,B in enumerate(fano) if i!=j)
cases.append(verify(7,fano,[1]*7))
cases.append(verify(7,[frozenset([i]) for i in range(7)],[1]*7))
h=s.symbols('h',positive=True)
avg=(4-(2-h)**2)/18
assert s.expand(avg-h*(4-h)/18)==0
out={'distributions':len(cases),'cases':cases,'near_tie_average_defect':'h*(4-h)/18','near_tie_bad_pair_probability':'1/2','scope':'Finite set/abstract row-law checks only; no old KKT or global Gamma certificate.'}
Path(__file__).with_name('cover_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'distributions':len(cases),'fano_delta':cases[-2]['delta'],'near_tie_identity':'PASS','scope':out['scope']}))
