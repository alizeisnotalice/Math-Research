"""Deterministic product quadrature of two frozen R651 independent-anchor laws."""
import json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss

delta=1/32; r=1/16; h=delta/8; w=1/1024; eps=56.; b=7/4; sigma=11/4; eta=1/4096
centers=(-delta/2,delta/2); H={'A':18333/262144,'B':145341/4194304}

def action(kind,x1,x2):
    c1=sigma*centers[0]-b*x1; c2=sigma*centers[1]-b*x2
    sep=c2-c1
    if kind=='A':
        assert 0<sep<r
        # Receiver overlap belongs to owner 2; row 1 owns only its exclusive portion.
        p1,p2=sep,r
    else:
        assert r<sep<2
        p1=p2=r
    W=p1+p2; a1=p1/W; a2=p2/W; Q=2*(a1+a2)
    demand1=2+eps*p1/a1; demand2=2+eps*p2/a2
    xstar=(p1*c1+p2*c2)/W
    cost=eps*(p1*(xstar-c1)**2+p2*(xstar-c2)**2)/demand1
    phi=demand1*cost
    ac_fee=eps*W*eta**2/3
    D=W-Q/16
    return {'c1':c1,'c2':c2,'separation':sep,'p1':p1,'p2':p2,'W':W,'alpha1':a1,'alpha2':a2,
            'Q_prime':Q,'demand1':demand1,'demand2':demand2,'kappa_prime':eps*W/Q,
            'phi':phi,'D':D,'ac_fee':ac_fee,'ac_H_next':phi+ac_fee,'minimizer':xstar,'cell_cost':cost}

def anchors(kind,x,y):
    if kind=='A': return centers[0]+h*x,centers[1]+h*y
    return w*(x-1)/2,w*(y+1)/2

def quad(kind,n):
    nodes,weights=leggauss(n)
    acc={k:0. for k in ('separation','W','phi','D','ac_fee')}
    for i,x in enumerate(nodes):
        for j,y in enumerate(nodes):
            a=action(kind,*anchors(kind,float(x),float(y)))
            for k in acc: acc[k]+=weights[i]*weights[j]*a[k]/4
    acc.update(n=n, gamma_constant=acc['D'],gamma_L=H[kind]-acc['phi'],actual_ac_gamma_L=H[kind]-acc['phi']-acc['ac_fee'])
    return acc

def verify_sample(kind,x,y):
    X=anchors(kind,x,y); a=action(kind,*X); c1,c2=a['c1'],a['c2']; C1=(c1-1,c1+1); C2=(c2-1,c2+1)
    B1=(c1-r/2,c1+r/2); B2=(c2-r/2,c2+r/2)
    intersection=max(0.,min(B1[1],B2[1])-max(B1[0],B2[0]))
    owner1=(B1[0],min(B1[1],B2[0])) if kind=='A' else B1
    owner2=B2
    p_actual=(owner1[1]-owner1[0],owner2[1]-owner2[0])
    # One positive-volume common cell is saturated; singleton pieces have load <1.
    xstar=a['minimizer']; cell=(max(C1[0],C2[0]),min(C1[1],C2[1]))
    errors={'ownership':max(abs(p_actual[0]-a['p1']),abs(p_actual[1]-a['p2'])),
            'packing_saturation':abs(a['alpha1']+a['alpha2']-1),
            'entropy_stationarity':abs(a['demand1']-a['demand2']),
            'primal_row_demand':abs(a['demand1']-a['demand2']),
            'primal_dual_gap':abs(a['phi']-a['demand1']*a['cell_cost']),
            'source_formula':abs(a['phi']-eps*a['p1']*a['p2']/a['W']*a['separation']**2)}
    assert cell[0]<xstar-eta<xstar+eta<cell[1] and max(errors.values())<1e-12
    return {'anchor':list(X),'new_centers':[c1,c2],'receiver_intervals':[list(B1),list(B2)],'owner_intervals':[list(owner1),list(owner2)],
            'receiver_overlap':intersection,'saturated_cell':list(cell),'primal':a['demand1'],'dual':[a['cell_cost'],0],
            'ac_interval':[xstar-eta,xstar+eta],'ac_mass':a['demand1'],'state':a,'residuals':errors}

if __name__=='__main__':
    levels=[16,32,64,128]; results={kind:[quad(kind,n) for n in levels] for kind in ('A','B')}
    samples={kind:[verify_sample(kind,*xy) for xy in [(-1.,-1.),(-1.,1.),(0.,0.),(1.,-1.),(1.,1.)]] for kind in ('A','B')}
    A=results['A'][-1]; B=results['B'][-1]
    difference_slope=B['gamma_L']-A['gamma_L']; actual_slope=B['actual_ac_gamma_L']-A['actual_ac_gamma_L']
    out={'source_laws':{'A':'independent Xi=yi+uniform[-h,h]','B':'independent X1 uniform[-w,0], X2 uniform[0,w]'},
         'quadrature':'tensor Gauss-Legendre, normalized product measure','quadrature_results':results,'samples':samples,
         'B_minus_A':{'constant':B['gamma_constant']-A['gamma_constant'],'L_coefficient':difference_slope,
                      'LP_crossing':-(B['gamma_constant']-A['gamma_constant'])/difference_slope,
                      'actual_AC_L_coefficient':actual_slope,'actual_AC_crossing':-(B['gamma_constant']-A['gamma_constant'])/actual_slope},
         'scope':'Floating numerical quadrature and sample checks only; independent anchors, no certified error bound, R<1.'}
    Path(__file__).with_name('quad_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'levels':levels,'A':A,'B':B,'B_minus_A':out['B_minus_A'],'max_sample_residual':max(v for ss in samples.values() for s in ss for v in s['residuals'].values())},indent=2))
