# R651 final geometry integration audit

Audited report: /tmp/ccu_r651_final/REPORT.tex
Actual SHA256: 4276781ad8e293f86ea089cb2556a9e00a91fba6fb4b053fc4e2507455765946
Requested SHA256: 4276781ad8e293f86ea089cb2556a9e00a91fba6fb4b053fc4e2507455765946

Verdict: PASS within the integration scope below. The frozen source matches the requested hash. No necessary correction was found in the audited integration.

## Scope

I read the frozen report and compared the old-source, minimizer-rectangle/collapsed-contact, and contact-cover portions to the completed OLD_SOURCE_AUDIT.md, MINIMIZER_RECTANGLE_AUDIT.md and CONTACT_COVER_SCREEN.md in /tmp/ccu_r651. I additionally checked the report's explicit aggregation of row cover weights into source-channel measures and the exception Cauchy estimate directly against the old packing load. This is not a fresh proof of the full Gamma budget or an independent certification of the numerical/product-law calculations. No calculation was rerun, and no report or other author's file was modified.

## Old-source constraint and source refinement

The report fixes geometry, owners, epsilon and lambda before varying the actual AC source, so R,M,m_j and the cost coefficients remain fixed. Its Phi_old is the actual finite-cell AC infimum, with cost evaluated using the membership labels of the positive-volume old saturated cell; boundary contact labels are not added to that convex cost.

The near-score inequality 0<=H-Phi_old<=eta M/L is compared to the same ALL-state/all-AC-source score supremum and does not assume AC attainment. The displayed dual-gap formula has the correct two nonnegative parts and actual row moments. Source refinement is described as preserving/improving the OLD score while requiring an assignment for the newly chosen source; the report expressly says that this changes the action law. It does not freeze a previous action after source replacement.

The same-action replacement H -> Phi_old in Gamma is correctly bounded between zero and eta Q'. Its sign is favorable excess removed from Gamma, so the report correctly warns that old-source optimality is not new positive budget. No raw-R near-maximality or D<=eta Q' is inferred.

## Complete minimum-set rectangle and contact

The report faithfully states the unique optimal radius vector, complete rectangle Z, weighted radius-deficit inequality, exact infinity-distance formula for x in R, and coefficient C_R=max_j s_j^2/w_j. Its proof uses the convex feasible radius set and cube product intervals, not strong convexity in x. It allows degenerate Z and does not claim a uniform bound on C_R or control relative to one canonical point.

The relative-interior argument correctly gives at least one collapsed-coordinate contact for every row. A zero rho_j forces Z={y_j}. There is no claim of a common contact coordinate across different rows or cells, coordinate orthogonality, or a positive uniform contact weight.

The stated AC nonattainment consequence is correct in the actual finite positive-weight old contract: each nonempty minimizing rectangle has at least one collapsed coordinate, hence is Lebesgue-null. A positive-mass AC source therefore has a strictly positive within-cell gap on at least one occupied cell; the nonnegative dual-slack part cannot cancel it. Thus H>Phi_old for every actual AC old source with M>0, even though arbitrary positive near-infimum tolerances remain available. This does not preclude near-score actual states or assert a Gamma counterexample.

The source/anchor distance-to-set budget keeps each cell's explicit C_K. The later collapsed-coordinate lower bound on points of E_j uses only their containment in the actual receiver, the exact contact, and |X_{ji}-xi_{Ki}|<=dist_infinity(X_j,Z_K). It is compatible with the audited rectangle proof and does not replace anchors by projected atoms. No full overlap/new-demand bound is claimed from it.

## Contact cover and the consistent iid row law

The Euler equality uses nonempty signed active-coordinate sets, with all signs included at zero. The constant-radius and pairwise-intersection consequence is stated only for an iid zero-defect law. The report first makes the Eulerian assignment gamma_j=lambda_j1_Aj mu an explicit separate branch, so its row anchor law is indeed mu|Aj/m_j. It does not silently transfer iid conclusions to the earlier weighted-minimizing assignment.

The finite-set cover proof has the correct real threshold sqrt(m), total weight at most sqrt(m), and covered probability at least 1-sqrt(delta). The two p cases and zero-delta endpoint are correctly handled; integer cardinalities create no additional rounding loss. No common coordinate for all patterns is presumed.

The report preserves the essential warning that small mean mixing defect does not control the exact disjoint-active-pattern probability. Its two near-tie vectors demonstrate precisely that missing quantitative link. It does not claim that the cover can already be applied with a small exceptional mass merely from a small Euler cost.

## Source-channel aggregation and adaptive exception bound

The source-capacity aggregation in the final report is valid directly from the old load. For each fixed row law the weights t_{j,e} are nonnegative and have sum_e t_{j,e}<=sqrt(2n). Consequently, pointwise mu-a.e.,

    sum_e sum_j lambda_j t_{j,e}1_Aj 1_{e in S_j(x)}
      <=sum_j lambda_j1_Aj sum_e t_{j,e}
      <=sqrt(2n) L_lambda(x)
      =sqrt(2n).

Thus sum_e tau_e<=sqrt(2n)mu as measures and the integrated total mass is at most sqrt(2n)M. This does not multiply the source budget by labels or scales, and it does not rely on independence of row weights from x beyond their being fixed for the old row law as explicitly specified.

If U_j is the row event not covered by its fixed weights, then the set theorem gives P(U_j)<=sqrt(delta_j). Its actual anchor/source mass is at most

    sum_j a_j P(U_j)<=sum_j a_j sqrt(delta_j)
       <=sqrt((sum_j a_j)(sum_j a_j delta_j))
       =sqrt(M sum_j a_j delta_j).

This is the correct weighted Cauchy inequality. For adaptive lost-source units, epsilon o_j/u_j<=a_j holds pathwise. Multiplying that cap by 1_{U_j} and then taking expectations proves the same exception bound without assuming the owner is independent of its anchor or extracting alpha from a conditional expectation.

These are source-capacity/source-unit statements only. They do NOT bound physical lost receiver volume without the row-dependent multiplier u_j/epsilon and the full ledger factor 1-L epsilon k_j. The report explicitly retains these prices, new row demands and Phi_new, and explicitly declines to cancel them with the cover. This limitation is central to the PASS verdict.

## Claim boundaries and remaining gap

The opening states the general root-order weak bound and positive full increment are unproved. The body distinguishes source cost from distance to a set, old-score improvement from same-action improvement, the minimizing and Eulerian assignment branches, and source-channel capacity from receiver payment. The final section retains large growth, near-minimum/flat-set motion, large C_K, new demanded cell masses and the full signed remainder.

The actual remaining obligation is a uniform positive complete Gamma increment on the SAME legal action/ownership/source LP, including both the quantitative near-active error and the physical new-source/lost-volume costs. None is established merely by the certified old-source gap, rectangle theorem, contact existence, fractional cover or aggregate source capacity. The report does not promote these partial results to that conclusion.

Final binding: PASS for SHA256 4276781ad8e293f86ea089cb2556a9e00a91fba6fb4b053fc4e2507455765946, limited to the geometry/source-capacity integration reviewed here. Numerical integration, complete Eulerian full-ledger legality and the general Gamma payment remain outside this audit's certification.

## Final expectation-wording rebind

The sole reported final change explicitly writes the uncovered quantities as E sum_j a_j 1_bad(X_j) and E sum_j (epsilon o_j/u_j)1_bad(X_j), and says the exception estimates are not per-realization bounds. I read that amended paragraph and confirmed it matches the expectation proof already given above. The deterministic measure inequality sum_e tau_e<=sqrt(2n)mu is unchanged. PASS is rebound to SHA256 4276781ad8e293f86ea089cb2556a9e00a91fba6fb4b053fc4e2507455765946. No other mathematics was re-audited or calculations rerun for this narrow rebind.
