# OLD_SOURCE_AUDIT.md

# R651 old-source LP audit — independent checkpoint

Before reading author material: fix geometry, actual positive owners, epsilon, entropy optimizer lambda, moments m and mass M. These determine R,kappa and G_old, independently of which actual AC KKT source is used. If F(mu)=R-LH(mu)/M exceeds the ALL-state supremum Sigma minus eta, varying only the old AC source gives

    0<=H(mu)-Phi_old<eta M/L,

where Phi_old is the AC source-cost infimum. AC attainment is unnecessary: a sequence of admissible AC near-minimizers gives sup_source F=R-LPhi_old/M<=Sigma. This proves the inequality without replacing the current source or its already-chosen action assignment.

A separately replaced old source generally requires replacing/reoptimizing gamma because sum gamma_j=mu. Source minimization therefore improves the OLD score but does not preserve an already-realized half-action law or an existing action margin by itself. Full gap and quantifier audit follows.

## Verdict and exact scope

The new near-score constraint and the proposed nonnegative gap decomposition are VALID. Old-source minimization can independently improve the OLD score without changing geometry, owners, epsilon, lambda, R, kappa or M. It does not by itself improve the full Gamma increment or preserve an already chosen gamma/action.

No exact source optimizer, atomic source, measurable family of minimizing sources, spatial displacement estimate, or uniform beta/lambda bound is required for these statements. An ALL-state/all-actual-source score comparison is essential. The audit below is limited to these new constraints and their legitimate use, not a repetition of the R650 conditional recovery theorem.

I derived the checkpoint above before reading /tmp/ccu_r651/TARGET.md. The target's candidate identities agree with the independent derivation. Its warning that concentration is a cost statement rather than a canonical-location statement is necessary.

## Fixed-geometry old source problem

Fix the actual finite old geometry, positive actual owners, epsilon>0, and actual entropy optimizer lambda. The resulting quantities

    m_j=d_j+epsilon v_j/lambda_j,
    Q=sum_j lambda_j d_j,  R=V/Q,  kappa=epsilon R,
    M=sum_j lambda_j m_j=(1+kappa)Q

are fixed independently of the choice of actual AC KKT source. Let S_old be the set of all nonnegative AC measures nu with nu(A_j)=m_j, total mass M, and L_lambda=1 nu-a.e. This set is nonempty by the actual finite entropy KKT construction. Its definition must not silently add a density cap, canonical-cell uniformity restriction, a prescribed gamma, or another source-dependent side condition.

For any nu in S_old,

    H(nu)=integral G_old dnu,
    G_old(x)=(1+kappa)epsilon sum_j(v_j/m_j)1_Aj(x)r_j(x)^2.

The cost coefficients also equal (1+kappa)lambda_j u_j/(1+u_j), so on the source union 0<=G_old<=1+kappa Lebesgue-a.e. The scalar bound 0<=H(nu)<=kappa M follows directly from its defining owner averages, not merely this pointwise upper bound.

The actual positive-volume old membership cells with lambda(K)=1 form a finite set. Write Omega_K for the exact old membership-pattern cell and

    c_K=ess inf_{Omega_K}G_old.

As in the independently audited R649 geometry, Omega_K equals the positive-volume closed intersection rectangle modulo null sets. On this rectangle the correct convex cost uses only labels in K; outside labels that touch a face cannot be inserted into its boundary objective. Define

    Phi_old=min {sum_K c_K z_K: z>=0,
                                sum_{K containing j}z_K=m_j}.

The feasible set is nonempty compact, its finite primal and signed-row dual optima are attained, and

    Phi_old=inf_{nu in S_old}H(nu).

The equality is an infimum over actual AC sources, not an assertion of AC attainment. For every tau>0, exact cell masses mixed with positive-volume near-cost-minimizer subsets give an actual AC nu_tau with H(nu_tau)<=Phi_old+tau M. All moments and saturation remain exact; only the objective has a tolerance. Densities may blow up as tau tends to zero.

## ALL-state near-F implies quantitative old-source near optimality

Let Sigma be the finite score supremum over the SAME calibrated state class and ALL its genuine AC sources, with deterministic L>0. Fix an actual state/source mu with

    F(mu)=R-LH(mu)/M >= Sigma-eta.

Every competitor nu in S_old, paired with the same geometry/owners/epsilon, belongs to the comparison class. Therefore

    R-LH(nu)/M<=Sigma.

Take AC near-minimizers and then their cost infimum, obtaining

    R-LPhi_old/M<=Sigma.

Subtract F(mu):

    0<=L[H(mu)-Phi_old]/M
       <=Sigma-F(mu)<=eta.

Hence

    0<=H(mu)-Phi_old<=eta M/L.

If near-maximality was defined by a strict F(mu)>Sigma-eta, the final inequality is strict as well. The weak version requested in TARGET.md is valid in either convention. No AC minimizer is needed, and no source replacement was performed in this proof. In particular the current already-selected gamma can remain exactly the same while the inequality is applied to its current source.

The comparison would not be justified if Sigma were only over a source subclass that excludes the fixed-geometry near-minimizers, or only over additional source/action-dependent restrictions. A restriction only to the same R-critical band would not obstruct this particular fixed-geometry variation because R and kappa do not change, but the authoritative Sigma is the all-state one needed by the complete score argument. One must not interchange these different suprema elsewhere.

This consequence is source optimality at the given geometry. It does not make the geometry itself an attained extremum, make raw R arbitrarily near its raw supremum, or supply the invalid bound D<=eta Q'.

## Exact nonnegative dual-gap decomposition

Take ANY optimal finite LP row dual beta satisfying

    beta(K):=sum_{j in K}beta_j<=c_K,
    sum_j beta_j m_j=Phi_old.

There is no positivity requirement on individual beta_j because the moment constraints are equalities. For the CURRENT actual mu put z_K=mu(Omega_K). These masses satisfy the same row constraints. Saturation confines mu, modulo null sets, to these saturated positive-volume cells. Then exactly

    H(mu)-Phi_old
      =sum_K integral_{Omega_K}(G_old-c_K)dmu
         +sum_K[c_K-beta(K)]z_K.

Each displayed summand is nonnegative. The first is nonnegative mu-a.e. because c_K is a Lebesgue essential infimum and mu is AC; the second is nonnegative by dual feasibility. Substituting the near-F bound gives an upper bound eta M/L for their SUM. This does not require a uniform beta bound, uniqueness of beta, or uniqueness of primal cell masses.

Equivalently, define the nonnegative source gap density

    g_gap(x)=[G_old(x)-c_K]+[c_K-beta(K)]
              on Omega_K,  mu-a.e.

Then integral g_gap dmu=H-Phi_old. For every t>0,

    mu({g_gap>t}) <= (H-Phi_old)/t <=eta M/(Lt).

Consequently old source mass in cells with dual slack greater than t, or in regions whose within-cell cost excess exceeds t, is small in this exact weighted-mass sense. The same bound controls the union of these two exceptional conditions since either forces g_gap>t. The report's phrase “low-cost parts of nearly dual-tight cells” is valid precisely with this quantitative meaning.

This does NOT bound distance to a chosen point minimizer. Infinity-norm squared costs can have flat minimizing sets, cell masses can have multiple optimal assignments, and the geometric modulus converting cost excess into distance can depend on the fixed radii, weights and positions. It gives no uniform distance-to-a-canonical-minimizer, no per-row conclusion after division by a tiny lambda_j, and no uniform control on beta_j/lambda_j. It also gives no extension of dual inequalities to nonsaturated cells carrying no old source.

## Can the old source be improved independently without loss?

YES for the old score, with a precise order of quantifiers. For any fixed original mu and any desired tolerance tau>0, there exists an actual AC nu with

    H(nu)<=H(mu),
    H(nu)<=Phi_old+tau M.

If the original mu already satisfies the second inequality, use mu itself. Otherwise choose an AC near-minimizer with cost at most Phi_old+tau M, which is strictly below H(mu). Thus source refinement can be chosen to preserve or improve F, while keeping R, kappa, M, geometry, owners, lambda and the old critical regime exactly unchanged. If H(mu)>Phi_old, choosing tau<(H(mu)-Phi_old)/M gives strict score improvement. An exactly minimizing AC source is not implied.

One can therefore select a near-F actual state, refine its source to any positive source-cost tolerance without lowering its score, and THEN choose a genuine weighted-optimal decomposition gamma for that refined source. The usual finite supported assignment problem is feasible (the baseline lambda_j1_Aj nu has masses a_j and sums to nu), and the weighted objective has an optimizer on that fixed finite state. Any theorem stated uniformly for all actual source states can be applied to this newly chosen source as a fresh state.

NO for an already fixed decomposition or realized action without further work. If sum_j gamma_j=mu, the same gamma cannot sum to a different nu. A source change generally requires a new optimal gamma and new independent product anchors. It may change the entire action law and the actual E-priority ownership, alpha, S,D, source-LP cost Phi_new and Gamma. Selecting nu_tau and gamma_tau first defines a legitimate NEW actual half-action experiment; it is not a preservation theorem for a previous action or its gain.

The near-source inequality from ALL-state near-F avoids this problem: it already applies to the current mu and current genuine gamma, so no replacement is needed merely to use that inequality. This is the safest form when an argument must retain the same complete action ledger.

## Exact approximation costs versus unproved action stability

A fixed-geometry source approximation H(nu_tau)<=Phi_old+tau M has a known old-score tolerance at most Ltau relative to the formal optimal-source score R-LPhi_old/M. The no-loss refinement above also avoids any loss relative to the original actual score. These are the only automatic approximation estimates.

They do not control total variation or a spatial transport distance between mu and nu_tau. They do not control the product anchor laws or the outcome-dependent E-priority owner/alpha maps. A weak limit of the AC near-minimizers can have boundary atoms; its physical cube memberships can differ from their abstract tagged cell labels. The exact cell moment constraints of the approximating AC measures therefore do not automatically become the same physical moment constraints of a boundary-atomic limit. Such an atom is neither an authorized old source nor an authorized next AC source.

Accordingly an argument that first replaces the old source by a tagged or atomic LP minimizer and proves a favorable action there must separately recover an ACTUAL AC state, legal gamma and action, actual owners, actual alpha, and the complete Gamma margin. Convergence of the old objective alone is not a bound on any of those action quantities. Relevant errors include changes in W,Q',D,H, and the actual Phi_new, together with any needed control of changing contact/incidence cells. A source-independent strict-interior D recovery statement from R645 is not by itself a score/source-LP recovery statement.

Neither the candidate gap identity nor a canonical/secondary minimizer rule supplies this stability theorem. In particular a tie rule among flat minima cannot replace a missing distance modulus. If a proof needs source gap zero, it must either establish an actual AC optimizer or keep a positive tolerance and show that all ensuing action-margin errors are paid; setting tau=0 is not legitimate.

No globally measurable kernel tau/state -> nu_tau is required for the pointwise source-refinement or fixed-state score comparison. If one claims an expectation after choosing a source, it is enough to fix that actual source and its assignment first, then use its well-defined product action law. Any expectation of outcome-dependent owners or Phi_new still needs its ordinary measurability, but this audit does not add an unnecessary all-states source-selection requirement.

## Genuine remaining condition and unverified dependencies

The validated new information is that a near-F state is also nearly minimizing the old source cost at its OWN fixed geometry, with the exact gap budget eta M/L and the displayed nonnegative decomposition. To close the research target one still needs an actual geometric comparison that uses this constraint to pay the SAME new demanded cell masses/source cost, covariance/growth, overlap and fill terms in Gamma. No such comparison follows just by naming the old LP, selecting a minimizer, or passing to a source limit.

The finite saturated-cell geometry, finite LP duality, and AC near-infimum construction are inherited from the independently completed R649 audit; I have not repeated their full proofs here. The availability of a genuine weighted gamma for each chosen actual source is the existing finite assignment result and can also be obtained from its feasible baseline and weak-star compactness. The entire original/global action budget, a uniform optimal-dual coefficient estimate, a source/action continuity theorem through arbitrary contacts, and any positive uniform Gamma margin remain unverified by this bounded audit.

The fresh TARGET.md keeps these conditions explicit and does not itself claim the general theorem. The statement that old sources can be chosen “jointly near-optimal” is correct only at positive AC tolerance and with gamma selected for the chosen source; it must not be read as exact AC attainment or as preserving a previously realized action.

## Actual mathematical-tool check

Executed the installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. The fixed-geometry score gain R-LPhi/M-[R-LH/M]=L(H-Phi)/M and a generic two-cell gap decomposition both returned exact zero residuals. The source tolerance tau M gives old-score tolerance exactly Ltau. These are symbolic algebra checks, not numerical evidence for a Gamma margin or a source/action limit theorem. No geometric scan, new construction, Git operation or PDF was performed.


---

# MINIMIZER_RECTANGLE_AUDIT.md

# Independent minimizer-rectangle audit — checkpoint before author

The stated cube-product geometry lemma passes an independent proof. For a nonempty compact axis-aligned rectangle R and finite positive weights w_j and scales s_j, the epigraph-radius feasible set T={t>=0: exists x in R with |x_i-y_{ji}|<=s_jt_j for all j,i} is nonempty convex closed. Weighted squared norm has a unique minimizer rho* on T. Monotonicity in nonnegative radii implies that every minimizing point of G has exactly radius vector rho*, and the full minimizer set is the rectangle Z=R intersect intersection_j Q(y_j,s_j rho*_j), allowing zero-width sides.

Projection optimality in T gives G(x)-min G >=sum_j w_j(r_j(x)-rho*_j)^2. Coordinate clamping to Z gives dist_infinity(x,Z)=max_j s_j(r_j(x)-rho*_j)_+ for x in R, because the R constraints are already satisfied. Thus dist_infinity(x,Z)^2<=max_j(s_j^2/w_j)[G(x)-min G]. No canonical point or uniform-in-geometry coefficient is obtained.

## Final verdict and assumptions

PASS. Every displayed claim in the assigned proposition is correct for the intended actual old-cell geometry: R is a nonempty compact axis-aligned closed rectangle, the row family is finite and nonempty, all s_j>0, and all w_j>0. The original cell rectangle has positive volume, but the lemma itself also permits a lower-dimensional nonempty R. Its minimizer rectangle Z may be lower dimensional or a point. Zero components of rho* are allowed.

The proof below is in radius-vector space and uses the product structure of cube sublevel sets. It does not assume strong convexity of G as a function of x. It provides distance to the ENTIRE minimum set, not to a canonical selected point. The coefficient max_j(s_j^2/w_j) is finite for the fixed instance but is not a universal geometric constant.

The independent checkpoint was written before reading /tmp/ccu_r651/OPTIMAL_SOURCE_GEOMETRY.md and FLAT_DIRECTION_CHECK.md. The author material available at that point contains the earlier anisotropic coordinate certificate and flat-direction example, not the new rectangle proof. The new result is consistent with both and is stronger in directions transverse to the full minimizer set. It does not contradict their failure of control relative to a single canonical minimizer.

## Radius feasibility set

Write

    r_j(x)=max_i |x_i-y_{ji}|/s_j,
    G(x)=sum_j w_j r_j(x)^2,
    T={t in [0,infinity)^J: exists x in R,
                            |x_i-y_{ji}|<=s_j t_j for all j,i}.

Equivalently t belongs to T precisely when some x in R has r(x)<=t componentwise. The defining inequalities in (x,t) are linear after writing the two signs of each absolute value, so their feasible set is convex, and its projection T is convex.

Closedness is checked explicitly rather than inferred from arbitrary projections of closed sets: if t^l in T converges to t, choose witnesses x^l in the compact R. A convergent subsequence has limit x in R, and all finitely many inequalities pass to the limit, proving t in T. Nonemptiness follows by taking any x in R and t=r(x). Thus T is a nonempty closed convex set.

The function J(t)=sum_j w_j t_j^2 is continuous, coercive and strictly convex because every w_j>0. It therefore has a minimizer rho* in T and that minimizer is unique. The nonnegative radius domain matters for the componentwise monotonicity used next.

## Exact correspondence of the two optimization problems

For every x in R, r(x) belongs to T, hence

    G(x)=J(r(x))>=J(rho*).

Since rho* belongs to T, there is a witness x* in R with r(x*)<=rho*. Nonnegativity and positive weights imply J(r(x*))<=J(rho*), so equality holds. In fact r(x*)=rho*: if any component were strictly smaller, its positive squared-weight contribution would make the total strictly smaller (a zero rho*_j cannot have a smaller nonnegative component). Therefore

    min_R G=J(rho*).

If x minimizes G, then r(x) is a minimizer of J over T, so uniqueness gives r(x)=rho*. Conversely a point with r(x)=rho* minimizes G. The same conclusion follows for every x satisfying r(x)<=rho*, because such a point cannot have a strictly smaller positive-weight radius component without beating J(rho*).

Consequently the ENTIRE minimizing set is exactly

    Z=argmin_R G
      ={x in R:r_j(x)<=rho*_j for all j}
      =R intersect intersection_j Q(y_j,s_j rho*_j).

This is a nonempty compact rectangle, with closed sides that may have zero width. This characterization is specific to the cube/infinity-norm product sublevel geometry. It is not a claim that general convex norm-distance minimizer sets are rectangles.

## Radius-vector gap controls every transverse direction

Convex optimality of rho* over T yields, for every t in T,

    sum_j w_j rho*_j(t_j-rho*_j)>=0.

A direct proof is to differentiate J(rho*+theta(t-rho*)) at theta=0 from the right, since that segment remains in T and rho* minimizes J. Expanding the weighted square gives

    J(t)-J(rho*)
      =sum_j w_j(t_j-rho*_j)^2
          +2sum_j w_j rho*_j(t_j-rho*_j)
      >=sum_j w_j(t_j-rho*_j)^2.

Apply this to t=r(x) for any x in R:

    G(x)-min_R G>=sum_j w_j(r_j(x)-rho*_j)^2.          [R1]

This estimate does not presume that every r_j(x)-rho*_j is nonnegative. The signed first-order sum is nonnegative as a WHOLE; individual radius deviations can be negative. The later distance formula correctly uses positive parts instead of dropping this distinction.

## Exact distance to the minimizing rectangle

Write R=product_i [L_i,U_i]. The minimizer rectangle has endpoints

    ell_i=max(L_i,max_j[y_{ji}-s_j rho*_j]),
    u_i=min(U_i,min_j[y_{ji}+s_j rho*_j]).

Nonemptiness established above ensures ell_i<=u_i for every i. For any x, coordinate clamping to these intervals gives an infinity-nearest point of Z, so

    dist_infinity(x,Z)=max_i max(ell_i-x_i,x_i-u_i,0).

For x in R, the original R constraints cause no positive violation: L_i-x_i<=0 and x_i-U_i<=0. Thus only the cube endpoints contribute, yielding

    dist_infinity(x,Z)
      =max_{j,i} (|x_i-y_{ji}|-s_j rho*_j)_+
      =max_j s_j(r_j(x)-rho*_j)_+.                   [R2]

The interchange of maximum and positive part is valid for a finite family. This remains true when Z is degenerate, when some rho*_j=0, and when x or the nearest point lies on a boundary. The hypothesis x in R is essential for omitting the R constraints; for x outside R the displayed simplified formula can fail.

Combining R1 and R2,

    dist_infinity(x,Z)^2
      =max_j s_j^2(r_j(x)-rho*_j)_+^2
      <=[max_j(s_j^2/w_j)]
                       sum_j w_j(r_j(x)-rho*_j)^2
      <=[max_j(s_j^2/w_j)] [G(x)-min_R G].            [R3]

No dimension factor is introduced in this step. The instance-dependent coefficient may nevertheless become arbitrarily large as a relevant weight shrinks or a radius grows; no min-weight division can be relabeled a uniform payment.

## Boundaries, flat minima and actual-source use

The proof treats CLOSED rectangle geometry. In an actual saturated membership cell, the full rectangle and the exact cell agree only modulo Lebesgue-null sets. The scalar cost minimum and the rectangle Z are coefficient/reference objects. A point of Z lying on an outside-label contact face need not have the same ambient membership pattern as the cell interior. Neither its existence nor the coordinate projection to Z installs it as an actual source atom or preserves all physical KKT moments under source replacement.

Flat directions remain possible. In the already documented two-equal-cube example, G has minimum set {0} times [-d,d]. The unique radius vector is (d,d), and R2 gives zero distance everywhere on that segment, correctly retaining all flat directions. The failure of distance-to-a-selected-minimizer coercivity does not obstruct distance-to-the-whole-set coercivity. Conversely R3 does not locate a point within a flat direction and cannot justify a canonical-point reduction.

For the actual old source, apply the lemma separately in each positive-volume saturated old cell K, with its own cost weights and coefficient C_K=max_{j in K}(s_j^2/w_j). The independently verified old-source gap then implies

    sum_K (1/C_K) integral_{Omega_K}
                     dist_infinity(x,Z_K)^2 dmu(x)
       <=sum_K integral_{Omega_K}(G_old-c_K)dmu
       <=H-Phi_old<=eta M/L.

This is a legitimate all-direction distance-to-minimum-SET budget with explicit cell-dependent constants. It does not yield a uniform unweighted spatial budget by discarding those constants. It can be sampled under the actual prescribed gamma because sum_j gamma_j=mu; it does not require replacing the gamma law. Any projected locations remain diagnostic references until the actual action/source/owner costs are proved stable.

In particular, no conclusion here bounds the change of O, fill, alpha, demanded new cell masses, Phi_new, or the complete Gamma. Those are nonlinear functions of the actual anchor tuple and its incidence/ownership pattern. The result removes the earlier absence of a set-distance certificate, but not its nonuniform coefficient, its freedom along Z, or the need to pay actual changes in the complete score.

## Executed local mathematical-tool evidence

Ran the installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. The generic two-coordinate weighted projection expansion had exact residual zero. On the existing flat-minimum fixture at x=0,y>d, subtracting the radius-deficit lower bound from the exact gap yielded 4d(y-d)>=0. At d=1/4,y=13/50 the squared distance to the minimum SET is exactly 1/10000 and the cost gap is 51/5000, consistent with R3. This check was targeted to the new frozen set-distance claim, not a numerical scan or a Gamma experiment.

Final scope: the cube-product minimizer-rectangle theorem and its stated nonuniform set-distance bound are certified. Uniform Gamma stability and the general target remain unproved. No other author's file, report, Git state or PDF was changed.

## Short addendum: every row contacts a collapsed coordinate

PASS for the requested contact-existence corollary. Keep the proved nonempty rectangle Z=product_i [ell_i,u_i] and r_j(x)=rho*_j for EVERY x in Z.

Fix a row j and first suppose rho*_j>0. Choose x in the relative interior of Z: x_i lies strictly between ell_i and u_i for each nondegenerate coordinate interval, and equals its singleton value in every degenerate interval. Since the WHOLE interval Z_i is contained in [y_{ji}-s_j rho*_j,y_{ji}+s_j rho*_j], every nondegenerate coordinate satisfies

    |x_i-y_{ji}|<s_j rho*_j.

But max_i |x_i-y_{ji}|=s_j rho*_j by the constant-radius property. Thus some maximizing coordinate i must be degenerate, with Z_i={xi_i}, and

    |xi_i-y_{ji}|=s_j rho*_j.

The contact equality then holds along the entire Z because that coordinate is fixed. In particular at least one coordinate of Z collapses, and each row has at least one such collapsed-coordinate contact. A row may have several contacts, and different rows need not use the same coordinate.

If rho*_j=0, the identity r_j(x)=0 throughout the nonempty Z forces x=y_j for all x in Z, hence Z={y_j}. Every coordinate is then collapsed and satisfies the zero-radius contact equality.

This proves existence of an actual coordinate contact of each row with the full minimizer rectangle. It does NOT assert orthogonality, positive lower curvature, a common contact coordinate across rows or cells, a uniform contact weight, or that the contacted index maximizes any separate source/anchor coefficient. No all-lost or Gamma payment follows from contact existence alone.


---

# JOINT_SCOPE_AUDIT.md

# R651 independent owner/minimum-set integration audit

**Verdict: PASS for the stated adaptive lost-copy bounds and the minimum-set rectangle/contact theorem, with the limitations below. No uniform lost-copy/new-source/Gamma payment follows.**

Scope: OPTIMAL_SOURCE_OWNERS.md's actual-anchor and adaptive-owner implications, and the old-cell legality and quantitative scope of MINIMIZER_RECTANGLE_AUDIT.md. I checked the inequalities from their definitions and reconstructed the radius-vector/product proof. No author file was edited and no numeric experiment was repeated.

## 1. One fixed old source gap and legal cell costs

All old row data, source mu, gamma, weights, rectangle references and the optimal old dual beta are fixed before the product draw. Let delta_src=H-Phi_old. Its near-score bound delta_src<=eta M/L is used only under the explicitly stated all-state near-score premise. No raw D<=eta Q' assumption is involved.

Actual old positive lambda and positive-volume saturated cells permit the usual closed rectangle references. If a finite product refinement R is used, its cost is G_R with ONLY its interior incidence labels K_R, and beta(K_R)<=c_R. Parallel refined rectangles with the same incidence do not change the LP value: their smallest cost equals the original cell infimum. Their boundaries are null for actual AC mu and for every gamma_j<=mu.

Thus the exact gap decomposition is

  delta_src=sum_R integral_R(G_R-c_R)dmu
             +sum_R[c_R-beta(K_R)]mu(R).

No ambient extra contact label is inserted at a reference minimum. All old rows are still represented in the moment system; a row later receiving zero new owner is not dropped here.

## 2. The anisotropic certificate and actual-anchor expectation

Convex optimality of G_R on the closed rectangle yields a subgradient built from convex combinations of active coordinate quadratics at xi_R. The sum is a rectangle normal in the required sense b_R dot(x-xi_R)>=0 for x in closure R. Expanding the selected quadratics proves

  G_R(x)-c_R>=D_R(x)
    =sum_l A_Rl(x_l-xi_Rl)^2+b_R dot(x-xi_R)>=0.

The weights A_Rl are nonnegative, with sum_l A_Rl=sum_(j in K_R)w_j/s_j^2. Individual coordinates may have zero coefficient; the formula does not imply uniform coercivity toward the selected xi_R.

Define Delta_j(Z)=D_R(X_j)+c_R-beta(K_R) using the old cell containing the actual anchor. Then, on a common probability-one event avoiding finitely many old boundaries,

  E sum_j a_j Delta_j(Z)
    =sum_j integral Delta(x)d gamma_j(x)
    =integral Delta(x)dmu(x)<=delta_src.

The equality uses the actual old anchor marginals and sum_j gamma_j=mu. It does not require independence for this sum, though the actual prescribed product law is unchanged. No ghost-source substitution or conditioning on adaptive alpha occurs.

## 3. Adaptive owner inequality is valid pathwise before expectation

For ANY measurable E-priority choice after seeing the whole action, including forced-owner choices,

  0<=o_j<=ell_j,  eps ell_j/u_j=a_j.

Since Delta_j>=0,

  sum_j(eps o_j/u_j)Delta_j<=sum_j a_j Delta_j

holds for each realized action on that common full-measure event. Taking expectation proves precisely

  E sum_j(eps o_j/u_j)Delta_j<=delta_src.

There is no illicit factorization of o_j, p_j, alpha or a row event. The actual alpha/source LP must still be recomputed for the selected owners when the result is used in Gamma, but no alpha bound is needed for this inequality.

The kept E-owner fraction eps(ell_j-o_j)/u_j and the lost fraction eps o_j/u_j sum to a_j. Therefore the two corresponding nonnegative expectations ADD to the original anchor gap budget. Each cannot be spent as a fresh copy of delta_src.

For fixed U,tau>0, restricting to u_j<=U and Delta_j>=tau gives

  E sum_(u_j<=U) o_j 1_(Delta_j>=tau)
      <=U delta_src/(eps tau).

This is an actual physical loss estimate on exactly that subset. High-u loss and the near-minimum/dual-tight complement Delta_j<tau remain. The proof does not charge either complement to already-paid low growth, fill or an extra source credit. Because Gamma's lost-copy term has a bounded coefficient when zeta is calibrated, this bound can price only its specified bad-anchor/moderate-u part; it does not pay all of O or Phi_new.

For deleted old labels p_j=0 and o_j=ell_j, so the lost weight equals a_j, not zero. They are included in this bound and in the residual full Gamma account.

## 4. Independent minimum-set proof and contact corollary

For a compact nonempty rectangle R and positive w_j,s_j, let r_j(x)=||x-y_j||_infinity/s_j and G=sum_j w_j r_j^2. The radius feasible set

  T={t>=0: exists x in R with r_j(x)<=t_j for all j}

is nonempty and convex by the joint linear inequalities in x,t. It is closed: convergent radius vectors have witnesses with a convergent subsequence in compact R. The strictly convex coercive function sum_j w_j t_j^2 has a unique minimizing vector rho on T.

Every spatial minimizer must have r(x)=rho; otherwise it would give another or smaller radius optimum. Conversely r(x)<=rho forces equality in all positively weighted radii and is minimizing. Hence

  Z=argmin_R G=R intersect intersection_j Q(y_j,s_j rho_j)

is a nonempty compact axis-aligned rectangle, possibly degenerate. This proof does not require spatial strong convexity and does not select a canonical point in a flat direction.

Radius-space optimality gives

  G(x)-min_R G>=sum_j w_j[r_j(x)-rho_j]^2.

For x IN R, coordinate clamping to the nonempty intersection rectangle gives exactly

  dist_infinity(x,Z)=max_j s_j[r_j(x)-rho_j]_+.

The R constraints cause no additional violation because x is already in R. This formula would not hold in that simplified form for arbitrary x outside R. Combining it with the preceding gap gives

  dist_infinity(x,Z)^2<=C_R[G(x)-min_R G],
  C_R=max_j s_j^2/w_j.

The coefficient is finite for the FIXED instance, but is not uniform in geometry, source weights, scales or label count. Nothing in the old source gap allows it to be discarded.

For the collapsed-contact corollary, take a relative interior point x of Z. In each nondegenerate coordinate interval, x is strictly inside the corresponding row-radius interval whenever rho_j>0. Yet r_j(x)=rho_j. Thus every row j has some collapsed coordinate on which |x_l-y_jl|=s_j rho_j; that equality holds throughout Z. If rho_j=0, Z={y_j}, so every coordinate collapses. Different rows may contact different coordinates, with no positive lower bound on the contact's source weight or curvature. The corollary is correct.

## 5. Legitimate combined budget, not two purchases

The root minimum-set result applies to the SAME old cost G_R and its SAME c_R. Thus

  dist_infinity(x,Z_R)^2/C_R+c_R-beta(K_R)
    <=G_R(x)-beta(K_R).

It gives an alternative actual-anchor/lost-owner budget by the same argument in sections 2-3. It does not follow that the earlier anisotropic D_R itself dominates this set distance. The two certificates are both bounded by the same excess G_R-c_R and must not be added as separate budgets.

A safe combined certificate is

  Delta_R^combined(x)
    =max{D_R(x),dist_infinity(x,Z_R)^2/C_R}
       +c_R-beta(K_R)
    <=G_R(x)-beta(K_R).

It retains both kinds of information within ONE delta_src allowance. For example a physical-volume estimate requiring u<=U, C_R<=Cstar and dist(x,Z_R)>=d>0 costs at most U Cstar delta_src/(eps d^2). Here Cstar is an explicit stratum threshold; the complement C_R>Cstar remains unpaid. It is not a universal coefficient deduced from the theorem.

References projected to Z_R may lie on old outside-label contact faces. They do not install a new AC source or preserve all ambient KKT moments, actual E-priority owners, new alpha or Phi_new. Even legal individual projected anchor coordinates do not authorize replacing the actual source/action law without the missing Gamma stability estimate.

## 6. AC and exact-minimum boundary consequence

There is a useful scope consequence of the proved contact lemma. Every positive-weight nonempty old cell minimum set Z_R has at least one collapsed coordinate (or is a point), and hence has Lebesgue measure zero. For an actual AC source with positive mass on that cell, integral_R(G_R-c_R)dmu is strictly positive. Since some cell has positive source mass, the present finite positive-weight contract cannot attain H=Phi_old with a genuine nonzero AC source. The near-infimum construction remains valid and can make the gap arbitrarily small; no contradiction with near-score selection follows.

Thus any use of an EXACT old minimizing source must be explicitly a reference/relaxed limit, not an actual input to the anchor action. The reviewed files correctly retain AC approximation/reference status and do not claim that a canonical minimum-set point has become an actual source atom.

## 7. What has and has not been paid

The actual summed source-gap budget, its adaptive lost-copy version and the moderate-u/bad-anchor physical estimate are valid, including forced owners. The whole-minimum-set theorem supplies an all-direction transverse certificate with its cell-dependent C_R; it does not supply a dimension-uniform or label-uniform Euclidean/infinity distance budget.

High-u loss, near-minimum loss, large-C_R cells, movement along flat Z_R directions, new row-demand reassignment, Phi_new, and the joint signed growth/fill/return terms remain. No proof of reference-receiver separation, uniform Gamma stability, positive Gamma margin, or global contraction is obtained here. No low-row variance or preexisting return/source credit is spent again.

This audit repeated no numerical experiment. It used direct finite convex/measure arguments and the already recorded tool checks only within their stated algebraic scope.
