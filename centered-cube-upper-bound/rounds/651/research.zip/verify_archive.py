from pathlib import Path
import ast,hashlib,json,re,subprocess,sys,tempfile,shutil
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
assert files==set(manifest['files'])
for name,digest in manifest['files'].items():
 p=root/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
doc=(root/'REPORT.tex').read_text();stack=[]
for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',doc):
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',doc);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',doc)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
assert all(ord(c)>=32 or c in '\n\t' for c in doc)
sha=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ['FINAL_GEOMETRY_AUDIT.md','FINAL_LEDGER_AUDIT.md']:assert sha in (root/name).read_text()
with tempfile.TemporaryDirectory(prefix='ccu-r651-replay-') as tmp:
 rep=Path(tmp)/'repro';shutil.copytree(root/'repro',rep)
 def run(name):
  out=subprocess.run([sys.executable,'-B',str(rep/name)],cwd=rep,capture_output=True,text=True,check=True).stdout
  assert out.strip()
  return json.loads(out)
 for script,output in [('check_old.py','old_results.json'),('check_expectation.py','expectation_certificate.json')]:
  assert run(script)==json.loads((root/'repro'/output).read_text())
  print('PASS exact output:',script)
 run('action_quad.py')
 assert (rep/'quad_results.json').read_bytes()==(root/'repro/quad_results.json').read_bytes()
 rectangle=run('check_rectangle.py');assert rectangle['total_points']==1048
 cover=run('check_cover.py');assert cover['distributions']==130
 ledger=run('check_ledger.py');assert len(ledger['residuals'])==5
 print('PASS quadrature replay,1048 rational geometry points,130 finite cover distributions,5 ledger identities')
print(json.dumps({'files':len(files),'latex_labels':len(labels),'report_sha256':sha,'scope':'No PDF or MATLAB rerun; no physical Gamma payment or general theorem certified.'}))
