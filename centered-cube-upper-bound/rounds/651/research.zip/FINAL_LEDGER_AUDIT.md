# R651 final ledger and probability integration audit

**Result: PASS within the final integrated ledger scope, including the explicitly expected channel-exception bounds. No full Gamma payment or uniform positive margin has been established.**

Bound report: `/tmp/ccu_r651_final/REPORT.tex`

SHA-256: `4276781ad8e293f86ea089cb2556a9e00a91fba6fb4b053fc4e2507455765946`

Scope: same full Gamma, old-source gap and adaptive lost-copy budget, Euler branch and mixing credit, minimum-set limitations, source-capacity versus physical prices, withdrawn optimizing-law claims, and the old-law scope of NUMERIC_REVIEW.md. Earlier independent proofs and numeric certificates are reused; no numerical experiment was rerun and no other file was modified.

## 1. Same actual objective and one consistent law

The old geometry/entropy/source contract permits disjoint positive old I_j without requiring old full-union coverage. E-priority actual next owners cover the full new receiver union; genuine zero owners are deleted and alpha is recomputed. Old rows remain in the old growth/image/loss sums. New positive denominators and source LP rows refer to retained labels.

The full target is still Gamma=D+L(Q'/M)H-L Phi_new, with the original D=E-O+F+RS. H, source cells, actual owner and alpha refer to the same action/state. No source LP value, source-optimality gap, channel count or new state is inserted as free Gamma income.

The report treats Euler as an explicit legal alternative selection, not as an unexplained weighted minimizer. The old R649 weighted minimum was used by the propagation proof only to compare with the Euler benchmark. Euler gives equality and the stronger rowwise conditional marginal identity. It does not restore the old pair-exchange optimum or coercivity. Expectations under the former minimizing law are not retained as expectations under Euler.

## 2. Old source optimality and adaptive owners

The old source can vary with geometry/owners/lambda fixed, so R,M and old row demands remain fixed. The all-state/all-AC score supremum implies 0<=H-Phi_old<=eta M/L without assuming attainment. The cell gap identity with beta is correct and nonnegative, using only interior labels for boundary cost coefficients.

Replacing H by Phi_old in the same-action Gamma changes it by exactly L(Q'/M)(H-Phi_old), between zero and eta Q'. The report correctly observes that this removes favorable old-source excess; it does not create positive budget.

The final report uses the full slack Delta=G_K-beta(K), so sum a_j E Delta(X_j)=H-Phi_old is exact for every feasible assignment. The adaptive owner estimate follows pathwise from eps o_j/u_j<=a_j and Delta>=0. No owner, alpha or anchor independence is inserted. Deleted old rows have o_j=ell_j and remain charged. The physical-volume consequence restricts BOTH u_j<=U and Delta>=tau; the high-u and small-gap complements remain.

Kept and lost source fractions share one source gap. Coordinates and different owner subsets cannot each spend a new copy. The minimum-set/normal certificates do not add another copy of Delta to the full slack already used.

## 3. Minimum-set geometry stays within its actual scope

The constant radius vector, whole-minimum-set rectangle, positive-part distance identity and C_R=max s_j^2/w_j bound are consistent with the independently audited radius-space proof. The constant is explicitly geometry-dependent; the report does not promote it to a uniform cost. The collapsed-coordinate contact corollary concerns reference minima of the SAME old cell cost.

The null minimum-set consequence is also correct for the finite positive-weight old contract. A genuine nonzero AC source cannot put all its mass on these null minimizer sets, so H=Phi_old is not asserted attained. Positive approximation tolerances remain possible.

The stated contact-coordinate image inequality follows from actual E_j subset B'_j, the fixed collapsed contact coordinate and |X_ji-xi_Ki|<=dist_infinity(X_j,Z_K). It uses actual anchors and leaves the cell-dependent distance budget intact. It does not price total physical overlap or new-source demands. Reference projections are not installed as actual atoms/actions.

## 4. Euler matching and the exact mixing credit

Under gamma_j=lambda_j 1_Aj mu, the actual row law is mu|Aj/m_j. Therefore v_j gamma_j(K)/a_j=v_j mu(K)/m_j for every old source cell and every positive u_j. This is genuine arbitrary-growth equality of source-volume and anchor-volume weights. It is not per-sample simultaneous cell balance or a new source reassignment certificate.

The displayed chi_j is nonnegative by weighted convexity of the squared infinity norm. The original source integral defining k_j and the true Euler anchor have iid row conditional law. Hence E k_j=q_j^2h_j-E chi_j exactly and J_mix=sum a_j u_j E chi_j>=0 has the stated source units.

Substitution into the SAME full owner identity gives exactly

  E Gamma=E+L D_H-L C_H+L J_mix
          +E sum(f_j-o_j)(1-zeta k_j)
          +(R-LH/M)E S-L E Xi.

The +L J_mix sign and coefficient are correct, S keeps the OLD score coefficient, and adaptive ownership/source quantities remain inside their action expectations. This is an equality, not a positive lower bound on its entirety. No weighted-minimizer descent is added to the Euler mixing credit. The scalar growth/covariance, fill/lost and actual new-source terms still need one joint payment.

The freely split joint edge problem from the earlier branch is explicitly not claimed minimized by Euler. Its dual lower bound is not misused as a new-source primal upper bound.

## 5. Fractional contact cover: source capacity, with expectation quantified

The finite set-cover statement and its small-set proof have the stated direction. A uniform 1/sqrt(m) cover handles large patterns; otherwise a small positive-probability pattern with disjointness at most delta/p gives a cover of cost <=sqrt(m) missing at most sqrt(delta). The zero-delta cases are handled without assuming a common element across all positive patterns.

For fixed row-law weights, summing tau_e over e gives a density bounded by sqrt(2n) sum lambda_j 1_Aj, hence by sqrt(2n) mu as measures. It counts old source only once and has no additional label/scale factor.

The exception inequality concerns anchor-law mass, equivalently EXPECTED realized source-weighted anchor mass:

  E sum_j a_j 1_bad_j(X_j)
       <=sum_j a_j sqrt(delta_j)
       <=sqrt(M sum_j a_j delta_j).

The adaptive lost-source exception is also an EXPECTATION, justified by the pointwise eps o_j/u_j cap; it is not a pathwise bound on every realized anchor tuple. This quantifier was reported during final integration and is explicit in the bound report, including the statement that these are not per-realization bounds.

Most importantly, neither source-capacity bound pays receiver volume. The actual lost-copy price per source unit remains (u_j/eps)(1-L eps k_j), and new row demands/Phi_new remain. The near-active-set exception is also unpaid: small average mixing does not bound exact active-pattern disjointness, as the retained two-vector example shows. Thus the square-root source count is not presented as a root weak-type bound or a completed Gamma estimate.

## 6. Numerical branch and evidence match the independent review

I read NUMERIC_REVIEW.md. The final report clearly labels the two-source product-law experiment as the PREVIOUS minimizing-assignment branch. Its source supports, row assignment laws, action/owner change and complete raw D are recomputed there. The exact product integrals and actual AC-source fees agree in scope with the independent review; no new calculation is claimed by this audit.

The report keeps the old R=1/16<1 and states that neither state is a global near-extremizer. It distinguishes old source score improvement from full Gamma improvement and retains the changed receivers/owners. The AC fees are subtracted from the proper L coefficients; source atoms and AC attainment are not used. The resulting expectations are explicitly NOT reused under Euler.

The saved MATLAB and quadrature values remain floating corroboration; the Arb enclosures and rational/symbolic certificates retain their separate status. Rectangle finite tests corroborate the already-proved lemma, retain the small-weight modulus and do not infer a general dimension bound.

## 7. Final scope and unresolved costs

No duplicate source-gap allowance, minimizing-gamma gain, per-coordinate source budget or physical-volume credit was found in the integrated branch. The abstract/conclusion retain the absence of a dimension-uniform positive full increment.

High growth, near-minimum loss, large C_K, flat-set motion, near-active-set tolerance, physical channel prices, new source row-demand reassignment and the full signed covariance/lost/source terms remain. The Euler law supplies exact matching and a genuine nonnegative mixing defect; it does not itself prove a uniform Gamma margin, a contractive actual recursion or the general root-order theorem.
