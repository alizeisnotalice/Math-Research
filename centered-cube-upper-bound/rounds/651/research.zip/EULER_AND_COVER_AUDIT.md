# EULER_LAW_AUDIT.md

# R651 independent audit: choosing the Euler anchor law

**Verdict: YES. The Euler assignment is a legitimate replacement selection for the same full Gamma route and preserves the complete R649 propagation estimate and R647 action ledger. It is generally NOT the uB-minimizing assignment; its benchmark cost is equal to the benchmark, which is all the audited prototype proof needs.**

I checked the actual R649 REPORT proof around equations assignment/master/drift, its original D/target contract, and its actual-source section, rather than relying on a summary. Only this file is edited. No new fixture or action-law expectation is computed from the old numeric samples.

## 1. Legality and the exact row law

Fix the genuine current source mu, actual old lambda and all old row data. Choose ONCE, before anchors,

  gamma_j^E= lambda_j 1_Aj mu.

Then sum_j gamma_j^E=L_lambda mu=mu, its mass is lambda_j mu(A_j)=a_j, it is supported in A_j, and it is AC. The actual anchor law is

  X_j independent,  X_j~gamma_j^E/a_j=mu|Aj/m_j.

This is a new explicitly chosen legal product law. All C,E,p,alpha,Phi_new and realized costs must be recomputed for it. It is invalid to retain expectations or samples attributed to the previous minimizing law while relabeling them Euler.

No old pair-exchange F-optimality is restored. Euler is generally not the weighted center optimum either. The legal-half-action and actual-source contract do not require either optimization property.

## 2. What the R649 weighted minimum was actually used for

In the R649 propagation proof, the only optimizing step is

  sum_j a_j u_j B(u_j) g_j^anc
      <=sum_j a_j u_j B(u_j) h_j,

obtained by comparing the minimizing gamma to the Euler benchmark. Under the Euler choice, g_j^anc=h_j ROW BY ROW, so this comparison holds with equality.

The own-anchor convexity estimate remains

  k_j(X_j)<=A(u_j)h_j+B(u_j)r_j(X_j)^2,
  A+B=q(u_j)^2.

Euler's true marginal therefore gives the stronger rowwise statement

  E k_j<=q(u_j)^2 h_j.

This statement can be multiplied by fixed nonnegative old row coefficients; it does not permit moving an adaptive p_j or alpha_j outside expectation.

With SAME E-priority owners and their actual alpha, the complete ALL-old prototype is still

  H_proto=sum_all a_j u_j k_j+eps sum_all(f_j-o_j)k_j.

Consequently

  E H_proto<=sum_all a_j u_j q(u_j)^2h_j
                +eps E sum_all(f_j-o_j)k_j
           =H-D_H+C_H+eps E sum_all(f_j-o_j)k_j.         (E1)

Every adaptive ownership term is retained. For a deleted old row, o_j=ell_j and p_j=f_j=0, so its old diagonal cancels with its lost-copy term. No old row disappears.

## 3. Exact source-volume / anchor-volume matching for every u

Use the DISJOINT old saturated membership cells Omega_K, with z_K=mu(Omega_K), and j in K. Define

  e_Kj=v_j z_K/m_j,
  f_Kj=v_j gamma_j^E(Omega_K)/a_j.

Since gamma_j^E(Omega_K)=lambda_j z_K and a_j=lambda_j m_j,

  f_Kj=e_Kj

EXACTLY, for arbitrary positive old u_j, scales and source concentration. No balanced-growth assumption is used. For zero-mass cells both volumes are zero; no conditional mean is defined there. Summing over K gives v_j for each row and V in total.

When z_K>0, the conditional anchor law given X_j in Omega_K is mu|Omega_K/z_K for EVERY j in K. These are matching conditional marginal laws, not a statement that different independent anchors are the same random point.

The old source-coordinate cost weights w_j=(1+kappa)eps v_j/m_j satisfy

  z_K w_j=(1+kappa)eps e_Kj=(1+kappa)eps f_Kj.

Thus the SAME old coordinate equilibrium has precisely the true anchor-VOLUME weights on that cell. This repairs the former mismatch between cell source-volume weights and a general optimal assignment's anchor volumes. It does not put X_j at the minimum-set reference, impose coordinate independence, or price new row-demand reassignment by itself.

Also, for every fixed row function phi_j,

  sum_j v_j E phi_j(X_j)
      =sum_j(v_j/m_j)int_Aj phi_j dmu.

In particular H=(1+kappa)eps sum_j v_j E r_j(X_j)^2. These identities concern genuine Euler anchors, not ghost resampling after adaptive alpha has been frozen.

## 4. Inventory of estimates preserved and withdrawn

Preserved under the newly fixed Euler law:

* Actual old entropy/KKT identities, harmonic pi=lambda_j d_j/Q, full D=E-O+F+RS and all-old owner identities: they are pathwise/state identities.
* R647 all-old return/merge construction, low-INCOMING score payment, density lower bound and same-alpha far-source hinge: their proofs need legal A_j subset C_j and feasible/support-correct anchors, not the assignment optimum. Their expectations are now taken under Euler; low targets are not deleted.
* R649 H terminal, normalization cancellation, actual h'_j, source LP and Gamma definitions: they do not use the optimizing assignment.
* The complete prototype E1, balanced prototype contraction and all subsequent growth/covariance algebra: Euler supplies the required weighted comparison with equality.
* R651 old-source near-optimality, rectangle/minimum-set and actual adaptive-lost-copy gap budgets: they need sum gamma_j=mu and true marginals. Euler satisfies them, with the additional e=f identity.
* Score-near-max source gap H-Phi_old<=eta M/L: Fscore does not contain gamma, so choosing Euler changes neither that old score nor its source constraint. It does change the random successor.

Withdrawn or not inferred:

* No uB minimizer descent gain J_Euler-J_gamma is credited; it is zero for Euler.
* No old unnormalized F optimum, Delta>=0 pair coercivity or nonnegative old exchange gap is invoked.
* The freely split edge joint LP in OLD_NEW_BRIDGE.md remains a relaxation of source-plus-assignment. Euler imposes b_Kj=lambda_j z_K, so its small JOINT scalarized dual-gap estimate cannot be inherited merely because the source is near-primary-optimal. Primary old-source gap bounds remain valid.
* No previous expected Gamma or source-cell/owner distribution is carried from the minimizing law to Euler.

For Euler the unweighted row moments also obey Z_gamma=Z_lambda exactly. Thus any older estimate relying ONLY on that benchmark comparison can be separately restated for Euler. It is not permission to append its reload/fill/growth payments to the present H/Gamma ledger a second time. Oriented flow feasibility and old saturation at anchors also remain valid, but no physical-flow domination or old pair-cost sign follows.

## 5. Evidence scope of the old two-source fixtures

The R650 nearest-left-box/nearest-right-box assignment was the weighted minimizer in that symmetric old model. Euler instead has gamma_1=gamma_2=mu/2 because both old cubes contain the full source and lambda_1=lambda_2=1/2. Each Euler anchor is a mixture of BOTH boxes. These are different actual product laws.

Therefore the old nearest-source assignment evidence and any law-based interpretation cannot be transplanted to an Euler expected inequality. The fixed representative tuple X_i=y_i still gives a legal deterministic action with the same geometry and owner/source computations, and belongs to Euler's support; an exact tuple is a null event under either AC law. Its deterministic same-score ownership effect may remain labeled as such, but it proves no positive-probability or expected Euler gain. No new Euler experiment has been run for this audit.

## 6. Independent exact Euler mixing defect and full propagation

This additional calculation was derived independently before the author's new mixing paragraph was available. Put sigma_j=1+b_j and define, for x,z in A_j,

  chi_j(x,z)=
   {sigma_j[r_j(x)^2+b_j r_j(z)^2]
     -||(x-y_j)+b_j(z-y_j)||_infinity^2/s_j^2}/t_j^2.

The weighted norm-square convexity inequality gives chi_j>=0 pointwise. Under Euler the integrated old source point x and the ACTUAL own anchor z=X_j have independent identical conditional law mu|Aj/m_j. Thus

  E k_j
    =q_j^2 h_j
      -integral integral chi_j(x,z) d(mu|Aj/m_j)(x)
                                     d(mu|Aj/m_j)(z).

No new independent source law is imposed on different coordinates. The x variable is the original conditional integral defining k_j; averaging over the true Euler anchor law supplies its second iid row variable. Adaptive owners and alpha do not occur inside this fixed-row marginal calculation.

Define the deterministic old-state mixing quantity

  J_mix=sum_all a_j u_j E_(x,z iid mu|Aj/m_j) chi_j(x,z)>=0.

Then the COMPLETE propagation is an equality:

  E sum_all a_j u_j k_j
     =sum_all a_j u_j q_j^2 h_j-J_mix,
  E H_proto
     =H-D_H+C_H-J_mix+eps E sum_all(f_j-o_j)k_j.         (E2)

The owner term has not been factored or bounded. All old rows remain present, including labels later deleted. This J_mix is the exact convexity defect in the prototype, not a claimed minimizer descent J_Euler-J_gamma.

With Xi=Phi_new-H_proto, zeta=L eps and F_oldscore=R-LH/M, the exact full score is

  E Gamma_L
    =Eold+L(D_H-C_H)+L J_mix
       +E sum_all(f_j-o_j)(1-zeta k_j)
       +F_oldscore E S-L E Xi.                         (E3)

The source-slack coefficient is the OLD score, unchanged. Expanding Eold-L C_H through the genuine harmonic pi=lambda_j d_j/Q yields

  E Gamma_L
    =(V/kappa)E_pi[(u-kappa)^2(1-zeta q(u)^2h)]
      +L D_H-zeta V Cov_pi(u,q(u)^2h)+L J_mix
      +E sum_all(f_j-o_j)(1-zeta k_j)
      +F_oldscore E S-L E Xi.                         (E4)

The former weighted-minimizer lower bound is now this exact Euler equality with +L J_mix. No claim gives J_mix a uniform positive fraction of H or M. AC sources can concentrate and the infinity-norm cost has flat directions; the new quantity must be used within this SAME equation, not as an additional free allowance outside it. The source/lost/covariance sign still requires proof.

## 7. Precise conclusion and local evidence

Changing from the minimizing assignment to Euler is a legitimate change of the auxiliary action-selection rule within the full original geometric goal. It preserves the functional Gamma target, all state definitions, actual KKT, E-priority ownership and same-epsilon normalization. It changes the sampled action law and therefore the unknown expectation to be proved.

The decisive benefits actually verified are arbitrary-u cell-volume equality e_Kj=f_Kj, rowwise prototype control, and the exact nonnegative mixing term in E2-E4. No old optimum descent is credited. No new source/overlap price or uniform positive Gamma increment has been proved by this audit.

Executed the installed local math Python with SymPy 1.14.0. The Euler cell-volume identity, A+B=q^2 and source/equilibrium volume coefficient all had zero exact residuals. A second bounded symbolic check returned zero for the iid mixing coefficient in E2 and the +L J_mix sign/coefficient in E3. No numerical fixture, old two-source expectation or broad scan was rerun.

## 8. Check against the author's Euler continuation

After the independent derivation above, I read OPTIMAL_SOURCE_OWNERS.md's newly appended equations (7)-(12). Its Euler feasibility, all-u volume equality, mixing definition, rowwise exact average and full expected Gamma identity agree with sections 1-7 of this audit. In particular its (12) has the correct +L J_mix sign, unchanged OLD score coefficient on E S, and all adaptive owner/source quantities inside their actual expectations. Its one-time L tau M' subtraction is required when replacing Phi_new by an actual AC near-minimal source.

The additional reference channel-flux formula is also consistent. At a relative-interior point xi_R of the old minimum rectangle, active row radius coordinates are collapsed. Thus the equilibrium theta may use those active coordinates; if rho_Rj=0 the whole minimum rectangle is the single y_j. From

  b_Rl=2 sum_j [(1+kappa)eps v_j/m_j]
                    theta_Rjl(xi_Rl-y_jl)/s_j^2

and active-contact xi_Rl-y_jl=sign(xi_Rl-y_jl)s_j rho_Rj, multiply by z_R/[2(1+kappa)eps] to obtain exactly the author's volume-weighted flux (9). The zero-radius case contributes zero and causes no division by rho. Rectangle-boundary normals remain on the right side and are not discarded. Euler e=f transfers its coefficients to expected actual anchor-volume channels, not to per-realization simultaneous balance.

No further geometric payment follows from that flux identity. Its rho/s price is not yet the adaptive lost receiver-volume price, and it does not construct a feasible low-cost new demanded-cell mass vector. The author explicitly retains these distinctions and makes no uniform positive Gamma claim.


---

# CONTACT_COVER_SCREEN.md

# R651 contact-cover screen — independent checkpoint

The Euler equality and finite-set cover statements pass independent inspection, with signed active sets A(v)={(i,sigma):sigma v_i=||v||_infinity}; at v=0 this convention gives all 2n signed coordinates. The Euler numerator decomposes into b(||v||-||w||)^2 plus the nonnegative triangle deficit (||v||+b||w||)^2-||v+bw||^2. Equality therefore requires equal norms and a common signed active coordinate.

For any distribution P on nonempty subsets of an m-element set, with delta=P(A intersect B empty) under iid draws, the proposed two-case proof gives nonnegative weights of total <=sqrt(m) covering probability at least 1-sqrt(delta). Cardinal thresholds are literal |A|<=sqrt(m), equivalent to <=floor(sqrt(m)); no integrality obstruction occurs. Full proof and exact limitations follow.

## Final verdict and precise assumptions

PASS for the stated Euler equality, iid zero-defect pattern structure, pairwise-intersecting-family transversal, and quantitative random-set cover. All are elementary statements proved below. No external theorem is used.

Here n>=1, b>0, t>0, and ||.|| denotes the infinity norm on R^n. For the actual half-action t=1+2b, but that relation is unnecessary for the algebraic equality characterization. The set-cover statement holds for any positive integer m, hence in particular m=2n.

The statements yield a possible sqrt(2n) ROW-LAW structure. They do not establish the actual full source/column budget or a positive Gamma increment. In particular the missing passage from small continuous Euler defect to a small exact disjoint-active-pattern probability must not be silently assumed.

## Euler equality: signed active coordinates and zero vectors

For v in R^n define its nonempty signed active set

    A(v)={(i,sigma):1<=i<=n, sigma in {-1,+1},
                         sigma v_i=||v||}.

If v is nonzero, this is the set of signed coordinates attaining its norm. If v=0, BOTH signs at every coordinate belong to A(v). This zero-vector convention is essential for a uniform 'if and only if' statement.

Put a=||v|| and c=||w||. The numerator of the assigned defect has the exact decomposition

    (1+b)(a^2+b c^2)-||v+bw||^2
      =b(a-c)^2+[(a+b c)^2-||v+bw||^2].

Both terms are nonnegative, the second by the norm triangle inequality. Therefore chi(v,w)=0 forces a=c and equality in that triangle inequality. Choose a coordinate attaining ||v+bw|| and its sign sigma. Equality in

    sigma(v_i+b w_i)<=|v_i|+b|w_i|<=a+b c

forces sigma v_i=a and sigma w_i=c. Thus A(v) intersects A(w). Conversely, a common signed active coordinate gives ||v+bw||=a+b c; if a=c the square decomposition vanishes. Hence precisely

    chi(v,w)=0 iff ||v||=||w|| and A(v) intersect A(w) nonempty.

This also handles v=w=0. A convention that assigns the empty active pattern at zero would require treating that case separately.

## Iid zero-defect law

Let V,W be independent with the SAME probability law on R^n. If chi(V,W)=0 almost surely, then ||V||=||W|| almost surely. Two iid real random variables that agree almost surely must have a Dirac law: for each real threshold q, independence gives P(||V||<=q)P(||W||>q)=0. Testing rational thresholds identifies one constant radius r0>=0. Thus ||V||=r0 almost surely.

The same conclusion holds if the nonnegative defect has expectation zero, because then it vanishes almost surely. No hidden second-moment argument is required for this zero statement.

The random signed active set takes only finitely many nonempty values. If two values A,B each have positive probability and were disjoint, independence would assign their joint occurrence positive probability, contradicting the Euler equality. Therefore the positive-probability pattern family is pairwise intersecting.

It need not have a common coordinate. For n=3, the equiprobable vectors (1,1,0), (0,1,1), (1,0,1) all have norm one and positive active patterns {+1,+2}, {+2,+3}, {+1,+3}. Every pair intersects but the intersection of all three is empty. This is an abstract row-law example, not an actual AC cube source.

Identical distribution and independence are substantive hypotheses. Two different independent laws with zero cross defect yield a cross-intersection condition between their two supported pattern families, not automatically pairwise intersection within either family. The actual Euler integral involving old mu|Aj/m_j versus gamma_j/a_j cannot be called iid unless that equality of laws is proved; in general gamma_j is not lambda_j1_Aj mu.

For an actual AC row law obtained by an invertible translation/scaling of source coordinates, a constant infinity norm is supported on a Lebesgue-null cube surface (or a singleton at radius zero). Thus exact iid zero defect is an ideal/limiting structural statement in that setting, not an assertion that a positive actual AC source attains it.

## Pairwise-intersecting finite-family transversal

Let F be a nonempty family of nonempty subsets of an m-element universe, and suppose every two members intersect. Let A0 be a member of minimum size r>=1.

If r<=sqrt(m), set w_i=1 for i in A0 and zero otherwise. Every member intersects A0 and has sum_{i in A}w_i>=1, while total weight is r<=sqrt(m).

If r>sqrt(m), set w_i=1/r for every universe element. Every member has at least r elements, so its weight is at least one, while total weight is m/r<sqrt(m).

This proves the claimed nonnegative fractional transversal bound without a common global element, an orthogonality assumption, or an external set-system theorem. The universe can be signed coordinates; no claim that every possible set family is realizable by actual cube/source data is needed.

## Quantitative random-set version

Let P be ANY probability distribution on the nonempty subsets of an m-element universe. For independent A,B with law P define

    delta=P(A intersect B empty) in [0,1].

There exist nonnegative deterministic weights w_i, depending on P, such that

    sum_i w_i<=sqrt(m),
    P(sum_{i in A}w_i>=1)>=1-sqrt(delta).

Proof. Write S={A:|A|<=sqrt(m)} and p=P(S).

If p<=sqrt(delta), choose uniform w_i=1/sqrt(m). Every A outside S has |A|>sqrt(m) and therefore has weight >1. Covered mass is at least 1-p>=1-sqrt(delta), and total weight is exactly sqrt(m). When m is a perfect square, sets of cardinality exactly sqrt(m) are also covered; the lower bound simply does not need this extra mass.

If p>sqrt(delta), then p>0. For a fixed set A define its bad degree

    d(A)=P(B intersect A empty).

Averaging over the small sets gives

    sum_{A in S}P(A)d(A)<=delta.

Hence some small set A0 of positive P-mass has d(A0)<=delta/p. The set universe is finite, so this is a literal finite weighted-average selection, with no measurable-selection issue. Take w_i=1_{i in A0}. Its total weight is |A0|<=sqrt(m), and it covers exactly the sets intersecting A0, with probability

    1-d(A0)>=1-delta/p>=1-sqrt(delta).

For delta>0 the last inequality is strict in this branch. At delta=0 the same branch gives d(A0)=0 and complete coverage. If delta=0,p=0 the uniform branch covers all sets. At delta=1 the claimed covered lower bound is zero and the uniform branch remains valid. Equality p=sqrt(delta) belongs to the first branch, so no threshold ambiguity occurs.

All cardinal thresholds are integer-safe: |A|<=sqrt(m) means |A|<=floor(sqrt(m)); outside sets have integer cardinality strictly greater than sqrt(m). There is no need to replace sqrt(m) by a ceiling in the total-weight claim. The positive weights need not sum to one; they are a fractional cover, not a probability distribution on coordinates.

## Quantitative limitation: small Euler defect does not bound exact pattern delta

The proved random-set theorem takes delta as an INPUT. A small expected Euler defect does not, by itself, imply a small delta for exact active sets. Near ties can change exact active coordinates discontinuously.

For a concrete abstract example in R^2, let V be equiprobable on

    v_e=(1,1-e),   w_e=(1-e,1),   0<e<1,

and W be an independent copy. Both vector norms are one, but their active patterns are the disjoint singletons {+1} and {+2}. Thus delta=1/2 for every e>0. At b=1,t=3, same-type defects are zero, cross-type defects are (4e-e^2)/9, and

    E chi(V,W)=(4e-e^2)/18 ->0 as e down to zero.

Therefore no implication delta->0 from E chi->0 is available without an additional active-coordinate margin, an approximate-active-set construction with its own priced error, or another genuine comparison. This example does not refute the set-cover theorem, the exact zero-defect statement, or any claimed actual critical cube inequality; it identifies the exact missing quantitative connection.

## Scope for the full source/action problem

At m=2n, the cover budget is sqrt(2n), providing the announced dimension source for a potential row-law mechanism. But the weights may depend on the individual row's full law. The argument alone does not combine different rows' weights into one source-column packing, price uncovered mass under inverse entropy factors, or compare the covered coordinates with actual receiver losses/new demanded cell masses. It also does not convert a contact existence statement into coordinate orthogonality.

Any application to the unchanged Gamma ledger must retain the actual source moments, the prescribed gamma and its independent product law, the one E-priority ownership, actual alpha and actual Phi_new. Neither the fractional cover nor its zero-defect motivation supplies these all-row payments. No uniform positive Gamma increment or general bound is certified.

## Actual symbolic check

Executed the installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. The Euler numerator decomposition had exact residual zero. The near-tie two-point iid fixture at b=1,t=3 gave expected defect e(4-e)/18. The non-square threshold example m=6 has floor(sqrt(m))=2 and uniform total weight exactly sqrt(6). These checks target the frozen statement and its threshold/defect distinction; no scan or actual source experiment was performed.

Final delivery is confined to this file. No external theorem, atomized actual source, Git operation, PDF, or global-budget conclusion was used.
