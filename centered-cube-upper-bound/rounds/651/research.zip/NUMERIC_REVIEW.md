# R651 final independent review of the two-source full-product-law calculation

**Verdict: PASS for the frozen two-source comparison, including the complete anchor expectation and actual AC-source fees.** This round evaluates genuine independent anchor laws, rather than only R650's fixed representative anchors. The experiment remains one-dimensional with old `R=1/16<1`; it does not establish or refute the general critical-state budget.

Scope is exactly the two sources and policies in `NUMERIC_PLAN.md`: A is the R650 two-box source with an optimal E-priority endpoint owner at every actual action; B is the centered positive-width AC near-minimizer with forced ownership. There is no added source class, width sweep, dimension expansion, or execution of a new stage in this review. The separate rectangle test files present in the directory are outside this frozen comparison and are not certified by this review.

I read `check_old.py`, `check_expectation.py`, `action_quad.py`, their saved results, and the MATLAB script/log. I reran the two small exact certificate scripts without changing their output files, then independently reconstructed the old integrals, minimizing assignment price difference, endpoint logarithmic integral, B product integral, raw D and AC fees. Final hashes are bound below. No other worker file, Git state, or PDF was modified.

## 1. Genuine old sources and actual minimizing gamma

Both sources use the same real old state: `a=32,s=2/9,d=4/9,v=1/72,epsilon=56,lambda=(1/2,1/2)`, centers +/-1/64, old `m=(2,2),M=2,Q=4/9,V=1/36,R=1/16,kappa=7/2`. The owned old receivers are truly disjoint. Both source supports lie strictly in the common old intersection `[-119/576,119/576]`, so their total mass 2 gives `mu(A_i)=m_i` and old load one mu-a.e. The positive old source and these exact gradients certify old entropy KKT.

Source A has mass 1 on each `[-5/256,-3/256]` and `[3/256,5/256]`, density 128 on each. Source B has mass 2 on `[-1/1024,1/1024]`, density 1024. Neither is an atom or a zero-width approximation.

The old spatial objective on the one saturated common cell is
\[
G_{old}(x)=\kappa t^2(x^2+\delta^2/4),\quad t=9/2,\quad\delta=1/32.
\]
The forced old LP source mass is 2; primal `z=2` and dual `(G_old(0),0)` agree. Thus
\[
\Phi_{old}=567/16384,
\quad H_A=18333/262144=(97/48)\Phi_{old},
\quad H_A-\Phi_{old}=9261/262144,
\]
\[
H_B=145341/4194304,
\quad H_B-\Phi_{old}=189/4194304.
\]
The exact H infimum is not attained by an AC source: its minimizing set is the singleton zero. B is a genuine positive-width AC near-minimizer, with its positive gap retained.

The assignment coefficient `u B(u)=539/648` is the same positive number for both old rows. The normalized squared costs differ by
\[
r_1(x)^2-r_2(x)^2=2\delta x/s^2.
\]
Each source has mass exactly 1 on each side of zero. Assigning all negative source to row 1 and positive source to row 2 therefore attains the **pointwise** lower cost while satisfying both row masses 1. This proves global assignment optimality over all feasible source partitions; comparing only the reverse assignment would not by itself be enough. The scripts' reverse-cost check agrees with this stronger proof.

Accordingly, A has independent `X_i=y_i+Uniform[-h,h]`, `h=1/256`; B has independent `X1~Uniform[-w,0]`, `X2~Uniform[0,w]`, `w=1/1024`. These are the actual laws used in every expectation below.

## 2. The changed action and actual ownership are accounted for

The half action is recomputed as `c_i=sigma*y_i-b*X_i`, with `b=7/4,sigma=11/4` and new halfside 1. All original I are full old receivers, so every image E_i is the corresponding full new B'_i.

For A, actual center separation satisfies
\[
\Delta_A=\delta-b(\xi_2-\xi_1)
\in[9/512,23/512]\subset(0,r),\quad r=1/16.
\]
Thus the new receivers overlap throughout the entire anchor support. The optimal E-priority endpoint policy assigns the whole overlap to row 2, so `p1=Delta_A,p2=r,W=r+Delta_A`. The reflected endpoint is equivalent. For a fixed action, `Q'=2` and D,H are owner-independent; minimizing `p1*p2` on its actual interval is therefore exactly maximizing the same Gamma_L for every L>0. The endpoint is optimal, not merely a selected convenient owner.

For B,
\[
\Delta_B=\sigma\delta-b(X_2-X_1)
\in[169/2048,11/128]\subset(r,2).
\]
The receivers are disjoint throughout the entire support, so `p1=p2=r,W=1/8` is forced. The large C intervals still overlap with positive volume. In both models the actual entropy solution is `alpha_i=p_i/W`; hence the large-cube load is saturated on their common cell, singleton-cell loads are below one, and all rows remain positive. Exact stationarity has the common positive multiplier `m'=2+epsilon W`. Consequently `Q'=M=2,S=0,E'=0` in every realization.

No alpha is frozen across A's varying anchors or varying ownership. A's next kappa ranges over `[287/128,385/128]`, whereas B's next kappa is 7/2. Neither experiment is a general calibrated critical-state sequence.

The raw full ledger is preserved: old growth is zero and fill is zero. A has actual overlap `O=r-Delta_A`, so `D_A=Delta_A-r`; B has no overlap and `D_B=0`. Therefore
\[
\mathbb E D_A=-1/32,\qquad \mathbb E D_B=0.
\]
These raw terms must not be omitted when comparing the source choices.

## 3. Exact new source LP, complete expectation, and AC fees

There is exactly one positive-volume saturated cell, the real common C interval. At a given action its quadratic cost is
\[
G_{src}(x)=\frac\epsilon{m'}\sum_i p_i(x-c_i)^2.
\]
The minimizing point is the p-weighted new center, inside that cell. Primal mass m' and dual `(c_cell,0)` give equal value
\[
\Phi_{new}=\epsilon p_1p_2\Delta^2/W.
\]
This is the R651 source cost without an erroneous division by g.

A uses `Phi_A,end=epsilon*r*Delta_A^3/(r+Delta_A)`. With `q=2bh=7/512`, the exact transformed product law is triangular. Its reciprocal expectation is
\[
J=\mathbb E[1/(r+\Delta_A)]
=\frac{512}{49}[55\log(55/48)+41\log(41/48)],
\]
so
\[
\mathbb E\Phi_{A,end}
=\epsilon r[\delta^2+q^2/6-r\delta+r^2-r^3J].
\]
I independently integrated the two halves of that triangular density and checked exact equality to this logarithmic expression. B's direct rectangular product integral gives
\[
\mathbb E\Phi_B=4999393/402653184.
\]
Thus the **same full objective** in both cases has exact form
\[
\mathbb E\Gamma_{A,end}=-1/32+L(H_A-\mathbb E\Phi_{A,end}),
\qquad
\mathbb E\Gamma_B=L(8953343/402653184).
\]
The actual 256-bit Arb enclosures from the rerun exact certificate are:

| Quantity | Enclosure, abbreviated decimal |
|---|---:|
| E Phi_A,end | 0.00121577448221454945096475274803089582990801591 +/- 3.36e-49 |
| A Gamma L coefficient | 0.0687190704884885755490352472519691041700919841 +/- 1.04e-47 |
| B Gamma L coefficient | 0.0222358678778012593587239583333333333333333333 +/- 3.34e-47 |
| B-minus-A L coefficient | -0.0464832026106873161903112889186357708367586508 +/- 4.37e-47 |
| LP-score crossing | 0.672285863384444780225492035411261610009227050 +/- 3.17e-46 |

The constant in B-minus-A is +1/32. Hence improving the old source does not monotonically improve the complete increment for all L. This does not contradict improvement of the old score itself: old R,M are unchanged and its improvement is `L*(H_A-H_B)/M`. Nor is it a failure of the general critical target, which these small-N inputs do not satisfy.

For every action the explicit AC next source is uniform mass m' on `[x_p-eta,x_p+eta]`, eta=1/4096. The separation bounds imply this interval stays strictly within the common C cell. It has both exact row demands and saturated load. Its cost is exactly `Phi_new+epsilon W eta^2/3`. Expected fees are
\[
f_A=7/67108864,\qquad f_B=7/50331648.
\]
They are subtracted as `L f_A,L f_B` from the respective full increments. The actual-AC crossing is therefore different and is enclosed by
\[
0.672285360515854704117716937078381219667754516
\quad\pm2.35\cdot10^{-46}.
\]
No source atom or fictitious AC attainment was substituted. The explicit anchor-dependent source interval is a concrete continuous rule in this model; no unproved generic source-kernel selection is required here.

## 4. Floating crosschecks have the correct interpretation

I inspected `action_quad.py` and all saved quadrature levels 16,32,64,128. It transforms the true two product laws correctly, recomputes centers, p, alpha, demands and D at every quadrature node, and uses endpoint A / forced B ownership. Against the independently derived exact values, the largest saved absolute differences in E Phi were approximately `3.90e-18` for A and `8.67e-17` for B. These are observed agreement figures, not certified quadrature error bounds.

The five sample tuples per model verify floating geometry and KKT at those tuples only. Whole-support validity comes from the exact interval bounds and formulas in sections 1–3, not from those ten samples.

I inspected `crosscheck.m` and the saved `MATLAB_RESULT.txt`; I did not rerun MATLAB. The script uses the correct normalized product integrals for both sources. The saved MATLAB R2026a Update 4 `integral2` result differs from the exact A value rounded to double by about `1.52e-18`, and matches the rational B value at that precision. Its slopes, crossings and AC fees agree to floating precision. This saved MATLAB execution is independent corroboration, not a rigorous interval certificate and not an execution performed by this reviewer.

## 5. Actual reproduction commands and scope of reruns

The following command was actually executed. It reruns only the two small exact scripts, captures stdout in memory and compares it to their saved JSON. It does not rewrite the result files or rerun the floating quadrature/MATLAB calculation.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
from pathlib import Path
import subprocess,sys,json
root=Path('/tmp/ccu_r651/numeric')
for script,result in [('check_old.py','old_results.json'),
                      ('check_expectation.py','expectation_certificate.json')]:
    run=subprocess.run([sys.executable,str(root/script)],check=True,
                       capture_output=True,text=True)
    assert json.loads(run.stdout)==json.loads((root/result).read_text())
    print('PASS exact-script rerun and saved-output equality:',script,result)
print('Python',sys.version.split()[0])
PY
```

Output was two PASS lines and `Python 3.12.14`. The exact scripts used SymPy 1.14.0 and python-flint 0.9.0, Arb precision 256 bits.

The following complete independent derivation/check was also actually executed; it does not import author functions or mutate any result:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
from pathlib import Path
import sympy as S,json,re,hashlib
from flint import arb,ctx
ctx.prec=256
root=Path('/tmp/ccu_r651/numeric')
x,y,z=S.symbols('x y z',real=True)
k=S.Rational(7,2); t=S.Rational(9,2); s=1/t; b=k/2; sig=1+b
d=S.Rational(1,32); r=S.Rational(1,16)
h=S.Rational(1,256); w=S.Rational(1,1024)
ep=S.Integer(56); eta=S.Rational(1,4096)
Gold=k*t*t*(x*x+d*d/4)
phiold=2*Gold.subs(x,0)
HA=sum(S.integrate(Gold,(x,cen-h,cen+h))/(2*h)
       for cen in [-d/2,d/2])
HB=S.integrate(Gold,(x,-w,w))/w
assert (phiold,HA,HB)==(S.Rational(567,16384),
 S.Rational(18333,262144),S.Rational(145341,4194304))
assert S.expand(((x+d/2)/s)**2-((x-d/2)/s)**2)==2*d*x/s**2
sepA=d-b*(y-x); q=2*b*h
sepB=sig*d-b*(y-x)
J=((r+d+q)*S.log((r+d+q)/(r+d))
   +(r+d-q)*S.log((r+d-q)/(r+d)))/q**2
phiA=ep*r*(d*d+q*q/6-r*d+r*r-r**3*J)
tri=ep*r*z**3/(r+z)
phiAint=(S.integrate(tri*(z-d+q)/q**2,(z,d-q,d))
         +S.integrate(tri*(d+q-z)/q**2,(z,d,d+q)))
assert S.expand_log(S.simplify(phiA-phiAint),force=True).simplify()==0
phiB=S.integrate(S.integrate(ep*r/2*sepB**2,(x,-w,0)),
                 (y,0,w))/w**2
assert phiB==S.Rational(4999393,402653184)
DA=S.integrate(S.integrate(sepA-r,(x,-h,h)),
               (y,-h,h))/(4*h*h)
assert DA==-S.Rational(1,32)
assert S.integrate(S.integrate(S.Integer(0),(x,-w,0)),
                   (y,0,w))/w**2==0
feeA=ep*(r+d)*eta**2/3; feeB=ep*(2*r)*eta**2/3
assert feeA==S.Rational(7,67108864)
assert feeB==S.Rational(7,50331648)
print('PASS independent old-source integrals, assignment cost difference, '
      'endpoint log integral, B product integral, raw D and AC fees')
quad=json.loads((root/'quad_results.json').read_text())
refA=float(phiA.evalf(50)); refB=float(phiB)
errA=max(abs(row['phi']-refA) for row in quad['quadrature_results']['A'])
errB=max(abs(row['phi']-refB) for row in quad['quadrature_results']['B'])
assert errA<1e-15 and errB<1e-15
print('diagnostic_max_quadrature_abs_differences',errA,errB)
mat=(root/'MATLAB_RESULT.txt').read_text()
ma,mb=map(float,re.search(r'; A ([^ ]+) B ([^\n]+)',mat).groups())
assert abs(ma-refA)<1e-15 and abs(mb-refB)<1e-15
print('diagnostic_MATLAB_abs_differences',abs(ma-refA),abs(mb-refB))
for name in ['check_old.py','old_results.json','check_expectation.py',
             'expectation_certificate.json','action_quad.py',
             'quad_results.json','crosscheck.m','MATLAB_RESULT.txt']:
    print('SHA256',name,hashlib.sha256((root/name).read_bytes()).hexdigest())
PY
```

This returned PASS for the independent exact derivation and the diagnostic discrepancies quoted above. The numeric 1e-15 comparisons in this command are explicitly floating crosschecks; the symbolic identities and Arb calculations are the exact/rigorous part. No tolerance is used to infer old KKT, saturation, assignment optimality, the source LP minimum, or a general theorem.

## 6. Final SHA-256 binding and stop

| Artifact | SHA-256 |
|---|---|
| check_old.py | 99e807a1a8048557aec43a7323e51c3e8d15bbdeb52b46bbd9909498fc5f82a5 |
| old_results.json | 74186925f300bd3b5edd2afce7b6d2f44b7e16c0bb4b43ad520f601e29c09388 |
| check_expectation.py | 46aeaed0a24002733a3136f68dbc40e9f19fc82ec352da71b997de5dbb3c9717 |
| expectation_certificate.json | 685210b7ca61f56ff5bd09ec7ba63ddf88c86df2455228bd8d5079311ed10404 |
| action_quad.py | 9fb008bb25630559972d26bd637df043a1f1917056c1242abd753370a3d4bd75 |
| quad_results.json | a46bcda6c567f841ac33ab80a18b85612a983be6dbb88ad6ce53441b0e7831b2 |
| crosscheck.m | 75163f3b6e90fc1ce6966c52f923d4c3a3605be737c1b7b76bdc53830a630a2f |
| MATLAB_RESULT.txt | cb19be498502790a1897d16c069a288c46a142df4e196626587166eda0bef2bf |

This finite evidence establishes that old-source optimization must be incorporated into the actual action law and full score; its effect is not captured by lowering an isolated source cost while freezing receivers. It does not provide a uniform positive margin or the general root-order bound. The original whole-family target and all recovery obligations remain open. No further local experiment is recommended from this frozen comparison.
