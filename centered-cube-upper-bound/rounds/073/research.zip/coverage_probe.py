#!/usr/bin/env python3
"""Actual band gated-posterior packet optimization with independent validation.
Finite source-only partitions with weighted-median candidates and, in low
dimension, unrestricted finite-arrangement representatives.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,itertools,json,math,time
from pathlib import Path
from fractions import Fraction as F
import numpy as np

def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])

def integer_masses(src):
    masses=[F(p)/F(src['W']) for p in src['weights']];den=math.lcm(*(p.denominator for p in masses));assert den<2**60
    integers=np.array([p.numerator*(den//p.denominator) for p in masses],dtype=np.int64)
    return den,integers

def pack(coords,weights,family):
    merged={};weights=[F(p) for p in weights];W=sum(weights)
    for y,p in zip(coords,weights):merged[tuple(float(z) for z in y)]=merged.get(tuple(float(z) for z in y),F(0))+p/W
    return dict(family=family,n=len(coords[0]),N_requested=len(coords),N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W='1')

def binary_geometry(x,coords):
    xr=[float(z).as_integer_ratio() for z in x];yr=[[float(z).as_integer_ratio() for z in y] for y in coords]
    B=max(t.bit_length()-1 for u,t in xr+sum(yr,[]));xi=[u<<(B-(t.bit_length()-1)) for u,t in xr]
    ds=[max(abs(z-(u<<(B-(t.bit_length()-1)))) for z,(u,t) in zip(xi,row)) for row in yr]
    return ds,B

def exact_winner(x,src,H):
    ds,B=binary_geometry(x,src['coords']);den,ints=integer_masses(src);order=sorted(range(src['N']),key=lambda i:ds[i])
    cum=0;bestnum=0;bestden=1;best=-1
    for j,i in enumerate(order):
        cum+=int(ints[i])
        if j+1<len(order) and ds[i]==ds[order[j+1]]:continue
        d=ds[i]**src['n']
        if d==0:raise ValueError('Receiver coincides with an atom; null-set sample unsupported')
        if cum*bestden>bestnum*d:bestnum,bestden,best=cum,d,j
    M=F(bestnum,bestden)*F(src['W'])/den/F(2)**(src['n']*(1-B))
    capture=np.zeros(src['N'],dtype=bool);capture[order[:best+1]]=True
    return capture,M,H<M<=2*H,order,best

def actual_volumes(x,src,H):
    ds,B=binary_geometry(x,src['coords']);V=F(src['W'])/F(H);factor=F(2)**(src['n']*(1-B))/V
    return [d**src['n']*factor for d in ds],[F(p)/F(src['W']) for p in src['weights']]

def structured_source(kind,n,N,seed):
    rng=np.random.default_rng(seed)
    if kind=='binary':
        if N<=2**n:
            labels=rng.choice(2**n,size=N,replace=False)
            y=np.array([[2*((int(j)>>k)&1)-1 for k in range(n)] for j in labels],float)
        else:
            y=rng.choice([-1.,1.],size=(N,n))+rng.integers(-8,9,size=(N,n))/64
        weights=[1]*N
    elif kind=='hierarchical':
        depth=max(1,(N-1).bit_length())
        code=rng.integers(0,2,size=(depth,n))*2-1
        y=np.array([sum((((j>>k)&1)*2-1)*2.**(-k)*code[k] for k in range(depth)) for j in range(N)])
        y/=max(1.,float(abs(y).max()));weights=[1]*N
    elif kind=='correlated':
        t=np.linspace(-1,1,N)[:,None]
        y=t+rng.integers(-4,5,size=(N,n))/128;weights=[1]*N
    elif kind=='unequal_cloud':
        y=rng.integers(-64,65,size=(N,n))/64;weights=[1+(j%8)**2 for j in range(N)]
    elif kind=='multi_cluster':
        centers=rng.choice([-1.,1.],size=(4,n));y=np.array([centers[j%4]+rng.integers(-8,9,size=n)*2.**(-4-j//4) for j in range(N)])
        weights=[1+3*(j%4==0) for j in range(N)]
    else:raise ValueError(kind)
    return pack(y.tolist(),[F(p) for p in weights],kind)

def draw_winner(src,lam,S,seed):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/lam)
    component=rng.choice(3,size=S,p=[.5,.25,.25]);unif=rng.integers(src['N'],size=S);mass=rng.choice(src['N'],size=S,p=a);center=np.where(component==0,unif,mass)
    U=np.maximum(rng.random(S),np.nextafter(0.,1.));inner=rng.integers(0,2,size=S)==0
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))+np.where(component==2,np.log(a[center]),0)
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1;theta[np.arange(S),face]=sign
    return y[center]+(.5*np.exp(lv/n))[:,None]*theta,component,center,U,inner,face,sign

def winner_batch(x,src,lam):
    y,a=arrays(src);S=len(x);n=src['n'];N=src['N'];den,ints=integer_masses(src);V=float(F(src['W'])/lam)
    delta=x[:,None,:]-y[None,:,:];dist=np.max(abs(delta),axis=2)
    if np.any(dist==0):raise ValueError('Null-set atom receiver coincidence unsupported')
    L=n*np.log(2*dist)-math.log(V)
    t=np.exp(-2*np.maximum(L,0));q=t.sum(axis=1)/(4*N)+(t*a[None,:]).sum(axis=1)/8+np.exp(-2*np.maximum(L-np.log(a)[None,:],0)).sum(axis=1)/8
    order=np.argsort(L,axis=1,kind='stable');sl=np.take_along_axis(L,order,axis=1)
    ends=np.concatenate([sl[:,1:]!=sl[:,:-1],np.ones((S,1),bool)],axis=1);fix=0;falsegroups=0
    near=np.any(abs(sl[:,1:]-sl[:,:-1])<=64*np.finfo(float).eps*(np.max(abs(sl),axis=1)[:,None]+2),axis=1)
    for r in np.flatnonzero(near):
        ds,B=binary_geometry(x[r],src['coords']);oi=sorted(range(N),key=lambda i:ds[i]);order[r]=oi;sl[r]=L[r,oi]
        en=np.array([ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True]);falsegroups+=int(np.sum(en & ~np.concatenate([sl[r,1:]!=sl[r,:-1],[True]])));ends[r]=en;fix+=1
    cum=np.cumsum(ints[order],axis=1);arr=np.where(ends,cum/den*np.exp(-sl),0);best=np.argmax(arr,axis=1);M=np.max(arr,axis=1)
    # Smallest-volume maximizing complete batch, with exact fallback for close winners.
    runner=np.partition(arr,-2,axis=1)[:,-2] if N>1 else np.zeros(S)
    exact=np.flatnonzero((M-runner<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-1)<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-2)<=128*np.finfo(float).eps*np.maximum(M,1)))
    exactmeta={}
    for r in exact:
        capture,mm,_,oi,bj=exact_winner(x[r],src,lam);order[r]=oi;sl[r]=L[r,oi];best[r]=bj;M[r]=float(mm/lam)
        ds,B=binary_geometry(x[r],src['coords']);ends[r]=[ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True];exactmeta[r]=(capture,mm)
    cum=np.cumsum(ints[order],axis=1);Fstar=cum[np.arange(S),best]/den;count=best+1
    tau=np.exp(sl[np.arange(S),best]);rank=np.empty((S,N),int);np.put_along_axis(rank,order,np.broadcast_to(np.arange(N),(S,N)),axis=1);capture=rank<=best[:,None]
    weak=M>1;band=(M>1)&(M<=2)
    for r,(cp,mm) in exactmeta.items():
        capture[r]=cp;count[r]=int(cp.sum());Fstar[r]=float(F(int(ints[cp].sum()),den));tau[r]=Fstar[r]/float(mm/lam);weak[r]=mm>lam;band[r]=lam<mm<=2*lam
    single=count==1;majority=(~single)&(cum[np.arange(S),best]*2>den);residual=~single & ~majority
    inv=q**-1;weakscore=weak*inv;bandscore=band*M*inv;bandvolume=band*inv
    loads=band[:,None]*capture/(tau*q)[:,None];weightedloads=loads*a[None,:]
    assert np.max(abs(weightedloads.sum(axis=1)-bandscore))<2e-9
    assert np.max(weakscore)<=4*N*(1+1e-10) and np.max(bandscore)<=8*N*(1+1e-10)
    assert np.max(weightedloads)<=8*N*(1+1e-10)
    eff=Fstar**2/np.sum(capture*a[None,:]**2,axis=1)
    posterior=capture*a[None,:]/Fstar[:,None];entropy=-np.sum(posterior*np.log(np.maximum(posterior,1e-300)),axis=1)
    return dict(M=M,q=q,weak=weak,band=band,Fstar=Fstar,count=count,tau=tau,capture=capture,posterior=posterior,entropy=entropy,geometry_fallback=fix,falsegroups=falsegroups,exact_winner_rows=len(exact))

def stats(z,bound):
    return dict(mean=float(np.mean(z)),sample_SE=float(np.std(z,ddof=1)/math.sqrt(len(z))),maximum=float(np.max(z)),ideal_bound=float(bound),ideal_Hoeffding95_radius=float(bound)*math.sqrt(math.log(40)/(2*len(z))))

def separation(src):
    y=np.array(src['coords']);return float(min(np.max(abs(y[i]-y[j])) for i in range(len(y)) for j in range(i))) if len(y)>1 else 1.

def refine(macro,K,eps_ratio):
    eps=separation(macro)*float(eps_ratio);coords=[];p=[];labels=[]
    for i,(y,w) in enumerate(zip(macro['coords'],macro['weights'])):
        for j in range(K):
            t=(2*j+1-K)/K;offset=[eps*t*(1 if k%2==0 else -1) for k in range(macro['n'])]
            coords.append([float(v+u) for v,u in zip(y,offset)]);p.append(F(w)/K);labels.append(i)
    src=pack(coords,p,'micro_refinement');lookup={tuple(y):i for y,i in zip(coords,labels)};parent=[lookup[tuple(y)] for y in src['coords']]
    assert src['N']==macro['N']*K
    support=max((abs(F(z)-F(macro['coords'][i][k])) for y,i in zip(src['coords'],parent) for k,z in enumerate(y)),default=F(0))
    return src,parent,support

def density_guard(x,macro,lam):
    vols,a=actual_volumes(x,macro,lam);N=macro['N'];terms=[min(F(1),1/v**2)/(4*N) for v in vols]+[ai*min(F(1),1/v**2)/8 for ai,v in zip(a,vols)]+[min(F(1),(ai/v)**2)/8 for ai,v in zip(a,vols)];Q=10**80
    return F(sum(z.numerator*Q//z.denominator for z in terms),Q),F(sum(-(-z.numerator*Q//z.denominator) for z in terms),Q)


def batch(src,lam,S,seed):
    x,*_=draw_winner(src,lam,S,seed);ch=[winner_batch(x[j:j+128],src,lam) for j in range(0,S,128)];d={k:np.concatenate([z[k] for z in ch]) for k in ['M','q','weak','band','capture','Fstar','entropy']};y,_=arrays(src);d['x']=x;d['radius']=np.max(np.where(d['capture'],np.max(abs(x[:,None,:]-y[None,:,:]),axis=2),0),axis=1);d['r_exact']={};d['bandscore']=d['band']*d['M']/d['q'];d['source']=src
    return d


def exact_radius(d,i):
    if i not in d['r_exact']:
        ds,B=binary_geometry(d['x'][i],d['source']['coords']);d['r_exact'][i]=F(max(ds[j] for j in np.flatnonzero(d['capture'][i])),2**B)
    return d['r_exact'][i]


def gate(d,c):
    dist=np.max(abs(d['x']-np.array([float(z) for z in c])),axis=1);r=d['radius'];g=dist<=r
    near=abs(dist-r)<=128*np.finfo(float).eps*(dist+r+1)
    for i in np.flatnonzero(near):g[i]=max(abs(F(float(z))-ck) for z,ck in zip(d['x'][i],c))<=exact_radius(d,int(i))
    return g


def median_candidates(src,atom):
    candidates=[]
    for k in range(src['n']):
        marginal={}
        for i in atom:
            z=F(src['coords'][i][k]);marginal[z]=marginal.get(z,F(0))+F(src['weights'][i])
        total=sum(marginal.values());cum=F(0);lo=hi=None
        for z,w in sorted(marginal.items()):
            cum+=w
            if lo is None and 2*cum>=total:lo=z
            if 2*cum>total:hi=z;break
        candidates.append(sorted(set([lo,hi,(lo+hi)/2])))
    if math.prod(len(a) for a in candidates)<=128:return [tuple(v) for v in itertools.product(*candidates)]
    # Explicit restricted comparison in high dimension, not all median products.
    return list(dict.fromkeys(tuple(a[j] if j<len(a) else a[-1] for a in candidates) for j in [0,1,2]))


def score_packet(d,atom,rep,t):
    _,ints=integer_masses(d['source']);capt=(d['capture'][:,atom]*ints[atom]).sum(axis=1);total=(d['capture']*ints[None,:]).sum(axis=1);pi=capt/total
    return d['bandscore']*pi**(1+t)*gate(d,rep)


def median_best(d,atom,ts):
    cc=median_candidates(d['source'],atom);g=np.array([gate(d,c) for c in cc]);_,ints=integer_masses(d['source']);pi=(d['capture'][:,atom]*ints[atom]).sum(axis=1)/(d['capture']*ints[None,:]).sum(axis=1)
    out=[]
    for t in ts:
        val=g@(d['bandscore']*pi**(1+t))/len(d['x']);j=int(np.argmax(val));out.append((float(val[j]),cc[j]))
    return out,len(cc)


def arrangement_best(d,atom,ts,median=False):
    # Exact rational arrangement indices; floating positive weighted-depth sums.
    import bisect
    assert d['source']['n']<=2
    ind=np.flatnonzero(d['band']);n=d['source']['n'];src=d['source'];axes=[];lo=[];hi=[]
    for k in range(n):
        aa=min(F(src['coords'][i][k]) for i in atom);bb=max(F(src['coords'][i][k]) for i in atom)
        if median:
            mm=median_candidates(src,atom);aa=min(c[k] for c in mm);bb=max(c[k] for c in mm)
        faces={aa,bb}
        for i in ind:
            r=exact_radius(d,int(i));xx=F(float(d['x'][i,k]));faces.update(z for z in [xx-r,xx+r] if aa<=z<=bb)
        edges=sorted(faces);axes.append(sorted(set(edges+[(a+b)/2 for a,b in zip(edges,edges[1:])])))
        lo.append([bisect.bisect_left(axes[-1],F(float(d['x'][i,k]))-exact_radius(d,int(i))) for i in ind]);hi.append([bisect.bisect_right(axes[-1],F(float(d['x'][i,k]))+exact_radius(d,int(i))) for i in ind])
    _,ints=integer_masses(src);pi=(d['capture'][:,atom]*ints[atom]).sum(axis=1)/(d['capture']*ints[None,:]).sum(axis=1);result=[]
    for t in ts:
        weight=(d['bandscore']*pi**(1+t)/len(d['x']))[ind];shape=tuple(len(a)+1 for a in axes);A=np.zeros(shape)
        if n==1:
            np.add.at(A,lo[0],weight);np.add.at(A,hi[0],-weight);vals=np.cumsum(A)[:-1]
        else:
            np.add.at(A,(lo[0],lo[1]),weight);np.add.at(A,(hi[0],lo[1]),-weight);np.add.at(A,(lo[0],hi[1]),-weight);np.add.at(A,(hi[0],hi[1]),weight);vals=A.cumsum(axis=0).cumsum(axis=1)[:-1,:-1]
        idx=np.unravel_index(int(np.argmax(vals)),vals.shape);rep=tuple(axes[k][idx[k]] for k in range(n));value=float(score_packet(d,atom,rep,t).mean());assert abs(value-float(vals[idx]))<1e-9
        result.append((value,rep))
    return result,math.prod(len(a) for a in axes)


def set_partition_opt(d,ts,kind):
    N=d['source']['N'];assert N<=8;full=(1<<N)-1;packets={};candidates=0
    for mask in range(1,full+1):
        atom=[i for i in range(N) if mask>>i&1];best,num=arrangement_best(d,atom,ts,median=(kind=='median_arrangement')) if kind in ['arrangement','median_arrangement'] else median_best(d,atom,ts);packets[mask]=best;candidates+=num
    choices=[]
    for j,t in enumerate(ts):
        dp={0:(0.,[])}
        for mask in range(1,full+1):
            bit=mask&-mask;sub=mask;opt=(-1.,[])
            while sub:
                if sub&bit:
                    val=packets[sub][j][0]+dp[mask^sub][0]
                    if val>opt[0]:opt=(val,dp[mask^sub][1]+[sub])
                sub=(sub-1)&mask
            dp[mask]=opt
        val,blocks=dp[full];choices.append(dict(method='exhaustive_'+kind,t=t,training_objective=val,packets=[dict(indices=[i for i in range(N) if m>>i&1],representative=[str(z) for z in packets[m][j][1]]) for m in blocks],candidate_representative_count=candidates,scope='Floating optimum of finite training witness and stated finite representative candidates; no continuum optimality certificate.'))
    return choices


def median_tree(src):
    nodes=[]
    def build(atom,depth):
        nid=len(nodes);nodes.append(dict(indices=atom,children=[]));N=len(atom)
        if N>1:
            axis=depth%src['n'];ordered=sorted(atom,key=lambda i:(F(src['coords'][i][axis]),i));w=[F(src['weights'][i]) for i in ordered];total=sum(w);cum=F(0);cuts=[]
            for k in range(1,N):cum+=w[k-1];cuts.append((abs(2*cum-total),k))
            cut=min(cuts)[1];nodes[nid]['children']=[build(ordered[:cut],depth+1),build(ordered[cut:],depth+1)]
        return nid
    build(list(range(src['N'])),0);return nodes


def tree_opt(d,ts):
    nodes=median_tree(d['source']);best={i:median_best(d,z['indices'],ts)[0] for i,z in enumerate(nodes)};out=[]
    for j,t in enumerate(ts):
        def visit(i):
            val,rep=best[i][j];opt=(val,[i]);ch=nodes[i]['children']
            if ch:
                a,b=[visit(k) for k in ch]
                if a[0]+b[0]>val:opt=(a[0]+b[0],a[1]+b[1])
            return opt
        val,ids=visit(0);out.append(dict(method='optimized_median_tree_frontier',t=t,training_objective=val,packets=[dict(indices=nodes[i]['indices'],representative=[str(z) for z in best[i][j][1]]) for i in ids],scope='Floating optimum only among frontiers of the fixed source-only coordinate/mass-balanced tree and its stated median candidates.'))
    return out


def fixed_choice(d,blocks,ts,name):
    best=[median_best(d,atom,ts)[0] for atom in blocks];return [dict(method=name,t=t,training_objective=sum(v[j][0] for v in best),packets=[dict(indices=atom,representative=[str(z) for z in v[j][1]]) for atom,v in zip(blocks,best)]) for j,t in enumerate(ts)]


def validate(d,choice):
    N=d['source']['N'];den,ints=integer_masses(d['source']);total=(d['capture']*ints[None,:]).sum(axis=1);power=np.zeros(len(total));paid=np.zeros(len(total));hh=np.zeros(len(total));allindices=[];medianchecks=0;packetgates=[]
    for packet in choice['packets']:
        atom=packet['indices'];rep=tuple(F(z) for z in packet['representative']);allindices+=atom;pi=(d['capture'][:,atom]*ints[atom]).sum(axis=1)/total;g=gate(d,rep);packetgates.append(g);power+=g*pi**(1+choice['t']);paid+=g*pi;hh-=g*pi*np.log(np.maximum(pi,1e-300))
        if choice['method']!='exhaustive_arrangement':
            w=sum(F(d['source']['weights'][i]) for i in atom)
            for k,c in enumerate(rep):assert 2*sum((F(d['source']['weights'][i]) for i in atom if F(d['source']['coords'][i][k])<=c),F(0))>=w and 2*sum((F(d['source']['weights'][i]) for i in atom if F(d['source']['coords'][i][k])>=c),F(0))>=w;medianchecks+=1
    assert sorted(allindices)==list(range(N)) and np.all(power<=paid+1e-10) and np.all(paid<=1+1e-10)
    H=np.where(paid>0,hh/np.maximum(paid,1e-300)+np.log(np.maximum(paid,1e-300)),0);assert np.all(H>=-1e-10);H=np.maximum(H,0)
    z=d['bandscore'];B=8*N;traffic=stats(z*power,B);fee=1+math.log(2)+1/choice['t'];sigma=.5;h=math.sqrt(d['source']['n']);A=paid*((paid>=sigma)&(H<=h))
    return dict(_power=power,_paid=paid,_gates=packetgates,method=choice['method'],t=choice['t'],packets=choice['packets'],training_objective=choice['training_objective'],validation_power_traffic=traffic,analytic_general_power_bound=fee,validation_paid_traffic=stats(z*paid,B),validation_unpaid_traffic=stats(z*(1-paid),B),sigma=sigma,paid_entropy_cutoff=h,qualified_paid_traffic=stats(z*A,B),remaining_after_qualification=stats(z*(1-A),B),paid_entropy_traffic=stats(z*paid*H,B*math.log(max(1,N))),conditional_paid_entropy=float((z*paid)@H/(z@paid)) if z@paid else None,exact_median_coordinate_checks=medianchecks)


def rational_guard():
    # Exact optimization of a finite positive receiver witness, t=1.
    src=pack(list(itertools.product([-1.,1.],repeat=2)),[F(1,4)]*4,'exact_receiver_witness');lam=F(1,32)
    xs=[(F(s)*F(5,2),F(0)) for s in [-1,1]]+[(F(0),F(s)*F(5,2)) for s in [-1,1]]+list(itertools.product([F(-2),F(2)],repeat=2));witness=[]
    for x in xs:
        cp,M,band,_,_=exact_winner(x,src,lam);assert band
        r=max(max(abs(z-F(y)) for z,y in zip(x,src['coords'][i])) for i in np.flatnonzero(cp));witness.append((x,r,cp,M))
    values={};medianvalues={};bestrep={};N=4
    for mask in range(1,1<<N):
        atom=[i for i in range(N) if mask>>i&1];axes=[]
        for k in range(2):
            aa=min(F(src['coords'][i][k]) for i in atom);bb=max(F(src['coords'][i][k]) for i in atom);faces={aa,bb}
            for x,r,_,_ in witness:faces.update(z for z in [x[k]-r,x[k]+r] if aa<=z<=bb)
            ed=sorted(faces);axes.append(sorted(set(ed+[(a+b)/2 for a,b in zip(ed,ed[1:])])))
        candidates=list(itertools.product(*axes));val=[]
        for c in candidates:
            score=F(0)
            for x,r,cp,M in witness:
                if max(abs(a-b) for a,b in zip(x,c))<=r:
                    pi=F(sum(bool(cp[i]) for i in atom),int(cp.sum()));score+=M*pi**2/F(len(witness))
            val.append((score,c))
        values[mask],bestrep[mask]=max(val,key=lambda z:z[0]);mm=median_candidates(src,atom)
        aa=[min(c[k] for c in mm) for k in range(2)];bb=[max(c[k] for c in mm) for k in range(2)]
        medianvalues[mask]=max(score for score,c in val if all(a<=z<=b for a,z,b in zip(aa,c,bb)))
    def dp(vals):
        v={0:F(0)}
        for mask in range(1,1<<N):
            bit=mask&-mask;sub=mask;options=[]
            while sub:
                if sub&bit:options.append(vals[sub]+v[mask^sub])
                sub=(sub-1)&mask
            v[mask]=max(options)
        return v[(1<<N)-1]
    def partitions(items):
        if not items:yield [];return
        first=items[0]
        for rest in partitions(items[1:]):
            yield [[first]]+rest
            for j in range(len(rest)):yield rest[:j]+[[first]+rest[j]]+rest[j+1:]
    allp=list(partitions(list(range(N))));assert len(allp)==15
    brute=max(sum(values[sum(1<<i for i in block)] for block in p) for p in allp);opt=dp(values);med=dp(medianvalues);assert brute==opt and med<=opt
    return dict(source=src,lambda_value=str(lam),t='1',receiver_count=len(xs),receiver_weights='1/8',all_partitions_enumerated=len(allp),all_subsets=15,exact_unrestricted_arrangement_optimum=str(opt),exact_median_arrangement_optimum=str(med),exact_DP_equals_partition_enumeration=True,scope='Exact finite positive receiver witness only; not a quadrature certificate for a Lebesgue integral or an arbitrary-source bound.')


def point_guard(d,lam,choice,i,power,observedgates):
    src=d['source'];cp,M,band,_,_=exact_winner(d['x'][i],src,lam);assert np.array_equal(cp,d['capture'][i]) and band==bool(d['band'][i]);qlo,qhi=density_guard(d['x'][i],src,lam);r=exact_radius(d,i);a=[F(p) for p in src['weights']];capt=sum(a[j] for j in np.flatnonzero(cp));gates=[];pval=0.
    for pj,packet in enumerate(choice['packets']):
        c=tuple(F(z) for z in packet['representative']);g=max(abs(F(float(z))-ck) for z,ck in zip(d['x'][i],c))<=r;assert g==bool(observedgates[pj][i]);pi=sum((a[j] for j in packet['indices'] if cp[j]),F(0))/capt;gates.append(dict(gate=g,posterior=str(pi)));pval+=int(g)*float(pi)**(1+choice['t'])
    assert abs(pval-power[i])<1e-10
    return dict(receiver=d['x'][i].tolist(),M_lambda=str(M/lam),weak=M>lam,band=band,captured_indices=np.flatnonzero(cp).tolist(),packet_gates=gates,qcore_interval=[str(qlo),str(qhi)],q_relative_width=float((qhi-qlo)/qlo),M_float_relative=abs(d['M'][i]-float(M/lam))/float(M/lam),q_float_relative=float(max(abs(F(float(d['q'][i]))-qlo),abs(F(float(d['q'][i]))-qhi))/qlo),scope='Exact retained actual winner, original band, median/arrangement containment and outward rational full proposal density; no receiver-integral certificate.')


def cases(pilot=False):
    out=[]
    def add(label,src,lam,blocks=None):out.append(dict(label=label,source=src,lambda_value=str(lam),blocks=blocks))
    if pilot:
        add('pilot_grid6_n1',pack([[j/5] for j in range(6)],[1]*6,'grid'),F(1,4))
        add('pilot_vertices4_n2',pack(list(itertools.product([-1.,1.],repeat=2)),[1]*4,'vertices'),F(1,32))
        add('pilot_heterogeneous6_n3',structured_source('unequal_cloud',3,6,730006),F(1,64));return out
    add('grid8_n1',pack([[j/7] for j in range(8)],[1]*8,'grid'),F(1,4))
    add('vertices4_n2',pack(list(itertools.product([-1.,1.],repeat=2)),[1]*4,'vertices'),F(1,32))
    add('heterogeneous_two_scale6_n2',pack([[-2,-1],[-2,1],[0,-.5],[0,.5],[2,-1],[2,1]],[1,1,2,2,4,4],'two_scale'),F(1,32))
    add('heterogeneous6_n3',structured_source('unequal_cloud',3,6,730006),F(1,64))
    for spacing in [4,20]:
        m=8;src=pack([[g*spacing+j/(m-1)] for g in range(3) for j in range(m)],[1]*(3*m),'three_groups');add(f'three_groups_m8_spacing{spacing}',src,F(1,12),[list(range(g*m,(g+1)*m)) for g in range(3)])
    add('homogeneous_grid64_n1',pack([[j/63] for j in range(64)],[1]*64,'grid'),F(1,4))
    for n,kind,Ks in [(4,'binary',[1,4,16]),(8,'correlated',[1,8])]:
        macro=structured_source(kind,n,8,730400+n)
        for K in Ks:
            src,parents,support=refine(macro,K,F(1,4096));add(f'{kind}_macro8_n{n}_K{K}',src,F(1,2**(n+3)),[[j for j,p in enumerate(parents) if p==i] for i in range(macro['N'])])
    for n in [2,8,16]:
        for N in [8,32]:add(f'independent_n{n}_N{N}',structured_source('unequal_cloud',n,N,730000+100*n+N),F(1,2**(n+1)))
    return out


def main():
    start=time.perf_counter();ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args();sources=cases(args.pilot);rows=[];training=[];guards=[];draws=0
    for cid,case in enumerate(sources):
        src=case['source'];lam=F(case['lambda_value']);n=src['n'];ts=sorted(set([1.,1/math.sqrt(n),1/(1+math.sqrt(n)*math.log(n+2))]));trainseed=(730100 if args.pilot else 731000)+cid;S=128 if args.pilot else 256;d=batch(src,lam,S,trainseed);draws+=S
        choices=tree_opt(d,ts)+fixed_choice(d,[list(range(src['N']))],ts,'whole_source_median')+fixed_choice(d,[[i] for i in range(src['N'])],ts,'singleton_atoms')
        if case['blocks']:choices+=fixed_choice(d,case['blocks'],ts,'registered_macro_packets')
        if src['N']<=8:
            choices+=set_partition_opt(d,ts,'median')
            if n<=2:choices+=set_partition_opt(d,ts,'median_arrangement')+set_partition_opt(d,ts,'arrangement')
        training.append(dict(source_id=cid,seed=trainseed,samples=S,choices=choices,band_M=stats(d['bandscore'],8*src['N'])))
        seeds=[730900+cid] if args.pilot else [732000+10*cid,732001+10*cid];S=512 if args.pilot else 2048
        for seed in seeds:
            v=batch(src,lam,S,seed);draws+=S
            for choice in choices:
                row=validate(v,choice);power=row.pop('_power');row.pop('_paid');observedgates=row.pop('_gates');ids={int(np.argmax(v['bandscore']*power))}
                for th in [1,2]:
                    for above in [False,True]:
                        inds=np.flatnonzero((v['M']>th)==above)
                        if len(inds):ids.add(int(inds[np.argmin(abs(np.log(v['M'][inds]/th)))]))
                row.update(source_id=cid,seed=seed,samples=S,atomic_entropy_band_mean=float(v['bandscore']@v['entropy']/v['bandscore'].sum()) if v['bandscore'].sum() else None,band_M=stats(v['bandscore'],8*src['N']),weak=stats(v['weak']/v['q'],4*src['N']),guards=[point_guard(v,lam,choice,i,power,observedgates) for i in sorted(ids)]);guards.extend(row['guards']);rows.append(row)
        print(case['label'],'choices',len(choices),'rows',len(rows),'seconds',round(time.perf_counter()-start,3),flush=True)
    out=dict(status='PILOT' if args.pilot else 'FINAL',scope='Actual globally capped true winner band, source-only common whole-site partitions and fixed representatives; finite floating training optimization and independent fullspace validation.',sources=sources,training=training,rows=rows,exact_finite_witness_guard=rational_guard(),counts=dict(sources=len(sources),training_choices=sum(len(z['choices']) for z in training),validation_rows=len(rows),independent_receiver_draws=draws,retained_exact_point_checks=len(guards)),guard_summary=dict(max_M_relative=max(g['M_float_relative'] for g in guards),max_q_relative=max(g['q_float_relative'] for g in guards),max_q_interval_width=max(g['q_relative_width'] for g in guards)),environment=dict(numpy=np.__version__,python='3.12.14',BLAS_threads=1))
    Path(__file__).with_name('coverage_results.json').write_text(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n');print('DONE',out['counts'],'runtime_seconds',time.perf_counter()-start,flush=True)


if __name__=='__main__':main()
