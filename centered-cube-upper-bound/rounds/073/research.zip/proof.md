# Round73: common exponential-clock rounding and the geometric coverage gap

2026-10-11. **The arbitrary-input sqrt(n)n^{o(1)} weak bound remains UNPROVED.**
The retained unconditional general benchmark is O(n log n).
The previous interrupted goal turn made progress: it produced the coverage
proof, the final numerical experiment and an independently derived rounding
check. This continuation audited and finalized that same round, without
starting a new round or treating the interruption as a mathematical blocker.

## Proved contribution and exact missing condition

For one actual full-scale beta-band, let O_t be the best common source
partition's contained-representative (1+t)-power occupation, T the original
band occupation, and B_t its source-capacity packing relaxation. This round
proves

    O_t <= B_t <= (1+t) O_t,
    B_t <= min(T, [1+log beta+1/t] W).

Independent exponential clocks assign each physical source site to one
incident packet. The resulting source partition is shared by all receivers;
its cost and rounding factor do not depend on source count or tree depth.
Neither fractional source shares nor a random fixed partition improve the
single aggregate optimum; unrestricted representatives are essential to that
claim. Median constraints are optional sufficient gates, and need not survive
rounding. A finite exact dual identifies the remaining geometric condition:
all feasible source-price vectors must cost at least kappa_n T.

For beta=2 and t=1/sqrt(n), a uniform kappa_n>=n^{-o(1)} would yield
C_n<=2(1+log 2+sqrt(n))/kappa_n. The complete conditional band summation and
zero-loss atomic-to-L1 return are provided. The required lower bound on
kappa_n is NOT established. The LP has no uncontrolled integrality loss,
but its general geometric coverage remains the central missing theorem.

The soft-layer chapter retains a bounded endpoint-mask score. Its fixed-scale
fee I_n(delta)<=min(4,2n delta) is valid for arbitrary sources. However an actual
E2 kernel, genuine L1 cube source and finite side set in [1,2] force the
unrestricted dynamically selected strong energy on the original global cap
to be at least n/1944 at delta=1/n. This falsifies a dimension-free strong
shortcut, not the desired weak estimate or a fixed-ratio original band.
The repaired statement retains a signed selector carry and a separate
background-high branch; neither is paid at the target order here.

## Numerical evidence and reproducibility

The main experiment uses actual complete-distance-batch winners and a
normalized full-space Lebesgue proposal. Training chooses a common partition;
two independent held-out batches evaluate the frozen choice. It contains
18 sources, 217 training choices, 434 held-out method/exponent/seed rows,
and 78336 independent receiver draws (4608 training, 73728 held-out).
The 2126 retained rational point checks may repeat receivers across methods;
they are not 2126 independent cubature cells. A separate eight-receiver exact
witness enumerates all 15 source partitions, with optimum 13/288; this is not
a Lebesgue integral. Narrow microclusters and spaced groups expose failures
of singleton powers and of the tested fixed tree. Held-out examples show that
an optimum on training points need not outperform a simpler fixed partition
on fresh receivers. No dimensional exponent is fitted.

The parent independently replayed the final program in 12.45 seconds; its
JSON is byte-identical. Two author guards and the independent parent race
guard were also run by the parent. Complete code, exact outputs, runtime
receipt, source parameters, seeds and hashes are retained. Finite checks do
not prove a general coverage fraction. Formal ideal-law concentration bounds
and their finite-machine limitations are reported explicitly.

To reproduce, extract this archive to a temporary directory, preserve the
reference coverage_results.json, and run coverage_probe.py with Python
3.12.14 and NumPy 2.3.5. The script writes its output beside itself. Running
--pilot overwrites that adjacent filename with a pilot output; use a separate
temporary copy. Three supplemental standard-library guards are embedded below
as Python code blocks; extract each to its own script. The race guard writes
race_results.json; its reference result is retained in inventory.json.
The LaTeX document is saved as proof.tex.txt, without compilation or PDF.
All 64 canonical skill entries and 437 direct references are present and
unchanged against Round72. This availability check is distinct from the
specific mathematical hypothesis audits recorded in the chapters.



---

# Round 73: source-capacity packet coverage and a constant-loss common rounding

Status: the arbitrary-input centered-cube bound C_n <= sqrt(n) n^{o(1)} remains unproved. The new implication below removes an uncontrolled source-partition relaxation gap: a source-capacity packet LP is within a factor 1+t of the optimum *actual common partition* for contained-representative (1+t)-power traffic. It does not prove that either optimum covers a dimension-only proportion of the original winner occupation.

## 1. Actual input and paid score

Let mu=sum_{i=1}^N p_i delta_{y_i}, with p_i>0 and coincident sites merged, W=sum_i p_i. Q(x,L) is a closed centered cube of full side L. On the original all-scale band Omega={lambda<Mmu<=beta lambda}, lambda>0, beta>1, choose the smallest-volume complete-batch maximizing cube Q*(x). Let F(x)=mu(Q*(x)), V(x)=|Q*(x)|, and M(x)=F(x)/V(x). Source receivers are a null set. The finite distance-batch selection is Borel.

For t>0 write q=1+t. A common packet partition consists of finitely many fixed nonnegative source allocations z_{J,i} satisfying sum_J z_{J,i}=p_i, with arbitrary fixed representatives c_J. For captured mass a_J(x)=sum_{i:y_i in Q*(x)}z_{J,i}, define

    P_t(partition;x)=sum_J 1{c_J in Q*(x)} [a_J(x)/F(x)]^q,
    R_t(partition)=integral_Omega M(x) P_t(partition;x) dx.

Representatives are unrestricted. Coordinate medians are a sufficient gate from Round72, not a requirement of its payment theorem. In every common partition, 0<=P_t<=1. Original mu, band and winner remain fixed when selecting packets.

Round72's proved radial envelope gives

    R_t(partition) <= C_t W,  C_t=1+log beta+1/t.        (1.1)

More generally, for any single packet z<=p and any fixed representative c,

    b_t(z,c)=integral_Omega M 1{c in Q*}(a_z/F)^q dx
       <= C_t sum_i z_i.                             (1.2)

For completeness, the retained radial proof also checks that (1.2) allows arbitrary fixed fractional packets and arbitrary representatives. Put w=sum_i z_i>0 and v(x)=(2||x-c||_infinity)^n. On the representative gate, V>=v; also a_z<=w, F>lambda V and M<=beta lambda. Thus the integrand in (1.2) is bounded by each of beta lambda, w/v, and w^(1+t)/(lambda^t v^(1+t)). Use these three bounds respectively on v<=w/(beta lambda), w/(beta lambda)<v<=w/lambda, and v>w/lambda. The radial volume identity dx=dv after angular averaging gives exactly w+w log beta+w/t. The point c is null; w=0 contributes zero. This is the retained Round72 proof, included to make the relaxation's hypothesis check explicit.

This uses the same original band, not a private packet maximal set. The band has finite volume: all its capture cubes have side at most (W/lambda)^{1/n} and intersect the bounded finite source set. Its occupation T=integral_Omega M is consequently finite.

Prior audit: Round68 majority-node selection leaves global activation mass unpaid; Round71/72 paid posterior moments do not prove coverage. The earlier packet_coverage_feasibility_20261007.md refutes a different fixed-fullness/fixed-dominance contract for bounded-density restricted-window inputs. No such dominance or fullness hypothesis is imposed here. The new step is the exact optimization and its rounding comparison, not another claim that a power identity pays the full traffic.

## 2. Fractional common partitions have no aggregate advantage without median restrictions

Fix any finite collection of representatives c_1,...,c_K. The source allocations form the product of N simplices

    z_{J,i}>=0,  sum_J z_{J,i}=p_i.

For each receiver, the gates are fixed, and a_J is linear in the allocations. Since s->s^q is convex, R_t is convex on this compact allocation polytope. Every allocation is a convex combination of its extreme points: explicitly, assign site i independently to label J with probability z_{J,i}/p_i. The resulting whole-site assignment has mean allocation z. Jensen, first pointwise and then integrated, gives

    R_t(z,c) <= expected R_t(whole-site assignment,c).

Thus at least one deterministic whole-site partition with these representatives dominates the fractional partition in *aggregate* score. Empty labels can be deleted, leaving at most N nonempty packets. This is not a pointwise domination statement. It relies on unrestricted representatives: after changing packet membership, its old representative need not remain a median.

A source-only random distribution over common partitions also cannot increase one aggregate optimum, because its expected score is at most the largest deterministic score. Such randomization can still assist a simultaneous pointwise or minimax coverage problem; the preceding assertion concerns the single actual occupation functional R_t.

### Attainment for the full Lebesgue band

For a whole-site packet J, a representative can be clamped coordinatewise to the packet's bounding box without losing any positive captured gate. Indeed a coordinate interval of Q* containing both the old representative coordinate and a captured packet site contains the projection of that coordinate onto the packet's coordinate range. Hence whenever a_J>0 and c in Q*, the clamped c remains in Q*.

Within this compact bounding box, the score is upper semicontinuous in c. For c_k->c, closedness of Q*(x) gives limsup 1{c_k in Q*}<=1{c in Q*}; multiply by the fixed nonnegative captured factor and use reverse Fatou with integrable upper bound M. Therefore each packet has a maximizing representative. There are finitely many whole-site set partitions. The supremum over all finite fractional common partitions and all arbitrary representatives equals a maximum over whole-site partitions, with at most N nonempty packets and compact representatives. This statement has no source-count-independent algorithmic complexity claim.

## 3. The source-capacity relaxation and its exact finite LP

For each nonempty subset J of {1,...,N}, let mu_J=sum_{i in J}p_i delta_{y_i}, and set

    b_J = max_c b_t(mu_J,c).

The maximum exists by Section 2. Choose one fixed maximizing c_J. The *common partition optimum* is

    O_t = max_{set partitions P} sum_{J in P} b_J.

Define the source-capacity packing LP

    B_t = max sum_{nonempty J} alpha_J b_J
          subject to alpha_J>=0,
          sum_{J contains i}alpha_J<=1  for every i.   (3.1)

There are 2^N-1 columns and N capacity constraints. Coefficients are finite actual spatial integrals, not numerical estimates. Every nonempty column has alpha_J<=1. Leftover capacity may be filled by singleton columns without decreasing the objective, so its optimum can also be realized with equality capacities. This LP does not directly encode a common partition: overlapping packets receive fractional coefficients, rather than fractional packet shares raised to the power q.

It nevertheless has the paid source budget

    B_t <= C_t sum_J alpha_J sum_{i in J}p_i
        <= C_t W.                                    (3.2)

All mass is charged once in the capacity sum. No new packet good sets appear. Pointwise the relaxed score is at most one: sum_J alpha_J e_J(a_J/F)^q <= sum_J alpha_J a_J/F <= 1, by the source capacities. Thus B_t<=T as well. At the endpoint q=1, singleton representatives y_i give O_0=B_0=T; the actual coverage deficit is a q>1 issue.

A finite LP optimum can be chosen with at most N positive columns. Choose an optimum with minimal positive support. If its incidence columns were dependent, move its coefficients along a dependence while preserving all source loads. One sign would improve the objective unless the objective derivative were zero; in that zero case move until a coefficient vanishes. Both contradict optimality or minimal support. This is a finite optimization reduction, not a dimension-only bound on the number of source labels.

### Arbitrary fractional packet columns add no value to this relaxation

Suppose a relaxed column has allocation 0<=z_i<=p_i and fixed c. Choose a random subset J by independently including site i with probability z_i/p_i. Its full-site allocation has mean z. Convexity gives

    b_t(z,c) <= sum_J theta_J b_t(mu_J,c),
    z_i = sum_J theta_J p_i 1{i in J},

where theta_J is the subset distribution (the empty subset has zero score). Replacing this column by these weighted whole-site columns preserves its source consumption and improves its score. Applying this to each finite relaxed family proves that (3.1) already captures all finite weighted fractional packet columns. Countable families with finite source capacities follow by monotone truncation and the finite LP upper bound. This is a statement about weighted packet packing; it does not identify that relaxation with a fractional common partition.

## 4. Shared exponential clocks round the relaxation with factor 1+t

Take any feasible alpha in (3.1), delete zero coefficients, and independently sample T_J~Exp(rate alpha_J), once for each remaining column. Assign each source site i to the incident column whose clock is earliest. A site belonging to no positive column is placed in its own singleton packet. All ties have probability zero. These assignments define a source-only common partition, with source mass exactly conserved in every realization. Retain c_J as the representative of each nonempty assigned packet; it need not be its new median. Original Q*(x), M and Omega do not change.

Fix J and condition on T_J=s. A site i in J is assigned to J with probability

    exp[-s sum_{K not J:i in K}alpha_K]
       >= exp[-(1-alpha_J)s].                          (4.1)

The random assignments of different sites are generally dependent. No independence between sites is required. At a fixed original receiver let A_J(x) be the captured mass assigned to J. From (4.1),

    expected[A_J(x) | T_J=s]
       >= exp[-(1-alpha_J)s] mu_J(Q*(x)).

Conditional Jensen then gives

    expected[A_J(x)^q | T_J=s]
       >= exp[-q(1-alpha_J)s] mu_J(Q*(x))^q.

Integrating against alpha_J exp(-alpha_J s)ds yields the sharper bound

    expected[A_J(x)^q]
       >= alpha_J/[q-(q-1)alpha_J] mu_J(Q*(x))^q
       >= (alpha_J/q) mu_J(Q*(x))^q.                  (4.2)

The gate 1{c_J in Q*(x)} is deterministic under these clocks. Thus the pointwise common-partition power traffic satisfies

    expected P_t(rounded;x)
       >= sum_J alpha_J/[q-(q-1)alpha_J]
                 1{c_J in Q*}[mu_J(Q*)/F]^q
       >= (1/q) sum_J alpha_J
                 1{c_J in Q*}[mu_J(Q*)/F]^q.         (4.3)

Nonnegative Tonelli and the deterministic aggregate optimum give

    O_t <= B_t <= (1+t) O_t.                          (4.4)

The first inequality embeds ordinary partitions into the LP; the second follows from (4.3) and existence of a realization with score at least its mean. This comparison is independent of n, N, refinement and depth. It improves a Bernoulli-selection/unique-incidence rounding bound, which would give only the smaller constant max_delta delta(1-delta)^q. The exponential-clock proof is a finite shared-source construction, not an arrival filtration or martingale claim.

## 5. Exact dual and finite receiver witness reduction

The finite LP dual is

    B_t = min sum_i u_i
          subject to u_i>=0,
          sum_{i in J}u_i>=b_J  for every nonempty J.  (5.1)

Equivalently u_i=p_i pi_i are source prices, and the cost is sum_i p_i pi_i. Weak duality follows by multiplying the subset inequalities by alpha_J and summing capacities. Equality and attainment are finite-dimensional facts, proved here to avoid importing an infinite-dimensional minimax claim.

Let A_J be the 0/1 incidence vector of J and consider the finitely generated cone C generated by (A_J,b_J), all (e_i,0), and (0,-1). It consists of (A alpha+s,b dot alpha-r) with alpha,s,r>=0. This cone is closed: a nonnegative combination can be reduced to linearly independent active generators by removing a linear dependence until a coefficient vanishes; among finitely many independent subfamilies, pass to one fixed subfamily along a converging sequence. Its independent coefficients then converge and remain nonnegative. For z>B_t, the point (1,...,1,z) is outside C. Strict finite-dimensional separation from this closed convex cone yields a functional (u,-v) nonnegative on C and negative at that point. The generators force u>=0,v>=0; v=0 cannot give negativity on (1,...,1,z), so v>0. Normalize v=1 to obtain a dual feasible u with sum_i u_i<z. Let z decrease to B_t. The feasible u are bounded after imposing sum_i u_i<=B_t+1, hence a convergent subsequence attains equality. This establishes (5.1).

The obvious feasible prices u_i=C_t p_i recover only (3.2). A genuine coverage obstruction for a given input would require smaller prices satisfying *all* subset inequalities, not a few sampled packet columns.

### Finite receiver witnesses

For fixed actual-band receivers x_l and nonnegative weights nu_l, define

    b_J^fin = max_c sum_l nu_l 1{c in Q*(x_l)}
                        [mu_J(Q*(x_l))/F(x_l)]^q.

Here nu_l may already include M(x_l) times a prescribed quadrature weight. The finite objective is not a certified spatial integral unless separate cubature/error bounds are supplied.

For these witnesses, representatives reduce exactly to a finite product arrangement. In each coordinate take all source bounding-box endpoints and all selected winner-cube faces inside the source bounding box. Include each endpoint and one midpoint of every consecutive open interval. Gates are constant on each product cell; endpoints remain separate because cubes are closed. A positive captured gate can first be clamped to the relevant packet bounding box, so this finite list attains every subset's maximum. It need not consist of source coordinates or coordinate medians. Median-restricted optimization also has a finite arrangement if all source coordinate values are added, but it is a different constrained problem.

Fractional-to-integral reduction does not hold under frozen median requirements by the same argument. For example, three equal sites (0,0),(2,1),(1,3), assigned with half mass to each incident pair, give three valid pair-midpoint median packets. With just those three frozen midpoints, no whole-site partition exists with each representative still a median: singleton representatives would need their own site, and the whole-input unique median is (1,1), different from all three pair midpoints. Rounding remains legitimate for the unrestricted R72 theorem because median status was never required for payment.

## 6. What is paid, and what remains genuinely geometric

Write T=integral_Omega M. For any t>0, a source-uniform lower bound

    B_t >= kappa_n T                                  (6.1)

would, directly from (3.2), give

    T <= [1+log beta+1/t] W/kappa_n.                   (6.2)

By (4.4), (6.1) is equivalent up to factor 1+t to the best unrestricted common-partition power coverage. For t<=1 this factor is at most 2, and for t about 1/sqrt(n) it approaches 1. Thus the relaxation has no hidden source reweighting, atom-count, or tree-depth loss. The remaining task is to prove (6.1) with [1+log beta+1/t]/kappa_n <= sqrt(n)n^{o(1)}. No such bound is proved here. Equivalently, every dual feasible source-price vector in (5.1) must have sum_i u_i>=kappa_n T. With t=1/sqrt(n), the paid fee is 1+log beta+sqrt(n), and kappa_n>=n^{-o(1)} would be sufficient.

The score uses powers, not just contained mass. Singleton packets have contained mass fraction one at every winner, but their power traffic can be arbitrarily small under microscopic refinement. The exact optimization can merge their common source before measuring the power, and no arbitrary refinement cost appears in the rounding factor. This observation does not ensure that one common partition merges all receiver-dependent cooperative groups effectively.

Fixed random partitions cannot improve a single aggregate optimum; shared-clock rounding still supplies a pointwise comparison to a feasible LP packing and can matter for simultaneous requirements. Any finite witness optimization or dual certificate must retain its finite scope. A dual that makes B_t/T small is a failure certificate for this coverage route on that input, not automatically a weak-type lower bound. A large finite B_t cannot prove full Lebesgue coverage. These are the exact paid/unpaid boundaries.

### Conditional return to the full weak bound

If (6.1) holds uniformly for every finite positive atomic source and every lambda, put D_n=C_t/kappa_n. The disjoint bands {beta^k lambda<M<=beta^{k+1}lambda}, k>=0, cover {M>lambda} off the null source set. Each has occupation at most D_n W, so

    lambda |{M>lambda}|
      <= sum_{k>=0} beta^{-k} integral_{band k} M
      <= [beta/(beta-1)] D_n W.                       (6.3)

This uses the same physical source at each threshold; the geometrically decreasing receiver coefficient is what pays the summation. For beta=2,t=1/sqrt(n), the conditional weak constant is at most 2[1+log 2+sqrt(n)]/kappa_n.

The retained zero-loss weak atomic return also has a short direct proof. For compactly supported f>=0 in L1, move each cell's source mass to one representative using finite grids of diameter epsilon_k->0, obtaining finite atoms of the same mass. Every original Q(x,L) maps into Q(x,L+2epsilon_k), so Mmu_k(x)>=mu(Q(x,L))/(L+2epsilon_k)^n. Hence Mf<=liminf_k Mmu_k pointwise. Strict-level inclusion and Fatou transfer the same weak constant. Finally truncate an arbitrary positive L1 input to growing bounded supports and use monotone convergence of its maximal function. No cap-energy approximation statement is involved.

## 7. Current skills and reproducible guard

Current canonical E03, D04, M02 and L03 entrances and their method/interface/provenance were reread. E03 is used only to enforce source flow and distinguish common assignments from per-receiver selection; no tree Bellman theorem is imported. D04 is used only for finite captured shares and convexity, not infinite entropy differences. M02 permits the finite closed-cone separation in Section 5; closure and normalization are proved explicitly. L03 separates exact rational checks from high-precision evidence. No external paper is cited without reading its applicable theorem; no external theorem is needed here.

The embedded standard-library guard was executed using exact fractions.Fraction arithmetic for q=2. It enumerates actual complete-batch band winners, finite closed-cube face arrangements, all small set partitions, exact rational LP vertices and clock-order probabilities. It checks the sharper pointwise Jensen rounding bound, median-restriction example, fractional source-box reduction, and finite geometric band sums. The analytic proofs apply to every q>1. These finite guards test the derivations, not (6.1), and certify no Lebesgue cubature.

```python
from fractions import Fraction as F
from itertools import combinations, product, permutations
import json

counts=dict(winners=0, arrangement_scores=0, lp_bases=0,
            partitions=0, race_orders=0, pointwise_race=0,
            fractional_box=0, median_assignments=0)

def dist(x,y): return max(abs(a-b) for a,b in zip(x,y))

def winner(points,weights,x):
    batches={}
    for i,y in enumerate(points):
        r=dist(x,y); assert r>0
        batches.setdefault(r,[]).append(i)
    best=F(-1); total=F(0); captured=[]; chosen=None
    for r,indices in sorted(batches.items()):
        total+=sum((weights[i] for i in indices),F(0)); captured+=indices
        M=total/(2*r)**len(x)
        if M>best: best=M; chosen=(r,total,tuple(captured))
    return best,chosen

def solve(A,b):
    n=len(b); R=[list(map(F,row))+[F(v)] for row,v in zip(A,b)]
    for k in range(n):
        pivot=next((i for i in range(k,n) if R[i][k]),None)
        if pivot is None: return None
        R[k],R[pivot]=R[pivot],R[k]; a=R[k][k]
        R[k]=[v/a for v in R[k]]
        for i in range(n):
            if i!=k:
                a=R[i][k]; R[i]=[u-a*v for u,v in zip(R[i],R[k])]
    return [row[-1] for row in R]

def partitions(n):
    def rec(i,blocks):
        if i==n:
            yield tuple(tuple(b) for b in blocks); return
        for j in range(len(blocks)):
            new=[list(b) for b in blocks]; new[j].append(i)
            yield from rec(i+1,new)
        yield from rec(i+1,blocks+[[i]])
    yield from rec(0,[])

def arrangements(points,rows):
    n=len(points[0]); grids=[]
    for k in range(n):
        lo=min(y[k] for y in points); hi=max(y[k] for y in points)
        endpoints={lo,hi}
        for x,r,_,_,_ in rows:
            endpoints.update(v for v in [x[k]-r,x[k]+r] if lo<=v<=hi)
        endpoints=sorted(endpoints)
        grids.append(sorted(set(endpoints+[(a+b)/2 for a,b in zip(endpoints,endpoints[1:])])))
    return list(product(*grids))

def score_at(J,c,weights,rows):
    answer=[]
    for x,r,Fstar,cap,nu in rows:
        a=sum((weights[i] for i in J if i in cap),F(0))
        answer.append(nu*(a/Fstar)**2 if dist(x,c)<=r else F(0))
    return answer

def exact_lp(subsets,b,N):
    best=F(0); alpha={}; dual=None; dualcost=None
    for k in range(1,N+1):
        for cols in combinations(range(len(subsets)),k):
            for active in combinations(range(N),k):
                A=[[F(i in subsets[j]) for j in cols] for i in active]
                a=solve(A,[F(1)]*k)
                if a is None: continue
                counts['lp_bases']+=1
                if min(a)<0: continue
                loads=[sum(a[z] for z,j in enumerate(cols) if i in subsets[j]) for i in range(N)]
                if max(loads)>1: continue
                val=sum((a[z]*b[j] for z,j in enumerate(cols)),F(0))
                if val>best:
                    best=val; alpha={j:a[z] for z,j in enumerate(cols) if a[z]}
                u0=solve(list(map(list,zip(*A))),[b[j] for j in cols])
                u=[F(0)]*N
                for i,v in zip(active,u0): u[i]=v
                if min(u)>=0 and all(sum((u[i] for i in J),F(0))>=bj for J,bj in zip(subsets,b)):
                    if dualcost is None or sum(u)<dualcost:
                        dual=u; dualcost=sum(u)
    assert dualcost==best
    return best,alpha,dual

cases=[
    ([(F(0),),(F(1),),(F(2),)], [F(1,3)]*3,
     [(F(z,4),) for z in [-6,-2,1,3,6,10]], F(1,4)),
    ([(F(-1),F(-1)),(F(1),F(-1)),(F(-1),F(1)),(F(1),F(1))],
     [F(1,4)]*4,
     [(F(a,2),F(b,2)) for a,b in product([-1,0,1],repeat=2)],F(3,16)),
    ([(F(0),F(0)),(F(2),F(1)),(F(1),F(3))],[F(1,3)]*3,
     [(F(a,2),F(b,2)) for a,b in [(1,1),(1,3),(3,1),(3,3),(5,5),(-2,1)]],F(1,16))]
results=[]; frames=[]
for points,weights,queries,lam in cases:
    N=len(points); rows=[]
    for x in queries:
        M,(r,Fstar,cap)=winner(points,weights,x); counts['winners']+=1
        if lam<M<=2*lam:
            rows.append((x,r,Fstar,set(cap),M)) # finite unit cubature weights
    assert rows
    reps=arrangements(points,rows)
    subsets=[tuple(i for i in range(N) if mask>>i&1) for mask in range(1,1<<N)]
    b=[]; centers=[]; traces=[]
    for J in subsets:
        best=None; cbest=None; trace=None
        for c in reps:
            values=score_at(J,c,weights,rows); val=sum(values,F(0))
            counts['arrangement_scores']+=1
            if best is None or val>best: best=val; cbest=c; trace=values
        b.append(best); centers.append(cbest); traces.append(trace)
    B,alpha,u=exact_lp(subsets,b,N)
    lookup={J:j for j,J in enumerate(subsets)}
    O=F(0)
    for P in partitions(N):
        O=max(O,sum((b[lookup[J]] for J in P),F(0))); counts['partitions']+=1
    assert O<=B<=2*O
    # Exact exponential race: permutation probability is product(rate/remaining rates).
    active=list(alpha); expected=F(0); totalprob=F(0)
    percol={j:[F(0)]*len(rows) for j in active}
    for order in permutations(active):
        prob=F(1); remaining=sum(alpha.values(),F(0))
        for j in order: prob*=alpha[j]/remaining; remaining-=alpha[j]
        totalprob+=prob; assigned={j:[] for j in active}; owners=set()
        for j in order:
            for i in subsets[j]:
                if i not in owners: assigned[j].append(i); owners.add(i)
        realized=F(0)
        for j in active:
            values=score_at(assigned[j],centers[j],weights,rows)
            for l,val in enumerate(values): percol[j][l]+=prob*val
            realized+=sum(values,F(0))
        for i in set(range(N))-owners:
            realized+=sum(score_at([i],points[i],weights,rows),F(0))
        expected+=prob*realized; counts['race_orders']+=1
    assert totalprob==1 and expected<=O and expected>=B/2
    for j in active:
        for got,original in zip(percol[j],traces[j]):
            assert got>=alpha[j]/(2-alpha[j])*original
            counts['pointwise_race']+=1
    # Source-box convex reduction for a genuinely fractional packet and fixed rep.
    ratios=[F(i+1,N+2) for i in range(N)]
    z=[p*r for p,r in zip(weights,ratios)]
    c=tuple(sum(y[k] for y in points)/N for k in range(len(points[0])))
    raw=F(0)
    for x,r,Fstar,cap,nu in rows:
        a=sum((z[i] for i in cap),F(0))
        raw+=nu*(a/Fstar)**2 if dist(x,c)<=r else F(0)
    mixed=F(0)
    for mask in range(1<<N):
        J=[i for i in range(N) if mask>>i&1]
        prob=F(1)
        for i in range(N): prob*=ratios[i] if i in J else 1-ratios[i]
        mixed+=prob*sum(score_at(J,c,weights,rows),F(0))
        counts['fractional_box']+=1
    assert raw<=mixed
    frames.append((points,weights,rows,subsets,b,centers,traces,O))
    results.append(dict(n=len(points[0]),N=N,witnesses=len(rows),
                        partition=str(O),packing=str(B),dual=str(sum(u)),
                        race_expectation=str(expected)))

# Additional overlap pressure: fractional feasible families need not be LP optima.
for points,weights,rows,subsets,b,centers,traces,O in frames:
    N=len(points); index={J:j for j,J in enumerate(subsets)}
    families=[{index[tuple(range(N))]:F(1,4),
               **{index[(i,)]:F(3,4) for i in range(N)}},
              {index[J]:F(1,N-1) for J in combinations(range(N),2)}]
    for alpha in families:
        assert all(sum((a for j,a in alpha.items() if i in subsets[j]),F(0))<=1
                   for i in range(N))
        percol={j:[F(0)]*len(rows) for j in alpha}; expected=F(0); totalprob=F(0)
        for order in permutations(alpha):
            prob=F(1); remaining=sum(alpha.values(),F(0)); owners=set()
            assigned={j:[] for j in alpha}
            for j in order:
                prob*=alpha[j]/remaining; remaining-=alpha[j]
                for i in subsets[j]:
                    if i not in owners: owners.add(i); assigned[j].append(i)
            totalprob+=prob; realized=F(0)
            for j in alpha:
                values=score_at(assigned[j],centers[j],weights,rows)
                for l,v in enumerate(values): percol[j][l]+=prob*v
                realized+=sum(values,F(0))
            expected+=prob*realized; counts['race_orders']+=1
        assert totalprob==1 and expected<=O
        for j,a in alpha.items():
            for got,original in zip(percol[j],traces[j]):
                assert got>=a/(2-a)*original
                counts['pointwise_race']+=1

# Frozen median restriction: fractional triangle packets valid, no integral assignment.
points=[(F(0),F(0)),(F(2),F(1)),(F(1),F(3))]
pairs=[(0,1),(0,2),(1,2)]
centers=[tuple((points[i][k]+points[j][k])/2 for k in range(2)) for i,j in pairs]
def ismedian(J,c):
    if not J: return True
    for k in range(2):
        if 2*sum(points[i][k]<c[k] for i in J)>len(J): return False
        if 2*sum(points[i][k]>c[k] for i in J)>len(J): return False
    return True
assert all(ismedian(J,c) for J,c in zip(pairs,centers))
valid=0
for assignment in product(range(3),repeat=3):
    P=[[i for i,j in enumerate(assignment) if j==k] for k in range(3)]
    valid+=all(ismedian(J,c) for J,c in zip(P,centers))
    counts['median_assignments']+=1
assert valid==0
# Geometric band summation constants, exact finite threshold decomposition.
for beta in [F(3,2),F(2),F(3)]:
    for K in [1,2,4,8,16]:
        assert sum((beta**(-k) for k in range(K)),F(0))==beta/(beta-1)*(1-beta**(-K))
print(json.dumps(dict(status='PASS',scope='finite actual-band witnesses; no Lebesgue cubature claim',
                      counts=counts,cases=results),indent=2))
```

## 8. Final independent audit and actual guard output

The finalizer reread the entire saved mathematical text and independently checked the fixed-input convex reduction, compact representative attainment, source-capacity payment, shared-clock conditional Jensen argument, closed-cone duality, finite closed-face witness reduction, all-beta band summation, and zero-loss atomic return. No theorem scope was expanded. The resulting proved statements are O_t<=B_t<=(1+t)O_t and B_t<=min(T,[1+log beta+1/t]W); the missing dimension-uniform lower bound B_t>=kappa_n T remains unproved.

Canonical M02 and L03 entry, method, cube interface, and provenance were reread during this final audit. M02 is used only within its finite-dimensional nonempty closed-convex-set scope; the cone closure and dual normalization are explicit. L03 is used for exact rational primal/dual and residual checks. No floating interval API or outward-rounding library is claimed to have been tested. E03 and D04 retain only the limited roles recorded in Section 7.

All three finite LP objectives equal both their certified dual costs and optimal-family race expectations: 2/3, 5/4, and 71/324. Additional nonoptimal overlapping families test genuine fractional overlap. The guard also checks 15 exact finite geometric-series identities (three beta values and five truncations); these are separate from the eight counters printed below. The full-band and atomic-return arguments are analytic proofs above, rather than claims inferred from these samples.

The following is the actual stdout of the embedded guard, executed successfully without third-party modules:

```json
{
  "status": "PASS",
  "scope": "finite actual-band witnesses; no Lebesgue cubature claim",
  "counts": {
    "winners": 21,
    "arrangement_scores": 641,
    "lp_bases": 2342,
    "partitions": 25,
    "race_orders": 905,
    "pointwise_race": 105,
    "fractional_box": 32,
    "median_assignments": 27
  },
  "cases": [
    {
      "n": 1,
      "N": 3,
      "witnesses": 2,
      "partition": "2/3",
      "packing": "2/3",
      "dual": "2/3",
      "race_expectation": "2/3"
    },
    {
      "n": 2,
      "N": 4,
      "witnesses": 5,
      "partition": "5/4",
      "packing": "5/4",
      "dual": "5/4",
      "race_expectation": "5/4"
    },
    {
      "n": 2,
      "N": 3,
      "witnesses": 3,
      "partition": "71/324",
      "packing": "71/324",
      "dual": "71/324",
      "race_expectation": "71/324"
    }
  ]
}
```

Guard source SHA-256 (exact characters between the Python fence markers, without an appended newline): `cb11aeac96e9f43267b2fe0fc4ee38a0dec731ff3ee5d82e343221bf44b8db04`.

Actual stdout SHA-256 (including its final newline): `fd1e80155db9749afd98baf5b5e60910fa4da7806f235f43bceabe24fb2f93ab`.

Freeze scope: this Markdown and the matching LaTeX fragment contain the finalized proof and reproducibility record. No compilation or PDF was requested. File SHA-256 values are reported to the parent for replay after the final write; self-referential file hashes are not embedded in the files.


---

# Round73: bounded soft-layer contrast and the unpaid scale-selection carry

Status: a fixed-scale information budget, an analytic falsification of its dimension-free dynamic strong extension, and a correct stopped/major-subset ledger are proved below. The actual E2 smoothing kernel and a genuine L1 input are retained in the falsification. No general sqrt(n)n^{o(1)} weak upper bound, dynamic soft-layer weak theorem, or paid selector-carry theorem is claimed.

## 1. Actual endpoint and history audit

The objective asks for a finite-physical-window weak estimate for

    T_(s,L) f=f*[(psi_(delta/2)^tensor n)_L-(psi_delta^tensor n)_L],
    delta=2^(-s),  L in an arbitrary finite J subset [1,2].

Here h=1_[-1/2,1/2], w(x)=integral_0^1 exp(-|x|/t)dt, phi=h*w, and psi_delta=(1-delta)h+delta phi. Both h and w have mass one. The scale variable here is the full physical side L, not volume time. No claim below follows from the length of the parameter interval alone.

The finite telescoping identity is

    phi^tensor n + sum_(s=0)^S [psi_(2^(-s-1))^tensor n-psi_(2^(-s))^tensor n]
       =psi_(2^(-S-1))^tensor n.

The right side tends to h^tensor n in L1, since its mixture puts mass (1-delta)^n on the hard component and

    ||psi_delta^tensor n-h^tensor n||_1<=2[1-(1-delta)^n]<=2n delta.

Convolution and dilation preserve the identity. The finite mask expansion, with bounded kernels, also gives pointwise convergence for every finite positive measure, and for an L1 source after choosing its ordinary convolution representatives. For finite J the same null set can be used at all its sides. This retained telescoping does not establish the required maximal estimate.

Prior records read for this task include the actual E2 softness Markov-divisibility proof; the signed-normal posterior identity; logistic_chain_actual_interface_20261007.md; posterior_only_weak_obstruction_20261007.md; bernoulli_weak_endpoint_20261007.md; and gamma_occupancy_winner_bridge_20261007.md. Their source-conservation and posterior identities are retained, not registered again as new endpoint progress. The fixed-scale Cauchy calculation below is likewise a basic tool, not a claimed new general cube theorem. The scope-specific new obstruction is Section 3: even a bounded finite-endpoint score, on the actual original global cap, does not acquire a dimension-free strong physical-selector budget. Unlike a free Bernstein-coefficient fixture, this obstruction uses the actual E2 kernel and a genuine L1 source. Section 4 records the precise correction.

## 2. Bounded endpoint score with an exact source-mass budget

This section works for every positive probability density phi and therefore applies to the actual kernel. For a mask m in {0,1}^n define the mass-one component

    k_m(z)=product_i [h(z_i) if m_i=0, phi(z_i) if m_i=1].

Let alpha_m be the Bernoulli(delta/2) product mask law and beta_m the Bernoulli(delta) law. Set q_m=(alpha_m+beta_m)/2 and zeta_m=(alpha_m-beta_m)/q_m when q_m>0. Zero q terms are omitted. Then |zeta_m|<=2 and sum_m q_m zeta_m=0. These are latent mask probabilities independent of the source. The ACTUAL posterior after receiver selection is generally neither centered nor product.

For any real or complex finite source nu, let mu=|nu|, W=mu(R^n), and define

    F_L=mu*sum_m q_m(k_m)_L,
    C_L=mu*J_(n,delta,L),
    J_(n,delta)=sum_m q_m zeta_m^2 k_m,
    I_n(delta)=sum_m q_m zeta_m^2.

For each fixed L, Tonelli makes F_L and C_L finite almost everywhere; all pointwise statements below are understood on that common full-measure set. For a finite scale family, intersect its finitely many full-measure sets. The layer contrast is T_L nu=sum_m q_m zeta_m [nu*(k_m)_L]. Cauchy in the SAME joint measure mu(dy) q_m(k_m)_L(x-y) gives

    |T_L nu(x)|^2/F_L(x)<=C_L(x),                              (2.1)

with quotient zero when F_L=0. This permits arbitrary source-coordinate dependence and preserves the entire source. Since every component kernel has mass one,

    integral C_L dx=I_n(delta)W,
    integral |T_L nu|^2/F_L dx<=I_n(delta)W.                   (2.2)

The exact scalar fee is

    I_n(delta)=2 sum_(k=0)^n (a_k-b_k)^2/(a_k+b_k),
    a_k=binom(n,k)(delta/2)^k(1-delta/2)^(n-k),
    b_k=binom(n,k)delta^k(1-delta)^(n-k).                      (2.3)

Use the convention 0^0=1 and omit zero denominators. Since (a-b)^2/(a+b)<=|a-b|, I<=4 TV(alpha,beta). Couple the endpoint masks by the same independent coordinate uniforms; they differ with probability 1-(1-delta/2)^n. Hence

    I_n(delta)<=4[1-(1-delta/2)^n]<=min(4,2n delta).           (2.4)

This bounded endpoint score avoids the exponential chi-square fee obtained by comparing directly under a single endpoint law. It does not turn a receiver-dependent scale into an independent draw. Randomizing one common L independently of receivers keeps (2.2), by probability averaging. Taking its supremum over L does not.

For a fixed side L, the contrast event with F_L<=B lambda is paid:

    lambda |{|T_L nu|>lambda, F_L<=B lambda}|
       <=B I_n(delta)W.                                    (2.5)

The background-high branch and the variable-scale selection remain separate. No bound on F_L by an ORIGINAL cube cap is assumed; phi is noncompactly supported.

## 3. Actual E2, finite J, genuine L1, and the original global cap

We falsify the following plausible but stronger shortcut:

    integral_(G_H) sup_(L in J) |T_L f|^2/F_L dx
       <=C I_n(delta)||f||_1                                (FALSE)

with C independent of n and finite J. This is NOT the objective's weak estimate and is NOT an estimate on a fixed original beta-band or a contrast/background threshold band.

First, the actual phi is bounded by 3/4. The even decreasing w has its maximal interval mass in the interval centered at zero, so phi(x)<=phi(0). The mass of w outside [-1/2,1/2] equals

    2 integral_0^1 t exp[-1/(2t)]dt
       >=2 exp(-1) integral_(1/2)^1 tdt=3/(4e)>1/4.

Here e<3 (for example, use the exponential series and k!>=2^(k-1), with a strict inequality for some k). Since phi(0)=integral_[-1/2,1/2] w=1 minus this tail mass, 0<=phi<=3/4. This uses the original E2 density, not another smoothing kernel.

Take n>=2, delta=1/n, epsilon=1/(100n), and the normalized genuine L1 cube source

    f_epsilon=(2epsilon)^(-n) 1_[-epsilon,epsilon]^n, W=1.

For compatibility with the objective's dyadic softness, one may restrict to n=2^s; that subsequence already disproves a uniform strong shortcut. Let

    X={x:1/2<=r=||x||_infinity<=1-2epsilon},
    J={1+j epsilon: j=0,...,100n},
    L_0(x)=2(r+epsilon),
    L(x)=the smallest member of J at least L_0(x).

This is one fixed finite scale grid and a Borel selector from the actual source. On X, 1<=L<=2 and L<=L_0+epsilon. Every y in the source cube has |(x_i-y_i)/L|<=1/2. Therefore h=1 in every coordinate. Put P=psi_(delta/2)^tensor n and Q=psi_delta^tensor n. At every such normalized displacement,

    P>= (1-1/(2n))^n>=1/2,
    P/Q=product_i [(1-(1-phi_i)/(2n))/(1-(1-phi_i)/n)]
       >=(1+1/(8n))^n>=9/8.                               (3.1)

The denominators are positive. The first inequality uses Bernoulli; the ratio uses 1-phi_i>=1/4 and a denominator at most one. On these full captures, T_L f>= (P_L*f)/9 and F_L<=P_L*f. Hence

    |T_L f|^2/F_L >=(P_L*f)/81>=L^(-n)/162.                (3.2)

The original centered-cube maximal function satisfies M f<2 everywhere on X. Indeed any nonzero capture has side at least 2(r-epsilon)>=1-2epsilon. Its average is at most (1-2epsilon)^(-n)<=50/49 by Bernoulli. Thus X lies inside the TRUE ORIGINAL global cap G_2={M f_epsilon<2}; no soft or representative cap is substituted.

Moreover L<=L_0(1+epsilon), since L_0>=1. The elementary geometric-series estimate (1+epsilon)^n<=1/(1-n epsilon)=100/99 gives L^(-n)>L_0^(-n)/2. The pushforward dx under r=||x||_infinity is d(2r)^n. Therefore

    integral_X L_0^(-n) dx
       =n integral_(1/2)^(1-2epsilon) [r/(r+epsilon)]^n dr/r
       >=(n/2) log[2(1-2epsilon)]>=n/6.

We used [r/(r+epsilon)]^n>=(1-2epsilon)^n>=49/50>1/2 and log(3/2)>=1/3. Combining with (3.2) proves

    integral_(G_2) sup_(L in J) |T_L f|^2/F_L dx
       >=integral_X |T_(L(x)) f|^2/F_(L(x)) dx>=n/1944.      (3.3)

At delta=1/n, (2.4) gives I_n(delta)<=2. Thus the dynamic strong fee can exceed the prior fee by an unbounded factor. The test uses an actual finite J, rather than assuming a continuum selector is approximable without paying its hard boundaries. It also uses a genuine L1 input, so no atomic approximation or cap-set limit is needed.

The wide radial interval in X spans exponentially many output amplitude levels as n increases. It is not contained in one fixed ratio original beta-band, and (3.3) does not falsify a fixed contrast threshold restricted by F_(L(x))<=B lambda with B dimension-free. It must not be called a counterexample to the requested soft-layer weak bound. In particular the original cap H=2 is fixed here; changing it to R lambda in a weak return would require tracking R, which may be exponential on the smallest threshold. The result only forbids replacing the dynamic source-selection fee by the prior information fee before doing threshold/major-subset localization.

## 4. Correct selected-scale carry and threshold repair

Fix any L_ref in [1,2], a measurable finite-valued selector L(x), a finite-measure output event E, and a measurable mask 0<=theta<=1_E. For the same original mu=|nu| and J_(n,delta) from Section 2, define the signed carry

    R_theta=integral theta(x) integral mu(dy)
       [J_(n,delta,L(x))(x-y)-J_(n,delta,L_ref)(x-y)]dx.      (4.1)

All terms are finite for the actual E2 kernels on a finite event and side window: the component densities are bounded by one before dilation. Fubini is justified by the finite product measure. Keeping the sign until after integration gives the exact identity and inequality

    integral theta C_(L(x)) dx
       =integral theta C_(L_ref) dx+R_theta,
    integral theta |T_(L(x))nu|^2/F_(L(x)) dx
       <=I_n(delta)W+R_theta.                             (4.2)

The second line uses only integral theta C_ref<=I W; it does not drop a negative carry or silently claim it nonpositive. Although R_theta is signed, the displayed right side is nonnegative whenever it bounds the left side through the exact first line. One can exhaust larger E after separate integrability; no infinite-event Fubini is asserted for free.

Suppose the selected event obeys |T_(L(x))nu|>lambda and F_(L(x))<=B lambda, and the mask retains integral theta>=kappa |E|. Then

    lambda |E| <=(B/kappa)[I_n(delta)W+R_theta].           (4.3)

An actual first contrast crossing on an ORDERED FINITE physical grid defines a Borel selector and is permitted here. It is a deterministic source-dependent mean crossing, not a stopping time of an auxiliary random payoff; no optional-stopping theorem is used. A mask/carry theorem on these actual events, plus a paid background-high branch, would produce a weak estimate. Such a theorem is NOT established. Replacing R_theta by zero is refuted for the unrestricted weighted strong test in Section 3, but that test leaves this properly thresholded major-subset interface open.

For the entire contrast crossing event E_all, choose the first crossing selector and split it into E_low={F_selected<=B lambda} and E_high={F_selected>B lambda}. Equation (4.3) applies only to E_low. E_high is contained in {max_(L in J) F_L>B lambda} and must have its own positive-background weak budget. We have neither paid that branch uniformly at the desired order nor paid R_theta on E_low. This is the precise remaining debt. There is no weak-quasinorm triangle inequality or automatic mixture of conditional weak bounds in this reduction.

The source-column form of the carry is explicit:

    R_theta=integral mu(dy) sum_m q_m zeta_m^2
       integral theta(x)[(k_m)_(L(x))(x-y)-(k_m)_(L_ref)(x-y)]dx.

This can be tested on actual common inputs without differentiating the hard boundary or replacing its sign by an absolute lifetime. It is stronger bookkeeping than a latent prior-variance assertion, but it is not a paid bound or an equivalence claim for the general weak problem.

## 5. Current skills and evidence boundary

The current A02/N04 entrances, methods, and cube interfaces were re-read for the common-source map and paid error conditions. The masks here are a finite static latent experiment; no new jump process, stopping filtration, or compensation theorem is asserted. All proofs above use elementary finite sums, Tonelli/Fubini, Cauchy, Bernoulli and cube geometry. No external literature result is imported; the historical E2 Markov-divisibility theorem is retained only as context and is unused in the proofs. No Git or TeX compilation occurred.

Current skill-byte SHA-256 values (hashes confirm bytes, not mathematical acceptance):

- `math-a02-outer-relaxation-budget/SKILL.md`: `5718759f09c75af3353a9e041f2f20ebcbca429d49eeb85ccea3bef998f141e5`
- `math-a02-outer-relaxation-budget/references/method.md`: `5a504ef9b0a05aec083f8b18e41571957b5a8ce71cde2c1a4d49f928fb07b719`
- `math-a02-outer-relaxation-budget/references/cube-interface.md`: `54707b23158ee96f429294bcba9f0d3a293ff1011d407a2fe98870ab689626bb`
- `math-n04-summable-error-entropy-descent/SKILL.md`: `0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107`
- `math-n04-summable-error-entropy-descent/references/method.md`: `1322560cd8179ec6fff99df47b65b581f60d6f58ea0bd461bd243f4f88bd05f7`
- `math-n04-summable-error-entropy-descent/references/cube-interface.md`: `7a3cd70b0b4e07acfa7c1f50d4a410ddd75e32fe9b535105907ccff80eb8d439`

## 6. Self-contained staged guard

The exact guard verifies binomial fees and coupling envelopes, finite mask Cauchy on arbitrary correlated atomic inputs, and the selected-scale carry identity by complete rational spatial-cell integration. For the latter universal lemma it uses the explicitly labeled auxiliary probability density phi_aux=1_[-1,1]/2, which is NOT substituted for the actual E2 counterexample. The actual E2 obstruction is checked only through exact rational consequences of the analytic Bernoulli/geometry bounds. No numerical quadrature of the actual E2 kernel is claimed. The analytic mass-outside proof supplies the actual E2 bound phi<=3/4; the guard does not independently certify that analytic fact.

The following Python 3 guard uses only the standard library and exact `Fraction` arithmetic. It tests universal finite lemmas on specified fixtures, not all possible sources; their universal proofs are Sections 2 and 4. In the cell stage, complete integration also checks the full source-column carry rather than a pointwise posterior replacement. Stage 4 checks rational consequences, while the logarithmic lower bound remains analytic (`log(3/2)=integral_1^(3/2) dt/t>=1/3`).

```python
from fractions import Fraction as Q
from itertools import product
from math import comb

counts = dict(fees=0, mask_equalities=0, cauchy=0, carry_cells=0,
              mass_equalities=0, carry_runs=0, threshold_runs=0,
              actual_E2_rational_rows=0)
carry_signs = set()

def fee(n, d):
    a = [Q(comb(n,k))*(d/2)**k*(1-d/2)**(n-k) for k in range(n+1)]
    b = [Q(comb(n,k))*d**k*(1-d)**(n-k) for k in range(n+1)]
    return sum((2*(u-v)**2/(u+v) for u,v in zip(a,b) if u+v), Q(0))

def laws(n, d):
    masks = list(product((0,1), repeat=n))
    rows = []
    for m in masks:
        a = (d/2)**sum(m)*(1-d/2)**(n-sum(m))
        b = d**sum(m)*(1-d)**(n-sum(m))
        q = (a+b)/2
        z = (a-b)/q if q else Q(0)
        rows.append((m,q,z))
    assert sum((q for _,q,_ in rows),Q(0)) == 1
    assert sum((q*z for _,q,z in rows),Q(0)) == 0
    assert all(abs(z) <= 2 for _,_,z in rows)
    return rows

# Stage 1: exact binomial fees, coupling envelopes and full-mask equality.
for n in range(1,25):
    ds = sorted({Q(0),Q(1),Q(1,2),Q(1,4),Q(1,8),
                 Q(1,n),Q(1,2*n),Q(2,3*n)})
    for d in ds:
        I = fee(n,d)
        coupling = 4*(1-(1-d/2)**n)
        assert 0 <= I <= coupling <= min(Q(4),2*n*d)
        counts['fees'] += 1
        if n <= 6:
            assert I == sum((q*z*z for _,q,z in laws(n,d)),Q(0))
            counts['mask_equalities'] += 1

# phi_aux is a separate test density, not the actual E2 density.
def kernel(m, x, y, L):
    v = Q(1)
    for mi,xi,yi in zip(m,x,y):
        u = abs((xi-yi)/L)
        v *= (Q(1,2) if u <= 1 else Q(0)) if mi else (Q(1) if u <= Q(1,2) else Q(0))
    return v/L**len(m)

def source(n):
    ys = [(Q(0),)*n, tuple(Q((-1)**i,3) for i in range(n)),
          tuple(Q(i+1,2*(n+1)) for i in range(n))]
    masses = (Q(1,2),Q(1,3),Q(1,6))
    phases = ((Q(1),Q(0)),(Q(3,5),Q(4,5)),(Q(-5,13),Q(12,13)))
    assert sum(masses) == 1
    assert all(a*a+b*b == 1 for a,b in phases)
    return ys,masses,phases

def values(rows, ks, masses, phases):
    F = Tr = Ti = C = Q(0)
    for j,(mass,(pr,pi)) in enumerate(zip(masses,phases)):
        for k,(_,q,z) in zip(ks[j],rows):
            b = mass*q*k
            F += b
            Tr += b*z*pr
            Ti += b*z*pi
            C += b*z*z
    S2 = Tr*Tr+Ti*Ti
    assert S2 <= F*C
    assert F or (S2 == C == 0)
    return F,S2,C

# Stage 2: joint-measure Cauchy, with correlated atoms and rational complex phases.
receivers = (Q(-3,2),Q(-1,2),Q(0),Q(1,3),Q(3,2))
Ls = (Q(1),Q(5,4),Q(3,2),Q(2))
for n in (1,2,3):
    ys,masses,phases = source(n)
    for d in sorted({Q(0),Q(1,2*n),Q(1,n),Q(1,2),Q(1)}):
        rows = laws(n,d)
        for x in product(receivers,repeat=n):
            for L in Ls:
                ks = [[kernel(m,x,y,L) for m,_,_ in rows] for y in ys]
                values(rows,ks,masses,phases)
                counts['cauchy'] += 1

# Stage 3: exact full spatial-cell integration for a finite physical selector.
# All supports lie in E=[-3,3]^n. Every hard/aux-soft boundary at every L is
# inserted, so kernels are constant a.e. on each cell. Boundaries have zero mass.
Ls = (Q(1),Q(3,2),Q(2))
for n in (1,2):
    ys,masses,phases = source(n)
    axes = []
    for i in range(n):
        cuts = {Q(-3),Q(3),Q(-1,4),Q(0),Q(1,5)}
        for y in ys:
            for L in Ls:
                for radius in (L/2,L):
                    cuts.update((y[i]-radius,y[i]+radius))
        cuts = sorted(cuts)
        axes.append([(a,b) for a,b in zip(cuts,cuts[1:])])
    cells = []
    for box in product(*axes):
        x = tuple((a+b)/2 for a,b in box)
        volume = Q(1)
        for a,b in box:
            volume *= b-a
        cells.append((x,volume))
    for d in (Q(1,n+1),Q(1)):
        rows = laws(n,d)
        I = fee(n,d)
        data = []
        full_C = [Q(0)]*len(Ls)
        for x,volume in cells:
            kernels = [[[kernel(m,x,y,L) for m,_,_ in rows] for y in ys] for L in Ls]
            vals = [values(rows,ks,masses,phases) for ks in kernels]
            data.append((x,volume,kernels,vals))
            for j,(_,_,C) in enumerate(vals):
                full_C[j] += volume*C
        assert all(c == I for c in full_C)
        counts['mass_equalities'] += len(Ls)
        for mode in ('max_C','min_C','first_crossing'):
            lam,B,kappa = Q(1,64),Q(8),Q(1,3)
            selected = reference = carry = energy = retained = event_mass = Q(0)
            columns = [[Q(0) for _ in rows] for _ in ys]
            for x,volume,kernels,vals in data:
                theta0 = Q(1) if x[0] < Q(-1,4) else (Q(1,2) if x[0] < Q(1,5) else Q(1,3))
                if mode == 'first_crossing':
                    hits = [j for j,(_,s2,_) in enumerate(vals) if s2 > lam*lam]
                    j = hits[0] if hits else 0
                    F,S2,C = vals[j]
                    low = bool(hits) and F <= B*lam
                    if bool(hits) and not low:
                        assert max(v[0] for v in vals) > B*lam
                    theta = theta0 if low else Q(0)
                    event_mass += volume if low else Q(0)
                else:
                    j = (max if mode == 'max_C' else min)(range(len(Ls)),key=lambda j:vals[j][2])
                    F,S2,C = vals[j]
                    theta = Q(1)
                Cref = vals[0][2]
                selected += volume*theta*C
                reference += volume*theta*Cref
                carry += volume*theta*(C-Cref)
                energy += volume*theta*(S2/F if F else Q(0))
                retained += volume*theta
                for a in range(len(ys)):
                    for b in range(len(rows)):
                        columns[a][b] += volume*theta*(kernels[j][a][b]-kernels[0][a][b])
                counts['carry_cells'] += 1
            column_carry = sum((masses[a]*q*z*z*columns[a][b]
                                for a in range(len(ys))
                                for b,(_,q,z) in enumerate(rows)),Q(0))
            assert selected == reference+carry
            assert carry == column_carry
            assert 0 <= energy <= selected <= I+carry
            counts['carry_runs'] += 1
            carry_signs.add((carry > 0)-(carry < 0))
            if mode == 'first_crossing':
                assert event_mass > 0
                assert retained >= kappa*event_mass
                assert lam*event_mass <= (B/kappa)*(I+carry)
                counts['threshold_runs'] += 1
assert {-1,1} <= carry_signs

# Stage 4: rational consequences of the analytic actual-E2 bound phi <= 3/4.
# This stage performs no actual-E2 quadrature or pointwise kernel certification.
for n in range(2,129):
    eps = Q(1,100*n)
    assert (1-Q(1,2*n))**n >= Q(1,2)
    assert (1+Q(1,8*n))**n >= Q(9,8)
    assert (1-2*eps)**n >= Q(49,50)
    assert 1/(1-2*eps)**n <= Q(50,49)
    assert (1+eps)**n <= Q(100,99) < 2
    assert 2*(1-2*eps) >= Q(3,2)
    assert fee(n,Q(1,n)) <= 2
    assert Q(1,162)*Q(1,2)*Q(1,6) == Q(1,1944)
    counts['actual_E2_rational_rows'] += 1
print('PASS', counts)
print('signed carry signs:', sorted(carry_signs))
```

Executed exact-guard result (Python 3, standard library only):

```text
PASS {'fees': 185, 'mask_equalities': 42, 'cauchy': 2960, 'carry_cells': 7110, 'mass_equalities': 12, 'carry_runs': 12, 'threshold_runs': 4, 'actual_E2_rational_rows': 127}
signed carry signs: [-1, 1]
```

The SHA-256 of the code block, including its final newline, is `95c1317f685cfcdaa6b9e91dad2c0c2282b1a640b08e52c618f260cf92511af4`. This is an executed finite regression guard, not a proof of the unrestricted weak target. The auxiliary density is used only for the universal finite Cauchy/carry fixtures; the actual E2 counterexample relies on its separately proved analytic bound.


---

# Parent audit: shared exponential races and exact pair probabilities

The complete general rounding proof is in the coverage chapter. This independent check keeps original actual winners fixed and uses shared source clocks. It does not sample a new partition separately for each receiver.

For feasible whole-site column coefficients alpha_J, let s_i=sum_{J contains i}alpha_J<=1. With independent clocks Exp(alpha_J), a captured source pair i,k is assigned to the same specified column J precisely when J has the earliest clock among all columns incident to at least one of i,k. If i,k belong to J, this probability is

    alpha_J / sum_{K: K intersects {i,k}}alpha_K.

The denominator includes J once, including when i=k. Thus for q=2 the expected gated posterior score of rounded packet J has an exact double-sum formula. Since the denominator is at most s_i+s_k<=2, it is at least alpha_J/2 times the unrounded squared score. This is an independent verification of the q=2 part of the conditional-Jensen proof. It does not require source-site assignment independence.

For a finite column family, the probability of a complete clock order j_1,...,j_m is the product over positions r of alpha_(j_r) divided by the sum of rates not yet ordered. This follows successively from the exponential minimum law and memorylessness. The exact guard enumerates all these orders, assigns each source to its first incident column, and verifies the order probabilities sum to one. It deliberately omits any positive score from uncovered leftover singleton packets; the resulting lower checks therefore remain valid.

The independent parent guard uses rational coordinates, positive rational source masses and receiver weights. Every finite witness uses the actual complete-distance-batch maximizing cube and one original beta=2 band. The receiver weights define only a finite functional, not a certified Lebesgue integral. Three stages cover 22 cases with dimensions 1--8, 3--6 sources, and q=1,2,3 (expanded cases use q=2); 53 receiver witnesses and 1,644 race orders are checked exactly. Fifteen additional pair-formula checks reach dimension 128 and 16 sources, without claiming these individual receivers represent a high-dimensional volume. Seven of the 22 staged cases have zero gated column score; they test the zero-score branch, while 15 have nonzero objective. All checks passed.

The guard also labels a purely abstract gate calibration. Take one all-site column of rate epsilon and N singleton competitors of rate 1-epsilon, and retain only the all-site gate at the witness. Its expected squared score divided by epsilon is

    1/N+(1-1/N)/(2-epsilon),

which approaches 1/2 when epsilon=1/N and N grows. This artificial gate pattern is NOT claimed to be realizable by optimized representatives of actual cubes. It calibrates the general race estimate, not the geometric coverage problem or its optimal constant. In particular, it cannot be used as a lower bound for the cube maximal operator.

No literature novelty is asserted for the rounding method. The real-power exponential-clock argument is proved directly here; no external contention-resolution theorem is used or transferred to this convex power objective.

Reproduction uses only Python's standard library. The complete guard is embedded below and writes race_results.json next to itself. Its saved exact result is included in the archive inventory. The parent executed this guard independently of the separate coverage author guard. Neither exact finite guard establishes the still-missing all-input coverage fraction.


```python
"""Exact finite checks of common exponential-clock contention rounding.
All counts/integrals here are FINITE receiver witnesses, not Lebesgue quadrature.
No external dependencies. Float is used only for elapsed seconds in stdout.
"""
from fractions import Fraction as F
from itertools import permutations, product
from pathlib import Path
import json, random

def winner(ys, ps, x):
    ds = sorted(set(2*max(abs(a-b) for a,b in zip(x,y)) for y in ys))
    if not ds or ds[0] == 0: return None
    n=len(x); best=None
    for L in ds:
        cap=tuple(i for i,y in enumerate(ys) if 2*max(abs(a-b) for a,b in zip(x,y))<=L)
        mass=sum((ps[i] for i in cap), F(0)); val=mass/L**n
        if best is None or val>best[0]: best=(val,L,cap,mass)
    return best

def gate(c,x,L): return all(2*abs(a-b)<=L for a,b in zip(c,x))
def columns(N,rng,m):
    ss=list(range(1,1<<N)); rng.shuffle(ss); masks=ss[:m]
    raw=[F(rng.randint(1,9),rng.randint(1,7)) for _ in masks]
    cap=max(sum((a for a,j in zip(raw,masks) if j>>i&1),F(0)) for i in range(N))
    return masks,[a/cap for a in raw]

def score(masks,reps,ys,ps,receivers,q):
    ans=F(0)
    for x,w in receivers:
        M,L,cap,mass=winner(ys,ps,x)
        for j,c in zip(masks,reps):
            if gate(c,x,L):
                a=sum((ps[i] for i in cap if j>>i&1),F(0))
                ans+=w*M*(a/mass)**q
    return ans

def pair_exact(masks,rates,reps,ys,ps,receivers):
    # E[sum packet retained posterior squared], without enumerating race orders.
    ans=F(0); N=len(ps)
    for x,w in receivers:
        M,L,cap,mass=winner(ys,ps,x)
        for j,a,c in zip(masks,rates,reps):
            if not gate(c,x,L): continue
            for i,k in product(cap,repeat=2):
                if j>>i&1 and j>>k&1:
                    union=sum((b for l,b in zip(masks,rates) if (l>>i&1) or (l>>k&1)),F(0))
                    ans+=w*M*ps[i]*ps[k]/mass**2*a/union
    return ans

def race_enum(masks,rates,reps,ys,ps,receivers,q):
    ans=F(0); prob_sum=F(0); min_ratio=None; totals=F(0)
    for order in permutations(range(len(masks))):
        remaining=sum(rates,F(0)); prob=F(1); assigned=0; out=[0]*len(masks)
        for k in order:
            prob*=rates[k]/remaining; remaining-=rates[k]
            out[k]=masks[k]&~assigned; assigned|=masks[k]
        prob_sum+=prob
        ans+=prob*score(out,reps,ys,ps,receivers,q)
    assert prob_sum==1
    # Intentionally omit leftover singleton gain: all lower bounds still apply.
    return ans

def run():
    rng=random.Random(731011); rows=[]; receivers_count=0; permutations_count=0; pair_terms=0
    for stage,nvals,N,m,count in [('pilot',[1,2],3,3,6),('pressure',[1,2,3],4,4,8),('expanded',[1,2,4,8],6,5,8)]:
        for case in range(count):
            n=nvals[case%len(nvals)]
            ys=[]
            while len(ys)<N:
                y=tuple(F(rng.randint(-6,6),3) for _ in range(n))
                if y not in ys: ys.append(y)
            raw=[F(rng.randint(1,9)) for _ in ys]; W=sum(raw); ps=[a/W for a in raw]
            masks,rates=columns(N,rng,m)
            reps=[]
            for j in masks:
                inds=[i for i in range(N) if j>>i&1]
                reps.append(tuple((min(ys[i][k] for i in inds)+max(ys[i][k] for i in inds))/2 for k in range(n)))
            # One actual beta=2 band from a generated, non-atomic receiver.
            seeds=[]
            for h in range(8):
                x=tuple(F(rng.randint(-23,23),7) for _ in range(n))
                if winner(ys,ps,x): seeds.append(x)
            base=winner(ys,ps,seeds[0])[0]; lam=base*F(3,4)
            recv=[(x,F(rng.randint(1,5),11)) for x in seeds if lam<winner(ys,ps,x)[0]<=2*lam]
            assert recv
            receivers_count+=len(recv)
            qs=[1,2,3] if stage!='expanded' else [2]
            ratios={}
            for q in qs:
                col=[score([j],[c],ys,ps,recv,q) for j,c in zip(masks,reps)]
                lp=sum((a*b for a,b in zip(rates,col)),F(0))
                strong=sum((a/(q-(q-1)*a)*b for a,b in zip(rates,col)),F(0))
                exact=race_enum(masks,rates,reps,ys,ps,recv,q)
                assert exact>=strong>=lp/q
                if q==2:
                    assert exact==pair_exact(masks,rates,reps,ys,ps,recv)
                    pair_terms+=len(recv)*m*N*N
                from math import factorial
                permutations_count+=factorial(m)
                ratios[str(q)]=None if lp==0 else str(exact/lp)
            rows.append({'stage':stage,'n':n,'N':N,'columns':m,'receivers':len(recv),'race_to_LP_ratios':ratios})
    # High-dimensional rational actual-winner pressure: no factorial enumeration.
    expanded=0
    for n in [1,2,8,32,128]:
        for N in [4,8,16]:
            ys=[tuple(F((i*(k+3)+k*k)%17,7) for k in range(n)) for i in range(N)]
            ps=[F(i+1,N*(N+1)//2) for i in range(N)]
            masks,rates=columns(N,rng,min(12,(1<<N)-1))
            reps=[ys[(j&-j).bit_length()-1] for j in masks]
            x=tuple(F(31+k%3,11) for k in range(n)); recv=[(x,F(1))]
            vals=[score([j],[c],ys,ps,recv,2) for j,c in zip(masks,reps)]
            lp=sum((a*b for a,b in zip(rates,vals)),F(0))
            exact=pair_exact(masks,rates,reps,ys,ps,recv)
            assert exact>=lp/2
            # Actual band can always be fixed as lambda=3M/4 for this witness.
            expanded+=1
    # A nonphysical abstract receiver family shows loss can approach q=2.
    # m sites, columns J0=all and Ji={i}; capacities alpha0=eps, alphai=1-eps.
    # Only J0 has a gate at this receiver. Its expected retained power/alpha0
    # equals 1/m + (1-1/m)/(2-eps), tending to 1/2.
    # This is NOT a cube-realizable counterexample: contained subset gate structure matters.
    abstract=[]
    for N in [2,8,64,1024]:
        eps=F(1,N)
        ratio=F(1,N)+(1-F(1,N))/(2-eps)
        assert ratio>F(1,2)
        abstract.append({'N':N,'epsilon':str(eps),'ratio':str(ratio),'physical_cube_claim':False})
    return {'status':'PASS','scope':'finite actual-band witnesses; no Lebesgue integral or general dimension bound certified','seed':731011,'rows':rows,'enumerated_receiver_witnesses':receivers_count,'race_permutations':permutations_count,'upper_bound_pair_terms':pair_terms,'expanded_pair_checks':expanded,'abstract_gate_calibration':abstract}
if __name__=='__main__':
    data=run(); out=Path(__file__).with_name('race_results.json'); out.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n'); print(json.dumps({k:v for k,v in data.items() if k not in ('rows','abstract_gate_calibration')},sort_keys=True))
```


---

# Round 73: finite common-packet optimization on the actual winner band

The frozen experiment evaluates actual common whole-site partitions and contained fixed representatives on the original all-scale centered-cube winner band. It finds clear pressure against singleton power coverage and against the particular balanced-coordinate tree, and demonstrates training selection bias. It does not establish a dimension-only coverage fraction, an arbitrary-input extremum, or the target `C_n ≤ √n n^{o(1)}`. No asymptotic order is fitted.

## Actual object and the score

Each source is one finite positive atomic measure `μ=Σ p_i δ_{y_i}`, with coincident sites merged and exact rational mass `W=1`. Stored coordinates are interpreted as their exact binary floating values; for example, a grid constructed with `j/7` is the resulting binary grid, rather than an exact rational `j/7` grid. The source and its threshold are held fixed while packets are selected.

For each receiver, the program considers every arrival volume `v_i=(2‖x-y_i‖∞)^n`. The average can only decrease between successive arrivals, so testing every complete equal-distance batch evaluates the actual all-scale centered maximal function. Among maximizing batches, it selects the smallest volume. Equal-distance sites enter together; they are not independent arrival labels. Atom receivers are a null set and are rejected if encountered. No finite scale window, radius mesh, source-weighted receiver measure or spatial truncation replaces this object.

Write `Q*(x)` for the closed winning cube, `F=μ(Q*)`, `V*=|Q*|`, and `M=F/V*`. The original band is `Ω={λ<M≤2λ}`. A partition consists of disjoint nonempty site-index blocks `J` whose union is every merged source site, each with one fixed representative `c_J`. Both membership and representatives are common across all validation receivers. Put

`π_J(x)=μ_J(Q*(x))/F(x)`, `g_J(x)=1{c_J∈Q*(x)}`,

`P_t(x)=Σ_J g_J π_J^(1+t)`, `s(x)=Σ_J g_J π_J`.

The reported power traffic is `R_t/W=∫_Ω M P_t dx/W`; paid traffic is `∫_Ω M s dx/W`; unpaid traffic is `∫_Ω M(1-s) dx/W`. The assertions check exact source-site partitioning, `0≤P_t≤s≤1`, and coordinate median conditions for all methods that impose them. The method `exhaustive_arrangement` permits unrestricted representatives. This run does not optimize the source-capacity LP or its dual, and does not implement shared exponential-clock rounding.

The analytic general payment fee stored in each row is `C_t=1+log 2+1/t`. It is an upper payment bound for a partition, not a demonstrated coverage lower bound. The actual band occupation `T/W=∫_Ω M dx/W` and weak statistic `λ|{M>λ}|/W` are stored separately.

For paid entropy, the code uses `H=−Σ_{g_J=1}(π_J/s)log(π_J/s)` when `s>0`, and zero otherwise. It records paid entropy traffic and the ratio `∫_Ω MsH / ∫_Ω Ms`, without a separately estimated ratio confidence interval. Qualification retains `A=s·1{s≥1/2,H≤√n}`; the recorded remainder is `∫_Ω M(1−A) dx/W`. This is a diagnostic retained/omitted ledger, not a theorem that the remainder is paid elsewhere.

## Full-space proposal and Radon–Nikodym bounds

Put `V=W/λ`, `a_i=p_i/W`, and `τ_i=v_i/V`. The receiver law is a mixture with probabilities `1/2,1/4,1/4`: a uniformly selected source center at volume scale `V`; a mass-selected center at scale `V`; and a mass-selected center at its own scale `Va_i`. For a volume scale `b`, draw with equal probability `v=bU` or `v=b/U`, `U` uniform on `(0,1)`. The radial volume density is `1/(2b)` on `0<v≤b` and `b/(2v²)` on `v>b`; each branch has mass `1/2`. A uniformly selected cube face, its sign and uniform remaining face coordinates give the normalized cone angular law, so Lebesgue measure decomposes as `dx=dv dσ`.

The complete dimensionless proposal density, evaluated with all centers and all components at every receiver, is

`qcore(x)=V q(x)=Σ_i min(1,τ_i^−2)/(4N) + Σ_i a_i min(1,τ_i^−2)/8 + Σ_i min(1,(a_i/τ_i)^2)/8`.

Thus the importance scores are `1{M>λ}/qcore`, `1_Ω(M/λ)/qcore`, and the latter multiplied by `P_t`, `s`, or the other retained diagnostic factor. Their ideal continuous-proposal expectations are exactly the normalized spatial integrals above. The density used here is attached to each actual source, including all its refined sites; it is not the unrefined-macro proposal from Round 72.

A weak winner has `V*<V` since its captured mass is at most `W`. At least one captured source center therefore has `τ_i<1`, giving `qcore≥1/(4N)`. The weak score is bounded by `4N`; on the band the occupation and nonnegative power/paid/omitted/qualified scores are bounded by `8N`. Paid entropy traffic is bounded by `8N log N`. These are analytic bounds for the normalized ideal law. They depend on site count `N`, and hence are not refinement-uniform concentration constants.

## Finite search scope and independent validation

The exponent set is `t∈{1,1/√n,1/(1+√n log(n+2))}`, with duplicates removed. Every source has 256 training draws, seed `731000+source_id`. Selected partitions and representatives are frozen before two independent held-out batches of 2,048 receivers, seeds `732000+10·source_id` and `732001+10·source_id`. All alternatives on a given held-out batch share those same receivers. Consequently 434 method/exponent/seed rows are not 434 independent receiver samples. All thresholds, source formulas, geometry seeds, site coordinates, weights, training choices and representatives are retained in the JSON.

The tree is constructed only from the source: at depth `d`, order by coordinate `d mod n`, using site index for ties, and choose the split with mass closest to half. Training dynamic programming chooses either each node or its two children, maximizing the additive training score among frontiers of this fixed tree. Receiver data influence which frontier and representatives are selected, but after training the resulting partition is fixed for all held-out receivers. This is not receiver-dependent regrouping.

Representative and partition searches have the following exact scope:

- `singleton_atoms`: all site singletons, represented at their sites.
- `whole_source_median`: one whole-source packet, with the training-best listed coordinate median candidate.
- `registered_macro_packets`: the source's predefined three groups or eight microcluster parent blocks; only its listed representatives are chosen by training.
- `optimized_median_tree_frontier`: frontiers of the one balanced-coordinate tree, using the listed median candidates at each node.
- `exhaustive_median`: all set partitions for `N≤8`, with each block optimized over the stated finite median candidates.
- `exhaustive_median_arrangement`: all set partitions for `N≤8,n≤2`, with representatives from the finite winner-face arrangement inside the full coordinate median box.
- `exhaustive_arrangement`: all set partitions for `N≤8,n≤2`, with unrestricted representatives reduced to the finite winner-face arrangement in the packet bounding box.

For each coordinate, median candidates include the lower and upper weighted medians and their midpoint. All products are tested if there are at most 128. Above that cap, only the three synchronized lower/upper/midpoint vectors are retained, with duplicates removed. The higher-dimensional median searches therefore need not optimize over every product median or the entire median box.

The low-dimensional arrangement includes winner-cube faces and packet-box endpoints, with a midpoint in each open interval, retaining endpoints because cubes are closed. Its indexing and containment geometry are rational. Within the finite training receiver witness this exhausts the relevant gate patterns; positive captured gates can first be clamped to the packet box. The training weights, objective sums and comparisons remain floating arithmetic. “Exhaustive” denotes all finite set partitions and the stated finite gate candidates, not a certified continuum spatial optimum or a rigorously rounded floating optimizer. For unrestricted arrangements only, the finite candidate reduction accounts for the full representative box of that finite witness.

The final archive contains 18 sources, 217 trained choices and 434 held-out rows. There are 78,336 independent receiver draws: 4,608 training draws and 73,728 held-out draws. There are 2,126 retained rational point checks; the same receiver can appear in checks for several methods or exponents. Across held-out rows, 23,538 coordinate-median checks are asserted exactly. Training method counts are 50 tree, 50 whole-source, 50 singleton, 19 registered macro, 26 exhaustive median, 11 median arrangement and 11 unrestricted arrangement. The earlier three-source pilot had 1,920 draws and 42 rows; it is a separate logged stage and is not counted in this FINAL JSON.

## Registered source table

All source masses are normalized to one. Three-group sources have equal weights; heterogeneous sources use the weights specified by their source formula. “Independent” labels denote the registered seeded coordinate-cloud controls, not a claim that a winner posterior has independent coordinates. Microcluster refinement replaces each of eight macro sites by `K` equal submasses, with alternating-coordinate diagonal offsets at minimum macro separation times `1/4096`. The source constructor verifies `N=8K`; macro membership is retained as an explicit common partition.

| Source id | Label | n | merged N | λ | trained choices |
|---:|---|---:|---:|---:|---:|
| 0 | grid8_n1 | 1 | 8 | 1/4 | 12 |
| 1 | vertices4_n2 | 2 | 4 | 1/32 | 18 |
| 2 | heterogeneous_two_scale6_n2 | 2 | 6 | 1/32 | 18 |
| 3 | heterogeneous6_n3 | 3 | 6 | 1/64 | 12 |
| 4 | three_groups_m8_spacing4 | 1 | 24 | 1/12 | 8 |
| 5 | three_groups_m8_spacing20 | 1 | 24 | 1/12 | 8 |
| 6 | homogeneous_grid64_n1 | 1 | 64 | 1/4 | 6 |
| 7 | binary_macro8_n4_K1 | 4 | 8 | 1/128 | 15 |
| 8 | binary_macro8_n4_K4 | 4 | 32 | 1/128 | 12 |
| 9 | binary_macro8_n4_K16 | 4 | 128 | 1/128 | 12 |
| 10 | correlated_macro8_n8_K1 | 8 | 8 | 1/2048 | 15 |
| 11 | correlated_macro8_n8_K8 | 8 | 64 | 1/2048 | 12 |
| 12 | independent_n2_N8 | 2 | 8 | 1/8 | 18 |
| 13 | independent_n2_N32 | 2 | 32 | 1/8 | 9 |
| 14 | independent_n8_N8 | 8 | 8 | 1/512 | 12 |
| 15 | independent_n8_N32 | 8 | 32 | 1/512 | 9 |
| 16 | independent_n16_N8 | 16 | 8 | 1/131072 | 12 |
| 17 | independent_n16_N32 | 16 | 32 | 1/131072 | 9 |

## Held-out findings at t=1

The table averages the two equal-size held-out batches. Each `±` is one combined sample standard error, computed as `sqrt(SE_1²+SE_2²)/2`; it is not a certified confidence interval. Values from different methods in a row are paired through shared receivers, so their differences need a paired analysis before assigning uncertainty to the difference. Values for different refinements use different registered draws, so these are not paired refinement differences. The JSON retains all other exponents and individual seed rows.

| Source | Band occupation T/W | Tree power | Whole-source power | Singleton power | Registered macro power |
|---|---:|---:|---:|---:|---:|
| grid8_n1 | 0.58870 ± 0.01741 | 0.57006 ± 0.01722 | 0.57006 ± 0.01722 | 0.08990 ± 0.00399 | — |
| vertices4_n2 | 0.45185 ± 0.01781 | 0.33572 ± 0.01394 | 0.15971 ± 0.01114 | 0.33572 ± 0.01394 | — |
| heterogeneous_two_scale6_n2 | 0.52642 ± 0.01895 | 0.39535 ± 0.01579 | 0.15600 ± 0.01109 | 0.39535 ± 0.01579 | — |
| heterogeneous6_n3 | 0.50111 ± 0.01787 | 0.35665 ± 0.01428 | 0.26155 ± 0.01286 | 0.33621 ± 0.01395 | — |
| three_groups_m8_spacing4 | 0.83108 ± 0.02166 | 0.52153 ± 0.01855 | 0.52153 ± 0.01855 | 0.09839 ± 0.00428 | 0.61328 ± 0.01694 |
| three_groups_m8_spacing20 | 0.59877 ± 0.02612 | 0.37957 ± 0.02145 | 0.20177 ± 0.01575 | 0.09010 ± 0.00517 | 0.58134 ± 0.02589 |
| homogeneous_grid64_n1 | 0.71637 ± 0.02193 | 0.71637 ± 0.02193 | 0.71637 ± 0.02193 | 0.01119 ± 0.00034 | — |
| binary_macro8_n4_K1 | 0.92564 ± 0.03140 | 0.68787 ± 0.02691 | 0.25053 ± 0.01593 | 0.68787 ± 0.02691 | 0.68787 ± 0.02691 |
| binary_macro8_n4_K4 | 0.98417 ± 0.04044 | 0.27423 ± 0.01259 | 0.27081 ± 0.02089 | 0.18821 ± 0.00867 | 0.75282 ± 0.03468 |
| binary_macro8_n4_K16 | 0.93160 ± 0.04730 | 0.28335 ± 0.02042 | 0.23529 ± 0.02197 | 0.04460 ± 0.00262 | 0.71362 ± 0.04191 |
| correlated_macro8_n8_K1 | 0.54138 ± 0.02460 | 0.48034 ± 0.02288 | 0.07988 ± 0.00933 | 0.48034 ± 0.02288 | 0.48034 ± 0.02288 |
| correlated_macro8_n8_K8 | 0.55296 ± 0.03245 | 0.44185 ± 0.02799 | 0.07208 ± 0.01130 | 0.06134 ± 0.00373 | 0.49073 ± 0.02986 |
| independent_n2_N8 | 0.49146 ± 0.01739 | 0.38557 ± 0.01577 | 0.38557 ± 0.01577 | 0.23159 ± 0.00952 | — |
| independent_n2_N32 | 0.31582 ± 0.01447 | 0.17055 ± 0.00991 | 0.02138 ± 0.00377 | 0.14376 ± 0.00803 | — |
| independent_n8_N8 | 0.68768 ± 0.03173 | 0.66282 ± 0.03116 | 0.06013 ± 0.00849 | 0.66282 ± 0.03116 | — |
| independent_n8_N32 | 0.58271 ± 0.03165 | 0.43666 ± 0.02758 | 0.01707 ± 0.00439 | 0.53643 ± 0.03045 | — |
| independent_n16_N8 | 0.67984 ± 0.03450 | 0.64223 ± 0.03337 | 0.05341 ± 0.00981 | 0.67867 ± 0.03447 | — |
| independent_n16_N32 | 0.63751 ± 0.03852 | 0.47024 ± 0.03336 | 0.00000 ± 0.00000 | 0.63751 ± 0.03852 | — |

The n4 eight-macro source gives the clearest refinement pressure. For `K=1,4,16`, macro power is `.68787,.75282,.71362`, whereas singleton power is `.68787,.18821,.04460`. The selected tree gives `.68787,.27423,.28335`, using 8,19,14 packets. The registered eight-parent partition maintains much more power on these narrow cluster inputs, but the experiment does not prove invariance at every receiver or for arbitrary cluster refinements. The n8 correlated case likewise gives macro `.48034,.49073` for `K=1,8`, with singleton `.48034,.06134`.

For three groups separated by 20, the registered three-packet score is `.58134 ± .02589`, near the observed band `.59877 ± .02612`. The fixed tree's selected two-packet frontier gives `.37957 ± .02145`; the one whole-source median gives `.20177 ± .01575`. Thus the tested tree family can miss a useful common grouping even with training optimization. This is a failure of this finite tree strategy on a tested source, not a failure certificate for the unrestricted common-partition optimum. At spacing 4, the three-packet power is `.61328`, while its paid traffic is `.80934`; full paid mass and high power are distinct quantities.

For the homogeneous 64-site grid, the selected whole packet contains its representative on every sampled band winner and yields the full observed band `.71637 ± .02193`. Singletons also have full paid traffic, but their `t=1` power is `.01119 ± .00034`, exactly one sixty-fourth of the sample band score. Their conditional paid entropy is `log 64=4.15888`, above the qualification cutoff `√n=1`, so qualified singleton traffic is zero. This finite observation illustrates how atomic splitting can erase power while retaining paid mass; it does not certify the whole-source gate at all unsampled receivers.

The four-vertex case illustrates search optimism. The all-partition finite training optimum is `.338342` (identical here for median, median-arrangement and unrestricted-arrangement methods), exceeding the singleton training score `.327869`. Its selected three-packet partition nevertheless gives held-out `.282026 ± .013229`, while singletons and the selected tree give `.335716 ± .013940`. The search is optimal for its finite training witness; that property does not order held-out spatial estimates. Training contains only 256 draws. Other cases show comparable instability: in n16/N32, the tree and singleton training objectives tie at `.620904`, while held-out tree and singleton power are `.470240` and `.637512`; the whole-source median sees zero sampled held-out traffic. A zero observed mean or SE is not proof that the true integral vanishes.

The displayed examples were chosen to expose the finite mechanisms in the completed run. This reporting selection has no independent extremality guarantee. The cloud controls and the small source list do not cover arbitrary source geometry, thresholds, dimensions, or source count. No conclusion about a growth rate in n is inferred from them.

## Exact finite witness and retained point guards

The standalone rational guard uses four equal masses at `(±1,±1)`, `λ=1/32`, `t=1`, and eight receivers with weights `1/8`: `(±5/2,0)`, `(0,±5/2)`, and `(±2,±2)`. The first four actual winners capture a vertex pair and have `M=1/18`; the last four capture a singleton and have `M=1/16`, at the closed upper band endpoint `2λ`. The complete equal-distance batches and smallest-volume maximizing selection are evaluated exactly.

For this finite positive receiver witness, rational arrangement representatives and exact additive objectives give unrestricted and median-restricted optima both `13/288`. All 15 nonempty source subsets and all 15 set partitions are processed; subset dynamic programming agrees exactly with direct partition enumeration. The guard was rerun independently during preparation of this report and returned the same exact values. It certifies the objective `Σ_l (1/8) M(x_l)P_1(x_l)` on those eight receivers only. Neither the weights `1/8` nor these finite points constitute a certified Lebesgue quadrature, and this exact number is not the normalized band integral.

For each held-out choice the program retains the receiver of the largest sampled power score and the closest available sampled receivers above and below `M/λ=1,2`. On those points it recomputes the arrival geometry from exact binary-coordinate integers, the maximizing complete batch, the original band and each contained-representative gate. Posterior masses are rational. The full proposal density is enclosed by rounding every rational component downward/upward to the denominator `10^80` before summation. Its maximum retained relative interval width is `2.1287403321625253e−75`; maximum relative floating discrepancy is `1.112409362761048e−15` for `M/λ` and `1.839441489855239e−15` for qcore.

Floating geometry uses an exact fallback for near equal-distance groups and near competing winners or band thresholds; containment uses an exact fallback near winner-cube faces. The retained guards verify their stated actual points, not every floating evaluation in all space. Powers at general real t, objective sums, empirical maxima and entropy arithmetic remain ordinary floating computations; the guards do not certify their outward intervals. Point agreement, including many repeated checks across methods, is not a spatial integral enclosure.

## Uncertainty, skill boundary and replay

Each nonnegative score stores mean, sample SE, sampled maximum, the analytic ideal-law range bound and the formal two-sided 95% Hoeffding radius `B sqrt(log(40)/(2S))`. For a held-out 2,048-draw row with the band/power bound `B=8N`, this radius is `.96032` at `N=4` and `30.73033` at `N=128`; these bounds are much wider than the observed SEs and scores. Even these radii assume the ideal normalized continuous law and exact score evaluation. Finite-machine pseudorandom generation, floating calculations, reporting selection and comparisons across many methods are not certified by them. The listed per-row radii are not simultaneous 95% guarantees over the entire archive.

The current L02 (adversarial input search) and L03 (rational/interval certificates) skill entrances were read for this report. Their finite-search-versus-proof and outward-rounding limitations are observed: the sources are explicitly feasible, all retained partitions conserve the source, search scopes and ties are recorded, and the exact guard remains a finite certificate. No generic verified interval library or theorem migration is asserted. This run supplies numerical mechanism checks; the geometric coverage theorem remains open.

`coverage_probe.py` writes `coverage_results.json` beside itself. To reproduce the full archive while preserving the frozen output, copy the script into a temporary directory and run it there without `--pilot`:

```sh
TASK_REPLAY_DIR=$(mktemp -d)
cp /Users/zhengzhihao/Desktop/T/output/centered_cube_round073_20261011/coverage_probe.py "$TASK_REPLAY_DIR/coverage_probe.py"
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 "$TASK_REPLAY_DIR/coverage_probe.py"
shasum -a 256 "$TASK_REPLAY_DIR/coverage_results.json"
```

Run `--pilot` only on such a temporary copy, since it writes a PILOT JSON at the same adjacent pathname. The archived environment is NumPy 2.3.5, Python 3.12.14 and BLAS threads 1. The original completed final run was logged as exiting successfully in 11.7271 seconds; runtime is printed and excluded from deterministic JSON. This report preparation reran the exact eight-receiver guard. The parent independently replayed the full final script in a temporary directory with the bundled runtime: exit code 0, elapsed 12.452894625 seconds, empty stderr, and byte-identical final JSON. The retained `main_replay_receipt.json` records the executable, frozen script hash, expected/result hashes and stdout. Deterministic replay confirms reproduction of the saved finite experiment, not accuracy of its unsampled spatial integral.

Frozen coverage_probe.py SHA256: `e619bba8a9b1e71c1abc92348d72e415ddf44ef81b699df3036fd730d8e5ae2d`.

Frozen coverage_results.json SHA256: `d574de6f4e6f29df880b20333074e9fa627391bfc99b3f9ae15f72d4975b9d3b`.
