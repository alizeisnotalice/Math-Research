# R167：少数接收坐标可任意远溢出的实际付款分支

状态：本稿证明一个一般来源的新接收分支及完整显式费用。使用非对称核幂，容许少数坐标位于 b-core 外任意远；不限制外 hard 来源，不使用固定 I1 特例，不处理 same-α 余额的新优化，也不做 soft-mask 展开。

## 1. 精确命题与覆盖范围

固定原 soft 下门 0<s_0≤1，记

\[
 \eta=1-\int_{-1}^1\phi(t)dt>0,\quad
 \varepsilon=s_0\eta,\quad \alpha=3\varepsilon/4,\quad
 T_\varepsilon=\log(80e/\alpha),
\]

\[
 m_b(x,y)=\#\{i:|x_i-y_i|>b/2\},\qquad
 m_0(n,s_0)=\left\lfloor{\alpha n\over4T_\varepsilon}\right\rfloor.
                                                               \tag{X1}
\]

令 \(\mathcal S=\{s(x)\ge s_0,\ m_b(x,y)\le m_0(n,s_0)\}\)。对原 raw 正交通限制到此接收分支，保留同一个 α_RC（本稿的 α=3ε/4 仅为指数常数，绝不替换 α_RC）、原 good/bad、ρ、全部资格以及 β–ν 来源关系，得到

\[
\boxed{\quad
 2\Lambda P_{\mathcal S}
 \le 96\Lambda (K/3)^{1/4} e^{3/2}\log2\,
 (1+\log(1/s_0))
 \left({28\over3e\varepsilon}\right)^{7/2}
 \sqrt n\,W_\beta .\quad}                                  \tag{X2}
\]

K、Λ 沿原参数保留，未固定为 1，也未将其维数依赖吸入常数。此式沿本轮已恢复并核验的 FIRST／history 合同：固定 (ω,V,j,y,t) 时 Π_t、ν 不依接收点 x 或外 hard 来源；每个 Π_t 是实际完整支持上的概率。硬帽 16/3 只用一次，安全 j 数 ≤n+2，β 聚合为原 W_β。

新覆盖与旧接收域 U_{d_*}(y) 可以有交叠。新增分支取 \(\mathcal S\setminus U_{d_*}(y)\) 即可直接使用 (X2)，旧 U_{d_*} 分支仅付一次。m_0≥1 时，新分支允许最多 m_0 个坐标具有任意大的 overflow，故并非小总距离 U_d 的重述。若 m_0=0，新增差集为空或已在旧域；不声称每个有限 n 都扩域。

## 2. 全来源点态核比与外坐标积分

归一 b=1，接收坐标 X=(x_i−y_i)/b，来源坐标 V=(v_i−y_i)/b，ℓ=L/b∈[1/2,1]。记

\[
 a_\phi=2\sinh(1/2),\quad
 c_0={7\over24}(1-e^{-1})^2.
\]

以下两条全位置初等包络成立：

\[
 C(V)\ge c_0{e^{-|V|}\over1+|V|},\qquad
 \phi(t)\le3{e^{-|t|}\over1+|t|}.                         \tag{X3}
\]

证明：|V|≤1 时 C(V)≥C(1)≥c_0；|V|≥1 时，已核的尾积分直接给 C(V)≥a_φ²e^{−|V|}/(|V|+3)，足以推出第一式。|t|≤1/2 时 φ≤1，且 3e^{−|t|}/(1+|t|)>1；|t|≥1/2 时尾式 φ(t)≤a_φe^{−|t|}/(|t|+1/2)≤(3a_φ/2)e^{−|t|}/(1+|t|)<3e^{−|t|}/(1+|t|)。

由三角不等式，得到本路线的全来源点态界

\[
 \boxed{\quad
 {\phi(X-V)\over C(V)}
 \le{3\over c_0}(1+|X|)e^{|X|}\qquad(X,V\in\mathbb R).
 \quad}                                                   \tag{X4}
\]

它没有来源距离阈值或未证 supremum。分别使用
|V|−|X−V|≤|X| 与 (1+|V|)/(1+|X−V|)≤1+|X| 即得。

定义非对称一维接收核

\[
 H_V(X)=p_{s,\ell}(X)^{3/4}
        [\phi(X-V)/C(V)]^{1/4}.
\]

core 内 Hölder 给出

\[
 \int_{|X|\le1/2}H_V(X)dX
 \le\left(\int_{|X|\le1/2}p_{s,\ell}\right)^{3/4}
      \left(\int_{|X|\le1/2}\phi(X-V)/C(V)\right)^{1/4}
 \le(1-s\eta)^{3/4}.                                    \tag{X5}
\]

因为 1/(2ℓ)≤1，p 的 core 质量≤1−sη；φ≤F 保证第二积分≤1。

core 外 p 的硬部分严格为零。用 ℓ≥1/2 与 φ 单调，

\[
 p_{s,\ell}(X)\le2s\phi(X)
 \le3a_\phi s\,{e^{-|X|}\over1+|X|},\qquad |X|>1/2.
\]

与 (X4) 合并，外坐标积分有与 V 无关的显式有限常数

\[
\begin{split}
 \int_{|X|>1/2}H_V(X)dX
 &\le4e^{-1/4}(3a_\phi s)^{3/4}(3/c_0)^{1/4}\\
 &<20s^{3/4}\le20.                                      \tag{X6}
\end{split}
\]

这里被积尾为 e^{−|X|/2}(1+|X|)^{−1/2}，上放其多项式因子至 1 后直接积分。常数 20 可由 a_φ<1.043、c_0>0.116 直接核算。指数 1/4 的作用是使尾部保留净指数衰减；没有将平方根直接窗粗化成两个窗质量。

## 3. 混合外坐标的组合费用

固定来源向量 V 以及合法 s≥s_0、ℓ∈[1/2,1]。对恰有 m 个外 core 坐标的接收域，用产品 Tonelli 与 (X5)–(X6)，积分至多

\[
 {n\choose m}e^{-\alpha(n-m)}20^m.
\]

这只是接收核的产品积分，完全不假设来源 ν 是产品测度。令 r_0=α/(4T_ε)。对 m≤floor(r_0n)，

\[
\begin{split}
 \int_{m_b\le m_0}\prod_iH_{V_i}(X_i)dX
 &\le e^{-\alpha n}
       \sum_{m\le r_0n}{n\choose m}(20e^\alpha)^m\\
 &\le \exp[-\alpha n+nH(r_0)+nr_0\log(20e^\alpha)]\\
 &\le e^{-\alpha n/2}=e^{-3\varepsilon n/8}.              \tag{X7}
\end{split}
\]

第二步用 r_0≤1/2 下的二项熵界（由二项分布总质量为 1 直接证明）；H(r)≤r log(e/r)。末步用
log(e·20e^α/r_0)=T_ε+log T_ε+α≤2T_ε。因为 α≤3/4、T_ε≥log(80e/(3/4))>5，这个不等式直接成立。

## 4. 原参数选择器的真实价格

此节只使用 scale 任务给出的原指数网格接口，不做 soft-mask 展开。可自足核验如下：s∈[s_0,1] 向下取 σ=s_0e^{k/n}，σ≤s<e^{1/n}σ；各坐标 f_s≤e^{1/n}f_σ，故产品核至多 e 倍。节点数 N_s≤1+n log(1/s_0)。

L∈[a,b] 向上舍入到相邻比≤e^{1/n}的节点 L′，包括 b 端点。因 f_σ 偶单调，P_{σ,L}≤eP_{σ,L′}。节点数 N_L≤n+2。因此

\[
 p_{s,L}^{3/4}\le e^{3/2}p_{\sigma,L'}^{3/4},\qquad
 N_LN_s\le(n+2)(1+n\log(1/s_0)).                         \tag{X8}
\]

receiver 条件 m_b≤m_0 用 b 定义，不随网格 L′ 改变。J_v/Cprod 也不需要重选来源或网格。对每个节点使用 (X7)，再真实求和，得到

\[
 \int_{m_b\le m_0}\sup_{s\ge s_0,L}
 p_{s,L}(x-y)^{3/4}\big[J_v(x)/C_{\rm prod}(y,v)\big]^{1/4}dx
 \le e^{3/2}(n+2)(1+n\log(1/s_0))e^{-3\varepsilon n/8}.
                                                               \tag{X9}
\]

缩放 b 在左侧正好抵消：核总次数为 1，dx 提供 b^n。没有遗漏 b^n 或使用接收点依赖的来源优化。

## 5. 接回原 δ、Π、hard 与 β

原 good 门给 pχ_J≤min(p,KJ/(3w_g))。用 min(A,B)≤A^{3/4}B^{1/4} 以及 w_g(v)≥Cprod(y,v)，

\[
 1_{\rm good}p\chi_J
 \le (K/3)^{1/4}p^{3/4}[J/C_{\rm prod}]^{1/4}.             \tag{X10}
\]

同一 α_RC 计算出的 ρ 保持原值，正项估计仅用 0≤ρ≤1；没有补偿来源替换原 bad u。用原 δ(v,u)≤n、实际时间长度≤log2。由于固定原标签下 Π_t 不依接收点及 hard 来源，(X9) 对每个原 v、u 都统一，先用 Tonelli 移至空间积分，再积分 Π_t(v)Π_t(u) 的概率质量≤1。未假定 e_t 有下界，也未把 ν 替换成 β。

接收分支不依外 hard 来源，因此先对其使用一次原硬帽 q^{-1}∫h_R a_history dν≤16/3；这里已经消掉 raw 硬来源，后续不再乘或复用其核。安全 j 数≤n+2，其他原期望、V/history 与 β 沿已核 RB16 聚合成 W_β。于是完整 signed 价为

\[
 {32\Lambda\over3}(K/3)^{1/4}e^{3/2}\log2\,
 n(n+2)^2(1+n\log(1/s_0))e^{-3\varepsilon n/8}W_\beta.
                                                               \tag{X11}
\]

用 n+2≤3n、1+n log(1/s_0)≤n(1+log(1/s_0))，再用

\[
 n^4e^{-3\varepsilon n/8}
 \le\sqrt n\left({28\over3e\varepsilon}\right)^{7/2},
\]

得到 (X2)。这一步的 supremum 只是已知实变量函数 r^{7/2}e^{−3εr/8} 的微分极值，不是未知来源或接收范数。

## 6. 剩余域与停止点

与本轮已付 U_{d_*} 分支合并后，一般未付正交通仍包括低 soft s<s_0，以及 s≥s_0 下同时满足 x∉U_{d_*}(y)、m_b(x,y)>m_0(n,s_0) 的部分。若其他任务另支付大 m 的 FIRST 尾，则还需真实检查二者之间的中间 m 带，不能称全部补集已解决。

本稿成功点是 (X2) 的一般来源实际分支价格：有限个外坐标可以任意远，全部 source、time、hard、selector、j 和 β 费用已经列明。它不是全部弱型上界；没有将固定 I1 作为终点，也没有为剩余大／中 m 区域猜阶。交付至此停止。
