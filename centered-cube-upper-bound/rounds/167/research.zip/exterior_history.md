# R167 receiver外部：最小历史与工具合同

结论先行：本轮有界检索中，未定位到已支付“原soft中心y的接收总溢出 \(D_b(x-y):=\sum_i(|x_i-y_i|-b/2)_+>d_*\)”的旧一般分支。已定位的近邻成果分别控制good来源v相对接收盒、相邻尺度薄壳、极小soft带，以及原诊断mask的条件面命中；它们的变量、门及费用不能互换。下文是去重与可迁移条件记录，不是新外部付款，也不声称未读历史不存在其他结果。

## EH1. 本轮对象与准确区别

本轮目标是 R167 task_contract 中真实未付正交通的 \(x\notin U_{d_*}(y)\)，其中
\[
 U_d(y)=\{x:D_b(x-y)\le d\},\quad
 D_b(x-y)=\sum_i(|x_i-y_i|-b/2)_+.
\]
它不限制外硬来源z到y的距离。R166已证的来源near分支与本轮拟增强的receiver-U分支必须各保留其原门；本稿未独审本轮增强证明，不能把它先登记为已付。尤其“good v在Q_L(x)内”“x-y在b-core内”“少个坐标在盒外”“盒外位移总量小”是四种不同事件。\(D_b>0\) 只需要一个很远坐标，不等价于大量盒外坐标；计数尾和位移幅度尾不能互相替换。

## EH2. 已定位的实际付款及本轮对比

所有ZIP路径以本仓库 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/` 为前缀；行号是UTF-8文本按换行计数。先按文件名及关键词索引，再只读下列命中段，不通读整轮proof。

|原出处与实读段|准确旧命题/价格|对R167的适用限制|
|---|---|---|
|`rounds/155/research.zip:joint_receiver_geometry.md:51–80`，JR3–5|在原未付正交通内，good来源 \(v\in Q_{L(x)}(x)\)、\(k_t(v)\ge m\)、原删源保留率 \(\eta_j\ge\eta_0\)，完整价 \(2\Lambda P\le32\Lambda\eta_0^{-1}(n/m)W_\beta\)；取m=⌈√n⌉、η0=1/2得64Λ√nWβ，全部实际soft参数可用。|控制x-v，不是x-y；额外η门未由high/FIRST推出。可与本轮外部正交通取交集，但不支付其整体，也不是新成果。|
|`rounds/156/research.zip:exterior_geometry.md:38–83,128–149,256–264`，EG3–5|令 \(I_\xi(v)=\{i:C_i(v)<\xi\}\)，\(N_L=\#\{i\in I_\xi(v):|x_i-v_i|>L/2\}\)。支付v∉Q_L(x)、k≥m>R、N_L≤R、η≥η0；价 \(64\Lambda\eta_0^{-1}(1+\pi\sqrt n)q_0S_R(q_0)W_\beta\)，q0=2n/(m−R)，S_R见该稿EG2。固定R、m≥θn时为条件根阶。|只允许激活score坐标中少量失捕获；未激活坐标可任意盒外。不是“soft外坐标≥k”高计数付款，也不以y为盒中心。R增长须付S_R费用，不能称全盒外。|
|`rounds/157/research.zip:exterior_joint.md:34–84,88–138`，EJ4–13|S_L=N_L−N_{L+}统计激活坐标落 \(L/2<|x_i-v_i|\le L^+/2\) 的数量。固定核尾P_n,q=min{1,binom(n,q)(2/n)^q}；完整价 \(32\Lambda\eta_0^{-1}n\log2(2+n\log2)(P_{n,q}+\pi\sqrt n\sqrt{P_{n,q}})W_\beta\)。n≥8取最小binom(n,q_n)(2/n)^q_n≤n^-4，得到192Λη0^-1√nWβ。|这是邻近尺度薄壳，不是远离b-core的overflow。多数坐标同时在L、L+盒外的补集明确未付；其固定source二项尾已含selector费用，不能重报同一薄壳为新进展。|
|`rounds/160/research.zip:core_tail.md:3–9,83–140`；`rounds/161/research.zip:global_hard_band.md:25–32,130–154`|R160交0<s≤2^-80/7、zg≤2/3、η≥η0得完整J责任根阶；R161去zg上门，改0<s≤S*=320000^-8/7、全zg≤1、η≥η0，价<2^40Λη0^-1(K/3)^(1/8)√nWβ，n≥2^19可48。|这些覆盖任意来源位移/接收位置，但只在极小soft带和η门内。与本轮s≥s0大/中soft及低η剩余不能互相覆盖。若本轮碰到其交集，先与旧付款不交化。|
|`rounds/076/research.zip:proof.md:603–612`|原E2软层的latent噪声截断，有限物理尺度族⊂[1,2]。\(\|\max_L|T_{noise-tail,L}\nu|\|_1\le2n(1+n\log2)\delta e^{3/4-R/2}W\)。取R=3/2+2log[2n(1+nlog2)]+2a0，所有δ_s=2^-s层合计强L1≤2e^-a0W。|截的是latent平移噪声的∞半径O(log n)，不是本轮D_b接收总溢出阈值。原核、层衰减、有限尺度族须保留；不能据此直接宣称当前raw或连续全部尺度的外部支已付。|

旧成果中最近的“score—真实receiver”联合机制是R155/156：固定来源v后在乘积接收核下建立真捕获概率，才对原后验/删除作有费用比较。它不声称Π内部坐标独立。R157同样先对固定来源和固定核证明薄壳概率，再支付soft Fisher与尺度网格。与本轮的直接 \(D_b(x-y)\) 外部估计相比，均需换事件并重新核对完整费用，不能仅换名称或引用二项尾。

## EH3. 原soft mask、强迫外坐标及已有条件行费

在根目录 `actual_face_mask_exchange_20261007.md:9–43,82–115` 找到直接涉及x−y盒外坐标的原合同。它保留原完整输入/来源对/history，对固定原标签作诊断正分配
\[
 \pi_x(A\mid y)=P^A_{s,L}(x-y)/P_{s,L}(x-y),
 \qquad p_i(x,y)=\frac{s\phi((x_i-y_i)/L)}{(1-s)h((x_i-y_i)/L)+s\phi((x_i-y_i)/L)}.
 \tag{EH3a}
\]
固定y时的mask坐标独立，但混合y或进一步依mask角位置筛选后不自动保持。该A是附加诊断，不等于原early history的活动坐标。

令 \(O_L(x,y)=\{i:|x_i-y_i|>L/2\}\)、o=|O_L|、K_mask=|A|。凡正核权的mask都必须含O_L，故K_mask≥o；固定K_mask=k后
\[
 A=O_L\cup B,\quad |B|=k-o,\qquad
 \Pr(B\mid K=k,x,y)=\frac{\prod_{i\in B}\phi_i}{e_{k-o}(\phi_{[n]\setminus O_L})}.
 \tag{EH3b}
\]
因此不能把“先验K/n”直接乘到原后验。原hard面J(x,z)若落O_L，命中A是确定事件；这就是旧forced-hit障碍。对J∉O_L才有
\[
 \Pr(J\in A\mid K=k,x,y)\le\frac{8(k-o)}{3(n-o)+5(k-o)}\le\frac{8k}{3n+5k}.
 \tag{EH3c}
\]
原稿实际付的是“unforced hit且K_mask≤M0”的原行子支，费用
\[
 R_{unforced\ hit,K\le M0}\le\frac{32M0}{3n+5M0}X.
 \tag{EH3d}
\]
这是需与已用吸收槽核对的X费；不是一般√nWβ外部估计。forced-hit、nonhit和K_mask>M0未由它支付。同根 `double_cutoff_actual_geometry_interface_20261007.md:16,217–228`保留 \(O_L<k_\varepsilon\) 与K双cutoff，但明确没有证明所有current行的k_ε为O(√n)，也没有把原soft位置约束转成source-once接收列费。

对本轮可用的纯集合关系只有 \(O_b(x,y)\subset O_L(x,y)\subset A\)（L≤b），不能从中得 \(D_b\) 的幅度尾；更不能将K_mask与原来源score \(k_\xi(v)=\#\{C_i(v)<\xi\}\) 识别。两者分别由x−y的soft展开与y−v的阈值定义，旧档没有提供无费等同关系。

## EH4. 本轮可使用的64工具条件

本轮读取已安装F02/F04/H05的SKILL及各自 `references/cube-interface.md`。以下只记录接口要求；未新核外部论文原文，不引用技能内题录为本轮新定理。

- `/Users/zhengzhihao/.codex/skills/math-h05-chernoff-hoeffding-bernstein/SKILL.md`：Chernoff须先证明实际目标测度下的mgf上界及其参数域。固定y、固定s,L、完整乘积接收核时可自证坐标mgf乘积；原Π、good/bad、high、same-alpha/history条件化后不自动独立。若使用mask条件律，须用EH3的实际p_i及强迫坐标，而非先验s。若用依赖indicator版本，需所有k子集的共同成功概率，边际均值或两两相关不足。最终还需支付sup_s,L、j/time、原β来源与hard一次帽；概率尾本身不是实际raw费用。
- `/Users/zhengzhihao/.codex/skills/math-f02-tensor-fourier-positivity-soft-square-supremum/SKILL.md`：Fubini张量规则要求有限个L1因子/乘积底测度，不能用于带删源耦合的Π。中心cube的sinc Fourier可负，非负空间核不是Fourier正核。有限softmax误差log(m)/β必须付；它不自动给全尺度sup。该技能不供应本轮overflow收缩或soft-mask score联合界。
- `/Users/zhengzhihao/.codex/skills/math-f04-poisson-gamma-abel-square-function/SKILL.md`：Hilbert Poisson平方函数恒等式须先给非负自伴生成元L，权重为∫t||∂tP_tf||²dt，零谱投影须保留；Gamma需shape/rate正及实际Laplace参数域。逐谱Abel收敛不控制max。其cube接口明确说平均尺度族等价性、Gamma混合核及误差项尚未建立。故本轮真实φ的指数混合可作自证标量积分，但不能仅因有指数就调用Poisson/Gamma平方函数或宣布控制receiver overflow。粗糙域PDE入口与本题对象也不同。

成功的新迁移须对当前 \(D_b>d_*\) 与原正积分给同向上界，并共同付原β、归一化、s/L/j/time与允许吸收费；若只证明fixed-kernel尾或mask计数，则准确标为尚待接回的核工具。旧R155–161已付域应先剔交集，EH3旧行费不得重复领取。至此完成有界历史核验，停止，不作新外部研究。
