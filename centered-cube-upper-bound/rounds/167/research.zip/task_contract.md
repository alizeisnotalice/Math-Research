# R167：接收几何分支与其真实补集
起点R166已推送0f38020bd6ea999f7613145de99d494ff4efec1a。冻结附件 /Users/zhengzhihao/Desktop/T/output/centered_cube_round166_20261015_final_checkpoint。每人仅读相关片段；只写自己责任文件，不Git、不改别人、不自行spawn，交付停止。

一般目标任意正L1的一致sqrt(n)n^o(1)弱型仍未完成。原h=1[-.5,.5], w(r)=∫0¹e^-|r|/a da,φ=h*w,F=max(h,φ),C=h*F；p=P_s,L(x-y),Jv=P1,b(x-v), a≤L,R≤b≤2a。Q=(K1+K2+J)/3,good pwg≤KQ,bad反向,χJ=J/(3Q)。ξ=cjt/b∈[.5,1],wξ(v)=∏min(1,C((y-v)/b)/ξ),kξ=#Ci<ξ,Πt=1Zt wtν/et，Zg⊂Zt。保留原rho=[1−(DK0+αJ)/(TΔ)]+、同α、全部门。精确定义需要时读166 task_contract及source_contract。

恢复原合同：q是共同FIRST水平，P_s(x),L(x)f(x)=q且所有future s'≥s,L'∈[a,b]≤q；ν≤β≤f dx，a_history∈[0,1]聚合RN；固定(ω,V,j,y,t)时Πt、et、ν不依x/硬z，终端wg,g,rho及选择器仍依x。原raw signed为2Λ EΣVj ∫q^-1 p hR a_history rho χJ δ Πt² dt/t dx dβ(y)dν(z)，δ=(kv−ku)+。hard帽q^-1∫hR aν≤16/3只能用一次；外β质量Wβ，j有限≤n+1或安全n+2、时间长≤log2。βν不相等不独立。有限producer q=max三核不等于完整FIRST。

R166 RB16已证s≥s0、||z−y||1≤d*=bnε/(8θ)的真实正支≤C ε^-5/2√n Wβ；ε=s0η,η=1−∫[-1,1]φ, Lφ=2/(1−e^-1),θ=Lφ+(16+8e^Lφ)/ε。其真正解析工具为U_d(y)={Σ(|x_i−y_i|−b/2)+≤d}上∫sup_s,L sqrt(pJ/Cprod)≤sqrt[eNL(n+1)] exp(-nε/8)，NL≤n+2。

本轮主代理准确增强命题：直接把原正分支限定s≥s0、x∈U_d*(y)，不限制外硬z。hard帽后同一证明应完整支付该更大分支，常数不变。先独审再计成果。原I1所有source距离near均失败，但x可能都在y的b-core，请数值精确验证。重点随即转向x∉U_d*(y)，不是继续优化tinynear常数。

严审已证明CS分离窗质量会丢指数收缩：I1 G1→CORE单坐标direct∈[.8070896593,.8113121281]、PB/γ>1.02656；任意n固定几何tensor ratio>(253/203)^n。direct不能先粗化成PiBi/γ。原8正行12组direct均通过指数门，有限非FULL。direct全来源节点+两倾斜尾证书桥已审，但全参数全来源收缩未证；E11/E12未独审。不凭数值猜阶。

成功为一般补集新可付款估计/有效几何覆盖，或改变下一步的原剩余正模型证据；不重复近支证明、旧截顶r_t势(R147)、补偿κ改名或纯固定尺度小例。初步探索—已知压力—扩大参数三阶段，所有真实来源、dx、s0/尺度/j费用保留。已证初等Tonelli/CS/weighted bounds可用，新外工具须核原文。独审先审命题/量词再作者。每轮独立归档提交推送，不编译PDF。
