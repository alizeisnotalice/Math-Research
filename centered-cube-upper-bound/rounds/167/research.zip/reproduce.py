#!/usr/bin/env python3
"""Verify bundle; optionally replay with existing local historical dependencies."""
from pathlib import Path
import argparse,hashlib,json,importlib.util,contextlib,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
for name,digest in json.loads((HERE/'manifest.json').read_text())['sha256'].items():
 assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
print('Bundle hashes PASS')
if a.verify_only:raise SystemExit
if a.output_dir is None:p.error('--output-dir is required for replay')
a.output_dir.mkdir(parents=True,exist_ok=True)
assert a.output_dir.resolve()!=HERE
receipt={}
for name in ('rate_probe','receiver_exterior_probe','fractional_geometry_probe'):
 spec=importlib.util.spec_from_file_location(name,HERE/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=a.output_dir
 with (a.output_dir/(name+'.log')).open('w') as f,contextlib.redirect_stdout(f):m.main()
 ok=json.loads((HERE/(name+'.json')).read_text())==json.loads((a.output_dir/(name+'.json')).read_text())
 receipt[name]={'exact_json_equal':ok};assert ok,name
 print(name,'PASS')
code=(HERE/'exterior_certificate.md').read_text().split('```python\n')[1].split('```')[0]
with (a.output_dir/'exact_certificate.log').open('w') as f,contextlib.redirect_stdout(f):exec(compile(code,'exterior_certificate.md','exec'),{})
receipt['fraction_certificate']='PASS'
(a.output_dir/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('All replays PASS')
