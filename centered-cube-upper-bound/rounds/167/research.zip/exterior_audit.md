# R167 receiver overflow 独立入口审查

状态：已读本轮 `task_contract.md`，只筛准确命题的必要条件；尚未读作者稿，没有新增补集付款结论。仅写本文件，不 Git，不改他人。等待 `triple_geometry` 或 `soft_mask_budget` 的准确命题。

## 1. overflow 与强制 soft 的准确含义

固定参数、接收点与 y，记

    e_i=(|x_i−y_i|−b/2)_+,
    O_b={i:e_i>0},   O_L={i:|x_i−y_i|>L/2}.

L≤b 给 O_b⊂O_L。在 i∈O_L 上 hard h((x_i−y_i)/L)=0，因此该坐标原混合核准确等于 s phi((x_i−y_i)/L)/L。若有 m 个这样的坐标，p 中确有 s^m，sqrt(p) 中确有 s^(m/2)。这只描述核因子，不自动描述带全部归一化/门的原交通。

边界须严格：|x_i−y_i|=L/2 时按原闭区间 h 定义仍可有 hard 值，不能逐点称强制 soft。对固定 L 的 Lebesgue 积分可忽略该坐标超平面；对 L=L(x) 的自适应选择不能自动称其零测。使用 e_i>0 的 b-overflow 则没有这个边界问题。

真实补集为 Σe_i>d_*。它可以来自少数坐标大幅越界或许多坐标小幅越界；不能只凭这个总量推出某个固定比例的坐标都 overflow。

## 2. 原 score 不是 receiver mask

原 k_ξ(v) 的坐标阈值是 C((y_i−v_i)/b)<ξ；receiver overflow 由 x_i−y_i 决定。二者的来源变量不同。仅凭核定义没有 δ_ξ(v,u)≤|O_b|、δ>0⇒overflow 或 overflow⇒低 score 等关系。

若新命题把 score 与 mask 连接，必须在保留原 good/bad、同 alpha、核/尺度和实际资格后给出独立证明；不能以命名“活动坐标”把两个集合认同。原 u 保持 bad 来源，外硬 z 亦不得换成 u。

## 3. 可以 tensor 的对象与必须支付的 mask 费用

对固定 y,v,u、固定 s,L,b 及固定 mask，原产品核与按坐标区间给出的接收域可以 Tonelli tensor。该产品结构属于核与盒，不属于一般来源 ν；ν、β 和当前来源坐标可以任意相关。

全部 masks 的合计若真能重组为同一固定参数下 ∏_i(interior_i+exterior_i)，可用准确乘积式一起计价。若先逐 mask 估后再求和，2^n 或按层 binomial(n,m) 费用必须出现并被控制；不能每个 mask 领取一次同样的全预算。对 Σe_i>d_* 的非产品域可用一个准确的指数权上界转换，但必须证明相应一维加权积分及所有参数的统一费用，不能只写出 Chernoff 形式就登记根阶。

若 s,L 或所选 mask 随 x 变化，固定参数 tensor 并不自动允许在整个接收积分中免费选择这些参数；需要原合法分解、统一包络或带总费用的覆盖。

## 4. 时间、soft 极限与原来源合同

按本轮已恢复原合同，固定 (omega,V,j,y,t) 时 ν、Z_t、w_t、e_t、Π_t 不依 x/外硬 z；可先正 Tonelli 固定 t，再保留原接收门做 dx 积分。若核估计对全部 v,u 统一，可在正确积分次序下使用 Π_t 的概率总量；若不统一，须保留真实来源平均。

这不冻结终端 wg、g、rho、所选 s,L,R 或依 x 的时间窗。不能把当前 Π_t 的固定 t 性质移给终端 wg，也不能用 Π_g 冒替 Π_t。原 ν≤β≤f dx 只是测度包含关系，不意味着 β=ν、不意味着外 ν 或 β 归一为概率、更不意味着来源坐标独立。

s^m/s^(m/2) 的 soft 抑制应直接保留。若证明同时产生 s^(−a) 或 soft 下门 s0 的负幂，必须合并并显示净费用；s↓0 不能借一个形式上的 soft 因子就默认统一可控。原 s=0 端点如使用，须另作准确退化说明。

硬帽 q^(−1)∫h_R a_history ν≤16/3 只用一次。raw 保留硬积分与帽后形式不能重复计价；唯一 j、时间长、history、尺度与外 W_beta 仍按原总账处理。本检查点不重证已核 receiver-near 正支。

## 5. 下一审查入口与停止点

作者准确命题至少应写清：真实补集域；mask 是否互斥完备；固定/自适应参数；score 与 overflow 的连接证据；任意相关来源下来源平均的位置；soft 与 mask 总费用；最终与原 signed/硬帽/j/time 的接口。

目前没有准确新补集命题可核，故到此停止等待，不构造无关反例、不扩大旧 near 证明。


## 6. 新 sparse-overflow 命题：独立推导与作者后审

先按主代理给出的准确公式独立推导外包络与熵求和，再实读 `exterior_geometry.md` 全稿核对 X3–X11 及 X2。绑定 SHA256：`986487adbeb8fd8920bf83a4a13fdb7ba0f571b7abab4f6e1c90d4db76b9987f`。未进行额外数值运行。

### 6.1 全来源包络与外积分：通过

令 a_phi=2sinh(1/2)、c0=7(1−e^(−1))²/24。对 |V|≤1，C(V)≥c0 足够；对 |V|≥1，已核尾下界 C(V)≥a_phi² e^(−|V|)/(|V|+3)，由于 a_phi²/c0=24e/7>2，可下放为 c0e^(−|V|)/(1+|V|)。phi 的 core 用 phi≤1、tail 用 a_phi e^(−|t|)/(|t|+1/2)，分别给 X3 的全线常数 3。

三角不等式分别给指数比与多项式比，故对所有 X,V，

    phi(X−V)/C(V)≤(3/c0)(1+|X|)exp(|X|).

没有取未证 source sup，也不要求 source 距离有界。

对 H_V=p_{s,ell}^{3/4}(phi(X−V)/C(V))^{1/4}，core Hölder 的第二积分为 ∫core phi(X−V)/C(V)≤1，第一积分≤1−s eta，所以 X5 成立。

在 |X|>1/2，ell≤1 保证 hard 严格为零，ell≥1/2 和 phi 单调给 p≤2s phi(X)。由 2/(|X|+1/2)≤3/(1+|X|) 得 X6 使用的外 p 包络。于是

    H_V(X)≤(3a_phi s)^(3/4)(3/c0)^(1/4)
                  exp(−|X|/2)(1+|X|)^(−1/2).

积分并上放最后多项式因子为 1，给外积分≤4e^(−1/4)(3a_phi s)^(3/4)(3/c0)^(1/4)<20s^(3/4)。可不用小数近似核这个“<20”：取 e>8/3>5/2、e<25/9<4，则 a_phi<7/6、c0>21/200，因而 (3a_phi)^(3/4)<8/3、(3/c0)^(1/4)<7/3、4e^(−1/4)<16/5；三者积<896/45<20。此常数是严格绝对常数。

### 6.2 组合费用与真实补集：通过

记 epsilon=s0 eta，alpha=3epsilon/4，T=log(80e/alpha)，r0=alpha/(4T)，m0=floor(r0n)。epsilon∈(0,1)、alpha≤3/4，故 T>1、0<r0<1/2。

固定来源向量及固定合法参数。core 每坐标质量≤exp(−alpha)，外每坐标≤20。恰有 m 个外坐标的互斥接收域可 tensor 后真实合计，得到 binomial(n,m)exp(−alpha(n−m))20^m。这里 tensor 的是固定核与接收域，不是 ν 的随机坐标。

对 r0<1/2，二项式定理取 t=r0/(1−r0)≤1 即可证 ∑_{m≤r0n}binomial(n,m)≤exp(nH(r0))，又 (20e^alpha)^m≤(20e^alpha)^(r0n)。用 H(r)≤r log(e/r)，

    H(r0)+r0log(20e^alpha)
      ≤r0[T+log T+alpha]≤2r0T=alpha/2.

最后由 log T≤T−1 与 alpha≤1 立即成立。因此 X7 的总上界 exp(−alpha n/2)=exp(−3epsilon n/8) 正确；floor 边界、m0=0 也涵盖。2^n/binomial 组合成本已明确在这个熵估计内，不是免费省略。

本命题始终只用 δ≤n，不建立或偷用 score=receiver mask 的错误关系。sparse 域是 m_b≤m0，允许最多 m0 个 overflow 坐标任意远。与已付 U_d 相交部分不用重付，新实际付款分支可限制为 S\U_d。m0=0 时差集不提供新覆盖，作者已经明确。

### 6.3 X8–X9 参数覆盖：通过

soft 网格向下取 sigma=s0exp(k/n)，sigma≤s<exp(1/n)sigma。hard 系数 1−s≤1−sigma，soft 系数 s≤exp(1/n)sigma，故每维 f_s≤exp(1/n)f_sigma，整个产品至多 e；节点数 floor(nlog(1/s0))+1≤1+nlog(1/s0)。这不是按坐标各选 soft。

尺度网格从 a 向上取相邻比≤exp(1/n)并包含 b；核的偶递减性给 P_{sigma,L}≤eP_{sigma,L'}，节点数≤n+2。合起来 p^(3/4) 的价格为 e^(3/2)，共享参数的网格总数为 N_sN_L，不能误计为其 n 次幂。接收 mask 用固定 b 定义，J/Cprod 不随该 soft/尺度节点改变，故 X9 的 supremum≤节点真实求和合法。

物理缩放时 p 总次数 3/4 与 J 总次数 1/4 相加为 1，核提供 b^(−n)，dx 提供 b^n，正好相消；Cprod 无量纲。未遗漏尺度幂。

### 6.4 X10–X11 原实际计价：在本轮恢复合同下通过

good 门与 chiJ 给 pchiJ≤min(p,KJ/(3wg))；min(A,B)≤A^(3/4)B^(1/4)，且 wg≥Cprod，所以 X10 正确，K 保留。rho 使用同一原 alpha_RC，只以上界 1 放松，没有重新优化余额。证明的指数常数 alpha 与 alpha_RC 分别定义，未混淆。

按本轮已恢复合同，固定 (omega,V,j,y,t) 时实际完整 Π_t 不依 x 或外 hard z。X9 对每个来源 v,u 统一，故 Tonelli 后可取两份真实 Π_t 的总质量≤1；不要求来源坐标独立，不要求 et 下界，也不以 Π_g 替代 Π_t。仍依 x 的终端 wg、rho、selected s,L 已分别由 wg≥Cprod、rho≤1 和实际参数网格覆盖处理，未被当前 t 的冻结隐式固定。

S 不依 hard z，相关非负资格可保留或上放后对其用一次原 16/3 硬帽。signed 2Lambda 合计 32Lambda/3；δ≤n 与统一时间长≤log2；唯一 j 安全数≤n+2，再乘 X9 的尺度数≤n+2。原期望、V/history 与 beta 按合同明确可复用的 RB16 聚合为 W_beta。因此准确得到

    (32Lambda/3)(K/3)^(1/4)e^(3/2)log2
       ×n(n+2)²[1+nlog(1/s0)]exp(−3epsilon n/8)W_beta.

这是 X11。硬来源已在该步消去，没有再次保留 raw h_R 领取额外收益或再乘 16/3。本审查使用本轮确认的原 RB16 聚合/时间/j 合同，未自行重写原来源接口证明。

### 6.5 X2 的显式常数：通过

n≥1 时 n+2≤3n、1+nlog(1/s0)≤n[1+log(1/s0)]，所以 X11 的多项式部分≤9n^4[1+log(1/s0)]。32/3×9=96。再由微分极值

    sup_{r≥0}r^(7/2)exp(−3epsilon r/8)
       =[28/(3e epsilon)]^(7/2),

得到作者 X2 的全部显式常数

    96Lambda (K/3)^(1/4)e^(3/2)log2 [1+log(1/s0)]
        [28/(3e epsilon)]^(7/2) sqrt(n) W_beta.

这里 s0/epsilon 的负幂、K 与 Lambda 的原依赖均保留，不能把 s0 随 n 下降时的费用藏成维数无关常数。

### 6.6 最终判定与未付范围

X3–X11 及最终 X2 在 R167 恢复的原合同下严格通过，给出任意相关来源的真实 sparse-overflow 正交通分支价格。按 S\U_d 使用不会与旧 receiver-near 双计。本审查没有把有限 I1 模型作为证明，也没有重证旧 near。

一般目标仍未闭合：低 soft s<s0，以及 s≥s0、x∉U_d、m_b>m0 的中/高 overflow 部分仍待付；若另稿给大 m 门，还必须检查中间 gap，不能由两端已付推断全部覆盖。

本指定作者后审完成并停止，不自行扩展补集命题。
