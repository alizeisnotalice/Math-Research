# R167：强制 soft mask、FIRST 上尾与混合幂支的选择器费用

状态：得到作用于同一真实来源 y 的 mask/FIRST 上尾预算，并为独立几何稿的混合幂稀疏外坐标支提供完整自适应费用。没有证明一般外 receiver 补集付款。只编辑本文件，不 Git，不 spawn；几何稿的单坐标常数由其作者及主代理独审，本稿不重复证明或冒称已经独审该常数。

## 1. 命题、量词和目标筛查

使用 R167 task_contract 及 R166 恢复的来源合同。对实际 receiver x 固定原共同当前参数 s=s(x)>0、L=L(x)∈[a,b]，b/a≤2。完整 FIRST 给

\[
 P_{s,L}f(x)=q,\qquad P_{s',L}f(x)\le q\quad(s'\ge s),
 \qquad\nu_V\le\beta_V\le fdx.
 \tag{1}
\]

原不交叶使逐种子 \(\sum_V\beta_V\le fdx\)。下面涉及所有叶合并的 receiver 行估计时，使用同一原当前 s,L 及同一完整 f；不允许每个被积分 y 选择自己的测试 s'，也不在不同子历史上重复领取 (1)。单叶版本可直接把 β 写为 β_V。

定义相对于同一来源 y 的外 core 坐标集合、数量、overflow：

\[
 E_y(x)=\{i:|x_i-y_i|>b/2\},\quad m_y(x)=|E_y(x)|,
 \quad O_y(x)=\sum_i(|x_i-y_i|-b/2)_+.
 \tag{2}
\]

原剩余是 O_y(x)>d_*。由于 L≤b，E_y(x) 内的坐标在原 h_L 支撑外，必用 soft 分量；但 O>d_* 不推出 m 大，一坐标可携带任意 overflow。

本稿分清三种预算：(i) 固定 receiver 的真实来源上尾，由 FIRST 支付；(ii) 几何稿固定来源的 x 积分，由其混合幂估计支付；(iii) 最终 raw 的 hard 帽、Π概率化、j 和时间费用。不会把 (i) 的 q|receiver set| 价格称为 Wβ column 价格，也不会把 mask 当成独立于 y、x 的额外随机来源。

## 2. 初步：完整 mask 展开，不隐去 2^n 项

记 \(h_{L,i}=L^{-1}h((x_i-y_i)/L)\)、\(\phi_{L,i}=L^{-1}\phi((x_i-y_i)/L)\)。完整展开为

\[
 p_s(x-y)=\sum_{S\subset[n]}s^{|S|}(1-s)^{n-|S|}
 \prod_{i\in S}\phi_{L,i}\prod_{i\notin S}h_{L,i}.
 \tag{3}
\]

这里确有 2^n 个 mask。每个非零项必须满足 E_y(x)⊂S。固定 x 后，定义真实同源的有限联合测度

\[
 d\Gamma_x(y,S)=q^{-1}s^{|S|}(1-s)^{n-|S|}
 \prod_{i\in S}\phi_{L,i}\prod_{i\notin S}h_{L,i}\,d\beta(y).
 \tag{4}
\]

其 y 边缘是 p_s(x-y)dβ(y)/q，总质量≤1，且 m_y(x)≤|S| 在其支撑上成立。式 (4) 只是原核的正分解；没有生成独立的 posterior，也没有将 β 概率化。

对 τ≥0，令 Z=1-s+s e^τ、s'=s e^τ/Z。逐点精确求和给

\[
 \sum_S e^{\tau|S|}s^{|S|}(1-s)^{n-|S|}
 \prod_{i\in S}\phi_{L,i}\prod_{i\notin S}h_{L,i}
 =Z^nP_{s',L}(x-y).
\]

s'≥s，故完整 FIRST 和 β≤f 给

\[
 \boxed{\int e^{\tau m_y(x)}\frac{p_s(x-y)}q,d\beta(y)
 \le\sum_S\int e^{\tau|S|}d\Gamma_x
 \le(1-s+s e^\tau)^n.}
 \tag{5}
\]

这是把全部 mask 精确求和后的价格；2^n 没有被忽略。它对所有 s∈(0,1] 成立，不花 s_0^{-1} 或尺度网格费用。测试只依当前 x 的 s、L 和选定 τ，同一行不依 y 重选。

## 3. 扩强：硬支撑内的 soft 底量降低上尾中心

设

\[
 a_\phi=\phi(1/2)\in(0,1),\qquad c=1-a_\phi\in(0,1).
\]

在 h 的支撑内，phi≥a_phi。对任意 s≤s'≤1，若坐标在 E_y(x) 内，原核比恰为 s'/s；若坐标不在 E_y(x) 内，则无论它位于 h_L 支撑内外都有

\[
 \frac{f_{s'}((x_i-y_i)/L)}{f_s((x_i-y_i)/L)}
 \ge\frac{1-cs'}{1-cs}.
 \tag{6}
\]

证明：在 h_L 内，比值是 \((1-s'+s'\phi)/(1-s+s\phi)\)，它对 φ 单调增加，最小值在 a_phi；在 h_L 外，比值 s'/s≥1，而右端≤1。原闭面上采用 h=1，phi≥a_phi 仍成立。

因此同一 y 逐点有

\[
 \frac{P_{s',L}(x-y)}{P_{s,L}(x-y)}
 \ge (s'/s)^{m_y(x)}
 \left(\frac{1-cs'}{1-cs}\right)^{n-m_y(x)}.
 \tag{7}
\]

令 r=cs，r'=cs'，并设

\[
 \tau=\log\frac{r'(1-r)}{r(1-r')},\qquad
 0\le\tau\le\tau_{\max}(s):=
 \log\frac{1-cs}{s(1-c)}.
\]

对 s<1，tau_max>0。将 (7) 与 FIRST 相接，得到严格更强的有限倾斜范围：

\[
 \boxed{\int e^{\tau m_y(x)}\frac{p_s(x-y)}q,d\beta(y)
 \le(1-cs+cs e^\tau)^n,
 \quad 0\le\tau\le\tau_{\max}(s).}
 \tag{8}
\]

这里不能把有限 τ 范围扩成任意 τ；s'=1 已是原 future 端点。特别地，s=1 时 tau_max=0，(8) 不给非平凡上尾，必须退回 (5) 或其它几何。s_0 只规定当前参数范围，不产生额外价格。

若整数 k 满足 nr≤k≤nc，可选 r'=k/n（从而 s'=k/(cn)≤1），直接从 (8) 得

\[
 \int_{\{m_y\ge k\}}\frac{p_s}q,d\beta
 \le\exp\{-nD(k/n\Vert r)\},
\quad D(a\Vert r)=a\log(a/r)+(1-a)\log((1-a)/(1-r)).
 \tag{9}
\]

若 k>nc，则用 r'=c 得真实的端点线性指数，不能继续使用未经授权的二项率函数最优点。具体地，记 z=k/n，端点速率为

\[
 I_s(z)=z\tau_{\max}(s)-\log\frac{1-cs}{1-c},\quad c\le z\le1.
 \tag{9a}
\]

在 z=c 与二项率函数连续接合，z=1 时恰为 I_s(1)=−log s。因此这套有限倾斜证书要达到 n^{-A}，至少需要 n log(1/s)≥A log n；这不是声称实际来源尾必定达到该上界。特别 s=1−1/n 时最强指数仅为常数量级，不能认证任意多项式抑制，s=1 时完全退化。高 soft 补集必须保留，不能藏入“中间段”或把超过 n 的阈值当成覆盖证明。式 (8) 是两个情况统一且无歧义的接口。

### 3.1 不引用外部尾定理的显式界

令 g(τ)=log(1-r+r e^τ)。直接微分可得 g(0)=0、g'(0)=r，且 g''=r_τ(1-r_τ)≤1/4，因此

\[
 g(\tau)\le r\tau+\tau^2/8.
\]

对 Δ>0，用 (8) 并取 \(\tau=\min(4\Delta/n,\tau_{\max})\)，得到

\[
 \boxed{\int_{\{m_y-ncs\ge\Delta\}}\frac{p_s}q\,d\beta
 \le\exp\!\left[-\min\left(\frac{2\Delta^2}n,
                         \frac{\tau_{\max}(s)\Delta}2\right)\right].}
 \tag{10}
\]

若 s∈[s_0,s_1]、s_1<1，则 tau_max(s)≥tau_*:=tau_max(s_1)>0。任意 H>0，取

\[
 \Delta_H=\max\left\{\sqrt{nH/2},\,2H/\tau_*\right\}
 \tag{11}
\]

即可将上尾压至 e^{-H}，统一于全部 L∈[a,b] 和 s∈[s_0,s_1]，不取 receiver 参数 supremum 后误用 FIRST。若阈值超过 n，事件为空，结论仍成立。

对于整个 [s_0,1]，(5) 给不截断版本

\[
 \int_{\{m_y-ns\ge\Delta\}}p_s\,d\beta/q
 \le e^{-2\Delta^2/n}.
 \tag{12}
\]

由 (10) 层饼积分还可核验

\[
 \int(m_y-ncs)_+\,p_s\,d\beta/q
 \le\frac{\sqrt{\pi n}}{2\sqrt2}+\frac2{\tau_*},
 \tag{13}
\]

因为 e^{-min(A,B)}≤e^{-A}+e^{-B}。这是 receiver 行的超额计数根阶控制；不控制完整 m 的 ncs 部分，更不直接等同于原 δ 的根阶预算。

## 4. 与原 δ、direct 核及 raw 的准确联系

令 \(d_i=1_{\{C_i(v)<\xi\}}-1_{\{C_i(u)<\xi\}}\)。则原 \(\delta=(\sum_i d_i)_+\) 满足精确的坐标分解上界

\[
 \delta\le\left(\sum_{i\notin E_y(x)}d_i\right)_+
          +\left(\sum_{i\in E_y(x)}d_i\right)_+
 \le\delta_{\rm core}+m_y(x).
 \tag{14}
\]

但是没有 \(\delta\le m_y\) 的一般结论：m 的定义只含 x,y；k 的定义含 y,v,u，core 坐标仍可贡献最多 n-m 的正 score。取全部 C_i(v)<ξ、全部 C_i(u)≥ξ 的代数配置即有 δ=n，而 receiver 可只有一个外坐标。该配置仅说明不能从 mask 恒等式推出更强点态不等式，不冒称它实现全部 good/high/rho/FIRST/history 门。

对 direct 混合核也不能免费丢 mask 数。对 0<α<1，若从 (3) 逐项用 \((\sum A_S)^\alpha\le\sum A_S^\alpha\)，仅权重和就变为

\[
 \sum_{S\supset E}s^{\alpha|S|}(1-s)^{\alpha(n-|S|)}
 =s^{\alpha m}[s^\alpha+(1-s)^\alpha]^{n-m}.
 \tag{15}
\]

它通常有指数增长。把 2^n 项按 |S| 分组为 n+1 项并不会自动消除 (15)：先平均 mask 再取凹幂的方向不足以用逐 mask 积分上界。故本稿没有从 (5) 声称 direct 核的免费 n+1 包络，也没有将 J_v/C_i 与 y 的尾事件设为独立。

**真实 raw 的大 m 分支。** 取 receiver 集 \(\mathcal E\)，保留其原门，并限制来源到

\[
 A_H(x)=\{y:m_y(x)\ge ncs(x)+\Delta_H\}
\]

（用于 s≤s_1<1；全 [s_0,1] 可改用 (12) 的 ns 阈值）。由于这是同一来源 y 的筛选，它与外硬 z 无关，可以合法使用一次 hard 帽

\[
 q^{-1}\int h_R(x-z)a_\omega(x,y,z)d\nu_V(z)\le16/3.
\]

再仅用 rho≤1、chi_J≤1、δ≤n、两份 Π_t 质量≤1、时间长度≤log2、j 数≤n+2，以及逐种子不交叶之和β≤f，得到

\[
 \boxed{\operatorname{raw}(A_H)
 \le 2\Lambda\frac{16}3\,n(n+2)\log2\;q|\mathcal E|\,e^{-H}.}
 \tag{16}
\]

同一 receiver 的 FIRST 估计用于叶合并后的 β；没有给每叶分别领取 q 再相加。这里保守支付 n+2，未借“唯一 j”再省一因子。若原不同标签使用不同当前 s,L，必须沿实际共同选择器合同合并；(16) 不授予每标签免费不同 FIRST 测试。

给定 ζ∈(0,1)，令 \(H=\log[n(n+2)/\zeta]\)，便有

\[
 \operatorname{raw}(A_H)\le
 2\Lambda\frac{16}3\log2\;\zeta q|\mathcal E|.
 \tag{17}
\]

这是明确可用于吸收的 receiver 体积价格，阈值费用为
\(\sqrt{n\log(n/\zeta)}+\tau_*^{-1}\log(n/\zeta)\)。没有将它称为 Wβ 付款；是否能吸收、吸收系数多大，须代回主稿的实际 receiver 量定义。same-alpha 未重算；rho 只作合法上放。hard 帽只用一次。

## 5. 与独立稀疏几何支配合：只支付自适应费用

triple_geometry 提供待其独审的固定来源、固定参数支：对 α=3/4 的真实比较核

\[
 p\chi_J1_G\le(K/3)^{1/4}p^{3/4}(J/w_g)^{1/4}
 \le(K/3)^{1/4}p^{3/4}(J/\prod C_i)^{1/4},
\]

按 m 外 core 坐标有 \(\binom nm A^{n-m}B^m\)，并在其明确的稀疏范围 \(m\le m_*\) 上推出 \(e^{-\kappa n}\) 型积分。该稿负责 A、B、m_*、κ 的证明，本稿只给如下严格选择器接口：

> 若对全部固定 s∈[s_0,1]、L∈[a,b]、全部来源 y,v，同一个基于 b 的集合 \(\{m_y(x)\le m_*\}\) 上，\(\int p_{s,L}^{3/4}(J_v/\prod C_i)^{1/4}\le e^{-\kappa n}\)，则允许任意 receiver 当前 s(x),L(x)，代价至多 \(e^{3/2}N_LN_s\)。

证明不重做 R166 网格，而直接使用其已核单调舍入：L 向上、s 向下，倍率间隔 e^{1/n}，含 b 端点；

\[
 p_{s,L}\le e^2p_{\sigma,L'},\quad
 N_L\le n+2,\quad N_s\le1+n\log(1/s_0).
\]

因此混合幂核逐点至多 \(e^{3/2}\) 倍对应节点核。外 core 集合由 x,y,b 决定，与舍入无关，J/C 也无须覆盖；有限正求和给

\[
 \int_{\{m_y\le m_*\}}
 \sup_{L,s}p_{s,L}^{3/4}(J/\prod C_i)^{1/4}dx
 \le e^{3/2}(n+2)[1+n\log(1/s_0)]e^{-\kappa n}.
 \tag{18}
\]

s_0=1 时软度只有一个节点；s_0>0 是此接口必要范围。这里不采用 (15) 的凹幂 mask 展开，因它会付指数费用。

原 m 支与外 hard z 无关，故一次 hard 帽后，固定 ξ 的 Π²在 dx 外。由 uniform-v 的 (18)，积分两份 Π≤1，再支付 j≤n+2、δ≤n 和 log2，得到这一几何支的真实费用

\[
 2\Lambda\frac{16}3\log2\,(K_{\max}/3)^{1/4}e^{3/2}
 n(n+2)^2[1+n\log(1/s_0)]e^{-\kappa n}W_\beta.
 \tag{19}
\]

如果 K 没有统一已付帽，K 因子须留在原标签积分，不能取 K=1。若几何稿固定节点界另有显式常数，也应原样乘入 (19)。对于 n≥1，

\[
 n(n+2)^2[1+n\log(1/s_0)]\le9[1+\log(1/s_0)]n^4,
\]

\[
 n^4e^{-\kappa n}\le
 \left(\frac7{2e\kappa}\right)^{7/2}\sqrt n.
 \tag{20}
\]

因此该稀疏支的适应参数不会破坏根阶；完整费用是 \([1+\log(1/s_0)]\kappa^{-7/2}\) 及 (19) 的显式常数。它不是为一般补集领取预算，而是几何稿统一节点收缩成立后的准确支付接口。

## 6. 已有压力、扩大范围和停止点

初步：(3)–(5) 给完整 mask 结构和无遗漏的 FIRST 生成函数。已知压力：(14)–(15) 说明 forced mask 不自动控制 δ，也不允许在 direct 凹幂核里免费忽略 mask 数；一坐标任意大 overflow 又说明外 U_d 不自动落在大 m 上尾。

扩大：(8)–(17) 把上尾中心从 ns 降至 ncs，给全尺度、全部中间软度段的真实 receiver 行价格；(18)–(20) 给独立稀疏几何支的连续参数与 raw 费用。整个 [s_0,1] 的无上门版本仍有 (5)、(12)，但改进中心 cs 的 τ_*费用在 s_1→1 时发散，不能藏入常数。

和几何稿合并后，若其稀疏门是 \(m\lesssim\varepsilon n/\log(C/\varepsilon)\)，本稿大 m 门约为 \(m\gtrsim csn+\sqrt{n\log n}\)。两门之间通常有非空数量带。其 direct 核／原 score 是否能联合支付仍未证。尤其不能因为两个极端层都可控就声称覆盖全部 O>d_* 的真实补集。

本稿未作数值试验，所有上界均由显示的恒等式、不等式、有限求和及单变量微分推导。未重算 same-alpha，未重做 R166 near 支或裸尺度线性工具；未将有限 source 配置宣称 FULL。交付至此停止。
