# R167：高接收峰度、同 alpha 与真实 bad 核矩的有界检查

状态：本路线没有取得新的完整外部付款。它把 full FIRST 与 same-alpha 的实际 reserve 写成非负分解，并把高 overflow 坐标数强制出的指数因子接到**当前** bad 后验的 K0/wt 一阶矩上。该矩只有上界，不能据此支付低核比坏源；再用高核比截断会回到 R144 已有接口，本文不重复登记。最具体未证步骤在 §5。

## 1. 原对象与路线边界

读 R167 task_contract、R166 source_contract/实际 rho 定义，并定向核 R144 capacity.md C1–C9。只研究原近接收集合补集

    D_b(x,y):=Σi(|xi−yi|−b/2)+>d*，

并以 m(x,y)=#{i:|xi−yi|>b/2} 标记其中高坐标数部分。m大和D_b大不是同一条件；本文不把该计数换成总距离。纯几何低m路线、soft-mask/Chernoff路线由其他作者处理，本稿不重复。

固定同一实际行的 s,L,R,g,wg、same-alpha、T、Δv及原 good/bad。q为完整FIRST共同水平，P_s,L f(x)=q，K0f(x)≤q，QJ=∫Jdν≤q；ν≤β≤f dx。当前 t 固定后，Πt不依x/外hard z，终端资格和alpha仍依x。所有积分中的bad均是原终端bad Dg（或其实际子集D0），不是新来源标签。high为p eg≥2Kq。

不把q改为三测试最大值，不把alpha改成有利数值；外hard来源z不与内bad u合并。原所有资格、low-c、history、唯一j仍在原正交通，下面仅作逐行必要估计。全文没有使用一次hard帽来宣称尚未取得的全局价。

## 2. 接收峰度上界保留实际 eg/q

置

B_s=(1−s)+sφ(0)，
Pmax=L^(−n) B_s^n，
ζ_s,L=sφ(b/(2L))/B_s∈(0,1)。                                 (ER1)

每个外b-core坐标的hard部分为零，且φ在正半轴递减；其余坐标f_s≤B_s。因此对全部原合法s>0,L≤b，

    p=P_s,L(x−y)≤Pmax ζ_s,L^m。                              (ER2)

原high随即给真实必要条件

    m log(1/ζ_s,L)≤log[Pmax eg/(2Kq)]。                       (ER3)

右端负时该实际high行为空。ER3不提供其右端的统一上界：eg是原全部存活来源的wg质量，q是完整输入的FIRST水平。ν≤β提供质量支配，既不提供eg/q的常数帽，也不授权把β换成ν。不能删除high后将右端的log来源比作为已付费用。

## 3. 同 alpha 的 full-input reserve 恒等式

令原

U(u)=1_{原有效good} min(TΔu,DK0u)，
c(u)=U(u)/(DK0u)∈[0,1]，
R0=q−D^(−1)∫U dν=alpha QJ/D。                               (ER4)

s>0确保K0u>0；原退化零交通行先排除。把 f dx写成输入测度F，因ν≤F，

    τ=F−cν=(F−ν)+(1−c)ν≥0。

完整FIRST给精确非负分解

    R0=[q−K0F(x)]+∫K0(x−u)dτ(u)。                           (ER5)

第一项来自合法future K0的完整输入差额；第二项同时含F−ν、未捕获的good、原bad及其他未消耗来源。尤其τ≥(β−ν)+(1−c)ν，但不能丢掉其中各项后又把它们当成独立的alpha余额重复支出。

原Dg上U=0，故

    ∫Dg K0u dν(u)≤R0=alpha QJ/D。                            (ER6)

ER5说明恢复完整FIRST的实际作用：alpha不能由截取ν的测试自行重算；完整输入外的reserve仍在。它没有给R0的正下界，更没有给eg的上界。若alpha=0，则由ER6与K0>0，原bad来源为零，原正交通为零；不能据此把alpha很小时的bad后验概率直接判小。

## 4. 高峰度强制的当前 bad 一阶核矩

定义实际当前核比

    κt(u)=K0u/wt(u)。

Dg⊂Zg⊂Zt，因此固定原t后有准确式及同行界

∫Dg κt(u)dΠt(u)
 =et^(−1)∫Dg K0u dν(u)
 ≤alpha QJ/(D et)
 ≤alpha q/(D et)
 ≤alpha p/(2DK)。                                            (ER7)

最后一步只用原et≥eg与high，未取source supremum，也没有以Πg替代Πt。ER7对实际bad子域D0仍有效。它是直接处理当前归一的同行矩，而不是把接收积分中的et拔除。

对实际正余good v，令

Av=TΔv−DK0v>0，dv=Av/(TΔv)∈(0,1]。

rho_v>0等价于alpha Jv<Av，故ER7和ER2给

    ∫Dg κt dΠt < p Av/(2DKJv)
                   ≤Pmax ζ_s,L^m Av/(2DKJv)。                (ER8)

保留rho与同一个alpha的共同消耗，而非分别取最坏值，还能写成

rho_v∫Dg κt dΠt
 ≤[p/(2DK)] alpha(dv−alpha Jv/(TΔv))+
 ≤p TΔv dv²/(8DKJv)
 ≤Pmax ζ_s,L^m TΔv dv²/(8DKJv)。                             (ER9)

中间仅用一元二次式最大值TΔv dv²/(4Jv)。没有选取新的alpha，且不同v之间并不相加领取多个reserve；ER9只是一条对原actual alpha同时成立的数值上界。

**方向审计。** ER8–9在m大时强制K0/wt的bad一阶矩很小，却不强制bad后验质量很小。原正交通恰可能保留在κt很小的来源上。Markov从该式只能估计高κt集合的质量，不能估计低κt集合，更不能把ζ^m直接乘到原未加κt的δ交通上。

若先改用terminal bad，则由good和q≥∫Qν，Πg(Dg)≥1/2。令其条件均值为barκg，则同样推得

    barκg < p Av/(DKJv)。                                    (ER10)

ER10是对整个terminal bad分布的必要条件；不能把“至少一半后验为bad”移给其实际严格score子集D0，也不能在current t上免费保留该一半。

## 5. 与旧高核比付款的准确接缝及未证步骤

在δ(v,u)>0处，R144真实pair核比为

c_pair(v,u)=D K0u Jv et/[TΔv QJ wt(u) δ(v,u)]
          =[D Jv et/(TΔv QJ)] κt(u)/δ(v,u)。                  (ER11)

因此把ER7–9除以一个κt下门、再在good来源上平均，仍只是“高核比容量→低核比补集”的老路线。R144 C5已给更准确的rho平方容量证书；其合法付款域和原low-c补集不可扩大后重报。本文没有把ER9改名成新的根阶分支。

本轮余下高m问题的精确位置是：在保留原low-c、positive rho、high与完整FIRST时，需估计**同一个接收积分**中的

    p ·rho_v χJ_v δt(v,u)
    ·1_{D_b>d*} ·1_{m≥m0} ·1_{原low-c}
    dΠt(v)dΠt(u) dx dβ(y)，                                 (ER12)

并恢复原hard、history、唯一j、时间及外2Λ账。ER8–9在该量中额外插入κt才有指数上界；目前没有证明可把该κt取消，或用源质量Wβ支付其逆因子。一个可用的新论证必须联合小κt的真实u位置、good v位置、外部接收x、原δ及同一Πt；对κt先取source最坏值会丢掉本来需要的几何信息。

若合法使用一次hard帽，则外系数变为32Λ/3，ER12还须有完整的dx、dβ、dt/t与j预算，不能再保留hR并加第二个16/3。若靠逐行数值帽使来源先消尽，可利用共同原时间窗与唯一j合并；若靠固定来源接收积分，则Πt只能在固定(j,y,t)后移出，j费用须明确。本文没有达到这两种完整付款入口的任一种。

另一种等价的缺口是ER3右端的高来源比：即使ER5精确保留全部full-input reserve，仍未得到在ER12的实际测度下控制log[Pmax eg/(2Kq)]的根阶总预算。将这个log或所需逆核矩命名为“新范数/熵”不会消除费用，本文不这样登记。

## 6. 三阶段核验和结论

初步：逐式核q为共同FIRST水平、K0为合法future、U在原bad上为零；ER5为非负测度恒等式，ER7保留实际et，ER8保留同一个alpha。零QJ/et/Δ及alpha=0均沿原零交通定义，不对零取商。

已有压力：主代理报告原I1全exterior因p上界约0.09338而high所需p约0.60899而严格不可能。本稿未重跑该有限数值，亦不以该模型宣称一般外域为空。它只说明不能在原样本自由改p/q制造exterior，必须保留eg、完整共同q和实际lambda。旧R144低核比剩余正是ER9不可取消κt的压力点，不能回报其高核支为新结果。

扩大范围：ER1–11是任意相关来源、任意合法接收选择器、全部n与原s>0的解析关系；但没有从这些必要关系得到原一般高m的外预算。本稿没有构造新的有限FULL模型，也没有声称低κ坏源的抽象概率模型就是几何反例。

交付结论：新增的是对本轮高峰度路线的准确同alpha/full-FIRST核验与停止位置，不是新增已付子支。一般receiver补集仍UNPROVED；下一步须真正处理ER12中低K0/wt坏源的联合接收几何，或给ER3来源比在同一原测度下的有效预算。到此停止。
