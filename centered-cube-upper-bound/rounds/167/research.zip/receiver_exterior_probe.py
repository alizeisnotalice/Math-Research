#!/usr/bin/env python3
"""R167 frozen-model receiver-exterior checks; no new sources or FULL claim."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import importlib.util
import hashlib
import json
import math

HERE=Path(__file__).resolve().parent
PRODUCER=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015_final_checkpoint/work/receiver_probe.py')
POINTS=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json')
spec=importlib.util.spec_from_file_location('r151_exterior',PRODUCER)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
mp=old.mp;mp.mp.dps=70


def mf(x):
    return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(str(x))


def distance(xq,y,b):
    return sum((max(abs(xq[i]-y[i])-b/2,F(0)) for i in range(len(xq))),F(0))


def main():
    template=next(x for x in json.loads(old.R136.read_text())['cases'] if x['id']=='I1')
    model=old.build(template,json.loads(old.R142.read_text())['cases']['I1'])
    data=json.loads(POINTS.read_text())['point_records'];allrows=data['8']
    rows=[r for r in allrows if r['after'] and r['gates']['high'] and r['I']>0]
    assert len(rows)==8
    y=[F(str(template['parameters']['y']))]*4;b=model['bF'];s0=mp.mpf('.25')
    eta=2*(mp.expint(4,mp.mpf('.5'))-mp.expint(4,mp.mpf('1.5')))
    eps=s0*eta;Lphi=2/(1-mp.exp(-1));theta=Lphi+(16+8*mp.exp(Lphi))/eps
    dstar=mf(b)*model['n']*eps/(8*theta)
    def classify(r):
        xx=[old.Fq(v) for v in r['xq']];d=distance(xx,y,b)
        return dict(xq=r['xq'],D_exact=old.fstr(d),exterior=mf(d)>dstar,
                    b_core_coordinate_margin_exact=old.fstr(min(b/2-abs(xx[i]-y[i]) for i in range(len(xx)))),
                    after=r['after'],high=r['gates']['high'],I=r['I'],
                    dx_weight_corrected=r.get('dx_weight_corrected'))
    initial=[classify(r) for r in rows]
    saved=[classify(r) for r in allrows]
    positive_saved=[r for r in saved if r['after'] and r['high'] and r['I']>0]
    # Exact rational frozen-model exclusion: phi<=1, one outside b-core
    # coordinate has no hard p term since L<b. No special-function bounds enter
    # this comparison, although lamF/wgF themselves are producer input numbers.
    egF=sum((model['nuF'][i]*model['wgF'][i] for i in range(6)),F(0))
    simple_upper=model['sF']/model['LF']**model['n']
    p_required=F(3,2)*model['KF']*model['lamF']/egF
    rational_excluded=simple_upper<p_required
    assert rational_excluded and model['LF']<b
    f0=1-model['s']+model['s']*float(old.phi_np([0.])[0])
    tighter_upper=model['s']*float(old.phi_np([float(b/(2*model['LF']))])[0])*f0**3/model['L']**4
    # Bounded boundary pressure. Every point is an exact rational point only;
    # no dx cell or implied positive volume is attached.
    pts={}
    offsets=[F(0),F(1,10**6),F(1,10**5),F(1,1000),F(1,100),F(1,20),F(1,10)]
    for base in ([F(0)]*4,[F(1,10)]*4,[F(3,10)]*4):
        for axis in range(4):
            for sign in (-1,1):
                for offset in offsets:
                    xx=list(base);xx[axis]=y[axis]+sign*(b/2+offset)
                    pts[tuple(xx)]='core_boundary_pressure'
    for r in rows:
        for axis in range(4):
            for sign in (-1,1):
                for offset in (F(0),F(1,10**5),F(1,1000),F(1,100),F(1,20)):
                    xx=[old.Fq(x) for x in r['xq']];xx[axis]=y[axis]+sign*(b/2+offset)
                    pts[tuple(xx)]='old_positive_to_boundary'
    tested=[]
    for xx,kind in pts.items():
        r=old.one_point(model,list(xx),template);d=distance(list(xx),y,b)
        hi=r['p']*model['eg']/(2*model['K']*r['q']) if r['q']>0 else 0.
        flo=r['q']/(.75*model['lam'])
        tested.append(dict(kind=kind,xq=r['xq'],D_exact=old.fstr(d),exterior=mf(d)>dstar,
                           p=r['p'],q=r['q'],alpha=r['alpha'],rho=r['rho'],
                           high_ratio=hi,lambda_lower_ratio=flo,joint_necessary_ratio=min(hi,flo),
                           after=r['after'],I=r['I'],hard_sources=r['hard_sources'],failure_gates=r['failure_gates']))
    ext=[r for r in tested if r['exterior']]
    best=sorted(ext,key=lambda r:r['joint_necessary_ratio'],reverse=True)[:6]
    supported=[r for r in ext if any(r['hard_sources'])]
    best_supported=sorted(supported,key=lambda r:r['joint_necessary_ratio'],reverse=True)[:4]
    # Three explicit old-boundary points, no large mp expansion.
    mpchecks=[]
    for xx in ([F(-20001,100000),F(0),F(0),F(0)],
               [F(80001,100000),F(3,10),F(3,10),F(3,10)],
               [F(-201,1000),F(-1,16),F(-1,16),F(5,16)]):
        check=old.mp_check(model,template,xx)
        r=old.one_point(model,xx,template)
        check['float_rel_p_error']=float(abs(mf(r['p'])/mp.mpf(check['p'])-1))
        check['float_rel_q_error']=float(abs(mf(r['q'])/mp.mpf(check['q'])-1))
        check['D_exact']=old.fstr(distance(xx,y,b));mpchecks.append(check)
    out=dict(scope='Frozen R151 I1 six-source model with original producer q=max-three and same-alpha; necessary implementation gates, not FULL common-FIRST certification.',
             inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (PRODUCER,POINTS,old.R136,old.R142)},
             parameters=dict(n=model['n'],s=model['s'],s0=.25,L=model['L'],b=float(b),y=[old.fstr(x) for x in y],
                             lambda_model=model['lam'],eg=float(egF)),
             receiver_gate=dict(D='sum_i (abs(x_i-y_i)-b/2)+',eta=mp.nstr(eta,35),epsilon=mp.nstr(eps,35),
                                Lphi=mp.nstr(Lphi,35),theta=mp.nstr(theta,35),dstar=mp.nstr(dstar,35)),
             stages=dict(initial_eight=initial,
                         saved_m8=dict(total_rows=len(saved),after_rows=sum(r['after'] for r in saved),
                                       positive_after_high_rows=len(positive_saved),exterior_positive_after_high=[r for r in positive_saved if r['exterior']],
                                       existing_dx_weights='Original corrected orbit/cell weights retained on saved rows; no weights attached to new point searches.'),
                         boundary_pressure=dict(point_count=len(tested),exterior_points=len(ext),
                                                hard_supported_exterior_points=len(supported),
                                                exterior_after_high_positive=sum(r['after'] and r['I']>0 for r in ext),
                                                exterior_joint_high_lambda_pass=sum(r['high_ratio']>=1 and r['lambda_lower_ratio']>=1 for r in ext),
                                                exterior_failure_counts=dict(Counter(g for r in ext for g in r['failure_gates'])),
                                                best_joint_necessary_points=best,
                                                best_hard_supported_joint_necessary_points=best_supported),
                         expanded='No m16 or free parameter/source expansion: the frozen-model rational p/high/lambda exclusion already rules out every exterior point.'),
             frozen_model_exclusion=dict(assumptions='Original fixed s=.25,L=.9<b=1,n4, fixed lambda_model and eg; necessary high and q>=.75*lambda_model.',
                                        argument='For D>0 at least one abs(x_i-y_i)>b/2>L/2, so its hard p factor vanishes. Since phi<=1, p<=s/L^n. High and lambda_lower require p>=3K*lambda_model/(2eg).',
                                        p_exterior_simple_upper_exact=old.fstr(simple_upper),p_exterior_simple_upper=float(simple_upper),
                                        p_required_exact=old.fstr(p_required),p_required=float(p_required),
                                        strict_rational_comparison=rational_excluded,
                                        p_required_strictly_gt_3_over_5=p_required>F(3,5),
                                        simple_upper_strictly_lt_2_over_5=simple_upper<F(2,5),
                                        tighter_phi_exterior_upper_float=tighter_upper,
                                        scope_caveat='Exact comparison treats frozen lamF/nuF/wgF decimals as rational model inputs; it does not certify the full kernel/FIRST source model.'),
             mp70_checks=mpchecks,
             summary=dict(old_eight_D_all_zero=all(r['D_exact']=='0' for r in initial),
                          old_eight_receiver_gate_coverage=8,
                          saved_m8_exterior_positive_count=sum(r['exterior'] for r in positive_saved),
                          boundary_search_exterior_positive_count=sum(r['after'] and r['I']>0 for r in ext),
                          fixed_model_no_exterior_necessary_gate_points=rational_excluded,
                          max_mp_rel_p_q_error=max(max(r['float_rel_p_error'],r['float_rel_q_error']) for r in mpchecks)),
             limitations=['Source-near failure in R165 does not imply receiver-near failure; all eight old positive receivers are in the b-core.',
                          'No new point is assigned dx volume; finite boundary samples alone do not prove absence.',
                          'Frozen-model necessary-gate exclusion is narrower than a FULL theorem and does not cover varying source/soft/lambda models.',
                          'The true receiver-exterior branch of the general problem remains unpaid.'])
    (HERE/'receiver_exterior_probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(receiver_gate=out['receiver_gate'],summary=out['summary'],
                         pressure_counts={k:v for k,v in out['stages']['boundary_pressure'].items() if not k.startswith('best_')}),indent=2))


if __name__=='__main__':
    main()
