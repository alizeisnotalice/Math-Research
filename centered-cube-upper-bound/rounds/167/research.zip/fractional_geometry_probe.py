#!/usr/bin/env python3
"""Finite checks of R167 X5/X6 and the small-exterior-coordinate sum.

theta=1/4. These are fixed-kernel numerical diagnostics, not source supremum or
original-traffic certificates. No old I1 receiver-exterior search is repeated.
"""
from pathlib import Path
import importlib.util
import json
import math
import hashlib

HERE=Path(__file__).resolve().parent
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
spec=importlib.util.spec_from_file_location('fractional_kernel_tools',DEP)
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
old,np,mp=tool.old,tool.np,tool.mp
RADIUS=80.
NODES={n:np.polynomial.legendre.leggauss(n) for n in (48,96)}
C0=7/24*(1-math.exp(-1))**2
APHI=2*math.sinh(.5)
ETA=tool.ETA


def cuts(lo,hi,L,V,max_step=2.):
    base=sorted(set([lo,hi]+[x for x in (-L/2,L/2,V-.5,V+.5) if lo<x<hi]))
    result=[lo]
    for l,h in zip(base[:-1],base[1:]):
        result.extend(np.linspace(l,h,max(1,math.ceil((h-l)/max_step))+1)[1:].tolist())
    return result


def integrate(s,L,V,lo,hi,order):
    cc=cuts(lo,hi,L,V);left,right=np.array(cc[:-1]),np.array(cc[1:])
    nd,wt=NODES[order]
    x=(left[:,None]+right[:,None])/2+(right-left)[:,None]/2*nd[None,:]
    p=((1-s)*(np.abs(x)<=L/2)+s*old.phi_np(x/L))/L
    ratio=old.phi_np(x-V)/tool.C(V)
    h=p**.75*ratio**.25
    return float(np.sum((right-left)/2*(h@wt)))


def evaluate(s,L,V,stage,label):
    co48=integrate(s,L,V,-.5,.5,48);co=integrate(s,L,V,-.5,.5,96)
    ou48=integrate(s,L,V,-RADIUS,-.5,48)+integrate(s,L,V,.5,RADIUS,48)
    ou=integrate(s,L,V,-RADIUS,-.5,96)+integrate(s,L,V,.5,RADIUS,96)
    constant=(3*APHI*s)**.75*(3/C0)**.25
    tail=4*constant*math.exp(-RADIUS/2)/math.sqrt(1+RADIUS)
    x6=4*math.exp(-.25)*constant
    core_bound=(1-s*ETA)**.75;outer_bound=20*s**.75
    return dict(stage=stage,label=label,s=s,L_over_b=L,V=V,core=co,outer_window=ou,
                outer_uniform_tail_upper=tail,outer_plus_tail=ou+tail,
                core_X5_bound=core_bound,outer_X6_analytic_bound=x6,outer_20s75_bound=outer_bound,
                core_X5_ratio=co/core_bound,outer_20s75_ratio=(ou+tail)/outer_bound,
                X6_constant_over_20s75=x6/outer_bound,
                GL48_GL96_core_abs_difference=abs(co48-co),GL48_GL96_outer_abs_difference=abs(ou48-ou))


def logadd(a,b):
    if a==-math.inf:return b
    if b==-math.inf:return a
    m=max(a,b);return m+math.log1p(math.exp(-abs(a-b)))


def log_binomial_sum(n,m0,logcore,logouter):
    term=n*logcore;result=term
    for m in range(m0):
        term+=math.log(n-m)-math.log(m+1)+logouter-logcore
        result=logadd(result,term)
    return result


def mp_reference(s,L,V):
    mp.mp.dps=50
    ss,ll,vv=[mp.mpf(str(x)) for x in (s,L,V)]
    def h(x):
        p=((1-ss)*int(abs(x)<=ll/2)+ss*old.phi_mp(x/ll))/ll
        return p**mp.mpf('.75')*(old.phi_mp(x-vv)/tool.mp_C(vv))**mp.mpf('.25')
    def q(lo,hi):
        points=[mp.mpf(str(x)) for x in cuts(lo,hi,L,V,4.)]
        return sum(mp.quad(h,[a,b]) for a,b in zip(points[:-1],points[1:]))
    return q(-.5,.5),q(-RADIUS,-.5)+q(.5,RADIUS)


def main():
    rows=[evaluate(.25,.9,-1.1,'initial','I1 physical y=.3,v=-.8 => V=-1.1'),
          evaluate(.25,.9,0.,'initial','center v=y => V=0')]
    rows += [evaluate(s,L,V,'pressure','finite source/scale/soft pressure')
             for s in (.001,1.) for L in (.5,1.) for V in (-32.,-8.,0.,8.,32.)]
    rows += [evaluate(s,L,V,'expanded','far source ±64')
             for s in (.001,.25,1.) for L in (.5,.9,1.) for V in (-64.,64.)]
    combinations=[]
    for s0 in (.001,.25,1.):
        epsilon=s0*ETA;alpha=.75*epsilon;T=math.log(80*math.e/alpha);r0=alpha/(4*T)
        candidates=[r for r in rows if r['s']>=s0]
        for n in (4,64,4096,65536,1000000):
            m0=math.floor(r0*n)
            coarse=log_binomial_sum(n,m0,-alpha,math.log(20))
            finite=[]
            for r in candidates:
                value=log_binomial_sum(n,m0,math.log(r['core']),math.log(r['outer_plus_tail']))
                finite.append((value,r))
            worst,r=max(finite,key=lambda x:x[0])
            combinations.append(dict(s0=s0,n=n,epsilon=epsilon,alpha_decay=alpha,T_epsilon=T,r0=r0,m0=m0,m0_over_n=m0/n,
                                     coarse_X7_log_sum=coarse,X7_log_bound=-alpha*n/2,
                                     coarse_log_margin=-alpha*n/2-coarse,
                                     finite_uniform_source_log_sum_max=worst,
                                     finite_worst_case=dict(s=r['s'],L_over_b=r['L_over_b'],V=r['V']),
                                     note='Finite homogeneous repeated-coordinate examples only; no source supremum or arbitrary product-source hypothesis.'))
    refc,refo=mp_reference(.25,.9,-1.1)
    reference=dict(s=.25,L_over_b=.9,V=-1.1,mp50_core=mp.nstr(refc,30),mp50_outer_window=mp.nstr(refo,30),
                   core_abs_error=float(abs(mp.mpf(rows[0]['core'])-refc)),outer_abs_error=float(abs(mp.mpf(rows[0]['outer_window'])-refo)))
    out=dict(scope='Finite fractional-kernel X5/X6 implementation checks only. theta=.25,b=1,X=(x-y)/b,V=(v-y)/b. No original receiver search or FULL claim.',
             inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (DEP,Path(old.__file__))},
             formulas=dict(H='p_s,L(X)^.75 * (phi(X-V)/C(V))^.25',core='abs(X)<=.5',outer='abs(X)>.5',
                           core_cap='(1-s*eta)^.75',outer_cap='20*s^.75',
                           eta=ETA,c0=C0,a_phi=APHI,
                           X4='phi(X-V)/C(V) <= (3/c0)*(1+abs(X))*exp(abs(X))',
                           outer_pointwise='H <= (3*a_phi*s)^.75*(3/c0)^.25*exp(-abs(X)/2)/sqrt(1+abs(X))',
                           outer_tail='For abs(X)>T, <=4*(3*a_phi*s)^.75*(3/c0)^.25*exp(-T/2)/sqrt(1+T)'),
             quadrature=dict(orders=[48,96],outer_window=[-RADIUS,RADIUS],max_smooth_panel=2.,
                             breaks='+-L/2, V+-.5, core endpoints +-.5',
                             caveat='X4 tail is retained analytically; GL floating error has no interval certificate.'),
             stage_records=rows,combination_log_checks=combinations,mp50_reference=reference,
             summary=dict(case_count=len(rows),max_core_X5_ratio=max(r['core_X5_ratio'] for r in rows),
                          max_outer_20s75_ratio=max(r['outer_20s75_ratio'] for r in rows),
                          core_X5_exceedances=sum(r['core_X5_ratio']>1+1e-10 for r in rows),
                          outer_20s75_exceedances=sum(r['outer_20s75_ratio']>1+1e-10 for r in rows),
                          max_X6_constant_over_20s75=max(r['X6_constant_over_20s75'] for r in rows),
                          max_GL_core_difference=max(r['GL48_GL96_core_abs_difference'] for r in rows),
                          max_GL_outer_difference=max(r['GL48_GL96_outer_abs_difference'] for r in rows),
                          max_uniform_tail_upper=max(r['outer_uniform_tail_upper'] for r in rows),
                          minimum_coarse_X7_log_margin=min(r['coarse_log_margin'] for r in combinations),
                          X7_coarse_exceedances=sum(r['coarse_log_margin']<0 for r in combinations)),
             limitations=['No whole-source or whole-parameter supremum is certified by a finite menu.',
                          'The combination checks use log binomial recurrence; they test kernel integral envelopes, not original traffic weights.',
                          'No conclusion on general-n weak bounds or FULL payments is drawn from these numbers.',
                          'The old fixed I1 exterior search is not repeated.'])
    (HERE/'fractional_geometry_probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(summary=out['summary'],initial=rows[:2],mp50_reference=reference),indent=2))


if __name__=='__main__':main()
