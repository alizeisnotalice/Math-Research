#!/usr/bin/env python3
"""Finite constrained-FIRST-Chernoff diagnostics; no probabilistic model simulation."""
from pathlib import Path
import importlib.util,json,math,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
p=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round165_20261015_final_checkpoint/hard_overlap_check.py')
spec=importlib.util.spec_from_file_location('rate167',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=.5+float(m.old.expn(3,1.))
def rate(s,r):
    if s==1:return 0.
    p=c*s
    if r<=p:return 0.
    if r<=c:return r*math.log(r/p)+(1-r)*math.log((1-r)/(1-p))
    T=math.log((1-p)/(s*(1-c)))
    return r*T-math.log((1-p)/(1-c))
def main():
    kernel=[]
    for s in (.001,.01,.25,.75,.99,1.):
        T=0. if s==1 else math.log((1-c*s)/(s*(1-c)))
        for frac in (0.,.25,.5,1.):
            t=T*frac;B=1+c*s*math.expm1(t);sp=s*math.exp(t)/B
            for L in (.5,.9,1.):
                for x in (-2.,-.6,-.5,-L/2,0.,L/2,.5,.6,2.):
                    phi=float(m.old.phi_np(m.np.array([x/L]))[0]);hard=float(abs(x)<=L/2)
                    fs=((1-s)*hard+s*phi)/L;fp=((1-sp)*hard+sp*phi)/L
                    lhs=math.exp(t*int(abs(x)>.5))*fs;rhs=B*fp
                    kernel.append(dict(s=s,t_fraction=frac,L=L,x=x,left=lhs,right=rhs,margin=rhs-lhs))
    levels=[]
    for n in (4,16,64,256,4096,65536):
        for s in (.01,.25,.75,.99,1-1/n,1.):
            goal=4*math.log(n)/n
            feasible=rate(s,1)>=goal
            r=None
            if feasible:
                lo=c*s;hi=1.
                for _ in range(70):
                    mid=(lo+hi)/2
                    if rate(s,mid)>=goal:hi=mid
                    else:lo=mid
                r=hi
            levels.append(dict(n=n,s=s,target_tail='n^-4',max_available_exponent=n*rate(s,1),required_exponent=4*math.log(n),method_feasible=feasible,r_threshold=r,tilt_branch=None if r is None else ('bernoulli' if r<=c else 'capped')))
    # Compare the closed form to direct one-dimensional tilt-grid maximization.
    errors=[]
    for s in (.001,.25,.75,.99):
        T=math.log((1-c*s)/(s*(1-c)))
        for r in (0.,c*s,(c*s+c)/2,c,(c+1)/2,1.):
            grid=max(r*(T*j/10000)-math.log1p(c*s*math.expm1(T*j/10000)) for j in range(10001))
            errors.append(dict(s=s,r=r,closed=rate(s,r),tilt_grid=grid,closed_minus_grid=rate(s,r)-grid))
    out=dict(scope='Finite floating checks; exact rate is justified analytically, not by grids.',c=c,kernel_checks=len(kernel),min_kernel_margin=min(x['margin'] for x in kernel),kernel_failures=sum(x['margin'] < -1e-12 for x in kernel),kernel_cases=kernel,thresholds=levels,rate_grid_comparisons=errors,max_closed_minus_grid=max(x['closed_minus_grid'] for x in errors),stages=['initial s=.25 and kernel core/shell/exterior','hard boundaries and s=1 endpoint stress','n to65536 and s=1-1/n high-soft degeneration'],limitations='Thresholds optimize a valid upper-bound method only; infeasible does not imply the true traffic is large. No actual FIRST realization is certified by this scalar scan.')
    (HERE/'rate_probe.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('kernel_cases','thresholds','rate_grid_comparisons')},indent=2))
if __name__=='__main__':main()
