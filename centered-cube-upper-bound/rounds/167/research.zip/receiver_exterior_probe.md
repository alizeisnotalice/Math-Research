# R167：原I1接收补集检查

**旧8个正receiver全部被新receiver门覆盖；固定此I1模型无法产生合格exterior。** Fraction精确计算8行的 `D=sum_i(|x_i-y_i|-b/2)+` 全为0。读取全部7776个已保存m8行后，原 `after/high/I>0` 仍恰有这8行，exterior正行数0。原source距离门失败与receiver门失败不同，不能混同。

进一步发现一个固定模型的排除条件：外core的p上界与原high/lambda门冲突。因此不继续m16大网格，改做488个有理边界点压力核对；其中376个exterior点全部失败high，无剩余合格实例。一般模型的exterior分支仍未支付。

## 准确参数与初步几何

只沿用原R151六源、nu、固定lambda、s=.25、L=.9、b=1、n=4、y=(.3)^4；同一producer逐点恢复q与共同alpha，不另选来源或alpha。producer的q为逐receiver三核最大值，尚非完整FIRST共同q模型。

按本轮s0=.25计算

\[
\varepsilon=.05961792544702430,\qquad
\theta=3446.9556647781645,\qquad
d_*={bn\varepsilon\over8\theta}
=.000008647910104590963.
\]

8个原xq均用有理数核D=0，不依赖浮点门容差；最小坐标core余量为11/80。几何上，原m8边长1/8的对应网格盒仍在b-core内，余量3/40；这不代表资格门在整个网格盒成立。JSON保留每行原 `dx_weight_corrected`，没有把网格点计数或盒几何当作FULL正域积分证书。

第二阶段读取原全部m8行，只筛原producer已有必要实现门：12行after，其中8行I>0；8行都在新receiver门内。未重算全m8核，没有添加门外裸正交通作为合格样本。

## 改变搜索决策的固定模型排除

对当前固定s,L,b,n，若D>0，则至少一坐标
`|x_i-y_i|>b/2>L/2`，该坐标p的硬项为0。用phi≤1和其余因子≤1，得到全空间的简洁上界

\[
p(x)\le {s\over L^n}={2500\over6561}<\frac25.
\]

而原必要门 `q>=3lambda/4` 与 `p*eg>=2Kq` 同时要求

\[
p(x)\ge{3K\lambda\over2e_g}
\approx .6089866138430492>\frac35.
\]

lambda和eg由冻结producer输入的精确有理数重建，上面两项严格分数比较都通过，差距超过1/5。该固定数值模型因此连D>0都不可能同时满足两个必要门，更不可能有D>d*的after/high正行。独立certificate代理亦复核此Fraction比较。

这个结论的准确范围是：**把原lambdaF、nuF、wgF有限记录视作有理输入的冻结模型**。这些十进制核数据本身未在此升级为真核区间证书，更未认证完整f/FIRST/history合同。它也不排除改变输入模型、s或lambda后出现一般exterior；不能据此认定一般补集为空。

另用phi偶递减性得更紧的浮点上界约`.09338476952`，仅作压力一致性对照；排除决定不依赖这个特殊函数近似值。

## 有界原边界压力

只取y的b-core边界 `x_i=-.2` 或`.8` 附近，偏移0、1e−6、1e−5、.001、.01、.05、.1；其他坐标取0、.1、.3。再把原8个positive点逐坐标移到相同边界邻域。去重后488个精确有理点，全部沿用原参数、六源和producer门。

其中376个点满足D>d*，208个还在原某hard来源支持内；exterior点中high失败376次，没有点同时通过high与lambda_lower，after正点0。每点只是点证，没有附加dx权重或正体积。

例如 `(3/10,3/10,3/10,-201/1000)` 有D=.001、原CORE hard支持，裸I约`.11729681`，但high比值仅`.25385632`、lambda_lower比值`.60275808`，故不能登记为原剩余合格交通。这也说明单看正I会误判补集实例。

三个有理边界点作原核mp70复核，p/q的float相对误差最大`6.28e-16`。这检查实现，没有声称浮点为区间证书。因固定模型全空间的两个必要门已冲突，不再扩大m16或改变参数，以免重复无效扫描或绕过原资格。

## 复现与限制

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 centered-cube-upper-bound/rounds/167/work/receiver_exterior_probe.py
```

脚本只写同目录JSON，保存所需原producer和输入SHA。只修改本任务三文件，没有Git操作。实际一般exterior、变化接收参数及完整FIRST来源合同仍需下一步研究；本固定I1不能再作为该补集的正域搜索种子。任务到此停止。
