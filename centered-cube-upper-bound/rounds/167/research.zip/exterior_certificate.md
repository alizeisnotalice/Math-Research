# R167 接收外溢的精确覆盖与固定 I1 排除证书

## 1. 命题与证明等级

定义接收外溢

\[
D_b(x;y)=\sum_{i=1}^n(|x_i-y_i|-b/2)_+,
\qquad U_d(y)=\{x:D_b(x;y)\le d\}.
\]

本稿独立以 `Fraction` 重读 R166 的八条实际 `xq`，只证明其接收几何；不重做 R166 direct/CS 实例，不搜索新点。旧 `after/high/I>0` 标签仅承认冻结 producer 已审的有限实现层级，不把它们提升为完整 FIRST/history 或区间认证正交通。

严格结论是：

1. 八条记录全部满足 **D_b(x;y)=0**，并离 y 的 b-core 边界有共同精确余量 **11/80**；因此对任意 d≥0 都在 U_d(y) 内。
2. 一条初等的通用充分条件可排除高支在 b-core 外出现；在固定 I1 的**冻结有理 producer 常量**层级，该条件以至少 1/5 的严格 p 阈值差成立。因此继续细化同一 I1 的 receiver 网格不可能找到同时通过原 high 和 `lambda_lower` 的 exterior 正例。

第二点不是将 producer 中记录的特殊函数近似认证为真实核；其层级与可升级条件见第 4 节。没有找到新的 exterior 正例，故本任务只交说明和嵌入复算代码，不新增代码/JSON产物。

## 2. 八条接收点的有理证书

输入为冻结 R166 `actual_window_probe.json` 的 `positive_rows`。参数 y=3/10、b=1 来自原 I1 字符串参数；各 `xq` 为原有理坐标，未从 float 反推。

| 行 | xq | 最大坐标距离 | 最小 core 余量 | D_b |
|---:|---|---:|---:|---:|
| 1 | (−1/16,−1/16,−1/16,5/16) | 29/80 | 11/80 | 0 |
| 2 | (−1/16,1/16,−1/16,3/16) | 29/80 | 11/80 | 0 |
| 3 | (−1/16,−1/16,1/16,3/16) | 29/80 | 11/80 | 0 |
| 4 | (−1/16,1/16,1/16,1/16) | 29/80 | 11/80 | 0 |
| 5 | (−1/16,−1/16,3/16,1/16) | 29/80 | 11/80 | 0 |
| 6 | (−1/16,−1/16,5/16,−1/16) | 29/80 | 11/80 | 0 |
| 7 | (1/16,−1/16,1/16,1/16) | 29/80 | 11/80 | 0 |
| 8 | (1/16,−1/16,3/16,−1/16) | 29/80 | 11/80 | 0 |

从原六源有理坐标另核 hard 支撑，八行均只有 index 5 **CORE**：对 CORE 每坐标 |x_i−z_i|≤1/2，对其余每个源至少一坐标严格超出 1/2。外 hard z 没有和 bad u 混用。

若 δ 是任意坐标扰动且 ||δ||∞≤11/80，则这些 x+δ 仍在 U_0(y)。特别是 m8 对应边长 1/8 的网格盒（中心到边界 1/16）全部位于 U_0(y)，距 core 边界尚余 3/40。**这里只认证整盒的几何，不声称 high/rho/positive 门在整盒成立，也不把八点数值交通外推为整盒积分。**

R167 的 d*=bnε/(8θ) 在 ε>0 时为正，所以增强的接收分支覆盖这些行的全部接收几何。它们 s=1/4；若选 s0≤1/4，s 门也匹配；若 s0>1/4，它们已被 s 门排除，不构成外溢反例。这一几何结论完全不需要算 η、θ、指数积分或 GL。

## 3. 固定参数模型的全空间排除切口

**准确命题。** 固定 n≥1、0≤s≤1、0<L≤b、K>0、λ>0、e_g>0，令

\[
p(x)=L^{-n}\prod_{i=1}^n[(1-s)1_{|x_i-y_i|\le L/2}
+s\phi((x_i-y_i)/L)].
\]

假设当前门为

\[
p(x)e_g\ge2Kq(x),\qquad q(x)\ge\tfrac34\lambda.
\]

这里 q 可以是 producer 的逐点 q，也可以是共同 FIRST q；本命题只用上述必要不等式。若

\[
\boxed{\frac{3K\lambda}{2e_g}>\frac{s}{L^n}},
\tag{EX}
\]

则任意通过这两个门的 x 都在 U_0(y)，因而在每个 U_d(y), d≥0 中。

**初等证明。** 由定义 w≤1，φ=h*w≤∫h=1，且 φ≥0。若 x∉U_0(y)，则至少一坐标 |x_i−y_i|>b/2≥L/2，其硬指示为零，该坐标方括号≤s；其他坐标方括号≤1。因此

\[
x\notin U_0(y)\Longrightarrow p(x)\le sL^{-n}.
\]

而两门推出 p(x)≥3Kλ/(2e_g)，与 (EX) 矛盾。该证明保留原 q、e_g、s、L，不另选α、不删来源、不用 posterior 独立性，也未领取 hard 帽。

**代入冻结 I1。** 用原 R151 `build` 的精确有理规则重建 ν：将 R142 `nu_exact` 分别乘 (4096,4096,4096,256,1,256)，再归一化；全部来源保留。用 id=0 记录的 K0,K1,K2,J 有理十进制串构成

\[
Q_i=(K1_i+K2_i+J_i)/3,
\quad\lambda_F=\max\{\sum_i\nu_iK0_i,\sum_i\nu_iJ_i,\sum_i\nu_iQ_i\},
\quad e_{g,F}=\sum_i\nu_i w_{g,i}.
\]

`Fraction` 精确比较的结果：λ_F 的取最大分支为 J，并且

\[
\lambda_F\approx2.3935561602210266\times10^{-7},\quad
e_{g,F}\approx5.895588111000511\times10^{-7},
\]

\[
\frac{3K\lambda_F}{2e_{g,F}}>\frac35,
\qquad \frac{s}{L^4}=\frac{2500}{6561}<\frac25,
\qquad \frac{3K\lambda_F}{2e_{g,F}}-\frac{s}{L^4}>\frac15.
\]

近似小数仅帮助阅读；三个严格不等式全部由有理交叉乘法核验。因此在固定 I1、固定记录常量与原两门下，**整个 core 外部都被排除**，包括 D_b>d* 的真正补集。有限搜索没有正例在这里有一个全空间的固定模型解释，不再是“网格未找到”的经验结论。

## 4. 不升级的等级与待证条件

这份证书须区别三层：

- 八行的 D=0 与 hard 支撑是原有理几何的严格事实；无特殊函数误差。
- (EX)→“外部两门不相容”是对任意满足条件的真实参数/常量的初等定理。
- 原 I1 的数值代入严格核验的是**冻结 producer 的有理常量**。其 λ_F 使用原 mp70/十进制核记录，e_g,F 使用原模板 w_g 十进制记录。本次没有把这些记录数值当成真实 exp/C 积分的区间端点，故不宣布真实核 λ、e_g 已经由本次认证。

若要在真实核层级升级，只需提供保守的 λ_-≤λ_true、e_{g,true}≤e_+，满足

\[
\frac{3K\lambda_-}{2e_+}>\frac{2500}{6561}.
\]

可采用 R166 已审的 Taylor 指数包围与 E3/E4 凸上下和分别认证这些常量；本次没有为凑数重跑它们。更一般的 exterior 仍需实际改变 s/L/source 组合，或者不再受这个固定模型的 (EX) 约束，并同时核原 high、共同α、bad/good、low-c、hard 支撑、全部必要来源测试。新候选的正 margin/mp 结果也须按其等级陈述，完整 FIRST、ν≤β≤f dx 和 history/selector 费用不能由有限候选自动获得。

## 5. 可追溯输入与复算

实际读入的 SHA-256：

| 输入 | SHA-256 |
|---|---|
| 冻结 R166 actual_window_probe.json | `1c9a8a2b60297751260742136fb61732ce68cf690c43309b8fd55345ad4d56c9` |
| R136 active_traffic_v2.json | `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de` |
| R142 numeric_receiver.json | `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55` |

以下为本次实际运行逻辑的自足精简版；只读输入、打印精确判断，无需安装依赖：

```python
from fractions import Fraction as F
from pathlib import Path
import json
root = Path('/Users/zhengzhihao/Desktop/T/output')
a = json.loads((root/'centered_cube_round166_20261015_final_checkpoint/actual_window_probe.json').read_text())
p = root/'r142_portable_replay_verified_20261015'
t = next(c for c in json.loads((p/'centered_cube_round136_20261014/active_traffic_v2.json').read_text())['cases'] if c['id']=='I1')
r = json.loads((p/'centered_cube_round142_20261015/numeric_receiver.json').read_text())['cases']['I1']
def fq(v):
    return F(int(v['numerator']), int(v['denominator'])) if isinstance(v,dict) else F(str(v))
y,b = fq(t['parameters']['y']),fq(t['parameters']['b'])
assert (y,b)==(F(3,10),F(1))
positions = [[fq(v) for v in z['position']] for z in t['atoms']]
assert len(a['positive_rows'])==8
for row in a['positive_rows']:
    x=list(map(F,row['xq']))
    distance=[abs(v-y) for v in x]
    D=sum((max(F(0),v-b/2) for v in distance), F(0))
    hard=[j for j,z in enumerate(positions) if all(abs(v-w)<=F(1,2) for v,w in zip(x,z))]
    assert D==0 and max(distance)==F(29,80)
    assert min(b/2-v for v in distance)==F(11,80)
    assert hard==[5] and t['atoms'][5]['name']=='CORE'
    print(row['xq'], D, F(11,80), hard)
nu0=list(map(fq,r['nu_exact']))
raw=[v*m for v,m in zip(nu0,[4096,4096,4096,256,1,256])]
nu=[v/sum(raw) for v in raw]
base=next(v for v in r['verifications'] if v.get('id')==0)
k={name:list(map(fq,base[name])) for name in ('K0','K1','K2','J')}
k['Q']=[sum(values)/3 for values in zip(k['K1'],k['K2'],k['J'])]
levels={name:sum(v*w for v,w in zip(nu,k[name])) for name in ('K0','J','Q')}
lam=max(levels.values())
eg=sum(v*fq(z['wg']) for v,z in zip(nu,t['atoms']))
K,L,s=map(lambda name:fq(t['parameters'][name]),('K','L','s'))
assert (K,L,s,t['n'])==(F(1),F(9,10),F(1,4),4)
assert [name for name,value in levels.items() if value==lam]==['J']
threshold=3*K*lam/(2*eg)
upper=s/L**4
assert threshold>F(3,5) and upper==F(2500,6561)<F(2,5)
assert threshold-upper>F(1,5)
print('Exact rational exterior exclusion: PASS')
```

初步阶段完成八行的有理覆盖；已有压力是其共享原来源、原参数和原两门；扩大阶段采用全空间初等排除，不扩大网格或追加固定核小例。费用仅为有限有理运算。本稿不领取新原加权预算，不声称一般补集已付款，交付至此。
