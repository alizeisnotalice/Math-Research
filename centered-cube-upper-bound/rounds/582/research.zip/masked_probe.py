"""Frozen n2/n3 masked carrier passes; exact radical scores and continuous coverage."""
from fractions import Fraction as F
from math import gcd,prod
from functools import lru_cache,cmp_to_key
from pathlib import Path
import argparse,json,hashlib,time,sys,platform,resource,signal,shlex
import flint
from flint import arb,ctx
ctx.prec=512
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--baseline','--locked-input',dest='baseline',type=Path,default=Path(__file__).resolve().parent/'probe.json');args=ap.parse_args();start=time.perf_counter()
LIM=128*1024**2
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('120s guard, no candidate truncation')))
def guard():
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 if rss>LIM:raise MemoryError('128MB RSS guard, no candidate truncation')
 return rss
LOCKED_SHA='0b59417a638ab184a0e343f53a22b262d13df455f1dccb09e7cef90be7c03681'
raw=args.baseline.read_bytes();assert hashlib.sha256(raw).hexdigest()==LOCKED_SHA
def run(old):
 case_start=time.perf_counter();signal.alarm(120)
 n=old['input']['n'];assert n in (2,3)
 z=[tuple(map(F,p)) for p in old['input']['sources_rational']];w=list(map(F,old['input']['masses_exact']));N=len(z);ALL=(1<<N)-1;W=sum(w);U=F(2**(n+1));assert N in (8,10) and W<2*U/3
 ZERO=();ONE=((1,F(1)),);RADFACT={1:()}
 def pack(d):return tuple(sorted((r,c) for r,c in d.items() if c))
 def rat(q):q=F(q);return ((1,q),) if q else ZERO
 @lru_cache(maxsize=2048)
 def add(a,b):
  d=dict(a)
  for r,c in b:d[r]=d.get(r,F(0))+c
  return pack(d)
 def scale(a,q):return tuple((r,c*F(q)) for r,c in a if c*F(q))
 def sub(a,b):return add(a,scale(b,-1))
 @lru_cache(maxsize=10000)
 def basisproduct(r,s):
  d=dict(RADFACT[r])
  for p,e in RADFACT[s]:d[p]=d.get(p,0)+e
  c=1;rd=1;es=[]
  for p,e in sorted(d.items()):
   q,rem=divmod(e,n);c*=p**q
   if rem:rd*=p**rem;es.append((p,rem))
  RADFACT[rd]=tuple(es);return rd,c
 @lru_cache(maxsize=256)
 def mul(a,b):
  d={}
  for r,c in a:
   for s,e in b:
    t,g=basisproduct(r,s);d[t]=d.get(t,F(0))+c*e*g
  return pack(d)
 @lru_cache(None)
 def root(q):
  q=F(q);r=q.numerator*q.denominator**(n-1);c=F(1,q.denominator);p=2;rd=1;es=[]
  while p*p<=r:
   power=0
   while r%p==0:power+=1;r//=p
   c*=p**(power//n)
   if power%n:rd*=p**(power%n);es.append((p,power%n))
   p+=1 if p==2 else 2
  if r>1:rd*=r;es.append((r,1))
  RADFACT[rd]=tuple(es);return ((rd,c),)
 def af(q):q=F(q);return arb(q.numerator)/q.denominator
 @lru_cache(None)
 def arroot(r):return arb(r).sqrt() if n==2 else (arb(r).log()/3).exp()
 def av(a):return sum((af(c)*arroot(r) for r,c in a),arb(0))
 @lru_cache(maxsize=40000)
 def sign(a):
  if not a:return 0
  v=av(a)
  if v>0:return 1
  if v<0:return -1
  raise ArithmeticError('Nonzero exact radical sign unresolved')
 def out(a):return {'exact_squarefree_radical_terms' if n==2 else 'exact_cubefree_radical_terms':[[r,str(c)] for r,c in a],'Arb512':av(a).str(55)}
 def mass(S):return sum(w[i] for i in range(N) if S>>i&1)
 def bbox(S):
  ids=[i for i in range(N) if S>>i&1]
  return tuple((min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(n))
 def box(bb,m,outer=False):
  h=scale(root(m),F(1,2));B=tuple((sub(rat(lo if outer else hi),h),add(rat(hi if outer else lo),h)) for lo,hi in bb)
  return B if all(sign(sub(b,a))>0 for a,b in B) else None
 def volumeB(B):
  if not B:return ZERO
  v=ONE
  for a,b in B:v=mul(v,sub(b,a))
  return v
 def partial(S,m):
  ids=[i for i in range(N) if S>>i&1];tau=m/(4*n);fullbb=bbox(S);qb=[]
  for j in range(n):
   vals=sorted(set(z[i][j] for i in ids));dist={v:sum(w[i] for i in ids if z[i][j]==v) for v in vals}
   def q(order):
    tot=F(0)
    for v in order:
     tot+=dist[v]
     if tot>tau:return v
    raise AssertionError('quantile')
   qb.append((q(vals),q(vals[::-1])))
  rows=[];unique={};maskcores=[]
  for fm in range(1<<(2*n)):
   bounds=[(qb[j][0] if fm>>(2*j)&1 else fullbb[j][0],qb[j][1] if fm>>(2*j+1)&1 else fullbb[j][1]) for j in range(n)]
   K=sum(1<<i for i in ids if all(lo<=z[i][j]<=hi for j,(lo,hi) in enumerate(bounds)))
   assert K and mass(K)>=m/2
   maskcores.append(K)
   if K not in unique:unique[K]={'face_mask':fm,'K':K,'B':box(bbox(K),m),'bounds':bounds};rows.append(unique[K])
  assert rows[0]['K']==S
  return rows,tau,qb,maskcores
 subs={};high=[]
 for S in range(1,ALL+1):
  m=mass(S);bb=bbox(S);C=box(bb,m);beta=scale(volumeB(C),1/m);hi=sign(sub(scale(mul(beta,beta),n),ONE))>=0
  q={'S':S,'m':m,'bb':bb,'C':C,'beta':beta,'high':hi}
  if m>=1:q['candidates'],q['tau'],q['qb'],q['maskcores']=partial(S,m)
  subs[S]=q
  if hi:high.append(S)
 order=sorted(subs,key=lambda S:(-subs[S]['m'],S));used=0;selectedhigh=[]
 for S in order:
  if subs[S]['high'] and not S&used:selectedhigh.append(S);used|=S
 assert used==ALL and selectedhigh==old['original_high_greedy']['selected_partition_masks'] and high==old['original_high_greedy']['all_subset_high_masks']
 HB=[box(subs[S]['bb'],2*subs[S]['m'],True) for S in selectedhigh]
 def parse_endpoint(e):
  key=[]
  for rr,cc in e['exact_terms']:
   rr=int(rr);root(F(rr));key.append((rr,F(cc)))
  return tuple(key)
 oldends=[set(parse_endpoint(e) for e in es) for es in old['partition']['axis_endpoints']]
 endsets=[set(es) for es in oldends]
 for S in order:
  q=subs[S]
  for ca in q.get('candidates',[]):
   if ca['B']:
    for j,pair in enumerate(ca['B']):endsets[j].update(pair)
 ends=[sorted(es,key=cmp_to_key(lambda a,b:sign(sub(a,b)))) for es in endsets];dims=[len(es)-1 for es in ends];nx=dims[0];ny=dims[1];nr=prod(dims[:-1]);nz=dims[-1];idx=[{e:i for i,e in enumerate(es)} for es in ends]
 assert nr<=40000;guard()
 print(json.dumps({'stage':'complete_masked_preflight','case':old['name'],'all_subsets':ALL,'candidate_masks_per_inband_subset':1<<(2*n),'axis_endpoints':[len(es) for es in ends],'new_endpoint_counts':[len(es-oldes) for es,oldes in zip(endsets,oldends)],'full_cells':prod(dims),'stored_rows':nr}),flush=True)
 def ranges(B):return tuple((idx[j][a],idx[j][b]) for j,(a,b) in enumerate(B)) if B else None
 def zbits(R):return ((1<<(R[-1][1]-R[-1][0]))-1)<<R[-1][0]
 def rowiter(R):
  if n==2:yield from range(*R[0])
  else:
   for x in range(*R[0]):
    for y in range(*R[1]):yield x*dims[1]+y
 def insert(arr,R):
  if R:
   zz=zbits(R)
   for x in rowiter(R):arr[x]|=zz
 ER=[0]*nr;HR=[0]*nr
 for S in order:
  q=subs[S];q['R']=ranges(q['C'])
  if q['m']>=1:insert(ER,q['R'])
  for ca in q.get('candidates',[]):ca['range']=ranges(ca['B'])
 for B in HB:insert(HR,ranges(B))
 RR=[e&~h for e,h in zip(ER,HR)]
 for S in order:
  q=subs[S]
  if q['m']<1 and q['R']:
   zz=zbits(q['R']);assert not any(zz&~HR[x] for x in rowiter(q['R']))
 @lru_cache(maxsize=15000)
 def ylength(mask):
  v=ZERO
  while mask:
   lo=(mask&-mask).bit_length()-1;hi=lo
   while mask>>hi&1:hi+=1
   v=add(v,sub(ends[-1][hi],ends[-1][lo]));mask^=((1<<(hi-lo))-1)<<lo
  return v
 widths=[sub(b,a) for a,b in zip(ends[0],ends[0][1:])] if n==2 else [mul(sub(b,a),sub(d,c)) for a,b in zip(ends[0],ends[0][1:]) for c,d in zip(ends[1],ends[1][1:])]
 def volumeSparse(rows):
  d={}
  for x,mm in rows:
   if mm:
    for r,c in mul(widths[x],ylength(mm)):d[r]=d.get(r,F(0))+c
  return pack(d)
 J=volumeSparse(enumerate(RR));assert sign(J)>0
 assert (av(J)-arb(old['complete_Rlo_volume_Arb512'])).contains(0)
 # Existing extrema selection is not re-run: only reconstruct its locked paid cost exactly.
 locked_ext_cost=ZERO
 for r0 in old['extrema']['selected']:locked_ext_cost=add(locked_ext_cost,volumeB(subs[r0['mask']]['C']))
 assert (av(locked_ext_cost)-arb(old['extrema']['sum_full_carrier_fees_Arb512'])).contains(0)
 cov=[0]*nr;rawcov=[0]*nr;selected=[];fullfee=ZERO;freshsum=ZERO;witnesssum=ZERO;selectedmass=F(0);score_exact_ties=0;candidate_total=0;unique_total=0
 for S in order:
  q=subs[S];R=q['R']
  if q['m']<1 or not R:continue
  zz=zbits(R);wfresh=[(x,zz&RR[x]&~cov[x]) for x in rowiter(R)];wfresh=[(x,b) for x,b in wfresh if b]
  if not wfresh:continue
  cands=[];seen=set();candidate_total+=1<<(2*n)
  for ca in q['candidates']:
   P=ca['range'];assert P
   if P in seen:continue
   seen.add(P);unique_total+=1
   zp=zbits(P);rows=[(x,zp&RR[x]&~cov[x]) for x in rowiter(P)];rows=[(x,b) for x,b in rows if b]
   cost=volumeB(ca['B']);new=volumeSparse(rows);assert sign(cost)>0 and sign(new)>0
   assert all(pa<=ra and rb<=pb for (ra,rb),(pa,pb) in zip(R,P))
   cands.append((ca,cost,new,rows))
  best=cands[0];ties=[]
  for ca,cost,new,rows in cands[1:]:
   res=sub(mul(new,best[1]),mul(best[2],cost));sg=sign(res)
   if sg>0:best=(ca,cost,new,rows);ties=[]
   elif sg==0:score_exact_ties+=1;ties.append(ca['face_mask'])
  ca,cost,new,newrows=best;K=ca['K'];beta=subs[K]['beta'];assert sign(sub(scale(mul(beta,beta),n),ONE))<0
  witnessx,wm=wfresh[0];witnessy=(wm&-wm).bit_length()-1
  # Retain exact whole fresh cell for pairwise carrier-exit/tail certificate.
  winds=[witnessx,witnessy] if n==2 else [witnessx//ny,witnessx%ny,witnessy]
  cell=tuple((ends[j][ii],ends[j][ii+1]) for j,ii in enumerate(winds))
  candidate_records=[]
  for p,fee,vv,_ in cands:
   cmpbest=sub(mul(best[2],fee),mul(vv,best[1]));assert sign(cmpbest)>=0
   candidate_records.append({'face_mask':p['face_mask'],'core_mask':p['K'],'core_mass':str(mass(p['K'])),'full_carrier_cost':out(fee),'actual_new_Rlo_volume':out(vv),'winner_score_crossproduct_residual':out(cmpbest),'same_score_as_winner_exact':not cmpbest})
  rec={'mask':S,'mass':str(q['m']),'tau':str(q['tau']),'face_mask':ca['face_mask'],'face_bit_order':[s+tail for s in 'xyz'[:n] for tail in ('_lower','_upper')],'core_mask':K,'core_mass':str(mass(K)),'actual_core_bbox':[[str(a),str(b)] for a,b in bbox(K)],'partial_rectangle_bounds':[[str(a),str(b)] for a,b in ca['bounds']],'full_carrier_cost':out(cost),'true_new_Rlo_volume':out(new),'true_fresh_current_witness_volume':out(volumeSparse(wfresh)),'distinct_candidate_count':len(cands),'all_candidate_mask_count':1<<(2*n),'all_face_mask_core_map':q['maskcores'],'all_distinct_candidate_scores':candidate_records,'positive_fresh_witness_cell_indices':winds,'positive_fresh_witness_cell_exact':[[out(e) for e in pair] for pair in cell],'carrier_ranges':[list(p) for p in ca['range']],'winner_tie_rule':'smallest face mask among exact maximum scores','_B':ca['B'],'_cell':cell}
  selected.append(rec);selectedmass+=q['m'];fullfee=add(fullfee,cost);freshsum=add(freshsum,new);witnesssum=add(witnesssum,volumeSparse(wfresh))
  P=ca['range'];zp=zbits(P)
  for x in rowiter(P):cov[x]|=zp&RR[x];rawcov[x]|=zp
  guard()
 assert cov==RR and freshsum==J
 pairs=[]
 for j,new in enumerate(selected):
  for i,oldrow in enumerate(selected[:j]):
   lost=mass(oldrow['mask']&~new['mask']);exits=[];bb=bbox(oldrow['core_mask'])
   for axis,((nl,nh),(ol,oh)) in enumerate(zip(new['_cell'],oldrow['_B'])):
    if sign(sub(nh,ol))<=0:
     # Below B's lower receiver face excludes original points >= core max.
     tail=sum(1<<t for t in range(N) if oldrow['mask']>>t&1 and z[t][axis]>=bb[axis][1]);coord_face='upper';fm_bit=2*axis+1
     exits.append({'receiver_exit':'lower','source_coordinate_face':coord_face,'axis':axis,'mask_face_was_trimmed':bool(oldrow['face_mask']>>fm_bit&1),'inclusive_old_source_tail_mask':tail,'inclusive_old_source_tail_mass_exact':str(mass(tail))})
    if sign(sub(nl,oh))>=0:
     tail=sum(1<<t for t in range(N) if oldrow['mask']>>t&1 and z[t][axis]<=bb[axis][0]);coord_face='lower';fm_bit=2*axis
     exits.append({'receiver_exit':'upper','source_coordinate_face':coord_face,'axis':axis,'mask_face_was_trimmed':bool(oldrow['face_mask']>>fm_bit&1),'inclusive_old_source_tail_mask':tail,'inclusive_old_source_tail_mass_exact':str(mass(tail))})
   assert exits and lost>0
   for ex in exits:
    assert not ex['inclusive_old_source_tail_mask']&new['mask']
    assert lost>=F(ex['inclusive_old_source_tail_mass_exact'])
    if ex['mask_face_was_trimmed']:assert F(ex['inclusive_old_source_tail_mass_exact'])>F(oldrow['tau'])
   pairs.append({'old_index':i,'new_index':j,'actual_old_source_mass_excluded_exact':str(lost),'old_tau':oldrow['tau'],'loss_over_tau_exact':str(lost/F(oldrow['tau'])),'uniform_loss_gt_tau_observed_only':lost>F(oldrow['tau']),'whole_cell_exit_face_certificates':exits})
 for row in selected:del row['_B'];del row['_cell']
 diff=sub(locked_ext_cost,fullfee);sg=sign(diff)
 result={'status':'PASS_FROZEN_MASKED_FULL_COVER_CERTIFICATE','name':old['name'],'locked_input_sha256':LOCKED_SHA,'locked_source_script_sha256':'43553c70758dfda0152eddd812cf763fa8601bdf8745635e78df35ad1a675c7e','input':old['input'],'original_high_greedy_partition_masks':selectedhigh,'all_subset_high_masks_actual':high,'all_subsets':ALL,'inband_subsets':old['counts']['inband_subsets'],'masks_per_inband_subset':1<<(2*n),'partition':{'axis_endpoint_counts':[len(es) for es in ends],'new_axis_endpoint_counts':[len(es-oldes) for es,oldes in zip(endsets,oldends)],'axis_endpoints':[[out(e) for e in es] for es in ends],'full_continuous_cell_count':prod(dims),'stored_row_count':nr,'whole_cell_incidence_no_sampling':True},'full_Rlo_volume':out(J),'selected_count':len(selected),'sum_selected_actual_mass_exact':str(selectedmass),'sum_full_carrier_fees':out(fullfee),'sum_true_new_residual_fees':out(freshsum),'sum_true_fresh_current_witness_fees':out(witnesssum),'full_paid_carrier_union_volume':out(volumeSparse(enumerate(rawcov))),'locked_extrema_paid_cost_exact_reconstructed_without_rerunning_selection':out(locked_ext_cost),'locked_extrema_minus_masked_full_fee':out(diff),'masked_over_extrema_full_fee_Arb512':(av(fullfee)/av(locked_ext_cost)).str(55),'strict_fullfee_improvement':sg>0,'full_fee_direction':'lower' if sg>0 else 'higher' if sg<0 else 'exact_equal','complete_Rlo_covered_exact':True,'fresh_disjoint_partition_equals_full_Rlo_exact':freshsum==J,'triggered_raw_candidate_mask_count':candidate_total,'triggered_distinct_carrier_score_count':unique_total,'exact_score_tie_comparisons':score_exact_ties,'score_policy':'maximize actual new residual volume/full carrier volume at each descending actual witness; exact score cross-products, smallest face-mask exact tie. Heuristic selector, rigorously checked resulting cover/cost.','selected':selected,'pairwise_actual_mass_and_face_tails':pairs,'pairwise_uniform_tau_not_assumed':True,'uniform_loss_gt_tau_observed_all_pairs':all(p['uniform_loss_gt_tau_observed_only'] for p in pairs),'arithmetic':'All volume/cost/score/mass/tie identities exact Fraction nth-power-free radical coefficients; nonzero signs certified by Arb512. Ball displays are interval enclosures, not ordinary floats.','precision_bits':512,'unresolved_signs':0,'runtime_seconds':time.perf_counter()-case_start,'peak_rss_bytes':guard(),'processes':1,'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Only original frozen tiny input, no new parameters. No general budget or optimality statement. All2^(2n) masks considered at every triggered witness; nontriggered witnesses are skipped only by exact complete coverage.'}
 return result
baseline=json.loads(raw)
result={'status':'RUNNING','locked_input_sha256':LOCKED_SHA,'cases':[],'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for original in baseline['cases']:
 result['cases'].append(run(original));signal.alarm(0)
 args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 last=result['cases'][-1]
 print(json.dumps({k:last[k] for k in ['name','selected_count','sum_selected_actual_mass_exact','sum_full_carrier_fees','strict_fullfee_improvement','full_fee_direction','runtime_seconds','peak_rss_bytes']},ensure_ascii=False),flush=True)
result['status']='PASS_THREE_FROZEN_MASKED_FULL_COVER_CERTIFICATES';result['runtime_seconds']=time.perf_counter()-start;result['peak_rss_bytes']=guard();args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'runtime_seconds':result['runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes']}))
