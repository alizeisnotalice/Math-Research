"""Three frozen tiny-boundary full Rlo cover experiments; no sampled receivers."""
from fractions import Fraction as F
from itertools import product
from functools import lru_cache,cmp_to_key
from pathlib import Path
from math import prod
import argparse,json,sys,time,platform,resource,signal,shlex,hashlib
import flint
from flint import arb,ctx
ctx.prec=512
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args()
LIMIT=128*1024**2
START=time.perf_counter()
def alarm(*_):raise TimeoutError('120-second per-case guard exceeded; no subsets truncated')
signal.signal(signal.SIGALRM,alarm)
def memcheck():
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 if rss>LIMIT:raise MemoryError('128MB RSS guard exceeded; no subsets truncated')
 return rss
def af(x):x=F(x);return arb(x.numerator)/x.denominator
def ball(x):return x.str(55)
# Endpoint expression sum coefficient*cubert/sqrt(integer radicand), canonical nth-power reduction.
def packed(d):return tuple(sorted((d0,c) for d0,c in d.items() if c))
def rat(x):x=F(x);return ((1,x),) if x else ()
def add(a,b):
 d=dict(a)
 for k,c in b:d[k]=d.get(k,F(0))+c
 return packed(d)
def scale(a,c):return tuple((k,v*F(c)) for k,v in a if v*F(c))
def sub(a,b):return add(a,scale(b,-1))
def factor(v):
 d={};p=2
 while p*p<=v:
  while v%p==0:d[p]=d.get(p,0)+1;v//=p
  p+=1 if p==2 else 2
 if v>1:d[v]=d.get(v,0)+1
 return d

def run(name,n,points):
 t0=time.perf_counter();signal.alarm(120);memcheck()
 points=sorted(points,key=lambda p:tuple(p[0])+(p[1],));z=[tuple(p[0]) for p in points];weights=[p[1] for p in points];N=len(z);W=sum(weights);L=F(1);U=F(2**(n+1));ALL=(1<<N)-1;assert W<2*U/3
 @lru_cache(None)
 def root(q):
  q=F(q);rad=q.numerator*q.denominator**(n-1);coef=F(1,q.denominator);out=1
  for p,e in factor(rad).items():coef*=p**(e//n);out*=p**(e%n)
  return ((out,coef),)
 @lru_cache(None)
 def rootarb(d):return (arb(d).log()/n).exp() if d!=1 else arb(1)
 def av(x):return sum((af(c)*rootarb(d) for d,c in x),arb(0))
 @lru_cache(None)
 def sign(x):
  if not x:return 0
  for prec in (512,1024,2048):
   old=ctx.prec;ctx.prec=prec
   try:
    v=sum((af(c)*((arb(d).log()/n).exp() if d!=1 else arb(1)) for d,c in x),arb(0))
    if v>0:return 1
    if v<0:return -1
   finally:ctx.prec=old
  raise ArithmeticError('Unresolved endpoint sign; no floating tie or subset truncation allowed')
 def eo(x):return {'exact_terms':[[d,str(c)] for d,c in x],'Arb512':ball(av(x))}
 def mass(mask):return sum(weights[i] for i in range(N) if mask>>i&1)
 def bbox(mask):
  ids=[i for i in range(N) if mask>>i&1]
  return tuple((min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(n))
 def box(bb,m,expanded=False):
  half=scale(root(m),F(1,2));B=tuple((sub(rat(lo if expanded else hi),half),add(rat(hi if expanded else lo),half)) for lo,hi in bb)
  return B if all(sign(sub(b,a))>0 for a,b in B) else None
 def bvol(B):return prod((av(sub(b,a)) for a,b in B),start=arb(1)) if B else arb(0)
 def trim(S,m):
  ids=[i for i in range(N) if S>>i&1];tau=m/(4*n);bounds=[]
  for j in range(n):
   coords=sorted(set(z[i][j] for i in ids));masses={v:sum(weights[i] for i in ids if z[i][j]==v) for v in coords}
   def quant(order):
    accum=F(0)
    for v in order:
     accum+=masses[v]
     if accum>tau:return v
    raise AssertionError('No quantile')
   bounds.append((quant(coords),quant(coords[::-1])))
  K=sum(1<<i for i in ids if all(lo<=z[i][j]<=hi for j,(lo,hi) in enumerate(bounds)));mk=mass(K)
  assert K and mk>=m/2
  return K,tau,bounds
 b=1/arb(n).sqrt();subs={};high=[]
 for S in range(1,ALL+1):
  m=mass(S);bb=bbox(S);C=box(bb,m);beta=bvol(C)/af(m);res=n*beta**2-1
  if res>0:is_high=True
  elif res<0:is_high=False
  else:raise ArithmeticError('Unresolved high-beta threshold')
  K,tau,qbounds=trim(S,m);T=box(bbox(K),m)
  if C:
   assert T
   for (a0,b0),(a1,b1) in zip(C,T):assert sign(sub(a0,a1))>=0 and sign(sub(b1,b0))>=0
  row={'mask':S,'mass':m,'bbox':bb,'C':C,'beta':beta,'high':is_high,'K':K,'tau':tau,'qbounds':qbounds,'T':T}
  subs[S]=row
  if is_high:high.append(row)
 ordering=sorted(subs.values(),key=lambda q:(-q['mass'],q['mask']))
 selectedhigh=[];used=0;blocking=[]
 for q in ordering:
  if not q['high']:continue
  if not used&q['mask']:
   selectedhigh.append(q);used|=q['mask']
  else:
   blocker=next(p for p in selectedhigh if p['mask']&q['mask']);blocking.append({'mask':q['mask'],'earlier_blocker':blocker['mask'],'blocker_mass':str(blocker['mass'])})
 assert used==ALL and sum(q['mass'] for q in selectedhigh)==W
 # Construct the actual original H2 from actual selected high blocks, never a presumed singleton family.
 HB=[box(q['bbox'],2*q['mass'],expanded=True) for q in selectedhigh]
 assert all(HB)
 all_single=all(q['mask'].bit_count()==1 for q in high)
 endsets=[set() for _ in range(n)]
 for B in [q['C'] for q in subs.values()]+[q['T'] for q in subs.values()]+HB:
  if B:
   for j,pair in enumerate(B):endsets[j].update(pair)
 ends=[sorted(es,key=cmp_to_key(lambda a,b:sign(sub(a,b)))) for es in endsets];dims=[len(es)-1 for es in ends];nr=prod(dims[:-1]);nz=dims[-1]
 print(json.dumps({'stage':'frozen_complete_partition','case':name,'subsets':ALL,'high_count':len(high),'actual_high_partition':[q['mask'] for q in selectedhigh],'axis_endpoints':[len(es) for es in ends],'implicit_cells':prod(dims),'row_count':nr}),flush=True)
 memcheck();assert nr<=40000,'Preflight row bound exceeds frozen estimate; stop rather than truncate'
 indices=[{e:i for i,e in enumerate(es)} for es in ends]
 def ranges(B):return tuple((indices[j][lo],indices[j][hi]) for j,(lo,hi) in enumerate(B)) if B else None
 def rowiter(R):
  if n==2:
   yield from range(*R[0])
  else:
   for x in range(*R[0]):
    for y in range(*R[1]):yield x*dims[1]+y
 def zbits(R):return ((1<<(R[-1][1]-R[-1][0]))-1)<<R[-1][0]
 def insert(arr,R):
  if not R:return
  zz=zbits(R)
  for row in rowiter(R):arr[row]|=zz
 ER=[0]*nr;HR=[0]*nr
 for q in subs.values():
  q['crange']=ranges(q['C']);q['trange']=ranges(q['T'])
  if L<=q['mass']<=U:insert(ER,q['crange'])
 for B in HB:insert(HR,ranges(B))
 RR=[a&~h for a,h in zip(ER,HR)];assert any(RR)
 for q in subs.values():
  if q['mass']>=L or not q['crange']:continue
  zz=zbits(q['crange']);assert not any(zz&~HR[row] for row in rowiter(q['crange']))
 widths=[[av(sub(b,a)) for a,b in zip(es,es[1:])] for es in ends]
 if n==2:areas=widths[0]
 else:areas=[a*b0 for a in widths[0] for b0 in widths[1]]
 @lru_cache(maxsize=20000)
 def zlen(mask):
  v=arb(0)
  while mask:
   lo=(mask&-mask).bit_length()-1;hi=lo
   while mask>>hi&1:hi+=1
   v+=av(sub(ends[-1][hi],ends[-1][lo]));mask^=((1<<(hi-lo))-1)<<lo
  return v
 def sparsevol(items):return sum((areas[row]*zlen(mm) for row,mm in items if mm),arb(0))
 def arrvol(arr):return sparsevol(enumerate(arr))
 # All C boxes and both possible carriers have index-certified incidences; verify exact domain containment by endpoints.
 J=arrvol(RR);assert J>0
 def scheme(which):
  cov=[0]*nr;rawunion=[0]*nr;selected=[];masssum=F(0);fees=arb(0);freshsum=arb(0);witnessfreshsum=arb(0)
  for q in ordering:
   if not L<=q['mass']<=U or not q['crange']:continue
   R=q['crange'];zz=zbits(R);wfresh=[(row,zz&RR[row]&~cov[row]) for row in rowiter(R)];wfresh=[(i,m) for i,m in wfresh if m]
   if not wfresh:continue
   P=q['trange'] if which=='quantile' else R;carrier=q['T'] if which=='quantile' else q['C'];zp=zbits(P)
   assert P and q['mass']<=W
   fresh=[(row,zp&RR[row]&~cov[row]) for row in rowiter(P)];fresh=[(i,m) for i,m in fresh if m]
   fv=sparsevol(fresh);wv=sparsevol(wfresh);cost=bvol(carrier);assert fv>0 and wv>0
   K=q['K'] if which=='quantile' else q['mask'];mk=subs[K]['mass'];betaK=subs[K]['beta'];assert betaK<b
   increment_bound=betaK*af(q['mass'])+af(F(2,n)*(q['mass']-mk))
   if which=='quantile' and K!=q['mask']:assert increment_bound-cost>0
   witnessrow,wmask=wfresh[0];wi=(wmask&-wmask).bit_length()-1
   if n==2:winds=[witnessrow,wi]
   else:winds=[witnessrow//dims[1],witnessrow%dims[1],wi]
   rec={'mask':q['mask'],'mass':str(q['mass']),'core_mask':K,'core_mass':str(mk),'tau':str(q['tau']),'whole_tie_quantile_bounds':[[str(a),str(b0)] for a,b0 in q['qbounds']] if which=='quantile' else None,'full_carrier_volume_Arb512':ball(cost),'true_new_residual_carrier_volume_Arb512':ball(fv),'true_fresh_current_witness_volume_Arb512':ball(wv),'carrier_cost_bound_Arb512':ball(increment_bound),'beta_core_Arb512':ball(betaK),'positive_fresh_whole_cell_indices':winds,'positive_fresh_whole_cell_endpoints':[[eo(ends[j][i]),eo(ends[j][i+1])] for j,i in enumerate(winds)],'carrier_endpoint_ranges':[list(p) for p in P]}
   selected.append(rec);masssum+=q['mass'];fees+=cost;freshsum+=fv;witnessfreshsum+=wv
   for row in rowiter(P):cov[row]|=zp&RR[row];rawunion[row]|=zp
   memcheck()
  assert cov==RR
  # Geometric fresh pieces are exactly disjoint and cover RR; interval sums must enclose this identity.
  assert (freshsum-J).contains(0)
  assert selected and selected[0]['mask']==ALL
  pairs=[]
  for j,new in enumerate(selected):
   for i,old in enumerate(selected[:j]):
    lost=mass(old['mask']&~new['mask']);tau=F(old['mass'])/(4*n)
    if which=='quantile':assert lost>tau
    else:assert lost>0
    pairs.append({'old_selected_index':i,'new_selected_index':j,'old_mask':old['mask'],'new_mask':new['mask'],'old_source_mass_excluded_by_new_labels':str(lost),'tau_old':str(tau),'loss_over_tau_exact':str(lost/tau),'strict_loss_gt_tau':lost>tau})
  return {'scheme':which,'selected_count':len(selected),'skipped_inband_nonempty_count':sum(1 for q in ordering if L<=q['mass']<=U and q['C'])-len(selected),'sum_actual_selected_mass_exact':str(masssum),'sum_actual_selected_mass_over_W_exact':str(masssum/W),'sum_full_carrier_fees_Arb512':ball(fees),'sum_full_carrier_fees_over_W_Arb512':ball(fees/af(W)),'sum_true_new_residual_carrier_fees_Arb512':ball(freshsum),'sum_true_fresh_current_witness_fees_Arb512':ball(witnessfreshsum),'final_full_carrier_union_volume_Arb512':ball(arrvol(rawunion)),'complete_Rlo_covered_exact_incidence':True,'fresh_disjoint_partition_equals_Rlo_exact_incidence':True,'fresh_sum_minus_Rlo_Arb512':ball(freshsum-J),'first_selected_mask_full_source':True,'first_selected_trim_nontrivial':selected[0]['core_mask']!=ALL if which=='quantile' else False,'selected':selected,'pairwise_real_source_mass_exclusion':pairs},fees,masssum
 ext,ef,em=scheme('extrema');memcheck();trimres,tf,tm=scheme('quantile');assert trimres['first_selected_trim_nontrivial']
 diff=ef-tf
 if diff>0:fee_direction='quantile_strictly_lower'
 elif diff<0:fee_direction='quantile_strictly_higher'
 else:
  # Identical selected carriers imply exact equality; otherwise no false float tie.
  if [q['carrier_endpoint_ranges'] for q in ext['selected']]==[q['carrier_endpoint_ranges'] for q in trimres['selected']]:fee_direction='exact_same_selected_carriers'
  else:raise ArithmeticError('Unresolved total-fee comparison')
 counts={'all_subsets':ALL,'inband_subsets':sum(L<=q['mass']<=U for q in subs.values()),'positive_C_allsubsets':sum(bool(q['C']) for q in subs.values()),'positive_C_inband':sum(bool(q['C']) and L<=q['mass']<=U for q in subs.values()),'high_allsubsets':len(high),'high_greedy_blocks':len(selectedhigh)}
 ans={'name':name,'input':{'n':n,'N':N,'lambda':1,'L':'1','U':str(U),'W':str(W),'no_top_guard_W_lt_2U_over3_exact':True,'sources_rational':[[str(v) for v in p] for p in z],'masses_exact':[str(w) for w in weights],'coordinate_labels':'lexicographic coordinates then mass; increasing integer mask tie','selection_order':'decreasing exact actual source mass, increasing mask','full_family_not_truncated':True},'counts':counts,'original_high_greedy':{'threshold':'1/sqrt(n)','all_subset_high_masks':[q['mask'] for q in high],'selected_partition_masks':[q['mask'] for q in selectedhigh],'selected_partition_masses':[str(q['mass']) for q in selectedhigh],'blocked_high_certificates':blocking,'source_partition_exact':True,'all_high_are_singleton_actual_check':all_single,'H2_rule':'For each actual greedily selected high K, bbox(K) expanded by halfside (2mK)^(1/n) in every direction, union all such boxes.','H2_volume_Arb512':ball(arrvol(HR))},'partition':{'axis_endpoint_counts':[len(es) for es in ends],'axis_endpoints':[[eo(e) for e in es] for es in ends],'implicit_full_cell_count':prod(dims),'stored_z_bitset_row_count':nr,'incidence':'All actual C_S, H2 and both candidate carriers included before selection. Exact endpoint ranges determine whole open cells; no midpoint/sample centers.','volume':'Outward Arb512 cell/slab integration; endpoint formulas exact rational radicals.','unresolved_endpoint_signs':0},'complete_Rlo_volume_Arb512':ball(J),'extrema':ext,'quantile':trimres,'comparison':{'selected_mass_extrema_minus_quantile_exact':str(em-tm),'selected_mass_quantile_over_extrema_exact':str(tm/em),'full_carrier_fee_extrema_minus_quantile_Arb512':ball(diff),'full_carrier_fee_quantile_over_extrema_Arb512':ball(tf/ef),'full_fee_direction':fee_direction,'any_finite_cost_metric_strictly_improved':bool(tm<em or diff>0),'general_cumulative_source_budget_proved':False},'runtime_seconds':time.perf_counter()-t0,'peak_rss_bytes':memcheck(),'processes':1}
 signal.alarm(0);return ans

def frozen():
 eps=F(1,100)
 p=[(p,F(1)) for p in product((-F(3,4),F(3,4)),repeat=2)]+[((sg*F(19,20),F(0)),eps) for sg in (-1,1)]+[((F(0),sg*F(19,20)),eps) for sg in (-1,1)]
 yield 'initial_n2_fourcore_four_tiny_d19over20',2,p
 for d in (F(99,100),F(999,1000)):
  p=[(p,F(1)) for p in product((-F(1,2),F(1,2)),(-F(1,2),F(1,2)),(-F(9,10),F(9,10)))]+[((F(0),F(0),sg*d),eps) for sg in (-1,1)]
  yield 'obstruction_n3_eightcore_two_tiny_d'+str(d).replace('/','over'),3,p
result={'status':'RUNNING','cases':[],'precision_bits':512,'arithmetic_scope':'Fraction exact masses/quantiles and endpoint expressions, certified algebraic endpoint ordering; full continuous coverage by exact whole-cell incidence; outward Arb512 fee/volume integrals, not exact rational volumes.','interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'processes':1,'guard_seconds_per_case':120,'guard_peak_rss_bytes':LIMIT,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
try:
 for name,n,p in frozen():
  result['cases'].append(run(name,n,p));args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  last=result['cases'][-1]
  print(json.dumps({'stage':'case_complete','name':name,'Rlo':last['complete_Rlo_volume_Arb512'],'comparison':last['comparison'],'extrema_selected':last['extrema']['selected_count'],'quantile_selected':last['quantile']['selected_count'],'runtime_seconds':last['runtime_seconds'],'peak_rss_bytes':last['peak_rss_bytes']},ensure_ascii=False),flush=True)
 result['status']='PASS_THREE_FROZEN_FULL_RLO_SELECTED_COVER_EXPERIMENTS'
except Exception as e:
 signal.alarm(0);result['status']='STOP_GUARD_OR_CERTIFICATE_FAILURE_NO_TRUNCATION';result['error_type']=type(e).__name__;result['error']=str(e)
 result['runtime_seconds']=time.perf_counter()-START;result['peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');raise
result['runtime_seconds']=time.perf_counter()-START;result['peak_rss_bytes']=memcheck();args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'runtime_seconds':result['runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes']}))
