# R582 作者关键新增及真实联合势：整合前独审

**结论：下列明确范围内通过，无必须修复项；未得到完整来源价格或根阶预算。** 固定N完整 full-union 极值及最少正标签数的逐轴接触顶点归约是一般严格结论；整 carrier 费用、降质量分离、修正后的完整差集势变动也严格成立。它们尚未控制初始化/插入费用、全族来源重复或接触点的 exposed 压力。

先按准确命题独立推导，再对照作者稿。锁定已审版本：

| 文件 | SHA256 |
|---|---|
| `/tmp/ccu_r582_sol_global.md` | `05642d81f62aa3fa1d5d201c8f4fa1dd6e4be62e8a4dd0a54a5d033f6b225c9e` |
| `/tmp/ccu_r582_astra_global.md`（修正版） | `9ff61d2f2ee9d6f9fc14274a35481672c7a978ddbce7c9878996fee972fa5bfb` |

实际先读到的 Astra 旧版 SHA `3ac43ae433c30a03cd105f26ffa4e062ceca2a4ef6f10184ff0ae6bf18d13fd7` 不作为最终通过版本；其单面删层联动其他 bbox 极值的问题现已修正。未读数值占位中的最终报告，未重放完整数值。

## 1. 固定N完整极值与最少q归约

Sol A 与此前独审相符。对象是 lambda=W=1 的 **全部非空实际 C_S 的 union**，不是 R_lo 或固定 greedy H2 的残余函数。正标签 unit-distance components 的实际 receiver 不交，选最大 V_j/W_j 后同时归一质量和放大位置，再遇断裂就减少正标签数，给固定N有界正常形。非负 simplex 中零标签对完整 union 无影响，有限盒交体积及 inclusion-exclusion 连续，故 C_N 真达到。作者额外粗界 C_N<=N 亦成立：每个 receiver 至少落在一个原正来源的边长1 cube 中。它仍依赖N，未给N一致维数界。

在全局 C_N 最大配置中选择最小正标签数 q 是合法的有限整数选择；必须删除零质量槽后，仅对这 q 个正标签的位置建 endpoint chamber。它不是任意预设质量向量的位置极值的最小标签声明。

固定质量及其他轴、锚 z_(1,a)=0。所有候选仿射端点排序的闭 polyhedron P 上 V仿射，连续延伸到接触边界，且 V<=C_N。最大面 F非空。若 F有非零 recession v，锚使 v_1=0，所以至少两个不同 velocity 组。沿 y+tv 的全 union 始终取 C_N；t充分大时跨组来源在该轴距离>1，所有跨组盒空、组 receiver 两两不交，组内相对几何不变。因此

`C_N=sum_g W_g(V_g/W_g)`，

每个归一组都是正标签数严格小于q、总质量1的允许输入，故 ratio<=C_N；加权平均等号迫使至少一个（事实上每个）正质量组 ratio=C_N，违反q最小。此处不需要假设各组在原配置有正 exposed area 或可见边界。

非空 polyhedron F若无非零 recession则有界：无界序列相对固定点归一，单位极限满足全部齐次约束，会产生 recession。故 F为非空 compact polytope，有顶点；因F是P的face，该点也是P顶点。锚后维数q-1，全部有效 active endpoint equations 的法向 rank达到q-1。忽略同一 source index 的平凡恒等式后，其接触图必须连通，否则某分量整体平移仍为非零自由方向。q=1时结论为空条件。

逐轴替换为该顶点保持全局最大和原正质量数；其他轴的端点等式只依其自身位置及固定质量，后续替换不破坏先前 contacts。因此可取每轴有q-1独立 candidate contacts 的全局最大配置。

**范围限制通过：** contacts未必是正 exposed union faces，可能来自隐藏盒或其他轴为空的盒；没有正曝光、极值标签正比例质量或载体费用下界。有限contact reduction不是一般rootbound，也没有N趋无限时的统一紧性。

## 2. Regular-stratum 真导数与 Euler 不提供预算

Sol B、D 的位置/质量微分只在固定极值拥有者、无重合 exposed planes 的 regular stratum 上使用。盒上端点为 min z+r_S/2，下端为 max z-r_S/2；故位置导数的上面正号、下面负号正确。质量导数对每个包含i的S移动两端半宽 `r_S/(2n m_S)`，hidden faces按0计。这里用未受质量simplex约束的bare偏导，再讨论sum m_i=1上的驻点，二者没有混淆。

质量加权求和给 `sum_i m_i dV/dm_i=(1/(2n))sum_S r_S A_S`；完整union的坐标面通量给

`nV=sum_(i,a) z_(i,a)dV/dz_(i,a)+n sum_i m_i dV/dm_i`。

这是有限盒union的真实面通量/共同缩放恒等式。光滑位置驻点只得到 `sum_i m_i p_i=lambda V`，等质量价格只等于未知极值ratio；并无更小维数系数。实际接触顶点上不能随便取一个邻接stratum的梯度置0。作者明确区分bare导数价格与下降cover的计数价格h_i，未从Euler导出未证容量。

## 3. 降质量 whole-carrier cover 的完整性与费用

Sol前部选择完整原带中仍有正 fresh receiver 的最大质量S，初始 R_lo补集和低质量base。Fresh点在原H2外，使每个捕获原子质量<M/2，完整标签前缀首次达到M/2得到 proper实际K，`M/2<=k<M`。无需预先覆盖C_K，因为整个B(K,M)的新部分实际付款并加入E。

半core beta_K<b及R573正部产品给

`lambda|B(K,M)|<=M(1-s+s beta_K)<=M[b+log2/n]`，`s=(k/M)^(1/n)`。

该系数是**full carrier**系数，没有把R581 shell的额外1/n错加或漏掉；不要求K是虚拟动作。有限原实际族使正事件有限，剩余有限零测集可免费并入，故 `J=c0+sum p<=2W+(b+log2/n)sum M`。选最小价格实际半core后，`P_final=sum_i m_i h_i=sum k`，准确 `sum M<=2P_final`；未证明P_final根阶所需的O(n polylog W)预算。

Descending的几何结论只先给旧K不包含于新S。Sol的4h抽象计数在这个**必要集合条件**层面正确：每个至少h的core最多包含于binom(3h,h)个2h-parents，ratio至少2^h，因此仅靠非包含、降质量和halfcore价格不足以证明总价。作者明确不是实际cube反例，不否定真实carrier还能淘汰非包含parent的几何作用，未据抽象计数否定一般目标。

## 4. Astra完整分位、尺度及H4可选费用

修正版保留原输入和H2，直接对实际last T用tau=M/(4n)作inclusive weighted quantile；strict外尾删除、端点完整层保留，使k>=M/2，ties和重原子不拆。即使K=T也可购买fullcarrier，不需要proper-core旧覆盖信用。半core低beta及上述full费用界适用。

按M降序选择时，新m_S<=旧M，避开旧全修剪B(K,M)可排除旧T一条含端点尾，质量**至少**tau，且它在旧半径r_M外；S在更小r_S内，故确有 `nu(T\S)>=tau`。这补上此前升尺度路线缺少的尺度方向，仍未把旧缺失质量说成历史首次新容量。

若先proper halfcore再trim，则可能仅quarter parent，原H2半core资格不能沿用。作者另付原块扩张H4，安全界 `lambda|H4|<=4sqrt(n)W`，才可用quarter低beta与log4系数。H4不会自动证明quarter core的C_K已在原带中或已被旧覆盖包含；若以后需要此种baseline信用仍须另证。作者本次采用第1节fullcarrier路线，不使用该免费baseline，也未把H4当免付项。

理论(3)为 **>=tau**；允许等号。冻结数值若恰有严格 `>tau` 只说明那些有限输入，不能把理论强化成统一严格版。来源份额omega<=nu|T的(6)及缺额项M-a正确；遗漏可由其他参考占用，并非可重复领取的新容量。

## 5. 修正版完整差集的势变动

固定一个真实cover及其原见证groups、质量上限M_e和共同coreK_e，`k_e>=M_e/2`。保持输入与H2不变，source multiplicity为实际核心出现次数L_i。势

`E_eta=lambda|H2 union union_e A_e|+eta sum_i m_i(L_i-1)_+`

合法记录同一cover的实际体积与真实重复，不是另一个来源measure。

删某整层D_e后必须重算**全部实际bbox端点**。因K'_e⊂K_e且保持半质量，A'_e包含A_e并保护所有原parent receiver。通用新增区域严格为 `L=A'_e\A_e`；全部同步端点可逐一放松成嵌套盒，差集互不交覆盖完整L。跨空宽阈值取真实差集，不能套正宽导数。

旧版单条公式(8)现在明确只在其他全部实际端点不变、仅一面移动且正宽时用。通用动作都用

`q=lambda|L\G_-e|`，

因此其他方向联动扩张及corners没有漏付。每个被删标签出现次数减少1，其重复惩罚下降恰为 `m_i 1{L_i>=2}`，所以

`Delta E_eta=q-eta sum_(i∈D_e,L_i>=2)m_i`。

以q<=eta d作为接受条件确给非增动作；ties整层、半质量和完整覆盖均保持。未完成全方向分位时不继承统一tau，作者新增的量词限制正确。

## 6. 合法共同core合并与未付初始化

合并必须保留被合并groups的全部原parent witness，并选其共同实际K、M=max M_e、k>=M/2。B(K,M)包含每个原parent接收盒，故保护目标。若共同K也包含于每个旧K_e，则旧carriers均在新carrier内；更一般允许撤销无用overshoot时，必须按作者所述计算前后**真实全union**的有符号体积及D的准确变化，不能假定D必自动下降或把移除overshoot当作丢弃目标。

该可撤销静态cover势不同于不可退款的逐次实际现金账；作者把不可撤销模式限在单调扩大trim动作，没有把撤销信用冒作历史已付费用的返还。所有新core非空及半质量要求使carrier有限，未用空交定义全空间。

非增动作本身没有根阶初始界。若从空引用逐次插入，新core对已占用标签的重复惩罚跳跃仍须付款；若从全cover开始，初始D和volume都可能已是未知大账。终止时各候选完整新增区域之间不保证不交，半质量卡住的重复也没有剩余动作。作者准确保留这些缺口，没有将逐条终止不等式相加为全族容量。

## 审核操作与停止范围

实际全文审读上述两个确切hash，未运行完整数值、作者已做的SymPy或新的输入扫描；这里新结论以有限图/多面体、实际盒差集、面微分及计数的书面推导核验。未修改作者、最终报告或仓库，未git/PDF/开代理。

**可整合为一般严格结论：** 固定≤N fullU极值与最小q逐轴candidate-contact vertex；完整下降cover与fullcarrier局部费用；原尺度降序分位缺失质量；修正版完整差集/重复惩罚的准确势变动与接受条件。**未付：** 全族最终source price、联合势初始化/插入/终端与外向区域共同容量、任意N一致根阶上界，以及R_lo到一般目标的新改善。作者审完成，停止；未完成主报告另待指定版本审核。
