# R356 — An actual source-union certificate pays a whole original B_H layer branch

## Result and scope

One candidate was tested: use the full-f mass of the essential union of the ACTUAL sourcewise receiver cubes to lower-bound the ORIGINAL common-source square. It gives the conditional but genuinely payable branch below. It does not give the general root bound, and neither mass comparability nor the R353 crossing condition is claimed to imply its hypothesis.

For every 0<delta<1 there is an explicit original (y,r)-layer set L_delta such that

    B_H restricted to L_delta <= delta X_q.        (1)

Its W fee is zero. The complementary layer set keeps its original Q/J integrand. This is an alternative direct partition of the original B_H, not an extra fee to stack on top of all already-paid R353 branches.

## 1. Frozen original field

Retain actual Lebesgue receiver measure, the original E_r, m_u=integral f c_u=q_u R_u^n, dmu(u)=du/m_u, and the original clock

    ell=b^{-n}delta_b+n r^{-n-1}dr,
    ell([R_u,b])=R_u^{-n}.

At a fixed original source/time pair (y,r), write

    A(z)=A_yz(r)=integral_{E_r}c_u(y)c_u(z)dmu(u),
    J=J_y(r)=integral_{E_r}c_u(y)dmu(u),
    M=M_y(r)=integral f(z)A(z)dz.

In the full matching field, the SAME receiver masses give the exact simplification

    M_y(r)=integral_{E_r}c_u(y)du.                 (2)

Define the essential source union and its true full-f mass by

    U_y(r)={z:A_yz(r)>0},
    S_y(r)=integral_{U_y(r)} f(z)dz.               (3)

This is a measurable set/value from the already measurable A. It avoids adding cubes belonging only to null receiver sections. We have S<=W. On J>0, M>0 for almost every relevant y because f-matched receiver masses are positive; any zero-M case contributes zero and is handled separately.

The layer contribution to the original hard quantity is

    B_y(r)=Q_y(r)/J=M-(1/J)integral f(z)A(z)^2dz.  (4)

No independent source posterior or new receiver measure is used.

## 2. The source-union square lower bound and exact variance remainder

For S>0, Cauchy–Schwarz on the actual measure f(z)1_U dz gives

    integral f A^2 >= M^2/S.                      (5)

More precisely, define

    V_y(r)=integral_U f(z)[A(z)-M/S]^2dz >=0.

Then

    integral f A^2=M^2/S+V_y(r),
    B_y(r)=M[1-M/(JS)]-V_y(r)/J.                  (6)

The ratio M/(JS) is the actual average coverage fraction of the union under its full-f source measure. Since A<=J, it belongs to (0,1]. This identity connects the real common-source square to a nonlinear union-mass quantity without estimating arbitrary f by a boundary volume.

For 0<delta<1 define the original high-layer set

    L_delta={(y,r):J_y(r)>=H,
          S_y(r)<=M_y(r)/[(1-delta)J_y(r)]}.       (7)

Equation (6) proves, pointwise on this set,

    0<=Q_y(r)/J_y(r)<=delta M_y(r)-V_y(r)/J_y(r)
                         <=delta M_y(r).         (8)

Thus this is a whole-layer payment. It does not merely pay a selected fraction of z or replace the original source with a favorable subset. The variance term in (8) is part of the same original square and is not spent elsewhere.

## 3. One global payment under the original clock

Integrate (8) with f(y)dy and the original ell. By (2), positive Tonelli, and the exact inclusive clock tail,

    integral ell(dr) integral f(y)M_y(r)dy
      =integral_E [integral f(y)c_u(y)dy]
                       ell([R_u,b])du
      =integral_E m_u R_u^{-n}du
      =X_q.                                       (9)

Therefore (1) follows, with complete constants

    receiver fee: delta X_q,
    source fee: 0,
    extra scale/layer fee: 0.

There is an exact disjoint decomposition

    B_H=B_good,delta+B_bad,delta,
    B_good,delta<=delta X_q.                       (10)

The remainder is precisely the original Q/J integrand on J>=H and S>M/[(1-delta)J]. No new source/endpoint/clock is inserted into that remainder. If used at the historical entrance with factors 2 and Lambda=128/119, the fee becomes 2 Lambda delta X_q=(256/119)delta X_q. This price is not added on top of prior payments for the same original layers; the chosen ledger partition must be disjoint.

For the original B_H(f,nu) with nu<=f, the established positive domination by the full-f matching hard expression must be invoked first. One cannot apply the exact cancellation (2) directly to arbitrary separately masked two-source data.

## 4. A genuine geometric sufficient certificate

The union in (3) has an actual spatial localization:

    U_y(r) subset Q_{2r}(y),                       (11)

where Q_{2r}(y) has side length 2r. If A_yz(r)>0, an actual receiver u with R_u<=r captures both y and z. Hence

    ||z-y||_infinity <= ||z-u||_infinity+||u-y||_infinity
                     <=R_u<=r,

which proves (11), with the usual harmless null sections.

Accordingly the fully explicit local-mass test

    integral_{Q_{2r}(y)} f(z)dz
         <=M_y(r)/[(1-delta)J_y(r)]                (12)

implies membership in L_delta and the same delta X_q payment. Using the exact essential union is sharper than (12). The mass in (12) is the actual full-f integral; it is never estimated by volume times an invented f bound.

The test can also be certified by any proved containment of U_y(r) in a measurable source set V_y,r whose TRUE f mass is below the right side of (7). In particular an actual accepted enclosing receiver cube can serve as such a certificate if its containment and matched-mass bound are checked. Mere center proximity or comparable radii is not such a certificate.

This differs from assuming the pairwise agreement conclusion Q<=delta JM: it gives a sufficient test using a first moment and the full-f mass of a geometrically localized source union. It still requires a genuine mass certificate and does not establish that the favorable layers have a uniformly positive share of B_H.

## 5. Relation to R355 P+I and the unresolved general part

At every original r, integrating (5) in f(y)1_{J>=H}/J gives a lower bound for the exact original negative term P(r)+I(r) from R355. The proof above localizes this lower bound to L_delta before integrating the original clock, so it is a positive estimate of the original cumulative quantity, rather than merely a new square representation.

The complementary branch may have large source-union mass relative to the average captured mass. Neither the true-dx column estimate, the fixed L4 occupancy estimate, nor mass comparability has been shown here to rule this out or to pay that complement. The R353 crossing guard is attached to an initial marked witness and does not imply (7) for all original layers; it was not migrated to current endpoints.

Thus this candidate produces the explicit conditional receipt (1), but the general estimate

    B_H<=delta X_q+C_delta sqrt(n)log^A(n+2)W

remains unproved. No claim about extrema, optimizer existence, uniform f, or the sign of the original constrained second variation is made. Only the present union-mass candidate was pursued.

## 6. Executed exact checks

Python fractions.Fraction was actually run on 5,103 finite source/coverage arrays. It verified the exact variance identity (6), and on 9,837 qualifying delta tests verified the whole-layer inequality (8). Output:

    PASS: 5103 exact union-mass variance identities;
          9837 conditional layer payments

These are algebra diagnostics, not examples asserted to satisfy every original cube/high-past/crossing gate. Equations (2)-(12) are the analytic proof for the actual full-f receiver field.

Only /tmp/r356_square.md was authored. No other research file or Git state was changed.
