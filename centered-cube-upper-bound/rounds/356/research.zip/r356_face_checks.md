R356 independent single-face capacity support

Frozen fresh standard-library local Python processes returned PASS 2,949 exact Fraction assertions. Continuous geometric calculations: initial 180, boundary stress 381, expanded 162 (723 total). Separate finite terminal-face accounting: 71,348,1807 (2,226 total). No floating-point comparison determines an assertion.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r356_face_checks.py
```

The portable self-contained script writes r356_face_checks_result.json beside itself. The earlier r356_numeric.py/result/md matched-S tests remain frozen and unmodified. Only this note and the new face script/result comprise this additional evidence.

Continuous geometry. In absolute-coordinate unit cube [0,1]^n, fix one coordinate i. The CLOSED cone condition x_i>=sigma max_j x_j has volume fraction

alpha=1-sigma+sigma/n.

Two independent integration decompositions are evaluated exactly. Slicing x_i=t gives integral_0^sigma (t/sigma)^(n-1) dt plus the slab of volume 1-sigma; sigma=0 is handled separately. Partitioning by the unique maximum coordinate (ties null) gives 1/n when i is maximal plus (n-1)(1-sigma)/n otherwise. Both agree with alpha. This is the absolute-coordinate fraction; the orthant factors cancel when restored to the centered cube.

For a radial receiver selector R(x)=max(a,2|x|_infinity) inside Q_b, the low-radius single-coordinate strip has normalized volume 1-sigma. On a<2|x|_infinity<=b the cone fraction gives radial coefficient n alpha=n(1-sigma)+sigma. For 0<sigma<1 the strict face |x_i|>sigma R(x)/2 has the same cone fraction (the equality boundary is null). The resulting analytic radial capacity is

B1=(1-sigma)+[n(1-sigma)+sigma] log(b/a).

At sigma=1 the actual STRICT face is empty: strict cone fraction and actual capacity are zero. The closed-cone fraction 1/n is instead the non-strict value and the sigma-up-to-1 left limit. B1(1)=log(b/a) is still a valid non-sharp upper bound, not the strict radial capacity. The result records closed and strict fractions separately. Sigma=0 is an extended-boundary diagnostic; the main theorem assumes sigma>0.

The code compares the coefficient with n alpha and encloses each log by 100 terms of the positive atanh series with its explicit geometric remainder. Ratios b/a=1,3/2,2 are tested. These are exact analytic integral evaluations in finite parameter cases, not a numerical proof of the general envelope theorem.

Additional real receiver-dx check. For n<=64, a four-interval radial menu is assigned piecewise on actual receiver shells Q_rj minus Q_r(j-1). At fixed R=r_j the exact strip volume is

(1-sigma) r_j^n - r_(j-1)^(n-1) [r_(j-1)-sigma r_j]_+.

Dividing by r_j^n and adding the actual R=a inner strip gives the exact continuous receiver integral. It is checked against a rational lower endpoint of B1 (or exact equality when a=b), which is stronger than comparison with an outward upper endpoint. These are actual dx shell integrals, not receiver point weights. At sigma=1 both these finite piecewise-constant fields and the strict radial selector have zero face mass; the nonzero log expression is only an upper bound from the closed-cone coefficient.

Three-stage range. Initial n=1,2,3 with sigma=1/4,1/2. Stress n=1,2,16,64 with sigma=0,1,1023/1024, including degenerate b=a and narrow strips. Expanded n=256,1024,4096 with sigma=1/2,1-1/sqrt(n),1-1/4096. The n=1 cone fraction is exactly 1, sigma=0 fraction exactly 1, and sigma=1 CLOSED fraction exactly 1/n, while its STRICT fraction is zero. For example n=4096,sigma=4095/4096 gives alpha=8191/16777216 and log coefficient 8191/4096; the root-thickness choice sigma=63/64 instead has coefficient 4159/64. Both are stored exactly. No dimension trend is fitted.

Separate finite terminal-face accounting. The new finite data have THREE indices T[j,i,z]: generation j=0,...,N-1, coordinate i=0,...,d-1, and source z. Dimensions are d=8N, deliberately different from N. Each per-generation, per-coordinate source column obeys 0<=T[j,i,z]<=B1=1/2. The cumulative coordinate column is Li(z)=sum_j T[j,i,z], so every coordinate obeys Li<=NB1. Sources select their own maximizing COORDINATE, not generation.

Terminal mass is generated from actual finite mass atoms, rather than declaring an unrelated L. Each source uses one of three explicit patterns in every generation:

- A concentrated mass-B1 atom is assigned to one source-specific coordinate face.
- Two mass-B1/2 atoms are assigned to {focus,next} and {focus}, respectively; this produces genuine overlapping face cover.
- d separate mass-B1 atoms are assigned to the d individual coordinate faces.

Every atom has a nonempty face set. The program adds atom masses once to l_j(z), while adding each atom to every face assigned to it in T[j,i,z]. Then L(z)=sum_j l_j(z). It checks per-generation coverage and the full-source inequalities max_i Li(z)<=L(z)<=sum_i Li(z). Thus no uncovered terminal mass is inserted and face overlap is allowed without duplicating L.

For theta=1/4, a source is selected when max_i Li>=theta L. Its complete terminal mass is bounded by max_i Li/theta<=NB1/theta. The exact source-integrated selected part is at most NB1 W/theta. Original cost splits exactly into selected and retained parts. Concentrated sources are selected. The direction-dispersed sources have L=dNB1>NB1 and max_i Li=NB1, so they lie in the unselected complement. This explicitly shows why total L must not be assumed bounded by NB1.

| Generations N | Coordinates d | Selected fraction | Retained fraction |
|---:|---:|---:|---:|
| 2 | 16 | 7/71 | 64/71 |
| 4 | 32 | 5/133 | 128/133 |
| 8 | 64 | 17/785 | 768/785 |

These are separate finite terminal-face mass constructions, not native paths or actual receiver dx. Choosing a different maximizing coordinate for each source introduces no extra factor d in the paid gate: the maximum is bounded by NB1 before integrating. The construction verifies only this finite accounting interface, not the assumptions of a true path-source marginal theorem.

Scope. Continuous cone/strip and real radial receiver-shell geometry are distinguished from finite source-column matrices. No original q-band, high-past/core/history, native paths, receiver marginal propagation, universal root payment, or unpriced total-source L bound is certified by these tests. Large retained fractions are reported explicitly rather than treated as paid.
