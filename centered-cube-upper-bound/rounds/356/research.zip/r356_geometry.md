# R356 — A single-face capacity pays direction-concentrated terminal sources

## Proved outcome

Keep the complete R355 marked path process and its remaining normal-terminal measure F_shell. This note changes no transition, stopping rule, posterior, or original gate. It splits only the existing terminal-source event.

Write

    x=√n,  s=1+x,  A_n=1+n log(b/a),
    N=max(1,ceil(log[(λ/q_-)(b/a)^n]/x)),
    σ^n=min(1,s/(N A_n)),  L_n=log(n+2)>1.

Here σ is exactly the common R355 inner shrink factor σ_*. Define

    B_1(σ)=(1−σ)+[n(1−σ)+σ]log(b/a).                 (1)

Let f(z)L(z)dz be the actual terminal-source marginal of F_shell. Let f(z)L_i(z)dz be its further restriction to the event that the terminal receiver w has

    |w_i−z_i|>σR_w/2.                                (2)

The coordinate events may overlap. The exact full-source accounting and actual-center geometry give the new joint bound

    max_{1≤i≤n} L_i(z)≤N B_1(σ)  for a.e. z.          (3)

For any 0<ϑ<1, set

    S_ϑ={z:L(z)>0, max_i L_i(z)≥ϑL(z)}.

The entire terminal traffic with source z∈S_ϑ, not just its dominant-face fraction, is paid by

    F_face(ϑ):=∫_{S_ϑ}f(z)L(z)dz
        ≤[N B_1(σ)/ϑ]∫_{S_ϑ}f(z)dz
        ≤[N B_1(σ)/ϑ]W.                             (4)

Choose ϑ=1/L_n. The exact decomposition and payment are

    F_shell=F_face+F_diff,
    F_face≤C_dir,n W,
    C_dir,n=N B_1(σ)L_n.                             (5)

On the nonempty original high-past branch, the already audited bounds N≤√n and n(1−σ)≤log n imply

    C_dir,n≤3√n log²(n+2).                            (6)

Thus (5) is a genuinely new root-times-log-squared source payment and has no new X_q fee. The remaining terminal sources satisfy

    L_i(z)<L(z)/log(n+2)  for every coordinate i.      (7)

No independence, isotropy, or global bound for this direction-diffuse remainder is asserted.

## 1. Frozen field and what is retained

Use the same arbitrary nonnegative f∈L¹, W=∫f, actual Lebesgue receiver set E, and centered cubes

    Q_w=w+[-R_w/2,R_w/2]^n,
    m_w=∫f1_{Q_w}=q_wR_w^n,
    q_-=3λ/4≤q_w≤λ,   a≤R_w≤b≤2a,
    π_w(dz)=f(z)1_{Q_w}(z)dz/m_w.

The R355 process starts with the original R353 crossing entrance. Every initial label remains fixed, including old source y, old small receiver, old u, full J, ηΩ, original physical clock including its terminal atom, all original high-past/outside/prefix gates, and initial witness w_0. The old-time crossing condition belongs only to (y,r,w_0); it is not moved to later receivers.

The process retains the true noncyclic rank subkernel, strict factor-K mass growth, and at most N receiver visits. At a visit it first stops an inner-rich receiver, then samples from the unchanged full-f posterior. It tests inner-source stopping, then ancestor recapture, then rank termination or continuation. All tests delete their actual probability without renormalization.

The arriving actual receiver density at every generation is at most q_w. Every path contributing to F_shell has, at each visited receiver, posterior shell mass greater than 3/4. Every actually sampled source is in its current receiver's shell and avoids all earlier ancestor cubes. These are the already proved R355 facts; none is replaced by an assumption of cross-path disjointness.

## 2. The terminal joint law must be controlled before forgetting its source

Let κ_j(w)dw be the actual arrival measure before the tests at generation j, so 0≤κ_j≤q. Keep all its past marks. Conditional on that marked arrival at a nonrich receiver, the source draw is exactly π_w, before any current source or rank test.

The terminal event at that visit is a positive restriction of this true draw. Therefore its (z,w) marginal has a measurable representation

    dT_j(z,w)=f(z)1_{Q_w}(z) k_j(z,w) dz dw/m_w,
    0≤k_j(z,w)≤κ_j(w)≤q_w.                           (8)

For example k_j includes the nonrich indicator, the inner-source exclusion, the conditional ancestor-avoidance factor obtained from the retained history, and the genuine missing-rank probability. Each factor is between zero and one. Standard disintegration of the finite marked history measure gives this representation; no new favorable source law is chosen.

The key input is the full joint domination (8), not merely a bound on the terminal receiver marginal. Conditioning on terminal success would generally change the source posterior, and is not used.

Define

    L(z)=sum_{j=0}^{N−1}∫_E 1_{Q_w}(z)k_j(z,w)dw/m_w,
    L_i(z)=sum_{j=0}^{N−1}∫_E 1_{Q_w}(z)k_j(z,w)
                      1_{|w_i−z_i|>σR_w/2}dw/m_w.    (9)

Then exactly

    |F_shell|=∫f(z)L(z)dz,
    0≤L_i≤L,
    L≤sum_{i=1}^n L_i.                               (10)

The last inequality follows because every actual terminal source is outside σQ_w and inside Q_w, so at least one event (2) holds. It is not an equality in general, since several coordinate faces can be close at once.

The sum in (9) uses the finite original horizon. All old path labels still exist above this marginal and remain attached when a source event is restricted below.

## 3. Actual-center capacity of one coordinate face

For each source z, coordinate i, and 0<σ<1,

    ∫_E 1_{z∈Q_w}1_{|w_i−z_i|>σR_w/2}R_w^{-n}dw
       ≤B_1(σ).                                     (11)

Translate z to the origin and put r=2||w||∞. The source-capture and face gates imply

    r≤R_w≤b,  R_w≥a,  2|w_i|>σR_w.

First consider r<a. Then R_w^{-n}≤a^{-n}, and contributing centers lie in the cube of side a with |w_i|>σa/2. Its exact volume is (1−σ)a^n, giving contribution at most 1−σ.

For r≥a, use R_w^{-n}≤r^{-n}. The face gate implies the homogeneous cone condition

    |w_i|>σ||w||∞.                                   (12)

The proportion of the cube of side r occupied by this cone is

    c_i(σ)=1−σ+σ/n.                                  (13)

One direct proof works in the positive orthant: if the i-th absolute coordinate normalized by the cube half-side is t∈[0,1], the other coordinates must be less than t/σ. For σ<1 the resulting volume is

    ∫_0^σ(t/σ)^{n−1}dt+∫_σ^1 1dt=σ/n+1−σ.

Signs give the same fraction. Because the cone is homogeneous, its volume inside the cube of side r is c_i(σ)r^n, whose shell derivative is n c_i(σ)r^{n−1}dr. The high-radius contribution is thus at most

    ∫_a^b r^{-n}n c_i(σ)r^{n−1}dr
       =[n(1−σ)+σ]log(b/a).

Adding the low-radius contribution proves (11).

This is genuine receiver-center geometry. The small parameter is the angular fraction of a specified coordinate's face region in an actual center shell. It is not an f-mass estimate for a thin boundary layer. In particular, no cap on arbitrary f is introduced.

### Boundary cases

For n=1 and σ<1 the cone fraction is one, and (11) reads

    capacity≤(1−σ)+log(b/a),

consistent with the direct one-dimensional center integral.

At σ=1 the strict face event in (11) is empty. We keep the formula B_1(1)=log(b/a) as a valid, possibly non-sharp upper bound, and prove this endpoint separately by zero≤B_1(1). Formula (13) is not used at σ=1: the strict cone event has an endpoint discontinuity there. The actual R355 remaining flow is zero when σ=1, because π_w(Q_w)=1 triggers its rich stop at every receiver.

If b=a the logarithmic term vanishes, and the flat contribution 1−σ remains valid. Strict face boundaries are kept as written; no mass is discarded by changing a strict test to an unproved almost-everywhere convention.

## 4. Cross-path source-direction capacity and the paid whole-source branch

By (8), q_w/m_w=R_w^{-n}, and (11), each generation contributes at most B_1(σ) to each L_i(z). Summing at most N generations proves

    L_i(z)≤N B_1(σ),

simultaneously for all i, hence (3). No claim that the cumulative arrival density is at most q is made; the factor N has been paid explicitly. The gain is that a single-coordinate source-center capacity is logarithmic rather than root or linear in n.

Importantly, (3) also permits a different measurable coordinate i(z) for each source. A finite maximum is measurable; one can choose its smallest maximizing index. There is no factor n for this source-specific choice because (3) is a pointwise bound uniform over coordinates, not a union of separately priced receiver events.

On S_ϑ, L(z)≤max_i L_i(z)/ϑ≤N B_1(σ)/ϑ. Multiplication by the actual f(z) and integration proves (4). The whole terminal traffic over that source set is thereby paid, even if an individual tuple over that source uses a different coordinate face from its source's dominant direction. The factor 1/ϑ pays for exactly this distinction.

On {L=0}, all L_i are zero by (10), so there is no terminal-source mass. Define the source-heavy set with L>0 as above and put all zero-L points in its complement; no ratio by zero is used. A source point with f=0 also contributes no traffic, whatever versions of the L_i are chosen there.

Taking ϑ=1/log(n+2) is valid for every n≥1 because log(n+2)>1. Restricting the existing terminal measure to z∈S_ϑ and z∉S_ϑ gives the exact decomposition (5). It does not reconstruct the process, recompute f or J, or alter any old mark.

The remaining ratios L_i/L are probabilities of coordinate-face events under the original terminal joint law conditional on the same source z. They are not the individual receiver posterior π_w, and the events overlap. Equation (7) must not be interpreted as posterior independence, independent coordinates, or a claim of disjoint contributions from different paths.

## 5. Root-log-squared fee and its limits

On every nonempty original high-past branch, the R352/R355 guards give

    N≤x,
    n(1−σ)≤−n logσ=log(max(1,N A_n/s))≤log n.

Consequently, writing L_n=log(n+2),

    B_1(σ)
      ≤1+(log n+1)log 2
      ≤(1+2log2)L_n
      <3L_n.

Together with (5), this proves the explicit bound (6). The exact coefficient C_dir,n=N B_1(σ)L_n is retained when useful. If the original high-past branch is empty, F_shell is zero and no source fee need be assigned.

There is also a bound without that entrance guard: N≤3√n and n(1−σ)≤log(3n) give

    C_dir,n≤3√n L_n[1+(log(3n)+1)log2],

still of root-times-log-squared order. Neither version says the entire terminal flow is paid: the theorem pays only the source block S_ϑ, with the exact complement (7).

The remaining joint terminal traffic can be spread across many coordinate directions at each source. All original mass growth, shell, ancestor freshness, and initial old-clock crossing conditions remain in force there. No estimate for the total of that diffuse block follows here merely from its directional spread.

## 6. Complete incremental ledger

Use the R355 exact process and ledger unchanged until its F_shell slot. Substitute (5) once:

    B_H≤F_diff
       +[(13/3)ε+γ_eff+β+α_rec+c_eff]X_q
       +[C_{ε,n}+8s+C_dir,n]W
       +(D_top,n+C_hit,n+s)W_ex.                     (14)

Here all symbols other than C_dir,n retain their R355 meanings, including β=ε/16. The new fee is C_dir,n W, or the coarser 3√n log²(n+2)W on the original nonempty branch. It is full W because the terminal source is drawn from the full-f posterior, rather than from the original excess source g_ex.

There is zero new X_q fee and no second charge for R355 rich/inner stopping or R352 recapture. The old original-time crossing remains attached only to the initial w_0. Every other archived unpriced slot remains present.

Entrance factor two and exterior Λ multiply the new source cost, yielding 2ΛC_dir,nW. The receiver absorption coefficient and its conditional CZ accounting remain exactly those of R355; its unallocated balance is not spent on this source-only payment.

This proves a nontrivial common-source cross-path branch budget. It does not prove the general root weak-type goal or remove the remaining F_diff slot.

## 7. Executed reproducible checks

The following Python code was actually run. It passed 8,160 exact rational cone integrations and 2,400 exact source-block splits with overlapping face events. It separately checks the strict σ=1 endpoint. It also performs a floating-point Simpson check in a genuine one-dimensional center field: R(w)=max(a,2|w|), E=[−b/2,b/2], and f=1 on [−b,b] give m_w=R_w and q_w=1. The maximum quadrature error was 2.220446049250313e−15. That last diagnostic is ordinary floating point, not an exact certificate, and is not claimed to realize the original high-past/path contract.

```python
from fractions import Fraction as F
from random import Random
import math
cone_checks=0
for n in range(1,61):
 for den in range(2,18):
  for k in range(1,den):
   sigma=F(k,den)
   integral=sigma**n/(n*sigma**(n-1)) + 1-sigma
   assert integral==1-sigma+sigma/n
   assert n*integral==n*(1-sigma)+sigma
   if n==1: assert integral==1
   cone_checks+=1
# sigma=1 is separate: a strict selected-face coordinate cannot exceed the max.
assert all(not (F(k,10)>max(F(k,10),F(3,10))) for k in range(11))
rng=Random(356); split_checks=0
for n in range(1,9):
 for trial in range(100):
  weights=[F(rng.randrange(1,10),10) for _ in range(12)]
  faces=[]
  for _ in weights:
   subset={i for i in range(n) if rng.randrange(2)}
   if not subset: subset={rng.randrange(n)}
   faces.append(subset)
  total=sum(weights)
  loads=[sum(w for w,S in zip(weights,faces) if i in S) for i in range(n)]
  assert max(loads)<=total and sum(loads)>=total
  for threshold in [F(1,2),F(1,4),F(1,8)]:
   paid=max(loads)>=threshold*total
   if paid: assert total<=max(loads)/threshold
   else: assert all(v<threshold*total for v in loads)
   split_checks+=1
a,b=1.0,2.0
M=2000; lo=a/2; hi=b/2; step=(hi-lo)/M
quad=step/3*sum((1 if j in (0,M) else 4 if j%2 else 2)/(lo+j*step)
               for j in range(M+1))
err=max(abs((1-s)+quad-((1-s)+math.log(b/a))) for s in [.2,.5,.9])
assert err<1e-11
print('PASS',cone_checks,'exact cone integrations;',split_checks,
      'exact overlapping-face source splits;',
      '1D actual-center quadrature max error',err)
```

Only /tmp/r356_geometry.md was authored. The new proved fee is (4)–(6), and the direction-diffuse terminal block remains unpriced.
