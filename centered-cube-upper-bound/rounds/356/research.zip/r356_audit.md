# R356 final independent audit — PASS for the direction-concentrated terminal-source payment

This final audit replaces the preliminary status in this owned file. Independent screens were completed before reading the new proofs. The final geometry, main/ledger/README, both numeric modules and their notes/results, standalone geometry checks, and unadopted square/defect notes were read. Only this audit was changed; no author files or Git state were modified. The whole historical reduction is inherited rather than re-audited, and general arbitrary-input root-order weak-type closure is not certified.

## 1. Actual single-coordinate face geometry: PASS

For fixed source z, coordinate i, arbitrary measurable actual R_w in [a,b], and 0<sigma<1, capture and the strict face test imply t=2||w-z||_infty<=R_w and 2|w_i-z_i|>sigma R_w. In t<a the density is <=a^(-n) and the admissible strip has volume (1-sigma)a^n. In t>=a the density is <=t^(-n) and the admissible cone has cube-volume fraction 1-sigma+sigma/n. Homogeneity gives shell derivative n times that fraction, hence the exact upper coefficient
 B1=(1-sigma)+[n(1-sigma)+sigma]log(b/a).
This is an actual receiver-center envelope, not a bound on arbitrary f source mass or a fixed-radius strip-volume substitution. Absolute-coordinate signs are already included; no missing factor two occurs.

The final proof correctly separates sigma=1: its STRICT face event is empty, while B1(1)=log(b/a) remains a nonsharp positive upper bound. The closed-cone coefficient 1/n is not incorrectly asserted to equal that strict event. n=1, b=a, and zero terminal columns are handled. The initial independent screen also allowed the closed-face upper envelope; using the final strict face can only reduce the integral, and the endpoint distinction is explicitly preserved.

## 2. Correct terminal joint law and columns: PASS

The SAME R355 marked process is retained. Arrival at generation j has density kappa_j<=q. Before any current source or rank-success conditioning, its actual draw is the full-f posterior. All nonrich, inner-exclusion, ancestor-avoidance, rank-loss and history filters are probabilities in [0,1]. Thus the source/receiver normal-terminal joint measure has representation
 dT_j=f(z)c_w(z)k_j(z,w)dz dw/m_w,
 0<=k_j(z,w)<=kappa_j(w)<=q_w.
This joint domination, not merely an integrated terminal receiver bound, justifies the sourcewise capacity. The proof explicitly retains it and obtains simultaneous coordinate bounds L_i(z)<=N B1. It does not claim that cumulative receiver occupation is <=q.

L is the complete normal-terminal source column, and L_i the same measure restricted to coordinate i's strict face event. Their definitions sum over GENERATION j, with i a distinct coordinate index. Positive submeasure relations give 0<=L_i<=L. Because every actual remaining R355 terminal sample is outside sigma Q_w, L<=sum_i L_i; overlap between several faces is allowed, and L is not counted repeatedly. These columns describe current terminal source z, not the old original source y or individual receiver posterior pi_w.

## 3. Paid source class and its actual complement: PASS

For 0<vartheta<1, use the measurable source set {L>0,max_i L_i>=vartheta L}. On that set the ENTIRE source-terminal mass is at most NB1/vartheta times its true f mass. A finite source-dependent maximizing coordinate introduces no factor n because max_i L_i is pointwise bounded before source integration. It does not permit a private coordinate for each receiver event at the same price.

This is an exact POSTHOC positive partition of the already defined terminal measure; it need not be predictable since the transition/stopping process is unchanged. No new source law, clock, J, old gate, posterior or rank kernel is recomputed. Treating the selected source set as a new original input would require a new argument and is not done here.

Taking vartheta=1/log(n+2) pays C_dir W with C_dir=NB1 log(n+2). L=0 contributes no traffic and uses no ratio. On positive-L sources in the complement, every L_i<L/log(n+2). This is aggregate direction dispersion under the SAME terminal source joint law, not pathwise uniformity, coordinate independence, isotropy or a bound on the entire remainder. No fixed positive paid fraction for all inputs is proved.

The inherited nonempty original high-past guards N<=sqrt(n) and n(1-sigma)<=log n imply
 B1<=1+(log n+1)log2<3log(n+2),
so C_dir<=3sqrt(n)log^2(n+2). The simple inequalities log(n+2)>1, log n<=log(n+2), and log2<1 suffice for the constant three; no floating fit or dimension-dependent maximal constant enters. Empty old input has zero terminal flow and may be assigned zero fee. The unconditional larger bound in the proof remains separate. A thin coordinate layer may occupy most high-dimensional cube volume and may hold most arbitrary source mass; the proof does not assume otherwise.

## 4. Incremental complete ledger: PASS, no new X fee

The final ledger retains the complete R355 base account for comparison, then substitutes F_shell=F_dir+F_disp exactly once in that existing slot. The final W coefficient is C_epsilon,n+8s+C_dir, W_ex remains D_top+C_hit+s, and all receiver coefficients remain unchanged. The new source term receives entrance factor two and exterior Lambda, giving 2Lambda C_dir W. Rich/inner stopping, R352 recapture, the old clock, source clipping, peeling, and their prices are not charged again.

Under the explicitly conditional same-certified-X placement of the historical CZ term, receiver absorption remains <889/2304 with unallocated headroom >1415/2304. This is headroom rather than payment for an unresolved integral. The initial-witness-only old time/source crossing, all other soft/crossing and hard-contract-exterior terms, distance/low-pe/extreme-scale/threshold complements, chronological initial/deletion/future-deleted-source atoms, H/layer/source/physical-scale/outer-integral/truncation-limit fees and single-use negative credit are preserved. Auxiliary rank termination and physical ell's b atom do not replace chronological atoms.

The final ledger's copied base paragraphs identify prior-round fees before the explicit R356 incremental section; they are not new repeated charges. No general B_H or weak-type closure, nor an assertion that only constants/logarithms remain, is made.

## 5. Unadopted source-union and rank-defect notes

The square note's Cauchy certificate is valid in its stated hard shared-f field: M=int fA=int_{E_r}c_u(y)du, S=int f1_{A>0}, and int fA^2=M^2/S+V. Its favorable inclusive high-J layers have loss <=delta M-V/J<=delta M, and inclusive physical Tonelli integrates the entire first moment to X_q. J=0 or S=0 gives zero contribution with the stated conventions. S is an ESSENTIAL receiver-overlap union, S<=int_{Q_{2r}(y)}f; the larger halo is only a sufficient substitute. This conditional branch overlaps older payments and is NOT added to the adopted ledger. It is not a root estimate for its complement or an asserted general novelty result.

The defect note correctly proves I<=sigma P=sigma-d from the ORIGINAL full-source/clock column, not I<=C d. Its sourcewise bottom-rank defect and top-rank row loss are distinguished, and augmented old-source/rank singularity is not misread as receiver-marginal singularity. The old defect slice and Green identity do not pay the full entrance. No bridge from thin-shell posterior to bottom-rank posterior is proved. These notes introduce no extra fee or new credited tool in the adopted main account.

## 6. Code/results, actual execution, and scope: PASS

Read face_checks.py and its notes/result in full. Its corrected finite tensor has distinct indices T[j,i,z] for generation, coordinate and source, with N=2/4/8 and d=8N. Every terminal mass atom is explicitly assigned a nonempty coordinate-face set. It is added once to L and to each assigned coordinate's L_i, giving max_i L_i<=L<=sum_i L_i without uncovered traffic. The cumulative coordinate bound is NB1; source maximization is over i, not j. Concentrated, overlapping and direction-dispersed examples and their exact retained fractions are stored. The selected fractions 7/71, 5/133 and 17/785 leave explicit large complements. This is separate finite column accounting, not a native path or actual receiver-dx realization.

The geometric part distinguishes closed-cone from strict-face fractions, notably sigma=1, and computes exact cone/strip and piecewise radial-shell receiver-dx integrals. At sigma=0 it is an explicitly extended diagnostic, outside the theorem's positive-sigma domain. Rational atanh bounds are outward; comparisons against a lower log endpoint in the finite receiver examples are valid stronger inequalities. Face result metadata matches 2949 Fraction checks =723 geometric+2226 finite column. The frozen three face-file hashes match the parent's supplied final values.

The separate matched-S numeric module preserves actual positive source-box masses and complete physical cube incidences, but uses finite receiver quadrature weights. Its radius-prefix layer weights compress the original physical continuous measure by differences of inverse powers and the true terminal atom; no interior menu atoms are manufactured. Its 474 Fraction checks, conditional paid portions and unpaid remainder are reported honestly. Some radii exceed an octave and its higher-dimensional square examples are embeddings, not independent dimension-growth stress fields. It does not implement native q-band/high-past/history.

The parent reports fresh execution of 2949 face checks, 474 matched-S checks, and the geometry standalone proof script: 8160 exact cone cases and 2400 exact overlapping-face source splits, plus one ordinary floating-point 1D Simpson diagnostic with error about 2.22e-15. That floating error is not an interval certificate or high-dimensional path evidence. The standalone script is byte-identical to the geometry proof's unique embedded block. The square note's 5103 identities/9837 favorable tests and the defect's 27 checks are AUTHOR execution reports, not additional parent reruns; no standalone embedded Python for the square's reported 5103 is claimed present. The inherited defect-script dependency hash matches the referenced R351 file.

I did not repeat the parent pipelines. My separate independent preliminary computations were 194 overlap/Jensen/actual-1D examples and 161 face-cone/finite radial/source-gate cases. Final review checked stored result metadata and embedded-code identity. These auditor calculations are not added to the parent totals. Finite evidence supports the stated algebra and parameter checks; the real-dx receipt itself is the analytic proof above.

## Final conclusion

PASS for the adopted direction-concentrated normal-terminal source payment, its true joint-law foundation, strict endpoint/source-zero guards, constant-three bound, unchanged process and exact incremental ledger. General control of direction-dispersed cross-path traffic and the complete arbitrary-input theorem remain open. This bounded audit is complete.

## Frozen SHA256 bindings

Adopted files, reviewed auxiliary notes (not additional main fees), and necessary inherited interfaces. Binding old contracts does not mean a new exhaustive historical audit.

```
05d4c9d098fb0d025ad7ceb0922817e6e9a79ff6037a378e7d85f4d61a75a109  /tmp/r356_main.md
7fd942f032fc24995d15cc05e5f0d395326e5239e3f7c13c5704d8f9b1d845dd  /tmp/r356_ledger.md
31d68fc1701d11a804ba1a2c9cd71e58be57623b3a4d6a57d14a2214b69550e3  /tmp/r356_readme.md
fdd9f88782dad7028ebe8004e3e75148f3e72770a502eb185dc216124bef3394  /tmp/r356_geometry.md
b0ca97460ecc1d7b6471735a373901dd8ba597e2bfc0ffcab701c7d30cd06612  /tmp/r356_geometry_checks.py
7515c0866cf8f4ccd2a193c9990c0210e3f18e8cec867ab547ddd934553bc53b  /tmp/r356_face_checks.py
97f9652726b61158878e07add10f9a15cc3291a4270a364aa6382b380ead0aa0  /tmp/r356_face_checks_result.json
84a742181801e0200ecdb5011a21649a463b81fe660fed6c9561b06c433515a6  /tmp/r356_face_checks.md
4a38d229f570ef1e3e3935dfd2d623b4e9cdcd46cffebb9d512a07ff51d442b8  /tmp/r356_numeric.py
4ac5f7a971da48ffd4f6894a43b4bde107056cfcb8ddedae2d39f7a6771cf5c7  /tmp/r356_numeric_result.json
82a1b61b1add481e2d110f0cb0133e8d8a8e2bea3a6d6c7ac814513dfe67ace7  /tmp/r356_numeric.md
f3dda7ae0b7509021476f4d3942b6c7fd8e2a85e24b1175afd40a748cdf5e36d  /tmp/r356_square.md
215a27b885e9163cf9417fb96166c0c97286717fead16f4f3ca7f8b416aaf52f  /tmp/r356_defect.md
42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64  /tmp/r355_geometry.md
1185347b4fd68f4d4a41da70f0862bf3709436ac3b6143592422f894c1550fd9  /tmp/r355_ledger.md
a81c51577e83b15046e3d39f2337ad265f7628f607fd6064ade945f1136316b1  /tmp/r355_audit.md
3ffe96d2acab960535e236abf7fcf2a0ee0d351d7755d49501a3175dd69cfdcc  /tmp/r352_core.md
27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b  /tmp/r351_core.md
333f0f45adfae3add7c81384a3bd061e641690ecbe3631cd43857cfb04e92601  /tmp/r351_core_checks.py
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
```
