#!/usr/bin/env python3
"""Exact single-face continuous capacity diagnostics and separate finite column accounting."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
from collections import Counter
import json
BASE=Path(__file__).resolve().parent;C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def logbounds(x,N=100):
 z=(x-1)/(x+1);lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return lo,lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
def cone(n,sigma):
 # Independent decompositions of {x_1 >= sigma max x} in [0,1]^n.
 # Slice at x_1=t: inner [0,sigma] integral plus upper slab.
 slicing=1-sigma+(sigma**n/(sigma**(n-1)*n) if sigma else F(0))
 # Partition according to the unique coordinate attaining the maximum (ties null).
 maxpartition=F(1,n)+(n-1)*(1-sigma)/n
 formula=1-sigma+sigma/n
 ck('unit_cube_slice_exact_monomial_integral',slicing==formula)
 ck('independent_max_coordinate_partition',maxpartition==formula)
 ck('cone_fraction_range',0<=formula<=1)
 if n==1:ck('n1_cone_is_entire_interval',formula==1)
 if sigma==0:ck('sigma_zero_whole_cube',formula==1)
 if sigma==1:ck('sigma_one_single_max_coordinate_sector',formula==F(1,n))
 return formula
def geometric(stage,n,sigma,ratio):
 before=sum(C.values());alpha=cone(n,sigma);strict_alpha=F(0) if sigma==1 else alpha;coef=n*(1-sigma)+sigma;ll,lh=logbounds(ratio);lower=(1-sigma)+coef*ll;upper=(1-sigma)+coef*lh
 ck('face_radial_coefficient_matches_cone',coef==n*alpha)
 ck('low_radius_actual_strip_volume',1-sigma==F(1)-sigma)
 ck('capacity_log_interval_outward',lower<=upper)
 finite=None
 if n<=64:
  rs=[F(1)+(ratio-1)*j/4 for j in range(5)];rs=sorted(set(rs));finite=1-sigma
  for a,b in zip(rs,rs[1:]):
   stripouter=(1-sigma)*b**n;stripinner=a**(n-1)*max(F(0),a-sigma*b);actualvolume=stripouter-stripinner
   ck('actual_radial_receiver_shell_strip_nonnegative',actualvolume>=0)
   finite+=actualvolume/b**n
  ck('actual_piecewise_receiver_dx_face_capacity',finite<=lower if ratio>1 else finite==lower)
 return dict(stage=stage,n=n,sigma=str(sigma),b_over_a=str(ratio),closed_cone_volume_fraction=str(alpha),strict_face_cone_fraction=str(strict_alpha),B1_interpretation='upper bound only at sigma=1; closed-cone/left-limit coefficient' if sigma==1 else 'analytic strict-face radial capacity',low_radius_capacity=str(1-sigma),log_coefficient=str(coef),B1_lower=str(lower),B1_upper=str(upper),finite_piecewise_receiver_capacity=str(finite) if finite is not None else None,exact_checks=sum(C.values())-before)
def finite_columns(stage,N):
 before=sum(C.values());B=F(1,2);theta=F(1,4);d=8*N;ns=N+2;weights=[1+F(z%3,2) for z in range(ns)]
 T=[[[F(0) for z in range(ns)] for i in range(d)] for j in range(N)];lj=[[F(0) for z in range(ns)] for j in range(N)];patterns=[]
 for z in range(ns):
  focus=(3*z)%d;kind=z%3;patterns.append(['one_face','overlapping_two_faces','coordinate_dispersed'][kind])
  for j in range(N):
   atoms=[(B,[focus])] if kind==0 else [(B/2,[focus,(focus+1)%d]),(B/2,[focus])] if kind==1 else [(B,[i]) for i in range(d)]
   for mass,faces in atoms:
    ck('terminal_atom_has_nonempty_face_cover',mass>0 and bool(faces) and len(set(faces))==len(faces))
    lj[j][z]+=mass
    for i in faces:T[j][i][z]+=mass
   ck('per_generation_each_coordinate_column_cap',all(T[j][i][z]<=B for i in range(d)))
   ck('per_generation_terminal_face_cover',max(T[j][i][z] for i in range(d))<=lj[j][z]<=sum(T[j][i][z] for i in range(d)))
 Li=[[sum(T[j][i][z] for j in range(N)) for z in range(ns)] for i in range(d)];L=[sum(lj[j][z] for j in range(N)) for z in range(ns)];paid=remaining=F(0);argmax=[]
 for z in range(ns):
  vals=[Li[i][z] for i in range(d)];mx=max(vals);argmax.append(vals.index(mx))
  ck('cumulative_fixed_coordinate_bound_NB1',all(0<=v<=N*B for v in vals))
  ck('full_terminal_mass_covered_by_coordinate_faces',mx<=L[z]<=sum(vals))
  good=mx>=theta*L[z]
  if good:
   ck('source_gate_full_L_paid_by_coordinate_max',L[z]<=mx/theta);paid+=weights[z]*L[z]
  else:remaining+=weights[z]*L[z]
 W=sum(weights);total=sum(f*l for f,l in zip(weights,L));ck('finite_paid_remainder_conserve',paid+remaining==total)
 ck('integrated_source_gate_payment',paid<=N*B*W/theta)
 ck('direction_dispersed_complement_can_exceed_NB1',any(L[z]>N*B and max(Li[i][z] for i in range(d))<theta*L[z] for z in range(ns)))
 ck('different_sources_select_different_coordinates',len(set(argmax))>1)
 return dict(stage=stage,N_generations=N,d_coordinates=d,B1=str(B),theta=str(theta),source_masses=list(map(str,weights)),terminal_atom_pattern_by_source=patterns,T_generation_coordinate_source=[[[str(v) for v in zs] for zs in row] for row in T],terminal_mass_per_generation_source=[[str(v) for v in row] for row in lj],Li_coordinate_source=[[str(v) for v in row] for row in Li],source_total_L=list(map(str,L)),chosen_coordinate_by_source=argmax,original_total=str(total),paid=str(paid),remaining=str(remaining),paid_fraction=str(paid/total),budget_NB1W_over_theta=str(N*B*W/theta),exact_checks=sum(C.values())-before,scope='Separate three-index finite terminal-face accounting, with each terminal mass atom explicitly assigned a nonempty coordinate-face set. Not native path geometry. B1=1/2 uses rational a=b, sigma=1/2. j is generation and i is coordinate; d=8N.')

def main():
 rows=[];stages=[]
 for stage,ns,sigmas in [('initial',[1,2,3],[F(1,4),F(1,2)]),('boundary_stress',[1,2,16,64],[F(0),F(1),F(1023,1024)]),('expanded',[256,1024,4096],[F(1,2),F(1)-F(1,4096)])]:
  before=sum(C.values())
  for n in ns:
   values=list(sigmas)
   if stage=='expanded':values.insert(1,F(isqrt(n)-1,isqrt(n)))
   for sigma in values:
    for ratio in [F(1),F(3,2),F(2)]:rows.append(geometric(stage,n,sigma,ratio))
  stages.append(dict(stage=stage,exact_checks=sum(C.values())-before))
 columns=[finite_columns(st,N) for st,N in [('initial',2),('boundary_stress',4),('expanded',8)]]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),geometry_stages=stages,geometry=rows,finite_column_accounting=columns,scope='Closed-cone and strict-face fractions are distinguished, especially sigma=1 where actual strict face is empty and B1 is only an upper bound. Continuous cone/strip volume integrals and physical radial receiver-shell capacities are separated from finite source-column algebra. No native paths, receiver marginal theorem, general operator bound or root payment is numerically certified.')
 (BASE/'r356_face_checks_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),geometry_stages=stages,columns=[dict(N=x['N_generations'],d=x['d_coordinates'],checks=x['exact_checks'],paid_fraction=x['paid_fraction']) for x in columns]),sort_keys=True))
if __name__=='__main__':main()
