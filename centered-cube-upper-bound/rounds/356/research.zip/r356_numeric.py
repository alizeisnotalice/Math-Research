#!/usr/bin/env python3
"""Exact matched-source overlap screening on finite cube-generated receiver labels."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
from itertools import product
import json
BASE=Path(__file__).resolve().parent;C=Counter();DELTAS=[F(1,16),F(1,8),F(1,4)]
def ck(k,v):
 C[k]+=1
 assert v,k
def makecase(stage,name,n,centres,masses,receivers,h=F(1,100)):
 # Receiver tuple (centre vector, side, finite quadrature weight).
 before=sum(C.values());inc=[];rows=[]
 for pos,R,weight in receivers:
  cc=[]
  ck('positive_physical_cube_and_quadrature_weight',R>0 and weight>=0)
  for z in centres:
   inside=all(abs(x-y)+h<=R/2 for x,y in zip(pos,z));outside=any(abs(x-y)-h>=R/2 for x,y in zip(pos,z))
   ck('actual_whole_positive_source_box_capture',inside or outside);cc.append(int(inside))
  m=sum(f*c for f,c in zip(masses,cc));ck('receiver_has_positive_full_source_mass',m>0)
  rows.append((R,weight,cc,m))
 rows.sort(key=lambda x:x[0]);radii=sorted(set(x[0] for x in rows));b=max(radii);prefixes=[]
 paid={str(d):F(0) for d in DELTAS};fullB=F(0);W=sum(masses);gates={str(d):0 for d in DELTAS};equal={str(d):0 for d in DELTAS};nonzero=0
 for k,r in enumerate(radii):
  ell=r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0)
  A=[[sum((wt*cc[y]*cc[z]/m for R,wt,cc,m in rows if R<=r),F(0)) for z in range(len(masses))] for y in range(len(masses))]
  costs={str(d):F(0) for d in DELTAS};base=F(0);details=[]
  for y,fy in enumerate(masses):
   J=A[y][y]
   if not J:
    ck('zero_J_has_zero_original_overlap',all(a==0 for a in A[y]));details.append({'source':y,'J':'0','L':'0','gate':{str(d):False for d in DELTAS}});continue
   M=sum(f*a for f,a in zip(masses,A[y]));S=sum(f for f,a in zip(masses,A[y]) if a>0);square=sum(f*a*a for f,a in zip(masses,A[y]));L=M-square/J
   ck('original_overlap_variance_nonnegative',0<=L<=M)
   ck('actual_prefix_overlap_bounded_by_J',all(0<=a<=J for a in A[y]))
   ck('matched_source_mass_cauchy',M*M<=S*square)
   nonzero+=L>0;base+=fy*L;gate={}
   for d in DELTAS:
    good=(1-d)*J*S<=M;gate[str(d)]=good
    if good:
     ck('source_mass_screen_pays_original_variance',L<=d*M);costs[str(d)]+=fy*L;gates[str(d)]+=1;equal[str(d)]+=((1-d)*J*S==M)
   details.append(dict(source=y,J=str(J),M=str(M),S=str(S),L=str(L),gate=gate))
  fullB+=ell*base
  for d in DELTAS:paid[str(d)]+=ell*costs[str(d)]
  prefixes.append(dict(radius=str(r),physical_ell_weight=str(ell),original_source_integrated_L=str(base),rows=details))
 for d in DELTAS:ck('paid_and_remainder_conserve_original_B',0<=paid[str(d)]<=fullB and paid[str(d)]+(fullB-paid[str(d)])==fullB)
 return dict(stage=stage,name=name,n=n,source_centres=[[str(x) for x in z] for z in centres],source_box_side=str(2*h),source_masses=list(map(str,masses)),source_W=str(W),receiver_quadrature=[dict(centre=list(map(str,pos)),R=str(R),weight=str(w)) for pos,R,w in receivers],prefixes=prefixes,original_B=str(fullB),nonzero_L_rows=nonzero,comparison={str(d):dict(paid=str(paid[str(d)]),remaining=str(fullB-paid[str(d)]),paid_fraction=str(paid[str(d)]/fullB) if fullB else None,gate_rows=gates[str(d)],equality_gate_rows=equal[str(d)]) for d in DELTAS},exact_checks=sum(C.values())-before,scope='True positive-volume uniform source boxes with exact whole-cube incidence; receiver weights are finite quadrature, not receiver dx. No original q-band/highpast/global gate or general budget certificate.')
def main():
 cases=[];zero=(F(0),);one=(F(1),)
 cases.append(makecase('initial','all_shared_zero_variance',1,[zero,one],[F(1),F(1)],[((F(1,2),),F(6,5),F(1))]))
 cases.append(makecase('initial','mixed_shared_private',1,[zero,one],[F(1),F(1)],[((F(0),),F(2,5),F(1)),((F(1,2),),F(6,5),F(2))]))
 for d in DELTAS:
  v=2*d/(1-2*d)
  cases.append(makecase('boundary_stress','exact_gate_delta_'+str(d),1,[zero,one],[F(1),F(1)],[((F(0),),F(2,5),v),((F(1,2),),F(6,5),F(2))]))
 cases.append(makecase('boundary_stress','concentrated_actual_mass',1,[zero,one,(F(2),)],[F(100),F(1),F(1,100)],[((F(0),),F(2,5),F(1)),((F(1,2),),F(6,5),F(2)),((F(3,2),),F(6,5),F(1))]))
 for n in [2,4,8]:
  centres=[tuple(map(F,z)) for z in product([0,1],repeat=2)]
  centres=[z+(F(0),)*(n-2) for z in centres]
  receivers=[]
  for z in centres:receivers.append((z,F(2,5),F(1,4)))
  for y in [F(0),F(1)]:receivers.append(((F(1,2),y)+(F(0),)*(n-2),F(6,5),F(1,2)))
  receivers.append(((F(1,2),F(1,2))+(F(0),)*(n-2),F(3,2),F(1)))
  masses=[F(1),F(1),F(1),F(1)] if n==2 else [F(1,10),F(1),F(3),F(10)]
  cases.append(makecase('expanded','square_cubes_n'+str(n),n,centres,masses,receivers))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=cases,scope='Exact finite matched-source budget screen; actual compact positive L1 source geometry with finite receiver quadrature, never claimed true receiver dx/global gate. n4/8 examples embed a 2D square in higher-dimensional positive source/cube boxes; not an independent growing-dimensional stress family.')
 (BASE/'r356_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[dict(name=m['name'],checks=m['exact_checks'],B=m['original_B'],paid={d:x['paid_fraction'] for d,x in m['comparison'].items()}) for m in cases]),sort_keys=True))
if __name__=='__main__':main()
