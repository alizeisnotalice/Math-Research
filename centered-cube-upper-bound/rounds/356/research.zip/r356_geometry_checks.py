from fractions import Fraction as F
from random import Random
import math
cone_checks=0
for n in range(1,61):
 for den in range(2,18):
  for k in range(1,den):
   sigma=F(k,den)
   integral=sigma**n/(n*sigma**(n-1)) + 1-sigma
   assert integral==1-sigma+sigma/n
   assert n*integral==n*(1-sigma)+sigma
   if n==1: assert integral==1
   cone_checks+=1
# sigma=1 is separate: a strict selected-face coordinate cannot exceed the max.
assert all(not (F(k,10)>max(F(k,10),F(3,10))) for k in range(11))
rng=Random(356); split_checks=0
for n in range(1,9):
 for trial in range(100):
  weights=[F(rng.randrange(1,10),10) for _ in range(12)]
  faces=[]
  for _ in weights:
   subset={i for i in range(n) if rng.randrange(2)}
   if not subset: subset={rng.randrange(n)}
   faces.append(subset)
  total=sum(weights)
  loads=[sum(w for w,S in zip(weights,faces) if i in S) for i in range(n)]
  assert max(loads)<=total and sum(loads)>=total
  for threshold in [F(1,2),F(1,4),F(1,8)]:
   paid=max(loads)>=threshold*total
   if paid: assert total<=max(loads)/threshold
   else: assert all(v<threshold*total for v in loads)
   split_checks+=1
a,b=1.0,2.0
M=2000; lo=a/2; hi=b/2; step=(hi-lo)/M
quad=step/3*sum((1 if j in (0,M) else 4 if j%2 else 2)/(lo+j*step)
               for j in range(M+1))
err=max(abs((1-s)+quad-((1-s)+math.log(b/a))) for s in [.2,.5,.9])
assert err<1e-11
print('PASS',cone_checks,'exact cone integrations;',split_checks,
      'exact overlapping-face source splits;',
      '1D actual-center quadrature max error',err)
