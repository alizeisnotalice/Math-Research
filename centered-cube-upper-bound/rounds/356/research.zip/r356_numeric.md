R356 matched-source mass screen: finite exact exploration

Frozen fresh standard-library Python processes returned PASS 474 exact Fraction assertions: initial 47, equality/concentration stress 128, expanded 299. Nine actual source-box/cube-generated finite receiver configurations were tested at delta=1/16,1/8,1/4. Reproduce with:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r356_numeric.py
```

The script is self-contained and writes r356_numeric_result.json beside itself. The result preserves source centres, actual positive source masses, source-box side, physical receiver cubes, finite quadrature weights, each radius prefix, physical ell weights including the terminal atom, row J/M/S/L, gate decisions, original B, screened share, and remaining share.

Definitions and exact certificate. For each full positive-volume source box, f is uniform with its stated rational mass. Every receiver cube is checked to capture an entire source box or miss it entirely; partial intersection is not approximated. Source probabilities and receiver full masses use these actual f masses. Receiver weights are finite quadrature weights, NOT receiver dx. For each physical-radius prefix the code computes

A_yz=sum_u weight_u c_uy c_uz/m_u, J_y=A_yy,
M_y=sum_z f_z A_yz, S_y=sum_{A_yz>0} f_z,
L_y=M_y-sum_z f_z A_yz^2/J_y.

Zero J rows are handled separately. Cauchy gives M^2<=S sum f A^2; hence the true-source-mass screen (1-delta)JS<=M implies L<=M-M^2/(JS)<=delta M. All of these finite quantities and inequalities are computed rationally. S is reachable source MASS, not boundary volume or a source density cap.

Actual paid part. For each delta, the reported screened amount is the original integral sum_prefix ell sum_y f_y L_y restricted to good rows. The remainder is the original B minus that amount, with exact conservation. This is not a claim that the entire input improves.

| Fixture | Original B | Paid fraction, delta=1/16 | delta=1/8 | delta=1/4 |
|---|---:|---:|---:|---:|
| Mixed shared/private two-source | 5/12 | 0 | 0 | 1 |
| Concentrated masses 100,1,1/100 | 20202505/9302706 | 0.25496838 | 0.25496838 | 0.25496838 |
| Equal-mass square, n=2 | 73/72 | 0 | 0 | 9/73 = 0.12328767 |
| Unequal-mass square embedded in n=4 | exact rational in result | 0.05003284 | 0.30414631 | 0.30414631 |
| Same square embedded in n=8 | exact rational in result | 0.12145630 | 0.30070527 | 0.30070527 |

Thus the screen can be empty for a positive original B, can pay a controlled minority, or can pay the whole B in a specially matched configuration. The concentration stress still leaves about 74.5% unpaid. At delta=1/4 the equal square leaves about 87.7% unpaid. These leftovers remain explicit; they are not renamed as paid traffic.

Equality stress. The two source boxes at 0 and 1 have mass 1. A shared receiver has weight 2 and mass 2, contributing A_yz=1; a private receiver captures source 0 with weight v=2delta/(1-2delta). At the final prefix, source 0 has (1-delta)JS=M exactly, with nonzero L. A separate fixture is built for each tested delta, and its inclusive screen is verified. The fully shared configuration has B=0 and its fraction is null rather than an artificial success percentage. Early prefixes include genuine zero-J rows. All physical layer weights are r_i^-n-r_(i+1)^-n, with final r_last^-n; compression does not introduce interior clock atoms.

Scope and decision. These are compact positive-L1 sources with actual cube incidences but finite receiver quadrature. The source masses, cubes and original normalized m are frozen. The receivers are not claimed to satisfy a true-dx realization, original q band, high-past, full historical qualification, or the general global gate. Some diagnostic radius menus exceed an octave; no original octave theorem is inferred. The n=4 and n=8 square fixtures embed a 2D source-centre pattern in higher-dimensional positive boxes; their changing ell weights do not establish a dimension trend. No asymptotic exponent is fitted. The useful finite conclusion is that matching the reachable SOURCE mass can pay real nonzero variance while leaving substantial and accurately reported residual cost.
