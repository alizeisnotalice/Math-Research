"""R848: exact cubical star tests with true source and receiver masses."""

from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations
from math import prod
import sys


N = 16
EPS = F(1, 2**20)
CORE = EPS / 64
PACKET = EPS / 16
BACKGROUND = F(5, 4)
PEAK_MASS = F(1, 8)


def point(x, y, z=F(0)):
    return (F(x), F(y), F(z)) + (F(0),) * (N-3)


def box(center, radius):
    return tuple((v-radius, v+radius) for v in center)


def intersection(boxes):
    return tuple((max(lo for lo, _ in axis), min(hi for _, hi in axis))
                 for axis in zip(*boxes))


def volume(B):
    return prod(max(F(0), hi-lo) for lo, hi in B)


def subset(A, B):
    return all(lo2 <= lo1 <= hi1 <= hi2 for (lo1, hi1), (lo2, hi2) in zip(A, B))


def shown(value, rounding=None):
    with localcontext() as ctx:
        ctx.prec = 8
        if rounding is not None:
            ctx.rounding = rounding
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def interval(lo, hi):
    return f"[{shown(lo, ROUND_FLOOR)}, {shown(hi, ROUND_CEILING)}]"


CENTERS = (point(0, 1), point(-F(3, 4)+EPS, -F(3, 4)+EPS),
           point(F(5, 8)-EPS, -F(5, 8)+EPS), point(0, 0))
SIDES = (F(2), F(3, 2), F(5, 4), F(1))
VOLUMES = tuple(l**N for l in SIDES)
CORE_VOLUMES = ((2*CORE)**N,) * len(SIDES)
INNER = tuple(box(c, l/2-CORE) for c, l in zip(CENTERS, SIDES))
OUTER = tuple(box(c, l/2+CORE) for c, l in zip(CENTERS, SIDES))
SMALL_CELL = box(point(0, EPS/2), PACKET)
PAIRS = tuple(combinations(range(3), 2))


def certify_receivers():
    for p, q in combinations(CENTERS, 2):
        assert volume(intersection((box(p, CORE), box(q, CORE)))) == 0
    for c in CENTERS:
        assert subset(box(c, 1+CORE), box(point(0, 0), F(4)))
    assert 1 < BACKGROUND < BACKGROUND + 3*PEAK_MASS < 2
    # Every cube with center in a tested core and side in [1,2] is inside
    # the background. Its density is between 5/4 and 5/4+(3/8)/1^N.
    # True volume-bin exponents, in strictly decreasing order.
    exponents = (16, 10, 6, 0)
    assert all(F(2)**(k-1) < v <= F(2)**k for k, v in zip(exponents, VOLUMES))
    assert all(exponents[0]-k > 4 for k in exponents[1:])
    assert subset(SMALL_CELL, intersection(INNER))
    print("n=16, disjoint real receiver cores; all [1,2] averages on cores lie in [5/4,13/8].")
    print("  sides 2,3/2,5/4,1; real volume bins k=16,10,6,0; each core volume", shown(CORE_VOLUMES[0]))
    print("  eta=full supported background plus the indicated actual packets (lambda=1).")


def packet_masks(packets, expected):
    actual = []
    for P in packets:
        mask = set()
        for i in range(len(SIDES)):
            if subset(P, INNER[i]):
                mask.add(i)
            else:
                assert volume(intersection((P, OUTER[i]))) == 0
        actual.append(frozenset(mask))
    assert actual == list(map(frozenset, expected))
    assert all(volume(intersection(pair)) == 0 for pair in combinations(packets, 2))
    return actual


def star_data(indices, masks):
    selected = frozenset(indices)
    i_lo = volume(intersection(INNER[i] for i in indices))
    i_hi = volume(intersection(OUTER[i] for i in indices))
    packets_in_intersection = sum(PEAK_MASS for mask in masks if selected <= mask)
    assert 0 < i_lo <= i_hi
    true_lo = BACKGROUND*i_lo + packets_in_intersection
    true_hi = BACKGROUND*i_hi + packets_in_intersection
    q_lo = BACKGROUND + packets_in_intersection/i_hi
    q_hi = BACKGROUND + packets_in_intersection/i_lo
    return i_lo, i_hi, true_lo, true_hi, q_lo, q_hi


def weights(masks, cut):
    source = tuple(BACKGROUND*v+sum(PEAK_MASS for mask in masks if i in mask)
                   for i, v in enumerate(VOLUMES))
    if cut:
        # Actual opposite endpoint retained in outer quarter of the last
        # coordinate interval. Its shelf is [x_N+r/2,x_N+r] so no central packet enters.
        assert CORE + PACKET < min(SIDES)/4
        partner = tuple(BACKGROUND*v/4 for v in VOLUMES)
    else:
        partner = source
    discount = tuple(m/s for m, s in zip(partner, source))
    coeff = tuple(c*m/v**2 for c, m, v in zip(CORE_VOLUMES, partner, VOLUMES))
    raw_one = tuple(c*s*m/v**2 for c, s, m, v in zip(CORE_VOLUMES, source, partner, VOLUMES))
    assert all(weights_i == r/s for weights_i, r, s in zip(coeff, raw_one, source))
    return source, partner, discount, coeff, raw_one


def separate_pairs():
    packets = (box(point(-F(3, 4), EPS/2), PACKET),
               box(point(F(3, 4), EPS/2), PACKET),
               box(point(0, -F(3, 4)), PACKET))
    masks = packet_masks(packets, PAIRS)
    assert all(volume(intersection((SMALL_CELL, P))) == 0 for P in packets)
    source, partner, discount, coeff, raw_one = weights(masks, cut=True)
    print("Disjoint pair-only peak packets: mass 1/8 each; actual Q, shelf-discounted Q, and original W.")
    for ids in (*PAIRS, (0, 1, 2), (0, 1, 2, 3)):
        i_lo, i_hi, e_lo, e_hi, q_lo, q_hi = star_data(ids, masks)
        drop = prod(discount[i] for i in ids)
        scale = prod(coeff[i] for i in ids)
        if len(ids) == 2:
            assert q_lo > 100 and q_lo*drop > 16
        else:
            assert q_lo == q_hi == BACKGROUND and q_hi*drop < F(1, 50)
        nominal_i = volume(intersection(box(CENTERS[i], SIDES[i]/2) for i in ids))
        nominal_e = BACKGROUND*nominal_i + sum(PEAK_MASS for mask in masks if set(ids) <= mask)
        v = prod(VOLUMES[i] for i in ids)
        q = nominal_e/nominal_i*drop
        assert q*(prod(source[i] for i in ids)/v)*(nominal_i/v) == (
            nominal_e*prod(partner[i]/VOLUMES[i]**2 for i in ids))
        print(" ", ids, "Q", interval(q_lo,q_hi), "cut", interval(drop*q_lo,drop*q_hi),
              "; W", interval(scale*e_lo,scale*e_hi),
              "; overlap/support", interval(i_lo/min(VOLUMES[i] for i in ids),
                                           i_hi/min(VOLUMES[i] for i in ids)))
    common_cell_mass = BACKGROUND*volume(SMALL_CELL)
    true_pair = star_data((0, 1), masks)[2]
    true_triple = star_data((0, 1, 2), masks)[3]
    assert true_triple/true_pair < F(1, 10**8)
    print("  conditional pair-source retention into the third witness <", shown(F(1,10**8)))
    cut_three = common_cell_mass*prod(coeff[:3])
    assert 0 < cut_three < star_data((0, 1, 2), masks)[2]*prod(coeff[:3])
    print("  common small cell volume", shown(volume(SMALL_CELL)),
          "; true source mass", shown(common_cell_mass),
          "; its original 3-slot W", shown(cut_three))
    print("  original one-slot masses after the real opposite-endpoint cut",
          tuple(map(shown, raw_one)))


def shared_peak():
    masks = packet_masks((SMALL_CELL,), (range(4),))
    _, _, discount, coeff, raw_one = weights(masks, cut=True)
    count = 4
    tiny = CORE/(4*count)
    ratio = (tiny/CORE)**N
    old_cores = []
    for c in CENTERS[1:]:
        for j in range(count):
            ctr = list(c)
            ctr[2] += CORE*F(2*j-count+1, 2*count)
            core = box(ctr, tiny)
            assert subset(core, box(c, CORE))
            old_cores.append(core)
    assert len(old_cores) == 12
    assert all(volume(intersection(pair)) == 0 for pair in combinations(old_cores,2))
    aggregate = (coeff[0],) + tuple(count*ratio*c for c in coeff[1:])
    cell_mass = BACKGROUND*volume(SMALL_CELL) + PEAK_MASS
    print("Same real positive-width spike in current witness and 12 disjoint old cores across three old bins.")
    print("  relative core volume per old sibling", shown(ratio), "; cell mass", shown(cell_mass),
          "; current original one-slot mass", shown(raw_one[0]))
    for ids in ((0, 1), (0, 1, 2), (0, 1, 2, 3)):
        i_lo, i_hi, e_lo, e_hi, q_lo, q_hi = star_data(ids, masks)
        drop = prod(discount[i] for i in ids)
        scale = prod(aggregate[i] for i in ids)
        assert q_lo*drop > 16 and e_lo >= cell_mass
        assert cell_mass/e_hi <= 1
        print(" ", ids, "cut Q", interval(drop*q_lo,drop*q_hi), "actual W incl. all sibling tuples",
              interval(scale*e_lo,scale*e_hi), "; small-cell W", shown(cell_mass*scale),
              "; volume fraction", interval(volume(SMALL_CELL)/i_hi, volume(SMALL_CELL)/i_lo),
              "; real mass fraction", interval(cell_mass/e_hi, cell_mass/e_lo))
    print("  common cell old receiver load per unit source:", shown(sum(aggregate[1:])),
          "; covered counts by successive slots 4,16,64.")


def polynomial_kernel(sides, moment):
    coeff = [F(1)]
    for l in sides:
        coeff = [coeff[0]] + [coeff[j]-coeff[j-1]/l for j in range(1,len(coeff))] + [-coeff[-1]/l]
    return sum(c*moment(k) for k, c in enumerate(coeff))


def reference_stages(half, source_density, label):
    def triangular(k):
        return ((2*half)**(k+2) - 2*half**(k+2))/((k+1)*(k+2)*half**2)

    def uniform(k, left, right):
        return (right**(k+1)-left**(k+1))/((k+1)*(right-left))

    # w in one true lower orthant cell, w' in the upper orthant cell; both
    # have side half. References independent given that very same w.
    # In each coordinate, D=w'-w has the exact triangular moments above.
    # Given w, fresh w'_j yield distance mean half/2-w after recentering.
    # To contain the entire candidate cell use its far endpoint half-w.
    assert 0 < 2*half < min(SIDES[1:])
    assert triangular(0) == 1 and triangular(1) == half
    candidate_mass = source_density*half**N
    print(label, "candidate cell mass", shown(candidate_mass))
    for m in (1, 2, 3):
        sizes = SIDES[1:m+1]
        same = polynomial_kernel(sizes, triangular)**N
        fresh = polynomial_kernel(sizes, lambda k: uniform(k,half/2,3*half/2))**N
        inner = polynomial_kernel(sizes, lambda k: uniform(k,half,2*half))**N
        assert 0 < inner < fresh <= same < 1
        assert (fresh == same) == (m==1)
        real_cell_integral = candidate_mass*same
        leb_cell_integral = half**N * same
        assert real_cell_integral == source_density*leb_cell_integral
        print("  old slots",m,"same-point/fresh-point/whole-cell probabilities",
              tuple(map(shown,(same,fresh,inner))), "; reuse gap", shown(same-fresh),
              "; true cell integral", shown(real_cell_integral))


if __name__ == "__main__":
    print(sys.version.split()[0])
    certify_receivers()
    separate_pairs()
    shared_peak()
    peak_density = BACKGROUND + PEAK_MASS/(2*PACKET)**N
    reference_stages(PACKET, peak_density, "Actual shared spike, three successive uniform-reference tests:")
    reference_stages(F(1,8), F(3,2), "Pure density-3/2 background, same uniform-reference tests:")
    print("All assertions passed in exact rational arithmetic. Interval endpoints round outwards.")
