"""Exact two-endpoint alternating rank transport and reversed terminal accounting."""
from collections import defaultdict, namedtuple
from fractions import Fraction as F
from math import prod
import sys

Row = namedtuple("Row", "bin left right mass")


def band(upper, lower, h):
    def area(q):
        a, b = upper
        c, d = lower
        return (max(0, d + q - a) ** 2 - max(0, c + q - a) ** 2
                - max(0, d + q - b) ** 2 + max(0, c + q - b) ** 2) / F(2)

    return (area(2 * h) - area(h)) / h


def build(rows, masses, h, gate):
    all_states = 2 * len(rows)
    measure = [row.mass / 2 for row in rows for _ in (0, 1)]
    forward = [{} for _ in measure]
    reverse = [{} for _ in measure]
    groups = defaultdict(lambda: defaultdict(list))
    for r, row in enumerate(rows):
        groups[0, row.left][row.bin].append(r)
        groups[1, row.right][row.bin].append(r)
    stats = defaultdict(F)
    ranges = defaultdict(list)
    rank_data = {}
    for (phase, anchor), by_bin in groups.items():
        lengths = {i: sum(rows[r].mass for r in row_ids) / masses[anchor]
                   for i, row_ids in by_bin.items()}
        rank_data[phase, anchor] = intervals = {}
        start = F(0)
        for i, length in sorted(lengths.items()):
            assert 0 < length <= 4
            intervals[i] = start, start + length
            start += length
        pairs = {(i, j): band(u, v, h) for i, u in intervals.items()
                 for j, v in intervals.items() if j < i}
        for i, length in lengths.items():
            assert sum(value for (k, _), value in pairs.items() if k == i) <= length
            assert sum(value for (_, k), value in pairs.items() if k == i) <= length
            assert band(intervals[i], intervals[i], h) == 0
        for (i, j), overlap in pairs.items():
            if not overlap:
                continue
            for r in by_bin[i]:
                for s in by_bin[j]:
                    e, f = 2 * r + phase, 2 * s + 1 - phase
                    weight, key, limits = gate(rows[r], rows[s], phase)
                    assert 0 <= weight <= 1
                    raw = overlap / lengths[i] * rows[s].mass / (lengths[j] * masses[anchor])
                    stats["proposal"] += measure[e] * raw
                    stats[key] += measure[e] * raw * (1 - weight)
                    if weight:
                        p = raw * weight
                        forward[e][f] = p
                        reverse[f][e] = (overlap / lengths[j] * rows[r].mass
                                         / (lengths[i] * masses[anchor]) * weight)
                        assert measure[e] * p == measure[f] * reverse[f][e]
                        stats["accepted"] += measure[e] * p
                        ranges["accepted"].append(limits)
                    if weight < 1:
                        ranges[key].append(limits)
    assert all(p < all_states for row in (*forward, *reverse) for p in row)
    assert stats["proposal"] == stats["accepted"] + sum(
        v for k, v in stats.items() if k not in ("proposal", "accepted"))
    return measure, forward, reverse, stats, ranges, rank_data


def evolve(vector, matrix):
    out = [F(0)] * len(vector)
    for e, value in enumerate(vector):
        if value:
            for f, p in matrix[e].items():
                out[f] += value * p
    return out


def terminal(name, measure, p, adjoint, stats, ranges, short):
    capacity = [sum(row.values(), F(0)) for row in p]
    c = [sum(row.values(), F(0)) for row in adjoint]
    assert all(0 <= value <= 1 for value in capacity + c)
    stop = [f * (1 - q) for f, q in zip(measure, capacity)]
    assert [a - b for a, b in zip(measure, evolve(measure, adjoint))] == stop
    total, total_stop = sum(measure), sum(stop)
    a, b, recovered = measure, stop, [F(0)] * len(measure)
    history, low, brief, union = [], F(0), F(0), F(0)
    probability = {(e, F(1)): mass for e, mass in enumerate(stop) if mass}
    j = 0
    while any(b):
        value = sum(b)
        assert value == sum(f * (1 - r) for f, r in zip(a, capacity))
        check = [F(0)] * len(measure)
        step = defaultdict(F)
        for (e, factor), mass in probability.items():
            check[e] += mass * factor
            is_low = factor <= F(1, (j + 1) ** 2)
            if is_low:
                low += mass * factor
            if j <= short:
                brief += mass * factor
            if is_low or j <= short:
                union += mass * factor
            if c[e]:
                for f, edge in adjoint[e].items():
                    step[f, factor * c[e]] += mass * edge / c[e]
        assert check == b
        assert sum(probability.values()) <= total_stop
        history.append(value)
        recovered = [u + v for u, v in zip(recovered, b)]
        a, b = evolve(a, p), evolve(b, adjoint)
        probability = step
        j += 1
    h2 = sum(F(1, (depth + 1) ** 2) for depth in range(j))
    assert recovered == measure and sum(history) == total
    assert low <= total_stop * h2 and brief <= total_stop * (short + 1)
    assert union <= total_stop * (short + 1 + h2)
    print(name, "mass", decimal(total), "D/F", decimal(total_stop / total),
          "max P1,P*1", max(capacity), max(c))
    print("  path mass/F by depth:", " ".join(decimal(x / total) for x in history))
    print("  proposal/F, accepted/F:", decimal(stats["proposal"] / total),
          decimal(stats["accepted"] / total))
    for key in sorted(ranges):
        lo, hi = zip(*ranges[key])
        rejection = stats[key] / total if key != "accepted" else F(0)
        print(f"  gate {key}: K in [{min(lo)},{max(hi)}]; rejected/F={decimal(rejection)}")
    print("  below weight cutoff, short, union /F:", *(decimal(v / total)
          for v in (low, brief, union)), "terminal states exact")


def decimal(q):
    return f"{float(q):.8g}"


def geometry():
    n, density = 4, F(3, 2)
    centers = dict(zip("ABCD", map(F, ("-3/16", "-1/16", "1/16", "3/16"))))
    source_width = F(1, 32)
    source_mass = density * source_width * F(1, 4) ** (n - 1)
    receiver_volume = F(1, 32) * F(1, 8) ** (n - 1)
    sides = list(map(F, ("1", "9/8", "5/4", "3/2", "2")))
    receiver_centers = [F(i - 2, 16) for i in range(5)]
    for i, side in enumerate(sides):
        v = side ** n
        assert (i == 0 and v == 1) or (i >= 1 and 2 ** (i - 1) < v <= 2 ** i)
        assert max(abs(z - receiver_centers[i]) for z in centers.values()) + source_width < side / 2
    assert all(b - a > F(1, 32) for a, b in zip(receiver_centers, receiver_centers[1:]))
    template = ((0, "A", "B", 1), (0, "A", "D", F(1, 2)), (1, "D", "B", 1),
                (2, "D", "C", 1), (3, "A", "C", 1), (3, "A", "B", F(1, 2)),
                (4, "A", "B", 1))
    raw = [receiver_volume * source_mass ** 2 / sides[i] ** (2 * n)
           for i, _, _, _ in template]
    unit = F(3, 4) * min(cap / weight for cap, (_, _, _, weight) in zip(raw, template))
    rows = [Row(i, a, z, unit * weight) for i, a, z, weight in template]
    assert all(0 < row.mass <= cap for row, cap in zip(rows, raw))
    h = F(3, 2) * unit / source_mass

    def gate(r, s, phase):
        old, new = (r.right, s.right) if phase == 0 else (r.left, s.left)
        distance = abs(centers[old] - centers[new])
        limits = max(F(0), distance - source_width), distance + source_width
        if old == new:
            assert limits[1] < F(1, 16)
            return F(0), "near-partner", limits
        assert limits[0] > F(1, 16)
        weight = F(3, 4) if centers[new] < centers[old] else F(1)
        return weight, "directed-thinning", limits

    data = build(rows, {key: source_mass for key in centers}, h, gate)
    print("TRUE BOXES n=4, sigma=3/2 on [-4,4]^n, lambda=1; five actual bins 0..4.")
    print("  H=", h, "(small for replay; theoretical H about sqrt(n) not tested)",
          "row fractions min/max", min(r.mass / cap for r, cap in zip(rows, raw)),
          max(r.mass / cap for r, cap in zip(rows, raw)))
    original_spine = (6, 4, 3, 2, 0)
    spine = [2 * row + phase % 2 for phase, row in enumerate(original_spine)]
    exact_spine = data[0][spine[0]] * prod(data[1][e][f] for e, f in zip(spine, spine[1:]))
    assert exact_spine > 0
    print("  one physical four-step path mass", exact_spine)
    terminal("box transport", *data[:5], short=1)
    intervals = data[-1][0, "A"]
    shared_rank(intervals[4], intervals[3], intervals[0], h, "actual A at bin 4", F(2, 9))


def shared_rank(current, old1, old2, h, label, gate_product=None):
    a, b = current

    def portion(u, target):
        return max(F(0), min(u - h, target[1]) - max(u - 2 * h, target[0])) / h

    knots = {a, b}
    for v in old1 + old2:
        for q in (h, 2 * h):
            if a < v + q < b:
                knots.add(v + q)
    knots = sorted(knots)
    f = lambda u: portion(u, old1) * portion(u, old2)
    shared = sum((hi - lo) * (f(lo) + 4 * f((lo + hi) / 2) + f(hi)) / 6
                 for lo, hi in zip(knots, knots[1:])) / (b - a)
    independent = band(current, old1, h) * band(current, old2, h) / (b - a) ** 2
    assert 0 <= shared <= 1 and shared != independent
    print("  shared vs independently redrawn starting rank (raw)", label, shared, independent)
    if gate_product is not None:
        # Given the fresh rank is in its old bin, the actual side-partner
        # mixture accepts 2/3 in bin 3 and 1/3 in bin 0.
        accepted = shared * gate_product, independent * gate_product
        assert accepted == (F(10, 243), F(4, 81))
        print("  same comparison after actual partner gates:", *accepted)


def synthetic():
    print("FINITE STRESS / abstract balanced rows, no box realization claimed.")
    h = F(5, 4)

    def all_edges(r, s, phase):
        gap = F(r.bin - s.bin)
        return F(1), "unused", (gap, gap)

    def near_gate(r, s, phase):
        gap = F(r.bin - s.bin)
        return (F(1, 2) if gap == 1 else F(1)), "near-time", (gap, gap)

    m = 4
    sources = {k: F(1) for k in range(m)}
    for height, gate in ((10, all_edges), (22, near_gate)):
        rows = [Row(i, k, (k + i) % m, F(1))
                for i in range(height) for k in range(m)]
        for i in range(height):
            assert {r.left for r in rows if r.bin == i} == set(sources)
            assert {r.right for r in rows if r.bin == i} == set(sources)
            assert all(r.mass == F(1) for r in rows if r.bin == i)
        data = build(rows, sources, h, gate)
        assert all(stop - start == 1 for intervals in data[-1].values()
                   for start, stop in intervals.values())
        terminal(f"balanced height={height} H={h}", *data[:5], short=3)
    shared_rank((F(2), F(3)), (F(1), F(2)), (F(0), F(1)), F(1), "adjacent old bins")
    shared_rank((F(2), F(3)), (F(1), F(2)), (F(1), F(2)), F(1), "same old bin twice")


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; decimal displays rounded.")
    geometry()
    synthetic()
