"""Actual shared source with different full scale histories on the very same observed star."""
from decimal import Decimal, localcontext
from fractions import Fraction as F
from math import comb, factorial
import sys

import flint
from flint import arb, ctx


def overlap(interval, window):
    return max(F(0), min(interval[1], window[1]) - max(interval[0], window[0]))


def rank_factor(current, old, offsets, H):
    """Integrate the two independent old-bin overlap fractions over ONE current rank."""
    lo, hi = current
    knots = {lo,hi}
    for (v0,v1),(a,b) in zip(old, offsets):
        knots.update(p for p in (v0+a,v0+b,v1+a,v1+b,2*H) if lo < p < hi)
    def term(u):
        if u < 2*H:
            return F(0)
        prod = F(1)
        for (v0,v1),(a,b) in zip(old, offsets):
            prod *= overlap((v0,v1),(u-b,u-a))/(v1-v0)
        return prod
    cuts = sorted(knots)
    value = sum((b-a)*(term(a)+4*term((a+b)/2)+term(b))/6 for a,b in zip(cuts,cuts[1:])
                if a >= 2*H)
    compatible = lo >= 2*H and all(hi-b <= v0 and v1 <= lo-a
                                     for (v0,v1),(a,b) in zip(old,offsets))
    return value/(hi-lo), compatible


def decimal_string(q):
    with localcontext() as dc:
        dc.prec = 18
        return f"{Decimal(q.numerator)/Decimal(q.denominator):.8E}"


def real_full_history():
    n, last = 128, 56
    side = [F(129,128)**j for j in range(last+1)]
    vol = [s**n for s in side]
    assert side[0] == 1 and side[-1] <= 2 and all(b > 2*a for a,b in zip(vol,vol[1:]))
    # Adjacent index labels designate distinct true ceil(log2 v) bins. All other bins have zero F.
    denom = 32*sum(v*v for v in vol)
    widths = [v*v/denom for v in vol]
    cross_area = F(1,4)**(n-1)
    assert sum(widths) == F(1,32)
    # Receiver cores are consecutive half-open first-axis intervals in [0,1/32],
    # with transverse [-1/8,1/8]^(n-1). Each physical witness contains all 4 packets.
    centers = [F(-1,4),F(-1,8),F(1,8),F(1,4)]
    packet_side = F(1,64)
    assert max(abs(q)+F(1,32)+packet_side/2 for q in centers)<F(1,2)
    assert F(1,8)+packet_side/2<F(1,2)
    masses = [(2**20-1)*F(1,2**24),F(1,2**24),F(8,2**24),F(1,64)]
    # sigma=(5/4) 1_[-4,4]^n dx plus nonnegative excess on 4 disjoint packets to give these masses.
    additions = [m-F(5,4)*packet_side**n for m in masses]
    assert min(additions)>0 and sum(additions)<F(1,4)
    assert F(5,4)+sum(additions)<2
    unit_load = masses[-1]*cross_area/denom
    assert all(masses[-1]*width*cross_area/v**2 == unit_load for width,v in zip(widths,vol))
    # g_j(w,z) is a fixed weight in [0,1] below, with z in the fourth actual packet.
    def weights(role):
        out = [F(1) for _ in side]
        if role == 0:
            for j in range(30,last):
                if j not in (30,38):
                    out[j] = F(1,4)
        if role == 2:
            out[39:42] = [F(1,4)]*3
        return out
    H, d = F(16), F(4)  # units of the true one-bin load; small illustrative prices
    offsets = ((H,H+d),(H+2*d,H+3*d))
    factors = []
    for i in range(3):
        t = weights(i)
        cut = [F(0)]
        for q in t:
            cut.append(cut[-1]+q)
        intervals = [(cut[j],cut[j+1]) for j in (56,38,30)]
        a, all_ = rank_factor(intervals[0],intervals[1:],offsets,H)
        assert all(t[j] == 1 for j in (56,38,30))
        factors.append((a,all_))
        print("packet", "ABC"[i], "true-scale mass ranks/unit", *intervals, "normalized rank factor",a,"whole bins",all_)
    assert factors == [(0,False),(1,True),(F(9,64),False)]
    raw, scheduled, whole = sum(masses[:3]), sum(m*a for m,(a,_) in zip(masses,factors)), masses[1]
    assert raw/whole == 2**20+8 and scheduled/whole == F(17,8)
    print("same observed receiver and private-partner tuple, unfiltered/complete",raw/whole,
          "untrimmed/complete",scheduled/whole,"conditional B untrimmed",whole/scheduled)
    # Packet B has uniform density. Partition it into two Borel cells at 1/4 of its width.
    # Under a whole-compatible star the conditional shared source is uniform in B.
    posterior = (F(1,4), F(3,4))
    independent = [[x*y for y in posterior] for x in posterior]
    assert tuple(map(sum,independent)) == posterior
    assert tuple(sum(row[j] for row in independent) for j in range(2)) == posterior
    print("same complete star, resampled source cells, off-diagonal probability",
          independent[0][1]+independent[1][0],"old output marginals",*posterior)
    # A sample at actual center of each core has positive I; all ratios above hold throughout all cores.
    print("disjoint receivers",len(side),"dimension",n,"unit true load",decimal_string(unit_load))


def multinomial_order():
    a = [F(1,8), F(3,8), F(1,4), F(1,4)]
    coeff = [F(1)]+[F(0)]*4
    for x in a:
        for j in range(4,0,-1):
            coeff[j]+=x*coeff[j-1]
    for m in (2,3,4):
        assert coeff[m]*factorial(m)<=sum(a)**m
        print("strictly ordered moment coefficient",m,coeff[m],"versus power/factorial",sum(a)**m/factorial(m))


def geometric_cost():
    # Conditional outside-cube reference. Exact one-dimensional expected common length.
    for sizes in ((F(1),F(1)),(F(1),F(3,2),F(2)),tuple(F(1)+F(i,8) for i in range(9))):
        poly = [F(1)]
        for s in sizes:
            out = poly+[F(0)]
            for k,p in enumerate(poly):
                out[k+1]-=p/s
            poly=out
        a=min(sizes)
        length=2*sum(c*a**(i+1)/(i+1) for i,c in enumerate(poly))
        assert length<=2*max(sizes)/(len(sizes)+1)
        print("overlap mean length",len(sizes),length)
    for n in (64,256,1024,4096):
        N, b = n+2, int(n**0.5)
        assert b*b==n
        H = 8*(b+2)
        m = min(8, int((arb(N).log()).floor().unique_fmpz()))
        d = F(H,2*(m-1))
        assert d>=8
        eps = F(4**m*comb(N,m),2**(n-1)*d**(m-1))
        print("n",n,"m",m,"rank spacing",d,"multi-intersection geometric price/S",
              decimal_string(eps))


def cell_transport():
    # Conditional density vs. actual mass per resolution cell.
    for n in (8,32,128):
        width = F(1,4*n)
        mass = width**n/2
        microscopic = width/1024
        true_density = mass/microscopic**n
        smeared_density = mass/width**n
        inflation = (1+2*width)**n
        assert true_density > n**3 and smeared_density == F(1,2)
        assert arb(inflation.numerator)/inflation.denominator < (arb(1)/2).exp()
        print("cell dimension",n,"true/spread density",f"2^{10*n}",
              "spread density",smeared_density,"inflation",decimal_string(inflation))


if __name__ == "__main__":
    ctx.prec = 192
    print("Python",sys.version.split()[0],"python-flint",flint.__version__,"Arb bits",ctx.prec)
    real_full_history()
    multinomial_order()
    geometric_cost()
    cell_transport()
