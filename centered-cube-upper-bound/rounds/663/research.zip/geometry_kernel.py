"""Exact finite-cell Lebesgue geometry for frozen R663 diagnostics.

measure(fixture, groups): groups contain source_ids and representative_row_id.
All numerical outputs are fractions.Fraction; no claims of admissibility.
"""
from fractions import Fraction as F
from itertools import product
from math import prod


def _f(x):
    if isinstance(x, float):
        raise ValueError('Use integer or p/q string, not binary float')
    return F(x)


def measure(fixture, groups, max_cells=2_000_000):
    n = int(fixture['n'])
    if n <= 0:
        raise ValueError('n must be positive')
    cubes = {str(c['id']): c for c in fixture['cubes']}
    if len(cubes) != len(fixture['cubes']):
        raise ValueError('duplicate cube id')
    q = {str(i): _f(v) for i, v in fixture['q'].items()}
    if any(v < 0 for v in q.values()):
        raise ValueError('negative q')
    if set(q) - set(cubes):
        raise ValueError('q references missing cube')
    boxes = {}
    for i, c in cubes.items():
        y, s = list(map(_f, c['y'])), _f(c['s'])
        if len(y) != n or s <= 0:
            raise ValueError('invalid cube dimension or radius')
        boxes[i] = (tuple(x-s for x in y), tuple(x+s for x in y))
    c0 = F(32*n+1, 32*n)
    regions = []
    for group in groups:
        ids = [str(i) for i in group['source_ids']]
        rid = str(group['representative_row_id'])
        if not ids or rid not in cubes or any(i not in cubes for i in ids):
            raise ValueError('invalid group source or representative')
        lo = tuple(max(boxes[i][0][d] for i in ids) for d in range(n))
        hi = tuple(min(boxes[i][1][d] for i in ids) for d in range(n))
        # Equality is a nonempty degenerate intersection and must be expanded.
        empty = any(a > b for a,b in zip(lo,hi))
        radius = c0 * _f(cubes[rid]['s'])
        lower = tuple(x-radius for x in lo)
        upper = tuple(x+radius for x in hi)
        regions.append((lower, upper, cubes[rid]['order'], empty))
    result = {'W_union': F(0), 'W_sum': F(0), 'groups': [], 'cells': 0}
    if not regions:
        return result
    valid = [r for r in regions if not r[3]]
    if not valid:
        result['groups'] = [{'lower': r[0], 'upper': r[1], 'volume': F(0), 'empty_intersection': True} for r in regions]
        return result
    axes = []
    # A-faces split every pre-load indicator; region faces split ownership.
    for d in range(n):
        cuts = {v for lo,hi,_,empty in valid for v in (lo[d],hi[d])}
        envelope_lo, envelope_hi = min(cuts), max(cuts)
        for i in cubes:
            for v in (boxes[i][0][d], boxes[i][1][d]):
                if envelope_lo < v < envelope_hi:
                    cuts.add(v)
        ordered = sorted(cuts)
        axes.append([(a,b) for a,b in zip(ordered,ordered[1:]) if a < b])
    cell_count = prod(len(a) for a in axes)
    if cell_count > max_cells:
        raise ValueError(f'cell count {cell_count} exceeds limit {max_cells}')
    vols = [F(0) for _ in regions]
    for cell in product(*axes):
        mid = tuple((a+b)/2 for a,b in cell)
        volume = prod((b-a for a,b in cell), start=F(1))
        inside = [i for i,(lo,hi) in boxes.items() if all(a < x < b for a,x,b in zip(lo,mid,hi))]
        covered = False
        for j,(lo,hi,order,empty) in enumerate(regions):
            if empty or not all(a < x < b for a,x,b in zip(lo,mid,hi)):
                continue
            load = sum((q.get(i,F(0)) for i in inside if cubes[i]['order'] < order), F(0))
            if load <= 1:
                vols[j] += volume
                covered = True
        if covered:
            result['W_union'] += volume
    result['W_sum'] = sum(vols,F(0))
    result['cells'] = cell_count
    result['groups'] = [{'lower': r[0], 'upper': r[1], 'volume': v, 'empty_intersection': r[3]} for r,v in zip(regions,vols)]
    return result


def increment(fixture, old_groups, new_groups, max_cells=2_000_000):
    """Arrival increments: all new regions are unioned before subtracting old."""
    old = measure(fixture, old_groups, max_cells)
    new = measure(fixture, new_groups, max_cells)
    after = measure(fixture, list(old_groups)+list(new_groups), max_cells)
    return {'W_union_before': old['W_union'], 'W_union_after': after['W_union'],
            'W_sum_before': old['W_sum'], 'W_sum_after': after['W_sum'],
            'new_union_volume': new['W_union'],
            'increment_volume': after['W_union']-old['W_union']}
