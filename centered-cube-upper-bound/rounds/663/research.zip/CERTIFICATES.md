# R663 independent certificates

Executed 2026-11-15 in this directory with `/Users/zzh/.local/share/math-research-tools/venv/bin/python certificates.py`; interpreter Python 3.12.14, python-flint 0.9.0, Arb precision 256 bits. Script and input SHA-256 at execution:

- `certificates.py`: `f1cc8ecd17590c771ae46db4f729287b8abd1f7ce97ba7b32cb034363d43ec0a`
- `geometry_fixture.json`: `1eef91dffff4481e2c3ea83472457408776dc45c5bfa114675d8ee3f686344c7`
- `PROCESS_RESULTS.json`: `866e3b67a7dc08c8f0fb23a334c18036880c33ec07c36bc4f711609c8be50985`

Actual output:

```text
samples = 27
enumerated = 43/72, 43/108, 1/216
formula = 43/72, 43/108, 1/216
sum = 1
Arb bits: 256
E: [837962906690083939905896.1224411543793127442997434719922699003580285471607295 +/- 6.95e-53]
c256: [5.594856381350587773915340349559311736134322524129732000811642921960864846577e-924 +/- 1.35e-1000]
log10(c256): [-923.2522110572299079485076552179253228235219326324153926023602878901788290655 +/- 4.71e-74]
log2 rational upper: 23581/34020 < 3/4
exact cells: n3_simultaneous_two_keys events: 4 cells: 735 all ledger entries verified
exact cells: n3_repeated_labels_nontrivial_L events: 6 cells: 735 all ledger entries verified
exact cells: n3_repeated_labels_nontrivial_L events: 6 cells: 735 all ledger entries verified
event-ID rename replay verified
exact cells: closed_touching_intervals events: 2 cells: 5 all ledger entries verified
closed touching intersection: enlarged volume = 2
```

The script checks the rational atanh series upper bound, the finite winner enumeration and all cell measures using exact fractions. It asserts the stated Arb interval signs. For all integer n>=256, b(n)=(64n+1)/(1024n²) decreases and b(256)<1/4000<1; exact integer comparisons yield 32b(n)^n <=32/4000^256<10^-916. The E result excludes only the specified Poisson crude-tail times 2^n envelope, not the original geometric problem. The geometry tests are finite deterministic diagnostics, not original admission or near-budget evidence.

The intersection emptiness test uses strict `lower > upper`: a singleton intersection is retained before Minkowski enlargement. The separate one-dimensional touching input has A=[-1,1], B=[1,3]; intersection {1} expands by [-1,1] to [0,2], volume 2. No Wolfram computation was used.
