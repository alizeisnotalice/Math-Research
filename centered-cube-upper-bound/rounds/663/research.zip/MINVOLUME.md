# R663 A2 — first-source minimum-volume allocation

## Decisive formula and status

Let `b = 8`. Keep the actual shared Poisson law, all original representative choices, and first-coverage visibility. After the independently paid sets

\[
 P_b=\bigcup_{N_i(b)\ge1}A_i,
 \qquad
 Q_b^{\rm rep}=\bigcup_{N_i(b)\ge2}(A_i+c_0s_i[-1,1]^n),
\]
write

\[
 S_b=\Omega_b\setminus(P_b\cup Q_b^{\rm rep}).
\]
Their established budgets, communicated and independently audited in this round, are

\[
 \mathbb E|P_b|\le bU,
 \qquad
 \mathbb E|Q_b^{\rm rep}|
 \le \frac{b^2}{2}\Big(\frac{1+c_0}{a}\Big)^nU.
 \tag{1}
\]
For each point of `S_b`, choose its first covering key, breaking simultaneous-key ties by a fixed deterministic order. Within that key choose the largest original source index `i`. Because the source order is radius-descending, this is a minimum-radius/minimum-volume label, with all equal-radius ties resolved. Let `Z_i^b` be the resulting assigned spatial set. Then the sets `Z_i^b` are disjoint and partition `S_b`.

An assigned key contains the globally first event of label `i`. On `S_b` it contains the globally only event of label `i` in `[0,b]`. Conditioning on that event's time gives the exact, nonnegative, one-source formula

\[
 \boxed{
 \mathbb E|S_b|
 =\sum_i q_i e^{-bq_i}\int_0^b
       \mathbb E\big|Z_i^b(u;\eta_{-i})\big|\,du
 =\sum_i |F_i|\,C_i^b,
 }
 \tag{2}
\]

\[
 C_i^b=\frac{e^{-bq_i}}{d_i}
           \int_0^b\mathbb E|Z_i^b(u;\eta_{-i})|\,du.
 \tag{3}
\]
Here `eta_{-i}` is the unmodified joint background of every other label, and the Palm configuration has exactly one `i` event at `u`, with no other `i` event in `[0,b]`. The integrand recomputes all keys, their actual representatives, first visibility, `P_b`, `Q_b^rep`, and the deterministic assignment in that same background. It is not an iid law for an optimally selected anchor.

**No new absolute payment has been proved.** The outstanding estimate is the weighted aggregate

\[
 \sum_i|F_i|C_i^b\le A U.
 \tag{4}
\]
A uniform bound on every `C_i^b` would suffice but is stronger than necessary. Neither (2) nor the additional admission structure below is counted as a new global bound. The original general dimension target remains unproved.

## Why the exact source formula is valid

For a key whose chosen minimum source is `i`, every sampled radius is at least `s_i`, its target radius is at most `s_i`, and its intersection is contained in `A_i`. Consequently, simultaneously for all anchors and all such keys,

\[
 Z_i^b\subset A_i+c_0s_i[-1,1]^n,
 \qquad |Z_i^b|\le(1+c_0)^n d_i.
 \tag{5}
\]
Every key containing label `i` contains that label's globally first event: an earlier `i` event also belongs to the target's source pool and therefore cannot be skipped by its first-`k` event list. If `N_i(b)\ge2`, every point of that key's region belongs to `Q_b^rep`, whether or not the key itself repeated `i`. Thus no point of `S_b` is assigned to `i` in that case.

For a rate-`q_i` Poisson process, the density of exactly one event at time `u` in `[0,b]` is `q_i exp(-bq_i) du`. The other label processes are independent of this event-count conditioning. Integrate the actual assigned volume and sum. This proves (2). No insertion times of other labels are removed or replaced by a simplex factor.

Without the paid repeat pruning, the corresponding valid first-event formula is

\[
 \mathbb E|\Omega_b|
 =\sum_i q_i\int_0^b e^{-q_i u}
       \mathbb E|\widetilde Z_i^b(u)|\,du,
\]
where the `i` process after `u` remains live. Formula (2) is more specific to the now unpaid residual: it retains only globally single-event labels.

The available deterministic bound gives only

\[
 C_i^b\le b e^{-bq_i}(1+c_0)^n\le b(1+c_0)^n.
 \tag{6}
\]
It is dimension dependent and does not close (4).

## A real admission condition shared by all keys charged to one source

For an accepted source `i`, put

\[
 J_i^{\rm in}=\{j<i:y_i\in c_0A_j\},
 \qquad \lambda_i=\sum_{j\in J_i^{\rm in}}q_j.
\]
Original admission, with actual raw weights, gives

\[
 \lambda_i\le\sum_{j<i}w_j\mathbf1_{c_0A_j}(y_i)\le1.
 \tag{7}
\]
This is a constraint at the chosen minimum source's center, not an extra iid assumption. It holds simultaneously for all possible representatives charged to `i`.

Under the single-`i` Palm law in (2), the number of background events in `J_i^in` by time `b` has law

\[
 N_i^{\rm in}(b)\sim\operatorname{Poisson}(b\lambda_i),
 \qquad b\lambda_i\le b.
 \tag{8}
\]
Every assigned key contains `i` exactly once; all its other indices are strictly less than `i`. Therefore it has at least

\[
 k-1-N_i^{\rm in}(b)
 \tag{9}
\]

events from earlier sources `j` with `y_i` outside `c_0A_j`. These are distinct labels on `S_b`. Furthermore, since `s_j\ge s_i`, each such `A_j` is disjoint from the small receiver `B_i`: in a separating coordinate its distance from `y_i` exceeds `s_j/a\ge s_i/a`.

For every point `x` of `S_b`, all sampled original parents, including `A_i`, also exclude `x`. Thus the joint remainder really has all three properties:

- all labels of the assigned key have globally exactly one event;
- `x` is outside every marked original parent;
- except for the common count (8), the key's larger sources exclude `c_0`-coverage of `y_i` and hence exclude `B_i`.

The count (8) must not be declared independent of the selected key or of `Z_i^b`: it is part of the very background that selects them. The unconditional Poisson law itself is valid.

## Why these pointwise conditions do not by themselves bound the halo

This is a diagnostic for a deterministic geometric shortcut, not an actual near-input counterexample.

Let `s_i=1`, `y_i=0`, and `A_i=[-1,1]^n`. Set `epsilon=1/4`. Choose distinct radii `1<s_j<n` and parents

\[
 A_j=Q((0,s_j+1-\varepsilon,0,\ldots,0),s_j).
\]
All these parents exclude `y_i` even after `c_0` expansion, since their lower second-coordinate face after expansion is

\[
 1-\varepsilon-s_j/a>3/4-1/32>0.
\]
Their intersection with `A_i` has positive volume:

\[
 K=[-1,1]\times[1-\varepsilon,1]
            \times[-1,1]^{n-2}.
\]
With target radius `r=1`, its halo contains the set

\[
 E=\{x:-\varepsilon<x_2<1-\varepsilon,\quad
            |x_m|<2\ (m\ne2),\quad
            \max_{m\ne2}|x_m|>1\}.
\]
Every `x` in `E` is outside `A_i` and every `A_j`. Also

\[
 \frac{|E|}{d_i}
 =\frac{4^{n-1}-2^{n-1}}{2^n}
 =2^{n-2}-\frac12.
 \tag{10}
\]
So distinctness, exclusion of both the source center and the output point, and a positive-volume common intersection do not yield an absolute deterministic halo bound for one minimum source.

This configuration cannot be promoted to a frozen-input counterexample by simply declaring a large load. A larger-radius displayed parent contains the center of every smaller displayed parent. Under genuine admission, the raw earlier load there is at most one. In particular the minimum source at the origin is the only center that escapes all these parents; the other sources' mutual admission prevents this displayed one-direction list from accumulating the required near load. Any successful argument for (4) must use that additional mutual-admission and true-high-load information. Equation (10) only rules out discarding it.

## A discarded coarse-tail route and actual computational evidence

Before repeat pruning, the first-`i` Palm number of non-outward events is bounded by `1+Poisson(b(1+q_i))`; after pruning it is `1+Poisson(b)`. Multiplying an upper-tail probability for this count by the full envelope `(1+c_0)^n d_i` does not give a dimension-uniform bound when `k` is of order `sqrt(n)`: its log behaves as

\[
 n\log2-O(\sqrt n\log n),
\]
which is positive for sufficiently large dimensions.

The numerical-design worker actually ran local Python Decimal at 70 and 110 digits for

\[
 n=2^{80},\quad \tau=2^{54},\quad m=\tau-1,
\]
using the conservative Poisson mean `9`. Its scalar

\[
 E=n\log\left(2+\frac1{32n}\right)
       -m\log\frac{m}{9e}-9
\]
was subsequently independently enclosed by the numeric auditor with Arb at 256 bits:

\[
 E\in[837962906690083939905896.1224411543793127442997434719922699003580285471607295
       \ \pm 6.95\,10^{-53}]>0.
\]
The scripts and evidence belong to that worker's `NUMERIC_DESIGN` / certificate deliverables, not this file. This check only rejects the coarse tail-times-envelope payment; it is neither a geometric counterexample nor evidence against (4).

## Bounded handoff

The source-by-source Palm integral (2), the simultaneous admission count (7)–(9), and the simple/external residual are all compatible. The precise unproved step is a bound on their actual joint spatial assignment using mutual admission and high load, sufficient for (4). The one-anchor fractional minimum moment and full lens theorem do not automatically become conditional estimates for this background-selected union, and summing anchor masses would reintroduce the original unpaid repetition.

No new complete-family absolute inequality or summable contraction was obtained in this bounded attempt. Stop here pending reassignment; do not count the equivalent integral as improvement.
