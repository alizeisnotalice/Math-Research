# R663 最终独立整合审查 — S8

**结论：PASS（限报告实际声称的局部全族支付、精确恒等式和条件回代）；完整目标 OPEN。无需修改当前报告。**

本审查绑定 `/Volumes/data/CodexTemp/centered-cube-r663-20261115/REPORT.tex`，SHA-256：

`98e7682e40d0379e9e79ff4500ee238d0f40f13529f5fccefd198174fcb85481`

先独立核对报告开头、(6)、(7)、(13)，再读报告其余证明、`FINITE_HORIZON.md`、`AUDIT_POTENTIAL.md`（含§7）、`MINIMUM_DISINTEGRATION.md` §6 和 `NUMERIC_DESIGN.md`。没有重跑几何程序、Arb 或随机模拟；没有编辑他人文件、Git 或新增代理。数学审查使用 math-research 与 J04 的可预测性、非负积分和端点检查；下附唯一新增的本机核验仅是式(7)的符号常数回代。

## 1. 结论与三个关键公式

报告明确未证明一般纯 `C_n≤K√n`，也未证明旧一般 `n^{1/2+o(1)}`。本轮新成果被限制为同一随机 covering 中两份真正的全族空间支付及 finite-horizon reduction；并未把剩余精确公式记作已支付费用。这与后续证明一致。

**(6) PASS，量词为所有实际有限完整状态。** 固定 `b=8`，真实 near 行有 `T_j>τ/2`、`k=ceil(2τ)`，整数事件 `N_j(8)<k` 蕴含 `N_j(8)<2τ`。Poisson 指数 Markov 给 `P(unfinished)≤e^{-τ/2}≤ε_τ=e^{-τ/4}`。真实 `X_j` 不交，所以按其体积求期望不需要各目标完成事件独立。完成损失纳入同一 `Ω_8`，未完成部分最多 `ε_τV_near`，故 `(1−ε_τ)V_near≤E|Ω_8|`。端点没有强制补完成或免费添加 region。

**(7) PASS，但严格是条件结论。** 若对同一全部实际状态另证 `E|S_8|≤AU`（A 为绝对常数），则由(3)、(6)与 `P_0≥U/τ`：

`V_0/P_0≤C_adm{τ[1+(8+δ_n+A)/(1−ε_τ)]+K_far}`。

用 `(1−ε_τ)^{-1}≤2`、`δ_n<3` 得系数 `1+2(8+δ_n+A)≤23+2A`，再以 `τ=16384√n` 和 `K_far≤K_far√n` 得(7)。没有代表数、tag数、尺度范围或最小正 q 的隐含依赖。`n<256` 用已证 near 空分支；`U=0` 无正 near source，完整账得 `V_0=0`，未除零。

**(13) OPEN，精确量词正确。** 它要求在所有当前实际有限状态、同一固定 horizon 联合律、同一真实 source/receiver/admission 和 first visibility 选择下，以绝对 A 支付加权总和。它不要求每个条件来源分别有统一帽，后者更强。报告既未证明(13)，也未从前两项支付或一维 count law 推断(13)。其等价性依赖(9)的精确条件积分，见第3节。

## 2. 两份全族支付与 residual 限制

- `P_b^mark=∪_{N_i(b)≥1}A_i` 包含所有已标记来源，不限于选中或完成 key 的来源。`E|P_b^mark|≤Σd_iE N_i(b)=bU`，故 `b=8` 为 `8U`。没有把每次 event 只按 `|F_i|` 收费。
- `Q_b^rep=∪_{N_i(b)≥2}(A_i+c_0s_iQ)` 使用**全局计数**。原 owner 给真实 `q_i≤a^{-n}`，Poisson factorial moment 给 `P(N_i≥2)≤b²q_i²/2`，故 `E|Q_b^rep|≤(b²/2)[(1+c_0)/a]^nU`。这只对来源求和，不对目标、代表或 key 求和。`b=8` 正好给报告的 `δ_n`。
- 对任意完成 key 的每个标签 i，其代表 h 满足 `s_h≤s_i`，故整个 region 在该 i 的扩张 parent 中。若其全局第二次 event 在 key 完成后、但仍在 b 前发生，它仍由 `Q_b^rep` 支付。这是报告保留的必要强化。
- 因此 `S_b` 的任一点，由**每一个**覆盖它的完成 key 所用标签均满足 `N_i(b)=1`，不仅是该 key 内无重复。该点也不在任何已标记原 parent 中，包括未属于所选 key 的已标记来源。报告保留了这些同时限制，没有把余下 key 宣称 iid。

## 3. Janossy 分解与 admission 背景

对 `S_b` 先选真实 first covering key（同 arrival 多 key 用固定规则破同分），再选最大原索引 i，等价于最小半径/体积 source 的确定破同分。`Z_i^b` 是不交分割，不会重复支付同一点。

选中的 i 必全局恰有一次 event；它在 `[0,b]` 的位置密度为 `q_i e^{-bq_i}du`。给定它后，其他 source processes 保持原独立律，但每个积分内重新计算全部历史、paid sets、代表及 visibility。于是(9)和(13)左端相等。`Z_i^b` 依赖未来 repeat pruning 和竞争 key；报告正确使用 exact-one Janossy 条件积分及非负 Tonelli，未错用可预测 compensator，也未用 `e^{-uq_i}` 取代 `e^{-bq_i}`。

真实 admission 在固定中心 y_i 给 `λ_i=Σ_{j<i:y_i∈c_0A_j}q_j≤1`。在单个 i 的 exact-one 条件下，**未选择**的其余背景 incoming count 是 `Pois(bλ_i)`，可由 `Pois(b)` 随机支配。它与 `Z_i^b` 的存在、选中 key、体积没有独立性。报告显式保留选择偏差，未将 tail 与 selected-volume expectation 相乘。

最大索引规则保证其他 key 标签均早于 i。至少 `k−1−N_i^in(b)` 个 key events 来自外向来源；半径序加中心不在 `c_0A_j` 确保这些 `A_j` 避开 `B_i`。此确定几何信息没有被提升为未证的全局系数帽。

## 4. signed prefix union 与端点

active prefixes 只取非空且未完成者；最初 `A=Ω=∅`，potential 为零。旧 group 分裂后的各 child 代表不早于 parent，halo 半径及 `L_h` 只缩小、intersection 只增加约束，因此区域嵌套。首次收到 event 的空-prefix 目标只形成一个新的 singleton group，birth 可由单个 source 的扩张 parent 控制。

`B_i,D_i,Δ_i` 均在全部 child、survivor 和同 arrival 所有 completed keys **先取并集后**计算。因此 `δP=B_i−D_i−Δ_i` 保留空间重合收益；没有按 key 逐个收取 completion 或 death。固定有限输入有有限总体积 envelope，有限时域总 Poisson rate 有限，假想插入量依赖 past state，故该处非负有限 Poisson compensation 合法。式(11)保留 `E P_b≥0` 与 death 项，没有漏掉初始或终端项。其 birth 上界仍为 `b(1+c_0)^nU`，报告没有将其称作绝对预算。

这与第3节未来依赖的 Janossy integrand 是两个不同的适用合同，报告未混用。

## 5. 计算证据和 key 编码纠正

`NUMERIC_DESIGN.md` 明确 n=3 fixtures 的 `q=1/10` 或 `1` 超过真实 cap `96^{-3}`，且不满足实际 admission/near 条件；k=2/3 是诊断参数，未替换真实 `ceil(32768√3)`。三套实现一致只认证冻结实例的 event/geometry 账本，未成为原范围定理或反例。MATLAB 手选子集不是冻结 event ledger，报告引用的是对应冻结结果。

`n=2^80` 检查仅为一个 scalar upper-bound exponent 的严格区间正号，不是高维几何模拟。它拒绝的是“coarse tail × entire expanded parent”该上界策略，不是否定所有真实 residual 支付。

报告已正确撤回过强的旧警告：在同一固定全局 event tape 和固定 membership 中，source multiplicities 确定每个 source 的最前若干 events，全局顺序恢复 full key；故同 tape 中相同 label sequence 而不同 event IDs 的所谓反例不可能。实现保留 full event IDs 不影响现有证明，跨运行一致重命名 replay 也不制造该不可能反例。

## 6. 唯一新增本机核验及审查范围

只核对(7)条件常数的符号代数；不重跑现有几何程序/Arb。代码保存在本文件，使用已有数学环境执行：

```python
# BEGIN_FINAL_REVIEW_ALGEBRA
import sys
import sympy as sp
A, delta = sp.symbols('A delta', real=True)
from_account = sp.expand(1 + 2*(8 + delta + A))
assert from_account == 17 + 2*delta + 2*A
assert sp.expand((23 + 2*A) - from_account) == 2*(3-delta)
print('recovery coefficient:', from_account)
print('nonnegative slack for delta<=3:', sp.expand((23+2*A)-from_account))
print('Python:', sys.version.split()[0], 'SymPy:', sp.__version__)
# END_FINAL_REVIEW_ALGEBRA
```

复现：`/Users/zzh/.local/share/math-research-tools/venv/bin/python` 读取本文件上述两个 marker 之间的代码并执行。实际输出如下。这个符号检查只确认常数回代，不证明 residual bound。

```text
recovery coefficient: 2*A + 2*delta + 17
nonnegative slack for delta<=3: 6 - 2*delta
Python: 3.12.14 SymPy: 1.14.0
```

最终处分：当前报告所声称结论通过独立整合审查；未发现需修正文点。完整一般目标仍停在(13)的 `E|S_8|≤AU`，不能据本审查记作完成。

## 7. 封版前限定修订复核

主报告数学主体审查后，只复核新增的两处计算措辞/边界修复，未重新审计或重跑已过计算。最终绑定的是文件顶部的新报告 SHA，而非初读的 `36d8defe…c4daf`。

- 报告目前 :334–336 说 fixture experiment 的 stochastic trials 为零，并单列 seeded RNG reproducibility self-test，且声明它没有 probability-bound evidence。这与 `firstkey_engine.py:127` 的 `poisson_history(f,17)` 重现自检一致，纠正了过强的“全部 stochastic simulation 为零”措辞。n=2^80 仍只是 scalar check。
- `certificates.py` 的一般 `groups` 函数曾以 `lower>=upper` 丢弃相切但非空的 raw intersection；修复后只用严格 `lower>upper` 判空，保留 singleton 后再 Minkowski 扩张。当前代码已含一维 A=[−1,1]、B=[1,3] 的相切测试，交集 {1} 以 radius 1 扩张得到 [0,2]，长度 2。
- `CERTIFICATES.md` 记录了修复后的实际执行：`closed_touching_intervals` 两 events、5 rational cells 全账本通过，expanded volume=2；原两份735-cell fixture仍全部通过。原fixtures raw intersections均为正宽，故旧错误不改其已报体积，但该一般边界条件仍必须修复，现已修复并留下执行记录。
- 我只读取代码、记录并核对当前哈希，没有代跑该修复套件。当前 `certificates.py` SHA `f1cc8ecd17590c771ae46db4f729287b8abd1f7ce97ba7b32cb034363d43ec0a`、fixture SHA `1eef91dffff4481e2c3ea83472457408776dc45c5bfa114675d8ee3f686344c7`、process-results SHA `866e3b67a7dc08c8f0fb23a334c18036880c33ec07c36bc4f711609c8be50985` 与该执行记录完全相同。

上述修订不影响event-ID证明、(6)/(7)/(13)的审查结论或完整目标仍OPEN的处分。
