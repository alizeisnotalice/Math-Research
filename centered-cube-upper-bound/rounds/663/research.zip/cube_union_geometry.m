function result = cube_union_geometry(fixture, groups)
% Independent floating-point finite-cell check; exact outputs are Python Fraction.
n = fixture.n; cubes = fixture.cubes; nc = numel(cubes); ng = numel(groups);
ids = cell(1,nc); q = zeros(1,nc); ord = zeros(1,nc); radii = zeros(1,nc);
lo = zeros(nc,n); hi = zeros(nc,n);
for i=1:nc
    ids{i} = char(string(cubes(i).id)); ord(i) = cubes(i).order;
    radii(i) = ratval(cubes(i).s);
    for d=1:n
        if iscell(cubes(i).y), x=ratval(cubes(i).y{d}); else, x=ratval(cubes(i).y(d)); end
        lo(i,d)=x-radii(i); hi(i,d)=x+radii(i);
    end
    field=matlab.lang.makeValidName(ids{i});
    if isfield(fixture.q,field), q(i)=ratval(fixture.q.(field)); end
end
rlo=zeros(ng,n); rhi=zeros(ng,n); ro=zeros(ng,1); empty=false(ng,1);
for j=1:ng
    src=groups(j).source_ids;
    if ~iscell(src), src=cellstr(string(src)); end
    ix=zeros(1,numel(src));
    for t=1:numel(src), ix(t)=find(strcmp(ids,char(string(src{t}))),1); end
    h=find(strcmp(ids,char(string(groups(j).representative_row_id))),1);
    l=max(lo(ix,:),[],1); u=min(hi(ix,:),[],1); empty(j)=any(l>u);
    rad=(1+1/(32*n))*radii(h); rlo(j,:)=l-rad; rhi(j,:)=u+rad; ro(j)=ord(h);
end
result=struct('W_union',0,'W_sum',0,'group_volumes',zeros(ng,1),'cells',0);
valid=find(~empty); if isempty(valid), return; end
edges=cell(1,n); counts=zeros(1,n);
for d=1:n
    boundaries=[rlo(valid,d);rhi(valid,d)]; mn=min(boundaries); mx=max(boundaries);
    faces=[lo(:,d);hi(:,d)]; edges{d}=unique([boundaries;faces(faces>mn & faces<mx)]);
    counts(d)=numel(edges{d})-1;
end
N=prod(counts); if N>2e6, error('Cell count exceeds limit'); end
for z=0:N-1
    rem=z; mid=zeros(1,n); vol=1;
    for d=1:n
        ix=mod(rem,counts(d))+1; rem=floor(rem/counts(d));
        a=edges{d}(ix); b=edges{d}(ix+1); mid(d)=(a+b)/2; vol=vol*(b-a);
    end
    incube=all(lo<mid & mid<hi,2); covered=false;
    for j=valid'
        if all(rlo(j,:)<mid & mid<rhi(j,:)) && sum(q(incube' & ord<ro(j)))<=1
            result.group_volumes(j)=result.group_volumes(j)+vol; covered=true;
        end
    end
    if covered, result.W_union=result.W_union+vol; end
end
result.W_sum=sum(result.group_volumes); result.cells=N;
end
function x=ratval(v)
if isnumeric(v), x=double(v); return; end
parts=split(string(v),'/'); x=str2double(parts(1));
if numel(parts)==2, x=x/str2double(parts(2)); end
end
