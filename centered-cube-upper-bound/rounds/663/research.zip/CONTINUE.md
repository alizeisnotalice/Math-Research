# R663 continuation: one unchanged global target

Status: the pure general C_n <= K sqrt(n), and the former general n^(1/2+o(1)) goal, remain OPEN. REPORT.tex is the authoritative integrated statement. FINAL_REVIEW.md independently binds its SHA-256. Do not count exact identities or the finite diagnostic fixtures as dimension-order improvement.

## Read first

REPORT.tex sections 2–4 and 7 freeze the finite input, complete account, common source Poisson law, paid sets, and exact remaining target. R658 is the whole-history/minimal-recovery entry; R660–R662 supply the already proved actual-weight, admission and common-point tools. Do not reread the entire history without a specific need. The user's adopted Centered_Cube_Pro_Prompt_Sqrt_n.md calls for a short rebuilt construction with the full general scope.

## Frozen target

For every actual finite admission/residual state, a=32n, c0=1+1/a, tau=16384sqrt(n), k=ceil(2tau), q_i=|F_i|/d_i, U=sum |F_i|. The q values must be generated at this tau. Each actual near target has T_j in (tau/2,tau], its saturation witness and original radius order. All targets use one common independent source-labelled Poisson flow of rates q_i. Their first k actual events form their keys. A completed group uses the earliest original target h, radius s_h, and L_h={sum_{i<h}q_i 1_Ai <=1}. Union all completed regions at time b=8.

P_8 is the union of all source parents having at least one event. Q_8 is the union of (A_i+c0*s_i*[-1,1]^n) over sources having at least two global events by 8. S_8=Omega_8 minus (P_8 union Q_8). The proven complete account is

(1-exp(-tau/4))*V_near <= (8+delta_n)*U + E|S_8|,
delta_n=32*((64n+1)/(1024n^2))^n <3, and <10^-900 for n>=256.

The open statement is E|S_8| <= A U with absolute A. The exact single-event source decomposition is REPORT (9)/(13). It only requires the weighted aggregate sum |F_i| C_i <= A U, not an unproved uniform cap for every C_i. All source families' mutual admission constraints remain mandatory. Selected/background conditional independence must not be invented.

## Proven facts available to the next argument

- A source selected by the largest original index has minimum radius with a fixed tie rule. Its earlier incoming admission mass is <=1. At a prescribed exact-one event of this source, the *unselected* background incoming count has Poisson mean <=8; selected volume and this count are dependent.
- Every source in every key covering S_8 has exactly one global event by time 8, and S_8 misses every marked parent, even those outside the selected key.
- Real F_i are disjoint and lie in B_i; arbitrary f is not given a density bound.
- REPORT (11) is an exact signed active-prefix union account with terminal potential. Its proved birth bound is exponential, and has not been paid by its negative spatial term.
- R662 gives a common-point iid random-intersection expectation estimate. It cannot be summed across representatives or applied after selection without retaining the joint conditioning and source reuse.

## Decisions already made

Do not spend another round on a Poisson low-count tail times the whole expanded-parent envelope: its scalar bound fails at n=2^80 and asymptotically. This is not a counterexample to the true S_8 budget. Simple clock/depth potentials leave promotion when cores or representatives change. No root estimate follows from equal rates, fixed scales, arbitrary indicator caps or independently killed targets.

A useful next task must exploit actual mutual admission jointly with receiver exclusion and cube-coordinate geometry, or prove a globally summable birth/death comparison under that same input. A new identity alone is insufficient. An independent route may be tested only against the same complete account.

## Reproduction and scope

Use the local math interpreter /Users/zzh/.local/share/math-research-tools/venv/bin/python. Run `python verify.py` from an extracted archive. The script uses a separate temporary reproduction directory and does not overwrite frozen results. Dependencies include python-flint; exact rational checks use the standard library. MATLAB R2026b Update 1 was actually used for the saved frozen-fixture geometry crosscheck; no Mathematica run is claimed. No PDF is compiled.

Both 3D fixtures are diagnostic only: q, k, actual admission, near-window and actual owner conditions do not match the proposed general theorem. The engine additionally performs two identical seeded RNG calls solely for a reproducibility self-test. No Monte Carlo probability estimate was obtained. The independent cell checker now retains touching closed intersections before enlargement and includes a separate exact tangent input.

## Archive discipline and collaboration

One completed round, one commit/push. This round preserves only its integrated report, needed audits/proof supports, frozen numerical inputs, necessary code, actual result summaries and reproduction metadata. Local-only auxiliary face/overlap/source-integral notes and superseded exploration are not new certified global estimates. No caches or PDFs belong in the archive.

The actual R663 dispatch was four Astra, ten GPT-6.1 Sol and three Terra roles; their bounded tasks completed and stopped. Reuse them according to the next precise tasks; do not count completed agents as active or fill slots with duplicate work. No billing-credit data are available. Coordinate local numerical jobs by decision value, and do not count other projects' CPU load as this project's work.
