# Minimum-volume disintegration and one first-arrival source invoice

S3, R663, 2026-11-15. Scope: the actual common-point sources and the one shared first-k Poisson law in TASK.md and R662 REPORT §§3.1, 4. This note does not reprove or strengthen the local intersection estimate M. It gives exact source decompositions, including ties and repeated labels, and records the still unpaid geometric coefficient. No general dimension improvement is claimed.

The math-research skill was read for the distinction between identities, proofs, and computation. The identities below are proved algebraically. A tiny rational enumeration was requested through the parent for Terra; no computation is claimed here unless its result is appended below.

## 1. Fixed-family minimum, with ties and replacement

Fix a finite nonempty I with q_i>0, T=sum_I q_i and p_i=q_i/T. Let V=(V_1,...,V_k) consist of independent p-labels, with replacement. Set

A_i=sum_{j in I:d_j>=d_i}p_j,  B_i=sum_{j in I:d_j>d_i}p_j,
m_i=A_i-B_i=sum_{j:d_j=d_i}p_j>0.

Break minimum-volume ties by the first event position at which the minimum volume occurs. If that position is ell and its label is i, the event is

C_{i,ell}={d_{V_a}>d_i for a<ell; V_ell=i; d_{V_a}>=d_i for a>ell}.

These events partition the entire tuple space, including tuples with repeated labels. In particular,

P(C_{i,ell})=p_i B_i^(ell-1) A_i^(k-ell),
P(minimum winner=i)=(p_i/m_i)(A_i^k-B_i^k).                    (1)

The conventions 0^0=1 and zero-probability terms equal to zero cover all boundary cases. Given C_{i,ell}, the labels before ell are independent with law p_j 1_{d_j>d_i}/B_i, the label at ell is i, and the remaining labels are independent with law p_j 1_{d_j>=d_i}/A_i. There is no exclusion of later copies of i.

For every nonnegative tuple function F, the exact weighted disintegration is

E F(V)=sum_{i,ell} p_i B_i^(ell-1)A_i^(k-ell) E[F(V)|C_{i,ell}]. (2)

This remains true with F=Phi rho, or with rho_h^b at a finite horizon b. It does not replace E[Phi rho|C] by a product of conditional or unconditional expectations.

A deterministic ordering within each equal-d class gives another valid convention: order labels by (d_i,i), and replace A_i,B_i by the masses at-or-after and strictly-after i. The first-occurrence convention (1) has the advantage that equal-volume labels receive their exact q_i proportions.

For a volume-only nonnegative function g, (1) gives the exact expression

E g(d_min)=sum_i (p_i/m_i)(A_i^k-B_i^k)g(d_i).                (3)

Equivalently, with Q(u)=sum_{d_i>u}q_i and any alpha>0,

E d_min^alpha=alpha integral_0^infty u^(alpha-1)(Q(u)/T)^k du. (4)

Equation (4) alone has lost which source paid the minimum. Formula (2) retains that information and its correlation with selection.

## 2. Exact lens invoice, with representative or visibility weights

For one fixed representative candidate h, write I=I_h, T=T_h, R=c0 s_h, K_{hi}=A_i+R[-1,1]^n and

Phi_h(V)=integral_{L_h} product_{a<=k}1_{K_{h,V_a}}(x) dx.

All source cubes in I_h share z_h, so their intersections are nonempty. Thus the box identity used in R662 applies to Phi_h. For x define the restricted masses

A_{hi}(x)=sum_{j in I_h:d_j>=d_i}p_j 1_{K_{hj}}(x),
B_{hi}(x)=sum_{j in I_h:d_j>d_i}p_j 1_{K_{hj}}(x).

Let w_h(V,x) be any measurable weight in [0,1]. Conditional on C_{i,ell} AND all labels being x-eligible, let its conditional mean be wbar_{hi,ell}(x). The conditional label laws are exactly the two laws following (2), additionally restricted to K_{hj} containing x. A zero normalizer contributes zero. Tonelli and the same partition yield

E integral_{L_h} product_a 1_{K_{h,V_a}}(x) w_h(V,x) dx
 = sum_{i in I_h} |F_i| beta_{hi}(w),                         (5)

beta_{hi}(w)
 = 1/(T_h d_i) integral_{L_h intersect K_{hi}}
       sum_{ell=1}^k B_{hi}(x)^(ell-1) A_{hi}(x)^(k-ell)
                         wbar_{hi,ell}(x) dx.                 (6)

Here |F_i|=q_i d_i is the actual source volume. This is a genuine nonnegative source-by-source invoice, without a source-density cap or coordinate independence. It retains the exact geometric lens and all correlations. It is also valid when w_h depends on labels and x through a conditional average over event times and the shared background.

For the sum price at horizon b, take w_h(V,x)=rho_h^b(V), where

rho_h^b(v)=integral_0^b [T_h^k t^(k-1)e^(-T_h t)/(k-1)!]
  P(all earlier compatible targets killed by the shared background on I_h^c up to t) dt.

The kill events remain joint. The superscript b means a time cutoff, not a power. Then (5) is the exact minimum-source decomposition of that representative's sum-price term.

For the union price, define theta_h^b(v,x) as follows. Condition on the first k labels in I_h being v; average over their ordered times and the complete other-label history. The event whose indicator is averaged is: h represents its key, its completion time is at most b, and this key wins x's first-coverage assignment (defined in §3). Then 0<=theta_h^b(v,x)<=rho_h^b(v). Taking w=theta gives

E|Omega_b|=sum_i |F_i| sum_{h:i in I_h} beta_{hi}(theta).       (7)

There is no iid assertion about the selected tuple in (7). The iid law is only the conditional integration reference before applying theta. The visibility weight depends on the actual previous completion times. Consequently one cannot obtain theta by appending an independent visibility probability to rho, or discard earlier insertion times with a bare simplex factor.

A legal but weaker bound is obtained by the minimum cube envelope. Put

g_{hi}=(d_i^(1/n)+2R)^n.

On C_{i,ell}, Phi_h<=g_{hi}. Thus

E[Phi_h rho_h^b]
 <= sum_i |F_i| [g_{hi}/(T_h d_i)]
    sum_ell B_i^(ell-1)A_i^(k-ell)
                      E[rho_h^b(V)|C_{i,ell}].                (8)

Every conditional expectation in (8) matters. Dropping it is legal, but then the coefficients may repeat for arbitrarily many h. Neither (3), (4), nor R662's fractional minimum moments bounds that cross-anchor sum.

## 3. The whole union can be invoiced at one first event of each source

This section gives a useful collapse of (7) to one first-arrival Palm conditioning per source, without summing anchor laws at different gamma rates.

Fix a deterministic horizon b>0 (in particular b=8). For each covered x, choose the earliest completion time of a key covering x; if several keys complete at that arrival, choose one by a fixed deterministic order of their representatives. In the chosen key, choose the first event of minimum source volume d, as in §1, and assign x to its source label i. Let Z_i^b be the volume assigned to i. Pathwise,

|Omega_b|=sum_i Z_i^b.                                      (9)

These are assignments of newly visible union volume, not a sum of overlapping key volumes.

A first-k key containing label i necessarily contains the global first event of label i: since i belongs to that target's I_h, any earlier i-event is earlier in the same restricted stream and must be in its first-k prefix. The chosen minimum event is therefore the global first i-event. Denote its time by S_i. In particular Z_i^b=0 on {S_i>b}.

Condition on S_i=u. This means: no i-events before u, an event of label i at u, an independent rate-q_i process after u, and the original independent processes of every other label on the whole time interval. Let Z_i^b(u) denote the assigned volume evaluated in this conditional construction; all representatives, simultaneous completions, other anchors, low-load sets and first visibility are retained. Since S_i has density q_i e^(-q_i u),

E Z_i^b = q_i integral_0^b e^(-q_i u) E Z_i^b(u) du.          (10)

This is ordinary first-arrival conditioning, not a claim that the future-dependent assignment is predictable. No Mecke or compensator replacement of its past/future dependence is being made.

If a key has minimum winner i, its representative satisfies s_h<=s_i, and its intersection lies in A_i. Hence its entire restricted region lies in the same deterministic envelope

A_i+c0 s_i[-1,1]^n,

regardless of the anchor or other events. Consequently

0<=Z_i^b(u)<=(1+c0)^n d_i,
E Z_i^b <=(1-e^(-b q_i))(1+c0)^n d_i
          <=b(1+c0)^n |F_i|,                               (11)
E|Omega_b|<=b(1+c0)^n U.                                   (12)

This is a valid whole-family estimate with no tag multiplicity loss, but its exponential dimension factor does not meet the task. It shows precisely where the shared-law source budget exists and where geometry is still needed.

Comparing (7) and (10), the exact whole-source coefficient obeys

sum_{h:i in I_h} beta_{hi}(theta)
 = (1/d_i) integral_0^b e^(-q_i u) E Z_i^b(u) du
 <=b(1+c0)^n.                                              (13)

Thus a sufficient new geometric statement for Omega_b would be

integral_0^b e^(-q_i u) E Z_i^b(u) du <= A d_i               (14)

for every actual source i, with absolute A; a pointwise conditional bound E Z_i^b(u)<=C d_i would give A=bC. More generally a bound after multiplying (14) by q_i and summing i is enough. Equation (14) retains the same original multi-anchor shared background; replacing it by separately conditioned single-anchor minimum moments is not justified.

For Omega_infinity, (10) extends to [0,infinity) by monotone convergence of the first-coverage assignment (once x is covered its assignment is fixed). The bound from the deterministic envelope then gives only E Z_i^infinity<=(1+c0)^n d_i, with no q_i factor. Dividing by |F_i| reintroduces 1/q_i. A bounded-horizon argument therefore needs its own actual completion/tail contract before it pays the entire terminal union.

## 4. Exact obstruction and handoff

The surviving useful statements are (6), the conditional source invoice; (10), its once-per-source first-arrival form; and (13), their consistent whole-family coefficient. They are identities or elementary inequalities, not a new absolute bound.

The missing estimate is the conditional multi-anchor union geometry in (14), or a summable replacement for it. R662's local minimum moment bounds an unselected iid tuple from one I_h. Conditioning on selection, first visibility, or a source's first event changes the tuple/background law and can correlate large intersections with being selected. No negative correlation, conditional iid law, sum_h rho_h<=1, or cross-anchor source multiplicity bound has been established. Ties and repeated labels are not the obstruction: they are fully covered by the exact partitions above.

Only this file was written by S3. No other author's files or Git state were changed.

## 5. Bounded exact computation supplied by Terra

Terra reported actually running `certificates.py` in this same R663 directory, using Python `Fraction` to enumerate all 27 ordered tuples for p=(1/2,1/3,1/6), d=(1,1,4), k=3. The minimum-d/first-slot winner probabilities were exactly

(43/72, 43/108, 1/216),

and sum to 1. Each agrees with (1). This checks one tied, with-replacement example; the all-parameter justification is the partition proof in §1. S3 did not run or alter that certificate script.

## 6. Independent scope audit of the exact-once residual invoice

Author: S3. Reviewed author file: `MINVOLUME.md` (Astra A2), SHA-256 `8601eb21d8a2f96f7d575a4c86a98d22e3a88f192e62e46ac187bf47c7d2040f`. This section binds that file version. The exact-once argument below was checked from the parent's formula before reading the author file; the author file was then checked for scope and correlation claims. No prior probability example was rerun.

**Finding: the displayed exact-once source invoice is correct for the actual finite shared law. It remains an identity, with the weighted geometric payment unproved.**

Fix b=8, let P_b be the union of original parents whose labels have at least one event by b, let Q_b^rep be the union of A_j+c0 s_j[-1,1]^n over labels having at least two events, and set S_b=Omega_b minus their union. Choose the true first covering key for each x in S_b, resolving simultaneous key completions by a fixed deterministic order. In that key choose a minimum-d label, resolving equal d by the latest original index. Denote the resulting disjoint spatial pieces by Z_i^b.

1. **Repeat pruning applies to every covering key.** If any key covering x contains label j with N_j(b)>=2, its region is contained in A_j+c0 s_h[-1,1]^n, and s_h<=s_j. Hence x lies in Q_b^rep, a contradiction. Thus every label in any key covering a point of S_b has global count exactly one on [0,b]. This conclusion does not merely say that the key itself has no repeated label.

2. **The source order really is available.** Original sources are ordered by descending radius. Choosing the latest index among all minimum-radius labels is equivalent to choosing the largest index of the key. Every other label is strictly earlier than i; after repeat pruning all these labels are distinct. This is a deterministic order statement and does not make those labels conditionally independent.

3. **The correct conditional density is exact-one Janossy density.** If the globally unique i event is at u in [0,b], its density is q_i exp(-b q_i) du. Other labels retain their original independent Poisson laws. In the integrand, force exactly this one i event and recompute S_b, all completed keys and representatives, the true first visibility and the deterministic minimum-source assignment. Then, exactly,

   E|S_b| = sum_i q_i exp(-b q_i) integral_0^b
                      E|Z_i^b(u;eta_{-i})| du.

   The factor exp(-b q_i) must not be replaced by exp(-u q_i) while removing all later i events. The latter density belongs to the different first-event conditioning in §3, where the later i process remains live. The current Z_i depends on the entire interval, including future repeat pruning and competing completed keys. The proof is ordinary nonnegative conditional integration over the finite Poisson configuration; it is not a predictable compensator argument. Shared representatives and simultaneous completions remain inside the conditional integrand.

4. **Admission gives a genuine but unconditional incoming-count bound.** For each accepted source,

   lambda_i = sum_{j<i} q_j 1_{c0 A_j}(y_i)
            <= sum_{j<i} w_j 1_{c0 A_j}(y_i) <= 1.

   This uses the actual original admission test at y_i and q_j<=w_j. Under the exact-one-i conditional law, the other processes are unmodified, so N_i^in(b) is Poisson(b lambda_i), stochastically at most Poisson(b). An assigned key therefore contains at least k-1-N_i^in(b) earlier labels j with y_i outside c0 A_j (the lower bound is trivially valid if negative). For each such j, ||y_i-y_j||_infinity>c0 s_j implies separation of A_j from B_i, since s_j/a>=s_i/a. No claim that all key labels are incoming is needed or valid.

   The incoming event count is NOT independent of the assigned key, its existence, or its volume. Selection may favor large counts and correlated spatial configurations. Its unconditional Poisson law does not license multiplying a selected-volume expectation by an independent Poisson tail.

5. **The residual's elementary envelope is still dimension dependent.** Every region charged to i lies in A_i+c0 s_i[-1,1]^n. Thus C_i^b<=b exp(-b q_i)(1+c0)^n is valid, but no absolute bound on sum_i |F_i| C_i^b follows from the identities and admission count alone. The desired conclusion may use an aggregate weighted coefficient bound; a bound on every C_i is stronger than necessary.

The author's deterministic slab diagnosis is geometrically consistent: the displayed common intersection is [-1,1] times [3/4,1] times [-1,1]^(n-2), the specified E is outside all displayed parents and lies in its radius-one expansion, and |E|/d_i=2^(n-2)-1/2. Distinct radii require n>1. This verifies only the failure of the proposed deterministic shortcut after mutual admission/high-load constraints are discarded. It is not an actual near-state counterexample and supplies no evidence against the original global target. The author explicitly retains that qualification.

One minor wording qualification in the author's coarse-tail paragraph: after pruning, `1+Poisson(b)` is a stochastic upper bound on the non-outward count, not its exact law. The exact background mean is b lambda_i, and a selected key can bias the observed count further. The author already states the relevant non-independence restriction, so this wording does not invalidate the source identity or the handoff.

Audit disposition: exact-once formula, order tie rule, admission inequality, and unselected incoming-count law PASS with the stated scope. Conditional source geometry and its weighted global payment remain OPEN. Only this S3 file was appended; the audited author file was not edited.
