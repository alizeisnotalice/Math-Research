"""Global marked first-k process; rational geometry delegated to geometry_kernel."""
from fractions import Fraction
from collections import defaultdict
import json, random, sys
from pathlib import Path


def fracstr(x):
    return str(x) if isinstance(x, Fraction) else x

def run(fixture, history, measure=None):
    cubes = {c['id']: c for c in fixture['cubes']}
    targets = fixture['targets']
    rows = {t['id']: t['row_id'] for t in targets}
    memberships = {t['id']: set(t['I']) for t in targets}
    prefixes = {t['id']: [] for t in targets}
    sources = {}
    completed = {}
    seen = set()
    previous_time = None
    ledger = []
    k = int(fixture['k'])
    if k < 1: raise ValueError('k must be positive')
    def groups_for(mapping):
        buckets = defaultdict(list)
        for target, key in mapping.items():
            if key: buckets[tuple(key)].append(target)
        result=[]
        for key, members in buckets.items():
            members.sort(key=lambda t: cubes[rows[t]]['order'])
            result.append({'event_ids': list(key), 'source_ids': [sources[e] for e in key],
                           'representative_row_id': rows[members[0]], 'members': members})
        return result
    def regions():
        return groups_for(completed), groups_for({t:p for t,p in prefixes.items() if t not in completed})
    volumes = {}
    def volume(groups):
        if not groups: return Fraction(0)
        # Only the geometric union is cached; event-key identity is never collapsed.
        key = tuple(sorted({(str(g['representative_row_id']),
                            tuple(sorted(set(map(str, g['source_ids'])))))
                            for g in groups}))
        if key not in volumes:
            volumes[key] = measure(fixture, groups)['W_union']
        return volumes[key]
    def state(omega, active):
        if measure is None: return None
        o, a, r = volume(omega), volume(active), volume(omega+active)
        return {'omega':o, 'active':a, 'R':r, 'P':r-o}
    for event in history:
        eid, src = event['event_id'], event['source_id']
        if eid in seen: raise ValueError('duplicate event_id')
        if src not in cubes or src not in fixture['q'] or Fraction(fixture['q'][src]) <= 0:
            raise ValueError('event source must have positive rate')
        now=event.get('time')
        if now is not None:
            now=Fraction(str(now))
            if previous_time is not None and now <= previous_time: raise ValueError('event times must increase')
            previous_time=now
        before_o,before_a=regions(); before=state(before_o,before_a)
        seen.add(eid); sources[eid]=src
        newly=[]
        for t in targets:
            tid=t['id']
            if tid not in completed and src in memberships[tid]:
                prefixes[tid].append(eid)
                if len(prefixes[tid]) == k:
                    completed[tid]=tuple(prefixes[tid]); newly.append(tid)
        after_o,after_a=regions(); after=state(after_o,after_a)
        item={'event_id':eid,'source_id':src,'time':event.get('time'),
              'new_groups':groups_for({t:completed[t] for t in newly}),
              'completed_groups':after_o,'active_groups':after_a}
        if measure is not None:
            combined=volume(before_o+before_a+after_o+after_a)
            delta=after['omega']-before['omega']
            B=combined-before['R']; D=combined-after['R']
            assert delta >= 0 and B >= 0 and D >= 0
            assert after['P']-before['P'] == B-D-delta
            item.update({'before':before,'after':after,'B':B,'D':D,'Delta':delta})
        ledger.append(item)
    return ledger

def poisson_history(fixture, seed, horizon=8, max_events=100000):
    """Direct superposition: one global exponential clock, then independent mark.

    Floating-point event times are simulation, never exact probability evidence.
    """
    ids=[i for i,q in fixture['q'].items() if Fraction(q)>0]
    rates=[float(Fraction(fixture['q'][i])) for i in ids]
    total=sum(rates); rng=random.Random(seed); t=0.; out=[]
    if not total: return out
    while True:
        t += rng.expovariate(total)
        if t > horizon: return out
        if len(out)>=max_events: raise RuntimeError('bounded event budget exceeded')
        u=rng.random()*total; cumulative=0.
        for i,r in zip(ids,rates):
            cumulative+=r
            if u<cumulative: break
        out.append({'event_id':f'e{len(out)+1}','source_id':i,'time':repr(t)})

def selftest():
    # Repeated source events retain their distinct event IDs.
    f={'k':2,'cubes':[{'id':i,'order':j} for j,i in enumerate('abcxy')],
       'q':{'a':'1','b':'1','c':'1'},'targets':[
           {'id':'x','row_id':'x','I':['a','b']},
           {'id':'y','row_id':'y','I':['a','c']}]}
    h=[{'event_id':'a1','source_id':'a'}, {'event_id':'b1','source_id':'b'},
       {'event_id':'a2','source_id':'a'}, {'event_id':'c1','source_id':'c'}]
    result=run(f,h)
    assert result[1]['new_groups'][0]['event_ids']==['a1','b1']
    assert result[2]['new_groups'][0]['event_ids']==['a1','a2']
    f2={'k':1,'cubes':[{'id':i,'order':j} for j,i in enumerate('axy')],
        'q':{'a':'1'},'targets':[{'id':'x','row_id':'x','I':['a']}, {'id':'y','row_id':'y','I':['a']}]}
    assert run(f2,[{'event_id':'a1','source_id':'a'}])[0]['new_groups'][0]['members']==['x','y']
    # Different event identities can produce exactly the same geometric region.
    from geometry_kernel import measure
    fg={'n':1,'k':1,'cubes':[{'id':i,'order':j,'y':['0'],'s':'1'}
       for j,i in enumerate(['a','b','x','y'])],
       'q':{'a':'1/10','b':'1/10','x':'0','y':'0'},
       'targets':[{'id':'x','row_id':'x','I':['a']}, {'id':'y','row_id':'y','I':['b']}]}
    lg=run(fg,[{'event_id':'a1','source_id':'a','time':'1'},
               {'event_id':'b1','source_id':'b','time':'2'}],measure)
    assert lg[0]['new_groups'][0]['event_ids']==['a1']
    assert lg[1]['new_groups'][0]['event_ids']==['b1']
    assert lg[1]['Delta']==0 and len(lg[1]['completed_groups'])==2
    assert poisson_history(f,17)==poisson_history(f,17)
    print('process deterministic tests passed')

def run_fixtures(input_path, output_path):
    from geometry_kernel import measure
    data=json.loads(Path(input_path).read_text())
    assert data['run_budget']['stochastic_runs'] == 0
    result={'qualification':'diagnostic-only; original near/admission/actual-q not established',
            'probability_evidence':'none; deterministic exact event tapes', 'fixtures':[]}
    for f in data['fixtures']:
        tape=f['history']+[f['proposed_event']]
        ledger=run(f,tape,measure)
        for time, expected in f['expected']['completed_keys_by_time'].items():
            actual=next(x['new_groups'] for x in ledger if x['time']==time)
            normalized=[{'key':g['event_ids'],'representative':g['representative_row_id'],
                         'members':g['members']} for g in actual]
            assert normalized == expected, (f['id'], time, normalized, expected)
        last=ledger[-2]
        assert last['after']['omega']==Fraction(f['expected']['W_union_final'])
        assert measure(f,last['completed_groups'])['W_sum']==Fraction(f['expected']['W_sum_final'])
        assert ledger[-1]['Delta']==Fraction(f['expected']['proposed_delta'])
        if 'delta_at_t3' in f['expected']:
            assert last['Delta']==Fraction(f['expected']['delta_at_t3'])
        U=sum(Fraction(c['s'])**int(f['n'])*2**int(f['n'])*Fraction(f['q'][c['id']]) for c in f['cubes'])
        assert U==Fraction(f['expected']['U_diagnostic'])
        item={'id':f['id'],'horizon':8,'U_diagnostic':U,'ledger':ledger}
        if 'event_id_replay' in f:
            renames=f['event_id_replay']['replace_event_ids']
            renamed=[dict(e,event_id=renames.get(e['event_id'],e['event_id'])) for e in tape]
            replay=run(f,renamed,measure)
            for x,y in zip(ledger,replay):
                assert all(x[z]==y[z] for z in ['before','after','B','D','Delta'])
                assert [[g['representative_row_id'],g['members']] for g in x['completed_groups']]==[[g['representative_row_id'],g['members']] for g in y['completed_groups']]
            assert all(x['event_ids'] != y['event_ids'] for x,y in zip(ledger[-2]['completed_groups'],replay[-2]['completed_groups']))
            item['event_id_rename_replay']={'passed':True,'renames':renames}
        result['fixtures'].append(item)
    Path(output_path).write_text(json.dumps(result,default=fracstr,indent=2,ensure_ascii=False)+'\n')
    print('fixture exact accounting passed:',len(result['fixtures']))

if __name__=='__main__':
    if sys.argv[1:] == ['--selftest']: selftest()
    elif len(sys.argv)==4 and sys.argv[1]=='--fixture': run_fixtures(sys.argv[2],sys.argv[3])
    else: raise SystemExit('use --selftest or --fixture INPUT OUTPUT')
