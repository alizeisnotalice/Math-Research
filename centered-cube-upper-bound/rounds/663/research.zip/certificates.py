"""R663: exact minimum-volume winner certificate, 2026-11-15."""
from fractions import Fraction as F
from itertools import product
from math import prod

p = (F(1, 2), F(1, 3), F(1, 6))
d = (1, 1, 4)
k = 3
winners = [F(0) for _ in p]
for sample in product(range(len(p)), repeat=k):
    weight = prod(p[i] for i in sample)
    minimum = min(d[i] for i in sample)
    winner = next(i for i in sample if d[i] == minimum)
    winners[winner] += weight
formula = []
for i in range(len(p)):
    lower = sum((p[j] for j in range(len(p)) if d[j] < d[i]), F(0))
    equal = sum((p[j] for j in range(len(p)) if d[j] == d[i]), F(0))
    formula.append(p[i] / equal * ((1-lower)**k - (1-lower-equal)**k))
expected = [F(43,72), F(43,108), F(1,216)]
assert winners == formula == expected and sum(winners) == 1
print('samples =', len(p)**k)
print('enumerated =', ', '.join(map(str, winners)))
print('formula =', ', '.join(map(str, formula)))
print('sum =', sum(winners))

# Independent 256-bit Arb enclosures for the two stated numerical claims.
from flint import arb, ctx
ctx.prec = 256
A = arb
n = 2**80
tau = 2**54
m = tau - 1
E = A(n)*(A(2)+A(1)/(32*A(n))).log()-A(m)*((A(m)/9).log()-1)-9
assert E > 0
c256 = 32*((A(64)*256+1)/(A(1024)*256**2))**256
assert c256 < A(10)**(-900)
print('Arb bits:', ctx.prec)
print('E:', E)
print('c256:', c256)
print('log10(c256):', c256.log()/A(10).log())
# Exact monotone upper bound at and above n=256.
base256 = F(64*256+1, 1024*256**2)
assert base256 < F(1,4000) and 4000**5 > 10**18
# Thus 32 * base(n)^n <= 32/4000^256 < 10^-916 < 10^-900.
assert 32*10**916 < 4000**256
# log(2) = 2*atanh(1/3); tail <= 2*x^(2N+1)/((2N+1)*(1-x^2)).
x=F(1,3); N=3
partial=2*sum((x**(2*j+1)/F(2*j+1) for j in range(N)), F(0))
tail=2*x**(2*N+1)/(F(2*N+1)*(1-x*x))
assert partial + tail < F(3,4)
print('log2 rational upper:', partial+tail, '< 3/4')

# Independent exact cell decomposition of the deterministic fixture ledger.
import json
from collections import defaultdict
with open('geometry_fixture.json') as f: fixtures=json.load(f)['fixtures']
with open('PROCESS_RESULTS.json') as f: reported=json.load(f)['fixtures']

def fixture_check(fix, report):
    cubes={c['id']:c for c in fix['cubes']}; n=fix['n']; k=fix['k']; c0=F(fix['c0'])
    q={i:F(v) for i,v in fix['q'].items()}
    for c in cubes.values():
        c['yy']=tuple(map(F,c['y'])); c['ss']=F(c['s'])
    tape=fix['history']+[fix['proposed_event']]
    def groups(events):
        g=defaultdict(list)
        for target in fix['targets']:
            key=tuple(e['event_id'] for e in events if e['source_id'] in target['I'])[:k]
            if key: g[key].append(target)
        out=[]
        lookup={e['event_id']:e['source_id'] for e in events}
        for ids,members in g.items():
            rep=min((cubes[t['row_id']] for t in members),key=lambda c:c['order'])
            src=tuple(lookup[i] for i in ids)
            lo=tuple(max(cubes[i]['yy'][j]-cubes[i]['ss'] for i in src)-c0*rep['ss'] for j in range(n))
            hi=tuple(min(cubes[i]['yy'][j]+cubes[i]['ss'] for i in src)+c0*rep['ss'] for j in range(n))
            # Verify intersections before Minkowski enlargement.
            if any(max(cubes[i]['yy'][j]-cubes[i]['ss'] for i in src) > min(cubes[i]['yy'][j]+cubes[i]['ss'] for i in src) for j in range(n)):
                continue
            out.append((ids,src,rep,tuple(t['id'] for t in members),lo,hi))
        return out
    snapshots=[groups(tape[:i]) for i in range(len(tape)+1)]
    edges=[set() for _ in range(n)]
    for c in cubes.values():
        for j in range(n): edges[j].update((c['yy'][j]-c['ss'],c['yy'][j]+c['ss']))
    for snap in snapshots:
        for _,_,_,_,lo,hi in snap:
            for j in range(n): edges[j].update((lo[j],hi[j]))
    intervals=[]
    for e in edges:
        v=sorted(e); intervals.append([((a+b)/2,b-a) for a,b in zip(v,v[1:]) if a<b])
    states=[{'omega':F(0),'active':F(0),'R':F(0),'P':F(0)} for _ in snapshots]
    changes=[{'B':F(0),'D':F(0),'Delta':F(0)} for _ in tape]
    def inside(p,c): return all(abs(p[j]-c['yy'][j]) < c['ss'] for j in range(n))
    for cell in product(*intervals):
        pt=tuple(x[0] for x in cell); vol=prod(x[1] for x in cell)
        memberships=[]
        for snap in snapshots:
            active=omega=False
            for ids,src,rep,members,lo,hi in snap:
                if all(lo[j]<pt[j]<hi[j] for j in range(n)) and sum((q[c['id']] for c in cubes.values() if c['order']<rep['order'] and inside(pt,c)),F(0))<=1:
                    if len(ids)==k: omega=True
                    else: active=True
            R=omega or active; P=active and not omega
            memberships.append((omega,active,R,P))
        for i,values in enumerate(memberships):
            for name,flag in zip(('omega','active','R','P'),values):
                if flag: states[i][name]+=vol
        for i,(old,new) in enumerate(zip(memberships,memberships[1:])):
            if new[2] and not old[2]: changes[i]['B']+=vol
            if old[2] and not new[2]: changes[i]['D']+=vol
            if new[0] and not old[0]: changes[i]['Delta']+=vol
            assert not old[0] or new[0]
    for i,row in enumerate(report['ledger']):
        assert row['event_id']==tape[i]['event_id']
        for phase,s in [('before',states[i]),('after',states[i+1])]:
            assert {name:F(val) for name,val in row[phase].items()}==s, (fix['id'],i,phase,s)
        assert {name:F(row[name]) for name in ('B','D','Delta')}==changes[i]
        assert states[i+1]['P']-states[i]['P']==changes[i]['B']-changes[i]['D']-changes[i]['Delta']
        snap=snapshots[i+1]
        for label,filter_ in [('active_groups',lambda x:len(x[0])<k),('completed_groups',lambda x:len(x[0])==k)]:
            actual={(g[0],g[1],g[2]['id'],g[3]) for g in snap if filter_(g)}
            claimed={(tuple(g['event_ids']),tuple(g['source_ids']),g['representative_row_id'],tuple(g['members'])) for g in row[label]}
            assert actual==claimed, (fix['id'],i,label,actual,claimed)
    print('exact cells:',fix['id'],'events:',len(tape),'cells:',prod(map(len,intervals)),'all ledger entries verified')
for fix,rep in zip(fixtures,reported): fixture_check(fix,rep)
# Replay with renamed event IDs; same geometric ledger, renamed keys.
import copy
renamed=copy.deepcopy(fixtures[1]); expected=copy.deepcopy(reported[1])
rename=renamed['event_id_replay']['replace_event_ids']
for ev in renamed['history']+[renamed['proposed_event']]: ev['event_id']=rename.get(ev['event_id'],ev['event_id'])
for row in expected['ledger']:
    row['event_id']=rename.get(row['event_id'],row['event_id'])
    for field in ('new_groups','completed_groups','active_groups'):
        for g in row[field]: g['event_ids']=[rename.get(i,i) for i in g['event_ids']]
fixture_check(renamed,expected)
print('event-ID rename replay verified')
# Closed touching intervals A=[-1,1], B=[1,3]: intersection {1},
# then expansion by [-1,1] gives [0,2], a region of length 2.
tangent={'id':'closed_touching_intervals','n':1,'c0':'1','k':2,
 'cubes':[{'id':'A','order':1,'y':['0'],'s':'1'},
          {'id':'B','order':2,'y':['2'],'s':'1'},
          {'id':'T','order':3,'y':['1'],'s':'1'}],
 'q':{'A':'1','B':'1','T':'0'},
 'targets':[{'id':'target','row_id':'T','I':['A','B']}],
 'history':[{'event_id':'a','source_id':'A'}],
 'proposed_event':{'event_id':'b','source_id':'B'}}
first={'event_ids':['a'],'source_ids':['A'],'representative_row_id':'T','members':['target']}
second={'event_ids':['a','b'],'source_ids':['A','B'],'representative_row_id':'T','members':['target']}
z={'omega':'0','active':'0','R':'0','P':'0'}
u={'omega':'0','active':'4','R':'4','P':'4'}
v={'omega':'2','active':'0','R':'2','P':'0'}
tangent_report={'ledger':[
 {'event_id':'a','before':z,'after':u,'B':'4','D':'0','Delta':'0','active_groups':[first],'completed_groups':[]},
 {'event_id':'b','before':u,'after':v,'B':'0','D':'2','Delta':'2','active_groups':[],'completed_groups':[second]}]}
fixture_check(tangent,tangent_report)
print('closed touching intersection: enlarged volume = 2')
