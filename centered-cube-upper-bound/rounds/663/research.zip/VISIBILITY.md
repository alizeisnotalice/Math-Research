# R663 spatial visibility: paid source interior and the exact exterior defect

**Status.** A genuine full-family source-interior payment and explicit negative overlap formulas are proved below. No absolute bound for the remaining exterior is proved. In particular this note does **not** prove A3, replace the union by a key sum, or count a new name for the remaining cost as progress on the dimensional constant. The parent's finite-window reduction is used with the same process and horizon 8.

## Key formula

Write
\[
 P_t=\bigcup_{e:\,t_e\le t}A_{i_e},\qquad
 R_t=\Omega_t\setminus P_t,\qquad
 f(x)=\sum_iq_i1_{A_i}(x),\qquad \int f=U.
\]
Here every marked source event up to time t is included in P_t, whether or not it completes a key. For an insertion of label i into the actual history just before t, retain the original simultaneous-key union increment \(\Delta_i\). Then
\[
\boxed{
 \mathbb E|\Omega_8|
 \le 8U+
 \sum_iq_i\int_0^8\mathbb E
       |\Delta_i\setminus(P_{t-}\cup A_i)|\,dt
 -\int_0^8\mathbb E\int_{R_{t-}} f(x)\,dx\,dt .
}                                                    \tag{V1}
\]
The last term is an actual negative overlap recovery: a newly marked original parent cube swallows exterior coverage created earlier, across all keys at once. The birth term already subtracts both the entire old coverage and the entire marked-parent union. It does not sum new keys separately.

The independently paid part is
\[
 \mathbb E|\Omega_8\cap P_8|
 \le \mathbb E|P_8|
 =\int(1-e^{-8f(x)})\,dx\le8U.                     \tag{V2}
\]
Thus the unresolved spatial part consists only of points which are in a completed halo but in **none** of the marked original parent cubes, including marked sources outside that key.

## Proof of V1 and V2

Fix an actual pre-arrival history. Put \(P=P_{t-}\), \(\Omega=\Omega_{t-}\), and let N be the union of all key regions newly completed by the proposed event. Thus \(\Delta_i=N\setminus\Omega\). After the event,
\[
 P'=P\cup A_i,\quad \Omega'=\Omega\cup N,\quad
 R'=\Omega'\setminus P'.
\]
The two disjoint changes in R are precisely
\[
 R'\setminus R=\Delta_i\setminus(P\cup A_i),\qquad
 R\setminus R'=R\cap A_i.
\]
Consequently the pathwise signed increment is
\[
 |R'|-|R|
 =|\Delta_i\setminus(P\cup A_i)|-|R\cap A_i|.       \tag{V3}
\]
This includes events completing no key: their first term is zero, but they may still remove old exterior. Applying the already available finite-horizon compensation argument separately to these nonnegative birth and removal terms gives
\[
 \mathbb E|R_8|
 =\sum_iq_i\int_0^8\mathbb E
 |\Delta_i\setminus(P_{t-}\cup A_i)|\,dt
 -\int_0^8\mathbb E\int_{R_{t-}}f(x)\,dx\,dt.       \tag{V4}
\]
All sums, source supports and halo envelopes are finite, so the two integrals are finite; no subtraction of infinities is involved. For a fixed x, no source containing x is marked by time 8 with probability \(e^{-8f(x)}\). This proves V2 by Tonelli. Finally use \(|\Omega_8|=|\Omega_8\cap P_8|+|R_8|\).

One may replace 8U in V1 by the smaller deterministic integral \(\int(1-e^{-8f})\). Nothing here alters the original q, F_i, losses, keys, representatives, or L_h.

## Terminal reordering removes an unnecessary restriction mismatch

For each actual target h whose own key is completed by time 8, let
\[
 S_h=\{\text{distinct source labels among its first k marked events}\},
 \quad \delta_h=c_0s_h,\quad
 H_h=\bigcap_{a\in S_h}(A_a+\delta_h[-1,1]^n),
 \quad D_h=H_h\cap L_h.
\]
Each key has the actual common witness z_h. Hence its unexpanded intersection is nonempty, and for these axis-aligned boxes
\[
 H_h=\left(\bigcap_{a\in S_h}A_a\right)+\delta_h[-1,1]^n.
\]
This equality uses nonemptiness; it is not asserted for an arbitrary empty intersection of boxes.

If h and j share a key and h<j, then \(s_h\ge s_j\), \(L_h\supseteq L_j\), and therefore \(D_h\supseteq D_j\). All members sharing that completed key are already completed at its completion time. It follows that
\[
 \Omega_8=\bigcup_{h:\,N_{I_h}(8)\ge k}D_h.          \tag{V5}
\]
This is exactly the original representative union. It can be revealed in increasing **target order** after the whole history up to 8 is fixed. This rearrangement makes no independence claim about selected halos and discards no event times in an expectation formula.

Let \(\mathcal C\) denote the completed targets and, for h in \(\mathcal C\), let
\[
 E_h=D_h\setminus\bigcup_{g<h,\,g\in\mathcal C}D_g.
\]
The E_h are disjoint and have union \(\Omega_8\). Because \(L_h\subseteq L_g\) for g<h, on D_h one has \(x\in D_g\iff x\in H_g\). Thus the terminal increment has no unfavorable \(L_h\setminus L_g\) term.

## Explicit cross-key negative overlap and face strips

For every completed g<h,
\[
 |E_h|\le |D_h|-|D_h\cap H_g|,                       \tag{V6}
\]
and, retaining only the genuinely unpaid exterior,
\[
 |E_h\setminus P_8|
 \le |D_h\setminus P_8|-|D_h\cap H_g\setminus P_8|.  \tag{V7}
\]
The overlap term is geometrically explicit. Write
\[
 H_h=\prod_m[\alpha_{hm},\beta_{hm}],\quad
 \alpha_{hm}=\max_{a\in S_h}(y_{am}-s_a)-\delta_h,
 \quad \beta_{hm}=\min_{a\in S_h}(y_{am}+s_a)+\delta_h.
\]
Then
\[
 D_h\cap H_g=L_h\cap
 \prod_m[\max(\alpha_{hm},\alpha_{gm}),
          \min(\beta_{hm},\beta_{gm})],              \tag{V8}
\]
with the product empty when a lower endpoint exceeds its upper endpoint. The L_h restriction cannot be dropped from a lower bound on this negative overlap.

More specifically, all shared-label constraints are automatically satisfied: \(\delta_g\ge\delta_h\), so \(H_h\subseteq A_a+\delta_g[-1,1]^n\) for each \(a\in S_g\cap S_h\). Therefore
\[
 D_h\setminus D_g
 =D_h\cap\bigcup_{a\in S_g\setminus S_h}
                  (A_a+\delta_g[-1,1]^n)^c.         \tag{V9}
\]
If \(S_g\subseteq S_h\), this gives E_h empty, even when the marked keys are distinct. For a general old key, only its old-only source faces can expose new area. In coordinates each complement in V9 is the union of the 2n half-space strips
\[
 \{x_m<y_{am}-s_a-\delta_g\}\quad\text{and}\quad
 \{x_m>y_{am}+s_a+\delta_g\},\qquad 1\le m\le n.
\]
Keeping **all** previous completed keys, rather than choosing a single predecessor, gives the exact simultaneous escape condition
\[
 E_h\setminus P_8
 =D_h\cap P_8^c\cap
  \bigcap_{g<h,\,g\in\mathcal C}
  \bigcup_{a\in S_g\setminus S_h}
             (A_a+\delta_g[-1,1]^n)^c.              \tag{V10}
\]
The empty outer intersection is the entire space; an empty inner union is empty. V6--V10 retain the actual cross-key spatial intersections and every source label. They do not assume a bounded number of targets per source.

## What remains unpaid, exactly

The nonnegative birth term in V1 is not controlled by the available one-group intersection moment. It is selected jointly by the whole actual Poisson history, the newly completed target collection, prior coverage, and the marked-parent union. No factorization into an unconditional halo moment and a selection probability has been established.

V10 shows the geometric issue without hiding it in a key-volume sum: a still-visible exterior point must evade an old-only expanded source face for **every** previous completed target. No full-family estimate has been obtained for these simultaneous face-escape sets. Merely reusing a source label eliminates shared constraints in V9; it does not establish a positive lower bound on the overlap in V7.

The negative removal term in V1 pays at rate f(x) on old exterior. The known restrictions are upper-load restrictions, and they provide no established positive lower bound on f at newly exposed exterior points. In particular this argument supplies no payment where the exterior lies outside the deterministic union of all original parent cubes, for which f=0. This observation is a limitation of the proposed potential, not a constructed counterexample to the actual model or A3.

Thus V1 genuinely pays the complete marked-parent interior at cost at most 8U and records a signed geometric recovery. The remaining task is still to control the exterior births after their actual removal. Neither V1 nor V10 provides that control; no bound \(\mathbb E|\Omega_8|\le A U\) follows here. This is the stopping point of the assigned bounded visibility investigation.

## Exact local verification

The proof above is by sets, not by computation. As a sign check for V3, local Python 3.15.0 exhaustively checked all 4096 quadruples (Omega,P,A,N) of subsets of a three-point universe; every case passed. This specifically checks arbitrary simultaneous-new-region unions N and arrivals with N empty. No Monte Carlo, incidence-model counterexample, or numerical estimate of A3 was used.

Reproducible check (executed through stdin to respect sole-file ownership):

```python
from itertools import product
universe = set(range(3))
subsets = [{j for j in universe if mask & (1 << j)}
           for mask in range(8)]
checks = 0
for omega, p, a, new in product(subsets, repeat=4):
    old_r = omega - p
    new_r = (omega | new) - (p | a)
    birth = new - (omega | p | a)
    killed = old_r & a
    assert len(new_r) - len(old_r) == len(birth) - len(killed)
    checks += 1
print(checks)  # actual output: 4096
```
