# Deterministic horizon 8: exact absorption and its remaining budget

Author: Sol S1. Scope: the frozen actual R663 state and its one shared global first-key Poisson process only. Read TASK.md and R662 REPORT §§2,4; the R662 finite-Poisson compensation identities are reused. No general estimate for E|Ω8| is established here. This file is the sole authored artifact.

## 1. The ceiling causes no loss in the completion estimate

Fix a near row j. Put τ=16384√n, k=ceil(2τ), Tj∈(τ/2,τ], and let Nj(t) count all global marked events whose source label lies in Ij. Repetitions of a source label count separately. Superposition gives Nj(8)∼Poisson(8Tj). Its first key has not completed by 8 exactly when Nj(8)<k. Since Nj(8) is integer,

    Nj(8)<ceil(2τ)  ⇔  Nj(8)≤ceil(2τ)−1<2τ.

For s=log 2, the exponential Markov inequality gives

    P(Nj(8)<k)
      ≤ exp(2τs) E exp(−s Nj(8))
      = exp(2τ log 2−4Tj)
      ≤ exp(−(2−2 log 2)τ)
      ≤ exp(−τ/2) ≤ ετ,        ετ:=exp(−τ/4).

Here log 2<3/4 follows, for example, from e^(3/4)>1+3/4+(3/4)^2/2=65/32>2. This proves all constants for every τ>0 in the stated load range; it requires no asymptotic approximation or removal of the ceiling. The first inequality may use a non-strict upper event, so there is no concern about strict versus non-strict Markov inequalities.

## 2. Actual disjoint losses absorb the unfinished part

Let Jnear denote the deterministic near rows, Xj=Ej\Fj their true loss pieces, and Vnear=Σj∈Jnear |Xj|. They are pairwise disjoint because the full owners Ej are disjoint. Define the unfinished actual loss

    R8 = ⋃{Xj : j∈Jnear, Nj(8)<k}.

For each realization, every completed loss Xj is contained in its completed group region, hence in Ω8. The shared key law does not require any independence between the completion indicators. Disjointness gives the exact identity

    |R8|=Σj∈Jnear |Xj| 1{Nj(8)<k},
    E|R8|≤ετ Vnear,
    Vnear≤|Ω8|+|R8|.

Consequently

    (1−ετ)Vnear≤E|Ω8|,
    Vnear≤E|Ω8|/(1−ετ).                         (FH-absorb)

This is a finite-horizon reduction of the same original union problem. It supplies no bound for E|Ω8| in terms of U. It would also suffice to bound the completed actual-loss union, but Ω8 is the frozen process being retained.

## 3. Complete original cost recovery

Write Cadm=1+exp(1/16), Kfar=2exp(33/32), U=Σi di qi, and P0≥U/τ. The previously proved whole-family account is

    V0≤Cadm[U+Kfar U/τ+Vnear].

For U>0, (FH-absorb) therefore gives the exact conditional bound

    V0/P0≤Cadm[τ+Kfar+τ E|Ω8|/((1−ετ)U)].      (FH-account)

If a new estimate E|Ω8|≤A U with absolute A is proved for every actual finite state, then

    V0/P0≤Cadm[τ(1+A/(1−ετ))+Kfar].

Using τ=16384√n, n≥1 and (1−ετ)^−1≤2, the finite recovery Cn≤sup V0/P0 gives

    Cn≤Cadm[16384(1+2A)+Kfar]√n.

Keeping the exact denominator is sharper. For n<256 the already proved empty-near branch needs no random budget and yields V0/P0≤Cadm(τ+Kfar). If U=0, the frozen account and far bound imply V0≤Cadm Vnear, while the near source sets cannot have Tj>τ/2; hence Vnear=0 and V0=0. There is then no division by U. These deductions are conditional on the stated new AU estimate; that estimate is not proved here.

## 4. Source marked-volume expectation, and all jump bookkeeping

For every positive source qi, give each label-i arrival deterministic volume charge

    di=|Fi|/qi=(2si)^n.

The total marked source charge through time 8 is

    M8=Σi:qi>0 di Ni(8),      E M8=8Σi qi di=8U.             (FH-source)

No positive source is omitted. This charge is di per arrival. Charging only |Fi| per arrival would have expectation 8Σi qi|Fi|, generally a different quantity. Repeated labels are charged on every arrival; these are charges of marked events, not the volume of the set union of the repeatedly selected Fi.

Let Δi(history<t) be the frozen increment: the union of ALL new key regions completed upon insertion of one label-i event, minus Ωt−. As k≥1, Ω0=∅ almost surely and there is no initial region charge. Distinct global events have distinct times almost surely, but a single arrival may complete several keys. Their new regions must be unioned before taking volume. The finite-horizon compensation identity already audited in R662 yields

    E|Ω8|=Σi qi ∫0^8 E|Δi(history<t)|dt.                    (FH-drift)

All possible regions lie in the fixed bounded envelope of this finite input, and the total source rate is finite. Thus Ω8 is integrable. The deterministic endpoint contributes no jump almost surely. At 8 the process simply stops: no key is forcibly completed and no remaining group region is added for free. The remaining actual loss is settled only by (FH-absorb). There is no terminal Ω∞ limit in this reduction.

For example, either a proved pathwise charge |Ω8|≤B M8, or a proved integrated expected charge E|Ω8|≤B E M8, would give E|Ω8|≤8B U. A sufficient stronger drift condition is Σi qi E|Δi(history<t)|≤B U for almost every t∈[0,8]; this also gives E|Ω8|≤8B U. None is inferred from (FH-source) or (FH-drift). Under such a new B-budget, the original account would be

    V0/P0≤Cadm[τ(1+8B/(1−ετ))+Kfar],
    Cn≤Cadm[16384(1+16B)+Kfar]√n.

The absence of a proven comparison between coverage increments and the source charge is precisely the remaining global obstruction.

## 5. Exact truncated representative factor

For a fixed candidate representative h and an ordered label tuple v=(i1,…,ik) wholly in Ih, retain

    φh(v)=|(⋂ℓ Aiℓ+c0 sh[−1,1]^n)∩Lh|.

Let Ch(v) be the finite set of earlier targets ℓ<h compatible with v, meaning every entry of v belongs to Iℓ. For ℓ∈Ch(v), put Bℓh=Iℓ\Ih. With independent Poisson background processes only on labels outside Ih, define the joint kill probability

    ph(v,t)=P[ηt(Bℓh)>0 for every ℓ∈Ch(v)].

The probability is 1 for an empty list of conditions and is 0 if one required Bℓh is empty. These joint hit events generally are dependent. The outside background is independent of the Ih processes; its law remains unchanged conditional on the Ih key and its completion time. For the first k events of Ih, the ordered label tuple is iid with weights qi/Th and independent of its completion time th∼Gamma(shape k, rate Th). Therefore the correct truncated factor is

    ρh^8(v)=∫0^8 [Th^k t^(k−1)e^(−Th t)/(k−1)!] ph(v,t)dt.

It includes both completion by time 8 and survival as the earliest representative. It is not the probability of the latter event under an arbitrarily reselected tuple law. If WΣ,8 is the sum of regions of completed groups, then

    E WΣ,8=Σh E(v iid qi/Th)[φh(v)ρh^8(v)],
    E|Ω8|≤E WΣ,8.

This is the R662 marked-Poisson formula with the same completion-time integral restricted to [0,8]. All key group members already exist at their shared completion time, so there is no later change of representative. The sum formula counts distinct completed groups exactly once. It may overpay their overlaps and is not required to be the route to the union bound.

Define Fk,r(t)=P(Gamma(k,rate r)≤t)=P(Poisson(rt)≥k). For every fixed tuple,

    0≤ρh^8(v)≤Fk,Th(8)≤1,
    ρh^8(v)≤ρh(v),
    0≤ρh(v)−ρh^8(v)≤1−Fk,Th(8)≤ετ.

Only the gamma CDF, not ρh^8 itself, has the lower bound 1−ετ. Since ph(v,t) is nondecreasing in t, there is also the valid sharper upper bound

    ρh^8(v)≤Fk,Th(8) ph(v,8).

For an entirely explicit finite expression, for S⊂Ch(v) let

    bS=Σi∈⋃ℓ∈S Bℓh qi,       b∅=0.

Inclusion–exclusion of the joint kill events, with no independence assertion between them, gives

    ph(v,t)=ΣS⊂Ch(v) (−1)^|S| e^(−bS t),
    ρh^8(v)=ΣS⊂Ch(v) (−1)^|S|
                 [Th/(Th+bS)]^k Fk,Th+bS(8).

The analogous untruncated formula replaces every F by 1. These are exact finite identities even with empty or coincident kill sets; their alternating signs must not be bounded term by term as positive terms.

Finally, for n≥256 the already proved local iid estimate and the tuple-independent CDF bound imply

    E|Ω8|≤Σh Fk,Th(8) Uh exp(100n/k−Th/8)
           ≤exp(−τ/32)Σh Uh.

This still repeats source masses across h. Truncation alone does not repair that repetition, cannot justify E(φρ)=Eφ Eρ, and does not imply a general AU union budget.

## 6. Small actual computation and reproduction

The proof above is analytic. The following bounded local Python check retains exact ceilings at an integral and a nonintegral τ, checks the Poisson mgf algebra, and checks the sole scalar logarithm constant with 128-bit Arb. There is no parameter scan or simulation. It is embedded here so this remains the single owned artifact.

```python
# BEGIN_FINITE_HORIZON_CHECK
import sys
import sympy as sp
from flint import arb, ctx
ctx.prec = 128
tau, T = sp.symbols('tau T', positive=True)
s = sp.log(2)
exponent = sp.simplify(2*tau*s + 8*T*(sp.exp(-s)-1))
assert sp.simplify(exponent-(2*tau*sp.log(2)-4*T)) == 0
for n in [sp.Integer(1), sp.Integer(2)]:
    v = 16384*sp.sqrt(n)
    k = sp.ceiling(2*v)
    assert bool(k-1 < 2*v)
    print('ceiling check:', 'n=', n, 'k=', k, 'k-1<2tau=', True)
margin = 2-2*arb(2).log()-arb(1)/2
assert margin > 0
print('Chernoff coefficient minus 1/2:', margin)
print('mgf exponent:', exponent)
print('Python:', sys.version.split()[0], 'SymPy:', sp.__version__)
# END_FINITE_HORIZON_CHECK
```

Reproduction command (no extra authored file):

```sh
/Users/zzh/.local/share/math-research-tools/venv/bin/python -c 'from pathlib import Path; s=Path("/Volumes/data/CodexTemp/centered-cube-r663-20261115/FINITE_HORIZON.md").read_text(); exec(s.split("# BEGIN_FINITE_HORIZON_CHECK",1)[1].split("# END_FINITE_HORIZON_CHECK",1)[0])'
```

Actual output is recorded below after execution.

Execution succeeded (exit 0) in the existing dedicated mathematics environment:

```text
ceiling check: n= 1 k= 32768 k-1<2tau= True
ceiling check: n= 2 k= 46341 k-1<2tau= True
Chernoff coefficient minus 1/2: [0.11370563888010938116553575708364686385 +/- 7.11e-39]
mgf exponent: -4*T + 2*tau*log(2)
Python: 3.12.14 SymPy: 1.14.0
```

The two ceiling inputs are finite checks only; the integer identity in §1 proves all τ. Arb certifies the displayed strict numerical margin; the elementary exponential-series inequality in §1 also proves its sign without computation. No global union bound is inferred from these checks.
