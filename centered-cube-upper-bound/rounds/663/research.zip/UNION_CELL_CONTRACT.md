# R663 exact union-cell contract

Owner: Sol S6 (`r663_union_cells`). This file specifies the geometry and qualification contract; Terra owns implementation. Other authors' files are not edited here. Applicable skills: `math-research`, `python-math` for the exact arithmetic check below.

## 1. Scope and decisive formulas

For a fixed finite actual cube family and a fixed shared marked-event history, the following is an exact finite computation, not a proof of a uniform estimate on its expectation. A geometry-only diagnostic may use unqualified targets, but must report that status.

Write `a=32*n`, `c0=1+1/a`, `A_i=prod_r[y_ir-s_i,y_ir+s_i]`, and `B_i=prod_r[y_ir-s_i/a,y_ir+s_i/a]`. Indices always refer to the original radius-descending order, with an explicit deterministic order for equal radii. Let

`p_h(C)=sum_{i: order(i)<order(h)} q_i * 1_{A_i}(C)`.

A completed key `K` is an ordered list of **global event identities**, not merely of labels. Its representative `h(K)` is the earliest target in that key group. Set

`J_K = intersection_{event e in K} A_source(e)`;

`R_K = J_K + c0*s_h*[-1,1]^n`;

`D_K = R_K intersect {p_h<=1}`.

If `ell_r=max_{e in K}(y_source(e),r-s_source(e))` and `u_r=min_{e in K}(y_source(e),r+s_source(e))`, then `J_K` is empty iff **some `ell_r>u_r`**. Otherwise `R_K=prod_r[ell_r-c0*s_h,u_r+c0*s_h]`. In particular a degenerate closed intersection with `ell_r=u_r` must not be discarded before Minkowski enlargement: it may enlarge to a set of positive volume. Distinct event keys with equal label lists or equal geometric boxes remain distinct groups for `W_sum`.

For old completed groups `G_old` and the groups `G_new` completed at one inserted event,

`old(C)=any_{K in G_old}(C subset R_K and p_h(K)(C)<=1)`;

`new(C)=any_{K in G_new}(C subset R_K and p_h(K)(C)<=1)`.

All containment tests here are on cell interiors / an interior midpoint. Then

`W_union_before = sum_C vol(C)*old(C)`;

`W_union_after  = sum_C vol(C)*(old(C) or new(C))`;

`W_sum_before   = sum_C vol(C)*sum_{K in G_old}1_{D_K}(C)`;

`W_sum_after    = W_sum_before + sum_C vol(C)*sum_{K in G_new}1_{D_K}(C)`;

`new_union_volume = sum_C vol(C)*new(C)`;

`increment_volume = sum_C vol(C)*(not old(C))*new(C)`.

Thus `increment_volume=W_union_after-W_union_before`. A sum of new individual group volumes is generally neither `new_union_volume` nor the increment.

## 2. Rational JSON input

Version name: `r663-union-cell-v1`. All exact rationals are canonical strings `"p/q"` with coprime integers and positive denominator; integer strings such as `"0"` may be accepted and normalized. Floats do not qualify as exact input. IDs are unique strings; `order` and `k` are integers. Source IDs refer to cube IDs, and a target's `row_id` refers to its cube in the same table.

```json
{
  "schema": "r663-union-cell-v1",
  "n": 1,
  "cubes": [
    {"id":"A", "order":1, "y":["0/1"], "s":"2/1"},
    {"id":"B", "order":2, "y":["2/1"], "s":"2/1"},
    {"id":"C", "order":3, "y":["1/1"], "s":"2/1"},
    {"id":"H", "order":4, "y":["0/1"], "s":"1/1"},
    {"id":"J", "order":5, "y":["1/1"], "s":"1/2"}
  ],
  "q":{"A":"1/10","B":"1/10","C":"1/10","H":"0/1","J":"0/1"},
  "k":2,
  "targets":[
    {"id":"TH","row_id":"H","I":["A","C"]},
    {"id":"TJ","row_id":"J","I":["B","C"]}
  ],
  "history":[
    {"event_id":"e1","source_id":"A"},
    {"event_id":"e2","source_id":"B"}
  ],
  "proposed_source_id":"C",
  "qualification":{"mode":"geometry_only"},
  "emit_cells":false
}
```

The history list is the global arrival order. Times are optional metadata; if provided they must be strictly increasing finite exact numbers and do not alter the spatial computation. An inserted event receives a fresh ID after all history IDs (implementations may accept an explicit fresh `proposed_event_id`). A proposed arrival from `q_i=0` has a well-defined hypothetical geometry but is not a possible positive-rate mark; the history/law flag must fail. Duplicate source labels in a key are valid; duplicate event identities are invalid.

Minimum geometric data are the cube table, fixed nonnegative `q`, targets' exact source sets, `k`, and the ordered event identities with their source labels. `F_i`, `X_i`, times, a Poisson sampler, and owner shapes are unnecessary to compute the displayed geometric quantities. `U=sum_i (2*s_i)^n*q_i` needs only cubes and q. For a general fixed history, no loss of relevant information occurs by storing each target's first `min(k,count)` event IDs and the completed group ledger. A label-tuple count table without global event identity is insufficient.

`qualification.mode="actual_full_near"` additionally requires the **complete original** cube table, accepted/rejected claims if supplied, the original radius order, and for every actual lost accepted row an interior witness `z` (or a request to derive one canonically). It requires the supplied target list to contain exactly every near lost row, with the exact derived `I`. `mode="actual_target_subset"` checks each supplied row but does not claim the full union covers all near losses. Optional witness objects have the form `{"row_id":"...","z":["p/q",...]}`. Store witness choices with the experiment: different valid choices may give different `I` and hence different random laws, while remaining actual.

A backend may instead expose a pure geometry call taking already-completed group records. Such a call still needs each group's representative row, its event/source list or exact expanded box, all A_i and q for `L_h`, and the complete old-group ledger. It must declare whether history consistency was actually checked.

## 3. One event, several first keys

For target j, restrict the global history to labels in `I_j`. If at least k events are present, its fixed key is its first k **event IDs**, with completion at its kth event. Otherwise let `m_j<k` be its count. Inserting source i completes precisely targets with `m_j=k-1` and `i in I_j`. Append the same new global event ID to each of those restricted histories, then group these newly completed targets by equality of the full resulting event-ID list. Distinct new keys at this arrival must all be processed before computing one union increment.

Each new group's members are all the targets with that key. There are no later members: any target whose first k event IDs equal the key has already seen all k events when its final event arrives. Previously completed groups cannot gain members or change representative. In particular no newly completed key can equal an old key, because its final event is fresh. The representative is the minimum original `order(row_id)` among group members, not the smallest source label and not a separately sampled row.

When computing a hypothetical `Delta_i(history<t)`, all proposed source labels use exactly the same pre-insertion old ledger. Do not mutate the shared old ledger after computing the first hypothetical label. Actual history advancement, if requested, commits only the selected arrival.

## 4. Exact finite cells and completeness proof

For every coordinate r, collect and sort distinct endpoints of all `A_i`, and all old/new nonempty expanded boxes `R_K`. For owner verification also include all `B_i` endpoints. Adjacent **distinct** endpoints determine open coordinate intervals; their products are open cells C of strictly positive n-dimensional volume. It is enough to enumerate cells within the finite union bounding envelope of old/new boxes for union calculations. If no group exists, all relevant volumes are zero. For `U`, owners, or load maxima, use the corresponding B/A envelope instead.

On each cell every `1_Ai`, `1_RK`, every prefix load and every `1_DK` is constant. The rational midpoint is an exact membership representative. Its volume is the product of its rational side lengths. This proves each finite sum in Section 1 equals the Lebesgue volume in question: the omitted finite coordinate-hyperplane union has Lebesgue measure zero. No closed-boundary hit is counted as positive volume, and touching expanded boxes have zero-volume overlap. This is a proof of exactness for this finite input, not an extrapolation from grid sampling.

A post hoc table of positive cells is a certificate when it includes cell bounds, volume, source membership bitset, relevant prefix loads, old/new active-key IDs, and coverage booleans. A compact certificate may instead include endpoint lists and the exact deterministic evaluator. Cells with zero side length must never be emitted as positive cells.

One may precompute an arrangement before sampling: in coordinate r include `y_ir+-s_i` and, for every possible representative h, `y_ir-s_i-c0*s_h` and `y_ir+s_i+c0*s_h` for all sources i. These include every possible expanded-intersection face because maxima/minima select source endpoints. Include B faces if owners are certified. This finite universal arrangement may be very large; there is no complexity requirement permitting omitted constraints.

## 5. Owner U and actual-family qualification

Qualification is separate from exact geometric evaluation. It must report each following predicate, not one ambiguous `qualified=true`.

1. **`input_exact`**: all dimensions, IDs, finite positive radii, exact coordinates and nonnegative q are valid. Orders form a strict total order, and actual mode has radii nonincreasing in that order.
2. **`admission_exact`**: regenerate the scan on the full original family. At candidate j, using previously accepted raw weights `w_i`, retain iff `sum_{accepted i<j} w_i * 1_{c0 A_i}(y_j)<=1`, with `c0 A_i=Q(y_i,c0*s_i)`. This is an exact **point** membership test, including closed boundaries; unlike volume tests it cannot ignore a boundary hit. For an accepted row compute `E_j=B_j \ union_{accepted i<j} B_i` by B-membership cells, then `w_j=|E_j|/(2*s_j)^n`. Rejected rows carry no source q. Do not test admission with q in place of w.
3. **`residual_exact`**: on each accepted row in order compute `ell_j=esssup_{x in A_j} sum_{accepted i<j} q_i*1_Ai(x)` as the maximum prefix load on all positive cells meeting the interior of A_j. Enforce `q_j=min(w_j,max(0,tau-ell_j))`, `tau=16384*sqrt(n)`. A maximum on a closed lower-dimensional face is not an essential supremum. Verify global a.e. load `sum q_i1_Ai<=tau` and `0<=q_j<=w_j`; these follow from a correct reconstruction but are useful independent certificate checks.
4. **`owners_feasible`**: accepted full owners are pairwise a.e. disjoint and q satisfies `0<=d_j*q_j<=|E_j|`. This is exactly what is needed for the existence of measurable disjoint `F_j subset E_j` with those volumes. Hence `U=sum d_j*q_j` is exact without storing F. If actual F/X geometry is requested, fill owner cells in a fixed lexicographic order and split the final cell along its first coordinate by the required rational volume; retain all resulting cuts. This constructs rational boxes for F/X in rational-q mode. A preselected F must instead be supplied and checked; do not pretend the canonical construction reproduces it.
5. **`witnesses_positive_cell`**: a lost row is one with `q_j<w_j`. For every such row choose/verify z_j inside an **open full-dimensional cell of the arrangement of all original A faces**, inside A_j, with complete prefix load through j equal to tau. Verify complete full-family load there equals tau and no future positive-q cube contains z_j. Witnesses on any A boundary do not meet this contract. Canonical construction searches the global arrangement for such a cell and takes its midpoint. This retains the actual positive-cell saturation meaning.
6. **`near_sets_exact`**: for each lost row split its complete witness load into sources with `s_i>=n*s_j` and sources with `s_j<=s_i<n*s_j`, retaining `q_i>0` and `z_j in A_i`. The near rows are precisely those with far load `<tau/2`; their near load is then `>tau/2`. Verify every positive source at the witness lies in these two ranges (none later / smaller). The target's supplied `I_j` must equal that complete near-source set, not a convenient subset. In `actual_full_near` mode, verify every and only near lost row appears once.
7. **`k_actual`**: `k=ceil(2*tau)`. A diagnostic k must not acquire this flag.
8. **`history_structural`**: every event source has q>0, event IDs are unique, ordering is strict if times are present, and completed groups/representatives are regenerated from this single shared history. This checks structural consistency, not that a sampler truly generated independent Poisson processes. Report sampler provenance separately (`not_provided` if absent).
9. **`loss_cover_verified`** (optional stronger diagnostic): if actual F/X are materialized, check each near X_j lies a.e. in its completed group's D once that target is complete. For a still-pending target no completed-key cover is claimed. Admission and witnesses give the mathematical cover; explicit cells can verify it for a finite chosen realization.

The aggregate `actual_full_near_qualified` requires flags 1--8 and full target completeness. An empty near family can qualify vacuously; always output the number of actual near lost rows and whether it is nonempty. Geometry-only diagnostic inputs may have all spatial answers exact while this aggregate is false. A finite prefix with pending targets yields exact `Omega_prefix`, not terminal `W_union`. Use `terminal_complete=true` only when all supplied targets have completed; call the prefix output `W_union_prefix` otherwise.

### Irrational tau versus rational q

For square n, tau is rational/integer and every reconstruction step above is rational. For nonsquare n, exact rational q can be compared to tau by integer/rational squaring after sign checks, but a positive clipped value `tau-ell_j` is irrational when all earlier q are rational. Consequently a genuinely actual finite rational-q family at nonsquare n cannot have a first lost row: at the first loss all prior q and ell are rational, and feasibility forces either a positive irrational clipping or a rational equality to irrational tau. Thus an all-rational fixed-q test with nonempty actual near targets at nonsquare n must fail qualification. Do not replace tau by a float or a nearby rational to evade this issue. Use square n (e.g. 256 or 1024) or explicitly extend the arithmetic backend and schema to `Q(sqrt(n))`; any such extension must also specify exact ordering/comparison and exact endpoint handling if coordinates are extended. The rational-only schema makes no such implicit extension.

## 6. Exact output fields

```json
{
  "schema":"r663-union-cell-v1",
  "arithmetic":"rational_exact",
  "U":"6/5",
  "W_union_before":"0/1",
  "W_union_after":"355/64",
  "W_sum_before":"0/1",
  "W_sum_after":"291/32",
  "new_union_volume":"355/64",
  "increment_volume":"355/64",
  "terminal_complete_before":false,
  "terminal_complete_after":true,
  "groups_before":[],
  "groups_new":[
    {"key_event_ids":["e1","e3"],"source_ids":["A","C"],
     "member_target_ids":["TH"],"representative_row_id":"H",
     "intersection_empty":false,"lower":["-65/32"],"upper":["97/32"],
     "volume":"81/16","completed_at_event_id":"e3"},
    {"key_event_ids":["e2","e3"],"source_ids":["B","C"],
     "member_target_ids":["TJ"],"representative_row_id":"J",
     "intersection_empty":false,"lower":["-33/64"],"upper":["225/64"],
     "volume":"129/32","completed_at_event_id":"e3"}
  ],
  "qualification":{
    "mode":"geometry_only","input_exact":true,"history_structural":true,
    "actual_full_near_qualified":false,
    "sampler_provenance":"not_provided",
    "reasons":["diagnostic k and target sets; actual admission/residual/near checks not requested"]
  },
  "checks":{
    "increment_equals_union_difference":true,
    "union_le_sum":true,
    "new_union_le_new_group_volume_sum":true
  }
}
```

Here `lower/upper` are the **expanded** R_K box endpoints; `volume` is `|D_K|`, so it can be smaller than the box volume. Empty intersections have `intersection_empty=true`, null endpoints, and zero D volume. For history-only calls with no proposed arrival, after equals before and new fields are zero. Expose pending targets with counts if useful. Diagnostic decimal display may accompany exact fractions but does not replace them. Omitted qualification checks should be `null`/`not_checked`, not false assertions of mathematical failure and not implicitly true.

## 7. Safe reductions, with limits

- Precompute every positive cell's source-membership bitset and prefix loads in original order. Since q>=0, `L_h` decreases with h. A cell's eligible representatives form an initial segment of the original order: query the largest h for which its prefix load is <=1. This replaces repeated load sums without omitting any constraint.
- Geometry of one key needs only the coordinate maxima/minima of distinct source labels. Event identity/order still determines grouping, representative and W_sum. Extrema compression is geometry-only.
- If two expanded boxes satisfy `R_1 superset R_2` and `order(h_1)<=order(h_2)`, then `D_1 superset D_2`. The dominated D can be removed for a union calculation only. In particular equal source intersections with earlier/larger-radius representatives satisfy this containment. Keep every actual group for W_sum and group provenance.
- With only nonnegative additions, the old-union ledger can be represented by a coverage bitset or union antichain on a fixed universal arrangement. Do not remove an old region merely because it is dominated by a newly proposed one while still needing the old/new increment difference; retain the old coverage bitset.
- A union decomposition into disjoint key-attributed cells may choose any explicit deterministic priority. It is an optional accounting convention, not a proved source-charge inequality. No minimum-source budget or dimension-free potential follows from these finite formulas.

## 8. Exact arithmetic check and evidence boundary

The JSON fixture above is deliberately geometry-only: n=1 and k=2 cannot qualify as actual near at the frozen tau. Its one proposed C arrival completes two distinct keys. Every prefix load is at most 3/10, so each L_h is all space. The two enlarged intervals overlap with length 227/64. Therefore their union/increment is 355/64, versus group-volume sum 291/32. If an old completed group covers `[-33/128,289/128]`, its length is 161/64 and the same arrival's increment is 97/32; each new individual D is larger, so summing would miss both old and new overlap.

The following standalone Python standard-library calculation is reproducible (no additional files are owned by S6). Its actual execution and result are reported to the main agent. It verifies the rational interval arithmetic and both old/new overlap cases only; it does not verify an actual near instance, prove a general bound, or replace Terra's cell/history implementation.

```python
from fractions import Fraction as F
A=(F(-65,32),F(97,32)); B=(F(-33,64),F(225,64))
old=(F(-33,128),F(289,128))
length=lambda I:I[1]-I[0]
union=max(A[1],B[1])-min(A[0],B[0])
overlap=max(F(0),min(A[1],B[1])-max(A[0],B[0]))
assert length(A)==F(81,16) and length(B)==F(129,32)
assert union==F(355,64) and length(A)+length(B)==F(291,32)
assert overlap==F(227,64)
assert min(A[0],B[0])<=old[0]<=old[1]<=max(A[1],B[1])
assert union-length(old)==F(97,32)
print({'union':str(union),'sum':str(length(A)+length(B)),
       'overlap':str(overlap),'old':str(length(old)),
       'increment_with_old':str(union-length(old)), 'U':str(3*F(4)*F(1,10))})
```

### Executed verification record

On this turn local Python 3.15.0 with standard-library `fractions.Fraction` executed the displayed interval check successfully. Actual output: `union=355/64`, `sum=291/32`, `overlap=227/64`, `old=161/64`, `increment_with_old=97/32`, `U=6/5`.

A separate exact closed-form check read S10's `geometry_fixture.json` without changing it. With `e=97/384`, `b=4+2e`, set `vM=(3+2e)b^2`, `vL=(7/2+2e)b^2`. The first fixture has old volume `vM`, final union `b^3`, sum `vM+2vL`, and t3 increment `b^3-vM`. All expected fractions matched. In the second fixture the pair-overlap forbidden set for `L_h` is `[-2,2]^3` up to null faces. Its middle volume is `vM-16(3+2e)`, each side volume is `vL-16(7/2+e)`, and final union is `b^3-64`. All expected fractions again matched: final union `194229793/7077888`, sum `135812513/2359296`, middle/intersection `106603873/7077888`.

These fixtures are correctly flagged diagnostic-only. In n=3 every actual raw owner weight is at most `a^(-n)=1/884736`, whereas the fixture source q are 1/10 or 1, so actual residual qualification necessarily fails. Their top-level `prefix_contract` defines an additional unfinished-prefix potential object, separate from completed-key Omega; this file does not certify a potential budget for that object. At the fixture's full history all targets already completed, so its subsequent proposed arrival has zero completed-key increment. Replay the first fixture's first two events and insert its third event to test the simultaneous-two-key increment.
