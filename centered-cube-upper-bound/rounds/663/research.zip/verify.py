#!/usr/bin/env python3
"""Reproduce the frozen R663 checks without modifying frozen inputs."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parent
RESULT = ROOT / 'VERIFICATION.json'
TEMP_ROOT = Path('/Volumes/data/CodexTemp')
PY_FILES = ('geometry_kernel.py', 'firstkey_engine.py', 'certificates.py')
EXPECTED_REPORT = '98e7682e40d0379e9e79ff4500ee238d0f40f13529f5fccefd198174fcb85481'
checks = []

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check(name, function):
    try:
        details = function()
        checks.append({'name': name, 'status': 'pass', 'details': details})
    except Exception as exc:
        checks.append({'name': name, 'status': 'fail', 'error': str(exc),
                       'traceback': traceback.format_exc(limit=4)})

def manifest_check():
    path = ROOT / 'MANIFEST.json'
    if not path.exists():
        return {'status': 'skipped', 'reason': 'MANIFEST.json absent'}
    data = json.loads(path.read_text(encoding='utf-8'))
    entries = data.get('files', data.get('entries')) if isinstance(data, dict) else data
    if entries is None:
        raise ValueError('manifest has no files or entries field')
    if isinstance(entries, dict):
        pairs = [(name, value.get('sha256') if isinstance(value, dict) else value)
                 for name, value in entries.items()]
    elif isinstance(entries, list):
        pairs = [(item.get('path', item.get('name')), item.get('sha256')) for item in entries]
    else:
        raise ValueError('unrecognized manifest entries')
    if not pairs: raise ValueError('empty manifest')
    verified, skipped = [], []
    for name, expected in pairs:
        if not isinstance(name, str) or not re.fullmatch(r'[a-fA-F0-9]{64}', str(expected)):
            raise ValueError(f'invalid manifest entry: {name!r}')
        target = (ROOT / name).resolve()
        if not target.is_relative_to(ROOT): raise ValueError(f'outside bundle: {name}')
        if target == path.resolve():
            raise ValueError('manifest must not list itself')
        actual = digest(target)
        if actual.lower() != expected.lower(): raise ValueError(f'hash mismatch: {name}')
        verified.append(name)
    return {'verified_count':len(verified), 'verified':verified, 'circular_entries_skipped':skipped}

def syntax_check():
    for name in PY_FILES:
        ast.parse((ROOT/name).read_text(encoding='utf-8'), filename=name)
    return {'files': list(PY_FILES), 'method':'ast.parse (no bytecode written)'}

def tex_check():
    text = (ROOT/'REPORT.tex').read_text(encoding='utf-8')
    bad = [(i,ord(c)) for i,c in enumerate(text) if (ord(c)<32 and c not in '\n\r\t') or ord(c)==127]
    if bad: raise ValueError(f'control characters (offset, code): {bad[:10]}')
    # Strip unescaped comments, preserving escaped percent signs.
    cleaned = []
    for line in text.splitlines():
        for i,c in enumerate(line):
            if c == '%':
                j=i-1
                while j>=0 and line[j]=='\\': j-=1
                if (i-1-j)%2==0:
                    line=line[:i]; break
        cleaned.append(line)
    stack=[]
    for match in re.finditer(r'\\(begin|end)\s*\{([^{}]+)\}', '\n'.join(cleaned)):
        op,env=match.groups()
        if op=='begin': stack.append(env)
        elif not stack or stack.pop()!=env: raise ValueError(f'unmatched environment end {env}')
    if stack: raise ValueError(f'unclosed environments: {stack}')
    return {'control_characters':'none', 'environment_nesting':'balanced', 'scope':'textual check, not TeX compilation'}

def report_binding():
    actual=digest(ROOT/'REPORT.tex')
    if actual != EXPECTED_REPORT: raise ValueError(f'REPORT SHA mismatch: {actual}')
    review=(ROOT/'FINAL_REVIEW.md').read_text(encoding='utf-8')
    header=review.split('## ',1)[0]
    if actual not in header or 'REPORT.tex' not in header: raise ValueError('FINAL_REVIEW header does not bind report SHA')
    return {'report_sha256':actual,'review_sha256':digest(ROOT/'FINAL_REVIEW.md')}

def run_process(command,cwd):
    env=os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE']='1'
    completed=subprocess.run(command,cwd=cwd,env=env,text=True,capture_output=True,timeout=180)
    out={'command':command,'exit_code':completed.returncode,'stdout':completed.stdout.strip(),
         'stderr':completed.stderr.strip()}
    if completed.returncode: raise RuntimeError(json.dumps(out,ensure_ascii=False))
    return out

def reproduce():
    if not TEMP_ROOT.is_dir(): raise FileNotFoundError(str(TEMP_ROOT))
    with tempfile.TemporaryDirectory(prefix='r663-verify-',dir=TEMP_ROOT) as temp:
        work=Path(temp)
        for name in (*PY_FILES,'geometry_fixture.json','PROCESS_RESULTS.json'):
            shutil.copyfile(ROOT/name,work/name)
        commands=[]
        commands.append(run_process([sys.executable,'firstkey_engine.py','--selftest'],work))
        commands.append(run_process([sys.executable,'firstkey_engine.py','--fixture','geometry_fixture.json','reproduced.json'],work))
        fresh=json.loads((work/'reproduced.json').read_text(encoding='utf-8'))
        frozen=json.loads((work/'PROCESS_RESULTS.json').read_text(encoding='utf-8'))
        if fresh != frozen: raise ValueError('reproduced JSON differs from frozen PROCESS_RESULTS.json')
        commands.append(run_process([sys.executable,'certificates.py'],work))
        if 'closed touching intersection: enlarged volume = 2' not in commands[-1]['stdout']:
            raise ValueError('tangent boundary test output absent')
        return {'isolated_directory_parent':str(TEMP_ROOT),'temporary_directory_removed':True,
                'commands':commands,'full_json_comparison':'equal', 'tangent_test':'passed'}

for name,fn in [('manifest',manifest_check),('python_syntax',syntax_check),
                ('report_tex',tex_check),('report_review_binding',report_binding),
                ('isolated_reproduction',reproduce)]:
    check(name,fn)
result={'status':'pass' if all(c['status']=='pass' for c in checks) else 'fail',
        'python_executable':sys.executable,'python_version':sys.version,
        'verification_script_sha256':digest(Path(__file__)), 'checks':checks}
manifest_path = ROOT / 'MANIFEST.json'
if manifest_path.exists():
    # Preserve a sealed VERIFICATION.json, whose hash may be in the manifest.
    print(json.dumps(result,ensure_ascii=False,indent=2))
else:
    RESULT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('verification:',result['status'],'; result:',RESULT if not manifest_path.exists() else 'stdout (sealed record preserved)')
for item in checks: print(item['name']+':',item['status'])
sys.exit(0 if result['status']=='pass' else 1)
