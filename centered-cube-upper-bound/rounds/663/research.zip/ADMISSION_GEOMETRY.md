# R663 admission geometry: a paid repeated-label branch and the unpaid source frontier

Status: a genuine finite-time whole-family estimate is proved for repeated-source keys. No bound for the full first-coverage union, and no bound for the remaining distinct-source frontier, is claimed.

## Key formulas first

Write `a=32n`, `c0=1+1/a`, `di=(2si)^n`, and let `Ni(t)` be the one common rate-`qi` Poisson count. Real ownership gives

\[
0\le q_i=|F_i|/d_i\le a^{-n}.
\]

Let `Omega_t^rep` be the union of all actual completed-key regions whose key repeats at least one source label. Then, for every finite actual family and every finite deterministic `t`,

\[
\boxed{\quad
\mathbb E|\Omega_t^{\rm rep}|
\le \frac{t^2}{2}\left(\frac{1+c_0}{a}\right)^n U.
\quad}                                                     \tag{R}
\]

Thus at the proposed common horizon `t=8`,

\[
\mathbb E|\Omega_8^{\rm rep}|\le
32\left(\frac{2+1/(32n)}{32n}\right)^n U.
\]

For `n>=256`, this coefficient is less than `10^(-900)`. This removes an actual complete branch of the same shared-process union. It is not a payment for the distinct-label keys.

There is also a source-order frontier interface. Set

\[
M_i(z)=\sum_{\ell\le i}N_\ell(t)\mathbf1_{A_\ell}(z),\qquad
Z_i=\{z:M_i(z)\ge k\},\qquad Z_0=\varnothing,
\]

\[
\mathcal H_i=
\bigcup_{h\le i}\big[(Z_h+c_0s_h[-1,1]^n)\cap L_h\big].
\]

This is a majorant built from the same actual source family and the same Poisson counts; it does not introduce new random draws. For the actual union,

\[
\Omega_t\subset\mathcal H_N,
\qquad
\mathcal H_N=
\bigcup_i\big[((Z_i\setminus Z_{i-1})+c_0s_i[-1,1]^n)\cap L_i\big].       \tag{F1}
\]

Define, using only counts of sources earlier than `i`,

\[
K_i=
\left[\left(A_i\cap\{M_{i-1}=k-1\}
               +c_0s_i[-1,1]^n\right)\cap L_i\right]
\setminus\mathcal H_{i-1}.                                    \tag{F2}
\]

Parentheses in (F2) mean first intersect `Ai` with the displayed level set, then take its Minkowski sum. The resulting valid bound is

\[
\boxed{\quad
\mathbb E|\Omega_t|
\le t\sum_i q_i e^{-tq_i}\,\mathbb E|K_i|
 +\frac{t^2}{2}\left(\frac{1+c_0}{a}\right)^n U.
\quad}                                                       \tag{F3}
\]

No estimate `sum_i qi E|Ki| <= C U` has been established. In particular, (F3) is a conditional interface, not a renamed proof of the desired result. The majorant can be strictly larger than the actual union and does not preserve all first-k event exclusions.

## 1. Exact repeated-label payment

For any actual completed group with representative `h`, every source label in its key belongs to `Ih`. If label `i` repeats, then `Ni(t)>=2`, `si>=sh`, and

\[
D_{\rm key}\subset
A_i+c_0s_h[-1,1]^n
\subset A_i+c_0s_i[-1,1]^n.
\]

The entire repeated-label union, irrespective of the number of witnesses, representatives, or groups, is consequently contained in

\[
\bigcup_{i:N_i(t)\ge2}(A_i+c_0s_i[-1,1]^n).
\]

The enclosing cube has volume `(1+c0)^n di`. The Poisson factorial-moment inequality gives

\[
\Pr\{N_i(t)\ge2\}
\le\tfrac12\mathbb E[N_i(t)(N_i(t)-1)]
=\tfrac12 t^2q_i^2.
\]

Therefore

\[
\mathbb E|\Omega_t^{\rm rep}|
\le\tfrac12t^2(1+c_0)^n\sum_i d_iq_i^2
\le\tfrac12t^2(1+c_0)^na^{-n}\sum_i|F_i|.
\]

This proves (R). It uses no source-coordinate independence, no source density cap, and no sum over representatives. The tiny factor comes from the actual individual bound `|Fi|<=|Bi|`, not from an arbitrary measure on a thin boundary.

More generally, the union of keys repeating some source at least `m` times, `m>=2`, has expectation at most

\[
\frac{t^m}{m!}\left(\frac{1+c_0}{a^{m-1}}\right)^n U.
\]

This is a finite-horizon statement. Letting `t` tend to infinity destroys this payment. Nor does removal of repeated-label regions make the remaining selected tuples iid.

## 2. Why the source-order envelope is valid

A source appearing in `Ih` cannot be later than `h`: the actual complete saturation witness of row `h` excludes every later positive source. For any point `x` in the completed-key region, choose `z` in the full box intersection of its key with `||x-z||infinity<=c0 sh`. The `k` events of the key, including repeated labels with their correct multiplicity, give `Mh(z)>=k`. Also `x in Lh`. Hence `x in H_N`.

Both uses retain all coordinate inequalities of the common box intersection. There is no sum of one-coordinate boundary estimates.

For the second claim in (F1), if `z in Zh`, let `i<=h` be its first source-order threshold crossing. Then `z in Zi\Z_{i-1}`, `si>=sh`, and `Lh subset Li`, since the deterministic prefix loads increase in the original order. Thus every point of `(Zh+c0 sh cube) intersect Lh` belongs to the corresponding crossing piece for `i`. Conversely, each crossing piece is contained in the `i` term of the definition of `H_N`. This proves equality of the two unions in (F1).

A zero-count source does not create a threshold crossing. A row with `qi=0` therefore cannot create a new piece in this envelope, although it may have an actual target key. This is how (F1) gets rid of target count without falsely assigning independent tuples to representatives.

## 3. Conditional source increment and the remaining geometric contract

Condition on all Poisson counts of sources before `i` in the original order. The already constructed set `H_{i-1}` and `M_{i-1}` are then fixed, and `Ni(t)` remains independent Poisson with mean `t qi`.

For the outcome `Ni(t)=m>=1`,

\[
Z_i\setminus Z_{i-1}
=A_i\cap\{k-m\le M_{i-1}<k\}.
\]

The new volume of the source-order envelope is exactly this set expanded by `c0 si`, restricted to `Li`, and with `H_{i-1}` removed. For `m=1`, it is `Ki`. For all `m>=2`, it is contained in `Ai+c0 si cube`. Summing the conditional expectation and applying the same factorial-moment calculation as in Section 1 proves (F3).

The specific unpaid statement that would close this enlarged route at `t=8` is

\[
\sum_i q_i e^{-8q_i}\,\mathbb E|K_i|\le C U
\quad\text{with absolute }C.                                  \tag{G}
\]

The true low-load condition is still present in `Ki`:

\[
x\in K_i\Longrightarrow
\sum_{\ell<i}q_\ell\mathbf1_{A_\ell}(x)\le1,
\]

while for some jointly constrained `z in Ai` near `x`, the earlier realized count is exactly `k-1`. Moreover, `x` has not been covered by any earlier enlarged threshold-crossing piece. This last subtraction is essential to the union objective.

The deterministic actual `qh` load exceeding `tau/2` at the original witness does not automatically persist at this new `z`; `z` may be anywhere in the sampled intersection. Likewise, the joint first-k selection exclusions have been relaxed by the envelope. Thus an argument for (G) would need to justify its own scope. It cannot import the local iid intersection estimate and multiply it by an unrelated representative probability.

The elementary individual bound `|Ki|<=(1+c0)^n di` gives only `t(1+c0)^n U` and does not close (G). Dividing by `k`, or summing thin boundary volumes coordinate by coordinate, still leaves the wrong dimensional cost. No further step has been justified here.

## 4. Actual numerical check and status

Executed a small MATLAB calculation of

`log10(32) + n*log10((2+1/(32*n))/(32*n))`

for `n=2,256,10^6`. The returned decimal values were respectively about `-1.4984`, `-923.25`, and `-7.2041e6`. This confirms the scale of the coefficient, not the proof of (R).

A direct uniform proof of the stated `10^(-900)` bound is elementary: the positive base `(2+1/(32n))/(32n)` decreases with `n` and is less than `1/4000` for `n>=256`; hence `32*4000^(-256)<10^(-900)`.

Only the repeated-label branch is globally paid. All distinct-label keys, including their actual shared first-coverage overlap, remain to be controlled. The source-order envelope is delivered as an explicit conditional route, not counted as a full-family improvement beyond the repeated-label payment.
