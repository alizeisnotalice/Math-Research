# R663 S9 independent audit: nonempty-prefix union potential

## Verdict and precise scope

**PASS** for the pathwise identity, all-keys finite-horizon compensation identity, and the bound

\[
\mathbb E|\Omega_H|+\mathbb EP_H+
\mathbb E\int_0^H\sum_iq_iD_i(t)\,dt
=\mathbb E\int_0^H\sum_iq_iB_i(t)\,dt
\le H(1+c_0)^nU.
\]

This retains the actual original family, the same common source Poisson processes, all newly completed keys at each event, and all spatial overlap. It does **not** prove an absolute-constant near-loss budget or a square-root dimension improvement. The exponential factor cannot be promoted to the requested final result. A rigorous terminal equality is available, but the displayed linear-in-H bound alone gives no useful bound after H tends to infinity.

The candidate was derived independently from TASK.md before TIME_POTENTIAL.md became available, then checked against the delivered TIME_POTENTIAL.md. The two agree on the claims above. This audit signs neither the separate unfinished-loss absorption question nor any unseen finite-horizon theorem.

## 1. Definitions needed for the claim

Use the finite collection of actual near targets j, their fixed sets I_j, fixed nonnegative q_i, fixed k, and original radius order. Every event has its actual time and source label. Outside the null set of simultaneous arrivals, times strictly order all global events. A target is incomplete if it has accumulated fewer than k qualifying events. Its prefix is the ordered list of its qualifying events so far.

Only incomplete targets with **nonempty** prefixes receive active regions. Targets with identical complete prefixes, including event identities and prefix lengths, form a group g. Let h(g)=min g and

\[
H_g=\left(\bigcap_{e\in\operatorname{prefix}(g)}A_{\operatorname{label}(e)}
+c_0s_{h(g)}[-1,1]^n\right)\cap L_{h(g)}.
\]

Repeated labels still have distinct event identities in the prefix, though the repeated spatial intersection is redundant. Empty prefixes have no spatial region: assigning the empty intersection its usual whole-space value would invalidate the initial condition and bounded-envelope argument.

Set A to the union of active H_g, R=Omega union A, and P=|A minus Omega|=|R|-|Omega|. Here Omega contains all completed-key regions, with their fixed earliest representative. Initially A=Omega=empty and P=0.

## 2. Every old group has only nested successors

At insertion of source i, split an old group according to whether i belongs to I_j. The unhit subgroup retains its prefix. The hit subgroup appends the same new event; it remains active or completes. Each nonempty subgroup has representative h' at least h, hence s_h' at most s_h. Moreover

\[
L_{h'}=\{x:\sum_{r<h'}q_r1_{A_r}(x)\le1\}\subseteq L_h,
\]

since every additional summand is nonnegative. The spatial source intersection is unchanged or gains A_i. Both the halo radius and L truncation can therefore only shrink. Thus every active or completed child satisfies H_child subset H_parent.

This includes the case in which the former representative completes or leaves an unhit remainder with a later representative. It also includes arbitrarily many old groups completing at this single arrival. Distinct old prefixes cannot merge after the arrival: newly appended events have the current time, and appending the same event is injective on old prefixes.

For a completed child, H_child is exactly its D_key. Its representative cannot change later: any target with this full time-stamped k-event key has already received all k events at the time of the last one. No target can join that completed key at a later time.

## 3. Newbirth uniqueness and its volume

All previously empty targets hit by this event acquire exactly the same singleton prefix (t,i). Consequently they form at most one new group, irrespective of how many targets were hit. If k=1 this group is immediately completed and is treated as the same newbirth contribution to Omega; the actual task has larger k.

Let J be the region of this new group and h its earliest target. Since i belongs to I_h, the actual near-source condition supplies s_h at most s_i. Therefore

\[
J\subseteq A_i+c_0s_i[-1,1]^n,
\qquad |J|\le (1+c_0)^n(2s_i)^n=(1+c_0)^nd_i.
\]

All other post-event R regions were already inside old R, by Section 2 and monotonicity of old Omega. Hence R' minus R is contained in J. This proves B_i at most (1+c_0)^n d_i, with no target or active-group multiplicity. If the empty-prefix hit set is empty then B_i=0.

An auxiliary observation useful only for finite-input integrability is that source i can create such a newbirth only at its own first global arrival. After that arrival every target containing i in I_j has a nonempty prefix forever. It follows that total birth volume is pathwise at most (1+c_0)^n sum_{i:q_i>0}d_i. This is not a U budget: small positive q_i prevent replacing sum d_i by an absolute multiple of sum q_id_i.

## 4. Exact set accounting, including all overlap

Define B_i=|R' minus R|, D_i=|R minus R'|, and Delta_i=Omega' minus Omega. Every set lies in the fixed finite-volume envelope union_i(A_i+c_0s_i cube). Thus all differences of volumes below are legitimate. Since Omega is monotone,

\[
P'-P=(|R'|-|R|)-(|\Omega'|-|\Omega|)
=B_i-D_i-|\Delta_i|.
\]

No disjointness between H_g is required. A completed portion already in old Omega contributes zero to Delta_i. A region lost from one active group but retained by another contributes zero to D_i. A completed region transferred from A to Omega reduces P by exactly its new visible volume while leaving R unchanged there. These facts handle the potentially problematic overlap and simultaneous-completion cases directly at the union level.

## 5. Finite horizon and terminal settlement

The hypothetical insertion costs B_i,D_i,|Delta_i| are functions of pre-event state and the proposed source i. They are predictable when evaluated immediately before arrivals; the inserted event time is the current t. The finite source set has finite total rate. All costs are bounded by the fixed envelope volume, so the finite-horizon jump sums and compensator integrals are integrable. Applying the elementary source-Poisson compensation formula to each nonnegative cost and summing the pathwise identity gives the equality in the verdict. The bound follows from Section 3 and sum_i q_id_i=U. Using eta_t instead of eta_{t-} in the dt integral has no effect.

There is also an exact infinite-horizon statement for this finite input. Each target has T_j=sum_{i in I_j}q_i>0 and completes in a finite time almost surely. There are finitely many targets, so their last completion time is finite almost surely and P_H tends to zero. Each target advances at most k times. Therefore there are at most k times (number of targets) global events that change any target state, hence at most that many nonzero B,D,Delta jumps. Their sums are bounded by this finite deterministic count times the envelope volume. In particular all cumulative jump sums are integrable.

Taking the pathwise terminal limit, then expectations and nonnegative compensation, gives

\[
\mathbb E|\Omega_\infty|+
\mathbb E\int_0^\infty\sum_iq_iD_i(t)\,dt
=\mathbb E\int_0^\infty\sum_iq_iB_i(t)\,dt<\infty.
\]

This proves exact terminal settlement, not a new useful dimension bound. Taking H to infinity on H(1+c_0)^nU merely loses the quantitative estimate. A usable absolute U bound would still need additional control of birth minus dissipation (or another genuine estimate).

For completeness the first-arrival observation also yields

\[
\mathbb E\int_0^H\sum_iq_iB_i(t)\,dt
\le(1+c_0)^n\sum_{i:q_i>0}d_i(1-e^{-q_iH}),
\]

because B_i(t)=0 after source i's first arrival. This has a finite terminal limit but charges sum d_i, not U, so it is not signed as progress toward the required global budget.

## 6. Local computation and evidence boundary

Used the installed math-research, jump-compensation/exit-settlement, and python-math guidance. An actual local Python standard-library run exhaustively checked the pointwise overlap-accounting identity for all 12 Boolean states (omega,a,omega',a') satisfying omega at most omega'. Output was:

    {'check': 'pointwise finite-state overlap accounting',
     'admissible_cases': 12, 'all_pass': True}

Reproducible code (executed with python3 via stdin to respect the single-owned-file restriction):

```python
from itertools import product
cases=0
for w,a,wp,ap in product((0,1),repeat=4):
    if wp<w:
        continue
    r=w or a
    rp=wp or ap
    p=a and not w
    pp=ap and not wp
    b=rp and not r
    d=r and not rp
    delta=wp and not w
    assert int(pp)-int(p)==int(b)-int(d)-int(delta)
    cases+=1
print({'check':'pointwise finite-state overlap accounting',
       'admissible_cases':cases,'all_pass':True})
```

This finite calculation checks the overlap identity only. Sections 1–5 supply the mathematical justification for geometric nesting, birth uniqueness, compensation, and terminal limits; the Boolean computation is not evidence for those additional claims.

## 7. Additional independent audit: paid repeated-source union and marked-parent interior

**PASS, for every finite actual family and each fixed finite deterministic b.** This section was first derived independently from the proposed statement, then checked against ADMISSION_GEOMETRY.md Section 1 and VISIBILITY.md (V2). The audit signs the repeated-source payment and the exact residual restrictions below. It does not sign the separate source-order-envelope interface (F1)–(F3), and it does not estimate the residual exterior.

Use the same global processes and original first-k keys as before, without skipping events, rejecting keys, resampling tuples, or changing group representatives. Write

\[
N_i=N_i(b),\quad C_i=A_i+c_0s_i[-1,1]^n,\quad
Q_b^{\rm repeat}=\bigcup_{i:N_i\ge2}C_i,\quad
P_b^{\rm marked}=\bigcup_{i:N_i\ge1}A_i.
\]

The new Q and P symbols are spatial sets and must not be confused with the scalar active-prefix potential P in Sections 1–6. Real ownership supplies

\[
0\le q_i\le w_i\le |B_i|/d_i=a^{-n}.
\]

### 7.1. Every repeated key's entire region is paid

Fix any realized completed key by time b, its actual whole target group, and its earliest representative h. Every source i in this key lies in I_h, hence s_i at least s_h. Consequently, even without using the low-load cut,

\[
D_{\rm key}\subseteq A_i+c_0s_h[-1,1]^n\subseteq C_i.
\]

If a source i repeats in that key, the actual global count N_i(b) is at least 2. Therefore the entire D_key lies in Q_b^repeat. This is true simultaneously for all completed keys, including arbitrarily many keys completed at one arrival and overlapping keys with different representatives. Thus

\[
\Omega_b^{\rm repeated\ key}\subseteq Q_b^{\rm repeat}.
\]

There is no union bound over targets or representatives. Only the original finite source labels are summed in the next estimate.

Since N_i has Poisson mean bq_i,

\[
\Pr(N_i\ge2)\le\tfrac12\mathbb E[N_i(N_i-1)]
=\tfrac12b^2q_i^2.
\]

Subadditivity of volume, the exact cube volume |C_i|=(1+c_0)^nd_i, and the individual q_i bound give

\[
\begin{aligned}
\mathbb E|Q_b^{\rm repeat}|
&\le\frac{b^2}{2}(1+c_0)^n\sum_i d_iq_i^2\\
&\le\frac{b^2}{2}\left(\frac{1+c_0}{a}\right)^n
\sum_i d_iq_i
=\frac{b^2}{2}\left(\frac{1+c_0}{a}\right)^nU.
\end{aligned}
\]

For b=8 the coefficient is exactly 32[(2+1/(32n))/(32n)]^n. This stronger enclosing-union payment subsumes ADMISSION_GEOMETRY.md's bound for Omega_b^rep. No conditional unbiasedness or independence between selected keys is used.

### 7.2. The residual has globally single-occurrence sources

The enclosing cubes also pay some keys which have no repeat inside their first k events. Indeed, if **any** source i appearing in a completed key has N_i(b) at least 2, the same containment puts that whole key region inside Q_b^repeat. The other occurrence can be outside the key or later than its completion; it still counts before b and still activates C_i.

Therefore, for every point x in Omega_b minus Q_b^repeat, every completed key whose D_key contains x uses only labels i with global N_i(b)=1. In particular each such key has k pairwise distinct labels. Equivalently, any original D_key with nonempty remainder outside Q_b^repeat has this property. This does not claim that all original completed keys become distinct; the other regions have been spatially paid and removed from this accounting.

### 7.3. Paid marked-parent interior and combined exact reduction

The marked-parent union is formed from **all** source events by b, whether or not a source completed a key. For each x its occupancy probability is 1-exp(-b f(x)), where f(x)=sum_iq_i1_Ai(x). Thus

\[
\mathbb E|\Omega_b\cap P_b^{\rm marked}|
\le\mathbb E|P_b^{\rm marked}|
=\int(1-e^{-bf(x)})\,dx\le b\int f=bU.
\]

Only the equality with the exponential uses independence of the original source processes. The weaker bound needed here also follows directly from sum_i d_i Pr(N_i at least 1) at most b sum_i d_iq_i.

Let

\[
S_b=\Omega_b\setminus(P_b^{\rm marked}\cup Q_b^{\rm repeat}).
\]

A disjoint partition of Omega_b into its marked-parent part, its repeat-cube part outside the first part, and S_b gives the valid whole-family reduction

\[
\mathbb E|\Omega_b|
\le\left[b+\frac{b^2}{2}
\left(\frac{1+c_0}{a}\right)^n\right]U+\mathbb E|S_b|.
\]

Every x in S_b is outside **every** marked original A_i, including marked sources outside any chosen witness key. Every completed key covering x has k distinct source labels and N_i(b)=1 for each label. These are simultaneous pointwise restrictions in the original process. They do not make the surviving tuples iid and do not provide an estimate for E|S_b|.

### 7.4. Boundary cases and evidence

Zero-rate sources have N_i=0 almost surely and contribute nothing. Empty near families and empty residual sets give the statements trivially. The inclusions hold for closed cubes, including tangent boundaries; changing cube-boundary conventions does not change their Lebesgue volumes. The L_h restriction only shrinks regions. A fixed deterministic horizon has no arrival exactly at b almost surely; either standard endpoint convention gives the same expected estimates. Finite source families ensure all unions and integrals are measurable and finite.

No modification to the first-key process is authorized or required: this is a partition of its already defined spatial union at the common deterministic time b. It is a genuine payment for two whole-family spatial portions. The remaining S_b is still unpaid, and the displayed reduction is not a complete first-coverage estimate.

An actual Python Fraction run verified coefficient simplification and finite dimension boundary values. At b=8 it returned 65/32 for n=1 and 16641/524288 for n=2; at n=256 the base was exactly 16385/67108864. These checks corroborate the constants only; the inequalities and all quantifiers are proved above.
