# R663：活跃前缀势、精确生成元与未解决的源移入费用

## 结论及状态

得到一个有界、保留全部 union 重叠收益的前缀势，生成元准确包含同次所有新完成 key 的新增可见区域 Δ_i。它引入了明确的空间耗散 D_i，源端可按 U 支付，但目前常数为 H(1+c0)^n，H=8 时仍为指数维数。没有证明 E|Ω_8|≤A U（绝对常数 A），不计作根阶或维数改进。

此构造使用同一原始有限输入和同一全局 Poisson 律；不引入替代 incidence 模型，不假设选出的代表 tuple 为无偏 iid，不按 target 数 m 计费。不处理 S1 所审未完成损失吸收。

## 1. 非空活跃前缀与单调细化

设 N_j(t) 为 I_j 中截至 t 的实际到达数。在 1≤N_j(t)<k 的 target 中，以完整的实际有时标前缀相同分组；前缀长度也必须相同。记一个活跃组为 g，其代表 h(g)=min g。令

    H_g(η) = (intersection_{e in prefix(g)} A_{label(e)}
                  + c0 s_{h(g)}[-1,1]^n) ∩ L_{h(g)}.

空前缀不设空间区域。重复 label 仍保留其事件身份，以判断前缀相等；重复交集不会改变空间区域。

一个事件只把已有组按该来源是否属于 I_j 进一步细分。每个仍活跃 child 或本次完成 child 的代表 h'≥h，故

    s_{h'}≤s_h,    L_{h'}⊂L_h,
    intersection(child labels)⊂intersection(parent labels),
    H_child⊂H_parent.

L_h 的嵌套来自 q_i≥0 和 L_h={Σ_{i<h}q_i1_{A_i}≤1}。未被事件击中的子组也满足同一包含关系；父组代表离开时它的候选半径和 L 截断都只会缩小。因此所有已有活跃组的后继区域都包含在原活跃区域并集中。本次完成组的 H_child 正是相应完整 key 的 D_key，包含同次全部完成组，不只选一个 winner。

唯一可能向空间包络外移入的区域来自此前 N_j=0、此刻首次收到该来源 i 的 targets。这些 targets 的前缀都为同一个有时标单事件 (t,i)，所以本次至多产生一个首标记组。其代表 h 满足 i∈I_h，从而 s_h≤s_i，故新生区域

    J_i(η)⊂A_i+c0 s_i[-1,1]^n,
    |J_i(η)|≤(1+c0)^n d_i.

这里没有对其它活跃组的数量求和。

## 2. 可检查的生成元恒等式

定义

    A(η)=union_{g active} H_g(η),
    R(η)=Ω(η)∪A(η),
    P(η)=|A(η)\Ω(η)|=|R(η)|-|Ω(η)|.

P≥0，P(0)=0。有限输入的所有 H_g 均位于有限个 A_i+c0 s_i cube 的并集中，故 P 有界。事件 i 后状态记 η^i。定义新符号

    B_i(η)=|R(η^i)\R(η)|,
    D_i(η)=|R(η)\R(η^i)|.

B_i 是源移入，D_i 是真实空间耗散：旧活跃前缀的空间消失，且既没有被其它活跃前缀保留，也没有被完成 key 留在 Ω。已完成 Ω 永不消失，故 D_i≥0 且确实来自未兑现的候选区域。由第 1 节，

    R(η^i)\R(η)⊂J_i(η),
    B_i≤(1+c0)^n d_i.

任务已固定的新增覆盖为 Ω(η^i)\Ω(η)=Δ_i(η)，所以直接作集合差得到

    P(η^i)-P(η)=B_i(η)-D_i(η)-|Δ_i(η)|,
    (L P)(η)=Σ_i q_i[B_i(η)-D_i(η)-|Δ_i(η)|].             (GEN)

(GEN) 包含同一事件所有新 key 的实际新增 union。D_i 不是逐 target 或逐 key 体积和，已经扣掉所有重叠保留。

有限窗 H 下，补偿和有界势的 Dynkin 恒等式给出

    E|Ω_H| + EP(η_H) + E∫_0^H Σ_i q_i D_i(η_t)dt
      = E∫_0^H Σ_i q_i B_i(η_t)dt
      ≤ H(1+c0)^n Σ_i q_i d_i
      = H(1+c0)^n U.                                      (BAL)

所以端点 P_H 非负，可丢弃；源端确实按 Fi 费用支付，没有 m。时间 t 只需按有限窗停止，不要求无限窗可积性。状态可用每个 target 至多 k 个事件的相对身份、已完成 key、源 labels 以及前缀等价类编码；有限 target/source/k 使可达状态在重命名旧事件身份后有限，不必保留无关旧到达。未提出值得交 Terra 求解的新矩阵不等式。

## 3. 精确障碍与停止边界

源端的单标记区域 A_i+c0 s_h cube 可能有比例 (1+c0)^n；上述几何包含只给 (1+c0)^n d_i。因此 (BAL) 不能付绝对常数 A U。需要证明一个真实历史依赖的几何耗散估计，把源移入的指数费用减去 D_i；当前没有这样的估计。它不由固定 h 的无条件完整 tuple 交集矩直接推出：D_i 同时依赖所有已生成前缀、此前覆盖以及代表细分。

若将每个深度 p 的活跃区域乘 w_p，希望 w_1 很小而完成前的 w_{k-1}=1，则在某个完整活跃组推进且交集不变的事件上，会产生

    (w_{p+1}-w_p)|H_g|>0.

这不是虚设 incidence 反例：任务允许重复 label；重复收到一个已在前缀中的来源时，交集本身可保持不变。代表与组都未变化时，L 截断和 halo 也保持不变。该事件没有任何上述 D_i 可供支付。因此递增深度权重不能沿用 (GEN) 的单步耗散；它必须另付全部促进项。尚未证明实际 admission 给出了促进项的统一 source 费用界。此处仅指出候选势所需的新不等式，不宣称真实模型不可能成立。

这条分支到此停止。没有把 (GEN)、指数维数界或同一未付总量重新命名为目标进展。

## 4. 本机精确集合核验（仅核验记账）

以下 Python 标准库脚本穷举三点有限空间中所有 Ω,A,C,S,J，限制 C⊂A、S⊂A。其中 C 是本次完成区域，S 是旧活跃组全部后继区域，J 是新生区域。核验不使用概率或浮点数，检查 (GEN) 的单步集合恒等式。它不验证几何包含或绝对常数费用估计。

```python
from itertools import product
universe=7
checks=0
for omega,active,completed,surviving,newborn in product(range(8),repeat=5):
    if completed & ~active or surviving & ~active:
        continue
    omega_next=omega|completed
    active_next=surviving|newborn
    r=omega|active
    r_next=omega_next|active_next
    p=(active & ~omega & universe).bit_count()
    p_next=(active_next & ~omega_next & universe).bit_count()
    birth=(r_next & ~r & universe).bit_count()
    death=(r & ~r_next & universe).bit_count()
    delta=(omega_next & ~omega & universe).bit_count()
    assert p_next-p == birth-death-delta
    assert not ((r_next & ~r & universe) & ~newborn)
    checks+=1
print('Exact set checks:',checks,'; all passed')
```

实际执行：`/Users/zzh/.local/bin/python3`，Python 3.15.0。输出：

```text
Exact set checks: 8000 ; all passed
```
