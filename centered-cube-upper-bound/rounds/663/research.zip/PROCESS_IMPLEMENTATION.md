# R663 全局首 k 事件过程：实现与精确账

`firstkey_engine.py` 按唯一全局到达次序将事件投影至每个固定来源集 I_j。键是有序 event_id 元组，source_id 和时间独立保留；一个到达先更新所有未完成 target，再按完整键同时分组，代表取最小原始 row order。已完成 target 的键固定，重复来源标签保留为不同事件。非空未完成前缀同样按 event_id 分组；空前缀无区域。每个事件以 `geometry_kernel.measure` 计算完整 Ω、活跃 A、R=Ω∪A、P=|R|−|Ω|，将新旧 R 一起取并求 B、D，并核验 ΔP=B−D−Δ。几何缓存只缓存并集体积，绝不用于判定键身份。

`PROCESS_RESULTS.json` 保存两条冻结确定性事件带及逐事件精确有理数账；每条包含 8 之前的所有给定事件及一个事后提议事件，按约定将其后至 H=8 设为空。该事件带是一个确定性的有限窗样例，不是无条件 Poisson 概率计算。fixture 1 在 a1 同时完成 [b1,a1] 与 [c1,a1]；B=0，D=Δ=748225/36864。fixture 2 在 b2 处理相同来源的第二次独立事件而没有混同，B=D=Δ=0。事件 ID 一一重命名重放保留各空间量、成员及代表。额外自检两个不同事件产生同一几何区域时保持独立键且第二次 Δ=0。

本文件还提供 `poisson_history`：使用单一总率指数时钟和按 q_i/Σq 抽取标记，独立每次到达，固定 seed 且设置事件上限。时间和抽样是浮点模拟，不是精确概率证据。按照 fixture 冻结的共享运行预算 stochastic_runs=0，本次未运行研究性随机试验。`--selftest` 使用 seed 17 调用 `poisson_history` 两次，生成两条随机事件带并检查二者相同；这是随机数发生器复现性自检，不是研究性蒙特卡洛试验。有限窗补偿等式也未由本计算证明。

两个 fixture 仅作诊断：n=3 而实际 near 在 n<256 为空，原始 admission、真实剩余 q 和高 T 条件没有通过；几何分数精确不产生对原一般命题的证明。

复现（Python 3.12 数学环境，`geometry_kernel.py` 与冻结 fixture 同目录）：

```sh
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r663-20261115/firstkey_engine.py --selftest
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r663-20261115/firstkey_engine.py --fixture /Volumes/data/CodexTemp/centered-cube-r663-20261115/geometry_fixture.json /Volumes/data/CodexTemp/centered-cube-r663-20261115/PROCESS_RESULTS.json
```

两条命令均已执行并通过。运行前实测机器为 12 逻辑核、16 GiB，聚合 CPU 使用率约 1186.5%；共享预算因此只使用上述有限精确核验。

固定的全局流中，如果两个 target 的前 k 个来源标签序列相同，那么它们对应的全局事件 ID 序列也相同；来源标签序列不会在同一流上形成不同事件键。事件 ID 重命名重放是在整个事件带上一一改名，核验标识命名不影响几何与分组，并非上述不可能情形的反例。
