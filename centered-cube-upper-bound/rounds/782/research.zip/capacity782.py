"""Check the common source transfer and the first stopping cell on physical parents."""
from fractions import Fraction as Q
from itertools import product
from functools import cache
import json
import sys

from flint import arb, ctx
import transport782 as base

ctx.prec = 256
zero = Q(0)
one = Q(1)


def total(seq):
    return sum(seq, zero)


def interval(center, radius):
    return center - radius, center + radius


def intersect(*items):
    return max(x[0] for x in items), min(x[1] for x in items)


def cases(count, dyadic_level, share):
    # Four labelled endpoints are unnecessary. Both next arms may reuse the old u.
    coords = [("0", "1"), ("-11/4", "9/8"), ("3", "19/16"),
              ("-3/2", "25/16"), ("3/2", "13/8"), ("-3/4", "7/4")]
    coords = [(Q(c), Q(s)) for c, s in coords[:3 + count]]
    A = [interval(c, s) for c, s in coords]
    E = [interval(c, s / 128) for c, s in coords]
    mu = base.mu_axis
    m = list(map(mu, A))
    assert m == [hi - lo for lo, hi in A]
    assert all(mu(intersect(e, f)) == 0 for k, e in enumerate(E) for f in E[:k])
    I = [(b-a)*Q(8-(k%3), 8) for k, (a,b) in enumerate(E)]
    vset = list(range(3,len(A)))
    future = list(range(3))
    rates = [j / mass for j,mass in zip(I,m)]
    degrees = {j: total(rates[i]*mu(intersect(A[j], A[i]))/m[j]
                         for i in range(len(A)) if i != j) for j in vset}
    Y = (zero, Q(1,64))
    assert all(intersect(Y, A[j]) == Y for j in [0,*vset])
    lam = rates[0] * mu(Y)
    h = {i:rates[i] for i in vset}
    H = total(rates[i] for i in range(len(A)) if intersect(A[i], Y)==Y)
    # Dyadic source partitions and original parents are both exact on these atoms.
    outer = Q(8)
    grid = [-outer + 2*outer*Q(i,2**dyadic_level) for i in range(2**dyadic_level+1)]
    cuts = sorted(set(grid).union(x for pair in A for x in pair))
    atoms = list(zip(cuts, cuts[1:]))
    size = list(map(mu, atoms))
    mark = [{i for i in range(len(A)) if intersect(cell, A[i]) == cell} for cell in atoms]
    e = {i:[(total(rates[g] for g in future if g in label)/(m[i]*degrees[i])
             if i in label else zero) for label in mark] for i in vset}
    p = {i:total(s*v for s,v in zip(size,e[i])) for i in vset}
    assert all(0<p_i<=1 for p_i in p.values())
    T = total(h[i]*p[i] for i in vset)
    pi = {i:h[i]*p[i]/T for i in vset}
    assert lam*T == total(
        I[0]*I[i]*I[g]*mu(Y)*mu(intersect(A[i],A[g]))
        /(m[0]*m[g]*m[i]**2*degrees[i]) for i in vset for g in future
    )
    where = {x:k for k,x in enumerate(cuts)}
    Rmass = lam*T
    weighted = lam*T*T/H
    source_cover = [total(pi[i] for i in vset if i in label) for label in mark]

    def upper_tail(values, ids, mass):
        remain = mass
        weights = {}
        for j in sorted(ids, key=lambda b:(-values[b], b)):
            used = min(remain, size[j])
            if used:
                weights[j] = used / mass
                remain -= used
            if remain == 0:
                break
        assert sum(weights.values()) == 1
        return weights, total(values[j]*q for j,q in weights.items())

    @cache
    def node(depth, k):
        span = Q(16,2**depth)
        a = -outer + k*span
        ids = tuple(range(where[a], where[a+span]))
        mass = total(size[j] for j in ids)
        E_i = {i:total(size[j]*e[i][j] for j in ids) for i in vset}
        obs = total(h[i]*E_i[i] for i in vset)
        if not obs:
            return ids, mass, E_i, obs, {}, zero, zero, {}
        nu = {i:h[i]*E_i[i]/obs for i in vset}
        full = {j:source_cover[j]*total(nu[i] for i in vset if i in mark[j]) for j in ids}
        qx,score = upper_tail(full, ids, share*mass)
        private = total(nu[i]*upper_tail(
            {j:source_cover[j]*int(i in mark[j]) for j in ids},ids,share*mass
        )[1] for i in vset)
        assert 0 <= score <= private <= 1
        return ids, mass, E_i, obs, nu, score, private, qx

    levels = [(d,k) for d in range(dyadic_level+1) for k in range(2**d)]
    worst_private_gap = max(node(*q)[6]-node(*q)[5] for q in levels)
    results = []
    for threshold in (Q(3,10), Q(11,20), Q(17,20), Q(19,20)):
        first = []
        pending = [(0,0)]
        while pending:
            d,k = pending.pop()
            _,_,_,obs,_,score,_,_ = node(d,k)
            if not obs:
                continue
            if score>threshold:
                first.append((d,k))
            elif d<dyadic_level:
                pending.extend([(d+1,2*k),(d+1,2*k+1)])
        root_share = zero
        unfiltered = zero
        by_nodes = zero
        flows = {(i,j):zero for i,j in product(vset,repeat=2)}
        columns = [zero]*len(atoms)
        for q in first:
            ids,mass,E_i,obs,nu,score,_,qx = node(*q)
            root_share += obs/T
            by_nodes += lam*T/H*obs*score
            for b,t in qx.items():
                columns[b] += mass*t/size[b]
            for i,j in flows:
                sol = total(t for b,t in qx.items() if i in mark[b] and j in mark[b])
                flows[i,j] += lam/H*h[i]*p[i]*h[j]*E_i[j]*sol
        for q in levels:
            obs,score = node(*q)[3],node(*q)[5]
            if score>threshold:
                unfiltered += obs/T
        assert by_nodes==total(flows.values())
        assert 0<=root_share<=1 and root_share<=unfiltered
        assert max(columns)<=1/share
        assert by_nodes >= threshold*weighted*root_share
        cap = max(m[i]*max(e[i]) for i in vset)
        pair_reports = []
        for eta in (Q(1,8), Q(1,4)):
            small = {(i,j) for i,j in flows if mu(intersect(A[i],A[j]))<=eta*min(m[i],m[j])}
            large_actual = total(v for ij,v in flows.items() if ij not in small)
            small_actual = total(flows[ij] for ij in small)
            large_rhs = lam/H*total(h[i]*p[i]*h[j]*p[j] for i,j in flows if (i,j) not in small)
            small_rhs = lam/H*total(h[i]*p[i]*h[j]*max(e[j])*mu(intersect(A[i],A[j]))/share for i,j in small)
            assert large_actual<=large_rhs and small_actual<=small_rhs<=Rmass*cap*eta/share
            pair_reports.append({"eta":eta,"small_physical_pairs":len(small),
                                 "large_actual":large_actual,"large_rhs":large_rhs,
                                 "small_actual":small_actual,"small_intersection_rhs":small_rhs})
        results.append({"threshold":threshold,"first_stops":sorted(first),"first_original_fraction":root_share,
                        "wrong_repeated_levels_fraction":unfiltered,"combined_payment":by_nodes,
                        "actual_peak":Rmass,"max_column_density":max(columns),"bounds":pair_reports})
    return {"active_middle_count":count,"dyadic_last_depth":dyadic_level,"top_source_fraction":share,
            "A":A,"E":E,"true_I":I,"old_full_degree":degrees,"physical_mu":m,"pi":pi,"H":H,"T":T,
            "largest_advantage_from_illegally_seeing_central_label":worst_private_gap,"decisions":results}


def scalar(n):
    # Original wide-window model, one entire 1/K stratum per specified coordinate.
    l = arb(n+2).log()
    r_ball = arb(n).sqrt()*l**2
    r = int(r_ball.ceil().unique_fmpz())
    ideal = (3*arb(n)/(74*arb(n).log())).sqrt()
    K = max(48, int((ideal+arb(1)/2).floor().unique_fmpz())-20)
    log_alpha = arb(n+1).log() - arb(r)/256
    if log_alpha>=0:
        return {"n":n,"K":K,"admissible_alpha_below_one":False}
    t = 1/l**2
    # An entire product stratum has at least (K+20)^(-d) of the source.
    bound = -(arb(4).log()+log_alpha+t.log())/arb(K+20).log()
    floor = int(bound.floor().unique_fmpz())
    assert arb(floor)<bound and arb(floor+1)>bound
    return {"n":n,"K":K,"admissible_alpha_below_one":True,
            "log_alpha":log_alpha.str(18),"d_max":min(n,floor) if floor>=0 else None}



def profiles(half_width, alpha, threshold):
    centers=[Q(x) for x in ("0","-11/4","3","-3/2","3/2","-3/4")]
    radii=[Q(x) for x in ("1","9/8","19/16","25/16","13/8","7/4")]
    A=[interval(c,s) for c,s in zip(centers,radii)]
    I=[s*Q(8-k%3,512) for k,s in enumerate(radii)]
    E=[interval(c,s/128) for c,s in zip(centers,radii)]
    assert all(v<=b-a for v,(a,b) in zip(I,E))
    assert all(intersect(x,y)[0]>=intersect(x,y)[1] for i,x in enumerate(E) for y in E[:i])
    # The fixture enlarges only the finite support of the same mean-one measure.
    def prim(x):
        whole=x//base.PERIOD
        tail=x-whole*base.PERIOD
        return whole*base.PERIOD+tail/2+max(zero,tail-base.PERIOD/2)
    def smass(cell):
        a,b=intersect(cell,(-half_width,half_width))
        return prim(b)-prim(a) if a<b else zero
    S=smass((-half_width,half_width))
    m=list(map(smass,A))
    assert m==[2*s for s in radii]
    rho=[x/y for x,y in zip(I,m)]
    mids=range(3,6)
    parents=range(len(A))
    degree={i:total(rho[j]*smass(intersect(A[i],A[j]))/m[i] for j in parents if i!=j) for i in mids}
    prob={i:total(rho[j]*smass(intersect(A[i],A[j]))/(m[i]*degree[i]) for j in range(3)) for i in mids}
    edges=sorted({-half_width,half_width,*(r for a in A for r in a)})
    cells=list(zip(edges,edges[1:]))
    mass=list(map(smass,cells))
    def signature(y):
        return frozenset(i for i in mids if A[i][0]<=y<=A[i][1])
    sig=[signature((a+b)/2) for a,b in cells]
    all_sigs=set(sig).union(signature(x) for x in edges)
    def field(prototype, kind):
        return total(prototype[j-3] for j in kind)
    def upper_mean(values):
        used=alpha*S
        val=zero
        for i in sorted(range(len(cells)),key=lambda k:-values[k]):
            take=min(used,mass[i])
            val+=take*values[i]
            used-=take
            if not used: break
        return val/(alpha*S)
    anchors=[]
    pool=[]
    for y,cell in enumerate(cells):
        active=sig[y]
        T=total(rho[j]*prob[j] for j in active)
        start=total(rho[u] for u in range(3) if intersect(cell,A[u])==cell)
        if start*T:
            pi=tuple(rho[i]*prob[i]/T if i in active else zero for i in mids)
            assert field(pi,active)==1
            score=upper_mean([field(pi,s)**2 for s in sig])
            anchors.append((y,pi,start*T,score))
            if pi not in pool: pool.append(pi)
    density_cap=max(row[2] for row in anchors)
    rows=[]
    for count in sorted({1,3,len(pool)}):
        # One dictionary is frozen before looking at any individual peak.
        choices=pool[:count]
        high=[[k for k,tag in enumerate(sig) if field(law,tag)>=Q(7,8)] for law in choices]
        masses=[total(mass[k] for k in Bset) for Bset in high]
        limit=Q(16,9)*alpha*threshold*S
        allowed={k for idx,Bset in enumerate(high) if masses[idx]<=limit for k in Bset}
        paid=survived=zero
        for y,pi,rate,score in anchors:
            if score>threshold: continue
            survived+=mass[y]*rate
            matches=[j for j,law in enumerate(choices)
                     if max(abs(field(pi,s)-field(law,s)) for s in all_sigs)<=Q(1,8)]
            if matches:
                assert y in allowed and all(y in high[j] and masses[j]<=limit for j in matches)
                paid+=mass[y]*rate
        union=total(mass[k] for k in allowed)
        assert paid<=min(survived,density_cap*union) and union<=count*limit
        rows.append({"prototypes":count,"original_after_root":survived,"captured_actual_mass":paid,
                     "small_core_union_true_mu":union,"all_core_masses":masses,"single_core_limit":limit,
                     "actual_first_price_density_sup":density_cap})
    return {"source_support_half_width":half_width,"alpha":alpha,"threshold":threshold,
            "source_mass":S,"actual_anchor_regions":len(anchors),"distinct_profiles":len(pool),"dictionary_results":rows}



def grid_shifts(n):
    # A unit source cube straddles all coordinate boundaries of the unshifted grid.
    # Each cube below has full edge 8*n and each halo adds 4 at both faces.
    def axis_count(z, shift):
        step=8*n
        left=(z-8*shift)//step
        return sum(8*shift+j*step-4 <= z < 8*shift+(j+1)*step+4
                   for j in (left-1,left,left+1))
    test=[Q(1,4),Q(-1,4),Q(9,2),Q(63,4)]
    values=[[axis_count(x,k) for k in range(n)] for x in test]
    assert all(sum(row)==n+1 for row in values)
    best=one
    bad=2**n
    expected=Q(n+1,n)**n
    exhaustive=n<=4
    if exhaustive:
        xs=[test[k%len(test)] for k in range(n)]
        actual=total(base.prod(axis_count(x,shift) for x,shift in zip(xs,shifts))
                     for shifts in product(range(n),repeat=n))/n**n
        assert actual==expected
    assert min(values[0])**n==best and max(values[0])**n==bad
    return {"n":n,"axis_counts":values,"unshifted_multiplicity_for_core":bad,
            "minimal_multiplicity_for_core":best,"exact_mean":expected,
            "full_enumeration":exhaustive}


if __name__=="__main__":
    data = [cases(n,d,alpha) for n,d in [(2,3),(3,4),(3,6)] for alpha in (one,Q(1,4),Q(1,16))]
    lowers = [scalar(n) for n in (256,1024,4096,2**16,2**24,2**40,2**80)]
    assert any(item["largest_advantage_from_illegally_seeing_central_label"]>0 for item in data)
    assert any(x["wrong_repeated_levels_fraction"]>1 for row in data for x in row["decisions"])
    dicts=[profiles(Q(s),a,t) for s in (8,32,64) for a,t in [(Q(1,8),Q(1,8)),(Q(1,4),Q(7,32)),(Q(1,2),Q(7,32))]]
    assert any(0 < d["captured_actual_mass"] < d["original_after_root"] for x in dicts for d in x["dictionary_results"])
    print(json.dumps({"translated_cubes":[grid_shifts(n) for n in (2,4,8,32,128)],"profile_dictionary":dicts,"python":sys.version.split()[0],"flint":base.flint_version,"arb_bits":ctx.prec,
        "command":"python -B capacity782.py","fixture_scope":"AC periodic true source in 1D, all old neighbors in d, genuine marked integrals and disjoint receivers; the diagnostic eta tests physical pairs and does not assert all original hard or path gates.",
        "fixtures":data,"wide_window_scalar":lowers},indent=2,sort_keys=True,default=str))
