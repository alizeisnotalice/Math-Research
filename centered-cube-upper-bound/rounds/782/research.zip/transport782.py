#!/usr/bin/env python3
"""R782 exact and ball-arithmetic audit of common right-price transport."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
import json
import sys

from flint import __version__ as flint_version, arb, ctx


ctx.prec=256
PERIOD=F(1,32)


def ss(values):
    return sum(values,F(0))


def prod(values):
    r=F(1)
    for v in values:
        r*=v
    return r


def interval(*xs):
    return tuple(map(F,xs))


def length(i):
    return max(F(0),i[1]-i[0])


def section(*xs):
    return max(i[0] for i in xs),min(i[1] for i in xs)


def meet(*boxes):
    return tuple(section(*axis) for axis in zip(*boxes))


def q(c,s):
    return tuple((a-s,a+s) for a in c)


def contains(a,b):
    return all(x<=u<=v<=y for (x,y),(u,v) in zip(a,b))


def volume(x):
    return prod(map(length,x))


def mu_axis(i):
    lo,hi=section(i,interval(-8,8))
    if lo>=hi:
        return F(0)

    def primitive(t):
        h=t//PERIOD
        f=t-h*PERIOD
        return h*PERIOD+f/2+max(F(0),f-PERIOD/2)

    return primitive(hi)-primitive(lo)


def mu(b):
    return prod(map(mu_axis,b))


def B(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def dyadic_left(volume):
    base=1
    while base>volume:
        base=F(base,2)
    while 2*base<=volume:
        base*=2
    return base


def show(x):
    return x.str(22)


def get_model(n,mode):
    records=[]
    contexts={}
    centres_used=set()

    def add(R,center,radius,mark,I_ratio=F(1)):
        parent=q(center,radius)
        e=q(center,radius/1024)
        assert contains(parent,mark) and contains(parent,e)
        label=len(records)
        records.append((R,parent,mark,e,volume(e)*I_ratio,radius))
        return label

    if n==1:
        for R in (1,2,4):
            u_center=F(-R,4)
            g_center=F(R,4)
            u=add(R,(u_center,),F(5*R,8),q((u_center,),F(5*R,8)))
            g=add(R,(g_center,),F(3*R,4),q((g_center,),F(3*R,4)),F(7,8))
            patterns={
                "identical":[interval("-3/8","3/8")]*2,
                "partial":[interval("-3/8","1/8"),interval("-1/16","1/4")],
                "near_separated":[interval("-3/8","1/128"),interval("-1/128","3/8")],
            }[mode]
            vs=tuple(add(R,(c*R,),s*R,(tuple(R*t for t in window),),f)
                     for c,s,window,f in zip(
                         interval("-3/32","3/32"),interval("7/8","15/16"),patterns,(F(1),F(3,4))))
            contexts[R]=u,g,vs
            centres_used.update(vs)
    else:
        R=2
        xc=interval("-1/4","-1/4")
        zc=interval("1/4","1/4")
        u=add(R,xc,F(1),q(xc,F(1)))
        g=add(R,zc,F(9,8),q(zc,F(9,8)),F(7,8))
        patterns={
            "identical":[interval("-1/2","1/2")]*3,
            "partial":[interval("-1/2","1/8"),interval("-1/16","1/4"),interval("-1/8","1/2")],
            "near_separated":[interval("-1/2","1/128"),interval("-1/2","1/128"),interval("-1/128","1/2")],
        }[mode]
        vs=tuple(add(R,w,r,(cut,interval("-1/2","1/2")),f)
                 for w,r,cut,f in zip(
                     [interval("-1/16",0),interval(0,"1/16"),interval("1/16",0)],
                     interval("11/8","3/2","7/4"),patterns,(F(1),F(3,4),F(7,8))))
        contexts[R]=u,g,vs
        centres_used.update(vs)
    O,A,C,E,I,radii=map(tuple,zip(*records))
    assert all(not volume(meet(e,f)) for i,e in enumerate(E) for f in E[:i])
    m=tuple(map(mu,A))
    assert m==tuple(map(volume,A))
    assert all(0<w<=volume(e) for w,e in zip(I,E))
    assert all(F(R,2)<=s<R for R,s in zip(O,radii))
    ks=range(len(A))
    true_C={(i,j):mu(meet(C[i],C[j])) for i,j in product(ks,repeat=2)}
    K={(i,j):v/(m[i]*m[j]) if i!=j else F(0) for (i,j),v in true_C.items()}
    degree={v:ss(I[g]*K[v,g] for g in ks) for v in centres_used}
    return O,A,C,E,I,radii,m,K,true_C,degree,contexts


def one_case(n,mode):
    O,A,C,E,I,radii,m,K,true_C,degree,contexts=get_model(n,mode)
    Y=q((F(0),)*n,F(1,256))
    edges=[sorted({F(-8),F(8),*(z for b in (*A,*C,Y) for z in b[j])}) for j in range(n)]
    cells=list(product(*(list(zip(e,e[1:])) for e in edges)))
    lam_total=mass_total=F(0)
    left_integral=right_integral=pairwise_integral=arb(0)
    maximal_mix=F(0)
    model_diagnostics={}
    for R,(u,g,vs) in contexts.items():
        future=(u,g)
        assert all(m[j]<m[v] and K[v,j]>0 for v in vs for j in future)
        assert contains(C[u],Y) and all(contains(C[v],Y) for v in vs)
        lam=I[u]/m[u]*mu(Y)
        H_v={v:I[v]/m[v] for v in vs}
        H=ss(I[v]/m[v] for v in range(len(A)) if O[v]==R and contains(C[v],Y))
        assert H>ss(H_v.values())>0
        total_direct=F(0)
        density=[]
        for cell in cells:
            mu_z=mu(cell)
            assert mu_z>0
            by_original={}
            by_switch={}
            for v in vs:
                source_amp=I[u]*I[v]*K[u,v]*mu(meet(Y,C[u],C[v]))/true_C[u,v]
                q0=ss(source_amp*I[j]*K[v,j]*mu(meet(cell,C[v],C[j]))/(degree[v]*true_C[v,j])
                      for j in future)
                by_original[v]=q0/(lam*H_v[v]*mu_z)
                private=ss(I[j]/m[j] for j in future if contains(C[j],cell)) if contains(C[v],cell) else F(0)
                by_switch[v]=private/(m[v]*degree[v])
            assert by_original==by_switch
            total_direct+=lam*mu_z*ss(H_v[v]*x for v,x in by_original.items())
            if any(by_switch.values()):
                density.append((cell,mu_z,by_switch))
        p={v:ss(w*row[v] for _,w,row in density) for v in vs}
        assert all(0<t<1 for t in p.values())
        T=ss(p[v]*H_v[v] for v in vs)
        pi={v:p[v]*H_v[v]/T for v in vs}
        assert ss(pi.values())==1 and lam*T==total_direct>0
        lam_total+=lam
        mass_total+=total_direct
        left=right=arb(0)
        original_partition_acc=F(0)
        coarse_partition_acc=F(0)
        bins={v:dyadic_left(m[v]) for v in vs}
        for _,w,row in density:
            t=ss(H_v[v]*row[v] for v in vs)
            post={v:H_v[v]*row[v]/t for v in vs}
            assert sum(post.values())==1
            for v,v2 in product(vs,repeat=2):
                # Positivity means equality after squaring is exact equality of root terms.
                aa=(T*t/H)**2*pi[v]*post[v]*pi[v2]*post[v2]
                bb=(H_v[v]*H_v[v2]/H)**2*p[v]*row[v]*p[v2]*row[v2]
                c=(T*T/H)**2*(pi[v]*pi[v2])**2*(row[v]/p[v])*(row[v2]/p[v2])
                assert aa==bb==c
            Aff=sum((B(pi[v]*post[v]).sqrt() for v in vs),arb(0))
            left+=B(lam*w*t*T/H)*Aff**2
            weighted_root=sum((B(H_v[v])*B(p[v]*row[v]).sqrt() for v in vs),arb(0))
            right+=B(lam*w/H)*weighted_root**2
            original_partition_acc += w*t*max(post.values())/T
            by_bin={b:ss(post[v] for v in vs if bins[v]==b) for b in set(bins.values())}
            coarse_partition_acc += w*t*max(by_bin.values())/T
        assert (left-right).contains(0)
        left_integral+=left
        right_integral+=right
        cap=lam*T*T/H
        pair_aff=arb(0)
        pair_max=F(0)
        pairs={}
        for v,v2 in product(vs,repeat=2):
            maximal=F(0)
            aff=arb(0)
            fake=fine=F(0)
            for cell,w,row in density:
                k0,k1=row[v]/p[v],row[v2]/p[v2]
                maximal+=w*min(k0,k1)
                aff+=B(w)*B(k0*k1).sqrt()
                fake+=w*w*k0*k1
                lo,hi=cell[0]
                part=((lo,(lo+hi)/2),*cell[1:])
                first=mu(part)
                assert 0<first<w
                fine+=(first**2+(w-first)**2)*k0*k1
            assert 0<fine<fake and maximal>0  # all trial marks share a positive central interval
            assert (aff-B(maximal)).contains(0) or aff>B(maximal)
            pair_aff+=B(pi[v]*pi[v2])*aff
            pair_max+=pi[v]*pi[v2]*maximal
            if v<v2:
                pairs[str((v,v2))]={"common_price_maximal_probability":maximal,
                                    "Hellinger_between_right_laws":show(aff),
                                    "independent_exact_equal_price_probability":F(0),
                                    "wrong_same_cell_probability":fake,"same_cell_after_bisection":fine}
        assert (B(cap)*pair_aff-left).contains(0)
        assert (pair_aff-B(pair_max)).contains(0) or pair_aff>B(pair_max)
        if mode=="identical":
            assert pair_max==1
        if mode=="partial" and n==1:
            assert pair_aff>B(pair_max)
        pairwise_integral+=B(cap)*pair_aff
        maximal_mix+=cap*pair_max
        coarse_prior=max(ss(pi[v] for v in vs if bins[v]==b) for b in set(bins.values()))
        assert 0<max(pi.values())<=original_partition_acc<=coarse_partition_acc<=1
        assert coarse_prior<=coarse_partition_acc
        model_diagnostics[R]={"lambda_a":lam,"H":H,"true_unweighted_R_mass":total_direct,
            "ancestor_T":T,"p_by_centre":p,"prior":pi,"old_full_degree_by_centre":{v:degree[v] for v in vs},
            "nonzero_true_right_price_cells":len(density),"prior_only_normalization_cap_lambda_T_squared_over_H":cap,
            "affinity_squared_weighted_integral_over_that_cap":show(left/B(cap)),
            "coupled_same_price_weighted_integral_over_that_cap":pair_max,
            "off_diagonal_true_right_price_pairs":pairs,
            "volume_bucket_left_end_by_centre":bins,"center_MAP_prior_and_post":[max(pi.values()),original_partition_acc],
            "volume_bucket_MAP_prior_and_post":[coarse_prior,coarse_partition_acc]}
    assert (left_integral-right_integral).contains(0) and (left_integral-pairwise_integral).contains(0)
    return {"n":n,"shape":mode,"physical_parents":A,"true_marks":C,"disjoint_owner_boxes":E,
            "original_I":I,"actual_m":m,"original_absolute_radius_upper_ends":O,
            "same_anchor_actual_Y":Y,"geometric_masses_equal_actual_source_mass":True,
            "lambda_total":lam_total,"actual_old_R_total":mass_total,"by_context":model_diagnostics,
            "affinity_identity_three_integrations":[show(left_integral),show(right_integral),show(pairwise_integral)],
            "maximal_coupling_integral_exact":maximal_mix,
            "analytic_diagonal_scope":"independent draws have zero probability of exactly equal prices by absolute continuity; the reported cell collision is a distinct discretization event",
            "old_graph_scope":"true positive marked intersections and predetermined smaller arms u and g in the same radius octave; full old degree retains every physical neighbor; high-dimensional original masks are outside the fixture"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint_version,"precision_bits":ctx.prec,
                      "arithmetic":"Fraction for all exact path, square, coupling and classification identities, Arb for square roots",
                      "command":"python -B transport782.py",
                      "mu":"period 1/32 each axis, densities 1/2 then 3/2 on [-8,8]^n; no atoms",
                      "models":[one_case(n,mode) for n,mode in product((1,2),("identical","partial","near_separated"))]},
                     indent=2,sort_keys=True,default=str))
