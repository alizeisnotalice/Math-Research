#!/usr/bin/env python3
"""R782 true dyadic density stops and one shared price replacement."""

from fractions import Fraction as F
from itertools import combinations, product
import json
import sys


def ss(items):
    return sum(items,F(0))


def prod(items):
    out=F(1)
    for q in items:
        out*=q
    return out


def length(i):
    return max(F(0),i[1]-i[0])


def section(*ranges):
    return max(i[0] for i in ranges),min(i[1] for i in ranges)


def intersect(*boxes):
    return tuple(section(*axis) for axis in zip(*boxes))


def box(c,r):
    return tuple((t-r,t+r) for t in c)


def contains(p,q):
    return all(x<=a<=b<=y for (x,y),(a,b) in zip(p,q))


def vol(q):
    return prod(map(length,q))


DOMAIN=(F(-8),F(8))


def m1(interval):
    lo,hi=section(interval,DOMAIN)
    if not lo<hi:
        return F(0)

    def primitive(t):
        period=t//2
        u=t-2*period
        return 2*period+max(F(0),u-F(1,2))+max(F(0),u-F(3,2))

    return primitive(hi)-primitive(lo)


def mu(p):
    return prod(map(m1,p))


def stopping(n,H):
    root=(DOMAIN,)*n
    leaves=[]
    checks=[]
    assert mu(root)<=H*vol(root)

    def dfs(p,depth,parent_density):
        mass=mu(p)
        volume=vol(p)
        d=mass/volume
        if d>H:
            assert parent_density<=H<d<=2*H
            leaves.append((p,mass,True))
            checks.append((depth,d,parent_density))
            return
        sizes=list(map(length,p))
        if max(sizes)==F(1,2):
            # Every interval is contained in one exact density phase.
            assert all(i[0]*2==int(i[0]*2) for i in p)
            leaves.append((p,mass,False))
            return
        axis=sizes.index(max(sizes))
        lo,hi=p[axis]
        mid=(lo+hi)/2
        for child in ((lo,mid),(mid,hi)):
            q=p[:axis]+(child,)+p[axis+1:]
            dfs(q,depth+1,d)

    dfs(root,0,F(0))
    assert ss(m for _,m,_ in leaves)==mu(root)
    assert ss(vol(q) for q,_,_ in leaves)==vol(root)
    return leaves,checks


def model(n):
    coords=[(F(0),)*n,(F(3),)+(F(0),)*(n-1),
            (F(4),)+(F(0),)*(n-1),(F(0),)*n]
    radii=[F(11,8),F(7,4),F(9,8),F(13,8)]
    if n==2:
        coords.extend([(F(1),F(0)),(F(0),F(1))])
        radii.extend([F(25,16),F(29,16)])
    A=[box(c,r) for c,r in zip(coords,radii)]
    own_half=F(1,256*n)
    E=[]
    for i,(c,r) in enumerate(zip(coords,radii)):
        offset=-2*own_half if i==0 else 2*own_half if i==3 else F(0)
        owner=box((c[0]+offset,*c[1:]),own_half)
        assert contains(box(c,r/(32*n)),owner)
        E.append(owner)
    assert all(not vol(intersect(a,b)) for i,a in enumerate(E) for b in E[:i])
    I=list(map(vol,E))
    m=list(map(mu,A))
    assert m==list(map(vol,A))
    for c,s in zip(coords,radii):
        for x in c:
            assert x==int(x)
            cuts={F(0),s}
            cuts.update(abs(x-F(k,2)) for k in range(-16,17) if abs(x-F(k,2))<s)
            assert all(m1((x-r,x+r))==2*r for r in cuts)
    vertices=range(len(A))
    s={(i,j):mu(intersect(A[i],A[j])) for i,j in product(vertices,repeat=2)}
    K={(i,j):v/(m[i]*m[j]) if i!=j else F(0) for (i,j),v in s.items()}
    d={v:ss(I[u]*K[u,v] for u in vertices) for v in vertices}
    arms={v:tuple(u for u in vertices if m[u]<m[v] and K[u,v]>0) for v in vertices}
    assert all(d.values()) and all(arms[v] for v in (1,3))
    return A,E,m,I,s,K,d,arms,vertices


def certify(n,H):
    A,E,m,I,s,K,d,arms,vertices=model(n)
    leaves,checks=stopping(n,H)
    gamma=F(1,16)
    huge=1+gamma/n
    expanded=[]
    for q in A:
        expanded.append(tuple(((a+b)/2-(b-a)*huge/2,(a+b)/2+(b-a)*huge/2) for a,b in q))
    stopped=[q for q,_,hit in leaves if hit]
    outside=ss(mass for _,mass,hit in leaves if not hit)
    assert stopped and outside>0

    original=shared=private=pooled=pooled_private=F(0)
    positive_private_bias=negative_private_bias=None
    for v in vertices:
        for u in arms[v]:
            old_joint=I[u]*I[v]*K[u,v]
            right_prob=ss(I[g]*K[v,g] for g in arms[v])/d[v]
            pair_cells=[]
            for p,mass,hit in leaves:
                marked=mu(intersect(A[u],A[v],p))
                if not marked:
                    continue
                if hit:
                    common=vol(intersect(p,expanded[u],expanded[v]))/vol(p)
                    independent=prod(vol(intersect(p,expanded[t]))/vol(p) for t in (u,v))
                else:
                    common=independent=F(1)
                pair_cells.append((marked,common,independent))
                if hit and right_prob and independent!=common:
                    evidence={"parents_u_v":[u,v],"first_density_stop":p,"true_left_mu":marked,
                              "shared_replacement_probability":common,"private_probe_probability":independent}
                    if independent>common and positive_private_bias is None:
                        positive_private_bias=evidence
                    if independent<common and negative_private_bias is None:
                        negative_private_bias=evidence
            assert ss(w for w,_,_ in pair_cells)==s[u,v]
            common_sum=ss(w*c for w,c,_ in pair_cells)
            independent_sum=ss(w*c for w,_,c in pair_cells)
            for g in arms[v]:
                raw=old_joint*I[g]*K[v,g]/d[v]
                original+=raw
                shared+=raw*common_sum/s[u,v]
                private+=raw*independent_sum/s[u,v]
            coefficient=I[u]*I[v]/(m[u]*m[v])
            pooled+=coefficient*right_prob*common_sum
            pooled_private+=coefficient*right_prob*independent_sum
            bar_two_fathers=ss((mass/vol(p))*vol(intersect(p,expanded[u],expanded[v]))
                               for p,mass,_ in leaves)
            assert right_prob*common_sum<=bar_two_fathers
    assert (shared,private)==(pooled,pooled_private)
    assert 0<shared<=original and 0<private<=original
    if H==F(5,4):
        assert positive_private_bias and negative_private_bias

    weights=[I[v]/m[v] for v in vertices]
    # Pair expansion and a second direct cell integration under the same shared x.
    by_pairs=ss(weights[u]*weights[v]*ss(mass*vol(intersect(p,expanded[u],expanded[v]))/vol(p)
                                         for p,mass,_ in leaves)
                for u,v in product(vertices,repeat=2))
    direct=F(0)
    for p,mass,_ in leaves:
        if not mass:
            continue
        cuts=[sorted({*axis,*(x for lift in expanded for x in lift[j]
                             if axis[0]<x<axis[1])}) for j,axis in enumerate(p)]
        for cell in product(*(list(zip(z,z[1:])) for z in cuts)):
            load=ss(weights[u] for u in vertices if contains(expanded[u],cell))
            direct+=mass/vol(p)*vol(cell)*load**2
    assert shared<=direct==by_pairs

    impure_mu_passes=0
    geometric_passes=0
    geometric_failures=0
    lebesgue_failure=None
    for P in stopped:
        mP=mu(P)
        for u,v in combinations(vertices,2):
            A0,A1=A[u],A[v]
            both=mu(intersect(P,A0,A1))
            old_mu=[mu(intersect(P,a0))/mP for a0 in (A0,A1)]
            old_vol=[vol(intersect(P,a0))/vol(P) for a0 in (A0,A1)]
            if min(old_mu)>F(3,4):
                assert mP<=2*both
                impure_mu_passes+=1
            if min(old_vol)>F(3,4):
                geometric_passes+=1
                if mP>2*both:
                    geometric_failures+=1
                    if lebesgue_failure is None or (u,v)==(4,5):
                        lebesgue_failure={"P":P,"parents":[u,v],"original_mu_P":mP,
                                          "geometric_parent_fractions":old_vol,"true_mu_parent_fractions":old_mu,
                                          "mu_P_intersection":both}
    small_expansion_failure=None
    if n==2 and H==F(5,4):
        expected=((F(1),F(2)),(F(0),F(2)))
        assert expected in stopped
        assert min(vol(intersect(expected,A[u]))/vol(expected) for u in (4,5))>F(3,4)
        assert mu(expected)==3 and mu(intersect(expected,A[4],A[5]))==F(81,64)
        assert geometric_failures>0
        lifts=[tuple(((lo+hi)/2-(hi-lo)*F(65,64)/2,(lo+hi)/2+(hi-lo)*F(65,64)/2)
                     for lo,hi in A[i]) for i in (4,5)]
        lifted_intersection=mu(intersect(expected,*lifts))
        assert min(vol(intersect(expected,Q))/vol(expected) for Q in lifts)>F(3,4)
        assert 2*lifted_intersection<mu(expected)
        small_expansion_failure={"expansion":F(65,64),"same_P_mu":mu(expected),
                                 "true_intersection_mass":lifted_intersection}
    return {"n":n,"H":H,"gamma":gamma,"real_parents":A,"true_parent_masses":m,"disjoint_E":E,
            "old_full_degree":d,"first_stop_count":len(checks),"actual_stop_depths":sorted({j for j,_,_ in checks}),
            "positive_outside_original_mu":outside,"stop_density_bounds":[min(d for _,d,_ in checks),
                                                                            max(d for _,d,_ in checks)],
            "pre_screen_Q0_total":original,"actual_shared_replacement_Q0":shared,
            "actual_private_replacement_Q0":private,"Z_gamma_squared_integral_true_mu_bar":direct,
            "private_overstates_example":positive_private_bias,"private_understates_example":negative_private_bias,
            "local_mass_test":{"true_mu_three_quarter_tests":impure_mu_passes,
                               "geometric_three_quarter_tests":geometric_passes,
                               "geometric_only_failures":geometric_failures,
                               "geometric_only_failure_witness":lebesgue_failure,
                               "actual_small_dilation_preserves_failure":small_expansion_failure},
            "scope":"finite real source and radius contracts; the original high-dimensional hard masks are outside the fixture"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B stops782.py",
                      "phase":"period 2, densities 0 on [0,1/2), 1 on [1/2,3/2), 2 on [3/2,2), tensorized on [-8,8]",
                      "models":[certify(n,H) for n,caps in
                                ((1,(F(5,4),F(7,4))),(2,(F(5,4),F(9,4)))) for H in caps]},
                     sort_keys=True,indent=2,default=str))
