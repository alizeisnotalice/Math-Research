#!/usr/bin/env python3
"""Exact face, common-corner, and binomial certificates for Round 844."""

from fractions import Fraction as Q
from itertools import combinations, product
from math import comb, factorial, isqrt, prod


def box(*intervals):
    """Turn coordinates expressed in sixteenths into a rational box."""
    return tuple((Q(left, 16), Q(right, 16)) for left, right in intervals)


def intersection(boxes, indices):
    return tuple((max(boxes[i][axis][0] for i in indices),
                  min(boxes[i][axis][1] for i in indices))
                 for axis in range(len(boxes[0])))


def contains_point(region, point):
    return all(left <= coordinate <= right
               for (left, right), coordinate in zip(region, point))


def contains_box(outer, inner):
    return all(left <= low <= high <= right
               for (left, right), (low, high) in zip(outer, inner))


def disjoint(first, second):
    return any(right < low or high < left
               for (left, right), (low, high) in zip(first, second))


def endpoint_distance(point, anchor):
    return sum(abs(value - origin) for value, origin in zip(point, anchor))


def minimum_distance(region, anchor):
    return sum(max(left - origin, origin - right, 0)
               for (left, right), origin in zip(region, anchor))


def furthest_vertex(region, anchor):
    return tuple(max(interval, key=lambda value: abs(value - origin))
                 for interval, origin in zip(region, anchor))


def center(region):
    return tuple((left + right) / 2 for left, right in region)


def offset(region, radius):
    return tuple((left - radius, right + radius) for left, right in region)


def check_family(boxes, family, anchor, candidate, radius):
    n = len(anchor)
    common = intersection(boxes, family)
    assert contains_point(common, anchor) and contains_point(common, candidate)

    tied_faces = 0
    defining = set()
    for axis, interval in enumerate(common):
        for side, face in enumerate(interval):
            attaining = [i for i in family if boxes[i][axis][side] == face]
            assert attaining
            tied_faces += len(attaining) > 1
            defining.add(min(attaining))
    assert 1 <= len(defining) <= 2 * n
    assert intersection(boxes, defining) == common

    padding = [i for i in family if i not in defining][:2 * n - len(defining)]
    exposed = defining.union(padding)
    assert len(exposed) == 2 * n and exposed <= set(family)
    assert intersection(boxes, exposed) == common

    vertex = furthest_vertex(common, anchor)
    assert endpoint_distance(vertex, anchor) == max(
        endpoint_distance(corner, anchor) for corner in product(*common))
    assert endpoint_distance(vertex, anchor) >= endpoint_distance(candidate, anchor) > radius
    assert all(contains_point(boxes[i], vertex) for i in family)
    remaining_hits = sum(contains_point(region, vertex)
                         for i, region in enumerate(boxes) if i not in exposed)
    assert remaining_hits >= len(family) - 2 * n >= 2 * n
    return len(defining), tied_faces, remaining_hits


def check_fixture(name, boxes, anchor_region, candidate_region, radius,
                  expected_full_faces):
    n = len(anchor_region)
    assert len(boxes) == 8 * n
    anchor = center(anchor_region)
    candidate = center(candidate_region)
    chosen = tuple(i for i, region in enumerate(boxes)
                   if contains_point(region, candidate))
    assert 4 * n <= len(chosen) < len(boxes)
    assert minimum_distance(candidate_region, anchor) > radius

    # Positive-width realizations: give each distinct center a small receiver
    # cube and keep its designated witness side constant throughout that cube.
    # For input density 3/2 on [-4,4]^n and lambda=1, the strict height
    # condition holds on every receiver cube. These are geometric fixtures,
    # not a claim about the size of a terminal or high-load subflow.
    displacement = Q(1, 512)
    receiver_regions = [
        tuple((coordinate - displacement, coordinate + displacement)
              for coordinate in center(region))
        for region in boxes
    ]
    assert all(disjoint(first, second)
               for first, second in combinations(receiver_regions, 2))
    support = tuple((Q(-4), Q(4)) for _ in range(n))
    receiver_mass = Q(0)
    for i, region in enumerate(boxes):
        sides = {right - left for left, right in region}
        assert len(sides) == 1 and Q(1) <= next(iter(sides)) <= Q(2)
        assert contains_box(support, offset(region, displacement))
        core = offset(region, -displacement)
        assert contains_box(core, anchor_region)
        if i in chosen:
            assert contains_box(core, candidate_region)
        else:
            assert disjoint(offset(region, displacement), candidate_region)
        volume = prod(right - left for left, right in region)
        source_mass = Q(3, 2) * volume
        assert volume < source_mass <= 2 * volume
        receiver_mass += prod(right - left for left, right in receiver_regions[i])
    assert receiver_mass > 0

    full = check_family(boxes, chosen, anchor, candidate, radius)
    assert full[0] == expected_full_faces and full[1] > 0
    families = [family for family in combinations(chosen, 4 * n) if family != chosen]
    families.append(chosen)
    outcomes = [check_family(boxes, family, anchor, candidate, radius)
                for family in families]
    print(f'{name}: n={n}, witnesses={len(boxes)}, candidate hits={len(chosen)}, '
          f'checked subfamilies={len(families)}')
    print(f'  full defining indices={full[0]}, padded size={2*n}, '
          f'tied faces={full[1]}, minimum unexposed vertex hits={min(s[2] for s in outcomes)}')
    print(f'  shared positive-width source, far candidate box, and '
          f'disjoint receiver regions: PASS (receiver volume {receiver_mass})')
    print('  input density 3/2 on [-4,4]^n, lambda=1, true strict witness height: PASS')


def tail_certificate(n):
    N = n + 2
    q = Q(1, N ** 13)
    # At B=32 log N and T>=1/sqrt(n), this verifies q_B<=q without
    # approximating sqrt(n) or exponentiating a floating-point logarithm.
    assert 16 * (n + 1) ** 2 * n <= N ** 6

    # Union over exposed index sets, then over k specific extra successes.
    robust_upper = comb(8 * n, 2 * n) * comb(6 * n, 2 * n) * q ** (2 * n)
    assert robust_upper <= Q(1, N ** 6)

    m = isqrt(n)
    if m * m < n:
        m += 1
    k = (m + 1) // 2
    half_upper = comb(m, k) * q ** k
    loose_half_upper = 2 ** m * q ** k
    assert half_upper <= loose_half_upper <= Q(1, N ** (5 * m))
    assert 5 * m >= 2 * isqrt(n) + 2
    print(f'n={n:4d} N={N:4d} q=N^-13 m={m:2d} k={k:2d}: '
          f'robust <= N^-6 PASS; half-tail <= N^-{5*m} PASS')


def uniform_axis_certificate():
    print('Uniform-coordinate product checks (finite exact evidence only):')
    d = 2
    k = d
    n = 2 * d
    length = 32 * (n + 1) * k
    for side in (Q(3, 2), Q(7, 4)):
        base_volume = side ** d
        base_mass = Q(3, 2) * base_volume
        factor = side ** k
        extended_volume = base_volume * factor
        extended_mass = base_mass * factor
        assert extended_mass / extended_volume == base_mass / base_volume == Q(3, 2)
        print(f'  d={d}, k={k}, side={side}: mass and volume factor {factor}; average=3/2 PASS')

    exterior = 4 * (n + 1) * (1 - (1 - Q(2, length)) ** k)
    exterior_upper = Q(8 * (n + 1) * k, length)
    assert exterior <= exterior_upper == Q(1, 4)
    print(f'  n={n}, k={k}, L={length}: exterior coefficient {exterior} <= 1/4 PASS')

    gamma = Q(1, 16)
    for k in (4096, 8192):
        n = 2 * k
        N = n + 2
        log_cap = (N - 1).bit_length()
        assert 2 ** (log_cap - 1) < N <= 2 ** log_cap
        radius_cap = 32 * log_cap + 1
        # The whole l1 ball has volume 2^k B^k/k!. Each normalized
        # uniform interval has length at least 1. Restriction to a
        # slice of relative mass at least gamma costs at most 1/gamma.
        numerator = gamma.denominator * (2 * radius_cap) ** k
        denominator = factorial(k)
        quotient = (denominator - 1) // numerator
        if quotient == 0:
            print(f'  k={k}, n={n}, Bcap={radius_cap}, gamma=1/16: '
                  'q<=1, b=0 (trivial bound)')
            continue
        bit_bound = quotient.bit_length() - 1
        assert numerator * (1 << bit_bound) < denominator
        assert numerator * (1 << (bit_bound + 1)) >= denominator
        print(f'  k={k}, n={n}, Bcap={radius_cap}, gamma=1/16: '
              f'q < 2^-{bit_bound} (integer certificate)')
    print('No high-load terminal is asserted by these product checks.')


def main():
    print('Round 844: exact rational face and common-corner certificates')
    print('Finite fixtures check the geometry and strict heights, not a high-load assumption.')
    one_dimensional = tuple(
        box(interval) for interval in
        [(-4, 24), (-8, 20), (-4, 28), (-12, 20), (-8, 24),
         (-12, 8), (-12, 12), (-16, 8)]
    )
    misses = tuple(box(*intervals) for intervals in
                   [((-12, 8), (-4, 16)), ((-8, 8), (-4, 12)),
                    ((-16, 8), (-8, 16)), ((-4, 16), (-12, 8)),
                    ((-4, 12), (-8, 8)), ((-8, 16), (-16, 8)),
                    ((-12, 8), (-12, 8))])
    four_faces = tuple(box(*intervals) for intervals in
                       [((0, 24), (-4, 20)), ((-8, 16), (-4, 20)),
                        ((-4, 20), (0, 24)), ((-4, 20), (-8, 16)),
                        ((0, 28), (-4, 24)), ((-12, 16), (-8, 20)),
                        ((-4, 24), (0, 28)), ((-8, 20), (-12, 16)),
                        ((-4, 20), (-4, 20))]) + misses
    padding = tuple(box(*intervals) for intervals in
                    [((0, 16), (0, 16)), ((-1, 18), (-2, 17)),
                     ((-2, 18), (-1, 19)), ((-4, 21), (-3, 22)),
                     ((0, 20), (-2, 18)), ((-4, 16), (-2, 18)),
                     ((-2, 18), (0, 20)), ((-2, 18), (-4, 16)),
                     ((-5, 21), (-6, 20))]) + misses
    check_fixture('one dimensional ties', one_dimensional,
                  box((-1, 1)), box((16, 18)), Q(3, 4), 2)
    check_fixture('four distinct two-dimensional faces', four_faces,
                  box((1, 3), (1, 3)), box((11, 13), (11, 13)), Q(1), 4)
    check_fixture('a single defining cube followed by padding', padding,
                  box((1, 3), (1, 3)), box((11, 13), (11, 13)), Q(1), 1)

    print('Exact integer and Fraction tail bounds (no decimal approximations):')
    # These comparisons also explain the simple uniform analytic bounds.
    assert 16 <= 3 ** 3
    assert 2 ** 14 <= 3 ** 20
    assert 2 ** 2 <= 3 ** 3
    for n in (1, 4, 16, 128, 1024):
        tail_certificate(n)
    uniform_axis_certificate()


if __name__ == '__main__':
    main()
