"""R844 exact exchange of two anchors on four actual witness blocks."""
from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import sys


def show(x, upper=None):
    upper = x if upper is None else upper
    assert x <= upper
    with localcontext() as ctx:
        ctx.prec = 15
        ctx.rounding = ROUND_FLOOR
        lo = Decimal(x.numerator)/Decimal(x.denominator)
        ctx.rounding = ROUND_CEILING
        hi = Decimal(upper.numerator)/Decimal(upper.denominator)
    return f"[{lo}, {hi}]"


def box(ctr, radius):
    return tuple((x-radius, x+radius) for x in ctr)


def volume(box):
    return prod(hi-lo for lo,hi in box)


def separated(a,b,extra=F(0)):
    return any(max(lo2-hi1,lo1-hi2)>extra
               for (lo1,hi1),(lo2,hi2) in zip(a,b,strict=True))


@dataclass(frozen=True)
class Row:
    X: tuple
    L: F
    D: int
    marks: tuple
    mass: F

    @property
    def v(self):
        return self.L**2


def series_log(x):
    t = (x-1)/(x+1)
    assert 0 <= t <= F(1,3)
    n = 24
    lo = 2*sum(t**(2*j+1)/(2*j+1) for j in range(n))
    rem = 2*t**(2*n+1)/((2*n+1)*(1-t*t))
    return lo,lo+rem


LOG2 = series_log(F(2))


def log_bounds(x):
    if x<1:
        lo,hi = log_bounds(1/x)
        return -hi,-lo
    k = x.numerator.bit_length()-x.denominator.bit_length()
    k -= x < F(2)**k
    lo,hi = series_log(x/(F(2)**k))
    return lo+k*LOG2[0],hi+k*LOG2[1]


def quantize(table, mapping):
    out = defaultdict(F)
    for (a,b,z,D), mass in table.items():
        out[a,mapping(b),z,D] += mass
    return dict(out)


def mutual_information(W,E):
    lower = upper = F(0)
    for cell,value in W.items():
        assert value>0 and E[cell]>0
        a,b = log_bounds(value/E[cell])
        lower += value*a
        upper += value*b
    assert 0<=lower<=upper
    return lower,upper


def report_decisions(W,E):
    print("  exact information certificates in nats; natural log enclosed by a 24-term rational series")
    Wbit,Ebit = (quantize(table,lambda b: int(b!=0)) for table in (W,E))
    Wconst,Econst = (quantize(table,lambda b: 0) for table in (W,E))
    assert Wconst==Econst
    info = mutual_information(W,E)
    bit = mutual_information(Wbit,Ebit)
    constant = mutual_information(Wconst,Econst)
    assert bit[1]<=info[0] and constant==(0,0)
    for name,result in (("original",info),("second anchor common/private bit",bit),
                        ("constant second anchor",constant)):
        print("   I(a;a-prime | z,D)",name,show(*result))
    for M in (1,2,4):
        allowed = {atom for atom,q in E.items() if W.get(atom,0)<=M*q}
        p,q = sum(W.get(atom,0) for atom in allowed),sum(E[atom] for atom in allowed)
        bound = min(F(1),M*q)
        hit = 1-(1-q)**M
        assert 0<=p<=bound<=2*hit and hit<=1
        print("   low-density event C<=",M,"W p",show(p),"E q",show(q),
              "min(1,Lq)",show(bound),"actual independent list hit",show(hit),
              "rational payment factor 2 verified")


def actual_data():
    w = F(1,256)
    source = [(box((0,0),w),F(1))]
    rows = []
    for i,signs in enumerate(product((-1,1),repeat=2),1):
        if signs[-1]==-1:
            c,z,L,D,private = F(15,32),F(7,8),F(17,16),1,F(1,4)
        else:
            c,z,L,D,private = F(31,32),F(31,16),F(2),4,F(4)
        source.append((box((p*z for p in signs),w),private))
        rows.append(Row(box((p*c for p in signs),w),L,D,(0,i),1+private))
    assert all(separated(a[0],b[0]) for a,b in combinations(source,2))
    assert all(separated(a.X,b.X) for a,b in combinations(rows,2))
    for row in rows:
        assert 1<=row.L<=2 and row.D<=row.v<2*row.D and row.mass>row.v
        for i,(s,_) in enumerate(source):
            if i in row.marks:
                assert all(max(u_hi-r_lo,r_hi-u_lo)<row.L/2
                           for (r_lo,r_hi),(u_lo,u_hi) in zip(row.X,s,strict=True))
                if row.D==4:
                    assert separated(row.X,s, F(1)-F(6,128))
            else:
                assert separated(row.X,s,1)
        # On a large core no source can enter below length 2*(1-6/128).
        cap = row.mass if row.D==1 else row.mass/(2*(1-F(6,128)))**2
        assert row.mass/row.v<=cap<2
    eta = tuple(v for _,v in source)
    print("Actual 2D data: bounded window 1<M_I<=2, actual a,z ordered pair density dx dη(a)dη(z)/v².")
    print("  source boxes and masses:",source)
    print("  four disjoint real receiver squares (X,L,D,true witness mass):",rows)
    print("  per-square area", volume(rows[0].X), "source positive side",2*w)
    return eta,tuple(rows)


def event_data(eta,rows):
    events = tuple((i,z,row.D) for i,row in enumerate(rows) for z in row.marks)
    # p[a][e] uses density per unit eta of the candidate anchor; eta[a] is
    # deliberately not absorbed before forming r[a]=sum_e p[a][e].
    p = {a:{e:volume(rows[e[0]].X)*eta[e[1]]/rows[e[0]].v**2
                  for e in events if a in rows[e[0]].marks} for a in range(len(eta))}
    r = {a:sum(law.values()) for a,law in p.items()}
    total = sum(eta[a]*v for a,v in r.items())
    R = {(a,e):eta[a]*v/total for a,law in p.items() for e,v in law.items()}
    marginal = defaultdict(F)
    zd = defaultdict(F)
    for (a,(_,z,D)),w in R.items():
        marginal[a,z,D] += w
        zd[z,D] += w
    E = {(a,b,z,D):marginal[a,z,D]*marginal[b,z,D]/mass
         for (z,D),mass in zd.items() for a in r for b in r
         if marginal.get((a,z,D),0) and marginal.get((b,z,D),0)}
    assert sum(R.values())==sum(E.values())==1 and all(v>0 for v in r.values())
    print("  true total restricted R mass",total,"per-unit-source intensities r",r)
    print("  normalized original z,D marginal",dict(sorted(zd.items())))
    return events,p,r,total,R,dict(marginal),E


def tv(a,b):
    return sum(abs(a.get(x,0)-b.get(x,0)) for x in a.keys()|b.keys())/2


def exchange(m,eta,rows,data):
    events,p,r,total,R,orig_zd,E = data
    W = defaultdict(F)
    old_slots = [defaultdict(F) for _ in range(m)]
    new_slots = [defaultdict(F) for _ in range(m)]
    wrong_slots = [defaultdict(F) for _ in range(m)]
    joint_tv = F(0)
    q_only = mean_pool = F(0)
    positive = ambiguous = 0
    for obs in product(events,repeat=m):
        b = {a:prod(p[a].get(e,F(0)) for e in obs) for a in r}
        true = {a:eta[a]*b[a]*r[a]**(1-m)/total for a in r if b[a]}
        mass = sum(true.values())
        if mass==0:
            continue
        positive += 1
        ambiguous += len(true)>1
        i,z,D = obs[0]
        old_mass = sum(eta[a]*b[a] for a in true)
        wrong = {a:eta[a]*b[a]/old_mass for a in true}
        # Full observation includes real coordinates, whose conditional
        # densities on the blocks are shared by all competing anchor labels.
        for a,a_mass in true.items():
            post = a_mass/mass
            assert sum(q*post for q in true.values())==a_mass
            joint_tv += abs(mass*wrong[a]-a_mass)/2
            for j,e in enumerate(obs):
                old_slots[j][a,e] += a_mass
                new_slots[j][a,e] += mass*post
                wrong_slots[j][a,e] += mass*wrong[a]
            for a_prime,q in true.items():
                W[a,a_prime,z,D] += a_mass*q/mass
        possible = set.intersection(*(set(rows[k].marks) for k,_,_ in obs))
        assert possible==set(true)
        if possible=={0}:
            q_only += mass
        live = sum(eta[a] for a in possible)
        mean_pool += mass*live/rows[i].mass
    assert sum(W.values())==1
    assert all(slot==R for slot in old_slots) and all(slot==R for slot in new_slots)
    marg_a,marg_b,ind_a,ind_b = (defaultdict(F) for _ in range(4))
    for table,A,B in ((W,marg_a,marg_b),(E,ind_a,ind_b)):
        for (a,b,z,D),value in table.items():
            A[a,z,D] += value
            B[b,z,D] += value
    assert dict(marg_a)==dict(marg_b)==dict(ind_a)==dict(ind_b)==orig_zd
    assert all(E.get(key,0)>0 for key in W)
    assert all(W[a,b,z,D]==W[b,a,z,D] for a,b,z,D in W)
    ratios = {key:value/E[key] for key,value in W.items()}
    assert sum(E[key]*x for key,x in ratios.items())==1
    print("m",m,"positive profiles",positive,"ambiguous",ambiguous,"W atoms",len(W),
          "independent E atoms",len(E),"all original slot and both z,D marginals exact")
    for L in (1,2,4):
        event = {key for key,x in ratios.items() if x>L}
        rho, independent = sum(W[key] for key in event),sum(E[key] for key in event)
        assert rho==sum(E[key]*ratios[key] for key in event)
        assert rho>=L*independent
        print("  density C>L",L,"joint W tail",show(rho),"independent E on same set",show(independent),
              "tail atoms",len(event))
    print("  maximum density C",show(max(ratios.values())),"W-vs-E TV",show(tv(W,E)))
    print("  exact P(shared true pool only q)",q_only,show(q_only),
          "and E[pool mass / first witness mass]",show(mean_pool))
    if m==2:
        assert joint_tv>0 and all(tv(slot,R)>0 for slot in wrong_slots)
        wrong_zd = defaultdict(F)
        for (a,(_,z,D)),value in wrong_slots[0].items():
            wrong_zd[a,z,D] += value
        assert tv(wrong_zd,orig_zd)>0
        print("  OMITTING 1/r: TV(full a-prime,obs)",joint_tv,show(joint_tv))
        print("  OMITTING 1/r: TV(original slots)",[show(tv(slot,R)) for slot in wrong_slots],
              "TV(a-prime,z,D)",show(tv(wrong_zd,orig_zd)))
    report_decisions(W,E)
    return mean_pool,q_only


def main():
    print("Replay:",sys.executable,"-B exchange844.py > exchange844.txt")
    print("Python",sys.version.split()[0],"exact Fraction and outward decimal display.")
    eta,rows = actual_data()
    data = event_data(eta,rows)
    summaries = [exchange(m,eta,rows,data) for m in (1,2,3)]
    assert summaries[0]==(1,0)
    assert summaries[0][0]>summaries[1][0]>summaries[2][0]
    assert summaries[0][1]<summaries[1][1]<summaries[2][1]
    print("Scope: original four low-dimensional receiver blocks only; no high-load terminal claim.")
    print("PASS")


if __name__=="__main__":
    main()
