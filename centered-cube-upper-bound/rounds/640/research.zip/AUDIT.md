# R640 独立主命题筛查及首条有价候选审核

先只读 CONTRACT 与主代理发送的准确候选，未读本轮作者证明，未扫描旧例或重推 scope/终端。

**结论：首条候选下界通过。它给出不依赖 old linear-face conditioning、无 N 或 λ_min 因子的同一次真实 receiver 信用。尚未证明该信用足够支付完整 receiver 缺额；全正与有价下界均不自动产生全局净增益。**

## 1. 初筛必须保留的最小价格与验收标准

- 固定同一旧 μ 和同一整组 Z；新中心位移不除 a。真实 VZ、实际新顺序 increments w_j、正则最优 α、source capture 必须全部来自这个共同动作。
- 删零后 J 为 retained labels，w_j>0；α_j>0 只对 J 成立。所有真实 rows/尺度、零删除及实际 union 仍保留，不以名义体积代 VZ。
- 新最优的支持梯度为 `r_j=m_j+εw_j/α_j`，不是 m_j。正权可避免精确零系数，但使用它必须付实际 w_j 与质量差分母，不能推统一 α_min。
- 一次 μ 信用须由同一个全族 packing/source identity 控制；逐 row 的捕获质量可重叠，不能各领一份 M。
- 可验收的完整结论仍需某个实际 Z 的 `Dε≥cV−CLnM`，常数统一于 N、尺度、最小权及步骤。只证信用正、切面或 entropy gap 正均不够。

## 2. 新 row 权的真实定量下界通过

令 α 是 retained 新族自己的正则最优，

\[
Q'=\sum_{j\in J}m_j\alpha_j,\quad
M'=Q'+\epsilon V_Z,
\quad r_j=m_j+\epsilon w_j/\alpha_j.
\]

新支持梯度与单行可行 packing `e_j` 给

\[
r_j\le r\cdot\alpha=Q'+\epsilon\sum_{j\in J}w_j=M'.
\]

虽然 e_j 有零坐标，沿 α 到 e_j 的开线段仍全正，所以这一一阶支持比较合法。也可用新 KKT 真实来源的逐行质量≤总量证明同式；不必把新来源与旧 μ 混同。

由于 εw_j/α_j>0，分母必严格正，并有

\[
\boxed{M'-m_j>0,\qquad
\alpha_j\ge q_j:=\frac{\epsilon w_j}{M'-m_j}.}\tag{A}
\]

常数为 1，无标签数/最小质量损失。因 q_j≤α_j，向零删除行延拓后 q 是**同一个新族的全局可行 packing**：`L_q^C≤L_α^C≤1`。因此这份逐行下界可以共同使用，不是互不兼容的 rowwise 边缘。

## 3. 旧同 μ source residual 与捕获信用通过

用 c_j 表示主代理候选中的 `a_j`：

\[
c_j=\mu(C_j\setminus A_j)\ge0,
\quad U_\alpha=\int(1-L_\alpha^C)d\mu\ge0.
\]

Aj⊂Cj 且旧 μAj=mj，故完整、同源恒等式为

\[
\boxed{M-Q'=U_\alpha+\sum_{j\in J}\alpha_jc_j.}\tag{B}
\]

删零标签不会破坏此式：α 在未保留 rows 上为 0；未覆盖旧来源仍留在 Uα 内。

由 (A)，

\[
\boxed{M-Q'
\ge U_\alpha+\epsilon\sum_{j\in J}
\frac{w_jc_j}{M'-m_j}.}\tag{C}
\]

父命题中舍去 Uα 的较弱版本也成立。此处没有按 j 重复 source：先有同一个全族恒等式 (B)，再逐项降低其非负权。capture 可彼此重叠，但 q≤α 的 packing 与 (B) 已共同控制复用。

这正是 direct Qε 带来的合法新价格，不需要证明切掉 old linear optimal face 或使用其 vertex/Hoffman conditioning。

## 4. 显式化分母的方向

同 μ 新 witnesses 给 Q′≤M，所以 M′≤M+εVZ。于是

\[
0<M'-m_j\le M+\epsilon V_Z-m_j,
\]

\[
\boxed{M-Q'
\ge U_\alpha+\epsilon\sum_j\frac{w_jc_j}{M'-m_j}
\ge U_\alpha+\epsilon\sum_j
\frac{w_jc_j}{M+\epsilon V_Z-m_j}.}\tag{C_exp}
\]

显式分母变大，所得下界更弱；不得将方向倒转。旧 m_j≤M 也保证显式分母正。实际分母 M′−m_j 与 receiver/capture 的相关性若有利，可以保留，不必为简便提前粗化。

## 5. 同次真实 receiver 积分：价格没有丢失

令 `I_j^Z` 为新族真正的不交顺序 increments，`|I_j^Z|=w_j`，它们的并是实际 UZ 至零测。则

\[
\boxed{\sum_j\frac{w_jc_j}{M'-m_j}
=\int_{U_Z}\frac{c_{j(z)}}{M'-m_{j(z)}}dz,}
\]

其中 j(z) 是这份实际新分区唯一标签。等价的共同 source–receiver 核为

\[
\epsilon\int\!\int
\sum_j\frac{1_{I_j^Z}(z)1_{C_j\setminus A_j}(x)}{M'-m_j}
\,d\mu(x)\,dz.
\]

这是完整 receiver 质量 w_j 的积分，不是中心数或另一个名义 v_j；没有额外 Jacobian。非负 Fubini 合法，上述带 ε 的总积分由 (C) 控制为≤M。source μ 不需产品结构或密度帽。

若改用 capture 最大化的另一组 Z、另一份顺序、旧 increments v_j 或不同 μ，不能继续保留当前 w_j/分母。这一 joint correlation 正是收益证明必须处理的对象。

## 6. 完整预算的可验收式与决定性缺口

从 (C) 得到合法全量下界

\[
\boxed{D_\epsilon(Z)\ge
V_Z-RM+RU_\alpha
+R\epsilon\int_{U_Z}
\frac{c_{j(z)}}{M'-m_{j(z)}}dz.}\tag{D_lower}
\]

若作者能对某一个共同实际 Z 证明右端≥`cV−CLnM`，则完整主目标通过。也可证明更强的全族权比较，直接使用 (B) 的实际 α，而不必接受 (A) 可能损失的信用。

目前合同没有下界迫使这一 receiver-priced capture 积分足够大，也未证明 Uα 足够大，更没有将其与同一次 VZ 的缺额 RM−VZ 作统一比较。capture 为零或这份 lower credit 很弱，并不否定 direct Qε：Uα 及未被 (A) 保留的实际 α 信用可能重要。不能把这一充分下界再误当成目标必须满足的窄条件。

若接下来使用 cube 坐标几何，必须保留真实约束 `x∈C_j\A_j` 与 `z∈I_j^Z` 的全部坐标/尺度和源相关性；不能将其缩成每行独立最佳捕获、未定价的 clique 数、whole-row 整数指派或旧 face 上的裸 overload。

**最终审核状态：首条有价放缩通过；显式化方向与同次 receiver 积分均通过。完整统一净收益仍未证明。**

## 7. 实际工具与停止点

本机 math venv、SymPy 1.14.0 轻量核验：令 b>0、s≥0 为实际分母及其显式化增加量，紧 lower credit 减显式 lower credit 为 `εwc·s/[b(b+s)]≥0`；完整 source-gap 回代 D 的符号残差为 0。没有实验或重复历史例。

完成这份 bounded 独审，等待 root/作者后续完整收益候选，不持续空跑。

## 8. 新完整候选：共同降序与二次反馈下界的量词/根支审核

按主代理新命题独立核物理对象与根支；基本根式换元已由另一独审核过，本节不重复同处展开。

**结论：共同排序、删除、A 的 envelope 身份、二次可行根支及 b>0 的常数均通过。几何统一 b 下界未证；b≤0 不能被当成实际 Dε≤0。**

### 8.1 共同新顺序与真实 receiver envelope

固定同一份旧 μ 和同一整组 Z，先计算所有行的固定捕获质量

\[
a_j=\mu(C_j\setminus A_j)\ge0.
\]

按 a_j 非增排序，平手用一次固定规则，再按该顺序计算真实新 receiver increments I_j^Z、w_j。对任一 receiver 点，第一次覆盖它的行恰有其全部 cover 中最大的 a_j，因此

\[
\boxed{A:=\sum_jw_ja_j
=\int_{U_Z}\max_{j:z\in C_j/a}a_j\,dz.}
\]

这是一次共同全族排序，不是在给定收费 source 点后换动作。a_j 是整块 μ 捕获质量；不把 maximum 穿过 μ 积分，也没有来源独立性假设。

若某行新 increment 为零，它的 receiver 至零测已被更早的 ≥a 行覆盖，删除它不改变 UZ 或上式 envelope。保留原相对顺序后，所有 retained w_j>0，求其自己的 same-ε barrier 最优 α。不得继续使用删除前/另一排序的 α。

μ 可以全局影响 a_j 与所选顺序；direct Qε 确实随真实新顺序变化。这是合法的共同选择权限，不是把 Qlin 的 order-independence 错搬过来。

### 8.2 二次反馈不等式的物理范围

令

\[
W=V_Z>0,\quad Q'=Q_{\epsilon,\rm new}>0,\quad
S=M-Q'\in[0,M),\quad M'=Q'+\epsilon W=M+\epsilon W-S>0.
\]

已审新权下界的较弱版本 `α_j≥εw_j/M′` 与同 μ residual 给

\[
\boxed{S(M+\epsilon W-S)\ge\epsilon A.}
\]

因为 `0≤a_j≤M`，真实 A 满足 `0≤A≤MW`。实际 finite rows 还有 a_j≤M−m_j<M，故 W>0 时 θ=A/(MW)<1；使用闭上界 θ≤1 是合法的放松，不声称 θ=1 必可实现。A=0/θ=0 没有除零问题。

该式仍是同一次真实 receiver/source 的全量下界。它舍去了 Uα 和较强分母 M′−m_j，所以只是充分的 lower estimate，不是所有 positive D 的必要条件。

### 8.3 minus root 是合法下根，不假定实际 S 等于它

设 B=M+εW。由二次式

\[
S^2-BS+\epsilon A\le0,
\]

实际 S 位于两个根之间，故可以取 minus root 作下界。根号总为实数，因为

\[
B^2-4\epsilon A
\ge(M+\epsilon W)^2-4\epsilon MW
=(M-\epsilon W)^2\ge0.
\]

这里没有把 S 改成某个新来源、没有假设它正好取下根，也不需要选择 upper root 或抛弃实际 S<M 的约束。

令

\[
k=\epsilon R>3,\quad s=1+k=M/Q,\quad r=W/V>0,
\quad\theta=A/(MW)\in[0,1],
\]

\[
b=r+k\theta-s,\qquad T=(k+2)r-s.
\]

主代理给定的归一化下界

\[
\boxed{\frac{D_\epsilon}{V}\ge
\frac{T-\sqrt{T^2-4srb}}2}
\]

与上述物理下根一致；其中旧 Q、R、V、M 与新的 W、A、S 分别固定，未混用新旧 increments。

### 8.4 正收益支的域与常数

若 b>0，则 θ≤1 给

\[
r>s-k\theta\ge s-k=1,
\quad T>(k+2)-s=1.
\]

所以 T>0 且根号≤T，rationalization 合法：

\[
\frac{T-\sqrt{T^2-4srb}}2
=\frac{2srb}{T+\sqrt{T^2-4srb}}
\ge\frac{srb}{T}
\ge\frac{s}{k+2}b
\ge\frac45b.
\]

最后一步使用 k>3，实际 `(k+1)/(k+2)>4/5`；写≥4/5安全。常数无 n、N、λ_min 或最小质量费用。

若 b<0，则根式 lower bound 非正；这不提供实际 D 的上界。若 b=0，在 θ≤1 下有 r≥1、T≥1，该 lower bound 为 0；也不意味着 D=0。不能在非正支使用“√Δ≤T”或将一个非正 lower bound倒作 actual D≤0。

因此 **b>0 是这条 capture-only 正支的充分条件，不是完整 Dε>0 的必要条件**。其失败可能只是下界未保留 Uα 或实际 α 的额外信用。

### 8.5 尚未付款的唯一新增含量

必须仍对一个共同实际 Z、上述实际共同顺序证明统一的 b 下界（或直接证明更强的完整 D 下界），并保留其 receiver 缺额和来源捕获的相关性。单独扩大某些 a_j、证明 A>0、切掉 linear face 或换另一次 receiver 排序，都不蕴含 b>0。

如将来同一对象证明 `b≥b_0−C_1 L_nM/V`，并在预定 hard 参数下保证该下界严格正，则本节可给 `Dε≥(4b_0/5)V−(4C_1/5)L_nM`；这只是条件回代，不是本轮已经得到的几何估计。

**定点审核通过；几何统一 b 下界仍未证。完成追加，停止待下一候选。**

## 9. 本轮重点 geometry decision：derived capture guarantee 的全域上限

**独立判定通过：** 对当前增强根式保证 Lcap，有

\[
\boxed{L_{\rm cap}\le(W-RM)_++PM.}\tag{CAP}
\]

这是 **对一个已证明 lower guarantee 的上限**，不是 actual Dε、实际 Σαa 或 Uα 的上限。该范围限定不可删。

### 9.1 所有尺度、新顺序都保留的全族 Fubini 界

固定同一实际 Z 和任意共同新顺序，w_j 是真正不交的 receiver increments。每个新 cube C_j=Q(c_j,ρ_j) 体积为旧 m_j=μ(A_j)≤M，因此

\[
\rho_j\le M^{1/n}/2.
\]

对任意 source 点 x，只看满足 x∈C_j 的 labels。任意 z∈C_j/a 的真实新中心是 c_j，而非旧 y_j；逐坐标给

\[
\|z-x\|_\infty
<\rho_j/a+\rho_j
\le(1+1/a)M^{1/n}/2.
\]

所以全部这些 labels 的真实 increments 都落在一只以 x 为中心、体积 PM 的 cube 中。increments 不交，准确得到

\[
\boxed{\sum_jw_j1_{C_j}(x)\le PM\quad\text{逐点成立}.}
\]

非负 Fubini 遂给

\[
\sum_jw_j\mu(C_j)
=\int\sum_jw_j1_{C_j}(x)d\mu(x)
\le PM^2.
\]

因此

\[
\boxed{A=\sum_jw_ja_j\le PM^2.}\tag{A_cap}
\]

没有固定尺度、N 或半径数损失；只用实际新中心、ρ_j 的总质量界和 disjoint increments。开 cube 边界不增加 membership，原点态证明已经足够；旧 μ 的 AC 合同也使边界质量为零。没有 μ 密度帽或产品性假设。

### 9.2 增强参数 c 与根式的域

A>0 时定义

\[
\theta=\frac{A}{MW},\quad
c=\frac{\sum_jw_ja_jm_j}{MA},\quad
u=\frac{\epsilon W}{M}>0.
\]

这里 u 是标量 εW/M，不是任何 packing 权。因 `a_j+m_j=μ(C_j)≤M`，

\[
\sum_jw_ja_jm_j+\sum_jw_ja_j^2\le MA.
\]

再用 weighted Cauchy `Σw_ja_j²≥A²/W`，得到

\[
\boxed{\theta+c\le1.}
\]

这一结论需要上述 Cauchy 连接两种不同权重，不是把 rowwise a_j+m_j≤M 直接无权平均。

由已审紧分母价格以及 reciprocal Jensen，actual t=S/M 满足

\[
t(1+u-c-t)\ge u\theta.
\]

其中 Jensen 权为 w_ja_j/A，实际分母 `M′−m_j` 全正，均值分母也正。故 lower root

\[
g_c=\frac{1+u-c-
\sqrt{(1+u-c)^2-4u\theta}}2
\]

确为 S/M 的 lower guarantee。θ+c≤1 保证根号非负。

令 `f(x)=x(1+u−c−x)`。有

\[
f(\theta)-u\theta=\theta(1-c-\theta)\ge0,
\quad
f(u)-u\theta=u(1-c-\theta)\ge0.
\]

θ、u 都在该二次可行根区间内，因此

\[
\boxed{g_c\le\min(\theta,u)\quad\text{对全部 }u>0.}
\]

不需要 θ<u。若 θ>u，仍可由另一端点 u 控制 lower root；不能因根的排序而漏掉此域。

A=0 时 c 不定义，应直接取 capture-only 下界 S≥0，g=0；最终 (CAP) 同样成立，不进行 0/0 参数化。

### 9.3 三段全域推导

定义

\[
r=W/V,\quad k=\epsilon R>3,\quad s=1+k=RM/V>4,
\quad\Delta=PM/V.
\]

hard 关系给 `Δ=1/(2Hβ)<2/(3H)<1`，并有 `u=kr/s`、`θ≤PM/W=Δ/r`。当前 derived guarantee 为

\[
L_{\rm cap}=W-RM+RMg_c.
\]

1. **0<r≤1：** 用 g_c≤u，

\[
L_{\rm cap}/V\le r-s+s(kr/s)=s(r-1)\le0.
\]

2. **1≤r≤s：** 用 g_c≤θ≤Δ/r，

\[
L_{\rm cap}/V\le h(r):=r-s+s\Delta/r.
\]

h″(r)=2sΔ/r³>0，故区间上最大值在端点；`h(s)=Δ`，且

\[
h(1)-\Delta=(s-1)(\Delta-1)\le0.
\]

因此 Lcap≤ΔV=PM。

3. **r≥s：** 捕获增量本身满足

\[
RMg_c\le RM\theta\le PRM^2/W\le PM,
\]

故 `Lcap≤W−RM+PM`。

合并三段即得 (CAP)，不需要 W>RM/2 之类额外分箱或 2P 常数。

### 9.4 对研究决策的准确含义

当 W≤RM 时，当前 g_c 根式保证至多 PM；hard 中 `PM/V=Δ<O(1/H)`，不能单凭这份保证得到参数统一的正 cV 预算（H 预先选大后所需净 margin 是 V 的固定比例）。

若 W>RM，捕获根式在 receiver-alone overshoot `W−RM` 之外仍至多额外保证 PM。可能的 V 级收益此时必须来自真实 receiver overshoot，或来自本根式没有保留的其它信用。

因此停止继续把这份捕获加权 g_c 根式单独调参作为完整主预算是有数学依据的。但结论**不**上界 actual Dε、实际 `Σα_ja_j`、Uα，亦不排除保留完整 α 价格或其它更强同源估计；本根式先用了 α 的 lower bound、Jensen 并舍去 Uα，不能把 lower guarantee 的 ceiling 倒作实际对象的 ceiling。

可以保留的完整来源账仍为

\[
D_\epsilon=W-RM+RU_\alpha+R\sum_j\alpha_ja_j.
\]

后续必须保留 Uα 并证明新的全量比较，或独立证明真实 receiver 的足够 overshoot。当前没有这些 uniform net-gain 证明。

本机 SymPy 1.14.0 轻量核验 h″、两端差及 f(θ)/f(u) 的因式分解；几何 Fubini 与 source-once 范围由上述解析证明。未做扫描或重复旧例。

**本轮 geometry decision 核准：精确全域 cap (CAP) 成立；范围严格限当前 derived guarantee。完成定点审查，停止待命。**
