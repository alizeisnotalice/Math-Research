#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys,subprocess,os,tempfile,shutil,time,ast,re
root=Path(__file__).resolve().parent;start=time.perf_counter()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if (root/'MANIFEST.json').exists():
 for name,h in json.loads((root/'MANIFEST.json').read_text()).items():assert sha(root/name)==h,name
for p in root.rglob('*.py'):ast.parse(p.read_text(),filename=str(p))
s=(root/'REPORT.tex').read_text();stack=[]
for kind,name in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
 if kind=='begin':stack.append(name)
 else:assert stack.pop()==name
assert not stack and s.count('\\[')==s.count('\\]')
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='ccu-r640-verify-') as tmp:
 t=Path(tmp);shutil.copytree(root/'numeric',t/'numeric')
 def run(file):
  p=subprocess.run([sys.executable,str(t/'numeric'/file)],env=env,cwd=t/'numeric',text=True,capture_output=True,check=True)
  return json.loads(p.stdout)
 exact=run('verify.py');assert exact['status']=='PASS' and exact['all_exact_fraction']
 saved=json.loads((root/'numeric'/'verify_results.json').read_text())
 for k in ['counterexample_sha256','script_sha256','defect_interval_coarse','all_exact_fraction']:assert exact[k]==saved[k]
 assert exact['script_sha256']==sha(root/'numeric'/'verify.py')
 assert exact['counterexample_sha256']==sha(root/'numeric'/'counterexample.json')
 algebra=run('algebra.py');assert algebra['status']=='PASS' and len(algebra['residuals'])==7 and set(algebra['residuals'].values())=={'0'}
summary={'status':'passed','interpreter':sys.executable,'python':sys.version,'wall_s':time.perf_counter()-start,'counterexample':exact,'algebra':algebra,'python_syntax':'passed','latex_structure':'passed; not compiled','scope':'One exact owner-concavity counterexample, seven symbolic identities. Neither proves a general root upper bound. No MATLAB or Arb run.'}
(root/'RUN_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
