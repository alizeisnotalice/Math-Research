# R640 新顺序 / receiver owner 与 own-Qε（Sol high）

**结论先行：** 重新选择一个共同的新顺序合法；任意分数 owner 虽可实现成真实 Lebesgue 分区，却一般不是单一顺序，不能免费替代当前顺序合同。Qε在真实 owner base 上的通用凹性已被严格有限证书否定，但这不否定以其他理由取得顺序极点最小值。现阶段没有一般 order-minimum 定理，也没有 uniform receiver/score 价格支付完整Dε。

本支可用于主证明的准确互补式是：固定新几何，相邻顺序交换只转移其真实未覆盖交叠体积 h；在端点正权、响应已完整处理的区间，

    ΔQε=ε∫_0^h[ξ_k(s)−ξ_j(s)]ds.                 (O)

只有这个**全路径价格**的符号，或实际重新优化后的端点比较，才能认证合法顺序收益；初始梯度的排序不够。

## 1. 共同新顺序的权限

先固定同一旧来源μ、整组Z和全部新星C_j。新顺序可依赖这些完整数据，但只能选一次，对全部receiver/source付款共同使用。对每个顺序重算真实increments；删零后重新算 retained packing及其正则最优，需求是 retained m_j、权重是该顺序真实w_j，ε不变。

这是当前完整Dε目标允许的动作。它不改变旧R、μ、m或新物理union W=V_Z；只改变新正则容量。若改旧顺序，则旧v、λ、m、R乃至ρ都须重算，不能仍沿用旧动作与基线。

## 2. 完整 receiver owner base：fractional不等于顺序

对固定新receivers B_j'=C_j/a，设 f(S)=|∪_{j∈S}B_j'|。所有真实可测partition I_j'⊂B_j'、互不交且覆盖union至零测，其质量w恰组成

    B_f={w≥0:w(S)≤f(S)所有S, Σw=W}.

必要性直接由支持与总量；充分性可在有限positive receiver atoms上用一次bipartite流/Hall cuts实现。若先得到fractional atom allocation，Lebesgue非原子性允许逐atom切成所需体积的真实measurable pieces，精确保同一w，不需按源点随机化。

对任意label cost c，线性最小值精确为

    min_{B_f}c·w=∫_{union}min_{j:x∈B_j'}c_j dx.

按c升序的共同顺序使每点归给最早覆盖者，达到该值。因此B_f等于全部greedy顺序增量向量的凸包；这些是coverage base的greedy vertices（可有重复）。

然而一般base点只是顺序的凸组合，不是一个单一顺序。Qε(w)不是线性目标；不能把上述线性极点结论、fractional可实现性或随机混合顺序，直接改称存在某顺序达到更小Qε。随机选顺序的E Qε与先混质量后Qε(Ew)也不同。

## 3. 对实际owner变化的正确新Q响应

此处只变新w，固定stars、需求m、ε和packing polytope。令新正则解α全正，稳定活动面Bα=1，Z基为kerB，

    H=εdiag(w/α²), K=Z(ZᵀHZ)^{-1}Zᵀ,
    ξ=(α−KHα)/α.

则对Σdotw=0的真实owner变化，

    dotQε=εΣ(ξ_j−1)dotw_j=ε ξ·dotw.

ξ一般有符号；不是packing或probability权。若一个positive owner确为局部min且该响应可微，则必须最小化linear functional ξ·w。因此其正质量仅可给每个实际overlap atom中ξ最小的labels（ties可分配）。这是有条件的owner必要条件，不能从固定δ-near-family直接偷推驻点。

定义实际线性化缺口

    H_owner=ξ·w−∫min_{j:x∈B_j'}ξ_j dx≥0.

若它严格正，朝ξ排序greedy质量作convex方向给dotQε=−εH_owner。中间质量可实现为真实partition，但一般不是顺序；所以它只是在扩大owner类中或作为端点分析路径的下降方向，并未给原顺序类中的有限收益。face变化要重算真实响应，不能全程冻结初始ξ。

## 4. 一个真正order-only的有限桥

设当前顺序中j紧邻k，之前union为U0。交换两者时

    h=|(B_j'∩B_k')\U0|,
    w_j'=w_j−h, w_k'=w_k+h,

其余行实际increments不变，因为两者之后的prefix union相同。两个端点都是一个共同真实顺序。

若交换后仍全正，可沿w(s)=w+s(e_k−e_j),0≤s≤h作同一完整新族的正则比较；中间partition可仅在这个共同overlap中重新分配。若稳定face响应在全路径或经核准的分段成立，积分给(O)。例如全路径ξ_j−ξ_k≥η>0时，

    Qε(new)≤Qε(old)−εηh,
    Dε(new)≥Dε(old)+Rεηh.

这是同一完整目标的合法定量顺序增益，没有复制来源质量、改receiverunion或少算其他行。但未证明cube geometry能保证足量h及全路径score-gap；初始ξ_j>ξ_k不保证整个交换后Q变小。

若端点出现w_j'=0，必须按实际定义删星并重算Qε。删除保union至零测，但删除线性变量会换优化问题；不能把固定六行/含zero-weight问题的极限值自动等同于删后的Qε。本审不使用未经证明的zero-owner continuity来补这个跳步。

## 5. 通用凹性反例的精确范围

只读并执行一次Terra可移植 `/tmp/ccu_r640/numeric/verify.py`。三真实n=2大stars共交，receivers七种非零membership均正。两端w0,w1与mid均全正；其atom分配可用rational cuts实现实际分区，且两端各有明确三个真实顺序极点的rational凸组合。

simplex Γ方程的Fraction正分母/严格反号根括认证

    −10^-12 < Qε((w0+w1)/2)−[Qε(w0)+Qε(w1)]/2 <−10^-13.

故真实owner base上Qε通用凹性为假。这不是zero权、换星或浮点误差造成的反例，不能再用该凹性证明顺序归约。

**但它没有否定order-extreme minimum。** 在这个common-star-clique子类，Γ满足

    Σ εw_j/(Γ−m_j)=1, Qε=Γ−εW.

对固定总W的convex mixtures，方程对w线性且对Γ严格递减，所以混合Γ介于端点Γ之间，Qε亦然。此例每label还有exclusive positive receiver atom，所有order极点都正；结合B_f=conv orders，仍有Qε(w)≥min_order Qε(order)。因此非凹性与该子类的顺序最小值归约完全相容。

一般interwoven packing polytope的类似quasiconcavity或order-minimum性质尚未证明。本审不从一个强凹性命题失败否定整个顺序策略，也不追加反例扫描。

## 6. 若明确扩大owner类，哪些权限仍需保留

可以从一开始把supremum类改为所有≤N个真实measurable partitions、每个保留质量正；finite KKT source、固定N终端及原输入packing入口只需I_j⊂B_j、disjoint、Σw=union体积，因而相应基础工具不要求它是顺序increments。

但这是真实扩大近极值类，不能把一个fractional新动作塞回原ordered S_N而不作声明。全部未证positive Dε估计也要覆盖该扩大旧类；不能只扩大选择权限而保留依赖前序历史的假设。任何order-specific几何付款都须另核，本节不宣称这些未证预算已随权限自动得到。

zero-owner时先删相应星、union保至零测，重算目标。可将类定义为各retained子族上的positive partitions，仍≤N；无需假设zero-boundary的最优达到。固定positive family邻域内Qε连续，不代表“留zero线性变量”与“删星”问题在边界相同。

同源strict近似若以后需要，可先固定retained positive partition，再将各piece与相应逼近cubes取交、将余下小量receiver重新分配，取得真实weights连续逼近；这里用finite cubes的symmetric-difference连续性，不能假设同步位移收回后的small receivers逐个嵌套。但必须保留已有完整margin，且重新核polytope。这只是权限的必要条件，不是本支的预算收益。本审没有用扩大类消去任何实际费用或取得真正几何驻点。

## 7. 与Astra实际capture-order信用的定点对照

outer作者提出的次序是一个**真实order**，不依赖上述被反驳的凹性。固定μ,Z，记a_j=μ(C_j\A_j)，按a降序选共同新顺序，删零行后仍有

    A=Σw_ja_j=∫_{receiver union}max_{j:x∈C_j/a}a_j dx.

删去zero行只删掉被更高/等a前序覆盖的receiver，故该envelope积分不变，不能为不同source各用不同order。

记α为新自身正则最优、Q'=m·α、S=M−Q'≥0、M'=Q'+εW。新真实KKT给

    α_j≥εw_j/(M'−m_j)≥εw_j/M'.

旧μ残差给S≥Σα_ja_j。因此S(M+εW−S)≥εA，A≤MW保证实根下界

    S≥[M+εW−sqrt((M+εW)^2−4εA)]/2.

A>0时可进一步以a加权均值mbar=Σw a m/A保留m分母。令

    r=W/V, k=εR, s=k+1,
    θ=A/(MW), χ=mbar/M,
    gχ=[1+u−χ−sqrt((1+u−χ)^2−4uθ)]/2,
    u=εW/M=kr/s.

Jensen与a_j≤M−m_j给S≥Mgχ、θ+χ≤1、gχ≤min(u,1−χ)。准确回代为

    Dε/V≥d:=r−s+s gχ,
    bχ:=r+kθ−s+χ(s−r)/r
       =d[1−(χ+gχ)/r].

r>1时该factor位于(0,1]，故bχ>0即可给完整Dε/V≥bχ。A=0时mbar未定义，须退回S≥0；r>1及bχ统一正仍须同次几何证明。

最终 `/tmp/ccu_r640/regularized.md` 的进一步展开也通过：在真实owner概率w/W下，

    ζ=1−θ−χ
      =[E(a·μ(C_owner^c))+Var(a)]/[M E a]≥0,
    bχ=(r−1)(1−sχ/r)−kζ.

这些式子保留新M'、真实w和共同order，不能用旧v替代。它们是实际已定价的完整下界，但目前没有cube几何强制其右端达到c−CL_nM/V。报告明确未证这一点，未把公式本身登记为完整预算。

## 8. 计算与停止

本审仅运行一次Fraction portable反例verifier（约0.00074秒），没有重复6案探索或扫描。输入hash `e06b9da28d903d46cc8f12b4e587df54d44bf84c48c910074d505883481d806d`；verifier hash `4f8980cf46badcff646c334a4de6b96d751c0569e49ac101d10da44c4f90dda7`。另用本机math venv/SymPy对bχ反馈factor恒等式作精确核验，残差0、约0.04秒。

已交换关键公式与真实owner范围，未修改他人文件/仓库。**当前未得一般顺序优化的uniform收益，也未证明实际cube的capture-order joint下界；完整目标未付。** 唯一写入本文件，bounded交付后停止。

## 9. 追加独审：full-source block 与真正删行的完整价格

按主代理最后要求，先独立推导，再只读对照 `/tmp/ccu_r640/action.md` 的追加§5。**结论通过，无实质修正项；不能将这些条件比较登记为删除保持hard或免费按N归纳。**

设旧 H={j:m_j=M}。AC与μ(A_h)=M给任意旧/新行k的μ(A_h∩A_k)>0、μ(C_h∩C_k)>0，因此有真实正体积交。全源行两两亦如此；对任何其余行clique，轴平行boxes的有限Helly2使加上全部H仍有共同正体积交。故旧与新packing都有真实join结构，不是仅有若干pair的替代图。

旧owned h=Σ_Hv_j≤|∪_H B_j|≤P max_Hd_j≤PM。hard时V/M>3PH/2，故H不能包含全部标签，G非空且V0=V−h>0。H为空则以下删行比较平凡。对非空H的旧正则解，t0=Σ_Hλ∈(0,1)，λ_G=(1−t0)κ；固定t0的条件优化确给κ在**继承旧v_G**、同PG、参数ε'=ε/(1−t0)下最优。旧H的stationarity逐行给

    Σ_Hd_jλ_j=M t0−εh,
    Q_{ε',G}(v_G)=M−ε'V0.

这些是旧解身份，不能把旧λ/v免费代入新的regularized问题。作者对新block另外用新实际w/new t推导，范围没有混淆。

固定packing、d与正权v时，对0<α<β，正则最优的线性部分满足全局

    0≤Q_α−Q_β≤(β−α)Σv.

无需活动面稳定。先比较两个正则目标，得熵项随参数不减，故D=Q_α−Q_β≥0；两KKT方向比较又给

    x=Σv λ_β/λ_α≤V+D/α,
    y=Σv λ_α/λ_β≤V−D/β,
    xy≥V².

因此D[D−(β−α)V]≤0，得到精确Lip界。代入ε'给

    Q_{ε,G}(v_G)≤Q+εh.                            (H1)

真正删除旧H、**保G原相对顺序**时，各G新增量为v_j+u_j，u_j≥0；receiver真实丢失ℓ满足Σu=h−ℓ=:U≥0。G原v_j>0，删除后仍正，无zero权极限问题。若再另换G顺序，u未必逐分量非负，不能沿用下面这条式。

同PG、同d、同ε下，设δQ=Qε(v+u)−Qε(v)、z_j=λ'_j/λ_j。两KKT给

    x=Σv_jz_j≤V0−δQ/ε,
    y=Σ(v_j+u_j)/z_j≤V0+U+δQ/ε,
    xy≥T²,  T=Σ√(v_j(v_j+u_j)).

各右端为正，解二次不等式即得

    δQ≤ε[√((2V0+U)²−4T²)−U]/2
       ≤ε√(V0U).                                 (H2)

T≤√(V0(V0+U))保证根区间合法，T≥V0给最后上界。没有假设Q对单个权重单调，也不需要face稳定；δQ本身可以为负。

所以作者的真实删行比较准确：

    Qε,deleteH≤Q+εh+ε√((V−h)(h−ℓ)),
    (V−ℓ)−R Qε,deleteH
      ≥−ℓ−Rεh−Rε√((V−h)(h−ℓ)).                 (H3)

第一条(H1)只用于继承权重，第二条(H2)才支付真实owner重分配。h≤PM不使R倍费用免费：粗平方根费至多RM/√(2H)，尚非统一CL_nM，也不给原hard阈值的无损保持。可在额外定量余量下另核某个特定删除，但当前不能声称已消除full-source障碍。

`action.md`的新尾部后置、join条件优化与旧删除追加各自使用正确的实际weights；其最终保留未付R倍误差、H空/Δ零等分支，没有把“完整新linear容量恒为M”错误等同于新Qε恒为M。此追加仅核上述scope与公式，未重跑数值、未改作者文件；完成即停。
