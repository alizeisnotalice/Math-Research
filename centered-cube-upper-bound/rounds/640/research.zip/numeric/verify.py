#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import product,permutations
from pathlib import Path
from hashlib import sha256
import time,resource,sys,json,math
w=time.perf_counter();cpu=time.process_time();path=Path(__file__).with_name('counterexample.json');d=json.loads(path.read_text());n=d['n'];a=32*n;r=list(map(F,d['radii']));c=[[F(x) for x in z] for z in d['centers']];eps=F(d['epsilon']);assert n==2 and eps==F(64,4225)
assert all(max(map(abs,y))<s for y,s in zip(c,r))
axes=[]
for j in range(n):
 cuts=sorted({c[i][j]+h*r[i]/a for i in range(3) for h in (-1,1)});axes.append(list(zip(cuts,cuts[1:])))
cells={}
for box in product(*axes):
 p=[(l+u)/2 for l,u in box];mask=sum(1<<i for i in range(3) if all(abs(p[j]-c[i][j])<r[i]/a for j in range(n)))
 if mask:cells[mask]=cells.get(mask,F(0))+math.prod(u-l for l,u in box)
assert {str(k):str(v) for k,v in cells.items()}==d['receiver_cell_volumes'] and len(cells)==7
V=sum(cells.values());uniform=[sum((q/F(mask.bit_count()) for mask,q in cells.items() if mask>>i&1),F(0)) for i in range(3)];W=cells[7]
v0=[uniform[i]+F(3,4)*W*([F(2,3),F(-1,3),F(-1,3)][i]) for i in range(3)];v1=[uniform[i]+F(3,4)*W*([F(-1,3),F(1,3),F(0)][i]) for i in range(3)];vm=[(v0[i]+v1[i])/2 for i in range(3)]
assert all(x>0 for x in v0+v1+vm) and all(sum(v)==V for v in [v0,v1,vm]);assert [list(map(str,x)) for x in (v0,v1,vm)]==[d['owner_v0'],d['owner_v1'],d['owner_mid']]
# Check explicit convex combinations of actual greedy order vertices independently.
def greedy(seq):
 v=[F(0)]*3
 for mask,q in cells.items():v[next(i for i in seq if mask>>i&1)]+=q
 return v
for v,combo in [(v0,[((0,1,2),F(107329,178320)),((1,0,2),F(20111,178320)),((2,0,1),F(212,743))]),(v1,[((0,1,2),F(106111,1783200)),((1,0,2),F(938609,1783200)),((2,0,1),F(3077,7430))])]:
 assert sum(k for seq,k in combo)==1
 assert all(sum(k*greedy(seq)[j] for seq,k in combo)==v[j] for j in range(3))
stars=[(2*s)**n for s in r];intervals=[]
for v,key in [(v0,'Q0_interval'),(v1,'Q1_interval'),(vm,'Qmid_interval')]:
 ql,qh=map(F,d[key]);gl=ql+eps*V;gh=qh+eps*V
 def f(g):return sum((eps*v[i]/(g-stars[i]) for i in range(3)),F(0))-1
 assert gl>max(stars) and f(gl)>0 and f(gh)<0;intervals.append((ql,qh))
q0,q1,qm=intervals;L=qm[0]-(q0[1]+q1[1])/2;U=qm[1]-(q0[0]+q1[0])/2
assert list(map(str,(L,U)))==d['defect_interval'];assert -F(1,10**12)<L<=U<-F(1,10**13)
print(json.dumps({'status':'PASS','defect_interval_coarse':['-1/1000000000000','-1/10000000000000'],'all_exact_fraction':True,'counterexample_sha256':sha256(path.read_bytes()).hexdigest(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-w,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2))
