#!/usr/bin/env python3
"""Exact symbolic bookkeeping only; inequalities and geometry are proved in REPORT.tex."""
import sys,time,json,resource
import sympy as S
start=time.perf_counter()
k,r,g,chi,u,theta,V,z,e1,e2,U,C,s,eta=S.symbols('k r g chi u theta V z e1 e2 U C s eta',positive=True)
ss=1+k; uu=k*r/ss; th=g*(1+uu-chi-g)/uu
b=r+k*th-ss+chi*(ss-r)/r
items={
 'enhanced_score':b-(r-ss+ss*g)*(1-(chi+g)/r),
 'radicand':(1+u-chi)**2-4*u*theta-(u-(1-chi))**2-4*u*(1-chi-theta),
 'epsilon_lipschitz_product':(V+z/e1)*(V-z/e2)-V**2-z*((e2-e1)*V-z)/(e1*e2),
 'owner_increment_product':(V-z)*(V+U+z)-C**2-(V*(V+U)-C**2-U*z-z**2),
 'cap_convexity':S.diff(r-s+s*eta/r,r,2)-2*s*eta/r**3,
 'cap_left_endpoint':(1-s+s*eta)-eta-(1-s)*(1-eta),
 'cap_right_endpoint':(s-s+s*eta/s)-eta,
}
res={name:str(S.factor(expr)) for name,expr in items.items()}
assert all(v=='0' for v in res.values()),res
print(json.dumps({'status':'PASS','residuals':res,'python':sys.version,'sympy':S.__version__,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Symbolic identities only; no general weak bound or interval API is certified.'},indent=2))
