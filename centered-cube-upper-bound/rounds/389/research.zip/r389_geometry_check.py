from fractions import Fraction as F
from itertools import product

# Rational enclosures: 2 atanh(z), with rigorous positive-series tail.
def ln_bounds(x):
    assert x >= 1
    k=0
    while x>=2:
        x/=2; k+=1
    def core(z):
        N=18
        lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)), F(0))
        err=2*z**(2*N+1)/((2*N+1)*(1-z*z))
        return lo,lo+err
    l2,u2=core(F(1,3)); l,u=core((x-1)/(x+1))
    return k*l2+l,k*u2+u

counts={'clock_integral':0,'native_center_capacity':0,'native_terminal':0,'inverse_rank':0,'exact_split':0}
# Stage 1: exact monotone Riemann enclosures of the clock primitive.
for s,N in product((F(25+i,24) for i in range(8)),(16,32,64)):
    dx=(s-1)/N
    lower=upper=F(0)
    for j in range(N):
        left=1+j*dx; right=left+dx
        lr,ur=ln_bounds(s/right); ll,ul=ln_bounds(s/left)
        lower+=dx*(1+lr)/right**2
        upper+=dx*(1+ul)/left**2
    ls,us=ln_bounds(s)
    assert lower<=us and ls<=upper
    counts['clock_integral']+=1

def overlap(a,b,c,d):
    return max(F(0),min(b,d)-max(a,c))

# Stage 2: native Lebesgue-center fields, not receiver quadrature.
# f=3/4 on [-4,4], plus total mass 1/5 on [-3/5,-59/100].
# E_u=[-eta,eta], radius Ru; E_w=[2/5-eta,2/5+eta], radius Rw.
# All u cubes contain the packet, and all w cubes exclude it.
q=F(3,4); packet=F(1,5)
for Ru,gap,eta in product((F(3,2),F(8,5),F(17,10)),(F(1,20),F(1,10)),(F(1,100),F(1,50))):
    Rw=Ru+gap; mu=q*Ru+packet; mw=q*Rw
    assert q<=mu/Ru<=1 and mw/Rw==q and mw<mu
    assert eta-Ru/2<=F(-3,5) and -eta+Ru/2>=F(-59,100)
    assert F(2,5)-eta-Rw/2>F(-59,100)
    for yi in range(-14,15):
        y=F(yi,20)
        Tu=overlap(-eta,eta,y-Ru/2,y+Ru/2)/mu+overlap(F(2,5)-eta,F(2,5)+eta,y-Rw/2,y+Rw/2)/mw
        Ju=overlap(-eta,eta,y-Ru/2,y+Ru/2)/mu
        defect=Tu-Ju
        assert defect>=0
        for j in range(5):
            r=Ru+(Rw-Ru)*F(j,5)
            if r>=mu/q:
                assert defect==0
            else:
                lo,_=ln_bounds(mu/(q*r))
                assert defect<=(1+lo)/q
            counts['native_center_capacity']+=1
        clock_defect=defect*(1/Ru-1/Rw)
        lo,_=ln_bounds((mu/Ru)/q)
        assert clock_defect<=lo/(q*Ru)
        # At b=Rw every receiver is present: terminal atom defect is exactly zero.
        Jb=Tu
        assert max(Tu-Jb,F(0))==0
        counts['native_terminal']+=1

# Stage 3a: inclusive ranks and strict-left inverse-rank estimate at atoms.
for weights in product((1,2,3),repeat=4):
    J=sum(F(w,7) for w in weights)
    for h in (F(1,14),F(1,7),F(3,7),F(2)):
        rank=F(0); value=F(0)
        for w in weights:
            before=rank; rank+=F(w,7)
            if before>h: value+=F(w,7)/rank
        if J<=h:
            assert value==0
        else:
            lo,_=ln_bounds(J/h)
            assert value<=lo
        counts['inverse_rank']+=1
# Stage 3b: the exact retained original denominator, including all edge cases.
for T,J,ratio in product((F(0),F(1,4),F(1),F(3)),(F(0),F(1,8),F(1),F(4)),(F(0),F(1,3),F(1))):
    A=J*ratio
    if T==0 or J==0:
        # No original live source at these zero denominators.
        A=F(0); original=retained=paid=F(0)
    else:
        original=A/J
        multiplier=min(F(1),J/T)
        retained=original*multiplier
        paid=original-retained
        assert retained==A/max(J,T)
        assert paid<=max(T-J,F(0))/T
    assert original==paid+retained
    counts['exact_split']+=1
print('PASS',counts,'total',sum(counts.values()))
