from fractions import Fraction as F
from itertools import product
counts={'native_energy':0,'block_schur':0,'weighted_majorant':0}
# Native real-center 1D field: E=[-2,2], f=1 on [-5,5], actual R by patch.
patch=[(F(-2),F(-1),F(1)),(F(-1),F(0),F(1)),(F(0),F(1),F(3,2)),(F(1),F(2),F(2))]
groups=[[0,1],[2],[3]]
def pp(x):return max(F(0),x)
def ramp2(A,B,C,D,s):
 return (pp(D-A+s)**3-pp(D-B+s)**3-pp(C-A+s)**3+pp(C-B+s)**3)/6
def pair(i,j):
 A,B,R=patch[i];C,D,S=patch[j];a=(R+S)/2;b=abs(R-S)/2
 return (ramp2(A,B,C,D,a)-ramp2(A,B,C,D,b)-ramp2(A,B,C,D,-b)+ramp2(A,B,C,D,-a))/(R*S)
def Ji(g,y):
 return sum(max(F(0),min(B,y+R/2)-max(A,y-R/2))/R for i in groups[g] for A,B,R in [patch[i]])
M=[[pair(i,j) for j in range(4)] for i in range(4)]
breaks=sorted({A-R/2 for A,B,R in patch}|{A+R/2 for A,B,R in patch}|{B-R/2 for A,B,R in patch}|{B+R/2 for A,B,R in patch})
for g in range(3):
 for y in breaks+[(a+b)/2 for a,b in zip(breaks,breaks[1:])]:
  assert 0<=Ji(g,y)<=1
  counts['native_energy']+=1
 for h in range(3):
  source=sum((b-a)*(Ji(g,a)*Ji(h,a)+4*Ji(g,(a+b)/2)*Ji(h,(a+b)/2)+Ji(g,b)*Ji(h,b))/6 for a,b in zip(breaks,breaks[1:]))
  receiver=sum(M[i][j] for i in groups[g] for j in groups[h])
  assert source==receiver
  counts['native_energy']+=1
# Indicator Galerkin tests are exact full real-center integrals, not point weights.
for g in range(3):
 for h in range(3):
  for x in product(range(-2,3),repeat=len(groups[g])):
   for y in product(range(-2,3),repeat=len(groups[h])):
    bil=sum(F(x[ii]*y[jj])*M[i][j] for ii,i in enumerate(groups[g]) for jj,j in enumerate(groups[h]))
    # Each fixed-radius source capacity is one, so each block norm is <=1.
    assert bil*bil<=sum(a*a for a in x)*sum(b*b for b in y)
    counts['block_schur']+=1
# Exact weighted-Schur obstruction for the bound matrix s_i s_j, not for K itself.
for s in product((F(1,2),F(1),F(2)),repeat=3):
 B=sum(a*a for a in s)
 for w in product((F(1,3),F(1),F(3)),repeat=3):
  Z=sum(a*b for a,b in zip(s,w))
  ratio=[a*Z/b for a,b in zip(s,w)]
  average=sum((a*b/Z)*r for a,b,r in zip(s,w,ratio))
  assert average==B and max(ratio)>=B
  counts['weighted_majorant']+=2
 Z=sum(a*a for a in s)
 assert all(a*Z/a==B for a in s)
 counts['weighted_majorant']+=1
print('PASS',counts,'total',sum(counts.values()))
# Closed-atom truncated Hardy: g may vary within a single equal-mass atom.
hardy={'atomic_lp':0,'compressed_lp':0,'lift':0}
for weights in ((F(1,8),F(1,4),F(1,2),F(1)),(F(1),F(1,3),F(1,5),F(1,7)),(F(1),)*4):
 masses=[F(1),F(2),F(2),F(8)]
 ranks=[sum(weights[j] for j in range(4) if masses[j]<=m) for m in masses]
 for values in product((F(0),F(1),F(3)),repeat=4):
  for beta in (F(1,4),F(1,2),F(3,4),F(4,5)):
   out=[sum(weights[j]*values[j] for j in range(4) if ranks[j]<beta*ranks[i])/ranks[i] for i in range(4)]
   assert all(sum(weights[j] for j in range(4) if ranks[j]<beta*ranks[i])<=beta*ranks[i] for i in range(4))
   for p in (2,3,4,8):
    lhs=sum(w*x**p for w,x in zip(weights,out));rhs=F(p,p-1)**p*beta**(p-1)*sum(w*x**p for w,x in zip(weights,values))
    assert lhs<=rhs
    hardy['atomic_lp']+=1
# Source-conditional compression for actual finite cube/source incidences.
# Native source integration is exact; receiver weights are quadrature here.
R=[F(1),F(1),F(3,2),F(2)];cent=[F(-1,4),F(1,4),F(0),F(1,2)]
ends=sorted({x for a,r in zip(cent,R) for x in (a-r/2,a+r/2)})
cells=[]
for j,(a,b) in enumerate(zip(ends,ends[1:])):
 y=(a+b)/2;f=F(1)+F(j%3-1,8);c=[int(abs(y-z)<r/2) for z,r in zip(cent,R)]
 if any(c):cells.append(((b-a)*f,c))
m=[sum(f*c[u] for f,c in cells) for u in range(4)]
du=[F(1,5),F(1,3),F(1,2),F(2,3)];mu=[du[u]/m[u] for u in range(4)]
q=[m[u]/R[u] for u in range(4)];lam=F(9,8);qmin=3*lam/4;ratio=lam/qmin
assert all(qmin<=a<=lam for a in q)
for beta in (F(1,4),F(1,2),F(3,4),F(4,5)):
 B=[[F(0) for v in range(4)] for u in range(4)]
 for f,c in cells:
  T=[sum(mu[v]*c[v] for v in range(4) if m[v]<=m[u]) for u in range(4)]
  for u in range(4):
   if not c[u] or not T[u]:continue
   for v in range(4):
    if T[v]<beta*T[u] and m[v]<m[u]:
     mark=F(1+(u+v)%3,3)
     B[u][v]+=f*c[v]*mu[v]*mark/(m[u]*T[u])
 assert all(sum(row)<=beta for row in B)
 for g in product((F(-1),F(0),F(2)),repeat=4):
  out=[sum(B[u][v]*g[v] for v in range(4)) for u in range(4)]
  for p in (2,3,4,8):
   lift=sum(f*sum(mu[u]*c[u]*abs(g[u])**p for u in range(4)) for f,c in cells)
   base=sum(du[u]*abs(g[u])**p for u in range(4))
   assert lift==base
   constant=F(p,p-1)**p*beta**(p-1)
   assert sum(du[u]*abs(out[u])**p for u in range(4))<=constant*base
   assert sum(q[u]*du[u]*abs(out[u])**p for u in range(4))<=ratio*constant*sum(q[u]*du[u]*abs(g[u])**p for u in range(4))
   hardy['lift']+=1;hardy['compressed_lp']+=2
print('PASS Hardy',hardy,'total',sum(hardy.values()),'all_total',sum(counts.values())+sum(hardy.values()))
# Conditional bridge: exact Young optimizer and a finite positive nilpotent kernel.
bridge=0
for p in (2,3,4,6,8):
 alpha=F(p-1,p)
 for A in (F(1,2),F(1),F(2),F(3)):
  for eps in (F(1,8),F(1,3),F(1),F(2)):
   root=alpha*A/eps;t=root**p
   C=alpha**(p-1)*A**p/(p*eps**(p-1))
   assert A*root**(p-1)-eps*t==C
   bridge+=1
K=[[F(0),F(1,4),F(1,8)],[F(0),F(0),F(1,4)],[F(0),F(0),F(0)]]
def act(x):return [sum(K[i][j]*x[j] for j in range(3)) for i in range(3)]
a=act([F(1)]*3);Ka=act(a)
for D in (F(1),F(2),F(4)):
 for Fv in product((F(0),F(1,4),F(1)),repeat=3):
  e=[max(F(0),a[i]-Ka[i]-D*Fv[i]) for i in range(3)]
  forcing=[D*Fv[i]+e[i] for i in range(3)]
  term=forcing;total=[F(0)]*3
  for _ in range(3):total=[total[i]+term[i] for i in range(3)];term=act(term)
  assert all(a[i]<=total[i] and 0<=e[i]<=a[i]<=1 for i in range(3))
  assert term==[F(0)]*3
  bridge+=2
print('PASS conditional_bridge',bridge,'all_total',sum(counts.values())+sum(hardy.values())+bridge)
