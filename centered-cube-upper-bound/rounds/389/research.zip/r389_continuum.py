"""R389 actual positive-du order-fee witness. Exact rational bounds, stdlib only."""
from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import hashlib,json
COUNT=0

def ck(x):
 global COUNT
 assert x
 COUNT+=1

def logbounds(x,N=28):
 assert x>=1
 k=0
 while x>2:x/=2;k+=1
 def core(z):
  t=(z-1)/(z+1)
  lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
  return lo,lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 lo,hi=core(x);l2,u2=core(F(2));return lo+k*l2,hi+k*u2

explo=sum((F(2**j,factorial(j)) for j in range(31)),F(0))
exphi=explo+F(2**31,factorial(31))/(1-F(2,32))
ck(7<explo<exphi<8)

def case(eta,b,wfactor,P):
 n=4;bg=F(3,4);left=F(1,5);a=rv=F(51,100);ru=F(1)
 bw=wfactor*eta;vu=vv=eta**n;vw=bw**n;VD=F(1,100)**n;fD=bg+P/VD
 mv=bg*rv**n+P;qv=mv/rv**n
 mu0=F(17,20)+P;mu_lo=mu0-left*eta/2;mu_hi=mu0+left*eta/2
 mw0=bg*b**n+left*(b/2-F(2,5))*b**3+P
 mw_lo=mw0-left*b**3*bw/2;mw_hi=mw0+left*b**3*bw/2
 ck(a<ru<b<=2*a and bw>0)
 ck(F(3,4)<=qv<=1 and F(3,4)<=mu_lo<=mu_hi<=1)
 ck(F(3,4)<=mw_lo/b**n<=mw_hi/b**n<=1)
 ck(mw_hi<mu_lo and mu_lo>8*mv and mw_lo>mv)
 # Complete real center domains: cube-source geometry, no point quadrature.
 Dlo=[F(47,100)]+[F(1,10)]*3;Dhi=[F(12,25)]+[F(11,100)]*3
 for center,R,side in [([F(0)]*4,ru,eta),([F(7,10)]+[F(1,4)]*3,rv,eta),([F(2,5),F(0),F(0),F(0)],b,bw)]:
  for i in range(4):
   ck(center[i]+side/2-R/2<=Dlo[i] and center[i]-side/2+R/2>=Dhi[i])
   ck(abs(center[i])+side/2+R/2<2)
 ck(F(7,10)-eta/2-rv/2>0) # v has no left-density background
 ck(-eta/2-ru/2<0<eta/2+ru/2)
 ck(F(2,5)+bw/2-b/2<0<F(2,5)-bw/2+b/2)
 ck(eta<F(1,10) and bw/2+eta/2<F(3,10)) # disjoint boxes
 ck(fD>4*max(qv,mu_hi,mw_hi/b**n)) # n4 original T=4
 # Genuine actual occupation integrals lie in these exact interval bounds.
 Iv=vv/mv;Iu_lo=vu/mu_hi;Iu_hi=vu/mu_lo;Iw_lo=vw/mw_hi;Iw_hi=vw/mw_lo
 Jlo=Iv+Iu_lo;Jhi=Iv+Iu_hi
 Tlo=Iv+Iw_lo;Thi=Iv+Iw_hi+Iu_hi
 Jblo=Iv+Iu_lo+Iw_lo;Jbhi=Thi
 ck(Tlo>Jhi and Jblo>Jhi)
 h=H=Iv/100
 ck(Iv>h and Jlo>H)
 # For any u, strict massfar sourcepast includes the entire real v family.
 ck(mu_lo>8*mv and mu_hi<7*mw_lo and mu_hi<7*mu_lo)
 emin=1-Jhi/Tlo;emax=1-Jlo/Thi
 ck(0<emin<=emax<1)
 # Complete physical clock: continuous interval before b + terminal b atom.
 ellv=rv**(-4)-1;ellu=1-b**(-4);ellb=b**(-4)
 ck(ellv+ellu+ellb==rv**(-4) and ellu>0 and ellb>0)
 # Pointwise order factor e is zero at b, since every mass-ranked receiver
 # is physically present; no source/rank atom gets omitted.
 for IU,IW,frac in product([Iu_lo,Iu_hi],[Iw_lo,Iw_hi],[F(0),F(1,2),F(1)]):
  JJ=Iv+IU+IW;TT=Iv+IW+frac*IU
  ck(TT<=JJ and max(F(0),1-JJ/TT)==0)
 # Normalized denominator identity on every corner of the certified early box.
 for JJ,TT in product([Jlo,Jhi],[Tlo,Thi]):
  ee=max(F(0),1-JJ/TT)
  ck((1-ee)/JJ==1/max(JJ,TT))
 # Full pairbox target capture bounds, not values at center surrogates.
 diffs=[F(7,10)]+[F(1,4)]*3
 for d in diffs:ck((ru-rv)/2<d-eta and d+eta<(ru+rv)/2)
 ck((2*(diffs[0]-eta)/ru)**n>3)
 excess=[2*(d-eta)-(ru-rv) for d in diffs]
 ck(all(z>0 for z in excess) and n>F(n,8) and sum(excess)>F(n,20))
 beta=1+F(1,n)
 ck(sum(excess)>n*((1+beta)*rv-ru)**2/(4*beta*rv))
 pmin=((ru+rv)/2-diffs[0]-eta)/rv*(((ru+rv)/2-diffs[1]-eta)/rv)**3
 pmax=((ru+rv)/2-diffs[0]+eta)/rv*(((ru+rv)/2-diffs[1]+eta)/rv)**3
 ck(0<pmin<=pmax<1)
 source_excess=(fD-qv)*VD/mv
 gaplo=1-mv/mu_lo;gaphi=1-mv/mu_hi
 prelo=vu*vv*source_excess*gaplo*(1-pmax)
 prehi=vu*vv*source_excess*gaphi*(1-pmin)
 # Actual interval integral includes variable m_u,T_u and target overlap.
 # These are rigorous full-dx bounds, NOT a center-value quadrature.
 original_interval_lo=prelo*ellu/Jhi;original_interval_hi=prehi*ellu/Jlo
 order_lo=prelo*ellu*emin/Jhi;order_hi=prehi*ellu*emax/Jlo
 remaining_interval_lo=prelo*ellu/Thi;remaining_interval_hi=prehi*ellu/Tlo
 original_terminal_lo=prelo*ellb/Jbhi;original_terminal_hi=prehi*ellb/Jblo
 ck(0<order_lo<=order_hi and 0<original_interval_lo<=original_interval_hi)
 ck(0<remaining_interval_lo<=remaining_interval_hi)
 ck(order_hi<=original_interval_hi and original_terminal_lo>0)
 # Full source and full receiver fields retained in X/W and the source fee.
 W=bg*4**4+left*F(4**4,2)+P
 E=vu+vv+vw
 Xlo=vu*mu_lo+vv*qv+vw*mw_lo/b**4
 Xhi=vu*mu_hi+vv*qv+vw*mw_hi/b**4
 ck(bg*E<=Xlo<=Xhi<=E)
 Jglobal=Jbhi
 lq,uq=logbounds(F(4,3));lr,ur=logbounds(Jglobal/h)
 ck(0<lq<=uq and 0<lr<=ur)
 fee_lower=F(4,3)*lq*lr*W;fee_upper=F(4,3)*uq*ur*W
 ck(fee_lower<=fee_upper and order_hi<=fee_upper)
 return {'eta':str(eta),'b_Rw':str(b),'w_side_factor':str(wfactor),'P':str(P),
  'qv':str(qv),'qu_lower':str(mu_lo),'qu_upper':str(mu_hi),'qw_lower':str(mw_lo/b**4),'qw_upper':str(mw_hi/b**4),
  'mu_bounds':[str(mu_lo),str(mu_hi)],'mw_bounds':[str(mw_lo),str(mw_hi)],'mv':str(mv),
  'J_early_bounds':[str(Jlo),str(Jhi)],'Tu_early_bounds':[str(Tlo),str(Thi)],
  'order_factor_bounds':[str(emin),str(emax)],'terminal_order_factor':'0',
  'original_interval_cost_bounds':[str(original_interval_lo),str(original_interval_hi)],
  'positive_order_fee_bounds':[str(order_lo),str(order_hi)],
  'remaining_max_denominator_interval_bounds':[str(remaining_interval_lo),str(remaining_interval_hi)],
  'original_terminal_cost_bounds':[str(original_terminal_lo),str(original_terminal_hi)],
  'capture_bounds':[str(pmin),str(pmax)],'h_H_diagnostic':str(h),'W_full_f':str(W),
  'E_volume':str(E),'Xq_bounds':[str(Xlo),str(Xhi)],
  'uniform_J_bound':str(Jglobal),'analytic_source_fee_display_bounds':[str(fee_lower),str(fee_upper)],
  'order_lower_over_X_upper':str(order_lo/Xhi),'order_upper_over_X_lower':str(order_hi/Xlo)}

def summary(cases):
 out={'executed_parameter_fields':len(cases),'exact_case_digest':hashlib.sha256(json.dumps(cases,sort_keys=True).encode()).hexdigest()}
 for key in ['positive_order_fee_bounds','order_factor_bounds']:
  out[key+'_global_lower']=str(min(F(c[key][0]) for c in cases))
  out[key+'_global_upper']=str(max(F(c[key][1]) for c in cases))
 return out

def main():
 initial=[case(F(1,1000),F(101,100),F(2),F(1,2**20))]
 pressure=[case(e,b,f,F(1,2**20)) for e,b,f in product([F(1,2000),F(1,1000),F(1,500)],[F(201,200),F(101,100),F(203,200)],[F(3,2),F(2),F(5,2)])]
 expanded=[case(e,b,f,p) for e,b,f,p in product([F(1,2000),F(1,1000),F(1,500)],[F(201,200),F(101,100),F(203,200)],[F(3,2),F(2),F(5,2)],[F(1,2**22),F(1,2**20),F(1,2**18)])]
 result={'scope':'Genuine positive-volume Lebesgue receiver boxes and full positive L1 step source; masses vary continuously with first receiver coordinate. Exact Fraction enclosures certify positive clock-order cost, not exact center quadrature. Actual q-band/matching/same-full-f caps, strict exp2 massfar, sourceD commoncapture, inherited outside/dense/deep/not-Bplus scalar geometry and literal h/H gates realized. Not the R385-388 filtered G_smooth or synchronized native/historical qualification. Analytic sourcefee display bound is not its actual cost integral.',
  'fraction_assertions':COUNT,'baseline':initial[0],'stages':{'initial':summary(initial),'pressure':summary(pressure),'expanded':summary(expanded)}}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNT,'exact Fraction assertions; fields1/27/81')
 print('baseline order bounds',initial[0]['positive_order_fee_bounds'],'e bounds',initial[0]['order_factor_bounds'])
if __name__=='__main__':main()
