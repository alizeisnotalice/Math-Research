# R389 independent audit — FINAL PASS

Scope: this file only; no author/repository edits. Both candidates were derived independently before reading new R389 author proofs. Final proofs, scripts, result/notes and integrated main/ledger/readme have now been reviewed. PASS applies to the exact statements and accounting below. A frozen Lp contraction is not an original-history flow or a source-W budget, and general closure is not certified.

## 1. Positive clock-lag payment in the original flow

Keep full f, actual finite E/du, positive matched m_u=q_u R_u^n with q_-<=q_u<=lambda, original mass-far gate K>lambda/q_-, strict Z_u>h, all actual marks and the complete physical clock. Let T_u=T_y(m_u), J=J_y(r), and e=(1-J/T_u)_+. On original live sources T_u>=Z_u>h, so this denominator is positive. Zero-J sources have no original cost by its convention.

The set counted by T_u but missing from J consists of actual receivers w with R_w>r and m_w<=m_u. Additional J receivers with mass>m_u can only reduce T_u-J. Thus

    (T_u-J)_+ <= integral c_w(y)1_{R_w>r,m_w<=m_u}dw/m_w.

For r<(m_u/q_-)^(1/n), actual capture and matching dominate this missing measure by

    q_-^-1[1+log(m_u/(q_- r^n))].

Indeed R_w>r and m_w>=q_-R_w^n imply 1/m_w<=1/[q_- max(r,2||w-y||_infinity)^n], and capture implies 2||w-y||_infinity<=(m_u/q_-)^(1/n). The radial center-volume variable (2||w-y||_infinity)^n integrates to the displayed quantity. If r>=(m_u/q_-)^(1/n) the missing set is empty. This is a real receiver-center envelope, not a source-density cap. At r=b no receivers are missing and e=0, so the physical terminal atom contributes no price.

In the original positive cost, sum the small-v measure first: it is at most J_y(r). Use loss m_u-m_v<=m_u. The paid proportion e therefore costs at most integral f(y)c_u(y)du ell(dr) e. Bound e by the missing measure/T_u. Set x=(r/R_u)^n and s=q_u/q_-; the continuous clock change gives

    integral_1^s [1+log(s/x)]dx/x^2=log s.

An antiderivative is -log(s/x)/x. Integrating only up to the actual b, if smaller, can only lower this nonnegative upper bound. Hence the paid cost is at most

    (lambda/q_-)log(lambda/q_-)
       * integral f(y) integral c_u(y)du/[m_u T_y(m_u)]dy.

On these sources, strict mass past gives T_y(m_u-)>h, since K>1. The atom-safe right-rank inequality integral 1_{T(t-)>h}dT(t)/T(t)<=log_+(J_b/h) excludes an initial crossing atom and handles continuous/singular parts. Therefore the actual proportional payment is bounded by

    P_lag W,  P_lag=(lambda/q_-)log(lambda/q_-)
                       log_+(Jmax/h).

More precisely retain integral f(y)log_+(J_b(y)/h)dy in place of log_+(Jmax/h)W. When lambda=q_- the missing future mass-prefix is empty and the price is zero. No extra first-jump, scale-bin or h factor is introduced. This receipt adds a genuine source-W fee to its positive branch, subject to final accounting.

## 2. Exact retained denominator and frozen mass-prefix kernel

Retain the original traffic with factor 1-e=min(1,J/T_u). Its original reciprocal J becomes exactly

    (1-e)/J=1/max(J,T_u)<=1/T_u.

Every original high-J, far, spatial, source, target and history mark stays in place. The new bound is an upper kernel with the ORIGINAL mass prefix; it is not obtained by rebuilding a smaller field or pretending that the mass prefix equals the radius prefix.

Normalize the original clock by nu_u(dr)=R_u^n ell(dr) on[R_u,b], a probability including b's atom. Normalize full source by pi_u=f c_u dy/m_u. All remaining factors, including 1-m_v/m_u, Tu/max(J,Tu) and other labels, are in[0,1]. Their clock average is a measurable frozen mark in[0,1]. The resulting nonnegative linear operator is

    K g(u)=integral pi_u(dy) integral nu_u(dr)
       integral mark(r,y,u,v)c_v(y)g(v)dv/[m_v T_y(m_u)].

Its actual small endpoints satisfy T_y(m_v)<b T_y(m_u), where b=(1+d)^-1 in(0,1) from the R387 near-rank complement. This is a single-edge condition; original future-history qualification is not asserted.

## 3. Atom-safe Hardy bound and measures

Fix y and rho_y(dv)=c_v(y)dv/m_v. The selected input endpoints have rho_y mass at most bT_y(m_u), by closed-CDF capacity (strict endpoints can only reduce it). Let g_y^* be the decreasing rearrangement of |g| for this finite measure. Dropping marks positively gives

    |K_y g(u)|<=F(T_y(m_u)),
    F(t)=t^-1 integral_0^{bt}g_y^*(s)ds.

F is decreasing because g_y^* is decreasing. Uniformize each mass atom over its occupied rank interval: output random rank s is at most its RIGHT closed rank T_y(m_u), so F(T_y(m_u))<=F(s). Integrating yields the usual Hardy-dilation estimate, for every 1<p<infinity,

    ||K_y g||_Lp(rho_y)<=p' b^(1-1/p)||g||_Lp(rho_y).

This handles mass atoms without replacing right ranks by equalities, or losing a first-rank term. Zero-rank output points have zero rho_y mass; use the original zero-cost convention there. Finite rho_y and then standard Lp approximation justify the rearrangement for unbounded input g.

The lift g(u)->g(u) in the joint measure du pi_u(dy)=f(y)dy rho_y(du) is an isometry from Lp(du), since full-f matching makes pi_u a probability. Conditional projection E_pi is a contraction; integration of the common-y estimate gives

    ||K||_Lp(du)<=p' b^(1-1/p).

Arbitrary u-dependent clock averages do not invalidate this: their nonnegative marks were bounded by one before rearrangement, with their probability normalization retained. For signed/complex g use positivity and |Kg|<=K|g|. The q-band then yields

    ||K||_Lp(q_u du)<=(lambda/q_-)^(1/p)p'b^(1-1/p).

As p increases to infinity this bound tends to b<1, so some finite sufficiently large p gives a strict contraction. Its admissible p and resolvent constants depend on the fixed d and q-band. The operator also has row mass<=b, directly by the same occupation capacity.

This is a legitimate frozen-operator/resampling contract. It does NOT make the operator the original history transition, preserve descendant entrance qualifications, or furnish a source-W root budget. The Lp(qdu) constant cannot be reinterpreted as an uncharged source capacity or a terminal settlement. Any later use must retain the actual input, output and renewal/defect fees explicitly.

## 4. Initial accounting and bounded local evidence

A final integration must add only the clock-lag price of Section 1 (with outer 2Lambda in the original entrance), retain all prior source fees and X allocations, and split the exact original cost before replacing its denominator by the upper mass-prefix kernel. Neither an operator norm nor a formal resolvent alone pays the remaining actual cost. No old square, R385 witness or other paid branch is subtracted a second time.

Reviewer actually ran 2916 standard-library Fraction finite mass-rank p=4 Hardy cases. They check the displayed fourth-power bound on finite atomic measures, not actual cube/history realizations or a general spectral proof. A local SymPy import was unavailable; the elementary original-clock antiderivative and integral identity above were checked analytically, not represented as a successful symbolic software run. No author pipeline was repeated.

PASS for both exact candidate statements and their measure/atom/clock constants. Final author and integrated reviews follow.


## 5. Author Hardy proof and checks reviewed

After the independent screen, read r389_aux.md and its entire check script. Its fixed-source decreasing rearrangement and RIGHT-rank comparison agree with Section 3, including g varying inside an equal-mass atom. The lift/isometry, conditional projection and variable-q factor are explicit and correct. Its measurable frozen kernel is defined without needing a jointly measurable optimizer/rearrangement. All old clock averages may be absorbed into a mark<=1 after their genuine probability normalization, with no loss of the sourcewise bound.

The explicit p choice is valid: for p>=2, log(p')<=2/p, so choosing p>=max(2,2[2+log(1+d)+log(lambda/q_-)]/log(1+d)) bounds the qdu norm by (1+d)^(-1/2)<1. B1<=beta also gives a legitimate auxiliary subprobability kernel. This does not certify later original arrivals or terminal/forcing prices; the note specifically warns that even the auxiliary adjoint arrivals need not remain pointwise bounded by qdu.

Its supplementary block-kernel calculations correctly identify du rather than mdu as the receiver measure. The weighted rank-one majorant retains a generally linear dimension upper bound, which is not a lower bound on the true operator or a counterexample to better geometry. These statements are auxiliary and receive no ledger payment.

The author's initial 10564 Fraction checks (subsequently extended to 10806 as recorded in Section 6) are transparently split: 2788 native one-dimensional center-energy/block/majorant tests and 7776 finite-atomic Hardy/compression/lift tests. The latter exact source/cube cells use receiver quadrature and do not certify a native continuum high-history field. Sampled p cases do not substitute for the general contraction proof. The declared scope matches the code read. No complete parent pipeline was repeated.

Author Hardy proof: PASS within its stated auxiliary scope. Clock proof, final actual examples and integration are reviewed below.


## 6. Final clock proof and updated exact-kernel auxiliary review

Read the complete final r389_geometry.md and its check script. Its future-receiver center envelope, separate zero terminal defect, exact antiderivative and strict-left inverse-rank payment agree with Section 1. The special case constant q gives no ordering error because mass order then implies radius order. The actual retained denominator is max(J,T_u), not an alteration of original J.

Equations (15a)--(15b) retain T_u/max(J,T_u) in a SINGLE normalized physical-clock average. Their expression has q_u/T_u times (1-m_v/m_u) against f c_u c_v mu(du)mu(dv), which is correct by m_u/R_u^n=q_u. This is an exact actual-cost identity. Dropping the ratio instead gives only the displayed G_prefix upper bound, and the two costs are not interchanged.

Read the updated r389_aux.md Section 5, Section 8 and appended checks. Its chi_actual includes original memberships, high-J, mass loss, all old marks and that denominator ratio. Consequently G_order=integral q_u(K_actual1)(u)du is exact, and the atomic Hardy proof applies to this frozen kernel directly. The old R388 pre-payment a_mid is not replaced in its posterior failure conditions by the new smaller a389=K_actual1.

The auxiliary row cap gives a389<=beta and K_actual a389<=beta a389. Thus the unproved pointwise condition a389<=K_actual a389+DF would merely give a389<=DF/(1-beta), an enlarged old witness coefficient. The text correctly stops treating it as a new geometric mechanism. Its actual defect, conditional Neumann implication and scalar Young constant are algebraically valid; no defect/source budget is supplied or assumed. The additional 242 tests certify that conditional algebra only. The final auxiliary count is 10806, including rather than adding again the earlier 10564 tests.

The clock script's 2484 Fraction assertions separate analytic-antiderivative checks from rational interval diagnostics, actual one-dimensional receiver-center capacity examples, terminal-zero identities and atomic/rational cost splits. It does not claim the native one-dimensional fields realize the original exponential-far/high-history residual. No whole pipeline was repeated in this independent file review.

## 7. Independent initial review of the n=4 continuous-clock positive example

Read the complete r389_continuum.py. Its intended full source is background (3/4) on Q4 plus an additional density 1/5 on the negative-first-coordinate half of Q4, plus packet mass P on D=[.47,.48]x[.10,.11]^3. The big center family is near zero, radius 1; small v near (.7,.25,.25,.25), radius .51; future w near (.4,0,0,0), radius b>1. All are actual positive-volume center boxes inside the stated support, and all their selected cubes capture D. Masses vary with their actual first coordinate:

    m_u=.85-(1/5)u_1+P,
    m_w=(3/4)b^4+(1/5)(b/2-w_1)b^3+P,
    m_v=(3/4)(.51)^4+P.

The code's interval endpoints therefore bound the full center fields, not just nominal centers. It checks q in[3/4,1], m_w<m_u while R_w>R_u, and m_u>8m_v with exp(2)<8. The lower exp(2)>7 certificate excludes w and other big masses from u's strict far past; the small v family remains included. Whole-pair source capture and inherited outside/dense/deep/not-Bplus scalar geometry inequalities hold on all relevant boxes, with diagnostic h/H only.

On D during r in[1,b), original J contains v and all u but not future w, while T_u contains all v and future w plus a variable portion of u. The code rigorously bounds these by Jlo/Jhi and Tlo/Thi. Tlo>Jhi proves a strict positive ordering factor for EVERY actual pair/source point. The complete clock on this interval has weight 1-b^-4; at b all receiver families are present, hence every mass prefix is included in J_b and ordering factor is zero. The terminal original cost may remain positive, but its ordering payment is exactly zero.

The original cost, ordering-payment and max-denominator remaining interval are bounded by conservative products of full-domain positive bounds: variable mass gap, target uniform-overlap fraction, J, T_u, and e. Each inequality direction is correct. These are exact rational ENCLOSURES of continuous integrals, not values at nominal centers. The positive lower ordering-payment certificate proves genuine continuous-clock activity. The analytic source-fee display is a bound from a uniform full-receiver occupation upper and outward rational logarithm intervals, not a computation of its actual source integral.

The script explicitly excludes certification of R385--388's complete filtering or a native G_smooth instance, synchronized h or historical acceptance. These restrictions must remain in the final note/main/readme. Final numeric explanation/results and integrated files have now been reviewed below.


## 8. Final continuum explanation/result and exact diagnostic scope

Read the final continuum explanation, latest code and saved JSON. The final explanation explicitly writes the intended full step source and variable real masses used in Section 7. It distinguishes true continuous interval-cost enclosures from exact equalities and from nominal-center values. Its terminal-zero statement uses the shared actual Iu/Iw and partial-Iu identity, not unrelated interval endpoints. Independent lower/upper enclosures for paid and remaining costs are not falsely required to sum endpoint by endpoint.

The final log display encloses the bounding expression (lambda/q_-)log(lambda/q_-)log_+(Jglobal/h)W using a valid uniform full-receiver occupation upper. Its lower endpoint is NOT a lower bound for the actual global source payment; its upper endpoint is a valid analytic price upper. The main/readme accurately maintain this distinction. Costs refer only to designated u-to-v raw clock traffic, not all flow. The positive order lower and zero terminal order factor are genuine original-clock statements, but the example is explicitly NOT the R385--388 fully filtered G_smooth or a synchronized/native historical certificate. Tiny cost/X, complete W, repeated parameter executions and no-near-extremizer scope are retained.

The saved result records 7413 Fraction assertions and 1/27/81 parameter-field executions with repetition; its terminal order factor is zero. The code uses only local standard-library dependencies and outputs JSON alongside itself. All arithmetic used for assertions is rational, with explicit rational exp/log bounds. No optimizer, point-receiver surrogate or Monte Carlo appears. No whole parent pipeline was repeated by this reviewer.

## 9. Final full accounting and limits

Read final main/ledger/readme. The prior ledger prefix through R388 is byte-for-byte unchanged from the already bound R388 ledger. The appended exact update is

    BH<=G_order+E387 X_q+(C338+S386+P388+P389)W,
    P389=(lambda/q_-)log(lambda/q_-)log_+(Jmax/h).

The original entrance retains 8lambda H W, 2d_eff A_n W_nu/H, twice G_order, twice E387 and twice the entire source coefficient, then multiplication by Lambda. Thus P389 receives exactly 2Lambda; no new X term, parameter/target-cap/template change or second source payment from the auxiliary Hardy theorem occurs. The same h is used throughout. P389 is only logarithmic under the stated synchronized threshold and does not increase the previous displayed root-logarithmic source exponent. It does not pay the original H entry or other slots.

The final exact actual kernel K_actual, its row a389=K_actual1, and the prior R388 pre-payment a_mid are explicitly distinct. The old posterior failure gate remains a statement involving a_mid and its actual F, not a stronger unproved statement involving the smaller a389. The upper G_prefix representation is also distinct from the exact G_order. These distinctions prevent inheriting an old trigger or reducing an old fee without a new proof.

The proved atomic Hardy contraction is a legitimate frozen-field norm/resolvent statement, with explicit qdu factor and row cap. Its iteration does not certify the original source/target/history law, and no forcing/terminal source price is supplied. The conditional a389<=Ka389+DF route is explicitly recognized as an unproved constant enlargement of the old witness, not a new geometric payment. Neither its defect nor a resolvent norm is inserted as a free source-W budget.

The actual G_order common-source geometric budget, original H entrance/choice, soft/crossing/entry, heavy-tail/wide-distance/low-pe/extreme-scale complements, initial/deleted/future-deleted history atoms, all-scale/source aggregation, truncation and limits remain unpaid. The physical terminal ordering defect being zero does not make historical atoms free. No general centered-cube root bound, positive covered fraction, or original-history flow is certified.

Parent reports successful actual runs 2484+10806+7413=20703 Fraction assertions. The auxiliary total 10806 includes its initial 10564 and the added 242 conditional checks; it is not counted twice. Reviewer bounded evidence consists of the separate 2916 finite-rank p=4 cases. The unavailable local SymPy import was not represented as a successful symbolic computation or as a claim about every local Python environment. This audit does not certify LaTeX layout/compilation or freshly re-prove the entire historical reduction.

FINAL PASS: no outstanding correction found in the clock-order receipt, exact actual-kernel mapping, auxiliary contraction, native diagnostic or final accounting. The general remaining budget remains open.

## 10. Final byte bindings

| File | SHA256 |
| --- | --- |
| `/tmp/r389_main.md` | `67bd456605251241ad659871b5aa00dadcad76b7e91635b5cb76df5cc67c3b90` |
| `/tmp/r389_ledger.md` | `10f4145bbc83290f6482ef6ac3b4289ff2d59921e74cb9ff011685c53c9bb7d6` |
| `/tmp/r389_readme.md` | `6a37b32d5e88c5433cc9edc8aff8692ecc3adc61359857d70a4f009c2b4f72f8` |
| `/tmp/r389_geometry.md` | `e007b0a5fca2af7e19fd8f7574c110c2ce1029de5d46d056c837fdecb22f2985` |
| `/tmp/r389_geometry_check.py` | `e68195cf9372da7b936043e8866bff86657a1d443834e1a68629df4d323decb7` |
| `/tmp/r389_aux.md` | `a9886d08238803e049faa6f34085d823fa888cfede624756f10b3d962ad07fc4` |
| `/tmp/r389_aux_check.py` | `027de56644790b63a9f7aa18d6cf087ce814f3052b2f3128d61cf676b725c3ec` |
| `/tmp/r389_continuum.md` | `26023d5aa4fc5ca0dc29898f8076535ebdd94010da750098682d7baf62da43d3` |
| `/tmp/r389_continuum.py` | `abdf302ea6925a028123c50911cc93a926249ba49f8f541645d07c374c2d5e7b` |
| `/tmp/r389_continuum.result.json` | `d89d7547d9cb0f090fd4753c6bea6f17981b4f0e9e4684aacb844fc973ccb61b` |
| `/tmp/r388_geometry.md` | `b3868aa0575a9893734711b9d39d8922f8f43b82fc6afc14791e9beef6ed7d00` |
| `/tmp/r388_ledger.md` | `0b6e2e2d45ac4db56e1abfe6497766670c953b2e84766c5890f6065052fa6950` |
| `/tmp/r387_geometry.md` | `683e9f7886d1e893b0923c5268840c5e696f8c94e55f1ecdb92050c4cfb14458` |
| `/tmp/r386_geometry.md` | `fe839792aff6ca2b1fcb6787a8073fe71d8ca3dd28b8d46585d350d2c5851bca` |
| `/tmp/r383_flow.md` | `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd` |
