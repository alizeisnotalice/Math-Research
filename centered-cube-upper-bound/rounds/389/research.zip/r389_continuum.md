# R389: positive clock-order payment on a real continuous receiver field

This verifies the new general clock-order receipt on a genuine positive-volume L1 source/receiver input. The cost is enclosed by exact Fraction bounds over full continuous center boxes; receiver-center values are never substituted for du integrals. It is not the R385–R388 filtered G_smooth, synchronized high-past choice, a historical FIRST/old-selector realization, or a general closure certificate.

## Complete input and actual matched masses

Use n=4, lambda=1, a=Rv=.51, Ru=1 and b=Rw=1.01 at baseline. The full source is

f(x)=[.75+.2*1_(x1<0)]1_Q4(x)+(P/|D|)1_D(x),
D=[.47,.48] times [.1,.11]^3, |D|=10^-8, P=2^-20.

Three disjoint real receiver center boxes have centers

u: (0,0,0,0), side eta=.001, actual R=L=1;
v: (.7,.25,.25,.25), side eta, actual R=L=.51;
w: (.4,0,0,0), side wfactor*eta, wfactor=2, actual R=L=b.

Hard softness is zero. Every actual capturing cube contains all D and lies in Q4. The v cubes are wholly on the positive x1 side; u and w cut the x1=0 background interface. Actual mass matching is therefore

mu(u)=.85-.2*u1+P,
mv=.75*.51^4+P,
mw(w)=.75*b^4+.2*(b/2-w1)*b^3+P.

These are variable real masses, not frozen center approximations. All actual q=m/R^4 lie in [3/4,1], so q<=lambda and same-full-f matching/cap hold. There is no first-crossing/old-selector certification. Full source mass is W=217.6+P. The full receiver volume and Xq enclosure include all three families.

A rational Taylor certificate proves 7<exp(2)<8. Actual mu_min>8mv, hence u→v is strictly mass-far for the original exp(sqrt(4)). All w and other u masses exceed mu_max/7, so the source-D strict far past of every u is exactly the complete v occupation. The inherited scalar outside/dense/deep/not-Bplus inequalities also hold over every u/v pair box. These geometric tests do not imply the later R385–R388 retentions or original history labels, which are not simulated. The n4 source threshold T=4 is checked on D.

## How the physical/mass order actually disagrees

Let Vu=Vv=eta^4 and Vw=(wfactor*eta)^4. On every y in D define actual continuous occupation integrals

Iv=Vv/mv,
Iu=integral_(u box)du/mu(u),
Iw=integral_(w box)dw/mw(w).

The script rigorously encloses Iu between Vu/mu_max and Vu/mu_min, and similarly Iw. These are integral bounds from genuine pointwise mass bounds, not center quadrature. On the physical clock interval [1,b),

J=Iv+Iu,
T_y(mu(u))=Iv+Iw+Iu_partial(u), 0<=Iu_partial<=Iu.

All w receivers are mass-earlier, since mw_max<mu_min, although physically Rw>Ru. For every tested field the exact rational enclosures imply

Tu_lower=Iv+Iw_lower > J_upper=Iv+Iu_upper.

Thus e=(1-J/Tu)+ is strictly positive on the complete u box and source D, for every physical r in [1,b). Select literal h=H=Iv/100, so the original strict-past and high-J conditions are nonempty. This h/H is diagnostic, not synchronized to a global absorption ledger.

At r=b the actual Jb=Iv+Iw+Iu contains every physical family. Consequently Tu=Iv+Iw+Iu_partial<=Jb exactly, and the terminal order factor is zero. The code checks this matched partial-occupation identity at the bounding corners and three partial fractions; it does not compare unrelated interval endpoints to infer the result.

The physical clock is kept in full: the first continuous prefix interval has weight Rv^-4-1, the interval [1,b) has weight 1-b^-4, and the genuine terminal atom has weight b^-4. Their sum is Rv^-4. There is no invented atom at the first menu radius.

## Certified actual-du cost enclosures

The positive source excess of the designated v is supported only on D: its actual Qv lies in x1>0, where the background is .75<qv. All overlap coordinates are in their partial affine regimes across the full u/v center boxes. The geometric target-uniform capture p(u,v) is bounded by substituting the coordinate difference extrema into the exact overlap product, giving p_min<=p<=p_max<1. This is not the full-f posterior capture; it is the actual uniform target factor in the original product-surplus cost.

The designated raw interval cost is the true integral

integral_du dv (1-mv/mu(u))*[(f_D-qv)|D|/mv]
    *(1-p(u,v))*(1-b^-4)/J.

Its order payment inserts e(u)=1-J/Tu(u). Exact lower and upper mass, occupation, overlap and e bounds enclose these full integrals. Positivity of the lower proves a real positive fee, rather than only a positive order factor at a point.

The remaining denominator satisfies the exact pointwise identity

(1-e)/J = 1/max(J,Tu).

On the early interval this is 1/Tu; at b it is 1/Jb. Both are checked. Independent interval enclosures of paid and remaining costs need not sum endpoint-by-endpoint: the underlying integrands, not unrelated enclosure endpoints, split exactly.

Baseline certified intervals (decimals display exact rational bounds):

| quantity | lower | upper |
|---|---:|---:|
| mu(u) | .8499009537 | .8501009537 |
| mw(w) | .8018842220 | .8022963424 |
| early J | 2.088466287e-11 | 2.088493968e-11 |
| early Tu | 3.965108775e-11 | 4.083794482e-11 |
| early order e | .4732820492 | .4885966236 |
| original designated interval cost | 2.947817099e-20 | 2.964579939e-20 |
| positive designated order payment | 1.395148917e-20 | 1.448483749e-20 |
| remaining max-denominator interval cost | 1.507543599e-20 | 1.561476774e-20 |
| original designated terminal cost | 3.712794867e-19 | 3.734820953e-19 |

The terminal cost is positive but its order payment is exactly zero. This is an important distinction: no terminal mass is silently charged as order error. It is the physical clock atom at b, not a historical jump atom. All reported costs concern only the designated u→v subbranch; other flow costs are not computed. Baseline h=H is 1.970833199e-13, full Xq lies in [1.392943466e-11,1.393597130e-11], and the order payment/Xq lies in [1.00111e-9,1.03987e-9]. It is not a near-extremal sample.

## Source fee and its meaning

Use the legitimate all-source uniform occupation upper

Jglobal=Iv+Vu/mu_min+Vw/mw_min.

The proved general source-price expression is bounded by

(lambda/q_-)*log(lambda/q_-)*log_+(Jglobal/h)*W,
q_-=3/4, lambda=1.

The script range-reduces rational logarithm arguments to [1,2] and uses the positive atanh series with an explicit rational tail upper. It records lower/upper enclosures **of this displayed bounding expression**, approximately 445.1868213 at baseline. They are not lower/upper measurements of the actual global source-fee integral, nor an exact value of actual Jmax. The displayed bound is extremely loose compared with the exhibited fee; that is reported rather than presented as sample budget efficiency.

## Three stages and reproduction

Stage 1 is the baseline. Stage 2 executes 27 fields with eta in {.0005,.001,.002}, b in {1.005,1.01,1.015}, and wfactor in {3/2,2,5/2}. Stage 3 executes those fields with P in {2^-22,2^-20,2^-18}, 81 fields. All keep b<=2a, q-band, mw_max<mu_min, strict far traffic, common D capture, positive order fee and zero terminal order fee. The stage-3 order factor bounds range from .1933445 to .7042790. Parameter repetitions are counted as executions, not independent examples.

Run `python3 r389_continuum.py`. Only the Python standard library is required. No old /tmp imports, optimizer, Monte Carlo, source point sampling or center-value quadrature. Output `r389_continuum.result.json` is written beside the script, with one full rational baseline, stage extrema and exact case digests. **7,413 exact Fraction assertions** passed. A second fresh process reproduced output bytes. Only owned R389 files were modified; no repository or Git actions. This is a verified general-clock diagnostic, not a claimed native G_smooth input.
