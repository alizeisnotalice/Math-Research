#!/usr/bin/env python3
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
import json,os,sys,time,resource,platform
sys.set_int_max_str_digits(0)
def fingerprint(x):
 s=str(x);return {'sha256':sha256(s.encode()).hexdigest(),'numerator_bits':abs(x.numerator).bit_length(),'denominator_bits':x.denominator.bit_length()}
def work(n):
 clock=time.perf_counter();cpu=time.process_time();a=32*n;g=ell=F(1,16*n);P=F(a+1,a)**n;eps=F(1,64)/P;d=2**n;v=F(2,a)**n;m=d+eps*v;b=1+g+ell;c=F(d)*b**n/m-1
 assert 0<c<1 and m/F(d)<(1+g/2)**n
 # critical ramp concave; its derivative decreases, yet at b it is positive.
 deriv=m*c/ell-F(d*n)*b**(n-1)
 assert deriv>0
 # Later all-source entering radius T=3+g-ell=3; even full 2m mass has strict cap.
 T=3+g-ell;assert F(d)*T**n>2*m
 # largest possible canonical radius rho satisfies rho^n <=2m/d;
 # thus expanded receiver balls have disjoint interiors.
 assert F(2)*m/F(d)<(a*(2+g)/2)**n
 # Original KKT: old small cubes disjoint, v_j=v, lambda=(1,1),
 # m_j=d+eps*v, M=2m, Q=2d, V=2v, R=1/a**n.
 assert m-d==eps*v and 2*m==2*d+eps*2*v and F(v,d)==F(1,a**n)
 tests=[]
 for k in [8,32,128,512]:
  # bounded adjustment is rational and guarantees 0<theta<1, preserving shrinking order
  h=min(F(1,2**k),c/2,(1-c)/2)
  for sign in [-1,1]:
   theta=c+sign*h;z=1+theta
   assert 0<=theta<=1
   if sign<0:
    assert z*m<F(d)*b**n;growth=m;Qstar=2*m;Vstar=2*m/a**n
   else:
    assert z*m>F(d)*b**n;growth=z*m;Qstar=growth;Vstar=2*growth/a**n
   D=Vstar-F(1,a**n)*Qstar
   assert D==(F(0) if sign<0 else growth/a**n)
   tests.append({'k':k,'side':'below' if sign<0 else 'above','step_bits':[h.numerator.bit_length(),h.denominator.bit_length()],'D_positive':D>0,'theta_fingerprint':fingerprint(theta),'D_fingerprint':fingerprint(D)})
 # At equality last strict-bad endpoint remains old root: later r=b only equal contact.
 assert (1+c)*m==F(d)*b**n
 return {'n':n,'critical':fingerprint(c),'ramp_endpoint_derivative_positive':True,'r0_before_half_gap':True,'outer_tail_cap':True,'grown_receivers_disjoint':True,'old_KKT':True,'equality_D_zero':True,'tests':tests,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-clock,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 start=time.perf_counter();ns=[1,2,3,7,16,32,64,256,1024,4096]
 # no more workers than tasks; each case a single process.
 with ProcessPoolExecutor(max_workers=min(15,len(ns))) as pool: results=list(pool.map(work,ns))
 out={'ns':ns,'results':results,'python':sys.version,'platform':platform.platform(),'workers':min(15,len(ns)),'wall_s':time.perf_counter()-start,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
 print(json.dumps(out,indent=2))
