#!/usr/bin/env python3
import concurrent.futures,contextlib,hashlib,io,json,os,platform,resource,sys,time
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
import radius_engine as eng
from independent import S,intervals,check,r
if not __debug__:raise RuntimeError('assertions must be enabled')
sys.set_int_max_str_digits(0)
HERE=Path(__file__).resolve().parent

def fstr(x):return str(F(x))
def generate(n,k):
 a=32*n; e=F(1,16*n); d=2**n; v=F(2,a)**n; eps=F(1,64)*F(a,a+1)**n; mass=d+eps*v; b=1+2*e; c=d*b**n/mass-1
 theta=c+F(k,2**(8 if abs(k)==1 else 32)) if k else c
 # k=±2 codes the small displacement, not a coefficient 2.
 if abs(k)==2:theta=c+F(1 if k>0 else -1,2**32)
 assert 0<=theta<=1
 centers=[[F(0)]*n,[2+e]+[F(0)]*(n-1)]; blocks=[]
 # Center 0's right-facing block and left-facing block; center 1 reversed.
 for j in range(2):
  x=centers[j][0]
  for inward,weight in [(True,theta),(False,1-theta)]:
   side=1 if (j==0)==inward else -1
   edge=(x+1-e,x+1) if side==1 else (x-1,x-1+e)
   box=[edge]+[(-e,e)]*(n-1); volume=sp.prod(hi-lo for lo,hi in box); density=weight*mass/F(volume)
   blocks.append({'box':[[fstr(lo),fstr(hi)] for lo,hi in box],'density':fstr(density)})
 data={'dimension':n,'centers':[[fstr(t) for t in c0] for c0 in centers],'sources':blocks}
 meta={'n':n,'theta':str(theta),'critical':str(c),'a':a,'gap':str(e),'mass':str(mass),'small_volume':str(v),'epsilon':str(eps),'side':('high' if theta>c else 'low')}
 return data,meta

def run_one(task):
 n,k=task;clock=time.monotonic();cpu=time.process_time();data,meta=generate(n,k);path=HERE/'inputs'/f'n{n}_{k:+d}.json';path.write_text(json.dumps(data,indent=2)+'\n');a=meta['a'];mass=F(meta['mass']);gap=F(meta['gap']);theta=F(meta['theta']);d=2**n
 src=[([(eng.Q(lo),eng.Q(hi)) for lo,hi in q['box']],eng.Q(q['density'])) for q in data['sources']]
 t=mass/d if meta['side']=='low' else (1+theta)*mass/d
 assert t < (F(a)*(2+gap)/2)**n
 # Witness primal and dual objectives agree; low gives disjoint stars, high gives positive intersection.
 threshold=(1+gap/2)**n
 assert (t<threshold) if meta['side']=='low' else (t>threshold)
 Q=2*d; V=2*F(meta['small_volume']); eps=F(meta['epsilon']);assert 2*mass==Q+eps*V and F(V,Q)==F(1,a**n)
 qstar=2*mass if meta['side']=='low' else t*d
 vstar=2*t*d/a**n; D=vstar-qstar/a**n
 assert D==(F(0) if meta['side']=='low' else t*d/a**n)
 centers=[]
 for c in data['centers']:
  z=eng.solve_center([eng.Q(x) for x in c],src,n)
  if z['status']!='certified':raise RuntimeError((n,k,c,z['status']))
  rm,rp=map(F,(z['r_minus'],z['r_plus'])); rl,rh=map(F,z['last_root_interval']);assert rm<=rl<=rh<=rp and rl**n<=t<=rh**n,(n,k,rl,rh,t)
  pieces=intervals(data,c)
  for s in z['segments']:
   lo,hi=map(S,(s['left'],s['right'])); mid=(lo+hi)/2; p=next(q for x,y,p,q in pieces if x<=mid<y)
   assert sp.Poly.from_list(list(map(S,s['coefficients'])),r)==p
  with contextlib.redirect_stdout(io.StringIO()): check(data,c,str(rm),str(rp))
  centers.append({'r_minus':str(rm),'r_plus':str(rp),'last_root_interval':list(map(str,(rl,rh)))})
 out={'case':f'n{n}_{k:+d}','meta':meta,'predicted_radius_power':str(t),'Qstar':str(qstar),'Vstar':str(vstar),'D':str(D),'centers':centers,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'wall_s':time.monotonic()-clock,'cpu_s':time.process_time()-cpu,'max_rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 return out
if __name__=='__main__':
 ns=list(map(int,os.getenv('DIMS','1,2,3,7,16').split(',')));workers=int(os.getenv('WORKERS','1')); tasks=[(n,k) for n in ns for k in (0,-1,1,-2,2)];start=time.monotonic()
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool: out=list(pool.map(run_one,tasks))
 result={'status':'PASS','cases':out,'python':sys.version,'sympy':sp.__version__,'platform':platform.platform(),'workers':workers,'wall_s':time.monotonic()-start,'scope':'finite same-input KKT source paths, not general hard bound'}
 (HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(out),'families',2*len(out),'centers','wall',result['wall_s'])
