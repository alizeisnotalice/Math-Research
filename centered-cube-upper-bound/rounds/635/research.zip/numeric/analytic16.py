#!/usr/bin/env python3
import hashlib,json,platform,resource,sys,time
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
from independent import intervals,S,r
from generic_verify import generate
if not __debug__:raise RuntimeError('assertions required')
sys.set_int_max_str_digits(0); here=Path(__file__).resolve().parent
start=time.monotonic();cpu=time.process_time();out=[];n=16;d=2**n
for k in (0,-1,1,-2,2):
 t=time.monotonic();data,meta=generate(n,k); path=here/'inputs'/f'n{n}_{k:+d}.json'; assert json.loads(path.read_text())==data
 theta=F(meta['theta']);critical=F(meta['critical']);gap=F(meta['gap']);ell=gap;a=meta['a'];mass=F(meta['mass']);eps=F(meta['epsilon']);v=F(meta['small_volume']);b=1+gap+ell;T=3+gap-ell
 assert 0<critical<1 and (1+critical)*mass==d*b**n
 assert F(mass,d)<(1+gap/2)**n and d*T**n>2*mass
 derivative=mass*critical/ell-d*n*b**(n-1);assert derivative>0
 target=mass/d if theta<=critical else (1+theta)*mass/d
 # Exact nth-root brackets from rational dyadic bisection.
 L=F(1);H=T
 for _ in range(200):
  mid=(L+H)/2
  if mid**n<target:L=mid
  else:H=mid
 assert L**n<target<=H**n and L>1
 assert (L> b if theta>critical else H<1+gap/2)
 assert H<a*(2+gap)/2
 counts=[]
 for center in data['centers']:
  pieces=intervals(data,center);counts.append(len(pieces))
  for left,right,m,g in pieces:
   if right<=1 or left>=T:continue
   low=max(left,S(1));high=min(right,S(T));assert low<high
   mid=(low+high)/2
   expected=mass if mid<=1+gap else (mass*(1+theta*(r-1-gap)/ell) if mid<b else (1+theta)*mass)
   assert m==sp.Poly(expected,r),(k,center,left,right,m,expected)
  # Each original source cube is inside exactly its corresponding original star;
  # exact masses of the two pieces sum to m per star, establishing source saturation.
  for j in range(2):
   c=list(map(F,data['centers'][j])); blockmass=F(0)
   for block in data['sources'][2*j:2*j+2]:
    box=[list(map(F,z)) for z in block['box']];assert all(c[i]-1<=z[0]<z[1]<=c[i]+1 for i,z in enumerate(box))
    blockmass+=F(block['density'])*sp.prod(hi-lo for lo,hi in box)
   assert blockmass==mass
 assert 2*mass==2*d+eps*2*v and F(v,d)==F(1,a**n)
 # Ramp critical G is concave with positive right derivative, hence increasing to 0;
 # subcritical G is bounded above by it.  Supercritical G(b)>0 and post-ramp
 # mass is constant, giving its final strict bad radius by monotonicity.
 Gb=mass*(1+theta)-d*b**n
 assert (Gb>0 if theta>critical else Gb<=0)
 qstar=mass*2 if theta<=critical else target*d;vstar=2*target*d/a**n;D=vstar-qstar/a**n
 assert D==(F(0) if theta<=critical else target*d/a**n)
 z={'case':f'n{n}_{k:+d}','side':meta['side'],'r_minus':str(L),'r_plus':str(H),'radius_power':str(target),'critical_ramp_derivative':str(derivative),'G_at_b':str(Gb),'segment_counts':counts,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'Qstar':str(qstar),'Vstar':str(vstar),'D':str(D),'wall_s':time.monotonic()-t}
 out.append(z);(here/'checkpoints'/f"{z['case']}.json").write_text(json.dumps(z,indent=2)+'\n')
result={'status':'PASS','method':'literal boxes -> all segment polynomials, analytic monotonicity/concavity and exact dyadic power comparisons','cases':out,'python':sys.version,'sympy':sp.__version__,'platform':platform.platform(),'wall_s':time.monotonic()-start,'cpu_s':time.process_time()-cpu,'max_rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'five n16 finite controls, not general dimension theorem'}
(here/'analytic16_results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(out),'families',len(out)*2,'centers')
