#!/usr/bin/env python3
"""Run all finite checks. Missing SUMMARY.json indicates incomplete or failed work."""
import hashlib,json,os,platform,resource,shlex,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
summary_file=P/'SUMMARY.json';summary_file.unlink(missing_ok=True)
import sympy as sp
import generic_verify
if not __debug__:raise RuntimeError('Run without python -O')
sys.set_int_max_str_digits(0)
start=time.monotonic();cpu=time.process_time()
for fname in ('results.json','analytic16_results.json','model_results.json'):(P/fname).unlink(missing_ok=True)
for f in (P/'checkpoints').glob('*.json'):f.unlink()
(P/'inputs').mkdir(exist_ok=True);(P/'checkpoints').mkdir(exist_ok=True)
for n in (1,2,3,7,16):
 for k in (0,-1,1,-2,2):
  d,_=generic_verify.generate(n,k);(P/'inputs'/f'n{n}_{k:+d}.json').write_text(json.dumps(d,indent=2)+'\n')
env=os.environ.copy();env.update({'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
def run(script,extra):
 e=env.copy();e.update(extra);t=time.monotonic();x=subprocess.run([sys.executable,str(P/script)],cwd=P,env=e,text=True,capture_output=True,check=True);return {'wall_s':time.monotonic()-t,'stdout':x.stdout.strip()}
cpu_count=os.cpu_count() or 1
workers=int(os.environ.get('R635_WORKERS',min(cpu_count,20)))
if not 1<=workers<=20:raise ValueError('R635_WORKERS must be between 1 and 20')
generic=run('generic_verify.py',{'DIMS':'1,2,3,7','WORKERS':str(workers)});g=json.loads((P/'results.json').read_text());assert len(g['cases'])==20 and all(len(z['centers'])==2 for z in g['cases'])
for z in g['cases']:(P/'checkpoints'/f"{z['case']}.json").write_text(json.dumps(z,indent=2)+'\n')
analytic=run('analytic16.py',{});a=json.loads((P/'analytic16_results.json').read_text());assert len(a['cases'])==5
model=run('fraction_model.py',{});m=json.loads(model['stdout']);assert m['ns']==[1,2,3,7,16,32,64,256,1024,4096] and len(m['results'])==10
(P/'model_results.json').write_text(json.dumps(m,indent=2)+'\n');model['stdout']='10 dimensions PASS'
checks=sorted((P/'checkpoints').glob('*.json'));inputs=sorted((P/'inputs').glob('*.json'));assert len(checks)==25 and len(inputs)==25
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary={'status':'PASS','scope':'finite same-source KKT-path controls; not a hard-family or dimension-order theorem','methods':{'generic_exact_root_isolation':{'dimensions':[1,2,3,7],'families':20,'centers':40,'workers':workers,**generic},'literal_box_polynomials_and_exact_power_bisection':{'dimension':16,'families':5,'centers':10,**analytic},'ten_dimension_fraction_model':model},'input_sha256':{p.name:sha(p) for p in inputs},'checkpoint_sha256':{p.name:sha(p) for p in checks},'code_sha256':{f:sha(P/f) for f in ('verify.py','generic_verify.py','analytic16.py','independent.py','radius_engine.py','fraction_model.py')},'python':sys.version,'interpreter':sys.executable,'sympy':sp.__version__,'platform':platform.platform(),'cpu_count':cpu_count,'command':shlex.join([sys.executable,*sys.argv]),'environment':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE','R635_WORKERS')},'wall_s':time.monotonic()-start,'cpu_parent_s':time.process_time()-cpu,'max_rss_parent_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'original_generic_n16_attempt':'5 workers intentionally stopped after 14m29s; no certificate','original_flint_probe':'intentionally stopped after 41.02s; no certificate'}
summary_file.write_text(json.dumps(summary,indent=2)+'\n');print('PASS 25 families / 50 centers; 10-dimension Fraction model')
