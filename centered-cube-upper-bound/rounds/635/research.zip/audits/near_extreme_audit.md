# R635 全局近极值权限独审（Sol high）

**结论：所提有限变分权限成立。** 固定 n、a、ε、N 后，可先选全局 ratio 近极值的完整 family；随后对其**每个**真实 L1 KKT 来源、每个同类有限更新，获得统一的完整 D 上界。无需 supremum 达到、无需 μ 优化 D、无需来源或 family 的紧性。它提供可用于正向证明的附加全局约束，但不证明正 D 增幅本身。

## 1. S_N 的合法定义

令 F_N 是所有非空**有序**完整 finite cube families 的正增量代表：按固定顺序删去零增量后，所有列出标签都满足 v_j>0，且列出标签数至多 N。固定 dilation a、正则参数 ε，按这个代表计算正则最优值的线性部分 Qε(F)。未列出的零标签不得在更新时重新激活而不计入 N。定义

    S_N=sup_{F∈F_N} R(F),   R(F)=V(F)/Qε(F).

必须包含所有允许几何、正半径和继承/所选顺序；不能再附“仍由最初固定 f 见证”“仍有旧 packing”“某个预定 μ”之类限制。反证更新只需落回同一 F_N。若选择一个全局固定排序规则，也必须证明该规则下全部更新仍属于所取 supremum 类；直接纳入所有顺序最安全。

R634 已审固定 N 终端保证 S_N<∞，本审不重证终端。非空 family 的 V、Qε 均正，故该 supremum 定义无除零。每个 δ>0 依 supremum 定义存在 F 满足

    S_N−δ<R(F)≤S_N.

不需要最优 family 存在，不需要 centers/radii 紧致，不需要 δ→0 时抽取任何极限。

## 2. 零标签与 Qlin/Qreg 的方向：上界成立

固定一个这样的 F，记 R=V/Qε、M=Qε+εV。对任意其真实 L1 KKT 来源 μ，形成完整 canonical stars A_j* 和 B_j*=A_j*/a。径向连续性给 μ(A_j*)=|A_j*|，原 m_j>d_j 保证最后 strict-bad 半径正且有限。

记 V*=|∪B_j*|，Qlin* 为**全部 canonical labels**的新线性 packing 最优值。由 μ 的 canonical 接触和新 packing 可行性，

    Qlin*=∫Lνdμ≤M.

新 family 中可能出现零 receiver increments。按指定顺序删除这些标签后，union 只改零测集合，V*不变，正标签数≤N；重新计算该 reduced family 的正则最优值，记 Qε'。删后正则 packing 扩零权即为删前完整 packing 的可行解，因此

    0<Qε'≤Qlin,reduced*≤Qlin*.

故方向准确为

    V*/Qlin* ≤ V*/Qε' ≤ S_N.

于是对原**完整** D，

    D(F,μ)=V*−R Qlin*
           ≤(S_N−R)Qlin*
           <δ Qlin*≤δM.                              (NE)

零标签不能直接从 D 的完整 Qlin* 中删掉并重命名，因为其线性 packing 目标可能改变；上面的比较已经完整支付这种差别，所以无须假定删前/删后线性最优值相同。

## 3. 所有来源与所有有限 witness 更新的量词

F 先按 S_N 选定，然后 (NE) 对这个 F 的每个真实 L1 KKT μ 成立。所有这类 μ 的原 Qε、V、M、R 相同；新 canonical 几何虽然随 μ 改变，仍然分别属于同一个全局 supremum 类。因此 μ 不必达到任何来源优化，亦不需 μ 的选取可测性或 AC 类紧性。

更一般地，对同一 μ 的任意非空有限新 witness family F'，只要标签数≤N、固定 a 与 ε、且各新 star 满足 μ(A'_j)≥|A'_j|，便有 Qlin(F')≤M，并得到

    D'(F,μ;F'):=V(F')−R Qlin(F')<δ Qlin(F')≤δM.

严格 bad witnesses 是这一条件的特例。同 centers 足够，但对该全局 F_N 并非必要；允许的更一般新 centers 也受 supremum 约束。新增标签超过 N、改变 a/ε、换成另一个受限 family 类，都不能直接沿用本结论。

这是“对任意 μ、其各自完整更新”的有限增量约束；不是 μ 的微分驻点条件。不能据此省掉 D 中的 overlap、RS、Cfill，不能未经可微性/可行路径证明就导出 Euler–Lagrange 方程、pointwise source 条件或所谓泛型 μ 驻点。

## 4. 如何选 δ，费用及维数依赖

若已有一个 hard family F0（标签数≤N）满足 R0>6PH，则 S_N≥R0。先取

    0<δ< (R0−6PH)/2,

即可保证任意 δ-near-extreme F 仍满足 R>6PH。δ 在选 μ 之前固定；没有将 hard 假设寄托于某个源的选择。

若正向候选以后真正给出同一步统一净下界 D≥γV，γ>0，则 hard 分支有

    V/M=R/(1+εR)>3PH/2.

所以只要另取 δ<3γPH/2，就有 δM<γV，与 (NE) 矛盾。可保守选 δ≤γPH/2，并同时满足上述 hard-gap 限制。

例如原 (U_exists) 若有统一 c,C，且预先 H=K L_n、K足够大使 hard 分支 D≥3cV/4，则取

    0<δ<min{(R0−6PH)/2, cPH/4}

已有充足余量；即使另保留原 strict endpoint 近似后只剩 D^-≥cV/2，也仍与相同近极值上界矛盾。所有常数必须在 family/δ/source 选择中保持原要求的统一性；若所谓正增幅随 δ 退化到比 δM 更小，不能用本原则完成矛盾。

δ 是 dimensionless ratio 精度，δM 才是 D 的体积费用。δ 可以依 n、a、ε、c,C 及 initial hard-gap 选择；supremum 的存在量词允许任意这种正精度。它不会自动给最终常数增加 1/δ、标签数或尺度损失。若以后提出实际算法或有限数值逼近，则其求近极值成本与认证误差需另记，本原则没有宣称可高效计算近极值 family。

## 5. 严格端点与一般 f：没有来源极限偷步

这里 S_N 的类是纯几何 finite families，不要求由某个固定来源严格见证。因此 canonical 等值 endpoint family 本身就属于可比较的几何类（删除零增量后）；直接证明 (NE) **无需**先把 endpoint 改成 strict-bad stars，也无需任何 source 弱极限。

若后续正向证明或更新另需严格 witnesses，可在已经选定的真实 μ 下取有限 strict-bad 内近似，并使用第3节的有限更新版。原已审的 canonical packing/union 端点控制仍适用；若从 endpoint 的下界转到 strict family，下界侧的误差必须支付。上界 (NE) 本身不引入这项近似费用。

若最终用正向预算排除每个 N 的 hard near-extreme family，则不存在任何 R>6PH 的完整 finite family。最初一般非负 L1 输入 f 的 strict witnesses、有限紧覆盖、Qε≤||f||1 和内正则性入口照旧恢复一般 f、全部正半径及真实 Lebesgue receivers。不能把 S_N 定义成“只来自这个固定 f”的类，否则辅助 μ 更新可能不在类内，关键比较便失效。

**实际轻量核验：** 本机 math venv、SymPy 1.14.0 核验 V/M−3PH/2=PH(R−6PH)/[2(2PH+R)] 的归一化残差为0，约0.16秒；没有重证/重算固定 N 终端、没有数值扫参。

**最终权限：** 可以从全局近极值 family 入手，得到对所有合法 KKT 来源共同成立的 (NE)，并只在这种额外约束下寻找一个真实来源的正向 D 付款。当前没有证明这个正向预算，本审不登记完整付款或根阶突破。唯一写入文件为本报告；完成停止。
