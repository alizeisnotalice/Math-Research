# R635 raw owner potential：完整目标端 L² 付款独审

先按主代理冻结定义独立推导，再向 selection 作者索取 proof。当前独立审核结论：**命题成立，前提是 F_j^0 构成 raw union 的真实 owner 分区。** 它给出同一完整族、全部 rows 的 Lebesgue target 上界，不给原 μ source 下界，也不独立支付物理负项 −RQ*。未改仓库或他人文件。

## 1. 物理 D 与 raw owner/Jacobian

保持原 μ、原 m_j,d_j,I_j,v_j 及完整 canonical 新族、V*、Q* 不变。设

\[
g_j^0=m_j/d_j,\quad\alpha_j=(g_j^0)^{1/n},\quad
T_j^0(z)=y_j+\alpha_j(z-y_j),\quad E_j^0=T_j^0(I_j).
\]

由 μ(A_j)=m_j>d_j，所有半径在 `[ar_j,α_jar_j)` 内严格坏，故 canonical 半径 `R_j*≥α_jar_j`。因此

\[
E_j^0\subset Q(y_j,\alpha_jr_j)\subset B_j^*=Q(y_j,R_j^*/a).
\]

取一个真正的、联合固定的可测 owner 分区：各 `F_j^0⊂E_j^0` 互不交，且其并等于 `∪E_j^0` 至零测集。令

\[
D_j=(T_j^0)^{-1}(F_j^0)\subset I_j,\quad u_j=|D_j|,\quad U_0=\sum_ju_j\le V.
\]

D_j 继承原 I_j 的真实不交性。Jacobian 为 g_j^0，故

\[
|F_j^0|=g_j^0u_j,\qquad
|\cup E_j^0|=\sum_jg_j^0u_j.
\]

定义

\[
W_0(x)=\sum_j\frac{u_j}{d_j}1_{A_j}(x).
\]

使用同一 μ 的原星质量，准确有

\[
\boxed{\int W_0d\mu=\sum_j\frac{u_jm_j}{d_j}
=\sum_jg_j^0u_j=|\cup E_j^0|.}
\]

于是

\[
C_0:=V^*-|\cup E_j^0|\ge0,
\qquad
\boxed{D=V^*-RQ^*=\int W_0d\mu-RQ^*+C_0.}
\]

物理 V*/Q* 完全没有替换。u_j=0 的 rows 可保留；所有其它 rows、尺度、低 e_j 标签均在和中，没有按高 excess 或某个 Γ 边缘删项。

### 必须保留的两项限定

- 不能仅沿用旧 canonical owner 再截到 E_j^0：那可能留下没有 raw owner 的孔洞。需要对 raw union 自身重新分配一个合法 owner；这只改变分析分区，不改变物理完整族及 D。
- `α_j≤t_j` **不保证** `E_j^0⊂E_j^*`，因为 I_j 是差集，一般不星形。合法包含是 `E_j^0⊂B_j*`。所以不能进一步声称 C0≥旧 C_fill，或把逐项 `g_j−g_j^0` 价格直接等同于 C0。canonical 价格通过同一物理 V*、Q* 和精确新 C0 完整保留，不是逐项无损认领旧价格。

## 2. 伴随算子：证明方向、半径与常数

在 Lebesgue L² 上定义

\[
(\mathcal Ah)(z)=\sum_j1_{D_j}(z)\frac1{d_j}\int_{A_j}h(x)dx.
\]

对 z∈D_j⊂I_j⊂B_j，有 `||z−y_j||∞<r_j`，所以

\[
A_j=Q(y_j,ar_j)\subset Q(z,(a+1)r_j),
\]

\[
\left|\frac1{d_j}\int_{A_j}h\right|
\le\frac1{d_j}\int_{A_j}|h|
\le\left(1+\frac1a\right)^nM_{\rm cube}h(z)
=P M_{\rm cube}h(z).
\]

这里 r_j 是半边长，体积比准确为 P；没有多付 2^n，也没有漏掉 a。

D_j 不交，故 `|Ah|≤P M_cube h` 在全部真实 D 上成立，外部为 0。Bourgain 维数无关强 L² 定理给

\[
\|\mathcal Ah\|_2\le PC_2\|h\|_2.
\]

此定理仅用于 Lebesgue L² 函数 h，未要求原来源 μ 有 L² 密度。

设 D0=∪D_j。按 Fubini，准确有

\[
\mathcal A^*1_{D_0}(x)
=\sum_j\frac1{d_j}1_{A_j}(x)\int_{D_j}1_{D_0}(z)dz
=W_0(x).
\]

因此对偶方向正确：

\[
\boxed{\|W_0\|_2\le PC_2\sqrt{U_0}.}
\]

也可直接用任意 h∈L² 的 `|∫W0h|≤PC2√U0||h||2` 证明，不需假设 W0 的 source 积分等于其 Lebesgue 积分。

## 3. 完整 target 付款成立

新最优 packing potential 满足 `0≤Lν≤1`、`∫Lνdx=Q*`，故

\[
\|L_\nu\|_2^2\le Q^*.
\]

Cauchy 与第 2 节给出全量估计

\[
\boxed{
0\le\mathcal B_0:=\int L_\nu W_0dx
\le PC_2\sqrt{Q^*U_0}
\le PC_2\sqrt{Q^*V}.}
\]

常数是 PC2，**不是** P²C2²。它不含标签数、最小半径、最小质量、λ_min、inverse-mass 极值或高/低 excess 删除损失；全部 rows 用同一个 disjoint D0 的 √U0 一次付款。

还可用 Q*≤M 与 εV<M 写成 `B0≤PC2 M/√ε=PC2√(2PH)M`，仅作为同一 target 上界的数值回代，不据此声称 D 已正。

## 4. 对完整 D 支付的准确符号

定义 source-covered 与 source-slack 部分

\[
\mathcal B_\mu=\int L_\nu W_0d\mu,\qquad
\mathcal S_0=\int(1-L_\nu)W_0d\mu\ge0.
\]

对同一个 canonical Tν，

\[
\mathcal T_0:=\int[W_0(X)-W_0(Y)]dT_\nu
=\mathcal B_\mu-\mathcal B_0.
\]

完整 D 的精确账为

\[
\boxed{D=\mathcal T_0+\mathcal B_0+\mathcal S_0-RQ^*+C_0.}
\]

新 L² 估计完整支付的是 **signed transport 比较中的 target 负项 −B0**（或任何另行合法展开中出现的这一完整 Lebesgue target 成本）。它不是 −RQ* 的上界，也不是 Bμ/∫W0dμ 的下界。

特别，不能从 `B0≤PC2√Q*V` 推出

\[
\int W_0d\mu\ge RQ^*+cV-C\sqrt n\,\mathrm{polylog}(n)M.
\]

原来源 μ 仍可集中；必须另证 source-retained growth、T0、slack 和 C0 的同对象净下界。若在 D 的上述恒等式中直接处理，B0 本来是正项：丢掉它给合法下界，而把其上界当作正项的下界则方向错误。

**所以这是一份实际完整有价 target 付款，不是一般闭合。** 它解除的是一个具体未付 target row 总费用；完整 D 的正 source 侧及物理 −RQ* 仍须联合结算。

## 5. 独立工具检查与作者 proof 状态

本机 math venv、SymPy 1.14.0 轻量核验 raw owner 质量恒等式、物理 D 恒等式及 Tν source/target 分解，三个符号残差均为 0。严格 L² 结论依赖第 2–3 节的算子/最大函数论证，不以符号化简替代。

已在独立推导后向 selection 作者索取 proof；收到后只对照本结论中的 owner 分区、全部 rows、包含关系和 source/target 符号，不重复其它旧审。

## 6. 作者 proof 最终对照（已收到）

已在独立推导完成后读取 `/tmp/ccu_r635/coordinates.md` §1–3。最终对照通过：

- §1 确实对 raw union 自身构造共同 owner 分区；只用 E0⊂完整 B*，明确不假设 raw/canonical increment unions 的嵌套，也不声称 C0≥旧 Cfill。价格式 `u_j/d_j=[λ_je_j/(ε(1−e_j))](u_j/v_j)` 正确。
- §2 伴随算子、最大函数比较、全部 rows 与 P、C2、√U0 常数均与本报告一致。owner 可依赖整体 μ、ν，不破坏结论，因为该算子界对所有合法 disjoint retained subsets 统一成立；未要求 owner 与测试函数/packing 独立。
- 作者 Young 式 `B0≤ηV+P²C2²Q*/(4η)` 方向和常数正确，仍只付款 target。
- §3 的 cell 产品性严格限制在合法的 uniform-on-old-coordinate-cell 辅助 source 选择。对 `C_k=C∩A_k*`，X 的条件分布为 C_k 中产品均匀，Y 为 A_k* 中产品均匀，真实未归一权是 `ν_k μ(C_k)`，所有分量总权为 Q*，没有每个 cell 重领 M。
- 旧 coordinate-face cell 的每个坐标区间在每个原 A_j 的固定侧，故 source incidence 可记为二值 q；target incidence 用区间交长比 p。telescoping `∏q−∏p=Σ_i(q_i−p_i)∏_{ℓ<i}q_ℓ∏_{ℓ>i}p_ℓ` 正确，所有正 exit/负 entry 与 u_j/d_j 都保留。由此得到的 signed Δ0 正是 `∫LνW0(dμ−dy)`，而非无价增量平方。
- 作者完整式 `(13)` 与本报告 D 分解一致；作者明确 `(14)` source/capacity 下界未证。
- 固定旧 λ 与全部旧 cell 质量时，m_j、raw pieces、raw union 固定，故 source-cell 内重新分布不能单独改变 `∫W0dμ=|unionE0|`。即便 analytical owner 改变，owner/Jacobian 恒等式仍使该总积分不变；canonical Q*、V*、C0 的变化则必须共同保留。

**最终判定：作者本轮全量 target 估计及同对象恒等式通过；不存在从 target 上界到 source 下界的合法自动推论。完整 D 的净正下界仍未证。已完成指定 bounded 独审，停止待命。**
