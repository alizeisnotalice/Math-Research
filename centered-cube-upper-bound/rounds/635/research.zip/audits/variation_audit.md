# R635：多行交换、同源变分及有限变化独立审核

**结论：capacity.md 的交换、条件性方向导数、有限维 alternative 与 Euler 后果通过；retention.md 的完整有限变化式和固定旧矩消去通过。没有得到统一净增益，不能据此认证 (U) 或一般根阶界。** 本审先只据主代理给出的命题独立推导，随后只读 `/tmp/ccu_r635/capacity.md`、`retention.md` 及 `branch_numeric/REPORT.md` 对照。唯一写入本文件，不修改他人输出、仓库或启动新 agent。

## 1. 完整新族多行交换

冻结新物理 stars A_k*、d_k*=|A_k*|、线性最优 ν。若 σ 本身可行，Lσ≤1、b_k=esssup_Ak* Lσ≤1，取

\[
\nu'_k=(1-\theta b_k)\nu_k+\theta\sigma_k,
\quad0\le\theta\le1.
\]

令 B(x)=Σν_kb_k1_Ak*(x)。有限标签数使每个 essential-sup 例外零集的并仍为零集，故 B≥LνLσ a.e.，从而

\[
1-L_{\nu'}=(1-L_\nu)(1-\theta L_\sigma)
             +\theta(B-L_\nu L_\sigma)\ge0.
\]

各 ν'_k 也非负；这是同一新 polytope 内的合法交换。ν 最优性准确给

\[
\sum_j\sigma_jd_j^*\le\sum_k\nu_kb_kd_k^*.
\tag{1}
\]

capacity.md 允许任意有限非负 σ，用 C=||Lσ||∞、将交换中的 θb、θσ 同时除 C，证明完全正确；C=0 时所有 σ=0。这个推广不要求 σ 是 packing。

owner 选出的 σ_j=|F_j|/d_j* 时，左端准确为 |∪E_j*|，方向是该 union 的**上界**，不能倒作 D 下界。完整增长体积已经在 F_j 中；右侧实际 b_k 价格仍需付。把第三核的非碰撞关系换成完整 canonical stars 可行容量不合法，作者没有这样做。

## 2. 同源可微公式的准确适用域

旧族、λ、v_j、旧 m_j、Q、M、R=V/Q 固定。来源 perturbation h 必须是实际 AC 密度变化，支持于旧饱和区 Sλ={Lλ=1}，满足全部旧矩 ∫Aj h=0，且负部能被现有 μ 承担。因为 1=Σλ_j1_Aj 在 Sλ 上，总质量也固定。于是 μ+th 仍可作为同一旧 KKT 来源；不能在已抽到 source 点后换来源。

以下公式还需要**同一个有限扰动邻域内**：canonical last-strict-bad 分支稳定、接触根横截、new clique polytope固定、完整 receiver union 的暴露面 chamber 可微。定义

\[
\chi_j=\partial_r[(2r)^n-\mu Q(y_j,r)]_{r=R_j^*}>0,
\quad c_j=\partial V^*/\partial R_j^*.
\]

c_j 已包含小 cube 半径 R_j*/a 的 1/a。对合法方向，隐式根公式给

\[
(R_j^*)'(h)=\frac{\int_{A_j^*}h\,dx}{\chi_j},
\quad (d_j^*)'(h)=\frac{nd_j^*}{R_j^*\chi_j}\int_{A_j^*}h\,dx.
\]

固定 compact polytope 上线性最优值的单侧导数必须用整个最优 face：

\[
(Q^*)'_+(h)=\max_{\nu\in\operatorname{Opt}}
                       \nu\cdot(d^*)'(h),
\]

故

\[
D'_+(h)=\min_{\nu\in\operatorname{Opt}}\int h\Psi_\nu\,dx,
\quad
\Psi_\nu=\sum_j
 \frac{c_j-Rnd_j^*\nu_j/R_j^*}{\chi_j}1_{A_j^*}.
\tag{2}
\]

这是完整 V*−RQ* 的导数，不是一个任意选定 ν 的导数，也不是 raw overlap 的导数。capacity.md 这些符号、最优面方向和成本均正确。

## 3. 无共同正导方向能推出什么

### 3.1 正 cell 内的双侧线性空间

在 baseline μ 为旧正 cell 上的均匀正密度时，按新 canonical faces 进一步细分为有限正体积 subcells，允许每个旧正 cell 内总质量为零的分片常数 h。任何这样的有限 h 均可作足够小的正负扰动；旧矩自动保持。

若不存在 h 使 (2) 严格为正，有限维分离给某个 νbar∈Opt，使所有这类 h 对 Ψνbar 的积分为零。因为 Ψν 本身属于这份有限细分的分片常数空间，这准确等价于 Ψνbar 在每个旧正 cell 内 Lebesgue-a.e. 为常数。νbar 可以是最优顶点的凸组合，仍属于同一完整 Opt face；不能先任取一个 ν 再逐方向更换。

若仅允许旧 uniform-cell 子类中的 cell-mass 变化，而不允许 cell 内细分，则不能推出 cell 内点态常数性，只能约束相应 cell 平均。当前作者将细分 perturbations 放在合法 AC 来源类中，故其 stated alternative 成立。对任意 AC baseline，不能无条件假定所有有界负向分片常数扰动都合法；需保留负部受 μ 支配，或限制在具有正密度下界的有限正区域。

### 3.2 完整有限 moment 切锥

进一步在同一有限细分的 Sλ 中允许合法 cell-mass 变化：正 source cells 可双侧变化，零 source cells 只可向正方向加质量，全部旧矩仍为零。若没有共同正导方向，或若所考察 μ 确是此有限局部问题的最大点，极锥/Farkas 分离给某个 νbar∈Opt 和无符号限制的 θ，使

\[
\Psi_{\bar\nu}\le\sum_j\theta_j1_{A_j}
\quad\text{Lebesgue-a.e. 于允许的 }S_\lambda,
\qquad
\Psi_{\bar\nu}=\sum_j\theta_j1_{A_j}
\quad\mu\text{-a.e.}
\tag{3}
\]

这是 cone polar：正 cells 上为等式、零 cells 上为上支配。无需额外 mass multiplier，因为常数 1 已在旧 row span 中。capacity.md 的 (3) 在这个有限稳定区内成立；“在 Sλ 上”必须按 a.e./正体积 AC 约定解释，不能扩展到边界点、任意原子测度或 Sλ 外部。它也不是不加条件的无限维 AC 优化定理。

(3) 是**条件性局部必要结构**。没有证明所需 source 最大值存在，没有证明可选到稳定的 interior 最大点，更没有证明 (3) 对 hard family 不可能。旧正 moments 不会自动消除 inert new rows；如果新 indicator 在 Sλ 上属于旧 row span，合法 h 对其积分始终为零。共面或相同限制的 new faces 也只约束 coefficient 的组合，不逐行强迫它们为零。

## 4. Euler 量与“全系数零”的真实结论

对完整新 receiver union，将所有 R_j* 同乘 s≥1，再把空间除以 s，等价于各 cube 半径固定、centers 逐坐标收缩为 y_j/s。固定其余坐标后是一维 interval union；每个连续分量的右端所属 center 不小于左端所属 center，因此同比例 center 收缩不增加该截面长度。逐坐标 Fubini 得

\[
V^*(sR^*)\le s^nV^*(R^*).
\]

在上述可微点求导即

\[
\sum_jR_j^*c_j\le nV^*.
\tag{4}
\]

若确实对全部 j 有 c_j=Rnd_j*νbar_j/R_j*，则乘 R_j* 加总给 RQ*≤V*，即 D≥0。此结论通过，但**只有非负，没有统一正余量**。它不能由 (2)–(3) 自动推出；即使全系数零成立，也不证明 D≥cV−CL_nM。

## 5. 有限变化、拓扑及真实 branch jump

同一 new polytope P* 保持时，准确有限变化为

\[
\Delta D=\min_{\nu\in P^*}
\{\Delta V^*-R\nu\cdot\Delta d^*
     +R[Q^*-\nu\cdot d^*]\}.
\tag{5}
\]

这里所有可行 ν 的旧 gap 非负，不能只保留当前 Opt。若 canonical 变化还改变 new polytope，则 retention.md 的完整式是

\[
\Delta D=\min_{\nu'\in P^{*'}}
\{\Delta V^*-R\nu'\cdot\Delta d^*
     +R[Q^*(\mu)-\nu'\cdot d^*]\}.
\tag{6}
\]

(6) 代数正确；ν' 未必旧可行，所以方括号**可为负**。不能把新旧多面体混用，不能从 fixed-chamber 导数外推 finite change。

`branch_numeric/REPORT.md` 的解析路径特别指出：旧 KKT 矩在整个来源路径固定，当前 canonical 小根仍可横截，但更外方有孤立等值接触；微小来源变化激活新的 strict-bad 岛，使 canonical last-bad 半径、clique 及 D 跳跃。因此**只说当前 canonical 根横截远远不够**。需要另行排除后续等值根/平台，确保 whole last-bad 分支稳定，并保持 clique 与 receiver 暴露面 chamber。capacity/retention 已明说这些限制，未把 generic 条件包装成全族结论。

本审只审核该路径所揭示的逻辑范围，未重复执行 root 的有理分支实验；主代理的独立复核另计。真实有限 jump 不反驳条件式 (2)，但决定其不能承担当前完整 family 的全局闭合。

## 6. retention 改写与旧矩不可重复领款

raw 因子 g0_j=m_j/d_j 在整个合法 KKT 来源类固定。若 analytical owner 也预先固定，则 u_j、W0=Σ(u_j/d_j)1_Aj 固定，并且

\[
\int W_0d\mu=\sum_j u_jm_j/d_j=V_0
\]

对所有这些来源完全相同。raw pieces 只需包含于完整 B_j*(μ)，无需包含于 E_j*(μ)。C0(μ)=V*(μ)−V0≥0 保留全部 canonical 余量，故 D=V0+C0−RQ*、ΔD=ΔC0−RΔQ* 都准确。raw target 的 L2 上界不是 source 选择已经降低 source 成本；选源若有收益，必须在完整 canonical volume、new capacity 或 fill 中体现。

raw 全量 target 的 L2 事实也可直接核实：对任意测试 φ∈L2，z∈D_j⊂I_j⊂B_j 时，原 A_j 包含于 Q(z,(a+1)r_j)，所以 |avg_Aj φ|≤P M_cube|φ|(z)。D_j 真实不交给 |∫W0φ|≤PC2√(Σu_j)||φ||2。因此 ||W0||2≤PC2√(Σu_j)，且 ∫LνW0≤PC2√(Q*Σu_j)≤PC2√(Q*V)。该证明没有遗漏 g0 或 1/m_j，但仍只是 Lebesgue target 上界，不是同一 μ 的 retained source 下界；不能据此把上段固定的 V0 减掉。

uniform old-cell 来源与任意 cell 内 AC 类确实不同。均匀化保旧 KKT 矩，但不保 canonical 半径、Q* 或 D；原子弱极限也不属于已选真实 AC 来源。retention.md 保留了这些量词，没有假设最优 μ 存在。它要求每个 hard family 存在一份好来源，或给定 μ 后构造定量 finite improvement；目前两者均未证明。

## 7. 实际轻量核验与停止结论

本机数学 Python/SymPy 1.14.0 实际一次运行：容量余量恒等式 `1−Lν'` 与分拆式之差为0；可变 new polytope 的有限变化逐 ν' 展开残差为0。进程 wall 约0.042秒。一般交换、分离、隐式根与 Euler 证明来自上文解析论证；没有新数值扫描、重复 root 分支计算或新增假设来源。

**最终通过范围：** 精确多行交换；明示稳定/可微条件下的 whole-Opt 源导数；正确有限切空间/切锥 alternative；完整 cube Euler 后果；保留新 polytope 与 gap 符号的 finite-change 式；retention 的固定旧矩消去。

**未通过为一般定理的部分：** 最优 μ 的存在、稳定区覆盖全部 hard families、从 stationarity 迫使全部 coefficients 为零、以及任何有足够统一余量的完整 D 下界。这些均未在作者稿中冒称成立。当前仍没有可付的完整候选，(U) 未证，不登记预算突破。审核完成停止。
