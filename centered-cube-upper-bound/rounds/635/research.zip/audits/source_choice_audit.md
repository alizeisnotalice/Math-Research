# R635 KKT 来源选择量词独审（Sol high）

**结论：可以合法弱化。** 对每个当前完整 finite family、预先固定的 a、H、ε=(2PH)^{-1} 及其正则最优 λ，只需**存在一个真实非负 L1 KKT 来源 μ**，使由这个 μ 构成的完整 canonical 更新满足同一个 D 下界；不必先证明对每个 KKT 来源都成立。这个存在性仍未证明，本审核只认证它对既定固定 N 反证和一般 f 恢复的充分性。没有更换 D 或另开付款机制。

## 1. 准确的充分量词

给定 n、a≥32n、H=K L_n（K 按原条件回代预先选足够大）、ε=(2PH)^{-1}。对任意完整 finite family F，固定顺序后的真实正增量为 I_j、v_j，V=Σv_j；令 λ 是原正则目标的最优解，Q=Σλ_jd_j，M=Q+εV，R=V/Q。所需合同可写为

    对每个这样的 F，若 R>6PH，则存在 μ∈KKT_L1(F,λ,ε)，使
    D(F,μ)=V*(F,μ)−R Q*(F,μ) ≥ cV−C L_n M.       (U_exists)

c>0、C≥0必须对所有更新 family、标签数、半径、来源选择及步骤统一；维数依赖只按既定 L_n 记账。这里只需在最终预先选定的 ε 下成立，不必额外要求任意 ε>0；但不能在看过 μ 或 κ 后再改 ε。

KKT_L1 是保持全部原矩条件 m_j=d_j+εv_j/λ_j、L_λ=1 μ-a.e. 的真实 L1 来源集合。对固定 F、λ、ε，所有此类 μ 的 m_j、总 M 相同，故右端和原 R 都不因选择 μ 改变；改变的是 canonical 半径、V*、Q*及完整 D。

因此“对每个 KKT 来源都成立”的 (U_all) 是一个足够但并非反证逻辑所必需的更强合同。这里没有证明 (U_all) 为假，也没有宣称其与 (U_exists) 等价。

## 2. 选择时序：全局选 μ 后再抽 X

合法次序是

    当前完整 F、真实 increments →固定 λ、Q、M
      →全局选定一个 μ→canonical 全族/新 packing/owner/Hall 等辅助对象
      →再按这个 μ 抽取 X、Y、标签和 receiver.

μ 可以依赖整个当前 family、固定 ε、全几何及已有历史；这是输入依赖的全局选择。不能在给定被收费 X 或 cell 后，分别挑有利 μ_X，再把这些互不相同来源的费用拼成一份 M。若证明中另选择最优 ν 或合法 owner，可在同一已选 μ 下作整体选择；但最终仍是这个 μ 的物理 V*、Q*和完整 D。

确定性逐步反证只需每步选一个符合 (U_exists) 的来源，不对所有 family 作积分，因此无需一个跨 family 的可测 selector。若以后提出随机 family 算法或对 family 再积分，则应另证相应可测性；不能从当前存在量词自动取得。

## 3. 有限胞腔质量可选到哪里、胞腔内密度可选到哪里

用所有原 A_j 的 coordinate faces 划分正体积矩形 cells C，记 b_jC=1_{C⊂A_j}、ℓ_C=Σλ_j b_jC。对一个真实 L1 KKT 来源，z_C=μ(C) 必须满足

    z_C≥0,
    z_C=0 当 ℓ_C<1,
    Σ_C b_jC z_C = m_j  对每个 j.                 (K)

边界 cells 为 Lebesgue 零测，不能承载 L1 质量。乘 λ 求和即得 Σ_C z_C=Σλ_jm_j=Q+εV=M。有限 KKT 构造保证至少一个这样的 z 存在；multipliers/source 不必唯一。

所以 **cell 质量分配不是任意自由的**：只能在 (K) 的非负可行多面体中改变，必须同时保留所有 row moments 和 tight-cell 支持。固定 z 后，可在每个 C 内任选非负 L1 密度 f_C、∫_C f_C=z_C；因所有原 membership 在 C 内恒定，原 m_j、M、L_λ 饱和与 KKT 均不变。所有 tight 正质量 cells 都处在至少一个有界 A_j 内，因而可直接均匀摊放 z_C/|C|，得到真实 L1 来源。

胞腔内重新布置密度可能改变 canonical 半径和 D；这正是允许的来源选择，但不能既换密度又沿用旧 canonical 全族、旧 Q*或旧 D。也不能任意指定额外 canonical caps 后仍称它们自动属于 (K)。好来源的凸平均仍是原 KKT 来源，却不保证保持好 D，因为 canonical 更新不是线性的。

## 4. 默认 uniform-cell 构造确有可用的条件产品结构

若保留 R619 的默认选择

    μ_z(dx)=Σ_C (z_C/|C|)1_C(x)dx,

则 X|C 是矩形 C 上的坐标 product uniform。Hall π_CD(j,k) 可只依赖有限 cell pair 选取；在 Γ 尚未作 canonical cross exclusion 时，给定 C,D,J=j,K=k，其 source 条件律准确为

    Unif(C)⊗Unif(D),

两个 source 相互独立，且各自坐标独立。未归一 cell-pair-label 权为

    w_CDjk=(z_C z_D/M²)π_CD(j,k)e_j e_k1_{j≠k}.

归一 Γ 时再统一除以 Ω。这并未把原 f 或全局 μ 变成坐标乘积来源；全局仍按这些真实权重混合，不能给每个 cell、pair 或坐标另领一份 M。

canonical cross exclusion 若仅删除 X∈A_k* 或 Y∈A_j*，则固定 C,D,j,k 的条件支持变为 C\A_k*、D\A_j*，原权额外乘两个存活比例，再按总存活质量归一。因该特定 mask 分解为 X 因子和 Y 因子，固定这些条件时两 source 仍可相互独立；**但单个 source 在 box complement 上一般已不再坐标独立**。后续若还有耦合两端的筛选，连 source 间独立也须重核。不能沿用未筛的 uniform(C)×uniform(D) 律、忽略存活权，或把归一化按每个 cell 单独重置。

本机 Python Fraction 作了一个仅核条件律的小检验：Unif((0,1)^2) 删除 (0,1/2)^2 后，两个坐标落上半区的边缘均为2/3，联合为1/3≠4/9。它说明 box-complement 筛选确可破坏坐标产品性；不是几何预算的反例或新估计。

同一默认 uniform-cell μ 下，Tν 也有一个准确的条件产品版本：给定原 cell C 和新标签 k，source X 均匀于矩形 C∩A_k*（正体积时），target Y 均匀于 A_k*，二者相互独立。该 cell/label 的未归一质量是 ν_k z_C |C∩A_k*|/|C|，全局总量仍为 Q*；不能用 z_C/M 代替这个实际权。它不会给 μ 的全局 product 性、维数无关密度帽或接回 receiver 时免除 e_j/ε 价格。已将这一范围与 contact 作者交换。

因此可以进一步提出一个**足够但更受限的**存在合同：对每个 F，存在满足 (K) 的 z，使默认 uniform-cell μ_z 实现 (U_exists)。若能证明它，就兼得真实 L1、原 KKT 和上述条件产品结构；但不能先依任意 cell 内密度找到好 μ，再未经证明地将它均匀化并保留 D 下界。目前没有证明 uniform-cell 或一般 L1 版本的完整 D 预算。

## 5. 每步重新选来源与严格端点：原反证仍有效

若 (U_exists) 成立，当前 hard family 可先选一个好 μ，获得原 R634 统一正 D 余量；再在这个固定 μ 下选足够接近 canonical endpoint 的真实 strict-bad 内近似，使同一 deficit 只损预留的可付误差。有限 open-box 的 packing/receiver 端点连续性沿用已审工具，不要求 μ 光滑或有界。

对该严格内近似新 family，旧 μ 是同一份可行见证来源，所以新正则 Q'_ε≤新线性 Q*,-≤旧 M；重新生成实际 increments、删零行后标签数不增，a、H、ε 不变。然后可在新 family 上重新解正则 packing，并重新选择另一个好 KKT L1 来源 μ'。不要求 μ' 是旧 μ 的变形、共享密度或由最初 f 见证；跨步质量已经通过 Q'_ε≤旧 M 与原完整 ratio 回代支付，不能省掉这条关系。

同样的存在合同适用于每一步，故原已审的统一 R 净增幅和固定初始 N 的有限终端仍形成条件性矛盾。来源选择自由本身没有增加标签数，也没有改动终端；无需将 μ_k 取任何弱极限。

严格半径选择必须在选定 μ 后完成：最后 strict-bad 半径是其自身的 supremum，不能假定所有较小半径都坏；可用趋近 supremum 的 strict-bad 序列并保留有限族共同误差预算。endpoint 等值星自身不必严格坏，不能删掉这项内近似费用。

## 6. 一般 f 恢复和禁止的“存在性”替代

第一步由任意非负 L1 原 f 的 strict witnesses 产生有限 family，并有 Q≤∫fL_λ≤||f||_1。后面只为排除所有 hard finite family，辅助 μ 可以另选。若 (U_exists) 完成，原紧集、内正则性、阈值齐次性恢复一般 f、全部正半径及真实 Lebesgue receivers，和 (U_all) 的已审回代完全相同；没有新增原 f 近似或分尺度费用。

但以下不能替代一个真实好 L1 来源：

- 仅在所有有限测度中取得可能为原子的最优 μ；
- 将 L1 来源序列的弱极限未经证明仍当作 L1 KKT 来源；
- 只用 finite z 多面体 compact，就假定 canonical D 连续并达到最优；
- 只证明一个无法保留实际正 deficit 余量的 supremum。

若直接证明 **在真实 L1 可行类上的** supremum 足够大，则可选实际 L1 近优来源，但必须给出选取误差并由同一步统一 D 余量支付；不能借原子极限或错误的 last-bad 半径连续性实现这个选取。

**最终判断：** (U_exists) 是合法、足够的全局选择弱化；默认 uniform-cell 版本还可合法保留未筛前的条件产品结构。两者均只是可用权限，不是已证 D 付款。当前没有证明所需存在性预算，本审不登记根阶突破。唯一写入文件为本报告；完成停止。
