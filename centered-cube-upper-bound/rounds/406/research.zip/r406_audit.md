# R406 independent audit — FINAL PASS (branch receipt only; global bound unresolved)

FINAL PASS for the new old-source branch receipt, its exact parameter/source fees and total-ledger substitution, and the limited spectral/no-payment subtask. No budget for the retained high-old-rank remainder or general cube bound is certified. Only this audit file was edited. The independent screens below preceded reading the R406 author arguments; subsequent full post-review and final byte bindings complete the audit. A bound P2<=C n Xq/q_-^2 remains only a sufficient stronger geometric route.

## Frozen actual kernel and its Hilbert spaces

Keep the full R405/R404 field and all original marks, clock, q-band, strict mass gate and actual center measures. Write I_Aw=f(Q_A intersect Q_w), m_A=f(Q_A), sigma(dA)=q_A dA, mu(dw)=dw/m_w, and

    H(A,w)=1_{m_A>K m_w} I_Aw/(m_A m_w),
    P_A=integral H(A,w) dw.

H maps child L2(dw) to parent L2(sigma), not between two copies of a probability space. Its un-gated formula is symmetric relative to actual Lebesgue centers, but the strict one-sided far gate is not symmetric: transposition reverses it. Swapping indices does not preserve the same selected mass domain. Changing a reference measure requires changing the kernel density, not just relabeling the norm.

Let A_n=1+n log(b/a). The actual selector center envelope gives, pointwise in a captured source,

    integral c_w(y) dw/m_w <= A_n/q_-,
    integral q_A c_A(y) dA/m_A
       =integral c_A(y) dA/R_A^n <= A_n.

Thus the original unweighted-in-mass Schur bounds are

    sup_A integral H(A,w)dw <= A_n/q_-,
    sup_w integral H(A,w)sigma(dA) <= A_n,
    ||H||_{L2(dw)->L2(sigma)} <= A_n/sqrt(q_-).

The second statement uses q_A/m_A=R_A^{-n} before estimating; it is not a free assertion that child dw equals child q_w dw. This baseline contains no useful strict-gap decay. On a single child mass layer, the volume cap for centers of mass <=t is t/q_-; dividing by child mass t cancels that scale. The one-sided far gate alone therefore does not generate an exponentially small *unweighted* row or column per mass layer through this Schur calculation.

## Exact HS reformulation and the missing constant-vector cost

With child measure mu(dw), the same operator has density

    L(A,w)=1_{m_A>K m_w} I_Aw/m_A,
    L1=P_A.

Its Hilbert-Schmidt norm is EXACTLY the old common-source moment:

    ||L||_HS^2
       =integral sigma(dA)mu(dw) 1far I_Aw^2/m_A^2
       =J_common <=2lambda Xq/(q_-^2 K).

This is a genuine existing matching estimate. However

    P2=||L1||_{L2(sigma)}^2
       <=||L||_HS^2 ||1||_{L2(mu)}^2
       =J_common * mu(E).

The factor mu(E) must be retained. It may be bounded by |E|/m_- for m_-=q_-a^n>0, but this is not a uniform n-order source estimate and introduces an unwanted global receiver/mass factor. HS smallness is not itself a P2 bound on a free normalized constant. In the original child-dw Hilbert space, ||H||_HS^2 instead has one extra 1/m_w relative to J_common; replacing it by the latter would be a measure error. The finite mass lower bound gives only ||H||_HS^2<=J_common/m_-, not its removal.

## A real tilted Schur bound, with its withdrawal obligation

For 0<alpha<=1 set H_alpha=(m_w/m_A)^alpha H. This is a different, mass-conjugated kernel. For fixed source y, let F_y(t) be the actual Lebesgue volume of capturing centers of matched mass <=t. Capture and q-band imply F_y(t)<=t/q_-. Positive Stieltjes integration gives

    integral_{m_w<t} c_w(y)m_w^(alpha-1)dw
        <=t^alpha/(alpha q_-).

This includes atoms, with alpha=1 simply the volume cap. Integrating the parent source posterior then yields

    sup_A integral H_alpha(A,w)dw
        <=K^(-alpha)/(alpha q_-).

For the opposite, genuinely sigma-weighted column use q_A<=lambda, the SAME parent source and strict parent mass. For any M>0 the actual mass/radial envelope gives

    integral c_A(y)1_{m_A>M}dA/m_A^(1+alpha)
       <=integral_0^infinity dz/max(M,q_-z)^(1+alpha)
       =(1+1/alpha) M^(-alpha)/q_-.

Consequently

    sup_w integral H_alpha(A,w)sigma(dA)
       <=(lambda/q_-)(1+1/alpha)K^(-alpha),
    ||H_alpha|| <=sqrt(lambda)/q_- * K^(-alpha)
                                  sqrt((1+1/alpha)/alpha).

These inequalities are valid local geometric tools, and no source density cap or independent radius is assumed. They do NOT prove the corresponding norm bound for H or P2: H_alpha=M_parent^(-alpha) H M_child^(alpha). Undoing the mass powers requires the actual mass range or appropriate input/output mass moments. The available range m_+/m_- <= (lambda/q_-)(b/a)^n can overwhelm the apparent K^(-alpha) gain. A spectral/mass-layer argument claiming improvement must state precisely how it controls these withdrawal factors jointly, rather than count the tilt twice or omit the constant-vector norm. Neither squared common capture nor finite chain depth supplies that missing withdrawal automatically.

## Actual bounded local computation

Ran an independent local Python standard-library Fraction check, 174 grouped assertions: 54 atomic radial-envelope tails (including the lower-edge mass atom) and 120 exact continuous-interval source/receiver-measure identities and Cauchy checks. The interval source was f=1 on a sufficiently large bounded interval, with exact overlap masses; receiver integration was finite quadrature and diagnostic K=3/2. It verifies H dw=L dmu and P2<=HS^2 mu(E) on that fixture, not a native original-history field or the unknown n-order estimate. These reviewer executions are not pooled with future author experiment counts. No separate file was created.

The original spectral prefilter ended here. These existing kernel facts alone did not pay the far marked budget; the separate old-source branch is reviewed below.

Context byte binding:
- `/tmp/r405_main.md`: `3f3d978f284fc9573157da5ae452d23c45d94abfb1ebeec349a961fa1b26f75f`


## Independent screen of the old-source rank payment (before author proof)

Read only the old R390/R398/R400 definitions for this claim. Keep their exact original source-labeled measure

    dGamma0(y,u,v)=f(y)q_u c_u(y)c_v(y)chi0(y,u,v)
                        dy mu(du)mu(dv)/T_u(y), 0<=chi0<=1.

The strict far-mass and middle strip are still in chi0. The true incoming disintegration is

    dGamma0=sigma(dv) pi_v(dy) k0(v,y),
    k0(v,y)=integral (q_u/q_v)c_u(y)chi0(y,u,v)mu(du)/T_u(y).

R390's inclusive-atomic strip proof bounds this k0 POINTWISE in the OLD source y by Ccol; it does not merely bound its pi_v average. Therefore the original source branch T_v(y)<=c h costs

    integral 1_{T_v(y)<=ch}dGamma0
      <=Ccol integral sigma(dv)pi_v(dy)1_{T_v(y)<=ch}
      <=Ccol lambda c h W.

This includes crossing atoms correctly: under inclusive CDF T(m), the mass of complete atoms with T(m)<=a is <=a. The right-rank crossing atom is excluded unless its complete endpoint fits. Zero-rank rows have zero actual contribution by the original support and Tonelli.

The additional cost being screened is the R397/R398 SWITCHING bill, not an unqualified new original-flow payment. For fixed old labeled (y,u,v), nested stage restrictions and the same-source sum_i b_i(z)<=1 imply

    sum_i 1_{A_i^2}(u,v)[pi_u(b_i)+pi_v(b_i)]<=2.

Every current external/small soft restriction can only reduce this positive sum. Thus the two endpoint switching terms together on the low-OLD-source branch have the once-only upper price 2 Ccol lambda c h W. There is no stage count, no transfer of a new witness z into the original old-source role, and no omitted E_uv/Z_u if the external term is represented by its normalized lift. The direct posterior expression already keeps that normalization exactly.

On the retained old-source branch T_v(y)>c h, strict far mass gives Z_u(y)>=T_v(y)>c h, including atoms. External new witness z already has Z_u(z)>Lh. For 0<=x<=1 and A>=c,B>=L, c,L>=4,

    (A-x)(B-x)>=AB(1-x)>=cL(1-x),

since AB>=A+B. This pays the retained external soft factor through the exclusive product with denominator c L h^2. At the small endpoint the native closed window gives Z_v>=T_v-epsilon0 h; the old source and new source ranks are consequently >(c-epsilon0)h and >(L-epsilon0)h. With epsilon0<=1/2 the same positive-product inequality applies. The two-end moment interface has the advertised coefficient

    B_cL=beta/(cL)+Ccol/[(c-epsilon0)(L-epsilon0)].

This is a valid improvement in the sufficient moment interface AFTER an explicitly priced removal, not a proof that the remaining high-rank moment is controlled. Its actual labels, stages, clocks and full-f ranks remain frozen. It must be applied to the current fixed bill, not obtained by subtracting an unproved smaller remainder from an older upper bound.

A source-only measurable c=c(y)>=4 is allowed: the pointwise incoming bound and inclusive-CDF estimate give the price

    2 Ccol lambda h integral f(y)c(y)dy.

For a useful finite estimate this integral must be finite; otherwise the bound is vacuous. The high-rank coefficient then remains the old-y-dependent B_{c(y),L} INSIDE the original source-pair integral. It cannot be assigned to the new witness z, chosen separately per receiver, or pulled outside without a proved bound. Measurability alone provides no coverage of the remaining high-rank bill.

Actually ran 128 Fraction soft-product cases (external and epsilon-adjusted small-end inequalities in each case) and 48 inclusive-CDF atom cases. These 176 additional grouped checks are abstract boundary/algebra diagnostics, separate from the earlier 174 measure checks and any future author counts. No separate script was saved. This independent screen passed before the author and report post-review below.


## Independent adaptive threshold screen

Define Ztot(y)=integral_E c_w(y)dw/m_w from the SAME complete original field and c(y)=4+sqrt(Ztot(y)/h). The actual center bound makes this measurable and finite; arbitrary values on f-zero sets are harmless. Full matching and positive Tonelli give exactly

    integral f(y)Ztot(y)dy=|E|.

For W>0, Cauchy gives integral f sqrt(Ztot)<=sqrt(W|E|). The old-source low-rank switching bill in the preceding screen therefore satisfies

    P_low <=2 Ccol lambda h integral f c
      <=8 Ccol lambda h W+2 Ccol lambda sqrt(h W |E|)
      <=eta Xq+[8 Ccol(lambda/q_-)
                  +Ccol^2(lambda/q_-)^2/eta] s W/epsilon0,

using |E|<=Xq/q_-, h=s/(epsilon0 q_-), eta>0 and the scalar Young inequality 2sqrt(ab)<=eta a+b/eta. Thus

    D=epsilon0^(-1)[8 Ccol(lambda/q_-)
                              +Ccol^2(lambda/q_-)^2/eta]

is the claimed source coefficient. If W=0, matching with q_->0 forces |E|=Xq=0, so the bill is zero and no division by W is needed. The estimate has no implicit positive covered proportion. Its retained positive restriction is T_v(y)>h c(y) at the ORIGINAL old y, with all other R404 factors and current field unchanged.

For the actual current remainder the correct new positive split is

    R404=R406+P_low,  hence R404<=R406+eta Xq+D s W.

Replacing only this inherited R404 slot gives multipliers 16 in G0, 32 in BH and 64Lambda at the original entrance. Old chi_n, Delta404, source prices, low-dimensional alternatives and available absorption constraints must remain; they are not withdrawn or charged again by this new source cutoff. This is an additional explicitly priced branch, not proof of the remaining high-rank budget.

Read and actually reran /tmp/r406_parent_check.py. PASS 2136 Fraction grouped assertions: phases 423,645,1068; total CDF 572, Young 1024, soft 540. The Young variable C in this scalar script may represent the whole Ccol*lambda factor; it does not numerically realize original matching or square roots from an actual source field. Repeated parameter/phase instances are assertion counts, not independent native examples. The script checks inclusive atom endpoints, the squared nonnegative Young comparison and epsilon-adjusted soft algebra. It is not a source-centered cube or original core certificate. Do not pool with the earlier unsaved reviewer cases as one experiment.

The adaptive candidate screen passed in this scope prior to author proof; final post-review follows below.


## Parent report, spectral subtask, and delivered-script post-review

Read the full current r406_main.md and r406_readme.md. Their general c(y) receipt, adaptive c*, D_eta, zero-input convention, finite-field justification and exact new positive remainder agree with the independent derivations above. The high-rank coefficient bound 64S/(49cL) follows from c-epsilon0>=7c/8 and L-epsilon0>=7L/8. The report correctly leaves variable c on the old y and conditions its displayed root-order terminology on dimension-uniform frozen constants. Its conditional P2 scaling is a target-strength comparison, not an established estimate.

The G0/BH/original-entrance substitutions are consistent: 16,32,64Lambda multiply only the new R404 split, and the existing chi_n, Delta404, P_L, E387, S390 and low-dimensional alternative each remain once. New absorption is exactly 64Lambda eta, not automatically available. The old H entrance and all other outstanding global slots remain explicit. Spectral failure is not misreported as failure of the separate old-source receipt. The report's statement that a PDF was reread is parent provenance, not a reviewer claim of reading or validating that PDF.

Read the complete r406_geometry.md and its embedded code, then the extracted standalone check script. PASS in the declared no-payment spectral scope: S_I maps real receiver L2(dw) to L2(fdy), S_J* S_I is the actual unmasked Gram block; the directed strict far gate is retained in adjacent mass blocks and is not claimed PSD/selfadjoint. The source-frame Cauchy bound and both Schur constants use the correct measures. Separate mass blocks share a source space and cannot be treated as orthogonal. The desired cross-block square estimate remains unproved, and no old/new payment is withdrawn or added by this note.

Actually reran r406_aux_check.py: 303 Fraction grouped assertions, split 15 marked_old_rank, 240 soft_two_rank,48 coefficient_transfer; all 15 marked rows positive in that diagnostic. Its matching source masses are real interval masses, but receiver IDs are coincident-center multiple-radius types spanning a factor16. It is NOT a native single-valued center selector or an octave receiver field; arbitrary finite receiver weights are quadrature/incidence weights. Main/readme now state these limitations explicitly. The adaptive options in this script are rational alternative source thresholds, not numerical tests of the square-root c* integral; that formula is proved analytically and Young's scalar algebra is separately checked.

Actually reran the extracted r406_geometry_check.py: 180 Fraction assertions (36 matched Gram,36 source-frame energies,108 two-sided Schur). Its source masses and selected q-band are exact for the finite cell model; finite receiver quadrature is not a native operator-norm certificate or original-history realization. All original source/clock/high-rank gates are not claimed realized. Reproduction extraction is explicitly documented in the revised note. These are the same delivered cases rerun by reviewer/parent, not extra experiments. The 2136+303+180=2619 delivered checks must not be pooled with unsaved independent reviewer arithmetic as new data.

No substantive issue was found in the main/readme or spectral note. The frozen auxiliary proof and final report were subsequently completed as recorded below.


## Final frozen auxiliary and report review

Read the complete frozen r406_aux.md. PASS: its Gamma0 disintegration preserves the actual old y, the original physical clock tail probability including b atom, loss, mass-prefix correction, cold/geometry/history marks and nested endpoint restrictions. The pointwise old-source incoming capacity is the genuine atomic rank-strip bound, with 1-beta crossing term retained. Low old-source CDF payment is performed before witness resampling; the summed two-endpoint switching mark is <=2 at each original edge, so no density-stage multiplicity is hidden. The additional external witness is kept with its real posterior; the E_uv/Z_u normalization is not replaced by one. Formula (3) is the actual R404 remainder and is not identified with unmarked P2.

The auxiliary atom-safe CDF, arbitrary source-only c(y), adaptive square-root choice, Young constant D_eta, positive high-old-rank remainder, B_cL and 64S/(49cL) follow the independently derived calculations above. Full matching establishes integral f Ztot=|E|; it is not a private receiver-dependent cluster or an assumption on source density. Infinite integral c remains only a vacuous bound, whereas c* has finite cost. The conditional P2 transfer is explicitly unproved, and changing L requires changing the complete R398 mother split/P_L. No new witness receives history qualifications.

Also independently checked the final linear optional threshold in auxiliary/main:

    c_lin(y)=4+kappa Ztot(y)/h,
    kappa=eta/(2 Ccol(lambda/q_-)) when Ccol>0,
    R404<=R_hi(c_lin)+eta Xq
                    +[8 Ccol(lambda/q_-)/epsilon0] sW.

This follows directly from integral fZtot=|E| and |E|<=Xq/q_-. It has a different residual gate T_v(y)>4h+kappa Ztot(y) and is not a uniform ordering of either residual or complete bound against the square-root version. The final report treats it as an alternative complete split, never a second fee or a freely inherited extra gate. Ccol=0 implies zero flow by the original incoming bound. The formal displayed ledger remains the square-root choice, as stated.

Re-read the final main/readme including the linear optional paragraph and the explicit numerical caveat. Their new total fees are exactly 16eta/32eta/64Lambda eta in the G0/BH/entrance slots and 16D_eta s/32D_eta s/64Lambda D_eta s for W, respectively; all old source/absorption fees and unproved slots stay once. Root-order terminology is conditional on the declared frozen parameter dependence, and the new global absorption allocation must still exist. No general completion, coverage proportion, near-extremizer or cross-block spectral estimate is claimed.

Numerical scope is correctly separated: 2136 parent scalar/CDF/soft assertions, 303 matched-incidence/soft/coefficient assertions, and180 spectral Gram/Schur assertions are 2619 delivered Fraction checks, each actually rerun by this reviewer, not extra experiments. The 303 fixture has coincident-center multiple-radius receiver types spanning factor16, hence is neither a single-valued native selector nor an octave/history realization; the notes state this. The 180 fixture uses finite receiver quadrature, not a native norm proof. The independent unsaved 174+176 reviewer checks above are separate and not added to the parent experimental total. No ordinary numerical fit is being used to prove the new receipt.

FINAL PASS in the stated scope: a genuine explicitly priced old-source low-rank positive branch of the actual general-input R404 bill is paid, including its adaptive source-dependent implementation. The high-old-rank remainder, global marked geometry, entrance/H choices, historical and full-scale balances remain unresolved. The spectral subtask only identifies a missing joint cross-mass square estimate and adds no payment. No author, script, result or repository file was changed by this reviewer. Audit is frozen at the SHA bindings below.

## Final SHA-256 bindings
- `/tmp/r406_main.md`: `433f82a68430e2de4459c16214364bfacbd699c88652049713aeda5a8dce70f4`
- `/tmp/r406_readme.md`: `976dfa8fe322074724b46a1c22bd8a63e5f3ee34bcc097560d5dad048bd35634`
- `/tmp/r406_aux.md`: `db741a843da268a794d1dd653bfa04b977d66dbda10ca605131f7d3ba77c3f5e`
- `/tmp/r406_geometry.md`: `86507086494df76df48185b08c6cc143d5df38cb61302de01cf1c2ecb89789ed`
- `/tmp/r406_parent_check.py`: `9f0225c4d7ec629762a735eeb6a27881173d39e7622ede72fc52aa5e3419ccba`
- `/tmp/r406_parent.result.txt`: `3de5cec4fa92741f27c3f52294c1fa5761851ceadca81d84736acf2a9bc4c131`
- `/tmp/r406_aux_check.py`: `bb5148272c808add3d1b0d952a516157f89518aac1368d4595e2b56a32b71801`
- `/tmp/r406_aux.result.txt`: `9880a2645c583e36779036e32b723985df886e1468edf586338ccf1a669c4a28`
- `/tmp/r406_geometry_check.py`: `258e710ab12528c18837541733d46788cfe79be5e1ee896b0e3e7eec042cc54c`
- `/tmp/r406_geometry.result.txt`: `4054e63c01018e2ca354e8c33da5584972dc395326e6e57f70f9b87397127ffe`
- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
- `/tmp/r405_main.md`: `3f3d978f284fc9573157da5ae452d23c45d94abfb1ebeec349a961fa1b26f75f`
