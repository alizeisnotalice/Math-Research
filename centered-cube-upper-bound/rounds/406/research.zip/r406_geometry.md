# R406 — Matched incidence blocks: exact spaces and the unresolved joint estimate

**Status of this spectral subtask: no new payment.** This note alone does not change the R404/R405 ledger; the parent main report separately accounts for the new old-source branch receipt. One spectral candidate was screened. The calculations below identify the missing joint estimate; the already available window and Schur bounds are not presented as a new geometric receipt.

## 1. The candidate and its actual measures

Keep the entire original field, full f, actual Lebesgue receiver measure, m_A=f(Q_A)=q_A R_A^n, q_-≤q_A≤λ, a≤R_A≤b≤2a, K=exp(√n). Define the actual operator on L2(E,dA)

 (H_far g)(A)=∫_E f(Q_A∩Q_w)/(m_A m_w)
                        1_{m_A>K m_w}g(w)dw.

It is well-defined and bounded by the existing finite center envelope. Its value at 1 is precisely the R405 posterior P_A. The candidate was

 ||H_far||_(L2(dA)→L2(dA)) ≤ C sqrt(n)/q_-.              (1)

This is a sufficient stronger statement, not a necessity for the original marked cost. If proved, it would give

 P2=∫q_A |H_far1|²dA
 ≤λ C²n|E|/q_-²≤(λ/q_-)C²nX_q/q_-²,
 R404≤(λ/q_-)C²ε_0²[n/(1+√n)²]B_L X_q.

Hence, with the corresponding full R398 choice of L and its retained P_L fee, it would affect the whole remainder. No assertion of (1) is made here. In particular, this calculation does not allocate a new absorption budget or change L.

The measure is dA, not m_A dA. Although the unmasked intersection kernel is symmetric on dA, the strict far mask is directed; H_far is not a self-adjoint positive-semidefinite operator. Positivity of its entries does not supply a spectral bound of the desired size.

## 2. Full-source factorization, with adjacent mass blocks kept exact

For any fixed receiver subset I define

 (S_I g)(y)=∫_I c_w(y)g(w)dw/m_w,
 S_I:L2(I,dw)→L2(f(y)dy).

The adjoint is (S_I*φ)(A)=∫π_A(dy)φ(y), A∈I. Thus the UNMASKED block from I to J is exactly S_J* S_I on the real receiver measure. This uses the SAME full f in both operators; it is not an assumed reversibility under a mass-weighted measure.

Let ρ_I(y)=∫_I c_w(y)dw/m_w. Weighted Cauchy–Schwarz and matching give

 ∫f |S_Ig|²
 ≤||ρ_I||∞ ∫f(y)∫_I c_w(y)|g(w)|²dw/m_w dy
 =||ρ_I||∞ ∫_I |g(w)|²dw.                               (2)

All integrands in the last exchange are nonnegative. Finite-support L2 estimates extend by density; a>0 and the actual center bounds supply finite constants. Zeros of f cause no issue in L2(fdy).

For a mass window I={M≤m_w≤e^D M}, the proved native window capacity gives ||ρ_I||∞≤(1+D)/q_-. Consequently

 ||S_I||²≤(1+D)/q_-,
 ||S_J* S_I||≤sqrt((1+D_I)(1+D_J))/q_-.                 (3)

This is a legitimate TWO-space estimate, using full matching in the equality of (2). It is an application of the old window receipt, not new payment for the far kernel.

To preserve the exact mass gate, set m0=q_-a^n and use half-open blocks I_j=[m0 K^j,m0 K^(j+1)), retaining any last endpoint in the final block. If the output block is j and input block k, then:

* j≤k: the far block vanishes;
* j≥k+2: it equals S_j* S_k, since every pair has m_A>K m_w;
* j=k+1: the exact indicator 1_{m_A>K m_w} MUST remain inside the block.

Threshold equality in the adjacent block is excluded. Merely replacing that partial block by the entire Gram block is a positive upper relaxation, not an identity. Both its row and column must still be considered for an operator-norm bound.

There are O(√n) mass blocks on the octave, but (3) gives an O(√n)/q_- bound per block. Their positive cross contributions do not become orthogonal simply because the receiver subsets are disjoint. Using only these separate bounds loses the desired order. It also discards the geometric fact that all blocks are selected on the same center space with one actual radius per center.

## 3. What remains unproved, and why the present bounds do not settle it

The full source occupation obeys ρ_E≤A_n/q_- with A_n=1+n log(b/a). Thus (2), applied to all E, proves

 ||H_full||=||S_E* S_E||≤A_n/q_-.

Since the kernels are nonnegative, |H_far g|≤H_full|g|, so this only gives ||H_far||≤A_n/q_-. It yields P2≤(λ/q_-)A_n² X_q/q_-², of the already known linear-in-n cost after division by h². No one-sided row estimate was substituted for a norm estimate, and no PSD Schur-multiplier result was applied to the directed mass mask.

The concrete unresolved step for the candidate is a JOINT cross-block estimate for the actual family S_j, not another per-block window bound. Even the following constant-input version would suffice:

 Σ_j || Σ_k (H_far)_(j,k) 1_(I_k) ||²_(L2(I_j,dA))
                      ≤C n |E|/q_-².                  (4)

In (4) the adjacent block has the exact gate described above, and the off-diagonal blocks use the same full-f source inner product. Establishing (4) requires controlling the simultaneous cross terms between different smaller-mass blocks at a common parent. The known individual source occupations, Gram factorization, strict mass ordering and disjoint receiver-block domains do not in the proof above control those cross terms. Neither finite block count nor the small overlap of one normalized far-mass pair establishes such a joint square bound.

Equation (4) is explicitly a remaining target, not a renamed result: the work here only verifies that the proposed L2 mechanism has the correct measures, factorization and exact mass boundaries. No new general estimate for the cross terms has been obtained. A future proof would have to use actual simultaneous cube geometry and matching beyond (2)–(3), or abandon this stronger spectral route and retain more of the original marked flow. There is no new X_q coefficient or W fee to add to the ledger.

## 4. Local checks and skill scope

Used the F05 skill as a measure/domain and two-sided Schur checklist, not as a theorem about this matched cube kernel:
`/Users/zhengzhihao/.codex/skills/math-f05-l2-spectral-parameter-schur-test/SKILL.md`.
Only the elementary Cauchy–Schwarz argument (2) is used; no external spectral theorem or citation-only multiplier assertion is invoked.

Executed locally with Python Fraction:

 PASS {'matched_gram': 36, 'source_frame_energy': 36,
       'two_sided_schur': 108} total 180.

The checks use one piecewise-constant full source on a cell grid, actual cell-aligned cubes with exact matched masses, and retain a 4/3 q-band. Receiver weights are finite quadrature weights. They verify exact Gram equality, the source-space bound using computed ρ, and the product of BOTH Schur constants for several strict mass cuts. They do not certify a native center-volume norm or the missing (1)/(4), and do not realize all original history/rank gates. No floating-point eigenvalue fit is used.

The exact code executed in this round follows for reproduction. The parent also extracted it as r406_geometry_check.py and reran it; that rerun is not an additional experiment.

```python
from fractions import Fraction as F
from itertools import product
counts={'matched_gram':0,'source_frame_energy':0,'two_sided_schur':0}
points=list(product([F(2*j+1,4) for j in range(-4,4)],repeat=2))
centers=list(product([F(j,2) for j in range(-1,2)],repeat=2))
for seed in range(1,10):
    f=[F(4+(i*seed)%3,16) for i in range(len(points))]
    raw=[]
    for j,c in enumerate(centers):
        R=F(1 if j%2 else 2)
        cap=[all(abs(x[k]-c[k])<=R/2 for k in range(2)) for x in points]
        m=sum(z for z,b in zip(f,cap) if b)
        raw.append((cap,m,m/R**2,F(j%3+1,7)))
    lam=max(x[2] for x in raw)
    rec=[x for x in raw if x[2]>=3*lam/4]
    N=len(rec)
    H=[[sum(f[i] for i in range(len(f)) if rec[j][0][i] and rec[k][0][i])/(rec[j][1]*rec[k][1]) for k in range(N)] for j in range(N)]
    for phase in range(4):
        g=[F((j+phase)%5-2,3) for j in range(N)]
        Sg=[sum(rec[j][3]*g[j]*rec[j][0][i]/rec[j][1] for j in range(N)) for i in range(len(f))]
        src=sum(f[i]*Sg[i]**2 for i in range(len(f)))
        gram=sum(rec[j][3]*rec[k][3]*g[j]*g[k]*H[j][k] for j in range(N) for k in range(N))
        assert src==gram
        counts['matched_gram']+=1
        rho=max(sum(rec[j][3]*rec[j][0][i]/rec[j][1] for j in range(N)) for i in range(len(f)))
        norm=sum(rec[j][3]*g[j]**2 for j in range(N))
        assert src<=rho*norm
        counts['source_frame_energy']+=1
        for K in (F(3,2),F(2),F(3)):
            T=[[H[j][k]*int(rec[j][1]>K*rec[k][1]) for k in range(N)] for j in range(N)]
            row=max(sum(T[j][k]*rec[k][3] for k in range(N)) for j in range(N))
            col=max(sum(T[j][k]*rec[j][3] for j in range(N)) for k in range(N))
            out=sum(rec[j][3]*sum(T[j][k]*rec[k][3]*g[k] for k in range(N))**2 for j in range(N))
            assert out<=row*col*norm
            counts['two_sided_schur']+=1
print('PASS',counts,'total',sum(counts.values()))
```

Bounded task ends here. No claim of new global or subbranch payment is made.
