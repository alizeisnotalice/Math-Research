# R406：保留原旧来源的秩分支付款

2026-10-19。结论是当前 R404 实际远域正分支的新付款；不证明其高旧秩补集或一般根阶上界。只使用冻结原场，不把新增见证接收者赋予原历史资格。

## 1. 原场、原标记与精确流

设 f≥0 属于 L1，W=∫f；实际接收测度为 du，a≤R_u≤b≤2a，m_u=f(Q_u)=q_uR_u^n，q_-≤q_u≤λ。记 μ(du)=du/m_u、σ(du)=q_u du、π_u(dy)=f(y)c_u(y)dy/m_u，X_q=σ(E)。取 K=e^(√n)、s=1+√n、h=s/(ε_0q_-)，0<ε_0≤1/2。

闭质量秩与严格过去秩分别为
\[
T_u(y)=\int c_w(y)1_{m_w\le m_u}\mu(dw),\qquad
Z_u(y)=\int c_w(y)1_{m_w<m_u/K}\mu(dw).
\]
物理累计 J_y(r)=∫_{R_w≤r}c_w(y)μ(dw) 始终为原 J。物理时钟为 ℓ(dr)=nr^{-n-1}dr+b^{-n}δ_b；ν_u(dr)=R_u^n1_[R_u,b](r)ℓ(dr) 是概率，包括终点原子。

原 R389–391 保留流可写为
\[
d\Gamma_0(y,u,v)=f(y)q_u c_u(y)c_v(y)
\frac{\chi_0(y,u,v)}{T_u(y)}\,dy\mu(du)\mu(dv),\quad0\le\chi_0\le1. \tag{1}
\]
这里 χ_0 包含原质量亏损 1−m_v/m_u，以及对 ν_u 的真实时钟平均：原 high-J 门、全部保存标记、T_u/max(J_y(r),T_u) 均留在平均中。原空间、历史、冷端、来源和阶段限制没有被重新生成。活跃流满足
\[
m_u>Km_v,\quad \alpha<T_v(y)/T_u(y)<\beta<1,\quad T_v(y)>2h.
\]
阶段 Γ_i=1_{A_i}(u)1_{A_i}(v)Γ_0 为原嵌套正限制。原切换标记 b_i(z)≥0 满足 Σ_i b_i(z)≤1；它们依赖原密度层和 D_i，本文不重算任何 m、q、J 或来源后验。

需要的原逐来源容量是
\[
\Gamma_i(du,dy,E)\le\beta\sigma(du)\pi_u(dy),\qquad
\Gamma_i(E,dy,dv)=\sigma(dv)\pi_v(dy)k_i(v,y),\quad k_i\le C_{\rm col}, \tag{2}
\]
其中 C_col=(λ/q_-)[1−β+log(β/α)]。第一跨越质量原子的项 1−β 不删除。

令 F(y,z) 表示 R404 的双范数远域：||y−z||∞>a(e^(1/√n)−1)/2 且 ||y−z||1>a/8。令 C_A(y,z)=∫_{m_w<m_A/K}c_w(y)c_w(z)μ(dw)，φ_u=min(1,C_u/h)、ψ_v=min(1,C_v/h)。当前费用正好是
\[
\begin{split}
R_{\rm ext,F}&=\sum_i\int d\Gamma_i\,\pi_u(dz)b_i(z)(1-c_v(z))
 1_{Z_u(z)>Lh}(1-\phi_u)1_F,\\
R_{\rm small,F}&=\sum_i\int d\Gamma_i\,\pi_v(dz)b_i(z)
 1_{T_v(z)>Lh}(1-\psi_v)1_F,\qquad R404=R_{\rm ext,F}+R_{\rm small,F}.
\end{split} \tag{3}
\]
L≥4。任何额外原正限制均留在 Γ_i 或上述标记内。式(3)才是分拆对象；无标记 P2 并不等于它。

## 2. 原子安全的旧来源阈值收据

对任意可测 c(y)≥4，按原旧来源 y 定义 R_hi[c]=R404[T_v(y)>hc(y)]。严格有
\[
\boxed{R404\le R_{\rm hi}[c]+2C_{\rm col}\lambda h\int f(y)c(y)dy.} \tag{4}
\]
若 ∫fc 无限，此式仅为扩展实数上界。

证明：固定 y，将 ρ_y(dw)=c_w(y)μ(dw) 推到实际质量轴。其闭 CDF 为 T。对任意 A≥0，
\[
\rho_y\{w:T_w(y)\le A\}\le A. \tag{5}
\]
确实，闭 CDF≤A 的质量值构成初始段；该段的每个完整初始截断的质量≤A，单调收敛即得结论。超过 A 的跨越原子整块被排除，不需要无原子假设。阈值 A=hc(y) 对固定 y 是常数，故 Tonelli 和 q_v≤λ 给
\[
\int\sigma(dv)\pi_v(dy)1_{T_v(y)\le hc(y)}
 \le\lambda h\int fc. \tag{6}
\]
对固定原边(y,u,v)，嵌套 Γ_i≤Γ_0 及 Σ_i b_i(z)≤1 给两个端点全部阶段收费至多 π_u(Σ_i b_i)+π_v(Σ_i b_i)≤2。其余标记均≤1。因此低旧秩部分≤2Γ_0[T_v(y)≤hc(y)]，再用(2)、(6)即得(4)。这是一次累计收费，不是每阶段收一次 W。

历史区别：R388 的 F_u 后验平均及 R390 的小端 F_v 标量截断没有删除每个旧来源的 T_v(y)≤ch；R386 已删去的是 T_v≤2h；R398 的低秩收费作用于新见证 z。本式支付当前仍在(3)内的旧 y 分支，保留所有旧价格，不重复使用它们。

## 3. 自适应根阶价格

定义原完整占用 Z_tot(y)=∫_E c_w(y)μ(dw)。完整匹配给
\[
\int fZ_{\rm tot}=|E|\le X_q/q_-.
\]
取 c_*(y)=4+√(Z_tot(y)/h)，可测且 ∫fc_* 有限。Cauchy–Schwarz 得 h∫fc_*≤4hW+√(hW|E|)。因此任意 η>0，r=λ/q_- 时，
\[
R404\le R_{\rm hi}[c_*]+\eta X_q+D_\eta sW,\qquad
D_\eta=\varepsilon_0^{-1}
 [8C_{\rm col}r+C_{\rm col}^2r^2/\eta]. \tag{7}
\]
这是对(4)交叉项的 Young 不等式，未使用来源密度帽。W=0 时接收场为空。参数一致有界时(7)确为可吸收 X 加根阶 W 的实际分支付款。

高补集仍为原 T_v(y)>4h+√(hZ_tot(y))，不能把此条件转移给 z 或新增见证 w。另一个合法但非必要的选择 c(y)=4+κZ_tot(y)/h 给价格 8C_col λhW+2C_col(λ/q_-)κX_q；本文最终采用(7)，两种价格不相加。

## 4. 高旧秩的真实双秩改进

先取常数 c≥4。原远质量 m_u>Km_v 蕴含 Z_u(y)≥T_v(y)>ch；闭窗容量给
\[
0\le T_A(y)-Z_A(y)\le (1+\log K)/q_-=\varepsilon_0h.
\]
所以小端旧 Z_v(y)>(c−ε_0)h。外端新 Z_u(z)>Lh，小端新 Z_v(z)>(L−ε_0)h。对 a,b≥2、x∈[0,1]，
\[
\frac{1-x}{(a-x)(b-x)}\le\frac1{ab},
\]
因为两边交叉相乘后差为 x(ab−a−b+x)≥0。应用于 x=C_A/h，并保原 exclusive E_A(y,z)=Z_A(y)−C_A(y,z)，得到
\[
R_{\rm hi}(c)\le \frac{B_{c,L}}{h^2}J_{\rm ex,F}
\le\frac{B_{c,L}}{h^2}P_2,\quad
B_{c,L}=\frac\beta{cL}+\frac{C_{\rm col}}{(c-\varepsilon_0)(L-\varepsilon_0)}
\le\frac{64S}{49cL}. \tag{8}
\]
这里 J_ex,F、P2 是 R405 同一原场的矩；式(8)是充分上界而非原费用等价。保留 c(y) 时，外项 β/[Lc(y)] 和小项 C_col/[(L−ε_0)(c(y)−ε_0)] 必须留在旧 y 积分内部。统一界使用 c,L≥4、ε_0≤1/2，因此 c−ε_0≥7c/8。

条件性量级传递：若将来另证 P2≤C_* nF(n)X_q/q_-²（F≥1），则高部分≤(64/49)C_*ε_0²S F/(cL) X_q。给定 δ>0，可取
\[
c=L=\max\{4,\sqrt{64C_*\varepsilon_0^2SF/(49\delta)}\}.
\]
结合新低旧秩费与母分拆价格 P_L=λh[β(L+ε_0)+C_col L]，总相关来源价为 λh[(β+3C_col)c+βε_0]W，同阶 √(nF)W。此 P2 假设未证；仅用现有 O(n²) 矩仍为线性价格。改变 L 必须重建 R398 全部高/低新来源分拆及 P_L，不能仅在(8)更换 L。

## 5. 原入口与限制

式(7)只替换旧总账的 R404。其母账系数分别为 G0 的16、BH的32、原入口的64Λ，Λ=128/119。因此新增入口价格恰为 64ΛηX_q+64ΛD_ηsW，余项为64ΛR_hi[c_*]；旧 χ_n、Δ404、P_L、S390、E387、H及全部外部费用原样保留。用常数 c 的(4)则新增入口来源费为128ΛC_col λchW。低维原完整core替换另用，不与这些价格叠加。

无标记P2丢失了(1)中的共同旧来源、原时钟平均、质量亏损、中间秩、外端 z 不捕获原 v、各阶段 b_i 与 D_i 的耦合；本轮只具体利用其中旧来源 T_v。未证明其他标记已结算，更没有令新 w,t 自动继承这些门。高旧秩远域仍未付；原负平方信用没有再次扣除。

## 6. 实际核验范围

脚本 `/tmp/r406_aux_check.py` 已实际运行，输出：

```
PASS {'marked_old_rank': 15, 'soft_two_rank': 240, 'coefficient_transfer': 48} total 303
positive_marked_low_rank_cases 15
```

15项检查在 f=1_[−8,8] 上用有限接收类型、精确来源区间、真实盒质量及嵌套阶段标记核验两端累计和闭CDF；所有低分支值均正。接收类型共享中心0、半径为1/2/4/8/16，是有限类型代数fixture，不是单值实际半径选择器或 native du 场，也不满足原octave/全历史合同。240项为有理双秩软因子，48项为系数比较；不能将303项解释为连续场或全维渐近证明。严格证明是上文的正分解、Tonelli和原子安全CDF论证。
