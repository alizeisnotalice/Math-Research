from fractions import Fraction as F
from itertools import product
counts={'matched_gram':0,'source_frame_energy':0,'two_sided_schur':0}
points=list(product([F(2*j+1,4) for j in range(-4,4)],repeat=2))
centers=list(product([F(j,2) for j in range(-1,2)],repeat=2))
for seed in range(1,10):
    f=[F(4+(i*seed)%3,16) for i in range(len(points))]
    raw=[]
    for j,c in enumerate(centers):
        R=F(1 if j%2 else 2)
        cap=[all(abs(x[k]-c[k])<=R/2 for k in range(2)) for x in points]
        m=sum(z for z,b in zip(f,cap) if b)
        raw.append((cap,m,m/R**2,F(j%3+1,7)))
    lam=max(x[2] for x in raw)
    rec=[x for x in raw if x[2]>=3*lam/4]
    N=len(rec)
    H=[[sum(f[i] for i in range(len(f)) if rec[j][0][i] and rec[k][0][i])/(rec[j][1]*rec[k][1]) for k in range(N)] for j in range(N)]
    for phase in range(4):
        g=[F((j+phase)%5-2,3) for j in range(N)]
        Sg=[sum(rec[j][3]*g[j]*rec[j][0][i]/rec[j][1] for j in range(N)) for i in range(len(f))]
        src=sum(f[i]*Sg[i]**2 for i in range(len(f)))
        gram=sum(rec[j][3]*rec[k][3]*g[j]*g[k]*H[j][k] for j in range(N) for k in range(N))
        assert src==gram
        counts['matched_gram']+=1
        rho=max(sum(rec[j][3]*rec[j][0][i]/rec[j][1] for j in range(N)) for i in range(len(f)))
        norm=sum(rec[j][3]*g[j]**2 for j in range(N))
        assert src<=rho*norm
        counts['source_frame_energy']+=1
        for K in (F(3,2),F(2),F(3)):
            T=[[H[j][k]*int(rec[j][1]>K*rec[k][1]) for k in range(N)] for j in range(N)]
            row=max(sum(T[j][k]*rec[k][3] for k in range(N)) for j in range(N))
            col=max(sum(T[j][k]*rec[j][3] for j in range(N)) for k in range(N))
            out=sum(rec[j][3]*sum(T[j][k]*rec[k][3]*g[k] for k in range(N))**2 for j in range(N))
            assert out<=row*col*norm
            counts['two_sided_schur']+=1
print('PASS',counts,'total',sum(counts.values()))
