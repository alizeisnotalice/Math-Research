from fractions import Fraction as F
from itertools import product
counts={}
# Inclusive CDF low sets, with ties; no atom may be split at threshold.
for phase,N in [('initial',3),('atoms',5),('expanded',8)]:
 cdf=young=soft=0
 for seed in range(1,N+1):
  mass=[F(1+(i*seed)%4) for i in range(N+2)]
  weight=[F(1+(i+seed)%7,7) for i in range(N+2)]
  T=[sum(weight[j] for j in range(len(mass)) if mass[j]<=mass[i]) for i in range(len(mass))]
  for cap in [F(k,3) for k in range(1,6*N)]:
   assert sum(weight[i] for i in range(len(mass)) if T[i]<=cap)<=cap
   cdf+=1
  for h,W,X,q,C,eta in product([F(1,3),F(2)], [F(1,5),F(3)], [F(1,7),F(9)], [F(2,3),F(1)], [F(1),F(3)], [F(1,16),F(1,3)]):
   # k sqrt(h W X/q) <= eta X+k^2 h W/(4 eta q).
   k=2*C
   rhs=eta*X+k*k*h*W/(4*eta*q)
   assert rhs>=0 and rhs*rhs>=k*k*h*W*X/q
   young+=1
 for c,L,eps in product([F(4),F(5),F(16)], [F(4),F(7),F(32)], [F(1,8),F(1,2)]):
  for h in [F(1,3),F(2)]:
   for Ccap in [F(0),h/4,h/2,3*h/4,h]:
    Eold=(c-eps)*h-Ccap; Enew=(L-eps)*h-Ccap
    softweight=1-Ccap/h
    assert softweight*(c-eps)*(L-eps)*h*h<=Eold*Enew
    soft+=1
 counts[phase]={'cdf':cdf,'young':young,'soft':soft}
print('PASS exact Fraction checks',counts)
print('Scope: finite atomic CDF, scalar Young and soft factors only; not full geometric core or general upper bound.')
