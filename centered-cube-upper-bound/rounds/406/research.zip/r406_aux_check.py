from fractions import Fraction as F
from itertools import product
counts={'marked_old_rank':0,'soft_two_rank':0,'coefficient_transfer':0}
positive=0
radii=list(map(F,(1,2,4,8,16)))
edges=list(map(F,(-8,-4,-2,-1)))+[F(-1,2),F(1,2)]+list(map(F,(1,2,4,8)))
cells=list(zip(edges,edges[1:])); weights=[b-a for a,b in cells]
capture=[[int(abs((a+b)/2)<=r/2) for a,b in cells] for r in radii]
mu=[F(1,5),F(1,4),F(1,3),F(1,2),F(1)]
rank=[[sum(mu[j]*capture[j][y] for j in range(v+1)) for y in range(len(cells))] for v in range(5)]
W=sum(weights)
for h in (F(1,20),F(1,10),F(1,5)):
    gamma={}; incoming={}
    for u,v,y in product(range(5),range(5),range(len(cells))):
        if not(capture[u][y] and capture[v][y] and radii[u]>2*radii[v]): continue
        Tu,Tv=rank[u][y],rank[v][y]
        if not (F(1,10)*Tu<Tv<F(9,10)*Tu and Tv>2*h): continue
        mark=(1-radii[v]/radii[u])*F(2,3)
        value=weights[y]*mu[u]*mu[v]*mark/Tu
        gamma[u,v,y]=value
        incoming[v,y]=incoming.get((v,y),F(0))+mu[u]*mark/Tu
    C=max(incoming.values(),default=F(0))
    stages=[set(range(5)),set(range(4)),set(range(3))]
    bs=[]
    for stage in stages:
        di=[]
        for z in range(len(cells)):
            di.append(sum(g*(F(capture[u][z],radii[u])+F(capture[v][z],radii[v])) for (u,v,y),g in gamma.items() if u in stage and v in stage))
        bs.append([F(3,10)*max(F(0),1-F(1,100)/d) if d else F(0) for d in di])
    for option in (('constant',F(4)),('constant',F(6)),('constant',F(8)),('adaptive',F(1,5)),('adaptive',F(1,2))):
        c=[option[1] if option[0]=='constant' else 4+option[1]*rank[-1][y]/h for y in range(len(cells))]
        low=sum(g for (u,v,y),g in gamma.items() if rank[v][y]<=c[y]*h)
        bill=F(0)
        for stage,bi in zip(stages,bs):
            for (u,v,y),g in gamma.items():
                if u not in stage or v not in stage or rank[v][y]>c[y]*h: continue
                postu=sum(weights[z]*capture[u][z]*bi[z] for z in range(len(cells)))/radii[u]
                postv=sum(weights[z]*capture[v][z]*bi[z] for z in range(len(cells)))/radii[v]
                bill+=g*(postu+postv)
        assert bill<=2*low
        assert low<=C*h*sum(weights[y]*c[y] for y in range(len(cells)))
        for y in range(len(cells)):
            occupied=sum(mu[v]*capture[v][y] for v in range(5) if rank[v][y]<=c[y]*h)
            assert occupied<=c[y]*h
        positive+=bill>0
        counts['marked_old_rank']+=1
for c,L,eps,x,da,db in product((F(4),F(6),F(8)),(F(4),F(7)),(F(1,4),F(1,2)),(F(0),F(1,4),F(1,2),F(3,4),F(1)),(F(0),F(1,3)),(F(0),F(1,2))):
    external=(1-x)/((c+da-x)*(L+db-x))
    small=(1-x)/((c-eps+da-x)*(L-eps+db-x))
    assert external<=1/(c*L)
    assert small<=1/((c-eps)*(L-eps))
    counts['soft_two_rank']+=1
for c,L,eps,beta,col in product((F(4),F(5),F(9)),(F(4),F(7)),(F(1,4),F(1,2)),(F(1,3),F(3,4)),(F(1),F(2))):
    new=beta/(c*L)+col/((c-eps)*(L-eps))
    old=beta/(2*L)+col/((2-eps)*(L-eps))
    assert new<=old
    assert new<=F(64,49)*(beta+col)/(c*L)
    counts['coefficient_transfer']+=1
print('PASS',counts,'total',sum(counts.values()))
print('positive_marked_low_rank_cases',positive)
