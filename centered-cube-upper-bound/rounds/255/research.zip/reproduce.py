#!/usr/bin/env python3
"""Frozen R255 hashes, exact finite certificates, and audit diagnostics."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,re
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
def verify():
    for name,expected in manifest['sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
verify()
print('manifest PASS',len(manifest['sha256']),flush=True)
with tempfile.TemporaryDirectory(prefix='cube-r255-replay-') as tmp:
    output=Path(tmp)/'numeric_checks.json'
    subprocess.run([sys.executable,str(root/'numeric_checks.py'),'--contract',str(root/'task_contract.md'),'--output',str(output)],check=True)
    assert output.read_bytes()==(root/'numeric_checks.json').read_bytes(),'numeric JSON differs'
    print('numeric JSON byte-identical PASS',flush=True)
    for name in ['audit.md','maximal_consequence.md']:
        blocks=re.findall(r'```python\n(.*?)```',(root/name).read_text(),re.S)
        assert blocks,('missing embedded checks',name)
        for i,block in enumerate(blocks):
            script=Path(tmp)/(name+'.'+str(i)+'.py');script.write_text(block)
            subprocess.run([sys.executable,str(script)],check=True)
        print('embedded checks PASS',name,len(blocks),flush=True)

verify()
print('post-replay hashes PASS; no PDF compilation')
