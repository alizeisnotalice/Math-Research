# R255 独立审计

## 命题先行初筛（未读作者稿）

工作只写本文件；共享树不改他人。首次读取时255目录/合同尚未落盘，已通知主代理并按授权创建本文件。历史依据只读R254冻结checkpoint中的已证Peano与kernel界。

目标为任意非负有限L1原来源mu，d=a/(8sqrt n)，任意内部不交尺度窗[s,t]属于[a,2a]，窗口数不受限。零来源、s=t或零总窗长均应给零；可先有限窗，再按非负能量单调推广到可数窗。无需来源L2或坐标独立，不可把同一结论移给任意signed来源。

**独立推导支持候选机制，待作者完整正测度构造终核。** 令k_R=(R−|x|)+/R²，H=(d−|x|)+³/(6d²)，k_d=(d−|x|)+/d²。H<=d² k_d/6且|H'|<=d k_d/2。空间二阶导k_R''=R^-2(delta_-R−2delta_0+delta_R)，所以a_R=H*k_R''由k_d与正测度卷积支配，质量<=c0=2d²/(3a²)。对logR求导而非对绝对值求导，导数正majorant质量<=d/a+(4/3)(d/a)²<=3d/a，因此|a_R−a_m|的正majorant质量<=3(d/a)log(t/s)。

令m=(s+t)/2,l=(t−s)/2，cross的空间二阶导为(st)^-1(delta_-m+delta_m−delta_-l−delta_l)。a_c−a_m可精确拆为系数差乘[H_-m+H_m−2H_0]与(st)^-1[H_-l+H_l−2H_0]，后者由H'平移积分支配。相应质量至多4(d²/6)l²/(st m²)+d l/(st)，在s>=a、t<=2a、d<=a下确可由2(d/a)log(t/s)支配；要保实际平移measure而不能仅给L1范数后冒用pair-transfer。

对每个active集合S，先冻结整块a_m的tensor，再保留inactive坐标的signed B_(n−|S|)。active差的tensor telescoping只用上述正卷积majorant，得到10|S|c0^(|S|−1)(d/a)delta及c0^|S| ||B_(n−|S|)||1。base只用B_n正部。零inactive维约定B_0=0。按全部subset求和给单窗能量上界

`[(4T−2) A_n delta²+10n(d/a)T delta] E_d(mu)`，

其中T=(1+c0)^n，A_n=n(log(n+1)+4)。另因原来源正、cross正，真实差平方<=E_s+E_t<=2T E_d；此处不是一般signed源的L2三角价。取两界min，以min(A,Cdelta²+Ddelta)<=sqrt(A C)delta+Ddelta，再按sum delta<=log2，消去窗口数。本轮coarse d=a/(8sqrt n)给T<=exp(1/96)，总价<=4exp(1/96)log2 sqrt(A_n)E_d。该常数依A_n>=n(log2+4)安全，尚待作者稿逐项绑定。

连续性与测度要求：所有H平移及k_d卷积majorant为实际有限正测度；最终连续代表使pair积分逐点有意义。有限正L1来源E_d有限，故R254自相关Cauchy保原位置/质量即可传递，不作胞内均匀化。若作者只证明a差的L1小而无k_d卷积支配，这是最早阻断；若先绝对值inactive B，将丢delta²抵消而恢复旧逐窗固定费。

本机实际执行35项bounded scalar质量/常数核验（Fraction精确质量表达式与mp60比较），全部PASS；普通诊断非区间，不替代上述任意参数证明。未运行新物理模型或借用原FULL资格。等待合同/作者稿及主整合后终审。


## coarse_source_transfer.md 全文审查

**CT1–6 PASS。** 已在命题初筛后完整读稿，受审SHA256 fc46ce46c9cda0f6c4907148fa96986242a441d5a875153194675cb373886316。CT3.1是实际平移区间Lebesgue测度证书，H绝对连续而H'零点跳不妨碍FTC。CT3.3系数与平移的两项质量分别<=4d²h/(3a³)、dh/a²；h<=a delta、d<=a使3(d/a)delta安全。CT3.4的cross四原子分解符号准确，近零二原子确在取绝对值前相减，常数2安全。

CT4对每个subset仅冻结active tensor；普通inactive概率张量并未分别作尺度变化估计，最后保整个B_l。所有正证书张量后仍有全坐标K_d卷积，因此CT2.2实际同源自相关CS可直接使用；不能把这一机制简化为L1核界而省空间majorant。B_0=0和A_0=0已定义，n1也覆盖。subset求和导数项是n(1+c)^(n−1)，用nT上放方向正确；二次项2A_n+4(T−1)A_n=(4T−2)A_n准确。

固定尺度备选2T依赖原正源和非负cross，保与本定理的量词一致。min两真实source界后按sum delta<=log(b/a)结算，退化窗与a=b无须除0。d=a/(8sqrt n)下T<=exp1/96；用A_n>=4n得sqrt8+5/8<4，作者最终常数比初筛更宽松而正确。有限窗口证明可按非负partial sums扩展至可数内部不交窗。旧R254粗d的任意窗数transfer缺口至此已付，不再登记为本轮未证；最大值还需prefix费，原高来源或一般弱型仍未闭合。

### 初筛35项实际诊断的完整复现代码

以下是本人本轮实际执行的同一代码；Fraction质量表达式是精确的，和log/粗尺度常数比较为mp60普通诊断，非区间证书，通用证明见正文。

```python
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=60
checks=0
for nr in [1,2,16,256]:
 d=mp.mpf(1)/(8*mp.sqrt(nr)); c0=2*d*d/3
 T=(1+c0)**nr; An=nr*(mp.log(nr+1)+4)
 assert T<=mp.exp(mp.mpf(1)/96)
 assert mp.sqrt(2*T*(4*T-2)*An)+10*nr*d*T<=4*T*mp.sqrt(An)
 checks+=2
for s in [F(1),F(5,4),F(3,2)]:
 for t in [s,F(7,4),F(2)]:
  if t<s: continue
  for d in [F(1,8),F(1,16),F(1,128)]:
   m=(s+t)/2; l=(t-s)/2; cd=d*d/6
   mass=4*cd*l*l/(s*t*m*m)+d*l/(s*t)
   delta=mp.log(mp.mpf(t.numerator)/t.denominator/
                (mp.mpf(s.numerator)/s.denominator))
   assert mp.mpf(mass.numerator)/mass.denominator<=2*mp.mpf(d.numerator)/d.denominator*delta+mp.mpf('1e-58')
   checks+=1
print('PASS',checks,'bounded scalar majorant/constant checks; noninterval diagnostic')
```

实际输出：`PASS 35 bounded scalar majorant/constant checks; noninterval diagnostic`。可用本机Python+mpmath1.3重放，无旧文件输入；不将其计入正式数值菜单或冒称FULL。


## 主稿与最大后果整合审核

**主proof全文及MC1–6 PASS。** 主稿正Peano/CT证明逐项与已审一致，有限正L1使所有pair与能量有限；连续代表和正measure majorant明确，未把分布等式只作形式计算。作者CT仅修inline排版至SHA377470e6603cd7da9de541d63b133fd49ca4a934dd0701cd5e1ffe281e4d38a1，数学未变。

最大值网格为J=ceil(n ell),N=J+1,q=ceil(log2 N)+1；first block包含非零f0，总响应单付T，其余nonzero块含末padding都是真窗口，count<=N/2^k。SW同时给逐块2T和同层(Q2^k/n+L)ell，D_k=T+min两价正确。固定正权sqrt D给同一个实际maximal算子的合法平方价格；e²连续up-grid和直接NT备选均保留，不假定正交。MC的exact D可比parent保守D更尖，两者是不同但均合法的显式证书，未混常数。

几何split同时付quadratic项与linear delta项的plateau。主q sqrt W已保留，粗d下W=O(sqrt n)，因此O(sqrt n log²(n+2))严格成立；没有将其冒称R254更细d的O(sqrt(nlog n))。ell0/单节点固定尺度、零源及端点padding都覆盖。

初始theta=min(1,tau/p)对每个zeta<=mu具有hereditary能量证书，已付SW对任意正来源故也适用提取的sigma。实际E、原共同R(x)与mu=sigma+rho均保，tau=lambda sqrt n/P的单位root质量价与真实剩余项完整。MC13若原traffic已有C_dom支配，外误差分配正确付C_dom²，而非偷去prefactor。MC11局部质量只是充分资格，MC12尾积分是精确原高剩余，不擅称已小；不同粗细d的能量/邻域不允许免费混配。

## 正式数值实现初审

已逐项读当前numeric的正measure构造及Bernstein验证。全部断点来自H、三角核、CDF的平移中心及中心±d；其外残差恒0，各相邻段残差为degree<=3。代码的四个函数值在0,1/3,2/3,1处精确重建cubic Bernstein coefficients：aa=12b1+6b2、bb=6b1+12b2，因此(2aa−bb)/18及(2bb−aa)/18确为b1,b2。只有所有精确Fraction系数非负才接受整段；否则二分重新证书，midpoint assert只作失败侦测而非通过凭据。故实际认证的是每段全体点，不是采样正就算majorant。两种残差符号分别认证绝对支配；所有atoms/segments非负、质量精确计算、支持外为0均保。

source卷积用真实正体积盒profile的分段线性乘积Fraction积分，tensor只描述实际指定输入。每窗价用delta上界(t−s)/s与A整数上界，是有限实例更松认证；真正无窗数log价仅ordinary mp40/70诊断，通用证明来自CT。最终菜单/notes/hash尚待数值员冻结后绑定，当前不宣称完整数值脚本由本人重放。


## 最终结论、实际运行归属与冻结

**PASS，无待修数学阻断。** 已证任意正有限L1来源在原粗尺度d=a/(8sqrt n)上的任意不交窗平方增量总价，无窗口数惩罚；已证同粗尺度连续octave最大平方能量O(sqrt n log²(n+2))E_d和明确初始来源提取付款。它们是一般来源工具的新证明，不再只是假设或finite模型诊断。高剩余来源、全局weak1、原soft/双后验及父历史总价仍未闭合，report保持这一等级。主稿最终SHA与CT/MC整合一致。

最终数值静审PASS。保留8参数、124双符号majorant/1184 Bernstein子区间、6真实正体积L1来源/366窗；最后仅增加14项纯公式价格，维数到2^40不当作物理来源。新增上放D_k/P、q=J.bit_length()+1、两种ell与closed cap逐项符合主稿，134个40/70字段最大差8.18496306936e−41明确为普通非区间一致性。本人实际再次核对最终源码/合同JSON自绑定及两Python AST，全部PASS；读取全部124证书的minimum coefficient>=0和mass<=massupper亦实际执行通过。整个正式numeric完整逐字节迁移重放由主代理随后执行，不冒称本人已跑全部366窗。

本人本轮独立实际运行的附加代码有两组：(1)本audit完整归档的35项bounded scalar诊断；(2)从最终MC7 Markdown实际提取执行的24个bookkeeping案例、97层、8425个exact-count增量块，输出全PASS，max C/[sqrt n log²(n+2)]=12.371733479546620326。第二组验证exact D、cap、plateau、tau阈值单位的有限算术，不代替SW一般证明；两个代码现在均可由最终driver实际重放。

最终report统计、范围和未付项静审PASS。reproduce.py最终版已实读：全部manifest前验、临时目录实际运行numeric并比对完整JSON、抽取audit及maximal_consequence中全部Python块运行、全部hash后验；不修改原源码/数值，不编译PDF。driver/hash清单在本audit冻结后由主代理生成并实际执行，回执另存，不需为回执再改本文件。报告中的复现承诺未提前当作成功运行证据。

### 最终受审SHA256

不绑定audit自身，避免清单循环；后续修改下列文件须重新核对。

|文件|SHA256|
|---|---|
|task_contract.md|`2402b9a0f42dae8d0e7eb97f43ff35ad21f970ed957530a5be96347885c403e4`|
|proof.tex.txt|`3ac8837ea22db89065b49320550f676a8dd7dfed3cadbee67d30d7b16beaff00`|
|coarse_source_transfer.md|`377470e6603cd7da9de541d63b133fd49ca4a934dd0701cd5e1ffe281e4d38a1`|
|maximal_consequence.md|`5bf044f1056bd570ce270300e043e1727343bc81e7eacffce4a154229a78efe6`|
|report.md|`d7337eb0c9531562e272083eca07683f64d93e8dd0b6d2bcfad41b9cdfbf1520`|
|reproduce.py|`cf250a21cdd14af1496efc1642114fa38281f003e2da23226fd585d880564586`|
|numeric_checks.py|`996bedb78a710a9979f82b634a3ea1fb2030fd54dd05727b116e7e677a089293`|
|numeric_checks.json|`6e7d82b1a205be823967d884f10a7f877851bdbae8c99ceef197d6fd3a28561b`|
|numeric_notes.md|`9d173a4736650e3c86ed4c74d4e4d48900c1a5ab2472b87275d0c4ad935a1654`|

R255独立审计完成。audit.md冻结并停止写入。
