#!/usr/bin/env python3
"""R255 exact finite Peano majorants and genuine L1 multiwindow energies.
Profile/inner integration adapted from R254, copied here without runtime dependency.
"""
import argparse,hashlib,json,math
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fs(x): return str(x.numerator)+'/'+str(x.denominator)
def exact(x):
    if max(x.numerator.bit_length(),x.denominator.bit_length())<3000: return {'fraction':fs(x)}
    def sig(v):
        q=abs(v); return {'bits':q.bit_length(),'sha256':hashlib.sha256(q.to_bytes((q.bit_length()+7)//8,'big')).hexdigest(),'sign':-1 if v<0 else 1}
    return {'numerator':sig(x.numerator),'denominator':sig(x.denominator)}
def m(x): return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def enc(x): return mp.nstr(x,50)
def length(z,l,x,R): return max(F(0),min(z+l/2,x+R/2)-max(z-l/2,x-R/2))
def profile(z,l,x,R): return length(z,l,x,R)/(l*R)
def inner(z,l,w,q,R,S):
    pts=sorted({p+sg*(T+v)/2 for p,v,T in [(z,l,R),(w,q,S)] for sg in [-1,1]}|{p+sg*abs(T-v)/2 for p,v,T in [(z,l,R),(w,q,S)] for sg in [-1,1]})
    total=F(0)
    for a,b in zip(pts,pts[1:]):
        x0,x1=profile(z,l,a,R),profile(z,l,b,R);y0,y1=profile(w,q,a,S),profile(w,q,b,S)
        total+=(b-a)*(2*x0*y0+x0*y1+x1*y0+2*x1*y1)/6
    return total

def gram(boxes,R,S):
    total=F(0)
    for mass,z,l in boxes:
        for mass2,w,q in boxes:
            val=mass*mass2
            for zi,li,wi,qi in zip(z,l,w,q): val*=inner(zi,li,wi,qi,R,S)
            total+=val
    return total

def kd(x,d):return max(F(0),d-abs(x))/d**2
def H(x,d):return max(F(0),d-abs(x))**3/(6*d*d)
def cdf(x,d):
    if x<=-d:return F(0)
    if x<=0:return (x+d)**2/(2*d*d)
    if x<d:return 1-(d-x)**2/(2*d*d)
    return F(1)
def aconv(x,terms,d):return sum(w*H(x-c,d)for c,w in terms)
def gamma_value(x,atoms,segments,d):
    return sum(w*kd(x-c,d)for c,w in atoms)+sum(w*(cdf(x-u,d)-cdf(x-v,d))for u,v,w in segments)
def gm(atoms,segments):return sum(w for _,w in atoms)+sum((v-u)*w for u,v,w in segments)
def seg(u,v,w):return(min(u,v),max(u,v),w)
def bernstein(f,a,b):
    v0,v1,v2,v3=[f(a+(b-a)*F(i,3))for i in range(4)]
    aa=27*v1-8*v0-v3;bb=27*v2-v0-8*v3
    return[v0,(2*aa-bb)/18,(2*bb-aa)/18,v3]
def certify(f,knots):
    pieces=0;maxdepth=0;minimum=None;digest=hashlib.sha256()
    def work(a,b,depth):
        nonlocal pieces,maxdepth,minimum
        coeff=bernstein(f,a,b)
        if min(coeff)<0:
            assert depth<24, 'Bernstein certificate unresolved'
            assert f((a+b)/2)>=0, 'negative residual'
            work(a,(a+b)/2,depth+1);work((a+b)/2,b,depth+1);return
        pieces+=1;maxdepth=max(maxdepth,depth);minimum=min(coeff)if minimum is None else min(minimum,min(coeff))
        digest.update(('|'.join(map(fs,[a,b]+coeff))+'\n').encode())
    for a,b in zip(knots,knots[1:]):work(a,b,0)
    return {'certified_subintervals':pieces,'max_bisection_depth':maxdepth,'minimum_Bernstein_coefficient':fs(minimum),'coefficient_certificate_sha256':digest.hexdigest()}
def scalar_menu():
    return [('initial',F(1,8),F(1),F(4097,4096)),('initial',F(1,8),F(1),F(9,8)),('stress',F(1,8),F(1),F(2)),('stress',F(1,16),F(3,2),F(25,16)),('stress',F(1,16),F(1),F(1)),('expanded',F(1,32),F(63,32),F(2)),('expanded',F(1,64),F(1),F(65,64)),('expanded',F(1,64),F(1),F(1048577,1048576))]
def scalar_cases():
    rows=[]
    for phase,d,s,t in scalar_menu():
        mid=(s+t)/2;h=(t-s)/2;ch=d*d/6
        ar=lambda R:[(-R,1/R**2),(F(0),-2/R**2),(R,1/R**2)]
        ac=[(-mid,1/(s*t)),(-h,-1/(s*t)),(h,-1/(s*t)),(mid,1/(s*t))]
        jobs=[]
        for R in sorted({s,t,mid}):
            terms=ar(R);atoms=[(z,abs(w)*ch)for z,w in terms]
            jobs.append(('base_R_'+fs(R),terms,atoms,[],F(2,3)*d*d))
        jobs.append(('base_cross',ac,[(z,abs(w)*ch)for z,w in ac],[],F(2,3)*d*d))
        dl=2*(t-s)/(t+s)
        for R in [s,t]:
            terms=ar(R)+[(z,-w)for z,w in ar(mid)]
            atoms=[(-R,abs(1/R**2-1/mid**2)*ch),(F(0),2*abs(1/R**2-1/mid**2)*ch),(R,abs(1/R**2-1/mid**2)*ch)]
            segments=[seg(-R,-mid,d/(2*mid**2)),seg(R,mid,d/(2*mid**2))]
            jobs.append(('endpoint_difference_'+fs(R),terms,atoms,segments,3*d*dl))
        coef=1/(s*t)-1/mid**2
        atoms=[(-mid,coef*ch),(F(0),2*coef*ch),(mid,coef*ch)]
        segments=[seg(-h,F(0),d/(2*s*t)),seg(h,F(0),d/(2*s*t))]
        jobs.append(('cross_difference',ac+[(z,-w)for z,w in ar(mid)],atoms,segments,2*d*dl))
        jobs.append(('translation_H',[(h,F(1)),(-h,F(-1))],[],[seg(-h,h,d/2)],d*h))
        certs=[]
        for name,terms,atoms,segments,massupper in jobs:
            assert all(w>=0 for _,w in atoms)and all(w>=0 for _,_,w in segments)
            mass=gm(atoms,segments);assert mass<=massupper
            centres={z for z,_ in terms}|{z for z,_ in atoms}|{z for u,v,_ in segments for z in [u,v]}
            knots=sorted({z+v for z in centres for v in [-d,F(0),d]})
            for sign in [-1,1]:
                cert=certify(lambda x:gamma_value(x,atoms,segments,d)+sign*aconv(x,terms,d),knots)
                certs.append({'name':name,'residual_sign':sign,'positive_atoms':[[fs(z),fs(w)]for z,w in atoms],'positive_segments':[[fs(u),fs(v),fs(w)]for u,v,w in segments],'exact_mass':fs(mass),'rational_mass_upper':fs(massupper),'knots':list(map(fs,knots)),**cert})
        rows.append({'phase':phase,'d':fs(d),'s':fs(s),'t':fs(t),'log_ratio_lower':fs(dl),'log_ratio_upper':fs((t-s)/s),'certificates':certs})
    return rows

def bx(mass,z,l):return (F(mass),list(map(F,z)),list(map(F,l)))
def source_menu():
    return [('initial','one_interval',1,2,F(1),F(2),[bx(1,[0],[F(3,8)])],False),('initial','four_dim_correlated',4,4,F(1),F(3,2),[bx(F(1,3),[-F(1,3)]*4,[F(1,16)]*4),bx(F(2,3),[F(1,3)]*4,[F(1,8)]*4)],False),('stress','tiny_box_short_windows',1,8,F(1),F(1025,1024),[bx(F(1,4),[0],[F(1,4096)]),bx(F(3,4),[F(1,2)],[F(1,2048)])],False),('stress','four_dim_opposite_corners',4,32,F(3,2),F(2),[bx(F(2,5),[-F(3,4)]*4,[F(1,32)]*4),bx(F(3,5),[F(3,4)]*4,[F(1,16)]*4)],False),('expanded','tensor_mixture_16',16,64,F(1),F(2),[bx(F(1,3),[-F(1,4)],[F(1,8)]),bx(F(2,3),[F(1,4)],[F(1,4)])],True),('expanded','tensor_mixture_64',64,256,F(1),F(2),[bx(F(1,3),[-F(1,4)],[F(1,8)]),bx(F(2,3),[F(1,4)],[F(1,4)])],True)]
def source_cases():
    rows=[];values=[]
    for phase,name,n,N,lo,hi,boxes,tensor in source_menu():
        rt=math.isqrt(n);assert rt*rt==n;d=F(1,8*rt);T=(1+F(2,3)*d*d)**n;Aup=n*(n.bit_length()+4)
        energy=lambda R,S:gram(boxes,R,S)**n if tensor else gram(boxes,R,S)
        ed=energy(d,d);total=F(0);price=F(0);maxratio=F(0);minmargin=None
        for j in range(N):
            s=lo+(hi-lo)*F(j,N);t=lo+(hi-lo)*F(j+1,N)
            inc=energy(s,s)+energy(t,t)-2*energy(s,t);du=(t-s)/s
            cost=min(2*T,(4*T-2)*Aup*du*du+10*n*d*T*du)
            assert inc>=0 and inc<=cost*ed
            total+=inc;price+=cost;maxratio=max(maxratio,inc/(cost*ed));minmargin=cost-inc/ed if minmargin is None else min(minmargin,cost-inc/ed)
        rows.append({'phase':phase,'name':name,'n':n,'windows':N,'range':[fs(lo),fs(hi)],'d':fs(d),'tensor_source':tensor,'source_boxes_per_coordinate_if_tensor':[{'mass':fs(v),'centre':list(map(fs,z)),'side':list(map(fs,l))}for v,z,l in boxes],'E_d':exact(ed),'increment_sum':exact(total),'sum_rational_single_window_prices':exact(price),'max_actual_over_window_price':exact(maxratio),'minimum_normalized_window_margin':exact(minmargin),'T':fs(T),'A_rational_upper':Aup})
        values.append((name,n,N,lo,hi,d,T,total/ed,price))
    return rows,values

def diagnostic(values,dps):
    with mp.workdps(dps):
        rows=[]
        for name,n,N,lo,hi,d,T,ratio,price in values:
            tt=m(T);An=n*(mp.log(n+1)+4)
            whole=mp.log(m(hi/lo))*(mp.sqrt(2*tt*(4*tt-2)*An)+10*n*m(d)*tt)
            assert m(ratio)<=whole
            rows.append({'name':name,'normalized_increment_sum':enc(m(ratio)),'rational_window_price_sum':enc(m(price)),'window_count_free_price':enc(whole),'actual_over_count_free_price':enc(m(ratio)/whole),'T':enc(tt),'coarse_simple_price':enc(4*mp.exp(mp.mpf(1)/96)*mp.log(m(hi/lo))*mp.sqrt(An))})
        return rows

def formula_prices(dps):
    with mp.workdps(dps):
        rows=[]
        for n in [1,16,256,4096,65536,2**24,2**40]:
            for divisor in [1,16]:
                ell=mp.log(2)/divisor;T=mp.exp(n*mp.log1p(mp.mpf(1)/(96*n)))
                An=n*(mp.log(n+1)+4);Q=(4*T-2)*An;Lc=mp.mpf(5)/4*T*mp.sqrt(n)
                J=int(mp.ceil(n*ell));N=J+1;q=J.bit_length()+1
                levels=[T+min(2*T*N/2**k,(Q*2**k/n+Lc)*ell)for k in range(q)]
                sqsum=sum(mp.sqrt(v)for v in levels)
                weighted=mp.e**2*sqsum**2;direct=mp.e**2*N*T;P=min(direct,weighted)
                g=1/(1-1/mp.sqrt(2));U=2*T*N;V=Q*ell/n;W=Lc*ell
                upper=q*mp.sqrt(T)+2*g*(U*V)**mp.mpf('.25')+q*mp.sqrt(W)
                assert sqsum<=upper
                rows.append({'n':n,'ell_divisor_of_log2':divisor,'J':J,'N':N,'q':q,'T':enc(T),'weighted_P':enc(weighted),'direct_P':enc(direct),'P':enc(P),'P_over_sqrt_n_log_nplus2_squared':enc(P/(mp.sqrt(n)*mp.log(n+2)**2)),'sqrt_D_sum':enc(sqsum),'analytic_sqrt_D_sum_upper':enc(upper),'scope':'Formula-only upper D_k evaluation; not an additional physical source or numerical proof of dimension order.'})
        return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md'));a=ap.parse_args()
    scal=scalar_cases();sources,values=source_cases();low=diagnostic(values,40);high=diagnostic(values,70);price40=formula_prices(40);price70=formula_prices(70)
    with mp.workdps(100):
        diffs=[abs(mp.mpf(x[k])-mp.mpf(y[k]))/max(1,abs(mp.mpf(y[k])))for x,y in zip(low,high)for k in x if k!='name'];diffs += [abs(mp.mpf(x[k])-mp.mpf(y[k]))/max(1,abs(mp.mpf(y[k])))for x,y in zip(price40,price70)for k in x if isinstance(x[k],str)and k!='scope'];difference=enc(max(diffs));assert max(diffs)<mp.mpf('1e-36')
    result={'schema':'R255-exact-Peano-majorants-v1','script_sha256':sha(__file__),'contract_sha256':sha(a.contract),'scope':'Exact finite positive convolution majorants and actual positive-volume L1 source energies; no FULL/history or general asymptotic certification. MP logarithmic prices are ordinary non-interval diagnostics.','counts':{'scalar_parameter_cases':len(scal),'signed_pointwise_majorant_certificates':sum(len(v['certificates'])for v in scal),'Bernstein_subinterval_certificates':sum(c['certified_subintervals']for v in scal for c in v['certificates']),'true_L1_source_models':len(sources),'source_window_checks':sum(v['windows']for v in sources),'precision_fields_compared':len(diffs),'formula_only_price_cases':len(price70)},'scalar_cases':scal,'source_models':sources,'mp40':low,'mp70':high,'formula_price_mp40':price40,'formula_price_mp70':price70,'precision_max_relative_difference':difference,'certificate_method':'On all H/triangle/CDF knots each residual is degree<=3; exact Fraction cubic Bernstein coefficients certify nonnegativity over whole closed subinterval, not point samples. Bisect only if coefficients need refinement. Both signs certify absolute majorization.','provenance':'Majorant formulas CT3 of coarse_source_transfer.md; self-contained profile/inner copied and generalized from R254. No external checkpoint runtime input.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'max_relative_difference':difference}))
if __name__=='__main__':main()
