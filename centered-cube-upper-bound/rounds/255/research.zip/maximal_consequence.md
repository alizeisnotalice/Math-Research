# R255: conditional coarse-scale maximal energy and original-source extraction

Every maximal estimate in this note is conditional on the single-window
input SW below. This note does not certify SW; the kernel author and
independent audit have that separate task. The fixed-scale comparison
and fractional-source algebra are already proved tools. No conclusion
here is an unconditional general weak-L1 theorem.

## MC1. Exact conditional input and physical smoothing length

Let n>=1, 0<a<=b<=2a, ell=log(b/a), and fix

    d=a/(8sqrt(n)), K_d=h_d*h_d,
    E_d(mu)=||h_d*mu||_2^2,
    T=(1+2d^2/(3a^2))^n=(1+1/(96n))^n<=96/95,
    A=n[log(n+1)+4], Q=(4T-2)A,
    L_c=10n(d/a)T=(5/4)T sqrt(n).

All cubes have full side R and h_R=R^-n 1_Q_R. The source mu is any
finite nonnegative L1 measure. The conditional hypothesis, uniformly
for every a<=s<=t<=b and delta=log(t/s), is

    ||(h_t-h_s)*mu||_2^2
                  <=min(2T,Q delta^2+L_c delta)E_d(mu). (SW)

In particular SW is required for every positive source, including any
fraction extracted later. It is not enough for SW to hold only for
one original source while being used without proof for its subsource.
The bound 2T follows separately from the proved fixed-scale comparison
E_R(mu)<=T E_d(mu), nonnegativity of h_R*mu, and the nonnegative cross
inner product. The second branch of SW is the unproved input here.

## MC2. Actual finite grid and each dyadic layer

Take J=ceil(n ell), N=J+1, R_j=min(b,a exp(j/n)), 0<=j<=J.
There are N<=3n nodes; for every R in [a,b] a common upward node
satisfies R_j/R<=exp(1/n). Positivity gives

    M_[a,b]mu<=e max_j h_Rj*mu.                         (MC1)

Write H_j=h_Rj*mu, form a_0=H_0 and a_j=H_j-H_{j-1}, and pad the
sequence by zero to length P=2^ceil(log2 N). The q=ceil(log2 N)+1
levels have lengths r_k=2^k, 0<=k<q. The first block at each level
equals H_min(r_k-1,J), hence has energy at most T E_d(mu).

The other nonzero blocks are increments on disjoint log-scale windows.
Their count is at most

    M_k=ceil(N/r_k)-1=floor((N-1)/r_k)<=N/r_k.

The last partly padded block remains a single increment. A block
starting at index v>=r_k has end w=min(v+r_k-1,J) and log-window
length delta_B=log(R_w/R_{v-1})<=r_k/n. The sum of these lengths on
one level is at most ell. Consequently the exact finite computable
conditional layer price is

    D_k^exact=T+sum_{other blocks B}
                               min(2T,Q delta_B^2+L_c delta_B),
    sum_blocks ||block||_2^2<=D_k^exact E_d(mu).        (MC2)

A convenient source-independent upper bound is

    D_k^exact<=D_k
       :=T+min(2TN/r_k,(Q r_k/n+L_c)ell).             (MC3)

Both the cap and the sum in MC2 retain all windows. A source is not
recropped or independently optimized for different blocks.

## MC3. Optimal scalar layer weights and an explicit logarithmic price

Every prefix H_j contains at most one dyadic block from each level.
For fixed positive scalar weights w_k, weighted Cauchy gives

    ||max_j H_j||_2^2
          <=(sum_k w_k)(sum_k D_k^exact/w_k)E_d(mu).

The optimal value of this scalar bound is (sum sqrt(D_k^exact))^2,
attained by w_k=sqrt(D_k^exact). This is optimal within this weighted
Cauchy certificate, not a claim of the best possible maximal operator
constant. The direct finite-node estimate is N T E_d(mu). Define

    C_{n,ell}=e^2 min(NT,(sum_k sqrt(D_k^exact))^2).

The full conditional maximal consequence is

    ||M_[a,b]mu||_2^2<=C_{n,ell}E_d(mu).              (MC4)

Thus all constants can be evaluated from n and ell without knowing
the source or a receiver. If ell=0, the only node is R=a and the
stronger direct fixed-scale constant T may replace e^2 T.

For a closed upper price put

    U=2TN, V=Q ell/n, W=L_c ell,
    g=(1-2^(-1/2))^-1.

The elementary inequality min(x,y+z)<=min(x,y)+min(x,z) and square
root subadditivity give

    sum_k sqrt(D_k)
       <=q sqrt(T)+2g(UV)^(1/4)+P_q(U,W),
    P_q(U,W)=sum_{k=0}^{q-1}sqrt(min(U2^-k,W)).        (MC5)

For W=0 put P_q=0. For W>0 an explicit bound retaining its plateau
length is

    P_q(U,W)<=min(q sqrt(W),g sqrt(U),
                 [g+1+log_+(U/W)/log2]sqrt(W)).       (MC6)

To prove MC5 split the quadratic geometric sum at r=sqrt(U/V); the
two sides each cost at most g(UV)^(1/4). If V=0 this term is zero.
For MC6, levels with 2^k<=U/W contribute sqrt(W); beyond that point
the terms decrease geometrically. There are at most
1+log_+(U/W)/log2 plateau levels. The other two bounds in MC6 follow
by dropping one branch of the minimum. No threshold menu or level
count is suppressed.

In particular one may simply use

    C_{n,ell}<=e^2 min{NT,
      [q sqrt(T)+2g(2TN(4T-2)A ell/n)^(1/4)
                                     +q sqrt((5/4)T sqrt(n)ell)]^2}.
                                                               (MC7)

Since N<=3n, T<=96/95, ell<=log2 and q=O(log(n+2)), this is
O(sqrt(n)log^2(n+2)). The linear delta term contributes O(sqrt(n))
to every level and therefore cannot be called a free root price:
its accumulated prefix cost includes the displayed squared logarithm.
MC2/MC5/MC6 can be appreciably smaller for a specified finite grid.

## MC4. Original-source fraction with the exact conditional price

Let lambda>0 and choose any tau>0. Define p=K_d*mu. This is a bounded
continuous nonnegative function, with p<=d^-n||mu||. Put

    theta(y)=min(1,tau/p(y)) when p(y)>0,
    theta(y)=1 when p(y)=0,
    sigma=theta mu, rho=(1-theta)mu.

The source fraction is measurable and fixed before the receiver
integral. It is independent of a later grid shift or dyadic block.
Its exact energy certificate follows by symmetry:

    E_d(sigma)<=integral theta^2 p dmu
                                 <=tau||sigma||.      (MC8)

All these are original positive source components, with mu=sigma+rho.
If zeta<=mu, the same theta has E_d(theta zeta)<=tau||theta zeta||,
since K_d*zeta<=p. Thus a common fraction computed from beta can be
applied to the actual nu<=beta without losing pointwise coupling or
the source-specific energy certificates.

Conditional on SW for these sources, MC4 and scalar Young give for
any finite receiver E, X=lambda|E|, epsilon>0,

    integral_E (h_{R(x)}*sigma)(x)dx
       <=epsilon X+C_{n,ell}tau||sigma||/(4epsilon lambda),
    integral_E (h_{R(x)}*mu)(x)dx
       <=epsilon X+C_{n,ell}tau||sigma||/(4epsilon lambda)
                           +integral_E(h_{R(x)}*rho)(x)dx.       (MC9)

Here R(x) is one common measurable receiver scale in [a,b], not a
separately selected R(x,y) for each source point. No all-R receiver
cap is needed for Young's inequality; an original cap is not spent
as an unproved bound on the residual.

The explicit root-normalized choice is

    tau_root=lambda sqrt(n)/C_{n,ell}.

It yields the actual partial-source fee

    epsilon X+sqrt(n)||sigma||/(4epsilon)             (MC10)

plus exactly the same residual term as MC9. On a full octave the
proved upper price MC7 implies that tau_root is at least a constant
times lambda/log^2(n+2); this lower threshold statement is conditional
on SW. It does not say that the entire original source has potential
below that threshold. Alternatively tau=lambda/T gives its own
explicitly chosen fraction, with the honest fee
C_{n,ell}||sigma||/(4epsilon T)=O(sqrt(n)log^2(n+2))||sigma||/epsilon.
There is no assertion that tau=lambda/T always exceeds tau_root for
every short or degenerate octave; their exact values decide the order.

## MC5. Actual low-potential qualification and the surviving high source

Since K_d is supported on Q_{2d} and bounded by d^-n,

    p(y)<=d^-n mu(Q_{2d}(y)).

Full retention is therefore certified on the actual local-mass set

    mu(Q_{2d}(y))<=tau_root d^n
             =lambda sqrt(n)d^n/C_{n,ell}.           (MC11)

Arbitrarily high densities of sufficiently small total local mass
can satisfy MC11. No source density cap or rank has been assumed.
Outside that set the fraction is still valid and may be nonzero;
that is a paid partial extraction, not payment of the complete high
source. In full generality its remaining mass is exactly

    ||rho||=integral_{p>tau}(1-tau/p)dmu
       =integral_tau^infinity (tau/t^2)mu{p>t}dt.     (MC12)

There is no original bound here that makes MC12 small. An independent
certificate E_d(rho)<=tau_root||rho|| would pay that whole residual
by MC4, but that certificate is not inferred from its name, the
original receiver cap, or the low-potential extraction.

For comparison R254 used d_0=a/(8n^(3/4)) and a different maximal
coefficient C_0=O(sqrt(n log(n+2))). Its valid estimate involves
E_d0(mu), whereas MC4 involves the coarser E_d(mu). One may compare
the two actual products or use legitimate sequential residual
extractions with their full aggregation costs. One may not take the
better constant from one and the coarser source energy from the other.
If both fractions are root normalized, their local-mass thresholds
have the exact scalar ratio n^(n/4)C_0/C_{n,ell}; the neighborhoods
Q_{2d} and Q_{2d0} also differ, so this is not a universal inclusion
of the corresponding source classes.

## MC6. Original traffic prefactors and source ledger

The statements above act on an already authorized common-scale hard
response. If an original positive traffic slot is bounded by
C_dom integral_E(h_{R(x)}*mu)(x)dx, with its authentic C_dom>0, choose
the internal Young error epsilon/C_dom. Its valid conclusion is

    traffic<=epsilon X
        +C_dom^2 C_{n,ell}tau||sigma||/(4epsilon lambda)
        +C_dom integral_E(h_{R(x)}*rho)(x)dx.          (MC13)

The square C_dom^2 is not dropped. No new positive domination of a
double-posterior traffic is asserted by MC13. The original full
posterior is not rebuilt from sigma, sources are not moved or made
uniform, and old negative credits are untouched. Summing over parent
histories, seeds or source groups still requires the original mass
ledger and compatible receiver-error shares. Conditional MC10 alone
does not certify general weak-type closure.

## MC7. Bounded actual bookkeeping check

The following local Python code was actually run with mpmath 1.3.0
at 60 decimal digits and exact Fraction log-grid lengths. It returned

    PASS 24 conditional bookkeeping cases; 97 levels;
    8425 exact-count increment blocks.

Dimensions were 1,2,16,64,512,4096 and octave log lengths were
0,1/100,1/5,69/100. It checked the last partial-block counts and exact
length constraints, D_k^exact<=D_k, both geometric sums including the
linear plateau, and the cancellation C tau_root=sqrt(n) at lambda=1.
The largest sampled C/[sqrt(n)log^2(n+2)] was
12.371733479546620326. This is finite arithmetic evidence, not a
dimension-order proof, directed interval certificate, or proof of SW.

```python
from fractions import Fraction as F
import mpmath as m
m.mp.dps=60
conv=lambda x:m.mpf(x.numerator)/x.denominator
g=1/(1-1/m.sqrt(2))
count=levels=blocks=0
maxnorm=m.mpf(0)
for n in [1,2,16,64,512,4096]:
 for ell in [F(0),F(1,100),F(1,5),F(69,100)]:
  J=(n*ell.numerator+ell.denominator-1)//ell.denominator
  N=J+1; q=(N-1).bit_length()+1
  T=(1+1/(96*m.mpf(n)))**n
  Q=(4*T-2)*n*(m.log(n+1)+4)
  Lc=m.mpf(5)/4*T*m.sqrt(n)
  x=[min(ell,F(j,n)) for j in range(N)]
  exact=[]; upper=[]
  for k in range(q):
   r=2**k; ds=[]
   for start in range(r,N,r):
    end=min(start+r-1,J)
    ds.append(x[end]-x[start-1])
   assert len(ds)==(N-1)//r and len(ds)*r<=N
   assert sum(ds,F(0))<=ell and all(0<=z<=F(r,n) for z in ds)
   price=T+sum(min(2*T,Q*conv(z)**2+Lc*conv(z)) for z in ds)
   cap=T+min(2*T*N/r,(Q*r/n+Lc)*conv(ell))
   assert price<=cap+m.mpf('1e-50')
   exact.append(price); upper.append(cap)
   levels+=1; blocks+=len(ds)
  U=2*T*N; V=Q*conv(ell)/n; W=Lc*conv(ell)
  P=sum(m.sqrt(min(U/(2**k),W)) for k in range(q))
  if W:
   Pbound=min(q*m.sqrt(W),g*m.sqrt(U),
       (g+1+max(0,m.log(U/W))/m.log(2))*m.sqrt(W))
  else:
   Pbound=m.mpf(0)
  assert P<=Pbound+m.mpf('1e-50')
  closed=q*m.sqrt(T)+2*g*(U*V)**m.mpf('.25')+Pbound
  assert sum(m.sqrt(z) for z in exact)<=sum(m.sqrt(z) for z in upper)+m.mpf('1e-50')
  assert sum(m.sqrt(z) for z in upper)<=closed+m.mpf('1e-50')
  C=m.e**2*min(N*T,sum(m.sqrt(z) for z in exact)**2)
  tau=m.sqrt(n)/C
  assert abs(C*tau-m.sqrt(n))<m.mpf('1e-50')
  assert T<=m.mpf(96)/95
  maxnorm=max(maxnorm,C/(m.sqrt(n)*m.log(n+2)**2))
  count+=1
print('PASS',count,'conditional bookkeeping cases;',levels,'levels;',
      blocks,'exact-count increment blocks')
print('max C/[sqrt(n)log(n+2)^2]',m.nstr(maxnorm,20))
```
