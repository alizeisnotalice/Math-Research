# 第255轮合同：粗尺度来源能量的共同中点消项

本轮延续R254，目标仍为任意非负L1输入的一般中心立方体弱型根阶上界；本轮不将能量界冒充该目标。

## 准确本轮命题
令 h_R=R^{-n}1_{[-R/2,R/2]^n}、K_R=h_R*h_R、E_d(μ)=||h_d*μ||_2²。对于非负有限L1来源μ、任意不交尺度窗[s_j,t_j]⊂[a,2a]、d=a/(8√n)，证明窗数无关的 Σ_j||(h_tj−h_sj)*μ||²≤C√(n log(n+2))E_d(μ)。同时推导连续octave最大函数能量界、原来源部分的线性质量付款，并明确高来源残余。

## 允许工具与边界
R254已独审的signed Peano恒等式、任意来源K_d平移配对≤E_d、真实pair kernel的A_n δ²估计及有限加权dyadic前缀分解。不得假定一般来源乘积独立、μ∈L2、窗口数有限于n、正部可自由微分，或把高能量残余删除。反例筛查仅服务命题审核，不替代构造新估计。

## 分工与交付
Astra /r217_peak：coarse_source_transfer.md，正测度majorant及active共同中点分解。
Sol /r217_compare：maximal_consequence.md，以上新命题成立条件下的最大界、真实来源分解与费用。
Sol /r217_audit：audit.md，先独立审命题再读作者，核验量词、符号、全部误差及回代。
Sol /r217_numeric：numeric_checks.py/json、numeric_notes.md，精确核验和三阶段参数范围。
主代理：合同、LaTeX证明、报告、复现脚本及打包提交。所有人仅写获分配文件，无git操作及PDF编译；无独立任务不启动其余Agent。

## 成功与停止边界
本轮成功须新一般能量界有完整证明和独审；若失败，记载准确缺口。一般弱型闭合还需所有真实高来源、尺度与历史费用付款。有限计算不得认证一般引理。逐轮单独提交与推送，只收本轮文件；当前基线c60401931ae0c5043f4bff8dfcd2ee35a5e97ec6。

## 本机工具与技能
按用户偏好运行本机Python。应用已重新读取的math-l03-rational-and-interval-certificates技能：Fraction证书与普通高精度严格分开，不声称通用向外舍入API得到验证。模型实际扣额数据不可得，不估计成本比例。
