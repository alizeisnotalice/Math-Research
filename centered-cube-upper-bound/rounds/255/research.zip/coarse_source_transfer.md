# R255：共同中点抵消与任意正来源的粗尺度传递

## CT1　主定理

设 \(n\ge1\)，\(0<a\le b\le2a\)，\(0<d\le a\)。记完整边长归一核
\[
 h_R=R^{-n}1_{[-R/2,R/2]^n},\quad
 K_d=h_d*h_d,\quad E_d(\mu)=\|h_d*\mu\|_2^2,
\]
\[
 c=\frac{2d^2}{3a^2},\quad T=(1+c)^n,\quad
 A_n=n[\log(n+1)+4].
\]
对任意非负有限 \(L^1\) 来源 \(\mu\)，以及任意有限组内部互不相交的区间 \([s_j,t_j]\subset[a,b]\)，有
\[
 \boxed{
 \sum_j\|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le \log(b/a)
 \left[\sqrt{2T(4T-2)A_n}+10n(d/a)T\right]E_d(\mu).
 }\tag{CT1.1}
\]
特别取原目标粗尺度 \(d=a/(8\sqrt n)\)，则 \(T\le e^{1/96}\)，并得到
\[
 \boxed{
 \sum_j\|(h_{t_j}-h_{s_j})*\mu\|_2^2
 \le4e^{1/96}\log(b/a)
       \sqrt{n[\log(n+1)+4]}\,E_d(\mu).
 }\tag{CT1.2}
\]
窗数完全不出现在费用中；短窗、长窗和相接端点均涵盖。\(a=b\) 或零长度窗时对应项为零。来源在胞内或任意小尺度上可以浓缩；没有改源、删 posterior 槽、增加密度或 rank 假设。

这支付了 R254 留下的“任意正 \(L^1\) 来源、粗平滑尺度、任意不交窗”平方增量问题。它不单独证明原 full weak-\(L^1\) 目标：右侧仍是真实 \(E_d(\mu)\)，全来源能量或抽取后的余来源账须另外结算。

## CT2　已证输入与正卷积证书

本稿使用 R254 的精确 signed Peano 展开及共同重叠核估计。为避免符号混淆，以下一维三角核写为 \(k_R(x)=(R-|x|)_+/R^2\)，而 \(K_R=k_R^{\otimes n}\)。对
\[
 B_{s,t}^{(q)}=k_s^{\otimes q}+k_t^{\otimes q}
                  -2c_{s,t}^{\otimes q},
 \qquad c_{s,t}=(h_s*h_t)_{\rm one\ dimension},
\]
R254 已证（令 \(\delta=\log(t/s)\le\log2\)）
\[
 \|(B_{s,t}^{(q)})_+\|_1\le2A_q\delta^2,
 \qquad\|B_{s,t}^{(q)}\|_1\le4A_q\delta^2,
 \quad A_q=q[\log(q+1)+4].\tag{CT2.1}
\]
另约定 \(B_{s,t}^{(0)}=0\)、\(A_0=0\)。本稿始终保留同一组 \(s,t\) 和同一对实际来源，不独立选择坐标尺度。

称一维函数 \(F\) 有质量 \(M\) 的正卷积证书，是指存在正有限测度 \(\Gamma\)，使
\[
 |F|\le k_d*\Gamma,\qquad\|\Gamma\|\le M.
\]
高维时把 \(k_d\) 换成对应维数的张量核。证书可相加、平移、张量化；质量分别相加或相乘。它不是来源预算的重新命名，因为下列同源传递直接支付其全部质量：
\[
 \iint(K_d*\Gamma)(y-z)\,d\mu(y)d\mu(z)
 \le\|\Gamma\|E_d(\mu).\tag{CT2.2}
\]
证明：Tonelli 将左边写为
\(\int\langle h_d*\mu,\operatorname{translation}_u(h_d*\mu)\rangle d\Gamma(u)\)，再用 Cauchy。对任意有限正来源，此能量有限；无需来源本身属于 \(L^2\)。

## CT3　近邻原子必须先相减

令
\[
 H(x)=\frac{(d-|x|)_+^3}{6d^2}.
\]
已有精确分布恒等式 \(H''=k_d-\delta_0\)，并且
\[
 0\le H\le\frac{d^2}{6}k_d,\qquad
 |H'|=\frac{(d-|x|)_+^2}{2d^2}\le\frac d2 k_d.
\]
因此任意 \(u,v\in\mathbb R\) 有
\[
 |H(x-u)-H(x-v)|
 \le\frac d2\int_{[\min(u,v),\max(u,v)]}k_d(x-r)dr.\tag{CT3.1}
\]
其正证书质量为 \((d/2)|u-v|\)，而不是分别对两个原子支付 \(d^2/3\)。\(H\) 绝对连续，故该平移基本公式合法；\(H'\) 在零点的跳跃不妨碍它。

记
\[
 a_R=H*\partial_x^2k_R
 =R^{-2}[H(\cdot+R)-2H+H(\cdot-R)].
\]
每个 \(a_R\)，\(R\in[a,b]\)，有质量至多
\(4(d^2/6)/R^2\le c\) 的证书。

对一个窗，置 \(m=(s+t)/2\)、\(h=(t-s)/2\)。由 \(t\le2a\) 及 \(t-s\le t\log(t/s)\)，有
\[
 h\le a\delta.\tag{CT3.2}
\]
对 \(R=s\) 或 \(t\)，先分离系数变化及端点平移：
\[
 a_R-a_m=(R^{-2}-m^{-2})[H(\cdot+R)-2H+H(\cdot-R)]
 +m^{-2}[H(\cdot+R)-H(\cdot+m)
                 +H(\cdot-R)-H(\cdot-m)].
\]
使用 \(|R^{-2}-m^{-2}|\le2h/a^3\) 和 CT3.1，其证书质量不超过
\[
 \frac{4d^2h}{3a^3}+\frac{dh}{a^2}
 \le\left[\frac43(d/a)^2+d/a\right]\delta
 \le3(d/a)\delta.\tag{CT3.3}
\]
最后只用了 \(d\le a\)。

对真实 mixed overlap，令 \(a_{s,t}=H*\partial_x^2c_{s,t}\)。空间二阶导数是
\[
 \partial_x^2c_{s,t}=(st)^{-1}
     (\delta_{-m}-\delta_{-h}-\delta_h+\delta_m).
\]
故 \(a_{s,t}\) 也有质量至多 \(c\) 的证书。令
\(S_m=H(\cdot+m)-2H+H(\cdot-m)\)、
\(D_h=H(\cdot+h)-2H+H(\cdot-h)\)，则
\[
 a_{s,t}-a_m=((st)^{-1}-m^{-2})S_m-(st)^{-1}D_h.
\]
因 \((st)^{-1}-m^{-2}=h^2/(st m^2)\)，两项的证书总质量至多
\[
 \frac{2d^2h^2}{3st m^2}+\frac{dh}{st}
 \le\frac23(d/a)^2\delta^2+(d/a)\delta
 \le2(d/a)\delta.\tag{CT3.4}
\]
这里保留了 \(-2\delta_0\) 与 \(-\delta_{-h}-\delta_h\) 的近邻抵消；最后使用 \(\delta\le\log2<1\)。

## CT4　张量中点分解：不产生 \(n\delta\) 的普通因子费用

Peano 算子记为 \(P=k_d*\)、\(L=H*\partial_x^2\)，则 \(I=P-L\)。对
\(B=B_{s,t}^{(n)}\) 在各坐标张量展开：
\[
 B=K_d*B+\sum_{\varnothing\ne S\subset[n]}(-1)^{|S|}E_S.
\]
若 \(k=|S|\)、\(l=n-k\)，在不影响记号的坐标排列下，
\[
 E_S=k_d^{\otimes l}*_{S^c}
 [a_s^{\otimes k}\otimes k_s^{\otimes l}
  +a_t^{\otimes k}\otimes k_t^{\otimes l}
  -2a_{s,t}^{\otimes k}\otimes c_{s,t}^{\otimes l}].\tag{CT4.1}
\]
只冻结含 \(H\) 的 \(k\) 个坐标因子，精确写成
\[
 \begin{aligned}
 [&a_s^{\otimes k}-a_m^{\otimes k}]\otimes k_s^{\otimes l}
 +[a_t^{\otimes k}-a_m^{\otimes k}]\otimes k_t^{\otimes l}\\
 &-2[a_{s,t}^{\otimes k}-a_m^{\otimes k}]\otimes c_{s,t}^{\otimes l}
 +a_m^{\otimes k}\otimes B_{s,t}^{(l)}.\tag{CT4.2}
 \end{aligned}
\]
前三项通过张量 telescoping 及 CT3.3–4，各普通因子仍是概率密度，证书总质量至多
\[
 (3+3+2\cdot2)k c^{k-1}(d/a)\delta
 =10k c^{k-1}(d/a)\delta.
\]
最后一项用 \(a_m\) 的证书以及真实 \(l\) 维共同重叠核的绝对值，质量为
\(c^k\|B_{s,t}^{(l)}\|_1\)。外面的 \(k_d^{\otimes l}\) 已在 CT4.1 中，所有坐标的平滑核都完整保留。因此存在正有限 \(\Gamma_S\) 满足
\[
 |E_S|\le K_d*\Gamma_S,
\qquad
 \|\Gamma_S\|\le10k c^{k-1}(d/a)\delta
                   +c^k\|B_{s,t}^{(l)}\|_1.\tag{CT4.3}
\]
关键是最后 \(l\) 个坐标保留整个 \(B^{(l)}\)；没有将其三个概率张量分别作一阶 total variation 比较。因此不会重新引入未偿还的 \(n\delta\) 因子。

## CT5　单窗正证书及无窗数求和

主项 \(K_d*B\le K_d*B_+\)。对所有非空 \(S\) 求和，利用
\[
 \sum_{k=1}^n\binom nk k c^{k-1}=n(1+c)^{n-1},\qquad
 \sum_{k=1}^n\binom nk c^k=T-1,
\]
以及 \(A_l\le A_n\)，得到正测度 \(\Gamma_{s,t}\)，使
\[
 B_{s,t}^{(n)}\le K_d*\Gamma_{s,t},
\]
\[
 \|\Gamma_{s,t}\|
 \le(4T-2)A_n\delta^2+10n(d/a)T\delta.\tag{CT5.1}
\]
其中二次项是 \(2A_n\delta^2+4A_n(T-1)\delta^2\)。符号展开的各项只在 CT4.2 的真实抵消之后才取绝对值。

由 CT2.2，CT5.1 是任意正来源的实际平方增量上界。另有同一来源的独立备选
\[
 \|(h_t-h_s)*\mu\|_2^2\le2T E_d(\mu).\tag{CT5.2}
\]
证明：对单个 \(K_R\) 的同一 Peano 展开，\(\|\partial^{2S}K_R\|_{TV}=(4/R^2)^{|S|}\)，得到 \(E(R)\le(1+2d^2/(3R^2))^nE_d\le TE_d\)。两正响应的 cross 内积非负，所以平方差至多 \(E(s)+E(t)\)。

令 \(Q=(4T-2)A_n\)、\(L=10n(d/a)T\)。对每个窗，将两合法价取小者，且
\[
 \min\{2T,Q\delta^2+L\delta\}
 \le\min\{2T,Q\delta^2\}+L\delta
 \le(\sqrt{2TQ}+L)\delta.
\]
不交窗满足 \(\sum_j\delta_j\le\log(b/a)\)，由此完整证明 CT1.1。没有按窗重新分配来源，也没有留下 \(M(T-1)\) 型费用。

当 \(d=a/(8\sqrt n)\)，有 \(c=1/(96n)\)、\(T\le e^{1/96}\)、\(A_n\ge4n\)。因
\[
 \sqrt{2T(4T-2)A_n}\le\sqrt8\,T\sqrt{A_n},
\quad
 10n(d/a)T=\tfrac54T\sqrt n\le\tfrac58T\sqrt{A_n},
\]
且 \(\sqrt8+5/8<4\)，得 CT1.2 的绝对常数。更精确常数可保留 CT1.1；本稿不优化它。

## CT6　接回范围与尚余来源账

CT1.2 涵盖任意有限窗数，特别涵盖实际尺度网格的所有 dyadic block 区间。因此 R252/R254 的有限 prefix 分解可在同一个粗尺度 \(d=a/(8\sqrt n)\) 上使用；不需要缩到 \(a/(8n^{3/4})\) 来补偿窗数。单个初始 prefix 的固定尺度能量按 CT5.2 支付。任何进一步最大值估计仍须保相应 prefix 常数和合法连续尺度上取整费用，不在此将它们删除。

这个结论不要求或改变真实接收域 \(E\)、原 β/ν 的后验、FIRST、cut 或来源秩；它先对每个原正来源本身成立。若将其用于原交通，应按实际来源把右侧平滑能量结算。对所有一般输入的 weak-\(L^1\) 根阶目标，来源能量仍需连续抽取或其它已认证预算；这里没有声称该全局目标已经完成。

依赖仅为 R254 已证 Peano/source-Cauchy 接口、R254 二阶共同重叠核估计，以及本稿 CT3–5 的近邻原子/共同中点抵消。未使用新的 source density 假设或未消费的负信用。
