"""R769 true low-price hard-pair refresh and independently checked halo volumes."""

import argparse
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, factorial
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(y,r):
    return y-r,y+r


def intersect(*intervals):
    return max(lo for lo,hi in intervals),min(hi for lo,hi in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def inside(I,x):
    return I[0]<=x<=I[1]


def atomic_row_marks(A,centers,s,a,v,weights,rows,eta):
    labels = range(len(A))
    u = Q(13,20)  # These two expanded target intervals touch in the first source parent.
    H = [interval(y,(1+u)*r) for y,r in zip(centers,s)]
    p = (Q(1),Q(2,3),Q(3,4),Q(1,2))
    q = (Q(1,2),Q(2,3),Q(1),Q(1))
    assert all(0<=z<=1 for z in (*p,*q))

    def row_value(i,x):
        return sum(q[j]*weights[i,j] for j in labels if inside(H[j],x))

    def row_winner(i,closed,open_reps):
        winner = max([*closed,*open_reps],key=lambda x:row_value(i,x))
        return winner,row_value(i,winner),max(row_value(i,x) for x in open_reps)

    def column_receipts(winners):
        points,maxima,open_maxima = map(list,zip(*winners))
        columns = []
        tally = []
        for j in labels:
            mark = sum(p[i]*q[j]*weights[i,j] for i in labels if inside(H[j],points[i]))
            own_nu = sum(p[i]*v[i] for i in labels if inside(H[j],points[i]))
            selected_D = sum(weights[i,j] for i in labels)
            assert mark<=eta*q[j]*a[j]*own_nu
            assert mark<=q[j]*selected_D<=q[j]*rows[j]
            columns.append([j,str(mark),str(own_nu),str(eta*q[j]*a[j]*own_nu),str(q[j]*rows[j])])
            tally.append(mark)
        total = sum(tally)
        assert all(mark>0 for mark in tally) and total==sum(p[i]*maxima[i] for i in labels)
        return {
            "winning_points_zeta":list(map(str,points)),"row_sup":list(map(str,maxima)),
            "open_piece_row_sup":list(map(str,open_maxima)),"total_raw_mark":str(total),
            "true_columns_j_mark_nu_halo_etaqa_bound_qD_bound":columns,
        }

    restricted = []
    for i in labels:
        cuts = sorted({*A[i]}|{x for box in H for x in box if inside(A[i],x)})
        midpoints = [(x+y)/2 for x,y in zip(cuts,cuts[1:])]
        candidate = row_winner(i,cuts,midpoints)
        assert inside(A[i],candidate[0]) and candidate[1]>0
        restricted.append(candidate)
    assert restricted[0][0]==Q(-11,10) and restricted[0][1]>restricted[0][2]

    # Every open cell between successive halo endpoints has constant membership.
    # The two rays have no halo membership, but remain part of the full domain.
    closed = sorted({x for box in H for x in box})
    tails = [closed[0]-1,closed[-1]+1]
    open_reps = [(x+y)/2 for x,y in zip(closed,closed[1:])] + tails
    assert all(not inside(box,x) for box,x in product(H,tails))
    full = [row_winner(i,closed,open_reps) for i in labels]
    assert all(full[i][1]>=restricted[i][1] for i in labels)
    assert full[0][0]==Q(-11,10) and full[0][1]>full[0][2]
    assert full[3][0]==Q(-11,10) and not inside(A[3],full[3][0])
    assert [winner[1] for winner in full]==[winner[1] for winner in restricted]
    return {
        "eta":str(eta),"halo_u_for_boundary_pressure":str(u),
        "p":list(map(str,p)),"q":list(map(str,q)),
        "restricted_domain":"each source parent A_i",
        **column_receipts(restricted),
        "whole_real_line": {
            **column_receipts(full),
            "halo_endpoints":list(map(str,closed)),
            "all_open_cell_representatives":list(map(str,open_reps)),
            "left_and_right_unbounded_open_representatives":list(map(str,tails)),
        },
    }


def priced_halo():
    centers = (Q(-1),Q(11,8),Q(-11,4),Q(31,8))
    s = (Q(1),Q(3,2),Q(1),Q(9,8))
    u = Q(1,2)
    A = [interval(y,r) for y,r in zip(centers,s)]
    owners = [interval(y,r/32) for y,r in zip(centers,s)]
    halo = [interval(y,(1+u)*r) for y,r in zip(centers,s)]
    labels = range(len(A))
    assert all(1<=r<2 for r in s)
    assert all(length(intersect(I,J))==0 for I,J in combinations(owners,2))
    density = [((Q(-5),Q(6)),Q(1)),((Q(-1,8),Q(0)),Q(3)),
               ((Q(-15,8),Q(-7,4)),Q(2)),((Q(11,4),Q(23,8)),Q(1)),
               ((Q(-3,2),Q(-1)),Q(1))]

    def mu(I):
        return sum(lam*length(intersect(I,P)) for P,lam in density)

    m = list(map(mu,A))
    v = list(map(length,owners))
    assert all(mj>length(I) for mj,I in zip(m,A)) and all(w>0 for w in v)
    a = [vi/mi for vi,mi in zip(v,m)]
    gates_minus = (Q(1),Q(3,4),Q(1,2),Q(1))
    gates_plus = (Q(1,2),Q(1),Q(1,2),Q(2,3))

    def phi(x,i):
        gate = gates_minus[i] if x<0 else gates_plus[i]
        return a[i]*gate if inside(A[i],x) else Q(0)

    nodes = sorted({Q(0)}|{x for I in [*A,*halo,*[P for P,w in density]] for x in I})
    cells = [((lo+hi)/2,mu((lo,hi))) for lo,hi in zip(nodes,nodes[1:])]
    reps = nodes+[x for x,w in cells]+[nodes[0]-1,nodes[-1]+1]
    row_sup = max(sum(phi(x,i) for i in labels) for x in reps)
    assert all(0<=phi(x,i)<=a[i]*inside(A[i],x) for x,i in product(reps,labels))
    pairs = tuple(product(labels,repeat=2))
    Qij = {(i,j):sum(w*phi(x,i)*phi(x,j) for x,w in cells) for i,j in pairs}
    overlaps = {(i,j):mu(intersect(A[i],A[j])) for i,j in pairs}
    for i,j in pairs:
        I = intersect(A[i],A[j])
        direct = a[i]*a[j]*(gates_minus[i]*gates_minus[j]*mu(intersect(I,(Q(-5),Q(0))))
                            +gates_plus[i]*gates_plus[j]*mu(intersect(I,(Q(0),Q(6)))))
        assert Qij[i,j]==Qij[j,i]==direct<=a[i]*a[j]*overlaps[i,j]
    rows = [sum(Qij[i,j] for i in labels) for j in labels]
    assert all(D<=v[j]*row_sup for j,D in enumerate(rows))

    categories = ("inner","shell","deep")

    def category(j,x):
        return 0 if inside(A[j],x) else (1 if inside(halo[j],x) else 2)

    hard = [(i,j) for i,j in pairs if 0<length(intersect(A[i],A[j]))<overlaps[i,j]]
    result = []
    atomic = None
    for eta in (Q(1,8),Q(1,6),Q(1,4)):
        selected = {(i,j) for i,j in hard if 0<overlaps[i,j]<=eta*min(m[i],m[j])}
        assert selected and all(i!=j and Qij[i,j]>0 and (j,i) in selected for i,j in selected)
        weights = {(i,j):Qij[i,j] if (i,j) in selected else Q(0) for i,j in pairs}
        total = sum(weights.values())
        if eta==Q(1,4):
            atomic = atomic_row_marks(A,centers,s,a,v,weights,rows,eta)

        def T(j,x):
            return sum(weights[i,j]/m[i] for i in labels if inside(A[i],x))

        by_row = []
        scalar_cap = Q(0)
        exact_halo_tally = Q(0)
        cell_categories = [Q(0)]*3
        for j in labels:
            D = sum(weights[i,j] for i in labels)
            assert sum(w*T(j,x) for x,w in cells)==D<=rows[j]<=v[j]*row_sup
            assert all(T(j,x)<=eta*a[j]*sum(a[i] for i in labels if inside(A[i],x)) for x in reps)
            weighted = sum(w*T(j,x) for x,w in cells if inside(halo[j],x))
            exact_halo_tally += weighted
            scalar_cap += eta*a[j]*sum(w*sum(a[i] for i in labels if inside(A[i],x))
                                        for x,w in cells if inside(halo[j],x))
            by_row.append([j,str(D),str(weighted)])
            for x,w in cells:
                cell_categories[category(j,x)] += w*T(j,x)
        assert sum(cell_categories)==total and all(x>0 for x in cell_categories)

        K = {}
        scalar_wrong_denominator = Q(0)
        actual_pairs = []
        for i,j in sorted(selected):
            prob_inner = overlaps[i,j]/m[i]
            prob_hit = mu(intersect(A[i],halo[j]))/m[i]
            K[i,j] = (prob_inner,prob_hit-prob_inner,1-prob_hit)
            assert all(x>0 for x in K[i,j]) and sum(K[i,j])==1
            assert prob_inner<=eta and weights[i,j]*prob_hit<=eta*a[i]*a[j]*mu(intersect(A[i],halo[j]))
            scalar_wrong_denominator += weights[i,j]*mu(intersect(A[i],halo[j]))/m[j]
            actual_pairs.append([i,j,str(weights[i,j]),str(prob_hit),str(prob_inner)])
        direct_categories = [sum(weights[i,j]*K[i,j][c] for i,j in selected) for c in range(3)]
        assert direct_categories==cell_categories
        assert sum(direct_categories[:2])==exact_halo_tally<=scalar_cap
        assert scalar_wrong_denominator!=exact_halo_tally
        independent = [[Q(0)]*3 for _ in range(3)]
        for i,j in sorted(selected):
            for (x,wx),(y,wy) in product(cells,repeat=2):
                if inside(A[i],x) and inside(A[j],y):
                    independent[category(j,x)][category(i,y)]+=weights[i,j]*wx/m[i]*wy/m[j]
        assert independent==[[sum(weights[i,j]*K[i,j][c]*K[j,i][d] for i,j in selected)
                              for d in range(3)] for c in range(3)]
        assert sum(map(sum,independent))==total and all(x>0 for row in independent for x in row)
        assert any(K[i,j]!=K[j,i] for i,j in selected)
        result.append({
            "eta_finite":str(eta),"hard_pairs_ordered":len(selected),"total_Q":str(total),
            "rows_j_Q_and_halo_integral":by_row,"sitewise_scalar_upper":str(scalar_cap),
            "actual_one_direction_halo":str(exact_halo_tally),
            "using_target_instead_of_source_m":str(scalar_wrong_denominator),
            "categories":categories,"one_direction_split_normalized":list(map(str,(m/total for m in direct_categories))),
            "independent_two_direction_modes_normalized":[[str(x/total) for x in row] for row in independent],
            "actual_pair_i_j_Q_K_and_inner_fraction":actual_pairs,
        })
    assert [row["hard_pairs_ordered"] for row in result]==[2,4,6]
    return {"physical_half_sides":list(map(str,s)),"mu_m":list(map(str,m)),"v":list(map(str,v)),
            "d":list(map(str,map(length,A))),"halo_u":str(u),"density_pieces":[[list(map(str,I)),str(w)] for I,w in density],
            "full_Q_column_sums_D":list(map(str,rows)),"exact_sup_sum_phi":str(row_sup),
            "closed_atomic_witness":atomic,"finite_price_tests":result}


def volume_ratio(n,u):
    return sum(Q(comb(n,j),factorial(j))*u**j for j in range(n+1))


def polygon_area(u):
    a,b = Q(1),1+u
    points = [(b,a),(a,b),(-a,b),(-b,a),(-b,-a),(-a,-b),(a,-b),(b,-a)]
    return abs(sum(x*w-y*z for (x,y),(z,w) in zip(points,points[1:]+points[:1])))/2


def actual_halo_geometry():
    rows = []
    for u in (Q(1,2),Q(1,8)):
        two = polygon_area(u)
        # Above the cube, the cross-section is the 2D polygon with offset u-z.
        # Simpson integrates this quadratic cross-section exactly.
        outside_both = 2*u/6*(polygon_area(Q(0))+4*polygon_area(u/2)+two)
        three = 2*two+outside_both
        face_edge_corner = 8+6*4*u+12*2*(u*u/2)+8*u**3/6
        assert two/4==volume_ratio(2,u)
        assert three==face_edge_corner and three/8==volume_ratio(3,u)
        assert all(ball(volume_ratio(n,u))<(2*(n*ball(u)).sqrt()).exp() for n in (2,3))
        rows.append({"u":str(u),"2D_polygon_area":str(two),"3D_sliced_volume":str(three),
                     "3D_face_edge_corner":str(face_edge_corner),"3D_two_outer_caps":str(outside_both)})
    return rows


def exponent_checks():
    result = []
    for n in (16,64,256,2**40):
        ell = arb(n+2).log()
        r_arb = (arb(n).sqrt()*ell**2).ceil().unique_fmpz()
        assert r_arb is not None
        r = int(r_arb)
        u = Q(r**2,8192**2*n)
        log_envelope = ball(Q(r,4096))
        log_eta = -ball(Q(r,256))
        abstract_half = (log_eta+log_envelope)/2
        target = -ball(Q(r,1024))
        hit = -ball(Q(r,2048))
        assert abstract_half == -ball(Q(15*r,8192))
        assert abstract_half<target<hit<0
        assert target-abstract_half==ball(Q(7*r,8192)) and hit-target==ball(Q(r,2048))
        row = {
            "n":n,"r":r,"u":str(u),"sqrt_eta_Lambda_log_envelope":abstract_half.str(15),
            "positive_log_slack_to_exp_minus_r_over_1024":str(Q(7*r,8192)),
            "post_threshold_log_decay":str(Q(r,2048)),
        }
        if n<=256:
            exact = volume_ratio(n,u)
            log_volume = ball(exact).log()
            assert log_volume < log_envelope
            true_half = (log_eta+log_volume)/2
            assert true_half<abstract_half
            row.update({"computed_Lambda":ball(exact).str(15),
                        "actual_sqrt_eta_Lambda_log":true_half.str(15)})
        else:
            demo_slack = target-abstract_half-4*arb(n).log()
            assert demo_slack>0
            row["illustrative_n4_polynomial_log_slack"] = demo_slack.str(15)
        result.append(row)
    return result


def report():
    return {
        "scope":(
            "Finite true interval families with disjoint full owners and nonuniform AC price. "
            "Finite eta thresholds diagnose the halo ledger. Exact 2D and 3D volume geometry and large-dimensional scalar "
            "envelopes are independently checked."
        ),
        "python":python_version(),"python_flint":flint_version,"arb_bits":ctx.prec,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "priced_halo":priced_halo(),"physical_halo_geometry":actual_halo_geometry(),"exponential_checks":exponent_checks(),
    }


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--out",type=Path)
    action.add_argument("--check",type=Path)
    args = parser.parse_args()
    cert = report()
    data = (json.dumps(cert,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print("Three genuine price thresholds, two polygon/polytopal offsets, and four exponent scales.")


if __name__=="__main__":
    main()

