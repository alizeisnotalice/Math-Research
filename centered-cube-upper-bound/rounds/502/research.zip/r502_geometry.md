# R502：任意两来源块的联合尾与质量细尾

本附件证明一个保完整接收质量的几何联合尾界。它没有构造一般来源的根阶几何分割，因此不宣称原余项已付款。

## 1. 模型与一般联合尾

令 \(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)<\infty\)。每个真实中心 \(B\) 使用同一个可测立方体选择器，边长 \(a\le R_B\le b\le2a\)，并满足
\[
m_B=\mu(Q_B)=q_BR_B^n,\qquad q\le q_B\le\lambda,\qquad r=\lambda/q.
\]
原父测度为 \(d\nu=t(B)q_B\,dB\)，\(0\le t\le S\)；连续 mark 可按其概率测度同时积分。记 \(m_-=qa^n\)、\(p_C(B)=\pi_B(C)\)。以下来源集合对整个中心场固定，不逐父重选。

取不交可测集 \(C,D\)，质量 \(M,N>0\)，具有有限的 \(\mu\)-本质包围盒 \(\prod_i[\ell_{Ci},u_{Ci}]\)、\(\prod_i[\ell_{Di},u_{Di}]\)。设
\[
e_i=\min(u_{Ci},u_{Di})-\max(\ell_{Ci},\ell_{Di}),\qquad
V_{CD}=\prod_{e_i\ge0}(1+e_i/a)\prod_{e_i<0}(1+e_i/b)_+.
\tag{1}
\]
负的 \(e_i\) 记录盒间隙。无界盒时不据此宣称有限价格。

对任意 \(s,t>0\)，令 \(m_*=\min(M/s,N/t)\)、\(R_*=\min(b,(m_*/q)^{1/n})\)。事件 \(p_C>s,p_D>t\) 上有 \(m_B<m_*\)、\(R_B\le R_*\)。若 \(R_*<a\)，事件为空；否则真实中心必须同时落在两本质盒的 \(R_*/2\) 扩张中，故其 Lebesgue 体积至多
\[
\prod_i(R_*+e_i)_+\le R_*^nV_{CD}\le (m_*/q)V_{CD}.
\]
这里正 \(e_i\) 用 \(R_*\ge a\)，负 \(e_i\) 用 \(R_*\le b\)。乘 \(t(B)q_B\le S\lambda\) 得
\[
\nu\{p_C>s,p_D>t\}\le SrV_{CD}\min(M/s,N/t).
\tag{2}
\]
这是对真实中心的容量估计，没有把盒体积作为来源质量帽；任意集中 \(f\) 仍适用。盒边界或 \(R_*=a\) 不需删除，零质量集合取连续延拓。

由于 \(C,D\) 不交，同一个完整分母还给
\[
p_C+p_D\le\delta_{C\cup D}:=\min(1,(M+N)/m_-).
\]
因此双层饼只在 \(s+t<\delta\) 积分。变换 \(s=\ell z,t=\ell(1-z)\) 给精确恒等式
\[
\int_{s+t<\delta}\min(M/s,N/t)\,ds\,dt
=\delta\,\mathcal E(M,N),
\quad \mathcal E(M,N)=M\log(1+N/M)+N\log(1+M/N).
\]
故
\[
\boxed{\int p_Cp_D\,d\nu\le Sr\,V_{CD}\,\delta_{C\cup D}\,\mathcal E(M,N).}
\tag{3}
\]
关键是共同的 \(m_B\)，不能替换为两个独立的单来源尾。

## 2. 原积分接口与终端纪律

对固定有限二叉来源分割树，根覆盖全部 \(\mu\)，每个内节点 \(F=C\sqcup D\)。唯一首分离恒等式为
\[
1=2\sum_{F\text{ 内节点}}p_Cp_D+\sum_{L\text{ 叶}}p_L^2.
\]
令叶本质盒边长为 \(\ell_i(L)\)，\(V_L=\prod_i(1+\ell_i(L)/a)\)。单尾层饼在 \(0<s<\delta_L\) 给
\(\int p_L^2d\nu\le2SrV_L\delta_L\mu(L)\)。从而
\[
R_\tau=\nu(E)\le2Sr\mathcal B_{\mathcal T},\qquad
\mathcal B_{\mathcal T}=
\sum_{F=C\sqcup D}\delta_FV_{CD}\mathcal E(\mu C,\mu D)
+\sum_{L\text{ 叶}}V_L\delta_L\mu L.
\tag{4}
\]
若对原祖先积分先用 \(H_B(x,z)\le\Phi_{\max}\)，则替代接口是 \(J\le2Sr\Phi_{\max}\mathcal B_{\mathcal T}\)。这和直接 \(H\equiv1\) 的式 (4) 是两种使用方式，不能叠加收取；详细保原 \(H\) 的首分离式由本轮主证明附件记录。不能以森林省略不同根之间的来源对。

无限细分可先保持真实叶残量。若最大叶质量 \(\epsilon_j\to0\)，则逐父
\[
\sum_{L\text{ 叶}}p_L^2\le\frac{\epsilon_j}{m_-}\sum_Lp_L
=\frac{\epsilon_j}{m_-}.
\tag{5}
\]
积分后至多 \(\epsilon_jR_\tau/m_-\to0\)；既有粗界 \(R_\tau\le SA_nW\) 保证有限。此极限不要求叶盒价有界，但也不控制内节点的几何费用。

## 3. 质量细尾确可和的范围

\(\mu=f\,dx\) 无原子，故可作可测的精确质量半分；这不提供空间受控的半分。对质量 \(M_0\) 的子树，每层节点质量 \(M_02^{-j}\)，熵增量为 \(\mu(F)\log2\)，所以无几何权的精确总和为
\[
M_0\log2\sum_{j\ge0}\min(1,M_0/(2^jm_-)).
\tag{6}
\]
令 \(j_0\) 为首个 \(M_02^{-j_0}\le m_-\) 的层，则从该层起之和不超过 \(2M_0\log2\)。**只有同时证明这些节点的 \(V_{CD}\le V_0\)，才能推出真实细尾价不超过 \(2V_0M_0\log2\)。**

若 \(u=M_0/m_-<1\)，式 (6) 中的级数为 \(2u\)；若 \(u\ge1\)、\(k=\lfloor\log_2u\rfloor\)，则为 \(k+1+u/2^k\)。因此质量平衡本身仍留下粗节点费用，并且没有限制其 \(V_{CD}\)。在已知紧凑盒内、\(V_0\) 有界的子树，原整节点叶价已可支付；不能把这项条件性细尾再次宣称为新的原余项付款。

本轮唯一尚缺的构造是：对一般 \(\mu\) 和同一个真实接收选择器，建立全局来源分割，使式 (4) 的**真实粗节点几何加权和**有根阶来源价（或保原 \(H\) 后取得更弱但足付的界）。精确质量半分的可测存在性不解决这一空间几何要求；式 (3) 的一般有符号盒交叠工具也不自动给此构造。

## 4. 已运行的有限核验

使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。输出为 `1 symbolic entropy scaling, 12 exact box bounds, 8 exact mass-tree assertions PASS.` 以下只核符号与有理算术；不是一般来源树构造或原历史的数值证明。

```python
from fractions import Fraction as F
import sympy as s
M,N,delta,z=s.symbols('M N delta z',positive=True)
z0=M/(M+N)
val=delta*(s.integrate(N/(1-z),(z,0,z0))+s.integrate(M/z,(z,z0,1)))
assert s.simplify(s.expand_log(
    val-delta*(M*s.log(1+N/M)+N*s.log(1+M/N)),force=True))==0
boxchecks=0
a,b=F(1),F(2)
for es in [(F(1,2),F(-1,4)),(F(-1),F(0)),(F(-3),F(1))]:
    V=F(1)
    for e in es:
        V*=max(F(0),1+e/(a if e>=0 else b))
    for R in [F(1),F(4,3),F(3,2),F(2)]:
        vol=F(1)
        for e in es:
            vol*=max(F(0),R+e)
        assert vol<=R**len(es)*V
        boxchecks+=1
serieschecks=0
for u in [F(1,4),F(1),F(3),F(16)]:
    total=sum(min(F(1),u/F(2)**j) for j in range(20))+u/F(2)**19
    if u<1:
        assert total==2*u
    else:
        k=0
        while F(2)**(k+1)<=u:
            k+=1
        assert total==k+1+u/F(2)**k
    j0=0
    while u/F(2)**j0>1:
        j0+=1
    assert 2*u/F(2)**j0<=2
    serieschecks+=2
print(f'1 symbolic entropy scaling, {boxchecks} exact box bounds, '
      f'{serieschecks} exact mass-tree assertions PASS.')
```
