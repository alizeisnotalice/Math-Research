# R502：首次分离树的原权恒等式、截断质量费与叶残项

保持 R501 的同一未付量 \(J=I_{\rm middle,in}+I_{\rm nonnear,out}\)，以及同一 \(\widehat\nu,\pi_B,G,v_x,K,T\)、质量／mark 顺序、边界与剩余 mask。记 \(m_-=qa^n>0\)、\(A_n=1+n\log(b/a)\)、\(\Phi=\Phi_{\max}\)。本稿证明有限树的完整账和合法极限；没有构造一般来源上可付的几何树，不将取 inf 或来源熵望远镜称为根阶付款。

## 1. 原祖先积分只作精确合并

令
\[
H_B(x,z)=1_{v_z(B)<K}\frac1T\int_{A\succ B}
\frac{G(A)c_A(x)}{m_A}\chi_\partial(A,x)M(A,B,x,z)
1_{v_x(A)\ge K}e^{-[v_x(A)-v_x(B)]/T}\widehat\nu(dA).
\]
这是原权，\(0\le H_B\le\Phi\)，且
\(J=\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)H_B(x,z)\)。没有把祖先 mask 换成只依子树的门。

先在一个有限质量、有限包围盒的来源集合 \(S_0\) 内取固定有限二叉可测树。每内部节点 \(S\) 的两个孩子 \(C,D\) 互不相交、并为 \(S\)，叶分割 \(S_0\)。树可依完整 \(f\) 构造，但同一棵树用于所有父与 pair，不逐 pair 重选。
置
\[
p_C(B)=\frac{\mu(Q_B\cap C)}{m_B},\qquad
H_B^{\rm sym}(x,z)=\tfrac12[H_B(x,z)+H_B(z,x)].
\]
对 \(p_Cp_D>0\)，定义真实父条件平均
\[
\theta_S(B)=\frac{\int_{C\times D}H_B^{\rm sym}(x,z)\pi_B(dx)\pi_B(dz)}
{\Phi p_C(B)p_D(B)}\in[0,1];
\]
零分母取0。\(\theta_S\) 保原两方向的所有接受权，通常依赖父、mark、原 head 及 void。

唯一首次分离节点给出精确有限式
\[
\boxed{J(S_0^2)=2\Phi\sum_{S\ {
m internal}}
\int p_C(B)p_D(B)\theta_S(B)\,d\widehat\nu(B)
+\sum_{C\ {
m leaf}}J(C^2).}\tag{1}
\]
系数2只来自两个有序方向之和；不假定 \(H_B\) 自身对称。具体地
\(J(C\times D)+J(D\times C)=2\int_{C\times D}H_B^{\rm sym}\,\widehat\nu\pi_B^2\)。分母始终为实际 \(m_B^2\)，不是 \(\mu(C)\mu(D)\)。

## 2. 共同质量截断同时进入交叉项与叶项

设 \(M=\mu(C),N=\mu(D)\)，\(\delta_S=\min(1,(M+N)/m_-)\)，并记
\[
\mathcal E(M,N)=(M+N)\log(M+N)-M\log M-N\log N.
\]
零质量按连续延拓，\(0\log0=0\)。因为 \(p_C+p_D\le\delta_S\)，联合尾仅需在 \(s+t<\delta_S\) 积分。

为说明几何输入的精确范围，令孩子包围盒端点为 \(l_{C,i},u_{C,i}\) 等，
\(e_i=\min(u_{C,i},u_{D,i})-\max(l_{C,i},l_{D,i})\)，并置
\[
V_{CD}=\prod_{e_i\ge0}(1+e_i/a)
\prod_{e_i<0}(1+e_i/b)_+.
\]
实际联合尾强制 \(R_B\le R_*:=\min\{b,[\min(M/s,N/t)/q]^{1/n}\}\)。非空时 \(R_*\ge a\)，共同兼容中心体积至多 \(\prod_i(R_*+e_i)_+\le R_*^nV_{CD}\)。故
\[
\nu\{p_C>s,p_D>t\}\le SrV_{CD}\min(M/s,N/t).
\]
缩放三角形 \((s,t)=\delta_S(u,v)\)，并用 R501 已证三角形积分，得到
\[
\int p_Cp_D\,d\nu\le SrV_{CD}\delta_S\mathcal E(M,N).\tag{2}
\]
保留 \(a=b\) 的端点；\(R_*<a\) 时事件为空。这里包围盒只作来源支持的几何包络，没有给非接收者集合虚设 matching。

对任一节点 \(C\)，包围盒各边长为 \(h_{C,i}\)，置
\(V_C=\prod_i(1+h_{C,i}/a)\)、\(\delta_C=\min(1,\mu(C)/m_-)\)。R500 单尾估计为
\(\nu\{p_C>t\}\le SrV_C\mu(C)/t\)，而 \(p_C\le\delta_C\)，所以
\[
\boxed{\int p_C^2d\nu\le2SrV_C\delta_C\mu(C).}\tag{3}
\]
因此不是把叶内残项静默删除，也不必继续付该叶无限细化的熵。

## 3. 可剪枝的完整费用与两个替代入口

对任一有限 pruning 定义
\[
\mathcal B(\mathcal T)=
\sum_{S\ {
m internal}}V_{CD}\delta_S\mathcal E(\mu C,\mu D)
+\sum_{C\ {
m leaf}}V_C\delta_C\mu(C).
\]
由 (1)–(3)，
\[
J(S_0^2)\le2Sr\Phi\mathcal B(\mathcal T).\tag{4}
\]
取上界时确实丢掉了 \(\theta_S\le1\)；不能随后声称仍利用了 head、距离或 void 的额外节省。

同一个树恒等式也可直接用于 \(H_B\equiv1\)。当 \(S_0\) 包含全部来源时，\(\pi_B(S_0)=1\)，于是得到更直接的**替代**入口
\[
\boxed{R_\tau=\int d\nu\le2Sr\mathcal B(\mathcal T).}\tag{5}
\]
它不乘 \(\Phi\)，也不依赖原接受权。因而构造
\(\mathcal B\lesssim\sqrt n\operatorname{polylog}(n)W\)
就足够支付整个固定场；通过 (4) 则需更强的 polylog 级树价。两入口择一使用，不在母账中重复相加；(5) 是充分几何目标，未被本稿证明。

有限树可自底向上在“停于本节点”和“付交叉再处理孩子”间取较小费用：
\[
B(S)=\min\{V_S\delta_S\mu(S),\
V_{CD}\delta_S\mathcal E(\mu C,\mu D)+B(C)+B(D)\}.\tag{6}
\]
这是真正可实现的有限 pruning。特别是紧凑来源簇的所有后代可一次按整节点平方支付，避免把无界分割熵当成必付价格。但 (6) 本身并不提供任意来源的统一上界。

对未截断的来源熵，只有
\[
\sum_{S\ {
m internal}}\mathcal E(\mu C,\mu D)
=\mu(S_0)\log\mu(S_0)-\sum_{C\ {
m leaf}}\mu C\log\mu C.
\tag{7}
\]
它可随细化发散。\(V_{CD}\delta_S\) 以及父依赖的 \(\theta_S\) 不允许从 (7) 免费移出；原后验树流不是总来源质量树流。当前缺口是**同一可实现树的几何加权总价**，或保原 \(\theta_S\) 后能严格改进 (4) 的共同积分比较；尚无这样的整体估计。没有把 inf 定义、(7) 或 (5) 自身记为新付款。

## 4. 无界来源与无限细化的合法性

对 \(O=S_0^c\)，原剩余 pair 的外部部分满足
\[
J\{x\in O\text{ or }z\in O\}
\le2\Phi\int\nu\pi_B(O)
\le2\Phi SA_n\mu(O).\tag{8}
\]
第二步使用真实来源中心容量 \(\int t(B)R_B^{-n}c_B(x)dB\le SA_n\)。直接入口 (5) 的对应误差为 \(2SA_n\mu(O)\)。更直接地，令 \(e=\mu(O)<m_-\)。原 \(m_B,\pi_B,\nu\) 完全不改，且 \(p_O(B)\le e/m_-\)，故
\[
(1-e/m_-)^2R_\tau
\le\int\pi_B(S_0)^2d\nu
\le2Sr\mathcal B(\mathcal T).
\tag{8a}
\]
原 \(J\) 的外部 pair 残项还满足 \(2\Phi eR_\tau/m_-\) 上界；它必须显式保留，不自动作为已吸收项。固定输入下取递增有界集使 \(e\to0\)，误差及 (8a) 的乘法损失趋零；树价仍须控制，不能将 \(\mu\) 改成截断来源后重新匹配。

有限盒内取一致细化、网格直径趋零的树。\(\mu=f\,dx\) 无原子，\(\pi_B\) 也无原子，因此同叶 pair 概率趋零。原权有界，且 \(\nu\) 有限，支配收敛给精确叶残项趋零；首次分离交叉项非负，单调收敛给无限级恒等式。若叶盒系数 \(V_C\le V_0\) 且 \(\max_C\mu(C)\to0\)，还可用显式费用
\[
\sum_{C\ {
m leaf}}V_C\delta_C\mu(C)
\le \frac{V_0\max_C\mu(C)}{m_-}\mu(S_0)\longrightarrow0.
\tag{9}
\]
实际叶残项还有不要求 \(V_C\) 有界的估计：设 \(\epsilon_k=\max_{C\ {\rm leaf}}\mu(C)\)，则逐父
\[
\sum_Cp_C(B)^2\le\frac{\epsilon_k}{m_-}\sum_Cp_C(B)
\le\frac{\epsilon_k}{m_-},
\]
所以 \(J\) 的真实叶残项至多 \(\Phi\epsilon_kR_\tau/m_-\to0\)。这里
\(R_\tau=\int\mu(dx)U(x)\le SA_nW<\infty\)。因此精确质量二分也可实现无限树极限，不必依赖几何网格直径。仍须证明内部价格总和具有目标阶数；实际叶残项消失不支付它们。每层必须使用同一棵嵌套树，不能拼接逐 pair 最优树。

\(\delta_S\) 确实使质量二分的深层熵可和：若某子树根质量为 \(M\)，且其节点 \(V_{CD}\le V_0\)，则该子树的无限交叉价格至多
\[
V_0M\log2\sum_{l\ge0}\min\{1,M/(2^lm_-)\}
\le V_0M[\log_+(M/m_-)+3\log2].\tag{10}
\]
若 \(M\le m_-\)，上式左端准确为 \(2\log2\,V_0M^2/m_-\)。证明是在第 \(l\) 层求和 \(2^l\) 个质量 \(M/2^l\) 的 binary 熵，然后对截断几何级数求和。非原子 \(\mu\) 允许质量二分。对有界根可取其包围盒系数为 \(V_0\)，但此系数可能很大；(10)并未给一般 root 几何价。它只说明不能再把无限质量细化本身当作必须发散的费用。

历史窄核对：R433 的邻格增长熵及 R435 的 clipped 熵总预算有特定增量权；其到原负载的比较仍未证明。本稿不借用该未证桥。R439 的共同随机格碰撞也不能替代 (1) 中的接受条件平均。

## 5. 实际有限核验

下列连续中心模型取 \(R_B=1\)、\(B\in[-1/2,1/2]\)、完整来源
\(f=1_{[-1,0)}+2\,1_{[0,1]}\)，于是 \(m_B=B+3/2\in[1,2]\)，\(q=1,\lambda=2,t=1\)。四个半单位来源格构成二叉树。非对称有理 \(H_{ij}\) 仅测试真实后验分母、两方向系数和叶残项，不声称实现原历史。

```python
import sympy as s
from fractions import Fraction as F
x=s.symbols('x', real=True)
h=s.Rational(1,2);m=x+s.Rational(3,2)
H=s.Matrix(4,4,lambda i,j:s.Rational(((i+1)*(j+2))%7,7))
total=0; checks=0; residual=0
for lo,hi in [(-h,s.Integer(0)),(s.Integer(0),h)]:
    mid=(lo+hi)/2; masses=[]
    for j in range(4):
        l=(j-2)*h;u=(j-1)*h;density=1 if j<2 else 2
        left=x-h if mid-h>l else l
        right=x+h if mid+h<u else u
        masses.append(s.expand(density*(right-left))
                      if (right-left).subs(x,mid)>0 else s.Integer(0))
    assert s.simplify(sum(masses)-m)==0;checks+=1
    full=sum(masses[i]*masses[j]*H[i,j]
             for i in range(4) for j in range(4))
    cross=0
    for C,D in [([0,1],[2,3]),([0],[1]),([2],[3])]:
        v=sum(masses[i]*masses[j]*(H[i,j]+H[j,i]) for i in C for j in D)
        w=2*sum(masses[i]*masses[j]*(H[i,j]+H[j,i])/2 for i in C for j in D)
        assert s.expand(v-w)==0;checks+=1;cross+=v
    leaf=sum(masses[i]**2*H[i,i] for i in range(4))
    assert s.expand(full-cross-leaf)==0;checks+=1
    total+=s.integrate(full/m,(x,lo,hi))
    residual+=s.integrate(leaf/m,(x,lo,hi))
print('native static pair integral=',s.simplify(total),'=',s.N(total,15))
print('leaf residual=',s.simplify(residual),'=',s.N(residual,15))
for depth in range(1,9):
    masses=[F(1,2**depth)]*(2**depth)
    assert sum(min(1,v)*v for v in masses)==F(1,2**depth);checks+=1
for Q in [F(1,4),F(1),F(3,2),F(2),F(7),F(16)]:
    k=0
    while 2**k<Q: k+=1
    explicit=sum(min(F(1),Q/2**l) for l in range(20))+2*Q/2**20
    assert explicit==k+2*Q/2**k;checks+=1
print(f'{checks} exact assertions PASS; continuous-center pair identity, '
      'eight leaf-tail and six geometric-series checks; no original history.')
```

实际运行24条断言通过；完整静态积分为
\((-135\log3-13+263\log2)/28\approx0.749466054181100\)，叶残项约
\(0.488529260615727\)。叶残项显著且已保留。有限数值仅核上述代数与静态模型，一般断言由解析证明给出。
