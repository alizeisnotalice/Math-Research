# R502：有限 source-box 树与规则 tensor 树的费用

实际完成 1917 项 exact/Arb 断言：9 个固定 source-box 几何，每个 4 个 DP 候选；另 3 个解析规则 tensor 树。每个 N=8 几何枚举全部 3025 个无序二分，但浮点仅用于选择候选树，不认证全局最优。选中树、固定 balanced 基线和两者差额均以 exact Fraction 几何、精确 prime-log 系数及 Arb384 复核。

决策：来源自适配及 δ 在小叶数例上明显有益，但不能由此推一般源预算。uniform side-2 box 的规则坐标树即使加 δ，coarse 内部节点仍给指数费用；叶子截断不解决它。该规则树不是所有树的下界，尚需更好的树或真实 rank/void/来源关联机制。

## 单 pair 几何方向

父候选实际尺度 a≤R≤b，a=1,b=2。对两个 source bounding intervals，e=min(u_C,u_D)−max(l_C,l_D)。中心扩张区间交长恰 (R+e)_+，所以

(R+e)_+/R ≤ 1+e/a（e≥0），或 (1+e/b)_+（e<0）。

前者随 R 下降，后者随 R 上升。SymPy 核导数，Fraction 核重叠、贴边、间隙、gap=b 和 gap>b 五组端点，各取 R=1,3/2,2。各坐标乘积即 V_CD。

这是捕获子集正质量所需中心区域的 outer box，未把 bounding-box union 误当实际来源集或 whole-capture 条件。该数值只复核方向；posterior joint-tail 引理由作者解析证明。

## 两种费用及剪枝递推

a=q=m_-=1。有限 8 叶质量各 1/4，总 W=2，不使用 W<m_- 的空场。δ(M)=min(1,M)。

每个节点两选一：

- 整个子集作为 bbox 叶，cost=2δ(M)V_node M，V_node=∏(1+width_i/a)；
- 分为不交 source 子集 C,D，子树费用加 2δ(M+N)V_CD E(M,N)，E=(M+N)log(M+N)−MlogM−NlogN。

ordered-pair 系数 2 全程保留。无 δ 对照将 merge 和 leaf 的 δ 都置1，不混用。四个 DP 版本为无δ/有δ，各自 forced8leaves/允许任意子集剪为bbox叶。几何 cache 相同，未为结果换 source。

每个选中树是合法 source 划分。若代入已给 tree joint-tail/square 账，可直接读有限输入上的 Rτ≤Sr·cost，不再外乘 Φ；本脚本不重新证明该一般账，更不继承原 history 成功门。

## 三个固定 source 族

n=8,32,128，所有原始叶为 side w=1/n 的半开小立方体，质量1/4、均匀正密度。三族各只有8叶，坐标完全有理：

1. compact：点标签 i=0,…,7，第 j 坐标为 bit_(j mod3)(i)/n；整体 bbox 宽2/n。
2. spikes：第 i 点为 (1/2)e_i，其余坐标0。
3. dispersed balanced hypercube：第 j 坐标为 bit_(j mod3)(i)/2。

各族源盒内部两两不交；compact 的接触边界由半开 convention 解决，μ 为 L1 密度、边界零测。源盒与 receiver 域不要求互不交。

三族整体 bbox 各宽均<1。因此 side-1 cubes 在一个严格正 Lebesgue 中心域中能完整捕获全部 W=2，实际 q_A=2∈[1,2]；脚本给这个中心域体积的精确 Fraction，避免空 receiver 的形式模型。没有创建原 highrank/history 流，此非空资格不说明 hardcore 非空。

## 候选费用与来源适配

下面为有 δ、允许剪枝的选中候选 cost/W；对应基线为标签次序的等数 balanced 二分树。

| n | compact | spikes | balanced hypercube |
|---|---:|---:|---:|
| 8 | 9.77787 | 8.35811 | 9.07683 |
| 32 | 10.53870 | 8.93381 | 8.71464 |
| 128 | 10.76918 | 9.09675 | 8.69029 |

n=128 三例均由严格 Arb 比较认证 cost/W<√128。n=8、32 不满足同一个系数1阈值，未强行总结全维界。固定叶数且参数随 n 缩放的这些例更不能替代任意源分割。

n=128 的四版本：

| 族 | 无δ强制叶 | 无δ可剪枝 | δ强制叶 | δ可剪枝 |
|---|---:|---:|---:|---:|
| compact | 15.56570 | 14.55134 | 10.76918 | 10.76918 |
| spikes | 13.66267 | 13.66267 | 9.09675 | 9.09675 |
| hypercube | 12.75190 | 12.75190 | 8.69029 | 8.69029 |

新 δ 下9例剪枝候选都仍选8个原叶；无δ的compact会剪成整root bbox。剪枝允许是合法选项，不保证在每例都改进。

来源适配的区别很明显：n=128 hypercube 的固定 balanced 基线 δ-cost/W 约2.1235×10^10，选中候选约8.69029。选中根分成7:1，并不是逐坐标均衡拆分；不能把 fixed balanced 的大费称所有树失败。

δ候选 n=128 每W的 leaf 总费均为1.35387，内部 merge 费分别9.41531、7.74288、7.33642，内部仍主导。JSON 保存每节点的 mass、δ、V、费用和最大节点；这也是区分“叶熵已被截断”与“内部几何仍需付款”的直接数据。

## 必要压力：uniform box 的规则 tensor 树

另用 f=1 于 side-2 box，W=2^n，q=a=m_-=1，b=2。规则树先逐坐标把长度2分到1，再把1分到1/2；不展开2^(2n) leaves，按层精确积分。

第一轮深度 k=0,…,n−1：节点 mass=2^(n−k)、δ=1，cross V=2^k3^(n−k−1)。该层 cost/W=2Vlog2。

第二轮 j=0,…,n−1：节点 mass=2^(−j)、δ=2^(−j)，cross V=(3/2)^j2^(n−j−1)。该层 cost/W=2^n(3/8)^jlog2。

末叶 δ=(1/2)^n、V=(3/2)^n，合计 leaf cost/W=2(3/4)^n。于是规则树完整值为

cost/W=2log2(3^n−2^n)+(8/5)2^nlog2[1−(3/8)^n]+2(3/4)^n。

两个几何级数经 SymPy 核验，n=2,8,32 再以 Fraction 层累加独立核闭式。

| n | 规则树 cost/W | root 一层 cost/W |
|---|---:|---:|
| 2 | 11.86878 | 4.15888 |
| 8 | 9024.58823 | 3031.82577 |
| 32 | 2.56883×10^15 | 8.56277×10^14 |

粗层 node mass≥1，δ=1，故指数 V 没被底部 δ 抵消。这是一个明确规则树候选的费用，不是任意 adaptive tree 的下界。它阻止仅凭 N8 紧簇例宣称树预算一般有效；可能需要更好的分割，也可能需实际 rank/void 或更锋利的粗层 joint-tail 关联，当前不作排他性判断。

## 复现与严格证书层级

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r502_numeric.py`

实际 Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb384 bits。DP discovery 是 deterministic float 搜索，所有二分均被枚举但浮点 tie/排序不作为严格 global optimum 证明。

选中和基线费用写成 rational 常数加 log2、log3、log5、log7 的精确 Fraction 系数，JSON 存这些系数、树及各节点；与基线的差若 exact0 直接核系数，否则用 Arb 严格判符号。所有36候选相对相应 fixed balanced 基线均有正改进；此仅为基线比较，不认证全局最优。

固定 stdout：`PASS 1917 exact/Arb assertions;9 box geometries x4 DP variants,3 regular tensor formulas;no global tree theorem`。

唯一动态字段 compute_index.seconds，隔离比较时删该字段。无随机scan、原流模拟、Poisson近似或仓库改动。白名单仅 `/tmp/r502_numeric.py`、`/tmp/r502_numeric.json`、`/tmp/r502_numeric.md`。完成限定任务后停止。
