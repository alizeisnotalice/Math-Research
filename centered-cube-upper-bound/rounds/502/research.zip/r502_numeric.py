from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import sys,platform,time,json,math
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def prime_log(q):
 q=F(q);out={}
 for num,sgn in [(q.numerator,1),(q.denominator,-1)]:
  for p in (2,3,5,7):
   while num%p==0 and num>1:out[p]=out.get(p,F(0))+sgn;num//=p
  assert num==1
 return {p:v for p,v in out.items() if v}
def entropy(k,l):
 out={}
 for q,sgn in [(F(k+l,4),1),(F(k,4),-1),(F(l,4),-1)]:
  for p,v in prime_log(q).items():out[p]=out.get(p,F(0))+sgn*q*v
 return {p:v for p,v in out.items() if v}
def plus(A,B):
 out=A.copy()
 for p,v in B.items():out[p]=out.get(p,F(0))+v
 return {p:v for p,v in out.items() if v}
def scalar(A,q):return {p:q*v for p,v in A.items() if q*v}
def evaluate(C):return ar(C.get(0,F(0)))+sum((ar(v)*arb(p).log() for p,v in C.items() if p),arb(0))
def exactzero(C):return not any(C.values())
def product(values):
 out=F(1)
 for v,k in Counter(values).items():out*=v**k
 return out
# Coordinate intersection direction, including contact and zero-volume endpoints.
pairs=[((F(0),F(1)),(F(1,2),F(3,2))),((F(0),F(1,2)),(F(1,2),F(1))),((F(0),F(1,4)),(F(3,4),F(1))),((F(0),F(1,4)),(F(9,4),F(5,2))),((F(0),F(1,4)),(F(13,4),F(7,2)))]
endpoints=[]
for C,D in pairs:
 e=min(C[1],D[1])-max(C[0],D[0]);V=(1+e) if e>=0 else max(F(0),1+e/2)
 vals=[]
 for R in (F(1),F(3,2),F(2)):
  length=max(F(0),min(C[1]+R/2,D[1]+R/2)-max(C[0]-R/2,D[0]-R/2))
  ck(length==max(F(0),R+e));ck(length/R<=V);vals.append(str(length/R))
 endpoints.append(dict(C=list(map(str,C)),D=list(map(str,D)),e=str(e),V=str(V),normalized_intersections=vals))
R,e=sp.symbols('R e',real=True);ck(sp.simplify(sp.diff(1+e/R,R)+e/R**2)==0)
records=[]
for n in (8,32,128):
 for model in ('compact_cluster','coordinate_spikes','balanced_hypercube'):
  w=F(1,n);half=w/2
  if model=='coordinate_spikes':centers=[tuple(F(1,2) if j==i else F(0) for j in range(n)) for i in range(8)]
  else:
   amp=w if model=='compact_cluster' else F(1,2)
   centers=[tuple(amp*((i>>(j%3))&1) for j in range(n)) for i in range(8)]
  boxes=[[(z-half,z+half) for z in center] for center in centers]
  for i in range(8):
   for j in range(i):ck(any(boxes[i][d][1]<=boxes[j][d][0] or boxes[j][d][1]<=boxes[i][d][0] for d in range(n)))
  bbox={};Vnode={};ms={};delta={}
  for mask in range(1,256):
   if mask&(mask-1)==0:b=boxes[mask.bit_length()-1]
   else:
    k=mask&-mask;B=bbox[mask^k];C=bbox[k];b=[(min(B[d][0],C[d][0]),max(B[d][1],C[d][1])) for d in range(n)]
   bbox[mask]=b;Vnode[mask]=product([1+u-l for l,u in b]);ms[mask]=F(mask.bit_count(),4);delta[mask]=min(F(1),ms[mask])
  fullvolume=product([max(F(0),1-(u-l)) for l,u in bbox[255]])
  ck(fullvolume>0) # R=1 fullcapture of W=2 is native q=2 on this positive center domain.
  cache={};parts={}
  for mask in range(1,256):
   arr=[];anchor=mask&-mask;left=(mask-1)&mask
   while left:
    if left!=mask and left&anchor:
     right=mask^left;arr.append((left,right))
     ee=[min(bbox[left][d][1],bbox[right][d][1])-max(bbox[left][d][0],bbox[right][d][0]) for d in range(n)]
     cache[left,right]=product([(1+z) if z>=0 else max(F(0),1+z/2) for z in ee])
    left=(left-1)&mask
   parts[mask]=arr
  ck(sum(map(len,parts.values()))==3025)
  entropy_float={(k,l):float(evaluate(entropy(k,l))) for k in range(1,8) for l in range(1,9-k)}
  def baseline(mask):
   ids=[i for i in range(8) if mask>>i&1]
   if len(ids)==1:return (mask,None,None)
   left=sum(1<<i for i in ids[:len(ids)//2]);return(mask,baseline(left),baseline(mask^left))
  def dp(truncated,prune):
   cost={};tree={}
   for mask in range(1,256):
    de=delta[mask] if truncated else F(1)
    best=2*float(de*Vnode[mask]*ms[mask]) if prune or mask.bit_count()==1 else math.inf
    selected=(mask,None,None)
    for left,right in parts[mask]:
     cand=cost[left]+cost[right]+2*float(de*cache[left,right])*entropy_float[left.bit_count(),right.bit_count()]
     if cand<best:best=cand;selected=(mask,tree[left],tree[right])
    cost[mask]=best;tree[mask]=selected
   return tree[255],cost[255]
  def certify(tree,truncated,nodes):
   mask,left,right=tree;de=delta[mask] if truncated else F(1)
   if left is None:C={0:2*de*Vnode[mask]*ms[mask]};kind='leaf';vf=Vnode[mask]
   else:
    lm,rm=left[0],right[0];vf=cache.get((lm,rm),cache.get((rm,lm)))
    C=scalar(entropy(lm.bit_count(),rm.bit_count()),2*de*vf);kind='merge'
   val=evaluate(C);ck(val.is_finite());ck(val>=0)
   nodes.append(dict(mask=mask,source_indices=[i for i in range(8) if mask>>i&1],kind=kind,mass=str(ms[mask]),delta=str(de),V=str(vf),cost=str(val)))
   if left is not None:C=plus(C,plus(certify(left,truncated,nodes),certify(right,truncated,nodes)))
   return C
  results=[]
  for truncated in (False,True):
   base_nodes=[];base_exact=certify(baseline(255),truncated,base_nodes)
   for prune in (False,True):
    tree,discovery=dp(truncated,prune);nodes=[];C=certify(tree,truncated,nodes);value=evaluate(C);diff=plus(base_exact,scalar(C,-1));dv=evaluate(diff)
    ck(dv.is_finite())
    if exactzero(diff):ck(dv.contains(0));sign='exact_equal'
    else:ck(dv>0 or dv<0);sign='positive' if dv>0 else 'negative'
    limit=2*arb(n).sqrt() # W=2: cost/W<=sqrt n iff cost<=2sqrt n.
    bound_pass=value<limit
    results.append(dict(delta=truncated,pruning=prune,float_discovery_cost=discovery,selected_exact_prime_log_coefficients={str(k):str(v) for k,v in C.items()},baseline_exact_prime_log_coefficients={str(k):str(v) for k,v in base_exact.items()},certified_selected_cost=str(value),selected_cost_over_W=str(value/2),baseline_balanced_cost=str(evaluate(base_exact)),baseline_minus_selected=str(dv),baseline_difference_sign=sign,cost_over_W_le_sqrt_n=bool(bound_pass),tree=tree,nodes=nodes,largest_node= max(nodes,key=lambda z:float(arb(z['cost'])))))
  records.append(dict(n=n,model=model,leaf_count=8,leaf_side=str(w),leaf_mass='1/4',W='2',a='1',b='2',q='1',m_min='1',r='2',center_rule='spike i=(1/2)e_i' if model=='coordinate_spikes' else ('bit_i(j mod3)/n' if model=='compact_cluster' else 'bit_i(j mod3)/2'),native_input_qualification='Disjoint half-open source cubes with uniform positive density; all support bbox widths<1. R=1 completecapture has mass2,q=2 on a positive center domain. No original hard/history claim.',positive_fullcapture_R1_center_volume=str(fullvolume),binary_partitions_examined=3025,results=results))
# Regular tensor tree: no expansion into exponentially many leaves.
NN,k=sp.symbols('NN k',integer=True,positive=True)
ck(sp.simplify(sp.summation(2**k*3**(NN-k-1),(k,0,NN-1))-(3**NN-2**NN))==0)
ck(sp.simplify(sp.summation(sp.Rational(3,8)**k,(k,0,NN-1))-(1-sp.Rational(3,8)**NN)/(1-sp.Rational(3,8)))==0)
tensor=[]
for n in (2,8,32):
 layers=[];coef=F(0)
 for k in range(n):
  V=F(2**k*3**(n-k-1));delta=F(1);layer=2*delta*V;coef+=layer;layers.append(dict(depth=k,stage='2to1',node_mass=str(F(2)**(n-k)),V=str(V),delta=str(delta),cost_over_W_log2_coefficient=str(layer)))
 for j in range(n):
  V=F(3,2)**j*2**(n-j-1);delta=F(1,2)**j;layer=2*delta*V;coef+=layer;layers.append(dict(depth=n+j,stage='1tohalf',node_mass=str(F(1,2)**j),V=str(V),delta=str(delta),cost_over_W_log2_coefficient=str(layer)))
 closed=2*(3**n-2**n)+F(8,5)*2**n*(1-F(3,8)**n);ck(coef==closed)
 leaf=2*F(3,4)**n;value=ar(coef)*arb(2).log()+ar(leaf)
 ck(value>arb(n).sqrt())
 tensor.append(dict(n=n,source='uniform density1 on side2 box',W=str(2**n),q='1',a='1',b='2',cost_over_W=str(value),log2_coefficient=str(coef),leaf_cost_over_W=str(leaf),first_root_layer_over_W=str(ar(2*3**(n-1))*arb(2).log()),layers=layers,scope='This fixed regular coordinate-bisection candidate only,not a lower bound on all trees.'))
result=dict(scope='Finite source-box candidate tree optimization and exact selected-tree validation;not an arbitrary-source theorem or original history certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r502_numeric.py',seconds=time.perf_counter()-start),checks=checks,finite_geometries=9,DP_variants_per_geometry=4,coordinate_endpoint_cases=endpoints,formulas=dict(V='ei=min(uCi,uDi)-max(lCi,lDi);prod_e>=0(1+ei/a)*prod_e<0(1+ei/b)_+',merge='2 delta(M+N) V_CD E(M,N),E=(M+N)log(M+N)-MlogM-NlogN',leaf='2 delta(M) V_node M;delta(M)=min(1,M/m_min)',pruning='At every subset node choose whole bbox leaf or binary split; W=2,m_min=1',tensor='cost/W=2log2(3^n-2^n)+(8/5)2^nlog2[1-(3/8)^n]+2(3/4)^n'),records=records,regular_tensor=tensor,decision='Source-adapted geometry and delta/pruning are evaluated on fixed finite inputs. The uniform tensor regular tree has exponential coarse-node cost despite small leafdelta,so small8leaf examples do not establish a general source tree budget.',errors='DP floats select candidates only. Geometric factors exact Fraction; selected and baseline costs exact rational plus prime-log coefficients evaluated by384-bit Arb. No rigorous global optimum claim. Tensor formulas exact,not expanded2^n leaves.')
(ROOT/'r502_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;9 box geometries x4 DP variants,3 regular tensor formulas;no global tree theorem')
