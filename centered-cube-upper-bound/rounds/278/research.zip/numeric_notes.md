# R278 actual moving retained-window screen

Executed6 physical geometries with sameL and Aplus legs, stages2/2/2,n8/64/512:12 labelled rows and11 unique core/collar integral triplets per precision. Functions phi,C,P are copied self-contained from the prior actual-kernel implementation; no old18-row or J-window suite was rerun or changed.

Actual F=sqrt(P_s,L P_s,A/Omega_L),Omega_L=min(1,C(r)/L),W side1+epsilon,epsilon=.5/(8sqrt n). Core and left/right collars are separately integrated at40/60 with all hard/phi-core endpoints split. All tested core bounds exp(−eta(1−Omega_L)),eta25/2^69,pass. Hard s0 same-L has exact core1 and zero collar; plus core=sqrt(8/9),also zero collar. These are genuine compact-support cases.

For positive s, collar/(epsilon sqrt s) ranges through a sampled maximum 0.5251697186482913,at fullsofts1,L.75,r1,Aplus. For nearzero s1e−6,L.5,r.5, the ratio is approximately.4049004(sameL)/.4017753(plus), while the core rises from.000671916 to.00841881 under the small target-scale change. Far displacements2/4 have smaller sampled collar ratios. These finite values do not identify a universal constant or dimension law.

Across179 numeric fields the actual scaled40/60 difference is 2.233954787694440302000284510831723585936518370956705306647801999999999999999999999974401094276807324e-40. Ordinary quadrature is not outward interval arithmetic; passing a bound containing tiny eta is not a numerical proof of its sharp/general constant. Fixed physical receiver kernel factorization supports the displayed repeated-coordinate logs, not an original all-soft/all-scale source/FIRST/high/history/FULL qualification.

Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r278_numeric.py --output /tmp/r278_numeric.json`. Python3.12.14,mpmath1.3.0.

Source SHA256: 2a268740db0d7485dab079d3f894c59bca790636f7e05ce31568dc0cdf85b41e

JSON SHA256: 37bb9aef6680d74cfc0cd6ce96017872754f76b583f8918cf5d2cf1ccf31c133
