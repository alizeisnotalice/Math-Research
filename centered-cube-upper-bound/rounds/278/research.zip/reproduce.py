"""R278 final archive verification and bounded numerical replay."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,sha in manifest['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
print('PASS manifest',len(manifest['sha256']))
if not args.check_only:
 with tempfile.TemporaryDirectory(prefix='r278-replay-') as td:
  for stem in ['r278_numeric','r278_checks','r278_geometry_checks']:
   output=Path(td)/(stem+'.json')
   subprocess.run([sys.executable,str(root/(stem+'.py')),'--output',str(output)],check=True)
   assert output.read_bytes()==(root/(stem+'.json')).read_bytes(),stem
   print('PASS byte-identical replay',stem)
 subprocess.run([sys.executable,str(root/'screen_checks.py')],check=True)
 print('PASS all bounded checks; no FULL or interval certificate')
