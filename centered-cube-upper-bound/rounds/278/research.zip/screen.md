# R278 independent moving-certified large-loss screen

**Verdict: PASS for the following explicit safe collar and paired-scale formulation.** It gives an actual-source payment for a large-loss subset of the original moving-certified positive traffic. It does not pay its low-loss complement or establish the global goal. No R278 author proof was read before this screen.

All cubes have full side length. Set gamma=1+1/n, c_n=gamma^n<e, d=a/(8sqrt(n)), epsilon_h=d/b, W_y=Q_{b+d}(y), and

`Omega_{L,i}=min(1,b C(|y_i-v_i|/b)/L)`,

`barw_L=product Omega_{L,i}`, `Delta_L=sum_i(1-Omega_{L,i})`.

Use the old R224 exact-min overlap theorem with R=b, m=L, M=b, and target A in [L,b]. Put `kappa=25/2^68`, `eta=kappa/2`. Its one-coordinate source-centered Q_b(y) half-mass is at most `exp[-eta(1-Omega_L)]`. This is the old fixed-parameter input; the new task is its valid collar, adaptive positive cover, and original-source settlement. The actual pure weight is compared to barw_L, never to a smaller barw_b without a proof.

## 1. A safe collar that retains the target hard term

For fixed common soft s in [0,1] and a<=L<=A<=b, write the one-coordinate half-kernel as `sqrt(P_{s,L} P_{s,A})/sqrt(Omega_L)`. On `Q_{b+d}(y)\Q_b(y)` the source hard component vanishes (apart from irrelevant Lebesgue endpoints). Splitting the square root of the target mixture gives two positive collar terms.

For the target-hard term to be nonzero, with D=|y-v| and epsilon_h=d/b,

`D/b <=1+epsilon_h/2<=17/16`.

A self-contained uniform bound is `C(D/b)>=V(D/b)>1/512`, where V=h*h*w. Indeed h*h is a probability density supported in [-1,1]; restricting the Laplace parameter to [1/2,1] gives

`V(r)>= (1/2)exp(-5)>1/(2*3^5)>1/512` for r<=17/16,

since `2(r+1)<=33/8<5` and e<3. Also Omega_L>=C because L<=b. The total collar length is d and `(LA)^(-1/2)<=2/b`. Thus this term is at most

`2sqrt(512) epsilon_h sqrt(s(1-s)) <=2sqrt(512)epsilon_h sqrt(s)`.

For the target-soft term, enlarge both soft profiles pointwise to physical scale b. The old inequality `phi(x)phi(x-r)<=V(r)<=C(r)<=Omega_L` gives at most

`2epsilon_h s<=2epsilon_h sqrt(s)`.

As `2sqrt(512)+2<48`, the complete one-coordinate collar is at most `48epsilon_h sqrt(s)`. No target-hard term was dropped. Adding this to the old core half-mass and using `1+x<=exp(x)` gives the all-position tensor bound

`integral_{W_y} sqrt(P_{s,L}(x-y)P_{s,A}(x-v)/barw_L(y,v)) dx`

`<=exp[-eta Delta_L+48exp(eta)n epsilon_h sqrt(s)]`.                (S1)

The source tensor structure here is that of fixed receiver kernels; no product structure is imposed on nu or beta. The constant 48 is conservative and needs no additional small-dimension exception. Since `n epsilon_h<=sqrt(n)/8`, its worst collar exponent is at most `6exp(eta)sqrt(n)`.

## 2. Actual moving maps permit one paired-scale menu

The two actual targets are `A_1(L)=L` and `A_2(L)=min(b,gamma L)`. Use the n common soft nodes sigma=k/(n+1) from R276. For actual s in [(k-1)/n,k/n], both source and target satisfy the coefficientwise density domination, and

`sigma<=min(1,s+1/n)`.

Round input L upward to B on the same gamma grid with at most n+1 nodes. For either moving map,

`A_i(L)<=A_i(B)<=gamma A_i(L)`, `B<=A_i(B)<=b`.

Thus the paired source and target node remain within the exact old R224 domain. There is no independent target-scale menu in the actual two-map application. Both density approximations together give a factor c_n^2 on the half-kernel. Also

`barw_B<=barw_L`, `Delta_B>=Delta_L`.

In particular the geometric loss does not need an O(1) downward rounding correction: upward input rounding strengthens it.

Finally the original band gives `c_j g<=gamma min(L,R)<=gamma L`, so

`w_g>=c_n^(-1)barw_L`.

This contributes exactly c_n^{1/2} on the original square-root domination. The full kernel cover therefore costs c_n^{5/2}<e^{5/2}, with at most n(n+1) nodes per moving leg. No node FIRST, classifier, or posterior is introduced.

## 3. Two valid loss-gate versions

### Simple source-loss threshold

For the event `Delta_L>=T`, a selected upward node also has Delta_B>=T. S1 and the finite cover give, per actual moving leg,

`integral envelope <=c_n^(5/2)n(n+1) exp[-eta T+6exp(eta)sqrt(n)]`.     (S2)

This directly establishes the initially proposed form with all finite fees visible.

### Refined soft-dependent gate

A more useful exact gate, suggested after the first independent collar/cover derivation, is

`G_T={eta Delta_L>=48exp(eta)n epsilon_h sqrt(min(1,s+1/n))+T}`,

where T>=0. Because the selected sigma is no larger than min(1,s+1/n) and Delta_B>=Delta_L, G_T implies the **static node gate**

`eta Delta_B>=48exp(eta)n epsilon_h sqrt(sigma)+T`.

The latter depends only on the fixed node and sources, so S1 bounds each gated node half-mass by exp(-T). The same finite cover then yields

`integral gated envelope <=c_n^(5/2)n(n+1)exp(-T)`.                 (S3)

This is a genuine pointwise transfer of the original gate to a stronger node loss, not a claim that a mean-centered density approximation controls a likelihood event. At s=0 the positive node is still legitimate and the displayed safety term is retained. Actual zero p or zero target contributes zero without taking a logarithm.

## 4. Original positive traffic and every outside fee

Let `E_i={p_y w_g(v)<=K K_i(v)}`, K>0, and restrict the original currently unpaid positive mother to E_i and one of the loss gates above. On E_i,

`p_y 1_Ei <=sqrt(K) sqrt(p_y K_i/w_g)`.

The original near hard-source support implies x in W_y. First use hardcap/q<=16/3 on the actual valid receiver domain. Only then extend the remaining positive x integral to its W_y envelope. At fixed `(omega,V,j,y,t)`, the complete original two posterior slots are independent of x; their full probability masses integrate to at most one. The score is at most n, and the entire original j-band clock sum is at most n, as proved in R276. Original high, terminal, capture, history and current-unpaid masks may be removed positively only in this order. No negative credit is altered.

Consequently, per moving leg, including the original outside 2 Lambda,

`P[E_i and G_T] <= (32 Lambda/3)sqrt(K)c_n^(5/2)n^3(n+1) exp(-T) W_beta`.   (S4)

Replacing G_T by Delta_L>=T gives the corresponding price with `exp[-eta T+6exp(eta)sqrt(n)]`. The generic arbitrary-A cover could alternatively use n(n+1)^2 nodes and is valid but unnecessary for the two actual moving maps.

The same pre-frozen terminal-leaf ledger gives `W_beta<=W_hi<=||f||_1`; no nu<=beta or source-coordinate independence is used. The factor sqrt(K) remains explicit. If K is not a common fixed scalar, its factor or the associated outer-data-dependent threshold remains inside the actual source expectation.

For the union of both moving certification events, summing S4 costs at most a factor 2. For example, take

`T=log_+[(64 Lambda/3)e^(5/2)sqrt(K)n^3(n+1)/epsilon]`.

Then the original positive union restricted to G_T costs at most `epsilon W_beta<=epsilon||f||_1`. This includes the cases where log_+ is zero; the unreduced prefactor is then already <=epsilon. If the gate exceeds the possible loss it is empty. The loss threshold itself is `eta^(-1)[O(sqrt(n)*sqrt(s+1/n))+O(log n+log_+(sqrt(K)/epsilon))]`, with the fixed tiny eta explicitly retained.

After the already paid J-certified subset is removed, original good implies certification by at least one moving target, but the original three-leg Q remains in every original bad/high definition. This argument pays only the displayed additional large-loss positive subset, not its low-loss complement, and never claims a new whole-traffic or signed closure. Any use alongside other paid subsets requires a disjoint current-positive allocation or a bound on their actual union, rather than billing overlapping positive mass twice.

## 5. Actual bounded arithmetic evidence

A local standard-library Python run passed **290 exact Fraction assertions** for the safe collar constants, paired scale ordering under a generic upward mesh, and Delta_B>=Delta_L, at n in {1,2,8}. A second bounded run passed **96 exact Fraction assertions** for the actual two moving maps and common-soft node gate ordering at n in {1,2,8,64}. These calculations test scalar algebra only; they do not replace the analytic collar/overlap proof and are not FULL or interval integration evidence.

Reproduce the 96 actual-map assertions:

```python
from fractions import Fraction as F
checks=0
for n in (1,2,8,64):
    gamma,a,b=F(n+1,n),F(1,2),F(1)
    grid=[a]
    while grid[-1]<b:
        grid.append(min(b,grid[-1]*gamma))
    for L in (F(1,2),F(3,5),F(4,5),F(1)):
        B=next(q for q in grid if q>=L)
        for i in (1,2):
            A=L if i==1 else min(b,gamma*L)
            Ap=B if i==1 else min(b,gamma*B)
            assert B<=Ap<=b;checks+=1
            assert A<=Ap<=gamma*A;checks+=1
    for s in (F(0),F(1,10),F(1,2),F(1)):
        ns=n*s
        k=max(1,(ns.numerator+ns.denominator-1)//ns.denominator)
        sigma,U=F(k,n+1),min(F(1),s+F(1,n))
        assert sigma<=U;checks+=1
        assert s<=gamma*sigma and 1-s<=gamma*(1-sigma);checks+=1
print('PASS',checks,'exact Fraction paired-map/common-soft gate assertions')
```

The separate 290-assertion run used the same rational gamma grid, input scales {1/2,3/5,4/5,1}, target interpolation fractions {0,1/3,2/3,1}, and coordinate C values generated from {1/1000,1/10,1/2,1}, capped after adding (i mod 3)/100. It checked each scale ordering/ratio and the loss monotonicity. The two constant assertions were `1/(2*3^5)>1/512` and `512<23^2`. No R278 author proof was read, and no repository/Git/PDF action was taken.

Full code for the 290-assertion run:

```python
from fractions import Fraction as F
checks=0
assert F(1,2*3**5)>F(1,512);checks+=1
assert 512<23**2;checks+=1
for n in (1,2,8):
    gam,a,b=F(n+1,n),F(1,2),F(1)
    grid=[a]
    while grid[-1]<b:
        grid.append(min(b,grid[-1]*gam))
    up=lambda x:next(B for B in grid if B>=x)
    for L in (F(1,2),F(3,5),F(4,5),F(1)):
        for f in (F(0),F(1,3),F(2,3),F(1)):
            A=L+f*(b-L)
            B,D=up(L),up(A)
            assert a<=B<=D<=b;checks+=1
            assert B<=gam*L and D<=gam*A;checks+=1
            for c in (F(1,1000),F(1,10),F(1,2),F(1)):
                cs=[min(F(1),c+F(i%3,100)) for i in range(n)]
                old=sum(1-min(F(1),b*C/L) for C in cs)
                new=sum(1-min(F(1),b*C/B) for C in cs)
                assert new>=old;checks+=1
print('PASS',checks,'exact Fraction collar / paired-scale-loss assertions')
```
