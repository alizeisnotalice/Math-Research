# 第278轮：移动认证大缺口付款与剩余时钟几何

一般中心立方体极大算子 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮新增一项原来源付款，并准确给出余下几何区域；不将单行时钟估计冒充全局结论。

## 新增解析结论

令 eta=25/2^69，epsilon_h=a/(8b sqrt(n))，Delta_L(y,v)=Σ_i[1−min(1,b C(|y_i−v_i|/b)/L)]。保原两移动认证事件 E_i={p_y w_g(v)≤K K_i(v)}，定义

D_T={eta Delta_L≥48 e^eta n epsilon_h sqrt(min(1,s+1/n))+T}。

在原当前未付正交通中，D_T∩(E_1∪E_2)的贡献至多

(64Λ/3)e^(5/2)√K n³(n+1)e^(−T) Wβ。

取 T=log_+[(64Λ/3)e^(5/2)√K n³(n+1)/epsilon]，即可支付 epsilon Wβ≤epsilon||f||₁。全 soft s∈[0,1]、两移动尺度的配对节点、完整原后验、全部比例带/时钟与真实接收窗口均保留。固定K/epsilon时，剩余好来源满足 Delta_L≤eta^(-1)[6e^eta sqrt(n)+T]，更精细为 O_eta(sqrt(ns)+1+log(n+2))。tiny eta明确保留，有限维数付款门可能为空，未声称新增域占正比例。

R224固定exact-min核界是旧输入。本轮新增的是保目标hard的collar、实际损失门的静态节点转移，以及raw-cert全L1回代到原来源；不重复登记旧fixed-column结论。

## 全局几何及剩余缺口

辅助证明把输入窗口均值联系到实际clamp缺口，保另一来源u的缺口和n(b/L−1)尺度项。不能只由小Delta_L(v)推出小正均值。

在固定实际L的原时钟上，Delta_L(v)≤D给完整两后验正score的行价≤1+2D[1+log_+(n/D)]；q_t>L的薄尾仅费≤1。这一单行价在本轮余域为根阶乘对数，但乘回原接收/来源母量后尚无线性来源帽。真正还缺接收核、尺度选择与完整来源的联合结算。原三核Q、bad/high与FIRST不改；不假设nu≤beta、u也有小缺口或来源坐标独立，不重新使用旧负信用。

## 审核修正

独立命题初筛先于作者阅读。主稿最终审计要求在半核包络式(9)显式加1_W_y，并把式(10)限定于W_y/原near-hard支持；已修复，费用不变。安全collar常数48来自解析比较，不采用样本拟合或不必要的强化常数。作者探索的16点态强化和中点积分不归档为本轮依据。

辅助几何的未定位T_small/4X常数引用已去掉，只保B乘未付原母量的结论；不借该引用宣称source付款。

## 实际本机验证

本机Python3.12.14/mpmath1.3.0，遵守已加载L03技能的证据边界。

- 6物理几何，三阶段各2例，每例same-L和Lplus两腿，共12行、11个独立核心/两侧collar积分组。含s=0、1、近零，L不等和位移到4；40/60位179字段最大差约2.234e−40。目标hard在collar不被误删；hard输入s0的collar精确为零。
- 主代理完整重跑积分脚本，JSON与保存结果逐字节相同。12条保存collar和12条张量界再检查通过；这没有提高原60位数据的可信精度。
- 12组Fraction配对节点模型覆盖n=1,2,8,32,64,512，验证尺度比、soft上节点、损失单调及几何门转移；原有理数C只是代数profile，不冒称FULL几何实例。检查脚本主代理重跑JSON字节一致。
- 独立screen的96+290项有理检查实际执行通过；辅助几何另有有界标量复现。有限计算不代替一般解析证明，未使用向外舍入区间积分。

解压后在有mpmath的Python运行 python reproduce.py；默认重跑全部必要检查，--check-only仅检查保存哈希。本机环境可用：
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 reproduce.py

只保最终LaTeX文本、必要辅助几何、独审及复现材料，不编译PDF。复用4个既有Agent；实际模型扣额数据不可得，不估计成本比例。

最终主证明独审PASS，SHA256 3f8697b3134490cf9d3e89ff83ce397690bf50b76c7991ed42f3e7ff503935ea。辅助几何独审PASS，绑定SHA256 6f4bb65a59338088580a6b9820b44b9eb44522ca703cea437c635a4774e8d802。辅助新增9个实际一维F_A核配置，三阶段各3例，40/60位共18次计算，最大精度差约3.459e-41；另10项G8端点、25项严格激活、12项逆函数域和原4项标量检查通过。主代理也重跑该checker，JSON字节一致。它们不认证全局来源预算。
