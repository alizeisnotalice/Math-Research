#!/usr/bin/env python3
"""R278 final geometry: original four scalar checks plus necessary endpoint screens."""
import argparse,contextlib,hashlib,io,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as m
FINAL_MARKDOWN_SHA256='6f4bb65a59338088580a6b9820b44b9eb44522ca703cea437c635a4774e8d802'
ORIGINAL_CODE="import sys\nsys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')\nfrom fractions import Fraction as F\nimport mpmath as m\nm.mp.dps=60\nchecks=0\nfor L,b,d in [(F(1),F(2),F(0)),(F(3,2),F(2),F(1,4)),(F(2),F(2),F(3,4))]:\n    lhs=(b/L)*(1-L/b+(L/b)*d)\n    assert lhs==b/L-1+d;checks+=1\nn=m.mpf(64);D=m.mpf(8);cut=D/n\nvalue=m.quad(lambda h:n,[0,cut])+m.quad(lambda h:D/h,[cut,1])\nclosed=D*(1+m.log(n/D))\nassert abs(value-closed)<m.mpf('1e-50');checks+=1\nprint('PASS',checks,'scalar algebra/integral checks; no source model added')\n"

def necessary_checks():
    with m.workdps(70):
        cases=[(2,F(1),F(0),None),(8,F(3,2),F(0),None),(8,F(2),F(16),None),(64,F(3,2),F(32),None),(64,F(2),F(1,1000),None),(512,F(3,2),F(1),None),(512,F(3,2),F(512,3),None),(8,F(3,2),F(1),F(1,2)),(8,F(3,2),F(1),None),(8,F(3,2),F(8),None)]
        rows=[]
        def mm(x):return m.mpf(x.numerator)/x.denominator
        for n,L,D,override in cases:
            a=F(1);b=F(2);gamma=F(n+1,n);end=min(b,gamma*L) if override is None else override;H=1-a/L;dd=mm(D);nn=m.mpf(n);hh=mm(H)
            if D==0 or H==0:closed=quad=m.mpf(0)
            elif D/n>=H:closed=quad=nn*hh
            else:
                cut=dd/nn;closed=dd*(1+m.log(nn*hh/dd));quad=m.quad(lambda x:nn,[0,cut])+m.quad(lambda x:dd/x,[cut,hh])
            envelope=m.mpf(0) if D==0 else dd*(1+max(m.mpf(0),m.log(nn/dd)))
            assert closed<=envelope+m.mpf('1e-55') and abs(closed-quad)<m.mpf('1e-55')
            late=nn*max(m.mpf(0),m.log(mm(end/L)));assert late<=1
            first=late+mm(L/a)*closed;bound=1+2*envelope;assert first<=bound+m.mpf('1e-55')
            rows.append({'n':n,'a':'1','b':'2','L_exact':str(L),'D_exact':str(D),'m_endpoint_exact':str(end),'empty_clock':end<a,'early_h_max_exact':str(H),'early_integral_closed':m.nstr(closed,90),'early_integral_quad':m.nstr(quad,90),'thin_q_gt_L_price':m.nstr(late,90),'extended_first_bound':m.nstr(first,90),'final_row_bound':m.nstr(bound,90),'empty_actual_clock_price':'0' if end<a else None})
        activation=[];L=F(3,2);n=8;gamma=F(9,8)
        for c in [F(1,2),F(1),F(3,2),F(25,16),F(2)]:
            delta=max(F(0),1-c/L)
            for q in [F(1),F(5,4),L,F(13,8),gamma*L]:
                active=c<q
                if q<=L:assert active==(delta>1-q/L)
                else:assert active==(delta>0 or (delta==0 and L<=c<q))
                activation.append({'c_exact':str(c),'q_exact':str(q),'delta_exact':str(delta),'active_strict':active,'region':'q<=L' if q<=L else 'thin_q>L'})
        inverse=[]
        for ratio in [F(1,2),F(3,4),F(1)]:
            for deficit in [F(0),F(1,4),F(999999,1000000),F(1)]:
                argument=ratio*(1-deficit)
                if deficit<1:assert 0<argument<=1
                else:assert argument==0
                inverse.append({'L_over_b_exact':str(ratio),'deficit_exact':str(deficit),'inverse_argument_exact':str(argument),'finite_inverse_domain':deficit<1,'q1_means_limit_infinity_not_finite_inverse':deficit==1})
        phi_half=m.mpf('.5')-m.expint(3,1);ch=1-phi_half;assert ch>m.mpf('.5')
        return {'G8_endpoint_envelopes':rows,'strict_activation_cases':activation,'inverse_range_cases':inverse,'phi_half':m.nstr(phi_half,90),'c_h':m.nstr(ch,90)}

def actual_kernel_checks():
    # b=1; integral of phi from zero uses E4 and exact hard-overlap lengths.
    menu=[('initial',8,'0','.5','same','0'),('initial',8,'.5','.75','plus','.25'),('initial',8,'1','1','b','.5'),
          ('stress',64,'1e-20','.5','b','.5'),('stress',64,'0','.75','same','1'),('stress',64,'.5','1','plus','2'),
          ('expanded',512,'1','.5','plus','4'),('expanded',512,'.5','.75','b','0'),('expanded',512,'1e-8','1','same','.25')]
    def run(dps):
        with m.workdps(dps):
            E=lambda x:m.expint(4,x)
            def softprim(x):
                t=abs(x)
                val=t-E(m.mpf('.5')-t)+E(m.mpf('.5')+t) if t<=m.mpf('.5') else m.mpf('.5')-E(t-m.mpf('.5'))+E(t+m.mpf('.5'))
                return val if x>=0 else -val
            def C(r):
                return 1-r+E(0)-E(r)-E(1)+E(r+1) if r<=1 else E(r-1)-2*E(r)+E(r+1)
            ch=1-(m.mpf('.5')-m.expint(3,1));rows=[]
            for phase,n,ss,ll,leg,rr in menu:
                s,L,r=map(m.mpf,(ss,ll,rr));A=L if leg=='same' else min(m.mpf(1),L*(1+m.mpf(1)/n)) if leg=='plus' else m.mpf(1)
                def F(rad):
                    low=(rad-A/2)/L;high=(rad+A/2)/L
                    hard=max(m.mpf(0),min(high,m.mpf('.5'))-max(low,-m.mpf('.5')))
                    return (1-s)*hard+s*(softprim(high)-softprim(low))
                F0,Fr=F(0),F(r);cv=C(r);delta=max(m.mpf(0),1-cv/L);alpha0=1-F0;loss=F0-Fr
                lower=max(m.mpf(0),delta-alpha0);upper=(delta+1/L-1)/ch;clamp=min(m.mpf(1),cv/L)
                tol=m.mpf(10)**(-dps+8)
                assert -tol<=alpha0<=s+tol and Fr<=clamp+tol and lower<=loss+tol and loss<=upper+tol
                assert loss>=max(m.mpf(0),delta-s)-tol
                row={'phase':phase,'n_for_plus':n,'s':ss,'L':ll,'target_leg':leg,'r':rr}
                for k,v in [('A',A),('F0',F0),('F_r',Fr),('C_r',cv),('delta',delta),('alpha0',alpha0),('loss',loss),('lower',lower),('upper',upper),('lower_margin',loss-lower),('upper_margin',upper-loss),('clamp_margin',clamp-Fr)]:row[k]=m.nstr(v,75)
                rows.append(row)
            return rows
    low,high=run(40),run(60);worst=m.mpf(0)
    with m.workdps(80):
        for x,y in zip(low,high):
            for key in ['A','F0','F_r','C_r','delta','alpha0','loss','lower','upper','lower_margin','upper_margin','clamp_margin']:
                a,b=m.mpf(x[key]),m.mpf(y[key]);worst=max(worst,abs(a-b)/max(1,abs(b)))
        assert worst<m.mpf('1e-30')
        return {'mp40':low,'mp60':high,'max_scaled_precision_difference':m.nstr(worst,75),'phase_counts':{'initial':3,'stress':3,'expanded':3},'method':'E4 odd primitive and exact hard overlap, ordinary mpmath40/60; no interval certificate or FULL source model.'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args();buf=io.StringIO();ns={}
    with contextlib.redirect_stdout(buf):exec(compile(ORIGINAL_CODE,'r278_geometry_final.md:original-code','exec'),ns)
    extra=necessary_checks();kernel=actual_kernel_checks()
    out={'schema':'R278-final-geometry-aux-replay-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'reviewed_final_markdown_sha256':FINAL_MARKDOWN_SHA256,'original_code_sha256':hashlib.sha256(ORIGINAL_CODE.encode()).hexdigest(),'counts':{'original_scalar_checks':ns['checks'],'new_G8_endpoint_checks':len(extra['G8_endpoint_envelopes']),'new_strict_activation_checks':len(extra['strict_activation_cases']),'new_inverse_range_checks':len(extra['inverse_range_cases']),'actual_1D_kernel_geometries':9,'actual_1D_precision_runs':18},'actual_kernel_checks':kernel,'original_stdout':buf.getvalue(),'additional_checks':extra,'scope':['Nine actual one-dimensional kernel geometries at40/60 digits supplement scalar geometry/clock envelopes and exact rational threshold checks; no full posterior or source model.','D0, D>n, early interval length0, thin q>L, and an empty clock are explicit. Finite passing examples do not prove G2-G8.','Final G5 retains only B times the unpaid original mother measure, including its outside constant. No Tsmall<=4X or8LambdaBX source payment is certified.','Original code mp60; added scalar integrals mp70 are ordinary, not interval certificates. No FULL/history/source-payment or main proof certification.']}
    text=json.dumps(out,sort_keys=True,indent=2)+'\n'
    if args.output:args.output.write_text(text)
    else:print(text,end='')
if __name__=='__main__':main()
