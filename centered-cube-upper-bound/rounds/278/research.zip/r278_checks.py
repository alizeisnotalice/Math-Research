#!/usr/bin/env python3
"""R278 saved actual rows: constant48 checks and exact paired-node gate algebra."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator

def saved_checks(data):
 out=[]
 with mp.workdps(90):
  eta=mp.mpf(25)/2**69
  for row in data['mp60']['rows']:
   n=row['n'];s=mm(row['s']);epsilon=mp.mpf(row['epsilon']);omega=mp.mpf(row['Omega_L']);core=mp.mpf(row['core_integral']);collar=mp.mpf(row['collar_integral']);total=mp.mpf(row['retained_window_integral'])
   assert abs(core+collar-total)<mp.mpf('1e-55')
   collarbound=48*epsilon*mp.sqrt(s);Delta=n*(1-omega);actual=n*mp.log(total);bound=-eta*Delta+48*mp.exp(eta)*n*epsilon*mp.sqrt(s)
   assert collar<=collarbound+mp.mpf('1e-50') and actual<=bound+mp.mpf('1e-45')
   assert abs(actual-mp.mpf(row['tensor_log_retained_integral']))<mp.mpf('1e-50')
   out.append({'stage':row['stage'],'n':n,'target_leg':row['target_leg'],'s_exact':row['s'],'collar_saved':row['collar_integral'],'collar_48_bound':enc(collarbound),'collar_48_margin':enc(collarbound-collar),'tensor_Delta':enc(Delta),'tensor_log_actual_from_saved60':enc(actual),'tensor_log_48_bound':enc(bound),'tensor_log_48_margin':enc(bound-actual)})
 return out

def paired_nodes():
 rows=[];eta=F(25,2**69)
 for n in [1,2,8,32,64,512]:
  gamma=F(n+1,n)
  for profile in [0,1]:
   L=F(1,2) if profile==0 else F(1) if n in [1,64] else F(3,4);top=min(F(1),gamma*L);B=top if profile==0 else (L+top)/2
   assert L<=B<=gamma*L
   A=[L,min(F(1),gamma*L)];Anode=[B,min(F(1),gamma*B)];assert all(a<=b<=gamma*a for a,b in zip(A,Anode))
   k=max(1,n//2) if profile==0 else n if n in [1,64] else min(n,n//2+1);s=F(k-1,n) if profile==0 else F(k,n);sigma=F(k,n+1);sbar=min(F(1),s+F(1,n));assert 0<=sigma<=sbar<=1
   c=[F(1)]*n if profile==1 and n in [1,64] else [[F(1,4),F(3,4),F(1)][i%3] for i in range(n)]
   omegaL=[min(F(1),x/L) for x in c];omegaB=[min(F(1),x/B) for x in c];assert all(b<=a for a,b in zip(omegaL,omegaB));DeltaL=sum(1-x for x in omegaL);DeltaB=sum(1-x for x in omegaB);assert DeltaB>=DeltaL
   # Geometric-loss gate, not a rebuilt likelihood good set. Nonnegative
   # squares remove irrational sqrt from both premises and conclusions.
   H=eta*DeltaL/2;T=eta*DeltaL/4;leftL=eta*DeltaL-T;leftB=eta*DeltaB-T
   assert leftL>=0 and leftL**2>=H**2*sbar
   assert leftB>=0 and leftB**2>=H**2*sigma
   rows.append({'stage':'initial' if n<=8 else 'stress' if n<=64 else 'expanded','n':n,'profile':profile,'b_exact':'1','gamma_exact':str(gamma),'L_exact':str(L),'B_exact':str(B),'A_at_L_exact':list(map(str,A)),'A_at_B_exact':list(map(str,Anode)),'soft_k':k,'s_exact':str(s),'sigma_exact':str(sigma),'sbar_exact':str(sbar),'Delta_L_exact':str(DeltaL),'Delta_B_exact':str(DeltaB),'eta_exact':str(eta),'H_exact':str(H),'T_exact':str(T),'premise_nonnegative_side_exact':str(leftL),'premise_square_margin_exact':str(leftL**2-H**2*sbar),'conclusion_nonnegative_side_exact':str(leftB),'conclusion_square_margin_exact':str(leftB**2-H**2*sigma),'zero_loss_case':DeltaL==0,'C_profile_scope':'Explicit positive rational clamp numerators; not asserted to be actual C(source distances).'} )
 return rows

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();inputpath=Path(__file__).with_name('r278_numeric.json');raw=inputpath.read_bytes();data=json.loads(raw);actual=saved_checks(data);exact=paired_nodes()
 out={'schema':'R278-constant48-paired-node-checks-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_basename':'r278_numeric.json','input_sha256':hashlib.sha256(raw).hexdigest(),'saved_actual_script_sha256':data['script_sha256'],'counts':{'saved_actual_row_collar_checks':len(actual),'saved_actual_tensor_checks':len(actual),'exact_paired_node_cases':len(exact),'target_scale_ratio_checks':2*len(exact),'soft_forward_checks':len(exact),'loss_monotonicity_checks':len(exact),'static_geometric_gate_transfers':len(exact),'zero_loss_gate_cases':sum(r['zero_loss_case'] for r in exact)},'saved_actual_checks':actual,'exact_paired_node_checks':exact,'scope':['Reads adjacent r278_numeric.json only; no new quadrature or old-menu rerun. 90-digit arithmetic here operates on saved60-digit strings and does not improve their original accuracy. Main analytic safe collar constant is48, not a sampled-fit constant.','Repeated-coordinate tensor upper bound is -eta Delta+48 exp(eta)n epsilon sqrt(s). Saved numerical core consistency and exact decomposition support only these finite row checks, not tiny-gap certification.','Paired-node target scales and monotone losses use exact Fractions. Static gate is geometric loss: eta Delta_L>=H sqrt(sbar)+T,Delta_B>=Delta_L,sigma<=sbar imply eta Delta_B>=H sqrt(sigma)+T, verified by nonnegative-side squared comparisons.','No pnode/likelihood good gate is created; no unrelated K M transfer is tested. Rational C profiles are algebraic numerators only. No FULL/FIRST/high/history/source-payment or dimension-order theorem certified.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'input_sha256':out['input_sha256']}))
if __name__=='__main__':main()
