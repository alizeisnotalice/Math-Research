# R278 final auxiliary geometry audit

Verdict: no blocking G2–G8 inequality, inverse-domain, orientation, or clock-threshold error found, under the stated fixed-parameter assumptions a<=L,R<=b<=2a,L<=A<=b. This is not an audit of the main proof or a source-payment certificate. The final version removes the unresolved numerical mother-mass reference; it only retains B times the still-unpaid original mother measure including its outside constant. That is the appropriate narrow scope.

Reviewed final file SHA256: 6f4bb65a59338088580a6b9820b44b9eb44522ca703cea437c635a4774e8d802. The diff from the earlier note changes only that G5 payment paragraph; no formula/code was altered.

## G2 lower and upper geometry

The lower step F_A(r)<=min(1,b C(r/b)/L) is valid: f_s<=F=max(h,phi), F is even nonincreasing, so F(x/L)<=F(x/b) for L<=b. The A-window is contained in the b-window around the same r. The L denominator remains, giving exactly b C/L rather than a wrongly normalized C. A>=L contains the complete hard component at r0, hence alpha0=1−F_A(0)<=s. Thus a_A(r)>=(delta_L(r)−alpha0)+, in particular a_A>=delta_L−s; no positive soft tail or hard endpoint is discarded.

The derivative of a_A is g(r−A/2)−g(r+A/2),nonnegative and at most1/L a.e. even at s0 in the piecewise-linear sense. On0<D<1,Cprime(D)=phi(D+.5)−1<=−c_h,with c_h=1−phi(.5)>.5; beyond1,C remains decreasing. Consequently1−C>=c_h min(D,1). The clamp inequality1−C<=1−L/b+(L/b)delta is in the correct direction and is equality only in the active case. Together with a_A<=min(1,r/L)<=(b/L)min(1,r/b), it yields the stated c_h inverse times(delta+epsilon_L). The signed mean is sum a(u)−a(v),so G3/G4 signs and the negative v contribution are correct. The n(b/L−1) term can genuinely be linear and is not omitted.

## Inverse range and plateau

C is continuous and strictly decreasing from1 towards0, but0 is not attained at finite radius. Thus C inverse has finite domain(0,1]. For0<=q<1,the argument(L/b)(1−q) lies in(0,1]; q1 requires the limit at infinity and is separately defined by Psi(1)=F_A(0). For L=b,q0 maps to radius0; for L<b it maps to the positive plateau boundary. Finite source radii have delta<1.

At positive deficit, the inverse representation is exact. At zero deficit a_A lies between0 andPsi(0), so subtracting the u-plateau remainder and adding the v-plateau remainder gives exactly G5. In particular the N0(u)/N0(v) placement is correct. L=b collapses the plateau and gives equality. This does not introduce a paid source moment or make the source-u contribution disappear.

## Full posterior canonical clock

At q=c_jt<=L,the original strict activation bC<q is equivalent to delta_L>1−q/L,including q=L. At q>L,positive-deficit coordinates are active and zero-deficit coordinates need the additional actual radial test L<=bC<q. The note preserves this information and does not falsely infer k0 on a D0 mask in the thin late interval. Since m<=gamma L,the whole late contribution is bounded by n loggamma<=1.

For q<L,Delta(v)<=D gives k(v)<=min(n,D/(1−q/L)); positive pair score<=k(v) allows integration against both unconditioned full posteriors. No renormalized v-small law or independence is used. Substitution h=1−q/L gives dt/t<=L/a abs(dh),and extending the early interval to h in[0,1−a/L] only enlarges it.

For D0 the early integral is defined0 without evaluating0/h at h0. For D>0,if D/n exceeds the upper h endpoint,the integral is nH<=D. Otherwise it is D[1+log(nH/D)]<=D[1+log_+(n/D)],using H<=1. This also covers D>n,where the log-plus is0,not a negative logarithm. L/a<=2 and the late bound yield G8. Empty original clocks have actual price0; the displayed extended envelope can remain positive. All relevant endpoints are guarded in the replay checks.

## Payment boundary and final correction

The earlier independent T_small/4X/8LambdaBX reference was not verifiable from the note because T_small had no exact mother-integral definition. The final file deletes that numerical inference and states only B times the mass of the original mother measure, including its outside constant. No source cap is established here. This correction resolves the scope concern; the unresolved joint dx,p_y,h_R,beta and full-posterior source ledger remains explicitly unpaid. Nothing here pays consumed negative credit or reuses the R276 exception.

## Actual local replay

The original embedded code reproduced PASS4 (three Fraction clamp-algebra identities and one ordinary mp60 elementary integral). The extracted standalone checker additionally passed10 G8 endpoint/envelope cases at mp70 (D0,D>n,early length0,thin q>L,branch equality,and empty clock),25 exact strict-activation cases,and12 exact inverse-domain cases. phi(.5) and c_h were also evaluated by E3 to check the stated numerical side of c_h>.5. None is a new source family or FULL example; the proofs above are analytic and finite passing checks do not certify generality.

Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r278_geometry_checks.py`. Optional `--output PATH` stores its deterministic summary. The exact original Markdown code is embedded, so no original /tmp Markdown path is required for archive replay. The added actual-kernel menu uses E4 primitives rather than quadrature; no old kernel menu was rerun.

Checker SHA256: 89a75d5a7f1eab02e8ce1678ca11b146640d2d148a2d8a8e5cc8662787abffc3


## Bounded actual-kernel three-stage supplement

The parent-requested final supplement was implemented and actually run: 9 distinct one-dimensional geometries, three per stage, at both mp40 and mp60 (18 precision runs). b=1 throughout. Initial n8: (s,L,A,r)=(0,.5,L,0),(.5,.75,min(1,gamma L),.25),(1,1,1,.5). Stress n64: (1e-20,.5,1,.5),(0,.75,L,1),(.5,1,min(1,gamma L),2). Expanded n512: (1,.5,min(1,gamma L),4),(.5,.75,1,0),(1e-8,1,L,.25). n here selects the Aplus ratio only; these are genuine one-dimensional densities, not n-dimensional source models.

F_A(r) was evaluated as the sum of its exact hard-overlap length and the soft E4 primitive difference. The odd primitive integral_0^x phi is x−E4(.5−x)+E4(.5+x) on0<=x<=.5 and .5−E4(x−.5)+E4(x+.5) beyond, with odd continuation. C uses the separate E4 inside/outside expression. Both working precisions checked F_A<=Omega,0<=alpha0<=s, the two G2 bounds, and the weaker lower delta−s bound. Cases include r0, clamp plateau, active clamp, hard s0,pure soft s1,nearzero soft and far radius4. All passed; equality margins at r0 are retained. The maximum scaled40/60 difference among the saved75-digit numerical fields is3.45904960917396e-41. This is ordinary precision comparison, not an interval certificate or proof.

The G8 menu now explicitly includes D=0,n/8,n,2n as well as the earlier thin-tail and empty-clock cases (10 endpoint cases total). Counts are kept separate from actual-kernel geometries. No source payment, FULL qualification, dimension order or main theorem is certified by these finite checks.
