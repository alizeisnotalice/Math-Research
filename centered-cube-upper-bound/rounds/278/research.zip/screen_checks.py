# Independent R278 screen checks; two separately counted bounded suites.

from fractions import Fraction as F
checks=0
for n in (1,2,8,64):
    gamma,a,b=F(n+1,n),F(1,2),F(1)
    grid=[a]
    while grid[-1]<b:
        grid.append(min(b,grid[-1]*gamma))
    for L in (F(1,2),F(3,5),F(4,5),F(1)):
        B=next(q for q in grid if q>=L)
        for i in (1,2):
            A=L if i==1 else min(b,gamma*L)
            Ap=B if i==1 else min(b,gamma*B)
            assert B<=Ap<=b;checks+=1
            assert A<=Ap<=gamma*A;checks+=1
    for s in (F(0),F(1,10),F(1,2),F(1)):
        ns=n*s
        k=max(1,(ns.numerator+ns.denominator-1)//ns.denominator)
        sigma,U=F(k,n+1),min(F(1),s+F(1,n))
        assert sigma<=U;checks+=1
        assert s<=gamma*sigma and 1-s<=gamma*(1-sigma);checks+=1
print('PASS',checks,'exact Fraction paired-map/common-soft gate assertions')

from fractions import Fraction as F
checks=0
assert F(1,2*3**5)>F(1,512);checks+=1
assert 512<23**2;checks+=1
for n in (1,2,8):
    gam,a,b=F(n+1,n),F(1,2),F(1)
    grid=[a]
    while grid[-1]<b:
        grid.append(min(b,grid[-1]*gam))
    up=lambda x:next(B for B in grid if B>=x)
    for L in (F(1,2),F(3,5),F(4,5),F(1)):
        for f in (F(0),F(1,3),F(2,3),F(1)):
            A=L+f*(b-L)
            B,D=up(L),up(A)
            assert a<=B<=D<=b;checks+=1
            assert B<=gam*L and D<=gam*A;checks+=1
            for c in (F(1,1000),F(1,10),F(1,2),F(1)):
                cs=[min(F(1),c+F(i%3,100)) for i in range(n)]
                old=sum(1-min(F(1),b*C/L) for C in cs)
                new=sum(1-min(F(1),b*C/B) for C in cs)
                assert new>=old;checks+=1
print('PASS',checks,'exact Fraction collar / paired-scale-loss assertions')
