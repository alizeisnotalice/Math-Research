# R278 final independent audit

**Verdict: PASS after the explicit common-window correction in equations (9)–(10).** The result pays the stated large-actual-Delta_L, moving-certified subset of the original near positive traffic. Its low-loss complement and the global weak-type goal remain unproved.

## Exact bound source and screening order

Final integrated proof read in full before the last domain repair and then checked specifically at the repair:

- `/tmp/r278_proof.tex.txt`
- SHA256 `3f8697b3134490cf9d3e89ff83ce397690bf50b76c7991ed42f3e7ff503935ea`.

The independent statement proof was saved before reading any R278 author proof:

- `/tmp/r278_screen.md`
- SHA256 `970176d1cc9dd95e47486b661d9ec5ea23ffcd4893f8236818c06fe1600f5826`.

This audit concerns the parent integrated main theorem, not the unused auxiliary geometry note or the author's discarded stronger pointwise/collar constants.

## Verified mathematical chain

1. **Target-hard collar is retained.** On the source-centered collar, the source hard component vanishes except on irrelevant Lebesgue endpoints. A nonzero target-hard component forces normalized displacement at most 17/16. The elementary restriction of V=h*h*w to Laplace parameters in [1/2,1] gives C>=V>1/512 there. Combining the total collar length d, (LA)^(-1/2)<=2/b and Omega_L>=C yields the displayed `2sqrt(512)epsilon_h sqrt(s(1-sigma))` bound. The target-soft term uses the actual old product inequality phi phi<=V<=C<=Omega_L and gives `2epsilon_h sqrt(s sigma)`. Both terms are bounded by their coefficient times sqrt(s), so the conservative 48 is rigorously valid for all independent source/target soft parameters in [0,1]. No target-hard term, soft tail, or n-dependent small-parameter exception is suppressed.

2. **Exact-min core and tensorization are legal.** With R=b, m=L, M=b, target A>=L and hard center y, the R224 normalized one-dimensional quantity is exactly the unweighted core half-integral needed here. The source/node scale is at least b/2. Adding the collar to `exp[-kappa(1-Omega_L)/2]` and tensorizing gives equation (8), including the factor exp(kappa/2) on the collar. This is an explicit added-collar argument, not an application of R224 at R>b or with a smaller denominator.

3. **Actual paired-scale cover has the stated cost and loss direction.** The n common soft nodes cover the closed interval, including s=0,1. Upward input rounding L<=B<=gamma L preserves both actual moving maps: A_1*=B, A_2*=min(b,gamma B), with A_i<=A_i*<=gamma A_i and A_i*>=B. Thus all fixed-node estimates remain in their legal domain and only n(n+1) nodes per leg are needed. The two positive density approximations give gamma^(2n) on the half-product. The denominator decreases upward, so Delta_B>=Delta_L; no loss-threshold rounding fee is missing.

4. **The dynamic loss gate transfers to a static node gate.** The chosen node satisfies sigma_k<=min(1,s+1/n), while Delta_B>=Delta_L. Therefore the original gate in (1) implies the displayed node gate with sigma_k. That gate is static in x at each fixed node/source pair. Equation (8) bounds each such gated node column by exp(-T), and its finite sum gives equation (9). No source-coordinate independence or new FIRST is used.

5. **The common window must be explicit, and now is.** The pre-repair equation (9) had omitted the left-hand indicator 1_{W_y}; its integral input only controlled W_y, so the global literal statement was not justified. The final proof now explicitly defines Fhat_i with this indicator and places 1_{W_y} on the left. Equation (10) is likewise restricted to W_y, in particular the original near-hard support. The actual proof had already established that support before hardcap, so this necessary domain repair changes no constant or claimed paid subset. The corrected source is the SHA-bound version above.

6. **Original posterior/source accounting passes.** On the original certification event the pointwise square-root domination has sqrt(K). The original band gives `w_g>=gamma^(-n)barw_L`, contributing gamma^(n/2) once. Together with the finite menu the total is at most e^(5/2). Original near and hard support imply x in W_y before integrating the hard source. The cap/q<=16/3 is applied only on the genuine receiver domain; x is extended only afterward. For fixed (omega,V,j,y,t), the complete original posterior pair is independent of x and hard z, and its probability mass is at most one. Raw score<=n and the full j-clock sum<=n are both explicitly paid. Multiplication by the original 2 Lambda produces `(32 Lambda/3)e^(5/2)sqrt(K)n^3(n+1)e^(-T)` per leg. Union of two legs costs at most two, exactly as in (2). No extra target-leg, physical, q, source-mass-square, or second recovery factor is hidden.

7. **Threshold, source bridge and residual scope pass.** The log_+ threshold in (3) pays epsilon W_beta for every epsilon>0; when its argument is <=1, T=0 leaves a prefactor already <=epsilon. K is positive under the original threshold qualification and its full dependence is retained; varying outer K must stay in its corresponding source charge or threshold. W_beta refers only to the same pre-frozen disjoint terminal-leaf soft sources, as verified in R276/R277, and does not use nu<=beta. The union can be billed disjointly as E1 and E2\E1, on the currently unpaid positive remainder only. The original three-kernel Q, terminal bad/high definitions, full posterior, and negative credits are not replaced. The consequence `Delta_L<D_n` is only for this remaining near/good slot after the stated payments, not for bad u or Delta_b. The explicit eta^(-1) in D_n is essential and correctly retained; emptiness or tiny coverage of the new gate in finite dimensions is not asserted away.

## Actual bounded arithmetic receipt

At the parent's request the two code blocks of the independent screen were extracted into `/tmp/r278_screen_checks.py` and the combined script was actually executed. It returned:

- PASS 96 exact Fraction paired-map/common-soft gate assertions;
- PASS 290 exact Fraction collar-constant/paired-scale-loss assertions.

Script SHA256: `5115bc07e180a9c9124ae60c11f18149b03087033ef3bded61878c96afb28239`.

These scalar checks are reproducible arithmetic evidence, not proofs of the general overlap/collar theorem, interval integration certificates, or original FULL instances. No old window suite or parent physical-kernel suite was rerun by this auditor; the main proof's 12-row physical numeric receipt is the parent's separate receipt, not an execution claimed here.

No further mathematical repair is necessary in the bound final main proof. No repository, Git state, or PDF was changed. The separate auxiliary geometry interface is not certified by this main audit. Work stops at the requested scope.
