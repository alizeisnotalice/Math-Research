# R278: exact mean/deficit geometry and the canonical-L clock bound

This note proves two deterministic tools on the full original row. Neither is registered as a new global source payment. The original n-scale plateau defect is explicit; the source-u deficit is not assumed bounded. No posterior coordinates are made independent, no source fraction is selected, and no consumed negative credit is reused.

## G1. Original quantities and fixed-parameter mean

Fix actual receiver parameters a<=L,R<=b<=2a, input soft value 0<=s<=1, and target-window side L<=A<=b. They include A=L, A=min(b,gamma L), and A=b. Translate the actual soft source y to zero and write r_i(v)=|v_i−y_i|. Define
\[
 F_A(r)=\int_{r-A/2}^{r+A/2}L^{-1}f_s(x/L)dx,\qquad
 a_A(r)=F_A(0)-F_A(r),
\]
\[
 \delta_L(r)=(1-bC(r/b)/L)_+,\quad
 \Delta_L(v)=\sum_i\delta_L(r_i(v)),\quad
 \mu_A(u,v)=\sum_i[F_A(r_i(v))-F_A(r_i(u))].
\]
This is the parent/R276 v−u orientation. The function F_A is even and nonincreasing on the positive half-line. Its radial loss a_A is continuous, nondecreasing, takes values in [0,1], and has a.e. derivative in [0,1/L]. These statements follow directly from the even decreasing input density bounded by 1/L; they also hold at s=0 with piecewise-linear F_A.

Put
\[
 c_h=1-\phi(1/2)>1/2,\qquad \varepsilon_L=b/L-1,
 \qquad \alpha_0=1-F_A(0)\in[0,s].
\]
The last bound uses A>=L, so the full hard component is contained at r=0. No original strict-soft gate is weakened by proving this closed-family kernel statement.

## G2. Explicit scalar extremal bounds and the signed mean bridge

For every r>=0,
\[
 \boxed{(\delta_L(r)-\alpha_0)_+\le a_A(r)
       \le c_h^{-1}[\delta_L(r)+\varepsilon_L].}          \tag{G2}
\]
Proof of the lower bound: since L,A<=b and f_s<=max(h,phi), enlarging the window and increasing the profile scale gives
\[
 F_A(r)\le\min\{1,bC(r/b)/L\}=1-\delta_L(r).
\]
Thus a_A(r)>=delta_L(r)−alpha_0, and a_A>=0.

For the upper bound, on 0<D<1, C'(D)=phi(D+1/2)−1<=−c_h. Beyond 1 the function C continues decreasing. Hence
\[
 1-C(D)\ge c_h\min(D,1).
\]
On the other hand
\[
 1-C(D)\le1-L/b+(L/b)\delta_L(bD),
\]
with equality when the clamp is active. Since a_A(r)<=min(1,r/L)<= (b/L)min(1,r/b), combining these inequalities gives G2. There is no assumption that the clamp is active, and no support boundary is ignored.

The actual signed mean consequently obeys
\[
 \boxed{\mu_A(u,v)\le
 c_h^{-1}[\Delta_L(u)+n\varepsilon_L]
       -\sum_i(\delta_L(r_i(v))-\alpha_0)_+.}             \tag{G3}
\]
The reverse bound is obtained by exchanging u and v and changing sign. In particular
\[
 -c_h^{-1}[\Delta_L(v)+n\varepsilon_L]
 \le\mu_A(u,v)\le c_h^{-1}[\Delta_L(u)+n\varepsilon_L].  \tag{G4}
\]
The positive part of G3 may be taken to bound mu_A^+. Its negative v term is genuine. It may be kept inside a positive upper estimate; it is not an original signed-traffic credit.

In general n epsilon_L can be linear in n. Small Delta_L(v) alone controls the opposite one-sided mean in G4, and does not provide a small upper bound on mu_A^+ without additional u/scale geometry. No low-soft/near-top-scale/both-small source subclass is declared to solve the middle hard domain.

## G3. Exact inverse-deficit description of the plateau, without replacing it by an unknown moment

C is continuous and strictly decreasing from 1 to 0 on [0,infinity). Let
\[
 r_L(q)=bC^{-1}((L/b)(1-q)),\quad
 \Psi_A(q)=F_A(0)-F_A(r_L(q)),\qquad0\le q<1.
\]
Extend Psi_A(1)=F_A(0). These are explicit scalar functions of the actual phi/C/window integrals. When delta_L(r)>0 one has the exact identity a_A(r)=Psi_A(delta_L(r)); when delta_L(r)=0,
\[
 0\le a_A(r)\le\Psi_A(0)\le c_h^{-1}\varepsilon_L.
\]
Thus, writing N_0(v)=#{i:delta_L(r_i(v))=0},
\[
 \sum_i[\Psi_A(\delta_i(u))-\Psi_A(\delta_i(v))]
                  -\Psi_A(0)N_0(u)
 \le\mu_A(u,v)
 \le\sum_i[\Psi_A(\delta_i(u))-\Psi_A(\delta_i(v))]
                  +\Psi_A(0)N_0(v).                     \tag{G5}
\]
For L=b the plateau collapses, Psi_A(0)=0 and this is an equality. For L<b it explicitly identifies the residual radius information lost by replacing actual positions with the clamped deficits. The plateau residual is generally not a root budget. G5 is a scalar inverse formula, not a new source-moment payment or a free source-rank property.

## G4. The actual activation radius and the whole canonical clock

Now fix the full original row x,y,j. The actual weights are
\(w_t(y,v)=\prod_i\min(1,bC(r_i(v)/b)/(c_jt))\),
and the two posteriors remain the original full Pi_t. Put q_t=c_jt and m=c_jg. The **actual** band gives
\[
 a\le q_t\le m\le\gamma\min(L,R)\le\gamma L,
 \qquad\gamma=1+1/n.
\]
When q_t<=L the strict active-coordinate convention gives the exact relation
\[
 \boxed{k_t(v)=\#\{i:\delta_L(r_i(v))>1-q_t/L\}.}       \tag{G6}
\]
This uses the same actual radial C threshold as the posterior; it is not an auxiliary independent-coordinate model. When q_t>L, the active coordinates consist of those with positive delta_L, plus the zero-deficit coordinates for which L<=bC(r_i/b)<q_t. The latter plateau information is not encoded in Delta_L. However the **entire** q_t>L portion has log-clock length at most log gamma.

For D>=0 retain the actual v-small positive mask 1_{Delta_L(v)<=D}; do not condition or renormalize either posterior. With d_t(v,u)=(k_t(v)−k_t(u))_+,
\[
 \int\!\Pi_t(dv)\Pi_t(du)\,
        d_t(v,u)1_{\{\Delta_L(v)\le D\}}
 \le\min\{n,D/(1-q_t/L)\}\quad(q_t<L).                 \tag{G7}
\]
This follows pointwise from G6 and d_t<=k_t(v), with no condition on u. On q_t>L use d_t<=n. Therefore the full original positive score on that domain has the row bound
\[
 \boxed{\int_{\tau_j}^{g}\!\frac{dt}t
    \int d_t(v,u)1_{\{\Delta_L(v)\le D\}}d\Pi_t(v)d\Pi_t(u)
 \le n[\log(m/L)]_+
   +\frac La\int_0^{1-a/L}\min\{n,D/h\}\,dh
 \le1+2D[1+\log_+(n/D)].}                               \tag{G8}
\]
At D=0 the second term is defined as zero. Empty original clocks give zero. For the first bound, truncate the early interval at min(L,m) if that is smaller; the displayed integral is an upper bound obtained by extending it. On the early interval dt/t=dq_t/q_t<= (L/a) d(1−q_t/L) in absolute value. The elementary integral is at most D[1+log_+(n/D)], and n log gamma<=1. Original far subwindows and positive masks can only reduce G8.

The refinement over a b-deficit bound is the use of the actual canonical L and the thin q_t>L tail. It is still a row clock estimate, closely related in purpose to older deficit-clock bounds; it is not registered as a second source payment. The original e_t and Pi_t are untouched throughout.

## G5. What remains in the true global budget

On a fixed original row the mean and the clock are now connected to the same deficit coordinates by G3, G5 and G6. The full source-u contribution in G3/G5 has not disappeared. If D is uniformly of order sqrt n times polylog factors on the current v-small domain, G8 gives a root-polylog **row** price without putting a cap on u. It does not pay that price in the source/receiver ledger.

Indeed multiplying a uniform row price B by the raw original nonnegative mother measure yields only B times the mass of that original mother measure (including its original outside constant). This note does not establish a source-mass bound for that quantity. No numerical coefficient in terms of an independently undefined T_small or X is asserted here. The missing step is a joint estimate in actual dx, p_y, h_R, beta and the same two posteriors that replaces this large receiver-X coefficient by its genuine source budget. The R276 fluctuation exception is already paid separately; neither its positive mask nor consumed N_Z negatives can be used to pay this mean/complement cost again.

This bounded task establishes the two explicit bridges and stops at that concrete global coupling gap. It does not assume source independence, impose a new bound on Delta_L(u), or promote small-v deficit alone to a global mean/traffic estimate.

## G6. Local mathematical-tool check

No additional source-family or numerical kernel menu was run. The default and bundled Python runtimes do not have SymPy installed, so the following bounded scalar mpmath/Fraction check was used instead; the strict proof is G2/G8 above.

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
from fractions import Fraction as F
import mpmath as m
m.mp.dps=60
checks=0
for L,b,d in [(F(1),F(2),F(0)),(F(3,2),F(2),F(1,4)),(F(2),F(2),F(3,4))]:
    lhs=(b/L)*(1-L/b+(L/b)*d)
    assert lhs==b/L-1+d;checks+=1
n=m.mpf(64);D=m.mpf(8);cut=D/n
value=m.quad(lambda h:n,[0,cut])+m.quad(lambda h:D/h,[cut,1])
closed=D*(1+m.log(n/D))
assert abs(value-closed)<m.mpf('1e-50');checks+=1
print('PASS',checks,'scalar algebra/integral checks; no source model added')
```

Actual local execution returned `PASS 4 scalar algebra/integral checks; no source model added` (exit 0). These arithmetic checks are not evidence of an original FULL example or a new dimension order.
