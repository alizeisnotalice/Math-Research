# R278 independent saved-row/code and exact-node audit

Verdict: no blocking implementation or direction error found. Main collar constant is48, an external analytic safe constant; the observed ratios below1 do not establish it. No new quadrature, old-menu rerun, or general source-payment claim was made.

The frozen numerical script uses the actual common-soft source/target P_s,L and P_s,A, A=L or min(1,gammaL), and the correct denominator Omega_L=min(1,C/L). C uses the E4 hard-overlap/soft-tail expression. It splits source and target cores,0,and r, integrates core and both collars separately, preserves s0 support, and retains s1. Tensor powers are repeated physical receiver-coordinate factorization, not posterior-coordinate independence. The input JSON source hash matches the frozen source.

The new standalone checker reads only adjacent `r278_numeric.json`; input SHA256 is 37bb9aef6680d74cfc0cd6ce96017872754f76b583f8918cf5d2cf1ccf31c133. All12 saved rows satisfy collar<=48epsilon sqrt(s), and their repeated-coordinate logs satisfy −eta Delta+48exp(eta)n epsilon sqrt(s). The two s0 rows have exactly zero collars. It also verifies saved core+collar decomposition and tensor log consistency. Its90-digit evaluation merely handles saved60-digit strings; it does not upgrade the old40/60 quadratures or certify the tiny eta gap.

Twelve exact Fraction paired-node models cover n1/2/8 (initial6),n32/64(stress4),n512(expanded2),including saturated/zero-loss cases. All L<=B<=gammaL, both target-scale sandwiches A_i(L)<=A_i(B)<=gamma A_i(L), sigma=k/(n+1)<=sbar=min(1,s+1/n), and Delta_B>=Delta_L hold. The loss direction is correct because min(1,C/B)<=min(1,C/L) for B>=L. Positive rational C profiles are algebraic numerators only, not asserted actual kernel values at fixed distances.

The static transfer is specifically the geometric-loss gate eta Delta_L>=H sqrt(sbar)+T. It is checked with exact nonnegative sides and squared inequalities, then eta Delta_B>=H sqrt(sigma)+T. There are12 transfers, including2 zero-loss H=T0 branches. No actualgood/nodegood likelihood set is reconstructed; no pnode or unrelated KM gate is introduced. The original likelihood/Cauchy step remains external.

Counts:12 saved collar checks,12 tensor checks,12 paired-node models,24 target-scale sandwiches,12 forward-soft checks,12 loss-monotonicity checks,12 gate transfers. All passed in the actual local Python run.

Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r278_checks.py --output /tmp/r278_checks.json`. Package replay must keep the frozen numeric JSON adjacent with basename `r278_numeric.json`; no /tmp input path is hardcoded.

No FULL, FIRST/high/history, adaptive all-scale selector, dimension-order or root conclusion is certified.

Reviewed original source SHA256: 2a268740db0d7485dab079d3f894c59bca790636f7e05ce31568dc0cdf85b41e

New checker SHA256: e26fc1419c86daf2dcbaae8f3308c9230b012a5fd902e6d3745ca80b39babafe

New result SHA256: c239a415c647cc82e9116da9f4a34bd8486a6fa8b1f14addffcb969e8f9af349
