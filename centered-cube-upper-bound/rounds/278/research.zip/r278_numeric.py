#!/usr/bin/env python3
"""R278 actual retained moving halfkernels, no old fixtures rerun."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 x=F(x);return mp.mpf(x.numerator)/x.denominator
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L
def quad(fn,a,b,knots):
 pts=sorted(set([a,b]+[x for x in knots if a<x<b]));return sum(mp.quad(fn,[x,y]) for x,y in zip(pts,pts[1:]))
def menu():return [('initial',8,'0','1/2','0'),('initial',8,'1/2','1','1/2'),('stress',64,'1','3/4','1'),('stress',64,'1/1000000','1/2','1/2'),('expanded',512,'1/100','3/4','2'),('expanded',512,'1/2','1/2','4')]
def run(dps,pilot=False):
 with mp.workdps(dps):
  eta=mp.mpf(25)/2**69;rows=[];calls=0;cache={}
  for stage,n,ss,ls,rs in menu()[:2] if pilot else menu():
   s,L,r=map(mm,[ss,ls,rs]);epsilon=mp.mpf('.5')/(8*mp.sqrt(n));h=(1+epsilon)/2;omega=min(mp.mpf(1),C(r)/L);bound=mp.exp(-eta*(1-omega))
   for leg in ['same_L','Lplus']:
    A=L if leg=='same_L' else min(mp.mpf(1),(1+mp.mpf(1)/n)*L);key=(s,L,A,r,epsilon)
    if key not in cache:
     fn=lambda x:mp.sqrt(P(s,L,x)*P(s,A,x-r)/omega);knots=[-L/2,L/2,r-A/2,r+A/2,mp.mpf(0),r]
     core=quad(fn,-mp.mpf('.5'),mp.mpf('.5'),knots);left=quad(fn,-h,-mp.mpf('.5'),knots);right=quad(fn,mp.mpf('.5'),h,knots);cache[key]=(core,left,right);calls+=1
    core,left,right=cache[key];collar=left+right;total=core+collar;assert core<=bound+mp.mpf('1e-28')
    if s==0:assert collar==0
    rows.append({'stage':stage,'n':n,'s':ss,'L':ls,'r':rs,'target_leg':leg,'A':enc(A),'epsilon':enc(epsilon),'C_r':enc(C(r)),'Omega_L':enc(omega),'core_integral':enc(core),'left_collar':enc(left),'right_collar':enc(right),'collar_integral':enc(collar),'retained_window_integral':enc(total),'core_bound':enc(bound),'core_bound_margin':enc(bound-core),'collar_over_epsilon_sqrt_s':enc(collar/(epsilon*mp.sqrt(s))) if s else None,'hard_s0_collar_zero':collar==0 if s==0 else None,'tensor_log_core_integral':enc(n*mp.log(core)) if core else '-inf','tensor_log_retained_integral':enc(n*mp.log(total)) if total else '-inf','tensor_core_log_bound':enc(-n*eta*(1-omega))})
  return {'eta':enc(eta),'rows':rows,'unique_integral_triplets':calls}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','s','L','r','target_leg']:
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(60)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-28')
 out={'schema':'R278-retained-moving-halfkernel-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'physical_geometries':6,'leg_rows_per_precision':12,'geometry_stages':{'initial':2,'stress':2,'expanded':2},'unique_core_collar_integral_triplets_per_precision':hi['unique_integral_triplets'],'hard_s0_leg_checks_per_precision':sum(r['s']=='0' for r in hi['rows']),'positive_s_collar_ratios_per_precision':sum(r['s']!='0' for r in hi['rows']),'precision_fields_compared':len(diff)},'mp40':lo,'mp60':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'definitions':{'F':'sqrt(P_s,L(x) P_s,A(x-r)/Omega_L)','Omega_L':'min(1,C(r)/L)','core':'[-.5,.5]','collar':'[-(1+epsilon)/2,(1+epsilon)/2] minus core','epsilon':'.5/(8sqrt n)','core_bound':'exp(-eta(1-Omega_L)),eta25/2^69'},'scope':['Actual moving kernels use common s for source and target; target scales are sameL and min(1,gammaL),gamma1+1/n. Fullsofts1 and hard s0 are retained.','Core and both collars are separately integrated with explicit actual jump and phi-core breakpoints. Hard s0 collar is exactly zero by compact source support; positive-soft ratio is recorded without inferring a universal constant or dimension order.','Ordinary40/60 mpmath is not outward interval arithmetic. Tiny eta core bound is a consistency screen, not numerical proof of the fixed-kernel theorem. Repeated-coordinate tensor logs factorize actual one-coordinate integrals only.','No oldR27718-row/window menus rerun; functions are copied self-contained. No original all-scale selector/FIRST/high/history/FULL/source-payment or root conclusion.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
