# Round 68: constant-loss binary replacement and shared-source deficiency

2026-10-11. **The uniform bound sqrt(n)n^{o(1)} is not proved.**
The retained fully general benchmark is O(n log n).

## Proved progress and remaining target

The principal new general construction replaces positive source mass by
uniform blocks in a cyclic binary rectangular filtration. Its cells have
aspect ratio at most two and parent-to-child volume ratio two. Selected
block heights therefore lie in (lambda,2lambda], instead of a range with
ratio 2^n. An isotropic containing-cube shield lies in the ORIGINAL bad
set. On the original good set, the complete signed replacement error has
square energy at most 2(1+e)HW at alpha=2n^2+1. All source mass, receiver
measure and full logvolume time are preserved.

This yields a constant-loss reduction to equal-height tests on nested
unions of actual selected cells: the layer loss is 1+log(2), rather than
1+n log(2). An intrinsic indicator-cap estimate would suffice as well.
The absolute target density is still exponential; the reduction removes
that multiplier from the conditional test, not from a global L2 bound.
The indicator-cap test with subpower dimension dependence is UNPROVED.
The final weak and full-scale return is also not asserted as completed.

The direct weak route retains a separate general source-packet transfer:
the paid cost is the sum of packet masses divided by their response
fractions, PLUS the actual uncovered weak volume. A fixed common source
tree gives an exact source variance identity, but its spatial integral
remains unbounded by the required dimension-only budget. Pointwise hard
partition and coordinate-order-tree obstructions are proved using actual
cube winners. The explicit Boolean receiver boxes have a small total
weak fee, so their existence is not a counterexample to an aggregate
exception allowance or to the main weak bound.

## Validation and reproduction

The main probe uses 93 rows and 167424 full-space receiver draws, with
pilot and heldout stages kept separate. Its independent replay is
byte-identical. Three supplemental guards use exact rational arithmetic
for finite geometry or algebra; they are embedded below. Finite tests
support implementation checks, not a general spatial bound. Sampling
standard errors and uninformatively wide formal Hoeffding radii are both
reported. Exact point checks do not certify all receiver classifications
or continuum integrals.

The archive has exactly five members: proof.md, proof.tex.txt,
partition_probe.py, partition_results.json, and inventory.json.
Extract to a temporary directory, preserve the supplied result JSON,
and run `python3 -B partition_probe.py` using Python 3.12.14 and NumPy
2.3.5. The script is standalone. Do not pass --pilot for a full replay.
Each embedded supplemental Python block runs separately with the
standard library. LaTeX is delivered as .tex.txt; no compilation or PDF
is claimed. No external theorem is imported by the name of a skill.



# Round 68: binary rectangular replacement and a constant-loss aggregate testing reduction

The general signed energy budget is not proved. The new construction progress is a source-conserved replacement with relative block-height spread at most two, a paid full signed error on the original good set, and a constant-loss reduction of the entire selected-block energy to equal-height nested-union tests. The absolute target height remains exponential; it is eliminated from the conditional testing reduction, not from the global L2 benchmark.

This construction was suggested by the parent agent's binary-filtration observation and independently audited here. The isotropic containing-cube shield gives slightly cleaner cap constants than coordinatewise rectangular dilation.

## 1. Actual balanced binary filtration

For k in Z write k=qn+r, 0<=r<n. At generation k use half-open axis-aligned cells whose side lengths are

\[
 \ell_j(k)=
 \begin{cases}2^{-q-1},&j<r,\\2^{-q},&j\ge r,\end{cases}
 \qquad j=0,\ldots,n-1.
\]

Their endpoints are integer multiples of these lengths. At generation k+1 each cell splits in coordinate r only. Thus each parent has exactly twice its child's volume. Cells have volume 2^{-k}; their largest side s satisfies s<=2|R|^{1/n}, and their aspect ratio is at most two. Each chain expands in all coordinates as k tends to minus infinity and shrinks in all coordinates as k tends to infinity.

Fix alpha>1 and

\[
 \lambda=[2(\alpha+1)]^nH.
\]

For an arbitrary finite positive Borel source mu of mass W, select every maximal cell R with m_R=mu(R)>lambda|R|. A bad cell has a maximal bad ancestor since ancestor volume tends to infinity and mass is at most W. The selected cells are disjoint and at most countable. The immediate parent is not bad, so

\[
 \lambda<h_R:=m_R/|R|\le2\lambda.                 \tag{1}
\]

Let U be their union and nu=mu restricted to U^c. Every binary cell has nu-mass at most lambda times its volume: a cell inside U has nu-mass zero, and any other cell is not bad. Since the cells shrink in all coordinates, open sets can be decomposed into countably many contained cells. This proves nu<=lambda dx, not merely a pointwise differentiation assertion. Write its density f_0<=lambda and define

\[
 B=\sum_Rh_R1_R,\qquad F=f_0+B.
\]

Mass(F)=W and F<=2lambda. For every finite atomic source all atoms belong to sufficiently small bad cells, f_0=0, and the number of selected cells is at most the number of distinct source atoms. No number-of-atoms factor enters any bound below.

## 2. The original good set shields every block

Let Q_R^* be the closed concentric cube of side s_R=max_j ell_j(R) containing R. Because s_R<=2|R|^{1/n},

\[
 m_R>\lambda|R|\ge H[(\alpha+1)s_R]^n.
\]

For any x in the closed cube alpha Q_R^*, a centered cube at x of side (alpha+1)s_R contains all source mass in R. Hence alpha Q_R^* lies in the strict original bad set Omega={Mmu>H}. Set G={Mmu<=H}, always for the ORIGINAL source.

If a receiver cube of side L centered at x in G meets R in positive volume, then L>=(alpha-1)s_R. Any source point in R is within L/2+s_R of x. Therefore, with

\[
 {\cal R}={\alpha+1\over\alpha-1},
\]

the original receiver cube of side calR L contains the entire mass of every selected block contributing to the target average. The residual is already part of the original source. Disjointness gives

\[
 MF(x)\le{\cal R}^nH \quad (x\in G).              \tag{2}
\]

Thus |D(mu-F)|<=(1+calR^n)H, for D=A_{qL}-A_L and any q>1.

## 3. Full signed error, with no q or stage count

Couple mu restricted to R to uniform Lebesgue measure on R, for example by their normalized product coupling. Each pair y,z lies in Q_R^* and has infinity displacement at most s_R. The full-side cube kernel satisfies

\[
 \|k_L(\cdot-y)-k_L(\cdot-z)\|_1
 \le2n\|y-z\|_\infty/L.
\]

On G the difference vanishes for L<(alpha-1)s_R, since both points lie in the containing cube and G avoids its alpha-dilation. Using du=n dL/L,

\[
 \int_G\int_{\mathbb R}|k_L(x-y)-k_L(x-z)|\,du\,dx
 \le {2n^2\over\alpha-1}.
\]

The two pieces of D have the same full-logtime integral after the change L to qL. Thus

\[
 \int_G\int |D(\mu-F)|\,du\,dx
 \le {4n^2\over\alpha-1}W.
\]

This is a bound for the COMPLETE aggregate signed error; the use of Tonelli on the sum of absolute coupling defects justifies countably many blocks. Combining with (2),

\[
 E_G(\mu-F):=\int_G\int|D(\mu-F)|^2
 \le {4n^2(1+{\cal R}^n)\over\alpha-1}HW.         \tag{3}
\]

At alpha=2n^2+1 and q=exp(1/n),

\[
 {\cal R}=1+1/n^2,\quad
 E_G(\mu-F)\le2(1+e)HW,\quad
 \|F\|_\infty\le2[4(n^2+1)]^nH.
\]

The absolute height is still exponential. Its relative selected-block spread is only two. The old global L2 shortcut would still cost kappa_n times this exponential height; it is not the proposed closure.

The already-paid diagonal bound also transfers verbatim to rectangles:

\[
 \sum_R E_G(h_R1_R)\le
 (1-e^{-1}){\cal R}^nH\sum_Rm_R.
\]

Indeed, for y in R the original cap forces
2||x-y||infinity >=(m_R/H)^{1/n}-2s_R
>=(m_R/H)^{1/n}/calR; Jensen and the one-source time identity give the claim. This remains a trace bound and does not control the signed cross sum.

## 4. Constant-loss reduction to nested equal-height tests

This is a proved CONDITIONAL lemma, not a paid estimate. Define U_t={B>t}; every U_t is a union of the actual selected rectangles, and the sets are nested. Assume, only for these unions and lambda<=t<=2lambda,

\[
 E_G(t1_{U_t})\le A_nH\,t|U_t|.                 \tag{T}
\]

No all-subset testing is required. The common original G is fixed throughout. At a jump level, the left-limit union is covered by taking t increasing to that level in (T); strict versus non-strict level sets do not create a gap.

Since B is zero off U and lambda<B<=2lambda on U,

\[
 B=\lambda1_{U_\lambda}+
       \int_\lambda^{2\lambda}1_{U_t}\,dt.
\]

Put W_0=lambda|U_lambda| and W_1=integral_lambda^{2lambda}|U_t|dt, so W_0+W_1=mass(B). Work in the actual Hilbert space L2(G x R,dx du), retaining all signed receiver and scale cancellations. Minkowski and (T), followed by Cauchy--Schwarz, give

\[
 \|DB\|
 \le\sqrt{A_nH}\left[
       \sqrt{W_0}+\int_\lambda^{2\lambda}
                         \sqrt{|U_t|/t}\,dt\right]
 \le\sqrt{A_nH}\,[\sqrt{W_0}+\sqrt{\log2}\sqrt{W_1}].
\]

A final two-term Cauchy inequality yields

\[
 E_G(B)\le(1+\log2)A_nH\,\mathrm{mass}(B).        \tag{4}
\]

All appearances of lambda cancel. The n-dimensional parent-volume overshoot is absent because the binary filtration has parent volume twice child volume. For a finite atomic source F=B, so (3)--(4) imply

\[
 E_G(\mu)\le
 \left[\sqrt{\,4n^2(1+{\cal R}^n)/(\alpha-1)\,}
       +\sqrt{(1+\log2)A_n}\right]^2 HW.         \tag{5}
\]

This formula states the exact conditional consequence, without asserting that (T) has the required dimension dependence or that the weak-upper goal has been achieved. The retained sufficient energy route seeks A_n=n^{o(1)} (ideally polylogarithmic); an O(sqrt(n)) energy estimate does not by itself establish the desired weak constant. The weak/all-scale return remains a separate unproved step in the general roadmap.

For a general Borel source, (4) pays only B CONDITIONALLY. The residual f_0 remains: a separate bound E_G(f_0)<=A_{0,n}H mass(f_0) would imply

\[
 E_G(F)\le[A_{0,n}+(1+\log2)A_n]HW
\]

by another two-term Cauchy inequality. The residual is dominated by mu, so Mf_0<=H on G, but that cap alone is not a proof of its square-energy budget. No density-to-atom limiting argument is assumed.

## 5. Exact signed layer pairing and the remaining inequality

For a finite selected family, list distinct heights lambda<h_1<...<h_K<=2lambda, set h_0=0, and put V_j={B>=h_j}. Then the exact signed identity is

\[
 E_G(B)=\sum_{j,k=1}^K(h_j-h_{j-1})(h_k-h_{k-1})
       \left\langle D1_{V_j},D1_{V_k}\right\rangle_{L^2(G\times R)}.
                                                               \tag{6}
\]

Each inner product retains the spatial integration BEFORE any estimate. For finite scale windows its kernel is

\[
 \int_{V_j}\int_{V_k}\int_G\int_{\mathrm{window}}
           d_L(x-y)d_L(x-z)\,du\,dx\,dz\,dy .
\]

Finite-window Fubini is legitimate for these finite-volume sets. Full-time (6) follows directly from the Hilbert-space identity and the retained L2 theorem, rather than an unproved interchange of an off-diagonal singular full-spatial kernel. For countably many blocks, bounded height and finite mass give L2 convergence of the block sum; the same theorem passes the identity to limits.

The new missing inequality is (T) on nested unions of BALANCED BINARY selected cells, with the desired A_n. It is genuinely weaker than a uniform source-block row Schur condition and does not charge positive interactions before spatial integration. Round66's positive budget counter and Round67's natural-row counter therefore do not disprove it. Conversely, the trace alone, PSD alone, or a signed Gram identity does not establish (T). The source cap, containing-cube shields and nested threshold geometry must still be used to prove that testing estimate. No such proof is given here.

For comparison, retaining the old cube filtration would give a relative height spread 2^n and the same layer argument would lose 1+n log2. An abstract rank-one model shows that a log-height-range loss can be real under testing and trace alone: heights h_i=2^i, cell volumes 2^-i, and formal indicator images a_i=2^-i have total mass K and block trace K, all threshold tests have constant at most two, but the full image has squared norm K^2. This is an algebraic pressure test, NOT a realizable cube/cap counterexample. The binary construction removes that particular large-range mechanism.

## 6. An intrinsic indicator-cap normal form

A sufficient version of (T) no longer refers to the original atomic source. Suppose every finite union V of cells in the balanced binary grid satisfies the intrinsic equal-height cap test

\[
 E_{\{M(t1_V)\le h\}}(t1_V)
 \le {\cal I}_n\,h\,t|V| \qquad (t,h>0).          \tag{I}
\]

The energy uses the same cube operator, q=exp(1/n), full logvolume time and Lebesgue measure. By amplitude homogeneity this is equivalent to

\[
 E_{\{M1_V\le\rho\}}(1_V)
 \le {\cal I}_n\,\rho|V|\qquad(\rho>0).
\]

For every actual threshold union U_t, pointwise t1_Ut<=B<=F implies M(t1_Ut)<=MF<=calR^n H on original G. Thus original G is a subset of the intrinsic good set with h=calR^nH. Nonnegativity of the energy integrand and (I) prove (T) with

\[
 A_n={\cal R}^n{\cal I}_n.
\]

At the canonical alpha=2n^2+1 this gives A_n<=e calI_n. Therefore (I) would imply for EVERY finite atomic source

\[
 E_G(\mu)\le
 \left[\sqrt{2(1+e)}
        +\sqrt{e(1+\log2){\cal I}_n}\right]^2HW.  \tag{7}
\]

This is a uniform general atomic cap-energy reduction to an indicator cap test with constant loss, not a family-specific upper estimate. The balanced geometry and two-to-one density spread have removed the exponential target-height multiplier.

Test (I) remains unproved here. The case rho>=1 is bounded by the retained global L2 theorem; the substantive range is rho<1, including the exponentially small rho required by the replacement. No converse from atomic cap energy to density cap energy is asserted. A weak-L1 atomic approximation theorem would not automatically prove good-set energy convergence or the converse of this reduction. The general Borel residual and the weak/all-scale return retain the scope restrictions stated above.

## 7. Current skill hypotheses

Current F02, F05 and N03 entries and their method/cube-interface files were re-read from disk. F02 permits the ordinary sinc tensor Fourier calculation but explicitly does not make cube indicators Fourier nonnegative. F05 requires both true weighted Schur margins; the present aggregate testing lemma does not invoke that test or a PSD multiplier theorem. N03 requires actual oscillatory phases and derivative hypotheses, which are absent here, so no van der Corput or stationary-phase result is used. No external source theorem is imported.

Entry SHA256:
F02 f6ea283da12ee2ebdceb352f8ef3cf0cd1d98752df08dca35ec84c18457cec8b
F05 9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9
N03 2ede839f40e7337d4b9293d5d9b306a3f9361b89f70c7c2e282164583d9576dd

## 8. Standalone exact guard

The guard uses only the Python standard library. It checks actual balanced-binary maximal selection, density spread, aspect ratio, containing-cube shielding geometry, exact original atomic cap gates, exact uniform-rectangle receiver averages, enlarged-original-source comparisons, and equal-height threshold-average domination. It also checks the signed layer identity on deterministic multi-round rational Hilbert models, including negative cross terms, and the rational relaxation 1+log2<2 of the proved conditional bound. These algebraic models are not numerical proofs of (T) for actual cube operators.

```python
from fractions import Fraction as F
from itertools import product
from random import Random
import json

def lengths(k,n):
    q,r=divmod(k,n)
    return tuple(F(2)**(-q-(j<r)) for j in range(n))
def cell(y,k):
    ell=lengths(k,len(y))
    return k,tuple(int(y[j]//ell[j]) for j in range(len(y)))
def bounds(R,n):
    k,a=R
    ell=lengths(k,n)
    return tuple(a[j]*ell[j] for j in range(n)),ell
def inside(y,R):
    left,ell=bounds(R,len(y))
    return all(left[j]<=y[j]<left[j]+ell[j] for j in range(len(y)))
def mass(R,src):
    return sum((p for y,p in src if inside(y,R)),F(0))
def selection(src,n,lam):
    lo,hi=-20*n,60*n
    assert sum(p for y,p in src)<=lam*F(2)**(-lo)
    assert all(p>lam*F(2)**(-hi) for y,p in src)
    answer=set()
    for y,p in src:
        bad=[cell(y,k) for k in range(lo,hi+1)
             if mass(cell(y,k),src)>lam*F(2)**(-k)]
        answer.add(min(bad,key=lambda R:R[0]))
    answer=sorted(answer)
    assert sum(mass(R,src) for R in answer)==sum(p for y,p in src)
    assert all(sum(inside(y,R) for R in answer)==1 for y,p in src)
    return answer
def cap(x,src,H):
    radii={max(abs(x[j]-y[j]) for j in range(len(x))) for y,p in src}
    for r in radii:
        if r==0: return False
        captured=sum((p for y,p in src if
                      max(abs(x[j]-y[j]) for j in range(len(x)))<=r),F(0))
        if captured>H*(2*r)**len(x): return False
    return True
def source_capture(x,L,src):
    return sum((p for y,p in src if
                all(abs(x[j]-y[j])<=L/2 for j in range(len(x)))),F(0))
def uniform_capture(x,L,rects,src,t=None):
    result=F(0)
    n=len(x)
    for R in rects:
        left,ell=bounds(R,n)
        overlap=F(1)
        for j in range(n):
            overlap*=max(F(0),min(x[j]+L/2,left[j]+ell[j])
                                   -max(x[j]-L/2,left[j]))
        density=mass(R,src)/F(2)**(-R[0])
        if t is not None: density=t if density>t else F(0)
        result+=density*overlap
    return result

def geometry_guard():
    counts={"selected":0,"exact_parent_ties":0,"receiver_scales":0,
            "shield_samples":0,"source_configurations":0,"threshold_averages":0}
    for n in range(1,9):
        zero=(F(0),)*n
        def pole(a):
            return (F(a),)+(F(0),)*(n-1)
        base=[(zero,F(1,2)),(pole(F(1,1024)),F(1,8)),
              (pole(1),F(1,4)),(pole(-1),F(1,8))]
        for alpha in (F(3,2),F(2*n*n+1)):
            H=F(1)
            lam=(2*(alpha+1))**n*H
            for src in (base,[(zero,lam/2)]):
                rects=selection(src,n,lam)
                counts["source_configurations"]+=1
                for R in rects:
                    k,a=R
                    left,ell=bounds(R,n)
                    vol=F(2)**(-k)
                    s=max(ell)
                    m=mass(R,src)
                    h=m/vol
                    assert lam<h<=2*lam
                    assert max(ell)<=2*min(ell)
                    assert s**n<=2**n*vol
                    assert m>H*((alpha+1)*s)**n
                    parent=cell(tuple(left[j]+ell[j]/2 for j in range(n)),k-1)
                    assert mass(parent,src)<=lam*2*vol
                    counts["selected"]+=1
                    if len(src)==1:
                        assert mass(parent,src)==lam*2*vol
                        counts["exact_parent_ties"]+=1
                    center=tuple(left[j]+ell[j]/2 for j in range(n))
                    for signs in ((1,)*n,(-1,)*n,tuple((-1)**j for j in range(n))):
                        x=tuple(center[j]+signs[j]*alpha*s/2 for j in range(n))
                        L=(alpha+1)*s
                        assert source_capture(x,L,src)>=m>H*L**n
                        counts["shield_samples"]+=1
                Rfac=(alpha+1)/(alpha-1)
                candidates=[]
                reach=8*(alpha+1)
                for dist in (F(1,2),F(3,2),F(3),reach):
                    for signs in ((1,)*n,(-1,)*n,tuple((-1)**j for j in range(n))):
                        candidates.append(tuple(signs[j]*dist for j in range(n)))
                for x in candidates:
                    if not cap(x,src,H): continue
                    scales={F(1,2),F(1),F(2),F(4),2*reach}
                    for R in rects:
                        left,ell=bounds(R,n)
                        s=max(ell)
                        scales.update((s*(alpha-1)/2,s*(alpha-1),s*(alpha+1)))
                    for L in scales:
                        fm=uniform_capture(x,L,rects,src)
                        mm=source_capture(x,Rfac*L,src)
                        assert fm<=mm<=H*(Rfac*L)**n
                        ts={lam,F(3,2)*lam,2*lam}
                        ts.update(mass(R,src)/F(2)**(-R[0]) for R in rects)
                        for t in ts:
                            tm=uniform_capture(x,L,rects,src,t)
                            assert tm<=fm<=H*(Rfac*L)**n
                            counts["threshold_averages"]+=1
                        for R in rects:
                            left,ell=bounds(R,n)
                            s=max(ell)
                            ov=F(1)
                            for j in range(n):
                                ov*=max(F(0),min(x[j]+L/2,left[j]+ell[j])
                                               -max(x[j]-L/2,left[j]))
                            if ov>0:
                                assert L>=(alpha-1)*s
                        counts["receiver_scales"]+=1
    return counts

def norm2(v):
    return sum((a*a for a in v),F(0))
def add(v,w):
    return tuple(a+b for a,b in zip(v,w))
def scale(c,v):
    return tuple(c*a for a in v)

def layer_guard():
    rng=Random(20261011)
    checks=0
    negative_cases=0
    largest_ratio=F(0)
    for round_id in range(3):
        for K in (1,2,4,8,16,32):
            for trial in range(4):
                d=3+round_id
                lam=F(3+round_id)
                heights=[lam*(1+F(rng.randrange(1,65),64)) for i in range(K)]
                volumes=[F(rng.randrange(1,17),16) for i in range(K)]
                images=[tuple(F(rng.randrange(-8,9),8) for j in range(d))
                        for i in range(K)]
                direct=(F(0),)*d
                for h,v in zip(heights,images): direct=add(direct,scale(h,v))
                cuts=sorted(set(heights))
                layered=(F(0),)*d
                previous=F(0)
                A=F(0)
                for h in cuts:
                    indices=[i for i in range(K) if heights[i]>=h]
                    v=(F(0),)*d
                    for i in indices: v=add(v,images[i])
                    layered=add(layered,scale(h-previous,v))
                    A=max(A,h*norm2(v)/sum(volumes[i] for i in indices))
                    previous=h
                assert direct==layered
                W=sum(heights[i]*volumes[i] for i in range(K))
                assert norm2(direct)<=2*A*W
                if A: largest_ratio=max(largest_ratio,norm2(direct)/(A*W))
                if any(sum(images[i][j]*images[k][j] for j in range(d))<0
                       for i in range(K) for k in range(i)):
                    negative_cases+=1
                checks+=1
    # Old wide-height rank-one stress, explicitly an algebraic model.
    wide=[]
    for K in (2,4,8,16,32,64,128):
        heights=[F(2)**i for i in range(1,K+1)]
        volumes=[1/h for h in heights]
        A=max(heights[j]*sum(volumes[j:]) for j in range(K))
        assert A<2
        assert sum(h*v for h,v in zip(heights,volumes))==K
        assert sum((h*v)**2 for h,v in zip(heights,volumes))==K
        assert sum(h*v for h,v in zip(heights,volumes))**2==K*K
        wide.append({"levels":K,"energy_over_mass":K})
    return {"rational_signed_layer_cases":checks,
            "cases_with_negative_cross_terms":negative_cases,
            "max_relaxed_constant_ratio_float":float(largest_ratio),
            "wide_height_algebraic_pressure":wide}

def run():
    return {"binary_rectangles":geometry_guard(),"layers":layer_guard(),
            "scope":"exact Fraction finite geometry/algebra guards; testing (T) remains unproved"}
if __name__=="__main__":
    print(json.dumps(run(),sort_keys=True,separators=(",",":")))
```

Actual replay: the embedded guard completed in about 2.48 seconds and passed every stated exact comparison, including 10,374 exact threshold-average domination comparisons. Its only displayed nonrational summary, the maximum conditional ratio 1.3158197077593456, is the float rendering of an exact rational value from the algebraic models, not an actual cube-energy estimate. The full weak-upper goal and test (T) remain unproved.


# Round 68: shared source packets and an aggregate deficiency transfer

The general centered-cube weak estimate remains unproved. This note proves a transfer with its complete source cost and an actual-cube obstruction to covering every residual receiver by one disjoint hard partition. The useful remaining requirement is an aggregate cost plus uncovered-volume estimate, rather than universal pointwise packet dominance.

## 1. Original winner and fixed source data

Let mu=sum_i p_i delta_{y_i}, with distinct sites, p_i>0 and total mass W. For x outside the finite source set, merge equal physical arrival volumes v_i(x)=(2||x-y_i||_infinity)^n. The centered maximal function is the finite maximum of cumulative captured mass divided by an arrival volume. Select the smallest arrival volume attaining this maximum. Denote its closed cube by Q*(x), its volume by V*(x), its captured mass by F*(x), and its average by M(x)=F*/V*.

These are Borel functions: distances are continuous, inclusion comparisons and equal-distance groups are Borel, and only finitely many comparisons are required. Positive-volume ties are retained. No general measurable-selection theorem is used.

Use the original residual band

    B_H = {x: H<M(x)<=2H, Q*(x) captures at least two sites,
                   F*(x)<=W/2}.

The equality F*=W/2 belongs to this residual branch. B_H has finite volume: if M>H, some source lies at distance less than (W/H)^(1/n)/2.

A shared packet family consists of measures

    nu_a=sum_i alpha_ai p_i delta_{y_i},  0<=alpha_ai<=1,
    w_a=nu_a(R^n)>0,

fixed before receiver integration. For a finite family, define source multiplicities m_i=sum_a alpha_ai and total charged mass

    sum_a w_a=sum_i p_i m_i.

Thus a disjoint or fractional partition has total charged mass W; an overlapping family must pay its actual mass multiplicity. A receiver-dependent list is not a common partition. Its union of all used packets is the family whose mass has to be paid.

## 2. Exact transfer, including threshold loss and deficiency

Assign each packet a fixed eta_a in (0,1]. Call a receiver eligible for a when

    nu_a(Q*(x))>w_a/2,       nu_a(Q*(x))>=eta_a F*(x).

Let E_a be its eligible set inside B_H. Then

    H |E_a| <= w_a/eta_a.                                      (2.1)

Proof. Put c_a=nu_a(Q*). Since M>H and c_a>=eta_a F*, we have c_a/V*>eta_a H. Because c_a<=w_a,

    V* < w_a/(eta_a H).

Enlarge Q*(x), keeping its center, to the common volume w_a/(eta_a H). Every enlarged cube captures strictly more than half of the same fixed measure nu_a. Any two captured source sets overlap in positive nu_a mass, so the two cubes intersect. If their common side length is L_a, their centers have coordinate differences at most L_a. Consequently E_a fits in an axis-parallel box of volume at most L_a^n=w_a/(eta_a H). Coordinate suprema and infima need not be attained; the same bound follows by outer boxes with arbitrarily small added widths. This proves (2.1).

The proof uses the original winner only. It does not assert that this cube is optimal for nu_a, and it does not replace the original receiver band by a packet good set.

Let U=B_H\(union_a E_a). Ordinary countable subadditivity gives the full transfer

    H |B_H| <= sum_a w_a/eta_a + H |U|.                        (2.2)

For a common eta and sum_a w_a<=L W, the paid term is L W/eta. Both multiplicity L and threshold loss eta^-1 are explicit. This is a volume union bound, not subadditivity of the weak-L1 quasinorm.

The same proof applies to a finite random choice of common families, indexed by t. If s(x)=P_t(x belongs to union_a E_a(t)) and C(t)=sum_a w_a(t)/eta_a(t), Tonelli gives

    H |B_H| <= E_t C(t) + H integral_{B_H} (1-s(x)) dx.        (2.3)

If s(x)>=sigma>0 almost everywhere on B_H, an alternative consequence is sigma H|B_H|<=E_t C(t). A countable randomized model follows under joint measurability and integrable cost; no such model is required by this note.

These are conditional transfers. To reach the residual target b_n=sqrt(n)n^{o(1)}, one must construct common source families for every finite positive source and H such that the right side of (2.2), or (2.3), is <=b_n W. A family depending on mu and H is allowed; it is then fixed as a family of actual submeasures. A sampled union only gives a lower pressure on its full all-receiver cost, and sampled coverage does not bound |U|.

## 3. Relation to a common source tree

For any common finite binary partition tree, let w_J=mu(J), c_J=mu(J intersect Q*(x)), and r_J=c_J/w_J. The root fraction is F*/W, and a captured leaf has fraction 1 while an uncaptured leaf has fraction 0. The elementary source variance identity is

    sum_edges w_child (r_child-r_parent)^2 = F*-(F*)^2/W.

At each split with child masses u,v, its contribution is

    uv/(u+v) (c_left/u-c_right/v)^2.

After division by V*, this is M(1-F*/W), between M/2 and M on the residual branch. This identity, independently developed in the parent proof, retains one common source mass and has no depth factor. It is a finite source-space identity; it does not provide the missing spatial integral bound for its edge terms.

The first nodes along each path with r_J>1/2 form a receiver-dependent antichain. They contain every captured leaf, their captured masses sum to F*, and their total node mass is strictly less than 2F* when F*>0. This row bound does not control the union of stopped nodes over all receivers. A single node may be selected by many receivers, and a source may belong to selected ancestors at different receivers. Applying (2.2) requires the all-receiver union mass or an independently paid aggregate deficiency. Summing W for every full tree level introduces a depth cost and is not a solution.

## 4. An actual-cube obstruction to one fixed hard partition

Fix even N>=40, put n=N+1, and take

    y_i=(e_i,0) in R^{N+1},    p_i=1/N,    W=1,    H=1/N.

Here e_i is the i-th standard basis vector of R^N. For every S subset of {1,...,N} with 2<=k=|S|<=N/2, there is a positive-volume region in B_H whose actual winner captures exactly S.

Proof. Choose a small delta>0, common to all these subsets, such that

    1/2+delta < (6/5)^(1/n)/2,       delta<1/4.

Let the first N receiver coordinates lie within delta of 1/2 for i in S, and within delta of -1/2 for i outside S. Let the last coordinate r satisfy

    (3k/5) < (2r)^n < (4k/5).

Then r>1/2+delta. Also r<1 because (4k/5)<=2N/5<2^n. The distance to every included site is exactly r, due to the last coordinate. The distance to every excluded site is greater than 3/2-delta>5/4. Thus the first physical arrival is precisely the entire tied group S, at volume V*=(2r)^n. Its average satisfies

    5H/4 < (k/N)/V* < 5H/3.

Every later arrival average is at most (5/2)^(-n)<1/N=H. Indeed 2^n>N for n=N+1, and 5/2>2. Before the first arrival the average is zero, and between arrivals it decreases. The first arrival is consequently the unique maximizing volume. Its captured mass is k/N<=1/2 and it has at least two sites. All receiver inequalities are strict on a product of nonempty open intervals, so the region has positive Lebesgue volume. The n-dimensional tying is an exact geometric feature, not a null-set tie discarded in computation.

Now consider one fixed disjoint hard partition of the sites into nonempty blocks J. For a query S, packet J has strict majority exactly when

    |J intersect S| > |J|/2.

If every two-site query has a majority packet, there cannot be two blocks of size at least 2: a pair containing one site from each has no majority in either. There cannot be a block of size at least 4: a pair inside it has captured size 2, which is at most half its size. Therefore every block is a singleton except possibly one block of size 2 or 3.

For any half-source query, k=N/2, every packet captures at most 3 sites. Its response fraction relative to the original winner is at most

    nu_J(Q*)/F* <= 3/k = 6/N.

Consequently no hard partition can cover all the positive-volume residual regions by majority plus eta-dominance when eta>6/N. In particular eta=1/sqrt(n) fails for even N>=40, since N^2>36(N+1). A mass-one hard partition using (2.2) with full pointwise coverage thus cannot have threshold cost eta^-1 better than N/6, which is of order n in this family.

This obstruction applies only to a single disjoint hard partition with universal pointwise coverage. It does not rule out fixed fractional partitions, overlapping families with paid multiplicity, several common trees, receiver-volume exceptions, or a weak estimate. The exhibited boxes may be extremely small. Their positive volume establishes failure of exact coverage, not a lower bound of the desired order on aggregate deficiency.

## 5. Scope, prior work, and numerical pressure

The retained repository notes source_partition_dominance_extension_20261007.md, source_fragment_localization_20261007.md, and general_source_packet_square_20261007.md were checked before this construction. They already require common source fragments and explicit dominance/fullness costs. Their bounded-scale support-box or square-profile interfaces do not supply the residual majority covering family used here. We do not claim that common packet allocation itself is new.

Current E03, G02 and M04 skill entrances, methods and cube interfaces were reread; their provenance status was inspected. E03 requires actual tree mass conservation and terminal terms before telescoping; no source Bellman theorem is invoked. G02 requires a separately proved covering/packing interface and does not convert this ordinary receiver volume into an outer-size estimate. M04's general selection statements remain scoped; the finite winner and finite packet choice here are proved Borel directly. No external theorem or bibliographic claim is used.

The numerical agent's source-only coordinate-median tree probes report eligibility coverage, the mass of the distinct selected-node union, source multiplicities, and threshold loss separately. A fixed-depth frontier is a genuine mass-W partition. The receiver-selected union may contain ancestors and descendants, so it must be charged as an overlapping family. The finite exact guard below checks source-tree algebra, hard-partition combinatorics, genuine physical cube winners, and the majority diameter mechanism. It performs no Monte Carlo integration and establishes no general asymptotic bound from finite results.

The unresolved general interface is

    E_t sum_a w_a(t)/eta_a(t)
      + H integral_{B_H} P_t(no eligible packet) dx
      <= sqrt(n)n^{o(1)} W,

with a shared actual source family. This is a sufficient condition with fully specified threshold and source costs. Neither the transfer nor the source variance identity proves it.

## 6. Reproducible exact guard

Run the following Python 3 block. All arithmetic is rational; roots in the construction are replaced by rational interior bisection witnesses. The finite checks supplement the analytic arguments above.

```python
from fractions import Fraction as Q
from itertools import combinations, product

counts = dict(tree=0, partitions=0, qualifying=0, geometry=0,
              majority_pairs=0, multiplicity=0)

def tree(ids, chain=False):
    if len(ids)==1:
        return ids[0]
    cut=1 if chain else len(ids)//2
    return (tree(ids[:cut],chain),tree(ids[cut:],chain))

def source_stats(t, weights, selected):
    if isinstance(t,int):
        w=weights[t]
        return w, w if t in selected else Q(0), Q(0), []
    a,b=(source_stats(c,weights,selected) for c in t)
    u,cu,qa,sa=a; v,cv,qb,sb=b
    w=u+v; c=cu+cv; r=c/w
    edge=u*(cu/u-r)**2+v*(cv/v-r)**2
    split=u*v/w*(cu/u-cv/v)**2
    assert edge==split
    return w,c,qa+qb+edge,[(w,c)]+sa+sb

def frontier(t, weights, selected):
    w,c,_,_=source_stats(t,weights,selected)
    if 2*c>w:
        return [(w,c)]
    if isinstance(t,int):
        return []
    return frontier(t[0],weights,selected)+frontier(t[1],weights,selected)

for N in range(2,9):
    weights=[Q(i%3+1,1) for i in range(N)]
    for mode in (False,True):
        t=tree(list(range(N)),mode)
        for mask in range(1,2**N):
            selected={i for i in range(N) if mask>>i&1}
            w,c,z,_=source_stats(t,weights,selected)
            assert z==c-c*c/w
            if 2*c<=w:
                stops=frontier(t,weights,selected)
                assert sum(s[1] for s in stops)==c
                assert sum(s[0] for s in stops)<2*c
            counts['tree']+=1

def partitions(n):
    def rec(i,blocks):
        if i==n:
            yield tuple(tuple(b) for b in blocks)
            return
        for j in range(len(blocks)):
            blocks[j].append(i)
            yield from rec(i+1,blocks)
            blocks[j].pop()
        blocks.append([i])
        yield from rec(i+1,blocks)
        blocks.pop()
    yield from rec(0,[])

for N in range(2,9):
    for p in partitions(N):
        counts['partitions']+=1
        allpairs=all(any(2*len(set(J)&set(S))>len(J) for J in p)
                     for S in combinations(range(N),2))
        structural=sum(len(J)>1 for J in p)<=1 and max(map(len,p))<=3
        assert allpairs==structural
        if allpairs:
            assert all(max(len(set(J)&set(S)) for J in p)<=3
                       for S in combinations(range(N),N//2))
            counts['qualifying']+=1
for N in (40,64,128,256):
    assert N*N>36*(N+1)  # 6/N < 1/sqrt(N+1)

def physical_winner(sites,weights,x):
    n=len(x)
    rs=[max(abs(a-b) for a,b in zip(x,y)) for y in sites]
    levels=sorted(set(rs))
    assert levels[0]>0
    arrivals=[]
    for r in levels:
        ids={i for i,s in enumerate(rs) if s<=r}
        v=(2*r)**n
        f=sum(weights[i] for i in ids)
        arrivals.append((f/v,v,ids,r))
    return max(arrivals,key=lambda z:(z[0],-z[1])),arrivals

def rational_r(n,k):
    lo,hi=Q(1,2),Q(1)
    for _ in range(100):
        r=(lo+hi)/2
        v=(2*r)**n
        if Q(3*k,5)<v<Q(4*k,5):
            return r
        if v<=Q(3*k,5): lo=r
        else: hi=r
    raise AssertionError('interior radius not found')

for N in (4,6,8,40,64):
    n=N+1; H=Q(1,N)
    sites=[tuple(Q(i==j) for j in range(N))+(Q(0),) for i in range(N)]
    weights=[Q(1,N)]*N
    subsets=(list(S) for k in range(2,N//2+1)
             for S in combinations(range(N),k)) if N<=8 else (
             list(range(k)) for k in sorted({2,3,4,N//4,N//2}))
    for S in subsets:
        r=rational_r(n,len(S))
        delta=min((r-Q(1,2))/4,Q(1,16))
        for phase in range(4):
            x=tuple((Q(1,2) if i in S else -Q(1,2))
                    +delta*Q((i+phase)%3-1,2) for i in range(N))+(r,)
            best,arrivals=physical_winner(sites,weights,x)
            assert best[2]==set(S)
            assert H<best[0]<2*H
            assert len(best[2])>=2 and Q(len(S),N)<=Q(1,2)
            assert all(z[0]<H for z in arrivals[1:])
            counts['geometry']+=1

for n in (1,2,3):
    sites=list(product((Q(-1),Q(0),Q(1)),repeat=n))
    weights=[Q(1,len(sites))]*len(sites)
    packets=[[Q(1) if i%3==a else Q(1,2) if i%3==(a+1)%3 else Q(0)
              for i in range(len(sites))] for a in range(3)]
    assert all(sum(a[i] for a in packets)==Q(3,2) for i in range(len(sites)))
    assert sum(sum(a[i]*weights[i] for i in range(len(sites)))
               for a in packets)==Q(3,2)
    counts['multiplicity']+=1
    receivers=[x for x in product((Q(-3,2),Q(-1,2),Q(0),Q(1,2),Q(3,2)),
                                  repeat=n) if x not in sites]
    H=Q(1,16); eta=Q(1,2)
    for a in packets:
        mass=sum(a[i]*weights[i] for i in range(len(sites)))
        eligible=[]
        for x in receivers:
            best,_=physical_winner(sites,weights,x)
            avg,v,ids,r=best
            f=avg*v; c=sum(a[i]*weights[i] for i in ids)
            if avg>H and 2*c>mass and c>=eta*f:
                assert v<mass/(eta*H)
                eligible.append((x,ids))
        for (x,I),(z,J) in combinations(eligible,2):
            assert sum(a[i]*weights[i] for i in I&J)>0
            assert max(abs(b-c) for b,c in zip(x,z))**n<=mass/(eta*H)
            counts['majority_pairs']+=1

print('PASS exact guard',counts)
```

Executed result: PASS, with 1,002 finite tree checks, 5,294 hard partitions
(217 satisfying all pair-majority queries), 820 actual physical-winner
checks, 40 majority receiver-pair checks, and 3 exact source-multiplicity
checks. The run used only the Python standard library and took under one
second on the current host. This is exact finite arithmetic verification,
not a floating-point interval claim or a spatial integration certificate.


# Shared source-tree variance and a pointwise coverage obstruction

This section gives an exact aggregate interface, not a new weak bound. It uses one source tree shared by all receivers. In particular, the tree is not chosen separately after seeing a winning cube. All source weights are positive; repeated sites have first been merged. The E03 finite-tree bookkeeping, G02 coverage-versus-cost distinction, and L03 exact-certificate restrictions are used. No external Bellman, outer-space, or martingale maximal theorem is imported.

## 1. A finite source martingale with an exact terminal term

Let `mu=sum_i p_i delta_{y_i}`, `W=sum_i p_i`, and let a finite rooted binary tree partition the source labels down to individual labels. For a node J write `w_J=sum_{i in J}p_i`. At a fixed receiver x and its genuine smallest-volume maximizing cube Q*, write

\[
V=|Q_*|,\quad c_J=\mu(Q_*\cap J),\quad r_J=c_J/w_J,
\quad F=\mu(Q_*),\quad M=F/V.
\]

Here intersections with J mean restrictions to its source labels. All node masses are positive. The source probability space has law `P(I=i)=p_i/W`. At fixed x, r_J along this source's tree path is the conditional expectation of `1_{y_I in Q*}`. This is a legitimate finite source martingale; it is not a spatial martingale and does not replace Lebesgue receiver measure by source measure.

For a split J=L union R, with u=w_L and v=w_R, direct expansion gives

\[
u r_L^2+v r_R^2-(u+v)r_J^2
=\frac{uv}{u+v}(r_L-r_R)^2.
\]

Summing over the finite tree cancels all internal terms. The leaf sum is F, since its membership values are zero or one. The root term is F^2/W. Consequently

\[
\mathcal V_T(x):=
\sum_{J\text{ internal}}\frac{w_Lw_R}{w_J}(r_L-r_R)^2
=\sum_{J\to K}w_K(r_K-r_J)^2
=F-\frac{F^2}{W}.                                      \tag{T1}
\]

No endpoint term has been discarded. For arbitrary trees with the stated leaves, the TOTAL quantity is the same; changing trees can redistribute its depths, but cannot lower its pointwise sum.

On the original residual band `B_H^res={H<M<=2H, Q* captures at least two sites, F<=W/2}`,

\[
\frac12M\le \frac{\mathcal V_T}{V}
=M(1-F/W)\le M.                                        \tag{T2}
\]

The finite selector from Round67 makes all these quantities measurable. Finite sums and nonnegative spatial integrals can be interchanged. An estimate

\[
\int_{B_H^{\rm res}}\frac{\mathcal V_T(x)}{V(x)}\,dx
\le b_n W                                                \tag{T3}
\]

would therefore give `H|B_H^res|<=2b_nW`. The already paid single-site and strict-majority branches, followed by dyadic threshold summation, give `C_n<=2+4b_n`. Conversely, a residual band bound controls (T3) up to a factor two. Thus (T3) is an equivalent aggregate difficulty, not a proved improvement. It retains actual shared-source geometry and avoids an unnecessary uniform per-source row requirement.

Stop each source path at its first node with r_J>1/2, if such a node exists. These stopped nodes form an antichain. Every captured source reaches a membership-one leaf and hence belongs to a stopped node; therefore the sum of their c_J is F. Since w_J<2c_J at each stopped node,

\[
\sum_{J\in\mathcal S(x)}w_J\le2F.                       \tag{T4}
\]

The set S(x) depends on x. Its union over receivers need not be an antichain. Replacing (T4) by a global bound on the union of activated nodes is unjustified; numeric activated-node unions are lower evidence of activity, not a complete continuum coverage certificate.

## 2. Why a small family of coordinate-order trees cannot promise pointwise dominance

Use the uniform source on `{−1,1}^n`, n>=2. Fix k coordinates, `1<=k<=floor(n/2)`, to the sign +1 and leave the others free. Let `epsilon=1/(100n)`. Consider the positive-volume receiver box

\[
|x_i-1|\le\epsilon\ (i\text{ fixed}),\qquad
|x_i|\le\epsilon\ (i\text{ free}).
\]

The full indicated subcube has source mass F=2^{-k}; its capture radius is `rho=1+max_free |x_i|`. Before rho, at least one free coordinate excludes half its vertices. Any nonempty earlier capture requires radius at least 1−epsilon, so its density is at most `F/[2(2(1−epsilon))^n]`. The density at rho is at least `F/[2(1+epsilon)]^n`, and is strictly larger, because

\[
2(1-\epsilon)^n>(1+\epsilon)^n.                         \tag{T5}
\]

For instance, `((1+epsilon)/(1−epsilon))^n <= (1+3epsilon)^n <=1/(1−3/100)<2`, using epsilon<=1/200 and the binomial coefficient bound. Any excluded fixed-coordinate vertex is at distance at least 2−epsilon. Subsequent densities are at most `1/[2(2−epsilon)]^n`, smaller than the preceding winner: `(2−epsilon)/(1+epsilon)>sqrt(2)` and k<=n/2. Between capture radii densities decrease. Thus the indicated subcube is the actual global winner, including at the nongeneric equal-distance points.

Choose `H=2^{-(n+k+1)}`. Since `(1+epsilon)^n<=100/99<2`, all these receivers lie in the true original band `H<M<=2H`. The winning capture includes at least two sources and at most half the mass.

A coordinate-order tree splits the vertex coordinates in a fixed permutation. At a compatible node, r_J is `2^{-s}`, where s is the number of still-unresolved fixed coordinates. Strict majority occurs only when all k fixed coordinates have been resolved. If D is the last position occupied by a fixed coordinate, there are `2^{D−k}` first-majority nodes, each capturing exactly a `2^{-(D−k)}` fraction of the original winning mass. All later nodes are smaller. A node response at least `2^{-m}` is therefore available if and only if

\[
D\le k+m.                                               \tag{T6}
\]

For a uniformly random coordinate order, with `0<=m<=n−k`, its exact probability is

\[
P(D\le k+m)=\frac{\binom{k+m}{k}}{\binom nk}.             \tag{T7}
\]

For even n, k=n/2 and m=O(log n), this is at most `(n+1)n^m/2^n`. The estimate follows from `binom(n,n/2)>=2^n/(n+1)` and `binom(k+m,m)<=n^m`. Consequently a polynomial number of common coordinate orders cannot guarantee a polynomial response fraction for every query. Indeed, average over the k-coordinate query subsets and apply the finite union bound; if the number of orders times (T7) is less than one, some query fails for all orders. This statement concerns this specified tree family and pointwise coverage. It says nothing against adaptive geometric trees, fractional covers, or aggregate exceptional-set estimates.

Crucially, these explicit difficult boxes are cheap in weak volume. Including all `binom(n,k)` coordinate choices and all `2^k` sign choices, the boxes are disjoint and their total normalized weak fee at the common H is

\[
H\sum |\text{box}|
=\frac12\binom nk\epsilon^n
\le\frac12(2\epsilon)^n.                               \tag{T8}
\]

Thus pointwise obstruction is not evidence of an unaffordable exceptional set. The appropriate next interface can allow coverage failure and bound its actual Lebesgue weak fee. The heldout full-space probe in this round separately measures such deficiencies; it does not infer their size from a worst receiver.

## 3. Exact multi-stage guards

The following standalone standard-library program exhausts 3,060 finite weighted tree/subset cases, checks 48 physical vertex receiver configurations with actual grouped-distance maxima, enumerates 21 permutation-probability cases, and verifies rational winner/box-fee inequalities for n=2,4,8,...,256. Small physical cases include ties; the large-dimensional combinatorial checks do not enumerate 2^n atoms. Its proofs are the arguments above, not these finite tests. No continuum weak estimate or asymptotic exponent is certified numerically.

The final archive embeds the program below so that this separate development file need not be added to Git. Run the extracted Python block with standard Python 3; no external library is required.


```python
"""Exact finite guards; no Monte Carlo or general weak-bound certification."""
from fractions import Fraction as F
from itertools import product, permutations
from math import comb
import json


def tree_check(weights, selected):
    def visit(ids):
        w = sum((weights[i] for i in ids), F(0))
        c = sum((weights[i] for i in ids if i in selected), F(0))
        if len(ids) == 1:
            return w, c, F(0), ([w] if c else [])
        mid = len(ids) // 2
        u, a, qa, sa = visit(ids[:mid])
        v, b, qb, sb = visit(ids[mid:])
        q = qa + qb + u*v/(u+v)*(a/u-b/v)**2
        stop = [w] if 2*c > w else sa+sb
        return w, c, q, stop
    w, c, q, stop = visit(list(range(len(weights))))
    assert q == c-c*c/w
    assert sum(stop, F(0)) <= 2*c
    if c <= w/2:
        assert c/2 <= q <= c


def physical(n, k, order, phase):
    eps = F(1, 100*n)
    fixed = set(range(n-k, n))
    x = [(F(1) if i in fixed else F(0))
         + F(((i+phase)%3)-1, 2)*eps for i in range(n)]
    vertices = list(product((-1, 1), repeat=n))
    p = F(1, 2**n)
    batches = {}
    for idx, y in enumerate(vertices):
        radius = max(abs(x[i]-y[i]) for i in range(n))
        batches.setdefault(radius, []).append(idx)
    mass = F(0)
    best = F(0)
    winner = set()
    seen = set()
    for radius, ids in sorted(batches.items()):
        seen.update(ids)
        mass += p*len(ids)
        avg = mass/(2*radius)**n
        if avg > best:
            best, winner = avg, set(seen)
    expected = {j for j, y in enumerate(vertices)
                if all(y[i] == 1 for i in fixed)}
    assert winner == expected
    H = F(1, 2**(n+k+1))
    assert H < best <= 2*H
    assert 2 <= len(winner) <= len(vertices)//2
    D = max(order.index(i)+1 for i in fixed)
    # First-majority nodes in the fixed coordinate-order tree.
    counts = {}
    for j in winner:
        key = tuple(vertices[j][i] for i in order[:D])
        counts[key] = counts.get(key, 0)+1
    assert len(counts) == 2**(D-k)
    assert {F(v, len(winner)) for v in counts.values()} == {F(1, 2**(D-k))}
    return len(batches)


def main():
    algebra = 0
    for N in range(2, 10):
        for raw in ([1]*N, list(range(1, N+1)), [2**i for i in range(N)]):
            weights = [F(w, sum(raw)) for w in raw]
            for bits in product((0, 1), repeat=N):
                tree_check(weights, {i for i,b in enumerate(bits) if b})
                algebra += 1
    geometries = 0
    batches = 0
    for n in (2, 3, 4, 6, 8):
        for k in sorted({1, n//2}):
            for order in (list(range(n)), list(reversed(range(n)))):
                for phase in range(3):
                    batches += physical(n, k, order, phase)
                    geometries += 1
    permutation_cases = 0
    for n in range(2, 8):
        k = n//2
        S = set(range(k))
        orders = list(permutations(range(n)))
        for m in range(n-k+1):
            success = sum(max(order.index(i)+1 for i in S) <= k+m for order in orders)
            assert F(success, len(orders)) == F(comb(k+m, k), comb(n, k))
            permutation_cases += 1
    pressure = []
    for n in (2, 4, 8, 16, 32, 64, 128, 256):
        k = n//2
        eps = F(1, 100*n)
        assert 2*(1-eps)**n > (1+eps)**n
        assert (2-eps)**(2*n) > 2**(2*k)*(1+eps)**(2*n)
        assert (1+eps)**n < 2
        m = (n.bit_length()-1)//2
        probability = F(comb(k+m, k), comb(n, k))
        all_boxes_fee = F(comb(n,k), 2)*eps**n
        assert all_boxes_fee <= F(1,2)*(2*eps)**n
        pressure.append({'n': n, 'k': k, 'm': m,
                         'success_probability_exact': str(probability),
                         'success_probability_display': float(probability),
                         'all_boxes_fee_exact': str(all_boxes_fee)})
    print(json.dumps({'algebra_cases':algebra, 'physical_geometries':geometries,
                      'physical_batches':batches, 'permutation_cases':permutation_cases,
                      'pressure':pressure, 'status':'PASS; finite exact guards only'},
                     sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
```


# Round 68: common source partitions on the actual residual band

This probe tests a shared source-only coordinate-median tree against actual centered-cube winners. It does not test independently optimized partitions at each receiver. The numerical pressure has two distinct outcomes: a fixed response requirement can leave substantial residual weak-band volume uncovered, and using different tree levels across receivers can repeatedly charge the same source mass. The observed union of selected nodes is a lower witness of activation, not a certified family covering every receiver.

The final standalone program is `partition_probe.py`, with adjacent `partition_results.json`. It ran 15 pilot rows / 7,680 draws and 78 heldout rows / 159,744 draws: 93 rows / 167,424 draws in total. The program stores source coordinates and rational masses, true thresholds, seeds, tree memberships, complete proposal information, selected-node unions, per-source multiplicities, response distributions, per-depth quadratic portions, and retained receiver guards. It uses the whole receiver space; there is no spatial box, scale grid, or fitted growth exponent.

## Actual geometry and shared candidate

For a finite positive source \(\mu=\sum_i p_i\delta_{y_i}\), \(W=\sum_i p_i\), the true maximal function is computed from grouped physical arrival volumes
\(v_i=(2\|x-y_i\|_\infty)^n\). Equal distances are complete batches. Between arrivals the average decreases, so testing all batch endpoints computes the all-scale maximum. The winner is the smallest-volume maximizing cube, including every atom in its final batch. The original band is \(B_H=\{H<M\mu\le2H\}\); its residual subset has at least two distinct source sites in the winner and captured mass \(F\le W/2\), with equality retained.

The tree is fixed before receivers are sampled. At each node it chooses the coordinate of largest machine-coordinate span (first axis on a tie), orders sites by that coordinate and then original site index, and splits at the nonempty prefix nearest half the node's rational total mass (smaller cut on a tie). Atoms are indivisible. Nodes are indexed in deterministic preorder. Every depth frontier, with terminal leaves carried forward, is a genuine partition of the original source and has total mass exactly \(W\). The family of all tree nodes instead has total mass \(\sum_J W_J\), generally exceeding \(W\).

For an original residual winner \(Q_*\), let \(c_J=\mu_J(Q_*)\). A node is eligible at response \(\eta\) when

\[
c_J>W_J/2,\qquad c_J\ge\eta F.
\]

The second condition gives \(\mu_J(Q_*)/|Q_*|\ge\eta M\mu(x)>\eta H\); this is an actual majority-cube witness for that common source node. The registered responses are \(1/2,1/4,1/8,1/\sqrt n\). Eligibility for the last is tested by the exact integer square comparison \(n c_J^2\ge F^2\), not by a floating square root comparison.

Among eligible nodes, the program chooses the smallest total node mass, then smallest node index. This receiver-dependent selection is only a diagnostic within the fixed shared tree. Its candidate global fee involves the union of distinct nodes selected across receiver space, \(\sum_J W_J/\eta\), not an average of selected masses. The program records both the union in each sample and the union across the two heldout seeds. Source multiplicity is counted explicitly; the union-mass identity \(\sum_J W_J=\sum_i p_i\,\mathrm{multiplicity}_i\) is checked. An unsampled region can activate more nodes, so a sampled union never supplies an upper bound on this fee.

For each fixed frontier it separately records majority-covered captured fraction, best majority response, and the weak-volume-weighted eligible coverage. Its predeclared fee is \(W/\eta\). The full tree's predeclared fee is \(\sum_JW_J/\eta\). These are different from the sampled active-node fee. The best response distribution over all majority nodes is weighted by original residual receiver volume; it does not merely report a worst point.

## Quadratic tree identity and local stopping

With \(r_J=c_J/W_J\), the exact source-tree identity is

\[
\sum_{J\to K}W_K(r_K-r_J)^2=F-F^2/W.
\]

For a binary split with child masses \(u,v\) and captures \(c_L,c_R\), its contribution equals
\(uv/(u+v)(c_L/u-c_R/v)^2\). Dividing the whole identity by the original winner volume gives \(M\mu(1-F/W)\), between \(M\mu/2\) and \(M\mu\) on the residual subset. The program records each depth's portion and its weak-volume-weighted fraction. Independent finite-point Fraction guards verify the edge sum, binary form, and final identity exactly.

It also stops separately at the first strict-majority node on each captured branch. This yields a local antichain covering all captured atoms; its total node mass is strictly less than \(2F\). That local guarantee does not bound the union of antichains selected at different receivers. The program reports their sampled common union and source multiplicities rather than converting the local inequality into a global budget.

## Registered stages and sampling

The 15 pilots use 512 draws each: equal/unequal nested and common-face sources in \(n=1,4,16\), \(N=64\); one-dimensional midpoint grids at \(H=1/4,2\); and four frozen Round 65 geometries. These pilots established which tests produced measurable original residual bands. They are labeled and are not pooled into heldout estimates.

The fixed heldout expansion has 39 configurations, two independent seeds each:

| Family | Configurations | Total draws |
|---|---:|---:|
| Common-face sources, \(n=2,4,8,16,32\), independently \(N=16,64,128\), 2,048 per seed | 15 | 61,440 |
| Four retained Round 65 sources, 4,096 per seed | 4 | 32,768 |
| Actual uniform vertices, \(n=4,8\), \(N=2^n\), two thresholds, 2,048 per seed | 4 | 16,384 |
| Seeded unequal random clouds, \(n=4,8,16,32\), \(N=16,64\), 2,048 per seed | 8 | 32,768 |
| Equal/unequal nested controls, \(n=4,16\), \(N=16,64\), 1,024 per seed | 8 | 16,384 |

All sources have positive rational weights and mass one. The retained Round 65 geometries preserve historical selection bias; receiver seeds are fresh. Vertex thresholds are \(H=2^{-(n+\lfloor n/2\rfloor+1)}\) and \(H=8^{-n}\). Clouds use dyadic coordinates, weights proportional to \((j+1)^2\), and \(H=3^{-n}\). Nested and common-face tests use \(H=4\). Dimension and source count are separately varied in the common-face and cloud families; the vertex relation \(N=2^n\) is explicitly special.

The full-space proposal is the final Round 67 three-component mixture. For cube-cone volume \(v\) about a source center, use the normalized radial density \(q_b(v)=1/(2b)\) for \(v\le b\), and \(b/(2v^2)\) otherwise. Each branch integrates to one half under \(dx=dv\,d\sigma\). Sampling uses \(v=bU\) or \(b/U\), with uniform cube-cone faces, signs and free coordinates. Machine zero \(U\) is replaced by the next positive float.

Set \(V=W/(2H)\), \(a_i=p_i/W\), \(\tau_i=v_i/V\). Choose a quarter global scale \(V\) with source probabilities \(a_i\), a quarter individual scales \(a_iV\) with source probabilities \(a_i\), and a half individual scales with centers chosen uniformly among distinct sites. The entire density is evaluated at every receiver:

\[
q(x)=V^{-1}q_{\rm core}(x),\quad
q_{\rm core}=\tfrac18\sum_i a_i\min(1,\tau_i^{-2})+
\tfrac18\sum_i\min(1,(a_i/\tau_i)^2)+
\frac1{4N}\sum_i a_i^{-1}\min(1,(a_i/\tau_i)^2).
\]

The normalized weak-volume score is \(\mathbf1_{B_H}/(2q_{\rm core})\). Since \(\tau_i\ge a_i\) on the band, it is at most \(16N\). Every coverage or uncovered score is a subset of this score. The quadratic density score is at most twice this envelope. JSON summaries retain sample SEs and formal per-summary ideal 95% Hoeffding radii. Heldout weak-score SEs range from 0.001589 to 0.069073; residual-score Hoeffding radii range from 5.4324 to 122.9213 and do not resolve the estimates. These ideal independent-sampling radii do not include floating error, are not simultaneous guarantees, and are not a certification of the machine sampler. Coverage ratios and selected maxima have no claimed certified confidence interval.

## Heldout findings

Two-seed residual means below are estimates of \(H|B_{\rm residual}|/W\); their reported SE is \(\sqrt{\mathrm{SE}_1^2+\mathrm{SE}_2^2}/2\). Coverage fractions are ratios of corresponding weighted means. Union masses combine both seeds but remain lower activity witnesses.

| Source | Residual mean ± SE | Coverage at \(\eta=1/2\) | Sampled selected-node union mass / \(W\) |
|---|---:|---:|---:|
| Common-face \(n=4,N=64\) | 0.50060 ± 0.03227 | 100% | 2.0625 |
| Common-face \(n=16,N=64\) | 0.54783 ± 0.03310 | 100% | 1.671875 |
| Common-face \(n=32,N=128\) | 0.47221 ± 0.03311 | 100% | 1.5 |
| Retained perturbed \(n=4,N=16\) | 0.04214 ± 0.00495 | 71.08% | 1.8125 |
| Retained \(n=16,N=64\) | 0.05530 ± 0.00576 | 85.21% | 1.07432 |
| Vertices \(n=4,H=8^{-4}\) | 0.35791 ± 0.01921 | 60.10% | 2.5625 |
| Vertices \(n=8,H=8^{-8}\) | 0.42645 ± 0.03356 | 12.47% | 1.32422 |
| Unequal cloud \(n=4,N=64\) | 0.19340 ± 0.01251 | 73.74% | 4.31544 |

The eight-dimensional vertex case at \(H=8^{-8}\) supplies the clearest volume-sensitive threshold-loss pressure in this finite computation. Its two seeds have 101 and 82 original residual hits. The \(\eta=1/2\) uncovered residual estimate is 0.37327 ± 0.03149, derived from disjoint response-bin score moments. Coverage rises to 31.23% at \(\eta=1/4\) and 46.85% at \(\eta=1/8\), still leaving substantial sampled deficiency. No fitted dependence on dimension or source count follows from this family.

The other eight-dimensional vertex threshold, \(H=2^{-13}\), has only two residual hits in one seed and one in the other. Its residual estimate 0.00832 ± 0.00499 and zero observed coverage at all registered responses are highly uncertain. The sampler does not resolve the rare positive-volume boxes in the independent analytic pressure construction. Their deterministic analytic guards are separate from this Monte Carlo output.

Common-face tests show a different obstruction. Although all sampled residual receivers have a qualifying \(\eta=1/2\) node, those nodes are selected across different depths. In \(n=4,N=64\), the sampled union charges some sources five times and has mass 2.0625\(W\); the local first-majority antichains' combined union has mass 3.84375\(W\). The best fixed frontier at this response covers about 95.27% of sampled residual volume, rather than the all-depth family's 100%. In \(n=16,N=64\), the corresponding best frontier covers about 94.17%. These observations require paying total common-family mass and retaining uncovered volume, rather than assuming a one-level cost \(W\).

In the \(n=4,N=64\) unequal cloud, the \(\eta=1/2\) selected union has mass 4.31544\(W\), and its maximum source multiplicity is seven. The associated candidate threshold fee is about 8.63\(W\). At \(\eta=1/4\), coverage improves to 99.77%, but the sampled union mass is still about 2.86813\(W\), with threshold fee about 11.47\(W\). This is a measured tradeoff for this fixed tree, not a lower bound against every shared partition scheme.

The per-depth quadratic identity is not uniformly concentrated at the root. Common-face \(n=16,N=64\) gives roughly 70% of its weak-volume-weighted quadratic fraction in the first two depths. The retained \(n=16,N=64\) candidate places roughly 61% in depths five and six, with small first-two-depth portions. In the eight-dimensional \(H=8^{-8}\) vertex case, every depth contributes, and the final depth has about 25–28%. These are depth distributions for the registered source-only trees, not a general concentration law.

Grid and deeply nested controls mostly have no observed original residual band at their registered thresholds. Their null observed residual estimates are not statements that the exact residual set is empty. They remain controls for actual grouped maxima and common tree construction rather than evidence about the unresolved aggregate residual budget.

## Finite guards and evidence boundary

There are 159 retained actual extremes, including maximum \(\eta=1/2\) uncovered score points, and 312 closest gate points from both sides of \(M/H=1,2\). Nine controlled receiver geometries test line/common-face ties in dimensions 1, 4 and 16. Exact duplication of source labels is merged and leaves the source and its tree unchanged. Three far-separated-copy checks prove unchanged local capture and the exact local half-mass scaling at specified receivers; they assert no global independence of copies or coarse cubes.

The guard reconstructs actual binary machine-coordinate distances as integers, computes arrival volumes as Fractions, checks the true minimal winner and gate, calculates the full mixture density rationally, and verifies tree eligibility and the edge identities exactly at that point. Proposal values and \(M/H\) are additionally printed at nearest-rounded Decimal precisions 80 and 120. The maximum retained full-density relative discrepancy is \(4.83\times10^{-15}\); the maximum 80/120-digit relative density change is \(4.68\times10^{-80}\). The largest floating tree-identity residual over all draws is \(1.12\times10^{-16}\). All retained captures, gates and eligibility comparisons pass the rational guards.

Across all draws, 102,638 receiver rows required exact binary distance grouping; 93,434 falsely equal log-distance boundaries were corrected. No row triggered the extra near-maximal-density or near-gate rational winner fallback in this registered run; the retained guards independently use rational winner computation regardless. The minimum sampled gate log-margin is \(1.081\times10^{-6}\).

Current L01/L02/L03/H05 entries and relevant method/interface restrictions were reread. Exact finite-point Fraction checks and nearest-rounded Decimal agreement are distinguished from interval-certified integration. No general outward interval API, classification at every receiver, continuous-space volume certificate, or general source-to-partition theorem is certified by this program. The source geometries are real finite positive inputs; no unrelated tree realization is substituted for their cube averages. The aggregate majority-transfer argument and independent deterministic pressure constructions belong to the analytic companion. Sampled active-family mass and finite coverage cannot be used as a global covering proof.

## Reproduction and freeze

Run the final program without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round068_20261011/partition_probe.py
```

It writes `partition_results.json` beside itself. `--pilot` intentionally runs only the 15 pilot rows and overwrites that output with status `PILOT`; it is not the archive replay command. The final file is standalone, contains the retained source data, and imports no prior-round program. Python 3.12.14 / NumPy 2.3.5 were used; BLAS thread counts are set to one. The final run exited 0 in 48.4211 seconds. The parent independently replayed the full program in a temporary directory: exit 0, 48.6826 seconds, byte-identical JSON. There is no live computation session. Runtime is excluded from JSON.

Frozen SHA-256:

- `partition_probe.py`: `aaeb4a75f5c9a7b3291e81fac327412d76fadff796c0c2ef0580c1a01cd9ebf0`
- `partition_results.json`: `33595a25eb66f7270f191b086afbf1254d2bcd8531c5c107e2604bd0cc01e173`

The script and data are frozen; no further sampling or edits are planned.


## Independent verification receipt

```json
{
  "round": 68,
  "previous_goal_turn": "progress: Round67 archived, pushed and verified on origin/main",
  "main": {
    "directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round068-main-replay-j7h2lgqa",
    "exit_code": 0,
    "runtime_seconds": 48.682566499999666,
    "byte_identical": true,
    "output_sha256": "33595a25eb66f7270f191b086afbf1254d2bcd8531c5c107e2604bd0cc01e173",
    "script_sha256": "aaeb4a75f5c9a7b3291e81fac327412d76fadff796c0c2ef0580c1a01cd9ebf0",
    "stderr": "",
    "stdout_tail": "dual 0.007305945231471682 half 0.0 union 0.0\nheldout 22 vertices 8 256 residual 0.36667758520934723 half 0.10902056307446248 union 0.82421875\nheldout 23 unequal_cloud 4 16 residual 0.1641669549036734 half 0.9549709538048358 union 2.9859625668449197\nheldout 24 unequal_cloud 4 64 residual 0.19318814564284104 half 0.6723114339435715 union 3.5474955277280857\nheldout 25 unequal_cloud 8 16 residual 0.12864941582017447 half 0.9280461393758217 union 2.5929144385026737\nheldout 26 unequal_cloud 8 64 residual 0.16348170084044478 half 0.8683951115881717 union 1.55996198568873\nheldout 27 unequal_cloud 16 16 residual 0.016485397092777163 half 0.9250114572450404 union 0.5848930481283422\nheldout 28 unequal_cloud 16 64 residual 0.04100072703183631 half 0.9275186969108805 union 0.5006596601073345\nheldout 29 unequal_cloud 32 16 residual 0.0 half None union 0.0\nheldout 30 unequal_cloud 32 64 residual 0.0 half None union 0.0\nheldout 31 nested_cluster 4 16 residual 0.004368622871944566 half 1.0 union 0.0625\nheldout 32 unequal_nested 4 16 residual 0.0 half None union 0.0\nheldout 33 nested_cluster 4 64 residual 0.0 half None union 0.0\nheldout 34 unequal_nested 4 64 residual 0.0 half None union 0.0\nheldout 35 nested_cluster 16 16 residual 0.0019742738302348855 half 1.0 union 0.0625\nheldout 36 unequal_nested 16 16 residual 0.0 half None union 0.0\nheldout 37 nested_cluster 16 64 residual 0.0 half None union 0.0\nheldout 38 unequal_nested 16 64 residual 0.0 half None union 0.0\nruntime 48.626190458002384\n"
  },
  "embedded": {
    "signed_total_budget": {
      "source_sha256": "6c337aaa7322c5b6dbf40dc91e362b027b485ade67c7fc6267ac2efb38df4151",
      "guard_sha256": "33468dba4b6ae9047a4c0e116e4c377108cdd8b1c92f0d9d62b681b0c51f1bf5",
      "exit_code": 0,
      "runtime_seconds": 2.4896737079980085,
      "stdout": "{\"binary_rectangles\":{\"exact_parent_ties\":16,\"receiver_scales\":2358,\"selected\":64,\"shield_samples\":192,\"source_configurations\":32,\"threshold_averages\":10374},\"layers\":{\"cases_with_negative_cross_terms\":54,\"max_relaxed_constant_ratio_float\":1.3158197077593456,\"rational_signed_layer_cases\":72,\"wide_height_algebraic_pressure\":[{\"energy_over_mass\":2,\"levels\":2},{\"energy_over_mass\":4,\"levels\":4},{\"energy_over_mass\":8,\"levels\":8},{\"energy_over_mass\":16,\"levels\":16},{\"energy_over_mass\":32,\"levels\":32},{\"energy_over_mass\":64,\"levels\":64},{\"energy_over_mass\":128,\"levels\":128}]},\"scope\":\"exact Fraction finite geometry/algebra guards; testing (T) remains unproved\"}\n",
      "stderr": "",
      "directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round068-signed-final-ioxej64f"
    },
    "shared_mass_partition": {
      "source_sha256": "c3cc5b13b7eb045bbec14466b0c9d9c7c384c1e3e46542de12df5685633ad688",
      "guard_sha256": "1bcd057734d029dd8b75f0460a746960f60c348716f87ed7acaa74edd64498b3",
      "exit_code": 0,
      "runtime_seconds": 0.28386141700320877,
      "stdout": "PASS exact guard {'tree': 1002, 'partitions': 5294, 'qualifying': 217, 'geometry': 820, 'majority_pairs': 40, 'multiplicity': 3}\n",
      "stderr": "",
      "directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round068-shared_mass_partition-etfc4_m8"
    },
    "tree_variance": {
      "guard_sha256": "76ec2d5d8a3107b8997a3041e866d1216f91c382a7ed5783e7ecec9f62b2c3a2",
      "exit_code": 0,
      "runtime_seconds": 0.19803566700284136,
      "stdout": "{\n  \"algebra_cases\": 3060,\n  \"permutation_cases\": 21,\n  \"physical_batches\": 172,\n  \"physical_geometries\": 48,\n  \"pressure\": [\n    {\n      \"all_boxes_fee_exact\": \"1/40000\",\n      \"k\": 1,\n      \"m\": 0,\n      \"n\": 2,\n      \"success_probability_display\": 0.5,\n      \"success_probability_exact\": \"1/2\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"3/25600000000\",\n      \"k\": 2,\n      \"m\": 1,\n      \"n\": 4,\n      \"success_probability_display\": 0.5,\n      \"success_probability_exact\": \"1/2\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"7/33554432000000000000000\",\n      \"k\": 4,\n      \"m\": 1,\n      \"n\": 8,\n      \"success_probability_display\": 0.07142857142857142,\n      \"success_probability_exact\": \"1/14\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"1287/368934881474191032320000000000000000000000000000000\",\n      \"k\": 8,\n      \"m\": 2,\n      \"n\": 16,\n      \"success_probability_display\": 0.0034965034965034965,\n      \"success_probability_exact\": \"1/286\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"60108039/2923003274661805836407369665432566039311865085952000000000000000000000000000000000000000000000000000000000000000\",\n      \"k\": 16,\n      \"m\": 2,\n      \"n\": 32,\n      \"success_probability_display\": 2.54541659560712e-07,\n      \"success_probability_exact\": \"1/3928630\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"916312070471295267/3940200619639447921227904010014361380507973927046544666794829340424572177149721061141426625488491564080662799030681600000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\",\n      \"k\": 32,\n      \"m\": 3,\n      \"n\": 64,\n      \"success_probability_display\": 3.571381525419418e-15,\n      \"success_probability_exact\": \"5/1400018442278526\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"95804584167712331464542351105522207/42263562490853219708187182793321328521507786082889721770236856722133912204537988757953380471012575031573951599460570294310587804760214842980043118277035166152670934719920406733498521414114115284241938632656895072331842263420124939107071751901362918119163086471819039866880000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\",\n      \"k\": 64,\n      \"m\": 3,\n      \"n\": 128,\n      \"success_probability_display\": 2.000113059982144e-33,\n      \"success_probability_exact\": \"1/499971736602193567814123531497350\"\n    },\n    {\n      \"all_boxes_fee_exact\": \"576865882344920633808974835786228688774021170197516203260843656726451875079/646340121426220146014297533773399039208882053394309680642606908550493102777357817863944028230458269273774359218437960389882391183009818421901763047728965662412617547346019921835003955007793042135921152767681351365535844372852395123236761886769523409411632917040726100857751517830821316172151047982478607710438286667793366848413699495731291389897123520706526441161556113186620523854169206283005171857283542334518872074369237147151967023046032918088073952264665744624542513694216404194503142034538626469393570851613133958700919945367059972764310503327788746710872042708664592092906369572099042963871117072221191924613120000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\",\n      \"k\": 128,\n      \"m\": 4,\n      \"n\": 256,\n      \"success_probability_display\": 2.0945570486651593e-69,\n      \"success_probability_exact\": \"1/477427912807287917321192784433579417968639821198106399526966387903494\"\n    }\n  ],\n  \"status\": \"PASS; finite exact guards only\"\n}\n",
      "stderr": ""
    }
  },
  "frozen_hashes": {
    "signed_total_budget.md": "6c337aaa7322c5b6dbf40dc91e362b027b485ade67c7fc6267ac2efb38df4151",
    "signed_total_budget.tex.txt": "1044593effabd116e1c04f9c9621a68132aa7c79b3317ac5ddcd31e92f9a7ae0",
    "shared_mass_partition.md": "c3cc5b13b7eb045bbec14466b0c9d9c7c384c1e3e46542de12df5685633ad688",
    "shared_mass_partition.tex.txt": "b96bb2331341e2dd93b359ce6a0ad1d46802adb393e0a83d493b8df3cebea339",
    "tree_variance.md": "63b97c647d71491af8943c3b4f9f3e509c5ca19fd009e19c16ab8ab463a91af7",
    "tree_variance.tex.txt": "3a90e66cd0d5f30fa1a8c05b1c826dc43987c34610587aad2421cc45b200c59c",
    "tree_variance_guard.py": "76ec2d5d8a3107b8997a3041e866d1216f91c382a7ed5783e7ecec9f62b2c3a2",
    "partition_numeric.md": "acf95b231f50fa8bacc94863ff5c7da72e43e2cd2cdf5e568d8d4b8642c938be",
    "partition_probe.py": "aaeb4a75f5c9a7b3291e81fac327412d76fadff796c0c2ef0580c1a01cd9ebf0",
    "partition_results.json": "33595a25eb66f7270f191b086afbf1254d2bcd8531c5c107e2604bd0cc01e173"
  },
  "proof_review": {
    "signed_total_budget": "Full Markdown and TeX independently read; binary nested cells, positive Borel residual domination, strict containing-cube shield, full-logtime coupling error, constant-loss Hilbert layer reduction, intrinsic indicator subset implication and unresolved weak return checked. Final threshold-average guard independently replayed.",
    "shared_mass_partition": "Full Markdown and TeX read; majority center diameter, explicit eta and weighted source multiplicity, randomized deficiency, actual e_i tied arrival geometry and hard partition combinatorics checked.",
    "tree_variance": "Direct finite telescoping, terminal/source law, true Boolean cube winner, permutation counting and total rare-box fee derived; exact multistage guard executed.",
    "partition_numeric": "Main source-tree construction, true grouped winner, rational node qualification, full-mixture score and bounds, per-depth identity and sample union scopes read. Full report reviewed; vertex uncovered score moments independently recomputed. No continuum numerical certification."
  },
  "used_skill_entries": {
    "math-e03-tree-bellman-cross-layer-budget": "5d587651365016a56122a262b05bdd2faa12166df5de70ec7d5e2ccea1a8377d",
    "math-g02-outer-lp-size-and-tree-stopping": "2d17a11f000d8016583ca4427a9a9099f5c37b9ec09286fb50d01c6aa848ec1d",
    "math-l03-rational-and-interval-certificates": "0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c",
    "math-f02-tensor-fourier-positivity-soft-square-supremum": "f6ea283da12ee2ebdceb352f8ef3cf0cd1d98752df08dca35ec84c18457cec8b",
    "math-f05-l2-spectral-parameter-schur-test": "9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9",
    "math-n03-oscillation-and-geometric-remainder": "2ede839f40e7337d4b9293d5d9b306a3f9361b89f70c7c2e282164583d9576dd",
    "math-m04-measurable-supremum-selection": "94d345413090478f55cf675d0db8127ae997d44aba919888f958306dfff5e293",
    "math-l01-lower-bound-test-parameters": "780eefeb65f87067a273799b40900e4e0129d183ab1c5faa6dd0be520d43f917",
    "math-l02-adversarial-input-search": "a4a7afc38da948ea8677142d694bbb31960e9791be9ed58d34ef49557157a343",
    "math-h05-chernoff-hoeffding-bernstein": "ea957eb2ef4224d5068a012ecf2eaae520a25213bf6dc3befb69e9af043b31f4"
  }
}
```
