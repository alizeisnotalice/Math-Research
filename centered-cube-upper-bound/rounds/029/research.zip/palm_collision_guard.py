from fractions import Fraction as F
from itertools import combinations
from math import comb
import json
from pathlib import Path

def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return c

def check(theta,k,p):
 # Every expression is divided by the common factor exp(-sum(theta)).
 C=len(theta); terminal=F(0); initial=F(0)
 for s in range(C+1):
  for S in combinations(range(C),s):
   w=F(1)
   for j in S:w*=theta[j]
   if s>=k:initial+=w
   terminal+=w*sum((F(comb(s,j))*p**j*(1-p)**(s-j) for j in range(k,s+1)),F(0))
 poly=[F(0)]*(C-k+1)
 for A in combinations(range(C),k):
  w=F(k); a=[F(1)]
  for j in range(C):
   if j in A:w*=theta[j]
   else:a=mul(a,[1+theta[j],-theta[j]])
  for j,v in enumerate(a):poly[j]+=w*v
 flux=sum((v*(1-p**(k+j))/F(k+j) for j,v in enumerate(poly)),F(0))
 assert terminal+flux==initial
 return {'cells':C,'k':k,'p':str(p),'initial_scaled':str(initial),'terminal_scaled':str(terminal),'flux_scaled':str(flux)}

rows=[]
for C in (2,3,5,8):
 for pattern in range(3):
  theta=[F(1,C) if pattern==0 else F(j+1,3) if pattern==1 else F(1,2**j) for j in range(C)]
  for k in sorted(set((2,min(3,C),C))):
   for p in (F(0),F(1,4),F(1,2),F(1)):
    rows.append(check(theta,k,p))
# Counterexample to checking only surviving cell labels at a final exit:
# Three initially live labels A,A,B, k=2, all eventually die.
# At the unique 2->1 crossing the pre-death pair is distinct iff the first
# death was one of the two A labels: probability 2/3. Full-path C2 already
# occurred at t=0, so the correct collision-free event has probability 0.
wrong=F(2,3); correct=F(0)
assert wrong>correct
out={'status':'PASS','exact_cases':len(rows),'cases':rows,'path_guard_counterexample':{'initial_labels':['A','A','B'],'threshold':2,'full_path_residual':str(correct),'present_pair_only':str(wrong)},'scope':'Pure-death exact algebra, with Poisson cell weights; not a general spatial weak-type bound.'}
Path(__file__).with_name('results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(rows),'rational identities; full-path counterexample 0 versus 2/3')

# Independent diagnostic of the actual axial source. The continuum receiver
# distribution is exact: P(sum(U_j**n)<=s)=Gamma(1+1/n)**n*s for 0<=s<=1.
# Floating diagnostics below do not certify this identity or asymptotic order.
import math, random
axes=[]
for n in (64,128,256,1024,4096,65536,1048576):
 T=n*math.log(2); m=math.ceil(64*math.log(2+T)); ell=(4*m)//5
 A=math.exp(n*math.lgamma(1+1/n))
 asym=-0.5772156649015329+math.pi**2/(12*n)
 remainder=2/(3*n*n*(1-1/n))
 # lgamma loses precision after multiplication by n: include a diagnostic
 # rounding allowance; no interval-certificate claim.
 assert abs(math.log(A)-asym)<=remainder+1e-8
 escape=0.25-0.6*m*T*(0.75**(m-ell))
 beta=n**(1/n)*(.51**(1-1/n))
 mode=math.exp(-m+m*math.log(m)-math.lgamma(m+1))
 assert escape>=.125 and beta<.6 and mode>=3/(20*math.sqrt(m))
 time=[]
 for fraction in (0,.25,.5,.75,1):
  t=T*fraction
  atom=.01*math.exp(-t)
  h=(1-atom)/2
  hi=h+1/(100*math.sqrt(m))
  assert 0<h<hi<1
  q=m*(2*hi+atom)
  pi=math.exp(-q+m*math.log(q)-math.lgamma(m+1))
  band=A*(hi-h)
  column_per_time=m*band*pi*escape
  assert pi>=3/(40*math.sqrt(m))
  assert column_per_time>=9/12800000
  time.append({'t_fraction':fraction,'band_probability':band,'pi_at_upper_q':pi,'analytic_lower_bound_float':column_per_time})
 axes.append({'n':n,'T':T,'m':m,'gamma_density':A,'beta_upper':beta,'survival_lower':escape,'time_checks':time})
# Initial, stress and enlarged independent checks of the Dirichlet receiver law.
mc=[]
for n,N,seed in ((8,12000,290081),(64,16000,290064),(256,20000,290256)):
 rng=random.Random(seed); count=0
 for _ in range(N):
  S=sum(rng.random()**n for j in range(n))
  count+=S<=.5
 exact=.5*math.exp(n*math.lgamma(1+1/n))
 # A 99% Hoeffding bound, not a confidence statement for the theorem.
 err=math.sqrt(math.log(200)/(2*N))
 assert abs(count/N-exact)<=err
 mc.append({'n':n,'N':N,'seed':seed,'count':count,'estimate':count/N,'exact_formula_float':exact,'hoeffding_99_halfwidth':err})
out['axial_source_diagnostics']=axes
out['receiver_law_monte_carlo']=mc
out['scope']+=' Axial diagnostics use floats and three seeded Monte Carlo batches; all-n column obstruction is established analytically in proof.'
Path(__file__).with_name('results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS 35 axial time checks, 7 dimension guards, 3 receiver-law batches')

# Local candidate exclusion in actual one-dimensional cube geometry.
# Set m/lambda=1; intensities rescale linearly. Endpoint samples are excluded
# because the probabilistic formulas integrate continuous mark heights.
geometry=[]
for L in (F(1),F(3,2),F(2)):
 for x in (F(-1,4),F(0),F(1,3)):
  for yoff in (F(-1,3),F(0),F(1,4)):
   y=x+L*yoff; d=F(1,4); cy=y//d
   source=[(x+L*F(j,8),F(j+5,13)) for j in range(-4,5)]
   ht=1/L; hy=1/max(F(1),2*abs(x-y)); b=F(0); kap=F(0); checks=0
   for z,w in source:
    if z//d!=cy:continue
    hz=1/max(F(1),2*abs(x-z)); cap=min(hy,hz)
    b+=w*ht; kap+=w*(cap-ht)
    cuts=sorted(set((F(0),ht,hy,hz,F(1))))
    for lo,hi in zip(cuts,cuts[1:]):
     u=(lo+hi)/2
     # Candidate lives from entry_y to L, partner lives from entry_z
     # until reciprocal cap 1/u, and intersection of these intervals is tested.
     start=max(F(1),2*abs(x-y),2*abs(x-z))
     actual=start<min(L,1/u) if L>start else (start==L and u<1/L)
     forbidden=u<cap
     assert actual==forbidden
     assert (forbidden and u>ht)==(ht<u<cap)
     checks+=1
   assert kap>=0
   geometry.append({'L':str(L),'x':str(x),'y':str(y),'cell_current_intensity':str(b),'past_forbidden_intensity':str(kap),'interval_checks':checks})
out['local_exclusion_geometry']=geometry
Path(__file__).with_name('results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(geometry),'exact local-exclusion geometries')
