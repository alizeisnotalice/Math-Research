#!/usr/bin/env python3
"""Bounded exact audit of nine halo contracts and three retained extreme rows."""
import os
for z in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[z]='1'
import argparse,sys,json,math,time,resource,hashlib,concurrent.futures
from fractions import Fraction as F
from pathlib import Path
sys.set_int_max_str_digits(100000)
def hash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def worker(rec):
 start=time.monotonic(); cpu=time.process_time();n=rec['n'];k=rec['k'];af=F(rec['a']);xs=list(map(F,rec['x']));Q=max([2*af.denominator]+[x.denominator for x in xs]);assert Q&(Q-1)==0
 a=int(af*Q);X=[int(x*Q) for x in xs];delta=F(1+k)/af**n;v=F(3,4)/delta;assert v>1
 cutoff=n*af/(4*(v-1)/(v+1));cut=math.ceil(cutoff*Q);Qpow=Q**n;ev=[]
 for group in (0,1):
  shift=group*a//2
  for axis,z in enumerate(X):
   q=(z-shift)//a;left=z-(q*a+shift);right=(q+1)*a+shift-z
   while left<=cut:ev.append((left,group,axis));left+=a
   while right<=cut:ev.append((right,group,axis));right+=a
 ev.sort();counts=[[0]*n for _ in range(2)];zero=[n,n];products=[1,1];i=0;best=[(0,1),(0,1)];wins=[None,None]
 while i<len(ev):
  left=ev[i][0]
  while i<len(ev) and ev[i][0]==left:
   _,g,j=ev[i];old=counts[g][j];counts[g][j]+=1
   if old==0:zero[g]-=1
   else:products[g]=products[g]//old*(old+1)
   i+=1
  right=ev[i][0] if i<len(ev) else cut
  if left>=right:continue
  N0=products[0] if zero[0]==0 else 0;N1=products[1] if zero[1]==0 else 0;m=N0+k*N1
  if not m:continue
  lp=(2*left)**n;norm=m*Qpow;cb=(norm>lp,4*norm>3*lp)
  if cb[1]:
   rp=(2*right)**n
   for z,good,num,den in ((0,cb[0],m,1),(1,cb[1],4*m,3)):
    if not good:continue
    if num*Qpow<=den*rp:nb,db=num,den
    else:nb,db=rp,Qpow
    b,d=best[z]
    if nb*d>b*db:best[z]=(nb,db);wins[z]=(left,right,N0,N1,m)
  if i%4096==0 and time.monotonic()-start>300:raise TimeoutError('budget exceeded; no partial proof')
 def display(pair):
  p,q=pair;return math.exp((math.log(p)-math.log(q))/n)/2 if p else 0.
 left,right,N0,N1,m=wins[1];saved=rec['saved_winner'];tauR=display(best[1]);
 return {'n':n,'k':k,'block':rec['block'],'index':rec['index'],'source_dominant':rec['source_dominant'],'event_count':len(ev),'safe_cutoff':str(cutoff),'E1':best[0][0]>0,'outer1_volume_num':str(best[0][0]),'outer1_volume_den':str(best[0][1]),'outertau_volume_num':str(best[1][0]),'outertau_volume_den':str(best[1][1]),'tau_winner':{'left':str(F(left,Q)),'next_event':str(F(right,Q)),'N0':str(N0),'N1':str(N1),'m':str(m),'weighted_identity':m==N0+k*N1},'saved_tau_winner':saved,'count_match':all(str(z)==saved[name] for name,z in [('N0',N0),('N1',N1),('m',m)]),'tau_radius_relative_error':abs(tauR/saved['right']-1),'wall_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--compact',type=Path,default=Path('/tmp/ccu_r630_importance_compact.json'));ap.add_argument('--periodic',type=Path,default=Path('/tmp/ccu_r630_periodic.json'));ap.add_argument('--output',type=Path,default=Path('/tmp/ccu_r630_exact_audit.json'));ap.add_argument('--workers',type=int,default=3);args=ap.parse_args();assert 1<=args.workers<=3;start=time.monotonic();d=json.loads(args.compact.read_text());p=json.loads(args.periodic.read_text());
 spacing={(b['n'],b['k']):F.from_float(b['spacing_binary64']) for b in p['blocks']};halos={};ha=[]
 for z in d['halo_contracts']:
  n,k=z['n'],z['k'];a=spacing[n,k];h=[]
  for q in z['halos']:
   hq=F(q['h_exact']);volume=(2*hq)**n; assert hq==F.from_float(q['h']) and volume==F(q['volume_exact']);h.append(hq)
   ha.append({'n':n,'k':k,'mass':q['mass'],'h_exact':str(hq),'a_exact':str(a),'strict_h_less_a_half':2*hq<a,'volume_le_mass':volume<=q['mass']})
  halos[n,k]=h
 assert len(ha)==18 and all(x['strict_h_less_a_half'] and x['volume_le_mass'] for x in ha)
 membership_diff=0;rho_error=0.;rho_gt2=0
 for item in d['selected_samples']:
  n,k=item['n'],item['k'];rec=item['record'];a=spacing[n,k];h=halos[n,k];x=list(map(F.from_float,rec['x']))
  membership=[all(abs((v-shift+a/2)%a-a/2)<h[idx] for v in x) for idx,shift in enumerate((F(0),a/2))]
  membership_diff+=int(membership!=[rec['in_halo0'],rec['in_halo1']]);den=F(1,2)+sum((F(1,4)*(a/(2*h[i]))**n if membership[i] else 0) for i in range(2));rho=1/den;rho_gt2+=int(rho>2);rho_error=max(rho_error,abs(float(rho)-rec['rho']))
 selections=[]
 for k in (1,64,4096):
  row=max((x for x in d['selected_samples'] if x['n']==512 and x['k']==k),key=lambda x:x['influence_score']);r=row['record'];dom=0 if r['pi0']>=r['pi1'] else 1
  selections.append({'n':512,'k':k,'block':row['block'],'index':r['index'],'source_dominant':dom,'influence_score':row['influence_score'],'a':str(spacing[512,k]),'x':list(map(lambda v:str(F.from_float(v)),r['x'])),'saved_winner':r['winner']})
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool: results=list(pool.map(worker,selections))
 parent_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 result={'compact_sha256':hash(args.compact),'periodic_sha256':hash(args.periodic),'script_sha256':hash(Path(__file__)),'halo_checks':ha,'retained_selected_samples_checked':len(d['selected_samples']),'membership_mismatches':membership_diff,'max_rho_abs_error_float':rho_error,'rho_over_two_count':rho_gt2,'proposal_formula':'q=1/2 + I0*(1/4)*(a/(2h0))^n + I1*(1/4)*(a/(2h1))^n; rho=1/q; overlaps add','selection_scope':'maximum influence among compact retained samples; full raw global extremality not independently established','selected_inputs':selections,'results':results,'workers':args.workers,'wall_seconds':time.monotonic()-start,'parent_peak_rss_bytes':parent_peak,'sum_worker_peaks_bytes':sum(r['peak_rss_bytes'] for r in results),'python':sys.version}
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2));
 with args.output.with_suffix('.md').open('w') as f:
  f.write('# R630 双源 halo 与选点精确审计\n\n九组 18 个 halo 使用 binary64 a/h 的精确有理值检查；所有 h<a/2、(2h)^n≤各自质量。每类周期 halo 自身无重叠，但两类 halo 可以重叠：相对于均匀胞概率的 proposal 密度 q=1/2+(1/4)I0(a/(2h0))^n+(1/4)I1(a/(2h1))^n，指标可同时为1，故两项相加，严格有 ρ=1/q≤2。逐条检验 compact 72 条保留样本的指标和权重，仅覆盖保留数据。\n\n')
  f.write('| n | k | block / index | 主导类 | E1 | winner N0/N1/m 匹配 | rτ 相对显示差 | 事件 | CPU秒 | RSS MiB |\n|---:|---:|---|---:|---|---|---:|---:|---:|---:|\n')
  for z in results:f.write(f"| {z['n']} | {z['k']} | {z['block']} / {z['index']} | {z['source_dominant']} | {z['E1']} | {z['count_match']} | {z['tau_radius_relative_error']:.3g} | {z['event_count']} | {z['cpu_seconds']:.2f} | {z['peak_rss_bytes']/2**20:.1f} |\n")
  f.write(f"\n72条保留样本 halo membership 不符 {membership_diff} 条，ρ>2 共 {rho_gt2} 条，精确公式与已保存浮点ρ最大绝对差 {rho_error:.3g}。三点选择是 compact 保留候选中 τρ·max(π0,π1)/δ 最大者，未单凭 compact 确认 raw 全体极值。全部尺度严格逐事件枚举，winner 的 N0、N1、m=N0+kN1 与两个阈值的精确体积保存在 JSON。\n\n")
  f.write(f"三 worker，墙时 {result['wall_seconds']:.2f} 秒；父进程峰值 {parent_peak/2**20:.1f} MiB，各 worker 峰值之和 {result['sum_worker_peaks_bytes']/2**20:.1f} MiB（各自峰值的保守和，不是同时测得的总峰值）。只检查 binary64 数据，不认证原无理间距或一般模型，也不重跑 Monte Carlo。\n")
 print([(r['k'],r['block'],r['index'],r['E1'],r['count_match'],r['tau_radius_relative_error'],r['event_count']) for r in results],flush=True)
if __name__=='__main__':main()
