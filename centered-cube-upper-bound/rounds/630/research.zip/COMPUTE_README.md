# R630 compact computation archive

Two standalone entry points in this directory: `ccu_r630_periodic.py` reproduces the original uniform pilot design, while `ccu_r630_importance.py` reproduces the independent halo-mixture sample design. Both use a sibling import and relative default output; the importance job bounds pending futures by four times worker slots, writes JSON as a stream, stores each halo contract once, and retains coordinates only for eight high-impact samples per case. No full run of the modified code has been made.

Commands for small checks (run from this directory):

```
python ccu_r630_importance.py --case 32,64 --blocks 2 --workers 2 --output check.json
python check_summary.py
```

`historical_compact.json` retains original 72 audit points, summaries, metadata, per-block seeds, and resources. `historical_scalars.json` holds all 9,216 proposal weights, E statuses and source fractions. Their summaries and all five tail plug-ins were recomputed successfully; maximum numerical discrepancy 2.67e-15. `receipt.json` records the original raw result SHA, changed script SHAs and the two-block parity result. Historical execution commands were:

- `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r630_importance.py --phase pilot --workers 14`
- `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r630_importance.py --phase full --workers 14`

Original run resource correction: parent RSS approximately 2.14 GiB, observed parent plus workers approximately 2.66 GiB; this exceeded the 1.5 GiB target. Total peak was not measured. The small portable test does not establish memory consumption for the complete job. CPU system readings include other tasks. Binary64 spacing and sampling errors preclude rigorous general conclusions.


Root unit correction: macOS ps RSS is KiB. The recorded 2,144,112 KiB parent is 2.0448 GiB; adding the 14 contemporaneous worker RSS values gives 2.5633 GiB (approximately). Earlier prose 2.14/2.66 GiB is superseded by RESOURCE_CORRECTION.json. This was one observation, not a measured peak; it still exceeded the 1.5 GiB target.
