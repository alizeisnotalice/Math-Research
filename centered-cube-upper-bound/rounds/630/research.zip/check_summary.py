import json, math
from pathlib import Path
import numpy as np
p=Path(__file__).parent
rows=json.loads((p/'historical_scalars.json').read_text())['records']
hist=json.loads((p/'historical_compact.json').read_text())['summaries']
maximum=0.
for s in hist:
 n,k,N=s['n'],s['k'],s['N'];rr=[r for r in rows if r[0]==n and r[1]==k];assert len(rr)==N
 rho=np.array([r[4] for r in rr]); E=np.array([r[5] for r in rr]); p0=np.array([r[6] for r in rr]);p1=np.array([r[7] for r in rr]); f=(1+k)*.75*n
 v0=f*rho*p0;v1=f*rho*p1/k
 for key,v in [('S0',v0.mean()),('S1',v1.mean()),('S0_SE',v0.std(ddof=1)/math.sqrt(N)),('S1_SE',v1.std(ddof=1)/math.sqrt(N)),('W',n*(rho*E).mean())]:
  diff=abs(s[key]-v);maximum=max(maximum,diff);assert diff<1e-10*max(1,abs(v)),(n,k,key,diff)
 for t in s['tail']:
  L=t['L'];got=(max(v0.mean()-L,0)+k*max(v1.mean()-L,0))/(1+k);assert abs(got-t['plugin'])<1e-10*max(1,abs(got))
print('all nine summaries and five tail plug-ins verified; max absolute difference',maximum)
