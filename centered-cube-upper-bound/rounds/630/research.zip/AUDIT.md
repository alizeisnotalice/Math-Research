# R630 第二阶段独立审计

2026-10-28。先独立核两组命题，再读`/tmp/ccu_r630_transport.md`与最终`/tmp/ccu_r630_radius_geometry.md`。未扫描或启动Agent；本机SymPy只作小型block determinant代数核验，不代替面积公式证明。周期采样数据不在此次审查范围。

## 1. 共同CZ扩散及运输误差：通过

cyclic二分的固定nested矩形网格每个父cell体积为子cell的2倍，aspect≤2且微分L1。最大bad cells可数不交，H<h̄_C≤2H；按cell均匀替换后g≤2H、∫g=M_h正确。这里均匀参照的坐标独立不属于原h。

R始终冻结为同一原f的outer半径。删去开扩大cells得到compact F0；以h≤f及outer等号计算完整tail差，确为≤τeM_h/H，不能只支付receiver删除体积。Var_C为Lebesgue均匀方差时，

Σ_C M_C Var_C S_F0≤2H||S_F0||²₂≤2H B_{2,n}²|F0|。

协方差展开保留全部source/receiver交叉项。对Φ=(S−L)_+，variance contraction及Cauchy给误差≤B_{2,n}sqrt(2H|F0|Ξ_H)，其中Ξ_H=ΣM_C avg_C(h/h̄_C−1)²不可省略、可为∞。作者(6)和Young余项HB_{2,n}²Ξ_H/(2δ)系数正确；不要求f∈L²，原完整tail有限由∫fS_F=τ|F|保证。没有一般Ξ_H≲M，故未得到全L1运输误差或root闭合。

## 2. Anchored质量时钟：直接L1有效

固定y、interior u，L1来源的A(v)绝对连续、A(0)=0、A'≥0。strict Gτ的每个开区间两端满足A=τv，含左端0的极限；逐区间积分再非负求和，得到∫_Gτ A'dv=τBτ。此式不能直接用于原子来源的classical derivative。

τ<c<1时，A'≤c的子菜单体积≥(1−τ/c)Bτ。重新按实际子菜单体积归一后的核有一次source预算，且原Cτ逐点支配(1−τ/c)倍子核；τ=3/4、c=7/8为1/7。不重归一而直接mask时，只能说全receiver总信用损失≤(τ/c)M，不能将它当outer-level contact trace的免费删除。

## 3. 联合contact公式：smooth范围的修复通过

认证范围为f∈C_c∞、f≥0、compact K⊂E1及固定I=[b0,b1]⊂(τ,1)。对固定u，用真正联合映射

Ψ_u(y,v)=(x=y−r(v)u, β=m(x,r(v))/v)，
det DΨ_u=(a0−β)/v。

Schur补精确消去中心漂移。selected域要求x∈K、β∈I、a0<β及全部future upper；它可测，且这些条件使r恰为唯一outer strict β-bad半径。故Ψ在selected域一对一。K及I给r统一正/上界，可在compact patches上用forward area formula。

固定x的一维Sard再Fubini排除的是receiver×level中的critical值a0=β，而不是声称其source像小。这个joint-map版本不先除单β Jacobian J，不删除a_u=β，也不要求Rβ全局Lipschitz、单方向injective或有限分支数；因而修复了初始按a.e.β忽略奇异pushforward的风险。

乘真实f(y)后再平均uniform u，像端平均恰为β，得作者exact identity H_I|K|，contact measure为(β−a0)dv/v。Bτ/v≤L部分的v属于Gτ，且0<β−a0≤b1，因此其总费用≤b1LM。除以H_I=∫_Iβdβ后的量是**β平均、source条件的fractional receiver贡献**；不是存在light contact的receiver集合体积，也不是每个β各自的同一结论。

## 4. 最终范围与未付位置

稿件只将质量时钟及子核归约直接推广L1，未将smooth contact身份自动扩成一般L1，范围正确。将来若获得对所有smooth输入统一的完整weaktype界，可由strict fixed-radius witness稳定和Fatou恢复L1；这不等于已证明原Cτ积分lower随近似收敛，strict平台、Bτ归一及contact measure仍需相应稳定性。

**关键公式均通过，无决定性错误；没有一般根阶改善。** 运输线仍缺真实h位置与receiver振荡的联合收费，不能以Ξ_H≲M补空；半径线仍缺heavy contact trace的严格吸收，不能用dv/Bτ时钟替代其dv/v费用。两者均未支付完整receiver目标或R559母账。审查完成，停止。

**最终数值解释补注。** k=1、两halo相同且proposal为.5U+.25H₀+.25H₁时，半对角平移交换cosets并保持μ、q、ρ、E及Rτ，故真实S₀=S₁；每个样本与平移配对后两列均为τa_binary^n·mean(ρ1_E)/2（名义a^n=2n时为τn·mean(ρ1_E)）。iid条件下SE用原N个Y=ρ1_E的样本方差，不能把相关配对当2N独立样本。令α=a_binary^n/[(1+k)n]，仅按名义体积作线性prefactor归一的S、原始W及其SE须乘α；前提是ρ已按实际cell及实际proposal计算，若ρ本身用了错误名义体积，则单乘α不足以修复。非线性尾须在对称化及α校正后重算，不能直接缩放旧tail；旧表应标名义化。n512旧列差异不作真实source不对称解释，新统计也不增加事件/积分证书范围。本补注只核两步逻辑，未运行或重判样本。
