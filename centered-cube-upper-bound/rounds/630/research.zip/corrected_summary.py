"""No new sampling: normalize actual binary64 cell volume; enforce k=1 symmetry."""
from pathlib import Path
from fractions import Fraction as F
import json, math
import numpy as np
p=Path(__file__).parent
d=json.loads((p/'historical_scalars.json').read_text())
out=[]
for n in (32,128,512):
    for k in (1,64,4096):
        a=((1+k)*n)**(1/n);alpha=F(a)**n/F((1+k)*n)
        assert abs(alpha-1)<F(1,10**12)
        rows=[r for r in d['records'] if r[:2]==[n,k]]
        z=np.array([[r[4]*r[5],r[4]*r[6],r[4]*r[7]] for r in rows])
        assert np.max(np.abs(z[:,1]+z[:,2]-z[:,0]))<1e-14
        fac=.75*n*float(alpha)
        if k==1:
            vals=np.column_stack([fac*z[:,0],fac*z[:,0]])
        else:
            vals=np.column_stack([(1+k)*fac*z[:,1],(1+k)*fac*z[:,2]/k])
        means=vals.mean(axis=0);se=vals.std(axis=0,ddof=1)/math.sqrt(len(rows))
        levels=[1.,2.,4.,math.sqrt(n),math.sqrt(n)*math.log(n+2)]
        tails=[{'L':L,'plugin':(max(means[0]-L,0)+k*max(means[1]-L,0))/(1+k)} for L in levels]
        out.append({'n':n,'k':k,'N':len(rows),'alpha_binary_normalization':float(alpha),
            'equal_mass_symmetry_used':k==1,'S0':means[0],'S1':means[1],
            'SE0':se[0],'SE1':se[1],'W':n*float(alpha)*z[:,0].mean(),
            'tails':tails})
(p/'corrected_summary.json').write_text(json.dumps({'scope':'Postprocessing of saved samples. k=1 half-cell translation is an exact model symmetry; error bars remain descriptive and tails are nonlinear plug-ins. No new samples or general proof.','results':out},indent=2))
for r in out:
    if r['k']==1:print(r['n'],r['S0'],r['SE0'])
