import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import argparse,concurrent.futures,ctypes,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import ccu_r630_periodic as base
sys.set_int_max_str_digits(0)

def halos(n,k,a):
 out=[]
 for mass in (1,k):
  h=np.nextafter(.5*math.exp(math.log(mass)/n),0.)
  while (2*F(float(h)))**n>mass or not 2*F(float(h))<F(float(a)):h=np.nextafter(h,0.)
  v=(2*F(float(h)))**n;out.append({'mass':mass,'h':float(h),'h_exact':str(F(float(h))),'volume_exact':str(v),'volume_float':float(v),'Vcell_over_Vhalo':math.exp(n*math.log(a/(2*h)))})
 return out

def block(spec):
 n,k,b=spec;t=time.monotonic();cpu=time.process_time();delta,a,cut=base.params(n,k);hh=halos(n,k,a);seed=630100000+n*100000+k*300+b;rng=np.random.default_rng(seed);records=[]
 for ii in range(4):
  draw=rng.random(n+1);component=0 if draw[0]<.5 else 1 if draw[0]<.75 else 2
  if component==0:x=(draw[1:]-.5)*a
  else:
   h=hh[component-1]['h'];shift=0. if component==1 else a/2;x=((shift+(2*draw[1:]-1)*h+a/2)%a)-a/2
  d0=np.abs((x+a/2)%a-a/2);d1=np.abs((x-a/2+a/2)%a-a/2);I0=bool(np.all(d0<hh[0]['h']));I1=bool(np.all(d1<hh[1]['h']));den=.5+.25*hh[0]['Vcell_over_Vhalo']*I0+.25*hh[1]['Vcell_over_Vhalo']*I1;rho=1/den;assert 0<rho<=2+1e-12
  r=base.scan(x,k,a,cut);rec={'index':4*b+ii,'component':component,'in_halo0':I0,'in_halo1':I1,'rho':rho,'status':r['status'],'events':r['events']}
  if r['status']=='E1':rec.update({'N0_over_m':r['N0_over_m'],'N1_over_m':r['N1_over_m'],'pi0':r['pi0'],'pi1':r['pi1'],'winner':r['winner'],'x':x.tolist()})
  records.append(rec)
 return {'n':n,'k':k,'block':b,'N':4,'seed':seed,'halo_contracts':hh,'records':records,'cpu_seconds':time.process_time()-cpu,'elapsed_seconds':time.monotonic()-t,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');v=(ctypes.c_uint32*4)();cnt=ctypes.c_uint32(4);return list(v) if lib.host_statistics(lib.mach_host_self(),3,v,ctypes.byref(cnt))==0 else None

def summary(out):
 final=[]
 for n in (32,128,512):
  for k in (1,64,4096):
   blocks=[b for b in out['blocks'] if b['n']==n and b['k']==k];rows=[r for b in blocks for r in b['records']];N=len(rows)
   if not N:continue
   r=np.array([z['rho'] for z in rows]);isE=np.array([z['status']=='E1' for z in rows]);a=np.array([z.get('N0_over_m',0.) for z in rows])*r;b=np.array([z.get('N1_over_m',0.) for z in rows])*r;em=r*isE;fac=(1+k)*.75*n;s0=fac*float(a.mean());s1=fac*float(b.mean());se0=fac*float(a.std(ddof=1))/math.sqrt(N) if N>1 else 0.;se1=fac*float(b.std(ddof=1))/math.sqrt(N) if N>1 else 0.;W=n*float(em.mean());weighted=(s0+k*s1)/(1+k);target=.75*W;assert abs(weighted-target)<=1e-9*max(1,target)
   tails=[]
   for L in (1.,2.,4.,math.sqrt(n),math.sqrt(n)*math.log(n+2)):
    calc=lambda x,y:(max(x-L,0)+k*max(y-L,0))/(1+k);tails.append({'L':L,'plugin':calc(s0,s1),'descriptive_2SE_range':[calc(s0-2*se0,s1-2*se1),calc(s0+2*se0,s1+2*se1)]})
   final.append({'n':n,'k':k,'N':N,'E1_hits':int(isE.sum()),'proposal_components':[sum(z['component']==i for z in rows) for i in range(3)],'halo_overlap_hits':sum(z['in_halo0'] and z['in_halo1'] for z in rows),'rho_max':float(r.max()),'rho_ESS':float(r.sum()**2/(r@r)),'weighted_E_ESS':float(em.sum()**2/(em@em)) if em@em else 0.,'W':W,'S0':s0,'S1':s1,'S0_SE':se0,'S1_SE':se1,'weighted_mean':weighted,'identity_target':target,'identity_residual':weighted-target,'tail':tails})
 return final

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',default=None);ap.add_argument('--blocks',type=int,default=256);ap.add_argument('--workers',type=int,default=14);ap.add_argument('--output',type=Path,default=Path(__file__).with_name('importance_replay.json'));a=ap.parse_args()
 assert 1<=a.workers<=14 and 1<=a.blocks<=256
 cases=[tuple(map(int,a.case.split(',')))] if a.case else [(n,k) for n in (32,128,512) for k in (1,64,4096)]
 todo=iter((n,k,b) for n,k in cases for b in range(a.blocks)); pending={}; results=[]; contracts={}; retained={}; start=time.monotonic(); cpus=0.; maxrss=0
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  def fill():
   while len(pending)<4*a.workers:
    try:q=next(todo)
    except StopIteration:break
    pending[pool.submit(block,q)]=q
  fill()
  while pending:
   done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    pending.pop(f); z=f.result();key=f"{z['n']},{z['k']}";contracts.setdefault(key,z.pop('halo_contracts'));cpus+=z['cpu_seconds'];maxrss=max(maxrss,z['peak_rss_bytes_macos']);results.append(z)
    keep=retained.setdefault(key,[])
    for row in z['records']:
     if 'x' in row:
      keep.append((row['rho']*max(row['pi0'],row['pi1']),row['index'],row));keep.sort(key=lambda t:(-t[0],t[1]))
      if len(keep)>8:keep.pop()[2].pop('x',None)
   fill()
 results.sort(key=lambda z:(z['n'],z['k'],z['block']))
 out={'blocks':results,'halo_contracts':contracts,'summaries':summary({'blocks':results}),'resources':{'wall_seconds':time.monotonic()-start,'worker_cpu_seconds':cpus,'worker_max_rss_bytes_macos':maxrss,'parent_max_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'workers':a.workers,'pending_limit':4*a.workers},'command':shlex.join([sys.executable]+sys.argv)}
 with a.output.open('w') as f:json.dump(out,f)
if __name__=='__main__':main()
