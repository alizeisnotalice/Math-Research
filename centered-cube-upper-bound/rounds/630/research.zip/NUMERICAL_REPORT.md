# R630 halo-mixture importance diagnostics

Each proposal is 1/2 uniform cell plus 1/4 from each strict single-atom halo, with overlap densities added. Every sample is weighted by the full mixture density. The two cosets are globally coupled and counts are added with masses 1 and k. Finite pilot/full estimates, tail plug-ins and 2SE propagation are descriptive, not certified confidence intervals.

| n | k | N | E1 hits | max ρ | weighted E ESS | S0 | S1 | weighted mean | τW | tail L=1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 32 | 1 | 1024 | 517 | 2 | 61.3331 | 1.0511388 | 1.3239049 | 1.1875219 | 1.1875219 | 0.18752185 |
| 32 | 64 | 1024 | 547 | 2 | 65.1608 | 0.01521771 | 1.5837142 | 1.5595835 | 1.5595835 | 0.57473399 |
| 32 | 4096 | 1024 | 517 | 2 | 60.6991 | 0.028415309 | 1.5472365 | 1.5468657 | 1.5468657 | 0.54710289 |
| 128 | 1 | 1024 | 517 | 2 | 15.9765 | 1.9120601 | 1.4498642 | 1.6809621 | 1.6809621 | 0.68096213 |
| 128 | 64 | 1024 | 518 | 2 | 18.9102 | 0.13066071 | 2.6240285 | 2.585669 | 2.585669 | 1.5990435 |
| 128 | 4096 | 1024 | 544 | 2 | 22.0075 | 0.0035250655 | 3.1796391 | 3.1788639 | 3.1788639 | 2.1791071 |
| 512 | 1 | 1024 | 553 | 2 | 4.30085 | 2.3424595 | 0.77157562 | 1.5570175 | 1.5570175 | 0.67122974 |
| 512 | 64 | 1024 | 530 | 2 | 7.18741 | 0.39555966 | 4.561852 | 4.4977552 | 4.4977552 | 3.5070542 |
| 512 | 4096 | 1024 | 530 | 2 | 11.0375 | 0.001264994 | 7.4784966 | 7.4766715 | 7.4766715 | 6.4769153 |

All five plug-in tails and descriptive propagated 2SE ranges are in JSON. A retained 1/2 uniform component covers configurations outside both single-atom halos, but finite sampling cannot prove that their contribution vanishes.

Resource correction: root observed parent RSS about 2.14 GiB and 14 workers about 38 MiB each, approximately 2.66 GiB in total, exceeding the 1.5 GiB target. This is a point observation, not a measured total peak. Root observed workers near 97–99% CPU and system CPU 96.05% and 93.50%; host CPU includes unrelated tasks. Parent memory cause was not profiled: queued tasks and retained records/checkpoint serialization are possible contributors. A future runner should bound submission and retain compact incremental records.

The mixture normalizes by its component weights; overlapping halo densities are added. Every halo-origin sample was E1, every component membership check passed, max rho was 2, and the largest floating identity residual was 8.89e-16. Uniform outside-halo coverage remains sparse, and high-dimensional standard errors are substantial. The float spacing approximates the ideal irrational spacing; no rigorous numerical or sampling certificate is claimed.

Raw JSON has SHA-256 a606ff23966bf725fa2a65b508a94dd38b0a7ab201ad2c428fe1373450c549bd; the derived compact receipt is ccu_r630_importance_compact.json and compressed raw is ccu_r630_importance_raw.json.gz. The compact file is not the original run output.


Root unit correction: macOS ps RSS is KiB. The recorded 2,144,112 KiB parent is 2.0448 GiB; adding the 14 contemporaneous worker RSS values gives 2.5633 GiB (approximately). Earlier prose 2.14/2.66 GiB is superseded by RESOURCE_CORRECTION.json. This was one observation, not a measured peak; it still exceeded the 1.5 GiB target.
