# R630：all-shell质量时钟与outer-level联合映射

**已证。** 完整strict bad-set有真实质量时钟，可将occupation常数因子地归约到anchored增长<1的子核；进一步用(n+1)维联合映射，准确处理所有outer支路、jump与固定方向fold，无需假定outer radius Lipschitz或单方向映射injective。非heavy部分只付一次M。**未证。** heavy trace的统一收缩，故尚无一般根阶界。

## 1. 实际all-shell时钟及常数因子子核

固定μ=f dx≥0、source y、interior u，令

`v=(2r)^n`，`A(v)=μQ(y−ru,r)`，`Gτ={A(v)>τv}`，`Bτ=|Gτ|`。

L1来源的anchored A在v上绝对连续、A(0)=0、A'≥0。Gτ开且在(0,M/τ)内；每个连通interval(a,b)端点均满足A=τv，包括a=0。对全部可数components求和，精确得到

`∫_{Gτ}A'(v)dv=τBτ`。                              (1)

这是真实来源质量增长，不是体积代替source质量。若τ<c<1，

`B_{τ,c}:=|{v∈Gτ:A'<=c}|>=(1−τ/c)Bτ`。

以该子菜单及B_{τ,c}归一得到辅助C_{τ,c}，仍source预算≤M，而原完整核逐点支配

`Cτ>=(1−τ/c)C_{τ,c}`。                              (2)

τ=3/4、c=7/8仅损1/7。若只mask、不重新归一，所丢总信用≤(τ/c)M。此结论对L1直接成立；它不授权按volume-flow的损失去删除outer graph的level-contact trace。

## 2. 联合映射消掉单β/单方向的多重性障碍

先取f∈C_c∞及compact K⊂E1，固定`I=[b0,b1]⊂(τ,1)`。令`m(x,r)=μQ(x,r)`、`V=(2r)^n`，并写

`a0=m_r/V'`，`a_u=(m_r−u·m_x)/V'`。

固定u，考虑真正联合映射

`Ψ_u(y,v)=(x=y−r(v)u, β=m(x,r(v))/v)`。

其Jacobian块为

`[ I       −u/V' ;  m_x^T/v       (a_u−β)/v ]`，

Schur补精确消去中心漂移项：

`det DΨ_u=(a0−β)/v`。                              (3)

定义selected集合T_u：x∈K、β∈I、a0<β，并对全部s>r满足

`μQ(x,s)<=βV(s)`。                                  (4)

条件可用有理s表出，故可测。a0<β保证r下方立即strict β-bad，(4)保证r后没有strict bad，因此r恰为真实outerβ半径。同一(x,β)只能有一个selected r，故Ψ_u在T_u上全局one-to-one。

**不需要排除a_u=β。** 即使固定β的`x↦x+Rβ(x)u`有fold或多支路，联合映射(3)在a0<β上仍非奇异；不能将这些fold先删掉，也不需另给其次数收费。

对固定x，r↦m(x,r)/V(r)的critical values满足a0=β，一维Sard后再(x,β)-Fubini，表明它们在K×I中零测。K⊂E1及I⊂(τ,1)给selected r统一正下界和有限上界，所以可用compact patches上的C1/Lipschitz area formula。此处排除的是receiver×level积分中的critical值，不声称其source image质量小，也不假设f面密度有帽。

## 3. 全receiver trace与一次source light费用

将area formula乘真实f(y)，再对uniform u平均。像端有

`E_u f(x+Rβ(x)u)=μQ(x,Rβ)/V(Rβ)=β`。

因此准确得到

`H_I |K|=∫dμ(y) E_u ∫_{T_u(y)}[β(y,u,v)−a0]/v dv`，
`H_I=∫_I βdβ=(b1²−b0²)/2`。                       (5)

所有支路均已由联合selected集合保留；没有无权出口数、单β的1/J或额外angular独立来源假设。

按`Bτ(y,u)/v<=L`分割(5)。因β≥b0>τ，每个contact v属于原完整Gτ，且`0<β−a0<=b1`，所以light部分严格满足

`∫dμ E_u∫_{T_u, Bτ/v<=L}(β−a0)dv/v <=b1 L M`。     (6)

这是一份共同source预算，不对每receiver、level或出口重领M。定义T_L为(5)中`Bτ/v>L`部分除以H_I，便有

`|K|<= (b1/H_I)L M+T_L`。                           (7)

这里light/heavy是β平均、source条件的**fractional receiver贡献**；不等于存在一个light contact的receiver集合体积，也没有逐β的同样结论。

取compact exhaustion K↑E1可按非负monotone convergence给完整receiver版本，不增加尺度费用。若最终能证`T_L<=θ|E1|+A_nM`且θ<1，(7)才会闭合；本稿未证该项。

## 4. 时钟与出口窗口不能代替heavy trace付款

(1)控制`dv/Bτ`与`A'dv/Bτ`，而(5)的trace为`(β−a0)dv/v`。在heavy区域Bτ/v大，不能反向用source总预算。式(2)的low-growth flow也不是对receiver×level trace的免费删选。

每个anchored β contact v_i确有forward窗口`[v_i,(β/τ)v_i)⊂Gτ`。对disjoint窗口只能推出

`Σ_i v_i<=Bτ/(β/τ−1)`；

窗口重叠时须计union/fresh length，不能逐出口加账。固定level的一般bad-set可以有可数components，当前合同没有uniform次数界；联合映射已避免单独支付出口数，但未因此控制heavy的dv/v权。窗口内中心随r移动，只保证τ-bad，亦不能直接当E1信用。

## 5. 全尺度/一般L1范围与停止

时钟(1)–(2)对L1直接有效。联合映射段在smooth compact输入上借level平均合法处理critical radial values；无需Rβ全局Lipschitz、有限全局支路数或a_u≠β。若未来取得uniform完整weak-type估计，可由L1近似、每个strict fixed-radius witness稳定性及Fatou转回一般输入；但原Cτ积分下界的极限还须处理strict τ平台对Bτ的影响，不能自动声称核收敛。

目前没有heavy trace的θ<1收缩，也没有新根阶界。已完成的是实际all-shell时钟、常数因子low-growth核归约、联合映射的exact全支路账及(6)的一次M费用。

本机SymPy核验了时钟端点代数、1/7系数及联合block determinant(3)。独审另核了one-to-one selected mask和critical-value处理。无扫描、agent、Astra或仓库修改。完成停止。
