# 第630轮复现与证据边界

先读 REPORT.tex、AUDIT.md。CONTACT_AUTHOR.md、TRANSPORT_AUTHOR.md 保留原审计对应文字；只有质量时钟直接覆盖一般L1，联合contact公式认证范围为光滑紧支撑输入和完整level平均。两个未付项没有被免费互相替换。

解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。版本、原运行命令、随机种子与原结果SHA在 historical_compact.json、receipt.json 中。可在解压目录执行：

```sh
python check_summary.py
python corrected_summary.py
python root_checks.py
python ccu_r630_importance.py --case 32,64 --blocks 2 --workers 2 --output check_again.json
python exact_audit.py --compact historical_compact.json --periodic periodic_parameters.json --output exact_again.json --workers 3
```

最后一条会重做三点高维整数扫描，历史已完成；没有为了拉高CPU占用再次执行。前四类检查实际已运行，其中两块数学字段、坐标和winner与历史一致。新版有界队列没有重跑完整9216点，不能据此认证整批内存峰值。COMPUTE_README.md说明并行入口及原批次。

historical_scalars.json 保存9216条小标量，可独立重算汇总；historical_compact.json只额外保留72个审计候选坐标和完整参数。periodic_parameters.json 从原均匀pilot提取九组实际格距，不含其可重建全输出。原约56MB主输出、重复全量坐标、缓存没有提交。exact_audit.json对应原三点核验及18个halo/72个proposal成员核验；portable输入只精简了不被核验程序使用的字段。

原浮点汇总采用名义体积(1+k)n。corrected_summary.py按实际binary64体积校正线性量，并对k=1利用严格半胞平移对称性；非线性尾在校正后重算。SE使用原样本数，不把成对对称样本当作新增独立样本。所有MC尾仍是plug-in，不是严格上下界。root_checks.py只认证九组体积误差/解析cutoff及有限符号检查，不认证所有浮点平台或采样误差。

RESOURCE_CORRECTION.json更正了macOS ps的KiB→GiB换算：当时父进程2.0448GiB、父与14工人合计2.5633GiB，是一次同时观测而非峰值，超过1.5GiB计划。原文字约2.14/2.66GiB的近似数保留在历史收据时，以本更正为准。宿主CPU约94–96%包括其他任务；未声称持续全程满载。

本轮调用Python、NumPy、SymPy、python-flint/Arb；没有调用MATLAB、没有编译PDF。技能D01只用于明确显式正耦合与成本方向，不以高级OT强对偶替代本题估计。
