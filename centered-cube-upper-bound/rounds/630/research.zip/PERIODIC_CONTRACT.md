# R630 周期column合同独立审计

2026-10-28。仅核所给对象；未读作者结论、未采样。令F为半开基本胞、|F|=a^n，y₀=0、y₁=(a/2)1，两cosets的单atom质量为1、k，δ=(1+k)/a^n<τ=3/4。

**公式成立。** 平移协变及非负Tonelli给（N_j是不带质量k的coset点数）

S_j=∫_(R^n)1_E(x)1{|x−y_j|∞<Rτ(x)}/V(Rτ(x))dx
   =∫_F1_E N_j/V dx=a^n E_F[1_E N_j/V]。

无额外δ或k；k仅在合成来源时相乘。计数界m/V≤δexp[na/(2r)]给全部τ-bad半径r<na/[2log(τ/δ)]。在E上outer半径正且有限；finite-entry平台中最后strict bad段不能在正质量entry处终止，否则count增加使右侧仍bad。因此末端确有m=N₀+kN₁=τV，且无atom在outer边界。原点本身也无奇异，m≥1；E外各比值按0延拓。遂

S_j=(1+k)τ/δ ·E_F[1_E N_j/m]，
(S₀+kS₁)/(1+k)=τP_F(E)/δ。

本机SymPy只复核最后加权代数，未认证事件。基本胞边界为receiver零测集；source代表采用半开胞，不重复计原点。

**可付款importance proposal。** 取单atom inner halos H_j在torus上的投影，半径h_j<a/2、V_j=(2h_j)^n≤质量_j，则H_j⊂E。可选dyadic h_j使体积精确可算。以概率p_U,p₀,p₁混合cell uniform及两halo uniform，例如(1/2,1/4,1/4)，其密度准确为

q(x)=p_U/a^n+p₀1_H₀/V₀+p₁1_H₁/V₁。

重叠处相加；ρ(x)=1/(a^nq(x))≤1/p_U。用E_q[ρ1_E]及E_q[ρ1_E N_j/m]分别估P_F(E)和上述column期望。必须p_U>0保留multiatom witness补集E\(H₀∪H₁)，不能假定halos覆盖E。importance权变量一般非Bernoulli，应使用相应bounded/分层统计，不能机械沿用binary端点。

**范围。** 周期μ不是finite L1；平滑/截断转移须另证outer末平台及columns稳定，R626的occupation-DCT不能自动替代。δ=1/n时平凡周期weakratio上限为n，改变固定8的容易门槛，不认证一般定理。MC估计的是同一周期全E的S_j；零/少命中、浮点outer/count事件及有限统计都不是严格重列尾证书，也不检验全部compact receiver families的吸收。未把该outer column当成R626的归一化occupation核。合同通过，停止。
