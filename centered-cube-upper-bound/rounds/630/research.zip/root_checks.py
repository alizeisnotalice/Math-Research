"""R630 bounded algebra and nine saved-spacing checks; not a weak-type proof."""
from fractions import Fraction as F
from pathlib import Path
import json, math, sys
import sympy as s
from flint import arb, ctx
sys.set_int_max_str_digits(100000)
ctx.prec=192
out={'python':sys.version,'sympy':s.__version__,'arb_bits':ctx.prec,'determinants':[],'spacing':[]}
v,Vp,a0,beta=s.symbols('v Vp a0 beta', nonzero=True)
for n in (1,2,3,7):
    u=s.symbols('u:'+str(n)); g=s.symbols('g:'+str(n))
    au=a0-sum(u[i]*g[i] for i in range(n))/Vp
    mat=s.eye(n+1)
    for i in range(n):mat[i,n]=-u[i]/Vp;mat[n,i]=g[i]/v
    mat[n,n]=(au-beta)/v
    assert s.cancel(mat.det()-(a0-beta)/v)==0
    out['determinants'].append({'n':n,'identity':True})
assert 1-F(3,4)/F(7,8)==F(1,7)
def interval(q):return arb(q.numerator)/arb(q.denominator)
for n in (32,128,512):
    for k in (1,64,4096):
        a=((1+k)*n)**(1/n);aq=F(a);alpha=aq**n/F((1+k)*n)
        assert abs(alpha-1)<F(1,10**12)
        cut=n*a/(2*math.log(.75*n))*1.00000000001
        delta=F(1+k)/aq**n
        exact_threshold=arb(n)*interval(aq)/(2*interval(F(3,4)/delta).log())
        margin=interval(F(cut))-exact_threshold
        assert margin>0
        out['spacing'].append({'n':n,'k':k,'a_hex':a.hex(),
           'binary_volume_over_nominal':float(alpha),'exact_relative_error_lt_1e12_inverse':True,
           'cutoff_margin':str(margin),'positive_margin':True})
out['scope']='Finite symbolic checks support the stated general Schur-complement proof; nine rational/Arb checks certify only normalization error and analytic cutoffs, not floating platforms, sampling error, or weak-type estimates.'
Path(__file__).with_name('root_checks.json').write_text(json.dumps(out,indent=2))
print('4 symbolic determinants; 9 exact normalization and Arb cutoff checks passed')
