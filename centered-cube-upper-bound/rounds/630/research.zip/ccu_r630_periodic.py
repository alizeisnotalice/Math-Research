import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import argparse,concurrent.futures,ctypes,hashlib,heapq,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np
TAU=.75

def params(n,k):
 delta=1/n;a=((1+k)*n)**(1/n);cut=n*a/(2*math.log(TAU/delta))*1.00000000001;return delta,a,cut

def scan(x,k,a,cut):
 n=len(x);heap=[];counts=[[0]*n for _ in range(2)];zero=[n,n];prods=[1,1]
 for c in (0,1):
  shift=c*a/2
  for i,z in enumerate(x):
   q=math.floor((z-shift)/a);left=q*a+shift;right=left+a;heapq.heappush(heap,(z-left,c,i));heapq.heappush(heap,(right-z,c,i))
 r1=rtau=0.;winner=None;events=amb=0
 while heap:
  t=heap[0][0]
  if t>=cut:break
  while heap and heap[0][0]==t:
   _,c,i=heapq.heappop(heap);old=counts[c][i];counts[c][i]+=1
   if old==0:zero[c]-=1
   else:prods[c]=prods[c]//old*(old+1)
   heapq.heappush(heap,(t+a,c,i));events+=1
  N0=prods[0] if zero[0]==0 else 0;N1=prods[1] if zero[1]==0 else 0;m=N0+k*N1
  if not m:continue
  if t==0:return {'status':'atom_null_case','events':events}
  logm=math.log(m);margin=logm-n*math.log(2*t);end=min(heap[0][0],cut)
  if abs(margin)<1e-10 or abs(margin-math.log(TAU))<1e-10:amb+=1
  if margin>0:r1=max(r1,min(end,.5*math.exp(logm/n)))
  if margin>math.log(TAU):
   right=min(end,.5*math.exp((logm-math.log(TAU))/n))
   if right>rtau:rtau=right;winner={'left':t,'right':right,'N0':str(N0),'N1':str(N1),'m':str(m)}
 if not r1:return {'status':'not_E1','events':events,'near_equal_events':amb}
 assert winner and rtau>=r1*(1-1e-12);N0=int(winner['N0']);N1=int(winner['N1']);m=int(winner['m']);assert N0+k*N1==m
 return {'status':'E1','events':events,'near_equal_events':amb,'r1':r1,'r_tau':rtau,'winner':winner,'pi0':N0/m,'pi1':(k*N1)/m,'N0_over_m':N0/m,'N1_over_m':N1/m}

def block(spec):
 n,k,first,last=spec;t=time.monotonic();cpu=time.process_time();delta,a,cut=params(n,k);seed=630000+n*10+k;rng=np.random.default_rng(seed);points=(rng.random((256,n))-.5)*a;rows=[]
 for index in range(first,last):
  x=points[index];r=scan(x,k,a,cut);r['sample_index']=index;r['x']=x.tolist();rows.append(r)
 return {'n':n,'k':k,'first':first,'last':last,'N':last-first,'seed':seed,'delta':delta,'spacing_binary64':a,'cut_binary64':cut,'rows':rows,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def ticks():
 lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');v=(ctypes.c_uint32*4)();c=ctypes.c_uint32(4);return list(v) if lib.host_statistics(lib.mach_host_self(),3,v,ctypes.byref(c))==0 else None

def summary(out):
 results=[]
 for n in (32,128,512):
  for k in (1,64,4096):
   blocks=[r for r in out['blocks'] if r['n']==n and r['k']==k];N=sum(r['N'] for r in blocks)
   if not N:continue
   rows=[q for b in blocks for q in b['rows']];one=np.array([float(r.get('N0_over_m',0.)) for r in rows]);two=np.array([float(r.get('N1_over_m',0.)) for r in rows]);hits=sum(r['status']=='E1' for r in rows);scale=(1+k)*TAU*n;s0=scale*float(one.mean());s1=scale*float(two.mean());p=hits/N;W=p*n;identity=(s0+k*s1)/(1+k);rhs=TAU*W;assert abs(identity-rhs)<1e-9*max(1,abs(rhs))
   limits=[1.,2.,4.,math.sqrt(n),math.sqrt(n)*math.log(n+2)];tail=[{'L':L,'sourceweighted_tail_per_mass':(max(s0-L,0)+k*max(s1-L,0))/(1+k)} for L in limits]
   results.append({'n':n,'k':k,'N':N,'E1_hits':hits,'event_near_equal_count':sum(r.get('near_equal_events',0) for r in rows),'S0':s0,'S1':s1,'S0_sample_SE':scale*float(one.std(ddof=1))/math.sqrt(N) if N>1 else None,'S1_sample_SE':scale*float(two.std(ddof=1))/math.sqrt(N) if N>1 else None,'W':W,'weighted_mean':identity,'expected_weighted_mean':rhs,'identity_residual':identity-rhs,'tail':tail})
 return results

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--case',default=None);ap.add_argument('--samples',type=int,default=32);ap.add_argument('--workers',type=int,default=14);ap.add_argument('--output',type=Path,default=Path(__file__).with_name('uniform_replay.json'));a=ap.parse_args()
 cases=[tuple(map(int,a.case.split(',')))] if a.case else [(n,k) for n in (32,128,512) for k in (1,64,4096)]
 assert 1<=a.workers<=14 and 0<a.samples<=256
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool: blocks=list(pool.map(block,[(n,k,0,a.samples) for n,k in cases]))
 out={'blocks':blocks,'summaries':summary({'blocks':blocks}),'parent_peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'command':shlex.join([sys.executable]+sys.argv)}
 with a.output.open('w') as f:json.dump(out,f)
if __name__=='__main__':main()
