#!/usr/bin/env python3
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);args=p.parse_args()
manifest=json.loads((base/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
print('Archive hashes verified:',len(manifest['sha256']))
if not args.verify_only:
 if args.output_dir is None:p.error('--output-dir required unless --verify-only')
 args.output_dir.mkdir(parents=True,exist_ok=False)
 for stem in ['soft_bv_checks','score_event_checks']:
  out=args.output_dir/(stem+'.json')
  subprocess.run([sys.executable,str(base/(stem+'.py')),'--output',str(out)],check=True,env=os.environ.copy())
  assert out.read_bytes()==(base/(stem+'.json')).read_bytes(),stem+' JSON differs'
 print('Both complete JSON outputs reproduced byte-for-byte')
