# R187 soft/scale BV numerical review

Six one-dimensional moment cases, 30 product-bound formula rows, and 15 selector-formula rows were evaluated. All retained observations pass. Eight selector rows have h≤1/2; the remaining seven are marked unavailable, without clipping h. These are numerical diagnostics and finite evaluations of authored upper formulas, not a uniform proof, actual multidimensional norm calculation, physical FULL/FIRST/history instance, or fitted dimension order.

## Formula and boundary checks

The implementation uses f_s=(1−s)h+sφ with the original φ=h*w evaluated by E3. On smooth intervals f'_s=sφ'. Hence

`U=(φ−h)/f_s`, `V=−1−xsφ'/f_s`, and `∂sV=−xφ'h/f_s²`.

The derivative vanishes outside the hard interval. It is nonnegative inside. The spatial face delta is **not** included in V: its missing mass is retained separately in the surface formula. Consequently E_f U=0 and E_f V=−(1−s), not zero except at s=1. The six s inputs are exact rational values 1/2,3/4 (initial), 1−2^-20,1 (boundary stress), and 9/10,99/100 (expanded). Fraction stores these inputs before high-precision conversion.

Even integrands are integrated on [0,1/2] and [1/2,∞), then doubled; this is exactly the split at −1/2,0,1/2 on the full line. The isolated closed face does not affect these Lebesgue integrals. Infinite tails are integrated with infinite endpoints, without a finite cutoff presented as exact. E|∂sV| is supported on the compact core and independently cross-checked after cancelling f_s. E U² is cross-checked by compact integration plus the actual outer-tail mass (1−τ)/s. The actual φ mass and second moment are also checked numerically against 1 and 13/12.

## One-dimensional observations

At both 40 and 60 dps the mass and mean identities pass the 1e-28 residual checks. Sample values at 60 dps are:

| s | E U² | Var V | E|∂sV| | E V |
|---|---:|---:|---:|---:|
| 1/2 | 1.3195471303 | 0.7239164125 | 0.1581090861 | −1/2 |
| 3/4 | 1.0579001276 | 0.9103187425 | 0.1946313125 | −1/4 |
| 1−2^-20 | 0.9980007771 | 0.9901649648 | 0.2537441947 | −2^-20 |
| 1 | 0.9980008161 | 0.9901650895 | 0.2537444907 | 0 |

The parent constants are independently evaluated as c0=φ(1/2)≈0.3903080328, τ≈0.5054583160, Lφ≈3.1639534137,

`I=2(1/c0−1)≈3.1241579263`,

`J=2+(13/6)Lφ²≈23.6896359427`,

`K1=2(τ−c0)/c0≈0.5900482363`.

Every sampled moment satisfies E U²≤I, Var V≤J and E|∂sV|≤K1. The separately authored coarse checks E U²≤26/3, E V²≤110/3 and E|∂sV|≤2 also pass. E V² and Var V are saved as different quantities; their distinction is essential when E V≠0. None of these finite evaluations certifies the uniform inequalities over all s.

## Product and selector formula tables

For n=1,16,256,4096,65536, each s row evaluates the specified ac expression

`n sqrt(EU² VarV)+n^(3/2)(1−s)sqrt(EU²)+n E|∂sV|`

and surface expression

`n[1+(1−s)sqrt((n−1)EU²)]`.

Their sum is compared with both the parent uniform upper expression and the coarse 24n+6n^(3/2)(1−s). At n=1, surface equals exactly 1 as required. These quantities are analytic bounds evaluated from one-dimensional moments; the script does not label them actual product BV norms.

For n=4,16,256,4096,65536 and c=1,4,8, the selector table requests h=c sqrt(log(n+1)/n). Only h≤1/2 is evaluated. The parent expression

`B=1+log2 sqrt(nJ)+h sqrt(nI)+log2[(sqrt(IJ)+K1+1)nh+sqrt(I)n^(3/2)h²]`

is stored as five separate terms, together with the coarse M_n(h) and its normalized B/[sqrt(n)log(n+1)] value. The latter is a dimensionless finite formula evaluation, not an exponent fit. No rows at n=4 are admissible. The valid rows are n=16,c=1; n=256,c=1; and all three c values at n=4096 and 65536. The two linear-softness and quadratic-softness costs are retained in full.

## Precision, dependency, and reproduction

Both 40 and 60 dps blocks are saved at 50 printed digits; digits exceeding working precision are not claimed accurate. The largest observed difference across saved one-dimensional moments is about 1.31e-41. Such agreement and the residual thresholds are empirical controls, **not directed intervals or rigorous quadrature error bounds**. There is no Monte Carlo or new software installation. Failed observed checks exit nonzero.

The system python3 needs the existing local mpmath 1.3.0 vendor directory supplied externally:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 soft_bv_checks.py
```

The script uses standard `import mpmath`, records the package version and relative-name `.py` source hash (excluding bytecode), and stores only a filename key for the adjacent task-contract hash. It accepts `--output /tmp/result.json`. An isolated replay copies just the script and task contract into `/tmp/r187_soft_bv_review/`, uses the same external PYTHONPATH, and compares the entire JSON. No output timing or absolute dependency path enters the JSON.

The formulas keep the ac scale mean and all surface terms. They do not establish the parent's general receiver/source payment or the centered-cube weak bound. Further proof and integration remain outside this finite numerical task.

## Additional independent score-event review

The parent's three `score_event_checks.py/json` cases were independently read together with SE1–SE6 of `score_evolution_budget.md`. No substantive issue was found. The weights are the same rational masses times products min(1,A_i/t), with full posterior normalization on the current surviving set. Initial score is the right state at t=1; each segment ends at its pre-threshold left score; all same-time threshold multiplicities are then updated on the pre-deletion support before the deletion is applied. Duplicate threshold times are one event but retain each coordinate's multiplicity. Endpoint t=4 events are included consistently with the closed endpoint convention.

For each constant-score segment, the exact rational mean difference equals the variance integral from dm/dlogt=−Var. This is independently compared with 50-dps quadrature of Var(t)/t on that segment. The signed deletion formula uses the same threshold-updated middle state and checks δm=(deleted weight/e_before)(m_survivors−m_removed). The full identity is V=m_initial−m_final+Theta+signed_deletion. Positive and negative deletion cases and a same-time threshold/deletion event are present. The nodewise positive-flux comparisons use the correct integer-score g≤Var and IID g≤n/4 inequalities.

The stored exact variance integrals are 2/9, 307/2310, and 1232441267858221985140/30307243952942936898919. One case has positive deletion forcing 36/55; the expanded case has negative signed deletion. No arbitrary forcing bound, original forest, FIRST/history, or uniform physical price is certified. Its 50-dps quadrature is a consistency check, not an interval enclosure.

Exactly one isolated replay copied only the final score script to `/tmp/r187_score_event_review/` and wrote a new `replayed_score_events.json` via `--output`, using the same existing PYTHONPATH as above. The replay exited zero and its complete JSON equalled the parent's output. The soft-BV script and JSON were neither modified nor rerun for this review.

Reviewed score-file SHA256:

- `score_event_checks.py`: `8faaafa343f023dcd87d7bfcd8e5f87df067000d2a74f5cdea3fa02db14c2da0`

- `score_event_checks.json`: `e4f36fdeac8325e76ed9d24ccfaa30054c29ce69ee755069af565698cac4920d`
