#!/usr/bin/env python3
"""Finite algebraic score-event diagnostics; not an original-forest certificate."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
import mpmath as mp

def run():
 mp.mp.dps=50
 def mpf(q):return mp.mpf(q.numerator)/q.denominator
 cases=[('initial',[[F(1,2)],[8]],[1,1],{}),('threshold_delete_tie',[[1,2],[2,3],[4,4]],[1,2,3],{F(2):[2]}),('expanded',[[F(1,2),F(3,2),2,3],[1,2,2,4],[F(3,2),3,4,5],[2,2,3,4]],[F(1,1000),2,3,100],{F(3,2):[0],F(3):[1]})]
 rows=[]
 for label,alphas,masses,deletions in cases:
  alphas=[list(map(F,a)) for a in alphas];masses=list(map(F,masses));n=len(alphas[0]);alive=list(range(len(alphas)));start=F(1);end=F(4)
  def exact(t,ids,right):
   weights=[];scores=[]
   for z in ids:
    w=masses[z]
    for a in alphas[z]:w*=min(F(1),a/t)
    weights.append(w);scores.append(sum(a<=t if right else a<t for a in alphas[z]))
   e=sum(weights,F(0));assert e>0
   probs=[w/e for w in weights];mean=sum((p*k for p,k in zip(probs,scores)),F(0));var=sum((p*(k-mean)**2 for p,k in zip(probs,scores)),F(0));flux=sum((p*q*max(k-l,0) for p,k in zip(probs,scores) for q,l in zip(probs,scores)),F(0));assert flux<=var and flux<=F(n,4)
   return mean,e
  initial,_=exact(start,alive,True);previous=start;theta=F(0);delete=F(0);segments=F(0);numeric=mp.mpf(0);events=[]
  times=sorted(set([end]+[a for aa in alphas for a in aa if start<a<=end]+[a for a in deletions if start<a<=end]))
  for t in times:
   left,_=exact(previous,alive,True);before,e_before=exact(t,alive,False);segments+=left-before
   ids=list(alive)
   def variance(x):
    weights=[];ks=[]
    for z in ids:
     wt=mpf(masses[z]);k=0
     for a in alphas[z]:
      aa=mpf(a);wt*=min(mp.mpf(1),aa/x);k+=aa<x
     weights.append(wt);ks.append(k)
    total=sum(weights);m=sum(w*k for w,k in zip(weights,ks))/total
    return sum(w*(k-m)**2 for w,k in zip(weights,ks))/total/x
   numeric+=mp.quad(variance,[mpf(previous),mpf(t)])
   middle,_=exact(t,alive,True);th=middle-before;assert th>=0;theta+=th
   removed=[z for z in deletions.get(t,[]) if z in alive];survivors=[z for z in alive if z not in removed]
   after,e_after=exact(t,survivors,True);dj=after-middle;delete+=dj
   if removed:
    rm,er=exact(t,removed,True);assert er+e_after==e_before;assert dj==er/e_before*(after-rm)
   events.append({'t':str(t),'threshold':str(th),'deletion':str(dj),'survivors':survivors});alive=survivors;previous=t
  final,_=exact(end,alive,True);assert segments==initial-final+theta+delete
  error=abs(numeric-mpf(segments));assert error<mp.mpf('1e-35')
  rows.append({'stage':label,'n':n,'initial':str(initial),'final':str(final),'threshold_forcing':str(theta),'signed_deletion':str(delete),'variance_integral_exact_by_segments':str(segments),'variance_integral_quadrature':mp.nstr(numeric,45),'quadrature_error':mp.nstr(error,8),'events':events,'passed':True})
 return {'cases':rows,'all_checks_pass':True,'scope':'Three finite rational threshold/deletion models, exact jump algebra and independent 50dps variance integration. No original born forest, FIRST, history or uniform forcing price is certified.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();a.output.write_text(json.dumps(run(),indent=2,sort_keys=True)+'\n');print('3 finite event cases passed')
