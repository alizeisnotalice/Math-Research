# Parent: how a whole soft-tail estimate joins the extremal geometry

Status: exact candidate independently screened; pending final author and audit freeze. No general closure claim.

Let h_n=min(1/2,c sqrt(log(n+1)/n)), c>0 fixed, and sbar_n=1-h_n. This is a chosen split of the actual parameter range, not a claim that every strictsoft parameter is near 1. On the entire actual soft tail s>=sbar_n use the two-parameter spatial maximal density budget B_n(h_n) from residual_receiver_geometry.md, after the full original time-row budget and actual unique j have been settled. This order is essential: it avoids charging distinct j references after the spatial supremum.

With l=log(b/a), I=2(1/c0-1), J=2+(13/6)Lphi^2 and K1=2(tau-c0)/c0, the precise bound is

 B_n(h)=1+l sqrt(nJ)+h sqrt(nI)
          +l[(sqrt(IJ)+K1+1)n h+sqrt(I)n^(3/2)h^2].

The identities c0=1/2-E3(1)>0, tau=1/3+2E4(1), Lphi=2/(1-e^-1), and the one-dimensional variance and mixed-derivative bounds are proved in the author manuscript, not inferred from numerical values. The cap h<=1/2 ensures s>=1/2 in these estimates.

Uniformly n>=1, h_n sqrt(n)<=c sqrt(log(n+1)), n h_n<=c sqrt(n log(n+1)), and n^(3/2)h_n^2<=c^2 sqrt(n)log(n+1). Thus B_n(h_n)=O_c(sqrt(n)log(n+1)) with explicit dimension-independent constants displayed above. Multiplying the original full-row factor 16 Lambda/(3K kappa) gives this same source price times W_A for the specified original reciprocal J-share soft tail, provided the inherited outer constants are retained. It is not a claim about every other mother branch.

On the complementary harder part s<sbar_n, apply R186 to its actual overlap gate. Write Tstar for the supremum of the permitted original-window clocks and delta_n=K n A_n(sbar_n)^2 Tstar^2/48. When delta_n<=1 the whole harder part with w_g>=delta_n costs (32 Lambda/3)sqrt(n)W_A. Assign s=sbar_n to the soft part, so the two accounting regions are disjoint. A common original source budget is used twice with two explicit constants; no extra free partition is claimed.

For fixed c with c^2>63, once the cap is inactive the coarse R186 envelope gives

 delta_n <= (K e^2/48) n(n+1)^(6-c^2/9),

since n h_n^2=c^2 log(n+1). Thus delta_n eventually lies below one, and its decay exponent is supported analytically rather than by fitting. For c=8 the displayed bound is O(n^(-1/9)); actual mixed-affinity thresholds may be much smaller. Finite n with delta_n>1 are not falsely declared to have a nonempty R186 paid gate.

The remaining traffic of this specified branch is now only the harder parameter region with very small actual good overlap, plus any uncovered finite-dimensional gate cases and the other original mother branches. The R186 same-alpha current/J separation still applies there. A weighted current-face or far-source column budget is needed; neither the BV estimate nor the score-evolution identity proves it automatically. No additional layer iteration, new reference normalization or source ownership is smuggled into this integration.
