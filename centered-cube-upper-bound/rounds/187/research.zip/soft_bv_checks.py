#!/usr/bin/env python3
"""Finite high-precision diagnostics for mixed soft/scale BV bounds."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import argparse,hashlib,json
import mpmath as mp
HERE=Path(__file__).resolve().parent

def compute(dps):
 mp.mp.dps=dps
 half=mp.mpf('.5');tol=mp.mpf('1e-28')
 @lru_cache(None)
 def phi(x):
  x=abs(x)
  return 1-mp.expint(3,half+x)-mp.expint(3,half-x) if x<=half else mp.expint(3,x-half)-mp.expint(3,x+half)
 @lru_cache(None)
 def phip(x):return mp.expint(2,x+half)-mp.expint(2,abs(x-half))
 def integral(f):return 2*(mp.quad(f,[0,half])+mp.quad(f,[half,mp.inf]))
 c0=half-mp.expint(3,1);tau=mp.mpf(1)/3+2*mp.expint(4,1);Lphi=2/(1-mp.exp(-1));I=2*(1/c0-1);J=2+mp.mpf(13)/6*Lphi**2;K1=2*(tau-c0)/c0
 massphi=integral(phi);Umean=integral(lambda x:phi(x)-(1 if x<=half else 0));secondphi=integral(lambda x:x*x*phi(x));assert abs(massphi-1)<tol and abs(Umean)<tol and abs(secondphi-mp.mpf(13)/12)<tol
 specs=[('initial','.5'),('initial','.75'),('stress','near1'),('stress','1'),('expanded','.9'),('expanded','.99')];rows=[]
 for stage,ss in specs:
  sq=F(1)-F(1,2**20) if ss=='near1' else F(ss);s=mp.mpf(sq.numerator)/sq.denominator
  def f(x):return (1-s)*(1 if x<=half else 0)+s*phi(x)
  def U(x):return (phi(x)-(1 if x<=half else 0))/f(x)
  def V(x):return -1-x*s*phip(x)/f(x)
  def deriv(x):return -x*phip(x)*(1 if x<=half else 0)/f(x)**2
  mass=integral(f);meanV=integral(lambda x:V(x)*f(x));EU2=integral(lambda x:U(x)**2*f(x));EV2=integral(lambda x:V(x)**2*f(x));varV=EV2-meanV**2;derivmoment=2*mp.quad(lambda x:abs(deriv(x))*f(x),[0,half]);compact=2*mp.quad(lambda x:-x*phip(x)/f(x),[0,half]);EU2compact=2*mp.quad(lambda x:(phi(x)-1)**2/f(x),[0,half])+(1-tau)/s
  assert abs(mass-1)<tol and abs(meanV+(1-s))<tol and abs(EU2-EU2compact)<tol and abs(derivmoment-compact)<tol
  assert 0<=EU2<=I and 0<=varV<=J and 0<=derivmoment<=K1 and EU2<=mp.mpf(26)/3 and EV2<=mp.mpf(110)/3 and derivmoment<=2
  rows.append(dict(stage=stage,s_label=ss,s_fraction=str(sq),s=s,mass=mass,mean_U=Umean,mean_V=meanV,expected_mean_V=-(1-s),EU2=EU2,EU2_compact_plus_exact_tail=EU2compact,EV2=EV2,VarV=varV,E_abs_dsdV=derivmoment,derivative_compact_check=compact,checks_pass=True))
 products=[]
 for n in [1,16,256,4096,65536]:
  nn=mp.mpf(n)
  for row in rows:
   gap=1-row['s'];ac=nn*mp.sqrt(row['EU2']*row['VarV'])+nn**mp.mpf('1.5')*gap*mp.sqrt(row['EU2'])+nn*row['E_abs_dsdV'];surface=nn*(1+gap*mp.sqrt((nn-1)*row['EU2']));uniform=nn*(mp.sqrt(I*J)+K1+1)+2*mp.sqrt(I)*nn**mp.mpf('1.5')*gap;coarse=24*nn+6*nn**mp.mpf('1.5')*gap
   assert ac+surface<=uniform+tol and ac+surface<=coarse+tol and (n!=1 or surface==1)
   products.append(dict(n=n,s_label=row['s_label'],s=row['s'],ac_upper_formula=ac,surface_upper_formula=surface,total_formula=ac+surface,uniform_total_upper=uniform,coarse_total_upper=coarse,total_over_n_power_3_2=(ac+surface)/nn**mp.mpf('1.5'),checks_pass=True))
 selector=[]
 for n in [4,16,256,4096,65536]:
  nn=mp.mpf(n)
  for c in [1,4,8]:
   h=c*mp.sqrt(mp.log(nn+1)/nn);valid=h<=half
   if valid:
    terms=[mp.mpf(1),mp.log(2)*mp.sqrt(nn*J),h*mp.sqrt(nn*I),mp.log(2)*(mp.sqrt(I*J)+K1+1)*nn*h,mp.log(2)*mp.sqrt(I)*nn**mp.mpf('1.5')*h*h];B=sum(terms);coarse=1+7*mp.sqrt(nn)*mp.log(2)+3*h*mp.sqrt(nn)+24*nn*h*mp.log(2)+3*nn**mp.mpf('1.5')*h*h*mp.log(2)
    assert B<=coarse+tol
   else:terms=[];B=coarse=None
   selector.append(dict(n=n,c=c,h=h,valid_h_at_most_half=valid,B_terms=terms,selector_B=B,coarse_selector_M=coarse,B_over_sqrt_n_log_n_plus_1=B/(mp.sqrt(nn)*mp.log(nn+1)) if valid else None,status='finite evaluation of authored upper bound' if valid else 'outside h<=1/2; not evaluated'))
 def strings(x):
  if isinstance(x,mp.mpf):return mp.nstr(x,50)
  if isinstance(x,dict):return {k:strings(v) for k,v in x.items()}
  if isinstance(x,list):return [strings(v) for v in x]
  return x
 return strings(dict(dps=dps,constants=dict(c0=c0,tau=tau,Lphi=Lphi,I=I,J=J,K1=K1),phi_mass=massphi,phi_second_moment=secondphi,moment_cases=rows,product_formula_table=products,selector_table=selector))

def run():
 low,high=compute(40),compute(60);differences=[]
 for a,b in zip(low['moment_cases'],high['moment_cases']):
  dif={k:mp.nstr(abs(mp.mpf(a[k])-mp.mpf(b[k])),12) for k in ['mass','mean_U','mean_V','EU2','EV2','VarV','E_abs_dsdV']};assert all(mp.mpf(v)<mp.mpf('1e-27') for v in dif.values());differences.append(dict(s=a['s_label'],absolute_differences=dif))
 for a,b in zip(low['selector_table'],high['selector_table']):assert a['valid_h_at_most_half']==b['valid_h_at_most_half']
 root=Path(mp.__file__).resolve().parent;sha=hashlib.sha256()
 for p in sorted(root.rglob('*.py')):sha.update(p.relative_to(root).as_posix().encode());sha.update(p.read_bytes())
 return dict(schema='r187_soft_bv_diagnostics_v1',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependencies=dict(mpmath_version=mp.__version__,mpmath_source_tree_sha256=sha.hexdigest()),low_precision=low,high_precision=high,precision_differences=differences,summary=dict(moment_cases=len(high['moment_cases']),product_formula_rows=len(high['product_formula_table']),selector_rows=len(high['selector_table']),valid_selector_rows=sum(x['valid_h_at_most_half'] for x in high['selector_table']),all_observed_checks_pass=True),limitations=['Numerical quadrature and precision comparison, not directed intervals or a uniform proof','Smooth V omits face delta and has mean -(1-s); surface bound is recorded separately','Product and selector tables evaluate analytic upper formulas, not actual multidimensional variation norms','All h>1/2 rows are left unavailable without clipping','No physical FULL/FIRST/history qualification or fitted n order is inferred'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'soft_bv_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r['summary'],sort_keys=True))
