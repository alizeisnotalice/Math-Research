# 第187轮：整个软参数尾的全局核变差预算

一般中心立方体 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮取得的实际进展是支付指定原互反正 J-share 的整个近全软参数尾，不再要求good重叠下界。较硬参数区的极小重叠及其他原分支仍需攻坚。

## 主结果与完整费用

对真实product kernel P_s,L，建立共同参数s∈[1−h,1]、L∈[a,b]的L1最大密度界B_n(h)，0≤h≤1/2、b/a≤2。它同时保留内部导数与所有移动硬面的混合变差：

 B_n(h)=1+ell sqrt(nJ)+h sqrt(nI)
       +ell[(sqrt(IJ)+C1+1)n h+sqrt(I)n^(3/2)h²],
 ell=log(b/a), I=2(1/c0−1), J=2+(13/6)Lphi²,
 C1=2(tau−c0)/c0.

所有常数取实际一维核，已解析证明维度一致的矩界。尺度regular score的均值是−(1−s)，并非0；s=1时原核无硬跳，但其s导数仍有硬面项，均已计入。

先用原完整删除行界，再用实际唯一j合并，最后应用上述全参数空间包络，得整个soft尾来源价(16Lambda/(3Kkappa))B_n(h)W_A。未引入额外j参考、未重新选择alpha/rho、未假nu≤beta或source坐标独立。

取h_n=min(1/2,c sqrt(log(n+1)/n))，解析回代给O_c(sqrt(n)log(n+1))价格。再将较硬区域与第186轮重叠门拼接；两块不交、两个来源费用均显式保留。c²>63时，第186轮粗阈值最终小于1。这里的阶数来自证明，不从有限表拟合。

## 辅助路线及未付项目

完整score演化包含一般BV阈值forcing和真实删除均值项。删除正forcing可用原born-block账支付，但归一化阈值forcing的较小来源价未证明，因此该路线没有取得更小的无条件reference费用。保留精确接口避免后续重复漏项，不计作第二个根阶付款。

整个一般目标仍缺：s<1−h_n下的极小good重叠交通、有限阈值不适用处及其他原mother分支。第186轮同alpha似然分离可继续定位实际加权硬面与远源列，必要几何不能代替其预算。未声称一般闭合。

## 实际本机验证

调用已有Python Fraction/mpmath 1.3.0，无安装。三个阶段覆盖6组一维矩（40/60位复核）、30组product混合导数上界公式、15组selector公式（8组h≤1/2），均通过；越界h未截断冒充可用。父级独立运行，完整JSON逐字节一致。

另实际运行3组有限有理数事件模型，包括同刻阈值与正/负删除，精确跳跃恒等式与50位独立方差积分一致。这些不是原森林或FULL/FIRST/history证书；高精度诊断不是区间证明，product表也不是实际高维变差范数的直接计算。

## 证明、审计与复现

residual_receiver_geometry.md保存完整主证明及原row回代，score_evolution_budget.md保存辅助费用，parent_soft_tail_integration.md说明全局参数拼接，proof.tex.txt为详细LaTeX文本。独审先筛准确命题，再全文审；核对了粗常数与保留soft门的回代记号。

解压后python3 reproduce.py --verify-only。实际本机环境：

 PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 reproduce.py --output-dir <不存在的新目录>

数值输出有明确适用范围，未编译PDF。E03工具仅用于跨层质量/终端账资格核对，没有调用未经核验的外部Bellman定理；I02仅入场核对，没有将确定演化冒充鞅补偿。实际使用1 Astra high、2 Sol high、1 Sol medium，按独立任务启用；无扣额明细，不猜成本。仅归档本轮报告及必要证明/复现材料，逐轮提交推送。
