# R187：原删除后验的完整 score 演化与条件性方差参考预算

本稿推导原 fixed-(j,y) 后验在全部阈值和原删除下的均值演化，给出可回代 R186 固定正流量参考的方差预算。删除正增量有实际共同来源价格；归一化阈值 forcing 的较小全局来源价尚未取得。因此本稿没有证明 R186 的 nT/4 无条件参考质量变小，不把“假设 H 小”登记为新付款。其作用是给出准确的条件接口并防止漏掉连续阈值或删除费用。

## SE1. 实际原过程与端点约定

固定原 (omega,V,j,y) 和共同窗口 a≤b≤2a，nu=nu_V 是原硬来源。令 r=log t，A_i(z)=b C(|y_i−z_i|/b)/c_j，

    w_t(z)=∏_i min(1,A_i(z)/t),
    mu_t(dz)=1_Zt(z)w_t(z)nu(dz),  e_t=||mu_t||,
    Pi_t=mu_t/e_t,
    k_t(z)=Σ_i1_{A_i(z)<t},  m_t=∫k_t Pi_t.

这里的 Z_t 是原有限森林禁块版本，嵌套递减、仅有限实际删除、跳间恒定，不能替换成一个自由 nested family。fixed (omega,V,j,y,t) 的这些对象不依接收点 x；terminal A、rho、alpha、good/bad、current s/L 与全部原 masks 仍依 receiver，并全部保留到最终正放松时。

按 R117 JG2，只考虑原 receiver 前固定的非空 heavy 初始区间 I，左端 tau=a/c_j，右端 T≤bc_j；开放或闭合归属沿原实际版本。区间内 e_t>0，且 e_*≥B_j T^n>0（开放端取内侧左极限）。零长度/空区间没有 dt/t 通量，直接忽略。以下可先在有限正子区间证明，再取原端点极限。

为书写事件的 BV 式，采用 dt/t 等价的右连续 score

    k_t^+(z)=Σ_i1_{A_i(z)≤t}.

它只在固定 source 的有限阈值时刻改变原严格 score 的值，Fubini 后不改变原 dt/t 交通。m_start 取 tau 的右态，含已给定的 Z_tau 与 k_tau^+；因此阈值和删除事件只在 **(tau,T]** 计数，不再收 tau 原子。若 I 的右端开放，终端是 T−，所有恰在 T 的事件排除。下面以这个事件区间 J 表示准确的 (tau,T] 或其右开版本。

同刻 threshold 与 deletion 采用一个统一计算次序：先在全部 pre-deletion 来源上把 k^- 更新成 k^+，得到中间态；再执行原真正删除。权重 w 连续，threshold 不改变 e。以下 deletion 的 before 均指这个 threshold 后、delete 前中间态。计算次序只是 BV 恒等式的拆分，未在原过程插入新来源或时间质量。

## SE2. 完整阈值 forcing：一般 nu 的连续 BV 不能省略

定义归一化正阈值测度

    Theta(dr)=Σ_i∫ 1_Z(r−)(z) w_exp(r)(z)/e_(r−)
                    delta_(log A_i(z))(dr) nu(dz),      (SE1)

限制到 J。e_(r−)、Z_(r−) 在 deletion 同刻指尚未删除的质量/支持；在其余时刻连续选择与通常值一致。Theta 的原子同时包括该时刻所有 source 的阈值 multiplicity，不能把一个来源的多坐标跨越只计一次。

一般 L1/连续 nu 会使 Theta 有非原子部分；它可以是 AC 或奇异连续。故本稿不把它写成一列“全局离散阈值跳跃”的总和。原 finite-tree 假设仅使 deletion 有限，不使所有 source 的 threshold 离散。

逐 source k^+ 的正 Stieltjes 测度为 Σ_i delta_(log A_i(z))，而 w 对 r 绝对连续、满足 dw=−k w dr。在一个禁块恒定区间，正 Tonelli 与 BV 乘积法给

    de=−e m dr,
    d(∫k dmu)=−∫k²dmu dr+∫w dk nu,
    dm=−Var_Pi(k)dr+dTheta.                             (SE2)

其中 m 和 k 在 dr 项的版本差异无影响；阈值原子处 e 连续，所以没有遗漏的比值二阶项。heavy 区间的 e_*>0、nu 有限与每 source 至多 n 个阈值保证该逐行测度计算有限；来源参数可测性继承原 finite forest 和原 Z,w,e 核。

## SE3. 真正删除均值项与全 BV 恒等式

在原删除时刻 t，令 D_t=Z_(t−)\Z_t，

    d_t=∫_Dt w_t nu,  e_before=e_after+d_t,
    eta_t=d_t/e_before.

记 m_surv 与 m_removed 为 **threshold 更新后的** k^+ 在存活/删除部分的相应概率均值。质量为零的部分不作除法，相应乘积按0处理。原 heavy 区间内需要计入的删除均有 e_after>0。删除造成的真实均值变化为

    delta_del m_t=eta_t(m_surv−m_removed),
    |delta_del m_t|≤n eta_t.                            (SE3)

证明是 m_before=(e_after m_surv+d_t m_removed)/e_before，直接相减。删除低 score 来源可使 m 增大；故删除项不能一概丢掉或认为非正。

结合 SE2 得完整测度身份

    dm=−Var_Pi(k)dr+dTheta
                    +Σ_(t in J)delta_del m_t delta_(log t).

令

    V_I=∫_I Var_Pi_t(k_t)dt/t,
    D_+=Σ(delta_del m_t)_+,  D_−=Σ(−delta_del m_t)_+,
    H_I=Theta(J)+D_+.

积分得到

    V_I=m_start−m_end+Theta(J)+D_+−D_−,
    V_I≤m_start+H_I.                                    (SE4)

H_I 是**完整正 forcing**，不是净均值 m 的正变差。若 continuous threshold forcing 同时抵消了负方差漂移，m 可以近乎不变而 V_I 非零；不能以 m 的可见上跳代替 Theta。精确式保留 m_end 和 D_−，上界只是对同一实际式的正放松，不领取任何原 raw 的负信用。

## SE4. 整数 score 的正 pair 通量与三个正确上界

令原无额外 mask 的 fixed-time 正通量

    g_t=∬[k_t(v)−k_t(u)]_+Pi_t(dv)Pi_t(du),
    F_I=∫_I g_t dt/t,  L_I=∫_I dt/t.

同一 Pi 的两个槽交换给 g_t=(1/2)E|k−k'|。因 k−k' 为整数，|k−k'|≤(k−k')²，所以

    g_t≤Var_Pi(k),
    g_t≤sqrt[Var_Pi(k)/2],
    g_t≤n/4.                                           (SE5)

第二式是 Cauchy，第三式是 R186 已审的层糕 ∫_0^n P(k>h)P(k≤h)dh≤n/4。没有假设各坐标独立。时间 Cauchy 和 SE4 给

    F_I≤min{n L_I/4, V_I, sqrt(L_I V_I/2)},
    V_I≤m_start+Theta(J)+D_+.                           (SE6)

这些上界作用于原完整删除过程；只保留任意原 positive mask 会减少其通量，无须对 receiver-dependent terminal A 或 bad 指示求导。若想取较小的一项，应在该 fixed source 行上选择，不能随后删掉相应来源/时间费用。

## SE5. 原删除 forcing 的实际来源总价

这里可使用原硬来源的真实 born 资格，而不能给 beta 虚构同样资格。R117 JG14–18 的窄已审结论是

    Σ_(t in I_j)eta_t
       ≤[c_j^(n/2)+sqrt(n)c_j^(3n/2)]/ell_n,
    Σ_j Σ_(t in I_j)eta_t≤B_n,
    B_n=ell_n^−1[(1−gamma^(−n/2))^−1
                    +sqrt(n)(1−gamma^(−3n/2))^−1],
    ell_n=1+log n.                                     (SE7)

它使用 nu(A)≤h(A) 于原森林节点、实际删除不交以及 heavy 下界；原最细 heavy fallback 没有被伪造为 light 块。开放右端仅计 heavy 内的左侧块，闭右端仅当实际删除后仍在 heavy 内才计入。beta 仅作为外积分来源，不需要 born 容量或 nu≤beta。

由 SE3，逐 fixed (omega,V,y) 有 Σ_j D_+≤nB_n，且 D_++D_− 的和也满足此界。故实际共同来源结算为

    EΣ_(V,j)∫beta_V(dy)D_+≤nB_n Wbeta≤nB_n WA.         (SE8)

这是真实已知的删除 forcing 费用，通常为 O(n^(3/2)/(1+log n))WA；它不是新的 raw 根价，也不包含连续 threshold forcing。

## SE6. source 总账与 R186 reference 的条件性替换

所有以下量都在 receiver x 之前固定。使用原 heavy I_j,V,y（包含实际 far；比 R186 扩大的物理窗更小），定义

    Cclock=EΣ_(V,j)∫beta_V(dy)L_I,
    Vsource=EΣ_(V,j)∫beta_V(dy)V_I,
    Mstart=EΣ_(V,j)∫beta_V(dy)m_start,
    Tsource=EΣ_(V,j)∫beta_V(dy)Theta(J),
    Dsource_+=EΣ_(V,j)∫beta_V(dy)D_+.

空/零长度区间的这些项全部设0。原 n 与窗比例统一时，以 Nstar 为非空比例带个数的统一上界，Tstar 为 R186 的精确 clock-sum supremum，有

    Nstar≤1+floor[log2/(2log(1+1/n))],
    Cclock≤Tstar WA,  Mstart≤nNstar WA,
    Dsource_+≤nB_n WA,
    Vsource≤Mstart+Tsource+Dsource_+.                  (SE9)

窗族若随 omega,V 变，使用该同一原来源族的确定 supremum；也可先逐窗结算再求和，不能把单窗系数无说明地提出 EΣ。独立重跑窗继续支付真实来源重复。

把 R186 canonical 正 score reference 先限制到 receiver 前固定的原 heavy I（actual far 全在其中），其真实质量 Gsource 正是 EΣ∫beta F_I。由 SE5–6 的逐行界和跨来源 Cauchy，

    Gsource≤min{n Cclock/4, Vsource,
                         sqrt(Cclock Vsource/2)}.       (SE10)

它是有真实来源账的 exact refinement，Γ 仍固定，所有 original masks 仍在 R186 的 chi/density 内。SE10 本身不证明 Vsource 的维数小；用它代替旧 nTstar WA/4 时必须完整保留右侧实际价格。

例如 **仅当另证** Tsource≤h_n WA 时，可令

    v_n=nNstar+h_n+nB_n,
    b_evo=min{nTstar/4, v_n, sqrt(Tstar v_n/2)},
    Gsource≤b_evo WA.                                  (SE11)

这是假设写明的条件结论，不是本稿已经支付 h_n。若能取 h_n=O(n²)，则这条接口给 b_evo=O(n^(3/2))；本稿没有证明所需阈值 forcing 来源界，不把这一条件维数改进登记为一般结论。

## SE7. 对实际 mixed receiver 价格的准确影响

R186 的固定-reference恒等式、actual good 的密度界 sqrt[K/(3w_g(y,v))] 与已审 full-selector mixed affinity A_n(sbar) 原样保留。给定合法的 source 质量系数 b，若已证 Gsource≤b WA，则

    Raw^+[s≤sbar,w_g≥delta]
       ≤(32Lambda/3)A_n(sbar)b sqrt[K/(3delta)]WA,
    delta=K A_n(sbar)² b²/(3n)                         (SE12)

在0<delta≤1时给根阶 (32Lambda/3)sqrt(n)WA。b=0 时相应通量零，先处理，不形成零分母。可以用已证旧 b=nTstar/4；使用 SE11 则必须另付其 h_n 条件。K=1 actual，原 hard16/3与外2Lambda仍各仅一次，soft/scale/clock/source/window费用均由相应冻结工具保留。

未证明新的 h_n 之前，SE12 没有新增更小的无条件 reference 系数，也不改善原已付 overlap 阈值。Astra/父稿的其他全输入付款若成立，应独立登记；不能借本条件接口为它补一份未经证明的 threshold 价。

## SE8. 首个未付费用与检查点

首个缺口是明确的归一化阈值来源测度 Tsource：source z 在 t=A_i(z) 穿越阈值时的质量，乘同刻原 w/e_before，并对真实 beta、j、V、omega 求和。每 source 至多 n 个阈值，**不**等于 Tsource≤nWA；因为该 source 在每个阈值的 posterior 权重不同且 e 可以变化。nu 连续不使该 forcing 为零；有限森林也不使它只剩 deletion。原 source/common-parent 与 FIRST 容量尚未在本稿给出足够小的 Tsource 统一估计。

因此不能从 dm 中仅保留−Var后宣称 ∫Var≤n，也不能忽略正 deletion 跳或只计离散 threshold 原子。这些错误都会把未知费用伪装成新的 Γ 质量节约。本文对删除 forcing 已给真实 SE8 价，对阈值 forcing 只给准确公式和条件接口，不将其重新命名为已付预算。

初步解析核验：固定 score、无 deletion 的片段有 dm=−Var dr；整数两个槽给 g≤Var，n=1 的二点端点分布给 g=n/4取等。边界核验：同刻 threshold→delete 的两个增量逐一相加恢复真正总均值；起点右态排除起点事件，开放终点排除末端事件；空/零长度 heavy 行无 dt 质量。扩大核验：一般连续 nu 的非原子 Theta 全部保留，有限原删除及 born-source总价均在原支持上；source 总账没有 nu≤beta、坐标独立、新父质量帽或 receiver-dependent reference。

这些是解析资格检查，不是新的 FULL 数值实例或维数拟合。有限 rational 数据可以在所有事件时刻直接核对均值：阈值之间各 source 的 mu 依固定整数 score指数衰减，Var 积分等于片段端点均值差；阈值和删除增量由同一个实际中间态计算。它们不认证原森林/FIRST/L1历史，也不替代 Tsource 的一般来源价。

本稿到此停止。结论是完整演化与 conditional source-budget 接口、真实删除费用及准确未付 threshold 费用；没有取得更小的无条件 R186 reference 质量。
