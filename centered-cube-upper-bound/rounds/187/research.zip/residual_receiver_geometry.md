# R187：软参数尾的双参数 BV 核预算与完整删除行付款

本稿证明一项实际原交通预算：对全部原 reciprocal 正 J-share，整个真实软参数尾 s≥1−h（0≤h≤1/2）有明确来源价格，且不需要 good 重叠下界。关键是同时控制 soft 与 scale 的真实两参数核上确界，保留 current 硬面的跳项。取 h≈√(log(n+1)/n) 时，价格为 O(√n log(n+1))W_A。

这支付 R186 FL 的 soft 参数补集的一种规范选择，包括其 low-Fcal/high-A/central 部分；不要求每行 near saturation，也不假设 strictsoft 本身接近1。s<1−h 且 good 重叠低于 FL 阈值的 hard 中间层仍未闭合。本稿不把此前 HG 必要面层条件当作已经付款。

## RG1. 准确命题与原范围

令 h_1=1_[−1/2,1/2]，

    w(r)=∫_0^1 exp(−|r|/t)dt,       phi=h_1*w,
    f_s(r)=(1−s)h_1(r)+s phi(r),
    P_(s,L)(x)=L^(−n)∏_(i=1)^n f_s(x_i/L).

给定 0<a≤b≤2a，写 ell=log(b/a)，0≤h≤1/2。这里 h 是本稿软参数尾宽度，不是原 hstop，也不是核 h_1。定义真正的两参数核包络

    M_n(h;a,b)=∫_(R^n) sup_{1−h≤s≤1, a≤L≤b} P_(s,L)(x)dx.

下文证明

    M_n(h;a,b)≤B_n(h,ell),                              (RG1)
    B_n=1+ell√(n V_V)+h√(n V_U)
       +ell[(√(V_U V_V)+C_cross+1)n h
                              +√V_U n^(3/2)h²],

其中三个常数由同一个实际一维核显式给定：

    c0=phi(1/2),       tau=∫_[−1/2,1/2]phi,
    Lphi=2/(1−exp(−1)),
    V_U=2(c0^(−1)−1),
    V_V=2+(13/6)Lphi²,
    C_cross=2(tau−c0)/c0.                              (RG2)

可使用更简单的全显式上界

    B_n(h,ell)≤1+7ell√n+3h√n+24ell n h
                                      +3ell n^(3/2)h². (RG3)

回代原模型时，保留原固定窗口、q、所有接收域 E_rec、same alpha/rho、实际 Pi 和原删除，只对所选正交通作允许的正放大。原 beta 与 nu 仅各受父来源 A_V 支配，不假定彼此有序。原常数 K=1（公式保留 K），令

    gamma=1+1/n,       kappa=K(1+gamma^(−n))/3.

kappa≥1 时互反域空；以下 kappa<1。RG1 与原完整删除行预算给实际付款

    Raw_rec,J^+[s≥1−h]
       ≤[16Lambda/(3K kappa)] B_n(h,log2) Wbeta
       ≤[16Lambda/(3K kappa)] B_n(h,log2) W_A.           (RG4)

这里 Raw 指原 source-hard 帽之前的正 J-share；其一次帽16/3和外2Lambda只恢复一次。原已付正集合应先删除，RG4仍支付所剩子集。一般完整 mother shares、非互反交通、独立窗口重复来源费用没有被此式消除。

## RG2. 一维概率核、矩与斜率

Tonelli 给 ∫w=∫_0^1 2t dt=1，所以 h_1,w,phi 都是概率密度。它们偶对称；phi 严格正，在正轴递减。二阶矩为

    ∫r²w(r)dr=∫_0^1 4t³dt=1,
    ∫r²phi(r)dr=1+1/12=13/12.                          (RG5)

这些只是核自身的 product 计算，与实际来源坐标是否独立无关。

边界值及核心质量可写成

    c0=∫_0^1 t(1−exp(−1/t))dt,
    tau=1/3+2∫_0^1 t² exp(−1/t)dt.

因此 c0≥(1−exp(−1))/2>1/4，核心上 phi≥c0，且 tau≥c0。为了 RG3，较弱 c0>3/16 已足够。

这里给出已审斜率界的自证，以明确尾部资格。对 r≥1/2，

    phi(r)=∫_0^1 t exp(−(r−1/2)/t)(1−exp(−1/t))dt.

其负 log 斜率是 1/t 对此正混合的加权均值。随着 r 增大，倾斜 exp(−(r−1/2)/t) 压低大的 1/t，故该均值不增；可由两重积分的反向协方差直接证明，不需要在 r=1/2 假定二阶倾斜矩有限。边界分子≤1，分母≥(1−exp(−1))/2，故尾部负 log 斜率≤Lphi。核心上 |phi'|=|w(r+1/2)−w(r−1/2)|≤1 且 phi≥c0，也给同一界。综上

    |phi'(r)|/phi(r)≤Lphi<4.                           (RG6)

边界的一阶连续性足以衔接，两端无额外原子。

## RG3. 正常化 soft score 与带负均值的 regular scale score

固定 s∈[1/2,1]，令 X 具有密度 f_s。只在空间硬面之外定义 regular scale 导数，记

    U_s(r)=(phi(r)−h_1(r))/f_s(r),
    V_s(r)=−1−r s phi'(r)/f_s(r),
    T_s(r)=∂_s V_s(r)=−r phi'(r)h_1(r)/f_s(r)².

此处 T_s 不是原 capture 系数 T。它只用于核微分，完成估计后不出现在原交通中。s 的导数不移动硬面，故 U_s 是真实 soft score；V_s 只是尺度导数的绝对连续部分，不能漏记其均值。

利用 f_s≥s phi、∫phi=∫h_1=1，

    E U_s=0,
    E U_s²≤2∫(phi−h_1)²/phi
           =2[−1+∫_[−1/2,1/2]1/phi]≤V_U.              (RG7)

分部积分 ∫r phi'(r)dr=−1 给

    E V_s=−1+s=−(1−s).                                (RG8)

该负均值恰对应尚未加入的 current 硬面质量。由 RG5–6，

    Var(V_s)≤E V_s²
       ≤2+2s∫r²phi'(r)²/phi(r)dr≤V_V.                 (RG9)

因为 f_s−s(phi−h_1)=h_1，所写 T_s 是精确混合导数；它非负且只支撑核心。核心分部积分给

    ∫_[−1/2,1/2] |r phi'(r)|dr=tau−c0,
    E|T_s|=∫_[−1/2,1/2] |r phi'|/f_s
             ≤2(tau−c0)/c0=C_cross.                   (RG10)

另外 tau≤phi(0)=2∫_0^(1/2)w≤2∫_0^1w=2c0，故 C_cross≤2。也可直接由 f_s≥s phi 和 RG6 得 E|T_s|≤2。用 c0>3/16、Lphi<4，

    V_U≤26/3<9,       V_V<110/3<49,
    E|T_s|≤2.                                         (RG11)

RG3 的粗版本使用这些已统一证明的常数；也可在 RG10 与直接估计之间取较小者。

## RG4. product 核的 regular 混合导数

写 r_i=x_i/L，X_i 在此段仅表示独立密度 f_s 下的积分变量。令

    U^(n)=Σ_i U_s(X_i),        V^(n)=Σ_i V_s(X_i).

它们是 product 核计算的工具，不是假定原 nu/beta 独立。对空间硬面之外，

    ∂_s P_(s,L)=P_(s,L) U^(n),
    ∂_(log L)^ac P_(s,L)=P_(s,L) V^(n),
    ∂_(log L)^ac ∂_s P_(s,L)
       =P_(s,L)[U^(n)V^(n)+Σ_i T_s(X_i)].              (RG12)

由 E U=0、E V=−(1−s)，有

    E(U^(n))²≤n V_U,
    E(V^(n))²≤n V_V+n²(1−s)².

Cauchy 与 RG10 因而给真正的 regular 混合导数 L1 界

    ||∂_(log L)^ac ∂_s P_(s,L)||_1
      ≤(√(V_U V_V)+C_cross)n
                        +√V_U n^(3/2)(1−s).           (RG13)

若误令 V 的均值为0，最后一项会被错误删除，最终 h² 费用也会丢失。本稿始终保留它。

## RG5. moving hard faces 的完整 mixed variation

当 L 向上穿过 L=2|x_i| 时，第 i 个核因子从软外值跳至闭核心值，jump 为1−s。固定其他坐标，P_(s,L) 的尺度跳量为

    L^(−n)(1−s)∏_(k≠i)f_s(x_k/L).

对 s 求导，真正的 mixed jump 为

    L^(−n)∏_(k≠i)f_s(x_k/L)
           [−1+(1−s)Σ_(k≠i)U_s(x_k/L)].              (RG14)

−1 项不能删除；即使 s=1 时原核本身没有 hard jump，∂_s P 在该端点仍有此跳。这也是矩形上确界估计必须包含 surface mixed measure 的原因。

对 log L 的两张 moving faces x_i=±L/2，各自法向速度为 L/2。两面总速度与 L^(−n)、其他 n−1 坐标的 Jacobian 精确相消。因此每个单位 dlog L 的全部 mixed surface variation 的 x 积分至多

    Σ_i E|−1+(1−s)Σ_(k≠i)U_s(X_k)|
       ≤n+√V_U n√(n−1)(1−s)
       ≤n+√V_U n^(3/2)(1−s).                          (RG15)

这已经计入两侧面，不再额外乘2。n=1 时该 surface 价精确为1。多面同时相交是 Lebesgue 零集；这里是实际 dx 核积分，不是删除 source 原子的借口。闭面代表元采用原 right-entry 值，BV 总变差计入全部跳，端点代表元差只在核接收零集上发生。

将 RG13 与 RG15 合并，得到固定 s 的全部尺度 mixed variation 预算

    ∫_(R^n)|D_(log L)(∂_s P_(s,L))|(dx,dlog L)
       ≤ell[(√(V_U V_V)+C_cross+1)n
                           +2√V_U n^(3/2)(1−s)]       (RG16)

（左边的尺度变量限于 [log a,log b]）。它只含一个尺度导数，没有假定二阶尺度导数或省略 corner 项。

## RG6. 两参数矩形上确界与全部 selector 费用

对每个 fixed s，令 R_s,L=∂_s P_(s,L)。尺度方向的一维 BV 不等式和 Tonelli 给

    ∫sup_(a≤L≤b)|R_s,L(x)|dx
      ≤||R_s,a||_1+∫|D_(log L)R_s,L|
      ≤√(n V_U)
        +ell[(√(V_U V_V)+C_cross+1)n
                          +2√V_U n^(3/2)(1−s)].        (RG17)

固定 source 平移 y 仅将 x 换成 x−y；这些积分常数不变。

在 s=1 的全软边，核无尺度硬跳，E V_1=0，因此

    ∫sup_(a≤L≤b)P_(1,L)(x)dx
       ≤1+ell√(n V_V).                                (RG18)

对全部 s∈[1−h,1]、L∈[a,b]，soft 基本定理逐点给

    P_(s,L)(x)≤P_(1,L)(x)+∫_(1−h)^1 |R_r,L(x)|dr.

先对整个矩形取上确界，再用 RG17–18 和 Tonelli。因为

    ∫_(1−h)^1(1−r)dr=h²/2,

恰得到 RG1。使用 RG11 则得到 RG3，其中 mixed regular 常数为23n+3n^(3/2)(1−s)，mixed surface 常数为 n+3n^(3/2)(1−s)，总常数24与最终 h² 系数3均明确。

这一估计控制真正共同且可自适应的 s(x),L(x)，没有固定参数后免费取上确界、参数网格或独立坐标来源选择。核在 s 上连续；L 的闭面代表元可由向上有理尺度逼近，因此上确界可取可测版本。所有正积分可先有限截断，再单调放宽；RG1 提供有限的最终 L1 包络。

## RG7. 原完整删除行如何接回空间核

固定一个原 eligible 行 (omega,V,x,j,y)，保留真实 reciprocal bad 集 R_y 和所有 terminal/历史资格。原 R183/R182 完整删除通量界（RF1–RF2）给

    I_y=∫_actualfar dt/t
          ∬H A_y(v)(k_t(y,v)−k_t(y,u))_+
                         Pi_y,t(dv)Pi_y,t(du)
       ≤nu(R_y)/e_g(y)≤1/(2K kappa).                  (RG19)

这里 H∈[0,1] 保留 reciprocal 槽，其他实际正切片可直接限制；证明用 A≤1 作正上界，不改原 A、alpha 或 Pi。原 R_y 作为整行固定来源集合，完整删除的每个跳已经由 RF 支付，不把某个 time slice 当新的概率行。

为核对容量常数，互反 bad 给 p_u>kappa p_y，FIRST 给 ∫p_u nu(du)≤q，所以 nu(R_y)≤q/(kappa p_y)。原 high 是 p_y e_g≥2Kq，于是得到 RG19。该行价没有将 bad-u 重叠转给 good-v；没有要求 w_g(y,v) 大，也没有 ν≤β。

先结束这一个原行的完整时间积分，保持原唯一 1_{j(x)=j}，才使用与 j 无关的 RG19 合并。这里不是 R186 固定参考上逐 j 应用核估计，所以不额外收 T_n 或 nT_n/4；它们也没有被“免费取消”，而是由完整原行恒等式取代。不得把这种顺序移给不同 j 的固定参考而宣称同样无费。

原 hard/source 因子只用一次16/3帽、外2Lambda只用一次，故在 s(x)≥1−h 的真实片上

    Raw_rec,J^+
       ≤[16Lambda/(3K kappa)]
          EΣ_V∫_Erec 1_{s(x)≥1−h} dx∫beta_V(dy) p_y
       ≤[16Lambda/(3K kappa)]
          EΣ_V∫beta_V(dy)
              ∫_(R^n)sup_{s∈[1−h,1],L∈[a,b]}P_(s,L)(x−y)dx.

正 Tonelli 与 RG1 得到 RG4。x 的实际选择与所有原 high/history 门只在已付行后作正放大；beta 来源本来固定，不产生 x-dependent 参考。不同原窗口可分别使用各自 a,b，ell≤log2 的统一常数控制该来源族；独立重跑同一来源的窗口仍真实求和，不能重复使用一次 W_A。

## RG8. 可覆盖 FL soft 补集的规范参数与原费用

令 c>0 为预先固定常数，取

    h_n=min{1/2, c√[log(n+1)/n]}.

因为 h_n≤1/2 且 h_n²≤c²log(n+1)/n，RG3 给完全显式的根阶多对数价格

    B_n(h_n,log2)
      ≤√n[5/2+7log2
               +24c log2√log(n+1)+3c² log2 log(n+1)].  (RG20)

于是整个原 reciprocal 正 J-share 的参数片 s≥1−h_n 都由 RG4–20 支付，包括任意极小 good overlap、旧 large B、low Fcal/high A/中央时钟的交集。它不是原 strictsoft 下门的后果，而是对实际 s 作的合法正分割。

与 R186 FL 采用同一预选界 sbar=1−h_n 时，先付本稿 s≥sbar，再在互补 s<sbar 上使用 FL 的 w_g≥delta_n 门，可保持不交（边界放本稿）。FL 的实际门为

    delta_n=K n A_n(sbar)² Tstar²/48,

仅在 delta_n≤1 时有相应根阶示例价；其精确 selector 和 clock 费用仍按原 FL 保留。本稿没有另加 B 截断或参数层数，也不通过调小 delta 而重复领来源价。若取 c²>9(p+7)，则在未触及 h_n=1/2 的足够大 n 范围，FL 已审 soft-gap 计算给其 polynomial-overlap 示例；这只是参数匹配，不能推所有实际 good 重叠满足该门。

可以保持更一般 h_n，使 RG3 在 n h_n=√n n^o(1)、n^(3/2)h_n²=√n n^o(1) 时仍为根阶次多项式来源价；实际取值和所有常数必须明列，不能把任意 s 尾都称为 RG20 范围。

## RG9. HG 接口与准确剩余核心

R186 HG 在 high-A reciprocal 行给同点 J/current 分离。若 c_v=(k_v+alpha J_v)/a_v，eta_eff=eta−c_v>0，0<eta<kappa²，则

    log[(J_v/p_v)/(J_u/p_u)]
       >log{ kappa²(1−eta)/[eta_eff(w_g(y,u)²−kappa²)] }.

该比值精确分为去跳连续差和 signed current 硬面差；必要分离本身尚无加权面层价格。RG16 现在给出一个具体的替代：在 s 靠近1的整个参数矩形中，硬面跳幅为1−s，其 soft 导数与 ac 混合项的**总** receiver variation 可付，且 h² 成本明确。它不把实际选择的每个 source 面层独立计价；而是先用完整删除行，再对整个 current 核取一次已付矩形包络。

这解释了为什么同样的办法不能直接延至一般 hard 中间层：当 h 是固定正常数，RG3 的 n^(3/2)h² 项只有 O(n^(3/2)) 来源上界。该项来自 regular scale score 的真实均值 −(1−s) 与 soft score 的乘积，以及 mixed surface score，不能随意删掉。若只丢绝对值、只看 E V 的抵消或不记 hard surface，就会错误声称一般 root 包络。

所以结合本轮付款后，尚未完成的主区域具体为 s<1−h_n 且 w_g(y,v)<delta_n（以及 FL 阈值无非空结论的窗口），再交原 low-Fcal/high-A/中央等尚未付款门。该区可继续用 HG 的共同 receiver 分离，但需要真正的 weighted face/远对预算或新的原流量机制；本稿没有用未知小矩代替这一步。非互反交通、其他 mother shares 及全局窗口组织仍按原总账保留。

## RG10. 核验范围与停止点

初步解析检查：n=1 时 mixed surface 价恰为1；h=0 恢复全软尺度包络；a=b 时 ell=0，仅保留 soft 参数变化 1+h√(nV_U)。边界检查：s=1 的原尺度 jump 为零，但其 s 导数非零，RG14保留；moving face 的两侧速度已经计完，不双计；strictsoft 资格不被误读为近1。扩大检查：全部 s∈[1/2,1]、任意 n、任意共同 selector 与实际 beta/nu 共享父来源均由显式矩和矩形 BV 控制，来源之间/坐标之间无新独立性。

独立数值可在有限 s 上核对 E U、E V、三个矩和 n=1 surface 公式，只是诊断，不替代上文 uniform 解析证明，也不认证新的 FULL 样本。一般结论的输入仅为已审原 RF 完整删除行及自证核预算；不借用随机滤过、Bellman 定理或未经核验的输运工具。

本稿在 RG4/RG20 的实际原 soft-tail 付款和 RG9 的准确 hard 剩余处停止；一般正 L1 的完整 n^(1/2+o(1)) 弱型目标仍未完成。
