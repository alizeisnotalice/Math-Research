# R187 独立预检与后审

仅写本文件，不Git/spawn/PDF、不运行旧数值、不改他人。已先读task_contract.md，以下第一阶段未读本轮作者稿。沿用R186已审原fixed-time资格与完整j/time费用，不重证其混核付款。一般根阶目标未闭合。

## 1. 精确演化的原范围与零分母

固定原omega,V,j,y，取原合法heavy时间区间内的紧截断，用r=logt。ν有限，w连续且a.e.满足dw/dr=−kw，k(r,v)=Σ1_{A_i(v)<e^r}为整数0到n；原有限树Z仅有限个真实删除原子，跳间恒定。e>0时Π=1_Zwν/e，m=Πk；e0或原定义域外取零核，不在零行除法。开放端用原内侧极限与非负积分极限，不凭端点逐点导数遗漏阈值或删除。

每个source的k随r单调BV，总增长≤n，但一般连续ν汇总后的阈值forcing未必只有离散原子。不能把原有限树删除与连续source阈值混为同一有限菜单。若扩展到任意连续删源的nested支持，须另加其连续loss/forcing；本预检不把仅列删除跳之式推广至该扩展。

## 2. 独推均值方程及所有事件费用

无删除且避开source阈值时，固定source权重演化给

    dm/dr=−Var_Π(k)。

一般阈值以正测度

    Θ(dr)=∫_Z_before w(r,v) d_r k(r,v)ν(dv)

计入，包含连续与原子BV。权重跨阈值连续，阈值原子先使用原删除前支持，e不因score更新改变。若同一r还有删除，先形成阈值更新后/未删除中间态(θ)，再用该score删除；这是左右极限账，原dt交通在孤立阈值取值不受改变。

删前e_θ、删质量d、删源均值m_H，删后e_+=e_θ−d>0时有

    m_+−m_θ = d/(e_θ−d)(m_θ−m_H)
             = (d/e_θ)(m_+−m_H)。

此跳可正可负，正部≤n d/e_θ。d0时不定义无质量m_H，跳为0；删除后e0则原有效区间终止或零行，不能把上述分母继续用到0。阈值forcing和删除跳按实际中间态同时处理，避免双算同一事件。

因此完整积分恒等式为

    ∫Var_Π(k)dr = m_start−m_end +∫Θ/e +Σ(m_+−m_θ)。

闭/开端的起止均值与事件是否纳入应一并约定。有效紧区间e_min>0保证一般ν的forcing有限（可用n||ν||/e_min作合法但未付粗界）。由此可合法上放为

    ∫Var≤n+∫Θ/e+nΣ d/e_θ。

Σd/e_θ以及normalized threshold forcing仍是实际费用，不是自动O(1)或O(n)的来源预算。不能无删除重证后覆盖原完整支，也不能以source每坐标只跨一次就删掉随时间变化的e分母。

## 3. 原正flux与累计variance的可用关系

同一实际Π的两槽令q_flux=Π⊗Π(k_v−k_u)_+。对任意[0,n] law有

    q_flux≤n/4,       q_flux≤√[Var_Π(k)/2]。

此外原score为整数，|k_v−k_u|≤(k_v−k_u)²，所以

    q_flux=(1/2)E|k_v−k_u|≤Var_Π(k)。

该式只用原两槽product，不假来源坐标独立。令完整β/j/time聚合variance为Vagg，原time参考总质量Pagg≤Tstar Wβ；R186实际Γ+质量于是满足

    ||Γ+||_aggregate≤min{nTstar Wβ/4, Vagg,
                              √[Tstar Wβ·Vagg/2]}。

Wβ=0时全零先分派，无归一化除法。若另证明Vagg≤C nWβ，可条件改善旧O(n²)质量；但在端点、Θ/e、删除费用的真实聚合未证明之前，不将这一条件式登记为新的无条件付款。不同window重用及j聚合仍按R186收费，不能再次抹去Tstar。

## 4. HG必要分离升级接收付款的最低义务

R186 HG的actual same-alpha ηeff、J/current log间隔、连续位移及signed current硬面差均是同一原x,y,u,v的必要条件。若要据此付ε∫q或根阶W_A，须在原fixedΓ+下控制其实际receiver密度，而不是只证明source距离大或硬面数量非零。

固定L区间差支持长度≤2|u_i−v_i|不能免费用于L(x)。取全部a≤L≤b的正包络已有非消失尺度带宽b−a；保留同alpha/highA的原密度还含p_y、A和其他坐标。任何面层/远对estimate必须明确原selector、source归一、δ+参考、j/time/window与负信用，不把裸长度或核位移lemma当完整weighted列付款。终端重叠差也须保留初始weight比与整段signed时钟，不可认成actualfar可用消散。

## 5. 第一阶段停止点

已形成无作者结论依赖的精确演化接口及条件Γ+改善。首个尚未付的量是完整normalized threshold forcing与删除正跳的source聚合；另一目标的首个缺口是FIRST-selected current硬面/远对的真实weighted receiver列。等待作者准确命题先筛后读，不自行扩反例或数值。


## 6. 软尾双参数BV准确候选的作者前独筛

对q=1−s、s∈[1−h,1]、h≤1/2，f_s=q hcore+sφ。令U=(φ−hcore)/f_s，V=−1−r sφ′/f_s（仅scale regular部分），则EU=0、EV=−q。父级精确常数为

    c0=φ(.5), τ=∫hard φ, Lφ=2/(1−e^(−1)),
    I=2(1/c0−1), J=2+(13/6)Lφ²,
    K1=2(τ−c0)/c0。

EU²≤2∫(φ−hcore)²/φ≤I。|sφ′/f|≤Lφ及Ef r²≤13/12给EV²≤J。∂sV=−rφ′hcore/f²，积分inside部分并用f≥s c0≥c0/2、∫inside−rφ′=τ−c0，得E|∂sV|≤K1。

乘积核regular mixed derivative为P[(ΣU)(ΣV)+Σ∂sV]，L1至多(√IJ+K1)n+√I n^(3/2)q。moving hardface的scale测度每坐标两面各q/2、总q；其s导为[-1+qΣ_other U]乘其余概率核，故TV至多n+√I n^(3/2)q。此signed face项不可丢。合并后为(√IJ+K1+1)n+2√I n^(3/2)q。

先对signed ∂sP的真实scale-BV取sup_L，再积分s；以全soft P_1,L为基项，l=log(b/a)≤log2，得到

    ∫sup_(1−h≤s≤1,a≤L≤b)P_s,L
      ≤B_n(h)=1+l√(nJ)+h√(nI)
                  +l[(√IJ+K1+1)nh+√I n^(3/2)h²]。

这里l是窗口log，不能混同原ell_n=1+logn。h0为全softscale基项，s=1时q0面项消失，s=.5允许端点。矩形路径variation需保真实硬跳和共同代表元；成稿后重点核这一合法性，不能把distribution导数误作每点光滑导数。

原完整删除RF行界≤1/(2Kκ)须先用于每个actualrow并保uniquej，再用上面的current核正包络对真实x及固定β Tonelli。这样整个指定原reciprocal J-share softtail（不附wg下门）可付(16Λ/(3Kκ))B_n(h)Wβ≤同系数WA。allmother未由此覆盖。h≈√(log(n+1)/n)时得到√n log(n+1)来源价；这是显式选参数分割，不是从原strictsoft下门假定near1。

## 7. score准确候选与父soft/hard整合窄筛

Sol的right-score k+=Σ1_{Ai≤t}与原strict score在dt积分等价。主方程、整数flux三重min及聚合C/V候选与§2–3一致。已要求事件端点写清：若起始均值为τ右态，则Θ与删除事件从(τ,T]计，开放T用T−并排除T事件，不能把含τ原子的Θ(I)与右起态双计。

本独审另外窄读R117 research.zip::proof.md lines155–179,183–200：JG14的born原硬ν满足ν(A)≤h(A)，无需ν≤β；JG15/16给Σ_jΣd/e_before≤Bdel_n，其中

    Bdel_n=[(1−γ^(−n/2))^(−1)+√n(1−γ^(−3n/2))^(−1)]/ell_n。

故删除正均值强迫确可付n Bdel_n Wβ，initial可付n Nstar Wβ；normalized threshold Θ_global仍未付，不能把条件variance改善认证为已降低无条件canonical flux预算。

parent_soft_tail_integration.md已全文实读，准确候选窄审通过：h_n=min(.5,c√(log(n+1)/n))下B_n=O_c(√n log(n+1))，soft边界归softpart，hardpart s<1−h_n再用R186 overlap支，父source预算实际用两次且两常数明列。cap inactive时δ_n≤(Ke²/48)n(n+1)^(6−c²/9)，c²>63才有此粗decay，c8仅n^(−1/9)；δ>1的有限维未覆盖与hardtinywg、其他mother仍保留。本段待作者全文后绑定，不用数值猜阶。


## 8. 作者全文后审：score与真正软尾付款

独立筛查后已全文读score_evolution_budget.md SE1–8，通过，无修项。right-start排τ事件、openT用T−、一般ν连续/原子Θ、threshold→delete中间态、SE3删除符号、整数/CS三重min、原born删除nBdel_n来源价、sup窗/逐窗聚合全部正确。Tsource明确未付，SE11–12只是conditional接口，未声称无条件canonical reference已改善。

已全文读residual_receiver_geometry.md RG1–10，通过。精确c0/τ矩与log斜率、U零均值、V均值−(1−s)、真实ac mixed及signed moving face测度、每面q/2与mixed n1恰1、相交面接收零集与closed right-entry代表元、真矩形sup/可测有理逼近均正确。Ccross≤2有直接证明τ≤φ(0)=2∫0^.5w≤2∫0^1w=2c0，故精确B可支配于24/3粗常数，不从另一个ET上界误推Ccross。RG20的5/2基项来自1+3h√n≤(5/2)√n，h_n及h²根阶log费用齐全。

独审已窄读R182 frozen global_column_geometry.md RF1–4：RF2完整删除界覆盖全部原β外槽互反J-share，使用同一current容量与high，R_y整行固定并容许later-deleted，A≤1只作正上放。故RG7先结束原row、再合法uniquej、再固定β核sup，确实支付整个softtail，无wg下门与无新source归一。全局EΣV、一次hard16/3及外2Λ、跨窗口重用皆保留。唯一书面scope修项现已落实：RG7第一显示积分保1_{s(x)≥1−h}，随后才套soft-only sup，不能先删该门再声称硬参数也受控。

## 9. 整合与数值静态审查

proof.tex.txt已全文实读，矩形BV/surface、原RF系数16Λ/(3Kκ)、EΣ真实source/receiver顺序、hard/soft不交分割及c²>63/coarse c8仅n^(−1/9)均与作者证明一致，未认证allmother或hardtinywg。parent_soft_tail_integration.md的条件范围与费用另已全文通过。

soft_bv_checks.py与numerical_review.md已全文静态审过，未运行。6个40/60dps实际一维矩、30个产品上界公式及15个selector公式行（8个h≤.5有效）与定义一致。φ/E3/正轴φ′、EU²核心+真实∞tail、V负均值/二阶矩/方差区分、∂sV核心独查、真实phi质量与13/12矩、n1 surface1及log(n+1)无clip菜单均正确。产品/selector表明示为analytic upper公式评价而非实际多维norm；mpmath残差/双精度一致性非interval，有限代数不认证FIRST/history/FULL或一般维数阶。依赖只哈希.py，assert失败非零退出。最终文件绑定等待父最后回执后一次写入，不自行重跑。


## 10. 最终窄审、哈希与冻结

最终tex新增SE演化段已实读，正确保留非原子Θ/阈值后删除及未获全局forcing价；report/reproduce/parent_replay已实读，明确主付款仅整个原reciprocal正J-share softtail，score路线不是第二付款，hardtinywg/其他mother仍未闭合。RG7 soft指示窄修已核落实。父soft-BV实际重放回执exit0、完整JSON逐字节一致；本独审未运行。

score_event_checks.py与numerical_review.md最终新增独立回执已静态实读：同一有限质量与w、right-start、所有threshold multiplicity及threshold→delete中间态、闭末端、精确片段均值差与50dps独立variance积分/正负删除均一致。独立numeric reviewer一次隔离重放完整JSON相等；这不认证原born森林、FIRST/history、一般forcing价或有向误差。未重复数值、未编译PDF。

最终结论：RG的双参数BV与整个softtail真实来源付款通过，显式常数与全部moving面/selector/source费用通过；SE完整演化及已收费删除项通过，阈值forcing改善仅conditional。父soft/hard拼接与主稿通过，无一般闭合声明。下表实际计算最终SHA256，不含本文件、未来manifest/inventory或归档验证。审计冻结后停止，不自行扩展。

| 文件 | SHA256 |
|---|---|
| numerical_review.md | `c49eb475704e0ca08058ccd5ca691270abfd7d322e4dd85548647efe8891bc47` |
| parent_replay.json | `7d088f9e00f9ef4dd03c7008639d07cdcb417fc35e9458e3b436b48d99fe59d4` |
| parent_soft_tail_integration.md | `643ca089a96af7eb87d42066ebc074e57f69d9a906373370a8374a2d3f63116b` |
| proof.tex.txt | `2c9b67590bc85645bf75259024fcd822f1bec5c3bfccaa2e830ee8cd2fad83b5` |
| report.md | `a712d7d950d0b2dc244934b9eac07c995a8d6d7b31aadac60378de3216e0609f` |
| reproduce.py | `ddb0ddf4f6c8d5d04cf4522da617f28815a2b098c68a2385a8efcb9ce781cc32` |
| residual_receiver_geometry.md | `ce20fa2e53e2cceb8c6131a9501432b6e3eca593b4d75a0671c70d7e2d6da161` |
| score_event_checks.json | `e4f36fdeac8325e76ed9d24ccfaa30054c29ce69ee755069af565698cac4920d` |
| score_event_checks.py | `8faaafa343f023dcd87d7bfcd8e5f87df067000d2a74f5cdea3fa02db14c2da0` |
| score_evolution_budget.md | `a64721ec48bb6bbc0d9af2e4e2070eca9a92717e1cb0e5dcefa6505d1df0f9a9` |
| soft_bv_checks.json | `0b06c50b48b2a15370a4c2162f6d5e595309c1c8121223f11475c65f9c8ca7fa` |
| soft_bv_checks.py | `103a8584c094df4893cd32a81df2295d867ac5e4a795af87cf7b1779d48b0384` |
| task_contract.md | `0cfd24f7ff70e78b3f3f5adc9d49a2f7208b780ea6f9218c8bb213ee888602f7` |
