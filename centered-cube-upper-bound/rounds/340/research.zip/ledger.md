# 第340轮完整总账与判定边界

本轮目标是支付第302轮 B_H 后续 hard 槽中更大的原积分分支。一般一致弱型根阶上界未闭合。采用 N04 的逐项费用管理原则；不声称该技能提供本课题缺少的几何定理。

在 core.md 的全部原始假设下，W_beta=∫f，ν≤f dx，W_nu=ν(R^n)，Xq=∫E q_u du≤X=λ|E|。承接原入口（不在本轮重新认证历史所有归约）：

\[
T_*\le8\lambda H W_\beta+2d_{\rm eff}A_nW_\nu/H+2B_H,
\quad A_n=1+n\log(b/a),\quad H>0.
\]

令 ε=119/3072，δ=ε，η=exp(-√n)，L=nb/ε。G_growthbad 是原 G_out 完整积分加上大端门 m_u<η∫Q_(2L)(u)f；原 J、来源、实际接收测度、质量比、高过去和中心距离门均不改变。

\[
C_{\varepsilon,n}=\frac\lambda{q_-}
\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}\varepsilon+1+\sqrt n\right],
\]
\[
B_H\le G_{\rm growthbad}+3\varepsilon X_q+
[C_{\varepsilon,n}+1+\sqrt n+\log(4/3)]W_\beta.
\]

因此入口为
\[
T_*\le8\lambda HW_\beta+2d_{\rm eff}A_nW_\nu/H
+2G_{\rm growthbad}+6\varepsilon X_q
+2[C_{\varepsilon,n}+1+\sqrt n+\log(4/3)]W_\beta.
\]

历史外乘 Λ=128/119 给出 6Λε=1/4；若与历史 CZ 1/256 同属已认证的同一 X 总账，合计65/256，余191/256尚未分配。此为替换339槽，而不是每一轮再累加1/4。没有免费求和所有叶片、物理尺度或来源参数的许可；其他项未付款，不能由剩余吸收空间宣布全局成立。

未付项完整保留：

1. G_growthbad 的原始正交通，没有根阶预算。
2. 一般软密集 C_H−S_H、越阈 I_H、hard 合同之外质量可比重尾联合交通及未嵌入的其他 hard 项。
3. 宽距离、低 pe、极端尺度比及全部阈值补集，保留高度折扣与逆尺度费用。
4. 历史初始 I_time、删除跳跃 J_time、未来被删来源 D_time 独立留账；物理半径 b 的原子不是这些历史时间原子。
5. 后缀 P/Phi_next 负信用只使用一次；原 H、层数、尺度、来源、外积分和极限费用均未自动结清。

没有充分依据断言只剩常数与对数优化。后续主攻仍是 B_H 的全局来源增长坏集，而不是用边界体积推断任意来源的边界质量。重来源列与覆盖节省联合结算仍为待证方向。
