# R340 — One common shifted grid pays the local-growth branch

## Statement and original integral

Assume the unchanged R338/R339 hard contract: n≥1, f≥0 in L¹(Rⁿ), W=∫f>0; E is a measurable finite-volume receiver set with actual Lebesgue measure du; a≤R_u≤b≤2a is measurable; Q_u is the cube centered at u of side R_u; m_u=∫Q_u f=q_u R_uⁿ with q_-≤q_u≤λ and q_-=3λ/4. Set dμ(u)=du/m_u, c_u(y)=1_Q_u(y), E_r={R_u≤r}, J_y(r)=∫E_r c_u(y)dμ(u), and

    ell=b^(-n)δ_b+n r^(-n-1)dr on [a,b],
    X_q=∫E q_u du,    Z_y(t-)=∫E c_v(y)1_{m_v<t}dμ(v).

Keep K=e^{√n}, h=(1+√n)/(εq_-), α=(1+√n)^(1/n), and the exact original positive residual

    G_out = ∫ell(dr)∫f(y) 1_{J_y(r)≥H}/J_y(r)
       ×∬_{E_r²} c_u(y)c_v(y)(m_u-m_v)
          1_{m_u>K m_v}1_{Z_y(m_u/K-)>h}
          1_{||u-v||∞>αR_u/2} dμ(u)dμ(v)dy.            (1)

Zero-J rows have value zero. For measurable A⊂E, G_out(A) denotes only the additional large-endpoint gate u∈A in (1). All small endpoints, source variables, past gates, physical prefixes, J and ell remain original.

Fix 0<δ<1 and 0<η≤1, and define the deterministic geometric length and actual source mass

    L=nb/δ,      M_L(u)=∫_{Q_{2L}(u)} f,
    A={u∈E:m_u≥ηM_L(u)},      A_bad=E\A.             (2)

Here Q_{2L}(u) has side 2L. No original cap, q condition, or averaging selector is asserted at this enlarged scale. It is used solely to construct source labels.

The constructive receipt is

    G_out(A) ≤ δ X_q(A)+[1+log(λ/(ηq_-))]W.           (3)

Consequently the exact original residual satisfies

    G_out ≤ G_out(A_bad)+δ X_q
                 +[1+log(λ/(ηq_-))]W.               (4)

The growth condition is a genuine checkable source condition, not an assumption that a favorable clustering exists. The construction below works for every f and actual receiver field and pays all endpoints satisfying (2). It does not prove that A_bad has small traffic.

## A receiverwise domination retaining the original clock

For every measurable B⊂E,

    G_out(B)≤X_q(B).                                  (5)

Indeed on the original far-mass gate the integrand is nonnegative and m_u-m_v≤m_u. After this bound, the gated small-endpoint capture integral is at most J_y(r). Thus the source row factor divided by the original J is at most m_u. Keeping u∈B∩E_r and then integrating the actual source gives

    G_out(B) ≤ ∫ell(dr)∫_{B∩E_r}du∫f(y)c_u(y)dy
             =∫B m_u ell([R_u,b])du
             =∫B m_u R_u^(-n)du=X_q(B).

The inclusive tail is exactly R_u^(-n), including R_u=a or b and every selector atom. This argument neither estimates source mass by boundary volume nor changes J.

## One globally selected shift and exact source labels

Let τ be uniform on [0,L)ⁿ and let

    S_j^τ=τ+Lj+[0,L)ⁿ,  j∈Zⁿ,
    W_j^τ=∫_{S_j^τ}f.

These countably many actual source cells partition Rⁿ up to their null faces; Σ_jW_j^τ=W. Assign each receiver center u to its unique cell j_τ(u). Say u crosses when its cube is not contained, up to Lebesgue-null faces, in that center cell. Let C_τ be the crossing endpoints in A.

For fixed u, in each coordinate the proportion of shifts that contain the entire interval of length R_u in its center cell is 1-R_u/L. Since R_u≤b<L and the shift coordinates are independent,

    P_τ(u∈C_τ)=1-(1-R_u/L)ⁿ≤nR_u/L≤δ.              (6)

The exact formula includes the fact that τ-boundary coincidences have probability zero. Therefore Tonelli gives

    E_τ X_q(C_τ)≤δX_q(A).

There exists one common shift τ_* with

    X_q(C_{τ_*})≤δX_q(A).                            (7)

Existence is all that is required; there is no optimization of a separate shift for each cell, source, radius or receiver. An integrable real random variable has a value no larger than its mean, so no extra slack is needed in (7). The assignment is fixed before evaluating all traffic at this chosen shift.

Measurability is explicit: j_τ(u) is the coordinatewise floor of (u-τ)/L, the crossing predicate consists of measurable coordinate inequalities involving R_u, and (τ,u)↦q_u1_{C_τ}(u) is measurable. The function M_L is measurable by Tonelli (equivalently convolution); likewise W_j^τ is measurable in τ. Every fixed shift has Lebesgue-null cell faces, hence also f-null faces. This suffices for all receiver/source almost-everywhere statements. Countability and nonnegativity handle unbounded E and infinitely many cells.

Freeze τ_* and abbreviate S_j,W_j. Partition A\C_{τ_*} into the receivers A_j assigned to cell j. For u∈A_j,

    ∫_{Q_u\S_j}f=0,
    m_u≤W_j≤M_L(u),    ηW_j≤m_u.                    (8)

The middle inequality follows because a side-L cell containing u lies in the cube of side 2L centered at u. Thus these are true source-isolated endpoints, with their unchanged full-f masses and q. Isolation is needed only for the large endpoints in A_j; no restriction is imposed on the small receivers v. Zero-mass cells have no such endpoints since m_u≥q_-aⁿ>0.

## Per-cell payment and no source duplication

For W_j>0 define

    A_j^rad=max(a,(ηW_j/λ)^(1/n)),
    B_j^rad=min(b,(W_j/q_-)^(1/n)).

If A_j^rad>B_j^rad the receiver set A_j is empty. Otherwise (8) puts every R_u for u∈A_j in this interval. After the same small-endpoint row domination as in (5), the remaining large receiver volume at source y is

    V_{j,y}(r)=|{u∈A_j:R_u≤r, y∈Q_u}|.

It vanishes for r<A_j^rad; for A_j^rad≤r<B_j^rad it is at most rⁿ; for r≥B_j^rad it is at most (B_j^rad)ⁿ. These are actual receiver-center volume bounds, since y∈Q_u implies ||u-y||∞≤R_u/2. They put no density restriction on f.

By (8), the source integral is supported in S_j. Hence

    G_out(A_j)≤∫_{S_j}f(y)∫ell(dr)V_{j,y}(r)dy
       ≤[1+n log(B_j^rad/A_j^rad)]W_j
       ≤[1+log(λ/(ηq_-))]W_j.                       (9)

In the second line, the continuous contribution between the two radii is n log(B/A), and the complete original tail contributes Bⁿell([B,b])=1. No atom is inserted at B; the original b-atom and continuous tail are retained. The formula works also when A=B.

Sum (9) over the disjoint source cells, using ΣW_j=W exactly. Add the crossing payment (5),(7). This proves (3). Equivalently, no shift selection is needed to obtain the deterministic inequality: for every shift, the noncrossing part is bounded by the same constant times W; average the identity G_out(A)=G_out(A\C_τ)+G_out(C_τ) and use (5),(6). The selected-shift construction above additionally supplies one concrete common source partition with the claimed total crossing cost. Every large endpoint in A is counted exactly once, while the original small endpoints and global denominators remain intact throughout. There is no repeated charge for source mass across cells.

## Full slot, improvement, and the unpaid complement

Take η=e^{-√n}. Equation (4) becomes

    G_out≤G_growthbad+δX_q+[1+√n+log(4/3)]W,          (10)

where G_growthbad is exactly (1) with the additional gate

    m_u<e^{-√n} f(Q_{2nb/δ}(u)).                      (11)

Since M_L(u)≤W, every old global-heavy endpoint m_u≥ηW belongs to A. Thus A_bad⊂{m_u<ηW}. This is a structural strengthening of R339's global-mass criterion: local separated source clusters can meet (2) even when their cubes are globally light. The inclusion can be strict. No claim is made that it must be strict for every field or that the newly covered set always carries positive G_out.

Use the R338 complete slot directly:

    B_H(f,ν)≤G_out+2εX_q+C_{ε,n}W,
    C_{ε,n}=(λ/q_-)[(2+3√n+2e^{-√n})/ε+1+√n].

The resulting replacement ledger is

    B_H(f,ν)≤G_growthbad+(2ε+δ)X_q
       +[C_{ε,n}+1+√n+log(4/3)]W.                   (12)

This replaces the R339 heavy-source payment; that payment must not be added again. All original gates and clocks survive in G_growthbad, and every pre-existing entrance, soft, history, and outer multiplier remains due. If this slot has outer coefficient M, all terms in (12), including δX_q, are multiplied by M; δ must be chosen accordingly for the intended absorption budget. Its geometric price is the explicit label scale L=nb/δ.

Setting δ=ε (when 0<ε<1) makes the X_q coefficient in (12) equal to 3ε. This is a slot statement; any further entrance coefficient is accounted for in the parent ledger.

No cap at scale 2L is introduced. In particular the possibly large growth M_L/m is the exact remaining obstruction to this construction. For arbitrary f this growthbad term is not yet paid, so (12) is a constructive partial root-order receipt, not the general root-order theorem.

## Verification status

The proof above is analytic. A separate exact-rational script checks the probability bound and a genuine positive-volume receiver/grid-shift fixture; its run and exact scope are recorded below. Such checks verify the construction mechanics, not a general bound on G_growthbad or positive G_out in the diagnostic fixture.

`/tmp/r340_core_checks.py` was actually run with Python standard-library Fraction arithmetic and passed 457 check units: 384 exact probability-bound parameter cases (n=1,...,32, three δ values, four R/b values); 7 continuous receiver-integral checks; and 66 source-cell mass/containment cases. The positive-volume diagnostic has f equal to the indicator of [0,4]∪[21,25]∪[42,46], E the union of the middle length-two intervals, R=1, a=1/2, b=1, λ=1, δ=η=1/4. Its exact W=12, X_q=6, averaged crossing volume=3/2=δX_q, and one common shift τ=1/2 has crossing volume 1. The crossing integral is evaluated exactly from its complete piecewise-linear breakpoints, not from sampling receiver centers. The separate 66 cell checks use representatives of constant-cell/crossing receiver intervals and are finite diagnostic checks, not substitutes for the analytic all-u proof. All fixture endpoints are locally growth-good and globally light, verifying that the inclusion of endpoint sets can be strict. The script does not evaluate G_out and supplies no claim of nonzero original residual traffic for this one-dimensional diagnostic.
