# R340 — feasible near-isolation source labels

This bounded experiment tests feasible source labels on the existing actual-cube finite receiver quadratures. It does not implement a receiver dx field, the original full selector history, or a nonempty root high-past branch. It does not numerically certify the continuum good-label theorem.

Reproduce with standard-library Python; no solver or old /tmp data is needed:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r340_numeric.py
```

The script writes `r340_numeric_result.json` beside itself. R334 exact repaired source masses are embedded, with the source snapshot hash recorded. No q, receiver weight, cube, or captured source mass is reset.

## Registered models and source partitions

The complete source cube Q4 is partitioned by every receiver cube face; this gives 5/64/900 positive-volume boxes in n=1/2/3, merged into 4/10/19 complete incidence signatures, including zero. Each box is fully inside or outside every actual cube, checked by exact endpoints. Receivers, sides R in [1,2], and quadrature weights are stored explicitly in the JSON. The three stages use (i) uniform f=1_Q4; (ii) R334 H0 repaired ratio source; (iii) the existing nested-signature minimum-mass face endpoint. In stages ii/iii, assign each signature's mass uniformly across its actual source boxes. This is compact positive-L1 f, with beta=nu=f. All three stages satisfy actual m_i=integral_QRi f=R_i^n, so q_i=lambda=1 remains exact. Full W is 4,16,64 in stage i; about 1.76038,4,8 in ii; and 1.5,4,8 in iii. Xq=sum(receiver weights) is 2/5,1/2,1/2.

Enumerate every partition of the receivers into groups (2/15/52 partitions). Each receiver has its group's unique label. For each partition, test every priority ordering assigning a signature wholly to the first group with a capturing receiver; additionally test two soft assignments proportional to group capture counts or group occupation weights. Source outside all receiver cubes is unassigned. This yields 7/105/645 candidate partitions-and-rules per dimension, repeated across the three actual sources. It is a bounded candidate family, not an optimization over every possible theta.

For every candidate, theta is nonnegative and its sum over labels is at most one on every complete source cell. For each chosen certificate compute W_j=integral theta_j f and C_i=integral_QRi theta_label(i) f exactly. A receiver is good precisely when

`C_i >= (1-delta)m_i` and `m_i >= eta W_label(i)`.

Parameters are delta in {1/16,1/4,1/2} and eta in {1/8,1/2,1}. Selected certificates include exact theta, group, label mass, capture, and good-receiver data. A second candidate selection prioritizes massgap coverage rather than Xq coverage; its defining rule reconstructs theta uniquely.

## Actual results and limitations

Two fresh process runs passed **19,665 exact rational checks**, comprising label-stage counts 6,507 / 6,493 / 6,518 and 147 tiny-grid checks. There are also 81 ordinary floating-point log evaluations displaying the formal fee, separate from the exact counts. No solver status is used. The 19,518 count includes geometric endpoint checks, source mean equations, partition budgets, unique labels, and selected good conditions; it is not a count of distinct inputs.

At delta=1/16 and eta=1/2:

| Source | n1 covered Xq | n2 covered Xq | n3 covered Xq |
|---|---:|---:|---:|
| Uniform baseline |1|2/5|2/5|
| Repaired ratio source |1|3/5|2/5|
| Minimum-mass face |1|3/5|2/5|

The entries are fractions of Xq. At eta=1/8, delta=1/16, coverage increases to 1,1,4/5 in the baseline and repaired-source stages, and 1,1,1 on the minimum face. Relaxing delta to 1/2 generally raises coverage further; it does not establish the small-delta regime needed for absorption.

The unassigned expense diagnostic is the exact original reverse-minus-favorable massgap, with actual full-source integration, alpha=1 center-outside restriction, strict K=1 mass ordering, original finite scale layers including the terminal atom, and H=0 or 1/8. It is **not** G_{K,>h} at the original root/high-past threshold. The n1 diagnostic is zero. At n2/n3 it is nonzero and, at delta=1/16, eta=1/2, all six source variants have zero unassigned diagnostic massgap, despite 40–60% Xq coverage. The uncaptured diagnostic is not the entire remaining original BH. No sampled source points replace source integration.

For example, at H=0 the n2/n3 total diagnostic is 0.00814725/0.00436431 for uniform f, 0.03033209/0.01687076 for repaired f, and 0.03265638/0.01577254 on the minimum face. Its concentration on a few larger-side receiver endpoints explains why covering only part of Xq can cover it all; this is not evidence that a genuinely high-past branch has the same structure.

The choice of objective matters. On the n3 minimum face, delta=1/4 and eta=1/2, maximizing Xq coverage chooses 3/5 coverage while leaving the entire diagnostic massgap unassigned. Prioritizing gap coverage instead chooses 2/5 coverage and leaves zero. Both are feasible exact source partitions. Therefore coverage fraction alone is an inadequate selection criterion for a future label construction.

Finally, displaying the proposed formal good fee

`delta Xq + [1+log(1/(eta(1-delta)qminus))] W`, with qminus=3/4,

reveals a substantial limitation: at delta=1/16, eta=1/2, it is about 16.43 Xq and 32.79 Xq for the n2/n3 repaired sources (65.51 and 261.87 Xq for uniform sources). This is larger than the trivial original first-moment scale, even before charging unassigned receivers. Thus this experiment supplies nontrivial feasible labels and an objective-selection lesson, but no improved total budget. A useful next construction must simultaneously control the unassigned hard branch and the source-price coefficient. No dimension exponent or general attainability claim is inferred from n<=3.

## Small constructive-grid sanity check

A separate 147-check appendix, not another label search, verifies `1-(1-R/L)^n <= nR/L <= delta` exactly for n=1,2,3,16, R=1,3/2,2, delta=1/16,1/4,1/2, L=nb/delta with b=2 (36 cases). This is the exact product crossing probability for a uniform common grid shift. It does not test a chosen shift's traffic or prove its existence numerically.

For the actual one-dimensional f=1_Q4, 60 rational center/phase/radius cases explicitly construct the cell containing the center on a grid of side L=8. All cells lie in Q_(2L)(u). On the 51 noncrossing cases, exact interval intersections verify `m=f(Q_R(u)) <= W_cell <= M=f(Q_(2L)(u))`; 9 crossing cases are kept separate, and zero-capture cases are retained. This supports the elementary geometry of the parent's constructive random-grid route. It does not certify growth-good traffic or replace that route's analytic proof.
