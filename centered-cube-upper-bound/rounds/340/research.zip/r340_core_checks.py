"""Exact rational diagnostics for R340; no simulation of G_out."""
from fractions import Fraction as F
from math import floor

counts = {"probability": 0, "receiver_integral": 0, "cell_mass": 0}
for n in range(1, 33):
    for delta in (F(1, 2), F(1, 4), F(1, 10)):
        b = F(1)
        L = n*b/delta
        for R in (F(1, 2), F(2, 3), F(3, 4), F(1)):
            crossing = 1-(1-R/L)**n
            assert 0 <= crossing <= n*R/L <= delta
            counts["probability"] += 1

# f is the indicator of three separated length-four intervals.
# E is the union of their middle length-two intervals, R=1, q=m=1.
# All integrals below are over genuine continuous receiver intervals.
source = [(F(s), F(s+4)) for s in (0, 21, 42)]
receivers = [(a+1, b-1) for a,b in source]
L, R, delta, eta = F(4), F(1), F(1,4), F(1,4)
W = sum(b-a for a,b in source)
Xq = sum(b-a for a,b in receivers)
def overlap(a,b,c,d):
    return max(F(0), min(b,d)-max(a,c))
def source_mass(a,b):
    return sum(overlap(a,b,c,d) for c,d in source)
def crossing_volume(tau):
    total = F(0)
    for a,b in receivers:
        for k in range(floor((a-tau)/L)-1, floor((b-tau)/L)+2):
            boundary=tau+k*L
            total += overlap(a,b,boundary-R/2,boundary+R/2)
    return total

# These are all slope-change points of the exact continuous crossing volume.
breaks={F(0),L}
for a,b in receivers:
    for endpoint in (a,b):
        for sign in (-1,1):
            breaks.add((endpoint+sign*R/2) % L)
breaks=sorted(breaks)
integral=F(0)
for a,b in zip(breaks,breaks[1:]):
    fa,fb=crossing_volume(a),crossing_volume(b)
    assert crossing_volume((a+b)/2)==(fa+fb)/2
    integral+=(b-a)*(fa+fb)/2
    counts["receiver_integral"]+=1
assert integral/L==R/L*Xq==delta*Xq
counts["receiver_integral"]+=1
selected=min(breaks[:-1],key=crossing_volume)
assert crossing_volume(selected)<=delta*Xq
counts["receiver_integral"]+=1

# Check every positive-length receiver subinterval on which center cell and
# crossing status are fixed, at every shift breakpoint and interval midpoint.
shifts=sorted(set(breaks[:-1]+[(a+b)/2 for a,b in zip(breaks,breaks[1:])]))
for tau in shifts:
    for a,b in receivers:
        cuts={a,b}
        for k in range(floor((a-tau)/L)-1,floor((b-tau)/L)+2):
            boundary=tau+k*L
            for t in (boundary-R/2,boundary,boundary+R/2):
                if a<t<b:
                    cuts.add(t)
        cuts=sorted(cuts)
        for left,right in zip(cuts,cuts[1:]):
            u=(left+right)/2
            cell_left=tau+floor((u-tau)/L)*L
            cell_right=cell_left+L
            m=source_mass(u-R/2,u+R/2)
            local=source_mass(u-L,u+L)
            cell=source_mass(cell_left,cell_right)
            assert m==1 and local==4
            assert m>=eta*local and m<eta*W
            assert cell<=local
            noncross=(cell_left<=u-R/2 and u+R/2<=cell_right)
            if noncross:
                captured_in_cell=source_mass(max(u-R/2,cell_left),min(u+R/2,cell_right))
                assert captured_in_cell==m
                assert eta*cell<=m<=cell
            counts["cell_mass"]+=1
print("PASS",counts,"total",sum(counts.values()))
print("continuous fixture: W=",W,"Xq=",Xq,"average_cross=",integral/L,
      "selected_shift=",selected,"selected_cross=",crossing_volume(selected))
print("All fixture receivers are growth-good and globally light; G_out is not evaluated.")
