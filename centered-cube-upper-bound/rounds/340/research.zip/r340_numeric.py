#!/usr/bin/env python3
"""Exact feasible source-label certificates; finite actual-cube receiver quadrature."""
from fractions import Fraction as F
from itertools import product,permutations
from collections import Counter
from pathlib import Path
import json,math,hashlib
BASE=Path(__file__).resolve().parent
CHECK=Counter()
def ck(name,condition):
 CHECK[name]+=1
 assert condition,name

def fixtures():
 return [(1,[((F(-1,4),),F(1),F(1,5)),((F(1,4),),F(3,2),F(1,5))]),(2,[((F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(-1,2)),F(1),F(1,10)),((F(1,2),F(1,2)),F(3,2),F(1,5)),((F(0),F(0)),F(2),F(1,10))]),(3,[((F(-1,2),F(0),F(0)),F(1),F(1,10)),((F(0),F(-1,2),F(0)),F(1),F(1,10)),((F(0),F(0),F(1,2)),F(3,2),F(1,10)),((F(1,2),F(1,2),F(0)),F(3,2),F(1,10)),((F(0),F(0),F(0)),F(2),F(1,10))])]

def source_groups(n,recv):
 axes=[sorted(set([F(-2),F(2)]+[x[a]+sgn*r/2 for x,r,w in recv for sgn in [-1,1]])) for a in range(n)];g={};cells=0
 for ids in product(*[range(len(p)-1) for p in axes]):
  box=[(axes[a][i],axes[a][i+1]) for a,i in enumerate(ids)];vol=math.prod(hi-lo for lo,hi in box)
  c=tuple(int(all(lo>=x[a]-r/2 and hi<=x[a]+r/2 for a,(lo,hi) in enumerate(box))) for x,r,w in recv)
  for capture,(x,r,w) in zip(c,recv):ck('full_cell_inside_or_outside',capture or any(hi<=x[a]-r/2 or lo>=x[a]+r/2 for a,(lo,hi) in enumerate(box)))
  g[c]=g.get(c,F(0))+vol;cells+=1
 ck('complete_source_partition_volume',sum(g.values())==4**n)
 return sorted(g),g,cells

def partitions(N):
 out=[]
 def rec(i,groups):
  if i==N:out.append(tuple(tuple(g) for g in groups));return
  for k in range(len(groups)):
   groups[k].append(i);rec(i+1,groups);groups[k].pop()
  groups.append([i]);rec(i+1,groups);groups.pop()
 rec(0,[]);return out

def candidates(N,sigs,mu):
 for groups in partitions(N):
  label=[next(g for g,I in enumerate(groups) if i in I) for i in range(N)];G=len(groups)
  scores=[[sum(c[i] for i in I) for I in groups] for c in sigs]
  for order in permutations(range(G)):
   theta=[]
   for row in scores:
    j=next((j for j in order if row[j]),None);theta.append(tuple(F(int(j==g)) for g in range(G)))
   yield groups,label,theta,'hard_priority',order
  for rule in ['soft_count','soft_occupation']:
   theta=[]
   for c in sigs:
    v=[sum((mu[i] if rule=='soft_occupation' else F(1))*c[i] for i in I) for I in groups];total=sum(v)
    theta.append(tuple(a/total if total else F(0) for a in v))
   yield groups,label,theta,rule,()

def gap_endpoint(n,recv,sigs,mass,H,K=F(1)):
 # Original reverse-favorable massgap, full shared-source integral, alpha=1 outside.
 N=len(recv);mi=[r**n for x,r,w in recv];mu=[w/m for (x,r,w),m in zip(recv,mi)];answer=[F(0)]*N
 rs=sorted(set(r for x,r,w in recv))
 for k,r in enumerate(rs):
  active=[i for i,(x,R,w) in enumerate(recv) if R<=r];ell=r**-n-(rs[k+1]**-n if k+1<len(rs) else 0)
  for c,fy in zip(sigs,mass):
   J=sum(mu[i]*c[i] for i in active)
   if not J or J<H:continue
   for i in active:
    for j in active:
     center=max(abs(a-b) for a,b in zip(recv[i][0],recv[j][0]))
     if mi[i]>K*mi[j] and center>recv[i][1]/2:
      answer[i]+=fy*ell/J*mu[i]*mu[j]*c[i]*c[j]*(mi[i]-mi[j])
 return answer

def endpoint_source(sigs,mi):
 # Nested signatures from actual geometry, no manufactured incidence.
 chain=sorted(range(len(mi)),key=lambda i:(mi[i],i));out=[F(0)]*len(sigs);last=F(0)
 for k,i in enumerate(chain):
  c=tuple(int(j in chain[k:]) for j in range(len(mi)))
  ck('minimum_face_signature_exists',c in sigs)
  out[sigs.index(c)]+=mi[i]-last;last=mi[i]
 return out

def analyze(stage,n,recv,sigs,mass,cells):
 N=len(recv);mi=[r**n for x,r,w in recv];weights=[w for x,r,w in recv];mu=[w/m for w,m in zip(weights,mi)];X=sum(weights);W=sum(mass)
 for i in range(N):ck('actual_q_preserved',sum(m*c[i] for m,c in zip(mass,sigs))==mi[i])
 ck('source_nonnegative',all(m>=0 for m in mass))
 gaps={str(H):gap_endpoint(n,recv,sigs,mass,H) for H in [F(0),F(1,8)]};totals={H:sum(g) for H,g in gaps.items()}
 # Parameter candidates fixed before enumeration. Optimize finite coverage only.
 params=list(product([F(1,16),F(1,4),F(1,2)],[F(1,8),F(1,2),F(1)]));best={p:None for p in params};bestgap={p:None for p in params};candidate_count=0
 for groups,label,theta,rule,order in candidates(N,sigs,mu):
  candidate_count+=1;G=len(groups)
  ck('frozen_source_partition',all(all(t>=0 for t in row) and sum(row)<=1 for row in theta))
  ck('unique_receiver_label',len(label)==N and all(0<=g<G for g in label))
  Wj=[sum(m*t[g] for m,t in zip(mass,theta)) for g in range(G)]
  captured=[sum(m*c[i]*t[label[i]] for m,c,t in zip(mass,sigs,theta)) for i in range(N)]
  for delta,eta in params:
   good=[captured[i]>=(1-delta)*mi[i] and mi[i]>=eta*Wj[label[i]] for i in range(N)]
   coverage=sum(w for w,g in zip(weights,good) if g);unassigned={H:sum(v for v,g in zip(gap,good) if not g) for H,gap in gaps.items()}
   score=(coverage,-unassigned['0']);previous=best[delta,eta]
   if previous is None or score>previous['score']:
    best[delta,eta]=dict(score=score,good=good,groups=groups,label=label,rule=rule,order=order,theta=theta,Wj=Wj,captured=captured,coverage=coverage,unassigned=unassigned)
   scoregap=(-unassigned['0'],coverage);oldgap=bestgap[delta,eta]
   if oldgap is None or scoregap>oldgap['scoregap']:
    bestgap[delta,eta]=dict(scoregap=scoregap,good=good,groups=groups,label=label,rule=rule,order=order,Wj=Wj,captured=captured,coverage=coverage,unassigned=unassigned)
 rows=[]
 for (delta,eta),b in best.items():
  for i,g in enumerate(b['good']):
   if g:ck('selected_good_near_isolation',b['captured'][i]>=(1-delta)*mi[i] and mi[i]>=eta*b['Wj'][b['label'][i]])
  # Whole frozen partition retained in certificates, including zero signature.
  ck('selected_source_budget',sum(b['Wj'])<=W)
  row=dict(delta=str(delta),eta=str(eta),covered_Xq=str(b['coverage']),coverage_fraction=str(b['coverage']/X),good_receivers=[i for i,g in enumerate(b['good']) if g],groups=[list(g) for g in b['groups']],receiver_labels=b['label'],rule=b['rule'],priority_order=list(b['order']),label_masses=list(map(str,b['Wj'])),own_label_capture=list(map(str,b['captured'])),theta=[[str(t) for t in row] for row in b['theta']],unassigned_gap={H:str(v) for H,v in b['unassigned'].items()},unassigned_gap_fraction={H:float(b['unassigned'][H]/v) if v else None for H,v in totals.items()},formal_good_fee_diagnostic= float(delta*X)+(1+math.log(float(1/(eta*(1-delta)*F(3,4)))))*float(W))
  bg=bestgap[delta,eta]
  ck('gap_priority_source_budget',sum(bg['Wj'])<=W)
  for i,g in enumerate(bg['good']):
   if g:ck('gap_priority_good_conditions',bg['captured'][i]>=(1-delta)*mi[i] and mi[i]>=eta*bg['Wj'][bg['label'][i]])
  row['gap_priority_alternative']=dict(covered_Xq=str(bg['coverage']),coverage_fraction=str(bg['coverage']/X),good_receivers=[i for i,g in enumerate(bg['good']) if g],groups=[list(g) for g in bg['groups']],receiver_labels=bg['label'],rule=bg['rule'],priority_order=list(bg['order']),label_masses=list(map(str,bg['Wj'])),own_label_capture=list(map(str,bg['captured'])),unassigned_gap={H:str(v) for H,v in bg['unassigned'].items()},unassigned_gap_fraction={H:float(bg['unassigned'][H]/v) if v else None for H,v in totals.items()})
  rows.append(row)
 return dict(stage=stage,n=n,receiver_count=N,source_geometric_cells=cells,source_patterns=len(sigs),W=str(W),Xq=str(X),m_i=list(map(str,mi)),receiver_weights=list(map(str,weights)),source_masses=list(map(str,mass)),signatures=[list(c) for c in sigs],gap_total={H:str(v) for H,v in totals.items()},gap_scope='Exact full-source reverse-minus-favorable massgap under center-outside alpha1, K1 strict mass ordering, H0/H1over8. Not original highpast/root branch; no claim of nonempty highpast.',candidate_partitions_and_rules=candidate_count,results=rows)

def tiny_grid_checks():
 before=sum(CHECK.values());crossing=0;noncrossing=0;zero_capture=0
 for n,delta,R in product([1,2,3,16],[F(1,16),F(1,4),F(1,2)],[F(1),F(3,2),F(2)]):
  L=F(2*n)/delta;prob=1-(1-R/L)**n
  ck('grid_tensor_crossing_probability',0<=prob<=n*R/L<=delta)
 def mass(lo,hi):return max(F(0),min(hi,F(2))-max(lo,F(-2)))
 # One-dimensional actual f=1_Q4; cell chosen by a single frozen phase.
 L=F(8)
 for phase,x,R in product([F(0),L/4,L/2,3*L/4],[F(-3),F(-1,4),F(0),F(1,4),F(3)],[F(1),F(3,2),F(2)]):
  index=(x-phase)//L;lo=phase+index*L;hi=lo+L;ql=x-R/2;qh=x+R/2
  ck('grid_cell_inside_local_Q2L',x-L<=lo<=x<hi<=x+L)
  m=mass(ql,qh);W=mass(lo,hi);M=mass(x-L,x+L)
  if ql>=lo and qh<=hi:
   noncrossing+=1;zero_capture+=m==0
   ck('grid_noncross_actual_source_ledger',m<=W<=M)
  else:crossing+=1
 return dict(exact_checks=sum(CHECK.values())-before,tensor_probability_cases=36,actual_interval_cases=60,noncrossing_cases=noncrossing,crossing_cases=crossing,zero_capture_noncrossing_cases=zero_capture,scope='Tiny exact crossing-probability and actual 1D f=1_Q4 containment ledger only. No full traffic averaging or global shift-selection theorem is numerically certified.')

def main():
 models=[];stages=[]
 for stage in ['baseline','repaired_ratio_sources','minimum_mass_face_stress']:
  before=sum(CHECK.values())
  for n,recv in fixtures():
   sigs,g,cells=source_groups(n,recv);mi=[r**n for x,r,w in recv]
   if stage=='baseline':mass=[g[c] for c in sigs]
   elif stage=='repaired_ratio_sources':
    snap=SNAPSHOT[str(n)];mapping={tuple(c):F(x) for c,x in zip(snap['signatures'],snap['masses'])};mass=[mapping.get(c,F(0)) for c in sigs]
   else:mass=endpoint_source(sigs,mi)
   model=analyze(stage,n,recv,sigs,mass,cells);models.append(model)
   print(json.dumps(dict(stage=stage,n=n,coverage=[r['coverage_fraction'] for r in model['results']]),sort_keys=True),flush=True)
  stages.append(dict(name=stage,exact_checks=sum(CHECK.values())-before))
 grid=tiny_grid_checks()
 result=dict(grid_diagnostic=grid,status='PASS',total_exact_checks=sum(CHECK.values()),check_counts=dict(CHECK),stages=stages,source_snapshot_provenance=SNAPSHOT_PROVENANCE,receivers=[dict(n=n,entries=[dict(center=list(map(str,x)),R=str(r),quadrature_weight=str(w)) for x,r,w in recv]) for n,recv in fixtures()],models=models,scope='Actual positive-L1 cube face cells, original q1 and masses preserved, finite receiver quadrature only. Label certificates feasible, finite candidate enumeration not global optimum. Formal fee displayed only as diagnostic, not continuum theorem verification. Float log fee separate from exact rational checks.')
 (BASE/'r340_numeric_result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',exact_checks=sum(CHECK.values()),stages=stages),sort_keys=True))
SNAPSHOT={'1': {'signatures': [[0, 1], [1, 0], [1, 1]], 'masses': ['110927627/145885118', '18992534/72942559', '53950025/72942559']}, '2': {'signatures': [[0, 0, 0, 1], [0, 0, 1, 0], [0, 0, 1, 1], [0, 1, 0, 1], [0, 1, 1, 1], [1, 0, 0, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 1]], 'masses': ['152192675345354542508815/111014552212439362614092', '85979941608203/117492357305350462170218', '67636281/67089491', '111931209459059/150777896946455508989764', '56578442/91119697', '111931209459059/150777896946455508989764', '56578442/91119697', '32636771/86095918', '41/38439068']}, '3': {'signatures': [[0, 0, 0, 0, 1], [0, 0, 0, 1, 0], [0, 0, 0, 1, 1], [0, 0, 1, 0, 0], [0, 0, 1, 0, 1], [0, 0, 1, 1, 1], [0, 1, 0, 0, 1], [0, 1, 0, 1, 1], [0, 1, 1, 0, 1], [0, 1, 1, 1, 1], [1, 0, 0, 0, 1], [1, 0, 0, 1, 1], [1, 0, 1, 0, 1], [1, 0, 1, 1, 1], [1, 1, 0, 0, 1], [1, 1, 0, 1, 1], [1, 1, 1, 0, 1], [1, 1, 1, 1, 1]], 'masses': ['4427208217662176873923899605435104719801910732720069/1553012758086789705933097045293926421416243062528368', '9069628557741113471982278370985520477352474076753/557011166154917661470830900804615459045965902613581936376', '109951249/78606499', '23420327782968043843502544128714838662811557718256213/1438359231874780692476777865308294502211726654579517026236012', '96607821/69066997', '45726070/59629773', '242612854204622554633088594081394238046139619/1754261154533557326602070738752568555842629427839248', '6977014/83064919', '6133347/73020632', '4845835/11622246', '888386820965112287087277719689633629120072089351/6423660010772338539841551689887334583782197006626170928', '7651719/91097627', '7436688/88537573', '39714235/95250583', '11/98616464', '10016407/48264251', '19364335/93307423', '5/18827343']}}
SNAPSHOT_PROVENANCE={'file': 'r334_data_lp.json', 'sha256': '442ec3f5c66af3716ccc2d9c5f1ece3d24b7279fd80f06cac61b042e88b6fa14', 'selected': 'H0 exact repaired source certificates; embedded to remove runtime dependency'}
if __name__=='__main__':main()
