# R340: near-isolated source labels and the exact traffic leakage

## Contract and the new positive receipt

Use the exact R339/R338 contract, original G_out, J_y(r), global strict past Z, physical ell=b^{-n}δ_b+n r^{-n-1}dr on [a,b], full source masses m_u, actual Lebesgue du, and q_-≤q_u≤λ. In particular p_u(dy)=f(y)1_{Q_u}(y)dy/m_u is the real source posterior. Nothing below replaces it with an independent source or resets J. Write X_q(A)=∫_A q_u du.

Let {θ_j}_{j≥1} be a preassigned countable family of measurable functions with θ_j≥0 and Σ_jθ_j≤1 pointwise f-a.e., and put W_j=∫θ_j f. Thus each θ_j≤1 and Σ_j W_j≤W. These are actual source weights shared by all endpoints.

Fix 0≤d<1 and 0<η≤1. Let A⊂E be measurable and j(u) a measurable single label on A satisfying

    p_u(θ_{j(u)}) ≥ 1-d,
    m_u ≥ η W_{j(u)}.                                  (1)

All assigned labels necessarily have W_j>0. The original traffic restricted only by u∈A satisfies

    G_out(A) ≤ d X_q(A)
          + [1+log(λ/(η(1-d)q_-))] Σ_{j:E_j nonempty} W_j
      ≤ d X_q(A)+[1+log(λ/(η(1-d)q_-))]W,              (2)

where E_j={u∈A:j(u)=j}; labels used only on null receiver sets can be omitted. The expression with the sum may harmlessly include all labels instead.

Consequently, with G_rem the unchanged original traffic restricted to u∉A,

    G_out ≤ G_rem + d X_q
          + [1+log(λ/(η(1-d)q_-))]W.                  (3)

This is the claimed replacement of exact source isolation by near isolation. It pays a real positive branch, and G_rem is retained. Taking η=e^{-√n} gives source coefficient

    1+√n+log(4/3)+log(1/(1-d)).                        (4)

No existence of a useful label family is asserted by (2).

## Proof: source part and leakage part

For u∈E_j, actual near capture gives

    (1-d)m_u ≤ ∫θ_j f 1_{Q_u} ≤ W_j,

so the original full mass lies in the single window

    ηW_j ≤ m_u ≤ W_j/(1-d).                           (5)

Split the integrand for this u by the exact identity 1=θ_j(y)+(1-θ_j(y)). All original gates are kept in both nonnegative pieces.

For the θ_j source piece, the R339 mass-window proof applies directly to the positive source weight θ_j f, while retaining full-f endpoint masses and the original J. Specifically, the inner v integral divided by J is at most m_u; its source-centered real center-volume envelope has radii

    R_{-,j}=max(a,(ηW_j/λ)^(1/n)),
    R_{+,j}=min(b,(W_j/((1-d)q_-))^(1/n)).

If R_{-,j}>R_{+,j}, that receiver branch is empty. Otherwise its source fee is at most

    [1+n log(R_{+,j}/R_{-,j})]W_j
       ≤ [1+log(λ/(η(1-d)q_-))]W_j.                   (6)

The constant 1 in (6) remains the original inclusive physical tail R_{+,j}^n ell([R_{+,j},b])=1. In particular it includes the actual b atom, even when R_{+,j}<b. No atom is added at R_{+,j}. The λ/q_- factor is only inside the logarithm.

For the leakage piece, use the same original row bound by m_u before discarding gates. Then its full physical tail gives

    G_leak(E_j)
      ≤ ∫_{E_j}du R_u^{-n} ∫f(y)1_{Q_u}(y)(1-θ_j(y))dy
      = ∫_{E_j}q_u[1-p_u(θ_j)]du
      ≤ d X_q(E_j).                                   (7)

Summing (6) and (7) over disjoint receiver sets E_j proves (2), because Σ_jW_j≤W. In particular no duplicate assignment of the same u is permitted. All exchanges of nonnegative integrals are justified by Tonelli.

## Measurability for any already chosen source partition

The numerical capture p_u(θ_j) is measurable in u: fθ_j is measurable and integrable, and (u,y)↦1_{Q_u}(y) is measurable for the given measurable radius selector. For a fixed countable family define

    C_j={u∈E:p_u(θ_j)≥1-d and m_u≥ηW_j},
    A=∪_j C_j.

Assign the least admissible index j on A. This is a measurable single-label assignment, so (2) covers the entire eligible union for that prechosen family. For d<1/2 the capture condition already makes the admissible label unique, since Σ_jp_u(θ_j)≤1. At d=1/2 or larger the least-index rule avoids double counting.

The unassigned complement is precisely the set with no label satisfying both conditions; it includes endpoints whose available labels have weak capture or whose local mass is below ηW_j. This construction solves label selection *after a source partition is provided*. It does not construct a favorable source partition.

## A weaker sufficient condition using the traffic that actually occurs

Near capture at every assigned endpoint is stronger than the proof needs. Define the exact original traffic multiplier

    τ_u(y) = (1/q_u) ∫_{[R_u,b]} ell(dr)
              1_{J_y(r)≥H} 1_{Z_y(m_u/K-)>h}/J_y(r)
              × ∫_{E_r} 1_{Q_v}(y)(m_u-m_v)
                   1_{m_u>Km_v}
                   1_{||u-v||∞>αR_u/2} dμ(v),         (8)

using zero on zero-J rows. All source gates and original denominators are unchanged. The inner row is at most m_u. The inclusive ell tail gives

    0≤τ_u(y)≤m_u R_u^{-n}/q_u=1,
    G_out(A)=∫_A q_u du ∫p_u(dy)τ_u(y).               (9)

The common source is the same y in p_u and τ_u; (8) is a density representation, not an independent resampling operation.

Now fix 0<β≤1. Suppose a measurable assignment on A satisfies only the direct mass windows

    ηW_{j(u)}≤m_u≤W_{j(u)}/β.                         (10)

Define its exact leaked traffic

    L_T(A)=∫_A q_u du ∫p_u(dy)τ_u(y)(1-θ_{j(u)}(y)).  (11)

Applying the R339 source-window estimate to the θ part and leaving (11) exact yields

    G_out ≤ G_rem+L_T(A)
               +[1+log(λ/(ηβq_-))]W.                (12)

Thus the sufficient geometric selection target can be weakened to

    direct mass windows (10),
    G_rem+L_T(A) ≤ d X_q + C√n polylog(n)W,            (13)

with fixed β>0 and η=e^{-√n}; (12) would then pay the entire original G_out at root order. Nothing here proves (13).

A stronger, easier-to-state alternative to controlling L_T is the aggregate ordinary-posterior leakage

    L_p(A)=∫_A q_u[1-p_u(θ_{j(u)})]du,
    L_T(A)≤L_p(A).                                    (14)

An aggregate L_p bound suffices; a per-endpoint d bound is unnecessary. For example p_u(θ_j)≥β with β=1/2 supplies the upper mass bound in (10), while a separate small aggregate *traffic* leakage can supply (13). This allows posterior mass outside the label when that source mass carries little original traffic. Equations (11)–(14) specify the weaker condition without treating its existence as established.

## Brief compatibility constraint and the unresolved selection step

For d<1/2, two endpoints satisfying (1) with different labels must obey

    ∫min(dp_u,dp_w) = I_uw/max(m_u,m_w) ≤ 2d,
    I_uw=∫f 1_{Q_u}1_{Q_w}.                           (15)

Indeed if their labels are j≠k, then p_w(θ_j)≤1-p_w(θ_k)≤d, while p_u(θ_j)≥1-d. Since 0≤θ_j≤1, the total variation distance of p_u,p_w is at least 1-2d, proving (15). This does not itself provide a packing estimate or a source partition. It only records that overlapping source posteriors cannot be assigned favorable labels independently.

The missing positive construction is a countable source weight family of total weight at most one, together with assignments whose true local masses fit (10), and a bound on the actual residual (13). The original high-past and outer-center conditions have not been shown here to imply this. In particular, neither pairwise small posterior overlaps, arbitrary receiver clustering, nor separately optimizing a label for each source y supplies the required common partition and leakage budget. No free label reuse is allowed.

## Full hard-slot insertion and computational check

With the unchanged R338 choices and its coefficient C_{ε,n}, (3) yields

    B_H(f,ν) ≤ G_rem+(2ε+d)X_q
       +[C_{ε,n}+1+√n+log(4/3)+log(1/(1-d))]W.        (16)

Alternatively, use G_rem+L_T and source coefficient 1+√n+log(4/(3β)) as in (12). Both formulas retain all unassigned traffic. They are strict partial payments, not a general closure.

`/tmp/r340_geometry_checks.py` was actually run with Python Fraction arithmetic. It uses genuine one-dimensional step source f with weights (1,2,1,3) on four unit intervals, all ten nonempty interval cubes with integer endpoints, and every binary source partition. It passed 122 exact mass-cap assertions and 128 exact distinct-label consistency assertions. Those checks concern the scalar mass-cap and posterior-overlap lemmas; they do not simulate the full G_out or establish existence of favorable labels. The measure-theoretic payment is proved above.
