"""Exact simple-function diagnostics; analytic proofs are in r340_geometry.md."""
from fractions import Fraction as F
from itertools import product
weights = [F(1), F(2), F(1), F(3)]
intervals = [(i,j) for i in range(4) for j in range(i+1,5)]
delta = F(1,4)
consistency = 0
mass_caps = 0
for bits in product([0,1], repeat=4):
    labels = [list(map(F,bits)), [1-F(x) for x in bits]]
    total = [sum(w*t for w,t in zip(weights,label)) for label in labels]
    data=[]
    for i,j in intervals:
        mass=sum(weights[i:j])
        capture=[sum(weights[k]*labels[l][k] for k in range(i,j))/mass for l in range(2)]
        for l in range(2):
            if capture[l]>=1-delta:
                assert mass<=total[l]/(1-delta)
                mass_caps+=1
        data.append((i,j,mass,capture))
    for i,j,m,c in data:
        for k,l,M,C in data:
            if c[0]>=1-delta and C[1]>=1-delta:
                common=sum(weights[max(i,k):min(j,l)]) if max(i,k)<min(j,l) else F(0)
                assert common/max(m,M)<=2*delta
                consistency+=1
print({'exact_mass_cap_assertions':mass_caps,'exact_distinct_label_consistency_assertions':consistency,'status':'passed'})
