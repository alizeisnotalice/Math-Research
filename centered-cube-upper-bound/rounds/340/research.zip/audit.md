# R340 independent preauthor audit — fixed source allocation and near-isolation

Owned only `/tmp/r340_audit.md`; no Git/other-author edits. This screen precedes reading any R340 author proof. The object is the positive original hard-matched G_out from R338/R339, with actual f, m_u=f(Q_u), q_u=m_u/R_u^n, unchanged full J and every original positive gate.

## Quantified contract and disposition

PASS under a fixed finite or countable measurable family theta_j(z)>=0 with sum_j theta_j(z)<=1 for f-a.e. z. Set W_j=integral theta_j f, so sum_j W_j<=W. The allocation functions are fixed source functions before the receiver integral; they may be chosen from the frozen field, but there is no uncharged receiver-private family. A measurable unique receiver label j(u) gives disjoint receiver sets E_j. Fix 0<=delta<1 and 0<eta<=1. For a positive-mass receiver define

 p_u(theta_j)=m_u^(-1) integral_{Q_u}theta_j(z)f(z)dz.

The good large endpoints satisfy p_u(theta_{j(u)})>=1-delta and m_u>=eta W_{j(u)}. A good receiver cannot have W_j=0, since m_u>0 and 1-delta>0. Thus zero-mass components cause no division/endpoint issue. If an uncountable label family is proposed, a precise measurable mass integral/accounting contract must replace the displayed countable sum; it is not automatically licensed by this proof.

## Independent proof: assigned-source part

For u in E_j good, (1-delta)m_u<=integral_{Q_u}theta_j f<=W_j. Thus the ORIGINAL full-f mass lies in [eta W_j,W_j/(1-delta)]. The corresponding actual radius interval is

 [max(a,(eta W_j/lambda)^(1/n)), min(b,(W_j/((1-delta)q_-))^(1/n))].

Empty intervals contribute zero. For the outer source y split the SAME original integrand by theta_j(y)+(1-theta_j(y))=1, only after fixing its unique large-endpoint label. In the theta_j part, the inner small-endpoint posterior is bounded by its ORIGINAL full J; J is not recomputed from theta_j f or E_j. Then the actual capturing-center volume and the full inclusive ell tail from R339 give

 G_assigned,j <= [1+log(lambda/(eta(1-delta)q_-))] W_j.

The term 1 pays the complete upper-scale tail including b and singleton radius windows. Summing j costs at most C W, C=1+log(lambda/(eta(1-delta)q_-)). Restricting each j's receiver set cannot increase its volume majorant. The fixed source budget is why labels may vary with u without an additional copy of W. Arbitrarily assigning a different theta_u to each receiver, without one common summable source family, does not imply this sum bound.

## Independent proof: leakage part

At each retained u, use (m_u-m_v)<=m_u and integral c_v dmu(v)/J<=1 before dropping the positive original pair gates. The source leakage is integral_{Q_u}f(1-theta_{j(u)})<=delta m_u. Integrating the unchanged original ell tail from R_u to b yields

 G_leak <= integral_{E_good} R_u^(-n) integral_{Q_u}f(1-theta_{j(u)})du
        <= delta integral_{E_good}q_u du
        = delta X_good <= delta X_q.

The source-dependent high-past and high-H gates are only deleted for a positive upper bound, not recomputed. No factor 2, no independent small-source choice, no component FIRST, and no source density cap is used. This is an oriented large-endpoint receipt, so there is no symmetric half-factor. All physical radius atoms are included by the same inclusive ell identity.

Consequently

 G_out <= G_bad + C W + delta X_good,

where G_bad is the original complete positive traffic restricted to the complement of the good LARGE-endpoint receivers. It retains full sources, original q/J/past/center/mass/scale gates. No existence or useful coverage fraction of good labels is asserted.

## Ledger consequences and limits

Replacing the R338 residual directly gives BH<=G_bad+(2epsilon+delta)X_q+(C_epsilon,n+C)W (or retain sharper delta X_good). Under the original entrance factor 2, the NEW leakage debit is 2delta X_good, and an outer multiplier also multiplies it. It cannot be hidden in a previous epsilon allowance. This is an alternative residual partition, not a source bill added on top of an overlapping R339 heavy payment; a combined use requires an explicit disjoint priority allocation.

The fixed source family may use fractional theta and need not be spatially disjoint. Nevertheless the actual inequality sum theta<=1 and a single actual label per receiver are essential. Purity and mass threshold both refer to the ORIGINAL f-cube masses; replacing those masses or q by allocated-source masses changes the target. For eta=exp(-sqrt(n)), the assigned fee is 1+sqrt(n)+log(lambda/q_-)+log(1/(1-delta)); no generally favorable partition or root bound for G_bad follows. This payment does not certify the historical soft/general-scale/outer ledger or global root closure.

## Actual bounded tool execution

Reviewer ran 712 exact Fraction scalar/source-budget assertions covering delta=0 and positive delta, eta=1 and smaller eta, the mass-window implication and leakage inequality, and one fixed fractional three-component source budget. PASS. These are algebra diagnostics, not a real receiver geometry model or a proof of useful near-isolation coverage. The general estimates above are analytical.

Status: independent proposition screen PASS with the stated finite/countable fixed-source contract. Await author proof and final integration; this is not a final archive binding.


## Independent constructive random-grid screen (before core proof)

PASS for the fixed original hard field, 0<delta<1, 0<eta<=1, L=nb/delta and M(u)=integral_{Q_(2L)(u)}f. Keep growthgood={m_u>=eta M(u)} and growthbad its strict complement, both independent of the auxiliary shift. The field M is measurable (indeed convolution with a fixed bounded cube indicator), finite and at most W. It is not a replacement for m_u, q_u, J or the actual receiver scale.

For one global uniform shift s in [0,L)^n, let C_j(s) be half-open side-L cubes and j_s(u) the UNIQUE cell containing the actual receiver center. On the noncross event Q_u subset C_j(s),

 m_u<=W_j(s)=integral_{C_j(s)}f<=M(u)<=m_u/eta

for growthgood u: the containing source cell lies within the side-2L cube centered at u. Thus m_u is in [eta W_j,W_j], and its captured source is entirely assigned to the same cell, up to Lebesgue-null boundaries. Applying the R339 source-window proof separately to these disjoint receiver labels uses the SAME original full J. The full cell source masses sum to W for EVERY shift, so the complete growthgood/noncross traffic is at most [1+log(lambda/(eta q_-))]W for every shift. Countably many cells are settled by Tonelli. No private source is chosen per receiver and no cell-count multiplier occurs.

For the crossing traffic define g(u)>=0 to be the original G_out contribution density in the large receiver du, before inserting the shift. The unchanged original inner posterior/J is at most one after using (m_u-m_v)<=m_u, and the inclusive ell tail gives

 g(u)<=R_u^(-n)integral_{Q_u}f=q_u.

This uses the actual source and all original r-prefixes; no component FIRST or hard density cap is substituted. The event that a cube of side R_u crosses a side-L grid cell has probability 1-(1-R_u/L)^n<=n R_u/L<=delta (since R_u<=b<L). Therefore Tonelli gives

 average_s G_growthgood,cross(s)<=delta integral_growthgood g(u)du
                                      <=delta X_good<=delta X_q.

There exists a single shift satisfying that complete weighted crossing bound for the fixed field; it is not a separate shift per u/y/pair. More robustly, the final deterministic inequality follows by averaging the identity G_out=G_growthbad+G_growthgood,noncross(s)+G_growthgood,cross(s) directly. Thus no measurable choice of a favorable shift across external parameters is necessary: the shift can remain an auxiliary average and the remainder is the ORIGINAL deterministic growthbad traffic.

Final fixed-field receipt:

 G_out<=G_growthbad+[1+log(lambda/(eta q_-))]W+delta X_good.

Global heavy {m_u>=eta W} is contained in growthgood because M(u)<=W. This replaces the R339 heavy allocation, not a source bill added to an overlapping heavy allocation. It extends the structurally payable gate, while introducing the explicit crossing debit delta X_good. Under entrance factor2 and an outer multiplier, that debit must be charged accordingly. No generally useful coverage fraction, bound for growthbad, full-scale bridge or root closure follows merely from this construction.

Boundary/endpoint guards: all source and receiver measures here have Lebesgue densities, so fixed cube/grid boundaries have zero measure; the crossing probability is unaffected by half-open conventions or exact contact. L>R_u for every actual receiver since delta<1, including n=1, R_u=b. Source cells of zero mass cannot contain a positive-q receiver cube on the noncross event. Original physical radius atoms, including b, remain in the inclusive ell tail; the new grid is not a family of new averaging radii. Measurability follows from the fixed countable grid indexing and measurable (u,s) containment, and all averaging uses nonnegative Tonelli; X_q<infinity follows from finite E and q<=lambda.

Reviewer actually ran 147 additional exact Fraction scalar assertions for the full cube crossing probability bound and source-window implications (not an actual receiver/source fixture). PASS. Await the author core and final integration bytes; this remains an independent preauthor screen, not a final frozen R340 archive.


## First author file comparison — geometry PASS

Read complete `/tmp/r340_geometry.md` and `/tmp/r340_geometry_checks.py` after the independent screen. The finite/countable common-source contract, unique receiver label, original mass-window derivation and same-full-J leakage proof match the screen. Its measurable least-index assignment covers the eligible union for an already supplied family, without constructing the family. For d<1/2, uniqueness follows from sum_j p_u(theta_j)<=1. The generalized exact traffic density tau_u(y) is correctly normalized: source capture c_u is in the original posterior p_u, not omitted from the target; its original future inner row and inclusive tail give tau<=1. Exact traffic leakage L_T is retained, and the weaker direct-window interface does not recompute q, m, J or any original gate.

The compatibility identity integral min(dp_u,dp_w)=I_uw/max(m_u,m_w) and the different-label bound<=2d are correct; neither is promoted to a packing or coverage theorem. The check script genuinely uses finite 1D step-source cube masses and common binary source partitions, but only checks the scalar mass cap and posterior overlap. Its reported 122+128 exact assertions are author execution evidence, not a simulation or certificate of full G_out. No correction requested.

Bindings for this author comparison (not yet final R340 freeze):
- `/tmp/r340_geometry.md` SHA256 `a8a626f234890c71dd63dbe39785cbdf796807679b52ea00774cb567cc37a236`.
- `/tmp/r340_geometry_checks.py` SHA256 `677833bb258e1337c9164923511ce4ab32ce03b2bdba9097c6d3e956a63d612e`.


## Final core author comparison — PASS

Read complete `/tmp/r340_core.md` and `/tmp/r340_core_checks.py` after the independent construction screen. The theorem matches that screen. The receiverwise domination G_out(B)<=X_q(B) is proved for every measurable B using the original full J and actual inclusive physical tail; hence it also applies to the measurable crossing subset of each single shift. The displayed crossing probability and source-cell inclusion Q_u subset S_j subset Q_(2L)(u), up to null faces, have the correct SIDE lengths. In particular L=nb/delta>b even when n=1. Actual cell masses sum to W, while every noncrossing growthgood receiver satisfies eta W_j<=m_u<=W_j without changing q, J, m or any original mask. Zero-mass cells contain no such admissible receiver. The resulting source coefficient retains the complete upper-scale tail, including the actual b atom and singleton radius windows.

The chosen common shift in the text controls X_q(C_tau), which is stronger than controlling only the actual crossing traffic. Its measurability and finite integrability follow from the displayed floor/coordinate predicates and q<=lambda on finite-volume E. The direct averaging version is also proved, so the deterministic result needs no favorable-shift selector across external parameters. All original small receivers and source variables remain shared; no per-receiver or per-source choice of shift is made.

The exact remainder is the original positive G_out restricted only in the large endpoint by m_u<eta M_L(u). The inclusion growthbad subset global-light is valid since M_L<=W; no general nonemptiness or traffic coverage fraction is inferred from strict endpoint inclusion. The new enlarged side2L source cube is only a label construction device, not a new radius at which an original cap is assumed. The continuum fixture in the reproduction script has genuinely positive receiver volume and exact piecewise-linear integration of crossing volume, but it evaluates no G_out. It supports the strict set inclusion only.

Parent reports fresh execution of all 457 Fraction check units: 384 exact probability cases, 7 continuous receiver-integration checks, and 66 finite source-cell mechanics cases. These are units, not necessarily one assert instruction per unit. Code inspection confirms complete one-dimensional crossing breakpoints and trapezoidal integration of each proved-linear segment, rather than sampling being substituted for receiver integration. No repeat run was performed by this reviewer.

## Final numeric code/result/notes review — PASS for the stated finite scope

Read full `/tmp/r340_numeric.py`, its notes, and final result metadata. The source is integrated over the COMPLETE positive-volume face partition of Q4, including the zero capture pattern. Faces are checked to be entirely inside or outside each original actual cube; per-signature densities realize the prescribed compact L1 sources. Exact mass equations retain m_i=R_i^n and q_i=1 in all three source stages. Source labels are a common finite family, nonnegative and summing to at most one on every source signature. Receiver labels are unique. The finite candidate family includes priority partitions and the two stated fractional rules; it is not the class of all source partitions.

The massgap calculation retains actual shared-source integration, finite receiver quadrature weights, inclusive original scale layers and terminal atom, exact mass differences and center distances. It intentionally uses alpha=1, K=1, no high-past gate, and H=0 or1/8. Thus it is not the original R338/R340 root-threshold G_out. Its code and notes disclose that limitation. Selecting the objective by X_q coverage versus massgap coverage gives different feasible candidates; neither finite maximization proves a continuum coverage theorem. Selected gap-priority theta can be reconstructed from its frozen groups/rule/order and original occupation weights. Full BH, historical low-pe qualifications and continuous receiver realization are not attributed to the finite model.

The final metadata reads PASS, total19665 exact checks: stage counts6507+6493+6518=19518 plus147 grid checks. The grid appendix has36 probability cases and60 interval cases (51 noncrossing,9 crossing), with containment/source budgets checked only on the appropriate events; it is not a full traffic/shift-selection computation. The81 ordinary float formal-fee evaluations are separate from exact checks and carry no interval claim. The notes explicitly report that these formal source fees exceed trivial budgets in examples, rather than asserting a net improvement. Parent reports the completed fresh replay; this reviewer did not rerun the full enumeration. Parent also reports the separate geometry250 exact checks completed. Reviewer's earlier712+147 bounded scalar diagnostics are not added to those primary counts.

## Final main and ledger review — PASS

Read final `/tmp/r340_main.md` and `/tmp/r340_ledger.md`. They use the constructive core as the main replacement of R339, with the near-isolation label geometry as a separate alternative interface. Neither the old global-heavy bill nor the optional label-interface source fee is charged again on the same traffic. The core requires no unproved favorable label construction on growthgood; growthbad remains the unchanged original positive remainder. All original H/J/source/actualdu/mass/past/center predicates and physical selector atoms persist in that remainder.

The full slot substitution is

 BH <= G_growthbad+(2epsilon+delta)X_q
       +[C_epsilon,n+1+sqrt(n)+log(4/3)]W_beta.

With delta=epsilon, its receiver debit is3epsilon X_q; the inherited entrance factor2 gives6epsilon X_q, while keeping8lambda H W_beta and2d_eff A_n W_nu/H. No additional slot-internal lambda H completion is introduced. The inherited hard-matched source is beta=f; domination nu<=f and the original full-f q are unchanged. The historical entrance is explicitly carried as an inherited contract rather than re-certified for all historical reductions by these new proofs.

Exact local Fraction arithmetic confirms

 6*(128/119)*(119/3072)=1/4,
 1/4+1/256=65/256,   1-65/256=191/256.

The ledger conditions this aggregation on the authentic same-X outer account, and does not infer a free sum of leaf volumes or sources/scales. The1/4 replaces the former same-slot debit and is not accumulated per round. The remaining191/256 is not an automatic absorption certificate. The unpriced growthbad term, general soft dense crossing/post-crossing slots, hard branches outside the contract, wide/extreme scale and low-pe complements, chronological initial/deletion/future-source atoms, suffix credit, outer/source/scale sums and limits remain explicitly due. The direct physical radius b atom is not identified with historical time atoms. General centered-cube root closure is NOT established.

## Final byte bindings and disposition

The following local final bytes were read and hashed. Numeric execution evidence is the parent's report plus the saved result; no redundant full pipeline or optimizer was run. No TeX/PDF compilation or word-for-word typesetting review is certified. Only this audit file was written by this reviewer. Earlier awaiting statements record the preauthor stages and are superseded by this final review.

| File | SHA256 |
|---|---|
| /tmp/r340_core.md | `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90` |
| /tmp/r340_core_checks.py | `b86c5b7e1011ef3fbcc5b9b9ef9071bcd9042ae5260a4187869849681fa3303e` |
| /tmp/r340_geometry.md | `a8a626f234890c71dd63dbe39785cbdf796807679b52ea00774cb567cc37a236` |
| /tmp/r340_geometry_checks.py | `677833bb258e1337c9164923511ce4ab32ce03b2bdba9097c6d3e956a63d612e` |
| /tmp/r340_numeric.py | `049f055fe675cd2866fb97b17018e41f9c655e1d496ebe31c57c77f5af1f2ec0` |
| /tmp/r340_numeric.md | `84612db168557406ea36120a2b2304ba3c9460eb763ab5310582648d4f2b4e3c` |
| /tmp/r340_numeric_result.json | `e9c6fc33df5a1d935b3f1cca66f1c13a9b9fd15b6b866cdfc5e26ea4c37b3732` |
| /tmp/r340_main.md | `974e7a0a453bcb515f8d1a79e23987766188495f4c92df25be35f3ec7f52aa4e` |
| /tmp/r340_ledger.md | `407f68dd04265aab2c7ee7bd4707a65508c773d5f8005f52bb643d7a4b87ce14` |

Final disposition: PASS for these contracts, final source/receiver ledger replacement and evidence scope. No outstanding correction requested. Frozen after these final byte bindings; later content changes need a new binding. The growthbad and other listed global budgets remain unproved.
