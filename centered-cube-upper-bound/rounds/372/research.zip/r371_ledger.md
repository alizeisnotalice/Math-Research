# 第371轮完整优先费用账

沿用R370同一完整输入与实际接收场，令 $G_{joint}$ 为原 $G_{out,\neg B^+}$ 中来源因子 $(1-p_{uv})(f-q_v)_+$ 的积分；$p_{uv}=|Q_u\cap Q_v|/R_v^n$。全部原门、$J$、质量、时钟和末端原子不变。

新联合正支付覆盖旧floor以及其余项中的p份额。它以 $2\Gamma_n$ **替换** 旧floor的 $\Gamma_n$，不是增加第三份模板：
\[
B_H(f,\nu)\le G_{joint}
+\varepsilon_0\left[2+\frac{C_n^++2\Gamma_n}{1+\sqrt n}\right]X_q+C_{338}W,
\quad \nu\le f,\quad C_n^+<72,
\]
\[
C_{338}=\frac\lambda{q_-}\left\{\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right\},
\quad
\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+
2\sqrt n\sqrt{\tfrac14+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
可以保留更强的实际模板费 $2T_0-T_2$，但不能在使用 $2\Gamma_n$ 后又把 $T_2$ 当作支付别处的独立信用。旧原平方、路径回捕和已付几何门也没有再次使用。

对拟分配硬槽系数 $\eta>0$，设
\[
L_n^{joint}=2+\frac{72+2\Gamma_n}{1+\sqrt n},\qquad
\varepsilon_0=\eta/L_n^{joint},\qquad
h_*=(1+\sqrt n)L_n^{joint}/(\eta q_-).
\]
$C_{338}$ 必须使用同一个新 $\varepsilon_0$。于是本硬槽接收系数至多 $\eta$，来源费用为 $O_\eta(\sqrt{n\log(n+2)})W$。不同参数对应不同实际剩余门；固定参数见证不证明每个分配参数都非空。

原入口与外乘保留为
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{joint}
+2\varepsilon_0\left[2+\frac{C_n^++2\Gamma_n}{1+\sqrt n}\right]X_q+2C_{338}W,
\quad A_n=1+n\log(b/a),\quad\Lambda=128/119.
\]
全部再乘 $\Lambda$。这一硬槽至多贡献 $2\Lambda\eta$ 接收系数；其余独立槽尚未支付，故没有认证总吸收。

精确余项仍要求严格远质量、全局strictpast、高J、outside中心和notB+，另有 $(1-p_{uv})(f-q_v)_+$。没有删去低几何交叠或高密度来源。有限模型对偶证书、条件期望归一化与标记振荡的替代推导不额外收费。

独立未付：一般soft、crossing、不同原始入口连接、硬合同外重尾、宽距离/低pe/比例带及阈值补集、初始/删除跳跃/未来被删来源的历史时间项、H选择、来源及物理尺度聚合、外积分、截断和极限。历史完整账由R370归档保留；新优先式替换其最前面的余项及floor费，不混加历史替代路线。
