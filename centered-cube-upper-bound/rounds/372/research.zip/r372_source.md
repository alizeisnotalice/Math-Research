# R372 — Actual contained-cube shell certificates and the missing negative-price support

**Bounded outcome.** The four-price LP certificate is an exact positive combination of shells between ACTUAL nested receivers. This mechanism has a reusable signed-price version for real receiver measure. Applied to the current marked source kernel, subtraction of an actual cube outside its capture intersection is valid, with an explicit saving in its matched mass. If that cube intersects the target, its original marked source leakage must be restored. A precise inscribed-cube criterion identifies when the octave lower-radius restriction makes the simplest subtraction geometrically unavailable. No general aggregate root budget is established.

## 1. Frozen current source kernel

Keep the R371 ledger's full f, q_u, m_u=f(Q_u)=q_uR_u^n, actual E and radius selector, q_-≤q_u≤λ, a≤R_u≤b≤2a. All cubes have side length as subscript. Keep its exact pair mask S (far mass, outside center and not Bplus), and its original mark

    ω_u(y)=h_* R_u^n ∫_[R_u,b] ell(dr)
           1_(J_y(r)≥H)1_(Z_y(m_u/K-)>h_*)/J_y(r),
    0≤ω_u≤1,
    p_uv=|Q_u∩Q_v|/R_v^n.

Zero-J quotients are zero. Set

    θ_v(y)=(1−q_v/f(y))_+ when f(y)>0, and θ_v(y)=0 otherwise,
    φ_uv(y)=ω_u(y)θ_v(y)c_u(y)c_v(y).

Thus fθ_v=(f−q_v)_+ exactly. The current remaining integral is

    G_joint=∫dΛ(u,v) ∫f(y)φ_uv(y)dy,
    dΛ=(1/h_*) [du/R_u^n] [dv/m_v]
               S(u,v)(1−m_v/m_u)(1−p_uv).             (1)

This positive measure preserves the actual du, full matching masses, source-dependent J/past, and entire physical clock inside ω. No source-private receiver field is introduced. A pointwise cover of the kernel ∫φ_uv dΛ, followed by integration against f, is the only sense of signed-price certification used below.

## 2. What the four-price witness actually does

The R371 finite witness has actual intervals

    A=[−3/4,3/4], B=[−1/2,3/2],
    C=[1/2,3/2], D=[1/4,7/4],

and coefficients

    a=31/10080, b=187/30240,
    d=661/158976, c=19181/1854720.

Exactly c=b+d and C⊂B∩D. Its cover is therefore

    a c_A+b c_B+d c_D−c c_C
          =a c_A+b(c_B−c_C)+d(c_D−c_C)≥0.             (2)

The negative receiver price carves out a common ACTUAL contained cube. It does not substitute the intersection B∩D as an extra moment constraint. For the diagnostic q=1 moments its price is exactly

    a m_A+b(m_B−m_C)+d(m_D−m_C)=143287/11128320.

The nonnegativity of (2) alone does not prove it covers an arbitrary target: R371 separately certified its particular frozen target on every source cell. That missing target-cover check cannot be inferred from containment.

## 3. Reusable actual-shell certificate, including real-du conditions

Take any family of actual receiver pairs (u,v) with Q_v⊂Q_u up to Lebesgue null sets. For nonnegative edge weights b, each shell

    b(c_u−c_v)≥0,    ∫f b(c_u−c_v)=b(m_u−m_v).        (3)

A finite positive sum of these shells, together with positive actual-cube prices, is a legitimate signed receiver cover whenever its pointwise value dominates the desired source kernel almost everywhere. Its price is exactly the corresponding sum of matched masses, with no unpriced intersection or union.

For the real receiver field, the precise integral version is as follows. Let Π be a nonnegative measure on actual nested pairs, with both marginals absolutely continuous relative to the ACTUAL du, and assume

    ∫(m_u+m_v) Π(du,dv)<∞.

Let α(u)≥0 be measurable with ∫αm du<∞, and c≥0. If

    K(y)≤c+∫α(u)c_u(y)du
                   +∫[c_u(y)−c_v(y)]Π(du,dv)         (4)

for almost every y, then

    ∫fK≤cW+∫αm du+∫(m_u−m_v)Π(du,dv).              (5)

The signed receiver price is α plus the first marginal density minus the second marginal density. Proof: the integrability assumption allows Tonelli on both nonnegative sides of the difference, then the exact full-f matching identities give (5). No f-density cap is used. If actual matching is known only du-almost everywhere, a singular choice of receiver atoms is not licensed by this formulation. A finite discrete LP witness does not by itself provide these continuum marginal densities.

Relative to omitting all negative prices, the exact saving is ∫m_v dΠ. A quantitative nested-size criterion is

    m_v/m_u≥(q_-/λ)(R_v/R_u)^n.                       (6)

For example, if R_v≥(1−δ/n)R_u with 0≤δ≤1, Bernoulli gives a retained fraction at least (q_-/λ)(1−δ). This is an honest dimension-independent price saving when such actual nested pairs cover the target; it is not a proof that enough such pairs exist or that the resulting total price is root order. Telescoping a chain produces only its endpoint shell and endpoint mass difference, not repeated independent savings.

## 4. A direct current-kernel subtraction, with its exact leakage

Fix an actual remaining pair (u,v). Suppose another ACTUAL receiver w satisfies Q_w⊂Q_v. Since 0≤φ_uv≤c_v,

    φ_uv≤c_v−c_w+φ_uv c_w.                           (7)

Thus

    ∫fφ_uv≤m_v−m_w+L_uv,w,
    L_uv,w=∫_(Q_u∩Q_w) f(y)ω_u(y)θ_v(y)dy.           (8)

Every source weight, including the strict past at y, remains in this leakage term. It is not replaced by the volume of Q_u∩Q_w. When Q_w∩Q_u is null, L_uv,w=0 and (7) is a genuine negative receiver-price certificate for the current target:

    φ_uv≤c_v−c_w,    ∫fφ_uv≤m_v−m_w.                  (9)

One may use any measurable assignment or distribution of actual w satisfying the stated containment; integration against the unchanged dΛ gives the same bound with its FULL integrated cost

    ∫dΛ(m_v−m_w+L_uv,w).                             (10)

This is a legitimate conditional certificate, not a claimed root payment: the right side of (10) still needs a finite small-X/root-W bound. To represent it as a continuum signed-du price, the induced receiver marginals must also satisfy Section 3's absolute-continuity and integrability requirements. In particular a source-dependent choice w(y) is not an actual common receiver price unless its whole resulting kernel and cost are separately justified.

If w is disjoint from Q_u and R_w≥(1−δ/n)R_v, (6) gives

    ∫fφ_uv/m_v≤1−(q_-/λ)(1−δ).                      (11)

This is a concrete saving on that actual pair and keeps the necessary scale ratio. It does not remove the remaining receiver-pair integration. It is also not a resale of the floor or p-overlap payments: it covers only the frozen residual φ_uv in (1).

## 5. Exact geometric availability criterion and remaining gap

Let R=R_u≥s=R_v≥a, and assume Q_u∩Q_v has positive volume. Define actual one-coordinate protrusions

    e_i=(2|u_i−v_i|−(R−s))_+.

There exists ANY axis-parallel cube of side at least a contained in Q_v and disjoint from Q_u up to null sets if and only if

    max_i e_i≥2a.                                    (12)

This is an existence statement in Euclidean space, not yet in the actual receiver field E.

Proof. A product cube W⊂Q_v has null intersection with Q_u precisely when at least one coordinate interval of W has null intersection with the corresponding interval of Q_u. In that coordinate W must fit into a one-sided component of the interval of Q_v outside that of Q_u. Since R≥s and the intervals overlap, at most one such component is nonempty and its length is e_i/2. A side-a cube fits only if this length is at least a. Conversely, if e_i/2≥a, place its i-th side there and choose any centered side-a intervals inside the other sides of Q_v. This proves (12), including boundary equality since f is L1.

Consequences are concrete. If every e_i<2a, no actual receiver in the original radius band can support the direct disjoint subtraction (9), regardless of source density or matching prices. In particular if R_v=a and the cubes have positive-volume intersection, all e_i<2a, so this direct mechanism is unavailable. Even when (12) holds, actual E and the fixed radius selector need not provide the required w; one cannot insert it as a new matching constraint. If only a nested w with overlap is available, the exact missing source cost is L_uv,w in (8).

The finite four-price mechanism therefore suggests using actual near-size LARGE contained cubes to carve a collectively overcovered region, rather than assuming the original far-mass small endpoint supplies a useful negative price. For a general field, what remains unproved is a shared family of such actual shells that covers the current marked kernel with integrable marginals and a root-order aggregate mass-difference bill. Equations (4)–(12) specify both the reusable certificate and the geometric/cost conditions that cannot be omitted. No general closure or new unconditional ledger fee is asserted.

## 6. Reproducible exact local checks

These checks certify the four-price decomposition and its exact cost, the geometric existence criterion on a rational finite grid, and the marked leakage inequality on positive-length source cells. The latter uses genuine piecewise-constant integrable f and all masses from that same f, but does not claim every test also satisfies the original q-band or far-mass residual. They are diagnostics of the asserted identities, not continuum-cover evidence.

~~~python
from fractions import Fraction as F
from itertools import product

checks=0
a=F(31,10080); b=F(187,30240); d=F(661,158976); neg=F(19181,1854720)
assert b+d==neg; checks+=1
assert a*F(3,2)+b*(2-1)+d*(F(3,2)-1)==F(143287,11128320); checks+=1
intervals=[(F(-3,4),F(3,4)),(F(-1,2),F(3,2)),(F(1,2),F(3,2)),(F(1,4),F(7,4))]
ends=sorted(set(sum(([l,r] for l,r in intervals),[])))
for x in [(l+r)/2 for l,r in zip(ends,ends[1:])]+[F(-2),F(2)]:
    cs=[int(l<=x<=r) for l,r in intervals]
    assert a*cs[0]+b*cs[1]+d*cs[3]-neg*cs[2]==a*cs[0]+b*(cs[1]-cs[2])+d*(cs[3]-cs[2])>=0
    checks+=1

R=F(2); amin=F(1)
for side in (F(1),F(3,2),F(2)):
    for v in product([F(i,2) for i in range(-4,5)],repeat=2):
        if any(abs(x)>=(R+side)/2 for x in v): continue
        excess=[max(2*abs(x)-(R-side),F(0)) for x in v]
        condition=max(excess)>=2*amin
        choices=[(x-(side-amin)/2,x+(side-amin)/2) for x in v]
        exists=False
        for w in product(*choices):
            contained=all(abs(w[i]-v[i])+amin/2<=side/2 for i in range(2))
            disjoint=any(abs(w[i])>=R/2+amin/2 for i in range(2))
            exists|=contained and disjoint
        assert condition==exists
        checks+=1

cells=[(F(i,4),F(i+1,4)) for i in range(-8,8)]
for pattern in range(5):
    densities=[F((i*(pattern+1)+2)%7) for i in range(len(cells))]
    marks=[F((i+pattern)%5,4) for i in range(len(cells))]
    # Q_v=[-1,1]. Every listed Q_w is an actual nested interval for this check.
    mv=sum(f*(r-l) for (l,r),f in zip(cells,densities) if -1<=(l+r)/2<=1)
    qv=mv/2
    for wc in (F(-1,2),F(0),F(1,2)):
        ws=F(1)
        mw=sum(f*(r-l) for (l,r),f in zip(cells,densities) if abs((l+r)/2-wc)<=ws/2)
        for uc in (F(-1),F(0),F(1)):
            us=F(3,2); value=F(0); leak=F(0)
            for (l,r),f,om in zip(cells,densities,marks):
                y=(l+r)/2
                cv=int(abs(y)<=1); cw=int(abs(y-wc)<=ws/2); cu=int(abs(y-uc)<=us/2)
                theta=max(1-qv/f,F(0)) if f else F(0)
                phi=om*theta*cu*cv
                assert phi<=cv-cw+phi*cw
                value+=f*(r-l)*phi; leak+=f*(r-l)*phi*cw
            assert value<=mv-mw+leak
            checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
~~~

Execution record: the embedded script was actually run with local Python 3 and returned `PASS 178 exact Fraction aggregate checks` (exit status 0). Pointwise leakage assertions inside the last block are not separately counted.
