from fractions import Fraction as F
from itertools import product, permutations
from pathlib import Path
import json

profile_checks=0
for a,b,c,d,e in product(range(3), repeat=5):
    Z=max(c+d,a+d,b+c,e)
    alpha,beta,gamma=Z-d,Z-c,Z-c-d
    assert min(alpha,beta,gamma)>=0
    assert alpha>=a and beta>=b and alpha-gamma>=c
    assert beta-gamma>=d and alpha+beta-gamma>=e
    candidates=[]
    for aa,bb in product(range(5),repeat=2):
        for gg in range(min(aa,bb)+1):
            if aa>=a and bb>=b and aa-gg>=c and bb-gg>=d and aa+bb-gg>=e:
                candidates.append(aa+bb-gg)
    assert min(candidates)==Z
    Zp=max(max(a,c)+max(b,d),e)
    assert Z<=Zp
    profile_checks+=1

data=json.loads(Path(__file__).with_name('r371_lp_input.json').read_text())['cases']
total_triples=cell_checks=0
for case in data[-2:]:
    A=case['A']
    L=list(map(F,case['g_exact']))
    r=case['receivers']
    m=list(map(F,case['b_exact']))
    strict=triples=0
    for i,j,k in permutations(range(len(r)),3):
        xa,xb,xc=[F(r[t]['centre']) for t in (i,j,k)]
        sides=[F(r[t]['R']) for t in (i,j,k)]
        if not(sides[0]==sides[1]==sides[2] and xa<xc<xb and xb-xa<=sides[0]):
            continue
        regions={s:[] for s in ['AO','BO','AC','BC','AB']}
        for p,l in enumerate(L):
            aa,bb,cc=[A[t][p] for t in (i,j,k)]
            assert not(cc and not(aa or bb))
            assert not(aa and bb and not cc)
            if aa or bb:
                key='AB' if aa and bb else ('AC' if aa and cc else
                    ('BC' if bb and cc else ('AO' if aa else 'BO')))
                regions[key].append(l)
        v={s:max(q,default=F(0)) for s,q in regions.items()}
        a,b,c,d,e=[v[s] for s in ['AO','BO','AC','BC','AB']]
        Z=max(c+d,a+d,b+c,e)
        alpha,beta,gamma=Z-d,Z-c,Z-c-d
        for p,l in enumerate(L):
            local=l if A[i][p] or A[j][p] else F(0)
            price=alpha*A[i][p]+beta*A[j][p]-gamma*A[k][p]
            assert price>=local
            cell_checks+=1
        assert m[i]==m[j]==m[k]
        assert alpha*m[i]+beta*m[j]-gamma*m[k]==Z*m[i]
        Zp=max(max(a,c)+max(b,d),e)
        if case['name']=='grid15_weighted' and (i,j,k)==(1,7,4):
            first_alpha=max(a,c,e/2)
            first_beta=max(b,d,e-first_alpha)
            first_gamma=min(first_alpha-c,first_beta-d,first_alpha+first_beta-e)
            first_discount=first_gamma*m[k]
            first_cost=first_alpha*m[i]+first_beta*m[j]-first_gamma*m[k]
            assert first_discount==F(1,144)
            assert first_cost==Z*m[i]==Zp*m[i]==F(237,11776)
            print('three_stage_target','preliminary_discount',first_discount,
                  'signed_optimum',Z*m[i],'positive_endpoint_optimum',Zp*m[i])
        strict+=Z<Zp
        triples+=1
    total_triples+=triples
    print(case['name'],'triples',triples,'strict_optimal_improvements',strict)
print('PASS profiles',profile_checks,'triples',total_triples,'source_cell_checks',cell_checks)
