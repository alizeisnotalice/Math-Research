from fractions import Fraction as F
from itertools import product

checks=0
a=F(31,10080); b=F(187,30240); d=F(661,158976); neg=F(19181,1854720)
assert b+d==neg; checks+=1
assert a*F(3,2)+b*(2-1)+d*(F(3,2)-1)==F(143287,11128320); checks+=1
intervals=[(F(-3,4),F(3,4)),(F(-1,2),F(3,2)),(F(1,2),F(3,2)),(F(1,4),F(7,4))]
ends=sorted(set(sum(([l,r] for l,r in intervals),[])))
for x in [(l+r)/2 for l,r in zip(ends,ends[1:])]+[F(-2),F(2)]:
    cs=[int(l<=x<=r) for l,r in intervals]
    assert a*cs[0]+b*cs[1]+d*cs[3]-neg*cs[2]==a*cs[0]+b*(cs[1]-cs[2])+d*(cs[3]-cs[2])>=0
    checks+=1

R=F(2); amin=F(1)
for side in (F(1),F(3,2),F(2)):
    for v in product([F(i,2) for i in range(-4,5)],repeat=2):
        if any(abs(x)>=(R+side)/2 for x in v): continue
        excess=[max(2*abs(x)-(R-side),F(0)) for x in v]
        condition=max(excess)>=2*amin
        choices=[(x-(side-amin)/2,x+(side-amin)/2) for x in v]
        exists=False
        for w in product(*choices):
            contained=all(abs(w[i]-v[i])+amin/2<=side/2 for i in range(2))
            disjoint=any(abs(w[i])>=R/2+amin/2 for i in range(2))
            exists|=contained and disjoint
        assert condition==exists
        checks+=1

cells=[(F(i,4),F(i+1,4)) for i in range(-8,8)]
for pattern in range(5):
    densities=[F((i*(pattern+1)+2)%7) for i in range(len(cells))]
    marks=[F((i+pattern)%5,4) for i in range(len(cells))]
    # Q_v=[-1,1]. Every listed Q_w is an actual nested interval for this check.
    mv=sum(f*(r-l) for (l,r),f in zip(cells,densities) if -1<=(l+r)/2<=1)
    qv=mv/2
    for wc in (F(-1,2),F(0),F(1,2)):
        ws=F(1)
        mw=sum(f*(r-l) for (l,r),f in zip(cells,densities) if abs((l+r)/2-wc)<=ws/2)
        for uc in (F(-1),F(0),F(1)):
            us=F(3,2); value=F(0); leak=F(0)
            for (l,r),f,om in zip(cells,densities,marks):
                y=(l+r)/2
                cv=int(abs(y)<=1); cw=int(abs(y-wc)<=ws/2); cu=int(abs(y-uc)<=us/2)
                theta=max(1-qv/f,F(0)) if f else F(0)
                phi=om*theta*cu*cv
                assert phi<=cv-cw+phi*cw
                value+=f*(r-l)*phi; leak+=f*(r-l)*phi*cw
            assert value<=mv-mw+leak
            checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
