# R372 independent audit — FINAL PASS

Status: FINAL PASS for the stated conditional signed-shell and restricted three-cube certificates, their actual-field requirements, finite diagnostics and final integration. No unresolved correction was found. Only this audit was edited; no repository/author file was changed. The independent screen below preceded reading the author proofs. No general root-order payment is certified and R371's ledger remains unchanged.

## Actual nested-cube shell prices
For ACTUAL available source-capture cubes C subset A intersect B and coefficients b,d>=0, the function b(1_A-1_C)+d(1_B-1_C) is nonnegative, supported on the two respective shells. If it pointwise dominates the target nonnegative source load (with all other marks retained), multiplying by the actual f>=0 and integrating gives cost b(m_A-m_C)+d(m_B-m_C). This is exact and needs no density ceiling. Geometry showing a hypothetical cube fits does not supply it as a receiver of the original actual selector or furnish its matched mass qR^n. Any edge-measure version must have genuine receiver-Lebesgue marginals or their explicitly budgeted weights, and must keep the residual on any alleged inner-cube leakage.

## Equal-side three-cube scalar certificate
Let the same-side A,B differ only along one coordinate and C have intermediate coordinate center, with C subset A union B and A intersect B subset C. The five relevant regions are A minus C, B minus C, (A intersect C) minus B, (B intersect C) minus A, and A intersect B (contained in C). Let their nonnegative load upper bounds be a0,b0,c,d,e. For nonnegative alpha,beta,gamma, use alpha1_A+beta1_B-gamma1_C. Its five values are alpha,beta,alpha-gamma,beta-gamma,alpha+beta-gamma. Setting

Z=max(c+d,a0+d,b0+c,e), alpha=Z-d,beta=Z-c,gamma=Z-c-d

makes all three coefficients nonnegative and covers the five loads. If all three ACTUAL matched masses equal m, its exact cost is mZ. In the class alpha,beta,gamma>=0, every feasible cover has alpha+beta-gamma>=the four displayed lower bounds, hence this is optimal when the corresponding region constraints are genuinely imposed. Empty regions require care: their essential supremum should be defined0, and constraints on them must not be mistaken for necessary pointwise inequalities. For the stated same-side/intermediate geometry the paired empty-region structure can justify the same formula, but the final author proof must address degeneracies or explicitly restrict to nonempty regions.

The restriction gamma>=0 is essential to this particular optimum. If it is removed, c=d=1,a0=b0=e=0 can be covered by alpha=beta=0,gamma=-1, at cost m instead of2m; this is a positive C price, outside the specified class. No conclusion about all finite signed receiver-price certificates follows. If equal matching masses are absent, the displayed coefficients still provide a cover but its cost is alpha m_A+beta m_B-gamma m_C, not mZ and not automatically optimal.

For a nonnegative load, zeros outside A union B cause no extra issue only if no outside target load has been omitted. If any additional source support exists there it must receive its own intercept/cover or stay in the remainder. Null cube faces cause no f mass for L1 sources. In actual geometric full-f matching, equality of all three masses may further force vanishing f on some subregions; this can make nominal load constraints nonsharp but does not justify deleting constraints without specifying the almost-everywhere reference measure.

## Actual local computation and boundary of this screen
A local Python Fraction exercise actually passed244 scalar configurations:243 nonnegative five-load tuples verified the stated candidate cover/coefficient signs/cost; one explicit gamma-negative example checked the necessity of that class restriction. This is scalar algebra, not a native cube field or original hard-gate fixture, and is separate from author/parent totals. No R372 author file was read before this screen. The bounded author review, final integration and byte bindings follow below.


## Final source author review
Read /tmp/r372_source.md in full, including its complete embedded code. PASS. The exact current remaining kernel is f times phi=omega(1-q_v/f)+c_uc_v with zero convention on f=0, and dLambda retains the original(1-p) factor, actual mu-derived weights,clock,J,strict past and pair masks. Thus this note truly targets Gjoint. It neither resets the source nor spends an earlier negative square/floor credit.

The R371 four-price example is exactly a positive actual A price plus two actual-parent-minus-common-child shells: c=b+d and C subset B intersect D. Its stated rational cost is correct. Nonnegativity alone would not establish target domination; the manuscript correctly relies on the previously all-source-cell certified target for that finite diagnostic.

For general real receivers, the measure on nested actual pairs has both marginals absolutely continuous relative to ACTUAL du and finite integral(m_u+m_v). Together with the positive actual-cube-price integrability, this justifies the finite signed source/mass identity and genuine receiver-price densities. If matching were given only du-almost everywhere, singular selected receiver atoms are not licensed. Pointwise target cover and a cost bound are independent necessary obligations; neither follows from containment. The lower bound m_v/m_u>=(qminus/lambda)(R_v/R_u)^n and its Bernoulli near-size consequence are correctly oriented. Chain telescoping pays endpoint mass difference once, not repeated independent savings.

For an actual nested w in v, phi<=c_v-c_w+phi c_w holds pointwise. Its integral is m_v-m_w plus the ORIGINAL marked leakage over Qu intersect Qw; no boundary-volume replacement is made. Null intersection makes leakage zero only for L1 source, and actual availability/receiver-marginal integrability must still be checked before aggregating. The existence criterion max_i e_i>=2a is correct for positive-volume Qu intersect Qv,R>=s>=a: null intersection of axis product cubes requires one disjoint coordinate interval, whose available one-sided outside length is e_i/2. Equality fits with a null touching face. A geometric inscribed cube is not thereby an actual receiver. For s=a, positive overlap indeed makes every e_i<2a. No new general budget follows.

The178 aggregate Fraction diagnostics check actual rational shell prices, finite geometric availability and marked leakage on true piecewise-constant L1 intervals. They do not realize all original q/past gates. Inner pointwise checks are not separately included. The parent actually reran this script; the reviewer did not duplicate it.

## Final three-cube author review and empty-region resolution
Read /tmp/r372_geometry.md in full, including the exact-code block. PASS. The final theorem assumes0<displacement<=R and0<t<1. Its four regions OA,OB,IA,IB all have strictly positive Lebesgue volume: their exceptional-coordinate lengths are respectively t*d,(1-t)*d,(1-t)*d,t*d. Thus their four essential-supremum constraints are genuinely necessary in the restricted-class lower-bound proof. Only the triple intersection D can be null, precisely at d=R. Its e is0 and z>=e follows from z=(alpha-gamma)+(beta-gamma)+gamma>=c+d0>=0. The preliminary generic empty-region concern is fully resolved by these actual hypotheses; no broader empty-set theorem is claimed.

The cover values alpha,beta,c,d0,Z and all nonnegative coefficient signs are correct. Exact mass pricing uses the actual m_A,m_B,m_C; equal-mass optimum mZ requires the stated extra equalities and the restricted alpha,beta,gamma>=0 class. A positive middle price and other actual receiver prices are intentionally excluded. Optimal two-positive-endpoint cost Zplus=max(max(a,c)+max(b,d0),e) follows alpha>=max(a,c),beta>=max(b,d0),alpha+beta>=e. The manuscript distinguishes a discount relative to fixed positive coefficients from a discount relative to this OPTIMAL endpoint cover.

The finite/countable aggregation preserves the original linear load and its unpriced remainder, with explicit absolute signed mass-price summability. The source load is the original linear G before the floor/joint split, whereas the source-note phi covers Gjoint. These are alternative conditional estimates, not fees appended to each other or to the R371 paid ledger. Arbitrary actual selectors may supply no suitable equal-side intermediate receiver. No general family, aggregate root cost or remaining-load payment is proved.

## Code, finite outcomes and main/ledger scope
Read the standalone source and geometry scripts. Source matches its unique embedded block exactly after stripping outer whitespace. Geometry differs from its embedded block ONLY by replacing the absolute/tmp input path with Path(__file__).with_name('r371_lp_input.json'), making the provided frozen input portable. No arithmetic or geometry logic changed. The source input is the previously reviewed complete real-interval source-cell/matching fixture, with finite receiver QUADRATURE and lowered diagnostic gates; it is not a native high-dimensional hard-field realization.

The parent actually reran178 source checks,243 five-region formula-versus-integer-exhaustion profiles,40 actual finite triples and640 full-source-cell coverage checks. These are reported separately rather than summed into a success rate. The code's243 scalar profiles support the analytic lower-bound proof but do not prove arbitrary real load coefficients by enumeration. All40 finite triples have ZERO strict improvement over their optimal two-endpoint cover. The preliminary1/144 discount on a fixed nonoptimal cover disappears after the correct optimum comparison, exactly as the notes/main state. This is a diagnosis of the tested same-side mechanism, not a universal obstruction to signed receiver geometry. Reviewer244 scalar checks are separate and not added to parent counts. No full pipeline was rerun during this review.

Read the final main and README and checked their stated hashes. PASS. They retain the entire R371 hard-slot budget and explicitly insert NO new general price/absorption fee. The actual shell certificate and three-cube restricted optimum are conditional tools; their aggregate low cost and residual remain unpaid. The complete inherited R371 ledger is bound below and must not be combined with these replacements as an extra negative credit. Entrance2,outer128/119 and all independent unresolved slots remain intact. No finite model scanning outcome is claimed to certify the original hard difficulty or n asymptotics.

The unresolved objective is still a common actual-receiver cover with integrable source/receiver measures and a controlled TOTAL mass-price cost, or a direct bound for the marked residual. General soft/crossing/entrance, contract-exterior heavy/distance/low-pe/scale/threshold regimes, historical initial/deletion/future-source time atoms, H choice, source and physical-scale aggregation, outer integration, truncation and limits remain unproved as in R371. No PDF compilation, archive packaging, Git/publication, or comprehensive historical audit is certified. No outstanding correction; final bounded disposition PASS.

## Frozen final byte bindings
SHA256 applies to the exact reviewed bytes. The audit hash is supplied separately after saving.

- `/tmp/r372_main.md` — `5722c22954220fe04aeefeeb855410f5b58a73af86e4c936e01b3b6678804640`
- `/tmp/r372_readme.md` — `2685105bb791506f0d1129241a2fbea6dc333c30b142cf2097f7f9469757905b`
- `/tmp/r372_source.md` — `aff895db1b617efa8417a82cefe92781d3b6eced1de5945cb2fbf622e24f16b9`
- `/tmp/r372_geometry.md` — `440f165f4a31762034c796655f499f1e94a4084c8c861d58630d6401ed8901aa`
- `/tmp/r372_source_check.py` — `337db2994d1581b45ca7a114436fb6654a37cf091c60b3b08fe11b494982b9e8`
- `/tmp/r372_geometry_check.py` — `04a2cd5329b3736ddc89c543c0f24dd20776aac29af51afb0fc11867aab9e107`

Necessary frozen input and inherited contracts:

- `/tmp/r371_lp_input.json` — `4b3c79631b526510c48f875656c1bd01f31346394fdeaa4a93f773c7caabca53`
- `/tmp/r371_main.md` — `fab564727af22c6a95f90f25678875b67cfd02084f0abd1a03a5004df9a2c558`
- `/tmp/r371_ledger.md` — `4ad01abea21c4afe8d84fb50ddfb306cde298381f62065cbd39b6891875655d3`
- `/tmp/r371_audit.md` — `17061699676853791326b4bed45017af5100b6b55c96c62c1aa57bf19e1b3490`
- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`

Frozen FINAL PASS; later changes require renewed review/binding. No further bounded task work remains.
