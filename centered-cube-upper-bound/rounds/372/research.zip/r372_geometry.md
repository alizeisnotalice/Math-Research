# R372: an explicit three-cube signed-price structure, without a global payment

## 1. Scope and exact source load

The screened claim is a local, explicit signed receiver-price certificate. It is not a claim that the general remaining R371 integral is paid. All masses, radius selectors, J, strict-past gates and clocks are frozen from the same full f. No source coordinate independence or m du reversibility is used.

Use the original linear remainder G=G_out,not-Bplus before the R371 floor/excess split. In R370 notation its exact source load is
\[
 L(y)=\int_E\frac{dv}{m_v}\,c_v(y)F_v(y),\qquad
 F_v(y)=\frac1{h_*}\int_E\frac{du}{R_u^n}
 S(u,v)(1-m_v/m_u)\omega_u(y)c_u(y).
\]
Thus G=∫fL. All original sourcewise gates stay inside ω_u, and S is the original strict far-mass, outside-center, not-Bplus mask. This L is measurable, nonnegative and bounded under the finite receiver-measure contract. The following certificate works for any measurable nonnegative subload L_0≤L supported in the union of its two endpoint cubes. It therefore applies to the actual L, not an independent surrogate source.

The negative-middle price structure below is obtained by a direct five-region calculation. Only finite weak duality is needed; the Lagrange–Farkas skill was used to audit signs and distinguish this certificate from an infinite-dimensional existence or attainment claim.

## 2. Geometric support and closed-form certificate

Take three ACTUAL receivers with equal side R and centers
\[
 x_A=x,\quad x_B=x+d e_i,\quad x_C=x+t d e_i,
 \qquad 0<d\le R,\quad0<t<1.
\]
Every other center coordinate agrees. Then C⊂A∪B and A∩B⊂C. These follow by intersecting the three one-dimensional intervals in coordinate i; their other coordinate intervals coincide.

Partition U=A∪B into
\[
 O_A=A\setminus C,\quad O_B=B\setminus C,\quad
 I_A=(A\cap C)\setminus B,\quad I_B=(B\cap C)\setminus A,\quad D=A\cap B.
\]
Let a,b,c,d_0,e be the respective Lebesgue essential suprema of L_0 on these five regions. They are finite; an empty region has supremum zero. When d=R, D is null and its bound e=0 is automatic. (The symbol d_0 is a load bound, not the center displacement d.) Put
\[
 Z=\max\{c+d_0,\ a+d_0,\ b+c,\ e\},
\]
\[
 \alpha=Z-d_0,\quad \beta=Z-c,\quad \gamma=Z-c-d_0.
\]
All three are nonnegative, and the explicit signed cover is
\[
 L_0\le \alpha1_A+\beta1_B-\gamma1_C
 \quad\text{Lebesgue-a.e. on the entire source space}. \tag{1}
\]
Indeed the right side has respective values α, β, c, d_0, Z on O_A,O_B,I_A,I_B,D, and is zero off U. These values dominate the five suprema by construction.

Full-source matching therefore prices it exactly:
\[
 \int fL_0\le
 (Z-d_0)m_A+(Z-c)m_B-(Z-c-d_0)m_C. \tag{2}
\]
This is a genuine negative receiver price when γ>0. Its improvement over the same endpoint coefficients without subtraction is exactly γ m_C, with no density assumption. It must not be mistaken for improvement over the OPTIMAL nonnegative cover: that comparison is separate below. Formula (2) uses actual masses even when q_A,q_B,q_C differ.

There is no claim that an arbitrary actual radius selector supplies such triples. Inventing an intermediate receiver with a desired side would invalidate matching and is not allowed.

## 3. Exact restricted-class optimum and honest comparison

If m_A=m_B=m_C=m, formula (2) equals mZ. It is the exact minimum in the restricted class
\[
 \alpha1_A+\beta1_B-\gamma1_C\ge L_0,\qquad\alpha,\beta,\gamma\ge0.
\]
To prove the lower bound, put x=α−γ, y=β−γ. The five-region constraints imply x≥c, y≥d_0, α≥a, β≥b, and α+β−γ≥e. The normalized cost z=α+β−γ therefore satisfies
\[
 z=x+y+\gamma\ge c+d_0,\quad
 z=\alpha+y\ge a+d_0,\quad
 z=\beta+x\ge b+c,\quad z\ge e.
\]
The coefficients in §2 attain z=Z.

For comparison, using ONLY the two nonnegative endpoint prices has exact normalized optimum
\[
 Z_+=\max\{\max(a,c)+\max(b,d_0),\,e\}. \tag{3}
\]
Thus a strict improvement in this specific comparison occurs exactly when Z<Z_+. For instance a=b=1 and c=d_0=e=0 gives Z=1 versus Z_+=2. This is only a geometric load example; it is not claimed to arise from the original hard kernel.

These are restricted price classes. In particular a positive middle price and all other actual receiver prices are excluded from both comparisons. No conclusion about the optimum over all nonnegative receiver prices follows.

## 4. Aggregation and exact unpaid balance

For any finite collection of such actual triples and subloads L_j≥0 satisfying Σ_jL_j≤L, apply (2) to each. With L_rem=L−Σ_jL_j,
\[
 G\le\int fL_{\rm rem}+
 \sum_j\left[\alpha_jm_{A_j}+\beta_jm_{B_j}-\gamma_jm_{C_j}\right]. \tag{4}
\]
All terms retain the original source load and gates. Countable aggregation is also legitimate if
Σ_j(α_jm_Aj+β_jm_Bj+γ_jm_Cj)<∞; this is absolute integrability of the signed price against the actual matching data.

Equation (4) is an explicit priced conditional certificate, not a root-order estimate. To derive the requested general budget one still needs an actual family of triples/subloads whose total price has the desired εX_q+Cε√n log^A(n+2)W bound AND whose remaining integral is paid. Neither property is proved here. Radius variation may prevent any useful same-side triples, and the sourcewise marked load may have no inner-region slack. The remaining difficulty is exactly a globally cost-controlled, actual-receiver exchange structure, not the weak-duality direction. The next relevant structure would use unequal-side actual cubes jointly, checking all source cells of their common cover and their actual signed mass cost; the present five-region calculation does not transfer to that geometry without a new coverage proof.

This note concerns a replacement estimate for original G. It is not appended to the R371 ledger as another negative credit after its joint floor payment. No new receipt is inserted into that ledger.

## 5. Local exact tests and outcome

The code below was actually executed. It independently checks the closed formula by exhaustive integer-price search on 243 five-region load profiles, and checks all 40 applicable triples in the two existing R371 15-receiver interval fixtures. Their source load contains the actual finite clock, q matching, J and strict past of that diagnostic fixture.

The actual three-stage screen was: (i) a preliminary positive endpoint cover on weighted-grid triple (1,7,4), zero-based, admitted subtraction of exactly 1/144; (ii) optimization of that same two-endpoint positive cover removed the apparent gain, both optima being 237/11776; (iii) the complete 40-triple scan confirmed zero strict optimal improvements. The saved code reproduces all three stages.

Result: 243 formula-versus-exhaustive optimum checks pass; all 640 complete-source-cell inequalities pass; both actual finite fixtures have zero strict improvements over their optimal two-endpoint covers. An initially observed negative-price discount in one fixture was only relative to a nonoptimal positive cover; the optimum comparison eliminates it. This is not a counterexample to a more general signed geometry, and no further adversarial search was conducted.

These R371 fixtures use finite receiver quadrature and diagnostic one-dimensional gates. They are not certified native high-dimensional hard-branch examples. Their known globally useful signed certificate is not explained by this same-side three-cube structure.

No new general root-order payment was obtained. The deliverable is the explicit, optimally priced restricted geometric certificate (1)–(3), its lawful aggregation (4), and its quantified failure to improve the tested actual-load fixtures.

~~~python
from fractions import Fraction as F
from itertools import product, permutations
from pathlib import Path
import json

profile_checks=0
for a,b,c,d,e in product(range(3), repeat=5):
    Z=max(c+d,a+d,b+c,e)
    alpha,beta,gamma=Z-d,Z-c,Z-c-d
    assert min(alpha,beta,gamma)>=0
    assert alpha>=a and beta>=b and alpha-gamma>=c
    assert beta-gamma>=d and alpha+beta-gamma>=e
    candidates=[]
    for aa,bb in product(range(5),repeat=2):
        for gg in range(min(aa,bb)+1):
            if aa>=a and bb>=b and aa-gg>=c and bb-gg>=d and aa+bb-gg>=e:
                candidates.append(aa+bb-gg)
    assert min(candidates)==Z
    Zp=max(max(a,c)+max(b,d),e)
    assert Z<=Zp
    profile_checks+=1

data=json.loads(Path('/tmp/r371_lp_input.json').read_text())['cases']
total_triples=cell_checks=0
for case in data[-2:]:
    A=case['A']
    L=list(map(F,case['g_exact']))
    r=case['receivers']
    m=list(map(F,case['b_exact']))
    strict=triples=0
    for i,j,k in permutations(range(len(r)),3):
        xa,xb,xc=[F(r[t]['centre']) for t in (i,j,k)]
        sides=[F(r[t]['R']) for t in (i,j,k)]
        if not(sides[0]==sides[1]==sides[2] and xa<xc<xb and xb-xa<=sides[0]):
            continue
        regions={s:[] for s in ['AO','BO','AC','BC','AB']}
        for p,l in enumerate(L):
            aa,bb,cc=[A[t][p] for t in (i,j,k)]
            assert not(cc and not(aa or bb))
            assert not(aa and bb and not cc)
            if aa or bb:
                key='AB' if aa and bb else ('AC' if aa and cc else
                    ('BC' if bb and cc else ('AO' if aa else 'BO')))
                regions[key].append(l)
        v={s:max(q,default=F(0)) for s,q in regions.items()}
        a,b,c,d,e=[v[s] for s in ['AO','BO','AC','BC','AB']]
        Z=max(c+d,a+d,b+c,e)
        alpha,beta,gamma=Z-d,Z-c,Z-c-d
        for p,l in enumerate(L):
            local=l if A[i][p] or A[j][p] else F(0)
            price=alpha*A[i][p]+beta*A[j][p]-gamma*A[k][p]
            assert price>=local
            cell_checks+=1
        assert m[i]==m[j]==m[k]
        assert alpha*m[i]+beta*m[j]-gamma*m[k]==Z*m[i]
        Zp=max(max(a,c)+max(b,d),e)
        if case['name']=='grid15_weighted' and (i,j,k)==(1,7,4):
            first_alpha=max(a,c,e/2)
            first_beta=max(b,d,e-first_alpha)
            first_gamma=min(first_alpha-c,first_beta-d,first_alpha+first_beta-e)
            first_discount=first_gamma*m[k]
            first_cost=first_alpha*m[i]+first_beta*m[j]-first_gamma*m[k]
            assert first_discount==F(1,144)
            assert first_cost==Z*m[i]==Zp*m[i]==F(237,11776)
            print('three_stage_target','preliminary_discount',first_discount,
                  'signed_optimum',Z*m[i],'positive_endpoint_optimum',Zp*m[i])
        strict+=Z<Zp
        triples+=1
    total_triples+=triples
    print(case['name'],'triples',triples,'strict_optimal_improvements',strict)
print('PASS profiles',profile_checks,'triples',total_triples,'source_cell_checks',cell_checks)
~~~
