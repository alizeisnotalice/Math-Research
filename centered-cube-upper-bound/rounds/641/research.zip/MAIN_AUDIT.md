# R641 主稿限定最终审核

对象：`/tmp/ccu_r641_final/REPORT.tex`。

审核冻结 SHA256：
`1a027d3e50325eeef50f02a52aa7411cd93c1f543c0658ca364d28a1accc3698`。

**判定：指定 §1、§2、§4、§5 的完整账、条件和结论范围通过，未发现阻断问题。一般根阶主预算仍未证明。** §3 的一般 C3k 几何证明及对应独立复现按主代理分工由另一独审负责，本审不替代、不重跑该项。

## 1. 完整账与实际新权

§1 正确区分旧 KKT μ 与原输入 f。新 α 使用同一次 Z、新顺序、真实正增量，删零扩 0。`S=M−Q′=∫(1−Lα^old)dμ=Uα+Σα capture` 及 `D=W−RM+RS` 正确；固定 Z/order 的 source 不变性正确。

变形 pieces 账按冻结 E_j 定义保留实际 O、F，S 已含 deletion/barrier 信用，没有重复添加。主稿明确 (2) 未证，固定 N/near/恢复接口不计新增收益。

## 2. canonical cells、reach/join 与局部分母

完整旧 active K 的 coarse T_K、old λ 全正条件及真实 AC 来源实现正确；没有先按新零行投影 K。reach 和 expanded join 都能通过逐坐标 Helly 使 `α_N/s_K` 成为完整新 packing 内的可行测试，含 K∩J 为空、s=0、N 为空的边界。

式 (5)–(7) 使用同一份真实新 KKT 来源 ν′ 与实际梯度。`ν′(U_K)` 是局部新来源质量，非旧 μ；各 U_K 可重叠，主稿未把它们当互斥资源相加。local 分母非空时正，空项定 0。

`G≤S` 是下界证书，不是 S 的等式；主稿保留 S−G，且禁止和 (3) 重复加账。式 (8) 清楚标为要用该证书付款时尚需的全量充分条件，没有被报告成一般闭合。非hard 压力例只能表明这份局部证书不完备，不能上界 actual D。

## 3. §4 来源交换及新增不等量费用

(11) 用准确 old membership 记录移出质量。剩余来源在 A_j 的质量是 `m_j−Σ_{K∋j}f_K`；Aj⊂Cj，补入同一 Z 的实际 positive cliques 后即可保证新行≥m_j。f_K≤z_K、zero-mass 约定、共享旧包总支出和额外 old labels 的补偿均保留。

τ 是实际非负 AC capacity 来源，质量为 `M−Σf+Σh`，不要求 τ 保持旧矩，也不冒充新 regularized KKT 来源。因实际 α packing 可行，Q′≤||τ||，故 (13) 方向正确；它明确是 sufficient，不穷尽实际 S。

等量 cycle 的节省 `(k−2)f` 账正确。新增 (14) 也正确：每个内部 pair 补 `max(ell_r,r_r)`，selected clique 补 `max_r(ell_r+r_{r−1})`，总节省恰为

`Σmin(ell_r,r_r)−max_r(ell_r+r_{r−1})`。

共享 selected 行最后一项不能丢，主稿已保留且只用净正批次。这是有条件的完整交换模板，不证明任意 hard family 有足量可达交换。

## 4. §5 范围与归档

半幅 child 的包含关系及 5/(48n) 余量正确；low-growth 仅控制旧 v，不控制新 w、删除重分配或 owner 价格。主稿明确保留这些费用，没有把半幅区域永久限制成动作全域。

reach 的逐行最大化只生成候选；真实 order/w/α 仍需重算。最大值集合不闭时只取 receiver 近上确界的范围表述正确。没有把 finite nonhard 控制、产品公式、(8)/(13) 或 clique 数当作一般上界。

建议最小归档按主代理方案：详细 REPORT、本精简审核、`global_contact/check.py`、一份对应 `results.json`/hash，以及 C3k 独立 verify 与实际复现收据。一般 C3k 的 proof/verify 结论须一并到位；本审不重复数值。既有 C5 reach 预检被最终证书覆盖，不需再次收入重复脚本、数据或旧研究包。

**最终：上述 SHA 主稿的限定数学表述通过；未证明原完整 hard 目标。未修改主稿、未 Git、未 spawn。完成后停止待命。**
