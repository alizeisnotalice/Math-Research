#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import combinations
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from hashlib import sha256
import json,sys,time,os,resource
import numpy as np
sys.set_int_max_str_digits(0)
def dig(x):return sha256(str(x).encode()).hexdigest()
def work(k):
 clock=time.perf_counter();cpu=time.process_time();N=3*k;n=N*(N-3)//2;a=32*n;P=F(a+1,a)**n;eps=F(1,64)/P;u=2*eps/a**n;t=u/n;lo=F(7,8)*t;hi=t
 assert k>=3 and k%2==1 and 0<u<F(1,7) and F(1)/(1-F(7,8)*u)<1+u and 0<t<F(1,100)
 selected=set(range(0,N,3));assert len(selected)==k
 cycle={tuple(sorted((i,(i+1)%N))) for i in range(N)}
 # Every actual coordinate corresponds to one nonedge; values are 0,+/- (2+t)/2, or +/-3/2.
 # Nonnegative pair gaps encode 0, (2+t)/2, 3/2, 2+t, 3 by ranks 0..4.
 # No comparison uses floating point or rounded epsilon: ordering follows 0<t<1.
 lookup=np.array([0,0,1,2,3,0,4],dtype=np.uint8);actual=np.zeros((N,N),dtype=np.uint8);coord_count=0;special=0
 for u0,v0 in combinations(range(N),2):
  if (u0,v0) in cycle:continue
  arr=np.zeros(N,dtype=np.int8);amp=2 if (u0 in selected and v0 in selected) else 3
  if amp==2:special+=1
  arr[u0]=amp;arr[v0]=-amp
  diff=np.abs(arr[:,None]-arr[None,:]);actual=np.maximum(actual,lookup[diff]);coord_count+=1
 assert coord_count==n and special==k*(k-1)//2
 # The computed actual distances determine the graphs, then check the requested identities.
 assert all(actual[i,j]>0 for i,j in combinations(range(N),2))
 old={(i,j) for i,j in combinations(range(N),2) if actual[i,j] in (1,2)}
 expanded={(i,j) for i,j in combinations(range(N),2) if actual[i,j] in (1,2,3)}
 assert old==cycle
 clique_edges=set(combinations(sorted(selected),2));assert expanded==cycle|clique_edges
 adj=[0]*N
 for i,j in expanded:adj[i]|=1<<j;adj[j]|=1<<i
 for i,j in old:assert adj[i]&adj[j]==0
 triangles=[]
 for i,j,l in combinations(range(N),3):
  if (i,j) in expanded and (i,l) in expanded and (j,l) in expanded:triangles.append((i,j,l));assert {i,j,l}<=selected
 assert len(triangles)==k*(k-1)*(k-2)//6
 # Maximal clique types follow by clique containment of triangles; no non-selected vertex in any triangle.
 # Construct disjoint partition into selected clique and k internal cycle edges.
 partition=[tuple(sorted(selected))]+[(3*i+1,3*i+2) for i in range(k)]
 assert sorted(q for group in partition for q in group)==list(range(N))
 assert all(all(tuple(sorted(pair)) in expanded for pair in combinations(group,2)) for group in partition)
 # Complete packing check on maximal clique types: selected clique and every remaining edge.
 alpha=[F(1,k) if j in selected else F(1,2) for j in range(N)]
 assert sum(alpha[j] for j in selected)==1
 assert all(alpha[i]+alpha[j]<=1 for i,j in expanded)
 assert F(1,k)+F(1,2)<1
 # Unit-clique KKT for positive disjoint receiver increments w=m/a^n.
 d=2**n;m=F(d)*(1+u);v=F(d,a**n);w=m/a**n;M=F(N,2)*m;Qold=F(N,2)*d;V=N*v;R=F(2,a**n);Qnew=(k+1)*m;S=M-Qnew
 assert M==Qold+eps*V and (m-d)/2==eps*v and S==F(k-2,2)*m
 # Every old edge has coordinate distance at most 3/2, so its intersection contains a positive-volume box.
 assert F(2)-F(3,2)>0
 dual=[m+eps*w/alpha[g[0]] for g in partition]
 assert all(h>0 for h in dual)
 for i in range(N):assert sum(dual[j] for j,g in enumerate(partition) if i in g)==m+eps*w/alpha[i]
 assert all(sum(alpha[i] for i in g)==1 for g in partition)
 # Old-distance smallest gap >=1, and every shift ≤δ<t, so all new receivers disjoint.
 assert 1-2*hi>2*(1+hi)/a
 W=N*w;D=W-R*Qnew;assert D==F(k-2)*m/a**n
 assert all(isinstance(x,F) for x in (P,eps,u,t,lo,hi,m,v,w,M,Qold,V,R,Qnew,S,W,D))
 return {'k':k,'N':N,'n':n,'coordinate_count_checked':coord_count,'selected_nonedge_coordinates':special,'old_edges_checked':len(old),'new_edges_checked':len(expanded),'triangles_checked':len(triangles),'all_old_edges_have_no_common_new_neighbor':True,'all_new_maximal_cliques_covered_by_types':True,'receiver_disjoint_all_Z':True,'new_alpha_selected':str(F(1,k)),'new_alpha_other':'1/2','source_capture_all_Z_zero':True,'Qnew_over_m':str(F(k+1)),'S_over_m':str(F(k-2,2)),'D_over_m_over_a_power_n':str(F(k-2)),'u_sha256':dig(u),'t_sha256':dig(t),'t_bits':[t.numerator.bit_length(),t.denominator.bit_length()],'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-clock,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 T=time.perf_counter();stages=[[3,5,7],[9,11,13],[15,17,19,21,23,25]];runs=[]
 for stage in stages:
  ts=time.perf_counter();workers=min(os.cpu_count() or 1,15,len(stage))
  with ProcessPoolExecutor(max_workers=workers) as p:res=list(p.map(work,stage))
  runs.append({'k':stage,'workers':workers,'wall_s':time.perf_counter()-ts,'results':res})
 print(json.dumps({'stages':runs,'python':sys.version,'numpy':np.__version__,'wall_s':time.perf_counter()-T,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
