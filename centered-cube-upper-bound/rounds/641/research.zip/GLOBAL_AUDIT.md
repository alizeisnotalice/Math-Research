# R641 全局构造与来源交换终审

**通过范围：** 一般奇数 k≥3 的真实方体构造、全动作局部零价格、整个旧 KKT 来源类的升级、Z=0 的完整双 KKT/正收益，以及同一动作下的 fractional source-exchange 模板均成立。**仍未证明一般 hard 分支目标；本族不能反驳根阶目标，也不能证明共同全局动作的存在策略失败。**

最终主稿 `/tmp/ccu_r641_final/REPORT.tex` SHA-256：
`1a027d3e50325eeef50f02a52aa7411cd93c1f543c0658ca364d28a1accc3698`。

先据主代理命题独立推导，再对照 `global_contacts.md`、数值程序/报告及上述最终主稿。未发现实质数学错误。只写本文件，不 Git、不 spawn、不改他人文件。

## 1. 一般 k、维数和全部真实 cliques

N=3k 为奇数，n=N(N−3)/2≥27，恰为旧环全部非边数。参数精确化简为

\[
u=2\epsilon/a^n=1/[32(a+1)^n],\quad t=u/n,
\quad \delta=(1+u)^{1/n}-1.
\]

均值定理给 u/[n(1+u)]≤δ<t，故 7t/8<δ<t<1/100。每个非边专属坐标端点距离 D>2；旧边每坐标距离≤3/2<2，所以旧图确为 C_N。旧 maximal cliques 只有边，其完整交矩形每坐标宽≥1/2，真实正体积且彼此不交。任意两中心某坐标距≥1，故旧 receivers 不交，v=d/a^n。

所有动作 C_j 均含 A_j。D=3 的非边在任意 Z 后仍有距离≥3−2δ>2+2δ；Z=0 时 selected 非边因 t<2δ 全打开。因此全部动作图≤G=C_N∪K_selected，零位移精确达到 G。每个 nonselected 顶点只邻接其两个 cycle 邻点，且只邻接一个 selected；全部三角形都在 selected 中，完整 maximal-clique 类型为 selected clique 与各旧边。每条旧边均无共同 outside 邻居。轴平行开 boxes 的有限 Helly 性使该图分类同时认证全部真实正体积 cliques。

在 selected full clique 的交中，selected-pair 专属坐标宽为 2δ−t>0，其他坐标宽≥1/2+2δ；internal-edge full 交也严格正体积。所用 selected clique 与 internal-edge 矩形互不交，没有隐藏第三方成员，因而下述来源是实际 L1 密度而非原子或抽象图乘子。

## 2. 双 KKT 与整个旧来源类

旧 λ_j=1/2。各旧 edge full 交放均匀质量 m/2，给每行 m=d(1+u)，并满足

\[
(m-d)/2=\epsilon v,\quad
Q=Nd/2,\quad M=Nm/2=Q+\epsilon V.
\]

来源支持上旧 load=1；KKT 和严格凹性认证唯一正则 λ。

**所有旧 KKT 来源的升级成立。** 任意此类 AC 来源均支持于 Lλ=1；旧图无 triangle，该区域仅由 edge cells 构成。各 edge 总质量 z_i 满足 z_{i−1}+z_i=m，奇数 N 强制 z_i=m/2。内部 AC 密度可变，但不能改变这些总质量。这里必须保留 KKT saturation，不能推广至任意仅满足 lower averages 的来源。

若 outside 新 C_j 与旧 T_edge 正交，就会产生 G 中不存在的共同 outside 邻居。故对**所有旧 KKT 来源、全部 Z**，reach/join 邻域均空，μ(C_j\A_j)=0、μ(C_j)=m。完整来源恒等式给 Uα=S。此结论不依赖均匀化；也不把任意 shifted 等值 C_j 擅称 canonical last-bad cube。

全部动作的新 receiver 中心距≥1−2δ>2(1+δ)/a，所以真实 w=m/a^n，与顺序无关，无删零损失。Z=0 时 selected clique 与 k 条 internal edges 分割全部行，给线性上界 Σα≤k+1。α_selected=1/k、α_other=1/2 达到此界，side edges 的 load=1/k+1/2<1，完整可行。

线性对偶可在 selected full clique 放 m、每条 internal edge 放 m。实际 log-KKT 来源则分别放 m+kεw 和 m+2εw。每行满足 α_j(newmass_j−m)=εw，来源支持上新 load=1，总质量为 (k+1)m+Nεw。严格凹性因此认证实际唯一新权，得到

\[
Q'=(k+1)m,\quad S=(k/2-1)m>0,\quad
W=Nm/a^n=RM,\quad D=(k-2)m/a^n>0.
\]

旧 side-edge 块 load=1/2+1/k，internal-edge 块 load=1，故整个旧 KKT 来源类均有同一 Uα=S。零位移 O=F=Var=0，正收益恰为 RS，没有重复信用。

## 3. non-hard 与全动作量词

R=2/a^n 极小，明确非 hard。S/M=(k−2)/(3k)、D/V=(1+u)(k−2)/(3k)≥1/9 是此构造族的解析结果，不能外推一般维数阶。

已证的是 **∀Z local credit=0，而 Z=0 的实际 S,D>0**，不是所有 Z 均有正 S。实际上对 selected-pair 专属坐标向外各移 δ，可使新图退回 C_N，此时 α=1/2、Q'=M、S=0。因此不能由本例否定“存在好共同 global action”的策略。它排除的是对所有动作都按固定正比例用 local reach/join 代替完整 S，提示应保留跨旧来源块的新高阶 clique。

## 4. 正向全局 fractional source exchange

固定同一个完整 Z。把旧 μ 按准确旧 membership 分成 μ_K，质量 z_K；移除子测度 r_K≤μ_K、质量 f_K≤z_K。多批次必须共享供应，总移除≤μ。对同一次新图的 positive cliques L，在实际正体积交中加 AC 包 h_L。只要每个保留行 j 满足

\[
\sum_{L\ni j}h_L\ge\sum_{K\ni j}f_K,
\]

则 τ=μ−Σr_K+added 非负、AC，且

\[
\tau(C_j)\ge(\mu-\sum r_K)(A_j)+added(C_j)
\ge m_j-\sum_{K\ni j}f_K+\sum_{L\ni j}h_L\ge m_j.
\]

所以**移除包只需旧 membership 准确**；额外 new membership 不会漏需求，新包对额外行的覆盖也只增加 slack。弱对偶给

\[
Q'\le Q^*_{\rm new}\le\|\tau\|
=M-\sum f+\sum h,
\qquad D\ge W-RM+R(\sum f-\sum h).
\]

τ 仅认证新线性需求的覆盖费用，不能冒充新正则 KKT 来源；下一步必须重求自身正则最优与来源。最终主稿已明确这一点。

循环 batch：移除 side pairs (a_r,b_r),(c_r,a_{r+1}) 各 f；internal pair (b_r,c_r) 加 f，selected clique 加2f。每 a_r 移2f/补2f，每 b_r,c_r 移f/补f；净省(k−2)f。benchmark f=m/2 恰给 S，连同剩余旧 internal 包生成新完整线性最优 cover。这是真正可继续使用的 global clique 重分配，无需新 clique 包含某个完整旧 edge。

**最终新增不等量式(14)通过：** side 包分别移 ℓ_r,r_r，internal pair 补 max(ℓ_r,r_r)，selected clique 补 H0=max_r(ℓ_r+r_{r−1})。a_r 的损失是 ℓ_r+r_{r−1}，另两行损失分别为 ℓ_r,r_r，全部补足。净节省准确为

\[
\sum_r(\ell_r+r_r)-\sum_r\max(\ell_r,r_r)-H_0
=\sum_r\min(\ell_r,r_r)-\max_r(\ell_r+r_{r-1}).
\]

它可非正；只有正净省 batch 才产生信用。所有旧包供应限制、额外旧标签的逐行需求、同 Z 同时实现条件都必须保留。多个 batch 不能各自再用一份旧供应。

该模板未证明一般 hard family 总有足量 circulation，也未控制动作对真实 W 的影响；需要实际使 W−RM+R净省≥cV−CL_nM 才能付款。主稿没有把这个存在性缺口写成已证。

## 5. 局部公式及最终稿对照

主稿§2：完整旧 T_K 规范化正确。reach/join 经 axis-box Helly 得新局部 load≤s_K，积分同一真实新 KKT 来源得到(5)，再用 S=Σz_Ks_K 得(6)。分母 ν'(U_K) 对非空邻域确为正；不同 U_K 可重叠，不能当互斥资源。局部信用不与完整来源恒等式再次相加。global_contact 构造使所有邻域为空，故这一局部式即使优化新来源也不能按正比例覆盖全部 S。

主稿§3、独立稿 `global_contacts.md` 的一般 k/全部旧 KKT 类量词与上述独立证明一致；主稿§4(11)–(14) 与本审的 cover/row balance 完全一致。半幅动作的条件包含常数1−5/(48n) 可由 s_j/ρ_j≤1−1/(3n)、2/a≤1/(16n) 直接得到；低增长旧 v 总量<V/6 没有被误当成新 w/删除费用的付款。

未发现最终主稿的实质错误。允许补入的新 cliques 必须包括所有不含完整旧 active K 的高阶 cliques；不能继续用 local 扩邻域绕过这一项，也不能把本 non-hard 构造当作 root 目标反例。

## 6. 独立实际重跑收据

按要求只读 check.py 后独立执行一次，stdout 在内存解析，未覆盖原 results.json。12个奇数 k=3,5,…,25 全 PASS；最大 N=75、n=2700、t 分母44,294 bits。Python3.12.14、NumPy2.5.4；阶段 workers3/3/6、wall约0.059/0.092/0.992秒，总wall约1.143秒，worker CPU合计2.454秒，单worker peak RSS38,748,160 bytes。

脚本 SHA-256：
`3d287e16700ae46ba03dd8fcf762b0dac9ff7dd4ee7b3156657e069fea0efcfb`。
原 results.json 只读 SHA-256：
`47f13c51ba501a1ed9ee303cebd78f40d82468ea0f736998099ce9184c5f5ca8`。

程序逐真实非边坐标重建 pair 距离类别，再核图/cliques/双KKT；小整数秩排序由严格有理界支持，没有将微小 t 舍入为0。有限重跑不是任意 k 的证明；一般 k 由上文解析论证覆盖，更不构成一般维数阶证据。未重算其他样本或运行 MATLAB/Arb。

**最终状态：** 该全局构造与正向交换证书可归档；一般 hard 分支完整 D 下界仍未证明，不认证根阶上界，不进行反例滥用或继续 local 扩邻域。审核完成停止。
