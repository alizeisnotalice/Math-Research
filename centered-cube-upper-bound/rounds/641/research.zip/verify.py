#!/usr/bin/env python3
"""Reproduce the finite exact checks; does not certify the unresolved general bound."""
from pathlib import Path
from hashlib import sha256
import ast,json,os,re,subprocess,sys,tempfile,time
import sympy as sp
root=Path(__file__).resolve().parent
started=time.perf_counter()
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,meta in manifest['files'].items():
    p=root/name
    assert p.is_file() and p.parent==root
    data=p.read_bytes()
    assert len(data)==meta['bytes'] and sha256(data).hexdigest()==meta['sha256'],name
for name in ('check.py','verify.py'):
    ast.parse((root/name).read_text(),filename=name)
tex=(root/'REPORT.tex').read_text();stack=[]
for which,env in re.findall(r'\\(begin|end)\{([^}]+)\}',tex):
    if which=='begin':stack.append(env)
    else:assert stack and stack.pop()==env
assert not stack
expected=json.loads((root/'results.json').read_text())
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='ccu-r641-replay-') as out:
    proc=subprocess.run([sys.executable,str(root/'check.py')],cwd=out,env=env,capture_output=True,text=True,check=True)
    actual=json.loads(proc.stdout)
volatile={'cpu_s','wall_s','peak_rss_bytes','python','numpy'}
def stable(x):
    if isinstance(x,dict):return {k:stable(v) for k,v in x.items() if k not in volatile}
    if isinstance(x,list):return [stable(v) for v in x]
    return x
assert stable(expected)==stable(actual),'deterministic exact certificate differs'
k,m,e,w,f,a,n=sp.symbols('k m e w f a n',positive=True)
identities={
 'source_exchange_mass':2*k*f-(k*f+2*f)-(k-2)*f,
 'selected_row_loss':2*f-2*f,
 'internal_row_loss':f-f,
 'new_kkt_total':(m+k*e*w)+k*(m+2*e*w)-((k+1)*m+3*k*e*w),
 'normal_gap':3*k*m/2-(k+1)*m-(k-2)*m/2,
 'full_gain':3*k*m/a**n-(2/a**n)*(k+1)*m-(k-2)*m/a**n,
 'containment_margin':1-(1+2/(32*n)-1/(6*n))-sp.Rational(5,48)/n,
}
residuals={name:str(sp.simplify(value)) for name,value in identities.items()}
assert set(residuals.values())=={'0'}
rows=[r for stage in actual['stages'] for r in stage['results']]
summary={'status':'pass','scope':'Exact finite C_(3k) cube checks plus symbolic identities; not a proof of the general root bound.',
 'manifest_files_checked':len(manifest['files']),'cases':len(rows),'k_values':[r['k'] for r in rows],
 'max_dimension':max(r['n'] for r in rows),'max_workers':max(s['workers'] for s in actual['stages']),
 'cpu_s_sum':sum(r['cpu_s'] for r in rows),'max_worker_rss_bytes':max(r['peak_rss_bytes'] for r in rows),
 'batch_wall_s':actual['wall_s'],'overall_wall_s':time.perf_counter()-started,'python':sys.version,
 'numpy':actual['numpy'],'sympy':sp.__version__,'symbolic_residuals':residuals,
 'latex_check':'environment balance only; no compilation','report_sha256':sha256((root/'REPORT.tex').read_bytes()).hexdigest()}
(root/'RUN_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
