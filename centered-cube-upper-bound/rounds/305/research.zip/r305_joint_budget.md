# R305 — high-capture absorption and an exact source-conserving column ledger

## 1. Original target, qualifications and finite entry for this calculation

Use the EXACT qualified target and common marked binary-capture construction of /tmp/r304_geometry.md, not its unqualified positive enlargement. All sources, selected s,L,R,q, low/m and history/source qualifications are original. Write nu_* for its frozen hard-source restriction, with all gates still computed from the full sources. Retain

    q_-=3lambda/4, a<=L,R<=b<=2a, v(L,R)>=v0>0,
    U_y(x)=1_E(x)alpha(x,y)p_y(x)/q(x),
    J_y(r)=integral_(R(x)<=r) U_y(x)dx,
    A_yz(r)=integral_(R(x)<=r) U_y(x)b_y(x,z)
                                  1{z in Q_(R(x))(x)}dx,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr.

Here alpha is independent of z, 0<=b_y<=1, and U_y b_y is the exact original qualified point density. The binary capture is on receiver-plus-uniform-mark space; the formula for A retains its full qualification, including any fractional mask. Set p_yz(r)=A_yz(r)/J_y(r) when J>0, and zero otherwise. Thus 0<=p<=1. Let

    d=kappa0 psi_inf/(q_-v0),
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n.

The imported R304 identities/inequality are

    T=integral beta(dy)nu_*(dz)ell_n(dr) A_yz(r),        (1)
    B_H=integral beta(dy)nu_*(dz)ell_n(dr)
                          1{J_y(r)>=H}J_y(r)p(1-p),  (2)
    (1-2d/H)T<=8lambda H W_beta+2B_H.                 (3)

This T is finite: ORIGINAL FIRST and the hard-scale envelope give T<=A_n W_(nu_*), A_n=1+n log(b/a). The finite-target algebra below therefore uses no infinity-minus-infinity operation. It does not certify the full original global entry inequality or a payment for any other original slot. At the original low-pe ledger position the once-only multiplier is Lambda=128/119; if a different outer instance carries a positive multiplier, keep it inside that original outer integral.

## 2. A proved high-capture payment, with the full complement

Fix 0<eta<1/2. Partition the J>=H integrand into

    low: 0<=p<eta;
    middle: eta<=p<1-eta;
    high: 1-eta<=p<=1.

Denote the corresponding integrals by B_low,B_mid,B_high. This is an exact disjoint partition, including p=0 and all endpoints. On the high part,

    J p(1-p)<=eta Jp=eta A.

Consequently the actual paid receipt is

    B_high<=eta T.                                    (4)

It uses the EXACT qualified first moment (1). For an unqualified A whose first moment is a larger target, the right side must instead be that larger first moment; the substitution by T would not be licensed.

Combining (3),(4), for 1-2d/H-2eta>0, gives

    (1-2d/H-2eta)Lambda T
      <=8Lambda lambda H W_beta+2Lambda(B_low+B_mid).  (5)

Thus the original bound spends 2Lambda eta T on the high-capture portion; that is internally absorbed into the same finite Lambda T. It is not an asserted eta lambda|E| error. For the explicit choice H=8d, eta=1/8,

    Lambda T<=128Lambda lambda d W_beta
                                     +4Lambda(B_low+B_mid). (6)

The source coefficient is equivalently

    128Lambda lambda d=(512/3)Lambda kappa0 psi_inf/v0.

It includes q_- through d. No hard-source density, nu<=beta, new FIRST or repeated physical-scale source copy is used. B_low is NOT paid by eta T: when p is small, p(1-p) is close to p, so that proposed absorption has the wrong direction. The COMPLETE remaining fee in (6) is

    B_low+B_mid=integral beta(dy)nu_*(dz)ell_n(dr)
      1{J_y(r)>=8d, p_yz(r)<7/8}
             [A_yz(r)-A_yz(r)^2/J_y(r)].               (7)

All original source/history and near-heavy qualifications remain inside A. Formula (7) is left intact, including its negative square; it is not replaced by two source total masses.

## 3. Exact column regrouping retains both square savings

For any measurable row domain D(z,r) contained in {y:J_y(r)>=H}, define

    E_D(z,r)=integral_D J_y(r)beta(dy),
    L_D(z,r)=integral_D A_yz(r)beta(dy),
    V_D(z,r)=integral_D [A_yz(r)-A_yz(r)^2/J_y(r)]beta(dy).

These are finite by the full-soft envelope. If E_D=0, all three vanish. Otherwise the exact weighted variance identity is

    V_D=L_D-L_D^2/E_D
          -integral_D J_y(r)[p_yz(r)-L_D/E_D]^2 beta(dy). (8)

Proof: expand the last square, using integral_D Jp=L_D. This proves, without losing the original negative square,

    V_D<=L_D(1-L_D/E_D).                              (9)

The final term in (8) is an additional nonnegative between-row overlap saving. It is not an independently spendable source credit. Both (8) and (9) allow arbitrary concentration of beta or nu_* and arbitrary fractional/history qualifications. Choose D to be all J>=H rows, the low rows, the middle rows, or their union as needed; when D depends on z this dependence is retained. Integrating against the ORIGINAL nu_*(dz)ell_n(dr) gives the corresponding exact incidence fee, with each source used once.

This is regrouping of a positive finite integral followed by an exact finite subtraction. No posterior replacement or receiver-dependent source partition is inserted into the original traffic.

## 4. FIRST really supplies a source-limited middle-row packing

Let g(x)=integral U_y(x)beta(dy). ORIGINAL FIRST gives 0<=g<=1_E. Define the actual unqualified column occupation

    C_col(z,r)=integral_(R(x)<=r) g(x)
                                     1{z in Q_(R(x))(x)}dx.

For EVERY row domain D above, 0<=b_y<=1 and positive Tonelli imply

    0<=L_D(z,r)<=C_col(z,r)<=r^n.                     (10)

For the last inequality, each contributing x lies in Q_r(z), since R(x)<=r. This is a Lebesgue-volume conclusion at actual receivers using their original joint FIRST. It is NOT a density bound for either source and uses no cap at a source center.

For D_mid={J>=H,eta<=p<1-eta}, the additional pointwise fact A>=eta J yields the actual source-limited packing

    eta E_mid(z,r)<=L_mid(z,r)<=C_col(z,r)<=r^n,
    beta(D_mid(z,r))<=r^n/(eta H).                    (11)

Thus one cannot freely place an arbitrary number of large-J beta rows with middle capture over the same hard-source column at the same scale. This is a verified joint source restriction. It is also compatible with arbitrarily large total source masses away from those rows/columns.

There is a sharp scalar upper receipt combining (9),(10). Define G(0,c)=0, and for E>0,c>=0,

    G(E,c)=E/4,               E<=2c;
    G(E,c)=c-c^2/E,           E>=2c.

At c=0 the second formula gives zero; at E=2c the formulas agree. Since t-t^2/E increases to E/4 on [0,E/2] and then decreases,

    V_D(z,r)<=G(E_D(z,r),C_col(z,r)).                 (12)

This is the exact best bound from the displayed scalar constraints 0<=L_D<=min(E_D,C_col) alone. Constant p across the row domain makes the variance term in (8) zero. That scalar sharpness is not a counterexample for the full original cube field or its low/m gates.

Equations (8),(10),(11) are a general source-conserving re-columning/packing result; they do not require a convenient local-source regime. They retain the original receiver-selector and common-softness constraints through U and A.

## 5. What is paid, and the precise missing multiscale budget

The high-capture piece is paid by (4)–(6). The middle packing (11) is a theorem, but it is not yet a root-order payment. Indeed (10)–(12) alone only give

    V_mid<=L_mid<=r^n,
    B_mid<=A_n W_(nu_*), since integral r^n ell_n(dr)=A_n. (13)

This spends the hard source once after the full scale integral; it does NOT spend W_nu independently at each scale. Its dimension cost is nevertheless order n in a full octave. The slightly sharper factor 1-eta follows from p>=eta, but does not change that cost. On the low part there is no eta lower bound on p, so (11) does not apply there; the same old A_n bound remains available. Original hard caps give additional within-row bounds but do not themselves bound the integral over all middle-row domains in (11).

A substantive missing statement is a multiscale, original-source budget for the actual middle domains, for example a root-order bound on

    integral nu_*(dz)ell_n(dr)
                         G(E_mid(z,r),C_col(z,r)),    (14)

or a stronger estimate using the exact between-row saving in (8), together with a separate payment of the low piece in (7). A proof must control their actual scale overlap so that (13)'s A_n does not simply return. Neither original FIRST nor the scalar concavity identity supplied that extra scale information here. No assertion is made that (14) is small on every original input. This is the exact unpaid bridge, not a claimed source estimate obtained by renaming the incidence fee.

The same proofs apply SEPARATELY to every fixed common binary qualification level theta in (0,1] from /tmp/r305_geometry.md. Replace b_y(x,z) by 1{b_y(x,z)>=theta}, A,T,p,B by A_theta,T_theta,p_theta,B_theta, and retain the SAME U,J,d,H,beta,nu_*. The positive-theta support qualification supplied there licenses the original point heights. In particular

    B_(H,theta,high)<=eta T_theta,
    (1-2d/H-2eta)Lambda T_theta
      <=8Lambda lambda H W_beta
                        +2Lambda B_(H,theta,p_theta<1-eta). (15)

Integrating theta with total weight one and using T=integral_0^1 T_theta dtheta gives, at H=8d,eta=1/8,

    Lambda T<=128Lambda lambda d W_beta
            +4Lambda integral_0^1 B_(8d,theta,p_theta<7/8)dtheta. (16)

The complete low-p part is retained at EACH level. One must not average p_theta first and insert its variance: that would return the independent-mark artifact instead of the common-threshold incidence. All (8)–(14) can likewise be applied levelwise and then averaged. No free favorable theta is selected for an edge, and no theta source copies are charged. In a finite 1/m-weighted reduction the same source coefficient occurs once for T_m; applying its separately proved discarded-traffic estimate adds only the existing Lambda A_n/m W_(nu_*) if passing back to T. ALL incidence fees in (15)–(16) are at the displayed H; the main note's H=4d fee cannot silently replace the H=8d fee here.

This auxiliary does not optimize the common-threshold parameter or count its alternative receipt twice. R302–R304 point/soft-tail bounds remain available on their proved scopes; a source-dependent soft-degree cutoff alone does not establish the missing multiscale row packing. In particular the re-column calculation yields no new root payment for middle capture beyond the old A_n baseline (13). No complete global entry/coverage or original theorem is certified by this note.

## 6. Actual finite diagnostics

A standard-library exact-Fraction calculation used three disjoint receiver intervals [0,1/4], [1/2,3/4], [1,5/4], selected radii 1,3/2,2, three beta rows of masses 1/2,1/3,1/6, and four hard sources at -1/4,1/4,3/4,5/4 of masses 1/3,1/5,1/7,1/11. Receiver-row intensities were the matrix

    [[1,1/2,1/4],[1/2,1,1/2],[1/4,1/2,1]].

At each receiver interval their beta-weighted sum is at most one. Capture integrals used the EXACT interval intersection with each selected cube; qualifications were all one, binary receiver-varying, or fractional receiver-varying. For H in {1/16,1/8,1/4}, eta in {1/8,1/4}, the actual run passed 18 high-capture receipts, 864 exact re-column variance identities/column capacities, 216 middle-row packing checks and 18 full-complement identities. These finite occupation models test the algebra and receiver-volume bound, not realization by all original full-soft low/m fields. The proofs above supply the claimed general interface.

The following compact reproduction uses only the standard library and writes no files.

```python
from fractions import Fraction as F
from itertools import product
beta=[F(1,2),F(1,3),F(1,6)]
cells=[(F(0),F(1,4)),(F(1,2),F(3,4)),(F(1),F(5,4))]
rad=[F(1),F(3,2),F(2)]
U=[[F(1),F(1,2),F(1,4)],[F(1,2),F(1),F(1,2)],
   [F(1,4),F(1,2),F(1)]]
zs=[F(-1,4),F(1,4),F(3,4),F(5,4)]
nu=[F(1,3),F(1,5),F(1,7),F(1,11)]
assert all(sum(beta[y]*U[y][i] for y in range(3))<=1 for i in range(3))
ct=dict(high_receipt=0,recolumn_identity=0,middle_packing=0,full_complement=0)
for regime in range(3):
 layers=[]
 for k,r in enumerate(rad):
  J=[sum(U[y][i]*(cells[i][1]-cells[i][0])
         for i in range(k+1)) for y in range(3)]
  A=[]
  for y in range(3):
   az=[]
   for zi,z in enumerate(zs):
    val=F(0)
    for i in range(k+1):
     hit=max(F(0),min(cells[i][1],z+rad[i]/2)
                         -max(cells[i][0],z-rad[i]/2))
     mark=(F(1) if regime==0 else
          (F((y+i+zi)%2) if regime==1 else F((y+i+zi)%3,2)))
     val+=U[y][i]*hit*mark
    az.append(val)
   A.append(az)
  w=1/r-(1/rad[k+1] if k<2 else 0)
  layers.append((w,r,J,A))
 for H,eta in product([F(1,16),F(1,8),F(1,4)],[F(1,8),F(1,4)]):
  T=sum(w*sum(beta[y]*nu[z]*A[y][z]
      for y in range(3) for z in range(4)) for w,r,J,A in layers)
  Bs=[F(0),F(0),F(0)]
  for w,r,J,A in layers:
   for z in range(4):
    groups=[[],[],[]]
    for y in range(3):
     if J[y]<H: continue
     p=A[y][z]/J[y]
     g=2 if p>=1-eta else (1 if p>=eta else 0)
     groups[g].append(y)
     Bs[g]+=w*beta[y]*nu[z]*J[y]*p*(1-p)
    for inds in [sum(groups,[])]+groups:
     E=sum((beta[y]*J[y] for y in inds),F(0))
     L=sum((beta[y]*A[y][z] for y in inds),F(0))
     V=sum((beta[y]*A[y][z]*(1-A[y][z]/J[y]) for y in inds),F(0))
     assert L<=r
     if E:
      between=sum(beta[y]*J[y]*(A[y][z]/J[y]-L/E)**2 for y in inds)
      assert V==L-L*L/E-between
     else: assert L==V==0
     ct['recolumn_identity']+=1
    mid=groups[1]
    Em=sum((beta[y]*J[y] for y in mid),F(0))
    Lm=sum((beta[y]*A[y][z] for y in mid),F(0))
    assert eta*Em<=Lm<=r
    ct['middle_packing']+=1
  assert Bs[2]<=eta*T
  ct['high_receipt']+=1
  Ball=sum(w*sum(beta[y]*nu[z]*A[y][z]*(1-A[y][z]/J[y])
       for y in range(3) if J[y]>=H for z in range(4))
       for w,r,J,A in layers)
  assert sum(Bs)==Ball
  ct['full_complement']+=1
print('PASS',ct)
```

Only /tmp/r305_joint_budget.md was written. Other authors' files and Git were untouched.
