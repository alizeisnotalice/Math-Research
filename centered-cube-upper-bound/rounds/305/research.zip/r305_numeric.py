#!/usr/bin/env python3
"""R305 exact common-threshold coarea diagnostics on real L1 cells and shells."""
import json,random,sys,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
from math import lcm,isqrt
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
R=random.Random(30120261018);COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def cellvol(h,n):return F(2*h,32)**n
def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}
def shell(n):
 delta=F(1,100*n);m=min(4*n,16);rr=[1+F(i,m) for i in range(m+1)];vol=[];prev=F(0)
 for r in rr:
  v=(r-2*delta)**n;vol.append(v-prev);prev=v
 ck(all((r-2*delta)/2+delta==r/2 for r in rr),'shell_actual_full_source_inclusion',{'n':n})
 return {'name':'concentric_shell_n'+str(n),'n':n,'vol':vol,'L':rr,'R':rr,'soft':[[1] for r in rr],'hard':[[1] for r in rr],'beta':[F(1)],'nu':[F(4)],'first':[r**(-n) for r in rr],'hardresp':[4*r**(-n) for r in rr],'geometry':{'type':'centered_disjoint_shells','delta':delta,'m':m,'source_side':2*delta,'source_center':0,'receiver_shell_sides':'E0=Q_(1-2delta); Ei=Q_(Li-2delta) minus Q_(L_(i-1)-2delta); Li=Ri=1+i/m'}}
LEVELS=[F(1,4),F(1,2),F(1)];WIDTHS=[F(1,4),F(1,4),F(1,2)];POOL=[F(0),F(1,4),F(1,2),F(1)]
def gate(i,j,z,mode):
 if mode=='constant_half':return F(1,2)
 if mode=='binary_varying':return F(int((i+2*j+3*z)%3!=0))
 return POOL[(i+2*j+3*z)%4]
def V(J,A,nu):return sum(v*(a-a*a/J) for v,a in zip(nu,A)) if J else F(0)
def verify(c,mode):
 name=c['name']+'_'+mode;n=c['n'];nu=c['nu'];radii=sorted(set(c['R']+[F(2)]));weights=[r**(-n)-(radii[i+1]**(-n) if i+1<len(radii) else 0) for i,r in enumerate(radii)];layers=[]
 for j,beta in enumerate(c['beta']):
  u=[v*c['soft'][i][j]/c['L'][i]**n for i,v in enumerate(c['vol'])];den=lcm(*(a.denominator for a in u));ints=[a.numerator*(den//a.denominator) for a in u]
  prevJ=F(0);prevA=[[F(0)]*len(nu) for _ in LEVELS]
  for r,w in zip(radii,weights):
   ids=[i for i,ri in enumerate(c['R']) if ri<=r];J=sum((u[i] for i in ids),F(0));Ath=[[] for _ in LEVELS];Aind=[];categories=[];Qpair=Qindpair=diffpair=F(0)
   for z,v in enumerate(nu):
    a=[c['hard'][i][z]*gate(i,j,z,mode) for i in ids];avg=sum((u[i]*e for i,e in zip(ids,a)),F(0));Aind.append(avg)
    for k,theta in enumerate(LEVELS):Ath[k].append(sum((u[i]*(e>=theta) for i,e in zip(ids,a)),F(0)))
    ck(sum(width*At[z] for width,At in zip(WIDTHS,Ath))==avg,'exact_coarea_first_moment_per_source',{'case':name,'j':j,'r':str(r),'z':z})
    groups={e:0 for e in POOL}
    for i,e in zip(ids,a):groups[e]+=ints[i]
    categories.append(groups)
    qp=ip=dp=0
    for e,ue in groups.items():
     for f,uf in groups.items():
      en=int(4*e);fn=int(4*f);qp+=ue*uf*abs(en-fn);ip+=ue*uf*(4*en+4*fn-2*en*fn);dp+=ue*uf*(4*min(en,fn)-en*fn)
    Qpair+=v*F(qp,8*den**2);Qindpair+=v*F(ip,32*den**2);diffpair+=v*F(dp,16*den**2)
   M=sum(v*a for v,a in zip(nu,Aind));Qind=J*M-sum(v*a*a for v,a in zip(nu,Aind));Qco=sum(width*(J*sum(v*a for v,a in zip(nu,At))-sum(v*a*a for v,a in zip(nu,At))) for width,At in zip(WIDTHS,Ath))
   ck(0<=Qco==Qpair<=Qind==Qindpair,'exact_coarea_pair_gap_and_independent_domination',{'case':name,'j':j,'r':str(r)})
   ck(Qind-Qco==diffpair>=0,'exact_min_minus_product_difference',{'case':name,'j':j,'r':str(r)})
   if mode=='binary_varying':ck(Qco==Qind,'binary_qualification_coarea_equals_independent_gap',{'case':name,'j':j,'r':str(r)})
   if mode=='constant_half' and c['name'].startswith('concentric_shell'):ck(Qco==0 and (not J or Qind>0),'common_fractional_qualification_removes_artificial_variance',{'case':name,'r':str(r)})
   h=J-prevJ;avec=[[a-p for a,p in zip(At,prior)] for At,prior in zip(Ath,prevA)]
   vp=sum(width*V(prevJ,prior,nu) for width,prior in zip(WIDTHS,prevA));vb=sum(width*V(h,aa,nu) for width,aa in zip(WIDTHS,avec));vn=sum(width*V(J,At,nu) for width,At in zip(WIDTHS,Ath))
   gap=prevJ*h/J*sum(width*sum(v*(p/prevJ-a/h)**2 for v,p,a in zip(nu,prior,aa)) for width,prior,aa in zip(WIDTHS,prevA,avec)) if prevJ and h else F(0)
   ck(vn==vp+vb+gap and min(vp,vb,gap)>=0,'exact_theta_integrated_block_pooling',{'case':name,'j':j,'r':str(r)})
   ck(vn==(Qco/J if J else 0),'coarea_joint_potential_equals_Qco_over_original_J',{'case':name,'j':j})
   prevJ=J;prevA=Ath
   layers.append({'j':j,'r':r,'w':w,'beta':beta,'J':J,'Ath':Ath,'Aind':Aind,'M':M,'Qco':Qco,'Qind':Qind,'Vco':vn,'categories':categories,'common_den':den})
 for r in radii:
  for z in range(len(nu)):
   ck(sum(l['beta']*l['Aind'][z] for l in layers if l['r']==r)<=r**n,'true_shared_FIRST_marked_column_bound',{'case':name,'r':str(r),'z':z})
 first=sum(l['beta']*l['w']*l['M'] for l in layers);cofirst=sum(l['beta']*l['w']*width*sum(v*a for v,a in zip(nu,At)) for l in layers for width,At in zip(WIDTHS,l['Ath']))
 ck(first==cofirst,'exact_original_marked_traffic_first_moment_preserved',{'case':name})
 js=sorted(set(l['J'] for l in layers if l['J']));Hs=sorted(set([F(1,16),F(1),js[0],js[len(js)//2],js[-1]]));Wbeta=sum(c['beta']);Wnu=sum(nu);Cmenu=sum(w*r**n for w,r in zip(weights,radii));records=[]
 for d in [F(1,16),F(1),F(16)]:
  Oco=Oind=F(0)
  for l in layers:
   l['clipco']=sum(width*sum(v*min(d,a) for v,a in zip(nu,At)) for width,At in zip(WIDTHS,l['Ath']));l['clipind']=sum(v*min(d,a) for v,a in zip(nu,l['Aind']))
   ck(l['clipco']<=l['clipind'],'exact_coarea_clipped_cost_le_independent',{'case':name,'j':l['j'],'d':str(d)})
   Oco+=l['beta']*l['w']*l['clipco'];Oind+=l['beta']*l['w']*l['clipind']
  for H in Hs:
   low=sum(l['beta']*l['w']*l['clipco'] for l in layers if l['J']<H);large=Oco-low;BHco=sum(l['beta']*l['w']*l['Vco'] for l in layers if l['J']>=H);BHind=sum(l['beta']*l['w']*l['Qind']/l['J'] for l in layers if l['J']>=H);largeM=sum(l['beta']*l['w']*l['M'] for l in layers if l['J']>=H)
   ck(BHco<=BHind and low<=4*H*Wbeta,'coarea_original_J_threshold_low_budget',{'case':name,'d':str(d),'H':str(H)})
   ck(large<=d/H*largeM+BHco,'coarea_high_split_no_duplicate_beta',{'case':name,'d':str(d),'H':str(H)})
   rhs=4*H*Wbeta+d/H*Cmenu*Wnu+BHco;ck(Oco<=rhs,'coarea_full_global_split',{'case':name,'d':str(d),'H':str(H)})
   records.append({'d':d,'H':H,'H_is_original_J_atom':H in js,'Oco':Oco,'Oind':Oind,'BHco':BHco,'BHind':BHind,'global_RHS':rhs})
 if mode=='binary_varying' and c['name'].startswith('concentric_shell'):
  ck(any(l['Qco']>0 for l in layers),'real_binary_varying_qualification_cost_survives',{'case':name})
  ck(any(record['BHco']>0 for record in records),'real_binary_varying_qualification_fee_survives',{'case':name})
 rounded=[];root=isqrt(1+n);root+=int(root*root<1+n)
 for m in sorted(set([1,3,5,root])):
  delta=F(1,m);ck(sum(delta for _ in range(m))==1 and sum(beta*delta for beta in c['beta'] for _ in range(m))==Wbeta,'rounded_threshold_total_delta_beta_normalization',{'case':name,'m':m})
  Tm=F(0);qms=[]
  for l in layers:
   gridAt=[l['Ath'][next(k for k,theta in enumerate(LEVELS) if theta>=F(t,m))] for t in range(1,m+1)]
   avg=[delta*sum(At[z] for At in gridAt) for z in range(len(nu))]
   directavg=[];Qmpair=F(0)
   for z,(v,groups) in enumerate(zip(nu,l['categories'])):
    directavg.append(sum(F((m*e).numerator//(m*e).denominator,m)*F(ui,l['common_den']) for e,ui in groups.items()))
    numerator=0
    for e,ue in groups.items():
     for f,uf in groups.items():
      en=(m*e).numerator//(m*e).denominator;fn=(m*f).numerator//(m*f).denominator;numerator+=ue*uf*abs(en-fn)
    Qmpair+=v*F(numerator,2*m*l['common_den']**2)
   ck(avg==directavg,'rounded_floor_qualification_equals_uniform_grid_first_moment',{'case':name,'m':m,'j':l['j']})
   Qmgrid=delta*sum(l['J']*sum(v*a for v,a in zip(nu,At))-sum(v*a*a for v,a in zip(nu,At)) for At in gridAt)
   ck(Qmpair==Qmgrid,'rounded_pair_gap_equals_uniform_threshold_grid_gap',{'case':name,'m':m,'j':l['j']})
   qms.append(Qmgrid/l['J'] if l['J'] else F(0));Tm+=l['beta']*l['w']*sum(v*a for v,a in zip(nu,avg))
  bound=Cmenu*Wnu/m;ck(0<=first-Tm<=bound,'rounded_first_moment_payment_residual_bound',{'case':name,'m':m})
  for H in sorted(set([js[0],js[len(js)//2]])):
   Bco=sum(l['beta']*l['w']*l['Vco'] for l in layers if l['J']>=H);Bm=sum(l['beta']*l['w']*vm for l,vm in zip(layers,qms) if l['J']>=H)
   ck(abs(Bco-Bm)<=bound,'rounded_overlap_fee_payment_residual_bound',{'case':name,'m':m,'H':str(H)})
   rounded.append({'m':m,'H':H,'T':first,'Tm':Tm,'T_minus_Tm':first-Tm,'Bco':Bco,'Bm':Bm,'absolute_B_residual':abs(Bco-Bm),'Cmenu_Wnu_over_m':bound})
 geometry=c['geometry'] if 'geometry' in c else {'coordinate_denominator':32,'receiver_centers_num':c['X'],'receiver_halfwidth_num':c['Ehalf'],'beta_centers_num':c['Y'],'nu_centers_num':c['Z'],'source_halfwidth_num':1}
 return {'name':name,'n':n,'mode':mode,'receiver_cells':len(c['vol']),'beta_rows':len(c['beta']),'nu_cells':len(nu),'layer_count':len(layers),'positive_Qco_layers':sum(l['Qco']>0 for l in layers),'strict_Qco_less_Qind_layers':sum(l['Qco']<l['Qind'] for l in layers),'first_moment_traffic':first,'Cmenu':Cmenu,'example':next(({'j':l['j'],'r':l['r'],'J':l['J'],'Qco':l['Qco'],'Qind':l['Qind']} for l in layers if l['J'] and (l['Qco']<l['Qind'] or l['Qco']>0)),None),'geometry':geometry,'L':c['L'],'R':c['R'],'receiver_volumes':c['vol'],'beta_masses':c['beta'],'nu_masses':nu,'soft_incidence':c['soft'],'hard_incidence':c['hard'],'records':records,'rounded_payment_records':rounded}
def encode(x):
 if isinstance(x,F):
  if x.numerator.bit_length()+x.denominator.bit_length()<=1250:return str(x)
  a=abs(x.numerator).to_bytes(max(1,(abs(x.numerator).bit_length()+7)//8),'big');b=x.denominator.to_bytes(max(1,(x.denominator.bit_length()+7)//8),'big')
  with localcontext() as ctx:ctx.prec=60;val=str(Decimal(x.numerator)/Decimal(x.denominator))
  return {'decimal60':val,'exact_binary_rational_sha256':hashlib.sha256(bytes([x.numerator<0])+len(a).to_bytes(8,'big')+a+b).hexdigest()}
 raise TypeError(type(x).__name__)
settings=[('initial',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain')]),('atomic_boundary',[('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded_bounded_shell_menu',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])];stages=[]
for stage,specs in settings:
 cases=[make(name,n,kind) for name,n,kind in specs]
 if stage.startswith('expanded'):cases += [shell(n) for n in [16,32]]
 stages.append({'name':stage,'cases':[verify(c,mode) for c in cases for mode in ['geometry_fractional','constant_half','binary_varying']]})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Exact finite diagnostics on actual s=0 positive-L1 cell and shell geometries, FIRST<=1 and same-radius hardcap<=4. Frozen qualification masks do not implement original full low/e/m history; no root payment or FULL closure is certified.','bounded_menu_change':'The same cell generation as R304 is copied self-contained. High-dimensional shell menus use m=min(4n,16), hence17 shells at n16 and32, rather than65/129 shells in R304. Dimensions and positive-volume support remain genuine; old7793 checks are not rerun.','qualification_modes':'geometry_fractional=[0,1/4,1/2,1][(i+2j+3z)mod4]; constant_half=1/2; binary_varying=1{(i+2j+3z)mod3!=0}; all multiplied by actual hardcapture c_iz.','coarea':'One global theta uniform on(0,1), atom levels1/4,1/2,1 and widths1/4,1/4,1/2. J remains unmarked receiver mass. Atheta=sum u_i 1{c_iz b_ijz>=theta}.','identities':'Qco=integral_theta[J Mtheta-sum nu Atheta^2]=1/2 sum_ik u_i u_k sum nu |a_i-a_k|. Qind-Qco=sum_ik u_i u_k sum nu[min(a_i,a_k)-a_i a_k]>=0. First moment preserved; Oco<=Oind by concavity. Integrated Vco obeys exact block pooling at original J, including zero masses.','rounded_payment':'m=1,3,5,ceil sqrt(1+n); bm=floor(mb)/m. T-Tm<=Cmenu Wnu/m and |BHco-BHm|<=Cmenu Wnu/m at two existing J thresholds. Pair Bm equals uniform-grid threshold average; delta=1/m sums to1, and sum_j beta_j sum delta=Wbeta.','global_split':'At each original J=H atom, use large branch once. Oco<=4H Wbeta+(d/H)Cmenu Wnu+BHco; beta appears only once in each fee.','serialization':'Fractions with combined numerator/denominator bits<=1250 are exact strings. Larger values use60digit display and canonical binary rational SHA256 (sign byte,8byte numerator-byte-length,absolute numerator bytes,denominator bytes). All checks use full Fraction values.','check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n')
lines=['# R305 common-threshold coarea diagnostics','',out['scope'],'',out['bounded_menu_change'],'',out['coarea'],'',out['identities'],'','|model / qualification|layers|positive Qco|strict Qco<Qind|','|---|---:|---:|---:|']
for st in stages:
 for c in st['cases']:lines.append(f"|{c['name']}|{c['layer_count']}|{c['positive_Qco_layers']}|{c['strict_Qco_less_Qind_layers']}|")
lines+=['','On true complete-capture shells, constant fractional qualification gives Qco=0 while Qind>0: common threshold removes artificial independent-mark variance. Binary varying qualifications retain positive Qco on these same geometries, so coarea does not erase genuine qualification variation.','',out['global_split'],'',out['rounded_payment'],'','All comparisons are exact Fraction; the file contains geometry and qualification recipes for reproduction. Only these finite models are tested.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'layers':c['layer_count'],'Qco_positive':c['positive_Qco_layers'],'strict':c['strict_Qco_less_Qind_layers']} for st in stages for c in st['cases']]},indent=2));assert not FAIL,FAIL
