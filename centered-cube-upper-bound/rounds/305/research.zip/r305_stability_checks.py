from fractions import Fraction as F
from random import Random
import json
from pathlib import Path
rng=Random(305);counts={};cases=[]
def check(x,k):
 assert x,k
 counts[k]=counts.get(k,0)+1
for stage,N,num in [('initial',3,12),('endpoint_and_zero',6,20),('expanded',12,28)]:
 for case in range(num):
  u=[F(rng.randrange(5),16) for _ in range(N)]
  nu=[F(rng.randrange(1,5),8) for _ in range(4)]
  masks=[[F(rng.randrange(9),8) for z in nu] for i in u]
  other=[[F(rng.randrange(9),8) for z in nu] for i in u]
  if case==0:other=masks
  if case==1:u=[F(0)]*N
  if case==2:masks=[[F(1)]*4]*N;other=[[F(0)]*4]*N
  caps=[[rng.randrange(2) for z in nu] for i in u]
  layers=[]
  for end in sorted(set([1,N//2,N])):
   J=sum(u[:end]);weight=F(1,end+1);layers.append((end,J,weight))
  for H in [F(1,8),F(1,2),F(2)]:
   Bb=Bg=weighted=F(0);Ob=Og=F(0);d=F(1,3)
   for end,J,w in layers:
    weighted+=w*sum(u[i]*nu[z]*caps[i][z]*abs(masks[i][z]-other[i][z]) for i in range(end) for z in range(4))
    if J>=H:
     for mat,label in [(masks,'b'),(other,'g')]:
      Q=sum(u[i]*u[k]*nu[z]*abs(caps[i][z]*mat[i][z]-caps[k][z]*mat[k][z]) for i in range(end) for k in range(end) for z in range(4))/2
      if label=='b':Bb+=w*Q/J
      else:Bg+=w*Q/J
    theta=sorted(set([F(0),F(1)]+[masks[i][z] for i in range(end) for z in range(4)]+[other[i][z] for i in range(end) for z in range(4)]))
    for lo,hi in zip(theta,theta[1:]):
     for mat,label in [(masks,'b'),(other,'g')]:
      val=sum(nu[z]*min(d,sum(u[i]*caps[i][z]*(mat[i][z]>=hi) for i in range(end))) for z in range(4))
      if label=='b':Ob+=w*(hi-lo)*val
      else:Og+=w*(hi-lo)*val
   check(abs(Bb-Bg)<=weighted,'weighted_B_modulus')
   check(abs(Ob-Og)<=weighted,'weighted_O_modulus')
  # Pairwise Frechet bound: all joint Bernoulli laws parameterized by joint hit t.
  for p,q in zip(masks[0],other[0]):
   low=max(F(0),p+q-1);high=min(p,q)
   for joint in [low,(low+high)/2,high]:
    check(p+q-2*joint>=abs(p-q),'coupling_minimum')
   check(p+q-2*high==abs(p-q),'comonotone_equality')
  cases.append({'stage':stage,'receivers':N,'case':case})
out={'status':'PASS','scope':'Synthetic finite exact algebra for weighted stability and coupling optimum; not an original L1/full-history realization or a general root budget. Three stages include zero rows, identical/opposite masks, variable incidence and growing receiver count.','counts':counts,'case_count':len(cases),'cases':cases}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':counts,'case_count':len(cases)}))
