# R305 — one common qualification threshold, exact variance removal, and a paid finite reduction

## 1. Exact target and the distinction between the two improvements

Use the complete original R304 target

    T=integral I0(x,y,z)p_y(x)h_(R(x))(x-z)/q(x)
                                      dx beta(dy)nu_h(dz).

The frozen positive source restriction nu_h<=nu does not recompute original e_g,m, low/high gates, source/history qualifications or actual selectors. Retain a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, original FIRST and SAME-radius hard caps on E, and the original actual aspect v(L,R)>=v0>0. Choose a fixed original row gate 0<=alpha(x,y)<=1 with I0<=alpha. Put

    U_y(x)=alpha(x,y)1_E(x)p_y(x)/q(x),
    b_y(x,z)=I0(x,y,z)/alpha(x,y) if alpha>0, and 0 otherwise,
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr,
    d=kappa0 psi_inf/(q_-v0),
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n,
    H=4d, A_n=1+n log(b/a).

As in R304, the physical endpoint b is distinguished from the qualification b_y. Every complete target mask and actual source is retained.

For a single GLOBAL parameter theta in (0,1], define

    I_theta(x,y,z)=alpha(x,y)1{b_y(x,z)>=theta},
    T_theta=integral I_theta p_y h_R/q dx beta(dy)nu_h(dz).

All original quantities U,J,d,H and all source measures are held fixed as theta varies. The main continuous result is

    T<=64lambda d W_beta+4 B_H^co,                         (1)

where

    B_H^co=integral beta(dy)ell_n(dr)1{J_y(r)>=H}Q_y^co(r)/J_y(r),
    Q_y^co(r)=(1/2)integral_{R(u),R(w)<=r}U_y(u)U_y(w)
                integral |c_u(z)b_y(u,z)-c_w(z)b_y(w,z)|nu_h(dz)du dw,
    c_u(z)=1{z in Q_(R(u))(u)}.                            (2)

This uses TRUE qualification variation instead of the artificial independent-mark expression. It is no larger than R304's marked fee, with an exact nonnegative difference given in section 3. This is a structural improvement of the bound for the SAME whole target, not a demonstrated source-linear root bound for the remaining incidence.

There is a separate strictly payable positive portion of the actual traffic. For any integer m>=1 set delta=1/m and

    b_m=delta floor(m b), I_m=alpha b_m, T_m=T with I0 replaced by I_m.

Then

    0<=T-T_m<=(A_n/m) W_(nu_h),                           (3)
    T_m<=64lambda d W_beta+4 B_H^(m),                     (4)
    B_H^(m)=delta sum_(k=1)^m B_H^(theta=k/m).

Thus m=ceil(sqrt(A_n)) makes the discarded ORIGINAL fractional traffic root-priced. The remaining finite binary levels have total weight delta m=1, so their source budget is not multiplied by m. In addition

    |B_H^(m)-B_H^co|<=(A_n/m)W_(nu_h).                    (5)

These statements remove the independent-mark artifact and pay the finite-reduction error on all spatial and scale configurations. They do not pay the genuine binary source/history incidence left in B_H^(m).

## 2. Qualification inheritance and the one-threshold source ledger

The layer-cake identity is exact:

    integral_0^1 1{b>=theta}dtheta=b,
    T=integral_0^1 T_theta dtheta.                       (6)

Use theta>0 in every proof. If I_theta>0 then alpha>0 and b>=theta>0, hence I0>0. Therefore the original low/high point heights and aspect qualification hold on the entire support of I_theta, even though its amplitude can be larger than I0. These hypotheses are support qualifications, not claims that the original e_g or m has been recalculated for a different target amplitude. Original FIRST still holds because I_theta<=alpha<=1, and the hard-source cap is unchanged. At alpha=0 set b=0; such points never enter a positive-theta target. Define theta=0 arbitrarily as the zero target, since this endpoint has zero integration measure. Theta=1 causes no issue: it retains only b=1, still inside the original positive support.

For each fixed theta the source-qualified witness set is simply

    S_(y,theta)(u)={z:z in Q_(R(u))(u), b_y(u,z)>=theta}.

It is a measurable frozen subset of the SAME accepted witness cube, and nu_h(S)<=4lambda R(u)^n. Apply the binary-qualified common-witness theorem and the R304 internal first-moment identity to this target. Its cumulative marked capture A_theta and its quadratic Q_theta satisfy the same original J_y, and hence

    T_theta<=64lambda d W_beta+4 B_H^theta.               (7)

No source/history qualification is transferred from a witness u to a target receiver x. I_theta(x,y,z) remains in the target integral; qualification at u only defines a frozen source subset for the own-scale estimate. Every theta uses the SAME original beta,nu_h,U,J,d,H. Integrating (7) against Lebesgue measure on [0,1], whose total mass is one, charges 64lambda d W_beta ONCE. The same statement holds conditionally under the original outer data.

All integrands are nonnegative measurable functions of theta and the original variables. Finite witness configurations and their minimum-radius source pieces are measurable as before. Tonelli applies without an independent choice for each source pair. Although the proof may construct a witness law separately for each fixed theta, it never selects theta favorably per actual edge: (6) integrates the single shared layer-cake variable over the full target. A coupled realization can equally use common receiver samples for all theta; no independence across theta is required.

The full-soft row bound ensures finite J. Original FIRST gives T_theta<=A_nW_(nu_h), so each finite-target self-absorption used in (7) is legitimate. Original radius atoms are handled separately within each theta by the inclusive-CDF argument; theta integration does not change J or remove crossing atoms.

## 3. Exact coarea identity and the artificial variance removed

For fixed y,u,w,z set

    a=c_u(z)b_y(u,z), a'=c_w(z)b_y(w,z), 0<=a,a'<=1.

The qualified-capture indicators as functions of the SAME theta are the nested intervals 1{theta<=a},1{theta<=a'}. Thus

    integral_0^1 |1{theta<=a}-1{theta<=a'}|dtheta=|a-a'|. (8)

Tonelli in the exact binary quadratic identity proves

    integral_0^1 Q_y^theta(r)dtheta=Q_y^co(r),
    integral_0^1 B_H^theta dtheta=B_H^co.

This proves (1). The prior independent uniform marks instead produce a+a'-2aa'. Their difference is exactly

    a+a'-2aa'-|a-a'|=2min(a,a')[1-max(a,a')]>=0.

Therefore, with B_H^ind denoting the original R304 independent-mark fee at the SAME H and U,J,

    B_H^ind-B_H^co
      =integral beta(dy)ell_n(dr)1{J>=H}/J
          integral_{R(u),R(w)<=r}U_y(u)U_y(w)
            integral min(a,a')[1-max(a,a')]nu_h(dz)du dw >=0. (9)

The source coefficient in (1) is unchanged, so (9) is an exact reduction of the old upper budget. It is not named as a separately paid original traffic portion.

The true coarea integrand decomposes as

    |c_u b_u-c_w b_w|
      =c_u(1-c_w)b_u+c_w(1-c_u)b_w+c_uc_w|b_u-b_w|.       (10)

The first two terms are qualified physical cube-boundary incidence. The last is the REAL change of original qualification within the common cube. The artificial term from independent Bernoulli marks has disappeared; the genuine last term has not. If b_u=b_w is fractional and the cubes both capture z, (10)'s last term is zero, as it should be. If the original qualifications differ at the two receivers, their variation remains and must still be controlled.

In particular, when b is already binary at every receiver, (9) is zero: common-threshold coarea makes no fictitious improvement on that already-binary case. The principal original binary-history problem cannot be solved by this transformation alone.

## 4. A genuinely paid all-target increment using actual FIRST

For the downward quantizer, 0<=b-b_m<delta, except endpoints where it can be zero. The actual discarded target remains nonnegative and supported inside the original positive target. At each accepted receiver,

    integral (b-b_m)U_y(x)beta(dy)
       <=delta integral U_y(x)beta(dy)<=delta.

This is ORIGINAL FIRST, used before any receiver extension and without any source density assumption. Integrate the actual hard source and then use its legal hard-scale envelope once:

    T-T_m<=delta integral nu_h(dz)integral_E h_(R(x))(x-z)dx
           <=delta A_n W_(nu_h).                        (11)

This proves (3). An alternative actual receiver budget is 4lambda delta|E| when that quantity is useful and finite; no absorption entry is assumed. Formula (11), rather than that alternative, is the unconditional source payment used here.

The exact finite layer identity is

    b_m=delta sum_(k=1)^m 1{b>=k/m},
    T_m=delta sum_(k=1)^m T_(k/m).

Every k/m is positive, so the support qualification argument of section 2 applies to all levels, including k=m. Averaging (7) proves (4), with delta m=1. Together with (11),

    T<=64lambda d W_beta+4B_H^(m)+(A_n/m)W_(nu_h).       (12)

This is an exact finite weighted reduction of the complete original target. It does not discard source/history masks or spend the full nu_h mass independently for each layer. A future uniform binary-level estimate may be averaged using these weights; one must not replace the weighted sum by m unweighted source prices.

## 5. The incidence discretization itself has a source-paid error

Let a_m=delta floor(ma). Because c_u is binary, a_m=c_u b_m(u,z). For a>=a', the quantizer preserves their order and the difference between a-a' and a_m-a'_m is the difference of two remainders in [0,delta). Consequently

    ||a_m-a'_m|-|a-a'||<=delta 1{c_u=1 or c_w=1}.         (13)

The discrete coarea identity shows that B_H^(m) is the normalized double-receiver incidence with |a_m-a'_m| in place of |a-a'|. Write

    M_y^0(r)=integral nu_h(dz)integral_{R(u)<=r}
                                      U_y(u)c_u(z)du.

Using (13), the union indicator bound by c_u+c_w, and the half in Q, the error at a positive row satisfies

    |Q_y^(m)(r)-Q_y^co(r)|<=delta J_y(r)M_y^0(r).

Thus, keeping the ORIGINAL denominator and prefix gate,

    |B_H^(m)-B_H^co|
        <=delta integral beta(dy)ell_n(dr)M_y^0(r)
        <=delta A_n W_(nu_h).                            (14)

The last step uses joint original FIRST once, as in R302; M_y^0 is an unqualified positive upper measure only for this error estimate. No source cube cap at a new center is inferred. Equation (14) proves (5). The sign of the quantization error need not be fixed; its absolute value is what is paid.

Choosing m=ceil(sqrt(A_n)) gives A_n/m<=sqrt(A_n) for both (11) and (14). This is a real root source payment for the fractional traffic remainder and for numerical/finite qualification discretization. It is not a new root bound for B_H^co or B_H^(m). The continuous bound (1) is already sharper than replacing B_H^co by its error majorant; the purpose of (12)-(14) is a controlled finite binary formulation with no source-copy inflation.

## 6. Remaining geometry, zero cases and original outer ledger

The remaining exact incidence at each binary level is

    (1/2)integral beta(dy)ell_n(dr)1{J>=4d}/J
       integral_{R(u),R(w)<=r}U_y(u)U_y(w)
          nu_h(S_(y,theta)(u) Delta S_(y,theta)(w))du dw.

It includes common-cube source/history variation, not merely physical cube boundaries. The joint FIRST and same-radius hard caps used above do not yet provide a root-order estimate of its weighted average. Heavy-column overlap and complete original qualification variation must be used together in any next bound; a thin-boundary density estimate or removal of the last term of (10) is not justified.

If b is binary, the rounding remainder is zero for every m, B_H^(m)=B_H^co=B_H^ind, and the remaining problem is unchanged. This explicitly separates the genuine fractional payment from the still-open binary geometric bottleneck. No universal improvement in the dimension exponent is claimed for that binary input class.

If beta or nu_h has zero mass, all target integrals vanish. If J=0 then the corresponding marked and unmarked incidence is zero. H=4d>0 avoids division there. The original low/high constants, aspect v0 and source restriction remain exactly as displayed; in particular lambda d=(4/3)kappa0 psi_inf/v0 can still be expensive for small v0. Radius atoms are handled before theta integration, while threshold endpoints have the conventions specified in section 2.

All statements are conditional on the original outer field xi. Its original positive multiplier Lambda(xi) multiplies (1) or (12), including the single beta source fee, the weighted binary incidence and the paid nu_h remainder, inside the existing outer ledger. Neither coarea nor finite averaging proves that ledger complete, pays the aspect complement, or licenses an unproved epsilon lambda|E| absorption.

## 7. Actual finite exact checks

A local exact-Fraction run tested all-one, fractional receiver-varying, and all-zero qualifications on true finite cube capture patterns in n=1,2,4. It passed 27 common-threshold coarea identities, 27 exact nonnegative artificial-variance gaps, 45 positive traffic-rounding budgets, 135 normalized incidence-rounding budgets, and 30 exact binary invariances. Grid denominators included m=1,2,3,8,16 and qualification/radius threshold equalities. These diagnostics check the algebra and finite geometry; they do not certify the full original low/e_g/history realization or the remaining all-input root incidence bound. The actual code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
ct={'coarea':0,'variance_gap':0,'traffic_rounding':0,'fee_rounding':0,'binary_exact':0}
for n in [1,2,4]:
 rs=[F(1),F(3,2),F(2)];U=[F(1,4),F(1,2),F(1,4)];mass=[F(1,4)]*4
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];zs=centers+[(F(1),)*n]
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for marks in [[[F(1)]*4]*3,[[F(0),F(1,2),F(1),F(1,3)],[F(1,2),F(1),F(1,3),F(0)],[F(1),F(0),F(1,2),F(1)]],[[F(0)]*4]*3]:
  cuts=sorted(set([F(0),F(1)]+[b for row in marks for b in row]));layers=[]
  for k,r in enumerate(rs):
   J=sum(U[:k+1]); a=[[cap[i][z]*marks[i][z] for z in range(4)] for i in range(k+1)]
   A=[sum(U[i]*a[i][z] for i in range(k+1)) for z in range(4)]
   M=sum(m*x for m,x in zip(mass,A));ind=J*M-sum(m*x*x for m,x in zip(mass,A))
   co=sum(U[i]*U[j]*sum(mass[z]*abs(a[i][z]-a[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
   gap=sum(U[i]*U[j]*sum(mass[z]*min(a[i][z],a[j][z])*(1-max(a[i][z],a[j][z])) for z in range(4)) for i,j in product(range(k+1),repeat=2))
   assert ind-co==gap and gap>=0;ct['variance_gap']+=1
   layer=F(0)
   for lo,hi in zip(cuts,cuts[1:]):
    theta=(lo+hi)/2
    aa=[[cap[i][z]*int(marks[i][z]>=theta) for z in range(4)] for i in range(k+1)]
    q=sum(U[i]*U[j]*sum(mass[z]*abs(aa[i][z]-aa[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
    layer+=(hi-lo)*q
   assert layer==co;ct['coarea']+=1
   w=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
   M0=sum(mass[z]*sum(U[i]*cap[i][z] for i in range(k+1)) for z in range(4))
   layers.append((k,w,J,co,M0))
  T=sum(U[i]*rs[i]**(-n)*sum(mass[z]*cap[i][z]*marks[i][z] for z in range(4)) for i in range(3))
  F1=sum(w*M0 for k,w,J,co,M0 in layers)
  for m in [1,2,3,8,16]:
   delta=F(1,m);bm=[[F(int(m*b),m) for b in row] for row in marks]
   Tm=sum(U[i]*rs[i]**(-n)*sum(mass[z]*cap[i][z]*bm[i][z] for z in range(4)) for i in range(3))
   assert 0<=T-Tm<=delta*F1;ct['traffic_rounding']+=1
   for H in [F(1,4),F(1,2),F(2)]:
    Bc=Bq=F(0)
    for k,w,J,co,M0 in layers:
     if J<H:continue
     aa=[[cap[i][z]*bm[i][z] for z in range(4)] for i in range(k+1)]
     qq=sum(U[i]*U[j]*sum(mass[z]*abs(aa[i][z]-aa[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
     Bc+=w*co/J;Bq+=w*qq/J
    assert abs(Bc-Bq)<=delta*F1;ct['fee_rounding']+=1
   if all(b in [0,1] for row in marks for b in row):
    assert bm==marks and Tm==T;ct['binary_exact']+=1
print('PASS',ct)
```

Only /tmp/r305_geometry.md was written. No other author's file, previous frozen proof or Git state was changed.
