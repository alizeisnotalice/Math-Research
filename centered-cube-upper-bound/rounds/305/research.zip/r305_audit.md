# R305 independent audit — preauthor screen

Status: independent proposition screen PASS, with scope restrictions below. This section was saved before reading any R305 author proof.

## Shared threshold construction

Fix the entire original receiver field, sources, full e_g and m, and target mask I0. Assume 0<=alpha<=1 is z-independent and I0<=alpha. Put U=alpha 1_E p/q, b=I0/alpha on alpha>0, and b=0 otherwise. For theta in (0,1], I_theta=alpha 1{b>=theta}. Although I_theta can numerically exceed I0, its positive support is contained in {I0>0}. Thus the original low-pe/high-m/aspect physical heights hold on this support; the witness estimate needs these support heights, not the numerical fractional value. FIRST remains inherited from alpha<=1. Frozen restrictions nu_*<=nu inherit the hard cap; full e_g,m and qualifications are never recomputed.

At theta=0, the >= convention would include the zero mask support. Define that endpoint as zero or omit it; it is a null theta set. All thresholds use the SAME original U,J,d,H. Since integral_0^1 I_theta dtheta=I0, integrating the binary R304 receipt gives

T <= 64 lambda d W_beta + 4 B_co(4d).

The beta fee is charged once, because the threshold interval has length one. These auxiliary threshold traffics are not individually suballocations of the original fractional mask; their integral is exactly the original allocation.

For cube indicators c_u,c_w, the exact coarea identity is

integral_0^1 |c_u 1{b_u>=theta}-c_w 1{b_w>=theta}| dtheta = |c_u b_u-c_w b_w|.

The independent-mark pair disagreement minus this disagreement equals 2 c_u c_w[min(b_u,b_w)-b_u b_w]>=0. The boundary functional itself includes the original 1/2 double-integral prefactor. Thus B_co<=B_ind at fixed U,J,H, but B_co need not be bounded by the unqualified cube boundary: common-cube |b_u-b_w| remains.

## Coarea potential

Let A_theta(r)=integral_{R<=r} U c 1{b>=theta}, with J(r)=integral_{R<=r}U independent of theta. Each 0<=A_theta<=J. The potential V_co(r)=integral_0^1 integral_nu [A_theta-A_theta^2/J] dtheta uses zero value when J=0. The R304 block variance identity integrates directly over nu x theta, retaining its nonnegative square. Consequently V_co is nondecreasing and right-continuous; domination by J W_nu justifies theta integration and right continuity. Its overlap term uses min(b_u,b_w), giving exactly the preceding coarea boundary.

The cutoff W_H=1{J>=H}V_co is nondecreasing right-continuous and the original Stieltjes identity B_co(H)=integral_[a,b] r^-n dW_H(r) holds, including the full first-crossing potential and endpoint atoms. These radius atoms are not original deletion-time atoms.

The common-threshold Poisson average is integral_theta[1-exp(-t A_theta)], not 1-exp(-t A_actual). Applying the binary proof first and then integrating avoids that exchange.

## Finite thresholds and stability (independent extension screen)

For integer m>=1, delta=1/m, b_m=delta floor(mb), the inclusive thresholds k/m give b_m=delta sum_{k=1}^m 1{b>=k/m}, including exact equality at threshold atoms. The positive support is preserved. Original FIRST gives 0<=T-T_m<=delta A_n W_nu. The binary receipt gives T<=64 lambda d W_beta+4 B_m+delta A_n W_nu, where B_m=delta sum B_{k/m}; no m-fold beta cost occurs. If one replaces B_m by B_co, the resulting total error is at most 5 delta A_n W_nu.

More generally, at fixed U,J,H, for b,g in [0,1], the reverse triangle inequality and cancellation of J yield |B(b)-B(g)|<=T_|b-g|. Also |O_co(b)-O_co(g)|<=T_|b-g| by the 1-Lipschitz clipping map and integral_theta |1{b>=theta}-1{g>=theta}|=|b-g|. Uniform mask error delta therefore costs at most delta A_n W_nu. The stability identity does not grant low/m heights on a new support of g; threshold witness payment additionally requires original height/aspect support eligibility.

A single global uniform threshold simultaneously realizes the minimal Bernoulli pair disagreement |a-a'| for every pair of marginals a,a' in [0,1]. This is pair-disagreement optimality, not an assertion of optimality for other nonlinear Poisson or stopping objectives.

## Actual bounded diagnostics

Executed local Python Fraction checks: 64 common-threshold/coarea/disagreement-reduction cases and 96 exact block-variance cases, all PASS. These are finite diagnostics supporting the analytic derivation, not a substitute for it.

## Exact remaining scope

This is a receipt within the original low-pe, high-m, aspect-qualified branch. It does not certify a root bound for B_co or any finite binary-layer boundary, and does not establish the original-X entry connector or pay the independent I/J/D/high-pe suffix slots. When b is already binary, coarea versus independent marks and finite quantization give no improvement. Outer field integration and the original low-slot Lambda factor must still be retained once.

## Author comparison: mask stability

Read `/tmp/r305_mask_stability.md`, SHA256 `fc8723a0d0e27a1d0620a7b177c05d69128ebeed61bd36eef9543a45c6879b20`. PASS: S1-S2 correctly use original FIRST and the layer identity to cancel the shared J, retain actual q/scales and all source weights, and explicitly separate mask-functional stability from the eligibility required by the own-scale traffic bridge. Coarea Poisson stability is derived before any unsupported coupling exchange. The pair-cost optimality statement is correctly restricted to expected disagreement. Additional actual Fraction diagnostics: 2500 reverse-triangle mask cases and 400 inclusive-floor/coarea cases, all PASS.

## Author comparison: shared-threshold geometry

Read `/tmp/r305_geometry.md`, SHA256 `647f31f628134976cea12ce6275add6dce6ed95fd4a5d34b10b0ba3df9c7b5ed`. PASS: (1)-(14) match the independent screen, with original positive-support eligibility, alpha/threshold zero conventions, original U/J/H and full e/m frozen, exact nonnegative independent-mark variance removal, and one beta source charge. The finite weighted levels have total weight one; (12) retains the actual traffic error separately from the absolute boundary error. The geometric term still includes common-cube qualification variation; binary masks gain nothing from this transformation. The outer Lambda and aspect/source costs are explicitly retained.

Independently executed the exact embedded reproduction in memory: 27 coarea identities, 27 variance-gap cases, 45 traffic-rounding budgets, 135 incidence-rounding budgets, 30 binary invariances; all PASS. These are finite cube-capture diagnostics, not an all-input original-history realization or a root-bound proof.

## Author comparison: high-capture / column budget

Read `/tmp/r305_joint_budget.md`, SHA256 `eb4237d9aa086fbb7d6a2754c57e8351a949b2d756ac6ccb8a639313e38d5841`. PASS. The high-capture fee is bounded by eta times the EXACT same qualified T; its internal finite-T absorption yields the displayed H=8d, eta=1/8 coefficient 128 lambda d, while retaining the entire low-plus-middle fee. This is an alternative receipt at H=8d; no substitution of the main H=4d fee is permitted. Lambda occurs once.

The exact re-column identity preserves both the negative mean square and nonnegative between-row variance. Actual receiver FIRST implies C_col(z,r)<=r^n and eta E_mid<=L_mid<=r^n, without granting source density. The scalar G(E,c) is the optimum under the stated scalar constraints. These facts alone recover only A_n W_nu; the note correctly leaves the low and multiscale middle fees unpaid. Levelwise application then theta averaging uses the same J and one source budget, never the variance of averaged p.

Actually executed the embedded Fraction occupation diagnostic: 18 high receipts, 864 re-column identities, 216 middle packings, 18 full complements; all PASS. This is an occupation-model check, not an original low/e/history realization.

## Frozen component and finite-evidence bindings

- `/tmp/r305_geometry.md`: SHA256 `647f31f628134976cea12ce6275add6dce6ed95fd4a5d34b10b0ba3df9c7b5ed`.
- `/tmp/r305_mask_stability.md`: SHA256 `fc8723a0d0e27a1d0620a7b177c05d69128ebeed61bd36eef9543a45c6879b20`.
- `/tmp/r305_joint_budget.md`: SHA256 `eb4237d9aa086fbb7d6a2754c57e8351a949b2d756ac6ccb8a639313e38d5841`.
- `/tmp/r305_numeric.py`: SHA256 `d8c64466bcf93040ce8719e9e0fbe27203c9c15333b330c0ea921daa4268129e`.
- `/tmp/r305_numeric.json`: SHA256 `2c283aacf0c5c293e930b65322e99c940078836c72fdbba92ebd1fbc45a21a5a`.
- `/tmp/r305_numeric.md`: SHA256 `8c56752b2ef43f1a9b5cb48ed8760bfb195db1ce70ac64570b6fe19705e50aa5`.
- `/tmp/r305_stability_checks.py`: SHA256 `50223defde08ecf4cb60ff6df2c546e3fd50abab4e71c5dd9667bcd69336f394`.
- `/tmp/r305_stability_checks.json`: SHA256 `44f1127f0350e920c8e5e03c9cc7cbcc6e6a0c51ab47b6ccbce0556adcc84107`.

Inspected the completed numeric artifact: status PASS, failures empty, sum of exact counts 16237. The 24 qualification/model groups retain actual positive-volume s=0 geometry, FIRST and same-radius caps; full original low/e/m/history is explicitly not realized. The n=16,32 shell menus use 17 layers in this round, and earlier R304 checks are not relabeled as current work.
The stability artifact has 1320 exact synthetic checks (180 B modulus, 180 O modulus, 720 coupling lower bounds, 240 comonotone equalities); it explicitly disclaims an original L1/full-history realization. These two artifact counts were inspected, while the independent local and embedded checks recorded above were actually executed in this audit. Parent-reported independent reruns are separate evidence.

## Final integration verdict — frozen

PASS. Read the final README and detailed TeX source without compiling. README now explicitly states 0<=I0<=alpha<=1, alpha=0 convention and the inverse-aspect coefficient d. Both integration documents match the three audited proofs: main H=4d/64 lambda d receipt, separate H=8d/128 lambda d high-capture alternative with the whole low-plus-middle complement, exact coarea reduction, weighted stability, and finite threshold fee with total weight one. TeX explicitly records the combined 1+4=5 error coefficient if both approximation errors are substituted. The documents retain the binary qualification bottleneck, outer Lambda once, aspect cost, and incomplete original total ledger. No new epsilon X or full weak-type closure is asserted.

- `/tmp/r305_README.md`: SHA256 `a70eb0d5e87f694f11406703f8c7ba9a45604fe1206c3ad4684ed0322dfef6db`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_research.tex`: SHA256 `87e694cf8bcdb1fb50cfdf979bb64ddf285bb56a3d27f348fe43ef45ea60d8ae`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_geometry_checks.py`: SHA256 `d122584140b160212b57ee8968861f06f4074ea4530ccc7cd53fa5b7892215bf`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_joint_budget_checks.py`: SHA256 `06d90eeb0be451b98ab8b3bb8fa2eb84338b7c65622e29d5e004f4cc2574064b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_numeric.py`: SHA256 `d8c64466bcf93040ce8719e9e0fbe27203c9c15333b330c0ea921daa4268129e`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_stability_checks.py`: SHA256 `50223defde08ecf4cb60ff6df2c546e3fd50abab4e71c5dd9667bcd69336f394`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_numeric.json`: SHA256 `2c283aacf0c5c293e930b65322e99c940078836c72fdbba92ebd1fbc45a21a5a`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_stability_checks.json`: SHA256 `44f1127f0350e920c8e5e03c9cc7cbcc6e6a0c51ab47b6ccbce0556adcc84107`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_geometry_checks.log`: SHA256 `5adc65f2b1d8525a785d1d95a4ed9205bcb85d5f57f2a9d1435d43494720705b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_joint_budget_checks.log`: SHA256 `3b338418a4aa717fc8361adfac32b7bfd898fcb15a6a8d1a833ac47bf94fb606`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_numeric.log`: SHA256 `5213ad563656e92dcc0f114e4cce5ab4a5903aa33602bdad8eeb971b8d929787`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round305_20261017_final_checkpoint/r305_stability_checks.log`: SHA256 `63606ba343a713603bfe65ec98739fcaca03e8c332d82267e27bfa315a4857c0`.

Inspected staging logs: geometry 264 PASS and joint-budget 1116 PASS; both agree with this audit's actual embedded-code executions. Staged numeric/stability scripts and JSON are byte-identical to the frozen /tmp originals. Completed numeric JSON has 16237 PASS with empty failures, stability has 1320 PASS. Parent reported all four staging reruns completed; observed logs and output bindings support those counts. No finite model is promoted to an original full low/e/m/history realization.

The exact remaining mathematical gap is a general original-source/multiscale estimate for the weighted binary-level incidence, including genuine within-common-cube qualification variation and its entire low/intermediate capture portion. Coarea and approximation do not pay that fee; extreme-aspect and independent original-ledger slots plus the uncertified global entry connector remain. No author/repository/TeX/PDF files were modified by this audit. This audit is frozen at these hashes.
