from fractions import Fraction as F
from itertools import product
beta=[F(1,2),F(1,3),F(1,6)]
cells=[(F(0),F(1,4)),(F(1,2),F(3,4)),(F(1),F(5,4))]
rad=[F(1),F(3,2),F(2)]
U=[[F(1),F(1,2),F(1,4)],[F(1,2),F(1),F(1,2)],
   [F(1,4),F(1,2),F(1)]]
zs=[F(-1,4),F(1,4),F(3,4),F(5,4)]
nu=[F(1,3),F(1,5),F(1,7),F(1,11)]
assert all(sum(beta[y]*U[y][i] for y in range(3))<=1 for i in range(3))
ct=dict(high_receipt=0,recolumn_identity=0,middle_packing=0,full_complement=0)
for regime in range(3):
 layers=[]
 for k,r in enumerate(rad):
  J=[sum(U[y][i]*(cells[i][1]-cells[i][0])
         for i in range(k+1)) for y in range(3)]
  A=[]
  for y in range(3):
   az=[]
   for zi,z in enumerate(zs):
    val=F(0)
    for i in range(k+1):
     hit=max(F(0),min(cells[i][1],z+rad[i]/2)
                         -max(cells[i][0],z-rad[i]/2))
     mark=(F(1) if regime==0 else
          (F((y+i+zi)%2) if regime==1 else F((y+i+zi)%3,2)))
     val+=U[y][i]*hit*mark
    az.append(val)
   A.append(az)
  w=1/r-(1/rad[k+1] if k<2 else 0)
  layers.append((w,r,J,A))
 for H,eta in product([F(1,16),F(1,8),F(1,4)],[F(1,8),F(1,4)]):
  T=sum(w*sum(beta[y]*nu[z]*A[y][z]
      for y in range(3) for z in range(4)) for w,r,J,A in layers)
  Bs=[F(0),F(0),F(0)]
  for w,r,J,A in layers:
   for z in range(4):
    groups=[[],[],[]]
    for y in range(3):
     if J[y]<H: continue
     p=A[y][z]/J[y]
     g=2 if p>=1-eta else (1 if p>=eta else 0)
     groups[g].append(y)
     Bs[g]+=w*beta[y]*nu[z]*J[y]*p*(1-p)
    for inds in [sum(groups,[])]+groups:
     E=sum((beta[y]*J[y] for y in inds),F(0))
     L=sum((beta[y]*A[y][z] for y in inds),F(0))
     V=sum((beta[y]*A[y][z]*(1-A[y][z]/J[y]) for y in inds),F(0))
     assert L<=r
     if E:
      between=sum(beta[y]*J[y]*(A[y][z]/J[y]-L/E)**2 for y in inds)
      assert V==L-L*L/E-between
     else: assert L==V==0
     ct['recolumn_identity']+=1
    mid=groups[1]
    Em=sum((beta[y]*J[y] for y in mid),F(0))
    Lm=sum((beta[y]*A[y][z] for y in mid),F(0))
    assert eta*Em<=Lm<=r
    ct['middle_packing']+=1
  assert Bs[2]<=eta*T
  ct['high_receipt']+=1
  Ball=sum(w*sum(beta[y]*nu[z]*A[y][z]*(1-A[y][z]/J[y])
       for y in range(3) if J[y]>=H for z in range(4))
       for w,r,J,A in layers)
  assert sum(Bs)==Ball
  ct['full_complement']+=1
print('PASS',ct)
