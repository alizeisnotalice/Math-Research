from fractions import Fraction as F
from itertools import product
ct={'coarea':0,'variance_gap':0,'traffic_rounding':0,'fee_rounding':0,'binary_exact':0}
for n in [1,2,4]:
 rs=[F(1),F(3,2),F(2)];U=[F(1,4),F(1,2),F(1,4)];mass=[F(1,4)]*4
 centers=[(F(0),)*n,(F(1,2),)*n,(F(2),)*n];zs=centers+[(F(1),)*n]
 cap=[[int(all(abs(z[k]-c[k])<=r/2 for k in range(n))) for z in zs] for c,r in zip(centers,rs)]
 for marks in [[[F(1)]*4]*3,[[F(0),F(1,2),F(1),F(1,3)],[F(1,2),F(1),F(1,3),F(0)],[F(1),F(0),F(1,2),F(1)]],[[F(0)]*4]*3]:
  cuts=sorted(set([F(0),F(1)]+[b for row in marks for b in row]));layers=[]
  for k,r in enumerate(rs):
   J=sum(U[:k+1]); a=[[cap[i][z]*marks[i][z] for z in range(4)] for i in range(k+1)]
   A=[sum(U[i]*a[i][z] for i in range(k+1)) for z in range(4)]
   M=sum(m*x for m,x in zip(mass,A));ind=J*M-sum(m*x*x for m,x in zip(mass,A))
   co=sum(U[i]*U[j]*sum(mass[z]*abs(a[i][z]-a[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
   gap=sum(U[i]*U[j]*sum(mass[z]*min(a[i][z],a[j][z])*(1-max(a[i][z],a[j][z])) for z in range(4)) for i,j in product(range(k+1),repeat=2))
   assert ind-co==gap and gap>=0;ct['variance_gap']+=1
   layer=F(0)
   for lo,hi in zip(cuts,cuts[1:]):
    theta=(lo+hi)/2
    aa=[[cap[i][z]*int(marks[i][z]>=theta) for z in range(4)] for i in range(k+1)]
    q=sum(U[i]*U[j]*sum(mass[z]*abs(aa[i][z]-aa[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
    layer+=(hi-lo)*q
   assert layer==co;ct['coarea']+=1
   w=r**(-n)-(rs[k+1]**(-n) if k<2 else F(0))
   M0=sum(mass[z]*sum(U[i]*cap[i][z] for i in range(k+1)) for z in range(4))
   layers.append((k,w,J,co,M0))
  T=sum(U[i]*rs[i]**(-n)*sum(mass[z]*cap[i][z]*marks[i][z] for z in range(4)) for i in range(3))
  F1=sum(w*M0 for k,w,J,co,M0 in layers)
  for m in [1,2,3,8,16]:
   delta=F(1,m);bm=[[F(int(m*b),m) for b in row] for row in marks]
   Tm=sum(U[i]*rs[i]**(-n)*sum(mass[z]*cap[i][z]*bm[i][z] for z in range(4)) for i in range(3))
   assert 0<=T-Tm<=delta*F1;ct['traffic_rounding']+=1
   for H in [F(1,4),F(1,2),F(2)]:
    Bc=Bq=F(0)
    for k,w,J,co,M0 in layers:
     if J<H:continue
     aa=[[cap[i][z]*bm[i][z] for z in range(4)] for i in range(k+1)]
     qq=sum(U[i]*U[j]*sum(mass[z]*abs(aa[i][z]-aa[j][z]) for z in range(4)) for i,j in product(range(k+1),repeat=2))/2
     Bc+=w*co/J;Bq+=w*qq/J
    assert abs(Bc-Bq)<=delta*F1;ct['fee_rounding']+=1
   if all(b in [0,1] for row in marks for b in row):
    assert bm==marks and Tm==T;ct['binary_exact']+=1
print('PASS',ct)
