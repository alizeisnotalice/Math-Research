# R305 common-threshold coarea diagnostics

Exact finite diagnostics on actual s=0 positive-L1 cell and shell geometries, FIRST<=1 and same-radius hardcap<=4. Frozen qualification masks do not implement original full low/e/m history; no root payment or FULL closure is certified.

The same cell generation as R304 is copied self-contained. High-dimensional shell menus use m=min(4n,16), hence17 shells at n16 and32, rather than65/129 shells in R304. Dimensions and positive-volume support remain genuine; old7793 checks are not rerun.

One global theta uniform on(0,1), atom levels1/4,1/2,1 and widths1/4,1/4,1/2. J remains unmarked receiver mass. Atheta=sum u_i 1{c_iz b_ijz>=theta}.

Qco=integral_theta[J Mtheta-sum nu Atheta^2]=1/2 sum_ik u_i u_k sum nu |a_i-a_k|. Qind-Qco=sum_ik u_i u_k sum nu[min(a_i,a_k)-a_i a_k]>=0. First moment preserved; Oco<=Oind by concavity. Integrated Vco obeys exact block pooling at original J, including zero masses.

|model / qualification|layers|positive Qco|strict Qco<Qind|
|---|---:|---:|---:|
|disjoint_n1_geometry_fractional|8|0|2|
|disjoint_n1_constant_half|8|0|6|
|disjoint_n1_binary_varying|8|0|0|
|overlap_chain_n1_geometry_fractional|18|7|10|
|overlap_chain_n1_constant_half|18|7|14|
|overlap_chain_n1_binary_varying|18|7|0|
|cross_n4_geometry_fractional|48|13|24|
|cross_n4_constant_half|48|11|35|
|cross_n4_binary_varying|48|12|0|
|tied_n4_geometry_fractional|32|10|12|
|tied_n4_constant_half|32|10|18|
|tied_n4_binary_varying|32|10|0|
|cross_n8_geometry_fractional|48|13|24|
|cross_n8_constant_half|48|11|35|
|cross_n8_binary_varying|48|12|0|
|cross_n16_geometry_fractional|48|13|24|
|cross_n16_constant_half|48|11|35|
|cross_n16_binary_varying|48|12|0|
|concentric_shell_n16_geometry_fractional|17|16|16|
|concentric_shell_n16_constant_half|17|0|17|
|concentric_shell_n16_binary_varying|17|16|0|
|concentric_shell_n32_geometry_fractional|17|16|16|
|concentric_shell_n32_constant_half|17|0|17|
|concentric_shell_n32_binary_varying|17|16|0|

On true complete-capture shells, constant fractional qualification gives Qco=0 while Qind>0: common threshold removes artificial independent-mark variance. Binary varying qualifications retain positive Qco on these same geometries, so coarea does not erase genuine qualification variation.

At each original J=H atom, use large branch once. Oco<=4H Wbeta+(d/H)Cmenu Wnu+BHco; beta appears only once in each fee.

m=1,3,5,ceil sqrt(1+n); bm=floor(mb)/m. T-Tm<=Cmenu Wnu/m and |BHco-BHm|<=Cmenu Wnu/m at two existing J thresholds. Pair Bm equals uniform-grid threshold average; delta=1/m sums to1, and sum_j beta_j sum delta=Wbeta.

All comparisons are exact Fraction; the file contains geometry and qualification recipes for reproduction. Only these finite models are tested.
