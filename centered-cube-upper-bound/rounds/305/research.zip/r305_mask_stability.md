# R305 — uniform source-linear stability of qualified geometric functionals

This lemma uses actual Lebesgue receiver measure and original sources. It is not a dimension-root bound for the geometric functional itself. Fix original U_y(x)>=0, a<=R(x)<=b, and original FIRST integral U_y(x)beta(dy)<=1 almost everywhere on its receiver domain. Assume finite positive beta,nu and finite rows; all outside original multipliers remain outside. Put c_x(z)=1{z in Q_R(x)(x)} and J_y(r)=integral_(R<=r)U_y dx. J does not change with the qualification profile.

For any two measurable qualification profiles b_y(x,z),g_y(x,z) in [0,1], let

 T_b=integral U_y(x)b_y(x,z)R(x)^(-n)c_x(z) dx beta(dy)nu(dz).

Define the COMMON-THRESHOLD incidence functional

 B_H(b)=integral beta(dy)ell_n(dr)1{J_y(r)>=H}/(2J_y(r))
         integral_(R(x),R(w)<=r)U_y(x)U_y(w)
             integral |c_x(z)b_y(x,z)-c_w(z)b_y(w,z)|nu(dz)dx dw.

Here H>0 and ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr. There is no division on zero rows. Define its unqualified captured first moment F0=integral U_y(x)R(x)^(-n)c_x(z)dx beta(dy)nu(dz). Original FIRST, followed by the positive hard-scale envelope, gives

 F0<=A_n W_nu, A_n=1+n log(b/a).

In detail, for fixed x,z first integrate U_y over beta (at most one); then integrate the actual selected h_R(x-z) against dx. It is bounded by the integrable envelope H(z-x)=integral h_r(z-x)[delta_b(dr)+n dr/r], of mass A_n. This does not assume a source density cap, or a cap at source centers. Actual q and U remain frozen. No beta totalmass times nu totalmass is introduced.

## Uniform qualification stability

If |b-g|<=delta almost everywhere on the actual U_y dx beta nu measure, then

 |T_b-T_g|<=delta F0<=delta A_n W_nu,
 |B_H(b)-B_H(g)|<=delta F0<=delta A_n W_nu.          (S1)

The first inequality is immediate positive domination. For the second, the reverse triangle inequality bounds the difference of pair integrands by

 c_x(z)|b_y(x,z)-g_y(x,z)|+c_w(z)|b_y(w,z)-g_y(w,z)|.

Integrating the other receiver variable gives J in each term and cancels exactly the denominator 2J. Thus the absolute difference is at most delta times the high-prefix unqualified first moment, which is at most F0 by Tonelli. This works for every H, including atomic crossings and the terminal ell mass, with no H-dependent constant. Pairwise almost-everywhere statements follow by Fubini from the original marginal exceptional set; finite rows ensure the product exceptional set is null.

A weighted version replaces delta F0 by the ORIGINAL traffic of the absolute mask difference:

 |B_H(b)-B_H(g)| <= integral U_y(x)|b-g| h_R(x-z)dx beta(dy)nu(dz). (S2)

Indeed, the same pair integration gives its cumulative layer first moment; dropping only 1{J>=H} and using ell([R,b])=R^-n gives the right side exactly. This weighted modulus retains actual spatial allocation and can be smaller than the uniform bound. It has no new source credit: its right side must be paid on the original measure.

## Layer discretization and its limits

For integer m>=1 let g=floor(mb)/m. Then 0<=g<=b and |b-g|<1/m except at b=1 where it is zero. Moreover

 g=(1/m)sum_(k=1)^m 1{b>=k/m}.

Both T_g and B_H(g) are exactly the corresponding 1/m-weighted sums of binary-threshold traffic and incidence. For the second claim use |floor(ms)-floor(mt)|/m=(1/m)sum_k |1{s>=k/m}-1{t>=k/m}| on s,t in[0,1], with c_xb folded into s. Hence S1 gives uniform all-input source-linear errors <=A_n W_nu/m. Taking m=ceil(sqrt(A_n)) pays each such error at <=sqrt(A_n)W_nu. The weights sum to one, not m independent source payments. For b already binary the discretization is exact and makes no improvement to its unresolved geometry.

The threshold profiles may exceed the original b numerically. Their positive support lies inside {b>0}, so the separate low-pe,m>M own-scale theorem can be used only when all its original point-height assumptions hold on that support. S1-S2 themselves require only original FIRST and the stated actual scale window. They do not manufacture the own-scale assumptions. Original e_g,m,q, original I0/alpha normalization and all outside source budgets must remain frozen.

For an auxiliary Poisson capacity averaged over a common threshold, the analogous stability follows from |min(d,A)-min(d,C)|<=|A-C|, nonnegative Fubini and integral_0^1 |1{b>=theta}-1{g>=theta}|dtheta=|b-g|. Thus |Oco_d(b)-Oco_d(g)| is bounded by the same weighted right side of S2. This is stability of the capacity, not proof of a new traffic bridge absent the original own-scale hypotheses.

## Coupling optimality at fixed marginal qualifications

For any random binary qualification fields Z_x(z) with E Z_x(z)=c_x(z)b_y(x,z), the elementary inequality E|Z_x-Z_w|>=|E Z_x-E Z_w| applies. A single uniform theta shared by every receiver and every source simultaneously, Z_x(z)=1{theta<=c_x(z)b_y(x,z)}, achieves equality for all pairs. Consequently common thresholds minimize the expected pairwise incidence at fixed U,J and marginal b over all such couplings, even couplings that alter across sources. The original independent-mark construction need not be optimal. This is an exact pair-cost optimum, not a proof that arbitrary alternative couplings satisfy the same Poisson bridge: the legal bridge is obtained by applying the binary theorem conditional on theta before averaging.

The weighted derivative/stability bound (S2) is the new source-conserving tool. It does not pay B_H(b) itself, its binary intermediate-capture complement, extreme aspect, original time atoms or the missing global entry. Any outer allocation multiplies S1-S2 once and needs the original integrated source bridge.
