#!/usr/bin/env python3
"""Actual physical n1 integrals and common-measure algebra; not FULL."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def phi(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def val(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def enc(v):return mp.nstr(v,32)
def physical(c,dps):
 with mp.workdps(dps):
  L=mp.mpf(c['L']);R=mp.mpf(c['R']);y=mp.mpf(c['y']);region=c['Omega'];lo=-R/2 if region=='full' else mp.mpf(0);hi=R/2;O=mp.mpf(0) if region=='empty' else (hi-lo)/R;E=max(mp.mpf(0),abs(y)/2-1)
  cuts=sorted(set([lo,hi]+[x for x in (mp.mpf(0),y-L/2,y+L/2) if lo<x<hi]));I=mp.mpf(0)
  if region!='empty':
   for u,v in zip(cuts,cuts[1:]):I+=mp.quad(lambda x:val((x-y)/L,mp.mpf('.2') if x<0 else mp.mpf('.8'))/(L*R),[u,v])
  bound=O*mp.exp(-E);assert I<=bound*(1+mp.mpf(10)**(-dps+5))
  return {k:enc(v) for k,v in dict(I0=I,O=O,E=E,bound_with_O=bound,bound_without_O=mp.exp(-E),I0_over_bound=I/bound if bound else mp.mpf(0),I0_per_O=I/O if O else mp.mpf(0)).items()}
def pow0(x,t):return mp.mpf(1) if t==0 else x**t

def holder(c,dps):
 with mp.workdps(dps):
  theta=mp.mpf(c['theta']);O=mp.mpf(c['O']);weights=list(map(mp.mpf,['1','.5','2','.125']));Es=list(map(mp.mpf,['0','1','8','40']));damping=list(map(mp.mpf,['.8','.3','.9','.1']));Is=[O*mp.exp(-E)*t if not c.get('zero_I') else mp.mpf(0) for E,t in zip(Es,damping)];row=sum(w*i for w,i in zip(weights,Is));q=(row/O if O else mp.mpf(0))+mp.mpf('.01');weightedmass=sum(w*mp.exp(-E/2) for w,E in zip(weights,Es));lhs=sum(w*i**(1-2*theta) for w,i in zip(weights,Is));rhs=pow0(q*O,1-4*theta)*pow0(O,2*theta)*pow0(weightedmass,4*theta)
  assert row<=q*O and all(i<=O*mp.exp(-E) for i,E in zip(Is,Es)) and lhs<=rhs*(1+mp.mpf(10)**(-dps+5))
  return {k:enc(v) for k,v in dict(q=q,row=row,row_cap=q*O,m_weight=weightedmass,lhs=lhs,rhs=rhs,ratio=lhs/rhs if rhs else mp.mpf(0),FIRST_exponent=1-4*theta,envelope_exponent=2*theta,weightedmass_exponent=4*theta).items()}

def far(c,dps):
 with mp.workdps(dps):
  n=c['n'];logrho=mp.mpf(c['logrho']);rho=mp.exp(logrho);cut=2*max(mp.mpf(0),logrho);Es=[mp.mpf(0),cut,cut+1];fractions=[mp.mpf(1)/2,mp.mpf(1)/3,mp.mpf(1)/6];farparts=[rho*w*mp.exp(-E/2) for w,E in zip(fractions,Es) if E>=cut];rhofar=sum(farparts);rhow=sum(rho*w*mp.exp(-E/2) for w,E in zip(fractions,Es));rhonear=rhow-rhofar;assert rhofar<=1+mp.mpf(10)**(-dps+5)
  K=mp.mpf(256);N=int(mp.ceil(mp.pi*mp.sqrt(n)));B=mp.e*N;Rw=1+max(mp.mpf(0),mp.log(rhofar))+mp.log(K)+mp.log(B);delta=mp.mpf(0) if c['delta_mode']=='zero' else mp.exp(-20) if c['delta_mode']=='tiny' else Rw**(-3);core=mp.mpf(0) if not delta else delta*(Rw+mp.log(1/delta)/2)**3;fee=84*(mp.mpf(128)/119)*mp.e**5*core
  return dict(n=n,N=N,delta_mode=c['delta_mode'],logrho=enc(logrho),rho=enc(rho),far_E_threshold=enc(cut),rho_weighted_far=enc(rhofar),rho_weighted_near=enc(rhonear),rho_weighted_total=enc(rhow),K=enc(K),B=enc(B),R_weighted_far=enc(Rw),delta=enc(delta),delta_Rcubed=enc(delta*Rw**3),price_core=enc(core),price_with_84_Lambda_e5=enc(fee),scope='Finite scalar distances with original mass split once; no FIRST resources reused by distance layers, no FULL or n-order conclusion.')
def main(output,contract):
 menu=[dict(stage={0:'initial',2:'stress',8:'expanded'}[y],L=L,R=R,y=str(y),Omega=region) for y in (0,2,8) for L,R in [('1','2'),('2','1')] for region in ('full','positive_half')];menu.append(dict(stage='stress',L='1',R='2',y='8',Omega='empty'));rows=[]
 for c in menu:
  a=physical(c,30);b=physical(c,50)
  with mp.workdps(70):
   difference=abs(mp.mpf(a['I0'])-mp.mpf(b['I0']));assert difference<mp.mpf('1e-25');diff=enc(difference)
  rows.append(dict(configuration=c,mp30=a,mp50=b,absolute_precision_difference=diff))
 hm=[dict(theta=t,O=O) for t in ('.25','.1','.01') for O in ('1','.01','0')]+[dict(theta='.25',O='1',zero_I=True)];hrows=[dict(configuration=c,mp40=holder(c,40),mp70=holder(c,70)) for c in hm];fm=[dict(n=n,logrho=lr,delta_mode=mode) for n in (2,1000,1000000) for lr,mode in [('-2','zero'),('0','tiny'),('20','branch')]];frows=[dict(configuration=c,mp40=far(c,40),mp70=far(c,70)) for c in fm]
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),scope='Finite actual-kernel n1 tools and commonbasis Holder/far-gate diagnostics; not original FULL, general root proof or adaptive kernel-column normalization.',actual_softness='s(x)=.2 ifx<0,.8 otherwise, same physical common softness for each receiver',physical_parameters='a1,b2,z0; P_s,L=L^-1[(1-s)h(x/L)+s phi(x/L)]; hard h_R=R^-1 1_QR',physical_rows=rows,holder_arrays=hrows,holder_fixed_arrays=dict(beta_weights=['1','1/2','2','1/8'],E=['0','1','8','40'],damping=['.8','.3','.9','.1'],I='O exp(-E) damping, orzero; a^-n1; one common beta basis for row/envelope/interpolation',theta_quarter_guard='(qO)^0=1 explicitly even qO0; O^(2theta)=0 then whole bound0'),far_gate_rows=frows,counts=dict(actual_kernel_integrals=len(rows),common_Holder_arrays=len(hrows),far_gate_cases=len(frows)),precision_scope='Physical mp30/50 split ordinary quadrature, not interval proof; arrays/far mp40/70. Compact hard support has no omitted spatial tail. E envelope refers to z-y, not coordinatewise adaptive soft choice.')
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
