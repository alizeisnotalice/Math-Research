# R240 bounded design

Actual menu:12 true n=1 adaptive-soft kernel integrals with L/R=(1,2),(2,1), y=0/2/8, Omega full hardcube or its positive half; one empty-Omega boundary. Independent finite common-Holder arrays test theta=.25/.1/.01 and O=1/.01/0, plus a zero-I endpoint. Nine finite far-gate rows use n2/1000/1e6 and log rho=-2/0/20, preserving explicit K/B and delta-zero handling. These are distinct finite tools, not original FULL histories or fitted dimension orders. Only owned numerical files will change.

## Actual real-kernel menu and precision

All32 planned configurations ran:13 physical integrals,10 finite common-Holder arrays and9 far-gate algebra rows. Initial physical y=0, pressure y=2 and expanded y=8 each contain both(L,R)=(1,2),(2,1) and full/positive-half hardcube Omega. An additional empty-Omega case checks O=I0=0. All have a=1,b=2,z=0 and actual common s(x)=.2 for x<0,.8 otherwise. The physical kernel is P_s,L(x-y)=L^-1[(1-s)h((x-y)/L)+s phi((x-y)/L)], with true phi=h*integral_0^1 exp(-|u|/r)dr; h_R=R^-1 indicator[-R/2,R/2]. This is an actual one-dimensional integral with an adaptive measurable soft parameter, not independent soft choices in coordinates.

The compact receiver integration is split at0 and y±L/2 whenever inside Omega. mpmath30/50dps independently evaluates phi's E3 formula and each integral. Maximum recorded30/50 difference is2e-32. This is ordinary high-precision noninterval quadrature; agreement is not a rigorous error certificate. There is no omitted infinite receiver tail because hard h_R vanishes outside the integrated cube. Source y is a fixed physical kernel location, not a claimed original finite-L1 FULL source/history construction.

The verified distance envelope uses E=(|y|/2-1)+ and keeps I0<=O exp(-E), with a^-n=1. For the twelve nonempty cases I0/bound ranges approximately.000572148 to.440382075. At y=8 the maximum ratio is.031744269. Full Omega has O=1 and positive half has O=1/2; the latter halves the upper-envelope price. Dropping O yields a looser inequality that discards this measured geometric gain; it is not used for the subsequent interpolation. Empty Omega gives both I0 and the O-weighted envelope exactly0. No adaptive-scale column bound I0<=M^-n is assumed, especially in orientation R>L.

## Common-basis Holder endpoint checks

All arrays use the same positive beta weights(1,1/2,2,1/8), E=(0,1,8,40), and I_i=O exp(-E_i) damping_i with damping(.8,.3,.9,.1). q is fixed for the array as weightedrow/O+.01 when O>0 and.01 when O=0. It is not used as a claim of original global FIRST geometry. Each array checks the row constraint sum beta I<=qO, the pointwise envelope I<=O exp(-E), and the combined bound

    sum beta I^(1-2theta)
    <= (qO)^(1-4theta) O^(2theta)
       [sum beta exp(-E/2)]^(4theta).

Theta=.25,.1,.01 each uses O=1,.01,0. One additional theta=.25,O=1 array has I identically0. The theta=.25 zero exponent is explicitly evaluated as(qO)^0=1 even when O=0; the remaining O^(2theta) then correctly forces RHS0. Nonzero lhs/rhs ranges.817439143 to.978337672. Every row is independently evaluated at40/70dps. These finite arrays test one common measure and joint constraints, not unrelated optimizers or a FULL source realization.

## Far-source one-time partition and explicit price

Nine algebra rows use n=2,1000,10^6 and log rho_D=-2,0,20. Three source fractions1/2,1/3,1/6 have E=0,cut,cut+1 with cut=2 log_+rho_D. Each original piece is assigned once to F={E>=cut} or its complement; the same FIRST resource is not claimed once per distance layer. The resulting rho_w,F is.1264602358,.9344217766,.4344217766 respectively, hence<=1, with near and total weighted mass also retained. This is a scalar source-weight diagnostic, not evidence that every input has a nonempty useful far part or that the original FULL branch is covered.

K=256 remains explicit in each row, N=ceil(pi sqrt n), B=eN and R_w=1+log_+rho_w,F+log K+log B. Delta is respectively0,exp(-20),R_w^-3 for the three mass settings. Delta0 is evaluated directly as zero fee, without log(1/0). The JSON retains both delta[R_w+.5log(1/delta)]^3 and the entire84Lambda exp(5) multiplier with Lambda=128/119. No assertion about allowed n dependence of K, or fitted dimension order, is made. These rows do not remove the unpaid near-source part.

Compare's stronger phi/CDF/relative-scale envelopes were supplied as contextual metadata but are not extra claimed checks in this script. Only the simple O-weighted bound above is tested here; no duplicated complex menu or extra spatial cases were run.

## Reproduction

Existing bundled Python3.12.14 and vendor mpmath1.3.0 only; no package installation or NumPy dependency is needed.

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/240/work/numeric_checks.py \
--output /tmp/r240_numeric_replay.json \
--contract /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/240/work/task_contract.md
```

The script and adjacent contract may be relocated; path/runtime strings are excluded from the JSON. Only the three owned numerical files were edited.

## Frozen final replay

The complete separate-output replay was byte-identical: 38760 bytes, actual wall.30s,user.28s,system.00s. Actual counts13 physical kernels,10 common-Holder arrays,9 far-gate rows. SHA256 source `1d9ebe208f6d948d779b1b390385d340e08f1ec625dadd12663b92f89cfe90e1`; JSON `99a0b9cac34154af4757aae67903571bde737af8cf16e581eaea2dfd301650d5`; contract `b1c541ae866e8c6293af465e55a1ae17bde611b90e106acfc0ad41319517342f`.
