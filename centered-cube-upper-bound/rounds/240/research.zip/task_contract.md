# R240 保真实距离衰减的共同来源预算
日期2026-10-17；上轮8fbcf650ca8611672ddd73de048eeaf1424c52f5已推送。开工工作区干净。

## 唯一目标及候选命题
一般root上界仍未闭合。直接修复把实际重叠I0(y,z)压成β(D(z))总质量造成的远源过收费，不用余项改名代替证明。

原固定物理节点L*,R*∈[a,b]，E_z(y)=Σ_i(|yi−zi|/b−1)_+。候选对任意原actual s(x)均有I0=∫Ωh_R*P_s,L*≤a^-n exp(-E)O_R(z)。θ≤1/4时用I0^(1−2θ)=I0^(1−4θ)I0^(2θ)、actual FIRST和共同Holder，保m_w(z)=∫D exp(-E/2)dβ。接原half-QG菜单与fullν后验时钟完成全部j/M和，费用保全部K/B/尺度依赖。

一次远源门F_z={y∈D:E≥2log+ρD(z)}可使加权ρ_w,F≤1；这是原soft来源的一个可测分割，不替换posterior，远/近两笔总费分别记录，不能每个距离层重复FIRST资源。合法K的n依赖须查源，否则结论保显式logK，不宣称无条件root阶。F可能为空，不称覆盖一般输入或必有正比例。

## 独立工具
compare只负责共同soft正核包络、精确/可积的空间距离权及两朝向常数，非独立逐坐标选择soft。audit先独审同底测度插值/共同FIRST联合约束；可核缺质量capacity水位填充最优包络，但不将其当成已付global预算。允许R238/239原allR hardband、actual FIRST、原fullΠ、静态capture、三腿两朝向、7/(64θ³)几何级数工具。不得免费反向menu-FIRST、βrank、变量尺度核归一。

## 责任与交付
peak：distance_budget.md，全尺度距离加权主估计与一次远源门；compare：kernel_distance.md，精确kernel工具及n/尺度费用；audit：audit.md，先命题后证，原K来源及端点审计；numeric：numeric_checks.py/json、numeric_notes.md，三阶段真实核与精确/高精预算复现。主代理：contract、proof.tex.txt、report.md、reproduce.py、精简归档和独立提交推送。仅写责任文件、共享目录不改他人、不自行提交或无限扩展。复用四Agent。

## 检验及成功范围
初探实际1d核积分；边界压力含两朝向、source平移、adaptive softness、θ=1/4与δ零分支；扩大参数/维度只作明确有限代数检查，不拟合n阶、不认证FULL历史。正式数值以本机实际运行与完整JSON复跑为准。成功需独审的真正距离权和完整node预算，或明确改变下一步决策的证据；一般root闭合必须所有原分支/输入费用都完成，未完成则保持缺口。逐轮只README+research.zip新增、不编译PDF。
