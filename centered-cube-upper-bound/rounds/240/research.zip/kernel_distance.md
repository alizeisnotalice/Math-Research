# R240: common-soft overlap envelopes with explicit distance weights

Only this file is owned by this auxiliary task. The physical/clock sum
belongs to the main author. This note proves kernel bounds and their
actual-FIRST compatible source-weight interface; it does not supply a
new general input budget. No source, posterior or original gate changes.

## KD1. Data and the two elementary phi tails

Let h=1[-1/2,1/2], w(u)=integral_0^1 exp(-|u|/r)dr,
phi=h*w, f_s=(1-s)h+s phi, and

    P_{s,L}(x)=L^-n product_i f_s(x_i/L).

Here integral w=2 integral_0^1 r dr=1, so phi is a probability density
and phi<=1. Fix L,R in [a,b], 0<a<=b<=2a, M=max(L,R), and arbitrary
source shifts y,z. For t>=1/2, direct integration in the core variable
and then in t gives

    phi(t)=integral_0^1 r[e^{-(t-1/2)/r}-e^{-(t+1/2)/r}]dr
           <=(1/2)e^{-(t-1/2)},
    integral_t^infty phi(u)du
       =integral_0^1 r^2[e^{-(t-1/2)/r}-e^{-(t+1/2)/r}]dr
           <=(1/3)e^{-(t-1/2)}.                        (KD1)

The constants are uniform including t=1/2. Tonelli applies to the
original nonnegative integrands; the last steps use r<=1. These are
actual phi tails, not Laplace proxy densities.

Write d_i=|y_i-z_i|, D0=(L+R)/2,

    E_LR(y,z)=sum_i (d_i-D0)_+/L,
    k_far(y,z)=#{i:d_i>=D0}.

Equality at the boundary is harmless: hard interval overlap is zero.
Define the actual overlap, allowing any measurable common soft s(x),

    I0(y,z)=integral_Omega h_R(x-z)P_{s(x),L}(x-y)dx.    (KD2)

All fixed scales are fixed before x. The same s(x) is used in every
coordinate; no coordinatewise selection is introduced below.

## KD2. The L>=R orientation has a pointwise distance envelope

For x in Q_R(z), a far coordinate satisfies
|x_i-y_i|/L>=1/2+(d_i-D0)/L. Its hard factor vanishes for receiver
Lebesgue dx almost everywhere (the equality boundary is a null
hyperplane), and KD1 gives
f_s((x_i-y_i)/L)<= (1/2)exp[-(d_i-D0)/L], for every s.
All other coordinate factors are <=1. Therefore, when L>=R,

    I0(y,z)<=M^-n 2^{-k_far} exp(-E_LR).                (KD3)

This uses integral h_R=1 and P_{s(x),L}<=L^-n times the displayed
product. It is valid for actual adaptive s(x), without a soft menu.
The weight on its right is <=1. Its Lebesgue integral in y is

    integral 2^{-k_far}exp(-E_LR)dy=(2L+R)^n<= (3M)^n.  (KD4)

Indeed each one-dimensional weight equals one on (-D0,D0) and
(1/2)exp[-(|d|-D0)/L] outside. This is an explicit volume price,
not a claim that this particular envelope is normalized.

## KD3. A self-contained common-soft density envelope for R>L

For 0<=k<=n let B_{k,L}(x) be the average of the binomial(n,k)
product probability densities with phi_L in exactly k coordinates and
h_L in the others. Every B_k is normalized and has infinity norm
at most L^-n. The exact Bernstein expansion is

    P_{s,L}=sum_{k=0}^n binomial(n,k)s^k(1-s)^{n-k}B_{k,L}.

Each coefficient lies in [0,1], hence, simultaneously for all s,

    P_{s,L}<=sum_{k=0}^n B_{k,L}.                     (KD5)

This is n+1 complete common-soft comparison densities, not 2^n
separately charged coordinate choices. For R>L, consider the integral
of one of the underlying product densities on Q_R(z). If a far
coordinate uses h_L, its contribution is zero. If it uses phi_L,
the entire interval is on one side of the core and KD1 gives interval
probability <=(1/3)exp[-(d_i-D0)/L]. Each other coordinate probability
is <=1. Independence within this fixed product density therefore gives
the same bound 3^{-k_far}exp(-E_LR) for every such density. Averaging
and KD5 prove

    I0(y,z)<=(n+1)M^-n 3^{-k_far}exp(-E_LR), R>L.       (KD6)

The proof includes arbitrarily adaptive s(x). It never integrates
P_{s(x),L} as if it were a fixed probability density.

The already audited nearest posterior-angle common menu supplies a
second envelope: S_n has N=ceil(pi sqrt n) mid-angle soft values and

    P_{s,L}<=e sum_{r in S_n}P_{r,L}.                  (KD7)

This is the original common-soft result used in R237 LG6 and R238
OW3, with all n coordinates sharing each r. The same fixed-density
argument makes eN replace n+1 in KD6. Thus one may use

    C_n=min{n+1,e ceil(pi sqrt n)},
    I0<=C_n M^-n 3^{-k_far}e^{-E_LR}, R>L.            (KD8)

For L>=R retain the stronger menu-free KD3. No independent soft menu
for a target leg, no QG theorem and no FIRST were used in KD1–KD8.

## KD4. A normalized integrable source-distance weight

Here is a sharper way to retain source mass than a bare exponential.
Choose either complete density envelope: the n+1 Bernstein densities
with coefficient c=1, or N actual soft densities with coefficient c=e.
Let its number be J, its coefficient cost C=cJ, and its densities be
F_l,L. Set

    omega_LR(y-z)=(M^n/J)sum_l integral h_R(x-z)F_l,L(x-y)dx.

Then for both physical orientations, exactly

    0<=omega_LR<=1,
    integral_Rn omega_LR(d)dd=M^n,
    I0(y,z)<=C M^-n omega_LR(y-z).                    (KD9)

Each fixed product density, or average of such densities, has overlap
<=M^-n: use its probability integral when R>=L and its infinity norm
L^-n when L>=R. Its integral over y is one by Tonelli. This proves
all of KD9, including the exact normalized spatial mass. Select the
smaller C to obtain C_n above and its corresponding omega; the weight
changes with this explicit choice. A minimum of costs does not permit
mixing one envelope's constant with another envelope's weight.

For R>L this omega satisfies the same 3^{-k_far}e^{-E_LR} bound; for
L>=R it satisfies the safe 2^{-k_far}e^{-E_LR} bound by integrating
each product-density pointwise bound. In particular omega<=e^{-E_LR}.
The normalized mixture in KD9 avoids the exponential total volume of
a product of independently maximized coordinate envelopes. No claim
that those independent maxima form a probability density is made.

## KD5. Explicit integrable tails and all-scale distance comparison

For 0<lambda<1 define

    K(lambda)=2[-log(1-lambda)-lambda]/lambda^2.

The true one-dimensional w distribution obeys

    integral e^{lambda|u|}w(u)du
       =2 integral_0^1 r/(1-lambda r)dr=K(lambda).       (KD10)

Represent a coordinate from F_l,L convolved with h_R as a sum of a
uniform core displacement of size L/2, a uniform hard displacement
of size R/2, and, on its phi coordinates, an independent displacement
L W of density w. Consequently E_LR of that displacement is at most
the sum of the |W| on the soft coordinates. On every underlying
product density its exponential moment is <=K(lambda)^n, since
K(lambda)>=1. Mixtures preserve this bound. For the exact weight in
KD9, Chernoff therefore gives the fully normalized tail

    integral_{E_LR>=t}omega_LR(d)dd
        <=M^n K(lambda)^n e^{-lambda t}.               (KD11)

In particular K(1/2)=8log2-4 and the price is
M^n(8log2-4)^n exp(-t/2). This is an explicit exponential-in-n
moment constant; it is not suppressed or described as dimension-free.

For 0<p<=1 the elementary pointwise distance bound also gives

    integral omega_LR(d)^p dd
      <=[L+R+2L t0^p/p]^n,
    t0=1/3 if R>L, and t0=1/2 if L>=R.                (KD12)

This follows by integrating the product far-coordinate envelope in
each coordinate. At p=1 the exact M^n from KD9 is stronger. With
E_b(d)=sum_i(|d_i|/b-1)_+, one also has

    E_LR(d)>=E_b(d)>=(||d||_1/b-n)_+ .                (KD13)

Indeed D0<=b and L<=b. These bounds apply over the complete source
space and keep the precise L,R scale units. They do not turn a
Lebesgue kernel tail into a beta-mass tail without a further source
estimate. For example, for actual finite beta and any t>=0,

    integral_D omega^p beta
      <=beta(D intersect {E_LR<t})
             +e^{-pt}beta(D intersect {E_LR>=t}).       (KD14)

No beta infinity norm, rank or source-centered hard cap is inserted.

## KD6. Exact actual-FIRST compatible effective mass

Keep the original actual receiver domain and sources. In particular
actual-soft source FIRST and the fixed hard column give

    integral_D I0(y,z)beta(dy)<=q O_R(z),
    O_R(z)=integral_Omega h_R(x-z)dx<=1,
    D=D_V(z) is the original source-pair set.            (KD15)

Let 0<theta<=1/2, alpha=1-2theta and 0<=epsilon<=alpha. The parameters
are fixed before y and the receiver integral. For epsilon>0 define

    p=epsilon/(2theta+epsilon),
    m_p(z)=integral_D omega_LR(y-z)^p beta(dy).

With A=C M^-n from KD9, pointwise I0<=A omega and Holder in the same
original beta give

    integral_D I0^alpha beta
       <= A^epsilon [q O_R(z)]^{alpha-epsilon}
                         m_p(z)^{2theta+epsilon}.      (KD16)

Proof: I0^alpha<=A^epsilon I0^{alpha-epsilon}omega^epsilon,
then use Holder exponents 1/(alpha-epsilon) and
1/(2theta+epsilon). The second integrand is exactly omega^p.
At epsilon=0, define m_0=beta(D) to recover the original R238 source
Holder bound, including zero-weight fibers. At epsilon=alpha the
first Holder factor is one and KD16 is direct envelope integration.
Handle O_R=0 or beta(D)=0 as actual zero traffic before fractional
normalizations. The theta=1/2 endpoint has alpha=epsilon=0 and the
ordinary source-mass bound; no distance gain is falsely claimed there.

For example R238's actual-soft half-menu bound B M^-n, B=eN, combines
with KD16 on the *same* column to give

    (1/q)integral_D J_theta,act(y,z,v)beta(dy)
      <= B^{2theta} C^epsilon O_R(z)^{1-2theta-epsilon}
                   [m_p(z)/(q M^n)]^{2theta+epsilon}. (KD17)

After the same normalized two-Pi Gini step, multiply this by the
original node log-clock length u_M/4. All original outer coefficients,
capture and source nu(dz) remain. KD17 is a family of genuine
compatible weighted effective masses, not a renaming of beta(D):
omega has proved spatial decay and normalized integral, and epsilon>0
suppresses distant sources. Its increased mass power and exact
C^epsilon fee are explicitly retained. There is no assertion that one
can keep the old beta(D) power while adding a free distance weight.
Physical nodes change omega, so a complete j/M sum must retain that
dependence or prove an appropriate common upper weight; the main
author handles that separate step.

The clock integration order matters: first use the v-independent
pointwise majorant J_theta,act<=B^{2theta}M^{-2theta n}I0(y,z)^alpha;
then the two original Pi_t(y) at this same y give the Gini bound; only
then integrate beta and apply KD16. One must not take the already
beta-integrated inequality KD17 and integrate it against a posterior
which still depends on y. This stated order retains the true common
normalizer and introduces no static source envelope.

The sharper normalized M-scale bound can improve the simpler
a^-n exp(-E_b) pointwise price: its ratio is bounded by
C_n(a/M)^n because E_LR>=E_b. This is a strict quantitative improvement
when M/a>C_n^{1/n}, although it is not a general source-input payment.

## KD7. Real-kernel local checks

Python/mpmath 1.3.0 was actually run at 50 digits. It used exact decimal
inputs and the exact expint antiderivatives for phi interval integrals.
For six physical/distance states, it checked r=.1,.5,1 and repeated
tensor dimensions n=1,8,512 against the true far factors in KD1,
then checked the n=1 actual-soft supremum against its full Bernstein
envelope. All 60 comparisons passed, exit 0.

| (L,R,d) | normalized all-phi overlap | actual n=1 soft-sup overlap | Bernstein envelope |
|---|---:|---:|---:|
| (1,1,0) | .5054583159824548 | 1 | 1.505458315982455 |
| (1,1,1) | .1862311918978722 | .1862311918978722 | .1862311918978722 |
| (.5,1,.8) | .1965691909477191 | .1965691909477191 | .1965691909477191 |
| (.5,1,2) | .008559507436497125 | .008559507436497125 | .008559507436497125 |
| (1,.5,.8) | .2348704635102035 | .2348704635102035 | .2348704635102035 |
| (1,.5,2) | .04123308353042544 | .04123308353042544 | .04123308353042544 |

Separately the exact same interval primitives at (.5,1,0) returned
normalized actual soft-sup overlap 1.256069982229448, confirming the
need for an adaptive-soft envelope in the R>L orientation.
K(1/2) returned 1.545177444479562475338. These are finite kernel
diagnostics, not directed-interval certificates or FULL histories.

Reproducible main diagnostic, with no extra file required:

```python
import mpmath as m
m.mp.dps=50
E=lambda k,x:m.mpf(1)/(k-1) if x==0 else m.expint(k,x)
def pint(l,u):
    if u<=l:return m.mpf(0)
    if u<=0:return pint(-u,-l)
    if l<0:return pint(0,-l)+pint(0,u)
    Fi=lambda x:x-E(4,m.mpf('.5')-x)+E(4,m.mpf('.5')+x)
    Fo=lambda x:-E(4,x-m.mpf('.5'))+E(4,x+m.mpf('.5'))
    if u<=m.mpf('.5'):return Fi(u)-Fi(l)
    if l>=m.mpf('.5'):return Fo(u)-Fo(l)
    return pint(l,m.mpf('.5'))+pint(m.mpf('.5'),u)
cases=[('1','1','0'),('1','1','1'),('.5','1','.8'),('.5','1','2'),('1','.5','.8'),('1','.5','2')]
checks=0
for row in cases:
    L,R,d=map(m.mpf,row);M=max(L,R);lo=(d-R/2)/L;hi=(d+R/2)/L
    H=max(0,min(hi,m.mpf('.5'))-max(lo,-m.mpf('.5')));V=pint(lo,hi)
    gap=max(0,(d-(L+R)/2)/L);far=d>=(L+R)/2
    cap=(m.mpf(1)/3 if R>=L else m.mpf(1)/2) if far else m.mpf(1)
    for n in [1,8,512]:
        for r in map(m.mpf,['.1','.5','1']):
            a=M/R*((1-r)*H+r*V)
            assert a<=1+m.mpf('1e-45') and a<=cap*m.exp(-gap)*(1+m.mpf('1e-45'))
            assert a**n<=(cap*m.exp(-gap))**n*(1+m.mpf('1e-42'));checks+=1
    actual=M/R*(H+V-pint(max(lo,-m.mpf('.5')),min(hi,m.mpf('.5'))))
    bern=M/R*(H+V)
    assert actual<=bern+m.mpf('1e-45');checks+=1
    print(row,m.nstr(M/R*V,16),m.nstr(actual,16),m.nstr(bern,16))
print('checks',checks,'K(1/2)',m.nstr(8*m.log(2)-4,22),'PASS')
```

All proofs above are uniform in shifts and in the original admissible
soft range, with every stated n, menu, orientation and integration
cost explicit. No further search, PDF, Git operation or other file
edit is part of this auxiliary delivery.
