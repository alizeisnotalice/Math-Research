# R240：保真实来源距离的半阶重叠预算

本轮将原 soft 来源的总质量 `β(D(z))` 换成一个显式指数距离加权质量，并完整支付所有 `j/M/soft/clock` 费用。进一步把原来源只作一次 near/far 正分割，得到远来源子交通的全局参数化 `Wν` 预算，不留下来源质量矩。

该远来源集合可能为空，本文不声称覆盖正比例原交通。互补的有效近来源仍需支付；`K` 的选择未被免费限制，最终的 `log K` 费用完整保留。

## DB1. 原对象、单次来源分割与接收占用

固定 R238/R239 同一有限截断、原外资料 `(ω,V)`、`0<a≤b≤2a`、`q,K>0`、`ν≤β≤f`，保原 actual softness `s(x)`、真实 receiver `Ω`、全部 ancestry/capture/history/large-n 资格。原 source-pair 集为

\[
 D(z)=V\cap\{y:\|y-z\|_1\le17na\}
 \cap\{y:\|y-z\|_\infty\le b(5\log n+1/2)\}.
\]

原 `β,ν,q,a,b,D` 跨 `j` 相同。记 `m_D(z)=β(D(z))`、`ρ_D(z)=m_D(z)/(qa^n)`。

本稿可以对任何预冻结可测来源子集 `F_z⊂D(z)` 使用：它在固定原 hard `z` 后、receiver `x`、soft 来源 `y`、辅助槽 `v,u`、`j,M,t` 之前确定。只把母式中 `β(dy)` 的积分限制到 `F_z`，不重建来源或 FIRST。两辅助槽、`Π_t,e_t,Z_t,k_t` 始终由完整原 `ν` 定义。

对所有合法物理节点 `R*∈[a,b]`，记

\[
 O_{R^*}(z)=\int_\Omega h_{R^*}(x-z)dx\le\Delta(z)\le1.
\]

可以取 `Δ=1`；也可以取 R238/R239 已证明、预冻结且对全部节点有效的接收上界。若 `Δ=0`，原接收交通为零，先置零而不进入对数。其余取 `0<Δ≤1`。新来源分支不改变这些原几何上界。

## DB2. 不选择独立 softness 的逐点距离包络

原一维核为 `f_s=(1−s)h+sφ`，`h=1_[−1/2,1/2]`，
`φ=h*w`，`w(u)=∫_0^1exp(−|u|/r)dr`。由 `w≤1`、`w(u)≤exp(−|u|)`，

\[
 0\le f_s(u)\le\exp[-(|u|-1/2)_+]
 \quad\text{对同一实际 }s\in[0,1]. \tag{DB2.1}
\]

在 core 上右侧为一；在外部 `h=0` 且 `φ(u)≤exp(−(|u|−1/2))`。这是每个 `s` 都成立的直接上界，没有给不同坐标选不同的 soft 参数，也没有把右侧包络当成归一化概率核。

定义固定原 `a,b,z` 的距离量

\[
 E_z(y)=\sum_{i=1}^n(|y_i-z_i|/b-1)_+. \tag{DB2.2}
\]

若 `x∈Q_R*(z)` 且 `L*,R*≤b`，则逐坐标

\[
 (|x_i-y_i|/L^*-1/2)_+
 \ge(|y_i-z_i|/b-1)_+.
\]

又 `L*≥a`，故所有 actual-soft 节点都有

\[
 \boxed{P_{s(x),L^*}(x-y)\le a^{-n}e^{-E_z(y)}.} \tag{DB2.3}
\]

唯一点态尺度因子是显式 `a^−n`。不能另声称 coordinatewise-max 包络积分为一；下文只在 DB2.3 的原位置使用它。

## DB3. 保真实 receiver 的 I0 及加权来源 Hölder

固定节点，令

\[
 I_0(y,z)=\int_\Omega h_{R^*}(x-z)
 P_{s(x),L^*}(x-y)dx.
\]

DB2.3 与原 actual FIRST 给两个相容的界：

\[
 I_0(y,z)\le a^{-n}e^{-E_z(y)}O_{R^*}(z),\qquad
 \int_{F_z}I_0(y,z)\beta(dy)\le qO_{R^*}(z). \tag{DB3.1}
\]

第二式先在同一个原 receiver 上用 `∫_{F_z}P_s,L* β≤q`，再积分 hard 核。`O_R` 没有被提前替为一，也没有给 backward-soft 节点授 FIRST。

定义显式加权质量

\[
 m_w(F,z)=\int_{F_z}e^{-E_z(y)/2}\beta(dy),\qquad
 \rho_w(F,z)=m_w(F,z)/(qa^n). \tag{DB3.2}
\]

对 `0<θ≤1/4`，将 `I0^(1−2θ)=I0^(1−4θ)I0^(2θ)`。使用 DB3.1 的逐点界，再在同一来源测度上 Hölder，得

\[
 \begin{aligned}
 \int_{F_z}I_0^{1-2\theta}\,d\beta
 &\le a^{-2n\theta}O_{R^*}^{2\theta}
 \int_{F_z}I_0^{1-4\theta}e^{-2\theta E_z(y)}\beta(dy)\\
 &\le a^{-2n\theta}O_{R^*}^{2\theta}
 \left(\int_{F_z}I_0\,d\beta\right)^{1-4\theta}
 \left(\int_{F_z}e^{-E_z/2}\,d\beta\right)^{4\theta}\\
 &\le q^{1-4\theta}a^{-2n\theta}
 m_w(F,z)^{4\theta}O_{R^*}(z)^{1-2\theta}.
 \end{aligned} \tag{DB3.3}
\]

`θ=1/4` 可直接按第二项或连续极限解释；最终优化指数严格更小。若 `O_R=0` 或 `m_w=0`，原列/来源行先置零。这里每一来源质量只在一个加权积分里出现，未按距离层各自使用一份 FIRST 后再相加。

## DB4. 同原半阶列、完整 posterior 和节点费用

沿 R238，令 `B=e ceil(πsqrt n)`。半阶列先用已付共同 soft 菜单，再用 fixed-soft QG，保所需 capture，价格 `J_(1/2)≤B M^−n`。在同一正 receiver 测度上插值得

\[
 J_\theta(y,z,v)\le (BM^{-n})^{2\theta}I_0(y,z)^{1-2\theta}.
\]

这不是对 adaptive `I0` 授归一化。原 `Π_t` 不依 receiver/hard 来源，两个槽同律，故 `∫δ_t dΠ_t²≤n/4`。此时右侧已经一致于辅助 `v,u`，之后再积原 `β|F_z`。

记 `γ=1+1/n`、`c=γ^−j`、`M0=a/c²`、`ξ=n log(M/M0)`、`Z=(ξ−U)_+`，原 clock 长度至多 `Z/n`。原列外分母为 `q`。DB3.3 因此给

\[
 \boxed{\mathcal T^{F}_{jM,z}\le
 \frac Z4 B^{2\theta}\rho_w(F,z)^{4\theta}
 \Delta(z)^{1-2\theta}
 c^{4\theta n}e^{-2\theta\xi}.} \tag{DB4}
\]

量纲核对：`q^−1q^(1−4θ)m_w^(4θ)a^−2nθ M^−2nθ`
等于 `ρ_w^(4θ)(a/M)^(2nθ)`；再用 `a/M=c²e^−ξ/n` 即得所写指数。没有遗漏 `(b/a)^n` 或 orientation 因子。

此式保全部实际 soft、物理尺度、history、capture 和原来源。`F_z` 只是一项实际正交通的预冻结来源资格，辅助 posterior 不随之裁剪。没有重用负信用或重做 top-k，也不需要 heavy floor。

## DB5. 一次完整 j/M 求和与优化

R238 已证的正规节点加独立 capped endpoint 求和给

\[
 \sum_M\xi e^{-2\theta\xi}\le\frac1{2\theta^2},\qquad
 \sum_{j\ge0}c^{4\theta n}\le\frac7{8\theta}.
\]

故每腿/朝向，已经乘原 good 因子 `(K/3)^θ` 后，

\[
 \sum_{j,M}(K/3)^\theta\mathcal T^F_{jM,z}
 \le\frac7{64\theta^3}\Delta(z)(K/3)^\theta
 B^{2\theta}\rho_w(F,z)^{4\theta}\Delta(z)^{-2\theta}. \tag{DB5.1}
\]

对非零行定义

\[
 H_w(F,z)=1+\log_+\rho_w(F,z)+\log_+K+\log B
 +\tfrac12\log(1/\Delta(z)),\qquad
 \theta_z=\frac1{4H_w(F,z)}.
\]

它由原 `z` 与预冻结 source subset 决定，早于 `x,y,v,u,j,M,t`，且 `θ_z≤1/4`。指数因子不超过 `e`，因为

\[
 \theta_z[\log_+K+2\log B+4\log_+\rho_w
                   +2\log(1/\Delta)]\le1.
\]

代入 DB5.1 得 `≤7e Δ H_w³`。恢复原 `2Λe^4`、三腿、两朝向，得到一般加权来源定理

\[
 \boxed{P_{\rm farclock}^{F}(U)\le
 84\Lambda e^5\,\mathbb E\sum_V\int_V
 \Delta_V(z)H_w(F,z)^3\nu_V(dz).} \tag{DB5.2}
\]

`U≥0` 任意，`U=0` 仍只指当前原 far-clock 分支的整个有效窗。所有原 complementary fees 保持原账。`m_w=0` 的行贡献零，不需要对零质量取真实对数。

对 `F=D`，这是原完整剩余交通的显式距离价；可与 R238 同一对象的未加权界逐 `z` 取较小者，不能把二者相加当成两个信用。

## DB6. 远来源门的完整 Wν 付款

现在仅对原 soft 来源作一次正分割。对每个原 hard `z` 定义

\[
 t(z)=2\log_+\rho_D(z),\qquad
 F_z^{\rm dist}=\{y\in D(z):E_z(y)\ge t(z)\},
 \qquad N_z=D(z)\setminus F_z^{\rm dist}. \tag{DB6.1}
\]

这里 `dist` 表示 source-distance，不能与已经固定的 far-clock 分支混同。`t(z)` 在所有 receiver、source integration、node 和 auxiliary time 之前冻结。

由定义，

\[
 \rho_w(F^{\rm dist},z)
 \le e^{-t(z)/2}\rho_D(z)\le1. \tag{DB6.2}
\]

因此 DB5.2 取合法的统一 `Δ=1` 后，若原 `K` 在各 outer data 间共同，整个该来源子交通已经付为

\[
 \boxed{P_{\rm farclock}^{\rm dist}(U)\le
 84\Lambda e^5\,[1+\log_+K+\log(e\lceil\pi\sqrt n\rceil)]^3\,W_\nu,
 \quad W_\nu=\mathbb E\sum_V\nu_V(V).} \tag{DB6.3}
\]

若 `K=K_{\omega,V}` 随原 outer data 变化，则 DB6.3 的对数三次方必须保在 `\mathbb E\sum_V\int_V\nu_V(dz)` 内；不能将它作为共同常数乘 `W_\nu`。以下共同 `K` 的参数化解释均按这一资格理解。

原 disjoint leaves 与来源 domination 给 `Wν≤||f||1`（使用原 seed 期望，不新增恢复费）。这是全参数化来源预算，未留下 `β(D)` 的矩，也没有按远距离层复制一次 hard 来源质量。若保原 `Δ<1`，还可使用 DB5.2 的更小接收价。

`K>0` 保持原参数；本文没有从某个 `K=64` 工具实例或未经认证的 n 依赖推断它有界。只有当显示的 `[1+log_+K+log B]^3` 在所选原参数下不超过目标根阶费用时，DB6.3 才按该参数称为根阶付款。例如把 `K` 视为与 n 无关的固定参数时它为 `O_K(log³(n+1))Wν`；这不是对当前原 K 的额外授权。

## DB7. 距离层解释、覆盖范围与精确剩余

若仅为解释把 `D(z)` 分成 `A_m(z)={m≤E_z(y)<m+1}`，则

\[
 \sum_{m\ge0}e^{-(m+1)/2}\beta(A_m)
 \le m_w(D,z)\le\sum_{m\ge0}e^{-m/2}\beta(A_m).
\]

这是一份加权来源积分的恒等分解/夹界，不是分别估每一层交通然后复制 `Wν`。真正的付款只用 DB6 的两支原分割，正交通恰分成 `F_dist` 和 `N`；没有遗漏中间距离。

`ρ_D≤1` 时 `t=0`，整份 `D(z)` 已在 DB6 的已付支。一般情况下原 `D` 给 `E_z(y)≤17na/b`；若 `2log_+ρ_D>17na/b`，这个 far-source 支可以为空。本文不声称它占原交通的正比例，也不通过降低 t 来把未付部分隐藏掉。

唯一保留的原来源互补是

\[
 y\in D(z),\qquad E_z(y)<2\log_+\rho_D(z),
\]

与其原 receiver、capture、history、posterior 和 clock 条件的交。DB5.2 仍给它真实加权质量价，但本轮没有证明该互补的全局根阶预算。远处巨大来源若足以把自身 `log ρ_D` 门推得更远，仍可能落在此互补内；不能因指数距离权可计算就宣称一般目标已闭合。

## DB8. 本机实际核算

作者使用本机 Python/mpmath、40 位精度运行了 24 个真正一维 adaptive-soft `I0` 积分：`a=.5,b=1,z=0`，`L∈{.5,.75,1}`、`R∈{.5,1}`、`y∈{0,1,3,6}`，`Ω=Q_R(0)`，`s(x)=.1` 当 `x<0`、否则 `.9`。原 `φ` 采用 `expint(3,·)` 的解析式；quadrature 在 `0` 以及落在 hard 区间内的 `y±L/2` 处分段。全部核验 `I0≤a^−1exp[−(|y|/b−1)_+]`，最大比值为 `0.75272915799122739492`。

随后对每组 `(L,R)`，在这四个真实 `I0` 值上取来源质量 `[1,2,4,8]`、`q=Σmass·I0`、`θ∈{.1,.24}`，共 12 例核验 DB3.3 的加权 Hölder，全部通过。这里 `q` 是工具算例的聚合响应，不冒称满足原全尺度 FIRST。

这些是低维原核与代数接口检查，不是 FULL/history 实例，不拟合 n 阶。严格证明由 DB2–5 的逐点不等式、原 FIRST 和已有节点和给出；本轮独立 numeric/audit 的可复跑结果由各自责任文件记录。

本稿只写 `distance_budget.md`，不修改来源、posterior、FIRST 或其它工作者文件。全部新费用已显式列入 DB5–6，完成后不扩展未付近来源路线。
