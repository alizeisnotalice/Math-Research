# R240 independent audit — statement-first checkpoint

Only this audit file is edited. The contract was not yet on disk at the first two reads. This screening uses the parent's exact proposed node interface and frozen R238/R239 original-source tools; no R240 author proof has been read.

## Correct joint use of FIRST and a pointwise overlap envelope

Fix original outer data, hard anchor z, one legal physical node, theta in (0,1/2) and p=1-2theta in (0,1). Write mu=beta restricted to the authentic D_V(z), I(y)=I0(y,z), A=q O_R(z), and suppose an actually proved envelope is

    0<=I(y)<=F(y)=C_n M^(-n) omega(y,z),
    integral I dmu<=A.

I is the uncaptured actual-soft zeroth receiver column, hence independent of auxiliary v/u/time before using the common-posterior Gini bound. The envelope must hold for this actual adaptive-soft column, not just each fixed menu soft. All constants have their real dimensions: C_n and omega are dimensionless, F has density units, A is a source-weighted density response. C_n may depend on n and every physical-node dependence of omega must be retained.

For any alpha in [0,p], set gamma=(p-alpha)/(1-alpha). The pointwise product estimate followed by Holder gives the legitimate joint bound

    integral I^p dmu
       <=(integral I dmu)^alpha
          (integral F^gamma dmu)^(1-alpha)
       <=A^alpha (C_n M^(-n))^(p-alpha)
          (integral omega^gamma dmu)^(1-alpha).

It is not the multiplication of two unrelated integral upper bounds: the common I is split inside the same integral before Holder. Alpha=p gives the original FIRST/total-mass bound; alpha=0 gives the pointwise-envelope weighted-mass bound. Endpoint zero powers are handled as upper-bound conventions after zero rows; A=0 implies I=0 mu-almost everywhere and the true contribution vanishes first. Zero-mass and zero-envelope cases are treated before divisions.

Substitution into the parent's same-node inequality yields exactly

    node <= Z/4 * B^(2theta) C_n^(p-alpha) O_R(z)^alpha
          [ (integral_D omega^gamma dbeta)/(q M^n) ]^(1-alpha).

The original beta/nu sources, full two posteriors, source gate, capture and physical comparison fees are unchanged. This is a family of valid node prices. It does not grant an n-independent C_n, a node-independent weighted source mass or a free all-j/M sum.

## One common resource, rather than repeated q across layers

The exact positive-measure relaxation is also available. For finite mu and a finite integrable nonnegative F, maximize integral I^p over 0<=I<=F with integral I<=A. If A>=integral F, its value is integral F^p. If 0<A<integral F, choose a common lambda>0 with

    integral min(F,lambda)dmu=A.

The maximizing relaxed profile is I*=min(F,lambda). For any lambda>0, the elementary concave support-line estimate gives a valid upper bound

    integral I^p <= p lambda^(p-1) A
       + integral sup_{0<=u<=F(y)} [u^p-p lambda^(p-1)u] dmu,

whose supremum is attained at min(F(y),lambda). At the resource-matching lambda the bound is equality for the relaxed profile. This is a bound within the envelope/one-FIRST-resource class, not a construction of an actual cube column. It requires neither an external optimization theorem nor a new traffic source. Infima over rational lambda are legitimate when the data/finite moments make the expression measurable and continuous; selecting a certification scalar is different from reselecting the original kernel.

Equivalently, a source partition E_l has actual resources A_l=integral_E_l I dbeta with sum A_l<=A. A layer estimate sum A_l^p beta(E_l)^(1-p), combined with its layer envelope caps, preserves one shared resource. Giving every distance layer the entire A independently is an overestimate which can introduce an infinite/unpaid layer fee; source disjointness does not cancel it. A simpler safe truncation is

    integral I^p <= A^p mu{F>lambda}^(1-p)
                     + integral_{F<=lambda} F^p dmu,

where FIRST is used once on one part and the pointwise envelope on the other. Any later optimization must keep all its displayed terms.

## Original measure and scale qualifications

The actual receiver Omega must remain in I and in integral_D I dbeta<=q O_R. It retains the original actual-soft FIRST and all-scale receiver hardband. Beta inherits that receiver hardcap from beta<=f, but not nu's rank/birth/source-density conditions. Neither a source restriction beta|D nor a new weighted mass renormalizes nu in Pi_t or changes e_t(y).

A fixed-soft normalized-column decay cannot be assigned directly to the actual adaptive s(x), especially when R>L. If the proposed F is obtained by a menu, its count/constant stays inside F or the node price at the appropriate exponent. A v-dependent captured overlap cannot be extracted from the posterior without a static v-independent upper envelope. Time/u-dependent gates remain in the actual weighted traffic unless positively relaxed under an established bound.

The original theta remains frozen at its certified outer/hard-anchor level before receiver and node/time variables. The auxiliary Holder parameter or scalar resource-dual parameter may be optimized per already fixed node as an upper-bound certificate, but that optimization does not remove the resulting node dependence from the complete sum. Pointwise minima of proved prices for the same actual column are legal; multiplying independent estimates, restoring a discarded distance weight after integration, or normalizing an adaptive physical scale is not.

## Bounded local execution and status

An actual local mpmath 60-dps/Fraction calculation passed 60 common-resource waterfill checks and 180 weighted-Holder checks on finite measures, including zero caps/resource, repeated caps and active/inactive resource constraints. These are temporary bounded algebra diagnostics without archived standalone code, not formal package replay experiments, interval certificates or FULL original cube histories. The proofs above are elementary concavity and Holder on the actual common source measure.

Statement-first conclusion: the stated conditional envelope interface has valid joint-FIRST bounds and a sharp common-resource relaxation, but no source moment or general root closure follows until the actual envelope, its n/scale constants and the complete node/history budget are proved. Awaiting the exact contract and author candidate before final audit. No repeated counterexample campaign or author-proof review has been undertaken.

## Contract and direct actual-soft distance proposition

The contract subsequently appeared and was read, still before any R240 author draft. The direct proposed envelope can be established without a fixed-soft normalization or an artificial C_n. The original phi satisfies phi(u)<=exp(-(|u|-1/2)_+), so the same is true for every mixture f_s. For x in Q_R*(z), a<=L*,R*<=b,

    P_{s(x),L*}(x-y)<=a^(-n) exp(-E_z(y)),
    E_z(y)=sum_i (|y_i-z_i|/b-1)_+.

Consequently the true uncaptured overlap obeys I0(y,z)<=a^(-n)exp(-E_z(y))O_R*(z). This is valid at the actual receiver-selected s(x); no free adaptive kernel normalization or independent coordinate soft choice is used.

Fix any frozen measurable source subgate F_z contained in the original D_V(z), and write m_w,F(z)=integral_F exp(-E_z(y)/2)beta(dy), rho_w,F=m_w,F/(q a^n). For 0<theta<=1/4 choose alpha=1-4theta and gamma=1/2 in the valid joint bound above, now retaining the pointwise occupation factor as well. This yields

    integral_F I0^(1-2theta)dbeta
      <=q^(1-4theta) a^(-2n theta) m_w,F^(4theta)
          O_R*(z)^(1-2theta).

The endpoint theta=1/4 follows directly by integrating sqrt(I0); zero occupation and zero weighted mass give zero traffic before zero-power notation. The full source target/posterior is not restricted to F_z. FIRST is used once, not once per distance layer.

Substitution into the unchanged half-menu/Gini node estimate gives

    node <= Z/4 * B^(2theta) rho_w,F^(4theta)
             O_R*(z)^(1-2theta)c^(4n theta)exp(-2theta X).

For any certified common original-receiver bound O_R<=delta(z)<=1, the complete 7/(64theta^3) j/M sum remains applicable. Let

    H_w=1+log_+rho_w,F+log_+K+log B+(1/2)log(1/delta),
    theta_z=1/(4H_w).

Then the exponential source factor is at most e. Restoring the original 2 Lambda, three legs, two orientations and exp(4) physical cover gives exactly 84 Lambda exp(5) times the original nu-integral of delta H_w^3. This takes the stronger O_R exponent above; the earlier coarse delta^(1-4theta) route is superseded. Every parameter is frozen at the hard-anchor level before receiver, anchor y, node and auxiliary time. Delta=0 and zero F source mass are handled before logs/normalization.

The single positive partition F_z={y in D(z):E_z(y)>=2log_+rho_D(z)}, rho_D=beta(D(z))/(q a^n), is measurable and independent of all node/time variables. It ensures rho_w,F<=rho_D exp(-log_+rho_D)<=1. With delta=1 this whole original source-far subtraffic has the explicit price

    84 Lambda exp(5) [1+log_+K+log B]^3 W_nu.

The complement is the original source-near subtraffic and remains a separate budget; this partition need not have a nonzero far portion or cover the general remainder.

## Narrow audit of the inherited K parameter

Original R116 astra_first.md section 4, F13 explicitly starts with given K>0 and defines the failure set; F14 and the high split pe>=2Kq keep its K dependence. R117 JG3–JG5 carries that threshold into the later same-source construction. R128 proof.md RT5 line 658 says K is fixed along the original definition. Its lines 1491/1540 explicitly mark finite numerical K=64 as not certifying original theorem legality. GENERAL_CURRENT_REDUCTION.md line 159's K=128/3 belongs to a different mixed-potential radius and is not this good threshold. This narrow provenance does not establish that every later K-dependent branch permits an arbitrary n-independent replacement. Therefore the paid far-source result must retain log K; a root/polylog assertion requires the appropriate original K(n) and remaining ledger qualification, not the unrelated numerical or potential constant. No further historical search is needed for this bounded conclusion.

An additional actual local run passed 48 high-precision finite-point/cell tests of the refined actual-soft distance/weighted-Holder inequality, including theta=.01,.1,.25, adaptive soft values, both legal source scales and zero occupation. These are temporary non-FULL diagnostics, not an archived physical L1 experiment or a replacement for the analytic proof. Statement-first screening of the contract's main candidate passes with the explicit K and complementary-source restrictions; author-proof review is still pending.

## Final author-proof review

The complete parent proof (1)–(9) and its geometric subbranch, distance_budget.md DB1–DB8, and kernel_distance.md KD1–KD7 were read. The direct actual-soft envelope, joint-FIRST Holder split, refined occupation exponent O_R^(1-2theta), and q/a/M unit balance pass. The original same-y two-posterior Gini is applied only after a v-independent column majorant; beta is integrated afterwards. No y-dependent posterior normalizer is extracted. The common soft menu remains in the half-column price B^(2theta), full-nu posteriors and static capture are unchanged, and the complete regular/cap/j sum retains 7/(64theta^3). With theta_z=1/(4H_w), the exponent factor is <=e and restoring all original coefficients gives exactly 84 Lambda exp(5).

The source gate E_z(y)>=2log_+rho_D(z) is a single fixed positive partition of the original anchor relation. Its weighted mass is <=q a^n, so the displayed far-source price contains no unresolved beta-mass moment. It retains [1+log_+K+log B]^3 and can be taken outside the outer source expectation only for a common original K. DB6 was revised to state the same common/varying-K qualification as the parent proof. The explicit further branch delta R_w^3<=A has constant 4A+27/(2 exp(3)), since the log-occupation term is halved before cubing. Zero occupation/mass and theta=1/4 are handled before formal endpoint powers. The near-source complement and original K(n)/other-branch qualifications remain unproved; no universal root conclusion or positive coverage is inferred.

The auxiliary normalized envelope also passes with its explicit costs. Phi's point/CDF tails have constants 1/2 and 1/3. In orientation L>=R the actual source kernel admits a direct pointwise-a.e. distance envelope. In orientation R>L a sum of n+1 complete Bernstein product densities, or the already proved e N common-soft menu, covers adaptive softness. The selected envelope's own constant and weight must stay paired. Its normalized overlap omega lies in [0,1] and integrates over source displacement to M^n. The stated mgf K(lambda), K(lambda)^n tail, Lp volume and orientation factors are retained, not treated as dimension-free source-mass bounds. The source-compatible KD16/17 family is Holder on one original beta measure, and explicitly preserves its extra mass power and C^epsilon charge. A later all-node use must still keep omega's node dependence; the auxiliary normalized envelope is not itself the new global payment.

## Independent execution and reproducibility

The full numerical source and notes were read. One independent complete replay passed all 32 recorded configurations: 13 actual n=1 adaptive-soft kernel integrals, 10 common-measure Holder arrays and nine far-gate scalar rows. Its entire 38760-byte JSON was byte-identical, SHA256 99a0b9cac34154af4757aae67903571bde737af8cf16e581eaea2dfd301650d5. The physical integrations use the true phi kernel on the full compact hard support, split at soft/hard boundaries and the softness jump. Their mp30/50 agreement is ordinary high-precision quadrature evidence, not an interval error certificate or a finite-L1 FULL/history instance. The arrays use one shared row/envelope resource, including explicit quarter-theta zero-exponent handling. Scalar far rows retain K=256 as an illustrative parameter, not an authenticated original choice, and do not assert every listed distance is allowed by the actual source gate.

The archived KD7 script was independently extracted and executed: all 60 stated physical interval/tensor/common-soft comparisons passed, and the six printed rows plus K(1/2)=1.545177444479562475338 matched the file. These checks do not certify an asymptotic source budget. The main author's separate 24 kernel and 12 Holder diagnostics are author-reported, not this auditor's executions or additional formal configurations. The initial 60+180+48 temporary screening diagnostics remain separate and have no archived standalone script.

The final report and driver were read. The report keeps the original K dependence and near-source gap, separates the 32 formal configurations from the embedded 60 and informal checks, and makes no false FULL/interval claim. The driver copies source and contract to a new external directory, compares the whole JSON, extracts/runs KD7 and records its stdout, then verifies the manifest again. That final manifest-driver execution is the parent's later external receipt, not an execution claimed here.

Final mathematical conclusion: pass within the stated original far-clock/source-subgate scope. The weighted distance price and parameterized far-source mass payment are proved, with the explicit near-source complement, original parameter ledger and general root closure still open. Final boundary wording/hash binding follows below; no new mathematical route is being pursued.


Final boundary repair was read: KD2 explicitly means receiver Lebesgue almost everywhere at a touching hard-support hyperplane; all integral inequalities and the archived check code are unchanged. No audit writes are planned after this binding.

| File | SHA256 |
| --- | --- |
| task_contract.md | `b1c541ae866e8c6293af465e55a1ae17bde611b90e106acfc0ad41319517342f` |
| proof.tex.txt | `269ab84799214ce6dc1c2c0ba918958e963c74b9acdffffcf9ebf23df017b5e1` |
| distance_budget.md | `b77ced86fd189bb147970312d493b8fd45eac3b3e5f95109e7f63673ebe0d5e8` |
| kernel_distance.md | `7c0570b0c6803c724fb2fba4cb8447b6e45844c546b7b67d658ffcb3590e4755` |
| report.md | `c4e359643935a76751c44df2579a108b927c7e2a354e3d41f108415f3656864c` |
| numeric_checks.py | `1d9ebe208f6d948d779b1b390385d340e08f1ec625dadd12663b92f89cfe90e1` |
| numeric_checks.json | `99a0b9cac34154af4757aae67903571bde737af8cf16e581eaea2dfd301650d5` |
| numeric_notes.md | `a2c3c788d0b1d1090824b3b4e34ad812874643b1ab132cb64f6a484b85a5349f` |
| reproduce.py | `e7e2302e435971ca7b5504e0b98d33ec958800ed17cc57628cd1e3d2124c5fe8` |
