from fractions import Fraction as F
from itertools import product
from math import comb, factorial
import json
# Odd Taylor polynomials give rigorous lower bounds for exp(-v), v>=0.
def exp_lower(v):
 return sum(((-v)**j/F(factorial(j)) for j in range(40)),F(0))
rows=[]
for N in [4,8,16]:
 for prob in map(F,['1/8','1/4','1/2','3/4','1']):
  for eps in map(F,['1/4','1/2','3/4']):
   mu=N*prob;t=(1-eps)*mu
   bad=sum((F(comb(N,k))*prob**k*(1-prob)**(N-k) for k in range(N+1) if k<=t),F(0))
   v=eps*eps*mu/2
   # The reciprocal polynomial is an upper bound. The odd Taylor lower
   # bound additionally certifies bad <= exp(-v) for each finite row.
   den=sum((v**j/F(__import__('math').factorial(j)) for j in range(9)),F(0));upper=1/den
   assert bad<=exp_lower(v)<=upper
   rows.append({'N':N,'p':str(prob),'eps':str(eps),'bad_probability':str(bad),'exponent':str(v),'rational_upper':str(upper),'exponential_lower_certificate':str(exp_lower(v))})
spatial=[]
for n in [1,2,3]:
 pts=list(product([F(-1,4),F(1,4)],repeat=n));N0=len(pts);Ls=[F(1),F(3,2),F(2)]
 cuts=sorted({y[0]+sign*L/2 for y in pts for L in Ls for sign in [-1,1]})
 patterns={}
 for ix in product(range(len(cuts)-1),repeat=n):
  x=[(cuts[i]+cuts[i+1])/2 for i in ix];vol=F(1)
  for i in ix:vol*=cuts[i+1]-cuts[i]
  masks=tuple(tuple(j for j,y in enumerate(pts) if all(abs(xx-yy)<L/2 for xx,yy in zip(x,y))) for L in Ls)
  patterns[masks]=patterns.get(masks,F(0))+vol
 for sampleN in [1,2,3]:
  for lam,eps in product(map(F,['1/8','1/2']),map(F,['1/4','1/2'])):
   lower=(1-eps)*lam;original=expected=preserved=F(0);v=eps*eps*lam*sampleN/2
   delta_upper=1/(1+v);success_lower=1-delta_upper
   # Enumerate every iid sample tuple, including repeated locations.
   for masks,vol in patterns.items():
    vals=[F(len(mask),N0)/L**n for mask,L in zip(masks,Ls)];H=max(vals)
    original+=lam*vol*int(H>lam)
    selected=next((j for j,z in enumerate(vals) if z>lam),None)
    for sample in product(range(N0),repeat=sampleN):
     newvals=[F(sum(i in mask for i in sample),sampleN)/L**n for mask,L in zip(masks,Ls)]
     p=F(1,N0**sampleN);expected+=p*lower*vol*int(max(newvals)>lower)
     if selected is not None:preserved+=p*vol*int(newvals[selected]>lower)
   assert preserved>=success_lower*original/lam
   assert expected>=(1-eps)*success_lower*original
   spatial.append({'n':n,'source_atoms':N0,'samples':sampleN,'lambda':str(lam),'epsilon':str(eps),'original_weak':str(original),'expected_rounded_weak':str(expected),'retained_original_volume':str(preserved),'certified_success_lower':str(success_lower),'scope':'finite scales, all Lebesgue cells and all iid samples'})
# Unequal, independent block sampling: exact lower-tail laws.
block=[]
for scale in [F(1),F(1,4),F(1,16)]:
 masses=[scale*F(i,7) for i in [1,2,3,1]];ps=[F(1,8),F(1,2),F(3,4),F(1)]
 mu=sum((m*p for m,p in zip(masses,ps)),F(0));B=max(masses)
 for eps in map(F,['1/4','1/2','3/4']):
  bad=F(0)
  for bits in product([0,1],repeat=4):
   value=sum((m*b for m,b in zip(masses,bits)),F(0));prob=F(1)
   for b,p in zip(bits,ps):prob*=p if b else 1-p
   if value<=(1-eps)*mu:bad+=prob
  v=eps*eps*mu/(2*B);upper=1/(1+v);assert bad<=exp_lower(v)<=upper
  block.append({'scale':str(scale),'epsilon':str(eps),'bad':str(bad),'rational_upper':str(upper)})
necessity=[]
for M in [4,16,64]:
 pts=[F(k,2) for k in range(-M,M+1)]
 intervals=[(pts[i+1]-1,pts[i]+1) for i in range(len(pts)-1)]
 total=F(0);left,right=intervals[0]
 for l,r in intervals[1:]:
  if l>right:total+=right-left;left,right=l,r
  else:right=max(right,r)
 total+=right-left
 assert total==M+1 and total>=M-1
 necessity.append({'M':M,'source_atoms':len(pts),'W':len(pts),'continuous_window':[1,2],'lambda':1,'exact_original_weak':str(total),'proved_simple_lower':M-1,'output_N_atom_volume_upper':'2*(1-epsilon)*N','scope':'consecutive-pair exact interval union; proof explains full continuous-window equivalence up to endpoints'})
print(json.dumps({'status':'PASS','binomial_rounds':rows,'space_rounds':spatial,'unequal_block_rounds':block,'mass_resolution_necessity':necessity,'scope':'Exact scalar exponential certificates and rational spatial corollaries; finite tests do not prove a general dimension bound'},indent=2))
