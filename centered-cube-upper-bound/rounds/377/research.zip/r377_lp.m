% Only new fixed-retention residual refill LPs. All original fields stay frozen.
r377_base=fileparts(mfilename('fullpath'));r377_data=jsondecode(fileread(fullfile(r377_base,'r377_numeric_input.json')));
r377_options=optimoptions('linprog','Display','none');r377_results={};r377_count=0;
for r377_i=1:numel(r377_data.cases)
 r377_case=r377_data.cases(r377_i);
 for r377_j=1:numel(r377_case.residual_problems)
  r377_p=r377_case.residual_problems(r377_j);if ~r377_p.needs_lp,continue;end
  r377_cost=double(r377_p.cost_numeric);r377_rows=double(r377_p.row_numeric(:));r377_cols=double(r377_p.col_numeric(:));r377_nr=numel(r377_rows);r377_nc=numel(r377_cols);r377_f=reshape(r377_cost',[],1);
  r377_Ar=kron(speye(r377_nr),ones(1,r377_nc));r377_Ac=kron(ones(1,r377_nr),speye(r377_nc));
  [r377_x,r377_val,r377_flag,r377_info,r377_mult]=linprog(r377_f,r377_Ac,r377_cols,r377_Ar,r377_rows,zeros(numel(r377_f),1),[],r377_options);
  r377_res=struct('name',r377_case.name,'v',r377_p.v,'plan',r377_x,'exitflag',r377_flag,'value',r377_val);
  r377_count=r377_count+1;r377_results{r377_count}=r377_res;
 end
end
r377_fid=fopen(fullfile(r377_base,'r377_numeric_output.json'),'w');fwrite(r377_fid,jsonencode(struct('plans',[r377_results{:}])),'char');fclose(r377_fid);
fprintf('R377 completed %d new fixed-retention refill LPs.\n',r377_count);
