#!/usr/bin/env python3
"""R377: freeze priority retention and optimize only the remaining refill."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,deque
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def rat(v):return F(0) if abs(v)<1e-10 else F(str(v)).limit_denominator(10**9)
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def residual_problem(p,cert):
 d=F(p['d']);U=list(map(F,p['U']));loss=list(map(F,cert['loss_by_source_row']['water_priority']));full=[list(map(F,row)) for row in cert['plans']['water_priority']];C=[list(map(F,row)) for row in p['cost']];nr=len(loss);nc=len(U)
 retained=[[full[i][j]-d*loss[i]*U[j] for j in range(nc)] for i in range(nr)];r=[d*a for a in loss];cap=[2*d*U[j]-sum(retained[i][j] for i in range(nr)) for j in range(nc)]
 ck('frozen_retention_nonnegative_zero_loss',all(a>=0 for row in retained for a in row) and sum(retained[i][j]*C[i][j] for i in range(nr) for j in range(nc))==0)
 ck('residual_rows_and_target_capacity_nonnegative',all(a>=0 for a in r+cap) and sum(r)<=sum(cap))
 ck('old_uniform_refill_feasible_for_residual_problem',all(sum(r)*U[j]<=cap[j] for j in range(nc)))
 sr=[i for i in range(nr) if r[i]>0];tc=[j for j in range(nc) if cap[j]>0];cost=[[C[i][j] for j in tc] for i in sr];needs=bool(sr) and any(a>0 for row in cost for a in row)
 return dict(v=p['v'],row_indices=sr,target_indices=tc,row=list(map(str,[r[i] for i in sr])),col=list(map(str,[cap[j] for j in tc])),cost=[list(map(str,row)) for row in cost],row_numeric=list(map(float,[r[i] for i in sr])),col_numeric=list(map(float,[cap[j] for j in tc])),cost_numeric=[[float(a) for a in row] for row in cost],retained=[list(map(str,row)) for row in retained],old_uniform_cost=cert['bad']['water_priority'],needs_lp=needs)
def prepare():
 old=read('r376_numeric_input.json');res=read('r376_numeric_result.json');lookup={(a['name'],a['v']):a for a in res['construction_certificates']};cases=[]
 for c in old['cases']:
  c=dict(c);c['residual_problems']=[residual_problem(p,lookup[(c['name'],p['v'])]) for p in c['plans']];cases.append(c)
 data=dict(cases=cases,inherited_cap2_certificates=old['inherited_cap2_certificates'],provenance={p:sha(p) for p in ['r376_numeric_input.json','r376_numeric_result.json']},scope='Frozen R376 exact priority retention and all full-source diagnostic fields. Only residual refill is optimized. Real positive-volume L1 source/target cells, finite receiver quadrature; not native hard traffic.',construction_checks=sum(COUNTS.values()),construction_check_counts=dict(COUNTS))
 (BASE/'r377_numeric_input.json').write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PREPARED',construction_checks=sum(COUNTS.values()),cases=[dict(name=c['name'],new_lp_count=sum(p['needs_lp'] for p in c['residual_problems']),zero_residual=sum(not p['row'] for p in c['residual_problems'])) for c in cases]),indent=2))
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=list(map(F,p['col']));K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def solve_equalities(A,b):
 M=[list(map(F,row))+[F(v)] for row,v in zip(A,b)];nr=len(M);nc=len(M[0])-1;i=0;piv=[]
 for j in range(nc):
  k=next((k for k in range(i,nr) if M[k][j]),None)
  if k is None:continue
  M[i],M[k]=M[k],M[i];v=M[i][j];M[i]=[x/v for x in M[i]]
  for k in range(nr):
   if k!=i:
    v=M[k][j]
    if v:M[k]=[x-v*y for x,y in zip(M[k],M[i])]
  piv.append(j);i+=1
  if i==nr:break
 assert all(any(row[:nc]) or row[nc]==0 for row in M),'inconsistent support margin reconstruction'
 x=[F(0)]*nc
 for k,j in enumerate(piv):x[j]=M[k][-1]
 return x

def rational_transport(p,raw):
 cap2=True;capacity=F(1) # p[col] already contains the exact residual capacity.
 rows=list(map(F,p['row']));cols=list(map(F,p['col']));cost=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols)
 vals=[rat(x) for x in raw['plan']];edges=[(i,j) for i in range(nr) for j in range(nc) if vals[i*nc+j]>0]
 eq=[[int(a==i) for a,b in edges] for i in range(nr)]+[[int(b==j) for a,b in edges] for j in range(nc)]
 vv=[vals[i*nc+j] for i,j in edges];rhs=rows+cols
 if cap2:
  approxcol=[sum(vals[i*nc+j] for i in range(nr)) for j in range(nc)];sat=[j for j in range(nc) if abs(float(approxcol[j]-capacity*cols[j]))<1e-9]
  eq=eq[:nr]+[eq[nr+j] for j in sat];rhs=rows+[capacity*cols[j] for j in sat]
 res=[b-dot(a,vv) for a,b in zip(eq,rhs)];corr=solve_equalities(eq,res);vv=[a+b for a,b in zip(vv,corr)];T=[[F(0)]*nc for i in range(nr)]
 for (i,j),a in zip(edges,vv):T[i][j]=a
 ck('optimal_plan_nonnegative',all(a>=0 for row in T for a in row));colused=[sum(T[i][j] for i in range(nr)) for j in range(nc)]
 ck('residual_exact_source_and_column_upper' if cap2 else 'optimal_plan_both_exact_marginals',[sum(row) for row in T]==rows and (all(a<=capacity*b for a,b in zip(colused,cols)) if cap2 else colused==cols))
 # Exact weak-dual certificate from positive support: component offsets solve difference inequalities.
 adj=[[] for _ in range(nr+nc)]
 for i in range(nr):
  for j in range(nc):
   if T[i][j]>0:adj[i].append((nr+j,cost[i][j]));adj[nr+j].append((i,cost[i][j]))
 comp=[None]*(nr+nc);base=[F(0)]*(nr+nc);cc=0
 for start in range(nr+nc):
  if comp[start] is not None:continue
  comp[start]=cc;q=deque([start])
  while q:
   u=q.popleft()
   for v,c in adj[u]:
    if comp[v] is None:comp[v]=cc;base[v]=c-base[u];q.append(v)
    else:ck('dual_tight_support_consistency',base[u]+base[v]==c)
  cc+=1
 constraints=[(comp[i],comp[nr+j],cost[i][j]-base[i]-base[nr+j]) for i in range(nr) for j in range(nc)]
 if cap2:
  root=cc;cc+=1
  for j in range(nc):
   constraints.append((root,comp[nr+j],-base[nr+j])) # beta_j<=0
   if colused[j]<capacity*cols[j]:constraints.append((comp[nr+j],root,base[nr+j])) # slack implies beta_j=0
 offset=[F(0)]*cc
 for _ in range(cc):
  changed=False
  for a,b,c in constraints:
   if offset[a]>offset[b]+c:offset[a]=offset[b]+c;changed=True
  if not changed:break
 ck('dual_component_difference_constraints',all(offset[a]-offset[b]<=c for a,b,c in constraints))
 if cap2:
  anchor=offset[root];offset=[v-anchor for v in offset]
 rp=[base[i]+offset[comp[i]] for i in range(nr)];cp=[base[nr+j]-offset[comp[nr+j]] for j in range(nc)]
 if cap2:ck('residual_dual_columns_nonpositive_and_slack_complementary',all(b<=0 for b in cp) and all(b==0 or u==capacity*c for b,u,c in zip(cp,colused,cols)))
 ck('exact_transport_dual_all_cell_pairs',all(rp[i]+cp[j]<=cost[i][j] for i in range(nr) for j in range(nc)))
 primal=sum(T[i][j]*cost[i][j] for i in range(nr) for j in range(nc));dual=dot(rows,rp)+dot([capacity*c for c in cols] if cap2 else cols,cp);ck('residual_exact_primal_dual_zero_gap' if cap2 else 'exact_transport_primal_dual_zero_gap',primal==dual)
 return primal,dict(v=p['v'],target_class='fixed-retention residual cap',plan=[list(map(str,row)) for row in T],row_potential=list(map(str,rp)),column_potential=list(map(str,cp)),value=str(primal),margin_repair_nonzero=any(corr),exitflag=raw['exitflag'])
def cap2_lower(p,cert):
 C=[list(map(F,row)) for row in p['cost']];r=list(map(F,p['row']));s=list(map(F,p['col']));T=[list(map(F,row)) for row in cert['plan']];rp=list(map(F,cert['row_potential']));cp=list(map(F,cert['column_potential']));nr=len(r);nc=len(s)
 ck('reused_cap2_primal_feasible',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==r and all(sum(T[i][j] for i in range(nr))<=2*s[j] for j in range(nc)))
 ck('reused_cap2_dual_feasible',all(b<=0 for b in cp) and all(rp[i]+cp[j]<=C[i][j] for i in range(nr) for j in range(nc)))
 val=sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc));ck('reused_cap2_exact_optimal_benchmark',val==dot(r,rp)+dot([2*a for a in s],cp)==F(cert['value']));return val

def slack_row_refill(p,d,U):
 rows=list(map(F,p['row']));slack=list(map(F,p['col']));C=[list(map(F,row)) for row in p['cost']];total=sum(rows);nr=len(rows);nc=len(slack)
 if not total:return F(0),[],dict(v=p['v'],delta='0',t_delta=None,row_thresholds=[],value='0')
 delta=total/d;capmass=sum(slack);sigma=[b/capmass for b in slack];t=capmass/total
 ck('slack_reference_sigma_and_tdelta_exact',sum(sigma)==1 and capmass==d+total and t==(1+delta)/delta)
 T=[];thresholds=[];value=F(0);uniformgaps=[];Ucomp=[U[j] for j in p['target_indices']]
 for i,r in enumerate(rows):
  caps=[r*b/total for b in slack];left=r;plan=[F(0)]*nc;theta=None
  for j in sorted(range(nc),key=lambda j:(C[i][j],j)):
   take=min(left,caps[j]);plan[j]=take;left-=take
   if take:theta=C[i][j]
   if not left:break
  ck('slack_row_quantile_source_exact_and_caps',left==0 and sum(plan)==r and all(0<=a<=b for a,b in zip(plan,caps)))
  beta=[min(c-theta,F(0)) for c in C[i]];ck('slack_row_quantile_threshold_dual',all(b<=0 and theta+b<=c for b,c in zip(beta,C[i])))
  val=dot(C[i],plan);ck('slack_row_quantile_exact_optimality',val==r*theta+dot(caps,beta))
  uniformcost=r*dot(C[i],Ucomp);ck('slack_row_uniform_comparator_feasible_and_not_better',all(r*u<=cap for u,cap in zip(Ucomp,caps)) and val<=uniformcost);uniformgaps.append(str(uniformcost-val))
  value+=val;T.append(plan);thresholds.append(str(theta))
 ck('slack_row_quantile_global_residual_cap',all(sum(T[i][j] for i in range(nr))<=slack[j] for j in range(nc)))
 return value,T,dict(v=p['v'],delta=str(delta),t_delta=str(t),sigma=list(map(str,sigma)),row_thresholds=thresholds,uniform_row_gaps=uniformgaps,nonconstant_cost_rows=sum(len(set(row))>1 for row in C),strictly_loose_column_cost_distinct_counts=[len({c for c,b,u in zip(row,slack,Ucomp) if b>total*u}) for row in C],value=str(value),plan=[list(map(str,row)) for row in T])

def shared_free_buffer(p):
 rows=list(map(F,p['row']));slack=list(map(F,p['col']));C=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(slack)
 if not rows:return F(0),[],dict(v=p['v'],active_count=0,free_count=0,active_mass='0',value='0')
 active=[i for i,row in enumerate(C) if any(a>0 for a in row)];free=[i for i,row in enumerate(C) if all(a==0 for a in row)];da=sum(rows[i] for i in active);T=[[F(0)]*nc for i in range(nr)];thresholds={};value=F(0)
 ck('buffer_free_only_identically_zero_cost',set(active).isdisjoint(free) and len(active)+len(free)==nr and all(all(a==0 for a in C[i]) for i in free))
 if da:
  for i in active:
   caps=[rows[i]*b/da for b in slack];left=rows[i];theta=None
   for j in sorted(range(nc),key=lambda j:(C[i][j],j)):
    take=min(left,caps[j]);T[i][j]=take;left-=take
    if take:theta=C[i][j]
    if not left:break
   beta=[min(c-theta,F(0)) for c in C[i]];val=dot(C[i],T[i])
   ck('buffer_active_quantile_source_and_caps',left==0 and sum(T[i])==rows[i] and all(0<=a<=b for a,b in zip(T[i],caps)))
   ck('buffer_active_threshold_dual_and_zero_gap',all(b<=0 and theta+b<=c for b,c in zip(beta,C[i])) and val==rows[i]*theta+dot(caps,beta))
   value+=val;thresholds[i]=theta
 rem=[slack[j]-sum(T[i][j] for i in active) for j in range(nc)];remtotal=sum(rem);free_mass=sum(rows[i] for i in free)
 ck('buffer_remaining_slack_contains_all_free_mass',all(a>=0 for a in rem) and remtotal>=free_mass and (not free_mass or remtotal>0))
 for i in free:T[i]=[rows[i]*a/remtotal for a in rem]
 ck('buffer_full_residual_source_and_column_cap',all(a>=0 for row in T for a in row) and [sum(row) for row in T]==rows and all(sum(T[i][j] for i in range(nr))<=slack[j] for j in range(nc)))
 ck('buffer_free_fill_zero_cost',value==sum(T[i][j]*C[i][j] for i in range(nr) for j in range(nc)))
 cert=dict(v=p['v'],active_indices=active,free_indices=free,active_count=len(active),free_count=len(free),active_mass=str(da),active_thresholds={str(i):str(v) for i,v in thresholds.items()},remaining_slack=list(map(str,rem)),remaining_slack_mass=str(remtotal),free_mass=str(free_mass),value=str(value),plan=[list(map(str,row)) for row in T])
 if len(active)==1:
  i=active[0];theta=thresholds[i];rp=[theta if k==i else F(0) for k in range(nr)];cp=[min(a-theta,F(0)) for a in C[i]]
  ck('single_active_buffer_global_dual_feasible',all(b<=0 for b in cp) and all(rp[k]+cp[j]<=C[k][j] for k in range(nr) for j in range(nc)))
  ck('single_active_buffer_global_primal_dual_zero_gap',value==dot(rows,rp)+dot(slack,cp))
  cert['global_row_potential']=list(map(str,rp));cert['global_column_potential']=list(map(str,cp));cert['global_optimality_certified']=True
 else:cert['global_optimality_certified']=not active
 return value,T,cert

def verify():
 data=read('r377_numeric_input.json');raw=read('r377_numeric_output.json')['plans'];raw=[raw] if isinstance(raw,dict) else raw;lookup={(p['name'],p['v']):p for p in raw};bench={(c['name'],c['v']):c for c in data['inherited_cap2_certificates']};summ=[];certs=[];rowcerts=[];buffercerts=[]
 ck('exactly_eight_new_nontrivial_refill_lps',len(raw)==sum(p['needs_lp'] for c in data['cases'] for p in c['residual_problems'])==8)
 for c in data['cases']:
  fullmarks(c);uniform=F(0);refill=F(0);rowrefill=F(0);buffer=F(0);opt=F(0);per=[]
  for original,p in zip(c['plans'],c['residual_problems']):
   ck('original_and_residual_receiver_identity',original['v']==p['v']);rows=list(map(F,p['row']));cols=list(map(F,p['col']));C=[list(map(F,row)) for row in p['cost']];nr=len(rows);nc=len(cols)
   if p['needs_lp']:
    val,cert=rational_transport(p,lookup[(c['name'],p['v'])]);cert['name']=c['name'];T=[list(map(F,row)) for row in cert['plan']];certs.append(cert)
   elif rows:
    total=sum(cols);T=[[r*a/total for a in cols] for r in rows];val=F(0);ck('nonzero_residual_zero_cost_trivial_certificate',all(a==0 for row in C for a in row) and sum(rows)<=total)
   else:T=[];val=F(0);ck('zero_residual_trivial_no_lp',not rows)
   rowval,rowT,rowcert=slack_row_refill(p,F(original['d']),list(map(F,original['U'])));rowcert['name']=c['name'];rowcerts.append(rowcert)
   bufval,bufT,bufcert=shared_free_buffer(p);bufcert['name']=c['name'];buffercerts.append(bufcert)
   retained=[list(map(F,row)) for row in p['retained']];combined=[row[:] for row in retained];rowcombined=[row[:] for row in retained];bufcombined=[row[:] for row in retained]
   for i,ii in enumerate(p['row_indices']):
    for j,jj in enumerate(p['target_indices']):combined[ii][jj]+=T[i][j];rowcombined[ii][jj]+=rowT[i][j];bufcombined[ii][jj]+=bufT[i][j]
   source=list(map(F,original['row']));target=list(map(F,original['col']));OC=[list(map(F,row)) for row in original['cost']];ON=len(source);OM=len(target)
   ck('combined_plan_original_source_exact_and_target_cap2',all(a>=0 for row in combined for a in row) and [sum(row) for row in combined]==source and all(sum(combined[i][j] for i in range(ON))<=2*target[j] for j in range(OM)))
   ck('combined_cost_exact_residual_objective',sum(combined[i][j]*OC[i][j] for i in range(ON) for j in range(OM))==val)
   ck('slack_row_combined_plan_source_exact_cap2_and_actual_cost',[sum(row) for row in rowcombined]==source and all(sum(rowcombined[i][j] for i in range(ON))<=2*target[j] for j in range(OM)) and sum(rowcombined[i][j]*OC[i][j] for i in range(ON) for j in range(OM))==rowval)
   ck('buffer_combined_original_source_target_and_cost',[sum(row) for row in bufcombined]==source and all(sum(bufcombined[i][j] for i in range(ON))<=2*target[j] for j in range(OM)) and sum(bufcombined[i][j]*OC[i][j] for i in range(ON) for j in range(OM))==bufval)
   ob=cap2_lower(original,bench[(c['name'],p['v'])]) if original['nonzero_cost'] else F(0);old=F(p['old_uniform_cost']);ck('fixed_retention_refill_between_allcap2_and_uniform',ob<=val<=bufval<=rowval<=old)
   if p['needs_lp']:ck('observed_single_active_buffer_equals_conditional_and_global',bufcert['active_count']==1 and bufval==val==ob)
   w=F(original['weight']);buffer+=w*bufval;uniform+=w*old;refill+=w*val;rowrefill+=w*rowval;opt+=w*ob;per.append(dict(v=p['v'],needs_lp=p['needs_lp'],lost_mass=str(sum(rows)),uniform_bad=str(old),fixed_retention_refill_bad=str(val),slack_row_quantile_bad=str(rowval),shared_free_buffer_bad=str(bufval),allcap2_bad=str(ob)))
  G=F(c['original_diagonal']);floor=F(c['floor']);S=F(c['surplus_diagonal']);ck('actual_three_template_accounts',all(G==floor+(S-v)+v and 0<=v<=S for v in [uniform,rowrefill,buffer,refill,opt]))
  summ.append(dict(stage=c['stage'],name=c['name'],new_lp_count=sum(p['needs_lp'] for p in c['residual_problems']),original_G=str(G),actual_source_W=c['actual_W'],invariant_floor=str(floor),uniform_refill_bad=str(uniform),uniform_bad_fraction_of_G=str(uniform/G),fixed_retention_optimal_refill_bad=str(refill),slack_row_quantile_bad=str(rowrefill),shared_free_buffer_bad=str(buffer),buffer_bad_fraction_of_G=str(buffer/G),gap_buffer_to_conditional_lp=str(buffer-refill),slack_row_bad_fraction_of_G=str(rowrefill/G),gap_uniform_to_slack_row=str(uniform-rowrefill),gap_slack_row_to_conditional_lp=str(rowrefill-refill),refill_bad_fraction_of_G=str(refill/G),allcap2_optimal_bad=str(opt),allcap2_bad_fraction_of_G=str(opt/G),gap_due_to_uniform_refill=str(uniform-refill),gap_due_to_fixed_retention=str(refill-opt),actual_fixed_retention_floor_plus_good=str(G-refill),per_receiver=per))
 out=dict(status='PASS',construction_exact_checks=data['construction_checks'],verification_exact_checks=sum(COUNTS.values()),total_exact_grouped_checks=data['construction_checks']+sum(COUNTS.values()),verification_check_counts=dict(COUNTS),summary=summ,new_exact_refill_certificates=certs,slack_row_exact_certificates=rowcerts,shared_free_buffer_certificates=buffercerts,scope=data['scope'],provenance=data['provenance'])
 (BASE/'r377_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['new_exact_refill_certificates','slack_row_exact_certificates','shared_free_buffer_certificates']}|{'summary':[{k:v for k,v in c.items() if k!='per_receiver'} for c in summ]},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
