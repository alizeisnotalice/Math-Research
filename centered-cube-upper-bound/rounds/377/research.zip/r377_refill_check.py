from fractions import Fraction as F
from itertools import product
counts=[0,0,0]
active=[0,0,0]
strict=[0,0,0]
buffer_strict=[0,0,0]
single_profile=[0,0,0]

def water(U,H):
    cuts=sorted(set([F(1),F(2)]+[x for x in H if 1<x<2]))
    for lo,hi in zip(cuts,cuts[1:]):
        low=sum(w for w,x in zip(U,H) if x<=lo)
        high=sum(w*x for w,x in zip(U,H) if x>lo)
        if low:
            a=(2-high)/low
            if lo<=a<=hi:return a
    return F(2)

def take(weights,bounds,score,mass):
    left=mass;k=[F(0)]*len(weights)
    for val in sorted(set(score),reverse=True):
        ids=[i for i,x in enumerate(score) if x==val]
        cap=sum(weights[i]*bounds[i] for i in ids)
        fac=min(F(1),left/cap) if cap else F(0)
        for i in ids:k[i]=fac*bounds[i]
        left-=fac*cap
    assert left==0
    return k

def run(P,U,K,phase):
    nr,nc=len(P),len(U)
    L=[max(row) for row in K]
    rU=[sum(w*x for w,x in zip(U,row)) for row in K]
    g=[L[i]-rU[i] for i in range(nr)]
    C=[[L[i]-K[i][j] for j in range(nc)] for i in range(nr)]
    proposal=[]
    for i in range(nr):
        mask=[C[i][j]<=g[i]/2 for j in range(nc)]
        vol=sum(U[j] for j in range(nc) if mask[j])
        proposal.append([F(int(x))/vol for x in mask])
    H=[sum(P[i]*proposal[i][j] for i in range(nr)) for j in range(nc)]
    a=water(U,H)
    k=[[F(0)]*nc for _ in range(nr)]
    for j in range(nc):
        col=take(P,[proposal[i][j] for i in range(nr)],
                 [K[i][j]-rU[i] for i in range(nr)],min(H[j],a))
        for i in range(nr):k[i][j]=col[i]
    beta=[1-sum(U[j]*k[i][j] for j in range(nc)) for i in range(nr)]
    delta=sum(P[i]*beta[i] for i in range(nr))
    R=[sum(P[i]*k[i][j] for i in range(nr)) for j in range(nc)]
    slack=[2-x for x in R]
    assert delta==2-a and all(x>=delta for x in slack)
    assert sum(U[j]*slack[j] for j in range(nc))==1+delta
    counts[phase]+=2
    if not delta:
        assert all(x==0 for x in beta);counts[phase]+=1
        return
    active[phase]+=1
    Pb=[P[i]*beta[i]/delta for i in range(nr)]
    sig=[U[j]*slack[j]/(1+delta) for j in range(nc)]
    t=(1+delta)/delta
    opt=[];net_aff=F(0);qgain=F(0)
    for i in range(nr):
        rr=take(sig,[t]*nc,K[i],F(1))
        opt.append(rr)
        assert sum(sig[j]*rr[j] for j in range(nc))==1
        assert all(0<=x<=t for x in rr)
        rS=sum(sig[j]*K[i][j] for j in range(nc))
        var=sum(sig[j]*(K[i][j]-rS)**2 for j in range(nc))
        M=max(rS,delta*(L[i]-rS))
        aff=[1+(K[i][j]-rS)/M for j in range(nc)] if M else [F(1)]*nc
        assert all(0<=x<=t for x in aff)
        assert sum(sig[j]*aff[j] for j in range(nc))==1
        gain_aff=rS-rU[i]+(var/M if M else F(0))
        cost=sum(sig[j]*rr[j]*C[i][j] for j in range(nc))
        cuts=sorted(set([F(0),L[i]]+C[i]))
        profile=F(0);value=F(0)
        for lo,hi in zip(cuts,cuts[1:]):
            low=sum(U[j] for j in range(nc) if C[i][j]<=lo)
            e_low=sum(U[j]*(slack[j]-delta) for j in range(nc) if C[i][j]<=lo)
            profile+=(hi-lo)*min(1-low,e_low/delta)
            value+=(hi-lo)*max(F(0),1-low-e_low/delta)
        assert cost==value and g[i]-cost==profile>=max(F(0),gain_aff)
        qgain+=P[i]*beta[i]*profile
        net_aff+=P[i]*beta[i]*max(F(0),gain_aff)
        counts[phase]+=5
    refill=[[beta[i]*opt[i][j]*slack[j]/(1+delta) for j in range(nc)] for i in range(nr)]
    target=[sum(P[i]*refill[i][j] for i in range(nr)) for j in range(nc)]
    assert all(sum(U[j]*refill[i][j] for j in range(nc))==beta[i] for i in range(nr))
    assert all(target[j]<=slack[j] and R[j]+target[j]<=2 for j in range(nc))
    uniformcost=sum(P[i]*beta[i]*g[i] for i in range(nr))
    qcost=sum(P[i]*U[j]*refill[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert uniformcost-qcost==qgain>=net_aff>=0
    counts[phase]+=3
    col=[sum(Pb[i]*K[i][j] for i in range(nr)) for j in range(nc)]
    mean=sum(Pb[i]*rU[i] for i in range(nr))
    D=[[K[i][j]-rU[i]-col[j]+mean for j in range(nc)] for i in range(nr)]
    dc=[[beta[i]*(1+D[i][j]/2) for j in range(nc)] for i in range(nr)] # B=1
    assert all(x>=0 for row in dc for x in row)
    assert all(sum(U[j]*dc[i][j] for j in range(nc))==beta[i] for i in range(nr))
    assert all(sum(P[i]*dc[i][j] for i in range(nr))==delta for j in range(nc))
    dg=delta*sum(Pb[i]*U[j]*D[i][j]**2 for i in range(nr) for j in range(nc))/2
    dcost=sum(P[i]*U[j]*dc[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert uniformcost-dcost==dg>=0
    counts[phase]+=4
    def buffer(tau):
        cheap=[max(C[i])<=tau for i in range(nr)]
        da=sum(P[i]*beta[i] for i in range(nr) if not cheap[i])
        df=delta-da
        aa=[[F(0)]*nc for _ in range(nr)]
        if da:
            for i in range(nr):
                if not cheap[i]:
                    den=take(sig,[(1+delta)/da]*nc,K[i],F(1))
                    aa[i]=[beta[i]*den[j]*slack[j]/(1+delta) for j in range(nc)]
        colA=[sum(P[i]*aa[i][j] for i in range(nr)) for j in range(nc)]
        remain=[slack[j]-colA[j] for j in range(nc)]
        out=[[beta[i]*remain[j]/(1+df) if cheap[i] else aa[i][j]
              for j in range(nc)] for i in range(nr)]
        assert all(x>=0 for x in remain) and sum(U[j]*remain[j] for j in range(nc))==1+df
        assert all(sum(U[j]*out[i][j] for j in range(nc))==beta[i] for i in range(nr))
        assert all(sum(P[i]*out[i][j] for i in range(nr))<=slack[j] for j in range(nc))
        cc=sum(P[i]*U[j]*out[i][j]*C[i][j] for i in range(nr) if cheap[i] for j in range(nc))
        ac=sum(P[i]*U[j]*out[i][j]*C[i][j] for i in range(nr) if not cheap[i] for j in range(nc))
        assert cc<=tau*df
        counts[phase]+=4
        if tau==0:
            assert cc==0 and ac<=qcost
            dispersion=sum(P[i]*beta[i]*U[j]*U[l]*abs(C[i][j]-C[i][l])
                 for i in range(nr) if not cheap[i] for j in range(nc) for l in range(nc))
            credit=min(F(1),df/da)*dispersion/2 if da else F(0)
            assert uniformcost-ac>=credit
            profiles=set(tuple(C[i]) for i in range(nr) if not cheap[i] and beta[i]>0)
            if len(profiles)==1:
                prof=list(profiles)[0]
                agg=take(U,slack,[-x for x in prof],da)
                val=sum(U[j]*agg[j]*prof[j] for j in range(nc))
                cut=max(prof[j] for j in range(nc) if agg[j]>0)
                cert=cut*da-sum(U[j]*slack[j]*max(cut-prof[j],F(0)) for j in range(nc))
                assert ac==val==cert
                single_profile[phase]+=1
                counts[phase]+=1
            counts[phase]+=2
        return ac+cc
    bcost=buffer(F(0))
    buffer(F(1,4));buffer(F(1,2))
    bgain=uniformcost-bcost
    if bcost<qcost:buffer_strict[phase]+=1
    for seed in range(3):
        psi=[F((seed+2*j)%5,4) for j in range(nc)]
        phi=[max(K[i][j]-psi[j] for j in range(nc)) for i in range(nr)]
        bound=sum(P[i]*beta[i]*phi[i] for i in range(nr))+sum(U[j]*slack[j]*psi[j] for j in range(nc))
        reward=sum(P[i]*U[j]*refill[i][j]*K[i][j] for i in range(nr) for j in range(nc))
        comp=sum(P[i]*U[j]*refill[i][j]*(phi[i]+psi[j]-K[i][j]) for i in range(nr) for j in range(nc))
        unused=sum(U[j]*psi[j]*(slack[j]-target[j]) for j in range(nc))
        assert bound-reward==comp+unused>=0
        counts[phase]+=1
    if max(bgain,dg)>0:strict[phase]+=1

P=[F(1,3),F(2,3)];U=[F(1,6),F(1,3),F(1,2)]
for K in ([[F(0)]*3]*2, [[F(1)]*3]*2,
          [[F(1),F(0),F(0)],[F(1),F(0),F(0)]],
          [[F(0),F(1),F(0)],[F(0),F(0),F(1)]]):run(P,U,K,0)
for raw in list(product((F(0),F(1,2),F(1)),repeat=6))[:36]:
    run(P,U,[list(raw[:3]),list(raw[3:])],1)
for raw in product((F(0),F(1,2),F(1)),repeat=6):
    run(P,U,[list(raw[:3]),list(raw[3:])],2)
P3=[F(1,6),F(1,3),F(1,2)];U4=[F(1,10),F(1,5),F(3,10),F(2,5)]
for seed in range(97):
    K=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)] for i in range(3)]
    run(P3,U4,K,2)
print('PASS stages',counts,'total',sum(counts),'positive-delta cases',active,
      'strict refill gains',strict,'strict buffer-over-row gains',buffer_strict,
      'single-profile exact optimality cases',single_profile)
