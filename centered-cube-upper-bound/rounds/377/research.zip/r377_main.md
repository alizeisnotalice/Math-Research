# 第377轮：联合秩次预算与共享余容量补流

日期2026-10-18。状态：有新的已证明积分估计及可行几何补流；一般一致根阶弱型上界尚未闭合。

本轮冻结完整输入、真实Lebesgue接收测度及R376原场，不重新选择有利标记。准确命题及完整证明见geometry和refill，费用见ledger。只用显式正计划、单调层析、Tonelli和弱对偶；按本机64项工具D01的条件核验，不借用未证明的无限维强对偶。

## 新的一般积分估计

对任意联合可测失量标记0≤β_v(y)≤1，设Ξ=∫_E d_v E_Pβ_v dv。原核总权L满足
\[
 \int_E d_vE_P(\beta_vL_v)dv
 \le\lambda\int f\Phi_h(J_b,C)dy
 \le\varepsilon X_q+\lambda\log\frac\lambda{\varepsilon q_-}\Xi,
 \qquad 0<\varepsilon<\lambda/q_-.
\]
其中C_y=∫β_v(y)(1−q_v/f(y))_+c_v(y)dv/m_v（f=0取0），Φ由geometry(3)定义。证明利用真实半径秩次、严格过去、含末端原子的物理时钟以及∫fJ_b=|E|。失量系数不含log n；代价是明确的εX_q。Ξ的根阶预算没有因此自动成立。

## 补流几何的实质变化

固定R376保留子流k。剩余来源βP、目标容量sU，s=2−E_Pk≥δ=E_Pβ，∫s dU=1+δ。把零代价来源留作填充剩余容量的缓冲，先为活跃来源按真实s/δ_A容量选择低代价目标，随后将零代价来源送入未用容量。全计划仍保原来源、目标≤2U，仍为3Γ费用。

相对均匀补流，新计划具有显式来源加权振荡收益；相对旧比例行容量计划，只一般证明费用不增。单一活跃代价类型时，以直接弱证书证明固定k补流最优；多类型没有一般最优性宣称。可另作完整v计划择优，不能随意逐源混合只具有总容量保证的计划。

## 两项结果的合法结合

记g_v=L_v−E_UK_v，A_v={g_v>0}，β_A=β1_A，Ξ_A=∫d_vE_Pβ_A dv。所有本轮补流均对P_v⊗U_v绝对连续；g=0行的代价C=L−K在U_v几乎处处为0，故这些行真实补流费为0。设γ_v为实际残余补流（包含d_v），并令
\[
 \operatorname{Cap}_A=\int_Edv\int_{A_v\times Q_v}K_v(y,z)d\gamma_v(y,z),
 \quad S=\int_Edv\,d_v E_{P_vU_v}[k_v C_v].
\]
来源边缘精确给出
\[
 G_{\rm refill}=S+\int_Ed_vE_P(\beta_A L_v)dv-\operatorname{Cap}_A
 \le S+\varepsilon X_q+
 \lambda\log\frac\lambda{\varepsilon q_-}\Xi_A-\operatorname{Cap}_A. \tag{M1}
\]
这适用于free-buffer，亦适用于合法whole-v择优所得密度计划。捕获仅扣一次，不能再叠加旧uniform的Eξ或新振荡信用。若选择cheap分组，额外保留≤ζX_q的真实费用，活跃集相应改为cheap补集；本轮默认零阈值，不收此费。

S≤ξG_joint沿用已证近捕获盒支持性质，G_joint≤X_q为既有R370接口。改变ξ会改变k、β及Ξ_A，不能把失量固定后免费令ξ趋零。M1给出下一步须支付的具体带符号余额：S+λlog(λ/(εq_-))Ξ_A−Cap_A。未证明其一般根阶来源预算；不以Ξ_A≤|E|代替小系数付款。

## 本机验证与适用边界

本机MATLAB实际执行8个新固定k残余LP；Python Fraction复核8组零间隙原始/对偶证书，并独立验证显式free-buffer。三组冻结实际L1来源诊断中，buffer达到固定k LP及更宽cap2最优；旧slack-row quantile没有改善。二维剩余仍为4627/3720960，不是零。

三个阶段为1D等权、1D非均匀、2D扩大诊断。来源正体积积分真实，但接收端为有限求积而非Lebesgue一般场，门为诊断参数，不推断维数阶。另对秩次/原时钟/匹配作892组有理检查，对补流构造作13109组精确检查，数值证书脚本总798组（126构造+672验证）；主代理全部重跑通过。脚本检查是有限证据，原子及奇异连续情形由解析证明承担。

没有编译PDF。下一步应在原outside/not-Bplus和真实拥挤几何中支付M1余额，保留完整ledger中的其他缺口；本轮不重复否路线，也不宣称只剩常数优化。
