# R377 — freeze priority retention, optimize only the refill

## Decision

On all three frozen R376 fields, **optimal common refill with priority retention fixed equals the unrestricted target-cap2 optimum**. Thus the previously observed priority-versus-cap2 gap is removed by changing refill alone; these fixed retentions impose no additional optimal-cost gap in the tested samples.

The proposed explicit slack-reference row quantile is feasible and exactly row-optimal, but gives **the same cost as uniform refill** here. The additional explicit **shared free-buffer** construction does attain the conditional LP and all-cap2 optima, without any new optimizer call. It allocates scarce target capacity to the costly row first, then lets identically zero-cost rows absorb the remaining slack.

| Field | Priority + uniform bad/G | Slack-row quantile bad/G | Shared free-buffer = fixed-retention LP bad/G | Unrestricted cap2 bad/G |
|---|---:|---:|---:|---:|
| Equal 15 intervals | 491/35424 | 491/35424 | 0 | 0 |
| Weighted 15 intervals | 39691/5158332 | 39691/5158332 | 0 | 0 |
| Twelve 2D cubes | 22561/60288 | 22561/60288 | 661/1884 | 661/1884 |

This does not claim that every retention is harmless or that the row construction never helps. It identifies the bottleneck in these three actual-source finite-quadrature fields. No native hard-gate or dimension-rate conclusion is drawn.

## Frozen input and exact residual problem

R376's three complete sources, receiver cubes, masses, original marks, physical clock and priority retained subflows stay unchanged. The sources are actual compact positive-L1 piecewise-constant densities on 16,16,208 positive-volume source cells. All actual receiver matching remains m_u=R_u^n, q_u=1, with source masses 4,4,33/4. Receiver weights are finite quadrature, not dx. The script independently reconstructs all ω/J/strict-past/clock marks and every original common all-u cost before checking the new residual account.

For each v, R376 stores the priority completed plan and normalized source losses l_i. The exact frozen retention is recovered as

    k_ij = old_completed_plan_ij − d_v l_i U_j.

It is verified nonnegative and supported on the original zero-loss layers C=L−K=0. The remaining source rows and target capacities are

    r_i=d_v l_i,
    b_j=2d_vU_j−Σ_i k_ij.

They are nonnegative and uniform refill r_iU_j is explicitly feasible. The new LP minimizes the SAME original C against a remaining plan F with row sums r_i and columns≤b_j. There is one common plan per v for all u. No new mark, source, receiver radius, or independent per-u plan is introduced.

Zero source rows and zero-capacity targets are omitted only from the residual LP, then restored when verifying the full combined original plan. Exactly 34 v have zero residual and need no LP: 12,12,10. Exactly **eight** have nonzero residual and nontrivial cost: 3,3,2. Only these eight new LPs were actually run in MATLAB; no old cap LP was rerun.

## Exact conditional LP certificates and actual templates

Each new solver candidate is rationally reconstructed and checked against the exact remaining source and capacity constraints. Exact row and nonpositive column potentials satisfy α_i+β_j≤C_ij, and

    Σ_i r_i α_i + Σ_j b_j β_j = feasible refill cost.

All eight primal/dual gaps are zero. Margin corrections are zero. The retained cost is exactly zero; the sum of fixed retention plus optimal refill is checked on every original source/target cell for exact source marginal, target≤2d_vU, and exact total original cost.

The optimal refill bad costs are 0,0,4627/3720960. Reused R375 cap2 plans and duals are rechecked as benchmarks, rather than reoptimized. The equalities with the conditional optima hold after summing original outer receiver weights. Actual floor+good values are respectively

    41/4224, 143287/11128320, 8561/3720960.

The exact improvement over uniform refill is 491/3649536, 39691/400619520, 9863/119070720. The gap attributable to keeping these particular retentions fixed is zero in all three cases. Actual G=floor+good+bad is preserved; a coarse Γ template is not substituted for the sample integral.

## Explicit slack-reference row quantile

Write lost total as d_vδ and remaining column density as s_j=b_j/(d_vU_j). The checks give s_j≥δ and

    σ_j=b_j/[d_v(1+δ)],  Σ_jσ_j=1,
    t_δ=(1+δ)/δ.

For δ>0, each residual source row fills target costs in increasing order with entry cap

    cap_ij = r_i b_j/(d_vδ) = r_i t_δ σ_j.

The source row must sum to r_i; ties are split using the deterministic column-index rule. This cap implies the shared residual target capacity after summing rows. δ=0 is handled as a zero-flow case without division.

There are 21 positive residual source rows across the eight v. For each row, the exact last-filled cost θ gives min-cost dual potentials α=θ, β_j=min(C_ij−θ,0)≤0. Feasibility and

    row cost = r_iθ + Σ_j cap_ij β_j

are verified exactly. Every row's original uniform refill is itself feasible and has the same optimal row cost in this sample. The full reconstructed slack-row plan remains source exact and within original target cap2. There is no additional target-capacity or template enlargement.

The apparent lack of improvement is geometrically/structurally specific. In each of the eight nontrivial v there is exactly one residual row with nonconstant cost. On every strictly loose target column b_j>lost_total·U_j, that row's cost is constant. Its cheaper columns have tight capacity b_j=lost_total·U_j. The per-row restriction allocates these scarce cheap columns in proportion to lost source mass, so it cannot transfer their allocation away from constant-cost rows toward the row that benefits. A common residual plan can make that transfer and reaches the smaller optimum. Exact per-row uniform gaps (all zero), threshold values, and cost-distinctness diagnostics are saved.

This distinguishes two questions: a better reference alone does not improve these rowwise costs, while shared residual capacity does. It does not establish a universal obstruction to row quantiles or a general prescription for the native flow.

## Explicit shared free-buffer construction closes the observed gap

Classify residual rows as **free only if C_ij=0 for every remaining target j**; all other rows are active, including any constant-positive row. Let δ_A be the actual total active source mass. No constant-positive row is treated as free. In these actual data, all eight nontrivial plans have exactly one active row, and the other thirteen positive residual rows are truly free.

For δ_A>0, each active row i fills increasing original cost with caps

    active_cap_ij = r_i b_j/δ_A.

The usual threshold dual certifies its exact row minimum. The active rows collectively use at most b_j. Let b'_j be the remaining slack. Free rows are then assigned

    F_ij = r_i b'_j / Σ_j b'_j.

Their source sums are exact. Since Σb' = Σb−δ_A ≥ total free source mass, their combined columns fit in b'. Every free-row cost is zero. The code handles empty lost source and zero active mass without dividing by zero; it does not assert multi-active global optimality.

With **one** active row, its cap is the entire original slack b. Its greedy row minimum is a lower bound for any joint refill because all other rows have zero cost. The free-buffer plan attains that lower bound. More explicitly, if θ is its cutoff and β_j=min(C_active,j−θ,0), take active row potential θ and all free row potentials zero. Then β≤0, α_i+β_j≤C_ij on every row/column, and the exact global dual value equals the explicit buffer cost. All eight such full conditional primal/dual certificates are verified independently of MATLAB's candidate.

The combined fixed-retention+buffer plan is checked on the complete original cells for original source marginal, target cap2 and exact C cost. It attains bad costs 0,0,4627/3720960, equal to both the conditional LP and the inherited unrestricted cap2 optimum in these three samples. It therefore captures the entire observed gap left by uniform refill, while the retention remains frozen. No larger cap or new template coefficient is introduced.

This is a concrete shared-capacity mechanism, not just evidence that an optimizer could help. Its success here relies on the observed free/active geometry. General multi-active data may require further allocation, and no global native hard-field conclusion follows.

## Execution and reproduction

Three stages retain the original models: equal 1D initial case, nonuniform 1D pressure case, then complete 2D expansion. The local pipeline prepare→MATLAB-eight-LP→verify ran, then reran fresh. The final slack-row and shared-buffer modules use no new optimizer and are independently rerun in a fresh Python process. Final count: **126 construction + 672 verification = 798 exact grouped assertions**. These include 8 new conditional LP zero-gap certificates, 21 slack-row threshold zero-gap certificates, 8 explicit buffer row certificates and 8 global single-active zero-gap certificates, 34 zero-residual cases, and 10 inherited cap2 benchmark revalidations. Float flags/displays are not proof and are not included.

Standalone reproduction needs `r377_numeric.py`, `r377_lp.m`, and `r377_numeric_input.json` together. Run the MATLAB script, then:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r377_numeric.py

`r377_numeric_output.json` preserves eight actual solver candidates. `r377_numeric_result.json` preserves new rational refill plans/duals, explicit slack-row and shared-buffer plans/thresholds, the single-active buffer global duals, and all comparisons. Optional prepare mode snapshots frozen `r376_numeric_input.json` and `r376_numeric_result.json` with SHA256 provenance. Verify reads no older temporary script or data beyond its standalone snapshot. Nothing changes old files, global MATLAB paths, or repository state.

Scope: genuine positive-volume source/target L1 integrals, exact all-matching data and full frozen finite diagnostic marks; receiver integration is quadrature. These results are not a realization of original high-dimensional hard gates/history, a continuum source-budget certificate, or a general asymptotic bound.
