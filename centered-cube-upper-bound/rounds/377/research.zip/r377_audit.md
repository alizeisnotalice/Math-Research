# R377 independent audit — FINAL PASS

Status: FINAL PASS for the bounded claims and final bytes below. Owner scope: only this audit file, no repository/author changes. The independent screens preceded the corresponding author proofs; full author and final integration review are now complete. No general root-budget closure, arbitrary-transport optimum or native-gate realization is certified.

## Frozen retained plan, units and exact remaining capacity

Keep the R376 full-f field, original receiver measure, source-dependent marks, m/q/J/past/clock and aggregated C=L-K>=0 fixed. For each actual v, P and U are probability kernels and the full surplus source measure is dP. Freeze the ACTUAL retained density k(y,z) relative to P U from R376, with0<=k<=proposal and row retained mass<=1. Define

R(z)=E_P k(y,z), beta(y)=1-E_U k(y,z),
T=E_PU k=a-1, delta=E_P beta=1-T=2-a.

The retained joint measure is d*k P U, not k alone. Its source marginal is d(1-beta)P and target is d R U. Its exact retained cost is integral C*d*k P U. Lost source is d beta P, total d delta. The complete cap2 target ceiling is2dU, so the residual target CAPACITY is

s_v(dz)=d(2-R(z))U(dz),
||s_v||=d(2-T)=d(1+delta).

This capacity is larger than the missing source mass by exactly d. It is not a target equality constraint and must not be normalized as a probability of mass d delta. The original R376 water construction ensures R(z)+delta<=2; therefore s_v>=d delta U.

A legal nonuniform refill gamma_v has source marginal EXACTLY d beta P and target marginal at most s_v. Its mass is therefore automatically d delta. The total plan tau=d*k P U+gamma_v then has original source marginal dP and target<=2dU. Every original source mark remains at y. The new source/target associations occur only in the auxiliary transport plan; m,q,J,H and past remain defined from full f. No new source, private per-u plan or redefinition of the physical clock is licensed.

## Feasibility, class comparisons and zero cases

Uniform gamma_unif=d beta(y)P(dy)U(dz) is jointly measurable and feasible: its target is d delta U<=s_v. It recovers EXACTLY the original R376 priority plan and its beta*g refill cost. Any certified alternative refill can improve or match it at the SAME3Gamma template price, since the complete target cap stays2dU. The complete estimate must be rebuilt retained+new-refill, not formed by subtracting a lower dual value as if it were an achieved new cost.

For fixed v and frozen k, let conditional_opt be the infimum of TOTAL cost (retained cost plus refill cost) over this restricted refill class. Then

all_cap2_opt <= conditional_opt <= cost_R376_priority.

The left inequality follows because retaining k is an extra restriction on arbitrary source-preserving aggregate-cap2 plans. The right is witnessed by uniform refill. Replacing an infimum by a cost requires either an explicit jointly measurable feasible gamma family or a proved applicable attainment/selection result. A finite LP's optimum does not supply a measurable continuous-kernel optimizer. One can alternatively formulate the continuous comparison over jointly measurable full families, where the uniform candidate gives the same upper bound without selecting independent minimizers.

If delta=0, beta=0 P-almost everywhere by nonnegativity, and gamma=0 is forced. There is no refill LP and the retained plan is already complete. If d=0 all d-weighted plan/cost/constraint contributions vanish; original underlying K/L need not vanish. The endpoint delta=1 is covered algebraically although the specific R376 water solution has a>1 and hence delta<1. Integrability follows from0<=C<=B, finite source loss and the already finite original total source/receiver field. No part of the original cost is discarded.

## Finite LP and weak dual signs

For actual finite source/target cells use lost row masses ell_i=d P_i beta_i, target caps s_j=d U_j(2-R_j), and the exact cell cost C_ij. The primal is

min sum_ij C_ij gamma_ij,
gamma>=0, sum_j gamma_ij=ell_i, sum_i gamma_ij<=s_j.

Its feasible set is nonempty by the uniform plan, bounded and closed; finite-dimensional minimum attainment is justified. The dual is

max sum_i alpha_i ell_i+sum_j nu_j s_j,
alpha unrestricted, nu_j<=0, alpha_i+nu_j<=C_ij.

For any feasible pair, the pointwise inequality gives cost>=alpha*lost+nu*actual_target>=alpha*lost+nu*capacity because nu<=0. Thus the displayed objective is a LOWER bound on conditional REFILL cost. Add the frozen retained cost to compare TOTAL costs. A feasible primal provides an upper construction; exact matching primal/dual values certify a finite conditional optimum. Positive column dual prices, forced use of all slack, or a bare dual lower bound used as a transport upper bound would reverse the needed logic. Null source/target cells and redundant constraints can be handled directly; no full-rank or strictly feasible continuous transport premise is implied.

Exact finite certificates require all source equalities, all target inequalities, nonnegative entries, every cellwise dual inequality and correct nonpositive column potentials; solver flags or floating approximations alone are insufficient. The source and cost cells must be the actual frozen ones, and changing retained k or h changes the feasible subproblem and must be accounted for.

## Scope and actual reviewer arithmetic

This is a more flexible conditional refill than uniform completion, but it still freezes the retained proposal subflow. It does not prove optimality over all aggregate-cap2 transports, a dimension-uniform improvement, a positive covered fraction, or a general root estimate. The matching and weighted congestion requirements remain unresolved until an actual feasible family or quantitative bound is supplied. All original outside/strict-past/high-J marks and historical/soft/scale obligations stay in the ledger.

Reviewer actually ran a local Python Fraction exercise: PASS189 finite mass/slack/uniform-feasibility cases. It checked source loss d delta, slack mass d(1+delta), row sums and every target cap, including d=0 and endpoint losses. These are finite algebraic arrays, not actual native-hard geometry, and are separate from any author/parent pipeline. No R377 author proof had been read at this initial screen stage; completed author/final review follows.

## Additional independent screen: row quantiles using the ENTIRE residual capacity

For delta>0 write s_v(z)=2-R_v(z)>=delta and define the PROBABILITY kernel sigma_v=s_v U_v/(1+delta), t_delta=(1+delta)/delta. Normalize the lost source to beta P/delta when d*delta>0. Giving each lost-source row a probability target density bounded by t_delta relative to sigma guarantees aggregate refill target<=d*delta*t_delta*sigma=d*s_v U, precisely the residual cap. Uniform U is feasible in this row class because dU/dsigma=(1+delta)/s_v<=t_delta. Thus its exact row optimum cannot worsen uniform refill, with the original retained cost and same complete cap2/3Gamma fee.

For a fixed lost source y and0<=C<=L, the exact row cost follows from the already-proved explicit fractional-quantile rule:

V_slack(y)=integral_0^L [1-delta^-1 integral s_v(z)1{C(y,z)<=ell}U_v(dz)]_+ d ell.

Its improvement over uniform g=E_U C is exactly

integral_0^L min(U_v{C>ell},delta^-1 integral(s_v-delta)1{C<=ell}dU_v)d ell.

Indeed set F=U{C<=ell},E=delta^-1 integral(s-delta)1{C<=ell}dU. The integrand difference is(1-F)-(1-F-E)+=min(1-F,E). Endpoint atoms must still be fractionally filled in the attained row plan; strict/inclusive levels affect only a null set of ell, not the actual tie rule. Total refill cost/gain is integrated against d*beta(y)P(dy), NOT against all dP or normalized source without its mass factor. delta=0 has no refill. Although t_delta can be unbounded across v as delta tends to0, it is finite on every delta>0 fiber and the explicit kernel construction is measurable; this does not increase the full aggregate cap2 template price. This is a feasible stronger ROW class, not the general conditional optimum.

Reviewer actually ran1188 finite Fraction cases checking sigma normalization, feasibility of uniform U, exact fractional low-cost fill, the full tail formula and exact nonnegative gain formula. Combined reviewer-local arithmetic so far is1377 grouped scalar cases (189 earlier+1188), separate from future author/parent totals and not native hard geometry.

## Additional independent screen: original-J suffix and source-weighted Hardy bound

Let T_y=J_y(b). The actual mass gap implies R_v<R_u whenever A_uv>0. Retaining this strict radius suffix in the R376 derivation gives

L_v(y)<=lambda integral_{R>R_v,J_y(R-)>h} dJ_y(R)/J_y(R)
<=lambda log_+[T_y/max(h,J_y(R_v))].

The positive part (or a separate T_y<=h zero case) is REQUIRED in a statement over all y. Without it, a negative right side would incorrectly bound L=0. The right prefix J_y(R_v) includes the entire atom at R_v; that atom is excluded from the u suffix and cannot be charged again. Threshold-crossing jumps with left prefix<=h are excluded as before. A Stieltjes/rank argument covers continuous and singular-continuous parts and atoms; no radius density is assumed. The original high-J masks may be removed only by positive domination, with the full original J unchanged.

For ANY measurable0<=beta_v(y)<=1 (including the actual lost-source beta), define w_v(y)=beta_v(y)(1-q_v/f(y))_+, with0 at f=0, and

C_y=integral_E w_v(y)c_v(y) dmu_v,
Xi=integral_E dv d_v E_{P_v}beta_v=integral f(y)C_y dy.

Then0<=C_y<=T_y. If D=integral dv d_v E_P[beta*(L-r)] is the TRUE uniform-refill cost and E_return=integral dv d_v E_P[beta*r], the exact identity is D+E_return=integral dv d_v E_P[beta*L]. These are nonnegative terms from the same frozen source measure; no returned-credit payment is assumed.

Push c_v dmu_v to its radius ranks and preserve the weights w in[0,1]. For each atom, its right cumulative rank J_y(R_v) is at least every rank inside that atom. The potential phi_y(s)=log_+[T_y/max(h,s)] is decreasing, hence phi_y(J_right)<=phi_y(s). The weighted rank measure is dominated by rank Lebesgue with total C_y; decreasing rearrangement bounds it by the first C_y ranks. Therefore

D+E_return<=lambda integral f(y)Phi_h(T_y,C_y)dy,
Phi_h(T,C)=integral_0^C log_+[T/max(h,s)]ds.

This direction uses a RIGHT rank and gives an UPPER bound; it does not replace actual atom weights by independent uniforms. The exact scalar potential is0 when T<=h. For T>h it equals C log(T/h) for C<=h, and C log(T/C)+C-h for h<C<=T, with the C=0 term interpreted as0.

For every fixed theta in(0,1], Phi_h(T,C)<=theta*T+log(1/theta)*C. One proof drops h to bound Phi by C(1+log(T/C)), then applies log x<=x-1 with x=theta*T/C. Zero C/T are handled separately. Crucially the SAME full-f matching gives

integral f(y)T_y dy=integral_E dv/m_v integral_{Q_v} f(y)dy=|E|,
integral f(y)C_y dy=Xi.

Thus the exact joint quantity satisfies

D+E_return <= (lambda/q_-)*theta*X_q +lambda*log(1/theta)*Xi.

Here |E|<=X_q/q_- uses the actual original q band. This is a genuine source-weighted interface with no density cap and no independent-coordinate assumption. It does NOT prove a root price for Xi, nor permit replacing the exact nonuniform-refill cost by this uniform-refill quantity without its own positive comparison. Its use in a full estimate needs the actual beta of that plan and must not separately spend D/E_return a second time. This independent screen preceded author-proof reading; completed author/final review follows.

## Additional independent screen: free-source buffer and active-row capacity

The proposed buffer-sharing construction passes. Work in normalized lost-source measure eta(dy)=beta(y)P(dy), total delta. Split it measurably into free rows F with C(y,.)=0 U-almost everywhere and active rows A, of masses delta_F and delta_A. Since C>=0, F can be tested by the measurable condition E_U C=0. Costs and all old fields remain frozen. For delta_A>0, give every active row a target probability density<=s(z)/delta_A relative to U. An explicit weighted-quantile rule exists as above using probability sigma=sU/(1+delta), cap (1+delta)/delta_A. Its aggregate target density q_A satisfies0<=q_A<=s, integral_U q_A=delta_A. All quantities here omit the outer d; restore it once to joint mass/cost.

Set r(z)=s(z)-q_A(z)>=0. Its mass is1+delta-delta_A=1+delta_F. Fill the free source with the product eta_F(dy)*r(z)U(dz)/(1+delta_F). Its source is exact eta_F and target is delta_F*r/(1+delta_F)<=r. It has zero cost, and active+free target<=s. Thus the frozen retained source plus this refill is a genuine cap2 common plan. If delta_A=0 choose any such free completion directly, with zero cost; if delta_F=0 no free fill is needed. Normalizers are never zero.

If all active rows have the SAME cost function U-almost everywhere (in particular one actual finite active source type), any feasible refill's active target has mass delta_A and is dominated by sU. Its cost is minimized exactly by filling the cheapest delta_A target mass under that cap, which is the single-row quantile. Free source can always fill the leftover as above. Therefore this special conditional-refill optimum is exact, without claiming optimality among arbitrary full cap2 plans with unfrozen retention. For several distinct active cost types, independent active-row caps only yield a feasible upper construction, not necessarily the conditional optimum. Replacing free rows by a cheap group with esssup_U C<=tau is also feasible with the SAME normalized leftover fill, but its actual extra cost<=tau*delta_cheap must be retained; it is not a zero-cost buffer.

## Bounded geometry/Hardy author review

Read /tmp/r377_geometry.md and its complete standalone check script after the independent screen. PASS. The author has correctly included the required log_+ and T<=h zero case, strict R_u>R_v, radius-atom exclusion, and all original clock normalizations. The generalized-inverse argument preserves a radius atom's right rank and applies its original mark average in[0,1]; the decreasing fill inequality is in the needed upper direction. The proof covers singular-continuous pushforwards analytically, not by the finite Cantor/clock tests.

Its improved exact Fenchel bound is correct:

Phi_h(T,C)<= (theta*T-h)_+ +log(1/theta)*C.

For T>h, maximizing over C in[0,T] gives0 if theta*T<=h; otherwise the maximum is attained at C=theta*T and equals theta*T-h. Threshold equality yields a harmless plateau, not a missing atom term. Full-f matching yields integral fT=|E| and integral fC=Xi, so the claimed source-integrated estimate and epsilon tradeoff follow without a density cap. The subtraction E_xi is solely D=(D+E)-E. The exact first-term subtraction lambda*integral f min(theta*T,h) is already part of the same Fenchel bound and cannot be spent twice.

The geometry proof's uniform-refill D and its S+D whole-plan estimate must use that plan's ACTUAL beta. For a new nonuniform refill one needs an explicit comparison or its own cost calculation before inserting it into this inequality. The author retains this distinction, parameter synchronization, unchanged cap2/3Gamma fee and unpaid lambda*Xi balance. Xi<=|E| alone gives no small-coefficient root closure.

The892 claimed checks split as rank_hardy360, physical_clock432, matching_fubini100, totaling892. They use rigorous rational logarithm lower/upper bounds. Finite physical-clock cases keep matching q/R/m, ties and strict past, but do not realize actual Lebesgue cube receivers. Matching/Fubini cases are explicitly finite incidence algebra. Source/rank checks are finite parameter families rather than an exhaustive proof. The reviewer inspected code, without duplicating the full parent run.

Geometry and standalone hashes are bound with the final main/ledger below.

## Independent screen: Hardy on only the active refill source

The proposed active-only integration passes for the CONSTRUCTED absolutely-continuous refills. Define g_v=L_v-r_v>=0, beta_A=beta*1{g_v>0} and Xi_A=integral dv d_v E_P beta_A. This is a jointly measurable mark in[0,1], so the proved Hardy theorem applies with beta replaced by beta_A. Let gamma_A be the actual active refill measure, with exact source marginal d_v beta_A P_v. Then, before any inequality,

D_gamma=integral C dgamma_A=integral dv d_v E_P[beta_A L]-Capture_gamma,
Capture_gamma=integral K dgamma_A>=0.

Hence

D_gamma<=epsilon*X_q+lambda log(lambda/(epsilon*q_-))*Xi_A-Capture_gamma,
0<epsilon<lambda/q_-.

The retained-subflow bad cost remains separate. This is a replacement calculation for that same new plan, not uniform D plus a second capture subtraction. If the sharper Fenchel integral is used, its exact source mark is beta_A as well.

On g=0, nonnegative C has U mean0. The explicit refill densities are absolutely continuous with respect to their actual lost-source kernel times U, so free rows contribute0 to the actual cost. No Hardy charge for free lost-source mass is needed. This implication cannot be asserted for an arbitrary singular source-target plan supported on a rowwise U-null exceptional set. The newly proposed densities meet the needed AC condition; a general conditional-infimum statement must not silently infer it for every singular competitor. This improves the correct conditional balance but does not establish a root bound on lambda*Xi_A or on the retained-plus-signed balance.

## Bounded refill author review

Read /tmp/r377_refill.md in full, including the complete embedded script and its final B3 clarification. PASS. The slack-reference normalization and exact atom-safe row quantile agree with the independent screen. The affine alternative M_delta=max(r_sigma,delta*(L-r_sigma)) gives density between0 and1+1/delta, preserves its row and gains the full r_sigma-r_U+Var_sigma/M_delta; the baseline change is retained. For delta>0,M_delta=0 implies L=K=0 on that row. The variance quotient is bounded by L, so no small-delta singularity is smuggled into the cost. Per-row choice is allowed HERE because all candidates obey the same stronger conditional row cap; it does not license arbitrary mixing of aggregate-only plans.

The free-buffer construction has exact source marginals and aggregate target<=s, and all its refills are densities relative to U. B3 follows from min(1-F,(delta_F/delta_A)F)>=min(1,delta_F/delta_A)F(1-F), integrated using E|C-C'|=2 integral F(1-F). It lower-bounds the gain from UNIFORM refill, not the additional gain over the preceding slack-row quantile. The author's final clarification preserves this distinction; the latter cost comparison is merely nonnegative in general. The55 strict finite buffer-over-row cases check their exact cost differences separately.

The single-active-profile weak certificate has the correct minimization sign: C_*>=c-(c-C_*)_+ and active target<=sU yield cost>=c*delta_A-integral s(c-C_*)_+dU, attained by the scalar fractional fill. The proof explicitly restricts its null-set statement for possibly singular competitors; product-a.e equality suffices for the actual constructed density plans. Cheap-buffer rows retain their real cost<=tau*delta_cheap; choosing tau=zeta*q_- yields at most zeta*X_q because integral dv d_v delta_cheap<=|E|. This does not pay their active complement.

The independent doubly-centered refill uses the residual source P_beta with its exact zero conditional means, so its target is delta U and its reward is delta*E D^2/(2B). Its full plan can be compared against the buffer plan by WHOLE-v selection; the two credits must not be summed on the same lost mass. The unchanged retained k,cap2/3Gamma template and all original marks are retained. §6's reward-form weak dual has nonnegative target prices (the equivalent cost-form dual has nonpositive target prices); the pointwise domination and unused-capacity gap identity are correct. The proof does not assert a general sharp certificate or optimizer exists.

The script's13109 grouped Fraction assertions split46+448+12615. It checks atom allocation, affine net credit, exact double-centering target, free/cheap source completion, whole target/source constraints, B3 relative to uniform,187 single-profile exact scalar certificates and dual gap decompositions. The55 strict buffer-over-row cases are distinguished from244 cases with some strictly positive refill gain. These are finite algebraic kernels, not actual native highpast fields. This reviewer inspected the code and did not duplicate the parent pipeline. Completed final numerical/integration review follows.

## Bounded numerical/LP author review

Read final /tmp/r377_numeric.md,.py,.m and frozen input/output/result structures. PASS within their finite scope. Recorded R376 input/result provenance hashes match actual dependency bytes. A separate read-only comparison checked all42 frozen retained matrices against the actual saved R376 priority completed plans minus their EXACT uniform-refill mass; all agree. This comparison is provenance verification, separate from the parent798 pipeline assertions and reviewer1377 scalar cases.

The source/matching reconstruction keeps full compact L1 sources with W=4,4,33/4 and q=1,m=R^n; full J/global past/physical clock including its terminal atom and one all-u K/L per v are rebuilt. Numerical receivers remain finite quadrature with diagnostic thresholds and masks. No claims of native high-dimensional gates follow. The prepare phase recovers d-weighted retained cell MASS and lost row masses, so the residual cap2 LP columns are already the true remaining caps, not another factor2. Removing zero residual rows/caps for LP and restoring the full combined plan preserves every original source/target cell. All retained costs happen to be0 in this fixture; that observation is explicitly finite, not used to erase arbitrary retained costs in the analytic theorem.

MATLAB's transposed-cost reshape is consistent with the Python row-major plan indexing, and row-equality/column-upper matrices have the correct directions. Exactly eight new conditional refill LPs are solved (3+3+2);34 zero residual cases require no LP. Floating support/saturation classification is accepted only after exact rational reconstruction checks all source sums,target caps,nonnegativity and every dual cell inequality. The component-offset dual method enforces target prices<=0,slack-target price0 and exact primal-dual equality. All eight recorded margin repairs are0. Ten old unrestricted cap2 benchmarks are inherited and reverified, not newly optimized.

The slack-row caps are r_i*b_j/lost_total and correctly sum to each residual row mass; their threshold dual uses beta_j=min(C_ij-theta,0)<=0. The21 positive residual row certificates prove exact row optima and show uniform refill has the same row value HERE. This is not a universal row obstruction. The explicit buffer instead classifies FREE only when every remaining target cost is0; constant-positive rows would be active. Every nontrivial fixture has exactly one active row. That row uses the entire true residual cap, free source fills normalized remaining slack, and its scalar cutoff yields a complete conditional global dual with zero potentials on free rows. The code checks these global duals on ALL rows/columns as well as full-source/full-target reconstruction. Thus the buffer is an actual exact conditional optimum in this sample and matches the older all-cap2 benchmark; no larger target cap or reset matching is involved.

Saved aggregate costs are0,0,4627/3720960; actual floor+good is41/4224,143287/11128320,8561/3720960. The exact improvements over frozen uniform refill are491/3649536,39691/400619520,9863/119070720. The equalities conditional_opt=allcap2_opt are certified for these three cases only. Original G=floor+good+bad is checked with actual sample integrals, not a substituted Gamma envelope.

The final798 grouped exact assertions are126 prepare/construction plus672 verification. They include eight new LP certificates,21 slack-row certificates,eight explicit buffer/global single-active certificates,34 zero residuals and ten inherited benchmark revalidations. Solver exit flags and float displays are not mathematical evidence and are excluded. No complete numeric pipeline was repeated by this reviewer; code/results and42 retained-provenance identities were inspected. Final main/ledger/readme review and complete hash binding are completed below.


## Final integration and complete accounting

Read final main/ledger/readme and rechecked the two final editorial changes: the sourcewise C_y integral uses dv/m_v, and the final unpaid list names G_refill rather than the replaced Gpriority. PASS. Main M1 uses the ACTUAL d-weighted absolutely-continuous refill gamma, beta_A=beta*1{g>0}, exact active source marginal and its own Cap_A. Consequently G_refill=S+integral dEP(beta_A L)-Cap_A is an exact identity; free rows have0 cost only through the constructed density property, not by assuming all singular couplings ignore product-null sets. The Hardy tradeoff then gives M1 with no independent reuse of uniform E_xi, the Fenchel truncation subtraction or dispersion credits. The actual retained cost S remains, and its bound S<=xi*G_joint<=xi*X_q is valid from the proposal support. Varying xi changes k,beta and Xi_A; that dependence is retained.

For a cheap threshold tau=zeta*q_-, the cheap-group real cost is at most zeta*X_q and the active complement must be changed accordingly. Default zeta=0 adds no such cost. All full source fields/physical-clock atoms/original J,H,past and far/outside/not-Bplus masks remain. Target cap2 keeps exactly the same3Gamma joint template price. The old positive decomposition is REBUILT with the selected complete refill plan, not updated by subtracting an unattained dual lower value. Whole-v finite plan choice is legitimate and can only spend one candidate cost; no rowwise mixing of aggregate-only plans or summing alternative credits is licensed.

The original hard slot has base coefficient at most eta. Using Hardy, S<=xi*X and optional cheap fee adds epsilon+xi+zeta BEFORE entrance factor2 and outer Lambda=128/119. Therefore2Lambda(eta+epsilon+xi+zeta) is correct. The example eta=epsilon=xi=kappa/(6Lambda),zeta=0 gives exactly kappa when the stated smallness conditions hold. It allocates THIS hard slot only, not the entire original problem. Changing epsilon only selects the Hardy theta; changing eta changes epsilon0,h and the original h-dependent fields/C338 synchronously. Source price remains the existing C338; no new t_delta-times template price is introduced. Original8lambda H W,2d_eff A_clock Wnu/H,entrance2 and outer Lambda all remain.

Unpaid requirements are the active loss/capture signed balance (or the complete original G_refill), original entrance and soft/crossing interfaces, contract-external tails/scales/threshold complements, historical initial/deletion/future-source time atoms, H choice, source/physical-scale aggregation, outer integration, truncation and limits. Physical terminal atoms do not replace historical atoms. The finite explicit buffer matching all-cap2 optima does not close any of these general slots. This audit does not re-audit every historical reduction or assert that all remaining coefficients can be absorbed.

Parent reports actual fresh execution of geometry892 rational/log-enclosure checks, refill13109 grouped Fraction assertions and numeric798 grouped exact assertions, including eight new MATLAB LPs with exact certificates. These counts are not optimizer counts or independent analytic proofs. Reviewer actually ran1377 grouped scalar Fraction cases and separately verified42 retained-plan provenance comparisons; these are NOT added to the parent totals. No full parent pipeline was duplicated by this reviewer. The standalone refill script matches the unique embedded Python block after whitespace stripping. All source/target/proof files remain unmodified by the reviewer.

Final bounded decision: PASS. The joint-rank tradeoff is a genuine unconditional integral estimate under the stated original hard contract. The active/free buffer and other refills are explicit feasible same-cap plans, with exact special-case conditional optimality and honestly limited finite evidence. The general arbitrary-input root-budget problem remains unresolved in the retained balance and other original slots. No outstanding correction within this review.

## Final SHA256 bindings

These are the final reviewed bytes. Future mathematical edits require re-audit. Generated later TeX/PDF layout is outside this byte binding.

```text
c82863118784b72fc450100a4bcfedb8ed85432373f2f91fcf2431021ab9371e  /tmp/r377_main.md
3a4122195001d3a0587fff057dbc273ad25920ea71726688feb650b9c154e244  /tmp/r377_ledger.md
e1911f5eaef664bd28606481360379a7bdc5157e50b1019424865d0ce02740d8  /tmp/r377_readme.md
16b083e57cd84fe7d3b8b9a077d2211941e7efd340d3bf3bc7fdb0fcaa85a29d  /tmp/r377_geometry.md
37f1653bfa5099cbcd185822a7322fb6b1b6edc3226b252e41b966aa95ed752f  /tmp/r377_geometry_check.py
169bf35d301375bd249c5b1015a6f6020ac11070f37ecdeedf273ef65288a838  /tmp/r377_refill.md
fb71ba3000c5e5f88594f7b7dca4ce66d0705207361bfcd3505ac59994aa676e  /tmp/r377_refill_check.py
17d7192ae7e2b3246e65291fa3aec3f1ed8646cbb9186667a683b78bdc243a75  /tmp/r377_numeric.md
982a4b220e40c6268bce91d433e98e41a92e28a704a0364428fcde374f2234fa  /tmp/r377_numeric.py
585d481bbd5b6499ba280ef6c91d209c63fad3e9c1533d29ef3b422d49d64815  /tmp/r377_lp.m
09203e06b2352b8d096e9b7ffa0a5ebe8fa9626bb960456dda6e082e4305cd71  /tmp/r377_numeric_input.json
6beaecdba357a4ca20e1e26520f8c7cc40f707e3dfd5723da523f0d424f07532  /tmp/r377_numeric_output.json
53ec523917036edf4f783bd60a65c32af65abd9bbcd08827c5e5d1c7e4feb9a0  /tmp/r377_numeric_result.json
16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7  /tmp/r376_geometry.md
6e802aab24ab3c8334306a559dd176bae2bcc11567679fe5ab6feb3678baa8e0  /tmp/r376_priority.md
ee704b7df2428b2b7910b90e7f82805bebfba70947ac58101b9f6ab5ab6dea1e  /tmp/r376_main.md
28863cfe9c3636eeb4bea6003f90f30b15f2f3acb308aebf901aceaa0f564d02  /tmp/r376_ledger.md
a506057e8bfb9c0e03563f03bf02c02cb7287882347589fed0bbb84c3113cf97  /tmp/r376_audit.md
78e33df37d94bad295934ec67a77572c50561952feff6f1067a10951b2ecf4b9  /tmp/r376_numeric_input.json
19bf51c1a877147e6241b1f11775a4ce0fdb57b07a38b65782c02cd2dd51de1f  /tmp/r376_numeric_result.json
b703ec31eee5018d417b115ec7642b9768c91f72472077a0c23460ae27431502  /tmp/r375_geometry.md
3c432638efddd308e7f433ac079ebd539e587e7a899994aad8eb83ebd81df8c5  /tmp/r375_capacity.md
930aea90f1d8a991090a3d3a4d5c93b8f999e389e8f7d1ca9c2071995199044c  /tmp/r375_ledger.md
384a4ae6f3a1c6611b3ddeb81cd7a4a6c4b5a9b24b0f0ce48d3a0bfd63b2406d  /tmp/r374_geometry.md
fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a  /tmp/r370_geometry.md
```
