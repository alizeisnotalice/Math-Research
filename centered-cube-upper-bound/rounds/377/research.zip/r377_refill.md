# R377 — Using the actual residual target capacity for nonuniform refill

## 1. Frozen data and precise scope

Keep the original full-f hard field, actual receiver dv and du, and the R375/R376 common kernel 0≤K_v(y,z)≤L_v(y)≤B. Every source-dependent J, H, strict-past gate, physical clock and original mark remains at its original y. Let U_v be uniform on the actual Q_v, μ_v^+=d_vP_v, and C=L−K. No pointwise bound on f is assumed.

Freeze the **retained subflow k from R376**, rather than optimizing it again. Suppress v and write

\[
 R(z)=E_Pk(y,z),\quad \beta(y)=1-E_Uk(y,z),\quad
 \delta=E_P\beta,\quad s(z)=2-R(z).
\]

R376 gives R=min(H,a), δ=2−a, 1<a≤2. Therefore

\[
 0\le\beta\le1,\quad0\le\delta<1,\quad
 \boxed{s\ge\delta,\qquad E_Us=1+\delta.} \tag{1}
\]

These are aggregate densities relative to the actual U_v. In particular the old uniform refill β(y)P(dy)U(dz) was feasible. The remaining source measure is ν(dy)=β(y)P(dy), of mass δ; it is not renormalized away in any bill. If d_v=0 all plans and gains for v are zero. If δ_v=0, β_v=0 P_v-almost everywhere, no refill is needed, and all new credits are zero.

The construction below is a genuine feasible plan and an exactly solved stronger **row-cap** refill class. It is not asserted to solve every transport with source ν and target≤sU. A separate weak certificate for that larger problem is given in §6; §4 also gives a strictly larger feasible shared-buffer class.

## 2. A normalized slack reference, with no extra template charge

On δ>0 define

\[
 P_\beta=\beta P/\delta,\quad
 \sigma(dz)=\frac{s(z)}{1+\delta}U(dz),\quad
 t_\delta=\frac{1+\delta}{\delta}.
\]

Both P_β and σ are probabilities. For each source row, take any measurable density ρ_y relative to σ satisfying

\[
 0\le\rho_y\le t_\delta,\qquad E_\sigma\rho_y=1. \tag{2}
\]

Its refill measure ν(dy)ρ_y(z)σ(dz) has the exact source ν and target at most

\[
 \delta t_\delta\sigma=sU. \tag{3}
\]

Adding back the fixed k therefore leaves the full target at most 2U. Multiplication by d_v restores the original surplus plan. Although t_δ can diverge as δ↓0, it acts only on the remaining mass δ, and (3) is exact. **No t_δΓ_n price is introduced.**

A key point specific to the R376 retained subflow is that the old uniform conditional refill is inside this row-cap class:

\[
 \rho_y^{\rm unif}(z)=\frac{1+\delta}{s(z)}\le t_\delta
\]

by (1). Thus optimizing the new row class cannot worsen any source row's actual cost. For an arbitrary retained k with s<δ somewhere, (3) would still be a feasible construction, but this comparison with uniform refill would not follow; condition (1) is retained explicitly.

Use the R375 quantile construction relative to σ: for each y, retain σ-density t_δ on the lowest values of C(y,·), with a fractional density on the cutoff atom so the row integral equals one. Denote the resulting density ρ_y^*. Its exact row cost is

\[
 \boxed{V^*(y)=\int_0^{L(y)}
 \left(1-\frac1\delta\int s(z)1_{\{C(y,z)\le\ell\}}U(dz)\right)_+d\ell.} \tag{4}
\]

For completeness, the threshold is the infimum of c with σ{C≤c}≥1/t_δ. Below it the density is t_δ; on it the density is [1−t_δσ{C<c}]/σ{C=c}, when that atom has positive mass; otherwise no boundary density is needed. C=0 rows are included. Parameterized integration and rational threshold tests make this jointly measurable in (v,y), including the measurable parameter δ_v. Every δ>0 has finite t_δ; no uniform bound is used. The δ=0 case is defined separately as above.

Layer cake gives the lower bound in (4) for every row satisfying (2), and the displayed positive density attains it. Thus this is a direct feasible upper construction with a proof of optimality in its stated row class, without infinite-dimensional strong duality. Strict/non-strict cutoff inequalities only give the same cost after integration in ℓ; the threshold atom allocation itself is indispensable.

## 3. Exact new credit and an explicit computable tilt certificate

Let e(z)=s(z)−δ≥0. It has E_Ue=1. Write F_y(ℓ)=U{C(y,·)≤ℓ}. The old uniform row cost is g(y)=L(y)−E_UK=∫_0^L(1−F_y(ℓ))dℓ. Formula (4) yields the exact nonnegative credit

\[
 \boxed{g(y)-V^*(y)=\int_0^{L(y)}
 \min\left\{U\{C(y,\cdot)>\ell\},
       \frac1\delta\int e(z)1_{\{C(y,z)\le\ell\}}U(dz)\right\}d\ell.} \tag{5}
\]

It uses the actual remaining target capacity overlapping a lower-cost region, and the availability of mass to move away from a higher-cost region. It is strictly positive exactly when these two nonnegative factors are simultaneously positive on a positive-measure set of levels. Integration against the actual remaining source gives

\[
 \Delta_v^{\rm quant}=\int\beta(y)P(dy)[g(y)-V^*(y)]\ge0. \tag{6}
\]

The full fixed-k plan's new bad cost is exactly its old R376 bad cost minus (6). No source mass or old mark is discarded.

There is also a simple explicit certificate that does not require numerically locating every quantile. Set

\[
 r_\sigma(y)=E_\sigma K(y,\cdot),\quad
 M_\delta(y)=\max\{r_\sigma(y),\delta[L(y)-r_\sigma(y)]\}.
\]

When M_δ>0, the row density

\[
 \rho_y^{\rm aff}=1+\frac{K(y,z)-r_\sigma(y)}{M_\delta(y)} \tag{7}
\]

has mean one and lies in [0,1+1/δ]=[0,t_δ]. When M_δ=0 (necessarily L=0), take density one. Its reward is r_σ+Var_σ(K)/M_δ. Therefore the quantile plan satisfies the explicit **net** credit bound

\[
 \boxed{\Delta_v^{\rm quant}\ge
 \int\beta P\left[r_\sigma-r_U+
      \frac{\operatorname{Var}_\sigma K}{M_\delta}\right]_+.} \tag{8}
\]

The baseline change r_σ−r_U has not been omitted. Both the uniform and affine densities satisfy the same row cap (2), so choosing the better of these two per row is legitimate within this stronger class. This is different from arbitrary per-row mixing of plans known only to satisfy an aggregate cap. Integrability is immediate from Var_σK≤r_σ(L−r_σ) and M_δ≥r_σ: the quotient, with zero convention, is at most L≤B. Thus small δ produces no singular price.

## 4. Zero-cost source rows are a shared buffer, with a quantitative credit

The row-proportional cap in §2 can unnecessarily reserve target capacity for sources that cost zero everywhere. This restriction can be removed constructively. Let

\[
 F=\{y:g(y)=0\},\quad A=F^c,\quad
 \delta_F=\int_F\beta\,dP,\quad
 \delta_A=\int_A\beta\,dP=\delta-\delta_F.
\]

Since C≥0, C(y,·)=0 U-almost everywhere on F. These groups and masses are measurable. They concern the actual remaining sources, not an independently sampled replacement of the original f.

If δ_A>0, give every active row the larger cap

\[
 t_A=\frac{1+\delta}{\delta_A}
\]

relative to the same σ, and use the lowest-C quantile construction. Let q_y^A be this conditional density and let

\[
 A_Z(z)=\frac{s(z)}{1+\delta}\int_A\beta(y)q_y^A(z)P(dy)\le s(z).
\]

Its total target mass is δ_A. The remaining capacity S(z)=s(z)−A_Z(z) has integral 1+δ_F. Refill each free row by the common probability

\[
 \frac{S(z)}{1+\delta_F}U(dz). \tag{B1}
\]

The free target mass is δ_F S/(1+δ_F)≤S, and its cost is exactly zero. Both source groups keep their original ν=βP marginal; their union has target≤sU. If δ_A=0, simply refill all remaining sources with σ, at cost zero. If δ_F=0, this is the quantile plan of §2. All constructed target distributions are absolutely continuous relative to U, so the U-almost-everywhere zero-cost statement suffices.

The exact buffer-plan cost is

\[
 Q_{\rm buf}=\int_A\beta(y)P(dy)\int_0^{L(y)}
 \left(1-\frac1{\delta_A}\int s(z)1_{\{C(y,z)\le\ell\}}U(dz)\right)_+d\ell, \tag{B2}
\]

with value zero when δ_A=0. It is at most the previous quantile cost: each active row has a weaker cap than before, and the free rows have zero cost in both plans. Hence this is a genuine same-price improvement, not merely a different formulation of the old row cap.

More quantitatively, put Δ_v^buf=∫βg dP−Q_buf. Since s−δ_A=(s−δ)+δ_F≥δ_F, (5) with δ_A in place of δ gives

\[
 \boxed{\Delta_v^{\rm buf}\ge
 \frac12\min\{1,\delta_F/\delta_A\}
 \int_A\beta(y)P(dy)\,E_{U\otimes U}
             |C(y,z)-C(y,z')|.} \tag{B3}
\]

Use zero on the right if δ_A=0. To prove (B3), at a level ℓ write F_y=U{C≤ℓ}. The exact improvement is at least min(1−F_y,(δ_F/δ_A)F_y), which is at least min(1,δ_F/δ_A)F_y(1−F_y). Finally E|C−C'|=2∫F_y(1−F_y)dℓ. Thus a positive free mass and nonconstant active row costs give a strictly positive, explicit source-weighted dispersion credit **relative to uniform refill**. Formula (B3) is not a lower bound for the improvement over the earlier slack-row quantile plan: that comparison only gives Q_buf≤Q_quant, and its strictness must be checked separately. The finite strict buffer-over-row counts below check that separate exact cost difference, not (B3). No universal ratio to the original cost is asserted.

**Exact optimality with a single active cost profile.** If all active rows have the same cost C_*(z), the active aggregate can be any mass-δ_A submeasure dominated by sU. Every feasible refill therefore costs at least its scalar lowest-C_* bathtub value. The construction above attains it and puts the free sources into the remaining capacity at zero cost. A direct certificate is, for its cutoff c,

\[
 Q_{\rm buf}=c\delta_A-\int s(z)(c-C_*(z))_+U(dz).
\]

For any active aggregate γ_A≤sU of mass δ_A, its cost is at least this value by C_*≥c−(c−C_*)_+. Free cost is zero. Thus the claim uses a feasible plan and an elementary weak certificate, not strong duality. The same-profile assumption is required pointwise outside marginal null sets if comparison includes singular source-target couplings; product-almost-everywhere suffices for density plans, including all constructions here. This solves the stated single-profile conditional refill problem, not the general original field.

**Cheap rather than free rows.** More generally choose a measurable group F_τ on which C(y,z)≤τ for U-almost every z, for a fixed τ≥0. Its measurability can be certified by ∫1{C>τ}dU=0; the stronger simple test L(y)≤τ also suffices. Repeat the active/free allocation above with the remaining sources outside F_τ. The cheap group's actual cost is retained and bounded by τδ_cheap, rather than declared zero. The exact constructed cost is

\[
 Q_{A,\tau}+\int_{F_\tau}\beta(y)P(dy)
       \int C(y,z)\frac{S(z)}{1+\delta_{\rm cheap}}U(dz)
 \le Q_{A,\tau}+\tau\delta_{\rm cheap}. \tag{B4}
\]

Whole-v comparison with the free-buffer plan prevents deterioration. If a positive cheap threshold is chosen globally as τ=ζq_-, its complete added cost is at most

\[
 \tau\int_Ed_v\delta_{{\rm cheap},v}dv
 \le\zeta q_-|E|\le\zeta X_q. \tag{B5}
\]

The target template is still 3Γ. Formula (B5) prices only the cheap rows; it does not pay the remaining active cost Q_{A,τ}. The default τ=0 needs no added X_q fee.

## 5. An independent fixed-target credit and the complete receipt

For the same residual source P_β, let D(y,z) be the doubly centered K under P_β⊗U:

\[
 D=K-E_UK-E_{P_\beta}K+E_{P_\beta U}K.
\]

The refill ν(dy)[1+D/(2B)]U(dz) is nonnegative, has exact source ν and exact target δU≤sU. Its exact additional reward over uniform refill is

\[
 \Delta_v^{\rm dc}=\frac\delta{2B}E_{P_\beta U}D^2\ge0. \tag{9}
\]

This follows from the two zero conditional means and E(KD)=E D². Target control uses its **exact** target marginal; an unsupported pointwise factor bound is not substituted for that cancellation. This candidate need not satisfy the stronger row cap (2). Hence use a finite whole-v choice between the complete free-buffer refill and the complete doubly centered refill, with a fixed measurable tie rule. Its exact gain is

\[
 \Delta_{\rm refill}=\int_Ed_v\max\{\Delta_v^{\rm buf},\Delta_v^{\rm dc}\}\,dv,
 \qquad G_{\rm refill}=G_{\rm priority}-\Delta_{\rm refill}\ge0. \tag{10}
\]

The credits in (B2)–(B3) and (9) are not added on the same residual mass. The retained subflow k is identical for both choices.

The final full surplus plan has source d_vP_v and target≤2d_vU_v. Consequently its floor plus good mass for each original receiver pair is at most min(1,3p−2p²)≤3p. The complete hard-slot ledger is R376's receipt with its positive decomposition rebuilt using G_refill:

\[
 B_H(f,\nu)\le G_{\rm refill}
 +\epsilon_0\left[2+\frac{C_n^++3\Gamma_n}{1+\sqrt n}\right]X_q
 +\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\epsilon_0}
                         +1+\sqrt n\right]W. \tag{11}
\]

Here ν≤f is the original hard-slot source, distinct from the local residual notation ν(dy)=βP used above; W=||f||_1, X_q=∫_E q_u du and C_n^+<72. The original entrance terms, hard-slot multiplier and outer multiplier stay unchanged. All comparisons use the same frozen h and original fields. There is no extra floor, transport, reciprocal-J or negative-square charge.

## 6. A verifiable weak certificate for the larger fixed-k refill problem

For fixed v, any residual transport γ with source ν=βP and target≤sU has reward ∫K dγ. If measurable φ(y), ψ(z) obey

\[
 \psi\ge0,\qquad \phi(y)+\psi(z)\ge K(y,z),\qquad
 \int|\phi|d\nu+\int\psi s\,dU<\infty, \tag{12}
\]

then

\[
 \int K\,d\gamma\le\int\phi\,d\nu+\int\psi s\,dU. \tag{13}
\]

For all possibly singular transports, require the inequality pointwise outside separate ν-null and U-null sets. For transports with density relative to ν⊗U, product-almost-everywhere suffices. This distinction prevents a product-null exceptional set from being charged by a singular coupling.

For a particular feasible γ, the exact certificate gap is

\[
 \int\phi\,d\nu+\int\psi s\,dU-\int K\,d\gamma
 =\int(\phi+\psi-K)d\gamma+\int\psi\,d(sU-\gamma_Z)\ge0. \tag{14}
\]

Both terms vanishing certifies that candidate's optimality among the transports for which (12) holds. No existence of such a sharp certificate or optimizer is asserted. For finite cells, any nonnegative target prices ψ_j and φ_i=max_j(K_ij−ψ_j) give an immediately checkable bound. Equations (4)–(10), in contrast, are already feasible primal improvements and do not rely on obtaining a dual certificate.

The unproved global issue is a root-cost bound on G_refill. Formula (5) gives no uniform lower fraction when the remaining source's favorable target region has too little slack, and (9) can vanish on additive residual kernels. These are not paid by asserting that δ is small or by reusing a terminal/path condition. No iteration at zero additional cost is asserted.

## 7. Three-stage exact local verification

The standard-library script below builds finite atomic R376 retained subflows and then the new refill plans. It checks the slack normalization, variable-cap atom allocation, exact profile (5), affine net credit, fixed-target credit, zero/cheap-source buffer allocation and its dispersion credit, single-active-profile optimality, whole-plan cap, and valid dual gap identities. Its finite kernels are arithmetic diagnostics, not native high-past realizations.

```python
from fractions import Fraction as F
from itertools import product
counts=[0,0,0]
active=[0,0,0]
strict=[0,0,0]
buffer_strict=[0,0,0]
single_profile=[0,0,0]

def water(U,H):
    cuts=sorted(set([F(1),F(2)]+[x for x in H if 1<x<2]))
    for lo,hi in zip(cuts,cuts[1:]):
        low=sum(w for w,x in zip(U,H) if x<=lo)
        high=sum(w*x for w,x in zip(U,H) if x>lo)
        if low:
            a=(2-high)/low
            if lo<=a<=hi:return a
    return F(2)

def take(weights,bounds,score,mass):
    left=mass;k=[F(0)]*len(weights)
    for val in sorted(set(score),reverse=True):
        ids=[i for i,x in enumerate(score) if x==val]
        cap=sum(weights[i]*bounds[i] for i in ids)
        fac=min(F(1),left/cap) if cap else F(0)
        for i in ids:k[i]=fac*bounds[i]
        left-=fac*cap
    assert left==0
    return k

def run(P,U,K,phase):
    nr,nc=len(P),len(U)
    L=[max(row) for row in K]
    rU=[sum(w*x for w,x in zip(U,row)) for row in K]
    g=[L[i]-rU[i] for i in range(nr)]
    C=[[L[i]-K[i][j] for j in range(nc)] for i in range(nr)]
    proposal=[]
    for i in range(nr):
        mask=[C[i][j]<=g[i]/2 for j in range(nc)]
        vol=sum(U[j] for j in range(nc) if mask[j])
        proposal.append([F(int(x))/vol for x in mask])
    H=[sum(P[i]*proposal[i][j] for i in range(nr)) for j in range(nc)]
    a=water(U,H)
    k=[[F(0)]*nc for _ in range(nr)]
    for j in range(nc):
        col=take(P,[proposal[i][j] for i in range(nr)],
                 [K[i][j]-rU[i] for i in range(nr)],min(H[j],a))
        for i in range(nr):k[i][j]=col[i]
    beta=[1-sum(U[j]*k[i][j] for j in range(nc)) for i in range(nr)]
    delta=sum(P[i]*beta[i] for i in range(nr))
    R=[sum(P[i]*k[i][j] for i in range(nr)) for j in range(nc)]
    slack=[2-x for x in R]
    assert delta==2-a and all(x>=delta for x in slack)
    assert sum(U[j]*slack[j] for j in range(nc))==1+delta
    counts[phase]+=2
    if not delta:
        assert all(x==0 for x in beta);counts[phase]+=1
        return
    active[phase]+=1
    Pb=[P[i]*beta[i]/delta for i in range(nr)]
    sig=[U[j]*slack[j]/(1+delta) for j in range(nc)]
    t=(1+delta)/delta
    opt=[];net_aff=F(0);qgain=F(0)
    for i in range(nr):
        rr=take(sig,[t]*nc,K[i],F(1))
        opt.append(rr)
        assert sum(sig[j]*rr[j] for j in range(nc))==1
        assert all(0<=x<=t for x in rr)
        rS=sum(sig[j]*K[i][j] for j in range(nc))
        var=sum(sig[j]*(K[i][j]-rS)**2 for j in range(nc))
        M=max(rS,delta*(L[i]-rS))
        aff=[1+(K[i][j]-rS)/M for j in range(nc)] if M else [F(1)]*nc
        assert all(0<=x<=t for x in aff)
        assert sum(sig[j]*aff[j] for j in range(nc))==1
        gain_aff=rS-rU[i]+(var/M if M else F(0))
        cost=sum(sig[j]*rr[j]*C[i][j] for j in range(nc))
        cuts=sorted(set([F(0),L[i]]+C[i]))
        profile=F(0);value=F(0)
        for lo,hi in zip(cuts,cuts[1:]):
            low=sum(U[j] for j in range(nc) if C[i][j]<=lo)
            e_low=sum(U[j]*(slack[j]-delta) for j in range(nc) if C[i][j]<=lo)
            profile+=(hi-lo)*min(1-low,e_low/delta)
            value+=(hi-lo)*max(F(0),1-low-e_low/delta)
        assert cost==value and g[i]-cost==profile>=max(F(0),gain_aff)
        qgain+=P[i]*beta[i]*profile
        net_aff+=P[i]*beta[i]*max(F(0),gain_aff)
        counts[phase]+=5
    refill=[[beta[i]*opt[i][j]*slack[j]/(1+delta) for j in range(nc)] for i in range(nr)]
    target=[sum(P[i]*refill[i][j] for i in range(nr)) for j in range(nc)]
    assert all(sum(U[j]*refill[i][j] for j in range(nc))==beta[i] for i in range(nr))
    assert all(target[j]<=slack[j] and R[j]+target[j]<=2 for j in range(nc))
    uniformcost=sum(P[i]*beta[i]*g[i] for i in range(nr))
    qcost=sum(P[i]*U[j]*refill[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert uniformcost-qcost==qgain>=net_aff>=0
    counts[phase]+=3
    col=[sum(Pb[i]*K[i][j] for i in range(nr)) for j in range(nc)]
    mean=sum(Pb[i]*rU[i] for i in range(nr))
    D=[[K[i][j]-rU[i]-col[j]+mean for j in range(nc)] for i in range(nr)]
    dc=[[beta[i]*(1+D[i][j]/2) for j in range(nc)] for i in range(nr)] # B=1
    assert all(x>=0 for row in dc for x in row)
    assert all(sum(U[j]*dc[i][j] for j in range(nc))==beta[i] for i in range(nr))
    assert all(sum(P[i]*dc[i][j] for i in range(nr))==delta for j in range(nc))
    dg=delta*sum(Pb[i]*U[j]*D[i][j]**2 for i in range(nr) for j in range(nc))/2
    dcost=sum(P[i]*U[j]*dc[i][j]*C[i][j] for i in range(nr) for j in range(nc))
    assert uniformcost-dcost==dg>=0
    counts[phase]+=4
    def buffer(tau):
        cheap=[max(C[i])<=tau for i in range(nr)]
        da=sum(P[i]*beta[i] for i in range(nr) if not cheap[i])
        df=delta-da
        aa=[[F(0)]*nc for _ in range(nr)]
        if da:
            for i in range(nr):
                if not cheap[i]:
                    den=take(sig,[(1+delta)/da]*nc,K[i],F(1))
                    aa[i]=[beta[i]*den[j]*slack[j]/(1+delta) for j in range(nc)]
        colA=[sum(P[i]*aa[i][j] for i in range(nr)) for j in range(nc)]
        remain=[slack[j]-colA[j] for j in range(nc)]
        out=[[beta[i]*remain[j]/(1+df) if cheap[i] else aa[i][j]
              for j in range(nc)] for i in range(nr)]
        assert all(x>=0 for x in remain) and sum(U[j]*remain[j] for j in range(nc))==1+df
        assert all(sum(U[j]*out[i][j] for j in range(nc))==beta[i] for i in range(nr))
        assert all(sum(P[i]*out[i][j] for i in range(nr))<=slack[j] for j in range(nc))
        cc=sum(P[i]*U[j]*out[i][j]*C[i][j] for i in range(nr) if cheap[i] for j in range(nc))
        ac=sum(P[i]*U[j]*out[i][j]*C[i][j] for i in range(nr) if not cheap[i] for j in range(nc))
        assert cc<=tau*df
        counts[phase]+=4
        if tau==0:
            assert cc==0 and ac<=qcost
            dispersion=sum(P[i]*beta[i]*U[j]*U[l]*abs(C[i][j]-C[i][l])
                 for i in range(nr) if not cheap[i] for j in range(nc) for l in range(nc))
            credit=min(F(1),df/da)*dispersion/2 if da else F(0)
            assert uniformcost-ac>=credit
            profiles=set(tuple(C[i]) for i in range(nr) if not cheap[i] and beta[i]>0)
            if len(profiles)==1:
                prof=list(profiles)[0]
                agg=take(U,slack,[-x for x in prof],da)
                val=sum(U[j]*agg[j]*prof[j] for j in range(nc))
                cut=max(prof[j] for j in range(nc) if agg[j]>0)
                cert=cut*da-sum(U[j]*slack[j]*max(cut-prof[j],F(0)) for j in range(nc))
                assert ac==val==cert
                single_profile[phase]+=1
                counts[phase]+=1
            counts[phase]+=2
        return ac+cc
    bcost=buffer(F(0))
    buffer(F(1,4));buffer(F(1,2))
    bgain=uniformcost-bcost
    if bcost<qcost:buffer_strict[phase]+=1
    for seed in range(3):
        psi=[F((seed+2*j)%5,4) for j in range(nc)]
        phi=[max(K[i][j]-psi[j] for j in range(nc)) for i in range(nr)]
        bound=sum(P[i]*beta[i]*phi[i] for i in range(nr))+sum(U[j]*slack[j]*psi[j] for j in range(nc))
        reward=sum(P[i]*U[j]*refill[i][j]*K[i][j] for i in range(nr) for j in range(nc))
        comp=sum(P[i]*U[j]*refill[i][j]*(phi[i]+psi[j]-K[i][j]) for i in range(nr) for j in range(nc))
        unused=sum(U[j]*psi[j]*(slack[j]-target[j]) for j in range(nc))
        assert bound-reward==comp+unused>=0
        counts[phase]+=1
    if max(bgain,dg)>0:strict[phase]+=1

P=[F(1,3),F(2,3)];U=[F(1,6),F(1,3),F(1,2)]
for K in ([[F(0)]*3]*2, [[F(1)]*3]*2,
          [[F(1),F(0),F(0)],[F(1),F(0),F(0)]],
          [[F(0),F(1),F(0)],[F(0),F(0),F(1)]]):run(P,U,K,0)
for raw in list(product((F(0),F(1,2),F(1)),repeat=6))[:36]:
    run(P,U,[list(raw[:3]),list(raw[3:])],1)
for raw in product((F(0),F(1,2),F(1)),repeat=6):
    run(P,U,[list(raw[:3]),list(raw[3:])],2)
P3=[F(1,6),F(1,3),F(1,2)];U4=[F(1,10),F(1,5),F(3,10),F(2,5)]
for seed in range(97):
    K=[[F((seed*(i+1)+j*j+3*i*j+2*i)%9,8) for j in range(4)] for i in range(3)]
    run(P3,U4,K,2)
print('PASS stages',counts,'total',sum(counts),'positive-delta cases',active,
      'strict refill gains',strict,'strict buffer-over-row gains',buffer_strict,
      'single-profile exact optimality cases',single_profile)
```

Actual execution of the final embedded script: **PASS stages [46, 448, 12615], total 13109 grouped assertions; positive-δ cases [1, 10, 297]; strict refill gains [0, 10, 234]; strict buffer-over-row gains [0, 10, 45]; single-profile exact optimality cases [1, 10, 176].** The stages are four explicit boundary inputs, the first 36 two-by-three profiles, and all 729 two-by-three profiles plus 97 three-by-four profiles. All arithmetic is Fraction arithmetic. The 55 strict buffer-over-row cases confirm an actual improvement of the new shared allocation over the preceding proportional row cap within these finite checks; they do not certify a uniform contraction or native high-past realization.
