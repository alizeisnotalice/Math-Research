# R377 — Joint source occupation in the original reciprocal-J clock

## 1. Exact candidate and scope

All R376 fields are frozen: the actual finite-measure Lebesgue receiver set E, full f≥0 in L¹, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, μ(du)=du/m_u, a≤R_u≤b≤2a, the complete physical clock, original H and strict mass-past gate at h. The mass ratio K>λ/q_- is unchanged. No source density bound is assumed.

For the R375 shared-box plan let 0≤β_v(y)≤1 be its actual lost row mass. Let
U_v=c_v dz/R_v^n, d_vP_v(dy)=(f(y)−q_v)_+c_v(y)dy/m_v,
r_v(y)=E_{U_v}K_v(y,·), and retain the exact R376 L_v. Define
\[
 \Xi=\int_E dv\,d_vE_{P_v}\beta_v,\quad
 E_\xi=\int_E dv\,d_vE_{P_v}[\beta_vr_v],\quad
 D_\xi=\int_E dv\,d_vE_{P_v}[\beta_v(L_v-r_v)].
\]
Thus Dξ+Eξ is exactly the β-weighted original L integral. Eξ is an existing part of this identity, not a second use of a capture-square credit.

The new integral estimate is, for every 0<θ<1,
\[
 \boxed{D_\xi+E_\xi
 \le \lambda\int f(y)(\theta J_b(y)-h)_+\,dy
       +\lambda\log(1/\theta)\Xi
 \le {\lambda\over q_-}\theta X_q+
       \lambda\log(1/\theta)\Xi.} \tag{1}
\]
This is unconditional for the actual β (indeed for every jointly measurable β∈[0,1]). It preserves source matching in the final integration. In particular, for 0<ε<λ/q_-,
\[
 \boxed{D_\xi\le\varepsilon X_q+
 \lambda\log{\lambda\over\varepsilon q_-}\,\Xi-E_\xi.} \tag{2}
\]
It replaces the old dimension-dependent logarithmic coefficient on the lost mass by a dimension-independent coefficient after paying εX_q. It does not establish a root-order bound for λΞ. That remaining requirement is stated in §5.

## 2. A strictly sharper sourcewise joint-rank estimate

Set T_y=J_b(y) and, on f(y)>0,
\[
 a_v(y)=\beta_v(y)\left(1-{q_v\over f(y)}\right)_+,\qquad
 C_y=\int_E a_v(y)c_v(y)\mu(dv).
\]
Set a=C=0 where f=0. Then 0≤C_y≤T_y. Measurability follows from the actual jointly measurable fields and positive Tonelli; no new selection is used.

For 0≤C≤T define Φ_h(T,C)=0 when T≤h, and otherwise
\[
 \Phi_h(T,C)=\int_0^C\log_+{T\over\max(h,s)}\,ds
 =
 \begin{cases}
 C\log(T/h),&C\le h,\\
 C\log(T/C)+C-h,&h<C\le T.
 \end{cases} \tag{3}
\]
The stronger assertion proved below is
\[
 \boxed{D_\xi+E_\xi\le\lambda\int f(y)\Phi_h(T_y,C_y)\,dy.} \tag{4}
\]
For C>h the reduction relative to the separated R376 bound
C log(T/h) is exactly
\[
 C\log(C/h)-C+h\ge0. \tag{5}
\]
Thus the improvement uses the shared receiver occupation C, not just another pointwise L envelope. When C≤h, this relaxation gives no such improvement.

### Original-clock reduction, retaining the actual gates

Write A_uv for the unchanged pair mask times 1−m_v/m_u, so
0≤A_uv≤1_{m_v<m_u/K}. In the actual formula
\[
 L_v(y)=\int_E A_{uv}c_u(y)\,du
 \int_{[R_u,b]}\ell(dr)\,
 {1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}\over J_y(r)},
\]
the atom b^{-n}δ_b is included in ell. As proved in R376,
strict mass past implies J_y(R_u−)>h, and the complete inclusive clock tail is R_u^{-n}. Consequently
\[
 L_v(y)\le\int_E
 {q_uc_u(y)\over J_y(R_u)}
 1_{R_u>R_v}1_{J_y(R_u-)>h}\,\mu(du). \tag{6}
\]
Here R_u>R_v follows from the actual far-mass gate and K>λ/q_-; it is not an added independent-radius assumption. The only losses in (6) are positive domination of old masks, loss factor, and the H indicator, together with J_y(r)≥J_y(R_u). No ω≤1 substitution precedes this step.

For the actual pushforward measure η_y(dR)=∫c_u(y)μ(du)δ_{R_u}(dR), put F(R)=J_y(R), T=F(b). The strict tail version of R376's rank lemma gives, for every R₀,
\[
 \int_{\{R>R_0,\ F(R-)>h\}}{dF(R)\over F(R)}
 \le\log_+{T\over\max\{h,F(R_0)\}}. \tag{7}
\]
A zero-total tail is interpreted as zero. To verify all atom and singular cases, use the generalized inverse Q(s) of F. Lebesgue ds on (0,T) pushes to η, and F(Q(s)−)≤s≤F(Q(s)) almost everywhere. A retained rank has s>h and s≥F(R₀); the integrand is at most 1/s. The strict R>R₀ excludes the entire radius atom at R₀. A first threshold-crossing atom is likewise excluded by the strict-left condition. This proves (7) without a differentiation or continuity assumption.

Use q_u≤λ only now. Multiplying (6) by a_v(y)c_v(y)μ(dv) and applying Tonelli and (7) bounds the joint occupation at y by
\[
 \lambda\int a_v(y)c_v(y)
 \log_+{T\over\max\{h,F(R_v)\}}\,\mu(dv). \tag{8}
\]
The marked radius measure in (8) is dominated by η and has total mass C. On each radius atom its mark can be replaced by its η-average in [0,1]. Under inverse ranks this becomes a function α(s)∈[0,1] with integral C. Since F(Q(s))≥s, (8)/λ is at most
\[
 \int_0^T \alpha(s)\log_+{T\over\max(h,s)}\,ds
 \le\int_0^C\log_+{T\over\max(h,s)}\,ds=\Phi_h(T,C). \tag{9}
\]
The last inequality is the elementary decreasing-kernel filling rule: moving any mark from a higher rank to an unfilled lower rank cannot decrease the integral. Equivalently, layer-cake gives ∫α1_{k>t}≤min(C,|{k>t}|), and integration proves (9). This also covers continuous-singular η and zero C or T.

Finally,
\[
 \int dv\,d_vE_P[\beta_vL_v]
 =\int f(y)\int a_v(y)c_v(y)L_v(y)\mu(dv)\,dy.
\]
This is an identity with the full f; no source/receiver independence is asserted. Together with (8)–(9) it proves (4).

## 3. Exact source matching pays the adjustable first term

For a=log(1/θ), maximizing Φ_h(T,C)−aC over 0≤C≤T gives
\[
 \Phi_h(T,C)\le(\theta T-h)_++\log(1/\theta)C. \tag{10}
\]
Indeed its C-derivative, except at harmless join points, is
log[T/max(h,C)]−a. If θT≤h its maximum is at C=0; otherwise a maximum is at C=θT and has value θT−h. For T≤h both sides are nonnegative and the claim is immediate. This is also a direct calculation from (3).

The two matching identities are exact:
\[
 \int f(y)T_y\,dy=\int_E {f(Q_v)\over m_v}dv=|E|
 \le X_q/q_-,\qquad
 \int f(y)C_y\,dy=\Xi. \tag{11}
\]
Positive Tonelli is justified since the right sides are finite; in particular Ξ≤|E|. Applying (10) in (4) and then (11) proves (1)–(2). The exact first term also equals λθ|E|−λ∫f(y)min{θJ_b(y),h}dy. This last subtraction is already contained in (1); it is not an independent credit to add elsewhere.

A useful second consequence, requiring no tunable parameter, is
Dξ+Eξ≤λ∫f(J_b−h)_+≤(λ/q_-)X_q.
It is weaker than the desired small-coefficient budget and is not presented as closure.

## 4. Full-plan and ledger costs, without double counting

For the same shared-box plan the existing exact good-box bound is
\[
 \operatorname{Bad}(\tau^\Box)
 \le S_\xi+D_\xi,\qquad
 S_\xi=\int dv\,d_vE_P[s_v(y)(1-\beta_v(y))].
\]
Hence the new lawful replacement is
\[
 \operatorname{Bad}(\tau^\Box)
 \le S_\xi+\varepsilon X_q+
 \lambda\log{\lambda\over\varepsilon q_-}\Xi-E_\xi. \tag{12}
\]
The target cap remains the existing cap 2, and the template fee remains 3Γ_n. This proof constructs no extra transport and adds no target-cap fee.

Insert (12), or the tighter (4) with −Eξ, into the same-field ledger
\[
 B_H\le\operatorname{Bad}(\tau)
 +\varepsilon_0\!\left[2+{C_n^++3\Gamma_n\over1+\sqrt n}\right]X_q
 +C_{338}W.
\]
Thus ε adds only to this displayed X_q coefficient. ε₀, h and all original fields can stay fixed when choosing θ. If ε₀ is itself later changed to allocate a requested total coefficient, the h-dependent fields and C338 must be rebuilt consistently. Eξ is subtracted only as part of Dξ=(Dξ+Eξ)−Eξ; it is not added to any previously charged credit. Selecting the best whole-v plan against other cap-2 plans remains valid; arbitrary row-by-row mixing is not claimed.

## 5. Exact unpaid balance and limitations

The genuinely new receipt is the source-integrated joint-rank bound (4) and its dimension-independent tradeoff (1). The remaining balance in (12) is
\[
 S_\xi+
 \lambda\log{\lambda\over\varepsilon q_-}\Xi-E_\xi. \tag{13}
\]
The proof does not bound λΞ by a root-order multiple of W, and does not show that Eξ purchases the entire positive part of (13). Ξ remains the actual shared-target truncation loss. Its trivial bound |E| would leave another order-one X_q coefficient and cannot close an arbitrarily small ε budget.

This is a quantitative improvement of the original integral kernel, not an unconditional general weak-(1,1) root bound. The physical clock, strict past, source-dependent J and original matching have all been used. The spatial outside/not-Bplus constraints remain present in the initial integral and were relaxed positively in (6); a next improvement would have to use their geometry to pay the actual shared loss Ξ or the smaller signed balance (13), rather than count the same rank improvement again.

## 6. Reproducible local checks

The self-contained script is /tmp/r377_geometry_check.py, executed locally on 2026-10-18. It uses Fraction arithmetic and certified lower/upper rational logarithm sums:
log r=2Σ x^(2k+1)/(2k+1), x=(r−1)/(r+1), with the remaining tail bounded by 2x^(2N+1)/[(2N+1)(1−x²)].

Actual output:
PASS {'rank_hardy': 360, 'physical_clock': 432, 'matching_fubini': 100} total 892

Stage 1 verifies the marked joint-rank bound and its θ tradeoff for atomic ranks. Stage 2 verifies the complete finite physical-clock algebra, varying q, tied radii, strict mass past and the H gate, before any relaxation. Stage 3 verifies the exact full-f matching/Fubini identities with nonconstant β and surplus factors. These are algebraic diagnostics; the finite incidence samples are not claimed to be native Lebesgue hard-field examples. Singular-continuous measures are handled by the analytic inverse-rank proof, not by extrapolating the tests. No floating-point fit is used as mathematical evidence.
