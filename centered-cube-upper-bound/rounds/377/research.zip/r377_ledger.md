# R377 完整总账

冻结场和全部原入口沿用R376；旧文档作为依赖附入。新G_refill是保留k及本轮实际共同补流的真实坏费用。floor+good重新按该同一计划分解，目标仍cap2。

M1允许代入
\[
G_{\rm refill}\le S+\varepsilon X_q+
\lambda\log(\lambda/(\varepsilon q_-))\Xi_A-\operatorname{Cap}_A.
\]
Ξ_A保留实际来源失量，Cap_A仅来自该补流在活跃源的实际捕获。零费行以密度计划保证，不能借产品零集假定任意奇异耦合亦零费。S是保留部分真实费；也可用ξG_joint≤ξX_q，但改变ξ必须重建全部proposal及失量。

原入口外乘2Λ后，M1增加2Λε；若用S≤ξX_q再增加2Λξ。默认free阈值0无cheap价。选正阈值τ=ζq_-时另加2Λζ，并保留其active补集。故本槽的显式接收系数至多2Λ(η+ε+ξ+ζ)，ζ默认0。给该槽总预算κ，可例如η=ε=ξ=κ/(6Λ)、ζ=0（κ足够小使ξ<1、ε<λ/q_-）；这只分配本槽，不认证全部其他槽系数总和。

仍须证明剩余λlog(λ/(εq_-))Ξ_A−Cap_A的一般根阶来源付款，或保留S后直接控制完整带符号余额。不得加回uniform扣项或把Φ中的截断负项再计一次。改变ε只改变θ，不改h；改变η即改变ε0和h，全部原门同步。

## 原始入口与全部价格

新floor+good仍≤min(1,3p−2p²)≤3p，故完整硬槽用新的真实剩余替换旧剩余：
\[
B_H(f,\nu)\le G_{\rm refill}+\varepsilon_0[2+(C_n^++3\Gamma_n)/(1+\sqrt n)]X_q+C_{338}W,
\]
\[
C_{338}=\frac\lambda{q_-}\{(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon_0+1+\sqrt n\},\quad C_n^+<72,
\]
\[
\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2),
\quad A_n=1+n\log(b/a),\quad q_-=3\lambda/4.
\]
给定本槽η，仍用原
\[
\mathcal L_n=2+(72+3\Gamma_n)/(1+\sqrt n),\quad
\varepsilon_0=\eta/\mathcal L_n,\quad h=(1+\sqrt n)\mathcal L_n/(\eta q_-).
\]
参数及门全部同步。来源费仍O_η(√(n log(n+2)))W。本轮显式补流不引入新的t倍费用。完整入口为
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{\rm refill}
+2\varepsilon_0[2+(C_n^++3\Gamma_n)/(1+\sqrt n)]X_q+2C_{338}W.
\]
整式乘Λ=128/119；所有已计入G_refill的信用只扣一次。原基础硬槽系数≤2Λη，未认证所有槽总和可吸收。

仍未支付：来源加权拥挤/余项G_refill的一般根阶预算；原入口与soft/crossing接口；合同外重尾、宽距离/低pe/极端尺度比和阈值补集；历史初始/删除跳跃/未来被删来源；H选择、全尺度及来源聚合、外积分、截断与极限。物理末端原子不代替历史原子。有限诊断的类内最优不关闭任何这些槽。
