from fractions import Fraction as F
from itertools import product
counts={'rank_hardy':0,'physical_clock':0,'matching_fubini':0}
def log_bounds(r,N):
    assert r>=1
    x=(r-1)/(r+1); xp=x; lo=F(0)
    for k in range(N):
        lo+=2*xp/(2*k+1); xp*=x*x
    return lo,lo+2*xp/((2*N+1)*(1-x*x))
def certify_phi(value,T,C,h):
    assert 0<=C<=T
    if T<=h or C==0:
        assert value==0; return
    den=max(h,C)
    offset=max(C-h,F(0))
    for N in (8,32,128,512):
        lo,hi=log_bounds(T/den,N)
        if value<=C*lo+offset: return
    raise AssertionError(('Phi',value,T,C,h))
def certify_young(value,T,C,h,theta):
    base=max(theta*T-h,F(0))
    for N in (8,32,128,512):
        lo,hi=log_bounds(1/theta,N)
        if value<=base+C*lo:return
    raise AssertionError(('Young',value,T,C,h,theta))
# Stage 1: atoms with shared radii; arbitrary marked occupation 0<=a<=1.
for n in range(1,7):
 for seed in range(12):
  w=[F(1+(i*3+seed)%7,1+(i+seed)%4) for i in range(n)]
  marks=[F((i*5+seed)%5,4) for i in range(n)]
  T=sum(w); C=sum(x*a for x,a in zip(w,marks))
  for ratio in (F(1,4),F(1,2),F(3,4),F(1),F(2)):
   h=T*ratio; left=F(0); past=F(0); val=F(0)
   for x,a in zip(w,marks):
    right=left+x
    if left>h: val+=x*past/right
    left=right;past+=x*a
   certify_phi(val,T,C,h)
   for theta in (F(1,4),F(1,2),F(3,4)):
    certify_young(val,T,C,h,theta)
   counts['rank_hardy']+=1
# Stage 2: exact original-shape physical clock, q-band, strict mass past.
for dim in (2,3,4):
 for seed in range(24):
  R=[F(1),F(5,4),F(3,2),F(3,2),F(2)]
  q=[F(3+(i+seed)%2,4) for i in range(5)]
  m=[q[i]*R[i]**dim for i in range(5)]
  mu=[F(1+(i*2+seed)%5,4) for i in range(5)]
  cap=[int((i+seed)%4!=0) for i in range(5)]
  a=[F((3*i+seed)%5,4) for i in range(5)]
  T=sum(mu[i]*cap[i] for i in range(5))
  C=sum(mu[i]*cap[i]*a[i] for i in range(5))
  grid=sorted(set(R)); K=F(3,2)
  J=[sum(mu[i]*cap[i] for i in range(5) if R[i]<=r) for r in grid]
  clock=[r**(-dim)-(grid[k+1]**(-dim) if k+1<len(grid) else 0)
         for k,r in enumerate(grid)]
  for hr in (F(1,4),F(1,2),F(3,4)):
   h=T*hr
   for H in (T/3,2*T/3):
    val=F(0)
    for u in range(5):
     zp=sum(mu[v]*cap[v] for v in range(5) if m[v]<m[u]/K)
     if zp<=h:continue
     assert sum(mu[v]*cap[v] for v in range(5) if R[v]<R[u])>h
     inner=sum(clock[k]/J[k] for k,r in enumerate(grid)
               if r>=R[u] and J[k]>=H and J[k]>0)
     for v in range(5):
      if m[v]>=m[u]/K:continue
      A=(1-m[v]/m[u])*F((u+v+seed)%3,2)
      du=mu[u]*m[u]
      val+=mu[v]*cap[v]*a[v]*du*cap[u]*A*inner
    certify_phi(val,T,C,h) # lambda=1
    for theta in (F(1,4),F(1,2)):
     certify_young(val,T,C,h,theta)
    counts['physical_clock']+=1
# Stage 3: full-f matching and Fubini identities; finite incidence algebra.
# These are not claimed to realize the Lebesgue hard-field geometry.
for seed in range(100):
 f=[F(1+(j*3+seed)%9,2) for j in range(7)]
 dy=[F(1+(j+seed)%4,3) for j in range(7)]
 c=[[int((i+j+seed)%4!=0) for j in range(7)] for i in range(5)]
 m=[sum(f[j]*dy[j]*c[i][j] for j in range(7)) for i in range(5)]
 du=[F(1+(i+seed)%5,3) for i in range(5)]
 q=[F(3+(i+seed)%2,4) for i in range(5)]
 mu=[du[i]/m[i] for i in range(5)]
 beta=[[F((2*i+j+seed)%5,4) for j in range(7)] for i in range(5)]
 T=[sum(c[i][j]*mu[i] for i in range(5)) for j in range(7)]
 C=[sum(c[i][j]*mu[i]*beta[i][j]*max(1-q[i]/f[j],F(0))
        for i in range(5)) for j in range(7)]
 xi_direct=sum(du[i]*sum(dy[j]*c[i][j]*max(f[j]-q[i],F(0))*beta[i][j]
                        for j in range(7))/m[i] for i in range(5))
 assert sum(f[j]*dy[j]*T[j] for j in range(7))==sum(du)
 assert sum(f[j]*dy[j]*C[j] for j in range(7))==xi_direct
 assert all(0<=C[j]<=T[j] for j in range(7))
 counts['matching_fubini']+=1
print('PASS',counts,'total',sum(counts.values()))
