from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,sys,platform
import numpy as np
import scipy
from scipy.optimize import linprog

def solve(rows,cols,cost):
 nr,nc=len(rows),len(cols)
 if not nr or not nc:return Q(0),Q(0),[]
 eq=np.zeros((nr+nc,nr*nc))
 for i in range(nr):
  for j in range(nc):eq[i,i*nc+j]=eq[nr+j,i*nc+j]=1
 res=linprog([float(c) for row in cost for c in row],A_eq=eq,b_eq=list(map(float,rows+cols)),bounds=(0,None),method='highs')
 assert res.success
 plan=[Q(float(x)).limit_denominator(10**10) for x in res.x]
 assert all(x>=0 for x in plan)
 assert [sum(plan[i*nc:(i+1)*nc]) for i in range(nr)]==rows
 assert [sum(plan[i*nc+j] for i in range(nr)) for j in range(nc)]==cols
 prim=sum((cost[i][j]*plan[i*nc+j] for i in range(nr) for j in range(nc)),Q(0))
 u=[Q(float(x)).limit_denominator(10**10) for x in res.eqlin.marginals[:nr]]
 v=[Q(float(x)).limit_denominator(10**10) for x in res.eqlin.marginals[nr:]]
 excess=max(Q(0),max(u[i]+v[j]-cost[i][j] for i in range(nr) for j in range(nc)))
 u=[x-excess for x in u]
 assert all(u[i]+v[j]<=cost[i][j] for i in range(nr) for j in range(nc))
 dual=sum(x*y for x,y in zip(u,rows))+sum(x*y for x,y in zip(v,cols))
 return prim,dual,{'rows':list(map(str,rows)),'cols':list(map(str,cols)),'cost':[[str(x) for x in r] for r in cost],'plan':list(map(str,plan)),'u':list(map(str,u)),'v':list(map(str,v))}

base=json.load(open(Path(__file__).with_name('r534_transport_input.json')))
results=[]
for r in base['results']:
 if r['caps']:continue
 N=r['parents'];w=Q(1,4);centers=[tuple(map(Q,c)) for c in r['centers']];radii=list(map(Q,r['radii']))
 boxes=[(tuple(c-R/2 for c in B),tuple(c+R/2 for c in B)) for B,R in zip(centers,radii)]
 axes=[sorted({v[d] for box in boxes for v in box}) for d in [0,1]]
 pats={}
 for i,j in product(range(len(axes[0])-1),range(len(axes[1])-1)):
  x=(axes[0][i]+axes[0][i+1])/2;y=(axes[1][j]+axes[1][j+1])/2
  bits=tuple(l[0]<x<h[0] and l[1]<y<h[1] for l,h in boxes)
  if not any(bits):continue
  pats[bits]=pats.get(bits,Q(0))+(axes[0][i+1]-axes[0][i])*(axes[1][j+1]-axes[1][j])
 bits=list(pats);vol=list(pats.values());P=len(bits);mass=[Q(0)]*P
 for i,m in r['nonzero_primal_masses']:mass[i]=Q(m)
 a=[w/R**2 for R in radii]
 adj=[[False]*N for _ in range(N)]
 for i,j in product(range(N),repeat=2):
  if i==j:continue
  ov=Q(1)
  for d in [0,1]:ov*=max(Q(0),min(boxes[i][1][d],boxes[j][1][d])-max(boxes[i][0][d],boxes[j][0][d]))
  adj[i][j]=2*ov**2<min(radii[i]**2,radii[j]**2)**2
 D=[sum(a[i] for i in range(N) if b[i]) for b in bits]
 h=[[sum(a[j] for j in range(N) if adj[i][j] and b[j]) for b in bits] for i in range(N)]
 F=[sum(a[i]*h[i][s] for i in range(N) if bits[s][i]) for s in range(P)]
 nuplus=[max(Q(0),m-v) for m,v in zip(mass,vol)];numinus=[max(Q(0),v-m) for m,v in zip(mass,vol)]
 A=sum(m*d*d for m,d in zip(mass,D));Gamma=sum((m-v)*f for m,v,f in zip(mass,vol,F));X=w*N
 Jprod=Q(0);Jopt=Q(0);Jdual=Q(0);marg=Q(0);certs=[]
 for i in range(N):
  pp=[s for s in range(P) if bits[s][i] and nuplus[s]];mm=[s for s in range(P) if bits[s][i] and numinus[s]]
  rows=[nuplus[s] for s in pp];cols=[numinus[s] for s in mm];m=sum(rows,Q(0));assert m==sum(cols,Q(0))
  marg+=a[i]*m
  if not m:continue
  costs=[[max(Q(0),h[i][s]-h[i][t])**2/D[s] for t in mm] for s in pp]
  Jprod+=a[i]*sum(rows[u]*cols[v]*costs[u][v]/m for u in range(len(pp)) for v in range(len(mm)))
  primal,dual,cert=solve(rows,cols,costs);Jopt+=a[i]*primal;Jdual+=a[i]*dual
  cert['parent']=i;cert['positive_patterns']=pp;cert['negative_patterns']=mm;certs.append(cert)
 assert Jprod>=Jopt>=Jdual
 assert Gamma<=0 or Gamma**2<=A*Jopt
 G=[Q(0)]*P
 for i in range(N):
  m=sum((nuplus[t] for t in range(P) if bits[t][i]),Q(0))
  if not m:continue
  mean=sum((numinus[t]*h[i][t] for t in range(P) if bits[t][i]),Q(0))/m
  for t in range(P):
   if bits[t][i]:G[t]+=a[i]*mean
 Gamma_drift=sum(nuplus[t]*(F[t]-G[t]) for t in range(P))
 assert Gamma_drift==Gamma
 Jdrift=sum(nuplus[t]*max(Q(0),F[t]-G[t])**2/D[t]**2 for t in range(P))
 assert Jdrift<=Jopt and (Gamma<=0 or Gamma**2<=A*Jdrift)
 result={'J_drift':str(Jdrift),'G':list(map(str,G)),'parents':N,'depth':r['corner_depth'],'patterns':[list(map(int,b)) for b in bits],'volumes':list(map(str,vol)),'source_masses':list(map(str,mass)),'D':list(map(str,D)),'h':[[str(x) for x in v] for v in h],'X':str(X),'A':str(A),'Gamma':str(Gamma),'transport_mass':str(marg),'J_product':str(Jprod),'J_optimal_upper':str(Jopt),'J_optimal_lower':str(Jdual),'exact_gap':str(Jopt-Jdual),'certificates':certs}
 results.append(result)
 print(N,r['corner_depth'],'Jprod/X',float(Jprod/X),'Jopt/X',float(Jopt/X),'gap',str(Jopt-Jdual),'Gamma/X',float(Gamma/X),'Jdrift/X',float(Jdrift/X),flush=True)
out={'scope':'Exact finite weighted receiving-center transport models, source uniform on each union of arrangement cells with the same root membership. All source masses satisfy root equalities. Not actual full Lebesgue receiving set.', 'environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},'results':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
