from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from fractions import Fraction as F
from itertools import combinations, product
from math import isqrt, prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def interval(value):
    return value.str(24)


def total(values):
    return sum(values, F(0))


def triangular_density(t):
    return max(F(0), 1-abs(t))


def triangular_cdf(t):
    if t <= -1:
        return F(0)
    if t < 0:
        return (1+t)**2/2
    if t < 1:
        return 1-(1-t)**2/2
    return F(1)


def d_s(x, S, s, eps, c):
    if not s:
        return (F(1)/(2*S) if -S <= x <= S else F(0))
    right = (S-x)/(eps*s)-c/eps
    left = (-S-x)/(eps*s)-c/eps
    return (triangular_cdf(right)-triangular_cdf(left))/(2*S)


def d_derivative(x, S, s, eps, c):
    right = (S-x)/(eps*s)-c/eps
    left = (-S-x)/(eps*s)-c/eps
    return (triangular_density(left)*(left+c/eps)
            - triangular_density(right)*(right+c/eps))/(2*S*s)


def knots(S, s, eps, c):
    return sorted({face-s*(c+eps*t) for face in (-S, S) for t in (-1, 0, 1)})


def exact_piecewise_integral(function, cuts):
    return total(
        (r-l)*(function(l)+4*function((l+r)/2)+function(r))/6
        for l, r in zip(cuts, cuts[1:])
    )


def moments(S, s, eps, c, lo=None, hi=None):
    edges = knots(S, s, eps, c)
    l = max(lo, edges[0]) if lo is not None else edges[0]
    r = min(hi, edges[-1]) if hi is not None else edges[-1]
    if l >= r:
        return F(0), F(0)
    cuts = sorted({l, r, *(x for x in edges if l<x<r)})
    density_mass = exact_piecewise_integral(lambda x: d_s(x,S,s,eps,c), cuts)
    score_integral = exact_piecewise_integral(lambda x: d_derivative(x,S,s,eps,c), cuts)
    return density_mass, score_integral


def exact_fisher(S, s, eps, c):
    root2 = arb(2).sqrt()
    y = 1/root2
    log_tanh = ((1+y)/(1-y)).log()/2
    I0 = 4*root2*log_tanh
    I2 = 8*(3*log_tanh/root2-arb(2).log()-1)
    return ball(eps/(2*S*s))*(I2+ball((c/eps)**2)*I0)


def fisher_interval(S, s, eps, c, partitions=128):
    lower = F(0)
    upper = F(0)
    shifted = (c/eps)**2
    for j in range(partitions):
        a, b = F(j, partitions), F(j+1, partitions)
        lower += (8*((1-b)**2+shifted)/(2-a*a))*(b-a)
        upper += (8*((1-a)**2+shifted)/(2-b*b))*(b-a)
    return lower*eps/(2*S*s), upper*eps/(2*S*s)


def one_axis():
    reports = []
    evaluations = 0
    for S, s, eps, c in (
        (F(1), F(1), F(1), F(0)),
        (F(2), F(1, 8), F(1, 2), F(0)),
        (F(1), F(1, 2), F(1, 4), F(-3, 4)),
        (F(3, 2), F(3, 2), F(1, 8), F(7, 8)),
        (F(1), F(1, 1024), F(1, 32), F(-31, 32)),
        (F(1), F(7, 8), F(1, 3), F(1, 5)),
    ):
        lo_left, hi_left = (-S-s*(c+eps), -S-s*(c-eps))
        lo_right, hi_right = (S-s*(c+eps), S-s*(c-eps))
        assert lo_left < hi_left <= lo_right < hi_right
        assert knots(S,s,eps,c)[0] == lo_left and knots(S,s,eps,c)[-1] == hi_right
        assert d_s(lo_left,S,s,eps,c) == d_s(hi_right,S,s,eps,c) == 0
        assert d_derivative(lo_left,S,s,eps,c) == d_derivative(hi_right,S,s,eps,c) == 0
        assert d_s((hi_left+lo_right)/2,S,s,eps,c) == 1/(2*S)
        assert d_derivative((hi_left+lo_right)/2,S,s,eps,c) == 0
        for t in (F(-1),F(-3,4),F(-1,8),F(0),F(1,8),F(3,4),F(1)):
            theta, cdf = triangular_density(t), triangular_cdf(t)
            x_left, x_right = (-S-s*(c+eps*t), S-s*(c+eps*t))
            assert d_s(x_left,S,s,eps,c) == (1-cdf)/(2*S)
            assert d_s(x_right,S,s,eps,c) == cdf/(2*S)
            score = theta*(t+c/eps)/(2*S*s)
            assert d_derivative(x_left,S,s,eps,c) == score
            assert d_derivative(x_right,S,s,eps,c) == -score
            if 0<cdf<1:
                factor = theta**2*(1/cdf+1/(1-cdf))
                assert factor == 4/(2-theta**2) <= 4
            evaluations += 2
        weighted_volume, mean_score = moments(S, s, eps, c)
        assert weighted_volume == 1 and mean_score == 0
        assert moments(S,s,eps,c,lo_left,hi_left)[1] == c/(2*S)
        assert moments(S,s,eps,c,lo_right,hi_right)[1] == -c/(2*S)
        integrated = exact_fisher(S,s,eps,c)
        lower, upper = fisher_interval(S,s,eps,c)
        assert ball(lower) < integrated < ball(upper)
        assert integrated < ball(4*(c*c+eps*eps/3)/(eps*S*s)) <= ball(4/(eps*S*s))
        assert integrated < ball(F(8,3)/(eps*S*s))
        reports.append({
            "S": str(S), "s": str(s), "epsilon": str(eps), "c": str(c),
            "support": list(map(str,(lo_left,hi_right))),
            "flat_part": list(map(str,(hi_left,lo_right))),
            "density_mass": str(weighted_volume),
            "score_mean_weighted_by_density": str(mean_score),
            "left_right_score_integrals": [str(c/(2*S)),str(-c/(2*S))],
            "closed_form_scale_fisher": interval(integrated),
            "Fisher_exact_rational_partition_lower": interval(ball(lower)),
            "Fisher_exact_rational_partition_upper": interval(ball(upper)),
            "theorem_axis_Fisher_bound": str(F(8,3)/(eps*S*s)),
        })
    return {"rational_edge_evaluations": evaluations, "examples": reports}


def adaptive_tree():
    eps, S, s = F(1,4), F(1), F(3,4)
    root_c = F(-1,4)
    # On the left read 2 then 3. On the right read 3 then 2.
    branches = (
        (None,F(0), (1,2,3), F(1,2), F(1,4), F(-1,2), F(1,4)),
        (F(0),None, (1,3,2), F(-1,2), F(-1,4), F(1,4), F(-1,2)),
    )
    full_fisher = exact_fisher(S,s,eps,root_c)
    leaf_records = []
    leaf_mass = F(0)
    cross_scores = [F(0)]*3
    score_means = [F(0)]*3
    rank_pairs = tuple(combinations(range(3),2))
    root_partition = [F(0),F(0)]
    for root_low, root_high, order, c_mid, mid_cut, c_left, c_right in branches:
        d_root, q_root = moments(S,s,eps,root_c,root_low,root_high)
        root_partition[0] += d_root
        root_partition[1] += q_root
        full_fisher += ball(d_root)*exact_fisher(S,s,eps,c_mid)
        mid_partition = [F(0),F(0)]
        for left,right,c_last in ((None,mid_cut,c_left),(mid_cut,None,c_right)):
            d_mid,q_mid = moments(S,s,eps,c_mid,left,right)
            mid_partition[0] += d_mid
            mid_partition[1] += q_mid
            d_last,q_last = moments(S,s,eps,c_last)
            assert (d_last,q_last)==(1,0)
            ds, qs = (d_root,d_mid,d_last),(q_root,q_mid,q_last)
            volume = prod(ds)
            leaf_mass += volume
            full_fisher += ball(volume)*exact_fisher(S,s,eps,c_last)
            for rank in range(3):
                score_means[rank] += prod(qs[i] if i==rank else ds[i] for i in range(3))
            for rid,(a,b) in enumerate(rank_pairs):
                cross_scores[rid] += prod(qs[i] if i in (a,b) else ds[i] for i in range(3))
            leaf_records.append({
                "read_order": list(order),
                "centers_read_order": list(map(str,(root_c,c_mid,c_last))),
                "root_range": [str(root_low),str(root_high)],
                "middle_range": [str(left),str(right)],
                "leaf_probability": str(volume),
                "axis_unscaled_subinterval_derivative_integrals": list(map(str,qs)),
            })
        assert mid_partition == [1,0]
    assert root_partition == [1,0] and leaf_mass == 1
    assert score_means == cross_scores == [0,0,0]
    assert full_fisher < ball(8/(eps*S*s))
    return {
        "S": str(S), "s": str(s), "epsilon": str(eps),
        "leaves": leaf_records,
        "mass": str(leaf_mass),
        "conditional_score_means": list(map(str,score_means)),
        "cross_score_terms_12_13_23": list(map(str,cross_scores)),
        "conditional_Fisher_sum": interval(full_fisher),
    }


def actual_multiscale(n):
    S = F(1)
    a = 32*n
    G = isqrt(n)
    assert G**2 == n
    small = tuple(F(x) for x in ("1/128","1/16","1/8","1/4","1/2","3/4","1"))
    assert sorted(set(small)) == list(small)
    big_d = 2**n
    big_v = F(big_d,a**n)
    eps,c = F(1,4),F(-1,2)
    assert F(1,a)+c+eps < 0 and 1-F(1,a)+c-eps >= 0
    assert F(1,a)+small[-1]/a < 1
    lam_big = big_v/(2*G*big_d)
    owners = []
    previous = F(0)
    packing_mass = lam_big
    total_forward = F(0)
    total_reverse = F(0)
    small_owners = F(0)
    for s in small:
        d = (2*s)**n
        v = (d-previous)/a**n
        previous = d
        assert v > 0
        small_owners += v
        # The whole price of each small cube comes from [1-s,1]^n.
        intersection_volume = s**n
        shared_price = big_d*intersection_volume
        m_small = shared_price
        p, q = shared_price/m_small,intersection_volume/d
        assert m_small == d and p == 1 and q == F(1,2**n)
        # This checks the entire actual owner and both extremes of the triangular support.
        min_probe = 1-s/a+s*(c-eps)
        max_probe = 1+s/a+s*(c+eps)
        assert 0 <= min_probe <= max_probe < 1
        lam = v/(4*G*d)
        packing_mass += lam
        assert lam*d <= v/G
        forward = lam_big*v*shared_price/m_small
        reverse = lam*big_v*shared_price/big_d
        assert forward == 2*reverse > 0
        total_forward+=forward
        total_reverse+=reverse
        owners.append({
            "s": str(s), "d_and_m": str(d), "shell_owner": str(v),
            "p_actual_price": str(p), "q_geometric_volume": str(q),
            "p_negative_triangular_probe_every_owner_point": "1",
            "probe_coordinate_support_for_all_owner_points": [str(min_probe),str(max_probe)],
            "lambda": str(lam),
            "Pi_big_to_small": str(forward),
            "Pi_small_to_big": str(reverse),
        })
    assert small_owners == (2*small[-1])**n/a**n
    assert packing_mass < 1 and lam_big*big_d <= big_v/G
    assert ball(big_d) > arb(n).sqrt()
    return {
        "dimension": n, "big_radius": str(S), "large_owner": str(big_v),
        "mu_density_on_0_1_to_n": str(big_d), "M_and_P0": str(big_d),
        "numerical_cap_normalizer_not_global_G": G, "K_for_cap": 1, "large_source_lambda": str(lam_big),
        "owner_shells_disjoint_with_big_and_complete": True,
        "triangular_center_and_width": [str(c),str(eps)],
        "total_packing_load_at_common_interior": str(packing_mass),
        "small_layers": owners,
        "Pi_big_to_small_total": str(total_forward),
        "Pi_small_to_big_total": str(total_reverse),
    }


def deterministic_sweep(n,S,T,levels):
    assert 0 < T <= S
    spacing = T/levels
    step_union = 1 + levels*(1-(1-spacing/(2*S))**n)
    exact_continuous = 1+n*T/(2*S)
    assert 1 < step_union < exact_continuous
    if n<=3 and levels<=6:
        shifts = tuple(spacing*j for j in range(levels+1))
        by_inclusion_exclusion = total(
            (-1)**(j+1)*(2*S-(q[-1]-q[0]))**n
            for j in range(1,len(shifts)+1) for q in combinations(shifts,j)
        )/(2*S)**n
        assert by_inclusion_exclusion == step_union
    return {
        "dimension": n, "S": str(S), "max_s": str(T), "number_of_equal_increments": levels,
        "discrete_sweep_exact_mass": str(step_union), "continuous_sweep_exact_mass": str(exact_continuous),
    }


def interval_density(S,eps,c,a,b,lo_s,hi_s):
    if not lo_s:
        lower_y = a+min(F(0),hi_s*(c-eps))
        upper_y = b+max(F(0),hi_s*(c+eps))
        if -S <= lower_y and upper_y <= S:
            return 1/(2*S),1/(2*S)
        if upper_y<-S or lower_y>S:
            return F(0),F(0)
        return F(0),1/(2*S)
    right = [(S-x)/(eps*s)-c/eps for x,s in product((a,b),(lo_s,hi_s))]
    left = [(-S-x)/(eps*s)-c/eps for x,s in product((a,b),(lo_s,hi_s))]
    lower = max(F(0),triangular_cdf(min(right))-triangular_cdf(max(left)))/(2*S)
    upper = min(F(1),triangular_cdf(max(right))-triangular_cdf(min(left)))/(2*S)
    assert 0 <= lower <= upper <= 1/(2*S)
    for x,s in product((a,(a+b)/2,b),(lo_s,(lo_s+hi_s)/2,hi_s)):
        assert lower <= d_s(x,S,s,eps,c) <= upper
    return lower,upper


def finite_envelope(n,S,eps,mixture,spatial_count,scale_count):
    assert total(weight for weight,_ in mixture)==1
    assert all(len(c)==n and max(map(abs,c))+eps<=1 for _,c in mixture)
    spatial_step = 4*S/spatial_count
    edges = [-2*S+i*spatial_step for i in range(spatial_count+1)]
    scale_step = S/scale_count
    s_ranges = [(F(0),F(0))]+[(i*scale_step,(i+1)*scale_step) for i in range(scale_count)]+[(S,S)]
    centers = sorted({c for _,v in mixture for c in v})
    lookup = {
        (c,i,j): interval_density(S,eps,c,edges[i],edges[i+1],ls,hs)
        for c,i in product(centers,range(spatial_count))
        for j,(ls,hs) in enumerate(s_ranges)
    }
    lval,uval = F(0),F(0)
    for cell in product(range(spatial_count),repeat=n):
        bounds = []
        for j in range(len(s_ranges)):
            lo = total(w*prod(lookup[c,i,j][0] for c,i in zip(v,cell)) for w,v in mixture)
            hi = total(w*prod(lookup[c,i,j][1] for c,i in zip(v,cell)) for w,v in mixture)
            bounds.append((lo,hi))
        lval += max(v[0] for v in bounds)
        uval += max(v[1] for v in bounds)
    low,high = lval*spatial_step**n,uval*spatial_step**n
    theorem = 1+ball(F(8*n,3)/eps).sqrt()
    assert 0 < low <= high and ball(high) < theorem
    # Each scale marginal integrates exactly 1; the envelope therefore also has lower bound 1.
    low = max(F(1),low)
    return {
        "dimension": n, "S": str(S), "epsilon": str(eps),
        "components": [{"weight":str(w),"center_vector":list(map(str,v))} for w,v in mixture],
        "spatial_axis_cells": spatial_count, "scale_intervals": scale_count,
        "continuous_envelope_integral_lower_from_rational_boxes": str(low),
        "continuous_envelope_integral_upper_from_rational_boxes": str(high),
        "continuous_envelope_lower_arb": interval(ball(low)),
        "continuous_envelope_upper_arb": interval(ball(high)),
        "theorem_upper": interval(theorem),
    }


def centered_axis_envelope():
    eps,S = F(1,2),F(1)
    outer = knots(S,S,eps,F(0))
    right_tail = exact_piecewise_integral(
        lambda x: d_s(x,S,S,eps,F(0)), sorted({S,*(x for x in outer if x>S)})
    )
    assert right_tail == eps/12
    return {"epsilon": str(eps), "exact_1d_continuous_envelope_mass": str(1+2*right_tail)}


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    return {
        "schema": "r750-triangular-Fisher-envelope-verification-v1",
        "runtime": {
            "python": platform.python_version(), "python_flint": flint.__version__,
            "python_executable": sys.executable, "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable,"-B",script.name,"--out","verify.json"],
            "rerun_command": [sys.executable,"-B",script.name,"--check","verify.json"],
        },
        "one_axis_triangular_score_and_fisher": one_axis(),
        "real_adaptive_three_axis_tree": adaptive_tree(),
        "exact_1d_centered_envelope": centered_axis_envelope(),
        "actual_complete_multiscale_price_construction": [actual_multiscale(n) for n in (4,16,64)],
        "deterministic_corner_sweep": [
            deterministic_sweep(n,S,T,m) for n,S,T,m in (
                (2,F(1),F(1),4),(3,F(2),F(1),6),(16,F(1),F(1),32),(64,F(2),F(1),64))
        ],
        "continuous_product_or_mixture_envelope_rational_enclosures": [
            finite_envelope(1,F(1),F(1,2),((F(1),(F(0),)),),24,16),
            finite_envelope(2,F(3,2),F(1,4),((F(1),(F(-3,4),F(1,4))),),12,12),
            finite_envelope(3,F(1),F(1,8),
                            ((F(1,3),(F(7,8),F(-1,2),F(0))),
                             (F(2,3),(F(-5,8),F(1,4),F(3,4)))),8,8),
        ],
        "scope": [
            "Rational edges and moments are exact. The closed Fisher integral is enclosed independently by monotone rational rectangle sums.",
            "Tree thresholds and centers are fixed in advance as functions of the already-read coordinates, independently of s.",
            "Multiscale prices and all owner shells use actual coordinates and rational volumes. The test normalizer sqrt(n) fixes explicit coefficients. Scaling those coefficients by sqrt(n)/max(G,sqrt(n)) gives the actual global cap and preserves the ratio of the two tested flows.",
            "Continuous envelope brackets cover all s in [0,S] on every rational spatial cell in dimensions 1 through 3; larger sweep dimensions use exact scalar geometry formulas.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out",type=Path)
    mode.add_argument("--check",type=Path)
    args = parser.parse_args()
    raw = json.dumps(report(),indent=2,sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(raw,encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != raw:
            raise SystemExit("rerun differs from saved JSON")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__ == "__main__":
    main()
