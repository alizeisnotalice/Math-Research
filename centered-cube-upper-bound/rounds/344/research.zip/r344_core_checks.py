"""Exact R344 lemma checks; log-mass measures are algebra diagnostics."""
from fractions import Fraction as F
from itertools import product

def phi(s):
    return max(s-1,F(0))**2/(2*s) if s else F(0)
counts={"atomic_capacity_moment":0,"continuous_capacity_profile":0,"phi_monotonicity":0,"physical_cost":0}
for raw in product((F(0),F(1,2),F(1)),repeat=3):
    if not any(raw): continue
    for q in (F(1),F(2)):
        for shift in (F(0),F(1,3)):
            J=sum(raw); cumulative=F(0); atoms=[]
            for weight in raw:
                if not weight: continue
                cumulative+=weight
                x=max(F(0),q*cumulative-1)+shift
                atoms.append((x,weight))
            # Check at every distinct jump, including repeated positions.
            for x in set(x for x,w in atoms):
                Fx=sum(w for z,w in atoms if z<=x)
                assert Fx<=(1+x)/q
            moment=sum(x*w for x,w in atoms)
            assert moment>=max(q*J-1,F(0))**2/(2*q)
            counts["atomic_capacity_moment"]+=1
# κ=(1/q)δ0+(1/q)1_[0,L]dx has exact lower-bound equality.
for q in (F(1,2),F(1),F(2)):
    for length in (F(0),F(1,2),F(2),F(5)):
        J=(1+length)/q
        moment=length**2/(2*q)
        assert moment==max(q*J-1,F(0))**2/(2*q)
        counts["continuous_capacity_profile"]+=1
points=[F(0),F(1,2),F(1),F(3,2),F(2),F(4)]
for a,b in zip(points,points[1:]):
    assert phi(a)<=phi(b)
    counts["phi_monotonicity"]+=1
for s in (F(1,2),F(1),F(2),F(5)):
    for T in (F(0),F(1),F(3),F(6)):
        if 1+T<=s: continue
        for c in (F(0),F(1,3)):
            t0=max(s-1,F(0))
            assert T>=t0 and c+t0-phi(s)>=0
            endpoint=c+T-phi(s)
            # Exact trapezoid integration for the affine continuous integrand.
            integral=(T-t0)*((c+t0-phi(s))+(c+T-phi(s)))/2
            polynomial=c+T-phi(s)+(T-t0)*(c-phi(s))+(T*T-t0*t0)/2
            assert endpoint+integral==polynomial
            counts["physical_cost"]+=1
print("PASS",counts,"total",sum(counts.values()))
print("These certify the geometric-capacity lemma algebra, not a root traffic budget.")
