"""Exact mechanics checks for occupancy duality and the source truncation fee.
The dimension-free maximal theorem is external, not proved by these tests.
"""
from fractions import Fraction as F
from itertools import product
rows=[(F(-1),F(0),F(1)),(F(0),F(1),F(2))]

def overlap(a,b,c,d):
    return max(F(0),min(b,d)-max(a,c))

def J(y):
    return sum(overlap(a,b,y-R/2,y+R/2)/R for a,b,R in rows)

breaks=sorted({x+sgn*R/2 for a,b,R in rows for x in [a,b] for sgn in [-1,1]})
first=F(0); second=F(0)
for a,b in zip(breaks,breaks[1:]):
    ja,jb=J(a),J(b)
    first+=(b-a)*(ja+jb)/2
    second+=(b-a)*(ja*ja+ja*jb+jb*jb)/3
counts={'first_moment':0,'duality':0,'tail_capacity':0,'fee_scaling':0,'fourth_moment_fee_scaling':0}
assert first==sum(b-a for a,b,R in rows)
counts['first_moment']+=1
for c,d in [(F(-2),F(0)),(F(-1),F(1)),(F(0),F(2)),(F(-1,4),F(3,4)),(F(-3),F(3))]:
    cuts=sorted(set(breaks+[c,d]))
    lhs=sum((min(b,d)-max(a,c))*(J(max(a,c))+J(min(b,d)))/2 for a,b in zip(cuts,cuts[1:]) if max(a,c)<min(b,d))
    rhs=F(0)
    for a,b,R in rows:
        knots=sorted({a,b,*[max(a,min(b,z)) for z in [c-R/2,c+R/2,d-R/2,d+R/2]]})
        for lo,hi in zip(knots,knots[1:]):
            def avg(u): return overlap(c,d,u-R/2,u+R/2)/R
            rhs+=(hi-lo)*(avg(lo)+avg(hi))/2
    assert lhs==rhs
    counts['duality']+=1
for h in [F(1,4),F(1,2),F(3,4),F(1),F(5,4),F(3,2)]:
    measure=F(0)
    for a,b in zip(breaks,breaks[1:]):
        ja,jb=J(a),J(b)
        if min(ja,jb)>=h:
            if max(ja,jb)>h: measure+=b-a
        elif max(ja,jb)>h:
            measure+=(b-a)*(max(ja,jb)-h)/abs(jb-ja)
    assert h*h*measure<=second
    counts['tail_capacity']+=1
for k,eps,q,C2sq in product(range(1,17),[F(1,16),F(119,3072)],[F(3,4),F(3,2)],[F(1),F(4)]):
    n=k*k; h=(1+k)/(eps*q); T=q/(C2sq*eps)
    # A_n<=1+n is an analytic consequence of b/a<=2 and log 2<1.
    coefficient=C2sq*T*(1+n)/(q*q*q*h*h)
    assert coefficient<=eps
    counts['fee_scaling']+=1
for k,eps,q,C43power in product(range(1,17),[F(1,16),F(119,3072)],[F(3,4),F(3,2)],[F(1),F(16)]):
    n=k*k; h=(1+k)/(eps*q); T=q*n/(C43power*eps**3)
    coefficient=C43power*T*(1+n)/(q**5*h**4)
    assert coefficient<=eps
    counts['fourth_moment_fee_scaling']+=1
print({'exact_assertions':sum(counts.values()),'counts':counts,'fixture_integral_J':str(first),'fixture_integral_J_squared':str(second),'status':'passed'})
