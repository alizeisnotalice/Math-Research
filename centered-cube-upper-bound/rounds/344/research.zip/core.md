# R344 — A real-center capacity lower bound for the entropy credit

**Status.** The actual geometry forces a positive lower bound on the R343 entropy cancellation. This is an unconditional estimate of that credit, not a root-order payment for localbad. No source-global near-extremizer assumption or stability assertion is used. The remaining source-global transfer is stated explicitly below.

## Contract and the new estimate

Keep the original hard field, source f, actual du, m_u=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ=du/m, E_r, J_y(r), ell, H, and original G_out. Let A be any fixed measurable large-endpoint set, including localbad. Fix (y,r), write ρ(du)=1_{E_r}c_u(y)μ(du), J=∫ρ, V=∫mρ, and m_0=q_-a^n. Zero rows contribute zero.

Define

    φ(s)=(s−1)_+²/(2s) for s>0,    φ(0)=0.

The actual receiver geometry gives the lower bound

    ∫log(m_u/m_0)ρ(du) ≥ (q_-J−1)_+²/(2q_-).       (1)

Consequently the exact R343 row credit satisfies

    (V/J)∫log(m/m_0)ρ ≥ V φ(q_-J).                   (2)

This uses the genuine mass lower bound m_u≥q_-R_u^n and actual center volume, not a source density assumption or arbitrary matrix model.

## Proof from a real-center cumulative capacity

For t≥m_0 let F_y(t)=∫1_{m_u≤t}ρ(du). If u contributes, then capture implies 2||u−y||∞≤R_u and

    m_u≥q_- max{a,2||u−y||∞}^n,
    2||u−y||∞≤(t/q_-)^(1/n).

Therefore, enlarging only the actual receiver-center set,

    F_y(t)≤∫_{2||u−y||∞≤(t/q_-)^(1/n)}
                 du/[q_- max{a,2||u−y||∞}^n]
           =[1+log(t/m_0)]/q_-.                     (3)

Indeed s=(2||u−y||∞)^n has sublevel volume s. The inner region s≤a^n contributes 1/q_-, and the rest contributes q_-^(-1)log(t/m_0). The physical prefix E_r can only decrease this expression. In particular, independently, the same argument with R_u≤r gives J≤[1+n log(r/a)]/q_-.

Put x=log(m/m_0)≥0. Its cumulative ρ-mass obeys F_x(z)≤(1+z)/q_-. Layer cake, valid also for atoms at x=0 or other mass levels, yields

    ∫xρ =∫_0^∞[J−F_x(z)]dz
          ≥∫_0^{(q_-J−1)_+}[J−(1+z)/q_-]dz
          =(q_-J−1)_+²/(2q_-).

This proves (1), and multiplication by V/J proves (2). No ordering of a countable atom set is required. All moments are finite because m∈[q_-a^n,λr^n].

## Full source integral, high past, and exact costs

Let k=log K. As in R343, the original far traffic obeys kG_out(A)≤Γ_A, where Γ_A retains every original gate and multiplies each retained mass difference by log(m_u/m_v). The high-past gate implies J_y(r)>h: because K>λ/q_-, every v counted in Z_y(m_u/K−) has R_v<R_u≤r. Thus put

    ℛ={(y,r):J_y(r)≥H and J_y(r)>h}.

This is only a source-row enlargement of the original active traffic; it does not alter J. Define the exact positive term and exact cancellation over ℛ by

    Ψ_ℛ=∫ell∫f1_ℛ ∫m log(m/m_0)ρ,
    C_ℛ=∫ell∫f1_ℛ (V/J)∫log(m/m_0)ρ.

Applying (2) gives a proved lower bound for the original cancellation,

    C_ℛ≥B_ℛ:=∫ell∫f1_ℛ V φ(q_-J),
    kG_out(A)≤Ψ_ℛ−C_ℛ≤Ψ_ℛ−B_ℛ.                    (4)

The difference on the right is nonnegative because B_ℛ≤C_ℛ≤Ψ_ℛ. All source integrations use the same original f. No free block allocation is present.

The function φ is increasing: for s>1, φ(s)=s/2−1+1/(2s), with derivative (1−s^(-2))/2≥0. Therefore

    B_ℛ≥φ(q_-h)N_ℛ,
    N_ℛ=∫ell∫f1_ℛ V.                                (5)

The available absolute accounts remain

    0≤N_ℛ≤X_q,
    Ψ_ℛ≤Ψ:=∫E q_u log(m_u/m_0)du
             ≤[log(λ/q_-)+n log(b/a)]X_q.           (6)

The first equality behind (6) is the actual matched identity ∫f c_u=m_u; the physical integral uses the exact inclusive tail ell([R_u,b])=R_u^(-n). Thus all selector atoms and the original b atom are retained. On each row the source envelope is V≤r^n. Equations (4)–(6) debit no new source fee, but they also do not bound Ψ_ℛ−B_ℛ by a root-order source price.

For an explicit source-only account of this method, write s=q_-h, c=log(λ/q_-), T=n log(b/a), and t_0=(s−1)_+. If 1+T≤s, the strict gate J>h is impossible, so G_out(A)=0. Otherwise T≥t_0, and the capacity J≤[1+nlog(r/a)]/q_- and (5) give

    kG_out(A)≤W{c+T−φ(s)
                   +(T−t_0)[c−φ(s)]+(T²−t_0²)/2}. (7)

The terminal term is the actual b atom; the remaining terms integrate c+t−φ(s) over t=nlog(r/a) from t_0 to T. The integrand is nonnegative on the eligible range. For fixed original absorption parameters and large n, (7) still permits an order-n² entropy cost, hence order-n^(3/2)W after division by k=√n. It is not entered as a new payment or an improvement to the main ledger.

## Exact remaining source-global issue

The new credit is weighted by f(y)V_y(r), and depends nonlinearly on the original occupancy J_y(r). The basic source marginal relation is instead ∫fJ_y(r)=|E_r|. A large ratio X_q/W does not, by that identity alone, provide a lower bound for B_ℛ sufficiently close to Ψ_ℛ. In particular, N_ℛ≤X_q is an upper bound and cannot be reversed to use the term φ(q_-h)N_ℛ as a fixed fraction of X_q.

Thus the remaining step is a quantitative relation between the actual source-weighted occupancy/log-mass distribution in (4) and the global ratio X_q/W, preserving both the fV weighting and all omitted-pair credit. No such relation is proved here. Truncating logs does not repair this transfer: on the original far gate the capped logarithm is identically log K, as checked in R343. The result of this bounded task is the geometric credit estimate (1)–(5), together with its honest residual costs (6)–(7), not a source-global near-extremizer payment.

## Verification

The saved Fraction script checks the cumulative-capacity moment inequality, its continuous extremal capacity profile, monotonicity of φ on finite rational arguments, and the exact polynomial integration in (7). These are lemma diagnostics, not claims that every artificial log-mass measure is a realizable cube field and not a localbad traffic simulation. Actual execution details follow below.

`/tmp/r344_core_checks.py` was actually executed with Fraction arithmetic. All 141 check units passed: 104 finite atomic cumulative-capacity/moment cases; 12 continuous-profile equality cases; 5 monotonicity comparisons; and 20 exact physical-cost integration cases, including the zero-width interval when s<1. The atomic log-mass measures are constructed to satisfy the proved cumulative capacity and do not replace the actual cube model in the proof. The continuous profile checks only the algebraic sharpness of that capacity-to-moment step. No new row counterexample, extremizer family, or traffic simulation is introduced. Only this note and its check script are authored; bounded delivery stops here.
