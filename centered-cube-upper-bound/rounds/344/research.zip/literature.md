# R344 / urgent follow-up: dimension-free centered-cube maximal bounds

## Direct primary theorem

Jean Bourgain, “On the Hardy-Littlewood Maximal Function for the Cube,” arXiv:1212.2661v1 (11 Dec 2012), primary PDF: https://arxiv.org/pdf/1212.2661.

- PDF p. 1, equations (1.1)–(1.3): for a convex centrally symmetric body `B ⊂ R^n`, `M_B f(x) = sup_{t>0} |B|^{-1} ∫_B |f(x+ty)| dy`, defined for `f ∈ L^1_loc`; `C_p(B)` is its strong `L^p` operator constant. This is centered averaging over every dilation `tB`, `t>0`.
- PDF p. 3, Theorem: for `B_∞^(n)=[-1/2,1/2]^n`, `C_p(B_∞) ≤ C_p` for all `p>1`. The `C_p` depends on `p` alone, not `n`; the theorem states no explicit numerical value. This directly covers axis-parallel centered cubes at every side length. It applies to arbitrary `f ∈ L^p(R^n)`, including `p=4/3` and `p=2`.
- Scope read: primary PDF abstract and PDF pp. 1–3 (definitions, prior-result context, cube theorem and cube normalization). No proof pages beyond p. 3 were needed to verify this application. The theorem is strong `L^p`, not weak `L^1`.

The introduction separately reports the centered-cube weak-`(1,1)` estimate `C_1(B) ≲ n log n` as Stein–Strömberg and notes that the cited cube lower bounds rule out a dimension-free weak-`(1,1)` constant. Do not infer weak-`(1,1)` control from the strong-`L^p` theorem.

## L2 cross-check

Deleaval–Guédon–Maurey, “Dimension free bounds for the Hardy–Littlewood maximal operator associated to convex sets,” *Ann. Fac. Sci. Toulouse* 27 (2018), PDF: https://www.numdam.org/item/10.5802/afst.1567.pdf. Printed pp. 4–5 define `M_C f(x)=sup_{t>0}|C|^{-1}∫_C|f(x+tv)|dv`. Printed p. 74, Theorem 5.1 attributes to Bourgain `||M_C f||_2 ≤ κ_2 ||f||_2` for every `f ∈ L^2` and every symmetric convex body, with universal `κ_2`. A later proof on printed p. 92 gives explicit nonsharp `κ_2<140`. This confirms the absolute `C_2`; Bourgain’s 2012 primary cube theorem additionally supplies `p=4/3`.

## Application boundary

For any measurable `F ∈ L^(4/3)(R^n)`, the full continuous centered-cube maximal operator obeys `||M_cube F||_(4/3) ≤ C_(4/3)||F||_(4/3)`, with dimension-free constant. The theorem does not itself bound a receiver-dependent selected-radius operator, nor settle how a proof-specific mask or source restriction interacts with the maximal operator; those require a separate domination/adjoint argument.
