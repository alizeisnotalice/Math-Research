# 第344轮完整总账

以第342轮已核验hard槽为入口；不声称本轮重新认证全部历史归约。N04用于逐项费用与误差管理，不提供缺少的几何定理。W_beta=∫f，ν≤f dx，W_nu=ν(Rⁿ)，Xq=∫E q_u du≤X=λ|E|。

原入口保留
\[
T_{\rm entrance}\le8\lambda HW_\beta+2d_{\rm eff}A_nW_\nu/H+2B_H,
\quad A_n=1+n\log(b/a).
\]

令A为第342轮增长坏端点集合，G_res=G_A[(f−T_clip)_+]。原所有场由完整f定义。保持ε=119/3072，η=e^(−√n)。
\[
C_{\varepsilon,n}=\frac\lambda{q_-}
[(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon+1+\sqrt n],
\quad C_{\rm cover,n}=2[1+3\sqrt n+\log(8/3)].
\]

新槽为
\[
B_H\le G_{\rm res}+3\varepsilon X_q+
(C_{\varepsilon,n}+C_{\rm cover,n})W_\beta.
\]
其中2ε是原槽费用，新增ε支付截断来源。它替换旧槽，不能逐轮累计旧定位费。于是
\[
T_{\rm entrance}\le8\lambda HW_\beta+2d_{\rm eff}A_nW_\nu/H
+2G_{\rm res}+6\varepsilon X_q+2(C_{\varepsilon,n}+C_{\rm cover,n})W_\beta.
\]

历史外乘Λ=128/119下，6Λε=1/4；旧4Λε=1/6，新增支出1/12。若历史CZ的1/256属于已认证的同一X账本，总吸收为65/256，余191/256未分配。这个剩余不是其他分支已付款的证据。不同尺度、层、来源参数不可免费求和。

未付项逐项保留：

1. G_res：实际超截断来源与增长坏端点的完整原交通，尚无根阶预算。
2. 一般软密集C_H−S_H、越阈I_H、hard合同之外的质量可比重尾联合交通及其他未嵌入hard项。
3. 宽距离、低pe、极端尺度比及全部阈值补集；高度折扣和逆尺度费用同时保留。
4. 历史初始I_time、删除跳跃J_time、未来被删来源D_time分别留账。物理半径b原子已在A_n中，但不能替代历史时间原子。
5. 后缀P/Phi_next负信用只计一次；原H、物理尺度、分层、来源、外积分及极限费用不自动结清。

core.md新增熵信用为严格几何估计，但其粗来源预算仍达n^(3/2)W，不录为新根阶付款。没有假设任意来源在薄边界上质量小，没有改动共同来源。一般n^(1/2+o(1))上界仍未闭合。
