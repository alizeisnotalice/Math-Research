# R344 — conditional L4 source clipping and exact receiver-dx checks

This file separates a conditional parameter substitution from genuine one-dimensional integration. It does not estimate or certify a universal Bourgain constant from finitely many examples, and does not implement the complete historical selector or a nonempty root high-past branch.

## Conditional parameter receipt

Assume the stated dimension-free norm bound `||J_b||_4 <= C ||1_E/q||_4`, C>=1. With X=integral_E q and q>=qminus,

`integral J_b^4 <= C^4 integral_E q^-4 <= C^4 X/qminus^5`.

For g=min(f,T), `integral_{J_b>h}g <= T |{J_b>h}| <= T integral J_b^4/h^4`. Write An=1+n log2, n=k², qminus=3/4, and set

`h=(1+k)/(epsilon qminus)`, `T=qminus n/(C^4 epsilon^3)`.

Then the conditional source-window coefficient satisfies

`An T C^4/(qminus^5 h^4) = epsilon*n*An/(1+k)^4 <= epsilon`.

The script checks this cancellation exactly, using an outward rational atanh-series enclosure for log2, and verifies `n An_upper <= (1+k)^4`. No floating comparison certifies the inequality. Stages cover n1/4/16, n64/256, and n1024/4096; epsilon is 119/3072, 1/16, or 1/2; C is 1,2,or10. These C values are **substitution diagnostics only**, not certified universal constants. There are 140 rational parameter checks (60/40/40). The payment/epsilon upper coefficient increases from about 0.105821699 at n1 to 0.651695723 at n4096; it is independent of the chosen C after cancellation. This tests algebra, not the underlying maximal theorem.

## Actual positive-volume receiver models

All three models have compact f on [-2,2], total mass4. The source is uniform, or period-one packets with one unit of mass per period:

1. Uniform density1.
2. In each period [j,j+1), density4 on [j,j+1/4), zero elsewhere.
3. In each period, density3 on its first quarter, density1 on its second quarter, zero on the remaining half.

Four periods j=-2,-1,0,1 are retained. The positive-volume disjoint receiver intervals E_i and assigned hard sides R_i are:

| Stage | receiver intervals with assigned R |
|---|---|
|initial|[-1/2,-1/4], R1; [1/4,1/2], R2|
|stress|[-3/4,-1/2], R1; [-1/4,0], R2; [1/4,1/2], R1|
|expanded|[-7/8,-3/4], R1; [-5/8,-1/2], R2; [-1/4,1/4], R1; [1/2,3/4], R2|

These are actual receiver Lebesgue intervals, not quadrature weights. The actual full-source response is q=1 at every receiver: all hard intervals stay inside [-2,2], and intervals of sides 1 and 2 integrate exactly one and two periods. The script independently checks every endpoint of every affine piece of the moving hard response, including source-density breakpoints. Thus q=1 is derived from f, not reset after a source change. Use the actual hard kernel s=0,L=R, so

`J_b(y)=sum_i |E_i intersect [y-R_i/2,y+R_i/2]|/R_i`.

Every breakpoint of this function and of f is retained. J is exactly affine on each piece; the script checks its midpoint value and integrates J^4 by the exact polynomial formula. Level crossings at rational h are solved exactly, including flat J=h pieces, which are excluded from the strict set {J>h}. Clipping replaces only the tested source g; original f,q,J remain frozen.

## Results

Two fresh processes passed **597 exact rational checks**: 140 parameter checks plus actual-model checks 145/150/162. Ordinary decimal conversions are display diagnostics, not counted proofs.

| Model | X=receiver length | max J | exact integral J^4 | decimal |
|---|---:|---:|---:|---:|
|initial|1/2|3/8|1179/81920|0.01439208984|
|stress|3/4|3/8|2997/81920|0.03658447266|
|expanded|1|11/16|464107/2621440|0.17704277039|

The exact first moment integral J=X is also checked. For h in {0,1/16,1/8,1/4,1/2,maxJ}, the code computes Lebesgue |{J>h}| and verifies `h^4 |{J>h}| <= integral J^4`. In all models the strict tail at maxJ is empty. For example at h=1/4, tail volumes are 7/8,23/12,21/16 respectively. The actual original source masses on those tails are 7/8,2,19/16; density is not replaced by tail volume.

For every tail the script integrates g=min(f,T) exactly for T=1/4,1,2,4 and the three n1 substitution thresholds at epsilon119/3072,C1/2/10. It verifies both

`integral_tail g <= T |tail|` and `h^4 integral_tail g <= T integral J^4`,

and separately checks full clipped+residual source mass=4. On the nonuniform expanded model, h=1/4, the original tail source mass 19/16 becomes 11/16 at T=1 or 15/16 at T=2. This is genuine clipping of the original positive-L1 packet densities; the original receiver q and J are unchanged.

At n1 the representative root h=2/(epsilon qminus) is larger than every J in these fields. That original high-past branch is empty. The smaller h levels above test the exact integration and clipping lemma, not a claimed nonempty original root branch. The instance inequalities integral J^4<=C^4 X for C1/2/10 also pass here, but are not used as universal operator evidence.

## Reproduction

The three files `r344_numeric.py`, `r344_numeric_result.json`, and this note are sufficient. Standard library only, no historical /tmp imports or optimizer:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r344_numeric.py
```

The JSON is written beside the script and stores every receiver interval, source density piece, J segment, level-set length, and clipped tail source integral exactly. The universal norm theorem and its applicability are analytic inputs; this finite calculation only checks the parameter chain and the stated actual one-dimensional interfaces.
