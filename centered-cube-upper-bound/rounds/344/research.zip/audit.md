# R344 independent preauthor screen — bounded-source branch via the actual adjoint

Owned only `/tmp/r344_audit.md`; no Git/other-author edits or R344 author proof read for this screen. Fixed original actual hard-matched field, finite receiver E, 0<a<=R_u<=b<=2a, f>=0 in L1, m_u=f(Q_u)=q_uR_u^n, q_-<=q_u<=lambda, original full J, source/past/center/far/H gates and inclusive physical ell. All fields remain frozen when a source component is considered.

## Disposition and independently verified external theorem — PASS

Directly read Jean Bourgain, *On the Hardy-Littlewood maximal function for the cube*, arXiv:1212.2661v1 (2012), printed page3 theorem; definitions(1.1)-(1.2) on printed page1 specify the centered dilate maximal operator. It states a dimension-independent Lp bound for the cube for every FIXED p>1. Source: https://arxiv.org/pdf/1212.2661 (theorem on zero-based PDF page2). Thus p=4/3 is legal; choose one dimension-independent C>=max(1,C_(4/3)). No near-one p(n), uniform limit in p, weak-(1,1) estimate or other body is imported. This audit does not claim an explicit numerical value for C.

## Actual selector and its adjoint, retaining q powers

Define the FROZEN linear selector

 Tphi(u)=1_E(u)R_u^(-n)integral_{Q_u}phi(y)dy.

For signed phi, |Tphi|<=M_cube|phi|. Therefore T:L^(4/3)(source dy)->L^(4/3)(receiver du) has norm<=C. Duality gives T*:L4(receiver du)->L4(source dy) with the same norm. This is the adjoint of the SAME measurable radius selector, not a new optimizing selector depending on phi or y.

Since actual E has finite volume and q>=q_->0, v(u)=1_E(u)/q_u belongs to L4, and its positive kernel adjoint is the ORIGINAL

 J_b(y)=integral_E c_u(y)du/(q_uR_u^n)=T*v(y).

The kernel formula is justified first by nonnegative Tonelli/test functions and then the bounded operator identity. No Lp assumption on the full f is required: f is used to freeze the selector/response, not as the input on which the strong-Lp theorem is invoked. Consequently

 ||J_b||_4^4<=C^4 integral_E q_u^(-4)du
             <=C^4|E|/q_-^4<=C^4X_q/q_-^5.              (1)

The last q_- is needed to replace |E| by X_q/q_-. Omitting it would give the wrong density scaling.

## Original positive source kernel and high-past support

For any fixed measurable original large-endpoint set A, let k_A(y) be the full original G_out source density after integrating its receiver endpoints and physical clock, so G_out(A)[g]=integral g(y)k_A(y)dy. All q,m,J,past/H/far/center fields inside k_A are the original FULL-f fields, fixed independently of g. Positive linearity is only in this outer source component.

The original inner small-endpoint row divided by J is at most m_u. Multiplying by dmu(u) leaves actual du; then

 0<=k_A(y)<=integral ell(dr)|{u in A intersect E_r:y in Q_u}|
            <=integral ell(dr)r^n=A_n,
 A_n=1+nlog(b/a).

This actual receiver-center bound keeps the full terminal b atom and does not bound source density by volume. Further, the original high-past gate implies J_y(r)>h for every contributing pair because K>lambda/q_- places ALL strict mass-past receivers before the large physical radius. Therefore

 k_A(y)=0 unless J_b(y)>h.

No source support or high-J bound is inferred where that gate is absent; H can be arbitrary and is only an additional original restriction.

For any NONNEGATIVE bounded source component0<=g<=T_scalar,

 G_out(A)[g]<=A_n T_scalar |{J_b>h}|
            <= A_n T_scalar C^4X_q/(q_-^5h^4).           (2)

The same inequality holds if the source component is not Lp; its boundedness and the finite high-J support suffice. To use it as an exact original source split one takes g<=f, rather than assigning unrelated input data.

## Exact threshold, source split and replacement ledger

Retain the original h=(1+sqrt(n))/(epsilon q_-), epsilon>0. Choose

 T_scalar=q_- n/(C^4epsilon^3).

Substitution into(2) gives EXACTLY

 G_out(A)[g]<=epsilon*n A_n/(1+sqrt(n))^4 * X_q
              <=epsilon X_q.

The last inequality holds for every integer n>=1: b/a<=2 implies A_n<=1+n, and n(1+n)<=(1+sqrt(n))^4. The constant C is fixed once at p4/3 and is not asserted to be1 or computed by these scalar checks. The threshold has the same density units as f and scales correctly when f,q,lambda are rescaled.

Now g=min(f,T_scalar) and f_hi=(f-T_scalar)_+ give the EXACT common-source decomposition f=g+f_hi. This does not recompute q,m,J,E,source neighborhoods or any history qualification from g or f_hi. In particular the original R342 cover still pays its good receiver branch with the ORIGINAL full W, not a fictitious reduced source mass. On its original bad receiver set,

 G_bad[f]=G_bad[g]+G_bad[f_hi]<=epsilon X_q+G_bad[f_hi].

Thus the inherited R342 hard slot becomes

 BH<=G_bad[f_hi]+3epsilon X_q+(C_338+C_root342)W.

The original entrance factor2 makes this6epsilon X_q; with the inherited epsilon119/3072 and outer128/119 this is1/4, replacing the former same-slot1/6 rather than adding both. If the old CZ1/256 is valid on the SAME authentic outer X ledger, the combined debit is65/256, with191/256 unallocated. No other entrance, soft, scale, chronological or outer fees disappear. The high-density source residual keeps the exact original bad receiver and all original gates.

This is a genuinely paid positive SOURCE branch for arbitrary original f; it is not a general bounded-density assumption on f or a reset of the full input. High-density source mass may be essentially all W, and its original traffic remains unpriced. No global root closure, uniformly favorable tail fraction, free outer aggregation or new source Shannon credit follows.

## Actual bounded tool use and stopping point

Reviewer independently opened the primary arXiv PDF and read its centered-maximal definition and all-fixed-p theorem. Also ran234 exact Fraction parameter-cancellation and threshold inequalities in bounded dimensions/positive q,C,epsilon values, using a valid rational upper bound for log2. All passed. These are scalar diagnostics, not an evaluation of C or a real original traffic/strong-Lp computation. The general adjoint/measure argument is analytical; the cited strong-Lp theorem is an external proved input.

Independent proposition screen PASS. Await author proof and final integration for file-level comparison/binding. Only this audit file was written. No full numeric pipeline or general root certificate is claimed.


## First author comparison — geometry and auxiliary core PASS

Read full `/tmp/r344_geometry.md`, its268-assertion reproduction script, `/tmp/r344_core.md` and its141-unit script after the independent screen. The geometric proof agrees with the independently checked adjoint/truncation receipt. It correctly retains the heterogeneous moment integral_E q^(-p)du before replacing it by X_q/q_-^(p+1), explicitly forbids replacing full-field X_q by X_q(A), and keeps all data frozen from full f. The exact p-dependent threshold and its safe p2/p4 specializations have the correct q and epsilon powers. Its external strong-Lp input is the fixed-exponent centered-cube result independently verified above; finite diagnostics do not purport to prove that theorem or evaluate C_(4/3).

The auxiliary capacity argument is also valid. Actual captured center density is bounded by1/[q_-max(a,2dist)^n], yielding F_y(t)<=[1+log(t/m_0)]/q_- for t>=m_0. Layer cake of x=log(m/m_0) with its inclusive cumulative mass gives the triangular lower moment(q_-J-1)_+^2/(2q_-), including zero-log mass atoms. Multiplication by V/J gives the stated credit V phi(q_-J). The occupancy cap J<=[1+nlog(r/a)]/q_- is in the correct direction and cannot be used as source-density information.

The high-past source-row enlargement R={J>=H,J>h} is positive and leaves original J unchanged. Both exact entropy cancellation and its new lower bound use the SAME original f. Monotonicity of phi and the nonnegative difference Psi_R-B_R are justified. The explicit source-only physical cost includes the terminal c+T-phi(s) and continuous integral from t_0=(s-1)_+; it is zero in the correctly separated impossible-gate case1+T<=s. For s<1,t_00 and phi0, the zero-width continuous interval is handled. The remaining cost can still be order n^(3/2)W after log-K division, so this credit estimate is not registered as a new root payment. The missing fV-weighted source-global transfer is explicitly retained, and N_R<=X_q is not inverted into a lower bound.

The saved geometry fixture consists of actual continuous receiver intervals and compact hard source, with q1, exact piecewise-linear terminal occupancy, integral J=2 and integral J^2=19/12. Its duality and strict-tail measures are integrated at all breakpoints, not sampled; it is not the original high-past target. Core141 are check UNITS of capacity/log-moment/profile/integration algebra, some with additional guards, not141 independent actual cube/source fields. No full pipeline was replayed by the reviewer. Await final main/ledger/numeric scope for archive binding.


## Final literature/analytic input review — PASS at the required fixed exponent

Read `/tmp/r344_literature.md` in full. The theorem needed for this budget is the primary centered-cube fixed-p theorem independently opened/read above; it matches the actual side-R normalized kernel and fixed p'=4/3. No numerical value of C_(4/3), no p depending on n, no uniform near-L1 constant and no weak-L1 estimate is inferred. The literature file's additional L2 cross-check is contextual and is not required for or used as a numerical constant in this final p4 receipt; this audit does not claim a separate derivation of that secondary explicit constant. All published-input dependence remains clearly separated from local finite checks.

## Final numerical code, result and notes — PASS for the declared scope

Read complete `/tmp/r344_numeric.py`, final notes and saved result metadata. The parameter branch conditionally assumes the given universal norm bound and then performs exact arithmetic. Its log2 bounds are outward rational atanh-series bounds. The C=1,2,10 values are substitutions, not certified Bourgain constants; after the correct cancellation the coefficient is independent of that substituted C. The actual original theorem is analytical and external, not inferred from these examples.

The three actual one-dimensional models have positive receiver Lebesgue intervals and compact step sources. Period-one source profiles give original hard q1 on sides1/2; code additionally checks all moving-source-breakpoint locations needed to prove q1 on every affine response segment. It does not reset q from the clipped source. The complete source/receiver breakpoints make J exactly affine on each retained segment. Its fourth moment is integrated by the exact affine-power formula, and strict level sets solve crossings exactly and exclude flat J=h intervals. Source density pieces are retained independently of J breakpoints, so original tail source mass is not confused with its Lebesgue volume.

Clipping only replaces the tested source density by min(f,T); the original response and J remain unchanged. The code checks source split mass with the EXACT excess(f-T)_+, not a fictitious changed input or a source-volume bound. Both clipped tail bounds are proved at diagnostic small h values. The original n1 root h is explicitly larger than the actual maximum J in these fields, so that branch is empty; no nonempty original high-past/full-history stress is claimed. Instance moment inequalities do not certify a universal operator norm. Ordinary decimal conversions are readability only, with all counted comparisons rational.

Parent reports completed fresh numerical597 exact assertions, independently matched by result PASS metadata:140 parameter checks (60/40/40) and457 actual receiver-interval checks (145/150/162). Parent also reports fresh geometry268 exact assertions and core141 exact check UNITS. These total1006 exact check units at the stated scopes, not1006 independent actual fields or a computation of the missing traffic. Core units can contain additional internal capacity guards. The actual geometry fixture and core capacity diagnostics have the limitations already recorded above. Reviewer did not repeat these full pipelines; reviewer's earlier234 independent scalar assertions are not added to the primary count.

## Final main and complete ledger — PASS

Read final `/tmp/r344_main.md` and `/tmp/r344_ledger.md`. The new positive payment is the exact source split ONLY on the original R342 growthbad large endpoints. Endpoint partition comes first; on its bad portion one then splits the outer source f=min(f,T_clip)+(f-T_clip)_+. All original full-f receiver masses, q, J, original growth neighborhoods, high-H, strict global past/mass/center predicates and physical ell remain unchanged. The source-positive kernel is independent of the component being integrated; no requalification from the clipped or excess input occurs.

The paid R342 good endpoints keep the full ORIGINAL source cover cost. It cannot be reduced by pretending that the excess-source field has its own inherited source/receiver contract. The new bad/excess residual is a positive exact remaining part of the same integral, not a renamed entropy deficit. Its high-density source portion may contain nearly all source mass; no favorable tail fraction is asserted.

The hard slot is correctly

 BH<=G_res+3epsilon X_q+(C_epsilon,n+C_cover,n)W_beta,
 G_res=G_A[(f-T_clip)_+].

The inherited entrance factor2 therefore gives6epsilon X_q, while keeping8lambda H W_beta,2d_eff A_n W_nu/H,2G_res and twice the explicit source coefficient. No additional slot-internal lambda H completion or auxiliary-entropy credit is added. W_beta=f and nu<=f refer to the same original hard source/response; the historical entrance is carried as a supplied contract, not entirely re-certified by this round.

Local exact Fraction arithmetic verifies, with epsilon119/3072 and Lambda128/119,

 6Lambda epsilon=1/4,
 4Lambda epsilon=1/6,
 2Lambda epsilon=1/12,
 1/4+1/256=65/256,   1-65/256=191/256.

Thus the new ledger replaces the old slot with an additional1/12 debit relative to the R342/R343 slot; it does NOT add old1/6 and new1/4 as separate slots. The old CZ1/256 combination is explicitly conditional on the authentic SAME-X outer account. There is no free sum over arbitrary leaves, source copies, layers or physical scales. Remaining191/256 is not payment for anything else.

The full unpaid list persists: original joint growthbad/excess-source traffic, general soft dense crossing/post-crossing and other hard branches outside this contraction, wide/extreme scale and low-pe complements, chronological initial/deletion/future-source atoms, suffix credit, source/scale/outer sums and limits. The physical terminal b atom already in A_n is not identified with a historical time atom. The auxiliary real geometric entropy-credit estimate receives NO new root payment, and its unresolved fV-weighted global transfer remains explicit. No claim that only constants/logs remain, or that the general root weak-type theorem is closed, is certified.

## Final byte bindings and disposition

Only this audit file was written by the reviewer. Parent replay reports and saved metadata are distinguished from proof/code inspection and reviewer's own bounded local checks. No redundant whole pipeline, optimizer or TeX/PDF compiler was run by the reviewer. The original contract and R342 cover are bound as unchanged inherited sources; this does not re-certify every historical coefficient. Earlier awaiting statements record preauthor stages and are superseded by this final comparison.

| File | SHA256 |
|---|---|
| /tmp/r344_main.md | `1edc646ce74132a7e3ad1000879ccf487da06f984d3266d61a0b9304a65f9454` |
| /tmp/r344_ledger.md | `f385a3aea7be3d6758219b3d31c96f50c5e2f237050ec51033a57e97d5b58d73` |
| /tmp/r344_geometry.md | `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a` |
| /tmp/r344_core.md | `1399fca57f130f327439be51e6e04995cc03104cf8ce6cc0a8d8c84361906ac0` |
| /tmp/r344_literature.md | `a6795c05ed9c609ed3ceb28ed9b78e0eba57e0ff5df9ea22b53bc5a65673fa62` |
| /tmp/r344_numeric.md | `d9b046ed5ac4fbf6f0c06e5e0a44c334cab368311acd4526c7b7e4f2cdb67b62` |
| /tmp/r344_numeric.py | `198ec73032fd8e0306ad879905a49d621615bb816ba8df941015cdf8dcb7563e` |
| /tmp/r344_numeric_result.json | `3eb6435b538339251126013852c75977dc10c4c9cace5b65e4419b61adabbdfe` |
| /tmp/r344_geometry_checks.py | `1b15db8b110b7c083fe488d20025a8a59a048779b6c9b43e9da2c50d8f94bbcb` |
| /tmp/r344_core_checks.py | `694df15b8fbf0cee7afaa2174f812488b9bd16a50866768f92ee43ca8a648c34` |
| /tmp/r340_core.md | `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90` |
| /tmp/r342_geometry.md | `d8d62f1ad59e894ed936fdd64328e608a1b6b682190dbc3b45aed826571dd983` |

Final disposition: PASS for the fixed-exponent adjoint/source-clipping payment, exact geometric credit, literature applicability, final replacement ledger and evidence scope. No outstanding correction requested. Frozen after final byte bindings; later changes require a new binding. The joint excess-source/growthbad residual and the general global root budget remain unproved.
