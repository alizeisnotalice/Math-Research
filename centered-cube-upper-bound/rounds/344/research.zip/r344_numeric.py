#!/usr/bin/env python3
"""Conditional L4 parameter algebra and exact positive-dx one-dimensional tests."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
from math import isqrt
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def log2_bounds(N=32):
 t=F(1,3);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return lo,lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
def parameter_stage(ns):
 before=sum(C.values());rows=[];lo,hi=log2_bounds();q=F(3,4)
 for n in ns:
  k=isqrt(n);ck('square_dimension_exact',k*k==n);Anlo=1+n*lo;Anhi=1+n*hi
  ck('nAn_upper_root_fourth',n*Anhi<=(1+k)**4)
  for eps in [F(119,3072),F(1,16),F(1,2)]:
   for const in [F(1),F(2),F(10)]:
    T=q*n/(const**4*eps**3);h=F(1+k)/(eps*q);tail_coefficient=const**4/(q**5*h**4);payment_hi=Anhi*T*tail_coefficient
    ck('symbolic_parameter_cancellation',T*tail_coefficient==eps*n/F((1+k)**4))
    ck('conditional_payment_below_epsilon',payment_hi<=eps)
    rows.append(dict(n=n,epsilon=str(eps),C_diagnostic=str(const),qminus=str(q),T=str(T),h=str(h),An_lower=str(Anlo),An_upper=str(Anhi),conditional_payment_per_X_upper=str(payment_hi),payment_over_epsilon_decimal=float(payment_hi/eps),scope='Conditional on the given universal L4 norm bound; C1,2,10 are substitution diagnostics, not certified universal constants.'))
 return dict(dimensions=ns,exact_checks=sum(C.values())-before,rows=rows)

def source(mode):
 if mode=='uniform':return [(F(-2),F(2),F(1))]
 if mode=='one_packet_per_period':profile=[(F(0),F(1,4),F(4)),(F(1,4),F(1),F(0))]
 else:profile=[(F(0),F(1,4),F(3)),(F(1,4),F(1,2),F(1)),(F(1,2),F(1),F(0))]
 return [(a+j,b+j,d) for j in range(-2,2) for a,b,d in profile]
def fmass(src,lo,hi):return sum((max(F(0),min(b,hi)-max(a,lo))*d for a,b,d in src),F(0))
def Jvalue(E,y):return sum((max(F(0),min(b,y+R/2)-max(a,y-R/2))/R for a,b,R in E),F(0))
def int_affine_power(a,b,fa,fb,p):
 # Integral of the exact affine segment. Formula also handles fa=fb without division.
 return (b-a)*sum((fa**(p-j)*fb**j for j in range(p+1)),F(0))/F(p+1)
def level_portion(a,b,fa,fb,h):
 if min(fa,fb)>=h:
  return F(0) if fa==fb==h else b-a
 if max(fa,fb)<=h:return F(0)
 crossing=a+(h-fa)*(b-a)/(fb-fa)
 return b-crossing if fb>fa else crossing-a

def actual_model(name,E,mode):
 before=sum(C.values());src=source(mode);X=sum(b-a for a,b,R in E);W=fmass(src,F(-2),F(2));checks_q=0
 ck('receiver_intervals_disjoint',all(E[i][1]<=E[i+1][0] for i in range(len(E)-1)))
 # All source-moving-boundary breakpoints; hard response affine on each piece.
 for a,b,R in E:
  points=sorted(set([a,b]+[z+sgn*R/2 for lo,hi,d in src for z in [lo,hi] for sgn in [-1,1] if a<z+sgn*R/2<b]))
  for u in points:
   ck('actual_full_source_q_one',fmass(src,u-R/2,u+R/2)==R);checks_q+=1
 points=sorted(set([F(-2),F(2)]+[z+sgn*R/2 for a,b,R in E for z in [a,b] for sgn in [-1,1]]+[z for a,b,d in src for z in [a,b]]))
 segments=[];moment=first=F(0)
 for a,b in zip(points,points[1:]):
  fa=Jvalue(E,a);fb=Jvalue(E,b);mid=(a+b)/2
  ck('J_piecewise_affine_exact',Jvalue(E,mid)==(fa+fb)/2)
  density=next((d for lo,hi,d in src if lo<=mid<=hi),F(0))
  moment+=int_affine_power(a,b,fa,fb,4);first+=int_affine_power(a,b,fa,fb,1);segments.append((a,b,fa,fb,density))
 ck('kernel_first_moment_mass',first==X)
 maximum=max([s[2] for s in segments]+[s[3] for s in segments]);ck('local_J_bounded_by_receiver_volume',maximum<=X)
 thresholds=sorted(set([F(0),F(1,16),F(1,8),F(1,4),F(1,2),maximum]));rows=[]
 Tvalues=[F(1,4),F(1),F(2),F(4)]
 qminus=F(3,4);eps=F(119,3072)
 for const in [F(1),F(2),F(10)]:Tvalues.append(qminus/(const**4*eps**3))
 for h in thresholds:
  volume=F(0);tailf=F(0);clip={T:F(0) for T in Tvalues}
  for a,b,fa,fb,d in segments:
   length=level_portion(a,b,fa,fb,h);volume+=length;tailf+=d*length
   for T in Tvalues:clip[T]+=min(d,T)*length
  ck('exact_strict_levelset_markov',h**4*volume<=moment)
  if h==maximum:ck('maximum_strict_tail_empty',volume==0)
  records=[]
  for T,g in clip.items():
   ck('original_source_clipping_tail',0<=g<=tailf and g<=T*volume)
   if h:ck('clipped_tail_via_fourth_moment',g*h**4<=T*moment)
   fullg=sum((b-a)*min(d,T) for a,b,d in src);fullres=sum((b-a)*max(F(0),d-T) for a,b,d in src)
   ck('source_split_mass_exact',fullg+fullres==W)
   records.append(dict(T=str(T),clipped_source_highJ_mass=str(g),original_source_highJ_mass=str(tailf),T_times_tail_volume=str(T*volume),full_clipped_source_mass=str(fullg),full_residual_source_mass=str(fullres)))
  rows.append(dict(h=str(h),strict_tail_volume=str(volume),h4_tail_volume=str(h**4*volume),source_tail_mass=str(tailf),clipping=records))
 # Original representative n1 h is large: assert empty rather than claim hard-branch stress.
 original_h=F(2)/(eps*qminus);ck('representative_original_n1_highpast_empty',maximum<original_h)
 # Instance-level moment inequality is checked, never promoted to a universal C.
 for const in [F(1),F(2),F(10)]:ck('instance_moment_bound_only',moment<=const**4*X)
 return dict(stage=name,source_mode=mode,source_intervals=[list(map(str,s)) for s in src],receiver_intervals=[list(map(str,s)) for s in E],actual_q='1',X_exact=str(X),W_exact=str(W),J_max=str(maximum),J_fourth_moment_exact=str(moment),J_fourth_moment_decimal=float(moment),J_first_moment_exact=str(first),segments=[list(map(str,s)) for s in segments],original_n1_h=str(original_h),original_n1_high_branch_empty=True,levelsets=rows,exact_checks=sum(C.values())-before,scope='Genuine positive receiver Lebesgue intervals, exact original q1 from full f, hard L=R1 or2. Clipping only changes tested source g; original q/J not recomputed. Not complete original history or a nonempty root branch.')

def main():
 params=[]
 for name,ns in [('initial',[1,4,16]),('stress',[64,256]),('expanded',[1024,4096])]:
  s=parameter_stage(ns);s['name']=name;params.append(s)
 models=[actual_model('initial',[(F(-1,2),F(-1,4),F(1)),(F(1,4),F(1,2),F(2))],'uniform'),actual_model('stress',[(F(-3,4),F(-1,2),F(1)),(F(-1,4),F(0),F(2)),(F(1,4),F(1,2),F(1))],'one_packet_per_period'),actual_model('expanded',[(F(-7,8),F(-3,4),F(1)),(F(-5,8),F(-1,2),F(2)),(F(-1,4),F(1,4),F(1)),(F(1,2),F(3,4),F(2))],'two_level_packet_per_period')]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),conditional_parameter_stages=params,actual_interval_models=models,scope='Conditional symbolic L4 substitution plus true one-dimensional receiver dx calculations. No universal C is estimated/certified. Original n1 highpast branch empty; lower diagnostic levels not root claims. All integral comparisons rational; display floats only.')
 (BASE/'r344_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),parameter_counts=[s['exact_checks'] for s in params],actual_model_counts=[m['exact_checks'] for m in models]),sort_keys=True))
if __name__=='__main__':main()
