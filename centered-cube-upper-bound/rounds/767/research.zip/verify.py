"""R767 finite rooted triangular Hall budget and genuine truncated-distance sets."""

import argparse
from collections import defaultdict, deque
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version


def interval(c,r):
    return c-r,c+r


def intersect(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def contains(I,x):
    return I[0]<=x<=I[1]


def endpoints(intervals):
    return sorted({x for I in intervals for x in I})


def active_atoms(sets,density,mu):
    edges = endpoints([*sets,*[P for P,w in density]])
    return [((a,b),mu((a,b)),tuple(j for j,I in enumerate(sets) if contains(I,(a+b)/2)))
            for a,b in zip(edges,edges[1:])]


def input_model():
    A = [(Q(-2),Q(1)),(Q(-1),Q(2))]
    density = [((Q(-3),Q(3)),Q(1)),((Q(-7,4),Q(-5,4)),Q(4)),
               ((Q(1,2),Q(3,2)),Q(2))]

    def mu(I):
        return sum(w*length(intersect(I,P)) for P,w in density)

    return A,density,mu


def fractional_allocation(atoms,demand,sets,mu):
    # Edmonds--Karp with exact rational residual capacities.
    source,offset,sink = 0,1+len(demand),1+len(demand)+len(atoms)
    capacities = defaultdict(Q)
    graph = [[] for _ in range(sink+1)]

    def arc(x,y,capacity):
        capacities[x,y] = capacity
        graph[x].append(y)
        graph[y].append(x)

    total = sum(demand)
    for i,w in enumerate(demand):
        arc(source,i+1,w)
    for j,(_,mass,M) in enumerate(atoms):
        arc(offset+j,sink,mass)
        for e in M:
            arc(e+1,offset+j,total)
    residual = capacities.copy()
    augmentations = 0
    actual = Q(0)
    while True:
        parent = {source:None}
        queue = deque([source])
        while queue and sink not in parent:
            x = queue.popleft()
            for y in graph[x]:
                if y not in parent and residual[x,y]>0:
                    parent[y] = x
                    queue.append(y)
        if sink not in parent:
            break
        route = []
        y = sink
        while y!=source:
            x = parent[y]
            route.append((x,y))
            y = x
        w = min(residual[x,y] for x,y in route)
        for x,y in route:
            residual[x,y]-=w
            residual[y,x]+=w
        actual+=w
        augmentations+=1
    assert actual==total
    assigned = [Q(0)]*len(demand)
    cuts = []
    for j,((lo,hi),mass,M) in enumerate(atoms):
        if not mass:
            continue
        cursor = lo
        local_density = mass/(hi-lo)
        used = Q(0)
        for e in M:
            amount = capacities[e+1,offset+j]-residual[e+1,offset+j]
            assert amount>=0
            if amount:
                right = cursor+amount/local_density
                assert lo<=cursor<right<=hi and contains(sets[e],cursor) and contains(sets[e],right)
                assert mu((cursor,right))==amount
                cuts.append([e,str(cursor),str(right),str(amount)])
                cursor = right
                assigned[e]+=amount
                used+=amount
        assert used<=mass
    assert assigned==demand
    return {"total_allocated":str(actual),"augmentations":augmentations,"pieces_edge_endpoints_mass":cuts,
            "assigned":list(map(str,assigned))}


def hall_audit():
    A,price,mu = input_model()
    parents = range(len(A))
    m = [mu(I) for I in A]
    z = (Q(-3,4),Q(1,4),Q(3,4))
    s = (Q(1,8),Q(1,4),Q(3,8))
    k = [interval(x,r) for x,r in zip(z,s)]
    assert all(contains(A[t],x) and contains(K,x) for x,K in zip(z,k) for t in parents)
    all_parents = A+k
    E = [interval((x+y)/2,(y-x)/64) for x,y in all_parents]
    assert all(length(intersect(X,Y))==0 for X,Y in combinations(E,2))
    assert all(mu(P)>=length(P) for P in all_parents)
    a = [length(E[t])/m[t] for t in parents]
    beta = [Q(1,4),Q(1,2),Q(1,4)]
    v_proxy = [Q(1),Q(3),Q(5)]
    dirs = ["small_source","small_receiver","small_source"]
    hats = [Q(1),Q(3,4)]
    pi = []
    for direction in dirs:
        raw = a if direction=="small_source" else [u*v for u,v in zip(a,hats)]
        pi.append([value/sum(raw) for value in raw])
    assert sum(beta)==1 and all(sum(p)==1 for p in pi)
    edge = list(product(range(len(z)),parents))
    C = [A[0],A[1],(Q(-1),Q(1,2)),(Q(-1,2),Q(3,4)),
         (Q(-1,2),Q(1,2)),(Q(-1,4),Q(1,4))]
    assert all(intersect(C[e],A[t])==C[e] for e,(i,t) in enumerate(edge))
    p0 = min(mu(C[e])/m[t] for e,(i,t) in enumerate(edge))
    assert 0<p0<=1
    q = [beta[i]*pi[i][t]*v_proxy[i] for i,t in edge]
    e_scale = [s[i] for i,t in edge]
    eta_table = {
        (e,j):sum(pi[j][u]*v_proxy[j]*mu(intersect(C[e],A[u])) for u in parents)/m[t]
        for e,(i,t) in enumerate(edge) for j in range(len(z))
    }
    eta = max(value for (e,j),value in eta_table.items() if s[j]<=e_scale[e])
    reverse_pressure = eta_table[0,2]
    assert e_scale[0]<s[2] and reverse_pressure>eta>0
    atoms = active_atoms(C,price,mu)
    for e in range(len(edge)):
        assert mu(C[e])==sum(mass for _,mass,M in atoms if e in M)
    kernel = {(e,f):q[e]*q[f]*mu(intersect(C[e],C[f])) for e,f in product(range(len(edge)),repeat=2)}
    all_subset = []
    worst_ratio = Q(0)
    for size in range(1,len(edge)+1):
        for I in combinations(range(len(edge)),size):
            cell_quad = sum(mass*sum(q[e] for e in I if e in M)**2 for _,mass,M in atoms)
            actual = sum(kernel[e,f] for e,f in product(I,repeat=2))
            ordered = sum(kernel[e,f] for e,f in product(I,repeat=2) if e_scale[f]<=e_scale[e])
            reversed_order = sum(kernel[e,f] for e,f in product(I,repeat=2) if e_scale[f]>=e_scale[e])
            ties = sum(kernel[e,f] for e,f in product(I,repeat=2) if e_scale[f]==e_scale[e])
            raw = sum(q[e]*m[edge[e][1]] for e in I)
            for e in I:
                actual_row = sum(kernel[e,f] for f in I if e_scale[f]<=e_scale[e])
                relaxed_row = q[e]*m[edge[e][1]]*sum(beta[j]*eta_table[e,j] for j in range(len(z))
                                                     if s[j]<=e_scale[e])
                assert actual_row<=relaxed_row<=eta*q[e]*m[edge[e][1]]
            assert cell_quad==actual==ordered+reversed_order-ties and ordered==reversed_order
            assert actual<=2*ordered<=2*eta*raw
            integral = sum(q[e]*mu(C[e]) for e in I)
            union = sum(mass for _,mass,M in atoms if any(e in M for e in I))
            assert p0*raw<=integral and integral**2<=union*actual
            demand_sum = raw*p0*p0/(2*eta)
            assert demand_sum<=union
            all_subset.append((I,raw,actual,ordered,ties,union,demand_sum))
            worst_ratio = max(worst_ratio,actual/(2*eta*raw))

    demand = [q[e]*m[t]*p0**2/(2*eta) for e,(i,t) in enumerate(edge)]
    flow = fractional_allocation(atoms,demand,C,mu)
    assert len(all_subset)==2**len(edge)-1
    I,raw,actual,ordered,ties,union,demand_sum = all_subset[-1]
    return {
        "parents":[list(map(str,I)) for I in A],"real_small_root_z":list(map(str,z)),
        "small_root_s":list(map(str,s)),"root_directions":dirs,
        "beta":list(map(str,beta)),"v_finite_proxy":list(map(str,v_proxy)),
        "pi_actual_parent_posteriors":[list(map(str,p)) for p in pi],
        "m_t":list(map(str,m)),"edge_root_and_parent":edge,"q":list(map(str,q)),
        "continuous_C_e":[list(map(str,I)) for I in C],"p0":str(p0),
        "eta":str(eta),"reverse_unallowed_row_average":str(reverse_pressure),
        "all_nonempty_I_checked":len(all_subset),"max_ratio_quad_over_2_eta_raw":str(worst_ratio),
        "full_I_quad_ordered_ties_raw_union_demand":list(map(str,(actual,ordered,ties,raw,union,demand_sum))),
        "exact_Hall_allocation":flow,
        "actual_unnormalized_H":actual_H(A,C,edge,s,pi,v_proxy,m,eta,p0,atoms,mu),
    }


def reverse_row_pressure():
    A = [(Q(-1),Q(1)),(Q(-3),Q(5))]
    C = [A[0],(Q(-1,2),Q(1,2))]
    roots = [interval(Q(-1,4),Q(1,8)),interval(Q(1,4),Q(1,4))]
    E = [interval((a+b)/2,(b-a)/64) for a,b in A+roots]
    assert all(length(intersect(I,J))==0 for I,J in combinations(E,2))
    assert all(contains(P,(K[0]+K[1])/2) for P,K in zip(A,roots))

    def mu(I):
        return length(intersect(I,(Q(-4),Q(6))))+4*length(intersect(I,(Q(2),Q(4))))

    m = list(map(mu,A))
    q = (Q(1,2),Q(5))  # Two roots with beta=1/2, single-label posteriors, and proxies 1,10.
    v = (Q(1),Q(10))
    eta = max(v[j]*mu(intersect(C[e],A[j]))/m[e] for e in range(2) for j in range(e+1))
    actual_reverse = q[1]*mu(intersect(*C))/m[0]
    assert eta==1 and actual_reverse==Q(5,2)>eta
    actual_quad = sum(q[i]*q[j]*mu(intersect(C[i],C[j])) for i,j in product(range(2),repeat=2))
    raw = sum(w*mj for w,mj in zip(q,m))
    assert actual_quad==Q(61,2)<2*eta*raw
    return {"eta":str(eta),"actual_strict_reverse_row_without_equal_scale":str(actual_reverse),
            "quad":str(actual_quad),"right_hand_side":str(2*eta*raw)}


def concentration_set(I,s,ball_cut,mass_cut,density,mu):
    radius = s*ball_cut  # In 1D, D_s<=ball_cut<1 is an ordinary interval.
    den = mu(I)
    breaks = endpoints([I]+[intersect(I,P) for P,w in density if length(intersect(I,P))])
    cuts = sorted({*I}|{x+sign*radius for x in breaks for sign in (-1,1) if contains(I,x+sign*radius)})

    def center_mass(x):
        return mu(intersect(I,interval(x,radius)))/den

    kept = []
    for a,b in zip(cuts,cuts[1:]):
        left,right = center_mass(a),center_mass(b)
        assert center_mass((a+b)/2)==(left+right)/2
        if left<=mass_cut and right<=mass_cut:
            kept.append((a,b))
        elif (left<=mass_cut)!=(right<=mass_cut):
            root = a+(b-a)*(mass_cut-left)/(right-left)
            assert a<=root<=b and center_mass(root)==mass_cut
            kept.append((a,root) if left<=mass_cut else (root,b))
    return kept,center_mass


def nested_audit():
    A,density,mu = input_model()
    points = [(Q(0),Q(0)),(Q(3,8),Q(1,2)),(Q(1),Q(-3,4)),(Q(9,8),Q(1,8))]
    scales = (Q(1,2),Q(3,4),Q(1))
    ball_cut,mass_cut = Q(1,2),Q(1,4)

    def D_s(x,y,s):
        return sum(min(Q(1),abs(a-b)/s) for a,b in zip(x,y))

    checks = 0
    for x,y,z in product(points,repeat=3):
        values = [D_s(x,y,s) for s in scales]
        assert values==sorted(values,reverse=True)
        for s in scales:
            assert D_s(x,z,s)<=D_s(x,y,s)+D_s(y,z,s)
            checks+=1
    result = []
    for t,I in enumerate(A):
        outputs = [concentration_set(I,s,ball_cut,mass_cut,density,mu) for s in scales]
        regions = [sets for sets,test in outputs]
        edges = endpoints([I]+[J for region in regions for J in region])
        reps = edges+[(a+b)/2 for a,b in zip(edges,edges[1:])]
        for x in reps:
            flags = [any(contains(J,x) for J in M) for M in regions]
            assert flags==[test(x)<=mass_cut for sets,test in outputs]
            assert flags==sorted(flags,reverse=True) and any(flags)==flags[0]
        masses = [sum(mu(J) for J in sets) for sets in regions]
        union = sum(mu((a,b)) for a,b in zip(edges,edges[1:]) if any(
            contains(J,(a+b)/2) for region in regions for J in region
        ))
        assert 0<union==max(masses)<sum(masses) and masses[0]>masses[-1]
        concentration_once = sum(mu((a,b)) for a,b in zip(edges,edges[1:]) if any(
            not any(contains(J,(a+b)/2) for J in region) for region in regions
        ))
        concentration_masses = [mu(I)-mass for mass in masses]
        assert 0<concentration_once==max(concentration_masses)<sum(concentration_masses)
        result.append({"parent":t,"C_mu_for_increasing_s":list(map(str,masses)),
                       "C_intervals":[[list(map(str,J)) for J in M] for M in regions],
                       "pay_once_parent_union":str(union),"would_be_per_scale_sum":str(sum(masses)),
                       "concentration_complement_union_paid_once":str(concentration_once),
                       "concentration_complement_per_scale_sum":str(sum(concentration_masses))})
    return {"triangle_checks":checks,"s":list(map(str,scales)),
            "finite_proxy_ball_cut":str(ball_cut),"finite_proxy_mass_cut":str(mass_cut),"parents":result}


def actual_H(A,C,edge,s,pi,v_proxy,m,eta,p0,atoms,mu):
    M = [Q(1),Q(2),Q(3)]
    label = {pair:e for e,pair in enumerate(edge)}
    J = [M[i]*pi[i][t] for i,t in edge]
    q = [J[e]/m[t] for e,(i,t) in enumerate(edge)]
    H = [Q(0)]*len(edge)
    comparisons = []
    for e,(i,t) in enumerate(edge):
        for j in range(len(s)):
            if s[j]>s[i]:
                continue
            Lam = [u for u in range(len(A)) if pi[j][u]>0 and (B := intersect(A[u],A[t]))[0]<=B[1]]
            assert len(Lam)==len(A)  # The two true parents have positive overlap.
            K = sum(pi[j][u]*mu(intersect(C[e],C[label[j,u]]))/(m[t]*m[u]) for u in Lam)
            first = sum(pi[j][u] for u in Lam)/m[t]
            second = eta*max(1/(v_proxy[j]*m[u]) for u in Lam)
            assert 0<K<=min(first,second)
            H[e]+=M[j]*min(first,second)
            comparisons.append([e,j,str(K),str(first),str(second)])
    assert any(Q(first)<Q(second) for e,j,k,first,second in comparisons)
    assert any(Q(first)>Q(second) for e,j,k,first,second in comparisons)
    checks = []
    for h in sorted(set(H)):
        I = [e for e,h_e in enumerate(H) if h_e<=h]
        mass = sum(J[e] for e in I)
        union = sum(w for _,w,active in atoms if any(e in active for e in I))
        linear = sum(q[e]*mu(C[e]) for e in I)
        quadratic = sum(w*sum(q[e] for e in I if e in active)**2 for _,w,active in atoms)
        pair_quad = sum(q[e]*q[f]*mu(intersect(C[e],C[f])) for e,f in product(I,repeat=2))
        ordered = sum(q[e]*q[f]*mu(intersect(C[e],C[f])) for e,f in product(I,repeat=2)
                      if s[edge[f][0]]<=s[edge[e][0]])
        for e in I:
            i,t = edge[e]
            row = sum(q[f]*mu(intersect(C[e],C[f]))/m[t] for f in I if s[edge[f][0]]<=s[i])
            assert row<=H[e]<=h
        assert p0*mass<=linear and linear**2<=union*quadratic
        assert quadratic==pair_quad<=2*ordered<=2*h*mass
        assert p0**2*mass**2<=2*h*union*mass
        checks.append({"h":str(h),"I":I,"J_I":str(mass),"union_price":str(union),
                       "Phi_linear":str(linear),"Phi_quadratic":str(quadratic),
                       "p0_squared_J_squared":str(p0**2*mass**2),
                       "two_h_union_times_J":str(2*h*union*mass)})
    assert len(checks)>=3 and Q(checks[-1]["J_I"])==sum(M)==6
    return {"M_unnormalized_finite_proxy":list(map(str,M)),"edge_J":list(map(str,J)),
            "H_e":list(map(str,H)),"K_and_two_bounds":comparisons,
            "actual_H_threshold_checks":checks,"scope":"Full Phi on each H subflow, independent of the scale split."}


def scale_split_audit():
    t = [(Q(1,8),Q(1,2)),(Q(-1,4),Q(1)),(Q(1,2),Q(2)),(Q(-1),Q(4))]
    k = interval(Q(0),Q(1,16))
    A = [interval(y,s) for y,s in t]
    E = [interval((I[0]+I[1])/2,length(I)/64) for I in [k,*A]]
    assert all(length(intersect(I,J))==0 for I,J in combinations(E,2))
    assert all(intersect(k,I)==k for I in A)
    left,right = (k[0],Q(0)),(Q(0),k[1])
    density = [((Q(-8),Q(8)),Q(1)),(left,Q(2)),(right,Q(1))]

    def mu(I):
        return sum(w*length(intersect(I,P)) for P,w in density)

    d = [length(I) for I in [k,*A]]
    m = [mu(I) for I in [k,*A]]
    v = list(map(length,E))
    a = [vol/mj for vol,mj in zip(v,m)]
    assert all(mj>dj for mj,dj in zip(m,d))
    G,K = Q(65,32),Q(4)
    hats = [Q(1),Q(1),Q(1,2),Q(3,4),Q(1,4)]
    w = [K*ct*g/G for ct,g in zip(hats,a)]
    assert sum(w)<=1
    labels = range(len(A))
    plus = [w[0]*a[j+1]*(mu(left)+Q(j+2,5)*mu(right)) for j in labels]
    minus = [w[j+1]*a[0]*(Q(1,2)*mu(left)+mu(right)) for j in labels]
    assert all(p>0 and q>0 and p!=q for p,q in zip(plus,minus))
    J = [p+q for p,q in zip(plus,minus)]
    weights = [x/mj for x,mj in zip(J,m[1:])]
    atoms = active_atoms(A,density,mu)
    assert sum(J)==sum(mass*sum(weights[j] for j in active) for _,mass,active in atoms)
    spatial_quad = sum(mass*sum(weights[j] for j in active)**2 for _,mass,active in atoms)
    totals, counts = defaultdict(Q),defaultdict(int)
    ties = {}
    for i,j in product(labels,repeat=2):
        ratio = min(t[i][1],t[j][1])/max(t[i][1],t[j][1])
        kind = "far" if ratio<=Q(1,8) else ("near" if ratio>=Q(1,2) else "middle")
        mass = weights[i]*weights[j]*mu(intersect(A[i],A[j]))
        assert mass>0
        totals[kind]+=mass
        counts[kind]+=1
        if i<j and ratio in (Q(1,8),Q(1,2)):
            ties[i,j] = kind
    assert ties[0,3]=="far" and ties[0,1]=="near"
    assert all(totals[c]>0 for c in ("near","far","middle")) and sum(totals.values())==spatial_quad
    return {
        "true_parent_radii":[str(r) for y,r in t],"m_t":list(map(str,m[1:])),
        "small_source_original":list(map(str,plus)),"large_source_original":list(map(str,minus)),
        "large_parent_marginal_J":list(map(str,J)),
        "phi_squared":str(spatial_quad),"far_first_counts":counts,
        "ordered_real_scale_components":{k:str(v) for k,v in totals.items()},
        "scope":"Independent uncut true parent model, classifications at radius ratios 1/8 and 1/2.",
    }


def report():
    return {
        "scope":(
            "Finite intervals and positive compactly supported AC pricing. The Hall inputs use chosen continuous C_e and rational "
            "exponential factors; the separate nested test computes genuine D_s balls with rational cutoff proxies."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "rooted_Hall":hall_audit(),"reverse_row_pressure":reverse_row_pressure(),
        "truncated_distance_and_union":nested_audit(),
        "actual_scale_split":scale_split_audit(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print("63 Hall subfamilies and exact realized flow; 192 truncated-metric triple checks.")


if __name__=="__main__":
    main()

