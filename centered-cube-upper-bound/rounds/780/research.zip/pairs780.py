#!/usr/bin/env python3
"""R780 exact common-source reachable domains and one shared target density cap."""

from fractions import Fraction as F
from itertools import combinations, permutations, product
from math import factorial, isqrt
import json
import sys


def ss(items):
    return sum(items,F(0))


def prod(items):
    out=F(1)
    for value in items:
        out*=value
    return out


def width(interval):
    return max(F(0),interval[1]-interval[0])


def section(*intervals):
    return max(i[0] for i in intervals),min(i[1] for i in intervals)


def meet(*boxes):
    return tuple(section(*branch) for branch in zip(*boxes))


def box(center,r):
    return tuple((z-r,z+r) for z in center)


def volume(b):
    return prod(map(width,b))


def contains(outer,inner):
    return all(lo<=a<=b<=hi for (lo,hi),(a,b) in zip(outer,inner))


def minorized(w,d):
    u=sorted(map(abs,w),reverse=True)
    v=sorted(map(abs,d),reverse=True)
    return all(sum(u[:k])<=sum(v[:k]) for k in range(1,len(u)+1))


def kernel(w,T):
    return prod(max(F(0),1-abs(z)/(2*T)) for z in w)


def lens(w,T):
    n=len(w)
    return volume(meet(box((F(0),)*n,T),box(w,T)))/(2*T)**n


def area_from_signed_permutations(d):
    points=sorted({tuple(s*z for s,z in zip(sign,p))
                   for p in permutations(d) for sign in product((-1,1),repeat=2)})

    def cross(a,b,c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

    def chain(points):
        result=[]
        for point in points:
            while len(result)>1 and cross(result[-2],result[-1],point)<=0:
                result.pop()
            result.append(point)
        return result

    convex=chain(points)[:-1]+chain(reversed(points))[:-1]
    area=abs(ss(a[0]*b[1]-b[0]*a[1] for a,b in zip(convex,convex[1:]+convex[:1])))/2
    a,b=sorted(map(abs,d),reverse=True)
    assert area==4*a*a-2*(a-b)**2
    return convex,area


def certify(n):
    a=32*n
    h=1+F(1,a)
    R=F(2)
    eps=F(1,128*n)
    L=3-(n+2)*eps
    rr=min(F(3,2)-3*eps,(3-(n+4)*eps)/n)
    assert 0<rr and n*rr<=L
    vol_S=(2*rr)**n
    vol_D=2**n*L**n/factorial(n)
    extra=vol_D-vol_S
    assert extra>vol_S

    def embed(x,y):
        return (F(x),F(y))+(F(0),)*(n-2)

    y0=embed("-3/2","-3/2")
    map_z={"axis_x":embed("3/2","-3/2"),"axis_y":embed("-3/2","3/2"),
           "balanced":embed(0,0)}
    shifts=(embed("-5/2","-5/2"),embed(-F(1,8*n),-F(1,8*n)),
            embed(F(1,8*n),F(1,8*n)),embed("5/2","-5/2"),
            embed("-5/2","5/2"),embed("9/8","9/8"))
    rmid=2-F(1,4*n)
    small=F(5,4)
    radii=(small,rmid,rmid,small,small,small)
    A=[box(c,s) for c,s in zip(shifts,radii)]
    C=list(A)
    C[2]=tuple((lo,hi-F(1,16*n)) for lo,hi in A[2])
    E=[box(c,s/a) for c,s in zip(shifts,radii)]
    assert all(1<=r<2 for r in radii)
    assert all(contains(A[i],E[i]) for i in range(6))
    assert all(not volume(meet(e,f)) for i,e in enumerate(E) for f in E[:i])
    period=F(1,4*n)
    def mu_1(I):
        lo,hi=section(I,(F(-8),F(8)))
        def cumulative(x):
            g=x//period
            t=x-g*period
            return g*period+t/2+max(F(0),t-period/2)
        return cumulative(hi)-cumulative(lo) if hi>lo else F(0)

    def mu(Q):
        return prod(map(mu_1,Q))

    m=list(map(mu,A))
    I=list(map(volume,E))
    assert m==list(map(volume,A)) and (2*R)**n/2<=m[1]==m[2]<(2*R)**n
    intersections={(e,g):mu(meet(C[e],C[g])) for e,g in product(range(6),repeat=2)}
    K={(e,g):s/(m[e]*m[g]) if e!=g else F(0) for (e,g),s in intersections.items()}
    degree={e:ss(I[j]*K[e,j] for j in range(6)) for e in (1,2)}
    assert K[1,2]>0
    Y=box(y0,eps)
    S_phys=box(y0,rr)
    eps_spread=2*eps
    assert n*rr+n*eps<=3-4*eps
    assert rr+eps<=F(3,2)-2*eps
    assert L+n*eps==3-2*eps

    scales=(F(13,8),F(7,4),h*R)
    records={}
    for g,(name,z) in enumerate(map_z.items(),3):
        Z=box(z,eps)
        assert contains(C[0],Y) and contains(C[g],Z)
        assert all(contains(C[e],Y) and contains(C[e],Z) for e in (1,2))
        # Both marks retain their actual intersection normalization and the full d(e).
        paths={}
        for left,right,P,Q in ((0,g,Y,Z),(g,0,Z,Y)):
            per_e={}
            for e in (1,2):
                first=I[left]*I[e]*K[left,e]
                second=I[right]*K[e,right]/degree[e]
                price1=mu(meet(P,C[left],C[e]))/intersections[left,e]
                price2=mu(meet(Q,C[e],C[right]))/intersections[e,right]
                per_e[e]=first*second*price1*price2
            merged=mu(P)*mu(Q)*ss(I[left]*I[e]*I[right]/(degree[e]*m[left]*m[e]**2*m[right])
                                   for e in (1,2))
            assert all(per_e.values()) and ss(per_e.values())==merged>0
            paths[(left,right)]=(per_e,merged)
        assert paths[0,g][1]==paths[g,0][1]
        d=tuple(zj-yj for yj,zj in zip(y0,z))
        section_d=tuple((z0-y1,z1-y0a) for (y0a,y1),(z0,z1) in zip(Y,Z))
        projected_small=tuple(max(F(0),min(abs(lo),abs(hi))) if lo*hi>0 else F(0)
                              for lo,hi in section_d)
        box_volume=volume(section_d)
        assert box_volume==(4*eps)**n
        by_coordinates=prod(2*r for r in projected_small)
        old_majorized=(rr,)*n
        assert minorized(old_majorized,d)
        for scale in scales:
            for dv in (d,tuple(-u for u in d),tuple(reversed(d))):
                assert minorized(old_majorized,dv) and kernel(old_majorized,scale)>=kernel(dv,scale)>0
                assert lens(dv,scale)==kernel(dv,scale)
            assert lens(old_majorized,scale)==kernel(old_majorized,scale)
        if name.startswith("axis"):
            spare_w=(L-eps,)+(F(0),)*(n-1)
            assert abs(spare_w[0])>rr and minorized(spare_w,d)
            assert all(kernel(spare_w,scale)>=kernel(d,scale) for scale in scales)
        signed_hull=None
        if n==2:
            vertices,hull=area_from_signed_permutations(d)
            assert hull==(F(9) if name=="balanced" else F(18))
            signed_hull={"vertices":vertices,"area":hull}
        # True owner perturbation of both ends, relative to their own centers.
        pivot_diffs=tuple((j[0]-i[1]-(cj-ci),j[1]-i[0]-(cj-ci))
                          for i,j,ci,cj in zip(E[0],E[g],shifts[0],shifts[g]))
        assert volume(pivot_diffs)==(4*small/a)**n
        records[name]={"d_at_price_centers":d,"actual_coordinate_d_box":section_d,
                       "raw_d_coordinate_box_volume":box_volume,
                       "robust_componentwise_sign_box_volume":by_coordinates,
                       "price_box_z":Z,"symmetric_signed_permutation_hull":signed_hull,
                       "genuine_forward_and_reverse_peak_by_middle":[paths[0,g][0],paths[g,0][0]],
                       "positive_true_mass":paths[0,g][1],
                       "actual_owner_difference_offset_volume":volume(pivot_diffs),
                       "tested_scale_kernel_values_at_d":[kernel(d,T) for T in scales],
                       "same_displacement_at_each_scale":old_majorized}
    masses={name:v["positive_true_mass"] for name,v in records.items()}
    M=masses["balanced"]
    assert set(masses.values())=={M}
    if n==2:
        assert contains(S_phys,E[0])
        assert records["axis_x"]["robust_componentwise_sign_box_volume"]==0

    # All right price classes pay through this same Lebesgue target capacity.
    cap=F(3,2)*M/vol_S
    solo=M/vol_S
    naive_common=ss(masses.values())/vol_S
    assert solo<cap<naive_common
    allocations={name:((mass,F(0)) if name=="balanced" else (mass/4,3*mass/4))
                 for name,mass in masses.items()}
    routed=[ss(q[k] for q in allocations.values()) for k in (0,1)]
    densities=[routed[0]/vol_S,routed[1]/extra]
    assert densities[0]==cap and densities[1]<cap and sum(routed)==ss(masses.values())
    capacities=(cap*vol_S,cap*extra)
    for k in range(1,4):
        for subset in combinations(masses,k):
            capacity=capacities[0] if set(subset)=={"balanced"} else sum(capacities)
            assert ss(masses[name] for name in subset)<=capacity

    full_uniform=None
    if n==2:
        # Less favorable than the common-subdomain test: every exact d is uniform on its
        # entire own signed permutation hull. Bounds cover all y,z in each true price box.
        axis_lo=2*(3-2*eps)**2
        axis_hi=2*(3+4*eps)**2
        balanced_lo=4*(F(3,2)-2*eps)**2
        balanced_hi=4*(F(3,2)+2*eps)**2
        one_density_upper=max(M/axis_lo,M/balanced_lo)
        add_density_lower=2*M/axis_hi+M/balanced_hi
        assert one_density_upper<cap<add_density_lower
        full_uniform={"full_axis_hull_volume_enclosure":[axis_lo,axis_hi],
                      "full_balanced_hull_volume_enclosure":[balanced_lo,balanced_hi],
                      "maximum_single_density_bound":one_density_upper,
                      "sum_density_lower_bound_throughout_S":add_density_lower}

    # The reference old rule uses diagnostic ell=1 and its own actual units.
    root=isqrt(128*n)
    lower_octave_radius=F(1)
    one_upper=lower_octave_radius/root
    one_lower=one_upper if root*root==128*n else lower_octave_radius/(root+1)
    if n==2:
        assert one_lower==one_upper==F(1,16)
        assert (2*one_upper)**n==F(1,64) and (4*one_upper)**n==F(1,16)
    return {"n":n,"period_for_each_source_coordinate":period,"O":"[1,2)","upper_parent_bin_radius":R,"lower_octave_radius":lower_octave_radius,"h":h,
            "true_radii":radii,"real_parent_mass_equals_its_volume":True,
            "actual_disjoint_owners":True,"original_degree":degree,"Y_shared_true_source_price_box":Y,
            "kernel_length_scales_checked":scales,"cases":records,
            "all_positive_scales_reason":"weak prefix majorization gives the inequality for every hinge sum (x-s)_+; apply it to the increasing convex -log(1-x/(2T)); if K_T(d)=0 the comparison is immediate",
            "shared_reachable":{"center":y0,"axis_L1_radius":L,"axis_D_volume":vol_D,
                                "balanced_physical_cube_half_side":rr,"S_volume":vol_S,
                                "axis_only_remainder_volume":extra,
                                "robust_proof":"axis: all prefix sums are <= L+n eps <= max |d|; balanced: first prefix <= rr+eps <= first |d|, all remaining prefixes <= n(rr+eps) <= sum of the two dominant |d|"},
            "old_single_endpoint_comparator":{"diagnostic_ell":1,"allowed_half_side_interval":[one_lower,one_upper],
                                               "one_moved_end_volume_upper":(2*one_upper)**n,
                                               "both_independently_moved_difference_volume_upper":(4*one_upper)**n},
            "true_shared_density_cap":{"per_original_right_class_mass":M,
                "one_shared_density_cap":cap,"independent_legal_single_density":solo,
                "illegal_sum_density_from_full_reuse_of_S":naive_common,
                "common_only_capacity":capacities[0],"new_total_allocated":ss(masses.values()),
                "all_seven_nonempty_class_subset_capacity_checks_included":True,
                "allocations_into_S_then_remainder":allocations,"reassigned_densities":densities,
                "full_d_specific_uniform_domains_have_overlap_violation":full_uniform},
            "scope":"finite actual ordinary 2/4/8D cubes, preorder by weak majorization and declared diagnostic ell; capacity is not reset by the future price, label, or original middle history"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B pairs780.py",
                      "dimensions":[certify(n) for n in (2,4,8)]},
                     sort_keys=True,indent=2,default=str))
