"""Exact and interval checks for the R780 source budget and shared capacities."""
import hashlib
import itertools
import json
import math
import platform
import sys
from fractions import Fraction as F

import flint
from flint import arb, ctx
import numpy as np
import scipy
from scipy.optimize import linprog
import sympy as sp


def dot(x, y):
    return sum((a*b for a, b in zip(x, y)), F(0))


def rational(x):
    return F(float(x)).limit_denominator(10**7)


def mult(x):
    return math.prod(x, start=F(1))


def boundary_example(n):
    s, a = F(5, 4), F(7, 4)
    q, interior_mass = F(1, 256*n), F(1, 10)
    u, v, g = (-a-s+q, s), (F(0), a), (a+s-q, s)
    medium = (2*a-2*interior_mass)/(2*a-2*q)
    edge, outside = interior_mass/q, (2*s-interior_mass)/q
    pieces = [(-a-q, -a, outside), (-a, -a+q, edge),
              (-a+q, a-q, medium), (a-q, a, edge), (a, a+q, outside)]

    def mass(lo, hi):
        return sum((max(F(0), min(hi, y)-max(lo, x))*d for x,y,d in pieces), F(0))

    def interval(parent):
        c,r = parent
        return c-r,c+r

    def meet_mass(i,j):
        l,r = interval(i)
        s0,t = interval(j)
        return mass(max(l,s0),min(r,t))**n

    checks = 0
    for center, radius in (u,v,g):
        critical = {F(0), radius}
        critical |= {abs(z-center) for x,y,_ in pieces for z in (x,y) if abs(z-center)<radius}
        for r in critical:
            checks += 1
            assert mass(center-r,center+r) <= 2*r
        assert mass(center-radius,center+radius) == 2*radius
    boxes=[u,v,g]
    weights=[(2*r/(32*n))**n for c,r in boxes]
    m=[(2*r)**n for c,r in boxes]
    for (c,r),(d,t) in itertools.combinations(boxes,2):
        assert abs(d-c)>(r+t)/(32*n)
    eta_edge = (interior_mass/(2*s))**n
    for i in (0,2):
        assert meet_mass(boxes[i],v)/m[i] == eta_edge
    # Fixed eligibility graph, including both orientations and diagonal endpoint pairs.
    K = [meet_mass(x,v)/(mi*m[1]) for x,mi in zip(boxes,m)]
    degree = sum(weights[i]*K[i] for i in (0,2))
    gross = marked = F(0)
    for i,j in itertools.product((0,2),repeat=2):
        path = weights[i]*weights[1]*weights[j]*K[i]*K[j]/degree
        gross += path
        marked += int(i!=j)*path
    assert gross == weights[1]*degree and 2*marked==gross
    # Both entire small-parent sources are contained in their respective grid cells.
    b=F(1,32*n)
    assert (a/(2*b)).denominator==1 and q<b
    assert mass(-a-b,-a+b) >= 2*s
    assert mass(a-b,a+b) >= 2*s
    raw=F(1)
    clipped=min(raw,eta_edge)
    assert raw/clipped==25**n and (raw/clipped)**2==25**(2*n)
    assert 2*q<=s/32 and F(64*n)*2*q/s==F(2,5)
    return dict(n=n,first_crossing_breakpoints=checks,edge_fraction=eta_edge,
                joint_reference_raw_over_clipped=25**(2*n),central_degree=degree,
                ordered_all_peak=gross,ordered_cross_peak=marked,
                log_source_potential_lower="−2/5",cap_half_width=b)


def budgets():
    u, b, h, n = sp.symbols("u b h n",positive=True)
    expression=n*sp.log(2*u)+2*n*sp.log(1+2*b/(h*u))
    slope = sp.factor(sp.diff(expression,u)*u/n)
    assert sp.simplify(slope-(h*u-2*b)/(h*u+2*b))==0
    ctx.prec=256
    rows=[]
    for N in (64,256,1024,4096,2**16,2**24,2**40,2**80):
        a=arb(N)
        ell=arb(N+2).log()
        r=(a.sqrt()*ell**2).ceil().unique_fmpz()
        assert r is not None
        T=arb(r)/256
        kappa=8*a/T
        h=1+1/(32*a)
        assert kappa>8 and kappa>(2+4*h)*(T/(2*a)).exp()
        # Logs of the two summands relative to eta^(1/6).
        log_first=-T+T/3+4*a/kappa+T/6
        log_second=T/2+a*((2+4*h)/kappa).log()
        assert log_first.contains(0) and log_second<0
        # Distinct graph test: can the two diagnostic parents meet the volume-gap gate?
        gap=a*(arb(7)/5).log()-a.sqrt()*ell**3
        assert gap>0 or gap<0
        rows.append(dict(n=N,r=str(r),kappa=kappa.str(14),log_second=log_second.str(14),
                         boundary_input_meets_volume_gap=bool(gap>0)))
    return dict(log_derivative=str(slope),parameters=rows)


def gamma_capacity():
    rows=[]
    for n in (1,2,4,8,16,32,64,128,256):
        # Direct finite upper-tail subtraction loses digits near p=1.
        ctx.prec=300+int(n*math.log2(n+2))+2*n
        for label,x in (("1/2",arb(1)/2),("(3/4)^n",(arb(3)/4)**n),
                        ("(1/2)^n",(arb(1)/2)**n),("(1/4)^n",(arb(1)/4)**n)):
            s=-x.log()
            total=term=arb(1)
            for j in range(1,n):
                term=term*s/j
                total=total+term
            by_layers=1-x*total
            incomplete=s.gamma_lower(n)/math.factorial(n-1)
            assert by_layers.overlaps(incomplete) and by_layers>0 and by_layers<1
            rows.append(dict(n=n,level=label,volume_fraction=incomplete.str(16),
                             precision_bits=ctx.prec))
    ctx.prec=256
    return rows


def masks(size):
    return [[i for i in range(size) if mask & (1<<i)] for mask in range(1,1<<size)]


def union_length(intervals):
    total=F(0)
    right=None
    for a,b in sorted(intervals):
        total += b-a if right is None or a>=right else max(F(0),b-right)
        right=b if right is None else max(right,b)
    return total


def prefix_loss(ref, priority, deficiency):
    answers=[]
    prev=F(0)
    for top in sorted({value for value in priority if value>0}):
        restricted=[m if w>=top else F(0) for m,w in zip(ref,priority)]
        answers.append((top-prev)*deficiency(restricted))
        prev=top
    return sum(answers,F(0))


def shared_lp(x, ref, edges, peak, endcap, diffcap):
    # Diagnostic in physical units, with t=1/2, s=1/8, no repeated targets.
    v,e=len(x),len(edges)
    edge_supply=[ref[i]*ref[j] for i,j in edges]
    dist=[abs(x[j]-x[i]) for i,j in edges]
    assert all(d<1 for d in dist)
    width=F(1,8)
    subsets=masks(v)
    end_rooms=[endcap*union_length([(x[i]-width,x[i]+width) for i in subset])
               for subset in subsets]
    thresholds=sorted(set(dist))
    diff_rooms=[diffcap*2*d for d in thresholds]
    A=[]
    b=[]
    def row():
        return [F(0)]*(v+2*e)
    for k,(i,j) in enumerate(edges):
        R=row()
        R[i]-=1
        R[j]-=1
        R[v+k]=R[v+e+k]=-1
        A.append(R)
        b.append(F(-1))
    for subset,cap in zip(subsets,end_rooms):
        R=row()
        for i in subset:
            R[i]=ref[i]
        A.append(R)
        b.append(cap)
    for t,cap in zip(thresholds,diff_rooms):
        R=row()
        for k,d in enumerate(dist):
            if d<=t:
                R[v+k]=edge_supply[k]
        A.append(R)
        b.append(cap)
    for k in range(v+e):
        R=row()
        R[k]=1
        A.append(R)
        b.append(F(1))
    cost=[F(0)]*(v+e)+list(map(F,peak))
    sol=linprog(np.array(cost,dtype=float),A_ub=np.array(A,dtype=float),
                b_ub=np.array(b,dtype=float),bounds=(0,None),method="highs")
    assert sol.success
    primal=list(map(rational,sol.x))
    lambdas=[-rational(z) for z in sol.ineqlin.marginals]
    assert min(primal)>=0 and min(lambdas)>=0
    assert all(dot(ar,primal)<=cap for ar,cap in zip(A,b))
    assert all(c+dot(col,lambdas)>=0 for col,c in zip(zip(*A),cost))
    objective=dot(cost,primal)
    assert objective==-dot(b,lambdas)
    subflow=lambdas[:e]
    assert all(0<=f<=p for f,p in zip(subflow,peak))
    summed=[F(0)]*v
    for (i,j),f in zip(edges,subflow):
        summed[i]+=f
        summed[j]+=f
    def end_def(q):
        return max([F(0)]+[sum(q[i] for i in S)-h for S,h in zip(subsets,end_rooms)])
    def pair_def(q):
        return max([F(0)]+[sum(val for val,d in zip(q,dist) if d<=t)-h
                            for t,h in zip(thresholds,diff_rooms)])
    end=prefix_loss(ref,[a/b for a,b in zip(summed,ref)],end_def)
    pair=prefix_loss(edge_supply,[a/b for a,b in zip(subflow,edge_supply)],pair_def)
    assert end+pair-2*sum(subflow)==objective
    return dict(objective=objective,subflow=subflow,primal=primal,nonnegative_dual=lambdas,
                endpoint_loss=end,pair_loss=pair)


def lp_tests():
    x=[F(0),F(1,4),F(3,4)]
    edges=[(0,0),(0,1),(1,2),(0,2),(2,2)]
    rows=[]
    for ref in ((2,2,2),(3,4,2),(5,2,3)):
        for peak in ((1,2,3,4,2),(6,3,2,5,1),(2,2,4,3,5)):
            for endcap in (1,4,8,12):
                base=shared_lp(x,ref,edges,peak,endcap,0)
                for diffcap in (1,4,8,16):
                    full=shared_lp(x,ref,edges,peak,endcap,diffcap)
                    assert 0<=full["objective"]<=base["objective"]
                    rows.append(dict(ref=ref,peak=peak,endcap=endcap,diffcap=diffcap,
                        endpoint_only=base["objective"],complete=full["objective"],
                        partial_subflow=any(0<t<v for t,v in zip(full["subflow"],peak)),
                        full=full))
    choice=next((r for r in rows if 0<r["complete"]<r["endpoint_only"] and r["partial_subflow"]),None)
    assert choice is not None
    return dict(cases=len(rows),positive_improvements=sum(r["complete"]<r["endpoint_only"] for r in rows),
                partially_served_and_improved=sum(0<r["complete"]<r["endpoint_only"] for r in rows),
                zero_residual_after_improvement=sum(r["complete"]==0<r["endpoint_only"] for r in rows),
                nontrivial_joint_subflow=sum(r["partial_subflow"] for r in rows),illustration=choice,
                data_digest=hashlib.sha256(json.dumps(rows,sort_keys=True,default=str).encode()).hexdigest())


def wide_window_test():
    # One smoothed atom per stratum of length 1/K, with periodic extensions.
    # Background <=40/(K+20); at most ceil(K*d)+1 touched strata for length d.
    d=F(11,256)
    rows=[]
    ctx.prec=256
    for n in (64,256,1024,4096,2**16,2**24,2**40,2**80):
        root=(3*arb(n)/(74*arb(n).log())).sqrt()
        rounded=(root+arb(1)/2).floor().unique_fmpz()
        assert rounded is not None
        K=max(48,int(rounded)-20)
        bound=(math.ceil(d*K)+1+40*d)/(K+20)
        assert bound<=F(1,11)
        L=arb(n+2).log()
        r=(arb(n).sqrt()*L**2).ceil().unique_fmpz()
        assert r is not None
        log_relative=n*(arb(bound.numerator)/bound.denominator).log()+arb(r)/256
        assert log_relative<0
        rows.append(dict(n=n,K=K,per_coordinate_upper=bound,
                         log_of_potential_over_eta_upper=log_relative.str(15)))
    return rows




if __name__=="__main__":
    result=dict(python=sys.version.split()[0],machine=platform.machine(),scipy=scipy.__version__,
                sympy=sp.__version__,flint=flint.__version__,numpy=np.__version__,
                scope="univariate source tensored in n coordinates; parameter sample; physical scalar rank; diagnostic LP",
                boundary=[boundary_example(n) for n in (1,2,4,8,16,32,64)],budgets=budgets(),
                gamma=gamma_capacity(),LP=lp_tests(),wide_window=wide_window_test())
    print(json.dumps(result,sort_keys=True,indent=2,default=str))
