"""R622 saved rational arithmetic / shard coverage checks; no large rescan."""
from pathlib import Path
from fractions import Fraction as F
import argparse, hashlib, itertools, json, math, sys

def compositions(n, b):
    if b == 1:
        yield (n,)
        return
    for k in range(n + 1):
        for t in compositions(n-k, b-1):
            yield (k,) + t

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).parent)
    args=ap.parse_args();root=args.root
    x=json.loads((root/'ccu_r622_numeric.json').read_text())
    assert len(x['results'])==16
    assert {(r['n'],r['bins']) for r in x['results']}==set(itertools.product((7,8,10,12),(4,6,8,12)))
    s=F(21,20);eps=F(1,10**9);theta=1-F(1,10**8);K=10**8
    for r in x['results']:
        n,B=r['n'],r['bins'];L,U=r['lower_boxes'],r['upper_boxes']
        assert 0<=L<=U<=B**n
        assert r['labeled_receiver_boxes']==B**n
        assert r['histograms']==math.comb(n+B-1,B-1)
        scales=r['scale_counts'];assert len(scales)==(n+1)**2==r['scale_count']
        assert len({m for i,j,m,ni,no in scales})==len(scales)
        for i,j,m,ni,no in scales:
            assert m==2**i*3**j and (i+1)//2+j<=n
            assert 0<=ni<=no<=B**n and ni<=L and no<=U
        assert F(*r['ideal_continuous_volume_lower'])==L*(s/B)**n
        assert F(*r['ideal_continuous_volume_upper'])==U*(s/B)**n
        assert F(*r['finite_L1_lower'])==theta*L*(s/B-2*eps)**n*F(2*K+1,2*K+5)**n
        if 'markov_single_upper_exact' in r:
            assert F(*r['markov_single_upper_exact'])==min(1,max(t[4] for t in scales)*(s/B)**n)
    sh=x['shard12'];assert sh['status']=='complete'
    assert sh['expected_shards']==sh['finished_futures']==3646
    for ns,a in sh['aggregates'].items():
        n=int(ns);prefix=[tuple(t) for t in a['completed_shards']]
        expected={p for k in range(n+1) for p in compositions(k,4)}
        assert len(prefix)==len(set(prefix))==len(expected)
        assert set(prefix)==expected and a['N']==12**n
        r=next(r for r in x['results'] if r['n']==n and r['bins']==12)
        assert r['lower_boxes']==a['unionin'] and r['upper_boxes']==a['unionout']
        assert [t[3] for t in r['scale_counts']]==a['inner']
        assert [t[4] for t in r['scale_counts']]==a['outer']
    assert F(11,10)**7<2
    small=json.loads((root/'ccu_r622_interval.json').read_text());assert len(small['cases'])==9
    manifest=root/'MANIFEST.json'
    if manifest.exists():
        for name,digest in json.loads(manifest.read_text()).items():
            assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
    print(json.dumps({'saved_cases':16,'complete_shards':3646,'small_independent_cases':9,
                      'seven_dimensional_full_cell_check':True,
                      'scope':'saved exact arithmetic and task coverage; not a large-case recomputation or general upper-bound proof'}))

if __name__=='__main__':main()
