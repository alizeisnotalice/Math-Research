# R622 同尺度易例与真实格点多尺度接收：独立审计

日期：2026-10-28。第1–3节先于阅读R622作者证明或Terra代码形成；第4–8节随后核对主稿、bridge、生产数值代码与最终报告。不改repo，不启动重计算或Agent，不扫描新实例。

## 1. 已可直接付款的两个一般门槛

任意有限全supplied family，取最大star单独packing即有Q*≥max_j|aB_j|；V≤N max_j|B_j|，故

V/Q*≤N/a^n。

当这个数已在目标界以内，实例本来已付款。不能固定N后调大a，再交换到全部有限family的sup；真正有限cover的N可随a增长。

若全部B_j半径同为r，令D=[2(a+1)r]^n、λ_j=v_j/D。对任意source点y，所有含y的a-stars对应的小B_j均在B(y,(a+1)r)中，实际increments不交，所以Σ_(j:y∈aBj)v_j≤D。于是λ全空间可行，且

Q=Σ_j λ_j(2ar)^n=V/(1+1/a)^n。

这是任意位置、任意N、所有n的同尺度一般工具；不需要product结构或共同交。因此同尺度product数值、冻结或source LP结果不能算作本轮新的多尺度推进。真正新内容必须使用不同averaging尺度间的共同source及receiver耦合。

## 2. 七维格点实验的独立数学检查表

以下按单位质量点源、格距s=21/20、阈值1理解，作者须明确其规范。s控制source density，不是packing dilation a。r=(∏ℓ_i)^(1/7)/2是averaging cube半径，不应未经说明当作B_j的小receiver半径。

在反射半胞t_i∈[0,s/2]，一维第ℓ近格点距离（ℓ=1,2,3,4）依次是

t，s−t，s+t，2s−t。

同一个ℓ向量给m=∏ℓ_i及共同r=m^(1/7)/2；各坐标距离均小于r时，cube含至少m个单位质量点。不能在各坐标独立选择不同radius后仍当成一个cube。允许实际包含更多格点只会加强lower witness。

ℓ_i∈{1,2,3,4}是一个有限、多尺度witness菜单，r范围[1/2,2]。它可以给真实连续receiver lower bound；即使完全计算该union，也不是所有半径maximal level set的upper bound。外夹逼只upperbound这个候选union，不能upperbound一般C_7。

严格内外box分类须满足：inner box确在某个完整witness box中，或有其他严格union-cover证明；outer必须包含每个可能与任一witness相交的bin box。一个box可由多个witness联合覆盖，故“存在单witness全含”只是合法但可能保守的inner测试。对有理bin端点q≥0，q与r的比较可准确改为(2q)^7与整数m比较，无需把浮点radical当区间证书。

坐标置换压缩只在完整source/menu/分bin均置换对称时成立。bin histogram k_b对应的multiplicity为7!/∏k_b!，体积权是该系数乘∏width_b^(k_b)。不能把一个代表box简单乘7!忽略重复bins；也不能将不同witness的volume相加当union。固定同一个ℓ向量的product/radius一致性必须由压缩后的existence测试保留。

## 3. 真实测度与有限L1入口

无限周期原子格点不是L1输入。若半胞候选覆盖体积为W_half，完整周期receiver体积为2^7 W_half；每胞质量为1。因此应比较

2^7 W_half=s^7·(半胞覆盖比例)，

而不是把source norm误作胞体积。若阈值改成η，则相应比值再乘η。

要用于真正C_7下界：截取大有限格点窗口，receiver只取距窗口边界足够远的周期cells以保留所有r≤2 witnesses；然后把每点替为小质量保持L1 bump。finite-window边界比例在固定n下趋0。接收点避开有限witness边界后有包含裕量，可保留bumps并稍缩radius得到strict平均>1；或先用η<1再取η↑1。有限witness union边界为零测，故eroded receiver体积趋向原值。若要一个严格有限数值下界，应明确选定窗口、bump/erode/阈值误差，或以operator supremum的严格极限论证给出≥结论。

这比只看有限centers、同尺度product或独立clique retention更直接测试真正多尺度continuous receiver。但它仍是固定七维、特殊source、有限四倍半径带的lower-profile探路，不是一般n上界/递推定理。所有finite L1与真实Lebesgue receiver条件都必须保留。

## 4. 主稿的一般筛选与轨道公式：通过范围

已读 `/tmp/ccu_r622_main_sol.md`。N门槛与第1节一致；窄半径带r_j∈[r,R]时，原increments给λ_j=v_j/[2(a+1)R]^n可行，Q*≥[ar/((a+1)R)]^nV，故同尺度及R/r≤exp(c/n)的费用正确。它们已付一般工具，没有product特例的新推进。

共同有限Euclidean-isometry群若保持一个非空轴平行cube family，移至群共同固定点后确为signed permutations，故|G|≤2^n n!、N≤L|G|；Stirling项的指数常数2/e正确。该界不能用于无限平移周期群。共同群平均保持全space packing与objective，orbit count-vector LP准确保留所有尺度的共同load。两orbit的H=1+ρ及receiver交J给V/Q*≤P(1+ρ)/(1+J/V)，方向正确；未给一般多orbit root估计。

## 5. Bridge：真实来源证书到有限cube family

已读 `/tmp/ccu_r622_bridge.md`。R006具体下界2.1365作为原证书的继承输入，**本审未重新独立认证该旧数值并集**。在该输入成立时，bridge的几何与收费连接通过。

周期packing核必须累加所有lattice images。同一个每胞单位bump来源对全部admissible averaging cubes供给质量≥m；将全periodized load对该source积分，准确给Q_cell*≤1。source-primal上界不等于已求得Q_cell*=1。共同反射与后六坐标置换保持R006的非对称格子、完整domains及canonical最大m选择，群平均无损；不是给各label或各scale独立来源。

有限化中receiver胞数(2K+1)^7、source collar胞数(2K+5)^7明确区分。f_K/theta给source-primal质量上界(2K+5)^7/theta，因此比值下界正是theta·|E|·[(2K+1)/(2K+5)]^7。theta是水平/来源归一成本，collar是边界source质量成本，均只付一次。不能将finite collar的2直接当periodized kernel image截断而不核范围；proof已明确此区别。

每个closed admissible box以坐标间距≤r_ell/a的有限中心网格覆盖，任一点距某网格中心≤r_ell/(2a)<r_ell/a，所以small B确覆盖**整块**receiver。所有中心仍有同source的真实bad averaging cube；重复centre换用最大已证radius只会扩大small cover。由任意有限packing Q*≤source质量，V≥真实covered volume，得到真实有限family的V/Q*>1（继承R006证书时>2.1365）。这里没有把bin中心数量当体积，也没有把Q*当作已求得最优值。完全有理中心/半径需另行保留root区间和余量；允许精确代数数据的有限存在性论证已充分。

## 6. 数值算法的几何与整数逻辑

检查表形成后才读 `/tmp/ccu_r622_numeric.py`。代码的ℓ起始索引0,0,−1,−1、统一m=2^i3^j与radius、根区间、bin全含/正长度相交测试，均实现第2节模型。可达产品满足ceil(i/2)+j≤n，共(n+1)^2 scales。指数编码i+(2n+1)j不发生进位混叠；histogram的multinomial权准确，逐scale先判existence再取union，未加重叠体积。

整数root给r_-≤r_m<r_+；inner全bin通过是合法下界，outer正长度相交测试覆盖所有正体积真实交（仅边界差无体积）。所有计数为Python整数，体积/finite值由Fraction构成，小数只是显示。outer仅约束ℓ≤4的menu，不能upperbound完整maximal levelset。max-product加速仅对全menu union等价，不替代单scale标记计数；报告没有宣称本轮大任务运行了该未实施加速。

固定radius周期平均在完整胞上的积分等于胞质量1，所以单尺度level-1 receiver体积≤1；这里不是uniform-probability平均为1。理想inner差与Markov优势只用于周期profile；finite L1自身的单尺度weak ratio≤1另由全空间积分守恒给出。n7的m=1、m=2完整胞覆盖论证与模型一致，但不要求粗inner bins自动达到该解析值。

## 7. 平滑见证勘误及分片纳入规则

**发现并修复的归一错误：** 原生产注释称每个half-bin每侧缩EPS，却使用N_-(s/B−2EPS)^n；二者差二倍。正式证明现改为每个half-bin每侧缩EPS/2，半胞边长变成s/(2B)−EPS，反射后正是(s/B−2EPS)^n。取bump radius EPS/4，则相对于已内判定的整bin有严格几何裕量，原averaging radius仍包含所有对应bumps。全部source-block偏移在±2内，collar2足够；theta<1给共同strict水平。故保存的finite分数无需重算，只须采用修订后的真实见证。最终REPORT及REPRODUCE已明确此勘误；生产脚本保留原执行字节，旧注释不能再当正式证明。

已核生产分片代码：B12的prefix是前四bin的counts，tail为其余八bin，所有prefix和≤n，故每个完整histogram恰落一个任务。partial shard不贡献任何计数；只有完整shards累加。只在aggregate N=12^n时才生成该维度结果；缺任一唯一prefix都会缺正权histogram，不能伪装完整upper。前三分辨率的case函数也在完成全部histograms并核N=B^n后才返回纳入。

读取当前JSON确认16个(n,B)身份齐全且唯一、shard status=complete、expected/finished=3646；各维aggregate N=12^n、保存prefix无重复。当前script SHA与生产字节匹配，旧12案版本的prior hash保留；最终归档生产文件与已审生产文件字节一致。根代理另实际重放9个小例、verify完整集合，并对n7/B12作单体重算；这些是其独立收据，**本审未重算全部大例，也未把另外三个B12算成已重算**。

## 8. 最终报告与停止范围

最终 `/tmp/ccu_r622_final/REPORT.tex` 的筛选、全来源finite dense-cover桥、多尺度menu、bin体积、theta/collar、修订平滑参数、阶段/分片来源及新旧证据边界与上述审查一致。复现说明承认历史版本字节并未全部保留、production旧注释erratum以及慢机器partial不能当完成，范围准确。

已核的积极结论是：该实验真正处理同一source、不同averaging radii及连续receiver体积；其finite L1证书可产生非平凡V/Q*>1的真实有限family，比同尺度或N/a^n已付小族更直接检测多尺度竞争。它不证明这些family违反root级目标，也不提供一般upper bound。R006更强旧值只继承，不称本轮新独立数值认证；16个有限维menu结果也不外推维数阶。

最终无未修复的关键数学疑问。一般任意输入、全尺度的共同packing下界及原母账仍未闭合。未认证最终ZIP或commit；未新增重计算、扫描或Agent。审计完成，立即停止。
