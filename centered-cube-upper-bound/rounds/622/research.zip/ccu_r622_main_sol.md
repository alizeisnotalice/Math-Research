# R622：预算筛选、同尺度已付账与真正多尺度竞争

本轮没有一般维数新界。主代理共享的真实budget-hard receiver/source构造由bridge另稿认证；本稿不重复其证明，也不把有限样本当维数指数证据。以下只收束准确关键公式，并将未付量限定为完整多尺度family的共同source竞争。没有启动新的数值任务，没有修改仓库或他人文件。

## 1. N门槛：先终止有限小族

单行λ_j=1始终packing可行，故Q*≥max_jd_j。另一方面真实receiver不交增量满足

  V≤Σ_j|B_j|=a^(−n)Σ_jd_j≤N a^(−n)max_jd_j。

所以准确有

  V/Q*≤N/a^n。                                     (1)

旧N=40、n=2、a=8族至多为5/8，任意半径分布也不可能budget-hard；不再延伸它。反过来，V/Q*>1要求N>a^n，但N>a^n只是必要条件，不能替代真实V/Q*证据。

(1)不排除一般有限逼近或任意a下的budget-hard族：稠密小B覆盖时N可随a增长，不能固定N后让a→∞，再推断全族目标已经容易。主代理共享的桥梁正处理这种真正大规模接收几何。

## 2. 同尺度与窄半径带：全部几何都已可付款，无需product假设

假设全部r_j∈[r,R]，沿原真实increments定义

  λ_j=v_j/[2(a+1)R]^n。

若y∈A_j，则I_j⊂B(y,(a+1)r_j)⊂B(y,(a+1)R)。所有I_j不交，因此在同一个任意source位置y，

  Σ_jλ_j1_Aj(y)≤1。

这个真实全族packing给出

  Q*≥Σ_jλ_jd_j
     ≥[ar/((a+1)R)]^n V，
  V/Q*≤P(R/r)^n， P=(1+1/a)^n。                   (2)

同r时是V/Q*≤P；R/r≤exp(c/n)时只付P e^c。a≥n²时P≤exp(1/n)。故同尺度product、单轨道、巨大密集同r族都不构成新难点；此前product推导停止，不将此已付账包装成新进展。

多尺度可分别用(2)，但不同带的packing loads在同一source位置相加，不能把其objectives免费相加。母目标尚缺的正是跨带共同预算，而不是进一步计算某一带的常数。

## 3. 真正有限几何orbits的精确门槛

设一个共同有限cube-preserving Euclidean-isometry群G同时作用于整个多尺度family，family有L个orbits。有限群有共同固定点；移到该点后，其线性部分是signed permutations，故|G|≤2^n n!，N≤L·2^n n!。结合(1)，

  V/Q*≤L·2^n n!/a^n
   =L sqrt(2πn)[2n/(ea)]^n[1+O(1/n)]。             (3)

更明确的Stirling上界可用乘子exp(1/(12n))替换[1+O(1/n)]。这里指数底数的常数是2/e，不能漏掉e或用2代替精确门槛。

若a=cn、c>2/e，任何多项式L都指数容易；a=n²时上界为

  L sqrt(2πn)[2/(en)]^n[1+O(1/n)]。

所以有限几个signed-permutation orbits即使看起来N很大，在允许选择a≈n²的一般维数证明中仍自动通过预算。真正大族可有巨大orbit数、平移周期的近似结构或其它积分压缩；不能把非有限平移周期结构冒称同一个有限Euclidean symmetry群。

## 4. 对称压缩可以精确保留共同source竞争，但本身不改善界

若上述真实共同群存在，任意最优packing可群平均，目标不变且仍可行。因此最优λ可取每orbit一个常数x_s。记orbit大小N_s、star体积d_s及真实source count

  k_s(y)=#{j∈orbit s:y∈A_j}。

精确的全packing是

  Q*=max_{x_s≥0}{Σ_sN_sd_sx_s:
                    Σ_sk_s(y)x_s≤1 对全部y}。       (4)

这是所有尺度共同的count-vector约束。不能用每orbit各自最坏点独立付款，也不能只在一组receiver中心检查它。群平均只利用cube几何，不要求原输入坐标独立。

以下两orbit公式只准确记录竞争项，不称新一般改善。令K_s=max_yk_s(y)、p_s=k_s/K_s、q_s=N_sd_s/K_s。单orbit由对称性有最优q_s。若

  H=max_y[p_1(y)+p_2(y)]=1+ρ， 0≤ρ≤1，

则共同可行packing给Q*≥(q_1+q_2)/H。记U_s为各orbit的小cube receiver、J=|U_1∩U_2|、V=|U_1∪U_2|。每orbit同尺度，(2)给q_s≥|U_s|/P，故

  V/Q*≤P(1+ρ)/(1+J/V)。                           (5)

(5)展示真实source竞争与receiver重叠必须一起付款。两orbit本身至多2P，不能据此声称找到了大规模根阶机制；多orbit时同时max profiles与receiver实际union之间没有已证的统一根阶关系，任意权重混合也必须服从(4)。单独report source profile下降、receiver overlap下降或冻结某套weights，都不是一般packing下界。

## 5. 收束

已知筛选与窄带付款不再延伸。本轮主代理共享的真实budget-hard有限来源说明母目标没有被N40或少orbit的容易现象绕开。下一项有内容的全族证明必须将N无关的多尺度receiver union几何与同一个source预算联系起来，例如证明(4)中存在达到根阶目标的共同可行weights，或在择源面上给出完整可吸收机制。

本稿没有证明这种关系。source-overlap/receiver-overlap比率只列为准确未付竞争，辅助来源选择自由与实际未付receiver均保留；不把有限样本、同尺度账或对称压缩本身称为一般改善。

本机研究venv仅作精确符号核对：(2)的objective系数两种写法残差为0，旧N40门槛准确为5/8；未运行任何新候选优化或数值扫描。
