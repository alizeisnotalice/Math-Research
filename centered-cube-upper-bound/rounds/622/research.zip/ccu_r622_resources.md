# R622 数值阶段资源与来源账目

依据 `/tmp/ccu_r622_compute_index.json`、`/tmp/ccu_r622_numeric.json`、`/tmp/ccu_r622_interval.json`；没有重跑计算。

## 已记录的运行规模

- 共记录 16 个结果条目，最终 `shard12` 阶段标为 complete，3646/3646 shards 完成。
- 前12案的先前批次记录为墙钟 20.3591 秒、worker CPU 合计 30.71807 秒。
- 最终 `shard12` 阶段记录 13 workers、墙钟 73.1469 秒、CPU 合计 940.222266 秒。分维 CPU 合计为 n=7: 4.800445 秒、n=8: 15.019129 秒、n=10: 119.352645 秒、n=12: 801.050047 秒。
- compute index 的全记录 CPU 合计为 970.940336 秒，恰为先前批次与 shard12 CPU 合计；没有足够记录给出各阶段可相加的总墙钟时间。
- 所以 13 workers 是该阶段的并行上限/配置，不能据此声称全程持续满载。机器在 2026-10-28 03:36:45 和 03:36:46 的两次 top 样本分别显示 user 90.9%、system 6.19%、idle 3.71%，以及 user 88.4%、system 1.76%、idle 10.18%；这是两次瞬时采样，不是全阶段负载均值。样本中有13个 Python 进程，各约16–17 MiB RSS。

## 内存口径

- 记录的最大单 worker 峰值 RSS 为 28,114,944 bytes（约26.8 MiB）。
- `shard12_peak_worker_rss_sum_upper_bytes=365,494,272` 是13个单 worker 峰值的保守相加上界，不是同期实际总 RSS，也不能当作实测并发峰值。
- top 样本中各进程16–17 MiB与单 worker峰值字段的采集口径/时点不同；记录未给同步进程级 RSS 快照，故不推断全局峰值内存。

## 脚本版本与可复现性

- 三个命令都调用 `/tmp/ccu_r622_numeric.py`，参数阶段依次为 `first --workers 1`、`remaining --workers 11`、`shard12 --workers 13`。
- compute index 记录首次执行 SHA-256 `da3a53b53b887b1491b6a13e686dd5b39e453b95429813b5d4fe816205df5164`，pre-shard SHA-256 `e2c71917b72bb9909e363065be824f06d6136cf778d77f4c3d07127fc0704e22`，以及最终/current SHA-256 `375aca5e26fe78c12919d0127fa603912214e5084d848f796848dfbb0d79eaf0`。`numeric.json` 也记录最终脚本哈希为 375aca…；当前 `/tmp/ccu_r622_numeric.py` 的实测哈希与之相符。
- 阶段间生产脚本发生过变化。现有索引把 first 的执行哈希记为 da3、pre-shard 哈希记为 e2、最终 shard12/current 哈希记为 375；numeric 数据以最终哈希为顶层哈希并保留 `prior_script_sha256=e2…`。每个较早结果行没有各自的执行哈希，因而不能逐行精确归属版本。当前源文件可用于重新运行这些阶段，但现有文件不足以逐字恢复/验证 da3 与 e2 两个历史版本；这不影响“记录中任务已完成”的状态，但限制旧批次的版本级复现。
- 独立 interval 检查记录作者代码哈希 e2…、检查脚本 SHA-256 `659d40d3b086e586a5d2e18351e2d7ba2e285fb07c7be080354bd98c2b5e57d6`；当前检查脚本哈希与记录相符。该检查仅覆盖 n=2,3,4、B=2,3,4 的九个小型穷尽有理数案例，墙钟 1.34730 秒、CPU 1.34087 秒、峰值 RSS 25,280,512 bytes；明确不是对高维 shard 结果的独立复核。

## 证据边界

数值 JSON 中 `certified_union_advantage_lower` 在各案均为0；索引还明确说明 inner-grid gap 本身不证明真实多尺度增益。因此本账目只确认运行记录、阶段规模、资源与版本字段，不把数值结果升级为一般定理或严格证明。

## 最终归档补记

主代理将独立小例脚本改为可携带参数入口，并实际重放九案；归档的 interval JSON 已替换为这次新收据，作者最终生产哈希为375aca…，检查脚本哈希为c63e97…，墙时约1.33秒。另实际不分片重算 n7/B12，与分片所有计数和分数一致，约3.83秒。旧版本说明仍作为历史来源边界，未改写早期执行事实。

最终证明已使用单尺度积分为1的Markov上界，相关 `markov_certified_union_advantage_float` 与上面的纯外网格差字段含义不同；严格值可从内体积分数和精确单尺度上界重建。单靠资源账目不认证定理，最终数学范围及半胞平滑勘误见REPORT.tex、AUDIT.md。
