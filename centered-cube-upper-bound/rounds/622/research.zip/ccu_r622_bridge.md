# R622：R006 连续多尺度 receiver 的压缩 packing 合同

**关键结果。** R006 的同一个真实 L1 见证已经给出这一连续多尺度 family 的 source-primal 上界；配合其真实 receiver union 下界，可以严格检测 `V/Q*>2.1365`，不必先求一个新 LP 或把网格点数当体积。还可给出覆盖整块 receiver 的可检查有限截断。此处没有证明新的根阶上界；下界来源是指定 R006 证书，本稿不冒充重新独立认证其数值。

仅阅读指定 `lower/round006/proof.md`；没有读历史、运行数值、修改仓库。

## 1. 连续合法 family：先合并同尺度标签

为避免与 dilation a 混淆，记周期格距为

`h_1=(8^(1/7)+288^(1/7))/2`，
`h_2=...=h_7=(1+2^(1/7))/2`，
`Λ=diag(h_i) Z^7`，`F=Π_i[-h_i/2,h_i/2)`。

R006 长度标签 `ell∈{1,2}×{1,2,3,4}^6` 给质量 `m_ell=Πell_i`、真实公共半径

`r_ell=m_ell^(1/7)/2`，`|[-r_ell,r_ell]^7|=m_ell`。

令 D_ell 是 R006 已严格内缩 epsilon 后、连同128反射的 admissible-center boxes。每个 x∈D_ell 的**同一个**半径 r_ell cube 包含该标签所有 bump，因而对其同一周期来源有质量≥m_ell。

按真实 m 合并 `D_m=∪_{ell:m_ell=m}D_ell`。若需要唯一 r(x)，可取

`E_m=D_m\∪_{m'>m}D_m'`，`E=∪D_m`，`r(x)=m^(1/7)/2` 对 x∈E_m。

这是有限可测选择，选取该点最大的已证 admissible 半径；不同标签同半径不重复发 source 预算。也可保留 labelled actions，但须清楚不是8192个独立尺度。每个原小 receiver 定义为

`B_x=x+(-r(x)/a,r(x)/a)^7`，`A_x=x+(-r(x),r(x))^7`。

任意 a>1 都合法，且真实连续 receiver `U_a=∪_{x∈E}B_x` 包含 E。后续所有 receiver 体积均为 Lebesgue 体积。

## 2. 一周期的共同 load；不能每尺度各领一份 source

取单位质量、支撑在 `[-eta,eta]^7` 的对称 bump，eta为R006采用的epsilon/2。周期重复后在 torus F 上得到质量恰1的 L1 来源 μ_T。

对 canonical family 的任意非负有限中心 measure π_m（支撑E_m），定义完整 periodized load

`L_pi(y)=Σ_m ∫_{E_m} K_m(y−x) dπ_m(x)`，
`K_m(z)=Σ_{q∈Z^7}1_{||z+diag(h_i)q||∞<r_m}`，

并要求 `L_pi<=1` a.e.于F。kernel中的image sum是计数，不是modulo后只留一个0/1 indicator；cube可能跨多个周期。每个m只需有限images，其界须按r_m和h_i核验，不能只把 finite source collar 的2直接当成全load的image截断。

packing目标为

`Q_cell(pi)=Σ_m m·π_m(E_m)`。

同一个周期source满足 `μ_per(A_x)>=m`，Tonelli给

`Q_cell(pi)<=∫_F L_pi dμ_T<=1`。                    (1)

非空family与有限有界periodized kernel给 `Q_cell*>0`；因此 `0<Q_cell*<=1`。而R006真实内缩 receiver 满足 `|E|>2.1365`，所以

`|U_a|_torus/Q_cell* >= |E|/Q_cell* >2.1365`。       (2)

这里torus receiver取全部B_x的周期并；周期source并非R^7上L1见证，故(2)需要下一节finite collar才能直接接原有限合同。它本身已是准确的共享多尺度半无限packing模型。

### 有效且无损的轨道压缩

共同反射与后六坐标置换群 `G=(Z/2)^7⋊S_6` 保持格子、半径m、对称来源及全部admissible domains。长度标签尾部按四类multiplicity轨道存储，最多 `2·binom(9,3)` 种尾multiset/首轴类型；轨道包含 `6!/Πn_t!` 个标签。

对任何可行π作全G平均，load可行、Q不变；因此可在G-invariant packing measures中取同一sup。必须把轨道images及multiplicity完整加进load；receiver domains的重叠仍算真实union，不能乘multiplicity后直接加盒体积。canonical最大m选择也G-invariant。空间轨道压缩不等于各尺度独立优化。

## 3. 合法接回R^7：finite collar 与显式有限中心截断

沿用R006：receiver胞指标 `[-K,K]^7`，source胞指标 `[-K−2,K+2]^7`，单位bumps和实际r_m。令f_K为其有限L1来源，`||f_K||_1=(2K+5)^7`；它在上述receiver胞的每个x上对对应A_x仍有平均≥1。

取R006的 `theta<1` 并令 `μ_K=f_K/theta`，则全部stars满足source-primal需求 `μ_K(A_x)>=|A_x|`。连续center body

`E_K=∪_{q∈[-K,K]^7∩Z^7}(diag(h_i)q+E)`

具有真实体积 `(2K+1)^7|E|`，周期胞间内部不交。任意连续measure packing、尤其任意有限中心packing，都满足

`Q_K<=M_K=(2K+5)^7/theta`。

其small receiver union包含E_K，故

`V_K/Q_K* >=theta |E| ((2K+1)/(2K+5))^7`。          (3)

R006对内缩损失的现成严格下界为

`|E|>=L−D_epsilon`，
`D_epsilon=128·327·14·epsilon·2^6`。

因此(3)右侧正是R006已认证的有限L1比值下界，严格大于2.1365。全部collar、theta、epsilon费用保留；没有把无限周期source直接当成R^7的L1输入。

### 不枚举连续中心也能给可检查finite family

E_K是有限closed内缩boxes之并。对每个label box `D_ell=Π[p_i,q_i]`，沿坐标放包含两端点的有限等距网格，令间距≤`r_ell/a`。每个box点距某个网格中心的∞距离≤`r_ell/(2a)<r_ell/a`。中心仍在已证admissible box；若多个标签重复该中心，改用canonical最大已证半径只会扩大其B_x，保留覆盖。

因此这些有限中心的小cubes覆盖**整块**E_K；原source仍可行，有限family仍有(3)的相同比值下界。每box中心数可用

`Π_i(ceil(a(q_i−p_i)/r_ell)+1)`

显式控制（零宽情形略去）。这是体积覆盖证书，不是点数体积近似。使用实际代数半径即可精确表述；若要求完全有理数据，必须用已有root区间和内缩余量另认证半径/spacing取整后的覆盖及source containment，不能直接把r替成浮点数。

巨大K不应实际展开；该finite存在性由周期interior、有限label模板与已付collar给出。要研究更小finite候选，可以截取模板和receiver cells，但须单独重新付其边界体积，不能沿用(3)的整周期下界。

## 4. 一个真正区分单尺度与多尺度的约束

对任意固定r的周期来源平均

`g_r(x)=μ_per(x+[-r,r]^7)/(2r)^7`，

周期Fubini严格给

`∫_F g_r(x)dx=μ_T(F)=1`，
`|{x∈F:g_r(x)>=1}|<=1`。                           (4)

这里是积分为1；uniform probability平均为 `1/|F|`，不能混淆归一化。周期点源及对称bump都满足此式。每个m的全部labels必须先合并后应用(4)，所以其真实center union upper可与1取min。

R006总center union>2.1365因而是多个真实r联合的收益，不是把同尺度标签重复计算。至少三个真实尺度才可能达到该体积。对finite collar，固定尺度在receiver胞中的对应平均上界要保留 `((2K+5)/(2K+1))^7`，threshold theta时再乘theta^{-1}；只有极限才回到(4)。

记 `P=((a+1)/a)^7`。这与已知同尺度 `λ_j=v_j/[2(a+1)r]^7`、`Q>=V/P` 完全相容：问题是不同m的packingload共享同一个预算(1)。把各m的最优packing相加可能超load，已有source质量1正是同时阻止重复付款的完整证据。

## 5. 对一般估计的意义与限制

本次超出一个形式接口的内容是：真实R006完整连续receiver与同source证书，已经产生可严格检查的 `V/Q*>1` 多尺度family；无需先在易例上寻找数值比值。periodized kernel和G平均保留完整尺度竞争，finite网格覆盖加collar合法连接原有限packing合同。

尚无新的一般维数上界。尤其 source上界1只是primal certificate，不等于已经算出Q*=1；未证明continuous-measure最优与某个任意采样family的最优相等，也未将orbit压缩当成各label独立。若要得到一般根阶，仍须控制所有尺度共同load下的receiver/packing比值，不能从(4)逐尺度求和获得目标。

按用户数学工具偏好，仅实际用研究venv的SymPy核验 `(2r_m)^7=m`、receiver dilation、finite-collar比例及K→∞边界因子；没有数值评估、LP、扫描或重新计算R006 union。完成停止。
