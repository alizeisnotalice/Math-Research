import importlib.util,sys,math,itertools,hashlib,json,time,platform,resource
from pathlib import Path
from fractions import Fraction as F
start=time.perf_counter();cpu=time.process_time();sys.dont_write_bytecode=True
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--model',type=Path,default=Path(__file__).with_name('ccu_r622_numeric.py'));ap.add_argument('--output',type=Path,default=Path(__file__).with_name('interval_replay.json'));args=ap.parse_args()
p=args.model;spec=importlib.util.spec_from_file_location('r622_readonly',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
a=F(21,20);den=10**9
# Independent enumeration of all labeled bins and all axis-length tuples.
def kth(v,n):
 lo,hi=0,den*8
 while lo+1<hi:
  z=(lo+hi)//2
  if z**n<=v*den**n:lo=z
  else:hi=z
 return lo
def check(n,B):
 hist={}; ints={};outs={}; dims=list(itertools.product(range(B),repeat=n)); lengths=list(itertools.product((1,2,3,4),repeat=n))
 for ls in lengths:
  m=math.prod(ls);q=kth(m,n);rl=F(q,2*den);rh=F(q+1,2*den)
  def axis(ell,r):
   # choose ell nearest lattice points to any x in the nonnegative half-cell
   k={1:0,2:0,3:-1,4:-1}[ell];return ((k+ell-1)*a-r,k*a+r)
  for box in dims:
   ia=oa=True
   for b,ell in zip(box,ls):
    lo=F(b,2*B)*a;hi=F(b+1,2*B)*a;li,ri=axis(ell,rl);le,re=axis(ell,rh)
    ia=ia and li<=lo and hi<=ri;oa=oa and le<hi and lo<re
   if ia:ints.setdefault(m,set()).add(box)
   if oa:outs.setdefault(m,set()).add(box)
 for box in dims:
  key=tuple(sorted(box));hist[key]=hist.get(key,0)+1
 for key,count in hist.items():
  counts=[key.count(i) for i in range(B)]; assert count==math.factorial(n)//math.prod(math.factorial(v) for v in counts)
 allin=set().union(*ints.values()) if ints else set();allout=set().union(*outs.values()) if outs else set();assert allin<=allout
 result=mod.case((n,B));assert len(allin)==result['lower_boxes'] and len(allout)==result['upper_boxes']
 scale=[]
 for i,j,m,ni,no in result['scale_counts']:
  assert len(ints.get(m,set()))==ni and len(outs.get(m,set()))==no;scale.append([m,ni,no])
 return {'n':n,'B':B,'bin_boxes':len(dims),'assignments':len(lengths),'inner_union':len(allin),'outer_union':len(allout),'scale_counts':scale,'histogram_multiplicities_checked':len(hist)}
rows=[check(n,b) for n in (2,3,4) for b in (2,3,4)]
out={'cases':rows,'author_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'nine tiny exhaustive rational checks, not the large-dimensional computation'}
args.output.write_text(json.dumps(out,indent=2)+'\n');print([(r['n'],r['B'],r['inner_union'],r['outer_union']) for r in rows]);print('wall',out['wall_seconds'],'author hash',out['author_sha256'],'script hash',out['script_sha256'])
