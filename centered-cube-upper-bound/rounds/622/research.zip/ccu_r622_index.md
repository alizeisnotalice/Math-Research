# R622 七维思路与下界模型：有界来源索引

只读检查了专用项目索引、R616 归档目录清单与报告、七维下界 R006 证明及少量当前轮次摘要。没有全量解压、运行数值任务或改动仓库。

## 最值得继续读的三项来源

1. **七维有限 L1 下界、连续 receiver-union 的精确压缩：**
   `/Users/zhengzhihao/Desktop/T/Math-Research-cube-dim-7/cube-dim-7-bounds/lower/round006/proof.md`
   索引：`.../cube-dim-7-bounds/README.md`。这是当前找到的最明确“真实接收体积 + 下界”模型：长度族 `{1,2}×{1,2,3,4}^6` 共8192个带标签源块；每块质量参数 `m=∏ℓ_i`，共同半径 `r=m^(1/7)/2`。每个源块可接收的中心区域是一个坐标盒（原文以格点索引 `q` 写成端点）
   `R_{ℓ,q}=∏_k [max(0,(q_k+ℓ_k−1)a−r), min(a/2,q_k a+r)]`。
   关键计算量是完整连续并集 `|∪_{ℓ,q}R_{ℓ,q}|`，不是盒体积直接相加。六尾长度按多重集轨道压缩，乘数为 `6!/∏_s m_s!`；先按首坐标切片，递归计算活跃盒的低维并集截面，再由 Fubini 合回。这是精确的对称性降维；证明还用 inward/outward 有理盒夹逼并集端点，最后有限 L1 bump 平滑得到 `C7>2136578727666/10^12≈2.136578727666`。范围是固定 n=7 的严格下界；不是根阶下界或一般 n 族，也不是 R619 的选中星/支付模型。其 `a` 是该晶格模型中的间距参数，不能未经变量对应证明便把 `8192/a^7` 当成 R619 的 `N/a^n` 负载。

2. **七维 cube-cap 机制的任意维迁移与连续 Lebesgue 积分：**
   `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/616/README.md`；归档中的完整证明是 `rounds/616/research.zip` 内 `REPORT.tex`，实际联合账说明在 `actual_caps_results.tex`，可移植计算公式在 `actual_caps.py`。单见证的连续加权 cap 积分为
   `H(u;c,t)=2^{-n}∫_{||z||∞<t, ||u−z||∞≥c max(1,||z||∞)} max(1,||z||∞)^{-n} dz`。
   反射和坐标单调性让单 cap 上确界落在角点 `u=α·1`。在那里将中心空间按 `||z||∞=ρ` 分成内立方体与面壳，面交长为 `L_i(ρ)=min(2ρ,(1+c)ρ−u_i)`；捕获面面积为
   `S(ρ,u)=Σ_i(1+1_{u_i<(c−1)ρ})∏_{j≠i}L_j(ρ)`。
   因而可以直接做一维壳积分，而不是采样全部 n 维 receiver 空间。角点令 `ℓ_a(ρ)=(1+c−α/ρ)/2`，得到
   `J_a=1−ℓ_a(1)^n+n log t−(n/2)∫_1^t ℓ_a(ρ)^(n−1)dρ/ρ`。
   该 cap 进入有限 a 的一般输入/全尺度弱型上界；数值族取 `a→∞` 后为
   `C_n≤[(1+1/t)^(n/2)+√B_n(t)]²`,
   `B_n(t)=1−((1+1/t)/2)^n+n log t−(n/2)∫_1^t[1+1/(2t)−1/(2ρ)]^(n−1)dρ/ρ`。
   R616 报告证明这个单见证上界族的最优渐近仍是 `n log n−n log log n+O(n log log n/log n)`，不是算子下界；n=7 有严格有理标量/Arb 证书，但最优参数扫描本身不证明连续全局最优。

3. **同一真实 selection 的多见证连续 cap 与支付障碍：**
   R616 `REPORT.tex` §“Joint witnesses with the complete ledger”及 `actual_caps_results.tex`。归一化真实见证中心为 `u_k=(y_k−x)/((a+1)r_0)`，`s=max_k r_k/r_0`、`m_s(z)=max(s,||z||∞)`，多 cap 连续权积分为
   `H_T=2^{-n}∫_{||z||∞<t}m_s(z)^{-n} 1_{∀k:||u_k−z||∞≥c m_s(z)} dz`（若 `s≥t` 则置零）。完整账是
   `η|U|≤(1+A_a/τ)∫|f(x)|[pτ+W_tail+P H_T−O_P]dx`，
   其中新增 `(p−1)τ`、真实尾项和重复捕获信用都保留。这里积分仍是连续 Lebesgue 量，实际见证点不替换为方便的角点；R616 对一个 n=3、4096候选、p=8 的有限记录，以24^3个矩形盒做有理内外包络，严格认证几何上界改善。这个例子不是一般来源加权/根阶结论。数值角点 Hadamard 样本在 n=7 只是 Sobol 探路；不能拿来当实际下界或严格积分界。

## 当前 N/a^n 筛选及可用的大 N 候选

- R619/620/621 的摘要在 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/{619,620,621}/README.md`。R619 的 40-star、n=2、a=8 例确有 `N/a^n=40/64=0.625`，全部已经在旧付款族内；R620 说明现存12个 profile 也不满足简化树 DP 的严格前提，且分源只在11/12个有限配置取得证书。R621 进一步保留全局择源自由，仍指出高难完整家族的全局择源与累计几何收益未解决。
- R616 `selection.json`（位于上述 research.zip）有 N=4096 的实际选择历史，n=2、a=8 时选中数从113到1740；τ=1的三个历史选中数1703、1719、1740，数量上显著超过 `a^2=64`。它是值得进一步做精确 union-volume / source-LP 筛查的本机候选，且 quarter-grid occupancy 可以重建实际连续小盒并集。**现存 R616 报告只称它为有限 point-load/cap 诊断，不提供该大 N 家族的 V/Q*付款证书或 `C_n` 下界；因此只能列为候选数据，不可称已绕开付款障碍。**
- 真正有严格下界且保持全连续接收中心体积的模型仍首选七维 R006 晶格 union。它的8192是几何标签数、`a` 是晶格间距，不能与 R619 的选中 star 数、膨胀倍数直接并列。要检验 `N≫a^n` 付款条件，需先在同一选择/测度定义下构造 `N`、`a`、连续 `V` 和 `Q*`，再判断是否仍属已付族；目前所查摘要没有已证的同一接口映射。

## 状态、复现边界

七维项目入口 `/Users/zhengzhihao/Desktop/T/Math-Research-cube-dim-7/cube-dim-7-bounds/README.md` 与 `STATE.md` 说明七维专项停止、下界暂停；R006复核入口为 `audit/round006/lower/recheck.py`，有理输出在 `lower/round006/results.json`。一般覆盖主仓库入口 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/README.md` 当前索引到R621，并明确一般 `n^(1/2+o(1))` 目标未闭合。R616 的Sobol两scramble和角点诊断是探索证据；一份三维多 cap 包络和R006的七维下界另有有理/精确有限证书；一般 n 结论依靠各自解析证明，不能由有限样本升级。
