# R622 复现与证据边界

完整论证在 REPORT.tex；不编译 PDF。一般根阶上界未闭合。

本轮数值使用：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
主计算及证书只需 Python 标准库（整数、Fraction、进程池）；没有实际运行 MATLAB、Arb 或优化器。

## 必须采用的平滑勘误

最终有限来源证明以 REPORT.tex 和修订后的 ccu_r622_interval.md 为准：每个**半胞 bin**每侧收缩 epsilon/2，bump 半径 epsilon/4。这给出反射后 `(s/B - 2*epsilon)^n` 的真实体积，并有严格包含余量。

生产脚本及其自动生成的文字曾称每侧收缩 epsilon，存在二倍归一化错误。独审已修正明确见证参数；所有整数计数、根界和已保存的有限比值分数均不变。保留生产脚本实际执行字节以维持哈希来源；脚本中该旧注释不是最终证明。不得继续引用错误的每侧缩量。

## 轻量实际检查

在解压目录运行：

```sh
python verify.py
python ccu_r622_interval.py --model ccu_r622_numeric.py --output /tmp/r622-small-replay.json
```

第一项核16案准确分数、计数边界、3646分片唯一覆盖与聚合，及成员哈希，不重算大维并集。
第二项独立枚举 n=2,3,4、B=2,3,4 的全部标号盒和长度向量，比较每尺度与并集。
根代理已实际用归档版本重放九案通过。归档的 ccu_r622_interval.json 正是最终版本的新收据；早期检查仅留哈希和说明，不再存同样数据的重复副本。
monolithic_replay.json 是另一次实际 `(n,B)=(7,12)` 不分片重算，对比全部逐尺度计数、并集计数及有限分数均吻合，约3.83秒。其余三个 B=12 大例没有在本轮再次独立重算。

## 完整数值复现

使用独立输出目录，按顺序运行：

```sh
python ccu_r622_numeric.py --phase first --workers 1 --output-dir /tmp/r622-full-replay
python ccu_r622_numeric.py --phase remaining --workers 11 --output-dir /tmp/r622-full-replay
python ccu_r622_numeric.py --phase shard12 --workers 13 --output-dir /tmp/r622-full-replay
```

前两步运行12案；最后一步将四个B=12案拆为3646个动态分片。最后一步有112秒保护，慢机器可能产生 partial_timeout；只能把 N=B^n、完整汇总的案列为完成，不能把未完成任务当完整上界。重跑时应使用新目录，脚本并未阻止覆盖或重复追加旧结果。

输入是固定的格距21/20、轴向长度1至4、维数7/8/10/12、bins4/6/8/12，根分母10^9，epsilon=10^-9，K=10^8，theta=1-10^-8。无需下载原七维源码即可复现这组新实验。原R006的2.1365见证只作为已提供资料使用，本轮没有独立重算该旧值。

脚本第一、第二阶段和最终分片阶段的历史哈希不同，详见 ccu_r622_resources.md 与 compute index。最终生产脚本保留了实际分片执行版本；早期版本未逐字归档，不声称可以重建其每个历史字节。数学核心现版本已通过最终小例重放与一个较大案的聚合比对。

## 计数、证明和性能的区别

JSON中的整数和准确分数是有限模型证书数据；其连续几何与有限L1含义由报告中证明连接。展示小数不替代分数。维数有限、长度菜单有限，外夹逼不能当全算子的上界，不能外推维数阶。

13 workers是运行配置；近满载由两次系统采样另行确认，不代表全程持续同一占用。阶段CPU时间之和与墙钟分别记录。26.8MiB是最大单worker峰值，13倍是保守相加，不是同步实测总内存。

最终审查修复了平滑参数文字，并保留完整来源/receiver/collar/阈值费用。仍缺任意输入、全尺度的统一共同packing下界，未宣称一般闭合。
