import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
A=F(21,20);EPS=F(1,10**9);THETA=1-F(1,10**8);K=10**8;ROOTDEN=10**9

def floorroot(v,n):
 lo=0;hi=1
 while hi**n<=v:hi*=2
 while hi-lo>1:
  md=(hi+lo)//2
  if md**n<=v:lo=md
  else:hi=md
 return lo

def comps(n,b):
 if b==1:yield (n,);return
 for i in range(n+1):
  for q in comps(n-i,b-1):yield (i,)+q

def test(hist,opts,target,W):
 bits=1
 for idx,count in enumerate(hist):
  mask=opts[idx]
  if not mask and count:return False
  for _ in range(count):
   v=0
   if mask&1:v|=bits
   if mask&2:v|=bits<<1
   if mask&4:v|=bits<<W
   if mask&8:v|=bits<<2
   bits=v
 return bool((bits>>target)&1)

CACHE={}
def make_scales(n,B):
 key=(n,B)
 if key in CACHE:return CACHE[key]
 a=A;scales=[]
 for j in range(n+1):
  for i in range(2*(n-j)+1):
   if (i+1)//2+j>n:continue
   m=(2**i)*(3**j);q=floorroot(m*ROOTDEN**n,n);assert q**n<=m*ROOTDEN**n<(q+1)**n
   rl=F(q,2*ROOTDEN);rh=F(q+1,2*ROOTDEN);inside=[];outside=[]
   for b in range(B):
    bl=F(b,2*B)*a;br=F(b+1,2*B)*a;mi=mo=0
    for ell in (1,2,3,4):
     off=-(ell//2) if ell%2 else 1-ell//2; bit={1:1,2:2,3:4,4:8}[ell]
     lefti=max(F(0),(off+ell-1)*a-rl);righti=min(a/2,off*a+rl)
     lefto=max(F(0),(off+ell-1)*a-rh);righto=min(a/2,off*a+rh)
     if lefti<=bl and br<=righti:mi|=bit
     if lefto<br and bl<righto:mo|=bit
    inside.append(mi);outside.append(mo)
   scales.append((i,j,m,inside,outside))
 CACHE[key]=scales
 return scales

def case(arg):
 n,B=arg;t=time.monotonic();cpu=time.process_time();a=A;scales=make_scales(n,B)
 hist_count=math.comb(n+B-1,B-1);fac=[math.factorial(i) for i in range(n+1)];accin=[0]*len(scales);accout=[0]*len(scales);unionin=unionout=0;N=0
 for h in comps(n,B):
  weight=fac[n]
  for x in h:weight//=fac[x]
  flagi=flago=False
  for z,(i,j,m,ins,outs) in enumerate(scales):
   target=i+j*(2*n+1);iv=test(h,ins,target,2*n+1);ov=test(h,outs,target,2*n+1)
   if iv:accin[z]+=weight;flagi=True
   if ov:accout[z]+=weight;flago=True
  if flagi:unionin+=weight
  if flago:unionout+=weight
  N+=weight
 assert N==B**n and unionin<=unionout
 # True finite-L1 construction: strict θ<1, inward receiver bins shrink EPS per side, bump support radius EPS/2 and source collar 2 cells.
 finite=THETA*unionin*(a/B-2*EPS)**n*F(2*K+1,2*K+5)**n
 idealin=unionin*(a/B)**n;idealout=unionout*(a/B)**n
 best=max(range(len(scales)),key=lambda z:accin[z]); single=accin[best]*(a/B)**n; singleupper=max(accout)*(a/B)**n
 return {'n':n,'bins':B,'spacing':[a.numerator,a.denominator],'histograms':hist_count,'labeled_receiver_boxes':N,'scale_count':len(scales),'lower_boxes':unionin,'upper_boxes':unionout,'ideal_continuous_volume_lower':[idealin.numerator,idealin.denominator],'ideal_continuous_volume_upper':[idealout.numerator,idealout.denominator],'finite_L1_lower':[finite.numerator,finite.denominator],'ideal_lower_float':float(idealin),'ideal_upper_float':float(idealout),'finite_L1_lower_float':float(finite),'best_single_scale':{'m':scales[best][2],'exponents':list(scales[best][:2]),'lower_boxes':accin[best],'ideal_lower':float(single)},'union_gain_over_single':float(idealin-single),'best_single_scale_upper':float(singleupper),'certified_union_advantage_lower':float(max(F(0),idealin-singleupper)),'markov_single_upper_exact':[min(F(1),singleupper).numerator,min(F(1),singleupper).denominator],'markov_certified_union_advantage_float':float(max(F(0),idealin-min(F(1),singleupper))),'scale_counts':[[i,j,m,accin[z],accout[z]] for z,(i,j,m,_,__) in enumerate(scales)],'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def shard_task(arg):
 n,B,prefix,deadline=arg;startcpu=time.process_time(); scales=make_scales(n,B);fac=[math.factorial(i) for i in range(n+1)];inn=[0]*len(scales);out=[0]*len(scales);ui=uo=N=processed=0;remainder=n-sum(prefix)
 for tail in comps(remainder,B-len(prefix)):
  if time.monotonic()>deadline:return {'n':n,'prefix':prefix,'complete':False,'processed':processed,'cpu':time.process_time()-startcpu}
  h=prefix+tail;weight=fac[n]
  for x in h:weight//=fac[x]
  fi=fo=False
  for z,(i,j,m,ins,outs) in enumerate(scales):
   target=i+j*(2*n+1);iv=test(h,ins,target,2*n+1);ov=test(h,outs,target,2*n+1)
   if iv:inn[z]+=weight;fi=True
   if ov:out[z]+=weight;fo=True
  if fi:ui+=weight
  if fo:uo+=weight
  N+=weight;processed+=1
 return {'n':n,'prefix':prefix,'complete':True,'processed':processed,'cpu':time.process_time()-startcpu,'inner':inn,'outer':out,'unionin':ui,'unionout':uo,'N':N,'peak_rss':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('first','remaining','shard12'),required=True);p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--workers',type=int,default=1);args=p.parse_args();assert 1<=args.workers<=13;args.output_dir.mkdir(parents=True,exist_ok=True);path=args.output_dir/'ccu_r622_numeric.json';md=args.output_dir/'ccu_r622_numeric.md';idx=args.output_dir/'ccu_r622_compute_index.json'
 if args.phase=='first':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'platform':platform.platform(),'commands':[],'source':'symmetric 21/20-spaced periodic lattice atoms, positive finite bumps for finite-L1 lower; new family motivated by R006, not its claimed result','parameters':{'spacing':'21/20','source_lengths':[1,2,3,4],'root_denominator':ROOTDEN,'epsilon':str(EPS),'theta':str(THETA),'K':K},'results':[]};cases=[(8,4)]
 else:out=json.loads(path.read_text());cases=[(n,b) for n in (7,8,10,12) for b in (4,6,8) if (n,b)!=(8,4)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv));t=time.monotonic()
 if args.phase=='shard12':
  previous=out['script_sha256'];out['prior_script_sha256']=previous;out['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();deadline=t+112;acc={n:{'inner':[0]*len(make_scales(n,12)),'outer':[0]*len(make_scales(n,12)),'unionin':0,'unionout':0,'N':0,'completed_shards':[],'cpu':0.,'peak_rss':0} for n in (7,8,10,12)};tasks=[]
  for n in (7,8,10,12):
   for total in range(n+1):
    for prefix in comps(total,4):tasks.append((n,12,prefix,deadline))
  out['shard12']={'status':'running','expected_shards':len(tasks),'aggregates':acc};path.write_text(json.dumps(out));finished=0
  with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
   futures=[pool.submit(shard_task,q) for q in tasks]
   for f in concurrent.futures.as_completed(futures):
    r=f.result();finished+=1;a=acc[r['n']];a['cpu']+=r['cpu'];a['peak_rss']=max(a['peak_rss'],r.get('peak_rss',0))
    if r['complete']:
     a['completed_shards'].append(list(r['prefix']));a['N']+=r['N'];a['unionin']+=r['unionin'];a['unionout']+=r['unionout'];a['inner']=[u+v for u,v in zip(a['inner'],r['inner'])];a['outer']=[u+v for u,v in zip(a['outer'],r['outer'])]
    if finished%25==0:out['shard12']['finished_futures']=finished;path.write_text(json.dumps(out))
  for n,a in acc.items():
   if a['N']!=12**n:continue
   scales=make_scales(n,12);best=max(range(len(scales)),key=lambda k:a['inner'][k]);idealin=a['unionin']*(A/12)**n;idealout=a['unionout']*(A/12)**n;single=a['inner'][best]*(A/12)**n;singleupper=max(a['outer'])*(A/12)**n;finite=THETA*a['unionin']*(A/12-2*EPS)**n*F(2*K+1,2*K+5)**n
   out['results'].append({'n':n,'bins':12,'spacing':[A.numerator,A.denominator],'histograms':math.comb(n+11,11),'labeled_receiver_boxes':a['N'],'scale_count':len(scales),'lower_boxes':a['unionin'],'upper_boxes':a['unionout'],'ideal_continuous_volume_lower':[idealin.numerator,idealin.denominator],'ideal_continuous_volume_upper':[idealout.numerator,idealout.denominator],'finite_L1_lower':[finite.numerator,finite.denominator],'ideal_lower_float':float(idealin),'ideal_upper_float':float(idealout),'finite_L1_lower_float':float(finite),'best_single_scale':{'m':scales[best][2],'exponents':list(scales[best][:2]),'lower_boxes':a['inner'][best],'ideal_lower':float(single)},'union_gain_over_single':float(idealin-single),'best_single_scale_upper':float(singleupper),'certified_union_advantage_lower':float(max(F(0),idealin-singleupper)),'markov_single_upper_exact':[min(F(1),singleupper).numerator,min(F(1),singleupper).denominator],'markov_certified_union_advantage_float':float(max(F(0),idealin-min(F(1),singleupper))),'scale_counts':[[i,j,m,a['inner'][z],a['outer'][z]] for z,(i,j,m,_,__) in enumerate(scales)],'cpu_seconds':a['cpu'],'peak_rss_bytes_macos':a['peak_rss']})
  out['shard12']['status']='complete' if all(a['N']==12**n for n,a in acc.items()) else 'partial_timeout';out['shard12']['wall_seconds']=time.monotonic()-t;out['shard12']['finished_futures']=finished
 def save():
  path.write_text(json.dumps(out));lines=['# R622 high-dimensional multiscale receiver boxes','', 'A symmetric 21/20 lattice is a new test family inspired by R006, not a recomputation of its known winner. For each m=2^i 3^j the cube radius is m^(1/n)/2, the coordinate source block lengths are 1–4, and a histogram is accepted if some complete coordinate-length assignment has product m. Integer root brackets and inward/outward full-bin tests bound the true continuous receiver volume. An integer histogram multiplicity counts entire positive-volume boxes; this is not point counting. All m share one nonnegative source and threshold.','','| n | bins | histograms | scales | finite L1 lower | ideal inner | ideal outer | best single inner | inner-grid gain | best single upper | certified advantage | Markov gain |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda x:(x['n'],x['bins'])):lines.append('| %d | %d | %d | %d | %.8g | %.8g | %.8g | %.8g | %.8g | %.8g | %.8g | %.8g |'%(r['n'],r['bins'],r['histograms'],r['scale_count'],r['finite_L1_lower_float'],r['ideal_lower_float'],r['ideal_upper_float'],r['best_single_scale']['ideal_lower'],r['union_gain_over_single'],r['best_single_scale_upper'],r['certified_union_advantage_lower'],r['markov_certified_union_advantage_float']))
  lines+=['','The finite-L1 lower uses bump radius ε/2, receiver bin contraction ε, threshold θ=1−10^-8, source collar 2, and K=10^8. The periodic full-cell atom mass is 1; count × (a/B−2ε)^n × ((2K+1)/(2K+5))^n × θ is a real finite-L1 weak-ratio lower bound under the stated construction. Exact counts and rational fractions are in JSON. Inner-grid gain compares inner approximations and is not a certified difference between true unions. Markov gain uses the fact that every fixed-scale average integrates to one over a fundamental cell, so its event at level one has volume at most one. Certified advantage subtracts the largest single-scale outer bound from the multiscale inner bound and clips at zero. This is a finite diagnostic, not an asymptotic claim or a Q* optimum.'];md.write_text('\n'.join(lines)+'\n')
 if args.phase!='shard12':
  with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
   for f in concurrent.futures.as_completed([pool.submit(case,t) for t in cases]):
    r=f.result();out['results'].append(r);save();print('done',r['n'],r['bins'],r['histograms'],r['finite_L1_lower_float'],r['union_gain_over_single'],flush=True)
 out['last_elapsed_seconds']=time.monotonic()-t;save();idx.write_text(json.dumps({'phase':args.phase,'completed':len(out['results']),'workers':args.workers,'wall_seconds':out['last_elapsed_seconds'],'cpu_sum_seconds':sum(z['cpu_seconds'] for z in out['results']),'max_worker_rss_bytes':max(z['peak_rss_bytes_macos'] for z in out['results']),'script_sha256':out['script_sha256'],'commands':out['commands']},indent=2))
if __name__=='__main__':main()
