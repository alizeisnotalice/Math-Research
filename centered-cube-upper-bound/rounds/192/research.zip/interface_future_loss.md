# R192：实际 tiny-overlap 的 score 障碍、capture 曲线与逐来源未来损失

本稿给出原核和原支持下可直接回代的 score 下界，以及保留真实 Δ、同 α 和全部删除的逐 bad 来源界。它确证极小 overlap 的 target 在适当时钟区间具有高 score，但不将 score 排序或 terminal target 质量上界冒充 receiver 付款。近 target 正硬面方案在当前 tiny 域的费用也作了相容性筛查，不登记为本轮新增付款。

## IF1．同一原行、实际界面与真实 capture 时间

固定原 `(ω,V,x,j,y)`，保留原 current、FIRST、same α、Q、K0、ρ 和全部 history。写

\[
 \xi_t=c_jt/b,\quad
 C_i(v)=C(|y_i-v_i|/b),\quad
 w_t(y,v)=\prod_i\min(1,C_i(v)/\xi_t),
 \quad k_t(y,v)=\sum_i1_{\{C_i(v)<\xi_t\}}.
\]

closed threshold 等号不计入 k。辅助 t 的单点取值不改变时间积分。原 target
`A(v)=1_good ρ_y(v)J_v/(3Q_v)` 支持于 Z_g(y)，且

\[
 G(t)=\int A(v)w_t(y,v)\nu_V(dv),\quad
 e=e_g(y)>0,\quad D_A=G(ell)-G(g),\qquad
 e_t\ge e+G(t)-G(g).                                \tag{IF1}
\]

原 RT6/HG 的 capture 不是任意 a：

\[
 \tau=a/c_j,\quad h=g e^{-u_0/n},\quad
 \Delta_y(v)=w_\tau(y,v)-w_h(y,v),\quad
 T={c_j^{n/2}\over g^n\sqrt{1+\log n}},\quad
 \widehat H=\max\{a,\min[b,gc_j^{-1/2}m(s)(1+\log n)^{1/(2n)}]\},
\]
\[
 m(s)=1-s+s\phi(1/2),\qquad K_0=P_{s,\widehat H},\qquad
 \rho_y(v)=\left[1-{DK_{0,v}+\alpha_yJ_v\over T\Delta_y(v)}\right]_+
                   \text{ on the original capture set}.          \tag{IF2}
\]

Δ≤0、非原 capture 或 Q=0 槽按原 A=0 延拓。非零 far 行满足 `τ≤ell≤h<g`；若 ell≥h，时间积分先取0，不定义负钟长。所有未来曲线都保留 IF2 的原参数，未换成另一合法 future 的尺度。

原 reciprocal bad u 有 `w_g(y,u)>κ` 及 LJ17 的正 margin

\[
 m_y(u)=\log{p_yw_g(y,u)\over KQ_u}>0.
\]

定义原有符号计数（硬面闭边界保留）

\[
 N_H(z)=\#\{i:|x_i-z_i|\le H/2\},\quad
 \Delta N_H(v,u)=N_H(v)-N_H(u),\quad H=L,L^+,\quad
 j_s=\log{1-s+s\phi(1/2)\over s\phi(1/2)}.
\]

原 strictsoft 给 s>0；s=1 时 j_s=0。captured-good target 必须满足已审 LJ17

\[
 m_y(u)\le (L_\phi/L+18/b)\|v-u\|_1
      +j_s\max\{\Delta N_L(v,u),\Delta N_{L^+}(v,u),0\},
 \quad L_\phi={2\over1-e^{-1}}.                      \tag{IF3}
\]

本文不把这两个 signed 差改成无符号 crossing 数；特别两个差非正时，不能仍领取一个正硬跳项。IF3 及其 actual masks 在原积分中保留。

## IF2．原距离支持给出的全输入 tiny-score 下界

target v∈Z_g(y) 保留原距离帽

\[
 |y_i-v_i|/b\le R_n:=5\log n+1/2,\qquad \xi_g\le1.
\]

用原 `h_1=1_{[-1/2,1/2]}`、`w(r)=∫_0^1e^{-|r|/a}da`、`φ=h_1*w`、`C=h_1*max(h_1,φ)`，直接得到

\[
 w(r)\ge\tfrac12e^{-2|r|},\qquad
 C(d)\ge(h_1*h_1*w)(d)\ge\tfrac12e^{-2(d+1)}\quad(d\ge0).
\]

第一式只在 a∈[1/2,1] 上积分；第二式用两个单位盒的位移和绝对值至多1，它们的卷积质量为1。因此每个在 g 活跃的坐标贡献均至多

\[
 \log_+(\xi_g/C_i(v))\le M_n:=10\log n+3+\log2.      \tag{IF4}
\]

固定 `0<δ<1`，限制原 target 到 `w_g(y,v)<δ`，记 `L_δ=log(1/δ)`。对任意 t≤g，令 `r=n log(g/t)`。把坐标按 `C_i<ξ_t` 与 `C_i≥ξ_t` 分开，后一类在 g 的贡献至多 r/n，故

\[
 \log(1/w_g(y,v))\le M_n k_t(y,v)+r,
 \qquad k_t(y,v)\ge{(L_\delta-r)_+\over M_n}.         \tag{IF5}
\]

r<L_δ 时右侧下界为严格不等式；r≥L_δ 时仅有 k_t≥0，不能声称严格正 score。若需整数形式，当 r<L_δ 时可取 `floor((L_δ-r)/M_n)+1`。所得下界超过 n 时该 target 域为空。特别

\[
 k_g(y,v)>L_\delta/M_n,\qquad
 k_h(y,v)\ge (L_\delta-u_0)_+/M_n.                  \tag{IF6}
\]

这是来源坐标的确定性几何，不使用输入坐标独立或来源均匀密度。反之，若丢掉原 D_y 的坐标距离帽，一个极小 C_i 就能承担任意大的 log overlap，单凭 tiny overlap 不能推出此多坐标 score 下界。

## IF3．同一 reciprocal u 的 score 上界与实际排序区间

对 reciprocal bad u，`w_g(y,u)>κ`。每个在 t 活跃的坐标在 g 至少贡献 `log(g/t)=r/n`，所以对 r>0 有

\[
 k_t(y,u)<{n\log(1/\kappa)\over r}.                 \tag{IF7}
\]

这和 IF5 使用同一 y、同一物理 C/ξ 曲线。因此若

\[
 r(L_\delta-r)>nM_n\log(1/\kappa),                 \tag{IF8}
\]

则原实际 pair 确有 `k_t(y,v)>k_t(y,u)`。还必须与原 far、删除和 source 支持相交；若区间或来源不存在，不能凭 IF8 生成实际交通。该排序的方向产生正 score 差，不是原负 suffix 信用，也不是 receiver/source 积分的价格。

## IF4．真实 Δ 与 future loss 的同一曲线积分

定义原重叠时钟增量

\[
 \Lambda_{r_1,r_2}(v)=\log{w_{r_1}(y,v)\over w_{r_2}(y,v)}
              =\int_{r_1}^{r_2}k_t(y,v){dt\over t}
 \quad(0<r_1\le r_2).
\]

这里 r_1,r_2 是物理时间，不是 IF5 的无量纲 r。阈值处 w 连续，故没有遗漏 score 跳原子。实际曲线精确满足

\[
 \Delta_y(v)=w_h(y,v)(e^{\Lambda_{\tau,h}(v)}-1),\quad
 w_\ell(y,v)-w_g(y,v)=w_g(y,v)(e^{\Lambda_{\ell,g}(v)}-1). \tag{IF9}
\]

令

\[
 B_\delta(r)={L_\delta^2-(L_\delta-r)_+^2\over2nM_n}
                  \quad(r\ge0).
\]

按 IF5 对无量纲 r 积分可得

\[
 \Lambda_{t,g}(v)\ge B_\delta(n\log(g/t)).            \tag{IF10}
\]

更精确地在任意子区间直接积分同一 score 障碍。设 `r_τ=nlog(g/τ)≥u_0`，则

\[
 \Lambda_{\tau,h}(v)\ge B_\delta(r_\tau)-B_\delta(u_0),\quad
 \Lambda_{h,g}(v)\ge B_\delta(u_0),
\]
\[
 {\Delta_y(v)\over w_g(y,v)}
 \ge e^{B_\delta(u_0)}
           \left(e^{B_\delta(r_\tau)-B_\delta(u_0)}-1\right),\qquad
 {w_\ell-w_g\over w_g}(y,v)
 \ge e^{B_\delta(n\log(g/\ell))}-1.                 \tag{IF11}
\]

IF11 使用两个不交钟段的正增长因子相乘，没有把两个下界相减来声称差的下界。active 原 target 还须满足真实
`T w_h(e^{Λ_τh}−1)>DK0_v+αJ_v`；这些量的空间关系没有因 IF11 消失。

## IF5．保留 whole terminal 质量的逐 u 完整删除界

原 good、high 及合法 J future 直接给

\[
 {G(g)\over e}\le {K\int J\,d\nu\over3p_y e}
                       \le{1\over6}.               \tag{IF12}
\]

使用 `Jν≤q` 和 `p_y e≥2Kq`，并未使用 ν≤β。IF12 是上界，不能反向变成正的统一下界。

允许在原 positive pair 内保留任何时间固定的实际界面/tiny 指示 `Xi(u,v)∈[0,1]`，并要求其 target 支持于 `w_g<δ`。每个 u 固定后定义

\[
 A_u(v)=A(v)\Xi(u,v),\quad G_u(t)=\int A_u(v)w_t(y,v)\nu(dv),
\quad d_u={G_u(\ell)-G_u(g)\over e},\quad
 r_{g,u}={G_u(g)\over e}\in[0,1/6].
\]

这些是原 α 下的 masked target，不是一份重算的 capture。必须先在原正积分中对 u 作 Tonelli，再固定 u 使用它，不能将所有 A_u 当成一个共同 target 作 FTC。各自仍有无 target 删除及 `e_t≥e+G_u(t)−G_u(g)`。

令 `t_u=min(h,hit_y(u))`，hit 使用 R190 原 LCA 反函数；若 hit 超过原窗只在 h 截断。初始 alive 保证 hit>ell，非空行有 `ell≤t_u≤h`。写
`σ_g=nlog(g/ell)`、`σ_u=nlog(t_u/ell)`。去掉其他正乘子、用 `w_t(u)≤w_ell(u)`，完整原分母给

\[
 I_{\Xi}\le\int_{R_y}{w_\ell(y,u)\nu(du)\over e}
     \left[{1\over1+z_u(t_u)/e}-{1\over1+d_u}\right],
 \quad z_u(t)=G_u(t)-G_u(g).                        \tag{IF13}
\]

证明是将 `(k_v−k_u)_+≤k_v`、`−dG_u=∫A_u k_t w_tν dt/t` 代入，再积分 `(-dG_u)/(e+z_u)^2` 至真实截止；所有 bad 删除仍在 source 的截止和原分母中，未加删除次数费。

由 k≤n、IF10 及同一 r_{g,u}，可以保留

\[
 {z_u(t_u)\over e}\ge Z_{\mathrm{low},u}:=\max\left\{
 [e^{-\sigma_u}(d_u+r_{g,u})-r_{g,u}]_+,\quad
 r_{g,u}(e^{B_\delta(\sigma_g-\sigma_u)}-1)\right\}.  \tag{IF14}
\]

对实际数据 `0≤Z_low,u≤d_u`；该符号是无量纲的 z/e 下界，与本轮 CG 稿有质量量纲的 captured capacity L_u 不同。且

\[
 r_{g,u}(e^{B_\delta(\sigma_g)}-1)
       \le d_u\le r_{g,u}(e^{\sigma_g}-1).           \tag{IF15}
\]

因此 IF13 可用 `[(1+Z_low,u)^{-1}−(1+d_u)^{-1}]` 作上界，保留 whole target 质量而不把它粗放成1。原 HB 的精确 λ 校准可直接写成

\[
 \operatorname{Raw}_{\Xi}
 \le {16\Lambda\over3K\kappa}\,
 \mathbb E\sum_V\int_{E_{\rm rec}}q\,dx
       \int\left[{1\over1+Z_{\mathrm{low},u}}-{1\over1+d_u}\right]d\lambda_{x,V}.
                                                                  \tag{IF16}
\]

原 unique j、hard 帽和完整行时间界先完成后再合并，系数与 HB 相同。IF16 是实际正交通的上界，不反推未减亏损的 HB 势小。其 receiver 积分尚未证明为 ε 加 root-source 价。IF12 只给 r 的上界；即使 IF15 联合 late 条件要求 d 不小，所得 `r≥d/(e^{σ_g}−1)` 仍可有指数钟长费用，不能据此使 IF14 的后缀项统一大。

## IF6．近 target 正硬面方案的相容性筛，不另登记付款

曾筛查子支 `||u−v||_1/b≤h_0` 且 `max(ΔN_L,ΔN_Lplus,0)≥1`。reciprocal bad 的 current/J 比、去跳 log-Lipschitz 及正硬跳给

\[
 A(v)\le a(s,h_0):=[1+c_*e^{j_s-3L_\phi h_0}]^{-1},
 \qquad c_*={K\kappa\over3e}.
\]

同一 y 的 w_g Lipschitz 给 `w_g(y,v)>κe^{-18h_0}`，IF12 与逐 u 完整删除可给充分 receiver 系数

\[
 C_{\rm rec}{d_*\over1+d_*},\quad
 d_*=(\kappa^{-1}e^{18h_0}-1)\min(1/6,a(s,h_0)),
 \quad C_{\rm rec}=16\Lambda/(3K\kappa).             \tag{IF17}
\]

但当前 tiny 域 `w_g<δ<κ` 强制 `h_0>log(κ/δ)/18`。d_* 随 h_0 增，若

\[
 c_*e^{j_s}(\delta/\kappa)^{L_\phi/6}\le5,
\]

则在这个最小可相容距离处已经 `a≥1/6`、`d_*≥(δ^{-1}−1)/6`；δ≤1/7 时该充分费用至少为 `C_rec/2`，不能认证任意小 ε。这里只否定 IF17 在该参数域提供小系数的能力，不下界实际交通。原 s 的正下门还使 `e^{j_s}=O(n)`，而硬分支的 overlap 阈值可能指数小，所以不能靠忽略距离指数保留一个有利 s 因子。固定小距离时，该域又满足旧 `w_g²≥κ²e^{-36h_0}` overlap 门，不能冒称严格新增覆盖。两 signed 差非正及远 target 补集均保留。

## IF7．检查点与首个未付积分

本轮的新准确接口为 IF5–11 的实际 tiny-score/曲线下界、IF7–8 的同源 score 排序，以及 IF13–16 保 whole terminal 质量和逐 u cutoff 的原正交通界。它们保留真实 Δ、T、Hhat、同 α、Q、来源/森林和所有 s 依赖；没有输入坐标独立假设、重归一后验或跨窗免费复用。

尚未得到的是 IF16 在真实 dx、β、λ 和原捕获/硬面条件下的全局价格。target 的高 score 给增长率，whole terminal 质量却只有上界，二者尚不足以保证有足够的接收平均削减。LJ17 的 signed 界面只定位来源，不支付 adaptive current 面层；fractional capture 中未成为 Aν 的 neutral 部分也未因此取得小费。本文不重复树 reserve，不将这些量另命名为已付矩，不宣称一般目标闭合。到此停止本路线。
