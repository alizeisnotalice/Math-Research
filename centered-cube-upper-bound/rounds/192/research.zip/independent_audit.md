# R192 独立前筛检查点

仅本文件；不Git/spawn/数值/PDF/改他人。首次检查时R192目录与合同尚未落盘，先按主代理准确任务筛查，未读本轮作者稿。一般剩余是原middle s、low F_tree、晚LCA大h质量、near outerbad/tinygood交通；R191已付两片不能替它闭合。

## 1. 真正需要连接的量与来源资格

原h(P)=μ_hi(P∩B)，不是ν、β、capture或当前V质量。χ≤ν≤μ_hi及∫DK0(μ_hi−χ)≤αQJ保持同一原α；高祖先无权质量不能直接变成该weighted reserve。R191 TT一次聚合留下outside/attenuation/neutral与e_g/H0，LJ已付门之外的S_y(P)/P_x(P)仍可小。新的row subprob比率若只再用每层选择集U_Q⊂Q，数学就是LJ9已有矩界，未连接实际h/traffic则不计新几何付款。

原A沿辅助时间固定且支持Zg；pair-dependent history/low-tree/原剩余门继续留H。若要沿完整删除时钟作FTC，必须先固定source子集；纯正Cauchy门可依t/u/v，但不能因此重算α、重归一Π或挪用补集四亏损。β、ν只共父，不互支配。原K0不可由另一个合法future核替换。

## 2. 幂混核策略的最少合法接口

对任意固定0<θ<1，good p_y w_g≤KQ及A≤ρ给

    p_y A_v≤ρ_v (K/3)^θ p_y^(1−θ)(J_v/w_g)^θ。

这是同一行的点态插值，未增加独立性或来源。θ=1/2回到已审R191；它本身不支付middle soft。后续必须核原C^θ分母、current/J不同核类型及L尺度归一，不能把C当概率或丢掉n维乘积源代价。实际target v∈D_y才享target距离帽；outerbad距离与target距离不混用。

用R186 fixedΓ+时，reference保全原j/time质量L_n，不是receiver自适应Π_g。若θ随receiver或source pair选择，须先给共同正包络/有价菜单；先固定θ积分再免费选最优θ没有依据。任何幂积分都须对原合法s/L范围一致，硬面selector必须点态/Stieltjes计费，不以每个固定尺度零面抹去adaptive面。

## 3. 本阶段停止点

只有把captured/低K0的h(P)或hardface/futureloss接到实际q dx/source预算，才可登记新的完整子支或联合估计。必要支持、未知缺陷另命名、重复旧小s带均不当一般闭合。原source/window重复、所有尺度常数和有限截断极限必须保留。等待合同及准确作者/主代理命题后一次独筛与全文后审，不另攻坚或搜反例清单。

## 4. 合同补核与真正large-LCA随机边界付款：先筛

随后已读R192合同，主方向转为原LCA几何。为核preθ资格，只窄复读R189外部冻结grid_boundary_budget.md GB2–5：原μ_hi/current p/q/E在FULL单θ前固定，后续来源/历史/叶可依θ；同V products逐样本≤μ_hi²，绝不条件化后验后要求uniform。

在原initialalive且同top的pair上，S为同原有限树确定层，则

    side LCA(y,u)>S ⇔ Q_S(y)≠Q_S(u)。

证明若两点同S格，该格本身包含双点，LCA侧长≤S；反之若不同，所有包含双点的节点都在S层以上。严格>不可写≥，LCA=S时同S格；半开归属保证边界也成立。原A_ell大小不参与，旧side A_ell≥S且u初始alive的支确在新支内，但未由此认证严格FULL非空差集。

先取整行固定bad子集R'={u∈R_y:||y−u||1≤r,side LCA>S}，保持原A/α/Π/删除，R183完整行后得到λ'=1_R'λ及同ψ。再放ψ和actual current-product密度，丢同V标签，剩下fixed p_y p_u μ_hi²/q²乘fixed-S split事件。正Tonelli与原联合uniform相位给

    EΣV∫ψ dλ'≤min(1,r/S)(∫p dμ_hi/q)^2≤min(1,r/S)。

真实dx回代Raw≤Crec min(1,r/S)E∫qdx，Crec=16Λ/(3Kκ)。preθ逐x可测r/S选层沿R189原证明无层菜单；S>D_top该支为空，S=d0时所有初始pair均为largeLCA但概率系数未必小。source/window费仍原账，small-LCA质量尚未root付款。该候选是原指定交通的实际接收子支，不依独立来源或初始停块大。

## 5. fractional capture强化分母：先筛

Astra准确消息的接口通过。原χ≤ν、supportχ⊂Z_g、Aν≤χ且χ沿t终端冻结。则ν|Z_t−χ是非负递减来源，w_t亦递减，故

    e_t−Gχ(t)单调非增,
    e_t≥e_g+[Gχ(t)−Gχ(g)]=e_g+z_A(t)+z_N(t),
    z_N=∫(w_t−w_g)d(χ−Aν)≥0。

对同固定bad集，δ+≤k_v及N_R(t)≤N_ell给

    I_H≤N_ell∫(−dG_A)/(e_g+z_A+z_N)^2。

此式保实际分母/完整删除，无χ导数或重归一。hard零核可只用R191的三接口延拓，α0不除；pair-dependent low-F等仍H。χ的Zg支持是必要资格，不能用后来也被删除的捕获测度替代。只有初始neutral future质量大，未必强制其与target下降同钟重叠；该接口目前没有新增全局付款。等待作者准确共同时间/来源估计，不将neutral缺陷另命名为小矩。

## 6. pair-adaptive原层的加强与LS全文后审

主代理送准确加强后先独筛、再全文读lca_scale_geometry.md LS1–8。S允许preθ依固定x,y,u而定：先逐样本用actual λ支配到fixed current×μ²，之后每个固定pair自己的S都是确定原层，可独立套同一个θ的相位公式，再Tonelli。无需对选层求和，也不假适应来源独立。

取A_grid≥1、d1=||y−u||1，最小原层S≥A_grid d1；超顶取top并直接用原同top下largeLCA空，不能拿未达标的d1/top概率当1/A_grid。若S=d0，所有actual初始bad必跨finest，全部进入discard，因此补集无max(d0,...)；其余S<2A_grid d1，超顶也有sidePu≤Dtop<A_grid d1。故actual剩余统一sidePu≤2A_grid d1。d1=0无实际初始bad。原共同q的措辞已窄修，未把H/source改成receiver变阈值。

LS7真实价Crec/A_grid∫qdx通过，完全取消原near最坏r与初始大块限制；只定位小LCA，不支付其h或K0价，不据集合放宽认证严格FULL差集。

## 7. ordered-neutral逐u实际付款：先筛与全文后审

先筛Astra精确命题后全文读captured_joint_geometry.md CG1–19（含唯一j说明），通过。固定N_u≤χ−Aν、支持Zg，原排序阈值b_i clip到[0,log(g/ell)]并按升序逐项支配全部active target，给G_N,u(t)≥c_u G_A(t)，c_u=∫well dN_u/M_A。原e_t≥max(e,(1+c_u)G_A)，不改Π；原A支持Zg保证G_A无删除跳。逐u Tonelli/FTC及∫_0^∞dG/max(e,(1+c)G)^2=2/[e(1+c)]给

    I_H≤(1/e)∫R well(u)min(ψ,2/(1+c_u))ν(du)。

真实λ回代Crec及Σλmass≤1，选1+c_u≥2Crec/ε即支付εreceiver，原bad删除只减少正侧。N_u可依u但须沿t固定，且排序对完整Aν而非运行v；没有把sourcedependent测度视为fixedΓ。

CG15用有限esssup完整Aν定义C_u⊂Pu∩B，跨有限i可同时去零集，故排序资格准确。CG16标量weak clipping下包络L_u满足0≤L_u≤∫Cu wellχ，1+c_u≥L_u/M_A；仅标量c_cap，有理上确界可测，不借强对偶或逐点c(z)。CG19恰为h(Pu)减排序失败/物理衰减/同α费，三项均非负且完整保留。M_A0/D_A0先零，α0不除。完整付款是明确条件子支，不称这些条件由late h自动成立。

## 8. Sol界面与tiny-score接口：先筛与全文后审

先筛后全文读interface_future_loss.md IF1–17，通过。C≥.5e^(−2(d+1))及target距帽给Mn=10logn+3+log2；逐时r=nlog(g/t)下score≥(log(1/δ)−r)+/Mn，仅r<log(1/δ)时严格。积分给Bδ，真实Δ的两段lower从各自时钟段直接积分再相乘，未错误相减两个lower。reciprocal u的score上界与正score排序仅是local支持，不支付receiver或借负信用。

逐u A_u=原A·Xi先Tonelli，deadline取min(h_stop,hit)且ell≤h_stop非空才σ≥0；terminal r_g,u≤1/6是upper，未反推positive lower。IF14两个lower分别由全growth与tiny剩余clock取得，max仍≤实际z/e≤d，IF15保证可实现区间。IF16原λ系数准确，未称全局ε+root。最后仅符号L_u改Z_low,u以区别CG质量capacity，最终106b60…版无公式变化。IF17是充分费用无法小的相容性判断而非actual traffic lower，旧near门包含与tiny不相容均保留。

## 9. 一次总ε的整合与有限代码静态核

joint_budget_integration.md全文通过：0<ε≤Crec，A_grid=2Crec/ε给grid半份，捕获容量门L_u≥4Crec M_A/ε在grid补集给另一半份。原选择权限不同：S只能preθ pair数据，C_u可用已实现行/原Pu但沿t固定；没有互换这两个选择。剩余sidePu≤4Crec d1/ε和L_u门失败推出每个c_cap的h上界，方向正确，未将右侧未付物理费登记为来源预算。

已静态读lca_boundary_checks.py及ordered_loss_checks.py，未运行。前者保同phase来源、sameTop/topsep、strict>S、半开边界、pair-S超顶零支及固定current产品，不将topsep领smallLCA结论；272024相位cell的中点权重与lower-corner点态边界检查区分。后者15曲线25/45dps共30求积仅原形式clipping曲线，无删除样本不认证一般删除定理；12 Fraction标量capacity的greedy primal/断点dual相等仅有限模型核验，不作一般强对偶。两份诊断都未证明原FULL/alpha实例或维数阶数，等待最终review与主整合字节后冻结。

## 10. 最终整合窄核与冻结

已全文读proof.tex.txt、report.md、numerical_review.md、parent_verification.md及reproduce.py。LS/CG两条实际接收子支、总ε各半、原共同q、真实dx、time-fixed bad门、完整删除与源/window重复费用一致。Sol的tiny-score与Z_low,u端点仍只记准确待付款接口，没有把r_g upper反用positive lower，亦未抹掉n·sidePu或三物理费用。没有任意subprob树比率平凡推广的新root声明。

新增ordered_loss_checks.py的score_checks已静态核：n=2/4/8/16各三pattern，共12配置；C的E4两段、帽内距离、δ=√wg严格tiny、三个r位置的ξ与Mn/Bδ计算正确。35/50dps、以及15曲线25/45dps共30求积均非区间证明；12 Fraction弱capacity的有限primal/dual比较不认证一般强对偶。LCA精确相位检查只核有限几何/支配代数，非原FULL/history/α实例。主记录已实际完整重放LCA并byte一致、运行ordered全部断言；本审计未运行脚本。最终driver截至此审计仍待manifest冻结后执行，不将该未来操作认证为已运行。

reproduce入口先核manifest，再复制两脚本到新目录执行并逐byte比较完整JSON，mpmath环境需求已明示。没有PDF、Git、spawn或他人编辑。下表实算绑定14个其他最终文件，不绑定自身或尚未生成manifest，避免归档循环。

| 文件 | SHA256 |
|---|---|
| captured_joint_geometry.md | 935548498f4231d157c735f1eed3413204b6167729090ef068c7fe605bf15e80 |
| interface_future_loss.md | 106b607d35115f3f0485157e0390751561ef54bd1ec49dcff129817e41189e7f |
| joint_budget_integration.md | 0bbcb7ef26ec6e8964be31490389d5fcda95bf43877570ea6e96cf1a71454e40 |
| lca_boundary_checks.json | ae2428b049e37d01e564617007e995b8e73e0efba8add6b40d42536f3f9eea56 |
| lca_boundary_checks.py | 770d8694b6fcd6e1c37d8cdcdc45e34c3ea7fa9306d1e40e206328c7f844de1f |
| lca_scale_geometry.md | 2411a80035aded69e3e5d207c092452b9f2826b6f48533212a52c6dd8150a046 |
| numerical_review.md | 1549c32033ff926c092a31be129e8722cd30fe76beff4583a3937fe216950cd1 |
| ordered_loss_checks.json | 1e0a9cacc0ce183809d17c508f509974bf165146a0a1c2c8cff31ce3c054e331 |
| ordered_loss_checks.py | 51eaf96227c9ff75eb55d1fb31dde43b41dc75a9e537ec19637d1ea78faceb84 |
| parent_verification.md | 624416b3032eee0ea0b19558f00b00176c1b61b7558c043075bfc38123b6dd3a |
| proof.tex.txt | 94af2b382dc9a958472d145f270eb36c3b84f5d05abfaedcbf9d1fc5904daa0f |
| report.md | 17e166343a72b091eff799f0d9cf9bbb4853953ca3695fa2a8c1679c503bc12a |
| reproduce.py | 35fc17a134496e1e5e348415bb673ecf840d730b8e47ccf12092d4f55c648dec |
| task_contract.md | 34a1f037a0c75db2c16bd1e3403e6c439d7e64698544fe2d830e12e16935c2a6 |

冻结结论：pair-adaptive大LCA的真实εreceiver定位及ordered-neutral条件支的真实εreceiver吸收通过，合计只用一次预分配ε。small-LCA、排序失败/低K0/reserve不足的联合余域仍未获一般source根价；不认证严格旧FULL差集，一般中间硬层与最终弱型目标未闭合。停止本轮审计。
