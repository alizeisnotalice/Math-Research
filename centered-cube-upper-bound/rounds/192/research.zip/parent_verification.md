# R192 主核验

权威仓库/远端与main、起点cde462e已检查，开始无改动。本轮所有文件责任明确；四个复用Agent只写自己文件，不Git/spawn。上轮属于已推送实质进展，本轮没有阻塞。

主读R189 stopping_boundary_geometry全文及原GB来源合同；LS新事件先将λ正支配到preθ current×input，再逐pair选层取θ平均，未条件化已选source。读A02 skill正文，按实际正支配/误差流程，没有使用其书目作为定理。独审确认原共同q，已将q(x)明确为常值记号。LS7–8全面包含later-deleted bad，严格尺度与top overflow先处理。

主全文读CG并核CG8双测度比值、CG10 FTC积分2/[e(1+c)]、CG11逐u min和CG16 weak dual方向；neutral可随u但不得随running v或t。joint整合采用总ε各半；CG L_u为质量容量，IF Z_low,u为无量纲tail lower，已协调作者改名避免量纲碰撞。

主全文读IF，核原R128 RT6与R186 HG1实际Δ/T/Hhat，score障碍使用原坐标距离帽；r_u≤1/6不被反用。IF近target界未取得tiny域小费用，未登记新付款。CG、LS才是本轮两实际接收子支。

本机实际运行ordered脚本全部30曲线求积/12容量Fraction/12双精度score配置，断言通过；不是区间计算或FULL。主静态读LCA脚本的共同phase/bitmask实现与原top区别，并完整运行产生/tmp/r192_parent_lca.json，字节与生产一致。数值代理另独立隔离重放相同脚本。最终归档再用reproduce.py从最终冻结材料重跑两输出。

未编译PDF。只保必要Markdown、LaTeX文本、两脚本/JSON、driver/manifest，Git新增仅README/ZIP与索引；缓存、运行临时目录不入归档。一般证明未完成，剩余排序失败及低K0质量的真实joint预算明确保留。
