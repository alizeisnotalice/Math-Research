# R192：原共同祖先几何、捕获占用与中间硬层

起点main cde462e8b87d2c39c1761546a61ffd0de350148c，工作树干净、origin正确。上一轮为已核验并推送的实质进展。本轮一般目标不变，优先处理原middle s/晚合并大h/nearouterbad/tinygood/lowFtree剩余。

可用：R183完整删除与单向J能量，R188 current-product λ，R189原FULL preθ/current容量与随机网格，R190逐u合并时钟，R191实际LCA权重付款、TT一次reserve分解、空间包络。μhi、h=μhi|B、ν与β只共同父支配；sameα、K0、真实dx、原树与全window费保留。不得将任意row subprob的树比率推广重新登记为新几何，也不得把局部界面身份或近hard带替中间段闭合。

责任：Astra captured_joint_geometry.md攻h(Pu)→捕获/低K0联合可付来源；Sol interface_future_loss.md攻硬面/目标futureloss真实dx；Sol independent_audit.md独筛再后审；主攻原随机LCA几何和剩余预算整合。数值只在明确命题后派Sol medium，使用本机已有库，三阶段验证。无子代理Git/spawn，不互改文件，完成有界任务后停。

准确新增候选（主待独筛）：原y,u初始bad且||y−u||1≤r，若LCA侧长>S（S为原grid层，选在θ前），则y,u在S层异格，概率≤r/S。R188 λ支配与原preθ envelope或可直接给Crec r/S receiver付款，不依初始停止块A_ell大小；原θ依赖来源须由共同preθ包络吸收。若成立只记真实大LCA切片，不能声称留下小LCA质量已有root预算。
