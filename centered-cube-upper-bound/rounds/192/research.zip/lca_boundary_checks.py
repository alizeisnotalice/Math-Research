#!/usr/bin/env python3
"""Exact finite common-phase LCA and dominated current-product diagnostics."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,json
HERE=Path(__file__).resolve().parent
Z=F(0)
def sm(xs):return sum(xs,Z)
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 return x

def check(n,J,k,stage,mode,radius):
 top=2**J;S=2**k;radius=F(radius);atoms=[[F(0)]*n,[F(1,2)]*n,[F(S)]+[F(S,2)]*(n-1),[F(top)+F(1,2)]+[F(top,2)+F(1,2)]*(n-1)];M=len(atoms)
 mu=[F(i+1,10) for i in range(M)];p=[F(i+1,4) for i in range(M)];q=sm(a*b for a,b in zip(mu,p));P=[a*b/q for a,b in zip(mu,p)];assert sm(P)==1
 pairs=[(i,j) for i in range(M) for j in range(i+1,M)];B=len(pairs);ALL=(1<<B)-1;dist=[sm(abs(x-y) for x,y in zip(atoms[i],atoms[j])) for i,j in pairs];near=[x<=radius for x in dist]
 cuts=[];mids=[]
 for axis in range(n):
  pts={F(0),F(top)}
  for atom in atoms:
   for ell in range(J+1):
    side=2**ell;res=atom[axis]%side
    for m in range(top//side):
     t=res+m*side
     if 0<t<top:pts.add(t)
  c=sorted(pts);assert all(c[t+1]-c[t]==c[1]-c[0] for t in range(len(c)-1));cuts.append(c);mids.append([(a+b)/2 for a,b in zip(c,c[1:])])
 sizes=[len(v) for v in mids];phase_count=1
 for size in sizes:phase_count*=size
 def axis_masks(axis,theta):
  masks=[]
  for ell in range(J+1):
   cells=[(a[axis]-theta)//(2**ell) for a in atoms];mask=0
   for bit,(i,j) in enumerate(pairs):
    if cells[i]==cells[j]:mask|=1<<bit
   masks.append(mask)
  return masks
 pre_mid=[[axis_masks(axis,t) for t in mids[axis]] for axis in range(n)];pre_corner=[[axis_masks(axis,t) for t in cuts[axis][:-1]] for axis in range(n)]
 split=[0]*B;topsep=[0]*B;large=[0]*B;equalS=[0]*B;finest=[0]*B;adaptive=[0]*B;lca_counts=[[0]*(J+1) for _ in range(B)]
 scale_data={};discard_counts={A:[0]*B for A in [2,4]};discard_adaptive={A:[0]*B for A in [2,4]}
 for A in [2,4]:
  menu=[]
  for d in dist:
   req=F(A)*d;side=1;ell=0
   while side<req:side*=2;ell+=1
   overflow=side>top;limit=max(F(1),2*A*d);maxdepth=max(t for t in range(J+1) if 2**t<=limit)
   menu.append(dict(required_length=req,uncapped_scale=side,scale=min(side,top),scale_index=min(ell,J),overflow=overflow,remaining_limit=limit,max_allowed_remaining_depth=maxdepth))
  scale_data[A]=menu
 def phase_masks(indices,pre):
  masks=[ALL]*(J+1)
  for axis,index in enumerate(indices):
   for ell,mask in enumerate(pre[axis][index]):masks[ell]&=mask
  assert all(masks[ell]&~masks[ell+1]==0 for ell in range(J))
  return masks
 boundary_pair_checks=0
 for boundary,pre in [(False,pre_mid),(True,pre_corner)]:
  for indices in product(*(range(t) for t in sizes)):
   masks=phase_masks(indices,pre)
   if not boundary:
    code=sum(indices)
    if mode=='full':bn=cn=[4]*M
    elif mode=='coupled_attenuation':bn=[(code+2*i)%5 for i in range(M)];cn=[(code+i)%5 for i in range(M)]
    else:bn=[4 if (code+i)%4 in (0,1) else 0 for i in range(M)];cn=bn[:]
    assert all(0<=x<=4 for x in bn+cn)
   for bit,(i,j) in enumerate(pairs):
    same_top=bool(masks[J]&(1<<bit));Ssplit=not bool(masks[k]&(1<<bit));lca=next((ell for ell,mask in enumerate(masks) if mask&(1<<bit)),None)
    assert (lca is not None)==same_top
    event=same_top and lca>k
    if same_top:assert event==Ssplit
    else:assert Ssplit
    if boundary:boundary_pair_checks+=1
    else:
     split[bit]+=Ssplit;topsep[bit]+=not same_top;large[bit]+=event;equalS[bit]+=same_top and lca==k;finest[bit]+=bool(masks[0]&(1<<bit))
     if lca is not None:lca_counts[bit][lca]+=1
     coeff=bn[i]*cn[j]+bn[j]*cn[i];assert coeff<=32
     if event and near[bit]:adaptive[bit]+=coeff
    for A in [2,4]:
     data=scale_data[A][bit];discard=same_top and lca>data['scale_index']
     if data['overflow']:assert not discard
     if same_top and not discard:assert lca<=data['max_allowed_remaining_depth']
     if not boundary:
      discard_counts[A][bit]+=discard
      if discard:discard_adaptive[A][bit]+=coeff
 pair_rows=[]
 for bit,(i,j) in enumerate(pairs):
  formula=F(1)
  for x,y in zip(atoms[i],atoms[j]):formula*=max(F(0),1-abs(x-y)/S)
  formula=1-formula
  assert F(split[bit],phase_count)==formula and split[bit]==large[bit]+topsep[bit]
  assert formula<=min(F(1),dist[bit]/S)
  pair_rows.append(dict(pair=[i,j],distance_L1=dist[bit],near=near[bit],split_probability=F(split[bit],phase_count),split_formula=formula,same_top_large_LCA_probability=F(large[bit],phase_count),top_separate_probability=F(topsep[bit],phase_count),LCA_equal_S_probability=F(equalS[bit],phase_count),same_finest_probability=F(finest[bit],phase_count),same_top_LCA_depth_probabilities=[F(c,phase_count) for c in lca_counts[bit]]))
 weighted_split=sm(2*P[i]*P[j]*F(split[b],phase_count) for b,(i,j) in enumerate(pairs) if near[b]);weighted_same=sm(2*P[i]*P[j]*F(large[b],phase_count) for b,(i,j) in enumerate(pairs) if near[b]);weighted_top=sm(2*P[i]*P[j]*F(topsep[b],phase_count) for b,(i,j) in enumerate(pairs) if near[b]);adaptive_expect=sm(P[i]*P[j]*F(adaptive[b],16*phase_count) for b,(i,j) in enumerate(pairs));cap=min(F(1),radius/S)
 assert adaptive_expect<=weighted_same<=weighted_split<=cap and weighted_split==weighted_same+weighted_top
 adaptive_scales=[]
 for A in [2,4]:
  value=sm(2*P[i]*P[j]*F(discard_counts[A][b],phase_count) for b,(i,j) in enumerate(pairs));adapt=sm(P[i]*P[j]*F(discard_adaptive[A][b],16*phase_count) for b,(i,j) in enumerate(pairs));bound=sm(P)**2/A
  for b,data in enumerate(scale_data[A]):
   prob=F(discard_counts[A][b],phase_count);assert prob<=F(1,A)
   if data['overflow']:assert prob==0
  assert adapt<=value<=bound
  adaptive_scales.append(dict(A=A,pair_scale_data=scale_data[A],fixed_product_discard_expectation=value,adaptive_lambda_discard_expectation=adapt,full_current_mass_squared=sm(P)**2,bound=bound,remaining_same_top_bound_verified=True,diagonal_discard_zero=True,top_separate_is_not_part_of_discard=True))
 return dict(stage=stage,n=n,depth_J=J,finest_side=1,top_side=top,scale_k=k,S=S,radius=radius,atoms=atoms,mu=mu,p=p,q=q,fixed_current_P=P,source_mode=mode,source_description='beta_theta=bn/4 mu, nu_theta=cn/4 mu; same shared phase code, no independence or phase normalization',phase_cuts=cuts,open_phase_cells=phase_count,phase_cell_probability=F(1,phase_count),boundary_lower_corner_phases=phase_count,boundary_pair_checks=boundary_pair_checks,pair_rows=pair_rows,adaptive_lambda_large_LCA_near_expectation=adaptive_expect,fixed_product_same_top_large_LCA_near=weighted_same,fixed_product_top_separate_near=weighted_top,splitweighted_near=weighted_split,near_bound=cap,pair_dependent_scale_checks=adaptive_scales,all_exact_checks_pass=True)

def run():
 specs=[(1,2,0,'initial','full',F(1,2)),(2,2,1,'initial','full',1),(3,2,2,'initial','full',12),(1,3,1,'stress','coupled_attenuation',F(1,2)),(2,4,2,'stress','coupled_attenuation',1),(3,3,0,'stress','coupled_attenuation',F(3,2)),(1,5,4,'expanded','identical_adaptive_sources',F(1,2)),(2,5,1,'expanded','identical_adaptive_sources',1),(3,5,3,'expanded','identical_adaptive_sources',F(3,2))]
 rows=[check(*spec) for spec in specs]
 assert any(p['top_separate_probability']>0 for r in rows for p in r['pair_rows']) and any(p['LCA_equal_S_probability']>0 for r in rows for p in r['pair_rows']) and any(p['same_finest_probability']>0 for r in rows for p in r['pair_rows'])
 return enc(dict(schema='r192_lca_boundary_v1',arithmetic='Fraction phase partitions and fixed-current masses; integer counts inside equally weighted cells',cases=rows,summary=dict(cases=len(rows),initial_cases=3,stress_cases=3,expanded_cases=3,total_open_phase_cells=sum(r['open_phase_cells'] for r in rows),all_exact_checks_pass=True),limitations=['Finite atomic common-shift dyadic geometry and dominated-source algebra only; no original FULL/history or alpha construction','LCA exists only for same-top pairs; top-separated mass is separately recorded','The strict event LCA side>S is not the weak event side>=S','Boundary lower-corner phases are pointwise checks with zero probability weight, not additional uniform mass','Pair-dependent S is fixed from each pair before phase, including explicit above-top overflow; no random theta-dependent optimization','The same-top remaining bound is not asserted for top-separated pairs; all source costs remain with the parent proof']))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'lca_boundary_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
