import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
manifest=json.loads((base/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,name
print('Archive hashes verified:',len(manifest['sha256']))
if not a.verify_only:
 if a.output_dir is None:p.error('--output-dir required')
 a.output_dir.mkdir(parents=True,exist_ok=False)
 for stem in ['lca_boundary_checks','ordered_loss_checks']:
  dest=a.output_dir/(stem+'.py');shutil.copyfile(base/dest.name,dest)
  subprocess.run([sys.executable,str(dest)],check=True,env=os.environ.copy())
  assert dest.with_suffix('.json').read_bytes()==(base/(stem+'.json')).read_bytes(),stem
 print('Both full JSON outputs reproduced byte-for-byte')
