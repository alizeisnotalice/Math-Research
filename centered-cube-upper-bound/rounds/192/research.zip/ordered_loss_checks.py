"""Finite original-form overlap curves, not FULL/capture/history instances."""
from pathlib import Path
from fractions import Fraction as F
import json,argparse
import mpmath as mp
HERE=Path(__file__).resolve().parent

def capacity_checks():
 rows=[]
 for count in [2,4,8,16]:
  masses=[F(i+1,count*(count+1)//2) for i in range(count)]
  weights=[F(1+(i*3)%7,8) for i in range(count)]
  kernels=[F(1+(i*5)%11,12) for i in range(count)]
  total=sum((a*k for a,k in zip(masses,kernels)),F(0))
  for fraction in [F(0),F(1,3),F(1)]:
   reserve=total*fraction
   choices=[F(0)]+[w/k for w,k in zip(weights,kernels)]
   dual=max(sum((m*min(w,a*k) for m,w,k in zip(masses,weights,kernels)),F(0))-a*reserve for a in choices)
   # Residual removes largest weight per unit of kernel budget first.
   left=reserve;captured=masses[:]
   for i in sorted(range(count),key=lambda i:weights[i]/kernels[i],reverse=True):
    removed=min(captured[i],left/kernels[i]);captured[i]-=removed;left-=removed*kernels[i]
   primal=sum((m*w for m,w in zip(captured,weights)),F(0))
   assert left==0 and primal==dual
   rows.append(dict(atoms=count,reserve_fraction=str(fraction),dual=str(dual),primal=str(primal),exact_equal=True))
 return rows

def score_checks():
 out=[]
 for n in [2,4,8,16]:
  for pattern in range(3):
   histories=[]
   for dps in [35,50]:
    mp.mp.dps=dps;Rn=5*mp.log(n)+mp.mpf('.5');Mn=10*mp.log(n)+3+mp.log(2)
    ds=[Rn*(mp.mpf(1)/4 if pattern==0 else ((mp.mpf(i+1)/(n+1))*mp.mpf(3)/4 if pattern==1 else mp.mpf(3)/4)) for i in range(n)]
    def C(d):
     return 1-d+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,d)+mp.expint(4,d+1) if d<=1 else mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
    cs=[C(d) for d in ds];wg=mp.fprod(cs);delta=mp.sqrt(wg);Ld=mp.log(1/delta)
    assert 0<wg<delta<1 and all(c>=mp.exp(-Mn) for c in cs)
    rows=[]
    for ratio in [mp.mpf(0),mp.mpf('.5'),mp.mpf(1)]:
     r=ratio*n*mp.log(2);xi=mp.exp(-r/n);score=sum(c<xi for c in cs);wt=mp.fprod(min(1,c/xi) for c in cs)
     B=(Ld**2-max(0,Ld-r)**2)/(2*n*Mn)
     assert score>=max(0,Ld-r)/Mn and mp.log(wt/wg)>=B-mp.mpf('1e-30')
     rows.append(dict(r=mp.nstr(r,dps),score=score,score_lower=mp.nstr(max(0,Ld-r)/Mn,dps),actual_log_growth=mp.nstr(mp.log(wt/wg),dps),barrier=mp.nstr(B,dps)))
    histories.append(dict(dps=dps,delta=mp.nstr(delta,dps),rows=rows))
   assert abs(mp.mpf(histories[0]['delta'])-mp.mpf(histories[1]['delta']))<mp.mpf('1e-30')
   out.append(dict(n=n,pattern=pattern,precisions=histories))
 return out

def run():
 specs=[]
 for n in [1,2,4,8,16]:
  for multiplier in [F(1),F(8),F(64)]:
   # Target thresholds are coordinatewise no larger than neutral thresholds.
   target=[F(5+i%3,6) for i in range(n)]
   neutral=[v+F(2+i%2,3) for i,v in enumerate(target)]
   bad=[F(7+i%2,4) for i in range(n)]
   specs.append((n,multiplier,target,neutral,bad))
 rows=[]
 for case,(n,mult,ta,ne,ba) in enumerate(specs):
  vals=[]
  for dps in [25,45]:
   mp.mp.dps=dps
   def m(q):return mp.mpf(q.numerator)/q.denominator
   def w(a,t):return mp.fprod(min(mp.mpf(1),m(z)/t) for z in a)
   def k(a,t):return sum(m(z)<t for z in a)
   # Separate target/neutral/bad atoms, masses 1, mult, 1/3; target A=1/2.
   A=mp.mpf('.5');mn=m(mult);mb=mp.mpf(1)/3
   GA0=A*w(ta,mp.mpf(1));GN0=mn*w(ne,mp.mpf(1));c=GN0/GA0
   e=w(ta,mp.mpf(2))+mn*w(ne,mp.mpf(2))+mb*w(ba,mp.mpf(2))
   Nb=mb*w(ba,mp.mpf(1));bound=Nb/e*min(1,2/(1+c))
   cuts=sorted(set([mp.mpf(1),mp.mpf(2)]+[m(z) for ar in [ta,ne,ba] for z in ar if F(1)<z<F(2)]))
   def integrand(t):
    wa,wn,wb=w(ta,t),w(ne,t),w(ba,t)
    return A*wa*mb*wb*max(0,k(ta,t)-k(ba,t))/(wa+mn*wn+mb*wb)**2/t
   integral=mp.quad(integrand,cuts)
   samples=[(x+y)/2 for x,y in zip(cuts,cuts[1:])]
   assert all(k(ne,t)<=k(ta,t) for t in samples)
   assert all(mn*w(ne,t)/(A*w(ta,t))>=c-mp.mpf('1e-22') for t in samples)
   assert all(w(ta,t)+mn*w(ne,t)+mb*w(ba,t)>=max(e,(1+c)*A*w(ta,t))-mp.mpf('1e-22') for t in samples)
   assert integral<=bound+mp.mpf('1e-20')
   vals.append(dict(dps=dps,integral=mp.nstr(integral,dps),bound=mp.nstr(bound,dps),c=mp.nstr(c,dps),ratio=mp.nstr(integral/bound,dps)))
  difference=abs(mp.mpf(vals[0]['integral'])-mp.mpf(vals[1]['integral']));assert difference<mp.mpf('1e-20')
  rows.append(dict(n=n,neutral_mass=str(mult),target_thresholds=list(map(str,ta)),neutral_thresholds=list(map(str,ne)),bad_thresholds=list(map(str,ba)),stage='initial' if n<=2 else ('stress' if n<=8 else 'expanded'),values=vals,precision_difference=mp.nstr(difference,10)))
 return dict(schema='r192_ordered_loss_v1',cases=rows,capacity_checks=capacity_checks(),score_checks=score_checks(),summary=dict(cases=len(rows),evaluations=2*len(rows),capacity_cases=12,score_cases=12,maximum_dimension=16,all_checks_pass=True),limitations=['Original-form product overlap with fixed rational coordinate thresholds; not a certified physical source/receiver or FULL/capture/history realization','Numerical quadrature at 25 and 45 dps is not interval arithmetic','Score ordering here is exact coordinatewise threshold ordering; no independent source-coordinate hypothesis is used','Separate neutral atoms have no target weight; additional target residual is simply unused','No deletions in these examples; general deletions and time-dependent normalizers are proved in the manuscript, not certified by samples','No dimension order is fitted'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'ordered_loss_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(json.dumps(r['summary'],sort_keys=True))
