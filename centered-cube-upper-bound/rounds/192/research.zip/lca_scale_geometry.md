# R192 主候选：原最小共同祖先的大尺度接收吸收

状态：待全文独审；一般中间硬层未闭合。本命题加强R189的事件定位，不声称小祖先已付来源价。

## LS1. 固定合同与严格尺度事件

沿R189 GB1原FULL网格：d0=a/n，层S_k=2^k d0，k=0,...,J，Dtop=2^Jd0；同一θ在[0,Dtop)^n均匀，各层半开嵌套。原current p_x=P_{s(x),L(x)}、原window共同q>0、接收域E先于θ固定；下文积分中的q(x)仅为记号q(x)≡q，不改变原停止阈值或来源构造。输入μ=f dz固定，∫p_x dμ≤q；θ依赖β_V、ν_V分别受μ|V支配，同ω终端V不交。允许所有其他原币/筛选依θ，绝不假设来源与网格独立。

原bad u∈R_y⊂Z_ell(y)保证y,u同top、不同初始停止块，因而原LCA Pθ(y,u)存在且不同finest格。LCA沿完整辅助时间行不变；不会随t删源而重算。对原层S，

    {side(Pθ(y,u))>S} = {Q_S,θ(y)≠Q_S,θ(u)}        (LS1)

在同top资格上成立。证明：同S格使LCA⊂该格，边长≤S；不同S格使任意共同祖先严格高于S。S=Dtop时原同top两侧皆假。不能把左边改为≥S；LCA恰为S时pair可以在同S格中。没有共同top的pair不定义原LCA，但右边仍可正保留作包络。

R189原事件side(A_ell)≥S且u∉A_ell蕴含side(P)>S，因此本事件包含原已吸收几何事件。它还允许A_ell<S；不据此认证原全部物理条件下严格新差集。

## LS2. 整行限制与current-product支配

选r=r(x)≥0及S=S(x)为θ前可测、S值在原层集。将原时间固定bad集合限制为

    R_y^{r,S}={u∈R_y:||y−u||1≤r(x), side(Pθ(y,u))>S(x)}.

原A、α和所有good/target权不变，其他原H可保留。R183完整删除施于此bad子集、R188 HB8的同一current-product次耦合给

    Raw^{r,S}≤Crec EΣV∫E q(x)dx∫ψ_y1_{r,S} λ_x,V(dy,du),
    Crec=16Λ/(3Kκ), 0≤ψ≤1,
    λ_x,V≤q^(-2)[p_x(y)β_V(dy)]⊗[p_x(u)ν_V(du)].      (LS2)

这里同一个原唯一j整行处理；不对各时刻重领receiver预算。λ与ψ可依θ和x，均未当作固定测度。ν≤β未使用。

逐θ先以fixed μ支配，再用不交V正扩大和LS1：

    ΣV∫ψ1_{r,S}dλ
    ≤q^(-2)∫p_x(y)p_x(u)1_{||y−u||1≤r}
                      1_{Q_S(y)≠Q_S(u)} μ(dy)μ(du).    (LS3)

右侧才可以对θ取均值。对任意固定pair，

    Pr(split at S)=1−∏_i(1−|yi−ui|/S)_+
                 ≤min(1,||y−u||1/S).                  (LS4)

坐标相位来自原联合uniform law，非新独立平移。Tonelli及原current FIRST遂给

    Raw^{r,S}≤Crec min(1,r/S)∫E q(x)dx.                (LS5)

当r,S依x，式中系数写入积分内；若逐点Crec min(1,r(x)/S(x))≤ε，则总价≤ε∫q，无S取值个数损失。原receiver有限截断先算；其他独立窗口保持各自ε账，不免费重复。

## LS3. 不付尺度菜单的合法截断及剩余祖先大小

给ε>0，取原层中最小满足S≥Crec r/ε的层。若存在，LS5付side(P)>S部分，留下side(P)≤S。如果阈值≤d0，则S=d0，初始bad不同finest格意味着全部nearbad都在已付支。若阈值>d0且层存在，则S<2Crec r/ε，得到真实剩余祖先尺寸上界。若无层达到阈值，则取S=Dtop，需付的大LCA支为空，仍有side(P)≤Dtop<Crec r/ε。由此无论有无达标层，除已付支外都有

    side(P)≤max(d0,2Crec r/ε).                         (LS6)

空支不宣称LS5系数≤ε；它直接是零，这是超顶情况的正确处理。r=0时半开唯一格使跨格pair不存在，零支先处理。

R188 harder near-outerbad域设ζ=1−s、确定B_n=[log(L_n C_n/√n)]_+，原条件ζ²D_b(y,u)<16B_n。R189 reciprocal加强给||y−u||1≤bRκ D_b，Rκ=1+log(2/κ)。于是原θ前可选

    r(x)=16bRκ B_n/ζ(x)²

（ζ>0，B_n=0严格近域空），接LS5–6无需逐hard带求和。该定位允许中间hard全部原输入；它不把side(P)=O(r/ε)转成维数无关核下界。

## LS4. 保留的实际价格与下步接口

若z∈P，几何只给||z−u||1≤n·side(P)，因此logwg比较最多18n·side(P)/b，核衰减仍可能指数级。真实h(P)=μhi(P∩B)没有密度上帽；小P可有任意大源密度。重祖先质量、captured χ、neutral χ−Aν以及低K0仍需Astra/Sol的joint预算。

LS1–6不假定停止规则独立，亦不把自适应来源的边界事件按无条件概率直接相乘。真正合法的是先逐点用R188 λ支配到原θ前current×input包络，之后才取均值。本轮有限phase/Fraction检验只检查这一步有限模型及严格端点，不代替原preθ接口或一般证明。

## LS5. 来源对自适应的确定尺度：全部bad的失真吸收

LS2–4允许S=S(x,y,u)，只要它在θ前由原固定x,y,u及window确定且取原有限层。理由不是对已选择的随机来源条件化，而是在LS3的fixed μ⊗μ上逐pair取θ平均；S在该积分点固定。其取值可随pair不同，不把层分组后每层重领current容量。bad集合的此限制仍沿t固定，因此完整删除合法。

取常数A≥1，d=||y−u||1。d=0不在原bad初始域，先置零。选最小原层S≥Ad；若不存在取S=Dtop。若存在且S=d0，原bad必跨finest格，side(P)>S，所以该pair的全部原交通进入丢弃支；平均价仍d/d0≤1/A。若存在且S>d0，有S<2Ad（Ad恰为层时也成立），剩余side(P)≤S<2Ad。若超顶，discard支为空而side(P)≤Dtop<Ad。

因此可以对全部原reciprocal bad，不附near-outerbad门，定义实际子交通

    B_A={side(Pθ(y,u))>S(x,y,u)},

它满足

    Raw[B_A]≤(Crec/A)∫E q dx,                         (LS7)

且补集上的每个actualbad pair均有

    side(Pθ(y,u))≤2A||y−u||1.                         (LS8)

没有max(d0,...)残留，因为S=d0的全部actualbad已进入B_A。超顶行不能先引用不满足1/A的d/S概率；其discard事件原同top为空，直接取0。取A=max(1,Crec/ε)取得ε接收费。这个source-pair适应层完全不看θ、alpha、Pi或出生来源；若使S依赖这些量，以上交换不成立。

(LS7)是一般joint几何定位的实际接收预算，并没有自动给(LS8)的无权h或核卷积根价。d包含n个坐标距离，不能把cube l1直径n·side(P)改成side(P)。它使后续父块分析保留来源对实际距离，而非用整片near域最坏r；与此前吸收支按不交所有权结算一次。
