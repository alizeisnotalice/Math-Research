# R192 本机数值检验与证据边界

## 原共同相位与来源对选层（精确Fraction）

lca_boundary_checks.py由数值Sol编写、独审静态检查、主完整重放。9个主例分3初步/3适应来源压力/3扩大参数，n=1..3、J=2..5；枚举272024个open phasecells，并在相同数量lower-corner边界相位核half-open关系。所有源坐标为有理数，完整相位划分与单元长度精确，不用Monte Carlo。

核验同top上sideLCA>S恰等于S层异格，严格>不能改≥；full split=同top大LCA+topseparate。顶层测试sameTop大LCA为0而全split权为5507/14400，因而没有把topseparate当原LCA。θ依赖β/ν取自共同phase因子，分别受fixed μ支配而不独立；先固定current产品包络后概率积分方向正确。

同样相位加入A=2,4的pair-dependent S：最小dyadic≥A d1，超顶单列空discard。支付比≤1/A以及sameTop剩余side≤max(d0,2A d1)精确通过；一般证明另用原initialalive不同finest资格去max。有限原子例没有伪造原初始bad/FULL/current核资格。主运行输出/tmp/r192_parent_lca.json与保存JSON逐字节一致。

## 有序neutral耗散与实际score（非区间mpmath）

ordered_loss_checks.py由主编写，使用本机既有mpmath1.3.0。15条product-overlap曲线，n=1,2,4,8,16，每维数中性质量为1、8、64的三个设置；初步n≤2、压力n≤8及扩大n16。target和neutral的有理坐标阈值逐项有序，积分在所有阈值处切开；各曲线25/45位各算一次，共30次。检查真实e_t下界、GN/GA持续比例、原正score对的积分≤b·min(1,2/(1+c))。观察最大实际/上界比约0.2905803，最大两精度差约5.08e-27，c范围2.4..382.206；不把这些经验差当定向误差界。

另12个Fraction离散捕获容量例：2/4/8/16原子，储备预算分别为总k质量的0、1/3、1。计算sup_a[Σmin(w,ak)μ−aR]的所有折点，与按w/k排序的primal移除预算逐项精确相等。该有限检查不引用或认证一般强对偶；CG只使用逐a成立的弱下界。

最后12个实际C核score配置：n=2/4/8/16、每维数三种原距离帽内位置方案，35/50位分别计算，检查坐标C≥exp(−M_n)、三个钟位置的score障碍及积分log-growth下界。δ=√wg，确保strict tiny门；这些检验使用真实E4公式C，而不是任意score数组。没有α、FIRST、birth或真实接收域构造，不能称FULL实例。极小误差附近用预设容差，非区间证明。

## 复现与不作的推断

标准库执行第一个脚本；第二个用已有vendor：
`PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 ordered_loss_checks.py`。

不安装库，不编译PDF，不拟合n阶，不从finite grid最大值宣称一般极值。不记录未测运行时间。上述完整脚本最终由reproduce.py隔离重跑并逐字节比较输出；所有一般预算来自解析推导和原合同，不以数值pass代替。
