# R192：原捕获中性质量的时钟排序与实际接收付款

本稿证明一个有明确物理条件的接收吸收机制。原捕获来源中，若有足够的中性质量在整个辅助窗口内比全部 active target 衰减得慢，该质量持续进入原 e_t 分母。按每个实际 bad 来源的原 LCA 选择这部分质量，仍可逐来源积分，不需把 LCA 固定为一块，也不改后验。最终得到原正交通的一项 epsilon 接收价格。排序与质量条件并不由晚 LCA 的无权 h 质量自动推出；低 K0、排序失败及容量不足的余域明确保留。

## CG1. 原完整行及来源范围

固定原 (omega,V,x,j,y) 行、原初始时刻 ell、终端 g，0<ell≤g，e=e_g(y)>0。所有 dx 保留原 E_rec；下文没有扩大接收域。原 p_z、Q_z、J_z、K0=P_(s,Hhat)、k_z=DK0_z、a_y(z)=TDelta_y(z)、alpha_y、rho_y、good/bad、history、原树和删除均不变。当前严格软范围 s>1-2^(-1/n)>0 保证 K0>0；这不是近全软假设。

原 terminal target

    A(v)=1_good(v)rho_y(v)J_v/(3Q_v),
    0≤A≤1, supp(A nu)⊂Z_g(y),
    G(t)=∫A(v)w_t(y,v)nu(dv),
    M_A=G(ell), D_A=G(ell)-G(g), d=D_A/e,
    z(t)=G(t)-G(g), psi=d/(1+d).                       (CG1)

A 是原终端冻结权，不把 u-dependent history 或剩余 pair 门并入 A。若 M_A=0，原交通为0，先处理此支。余下 M_A>0。D_A=0 时同样没有连续 target score 损失，本文正交通为0；公式中的 psi 此时取0。

沿用 R191 LJ2 的真实 fractional capture

    chi_y(dz)=1_Ey(z)min(1,a_y(z)/k_z)nu(dz),
    0≤A nu≤chi_y≤nu≤mu_hi,
    supp chi_y⊂Z_g(y),
    R_alpha:=alpha_y QJ=Dq-∫k_z chi_y(dz),
    ∫k_z(mu_hi-chi_y)(dz)≤R_alpha.                    (CG2)

这里最后一步用同一合法 K0 的 FIRST，K0 mu_hi≤q。mu_hi、nu、beta 保持原来源；没有 nu≤beta 或每叶质量帽。capture 支持 good/terminal 的准确原定位是 R128 RT5–RT6；不继承旧稿已修复的来源排序。

实际 reciprocal bad 集 R_y⊂Z_ell(y) 可含后来删除的来源。令

    N_ell(R)=∫_R w_ell(y,u)nu(du),
    kappa=K(1+gamma^(-n))/3, gamma=1+1/n,
    C_rec=16Lambda/(3K kappa).

实际 K=1，只保留符号追踪费用。kappa≥1 时互反域空。原 high、reciprocal/current 容量给

    p_y e≥2Kq,
    N_ell(R_y)/e≤1/(2K kappa).                         (CG3)

本文处理 kappa<1 的原正交通。所有其他限制，包含 small LCA、middle s、near outer-bad、tiny good、低 Ftree/Fcal、晚时钟 F(d,sigma_u)>eta，保持在原 H(x,y,v,u,t)∈[0,1] 内。

## CG2. 原坐标阈值给出的真实耗散顺序

原物理辅助权为

    w_t(y,z)=∏_(i=1)^n min(1,C((y_i-z_i)/b)/xi_t),
    xi_t=c_j t/b.

固定原 ell,g；置 Tlog=log(g/ell)，并定义

    b_i(z)=clip(log(C((y_i-z_i)/b)/xi_ell),0,Tlog).

令 b_(1)(z)≤...≤b_(n)(z) 为该有限向量的排序。对 r=log(t/ell)∈[0,Tlog]，准确有

    w_t(y,z)/w_ell(y,z)
       =exp[-Σ_i(r-b_i(z))_+],
    score_t(y,z)=#{i:b_i(z)<r} a.e.                    (CG4)

已在 ell 时刻软化的坐标被截为0，整个窗口未软化的坐标被截为 Tlog，因此 CG4 包含两个端点退化。score 的单点阈值选择不影响 dt/t 积分，原闭面与删除仍按原约定。

一个可直接检验的充分顺序是

    b_(i)(z)≥b_(i)(v) for every i.                     (CG5)

它给 score_t(y,z)≤score_t(y,v) a.e.，以及全时段

    w_t(y,z)/w_ell(y,z)≥w_t(y,v)/w_ell(y,v).            (CG6)

CG5 比只比较 w_g 大小强；本文不从 tiny good 或 bad-u 的 w_g>kappa 推断它。所有比较使用同一原 y,j,b,ell,g，不调用交换中心后的另一个原行。

## CG3. 可依原 bad 来源选择的中性质量

对每个 u∈R_y，可选原测度 N_u，满足

    0≤N_u≤chi_y-A nu,  supp N_u⊂Z_g(y),
    N_u 在辅助时间 t 内固定，
    CG5 对 N_u(dz)×A(v)nu(dv) 几乎处处成立。          (CG7)

N_u 可以依 x,y,u、原 LCA、整个原 target 测度 A nu 及原共同数据，但不能依正在积分的单个 target v，也不能随 t 重选。令

    M_N(u)=∫w_ell(y,z)N_u(dz),
    c_u=M_N(u)/M_A,
    G_N,u(t)=∫w_t(y,z)N_u(dz).

在同一实际来源二重积分中使用 CG6，得到

    G_N,u(t) M_A≥M_N(u)G(t),
    G_N,u(t)≥c_u G(t).                                (CG8)

这里没有概率独立性假设：这是固定原测度的逐点乘积不等式再积分。因为 A nu+N_u≤chi_y≤nu，且这些来源均在 Z_g⊂Z_t 内，原分母满足

    e_t≥G(t)+G_N,u(t)≥(1+c_u)G(t),
    e_t≥e,
    e_t≥e+z(t).                                       (CG9)

最后一个式子是原完整删除分母补偿：e_t-G(t) 非增。还可保留更强的 e_t≥e+z(t)+z_N,u(t)，其中 z_N,u=G_N,u(t)-G_N,u(g)≥0，但下文吸收费不需要将 z_N,u 冒充未知已付矩。

## CG4. 逐 bad 来源 FTC 与原 lambda 回代

记原完整正行（可带 H）为

    I_H=∫_ell^g dt/t ∬ A(v) H(x,y,v,u,t)
        (score_t(y,v)-score_t(y,u))_+
        Pi_y,t(dv)Pi_y,t(du) 1_Ry(u).

先固定正在积分的 u。保持原 Pi 的分母与 alive 指示，随后仅用正上界

    1_Zt(u)w_t(y,u)≤w_ell(y,u),
    (score_v-score_u)_+≤score_v,
    -dG(t)=∫A(v)score_t(y,v)w_t(y,v)nu(dv) dt/t.

A 的 terminal 支持保证 G 没有 target 删除跳。CG9 给

    ∫_ell^g (-dG)/e_t²
       ≤∫_0^∞ dG/max(e,(1+c_u)G)²
       =2/[e(1+c_u)].                                (CG10)

另一方面原 e_t≥e+z(t) 精确给

    ∫_ell^g (-dG)/e_t²≤D_A/[e(e+D_A)]=psi/e.

这两个上界作用于同一 u 的真实积分。因此 Tonelli 后

    I_H≤(1/e)∫_Ry w_ell(y,u)
                   min(psi,2/(1+c_u))nu(du).          (CG11)

没有要求所有 u 共用 N 或 c。删除 bad 来源只正减少左端，故后来删除、并发删除及原辅助窗口截短都已覆盖；没有重复消费 R183 的负信用。不能将 CG11 改写成只对某个运行 target v 临时选择更有利 N_{u,v} 后仍使用同一 G 的结论。

用 R188 HB 的实际双边缘测度

    lambda_x,V(dy,du)
      =(2K kappa/q)(p_y/e_g(y))1_high(y)1_Ry(u)
                    w_ell(y,u)beta_V(dy)nu_V(du),
    E Σ_V∫lambda_x,V≤1

的原 current/FIRST 容量（在每个固定共同窗口/接收点上）回代。lambda 仍依 x、原森林、j 和终端数据；没有改为独立参考。一次 hard 帽16/3、一次外系数2Lambda 给

    Raw^+[H]≤C_rec E Σ_V∫_Erec q dx
                   ∫min(psi,2/(1+c_u))lambda_x,V.    (CG12)

这里 lambda 使用实际唯一 j(x) 及其原 ell,g，不是把各 j 的后验另行相加。

给定预分配的 0<epsilon≤C_rec，令 M_epsilon=2C_rec/epsilon。限制实际正交通到

    1+c_u≥M_epsilon                                  (CG13)

的子域，CG12 与原 lambda 总质量界给

    Raw^+[H;CG13]≤epsilon E∫_Erec q dx.                (CG14)

实际 receiver/唯一 j 在原整行求值期间保留，再使用统一行界与原 current 容量合并；没有额外 log2 时间费、LCA 层数费、soft/scale 菜单。若若干独立窗口重复使用 CG14，必须按主总账分配各窗 epsilon，不能重复领同一接收信用。本稿只花预先指定的 epsilon，不声称已有未使用的吸收余额。

## CG5. 原 LCA 上可计算的捕获容量

为将 CG7 接到原 h(P_u)，取每个初始 alive u 的实际

    P_u=LCA_omega(y,u).

这是 R190 已核的同一原树节点，沿 t 固定。其 h(P_u)=mu_hi(P_u∩B) 的出生载体 B 必须保留。

用整个原 target 测度 A nu 定义有限个本行阈值

    b_i^A=esssup_(A nu) b_(i)(v),  i=1,...,n,
    C_u=P_u∩B∩{z:b_(i)(z)≥b_i^A for every i}.          (CG15)

M_A>0 保证该 essential supremum 正常；阈值有界于[0,Tlog]。有限排序与 essential supremum 可测；它只依同一行全部 target 数据，不是依单个运行 v 的条件选择。有限个 i 可同时去除零集，于是 CG5 在 C_u×active target 上成立。现在取

    N_u=(chi_y-A nu)|C_u.

它满足 CG7，自动支持 Z_g；不需把 P_u 或 mu_hi 支持臆造为 Z_g。

定义一项实际物理下包络，而不是假定未知矩小：

    L_u=sup_(c_cap≥0) {
       ∫_Cu min(w_ell(y,z),c_cap k_z)mu_hi(dz)
            -c_cap R_alpha}.
                                                               (CG16)

其中 c_cap 是一个标量优化参数。所有积分保留真实 k=DK0 与同一个 R_alpha。对任意非负标量 c_cap，CG2 给

    ∫_Cu w_ell dchi
      ≥∫_Cu min(w_ell,c_cap k)dmu_hi-c_cap R_alpha.

证明只把 mu_hi=chi+(mu_hi-chi) 分开，并对第二部分使用 min(w_ell,c_cap k)≤c_cap k。取上确界得到

    0≤L_u≤∫_Cu w_ell dchi<∞,
    M_N(u)=∫_Cu w_ell dchi-∫_Cu A w_ell dnu
             ≥L_u-M_A,
    1+c_u≥L_u/M_A.                                   (CG17)

上确界可取非负有理 c_cap：括号内函数连续，因 ∫k dmu_hi≤Dq，且为有限值。故没有可测选择问题，也没有使用强对偶或允许点点选择 c_cap(z)。

因此原可直接核算的几何/容量条件

    L_u≥M_epsilon M_A                                 (CG18)

保证 CG13，享受 CG14 的真实 epsilon 接收价。它保留实际同 alpha、原 K0、target 初始权和 LCA。它没有把 h 当作 nu 或把 arbitrary subprobability 的旧树权重再登记成新来源付款。

原 h 对 CG16 的精确进入方式是，对每个 c_cap≥0，

    ∫_Cu min(w_ell,c_cap k)dmu_hi-c_cap R_alpha
      =h(P_u)-mu_hi((P_u∩B)\C_u)
        -∫_Cu[1-min(w_ell,c_cap k)]dmu_hi
        -c_cap R_alpha.                              (CG19)

每个被减项均为真实非负量。第一个是排序不合格的原父块质量；第二个同时保留初始物理权的衰减和低 K0；第三个是同一 alpha 的储备费。CG19 无维数成本的省略，也没有给 h 一个未经证明的空间密度帽。它给出足够条件：若某个标量 c_cap 使右端≥M_epsilon M_A，则原 CG18 子支已付。

## CG6. 几何范围、维数费用与仍未付的事件

主稿 LS 的随机 LCA 付款可以先支付原 large-distortion 域；其剩余逐 pair 保留 side(P_u)≤2A_grid||y-u||_1。本文不复证该网格估计，也不重领其 epsilon。在该剩余上，CG15–19 使用原实际 P_u，故可直接相交；但 side(P_u) 与 pair 距离的控制不自动保证 CG15 的阈值顺序，亦不把 n·side(P_u)/b 或真实 K0 衰减变成常数。

若只想从父块边长 S 给粗物理下界，可令 r_i=max_{z∈P_u}|z_i-y_i|，则同钟

    inf_(z∈P_u) w_ell(y,z)
       ≥∏_i min(1,C(r_i/b)/xi_ell).

所有 n 个因子必须保留。K0 的 corresponding inf 也要在原 Hhat、真实 hard 面上计算；本稿未用 expanded-current 核替换它。故 CG19 刻画的低核费用是真实剩余，不是可以凭小 initial cell 或 near outer-bad 文字删去的常数。

在先前已付域及 CG18 之外，最早仍缺的联合预算准确是：原 H/alpha/beta/Pi/真实 dx 加权下，如何控制 CG19 的排序失败质量、初始权/低 K0 衰减和储备费，使有足够 captured-neutral 初始质量在 target 耗散期间持续留在分母。仅知道 G_chi(ell) 大不能做到这一点；CG5–8 给出本稿已证明的一种真实时序条件，而不声称所有 tiny-good 点都满足它。

CG14 与 CG18 是新增实际条件子支的接收付款，区别于只记录一个必要支持关系。余域原位保留，未证明其小、未认证与全部此前分支的 FULL 严格覆盖扩大，亦未证明一般 sqrt(n)n^{o(1)} 结论闭合。
