# R192 联合预算与中间硬层的准确保留域

使用原一个window的共同q与真实接收域E，固定预分配0<ε≤Crec；此处ε是本轮总额度，不将两条吸收各领一份ε。先从此前已付交通中剔除，所有后续限制均在其补集，不重新定义A、α、Π、来源或森林。

取Agrid=2Crec/ε≥2，对每个原初始bad pair按LS5选preθ源对尺度S，第一子支Bgrid={sidePu>S}的价格≤ε/2·∫E q dx。补集每个actualbad有sidePu≤2Agrid||y−u||1=4Crec||y−u||1/ε。若S=d0，该pair没有剩余；超顶则Bgrid空，价格直接0而非用粗split概率。

在该补集，按CG15使用原全target阈值顺序域C_u，按CG16定义实际容量L_u；M_A=∫Awellν。M_A0行无交通。第二子支Bcap={L_u≥(4Crec/ε)M_A}的价格≤ε/2·∫E q dx，因为1+c_u≥L_u/M_A且逐u完整行乘子≤2/(1+c_u)。原λ总质量由同current FIRST控制，不收树层/soft/scale菜单。

因此

    Raw[Bgrid ∪ (Bgrid^c∩Bcap)]≤ε∫E q dx.

这是一笔完整真实接收预算，包含任意原输入、全部辅助时刻和后来删除bad；不依赖硬层只在有限函数族成立。两条的空间和时间量词不同：S只能preθ固定源对选择；C_u允许依原已实现行和Pu，但须沿t固定并与完整target权满足排序。不能互换这两个选择权限。

仍保留的中间硬层联合域准确满足

    sidePu≤(4Crec/ε)||y−u||1,
    L_u<(4Crec/ε)M_A,

以及全部旧实际history、lowFtree、small initial、晚deadline、大h、nearouterbad、tinygood等门。特别第二式对每个固定c_cap≥0都强制

    h(Pu) < (4Crec/ε)M_A
          + μhi((Pu∩B)\C_u)
          + ∫Cu [1−min(well,c_cap DK0)]dμhi
          + c_cap αQJ.

这不是将右端登记为已付项：排序失败、初始权/低K0衰减、reserve仍需实际joint来源价格。Pu尺寸只给cube l1直径n·sidePu，不能删除n。Sol的tiny-target score与实际Δ接口可提供耗散计数下界，但不足以证明整个captured父质量属于C_u；其essential-sup顺序是对全部active target，不能拿单个v的较弱条件替代。

所有其他独立window、剩余mother share和先前预算仍归原总账。ε并未被证明是尚未使用的余额；使用本定理时须由最终总证明分配。一般一致弱型根阶上界仍未闭合。
