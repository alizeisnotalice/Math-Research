# R299 — exact weighted rank, cumulative capture capacity, and FIRST absorption

## 1. General finite-measure identity, including atoms

Let mu be any finite positive measure on [a,b], a>0, with mass m<=1. Let its INCLUSIVE CDF be F(r)=mu([a,r]), let N>=1, and define

    g_N(t)=[1-(1-t)^(N+1)]/(N+1), 0<=t<=1,
    K_N(t)=integral_[a,t] (1-F(r))^N mu(dr).

At each atom s write d_s=mu({s}) and F(s-)=mu([a,s)). Then

    Delta_N(t)=sum_(s<=t)
        {g_N(F(s))-g_N(F(s-))-(1-F(s))^N d_s}>=0,
    K_N(t)=g_N(F(t))-Delta_N(t).                        (1)

The series is convergent, since all terms are nonnegative and their sum is at most g_N(m). Consequently the EXACT weighted rank identity is

    integral_[a,b] r^(-n)(1-F(r))^N mu(dr)
       =b^(-n)[g_N(m)-Delta_N(b)]
          +n integral_a^b t^(-n-1)
                          [g_N(F(t))-Delta_N(t)]dt.     (2)

Dropping Delta gives an upper bound, with equality for nonatomic mu, including singular continuous measures. Atoms at a and b are included correctly. No rank tie randomization is required.

Proof of (1): push Lebesgue measure on (0,m] through the generalized inverse of F. Outside the countable atom intervals (F(s-),F(s)], F at this inverse equals the quantile almost everywhere. On such an atom interval its value is the inclusive endpoint F(s). Integrating (1-F)^N over quantile space therefore subtracts exactly the displayed deficit from integral_0^(F(t))(1-u)^Ndu. Its sign follows from the decreasing integrand. For (2), use the elementary positive identity

    r^(-n)=b^(-n)+n integral_r^b t^(-n-1)dt

and Tonelli against the measure (1-F(r))^Nmu(dr). Thus no differentiability of F or informal Stieltjes endpoint rule is needed.

## 2. Apply it to the ORIGINAL ordered capture

Use the precise objects in /tmp/r298_capture_geometry.md, Sections 1,3,5:

    U_y(u)=1_E(u)p_y(u)/q(u), I_y=integral U_y,
    pi_y(du)=U_y(u)du/I_y,                              if I_y>0,
    F_yz(t)=C_y(t,z)
           =integral 1{R(u)<=t}1{z in Q_(R(u))(u)}pi_y(du).

Zero rows contribute zero. Let mu_yz be the capture subprobability pushed forward by its ACTUAL hard radius R(u); then F_yz is exactly its inclusive CDF. All original e_g,m, selected FIRST, kernels, and history masks remain unchanged.

Define actual cumulative capture quantities

    A_y(t)=integral g_N(F_yz(t))nu(dz),
    D_y(t)=integral Delta_(N,yz)(t)nu(dz),
    H_y(t)=integral F_yz(t)nu(dz),
    S_y(t)=nu{z:F_yz(t)>0},
    V_y(t)=integral 1{R(u)<=t}R(u)^n pi_y(du).

They are finite; D_y is measurable either from the atom formula or the difference in (1). With

    J_y=integral nu(dz)integral r^(-n)(1-F_yz(r))^N mu_yz(dr),

equation (2) gives the EXACT joint-source identity

    J_y=b^(-n)[A_y(b)-D_y(b)]
             +n integral_a^b t^(-n-1)[A_y(t)-D_y(t)]dt. (3)

This retains the entire scale-cumulative capture, not just the value at a. In particular

    J_y<=b^(-n)A_y(b)+n integral_a^b t^(-n-1)A_y(t)dt.  (4)

Original hard caps apply at the SAME accepted receiver u and SAME actual radius R(u), so positive Tonelli gives the genuine geometric budget

    H_y(t)=integral 1{R(u)<=t}
                         nu(Q_(R(u))(u))pi_y(du)
          <=4lambda V_y(t).                            (5)

This is not a density bound on nu.

Concavity of g_N and Jensen on the actual capture support yield the sharper bound

    A_y(t)<=S_y(t)g_N(H_y(t)/S_y(t))
       <=S_y(t)g_N(min(1,4lambda V_y(t)/S_y(t))).        (6)

If S_y(t)=0 all three quantities are zero. The first expression is optimal from just that support mass and its mean capture. A useful simpler consequence is

    A_y(t)<=min{4lambda V_y(t), S_y(t)/(N+1)}.           (7)

Equations (3)-(7) are the general finite-measure/source result. Merely inserting S_y<=W_nu recovers a global source-mass price; it does not establish an unconditional source-linear 1/N gain.

## 3. A verifiable cumulative witness-capacity hypothesis

Here is a concrete ORIGINAL hard-cap premise supplying more information than W_nu. For a row y and every needed t in [a,b], suppose the actual capture support {z:F_yz(t)>0} is covered, up to nu-null sets, by finite or countably many source cubes Q_(rho_k)(x_k), with

    a<=rho_k<=b,
    x_k an original accepted receiver carrying the hard cap
         at that SAME rho_k,
    sum_k rho_k^n<=C_y(t)t^n.                           (8)

Then the union bound and original caps give

    S_y(t)<=4lambda C_y(t)t^n.                         (9)

Overlaps only improve the source union mass. All witness radii are legal; no cap above b or at a different radius is inferred. The existence/measurability of a useful such cover is a genuine additional geometric condition. The hard cap at each individual receiver does not itself bound the mass of the union of all captured sources.

Combining (6) with (9) can retain the sharp Jensen profile. For the simpler bound suppose C_y(t)<=C uniformly and put alpha=C/(N+1). Then (7) yields

    A_y(t)<=4lambda min{V_y(t),alpha t^n}.               (10)

Let T=n log(b/a), let P_y be the probability law of

    s=n log(R(u)/a) in [0,T] under pi_y,
    v_y(t)=integral_(s<=t) exp(s-t)P_y(ds).

Since V_y(a exp(t/n))/(a exp(t/n))^n=v_y(t), (4) and (10) give the explicit scale-distribution receipt

    J_y<=4lambda epsilon_y,
    epsilon_y:=min{1, min(v_y(T),alpha)
                        +integral_0^T min(v_y(t),alpha)dt}. (11)

This is a one-dimensional cumulative-radius calculation; it is not a newly named original residual norm. The baseline one follows because v_y(T)+integral_0^T v_y(t)dt=1. Nonconstant C_y(t) can be retained by replacing alpha inside (11) with C_y(a exp(t/n))/(N+1), including its endpoint value. Formula (6) can further improve that receipt.

A simple full-parameter sufficient condition uses the actual log-volume span. If P_y is supported in an interval [s0,s1] of width D_y^rad=s1-s0, then

    epsilon_y<=eta_N(C,D_y^rad),
    eta_N(C,D):=min{1, [C/(N+1)]
                  [1+D+log_+((N+1)/C)]}.              (12)

At C=0 use value zero. Proof: extend v_y past T using its actual exponential tail. The tail integral from T to infinity is at least min(v_y(T),alpha), so the expression in (11) is at most integral_0^infinity min(v_y,alpha). Before s0 it vanishes; on [s0,s1] it is at most alpha; after s1, v_y(t)<=exp(s1-t). For alpha<=1 the last tail integral is alpha[1+log(1/alpha)], proving (12). For alpha>1 the baseline one proves the stated minimum. This accounts for continuously varying radii, all endpoints and atoms.

Without radius concentration one may take D=T, or use the exact profile (11). Thus N~sqrt(n) does NOT automatically yield a small factor when D can be order n. If C and D have fixed polylog bounds, the explicit eta_N is small for sufficiently large N; its finite value, rather than an unstated asymptotic, determines absorption.

## 4. Strict return to original traffic and FIRST

The rank comparison applies ONLY to the L>=R residual. There min(L,R)=R, so the original positive masks may be dropped after identifying U_y dx=I_y pi_y, giving

    T_((1-C)^N,L>=R)<=integral I_y J_y beta(dy)
                    <=4lambda integral I_y epsilon_y beta(dy). (13)

For every row with uniform epsilon_y<=epsilon, original FIRST gives

    integral I_y beta(dy)
       =integral_E [integral p_y(x)beta(dy)/q(x)]dx
       <=|E|,
    T_((1-C)^N,L>=R)<=4epsilon lambda|E|.               (14)

FIRST is used at the actual ORIGINAL receivers before any positive extension. No source density or q-scale source-mass bound is inferred.

For source pricing, the existing full-soft envelope gives I_y<=S/q_-, where S=(1+n log(b/a))Csoft_n. Thus independently

    T_((1-C)^N,L>=R)<=(16/3)S integral epsilon_y beta(dy). (15)

Relative to the old product receipt S W_beta W_nu/[q_-a^n(N+1)], the witness/radius hypotheses replace the global normalized source mass W_nu/(lambda a^n) by the actual cumulative cover and radius fee C[1+D+log_+((N+1)/C)]. This is a genuine reduction when that geometric fee is smaller, not a free universal 1/N source estimate.

For absorption, let X_E=lambda|E|<infinity. ONLY IF the original argument separately proves the matching entry inequality

    X_E<=P_paid+T_((1-C)^N,L>=R)+R_other,

then (14), with epsilon<1/4, implies

    (1-4epsilon)X_E<=P_paid+R_other.                    (16)

This note does not assert that the entry inequality has already been established or that R_other is paid. A different receiver set or an extended receiver integral cannot be substituted into X_E without proving its own ledger.

For L<R, the residual evaluates C_y(L,z), not the inclusive CDF at actual hard radius R. No version of (3),(13)-(16) is claimed for that portion. If a newer covered gate dominates the old cover pointwise, its residual is smaller, but the OLD rank comparison used here still only controls L>=R. The L<R integral requires its own new argument.

A precise conditional transfer is available if an independent argument proves the NEW residual is bounded by (1-v0 F_yz(R))^N on an actual gate v>=v0>0 (for example from D>=v F_yz(R), v=min(1,(L/R)^(n/2))). Replace g_N everywhere by

    g_(N,v0)(t)=[1-(1-v0 t)^(N+1)]/[v0(N+1)].

Its derivative is (1-v0 t)^N and it has the same concavity/atom proof. Equations (10)-(16) then use alpha=C/[v0(N+1)]. This can extend the rank comparison into that qualified portion of L<R; it does not prove the independent comparison, cover the complementary v<v0 traffic, or establish the cumulative-cover hypotheses on all inputs. Any absorption still requires the finite receiver truncation and matching proved entry in (16).

## 5. Bounded outcome and actual numerical checks

The unconditional results are exact identities (1)-(4), actual hard-cap budget (5), and cumulative support Jensen bound (6). The cover premise (8) gives the verifiable scale-distribution receipt (11); the explicit radius-span premise gives (12). Under a uniform small resulting epsilon, FIRST completes the true receiver budget (14), and absorption is conditional on the actual entry inequality as in (16). Capture-union cover capacity, long radius distributions and L<R remain explicit, rather than being replaced by a^-n W_nu.

A local Python run verified 45 exact-Fraction atomic weighted-rank identities (including atoms at a,b and their deficits), 27 continuous identities at 45-digit mpmath precision, and 60 discrete logarithmic-radius capacity profiles against (12). All passed. These are diagnostics, not proofs of a global capture cover. Only this temporary Markdown file was written; other authors and Git were preserved.

Minimal reproduction of the actual checks follows. It writes no files.

```python
from fractions import Fraction as F
import sys,random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=45
atomic=0
for n in [1,2,4]:
    for N in [1,2,4,16,64]:
        for masses in [[F(1,10)]*3,[F(1,5),F(3,10),F(1,2)],
                       [F(0),F(1,4),F(1,4)]]:
            rs=[F(1),F(3,2),F(2)]
            f=H=D=direct=F(0);Hs=[];As=[]
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            for r,m in zip(rs,masses):
                old=f;f+=m
                D+=g(f)-g(old)-(1-f)**N*m
                H+=(1-f)**N*m;direct+=r**(-n)*(1-f)**N*m
                Hs.append(H);As.append(g(f))
                assert H==g(f)-D
            exact=rs[-1]**(-n)*Hs[-1]+sum(
                Hs[i]*(rs[i]**(-n)-rs[i+1]**(-n)) for i in range(2))
            upper=rs[-1]**(-n)*As[-1]+sum(
                As[i]*(rs[i]**(-n)-rs[i+1]**(-n)) for i in range(2))
            assert direct==exact and direct<=upper
            atomic+=1
continuous=0
for n in [1,3,32]:
    for N in [1,4,64]:
        for mass in map(mp.mpf,['.25','.75','1']):
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            lhs=mp.quad(lambda r:r**(-n)*(1-mass*(r-1))**N*mass,[1,2])
            rhs=2**(-mp.mpf(n))*g(mass)+n*mp.quad(
                lambda r:r**(-n-1)*g(mass*(r-1)),[1,2])
            assert abs(lhs-rhs)<mp.mpf('1e-35')
            continuous+=1
rng=random.Random(299);profiles=0
for k in range(60):
    ss=sorted(set(mp.mpf(rng.randint(0,100))/10 for _ in range(5)))
    pp=[mp.mpf(rng.randint(1,10)) for _ in ss];pp=[x/sum(pp) for x in pp]
    alpha=mp.mpf(10)**(-mp.mpf(k%7)/2);v=eps=mp.mpf(0)
    for j,(s,p) in enumerate(zip(ss,pp)):
        v+=p
        gap=ss[j+1]-s if j+1<len(ss) else mp.mpf(0)
        if v<=alpha:
            eps+=v*(-mp.expm1(-gap))
        else:
            cross=mp.log(v/alpha)
            eps+=alpha*gap if gap<=cross else alpha*(cross+1)-v*mp.exp(-gap)
        v*=mp.exp(-gap)
    eps+=min(v,alpha)
    D=ss[-1]-ss[0]
    bound=min(1,alpha*(1+D+max(0,mp.log(1/alpha))))
    assert eps<=bound+mp.mpf('1e-35');profiles+=1
print('PASS exact atomic weighted rank identities=',atomic)
print('PASS continuous weighted rank identities=',continuous)
print('PASS scale-span capacity profiles=',profiles)
```
