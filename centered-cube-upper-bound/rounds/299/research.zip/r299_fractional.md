# R299: a source-linear geometric cover of receiver-scale cells

This note uses the audited R299 soft-witness theorem, not an endpoint theorem. All original low,m>M, FIRST, hard caps, source/history masks, receiver fields and Lebesgue dx remain. A fixed original row y has finitely many actual accepted witnesses (u_i,r_i). Set G=gamma^(n/2), kappa0=2K/(ell M), and

chi_i(L,R)=min(1,(L/r_i)^(n/2) min(1,(R/r_i)^(3n/2))).

The R299 pointwise envelope theorem gives, for EACH actual witness,

 integral dx nu(dz) I0 p_y h_R/q chi_i(L,R)1_{Q_ri(u_i)}(z)
 <= (16/3) kappa0 c_i,
 c_i=Psi_G((b/r_i)^n) in [1,psi_inf].                    (1)

This uses the actual cap at r_i; no density cap at smaller radii is asserted. It remains true if the witness depends measurably on y. The exact kernel envelope is integrated before the witness cap. The entire original outer multiplier must still be applied.

## A deterministic common cover, without sampling

Let D_j be measurable hard-source cells, with original edge target

 E_j={(x,z):z in D_j, L(x)>=l_j, R(x)>=s_j},
 a<=l_j,s_j<=b.

These are lower-scale conditions on original actual receivers, not changes to their chosen scales. Both arguments of chi_i are nondecreasing. Set

 A_ji=1_{D_j subset Q_ri(u_i)} chi_i(l_j,s_j).

For nonnegative coefficients lambda_i satisfying A lambda>=1, every edge in the target union satisfies

 1_union(E_j)(x,z) <= sum_i lambda_i chi_i(L(x),R(x))1_Qri(z). (2)

Choose a j containing that edge and use its full-cell containment and lower scales. Intersecting a cell is insufficient. Positivity, (1), and (2) give the original traffic bound

 T_union <= (16/3) kappa0 integral [sum_i c_i lambda_i(y)] beta(dy). (3)

No extra W_nu or scale-count multiplier occurs. Overlap of target cells does not require disjointness, because (2) concerns their union. The right side may exceed one; only a positive majorant is used. All row maps and coefficients must be measurable. For a verified finite menu on a measurable row partition this is explicit; arbitrary pointwise LP optimizers are not granted as measurable selectors.

A uniform cost sum c_i lambda_i<=T gives (16/3)kappa0 T W_beta. Thus a genuine measurable common cover with T<=sqrt(n) polylog(n), together with controlled kappa0 and original outer price, would pay this full covered branch. Existence of that cover for all original edges remains unproved.

## Exact finite geometry and what it changes

For any finite feasible A>=0 and positive c, let tau=min_{lambda>=0,A lambda>=1}c.lambda. Then

 1/tau=max_{pi>=0,sum pi=1} min_j sum_i pi_i A_ji/c_i. (4)

The explicit maps pi_i=c_i lambda_i/(c.lambda) and lambda_i=pi_i/(c_i g) prove (4); finite compactness proves the maximum exists. If a row of A is identically zero, no cover is certified and (3) is not asserted for that target. Any d>=0 with A^T d<=c is a lower certificate, and equal primal/dual objectives certify the finite optimum.

The R298 source-only cover cost used (r_i/a)^n. Here c_i is uniformly bounded, and the necessary small-scale loss is moved into the EXACT actual-edge coefficient chi_i(l_j,s_j), not discarded. This can improve targets whose actual scales allow larger witnesses, including L<R. It cannot be advertised as uniformly eliminating all exponential losses: a target at much smaller scales than every available witness can still have very small coefficients and large tau. The geometry to prove is a low-cost joint cover of source positions AND actual scale pairs. This note provides its rigorous original-traffic payment, rather than assuming receiver averages control all edges.

The theorem is analytic. No finite LP experiment in R298 is re-labelled as a numerical verification of the new coefficients or a general dimension exponent. R299 local exact tests of chi and its envelope are supplied separately. Weak soft capture and all uncovered scale/source cells remain in the original ledger.
