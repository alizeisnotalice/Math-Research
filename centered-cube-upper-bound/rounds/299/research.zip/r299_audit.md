# R299 independent preauthor screen

Ownership: only /tmp/r299_audit.md. No R299 author proof was read before saving this screen. Keep the original fixed receiver field, original sources, actual full e_g and m, all low/m>M/history/source gates, q_-=3lambda/4 and legal scales a<=L,R<=b. Write kappa0=2K/(ell M), gamma=1+1/n, G=gamma^(n/2), psi_inf=3-2/(3gamma^n). Every raw price still needs the original outer Lambda once and the original global source ledger.

## 1. Original global heights

The common original low/high conditions imply p<=kappa0 c_j^(n/2)(LR)^(-n/2). Consequently p<=kappa0 L^(-n/2)R^(-n/2). The band relation also gives the GLOBAL height p<=kappa0 G L^(-n/4)R^(-3n/4). For L<=R this is the direct band height. For L>R the band gives the stronger kappa0 G L^(-3n/4)R^(-n/4), which is at most the displayed global height. It is important not to derive this last bound merely from p<=kappa0 R^-n: that weaker estimate alone would not justify its L dependence.

Equivalently, writing t=min(L,R), one has both p<=kappa0 t^(-n/2)R^(-n/2) and p<=kappa0 G t^(-n/4)R^(-3n/4). These hold on the original gated traffic for all original softness and both orientations. They grant no new FIRST at substituted scales.

## 2. Eliminate the hard eligibility gate by a paid positive weight

For one frozen actual witness cube of side r in [a,b], the parent's weight w_r=min(1,(min(L,R)/r)^(2n)) is valid without the old gate min(L,R)>=r. When R<r, using t=min(L,R)<=R,

    p w_r h_R <= kappa0 r^(-2n)(t/R)^(3n/2) 1_QR
                 <=kappa0 r^(-2n)1_Qr.

This is the central block of the OLD own-scale hard envelope whose menu begins at r. When R>=r, w_r absorbs t<r into both original r-based point heights. Thus the full old envelope still dominates pointwise and its exact integrated coefficient remains r^-n Psi_G((b/r)^n), not a new scale-window factor. Actual witness hardcap nu(Q_r(u))<=4lambda r^n therefore pays this weighted witness traffic by at most (16/3)kappa0 psi_inf W_beta. The weight, not unweighted full traffic, is paid.

The stronger independently checked author-statement candidate is

    chi_r(L,R)=min(1,(L/r)^(n/2) min(1,(R/r)^(3n/2))).

For R<r, chi<=L^(n/2)R^(3n/2)r^(-2n), and the first global height gives exactly the same central-block domination. For R>=r, chi=min(1,(L/r)^(n/2)); it absorbs L<r into BOTH r-based heights (the second leaves the harmless factor (L/r)^(n/4)<=1). Hence the identical Psi_G envelope and own-scale source fee hold. Moreover chi_r>=w_r. In particular chi=1 on the former eligible min(L,R)>=r branch and is positive on previously excluded mismatches. This is a soft scale penalty, not a claim that all mismatches are freely paid.

An earlier sufficient product penalty min(1,(L/r)^(n/2))min(1,(R/r)^n) gives a finite constant <=4 by direct integration, but is superseded by the stronger central-block construction above; it is not needed in the final route.

## 3. Exact common weighted cover and quantifiers

For a finite configuration of accepted witnesses u_i, r_i=R(u_i), define

    H_config=1-product_i[1-chi_ri(L,R)1_Qri(ui)(z)].

It lies in [0,1] and is bounded by the sum of its individual weighted witnesses. Each summand has the proved same-radius cap payment; no disjoint source assignment is needed to obtain the N-witness upper fee (16/3)kappa0 psi_inf N W_beta. The individual chi weights may depend on the actual current L,R because their analytic receiver-envelope proof was performed before extension. This is not an invocation of the frozen-pair R296 theorem on a receiver-dependent mask.

With N iid witnesses under the actual canonical pi_y=U_y dx/I_y (zero rows treated as zero traffic), put D_y(L,R,z)=integral chi_R(u)(L,R)1_QR(u)(u)(z) pi_y(du). Independence gives the exact average H_N=1-(1-D_y(L,R,z))^N. Thus D>=eta traffic costs at most (16/3)kappa0 psi_inf N/[1-(1-eta)^N] W_beta, and eta=log(2)/N gives the twice-price branch. D is at least the old ordered C_y(min(L,R),z), but no global positive lower bound on D is asserted. The exact residual is the ORIGINAL traffic times (1-D)^N. Finite product kernels ensure measurability without choosing one global random field. Accepted witnesses must retain their actual same-radius caps; no beta/nu comparison or density assumption is introduced.

If literal indicator random covers are desired, add independent uniforms V_i and cover an actual triple when some V_i<=chi_ri(L,R) and z belongs to that witness cube. Averaging these uniforms gives H_config and then the iid witness formula. The common uniforms define a measurable cover of all receiver configurations; they do not create a receiver-independent source partition.

## 4. Weighted CDF rank layercake: safe budget and remaining quantities

For the original R298 rank branch L>=R, fix y,z and let mu_yz be the capturing subprobability on witness radii under pi_y, F_yz(t)=mu_yz([a,t]), inclusive. Define

    H_yz(t)=integral_[a,t] (1-F_yz(r))^N mu_yz(dr),
    G_N(s)=[1-(1-s)^(N+1)]/(N+1).

The inclusive-CDF jump argument gives H_yz(t)<=G_N(F_yz(t)) for every t, including atoms. Integration by parts/layercake gives the EXACT identity

    integral_[a,b] r^-n(1-F(r))^N dmu
       =b^-n H(b)+n integral_a^b t^(-n-1)H(t)dt,

and hence the upper bound replacing H by G_N(F). Integrating nu is legal by positive Tonelli. The original accepted witness caps yield the genuine cumulative moment bound

    integral F_yz(t)nu(dz)
       <=4lambda integral_{R(u)<=t} R(u)^n pi_y(du).

Since G_N(s)<=min(s,1/(N+1)), each integrated term is bounded by

    min(W_nu/(N+1),
        4lambda integral_{R(u)<=t}R(u)^n pi_y(du)).

Multiplying this layercake by the actual row mass I_y and integrating ORIGINAL beta gives a valid weighted rank receipt, with the complete I_y, cumulative radius moments, and nu mass retained. A sharper concavity version is W_nu G_N(min(1,4lambda integral_{R<=t}R^n dpi/W_nu)) when W_nu>0. Zero mass is handled separately. These source/cumulative quantities are not known to be a universal root-polylog linear budget. Independently the exact weighted rank integral integrated against nu is <=4lambda by the same actual witness cap and (1-F)^N<=1; its combination with the preceding bound may be useful, but does not supply an unsupported 1/N source-linear gain.

The new weighted-cover residual uses D rather than F(R). One must prove its domination by a rank expression before transferring this old L>=R layercake bound to it; D>=old ordered C does give a positive residual domination on L>=R. No such CDF-at-actual-R identity is supplied for L<R. The original full e_g and m remain unchanged throughout.

## 5. Actual bounded local diagnostics

Executed Python Fraction diagnostics before author-proof reading: 125 scalar configurations with n=4 and L,R,r in {1,5/4,3/2,7/4,2} verified chi>=w, the central-block bound for R<r, and both r-based heights for R>=r. Seven finite-atomic rank cases N=1,...,7 verified the exact weighted Stieltjes/layercake identity and its G_N upper bound. All PASS. These finite checks verify bookkeeping, not the original full-source hypotheses; the arguments above are the proof.

Independent-screen verdict: the stated weighted common-cover payment and exact residual are valid. The weighted rank-layercake budget is valid with its explicit source/cumulative-radius costs. An unconditional payment of every remaining original edge has not been proved. Await author files for bounded final comparison; no upstream or Git files changed.

## 6. Author-file comparison after the independent screen

PASS: /tmp/r299_geometry.md matches the independently screened chi witness envelope and exact iid union theorem. Equations (7)-(10) retain the original band derivation in both orientations. The same central block, exact Psi and own-radius source cap justify (11)-(18) with all repetition paid. Its additional aspect bound D>=min(1,(L/R)^(n/2)) C_y(R,z) is valid because every witness r<=R has chi_r at least this factor. Restricting the original actual receiver to v>=v0 before positive extension gives (21), and the inclusive-CDF inequality gives (22)-(23) with the explicit 1/v0 and source-product fee. The complementary aspect branch and the unsplit exact residual remain. Thus the former absence of an L<R rank interface is improved conditionally, while a sufficient integrated budget is not asserted.

PASS: /tmp/r299_fractional.md equations (1)-(4) correctly pay source-position/actual-scale target cells. The exact coefficient is full-cell containment times chi at the two lower scales; monotonicity of chi gives pointwise domination of the target edge union. Positive finite combinations of the single-witness receipts give (3), including overlaps. The new bounded c_i=Psi_G costs do not eliminate a potentially tiny coefficient and large cover cost. The finite nonnegative-matrix normalization tau=1/g is valid with positive costs, and measurable row coefficients are explicitly required. No old LP numeric result is relabeled as new-coefficient evidence.

Provisional proof bindings (frozen author texts, before final integration receipt):
- /tmp/r299_geometry.md: cef9052b58bedfd0d9d9f1519e1f7e13e011fe17abfbcbc3d7f3e7e4b2c8ec9f
- /tmp/r299_fractional.md: 3452b32aea15d8ef7c9f05031dba7f35d5e0c005923d90411950db410b67f330

## 7. Weighted-rank author comparison — PASS

The final /tmp/r299_rank.md agrees with the independently derived layercake, and supplies its exact atomic deficit. Equation (1) is the quantile integral with each atom evaluated at its inclusive upper endpoint; subtracting its nonnegative deficit is exact, including endpoint atoms. Positive layercake gives (2)-(4), and original same-radius hardcaps give the true cumulative radius-moment budget (5). Jensen over the actual capture support proves (6), retaining that support's source mass. No source density is inferred.

The additional cumulative-cover assumption (8) is explicitly unproved on general inputs and supplies (9), rather than being deduced from one-receiver caps. Under that premise the normalized exponential-radius profile gives (11). The identity v(T)+integral_0^T v(t)dt=1 and its terminal exponential-tail extension justify both the baseline and the span bound (12), with all C, N and log-span costs retained. FIRST is used on the same actual E in (14); absorption (16) is conditional on a separately proved matching entry and finite X_E, not asserted as global closure. The v0 transfer legitimately replaces g by its decreasing-derivative variant only after an independent D>=vF comparison and an actual aspect gate; it retains the complementary traffic and the 1/v0 fee.

No mathematical correction is required. SHA256: 4861c6469d78ada0783a34c1a918ec240af490fc2778adf4e935d5d0264184b5

## 8. Final README/evidence integration — PASS and frozen

Read the completed /tmp/r299_README.md. One initially ambiguous auxiliary-rank scope sentence was corrected before freezing: its epsilon=C/(N+1)[1+D+log_+((N+1)/C)] formula is now explicitly for L>=R. On the independently proved two-orientation aspect gate v>=v0, the README explicitly substitutes C/[v0(N+1)] everywhere, including the reciprocal inside the logarithm. This matches the two proofs, preserves the aspect-complement cost, and prevents an unsupported unqualified absorption. No proof correction was needed.

All remaining README formulas and scope agree with the three audited proofs: same-Psi single-witness payment, monotone weighted iid allocation, actual-scale/source-cell fractional coverage with unproved affordable full-cover existence, exact original residual, conditional cumulative-capacity/radius-span rank budget, finite E and matching-entry absorption requirements, and original outer/history ledger. There is no global weak-type closure claim.

Inspected actual evidence outputs: /tmp/r299_checks.json has no failures and its check counts sum exactly to 9992; its 312 height, 303 second-height, 24 basic radial, 21 sharp radial, 56 actual cube-point and 336 iid figures agree with README. The geometry rerun log records 256/864/36 PASS. The rank rerun log records 45 exact atomic, 27 high-precision continuous, 60 radius-profile PASS. The parent reports actually rerunning all these scripts; the auditor inspected their frozen output artifacts without repeating them. Independently executed 125 Fraction chi/envelope cases and seven weighted-layercake cases are documented in Section 5. Finite evidence does not establish original input histories or a dimension exponent.

Final SHA256 bindings:
- /tmp/r299_README.md: 2e8eeeb01add212c0a0a0cb761cfab9a850502652f8768fe0493df66a2be20dc
- /tmp/r299_geometry.md: cef9052b58bedfd0d9d9f1519e1f7e13e011fe17abfbcbc3d7f3e7e4b2c8ec9f
- /tmp/r299_fractional.md: 3452b32aea15d8ef7c9f05031dba7f35d5e0c005923d90411950db410b67f330
- /tmp/r299_rank.md: 4861c6469d78ada0783a34c1a918ec240af490fc2778adf4e935d5d0264184b5
- /tmp/r299_checks.py: cd8f2f8fcdb930de3dd89b334812d8ba70c93ccbf0e413b22b702c59a02d4822
- /tmp/r299_checks.json: 1631fb5f1ea3b925482c7cd3764981a339f9544cf2102f551dde31d1b1fb52a5
- /tmp/r299_geometry_checks.py: 82399d337a50794cfc5d0d7f87b2cab19f46281303380870dcf1b37885b28c7c
- /tmp/r299_geometry_checks.log: cf5bd5e2b11977ce51965cfcf84a721c9a4df2471e3c071936b3c131f08b343b
- /tmp/r299_rank_checks.py: 8c6e5c5d0fecabd8053a658341b2339c9a6317d83dfaa446591698cc354a4bf6
- /tmp/r299_rank_checks.log: 7c24f974bc6e69345ce2018f2cc6f4fab8d6b63c49a17721eae0bcb2828693ab

Final bounded verdict: PASS. The low-cost full joint source/scale cover, weak-soft-capture integral, cumulative-cover/radius-span hypotheses on general input, and original global outer/initial/jump/deletion ledgers remain unproved. No source-density comparison or free repeated hard-source mass was introduced. The file is frozen after this final bounded integration review; no repository, Git, PDF or other author file was changed.
