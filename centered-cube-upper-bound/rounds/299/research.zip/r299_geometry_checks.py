from fractions import Fraction as F
from itertools import product
counts={'height_checks':0,'iid_checks':0,'rank_checks':0}
for n in [4,8,16,64]:
 G=(1+F(1,n))**(n//2)
 for L,R,r in product([F(1),F(5,4),F(3,2),F(2)],repeat=3):
  chi=min(F(1),(L/r)**(n//2)*min(F(1),(R/r)**(3*n//2)))
  p=min((L*R)**(-n//2),G*L**(-n//4)*R**(-3*n//4))
  if R<r:
   assert p*chi*R**(-n)<=r**(-2*n)
  else:
   target=r**(-n)*min((R/r)**(-n//2),G*(R/r)**(-3*n//4))
   assert p*chi<=target
  assert chi>=min(F(1),(min(L,R)/r)**(2*n))
  if r<=min(L,R): assert chi==1
  if r<=R: assert chi>=min(F(1),(L/R)**(n//2))
  counts['height_checks']+=1
 probs=[F(1,6),F(1,3),F(1,2)]; radii=[F(1),F(3,2),F(2)]
 for L,R in product([F(1),F(3,2),F(2)],repeat=2):
  for capture in product([0,1],repeat=3):
   ws=[min(F(1),(L/r)**(n//2)*min(F(1),(R/r)**(3*n//2)))*c for r,c in zip(radii,capture)]
   D=sum(p*w for p,w in zip(probs,ws))
   for N in [1,2,3]:
    mean=F(0)
    for inds in product(range(3),repeat=N):
     mass=F(1); fail=F(1)
     for i in inds: mass*=probs[i]; fail*=1-ws[i]
     assert 1-fail<=sum(ws[i] for i in inds)
     mean+=mass*(1-fail)
    assert mean==1-(1-D)**N
    counts['iid_checks']+=1
for masses in [[F(1,4),F(1,2)],[F(1,10),F(1,10),F(1,10)],[F(1)]]:
 for v,N in product([F(1),F(1,2),F(1,100)],[1,2,8,64]):
  cum=F(0);lhs=F(0)
  for m in masses: cum+=m;lhs+=m*(1-v*cum)**N
  assert lhs<=(1-(1-v*cum)**(N+1))/(v*(N+1))
  counts['rank_checks']+=1
print('PASS',counts)
