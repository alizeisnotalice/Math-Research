# R299 — scale-penalized common witness cover at no extra source price

## 1. Precise theorem and what it improves

Fix the original outer-data/clock instance and all hypotheses of R298. In particular beta,nu are arbitrary finite positive L1 sources, a<=L(x),R(x)<=b<=2a, q_-=3lambda/4<=q(x)<=lambda, and E is the original accepted receiver set with original FIRST and maximal hard cap. The target is the complete original positive low-pe,m>M traffic

    dT=I0(x,y,z) p_y(x)h_(R(x))(x-z)/q(x)
                                     dx beta(dy)nu(dz),

with 0<=I0<=1 including every original gate, history and source restriction. M>0; the intermediate target has M=1. Keep the full original e_g,m, unique band and common selected s,L,R. Put

    kappa0=2K/(ell M), gamma=1+1/n, G=gamma^(n/2),
    psi_inf=3-2/(3gamma^n)<2.754748,
    U_y(u)=1_E(u)p_y(u)/q(u), I_y=integral U_y du,
    pi_y(du)=U_y(u)du/I_y   when I_y>0.

As in R298, I_y<=S/q_- with S=(1+n log(b/a))Csoft_n and Csoft_n<=1+(pi/2)sqrt(n). Zero rows carry no original traffic and all cover expressions there are defined to be zero.

For each frozen witness radius r in [a,b] define the explicit asymmetric penalty

    chi_r(L,R)=min{1, (L/r)^(n/2) min[1,(R/r)^(3n/2)]}.   (1)

This is in (0,1] for legal scales. It is one when r<=min(L,R), but is also positive when the actual minimum scale is below the witness radius. Define the new ACTUAL soft capture

    D_y(L,R,z)=integral chi_(R(u))(L,R)
                          1{z in Q_(R(u))(u)}pi_y(du),   (2)

and, for an integer N>=1, the common-cover allocation

    H_N^chi(x,y,z)=1-[1-D_y(L(x),R(x),z)]^N.              (3)

Then, on both orientations and all original bands together,

    T_(H_N^chi)<=(16/3)psi_inf kappa0 N W_beta.            (4)

The constant is exactly the R298 ordered-cover constant. In particular

    T_{D>=eta}<=[(16/3)psi_inf kappa0 N]/[1-(1-eta)^N]W_beta,
                  0<eta<=1,                            (5)
    T_{D>=log(2)/N}<=(32/3)psi_inf kappa0 N W_beta.         (6)

Thus N=ceil(sqrt(n)) gives a source-linear root payment with explicit kappa0 and the original outer price. Unlike the R298 hard eligibility condition, (1)-(3) admit actual edges with min(L,R)<r. No W_nu is charged per scale, and no cap is transferred to a smaller unsupported source cube.

This is a genuine monotone improvement of the paid allocation: if C denotes the old ordered capture, then D_y(L,R,z)>=C_y(min(L,R),z), so H_N^chi>=H_N. The exact remaining traffic is stated in section 5; this theorem does not imply all old weak-capture traffic has been paid.

## 2. Original heights: both orientations, without substituting e_g

The ORIGINAL low and high gates, with the same full e_g, imply

    p_y<=kappa0 c_j^(n/2)(LR)^(-n/2).

Since c_j<=1, the first general height is

    p_y<=kappa0(LR)^(-n/2).                              (7)

The actual band also gives c_j<=gamma min(L,R)/sqrt(LR). For L<=R this yields directly

    p_y<=kappa0 G L^(-n/4)R^(-3n/4).                     (8)

For L>R it first yields kappa0 G L^(-3n/4)R^(-n/4), which is at most the right side of (8) because L>R. Thus (8) is a valid GLOBAL second height. This step uses the band geometry; it does not infer (8) merely from p_y<=kappa0 R^(-n).

Equations (7)-(8) use no latent-softness cap or source-density assumption. They are applied only where the complete original I0 is nonzero. All original masks may subsequently be removed only by positive domination.

## 3. The single-witness theorem with the exact scale price

Fix a row y and one frozen accepted receiver u, with its SAME actual radius r=R(u). For any frozen pair weight 0<=omega(y,z)<=1 supported in Q_r(u), consider original traffic multiplied by omega(y,z)chi_r(L,R). No hard scale-eligibility gate is imposed.

If R<r, (1) gives chi_r<=(L/r)^(n/2)(R/r)^(3n/2). Hence by (7)

    p_y chi_r h_R(x-z)
       <=kappa0 r^(-2n)1_(Q_R(z))(x)
       <=kappa0 r^(-2n)1_(Q_r(z))(x).                   (9)

This is the central block already present in the original own-scale envelope at scale r. The supremum over all smaller legal R is dominated by that SAME block, not summed over smaller scales.

If R>=r, (1) is exactly min(1,(L/r)^(n/2)). Multiplying (7) gives

    p_y chi_r<=kappa0 r^(-n/2)R^(-n/2).

Multiplying (8) gives

    p_y chi_r<=kappa0 G r^(-n/4)R^(-3n/4),               (10)

because L^(-n/4)min(1,(L/r)^(n/2))<=r^(-n/4), separately for L<=r and L>=r. Therefore the complete product for ALL R in [a,b] is dominated by kappa0 times

    E_r(x-z)=sup_(r<=v<=b) v^(-n)1_(Q_v(z))(x)r^(-n)
               min[(v/r)^(-n/2),G(v/r)^(-3n/4)].        (11)

Indeed (9) is the v=r member of (11), and (10) supplies the other scales. The exact radial-shell integral is

    integral E_r dx=r^(-n)Psi_G((b/r)^n),
    Psi_G(B)=1+integral_1^B min(w^(-3/2),G w^(-7/4))dw
                  <=psi_inf.                          (12)

For completeness, Psi_G(B)=3-2B^(-1/2) for B<=G^4, and
Psi_G(B)=3-2/(3G^2)-(4/3)G B^(-3/4) for B>=G^4. The formulas agree at the crossover and at r=b give Psi_G(1)=1. All actual scales stay within [a,b]; the infinite integral is used only to upper-bound (12).

Retaining I0 until (7)-(10) are available, using q>=q_-, and then extending dx positively proves the rowwise receipt

    integral dx nu(dz) I0 p_y h_R/q omega chi_r
       <=(kappa0/q_-)r^(-n)Psi_G((b/r)^n)
                                      integral omega(y,z)nu(dz).
                                                               (13)

For omega=1_(Q_r(u)), the actual accepted witness cap gives

    nu(Q_r(u))<=4lambda r^n,
    row receipt <=(16/3)kappa0 Psi_G((b/r)^n)
                  <=(16/3)psi_inf kappa0.              (14)

There is no residual scale fee depending on r/a. Smaller actual R were absorbed by the central block in (9). The explicit price for allowing them is the penalty chi, not an extra source budget.

The simpler minscale penalty min(1,(min(L,R)/r)^(2n)) is also payable at the same price, because it is at most chi. The asymmetric form is stronger: for L<R and r<=R it only loses at most (L/R)^(n/2), rather than the minscale penalty's exponent 2n.

## 4. A common finite cover and exact iid averaging

For each nonzero row integrate N dummy witnesses u_1,...,u_N with product law pi_y^N. Put r_i=R(u_i) and

    w_i(x,y,z)=chi_(r_i)(L(x),R(x))1{z in Q_(r_i)(u_i)},
    H_config^chi=1-product_(i=1)^N(1-w_i).               (15)

All witnesses are fixed for the whole receiver integral. The actual field dependence in chi is a prescribed deterministic scale penalty, not a separately optimized witness choice at each x. Algebra gives

    0<=H_config^chi<=1, H_config^chi<=sum_i w_i.          (16)

Apply (13)-(14) to EACH witness before averaging, and sum the resulting rowwise receipts. This costs at most (16/3)psi_inf kappa0 N per beta row. The exact, possibly smaller fee is

    (kappa0/q_-) integral beta(dy)
       integral pi_y^N sum_i r_i^(-n)Psi_G((b/r_i)^n)
                                         nu(Q_(r_i)(u_i)).      (17)

Repeated hard-source mass in different witness cubes is explicitly charged in (17); it is not called disjoint. Its total is bounded by N witness caps, independently of the number of physical scales. This is the full repetition fee. No whole W_nu is restarted at each radius.

Independence gives the exact identity

    integral H_config^chi pi_y^N
              =1-[1-integral w_1 pi_y]^N=H_N^chi.       (18)

Positive Tonelli, (16)-(18) prove (4). The pointwise threshold domination in (5) then follows; (6) uses (1-log(2)/N)^N<=1/2. This proof does not treat H_N^chi as a receiver-independent pair mask in the R296 theorem. The legal sequence is the single-witness scale-penalty theorem, finite sum, and then averaging.

Unlike the average of a maximum, the product expression in (15) has exactly the iid formula (18). No reversed Jensen inequality is used. A probabilistic coin realization is unnecessary: (15) is already a bounded positive fractional allocation of original traffic.

Measurability follows from finite products and integration of the original measurable kernels. No measurable selection of a global random map y -> witnesses is needed. For I_y=0, nonnegative Tonelli gives zero original row traffic; assign zero H,D. The witness measures are absolutely continuous with respect to true du, so exceptional receiver null sets are not granted hard caps. Completed-measure versions or fixed Borel representatives yield the same integrals.

## 5. Exact residual, mismatch improvement, and success conditions

The new decomposition is exact:

    T=T_(H_N^chi)+T_((1-D_y(L,R,z))^N).                 (19)

Since chi=1 on r<=min(L,R), D>=C_y(min(L,R),z). Thus the newly paid allocation contains the R298 allocation pointwise; its additional part H_N^chi-H_N is nonnegative. This permits direct insertion into the existing positive ledger without recharging the old branch.

A concrete success condition for all the retained traffic is D_y(L(x),R(x),z)>=log(2)/N almost everywhere with respect to that original traffic. More generally (6) pays precisely that subset, and (19) keeps the rest. This condition is not deduced from arbitrary source masses or from the accepted receiver hard cap alone.

The rank bound now reaches both orientations with an explicit aspect-ratio cost. For any actual L,R define

    v(L,R)=min(1,(L/R)^(n/2)).

For every witness r<=R, formula (1) gives chi_r(L,R)>=v(L,R). Hence

    D_y(L,R,z)>=v(L,R)C_y(R,z).                         (20)

For fixed y,z let mu_yz be the pushforward by R(u) of the subprobability
1{z in Q_(R(u))(u)}pi_y(du), and let F_yz(r)=mu_yz([a,r]),
m_yz=mu_yz([a,b])<=1. This is the same inclusive CDF as in R298. On the actual subset v(L,R)>=v0, where 0<v0<=1 is fixed, (20) gives

    T_residual,{v>=v0}
      <=integral beta(dy) I_y integral nu(dz)
          integral_[a,b] r^(-n)[1-v0 F_yz(r)]^N mu_yz(dr).
                                                               (21)

Every original mask is removed only after writing the true receiver weight U_y dx and applying (20). The decreasing-CDF integral bound, valid also at atoms, is

    integral [1-v0 F(r)]^N mu(dr)
       <=[1-(1-v0 m)^(N+1)]/[v0(N+1)]
       <=1/[v0(N+1)].                                  (22)

At a jump use the right endpoint value of the decreasing function on its jump interval; continuous parts follow by the same distribution/quantile substitution. Thus

    T_residual,{v>=v0}
        <=W_nu/[a^n v0(N+1)] integral I_y beta(dy)
        <=S/[v0(N+1)] W_beta W_nu/(q_-a^n).             (23)

For L>=R, v=1 and this recovers R298's rank gain. For L<R it is NEW: every aspect subset L/R>=v0^(2/n) has a valid rank receipt with the exact factor 1/v0. This explicitly repairs the former absence of a rank bound on that orientation, while retaining the source-concentration fee. No source-linear consequence is inferred from (23).

The precise still-unpaid geometry is the weighted integral (21) when it cannot be controlled by root-polylog times W_beta+W_nu, together with the complementary aspect subset v<v0 if such a fixed v0 split is used. The unsplit exact residual is already (19); there is no requirement to make the v0 split. Joint geometry could improve (21) before discarding its r^(-n) weight, or enlarge D through a different legal common receiver probability. Neither improvement is assumed here. In particular a formal 1/N rank gain does not cancel the normalized product of source masses, and many scale-aspect slices cannot each receive a fresh W_nu budget.

## 6. Original outer fee and bounded computation

Everything is conditional on the full original outer/clock data xi. The formulas are jointly measurable when the original fields are. For N=N(xi), (4) contributes exactly

    integral Lambda(xi)(16/3)psi_inf(n)kappa0(xi)N(xi)
                                             W_beta(xi)dmu(xi),

and (6) has twice that fee. All earlier outer allocation and clock requirements remain. The cover is inserted only into already positive traffic; it is not differentiated inside an unrelated signed clock formula. FIRST remains an original hypothesis and can give the single aggregate baseline if needed; it is not swapped to nu or to a changed source.

An actual local Python exact-Fraction run passed 256 scale-height/penalty comparisons through n=64, 864 exact finite iid union identities, and 36 inclusive-CDF rank comparisons. The three parts test respectively the small/equal/large witness-scale regimes, finite shared witness unions with capture and noncapture, and rank distributions including atoms. These are finite algebra checks, not a numerical proof of all original L1 inputs. The analytic argument above supplies that proof interface. Exact code follows and writes no files.

```python
from fractions import Fraction as F
from itertools import product
counts={'height_checks':0,'iid_checks':0,'rank_checks':0}
for n in [4,8,16,64]:
 G=(1+F(1,n))**(n//2)
 for L,R,r in product([F(1),F(5,4),F(3,2),F(2)],repeat=3):
  chi=min(F(1),(L/r)**(n//2)*min(F(1),(R/r)**(3*n//2)))
  p=min((L*R)**(-n//2),G*L**(-n//4)*R**(-3*n//4))
  if R<r:
   assert p*chi*R**(-n)<=r**(-2*n)
  else:
   target=r**(-n)*min((R/r)**(-n//2),G*(R/r)**(-3*n//4))
   assert p*chi<=target
  assert chi>=min(F(1),(min(L,R)/r)**(2*n))
  if r<=min(L,R): assert chi==1
  if r<=R: assert chi>=min(F(1),(L/R)**(n//2))
  counts['height_checks']+=1
 probs=[F(1,6),F(1,3),F(1,2)]; radii=[F(1),F(3,2),F(2)]
 for L,R in product([F(1),F(3,2),F(2)],repeat=2):
  for capture in product([0,1],repeat=3):
   ws=[min(F(1),(L/r)**(n//2)*min(F(1),(R/r)**(3*n//2)))*c for r,c in zip(radii,capture)]
   D=sum(p*w for p,w in zip(probs,ws))
   for N in [1,2,3]:
    mean=F(0)
    for inds in product(range(3),repeat=N):
     mass=F(1); fail=F(1)
     for i in inds: mass*=probs[i]; fail*=1-ws[i]
     assert 1-fail<=sum(ws[i] for i in inds)
     mean+=mass*(1-fail)
    assert mean==1-(1-D)**N
    counts['iid_checks']+=1
for masses in [[F(1,4),F(1,2)],[F(1,10),F(1,10),F(1,10)],[F(1)]]:
 for v,N in product([F(1),F(1,2),F(1,100)],[1,2,8,64]):
  cum=F(0);lhs=F(0)
  for m in masses: cum+=m;lhs+=m*(1-v*cum)**N
  assert lhs<=(1-(1-v*cum)**(N+1))/(v*(N+1))
  counts['rank_checks']+=1
print('PASS',counts)
```

Only /tmp/r299_geometry.md was written. No earlier frozen proof, other author file or Git state was changed.
