from fractions import Fraction as F
import sys,random
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=45
atomic=0
for n in [1,2,4]:
    for N in [1,2,4,16,64]:
        for masses in [[F(1,10)]*3,[F(1,5),F(3,10),F(1,2)],
                       [F(0),F(1,4),F(1,4)]]:
            rs=[F(1),F(3,2),F(2)]
            f=H=D=direct=F(0);Hs=[];As=[]
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            for r,m in zip(rs,masses):
                old=f;f+=m
                D+=g(f)-g(old)-(1-f)**N*m
                H+=(1-f)**N*m;direct+=r**(-n)*(1-f)**N*m
                Hs.append(H);As.append(g(f))
                assert H==g(f)-D
            exact=rs[-1]**(-n)*Hs[-1]+sum(
                Hs[i]*(rs[i]**(-n)-rs[i+1]**(-n)) for i in range(2))
            upper=rs[-1]**(-n)*As[-1]+sum(
                As[i]*(rs[i]**(-n)-rs[i+1]**(-n)) for i in range(2))
            assert direct==exact and direct<=upper
            atomic+=1
continuous=0
for n in [1,3,32]:
    for N in [1,4,64]:
        for mass in map(mp.mpf,['.25','.75','1']):
            g=lambda u:(1-(1-u)**(N+1))/(N+1)
            lhs=mp.quad(lambda r:r**(-n)*(1-mass*(r-1))**N*mass,[1,2])
            rhs=2**(-mp.mpf(n))*g(mass)+n*mp.quad(
                lambda r:r**(-n-1)*g(mass*(r-1)),[1,2])
            assert abs(lhs-rhs)<mp.mpf('1e-35')
            continuous+=1
rng=random.Random(299);profiles=0
for k in range(60):
    ss=sorted(set(mp.mpf(rng.randint(0,100))/10 for _ in range(5)))
    pp=[mp.mpf(rng.randint(1,10)) for _ in ss];pp=[x/sum(pp) for x in pp]
    alpha=mp.mpf(10)**(-mp.mpf(k%7)/2);v=eps=mp.mpf(0)
    for j,(s,p) in enumerate(zip(ss,pp)):
        v+=p
        gap=ss[j+1]-s if j+1<len(ss) else mp.mpf(0)
        if v<=alpha:
            eps+=v*(-mp.expm1(-gap))
        else:
            cross=mp.log(v/alpha)
            eps+=alpha*gap if gap<=cross else alpha*(cross+1)-v*mp.exp(-gap)
        v*=mp.exp(-gap)
    eps+=min(v,alpha)
    D=ss[-1]-ss[0]
    bound=min(1,alpha*(1+D+max(0,mp.log(1/alpha))))
    assert eps<=bound+mp.mpf('1e-35');profiles+=1
print('PASS exact atomic weighted rank identities=',atomic)
print('PASS continuous weighted rank identities=',continuous)
print('PASS scale-span capacity profiles=',profiles)
