#!/usr/bin/env python3
"""R299 exact soft witness gate, scale-height transfer, and common iid geometry."""
import json,random
from pathlib import Path
from fractions import Fraction as F
from itertools import product
R=random.Random(29920261018)
FAIL=[];COUNTS={}
def check(ok,label,inputs):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'exact_inputs':inputs})
def chi(n,L,Rr,r):return min(F(1),(L/r)**(n//2)*min(F(1),(Rr/r)**(3*n//2)))
def mingate(n,L,Rr,r):return min(F(1),(min(L,Rr)/r)**(2*n))
def height_stage(ns,ratios,spread):
 cases=second=0;strict_min=strict_old=0;saturation=0;maxgain=F(1)
 for n in ns:
  for x,y in product(ratios,repeat=2):
   r=F(10)**R.randint(-spread,spread);L=r*x;Rr=r*y;w=chi(n,L,Rr,r);old=F(int(r<=min(L,Rr)));m=mingate(n,L,Rr,r)
   inputs={'n':n,'r':str(r),'L_over_r':str(x),'R_over_r':str(y)}
   check(old<=m<=w<=1,'old_min_new_gate_domination',inputs)
   strict_min+=w>m;strict_old+=w>old
   if m:maxgain=max(maxgain,w/m)
   p=(L*Rr)**(-n//2);hard=Rr**(-n);value=p*w*hard
   bound=r**(-2*n) if Rr<=r else r**(-n//2)*Rr**(-3*n//2)
   check(value<=bound,'two_piece_gated_height',inputs);cases+=1
   # L=r attains both pieces as a coefficient envelope, independently of x.
   sat=(r*Rr)**(-n//2)*chi(n,r,Rr,r)*hard
   check(sat==bound,'L_equals_r_saturates_raw_height',inputs);saturation+=1
   if n%4==0:
    gamma=F(n+1,n);G=gamma**(n//2);p2=G*L**(-n//4)*Rr**(-3*n//4)
    transferred=G*r**(-n//4)*Rr**(-7*n//4)
    check(p2*w*hard<=transferred,'second_height_transfer',inputs)
    combined=min(p,p2)*w*hard;combinedbound=bound if Rr<=r else min(bound,transferred)
    check(combined<=combinedbound,'combined_sharp_two_piece_height',inputs);second+=1
 return {'height_cases':cases,'second_height_cases_multiple_of_four':second,'exact_L_equals_r_saturation_checks':saturation,'strict_gate_gain_over_2n_min_cases':strict_min,'strict_gate_gain_over_hard_cases':strict_old,'max_chi_over_min_gate':str(maxgain)}

def spatial(ns):
 count=sharpcount=0;examples=[]
 for n in ns:
  for r in [F(1),F(3,2),F(2)]:
   a=F(1);b=F(2);rs=sorted(set([a,(a+r)/2,r,(r+b)/2,b]));rv=r**n
   # R<=r coefficient is constant and Q_r is in the finite menu.
   finite=rv*r**(-2*n);prev=rv
   for Rr in [v for v in rs if v>r]:
    vol=Rr**n;finite+=(vol-prev)*r**(-n//2)*Rr**(-3*n//2);prev=vol
   exact=rv**(-1)*(3-2*(r/b)**(n//2))
   shell=2*r**(-n//2)*(r**(-n//2)-b**(-n//2))
   inputs={'n':n,'r':str(r),'a':'1','b':'2'}
   check(rv**(-1)+shell==exact,'continuous_raw_shell_identity',inputs)
   check(finite<=exact<=3/rv,'finite_menu_le_continuous_raw_envelope',inputs);count+=1
   if n%4==0:
    G=F(n+1,n)**(n//2);S=(b/r)**n
    psi=3-2*(r/b)**(n//2) if S<=G**4 else 3-F(2,3)/G**2-F(4,3)*G*(r/b)**(3*n//4)
    finite2=1/rv;prev=rv
    for Rr in [v for v in rs if v>r]:
     vol=Rr**n;coef=min(r**(-n//2)*Rr**(-3*n//2),G*r**(-n//4)*Rr**(-7*n//4));finite2+=(vol-prev)*coef;prev=vol
    switch=min(b,r*F(n+1,n)**2)
    continuous=1/rv+2*r**(-n//2)*(r**(-n//2)-switch**(-n//2))+F(4,3)*G*r**(-n//4)*(switch**(-3*n//4)-b**(-3*n//4))
    check(rv*continuous==psi,'continuous_sharp_shell_identity',inputs)
    limit=3-F(2,3)/(F(n+1,n)**n)
    check(rv*finite2<=psi<=limit and psi<=rv*exact,'sharp_Psi_same_fee_transfer',inputs);sharpcount+=1
    if r==1:examples.append({'n':n,'r':'1','b':'2','exact_raw_envelope_integral':str(exact),'exact_sharp_Psi_G':str(psi)})
 return {'independent_radial_finite_menu_cases':count,'sharp_Psi_cases':sharpcount,'examples':examples}

def iid_stage(ns):
 casecount=configs=columnchecks=0;strictold=strictmin=0;examples=[]
 for n in ns:
  radii=[F(1),F(3,2),F(2)];pi=[F(1,2),F(1,3),F(1,6)]
  centers=[[F(0)]*n for _ in range(3)];centers[1][0]=F(3,4);centers[2][1]=F(3,4)
  points=[[F(0)]*n for _ in range(6)]
  points[0][0]=F(-1,2);points[2][0]=F(1,2);points[3][0]=F(3,2);points[4][1]=F(3,2);points[5][0]=points[5][1]=F(3)
  A=[[int(all(abs(x-z)<=r/2 for x,z in zip(c,p))) for p in points] for c,r in zip(centers,radii)]
  for index,(L,Rr) in enumerate([(F(1),F(1)),(F(1),F(2)),(F(2),F(1)),(F(3,2),F(3,2)),(F(2),F(2)),(F(3,2),F(1)),(F(1),F(3,2))]):
   N=1+index%4;ws=[chi(n,L,Rr,r) for r in radii];mins=[mingate(n,L,Rr,r) for r in radii];olds=[F(int(r<=min(L,Rr))) for r in radii]
   Ds=[sum(pi[i]*ws[i]*A[i][z] for i in range(3)) for z in range(len(points))]
   av=[F(0)]*len(points);mv=[F(0)]*len(points);ov=[F(0)]*len(points)
   for tup in product(range(3),repeat=N):
    prob=F(1)
    for i in tup:prob*=pi[i]
    for z in range(len(points)):
     hn=hm=ho=F(1)
     for i in tup:hn*=1-ws[i]*A[i][z];hm*=1-mins[i]*A[i][z];ho*=1-olds[i]*A[i][z]
     hn,hm,ho=1-hn,1-hm,1-ho
     check(hn>=hm>=ho,'common_configuration_gate_domination',{'n':n,'L':str(L),'R':str(Rr),'N':N,'tuple':list(tup),'target':z})
     av[z]+=prob*hn;mv[z]+=prob*hm;ov[z]+=prob*ho
    configs+=1
   for z in range(len(points)):
    target=1-(1-Ds[z])**N
    check(av[z]==target,'common_iid_exact_average',{'n':n,'L':str(L),'R':str(Rr),'N':N,'target':z,'D':str(Ds[z]),'actual':str(av[z]),'formula':str(target)})
    check(av[z]>=mv[z]>=ov[z],'averaged_gate_domination',{'n':n,'L':str(L),'R':str(Rr),'N':N,'target':z})
    if not any(A[i][z] for i in range(3)):check(av[z]==0,'uncovered_target_zero_mask',{'n':n,'target':z})
    strictold+=av[z]>ov[z];strictmin+=av[z]>mv[z];columnchecks+=1
   if n==4 and L==1 and Rr==2:
    examples.append({'n':n,'L':'1','R':'2','N':N,'target':'origin','D_new':str(Ds[1]),'new_average_mask':str(av[1]),'old_hard_average_mask':str(ov[1]),'min_gate_average_mask':str(mv[1])})
   casecount+=1
 return {'genuine_cube_point_cases':casecount,'iid_tuple_configurations':configs,'target_average_checks':columnchecks,'strict_averaged_gain_over_hard_columns':strictold,'strict_averaged_gain_over_min_columns':strictmin,'closed_cube_boundary_convention':True,'examples':examples}
settings=[('equal_scale_initial',[2,4],[F(1,2),F(1),F(2)],2),('boundary_and_unequal',[4,8,16],[F(1,4),F(1,2),F(3,4),F(1),F(3,2),F(2),F(4)],12),('expanded',[8,16,32],[F(1,10**12),F(1,1000),F(1,2),F(1),F(2),F(1000),F(10**12)],100)]
stages=[]
for name,ns,ratios,spread in settings:stages.append({'name':name,'dimensions':ns,'height_and_gate':height_stage(ns,ratios,spread),'radial_envelope':spatial(ns),'common_iid_cubes':iid_stage(ns)})
out={'status':'PASS' if not FAIL else 'FAIL','seed':29920261018,'scope':'Exact Fraction scalar height/gate and radial cube-envelope identities plus finite genuine closed-cube POINT incidence and common iid tuple enumeration. Extreme positive ratios are scalar stress cases, not asserted original physical-window histories. Point tests do not replace positive-volume/L1 proofs, and no FULL/source closure is claimed.','chi':'min(1,(L/r)^(n/2)*min(1,(R/r)^(3n/2)))','comparison':'old hard 1{r<=min(L,R)} <= min(1,(min(L,R)/r)^(2n)) <= chi','iid_average':'E[1-product_k(1-chi_i_k*capture_i_k,z)]=1-(1-sum_i pi_i chi_i capture_i,z)^N','check_counts':COUNTS,'failures':FAIL,'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'stage_counts':[{'name':s['name'],'height_cases':s['height_and_gate']['height_cases'],'cube_cases':s['common_iid_cubes']['genuine_cube_point_cases']} for s in stages]},indent=2))
