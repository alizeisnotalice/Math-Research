#!/usr/bin/env python3
"""R181 finite exact reserve-weighted checks. No physical/FIRST claim."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,sys,hashlib
HERE=Path(__file__).resolve().parent
def fs(x):return [F(v) for v in x]
def sm(x):return sum(x,F(0))
def fixture(name,stage,nu,J,K,q,D,a,ap,E,Ep,bb=None,bp=None):
 return dict(name=name,stage=stage,nu=fs(nu),J=fs(J),K=fs(K),q=F(q),D=F(D),a=fs(a),a_prime=fs(ap),E=E,E_prime=Ep)
def fixtures():
 ep=F(1,1024);tiny=F(1,2**20)
 return [
 fixture('identical','initial',[F(1,2)]*2,[1,2],[1,1],2,1,[3,0],[3,0],[1,0],[1,0],[0,1],[0,1]),
 fixture('capture_and_active_change','initial',[1,1],[1,1],[2,1],3,1,[1,6],[F(3,2),F(13,2)],[1,1],[1,1]),
 fixture('positive_small_K_mask_exchange','initial',[1],[1],[F(1,100)],1,1,[4],[4],[0],[1]),
 fixture('alpha_zero_saturated_capture','initial',[F(1,2)]*2,[1,2],[1,2],F(3,2),1,[3,6],[4,7],[1,1],[1,1]),
 fixture('zero_a_to_active','mask_zero_stress',[1],[1],[1],1,1,[0],[2],[1],[1]),
 fixture('all_zero_a_mask_changes','mask_zero_stress',[F(1,3),F(2,3)],[1,2],[1,3],3,1,[0,0],[0,0],[0,1],[1,0]),
 fixture('zero_mass_slot_ignored','mask_zero_stress',[0,1],[100,1],[100,1],1,1,[999,2],[0,3],[0,1],[1,1]),
 fixture('zero_K_exchange_necessity','mask_zero_stress',[1],[1],[0],1,1,[4],[4],[0],[1]),
 fixture('alpha_zero_to_positive','mask_zero_stress',[1,1],[1,1],[1,0],1,1,[2,4],[2,4],[1,1],[0,1]),
 fixture('near_sharp_S1','expanded',[1,1],[ep,1],[1,ep],1+ep,1,[F(1,2),1024],[F(5,8),1024],[1,1],[1,1],[1,1],[1,1]),
 fixture('D_and_J_range','expanded',[F(1,8),F(7,8)],[F(1,16),16],[F(1,4),2],2,F(7,3),[F(1,100),100],[F(1,10),101],[1,1],[0,1]),
 fixture('threshold_and_mask_crossing','expanded',[1,2,3],[1,F(1,8),8],[0,1,2],10,F(1,3),[0,F(1,3),4],[F(1,10),0,F(9,2)],[1,0,1],[0,1,1]),
 fixture('unequal_mass_and_large_a','expanded',[tiny,1-tiny],[1024,F(1,1024)],[1,1],2,1,[10000,100000],[10001,100003],[1,0],[0,1])]
def S(a,k,t):return F(0) if a==0 or a<=k+t else t*(a-k-t)**2/a**2
def expanded_S(a,k,t):return F(0) if a==0 or a<=k+t else t-2*t*(k+t)/a+t*(k+t)**2/a**2
def checkS(c):
 nu,J,K,a,ap,E,Ep=(c[k] for k in ('nu','J','K','a','a_prime','E','E_prime'));D,q=c['D'],c['q'];QJ=sm(j*m for j,m in zip(J,nu));assert QJ>0 and D>=0 and sm(k*m for k,m in zip(K,nu))<=q and all(v>=0 for v in nu+K+a+ap) and all(v>0 for v in J)
 cap=sm(e*min(x,D*k)*m for e,x,k,m in zip(E,a,K,nu));capp=sm(e*min(x,D*k)*m for e,x,k,m in zip(Ep,ap,K,nu));al=(D*q-cap)/QJ;alp=(D*q-capp)/QJ;assert al>=0 and alp>=0
 ss=[S(x,D*k,al*j) for x,k,j in zip(a,K,J)];ssp=[S(x,D*k,alp*j) for x,k,j in zip(ap,K,J)];acts=[e*v for e,v in zip(E,ss)];actp=[e*v for e,v in zip(Ep,ssp)];A=sm(abs(x-y)*m for x,y,m in zip(a,ap,nu));B=sm(k*abs(e-f)*m for k,e,f,m in zip(K,E,Ep,nu));Y=sm(min(x,y)*abs(e-f)*m for x,y,e,f,m in zip(ss,ssp,E,Ep,nu));lhs=sm(abs(x-y)*m for x,y,m in zip(ss,ssp,nu));lhsact=sm(abs(x-y)*m for x,y,m in zip(acts,actp,nu));bound=A+D*B
 identities=dict(signed_alpha=(alp-al)*QJ==cap-capp,expanded_S=all(v==expanded_S(x,D*k,al*j) for v,x,k,j in zip(ss,a,K,J)) and all(v==expanded_S(x,D*k,alp*j) for v,x,k,j in zip(ssp,ap,K,J)),homogeneity=all(S(F(3,2)*x,F(3,2)*D*k,F(3,2)*al*j)==F(3,2)*v for x,k,j,v in zip(a,K,J,ss)),capture_activity_disjoint=all(not(x<D*k and S(x,D*k,al*j)>0) for x,k,j in zip(a,K,J)))
 checks=dict(virtual_constant1=lhs<=bound,actual_mask_with_Y=lhsact<=bound+Y,S_bound=all(0<=v<=F(4,27)*x for v,x in zip(ss,a)) and all(0<=v<=F(4,27)*x for v,x in zip(ssp,ap)),alpha_capture=abs(al-alp)*QJ<=bound,identities=all(identities.values()))
 return dict(input=c,QJ=QJ,alpha=al,alpha_prime=alp,S=ss,S_prime=ssp,E_S=acts,E_S_prime=actp,A=A,B=B,Y=Y,virtual_lhs=lhs,actual_lhs=lhsact,bound_A_DB=bound,virtual_over_A=lhs/A if A else None,without_Y_pass=lhsact<=bound,identities=identities,checks=checks,scope='Finite algebraic arrays, not original physical/FIRST/history examples')

def mul(a,b):
 out=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def derivative_checks():
 factors=dict(S_sharp_factor=mul(mul([F(-1,3),1],[F(-1,3),1]),[F(4,3),-1])==[F(4,27),-1,2,-1],Ha_sharp_factor=[2*v for v in mul(mul([F(-2,3),1],[F(-2,3),1]),[F(1,3),1])]==[F(8,27),0,-2,2],Ht_lower_factor=[3*v for v in mul([F(-2,3),1],[F(-2,3),1])]==[F(4,3),-4,3])
 points=[('initial',F(0),F(0)),('initial',F(1,3),0),('initial',F(2,3),0),('initial',F(1,6),F(1,6)),('stress',0,F(1)),('stress',1,0),('stress',0,F(1,2)),('stress',F(1,2),F(1,2)),('expanded',F(1,1024),0),('expanded',F(1,2),F(1,1024)),('expanded',F(511,1024),F(513,1024)),('expanded',F(7,16),F(5,16))];out=[]
 for stage,x,y in points:
  x,y=F(x),F(y);z=x+y;assert 0<=z<=1;s=x*(1-z)**2;ha=2*x*z*(1-z);ht=(1-z)*(1-z-2*x)
  out.append(dict(stage=stage,x_t_over_a=x,y_k_over_a=y,S_over_a=s,H_a=ha,H_alpha_over_J_right_at_alpha0=ht,checks=dict(S=s<=F(4,27),Ha=0<=ha<=F(8,27),Ht=F(-1,3)<=ht<=1,Ha_majorant=ha<=2*z*z*(1-z),Ht_upper_gap=1-ht==z*(2-z)+2*x*(1-z))))
 return dict(polynomial_identities=factors,points=out,scope='Exact normalized derivative algebra including alpha0 right derivative; finite checks supplement the separate analytic proof')

def repair_case(name,stage,parent,beta,nu,K,J,q,D,bad,Ufraction):
 parent,beta,nu,K,J=map(fs,(parent,beta,nu,K,J));q,D=F(q),F(D);n=len(parent);assert D>0 and 0<=F(Ufraction)<=1 and all(0<=b<=a and 0<=v<=a for a,b,v in zip(parent,beta,nu)) and all(k>0 for k in K) and all(j>0 for j in J) and q>=sm(k*a for k,a in zip(K,parent))
 eta=[min(b,v) for b,v in zip(beta,nu)];zp=[max(b-v,0) for b,v in zip(beta,nu)];bt=[max(b,v) for b,v in zip(beta,nu)];QJ=sm(j*v for j,v in zip(J,nu));G=q-sm(k*v for k,v in zip(K,nu));Z=sm(k*z for k,z in zip(K,zp));carrier=[int(b>0) for b in beta];kernel=[F((i+1)**2)*carrier[i] for i in range(n)];CB=sm(g*b for g,b in zip(kernel,beta));CE=sm(g*v for g,v in zip(kernel,eta));CZ=sm(g*z for g,z in zip(kernel,zp));CN=sm(g*v for g,v in zip(kernel,nu));basechecks=dict(split=all(b==e+z for b,e,z in zip(beta,eta,zp)),positivepart_parent=all(z<=a-v for z,a,v in zip(zp,parent,nu)),max_parent=all(t<=a and t==v+z for t,a,v,z in zip(bt,parent,nu,zp)),outer_same_carrier=CB==CE+CZ and CB<=CN+CZ,reserve_GZ=G>=Z>=0)
 if QJ==0:
  assert all(v==0 for v in nu)
  basechecks['zero_inner_measure']=True
  return dict(name=name,stage=stage,parent=parent,f=parent,beta=beta,nu=nu,eta=eta,zeta_plus=zp,beta_tilde=bt,G=G,Z=Z,QJ=QJ,checks=basechecks,no_inner_branch=True,normalization_performed=False,alpha=None,tau=None,mu=None,moments={1:F(0),2:F(0)},scope='Zero inner measure: original pair zero; no alpha or reserve-density division')
 rows=[]
 for y in range(n):
  U=[F(0) if bad[y][i] else F(Ufraction)*D*K[i] for i in range(n)];B=sm(k*v*int(bb) for k,v,bb in zip(K,nu,bad[y]));gam=q-sm(u*v for u,v in zip(U,nu))/D;alpha=D*gam/QJ;assert gam>=G+B>=0
  if gam==0:assert B==0 and K[y]*zp[y]==0;ta=F(0);mu=[F(0)]*n
  else:ta=K[y]*zp[y]/gam;mu=[k*v*int(bb)/gam for k,v,bb in zip(K,nu,bad[y])]
  rows.append(dict(y=y,U=U,bad=bad[y],B=B,gamma=gam,alpha=alpha,tau=ta,mu=mu,mu_mass=sm(mu),reserve_slack=gam-G-B))
 moments={};bounds={};direct={};scalar={}
 for r in (1,2):
  moments[r]=sm(z['tau']*z['mu_mass']**r for z in rows);const=F(r**r,(r+1)**(r+1));bounds[r]=Z/G*const if G else F(0);direct[r]=F(0);scalar[r]=True
  for z in rows:
   if z['gamma']:
    numerator=K[z['y']]*zp[z['y']];direct[r]+=sm(numerator*prod([K[i]*nu[i]*int(z['bad'][i]) for i in picks])/z['gamma']**(r+1) for picks in product(range(n),repeat=r))
   B=z['B']
   if G:
    scalar[r] &= (G+B)**2-4*G*B==(B-G)**2 if r==1 else 4*(G+B)**3-27*G*B**2==(B-2*G)**2*(4*B+G)
  basechecks['moment_'+str(r)]=moments[r]<=bounds[r]<=const and direct[r]==moments[r] and scalar[r]
 basechecks['gamma0_bad0']=all(z['gamma']!=0 or (z['B']==0 and all(not bb or v==0 for bb,v in zip(z['bad'],nu))) for z in rows)
 basechecks['tau_mu_mass']=sm(z['tau'] for z in rows)<=1 and all(z['mu_mass']<=1 for z in rows)
 return dict(name=name,stage=stage,parent=parent,f=parent,beta=beta,nu=nu,ordered_nu_le_beta=all(v<=b for v,b in zip(nu,beta)),eta=eta,zeta_plus=zp,beta_tilde=bt,QJ=QJ,G=G,Z=Z,outer_carrier=carrier,outer_kernel_fixed=kernel,outer_integrals=dict(beta=CB,eta=CE,zeta_plus=CZ,nu_upper=CN),rows=rows,moments=moments,moment_bounds=bounds,direct_source_sums=direct,checks=basechecks,no_inner_branch=False,scope='Finite common-parent reserve algebra; fixed original rows, no physical FIRST/history claim')
def prod(xs):
 out=F(1)
 for x in xs:out*=x
 return out
def repair_checks():
 A=[F(5,6),F(7,10),F(4,5)];be=[F(3,4),F(1,5),F(2,3)];nu=[F(1,4),F(3,5),F(1,2)];K=[F(1,10),F(1,5),F(3,10)];J=[F(1,10),F(3,20),F(1,5)];bad=[[i==y for i in range(3)] for y in range(3)]
 out=[repair_case('unordered_equality_reserve','initial',A,be,nu,K,J,F(1,2),1,bad,1),repair_case('unordered_strict_reserve','initial',A,be,nu,K,J,F(1,2),F(7,3),bad,F(1,2))]
 nu2=[F(1,3),F(2,3)];K2=[F(1,2),F(3,4)];q=sm(k*v for k,v in zip(K2,nu2));
 out.append(repair_case('zero_G_zero_alpha','stress',nu2,[F(1,4),F(1,2)],nu2,K2,[1,2],q,1,[[False,False]]*2,1))
 out.append(repair_case('zero_G_bad_positive','stress',nu2,[F(1,4),F(1,2)],nu2,K2,[1,2],q,1,[[True,False]]*2,1))
 out.append(repair_case('zero_inner_QJ','stress',[1,1],[F(1,2),F(3,4)],[0,0],[1,2],[1,1],3,1,[[False,False]]*2,1))
 for r in (1,2):out.append(repair_case('moment_sharp_r'+str(r),'expanded',[r,1],[0,1],[r,0],[1,1],[1,1],r+1,1,[[True,False]]*2,1))
 return out

def tv_case(name,stage,M,nu,w,wp,Z):
 M=F(M);nu,w,wp=map(fs,(nu,w,wp));n=len(nu);assert M>=1 and all(x>0 for x in w+wp) and all(v>=0 for v in nu) and all(z in (0,1) for z in Z)
 ratios=[b/a for a,b in zip(w,wp)];assert all(1/M<=r<=M for r in ratios)
 e=sm(z*a*v for z,a,v in zip(Z,w,nu));ep=sm(z*a*v for z,a,v in zip(Z,wp,nu));assert e>0 and ep>0
 P=[z*a*v/e for z,a,v in zip(Z,w,nu)];PP=[z*a*v/ep for z,a,v in zip(Z,wp,nu)];diff=[b-a for a,b in zip(P,PP)];single=sm(abs(v) for v in diff)/2;dual=sm(max(v,0) for v in diff);joint=[PP[i]*PP[j]-P[i]*P[j] for i in range(n) for j in range(n)];double=sm(abs(v) for v in joint)/2;dual2=sm(max(v,0) for v in joint);bound=(M-1)/(M+1);bound2=(M*M-1)/(M*M+1)
 Fsingle=[F(i%3,2) for i in range(n)];Fpair=[F((i+2*j)%5,4) for i in range(n) for j in range(n)];test1=abs(sm(f*d for f,d in zip(Fsingle,diff)));test2=abs(sm(f*d for f,d in zip(Fpair,joint)))
 RN=[b/a if a else None for a,b in zip(P,PP)]
 checks=dict(same_support=all((a==0)==(b==0) for a,b in zip(P,PP)),RN_bounds=all(1/M**2<=r<=M**2 for r in RN if r is not None) and all(1/M**4<=RN[i]*RN[j]<=M**4 for i in range(n) for j in range(n) if RN[i] is not None and RN[j] is not None),normalized=sm(P)==sm(PP)==1,halfL1_duality=single==dual and double==dual2,single_bound=single<=bound,double_bound=double<=bound2,fixed_test= test1<=single and test2<=double,denominator_identity=all(d==z*v*(b*e-a*ep)/(e*ep) for d,z,v,a,b in zip(diff,Z,nu,w,wp)),product_identity=all(PP[i]*PP[j]-P[i]*P[j]==(PP[i]-P[i])*PP[j]+P[i]*(PP[j]-P[j]) for i in range(n) for j in range(n)))
 return dict(name=name,stage=stage,M=M,nu=nu,w=w,w_prime=wp,Z_fixed=Z,raw_ratios=ratios,e=e,e_prime=ep,P=P,P_prime=PP,normalized_RN=RN,single_TV_halfL1=single,single_positive_indicator_test=dual,single_bound=bound,two_copy_TV_halfL1=double,two_copy_positive_indicator_test=dual2,two_copy_bound=bound2,fixed_single_test=Fsingle,fixed_pair_test=Fpair,fixed_test_changes=[test1,test2],checks=checks,scope='Same fixed original Z and nu; only weights and full normalizers change. Numerical algebra, no score/history change')
def tv_checks():
 tiny=F(1,2**100);big=F(2**60)
 return [tv_case('M1_identical','initial',1,[1,1],[1,1],[1,1],[1,1]),tv_case('M2_single_sharp','initial',2,[F(2,3),F(1,3)],[1,1],[F(1,2),2],[1,1]),tv_case('M3_nonuniform','initial',3,[1,2,3],[1,F(1,2),F(1,4)],[F(1,3),F(1,2),F(3,4)],[1,1,1]),tv_case('tiny_common_weights','stress',2,[F(2,3),F(1,3)],[tiny,tiny],[tiny/2,2*tiny],[1,1]),tv_case('fixed_mask_and_zero_nu','stress',2,[1,2,3,0],[1,2,3,1],[F(1,2),4,3,2],[1,0,1,1]),tv_case('large_common_mass','expanded',16,[big,3*big,5*big],[F(1,8),F(1,4),F(1,2)],[F(1,128),F(1,4),8],[1,1,1]),tv_case('eight_slots','expanded',4,[1,2,3,5,7,11,13,17],[1,F(1,2),F(1,4),F(1,8),F(1,16),F(1,3),F(1,5),F(1,7)],[F(1,4),2,F(1,4),F(1,4),F(1,32),F(4,3),F(1,20),F(2,7)],[1]*8)]

def main():
 sc=[checkS(c) for c in fixtures()];der=derivative_checks();rep=repair_checks();tv=tv_checks();fail=[c['input']['name'] for c in sc if not all(c['checks'].values())]+[c['name'] for c in rep if not all(c['checks'].values())]+['derivative_polynomials' for v in der['polynomial_identities'].values() if not v]+['derivative_point' for c in der['points'] if not all(c['checks'].values())]
 fail += [c['name'] for c in tv if not all(c['checks'].values())]
 missingY=not next(c for c in sc if c['input']['name']=='zero_K_exchange_necessity')['without_Y_pass'];assert missingY
 out=dict(scope='Self-contained finite Fraction checker for final S and positive-part reserve algebra; not original physical/FIRST/history examples or global payment.',S_cases=sc,derivative=der,repair=rep,normalized_TV=tv,expected_omitted_cost_failure=dict(without_Y_fails=missingY),unexpected_failures=fail,all_exact_pass=not fail,definitions=dict(S='alpha*J*(1-(DK+alpha*J)/a)_+^2, a0=0',virtual_bound='A+DB',actual_bound='A+DB+Y',Y='sum min(S,S_prime)|E-E_prime|nu',same_support_TV='single <=(M-1)/(M+1), two independent copies <=(M^2-1)/(M^2+1); raw ratio controlled only with fixed Z',common_parent='beta,nu<=parent; eta=min, zeta_plus=(beta-nu)+, beta_tilde=max; no nu<=beta assumption',moments='sum tau_y*mu_y_mass^r <= (Z/G)*r^r/(r+1)^(r+1), r1/r2; G0 outer branch zero'),local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},runtime=dict(python=sys.version),limitations=['Exact certificates concern only the listed algebraic finite cases and polynomial identities.','Original kernels, source/history eligibility, actual dx/window/j costs are not instantiated.','Outer carrier and row coefficients are held fixed during positive comparison; no recapture or history regeneration.','No quadrature, physical scan, or asymptotic fit.'])
 (HERE/'reserve_weighted_checks.json').write_text(json.dumps(out,indent=2,default=str)+'\n');print(json.dumps(dict(S_cases=len(sc),derivative_points=len(der['points']),repair_cases=len(rep),TV_cases=len(tv),all_exact_pass=not fail,near_sharp_S_over_A=str(next(c for c in sc if c['input']['name']=='near_sharp_S1')['virtual_over_A']),unexpected_failures=fail)))
 if fail:raise SystemExit(1)
if __name__=='__main__':main()
