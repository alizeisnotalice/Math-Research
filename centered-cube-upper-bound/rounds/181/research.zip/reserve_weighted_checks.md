# R181 reserve-weighted finite checks

All finite checks pass for the new reserve-weighted S coefficient1, its sharp pointwise constants, the unordered common-parent positive-part repair, and the same-support normalized TV bounds. The script uses only Fraction arithmetic and the standard library. It supplies exact finite certificates and polynomial identities, not physical FIRST/history examples or a global traffic bound.

Run `python3 reserve_weighted_checks.py` from any directory. Only the checker and adjacent task contract are required; output is the adjacent JSON. There is no old JSON, numerical library, physical kernel or quadrature dependency. Unexpected failures are recorded and cause a nonzero exit code.

## Three bounded stages

|Test family|Initial|Stress|Expanded|
|---|---:|---:|---:|
|S stability|4|5|4|
|Normalized derivative points|4|4|4|
|Positive-part reserve repair|2|3|2|
|Same-support TV|3|2|2|

The39 named finite fixtures are accompanied by three exact polynomial coefficient identities. They are not a parameter sweep. Twelve S input arrays reuse R180's exact algebraic inputs; its now-irrelevant b-only fixture is replaced by an alpha0-to-positive capture change. No old physical quadrature is repeated.

## Same-alpha S and constant1

For QJ=sum Jnu>0, k=DK, q>=Knu and nonnegative data, retain

`alpha=(Dq-sum E min(a,k)nu)/QJ`,
`S=alpha J*(1-(k+alpha J)/a)_+^2`, with S=0 at a=0.

The author/independent audit screened the final bounds before dependent checks. For A=sum|a-a'|nu, B=sum K|E-E'|nu and Y=sum min(S,S')|E-E'|nu, the checker verifies

`sum |S-S'|nu <= A+DB`,
`sum |ES-E'S'|nu <= A+DB+Y`,
`S<=4a/27`.

Every normalization is recomputed from the same nu and appropriate capture row. Independent exact formulas check the signed capture/alpha identity, expanded S, homogeneity, and disjoint capture versus direct-a activity. The near-sharp finite input from R180 now gives

`sum |S-S'|nu/A =1153200589166610433/1156302503936000000 ≈.997317384716516`.

It supports confidence in coefficient1 within this algebraic class, not a physical traffic lower bound or dimensional order.

The zero-K mask-exchange fixture has alpha=alpha'=1, a=a'=4 and E0->E'1. It gives A=B=0 and virtual variation0, but actual variation9/16. Y=9/16 pays it exactly. Thus omitting the actual mask exchange price fails; no unexpected failure of the final bound remains. The alpha0-to-positive fixture is retained rather than dividing by or discarding alpha0: its virtual and actual changes are53/128 and49/128, both below DB=1.

For normalized x=alpha J/a, y=k/a and z=x+y in[0,1], the active-branch quantities are

`S/a=x(1-z)^2`,
`H_a=2xz(1-z)`,
`H_alpha/J=(1-z)(1-z-2x)`.

The12 rational points check S/a<=4/27, H_a<=8/27 and H_alpha/J in[-1/3,1], including the right derivative at alpha0. The three independent coefficient identities are

- 4/27-x(1-x)^2=(x-1/3)^2*(4/3-x);
- 8/27-2z^2(1-z)=2(z-2/3)^2*(z+1/3);
- (1-z)(1-3z)+1/3=3(z-2/3)^2.

The upper derivative gap is also checked as `1-H_alpha/J=z(2-z)+2x(1-z)`. The extrema are attained at the stated rational points; they are not inferred from a grid maximum. The separate audit supplies the path/disjoint-region proof of global stability; these checks do not replace it. In particular the original J*rho^2 still requires its remaining alpha-dependent normalization and actual source/bad masks before traffic payment.

## Common-parent positive part and actual reserve density

All repair fixtures retain arbitrary positive beta,nu under a common parent P, with f=P for the finite kernel test. They do not assume nu<=beta. Set eta=min(beta,nu), zeta_plus=(beta-nu)+ and beta_tilde=max(beta,nu). The code checks beta=eta+zeta_plus, eta<=nu, zeta_plus<=P-nu and beta_tilde<=P. An arbitrary nonnegative outer test is fixed on the original beta carrier and zero-extended elsewhere. Thus C_beta=C_eta+C_zeta_plus<=C_nu+C_zeta_plus uses the same test and original row coefficients; it does not recapture new sources or give new history eligibility.

For strictly positive K and J, q>=Kf, define G=q-Knu>=Z=Kzeta_plus. For each original outer row, U=0 on its bad source and0<=U<=DK elsewhere. The same original reserve is

`gamma=q-U nu/D >=G+B_y`, with `B_y=K(bad_y nu)`,
`alpha_rec=D gamma/QJ`,
`tau_y=K_y zeta_plus_y/gamma_y`,
`mu_y(u)=K_u bad_y(u)nu_u/gamma_y`.

The checker preserves these actual finite densities and verifies

`sum tau_y ||mu_y||^r <= (Z/G)*r^r/(r+1)^(r+1)`, r1 and r2.

It independently expands the moments as full positive source double/triple sums. The scalar identities `(G+B)^2-4GB=(B-G)^2` and `4(G+B)^3-27GB^2=(B-2G)^2(4B+G)` check the capacity constants. Two prescribed constructions attain exactly1/4 for r1 and4/27 for r2. The unordered initial fixture and a strict-reserve variant both pass.

Zero branches are explicit: G0 with positive K forces the positive outer source to vanish; tau is0. A gamma0 row forces its bad source mass0 before mu is defined as0. QJ0 forces zero inner nu and zero pair traffic; alpha/tau/mu are left undefined rather than divided by0. These scalar joint capacities do not include the original CJ physical kernel or pay its receiver column. They are not free independent source probabilities.

## Same-Z normalized receiver error

Astra and the independent audit confirmed the exact hypotheses before this part: nu and Z stay fixed; positive unnormalized weight ratios w'/w lie in[1/M,M]; and both full denominators are recomputed. Scores, gates and test functions are not changed. Let P=Z wnu/e and P'=Z w'nu/e'. Seven exact fixtures check

`TV(P,P')=halfL1 <=(M-1)/(M+1)`,
`TV(P tensor P,P' tensor P') <=(M^2-1)/(M^2+1)`.

For r=log M, these bounds are tanh(r/2) and tanh r. Each row checks halfL1 equals the positive-difference indicator's expectation, which certifies the finite dual norm; it does not change the original test in an application. Separate fixed bounded single/pair tests are also checked. Independent formulas verify the full-denominator difference and product telescoping. Normalized RN ratios are checked in[M^-2,M^2] on positive support, and two-copy ratios in[M^-4,M^4]. Zero nu and excluded Z slots are skipped for division and remain zero under both measures.

The cases include M1, a sharp M2 single-row distance1/3, a nonuniform three-slot row, common weights2^-100, fixed exclusions with a zero-nu slot, common source mass scaled by2^60, and eight slots with M4. No denominator is approximated or omitted. All eligible total masses are strictly positive. Support deletion is outside this statement and is not treated as free. These finite TV checks do not certify the physical log C bound18, score changes, kernel/history eligibility or the full receiver-error payment.

## Isolated reproduction

Copied only the checker and task contract to `/tmp/r181_reserve_review/` and ran once. The complete JSON matches exactly, including all Fraction values, zero branches, source moments and TV tests. No external historical files or numerical library were loaded. Both the original and migrated runs report no unexpected failures.
