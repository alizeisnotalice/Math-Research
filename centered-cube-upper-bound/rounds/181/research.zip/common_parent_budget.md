# R181：共同父来源、正部储备修复与正确的全局来源预算

本稿修复 R175 中未经继承的 ν≤β 条件。它不把实际 β 改成硬尾、不重新计算历史或 RC alpha；证明的是同一个正 companion 的精确分拆及一个共同父支配的正上界。已读 R181 合同、R175 CJ1–11、R173 mass_energy_audit §§2–3；亲读 R113 proof B2 27–34、R117 JG1 29–43、R128 RT4–6 637–667 的窄段，并与本轮 common_parent_source_index.md 的来源/窗口核验对齐。准确命题已先送独审。

仅写本文件，不 Git/spawn/PDF，不改他人文件。一般 middle companion 的 weighted 列预算仍未证明。

## CP1. 原共同父与求和资格

为免与接收重构系数混淆，记原软父测度为 A_V=alpha_V，RC系数写 alpha_rec,y。R113 B2 明示 A_V=mu_hi,omega|V、ν_V≤sigma_V≤A_V、β_V≤A_V，且没有假定 ν≤β。R112 J1–J3（proof.md 401–423）给同一omega的原终端叶两两不交，R107 D2（41–50）给原来源受 f dz 支配。上述额外窄定位由本轮 common_parent_source_index.md 核验；本稿不重读整部历史。

因此对**同一个原种子/共同窗口的来源构造**，

\[
\sum_V A_V\le\mu_{hi,\omega}\le f\,dz,\qquad
\sum_V\|\nu_V\|,\ \sum_V\|\beta_V\|
\le\sum_V\|A_V\|.
\tag{CP1}
\]

取同一个omega的期望，定义 W_sigma=E∑V∥sigma_V∥，得到

\[
\boxed{W_\nu,W_\beta\le W_A\le W_{hi}\le\|f\|_1.}
\tag{CP2}
\]

这是 aggregate 来源预算，不是每个V的 λb^n 帽，更不推出Wν≤Wβ。叶不交只属于该共同来源实现；不同独立窗口/菜单重跑不得免费并成同一不交族。CP10详列索引费用。

## CP2. 正部修复：精确关系与辅助上包络

固定V、omega，对共同父A取密度 b=dβ/dA、n=dν/dA，均在[0,1]。定义

\[
\eta=(\min(b,n))A=\beta\wedge\nu,\qquad
\zeta_+=(b-n)_+A=(\beta-\nu)_+,\qquad
\widetilde\beta=(\max(b,n))A=\beta\vee\nu.
\tag{CP3}
\]

逐点密度给准确测度关系

\[
\begin{gathered}
\beta=\eta+\zeta_+,\quad \eta\le\beta,\nu,\quad
\zeta_+\le\beta,\quad
\zeta_+\le A-\nu\le f\,dz-\nu,\\
\widetilde\beta=\nu+\zeta_+\le A,\qquad\beta\le\widetilde\beta.
\end{gathered}
\tag{CP4}
\]

例如(b−n)_+≤1−n，正是恢复外储备所需的点态事实。ζ+不是把signed β−ν当成正测度，而是其真正Hahn正部。全局还准确有

\[
W_\nu+W_{\zeta_+}=W_{\widetilde\beta}\le W_A,
\quad W_\eta+W_{\zeta_+}=W_\beta.
\tag{CP5}
\]

因此正放大无需2倍总来源预算。βtilde仅是辅助正包络，不是原软网络残余，不能据此继承所有关于原β的提取/history定理。

## CP3. 原 companion：一个等式、一个正放大

固定原全部来源、inner ν、e_t、Pi_t、RC alpha_rec,y、good/bad、rho和原门；令G(x,y,t,v,u)为该固定非负被积函数，包含原 outer carrier，且在未定义/不合格的外来源点取0。原 carrier不因改变outer积分测度而重构。

对任意外正测度sigma，记C_sigma=∫sigma(dy)ν(dv)ν(du)dt/t dx G，包含原E∑V,j、唯一j和各项[0,1]门。则

\[
\boxed{C_\beta=C_\eta+C_{\zeta_+}
\le C_\nu+C_{\zeta_+}=C_{\widetilde\beta}.}
\tag{CP6}
\]

首个分拆是测度线性的**等式**；中间仅是η≤ν导致的**正放大**，不是原交通身份。精确η版本可保留密度 r_eta=dη/dν=min(b,n)/n∈[0,1]（n=0取0），即Cη=∫ν(dy)r_eta(y)G。外ζ+和η均≤β，保留原软外来源资格；辅助ν部分只是带同一carrier的正上界，不宣称其每一点自动具备原软网络资格。

以下修复仅恢复那些只使用测度序、同一q/FIRST与same-alpha储备的R175代数。不能重构Pi、删除、history、同alpha或e_t，也不能把辅助βtilde看作一次新原来源构造。所有比较在原有限正截断先成立，非负极限后可扩到一般积分。

## CP4. 合法K0与同一same-alpha双储备

固定原x,V,j。原K0=P_{s,Hhat}(x−·)共同于整个外y积分；R128 RT6明定 Hhat=max(a,min(b,H0))，故Hhat∈[a,b]。因此完整输入的同一合法future测试给K0 f≤q；仅知K0ν≤q不足以推出下面外储备。

记

\[
Q_J=\int J\,d\nu,\quad
G_0=q-\int K0\,d\nu,\quad
Z=\int K0\,d\zeta_+.
\]

CP4和共同future给

\[
\boxed{0\le Z\le G_0.}
\tag{CP7}
\]

保持原D_y>0、原U_y=1_E min(TDelta,D_yK0)、原重构
alpha_rec,y Q_J=D_yq−∫U_y dν。实际bad集合 B_y满足U_y=0；不是随意取全部低score来源。定义

\[
B_y^0=\int_{\mathsf B_y}K0\,d\nu,\qquad
\gamma_y={\alpha_{rec,y}Q_J\over D_y}
=q-\int U_y/D_y\,d\nu.
\]

因为0≤U_y≤D_yK0，并在实际bad上为0，准确地

\[
\boxed{\gamma_y=G_0+\int(K0-U_y/D_y)d\nu
\ge G_0+B_y^0\ge0.}
\tag{CP8}
\]

这两个储备是同一实际gamma，不是可分两次独立领取的容量；QJ、alpha_rec均未重选。

## CP5. tau/mu及一般r幂容量

在gamma_y>0处，定义实际密度

\[
\tau(dy)={K0(x-y)\over\gamma_y}\zeta_+(dy),\qquad
\mu_y(du)={K0(x-u)1_{\mathsf B_y}(u)\over\gamma_y}\nu(du).
\tag{CP9}
\]

只在分母为正且K0为正处反向换密度。若G0>0，CP7–8给∥tau∥≤Z/G0≤1，∥mu_y∥=B_y^0/gamma_y≤1。更强地，对每个实r>0，

\[
\boxed{\int\tau(dy)\|\mu_y\|^r
\le{Z\over G_0}{r^r\over(r+1)^{r+1}}
\le{r^r\over(r+1)^{r+1}}.}
\tag{CP10}
\]

证明：被积密度为K0ζ+·(B_y^0)^r/gamma_y^(r+1)，而sup_{B≥0} B^r/(G0+B)^(r+1)=r^r/[(r+1)^(r+1)G0]，最大在B=rG0。对整数r，这也就是τ(dy)mu_y^⊗r的真实联合总质量。r=1给joint容量≤1/4；r=2给≤4/27。mu依y，不是另一份独立概率来源；非整数r只解释为写明的质量幂积分。

边界分开：实际strict s>0使K0,J在有限点严格正。QJ=0则ν=0，内来源槽为0，跳过alpha/Pi比值。G0=0时CP7给ζ+=0，可取tau=0，不能推所有η/ν交通为0，也不能推出alpha_rec=0。gamma_y=0时CP8强制B_y^0=0，strictK0给该bad槽ν质量0，可令mu_y=0；相应bad-pair直接为0。alpha_rec=0同理从gamma0处理，不除以alpha。若扩展到允许K0零的端点，只能重构正K0部分，零核来源必须另留；本稿不使用该扩展。

## CP6. rho实际式与一般幂的同alpha包络

在原正target E内，S_v=TDelta_v>0，原recapture为min(1,(U_y(v)+alpha_rec,y J_v)/S_v)，rho=1−recapture。令

d_v=[1−D_yK0_v/S_v]_+，z_v=alpha_rec,y J_v/S_v。

若D K0≥S，U=S且rho0；否则U=DK0。因此在同一个原target上准确有rho=(d_v−z_v)_+。它不是用一个自由alpha最优化后的重构。

对a>0、p>0，直接微分z^a(d−z)^p在[0,d]的最大点z=ad/(a+p)，给

\[
\alpha_{rec,y}^{a}J_v\rho_v^p
\le {a^ap^p\over(a+p)^{a+p}}
S_v^aJ_v^{1-a}d_v^{a+p}.
\tag{CP11}
\]

也可与实际点态alpha^a J d^p取小。特别对p=2定义

F1=min(alpha_rec J_v d_v²,4S_v d_v³/27)，
F2=min(alpha_rec² J_v d_v²,S_v²d_v⁴/(16J_v))。

得到alpha_rec Jρ²≤F1、alpha_rec²Jρ²≤F2，恢复cubic/quartic。alpha0时左端0；J严格正，d0或rho0槽直接0，不出现0/0。

## CP7. 纠正后的R175换密度与所有原槽

用原H保留1_Zt(v)、1_Zt(u)、实际bad/低score、R_eta/middle、eligible/high/唯一j/history，且不把密度吸入H。原companion正被积式仍是

p_y²rho_v²J_v/(9Q_v²)·w_t(y,v)w_t(y,u)/e_t(y)²。

CP6的Cν（原carrier仍保留）只换内bad密度，Cζ+同时换外正部及内bad密度；在正分母区域精确换密度后再用CP11得

\[
C_\nu\le E\sum_{V,j}\int dx\,\nu(dy){dt\over t}\nu(dv)\mu_y(du)\ H
{p_y^2Q_JF1\,w_vw_u\over9D_yQ_v^2e_t^2K0_u},
\tag{CP12}
\]
\[
C_{\zeta_+}\le E\sum_{V,j}\int dx\,\tau(dy){dt\over t}\nu(dv)\mu_y(du)\ H
{p_y^2Q_J^2F2\,w_vw_u\over9D_y^2Q_v^2e_t^2K0_yK0_u}.
\tag{CP13}
\]

若需精确Cη，CP12保留r_eta(y)。CP13使用quartic项时完整核为

\[
{p_y^2Q_J^2S_v^2d_v^4 w_vw_u
\over144D_y^2Q_v^2J_ve_t(y)^2K0_yK0_u}.
\tag{CP14}
\]

144=9·16，两个K0分母、J_v分母、e_t²和d_v⁴均保留。H含u依赖，不能先积分u后丢掉它；两槽原Pi和其支持始终未换，tau/mu仅是写明的密度变换。固定(omega,V,j,y,t)的nu/Zt/wt/et/Pi_t独立x，不表示terminalPi_g、rho/alpha、K0或H独立x。

## CP8. 正确的R173平方能量来源价

原未归一clock给∫k_t(v)²wt(y,v)dt/t≤n，在去除分母前仅用原eligible的e_t≥e_g，再把未归一时间正上放到共同xi∈[1/2,1]。high和共同FIRST只需outer正来源≤f：

∫high β(dy)/e_g(y)≤(2Kq)^(−1)∫p_yβ(dy)≤1/(2K)。

辅助βtilde≤A≤f也满足这一步。仍保持同一个innerν，固定J_b及实际uniquej给

\[
\boxed{E_{pair,J}\le E_J\le{n\over2K}W_\nu
\le{n\over2K}W_A.}
\tag{CP15}
\]

这里不再把Wν错误地换成原Wβ。具体：先得到每V的J_b*ν_V(x)，时间帽和high列价一致后才合并∑j1_{j(x)=j}≤1，再以固定J_b的真实dx积分归一；最后求叶子/omega来源质量。若不同列的b或核不共同，就不能执行这一步的免j合并。删除和[0,1]门只减小未归一积分；不得把归一Pi扩大到e_t≥e_g资格之外。

在同一个原正测度上作Cauchy，hard16/3与outer2Lambda各一次，得到纠正后的

\[
\boxed{Raw^{J,+}_{rem}\le{32\Lambda\over3}
\sqrt{\,{nW_\nu\over2K}\,C_\beta\,}
\le{32\Lambda\over3}
\sqrt{\,{nW_\nu\over2K}(C_\nu+C_{\zeta_+})\,}.}
\tag{CP16}
\]

这仍是精确未付companion接口，不因EJ已付就宣称raw完成；hard帽不能给两个CS因子各领一次。

## CP9. 全目标只需共同父质量，无需原Wbeta自支配

若下一步在真实同源、参数、H和dx下分别证明

Cν≤Bν Wν，Cζ+≤Bζ Wζ+，

则CP5给Cβ≤max(Bν,Bζ)W_A，完全没有2倍。令B=max(Bν,Bζ)，CP16即给

\[
Raw^{J,+}_{rem}\le{32\Lambda\over3}\sqrt{nB/(2K)}\,W_A
\le{32\Lambda\over3}\sqrt{nB/(2K)}\,\|f\|_1.
\tag{CP17 conditional interface}
\]

这是说明应当证明哪份真实预算的接口，Bν/Bζ的weighted列估计尚未得到。若只证明Cβ≤B Wβ，亦已有

Raw≤(32Lambda/3)sqrt(nB/(2K))sqrt(WνWβ)≤同常数W_A。

因此Wν≤Wβ从来不是一般f目标的必要条件。若先前已付分支用Wβ、Wν或Wζ+分别计费，可以统一上放到共同W_A，但必须把它们的真实常数/份额相加；不能以每项≤W_A为由重复领取同一全额预算。对η/ζ+的CP6只处理正剩余，所有原negative信用仍原位一次。

## CP10. 全部原window、menu和j费用

来源定位的准确范围为：同一omega的原不交终端叶给CP1；固定原a,b窗口是共同输入，不为每个receiver复制来源。R112 J18（604–615）对其已证明的有限scale网络用累计来源增量Σ_jη^(j)≤β，I2（805–815）只收一次K_alpha W_eta；这仅适用于那份累计构造，不使所有后续j交通免费。

R117 JG20（211–221）明确β和dominating M可跨j复用，故按j逐项得到的价格必须真正求和。CP9–14的tau_j、mu_j随x,V,j及y变，∥tau_j∥≤1或joint≤1/4不推出∑j∥tau_j∥≤1，更不给actual dx列价。CP15的uniquej消除费只在先取得共同J_b及统一时间/high帽之后成立；不能套给任意含j依赖反核归一的companion。

若有独立窗口/种子菜单m，必须保留W_{A,m}及其真实系数总和；仅逐m知道W_{A,m}≤∥f∥₁则朴素费用含菜单数。只有另证同一共同父及累计不重领的来源构造，才可再合为一个W_A。当前稿不免费完成该跨窗口步骤。CP2不包含任何每叶λb^n帽，也不提供高维低核来源反向质量控制。

## CP11. 本次实际修复与剩余weighted几何

已恢复原范围的代数工具是：CP3–5的正部与无2倍包络；CP7–10的共同K0双储备、tau/mu及r幂联合容量；CP11–14保持同alpha和全部原normalizers的cubic/quartic companion正上界；CP15–17以正确Wν和共同W_A结算的CS来源账。它们不依赖原ν≤β，辅助βtilde仅用于固定非负被积核的序比较。

另须隔离signed能量差：本稿的βtilde修复只针对写明的正companion及已核序/容量代数，不能直接把R179的E_W(β,ν)−E₀(β,ν)上放成βtilde版本。记δ_out=βtilde−β=(ν−β)_+≥0，对任一固定正能量核准确有

E_W(β,ν)−E₀(β,ν)=[E_W(βtilde,ν)−E₀(βtilde,ν)]−E_W(δ_out,ν)+E₀(δ_out,ν)。

即使丢掉非正的−E_W项，也须另付E₀(δ_out,ν)，因为负基准随outer来源改变。未修改的实际β仍只能在R179/180写明范围使用signed β−ν及TV费用，不能凭CP6把signed差额当正泛函。

尚缺的是CP12/13的实际weighted列积分：tau依x,V,j，mu还依y；K0反核、Q、J、Delta/d、e_t、samealpha、完整H和middle门均在原位。单独subprobability/joint1/4并不支付它们，既有hard/mixed overlap也不能删除这些密度。CP17的Bν/Bζ还不是已证常数；原一般根阶目标保持未闭合。

这次修复改变的是实际可用工具的来源资格和最终目标应付的质量账，不是一般Hahn分解后直接宣布有预算。未扩大旧分支，不重算历史/选择器，未消费原negative两次。交独审后停止本有界任务。
