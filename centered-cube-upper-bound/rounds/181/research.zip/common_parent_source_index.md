# R181 common-parent source budget: narrow source index

Scope: source mass and summation only, from the cited R107/R112/R113/R117 clauses and R181 contract. This does not certify a new estimate or add a per-window cap.

## Common parent and global mass

For a fixed seed `ω`, R112 `rounds/112/research.zip::proof.md`, J1–J3 (lines 401–423) says the terminal leaves `V` are pairwise disjoint, sets `α_V=μ_{hi,ω}|_V`, and has `ν_V≤σ_V≤α_V`. The same fixed `ω` is used throughout the traffic integral and the expectation `E∫_E r(x,ω)dx` (J2, lines 411–415). Thus the direct common-parent identity/inequality is

`Σ_V ||α_V|| = μ_{hi,ω}(∪V) ≤ μ_{hi,ω}(R^n)`.

R107 `rounds/107/research.zip::proof.md`, D2 (lines 41–50), records the inherited source domination `0≤μ_{V,ω}≤1_V μ_hi≤1_V f dz`; summing the disjoint leaf restrictions gives total source mass at most the original `μ_hi` mass, itself at most `||f||_1`. In the R112/R113 notation the corresponding global budget is `W_hi=E_ω μ_{hi,ω}(R^n)≤||f||_1` (or equality if the full source is retained). There is no factor depending on `n` or on a ratio-band index in this *single common-source* mass identity.

R113 B2, `rounds/113/research.zip::proof.md`, lines 27–34, freezes the positive split

`α_V=η_{α,V}+ζ_{α,V}`, `β_V:=ζ_{α,V}`, `W_α=W_{η_α}+W_β≤W_hi`.

It explicitly says the two pieces may overlap spatially and does not assume `ν≤β`. Combined with the disjoint-leaf common parent, this supplies `W_β≤W_α≤W_hi≤||f||_1` and `W_ν≤W_α≤W_hi≤||f||_1`, with the same expectation over `ω`. These are aggregate mass bounds across leaves for one source realization, not bounds `||α_V||,||β_V||≤C λ b^n` for each leaf/window.

## Which indices share that budget

The original fixed receiver window is a common input parameter, `a≤L_s(x),R(x)≤b≤2a`, not a new source copy for each receiver. R112 J1 (lines 401–409) fixes this window and common `q`; R112's multi-scale network operates on the same original `α_V`, while its cumulative source increments obey `η_β=Σ_j η^(j)≤β` and `Σ_j||η^(j)||=||η_β||` (J18, lines 604–615). Its final I2 charge is one `K_α W_{η_α}` (lines 805–815). Therefore the *finite scale/menu extraction already proved there* does not charge the same α mass once per menu entry; the maximum extraction fraction is accumulated by increments.

That statement does not make independent source constructions or independent original windows free. R117 JG1, `rounds/117/research.zip::proof.md`, lines 29–43, fixes a seed and an original disjoint leaf `V` but then carries the ratio-band index `j` in `Z_t`, `e_t`, and `Π_t`. R117 JG20 (lines 211–221) explicitly sums over `V,j` and warns that “β and the dominating M can be reused” across `j`, so the actual right side must be genuinely summed over those bands; a separate bound for each `j` cannot each spend the full `W_β` without paying its coefficient sum. Likewise, the disjointness cited in R112 is for terminal leaves at a fixed `ω`; the cited clauses do not state that leaves from independently rerun seed/window menus are mutually disjoint or that their source splits are one common split. Such menus need one common-parent construction or an explicit multiplicity/price.

## Limits of this locator

R113 B2 and R112's inherited source definition support the common-parent *global* mass budget, not a local volume-density estimate. The R107 D2 per-leaf estimate is for its designated pre-frozen current source `μ_{V,ω}`; it is not automatically a cap for the full `α_V=μ_{hi,ω}|_V` used in R112/R113. No `C λ b^n` per-leaf cap is claimed here. The earlier R180 source index's correction remains in force: β need not dominate ν, so `β−ν` can be signed; the common parent works with `α` and does not need that ordering.
