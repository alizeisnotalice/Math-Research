#!/usr/bin/env python3
"""Verify frozen inputs, optionally replay in a fresh output directory."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir');args=ap.parse_args()
inv=json.loads((root/'inventory.json').read_text())
for name,item in inv.items():
 p=root/name
 assert p.is_file() and p.stat().st_size==item['bytes'],name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
print('inventory verified',len(inv))
if args.verify_only:raise SystemExit(0)
if not args.output_dir:ap.error('--output-dir required unless --verify-only')
out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=False)
for name in ('reserve_weighted_checks.py','task_contract.md'):shutil.copy2(root/name,out/name)
subprocess.run([sys.executable,str(out/'reserve_weighted_checks.py')],check=True)
a=json.loads((root/'reserve_weighted_checks.json').read_text());b=json.loads((out/'reserve_weighted_checks.json').read_text())
a.pop('runtime',None);b.pop('runtime',None)
assert a==b,'non-runtime replay mismatch'
print('all non-runtime results match')
