# R181：原两槽后验的受控中心冻结

状态：本稿证明一个针对原正 J-share traffic 的真实接收误差预算。保持原 ν、完整原 Z_t、score、good/high、同 α 的 ρ、history 和全部资格门，仅将归一化时间权重的中心 y 替换为预先固定的近邻网格点。该替换的误差不含 ∥ν∥/e_t 放大，可按预先指定的 ε 支付到原接收量。冻结后的主项仍未获得一般根阶来源预算；本稿不称 middle 已解决。

该结果不假定 ν≤β，不使用来源体积质量帽，不重选或条件化原后验。辅助后验只是比较右端的新正对象，原 Π 及其负信用完全保留。外来源求和仅使用同一原窗口中已核的 β_V≤共同父来源、原叶不交，从而 Σ_Vβ_V≤f；跨独立窗口的费用不由本稿免除。

## 1. 保持不动的原对象与冻结对象

固定一个原 seed/window 块、固定 b。全文所有 dx 与 ∫q 都限制于原接收域 \(\mathcal E_{rec}\)（证明时可先取其原有限截断），不是先在全 Rⁿ 积分后使用 q≤λ。对每个原 (ω,V,j,y,t)，令
\[
\mu_{y,t}(dv)=1_{Z_{y,t}}(v)w_t(y,v)\nu(dv),\quad
e_{y,t}=\mu_{y,t}(\mathbb R^n),\quad
\Pi_{y,t}=\mu_{y,t}/e_{y,t}.
\tag{NB1}
\]
仅在 e_{y,t}>0 的原可定义行上使用概率；零行在原正目标中为零。原 ν、Z_t、w_t、e_t、Π_t 在固定 (ω,V,j,y,t) 后独立于 x，终端 Π_g 及接收参数并非如此。

给定可测中心映射 r(y)，它须在接收点 x 之前固定，满足
\[
18\|r(y)-y\|_1/b\le\eta.
\tag{NB2}
\]
定义辅助测度
\[
\widehat\mu_{y,t}(dv)
=1_{Z_{y,t}}(v)w_t(r(y),v)\nu(dv),\quad
\widehat e_{y,t}=\int1_{Z_{y,t}}w_t(r(y),v)\nu(dv),\quad
\widehat\Pi_{y,t}=\widehat\mu_{y,t}/\widehat e_{y,t}.
\tag{NB3}
\]
NB3 保留**实际 y 行的同一个完整 Z_{y,t}**，没有替换为 Z_{r(y),t}，没有删除来源，也没有只在某个子事件上条件化。归一积分使用全部原 Z_{y,t}。因此它不自动成为以 r(y) 为外来源的某条原行，也不继承那条行的 high、终端或删除身份。

原 p_y、Q_v、J_v、同 α 的 ρ_y(v)、good/high、bad、score k_t(y,v)、δ_t(y,v,u)、唯一 j、原时间窗及 history 在替换中全部不动。特别不把原 δ 改为由新中心 r(y) 导出的 score 差。

## 2. 物理 C 的全局对数控制

原 F=max(h,φ) 径向非增，0≤F≤1，C=h*F 正且偶。C 绝对连续且
\(C'(d)=F(d+1/2)-F(d-1/2)\) 几乎处处，故 |C′|≤1，且 C 在 d≥0 上非增。

先给一个完全显式的安全常数：
\[
\boxed{|\log C(d)-\log C(d')|\le18|d-d'|\quad(d,d'\in\mathbb R).}
\tag{NB4}
\]
证明如下。w(r)≥(1/2)e^{-2|r|}，因为定义积分可限制到 a∈[1/2,1]。在 d=1 处 C(1)=(h*φ)(1)，从而
\[
C(1)\ge\tfrac12e^{-2}(\sinh1)^2>1/18.
\tag{NB5}
\]
最后一步只用 e<3、sinh1>1。在 |d|≤1，C(d)≥C(1)，因此 |(log C)′|≤18。

对 x≥1/2，有准确表达
\[
\varphi(x)=\int_0^1 a e^{-(x-1/2)/a}(1-e^{-1/a})\,da.
\]
其负对数斜率为 1/a 在上述正权下的平均。相对于 x=1/2 的权，增加 x 乘以关于 1/a 递减的指数；两份积分相乘展开，得到该平均不增。在 x=1/2，分子≤1，分母
\(\int_0^1a(1-e^{-1/a})da\ge\int_{1/2}^1a(1-e^{-1})da>3/16\)，故尾部对数斜率≤16/3<6。内部 φ(x)≥φ(1/2)>3/16 且 |φ′|≤1，也有相同安全常数。这个论证只使用一阶可积量，无须宣称端点二阶矩有限。

当 d≥1，C(d) 是 φ 在 [d−1/2,d+1/2] 上的积分，因此继承 φ 的 6-log-Lipschitz 界。结合内部与偶性得到 NB4。

对任意 ξ>0，\(\log\min(1,C/\xi)=\min(0,\log C-\log\xi)\)。故无需冻结 ξ，也无需将 C 看成概率核，NB4 给
\[
e^{-\eta}\le{w_t(r(y),v)\over w_t(y,v)}\le e^{\eta}
\quad\text{于每个原来源点 }v.
\tag{NB6}
\]
于是
\[
e^{-\eta}e_{y,t}\le\widehat e_{y,t}\le e^\eta e_{y,t},
\quad
e^{-2\eta}\le{d\widehat\Pi_{y,t}\over d\Pi_{y,t}}\le e^{2\eta}.
\tag{NB7}
\]
这里后验的连续中心稳定不再包含 ∥ν∥/e_t；原支持无论有多少删除，NB6–7 都在同一个 Z 上成立。

## 3. 完整归一后的尖锐概率距离

约定 d_TV(P,Q)=sup_B|P(B)−Q(B)|，即总变差范数的一半。若 P 为概率，m≤f≤M 且 Q=fP/Pf，则
\[
d_{TV}(P,Q)\le{\sqrt M-\sqrt m\over\sqrt M+\sqrt m}.
\tag{NB8}
\]
初等证明：对任意事件 B，令 p=P(B)，f 在 B 及 Bᶜ 上的条件平均为 a,b。正差为 p(1−p)(a−b)/(pa+(1−p)b)，它随 a 增、随 b 减；以 a=M、b=m 上界，再对 p∈[0,1] 最大化即可。零质量事件直接为零。对所有 B 取上确界得 NB8。

将 NB8 用于 NB6，以及两个独立槽的未归一乘积比，得到
\[
d_{TV}(\Pi_{y,t},\widehat\Pi_{y,t})\le\tanh(\eta/2),
\quad
\boxed{d_{TV}(\Pi_{y,t}^{\otimes2},\widehat\Pi_{y,t}^{\otimes2})\le\tanh\eta.}
\tag{NB9}
\]
因此任何**同一个**原可测函数 0≤F≤1 均满足
\[
\left|\int F\,d\Pi^{\otimes2}-\int F\,d\widehat\Pi^{\otimes2}\right|
\le\tanh\eta.
\tag{NB10}
\]
这是完整归一之后的比较，不是将两个分母分别丢掉后估计未归一核差。

## 4. 原正 J-share 的 ε 接收误差

对实际 middle 正子集，令 H 保留原全部正门、两槽支持、bad、时间资格、history 等，并令
\[
A_y(v)=1_{good}\rho_y(v){J_v\over3Q_v},\qquad
F_{x,y,t}(v,u)=H\,A_y(v)\,{[k_t(y,v)-k_t(y,u)]_+\over n}.
\tag{NB11}
\]
因为 J/(3Q)≤1、ρ≤1、score 差≤n，准确有 0≤F≤1。即使 H 含 u 相关门也仍可直接使用 NB10，不将该门提到积分外。

令 R 为原 hard 上界使用一次之后的正 J-share 功能量：
\[
R={32\Lambda\over3}\mathbb E\sum_{V,j}
\int1_j(x)dx\,\beta_V(dy)\int_{\mathrm{far}}{dt\over t}
\,n p_y\int F_{x,y,t}\,d\Pi_{y,t}^{\otimes2}.
\tag{NB12}
\]
这仍保留原 middle 和其他门；原待付正项≤R。定义 \(\widehat R\) 为 NB12 中只把 Π² 换成 NB3 的 \(\widehat\Pi^2\)，F、p 及全部外积分不动。由 NB10，
\[
|R-\widehat R|
\le {32\Lambda\over3}n\tanh\eta\,
\mathbb E\sum_{V,j}\int1_j(x)dx\,\beta_V(dy)p_y
\int_{\mathrm{far}}{dt\over t}.
\tag{NB13}
\]
原 far 位于 ξ=c_jt/b∈[1/2,1]，可正上放至固定 j 的 [b/(2c_j),b/c_j] 与原可定义域交集，长度≤log2。原唯一 j 指示保持至这个统一行界后才求和，不逐 j 重领费用。再用同一窗口的 Σ_Vβ_V≤f、共同当前核与 FIRST，得到
\[
\boxed{|R-\widehat R|\le
{32\Lambda\over3}n\log2\,\tanh\eta\;
\mathbb E\int q(x)\,dx.}
\tag{NB14}
\]
若此前未核某个块的共同来源求和，只能先使用 NB13，不能擅自把不同窗口的 Σβ 都压成一份 f。所有无限量可先在原有限非负截断上比较，再取单调极限；绝对差只在有限截断处使用。

给定预先选定的 ε>0，取
\[
\eta_\varepsilon=\min\{1,3\varepsilon/(32\Lambda n\log2)\}.
\tag{NB15}
\]
由 tanhη≤η，原正项有严格桥接预算
\[
\boxed{\operatorname{Raw}^{J,+}_{middle}
\le\widehat R+\varepsilon\,\mathbb E\int q(x)dx.}
\tag{NB16}
\]
在原接收域 q≤λ，故这里的接收误差进一步不超过 \(\varepsilon\lambda\,\mathbb E|\mathcal E_{rec}|\)。该 ε 是本次新占用的接收误差份额；不宣称原总账自动有未使用的吸收信用。hard16/3 与 outer2Λ 均只使用一次。原 signed 负项保持原位，未被 NB16 消费。

## 5. 可构造网格与保留原能量的乘法比较

取坐标网格步长
\[
\ell_\varepsilon={b\eta_\varepsilon\over9n},\qquad
r(y)=\text{逐坐标最近的 }\ell_\varepsilon\mathbb Z^n\text{ 点},
\tag{NB17}
\]
并固定可测的平局规则。则 ∥r(y)−y∥₁≤nℓ_ε/2=bη_ε/18，满足 NB2。此网格在 x、当前接收尺度和实际门之前固定；无限空间使用可数网格，无需给每个原子行独立重选中心。NB14 只对统一误差积分，因此没有网格数量因子。

对冻结主项，原外来源仍按 cell 不交分割，\(\sum_{cell}\beta_V|_{cell}=\beta_V\)。若后续能将每格列价统一付给该格原来源质量，求和便不产生基数损失；本稿未证明这样的统一逐格或耦合列预算，也不把网格基数自动记成指数费用。并且 \(\widehat e_{y,t}\) 和支持仍通过实际 Z_{y,t} 依赖 y，中心相同不意味着后验相同。

NB7 还给同支持上的双槽 Radon–Nikodym 比较
\[
e^{-4\eta}\le
{d\widehat\Pi^{\otimes2}\over d\Pi^{\otimes2}}
\le e^{4\eta}.
\tag{NB18}
\]
所以任何原非负两槽系数——包括未有界的 companion 系数——在两个测度下的积分都在 e^{±4η} 之间。特别，冻结后的 fixed-J 平方能量仍使用**原** score，可由已付原能量直接得到
\[
\widehat E_J\le e^{4\eta}E_J
\le e^{4\eta}{nW_\nu\over2K}.
\tag{NB19}
\]
这里使用修正后的 W_ν 来源价格；若原不交父来源合同给 W_ν≤W_parent，再按该合同换成父来源总价，不写成未证的 W_β。原 companion C 与冻结 companion Ĉ 同样有 C≤e^{4η}Ĉ 及反向界，但本稿未证明 Ĉ 的全球费用。

NB19 来自同一原系数下的正测度比较，并非给 \(\widehat\Pi\) 套原 FTC。新中心的权重导数 score 一般不同于 k_t(y,·)；若进一步改变 score，必须另付跨阈值面费用，本稿没有这一步。

## 6. 明确的剩余列对象

在每个网格 cell r(y)=r 内，冻结 companion 可把共同权重
\(w_t(r,v)w_t(r,u)\) 提到 y 积分外，但剩余准确系数仍是
\[
\int_{\{r(y)=r\}}\beta_V(dy)
{1_{Z_{y,t}}(v)1_{Z_{y,t}}(u)\over\widehat e_{y,t}^{\,2}}
H\,1_{\mathsf B_y}(u)
{p_y^2\rho_y(v)^2J_v\over9Q_v^2},
\tag{NB20}
\]
随后保留 ν(dv)ν(du)、真实 dx、dt/t、原 j 和全部外期望。H 中原 score 门也仍依赖 y。相同 cell 不删除这些依赖，原 same-α 定义保持不变，既未将 bad 槽换为独立概率，也未对倒 K0 或倒 Q 取上确界。

本轮消去的是“连续移动 wt 的中心必须付 ∥ν∥/e_t”的不必要放大；这个改进由 NB6–10 的完整归一直接证明，且 NB16 给了真实 ε 接收误差。剩余命名明确：NB20 中的实际删源归一、同 α 的 ρ/Q、原 score 门与网格列的联合接收积分。没有把它们归结为一个假定很小的新范数。

因此下一步可在已固定的时间核中心上研究共同来源补偿，并用父稿的直接 Jρ²/αρ² 机制处理残余权重；仍须支付 NB20，而不能只付一个无权 overlap。原 middle 一般根阶预算未完成。本轮在此停止，不扩大条件门或数值搜索。
