# Round72: geometry-aware packet gates and the high-entropy residual

2026-10-11. **The general sqrt(n)n^{o(1)} bound remains UNPROVED.**
The retained unconditional general benchmark remains O(n log n).

## Outcome and proof status

This round tests the actual high-entropy occupation left unpaid in Round71.
It proves that, for every fixed finite entropy cutoff, the supremum of
high-entropy nonmajority multi-site winner occupation equals the complete
band-occupation supremum. Three separated copies remove majority capture;
distinct nearby fine atoms raise entropy without changing the fixed-threshold
band integral in the limit. This is an exact all-input saturation theorem,
not a new claim that optimized weak constants ignore microscopic structure.
Round45's microscopic response and Round50's finite-split results are retained.

The positive repair uses one fixed nonduplicating packet partition. The
captured traffic of packets whose fixed representative lies in the original
winner has heavy-share, posterior-power and entropy budgets without a
diameter condition. Coordinatewise weighted medians make capture of more
than half a packet sufficient. The paid mass fraction S is retained in the
entropy estimate; converting it to total occupation needs actual coverage.

A second global packet lemma uses d_J<=rho_J/(8n),
rho_J=(w_J/(beta lambda))^(1/n). The ORIGINAL global cap implies a uniform
representative-volume inflation at most exp(1/2), without a lower physical
scale. A stopped single-linkage tree selects one nonduplicating frontier
and absorbs sufficiently narrow refinements without charging every level.
This condition alone cannot compress arbitrary inputs: uniform fine lattices
force singleton admissible packets on a positive band of actual full-capture
winners. The representative-contained gate repairs that example, but a
universal gate-coverage budget is still missing.

Common random-grid shifts give an exact same-cell collision kernel and an
exact annealed triangular reconstruction. Finite-window squared error splits
into squared bias and conditional variance without cross-block independence.
However, a single true atomic source already forces an Omega(n log n)W
all-time signed L1 reconstruction error at cell side a/sqrt(n), on its
ORIGINAL global cap. This does not refute cap square energy or actual
random-packet occupation. Taking an absolute time integral is too expensive.

## Actual numerical evidence and remaining interface

The experiment preserves true complete-batch winners and full-space receiver
density. A fixed macro-source proposal is used for paired refinements; the
positive score envelope explicitly accounts for displacement. The pilot,
independent heldout refinements, independent dimension/source-count matrix,
Boolean pressure and exact point audits are reported below. Neither noisy
means nor finite rational audits determine a general dimensional exponent.
The completed run has 96 rows, 34816 unique receivers and 153600 paired
receiver-refinement evaluations, with 1524 fixed-grid alternatives and
482 retained rational point audits. The parent independently replayed the
frozen final program in 76.68 seconds and reproduced its JSON byte for byte.
Three supplemental guards are also independently run.

What remains is a paid coverage statement for the actual winner: control
representative-outside or poorly compressed packet traffic, preserving one
common input and without separately charging all partitions/tree levels.
Alternatively the signed-cap-energy route still needs its unproved subpower
budget. No bound here closes either missing general interface.

## Reproduction

Extract the five-member archive to a temporary directory and preserve the
reference packet_results.json before running `python3 -B packet_probe.py`.
The final program uses Python 3.12.14 and NumPy 2.3.5 and writes adjacent
packet_results.json. Do not pass --pilot for the final run. All source
parameters, random seeds and proposal definitions are retained.
The three supplemental standard-library Python guards are embedded in this
report as separate blocks. Their outputs and main replay receipt are in
inventory.json. Decimal 80/140 agreement is not interval certification.
Detailed LaTeX source is provided as proof.tex.txt without compilation or PDF.
The 64 canonical skill entries and 437 direct references were rechecked with
no change against Round71. File availability does not certify a theorem.



---

# Round72: high captured entropy retains the entire extremal problem

Status: the saturation theorem below is proved for every fixed dimension and finite positive atomic input. It rules out treating large atomic posterior entropy as a uniformly negligible tail. It does not refute a sqrt(n) bound on the actual total occupation. The general desired upper bound remains unproved.

## 1. Quantities and source-preserving refinement

Fix n>=1 and beta>1. For a finite positive measure mu=sum_i p_i delta_yi with distinct sites and W=sum p_i, use the actual smallest-volume maximizing closed cube, including complete arrival ties. Write M, winning captured mass F, posterior pi_i, and H=-sum pi_i log pi_i. Receivers are measured by Lebesgue measure. Define

    B_n(beta)=sup_(mu,lambda) W^-1 integral_{lambda<M<=beta lambda} M dx.

For h>=0, let B_n^res(beta,h) be the same supremum with the additional actual-winner conditions: at least two captured sites, F<=W/2, and H>h.

For each K, replace each original site i by K distinct sites y_i+z_(i,k), each of mass p_i/K, where ||z_(i,k)||_infinity<=epsilon_K and epsilon_K decreases to zero. Choose epsilon_K smaller than one quarter of the minimum parent-site separation, so different parent packets remain distinct. Such a refinement exists in every dimension, using distinct offsets along the first coordinate. Total mass is unchanged. All labels refer to actual distinct sites, not a formal splitting of coincident atoms.

The old Round45 weak-constant refinement limit and Round50 finite-split geometric theorem are retained. We do not count them as new results. The new conclusion here is saturation of the HIGH-ENTROPY, NONMAJORITY actual-winner occupation supremum. The following short quantitative stability argument records the exact version needed for that conclusion; it does not claim a source-uniform perturbation radius.

## 2. Stability and entropy divergence with the correct receiver measure

For x outside the original finite support, let d=min_i ||x-y_i||_infinity>0. When epsilon<d,

    [d/(d+epsilon)]^n M_mu(x)
       <= M_muK(x) <= [d/(d-epsilon)]^n M_mu(x).                 (1)

Indeed a witnessing original radius r>=d captures its complete refined packets at radius r+epsilon. Conversely, every nonzero refined capture has r>=d-epsilon and its parent mass is captured at radius r+epsilon. The lower ratio r/(r+epsilon) is at least d/(d+epsilon); the upper ratio (r+epsilon)/r is at most d/(d-epsilon). Thus M_muK tends pointwise to M_mu off the original support, irrespective of K and the fine-site arrangement.

Every positive level set {M_mu=t} is Lebesgue null. The maximum is attained at one of finitely many source distances. Its captured mass is one of finitely many subset sums; equality to t therefore places x on a boundary of a source-centered cube with a fixed positive radius. A finite union of such boundaries is null. Consequently the actual band indicators converge almost everywhere. For fixed lambda, all refined weak halos lie in a single bounded union of source-centered cubes: a nonzero witnessing cube above lambda has side <(W/lambda)^(1/n), and contains some site within epsilon of a parent. The band integrands are bounded by beta lambda. Dominated convergence gives

    integral_{lambda<M_muK<=beta lambda} M_muK dx
       -> integral_{lambda<M_mu<=beta lambda} M_mu dx.           (2)

This is a fixed-threshold assertion. It does not say that the full optimized weak constant converges to the coarse-source weak constant: Round45 explicitly retains a microscopic common-threshold response in that optimized limit. Here lambda is fixed before K and epsilon vary; no microscopic supremum is discarded.

On a refined winning band at a receiver with d>=delta and epsilon<=delta/2, its actual side is at least delta and its captured mass satisfies F_K>lambda delta^n. Each fine atom has mass at most p_max/K, so every nonzero posterior share is at most p_max/(K F_K). Hence

    H_K >= log(K F_K/p_max)
        > log K + log(lambda delta^n/p_max).                    (3)

This is simply the lower bound of Shannon entropy by minus the logarithm of the largest probability; no independent-coordinate hypothesis is used. For each fixed receiver off the parent support that is eventually in the band, H_K tends to infinity. The number of distinct captured fine sites also tends to infinity. Dominated convergence therefore strengthens (2): for each fixed finite h,

    integral_{band_K intersect {H_K>h}} M_muK dx
       -> integral_{band_mu} M_mu dx.                           (4)

The exceptional shrinking neighborhoods of the original sites have vanishing Lebesgue measure; equivalently they are covered by the same dominated-convergence argument. They are not sampled from the source distribution.

## 3. Removing both already-paid winner branches

One must not conclude from (4) alone that the nonmajority residual is as hard as the full problem: a refined single parent can still capture most of the entire source. The following spatial construction removes that issue.

Translate the original finite source to lie in [-R,R]^n and choose all refinements with epsilon<=1. Put three identical copies at 0, D e_1, and 2D e_1, each of total mass W, choosing

    D > 2(R+1)+(3W/lambda)^(1/n).

A cube capturing sites from two different copies has side at least D-2(R+1), hence its average is strictly less than lambda even if it captures all 3W mass. Each individual-copy halo is contained in that copy's support box expanded by (W/lambda)^(1/n)/2. The three halo boxes are disjoint by the chosen D. On the full union's weak halo, the actual maximizing cube must therefore belong to the unique corresponding copy. Its maximal value equals that copy's actual maximal value, and its captured mass is at most W=(total mass)/3. This holds uniformly for every refinement K under the same separation choice.

The union's band integral is exactly three times the one-copy band integral. The normalized value is unchanged, since total mass also triples. On the band, sufficiently refined winners have at least two sites and entropy exceeding h almost everywhere, by (3). Combining this with (2)--(4) proves

    B_n^res(beta,h) = B_n(beta),     every n>=1, beta>1, h<infinity.   (5)

The <= direction is immediate from set inclusion. For >=, start with any original finite source and threshold, apply the three-copy construction and refine, then pass to the limit. Taking the supremum over original inputs gives the result, including an extended-real interpretation if necessary. No maximizer is assumed to exist. In particular h may be any prescribed finite function of n, including sqrt(n) times a subpower factor.

For comparison with the original weak objective, let C_n^atom be its supremum over finite positive atomic sources. The direct inequalities are

    B_n(beta)<=beta C_n^atom,
    C_n^atom<=beta/(beta-1) B_n(beta).                            (6)

The first uses M<=beta lambda on the band. For the second, partition a weak level set into bands (beta^j lambda,beta^(j+1)lambda] and sum their lambda-volume bounds with weights beta^-j. Source points are null and no weak-quasinorm triangle inequality is invoked. The retained positive atomic transfer identifies the weak endpoint problem for L1 inputs. Thus a sqrt(n) bound for the high-entropy residual would indeed finish the objective; (5) shows that calling it a residual has not itself reduced the extremal difficulty.

## 4. What compression must retain

For any one fixed nonduplicating parent partition, the actual posterior satisfies the exact finite chain rule

    H_fine = H_packet + sum_J pi_J H(fine label | captured packet J).

Zero captured packets contribute zero. All quantities come from the same captured source in the same actual winning cube, with weights pi_J=a_J/F. Under full equal-K packet capture, the within-packet entropy is log K and H_fine=H_packet+log K. Partial capture changes the conditional entropy and cannot be ignored. This uses the finite chain rule verified in current D04, not an assumption that source labels remain distributed by their original prior after receiver selection.

Consequently no estimate claiming uniform decay of high atomic entropy occupation as h grows can hold, even after deleting single-site and strict-majority winners. Nor can low atomic entropy be guaranteed to cover a fixed positive fraction of every input's occupation. A geometric compression may remain useful, but it must pay its spatial error and retain the common source. The companion mass-adaptive packet lemma addresses that issue; it does not follow merely from this entropy identity.

## 5. Exact finite calibration, not a new special-source upper bound

For n=1, lambda=1, replace a unit atom by K>=2 equal atoms on the uniform grid in [-epsilon,epsilon], with epsilon=1/(128 K^2). At |x|>=2K epsilon, the full packet wins: if m<K sites are captured on the nearer side, then

    m(x+epsilon) <= K(x-y_start)

follows from (K-m)|x|>=2K epsilon>=m epsilon+K|y_start|. Inside |x|<=2K epsilon the full-packet average already exceeds 2. Hence the true band 1<M<=2 consists of the two intervals with |x| between 1/4-epsilon and 1/2-epsilon. Throughout it,

    M=1/[2(|x|+epsilon)],  H=log K,  integral_band M dx=log 2.

The weak ratio is 1-2epsilon. Three translates at 0,16,32 retain these normalized quantities and have captured mass exactly one third of total, so they lie in the nonmajority residual. This explicit calibration falsifies uniform entropy-tail decay already in dimension one. It is used only to test the general interface, not as a replacement goal.

The standalone refinement_entropy_guard.py performs rational stability, actual complete-batch winner, source conservation, copy separation and finite entropy-chain checks in staged dimensions/refinement sizes. The analytic theorem above supplies the all-input and limiting claims. Numerical entropy evaluations, where present, are not interval certificates.


---

# Round 72: common packets, contained representatives, and a paid captured-mass branch

Status: the arbitrary-input bound C_n <= sqrt(n) n^{o(1)} remains unproved. The results below hold for every finite positive atomic source and use its actual all-scale maximizing cube. They pay a common-packet captured-mass branch, repair artificial entropy introduced by micro-refinement, and show that a conservative diameter-based partition cannot compress all relevant entropy. The missing estimate is an aggregate coverage statement, not an atom-count or tree-depth allowance.

## 1. Objects and source conservation

Let mu = sum_i p_i delta_{y_i}, p_i>0, W=sum_i p_i, with coincident sites merged. Q(x,L) is the closed centered cube of full side L. Write A_L=mu(Q(x,L))/L^n and M=sup_{L>0} A_L. Fix lambda>0 and beta>1, and let Omega={lambda<M<=beta lambda}.

Away from the finite source set, M is the maximum over the finitely many complete distance batches. Choose the smallest-volume maximizing cube Q*(x), and set L*=side(Q*), V*=(L*)^n, F*=mu(Q*), so M=F*/V*. This choice is Borel: distances are continuous and the finite comparisons determining the first maximizing batch are Borel. Tied arrivals are captured together. All assertions concerning receivers disregard the null source set.

A common packet partition is a finite family of fixed positive measures mu_J with sum_J mu_J=mu. Thus each source mass is allocated once. Whole-site partitions are a special case; fractional allocations are also allowed. Let w_J=mu_J(R^n)>0, choose a fixed representative c_J, and put

    a_J(x)=mu_J(Q*(x)), pi_J(x)=a_J(x)/F*(x),
    t_J(x)=2||x-c_J||_infinity, v_J(x)=t_J(x)^n.

The pi_J sum to one and are the packet posterior of the *actual original winner*. We do not optimize a separate winner for each packet. For any fixed c, the pushforward of Lebesgue measure under v=(2||x-c||_infinity)^n is dv: its sublevel cube has volume v. All radial envelope integrals below therefore have no dimension-dependent angular factor.

## 2. Representative-contained partial capture is paid without a diameter assumption

Define e_J(x)=1{c_J in Q*(x)}. If e_J=1 then v_J<=V*, even if only part of the packet is captured. Consequently, on Omega,

    M pi_J = a_J/V* <= min(beta lambda, w_J/v_J),
    pi_J <= min(1, w_J/(M v_J)).                         (2.1)

For 0<eta<=1, e_J=1 and pi_J>=eta imply F*<=w_J/eta and v_J<=w_J/(eta lambda). Integrating (2.1) on this radial range gives

    integral_Omega M sum_J e_J pi_J 1{pi_J>=eta} dx
       <= [1+log(beta/eta)] W.                         (2.2)

Indeed integral_0^{w/(eta lambda)} min(beta lambda,w/v)dv = w[1+log(beta/eta)]. No assumption that the representative is an actual source atom is used, so the inner radial contribution +1 must be retained.

For every t>0, maximize z min(1,w/(zv))^{1+t} over lambda<z<=beta lambda. The resulting radial envelope is

    beta lambda,             0<v<=w/(beta lambda);
    w/v,                     w/(beta lambda)<v<=w/lambda;
    lambda (w/(lambda v))^{1+t}, v>w/lambda.

Its integral is w[1+log beta+1/t]. Therefore

    integral_Omega M sum_J e_J pi_J^{1+t} dx
       <= [1+log beta+1/t] W.                          (2.3)

These are general source-conserving estimates. They do not bound an individual normalized column uniformly, and they do not charge source mass once per tree level.

### Coordinate medians supply a useful gate

Choose each coordinate c_{J,k} to be a weighted median of the kth marginal of mu_J; equivalently, both halfspaces {y_k<=c_{J,k}} and {y_k>=c_{J,k}} have mass at least w_J/2. If a closed cube excludes c_J, one coordinate interval excludes its median and its captured mass is at most w_J/2. Thus

    a_J>w_J/2  implies  c_J in Q*.                     (2.4)

The strict inequality is necessary. For (.5 delta_0+.5 delta_2), c=0 is a valid median, while a cube capturing only 2 has mass w/2 and excludes c. Full packet capture also implies containment of a bounding-box center, but (2.4) permits partial capture and requires no diameter bound. The geometric center and the weighted-median representative should not be conflated for nonuniform masses.

## 3. Entropy of paid captured mass and the exact remaining debt

Let S=sum_J e_J pi_J. When S>0 define r_J=e_J pi_J/S and H_paid=-sum_J r_J log r_J, omitting zero terms. Set H_paid=0 when S=0. By Jensen applied with weights r_J,

    sum_J e_J pi_J^{1+t}
       = S^{1+t} sum_J r_J^{1+t}
       >= S^{1+t} exp(-t H_paid).                      (3.1)

For 0<sigma<=1 and h>=0 let E_{sigma,h}={x in Omega:S>=sigma,H_paid<=h} and A_{sigma,h}=S 1_{E_{sigma,h}}. Combining (2.3) and (3.1) yields, for every t>0,

    integral_Omega M A_{sigma,h} dx
       <= exp[t(h+log(1/sigma))] [1+log beta+1/t] W.

Taking t=1/[1+h+log(1/sigma)] proves

    integral_Omega M A_{sigma,h} dx
       <= e[2+log beta+h+log(1/sigma)] W = C W.         (3.2)

The charged object is captured mass traffic. Paying the whole receiver event costs a factor 1/sigma:

    integral_{E_{sigma,h}} M dx <= (C/sigma) W.         (3.3)

More precisely there is the exact decomposition

    integral_Omega M dx
       = integral_Omega M A_{sigma,h} dx
         + integral_Omega M(1-A_{sigma,h}) dx.          (3.4)

The second term is unpaid. It includes representative-outside capture and entropy dispersed over too many contained representatives. A sufficient *aggregate*, rather than pointwise, interface is

    integral_Omega M A_{sigma,h} dx >= kappa integral_Omega M dx,

with kappa>0; then (3.2) gives integral_Omega M <= CW/kappa. No such source-uniform interface is established here. To reach sqrt(n)n^{o(1)}, one needs [2+log beta+h+log(1/sigma)]/kappa <= sqrt(n)n^{o(1)} (or a stronger direct payment of the remaining debt).

### Common randomized partitions do not multiply mass

Let q be a source-only probability distribution on finitely many common packet partitions, chosen independently of x. Each partition individually has total mass W. Apply (3.2) to each, and average by Tonelli:

    integral_Omega M E_q A_{sigma,h} dx <= C W.        (3.5)

Thus an occupation-weighted lower bound on E_q A is sufficient with the same fee. This does not permit choosing a private partition for each receiver at no cost. Charging the union of all source-tree levels instead pays its actual source-mass multiplicity. Root conservation is not a Carleson packing estimate.

## 4. A mass-adaptive geometric alternative with no minimum winner scale

Fix a representative c_J with support radius d_J=max_{y in supp mu_J}||y-c_J||_infinity, and define rho_J=(w_J/(beta lambda))^{1/n}. Suppose

    d_J <= rho_J/(8n).                                (4.1)

Original *global* cap M<=beta lambda implies

    w_J <= beta lambda (t_J+2d_J)^n,
    t_J >= rho_J-2d_J.                                (4.2)

If a_J>0, some packet site belongs to Q*, whence L*>=t_J-2d_J. It follows that

    v_J <= gamma_n V*,
    v_J >= chi_n w_J/(beta lambda),                   (4.3)
    gamma_n=[(1-1/(4n))/(1-1/(2n))]^n
            =[1+1/(4n-2)]^n <= exp(1/2),
    chi_n=(1-1/(4n))^n.

To see the first estimate, (t/(t-2d))^n decreases with t, so it is at most [(rho-2d)/(rho-4d)]^n. This is bounded by gamma_n under (4.1). The logarithmic bound on gamma uses n/(4n-2)<=1/2. The cap and partial-capture estimates are on the *same original source*, so no private subsource good set is introduced.

Here the radial envelope uses p=gamma_n w_J in place of w_J and starts at v0=chi_n w_J/(beta lambda). Its inner omitted integral is beta lambda v0=chi_n w_J. The argument of Section 2 therefore gives

    integral_Omega M sum_J pi_J 1{pi_J>=eta} dx
       <= [gamma_n(1+log(beta/eta))-chi_n] W,
    integral_Omega M sum_J pi_J^{1+t} dx
       <= [gamma_n(1+log beta+1/t)-chi_n] W.            (4.4)

For packet entropy H_packet=-sum_J pi_J log pi_J, Jensen and t=1/(1+h) give

    integral_{Omega intersect {H_packet<=h}} M dx
       <= exp(h/(1+h))
          [gamma_n(2+log beta+h)-chi_n] W.             (4.5)

There is no externally imposed physical-window lower side a. Partial capture is allowed. These improvements use global cap; they do not transfer unchanged to a restricted-window maximal operator. Condition (4.1) is sufficient and will be shown too restrictive to handle all relevant winners.

## 5. A source-only tree frontier repairs microscopic label entropy

Construct a deterministic single-linkage binary tree on the source sites. Sort all pairs by L-infinity distance and then lexicographic site indices. Merge two current components whenever a sorted pair joins distinct components; skip cycle edges. Each union is a binary parent. Give every node its exact mass, bounding-box center, and half maximum coordinate span d_J.

Starting at the root, stop at a node precisely when (4.1) holds; otherwise descend to its children. Leaves have radius zero, so this is a finite frontier. It is the coarsest admissible frontier *in this fixed tree*, not an optimization over all possible partitions. Selected nodes are disjoint source-label sets, cover all labels, and have sum w_J=W. The exact rational test is

    (8n d_J)^n beta lambda <= w_J.

All selected packets obey (4.4)-(4.5), independently of the number of nodes or depth. No mass of unselected tree levels is charged.

For a refinement of N parent sites y_i separated by Delta>0, distribute parent mass p_i over arbitrarily many positive micro-sites within radius epsilon of y_i. If

    Delta>4epsilon,
    epsilon<=min_i (p_i/(beta lambda))^{1/n}/(8n),     (5.1)

all within-parent pair distances are at most 2epsilon and all cross-parent distances exceed 2epsilon. Each complete parent cluster is therefore formed as a tree node before a cross-parent merge. Its radius is at most epsilon, so it is admissible. The stopped frontier never descends below these nodes and is a coarsening of the parent-label partition.

For the actual refined winner, write q_i for its captured mass from parent i divided by its captured total F*. The frontier shares are sums of these q_i. The finite Shannon chain rule gives

    H(q_i)=H(pi_J)+sum_J pi_J H(q_i/pi_J : i in J),

with zero terms omitted. In particular H(pi_J)<=H(q_i)<=log N, even if the atomic posterior has arbitrarily large entropy from fine splitting. No convergence of the maximizing cube to a macro winner is needed for this statement; captured mass may be partial in every parent cluster. Assumption (5.1) depends on parent masses, not the minimum micro-atom mass.

This is a repair of artificial refinement entropy. It is not a general N-independent compression theorem. Earlier Round45/Round50 already supply related microscopic weak-constant limits and fixed-threshold split-box comparisons; no new weak-convergence theorem is asserted here.

## 6. A fixed positive band bulk defeats all admissible diameter partitions

Let n=1, m>=3, h=1/(m-1), and

    mu_m=(1/m) sum_{j=0}^{m-1} delta_{jh},
    lambda=1/4, beta=2.

For a right receiver x>1+h, the arrival capturing its k rightmost sites has radius x-1+(k-1)h and average

    A_k=k/[2m(x-1+(k-1)h)].

This is strictly increasing in k because x-1>h. Thus on x in (1+h,2), the actual all-scale unique winner captures all m sites and M=1/(2x), lying in the required band. At x=1+h all averages tie; the smallest-volume convention chooses the singleton. This single endpoint is excluded. Reflection about 1/2 gives a matching left interval. The two intervals have total occupation

    integral_bulk M dx=log(2(m-1)/m) -> log 2.          (6.1)

Now consider any nonduplicating packet partition, including fractional allocations. A packet supported on k distinct sites has mass w<=k/m and radius d>=(k-1)/[2(m-1)] for every representative. Here (4.1) becomes d<=w/4. For k>=2 this would imply

    2m(k-1)<=k(m-1),  hence k<=2m/(m+1)<2,

a contradiction. Every admissible packet is therefore supported at one site. On a full-capture winner its posterior share is at most 1/m, and H_packet>=log m. The positive occupation in (6.1) remains while this entropy diverges. No admissible frontier, choice of source-only tree, or fractional splitting fixes this failure.

To place the same pressure in the genuinely residual branch, use three copies translated by 0,20,40, each with mass 1, so W=3. On each of the explicit local bulk intervals, distance to every site in another copy is at least 17. Any cross-copy capture cube has side at least 34 and average at most 3/34<lambda. The original local winner is consequently unchanged. It captures m>=3 sites and mass 1=W/3. The normalized residual bulk occupation is again (6.1).

A packet spanning two copies has support diameter at least 19, so d>=19/2, whereas d<=w/4<=3/4 is impossible. A packet within one copy is still forced to one site by the preceding argument. Thus this is a bulk obstruction even to admissible packet compression restricted to multisource, submajority winners. It refutes a uniform high-entropy tail decay for this conservative geometry class; it is not a counterexample to the desired weak bound.

### The usable repair is already stronger than admissibility

Instead use the three whole-copy packets. Their medians are at their copy midpoints and lie in every local full-capture winner. Hence S=1 and H_paid=0 on the same bulk. These packets need not obey (4.1), but (3.2) pays this branch. This demonstrates why representative-contained captured mass, rather than diameter admissibility alone, is the proper weaker interface. For arbitrary sources, choosing common packets that give enough such traffic with small entropy remains unresolved.

## 7. Scope, current skills, and numerical evidence boundary

This is a finite-atomic general-input argument; it does not assert an energy limit through approximation or a complete weak-type return. All inequalities above are elementary finite sums, radial integration, source conservation, and Shannon/Jensen calculations proved here. No external theorem is invoked merely by a skill's name.

The current canonical entrances and method/interface/provenance of D04 (entropy chain rule), E03 (tree cross-layer budget), G01 (Carleson box/tent testing), and L03 (rational/interval certificates) were read from the installed directories. D04 applies to the finite captured label distribution with its actual posterior weights; no difference of infinite entropies appears. E03 applies to the single finite source tree and its one stopped frontier, with exact child mass conservation. G01 warns that a root mass bound is not all-node Carleson packing; this draft makes no such inference. L03 permits exact rational finite checks and requires distinguishing arbitrary precision replay from outward-rounded interval certification. No unverified floating interval API is used. The scope restrictions do not change these elementary conclusions.

The current skill hashes are recorded below. The embedded guard checks exact geometry and tree conservation, actual complete-batch winners and median gates, the lattice endpoints and admissibility obstruction, and high-precision entropy/radial constants. Finite checks corroborate the proofs; they are not a source-uniform theorem. Decimal replay is labeled precision evidence, not interval arithmetic.

## 8. Reproducible staged guard

The guard below is self-contained and uses only Python standard-library exact fractions and Decimal arithmetic.

```python
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
import json

counts = dict(geometry=0, tree=0, refinement=0, median=0,
              winner_envelope=0, lattice=0, entropy=0)

def dist(x,y):
    return max(abs(a-b) for a,b in zip(x,y))

def winner(points,weights,x):
    batches={}
    for i,y in enumerate(points):
        r=dist(x,y)
        assert r>0, 'receiver at a source is excluded'
        batches.setdefault(r,[]).append(i)
    total=F(0); best=F(-1); chosen=None; captured=[]
    n=len(x)
    for r,indices in sorted(batches.items()):
        total+=sum((weights[i] for i in indices),F(0))
        captured+=indices
        value=total/(2*r)**n
        if value>best: # equal values keep the smaller complete batch
            best=value; chosen=(r,total,tuple(captured))
    return best,chosen

def node(points,weights,indices,children=()):
    n=len(points[0]); indices=tuple(sorted(indices))
    lo=tuple(min(points[i][k] for i in indices) for k in range(n))
    hi=tuple(max(points[i][k] for i in indices) for k in range(n))
    return dict(indices=indices,children=children,
                mass=sum((weights[i] for i in indices),F(0)),
                center=tuple((a+b)/2 for a,b in zip(lo,hi)),
                radius=max(b-a for a,b in zip(lo,hi))/2)

def frontier(points,weights,lam,beta=F(2)):
    # Complete finite graph; ties resolved by fixed site labels.
    N=len(points); n=len(points[0]); parent=list(range(N))
    nodes=[node(points,weights,[i]) for i in range(N)]
    active={i:nodes[i] for i in range(N)}
    def find(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]]; i=parent[i]
        return i
    edges=sorted((dist(points[i],points[j]),i,j)
                 for i in range(N) for j in range(i+1,N))
    for _,i,j in edges:
        a,b=find(i),find(j)
        if a==b: continue
        A,B=active.pop(a),active.pop(b)
        parent[b]=a
        C=node(points,weights,A['indices']+B['indices'],(A,B))
        active[a]=C; nodes.append(C)
    root=next(iter(active.values())); out=[]
    def visit(J):
        if (8*n*J['radius'])**n*beta*lam<=J['mass']:
            out.append(J)
        else:
            assert J['children']
            for child in J['children']: visit(child)
    visit(root)
    assert sorted(i for J in out for i in J['indices'])==list(range(N))
    assert sum((J['mass'] for J in out),F(0))==sum(weights,F(0))
    assert all((8*n*J['radius'])**n*beta*lam<=J['mass'] for J in out)
    return out,nodes

def median(points,weights):
    total=sum(weights,F(0)); result=[]
    for k in range(len(points[0])):
        mass=F(0)
        for coordinate,i in sorted((y[k],i) for i,y in enumerate(points)):
            mass+=weights[i]
            if 2*mass>=total:
                result.append(coordinate); break
    return tuple(result)

def dec(q):
    return D(q.numerator)/D(q.denominator)

def entropy(values):
    return -sum((dec(p)*dec(p).ln() for p in values if p),D(0))

# Stage 1: exact mass-adaptive geometry, including the limiting admissible size.
for n in [1,2,3,4,8,16,32,64]:
    gamma=(F(1)-F(1,4*n))**n/(F(1)-F(1,2*n))**n
    chi=(F(1)-F(1,4*n))**n
    for rho in [F(1,3),F(1),F(3)]:
        for divisor in [0,16*n,8*n]:
            d=F(0) if divisor==0 else rho/divisor
            w=F(2)*rho**n # beta=2, lambda=1
            for offset in [F(0),rho/17,rho,7*rho]:
                t=rho-2*d+offset; L=t-2*d
                assert L>0 and (t/L)**n<=gamma
                assert t**n>=chi*w/2
                assert (8*n*d)**n*2<=w
                counts['geometry']+=1

# Stage 2: one source-only frontier, arbitrary fine refinement and partial capture.
for n in [1,2,4]:
    for K in [1,2,4,8,16]:
        eps=F(1,10000*n); points=[]; weights=[]; labels=[]
        pm=[F(1,7),F(2,7),F(4,7)]
        for i in range(3):
            for j in range(K):
                points.append((F(10*i)+eps*F(2*j-K+1,K),)+(F(0),)*(n-1))
                weights.append(pm[i]/K); labels.append(i)
        for lam in [F(1,8),F(1,4),F(1,2),F(1),F(2)]:
            out,nodes=frontier(points,weights,lam)
            assert (8*n*eps)**n*F(2)*lam<=min(pm)
            for i in range(3):
                owners={j for j,J in enumerate(out)
                        if any(labels[z]==i for z in J['indices'])}
                assert len(owners)==1
            counts['tree']+=1
            for x0 in [F(-1,3),F(1,10000),F(8),F(29)]:
                x=(x0,)+(F(1,3),)*(n-1)
                M,(r,captured_mass,captured)=winner(points,weights,x)
                cap=set(captured)
                fine=[weights[i]/captured_mass for i in captured]
                macro=[sum((weights[i] for i in captured if labels[i]==j),F(0))
                       /captured_mass for j in range(3)]
                packet=[sum((weights[i] for i in J['indices'] if i in cap),F(0))
                        /captured_mass for J in out]
                with localcontext() as ctx:
                    ctx.prec=100
                    assert entropy(packet)<=entropy(macro)+D('1e-90')
                    assert entropy(macro)<=entropy(fine)+D('1e-90')
                counts['refinement']+=1

# Stage 3: strict majority implies coordinate-median containment, actual winner envelopes.
for n in [1,2,3]:
    points=list(product([F(-1),F(0),F(2)],repeat=n))
    weights=[F(i+1,sum(range(1,len(points)+1))) for i in range(len(points))]
    c=median(points,weights); w=sum(weights,F(0))
    for x in product([F(-2),F(-1,2),F(1,2),F(3)],repeat=n):
        for r in [F(1,4),F(1),F(2),F(4)]:
            a=sum((p for y,p in zip(points,weights) if dist(x,y)<=r),F(0))
            if 2*a>w: assert dist(x,c)<=r
            counts['median']+=1
        M,(r,Fstar,indices)=winner(points,weights,x)
        # Packet all the source: a=Fstar. Set lambda=3M/4, beta=2.
        lam=F(3,4)*M; v=(2*dist(x,c))**n
        if dist(x,c)<=r:
            assert M<=2*lam
            if v: assert M<=w/v
            counts['winner_envelope']+=1
# Necessary strictness, closed-cube endpoint.
assert median([(F(0),),(F(2),)],[F(1,2),F(1,2)])==(F(0),)
assert dist((F(2),),(F(0),))>F(1,4)

# Stage 4: actual three-copy band winners, tie endpoint, and all support cardinalities.
for m in [3,4,8,16,32,64,128]:
    h=F(1,m-1); lam=F(1,4)
    points=[(F(c)+j*h,) for c in [0,20,40] for j in range(m)]
    weights=[F(1,m)]*len(points)
    for c in [0,20,40]:
        for z in [F(1,4),F(1,2),F(3,4)]:
            right=1+h+(1-h)*z
            for x in [(F(c)+right,), (F(c)+1-right,)]:
                M,(r,mass,indices)=winner(points,weights,x)
                assert mass==1 and len(indices)==m
                assert M==1/(2*right) and lam<M<=2*lam
                assert mass<=sum(weights,F(0))/2
                counts['lattice']+=1
    # One-copy all-tie point: smallest-side winner is one site.
    P=[(j*h,) for j in range(m)]; U=[F(1,m)]*m
    M,(r,mass,indices)=winner(P,U,(1+h,))
    assert len(indices)==1 and M==1/(2*(1+h))
    for k in range(2,m+1):
        assert 2*m*(k-1)>k*(m-1)
        counts['lattice']+=1
    assert F(19,2)>F(3,4)

# Stage 5: high-precision radial constants, coarsening and S-weighted entropy.
def precision_run(prec):
    result=[]
    with localcontext() as ctx:
        ctx.prec=prec
        for n in [1,2,3,4,8,16,32,64]:
            gam=dec((F(1)-F(1,4*n))**n/(F(1)-F(1,2*n))**n)
            chi=dec((F(1)-F(1,4*n))**n)
            assert gam<=(D(1)/2).exp()
            for b in [F(3,2),F(2),F(5)]:
                for t in [F(1,8),F(1,2),F(1),F(3)]:
                    # Integrate the three radial envelope pieces with w=lambda=1.
                    beta=dec(b); tt=dec(t); p=gam; v0=chi/beta
                    inner=beta*(p/beta-v0)
                    middle=p*beta.ln(); tail=p/tt
                    got=inner+middle+tail
                    want=gam*(1+beta.ln()+1/tt)-chi
                    assert abs(got-want)<D(10)**(-prec+8)
                    result.append(got)
        vectors=[[F(1,2),F(1,3),F(1,6)],
                 [F(1,100),F(49,100),F(1,2)],
                 [F(1,7)]*7]
        for pi in vectors:
            for mask in range(1,1<<len(pi)):
                selected=[p for j,p in enumerate(pi) if mask>>j&1]
                S=sum(selected,F(0)); rr=[p/S for p in selected]
                H=entropy(rr)
                for t in [F(1,8),F(1,2),F(1),F(3)]:
                    tt=dec(t); sd=dec(S)
                    lhs=sum((dec(p)**(1+tt) for p in selected),D(0))
                    rhs=sd**(1+tt)*(-tt*H).exp()
                    assert lhs+ D(10)**(-prec+8)>=rhs
                    result.append(lhs)
                    if prec==80: counts['entropy']+=1
        for m in [3,4,8,16,32,64,128]:
            bulk=dec(F(2*(m-1),m)).ln()
            assert 0<bulk<D(2).ln()
            result.extend([bulk,D(m).ln()])
    return result
A=precision_run(80); B=precision_run(140)
with localcontext() as ctx:
    ctx.prec=160
    replay=max(abs(a-b) for a,b in zip(A,B))
assert replay<D('1e-70')
print(json.dumps(dict(status='PASS',exact_counts=counts,
                      precision_values=len(A),precision_difference=str(replay),
                      precision_label='Decimal replay, not interval certification'),indent=2))
```


### Current skill-file SHA-256 receipt

Paths are relative to `/Users/zhengzhihao/.codex/skills/`. All sixteen files were read from their current canonical installation, including their provenance boundaries; no historical copy was substituted. The applicable conditions remain as described in Section 7. Hash identity is not mathematical certification.

| Current file | SHA-256 |
|---|---|
| `math-d04-entropy-chain-rule/SKILL.md` | `7af206b4d5b82a13fa35be43762ff42119a795aa06877b0ba4ea36503cc83ad0` |
| `math-d04-entropy-chain-rule/references/method.md` | `fa03f65cbb0357c2bf15b12c991b642a29a2fa1e22a4068c8a0ba0b6bcd9fa58` |
| `math-d04-entropy-chain-rule/references/cube-interface.md` | `8cc686fa95fbaab92ceeff61140359978148c353d539e5baa2bf76a7c2ed55f2` |
| `math-d04-entropy-chain-rule/references/provenance.md` | `51b415dda94661d9a41db817af16e49e05ab6ff1d149c4c7be5f3c7f3b9d4d3c` |
| `math-e03-tree-bellman-cross-layer-budget/SKILL.md` | `5d587651365016a56122a262b05bdd2faa12166df5de70ec7d5e2ccea1a8377d` |
| `math-e03-tree-bellman-cross-layer-budget/references/method.md` | `e2e2ea1e91c7b641ef6a5e3d23be4381b1d694e040f7d045c87a0f30c0f95be4` |
| `math-e03-tree-bellman-cross-layer-budget/references/cube-interface.md` | `fd64e8e14dd99e164237a89ff052822c07040d2ca68d63669738a3f141470869` |
| `math-e03-tree-bellman-cross-layer-budget/references/provenance.md` | `15849d325355188a42709c1a25ce7fd21ec2a7a78570e84d7c0d5aedc4e348f6` |
| `math-g01-carleson-measure-box-and-tent-test/SKILL.md` | `a09c5ad3047b402a07c26651b8c79b42a46843228b48cc961956c76372bc0cd4` |
| `math-g01-carleson-measure-box-and-tent-test/references/method.md` | `35c4b408f69ffd39d105d89e77b92922a1105b85595563021d606b8c0992498d` |
| `math-g01-carleson-measure-box-and-tent-test/references/cube-interface.md` | `b037ce5e4d2c20d20521fdec5daaec83faec0ef849ef1bbb58f76a9289e13f36` |
| `math-g01-carleson-measure-box-and-tent-test/references/provenance.md` | `88229396d52913ac4d45499be9390eab14ce46ae26017df36bdd441245b02d8c` |
| `math-l03-rational-and-interval-certificates/SKILL.md` | `0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c` |
| `math-l03-rational-and-interval-certificates/references/method.md` | `9a76bd1959a2b623dbe7951684ce55428bbd9e9ddaa4a3516688ca785b31508c` |
| `math-l03-rational-and-interval-certificates/references/cube-interface.md` | `764b98f99801a38b35ebeab5b3a934d5f8b31842ad3f94ff68da3b4844fe64a6` |
| `math-l03-rational-and-interval-certificates/references/provenance.md` | `ced0d588ce52a592b3142a8b5d4f09e37d3ebb9f6a922e1fc76e8e089b9ad5ab` |

### Executed guard receipt

Executed with system Python 3, exit 0. Exact checks passed: 288 mass-adaptive geometries, 75 common frontiers, 300 partial-refinement entropy coarsenings, 336 median-containment cube tests, 13 actual winner envelopes, and 374 lattice winner/cardinality tests. The entropy replay covers 564 checks. There are 674 numerical values at both 80 and 140 Decimal digits; their maximum difference is `9.13327793824928863437024893119806183631085967507411874264176e-79`, below `1e-70`. This is a high-precision replay, not interval certification.

The embedded code block, excluding the surrounding fence and its final separating newline, has SHA-256 `14489866c20d8bbbeaf8eb5242df944e4d9499ffc71120b4b8cdb2ce92c79371`.


---

# Round72: common random partitions, exact collisions, and a paid-error obstruction

Status: the common-shift identities and the original-good-set signed L1 obstruction below are proved for the stated general construction. They do not bound the general cap square energy or establish the desired sqrt(n)n^{o(1)} weak upper bound. The one-atom input is used to falsify a proposed dimension-free reconstruction payment, not as a substitute research objective. In particular, a representative's large pointwise geometric inflation is not itself a counterexample to an actual band-occupation estimate.

## 1. One random partition of the common source

Let mu=sum_i p_i delta_yi be any finite positive atomic input, W=sum_i p_i. Fix d>0, choose ONE theta uniformly in [0,d)^n, and let C_J(theta)=theta+dJ+[0,d)^n. Assign every original atom to its unique half-open cell. For a receiver and an actual selected closed cube Q, let a_J=mu(C_J intersect Q), F=mu(Q)>0, pi_J=a_J/F. The selected cube, original maximal function, original global band and receiver Lebesgue measure are independent of theta. We never replace the captured set by a cube of representatives. Boundary shifts form a theta-null set.

For any source pair, common-cell membership has probability

    P_theta(y_i,y_j in the same cell)=T_d(y_i-y_j),
    T_d(z)=product_l (1-|z_l|/d)_+.

Indeed the allowed one-coordinate shift interval has length (d-|y_i,l-y_j,l|)_+, and the n coordinates of theta are independent. The sources themselves are NOT independently rounded. Consequently, for every actual captured set, including partial packet capture,

    E_theta sum_J a_J^2
       =sum_(i,j: y_i,y_j in Q) p_i p_j T_d(y_i-y_j).             (1)

On any fixed measurable actual band E, Tonelli gives the corresponding exact traffic identity

    E_theta integral_E M sum_J pi_J^2 dx
       = integral_E [M/F^2] sum_(i,j captured) p_i p_j T_d(y_i-y_j) dx.  (2)

Both sides can be interpreted as extended nonnegative integrals. This is a concrete common-source collision kernel; no factor gamma is inserted. It is not a paid bound for the exponent-zero occupation. Jensen implies H_packet>=-log(sum pi_J^2), so a collision upper bound would point in the WRONG direction for a low-entropy coverage claim. A lower bound or a different paid selector is needed. Neither pairwise independence across source sites nor unrestricted reuse of shifts is licensed by (1).

## 2. Mass-conserving reconstruction and signed averaging

Use the same partition to flatten each cell:

    F_theta=sum_J [mu(C_J)/d^n] 1_CJ.

For each theta this is positive, preserves W, and uses exactly the original source masses. It need not have an affordable height. For any finite positive Borel source the same countable-cell construction is meaningful by Tonelli. Averaging theta gives the exact convolution

    E_theta F_theta=mu*t_d,
    t_d(z)=d^(-n) T_d(z).                                      (3)

For one coordinate and a fixed source y, the fraction of shifts putting y and z in the same cell is (1-|z-y|/d)_+; the flattened cell contributes d^-1. This proves (3), with coordinates multiplied. Cell centers alone would instead produce a uniform displacement kernel; that is a different reconstruction.

Write q=exp(1/n), u=n log L, D_L=A_(qL)-A_L. For any fixed receiver set G independent of theta and finite window 0<a<=L<=b<infinity, regard D F as an element of L2(G times [n log a,n log b]). For a finite source all relevant norms are finite: convolution by cube kernels is bounded from finite measures to L2 at sides >=a, and F_theta has mass W. Fubini and Hilbert-space centering prove

    E_theta ||D(mu-F_theta)||_G,window^2
      =||D(mu-mu*t_d)||_G,window^2
          +E_theta ||D(F_theta-mu*t_d)||_G,window^2.              (4)

Thus signed cancellation in the annealed bias does not pay the common-shift variance. This identity has no independence or orthogonality assertion about different source blocks. For infinite windows (4) is used only after integrability is separately established; finite windows suffice for the obstruction below. Triangle-free averaging preserves the original cap set, but its two nonnegative terms still require budgets.

## 3. Exact hard-boundary test on the original global cap

Take mu=p delta_0, H=p/a^n, d=a/s, s>=1. Its ORIGINAL global good set is G=R^n minus the open cube Q_a, up to null boundaries. Let bar F=E F_theta=p t_d. For L>=d, Fubini over translations gives

    integral_Q_L A_L bar F dx=p(1-d/(3L))^n.                    (5)

The expected one-coordinate overlap of Q_L and Q_L+Z, Z having the triangular density d^-1(1-|z|/d)_+, is L-E|Z|=L-d/3. For q>1, put h=(q-1)L/2. If 0<=h<=d,

    integral_Q_L A_(qL) bar F dx
      =p q^(-n) [1-(d-h)^3/(3d^2 L)]^n.                       (6)

Here the overlap of intervals with lengths L and qL is L-(|Z|-h)_+, and E(|Z|-h)_+=(d-h)^3/(3d^2). These are spatially integrated actual reconstruction formulas, not abstract rounding coefficients.

For n>=2, suppose 2a<=L<=nd/96. Since q-1<=2/n, h<=L/n<=d/96<d/2. Equations (5)--(6) imply

    integral_Q_L |D_L bar F| dx
       <=p(1+exp(-1)) exp[-nd/(24L)] <3p/32.                   (7)

We used (d-h)^3/(3d^2)>=d/24, (1-z)^n<=exp(-nz), nd/(24L)>=4, and exp(1)>2. On Q_L intersect G the original D_L mu is the constant -(1-exp(-1))p/L^n. Its absolute integral is

    (1-exp(-1))p [1-(a/L)^n] >3p/8.                           (8)

Subtracting (7) from (8) yields the conservative bound

    integral_G |D_L(mu-bar F)| dx >=p/4.                     (9)

There are no extra bad sets, source-count factors, minimum-mass factors, or an unproved cap convergence in this example. The source is genuinely atomic and G is exactly its original global cap set. Finite-window Jensen and Tonelli now give, whenever n>192s,

    E_theta integral_(n log(2a))^(n log(nd/96))
          integral_G |D_(exp(u/n))(mu-F_theta)| dx du
       >= (np/4) log[n/(192s)].                              (10)

In particular the dimension-free L1 payment C W for this random block-uniform reconstruction fails at s=sqrt(n); the lower bound is of order n log n along sufficiently large n. This is an ADJACENT-SCALE SIGNED error after receiver integration and after averaging the common offset. No absolute individual-source majorization was used to establish it. The proof pays a finite explicit volume-time window; extending a nonnegative integral to all u only increases it.

This does NOT refute a cap L2 square-error bound: from (9) alone Cauchy gives a square lower bound proportional to p^2/L^n, which can be exponentially small on these windows. It also does NOT refute an improved random-packet traffic bound: one atom has one packet and its actual band traffic is W log beta. The block-uniform height here equals H s^n. We do not infer a general high target-height obstruction from it. Equation (10) only kills the suggested common-offset repair through an all-time dimension-free signed L1 reconstruction budget.

For additional calibration, the single-side annealed leakage on G at L=a is exactly

    integral_G |A_a(mu-bar F)| dx=p[1-(1-1/(3s))^n].           (11)

Indeed A_a mu vanishes on G and the leakage is the complement of (5). This proves a linear hard-boundary dependence as s tends to infinity with fixed n, despite the reconstruction's zero mean displacement. A uniform estimate C n/s^2 cannot control (11) in that regime. At s=sqrt(n) it is merely an O(W) one-side loss; the deeper obstruction (10) comes from the paid volume-time length, not from falsely treating this loss as exponential.

## 4. Precise surviving interfaces

For a common random source partition and the ORIGINAL winner band, a sufficient useful objective would be a direct average occupation/entropy-coverage inequality with a mass budget independent of offset multiplicity, e.g. a bound for

    E_theta integral_E M 1_{H_packet(theta,x)<=h_n} dx

together with paid coverage of its complement. Equation (2) supplies an exact pair kernel on the same input, but neither the needed lower collision bound nor the complementary high-entropy payment is established. The parent refinement theorem shows why an atomic-label entropy tail alone cannot be dismissed. A reconstruction square-budget approach instead needs to pay BOTH terms in (4), on the ORIGINAL cap, without the target height H s^n. Neither statement follows from an annealed zero-displacement calculation. The remaining inequality is still a general all-source budget problem.

## 5. Current skills and evidence scope

This round re-read the current A02 and N04 SKILL.md entries, method and cube-interface files, and their provenance indices. The A02 common-input/one-sided-objective conditions are used to distinguish actual capture from representatives; N04 requires an actual summable volume-time budget, which (10) explicitly denies for this L1 proxy. No literature theorem is imported and no skill is treated as an automatic cube theorem. Current entry/method/interface hashes match the retained versions:

A02: 5718759f09c75af3353a9e041f2f20ebcbca429d49eeb85ccea3bef998f141e5;
5a504ef9b0a05aec083f8b18e41571957b5a8ce71cde2c1a4d49f928fb07b719;
54707b23158ee96f429294bcba9f0d3a293ff1011d407a2fe98870ab689626bb.

N04: 0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107;
1322560cd8179ec6fff99df47b65b581f60d6f58ea0bd461bd243f4f88bd05f7;
7a3cd70b0b4e07acfa7c1f50d4a410ddd75e32fe9b535105907ccff80eb8d439.

The proofs are elementary and standalone. No TeX compilation or Git action was performed.

## 6. Reproducible finite checks

The embedded standard-library guard checks actual source winners and common-grid collision probabilities by exact Fraction integration over ALL offset event cells in dimensions 1--4; no independent source displacement is substituted. It separately checks triangular fringe integration with exact rationals and actual q=exp(1/n) overlap/error formulas at Decimal 80/140 precision. The Decimal checks are precision diagnostics, not outward interval certificates; the proof above supplies the all-n constants.

```python
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from math import isqrt
import json

def event_boxes(points,d,n):
    parts=[]
    for l in range(n):
        b=sorted({F(0),d}|{y[l]%d for y in points})
        parts.append([( (a+b)/2,(b-a)/d) for a,b in zip(b,b[1:]) if b>a])
    for items in product(*parts):
        theta=tuple(t[0] for t in items)
        weight=F(1)
        for t in items: weight*=t[1]
        yield theta,weight

def label(y,theta,d):
    return tuple((v-t)//d for v,t in zip(y,theta))

def tent(z,d):
    ans=F(1)
    for v in z: ans*=max(F(0),1-abs(v)/d)
    return ans

def actual_winner(src,x):
    distances=sorted({max(abs(v-z) for v,z in zip(y,x)) for p,y in src})
    best=F(0); selected=None
    for r in distances:
        if r==0: raise ValueError('source receiver')
        inds=[i for i,(p,y) in enumerate(src) if max(abs(v-z) for v,z in zip(y,x))<=r]
        mass=sum((src[i][0] for i in inds),F(0))
        value=mass/(2*r)**len(x)
        if value>best: best=value;selected=(r,inds,mass)
    return best,selected

def decimal_bounds(precision):
    out=[]
    with localcontext() as ctx:
        ctx.prec=precision
        e=D(1).exp()
        for n in [2,16,64,256,1024,4096,65536,262144]:
            q=(D(1)/n).exp()
            assert q-1<=D(2)/n
            for s in sorted({1,4,isqrt(n),n}):
                upper=D(n)/(96*s)
                if upper<=2: continue
                d=D(1)/s
                for L in [D(2),(D(2)*upper).sqrt(),upper]:
                    h=(q-1)*L/2
                    fringe=(d-h)**3/(3*d*d)
                    assert 0<=h<=d/2
                    one=(1-d/(3*L))**n
                    two=(1-fringe/L)**n/e
                    old=(1-1/e)*(1-(1/L)**n)
                    lower=old-one-two
                    assert lower>D(1)/4
                    assert one+two<D(3)/32
                    out.append(lower)
    return out

def random_partition_guard():
    collision=0;offset_boxes=0;bands=0;annealed=0;fringes=0
    for n in [1,2,3,4]:
        for seed in [1,3]:
            src=[]
            for i in range(5):
                y=tuple(F(((i+2)*(l+3)+seed*l)%13-6,4) for l in range(n))
                src.append((F(i+1,7),y))
            d=F(3,4)
            boxes=list(event_boxes([y for p,y in src],d,n))
            assert sum((w for theta,w in boxes),F(0))==1
            offset_boxes+=len(boxes)
            for j in range(6):
                x=tuple(F(j*(l+1)-3,5)+F(1,97) for l in range(n))
                M,(r,inds,mass)=actual_winner(src,x)
                assert M>0 and all(max(abs(a-b) for a,b in zip(src[i][1],x))<=r for i in inds)
                rhs=sum((src[i][0]*src[j][0]*tent(tuple(a-b for a,b in zip(src[i][1],src[j][1])),d)
                         for i in inds for j in inds),F(0))
                lhs=F(0)
                for theta,w in boxes:
                    packets={}
                    for i in inds:
                        k=label(src[i][1],theta,d)
                        packets[k]=packets.get(k,F(0))+src[i][0]
                    lhs+=w*sum((a*a for a in packets.values()),F(0))
                assert lhs==rhs
                # The same actual winner and global band are used for EVERY theta.
                for lam in [F(1,4),F(1,2),F(1),F(2)]:
                    if lam<M<=2*lam:
                        assert M*lhs/mass**2==M*rhs/mass**2
                        bands+=1
                collision+=1
            for j in range(3):
                z=tuple(F(j-1,3)+F(l,11) for l in range(n))
                mean=F(0)
                for theta,w in event_boxes([y for p,y in src]+[z],d,n):
                    k=label(z,theta,d)
                    mean+=w*sum((p for p,y in src if label(y,theta,d)==k),F(0))/d**n
                expected=sum((p*tent(tuple(a-b for a,b in zip(z,y)),d)/d**n for p,y in src),F(0))
                assert mean==expected
                annealed+=1
    for d in [F(1,4),F(1),F(7,3)]:
        for h in [F(0),d/7,d/2,6*d/7,d]:
            # Exact integral of 2(z-h)(d-z)/d^2 from h to d.
            def primitive(z):
                return (d+h)*z*z/2-z**3/3-h*d*z
            actual=2*(primitive(d)-primitive(h))/(d*d)
            assert actual==(d-h)**3/(3*d*d)
            fringes+=1
    lo=decimal_bounds(80);hi=decimal_bounds(140)
    with localcontext() as ctx:
        ctx.prec=140
        discrepancy=max(abs(a-b) for a,b in zip(lo,hi))
        assert len(lo)==len(hi) and discrepancy<D('1e-70')
    return dict(exact_actual_collision_checks=collision,exact_offset_event_boxes=offset_boxes,
                actual_original_band_checks=bands,exact_annealed_source_checks=annealed,
                exact_triangular_fringe_checks=fringes,actual_q_overlap_checks=len(lo),
                max_decimal_precision_discrepancy=str(discrepancy),
                smallest_signed_L1_lower_bound=str(min(hi)),
                precision_scope='Decimal 80/140 agreement, not interval certification')

if __name__=='__main__':
    print(json.dumps(random_partition_guard(),sort_keys=True))
```

Actual replay: exit 0. Passed 48 exact actual-winner collision checks, 18 original-band checks, 24 exact annealed-source evaluations, 15 exact triangular-fringe integrals and 33 actual-q overlap/error tests, with 136 exact common-offset event boxes. Decimal dimensions range from 2 to 262144; only dimensions/s for which the stated nonempty window exists are tested. The 80/140-digit discrepancy was 9.01172480280828823331798949014259282146693650936612293423980e-81. The smallest computed conservative signed L1 lower bound was greater than 0.63212p. These finite computations are diagnostics and exact finite identities, not a certificate for all-source cap energy.


## Complete source-refinement rational guard

```python
from fractions import Fraction as F
from itertools import product
import json

def winner(x, ys, ps):
    batches={}
    for i,y in enumerate(ys):
        r=max(abs(a-b) for a,b in zip(x,y))
        batches.setdefault(r,[]).append(i)
    mass=F(0);best=None;ids=[]
    for r,js in sorted(batches.items()):
        mass+=sum((ps[i] for i in js),F(0));ids+=js
        if not r:continue
        value=mass/(2*r)**len(x)
        if best is None or value>best[0]:best=(value,r,mass,tuple(ids))
    return best

def main():
    counts={};records=[]
    for stage,ns,ks in [('pilot',[1,2],[2,4]),('pressure',[1,3,4],[3,8]),('expanded',[8,16],[2,16])]:
        count=0
        for n,K in product(ns,ks):
            ys=[tuple(F(3*j+i%2,2) for i in range(n)) for j in range(3)]
            ps=[F(1,7),F(2,7),F(4,7)]
            for eps in [F(1,128*K),F(1,1024*K)]:
                zs=[];ws=[];parents=[]
                for j,y in enumerate(ys):
                    for k in range(K):
                        off=eps*F(2*k-K+1,K-1)
                        zs.append((y[0]+off,)+y[1:]);ws.append(ps[j]/K);parents.append(j)
                assert len(set(zs))==len(zs) and sum(ws)==sum(ps)
                for q in range(1,13):
                    x=tuple(F(q*(i%3+1)-7,11) for i in range(n))
                    d=min(max(abs(a-b) for a,b in zip(x,y)) for y in ys)
                    if d<=eps:continue
                    old=winner(x,ys,ps);new=winner(x,zs,ws)
                    assert old[0]*(d/(d+eps))**n<=new[0]<=old[0]*(d/(d-eps))**n
                    val,r,mass,ids=new
                    assert max(ws[i]/mass for i in ids)<=max(ps)/(K*mass)
                    # Exact packet probability and fine conditional factorization.
                    sums=[sum((ws[i] for i in ids if parents[i]==j),F(0)) for j in range(3)]
                    assert sum(sums)==mass
                    for i in ids:
                        a=sums[parents[i]]
                        assert ws[i]/mass==(a/mass)*(ws[i]/a)
                    count+=1
        counts[stage]=count
    exact=0
    for K in [2,3,4,8,16,32,64,128]:
        eps=F(1,128*K*K)
        ys=[(eps*F(2*k-K+1,K-1),) for k in range(K)];ps=[F(1,K)]*K
        lo=F(1,4)-eps;hi=F(1,2)-eps
        for sign,q in product([-1,1],range(1,16)):
            x=sign*(lo+(hi-lo)*F(q,16));v,r,m,ids=winner((x,),ys,ps)
            assert F(1)<v<F(2) and m==1 and len(ids)==K
            assert v==1/(2*(abs(x)+eps))
            assert all(ps[i]/m==F(1,K) for i in ids)
            copies=[(y[0]+16*j,) for j in range(3) for y in ys]
            cp=ps*3; vv,rr,mm,ii=winner((x+16,),copies,cp)
            assert vv==v and mm==1 and mm<F(3,2) and len(ii)==K
            assert (F(16)-2*eps)>3 # Any cross-copy cube has average <1.
            exact+=1
        assert F(1,4)-eps>2*K*eps
        assert 1/(2*(2*K+1)*eps)>2
        records.append(dict(K=K,epsilon=str(eps),weak_ratio=str(1-2*eps),band_integral='log(2)',captured_entropy=f'log({K})',copy_mass_fraction='1/3'))
    counts['exact_high_entropy_residual_points']=exact
    out=dict(passed=True,counts=counts,calibrations=records,scope='finite exact checks; general saturation and limits are analytic')
    print(json.dumps(out,sort_keys=True))
    return out

if __name__=='__main__':main()
```


---

# Round 72: actual weak bands under source refinement and shared packets

The completed finite experiment separates two effects. Narrow microcluster refinement increases atomic captured entropy by essentially `log K`, while the entropy of the original macro packets stays close to its unrefined value and the actual weak/band estimates change little. Fixed grids can keep packet entropy small while their cell-center volume inflation remains costly. The adaptive radius criterion successfully compresses the tested narrow clusters; it cannot merge any two sites of the homogeneous one-dimensional grid in the exact guard. These observations do not prove a general winner budget, a dimension-uniform entropy tail, or a paid reconstruction estimate.

## Actual object and receiver measure

Every source is a single finite positive atomic measure of exact mass `W=1`. Coordinates are the exact dyadic values of the stored machine floats; weights are positive rational numbers. For every receiver, the program evaluates all arrival volumes

`v_i=(2||x-y_i||∞)^n`,

and tests the average after each complete equal-distance batch. The winner is the smallest-volume batch maximizing that average. No time mesh, source-measure receiver weighting, or spatial truncation is used. The reported weak statistic is `λ|{Mμ>λ}|/W`; the band statistic is `∫_{λ<Mμ≤2λ} Mμ dx/W`.

The microscopic source replaces macro atom `i` by `K` distinct atoms of mass `p_i/K`, with alternating-coordinate diagonal offsets. The input epsilon is the minimum macro-site separation times the registered ratio; the JSON also stores the exact maximum displacement realized after floating construction. Macro packet labels stay fixed across receivers and refinements.

The all-space proposal is frozen at the unrefined macro source. Put `V=W/λ`, `a_i=p_i/W`, `τ_i=v_i/V`, and let `M` denote the number of macro sites. Its complete normalized density is

`qcore=V q(x)=Σ min(1,τ_i^-2)/(4M) + Σ a_i min(1,τ_i^-2)/8 + Σ min(1,(a_i/τ_i)^2)/8`.

It is a mixture of normalized radial-volume laws, with center selection respectively uniform, mass-weighted/global-volume, and mass-weighted/individual-volume. Each radial law has density `1/(2b)` on `0<v≤b` and `b/(2v²)` on `v>b`; each half integrates to `1/2`. The cube-cone angular law is uniform, so `dx=dv dσ`. The entire density is evaluated at every receiver. The weak and band scores are respectively `1_{Mμ>λ}/qcore` and `1_band (Mμ/λ)/qcore`.

A refined weak winner contains at least one microatom. Its macro center has normalized volume at most `Γ=(1+2ε/V^(1/n))^n`. Therefore the uniform-macro component gives `qcore≥1/(4MΓ²)` and score envelopes `4MΓ²` and `8MΓ²`. The code uses an exact dyadic lower enclosure of the root `V^(1/n)` and an upward-enclosed displayed Gamma bound. This envelope depends on macro count and displacement, not on refinement count `K`.

## Registered stages and selection

The frozen run contains 96 source/seed/refinement rows, 34,816 unique all-space receivers, and 153,600 receiver–refinement evaluations. Sharing a receiver across refinements is intentional; the evaluations are not 153,600 independent draws. There are 1,524 fixed-grid diagnostic rows.

- Pilot: the four retained macro sources, `K=1,4,16`, ratio `1/256` for nontrivial refinement, 512 receivers per macro source; 12 rows.
- Independent held-out refinement: two seeds × 2,048 receivers per retained macro source; `K=1,2,4,8,16` at ratio `1/4096`, plus `K=8` at ratios `1/16` and `1/256`; 56 rows.
- Independent dimension/count controls: hierarchical sources with dimensions `2,8,32` and macro counts `4,16` varied separately, `K=1,8`, ratio `1/1024`, two seeds × 1,024 receivers; 24 rows. The threshold is `2^(-n-1)`.
- Boolean pressure: the actual full `±1` vertex source in dimension 8, macro count 256, threshold `1/65536`, `K=1,4`, ratio `1/4096`, two seeds × 2,048 receivers; four rows. The refined source has 1,024 sites.

The selected n1/n4/n8 macro geometries were chosen in Round 71, so their old selection bias remains. The n2 product-grid control is the retained exact-halo calibration source. Round 72 held-out receiver seeds are independent of that earlier selection and of this pilot. No new threshold or source optimizer selected the reported held-out values. The illustrative geometry rows below were selected after observing this finite run and are diagnostics, not an independently selected universal extremum.

## Paired refinement findings

The table combines the two held-out seeds with equal sample counts. The displayed `±` is one combined sample standard error for the mean, not a certified confidence interval. Entropies are self-normalized band-M-weighted ratios; the program does not estimate a separate confidence interval for those ratios.

| Macro source | K | Actual weak statistic | Actual band-M statistic | Atomic captured entropy | Macro captured entropy |
|---|---:|---:|---:|---:|---:|
| n1 selected, 16 macro sites | 1 | 1.25999 ± .01618 | 1.05961 ± .02224 | .43133 | .43133 |
| same | 16 | 1.25947 ± .01618 | 1.05890 ± .02224 | 3.20440 | .43182 |
| n2 product grid, 16 macro sites | 1 | 1.06585 ± .01709 | .73344 ± .02249 | .47554 | .47554 |
| same | 16 | 1.06585 ± .01709 | .73374 ± .02248 | 3.24830 | .47571 |
| n4 selected, 16 macro sites | 1 | 1.20798 ± .02577 | .91200 ± .03099 | .52552 | .52552 |
| same | 16 | 1.20586 ± .02574 | .91098 ± .03093 | 3.29698 | .52439 |
| n8 selected, 32 macro sites | 1 | 1.04550 ± .03144 | .69212 ± .03504 | .66516 | .66516 |
| same | 16 | 1.04187 ± .03136 | .68959 ± .03492 | 3.43983 | .66725 |
| n8 Boolean, 256 macro sites | 1 | 1.39990 ± .04166 | 1.09168 ± .04859 | .95471 | .95471 |
| same | 4 | 1.39640 ± .04162 | 1.08925 ± .04848 | 2.34069 | .95439 |

At ratio `1/4096`, every sampled original-band winner captures each touched macro packet completely. Hence `H_atomic-H_macro-logK` has maximum absolute band-weighted mean `1.17e-16`, an algebraic splitting diagnostic on these sampled captures. This is not a proof that all receivers capture entire packets. The paired band-difference means and SEs are stored separately in every row, using the same receivers rather than subtracting independent estimates.

The larger ratio `1/16` is a substantive control. For n4 selected, partial-macro traffic is `.4274` and `.3913` on the two seeds; for n8 selected, `.3439` and `.3493`. Those macro packets fail the adaptive-radius test. Weak/band values also change appreciably there, so finite-radius refinement is not treated as an exact invariance. The n2 ratio `1/16` fails the criterion despite no partial macro captures on its sampled band. Criterion failure and observed partial capture are separate diagnostics.

The dimension/count controls do not show a general entropy theorem: for several n32 controls the winner captures a single macro packet, so macro entropy is zero while atomic entropy is `log 8`. Dimensions and macro counts are varied independently, but this remains a limited hierarchical family and a limited threshold range.

## Fixed shared grids and actual geometry

For each `χ=1/64,1/256`, the source/threshold-only lower window is `aχ=(χW/(2λ))^(1/n)`. On the original band, `F*/W≥χ` implies winner full side at least `aχ`. Grid sides approximate `aχ/s` for `s=1,√n,n`; the exact rational machine side and exact rational lower root enclosure are stored. Cell membership is computed with rational half-open cells. Shift 0 is fixed at zero; shifts 1 and 2 are independently seeded common discrete phases with 1,024 possible fractions per coordinate. These are alternative frozen partitions of the same source. They are not a union cover, and two discrete phases do not certify a continuous-shift expectation. Correlations from the common shift are retained.

A captured packet posterior is `c_J/F*`, where `c_J` is the actual original winner's captured mass in that packet. All traffic uses `Mμ c_J/F*`; it does not charge the whole packet mass merely because the packet is touched. Partial-capture traffic uses the captured mass belonging to packets with `0<c_J<w_J`. The program records original-band traffic omitted by `F*/W<χ` separately.

For the geometric diagnostic, the winner radius is enlarged enough to include the cell-center representative of every touched packet, or enough to include every source site in those packets. The reported inflation is the resulting volume ratio, bounded below by 1, integrated against eligible original-band M traffic. It is not the maximum corner bound substituted as an integral. Safe geometric bounds are `(1+d/aχ)^n` and `(1+2d/aχ)^n`; the stored versions use the actual side and root enclosure.

An illustrative n32/macro16/K8 row (seed 726216, χ=1/64) has original band-M `.53421 ± .06557`, with no omitted traffic. Its cell-center inflation traffic is:

| s | shift 0 | shift 1 | shift 2 |
|---|---:|---:|---:|
| 1 | 5.134e7 ± 1.235e7 | 5.782e7 ± 1.584e7 | 7.665e7 ± 2.011e7 |
| √32 | 11.260 ± 2.119 | 14.519 ± 2.964 | 16.046 ± 3.002 |
| 32 | .7300 ± .0934 | .7155 ± .0917 | .8251 ± .1052 |

Packet entropy is zero for all three `s=1` alternatives on this sampled band. Thus small packet entropy does not itself pay this positive geometric inflation. The enormous formal Hoeffding radii remain useless here; for `s=1` the displayed cell-center radius is about `2.35e10`, already much larger than these means. No exponential-rate or dimension-growth fit is made.

The windows matter independently of this inflation. For example, Boolean n8/K4 seed 724001 has total band-M `1.00532`; χ=1/64 retains `.31965` and omits `.68567`. The omitted part is not declared covered by a grid estimate. Finer χ=1/256 diagnostics are retained separately.

## Mass-adaptive packets and exact failure control

For a packet with mass `w_J`, the source-only acceptance criterion is `d_J≤(w_J/(2λ))^(1/n)/(8n)`, where `d_J` is the actual bounding-box radius (half the maximum coordinate extent). The program checks the equivalent rational-power inequality exactly. Its representative is the bounding-box center. This is distinct from the fixed grid's cell-center representative; even a singleton's grid cell center may be far from its source site.

On the original global band the analytic mass-adaptive inflation bound is `γ_n=[(1-1/(4n))/(1-1/(2n))]^n≤exp(1/2)`. The code records accepted original captured traffic and actual bbox-center inflation and checks the floating values with a stated tolerance. It does not certify all floating inflation evaluations by interval arithmetic.

A lean source-only Kruskal tree is evaluated only for the narrow held-out n1/K16, n4/K16, and n8/K8 refinements. L∞ pair distances are exact dyadic integers; edge ties are ordered by `(distance,i,j)`. Starting at the root, a node is retained at the first accepted radius criterion; otherwise its children are visited. Every leaf passes. The resulting frontier is an antichain partition, so source mass is counted once. The six seed rows have respectively 16,16,32 packets, all admissible; none splits a macro packet. These finite frontiers do not establish an entropy bound for arbitrary sources.

The homogeneous-grid guard supplies a precise contrasting geometry. For `m=4,8,16,32,64,128,256,1024`, take equal mass `1/m` at `j/(m-1)` and λ=1/4. Any subset of `k≥2` sites has radius at least `(k-1)/(2(m-1))`, whereas its acceptance radius is `k/(4m)`. The code verifies their strict rational inequality for every k. Thus no multisite packet passes: the admissible frontier must remain singleton. On the two symmetric outer winner intervals, the actual full winner is the whole source and the band-M traffic is `log(2(m-1)/m)`, tending to `log 2`; captured entropy is `log m`. The finite rational interior winner and all packet-radius comparisons are checked by the standalone program. The traffic logarithm is evaluated as floating arithmetic. This guard prevents interpreting successful narrow-cluster compression as compression of every refinement or every fine source.

## Evidence boundary and replay

The program retained 482 weak/band score extremes and closest sampled gate points on both sides of `M/λ=1,2` where available. At these receivers, exact binary-coordinate arrival ordering, complete tied batches, exact maximizing winner and actual gate classification agree with the floating path. The complete macro density is enclosed by outward integer-grid rational sums at denominator `10^80`; maximum relative width is `2.43e-76`. Maximum observed floating relative discrepancies are `4.67e-15` for M and `2.99e-15` for q. Across all evaluations, 98,816 rows triggered exact binary grouping, with zero false-log groups found and zero near-maximal/gate winner fallbacks required. These are finite point checks, not an all-receiver enclosure or a certified spatial integral.

An initial pilot assertion incorrectly applied the grid window inflation bound to receivers outside the original band. It failed before producing that run's results. The condition was corrected to the actual band and the pilot and final registered run were rerun. No failed output is presented as successful evidence.

Each nonnegative score stores its sample SE, maximum, formal ideal-proposal range, and two-sided 95% Hoeffding radius `B sqrt(log(40)/(2S))`. Held-out weak-score radii range from `.6791` to `30.8205`, despite the much smaller SEs. The symbolic range follows from the normalized continuous proposal and geometry; products displayed as floats are diagnostic representations. Pseudorandom finite-machine sampling, all ordinary floating evaluations, and unsampled gate or extreme configurations are not covered by a rigorous continuous-integral certificate. Paired differences and conditional entropy ratios have different dependence/normalization from independent means. None is promoted to an arbitrary-source theorem, an individual-column theorem, or a weak counterexample from a noisy point estimate.

The current L01/L02/L03 entrances and their method, interface and provenance references were reopened; H05 entrance/method/interface were also reread. Their restrictions on actual feasible input, finite search versus proof, outward rounding, and independence were retained. No general discrete-to-continuous migration theorem or generic verified interval library is assumed.

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 packet_probe.py
```

The program is standalone and writes `packet_results.json` beside itself. `--pilot` intentionally writes a smaller PILOT JSON and must not be used for final archive replay. NumPy 2.3.5 / Python 3.12.14, BLAS threads 1. The completed local run exited 0 in 75.6479 seconds; wall-clock runtime is printed but excluded from deterministic JSON. Session 46332 is closed. No package installation, Git change, PDF operation, TeX compilation, or edit to another agent's file was performed.

Frozen script SHA256: `ae55b39f67bf2694d86dcd55ffb8ab12b79889404fdab920f31d6cf1d625b0ee`.

Frozen results SHA256: `2b12a5a84b6123d2b7e3b5b466cd992829750a56730beac1ecfcfa3cb880f65c`.
