#!/usr/bin/env python3
"""True weak/winner-band microcluster refinement and fixed shared packet probes.
All-space receivers use one complete macro-source proposal, paired across refinements.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse, itertools, json, math, time
from pathlib import Path
from fractions import Fraction as F
import numpy as np


def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])

def integer_masses(src):
    masses=[F(p)/F(src['W']) for p in src['weights']];den=math.lcm(*(p.denominator for p in masses));assert den<2**60
    integers=np.array([p.numerator*(den//p.denominator) for p in masses],dtype=np.int64)
    return den,integers

def pack(coords,weights,family):
    merged={};weights=[F(p) for p in weights];W=sum(weights)
    for y,p in zip(coords,weights):merged[tuple(float(z) for z in y)]=merged.get(tuple(float(z) for z in y),F(0))+p/W
    return dict(family=family,n=len(coords[0]),N_requested=len(coords),N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W='1')

def binary_geometry(x,coords):
    xr=[float(z).as_integer_ratio() for z in x];yr=[[float(z).as_integer_ratio() for z in y] for y in coords]
    B=max(t.bit_length()-1 for u,t in xr+sum(yr,[]));xi=[u<<(B-(t.bit_length()-1)) for u,t in xr]
    ds=[max(abs(z-(u<<(B-(t.bit_length()-1)))) for z,(u,t) in zip(xi,row)) for row in yr]
    return ds,B

def exact_winner(x,src,H):
    ds,B=binary_geometry(x,src['coords']);den,ints=integer_masses(src);order=sorted(range(src['N']),key=lambda i:ds[i])
    cum=0;bestnum=0;bestden=1;best=-1
    for j,i in enumerate(order):
        cum+=int(ints[i])
        if j+1<len(order) and ds[i]==ds[order[j+1]]:continue
        d=ds[i]**src['n']
        if d==0:raise ValueError('Receiver coincides with an atom; null-set sample unsupported')
        if cum*bestden>bestnum*d:bestnum,bestden,best=cum,d,j
    M=F(bestnum,bestden)*F(src['W'])/den/F(2)**(src['n']*(1-B))
    capture=np.zeros(src['N'],dtype=bool);capture[order[:best+1]]=True
    return capture,M,H<M<=2*H,order,best

def actual_volumes(x,src,H):
    ds,B=binary_geometry(x,src['coords']);V=F(src['W'])/F(H);factor=F(2)**(src['n']*(1-B))/V
    return [d**src['n']*factor for d in ds],[F(p)/F(src['W']) for p in src['weights']]

def structured_source(kind,n,N,seed):
    rng=np.random.default_rng(seed)
    if kind=='binary':
        if N<=2**n:
            labels=rng.choice(2**n,size=N,replace=False)
            y=np.array([[2*((int(j)>>k)&1)-1 for k in range(n)] for j in labels],float)
        else:
            y=rng.choice([-1.,1.],size=(N,n))+rng.integers(-8,9,size=(N,n))/64
        weights=[1]*N
    elif kind=='hierarchical':
        depth=max(1,(N-1).bit_length())
        code=rng.integers(0,2,size=(depth,n))*2-1
        y=np.array([sum((((j>>k)&1)*2-1)*2.**(-k)*code[k] for k in range(depth)) for j in range(N)])
        y/=max(1.,float(abs(y).max()));weights=[1]*N
    elif kind=='correlated':
        t=np.linspace(-1,1,N)[:,None]
        y=t+rng.integers(-4,5,size=(N,n))/128;weights=[1]*N
    elif kind=='unequal_cloud':
        y=rng.integers(-64,65,size=(N,n))/64;weights=[1+(j%8)**2 for j in range(N)]
    elif kind=='multi_cluster':
        centers=rng.choice([-1.,1.],size=(4,n));y=np.array([centers[j%4]+rng.integers(-8,9,size=n)*2.**(-4-j//4) for j in range(N)])
        weights=[1+3*(j%4==0) for j in range(N)]
    else:raise ValueError(kind)
    return pack(y.tolist(),[F(p) for p in weights],kind)

def draw_winner(src,lam,S,seed):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/lam)
    component=rng.choice(3,size=S,p=[.5,.25,.25]);unif=rng.integers(src['N'],size=S);mass=rng.choice(src['N'],size=S,p=a);center=np.where(component==0,unif,mass)
    U=np.maximum(rng.random(S),np.nextafter(0.,1.));inner=rng.integers(0,2,size=S)==0
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))+np.where(component==2,np.log(a[center]),0)
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1;theta[np.arange(S),face]=sign
    return y[center]+(.5*np.exp(lv/n))[:,None]*theta,component,center,U,inner,face,sign

def winner_batch(x,src,lam):
    y,a=arrays(src);S=len(x);n=src['n'];N=src['N'];den,ints=integer_masses(src);V=float(F(src['W'])/lam)
    delta=x[:,None,:]-y[None,:,:];dist=np.max(abs(delta),axis=2)
    if np.any(dist==0):raise ValueError('Null-set atom receiver coincidence unsupported')
    L=n*np.log(2*dist)-math.log(V)
    t=np.exp(-2*np.maximum(L,0));q=t.sum(axis=1)/(4*N)+(t*a[None,:]).sum(axis=1)/8+np.exp(-2*np.maximum(L-np.log(a)[None,:],0)).sum(axis=1)/8
    order=np.argsort(L,axis=1,kind='stable');sl=np.take_along_axis(L,order,axis=1)
    ends=np.concatenate([sl[:,1:]!=sl[:,:-1],np.ones((S,1),bool)],axis=1);fix=0;falsegroups=0
    near=np.any(abs(sl[:,1:]-sl[:,:-1])<=64*np.finfo(float).eps*(np.max(abs(sl),axis=1)[:,None]+2),axis=1)
    for r in np.flatnonzero(near):
        ds,B=binary_geometry(x[r],src['coords']);oi=sorted(range(N),key=lambda i:ds[i]);order[r]=oi;sl[r]=L[r,oi]
        en=np.array([ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True]);falsegroups+=int(np.sum(en & ~np.concatenate([sl[r,1:]!=sl[r,:-1],[True]])));ends[r]=en;fix+=1
    cum=np.cumsum(ints[order],axis=1);arr=np.where(ends,cum/den*np.exp(-sl),0);best=np.argmax(arr,axis=1);M=np.max(arr,axis=1)
    # Smallest-volume maximizing complete batch, with exact fallback for close winners.
    runner=np.partition(arr,-2,axis=1)[:,-2] if N>1 else np.zeros(S)
    exact=np.flatnonzero((M-runner<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-1)<=128*np.finfo(float).eps*np.maximum(M,1)) | (abs(M-2)<=128*np.finfo(float).eps*np.maximum(M,1)))
    exactmeta={}
    for r in exact:
        capture,mm,_,oi,bj=exact_winner(x[r],src,lam);order[r]=oi;sl[r]=L[r,oi];best[r]=bj;M[r]=float(mm/lam)
        ds,B=binary_geometry(x[r],src['coords']);ends[r]=[ds[oi[j]]!=ds[oi[j+1]] for j in range(N-1)]+[True];exactmeta[r]=(capture,mm)
    cum=np.cumsum(ints[order],axis=1);Fstar=cum[np.arange(S),best]/den;count=best+1
    tau=np.exp(sl[np.arange(S),best]);rank=np.empty((S,N),int);np.put_along_axis(rank,order,np.broadcast_to(np.arange(N),(S,N)),axis=1);capture=rank<=best[:,None]
    weak=M>1;band=(M>1)&(M<=2)
    for r,(cp,mm) in exactmeta.items():
        capture[r]=cp;count[r]=int(cp.sum());Fstar[r]=float(F(int(ints[cp].sum()),den));tau[r]=Fstar[r]/float(mm/lam);weak[r]=mm>lam;band[r]=lam<mm<=2*lam
    single=count==1;majority=(~single)&(cum[np.arange(S),best]*2>den);residual=~single & ~majority
    inv=q**-1;weakscore=weak*inv;bandscore=band*M*inv;bandvolume=band*inv
    loads=band[:,None]*capture/(tau*q)[:,None];weightedloads=loads*a[None,:]
    assert np.max(abs(weightedloads.sum(axis=1)-bandscore))<2e-9
    assert np.max(weakscore)<=4*N*(1+1e-10) and np.max(bandscore)<=8*N*(1+1e-10)
    assert np.max(weightedloads)<=8*N*(1+1e-10)
    eff=Fstar**2/np.sum(capture*a[None,:]**2,axis=1)
    posterior=capture*a[None,:]/Fstar[:,None];entropy=-np.sum(posterior*np.log(np.maximum(posterior,1e-300)),axis=1)
    return dict(M=M,q=q,weak=weak,band=band,Fstar=Fstar,count=count,tau=tau,capture=capture,posterior=posterior,entropy=entropy,geometry_fallback=fix,falsegroups=falsegroups,exact_winner_rows=len(exact))

MACROS=[{'label': 'R71_n1_selected', 'source': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[-0.825], [0.375], [-0.225], [0.9906250000000001], [-1.15625], [0.090625], [-0.49375], [0.6593749999999999], [-0.6437499999999999], [0.540625], [-0.10625], [1.140625], [-0.9906250000000001], [0.225], [-0.44921875], [0.840625]], 'family': 'hierarchical', 'n': 1, 'weights': ['9/142', '8/213', '9/142', '9/142', '9/142', '16/213', '9/142', '9/142', '9/142', '9/142', '9/142', '9/142', '9/142', '9/142', '9/142', '9/142']}, 'lambda': '4911210218475899/9007199254740992'}, {'label': 'R71_n2_product_grid16', 'source': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[-0.75, -0.75], [-0.75, -0.25], [-0.75, 0.25], [-0.75, 0.75], [-0.25, -0.75], [-0.25, -0.25], [-0.25, 0.25], [-0.25, 0.75], [0.25, -0.75], [0.25, -0.25], [0.25, 0.25], [0.25, 0.75], [0.75, -0.75], [0.75, -0.25], [0.75, 0.25], [0.75, 0.75]], 'family': 'certificate_product_grid16', 'n': 2, 'weights': ['1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16', '1/16']}, 'lambda': '1/4'}, {'label': 'R71_n4_selected', 'source': {'N': 16, 'N_labels': 16, 'N_requested': 16, 'W': '1', 'coords': [[-1.0, -1.0, -1.0, -1.0], [-1.0, 1.0, 1.0, 1.125], [1.0, 1.0, 1.0, 1.125], [-1.0, 1.0, -1.0, 1.125], [1.0, 1.0, -1.0, -1.0], [1.0, -1.0, 1.0, -1.0], [1.0, 1.0, -1.0, 1.125], [1.0, -1.0, 1.0, 1.125], [-1.0, -1.0, -1.0, 1.125], [-1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, -1.0, -1.0], [1.0, 1.0, 1.0, -1.0], [-1.0, -1.0, 1.0, 1.125], [1.0, -1.0, -1.0, -1.0], [1.0, -1.0, -1.0, 1.125]], 'family': 'binary', 'n': 4, 'weights': ['7/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67', '4/67']}, 'lambda': '1/256'}, {'label': 'R71_n8_selected', 'source': {'N': 32, 'N_labels': 32, 'N_requested': 32, 'W': '1', 'coords': [[-1.0, -1.0, -0.875, 1.0, 1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, 0.875, -1.0, -1.0, 1.0, -1.0, -1.0], [-1.0, 1.0, -0.875, -1.0, -1.0, 1.0, -1.0, 1.0], [1.0, 1.0, -0.875, -1.0, -1.0, -1.0, 1.0, 1.0], [-1.0, -1.0, 0.875, -1.0, 1.0, -1.0, -1.0, -1.0], [-1.0, -1.0, -0.875, 1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, 0.875, 1.0, 1.0, 1.0, -1.0, 1.0], [-1.0, 1.0, -0.875, 1.0, 1.0, -1.0, 1.0, 1.0], [1.0, -1.0, 0.875, -1.0, 1.0, -1.0, 1.0, 1.0], [1.0, 1.0, -0.875, 1.0, 1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, 0.875, -1.0, 1.0, 1.0, 1.0, -1.0], [1.0, -1.0, -0.875, -1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, -1.0, 0.875, -1.0, -1.0, 1.0, -1.0, 1.0], [1.125, 1.125, -0.84765625, -1.046875, -1.09375, 1.0, 0.890625, -0.875], [-1.0, -1.0, 0.875, 1.0, 1.0, -1.0, 1.0, -1.0], [1.0, 1.0, 0.875, 1.0, -1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, -0.875, -1.0, 1.0, -1.0, 1.0, 1.0], [-0.984375, 0.953125, -0.796875, -0.9375, -1.125, 0.96875, 1.0, 1.0625], [-1.0, 1.0, 0.875, 1.0, -1.0, -1.0, 1.0, -1.0], [1.0, -1.0, -0.875, 1.0, 1.0, 1.0, 1.0, 1.0], [-1.0, -1.0, 0.875, 1.0, 1.0, 1.0, 1.0, -1.0], [1.0, -1.0, 0.875, 1.0, 1.0, -1.0, -1.0, 1.0], [-1.0, 1.0, -0.875, -1.0, 1.0, 1.0, 1.0, -1.0], [1.0, 1.0, 0.875, 1.0, 1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, -0.875, -1.0, -1.0, -1.0, -1.0, -1.0], [-1.0, 1.0, -0.875, 1.0, -1.0, -1.0, -1.0, 1.0], [-1.0, -1.0, 0.875, 1.0, 1.0, 1.0, -1.0, -1.0], [1.0, 1.0, -0.875, -1.0, -1.0, -1.0, -1.0, 1.0], [1.0, 1.0, -0.875, -1.0, -1.0, -1.0, 1.0, -1.0], [-1.0, 1.0, -0.875, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 0.875, 1.0, 1.0, 1.0, 1.0, -1.0], [-1.0, 1.0, 0.875, 1.0, 1.0, -1.0, -1.0, -1.0]], 'family': 'binary', 'n': 8, 'weights': ['1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32', '1/32']}, 'lambda': '1/131072'}]


def nthroot_floor(m,n):
    lo=0;hi=1<<((m.bit_length()+n-1)//n)
    while lo+1<hi:
        t=(lo+hi)//2
        if t**n<=m:lo=t
        else:hi=t
    return hi if hi**n<=m else lo

def root_lower(z,n):
    z=F(z);Q=2**40;return F(nthroot_floor(z.numerator*Q**n//z.denominator,n),Q)

def upper_float(z):
    r=float(z)
    while F(r)<z:r=float(np.nextafter(r,math.inf))
    return r

def stats(z,bound):
    return dict(mean=float(np.mean(z)),sample_SE=float(np.std(z,ddof=1)/math.sqrt(len(z))),maximum=float(np.max(z)),ideal_bound=float(bound),ideal_Hoeffding95_radius=float(bound)*math.sqrt(math.log(40)/(2*len(z))))

def separation(src):
    y=np.array(src['coords']);return float(min(np.max(abs(y[i]-y[j])) for i in range(len(y)) for j in range(i))) if len(y)>1 else 1.


def refine(macro,K,eps_ratio):
    eps=separation(macro)*float(eps_ratio);coords=[];p=[];labels=[]
    for i,(y,w) in enumerate(zip(macro['coords'],macro['weights'])):
        for j in range(K):
            t=(2*j+1-K)/K;offset=[eps*t*(1 if k%2==0 else -1) for k in range(macro['n'])]
            coords.append([float(v+u) for v,u in zip(y,offset)]);p.append(F(w)/K);labels.append(i)
    src=pack(coords,p,'micro_refinement');lookup={tuple(y):i for y,i in zip(coords,labels)};parent=[lookup[tuple(y)] for y in src['coords']]
    assert src['N']==macro['N']*K
    support=max((abs(F(z)-F(macro['coords'][i][k])) for y,i in zip(src['coords'],parent) for k,z in enumerate(y)),default=F(0))
    return src,parent,support


def partition(src,labels,lam):
    keys=list(dict.fromkeys(labels));mapping={k:i for i,k in enumerate(keys)};ids=np.array([mapping[k] for k in labels]);order=np.argsort(ids,kind='stable');starts=np.r_[0,np.flatnonzero(np.diff(ids[order]))+1];den,ints=integer_masses(src);mass=np.add.reduceat(ints[order],starts);y=src['coords'];n=src['n'];adaptive=[]
    for group in range(len(keys)):
        atom=np.flatnonzero(ids==group);diam=max(max(F(y[i][k]) for i in atom)-min(F(y[i][k]) for i in atom) for k in range(n));adaptive.append((4*n*diam)**n<=F(int(mass[group]),den)*F(src['W'])/(2*lam))
    return dict(ids=ids,order=order,starts=starts,mass=mass,den=den,adaptive=np.array(adaptive))


def packet_capture(d,src,p):
    den,ints=integer_masses(src);c=np.add.reduceat((d['capture']*ints[None,:])[:,p['order']],p['starts'],axis=1);total=np.sum(c,axis=1);rho=c/total[:,None];entropy=-np.sum(rho*np.log(np.maximum(rho,1e-300)),axis=1);partial=np.sum(c*((c>0)&(c<p['mass'][None,:])),axis=1)/total;good=np.sum(c*p['adaptive'][None,:],axis=1)/total
    assert entropy.max()<=math.log(len(p['mass']))+1e-10 and np.all(entropy<=d['entropy']+1e-10)
    return c,entropy,partial,good


def fixed_grids(src,macro,lam):
    n=src['n'];V=F(macro['W'])/lam;grids=[]
    for chi in [F(1,64),F(1,256)]:
        lower=root_lower(chi*V/2,n)
        for s in sorted(set([1.,math.sqrt(n),float(n)])):
            ell=F(float(lower)/s);assert ell>0
            for shift_id in range(3):
                rng=np.random.default_rng(720441+1009*n+int(chi.denominator)+shift_id)
                shift=[F(0)]*n if shift_id==0 else [ell*F(int(t),1024) for t in rng.integers(0,1024,size=n)]
                labels=[tuple((F(z)-sh)//ell for z,sh in zip(y,shift)) for y in src['coords']];p=partition(src,labels,lam);keys=list(dict.fromkeys(labels));reps=[[sh+(k+F(1,2))*ell for k,sh in zip(key,shift)] for key in keys]
                grids.append(dict(chi=chi,s=s,shift_id=shift_id,ell=ell,lower=lower,shift=shift,partition=p,reps=reps,representative_bound=(1+ell/lower)**n,whole_support_bound=(1+2*ell/lower)**n))
    return grids


def density_guard(x,macro,lam):
    vols,a=actual_volumes(x,macro,lam);N=macro['N'];terms=[min(F(1),1/v**2)/(4*N) for v in vols]+[ai*min(F(1),1/v**2)/8 for ai,v in zip(a,vols)]+[min(F(1),(ai/v)**2)/8 for ai,v in zip(a,vols)];Q=10**80
    return F(sum(z.numerator*Q//z.denominator for z in terms),Q),F(sum(-(-z.numerator*Q//z.denominator) for z in terms),Q)


def exact_point(x,src,macro,lam,qfloat,mask,floatM):
    cap,M,_,_,_=exact_winner(x,src,lam);assert np.array_equal(cap,mask);qlo,qhi=density_guard(x,macro,lam)
    assert (floatM>1)==(M>lam) and (1<floatM<=2)==(lam<M<=2*lam)
    return dict(receiver=x.tolist(),M_lambda=str(M/lam),captured_indices=np.flatnonzero(cap).tolist(),weak=M>lam,band=lam<M<=2*lam,qcore_interval=[str(qlo),str(qhi)],q_relative_width=float((qhi-qlo)/qlo),float_M_relative=abs(floatM-float(M/lam))/float(M/lam),float_q_relative=float(max(abs(F(qfloat)-qlo),abs(F(qfloat)-qhi))/qlo),scope='Exact retained machine-coordinate winner and outward integer-grid complete macro proposal density; no receiver-integral certificate.')


def frontier_labels(src,lam):
    # Source-only exact dyadic L-infinity Kruskal tree; ties by (distance,i,j).
    N=src['N'];n=src['n'];yy=[[F(z) for z in y] for y in src['coords']];B=max(z.denominator.bit_length()-1 for y in yy for z in y);yi=[[int(z*2**B) for z in y] for y in yy]
    edges=sorted((max(abs(a-b) for a,b in zip(yi[i],yi[j])),i,j) for i in range(N) for j in range(i))
    uf=list(range(N));node=list(range(N));members=[[i] for i in range(N)];children=[None]*N
    def root(i):
        while uf[i]!=i:uf[i]=uf[uf[i]];i=uf[i]
        return i
    for _,i,j in edges:
        a,b=root(i),root(j)
        if a==b:continue
        left,right=sorted([node[a],node[b]]);nid=len(members);members.append(members[left]+members[right]);children.append((left,right));uf[b]=a;node[a]=nid
        if len(members[nid])==N:break
    labels=[None]*N;frontier=[]
    def visit(t):
        atom=members[t];w=sum(F(src['weights'][i]) for i in atom);diam=max(max(yy[i][k] for i in atom)-min(yy[i][k] for i in atom) for k in range(n));good=(4*n*diam)**n<=w/(2*lam)
        if good or children[t] is None:
            assert good
            g=len(frontier);frontier.append(atom)
            for i in atom:labels[i]=g
        else:
            for c in children[t]:visit(c)
    visit(node[root(0)]);assert sum(len(t) for t in frontier)==N
    return labels


def adaptive_metrics(x,src,d,p,band,rstar,bb):
    reps=[]
    for group in range(len(p['mass'])):
        atom=np.flatnonzero(p['ids']==group)
        reps.append([(min(src['coords'][i][k] for i in atom)+max(src['coords'][i][k] for i in atom))/2 for k in range(src['n'])])
    c,h,partial,good=packet_capture(d,src,p);rho=c/c.sum(axis=1)[:,None];rr=np.max(abs(x[:,None,:]-np.array(reps)[None,:,:]),axis=2);infl=np.maximum(1,rr/rstar[:,None])**src['n'];gamma=((1-F(1,4*src['n']))/(1-F(1,2*src['n'])))**src['n'];gb=upper_float(gamma)
    eligible=(c>0)&p['adaptive'][None,:]&d['band'][:,None]
    assert np.all(infl[eligible]<=gb*(1+1e-9))
    return dict(packet_count=len(p['mass']),all_packets_admissible=bool(p['adaptive'].all()),mass_counted_once_exact=True,bbox_center_admissible_inflation_traffic=stats(band*np.sum(rho*infl*p['adaptive'][None,:],axis=1),bb*gb),admissible_original_traffic=stats(band*good,bb),partial_capture_traffic=stats(band*partial,bb),captured_packet_entropy_band_mean=float(band@h/band.sum()) if band.sum() else None,gamma_exact=str(gamma))


def evaluate(x,macro,src,parents,support,lam,seed,K,eps_ratio,stage,macrodata):
    chunks=[winner_batch(x[j:j+128],src,lam) for j in range(0,len(x),128)];ks=[k for k in chunks[0] if k not in ['geometry_fallback','falsegroups','exact_winner_rows']];d={k:np.concatenate([z[k] for z in chunks]) for k in ks};q=macrodata['q'];S=len(x);N=src['N'];M=macro['N'];V=F(macro['W'])/lam;lower=root_lower(V,src['n']);Gamma=(1+2*support/lower)**src['n'];wb=upper_float(4*M*Gamma**2);bb=2*wb
    weak=d['weak']/q;band=d['band']*d['M']/q;assert weak.max()<=wb*(1+1e-10) and band.max()<=bb*(1+1e-10)
    macroband=macrodata['band']*macrodata['M']/q;macro_p=partition(src,parents,lam);cc,hm,partial,good=packet_capture(d,src,macro_p)
    rstar=np.max(np.where(d['capture'],np.concatenate([np.max(abs(x[j:j+128,None,:]-np.array(src['coords'])[None,:,:]),axis=2) for j in range(0,S,128)]),0),axis=1)
    def avg(z):return float(band@z/band.sum()) if band.sum() else None
    row=dict(stage=stage,seed=seed,samples=S,K=K,epsilon_ratio=str(eps_ratio),epsilon_support=str(support),macro_N=M,actual_N=N,lambda_value=str(lam),weak=stats(weak,wb),band_M=stats(band,bb),atomic_entropy_band_mean=avg(d['entropy']),macro_entropy_band_mean=avg(hm),macro_partial_capture_traffic=stats(band*partial,bb),macro_adaptive_good_traffic=stats(band*good,bb),atomic_high_entropy=stats(band*(d['entropy']>math.sqrt(src['n'])),bb),macro_high_entropy=stats(band*(hm>math.sqrt(src['n'])),bb),paired_weak_difference=dict(mean=float((weak-macrodata['weak']/q).mean()),sample_SE=float(np.std(weak-macrodata['weak']/q,ddof=1)/math.sqrt(S))),paired_band_difference=dict(mean=float((band-macroband).mean()),sample_SE=float(np.std(band-macroband,ddof=1)/math.sqrt(S))),entropy_increment_minus_logK_band_mean=avg(d['entropy']-hm-math.log(K)),macro_geometry_bound=str(Gamma),grid_packets=[],guards=[],exact_binary_geometry_rows=sum(z['geometry_fallback'] for z in chunks),false_log_groups_corrected=sum(z['falsegroups'] for z in chunks),exact_winner_rows=sum(z['exact_winner_rows'] for z in chunks))
    row['macro_adaptive_bbox_metrics']=adaptive_metrics(x,src,d,macro_p,band,rstar,bb)
    if stage=='heldout_refinement' and K in [8,16] and eps_ratio==F(1,4096) and ((src['n'] in [1,4] and K==16) or (src['n']==8 and K==8)):
        labels=frontier_labels(src,lam);pp=partition(src,labels,lam);row['Kruskal_frontier']=adaptive_metrics(x,src,d,pp,band,rstar,bb);row['Kruskal_frontier']['splits_any_macro_packet']=any(len(set(labels[j] for j,pid in enumerate(parents) if pid==i))>1 for i in range(M))
    atomdist=np.concatenate([np.max(abs(x[j:j+128,None,:]-np.array(src['coords'])[None,:,:]),axis=2) for j in range(0,S,128)])
    for g in fixed_grids(src,macro,lam):
        p=g['partition'];c,h,part,adapt=packet_capture(d,src,p);eligible=d['Fstar']>=float(g['chi']);weights=band*eligible;reps=np.array([[float(z) for z in y] for y in g['reps']]);touch=c>0
        rd=np.concatenate([np.max(abs(x[j:j+128,None,:]-reps[None,:,:]),axis=2) for j in range(0,S,128)]);rsupport=np.maximum.reduceat(atomdist[:,p['order']],p['starts'],axis=1)
        rrep=np.max(np.where(touch,rd,0),axis=1);rwhole=np.max(np.where(touch,rsupport,0),axis=1);gre=np.maximum(1,rrep/rstar)**src['n'];gwh=np.maximum(1,rwhole/rstar)**src['n'];rb=upper_float(g['representative_bound']);sb=upper_float(g['whole_support_bound'])
        assert np.all(gre[eligible & d['band']]<=rb*(1+1e-9)) and np.all(gwh[eligible & d['band']]<=sb*(1+1e-9))
        entry=dict(chi=str(g['chi']),s=g['s'],shift_id=g['shift_id'],grid_side=str(g['ell']),lower_window_side=str(g['lower']),shift=[str(z) for z in g['shift']],packet_count=len(p['mass']),eligible_band_M=stats(weights,bb),omitted_band_M=stats(band*(~eligible),bb),packet_entropy_conditional_mean=float(weights@h/weights.sum()) if weights.sum() else None,partial_capture_traffic=stats(weights*part,bb),adaptive_good_traffic=stats(weights*adapt,bb),representative_inflation_traffic=stats(weights*gre,bb*rb),whole_support_inflation_traffic=stats(weights*gwh,bb*sb),representative_log_inflation_traffic=stats(weights*np.log(gre),bb*math.log(rb)),corner_representative_bound=str(g['representative_bound']),corner_whole_support_bound=str(g['whole_support_bound']),entropy_cutoffs=[dict(h=t,covered_band_M=stats(weights*(h<=t),bb)) for t in [math.sqrt(src['n']),math.sqrt(src['n'])*math.log(src['n']+2)]])
        row['grid_packets'].append(entry)
    if stage!='pilot':
        ids=set(list(np.argsort(weak)[-1:])+list(np.argsort(band)[-1:]))
        for threshold in [1,2]:
            for above in [False,True]:
                inds=np.flatnonzero((d['M']>threshold)==above)
                if len(inds):ids.add(int(inds[np.argmin(abs(np.log(d['M'][inds]/threshold)))]))
        for i in sorted(ids):row['guards'].append(exact_point(x[i],src,macro,lam,q[i],d['capture'][i],d['M'][i]))
    return row


def homogeneous_guards():
    rows=[]
    for m in [4,8,16,32,64,128,256,1024]:
        # Any k>=2 subset has radius >=(k-1)/(2(m-1)); rho/8=k/(4m).
        for k in range(2,m+1):assert F(k-1,2*(m-1))>F(k,4*m)
        lo=F(m,m-1);hi=F(2);x=(lo+hi)/2
        ds=[abs(x-F(j,m-1)) for j in range(m)]
        candidates=[F(sum(t<=r for t in ds),m)/(2*r) for r in sorted(set(ds))]
        assert max(candidates)==F(1)/(2*x) and F(1,4)<max(candidates)<=F(1,2)
        traffic=math.log(float(hi/lo))
        rows.append(dict(m=m,lambda_value='1/4',winner_interval=[str(lo),'2'],both_sides_band_M=traffic,atomic_and_singleton_packet_entropy=math.log(m),all_multisite_packets_fail_exact=True,scope='Exact finite subset-radius inequalities and rational interior actual full winner; analytic interval traffic evaluated with float log.'))
    return rows


def macro_batch(x,src,lam):
    ch=[winner_batch(x[j:j+128],src,lam) for j in range(0,len(x),128)]
    return {k:np.concatenate([z[k] for z in ch]) for k in ['q','M','weak','band']}


def main():
    t=time.perf_counter();ap=argparse.ArgumentParser();ap.add_argument('--pilot',action='store_true');args=ap.parse_args()
    rows=[];registry=[];sources=[];sourcekeys={};unique=0
    def group(entry,cases,S,seeds,stage):
        nonlocal unique
        macro=entry['source'];lam=F(entry['lambda']);mid=len(registry);registry.append(entry)
        for seed in seeds:
            x,*_=draw_winner(macro,lam,S,seed);unique+=S;md=macro_batch(x,macro,lam)
            for K,eps in cases:
                key=(entry['label'],K,str(eps))
                if key not in sourcekeys:
                    src,parent,support=refine(macro,K,eps);sourcekeys[key]=len(sources);sources.append(dict(source=src,parent_ids=parent,epsilon_support=str(support),K=K,epsilon_ratio=str(eps),macro_id=mid))
                sid=sourcekeys[key];item=sources[sid]
                row=evaluate(x,macro,item['source'],item['parent_ids'],F(item['epsilon_support']),lam,seed,K,eps,stage,md)
                row.update(macro_id=mid,source_id=sid,label=entry['label'],n=macro['n']);rows.append(row)
            print(stage,entry['label'],seed,'rows',len(rows),'seconds',round(time.perf_counter()-t,3),flush=True)
    pilotcases=[(1,F(0)),(4,F(1,256)),(16,F(1,256))]
    for j,entry in enumerate(MACROS):group(entry,pilotcases,512,[720100+j],'pilot')
    if not args.pilot:
        pressure=[(1,F(0))]+[(k,F(1,4096)) for k in [2,4,8,16]]+[(8,F(1,16)),(8,F(1,256))]
        for j,entry in enumerate(MACROS):group(entry,pressure,2048,[721000+10*j,721001+10*j],'heldout_refinement')
        for n in [2,8,32]:
            for N in [4,16]:
                entry=dict(label=f'hierarchical_n{n}_macro{N}',source=structured_source('hierarchical',n,N,722000+100*n+N),**{'lambda':str(F(1,2**(n+1)))})
                group(entry,[(1,F(0)),(8,F(1,1024))],1024,[723000+100*n+N,723001+100*n+N],'heldout_independent_n_N')
        entry=dict(label='Boolean_n8_macro256',source=pack(list(itertools.product([-1.,1.],repeat=8)),[F(1,256)]*256,'Boolean_vertices'),**{'lambda':'1/65536'})
        group(entry,[(1,F(0)),(4,F(1,4096))],2048,[724001,724002],'heldout_Boolean')
    guards=[g for r in rows for g in r['guards']]
    out=dict(scope='Finite positive sources, actual full tied cube maximum and original band; all-space Lebesgue complete macro proposal. No fitted order or general bound from finite sampling.',status='PILOT' if args.pilot else 'FINAL',proposal='Fixed unrefined macro three-component radial proposal; all refinements of each seed share receivers and full macro density.',macros=registry,sources=sources,rows=rows,homogeneous_singleton_guards=homogeneous_guards(),counts=dict(rows=len(rows),unique_receivers=unique,receiver_refinement_evaluations=sum(r['samples'] for r in rows),fixed_grid_rows=sum(len(r['grid_packets']) for r in rows),retained_rational_points=len(guards)),guard_summary=dict(max_M_relative=max((g['float_M_relative'] for g in guards),default=0),max_q_relative=max((g['float_q_relative'] for g in guards),default=0),max_q_interval_relative_width=max((g['q_relative_width'] for g in guards),default=0)),environment=dict(python='3.12.14',numpy=np.__version__,BLAS_threads=1))
    Path(__file__).with_name('packet_results.json').write_text(json.dumps(out,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print('DONE',out['counts'],'runtime_seconds',time.perf_counter()-t,flush=True)


if __name__=='__main__':main()
