# R662 精简研究包：真实来源随机交集与同次全局覆盖

一般纯 C_n≤K√n 及旧一般 n^(1/2+o(1)) 均未证明。阅读顺序：REPORT.tex（完整本轮正文）→AUDIT_INTERSECTION.md→AUDIT_GLOBAL_KEY.md→AUDIT_NUMERIC.md→FINAL_REVIEW.md。不编译PDF。

独审通过的新几何：有限共点立方体、实际不交F_i⊂B_i、q_i=|F_i|/|A_i|，在规定高T和k条件下，真实iid交集外扩期望≤U exp(100n/k−T/8)。这是局部一般估计。首k事件覆盖使用同一Poisson过程；完整近尺度并集总价≤A U仍未证明，尤其不能免费去掉选择核、低前负载或跨组重叠。

## 文件与版本

- REPORT.tex 是本轮最终符号及参数入口：重新以τ=16384√n构造实际解，k=ceil(2τ)。
- TASK.md保留最初τ=8√n的任务快照，仅供原始合同/数值来源核对；最终解析参数以REPORT为准。环层MC仍使用原先8√n，未伪称运行新高T模型。
- COVERAGE_BRIDGE.md、SOFT_JOINT_PRICE.md保留决定性作者推导及独审定位。先前不成功的裁剪/core草稿只在本地保留，报告已摘要失败原因，不再归档重复文件。
- intersection_probe.py/results.json：12×256个真实有限环层模型的对数体积观测；不是体积比期望证书，未认证admission或目标损失。
- independent_numeric.py/json：参数有理/Arb核验、对数统计和4个既存样本独立复现。
- scalar_probe.py/results.json：SymPy恒等式、三个严格常数以及153个合法参数点的256位Arb比较；有限点并非连续域/任意n证明。
- NUMERIC.md：共享任务索引及实际范围。独立模型审计当时读的是该文件前1993字节，SHA=4abed0af5b3d7bd03e36743bc6e5fb1fd21aa0a929ba41801b65979f63f13df5；后来仅追加HALO-02方案。verify.py会实际核此前缀哈希，不篡改原运行记录。
- manifest.json、verify.py：最终文件哈希、报告审查绑定、语法和无覆盖重放。它们不认证一般数学命题。

## 实际工具与复现

实际解释器：/Users/zzh/.local/share/math-research-tools/venv/bin/python
版本：Python3.12.14、NumPy2.5.4、SciPy1.18.1、SymPy1.14.0、python-flint0.9.0。
原命令、seed、精度和运行时间在相应JSON中。本轮没有宣称使用MATLAB或Mathematica。

将research.zip解到 /Volumes/data/CodexTemp 下的新目录后执行：
  /Users/zzh/.local/share/math-research-tools/venv/bin/python verify.py
  /Users/zzh/.local/share/math-research-tools/venv/bin/python verify.py --replay

--replay在同一数据盘创建独立临时目录，重放独立审计和标量证书，比较全部数学记录；仅剔除新运行的耗时和重新记录的输入哈希，另外验证实际输入哈希。不会覆盖归档数据，也不会重做完整MC。
如确需完整重复MC，先将包复制到另一个数据盘目录，再在那里执行intersection_probe.py；不要覆盖原始证据。

审核使用J04补偿技能，实际读SKILL、method、cube-interface、provenance。没有导入其未读原论文或一般随机Fubini定理；本轮需要的有限Poisson式已独立推导。64项技能的审计方法是条件核验工具，不能独自认证最终引理。

## 剩余准确问题

同一真实residual解与首k联合过程，按首次完成的key组构造限制到低前负载集合的halo。证明它们的实际并集期望≤绝对常数×U；需要保留首次新增区域、同一arrival完成的全部组、代表选择与重叠节省。详细自足命题见REPORT式(6)、(17)、(20)。本轮没有证明这个全局费用。
