# R662：同一 Poisson 律的 soft 付款；联合 marked-clique 费用未证

状态：证明了一个真实全族 soft 覆盖费用，所有 target 使用同一组随机标记，来源复用已经在同一期望内支付。它没有支付全部 near loss；近尺度碎片仍未解决。进一步的高标记共同交覆盖尚无新的期望费用控制，故停止扩展，不把 Poisson tail 或另一个未证预算当成闭合。

所有 q_i、F_i、X_j、z_j 均来自 TASK.md 的同一次实际解，|F_i|=d_iq_i，F_i 和 X_j 是真实不交 owners。辅助随机覆盖不改变实际共同权 q/τ。

## 1. 一个可实证、全族只付一次的联合律

固定 c0=1+1/a。对每个实际正 q 来源 i，独立抽 Poisson(q_i) 个标记；每个标记再独立抽

    E~Exp(rate 2c0 n)，

并产生辅助 cube

    D_{i,E}=Q(y_i,s_i(1+c0 E))。

全部 target 共用这一套标记，不能为每个 target 重新抽取或重新计费。有限输入下标记总数几乎必然有限。

单个标记的期望体积满足

    E|D_{i,E}|=d_i E(1+c0E)^n
      ≤d_i E exp(nc0E)=2d_i。

因此同一随机覆盖族的总期望成本严格为

    E Σ_marks |D_{i,E}|≤2Σ_iq_i d_i=2U。            (COST)

即使一个标记服务许多 targets，它只在 COST 中出现一次。

对 target j，定义真实的 receiver 包含阈值

    δ_ij=[(||y_j−y_i||∞+s_j/a)/s_i−1]_+/c0，
    S_j^exact=Σ_i q_i exp(−2c0n δ_ij)。

E≥δ_ij 当且仅当该辅助 cube 包含整个 B_j。Poisson thinning 因而给同一联合律下

    P(B_j 被至少一个单标记 cube 整体覆盖)
      =1−exp(−S_j^exact)。

这不声称它等于被所有辅助 cubes 的并集覆盖的总概率；后者可以更大。

真实 X_j 不交。固定任一标记，所有被它整体覆盖的 X_j 的体积之和至多 |D_{i,E}|。先对此求和再取期望，得到更强的线性全族式

    Σ_lost j |X_j| S_j^exact≤2U，                  (SOFT)

从而也有

    Σ_lost j |X_j|(1−exp(−S_j^exact))≤2U。

没有假设 arbitrary f 或 KKT 来源有密度帽；仅使用真实 owner pieces 的不交性。

若 i∈I_j，则 z_j∈A_i 给

    δ_ij≤s_j/s_i。

故仅凭已冻结 near 数据也得到

    S_j^near:=Σ_{i∈I_j}q_i exp(−2c0n s_j/s_i)
       ≤S_j^exact，
    Σ_near j |X_j| S_j^near≤2U。                   (NEAR-SOFT)

例如 S_j^exact≥b 的所有实际损失体积至多 2U/b。这是一个真实 joint payment，但不是全部 near 的付款。

## 2. 为什么这还不能处理近尺度碎片

near 只保证 Σ_{i∈I_j}q_i>τ/2。它没有给 S_j^near 或 S_j^exact 的统一正下界；s_i接近s_j时，合同直接提供的 soft 权重为 exp(−O(n))。

这不是简单调整指数参数就能消除的费用。对任何单来源同心增长律，若 D_i=Q(y_i,s_i(1+c0E_i)) 且 E|D_i|≤K d_i，则

    P(E_i≥u)≤K/(1+c0u)^n。

所以在 u 接近1的尺度，保持每个来源绝对常数的体积期望，不能同时给这个充分增长事件一个维数无关的概率。该限制只针对本单源增长机制，不是否定利用多个共同来源的 clique halo。

因此 SOFT 是可支付的联合式；把尚未支付的 S_j^exact 很小的 targets 再命名为“fragmented”并不解决它们，本文件不作这种闭合声称。

## 3. 同一标记的高计数共同交覆盖：准确停止点

保留完全同一组 Poisson(q_i) 标记。真实 near 点 z_j 的入射标记数是 Poisson(T_j)，T_j=Σ_{i∈I_j}q_i>τ/2。令 k=floor(τ/4)，则

    P(入射标记数≥k)≥1−exp(−τ/16)>1/2。

这里独立性只来自实际抽样，不来自原方体、owners 或来源。

一个明确的联合辅助集是：对所有至少 k 个真实标记组成的子族 S，若它们有正体积共同交且 max_{i∈S}s_i<n min_{i∈S}s_i，取

    (∩_{i∈S}A_i)+Q(0,c0 min_{i∈S}s_i)，

再对所有这些 S 作并集，记为 H_k。标记允许同一原来源有多个副本，均来自本次 Poisson 律。

若 j 的 near 入射计数达到 k，所取来源同时包含同一个真实 z_j，且 s_j≤min s_i、max s_i<n s_j。因此整个 B_j 包含于 H_k。这是一个一次构造的 joint cover，未为每个 target 单独收费。

但本工作没有证明 E|H_k|≤C U。逐 tuple 求和会严重重复同一空间区域；把共同交换成逐 pair 的 envelope 又会丢掉同一 z 条件。Poisson 高计数概率本身不控制这个几何费用。没有找到新的随机几何费用步骤，所以不继续把该期望不等式包装成新的剩余目标或研究成果。

## 4. 核验与结论

本机指定数学 Python/SymPy 实际核得：n=3时上述单标记体积因子为61/36<2；指数矩上界严格为2；n=256时高计数失败概率界为exp(−8)。这些只作常数与积分 sanity check，不是根阶数值证据。

本次没有证明 V_near≤A U，也没有证明全部 anchor/source 重用费用受控。保留 SOFT 这一严格全族同次付款及其明确范围；高计数共同交路线因缺少新的联合几何成本估计而停止。未修改实际解、未扩大 soft 权家族、未运行扫描或改动他人文件。

# 后续检查点：首 k 真实事件分组、联合 void 与 admission

本段是主代理要求继续后的冻结检查点。先前单源 soft 式不再扩展。以下首 k 分组、补偿公式和 admission 限制已独立核验；全局总价仍未证明。

## 5. 一个总能覆盖真实 losses 的共同 first-key 律

将同一来源 Poisson 过程延长到时间 [0,∞)：来源 i 的事件速率始终为实际 q_i。每个事件保留完整的来源 label 和连续 arrival time；不同事件即使来源相同也不能混同。所有 targets 共用此过程。

固定一个整数 k≥1。对每个真实 near target j，令 K_j 为其固定 I_j 中最早 k 个实际事件组成的有序 key。T_j=Σ_{i∈I_j}q_i>0 是抽样前固定的真实 rate，所以 K_j 几乎必然存在。对单独固定 j，key 的来源 labels 为 iid law q_i/T_j，终止时刻为 Gamma(k,T_j)。

按完全相同 key 将全部 near targets 分成实际组 G。令 h(G) 为该组在原 radius-descending 实际顺序中的最早行，因此 s_h=max_{j∈G}s_j。若 key 的来源 tuple 为 i_1,…,i_k，写

    K(tuple)=∩_{l=1}^k A_{i_l}。

每个 j∈G 的同一个真实 z_j 都属于 K(tuple)，且 s_j≤min_l s_{i_l}。于是

    X_j⊂B_j⊂K(tuple)+Q(0,c0 s_h)。

这是一次全局实际 partition；没有为每个 target 独立抽样，也没有要求有限时间 Poisson(1) 达到大 k。首 k 时刻有限，所有有限 targets 的最大完成时刻也几乎必然有限。

对任意预先固定的非空 target 子族 G，记

    I_cap=∩_{j∈G}I_j，I_cup=∪_{j∈G}I_j，
    T_cap=Σ_{i∈I_cap}q_i，T_cup=Σ_{i∈I_cup}q_i。

其所有 targets 共用同一个 key，当且仅当 I_cup 过程的最早 k 个事件全部来自 I_cap。因此严格有

    P(所有 j∈G 共 key)=(T_cap/T_cup)^k。           (COALESCE)

在“固定 G 共 key”这个事件下，key 来源 labels 是 iid q_i/T_cap，时间是 Gamma(k,T_cup)。但是进一步条件化为“G 恰为最终最大 key 组”，会引入其他 targets 的排除事件；不能再无条件使用这个 iid 律。

## 6. 真实 admission 可以放进同一个最大半径代表

定义抽样前固定的低前负载集

    L_h={x:Σ_{i<h}q_i1_{A_i}(x)≤1}。

R661 admission 给每个 x∈X_j：Σ_{i<j}q_i1_{A_i}(x)≤Σ_{i<j}w_i1_{A_i}(x)≤1。组内 j≥h，故

    X_j⊂L_h，j∈G。

所以可以将组的辅助覆盖收紧为

    H_h(tuple)=[K(tuple)+Q(0,c0s_h)]∩L_h，
    Φ_h(tuple)=|H_h(tuple)|。                        (ADM-HALO)

它覆盖整组真实 losses，不声称覆盖整个 receiver union。L_h 随 h 单调递减，完全由同一次实际 q 固定；不使用新的源、不重优化所有权，也不把低前负载条件当作抽样后独立事件。

令随机组价格为

    C_k=Σ_实际key组G Φ_{h(G)}(key(G))。

则每次 realization 都有 V_near≤C_k。取所有 H_h 的并集只会进一步降低这个价格。

## 7. k 重 Mecke 的确切补偿式

以下 tuple 为有序来源 labels，允许同一原来源重复，因为插入的是不同时间的实际事件。令 ξ_t 为独立 Palm 背景，来源 i 的计数为 Poisson(tq_i)。对固定 tuple 定义存活 targets

    S(tuple,ξ_t)={j:所有 tuple labels 属于 I_j，ξ_t(I_j)=0}。

若该集合非空，取其原顺序最早行 h；令 Φ(tuple,ξ_t)=Φ_h(tuple)，否则为0。这里“背景为零”不包含插入的 k 个事件：插入事件恰是 key，其他事件才是 ξ_t。

固定终止时间 t 后，前 k−1 个插入时刻在 0<t_1<…<t_{k−1}<t 的单纯形中积分，体积为 t^(k−1)/(k−1)!。几何价格和 key 组成员只依赖 tuple、t 和背景是否有其他入射事件，不依赖这些较早插入时刻。于是

    E C_k
      =1/(k−1)! Σ_{i_1,…,i_k}(∏_l q_{i_l})
           ∫_0^∞ t^(k−1) E Φ(tuple,ξ_t) dt。        (MECKE)

所有同时存活 targets G 的背景空缺概率为

    P(ξ_t(I_j)=0 对全部 j∈G)=exp(−t T_cup)。

这是真实的联合 union-rate 惩罚。把它拆成每个 target 各自的 exp(−tT_j) 再求和，会丢掉要控制的跨组重用。

更明确地，令 π_h(tuple,t) 是 S(tuple,ξ_t) 最早行恰为 h 的概率。它包含同一背景下所有更早兼容 target 不存活的条件，因此

    0≤π_h≤exp(−tT_h)，Σ_hπ_h≤1。

对 tuple⊂I_h，定义

    ρ_h(tuple)=T_h^k/(k−1)!∫_0^∞t^(k−1)π_h(tuple,t)dt。

于是 0≤ρ_h≤1，且 MECKE 等价于

    E C_k=Σ_h E_{tuple iid q/T_h on fixed I_h}
                      [Φ_h(tuple)ρ_h(tuple)]。      (PRICE)

这里 T_h 始终是抽样前固定 I_h 的原始 rate，绝不是背景 ξ_t 之后“幸存来源”的随机 rate。ρ_h 是在 Gamma(k,T_h) 时间、条件 ξ_t(I_h)=0 下，没有更早兼容 target 存活的概率平均；它一般依赖 tuple。

这个公式允许来源重用，但把重用和代表选择放进同一个 joint law。没有要求逐来源重复系数分别有界。

## 8. 与局部 iid 交集矩候选的可接与不可接处

当前 Astra 局部候选（独审流程由主代理负责）针对固定真实共点源 I、固定 r、T=Σ_Iq_i，以及未经过代表选择的 iid law q_i/T，给

    M=E|∩_{l=1}^k A_{i_l}+c0r B∞|
      ≤U_I exp(100n/k−T/8)，

条件包括 T≥8192√n、k≥2T/c。它的 T 是固定原始源 rate。

若要统一满足这个条件，可以在新一轮实际 residual 构造中固定 τ=16384√n、k=ceil(2τ)；这需要按该 τ 重新生成同一次实际 q、F、X、z，不能仅把旧 τ=8√n 的符号替换而沿用旧解。first-key 律本身对任意固定 τ、k 都合法，不受 Poisson(1) 高计数概率限制。

对每个固定 h，ADM-HALO 只缩小无条件交集 halo，所以若局部候选通过，可用 ρ_h≤1 丢掉代表条件，得到

    E[Φ_hρ_h]≤EΦ_h≤U_h exp(100n/k−T_h/8)。

但把这些上界相加正是尚未支付的 Σ_h U_h。也不能写成 E[Φ_hρ_h]≤(EΦ_h)(Eρ_h)：代表选择和 tuple 几何有关，通常没有独立性或已证负相关。条件为最终最大 key 组时直接调用固定 I 的 iid 结论，同样存在选择偏差。

因此局部交集矩可以进入 PRICE 的单个固定 h 项，但目前没有证明保留 ρ_h 与 L_h 后，其全部加权总和≤A U。

## 9. 可进一步避免空间重复，但仍无总价界

可以将每个实际组的 ADM-HALO 在其 key 完成时加入同一个辅助并集 Ω_t。已完成 key 的组成员以后不会增加：若另一个 target 的 first key 真是同一组 k 个过去事件，它在该终止时刻已经完成。因此 Ω_t 单调增长，Ω_∞ 覆盖全部真实 near losses。

把每个 x 只归给首次进入 Ω_t 的到达事件，令 Δ_i^adm(η_{<t}) 为在时间 t 追加来源 i 的一个标记所新增的实际区域。Poisson 补偿严格给

    E|Ω_∞|=Σ_i q_i∫_0^∞ E|Δ_i^adm(η_{<t})|dt
           ≤E C_k。                                (FIRST-BIRTH)

这个式子每个空间点只计一次，保留所有共同 witness、原来源顺序和 admission。若直接在 k 重 Mecke 中使用“可见新增区域”，它一般依赖较早插入时刻；不能再无条件把这些时刻积分简化为 t^(k−1)/(k−1)!。

目前未证明 PRICE 的总和或更小的 FIRST-BIRTH 总费用≤A U。冻结的下一步仍是同一全局 void 桥：利用真实 L_h 与 union-rate 空缺相关性控制联合价格，不能丢代表偏差、逐组更新 U_h 后重复收费。新增局部矩界不因此成为一般弱型改进。

审稿记号补充：上文 C_k 即 W_sum=Σ_keys |halo_key∩L_h|，而 |Ω_∞| 即 W_union=|∪_keys(halo_key∩L_h)|。MECKE/PRICE 给 W_sum；FIRST-BIRTH 给 W_union。原始恢复只需要 E W_union≤A U。E W_sum≤A U 是较强的可选充分目标，本文件没有要求它必然成立；跨组实际覆盖重叠的节省应优先在 FIRST-BIRTH 中保留，不能因为 sum 公式容易写就无代价丢掉。
