# R662 independent numerical and model audit

**Verdict: the stated finite annular-grid source model, its parameter certificates, the intended sampling law, and the saved logarithmic sample summaries pass this bounded audit.** The computations are usable as finite-model diagnostics. They do not certify an expectation or tail bound for expanded intersection volume, R661 admission, target losses, a counterexample, or the desired dimension theorem.

I read TASK.md, NUMERIC.md, intersection_probe.py, and intersection_results.json. I independently wrote independent_numeric.py/json; no producer functions were imported. Only these two files and this report were written, with no edits to others' files and no Git operation. No sample population was enlarged: only four already-saved first observations were replayed, one per dimension.

## 1. Actual finite cubes and receivers

Let a=32n, rho=(a-2)/a, and r_l=rho^(-(l-1)). At layer l, each index vector j in {0,...,a-1}^n has receiver center

y_l(j)_v=r_l[(2j_v+1)/a-1].

The receiver B_lj has radius r_l/a, and its full parent A_lj has radius r_l. These are genuine axis-parallel common-radius cubes. The a^n receivers tile Q(0,r_l) up to boundaries. The indices with every coordinate in {1,...,a-2} tile the inner cube Q(0,rho r_l). Keeping vectors having at least one coordinate 0 or a-1 therefore leaves exactly the outer annulus, with

N_ring=a^n-(a-2)^n

labels per layer, not a^n kept labels. Because rho r_l=r_(l-1) for l>=2, successive annuli meet only on null boundaries. Their small receivers are disjoint in positive volume both within and across layers. Hence E_i=F_i=B_i is legitimate for this source-only family.

Every w_i=|B_i|/|A_i| equals q_i=a^-n. A layer has total q-load

N_ring a^-n=1-rho^n,

and the entire family has T=K(1-rho^n). All its parents contain the origin strictly; in fact they all contain Q(0,1/a), because each parent has coordinate margin at least r_l/a>=1/a about zero. Thus the maximum full-space source load is **exactly T**, achieved on a positive-volume common intersection. Any prefix load is <=T. When T<=tau=8sqrt(n), the residual recursion retains q=w for every source in any order, including radius-descending order: a new row's earlier-load supremum plus its w cannot exceed the total T.

The true source cost is

U=sum_i |F_i|=sum_l[(2r_l)^n-(2rho r_l)^n]
 =(2r_K)^n-(2rho)^n.

The smallest radius is one, so the full radius ratio is r_K. The saved parameters all have r_K<n. These identities describe the actual full receiver volumes, rather than an abstract incidence graph or an atomic source surrogate.

This does **not** establish the earlier R661 admission scan's separate past-raw-load<=1 contract on the E_i. The residual threshold tau is much larger than 1, and satisfying it is insufficient to infer that admission condition. Nor does this source-only model construct any rejected/lost target rows: all the displayed source rows are retained.

## 2. Independent rigorous parameter check

I recomputed rho and layer load exactly with integers/Fraction. All recorded n are perfect squares, so tau is an integer. K is verified by the exact integer comparisons

K N_ring <= tau a^n < (K+1) N_ring.

This proves the floor without a floating floor decision. Separately, 256-bit Arb independently recomputed r_K and log U, using

log U = n[log2+log r_K]+log[1-exp(n(log rho-log r_K))].

Each independent rho, layer load, T, tau, r_K, and log U interval is contained by its saved 192-bit enclosure. K, T<tau, and r_K<n all pass. The intended rounded k values are also rigorously inside their nearest-integer bins when T/2,T,2T are evaluated by interval arithmetic.

| n | K | T (approximate) | tau | r_K (approximate) | saved k values |
|---|---|---|---|---|---|
| 16 | 527 | 31.98990346 | 32 | 7.83586321 | 16,32,64 |
| 64 | 1055 | 63.94948336 | 64 | 2.80050509 | 32,64,128 |
| 256 | 2112 | 127.97475077 | 128 | 1.67438140 | 64,128,256 |
| 1024 | 4225 | 255.98738022 | 256 | 1.29410634 | 128,256,512 |

The JSON preserves all independent interval enclosures and exact floor pass checks. Three-layer telescoping was additionally tested with Fraction at each recorded n. The general telescoping identity follows from rho r_l=r_(l-1). The n=16,64 records are pilots; n=256,1024 are in the stated n>=256 target range. None of these finite parameter tests supplies an all-n construction theorem.

## 3. Sampling law

For a uniformly chosen grid vector from {0,...,a-1}^n, the number M of boundary coordinates is Binomial(n,2/a). Conditional on M=m>0, a uniform subset of m coordinates, independent uniform choices from {0,a-1} on that subset, and independent uniform choices from {1,...,a-2} elsewhere give every outer-ring vector equal probability. Indeed, for any specified vector with m boundary coordinates,

P(M=m | M>0) / [C(n,m) 2^m (a-2)^(n-m)]
 =1/[a^n-(a-2)^n].

The code's first-coordinate draw followed by uniform duplicate rejection produces a uniform ordered selection of distinct coordinates; forgetting order gives the required uniform subset. Rejection here concerns repeated **coordinates within one source**, not repeated source labels across draws.

Every layer has the same N_ring labels and every label has the same q=a^-n. Therefore independent uniform layers followed by independent uniform ring vectors give each full label probability

1/(K N_ring)=q/T.

The code draws these sources **with replacement**. Whole labels can repeat; no global label-deduplication step is present, and removing repetitions would alter the intended iid law. The layer law is uniform, not weighted by receiver volume d_iq_i; the latter would be a different model.

The conditional Binomial pmf and cumulative probabilities in the producer are evaluated in floating point, and the pseudorandom generator has finite state/precision. Thus the mathematical distribution just proved is exact, while its executable sampler is a numerical Monte Carlo implementation. This audit does not claim literal exact random sampling or certify the tiny far-tail probability rounding/underflow behavior.

As a small exact check of the distribution identity, the independent script enumerated the 252 ring labels for n=2,a=64 and verified each rational probability and their total one. This is only a check of the formula, not an additional high-dimensional probe.

## 4. Intersection, expansion, normalization, and bounded replay

For sampled parents, each coordinate of their intersection has endpoints

low_v=max_i(y_iv-r_i), high_v=min_i(y_iv+r_i).

The common origin makes high_v>0>low_v. Expanding this intersection by the axis-parallel cube Q(0,c0), c0=1+1/a, gives coordinate width high_v-low_v+2c0. Hence the recorded observable is exactly the floating evaluation of

Y=log(|(intersection_i A_i)+Q(0,c0)|/U)
 =sum_v log(high_v-low_v+2c0)-log U.

The expansion radius is c0 in units of the model's smallest radius r_1=1. There is no extra r_K multiplier. This is cube expansion; it is not expansion by a Euclidean or L1 ball. For these nonempty boxes, expanding each coordinate endpoint has the stated exact product-volume formula.

I replayed only rep=0,j=0 of the existing saved run for each dimension, with its saved seed. The independent replay used exact Fraction conditional-Binomial CDF comparisons instead of SciPy's floating pmf, and a scalar coordinate-extrema computation instead of the producer's NumPy max/min reductions. All four saved Y values agree to within about 1.2e-13. This uses no new draw population and does not rerun all 256 observations.

The n=16 first observation additionally received full exact-input 256-bit Arb geometry, with enclosure

[-29.5500195404751561799674318295233090549615675631149138453240135739695658928 +/- 4.42e-74].

Its saved floating value differs by less than 10^-10. This single interval check validates the observable's implementation; the remaining Monte Carlo observations are still floating computations, not rigorous per-observation interval certificates.

## 5. What the saved statistics do and do not establish

The saved file has exactly 12 cases and 256 values per case, total 3072 existing observations. I independently recomputed each case's mean, unbiased sample variance (denominator 255), sample standard deviation, empirical standard error (standard deviation/16), extrema, and linearly interpolated 50/90/99 percentiles. Every saved summary agrees within numerical tolerance.

All these are statistics of **Y, the logarithm of the volume ratio**. In particular:

- mean(Y) is not log E[exp(Y)] and does not estimate E[exp(Y)] by exponentiating it.
- The unbiased sample variance concerns Y under the ideal iid sampling interpretation; it is not a proven variance bound for the volume ratio.
- The reported standard errors are empirical estimates, not certified population errors or rigorous confidence intervals.
- The observed maxima and negative sampled Y values do not bound unobserved events, expectations, or tails. Rare large volume-ratio events may be missed and may have disproportionate expectation cost.

The calculations can support comparison of sampled typical logarithmic intersection sizes and their dispersion in this concrete source model. They cannot close an expected-volume estimate or a high-dimensional order statement. No expectation proof is inferred from absence of rare values in 256 observations.

## 6. Reproduction and final scope

Run from this directory:

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python independent_numeric.py

The final run used Python 3.12.14, NumPy 2.5.4, python-flint 0.9.0, one process, one Arb thread and BLAS limits one. Recorded audit wall time was about 0.1721 s and CPU time about 0.1523 s. No SciPy scan was run by the audit. SHA-256 hashes for TASK.md, NUMERIC.md, producer source/results and independent source are stored in independent_numeric.json. The producer source hash matches its saved result field.

The model is a valid real finite cube source family with disjoint full receivers and retained residual weights. Its finite parameter certificates are usable, and the saved Monte Carlo summaries are reproducible diagnostics of the stated logarithmic observable. R661 admission, target saturation/loss contracts, rigorous intersection-volume expectation/tail control, and the full-family dimension theorem remain unestablished by this computation.
