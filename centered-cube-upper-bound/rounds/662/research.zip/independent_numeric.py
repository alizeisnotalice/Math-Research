"""R662 independent model/interval audit. Four saved first samples replayed only.
No larger scan, no producer import, no new Monte Carlo sample population.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
    os.environ[key]='1'
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import math,json,hashlib,platform,time,resource
import numpy as np
import flint
from flint import arb,ctx,fmpq
P=Path(__file__).resolve().parent
ctx.prec=256;ctx.threads=1
start=time.monotonic();cpu0=resource.getrusage(resource.RUSAGE_SELF)
d=json.loads((P/'intersection_results.json').read_text())
assert hashlib.sha256((P/'intersection_probe.py').read_bytes()).hexdigest()==d['sha256']
assert d['precision_bits']==192 and d['workers']==1
assert d['seed_formula']=='662000+10*n+j, j=0,1,2'
assert [g['n'] for g in d['geometry']]==[16,64,256,1024]
assert len(d['cases'])==12

def aa(v):
    v=F(v);return arb(fmpq(v.numerator,v.denominator))
def contained(saved,value):assert arb(saved).contains(value)
def close(x,y):assert abs(x-y)<=1e-10*max(1,abs(x),abs(y))

def geometry(g):
    n=g['n'];a=32*n;tau=8*math.isqrt(n);assert math.isqrt(n)**2==n
    an=a**n;interior=(a-2)**n;ring=an-interior
    # Exact rational floor and exact load comparisons; no floating floor decision.
    K=(tau*an)//ring
    assert K==g['K'] and K*ring<=tau*an<(K+1)*ring
    rho=F(a-2,a);t=F(ring,an)
    assert t==1-rho**n
    rr=aa(rho);rm=rr**(-(K-1));T=K*aa(t)
    # Use a distinct log-domain evaluation of telescoping volume.
    logR=-(K-1)*rr.log()
    logU=n*(arb(2).log()+logR)+(1-(n*(rr.log()-logR)).exp()).log()
    assert 1<rm<n and T<=tau
    for key,value in [('rho',rr),('T_layer',aa(t)),('T',T),('tau',arb(tau)),('rmax',rm),('logU',logU)]:contained(g[key],value)
    assert g['K_floor_certified'] and g['T_le_tau'] and g['rmax_less_n']
    # Identity for layer shells and receiver cost, checked with exact rationals
    # at the first three scales; the general identity is algebraic.
    radii=[rho**(-j) for j in range(3)]
    assert radii[0]==1 and all(rho*radii[j]==radii[j-1] for j in (1,2))
    assert sum((2*r)**n-(2*r*rho)**n for r in radii)==(2*radii[-1])**n-(2*rho)**n
    return {'n':n,'a':a,'rho_exact':str(rho),'ring_count_formula':f'{a}^{n}-({a}-2)^{n}','q_exact_formula':f'{a}^(-{n})','K':K,'floor_exact':True,'T_layer':str(aa(t)),'T':str(T),'tau':tau,'load_gap':str(arb(tau)-T),'rmax':str(rm),'rmax_less_n':True,'logU':str(logU),'all_A_contain_Q0_1_over_a':True,'max_source_load_exact':'T','three_layer_exact_telescope_checked':True}

geoms=[geometry(g) for g in d['geometry']]
# Exact compressed conditional distribution identity, plus actual enumeration of
# the tiny n=2,a=64 ring (252 labels; used only to validate the sampling formula).
n0=2;a0=64;ring0=a0**n0-(a0-2)**n0
uniform=F(1,ring0);enumerated=0;total=F(0)
for vec in product(range(a0),repeat=n0):
    m=sum(i in (0,a0-1) for i in vec)
    if not m:continue
    pm=F(math.comb(n0,m)*2**m*(a0-2)**(n0-m),ring0)
    pvec=pm/F(math.comb(n0,m)*2**m*(a0-2)**(n0-m))
    assert pvec==uniform
    total+=pvec;enumerated+=1
assert enumerated==ring0==252 and total==1

summaries=[]
for idx,c in enumerate(d['cases']):
    n=c['n'];g=d['geometry'][idx//3];assert n==g['n']
    mult=(F(1,2),F(1),F(2))[idx%3]
    expected_k=round(g['T_float']*float(mult))
    assert c['k']==expected_k and c['reps']==256 and len(c['values'])==256
    exact_target=arb(geoms[idx//3]['T'])*aa(mult)
    assert aa(F(2*c['k']-1,2))<exact_target<aa(F(2*c['k']+1,2))
    values=c['values'];assert all(math.isfinite(x) for x in values)
    mean=math.fsum(values)/256
    var=math.fsum((x-mean)**2 for x in values)/255
    sd=math.sqrt(var);se=sd/16
    for key,value in [('mean',mean),('sample_variance',var),('sample_std',sd),('standard_error',se),('min',min(values)),('max',max(values))]:close(c[key],value)
    ss=sorted(values)
    for prob,saved in zip((.5,.9,.99),c['quantiles_50_90_99']):
        at=255*prob;k=int(at);fraction=at-k
        close(saved,ss[k]+fraction*(ss[min(k+1,255)]-ss[k]))
    summaries.append({'n':n,'k':c['k'],'reps':256,'saved_summaries_verified':True,'observable':'log(|intersection(A_samples)+Q(0,1+1/a)|/U)','mean_log':mean,'variance_log_ddof1':var,'standard_error_log_empirical':se})

# Replay only sample zero of j=0 for each saved dimension using the same RNG
# calls, but exact conditional-Binomial comparisons instead of scipy.stats.
replays=[]
for ix,g in enumerate(d['geometry']):
    n=g['n'];a=32*n;k=d['cases'][3*ix]['k'];K=g['K'];rng=np.random.default_rng(662000+10*n)
    layer=rng.integers(0,K,k)
    ind=rng.integers(1,a-1,size=(k,n),dtype=np.int32)
    uniforms=rng.random(k)
    ring=a**n-(a-2)**n
    pm=F(n*2*(a-2)**(n-1),ring);cdf=pm;mass=[cdf]
    while cdf<F.from_float(float(max(uniforms))):
        m=len(mass);pm*=F((n-m)*2,(m+1)*(a-2));cdf+=pm;mass.append(cdf)
    bc=np.array([next(m+1 for m,cut in enumerate(mass) if F.from_float(float(u))<cut) for u in uniforms])
    first=rng.integers(n,size=k)
    ind[np.arange(k),first]=rng.choice(np.array([0,a-1],dtype=np.int32),size=k)
    for i in np.flatnonzero(bc>1):
        taken={int(first[i])}
        while len(taken)<bc[i]:
            col=int(rng.integers(n))
            if col not in taken:
                taken.add(col);ind[i,col]=0 if rng.integers(2)==0 else a-1
    assert all(sum(int(j) in (0,a-1) for j in row)==int(m) for row,m in zip(ind,bc))
    lr=-math.log(1-2/a);scales=np.exp(layer*lr)
    # Compute coordinate extrema in a scalar loop, independent of producer's
    # NumPy max/min reductions. Full-source labels are sampled with replacement.
    low=[];high=[]
    for coord in range(n):
        intervals=[(float(r)*(float(2*int(ind[i,coord])+1)/a-2),float(r)*(float(2*int(ind[i,coord])+1)/a)) for i,r in enumerate(scales)]
        low.append(max(lo for lo,hi in intervals));high.append(min(hi for lo,hi in intervals))
    assert all(lo<0<hi for lo,hi in zip(low,high))
    c0=1+1/a
    logvalue=math.fsum(math.log(hi-lo+2*c0) for lo,hi in zip(low,high))-g['logU_float']
    saved=d['cases'][3*ix]['values'][0];close(logvalue,saved)
    record={'n':n,'j':0,'rep':0,'seed':662000+10*n,'k':k,'saved_log_value':saved,'independently_replayed_log_value':logvalue,'boundary_counts_from_exact_conditional_CDF':True,'max_boundary_count_in_this_replay':int(max(bc))}
    # One tiny recorded sample gets full exact-input interval geometry as well.
    if n==16:
        rho=F(a-2,a);radii=[aa(rho)**(-int(j)) for j in layer];c=aa(F(a+1,a))
        bits=[]
        for coord in range(n):
            lows=[r*aa(F(2*int(ind[i,coord])+1-2*a,a)) for i,r in enumerate(radii)]
            highs=[r*aa(F(2*int(ind[i,coord])+1,a)) for i,r in enumerate(radii)]
            lo=lows[0];hi=highs[0]
            for x,y in zip(lows[1:],highs[1:]):
                lo=(lo+x+abs(lo-x))/2;hi=(hi+y-abs(hi-y))/2
            assert lo<0<hi
            bits.append((hi-lo+2*c).log())
        exact_log=sum(bits)-arb(geoms[ix]['logU'])
        assert abs(exact_log-aa(F.from_float(saved)))<aa(F(1,10**10))
        record['true_rational_model_log_Arb']=str(exact_log)
        record['saved_float_error_less_than']='1e-10'
    replays.append(record)

r1=resource.getrusage(resource.RUSAGE_SELF)
out={'pass':True,'source_hash_matches':True,'model':'actual finite annular-grid full cube parents and disjoint small receivers','geometry':geoms,'sampling_identity':'P(index vector|outer ring)=1/[a^n-(a-2)^n]; uniform layers give each label q/T','small_exact_enumeration':{'n':n0,'a':a0,'ring_labels':enumerated,'total_probability':'1'},'sampling_with_replacement':True,'summary_checks':summaries,'saved_first_sample_replays':replays,'new_MC_samples':0,'independent_precision_bits':256,'source_precision_bits':192,'limitations':['R661 admission not established','no losses or target admission certified','mean/variance/SE concern the logarithm, not the volume ratio','no rigorous expectation/tail or high-dimensional order bound from MC','n16,64 are pilots only'],'versions':{'python':platform.python_version(),'numpy':np.__version__,'python_flint':flint.__version__},'workers':1,'blas_threads':1,'wall_seconds':time.monotonic()-start,'cpu_seconds':r1.ru_utime+r1.ru_stime-cpu0.ru_utime-cpu0.ru_stime,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python independent_numeric.py','sha256':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ('TASK.md','NUMERIC.md','intersection_probe.py','intersection_results.json','independent_numeric.py')}}
(P/'independent_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('summary_checks',)},indent=2))
