"""R662 archival checks and optional non-overwriting numerical replay."""
from pathlib import Path
import ast,hashlib,json,re,sys,subprocess,tempfile,shutil,os
P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest.json').read_text())
for name,meta in manifest['files'].items():
    b=(P/name).read_bytes()
    assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'],name
    assert not (name.endswith('.pdf') or '__pycache__' in name)
    if name.endswith('.py'):ast.parse(b.decode(),filename=name)
tex=(P/'REPORT.tex').read_text()
assert not any(ord(c)<32 and c not in '\n\r\t' for c in tex)
stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
    if m[1]=='begin':stack.append(m[2])
    else:assert stack and stack.pop()==m[2],m[0]
assert not stack
review=(P/'FINAL_REVIEW.md').read_text()
assert manifest['files']['REPORT.tex']['sha256'] in review
old=json.loads((P/'independent_numeric.json').read_text())
for name,h in old['sha256'].items():
    b=(P/name).read_bytes()
    if name=='NUMERIC.md':b=b[:1993]
    assert hashlib.sha256(b).hexdigest()==h,name
for script,data in [('intersection_probe.py','intersection_results.json'),('scalar_probe.py','scalar_results.json')]:
    assert hashlib.sha256((P/script).read_bytes()).hexdigest()==json.loads((P/data).read_text())['sha256']
if '--replay' in sys.argv:
    parent=Path('/Volumes/data/CodexTemp')
    assert parent.is_dir(),'Required data volume/temp directory unavailable'
    work=Path(tempfile.mkdtemp(prefix='r662-replay-',dir=parent))
    for name in ('TASK.md','NUMERIC.md','intersection_probe.py','intersection_results.json','independent_numeric.py','scalar_probe.py'):
        shutil.copy2(P/name,work/name)
    env=os.environ.copy()
    for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):
        env[k]='1'
    def math_only(x):
        if isinstance(x,dict):return {k:math_only(v) for k,v in x.items() if k not in ('wall_seconds','cpu_seconds','sha256')}
        if isinstance(x,list):return [math_only(v) for v in x]
        return x
    for script,data in [('independent_numeric.py','independent_numeric.json'),('scalar_probe.py','scalar_results.json')]:
        r=subprocess.run([sys.executable,str(work/script)],cwd=work,env=env,text=True,capture_output=True)
        assert r.returncode==0,(script,r.stderr,r.stdout)
        (work/(script+'.stdout.txt')).write_text(r.stdout)
        archived=json.loads((P/data).read_text());fresh=json.loads((work/data).read_text())
        assert math_only(archived)==math_only(fresh),data
        hashes=fresh['sha256']
        if isinstance(hashes,dict):
            for name,h in hashes.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==h,name
        else:assert hashes==hashlib.sha256((work/script).read_bytes()).hexdigest()
        print('REPLAY PASS',data)
    print('Non-overwriting replay directory:',work)
print('PASS: hashes, scope metadata, Python syntax, TeX environments, final review binding; no PDF compiled.')
