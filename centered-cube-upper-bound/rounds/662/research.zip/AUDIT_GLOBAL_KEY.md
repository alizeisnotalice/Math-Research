# R662：全局 first-key / Mecke / admission 联立审计

日期：2026-11-15。已先独立推导，再核对 `SOFT_JOINT_PRICE.md` 新增第5–9节。

**结论：真实 first-key 分组、共同 key 概率、Mecke 总价恒等式、Gamma/代表核及 FIRST-BIRTH 均通过；局部矩界可用于固定代表项，但尚不能支付全局 source reuse。** 必须在同一积分中同时保留代表选择与 admission 限制，不能把小的局部因子乘上未经控制的 \(\sum_hU_h\) 后称闭合。

本文采用主代理最终参数：在完整输入上以
\[
\tau=16384\sqrt n,\qquad k=\lceil2\tau\rceil
\]
重新运行同一真实 admission/residual 构造，得到实际 \(q,F,X,z,I_j\)。不能只改旧 \(\tau=8\sqrt n\) 的符号而保留旧解。\(a=32n,c_0=1+1/a,c=c_0^n\)。固定所有这些数据后才抽样。

## 1. key 及概率：PASS；必须保留完整事件

来源 \(i\) 使用相互独立、速率为实际 \(q_i\) 的时间 Poisson 过程，所有 targets 共用同一过程。对 target \(j\)，从固定 \(I_j\) 取最早 \(k\) 个事件，按时间排序，保留每个事件的来源 label 和时间。允许 label 重复，但事件本身不同；连续时间保证 a.s. 不同事件不同时到达。

\(T_j=\sum_{i\in I_j}q_i>\tau/2>0\)，故每个 key 的完成时间 a.s. 有限。targets 有限，所有 key 的最大完成时间也 a.s. 有限；无限时间版本没有未覆盖 target，也没有有限时间高计数失败项。不能改回 \([0,1]\) 后忘记未完成 losses。

对预先固定的非空 target 族 \(G\)，写 \(T_\cap=\sum_{\cap_{j\in G}I_j}q_i\)、\(T_\cup=\sum_{\cup_{j\in G}I_j}q_i\)。所有 target 共用 key 当且仅当 union 过程的前 \(k\) 个事件全部来自 intersection，故
\[
\Pr(\text{全部 }j\in G\text{ 共 key})=(T_\cap/T_\cup)^k.
\tag{1}
\]
这是“\(G\) 中所有行共 key”的概率，不是“最终完整 key 组恰等于 \(G\)”的概率；后者还需排除外部 targets。若只按 label multiset 合并、丢去事件时间身份，(1) 及下面的一组一次计价不再是同一个模型。

## 2. 最大半径、最早代表与真实低前负载：PASS

原顺序半径非增。每个实际 key 组取最早行 \(h\)，它也具有最大 target 半径 \(r_h=s_h\)，并按同一顺序解决半径 ties。令
\[
K(\boldsymbol i)=\bigcap_{\ell=1}^k A_{i_\ell},\qquad
D_h(\boldsymbol i)=K(\boldsymbol i)+Q(0,c_0r_h),
\]
\[
\mathcal L_h=\left\{x:\sum_{i<h}q_i\mathbf1_{A_i}(x)\le1\right\},
\qquad \phi_h(\boldsymbol i)=|D_h(\boldsymbol i)\cap\mathcal L_h|.
\]
每个组员的实际 \(z_j\in K\)，且 \(r_j\le r_h\)，所以整个 \(B_j\subset D_h\)。另一方面，仅真实 losses 满足
\[
X_j\subset E_j,\quad
\sum_{i<h}q_i\mathbf1_{A_i}\le
\sum_{i<j}w_i\mathbf1_{A_i}\le1\quad\text{a.e. on }X_j,
\]
因为 \(j\ge h\)。因此 \(X_j\subset D_h\cap\mathcal L_h\) a.e.。

不能声称整个 \(B_j\subset\mathcal L_h\)。\(\mathcal L_h\) 是抽样前由同一实际 \(q\) 固定的集合，不是独立随机事件；它随 \(h\) 单调递减。重复 labels 不增加新的来源片，\(K\) 中重复交集仅重复写同一个 \(A_i\)。

令
\(C_k^{\rm adm}=\sum_{\text{实际非空 key 组 }G}\phi_{h(G)}(key(G))\)。每次 realization 都有
\[
V_{\rm near}=\left|\bigcup_{j\ \rm near}X_j\right|
\le C_k^{\rm adm}.
\tag{2}
\]
这是完整 near loss 的覆盖，不是仅固定一个 target 的概率覆盖。

## 3. 精确 Mecke 系数及 Fubini：PASS

给定有序来源 tuple \(\boldsymbol i=(i_1,\ldots,i_k)\) 和独立 Palm 背景 \(\eta_t\)，各来源背景计数为 \(\operatorname{Poisson}(tq_i)\)。令
\[
S(\boldsymbol i,\eta_t)=\{j:\ i_\ell\in I_j\ \forall\ell,
\quad\eta_t(I_j)=0\}.
\]
空集合取价格零；否则令 \(h=\min S\)，取价格
\(\Phi(\boldsymbol i,\eta_t)=\phi_h(\boldsymbol i)\)。背景计数不包括插入的 \(k\) 个 key 事件。

固定终止时刻 \(t\)，前 \(k-1\) 个插入时刻满足
\(0<t_1<\cdots<t_{k-1}<t\)。组成员及上述价格不依赖这些较早时刻的具体值，其单纯形体积为 \(t^{k-1}/(k-1)!\)。因此
\[
\boxed{
\mathbb E C_k^{\rm adm}
=\frac1{(k-1)!}\sum_{i_1,\ldots,i_k}\Bigl(\prod_{\ell=1}^kq_{i_\ell}\Bigr)
\int_0^\infty t^{k-1}\mathbb E\Phi(\boldsymbol i,\eta_t)\,dt.}
\tag{3}
\]
有序 labels 允许重复；不能只求不同 label tuples，也不能再额外除以 \(k!\) 或重复次数阶乘。插入的是不同 marked points，同一来源可产生多个。有限窗口中的 Poisson 阶乘计数直接给该公式；窗口增大到无穷用非负单调收敛。

所有量非负，Tonelli 合法。价格还确实有限：有限输入给出统一有限 halo 体积上界 \(D_*\)，每 realization 至多有 target 数那么多个非空组，因此 \(C_k^{\rm adm}\le mD_*\)。亦可在右端用
\(\mathbb E\Phi\le D_*\sum_{j:\boldsymbol i\subset I_j}e^{-tT_j}\)
及 Gamma 积分得到相同有限界。

## 4. Gamma / rho 精确式：保留选择偏差

记 \(\pi_h(\boldsymbol i,t)=\Pr(h=\min S(\boldsymbol i,\eta_t))\)。对 \(\boldsymbol i\subset I_h\)，
\[
0\le\pi_h\le e^{-tT_h},\qquad
\rho_h(\boldsymbol i)=\frac{T_h^k}{(k-1)!}
\int_0^\infty t^{k-1}\pi_h(\boldsymbol i,t)\,dt\in[0,1].
\]
等价地，\(\rho_h\) 是在 \(t\sim\operatorname{Gamma}(k,T_h)\)、条件背景 \(\eta_t(I_h)=0\) 下，没有更早兼容 target 存活的概率平均。更早 \(\ell<h\) 若兼容该 tuple，需
\(\eta_t(I_\ell\setminus I_h)>0\)。这些排除事件共享背景，**不能相互独立地相乘**。

(3) 精确改写为
\[
\boxed{
\mathbb E C_k^{\rm adm}
=\sum_h\mathbb E_{\boldsymbol i\ \mathrm{iid}\ q_i/T_h\ {\rm on}\ I_h}
\left[\,|D_h(\boldsymbol i)\cap\mathcal L_h|\,
\rho_h(\boldsymbol i)\right].}
\tag{4}
\]
\(T_h\) 始终是抽样前固定原源 rate；当 \(h\) 存活时整个 \(I_h\) 都满足背景为空，所以不能说它被随机删到更小的负载。对任意另选的预定 anchor 删背景来源则是另一合同，不得混用。

\(\sum_h\pi_h\le1\) 对固定 tuple、\(t\) 正确，但不自动推出 \(\sum_h\rho_h\le1\)：不同 \(T_h\) 的归一和无穷时间积分仍在。按最终代表选择后的 tuple 律受到 \(\rho_h\) 偏置，不能继续称其无偏 iid。

## 5. 新局部矩定理的接口：可进入单项，不能免费总付

按主代理已独审通过的固定 anchor 局部版本，输入须是实际不交 \(F_i\)、共点源 \(I_h\)、\(r_h\le s_i\le nr_h\)、固定 \(T_h\)、有放回 iid tuple，且 \(T_h\ge8192\sqrt n\)、\(k\ge2T_h/c\)。这里全部条件吻合：near 给 \(T_h>\tau/2\)，同一饱和点给 \(T_h\le\tau\)，且 \(k=\lceil2\tau\rceil\ge2T_h/c\)。

对 \(n<256\)，共点近尺度实源负载上界
\(T_h\le c(1+n\log n)\le2(1+8n)<8192\sqrt n\)，故新参数下 near 为空，不需调用局部矩定理。

对 \(n\ge256\)，局部界
\[
M_h=\mathbb E_{\rm iid}|D_h(\boldsymbol i)|
\le U_h\exp(100n/k-T_h/8)
\]
可合法用于 (4) 的一个固定 \(h\) 项，因为 \(\rho_h\le1\)、\(\mathcal L_h\) 只缩小集合。但由此只能得到
\[
\mathbb E C_k^{\rm adm}\le e^{-1000\sqrt n}\sum_hU_h.
\tag{5}
\]
这里 \(100n/k-T_h/8\le-(8388583/8192)\sqrt n<-1000\sqrt n\)。\(\sum_hU_h\) 含真实 source 重用，不能替成 \(U\)，也不能凭非常小的常数忽略任意有限族大小。

特别不能使用
\(\mathbb E[\phi_h\rho_h]\le(\mathbb E\phi_h)(\mathbb E\rho_h)\)：尚无所需独立或负相关。**当前未证的全局桥必须在 (3)/(4) 同一积分中保留 \(\rho_h\) 与 \(\mathcal L_h\)**；局部矩 PASS 不等于联合总价 PASS。

## 6. FIRST-BIRTH：PASS；需把同次全部新组加入一次

一个 key 完成时，其完整组成员可由到该时刻的历史确定。以后不能增加成员：若另一个 target 的 first key 就是这 \(k\) 个过去事件，它在同一终止时刻已经完成。因此每个已加入 halo 的代表及半径以后不变，辅助并集 \(\Omega_t\) 单调增长。

一次 arrival 可能同时完成多个不同 keys。\(\Delta_i^{\rm adm}(\eta_{<t})\) 必须定义为在来源 \(i\) 插入该一个事件后，**这次所有新完成组 halo 的联合并集，减去旧 \(\Omega_{t-}\)**，而不是只选其中一个组。于是它是过去历史与插入事件的可测函数，并有
\[
V_{\rm near}\le|\Omega_\infty|,\qquad
\mathbb E|\Omega_\infty|
=\sum_iq_i\int_0^\infty\mathbb E|\Delta_i^{\rm adm}(\eta_{<t})|\,dt
\le\mathbb E C_k^{\rm adm}.
\tag{6}
\]
该式每个空间点只付首次进入并集的成本，保留全部真实 source、admission 和同 key 条件。有限窗口补偿后单调收敛即可，非负且空间上有统一有界包络。

若将“新增可见区域”直接代入 \(k\)-Mecke，它通常依赖较早插入时刻，因为那些时刻会改变其他组何时先覆盖该点。必须保留这些时刻的积分，或另设 order-statistics 平均；不能无条件沿用 (3) 原 \(\Phi\) 的简单单纯形因子。

## 审计停止点及实际工具记录

通过的是随机对象、覆盖和补偿恒等式及局部合同接口；没有证明 (4) 或更小的 (6) 受绝对常数乘 \(U\) 控制。下轮唯一桥为利用真实低前负载和 union-rate 空缺相关性进行联合付款，不能丢代表偏差后逐组重新付 \(U_h\)。

已实际调用本机指定 Python/SymPy，仅核对 Gamma 归一恒等式严格为 \(1\)，及新参数局部指数的精确上界 \(-8388583\sqrt n/8192\)（比 \(-1000\sqrt n\) 多出 \(196583\sqrt n/8192\) 的负裕量）。没有数值或几何扫描；计算不替代上述全局审计证明。只写此文件、不改他人文件、不 Git。交付后停止等待。
