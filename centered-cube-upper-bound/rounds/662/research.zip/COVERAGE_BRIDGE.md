# R662：全局几何覆盖连接的独立核查

## 结论

没有获得全族 `V_near <= A U`，也没有获得新的维数阶上界。本分支保留冻结任务中的实际 `q_i`、真实不交 `F_i`、完整近尺度区间和所有 near receivers。以下只记录可转交的精确公式与未完成的全局步骤，不作为新增全局定理。

## 先独立尝试的几何选择

对 near 行 `j`，记 `U_j = sum_{i in I_j}|F_i|`。单锚累计体积的既有估计给

`U_j >= c (2s_j)^n exp(T_j/c - 1)`，其中 `T_j = sum_{i in I_j}q_i > tau/2`。

因此，以 `z_j` 为中心、半径量级为 `s_j` 的整块接收区域已经具有指数级局部体积折扣。尝试用这些区域直接覆盖全部目标，可以绕开“一个目标必须与某个旧锚点共享 tau/3”这一条件。但常规方体覆盖选择引入 `exp(O(n))`；仅将锚点改作 `l1` 分离，并不能消除这个损失：`l1` 球的体积有 `1/n!`，精确公式

`|Q(0,R)+D B1|/(2R)^n = sum_{k=0}^n binom(n,k)(D/R)^k/k!`

只给定一个局部域的外扩体积，并未控制同一真实来源参与多少个所选局部域。尤其不能把该外扩比直接当作来源重数。本次没有找到既覆盖全部目标、又将该来源重数收费压至 `exp(C n/tau)` 的几何选择。

## 可交给联合抽样方向的精确恒等式

固定一个真实锚族 `J`，全部 `A_i` 含同一个点，令

`T = sum_{i in J}q_i`，`0 < r <= min_{i in J}s_i`。

独立按概率 `q_i/T` 抽取 `k` 个实际来源 `i_1,...,i_k`，允许重复标签。对轴平行盒，因交集非空，逐坐标区间运算严格给出

`(intersection_{ell=1}^k A_{i_ell}) + r B_infinity = intersection_{ell=1}^k (A_{i_ell}+r B_infinity)`。

所以由 Tonelli，

`E |(intersection_{ell=1}^k A_{i_ell})+r B_infinity|`

`= integral [ (1/T) sum_{i in J} q_i 1_{A_i+r B_infinity}(x) ]^k dx`。

这保留了实际标签、实际不同尺度以及真实抽样概率；不需要均匀中心分布或单尺度假设。公式本身没有给出一般情形下的 `exp(C n/k)` 界。更重要的是，对各锚族分别使用这个恒等式、再求和，会重新引入跨锚来源费用，不能将其换成 `U`。

**准确未证步：** 需要在同一全局抽样或选择中，将全部 near receivers 实际分配到这些随机交集的扩张区域，并用同一组 `F_i` 支付所产生区域的联合体积。局部抽样量的期望恒等式和局部平行体折扣均未提供这一步；本分支没有构造出该分配及其真实总价上界。

## 一个已停止的放松（不计实际族反例）

若删除来源尺度标签，仅保留 `F = union_i F_i`，用

`K_r(u) = (2 max{r,||u||_infinity})^{-n} 1_{||u||_infinity <= nr}`

主宰负载，则其精确积分为 `||K_r||_1 = 1+n log n`。细周期、占比约 `tau/(n log n)` 的指示集可使该放松在大内部区达到 `tau`，相应 halo 与 `|F|` 的比可达 `n log n/tau` 量级。因此这个删除标签的放松不能给常数总账。它不保留每个实际来源的唯一半径，故不是冻结任务的反例，也不推翻目标估计。按主代理要求停止该路线。

本分支未运行数值搜索，没有把模型或数值当作证明。未修改其他人的文件，未执行 Git 操作。

---

# 继续任务：真实随机交集的一般体积估计

本追加节替代前文“未获得随机交集一般估计”的状态；前文关于**全局共同付款尚缺**的判断仍保留。以下不是全局覆盖定理，而是主代理再次指派的具体随机交集机制的局部一般估计。常数刻意取宽。

## 命题

令 `n>=256, a=32n, c0=1+1/a, c=c0^n`。真实有限源族 `I` 满足：所有 `A_i=Q(y_i,s_i)` 含同一点 `z`；`s_i>=r>0`；`F_i subset Q(y_i,s_i/a)` 真正两两不交；`|F_i|=(2s_i)^n q_i`。置

`T=sum_i q_i, U=sum_i |F_i|, L=log[U/(c(2r)^n)]`。

若 `T>=8192 sqrt(n)`，按 `q_i/T` 独立抽取 `k` 个真实标签，整数 `k>=2T/c`，则

**`E | intersection_{ell=1}^k A_{i_ell} + c0 r B_infinity | <= U exp(100 n/k - T/8)`。**

取 `k=ceil(2T/c)` 即有 `k` 与 `T` 同阶。证明没有使用 `s_i<=nr`，所以尤其适用于任务的全近尺度区间。没有假设来源中心均匀、坐标独立或所有来源同尺度。

## 1. 共点累积分布与最小抽样体积

令 `d_i=(2s_i)^n`，`H(u)=sum_{d_i<=u}|F_i|`。由真实不交及共点性，

`H(u)<=min(cu,U)`。

令 `Q(u)=sum_{d_i>u}q_i`。Stieltjes 分部积分（舍去非正的 `-H(u)/u`）给

`Q(u)<=c[1+log(U/(cu))]`，`0<u<=U/c`；

`Q(u)<=U/u`，`u>=U/c`。

特别有 `L>=T/c-1`。记 `theta=T/c`，`d_min=min_ell d_{i_ell}`，并令

`u0=(U/c) exp(1-theta)`。

抽样独立性给 `P(d_min>u)=(Q(u)/T)^k`。对 `0<alpha<=1`，在 `u0,U/c` 分段并置 `u=(U/c)e^(1-y)`，得到

`E d_min^alpha <= u0^alpha`

`+ alpha (U/c)^alpha e^alpha integral_{1}^{theta} e^(-alpha y)(y/theta)^k dy`

`+ [alpha/(k-alpha)](U/c)^alpha theta^(-k)`。

当 `k>=2theta, theta>=2` 时，中间被积函数的对数导数 `k/y-alpha>=1`，故该项至多 `alpha u0^alpha`。末项除以 `u0^alpha` 后至多

`[alpha/(k-alpha)] exp[alpha(theta-1)] theta^(-k)<=1`。

因此统一有

**`E d_min^alpha <=3u0^alpha`，`0<=alpha<=1`。**

`alpha=0` 的情形直接成立。任意交集都包含于抽中最小方体，故二项式展开给第一条一般体积界

**`M:=E |intersection A_{i_ell}+c0r B_infinity|`

`<= (3/c) U exp(1-theta) [1+c0 exp(-(L+1-theta)/n)]^n`。**  (A)

这里没有将最小方体的扩大比一律放成 `2^n`。

## 2. 去掉旧 `+c` 门槛的 lens 分布估计

写 `R=c0r`，

`G(x)=sum_i q_i 1_{A_i+R B_infinity}(x)`。

共点盒交非空，逐坐标区间运算及 Tonelli 给

`M=integral [G(x)/T]^k dx`。

对固定 `x` 令 `D_x=sum_m (|x_m-z_m|-R)_+`，并令 `H_x(s)` 为满足 `s_i<=s` 且 `x in A_i+R B_infinity` 的真实来源总体积。每个此类 `F_i` 同时位于

`Q(z,c0s) intersection Q(x,c0s+R)`，

所以

`H_x(s)<=min{U, c(2s)^n exp[-D_x/(2c0s)]}`。

精确层积分为 `G(x)=(n/2^n) integral_r^infinity H_x(s)s^(-n-1) ds`。对任意 `lambda>0`，取

`S=r exp(L_lambda/n), L_lambda=L+log(2c/lambda)`。

在非空超水平集 `G>=lambda` 上该切点合法；尾积分等于 `lambda/2` 的上界，前积分至多 `c L_lambda exp[-D_x/(2c0S)]`。于是

`D_x<=2c0r exp(L_lambda/n) log(2c L_lambda/lambda)`。

由方体加 `l1` 球的精确平行体系数，对 `lambda=T exp(-t), 0<=t<=n`，令 `A=n exp(L/n)`，使用 `T>=4c, L>=1`，有

**`|{G>=T exp(-t)}|`

`<=U exp[-L+2sqrt(2e A(log(2cL/T)+2t))]`。**  (B)

具体用到了 `L_lambda<=L+t`、`exp(t/n)<=e` 及 `log(1+t/L)<=t/L<=t`。

用 layer cake，分开 `t<=n` 和 `t>n`。前段再用

`4sqrt(e A t) <= (k/2)t+8e A/k`。

后段用 `integral G <=(1+c0)^n U`。得到第二条全参数一般估计

**`M<=2U exp[-L+2sqrt(2e A log(2cL/T))+8e A/k]`

`+ [k/(k-1)] (1+c0)^n (U/T) exp[-(k-1)n]`。**  (C)

这是保留实际不同尺度的估计，低超水平集没有被丢弃。

## 3. 拼接 (A) 与 (C)

以下只用 `1<=c<=2, 1<c0<=2, e<3`。假设 `theta>=4096sqrt(n)`；命题的 `T>=8192sqrt(n)` 保证此条件。

首先，若

`L>=theta-1+n log(4c0 n/theta)`，

则 (A) 中的额外对数至多 `theta/4`，故

`M<=(3/c)U exp(1-3theta/4)<=U exp(-theta/2)`。

现考虑余下区间。令 `v=theta/n, x=L/n`。由于 `L>=theta-1`，该区间必有

`0<v<4c0<=8, x<=v+log(8/v)`。

若 `x<=1`，平方根项与 `L` 的比至多

`4sqrt(e)sqrt(n)/theta<=4sqrt(e)/4096<1/4`，

这里使用 `max_{y>0} sqrt(log(2y))/y=sqrt(2/e)`（只需 `log(2y)>=0` 的部分）。同时 `8e A/k<=8e^2 n/k`。

若 `x>=1`，由 `exp(x)<=(8/v)e^v<=(8/v)e^8`，有

`v exp(x)/x<=8e^8`，

`v^2 exp(x)log(2x/v)/x^2<=16e^7`。

第二式使用 `max_{v>0} v log(2x/v)=2x/e`。又 `v^2 n>=4096^2`，故平方根项与 `L` 的比的平方至多

`128e^8/4096^2<1/16`，

而 `8e A/k` 与 `L` 的比至多

`32e^9/4096^2<1/4`。

因此 (C) 的首项统一至多

`2e U exp[-theta/2+8e^2 n/k]`。

其第二项使用 `T>=2, 1+c0<=3, k>=2theta`，至多 `U exp(-theta n)`，从而至多 `U exp(-theta/2)`。吸收固定前因子（`theta` 已很大），得

`M<=U exp[8e^2 n/k-theta/4]`

`<=U exp[100 n/k-T/8]`，证明完成。

## 可用于全局机制的范围

此命题证实：高负载、真实不交来源下，抽取约 `T` 个实际标签产生的随机交集外扩，具有所需的 `exp(Cn/k-cT)` 局部期望折扣。它不能直接对所有锚点求和；全局共同 Poisson 抽样的覆盖、未命中事件以及跨锚来源总价仍须另证。本分支不据此声称 `V_near<=A U` 或原极大算子根阶上界已成立。

此追加推导未进行数值搜索；已请求主代理安排独立代数审查。上述结论以这里的完整解析推导为依据，不以参考模型为依据。

### 冻结量词补注（供独立审计）

本轮应用限定为 `r<=s_i<=nr`，族有限、`r>0`、`q_i>=0`，零 `q_i` 可删除；高 `T` 假设保证抽样分母非零。此时 `0<U<=c(2nr)^n`，故必有

`T<=c(1+n log n)`。

因此定理在 `8192sqrt(n)>c(1+n log n)` 的维数中没有满足假设的源族；没有利用这些空域声称小维数结论。`n>=256` 为整数。`k` 为任意满足 `k>=2T/c` 的正整数，没有另需的上限；为接合拟议机制可固定 `k=ceil(2T/c)`，此时 `k<=2(1+n log n)+1`。以上界以及前述完整证明共同冻结为**待独立审计的局部候选命题**，不是全局共同付款结论。
