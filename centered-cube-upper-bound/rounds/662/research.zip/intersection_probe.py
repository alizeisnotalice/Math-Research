import os
for v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[v]='1'
import numpy as np,scipy,flint
from scipy.stats import binom
from flint import arb,ctx
from pathlib import Path
import math,json,platform,hashlib,time
ctx.prec=192;ctx.threads=1;P=Path(__file__).parent

def geometry(n):
 a=32*n;rho=arb(1)-arb(2)/a;t=1-rho**n;target=8*arb(n).sqrt(); ratio=target/t;K=int(float(ratio));assert arb(K)<=ratio and ratio<arb(K+1)
 rmax=rho**(-(K-1));assert rmax<arb(n)
 logU=n*arb(2).log()+n*rmax.log()+(1-(rho/rmax)**n).log()
 return {'n':n,'a':a,'rho':str(rho),'T_layer':str(t),'K':K,'K_floor_certified':True,'T':str(K*t),'T_float':float(K*t),'tau':str(target),'T_le_tau':K*t<=target,'rmax':str(rmax),'rmax_less_n':True,'logU':str(logU),'logU_float':float(logU)}

def sample(n,k,g,rng,reps=256):
 a=g['a'];rho=1-2/a;lr=-math.log(rho);logU=g['logU_float'];c0=1+1/a
 counts=np.arange(1,n+1);probs=binom.pmf(counts,n,2/a);probs/=probs.sum();cdf=np.cumsum(probs);cdf[-1]=1
 records=[];t=time.monotonic();cpu=time.process_time()
 for rep in range(reps):
  scales=np.exp(rng.integers(0,g['K'],k)*lr)
  ind=rng.integers(1,a-1,size=(k,n),dtype=np.int32)
  bc=np.searchsorted(cdf,rng.random(k))+1
  # Uniform independent ordered coordinate selections with duplicate rejection.
  first=rng.integers(n,size=k);ind[np.arange(k),first]=rng.choice(np.array([0,a-1],dtype=np.int32),size=k)
  for i in np.flatnonzero(bc>1):
   taken={int(first[i])}
   while len(taken)<bc[i]:
    col=int(rng.integers(n))
    if col not in taken:taken.add(col);ind[i,col]=0 if rng.integers(2)==0 else a-1
  centers=scales[:,None]*((2.0*ind+1)/a-1)
  low=np.max(centers-scales[:,None],axis=0);high=np.min(centers+scales[:,None],axis=0)
  assert np.all(low<0) and np.all(high>0)
  records.append(float(np.log(high-low+2*c0).sum()-logU))
 a1=np.array(records);return {'n':n,'k':k,'reps':reps,'mean':float(a1.mean()),'sample_variance':float(a1.var(ddof=1)),'sample_std':float(a1.std(ddof=1)),'standard_error':float(a1.std(ddof=1)/math.sqrt(reps)),'min':float(a1.min()),'max':float(a1.max()),'quantiles_50_90_99':list(map(float,np.quantile(a1,[.5,.9,.99]))),'values':records,'wall_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu}
if __name__=='__main__':
 wall=time.monotonic();cpu=time.process_time();out=[];geoms=[];seed=662000;print('PID',os.getpid(),'one worker','seed',seed,flush=True)
 for n in (16,64,256,1024):
  geom=geometry(n);geoms.append(geom);T=geom['T_float'];ks=[round(T/2),round(T),round(2*T)]
  for j,k in enumerate(ks):
   z=sample(n,k,geom,np.random.default_rng(seed+n*10+j));out.append(z);print('n',n,'k',k,'mean',round(z['mean'],6),'variance',round(z['sample_variance'],6),'max',round(z['max'],6),flush=True)
  data={'task':'R662-HALO-01','seed_formula':'662000+10*n+j, j=0,1,2','geometry':geoms,'cases':out,'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'flint':flint.__version__},'precision_bits':192,'wall_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'workers':1,'command':'OPENBLAS_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r662-20261115/intersection_probe.py','sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Monte Carlo finite geometrical source model; R661 admission not established; not a general bound; rare tails remain unresolved'}
  (P/'intersection_results.json').write_text(json.dumps(data,indent=2)+'\n')
