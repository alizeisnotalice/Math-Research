# R662 continuation checkpoint

Authoritative target remains pure C_n<=K sqrt(n), arbitrary L1/all positive scales/fixed Lebesgue. Not proved; old n^(1/2+o(1)) not proved either.
Final REPORT.tex and audits are authoritative; original TASK.md's tau=8sqrt(n) is superseded for the analytic construction only.

New independently audited result: finite common-point Ai with disjoint actual Fi⊂Bi, qi=|Fi|/di, si>=r, n>=256,T>=8192sqrt(n),integer k>=2T/c give
E|intersection iid Ai+c0r cube|<=U exp(100n/k-T/8).
Proof: actual cumulative volume H(d)<=min(cd,U), minimum-sample fractional moments; two-point lens with lambda/2 tail cut; splice large-L minimum-volume and small-L lens moments. No coordinate independence.
Near scale domain T<=c(1+n logn); low dimensions can be empty. Do not present them as tested nonempty high-T cases.

Global chosen construction: rerun admission/residual at tau=16384sqrt(n), fixed k=ceil2tau. All true near I_j have T_j>tau/2,T_j<=tau; n<256 near is empty.
One source-label Poisson process, rate qi, on [0,infinity). Every target first-k actual events defines one key; group representative h earliest/largest radius.
L_h={x:preceding actual q-load<=1}. Group loss covered by (intersection key Ai+c0 s_h cube) intersect L_h.
W_union<=W_sum. Only E W_union<=A U needed; sum may be too strong.
Exact sum price: sum_h E_iid q/T_h [phi_h(tuple) rho_h(tuple)], rho_h Gamma(k,T_h) average of all earlier compatible targets killed in I_l\I_h by same outside Poisson background. Do not factor phi,rho; do not multiply correlated kill events.
Exact union: E W_union=sum_i qi int E|Delta_i(history)|dt, where Delta_i is union of ALL keys newly completed by this one arrival minus old union. Each x paid once. Keep full history; simple k-tuple simplex factor is not valid for newly-visible increments depending on earlier insertion times.
No bound yet; next work should remain on this single union/void/admission geometric integral, not more local weights or unbudgeted anchors.

Numerics: initial real compressed annular-grid experiment12x256 at n16/64/256/1024, low oldtau8sqrt(n), all recorded observable log volume ratio; cannot bound expectation from negative meanlog. No admission or loss claim.
Independent exact+256bit geometry and4 oldsample replay passed.
153 finite256bit scalar (A)/(C) point certificates passed for n2^20,2^24,2^32,2^48; no finite-to-general inference. Proof is analytic.
Source NUMERIC.md audited prefix1993bytes retained; laterHALO02append explicitly tracked.
No extraMC requested because it cannot resolve rare tails/global cost. No false CPU saturation claim.

Reuse agents: global_coverage_bridge Astra(xhigh) local theorem; joint_source_gain Astra(xhigh) globalPoissonlaw; packing_entry Sol(high) globalaudit; mass_payment_audit Sol(xhigh) localproofaudit; pool_compute Terra(high) numeric; pool_independent_audit Sol(high); history_391_520 Sol(high) finalreview. Completed agents are idle, not claimed working.
No actual credit data. User grants tools/models and parallel delegation. Keep fewrepo files; noPDF. Every finished round separatecommit/push.
