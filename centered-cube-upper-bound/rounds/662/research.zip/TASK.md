# R662 frozen task: actual joint source cost, not more local lemmas

Previous goal turn: progress. R660 and R661 were independently audited, separately committed, and remote-confirmed (06d23100176b9112dac27fa36f3731ceaa412b2d; cfa7acc0fb0c34ea2eacfc0ea95fb1af1d86fa16). General pure C_n<=K sqrt(n) is NOT proved. Guide permits direct packing and replacing mechanisms, not reducing original scope.

## Same complete finite object
For every finite axis-parallel common-radius cube family, a=32n, A_j=Q(y_j,s_j), B_j=A_j/a, d_j=(2s_j)^n, original V0=|union B_j| and P0=max Σd_j theta_j subject to θ>=0 and Σθ_j1_Aj<=1 a.e.
Known recovery C_n<=sup V0/P0<=exp(1/32)C_n.
An actual radius-descending admission scan costs at most C_adm=1+exp(1/16), and gives real disjoint full owners E_j⊂B_j with past raw load<=1 pointwise on each E_j.
For same tau=8 sqrt(n), n>=256, q_j=min(w_j,(tau-esssup_Aj Σ_{i<j}q_i1_Ai)_+), w_j=|E_j|/d_j. Real disjoint F_j⊂E_j, |F_j|=d_jq_j; X_j=E_j\F_j; U=Σ|Fi|. q/tau globally feasible, P0>=U/tau.
Every lost row has one actual complete saturation point z_j (including current row, away from all faces), load exactly tau. Future positive-q sources cannot contain it.
V_sel=U+V_far+V_near, V_far<=2 exp(33/32)U/tau.
Near I_j={i:q_i>0,z_j∈Ai,s_j<=s_i<n s_j}, load>tau/2.

## Proved geometry available
Set c0=1+1/a,c=c0^n.
Fixed anchor z_h, radius r_h, actual source subset J_h of positive q, all z_h∈Ai and r_h<=si<=n r_h; U_h=Σ_{i∈J_h}|Fi|.
Any number of targets sj<=r_h may each use a different shared subset {i∈J_h:z_j∈Ai}, provided its q-load>=tau/3.
The ENTIRE receiver union of that group is <=exp(-sqrt(n)/20) U_h.
Proof: pair lens plus exact |Q(0,R)+D B1|/(2R)^n=Σ binom(n,k)(D/R)^k/k!<=exp(2sqrt(nD/R)).
For B=tau/(3c)-1,L_h=log[U_h/(c(2r_h)^n)]∈[B,nlogn], actual group price is stronger U_h exp[-L_h+2sqrt(2n exp(L_h/n)log(L_h/B))]<=U_h exp(-L_h/50).
This is R661 REPORT.tex, source definitions must remain actual.

## Only real success criterion this round
Construct actual anchor/source/target selection (possibly source subpieces, soft assignment or a stronger common packing) for ALL finite original families so that total true receiver loss and source costs yield V_near<=A U, absolute A; or another genuine full-family bound improving the dimension order.
With partial groups the exact unpaid total is exp(-sqrt(n)/20)Σ_hU_h+V_fragmented. Merely naming this quantity, an LP/Hall restatement or a new local group lemma is not success.
Candidate to examine, NOT an asserted theorem: combine trimming/adaptive source prices with a true overlap cost exp(C n/tau) and geometric discount exp(-c tau), with tau an absolute multiple of sqrt(n). Any reparametrization needs all actual contracts and original V/P recovery.

## Obstacles that must not be repeated
1. A target can share <tau/3 with every old anchor, but much with their union. Cannot force it into one anchor.
2. Small pairwise q-overlap does not control ΣU_h because |Fi|=d_i q_i. Tiny q at large d can recur. Trimming upper radii must retain target coverage and account for the dropped load.
3. Source-by-source binary splits multiply inherited price by 1+exp(-q_i/c); no automatic Kraft.
4. Untruncated non-tangential source-field L2 fails exponentially even for actual one-scale tiled cubes (no losses). Known dimension-free cube L2 theorem does not control that new supremum.
5. Same-z high-admission off-diagonal energy E_off<=C nU is an equivalent sufficient target, not progress absent a new geometric bound.
6. F_i density<=1 is true receiver ownership, never a cap on arbitrary f or KKT measures. Keep all dimensions/scales/time/source costs.
7. Small-tag high-dimensional simulations automatically pass root calibration; no order inference.

## Work / sharing
Only own assigned files in /Volumes/data/CodexTemp/centered-cube-r662-20261115. Shared codebase: do not revert others. No Git by subagents. No model calls or computations claimed unless actually run. Main owns REPORT.tex, final integration and submission.
Start independently; decisive formula first, then exchange. Bound deliverable, stop and wait. Use necessary R661 REPORT/appendix portions only, not full history.
All numeric work has one NUMERIC.md task index and one owner. Do not run redundant expensive scans. Accurate real compressed models may be used; a model does not prove the general theorem.
