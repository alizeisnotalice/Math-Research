import os
for q in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[q]='1'
import sympy as sp,flint
from flint import arb,ctx
import platform,time,json,hashlib
from pathlib import Path
ctx.prec=256;ctx.threads=1;P=Path(__file__).parent
y,v,x=sp.symbols('y v x',positive=True);f=sp.log(2*y)/y**2;g=v*sp.log(2*x/v)
sym={'df':str(sp.diff(f,y)),'critical_y':str(sp.sqrt(sp.E)/2),'fmax':str(sp.simplify(f.subs(y,sp.sqrt(sp.E)/2))),'dg':str(sp.diff(g,v)),'d2g':str(sp.diff(g,v,2)),'critical_v':str(2*x/sp.E),'gmax':str(sp.simplify(g.subs(v,2*x/sp.E)))}
assert sp.simplify(f.subs(y,sp.sqrt(sp.E)/2)-2/sp.E)==0 and sp.simplify(g.subs(v,2*x/sp.E)-2*x/sp.E)==0
E=arb(1).exp();constants=[]
for label,diff in [('8e²<100',100-8*E**2),('128e⁸/4096²<1/16',arb(1)/16-128*E**8/4096**2),('32e⁹/4096²<1/4',arb(1)/4-32*E**9/4096**2)]:
 assert diff>0;constants.append({'claim':label,'right_minus_left':str(diff),'certified':True})

def scan(N):
 an=arb(N);c0=1+arb(1)/(32*an);c=c0**N;lo=8192*an.sqrt()/c;hi=1+an*an.log(); amin=int(float(lo));
 while arb(amin)<lo:amin+=1
 while arb(amin-1)>=lo:amin-=1
 amax=int(float(hi))
 while arb(amax)>hi:amax-=1
 while arb(amax+1)<=hi:amax+=1
 if amin>amax:return {'n':N,'empty_domain':True,'theta_lower':str(lo),'theta_upper':str(hi),'cases':[]}
 thetas=sorted(set(amin+(amax-amin)*j//4 for j in range(5)));cases=[];skipped=[]
 for theta in thetas:
  t=arb(theta);low=t-1;up=an*an.log();seam=low+an*(4*c0*an/t).log(); vals=[('lower',low),('upper',up),('x1',an),('seam_minus',seam-arb(1)/1024),('seam',seam),('seam_plus',seam+arb(1)/1024)]
  for name,l in vals:
   if name=='lower' or name=='upper': pass
   elif not (l>=low and l<=up):skipped.append({'theta':theta,'L':name,'reason':'outside or indeterminate legal range'});continue
   if not (2*l/t>1):skipped.append({'theta':theta,'L':name,'reason':'C log domain not strictly positive'});continue
   for multiplier in (1,2,8):
    k=2*theta*multiplier;ak=arb(k);T=c*t; logA=(arb(3)/c).log()+1-t+an*(1+c0*((-l-1+t)/an).exp()).log();expr=an*(l/an).exp();first=arb(2).log()-l+2*(2*E*expr*(2*l/t).log()).sqrt()+8*E*expr/ak;second=(ak/(ak-1)).log()+an*(1+c0).log()-T.log()-(ak-1)*an
    if first>second:logC=first+(1+(second-first).exp()).log()
    elif second>first:logC=second+(1+(first-second).exp()).log()
    else:raise ValueError('cannot compare logsum terms')
    if logA<logC:chosen='A';best=logA
    elif logC<logA:chosen='C';best=logC
    else:raise ValueError('cannot compare A and C')
    target=100*an/ak-T/8;diff=best-target
    cases.append({'theta':theta,'T':str(T),'L_kind':name,'L':str(l),'k':k,'logA':str(logA),'logC':str(logC),'branch':chosen,'target':str(target),'difference':str(diff),'float_difference':float(diff),'certified_negative':diff<0,'positive':diff>0})
 return {'n':N,'empty_domain':False,'theta_min_integer':amin,'theta_max_integer':amax,'theta_values':thetas,'cases':cases,'skipped':skipped}
if __name__=='__main__':
 start=time.monotonic();cases=[scan(2**i) for i in (20,24,32,48)];allcases=[(z['n'],q) for z in cases for q in z['cases']];worst=max(allcases,key=lambda z:z[1]['float_difference']);out={'task':'R662-HALO-02','symbolic':sym,'constants':constants,'results':cases,'worst':{'n':worst[0],**worst[1]},'uncertain_count':sum(not q['certified_negative'] and not q['positive'] for _,q in allcases),'positive_count':sum(q['positive'] for _,q in allcases),'precision_bits':ctx.prec,'python':platform.python_version(),'versions':{'flint':flint.__version__,'sympy':sp.__version__},'wall_seconds':time.monotonic()-start,'workers':1,'command':'OPENBLAS_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r662-20261115/scalar_probe.py','sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite scalar interval checks only; not a proof for all parameters or global source allocation'};(P/'scalar_results.json').write_text(json.dumps(out,indent=2)+'\n');print('cases',len(allcases),'positive',out['positive_count'],'uncertain',out['uncertain_count'],'worst',worst[0],worst[1]['float_difference'],'theta',worst[1]['theta'],'L',worst[1]['L_kind'],'k',worst[1]['k'],flush=True)
