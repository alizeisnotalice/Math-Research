from fractions import Fraction as F
from itertools import product
ct=dict(endpoint=0,gain_ratio=0,rapid_payment=0,union=0,atomic_crossing=0)
for n in (1,2,8,32):
 radii=[F(1),F(1001,1000),F(5,4),F(3,2),F(2)]
 for masses,H,pattern in product(([F(1,100),F(1),F(1,10),F(2),F(1)], [F(1),F(1,100),F(3),F(1,10),F(2)]),(F(1,10),F(1),F(4)),(0,1,2)):
  cap=[(i+pattern)%2 for i in range(5)] if pattern<2 else [0,0,1,1,1]
  J=[sum(masses[:i+1]) for i in range(5)];A=[sum(masses[j]*cap[j] for j in range(i+1)) for i in range(5)]
  weights=[radii[i]**(-n)-(radii[i+1]**(-n) if i<4 else 0) for i in range(5)]
  gate=[int(J[i]>=H and A[i]/J[i]<F(7,8)) for i in range(5)]
  K=[sum(weights[j]*gate[j]/J[j] for j in range(i,5)) for i in range(5)]
  for i,tidx in product(range(5),repeat=2):
   if tidx<i:continue
   r,t=radii[i],radii[tidx];D=max(H,J[i]);Dt=max(H,J[tidx]);v=(r/t)**n
   bound=(r**(-n)-t**(-n))/D+t**(-n)/Dt
   assert K[i]<=bound;ct['endpoint']+=1
   if J[i]<H<=J[tidx]:ct['atomic_crossing']+=1
   for sep in (F(1001,1000),F(5,4),F(2)):
    N=sum(masses[j]*(1-cap[j]) for j in range(i) if radii[j]<=r/sep)
    rho=N/D;psi=1-v+v*D/Dt
    assert K[i]*N<=r**(-n)*rho*psi<=r**(-n);ct['gain_ratio']+=1
    for delta in (F(1,8),F(1,4),F(1,2)):
     rapid=(v>=1-delta and Dt>=D/delta)
     if rapid:
      assert rho*psi<=2*delta;ct['rapid_payment']+=1
     eta=2*delta
     paid=(rho<=eta or rapid)
     if paid:
      assert K[i]*N<=eta*r**(-n);ct['union']+=1
print('PASS',ct)
