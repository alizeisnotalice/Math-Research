from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(3,2),F(2)]
mu=[F(1,4),F(1,3),F(1,5),F(1,7)]
levels=sorted(set(R))
J=lambda t:sum((m for r,m in zip(R,mu) if r<=t),F(0))
Jl=lambda t:sum((m for r,m in zip(R,mu) if r<t),F(0))
ct=0
for n,s,H,h,delta,f in product(
 [1,2,4],[F(5,4),F(3,2),F(2)],
 [F(1,10),F(1,2)],[F(1,4),F(3,4)],
 [F(1,10),F(1,2)],product([0,1],repeat=4)):
 weights=[r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0)
          for k,r in enumerate(levels)]
 Ap=lambda r:sum(mu[i]*f[i] for i in range(4) if R[i]<=r)
 def K(t):
  return sum((w/J(r) for r,w in zip(levels,weights)
    if r>=t and J(r)>=H and Ap(r)/J(r)<F(7,8)),F(0))
 def K0(t):
  return sum((w/J(r) for r,w in zip(levels,weights)
              if r>=t and J(r)>=H),F(0))
 near=lambda t,u:max(t,u)<s*min(t,u)
 Theta=[]
 for i,t in enumerate(R):
  th=t**n*sum(mu[j]*near(t,R[j])*K0(max(t,R[j])) for j in range(4))
  ex=t**n*sum(mu[j]*(1-f[j])*near(t,R[j])*K(max(t,R[j]))
              for j in range(4))
  g=(J(t)-J(t/s))/J(t)
  forward=sum(mu[j]*(t/R[j])**n/J(R[j])
                  for j in range(4) if t<R[j]<s*t)
  assert 0<=ex<=th<=1 and th<=g+forward
  if Jl(s*t)<=(1+delta)*J(t/s): assert th<=2*delta
  Theta.append(ex)
 Tparts=[mu[i]*f[i]*R[i]**(-n) for i in range(4)]
 B=sum(mu[i]*mu[j]*abs(f[i]-f[j])*near(R[i],R[j])
       *K(max(R[i],R[j])) for i in range(4) for j in range(4))/2
 assert B==sum(Tparts[i]*Theta[i] for i in range(4))
 lam=max([F(1,100)]+[F(f[i],4)*R[i]**(-n) for i in range(4)])
 low=quiet=growth=F(0)
 for i,t in enumerate(R):
  if J(t)<=h: low+=Tparts[i]*Theta[i]
  elif Jl(s*t)<=(1+delta)*J(t/s): quiet+=Tparts[i]*Theta[i]
  else: growth+=Tparts[i]*Theta[i]
 assert low<=4*lam*h and quiet<=2*delta*sum(Tparts)
 assert B==low+quiet+growth
 assert B<=4*lam*h+2*delta*sum(Tparts)+growth
 ct+=1
print('PASS retained_capture_gate_and_ties',ct)  # actual: 1152
