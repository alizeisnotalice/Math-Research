# R307 independent preauthor audit

Independent screen status: PASS. This section was saved before reading any R307 author proof.

## Fixed original interface and exact gain anchor

Fix one positive common threshold theta, original U,J,H, physical a<=R<=b and binary qualified capture sigma_theta. All actual low-pe, high-m, aspect and full source/history qualifications, original q and original source measures remain unchanged. Write ell_n=b^-n delta_b+n r^-n-1 dr and K(t)=integral_[t,b] ell_n(dr)1{J>=H,p_theta<7/8}/J, zero for t>b. Let N(t)=integral_{Ru<=t} Uu(1-sigma_u). Assume s>1.

The R306 far-gain component has exact large-capturing-receiver representation

G_far=integral Uw sigma_w N(Rw/s) K(Rw) beta nu dw.

The lower source radius equality Ru=Rw/s is included because the far separation is closed. No tie ambiguity occurs for s>1. For any r>=Rw satisfying J(r)>=H, J(r)>=max(H,J(Rw)); hence

K(Rw)<=Rw^-n/max(H,J(Rw)).

Writing dT_theta=Uw sigma_w Rw^-n dw beta nu, this gives G_far<=integral [N(Rw/s)/max(H,J(Rw))]dT_theta. The ratio is in [0,1]. Its <=epsilon branch is bounded by epsilon T_theta, preserving the actual target measure. Its complement remains an unpaid positive weighted-original-traffic fee; original caps or FIRST do not certify that ratio small in general.

## Near capture anchor and exact radius endpoints

The whole near fee can be oriented by its capturing receiver w, with bad receiver u satisfying Rw/s<Ru<sRw. Binary symmetry cancels the 1/2, including the radius diagonal; all ties may be assigned to the past part Ru<=Rw without duplication. Its past-plus-tie contribution is at most

integral [J(Rw)-J(Rw/s)]/max(H,J(Rw)) dT_theta.

The lower equality Ru=Rw/s belongs to far gain, hence must be excluded here. Past includes Ru=Rw and all original selector-radius atoms.

For future radii Rw<Ru<sRw, the same K bound at Ru and Ru^-n<=Rw^-n give the upper fee

integral dT_theta integral_(Rw,sRw) dJ(t)/max(H,J(t)).

Both integration endpoints are strict. Define F_H(j)=j/H for 0<=j<=H and 1+ln(j/H) for j>H. The integrand uses the POST-jump J(t); since 1/max(H,j) is nonincreasing, every atom obeys deltaJ/max(H,J_post)<=F_H(J_post)-F_H(J_pre). Continuous change is the ordinary chain rule. Therefore the future inner integral is <=F_H(J(sRw-))-F_H(J(Rw)). If sRw>b, extend J constantly as total row mass I and use I as the upper left limit; if sRw=b exactly, the atom at b remains EXCLUDED and J(b-) is required. If Rw=b the future is empty. No fictitious Lebesgue density of the selected radius is assumed.

These are weighted-ratio payments at the original actual receiver field, not new source-only mask substitutions. Ratios/qualification gates may depend on y,z,theta; their low branches are paid on the same dT_theta. Averaging theta uses its original total weight one. If several distinct components each use an epsilon payment, their coefficients must be added or assigned a shared total error budget; they cannot be charged repeatedly as one epsilon T. Far loss, ties, near, gain and all further complementary qualification components retain the R306 partition. No original-X absorption or source-root conclusion follows merely from these inequalities. Outer Lambda and the original source ledger remain necessary.

## Actual bounded diagnostics

Executed local finite diagnostics: 576 exact Fraction gain-anchor/K-bound/past/future configurations and 2304 60-digit inclusive-atom potential comparisons, all PASS. The models include repeated radii, exact separation equality, strict upper endpoint b and sR>b. They test the scalar/CDF algebra, not a realization of the full original low/e/m/history field or a general root budget.

Remaining gap: the large gain ratio and the near prefix-growth/potential ratios still require a general original-source budget. Neither fixed FIRST nor the same-radius cap proves that their high branches are small.

## Additional independent screen: rapid prefix growth pays more gain

Screened before reading any author proof: for r<=t<=b, splitting the layer at [r,t) and [t,b] gives

K(r)<=(r^-n-t^-n)/D(r)+t^-n/D(t), D(r)=max(H,J(r)).

The lower interval excludes t, so every selector-radius and terminal atom at t belongs to the second interval. Multiplying by N(r/s) r^n and putting rho=N/D(r), v=(r/t)^n gives rho[1-v+vD(r)/D(t)] as a bound on gain per actual dT_theta. For delta in (0,1), canonical t=min(b,r(1-delta)^(-1/n)) satisfies v>=1-delta. If D(t)>=D(r)/delta, this factor is at most 2delta-delta^2<=2delta. At r=t=b this rapid-growth condition is impossible since H>0 and delta<1; no terminal branch is silently paid.

Use the disjoint union {rho<=eta} and {rho>eta AND rapid growth}, with delta=eta/2. The coefficient on EACH portion is <=eta, so their UNION is bounded by eta times the SAME actual target, not 2eta T. The entire complement {rho>eta AND no rapid growth} retains its exact original gain integrand N K. This is an analytic split of existing traffic, not permission to choose a new receiver or apply FIRST after a source-dependent change. It does not prove the remaining branch has a source-root budget.

Actual additional diagnostics: 1440 exact Fraction K-splitting configurations (including t between radius atoms and t=b) and 222 exact rapid-growth coefficient cases, all PASS.

## Independent screen: conservative near-quiet branch and combined constants

For the actual near anchor r, put A=J((r/s)-), B=J(sr-), extending J as zero below a and constant beyond b. The conservative gate B<=(1+delta)A is sufficient. On actual positive capturing traffic J(r)>0 almost everywhere and A<=J(r)<=B; if A=0 the quiet gate forces J(r)=0 and there is no such traffic. The past/tie ratio is bounded by (B-A)/J(r)<=delta. The future ratio is <=log(B/J(r))<=log(1+delta)<=delta; this follows also directly from the post-jump chain inequality with D>=J. Thus quiet near is <=2delta T_theta. Using J((r/s)-) instead of the sharp J(r/s) only makes the paid gate smaller and includes more lower-atom mass in its upper budget, so no endpoint is lost.

With eta=1/32 and delta=eta/2, gain paid<=eta T_theta and quiet near<=eta T_theta. They are distinct incidence components even if their anchor sets overlap, so their total cost is 2eta T, not eta T. Add R306 loss<=T/8. In T<=128 lambda d W_beta+4 B, the retained coefficient is 1-4(1/8+2eta)=1/4. Hence Lambda T<=512 Lambda lambda d W_beta+16 Lambda times the exact full gain/near complement. This is internal finite-T absorption, adding ZERO to the original-X coefficient. No root estimate follows for d or that complement, and all independent ledger slots/aspect complements remain.

## Author comparison: exact near budget

Read `/tmp/r307_near_budget.md`, SHA256 `63c86f1336cc37689b0813de52f502e522ec58d0a9f703c16a7b2f118a8a0684`. PASS for (1)-(10). The exact capturing-anchor swap retains missed capture and the original p<7/8 gate. All ties remain, the lower strict-near atom is excluded and the future upper atom is excluded. Theta<=theta_row<=1 follows by undoing the swap, not from a density premise. Quiet past and forward bounds include the inclusive CDF jumps. The optional small-J branch is separately paid at actual accepted receivers by the SAME-radius cap and inclusive row mass <=h(y), costing 4lambda integral h beta; it is not used by the combined receipt and is not charged again. Source-dependent h(y,z) is correctly not granted for free. Disjoint-window growth counting does not pay the amplitude-weighted growth fee.

Actually executed the fresh embedded Fraction reproduction: 1152 retained-gate/near/tie cases PASS. These are finite incidence diagnostics and do not realize the complete original low/e/m/history field.

## Numeric artifact scope inspection

Read `/tmp/r307_numeric.py` and its diagnostic note. The interval integrals correctly use right-continuous prefix values, exact power differences, and the terminal b atom. All qualifications and U/radius data are explicitly scalar atomic-CDF models, not actual complete original L1/history fields. The tested rapid scales range over a finite rational menu; no exhaustive canonical-scale numerical search is claimed. The near scalar prefix sum is allowed to exceed one, with the true weight bounded by its minimum with one. The final 512/16 arithmetic is explicitly conditional on the proved near/gain inputs.

Completed JSON status `PASS`, empty failures, total 3197 exact checks; SHA256 `4e56d83591dada03cd7285abba5b2c781011e3b319f34e746ab2e79232a7af74`. Parent reports a fresh independent-directory rerun byte-identical to this artifact. This audit inspected the code/scope/output; it did not rerun the artifact-writing full numeric script.

## Author comparison: final gain / rapid-growth geometry

Read corrected `/tmp/r307_geometry.md`, SHA256 `e8ef9aed72957a80cbcea3c9e43e732d827898aae2eb66315d8989550baf41d8`. Equations (1)-(18) PASS against the independent screen. The exact gain anchor retains inclusive N,J and the original prefix gate. The two-endpoint layer split assigns t atoms to [t,b]; the canonical scale capped at b preserves v>=1-delta. The disjoint paid union has one eta coefficient, terminal rapid growth is impossible, and the exact persistent gain and displayed near separation remain unpaid in general. The source alternative and finite-T absorption are not double spent. The final text correctly restricts strict improvement to the OLD QUOTIENT UPPER BUDGET when D(t)>D(r) on positive original traffic with N>0; J growth below H is insufficient.

A reproducibility defect was found during this audit: the initial embedded weights comprehension used an undefined r, causing fresh execution to fail. The author changed that occurrence to radii[i], then reported fresh isolated-process exit0. This audit independently executed the corrected complete code in a fresh namespace: 1080 endpoint bounds, 3240 gain-quotient bounds, 423 rapid receipts, 9224 union receipts, and 216 observed H-crossing configurations; all stated assertions PASS. No earlier failed attempt is reported as a passing computation. The mathematical proof did not depend on the defective diagnostic line. These remain finite prefix diagnostics, not complete original-history realizations.

## Final integration verdict — frozen

PASS. Final combined note, README and static TeX agree with the independently screened and audited gain/near theorems. TeX now explicitly gives 0<=I0<=alpha<=1, alpha z-independent, actual a<=L,R<=b<=2a, q range, original SAME-radius hard cap and unchanged height constants; original U/J are fixed in theta while derived K may vary through A. The gain union has ONE eta cost. Gain and near are DISTINCT components, so their two eta costs are added. With s^n=8, eta=1/32, delta=1/64, the full paid coefficient is 1/8+2eta=3/16; multiplying by the imported coefficient four leaves 1/4. The final source/incidence coefficients 512 and 16 are correct.

Main near quiet uses the conservative J((r/s)-), leaving all lower and upper radius atoms correctly accounted for; it does not adopt the auxiliary small-J source receipt. The exact gain persistent complement and near nonquiet complement retain their source capture and missed-capture factors, original K and all qualifications. No positive-root conclusion follows for those charges. The original Lambda occurs once, internal finite-T absorption adds ZERO to the original-X coefficient, and the independent original ledger slots/aspect/entry obligations remain explicit. No εX or overall weak-type closure is claimed.

Final component / integration / evidence SHA256 bindings:

- `/tmp/r307_geometry.md`: SHA256 `e8ef9aed72957a80cbcea3c9e43e732d827898aae2eb66315d8989550baf41d8`.
- `/tmp/r307_near_budget.md`: SHA256 `63c86f1336cc37689b0813de52f502e522ec58d0a9f703c16a7b2f118a8a0684`.
- `/tmp/r307_combined.md`: SHA256 `f6297bec8678f504612a63ff0f06187ef4eb737b1500cc150caf44a1600d3c54`.
- `/tmp/r307_README.md`: SHA256 `e701e1d0395032d33ac6106c30471b36c7c576a2f743d582d56017d5958eeac1`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/research.tex`: SHA256 `364c37d62a7aaf54349cb793a67b252f074cd92660068a843268e5a24a6ffd9c`.
- `/tmp/r307_numeric.md`: SHA256 `16f01a15e47b21b18ee98f13f63cce361479e865008825bdd3cac475702349b4`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/geometry_checks.py`: SHA256 `42a0dbca301b623ac8dda66fbf71f873eb6d9b6af0c30bb47bc4e58a12e98634`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/near_checks.py`: SHA256 `4351a8c4ffc91893789a644af782685569fcb1d064ee65140826ae9f931cf47e`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/r307_numeric.py`: SHA256 `41bd2b7b9e37b46f581c2a4a183f72638ebad5e20dd8c52a674a4fccc2fdfb21`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/r307_numeric.json`: SHA256 `4e56d83591dada03cd7285abba5b2c781011e3b319f34e746ab2e79232a7af74`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/geometry_checks.log`: SHA256 `09c41e02b5fc08cd920b774199c70645ae8fd2f1e8dca43fd59b7f7572582f8a`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/near_checks.log`: SHA256 `c2af8f7b34f76164214b48c3d322e897702f39029361fccfe5ed6750eac5d305`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round307_20261018_final_checkpoint/numeric_checks.log`: SHA256 `76b7b2c27ee42a6ad3f77cb050fb706ffe5085a034f43c75f7ae9d6570a5dac9`.

Inspected completed parent staging logs: corrected geometry 1080/3240/423/9224 PASS with 216 crossing observations; near 1152 PASS. This audit independently executed both corrected embedded reproductions. Numeric staging code/JSON are byte-identical to the frozen /tmp originals; completed JSON has 3197 exact PASS with empty failures. Parent reports an independent fresh-process rerun of that numeric script. The full numeric JSON is an external reproducible result, deliberately not promised inside the ZIP; README correctly says the archive retains code and compact output. Finite scalar atomic-CDF models are explicitly not full original low/e/m/history realizations, and the sampled rapid-scale menu is not described as an exhaustive search.

Exact remaining gap: a general original-source root budget for high old-noncapture/no-rapid-growth gain and nonquiet near/tie incidence, with all actual qualifications and cross-row overlap retained. Logarithmic counts of row-growth windows do not pay source-weighted traffic. Inverse aspect/height costs, independent initial/deletion/future/suffix slots, source outer integration and the original global entry connector remain. No author, repository, TeX or PDF files were modified by this audit. This receipt is frozen at the listed hashes.
