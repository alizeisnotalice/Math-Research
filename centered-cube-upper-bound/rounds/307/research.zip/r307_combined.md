# R307 主代理整合：原交通付款与全局总账边界

本轮只推进R305–306的实际合资格low-pe、高m、尺度比v>=v0槽T；其他原槽保持R304完整总账。没有一般根阶闭合。所有计算先在共同有限截断上进行。

沿用原U,J、真实dx、beta,nu、q、所有来源和历史资格。共同theta只积分一次。固定H=8d，d=kappa0 psi_inf/(q_-v0)，Lambda=128/119。R305给出

T <=128 lambda d W_beta +4 integral_0^1 B_theta dtheta.

R306的正分解为B_theta=L_far+G_far+B_near；取s^n=8，L_far<=T_theta/8，near包括等半径原子。以下不重复支付森林far-loss。

令eta=1/32，delta=eta/2。G的实际捕获anchor r：D=max(H,J)，rho=N(r/s)/D(r)，t=min(b,r(1-delta)^(-1/n))。按rho<=eta、rho>eta且D(t)>=D(r)/delta组成互不交的已付并集，整体G_paid<=eta T_theta。剩余G_res保留原N K integrand及其两个互补条件。

near令J延拓为b之后的总质量。取保守的quiet门J(sr-) <= (1+delta) J((r/s)-)，其中J在a以下为0；这个条件比严格near所需的J(r/s)版本更强，因而合法。quiet上past项<=(J(sr-)-J((r/s)-))/J(r)<=delta；若J(r)=0，实际dT质量为0，预先归零。future项<=log(1+delta)<=delta。跨H时D>=J只减小上界。故B_near,quiet<=eta T_theta。剩余B_near,res保留真实miss-factor 1-sigma与完整K。零基准quiet若有capture质量不可能；不作0/0。

G_paid和near_paid虽可在同一anchor出现，属于两个不同正组件；系数相加为2eta，而不是误计为eta。于是

[1-4(1/8+2eta)] T <=128 lambda d W_beta +4 integral_0^1(G_res+B_near,res)dtheta.

左侧系数=1/4，得到

Lambda T <=512 Lambda lambda d W_beta +16 Lambda integral_0^1(G_res+B_near,res)dtheta.

本轮不采用辅助稿的额外小J付款，避免再添加一份来源价格；该引理仅作备选工具。上述是严格内部T吸收，不是epsilon X；无需重复用T<=4X扣除全局吸收预算。新增源项是否为sqrt(n)阶仍取决于原d与尺度比费用；不能选择有利v0后删去v<v0补集。

## 全局账目必须保留

R_out<=A_pre+E_pre X+Lambda T_small，且原T_small分解包括T_low、I_rem（初始）、J_rem（真正删除时间原子）、D_rem（未来被删来源连续项）、P_suffix（终端存活来源连续项）及仅一次的负项N_Zc,N_del。本轮只替换T_low中上述被明确限定的槽。

沿用R304原总吸收系数
E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)+epsilon_neartime+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G。
本轮内部T吸收对这个X系数新增0；完整后续采用清单及原全事件入口连接仍未获认证，不能据此宣称E_total<1并完成弱型界。

未付事项：G_res、B_near,res的一般来源根阶预算；v<v0；宽距离连续suffix及未覆盖补集；I/J/D独立预算；原入口、来源外层整合和完整采用误差表。R303的几何BH与这里R305资格coarea余项是不同有效估计中的费用，不凭名字当作同一个精确余项相互替换。

## 实质与限制

新付款是高旧非捕获比例但未来极短窗出现足够真实行质量增长的gain分支；它可严格扩大原rho小分支，保留捕获平方所产生的真实miss因子。near quiet付款明确带原子和前向增长。增长窗口数的对数控制仍不能支付来源加权质量；本轮没有此根预算。没有将边界体积转成任意来源质量，也未改接收器以冒用FIRST。

使用64项工具E03的质量、原子和终端核算纪律；没有援引未经条件核验的外部Bellman嵌入。无实际扣额数据，不估计模型成本。
