# R307 — exact near-pair swap, paid quiet rows, and the full growth branch

## 1. Original binary near/tie fee

Fix one original binary qualification level of R305. Keep its original finite L1 sources beta,nu_*, actual full-soft fields s,L,R,q, full-source low/m/history definitions and original row density U_y(x). Write

    f_y(x,z)=1{z in Q_(R(x))(x)} times the FULL binary qualification,
    J_y(r)=integral_(R(x)<=r)U_y(x)dx,
    A_yz(r)=integral_(R(x)<=r)U_y(x)f_y(x,z)dx,
    p_yz(r)=A_yz(r)/J_y(r) when J>0, and zero otherwise,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr.

The same selected R is used throughout; f is binary and supported in its actual hard cube. Original FIRST and the selected SAME-radius hard cap hold. Let H>0, s>1, and retain the original prefix gate

    chi_yz(r)=1{J_y(r)>=H,p_yz(r)<7/8}.

The COMPLETE strict-near fee, including all equal-radius pairs, is

    B_near=integral beta(dy)nu_*(dz)ell_n(dr)chi_yz(r)/(2J_y(r))
       integral_(R(x),R(w)<=r)U_y(x)U_y(w)
       1{max(R(x),R(w))<s min(R(x),R(w))}
                                      |f_y(x,z)-f_y(w,z)|dx dw. (1)

There is no division on J=0 because chi vanishes there. The p gate is computed from the ORIGINAL full prefix, not from its near-pair restriction. The actual binary target is

    T=integral U_y(x)f_y(x,z)R(x)^(-n)dx beta(dy)nu_*(dz).

It is finite by original FIRST and the hard-scale envelope. No global absorption entry is asserted.

## 2. An exact source-conserving swap, retaining overlap

Define

    K_yz(t)=integral_[t,b] chi_yz(r)ell_n(dr)/J_y(r),
    Theta_yz(t)=t^n integral U_y(w)[1-f_y(w,z)]
       1{max(t,R(w))<s min(t,R(w))}K_yz(max(t,R(w)))dw.

The binary identity |f-f'|=f(1-f')+f'(1-f), symmetry, and positive Tonelli give EXACTLY

    B_near=integral U_y(x)f_y(x,z)R(x)^(-n)
                             Theta_yz(R(x))dx beta(dy)nu_*(dz). (2)

Thus the source capture, its joint missed-capture factor, actual radius weight and original p<7/8 prefix gate are retained. Dropping 1-f and the p gate is used ONLY for the next upper bound, not in (2). All sources and selected profiles remain unchanged.

Let mu_y be the actual R-pushforward of U_y dx, and define the row-only upper weight

    K_y^0(t)=integral_[t,b]1{J_y(r)>=H}ell_n(dr)/J_y(r),
    theta_y(t)=t^n integral 1{max(t,u)<s min(t,u)}
                                         K_y^0(max(t,u))mu_y(du).

Then 0<=Theta_yz(t)<=theta_y(t)<=1. The last inequality follows by undoing the swap: for r>=t, the nearby w mass is at most J_y(r), so the remaining integral is at most t^n ell_n([t,b])=1.

For mu_y-a.e. t with J_y(t)>0, splitting w at u=t gives the sharper usable bound

    theta_y(t)<=g_y(t)+F_y(t),
    g_y(t)=[J_y(t)-J_y(t/s)]/J_y(t),
    F_y(t)=integral_(t,s t)(t/u)^n mu_y(du)/J_y(u).     (3)

All integrals are intersected with [a,b]. The cumulative J is extended by zero below a and constantly beyond b. Its left limit at s t is used below.

Proof: K_y^0(v)<=v^(-n)/J_y(v). For u<=t, strict nearness means t/s<u<=t, of mass J_y(t)-J_y(t/s). For u>t it means t<u<s t, yielding F. In particular the current-radius atom is IN g; the atom at t/s is OUT. Using J_y((t/s)-) instead of J_y(t/s) is a valid wider upper bound, but is not the exact strict-past mass. A one-sided recent fraction g alone omits the forward term F and cannot justify the proposed absorption.

## 3. A genuinely paid row-dependent split, with atoms

Fix 0<delta<1 and ANY measurable positive finite row threshold h(y). Partition original captured source points, by their actual t=R(x), into the following three DISJOINT classes:

    small:  J_y(t)<=h(y);
    quiet:  J_y(t)>h(y) and
                         J_y(s t-)<= (1+delta)J_y(t/s);
    growth: J_y(t)>h(y) and
                         J_y(s t-)> (1+delta)J_y(t/s). (4)

They cover all source points up to the null zero-row set. If J_y(t/s)=0 and J_y(t)>0, quiet is impossible. An atom crossing h is wholly excluded from small unless its post-jump J is still <=h; no part of that crossing atom disappears.

On a quiet point, (3) gives

    g_y(t)<=delta,
    F_y(t)<=log[J_y(s t-)/J_y(t)]<=log(1+delta),
    Theta_yz(t)<=c_delta:=delta+log(1+delta)<=2delta.   (5)

The Stieltjes logarithm bound includes atoms: an increment Delta J obeys Delta J/J_post<=integral_(J_pre)^(J_post)dv/v. Starting from J_y(t)>0 and adding the nonatomic part proves the displayed inequality. The upper endpoint is s t- because nearness is strict. Equal-radius atoms at t remain in the past term g and in the quiet/growth test.

On small points, Theta<=1 and the actual SAME-radius hard cap yield

    integral_small U_y(x)R(x)^(-n)
                                   integral f_y(x,z)nu_*(dz)dx
       <=4lambda integral 1{J_y(R(x))<=h(y)}U_y(x)dx
       <=4lambda h(y).                               (6)

The last inequality is an inclusive-prefix fact, valid with arbitrary radius atoms. It does not require a density cap for nu or a cap at any new radius.

Define the EXACT remaining auxiliary growth charge

    G_s,h,delta=integral_growth U_y(x)f_y(x,z)R(x)^(-n)
                            Theta_yz(R(x))dx beta(dy)nu_*(dz). (7)

Equations (2),(4) partition the auxiliary fee exactly. Equations (5),(6) prove

    B_near<=4lambda integral h(y)beta(dy)
                                  +c_delta T_quiet+G_s,h,delta
           <=4lambda integral h(y)beta(dy)+2delta T+G_s,h,delta. (8)

This is the paid contribution: small cumulative row mass costs its displayed original beta budget, and quiet growth costs an explicitly absorbable fraction of the SAME finite target. The growth charge still contains its actual source capture, missed-capture factor, R^(-n), H and p gate. It is not called paid or root-order. It satisfies G<=T_growth, which alone is the old bound, not a new estimate.

For an original incidence coefficient C_B Lambda and 0<epsilon<min(1,2C_B) choose delta=epsilon/(2C_B). Then

    C_B Lambda B_near<=4C_B Lambda lambda integral h beta
                           +epsilon Lambda T+C_B Lambda G_s,h,delta. (9)

For example C_B=4 and h(y)=H give source fee 16Lambda lambda H W_beta. The epsilon term can be moved only within a valid finite-target inequality already containing that Lambda T. No epsilon lambda|E| entry is assumed, and no other original far/aspect/history slot is removed. A source-dependent h(y,z) would not automatically inherit (6); that would need its actual source-weighted fee. The theorem therefore grants arbitrary ROW thresholds, not free independent source thresholds.

## 4. What logarithmic growth counting does not pay

There is a limited true telescoping fact. In a fixed row, take any ordered family of DISJOINT windows (t_i/s,s t_i) with

    J_y(t_i/s)>=h>0,
    J_y(s t_i-)>(1+delta)J_y(t_i/s).

Monotonicity between the windows gives

    number_of_windows *log(1+delta)<=log(J_y(b)/h).    (10)

Endpoint atoms cause no problem: the next lower inclusive prefix is at least the preceding upper left prefix. Windows whose lower prefix is below h are NOT covered by this count, even if their current atom is large; they remain in (7).

Equation (10) counts multiplicative increases of J. The measure in (7), however, is the original U_y dx times the ACTUAL captured source integral and R^(-n), not dJ/J or an unweighted window count. No theorem here converts those amplitude-weighted charges to (10). The same-R large-atom case is particularly visible: one growth event can carry a large dJ mass. Charging W_nu per window or normalizing every block to unit row mass would reintroduce unproved source copies. Original FIRST supplies its joint receiver constraint, but does not establish that conversion.

Thus (8)–(9) pay small/quiet branches of ALL strict-near pairs, including ties; the full growth complement (7) is still unpriced at root order. There is no general root payment claimed from growth counting. Actual source-capacity/overlap information beyond this row-mass test is still required. For common qualification levels apply the statements separately to each actual binary target and then average with the ORIGINAL weights of total mass one; no threshold copies or recomputed gates are granted.

## 5. Actual bounded diagnostic and reproduction

An exact-Fraction run passed 1152 cases with two DIFFERENT receivers at the SAME selected radius, both H threshold choices, actual p<7/8 retained, small/quiet/growth endpoints, and binary source captures. It checked (2), Theta<=theta<=min(1,g+F), the quiet bound and the complete receipt (8). These finite incidence models diagnose the algebra; they do not claim realization by every original full-soft low/m field. The analytic proof above uses that field's stated interface.

```python
from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(3,2),F(2)]
mu=[F(1,4),F(1,3),F(1,5),F(1,7)]
levels=sorted(set(R))
J=lambda t:sum((m for r,m in zip(R,mu) if r<=t),F(0))
Jl=lambda t:sum((m for r,m in zip(R,mu) if r<t),F(0))
ct=0
for n,s,H,h,delta,f in product(
 [1,2,4],[F(5,4),F(3,2),F(2)],
 [F(1,10),F(1,2)],[F(1,4),F(3,4)],
 [F(1,10),F(1,2)],product([0,1],repeat=4)):
 weights=[r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0)
          for k,r in enumerate(levels)]
 Ap=lambda r:sum(mu[i]*f[i] for i in range(4) if R[i]<=r)
 def K(t):
  return sum((w/J(r) for r,w in zip(levels,weights)
    if r>=t and J(r)>=H and Ap(r)/J(r)<F(7,8)),F(0))
 def K0(t):
  return sum((w/J(r) for r,w in zip(levels,weights)
              if r>=t and J(r)>=H),F(0))
 near=lambda t,u:max(t,u)<s*min(t,u)
 Theta=[]
 for i,t in enumerate(R):
  th=t**n*sum(mu[j]*near(t,R[j])*K0(max(t,R[j])) for j in range(4))
  ex=t**n*sum(mu[j]*(1-f[j])*near(t,R[j])*K(max(t,R[j]))
              for j in range(4))
  g=(J(t)-J(t/s))/J(t)
  forward=sum(mu[j]*(t/R[j])**n/J(R[j])
                  for j in range(4) if t<R[j]<s*t)
  assert 0<=ex<=th<=1 and th<=g+forward
  if Jl(s*t)<=(1+delta)*J(t/s): assert th<=2*delta
  Theta.append(ex)
 Tparts=[mu[i]*f[i]*R[i]**(-n) for i in range(4)]
 B=sum(mu[i]*mu[j]*abs(f[i]-f[j])*near(R[i],R[j])
       *K(max(R[i],R[j])) for i in range(4) for j in range(4))/2
 assert B==sum(Tparts[i]*Theta[i] for i in range(4))
 lam=max([F(1,100)]+[F(f[i],4)*R[i]**(-n) for i in range(4)])
 low=quiet=growth=F(0)
 for i,t in enumerate(R):
  if J(t)<=h: low+=Tparts[i]*Theta[i]
  elif Jl(s*t)<=(1+delta)*J(t/s): quiet+=Tparts[i]*Theta[i]
  else: growth+=Tparts[i]*Theta[i]
 assert low<=4*lam*h and quiet<=2*delta*sum(Tparts)
 assert B==low+quiet+growth
 assert B<=4*lam*h+2*delta*sum(Tparts)+growth
 ct+=1
print('PASS retained_capture_gate_and_ties',ct)  # actual: 1152
```

Only /tmp/r307_near_budget.md was written; other authors and Git were untouched.
