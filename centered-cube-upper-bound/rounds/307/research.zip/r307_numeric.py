#!/usr/bin/env python3
"""R307 exact finite atomic CDF diagnostics; no full original-history certificate."""
import json,hashlib
from fractions import Fraction as F
from pathlib import Path
COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
SVALUES=[F(5,4),F(3,2),F(33,32)];DELTAS=[F(1,64),F(1,16),F(1,8),F(1,4),F(1,2),F(3,4)];ETA=F(1,32)
def analyze(name,n,atoms):
 atoms=[(F(r),F(u),int(sigma)) for r,u,sigma in atoms];a=F(1);b=F(2);levels=sorted(set([a,b]+[r for r,u,s in atoms]));positive=sorted(set(sum(u for r,u,s in atoms if r<=v) for v in levels)-{F(0)});Hs=sorted(set([F(1),F(16),positive[0],positive[len(positive)//2]]));records=[];rapid_hits=quiet_hits=ratio_exceeds_one=terminal_hits=0
 def J(t):return sum((u for r,u,s in atoms if r<=t),F(0))
 def N(t):return sum((u*(1-s) for r,u,s in atoms if r<=t),F(0))
 for H in Hs:
  def D(t):return max(H,J(t))
  def gate(t):return J(t)>=H and sum(u*s for r,u,s in atoms if r<=t)*8<7*J(t)
  cache={}
  def K(t):
   if t in cache:return cache[t]
   if t>b:return F(0)
   value=F(0)
   for left,right in zip(levels,levels[1:]):
    lo=max(t,left)
    if lo<right and gate(left):value+=(lo**(-n)-right**(-n))/J(left)
   if t<=b and gate(b):value+=b**(-n)/J(b)
   cache[t]=value;return value
  for v in levels:
   if J(v) and sum(u*s for r,u,s in atoms if r<=v)*8==7*J(v):ck(not gate(v),'exact_p_seven_eighths_equality_excluded',{'case':name,'H':str(H),'r':str(v)})
  ck(K(b)==(b**(-n)/J(b) if gate(b) else 0),'exact_terminal_b_atom_in_K',{'case':name,'H':str(H)})
  query=sorted(set(levels+[min(b,r*F(1025,1024)) for r in levels]+[min(b,r*F(129,128)) for r in levels]))
  for r in levels:
   ck(K(r)<=r**(-n)/D(r),'exact_K_single_prefix_denominator_bound',{'case':name,'H':str(H),'r':str(r)})
   for t in query:
    if t<r:continue
    split=(r**(-n)-t**(-n))/D(r)+t**(-n)/D(t)
    ck(K(r)<=split,'exact_rapid_two_prefix_K_bound',{'case':name,'H':str(H),'r':str(r),'t':str(t)})
    for delta in DELTAS:
     close=(t/r)**n<=1/(1-delta);growth=D(t)>=D(r)/delta
     if r==t==b:
      terminal_hits+=1;ck(not growth,'terminal_rapid_growth_condition_impossible',{'case':name,'H':str(H),'delta':str(delta)})
     if close and growth:
      rapid_hits+=1
      for s in SVALUES:
       rho=N(r/s)/D(r);factor=r**n*N(r/s)*K(r);bound=(2*delta-delta*delta)*rho
       ck(factor<=bound<=2*delta,'exact_rapid_gain_constant_2delta_minus_delta_squared',{'case':name,'H':str(H),'r':str(r),'t':str(t),'delta':str(delta),'s':str(s)})
  target=sum((u*s*r**(-n) for r,u,s in atoms),F(0))
  for scale in SVALUES:
   G=sum((u*s*N(r/scale)*K(r) for r,u,s in atoms),F(0));direct=F(0)
   for rg,ug,sg in atoms:
    for rb,ub,sb in atoms:
     if rb<=rg/scale:direct+=ug*sg*ub*(1-sb)*K(rg)
   ck(G==direct,'exact_closed_endpoint_far_gain_anchor',{'case':name,'H':str(H),'s':str(scale)})
   paid=unpaid=F(0);lowcount=rapidcount=0
   for r,u,sigma in atoms:
    rho=N(r/scale)/D(r);factor=r**n*N(r/scale)*K(r)
    ck(0<=factor<=rho<=1,'exact_gain_ratio_anchor_bound',{'case':name,'H':str(H),'r':str(r),'s':str(scale)})
    rapid=any(t>=r and (t/r)**n<=1/(1-ETA/2) and D(t)>=D(r)/(ETA/2) for t in query)
    low=rho<=ETA;rapid_branch=(not low) and rapid
    ck(not(low and rapid_branch),'gain_low_ratio_and_rapid_union_disjoint',{'case':name})
    fee=u*sigma*r**(-n)*factor
    if low or rapid_branch:
     paid+=fee;lowcount+=int(low);rapidcount+=int(rapid_branch);ck(factor<=ETA,'gain_union_pointwise_eta_payment',{'case':name,'H':str(H)})
    else:unpaid+=fee
   ck(paid<=ETA*target and paid+unpaid==G,'gain_union_one_eta_T_not_two',{'case':name,'H':str(H),'s':str(scale)})
   for t in levels:
    theta=t**n*sum((u*(1-sigma)*K(max(t,r)) for r,u,sigma in atoms if t/scale<r<scale*t),F(0))
    past_theta=t**n*sum((u*(1-sigma)*K(t) for r,u,sigma in atoms if t/scale<r<=t),F(0))
    future_theta=t**n*sum((u*(1-sigma)*K(r) for r,u,sigma in atoms if t<r<scale*t),F(0))
    past=(J(t)-J(t/scale))/D(t);future=sum((u/D(r) for r,u,sigma in atoms if t<r<scale*t),F(0));bound=past+future
    ck(theta==past_theta+future_theta,'near_ties_assigned_once_to_past',{'case':name,'H':str(H),'t':str(t),'s':str(scale)})
    ck(past_theta<=past and future_theta<=future,'exact_near_past_and_future_bounds',{'case':name,'H':str(H),'t':str(t),'s':str(scale)})
    ck(theta<=min(F(1),bound),'exact_near_anchor_le_min_one_prefix_bound',{'case':name,'H':str(H),'t':str(t),'s':str(scale)})
    ratio_exceeds_one+=int(bound>1);quiet_hits+=int(bound<=ETA)
    if scale*t==b:
     ck(all(r!=b for r,u,sigma in atoms if t<r<scale*t),'strict_near_upper_b_excludes_terminal_atom',{'case':name,'H':str(H),'t':str(t),'s':str(scale)})
    records.append({'H':H,'s':scale,'anchor_t':t,'Theta':theta,'past_ratio':past,'future_ratio':future,'prefix_sum_may_exceed_one':bound,'gain_union_paid':paid,'gain_complement_unpaid':unpaid,'actual_target_T':target,'gain_low_receiver_atoms':lowcount,'gain_rapid_receiver_atoms':rapidcount})
 if name in ['rapid_n16','rapid_n64']:ck(any(record['gain_rapid_receiver_atoms']>0 and record['gain_union_paid']>0 for record in records),'nontrivial_rapid_union_branch_is_exercised',{'case':name})
 return {'name':name,'n':n,'atoms':[{'radius':r,'U_mass':u,'sigma':s} for r,u,s in atoms],'H_values':Hs,'rapid_configurations':rapid_hits,'terminal_rapid_impossibility_tests':terminal_hits,'near_prefix_sum_greater_than_one_cases':ratio_exceeds_one,'near_bound_le_eta_cases':quiet_hits,'records':records}
settings=[('initial',[('three_atoms_n1',1,[(1,1,0),(F(3,2),2,1),(2,3,0)]),('three_atoms_n4',4,[(1,2,1),(F(5,4),3,0),(2,1,1)])]),('atoms_endpoints_H_crossing',[('seven_eighth_gate_equality',1,[(1,7,1),(1,1,0),(F(5,4),1,0),(F(3,2),4,1),(2,2,0)]),('all_bad_tied_n4',4,[(1,1,0),(1,2,0),(F(5,4),16,0),(F(3,2),64,0),(2,128,0)]),('all_captured_n16',16,[(1,1,1),(F(4,3),8,1),(2,100,1)])]),('expanded_rapid_and_mass_range',[('rapid_n16',16,[(1,1,0),(F(3,2),1,1),(F(3,2)*F(1025,1024),10**6,0),(2,1,0)]),('rapid_n64',64,[(1,1,0),(F(3,2),1,1),(F(3,2)*F(16385,16384),10**12,0),(2,1,0)]),('tiny_mass_n64',64,[(1,F(1,10**9),0),(F(33,32),F(1,10**6),1),(F(17,16),1,0),(2,10**9,1)])])]
stages=[{'name':stage,'cases':[analyze(name,n,atoms) for name,n,atoms in models]} for stage,models in settings]
quiet_delta=ETA/2;loss=F(1,8);union_gain=ETA;quiet_near=ETA;remaining=1-4*(loss+union_gain+quiet_near)
ck(quiet_delta==F(1,64) and 2*quiet_delta==ETA,'integration_eta_and_quiet_delta_constants',{})
ck(remaining==F(1,4) and F(128)/remaining==512 and F(4)/remaining==16,'exact_final_512_16_absorption_coefficients',{})
for base in [F(0),F(1,16),F(1),F(10**9)]:
 for residual in [F(0),F(1,7),F(16)]:
  Tmax=512*base+16*residual;B=(loss+union_gain+quiet_near)*Tmax+residual
  ck(Tmax==128*base+4*B,'exact_final_absorption_boundary_equality',{'lambda_d_W':str(base),'Rnear_plus_Rgain':str(residual)})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Finite scalar atomic-CDF algebra with original unmarked J and binary capture sigma. Atomic U/radius/mask configurations are not claimed to realize complete original low/e/m, selector, forest or source histories. No full-input or root-payment certificate.','K':'Integral_[r,b] ell_n(dv) 1{J(v)>=H,p(v)<7/8}/J(v), p=captured_prefix/J, b=2. On each right-continuous CDF interval ell mass=left^-n-right^-n; terminal b^-n atom included.','near':'Theta=t^n sum Ubad 1{t/s<R<st}K(max(t,R)); ties R=t appear once in past. Theta<=min(1,(J(t)-J(t/s))/D(t)+sum_(t<R<st)deltaJ/D(R)). The prefix sum itself may exceed1.','rapid':'For r<=t<=b:K(r)<=(r^-n-t^-n)/D(r)+t^-n/D(t). If(t/r)^n<=1/(1-delta),D(t)>=D(r)/delta then r^n N(r/s)K(r)<=(2delta-delta^2)N(r/s)/D(r)<=2delta. Terminal r=t=b cannot meet growth.','gain_union':'eta=1/32,delta=eta/2. Disjoint low rho<=eta and rho>eta with a tested rapid witness give one eta*T payment. Complements remain their exact original gain fee. Search only the listed finite rational t menu, not all possible t.','integration_constants':'Assuming T<=128 lambda dW+4B and B<=(1/8+eta+eta)T+Rnear+Rgain, exact algebra gives T<=512 lambda dW+16(Rnear+Rgain). This checks constants, not the unimplemented near-quiet/source hypotheses.','check_counts':COUNTS,'failures':FAIL,'stages':stages}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=lambda x:str(x) if isinstance(x,F) else None,sort_keys=True,indent=2)+'\n')
lines=['# R307 finite gain and near-anchor diagnostics','',out['scope'],'',out['K'],'',out['near'],'',out['rapid'],'',out['gain_union'],'',out['integration_constants'],'','|model|n|rapid configurations|prefix sum>1|terminal impossibility tests|','|---|---:|---:|---:|---:|']
for st in stages:
 for c in st['cases']:lines.append(f"|{c['name']}|{c['n']}|{c['rapid_configurations']}|{c['near_prefix_sum_greater_than_one_cases']}|{c['terminal_rapid_impossibility_tests']}|")
lines+=['','All comparisons and all interval/atom layer integrals use Fraction. Models include tied receiver radii, zero target traffic, p=7/8 gate equality, H equal to a CDF atom, strict separation endpoints, terminal b atoms, rapid jumps and masses from1e-9 to1e12. Finite evidence only.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'rapid':c['rapid_configurations'],'prefixsum_gt1':c['near_prefix_sum_greater_than_one_cases']} for st in stages for c in st['cases']]},indent=2));assert not FAIL,FAIL
