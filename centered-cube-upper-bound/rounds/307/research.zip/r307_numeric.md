# R307 finite gain and near-anchor diagnostics

Finite scalar atomic-CDF algebra with original unmarked J and binary capture sigma. Atomic U/radius/mask configurations are not claimed to realize complete original low/e/m, selector, forest or source histories. No full-input or root-payment certificate.

Integral_[r,b] ell_n(dv) 1{J(v)>=H,p(v)<7/8}/J(v), p=captured_prefix/J, b=2. On each right-continuous CDF interval ell mass=left^-n-right^-n; terminal b^-n atom included.

Theta=t^n sum Ubad 1{t/s<R<st}K(max(t,R)); ties R=t appear once in past. Theta<=min(1,(J(t)-J(t/s))/D(t)+sum_(t<R<st)deltaJ/D(R)). The prefix sum itself may exceed1.

For r<=t<=b:K(r)<=(r^-n-t^-n)/D(r)+t^-n/D(t). If(t/r)^n<=1/(1-delta),D(t)>=D(r)/delta then r^n N(r/s)K(r)<=(2delta-delta^2)N(r/s)/D(r)<=2delta. Terminal r=t=b cannot meet growth.

eta=1/32,delta=eta/2. Disjoint low rho<=eta and rho>eta with a tested rapid witness give one eta*T payment. Complements remain their exact original gain fee. Search only the listed finite rational t menu, not all possible t.

Assuming T<=128 lambda dW+4B and B<=(1/8+eta+eta)T+Rnear+Rgain, exact algebra gives T<=512 lambda dW+16(Rnear+Rgain). This checks constants, not the unimplemented near-quiet/source hypotheses.

|model|n|rapid configurations|prefix sum>1|terminal impossibility tests|
|---|---:|---:|---:|---:|
|three_atoms_n1|1|14|2|18|
|three_atoms_n4|4|6|2|24|
|seven_eighth_gate_equality|1|16|4|24|
|all_bad_tied_n4|4|19|13|24|
|all_captured_n16|16|0|1|18|
|rapid_n16|16|36|6|18|
|rapid_n64|64|38|6|18|
|tiny_mass_n64|64|0|9|24|

All comparisons and all interval/atom layer integrals use Fraction. Models include tied receiver radii, zero target traffic, p=7/8 gate equality, H equal to a CDF atom, strict separation endpoints, terminal b atoms, rapid jumps and masses from1e-9 to1e12. Finite evidence only.
