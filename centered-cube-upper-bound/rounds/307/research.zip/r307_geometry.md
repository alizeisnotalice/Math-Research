# R307 — original binary gain, a stronger prefix quotient, and a paid row-growth branch

## 1. Exact candidate, retained original hypotheses and result

Use the SAME original field and notation as the frozen /tmp/r306_geometry.md: full-soft p_y=P_(s(x),L(x))(x-y), a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, original FIRST, SAME-R hard cap on E, full-original e_g and low-pe/m>M qualifications, actual aspect v>=v0, original sources beta and nu, and the fixed source restriction nu_*<=nu without recomputing any gate. Keep

    U_y(x)=1_E alpha(x,y)p_y(x)/q(x),
    0<=I0<=alpha<=1, b_y=I0/alpha on alpha>0, otherwise zero,
    sigma_theta(x,y,z)=1{z in Q_R(x)(x)}1{b_y(x,z)>=theta},
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_theta(y,z;r)=integral_{R(x)<=r}U_y(x)sigma_theta(x,y,z)dx,
    p_theta=A_theta/J_y when J_y>0,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr,
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n,
    d=kappa0 psi_inf/(q_-v0), H=8d,
    A_n=1+n log(b/a).

Theta belongs to (0,1]; its zero endpoint is set to zero. Positive-theta support inherits the original point-height/aspect qualifications, and all U,J,d,H and sources stay fixed as theta varies. Write the exact actual target measure at fixed theta as

    dmathcalT_theta(y,z,w)
       =beta(dy)nu_*(dz)U_y(w)sigma_theta(w,y,z)R(w)^(-n)dw.

Its total mass T_theta is finite, T_theta<=A_n W_nu* by original FIRST, and integral_0^1 T_theta dtheta=T. Thus all payments below use the original qualified first moment, not its unqualified enlargement.

Fix a separation k>1. Define

    N_theta(y,z;t)=integral_{R(u)<=t}U_y(u)[1-sigma_theta(u,y,z)]du,
    D_y(r)=max(H,J_y(r)),
    rho_theta(y,z;r)=N_theta(y,z;r/k)/D_y(r),             (1)

with N(t)=0 for t<a. The ORIGINAL remaining incidence kernel is

    K_theta(y,z;r)=integral_[r,b] ell_n(ds)
          1{J_y(s)>=H,p_theta(y,z;s)<7/8}/J_y(s).         (2)

The exact R306 separated gain is

    G_theta(k)=integral beta nu_* dw U_y(w)sigma_theta(w,y,z)
                           N_theta(y,z;R(w)/k)K_theta(y,z;R(w)). (3)

The first rigorously payable branch is rho<=eta, with price eta T_theta. This is stronger than the proposed N/J<=eta branch: D=max(H,J) also treats targets whose current prefix is below H but whose future incidence enters the H gate.

There is a second, genuinely additional branch, including points with rho>eta. For 0<delta<1, put

    t_delta(r)=min(b, r(1-delta)^(-1/n)),
    Rapid_delta(y,r)={D_y(t_delta(r))>=D_y(r)/delta}.     (4)

For 0<eta<1 and delta=eta/2, the union

    P_eta(theta,y,z,w)
       ={rho_theta(y,z;R(w))<=eta} UNION Rapid_(eta/2)(y,R(w)) (5)

has total GAIN fee at most eta T_theta, with no factor two:

    G_theta^paid(k,eta)<=eta T_theta.                   (6)

The union is integrated against the exact gain measure in (3), not against a newly invented target. It enlarges the paid set beyond small old-prefix quotient because actual future row growth can make the original denominator large. The full complement retains BOTH conditions

    rho_theta(y,z;r)>eta,
    D_y(t_(eta/2)(r))<2D_y(r)/eta.                      (7)

These are actual original row quantities. They do not follow automatically from FIRST or a source density claim. The proof also supplies the sharper all-input gain upper bound (12), and the root source receipt (15), but not a root bound on the whole complement (7).

## 2. Exact gain formula and inclusive atoms

R306 orders receiver pairs by R(u)<R(w) and calls sigma(u)=0,sigma(w)=1 a gain. On the separated region R(w)>=kR(u), k>1, strict ordering is automatic. At a fixed capturing receiver w with radius r, the earlier noncapturing mass is exactly N(r/k), INCLUDING a radius atom at r/k. Hence positive Tonelli gives (3), retaining every original source/history factor inside sigma and the original p<7/8 restriction inside K.

J_y(r) is inclusive, including all receivers of radius exactly r. For s>=r one has J_y(s)>=J_y(r), and on the original integration gate J_y(s)>=H. Thus

    1{J_y(s)>=H,p_theta(s)<7/8}/J_y(s) <=1/D_y(r),
    K_theta(y,z;r)<=r^(-n)/D_y(r).                     (8)

This proves G restricted to {rho<=eta} <=eta T_theta. No assumption of a continuous pushforward radius distribution is used. In particular one must not use J_y(r-) in the denominator at a capturing atom. If J_y(r)=0, the actual capturing receiver contribution vanishes almost everywhere under U_y(w)dw; D>=H>0 in any event makes all displayed quotients defined.

The numerator N(r/k) obeys 0<=N(r/k)<=J_y(r), so 0<=rho<=1. No captured source mass is falsely assigned to the old noncapturing receiver. The actual hard source in (3) is still captured only by w.

## 3. A two-endpoint denominator bound and actual row-growth dissipation

For ANY r<=t<=b, split the true scale measure into [r,t) and [t,b]. Since D is nondecreasing,

    K_theta(y,z;r)
      <=[r^(-n)-t^(-n)]/D_y(r)+t^(-n)/D_y(t).          (9)

For the first interval, on its original gate J_y(s)>=D_y(r). For the second interval, J_y(s)>=D_y(t). The scale identities are exact:

    integral_[r,t) ell_n(ds)=r^(-n)-t^(-n),
    integral_[t,b] ell_n(ds)=t^(-n).

At t=b the second interval includes the endpoint atom. At r=t the first interval is empty. If J crosses H or jumps exactly at t, its inclusive value J(t) is the correct denominator on the second interval. No right/left approximation or continuity assumption is needed.

Let v=(r/t)^n and define

    F_y(r,t)=1-v+v D_y(r)/D_y(t), 0<=F<=1.             (10)

Multiplying (9) by N(r/k) gives the all-input estimate

    G_theta(k)
      <=integral dmathcalT_theta(y,z,w)
                    rho_theta(y,z;r) F_y(r,t(r)), r=R(w), (11)

for any specified measurable row-scale choice t(r) in [r,b]. We use ONLY the canonical choice (4); there is no favorable witness or source-wise selector. Equivalently, this gives the explicit nonnegative improvement over the old quotient upper budget:

    G_theta(k)
      <=integral dmathcalT_theta rho_theta
          -integral dmathcalT_theta rho_theta (r/t)^n
                                 [1-D_y(r)/D_y(t)].    (12)

The second term is an actual prefix-growth saving on the SAME original data. It is not separately spent a second time. The original p<7/8 restriction remains in the gain on the left; dropping it only in the positive denominator estimates (8),(9) is an authorized majorant, not a redefinition of G.

For t=t_delta(r), one has (r/t)^n>=1-delta even if the scale is clipped at b. On Rapid_delta, D_y(r)/D_y(t)<=delta. Hence

    F_y(r,t)<=1-(r/t)^n+delta(r/t)^n<=2delta.           (13)

Therefore the gain on Rapid_delta is at most 2delta times its OWN original capturing-target mass. With delta=eta/2, split (5) disjointly into {rho<=eta} and {rho>eta} intersect Rapid_delta. On the first part use (8); on the second use (13) and rho<=1. Each pointwise majorant is eta dmathcalT_theta. Their disjoint union therefore costs eta T_theta, proving (6), rather than adding two full copies of eta T_theta.

When r=b, t_delta(r)=r and D(t)=D(r)>0; Rapid_delta is empty for delta<1. Thus the physical terminal atom receives no fictitious future growth. Its possible payment is through the first branch only. This also identifies a real limiting case of the mechanism.

## 4. Source-linear receipt, common theta and original coefficients

Averaging the exact positive split of (3),

    G_theta=G_theta^paid+G_theta^persist,
    integral_0^1 G_theta^paid dtheta<=eta T,             (14)

where persist is exactly (7). No nu source is copied over scales or theta, and all original outer data are held fixed. This proof changes no witness law and passes no pair-dependent quotient to an own-scale source-allocation lemma. It is an estimate of the existing gain integral, so there is no uncharged selection fee.

There is also the unconditional source receipt for this real positive incidence component:

    integral_0^1 G_theta^paid dtheta<=eta A_n W_nu*.     (15)

Taking eta=min(1/8,A_n^(-1/2)) pays it by sqrt(A_n)W_nu*, including all original binary/history inputs. This is a source-linear root payment for the UNION (5), not for all gains. One may instead use (14) for self-absorption; these are alternative receipts for the same component.

Retain the exact R306 near term, including radius ties, and its paid far-loss bound k^(-n)T. The R305 full entry consequently gives, when 1-4k^(-n)-4eta>0,

    [1-4k^(-n)-4eta] Lambda T
      <=128 Lambda lambda d W_beta
          +4 Lambda integral_0^1
                        [B_theta^near(k)+G_theta^persist(k,eta)]dtheta. (16)

All original aspect and height costs remain in

    lambda d=(4/3)kappa0 psi_inf/v0, kappa0=2K/(ell M).

For example k^n=16, eta=1/16, delta=1/32 give

    Lambda T<=256 Lambda lambda d W_beta
          +8 Lambda integral_0^1
                         [B_theta^near(16^(1/n))+G_theta^persist]dtheta. (17)

If k>b/a the far gains and losses are empty, and this example supplies no false nonempty far payment. The near term has changed with k and must be retained at its displayed value. A comparison with a different k cannot silently keep the old near term.

Original FIRST provides T_theta<=A_nW_nu* and hence legitimate finite self-absorption. The hard cap and point-height conditions enter the imported d/source fee, not a newly inferred density bound. If either original source mass is zero, all contributions vanish. All formulas hold conditionally on the original outer field: multiply every chosen receipt by its original positive Lambda inside the original outer integral. No full-ledger completion is asserted.

## 5. What remains and what was genuinely improved

The initial small-old-prefix criterion has been proved with inclusive J and strengthened to N/max(H,J). The additional rapid-row-growth criterion pays actual high-rho gains as well, with the SAME eta coefficient on their union. Formula (12) improves the old quotient upper budget strictly when D_y(t)>D_y(r) on a set of positive original capturing-target measure with N>0. An increase of J that remains below H does not suffice, because D=max(H,J) is then unchanged. It uses the real denominator growth in the original incidence integral, without inventing captured mass at the smaller receiver. These are new positive payments and a retained quantitative saving, not a claim that changing the name of the residual solves it.

The remaining separated gain has a quantitatively persistent structure: substantial old NONcapture N(r/k)>eta max(H,J(r)) survives, while the same actual row has no factor 2/eta increase up to t_(eta/2)(r). This structure can arise from physical noncapture, true binary history variation, or both. FIRST gives only integral U_y(w)beta(dy)<=1_E(w); it has not here been proved to force small capturing traffic on this persistent-row set. The existing full-soft row upper bound also bounds J but does not turn these two lower/upper prefix facts into a root-order cross-row source price. Same-R hard caps do not supply source density on the noncapture portion.

The exact outstanding integrated estimate is a source-linear root bound, possibly with an absorbable coefficient of T, for the true G restricted to (7), together with the separately retained near/tie term. A useful upper object retaining the new saving is

    integral_0^1 integral dmathcalT_theta
       1{rho>eta, D(t_delta(r))<D(r)/delta}
                    rho F_y(r,t_delta(r)) dtheta, delta=eta/2. (18)

This is an explicit majorant of the remaining gain, not a demonstrated source payment. Bounding it by T merely recovers a useless unit gain coefficient. A proof of a stronger price must use actual common-soft geometry, the original qualifications and shared FIRST beyond the monotonicity of J used here. No generic all-input root budget for (18) is claimed, and no near/far spatial subcase is substituted for that missing result.

## 6. Actual finite diagnostics, not a substitute for the remaining geometric proof

After correcting the transcribed weights index to radii[i], the complete embedded code was extracted and rerun in a fresh isolated Python process (python3 -I -c), which exited 0. This exact standard-library Fraction run checked 1080 two-endpoint bounds, 3240 gain quotient bounds, 423 nonvacuous rapid-growth receipts, 9224 union receipts and 216 cases where the prefix crossed H between the two endpoints. It used n=1,2,8,32; five rational physical radii with a very narrow initial gap; two strongly unequal row-mass profiles; alternating and one-birth binary qualifications; three prefix thresholds and three separation factors. The terminal atom, equal endpoints and strict p<7/8 gate were kept. These finite prefix models may be represented by qualifying subsets of common geometric captures; they do not certify full original low-pe/e_g realizability. The inequalities are proved above. Reproduction uses no additional file:

```python
from fractions import Fraction as F
from itertools import product
ct=dict(endpoint=0,gain_ratio=0,rapid_payment=0,union=0,atomic_crossing=0)
for n in (1,2,8,32):
 radii=[F(1),F(1001,1000),F(5,4),F(3,2),F(2)]
 for masses,H,pattern in product(([F(1,100),F(1),F(1,10),F(2),F(1)], [F(1),F(1,100),F(3),F(1,10),F(2)]),(F(1,10),F(1),F(4)),(0,1,2)):
  cap=[(i+pattern)%2 for i in range(5)] if pattern<2 else [0,0,1,1,1]
  J=[sum(masses[:i+1]) for i in range(5)];A=[sum(masses[j]*cap[j] for j in range(i+1)) for i in range(5)]
  weights=[radii[i]**(-n)-(radii[i+1]**(-n) if i<4 else 0) for i in range(5)]
  gate=[int(J[i]>=H and A[i]/J[i]<F(7,8)) for i in range(5)]
  K=[sum(weights[j]*gate[j]/J[j] for j in range(i,5)) for i in range(5)]
  for i,tidx in product(range(5),repeat=2):
   if tidx<i:continue
   r,t=radii[i],radii[tidx];D=max(H,J[i]);Dt=max(H,J[tidx]);v=(r/t)**n
   bound=(r**(-n)-t**(-n))/D+t**(-n)/Dt
   assert K[i]<=bound;ct['endpoint']+=1
   if J[i]<H<=J[tidx]:ct['atomic_crossing']+=1
   for sep in (F(1001,1000),F(5,4),F(2)):
    N=sum(masses[j]*(1-cap[j]) for j in range(i) if radii[j]<=r/sep)
    rho=N/D;psi=1-v+v*D/Dt
    assert K[i]*N<=r**(-n)*rho*psi<=r**(-n);ct['gain_ratio']+=1
    for delta in (F(1,8),F(1,4),F(1,2)):
     rapid=(v>=1-delta and Dt>=D/delta)
     if rapid:
      assert rho*psi<=2*delta;ct['rapid_payment']+=1
     eta=2*delta
     paid=(rho<=eta or rapid)
     if paid:
      assert K[i]*N<=eta*r**(-n);ct['union']+=1
print('PASS',ct)
```

Only /tmp/r307_geometry.md was written. No other author's file, earlier frozen proof or Git state was modified.
