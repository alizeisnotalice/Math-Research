# R185 affinity diagnostics

This is a numerical diagnostic of the stated one-dimensional affinity envelope. It makes no theorem certification or claim about arbitrary-source mixtures, the raw budget, or the full physical model. All six requested physical parameter cases were evaluated with `mpmath` quadrature at 25 and 40 decimal digits; the recorded precision differences are empirical comparisons, not rigorous error bounds. The tau identity was checked independently by direct quadrature of `phi` on `[-1/2,1/2]` and agreed with `1/3 + 2 E4(1)` to the displayed precision (`tau_difference = 0.0`).

The script splits the integral at both hard support endpoints `±H/2` and soft profile seams `d-b/2`, `d`, and `d+b/2`. For `s=0`, it integrates only the exact compact support of the hard density; no tail is truncated. For `s>0`, it integrates over the full real line using infinite endpoints. `phi` is evaluated by the specified `E3` formulas. The script accepts `--output`; run it with the installed runtime on `PYTHONPATH`, for example:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
  python affinity_checks.py --output affinity_checks.json
```

The six actual affinities and pointwise envelope values at 40 dps are:

| Case | Stage | `(s,H,b,d)` | Affinity | `a(s)` | Observed gap |
|---|---|---|---:|---:|---:|
| initial_centered | initial | `(1/2, 3/4, 1, 0)` | 0.9298827471 | 0.9665188853 | 0.0366361383 |
| initial_shifted | initial | `(1/4, 3/4, 1, 1/3)` | 0.8191507346 | 0.9128275746 | 0.0936768399 |
| hard_face_touch | stress | `(0, 1/2, 1, 1/2)` | 0.4375709432 | 0.7109559170 | 0.2733849739 |
| soft_endpoint | stress | `(1, 1, 1, 0)` | 1.0000000000 | 1.0000000000 | 0 |
| expanded_narrow_shift | expanded | `(1/2, 1/4, 1/2, 3/8)` | 0.6880128156 | 0.9665188853 | 0.2785060697 |
| expanded_wide_shift | expanded | `(3/4, 1, 2, 3/2)` | 0.7468670598 | 0.9921834013 | 0.2453163415 |

All six observed values satisfy `affinity <= a(s)` at the evaluated precision. The 25-to-40 dps absolute changes range from zero to `4.49e-27`. This is evidence about these evaluations only and does not establish the inequality.

The scalar table in `affinity_checks.json` records `a(s)^n` and the full factor `e(n+1)(1+(n/2)log 2)a(s)^n` for each of `n = 8, 64, 512, 4096` and `s = .25, .75, .95, .999`. It shows that the polynomial prefactor can dominate at moderate dimensions when `s` is large: for example, at `s=.95,n=512`, `a^n ≈ .855` while the full envelope is about `212732`; at `s=.25,n=512`, the corresponding values are about `5.24e-21` and `1.30e-15`. Thus the requested expression is reported without fitting an order or imposing an unrequested cap at one.

Reproduction used only the standard-library modules and `mpmath 1.3.0` from the runtime vendor directory specified in the task. The JSON records the `task_contract.md` SHA-256 and the mpmath version. No vendor-specific absolute path is embedded in the script or JSON.
