#!/usr/bin/env python3
"""Finite rational checks of MA11--15 algebra, not physical FIRST instances."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,hashlib

def run_case(name, stage, scale=F(1), parent=F(4), weight_scale=F(1), pyroot=F(2), jroot=F(1), active=F(3,4)):
    nu=[scale,2*scale]; beta=[scale,scale/2]; M=parent*scale
    assert M>=sum(nu) and M>=sum(beta) and M>0
    p_roots=[pyroot,3*pyroot/2]; j_roots=[jroot,4*jroot]
    A=[active,F(0)]; score=[3,1]
    weights=[[weight_scale,weight_scale],[weight_scale/2,weight_scale*F(3,4)]]
    dt=[F(1,3),F(2,5)]
    pi_mass=sum(beta)*sum(nu)**2/M**2
    assert pi_mass<=M
    direct=F(0); rebuilt=F(0); entries=[]
    for y in range(2):
      for u in range(2):
       for v in range(2):
        time=F(0)
        for t in range(2):
          e=sum(weights[t][i]*nu[i] for i in range(2))
          mask=F(u==1 and v==0)
          time+=dt[t]*mask*max(score[v]-score[u],0)*weights[t][u]*weights[t][v]/e**2
        density=p_roots[y]**2*A[v]*time
        B=M**2*(p_roots[y]/j_roots[v])*A[v]*time
        K=p_roots[y]*j_roots[v]
        pi=beta[y]*nu[u]*nu[v]/M**2
        d=density*beta[y]*nu[u]*nu[v]
        assert d==K*B*pi
        direct+=d;rebuilt+=K*B*pi
        entries.append((B,K,pi,d))
    assert direct==rebuilt
    positive=[row[0] for row in entries if row[0]>0]
    cutoff=min(positive) if positive else F(1)
    actual=sum(d for B,K,pi,d in entries if B<=cutoff)
    capped=cutoff*sum(K*pi for B,K,pi,d in entries if B<=cutoff)
    assert actual<=capped
    return {'name':name,'stage':stage,'pi_mass':str(pi_mass),'M':str(M),'direct':str(direct),'rebuilt':str(rebuilt),'positive_B':[str(x) for x in positive],'cutoff':str(cutoff),'cut_raw':str(actual),'cut_upper':str(capped),'pass':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
    specs=[('base','initial',{}),('small_target','initial',{'active':F(1,1000)}),('inactive','initial',{'active':F(0)}),
      ('large_parent','stress',{'parent':F(2**30)}),('small_mass','stress',{'scale':F(1,2**40)}),('large_mass','stress',{'scale':F(2**40)}),
      ('small_weight','expanded',{'weight_scale':F(1,2**40)}),('high_density_ratio','expanded',{'pyroot':F(2**30),'jroot':F(1,2**30)}),('low_density_ratio','expanded',{'pyroot':F(1,2**30),'jroot':F(2**30)})]
    rows=[run_case(n,s,**kw) for n,s,kw in specs]
    assert rows[0]['positive_B']==rows[4]['positive_B']==rows[5]['positive_B']==rows[6]['positive_B']
    assert F(rows[4]['direct'])*2**40==F(rows[0]['direct'])
    assert F(rows[5]['direct'])/2**40==F(rows[0]['direct'])
    assert rows[0]['direct']==rows[3]['direct']==rows[6]['direct']
    assert F(rows[3]['pi_mass'])*F(rows[3]['positive_B'][0])==F(rows[0]['pi_mass'])*F(rows[0]['positive_B'][0])
    # M=0 forces beta=nu=0 under common-parent domination: dispatch before division.
    zero_dispatch={'M':'0','beta_mass':'0','nu_mass':'0','raw':'0','division_performed':False}
    base=Path(__file__).resolve().parent
    result={'scope':'finite rational factorization and positive cutoff only; not physical time/FIRST/history or kernel integration',
       'source_sha256':{name:hashlib.sha256((base/name).read_bytes()).hexdigest() for name in ['triple_factor_check.py','mixed_affinity_raw_budget.md']},
       'cases':rows,'zero_dispatch':zero_dispatch,'summary':{'exact_cases':len(rows),'all_pass':True,'mass_scaling_pass':True,'parent_normalization_pass':True}}
    out=a.output or base/'triple_factor_check.json';out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(result['summary']))
if __name__=='__main__':main()
