# R185：同一储备似然的校准权重与原互反交通根阶付款

本文给出一个新的、无需未知矩假设的原加权 companion 估计。用实际同 alpha 的 bad 储备相对于 current 来源容量的似然，精确抵消原 companion 的 rho²，得到比 R184 已付包络逐点更大的校准权重；其全局价格仍是两个端点的价格。因而它支付原中央低旧包络、高 A 域中一个明确的正子支。本文不证明剩余低校准权重子支小，也不声称已经认证原物理模型中的严格覆盖扩大或一般根阶结论。

## JP1. 范围、原对象与来源账

固定原 (omega,V,a,b,q) 窗口，a≤L,R≤b≤2a，保留真正唯一标签 j(x)、共同阈值 q>0、原接收域 E_rec、原 FIRST 选择 s,L。写

    p_z=P_(s,L)(x−z),       J_z=P_(1,b)(x−z),
    gamma=1+1/n,            Lplus=min(b,gamma L),
    Q_z=(p_z+P_(s,Lplus)(x−z)+J_z)/3,
    QJ=∫J_z nu(dz).

nu、beta 分别受同一父来源 A_V 支配；不假设 nu≤beta，也不把 beta−nu 当正测度。原来源合同与 FIRST 只需给出

    ∫p_z nu(dz)≤q,        ∫p_y beta(dy)≤q,
    Wnu=E_omega Σ_V||nu_V||≤WA≤||f||_1.                 (JP1)

对独立重复窗口，应保留真实窗口求和，不免费复用最后一个质量不等式。本稿不用 QJ≤q，也不用每叶质量帽。所有 dx 均在原 E_rec（或原有限接收截断）上；仅在明确的正固定 J 核积分处扩大接收域。

保留 R183 JG2/R184 KG 的实际尺度：

    c_j=gamma^(−j), g=√(LR), ell_n=1+log n,
    T=c_j^(n/2)/(g^n√ell_n),
    H0=g c_j^(−1/2)(1−s+s phi(1/2)) ell_n^(1/(2n)),
    Hhat=max(a,min(b,H0)),   K0_z=P_(s,Hhat)(x−z),
    k_z=D K0_z,             a_v=T Delta_y(v),
    Delta_y(v)=w_tau(y,v)−w_hstop(y,v).

D≥1 是原继承常数，不是本稿新选参数。原非空 far 窗口有 tau<hstop≤g。k_z 是静态储备密度；下文辅助时间分数 k_t(y,z) 是另一对象，不能混用。严格软资格 s>1−2^(−1/n)>0 只用于原核正性，不代表 s 接近 1。

## JP2. 实际同 alpha 与互反行

原 capture 集 E_y 与实际 terminal bad 集 B_y 不交，且

    U_y(v)=1_Ey(v) min(a_v,k_v),
    alpha_y QJ=Dq−∫U_y nu,
    rho_v=[1−(k_v+alpha_y J_v)/a_v]_+ on E_y,
    rho=0 off E_y or when a_v=0.                         (JP2)

这是指定原 RC 重构的实际余权，不是对任意较小余权的稳定结论。由合法 K0 的 FIRST 容量，k nu≤Dq；保持同一个 alpha 得

    0≤alpha QJ≤Dq,       ∫_B k_u nu(du)≤alpha QJ.        (JP3)

原好槽和 high 条件为

    p_y w_g(y,v)≤K Q_v,
    A_y(v)=1_good rho_v J_v/(3Q_v),
    p_y e_g(y)≥2Kq,      e_t(y)≥e_g(y) on actual t≤g.

实际应用 K=1；保留 K 是追踪常数，不授权改变原门。

原基本 bad 记 b_x(y,u)=1{p_y w_g(y,u)>K Q_u}。本文坏槽域为

    Brec_y=B_y∩{b_x(y,u)b_x(u,y)=1}.

转置基本 bad 只定义该物理子域，不声称转置后的点具有原 high/history 资格。置

    d_n=(1+gamma^(−n))/3,       kappa=K d_n.

由径向单调 Q_z≥d_n p_z，互反两条严格不等式给

    w_g(y,u)>kappa,
    kappa/w_g(y,u)<p_y/p_u<w_g(y,u)/kappa.               (JP4)

kappa≥1 时互反域为空，以下只讨论 kappa<1。所有结论均保留 good-v 与 bad-u 两条不同的边；不能用 JP4 替换 good 边的重叠。

## JP3. 原后验与两项实际来源容量

保持原后验

    Pi_y,t(du)=1_Zy,t(u) w_t(y,u) nu(du)/e_y,t,
    e_y,t=∫_Zy,t w_t(y,u)nu(du),       w_g≤w_t≤1.

不重选 Z、不重归一 bad 子域，也不重算 alpha。在 alpha>0、QJ>0 的有效行上定义两项有限正测度

    P_y(du)=1_Brec_y(u) p_u nu(du)/q,
    S_y(du)=1_Brec_y(u) k_u nu(du)/(alpha QJ),
    L_y(u)=q k_u/(alpha QJ p_u)=dS_y/dP_y.               (JP5)

两者都是 subprobability；实际质量不补成 1。原严格软核在有限位置正，故上述实际有效行的似然正常。由 high、e_t≥e_g 及 JP4，

    q w_t(y,u)/(e_t p_u)
       ≤w_t(y,u)w_g(y,u)/(2K kappa)
       ≤1/(2K kappa).

因此仅在 Brec_y 上有测度支配

    1_Brec_y Pi_y,t≤P_y/(2K kappa).                     (JP6)

式中原 1_Z 不被替换；上式只是正上界。它不是全空间 Pi≤P。

对先于当前 u 积分选定的任意 r∈(0,1)，同一来源的 Holder 给

    ∫_Brec L^r Pi
       ≤(2K kappa)^−1∫L^r dP
       ≤(2K kappa)^−1||S||^r||P||^(1−r)
       ≤1/(2K kappa).                                  (JP7)

r=0、1 分别直接使用 ||P||、||S||，不定义 0^0。r 可依 x,y,t,v 与原共同数据，但不能在此步依正在积分的 u。两个端点合并则允许真正逐 pair 的选择：

    ∫_Brec max(1,L)Pi
       ≤m_join(y)/(2K kappa)≤1/(K kappa),
    m_join=∫max(1,L)dP=||P∨S||≤||P||+||S||≤2.          (JP8)

保留实际密度时 m_join=(||P||+||S||+||P−S||_TV)/2；这里 TV 是全变差范数。此恒等式不把任一来源归一成概率，也不提供额外的小量假设。

## JP4. 精确零支与校准权重

QJ=0 时严格正 J 使 nu=0，无交通。alpha=0 时 JP3 及严格正 K0 使 B_y 的 nu 质量为零，也无本文交通；这一结论不推广到允许 K0=0 的任意抽象扩展。a_v=0、rho_v=0 或非 capture target 的原被积式先定义为零，随后不在该零支上形成除法。

在其余 active 槽上令 w_v=w_g(y,v)，定义

    Wcal_r(v,u)=w_v² L_y(u)^r/rho_v²,       0≤r≤1,
    Fcal(v,u)=w_v² max(1,L_y(u))/rho_v²
             =sup_(0≤r≤1) Wcal_r(v,u).                 (JP9)

最后一个上确界恰为两端点最大值，无连续参数菜单费用。Fcal 是原 companion 的正乘子，并不改变 rho、alpha、Pi 或任何原门。加权被积式在前述零支为零，不能先写 0×∞。实际有效有限数据上 JP9 可测。

## JP5. 新加权 companion 定理及其证明

用 H∈[0,1] 记录原全部剩余门，包括接收、good/capture、原 bad、互反、分数次序、history、原中央域、旧已付域的补集等；若某些门依 u，不得把它们提出 u 积分。保留显式 high、唯一 j 与 actual far，定义

    C_rec[F]=E Σ_(V,j)∫_Erec 1_{j(x)=j} dx
       ∫_high beta(dy)∫_actualfar dt/t
       ∬ H [p_y² rho_v² J_v/(9Q_v²)]
                   F(v,u)Pi_y,t(dv)Pi_y,t(du).          (JP10)

定理：对 JP7 许可的 r（包括两端点），以及真正 pair-adaptive 的 Fcal，

    C_rec[Wcal_r]≤log2/(36 kappa) Wnu,
    C_rec[Fcal]≤log2/(18 kappa) Wnu
               ≤log2/(18 kappa) WA.                    (JP11)

证明先在同一原行、active target 上精确消去 rho²，再正放大必要的额外门。JP7 与实际 good 给

    ∫ H [p_y² rho_v² J_v/(9Q_v²)] Wcal_r(v,u)Pi(du)
       ≤p_y² w_v² J_v/(18K kappa Q_v²)
       ≤K J_v/(18 kappa).                              (JP12)

对 Fcal 用 JP8，右端乘 2。这里没有先分别取 inverse K0、inverse alpha、inverse rho 的上确界；rho 的消去发生在原被积式内部，L 的积分由同一个实际 alpha 的储备支付。保留实际 m_join 时 JP12 对 Fcal 的右端可写 K J_v m_join/(18 kappa)，但本文的无条件结论只用 m_join≤2。

固定 x,V,j,t 后，原 high 列满足

    ∫_high beta(dy)∫J_v Pi_y,t(dv)
       ≤(J*nu)(x)∫_high beta(dy)/e_g(y)
       ≤(J*nu)(x)/(2Kq)∫p_y beta(dy)
       ≤(J*nu)(x)/(2K).                                (JP13)

这同时使用原 beta 和 nu 的合法来源容量，不要求两者相互支配。Q、a、K0 从未冒充归一核。

令 xi=c_jt/b。原 actual far 在 xi∈[1/2,1] 的可定义子域内，dt/t=d xi/xi。JP12–13 后上界已不依 t,j，才正扩大至该共同区间，收取 log2，并使用 Σ_j1_{j(x)=j}≤1。不能在前面分别扩大不同 j 的归一化后再免费相加。对该原窗口共同固定 b，J=P_(1,b) 是概率核，故

    ∫_Erec(J*nu)(x)dx≤∫_(R^n)(J*nu)(x)dx=||nu||.

Tonelli 后给出 JP11。所有 current 自适应 s,L 的费用在此前通过真实 good/high/current 条件消去；没有固定参数结果后免费取上确界，也没有额外 softness、scale 或 r 菜单。多个独立窗口继续保留真实质量求和。

## JP6. 回代原 raw：明确的根阶来源价格

预先取 theta>0，只在此前尚未支付的原正交通上使用门 Fcal≥theta。未加权 companion 在该门下由 JP11 支配为 log2 Wnu/(18 kappa theta)。原 R173/R181 修复后的单向固定 J 能量为

    E_J=EΣ_(V,j)∫1_j dx∫_high beta(dy)∫_actualfar dt/t
          ∬H J_v(k_t(y,v)−k_t(y,u))_+² Pi(dv)Pi(du)
       ≤n Wnu/(2K).

该质量是 Wnu，不是未经证明可替换的 Wbeta。两边使用同一个原正切片（分数门分到两个平方根），Cauchy 恢复一次 hard 帽16/3及一次原外系数2Lambda，得到

    Raw_rec^+[Fcal≥theta]
       ≤(32Lambda/3)√[n log2/(36K kappa theta)] Wnu
       ≤(32Lambda/3)√[n log2/(36K kappa theta)] WA.        (JP14)

theta 固定时为根阶；若 theta=theta_n 变小，明确支付 theta_n^(−1/2)。该结论不消费任何原负项或已经使用的 suffix 信用。它直接适用于原中央、低旧 Fsup、高 A 的交集，因所有这些限制只是 JP10 中原 H 的正切片。不需要先假定每行 near saturation。

更粗乘子 w_v²L^r（不除 rho²）及 w_v²max(1,L) 由 rho²≤1 也享受对应价格；它们不是本文的最强结论。后续若采用原 NB 冻结，仍须另保留其两槽 RN 比较和原接收误差；本文证明直接在原 Pi 上完成，无冻结误差。

## JP7. 对旧包络的全 active 点态支配

记

    d_v=[1−k_v/a_v]_+,       z_v=alpha J_v/a_v.

active 时 rho_v=d_v−z_v>0。旧 R183/JG、R184/AE 权重为

    F_r^old=w_v²(z_v L_y(u))^r/c_r,
    c_r=4r^r/(r+2)^(r+2) (0<r≤1),       c_0=1.

同一实际 scalar 系数满足

    rho_v² z_v^r≤c_r d_v^(r+2)≤c_r.                    (JP15)

证明只需令 z_v=d_v z，最大化 z^r(1−z)²；极值在 z=r/(r+2)。r=0 用 rho²≤1。因此每个 r 都有 F_r^old≤Wcal_r，取逐 pair 上确界给

    Fsup_old≤Fcal.                                      (JP16)

这不依赖高 A 门。旧 AE 包络已经以两端点价格支付；新 JP11 的同价估计由独立的 JP5 证明，不能从 JP16 反向推出来。JP16 只证明同阈值的集合包含，不证明存在原全部 FIRST/history/L1 资格下的严格差集。当前有限代数检验也不能认证严格物理覆盖扩大。

对任一旧已付集合 O，合法正分割为

    Raw_rec^+=Raw_rec^+[O]
       +Raw_rec^+[O^c∩{Fcal≥theta}]
       +Raw_rec^+[O^c∩{Fcal<theta}].                    (JP17)

JP14只收中间项一次价格，最后一项原位保留。若旧门为 Fsup_old≥theta，则中间项精确落在旧低包络的新校准高权重部分，不再重复领旧价格。

## JP8. 完全显式的原核几何子门与 actual chi

由 JP3 定义 chi_y=alpha QJ/q，0<chi_y≤D，故

    L_y(u)=(D K0_u/p_u)/chi_y≥K0_u/p_u.

于是有实际可计算的几何乘子

    Fphys(v,u)=w_v²/rho_v²·max(1,K0_u/p_u)≤Fcal(v,u).   (JP18)

因此 Fphys≥theta 是 JP14 已付子支，不附任何未知 posterior 矩条件。K0 的尺度必须是 JP1 的 actual Hhat，不能改成另一个更有利测试。实际 chi 可能远小于 D；用 Fphys 是丢弃这种真实强化的较粗充分门。

若要与原物理位置直接核对，令 lambda=Hhat/L、r_i=|x_i−u_i|/L，f_s=(1−s)h+s phi，则准确地

    K0_u/p_u=lambda^(−n)∏_i f_s(r_i/lambda)/f_s(r_i).

这里所有坐标及硬面跳变均保留。R184 KG 的 n*rxi 和收缩硬面 N_h 不会因 JP18 免费消失。本文也没有将 bad-u 的 w_g>kappa 转给 good-v。

## JP9. 新低权重、高 A 核心的精确几何限制

在 active pair 上，Fcal<theta 等价于同时

    w_v²<theta rho_v²,
    L_y(u)<theta rho_v²/w_v².                           (JP19)

这已经移除了旧权重中 z_v 很小时带来的压低，但没有证明实际 L 很小的 bad 来源质量小。只知 ∫L dP=||S||≤1，而非等于1；同 alpha 的实际 bad 储备份额可能很小。

若另有原 A_y(v)>1−eta，0<eta<1，由 A=rho J/(p_v+pplus_v+J) 得

    rho_v>1−eta,
    (p_v+pplus_v)/J_v<eta/(1−eta),
    (k_v+alpha J_v)/(T Delta_y(v))<eta.                 (JP20)

这些均针对同一个真实 x,y,v。再用 hstop≤g 与 w_tau≤1，

    0<Delta_y(v)≤1−w_v,
    k_v+alpha J_v<eta T Delta_y(v)≤eta T(1−w_v).         (JP21)

联合低 Fcal 与 z_v<eta，得到同一 bad-u/good-v 的必要原核关系

    (D K0_u/p_u)(J_v/T)(q/QJ)
       <eta theta rho_v² Delta_y(v)/w_v²
       ≤eta theta rho_v²(1−w_v)/w_v².                  (JP22)

推导为左端=z_v L_y(u) Delta_y(v)，逐项使用 JP19–20；没有分别对两个源槽取极值。等价地，剩余源必须同时具有低 good 重叠、被 J 压倒的 current target、强 capture 的实际 a_v，以及相对于实际 chi 足够低的 bad K0/current 比。JP22 保留 T、QJ/q、actual Hhat 和 Delta；它不是量纲常数，也不是新已付估计。

因此最早尚未证明的全局步骤很具体：对满足 JP19–22 的同一三点核配置，需要控制原 dx beta(dy) Pi(dv)Pi(du) 加权的正 score 交通。现有 FIRST 只给 P、S 的上容量；它既不提供低 L 集的质量上界，也不使 JP22 的右端在 w_v小处一致小。JP20 的高 A 压制发生在 target v，JP3 的储备发生在 bad u，不能互换两个原槽或独立上确界后声称这些条件矛盾。没有在此缺口后附加未知小矩假设。

## JP10. 与 R184 中央分割及完整费用的衔接

R184 EC 的时间尾、未来到即时 target 桥和非负缺口恒等式继续按原价格使用；本文不重新证明，也不把其 near-U 必要条件变成所有行的假设。可先在原正交通作以下不交顺序：已付款旧分支 O；其补集上的 Fcal≥theta；其余保持原中央高 A、低 Fcal 等真实门。新项的来源价格仅为 JP14。

若采用 EC 的预分配接收误差，所有 epsilon∫q 仍只在同一原 E_rec 上记账，并与已有分支共用一次已分配误差预算；本文没有新增可自由重复消费的 epsilon 信用。独立窗口/父来源的重复使用也继续列出，不由校准自动消失。

本稿新增的实际付款是 JP11–14，新增可核物理充分门是 JP18；JP16 给全 active 范围的旧包络支配，JP19–22 精确定位未付核心。非互反 bad、其他 mother shares、以及剩余低 Fcal 核心的一般根阶价仍未证明。一般 n^(1/2+o(1)) 弱型目标保持未完成。

## JP11. 可复核来源与有限检查边界

主要已审输入：R183 final_checkpoint 的 joint_geometric_budget.md（JG1–JG10、JG16）及 reciprocal_capture_geometry.md；R184 final_checkpoint 的 adaptive_geometric_envelope.md、extremal_core_budget.md、kernel_ratio_geometry.md。R185 calibrated_weight_history.md 仅作指定历史范围的定位报告，不能用“未检出”替代本稿新定理的证明。

有限 exact checker 可验证 JP3、JP5–9、JP15–16 的同 alpha 代数和测度支配。若仅构造满足 JP6 的离散 bad 测度并在非bad补足概率，应明确只是该正支配引理的检查；它不认证原 w_t/e_t、continuum FIRST、森林/history、Lebesgue 接收域或 FULL 物理实例。任何 alpha0 抽象数据含 k=0 的 bad 正质量时，不能调用本稿依赖 strictsoft 正性的零交通支。所有数值结论与一般解析证明保持分开。
