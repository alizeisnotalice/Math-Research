# R185 same-source calibrated-weight checks

All retained checks pass: 12 strictly positive finite-array cases, 3 explicit zero branches, and 6 rejected illegal inputs. These are exact Fraction calculations in three stages, with no physical-kernel or full FIRST/history realization claim. No physical scan or extra software is used.

## Common input and original reserve

Every positive case constructs one common array with a capture target and a bad source domain. It sets D=q=1 before mass scaling, E={target}, B={bad sources}, and computes

`QJ=ΣJν, U=ΣE min(a,k)ν, alpha=(Dq−U)/QJ`.

The checker verifies capacity Dq≥Σkν and uses this actual alpha to recover d=1−k_v/a_v, z=alpha J_v/a_v, and rho=d−z>0. It never chooses rho independently. All p,k,J and source masses are positive. Bad-domain P=pν/q and S=kν/(alpha QJ) are computed from those same arrays. They retain their masses below one, with S allowed to have mass exactly one. Positive p,k,J are necessary interior qualifications only; these arbitrary arrays are not certified values of an original mixed physical kernel.

For reproducibility, starting from desired positive P,S with ΣP<1/2 and ΣS≤1, d,z obey 0<z<d<1. Write chi=2z/(2z+1−d). The target has ν=2, J=chi/4, a=chi/(4z), k=a(1−d); each bad source has ν_i=2P_i, J_i=chi/(2mν_i), k_i=chi S_i/ν_i, and p_i=1/2. The target p is (1−ΣP)/4. Then QJ=chi, alpha=1, U=1−chi, so all identities and capacities follow without independent maxima.

A completed finite posterior is also constructed: Π_bad=2P·util, target Π is the remaining probability, w=Π/ν, e=Σwν=1. All weights lie in (0,1]. Only the theorem's required bad-domain domination Π≤P/(2Kκ), K=1, κ=1/4, is used for payment; no corresponding domination is imposed on the nonbad target. This completion is not claimed to satisfy original reciprocal/high/kernel/history gates.

## Independent source payment and geometry comparison

The same-domain exact identities are

`mjoin=Σmax(P,S)=(massP+massS+Σ|P−S|)/2`,

`mjoin+Σmin(P,S)=massP+massS`, and `mjoin≤2`.

The L1 is total L1, not half probability TV. No free normalization of either subprobability occurs. The source bound is checked separately for every slot, then on the same integral:

`Σ Π Fcal rho²/w_good² = Σ Π max(1,ell) ≤ mjoin/(2Kκ)`.

Thus payment is a direct cancellation calculation. It is not inferred by monotonicity from an old bound for the smaller Fsup. The script also checks Fsup=w_good² E(z ell)≤Fcal, including the E-branch junction z ell=1/3 and a new-gate equality Fcal=1.

Retaining actual alpha gives chi=alpha QJ/q≤D and exactly ell=(D/chi)(K0/p), with K0=k/D. Consequently ell≥K0/p and Fcal is at least the corresponding pure-K0/current-ratio weight. This deterministic comparison keeps its actual chi factor; it does not supply any global source integration bound for a geometric surrogate.

## Three stages and actual results

Initial cases cover balanced P/S, underfilled masses, S-dominant likelihood, and P-dominant likelihood. Stress cases include ell=1, tiny z, tiny rho, and saturated S mass. Expanded cases mix likelihoods above/below one, have tiny common mass, rho close to one, and ell as large as 2^39. Six illegal cases reject negative mass, massP>1, massS>1, rho=0 as an active target, zero P with positive S, and zero J scale before division.

Representative exact results:

| Case | mjoin | Actual budget utilization | Old/new ≥1 gates |
|---|---:|---:|---|
| balanced | 2/5 | 1 | old false, new true at equality |
| underfilled | 1/15 | 1/4 | old false, new true |
| S-dominant | 9/10 | 3/4 | old false, new true |
| mixed likelihoods | 77/60 | 3/4 | only first source passes both |
| tiny common mass | 1/549755813888 | 1/16 | old false, new true |

The mixed case demonstrates that mjoin need not be ≤1; the tiny case demonstrates the source-utilization information lost by replacing it with 2. Tiny z and tiny rho can create substantial algebraic gate differences, but these cases do not prove that such gates capture substantial original traffic or receiver measure.

Zero alpha is recomputed from two explicit reserve arrays. With strictly positive bad k it forces bad ν=0; S and Fcal are not formed. A separate k=0, nonempty bad array has zero weighted reserve mass but is deliberately denied that strict-soft elimination/payment conclusion. A zero-a target is dispatched as zero traffic before any a or rho division. These branches avoid undefined 0·∞ expressions.

Each positive case is repeated under common ν,q scaling by 2^20 and under J scaling by 2^-20 with alpha counter-scaling. P,S,Π,d,z,rho,chi,ell, both weights, mjoin, and the same-integral payment remain exactly invariant. No dimension order or asymptotic fit is inferred.

## Reproduction

Standard Python 3 library only:

```sh
python3 numerical_checks.py
```

The script writes adjacent `numerical_checks.json`, or accepts `--output /tmp/result.json`. Its sole runtime input is adjacent `task_contract.md`, recorded by filename and SHA256. All assertion failures exit nonzero. Isolated replay copies only the script and contract outside the repository and compares the entire JSON. The author/auditor screen supplies the general inequalities; these finite cases independently verify the stated algebra and edge handling, not the general centered-cube result.
