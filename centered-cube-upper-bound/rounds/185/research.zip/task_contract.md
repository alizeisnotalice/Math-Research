# R185 contract: joint extremal geometry, not repeated exclusion

Parent began main clean at bcbbe34543f43962cd086f109efa216ed536c1c4; origin is the authorized Math-Research SSH remote. R184 was progress: independently audited instantaneous bridge, paid pair-adaptive envelope and physical geometry, committed and remote-verified.

Goal unchanged: every positive L1 input, genuine Lebesgue receiver measure, centered-cube n^(1/2+o(1)) weak type, all source/window/layer/error prices. This round targets the central low-Fsup/high-A joint traffic, plus any genuinely payable joint estimate that changes its global budget. It does not assume near saturation on every row.

Inherited definitions and tools: R184 EC fixed terminal A, z/e clock, U and complete nonnegative deficits; AE paid Fsup at factor2; KG original clamped Hhat/current ratio and reciprocal excess. R183 RCG and JG supply exact raw, companion and single-direction fixed-J energy. Authoritative frozen sources are external final_checkpoint directories and repository research.zip files. Keep original x,y,v,u, alpha, current s/L and legal K0, actual beta and nu sharing only a parent. Known limitations: no beta≥nu, no free source probabilities/entropy, no s≈1 deduction, no n rxi/Nh deletion, no independently shifted forest identification, no unproved repeated contraction, no finite numerical FULL certificate.

Responsibilities: parent main deduction/integration and Git; Astra high r166_raw_budget joint_extremal_payment.md, actual joint-source/near-extremal payment; Sol high r166_exact_certificate shared_displacement_geometry.md, distinct two-source same-point ratio/face-difference geometry; Sol high r164_audit independent_audit.md, independent premise screen before proof. Sol medium numerical agent activated only once precise formulas determine meaningful exact/numerical checks. Up to four Luna medium only for distinct bounded supporting jobs, never final key-lemma certification. No child Git, spawn or edits outside owned files. Agents are not alone, preserve others' work, deliver and stop.

Every candidate must state exact proposition, definitions, allowed tools, known limitations, output and failure criterion. Payable means actual receiver epsilon budget or source root price with all fees, not unpriced norm renaming. Important strategies receive preliminary, boundary/known-limit pressure, expanded parameter checks; no fitted exponent. Focus constructive global geometry. A negative finding only matters if it changes the next decision.

Skill M03 near-extremizer stability is used to qualify deficit/distance statements, not as a universal stability theorem. Its own supported example does not prove our stability estimate. Parent derives needed claims directly.

Each completed round: detailed LaTeX text (no PDF), actual numerical scope, independent audit, compact archive and individual main commit/push/remote verification. No available actual model deduction data, no invented cost ratios.
