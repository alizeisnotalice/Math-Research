# R185：混核极值几何、全自适应费用与原三来源正交通付款

本稿证明一个针对原 hard/soft 参数的全局几何估计：原 current 核与固定全软 J 核的混合亲和积分，在软度有明确上界时有均匀指数缺口；真正的 x-dependent soft/scale 选择费用全部支付。再以固定父来源归一的三来源测度，将这一核估计回代原 capped 正交通，支付一个明示的原正分支，费用为根阶来源价。大后验放大量的补集仍未付，不能把固定来源核估计当作任意卷积输入的统一指数缩小。

## MA1. 正确的一维概率核与质量缺口

h=1_[−1/2,1/2]，w(r)=∫_0^1 exp(−|r|/t)dt，phi=h*w。Tonelli 给∫w=∫_0^1 2t dt=1，因此 h,w,phi 都是概率密度。phi 偶、递减且严格正。记

    tau_phi=∫_[-1/2,1/2]phi(r)dr
           =2∫_0^1(1-r)w(r)dr
           =1/3+2∫_0^1 t² exp(−1/t)dt
           =1/3+2E4(1),                                 (MA1)

其中 E4 是标准积分 E4(1)=∫_1^∞e^(−u)u^(−4)du。0<tau_phi<2/3：末项积分小于e^(−1)/3<1/6。此处不使用外部未核的稳定性定理。

一维 p_s,H=(1−s)h_H+s phi_H，J_b=phi_b，0≤s≤1，0<H≤b。给任意两个来源 y,v，取 B=[y−H/2,y+H/2]，则

    ∫_B p_s,H(x−y)dx=r_s=1−s+s tau_phi,
    t_B:=∫_B J_b(x−v)dx≤tau_phi≤r_s.                   (MA2)

第二式来自 phi 偶递减、H≤b，即给定长度区间的质量在中心取得最大。对 B 及补集分别 Cauchy，

    ∫sqrt[p_s,H(x−y)J_b(x−v)]dx
      ≤sqrt(r_s t_B)+sqrt[(1−r_s)(1−t_B)]
      ≤a(s):=sqrt(r_s tau_phi)+sqrt[(1−r_s)(1−tau_phi)]. (MA3)

最后一函数在 t_B≤r_s 时随 t_B 增。a(s) 在 [0,1] 随 s 增，a(1)=1，s<1 时 a(s)<1；s0取a(0)=sqrt(tau_phi)。这保留同一源中心、实际硬区和 J 核，完全不要求源 y,v 分离。

将二点概率 (r_s,1−r_s)、(tau_phi,1−tau_phi) 写成平方根向量，Cauchy 给它们的全变差距离

    r_s−tau_phi ≤sqrt[1−a(s)²].

由 1−a²≤2(1−a) 得

    1−a(s)≥(1−s)²(1−tau_phi)²/2,
    a(s)≤exp[−(1−s)²(1−tau_phi)²/2].                   (MA4)

边界 s=1 是等号极限，不能把该退化当维数无关正缺口。

## MA2. 固定参数的全维共同接收积分

原 product P_s,H(x−y)=∏p_s,H(x_i−y_i)，J_b(x−v)=∏phi_b(x_i−v_i)。固定共同 s,H 后 Tonelli 精确张量，故任意 y,v∈R^n 均有

    ∫_(R^n)sqrt[P_s,H(x−y)J_b(x−v)]dx≤a(s)^n.          (MA5)

这是实际 Lebesgue dx，不是独立假定的来源分布。sources 可以相关，甚至 y=v。它也不是对 P_s,H*f 与 J_b*f 的同一指数界：来源混合后再开平方不允许沿该方向交换积分。

## MA3. 实际 adaptive H 和 s 的全部正包络费用

设 a≤H≤b≤2a。对固定 x,y,v,s，令 G_s,H=sqrt[P_s,H(x−y)J_b(x−v)]。H^(n/2)G_s,H 非减，因为 f_s=(1−s)h+s phi 是径向非增，每个 f_s((x_i−y_i)/H) 随 H 非减，硬面只产生正跳。分布意义 dG≥−(n/2)G dH/H；对每个 H 积到 b 并丢正跳，得到

    sup_(a≤H≤b) G_s,H
       ≤G_s,b+(n/2)∫_a^b G_s,H dH/H.                  (MA6)

它保留真正的硬跳，不假设核对 H 光滑。于是 fixed s 的尺度选择价为 1+(n/2)log(b/a)。

再取0<sbar<1、delta=1/(n+1)。对任意s∈[0,sbar]及t∈[(1−delta)s,(1−delta)s+delta sbar]，有t=(1−delta)s+delta r，r∈[0,sbar]，所以逐坐标 f_t≥(1−delta)f_s，

    G_t,H≥(1−delta)^(n/2)G_s,H.

区间长delta sbar，故

    sup_(s≤sbar)G_s,H
       ≤c_n/sbar∫_0^sbar G_t,H dt,
    c_n=(n+1)(1+1/n)^(n/2)≤sqrt(e)(n+1)≤e(n+1).        (MA7)

同一比较对 MA6 的整段非负右侧也成立，不能先分别 sup 后漏掉菜单。积分 x，MA5 和 a(t)≤a(sbar) 给

    ∫sup_(0≤s≤sbar,a≤H≤b) G_s,H(x)dx
      ≤c_n[1+(n/2)log(b/a)]a(sbar)^n
      ≤A_n(sbar):=e(n+1)(1+(n/2)log2)a(sbar)^n.         (MA8)

本稿回代和有限数值表统一使用最后这个较粗、显式的 A_n，不把它与更小 c_n 价格混写。sbar=0 时单独定义 A_n(0)=(1+(n/2)log2)tau_phi^(n/2)，只用 MA6，不除sbar；若为了连续参数表用粗e(n+1)式也仍是上界但不称最优。

由 MA4、tau_phi<2/3，还可得到对0<sbar<1

    A_n(sbar)≤e(n+1)² exp[−n(1−sbar)²/18].              (MA9)

例如给定 m>0，仅在真实参数允许

    (1−sbar)²≥18(m+2)log(n+1)/n

时才可推出 A_n≤e(n+1)^(−m)。条件右侧若大于1，则该示例范围为空。没有把 strictsoft 的原下门误读为这个上门；原 s>sbar 的全部交通必须另留。sbar接近1和中等n时前置费可压倒指数，这是实际数值表清楚显示的情况。

## MA4. 固定联合来源与线性质量归一

对任意不依receiver x的有限正联合来源 Gamma(dy,dv)，MA8与Tonelli给

    ∫dx∫sqrt[P_s(x),H(x)(x−y)J_b(x−v)]Gamma(dy,dv)
       ≤A_n(sbar)||Gamma||,                            (MA10)

只要实际共同 selector s(x)≤sbar、H(x)∈[a,b]。source相关无妨；不能将x相关posterior或截断后重新归一的source当固定Gamma。

现在回到实际原窗口。令父来源质量 M_V=||A_V||<∞，beta_V,nu_V≤A_V，故二者质量均≤M_V。M_V=0时原交通零。对M_V>0定义**固定**三来源

    pi_V(dy,du,dv)=beta_V(dy)nu_V(du)nu_V(dv)/M_V²,
    ||pi_V||=||beta_V||||nu_V||²/M_V²≤M_V.              (MA11)

pi 不是原 posterior，也未被当作概率。它只是合法的固定参考测度；所有真实 posterior 因子保留在下一段的显式密度里。不能改用随 x 改变的局部质量来降低分母费用。

## MA5. 原三来源密度的精确混核因子分解

沿用R183 RCG2及本轮JP：原A_y(v)=1_good rho_v J_v/(3Q_v)在辅助t中固定，实际posterior为1_Zt w_t nu/e_t。令Hmask∈[0,1]保留原high、坏槽互反、原far/history及此前未付补集等所有正门；不要把A中的rho/good重复乘入Hmask。原终端v支持和u的真实Z_t都显式保留在Hmask。对每个x先使用原唯一j=j(x)；若仍以sum_j书写，1_{j(x)=j}留在下面积分内，合并后才定义B。实际current p_y=P_s(x),L(x)(x−y)，L(x)∈[a,b]；J_v=P_1,b(x−v)。

定义不含hard/外常数的原capped正被积量

    p_y A_y(v)∫_actual dt/t Hmask
          (k_t(y,v)−k_t(y,u))_+ w_t(y,v)w_t(y,u)/e_t(y)².

在有效p_y,J_v>0的原行，置

    B_V(x,y,u,v)=M_V² sqrt(p_y/J_v) A_y(v)
       ×∫_actual dt/t Hmask
          (k_t(y,v)−k_t(y,u))_+ w_t(y,v)w_t(y,u)/e_t(y)². (MA12)

所有t-deletion和归一分母完整保留；B不另作为固定终端A参加FTC。原严格soft有效核正；e_t=0或非high、不活跃槽先按原交通为0分派，再定义B=0。M0同样先分派；不形成0×∞。允许B=+∞时仅在有限正截断上做身份，再由单调极限表达；有限B门足够用于下述付款。

令K(x;y,v)=sqrt(p_y J_v)。则对原选定正交通精确有

    Raw_capped=(32Lambda/3) E_omega Σ_V∫dx∫ K B_V dpi_V. (MA13)

这是代数恒等式，p_y、A、每个source及e_t的次数都未丢：K·M²sqrt(p_y/J_v)/M²=p_y。原hard-carrier raw只被一次16/3帽控制，外2Lambda也只有一次；MA13左侧指该capped量，原raw≤它。若原H还含signed净化后的正支，必须依原合同保留，不借任何已消费负项。

## MA6. 一个真正支付原hard层交通的全局分支

预先选0≤sbar<1和Bcap>0。在原尚未支付的正交通中，选择同一固定source三元组上的可测门

    s(x)≤sbar,    B_V(x,y,u,v)≤Bcap.                    (MA14)

门在整段辅助时间积分后决定，但对正交通是合法切片：不重算H、A、Pi或alpha，不重新定义B以适应所选门。由MA13、固定pi、MA8–11，

    Raw_original^+[MA14]
      ≤(32Lambda/3) Bcap A_n(sbar) W_A.                 (MA15)

这是实际Lebesgue接收积分中的**线性**来源价格，不是nu⊗nu的无价平方质量。选择

    Bcap=sqrt(n)/A_n(sbar)                              (MA16)

给实际根阶来源价 (32Lambda/3)sqrt(n)W_A。如预留不同来源常数，可相应缩放Bcap。每一独立窗口按原W_A账加总，不能将同一父来源重用而声称只收一次；本稿不消除原Λ及其他窗口/误差费用。

结合MA9，在满足真实soft上门的范围，Bcap至少为 sqrt(n)exp[n(1−sbar)²/18]/[e(n+1)²]。这说明新几何估计可容忍的后验放大量的明确尺度，不是声称所有实际B都小于它。对于sbar逼近1，A_n可能大于1，门会变严，按真实公式执行。

本付款可直接加上原中央、高A、低Fcal等限制，只需一开始把相应正乘子放入Hmask，再以它定义B。先前已付支移除后，新门只收新增正切片一次。不得对每个Bcap重选不同H却把诸多预算相加不计。

## MA7. 剩余困难与本轮实质边界

MA15不是一般上界：s>sbar的参数尾仍在，s≤sbar但B_V>Bcap的来源三元组也仍在。B含真实M²/e_t²、p_y/J_v、目标A和完整score时积分。高A时J_v压倒p_v，并不使p_y/J_v有统一上界；FIRST/high仅控制局部e_t与p_y，不直接控制固定父质量M/e_t。因此不能从当前资格删掉这个补集，也不能把旧线性receiver估计直接称作其根阶来源价。

这一步的实质是把原硬层的固定共同来源几何、soft/scale选择和真实raw中的密度放大同时写成一条已证明的付款式。相较只证明pair overlap很小，它明确了允许多大的实际posterior放大量、如何用原父质量保持L1线性、以及仍需处理的准确事件。下一步必须用同alpha capture、共同source占用和极值几何控制这个大B事件与低Fcal、高A的交集，而非再把B或M/e改名成一个已知预算。

M03技能仅用于要求非负亏损、参数依赖和near-extremal范围的资格检查。本稿新的概率二分缺口、tensor与selector证明均在上文自证，没有借用该技能未建立的通用稳定性或紧性结论。

数值边界：六个一维真实混核积分分别在25/40位计算，另表明确A_n的n,sbar费用；它们是诊断，不是有向区间证明。三来源分解另用标准库Fraction核对质量次数、缩放和正切片；这些代数数据不认证原continuum FIRST/history。所有解析结论均经独立审查，完整记录见本轮audit。
