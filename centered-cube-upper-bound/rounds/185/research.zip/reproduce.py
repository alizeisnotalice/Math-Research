#!/usr/bin/env python3
"""Verify archive; replay three finite checks with all original JSON fields."""
import argparse,hashlib,json,pathlib,shutil,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=pathlib.Path);a=p.parse_args()
b=pathlib.Path(__file__).resolve().parent
m=json.loads((b/'inventory.json').read_text())
for name, sha in m['sha256'].items():
    if hashlib.sha256((b/name).read_bytes()).hexdigest()!=sha:raise SystemExit('HASH_MISMATCH '+name)
print('ARCHIVE_HASHES_PASS',len(m['sha256']),flush=True)
if a.verify_only:sys.exit(0)
if a.output_dir is None:p.error('supply --verify-only or --output-dir NEW_DIRECTORY')
a.output_dir.mkdir(parents=True,exist_ok=False)
for name in ['task_contract.md','mixed_affinity_raw_budget.md','numerical_checks.py','affinity_checks.py','triple_factor_check.py']:shutil.copy2(b/name,a.output_dir/name)
for stem in ['numerical_checks','triple_factor_check','affinity_checks']:
    out=a.output_dir/(stem+'.json')
    subprocess.run([sys.executable,str(a.output_dir/(stem+'.py')),'--output',str(out)],check=True)
    if json.loads(out.read_text())!=json.loads((b/(stem+'.json')).read_text()):raise SystemExit('FULL_JSON_MISMATCH '+stem+' (check exact dependency source/version)')
    print('FULL_JSON_MATCH',stem,flush=True)
