# R185 calibrated-weight history check

Scope: a narrow search of the `research.zip` archives for R175, R183, and R184 only. Archive citations below use `rounds/<n>/research.zip::<member>#<line>` (one-based lines). This is a novelty/history check, not a proof of the R185 key lemma or a claim about all earlier rounds.

## Candidate and finding

Candidate on an active original high reciprocal row and the original bad∩reciprocal domain:

\[
P(du)=p_u\,d\nu(u)/q,\qquad
S(du)=DK^0_u\,d\nu(u)/(\alpha Q_J),\qquad
\ell_u=dS/dP,
\]

\[
F_{\rm cal}(y,v,u)=\frac{w_g(y,v)^2}{\rho_v^2}\max(1,\ell_u).
\]

The exact (F_{\rm cal}) expression and its proposed payment were not found in these three inspected archives. The ingredients have clear precedents: R184 uses the same-domain likelihood factorization (R_b=z_v\ell_u), with (z_v=\alpha J_v/(T\Delta_v)), and pays a pair-dependent envelope (F_{\sup}); R175 proves same-\(\alpha\) reserve/cut bounds and scalar residual inequalities. Thus this is a new weight/payment in the inspected scope, assembled from known same-\(\alpha\) ingredients.

**Payment distinction:** R184's bound on \(\mathcal C_{\rm rec}[F_{\sup}]\) does not imply a bound on \(\mathcal C_{\rm rec}[F_{\rm cal}]\) merely because (F_{\sup}\le F_{\rm cal}); the direction of monotonicity gives no such upper bound. The R185 payment for (F_{\rm cal}) must be established separately from the same-\(\alpha\) reserve and original current-capacity estimates, including the (\rho_v^2) cancellation. Sol's independent screening is the separate audit for that argument; this history note does not certify it.

For comparison, R184's already audited payment is specifically
\[
F_{\sup}=w_g^2 E(R_b),\quad E(R)=\sup_{0\le r\le1}R^r/c_r,
\quad \mathcal C_{\rm rec}[F_{\sup}]\le \log 2/(18\kappa)\,W_\nu.
\]
It charges the endpoint sum (F_0+F_1), with factor 2, and pays the branch (F_{\sup}\ge\theta); it expressly leaves the low-envelope complement unpaid. See R184 `adaptive_geometric_envelope.md` AE1–3, lines 5–56, and AE6/report lines 97–100 / 18–22. R184 AE5, lines 70–95, contains the likelihood factorization and subprobability constraints, but not (F_{\rm cal}).

## Closest archive precedents

- R183 `reciprocal_capture_geometry.md` lines 19–33 and `proof.tex.txt` lines 20–30 fix the terminal good weight containing the original \(\rho\), the bad source set, original \(\alpha\), and positive flux. The report, lines 19–27, gives fixed-r and target-adaptive-r (G_r^*) payments; it does not state the (\max(1,\ell)/\rho^2) weight.
- R175 `reserve_envelope.md` lines 5–14 defines \(\rho=(d-\alpha a)_+\), same-\(\alpha\) reserve and cut capacity. `residual_capacity.md` RC2–3, lines 21–52, gives \(\alpha Q_J\ge D\int_{\rm bad}K_0\,d\nu\) and the cut bound. `core_joint_geometry.md` CJ4–8, lines 52–101, records same-reserve normalization and cubic/quartic bounds involving \(\rho\). None states or pays (F_{\rm cal}).

## Domain and zero/capacity qualifications

R184 AE5 requires an original high row with (t\le g), (\alpha>0), and the same original bad∩reciprocal domain. (P,S) are subprobabilities (masses at most one); retain their actual masses and do not normalize them to probabilities. Define (\ell=dS/dP) on the relevant (P)-support. The original strict-soft interior gives positive (p,J,K_0) at finite positions, but endpoint/extended cases with (K_0=0) need separate handling.

Handle zero-traffic cases before forming ratios: (\alpha=0) gives zero effective bad traffic by the reserve identity; (T\Delta\le0), (\rho=0), or (Q_J=0) is an inactive/zero branch in the cited source arguments. The candidate's (1/\rho^2) is therefore only defined on active targets with (\rho>0); assign no positive-traffic claim to zero branches. Keep the exact bad∩reciprocal restriction. The reserve controls (K_0)-weighted bad mass, not unweighted mass; at (K_0=0), it cannot eliminate source mass or justify division by (K_0). See R175 `residual_capacity.md` lines 28–38 and `core_joint_geometry.md` lines 73–75.
