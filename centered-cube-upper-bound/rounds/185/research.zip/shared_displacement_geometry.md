# R185：共同接收点的双来源核比值、位移交通与联合重叠

本稿保留原 x,y,u,v、软度和裁剪尺度。新增工具有：体积项精确抵消的双来源核比值式；带 signed 硬环差的同 alpha 储备比较；源对邻近交通的明确 epsilon 接收费；以及保留全部共同 selector 费用的双来源 tensor affinity 预算。近对已包含旧 F0 已付门，不能报告为新增 low-F 覆盖；联合 overlap 的固定来源二次价格也没有被换成原 raw 的线性来源费。一般低核心总价仍未完成。

## SD1. 原量词与真正几何权重

固定同一个原 (omega,V,a,b,q,x,j(x))，a≤L,R≤b≤2a，g=√(LR)。沿用冻结 R184 KG 的

    H=Hhat=max(a,min(b,H0)),
    H0=g c_j^(−1/2)m(s)ell_n^(1/(2n)),
    m(s)=1−s+s phi(1/2),  ell_n=1+log n,
    T=c_j^(n/2)/(g^n√ell_n),
    p_z=P_(s,L)(x−z),  K0_z=P_(s,H)(x−z),
    J_z=P_(1,b)(x−z),  Q_z=(p_z+pplus_z+J_z)/3,
    k_z=DK0_z,  a_v=TDelta_y(v),  QJ=∫J_z nu(dz).

原 D≥1 固定。H/L 的两方向与三个裁剪区全部按 KG2 保留，不能独立选择 H 或重选 alpha。用 script R(z)=K0_z/p_z 表示静态比值，以区别原物理尺度 R 与 auxiliary score k_t。以下主要在实际严格软范围 s>0；s=0 单列。beta 与 nu 仅共享原父来源，不假定互相支配。

原 capture E_y 与 bad B_y 不交，

    alpha QJ=Dq−∫_E min(a_z,k_z)nu(dz),
    ∫_B k_z nu(dz)≤alpha QJ≤Dq,
    rho_v=[1−(k_v+alpha J_v)/a_v]_+,
    A(v)=1_good rho_v J_v/(3Q_v),  supp A⊂Z_g.

所有非零 positive target 均保留原 capture、good、terminal、far 与历史资格。a_v=0、rho_v=0、QJ=0 或 alpha=0 的有效零交通先处理，不造0×∞；原严格软核正，alpha=0 使 bad 的 k nu 质量、因而有效 bad 交通为零。

本轮父稿/Astra 的校准权为

    ell_u=q k_u/(alpha QJ p_u),
    Fcal(v,u)=w_g(y,v)^2 max(1,ell_u)/rho_v^2.

因为 alpha QJ≤Dq，有 ell_u≥script R(u)。因此明确的纯几何权重

    Fgeom(v,u)=w_g(y,v)^2 max(1,script R(u))/rho_v^2

在有效 positive 槽满足 Fgeom≤Fcal。它不含旧 F1 的 J_v/a_v 与 q/QJ 抑制因子；本文主要回代该新几何门。不主张 Fgeom 普遍支配旧 Fsup。

## SD2. 去跳连续部分与共同 x 的精确相对核比

记 f_s(r)=(1−s)1_{r≤1/2}+s phi(r)，

    jump_s=log[m(s)/(s phi(1/2))],
    tilde f_s(r)=f_s(r) exp(−jump_s 1_{r≤1/2}).

R184 KG3–4 已证：tilde f 连续且偶递减，其负对数导数 beta_s(r)=−s phi'(r)/f_s(r)（除硬面单点）在 [0,Lphi]，其中 Lphi=2/(1−exp(−1))。去跳只乘分段常数，不改变各段的 beta。

置 d_i(z)=|x_i−z_i|，

    B(d)=log tilde f_s(d/H)−log tilde f_s(d/L),
    N(z)=Σ_i[1_{d_i(z)≤H/2}−1_{d_i(z)≤L/2}].

从原 product 密度直接得到

    log script R(z)=nlog(L/H)+Σ_i B(d_i(z))+jump_s N(z).

所以同一原 x,s,L,H 下有完全精确的双来源式

    log[script R(u)/script R(v)]
      =Σ_i[B(d_i(u))−B(d_i(v))]+jump_s ΔN(u,v),
    ΔN(u,v)=N(u)−N(v).                                  (SD1)

nlog(L/H) 体积项真正抵消。N 为 signed 计数：H>L 时它数 (L/2,H/2] 中的坐标；H<L 时为 (H/2,L/2] 计数的负值。当前与 K0 两个硬面都采用原闭面，故左端严格、右端闭；原子来源不能删除这些面。

## SD3. 位移连续成本与尺度接近时的精确改进

几乎处处

    B'(d)=beta_s(d/L)/L−beta_s(d/H)/H,
    |B'(d)|≤Lphi/min(H,L).

第二式利用两个 beta 非负，绝对差由较大上界控制，不需多收两倍。令

    I_z,i=[d_i(z)/max(H,L),d_i(z)/min(H,L)],
    omega_i=Lphi min{ |d_i(u)−d_i(v)|/min(H,L),
                       |I_u,i symmetric_difference I_v,i| },
    Omega(u,v)=Σ_i omega_i.

后一条界来自 B(d)=sign(H−L)∫_(I_d)beta_s(r)dr；在两个区间的公共部分积分完全抵消。因此

    Omega≤Lphi ||u−v||_1/min(H,L),
    Omega≤Lphi |1/H−1/L| Σ_i[d_i(u)+d_i(v)].              (SD2)

两式都保留实际物理单位，后者使连续部分在 H→L 时消失。SD1 给

    script R(v) exp[−Omega+jump_s ΔN]
       ≤script R(u)
       ≤script R(v) exp[Omega+jump_s ΔN].                (SD3)

这里 signed ΔN 原样保留；不能以独立面数或仅 ||u−v|| 替代整个比值。若 M_sym 数两个来源的半开硬环 membership 不同的坐标，则 |ΔN|≤M_sym，且

    M_sym≤#{i: dist(d_i(v),{H/2,L/2})≤|u_i−v_i|}≤n.      (SD4)

这是实际共同 receiver-face 事件；小源位移并不保证面数小。u 或 v 恰在硬面时，即使 H→L，整个核比值也可能有真实跳；只有连续 Omega 消失，不能宣称全比值连续。H=L 时 N=0、Omega=0，两个比值均为1。

## SD4. 直接接原同 alpha 的联合储备，而非两个独立好槽

对同一个 active target v，SD3 乘 p_u 并积分原 bad 集的一部分，给

    (k_v/p_v) ∫_(B∩reciprocal)
       p_u exp[−Omega(u,v)+jump_s ΔN(u,v)] nu(du)
       ≤∫_B k_u nu(du)≤alpha QJ.                        (SD5)

这是有共同来源的、无 inverse-alpha 的联合正积分不等式；其几何权依 v,u，不可移出 u 积分。即使 beta 与 nu 无序，式子仍只用同一个内 nu。原 reciprocal、capture、bad、alpha 没有重构。不能由 SD5 把坏源的加权预算再当每个 v 的独立 q 预算另收；后续必须保留原 v 后验或用下文已证的共同来源价。

SD3 还给一个明确的 joint 几何充分权

    Ftr(v,u)=w_g(y,v)^2/rho_v^2
                ×max{1, script R(v)exp[−Omega+jump_s ΔN]}.

逐点 Ftr≤Fgeom≤Fcal。这里已把源 u 的未知核比值换成同点 target-v 的实际比值、两来源位移和真实硬环差，而非把两者各自取 n 维上确界。这个充分权本身不能假装扩大原 Fgeom 已付集合。

## SD5. 几何权的实际全局来源价与高 A 条件

为明确 SD4 接回的价格，给出 Fgeom 的独立端点证明。原 reciprocal 与 high 给

    Pi_y,t(du)1_reciprocal
       ≤p_u nu(du)/(2K kappa q),
    kappa=K(1+gamma^(−n))/3<1,
    e_t≥e_g,  p_y e_g≥2Kq.

原应用 K=1，不重选它。两个同输入 FIRST 容量是 ∫pnu≤q、∫K0nu≤q，故

    ∫_reciprocal max(1,script R(u))Pi(du)≤1/(K kappa).

在原 companion 中 rho_v² 被 Fgeom 的分母精确消掉，good 的 p_y w_g(y,v)≤KQ_v 给 target 行上界 KJ_v/(9kappa)。再用 high 的 beta 列、固定 J 源积分、原共同 xi∈[1/2,1] 后的唯一 j，恰如 R183 JG8–9，得到

    C_rec[Fgeom]≤log2/(18kappa)Wnu=2C0 Wnu,
    C0=log2/(36kappa).                                  (SD6)

这是实际 Lebesgue dx 预算。实际 K0 使用原 s,Hhat 的合法 FIRST 测试，不由 current 平均核免费推导 future 容量。没有 nu≤beta、质量帽或无费 selector sup。它与父稿 Fcal 付款属同一份正 companion 预算，不能重复登记两次。

因此固定 theta>0，原此前未付 positive reciprocal 交通在 Ftr≥theta 的子支有

    Raw^+[Ftr≥theta]
      ≤(32Lambda/3)√[n log2/(36K kappa theta)]W_A.         (SD7)

常数包括单向 E_J≤nWnu/(2K)、一个 hard16/3 和外2Lambda，均只用一次。theta 随 n 小则保留 theta^(−1/2)。所有源、窗、j、far、history 和真实 dx 仍是原对象；独立窗口重复来源费照旧累计。

高 A 的准确联合条件可比逐条上界更紧。令 r_v=(p_v+pplus_v)/J_v，active 时 A= rho_v/(1+r_v)。A>1−eta 蕴含

    k_v/a_v+alpha J_v/a_v+(1−eta)r_v<eta,
    rho_v>1−eta,   r_v<eta/(1−eta).                     (SD8)

不能由小 p_v/J_v 推 K0_v/p_v 大，因为 k_v/a_v 也可能更小。具体地若 low-Fgeom<theta 同时满足

    script R(v)≥M theta rho_v²/w_g(y,v)²,  M>1,

则由 SD3 必有 Omega−jump_s ΔN>log M。所以至少发生

    ||u−v||_1>min(H,L)log M/(2Lphi),

或在 jump_s>0 时发生 −jump_s ΔN>(log M)/2。s=1 无第二分支；H=L 两项均零，此条件与低门不相容。这是一条保留高-A actual target、同 alpha 储备和两来源几何的定量分歧，不是已付远位移或坏硬面质量的结论。一般 target 大比值前提本身尚无覆盖证明。

## SD6. actual C 的全局 log-Lipschitz 常数

近对 traffic 需要 C 的上速率，与 R184 的下速率不同。记 C1=C(1)。因为 phi≤1，0<d<1 有

    C(d)=1−d+∫_(1/2)^(1/2+d)phi(t)dt,
    |C'(d)|≤1,  C(d)≥C1.

在 d>1，C=h*phi 是正指数混合，负 log 导数随 d 非增，边界值 (phi(1/2)−phi(3/2))/C1≤1/C1。因此 log C 在全轴为 (1/C1)-Lipschitz。直接用 phi 的指数混合算得

    C1=∫_0^1 t²(1−exp(−1/t))²dt≥(1−exp(−1))²/3.

故可取明确常数

    LC=3/(1−exp(−1))²<8,
    |log C(r)−log C(t)|≤LC|r−t|.

0、1 的导数跳通过连续/局部 AC 积分处理。min(0,log C−log xi) 是1-Lipschitz 截断，所以对每个实际时钟参数，特别 terminal g，

    |log w_g(y,u)−log w_g(y,v)|≤LC||u−v||_1/b.           (SD9)

C、F 没有被概率化，也没有假定来源独立。

## SD7. 近来源对的实际 epsilon 接收替代价

固定 hdist>0，只取 ||u−v||_1≤hdist b 的原正 reciprocal 交通。wg(y,u)>kappa 与 SD9 给 wg(y,v)>kappa exp(−LC hdist)。又 A 来源 v∈Z_g，所以 measurable 集

    Vh={v∈Z_g:wg(y,v)≥kappa exp(−LC hdist)}

满足 nu(Vh)/e_g≤exp(LC hdist)/kappa。原 reciprocal p_u≥kappa p_y、current 容量及 high 给 nu(Rbad)/e_g≤1/(2Kkappa)。这里 Rbad 可以是固定原 reciprocal bad 大集合；删除/支持额外门在正上界中保留或丢弃。

对固定 u,v，用 auxiliary score k_t(y,z)=#{i:C(|y_i−z_i|/b)<xi_t}。有

    (k_t(v)−k_t(u))_+
       ≤Σ_i1{C_i(v)<xi_t≤C_i(u)},
    ∫_actual (k_t(v)−k_t(u))_+ dt/t
       ≤Σ_i log_+[C_i(u)/C_i(v)]
       ≤LC||u−v||_1/b≤LC hdist.                         (SD10)

固定阈值的端点在 dt/t 没有质量；来源原子及 source 删除不会改变此正上界。保持 v∈Z_g，令 e_t≥e_g、w_t≤1、A≤1，Tonelli 先固定 pair 积分时间，再用上述两个 nu 质量比，得到原行

    I_near≤LC hdist exp(LC hdist)/(2Kkappa²).

恢复原 hard/外系数并用同一个 current beta 列和 unique j，

    Raw_rec^+[||u−v||_1≤hdist b]
       ≤[16Lambda/(3Kkappa²)]LC hdist exp(LC hdist)
            ×E_omega∫_Erec q dx.                       (SD11)

没有 n、alpha 或 nu 总质量的因子，也没有另收 log2。原时钟域先逐行界到统一常数，保留1_j再求和；完整删除仅减少所放大的正交通，target Z_g 则一直保留以控制 nu(Vh)。

给定 epsilon>0，取

    hdist≤min{1/LC, 3Kkappa²epsilon/(16e Lambda LC)}

即可付 epsilon E∫q。费用可限制到原 high-A、low-envelope 或此前未付子支，不改 terminal A。

必须同时记录：近对有旧 F0=wg(y,v)²≥kappa²exp(−2LC hdist)。因此 SD11 是旧已付集合的一种 epsilon receiving **替代价格**，不是新增 low-F 覆盖；当 low-Fsup 阈值 theta≤该数时，近对与该低门交集为空。Fcal、Fgeom 均≥F0（有效 rho≤1），故低 Fcal/Fgeom 也必要满足

    ||u−v||_1>(b/LC)log[kappa/(rho_v√theta)]

只在右侧为正时有排除力；旧低 Fsup 则把 rho_v 换成1。此必要远位移不自动支付远对。

## SD8. 远对的真实同核 tensor affinity

对固定 0≤s≤1 定义一维移位 affinity

    a_s(d)=∫sqrt[f_s(r)f_s(r−d)]dr,
    gamma_s=(√m(s)−√(s phi(1/2)))².

若0≤d≤1，两个硬区的对称差由两个互不相交、各长d的区间组成。在其中一个密度至少 m(s)，另一个至多 s phi(1/2)，故每点平方根差的平方≥gamma_s。d≥1 时用两个不相交的完整硬区，各长1。于是

    2(1−a_s(d))=∫(sqrt f_s−sqrt f_s_shift)²
                  ≥2gamma_s min(d,1).

因此

    a_s(d)≤1−gamma_s min(d,1).

闭面端点在本 Lebesgue kernel 积分不影响值，和 SD1 的原子比值问题不同。gamma_s 随 s 递减，s=0 为1，s=1 为0。固定 s,H 的实际 tensor 等式与衰减为

    ∫sqrt[P_s,H(x−u)P_s,H(x−v)]dx
       =∏_i a_s(|u_i−v_i|/H)
       ≤exp[−gamma_s Σ_i min(|u_i−v_i|/H,1)].             (SD12)

这是两个来源的联合 receiver 积分，没有将来源各自的 n 维上确界相乘，也没有坐标独立假设。只使用核本身的原 product 定义。

## SD9. 全部共同尺度/软度 selector 费用

令 G_s,H(x)=sqrt[P_s,H(x−u)P_s,H(x−v)]。对固定 x,s,u,v，H^nG_s,H 随 H 非减，因为每个 f_s 的径向参数随 H 减小，含全部向内硬跳。distributional dG≥−nG dH/H，故

    sup_(H∈[a,b])G_s,H(x)
       ≤G_s,b(x)+n∫_a^b G_s,H(x)dH/H.                   (SD13)

固定 s 的共同 adaptive H receiver affinity 因而至多

    [1+nlog(b/a)] exp[−gamma_s D_b(u,v)],
    D_b(u,v)=Σ_i min(|u_i−v_i|/b,1).

这一步可以用于 actual Hhat 或 L 的共同 receiver selector，而不是把逐 H 的卷积界免费取 sup。

再固定0<sbar<1，将原 selector 限制在0≤s(x)≤sbar。取 delta=1/(n+1)。对任意 s∈[0,sbar] 及 t∈[(1−delta)s,(1−delta)s+delta sbar]，t=(1−delta)s+delta r，其中0≤r≤sbar，逐坐标 f_t≥(1−delta)f_s。所以

    G_t,H≥(1−delta)^nG_s,H≥e^(−1)G_s,H,
    sup_s G_s,H≤e(n+1)/sbar ∫_0^sbar G_t,H dt.

同一个 lower 比较也适用于 SD13 的整个正右侧。应用 Tonelli、SD12 及 gamma_t≥gamma_sbar，得真正共同 adaptive s,H 的估计

    ∫sup_(0≤s≤sbar,a≤H≤b)G_s,H(x)dx
       ≤e(n+1)[1+nlog(b/a)]exp[−gamma_sbar D_b(u,v)]
       ≤e(n+1)(1+nlog2)exp[−gamma_sbar D_b(u,v)].          (SD14)

sbar=0 时只用固定硬核版本 SD13，不除0。sbar→1 时 gamma_sbar→0，不能隐藏这一退化。该粗 soft 选择费为 n 阶而非 sqrt n；本稿不优化它。D_b 至少达到 log[e(n+1)(1+nlog2)]/gamma_sbar 加指定余量时，指数才补偿这里明确列出的选择费。

## SD10. actual dx、两个来源与未完成的混核桥

SD14 可对任意**不依 receiver x**的有限正联合来源 Gamma(du,dv) 用 Tonelli 积分，得到价格

    e(n+1)(1+nlog2)∫exp[−gamma_sbar D_b(u,v)]Gamma(du,dv).

允许 Gamma 相关，无需 product 来源。若取 nu⊗nu，则是显式二次联合质量/重叠价；没有线性化为 Wnu 或 ||f||1 的权限。原 posterior、alpha、terminal masks 若随 x 选择，则不能冒充固定 Gamma 后免费用本式。低核心的必要 ||u−v|| 远也不必让 D_b 超过上述 log n 阈值，例如一根坐标承担远位移时 D_b 饱和。

更重要的是，原 companion 的 target 密度是 J_v，实际正密度为

    Hmask p_y² rho_v² J_v/(9Q_v²)
          ×1_Zt(v)1_Zt(u)w_t(v)w_t(u)/e_t² ×nu(dv)nu(du).

它不是 SD12 的 sqrt(p_u p_v)。把 sqrt(p_u p_v) 插入后，剩余 receiver 乘子含

    Hmask p_y² rho_v² J_v w_t(v)w_t(u)
           /(9Q_v² e_t² sqrt(p_u p_v)),

且 p_v/J_v 在高 A 核心很小，不能对该乘子声称免费有界。即使改用不同核 sqrt(p_u J_v)，仍须处理原 Q_v、e_t 及来源归一化。父稿处理 current-vs-J affinity；本稿只提供如下公共 envelope 接口：sqrt[P_s,H(x−u)J_b(x−v)] 的 H^(n/2) 倍单调，所以 SD13 的 n 改为 n/2，完整 coarse selector 价是 e(n+1)[1+(n/2)log(b/a)]。不能把同核的 gamma_s D_b 衰减直接移给这个不同核。

因此 SD14 是真实联合 tensor 几何，并未证明上述实际余乘子或 beta/nu 两来源质量已获价。SD5 的 Fgeom/Ftr 已付权不消失；低该门的原 weighted integral 仍需要共同几何/来源容量桥。没有重新将一个未付范数命名为原预算已完成。

## SD11. 原总账、检查及停止点

此前已付的原正集合必须先移除。可在剩余中选择 SD7 的 source 根价，或对近对选 SD11 的 epsilon receiving 替代价，二者不能重复消费同一正片的价格或旧负信用。未付远对继续保留同 alpha、rho、capture/bad、硬环差、原 xi 时钟和 true dx；本文不把 signed 负项重新借给它。

初步解析检查：u=v 时体积项、Omega、DeltaN、score差都为零；H=L 时两个 ratio 为1；SD12 的 s=0、d≤1 给硬核 affinity 1−d 的精确值。边界检查：闭面 source 比值必须保持 half-open annulus，s=1 时 jump 为0且 gamma 为0；alpha=0、rho=0、QJ=0 等原零槽先分支。扩大检查：所有尺度比、Hhat 裁剪、任意 correlated sources 和任意 n 的 tensor product 均保留，sbar→1 与完整选择因子的退化显式列出。本文没有新 FULL/原子/物理参数搜索或拟合维数结论。

本轮对实际总账的改善是准确的价格选择与可回代 joint 几何条件，不是新的低核心全覆盖：SD11 给 near-pair 可调 epsilon receiving 价但已在旧 F0 内；SD3–7 给同点源比值、硬差与同 reserve 的严格 joint 工具；SD12–14 给远对实际 tensor overlap 及完整 selector 费。一般 low-Fcal/high-A 的混核乘子与线性来源归一化仍是明确剩余桥。本稿在该有界结果停止。
