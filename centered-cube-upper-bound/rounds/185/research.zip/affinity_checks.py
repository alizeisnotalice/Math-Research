#!/usr/bin/env python3
"""Numerical diagnostics for the one-dimensional affinity envelope (not a proof)."""
from pathlib import Path
import argparse
import hashlib
import json
import mpmath as mp
import mpmath as _mpmath

HERE = Path(__file__).resolve().parent


def phi(r):
    r = abs(r)
    if r <= mp.mpf('0.5'):
        return 1-mp.expint(3, mp.mpf('0.5')+r)-mp.expint(3, mp.mpf('0.5')-r)
    return mp.expint(3, r-mp.mpf('0.5'))-mp.expint(3, r+mp.mpf('0.5'))


def tau_formula():
    return mp.mpf(1)/3 + 2*mp.expint(4, 1)


def tau_direct():
    return mp.quad(phi, [-mp.mpf('.5'), 0, mp.mpf('.5')])


def a_bound(s, tau):
    return mp.sqrt(tau*(1-s+s*tau))+mp.sqrt((1-tau)*s*(1-tau))


def affinity(s, H, b, d):
    """Integrate over the line, splitting every hard/soft formula seam."""
    H, b, d, s = map(mp.mpf, (H, b, d, s))
    tau = tau_formula()
    def p(x):
        hard = (1/H if abs(x) <= H/2 else mp.mpf(0))
        return (1-s)*hard + s*phi(x/H)/H
    def j(x):
        return phi((x-d)/b)/b
    points = [-mp.inf, mp.inf]
    for x in (-H/2, H/2, d-b/2, d, d+b/2):
        points.append(x)
    points = sorted(set(points))
    f = lambda x: mp.sqrt(max(mp.mpf(0), p(x)*j(x)))
    # Compact support is exact when s=0, avoiding any numerical tail surrogate.
    if s == 0:
        lo, hi = -H/2, H/2
        cuts = [lo] + [x for x in points if x not in (-mp.inf, mp.inf) and lo < x < hi] + [hi]
        return mp.quad(f, cuts)
    return mp.quad(f, points)


CASES = [
    ('initial_centered', 'initial', '1/2', '3/4', '1', '0'),
    ('initial_shifted', 'initial', '1/4', '3/4', '1', '1/3'),
    ('hard_face_touch', 'stress', '0', '1/2', '1', '1/2'),
    ('soft_endpoint', 'stress', '1', '1', '1', '0'),
    ('expanded_narrow_shift', 'expanded', '1/2', '1/4', '1/2', '3/8'),
    ('expanded_wide_shift', 'expanded', '3/4', '1', '2', '3/2'),
]


def scalar_table(tau):
    out = []
    for ss in ('.25', '.75', '.95', '.999'):
        s = mp.mpf(ss)
        a = a_bound(s, tau)
        for n in (8, 64, 512, 4096):
            envelope = mp.e*(n+1)*(1+mp.mpf(n)/2*mp.log(2))*a**n
            out.append(dict(s=ss, n=n, a=mp.nstr(a, 45), a_to_n=mp.nstr(a**n, 45),
                            full_envelope=mp.nstr(envelope, 45)))
    return out


def compute(dps):
    mp.mp.dps = dps
    tf, td = tau_formula(), tau_direct()
    cases = []
    for name, stage, ss, hh, bb, dd in CASES:
        s, H, b, d = map(mp.mpf, (ss, hh, bb, dd))
        actual = affinity(s, H, b, d)
        bound = a_bound(s, tf)
        cases.append(dict(name=name, stage=stage, s=ss, H=hh, b=bb, d=dd,
                          affinity=mp.nstr(actual, 45), affinity_envelope=mp.nstr(bound, 45),
                          observed_gap=mp.nstr(bound-actual, 45), observed_leq=(actual <= bound)))
    return dict(dps=dps, tau_formula=mp.nstr(tf, 45), tau_direct_quadrature=mp.nstr(td, 45),
                tau_difference=mp.nstr(td-tf, 45), cases=cases, scalar_table=scalar_table(tf))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=HERE/'affinity_checks.json')
    args = parser.parse_args()
    low, high = compute(25), compute(40)
    # Empirical precision comparison is recorded, never interpreted as a rigorous error bar.
    by_name = {c['name']: c for c in high['cases']}
    for c in low['cases']:
        h = by_name[c['name']]
        c['precision_difference_abs'] = mp.nstr(abs(mp.mpf(c['affinity'])-mp.mpf(h['affinity'])), 12)
    mp_root = Path(_mpmath.__file__).resolve().parent
    mp_hash = hashlib.sha256()
    for source in sorted(p for p in mp_root.rglob('*.py') if p.is_file()):
        mp_hash.update(source.relative_to(mp_root).as_posix().encode())
        mp_hash.update(source.read_bytes())
    result = dict(schema='r185_affinity_diagnostics_v1', arithmetic='mpmath quadrature; empirical precision comparison only',
                  mpmath_version=mp.__version__, low_precision=low, high_precision=high,
                  source_hashes={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'task_contract.md', HERE/'affinity_checks.py')},
                  mpmath_source_tree_sha256=mp_hash.hexdigest(),
                  scope='Six prescribed one-dimensional cases and scalar envelope table; no parameter search, no rigorous interval claim, no arbitrary-source mixture or raw budget claim.')
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    all_leq = all(c['observed_leq'] for c in high['cases']) and all(c['observed_leq'] for c in low['cases'])
    print(json.dumps(dict(cases=len(high['cases']), all_observed_leq=all_leq,
                          tau_difference=high['tau_difference'], output=str(args.output))))
    if not all_leq:
        raise SystemExit('Observed affinity exceeded its envelope at one or more evaluated precisions')


if __name__ == '__main__':
    main()
