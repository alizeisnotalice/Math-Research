#!/usr/bin/env python3
"""R185 same-source calibration: exact finite algebra, no physical FULL claim."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
HERE=Path(__file__).resolve().parent
Z=F(0)
def sm(xs):return sum(xs,Z)
def fs(xs):return list(map(F,xs))
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x

def envelope(R):
 assert R>=0
 return 1/(1-R)**2 if R<=F(1,3) else F(27,4)*R

def case(name,stage,P,S,d,z,w,util=F(3,4),scale_nu=F(1),scale_J=F(1)):
 P,S=fs(P),fs(S);d,z,w,util,scale_nu,scale_J=map(F,(d,z,w,util,scale_nu,scale_J))
 assert P and len(P)==len(S) and all(x>0 for x in P+S) and sm(P)<F(1,2) and sm(S)<=1
 assert 0<z<d<1 and 0<w<=1 and 0<util<=1 and scale_nu>0 and scale_J>0
 # Build actual common finite arrays, rather than selecting rho and alpha independently.
 D=q=F(1);K=F(1);kappa=F(1,4);chi=2*z/(2*z+1-d);m=len(P)
 nu=[2]+[2*p for p in P];Q=chi
 J=[chi/4]+[chi/(2*m*v) for v in nu[1:]]
 a=[chi/(4*z)]+[Z]*m;k=[a[0]*(1-d)]+[chi*s/v for s,v in zip(S,nu[1:])]
 p=[(1-sm(P))/4]+[F(1,2)]*m;E=[1]+[0]*m;B=[0]+[1]*m
 pi_bad=[2*x*util for x in P];pi=[1-sm(pi_bad)]+pi_bad;wt=[x/v for x,v in zip(pi,nu)]
 # Two independent homogeneities: shared mass scaling; J/alpha counter-scaling.
 nu=[x*scale_nu for x in nu];q*=scale_nu;J=[x*scale_J for x in J]
 et=sm(x*v for x,v in zip(wt,nu));Q=sm(x*v for x,v in zip(J,nu));U=sm(e*min(x,h)*v for e,x,h,v in zip(E,a,k,nu));alpha=(D*q-U)/Q
 assert alpha>0 and D*q>=sm(h*v for h,v in zip(k,nu)) and all(x>0 for x in p+k+J)
 rho=max(1-(k[0]+alpha*J[0])/a[0],0);actual_d=1-k[0]/a[0];actual_z=alpha*J[0]/a[0];actual_chi=alpha*Q/q
 PP=[p[i]*nu[i]/q for i in range(1,m+1)];SS=[k[i]*nu[i]/(alpha*Q) for i in range(1,m+1)];PI=[wt[i]*nu[i]/et for i in range(1,m+1)]
 assert PP==P and SS==S and actual_d==d and actual_z==z and rho==d-z and actual_chi==chi and chi<=D
 ell=[s/x for x,s in zip(P,S)];ratio=[k[i]/(D*p[i]) for i in range(1,m+1)];join=sm(max(x,s) for x,s in zip(P,S));overlap=sm(min(x,s) for x,s in zip(P,S));l1=sm(abs(x-s) for x,s in zip(P,S))
 old=[w*w*envelope(z*l) for l in ell];cal=[w*w*max(1,l)/(rho*rho) for l in ell];pure=[w*w*max(1,r)/(rho*rho) for r in ratio]
 direct=sm(x*f*rho*rho/(w*w) for x,f in zip(PI,cal));cancel=sm(x*max(1,l) for x,l in zip(PI,ell));budget=join/(2*K*kappa)
 source_bounds=[P[i]*max(1,ell[i])/(2*K*kappa) for i in range(m)]
 checks=dict(same_alpha=alpha*Q==D*q-U,subprobabilities=sm(P)<=1 and sm(S)<=1,mjoin_identity=join==(sm(P)+sm(S)+l1)/2 and join+overlap==sm(P)+sm(S),mjoin_at_most_two=join<=2,actual_p_capacity=sm(x*v for x,v in zip(p,nu))<=q,posterior_full_normalization=sm(x*v/et for x,v in zip(wt,nu))==1 and all(0<x<=1 for x in wt),bad_domain_domination=all(x<=pp/(2*K*kappa) for x,pp in zip(PI,P)),per_source_payment=all(x*f*rho*rho/(w*w)<=b for x,f,b in zip(PI,cal,source_bounds)),same_integral_cancellation=direct==cancel<=budget,old_weight_dominated=all(o<=c for o,c in zip(old,cal)),chi_bound=0<chi<=D,likelihood_kernel_relation=all(l==(D/chi)*r and l>=r for l,r in zip(ell,ratio)),cal_strengthens_pure_ratio=all(c>=g for c,g in zip(cal,pure)))
 assert all(checks.values()),(name,checks)
 return dict(name=name,stage=stage,nu=nu,p=p,k=k,J=J,a=a,E=E,B=B,D=D,q=q,QJ=Q,alpha=alpha,et=et,wt=wt,full_posterior=[x*v/et for x,v in zip(wt,nu)],P_bad=P,S_bad=S,Pi_bad=PI,z=actual_z,d=actual_d,rho=rho,w_good=w,K=K,kappa=kappa,chi=chi,ell=ell,K0_over_p=ratio,mass_P=sm(P),mass_S=sm(S),mjoin=join,overlap=overlap,total_L1=l1,Fsup=old,Fcal=cal,pure_K0_ratio_weight=pure,old_paid_gate=[x>=1 for x in old],new_paid_gate=[x>=1 for x in cal],new_only_gate=[o<1<=c for o,c in zip(old,cal)],same_integral_direct=direct,same_integral_cancelled=cancel,source_budget=budget,budget_utilization=direct/budget,checks=checks,scope='Common positive finite arrays and completed wt posterior; only required bad-domain domination is certified, not original physical kernels/reciprocal/FIRST/history')

def rejection(name,stage,kind):
 base=dict(name='invalid',stage=stage,P=[F(1,5)],S=[F(1,5)],d=F(3,4),z=F(1,4),w=F(1,2))
 changes={'negative_mass':dict(P=[-1]),'P_excess':dict(P=[2]),'S_excess':dict(S=[2]),'rho_zero':dict(d=F(1,4)),'zero_P_positive_S':dict(P=[0]),'zero_J_scale':dict(scale_J=0)}
 base.update(changes[kind])
 try:case(**base)
 except AssertionError:return dict(name=name,stage=stage,input_class=kind,rejected=True,scope='Invalid inputs rejected before normalization or a payment claim')
 raise AssertionError('Invalid input accepted: '+kind)

def zero_cases():
 out=[]
 for name,nu,k,a,J,E,q,strict in [('alpha_zero_strict_bad_empty',[1,0],[1,1],[3,0],[1,1],[1,0],1,True),('alpha_zero_k_zero_nonempty_bad',[1,1],[1,0],[3,0],[1,1],[1,0],1,False)]:
  nu,k,a,J=map(fs,(nu,k,a,J));q=F(q);Q=sm(j*v for j,v in zip(J,nu));U=sm(e*min(x,h)*v for e,x,h,v in zip(E,a,k,nu));alpha=(q-U)/Q;badnu=nu[1];badk=k[1]*nu[1]
  assert alpha==0 and q>=sm(h*v for h,v in zip(k,nu)) and badk==0
  assert (badnu==0 if strict else badnu>0 and k[1]==0)
  out.append(dict(name=name,stage='stress',nu=nu,k=k,a=a,J=J,E=E,q=q,QJ=Q,alpha=alpha,bad_nu=badnu,bad_k_mass=badk,payment_asserted=False,strict_positive_k=strict,reason='No S or Fcal divided by alpha; strict positive k forces empty bad measure, whereas k=0 does not'))
 # Explicit inactive target dispatch, evaluated before a/J, alphaJ/a or Fcal.
 a=Z;traffic=Z if a<=0 else None
 assert traffic==0
 out.append(dict(name='zero_target_a_rho',stage='stress',a=a,rho=Z,target_traffic=traffic,payment_asserted=False,reason='Target traffic zero before evaluating weight; no 0 times infinity'))
 return out

def run():
 specs=[('balanced','initial',[F(1,5)]*2,[F(1,5)]*2,F(3,4),F(1,4),F(1,2)),('underfilled','initial',[F(1,20)],[F(1,15)],F(3,4),F(1,4),F(1,2)),('S_dominant_new_gate','initial',[F(1,100)],[F(9,10)],F(3,4),F(1,4),F(1,15)),('P_dominant','initial',[F(2,5)],[F(1,100)],F(3,4),F(1,4),F(3,4)),('ell_tie','stress',[F(1,10)]*2,[F(1,10)]*2,F(7,8),F(1,8),F(1,2)),('tiny_z','stress',[F(1,1000)],[F(9,10)],F(3,4),F(1,2**30),F(1,2)),('tiny_rho','stress',[F(1,10)],[F(1,10)],F(3,4),F(3,4)-F(1,2**30),F(1,100)),('saturated_S','stress',[F(1,5),F(1,10)],[F(1,4),F(3,4)],F(9,10),F(1,10),F(1,3)),('mixed_likelihoods','expanded',[F(1,100),F(1,3),F(1,20)],[F(9,10),F(1,100),F(1,100)],F(4,5),F(1,5),F(1,4)),('tiny_common_mass','expanded',[F(1,2**40)],[F(1,2**39)],F(3,4),F(1,4),F(1,2)),('near_full_rho','expanded',[F(1,4)],[F(1,4)],1-F(1,2**20),F(1,2**20),F(1,2)),('large_ell','expanded',[F(1,2**40)],[F(1,2)],F(3,4),F(1,2**20),F(1,2**10))]
 rows=[]
 for spec in specs:
  util={'balanced':F(1),'underfilled':F(1,4),'tiny_common_mass':F(1,16)}.get(spec[0],F(3,4))
  row=case(*spec,util=util);invariants=['P_bad','S_bad','Pi_bad','z','d','rho','chi','ell','Fsup','Fcal','mjoin','same_integral_direct','source_budget']
  for sn,sj in [(F(2**20),F(1)),(F(1),F(1,2**20))]:
   scaled=case(*spec,util=util,scale_nu=sn,scale_J=sj)
   assert all(row[k]==scaled[k] for k in invariants)
  row['scaling_invariants_pass']=True;rows.append(row)
 assert any(any(r['new_only_gate']) for r in rows)
 invalid=[rejection('reject_'+k,stage,k) for stage,k in [('initial','negative_mass'),('initial','P_excess'),('stress','S_excess'),('stress','rho_zero'),('expanded','zero_P_positive_S'),('expanded','zero_J_scale')]]
 return dict(schema='r185_same_source_calibration_v1',arithmetic='Fraction exact, no floating point or normalization of P/S',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},cases=rows,zero_branches=zero_cases(),invalid_inputs=invalid,summary=dict(main_valid_cases=len(rows),invalid_rejections=len(invalid),zero_branches=3,all_checks_pass=True,unexpected_failures=[]),notes=['P/S are subprobabilities on the same bad domain and same nu, not free normalized probabilities','All positive cases recompute actual alpha and target d,z,rho from common arrays; p,k,J are strictly positive but no physical kernel extension is certified','Source budget is checked directly on the same integral with rho squared cancelled; it is not inherited by monotonicity from a bound for the smaller old weight','Actual alpha chi<=D gives ell=(D/chi)K0/p>=K0/p; pure ratio strengthening is pointwise finite algebra only','Zero alpha with k=0 and nonempty bad is not granted strictsoft bad elimination or a calibration payment','The completed wt posterior is finite algebra, not original reciprocal/current/high/FIRST/history qualification','No claimed general dimension growth or low-F full coverage'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'numerical_checks.json');args=p.parse_args();r=run();args.output.write_text(json.dumps(enc(r),indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
