# R185 独立预检与后审

本文件责任仅独审；不改其他作者、不Git/spawn/PDF、不跑数值。第一阶段未读本轮作者稿或历史locator文件，只读父/作者准确候选消息、后落盘task_contract.md及必要原定义；R183/R184冻结结论按已核范围使用。目的为原真实联合交通付款，不开展一般反例扫描。

## 1. 真实目标及行估计升级所需量词

固定原同window/seed，原J-share正raw在一次hard帽后为

    (32Λ/3) EΣ_(V,j)∫_Erec dx 1_{j(x)=j}∫β_V(dy)p_y
      ∫far dt/t ∬ H A_y(v)(k_t(v)−k_t(u))_+
                       1_R(u) Π_y,t(dv)Π_y,t(du)。

H保留原high/history/capture及已付支补集；本轮核心还带central d<z/e_g<M、lowFsup及A>1−η。A终端固定，z=∫A(wt−wg)ν，Π用原完整source，不条件化。目标是同一个对象的ε E∫Erec qdx加√n polylog(n)W_A，不是仅固定行/尺度小。static k=DK0区别于score k_t。

任何row stable bound须对原所有合法receiver选择与相同ν、同alpha成立，并能证明其实际p_yβ(dy)dx积分的价格。不能只把∫pβ·未知row系数改称范数后记为来源预算。ν/β仅共同父支配，均可相关；fixed-source核张量式不使来源独立。

固定(omega,V,j,y,t)时原ν、Zt、wt、et、Πt先于x；但terminalg、wg、A/rho/alpha、原s/L/R/Hhat、high和history仍依x。以fixedJ列归一支付dx之前，要先合法消去/控制这些实际乘子。s/L/Hhat逐y重选后不能再套一次共同FIRST。不同j/time域须保持原1j或统一ξ=cjt/b后再求和；不同window source重用和接收误差各收费。

若移y而改变Z_y、capture E_y、bad、history或Π的分母，要付相应交换，不能把核比稳定当概率稳定。若用原详细平衡换y/u，平稳测度是e_yν(dy)，真实degree比仍在；外β须保η=β∧ν与ζ+，不能无费换ν。改变receiver还须保持原selectors为原数据/合法拉回，不能免费重新极值化。原负信用、已付子支与epsilon预算都只用一次。

## 2. 原共同current/K0列的可用接口

原Hhat由同x的s,L,R,j给出，依R128 RT6是合法相同s、Hhat∈[a,b]测试。只要保持这一共同选择（不依当前y/V重选），原FIRST与同window Σβ≤f给

    Σ∫p_yβ(dy)≤q,   Σ∫K0_yβ(dy)≤q.

于是anchor {K0_y/p_y>T0}的原reciprocal正raw，用R182统一row常数Crec=16Λ/(3Kκ)后可付≤Crec/T0·E∫q；T0=Crec/ε给预分配ε接收费。high上p_y>0，无零分母。该接口只是实际共同核容量及正分割，不主张比旧future-ratio支严格扩大；若选择器非共同则必须先付其真实菜单/选择成本。

R184 EC一次收缩、nearU集中与KG的source-ratio lower均保原n rxi、Nh、硬jump、clamp、target乘子和q/QJ。nearU不是每行假设；若只作条件近极值陈述，不能由此支付所有远离极值的交通或无证迭代原状态。

## 3. 作者前独推：同点两source的比值差

令R184去跳连续核tildef_s=f_s exp[−j_s1_{r≤.5}]。对同一x,s,L,H，设B(q)=log tildef_s(q/H)−log tildef_s(q/L)。其a.e.导数为

    B'(q)=β_s(q/L)/L−β_s(q/H)/H,
    |B'|≤Lphi/min(H,L),  Lphi=2/(1−e^−1),

因两项非负有界，取差无需粗加成两倍。比较source u、v时，−nlog(H/L)精确抵消，剩余

    log[(K0_u/p_u)/(K0_v/p_v)]
      =Σ[B(|x−u|)−B(|x−v|)]
       +j_s[N_H(u)−N_L(u)−N_H(v)+N_L(v)].

体积抵消不等于cross项消失；闭面的source-specific计数仍须逐点保留。也可将smooth差上放为Lphi乘两个scaled路径区间的对称差长度，保留H→L时为0；不凭此推一般dx根价。reciprocal只能给带n rxi基准的source位移，未付硬环/源分母不会因行比较消失。

## 4. Astra/父精确新calibrated候选的作者前筛查

有效rho_v>0、alpha>0、QJ>0行，在原bad∩reciprocal域定义

    ell_u=q DK0_u/(alpha QJ p_u),
    Wcal_r=wg(y,v)^2 ell_u^r/rho_v², 0≤r≤1.

R183 JG6同alpha/current/high给∫ell^rΠ≤1/(2Kκ)。r0直接用current容量，r1用bad kν≤alpha QJ，0<r<1同ν Hölder。原companion含p_y²rho²J_v/(9Q_v²)；先在有效槽点态消rho²，再用good p_y wg_v≤KQ_v，得每端row≤KJ_v/(18κ)。high列、commonξ及fixedJ dx给

    C_rec[Wcal_r]≤C0 Wν, C0=log2/(36κ).

inversealpha/rho仅为显式权重定义；没有分别估计S与mu或改alpha/Π。inactive rho0/a0先零被积式，alpha0在原strictsoft K0>0下实际bad质量0；QJ0为原零ν行，不定义∞×0。

pair sup现在恰max(1,ell)，因此

    Fcal=wg_v² max(1,ell_u)/rho_v²,
    C_rec[Fcal]≤2C0 Wν,
    Raw[Fcal≥θ]≤(32Λ/3)sqrt[n log2/(36Kκθ)]Wν≤同系数W_A.

此处source-adaptive max明确付两个端点，旧单向energy只用一次。旧z_v=alpha J_v/a_v、d_v=1−k_v/a_v、rho=d_v−z_v给rho²z_v^r≤c_r d_v^(r+2)≤c_r，含r0rho²≤1。故旧每F_r≤Wcal_r，旧Fsup≤Fcal于全部active原流量，不需高A的eta限制。新价可以一次覆盖旧envelope门，不得旧价与新价双算。未证严格新增FULL实例/所有未付交通覆盖。

低Fcal<θ准确迫wg_v²<θrho_v²及ell_u<θrho_v²/wg_v²；该核心仍未付款。不得只因归一weight已付就把全unweighted companion认作已付。

## 5. Sol近pair/核比候选的作者前筛查

actual C尾公式给C1=∫_0^1 t²(1−e^−1/t)²dt≥(1−e^−1)²/3。0<d<1内|C'|≤1、C≥C1；d>1外指数混合的log hazard递减，边界≤(1/2)/C1。因此全logC为Lc=3/(1−e^−1)²<8 Lipschitz，跨d0/d1按AC积分，不丢边界。

对原互反u、终端good v且||u−v||1≤hb，wg_u>κ给wg_v≥κe^−Lch。因此ν{v∈Zg:wg_v≥κe^−Lch}/eg≤e^Lch/κ；targetZg不能丢。原recip/current/high另给νR/eg≤1/(2Kκ)。同一row逐pair有

    (kv−ku)+≤Σ1{Cv_i<ξ≤Cu_i},
    ∫actual(kv−ku)+dt/t≤Σlog+(Cu_i/Cv_i)≤Lc||u−v||1/b.

丢wt≤1、et≥eg及正额外门，但保上述target终端帽，得到row≤Lc h e^Lch/(2Kκ²)，恢复外费

    Raw_rec{||u−v||1≤hb}
      ≤16Λ/(3Kκ²) Lc h e^Lch E∫q.

可取h≤min(1/Lc,3Kκ²ε/(16eΛLc))付ε；无n、clock长度、alpha或ν总质量隐藏费。允许全部原删除，因为Zt仅正丢，score pair来自相同y/j和同ξ。此支已包含旧F0≥κ²e^−2Lch的根阶门，只记可替代epsilon价/必要远位移，不能冒称新增lowF覆盖；Fcal≥F0同样如此。低F<θ<κ²时必要||u−v||1>(b/Lc)log(κ/√θ)。

## 6. 第一阶段交付

task_contract后落盘已实读，符合上述量词。尚未读本轮作者完整证明或Luna历史locator；当前仅独立/准确候选先筛。后续按明确成稿一次核证明、全dx/source/j/window费及有限证据标签。当前最早缺口是低Fcal、高A、central clock的同源三点接收预算；上述calibrated支和near替代价不构成一般闭合。交付检查点后等待，不自行扩研究或数值扫描。


## 7. 后续准确候选的作者前独筛（仍未读成稿）

### 7.1 共同合法核的物理充分门

由原same-alpha定义 αQJ≤Dq，得 ell_u≥K0_u/p_u。故有效ρ>0上

    Fgeom=wg_v² max(1,K0_u/p_u)/ρ_v² ≤ Fcal。

该门也可不调用α而直接证明：原 reciprocal Π_R≤p_uν/(2Kκq)，原共同合法K0满足K0ν≤q，故∫R max(1,K0/p)Π≤1/(Kκ)。原companion点态消ρ²及good后，high/fixedJ/commonξ结算仍为2C0 Wν。它是Fcal已付支的物理充分门；不能另称普遍支配旧Fsup，也不把两门重收费。same-point ratio lower可直接形成该门，不再携旧J_v/a_v·q/QJ因子；signed hard-cross差仍保留。

高A与低Fcal的剩余必要式也正确：hstop≤g给Δ≤1−wg_v，A>1−η给k_v+αJ_v<ηTΔ；zα=αJ_v/(TΔ)<η及ell_u<θρ_v²/wg_v²给

    (k_u/p_u)(J_v/T)(q/QJ)
      =zα ell_u Δ < ηθρ_v²(1−wg_v)/wg_v²。

这仍是必要几何条件，不是付款；不得删D、T、QJ或原clamp。

### 7.2 同核远对亲和与显式选择费

令f_s=(1−s)h+sφ，γ_s=(√(1−s+sφhalf)−√(sφhalf))²。两个硬区间对称差长2min(d,1)，其上sqrt核差至少√m_s−√(sφhalf)，故

    ∫√[f_s(r)f_s(r−d)]dr ≤1−γ_s min(d,1)。

固定共同s,H的乘积核可张量，得到exp[−γ_s Σmin(|u_i−v_i|/H,1)]。H^n√(P_Hu P_Hv)单调（含向上硬跳），使共同adaptiveH的正包络费为1+nlog(b/a)。soft平均取δ=1/(n+1)，t∈[(1−δ)s,(1−δ)s+δsbar]，每坐标两核均≥(1−δ)原值，所以G_t≥(1−δ)^nG_s≥e⁻¹G_s；共同adaptive s∈[0,sbar]再付e(n+1)。sbar=0另列，不除0；sbar→1时γ退化。因而该工具的粗联合价为

    e(n+1)(1+nlog2) exp[−γ_sbar Σmin(|u_i−v_i|/b,1)]。

任意相关有限联合源可Tonelli，但仍是二次联合来源kernel价，不能无帽线性化W或支付原companion额外乘子。

### 7.3 不同current/J核的统一亲和缺额

τ=∫[-.5,.5]φ∈(0,1)。对B=[u−H/2,u+H/2]，p_s,H(B)=r_s=1−s+sτ；J_b(B)=t≤τ≤r_s，因为φ偶递减且H≤b。二分CS给亲和≤√(r_s t)+√((1−r_s)(1−t))；此式在t≤r_s随t递增，故≤

    a(s)=√(r_s τ)+√((1−r_s)(1−τ))。

a(s)随s递增，s<1严格小于1。固定同s,H的n维亲和≤a(s)^n，对任意u,v成立。该指数缺额不能在来源叠加后免费继承。

对G_s,L=√(P_s,L(x−u)J_b(x−v))，L^{n/2}G随L非减，故尺度包络精确系数n/2；同soft平均的安全费e(n+1)给粗全adaptive kernel价

    e(n+1)(1+(n/2)log2) a(sbar)^n,   0<sbar<1。

更精确可保留每坐标actual overlap A_s,λ；不能将§7.2同核的距离衰减直接转到不同核。上述所有新亲和结论仅核级，无原p_y/Q/e/history主乘子或双来源质量的全局付款声称。


## 8. 数值文件静态审查（未运行）

已实读numerical_checks.py/md，并读取既有JSON核计数与E分支结点。12个positive共同数组均从同ν、a/k/J/E反算α、χ、d/z/ρ，未自由拼ρ与α；按同一bad域构造P/S，mjoin/L1/overlap恒等式及每槽/总和付款直接检查ρ²消去。两次homogeneity保留实际α与χ；3个zero先分支，6个invalid在除法前reject。underfilled确含z ell=1/3结点。wt补全及κ=1/4只满足显式抽象domination，不认证原physical/reciprocal/high/FIRST/history。所有assert失败非零退出，标准库、唯一合同hash输入、无求积/随机扫描。当前静态审查通过，不把12例代替一般证明；父/数值作者实际重放证据另列，本独审未运行。


## 9. 第一份作者成稿后审：joint_extremal_payment.md

前述独立检查点形成后，现已全文实读JP1–JP11，后审通过，无数学修项。关键是JP12在同一原companion被积式先消ρ²；JP13再用原good/high、实际β与ν的容量。统一ξ=cjt/b之后才扩大原far窗口和合并唯一j，保留固定b的J概率归一，得到每端C0=log2/(36κ)，Fcal两端价2C0，以及raw根价(32Λ/3)√[nlog2/(36Kκθ)]Wν≤同系数WA。其处理t/receiver自适应、source/window重用、inactive先零与α0依赖strictsoft K0正性的边界均正确。

JP15–16旧Fsup≤Fcal仅用作门集合包含，新较大权重的上界由独立付款证明给出，未倒置单调性。JP17合法分割不消费负信用；若一次用Fcal覆盖旧同阈值门，可统一只收新价。JP18物理核比只充分门，JP19–22准确保留低Fcal、高A、同α的未付三点核心，未把必要式当付款或声称物理strict新增实例。calibrated_weight_history.md现亦已实读，仅视为指定三轮的窄历史定位，不认证所有历史新颖性或代替本轮证明。


## 10. 第二份作者成稿后审：shared_displacement_geometry.md

已全文实读SD1–SD11，后审通过，无实质修项。SD1–4的同点ratio体积精确抵消，半开硬环signed差、Omega两种界及H=L/面原子/s=1边界正确；SD5只对同一内ν、同α储备积分。SD6–7物理充分门2C0/root36回代与JP同价而非另领信用。SD8高A的联合缺额式与条件大target ratio造成连续位移/反向硬差的二选分歧，仅为条件必要式，未称远对已付款。

SD9–11的C全局LC<8、近对逐pair先积分score时钟、保终端Zg帽与两源质量比，恢复16Λ/(3Kκ²)的ε替代价准确；低Fcal/Fgeom远位移必要式保ρ。近对已在旧F0内，未报strict新增覆盖。SD12–14同核tensor亲和、实际共同soft/scale selector显式全费与sbar→1退化均正确；不同current/J核不能借同核距离衰减，二次来源和真实余乘子缺口均准确保留。

## 11. 父三源归一与混核亲和付款的准确候选预检

成稿前先筛：固定原window父质量M_V>0，π_V=β_V⊗ν_V⊗ν_V/M_V²固定不依x，因三质量≤M_V而||π_V||≤M_V。K(x;y,v)=√(p_y J_v)。将原唯一j在实际行中先保留/合并后定义

    B=M_V²√(p_y/J_v) A_v
        ∫actual dt/t H δ+ wt_v wt_u/e_t²。

原capped正raw恰为(32Λ/3)∫K B dπ dx；A只含一次原ρJ/(3Q)，H不再重复算它。M=0、原零交通、p0或et0分支先按原定义零延拓，不写0∞。当所有额外门保持原样，π无receiver局部重归一，这一式是合法实际积分分解。

父优化soft平均使用半指数，c_n=(n+1)(1+1/n)^(n/2)；混核L尺度费n/2，故对s(x)≤sbar<1的uniform核积分上界

    A_n=c_n(1+(n/2)log2)a(sbar)^n。

sbar=0去soft选择费单列。于是实际正branch B≤Bcap 的raw≤(32Λ/3)Bcap A_n W_A，取Bcap=√n/A_n为明确根阶来源支。它仍保留B大补集，不能报中央一般覆盖；跨window、原uniquej与父来源重用不得省价。本节当前仅准确候选筛查，待父成稿核定义和整合。


## 12. 父mixed_affinity_raw_budget.md全文后审

已实读MA1–MA7，后审通过。τ=1/3+2E4(1)及τ<2/3，二点概率CS缺额1−a≥(1−s)²(1−τ)²/2，真实核张量均正确。soft半指数比较给c_n中间界，最终明确统一使用coarse

    A_n=e(n+1)(1+(n/2)log2)a(sbar)^n,

与有限表一致；sbar=0单列。MA9的e(n+1)²exp[−n(1−sbar)²/18]及示例soft上门条件、空范围均正确，不把原strictsoft下门偷换成该上门。

MA12保留实际时积分、全部H和归一，先合uniquej再定义B；MA13为指定原J-share一次hard帽后的精确正因子分解，π固定总质量≤M，无改变后验或本地质量。MA15以固定三源Tonelli付款实际B小/soft上门子支，Bcap=√n/A_n给(32Λ/3)√n W_A；没有把未付范数只改名后当全局预算，而是显式保留其互补事件。该支可在原central/highA/lowFcal上正切，依定义的H须先固定，不按B门重构自身。

一般目标仍未闭合：s>sbar、B>Bcap、低Fcal核心及非互反/其他mother份额依其既有账保留，源window重用与接收误差不因π归一消失。near-pair ε是旧支替代价；same-kernel affinity只为其原类型核，不能直接给current/J或真实余乘子价格。


## 13. 新三源代数及混核诊断的静态范围核对

已全文实读triple_factor_check.py及既有JSON。9个Fraction例分三阶段，逐三元组直接密度pA·time与K B π完全同次数，父M变化时B的M²和π的M⁻²相抵；ν/β/M共同缩放保B而使来源价线性缩放，wt共同缩放与e²相抵。cutoff使用原B不重定义H，正切片上界方向正确。M0仅按父支配必须零来源的显式记录先分派，不形成除法。它不认证kernel积分、原FIRST/history或物理时钟。

affinity_checks.py/md初版已静态实读，φ的E3两段、τ独立积分、6个指定(s,H,b,d)、s0真紧支撑与s>0全线积分均正确；25/40dps差仅经验稳定性。初版全树含pycache及仅打印失败的问题已由独立numeric reviewer要求窄修；现已实读affinity_numeric_review.md最终回执，确认生产者只哈希*.py、任一观测比较失败保存JSON后非零退出。该reviewer实际唯一隔离重放完整JSON一致；本独审未重跑，也不以回执代替解析定理。16行表采用最终coarse A_n，不偷用更小中间c_n；不作interval、连续参数或FULL认证。


## 14. 最终整合窄核与冻结结论

已全文读proof.tex.txt/report.md及reproduce.py；两处整合措辞修正现已窄核落实：三源精确身份属于指定原J-share一次hard帽后的capped正量，原正量≤该量而其他mother未覆盖；A_n(0)=(1+(n/2)log2)τ^(n/2)在tex明确单列。报告保留coarse A_n的n²量级选择费，soft上门退化、真实父质量/后验分母、大B与低Fcal事件及跨window费用均未偷省。

已实读parent_verification.md最终回执：父实际reproduce入口隔离重放21项校准、9项三源和6积分/16表，三个完整JSON相等；本独审只静态检查，不重复运行。reproducer保留全部字段比较、依赖输入哈希及子进程失败退出；临时19项清单不是本审计绑定的最终inventory。provenance.json仅记录指定旧档与skill字节/定位角色，不等于本轮重新通读全部原档或通过归档哈希认证数学。详细tex未编译PDF。

最终结论：三份数学稿在明确范围内通过。Fcal给同原alpha、source与posterior下真实新加权companion及根阶子支，旧包络门包含不代替付款证明；混核三源B门给指定原J-share真实线性来源根阶分支；同点比差和近对/远对工具按已列费用与边界成立。未证一般中央低Fcal、高A、大B、soft尾以及其他未付分支的总估计。有限代数/经验求积不认证全维或一般输入结论。两条本轮付款可按原不交顺序使用，原负信用、接收epsilon及已付source价只消费一次。

下表为本独审实际读取并实算的最终SHA256；不包含自身、inventory或之后生成的归档验证文件。数学与证据标签冻结后本独审停止，不自行扩研究。

| 文件 | SHA256 |
|---|---|
| affinity_checks.json | `8a397b756a17b42f5ec47bbd22969ea13f83d675d1342a8516269dba958515c4` |
| affinity_checks.md | `46c5053e8766357757c004f6d77d451f8eef3f10668d641819b0adee0fb63a54` |
| affinity_checks.py | `7dd9855ff349590c471b85c26669d3fa8d1a0042718a6f49ee7fc8cc1c8c7f55` |
| affinity_numeric_review.md | `cd44d6b65d8d878ae970a917d693d8c5873ef1e5baef1accd5cb37276d04fc00` |
| calibrated_weight_history.md | `01c819bd61f4f3661dce14afcfd6a20f2d656da983a0852977638c99135e4c72` |
| joint_extremal_payment.md | `a6f2be1ba0a03ca907d230e60f12e3b7321b5c8a9914e7b8a48200b4c83a2d02` |
| mixed_affinity_raw_budget.md | `4d900a225ad51cba8717c8d6a93af0d8e80d5a0def55a6e8d4b723ce99086c1d` |
| numerical_checks.json | `92f86bcac9569cac133b1c40e381bc4b9bfe517b6106e0f348daf0ed6b6b8d13` |
| numerical_checks.md | `b9e33cf12eddbfd84ee9d6d418c061904a8428f2e3776ae41345c609fd696b28` |
| numerical_checks.py | `01c7684fdc13df54ca2be8b2ac843c25b8c236ed003bb65b466484b5672a630d` |
| parent_verification.md | `72d6d10d7beda4c51eb194a804a77e09f0ab0903ed72be7b57fbdd6babfbc141` |
| proof.tex.txt | `f31452d93cedff0aaf3035d82788776a5dd71a15bddb353be62aaa02620364d8` |
| provenance.json | `5b384c6dbd0dd33f493acda2a9c15f23027785a067285dddbde7e90110139ac9` |
| report.md | `92ef8a25e8a94b8c3454584a656e42e1225884b37885f6928bc49a3b681fcfa1` |
| reproduce.py | `d4115d7ea3a194864d0cb2dd225948c04e8dc104619731ca85ead579e157018a` |
| shared_displacement_geometry.md | `db4d70cc9aed510a5f04e55b2ddbf4f886f03a2ac28aba2b0a13e4a9b771279b` |
| task_contract.md | `4dac557d2b20959e36d7d829e55ea1135868f6769eb6d2f230d5fbd473b3b022` |
| triple_factor_check.json | `8e4845d4a23ee054d52de3bfcae9834e411331857265ecbc17b962dd6b416d50` |
| triple_factor_check.py | `e9161de18e42c368a8858ee460a92c4d34c2bc01fc980680aa066e11b5fb45c9` |
