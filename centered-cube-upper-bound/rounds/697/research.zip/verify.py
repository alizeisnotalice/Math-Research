from fractions import Fraction as F
from pathlib import Path
import json, hashlib
from zipfile import ZipFile

def read(path):
    return json.loads(Path(path).read_text())
def value(row,key):
    return F(row[key])
allseeds=set()
counts=[0]*5
for host,k in [('mini',120),('laptop',150)]:
    base,cert,ref=[read(host+t+'.json') for t in ('','-cert','-refined')]
    get=lambda data:{r['seed']:r for r in data['rows']}
    b,c,r=map(get,(base,cert,ref))
    assert b.keys()==c.keys() and not allseeds.intersection(c)
    allseeds.update(c)
    chosen=sorted(c,key=lambda s:value(c[s],'upper')-value(c[s],'mixed'),reverse=True)[:k]
    assert chosen==list(r)
    for seed,z in c.items():
        assert all(b[seed][key]==z[key] for key in ('bad','n','center','pure','mixed'))
        cen,p,m,u=map(F,[z[key] for key in ('center','pure','mixed','upper')])
        assert 0<=cen<=p<=m<=u<=1
        counts[0]+=p>cen
        counts[1]+=m>p
        counts[2]+=u==m
        counts[3]+=u<1
        if seed in r:
            new=F(r[seed]['mixed'])
            assert m<=new<=min(u,F(r[seed]['upper']))
            counts[4]+=m<new
    for data in (base,cert,ref):
        assert len({i['pid'] for i in data['rows']})==data['workers']
        print(host,len(data['rows']),data['workers'],sum(i['cpu'] for i in data['rows']),data['elapsed'])
assert allseeds==set(range(2160)) and counts==[2160,1220,529,2094,267]
print(counts)
