import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        sel.append(i)
        for k in rows[i]:load[k]+=w
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:pools[j]=[k for k in sel if h in inc[k]]
    # Width zero, real translations in units of 1/32. All endpoints integers,
    # unit half-owner intervals suffice and lengths cancel in ratios.
    shifts=(-32,-16,0,16,32)
    entries={i:[[] for _ in shifts] for i in sel}
    for h,(j,P) in enumerate(pools.items()):
        for i in P:
            for e,d in enumerate(shifts):
                for side in (0,1):
                    x2=2*y[j]+2*side-1
                    if abs(x2-2*(y[i]+d))<64:entries[i][e].append(2*h+side)
    m=2*len(pools)
    def opt(units,init):
        cfg={i:[init[i]]*units for i in sel}
        loads=[0]*m
        for i,menu in entries.items():
            for h in menu[init[i]]:loads[h]+=units*theta[i]
        target=q*units
        for _ in range(12):
            changed=False
            for i,menu in entries.items():
                w=theta[i]
                for k,old in enumerate(cfg[i]):
                    for h in menu[old]:loads[h]-=w
                    scores=[sum(min(w,max(0,target-loads[h])) for h in slot) for slot in menu]
                    best=max(range(len(menu)),key=scores.__getitem__)
                    if scores[old]==scores[best]:best=old
                    changed|=best!=old
                    cfg[i][k]=best
                    for h in menu[best]:loads[h]+=w
            if not changed:break
        return sum(min(target,v) for v in loads),cfg,loads
    zero={i:2 for i in sel}
    fixed=sum(min(q,sum(theta[i] for i in P if abs((2*y[j]+2*side-1)-2*y[i])<64)) for j,P in pools.items() for side in (0,1))
    pure,conf,_=opt(1,zero)
    mix,_,loads=opt(4,{i:c[0] for i,c in conf.items()})
    assert 4*fixed<=4*pure<=mix<=4*m*q
    # Integer dual masks. For every f in [0,1]^m, weak duality bounds
    # the optimum over arbitrary probabilities on the five translations.
    scale=2**20
    f=[scale if v<4*q else 0 if v>4*q else scale//2 for v in loads]
    upper=m*q*scale
    # Exact Polyak-style steps for this finite piecewise-linear objective.
    for it in range(144):
        inflow=[0]*m
        cost=q*(m*scale-sum(f))
        for i,menu in entries.items():
            values=[sum(f[h] for h in slot) for slot in menu]
            best=max(range(len(menu)),key=values.__getitem__)
            cost+=theta[i]*values[best]
            for h in menu[best]:inflow[h]+=theta[i]
        upper=min(upper,cost)
        if 4*upper==mix*scale:break
        grad=[v-q for v in inflow]
        sq=sum(v*v for v in grad)
        assert sq and 4*cost>=mix*scale
        gap=4*cost-mix*scale
        f=[max(0,min(scale,old-(gap*g//(4*sq)))) for old,g in zip(f,grad)]
    assert 4*upper>=mix*scale
    return dict(seed=seed,n=n,bad=m//2,center=str(Fraction(fixed,m*q)) if m else None,pure=str(Fraction(pure,m*q)) if m else None,mixed=str(Fraction(mix,4*m*q)) if m else None,upper=str(Fraction(upper,m*q*scale)) if m else None,cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:])
    start=time.monotonic()
    with get_context('fork').Pool(workers) as p: rows=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rows)))
