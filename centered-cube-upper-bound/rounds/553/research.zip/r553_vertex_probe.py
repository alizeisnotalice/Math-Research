"""R553 fixed product atomic model; binary64 receiver and pair Monte Carlo only."""
from pathlib import Path
import json, time, sys, hashlib, itertools
import numpy as np
import scipy
START=time.monotonic()
N=4096; PAIRS=131072; BATCH=8192; SEEDS=[55301,55302]

def roots(n,seed,N=N):
 rng=np.random.default_rng(seed); b=rng.uniform(-.75,.75,(N,n))
 labels=np.zeros((N,n,2),bool); kroot=np.full(N,-1,int); residual=0.; margins=[]
 dist=2*np.abs(b[:,:,None]-np.array([-.25,.25]))
 for k in range(n+1):
  side=2.**(-k/n); membership=dist<=side
  count=np.prod(membership.sum(2),axis=1,dtype=np.int64)
  threshold=np.max(np.where(membership,dist,0),axis=(1,2))
  take=(kroot<0)&(count==(1<<(n-k)))&(threshold<side)
  labels[take]=membership[take]; kroot[take]=k
  if take.any(): residual=max(residual,abs(side**n-2.**(-k)))
  if take.any(): margins.extend((side-threshold[take]).tolist())
 inside=kroot>=0
 return b[inside],labels[inside],kroot[inside],dict(N=N,inside=int(inside.sum()),outside=int((~inside).sum()),domain_volume=1.5**n,E_volume_estimate=1.5**n*inside.mean(),level_counts={str(k):int(np.sum(kroot==k)) for k in range(n+1)},min_strict_margin=min(margins) if margins else None,max_mass_level_residual=residual)

def run(n,seed):
 b,l,k,meta=roots(n,seed); m=len(k); rng=np.random.default_rng(seed+100000)
 out=dict(n=n,seed=seed,receivers=meta)
 if m<64:
  out['stopped']='fewer than 64 receivers; no support tuning';return out
 side=2.**(-k/n);v=np.ldexp(np.ones(m),-k)
 factor=(1.5**n)**2*m*(m-1)/(N*(N-1))
 h=np.exp(1/(4*np.sqrt(n))); sums=[]; stats=np.zeros(6,dtype=np.int64)
 for start in range(0,PAIRS,BATCH):
  z=min(BATCH,PAIRS-start);a=rng.integers(m,size=z);c=rng.integers(m-1,size=z);c+=c>=a
  common=np.prod(np.sum(l[a]&l[c],axis=2),axis=1,dtype=np.int64)
  # Geometric overlap of closed cubes; boundary zero volume.
  overlap=np.prod(np.maximum(0,np.minimum(b[a]+side[a,None]/2,b[c]+side[c,None]/2)-np.maximum(b[a]-side[a,None]/2,b[c]-side[c,None]/2)),axis=1)
  ratio=side[c]/side[a];scale=(ratio>h)&(ratio<=n+1);low=overlap<v[a]/np.sqrt(n);core=scale&low
  mass=np.ldexp(common.astype(float),-n);positive=core&(common>0)
  weights=np.zeros(z);weights[positive]=2*mass[positive]/(v[a[positive]]*v[c[positive]])
  escale=np.log(v[c]/v[a]);scarce=np.zeros(z);scarce[positive]=np.log(v[a[positive]]/mass[positive])
  vals=np.stack([weights,weights*escale,weights*scarce],axis=1)
  sums.append(vals.mean(0)*factor)
  stats+=np.array([z,scale.sum(),core.sum(),positive.sum(),np.sum(core&(common==0)),np.sum(positive&(common==(np.ldexp(v[a],n).astype(np.int64))))])
 arr=np.array(sums);means=arr.mean(0);se=arr.std(0,ddof=1)/np.sqrt(len(arr))
 out.update(pair_count=int(stats[0]),pair_counts=dict(scale=int(stats[1]),core=int(stats[2]),positive_core=int(stats[3]),zero_source_core=int(stats[4]),positive_core_full_small_capture=int(stats[5])),Ustat_weight=factor,Acore=float(means[0]),Ecap_scale=float(means[1]),Ecap_scarcity=float(means[2]),Ecap=float(means[1]+means[2]),scarcity_entropy_fraction=float(means[2]/(means[1]+means[2])) if means[1]+means[2]>0 else None,conditional_batch_standard_error=dict(Acore=float(se[0]),scale=float(se[1]),scarcity=float(se[2])),batch_estimates=arr.tolist(),elapsed_seconds=time.monotonic()-START)
 return out

def independent_events():
 audits=[]
 for n in [2,4]:
  centres=np.random.default_rng(SEEDS[0]).uniform(-.75,.75,(N,n))
  atoms=np.array(list(itertools.product([-.25,.25],repeat=n)))
  for idx in [0,1,7,31]:
   b=centres[idx]; entry=np.max(2*np.abs(atoms-b),axis=1)
   events=np.unique(np.r_[0,entry,2.])
   candidates=[]
   for lo,hi in zip(events[:-1],events[1:]):
    count=np.sum(entry<(lo+hi)/2)
    if count:
     r=(count/(2**n))**(1/n)
     if lo<r<=hi:candidates.append(r)
   brute=max(candidates) if candidates else None
   product=None
   for k in range(n+1):
    r=2.**(-k/n);mem=2*np.abs(b[:,None]-np.array([-.25,.25]))<=r
    count=np.prod(mem.sum(1)); threshold=np.max(np.where(mem,2*np.abs(b[:,None]-np.array([-.25,.25])),0))
    if count==2**(n-k) and threshold<r:product=r;break
   agree=(brute is None and product is None) or (brute is not None and product is not None and abs(brute-product)<1e-14)
   assert agree
   audits.append(dict(n=n,sample_index=idx,centre=b.tolist(),explicit_atom_count=2**n,event_count=len(events),event_enumeration_root=brute,product_root=product,agree=bool(agree)))
 return audits

def main():
 records=[]
 # Stage 1: the prescribed n=2,4. Stage 2: only retain expansion if receivers are not scarce.
 for n in [2,4]:records.append(run(n,SEEDS[0]))
 if all(r['receivers']['inside']>=64 for r in records):
  for n in [6,8]:
   if time.monotonic()-START>35:break
   r=run(n,SEEDS[0]);records.append(r)
   if r['receivers']['inside']<64:break
 # One independent fixed-seed repeat diagnoses receiver sampling, only for informative estimates.
 for n in [r['n'] for r in records if r.get('pair_counts',{}).get('positive_core',0)>=100]:
  if time.monotonic()-START>48:break
  records.append(run(n,SEEDS[1]))
 result=dict(resource_guard=dict(batch_size=BATCH,largest_dimension=8,memory_note='Batch arrays are O(8192*8); conservative working-array estimate below 32 MiB, excluding interpreter/libraries; no giant pair matrix or RSS measurement.'),model=dict(atoms='uniform on {-1/4,+1/4}^n',mass=1,lambda_=1,domain='[-3/4,3/4]^n',N=N,pair_draws=PAIRS,batch=BATCH,seeds=SEEDS),formulas=dict(Acore='2 integral_K i/(VB VC)',Ecap='2 integral_K i/(VB VC) log(VC/i)',decomposition='log(VC/i)=log(VC/VB)+log(VB/i)',pair_weight='domain_volume^2*m*(m-1)/(N*(N-1)); sampled ordered distinct inside indices; factor2 inside integrand'),root_audit='For each mass level 2^-k test product count=2^(n-k), maximum captured-source entry threshold<side. Select smallest k. Every strict superlevel interval has constant captured count and descends to its mass-level root, or jumps to a larger mass count before it; finite event levels therefore exhaust actual outer roots. Equality-only events excluded.',scope='Binary64 root geometry and Monte Carlo receiver/pair quadrature; conditional batch errors omit receiver sampling error. No confidence or strict certificates. No 8192 receiver stage: fixed-seed diagnostic repeat suffices for the bounded decision, no convergence claim.',records=records,independent_explicit_event_audit=independent_events(),versions=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__),command=f'{sys.executable} {Path(__file__)}',elapsed_seconds=time.monotonic()-START,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
 print(json.dumps([{key:r.get(key) for key in ['n','seed','receivers','Acore','Ecap_scale','Ecap_scarcity','scarcity_entropy_fraction','conditional_batch_standard_error','pair_counts']} for r in records],indent=2))
if __name__=='__main__':main()
