from fractions import Fraction as F
from flint import arb,ctx
from math import isqrt
import json,sys
ctx.prec=256
def calc(n,off):
    a=32*n;J=n//8;dx=F(1,4*a);core=F(1,16*a)
    xx=F(7,128);v=1-F(63,64)-xx
    xs=[xx+(i-F(J-1,2))*dx for i in range(J)]
    assert xs[0]-core+F(63,64)>1+F(6,n) and xs[-1]+core<F(1,16)
    assert dx>2*core
    cut=[1-F(63,64)-x for x in xs]
    ref=[v>q for q in cut];test=[v+off>q for q in cut]
    mismatch=sum(i!=j for i,j in zip(ref,test))
    assert all(abs(v-q)>core for q in cut)
    assert all(abs(v+off-q)>core for q in cut)
    gap=max(q for q,ok in zip(cut,ref) if ok);top=min(q for q,ok in zip(cut,ref) if not ok)
    assert top-gap==dx and (gap<v+off<=top)==(mismatch==0)
    K=4096*isqrt(n)*a**n; el=arb(2).log()/K
    V=arb(J)/(8*a)**n;H=V*el.expm1()/2
    lg=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-el).expm1()).log()
    assert H>0 and H<V/4 and lg>(4*arb(8)**n+1).log()
    return dict(n=n,rows=J,offset=str(off),mismatches=mismatch,gap=str(dx),owner_width_normalized=str(dx+F(2,a)),
         high=str(H),V_T=str(V),logD_div_K_bounds=[str(lg/K),str((lg+arb(3).log())/K)],excess=0)
print(json.dumps(dict(python=sys.executable,bits=256,cases=[calc(n,d) for n in (256,1024,4096) for d in (F(0),F(3,4*32*n),F(1,256))]),indent=2))
