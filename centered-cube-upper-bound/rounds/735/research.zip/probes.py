from fractions import Fraction as F
import itertools,json,platform,sys,subprocess
from pathlib import Path
def solve(depth,tol,remote=False):
    leaves=[];cut=F(1,4)
    def tree(lo,hi,L,H,w,pred,d):
        if H<=L:return
        if (H-L)<=cut*w or d==depth:
            leaves.append((L,H,w,(H-L)<=cut*w));return
        probe=(lo+hi)/2; forecast=pred
        for b in (0,1):
            prob=F(7,8) if b==forecast else F(1,8)
            tree(probe if b else lo,hi if b else probe,max(L,probe-tol) if b else L,
                 H if b else min(H,probe+tol),w*prob,(forecast+b+1)%2,d+1)
    tree(F(0),F(1),F(0),F(1),F(1),0,0)
    cells=[(l,h) for l,h,p,passes in leaves if passes]
    if remote:
        pts=sorted(set(itertools.chain.from_iterable(cells)));vol=sum((v-u for u,v in zip(pts,pts[1:]) if any(l<(v+u)/2<h for l,h in cells)),F(0))
    else:
        vol=F(0);prev=F(0)
        for l,h in sorted(cells):vol+=max(F(0),h-max(prev,l));prev=max(prev,h)
    Q=sum((h-l for l,h in cells),F(0));P=sum((p for l,h,p,yes in leaves if yes),F(0))
    assert vol<=Q<=cut*P<=cut
    return [depth,str(tol),len(cells),str(vol),str(Q),str(P)]
def runs(remote):return [solve(k,F(1,j) if j else F(0),remote) for k in (4,8,12) for j in (0,256,4096)]
if '--remote' in sys.argv:
 print(json.dumps(runs(True)));sys.exit()
data=runs(False)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
p=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=90)
assert p.returncode==0 and json.loads(p.stdout)==data
print(json.dumps(dict(python=sys.executable,version=platform.python_version(),checks=data,cmd=cmd,remote_exit=p.returncode,match=True),indent=2))
