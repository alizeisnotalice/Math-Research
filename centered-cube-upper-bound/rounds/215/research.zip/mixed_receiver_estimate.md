# R215：原双来源时钟吸收共同接收矩的位移指数

本文证明一个适用于真实混合 slack 补域的加权接收核估计：在 CM12 的共同接收积分中保留原两份未归一化时钟权，可以消除该式的正来源位移指数，并留下显式衰减。它不假设来源有指数矩，不改变原来源中心或捕获状态。维数指数、inverse-soft、原 T、双 e_t 分母及全部窗口账仍保留；一般 signed 根阶预算尚未闭合。

## 1. 原量词与出处

窄读来源为 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md`，SHA256 `14e2d1021fed0379308ad9a8d75a756b3e706742d6343e3c53ba4ccc3275fb12`。其 637–667 行、RT4–6 给下列核和时钟合同；604–633 行、RT1–3 给原外测度和正负泛函。固定原 (ω,V,j,y,t) 后，ν_V、Z_t、w_t、e_t、Π_t 均独立接收点 x；终端 g、G/B、w_g、当前 s,L、K0 的尺度、capture α、FA/Ψ 与全部剩余历史门仍可依 x。本文使用原 Π_t，不换成 Π_g。

原核为 h=1_[−1/2,1/2]、w(r)=∫_0^1 exp(−|r|/a)da、φ=h*w、f_s=(1−s)h+sφ。设 F=max(h,φ)，
\[
 C(d)=\int_{-1/2}^{1/2}F(z-d)\,dz,\qquad
 d_z=(z-y)/b,\qquad \xi=c_jt/b,
\]
\[
 w_z:=w_t(y,z)=\prod_i\min\{1,C(|d_{z,i}|)/\xi\},\qquad
 \Pi_t(dz)=e_t^{-1}1_{Z_t}(z)w_z\nu_V(dz).
 \tag{MR1}
\]
因此 MR1 的 d_z 与 CM4/CM9 中换元 x=y+bX 后的来源位移恰是同一个向量；没有把 x−z、y−z 或另一行的来源中心混用。

上述 R128 的第637行定义 γ=1+1/n、c_j=γ^(−j) 及原非负比例索引，因而 0<c_j≤1；同一行给 τ_j=a_win/c_j≤g≤bc_j 与 h=g exp(−u/n)<g。原 far 域 t∈[a_win/c_j,h]，故
\[
 a_{win}/b\le\xi\le c_j^2\le1,\qquad \xi\ge1/2.
 \tag{MR2}
\]
在去掉 x 依赖的 far 门后，只扩大到固定 j 的 [a_win/c_j,bc_j] 与原定义域的交集；空区间置零。这一窗口的 log 长度不超过 log2，但不同 j 的来源/clock 不能因此免费合并。

同一 x 的 p_y=P_{s,L}(x−y)、J_z=P_{1,b}(x−z)、K_z=K0_z=P_{s,Hhat}(x−z)，L,Hhat∈[b/2,b]。本文严格 soft 部分取 s(x)≥s_min>0。原 strict-soft 下门可提供维数依赖 s_min，但不是维数无关常数。

原混合补域为每腿 z=v,u 同时满足
\[
 \mathfrak a_z={L_0J_z\over p_yw_z},\qquad
 \mathfrak b_z={K_z\over\kappa T w_z},\qquad
 \mathfrak a_z+\mathfrak b_z<1.
 \tag{MR3}
\]
p_y=0、w_z=0、e_t=0 或原空行先按零贡献处理。所有原 good/bad、baseline target、capture/high、剩余域与 suffix 门均可保在左侧；下述正估计删除它们时，只得到正上界，不授新模型或新负信用。

## 2. 物理 C 的全位移界

因为 φ≤1，F≤1，所以 C≤1。若 d≥1，h 部分与积分区间不重叠（d=1 的单点无积分质量），故 C(d)=(h*h*w)(d)。利用 w(r)≤e^{−|r|} 及卷积位移绝对值≤1，得 C(d)≤e^{1−d}。d≤1 时由 C≤1 得同一指数上界。因此
\[
 0<C(d)\le\min(1,e^{1-d}),\qquad d\ge0.
 \tag{MR4}
\]
设 d_ξ=1−logξ。对任意 P>A≥0，直接分 d≤d_ξ 与 d>d_ξ：
\[
 \boxed{\min(1,C(d)/\xi)^P e^{Ad}
 \le e^{A d_\xi}\exp[-(P-A)(d-d_\xi)_+].}
 \tag{MR5}
\]
第一段只用时钟因子≤1；第二段用 C(d)/ξ≤e^{d_ξ−d}。MR2 给 1≤d_ξ≤1+log2。这里 A 是矩的位移系数，不是原 target 权。

## 3. 共同接收矩的加权定理

固定非负指数 r,t_*,θ,χ，令
\[
 R=r+t_*,\quad \Theta=\theta+\chi<1/2,\quad A_0=1+R.
\]
t_* 是矩指数，绝不是原积分时刻 t。取共同预定参数
\[
 \epsilon={1-2\Theta\over4(1+R+2\Theta)},\quad
 c_\epsilon={\epsilon\over1+\epsilon},\quad
 \delta_*={3\over4}(1-2\Theta)>0,
\]
\[
 A_v=(1+\epsilon)(r+2\theta),\quad
 A_u=(1+\epsilon)(t_*+2\chi),\quad
 P_v=1+r+\theta,\quad P_u=1+t_*+\chi,
\]
\[
 \sigma_v=P_v-A_v>0,\qquad \sigma_u=P_u-A_u>0.
 \tag{MR6}
\]
确有 ε(R+2Θ)≤(1−2Θ)/4，所以 CM8 的全尺度尾率至少 δ_*。又 ε(r+2θ)≤(1−2Θ)/4，故 σ_v≥1−θ−(1−2Θ)/4>0；u 同理。ε 依全部固定指数选取，未声称只依 Θ。

定义
\[
 B_*=2^{A_0}c_\epsilon^{-(R+\Theta)}s_{min}^{-\Theta}
 \exp\{A_0/2+(1+\epsilon)(R+\Theta)/2\},
\]
\[
 \mathcal D_\xi(v,u)=
 \exp\{-\sigma_v\sum_i(|d_{v,i}|-d_\xi)_+
          -\sigma_u\sum_i(|d_{u,i}|-d_\xi)_+\}.
 \tag{MR7}
\]
在固定原 j,y,t,b 的实际来源对上，即使 s,L,Hhat 为任意满足上述范围的共同可测 x-selector，仍有
\[
 \boxed{
 w_v^{P_v}w_u^{P_u}
 \int p_y^{A_0}J_v^{-r}J_u^{-t_*}K_v^{-\theta}K_u^{-\chi}\,dx
 \le b^{n\Theta}
 \left({2B_*\over\delta_*}\right)^n
 e^{n(A_v+A_u)d_\xi}\mathcal D_\xi(v,u).
 }
 \tag{MR8}
\]
证明：CM9 的逐点共同 X 包络，在 λ=L/b、η=Hhat/b∈[1/2,1] 下为
\[
 b^{n\Theta}\,B_*^n e^{-\delta_*\|X\|_1}
 e^{A_v\|d_v\|_1+A_u\|d_u\|_1}
\]
（这里包括 x=y+bX 的单位）。先在同一个 X 上用此统一包络，再积分，给 (2/δ_*)^n。原 w_v,w_u 固定于接收积分之外。逐坐标使用 MR5 消去两个正位移指数，正好得到 MR8。没有交换 sup 与积分，没有将两腿共同 X 的矩拆成两个独立矩。

与 CM12 相比，MR8 不要求原 ν 具有任何正指数位移矩；两份额外的 1 来自真实双 Π 中各自的一份 w_t，而不是添加的来源权。它保留的是有界的实际距离衰减核。本文不据此声称 MR8 在每一参数区间都优于直接删门的粗正核估计。

例如 r=t_*=1/4、θ=χ=1/8 时，ε=1/16，A_v=A_u=17/32，P_v=P_u=11/8，σ_v=σ_u=27/32，δ_*=3/8。这是符号恒等的合法参数点，不是由数值拟合选择出的阶数。

## 4. 真混合 slack 的回代

沿用 CM5c 的已审 sharp 常数
\[
 C(r,\theta)={r^r\theta^\theta\over(r+\theta)^{r+\theta}},
 \quad C=1\text{ 在零指数端点},
 \quad C_{mix}=C(r,\theta)C(t_*,\chi).
\]
由同一 MR3（先保完整 slack，后才使用该标量上界），
\[
 w_vw_u\int p_y1_{mixed}\,dx
 \le {C_{mix}(\kappa T_{max})^\Theta\over L_0^R}
 w_v^{P_v}w_u^{P_u}
 \int p_y^{A_0}J_v^{-r}J_u^{-t_*}K_v^{-\theta}K_u^{-\chi}\,dx.
 \tag{MR9}
\]
若 T 固定可用实际 T；若沿当前 selector 变化，T_max 是该同一窗口内有证明的上界。原 T=c_j^{n/2}/(g^n√ℓ)、g≥a_win/c_j 给
\[
 T_{max}\le c_j^{3n/2}/(a_{win}^n\sqrt\ell).
 \tag{MR10}
\]
不可仅因 MR8 允许 selector 就把 T(x) 当常数。

结合得实际加权接收核价格
\[
 w_vw_u\int p_y1_{mixed}\,dx\le\mathcal K_n\mathcal D_\xi(v,u),
\quad
 \mathcal K_n={C_{mix}(\kappa b^nT_{max})^\Theta\over L_0^R}
 \left({2B_*\over\delta_*}\right)^n e^{n(A_v+A_u)d_\xi}.
 \tag{MR11}
\]
指数、inverse-soft、T_max 和真实 ξ 费用全部显示。也可在 MR9 中保实际 capture/good/bad 门，得到不超过此右侧的价格；本证明没有额外量化那些门的改善。

## 5. 原 raw、双 e 与第一处未付项

在原 RT1 硬承载一次 16/3 上界之后，正余项的同一实际测度具有形式
\[
 {32\Lambda\over3}\mathbb E\sum_{V,j}
 \int\beta_V(dy)\int {dt\over t}
 \int_{Z_t^2}{w_vw_u\over e_t^2}\nu_V(dv)\nu_V(du)
 \int_{E_{rec}} p_y\,H_{rem}\rho_{0v}(k_t(v)-k_t(u))_+
 1_{mixed}\,dx .
 \tag{MR12}
\]
H_rem 只包含原 high、终端 G/B、FA/Ψ、unique j、所有尚未支付域及合法时间资格的指示乘积，故 0≤H_rem≤1；ρ0 已在式中另列。具体 Ψ=1_{𝒵ᶜ}、χ_FA 的指示定义及两端域见上述 R128 的 613–625 行、RT2。硬承载已按 R214 RD14 的原 RT1 正上界单独结算，不把任何未有界密度暗藏进 H_rem。若实际原剩余 signed 表达另含已消费负额，其账沿原合同不变。本文只估计 MR12 的正部分，负余额仍保留一次。

用 ρ0≤1、(k_v−k_u)+≤n，再用 MR11，可严格得到
\[
 R^+_{mixed}\le {32\Lambda\over3}n\,
 \mathbb E\sum_{V,j}\int\beta_V(dy)
 \int_{I^0_{j,V,y}}{dt\over t}\,
 {\mathcal K_n\over e_t^2}
 \iint_{Z_t^2}\mathcal D_\xi(v,u)\nu_V(dv)\nu_V(du).
 \tag{MR13}
\]
I^0 是 MR2 的共同 x-independent 扩窗与原定义域交集。e_t=0 行取零而非形成 0/0。unique j 在 MR12 中精确保留；MR13 正放此门后出现真实 j 求和，不宣称免费唯一性。不同 b/窗口各保自身 K_n、β、ν、e_t 及源账。

这里是精确第一处未付款：原双 w_t 已用于 MR5 的位移吸收，MR13 中剩下的是 ν_V²/e_t² 加权衰减核，不是原 Π_t² 概率。不能再次用 ∫Π_t=1 消去这两份相同 w_t。尤其 σ_v、σ_u 不等于 1，D_ξ 并非 w_vw_u；没有从 FIRST 上容量推出其与 e_t² 的比较。

已证结果消除了 CM12 中任意来源的正位移指数积分要求，但仍有显式 K_n 的指数维数与上述来源重用账。即使删去所有共同 capture 门后可给另一个粗上界，也不把它登记为新增根阶结算。要从这里推进 signed 目标，必须在 MR12 的真实 high/capture/终端 G/B 与负余额下，控制同一来源的剩余重用；本稿没有把它替换成独立来源、没有假设 ν≤β，也没有给低 K0 来源质量添加反向帽。

本轮界是合法的原加权共同接收核改进，尚不是一般 mixed 补域的根阶付款。R214 已付帽外分支及 ε_mix 槽均不重复领取。
