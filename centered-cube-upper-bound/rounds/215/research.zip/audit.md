# R215 independent audit — final frozen review

Final status: the analytic statements, finite evidence and integration pass within the scopes recorded below. Section 8 binds all nine other work files. Earlier pending statements preserve the chronology of independent screening and are superseded by the final review. The original general signed mixed-cap/root-order budget remains unproved.

Status: independent premise review before any R215 author proof or numerical code. Read only task_contract.md for the new round. Only this audit file is owned by the auditor; no numerical execution, Git, PDF compilation or new agent is authorized or performed. Final manuscripts/evidence and byte binding remain pending.

## 1. Exact object retained

The original mixed-cap complement is the two-leg joint condition a_z+b_z<1, with a_z=L0 J_z/(p_y w_t(z)), b_z=K0_z/(kappa T w_t(z)). It is not merely the intersection a_z<1,b_z<1. The same receiver x, actual selector, RT1 source measure, full Pi_t tensor-square and e_t^{-2}, unique j/window qualification, target-only rho0 support, and original available negative must remain. The R214 additive-cap positive allowance was paid once and is not new credit this round.

The task is an improvement for this original object, not just another fixed-parameter normalization or a new cap. Fixed physical coordinate configurations may diagnose the already specified joint integral; they do not certify full history, FIRST/high/clamp qualification or a high-dimensional FULL input.

## 2. Independent exact physical tail screen

For fixed s in (0,1], finite displacements d_v,d_u, lambda,eta>0 and nonnegative exponents r,tau,theta,chi, put R=r+tau, Theta=theta+chi and A=1+R. The normalized one-dimensional factors are

    p_lambda(z)=lambda^{-1} f_s(z/lambda),
    j_d(z)=phi(z-d),
    k_eta,d(z)=eta^{-1} f_s((z-d)/eta).

The integrand is p_lambda^A j_dv^{-r} j_du^{-tau} k_eta,dv^{-theta} k_eta,du^{-chi}, sharing a single z throughout. The physical w kernel has

    w(x)=integral_0^1 exp(-|x|/a) da ~ exp(-|x|)/|x|,
    phi(x)=(h*w)(x) ~ M_h exp(-|x|)/|x|,
    M_h=integral_{-1/2}^{1/2} exp(t) dt=2 sinh(1/2)>0.

For example, w's equivalence follows by setting t=1/a, then scaling t-1 by 1/|x|; dominated convergence gives the limiting constant one. The phi equivalence then follows uniformly over its compact convolution shift. On the tails f_s=s phi, so a normalized scaled factor has leading constant s M_h/|z|, with its scale retained in the exponential rate; an extra leading lambda^{-1} or eta^{-1} must not be introduced after this cancellation.

Define

    delta0=A/lambda-R-Theta/eta,
    Dshift=(r+theta/eta)d_v+(tau+chi/eta)d_u.

As z tends to either tail, the complete integrand is asymptotic to

    C_plus exp(-delta0 z) z^{Theta-1}       (z -> +infinity),
    C_minus exp(-delta0 |z|) |z|^{Theta-1} (z -> -infinity),
    C_plus/minus = s^{A-Theta} M_h^{1-Theta} exp(-/+ Dshift).

Both constants are strictly positive and finite under the stated fixed strictsoft assumptions. They cannot cancel, because the integrand is nonnegative. Thus the one-dimensional integral is finite if and only if delta0>0: equality delta0=0 has polynomial power Theta-1>=-1 and diverges; negative delta0 diverges exponentially. Zero exponents simply remove their factors. Compact portions are finite because J and K are strictly positive there and the finite hard jumps in p or K introduce no denominator zero for s>0.

For lambda,eta in [1/2,1], delta0>=1-2Theta, so Theta<1/2 is sufficient over all these scales. It is also the exact condition if every scale pair is to be included: lambda=1,eta=1/2 has delta0=1-2Theta, hence Theta=1/2 already diverges. This statement is integrability, not a dimension-free or economical uniform bound. Explicit bounded constants additionally need the actual exponent, s_min, displacement, parameter-range and positive-gap qualifications. The pure-hard s=0 case cannot be obtained by placing zero into inverse kernels or multiplying zero by infinity; it has a separate support problem.

The n-dimensional moment still has the audited scale factor b^{n Theta}. Positive tensorization is across receiver coordinates for fixed physical parameters, not across the two source legs. The two source labels remain correlated through the same receiver variable in each one-dimensional factor.

## 3. Finite tail bounds and quadrature evidence

A computable exponential envelope may use epsilon>0 and c_epsilon=epsilon/(1+epsilon), with w>=c_epsilon exp(-(1+epsilon)|x|), phi>=c_epsilon exp(-(1+epsilon)(|x|+1/2)). Its actual gap is

    delta_epsilon=A/lambda-(1+epsilon)(R+Theta/eta)>0.

Then a verified integrand upper bound B exp(-delta_epsilon |z|) gives the rigorous analytic remainder 2B exp(-delta_epsilon X)/delta_epsilon outside [-X,X]. All B constants, scale normalization and displacement/softness costs must be explicit. Choosing a smaller delta_epsilon gap for convenience increases the tail cost. A bound proved only for one parameter configuration is not a free selector envelope.

At fixed parameters split the physical integrand at both outer hard faces z=+/-lambda/2 and both K hard-face pairs d_v+/-eta/2,d_u+/-eta/2. Splitting also at the J/phi seams d_v+/-1/2,d_u+/-1/2 and other actual nonsmooth formula seams is legitimate. Coincident seams should be deduplicated, without deleting one-sided intervals. Point values at fixed hard faces have zero Lebesgue mass for this finite integral; that fact must not be generalized to receiver-adaptive selectors locked to a face.

Numerical finite-core quadrature at 25 and 40 decimal digits, agreement of those answers, and a rigorous analytic tail upper bound are three distinct pieces of evidence. Their combination is not an interval certificate for the core unless numerical integration error is independently certified. A reported cut integral can be accompanied by its one-sided analytic remainder and precision sensitivity without claiming that its decimal digits are rigorous. No unexecuted six-row proposal is recorded as passed.

The six requested coordinate configurations cannot establish uniform source/scale/softness asymptotics, a fitted n-order, or original high-dimensional FULL qualification. Shared-x joint moments must not be replaced by the product of separately integrated source-leg moments. Any Monte Carlo or finite-precision evidence, if later authorized, needs its own declared scope rather than inheriting the analytic tensor identity.

## 4. Remaining adaptation and review status

R214 already supplies an explicit but expensive common pointwise selector envelope. Its exponential-in-n, inverse-soft and source-displacement costs remain real; arbitrary finite positive sources do not supply their moments for free. The source Pi normalization and the full RT1 beta/hard-source measure cannot be replaced by a natural receiver probability or a linear W_A budget without a proved connecting inequality. Source-dependent threshold/capture fields must not be moved through the receiver integral as constants unless the corresponding original freezing is actually valid.

H04 is used only as the previously read real-model/moment-domain/uniform-range discipline. No external LDP, MDP, Gaussian approximation, rate-function tail theorem or new literature claim is applied. Await the accurate author statements and final evidence before full review; the general signed mixed-cap complement remains unpaid.

## 5. Actual clock weight versus positive source-displacement growth — premise screen

Before reading the spatial author's new proof, independently checked the stated candidate. At fixed original j,y,t, let xi=c_j t/b in [1/2,1] and d=|y_i-z_i|/b. The actual clock factor is min(1,C(d)/xi). The general bound C<=1 and the tail bound C(d)<=exp(1-d) for d>=1 give, with d0=1-log(xi), every P>A>=0,

    min(1,C(d)/xi)^P exp(A d)
      <=exp(A d0) exp(-(P-A)(d-d0)_+).

For d<=d0 use the clock factor<=1. For d>d0>=1 use C/xi<=exp(d0-d). The tail equality C=h*h*w is needed only for d>=1; it must not be claimed as the global definition of C=h*max(h,phi).

After multiplying the CM5 threshold powers by the two unnormalized original posterior clock weights, P_v=1+r+theta and P_u=1+tau+chi. The uniform CM12 displacement exponents are A_v=(1+epsilon)(r+2theta), A_u=(1+epsilon)(tau+2chi). One can simultaneously enforce the positive receiver tail gap and P_v>A_v, P_u>A_u by choosing epsilon from the actual fixed exponents, since Theta<1/2. The explicit inequalities include epsilon(r+2theta)<1-theta and its other-leg counterpart. An epsilon depending only on Theta is not uniform over unbounded r+tau.

This absorbs the positive source-displacement exponent into actual clock decay. It removes the requirement for an unrestricted positive exponential source moment in this specific coarse upper bound. It does not pay the remaining exponential-in-n constant, inverse softness, Tmax/window and selector costs, or double source mass divided by e_t^2. In particular, the w_v w_u factors used here cannot subsequently be used again as an untouched posterior normalization to erase the residual source mass. Awaiting the full precise statement and original-measure application.

## 6. First full analytic and numerical reviews

After the independent screens, read joint_kernel_analysis.md in full (73d21f44a724b44d431bb2a8e10677ed69166a1846732de4d511857c1edb4343). JK1–18 pass within their declared fixed-parameter domain. The proof explicitly derives the physical tail rather than importing a rate theorem. Its extended two-scale version replaces theta/eta+chi/eta by theta/eta_v+chi/eta_u and has the correct direction-dependent constants. The exact delta0=0 logarithmic/power divergence, local strictsoft integrability and full-scale-rectangle qualification agree with the independent screen.

The explicit relative tail error also passes: Z>=max(2D*,D*+8a*) makes every relative kernel error at most one half. The log-error bound (16a+2|d|)/|z| is safe, so the exponent-weighted C_err and the two-sided JK12 bound follow. JK13 keeps the exact remaining positive tail integral; its simplified bound is restricted to 0<=Theta<=1. JK14's fixed-gap asymptotic and the stated compact-parameter/uniform-gap requirements retain all constants. The strictsoft tail relative error does not need 1/s, while uniform control of the whole moment still does require a lower softness bound or its full actual cost.

JK15–18 correctly distinguish common-receiver covariance from independent leg integration. Cauchy–Schwarz and Holder are upper bounds only after checking their respective higher-moment domains. The family lambda=1,eta_v=eta_u=1/2,r=tau=0,theta=3/10,chi=1/10 has joint gap 1/5 but U-second-moment gap -1/5, hence is a genuine physical fixed-kernel domain distinction, not a claim about original FULL inputs. The gradient/Hessian identity uses the same tilted receiver law and differentiates only the four moment exponents within a strict-gap region. It does not differentiate actual capture/selector fields. No necessary correction was found.

Read physical_joint_checks.py and numeric_notes.md completely, and inspected the frozen JSON without executing its generator. The script uses the true phi E3 formula, the normalized outer and both normalized K kernels, and a common integration variable in every factor. Its independent phi controls use the actual Laplace-scale integral. Main exponents are r=tau=1/4,theta=chi=1/8; the other three exponent sets are HH joint and the two separately integrated single-leg diagnostics. No independent-leg product is substituted into a proof.

There are six prescribed coordinate configurations, four moments at each of two precisions, hence 48 finite quadratures, plus twelve phi controls. All fixed hard faces, phi centers and seams are included in a deduplicated split; strictsoft denominators are positive. The CM9 log-B formula retains lambda^{-A}, eta^Theta, c_epsilon^{-(R+Theta)}, actual s^{-Theta} and both displacement exponents. Epsilon=1/4 gives positive gaps in the entire specified menu. The per-case common radii 73,74,169,20,45,185 are computed against all four analytic CM10 requirements at 60 dps and retained across both final precisions.

The JSON main 40-dps finite values begin 1.3938482406, 1.6894854944, 2.4914793107, 3.5093387983, 8.1888370070, 125.0207282278, matching the notes. The notes distinguish the analytic tail formula from its nondirected floating evaluation, noncertified finite-core quadrature, internal nonrigorous error indicators and cross-precision sensitivity. They do not add these into a rigorous interval enclosure. The six coordinate configurations do not construct a source measure, original mixed-event mask, posterior, selector, FIRST/high/history or FULL qualification. JK's newly proved tail/CS statements are not advertised as additionally numerically tested.

The frozen numeric hashes match actual bytes:

    physical_joint_checks.py   f779c96933d1381cbf97c5e4287361083a99caab5e9d0676105ed7ea83f3d37b
    physical_joint_checks.json 7178fc0e97607e0eea79d9d5331f5ce0a26e31db9f3634669d1faf011dccc29f
    numeric_notes.md           adc06f79fb82b6c5c333ec10d17d66ba4b23f46f46dd620b4347897d6ae4418d

The author reports actual local execution and isolated script+contract byte-identical replay, 12.827 seconds for the latter. This audit did not run either. Full spatial-author review, final TeX/report/driver review and final hash binding remain pending; no frozen final audit is claimed yet.

## 7. Full weighted receiver manuscript and integration review

Read mixed_receiver_estimate.md in full, first at e251f436fbff1c9889d32e70c0da2f24dc68cbd26be80957ec746f6244d72399 and then its provenance/scope-only update 6a3f62e06a227b372d105833147b2ea08204afd00e79c1438d94ec86ee76eefb. Independently read R128 research.zip's proof.md lines 637–667 for the actual definitions and freezing qualification. The cited external frozen proof.md exists and is byte-identical to that ZIP member, SHA-256 14e2d1021fed0379308ad9a8d75a756b3e706742d6343e3c53ba4ccc3275fb12. No broad historical reread was required.

MR1 uses exactly the original source-y displacement d_z=(z-y)/b, agreeing with CM9's receiver substitution x=y+bX. The original t>=a_win/c_j and g<=b c_j imply xi=c_j t/b in [a_win/b,c_j^2], hence [1/2,1]. The original nu,Z,w,e,Pi freezing is only for fixed omega,V,j,y,t; terminal and capture/selector fields are explicitly not granted that property. After positive release of the receiver-dependent far gate, its stated x-independent extension has logarithmic length at most log 2 when nonempty, with actual different-j source costs retained.

MR4–8 pass. The C tail argument uses h*h*w only on d>=1. The chosen epsilon=(1-2Theta)/[4(1+R+2Theta)] gives receiver tail gap at least delta_*=3(1-2Theta)/4 and both positive clock-decay gaps. Its stated example epsilon=1/16, A_v=A_u=17/32, P_v=P_u=11/8, sigma_v=sigma_u=27/32, delta_*=3/8 is exact. The common pointwise selector envelope is integrated before its source-displacement growth is absorbed by the two actual clock powers. The scale factor b^{nTheta}, softness cost and exponential-in-n constants are present. No sup-integral exchange or independent-source tensorization is used.

MR9–11 correctly apply the original mixed slack before the scalar C_mix relaxation. T(x)^Theta is replaced only by the proved actual-family Tmax, not declared independent of the selector. The dimensionless combination is (kappa b^n Tmax)^Theta. Both actual clock factors provide the additional one in P_v,P_u. Thus the result genuinely avoids demanding positive exponential moments of arbitrary finite sources in this coarse envelope, while not claiming an economical constant.

MR12–13 retain the original outer measure before its single hard-source positive bound and explicitly expose the later release of the unique-j gate as a real sum over j. H_rem is only the original bounded indicator product and rho0 is written separately; no uncontrolled density is hidden there. The bound with factor (32 Lambda/3)n, K_n/e_t^2 and the double nu decay integral has the correct order. The manuscript correctly warns that its two w factors have already been consumed in the absorption step: the remaining source integral is not Pi_t tensor-square, and no second posterior normalization or free e_t^{-2} cancellation is authorized. Source pair/selector/window/high/goodbad/negative costs remain unresolved.

Read the current complete proof.tex.txt through enddocument against both manuscripts. The tail proof, relative error bound, fixed-moment domain, common-receiver covariance/CS example, weighted selector envelope, source-weight absorption, exact mixed relaxation and explicit unpaid W4 bound agree. The numerical section states its actual finite evidence and limitations. No necessary mathematical or transcription repair was found in this version. Final digest binding is still deferred until the parent declares the full integration set frozen.

Statically read reproduce.py: it requires mpmath in the chosen Python, preserves the actual dependency environment, checks the complete manifest, uses a relocated script+contract copy, requires a fresh unprotected output, compares complete reference JSON bytes and rechecks the package. The auditor has not executed it. The parent reports an actual independent numerical rerun with complete byte identity; final post-manifest driver execution remains the parent's later action. Final report review and actual byte binding are pending.

## 8. Final report review, approved scope and byte binding

Read the final complete 260-line proof.tex.txt, report.md and driver against the two mathematical attachments and the frozen numerical evidence. The TeX correctly records the precise tail constants/scale cancellation, integrability iff, explicit relative remainder, covariance versus independent legs, actual clock displacement absorption with its common selector bound, and the still-unpaid double-source W4 expression. It does not turn the positive kernel estimate into an original signed budget. No necessary mathematical or transcription repair remains.

One report summary qualification was corrected at the auditor's request: the physical mixture range is explicitly 0<s<=1, rather than an unrestricted s>0. The final report retains this bound. Its six coordinate configurations, 48 finite quadratures, twelve independent phi controls, specified cutoff radii, example values, noninterval uncertainty, original FULL/source/selector limitations and the parent's actually reported direct replay are consistent with the frozen files. It does not claim the final manifest-driven replay has already occurred. The exact-tail and source-absorption conclusions are justified analytically, not inferred from the numerical menu.

The approved substantive result is the weighted same-receiver kernel estimate MR8 and its actual mixed positive application MR11–13: the two original unnormalized clock factors absorb CM12's positive source-displacement growth, retaining a bounded decaying source kernel. No positive exponential source moment is required for that coarse bound. Its exponential-in-n coefficient, inverse softness, actual amplitude/scale/window costs, real sum over released unique-j gates and nu_V^2/e_t^2 source reuse remain explicit and unpaid. It is not a new cap allowance and does not reuse R214's low-cap or epsilon_mix credit. The source weights used in absorption are not available for a second posterior normalization.

The exact strictsoft physical moment criterion and the CS-versus-joint domain distinction pass for the stated fixed parameters and general positive scales. Uniform bounds require their declared gap, compact-scale, displacement/exponent and softness qualifications. The complete scale rectangle statement does not assert physical realizability of each corner. No probability large-deviation theorem, source independence, nu<=beta, gratis receiver-selector normalization or paid negative credit was introduced.

Auditor actions were mathematical/code/JSON reading and read-only digest calculations; the only modified file was this audit. The auditor did not execute physical_joint_checks.py or reproduce.py, compile a PDF, run Git or spawn an agent. Numerical author and parent executions are attributed as such. The future parent manifest-driven relocated replay remains to be actually run and recorded by the parent after this freeze.

At binding the directory contains ten regular files, including this audit, and no manifest. The nine other files were hashed from their actual final bytes and will be rechecked against this table. This audit and the future manifest are excluded to prevent self-referential binding. Any later byte change requires the corresponding narrow renewed review and updated binding.

| File | SHA-256 |
|---|---|
| joint_kernel_analysis.md | 73d21f44a724b44d431bb2a8e10677ed69166a1846732de4d511857c1edb4343 |
| mixed_receiver_estimate.md | 6a3f62e06a227b372d105833147b2ea08204afd00e79c1438d94ec86ee76eefb |
| numeric_notes.md | adc06f79fb82b6c5c333ec10d17d66ba4b23f46f46dd620b4347897d6ae4418d |
| physical_joint_checks.json | 7178fc0e97607e0eea79d9d5331f5ce0a26e31db9f3634669d1faf011dccc29f |
| physical_joint_checks.py | f779c96933d1381cbf97c5e4287361083a99caab5e9d0676105ed7ea83f3d37b |
| proof.tex.txt | b2ce19a89cb4fad3253ce38f8b03c4a5f0ec332534f9b5b009ba097c5cbdf9dc |
| report.md | 4824f8c1d09780d0668de9fbb01cbf55f25a54fdd8d07ba326c4d07b8f933c2b |
| reproduce.py | 0f05917793ed3a9e35b88eb4cc7566c7b6ebfe57b4fcbcbb8c65c87bb4f21e5f |
| task_contract.md | 8685bee179e7cb6dbf26317b00e133849da684ec3e858cb4f1828078a5cdd657 |

Final review frozen after the actual-byte recheck. No author correction or other required audit work remains; the original general theorem and identified source budget remain open.
