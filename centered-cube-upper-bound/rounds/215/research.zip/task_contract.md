# R215 真实共同接收核矩与混合余量

R214已推送6664fa3c4d46cf10c551b7554eac863d38e98fc1。只读冻结 /Users/zhengzhihao/Desktop/T/output/centered_cube_round214_20261016_final_checkpoint/。一般目标不变，本轮不另造cap或重复归约；要检验并改善原混合帽补域的真实共同receiver几何。

准确补域：每腿z=v,u满足 a_z=L0J_z/(p_y w_t(z))、b_z=K0_z/(κT w_t(z))、a_z+b_z<1。原RT1真实dx、两来源完整Π²/e²、uniquej/窗口/selector、rho0 target与负余额都保留。R214已支付补域之外一次(16Λ/3)sqrt n WA+ε_mix X，不能重复领取。当前来源/receiver预算仍未付。

可用R214 CM3–12：同x联合矩p_y^(1+r+tau)Jv^-r Ju^-tau K0v^-θ K0u^-χ，固定参数张量m_i精确，尺度b^(nΘ)；Θ<1/2为原[.5,1]尺度的充分可积域，实际delta0=A/λ−R−Θ/η。CM5b保非tensor slack，CM5c sharp scalar常数后才正放。CM12具有显式指数/位移/selector成本，不能当根预算。R123/124已存在arcsine软度混合和AJ盒菜单，不重复登记。

本轮三阶段真实物理一维共同x积分：初步同源/对称，小软度或scale端点/异向来源压力，再扩大位移/精度/截断。参数仅coordinate-kernel配置，不认证完整clamp/history/FIRST或n维FULL。数值要独立核实际kernel表示、硬面分段、解析尾与精度敏感性；25/40dps一致不是interval证明。禁止把joint integral拆成各腿乘积、从有限n拟合阶数。

职责：Sol medium r171_numeric_design physical_joint_checks.py/json与numeric_notes.md，按主代理指定六行执行；Astra r166_raw_budget mixed_receiver_estimate.md，唯一核心为在真实source几何上改善CM5b/CM12的指数损失，尽力形成原signed预算，不再新cap；Sol high r166_exact_certificate joint_kernel_analysis.md，核精确kernel尾/共同矩解析与一致性，避免与Astra空间路线重复；Sol high r164_audit audit.md先筛准确命题，再审结果。主代理任务协议、实际复跑、决定可推进路线及终轮整合。

所有人不是独自编辑，仅责任文件，不Git/PDF/自启代理，必要更新复用当前Agent。依H04真实矩/参数纪律，不用LDP名称猜阶。仅经审查的实质成果归档；一轮结束再独立commit/push，未闭合一般目标明确保留。
