# R215：真实共同接收矩的精确尾、端点与分腿比较

状态：给任意实际严格soft s∈(0,1]、任意正尺度、有限来源位移及非负矩指数的精确尾；在此范围联合矩有限当且仅当delta0>0。零gap不是可积端点。给可用于截尾的显式相对误差包围、共同矩与独立乘积的准确协方差身份，以及CS/Hölder的上界方向和真实可用域区别。没有新增空间cap、来源预算或一般弱型闭合。

使用R214冻结CM3--12的定义，只分析同一receiver变量。H04真实模型/一致范围纪律继续适用；不援引LDP/MDP。父级指定六行数值只校验已运行的物理坐标积分，不自动核验本稿所有尾渐近、CS反例或原完整输入。

## JK1　一般尺度下的准确一维对象

保原物理h=1[-1/2,1/2]、w(x)=∫0¹exp(−|x|/a)da、phi=h*w、fs=(1−s)h+sphi。所有实际s∈(0,1]均包括；不取s0后仍逆除零核。

先将原b缩为1、y缩为0。lambda=Lcur/b>0；可允许两腿正尺度eta_v,eta_u>0，原实际共同Hhat对应eta_v=eta_u=eta。固定finite dv,du，定义
\[
 p(z)=\lambda^{-1}f_s(z/\lambda),\quad
 j_v(z)=\varphi(z-d_v),\quad
 k_v(z)=\eta_v^{-1}f_s((z-d_v)/\eta_v),
\]
\[
 j_u(z)=\varphi(z-d_u),\quad
 k_u(z)=\eta_u^{-1}f_s((z-d_u)/\eta_u).
 \tag{JK1}
\]
取r,tau,theta,chi≥0，R=r+tau，Theta=theta+chi，A=1+R。准确integrand与矩为
\[
 g(z)=p(z)^A j_v(z)^{-r}j_u(z)^{-\tau}
 k_v(z)^{-\theta}k_u(z)^{-\chi},\qquad
 m=\int_{\mathbb R}g(z)\,dz.
 \tag{JK2}
\]
零指数因子1；strictsoft使所有分母严格正。这里每因子使用同一个z，不能将来源位置改成不同receiver变量。

## JK2　w与phi的真实尾：leading常数及可核算误差

对x>0，作a=x/(x+t)的代换，精确得
\[
 w(x)=\frac{e^{-x}}x
 \int_0^\infty e^{-t}(1+t/x)^{-2}dt.
 \tag{JK3}
\]
因1−2u≤(1+u)^−2≤1，对x>0有
\[
 1-2/x\le x e^xw(x)\le1.
 \tag{JK4}
\]
下界在x>2时为正；尤其w(x)~e^−x/x。w偶，负尾相同。

令Mh=∫[-.5,.5]e^h dh=2sinh(1/2)>0。对x>5/2，将JK4在x−h上积分，可得明确包围
\[
 \frac{x}{x+1/2}\left(1-\frac2{x-1/2}\right)
 \le\frac{x e^x\varphi(x)}{M_h}
 \le\frac{x}{x-1/2}.
 \tag{JK5}
\]
因此phi(x)~Mh e^−x/x；由偶性两侧同常数。还可安全取
\[
 \left|\frac{x e^x\varphi(x)}{M_h}-1\right|\le4/x,
 \qquad x\ge5.
 \tag{JK6}
\]
证明：上偏差为(1/2)/(x−1/2)≤1/x；下偏差由
(1/2)/(x+1/2)+2x/(x²−1/4)≤4/x控制。不存在隐藏的source概率或极限定理。

故对任意a>0、固定d和s>0，超过硬core后精确fs=sphi，得到
\[
 a^{-1}f_s((z-d)/a)
 \sim sM_h\frac{e^{-|z-d|/a}}{|z-d|}.
 \tag{JK7}
\]
尺度前因子a^−1与尾中(|z-d|/a)^−1恰抵消；若错误留下额外lambda^−A eta^Theta，将错计leading常数。硬面只在有限位置，尾推导不微分它们，不产生虚构delta。

## JK3　共同矩的两侧精确尾与必要充分可积条件

置
\[
 \delta_0=A/\lambda-R-\theta/\eta_v-\chi/\eta_u,
\]
\[
 C_\pm=s^{A-\Theta}M_h^{1-\Theta}
 \exp\!\left[\mp\left\{
 (r+\theta/\eta_v)d_v+(\tau+\chi/\eta_u)d_u\right\}\right]>0.
 \tag{JK8}
\]
将JK7及phi尾逐因子相乘，得到
\[
 \boxed{g(z)\sim C_\pm e^{-\delta_0|z|}|z|^{\Theta-1}
 \quad(z\to\pm\infty).}
 \tag{JK9}
\]
多项式阶来自−A+R+Theta=Theta−1；leading常数的soft幂为s^(A−Theta)，不是s^Theta或各腿独立平均。来源方向影响C+与C−，不改变指数gap。

在任意紧z区间，所有分母phi、fs严格正且有正下界，只有有限幅硬跳，不存在局部不可积奇点。于是对非负矩指数
\[
 \boxed{m<\infty\quad\Longleftrightarrow\quad\delta_0>0.}
 \tag{JK10}
\]
证明：delta正时指数衰减压过任意多项式；delta负时至少一侧指数增长；delta0时两侧为正系数|z|^(Theta−1)，Theta≥0不可能可积。有限位移不能抵消两侧正尾。

令m_Z=∫[-Z,Z]g。端点精确发散阶为
\[
 \delta_0=0,\ \Theta=0:\quad
 \frac{m_Z}{\log Z}\to C_++C_-,
\]
\[
 \delta_0=0,\ \Theta>0:\quad
 \frac{m_Z}{Z^\Theta}\to\frac{C_++C_-}{\Theta}.
 \tag{JK11}
\]
这是直接积分JK9并作(1±epsilon)夹逼，不借概率渐近。这里修正R214此前已删去的端点猜测；并不修改其仅调用严格gap的已证上界。

## JK4　相对尾包围及一致范围

下面给不依浮点拟合的正包围。设a*=max(1,lambda,eta_v,eta_u)，D*=max(|dv|,|du|)。取Z≥max(2D*,D*+8a*)。每个scaled kernel在|z|≥Z均处于严格外尾；JK6的相对误差≤1/2。

以sigma=sign(z)，q=|z|。对a尺度、d中心的任一fs核，将其与sMh e^−q/a e^(sigma d/a)/q比较。因
|log(q/|z−d|)|≤2|d|/q，且|log(1+epsilon)|≤2|epsilon|（|epsilon|≤1/2），其log误差绝对值不超过(16a+2|d|)/q。phi腿同理取s=a=1。因此令
\[
 \begin{split}
 C_{err}={}&16A\lambda+r(16+2|d_v|)+\tau(16+2|d_u|)\\
 &+\theta(16\eta_v+2|d_v|)+\chi(16\eta_u+2|d_u|),
 \end{split}
\]
则
\[
 \boxed{e^{-C_{err}/q}C_\sigma e^{-\delta_0q}q^{\Theta-1}
 \le g(\sigma q)\le
 e^{C_{err}/q}C_\sigma e^{-\delta_0q}q^{\Theta-1},\quad q\ge Z.}
 \tag{JK12}
\]
这也自含证明JK9。strictsoft尾fs=sphi精确，故相对误差常数不含1/s；但C±保全部s幂，不推出整个矩在s→0时一致有界。

delta>0时，两侧尾的严格正上界为
\[
 \int_{|z|>Z}g(z)dz
 \le e^{C_{err}/Z}(C_++C_-)
 \int_Z^\infty e^{-\delta_0q}q^{\Theta-1}dq.
 \tag{JK13}
\]
末积分可按其正定义求上界；特别0≤Theta≤1时≤Z^(Theta−1)e^−deltaZ/delta。它与R214较粗CM10可择一使用，不以不同precision一致替代有限窗quad的严格误差。

并有固定delta>0的准确尾质量
\[
 \int_{|z|>Z}g(z)dz\sim
 \frac{C_++C_-}{\delta_0}e^{-\delta_0Z}Z^{\Theta-1}.
 \tag{JK14}
\]
证明令q=Z+t，提取e^−deltaZ Z^(Theta−1)，剩余积分收敛到∫0∞e^−delta tdt=1/delta；JK12保证误差消失。

一致性范围必须明说：尺度限于正紧区间、位移有共同有限界、指数在有界集合中、delta0≥delta_min>0，则Z与Cerr可统一，JK12--14有相应一致控制。若要整个m及其参数导数统一有界，还需s≥smin>0控制紧receiver区间的inverse核；只有tail相对式时不必删去显式s幂。source位移无界或尺度趋0、delta趋0时不得外提相同常数。

对原lambda,eta∈[1/2,1]、共同eta，有delta0≥1−2Theta。矩形尺度范围内Theta<1/2既保证每个矩可积，也对覆盖全部尺度是sharp：lambda1,eta1/2给delta0=1−2Theta。这里的必要性指这个完整正核参数矩形，不声称该端点必由每份原clamp/history输入实现；实际关系可能给更窄可行域。积分常数还依smin/位移/指数上界，不因正gap而维度免费。

## JK5　两来源的独立化为何不合法，CS到底给什么

在固定p(z)dz概率下定义
\[
 U(z)=(p(z)/j_v(z))^r k_v(z)^{-\theta},\qquad
 V(z)=(p(z)/j_u(z))^\tau k_u(z)^{-\chi}.

\]
若所写有限，精确有
\[
 \boxed{m=\mathbb E_p[UV]
 =\mathbb E_pU\,\mathbb E_pV+\operatorname{Cov}_p(U,V).}
 \tag{JK15}
\]
共同z没有被复制为两个独立变量；不证明协方差的符号就不能以两个single积分乘积当upper。

实际CS上界方向为
\[
 m\le\sqrt{\mathbb E_pU^2\,\mathbb E_pV^2}.
 \tag{JK16}
\]
更一般a>1、a'=a/(a−1)给Holder上界(EU^a)^(1/a)(EV^a')^(1/a')，必须核对应高阶矩有限。它们的尾判别仍由JK10逐项计算；CS要求
\[
 \delta_U=(1+2r)/\lambda-2r-2\theta/\eta_v>0,
 \quad
 \delta_V=(1+2\tau)/\lambda-2\tau-2\chi/\eta_u>0.
 \tag{JK17}
\]
共同矩有限并不保证这两个条件。真实物理核的一般族：lambda1、eta_v=eta_u1/2、r=tau0、theta3/10、chi1/10，任意fixed s>0、finite dv/du，joint gap=1/5，U二矩gap=−1/5，V二矩gap=3/5。故共同m有限，而CS右侧为infinity。这里不是一个浮点例，是对所有这些s/位移的尾判别；它说明保共同矩可保更大的可用指数域，而不产生一般来源付款。

相同两腿、r=tau、theta=chi且U=V时，m=EU²≥(EU)²；U非常数且二矩有限时严格。因而独立乘积至少在这种实际kernel配置下低估共同积分，不能充当有效上界。未授权的finite族不作为额外已运行数值。

## JK6　有限矩母函数的真实梯度与协方差

在delta0>0的参数内点，定义共同tilt概率dP*=g(z)dz/m。令
Z(z)=(log(p/jv),log(p/ju),−logkv,−logku)。局部指数取值在有界集合且保持严格gap时，尾log因子至多线性增长，JK12与delta buffer支配任意有限阶导数；紧区间strictsoft分母正，故可微分积分。
\[
 \nabla\log m=\mathbb E_*Z,\qquad
 \nabla^2\log m=\operatorname{Cov}_*(Z,Z)\succeq0.
 \tag{JK18}
\]
这里梯度仅对(r,tau,theta,chi)，固定原s/尺度/来源位置，不是对可跳的capture/selector作微分。交叉Hessian项是共同receiver的真实协方差；不能设零来分解Chernoff优化。需要统一导数常数时按JK4保smin、位移、尺度和指数范围。它是有限积分恒等式，不授LDP速率或原Pi的Fisher/方差估计。

## JK7　回到原n维与实际来源的范围

固定真实参数时，n维矩仍为b^(nTheta)∏m_i，仅由receiver product核和Tonelli；本稿一维精确判别逐i适用。原s/L/H是共同receiver选择，若随x变，不可先分别取每个m_i最优参数再相乘；原R214 CM12或已核AJ适配费仍须原样保留，不能用固定核积分替代∫sup。

原mixed补域精确slack(1−a_v)^theta(1−a_u)^chi仍是完整n维核比值的非tensor函数；JK2只分析取R214 CM5c常数放松之后的矩。保留slack的原积分可能更小，但不能以本尾式声称已经控制了它的原RT1来源/receiver预算。target额外capture与bad资格不混同。

固定原omega,V,j,y,t后，若完整Pi_t独立x，才可对固定v,u联合矩用非负Tonelli；原G/B、high、Hrem、T、g与actualsource masks依x时须保或明确正放。C±含来源位移指数，任意finite nu不保证相应指数矩；原Pi²/e²、β、硬源与唯一j/window重用也没有自动消去。新精确尾及CS可用域区别不构成一般线性WA预算。

数值接口：六个父级指定physical coordinate配置只核其实际共同积分、singleproduct对照和CM10有限截尾。JK8--18新增解析结论不预报已数值测试；25/40dps一致不等于interval认证，不由有限n推测阶数。全文未改其它人的数据或稿件，交付后停止。
