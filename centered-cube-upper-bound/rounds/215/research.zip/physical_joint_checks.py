#!/usr/bin/env python3
"""Finite same-receiver physical kernel moments, noninterval quadrature."""
import argparse,hashlib,json,time
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
CASES=[('initial','.75','1','1','0','0'),('initial','.75','1','1','.5','-.5'),
       ('stress','.25','1','.5','.5','-.5'),('stress','1','.5','1','0','2'),
       ('expanded','.99','.75','.75','2','-2'),('expanded','.75','1','.5','4','-4')]
EXPS=[('main','0.25','0.25','0.125','0.125'),('HH_joint','0.25','0.25','0','0'),
      ('HH_single_v','0.25','0','0','0'),('HH_single_u','0','0.25','0','0')]

def phi(x):
    r=abs(x);h=mp.mpf('.5')
    return 1-mp.expint(3,h-r)-mp.expint(3,h+r) if r<=h else mp.expint(3,r-h)-mp.expint(3,r+h)

def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)

def tail_parameters(s,lam,eta,dv,du,r,t,theta,chi):
    eps=mp.mpf('.25');ce=eps/(1+eps);R=r+t;bigtheta=theta+chi;A=1+R
    delta=A/lam-(1+eps)*(R+bigtheta/eta)
    assert delta>0
    logb=-A*mp.log(lam)+bigtheta*mp.log(eta)-(R+bigtheta)*mp.log(ce)-bigtheta*mp.log(s)
    logb+=A/2+(1+eps)*(R+bigtheta)/2
    logb+=(1+eps)*((r+theta/eta)*abs(dv)+(t+chi/eta)*abs(du))
    return {'epsilon':eps,'c_epsilon':ce,'A':A,'R':R,'Theta':bigtheta,'delta':delta,'log_B':logb,'B':mp.exp(logb)}

def choose_z(config):
    with mp.workdps(60):
        _,ss,ll,ee,vv,uu=config;s,lam,eta,dv,du=map(mp.mpf,(ss,ll,ee,vv,uu))
        needed=[]
        for _,r,t,th,ch in EXPS:
            params=tail_parameters(s,lam,eta,dv,du,*map(mp.mpf,(r,t,th,ch)))
            needed.append((mp.log(2)+params['log_B']-mp.log(params['delta'])+16*mp.log(10))/params['delta'])
        return int(mp.ceil(max(needed+[abs(dv)+eta,abs(du)+eta,lam])))

def evaluate(config,dps,zbound):
    with mp.workdps(dps):
        stage,ss,ll,ee,vv,uu=config;s,lam,eta,dv,du=map(mp.mpf,(ss,ll,ee,vv,uu));zz=mp.mpf(zbound)
        cuts={-zz,zz,mp.mpf(0),dv,du,-lam/2,lam/2,dv-eta/2,dv+eta/2,du-eta/2,du+eta/2,dv-mp.mpf('.5'),dv+mp.mpf('.5'),du-mp.mpf('.5'),du+mp.mpf('.5')}
        cuts=sorted(x for x in cuts if -zz<=x<=zz)
        cache={}
        def kernels(x):
            if x not in cache:
                p=fs(x/lam,s)/lam;jv=phi(x-dv);ju=phi(x-du)
                kv=fs((x-dv)/eta,s)/eta;ku=fs((x-du)/eta,s)/eta
                assert min(p,jv,ju,kv,ku)>0
                cache[x]=(mp.log(p),mp.log(jv),mp.log(ju),mp.log(kv),mp.log(ku))
            return cache[x]
        moments=[]
        for label,rr,tt,thh,chh in EXPS:
            r,t,th,ch=map(mp.mpf,(rr,tt,thh,chh));A=1+r+t
            def integrand(x):
                p,jv,ju,kv,ku=kernels(x)
                return mp.exp(A*p-r*jv-t*ju-th*kv-ch*ku)
            value=mp.mpf(0);error=mp.mpf(0)
            for left,right in zip(cuts,cuts[1:]):
                part,err=mp.quad(integrand,[left,right],error=True)
                value+=part;error+=err
            params=tail_parameters(s,lam,eta,dv,du,r,t,th,ch)
            tail=2*params['B']/params['delta']*mp.exp(-params['delta']*zz)
            assert tail<=mp.mpf('1e-16')*(1+mp.mpf('1e-15'))
            moments.append({'label':label,'r':rr,'tau':tt,'theta':thh,'chi':chh,
                'finite_integral':mp.nstr(value,dps),'quad_internal_error_indicator_nonrigorous':mp.nstr(error,dps),
                'analytic_tail_upper':mp.nstr(tail,dps),'tail_parameters':{k:mp.nstr(v,dps) for k,v in params.items()}})
        lookup={m['label']:mp.mpf(m['finite_integral']) for m in moments}
        product=lookup['HH_single_v']*lookup['HH_single_u'];joint=lookup['HH_joint']
        return {'dps':dps,'Z':zbound,'cuts':[mp.nstr(x,dps) for x in cuts],'kernel_cache_size':len(cache),'moments':moments,
                'HH_single_product':mp.nstr(product,dps),'HH_joint_minus_single_product':mp.nstr(joint-product,dps),
                'HH_joint_over_single_product':mp.nstr(joint/product,dps)}

def controls():
    rows=[]
    for dps in (25,40):
        with mp.workdps(dps):
            for rr in ('0','.25','.5','.75','2','4'):
                r=mp.mpf(rr);h=mp.mpf('.5')
                if r<=h:other=mp.quad(lambda t:t*(2-mp.exp(-(h-r)/t)-mp.exp(-(h+r)/t)),[0,1])
                else:other=mp.quad(lambda t:t*(mp.exp(-(r-h)/t)-mp.exp(-(r+h)/t)),[0,1])
                rows.append({'r':rr,'dps':dps,'phi_E3':mp.nstr(phi(r),dps),'direct_scale_integral':mp.nstr(other,dps),'absolute_difference':mp.nstr(abs(phi(r)-other),dps)})
    return rows

def run():
    rows=[]
    for idx,config in enumerate(CASES):
        z=choose_z(config);values=[evaluate(config,dps,z) for dps in (25,40)]
        differences=[]
        with mp.workdps(60):
            for lo,hi in zip(values[0]['moments'],values[1]['moments']):
                a=mp.mpf(lo['finite_integral']);b=mp.mpf(hi['finite_integral'])
                differences.append({'label':lo['label'],'absolute_difference':mp.nstr(abs(a-b),40),'relative_difference':mp.nstr(abs(a-b)/abs(b),40)})
        rows.append({'case':idx+1,'stage':config[0],'s':config[1],'lambda':config[2],'eta':config[3],'d_v':config[4],'d_u':config[5],'precisions':values,'precision_differences':differences})
        print('completed case '+str(idx+1),flush=True)
    return {'schema':'R215_same_receiver_physical_moments_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
            'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
            'analytic_source':{'name':'R214 coupled_receiver_moments.md CM4/CM6-10','sha256':'02763c7ce7c0a11fa02bebeff575dbb8b3534207b4f9cce5889a05934c619fa4'},
            'counts':{'coordinate_configs':len(rows),'precision_runs':2*len(rows),'moment_integrals':8*len(rows),'phi_control_points':12},
            'kernel_controls':controls(),'cases':rows,
            'scope':['Physical one-dimensional same-z p_lambda^(1+r+tau) Jv^-r Ju^-tau Kv^-theta Ku^-chi kernels, b1,y0.',
            'Finite quadrature uses all hard faces and phi centers/seams; CM10 analytic tail is separate from noncertified quadrature rounding.',
            '25/40dps agreement and mpmath internal error indicators are noninterval evidence, not rigorous integral enclosures.',
            'HH joint and single-leg product are both computed only as a dependence diagnostic; no factorization is assumed.',
            'No source measure, full posterior, original mixed event, selector, high/FIRST/history or FULL input is constructed. No dimension-order fit.']}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'physical_joint_checks.json');args=ap.parse_args()
    start=time.monotonic();result=run();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'counts':result['counts'],'runtime_seconds_console_only':round(time.monotonic()-start,3)},sort_keys=True))
