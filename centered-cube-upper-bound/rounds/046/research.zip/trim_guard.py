#!/usr/bin/env python3
"""Round 46: exact 1D trimming, threshold allocation, and line-grid packing.
Standard library only. Integer-center packing is a restricted construction;
weight-grid minima are discrete candidates, not continuous optimization proofs.
"""
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from pathlib import Path
import json
import time


def fs(x):return str(x)


@lru_cache(None)
def root_interval(q,bits=48):
    assert 0<=q<1
    if q==0:return F(0),F(0)
    lo,hi=F(0),F(1)
    for _ in range(bits):
        mid=(lo+hi)/2
        if mid*mid==q:return mid,mid
        if mid*mid<q:lo=mid
        else:hi=mid
    assert lo*lo<=q<=hi*hi
    return lo,hi


@lru_cache(None)
def source_family(xs,ws):
    kept=[(F(x),F(w)) for x,w in zip(xs,ws) if w]
    assert all(w>0 for x,w in kept)
    fam=[]
    for mask in range(1,1<<len(kept)):
        active=[kept[j] for j in range(len(kept)) if mask>>j&1]
        fam.append((sum((w for x,w in active),F(0)),min(x for x,w in active),max(x for x,w in active)))
    return tuple(fam)


def interval_union(intervals):
    total=F(0);right=None
    for l,r in sorted((l,r) for l,r in intervals if l<r):
        if right is None or l>right:
            total+=r-l;right=r
        elif r>right:
            total+=r-right;right=r
    return total


def weak_at(fam,lam):
    return lam*interval_union((hi-m/(2*lam),lo+m/(2*lam)) for m,lo,hi in fam)


@lru_cache(None)
def exact_W(xs,ws):
    """All affine endpoint crossings in t=1/lambda; on each cell ratio=A+B/t.
    Nonnegative sources are used throughout. Zero weights are omitted.
    """
    fam=source_family(xs,ws)
    if not fam:return F(0)
    lines=set((hi,-m/2) for m,lo,hi in fam)|set((lo,m/2) for m,lo,hi in fam)
    times=set()
    for (a,b),(c,d) in combinations(lines,2):
        if b!=d:
            t=(c-a)/(b-d)
            if t>0:times.add(t)
    best=sum(ws,F(0))
    for t in times:best=max(best,weak_at(fam,1/t))
    return best


def triangle_guard(mu,a,b):
    # Exact square-root comparison without approximating a square root.
    gap=mu-a-b
    assert gap<=0 or gap*gap<=4*a*b


def schedule(N,H,D):
    assert N>=1 and H>=0 and D>2*H
    centers=list(range(-H,N+H))
    weights=[max(0,min(N-1,c+H)-max(0,c-H)+1) for c in centers]
    dp=[0]*(len(centers)+1);choose=[False]*len(centers)
    for i,c in enumerate(centers):
        predecessor=max(0,i-D+1)  # number of earlier centers <= c-D
        score=weights[i]+dp[predecessor]
        if score>dp[i]:dp[i+1]=score;choose[i]=True
        else:dp[i+1]=dp[i]
    selected=[];i=len(centers)-1
    while i>=0:
        predecessor=max(0,i-D+1)
        if choose[i] and dp[i+1]==weights[i]+dp[predecessor]:
            selected.append(centers[i]);i=predecessor-1
        else:i-=1
    selected.reverse()
    assert all(b-a>=D for a,b in zip(selected,selected[1:]))
    covered={j for c in selected for j in range(max(0,c-H),min(N-1,c+H)+1)}
    assert len(covered)==dp[-1]
    canonical=list(range(H,N+H,D))
    ccovered={j for c in canonical for j in range(max(0,c-H),min(N-1,c+H)+1)}
    assert len(ccovered)<=len(covered)
    return len(covered),len(ccovered),len(selected)


def brute_schedule(N,H,D):
    # Independent exhaustive subset comparison, only for tiny integer ranges.
    cs=list(range(-H,N+H));best=0
    for mask in range(1<<len(cs)):
        chosen=[cs[i] for i in range(len(cs)) if mask>>i&1]
        if any(b-a<D for a,b in zip(chosen,chosen[1:])):continue
        coverage={j for c in chosen for j in range(max(0,c-H),min(N-1,c+H)+1)}
        best=max(best,len(coverage))
    return best


def greedy_alpha(ws,rho,order):
    a=list(ws);left=rho
    for i in order:
        drop=min(a[i],left);a[i]-=drop;left-=drop
        if not left:break
    assert not left
    return tuple(a)


def main():
    start=time.monotonic();rows=[]
    # Raw all-threshold optimizer checks the supplied two-point formula;
    # no formula is used by the optimizer itself.
    for a,b in product((F(0),F(1,8),F(1,4),F(1,2),F(3,4)),repeat=2):
        if not a+b:continue
        for distance in (F(1,3),F(1),F(7)):
            actual=exact_W((F(0),distance),(a,b));formula=a+b+min(a,b)/2
            assert actual==formula
            rows.append(dict(stage='two_point_raw_formula',weights=[fs(a),fs(b)],distance=fs(distance),W=fs(actual),status='PASS'))
    for denominator in (8,16,32):
        for drop in range(denominator+1):
            rho=F(drop,denominator);mass=1-rho
            analytic=mass+max(F(0),F(1,2)-rho)/2
            boundary_alpha=(max(F(0),F(1,2)-rho),min(F(1,2),mass))
            assert sum(boundary_alpha)==mass
            achieved=exact_W((F(0),F(1)),boundary_alpha)
            assert achieved==analytic
            candidates=[]
            # Exact mass; supported alpha<=mu. The analytic min has a separate
            # two-point proof, while this loop only guards a finite grid.
            for i in range(denominator//2+1):
                a=F(i,denominator);b=mass-a
                if 0<=b<=F(1,2):
                    v=exact_W((F(0),F(1)),(a,b));assert v>=analytic;candidates.append(v)
            assert min(candidates)==analytic
            rows.append(dict(stage='two_point_exact_trim',rho=fs(rho),weight_denominator=denominator,
                             analytic_continuous_min=fs(analytic),grid_min=fs(min(candidates)),
                             grid_candidates=len(candidates),boundary_achiever=[fs(x) for x in boundary_alpha],status='PASS'))
    cases=[('equal2',[0,1],[8,8],16,4),('unequal2',[0,1],[4,12],16,4),
           ('equal3',[0,1,2],[4,4,4],12,4),('nested4',[0,1,2,8],[2,2,4,8],16,4),
           ('paired4',[0,1,8,9],[2,6,2,6],16,4)]
    for name,xs,units,D,drop in cases:
        xs=tuple(map(F,xs));ws=tuple(F(u,D) for u in units);rho=F(drop,D)
        base=exact_W(xs,ws);values=[]
        for dv in product(*(range(min(u,drop)+1) for u in units)):
            if sum(dv)!=drop:continue
            alpha=tuple(F(u-v,D) for u,v in zip(units,dv));beta=tuple(F(v,D) for v in dv)
            va,vb=exact_W(xs,alpha),exact_W(xs,beta)
            assert va<=base and va>=1-rho
            triangle_guard(base,va,vb)
            values.append((va,alpha))
            rows.append(dict(stage='mixed_weight_grid_triangle',source=name,alpha=[fs(a) for a in alpha],
                             W_mu=fs(base),W_alpha=fs(va),W_beta=fs(vb),rho=fs(rho),status='PASS'))
        light=greedy_alpha(ws,rho,sorted(range(len(ws)),key=lambda i:ws[i]))
        proportional=tuple((1-rho)*w for w in ws)
        assert exact_W(xs,proportional)==(1-rho)*base
        rows.append(dict(stage='strategy_comparison',source=name,W_mu=fs(base),rho=fs(rho),
                         proportional_W=fs((1-rho)*base),light_first_W=fs(exact_W(xs,light)),
                         finite_grid_min=fs(min(values)[0]),finite_grid_max=fs(max(values)[0]),
                         finite_grid_candidates=len(values),
                         note='Finite grid extremum is not a continuous-submeasure optimum',status='PASS'))
    # A local atom-mass threshold cannot enforce a global deletion budget.
    N=8;rho=F(1,4);ws=(F(1,N),)*N
    assert all(w<=rho for w in ws)
    rows.append(dict(stage='small_atom_cutoff_counterexample',source='equal grid 0,...,7',atom_mass='1/8',
                     nominal_budget=fs(rho),mass_discarded_by_atom_threshold='1',
                     actual_W=fs(exact_W(tuple(map(F,range(N))),ws)),status='PASS'))
    # Three stages enlarge N and geometry parameters. Ambient dimension is
    # an embedding label; the exact DP is one-dimensional and independent of it.
    for N,H,D in ((4,0,2),(5,1,3),(6,1,4),(5,2,5)):
        got,can,k=schedule(N,H,D);brute=brute_schedule(N,H,D)
        assert got==brute
        rows.append(dict(stage='packing_dp_exhaustive',N=N,H=H,D=D,restricted_integer_center_max=got,
                         exhaustive_max=brute,status='PASS'))
    for stage,Ns,Hs in (('packing_initial',(16,32),(0,1)),('packing_pressure',(64,128),(1,2)),
                        ('packing_expanded',(256,1024,4096),(2,4))):
        for N,H in product(Ns,Hs):
            for multiplier in (1,2,8):
                D=multiplier*(2*H+1)
                got,canonical,k=schedule(N,H,D)
                rawupper=F(2*H+1,N)*(1+F(N-1+2*H,D));upper=min(F(1),rawupper)
                assert F(canonical,N)<=F(got,N)<=upper
                necessary_rho=1-upper;rl,ru=root_interval(necessary_rho)
                assert ru<1
                costL=1/(1-rl)**2;costU=1/(1-ru)**2
                for n in (1,8,64):
                    rows.append(dict(stage=stage,N=N,h=H,separation_d=D,ambient_dimension=n,
                                     restricted_integer_center_covered=got,restricted_retention_lower=fs(F(got,N)),
                                     canonical_retention=fs(F(canonical,N)),selected_integer_centers=k,
                                     universal_real_center_packing_upper=fs(upper),unclipped_upper=fs(rawupper),
                                     necessary_deletion_lower=fs(necessary_rho),sqrt_bits=48,
                                     raw_budget_absorption_at_deletion_lower_enclosure=[fs(costL),fs(costU)],
                                     normalized_budget_absorption_at_deletion_lower_enclosure=[fs(upper*costL),fs(upper*costU)],
                                     unavoidable_raw_budget_factor_lower=fs(costL),
                                     unavoidable_normalized_budget_factor_lower=fs(upper*costL),
                                     note='DP is a restricted attainable lower bound; universal packing upper applies to arbitrary real centers',status='PASS'))
    # General-dimensional support construction. N can be enormous: this is
    # exact symbolic packing/A arithmetic, not an atomic-volume enumeration.
    for n,H in product((1,2,4,8,16,64,256),(1,4,16)):
        K=2**n;D=8*n*H;N=K*D
        mass=F(2*H+1,D)
        assert D>2*H and 2*H+D-1<=N
        assert (K-1)*D+2*H<=N-1
        assert K*F(2*H+1,N)==mass
        assert F(1,K)==F(1,2)**n
        A=1+F(4*H,D-2*H)
        assert A==1+F(2,4*n-1)
        assert A<=1+F(1,n) and A**n<=(1+F(1,n))**n<3
        assert F(1,4*n)<=mass<=F(3,8*n)
        # Necessary bound for arbitrary admissible real-center packing with
        # A^n<=3. Bernoulli and pmin^(1/n)<=1 imply d>=(n+2)h;
        # the stated finite-range hypothesis makes the line count <=2N/d.
        generic_raw=F(2*H+1,N)*(1+F(N-1+2*H,D))
        middle=F(2*(2*H+1),D)
        assert generic_raw<=middle<=F(8*H,D)<=F(8,n+2)
        universal_mass_upper=min(F(1),F(8,n+2))
        q=F(2*H,D)
        assert D<=N-1+2*H and D*(1-q)<N
        unconditional_q_upper=4*q/(1-q)
        assert generic_raw<=unconditional_q_upper<=F(8,n)
        unconditional_mass_upper=min(F(1),F(8,n))
        rho=1-mass;rl,ru=root_interval(rho)
        assert rho<=rl<=ru<1
        costL=1/(1-rl)**2;costU=1/(1-ru)**2
        assert costL>=1/mass**2 and mass*costL>=1/mass
        rows.append(dict(stage='symbolic_dimension_packing',ambient_dimension=n,H=H,D=D,
                         K_exact=str(K),N_exact=str(N),cluster_weight=fs(F(1,K)),
                         cluster_weight_nthroot='1/2',A=fs(A),A_to_n=fs(A**n),budget_B='3',
                         retained_mass=fs(mass),construction_mass_bounds=[fs(F(1,4*n)),fs(F(3,8*n))],
                         boundary_hypothesis_retention_upper=fs(universal_mass_upper),
                         unconditional_mass_upper=fs(unconditional_mass_upper),
                         unconditional_q_retention_upper=fs(min(F(1),unconditional_q_upper)),
                         deletion_of_construction=fs(rho),sqrt_bits=48,
                         construction_raw_budget_factor_enclosure=[fs(costL),fs(costU)],
                         construction_normalized_budget_factor_enclosure=[fs(mass*costL),fs(mass*costU)],
                         analytic_raw_budget_factor_lower=fs(1/mass**2),
                         analytic_normalized_budget_factor_lower=fs(1/mass),
                         arithmetic_raw_lower_guard=fs(costL),
                         arithmetic_normalized_lower_guard=fs(mass*costL),
                         note='Symbolic support packing/A-budget guard; N atoms and maximal level-set volumes are not enumerated',status='PASS'))
    counts={}
    for row in rows:counts[row['stage']]=counts.get(row['stage'],0)+1
    result=dict(round=46,status='PASS',total_cases=len(rows),counts=counts,
                arithmetic='Fraction exact 1D endpoint optimizer, exact integer DP, rational sqrt enclosures',
                scope=['Positive atomic sources; W is not divided by source mass.',
                       'Continuous two-point trim formula is separately analytic; other weight grids give candidates only.',
                       'Integer-center DP does not assert optimality among arbitrary real centers.',
                       'Ambient dimension is only the line-grid embedding; no numerical high-dimensional quadrature.',
                       'Packing certifies necessary deletion and an unavoidable lower bound on absorption cost; it does not prove a new C_n upper bound.',
                       'For sqrt enclosure rl<=sqrt(rho)<=ru, cost at rho is between (1-rl)^(-2) and (1-ru)^(-2). Actual larger deletion gives only an unavoidable cost lower bound.',
                       'The 2^n-cluster construction uses symbolic support geometry, not enumeration or maximal-volume calculation.',
                       'Raw fixed-B absorption factor is (1-sqrt(rho))^-2; normalized good-budget b uses m/(1-sqrt(rho))^2, whose obstruction is order n rather than n squared.',
                       'Unconditional packing bound 8/n uses h>=1/2 and at least two nonempty separated clusters; 8/(n+2) additionally uses the finite-range boundary hypothesis.'],
                cases=rows)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(dict(status='PASS',total_cases=len(rows),counts=counts,runtime_seconds=time.monotonic()-start)))


if __name__=='__main__':main()
