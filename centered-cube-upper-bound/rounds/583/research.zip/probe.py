"""Frozen n2/n3 complete all-actual-halfcore cover LP and exact certificates."""
from fractions import Fraction as F
from math import gcd,prod
from functools import lru_cache,cmp_to_key
from pathlib import Path
import argparse,json,hashlib,time,sys,platform,resource,signal,shlex
import flint
from flint import arb,ctx
ctx.prec=512
ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,default=Path(__file__).resolve().parent/'probe.json');ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));ap.add_argument('--case',choices=['n2','n3','n3-confirm','all'],default='n2');ap.add_argument('--preflight-only',action='store_true');ap.add_argument('--masked-baseline',type=Path,default=Path(__file__).resolve().parent/'masked_probe.json');args=ap.parse_args();start=time.perf_counter();LIMIT=512*1024**2
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('180s guard; full candidate family is not truncated')))
def guard():
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 if rss>LIMIT:raise MemoryError('512MB guard; full candidate family is not truncated')
 return rss
BASE_SHA='0b59417a638ab184a0e343f53a22b262d13df455f1dccb09e7cef90be7c03681';raw=args.baseline.read_bytes();assert hashlib.sha256(raw).hexdigest()==BASE_SHA
def run(case_name,case_index):
 case_start=time.perf_counter();signal.alarm(180)
 old=baseline['cases'][case_index];n=old['input']['n'];assert n in (2,3)
 z=[tuple(map(F,p)) for p in old['input']['sources_rational']];weights=list(map(F,old['input']['masses_exact']));N=len(z);ALL=(1<<N)-1;W=sum(weights);U=F(2**(n+1));assert N in (8,10) and W<2*U/3
 ZERO=();ONE=((1,F(1)),);RADFACT={1:()}
 def pack(d):return tuple(sorted((r,c) for r,c in d.items() if c))
 def rat(q):q=F(q);return ((1,q),) if q else ZERO
 @lru_cache(maxsize=2048)
 def add(a,b):
  d=dict(a)
  for r,c in b:d[r]=d.get(r,F(0))+c
  return pack(d)
 def scale(a,c):return tuple((r,q*F(c)) for r,q in a if q*F(c))
 def sub(a,b):return add(a,scale(b,-1))
 @lru_cache(maxsize=20000)
 def basisproduct(r,s):
  d=dict(RADFACT[r])
  for p,e in RADFACT[s]:d[p]=d.get(p,0)+e
  fac=1;rad=1;es=[]
  for p,e in sorted(d.items()):
   q,rem=divmod(e,n);fac*=p**q
   if rem:rad*=p**rem;es.append((p,rem))
  RADFACT[rad]=tuple(es);return rad,fac
 @lru_cache(maxsize=512)
 def mul(a,b):
  d={}
  for r,c in a:
   for ss,e in b:
    t,g=basisproduct(r,ss);d[t]=d.get(t,F(0))+c*e*g
  return pack(d)
 @lru_cache(None)
 def root(q):
  q=F(q);r=q.numerator*q.denominator**(n-1);c=F(1,q.denominator);p=2;rad=1;es=[]
  while p*p<=r:
   e=0
   while r%p==0:e+=1;r//=p
   c*=p**(e//n)
   if e%n:rad*=p**(e%n);es.append((p,e%n))
   p+=1 if p==2 else 2
  if r>1:rad*=r;es.append((r,1))
  RADFACT[rad]=tuple(es);return ((rad,c),)
 def af(q):q=F(q);return arb(q.numerator)/q.denominator
 @lru_cache(None)
 def arroot(r):return arb(r).sqrt() if n==2 else (arb(r).log()/3).exp()
 def av(a):return sum((af(c)*arroot(r) for r,c in a),arb(0))
 @lru_cache(maxsize=10000)
 def sign(a):
  if not a:return 0
  v=av(a)
  if v>0:return 1
  if v<0:return -1
  raise ArithmeticError('Unresolved radical comparison')
 def out(a):return {'exact_squarefree_radical_terms' if n==2 else 'exact_cubefree_radical_terms':[[r,str(c)] for r,c in a],'Arb512':av(a).str(55)}
 def mass(S):return sum(weights[i] for i in range(N) if S>>i&1)
 def bbox(S):
  ids=[i for i in range(N) if S>>i&1]
  return tuple((min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(n))
 def box(bb,m,outer=False):
  h=scale(root(m),F(1,2));B=tuple((sub(rat(lo if outer else hi),h),add(rat(hi if outer else lo),h)) for lo,hi in bb)
  return B if all(sign(sub(b,a))>0 for a,b in B) else None
 def boxvol(B):
  if not B:return ZERO
  v=ONE
  for a,b in B:v=mul(v,sub(b,a))
  return v
 subs={}
 for S in range(1,ALL+1):
  m=mass(S);bb=bbox(S);C=box(bb,m);beta=scale(boxvol(C),1/m);high=sign(sub(scale(mul(beta,beta),n),ONE))>=0
  subs[S]={'mass':m,'bbox':bb,'C':C,'beta':beta,'high':high}
 used=0;hs=[]
 for S in sorted(subs,key=lambda S:(-subs[S]['mass'],S)):
  if subs[S]['high'] and not used&S:hs.append(S);used|=S
 assert used==ALL and hs==old['original_high_greedy']['selected_partition_masks']
 HB=[box(subs[S]['bbox'],2*subs[S]['mass'],True) for S in hs]
 # Initial exact arrangement is used ONLY for complete parent eligibility, not carrier incidence.
 def parse_endpoint(e):
  for r,c in e['exact_terms']:root(F(int(r)))
  return tuple((int(r),F(c)) for r,c in e['exact_terms'])
 oldends=[set(parse_endpoint(e) for e in axis) for axis in old['partition']['axis_endpoints']]
 def layout(endsets):
  ends=[sorted(es,key=cmp_to_key(lambda a,b:sign(sub(a,b)))) for es in endsets];idx=[{e:i for i,e in enumerate(es)} for es in ends];dims=[len(es)-1 for es in ends];nr=prod(dims[:-1])
  def ranges(B):return tuple((idx[j][a],idx[j][b]) for j,(a,b) in enumerate(B)) if B else None
  def zmask(R):return ((1<<(R[-1][1]-R[-1][0]))-1)<<R[-1][0]
  def rowiter(R):
   if n==2:yield from range(*R[0])
   else:
    for x in range(*R[0]):
     for y in range(*R[1]):yield x*dims[1]+y
  def insert(rows,R):
   if R:
    bits=zmask(R)
    for row in rowiter(R):rows[row]|=bits
  E=[0]*nr;H=[0]*nr
  for q in subs.values():
   if q['mass']>=1:insert(E,ranges(q['C']))
  for B in HB:insert(H,ranges(B))
  R=[e&~h for e,h in zip(E,H)]
  return ends,ranges,zmask,R,H,rowiter,dims
 ends0,ranges0,zm0,R0,H0,rowiter0,dims0=layout(oldends);eligible=[]
 for S,q in subs.items():
  R=ranges0(q['C'])
  if q['mass']>=1 and R and any(zm0(R)&R0[x] for x in rowiter0(R)):eligible.append(S)
 all_pairs=[];columns=[];dedup={}
 for S in eligible:
  M=subs[S]['mass'];K=S
  while K:
   mk=mass(K)
   if mk>=M/2:
    assert sign(sub(scale(mul(subs[K]['beta'],subs[K]['beta']),n),ONE))<0
    B=box(subs[K]['bbox'],M);assert B
    key=(B,M)
    if key not in dedup:dedup[key]=len(columns);columns.append({'parent':S,'core':K,'M':M,'B':B,'v':boxvol(B),'pairs':[]})
    j=dedup[key];columns[j]['pairs'].append((S,K));all_pairs.append((S,K,j))
   K=(K-1)&S
 endsets=[set(es) for es in oldends]
 for c in columns:
  for j,pair in enumerate(c['B']):endsets[j].update(pair)
 ends,ranges,zmask,RR,HR,rowiter,dims=layout(endsets);nr=prod(dims[:-1]);assert prod(dims)<=10000000
 rows=[];rowids=[{} for _ in range(nr)];areas=[];J=ZERO
 for x,bits in enumerate(RR):
  while bits:
   y=(bits&-bits).bit_length()-1;bits^=1<<y;i=len(rows);cellindex=[x,y] if n==2 else [x//dims[1],x%dims[1],y];rows.append(cellindex);rowids[x][y]=i
   a=ONE
   for axis,k in enumerate(cellindex):a=mul(a,sub(ends[axis][k+1],ends[axis][k]))
   areas.append(a);J=add(J,a)
 assert sign(J)>0 and (av(J)-arb(old['complete_Rlo_volume_Arb512'])).contains(0)
 nnz=0;rowcover=[0]*len(rows)
 for j,c in enumerate(columns):
  R=ranges(c['B']);ids=[]
  for x in rowiter(R):
   for y,i in rowids[x].items():
    if R[-1][0]<=y<R[-1][1]:ids.append(i);rowcover[i]+=1
  assert ids;c['rows']=sorted(ids);nnz+=len(ids)
  assert af(c['M'])*(1/arb(n).sqrt()+arb(2).log()/n)-av(c['v'])>0
 assert all(rowcover)
 rawpatterns=[0]*len(rows)
 for j,c in enumerate(columns):
  bit=1<<j
  for i in c['rows']:rawpatterns[i]|=bit
 pattern_index={};pattern_representatives=[];raw_to_pattern=[]
 for i,mask in enumerate(rawpatterns):
  assert mask
  if mask not in pattern_index:pattern_index[mask]=len(pattern_index);pattern_representatives.append(i)
  raw_to_pattern.append(pattern_index[mask])
 for c in columns:c['solver_rows']=sorted(set(raw_to_pattern[i] for i in c['rows']))
 compressed_nnz=sum(len(c['solver_rows']) for c in columns)
 preflight={'eligible_parent_count':len(eligible),'all_legal_parent_core_pair_count':len(all_pairs),'deduplicated_box_and_parent_mass_columns':len(columns),'axis_endpoint_counts':[len(es) for es in ends],'new_axis_endpoint_counts':[len(es-oldes) for es,oldes in zip(endsets,oldends)],'complete_arrangement_cell_count':prod(dims),'stored_row_count':nr,'positive_Rlo_cell_rows':len(rows),'sparse_nonzeros':nnz,'exact_distinct_incidence_pattern_rows':len(pattern_index),'compressed_solver_nonzeros':compressed_nnz,'full_Rlo_volume':out(J),'actual_original_H2_partition_masks':hs,'all_halfcore_low_beta_and_volume_guards':True,'rss_before_solver_bytes':guard()}
 print(json.dumps({'stage':'complete_all_halfcore_preflight','case':case_name,**preflight}),flush=True)
 result={'status':'PREFLIGHT_COMPLETE','locked_baseline_sha256':BASE_SHA,'case':case_name,'input':old['input'],'preflight':preflight}
 if args.preflight_only:
  result['runtime_seconds']=time.perf_counter()-case_start;return result
 # LP/certificate section appended below.
 import numpy as np
 import scipy
 from scipy.sparse import csc_matrix
 from scipy.optimize import linprog,OptimizeWarning
 import warnings
 # Outward dyadic bounds are obtained from exact Arb endpoint rationals, never rounded decimal strings.
 DEN=2**100
 vLo=[];vHi=[]
 for c in columns:
  a=av(c['v']);lo=F(str(a.lower().fmpq()));hi=F(str(a.upper().fmpq()))
  ll=(lo.numerator*DEN//lo.denominator);hh=-((-hi.numerator*DEN)//hi.denominator)
  low=F(ll,DEN);upper=F(hh,DEN);assert low>0 and af(low)<=a.lower() and af(upper)>=a.upper()
  vLo.append(low);vHi.append(upper)
 indptr=[0];ind=[]
 for c in columns:ind.extend(c['solver_rows']);indptr.append(len(ind))
 A=csc_matrix((np.ones(len(ind)),np.array(ind,dtype=np.int32),np.array(indptr,dtype=np.int32)),shape=(len(pattern_index),len(columns)))
 guard()
 def row_sums(alpha):
  sums=[F(0)]*len(rows)
  for j,x in enumerate(alpha):
   if x:
    for i in columns[j]['rows']:sums[i]+=x
  return sums
 def exact_plan_costs(alpha):
  mm=F(0);vv=ZERO;upper=F(0)
  for j,x in enumerate(alpha):
   if x:mm+=x*columns[j]['M'];vv=add(vv,scale(columns[j]['v'],x));upper+=x*vHi[j]
  return mm,vv,upper
 def solve(which):
  costs=[c['M'] for c in columns] if which=='mass' else [float(av(c['v'])) for c in columns]
  float_cost=np.array([float(c) for c in costs]);options={'presolve':True,'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9,'threads':1}
  with warnings.catch_warnings():
   warnings.filterwarnings('ignore',category=OptimizeWarning,message='Unrecognized options detected')
   sol=linprog(float_cost,A_ub=-A,b_ub=-np.ones(len(pattern_index)),bounds=(0,None),method='highs-ds',options=options)
  assert sol.success and sol.status==0,(sol.status,sol.message)
  D=10**12;alpha=[F(str(max(0,float(x)))).limit_denominator(D) for x in sol.x];seed_alpha=alpha[:]
  sums=row_sums(alpha);patches=[]
  for i,v in enumerate(sums):
   if v==0:
    j=next(j for j,c in enumerate(columns) if i in c['rows']);inc=1-v;alpha[j]+=inc;patches.append({'row':i,'column':j,'added':str(inc)})
    for r in columns[j]['rows']:sums[r]+=inc
  assert min(sums)>0
  up=max(F(1),1/min(sums));alpha=[x*up for x in alpha];sums=row_sums(alpha);assert all(v>=1 for v in sums)
  pattern_y=[F(str(max(0,-float(v)))).limit_denominator(D) for v in sol.ineqlin.marginals]
  y=[F(0)]*len(rows)
  for g,yy in enumerate(pattern_y):y[pattern_representatives[g]]=yy
  lowcost=[c['M'] for c in columns] if which=='mass' else vLo
  lhs=[sum(y[i] for i in c['rows']) for c in columns];down=min([F(1)]+[cc/v for cc,v in zip(lowcost,lhs) if v]);assert 0<=down<=1
  y=[v*down for v in y];lhs=[sum(y[i] for i in c['rows']) for c in columns];slack=[cc-v for cc,v in zip(lowcost,lhs)];assert all(s>=0 for s in slack)
  pm,pv,vu=exact_plan_costs(alpha);pu=pm if which=='mass' else vu;dl=sum(y);gap=pu-dl;assert gap>=0
  dactual=scale(ONE,pm) if which=='mass' else pv
  assert sign(sub(dactual,rat(dl)))>=0
  return {'objective':which,'solver_float_candidate':{'status':int(sol.status),'message':sol.message,'float_objective':float(sol.fun),'iterations':int(sol.nit),'method':'highs-ds','threads':1,'note':'Candidate only; optimal status is not used as proof.'},'rational_rounding_denominator_limit':D,'primal_upward_global_scale_exact':str(up),'primal_missing_row_patches':patches,'dual_downward_global_scale_exact':str(down),'primal_support':[{'column':j,'alpha_exact':str(x),'parent':columns[j]['parent'],'core':columns[j]['core']} for j,x in enumerate(alpha) if x],'dual_nonzero_cell_masses':[{'cell_row':i,'y_exact':str(v),'density':'y_exact / this cell exact area, constant on the entire cell'} for i,v in enumerate(y) if v],'all_primal_row_coverages_exact':[str(v) for v in sums],'all_dual_column_slacks_exact':[str(v) for v in slack],'primal_objective_upper_rational_exact':str(pu),'dual_objective_lower_rational_exact':str(dl),'certified_objective_gap_rational_exact':str(gap),'certified_objective_gap_Arb512':av(rat(gap)).str(55),'zero_gap_exact':not gap,'same_plan_selected_mass_exact':str(pm),'same_plan_full_carrier_volume_exact':out(pv),'same_plan_full_carrier_volume_upper_rational':str(vu),'all_full_cell_cover_constraints_Fraction_verified':True,'all_all_halfcore_column_dual_constraints_Fraction_verified':True},alpha
 pmass,amass=solve('mass');guard();pvolume,avolume=solve('volume');guard()
 # Compare both ledgers of each one common cover with frozen complete-cover baselines.
 references={}
 for name,s in [('extrema',old['extrema']),('fulltrim',old['quantile'])]:
  vv=ZERO;mm=F(0)
  for e in s['selected']:
   M=F(e['mass']);assert M==subs[e['mask']]['mass'];vv=add(vv,boxvol(box(subs[e['core_mask']]['bbox'],M)));mm+=M
  references[name]=(mm,vv)
 masked_sha=None
 if args.masked_baseline.exists():
  mraw=args.masked_baseline.read_bytes();masked_sha=hashlib.sha256(mraw).hexdigest();assert masked_sha=='832788c3eadb93ee93e7590c7e30c23b896655a3d7285f71c1e176b18174bada'
  masked=json.loads(mraw)['cases'][case_index];vv=ZERO;mm=F(0)
  for e in masked['selected']:
   M=F(e['mass']);assert M==subs[e['mask']]['mass'];vv=add(vv,boxvol(box(subs[e['core_mask']]['bbox'],M)));mm+=M
  references['masked']=(mm,vv)
 comparisons={}
 for sol,alpha in [(pmass,amass),(pvolume,avolume)]:
  mm,vv,_=exact_plan_costs(alpha);compare={}
  for name,(rm,rv) in references.items():
   dm=rm-mm;dv=sub(rv,vv)
   compare[name]={'reference_mass_exact':str(rm),'reference_volume_exact':out(rv),'mass_reference_minus_this_plan_exact':str(dm),'volume_reference_minus_this_plan_exact':out(dv),'this_single_plan_strictly_reduces_both_ledgers':dm>0 and sign(dv)>0,'this_single_plan_no_worse_both_and_one_strict':dm>=0 and sign(dv)>=0 and (dm>0 or sign(dv)>0)}
  comparisons[sol['objective']]=compare
 # Continuous dual interpretation and complete geometry certificates.
 cell_records=[]
 for i,cellindex in enumerate(rows):cell_records.append({'row':i,'axis_bin_indices':cellindex})
 column_records=[]
 for j,c in enumerate(columns):
  mask=sum(1<<i for i in c['rows'])
  column_records.append({'column':j,'representative_parent_mask':c['parent'],'representative_core_mask':c['core'],'parent_mass_M_exact':str(c['M']),'full_volume_exact':out(c['v']),'full_volume_lower_rational_exact':str(vLo[j]),'full_volume_upper_rational_exact':str(vHi[j]),'incidence_cell_row_bitmask_hex':hex(mask),'number_of_incident_cells':len(c['rows']),'all_legal_parent_core_representations':[[S,K] for S,K in c['pairs']]})
 result.update({'status':'PASS_COMPLETE_ALL_HALFCORE_TWO_OBJECTIVE_LP_CERTIFICATES','eligible_parent_masks':eligible,'all_parent_core_pair_to_column_mapping':[[S,K,j] for S,K,j in all_pairs],'exact_incidence_row_compression':{'raw_row_count':len(rows),'pattern_row_count':len(pattern_index),'raw_to_pattern':raw_to_pattern,'pattern_representative_positive_cell_rows':pattern_representatives,'pattern_column_bitmasks_hex':[hex(mask) for mask in pattern_index],'compressed_solver_nonzeros':compressed_nnz,'all_raw_cell_primal_constraints_expanded_verified':True,'dual_pattern_mass_embedded_in_representative_actual_cell':True,'density_has_no_assumed_upper_bound':True},'axis_endpoints_exact':[[out(e) for e in axis] for axis in ends],'cell_area_formula':'For row with bin indices k_j, area=product_j(axis_endpoint[j][k_j+1]-axis_endpoint[j][k_j]); all factors strictly positive.','cells':cell_records,'columns':column_records,'mass_optimization':pmass,'volume_optimization':pvolume,'same_common_plan_comparisons':comparisons,'masked_reference_sha256':masked_sha,'continuous_dual':'Each y_D is dual MASS on the entire positive-area cell D. The density y_D/area(D) is constant there, zero outside Rlo. Each actual carrier integral equals its full-cell incident sum; no cell area enters the finite cover constraint or its column dual constraint.','weak_duality_certificate':'For every nonnegative rational alpha,y, sum_D y_D <= sum_D y_D sum_e A_De alpha_e = sum_e alpha_e sum_D A_De y_D <= sum_e alpha_e c_e. All inequalities are exactly verified on the complete matrix; no solver strong-duality assertion required.','volume_objective_cost_bound_grid_denominator':str(DEN),'precision_bits':512,'arithmetic':'Fraction exact masses/coverage/duality/endpoint expressions; exact n-th-root-expression cell measures and plan volume; Arb512 nonzero signs and outward rational volume bounds. Float HiGHS only generates candidates.','frozen_case_only':True,'runtime_seconds':time.perf_counter()-case_start,'peak_rss_bytes':guard(),'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'numpy_version':np.__version__,'scipy_version':scipy.__version__,'processes':1,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
 return result
baseline=json.loads(raw)
case_index={'n2':0,'n3':1,'n3-confirm':2}
output={'status':'RUNNING','cases':{},'locked_baseline_sha256':BASE_SHA}
if args.output.exists():
 prior=json.loads(args.output.read_text())
 if 'cases' in prior:output['cases']=prior['cases']
 elif prior.get('status')=='PASS_COMPLETE_N2_ALL_HALFCORE_TWO_OBJECTIVE_LP_CERTIFICATES':output['cases']['n2']=prior
chosen=list(case_index) if args.case=='all' else [args.case]
for name in chosen:
 rr=run(name,case_index[name]);signal.alarm(0);output['cases'][name]=rr
 output['status']='PREFLIGHT_COMPLETE' if args.preflight_only else 'PASS_REQUESTED_COMPLETE_ALL_HALFCORE_CASES'
 output['runtime_seconds']=time.perf_counter()-start;output['peak_rss_bytes']=guard();output['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();output['command']='OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv)
 args.output.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
 if not args.preflight_only:
  print(json.dumps({'case':name,'status':rr['status'],'mass_objective_upper':rr['mass_optimization']['primal_objective_upper_rational_exact'],'mass_gap':rr['mass_optimization']['certified_objective_gap_Arb512'],'volume_objective':rr['volume_optimization']['same_plan_full_carrier_volume_exact']['Arb512'],'volume_gap':rr['volume_optimization']['certified_objective_gap_Arb512'],'volume_plan_mass':rr['volume_optimization']['same_plan_selected_mass_exact'],'runtime_seconds':rr['runtime_seconds'],'peak_rss_bytes':rr['peak_rss_bytes']},ensure_ascii=False),flush=True)
