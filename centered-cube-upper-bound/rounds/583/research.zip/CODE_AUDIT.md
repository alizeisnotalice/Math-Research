# R583 bounded independent code audit

**Verdict: PASS for the three frozen finite inputs and the stated objective
brackets. No concrete mathematical defect found.** This is a static review
of the complete final script, with inexpensive checks of the saved exact
combinatorial/Fraction fields. It is not an independent solver replay or a
general-dimensional theorem. The main agent owns the separate replay.

## Frozen files and claim being audited

Reviewed all 267 lines of `/tmp/ccu_r583_probe.py` and the final
`/tmp/ccu_r583_numeric_plan.md`. Also inspected the baseline endpoint
construction in `/tmp/ccu_r582_probe.py` and the frozen JSON structures.
No original script/result was edited or executed by this audit.

| Artifact | SHA256 |
|---|---|
| R583 code | `eaedc1d51990f19fe1dc6b9de0a556f682c7f9800018e78fdb7e9a27fb2acadd` |
| R583 result JSON | `a224dc4a6bfb0ee549d07457cf52a33c1309ec1c791c941b32783360a8e8366c` |
| R583 numeric plan | `11dc11908ed2eb8b86806becaff79cb1c9ab03d510398057c1745bc3ed038372` |
| R582 endpoint/input baseline JSON | `0b59417a638ab184a0e343f53a22b262d13df455f1dccb09e7cef90be7c03681` |
| R582 masked comparison JSON | `832788c3eadb93ee93e7590c7e30c23b896655a3d7285f71c1e176b18174bada` |

The accepted claim is a feasible common cover and a feasible continuous
cell-mass dual for **each frozen input separately**, bracketing each finite
complete LP objective. It includes all original eligible parents, every
actual halfcore of those parents, the original all-subset `H2`, and every
positive-volume cell of the complete original `Rlo`. It is not a claim
about all dimensions, all inputs, or the original arbitrary-L1 bound.

## Geometry completeness and endpoint dependency

1. Lines 19–20 read exact source coordinates and weights from the
   byte-hash-locked baseline. All three baseline inputs have `lambda=1`,
   `L=1`, `U=2^(n+1)`, positive weights, and `W<2U/3`. Consequently every
   subset has mass `<U` and there are **no top witnesses**. The code's
   `mass>=1` union in lines 109–113 is exactly the whole in-band union for
   these inputs. Omitting an explicit upper-band filter and explicit top
   subtraction is legitimate here only because of that exact bound.

2. Lines 82–90 enumerate all nonempty original masks, compute their
   actual capture boxes and high-beta tests, and reconstruct the
   descending-exact-mass, increasing-mask source-disjoint high greedy.
   The selected partition is checked against the frozen partition and
   covers all labels. `box(...,2*m,outer=True)` is precisely the original
   bbox-expanded `H2` carrier: each side is source range plus `(2m)^(1/n)`.
   It is not a newly chosen exception set.

3. Initial eligibility uses the old exact endpoint arrangement, but not
   old selector choices. The R582 baseline construction explicitly inserts
   endpoints of **every** actual `C_S`, its candidate trim carrier, and all
   original `H2` boxes before forming its grid. R583 reparses those exact
   expressions and reconstructs the full actual union and `H2`. Its
   `ranges` dictionary lookups fail rather than silently truncate a box
   if a necessary endpoint is missing. The eligibility test is positive
   full-cell intersection with that complete target, not a center sample.

4. For each eligible parent, lines 120–130 run through all its nonempty
   submasks, accepting exactly `m_K>=m_S/2` in Fraction arithmetic.
   Each column uses the actual core bbox and the **parent** radius
   `m_S^(1/n)`. Low-beta is checked at the core's own actual mass. No
   mass/radius proxy or invented core is used.

5. Deduplication uses `(full exact box, exact parent mass)`. Every original
   pair is retained in the pair-to-column mapping. Both LP coefficients
   and incidence agree for all representations of a deduplicated column;
   thus both objectives are preserved. Equal boxes with different masses
   are retained separately, which is harmless redundancy for `Pv`.

6. All unique column endpoints are added **before** final incidence.
   The final grid is the Cartesian product of all endpoints; bitset
   construction retains every target cell. Carrier membership is decided
   by integer endpoint ranges, with no midpoint or sampled receiver.
   Open-boundary faces are null. The reconstructed `Rlo` volume is also
   checked against the frozen Arb enclosure; this enclosure check alone
   is not a proof of geometry equality, but the all-box construction above
   supplies the relevant completeness argument.

## Radical arithmetic and outward certification

`root(q)` represents `q^(1/n)` exactly as a rational coefficient times an
nth root of an integer, extracting all nth powers. Multiplication adds
prime exponents and extracts further nth powers; sums use exact Fraction
coefficients. The square-/cube-free representations agree with the
baseline's canonical endpoint expressions. The cube-root evaluator is
`exp(log(r)/3)` for positive `r`, hence supplies a valid Arb enclosure of
the real cube root; it is not used as an exact symbolic simplification.

All nonzero geometry/threshold sign decisions use strict Arb interval
separation from zero. An unresolved expression raises an exception; it
does not get a floating tie or silently drop a candidate. Symbolically
empty expressions are exactly zero. High-beta is tested through
`n*beta^2-1`, valid because beta is nonnegative. These facts justify the
geometry ordering and inclusion decisions for accepted runs.

For each true volume cost, lines 175–181 obtain the exact rational
endpoints of its Arb enclosure, then floor/ceil on the `2^100` grid.
The code checks a positive rational lower bound and an outward upper
bound. It does **not** turn printed decimal strings into certified cost
bounds. The repair uses the lower endpoint for dual feasibility and the
upper endpoint for primal objective evaluation, the correct directions.

## Exact row compression and continuous dual

Every raw row receives its complete column-incidence bitmask. Only
identical masks are merged. The repeated primal inequalities are
literally the same inequality, so compression preserves the feasible
primal set and objective for both cost vectors. Conversely, raw dual
masses can be summed by pattern with no change to any column sum or the
objective. A compressed dual mass is expanded by placing it on one
actual positive-volume representative cell of that pattern. This proves
both directions of equivalence; no receiver sampling or relaxation is
involved.

For a raw cell `D`, `y_D` is a **mass**, not a density or quadrature weight.
The represented measure has constant density `y_D/|D|` on the entire
cell. Every carrier has all its endpoints in the grid, so its integral is
exactly the sum of incident cell masses. No pointwise density cap is
claimed. The full original cell areas remain recoverable as products of
successive exact endpoint differences even though large repeated area
payloads are omitted from serialization.

## Rational repair and objective brackets

HiGHS supplies candidates only. Nonnegative Fraction primal coefficients
are repaired on uncovered raw cells, then globally scaled upward until
**every raw row** has coverage at least one. Nonnegative Fraction dual
cell masses are globally scaled downward until **every distinct column**
sum is bounded by its exact mass cost or rational lower volume bound.
All original pairs are thereby covered because of the exact column
deduplication mapping. No solver optimal-status statement is a proof
premise for the resulting inequalities.

For any repaired pair, finite weak duality gives `dual lower <= true
minimum <= primal upper`. The code explicitly verifies nonnegative
slacks, expanded row coverages, and nonnegative bracket gaps. The mass
gaps are exactly zero, proving the separate finite mass minima. The true
volume gaps are nonzero; they certify brackets, not exact equality to the
finite minima. The mass-optimal and volume-optimal covers are distinct
plans, and their ledgers are not interchanged. The common volume-plan
comparisons reconstruct the frozen reference carrier fees; they do not
claim to rerun the old reference selectors or to exclude a third plan.

## Cheap saved-artifact checks actually run

Using local Python 3.12.14, without importing the probe or calling a
solver, I regenerated the complete `(S,K)` **mask/mass** list from each
saved eligible-parent list and the exact source weights. It equaled the
saved pair set with no duplicates. I checked every pair's mapped parent
cost and legal-representation entry, pattern-map/representative sizes,
all stored Fraction row coverages `>=1`, all stored Fraction column
slacks `>=0`, objective-gap identities, and support of dual masses on
actual representative cell rows. Results:

| Case | All pairs | Raw cells | Exact patterns | Unique columns |
|---|---:|---:|---:|---:|
| n2 | 849 | 85 | 41 | 146 |
| n3, d=.99 | 5191 | 56096 | 662 | 151 |
| n3, d=.999 | 5191 | 53912 | 734 | 151 |

All those checks passed. They check saved exact fields and enumeration;
they are not an independent recomputation of geometric incidence or of
all Fraction slacks from the full matrix. Static inspection above audits
that computation; the separate main-agent replay tests execution.
The final script hash was unchanged at the end of these checks.

## Explicit limitations

* Only the three locked inputs and their exact frozen comparison plans
  are certified. The hard-coded `lambda=L=1`, two dimensions choices, and
  no-top simplification are not a general-input implementation.
* The code's 512MB guard interprets `ru_maxrss` as bytes, correct on the
  reported macOS execution host. A Linux port would need its KiB unit
  conversion. This does not affect the mathematical certificates or the
  reported local execution, but the guard is not cross-platform as-is.
* Baseline hashes and endpoint payloads are genuine dependencies. Use
  the explicit baseline paths in the recorded command and a distinct
  output path. The optional masked file must be supplied to reproduce
  masked comparisons; without it the code omits those comparisons.
* Run normally, not with `python -O`, because proof checks use `assert`.
  Existing output may retain earlier cases when selecting a single case;
  audit each case's own code hash. The reviewed final `--case all` output
  contains all three cases with the same reviewed script hash.
* Runtime, package versions, solver iteration counts, and peak RSS are
  recorded execution metadata, not independently reproduced here. No
  claim of general optimality, integrality, dimension-uniform boundedness,
  or a new arbitrary-L1 estimate follows from these finite certificates.

No correction is required for the precise frozen finite claim. Audit
complete; no additional computation or parameter extension launched.
