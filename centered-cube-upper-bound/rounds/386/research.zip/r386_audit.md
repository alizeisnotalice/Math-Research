# R386 independent audit — FINAL PASS

Scope: only this file. The candidate below was checked independently before reading R386 author proofs. No repository or author files were changed. Final author proof, code/result/notes and integrated main/ledger/readme have now been reviewed. PASS applies to the exact successive original-cost subbranches and accounting below. The general bound remains open.

## 1. Original finite mass spectrum and measurable closed quantiles

Keep the same complete f, actual finite receiver E, positive bounded masses m, captures, source-exact plan, original J/clock and all spatial/source/history gates. At a fixed source y let rho_y(dv)=c_v(y)dv/m_v, J=J_b(y), T_y(t)=rho_y{m_v<=t}, and Z_u=rho_y{m_v<m_u/K}. Both T(t) and its strict-left version are measurable kernels. T is right-continuous, bounded by J<=Jmax=A_n/q_-, and its mass support lies in a fixed compact positive interval.

For ell_j=2^j h, j>=1, enable t_j(y)=inf{t:T_y(t)>=ell_j} only where J>=ell_j. Use arbitrary positive fallback endpoints on the inactive source set and multiply its window indicator by that activity indicator. Right-continuity and compact positive mass support ensure T(t_j)>=ell_j, including when J=ell_j, and make the quantile measurable by rational threshold tests. No mass atom is split physically.

If Z_u>h and T(m_u)>=2Z_u, choose the first dyadic level strictly greater than Z_u. It satisfies

    Z_u<ell_j<=2Z_u<=T(m_u)<=J.

Because T(t)<=Z_u for every t<m_u/K, this quantile cannot lie below m_u/K; since T(m_u)>=ell_j it cannot exceed m_u. Thus

    t_j(y) in[m_u/K,m_u],  m_u in[t_j(y),K t_j(y)].

A jump at m_u/K is permitted and yields the closed lower quantile endpoint. If Z_u equals a dyadic level, use the NEXT level rather than that equal level. The original strict mass comparison and closed windows are compatible.

The number of enabled candidate levels is at most L=max(0,floor(log_2(Jmax/h))) (levels start at 2h). If Jmax<2h there are no such windows; then Z>h already rules out T(m_u)>=2Z_u. Add the R385 essential-bottom window as one additional source-only window.

## 2. Preferred order: original R385 fraction, then actual large-end window traffic

First apply the R385 canonical bottom-window fractional receipt once, with price C lambda(1+log K)W/q_- and its exact marked remainder R_min. Its positive rows satisfy a>C(1-U), hence U>C/(C+1). Retain that actual same-plan positive restriction throughout subsequent cuts; do not replace it by the coarser union envelope.

On R_min directly pay only the CURRENT-source traffic inside the union of the L enabled dyadic large-end windows. No second whole-row lift is needed. The original source row cost is bounded by pi_u; the R385 fractional marker and all remaining marks are <=1. Each such actual window restriction is therefore bounded by

    integral_E q_u pi_u{m_u in[t_j(y),K t_j(y)]}du
       <=lambda(1+log K)W/q_-.

The quantile window is source-only and measurable; restricting it to its active source set only decreases the center integral. Union domination gives L times this fee. The combined large-end price, including R385 once, is thus (C+L)lambda(1+log K)W/q_-, rather than a second C-multiplied union lift.

All further traffic is an exact positive restriction of R_min. It retains the near-full-U row condition and misses every enabled dyadic window. The contrapositive of Section 1 then gives T_y(m_u)<2Z_u on each remaining actual source tuple. A separate whole-row qualification without this explicit source-window cut would not imply that condition. Original alpha/Y/clock and full-f matching stay fixed; no plan is reconstructed and no old trigger is transferred.

## 3. Regular column and atom-safe logarithm

For the remaining regular traffic, drop only positive target/source marks after preserving the original strict-past and physical clock. For fixed source y and small receiver v, its large-u column is bounded by

    integral_regular c_u(y)du/[R_u^n Z_u].

The physical clock tail is exactly R_u^-n, including b's terminal atom; J_y(r)>=Z_u on active r. Using q_u<=lambda and T(m_u)<2Z_u gives

    column <=2lambda integral_{T(t-)>h} dT(t)/T(t)
           <=2lambda log_+(J_b(y)/h).

Indeed T(m_u-)>=Z_u>h because m_u/K<m_u. The denominator is the RIGHT closed CDF. A mass atom of size d at rank interval (l,l+d] contributes d/(l+d)<=log((l+d)/l); its left rank is >h. The nonatomic and singular-continuous parts follow from rank integration. Thus no first-crossing atom or additional +1 is required. In particular this argument would fail with only T(m_u)>h while its left rank was below h; the original strict past provides the stronger condition actually used.

The corresponding source-small-receiver bound is f(y)rho_y(dv) times that column, with the actual remaining masks retained until the upper bound. It is not a q_v dv column cap and does not assert that the original source or receiver marginals have changed.

## 4. Closed low-rank exit and the next quantile window

For every finite CDF, whole atoms included,

    rho_y{v:T_y(m_v)<=2h}<=2h.

An atom jumping across 2h is excluded, rather than fractionally charged. Therefore the regular low-rank small-end subbranch costs at most

    4lambda h log_+(Jmax/h) W.

This is an actual source-W fee, not an X_q term. Empty or zero-J rows have no traffic and contribute zero.

After deleting that branch, T_y(m_v)>2h. If its own strict smaller-mass occupation Z_y(m_v/K-)<=h, the active level-2h quantile satisfies

    t_1(y) in[m_v/K,m_v],

because 2h>Z_y(m_v/K-) and T(m_v)>2h. Hence m_v belongs to [t_1,Kt_1]. The certified R381 small-end source-window estimate bounds this positive restriction by

    B_*(1+log K) W/q_-.

All restrictions are from the original same-plan cost, so they do not increase the original small-end source kernel envelope. Apply this window only after the low-rank branch, so the two payments are disjoint. The small-end window fee is separate from the earlier large-end union receipt: it acts on the still-unpaid endpoint branch, rather than paying the same source traffic twice.

The exact remaining branch has both original large-u strict past>h and small-v strict past>h at the SAME source y. This is not an assertion of Y_v, alpha_v, receiver activity, first-crossing or history qualification. Neither this two-sided strict-past condition nor the source union has yet received a general root budget.

## 5. Growth rates and final-accounting obligations

With K=exp(sqrt(n)), log K=sqrt(n), and the original synchronized h=(1+sqrt(n))/(epsilon0 q_-), the low-rank fee is

    (4lambda/q_-)(1+sqrt(n))/epsilon0
      *log_+(A_n epsilon0/(1+sqrt(n))) W.

For fixed parameters, or the previously stated inverse-polylogarithmic epsilon0 allocation, this is an allowed root times polylogarithm source price. L is O(log(n+2)); the large-end union fee and small-end window fee are likewise root times the displayed logarithmic/parameter factors. This asymptotic statement does not permit changing h after fixing original masks, and a new C or parameter choice must carry its complete fee and exact remainder.

The preferred total NEW source coefficient for these stages, including the inherited R385 price once, is

    (C+L)lambda(1+sqrt(n))/q_-
      +4lambda h log_+(Jmax/h)
      +B_*(1+sqrt(n))/q_-.

This is added to the other original coefficients such as C338, with all relevant hard-slot contributions doubled and multiplied by Lambda at the original entrance. The final ledger must retain exact successive positive restrictions, R383 screening once, all original H/source entrance terms and soft/crossing/history/scale/limit obligations. The first term already includes R385; no second C root price or C-multiplied whole-row union fee is added. No Hall approximation fee, extra negative square, small-receiver inherited qualification or general final closure follows.

## 6. Bounded reviewer mathematical-tool checks

Actually ran 2143 Python standard-library Fraction quantile/closed-rank checks on finite atomic mass spectra. These verified dyadic coverage including boundary atoms, the 2h small-end quantile implication, and whole-atom low-rank capacity. This is separate bounded algebra/measure evidence, not native continuous cube/high-history realization, a substitute for proof, or an additional parent pipeline count.

Conclusion: PASS for the precisely stated three-stage receipt and its original-clock/atomic endpoint constants. Final integration review is recorded below.


## 7. Final author-proof and script review

Read /tmp/r386_geometry.md and its entire check script after the independent screen. Equations (5)--(19) agree with the proof above, including inactive-level masks, full original E, strict left-rank restriction, and the measure f(y)c_v(y)dv/m_v at the exit. The logarithmic column alone is correctly NOT treated as a W budget; the whole-atom closed low-rank restriction is inserted before removing the exit measure. P_small retains B_* while P_jump does not, in agreement with the distinct small/large endpoint receipts. No endpoint history or outgoing cost is inherited.

The author's 8181 Fraction diagnostics use positive atanh-series rational lower bounds for logarithms, not floating-point tests. They check finite atomic rank measures and algebraic cost splitting, not native continuum field realizations. Their reported development failure after changing the low-rank cutoff to 2h is expressly excluded from passed evidence. No complete rerun was needed in this independent code review.

## 8. Independent review of the new true-du example

Read /tmp/r386_continuum.md, the entire Python code, and the saved result. All actual receiver center sets are genuine side-eta boxes. The sixteen tiling families at sign centers (+/-1/4)^4 have a positive-occupation capture union Q_(1+eta)(0), modulo null boundary, containing every large Q_u. All sixteen masses are far below m_u. This proves U_u=1 rather than merely a positive union estimate, so the original R385 witness and actual payment are zero.

Only the all-positive tiling family and the additional traffic family capture the high packet D. Their masses are both m_v, so the ORIGINAL packet occupation is Z=2eta^4/m_v and J=Z+eta^4/m_u. The other fifteen tiling families capture no packet. The tiling families fail the outside-center gate, but their capture occupation is retained in J and Z. The cost receives only the extra traffic family's small-end factor eta^4/m_v. The code correctly uses that factor, not Z, in alpha. Source/target masses and q are computed from the same complete background-plus-packet input.

The first-coordinate capture average is 3/2-2d. For each of the other three coordinates the overlap fraction is 1-2(v_shift-u_shift)_+; on the independent PRODUCT CENTER domains its mean is 1-eta/3 because the positive part of the difference of two side-eta uniform coordinates has mean eta/6. Applying Fubini to these real center domains gives exactly

    p_mean=(3/2-2d)(1-eta/3)^3.

This is actual center integration and makes no independence assumption on f. The global pairwise upper capture bound used for alpha and A_lower is conservative and holds for each continuous large center, so the core screen does not merely pass a block mean. Both formulas for G are algebraically identical and positive. All positive far costs start at R_u=b=1, hence only the true terminal physical-clock atom contributes; the earlier continuous clock has no positive far pair.

Every tested active dyadic source level is <=Z and its quantile is m_v; the code checks this per parameter field. Since m_u>K m_v, large-end quantile traffic is zero. T_y(m_v)=Z>2h excludes low-rank payment. K>2 and m_v/2<m_0 prove that small v has zero strict far past (using K<8 would have had the wrong implication). Thus the last level-2h small-end window pays the entire positive cost. The declared auxiliary-certificate direction correction and complete successful rerun are honestly recorded.

This example uses diagnostic h=H=10^-8 and diagnostic screening delta. It is not a synchronized R379/history realization or general lower bound. The actual parameter, q, capture, outside/dense/deep/not-Bplus and core guards are checked on whole center boxes. The parent reports 2617 Fraction assertions over 1+27+81 parameter-field executions; stages overlap, so this is not 109 distinct models. This number and the author's 8181 finite-rank diagnostics are separate from the reviewer's 2143 bounded checks. No full parent pipeline was repeated.

Author proof and true-du example: PASS within the stated scopes. Final integrated accounting and byte bindings follow.


## 9. Final integrated accounting and growth check

Read final r386_main.md, r386_ledger.md and r386_readme.md in full. The preferred source coefficient is exactly

    S386={[(C+L)lambda+B_*](1+sqrt(n))/q_-}
          +4lambda h log_+(Jmax/h).

It includes the R385 C-price ONCE. Starting from the already written R385 ledger adds only the L-window, low-rank and small-window prices; starting from the pre-window core writes C+L as displayed. This replaces the old same-slot C price and does not add F2 or another R384/R385 fee. The exact G_next is the final positive restriction, not a numerical proxy based only on U or a restarted receiver process.

The final hard estimate is

    BH<=G_next+(eta+sigma_n+epsilon383)X_q+(C338+S386)W.

The original entrance has 2G_next and twice the displayed hard-slot X and source coefficients, plus the retained 8lambda H W and 2d_eff A_n W_nu/H; the entire entrance is then multiplied by Lambda. Thus every new source price carries exactly 2Lambda. There is no new X_q coefficient, target-cap inflation, h/t change or reused negative-square credit. The inherited local kappa allocation is unchanged and is not a full global absorption certificate.

With fixed inherited absorption parameters, C=log(n+2), epsilon0^-1=O(log^(3/2)(n+2)), A_n=O(n), and the SAME original synchronized h, one has L=O(log(n+2)) and log_+(Jmax/h)=O(log(n+2)). The low-rank coefficient is therefore O(sqrt(n)log^(5/2)(n+2)); the window and B_* terms are no larger in this fixed-parameter sense. Constants retain their old parameter dependence. This estimate covers the displayed source coefficients only, not the unpaid H entrance or other slots.

The final presentation correctly leaves G_next, actual next-step spatial/source/target/history qualifications, and all inherited soft/crossing/entry, tail/scale complements, initial/deleted/future-deleted history atoms, aggregation, truncation and limits unpaid. Same-source strict-past availability at v is not a Markov continuation, Y_v or alpha_v claim. No old-history full reduction or LaTeX compilation was re-certified here.

Parent reports successful actual runs totaling 10798 Fraction assertions=8181 finite-rank checks+2617 continuum-example checks. Their scope, repeated parameter executions and corrected development guards are accurately stated. The reviewer ran the separate 2143 bounded Fraction tests from Section 6 and did not repeat parent pipelines. These evidence categories are not merged.

FINAL PASS: no outstanding correction found for the exact R386 receipts, true-du example, final fees or stated limitations. General root closure is NOT established.

## 10. Final byte bindings

The following final author files and specific inherited proof dependencies were bound after review. Inclusion of a historical dependency is not a claim of freshly re-auditing the entire historical reduction.

| File | SHA256 |
| --- | --- |
| `/tmp/r386_main.md` | `4b8a5585a5445d78b8a5a290fe9f722801aefa9352032cf2cac9281836433d47` |
| `/tmp/r386_ledger.md` | `151e01d43263b4572a9299e0964d91c46e72ea4fd951315b72673caf6be9a64f` |
| `/tmp/r386_readme.md` | `e784e6a0e1b2e54bea02506d0e7d2f67004805d484b250926d69e5aeb26fc9fd` |
| `/tmp/r386_geometry.md` | `fe839792aff6ca2b1fcb6787a8073fe71d8ca3dd28b8d46585d350d2c5851bca` |
| `/tmp/r386_geometry_check.py` | `e3a8f6e2cd693e3069cec2a498d644c065ce1a11c2458f6e66a7e4d3acc4fda9` |
| `/tmp/r386_continuum.md` | `a086a9f656722e78aeb4bf6aff301bd4e3c301770b83af247a0ff940474059c8` |
| `/tmp/r386_continuum.py` | `7a396f6e32b29ae8192dbd1ee3c67a07232810c8d5a82c239d7a011a9876e89d` |
| `/tmp/r386_continuum.result.json` | `05b1ea661caf2ded6b6af2d3d2a07c89fde806ead7a925ae1f544bef266018d6` |
| `/tmp/r385_geometry.md` | `f39ec03b200b8954695da179d5d24183a1420081a96aaee61f34fb09c353c8eb` |
| `/tmp/r385_ledger.md` | `481d851517df6cc6653810cde374bdef62e72fb0636c62f17d6ab950e4b89c45` |
| `/tmp/r376_geometry.md` | `16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7` |
| `/tmp/r381_geometry.md` | `df86a325407457678613cc00fb4de37023ff29fb5d6ce4b039238c148a2f071f` |
| `/tmp/r382_geometry.md` | `e596a311e4eca9be309c10aafe75db0e1938aa815dd258538461bdf0d47f2944` |
| `/tmp/r383_flow.md` | `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd` |
