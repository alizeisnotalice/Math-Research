from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json
count=0

def ck(x):
 global count
 assert x
 count+=1

ck(2<sum((F(2**j,factorial(j)) for j in range(11)),F(0)) and sum((F(2**j,factorial(j)) for j in range(11)),F(0))+F(2**11,factorial(11))/(1-F(2,12))<8)
def case(eta,d,P,delta):
 bg=F(3,4); rv=F(1,2);ru=F(1);m0=bg*rv**4
 mv=m0+P;mu=bg+P;qv=mv/rv**4;qu=mu;w=eta**4
 volD=F(1,100)**4;fD=bg+P/volD;h=F(1,10**8)
 ck(bg<=qv<=1 and bg<=qu<=1)
 ck(mu>8*mv and mv/2<m0)
 # Packet [.47,.48] x [.10,.11]^3: exactly all-positive tile captures it.
 ck(F(1,2)-eta/2>=F(12,25))
 ck(eta/2<F(1,10) and F(1,4)-eta/2+rv/2>F(11,100))
 ck(d+eta/2-rv/2<=F(47,100))
 ck(d+eta/2+rv/2<2)
 # Union of 16 true center-box families +/-1/4 covers every large Q_u.
 ck(F(1,4)+rv/2+eta/2==ru/2+eta/2)
 ck(-F(1,4)+rv/2+eta/2>=F(1,4)-rv/2-eta/2)
 # Tiling families have no outside pair; extra traffic family always does.
 ck((2*(F(1,4)+eta))**4<3)
 ck((2*(d-eta))**4>3 and d+eta<F(3,4))
 ck(2*(d-eta)-F(1,2)>F(4,20) and 1>F(4,8))
 beta=F(5,4);allowance=4*((1+beta)*rv-ru)**2/(4*beta*rv)
 ck(2*(d-eta)-(ru-rv)>allowance)
 ck(fD>4*max(qv,qu))
 Z=2*w/mv;J=Z+w/mu
 ck(Z>2*h and J<2*Z)
 # Every active dyadic source level is below Z; its quantile is mv.
 ell=2*h;levels=[]
 while ell<=J:
  ck(ell<=Z)
  levels.append(str(ell));ell*=2
 ck(len(levels)>0 and ell>J)
 # Exact full product-center target integration. Other coords: E(z+)=eta/6.
 pmean=(F(3,2)-2*d)*(1-eta/3)**3
 lossmean=1-pmean
 lossmin=1-(F(3,2)-2*(d-eta))
 c=(w/mv)/J*(1-mv/mu)*(1-qv/fD)
 piD=fD*volD/mu
 ck(piD*c*lossmin>2*delta and c*lossmin>delta)
 G=w*w*(1-mv/mu)*(fD-qv)*volD/(mv*J)*lossmean
 ck(G==qu*w*piD*c*lossmean and G>0)
 # U=1 from actual geometric union; no minimum-window witness for a large u.
 U=F(1);Fminimum=1-U
 ck(Fminimum==0)
 # Small endpoint: T(mv)=Z>2h but strict past at mv/K is zero.
 ck(Z>2*h and mv/2<m0 and mu>8*mv)
 return {'eta':str(eta),'d':str(d),'P':str(P),'delta':str(delta),
         'G':str(G),'U':'1','old_minimum_payment':'0','rank_jump_current_payment':'0',
         'low_rank_payment':'0','small_endpoint_window_payment':str(G),
         'Z':str(Z),'J':str(J),'active_packet_levels':levels,
         'A_lower':str(piD*c*lossmin),'capture_mean':str(pmean),
         'W':str(bg*4**4+P),'Xq':str(w*(15*bg+2*qv+qu))}
stages={
 'initial':[case(F(1,100),F(7,10),F(1,100),F(1,1000))],
 'pressure':[case(e,d,p,F(1,1000)) for e,d,p in product(
  [F(1,200),F(1,100),F(1,50)],[F(17,25),F(69,100),F(7,10)],
  [F(1,200),F(1,100),F(3,200)])],
 'expanded':[case(e,d,p,de) for e,d,p,de in product(
  [F(1,200),F(1,100),F(1,50)],[F(17,25),F(69,100),F(7,10)],
  [F(1,200),F(1,100),F(3,200)],[F(1,4000),F(1,2000),F(1,1000)])]}
result={'scope':'True Lebesgue center boxes; h=H=1e-8 literal diagnostic, not synchronized or complete historical selector',
        'counts':{k:len(v) for k,v in stages.items()},'fraction_assertions':count,'stages':stages}
Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('PASS',result['counts'],'Fraction assertions',count)
print('baseline',stages['initial'][0])
