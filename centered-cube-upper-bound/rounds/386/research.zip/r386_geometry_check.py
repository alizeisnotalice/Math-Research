from fractions import Fraction as F
from itertools import product

def log_lower(x):
 assert x>=1
 k=0
 while x>2:x/=2;k+=1
 def series(r):
  z=(r-1)/(r+1)
  return 2*sum((z**(2*i+1)/F(2*i+1) for i in range(30)),F(0))
 return k*series(F(2))+series(x)

counts={'quantile_cover':0,'regular_column':0,'terminal_exit':0,'failed_endpoint_cover':0,'fractional_union':0}
positive_jump=0;positive_terminal=0;empty_levels=0
for seed in range(1,25):
 mass=sorted(set(F(1+(seed+3*i)%19,2) for i in range(7)))
 N=len(mass)
 nu=[F(1+(seed+2*i)%7,5) for i in range(N)]
 q=[F(3+(seed+i)%2,4) for i in range(N)]
 T=[sum(nu[:i+1]) for i in range(N)];J=T[-1]
 Jmax=J+F(seed%3,4)
 for h,K in product((F(1,5),F(1,2),F(1),J,Jmax+1),(F(3,2),F(2),F(3))):
  levels=[];level=2*h
  while level<=Jmax:
   levels.append(level);level*=2
  empty_levels+=int(not levels)
  anchors=[next((mass[i] for i in range(N) if T[i]>=lev),None) for lev in levels]
  Z=[sum(nu[j] for j in range(N) if mass[j]<mass[i]/K) for i in range(N)]
  inside=[any(s is not None and s<=mass[i]<=K*s for s in anchors) for i in range(N)]
  for i in range(N):
   if Z[i]>h and T[i]>=2*Z[i]:
    assert inside[i];positive_jump+=1
   if Z[i]>h and not inside[i]:assert T[i]<2*Z[i]
   for lev,s in zip(levels,anchors):
    assert (s is None)==(J<lev)
    if s is not None:
     idx=mass.index(s)
     assert T[idx]>=lev and (idx==0 or T[idx-1]<lev)
   counts['quantile_cover']+=1
  col=[]
  for v in range(N):
   value=sum(q[u]*nu[u]/Z[u] for u in range(N)
             if mass[u]>K*mass[v] and Z[u]>h and not inside[u])
   col.append(value)
   if J>h:assert value<=2*log_lower(J/h)
   else:assert value==0
   counts['regular_column']+=1
  terminal=sum(nu[v]*col[v] for v in range(N) if T[v]<=2*h)
  assert sum(nu[v] for v in range(N) if T[v]<=2*h)<=2*h
  if J>h:assert terminal<=4*h*log_lower(J/h)
  else:assert terminal==0
  positive_terminal+=int(terminal>0)
  counts['terminal_exit']+=1
  first=next((mass[i] for i in range(N) if T[i]>=2*h),None)
  for v in range(N):
   if T[v]>2*h and Z[v]<=h:
    assert first is not None and first<=mass[v]<=K*first
   counts['failed_endpoint_cover']+=1
# Exact positive-cost splitting for a union window and then a lower-end branch.
for a,Fwin,b,C,p in product((F(0),F(1,4),F(1,2),F(1)),
                           (F(0),F(1,4),F(1,2),F(1)),
                           (F(0),F(1,4),F(1,2)),(F(1),F(2),F(3)),
                           (F(0),F(1,3),F(1))):
 if b>min(a,Fwin):continue
 paid=min(a,C*Fwin)
 if a==b:
  assert paid==a;res=F(0)
 else:
  t=(paid-b)/(a-b);assert 0<=t<=1
  res=(1-t)*(a-b)
 assert res==max(a-C*Fwin,F(0))
 terminal=p*res;last=(1-p)*res
 assert paid+terminal+last==a
 counts['fractional_union']+=1
print('PASS',counts,'total',sum(counts.values()),'rank-jump covered',positive_jump,
      'positive terminal cases',positive_terminal,'empty-level cases',empty_levels)
