# R379 全局总账：三个pair分支与两类原来源

所有量由同一完整f与原接收选择器定义。W=||f||_1，X_q=∫q_u du，q_-=3λ/4，A_n=1+nlog(b/a)，Λ=128/119，b≤2a。不同参数场的标记与不同计划信用不得拼接。

## 参数先后与实际计划

先固定η,ε,ε'>0及T=1+ceil(log_2(n+2))，置
\[
 \bar B=\frac{A_n\eta q_-}{2(1+\sqrt n)},\quad
 t=1+\max\{0,\lceil\log_2(\bar B/(\varepsilon q_-))\rceil\},
\]
\[
 \mathcal L=2+\frac{72+(T+t)\Gamma_n}{1+\sqrt n},\quad
 \varepsilon_0=\eta/\mathcal L,\quad h=\frac{1+\sqrt n}{\varepsilon_0q_-}.
\]
ε0≤η/2给原核B=A_n/h≤Bbar，故t没有循环定义。用该h同步重建所有原门、J/ω及clock；不能把它们改成截断f的场。

低来源μ_v^lo=1_{f≤Tq_v}μ_v^+走identity，成本逐点零，target≤(T−1)U。高来源μ_v^H=1_{f>Tq_v}μ_v^+=d_v^HP_v^H接R378针对remaining pair核的t层共同计划，target≤td_v^HU。dH=0时省略，不除零。

remaining pair核同时保留j>n/8、Σd_i>n/20和所有原门。其真实高来源dyadic部分运输缺额δ^H_{v,τ,∞}按R378有限关系定义，
\[
 \mathcal D_{H,deep}=\int_Ed_v^H\sum_{j=0}^{t-2}(\tau_{j+1}-\tau_j)
 \delta^H_{v,\tau_j,\infty}\,dv.
\]
阈值从εq_-倍增至Bbar，有限深度逼近误差≤ε'X_q。若t=1，直接product补高来源，D=0且成本≤εX_q。

## 完整付款与原始入口

同一全来源精确计划τ=τlo+τH，full bad按sparse、dense-shallow、dense-deep不交叠分解。前两支的合计费用≤σ_nX_q，其中
\[
 \sigma_n=\frac{\varepsilon_0}{1+\sqrt n}
 [\widehat b_n+(753/800)^n],
 \quad b_n=2^{-n}\sum_{j≤\lfloor n/8\rfloor}{n\choose j}4^j,
\]
并沿用n<8时bhat=0，其他维度bhat=b_n。两个界都只需来源精确，所以允许本轮混合了identity与密度计划的τ。低来源在第三支亦零；高来源成本≤(ε+ε')X_q+D_H,deep。

全计划floor+good≤(T+t)p，所以
\[
 B_H(f,\nu)\le \mathcal D_{H,deep}
 +(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+C_{338}W,
\]
\[
 C_{338}=\frac\lambda{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right],
\]
\[
 \Gamma_n=1+\frac{n}{4(\sqrt n+1)}
 +2\sqrt n\sqrt{1/4+\tfrac12\log(1+\sqrt n)}(1-1/\sqrt2).
\]
T+t=O_{η,ε}(log(n+2))，因此上述C338W=O_{η,ε}(sqrt(n)log^(3/2)(n+2))W。D_H,deep没有被此式支付。

原入口完整保留：
\[
 T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
 +2\mathcal D_{H,deep}
 +2(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+2C_{338}W.
\]
整式乘Λ。bhat≤1、(753/800)^n≤1，n≥1、ε0≤η/2，所以σ_n≤η/2。仅为此槽分配κ时可取η=ε=ε'=κ/(7Λ)，则2Λ(η+σ_n+ε+ε')≤κ。这不是其他槽的总吸收认证。

## 仍未支付

D_H,deep的一般根阶来源预算；原H入口与H选择；一般soft/crossing/entry；合同外重尾、宽距离、低pe与极端尺度比及全部阈值补集；初始、删除跳跃和未来被删来源历史原子；全尺度/来源聚合、外积分、截断与极限。物理末端原子不代替历史预算。

小几何p不等于小I_uv/m_v，高来源f>Tq_v也不自动有维数一致小L1尾。低来源identity的费用已计入(T+t)Γ，不能再把直接low-p界列成独立节省。若选用旧cap2/M1计划，必须同场比较完整成本，不能在本计划上额外扣旧Capture或旧振荡收益。

# 第380轮增量：同场来源簇付款，完整替代账单

以上第379轮参数、原入口、分支与所有未付接口原样保留。令τH为该轮高来源计划，G为其实际dense-deep成本，χ_v(y)=Σ_j(f_j/f)(y)χ_jv，Fθ=cθB*/q_-。B*=min(A_n/h,λlog_+(A_n/(q_-h)))；若B*=0则G=0，不作不必要除法。

## 选项A：同一个原计划，精确成本分解

令Rχ=∫dv∫(1−χ_v(y))C_v(y,z)dτH。则G≤FθW+Rχ，故
\[
 B_H\le R_\chi+(\eta+\sigma_n)X_q+(C_{338}+F_\theta)W,
\]
\[
 T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
 +2R_\chi+2(\eta+\sigma_n)X_q+2(C_{338}+F_\theta)W.
\]
整式乘Λ=128/119。这里没有再支付ε、ε'，因为没有把实际G替换成Hall上界；旧的G≤D_H,deep+(ε+ε')X_q仍是另一个可选完整上界。绝不能写Rχ≤D−Gχ。

θ=1/√n时Fθ=2√nB*/q_-；固定η、ε且λ/q_-=4/3时B*/q_-=O(log(n+2))。于是新增来源费用为O(√n log(n+2))W，原C338仍为O(√n log^(3/2)(n+2))。相同分解的质量窗|log(m/M)|≤√n可直接支付2e√nB*/q_-乘W，窗外实际成本保留；这与χ付款是二选一，不重复结算。

## 选项B：重新构造完整计划，保持目标容量

按χ切分原高来源，已付部分用product，余下部分按R378层构造。目标密度≤(dpaid+t drem)U≤t dHU，低来源identity不变，模板仍(T+t)Γ，无新增容量项。新剩余Hall账单Drem按残余归一化来源重算，不能声称小于旧D。完整账为
\[
 B_H\le D_{rem}+(\eta+\sigma_n+\varepsilon+\varepsilon')X_q
 +(C_{338}+F_\theta)W.
\]
入口中D_H,deep替换成Drem，C338替换成C338+Fθ，其他项原样保留，全式仍乘Λ。此槽η=ε=ε'=κ/(7Λ)仍保证总吸收≤κ，不构成其他槽认证。

## 未闭合部分

选项A的真实Rχ或选项B的Drem仍未获一般根阶预算；全局簇选择与质量失配联合几何是下一证明瓶颈。以上原H入口、soft/crossing/entry、重尾宽距离低pe极端尺度比、初始删除跳跃未来被删来源、全尺度聚合及极限全部继续列为未付，不能以本轮局部付款宣称全局闭合。

# 第381轮增量：来源可变窗口与准确余项

沿用上述R379参数及同一个完整原始场，优先保留原高来源共同计划τH。设L(y),U(y)来源可测且0<L≤U，log(U/L)≤D。窗口内与窗外为同一实际成本的不交叠分解G=Gwin+Rwin。由本轮直接质量—距离包络，F_D=(1+D)B*/q_-，
\[
 B_H\le R_{win}+(\eta+\sigma_n)X_q+(C_{338}+F_D)W,
\]
\[
 T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H
 +2R_{win}+2(\eta+\sigma_n)X_q+2(C_{338}+F_D)W.
\]
整式乘Λ。D=√n给新费用O(√n log(n+2))W；原C338仍O(√n log^(3/2)(n+2))W。B*=0时全部该成本为零。没有改变targetcap，仍(T+t)Γ，因此不重建h或追加模板费。

有限候选来源窗口优化后仍是一个来源可测窗口，价不乘候选数。软参照最优值同理，不可把soft付款与hard窗口付款对同一交通相加。取窗口补集而重建残余layered计划时，目标仍≤tdHU，但新Hall缺额须重算；不从旧D减去已付成本。

来源树路径最大核是另一个完整正分解，本轮θ=1价格q_-^{-1}∫f bh[2+log(Mroot/Mleaf)]。真实分割树且统一根W时，放松bh≤B*给(B*W/q_-)[2+H(p)]，p_leaf=Mleaf/W。树整质量跨度内的硬窗则常数1+H(p)。未证明H(p)一般根阶，不将它计为已闭合来源价；真实path-max剩余或整窗外成本继续保留。

只给此槽预算κ时，旧η=ε=ε'=κ/(7Λ)仍安全；优先同计划精确Rwin版本甚至无需新增ε、ε'。这不支付原H入口、其他soft/crossing/entry、重尾宽距低pe极小尺度比、初始与删除历史原子、全尺度聚合及极限。所有这些旧未付接口继续存在。

# 第382轮增量：原clock大端窗与二端账单

所有R379场参数、原入口、σ_n、C338、(T+t)Γ与旧未付槽保持不变。固定原计划的剩余deep成本测度dG。选来源可测窗口I_v(y),I_u(y)，宽度分别≤D_v,D_u，令b=1_{m_v∈I_v}，a=1_{m_u∈I_u}。

R₂=∫(1−b)(1−a)dG是精确双端未付成本。直接付款给
\[
 F_2={B_*(1+D_v)+\lambda(1+D_u)\over q_-},
\qquad B_H≤R_2+(\eta+\sigma_n)X_q+(C_{338}+F_2)W.
\]
保留全部原入口：
\[
 T_{entrance}≤8\lambda HW+2d_{eff}A_nW_\nu/H
 +2R_2+2(\eta+\sigma_n)X_q+2(C_{338}+F_2)W.
\]
整式乘Λ=128/119。若只选大端窗，删小端价并令R₂=∫(1−a)dG；新增来源价λ(1+D_u)/q_-。D_u=D_v=√n时F₂为O(√n log(n+2))，只大端为O(√n)。这只支付所选分支，并非一般G根阶。

上述付款没有新增X系数，也不增加目标容量或重新定义h。若使用小端原S=∫f b_h，可保留比B_*W更精确的价格；不将这两种完整上界重复结算。

可选残余核重建：先固定窗口，把(1−b(v,y))(1−a(u,y))乘入原u测度，保留原z核与完整f。R378近捕获与有限层构造仍可用，row bound≤原Bbar，同t、ε、ε'与目标cap。令其真实新Hall费用D₂，则
\[
 B_H≤D_2+(\eta+\sigma_n+\varepsilon+\varepsilon')X_q+(C_{338}+F_2)W.
\]
新D₂不是旧D减去付款；若窗口由旧计划优化，新计划的覆盖率须重算。外层仍2Λ，旧κ分配仍仅证明本槽可吸收，不证明其他槽。

同窗宽≤logK时两个已付事件互斥，余项分成m_u<L、m_v<L且m_u>U、m_v>U三类。三类费用尚未得一般预算，不把这种分类当作付款。

仍未付：R₂或D₂，原H入口与选择，soft/crossing/entry、合同外重尾宽距低pe极小尺度比及阈值补集、初始删除跳跃未来被删来源、全尺度聚合和极限。原平方信用已用于前序归约，不在本账再扣。数值中任何放松几何门/替换h都单列，不回填成上述一般证明。


# 第383轮增量：接收低流吸收与真实端点账

固定上一轮同计划双端窗外R₂；也可无窗取原G并将F₂设为0。以下G指该准确剩余量。取0<ε383≤1，应用本轮原接收分解G≤ε383X_q+G_core，不增加目标容量、h、t或模板费用。于是
\[
 B_H≤G_{core}+(\eta+\sigma_n+\varepsilon_{383})X_q+(C_{338}+F_2)W,
\]
\[
 T_{entrance}≤8\lambda HW+2d_{eff}A_nW_\nu/H
 +2G_{core}+2(\eta+\sigma_n+\varepsilon_{383})X_q+2(C_{338}+F_2)W.
\]
整式乘Λ=128/119。此版本没有把G替换为Hall上界，故不另收旧ε、ε'。仅为此槽分配κ，可取η=κ/(6Λ)、ε383=κ/(4Λ)，因σ≤η/2，新增总系数≤κ。仅当κ使ε383≤1时采用该选择；通常κ<1。旧参数ε用于确定t但不等同本轮ε383，也不额外形成此版本吸收项。

另一完整替代：对未筛G用min{X_q,cK(X_q−Q_flow)}替换，保留原η+σ和F₂；或对G_core重新定义其接受H使用相同P的能量上界。两种估计取更小的完整上界，不把Q_flow作为旧平方的额外扣款。相同P的全能量也可能过粗，不声称一般根阶。

未付：G_core的来源加权端点/实际条件sqrt(m)方差；原H入口及H选择；soft/crossing/entry；重尾、宽距离、低pe、极端尺度比及补集；初始、删除跳跃、未来被删来源；全尺度聚合、截断、极限交换。上述κ只控制本槽，并不认证所有槽总吸收。数值诊断门不改变任何该总账字段。


# 第384轮增量：按实际行密度的完整来源见证

本版本从未删除本次窗的原G和同一来源精确计划开始。先做R383正分解，再对G_core做本轮整行/窗口联合付款。记F_lift=Cλ(1+D)/q_-。本版本替换R382窗口账单，不另收F₂；其他既有不交付款若另保留必须逐一注明，本版本未混用。
\[
 B_H≤R_{lift}+(\eta+\sigma_n+\varepsilon_{383})X_q
 +(C_{338}+F_{lift})W,
\]
\[
 T_{entrance}≤8\lambda HW+2d_{eff}A_nW_\nu/H+2R_{lift}
 +2(\eta+\sigma_n+\varepsilon_{383})X_q+2(C_{338}+F_{lift})W.
\]
整式乘Λ=128/119。本轮没有新增X吸收系数或targetcap、t、h、模板费。C=2,D=√n时新增来源价严格根阶；总已付C338仍带允许的固定对数损失。

仅为本槽分配κ，仍可取η=κ/(6Λ)、ε383=κ/(4Λ)，σ≤η/2，故该槽X系数≤κ（取0<κ≤1）。这不认证其他槽总吸收。没有将实际R_lift替换为Hall上界，因此不额外收旧ε、ε'，也不从旧Hall缺额减去此付款。

R_lift准确为Acore>CF且实际来源窗外的原交通。所有原来源/目标/空间/时钟/历史门保留，不重建f。其存在高活跃来源质量的结论不等于接收者之间来源互不重叠，也不证明小端的后续资格。

仍未付：R_lift的一般根阶预算、原H入口与选择、soft/crossing/entry、重尾宽距离低pe极端尺度比及全部补集、初始删除跳跃未来被删来源、全尺度聚合/截断/极限。无旧square二次扣款。原physical terminal atom不替代历史原子预算。

本轮账单严格固定同一计划。改变计划会改变Acore及整行触发器，须重新核验，不能把旧weak行事件直接转授新计划。


可选分数付款版本：将本轮上面两式的R_lift直接替换为R_frac=∫_{Ehi}q_u(a_u−CF_u)_+du，其余字段及来源价完全相同。此为同价更小余项的替代估计，不能再次扣窗口付款。该版本不继承R_lift的δ/2行下界。若另外删去R_frac行密度≤ζ的接收者，准确新增ζX_q（入口2ΛζX_q）；须重新分配κ，本文默认未采用该额外删除，故此前κ公式不变。


# 第385轮增量：实际本质下锚，无覆盖个数假设

从R383未删本次窗的同一原计划/完整f核心出发。选择本轮实际来源谱下锚s及I=[s,Ks]，C≥1。令F_min=Cλ(1+√n)/q_-，R_min=∫_{Ehi}q[a−C(1−U)]_+。本次将R384窗口价和余项实例化为F_min、R_min，不再叠加旧F₂或另一次R384来源费。
\[
 B_H≤R_{min}+(\eta+\sigma_n+\varepsilon_{383})X_q+(C_{338}+F_{min})W,
\]
\[
 T_{entrance}≤8\lambda HW+2d_{eff}A_nW_\nu/H+2R_{min}
 +2(\eta+\sigma_n+\varepsilon_{383})X_q+2(C_{338}+F_{min})W.
\]
全式乘Λ=128/119。C=2时新增根阶；C=log(n+2)时新增根阶对数费用，不更改原h/t、目标容量或模板价。不存在新增X费用，仍以η=κ/(6Λ)、ε383=κ/(4Λ)、σ≤η/2保证本槽系数≤κ（0<κ≤1）。不将该局部κ分配称作全总账吸收。

R_min的支撑必须满足a>C(1−U)，因此U>C/(C+1)；但准确余项仍含a，不能只用U筛选后忽略实际费用。原窗口交通为零，故本次付款完全来自完整f的不同来源见证，不是原当前来源窗重复信用。

仍未付R_min及其全u近满联合捕获/真实交通预算；原H入口和选择、soft/crossing/entry、重尾宽距低pe极端尺度比与所有补集、初始删除跳跃未来被删来源、全尺度聚合与截断/极限。原physical terminal原子非历史预算，旧square无额外再扣，改计划须重算a和付款比例。


# 第386轮增量：实际秩分支与小端严格过去失败付款

按顺序：R385下锚分数付款；其实际余项中的大端dyadic分位窗；其余T_y(m_v)≤2h出口；最后小端level2h窗。每一步是原同计划交通的不交正分支，不删接收者、不重建J/Z或f。

记L=max(0,floor log2(Jmax/h))，Jmax=A_n/q_-，
\[
 S_{386}={[(C+L)\lambda+B_*](1+\sqrt n)\over q_-}
          +4\lambda h\log_+(Jmax/h).
\]
这是替代上轮C来源价后的总新增来源价，非上轮价再加一遍C项。于是
\[
 B_H≤G_{next}+(\eta+\sigma_n+\varepsilon_{383})X_q+(C_{338}+S_{386})W,
\]
\[
 T_{entrance}≤8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{next}
 +2(\eta+\sigma_n+\varepsilon_{383})X_q+2(C_{338}+S_{386})W.
\]
全式乘Λ=128/119。本轮无新增X吸收、targetcap、h/t或模板费；原κ分配不变，只认证本槽。原严格高past无源时该槽为零，不为除零引入虚构量位。

原同步选择给
\[
 4\lambda h\log_+(Jmax/h)=
 {4\lambda(1+\sqrt n)\over\varepsilon_0q_-}
 \log_+{\varepsilon_0 A_n\over1+\sqrt n}.
\]
固定既有η、ε等吸收参数，C=log(n+2)，ε0^(-1)=O(log^(3/2)(n+2))，所以S386与C338合计O(√n log^(5/2)(n+2))。常数保留旧参数依赖；该来源价不含原H入口等未付槽，不能据此宣布全局上界。

剩余G_next保持原标签、近满U，且u秩regular、小v闭秩>2h并有同来源strictpast>h。没有得到v的高行密度或下一次空间/目标/历史条件，没有未经证明的多跳守恒或免费终端。它及原H入口、soft/crossing/entry、重尾宽距低pe极端尺度与补集、初始删除跳跃未来被删来源、全尺度聚合/截断/极限仍未付。物理末端原子不代替历史预算。
