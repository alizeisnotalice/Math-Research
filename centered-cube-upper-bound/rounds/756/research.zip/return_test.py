"""One landing point for all four mixed pairs. All masses and inclusions are rational."""
from fractions import Fraction as Q
from itertools import product
from math import isqrt, prod


def run(n):
    a = 32 * n
    L = isqrt(n)
    radii = (2, 3, 5, 8)
    signs = ((1, 1, 1, 1), (-1, 1, 1, -1),
             (-1, -1, 1, 1), (-1, -1, -1, -1))
    weights = (Q(1, 8), Q(1, 8), Q(1, 4), Q(1, 2))
    owner_radius = Q(1, a)
    owner_volume = (2 * owner_radius)**n
    price_radius = Q(1, 4 * a)
    price_mass = owner_volume / (4 * L)
    # Use Lebesgue measure on a bounded box containing every parent, increasing
    # its density on the small origin patch to attain the prescribed price mass.
    assert price_mass >= (2 * price_radius)**n
    owner_centers = [tuple(Q(v, 2) for v in pattern) + (Q(0),) * (n-4)
                     for pattern in signs]
    anchors = [tuple(Q(r) - Q(1, 8) if i == k else Q(0) for i in range(n))
               for k, r in enumerate(radii)]
    all_centers = owner_centers + anchors
    all_radii = [1] * 4 + list(radii)
    for i, j in product(range(8), repeat=2):
        if i < j:
            assert max(abs(x-y) for x,y in zip(all_centers[i], all_centers[j])) > Q(all_radii[i]+all_radii[j], a)
    assert sum(weights) == 1
    mixed = tuple(product(range(2), range(2,4)))
    exact = Q(0)
    enlarged = Q(0)
    side_hits = [Q(0)] * 4
    for prob, center in zip(weights, owner_centers):
        assert max(map(abs, center)) + price_radius <= 1
        assert price_mass * prob <= owner_volume / L
        failed = []
        for anchor, radius in zip(anchors, radii):
            assert max(map(abs,anchor)) + price_radius <= radius
            bad = set()
            for axis, (x,c) in enumerate(zip(center, anchor)):
                distance = abs(x-c)
                if distance + owner_radius > radius:
                    assert distance - owner_radius > radius
                    bad.add(axis)
                assert distance + owner_radius <= 3 * radius
            failed.append(bad)
        unions = [failed[i] | failed[j] for i,j in mixed]
        exact += prob * any(len(S) == 0 for S in unions)
        enlarged += prob * any(len(S) <= 1 for S in unions)
        for j, axes in enumerate(unions):
            side_hits[j] += prob * (not axes)
    wrong_independent_union = 1 - prod(1-p for p in side_hits)
    assert (exact, enlarged) == (Q(1,4), Q(1,2))
    assert enlarged == Q(n, 2 * L**2)
    assert exact != wrong_independent_union
    print(f"n={n} same-landing q0={exact} q1={enlarged} four independent landings would give q0={wrong_independent_union}")


if __name__ == "__main__":
    for dimension in (4, 16, 64):
        run(dimension)
