"""Exact four-parent source-partition and nested owner-budget checks for R756."""

import argparse
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
import platform

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def as_arb(x):
    return arb(fmpq(x.numerator, x.denominator))


def shown(x):
    return as_arb(x).str(12)


def cube(n, first, rest, radius):
    return tuple((center-radius, center+radius) for center in (first,)+(rest,)*(n-1))


def intersection(*boxes):
    return tuple((max(p[0] for p in axis), min(p[1] for p in axis))
                 for axis in zip(*boxes))


def volume(box):
    return prod(max(Q(0), right-left) for left, right in box)


def contains(outer, inner):
    return all(a <= c <= d <= b for (a,b),(c,d) in zip(outer,inner))


def expand(box, r):
    return tuple((left-r,right+r) for left,right in box)


def measured(box, prices):
    return sum((mass*volume(intersection(support,box))/volume(support)
                for support,mass in prices), Q(0))


def two_price_interval(n, eta, h, radii, weights):
    # Z,Z' are independent; the two adjacent price boxes have eta width
    # along axis 1, and coincident 2*eta-width intervals on the other axes.
    same_probability = sum(w*w for w in weights)
    mean_first_difference = eta*(same_probability/3+1-same_probability)
    mean_total_difference = mean_first_difference+(n-1)*2*eta/3
    # R755 uses dyadic upper radii R_j with s_j <= R_j <= (1+1/n)*s_j.
    lower = 1+sum(mean_total_difference/(2*h*(1+Q(1,n))*s) for s in radii)
    other_axes = prod((1-eta/(h*s))**(-(n-1)) for s in radii)
    upper_same = other_axes*prod((1-eta/(2*h*s))**(-1) for s in radii)
    upper_different = other_axes*prod((1-eta/(h*s))**(-1) for s in radii)
    upper = same_probability*upper_same+(1-same_probability)*upper_different
    assert 1 < lower < upper < Q(65,64)
    return {"moment_interval_ends": [shown(lower),shown(upper)],
            "same_price_box_probability": str(same_probability),
            "proved_rational_upper_bound": "65/64"}


def tail_certificate(price_mass, load, local_g, universal_g, V):
    far, near = load
    assert 0 < far < near
    assert sum(m*w for m,w in zip(price_mass,load)) == V

    def stop_loss(x):
        return sum(m*max(Q(0),w-x) for m,w in zip(price_mass,load))

    exact_moment = sum(m*w*w for m,w in zip(price_mass,load))
    knots = (Q(0),far,near)
    area = sum((b-a)*(stop_loss(a)+stop_loss(b))/2 for a,b in zip(knots,knots[1:]))
    assert exact_moment == 2*area
    assert exact_moment <= 2*local_g*V <= 2*universal_g*V

    checks = {}
    for name,g in (("four_parent_subfamily",local_g),("universal_upper",universal_g)):
        for x in knots[1:]:
            assert as_arb(stop_loss(x)/V) < (-as_arb(x/g)).exp()
        assert stop_loss(Q(0)) == V
        stationary_checks = 0
        for a,b in zip(knots,knots[1:]):
            # In u=x/G the normalized stop-loss slope on this segment is -r.
            r = g*sum(m for m,w in zip(price_mass,load) if w>a)/V
            if r >= 1:
                continue
            critical = -as_arb(r).log()
            if critical < as_arb(a/g) or critical > as_arb(b/g):
                continue
            active_moment = sum(m*w for m,w in zip(price_mass,load) if w>a)/V
            assert as_arb(r)*(1+critical) > as_arb(active_moment)
            stationary_checks += 1
        checks[name] = {"G": shown(g),"stationary_points_checked": stationary_checks,
                        "moment_over_2GV": shown(exact_moment/(2*g*V))}
    return {
        "W_ext_W_B": [shown(w) for w in load],
        "integral_W_squared_over_V": shown(exact_moment/V),
        "stop_loss_sample_x_over_W_B_and_integral_over_V": [
            [shown(x/near),shown(stop_loss(x)/V)]
            for x in (Q(0),far/2,far,(far+near)/2,near,2*near)
        ],
        "envelope_check": "exp(-x/G) minus normalized piecewise affine stop-loss",
        "G_checks": checks,
    }


def geometry(n, L, c):
    assert L*L == n
    a = 32*n
    h = 1+Q(1,a)
    eta = Q(1,128*n)
    s = (Q(1),Q(5,4),2*(1-Q(1,16*n)),Q(2))
    centers = ((Q(0),1-eta),(Q(1,8),-s[1]+eta),(-Q(1,3),Q(0)),(Q(1),Q(0)))
    parents = tuple(cube(n,x,y,r) for (x,y),r in zip(centers,s))
    owners = tuple(cube(n,x,y,r/a) for (x,y),r in zip(centers,s))
    d, v = (tuple(volume(box) for box in family) for family in (parents,owners))
    V = sum(v)
    assert all(contains(A,E) for A,E in zip(parents,owners))
    assert all(volume(intersection(E1,E2)) == 0 for E1,E2 in combinations(owners,2))
    assert d[3] == 2**(2*n) and d[3]/2 <= d[2] < d[3]
    assert v == tuple(value/a**n for value in d)

    B = intersection(*parents[:2])
    I = intersection(*parents)
    perpendicular = ((-eta,eta),)*(n-1)
    assert I == B == ((Q(-1),Q(1)),)+perpendicular
    P = ((Q(-1),-1+eta),)+perpendicular
    R = ((-1+eta,Q(1)),)+perpendicular
    R_support = ((-1+eta,-1+2*eta),)+perpendicular
    ext = cube(n,Q(3,2),Q(0),Q(1,32))
    assert all(contains(B,block) for block in (P,R))
    assert volume(P)+volume(R) == volume(B) and volume(intersection(P,R)) == 0
    assert contains(R,R_support)
    assert all(volume(intersection(ext,A)) == 0 for A in parents[:2])
    assert all(contains(A,ext) for A in parents[2:])

    largest_window = expand(P,h*s[3])
    budget_scale = volume(largest_window)
    positive_price = c*budget_scale/L
    other_price = budget_scale/(8*L)
    M = positive_price+other_price
    S = d[3]
    assert d[1] <= M < S
    prices = ((P,positive_price),(R_support,other_price),(ext,S-M))
    assert [measured(block,prices) for block in (P,R,B,I)] == [
        positive_price,other_price,M,M
    ]
    m = tuple(measured(A,prices) for A in parents)
    assert m == (M,M,S,S) and all(x >= y for x,y in zip(m,d))

    scale_rows = []
    for t in (2,3):
        ratios = [volume(expand(block,h*s[t]))/(L*mass)
                  for block,mass in ((B,M),(P,positive_price),(R,other_price))]
        assert ratios[0] > 1 and ratios[2] > 1
        assert volume(expand(R_support,h*s[t])) > L*other_price
        assert ratios[1] <= 1 if t == 2 else ratios[1] == 1/c
        scale_rows.append({"target_label": t+1,
                           "volume_over_L_times_actual_price_B_P_R": list(map(shown,ratios)),
                           "P_is_paid": ratios[1] <= 1,
                           "P_is_exact_boundary": ratios[1] == 1})
    small_window = expand(P,h*s[2])
    assert contains(largest_window,small_window)
    assert contains(small_window,owners[2])
    assert not contains(small_window,owners[3])
    assert all(contains(largest_window,E) for E in owners[2:])
    actual_labels = (2,3) if c >= 1 else (2,)
    actual_window = expand(P,h*s[actual_labels[-1]])
    union_volume = sum(v[j] for j in set(actual_labels))
    assert union_volume <= volume(actual_window) <= L*positive_price
    repeated_windows = volume(small_window)+volume(largest_window)
    assert repeated_windows > L*positive_price

    assert volume(I) > 0
    # All nonempty subfamilies share I, so P0(J)=max(d_j:j in J).
    local_g = max(
        sum(v[j] for j in labels)/max(d[j] for j in labels)
        for size in range(1,5) for labels in combinations(range(4),size)
    )
    # A descending disjoint parent subfamily has (2+1/a)-dilated parents
    # covering every owned core. Its original parents are a feasible packing.
    universal_g = (2+Q(1,a))**n
    assert V/S <= local_g <= universal_g
    density_ratio = M/volume(I)
    density_comparison = universal_g*L*max(L,universal_g/(4096*16))
    assert density_ratio > density_comparison
    w = tuple(z/mass for z,mass in zip(v,m))
    lam = tuple(Q(i+1,4)*w[i]/universal_g for i in range(4))
    assert sum(lam) <= 1 and all(
        lam_i*m_i <= v_i/universal_g for lam_i,m_i,v_i in zip(lam,m,v)
    )

    # The four cross pairs use the same I on the price measure. Keep both
    # original source coefficients and both original receiving denominators.
    to_target = sum(lam[k]*w[t]*M for k,t in product((0,1),(2,3)))
    to_anchor = sum(lam[t]*w[k]*M for k,t in product((0,1),(2,3)))
    paid_ratio = positive_price/M
    assert 0 < to_target < to_anchor
    for forward in (False,True):
        selected = Q(0)
        for k,t in product((0,1),(2,3)):
            i,j = (k,t) if forward else (t,k)
            selected += lam[i]*w[j]*measured(intersection(P,parents[i],parents[j]),prices)
        assert selected == paid_ratio*(to_target if forward else to_anchor)

    selected_fractions = []
    for forward,total in ((True,to_target),(False,to_anchor)):
        selected = Q(0)
        for k,t in product((0,1),actual_labels):
            i,j = (k,t) if forward else (t,k)
            selected += lam[i]*w[j]*measured(intersection(P,parents[i],parents[j]),prices)
        assert 0 < selected <= paid_ratio*total
        selected_fractions.append(selected/total)

    return {
        "n": n, "a": a, "L": L, "c": str(c), "eta": str(eta),
        "half_sides": list(map(str,s)), "m_over_d": [shown(x/y) for x,y in zip(m,d)],
        "mu_B_over_total": shown(M/S), "mu_P_over_mu_B": str(paid_ratio),
        "density_mu_I_over_abs_I": shown(density_ratio),
        "density_reference_with_universal_G_upper": shown(density_comparison),
        "independent_two_price_BQ": two_price_interval(
            n,eta,h,s[1:],(positive_price/M,other_price/M)
        ),
        "per_scale": scale_rows,
        "merged_paid_owner_labels": [j+1 for j in actual_labels],
        "merged_owner_volume_over_one_price_cap": shown(union_volume/(L*positive_price)),
        "merged_envelope_over_one_price_cap": shown(volume(actual_window)/(L*positive_price)),
        "sum_of_both_envelopes_over_one_price_cap": shown(repeated_windows/(L*positive_price)),
        "raw_cross_flux_to_targets_and_anchors_over_V": [shown(to_target/V),shown(to_anchor/V)],
        "raw_cross_flux_ratio_kept_by_P_before_scale_gate": str(paid_ratio),
        "raw_cross_flux_ratio_kept_after_scale_gate_to_targets_and_anchors": list(map(shown,selected_fractions)),
        "original_F_on_B": shown(sum(lam)),
        "tail": tail_certificate((S-M,M),(sum(w[2:]),sum(w)),local_g,universal_g,V),
    }


def hall_certificate():
    """Integer Hall checks using genuine one-dimensional prices and full cores."""
    a, L = 32, 2
    demands = (2,4,4,3,1)
    cell_centers = tuple(map(Q,(0,60,80,140,350)))
    source_cells = tuple(cube(1,x,Q(0),Q(1,4)) for x in cell_centers)
    slot_centers = tuple(map(Q,(70,-20,14,8,143,159)))
    capacity = tuple(range(1,len(slot_centers)+1))
    radii = tuple(Q(a*v,2) for v in capacity)
    parents = tuple(cube(1,x,Q(0),s) for x,s in zip(slot_centers,radii))
    owners = tuple(cube(1,x,Q(0),s/a) for x,s in zip(slot_centers,radii))
    assert all(contains(A,E) for A,E in zip(parents,owners))
    assert all(volume(intersection(X,Y)) == 0 for X,Y in combinations(owners,2))
    assert all(volume(intersection(X,Y)) == 0 for X,Y in combinations(source_cells,2))
    assert tuple(volume(E) for E in owners) == capacity
    masses = tuple(Q(d,L) for d in demands)
    # Auxiliary prices lie outside the five-cell Hall source mask.
    reservoir = tuple(cube(1,x,Q(0),Q(1,8)) for x in slot_centers)
    assert all(volume(intersection(X,Y)) == 0 for X,Y in product(reservoir,source_cells))
    prices = tuple(zip(source_cells,masses))+tuple(zip(reservoir,map(volume,parents)))
    assert tuple(L*measured(cell,prices) for cell in source_cells) == demands
    assert all(measured(A,prices) >= volume(A) for A in parents)

    touch = []
    for A in parents:
        touched = frozenset(j for j,cell in enumerate(source_cells)
                            if volume(intersection(A,cell)) > 0)
        assert all(contains(A,source_cells[j]) for j in touched)
        touch.append(touched)
    assert [tuple(sorted(T)) for T in touch] == [(1,2),(0,),(0,1),(0,1),(2,3),(2,3)]

    def stages_of_subsets(labels):
        return [frozenset(s) for k in range(len(labels)+1) for s in combinations(labels,k)]

    all_cells = frozenset(range(len(source_cells)))
    subsets = stages_of_subsets(sorted(all_cells))
    previous = all_cells
    prior_available = set()
    rows = []
    # These independent integer allocations witness use of the initially blocked slot.
    proposed = {4: ((0,1,2),(1,2,3),(1,3,1)),
                6: ((2,0,1),(2,4,3),(3,4,2),(3,5,1))}
    for layer in range(len(parents)+1):
        scores = {
            P: sum(demands[j] for j in P)-sum(capacity[t] for t in range(layer) if P & touch[t])
            for P in subsets
        }
        score_max = max(scores.values())
        maximizers = [P for P in subsets if scores[P] == score_max]
        maximal = frozenset().union(*maximizers)
        assert maximal in maximizers and maximal <= previous
        removed = previous-maximal
        available = {
            t for t in range(layer) if touch[t] & removed and not touch[t] & maximal
        }
        assert not available & prior_available
        prior_available.update(available)
        certificates = []
        for X in stages_of_subsets(sorted(removed)):
            demand = sum(demands[j] for j in X)
            supply = sum(capacity[t] for t in available if X & touch[t])
            assert demand <= supply
            assert supply-demand == score_max-scores[maximal | X]
            certificates.append([sorted(X),demand,supply])
        flow = proposed.get(layer,())
        assert all(j in removed and t in available and j in touch[t] and v > 0 for j,t,v in flow)
        assert all(sum(v for col,t,v in flow if col == j) == demands[j] for j in removed)
        assert all(sum(v for j,row,v in flow if row == t) <= capacity[t] for t in available)
        rows.append({
            "layer": layer, "inclusion_largest_maximizer": sorted(maximal),
            "maximizer_count": len(maximizers), "score": score_max,
            "departed_cells": sorted(removed), "eligible_slots": sorted(available),
            "Hall_subsets_cell_indices_demand_capacity": certificates,
            "realized_integer_flow_cell_slot_units": flow,
        })
        previous = maximal
    assert [row["layer"] for row in rows if row["departed_cells"]] == [4,6]
    assert rows[2]["maximizer_count"] > 1 and rows[3]["maximizer_count"] > 1
    assert 0 not in rows[4]["eligible_slots"] and 0 in rows[6]["eligible_slots"]
    assert rows[-1]["inclusion_largest_maximizer"] == [4]
    return {
        "scope": "Independent 1D finite Hall certificate with a fixed five-cell source mask.",
        "cell_and_slot_indices": "zero based",
        "a": a, "L": L, "cell_centers": list(map(str,cell_centers)), "cell_radius": "1/4",
        "L_mu_required_units": demands, "parent_centers": list(map(str,slot_centers)),
        "parent_half_sides": list(map(str,radii)), "owner_slot_capacities": capacity,
        "touch": [sorted(T) for T in touch], "subsets_evaluated_each_layer": len(subsets),
        "layers": rows,
    }


def report():
    return {
        "python": platform.python_version(), "python_flint": flint_version,
        "arb_bits": ctx.prec, "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "reproduce": ["python","-B","verify.py","--check","verify.json"],
        "scope": (
            "Finite preterminal example with ordinary absolutely continuous price. "
            "M_Q uses the all-four unmasked price on I, p_Q=1. "
            "No terminal F threshold or scale separation is assumed. "
            "The exact subfamily G certificate is local. The universal benchmark is an upper bound."
        ),
        "nested_Hall": hall_certificate(),
        "geometry": [geometry(n,L,c) for n,L in ((4,2),(16,4),(64,8))
                     for c in (Q(127,128),Q(1),Q(129,128))],
    }


def main():
    cli = argparse.ArgumentParser()
    action = cli.add_mutually_exclusive_group(required=True)
    action.add_argument("--out",type=Path)
    action.add_argument("--check",type=Path)
    args = cli.parse_args()
    data = (json.dumps(report(),indent=2,sort_keys=True)+"\n").encode()
    if args.out is not None:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes() == data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")


if __name__ == "__main__":
    main()

