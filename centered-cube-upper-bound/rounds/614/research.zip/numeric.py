"""R614 exact high-first-block/whole-second-block shell envelope cost."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import json,time,sys,platform,resource,hashlib
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
r,u=sp.symbols('r u',positive=True)

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def tail_poly(size,threshold):
 # P[Bin(size,1-u)>=threshold], polynomial in u, exact coefficients.
 return sp.Poly(sp.expand(sum((sp.binomial(size,j)*(1-u)**j*u**(size-j) for j in range(threshold,size+1)),sp.Integer(0))),u)
rows=[]
for m in [1,2,4,8,16,32,64]:
 cutoff=m//2
 V=sp.Poly(sp.expand(r**m*sum((sp.binomial(m,j)*(r-1)**j for j in range(cutoff+1,m+1)),sp.Integer(0))),r)
 derivative=V.diff();rational=Q(0);logcoef=Q(0)
 for (power,),coeff in derivative.terms():
  exponent=power-2*m
  if exponent==-1:logcoef+=Q(coeff)
  else:rational+=Q(coeff)*Q(Q(2)**(exponent+1)-1,exponent+1)
 # Independent binomial-tail construction in u=1/r, dr/r=-du/u.
 tails=tail_poly(m-1,cutoff)+tail_poly(m,cutoff+1)
 independent_rational=Q(0);independent_log=Q(0)
 for (power,),coeff in tails.terms():
  if power==0:independent_log+=m*Q(coeff)
  else:independent_rational+=m*Q(coeff)*Q(1-Q(1,2)**power,power)
 assert rational==independent_rational and logcoef==independent_log==2*m
 # The root's predicted integrand equals the exact V'/r^(2m), not just its integral.
 difference=sp.Poly(sp.expand(derivative.as_expr()-m*r**(2*m-1)*tails.as_expr().subs(u,1/r)),r)
 assert difference.is_zero
 J=A(rational)+A(logcoef)*arb(2).log();assert J>0
 upper=2*m*arb(2).log();assert J<upper
 if m==1:assert rational==Q(-1,2) and logcoef==2
 if m==2:assert rational==Q(-9,4) and logcoef==4
 rows.append({'m':m,'n':2*m,'high_layer_threshold':'k>floor(m/2)='+str(cutoff),'V_degree':V.degree(),
  'J_exact':{'rational_part':str(rational),'log2_coefficient':str(logcoef)},'J':iv(J),'J_over_sqrt_m':iv(J/A(m).sqrt()),'J_over_m':iv(J/m),
  'independent_u_tail_integral_exact':{'rational_part':str(independent_rational),'log2_coefficient':str(independent_log)},
  'integrand_polynomial_residual':'0','two_integrals_exact_coefficient_residual':['0','0'],'elementary_upper_2m_log2':iv(upper),'positive_strictly_below_elementary_upper':True})
out={'status':'PASS_7_EXACT_HIGHBLOCK_COMPLEMENT_COSTS_AND_TAIL_FORMULA','definition':'V(t)=(1+t)^m sum_(k>floor(m/2)) binom(m,k)t^k; J_m=integral_0^1 (1+t)^(-2m)Vprime(t)dt.',
 'confirmed_tail_formula':'J_m=m integral_1^2 [P(Bin(m-1,p)>=floor(m/2))+P(Bin(m,p)>floor(m/2))]dr/r, p=1-1/r. The m=1 Bin(0,p)>=0 term is exactly1.',
 'derivation':'Differentiate V: derivative of the whole-second-block factor gives the Bin(m,p)>cutoff term; k binom(m,k)=m binom(m-1,k-1) gives Bin(m-1,p)>=cutoff. Both carry m/r after normalizing.',
 'methods':'Path1 expands V(r-1)=r^m sum binom(m,k)(r-1)^k and integrates Vprime/r^(2m) exactly. Path2 independently expands the two binomial tails in u=1/r and integrates m*tail_poly(u)/u on[1/2,1]. Both yield exact rational+integer*log2, with log coefficient2m. Exact integrand polynomial identity also checked.',
 'rows':rows,'error_policy':'SymPy integer polynomial expansion and Fraction integration are exact. Arb256 encloses rational conversion, log2 and sqrt normalization; no cancellation-prone floating integration, sampling, optimization or scan. No quadrature needed because both integration paths have exact antiderivatives.',
 'scope':'These are scalar high-first-block tensor whole-second-block envelope costs only. No assertion of a D budget, synchronous tensor estimate, operator inequality, asymptotic order inferred from numbers, or general weak-type upper bound.',
 'versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r614_tail.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'m':z['m'],'J':z['J']['display'],'J_over_sqrt_m':z['J_over_sqrt_m']['display']} for z in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
