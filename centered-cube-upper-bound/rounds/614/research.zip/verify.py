"""Independent integration-by-parts coefficients and rational log(2) certificates."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json,sys
import sympy as s
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('RESULTS.json')
j=json.loads(path.read_text())
N=200
loglo=2*sum((F(1,3**(2*i+1)*(2*i+1)) for i in range(N)),F(0))
loghi=loglo+2*F(1,3**(2*N+1)*(2*N+1))/(1-F(1,9))
for row in j['rows']:
 m=row['m'];a=[0]*(m+1)
 for k in range(m//2+1,m+1):
  for i in range(k+1):a[m-k+i]+=comb(m,k)*comb(k,i)*(-1)**i
 endpoint=F(sum(comb(m,k) for k in range(m//2+1,m+1)),2**m)
 rational=endpoint+2*m*sum((F(a[i],i)*(1-F(1,2**i)) for i in range(1,m+1)),F(0))
 logcoef=2*m*a[0]
 assert rational==F(row['J_exact']['rational_part'])
 assert logcoef==F(row['J_exact']['log2_coefficient'])
 assert F(row['J']['lo_exact'])<=rational+logcoef*loglo<=rational+logcoef*loghi<=F(row['J']['hi_exact'])
x,A,u=s.symbols('x A u',positive=True)
theta=x/(x+1)
rhs=(s.sqrt(2)*u+A)/(theta*s.sqrt(2))+4/((1-theta)*s.sqrt(2))
expected=(x+1)/x*u+(A/s.sqrt(2))*(x+1)/x+2*s.sqrt(2)*(x+1)
assert s.simplify(rhs-expected)==0
assert s.simplify(expected/(x+1)-(u/x+A/(s.sqrt(2)*x)+2*s.sqrt(2)))==0
print(json.dumps({'third_integral_formula_rows':len(j['rows']),'rational_atanh_log2_terms':N,'all_rational_intervals_inside_Arb_displays':True,'conditional_recurrence_residuals':['0','0'],'scope':'scalar integrals and conditional algebra, not general upper bound'}))
