from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from itertools import combinations
from math import factorial,comb
from pathlib import Path
import json

def dc(x):return D(x.numerator)/D(x.denominator) if isinstance(x,F) else D(x)
def tail(q,k):
 if not q:return D(0)
 term=(-q).exp()
 for j in range(1,k+1):term*=q/j
 total=term;j=k
 while term>total*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;total+=term
 return total

def fraction_text(v):
 with localcontext() as ctx:
  ctx.prec=70;return format(dc(v),'.16g')

def gamma_intervals():
 rows=[]
 for z in (F(1,100),F(1,4),F(1),F(4),F(16)):
  for r in (2,3,5,9,32):
   previous=None;checks=[]
   for N in (48,96,160):
    # Even Taylor polynomial of exp(-t) is an upper bound on t>=0;
    # the next odd polynomial is a lower bound. Integrate exactly.
    upper=sum(((-1)**j*z**(r-1+j)/F((r-1+j)*factorial(j)) for j in range(N+1)),F(0))/factorial(r-2)
    lower=upper-z**(r+N)/F((r+N)*factorial(N+1)*factorial(r-2))
    elo=sum(((-z)**j/F(factorial(j)) for j in range(N+2)),F(0))
    ehi=elo+z**(N+1)/F(factorial(N+1))
    poly=sum((z**j/F(factorial(j)) for j in range(r-1)),F(0))
    lo=max(F(0),lower,1-ehi*poly);hi=min(F(1),upper,1-elo*poly)
    assert 0<=lo<=hi<=1
    if previous:assert lo>=previous[0] and hi<=previous[1]
    previous=(lo,hi);checks.append(dict(N=N,positive_lower=lo>0,relative_width=fraction_text((hi-lo)/lo) if lo else None))
   assert lo>0 and (hi-lo)/lo<F(1,10**30)
   rows.append(dict(z=str(z),r=r,refinements=checks))
 return rows

def geometry():
 rows=[]
 for n in (1,2,4,8):
  for shift in (1,3,7):
   x=[F(shift+j+1,20+3*j) for j in range(n)];prod=F(1)
   for v in x:prod*=v
   # Each elementary symmetric mean is >= the matching power
   # of the geometric mean: raise to n to avoid irrational roots.
   for k in range(1,n+1):
    e=sum((__import__('functools').reduce(lambda a,b:a*b,c,F(1)) for c in combinations(x,k)),F(0))
    assert (e/F(comb(n,k)))**n>=prod**k
   expansion=F(1)
   for v in x:expansion*=1+v
   rows.append(dict(n=n,shift=shift,cell_volume=str(prod),expansion=str(expansion),symmetric_inequalities=n))
 return rows

def decimals(precision):
 with localcontext() as ctx:
  ctx.prec=precision;point=[];grids=[];lower=[];hybrid=[]
  for A in (D(2),D(16),D('1e6')):
   for z in (D('.01'),D('.25'),D(1),D(4),D(16)):
    for r in (2,3,5,9):
     l=r-1;gamma=A*tail(z,l);tuples=z**l/D(factorial(l));best=min(gamma,tuples)
     assert best<=gamma and best<=tuples
     hybrid.append(dict(A=str(A),z=str(z),r=r,gamma_factor=format(gamma,'.16g'),tuple_factor=format(tuples,'.16g'),choice='tuple' if tuples<gamma else 'gamma'))
  assert {r['choice'] for r in hybrid}=={'tuple','gamma'}
  for n in (1,2,8,64):
   B=D(2)**n
   for z in (D('.01'),D(1),D(16)):
    for r in (2,3,5):
     m=D(8);qsmall=z/B
     actual=m/z*(B*tail(qsmall,r)+z/D(r-1)*(tail(z,r-1)-tail(qsmall,r-1)))
     upper=m/D(r-1)*tail(z,r-1)
     assert 0<=actual<=upper*(1+D(10)**(-precision+12))
     point.append(dict(n=n,z=str(z),r=r,lambda_expected_volume_per_mass=format(actual,'.16g'),gamma_bound_per_mass=format(upper,'.16g')))
  for n in (1,2,4):
   prev=None
   for J in (2,4,8,16,32):
    m=D(4);A=(1+D(1)/J)**n;z=m/(D(J)**n);bound=A*m*tail(z,1)
    assert bound<=A*m*z
    if prev is not None:assert bound<prev
    prev=bound;grids.append(dict(n=n,J=J,collision_bound=format(bound,'.16g')))
  for e in (24,32,40,64,96):
   n=2**e;nd=D(n);cstar=D(2).sqrt()/10
   K=64*int((cstar*nd.sqrt()/(64*(8*nd.ln()).sqrt())+D('.5')).to_integral_value(rounding='ROUND_FLOOR'))
   assert K>0
   u=cstar*nd.sqrt()/D(K);h=u*u/2-2;loglam=h-D(2).ln();logm=2*nd.ln()
   # The retained lower theorem is asymptotic; these are only arithmetic
   # checks of its parameter formulas, not certifications of its n0.
   micro=1+2*logm-loglam+nd*(4*u.ln()-nd.ln())
   assert micro<0
   values=[]
   for typ,param in [('polynomial',1),('polynomial',4),('polynomial',16),('subexponential',D('.5')),('subexponential',D('.75'))]:
    logP=D(param)*nd.ln() if typ=='polynomial' else nd**param
    side=(logP/nd).exp()-1
    logbound=logP+2*logm-loglam+nd*(4*u.ln()+side.ln())
    values.append(dict(type=typ,parameter=str(param),log10_collision_bound=format(logbound/D(10).ln(),'.16g')))
   lower.append(dict(n_power_two=e,K=K,u=format(u,'.16g'),micro_log10_bound=format(micro/D(10).ln(),'.16g'),anisotropic=values))
  # All final enlarged parameters pay vanishing collision even for
  # exp(n^(.75)) expansion; no finite-dimensional lower event is simulated.
  assert all(D(v['log10_collision_bound'])<0 for v in lower[-1]['anisotropic'])
  return dict(point_cells=point,nonatomic_grids=grids,lower_model_parameters=lower,hybrid=hybrid)


def span_kernel_checks():
 rows=[]
 for n in (1,2,4,8):
  for r in (2,3,5):
   for kind in range(4):
    spans=[F(0) if kind==0 else F(1,4) if kind==1 else F(1+j%2*3,5) if kind==2 else (F(5,2) if j==0 else F(0)) for j in range(n)]
    # Realizable by two opposite corner points and r-2 midpoint points.
    lo=max([F(1)]+spans);b=F(2)
    if lo>=b:value=F(0)
    else:
     coeff=[F(1)]
     for d in spans:
      nxt=[F(0)]*(len(coeff)+1)
      for j,c in enumerate(coeff):nxt[j]-=d*c;nxt[j+1]+=c
      coeff=nxt
     integral=sum((c*(b**(j-n*r)-lo**(j-n*r))/F(j-n*r) for j,c in enumerate(coeff)),F(0))
     terminal=F(1)
     for d in spans:terminal*=b-d
     value=terminal/(factorial(r)*b**(n*r))+F(n,factorial(r-1))*integral
    upper=F(1,(r-1)*factorial(r-1))
    assert 0<=value<=upper
    if kind==3:assert value==0
    if kind==0:
     exact=F(1,factorial(r))*b**(-n*(r-1))+F(1,(r-1)*factorial(r-1))*(1-b**(-n*(r-1)))
     assert value==exact
    rows.append(dict(n=n,r=r,span_family=kind,integrated_tuple_kernel=str(value),mass_only_upper=str(upper)))
 return rows

if __name__=='__main__':
 g=gamma_intervals();a=geometry();sp=span_kernel_checks();p=decimals(70);assert p==decimals(110)
 result=dict(status='PASS; general square-root upper bound unproved',gamma=g,anisotropic_geometry=a,span_kernel=sp,**p,notes=['Gamma enclosures use exact rational Taylor integral/remainder signs, three refinements.','Decimal70/110 repeated; displayed 16-digit agreement is not interval certification.','Lower-model coefficients are arithmetic checks only. The accepted lower theorem has an unspecified sufficiently-large-n threshold.','No lower extremizer or Poisson spatial volume was numerically simulated.','No random sampling or seeds.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(g),'Gamma cases x3 refinements;',len(a),'anisotropic boxes;',len(p['point_cells']),'point-cell budgets;',len(p['nonatomic_grids']),'refinements;',len(p['lower_model_parameters']),'lower parameter vectors;',len(p['hybrid']),'hybrid comparisons;',len(sp),'span kernels')
