#!/usr/bin/env python3
"""Exact source-to-Lebesgue Hall cuts and certificates for the joint retention LP."""
import argparse
from collections import defaultdict, deque
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform

import numpy as np
import scipy
from scipy.optimize import linprog

ZERO=F(0)
ONE=F(1)
CUTS=tuple(F(1,2**k) for k in (16,12,8,5,3,1))
CELL_THRESHOLDS=(F(1,128),F(1,32),F(1,8),F(1,2))


def sumq(values):
    return sum(values,ZERO)


def transport(source, required, target, demand):
    """A rational augmenting-path flow, a saturating cut and outside transport."""
    starts={("s",i): demand*source[i] for i in source}
    rights={("d",j): target[j] for j in target if target[j]>0}
    src=("start",); snk=("end",)
    adj=defaultdict(list); residual=defaultdict(F); initial={}
    def edge(v,w,cap):
        adj[v].append(w); adj[w].append(v)
        residual[v,w]=cap; initial[v,w]=cap
    for v,cap in starts.items(): edge(src,v,cap)
    for v,cap in rights.items(): edge(v,snk,cap)
    inf=ONE+sumq(starts.values())+sumq(rights.values())
    for kind,i in starts:
        for kk,j in rights:
            if required[i] & j == required[i]:
                edge((kind,i),(kk,j),inf)
    value=ZERO
    while True:
        parent={src:None}
        q=deque([src])
        while q and snk not in parent:
            v=q.popleft()
            for w in adj[v]:
                if w not in parent and residual[v,w]>0:
                    parent[w]=v
                    q.append(w)
        if snk not in parent: break
        chain=[]; x=snk
        while x!=src:
            v=parent[x]; chain.append((v,x)); x=v
        inc=min(residual[v,w] for v,w in chain)
        for v,w in chain:
            residual[v,w]-=inc; residual[w,v]+=inc
        value+=inc
    bad={i for _,i in starts if ("s",i) in parent}
    union={j for _,j in rights if any((required[i]&j)==required[i] for i in bad)}
    budget=sumq(target[j] for j in union)
    bad_mass=sumq(source[i] for i in bad)
    assert value==demand*(sumq(source.values())-bad_mass)+budget
    assert (budget<demand*bad_mass if bad else budget==0)
    flows={}
    for i in source:
        for j in target:
            k=(("s",i),("d",j))
            if k not in initial: continue
            v=initial[k]-residual[k]
            if v: flows[i,j]=v
    assert all(sumq(v for (a,b),v in flows.items() if b==j)<=target[j] for j in target)
    for i in source:
        row=sumq(v for (a,b),v in flows.items() if a==i)
        assert row<=demand*source[i]
        if i not in bad:
            assert row==demand*source[i]
            assert all(j not in union for a,j in flows if a==i)
    return value,bad,union,bad_mass,budget,flows


def geometry(stage, law):
    mass={c["mask"]:F(c["mass"]) for c in stage["cells"] if F(c["mass"])>0}
    target={c["mask"]:F(c["volume"]) for c in stage["expanded_target_cells"] if c["mask"] and F(c["volume"])>0}
    bits={p["id"]:p["bit"] for p in stage["parents"]}
    pairs=defaultdict(lambda:defaultdict(F))
    req=defaultdict(dict); public={}
    for root in stage["roots_"+law]:
        t,u,g=root["t"],root["u"],root["g"]
        coeff=F(root["coefficient"])
        calc=ZERO
        for z,q in product(root["z_masks"],root["q_masks"]):
            amount=coeff*mass[z]*mass[q]
            calc+=amount
            pairs[t][z,q]+=amount
            for atom,small in ((z,u),(q,g)):
                needed=bits[t]|bits[small]
                assert atom&needed==needed
                req[t][atom]=req[t].get(atom,0)|needed
                public[atom]=public.get(atom,0)|needed
        assert calc==F(root["root_mass"])
    assert all(d==dict(((q,z),v) for (z,q),v in d.items()) for d in pairs.values())
    return mass,target,dict(pairs),dict(req),public


def cut_record(active_req,mass,targets,theta):
    source={i:mass[i] for i in active_req}
    val,bad,union,s,b,flows=transport(source,active_req,targets,theta)
    cert=dict(bad_source=sorted(bad),target_union=sorted(union),source_mass=str(s),
              target_volume=str(b),deficit=str(theta*s-b),transport_value=str(val),
              outside_full_witness=[[i,j,str(v)] for (i,j),v in sorted(flows.items()) if i not in bad])
    return bad,cert


def rank_support(weights,source,req,target):
    active=sorted([i for i in source if weights.get(i,0)>0],
                  key=lambda i:(-weights[i]/source[i],i))
    values=[weights[i]/source[i] for i in active]+[ZERO]
    total=ZERO; terms=[]
    for j in range(len(active)):
        if values[j]==values[j+1]: continue
        subset={k:source[k] for k in active[:j+1]}
        rank,bad,_,_,_,_=transport(subset,req,target,ONE)
        delta=values[j]-values[j+1]; total+=delta*rank
        terms.append([active[:j+1],str(delta),str(rank),sorted(bad)])
    return total,terms


def quantize(value):
    return min(ONE,max(ZERO,F(float(value)).limit_denominator(10**11)))


def joint_opt(pairs,req,mass,target,known=None):
    source={i:mass[i] for i in req}
    feasible=[(i,j) for i in sorted(req) for j in sorted(target) if req[i]&j==req[i]]
    owners=sorted(set(j for i,j in feasible))
    witness_scale={(i,j):min(source[i],target[j]) for i,j in feasible}
    edges=sorted(pairs)
    total=sumq(pairs.values())
    if not total: raise ValueError("empty input")
    weights={k:x/total for k,x in pairs.items()}
    rows=sorted(source)
    # Symmetric original joint law and identical spaces: averaging swapped plans
    # preserves feasibility and can only increase the concave min objective.
    assert all(weights.get((j,i),ZERO)==w for (i,j),w in weights.items())
    pairs_unordered=[(i,j) for i,j in edges if i<=j]
    undirected={(i,j):weights[i,j]*(1 if i==j else 2) for i,j in pairs_unordered}
    if known is None:
        fi={e:k for k,e in enumerate(feasible)}
        yi={e:len(fi)+k for k,e in enumerate(pairs_unordered)}
        role={e:k for k,e in enumerate(rows)}
        dest={e:len(rows)+k for k,e in enumerate(owners)}
        offset=len(role)+len(dest)
        A=np.zeros((offset+2*len(yi),len(fi)+len(yi)))
        bound=np.zeros(A.shape[0]); bound[:offset]=1
        for i,j in feasible:
            k=fi[i,j]; scale=witness_scale[i,j]
            A[role[i],k]=float(scale/source[i]); A[dest[j],k]=float(scale/target[j])
        for e in yi:
            for side,i in enumerate(e):
                row=offset+2*(yi[e]-len(fi))+side
                A[row,yi[e]]=1
                for a,b in feasible:
                    if a==i: A[row,fi[a,b]]=-float(witness_scale[a,b]/source[a])
        cost=np.zeros(A.shape[1])
        for e,k in yi.items(): cost[k]=-float(undirected[e])
        result=linprog(cost,A_ub=A,b_ub=bound,bounds=(0,None),method="highs",
                       options={"primal_feasibility_tolerance":1e-10,"dual_feasibility_tolerance":1e-10})
        if not result.success: raise ValueError(result.message)
        flow={e:witness_scale[e]*quantize(result.x[k]) for e,k in fi.items()}
        load=[ONE]+[sumq(x for (a,b),x in flow.items() if a==i)/source[i] for i in rows]
        load += [sumq(x for (a,b),x in flow.items() if b==j)/target[j] for j in owners]
        shrink=max(load); flow={e:x/shrink for e,x in flow.items() if x}
        orientation={}
        for pos,e in enumerate(pairs_unordered):
            x,y=(-result.ineqlin.marginals[offset+2*pos+j] for j in (0,1))
            orientation[e]=quantize(x/(x+y)) if x+y>0 else F(1,2)
    else:
        flow={(i,j):F(x) for i,j,x in known["primal_flow"]}
        orientation={(i,j):F(x) for i,j,x in known["dual_orientation"]}
    assert set(flow)<=set(feasible) and min(flow.values(),default=ZERO)>=0
    assert set(orientation)==set(undirected) and all(0<=v<=1 for v in orientation.values())
    accept={i:sumq(x for (a,b),x in flow.items() if a==i)/source[i] for i in rows}
    assert max(accept.values())<=1
    assert all(sumq(x for (a,b),x in flow.items() if b==j)<=target[j] for j in owners)
    lower=sumq(w*min(accept[i],accept[j]) for (i,j),w in undirected.items())
    independent=sumq(w*accept[i]*accept[j] for (i,j),w in undirected.items())
    loading=defaultdict(F)
    for (i,j),v in undirected.items():
        p=orientation[i,j]; loading[i]+=v*p; loading[j]+=v*(1-p)
    upper,rank_cert=rank_support(loading,source,req,target)
    assert 0<=independent<=lower<=upper
    return dict(upper=str(upper),lower=str(lower),gap=str(upper-lower),
                independent_with_same_primal=str(independent),primal_flow=[[i,j,str(x)] for (i,j),x in sorted(flow.items())],
                dual_orientation=[[i,j,str(x)] for (i,j),x in sorted(orientation.items())],
                rank_cut_certificate=rank_cert,original_mass=str(total))


def check_stage(stage,old=None):
    output=[]
    for pos,law in enumerate(("all","cross")):
        mass,target,pairs,per_t,global_req=geometry(stage,law)
        raw=sumq(sumq(d.values()) for d in pairs.values())
        runs=[]
        for theta in CUTS:
            bad,global_cut=cut_record(global_req,mass,target,theta)
            results={}; paid=by_g=by_t=ZERO; fine_raw=[ZERO,ZERO]
            for t,req in per_t.items():
                local,cert=cut_record(req,mass,target,theta)
                results[t]=cert
                for (i,j),w in pairs[t].items():
                    g=i not in bad and j not in bad
                    l=i not in local and j not in local
                    mix=(i not in bad or i not in local) and (j not in bad or j not in local)
                    paid+=w if mix else 0; by_g+=w if g else 0; by_t+=w if l else 0
                    fine_raw[0]+=w if mix and not(g or l) else 0
                    fine_raw[1]+=w if (not mix) and ((i in bad and i in local) or (j in bad and j in local)) else 0
            assert fine_raw[1]+paid==raw
            runs.append(dict(theta=str(theta),global_cut=global_cut,per_middle_cuts=results,
                             jointly_served_fraction=str(paid/raw),global_only=str(by_g/raw),local_only=str(by_t/raw),
                             requires_mixed_ports=str(fine_raw[0]/raw)))
        projected={t:joint_opt(pairs[t],req,mass,target,None if old is None else old[pos]["per_middle_LP"][t])
                   for t,req in per_t.items()}
        avg=lambda k:sumq(F(p[k])*F(p["original_mass"]) for p in projected.values())/raw
        output.append(dict(law=law,thresholds=runs,per_middle_LP=projected,mother=str(raw),
                           joint_lower=str(avg("lower")),joint_upper=str(avg("upper")),exact_gap=str(avg("gap")),
                           independent_same_primal=str(avg("independent_with_same_primal"))))
    return output


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data",type=Path,required=True)
    gp=p.add_mutually_exclusive_group(required=True)
    gp.add_argument("--output",type=Path); gp.add_argument("--check",type=Path)
    args=p.parse_args()
    src=json.loads(args.data.read_text())
    saved=json.loads(args.check.read_text()) if args.check else None
    stages=[]
    for pos,stage in enumerate(src["stages"]):
        laws=check_stage(stage,None if saved is None else saved["stages"][pos]["laws"])
        stages.append(dict(dimension=stage["dimension"],stage=stage["stage"],laws=laws))
        for d in laws:
            print(stage["dimension"],d["law"],"qLP",float(F(d["joint_lower"])),"ind",float(F(d["independent_same_primal"])),
                  "gap",float(F(d["exact_gap"])),"cuts",[round(float(F(x["jointly_served_fraction"])),5) for x in d["thresholds"]])
    payload=dict(runtime=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
                              architecture=platform.machine()),stages=stages,
                 scope="Fractions certify physical membership transport of the finite calibrated comb inputs only. Conditional rates are constant within each input incidence cell, preserving all active old labels for the middle. The LP is optimized only within this model.",
                 evidence="HiGHS proposes a nonnegative primal plan and an edge orientation. Exact rescaling and rational prefix max-flow/min-cut prove the interval. Replay checks the saved rational witnesses without consulting the floating optimizer.")
    txt=json.dumps(payload,sort_keys=True,indent=2)+"\n"
    if args.output: args.output.write_text(txt)
    else: assert txt==args.check.read_text()


if __name__=="__main__":
    main()
