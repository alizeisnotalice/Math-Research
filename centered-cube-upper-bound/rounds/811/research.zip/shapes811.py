#!/usr/bin/env python3
"""Equal-volume directional expansion on the true R811 comb Hall contracts."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from math import prod
from pathlib import Path
import platform

from comb811 import geometric_cells, verify_by_intersection_inversion, volume
from hall811 import geometry, sumq, transport

THRESHOLDS={
    2:(F(1,8),F(1,4),F(3,8)),
    3:(F(1,128),F(1,64),F(1,32)),
    4:(F(1,2048),F(1,1024),F(1,512)),
}


def shapes(stage):
    n,h=stage["dimension"],F(stage["h"])
    width=F(stage["density"]["bump_half_width"])
    thin=tuple(k for k in range(n) if all(
        0 < F(a["axis_lengths"][k]) <= 3*width/2
        for a in stage["arm_geometry"] if a["t"]=="t0"))
    transverse=tuple(k for k in range(n) if k not in thin)
    assert len(thin)==n-1 and len(transverse)==1
    i,j=thin[0],transverse[0]
    yield "isotropic",(h,)*n,thin,transverse
    # Keep the product h^n: two factors are h times reciprocal rational multipliers.
    for intensity,multiplier in (("mild",1+(h-1)/2),("full",h)):
        high,low=h*multiplier,h/multiplier
        for direction,axes in (("thin",(i,j)),("transverse",(j,i))):
            factors=[h]*n
            factors[axes[0]],factors[axes[1]]=high,low
            assert all(x>=1 for x in factors) and prod(factors)==h**n
            yield intensity+"_"+direction,tuple(factors),thin,transverse


def target_geometry(stage,factors):
    boxes=[]
    for p in stage["parents"]:
        A=tuple((F(x)-F(p["radius"])*r,F(x)+F(p["radius"])*r)
                for x,r in zip(p["center"],factors))
        assert volume(A)==F(p["m"])*prod(factors)
        boxes.append(A)
    width=F(stage["density"]["bump_half_width"])
    cells,segments=geometric_cells(boxes,width)
    verify_by_intersection_inversion(cells,boxes,width)
    return {mask:v for mask,(v,m) in cells.items() if mask},segments


def exhaustive_cuts(source,required,target):
    """List (source mass, neighbor volume, source membership masks) of every subset."""
    source_ids=tuple(sorted(source))
    target_ids=tuple(sorted(target))
    neighbors=[sum(1<<j for j,t in enumerate(target_ids) if required[i]&t==required[i])
               for i in source_ids]
    unions=[0]
    budgets={0:F(0)}
    rows=[(F(0),F(0),())]
    for mask in range(1,1<<len(source_ids)):
        low=mask&-mask
        k=low.bit_length()-1
        old=mask^low
        src=source_ids[k]
        union=unions[old]|neighbors[k]
        unions.append(union)
        if union not in budgets:
            budgets[union]=sumq(target[t] for j,t in enumerate(target_ids) if union&(1<<j))
        rows.append((rows[old][0]+source[src],budgets[union],tuple(sorted(rows[old][2]+(src,)))))
    return rows


def verify_flow(source,required,target,theta,rows,baseline=None):
    v,bad,union,src_mass,tgt_volume,flow=transport(source,required,target,theta)
    best_cut=max(theta*s-b for s,b,_ in rows) if baseline is None else baseline
    deficit=theta*src_mass-tgt_volume
    assert deficit==best_cut
    assert v==theta*sumq(source.values())-deficit
    return dict(theta=theta,source_cut=sorted(bad),target_cut=sorted(union),source_mass=src_mass,
                target_volume=tgt_volume,deficit=deficit,maximum_pushed_mass=v),flow


def optimum(source,required,target,rows):
    ratio,chosen=min((b/s,i) for i,(s,b,ids) in enumerate(rows) if s)
    theta=min(F(1),ratio)
    cut,flow=verify_flow(source,required,target,theta,rows,baseline=F(0))
    assert not cut["source_cut"] and sumq(flow.values())==theta*sumq(source.values())
    s,b,ids=rows[chosen]
    neighbors=tuple(k for k in sorted(target) if any(required[i]&k==required[i] for i in ids))
    assert sumq(target[k] for k in neighbors)==b and sumq(source[i] for i in ids)==s
    return dict(maximum_uniform_retention=theta,
                exact_dual_hall_cut=dict(source_masks=ids,neighbor_masks=neighbors,source_mass=s,
                                         target_capacity=b,ratio=b/s),
                exact_primal_flow=[(i,j,w) for (i,j),w in sorted(flow.items())])


def projection(stage,law,pairs,cut):
    mother=sumq(w for pairs_t in pairs.values() for w in pairs_t.values())
    assert mother==F(stage["benchmarks"][law]["mother"])
    bad=set(cut["source_cut"])
    old_by_middle={t:sumq(ws.values()) for t,ws in sorted(pairs.items())}
    outside_cut={t:sumq(w for (z,q),w in ws.items() if z not in bad and q not in bad)
                 for t,ws in sorted(pairs.items())}
    outside=sumq(outside_cut.values())
    kept=cut["theta"]*outside
    return dict(original_mother=mother,original_by_middle=old_by_middle,
                original_both_outside_cut_by_middle=outside_cut,original_both_outside_cut=outside,
                original_fraction_with_both_outside_cut=outside/mother,
                original_mass_inside_bad_cut_either_slot=mother-outside,
                proved_kept_mass_by_shared_coin_on_outside=kept,
                unpaid_mass_for_this_cut_plan=mother-kept)


def evaluate(stage):
    n=stage["dimension"]
    all_mass,standard,all_proj,all_local,required=geometry(stage,"all")
    cross_mass,cross_standard,cross_proj,cross_local,cross_req=geometry(stage,"cross")
    assert all_mass==cross_mass and standard==cross_standard and required==cross_req
    assert all_local==cross_local
    source={mask:all_mass[mask] for mask in required}
    # Exact input relation on both original sides, including all degree contributions and owner halves.
    parent_map={p["id"]:p for p in stage["parents"]}
    for law in ("all","cross"):
        for root in stage["roots_"+law]:
            t,u,g=(parent_map[root[key]] for key in ("t","u","g"))
            co=F(t["j"])/F(t["full_d"])*(F(u["j"])/F(u["m"])/F(t["m"]))*(F(g["j"])/F(g["m"])/F(t["m"]))
            assert F(root["coefficient"])==co
            assert sumq(map(F,root["sectors_00_01_10_11"]))==F(root["root_mass"])
    configs=[]
    for name,factors,thin,transverse in shapes(stage):
        target,segments=target_geometry(stage,factors)
        if name=="isotropic":
            assert target==standard
        rows=exhaustive_cuts(source,required,target)
        cert=optimum(source,required,target,rows)
        thresholds=[]
        for theta in THRESHOLDS[n]:
            cut,_=verify_flow(source,required,target,theta,rows)
            projections={law:projection(stage,law,P,cut) for law,P in (("all",all_proj),("cross",cross_proj))}
            thresholds.append(dict(cut=cut,projection=projections))
        configs.append(dict(shape=name,axis_multipliers=factors,thin_axes_zero_based=thin,
                            transverse_axes_zero_based=transverse,product_volume_multiplier=prod(factors),
                            positive_target_mask_count=len(target),positive_target_union_volume=sumq(target.values()),
                            target_face_segments_per_axis=segments,certificate=cert,thresholds=thresholds))
    theta={entry["shape"]:entry["certificate"]["maximum_uniform_retention"] for entry in configs}
    labels=("full_transverse","mild_transverse","isotropic","mild_thin","full_thin")
    assert all(theta[k]<theta[l] for k,l in zip(labels,labels[1:]))
    return dict(dimension=n,stage=stage["stage"],source_active_mask_count=len(source),
                hall_source_subsets_checked_per_shape=1<<len(source),
                exact_support_and_requirement_masks={mask:required[mask] for mask in sorted(required)},
                shape_results=configs)


def certificate(path):
    fixture=json.loads(path.read_text())
    code=Path(__file__).resolve().parent
    frozen={"comb811.py":code/"comb811.py","comb811.json":path,"hall811.py":code/"hall811.py"}
    return dict(interpreter=platform.python_version(),machine=platform.machine(),
                exact_arithmetic="fractions.Fraction throughout; exhaustive Hall cuts plus rational max-flow",
                frozen_inputs_sha256={n:sha256(p.read_bytes()).hexdigest() for n,p in frozen.items()},
                reproduction="python -B shapes811.py --data comb811.json --check shapes811.json",
                scope="Finite 2D, 3D and 4D comb fixtures. Each father has identical volume cost in every direction. Actual unions and intersections may differ. Old source, true full central degrees, joint prices and receiving halves remain frozen. All/cross have the same active requirements here, but different original edge weights.",
                cut_payment="The two price masks outside the selected Hall-deficient set are each allocated at least theta. One shared coin retains theta of their joint root mass; weights encountering the cut are set aside by this particular plan. This is a certificate, not a claim of optimal joint retention at the tested theta.",
                optimization="A single shared global source/target plan. Feasibility targets all active source masks preserving their full required expanded-parent mask. The exact largest uniform rate follows from all Hall cuts and a feasible rational flow at the minimum ratio.",
                stages=[evaluate(s) for s in fixture["stages"]])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",type=Path,default=Path("comb811.json"))
    modes=parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--output",type=Path)
    modes.add_argument("--check",type=Path)
    args=parser.parse_args()
    result=certificate(args.data)
    payload=(json.dumps(result,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(payload)
    else:
        assert args.check.read_bytes()==payload
    for s in result["stages"]:
        n=s["dimension"]
        for item in s["shape_results"]:
            theta=item["certificate"]["maximum_uniform_retention"]
            counts=[float(q["projection"]["cross"]["original_fraction_with_both_outside_cut"]) for q in item["thresholds"]]
            print(n,item["shape"],f"{float(theta):.10g}"," ".join(f"{value:.8g}" for value in counts))
    if args.check:
        print("byte-identical")


if __name__=="__main__":
    main()
