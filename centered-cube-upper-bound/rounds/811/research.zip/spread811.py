#!/usr/bin/env python3
"""One pooled source-to-Lebesgue Hall plan after exact finite symmetric spreading."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform

from comb811 import SUPPORT, intersection, interval_mass, mass
from hall811 import geometry, sumq, transport

ZERO=F(0)
ONE=F(1)
THETAS={2:(F(1,16),F(3,32),F(1,8)),
        3:(F(1,512),F(1,256),F(1,128)),
        4:(F(1,16384),F(3,32768),F(1,2048))}
METRICS=("F_valid","A_valid","outside_source_cut_F","outside_source_cut_A",
         "outside_right_cut_F","lands_in_bad_right_region","F_valid_but_in_bad_right_region")


def box(raw):
    return tuple(tuple(map(F,pair)) for pair in raw)


def coord_mask(boxes,k,x):
    return sum(1<<i for i,B in enumerate(boxes) if B[k][0]<x<B[k][1])


def translated_table(original,finite,wide,r):
    """Joint mass of original A-mask, new F-mask, and new A-mask."""
    n=len(original[0])
    universe=(1<<len(original))-1
    table={(universe,universe,universe):ONE}
    cuts_per_axis=[]
    for k in range(n):
        cuts={-SUPPORT,SUPPORT}
        for B in original:
            cuts.update(B[k])
        for B,d in product(original+finite,(-r,r)):
            cuts.update(v-d for v in B[k])
        knots=sorted(x for x in cuts if -SUPPORT<=x<=SUPPORT)
        line=defaultdict(F)
        for lo,hi in zip(knots,knots[1:]):
            x=(lo+hi)/2
            before=coord_mask(original,k,x)
            w=interval_mass(lo,hi,wide)/2
            for d in (-r,r):
                line[before,coord_mask(finite,k,x+d),coord_mask(original,k,x+d)]+=w
        updated=defaultdict(F)
        for (A,B,C),m in table.items():
            for (a,b,c),w in line.items():
                updated[A&a,B&b,C&c]+=m*w
        table=updated
        cuts_per_axis.append(len(knots)-1)
    return table,cuts_per_axis


def standalone_pooled(finite,wide,r):
    """Separate convolution of one-axis input densities on the output F partition."""
    n=len(finite[0])
    universe=(1<<len(finite))-1
    out={universe:ONE}
    for k in range(n):
        edges=sorted({-SUPPORT-r,SUPPORT+r,*(x for B in finite for x in B[k])})
        axis=defaultdict(F)
        for lo,hi in zip(edges,edges[1:]):
            w=sumq(interval_mass(lo-d,hi-d,wide) for d in (-r,r))/2
            if w:
                axis[coord_mask(finite,k,(lo+hi)/2)]+=w
        combined=defaultdict(F)
        for (i,m),(j,w) in product(out.items(),axis.items()):
            combined[i&j]+=m*w
        out=combined
    return out


def collapse(table,slot):
    counts=defaultdict(F)
    for key,w in table.items():
        counts[key[slot]]+=w
    return counts


def active_arms(stage):
    labels={p["id"]:p for p in stage["parents"]}
    arms={}
    for root in stage["roots_all"]:
        t,u=root["t"],root["u"]
        if (t,u) in arms:
            continue
        a,b=labels[t],labels[u]
        H=intersection(box(a["box"]),box(b["box"]))
        K=intersection(box(a["expanded_box"]),box(b["expanded_box"]))
        weight=F(stage["degrees"][t]["true_mu_intersections"][u])
        assert F(a["radius"])>F(b["radius"]) and weight>0
        arms[t,u]=(a["bit"]|b["bit"],H,K,weight)
    return arms


def check_arms(arms,table,wide,r):
    n=len(next(iter(arms.values()))[1])
    short=[]
    for (t,u),(need,H,K,weight) in sorted(arms.items()):
        cells=[(B,C,w) for (A,B,C),w in table.items() if A&need==need]
        shifts=tuple(product((-r,r),repeat=n))
        assert sumq(w for _,_,w in cells)==weight==mass(H,wide)
        def direct(target):
            return sumq(mass(intersection(H,tuple((lo-d,hi-d) for (lo,hi),d in zip(target,ds))),wide)
                        for ds in shifts)/len(shifts)
        a=sumq(w for _,C,w in cells if C&need==need)
        f=sumq(w for B,_,w in cells if B&need==need)
        assert a==direct(H) and f==direct(K) and 0<=a<=f<=weight
        short.append(dict(t=t,u=u,original_true_intersection_mass=weight,after_translation_F_rate=f/weight,
                          after_translation_A_rate=a/weight))
    return short


def maximal_uniform(source,target):
    theta=ONE
    cut_chain=[]
    while True:
        val,bad,_,s,b,_=transport(source,{i:i for i in source},target,theta)
        if not bad:
            assert val==theta*sumq(source.values())
            return theta,cut_chain
        assert b/s<theta
        cut_chain.append(dict(at_rate=theta,bad_masks=sorted(bad),source_mass=s,target_budget=b))
        theta=b/s


def hall_gate(source,target,theta):
    v,bad,U,s,b,flow=transport(source,{i:i for i in source},target,theta)
    assert sumq(target[i] for i in U)==b and sumq(source[i] for i in bad)==s
    assert bad<=U and v==theta*(sumq(source.values())-s)+b
    assert all(y not in U for x,y in flow if x not in bad)
    return dict(theta=theta,bad_source_masks=sorted(bad),target_union_Uprime_masks=sorted(U),bad_source_mass=s,
                bad_target_Lebesgue_mass=b,deficit=theta*s-b,pushed_mass=v,
                exact_transport=[[i,j,w] for (i,j),w in sorted(flow.items())]),bad,U


def arm_projection(table,arms,bad,U):
    rates={}
    price_masks={}
    for (t,u),(need,_,_,true_mass) in sorted(arms.items()):
        values={m:defaultdict(F) for m in METRICS}
        for (A,B,C),w in table.items():
            if A&need!=need:
                continue
            F_ok=B&need==need
            A_ok=C&need==need
            chosen=(F_ok,A_ok,F_ok and B not in bad,A_ok and B not in bad,
                    F_ok and B not in U,B in U,F_ok and B in U)
            for m,yes in zip(METRICS,chosen):
                if yes:
                    values[m][A]+=w
        price_masks[t,u]=values
        rates[t,u]={m:sumq(v.values())/true_mass for m,v in values.items()}
        a=rates[t,u]
        assert a["outside_right_cut_F"]+a["F_valid_but_in_bad_right_region"]==a["F_valid"]
        assert a["outside_right_cut_F"]<=a["outside_source_cut_F"]<=a["F_valid"]<=1
        assert a["outside_source_cut_A"]<=a["outside_source_cut_F"]
    return rates,price_masks


def joint_projection(stage,law,source_old,rates,raw,theta):
    mother=F(stage["benchmarks"][law]["mother"])
    roots=stage["roots_"+law]
    result={}
    check_mother=ZERO
    for e in roots:
        w=F(e["root_mass"])
        c=F(e["coefficient"])
        assert sumq(map(F,e["sectors_00_01_10_11"]))==w
        t,u,g=(e[k] for k in ("t","u","g"))
        z=tuple(e["z_masks"]); q=tuple(e["q_masks"])
        check_mother+=sumq(c*source_old[A]*source_old[B] for A,B in product(z,q))
    assert mother==sumq(F(e["root_mass"]) for e in roots)==check_mother
    for metric in METRICS:
        left=right=joint=by_atoms=ZERO
        for e in roots:
            t,u,g=(e[k] for k in ("t","u","g"))
            w=F(e["root_mass"])
            c=F(e["coefficient"])
            a,b=rates[t,u][metric],rates[t,g][metric]
            left+=w*a
            right+=w*b
            joint+=w*a*b
            X,Y=raw[t,u][metric],raw[t,g][metric]
            by_atoms+=c*sumq(X.get(A,ZERO)*Y.get(B,ZERO) for A,B in product(e["z_masks"],e["q_masks"]))
        assert left==right and joint==by_atoms and 0<=joint<=left<=mother
        result[metric]=dict(left_rate=left/mother,right_rate=right/mother,both_rate=joint/mother,both_true_mass=joint)
    keep=result["outside_source_cut_F"]["both_true_mass"]
    keep_outside_U=result["outside_right_cut_F"]["both_true_mass"]
    keep_A=result["outside_source_cut_A"]["both_true_mass"]
    assert keep_A<=keep and keep_outside_U<=keep
    wrong=result["lands_in_bad_right_region"]
    either_U=wrong["left_rate"]+wrong["right_rate"]-wrong["both_rate"]
    assert either_U<=2*wrong["left_rate"]
    assert result["F_valid"]["both_rate"]-either_U<=keep_outside_U/mother
    bin_tag={p["id"]:p["volume_bin"] for p in stage["parents"]}
    by_bin=defaultdict(lambda:[ZERO,ZERO,ZERO])
    for e in roots:
        t,u,g=(e[k] for k in ("t","u","g"))
        tag=bin_tag[t]
        w=F(e["root_mass"])
        by_bin[tag][0]+=w
        for k,m in enumerate(("F_valid","outside_source_cut_F"),1):
            by_bin[tag][k]+=w*rates[t,u][m]*rates[t,g][m]
    assert sumq(row[0] for row in by_bin.values())==mother and sumq(row[2] for row in by_bin.values())==keep
    return dict(original_mother=mother,pre_coin=result,either_price_lands_in_Uprime_rate=either_U,
                original_mother_F_eligible_good_by_middle_volume_bin=dict(by_bin),
                shared_coin_true_both_paid_mass=theta*keep,
                shared_coin_true_both_paid_rate=theta*keep/mother,independent_coins_true_both_paid_rate=theta**2*keep/mother,
                shared_coin_paid_rate_avoiding_Uprime=theta*keep_outside_U/mother,
                shared_coin_paid_rate_requiring_old_A=theta*keep_A/mother,
                rescued_by_allowing_F_instead_of_A_rate=theta*(keep-keep_A)/mother)


def test_shift(stage,original,expanded,old_mass,target,r):
    n=stage["dimension"]
    wide=F(stage["density"]["bump_half_width"])
    table,cuts=translated_table(original,expanded,wide,r)
    assert collapse(table,0)==old_mass
    pooled=collapse(table,1)
    assert pooled==standalone_pooled(expanded,wide,r)
    assert sumq(pooled.values())==(2*SUPPORT)**n and set(pooled)-{0}==set(target)
    source={B:pooled[B] for B in target}
    uniform_limit,chain=maximal_uniform(source,target)
    arms=active_arms(stage)
    geometry_checks=check_arms(arms,table,wide,r)
    trials=[]
    for theta in THETAS[n]:
        cut,bad,U=hall_gate(source,target,theta)
        assert bool(bad)==(theta>uniform_limit)
        mean_h_by_original_mask={A:sumq(w for (i,B,C),w in table.items() if i==A and B in U)/old_mass[A]
                                 for A in sorted(old_mass)}
        true_bad=sumq(pooled[B] for B in U)
        assert sumq(old_mass[A]*b for A,b in mean_h_by_original_mask.items())==true_bad
        rates,atom_rates=arm_projection(table,arms,bad,U)
        laws={law:joint_projection(stage,law,old_mass,rates,atom_rates,theta) for law in ("all","cross")}
        trials.append(dict(cut=cut,raw_average_h=true_bad/(2*SUPPORT)**n,h_by_original_price_mask=mean_h_by_original_mask,
                           each_true_arm_rate=[dict(t=t,u=u,**v) for (t,u),v in sorted(rates.items())],law_results=laws))
    return dict(absolute_shift_per_axis=r,one_axis_discrete_sign_probabilities=[F(1,2),F(1,2)],
                true_coordinate_cuts=cuts,nonzero_transition_records=len(table),pooled_mass_by_F_mask=dict(sorted(pooled.items())),
                exact_maximum_uniform_rate=uniform_limit,uniform_rate_Hall_cut_chain=chain,
                true_pairwise_geometric_checks=geometry_checks,thresholds=trials)


def stage_check(stage):
    n=stage["dimension"]
    assert all(1<=F(p["radius"])<2 for p in stage["parents"])
    old_mass,target,_,_,_=geometry(stage,"all")
    physical={p["id"]:p for p in stage["parents"]}
    for root in stage["roots_all"]:
        t,u,g=(physical[root[k]] for k in ("t","u","g"))
        expected=F(t["j"])/F(t["full_d"])*(F(u["j"])/F(u["m"])/F(t["m"]))*(F(g["j"])/F(g["m"])/F(t["m"]))
        assert F(root["coefficient"])==expected
    original=tuple(box(p["box"]) for p in stage["parents"])
    expanded=tuple(box(p["expanded_box"]) for p in stage["parents"])
    return dict(stage=stage["stage"],dimension=n,old_mass_with_all_parents=old_mass,
                target_Lebesgue_by_full_F_mask=target,inputs_with_true_degree=True,
                spreads=[test_shift(stage,original,expanded,old_mass,target,r) for r in (F(1,64*n),F(5,128*n))])


def certificate(path):
    home=Path(__file__).resolve().parent
    frozen={"comb811.json":path,"comb811.py":home/"comb811.py","hall811.py":home/"hall811.py"}
    return dict(python=platform.python_version(),machine=platform.machine(),arithmetic="exact Fraction; no floating solver",
                input_sha256={label:sha256(f.read_bytes()).hexdigest() for label,f in frozen.items()},
                reproduction="python -B spread811.py --data comb811.json --check spread811.json",
                model="One pooled source mu convolved with the same product of two equally likely signs on each axis, applied separately to the two original true prices. Source and target masks encode every expanded parent containing the translated position. The common Hall plan uses entire pooled supply in the radius octave, independent of t, u, g and the all/cross law.",
               _bad_region="Uprime is the union of target masks containing at least one label set from the deficient source cut. h(z) is the chance that z plus the sign displacement belongs to this bad target union.",
                final_marks="Apply one common Bernoulli(theta) to both qualified price slots. Each slot has the same thinning probability; sharing that coin leaves a single factor theta. The diagnostic contrast uses separate Bernoulli draws. The whole unthinned joint root uses both true original prices and original degree.",
                scope="Finite R811 calibrated comb diagnostic. The product discrete noise and finite Hall caps test these input measures, not the continuous general estimate.",
                stages=[stage_check(s) for s in json.loads(path.read_text())["stages"]])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",type=Path,default=Path("comb811.json"))
    gp=parser.add_mutually_exclusive_group(required=True)
    gp.add_argument("--output",type=Path)
    gp.add_argument("--check",type=Path)
    args=parser.parse_args()
    data=certificate(args.data)
    txt=(json.dumps(data,default=str,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(txt)
    else:
        assert args.check.read_bytes()==txt
    for s in data["stages"]:
        for spread in s["spreads"]:
            print(s["dimension"],spread["absolute_shift_per_axis"],"uniform",f"{float(spread['exact_maximum_uniform_rate']):.9g}",
                  "transition states",spread["nonzero_transition_records"])
            for item in spread["thresholds"]:
                cross=item["law_results"]["cross"]
                f=cross["pre_coin"]
                print("  ",item["cut"]["theta"],"bad masks",len(item["cut"]["bad_source_masks"]),
                      "cross F, F outside, h-left, shared paid, old-A paid, independent",
                      *(f"{float(x):.9g}" for x in (f["F_valid"]["both_rate"],f["outside_source_cut_F"]["both_rate"],
                        f["lands_in_bad_right_region"]["left_rate"],cross["shared_coin_true_both_paid_rate"],
                        cross["shared_coin_paid_rate_requiring_old_A"],cross["independent_coins_true_both_paid_rate"])))
    if args.check:
        print("byte-identical")


if __name__=="__main__":
    main()
