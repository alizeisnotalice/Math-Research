#!/usr/bin/env python3
"""Rebuild the round 811 diagnostics and replay the rational optimization proof."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def checked(data, expected, label):
    actual = sha256(data).hexdigest()
    if actual != expected:
        raise ValueError(f"{label}: expected {expected}, got {actual}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--previous", required=True, type=Path, help="round 810 research.zip")
    parser.add_argument("--work", required=True, type=Path, help="new output directory")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "MANIFEST.json").read_text())
    members = {name: checked((here / name).read_bytes(), digest, name)
               for name, digest in manifest["members"].items()}
    previous = args.previous.resolve()
    dependency = manifest["previous"]
    checked(previous.read_bytes(), dependency["archive_sha256"], "round 810 archive")
    with ZipFile(previous) as archive:
        old_program = checked(archive.read("joint810.py"), dependency["script_sha256"], "joint810.py")
    out = args.work.resolve()
    out.mkdir(parents=True, exist_ok=False)
    for name, blob in members.items():
        if (name.endswith(".py") and name != "replay811.py") or name == "hall811.json":
            (out / name).write_bytes(blob)
    (out / "joint810.py").write_bytes(old_program)

    def run(stem, arguments):
        subprocess.run([sys.executable, "-B", stem + ".py", *arguments], cwd=out, check=True)

    run("joint810", ["--output", "joint810.json"])
    checked((out / "joint810.json").read_bytes(), dependency["output_sha256"], "joint810.json")
    run("stop811", ["--r810-dir", str(out), "--output", "stop811.json"])
    run("comb811", ["--output", "comb811.json"])
    run("hall811", ["--data", "comb811.json", "--check", "hall811.json"])
    run("shapes811", ["--data", "comb811.json", "--output", "shapes811.json"])
    run("spread811", ["--data", "comb811.json", "--output", "spread811.json"])
    for name, digest in manifest["results"].items():
        checked((out / name).read_bytes(), digest, name)
        print("SHA256", digest, name, flush=True)
    print("Verified five round 811 outputs and the round 810 dependency.")


if __name__ == "__main__":
    main()
