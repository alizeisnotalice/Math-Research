#!/usr/bin/env python3
"""Exact common-marginal transport on true stripe-source diagnostic cells."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from math import ceil, floor, prod
from pathlib import Path
import platform
import sys


DEPENDENCIES={
 'joint810.py':'a682813430d04acba31640cb04a386369f98c0742a918db66562c847f353d250',
 'joint810.json':'2dc3b67f4f92daad1e8c5c4c3f45990c498aeab122d208809c3edb44e3efff01',
}
WIDTHS=(F(1,4),F(1,2),F(1))
METHODS=('independent_uniform_full_box','independent_first_coordinate_only','monotone_first_coordinate',
         'reversed_first_coordinate','targetwise_marginal_ceiling')


def total(x):
    return sum(x,F(0))


def box(B):
    return tuple(tuple(map(F,axis)) for axis in B)


def intersection(a,b):
    return max(a[0],b[0]),min(a[1],b[1])


def len1(I):
    return max(F(0),I[1]-I[0])


class FixedGrid:
    def __init__(self,width,amplitude,model):
        self.w=width
        self.a=amplitude
        self.model=model
        N=int(2*model.SUPPORT/width)
        assert N*width==2*model.SUPPORT
        self.axis=[(-model.SUPPORT+i*width,-model.SUPPORT+(i+1)*width) for i in range(N)]
        self.masses=[self.mass(I) for I in self.axis]
        self.densities=[m/width for m in self.masses]
        assert all(0<m for m in self.masses)
        if width>=model.PERIOD:
            assert set(self.densities)=={1}
        else:
            assert set(self.densities)=={1-amplitude,1+amplitude}
        assert total(self.masses)==2*model.SUPPORT

    def mass(self,I,quarter=False):
        if I[0]>=I[1]:
            return F(0)
        return self.model.mass((I,),self.a,by_quarters=quarter)

    def rank_hit(self,source,target,B,rho,reverse):
        a,b=B
        p,q=source
        l,r=target
        source_rank=(self.mass((a,p)),self.mass((a,q)))
        target_rank=(rho*(b-r),rho*(b-l)) if reverse else (rho*(l-a),rho*(r-a))
        exact=len1(intersection(source_rank,target_rank))
        # Independent, affine phase-by-phase preimage integration. On a phase
        # the map derivative has magnitude f/rho and the source density is f.
        preimage=F(0)
        quarter=self.model.QUARTER
        for k in range(floor(p/quarter),ceil(q/quarter)):
            x,y=max(p,k*quarter),min(q,(k+1)*quarter)
            if x>=y: continue
            X,Y=self.mass((a,x),quarter=True)/rho,self.mass((a,y),quarter=True)/rho
            image=(b-Y,b-X) if reverse else (a+X,a+Y)
            preimage+=rho*len1(intersection(image,target))
        assert exact==preimage
        return exact

    def x1(self,I,J):
        sourced=[]
        cols={k:[] for k in METHODS}
        for B,rho in zip(self.axis,self.densities):
            A=intersection(I,B)
            H=intersection(J,B)
            live=self.mass(A)
            sourced.append(live)
            if live and len1(H):
                assert self.mass(A,quarter=True)==live
                dest=rho*len1(H)
                # Both deterministic rank maps give the same target marginal.
                assert self.rank_hit(B,H,B,rho,False)==dest==self.rank_hit(B,H,B,rho,True)
                rnd=live*len1(H)/self.w
                mono=self.rank_hit(A,H,B,rho,False)
                refl=self.rank_hit(A,H,B,rho,True)
                hi=min(live,dest)
                assert all(0<=u<=hi for u in (rnd,mono,refl))
                vals=(rnd,rnd,mono,refl,hi)
            else:
                vals=(F(0),)*len(METHODS)
            for k,v in zip(cols,vals,strict=True): cols[k].append(v)
        mother=total(sourced)
        assert mother==self.mass(I)>0
        return sourced,cols

    def scored_box(self,Q,H):
        assert all(a<=p<q<=b for (p,q),(a,b) in zip(Q,H))
        raw,first=self.x1(Q[0],H[0])
        kernels={method:[values] for method,values in first.items()}
        rawaxes=[raw]
        for I,J in zip(Q[1:],H[1:]):
            widths=[len1(intersection(I,B)) for B in self.axis]
            assert total(widths)==len1(I)
            redraw=[p*len1(intersection(J,B))/self.w for p,B in zip(widths,self.axis)]
            rawaxes.append(widths)
            kernels['independent_uniform_full_box'].append(redraw)
            for k in METHODS[1:]:
                kernels[k].append(widths)
        original=prod(total(v) for v in rawaxes)
        assert original==self.model.mass(Q,self.a)>0
        scores={method:prod(total(A) for A in lens)/original for method,lens in kernels.items()}
        assert all(0<=v<=scores['targetwise_marginal_ceiling']<=1 for v in scores.values())
        return dict(original_mu=original,raw_axes=rawaxes,tracked_axes=kernels,scores=scores)


def actual_same_cell(A,B,method=None):
    left=A['raw_axes'] if method is None else A['tracked_axes'][method]
    right=B['raw_axes'] if method is None else B['tracked_axes'][method]
    return prod(total(a*b for a,b in zip(x,y,strict=True)) for x,y in zip(left,right,strict=True))


def arm_book(t,grid):
    out={}
    for a in t['true_arms']:
        e=a['g']; H=box(a['source_box']); raw=F(a['raw'])
        full=grid.scored_box(H,H)
        assert full['original_mu']==F(a['j_mu'])
        marks=[]
        for m in a['sectors']:
            Q=box(m['actual_price'])
            W=box(m['actual_owner'])
            score=grid.scored_box(Q,H)
            assert score['original_mu']==F(m['price_mu'])
            assert grid.model.volume(W)==F(m['owner_volume'])
            r=F(m['raw_leg_mass'])
            assert r>0
            marks.append(dict(q_half=m['q_half'],W_half=m['W_half'],raw=r,record_mu=score['original_mu'],
                              scores=score['scores']))
        assert total(v['raw'] for v in marks)==raw
        for k in METHODS[:-1]:
            assert total(v['raw']*v['scores'][k] for v in marks)/raw==full['scores'][k]
        # A per-mark fallback ceiling may spend the same output mass twice.
        # The full target H marginal ceiling is the one used for upper bounds.
        assert total(v['raw']*v['scores']['targetwise_marginal_ceiling'] for v in marks)/raw>=full['scores']['targetwise_marginal_ceiling']
        out[e]=dict(g=e,small_D=F(a['small_bin']),raw=raw,full=full,marks=marks)
    return out


def check_cartesian(grid,arm,stage):
    H=box(arm['source_box'])
    cells=[[I for I in grid.axis if len1(intersection(I,J))] for J in H]
    exact=F(0)
    pieces=0
    for B in product(*cells):
        A=grid.model.clip(H,B)
        if grid.model.volume(A):
            pieces+=1
            exact+=grid.model.mass(A,grid.a,by_quarters=True)*grid.model.volume(A)/grid.model.volume(B)
    expected=grid.scored_box(H,H)['scores']['independent_uniform_full_box']*F(arm['j_mu'])
    assert exact==expected
    return dict(explicit_true_boxes=pieces,absolute_retained_mu=exact)


def one_law(stage,law,grid,books):
    old=stage['olds']
    roots=F(0)
    same_root=F(0)
    first={k:F(0) for k in METHODS}
    second=first.copy()
    joint=first.copy()
    both_same=first.copy()
    by_t=[]
    count=0
    for t in stage['tests']:
        i=t['t']; arms=books[i]
        ref=next((p for p in t['actual_joint_laws'] if p['law']==law),None)
        if ref is None: continue
        coeff=F(stage['middles'][i]['j'])/F(t['full_original_degree'])
        exact_pairs={(v['q_g'],v['z_u']):F(v['actual_mass']) for v in ref['original_label_edge_masses']}
        raw_check={}
        by_half={}
        for g,u in product(arms,repeat=2):
            if law=='different_size_bins' and arms[g]['small_D']==arms[u]['small_D']:
                continue
            a,b=arms[g],arms[u]
            rowmass=F(0)
            direct={k:[F(0),F(0),F(0)] for k in METHODS[:-1]}
            for q,z in product(a['marks'],b['marks']):
                m=coeff*q['raw']*z['raw']
                count+=1
                rowmass+=m
                key=(g,q['W_half'])
                by_half[key]=by_half.get(key,F(0))+m
                for k in direct:
                    r,s=q['scores'][k],z['scores'][k]
                    direct[k][0]+=m*r
                    direct[k][1]+=m*s
                    direct[k][2]+=m*r*s
            assert rowmass==exact_pairs[g,u]==coeff*a['raw']*b['raw']
            raw_check[g,u]=rowmass
            roots+=rowmass
            A,B=a['full'],b['full']
            source_mother=A['original_mu']*B['original_mu']
            same_original=actual_same_cell(A,B)/source_mother
            same_root+=rowmass*same_original
            for k in METHODS:
                i1,i2=A['scores'][k],B['scores'][k]
                once,twice,both=rowmass*i1,rowmass*i2,rowmass*i1*i2
                if k in direct:
                    assert direct[k]==[once,twice,both]
                first[k]+=once
                second[k]+=twice
                joint[k]+=both
                same_given=actual_same_cell(A,B,k)/source_mother
                assert 0<=same_given<=same_original
                both_same[k]+=rowmass*same_given
        assert raw_check==exact_pairs and total(raw_check.values())==F(ref['original_joint_mother'])
        assert by_half=={(r['g'],r['half']):F(r['mass']) for r in ref['actual_q_owner_half_projection']}
        by_t.append(dict(t=i,full_degree=t['full_original_degree'],exact_mother=total(raw_check.values()),
                         ordered_pair_count=len(raw_check),actual_receiver_half_marginal_checked=True))
    assert roots>0
    assert all(first[k]==second[k] for k in METHODS)
    if law=='different_size_bins':
        assert same_root==0 and all(x==0 for x in both_same.values())
    else:
        assert same_root>0
    result=[]
    for k in METHODS:
        assert 0<=both_same[k]<=same_root and 0<=joint[k]<=min(first[k],second[k])<=roots
        rho1=first[k]/roots
        rho2=second[k]/roots
        prob=joint[k]/roots
        result.append(dict(method=k,actual_true_q_hit=rho1,actual_true_z_hit=rho2,
            original_joint_double_hit=prob,independent_marginal_product=rho1*rho2,
            joint_minus_product=prob-rho1*rho2,
            original_same_box_double_hit_probability_not_renormalized=both_same[k]/roots,
            original_double_hit_given_same_source_grid_box=both_same[k]/same_root if same_root else None))
    best=max(x['original_joint_double_hit'] for x in result[:-1])
    up=result[-1]['original_joint_double_hit']
    assert best<=up
    mono=result[2]['original_joint_double_hit']
    rnd=result[0]['original_joint_double_hit']
    return dict(law=law,exact_original_mother=roots,exact_number_positive_original_rectangle_mark_atoms=count,
        source_same_box_frequency=same_root/roots,per_middle_exact_mothers=by_t,methods=result,
        monotone_minus_full_box_independent_double=mono-rnd,
        best_feasible_candidate_double=best,true_common_optimum_upper_if_independent_kernel_applications=up,
        common_optimum_certified_if_gap_zero=best==up,conditional_ceiling_minus_best_candidate=up-best)


def example(source,model):
    amp=F(source['source_density_amplitude'])
    out=[]
    for w in WIDTHS:
        grid=FixedGrid(w,amp,model)
        books={t['t']:arm_book(t,grid) for t in source['tests']}
        sanity=check_cartesian(grid,source['tests'][0]['true_arms'][0],source) if source['n']==2 else None
        methods=[one_law(source,l,grid,books) for l in ('all_two_old_arms','different_size_bins')]
        out.append(dict(width=w,true_density_values=sorted(set(grid.densities)),grid_first_axis_cell_count=len(grid.axis),
                     full_n_dimensional_grid_cell_count=len(grid.axis)**source['n'],explicit_sanity_box_integration=sanity,
                     retained_by_full_price_arm_and_actual_receiving_half=[dict(t=t,g=g,per_mark=a['marks'],
                       full_true_target_hit=a['full']['scores']) for t,book in books.items() for g,a in book.items()],cases=methods))
    mothers=[tuple(r['exact_original_mother'] for r in x['cases']) for x in out]
    assert len(set(mothers))==1
    return dict(stage=source['stage'],dimension=source['n'],small_bins=source['old_bins'],middle_bins=source['middle_bins'],
                source_density_amplitude=amp,grid_tests=out)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r810-dir',type=Path,default=here)
    choice=p.add_mutually_exclusive_group()
    choice.add_argument('--output',type=Path)
    choice.add_argument('--check',type=Path)
    args=p.parse_args()
    base=args.r810_dir.resolve()
    for name,d in DEPENDENCIES.items():
        assert sha256((base/name).read_bytes()).hexdigest()==d
    sys.path.insert(0,str(base))
    import joint810 as model
    stage=json.loads((base/'joint810.json').read_text())['stages']
    data=[example(s,model) for s in stage]
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        reproduction='python -B stop811.py --check stop811.json',dependencies=DEPENDENCIES,stages=data,
        scope=dict(box='Deterministic coordinate-aligned diagnostic grid on the frozen support [-8,8]^n. All positive B use actual rho_B=mu(B)/Leb(B). Quarter-width cells show both nonunit densities. The two enlarged widths contain whole periods and rho_B=1.',
           kernel='Every observed point uses the same fixed kernel on its actual source box, independently of its hidden old labels. Compare full independent uniform redraw, first-coordinate-only independent redraw, and true first-coordinate monotone and reflected quantile couplings that keep other coordinates. Phase-wise affine preimages independently verify the rank formulas and every tested target marginal.',
           original='Use actual joint810 q,z bodies and receiving W/U halves, all original full d_t, and original conditional label-pair mother. Conditional on each actual full branch, the two new kernel applications are independent. Across true roots, double hit uses the original mixture of products. Every original edge mass and W half marginal is recovered.',
           upper='The targetwise oracle uses min(mu(H intersect B),rho_B*Leb(H intersect B)) for every target and source box. This bounds independent applications of any single common kernel. Reaching this bound certifies optimality, while a nonzero gap only records an upper bound. It does not assert existence of a common oracle optimizer.',
           same_box='Also compute the positive subflow in which both old prices start in the same physical grid B using product cell weights by axes. The cross-bin law has zero such subflow because the fixed grid boundary includes zero and the true price signs differ.',
           limit='Finite true price/source and ownership geometry. This diagnostic grid is not the high-dimensional first stopping collection. No asymptotic rate is inferred.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output: args.output.write_text(text)
    if args.check: assert args.check.read_text()==text
    if args.output or args.check:
        for s in data:
            for x in s['grid_tests']:
                for case in x['cases']:
                    print(s['stage'],x['width'],case['law'],'double',
                         *[format(float(r['original_joint_double_hit']),'.8g') for r in case['methods']],
                         'same B content',format(float(case['source_same_box_frequency']),'.6g'))
        if args.check: print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
