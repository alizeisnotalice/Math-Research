from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import sys,platform,json,time
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ss(v):return str(v)
def sqrtq(v):
 a=isqrt(v.numerator);b=isqrt(v.denominator);ck(a*a==v.numerator and b*b==v.denominator);return F(a,b)
# Actual five constant-density positive-length source packets. Each private
# cluster is split only to realize a genuinely asymmetric original mark.
pack=[(F(-84,100),F(-83,100),F(1)),(F(-83,100),F(-82,100),F(2)),(F(-1,100),F(1,100),F(1)),(F(82,100),F(83,100),F(3)),(F(83,100),F(84,100),F(5))]
cent=[F(-2,5),F(2,5)];clen=[F(1,100)]*2;side=[F(1),F(9,5)]
cap=[];marg=[]
for A in range(2):
 rr=[];mm=[]
 for lo,hi,mu in pack:
  left=cent[A]-clen[A]/2;right=cent[A]+clen[A]/2
  far=max(abs(left-hi),abs(right-lo));near=max(F(0),lo-right,left-hi)
  if far<side[A]/2:rr.append(1);mm.append(side[A]/2-far)
  else:ck(near>side[A]/2);rr.append(0);mm.append(near-side[A]/2)
 cap.append(rr);marg.append(mm)
ck(cap==[[1,1,1,0,0],[0,0,1,1,1]])
mu=[z[2] for z in pack];m=[sum(mu[x]*cap[A][x] for x in range(5)) for A in range(2)]
q=[m[A]/side[A] for A in range(2)];sig=[q[A]*clen[A] for A in range(2)];r=max(q)/min(q);S=F(1);W=sum(mu)
ell=[[[F(0)]*5 for _ in range(5)] for A in range(2)]
ell[0][0][1]=F(1,2);ell[0][1][0]=F(1,8)
ell[1][3][4]=F(1);ell[1][4][3]=F(1,4)
t=[sum(mu[y]*mu[z]*ell[A][y][z]*cap[A][y]*cap[A][z]/m[A]**2 for y in range(5) for z in range(5)) for A in range(2)]
ck(t==[F(5,64),F(25,108)])
for A in range(2):
 for y in range(5):
  for z in range(5):
   ck(0<=ell[A][y][z]<=S)
   if ell[A][y][z]:ck(cap[A][y]*cap[A][z]==1)
R=sum(sig[A]*t[A] for A in range(2))
native=[]
for label,labels,scale in [('rank_loss',[0,0],F(1)),('conditioning_pressure',[0,0],F(2)),('split_bands',[0,1],F(1))]:
 ell[0][0][1]=F(1,2)*scale;ell[0][1][0]=F(1,8)*scale
 t=[sum(mu[y]*mu[z]*ell[A][y][z]*cap[A][y]*cap[A][z]/m[A]**2 for y in range(5) for z in range(5)) for A in range(2)]
 ck(max(ell[0][0][1],ell[0][1][0])<=S)
 R=sum(sig[A]*t[A] for A in range(2))
 N=max(labels)+1;rankmass=F(0);rawhit=F(0);condhit=F(0);highmass=F(0);details=[]
 for x in range(5):
  for j in range(N):
   w=[t[A]*sig[A]*cap[A][x]/m[A] if labels[A]==j else F(0) for A in range(2)];u=sum(w)
   if not u:continue
   P=[z/u for z in w];keptposterior=F(0)
   for A in range(2):
    if not w[A]:continue
    beta=sum(P[B] for B in range(2) if m[B]<=m[A]);rank=beta>=F(1,2)
    if rank:keptposterior+=P[A]
    k=int(u/(256*r*S));ck(k==0)
    Q=[P[B]*(m[B]<=m[A])/beta for B in range(2)]
    ck(sum(Q)==1)
    # Exact original Gamma integral over (x,A,y,z), without replacing ell by t.
    hrecord=F(0);hraw=F(0)
    for y in range(5):
     for z in range(5):
      record=sig[A]*ell[A][y][z]*mu[x]*mu[y]*mu[z]*cap[A][x]*cap[A][y]*cap[A][z]/m[A]**3
      union=[int(bool(cap[B][y] or cap[B][z])) for B in range(2)]
      if rank:
       rankmass+=record
       condhit+=record*sum(Q[B]*union[B] for B in range(2))
       rawhit+=record*sum(P[B]*(m[B]<=m[A])*union[B] for B in range(2))
       hrecord+=record*sum(Q[B]*union[B] for B in range(2))
       hraw+=record*sum(P[B]*(m[B]<=m[A])*union[B] for B in range(2))
       if u>=256*r*S:highmass+=record
    ck(hrecord<=2*hraw)
    details.append(dict(source_x=x,band=j,parent=A,u=str(u),beta=str(beta),rank_kept=rank,k=k,conditional_hit_Gamma_contribution=str(hrecord)))
   ck(keptposterior>=F(1,2))
 ck(R/2<=rankmass<=R);ck(condhit<=8*r*S*N*W);ck(rawhit<=4*r*S*N*W);ck(condhit<=2*rawhit);ck(highmass==0)
 native.append(dict(mark_variant=label,small_parent_mark_scale=str(scale),actual_t=list(map(str,t)),phase='native_initial' if N==1 else 'native_band_rank_pressure',band_labels=labels,N=N,band_mass_ranges=[['4','9']] if N==1 else [['4','6'],['6','9']],original_Gamma_mass=str(R),rank_kept_mass=str(rankmass),rank_retained_fraction=str(rankmass/R),single_draw_rank_union_hit_integral=str(condhit),raw_inclusive_mass_hit_integral=str(rawhit),union_bound_8rSNW=str(8*r*S*N*W),Markov_badflow_bound_32rSNW=str(32*r*S*N*W),actual_high_rank_mass=str(highmass),actual_high_hit_integral='0',all_k_zero=True,source_parent_details=details))

# Finite compatible source indicator models, NOT actual cubes. Parent A
# contains common source mass1 and two private source atoms each (mA-1)/2.
# ell is1 on its ordered two-private pair only, zero otherwise, hence
# tA=(mA-1)^2/(4mA^2); sigmaA=mA/tA makes raw source column weight1.
abstract=[]
for name,N,k_wanted,mixed,ids in [('initial_k4',1024,4,False,[0,1,2,3]),('duplicate_gate_pressure',1024,4,False,[0,0,1,2]),('expanded_k20_massratio4',5120,20,True,[0,0]+list(range(1,19)))]:
 masses=[F(16384 if mixed and (A==0 or A>N//2) else 4096) for A in range(N)]
 # Exactly N/2 large and small in mixed case, with old parent0 large.
 if mixed:ck(sum(z==16384 for z in masses)==N//2)
 roots=[sqrtq(z) for z in sorted(set(masses))];rootmap=dict(zip(sorted(set(masses)),roots))
 u=F(N);k=int(u/256);ck(k==k_wanted);ck(len(ids)==k)
 alpha=8/u;beta=F(sum(mm<=masses[0] for mm in masses),N);ck(beta>=F(1,2))
 old_t=(masses[0]-1)**2/(4*masses[0]**2);old_sigma=masses[0]/old_t;ck(old_t*old_sigma/masses[0]==1)
 # Actual indicator intersections: self=mA, distinct=common source mass1.
 def gg(A,B):return F(1) if A==B else 1/(rootmap[masses[A]]*rootmap[masses[B]])
 # Verify expected Gram bound for each mass class, without forming NxN.
 for cls in sorted(set(masses)):
  A=masses.index(cls);allowed=[B for B in range(N) if masses[B]<=masses[A]]
  avg=sum(gg(A,B) for B in allowed)/len(allowed);ck(avg<=alpha)
 O=sum(gg(ids[a],ids[b]) for a in range(k) for b in range(k) if a!=b)
 threshold=4*alpha*k*(k-1);good=O<=threshold
 rows=[sum(gg(ids[a],ids[b]) for b in range(k) if b!=a) for a in range(k)]
 bad=[a for a in range(k) if rows[a]>F(1,2)]
 # Old ordered private source pair is captured iff sampled parent is0.
 hit=[a for a in range(k) if ids[a]==0];hitgood=len(hit)<=F(k,4)
 kept=[a for a in range(k) if a not in bad and a not in hit]
 ck(len(bad)<=2*O)
 if good:ck(len(bad)<=F(k-1,4))
 if good and hitgood:ck(len(kept)>=F(k,2))
 ck(all(ids[a]!=0 for a in kept))
 # Same band: ratio<=4, each sample mass<=original old-parent mass.
 ck(max(masses)/min(masses)<=4);ck(all(masses[A]<=masses[0] for A in ids))
 if name=='duplicate_gate_pressure':ck(not good);ck(not hitgood)
 else:ck(good and hitgood)
 abstract.append(dict(name=name,scope='FINITE INDICATOR GRAM ONLY, not cubes/CDF/original history',N=N,u=str(u),rS_normalization='1 (abstract interface)',k=k,mass_classes=list(map(str,sorted(set(masses)))),mass_ratio=str(max(masses)/min(masses)),single_band_logwidth='log(4)',source_model='common mass1; two private atoms each (mA-1)/2 per parent',original_mark='ellA=1 on ordered private1,private2 only; tA=(mA-1)^2/(4mA^2); sigmaA=mA/tA',old_parent=0,old_parent_mass=str(masses[0]),old_beta=str(beta),sample_parent_ids=ids,alpha_prime=str(alpha),ordered_off_total=str(O),geometry_threshold=str(threshold),geometrygood=good,old_hit_count=len(hit),old_hit_threshold=str(F(k,4)),hitgood=hitgood,geometry_deleted_indices=bad,kept_count=len(kept),kept_at_least_k_over_2=(len(kept)>=F(k,2)),old_pair_outside_whole_kept_family=True,one_draw_old_pair_hit_rate=str(1/(N*beta))))
result=dict(scope='Exact native static band/rank/hit integration plus compatible abstract indicator sample deletion interfaces. No original high-history certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),command='"'+sys.executable+'" r477_numeric.py',seconds=time.perf_counter()-start),checks=checks,exactness='All calculations Fraction; no floating arithmetic, solver, Monte Carlo or probability truncation.',native_geometry=dict(packets=[[str(z) for z in row] for row in pack],centers=list(map(str,cent)),center_lengths=list(map(str,clen)),sides=list(map(str,side)),capture=cap,strict_margins=[[str(z) for z in row] for row in marg],masses=list(map(str,m)),q=list(map(str,q)),sigma=list(map(str,sig)),t=list(map(str,t)),r=str(r),W=str(W)),native=native,abstract=abstract)
(ROOT/'r477_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'Fraction checks; 1 native field,3 mark/band cases and3 compatible abstract sample fixtures; static/interface only')
