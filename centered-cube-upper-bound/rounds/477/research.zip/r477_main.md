# 第477轮：同质量带整族双来源外部结构与共同核心费用

## 结果与边界

本轮将第476轮的一个锚父扩为整个实际父族：同一原记录的两条旧来源均在保留族的并集之外；所有父与原父质量可比且不更大，规模与同带实际接受占用成正比。全部低带、质量中位门和删除费用联合为根阶来源价。完整余流仍存在，没有证明一般上界。

新增的几何信息是共同核心的真实来源质量至多$3m_A/k$，但该核心承载的是依来源选择父族后的联合权，不能把静态容量直接当作原流的$3/k$下降。本稿写明这一权重，保留跨来源费用作为具体缺口。

## 1. 原始测度及完整质量带

沿原合同，$\mu=f dx$，$W=\mu(\mathbb R^n)$，$f\ge0$且可积；实际Lebesgue中心$A$的立方体边长$a\le R_A\le b\le2a$。$m_A=\mu(Q_A)=q_AR_A^n$，$q\le q_A\le\lambda$，$r=\lambda/q$，$\sigma=q_A dA$，$X=\sigma(E)$，$\pi_A=c_A\mu/m_A$。

完整原接受记录为$\xi$，其$(A,y,z)$投影是$\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz)$，$0\le\ell\le S$，全部阶段、时钟、初始、严格质量路径、soft、early、删除及未来门保留。父边缘$t(A)\sigma(dA)$满足$0\le t\le S$，原总量$R=|\Pi|$。

把整个$[qa^n,\lambda b^n]$分成$N$个互不交质量带$J_j$，对数宽度不超过$L$，端点归属明确，不删低端或高端补集。可取
\[
N\le1+\frac{\log r+n\log(b/a)}L.
\]
定义
\[
u_j(x)=\int_{m_A\in J_j}\frac{t(A)c_A(x)}{m_A}d\sigma(A),\qquad
P_{x,j}(dB)=\frac{1_{m_B\in J_j}t(B)c_B(x)}{m_Bu_j(x)}d\sigma(B).
\]
零$u_j$处无相应原流。独立附$x\sim\pi_A$，原记录按其父所属带标记$j$。该$(j,x)$边缘准确为$u_j(x)\mu(dx)$。令
\[
\mathcal M=\int\#\{j:u_j(x)>0\}\,d\mu(x)\le NW.
\]
以下$S=0$时原流全零，另行处理。

## 2. 中位质量门与实际同带采样

置$T=256rS$。删去$u_j(x)\le T$的正分数，成本至多$T\mathcal M$；记其余总量$R_{\rm high}$。在其上$u_j>T$，令
\[
\beta_j(A,x)=P_{x,j}\{m_B\le m_A\}.
\]
保留$\beta_j\ge1/2$，得到质量$R_{\rm rank}\ge R_{\rm high}/2$。证明用闭CDF的中位性质；在固定$(j,x)$处，积分旧来源与历史后的原父分布正是$P_{x,j}$。不是说每个父都自动满足中位门。等质量原子全部保留。

对保留记录使用条件父核
\[
Q_{A,x,j}(dB)=\frac{1_{m_B\le m_A}}{\beta_j(A,x)}P_{x,j}(dB),
\quad b_A(x)=u_j(x)\beta_j(A,x).
\]
它不大于$2P_{x,j}$。真实来源CDF给固定父亲和行界
\[
\int\gamma_{BC}Q_{A,x,j}(dC)\le\alpha':=8rS/u_j(x),
\qquad\gamma_{BC}=\frac{\mu(Q_B\cap Q_C)}{\sqrt{m_Bm_C}}.
\]
令$k=\lfloor u_j(x)/(256rS)\rfloor\ge1$，所以$k\alpha'\le1/32$。独立取$k$个$Q_{A,x,j}$父；样本真实捕获$x$，且
\[
e^{-L}m_A\le m_B\le m_A. \tag{1}
\]
新父只具有实际几何与接受父支持，不承接原记录的历史。

## 3. 两类删除在同一原记录上结算

记原样本有向非对角亲和总和$O$。$k\ge2$时$\mathbb EO\le\alpha'k(k-1)$，故事件
\[
O\le4\alpha'k(k-1)
\]
概率至少$3/4$。$k=1$时$O=0$且事件必成立。在此事件上删除原行和大于$1/2$的索引，删除数至多$2O\le(k-1)/4$。

在**同一个**样本上，再删去捕获原$y$或原$z$的父。设被捕获索引数为$H_{\rm hit}$，不重采原来源。对同一rank/high原流，
\[
\int \mathbb E[H_{\rm hit}/k]\,d\Gamma_{\rm rank}
\le8rS\mathcal M. \tag{2}
\]
这里$d\Gamma=\Pi(d\xi)\pi_A(dx)$，带标记仍为原$A$之带。证明由第476轮真实闭尾界
\[
\int_{m_A\ge m_B}\frac{c_A(x)\mu(Q_A\cap Q_B)}{m_A^2}d\sigma(A)\le2r
\]
逐带换序给出：每条旧来源收$2rS$，两条合$4rS$，条件父核的$1/\beta_j\le2$再给$8rS$；归一化$u_j$在该带准确消去。只正上放$\ell\le S$以估计被删项，不混合不同原记录的阶段或来源。

由Markov，样本$H_{\rm hit}>k/4$的原扩展质量至多$32rS\mathcal M$。同时保亲和好事件和$H_{\rm hit}\le k/4$，并执行上述两次删除，得到实际子流$\Xi$，满足
\[
\boxed{|\Xi|\ge\tfrac34 R_{\rm rank}-32rS\mathcal M
\ge\tfrac38R_{\rm high}-32rS\mathcal M.} \tag{3}
\]
这不要求两类坏事件独立，也不把已经删去的记录重新计入。

每条保留记录附带族$\mathcal F$，满足
\[
|\mathcal F|\ge k/2,\quad
x\in Q_A\cap\bigcap_{B\in\mathcal F}Q_B,\quad
y,z\in Q_A\setminus\bigcup_{B\in\mathcal F}Q_B, \tag{4}
\]
\[
\sum_{C\in\mathcal F\setminus\{B\}}\gamma_{BC}\le1/2,
\qquad\mu(\cup_{B\in\mathcal F}Q_B)\ge\tfrac23\sum_{B\in\mathcal F}m_B. \tag{5}
\]
Gram谱仍在$[1/2,3/2]$，删成员只降低行和；重复的归一来源向量不能同时保留。所有质量都满足(1)。按$k$整数分层、原索引删行可测。最终父族依赖原$y,z$；这是原流的合法正限制，不是原时钟下的新可预测控制。

## 4. 完整恢复费用

用$R\le R_{\rm high}+256rS\mathcal M$与(3)，得到
\[
\boxed{R\le\frac{1024}{3}rS\mathcal M+\frac83|\Xi|
\le\frac{1024}{3}rSNW+\frac83|\Xi|.} \tag{6}
\]
取$L=\sqrt n$、固定$r,S$，已付项为$O_{r,S}(\sqrt n)W$。此时整族与原父质量比在$[e^{-\sqrt n},1]$。$k$可为1；必须保留这一合法小族情形，不能默认为大型族。

因此需要对**同一**$\Xi$证明
\[
|\Xi|\le\tfrac38\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W
\]
才能回到目标。这个预算本轮没有取得；并未以更多局部分支或更换余项名称宣称闭合。

## 5. 共同核心的真实容量和联合权

令$l=|\mathcal F|$，$C=Q_A\cap\bigcap_{B\in\mathcal F}Q_B$。在$C$上$\sum_B c_B=l$，用(5)之前的二阶矩估计与$m_B\le m_A$得
\[
\mu(C)\le\frac{3\sum_Bm_B}{2l^2}
\le\frac{3m_A}{2l}\le\frac{3m_A}{k}. \tag{7}
\]
这是任意真实完整$f$的来源质量界，不是边界体积估计。

但对固定原记录和固定$k$层，未删除样本的联合权准确为
\[
\Pi(d\xi)\frac{c_A(x)}{m_A}d\mu(x)
\prod_{i=1}^{k}
\frac{1_{m_{B_i}\in J_j,\,m_{B_i}\le m_A}
 t(B_i)c_{B_i}(x)}{m_{B_i}b_A(x)}d\sigma(B_i), \tag{8}
\]
另保原high/rank门、亲和好事件及命中门。交换父元组与$x$后出现$b_A(x)^{-k}$，不是固定族下的裸$\pi_A(dx)$。因此(7)不能被直接记为$3/k$原流损失。最终族还依赖旧$y,z$；不能条件于这个删后族后再声称旧双来源按原独立$\pi_A^2$分布。

目前需控制的是(8)的实际联合权在共同核心上的总量及跨元组重复，而非另加未经证明的密度帽。原high-Z/low-common门约束旧来源，不能自动约束人工$x$。同带可比和(7)已证；其全局加权费用仍未付。

## 6. 原门与全母账

旧$T_G,T_{\rm loc}$、high-Z、low-common及所有阶段限制始终留在原$\xi$，新父没有这些资格。局部并集给出的环境来源质量下界不能当作原$T_{\rm loc}$的反向预算，亦不能把不同中心、半径的局部质量互换。

原宽距离、低pe、初始、跳跃删除、未来被删来源、极小尺度比和全尺度拼接费用均保留；第458轮母系数$S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}$以及其它母倍率没有被本轮覆盖。式(6)之后的新$\varepsilon$仍须与所有旧吸收一起计入总账。一般上界未证明。

## 7. 实际验证及下一步决定

使用指定独立Python环境，以有理算术核对真实连续块的原非对称接受权、闭CDF中位门、条件命中积分，并在明确标作有限指标模型的样本上核删行和旧来源删除。原生场的$u_j$低，真实hard门为空，不能冒充高占用实例。有限指标场只用于检验相容的Gram/来源/命中，不认证立方体实现或完整原历史。扩大参数与标记压力仅限数值附件列明范围。

下一步应直接估计(8)的加权共同核心：已证明的静态$1/k$容量需要与来源归一化及选择重复同时使用。原门保在整族外部记录上，这是本轮可用于后续几何推导的增强；尚不构成整体预算。保留详细LaTeX源及必要复现，不编译PDF；实际扣额数据不可得。
