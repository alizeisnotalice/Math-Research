# R477：整族双外约束、共同来源核心及选择费用

## 1. 同一原流与整族常数

沿 R476，\(\mu=f\,dx\)、\(\sigma=q_A dA\)、\(m_A=\mu(Q_A)\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)，原实际流父边缘为 \(t(A)\sigma(dA)\)，\(0\le t\le S\)。附加独立 \(x\sim\pi_A\) 后，来源边缘为 \(u(x)\mu(dx)\)，实际父后验
\[
 P_x(dB)=\frac{t(B)c_B(x)}{m_Bu(x)}\sigma(dB).
\]
以下只扩展原记录，所有旧 \(y,z\)、stage、clock、path 与接受权保留。新父没有原历史。

令 \(\beta_x(A)=P_x\{m_B\le m_A\}\)。包含质量原子的闭 CDF 性质给 \(P_x\{\beta_x(A)\ge1/2\}\ge1/2\)。在该事件上取截断概率核 \(P_x1_{m_B\le m_A}/\beta_x(A)\)。R475 的逐来源亲和行界给每行至多
\(\alpha'=8rS/u(x)\)。取 \(k=\lfloor u(x)/(256rS)\rfloor\ge1\)。独立抽 \(k\) 个截断父时，有向非对角亲和和 \(O\) 满足
\[
 \mathbb EO\le\alpha'k(k-1),\qquad
 \Pr\{O\le4\alpha'k(k-1)\}\ge3/4.
\]
\(k=1\) 直接取概率一。好事件上删除原行和大于 \(1/2\) 的点，删除数至多
\[
 2O\le8\alpha'k(k-1)\le(k-1)/4.
\tag{1}
\]

捕获旧 \(y\) 或 \(z\) 的样本比例，其原扩展流积分至多 \(8rSW\)：截断分母 \(\beta\ge1/2\) 带来因子二，每侧使用 R476 的真实平方尾 \(2rSW\)。因此捕获比例大于 \(1/4\) 的记录质量至多 \(32rSW\)。再删除这些捕获父，保留至少 \(k/2\) 个父。对任意来源集 \(G\subset\{u\ge256rS\}\)，全部步骤不作条件化除法，得到正子流至少
\[
 \frac38R_G-32rS\mu(G),\qquad R_G=\int_Gu\,d\mu.
\tag{2}
\]
每个保留父 \(B\) 都满足 \(x\in Q_B\)、\(m_B\le m_A\)、\(y,z\notin Q_B\)，且保留 Gram 行非对角和不超过 \(1/2\)。此处只核整族合同及费用，不将 (2) 当作根阶闭合。

## 2. 共同核心是小质量集合：真实整族几何估计

固定一个上述成功记录及其保留族 \(\mathcal F\)，令 \(l=|\mathcal F|\)、\(F=\sum_{B\in\mathcal F}c_B\)。真实指标向量的 Gram 界给
\[
 \int F^2d\mu\le\frac32\sum_{B\in\mathcal F}m_B.
\]
所以对任何 \(a>0\)，
\[
 \mu\{F\ge a\}\le\frac{3}{2a^2}\sum_Bm_B.
\]
特别地，定义共同核心 \(C=Q_A\cap\bigcap_{B\in\mathcal F}Q_B\)，则
\[
 \boxed{\quad
 \mu(C)\le\frac{3}{2l^2}\sum_Bm_B
 \le\frac{3m_A}{2l}\le\frac{3m_A}{k}.
 \quad}\tag{3}
\]
同时 \(\mu(\cup_BQ_B)\ge(2/3)\sum_Bm_B\)。因此人工来源 \(x\) 必在父后验质量至多 \(3/k\) 的共同核心中，而族的总质量几乎可加。这保留全部真实质量，不把父的数量等同于来源总质量；若各 \(m_B\) 很小，则 \(\sum m_B\) 仍可远小于 \(m_A\)。

## 3. 为何 (3) 尚不能支付原积分

固定整数 \(k\) 的来源层，记
\[
 v_A(x)=\int_{m_B\le m_A}\frac{t(B)c_B(x)}{m_B}\sigma(dB)
 =u(x)\beta_x(A).
\]
在剪枝之前，原记录、人工源和 \(k\) 个父的准确联合测度为
\[
 d\Pi(\xi)\,\frac{c_A(x)}{m_A}d\mu(x)
 \prod_{i=1}^k
 \left[\frac{t(B_i)c_{B_i}(x)1_{m_{B_i}\le m_A}}
 {m_{B_i}v_A(x)}\sigma(dB_i)\right].
\tag{4}
\]
后续实际正限制全部乘在 (4) 上。固定父元组及原记录后，来源积分含
\[
 \frac1{m_A}\int_{Q_A\cap\bigcap_i Q_{B_i}}
 \frac{\mathbf1_{\mathrm{actual\ success}}(\xi,x,\mathbf B)}{v_A(x)^k}
 d\mu(x).
\tag{5}
\]
不能把它替成 \(\pi_A(C)\) 乘一个无偿概率：同一 \(x\) 决定整个父采样核，归一分母随来源变化。利用 \(\beta\ge1/2\) 与来源层下界虽能粗控 \(v_A^{-k}\)，随后父元组的真实中心积分出现 \(k\) 次共同选择费用；现有合同没有把这些费用降为一次共享 \(W\)。

此外，删掉捕获旧 \(y,z\) 的点后，最终族依赖旧来源。不能给定这个族后宣称旧源仍服从原无条件父后验，再用 \(S[1-\pi_A(\cup Q_B)]^2\)。该估计只对删 hit 之前、独立于旧来源的固定族及全族零 hit 事件合法，不能覆盖 (2)。

**唯一未闭合比较。** 需在 (4) 的真实选择权下，联合结算共同核心的小质量 (3) 与族的近可加质量，控制跨 \(x\)、跨元组的重复来源使用。原 high-rank、low-common 与低 \(T_G,T_{\rm loc}\) 约束的是旧 \(y,z\) 及原父，不是人工 \(x\) 的密度；它们目前尚未给 (5) 的有偿上界。故没有证明原完整流的新根阶价格，也不增加一个命名余项。这个核查明确排除了“共同核心质量 \(3/k\) 即原流保留比例 \(3/k\)”的错误用法。

## 4. 小型原生核验范围

下列六例是完整非均匀 \(f\) 与正 Lebesgue 中心块，核验 (3) 的几何适用性，不认证原高占用、rank、clock 或历史。二维原父边长二，四子父边长一，子中心为 \((\pm.49,\pm.49)\)。共同来源在零，四私有来源在 \((\pm.75,\pm.75)\)，旧双来源在 \((\pm.995,0)\)。来源包半边长 \(10^{-5}\)，所有中心块半边长 \(10^{-4}\)。私有与旧来源包质量各一，共同包质量 \(\varepsilon\)。实际 \(q_A=(6+\varepsilon)/4\)、\(q_B=1+\varepsilon\)，均在 \([1,2]\)，且处于同一 octave。

```python
from fractions import Fraction as F
from itertools import product
checks=0
signs=list(product((-1,1),repeat=2))
centers=[(F(0),F(0))]+[tuple(F(49,100)*s for s in v) for v in signs]
sides=[F(2)]+[F(1)]*4
sources=[(F(0),F(0))]+[tuple(F(3,4)*s for s in v) for v in signs]+[(F(199,200),F(0)),(-F(199,200),F(0))]
eta=F(1,10000);delta=F(1,100000)
for eps in map(F,('1/100','1/50','1/20','1/10','1/8','1/5')):
 masses=[eps]+[F(1)]*6
 capture=[]
 for A,R in zip(centers,sides):
  row=[]
  for x in sources:
   inside=all(abs(A[j]-x[j])+eta+delta<=R/2 for j in range(2))
   outside=any(abs(A[j]-x[j])-eta-delta>R/2 for j in range(2))
   assert inside or outside; checks+=1
   row.append(int(inside))
  capture.append(row)
 m=[sum(a*b for a,b in zip(row,masses)) for row in capture]
 assert all(F(1)<=m[i]/sides[i]**2<=F(2) for i in range(5)); checks+=1
 assert all(capture[i][0] and not capture[i][5] and not capture[i][6] for i in range(1,5));checks+=1
 overlap=[[sum(masses[x]*capture[i][x]*capture[j][x] for x in range(7)) for j in range(1,5)] for i in range(1,5)]
 assert all(sum(overlap[i][j]/(1+eps) for j in range(4) if i!=j)<=F(1,2) for i in range(4));checks+=1
 core=sum(masses[x] for x in range(7) if all(capture[i][x] for i in range(5)))
 union=sum(masses[x] for x in range(7) if any(capture[i][x] for i in range(1,5)))
 assert core<=F(3,2)*sum(m[1:])/16<=F(3,8)*m[0];checks+=1
 assert union>=F(2,3)*sum(m[1:]);checks+=1
print('PASS 6 native octave packet fields;',checks,'Fraction assertions; no high-occupancy/history claim')
```

实际运行输出：

```text
PASS 6 native octave packet fields; 240 Fraction assertions; no high-occupancy/history claim
```
