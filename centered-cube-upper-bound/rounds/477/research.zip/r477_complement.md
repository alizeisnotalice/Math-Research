# R477：全质量带闭秩保留、原来源删除与可比父族

本稿核准作用于完整原接受流的全带构造及全部费用。它以根阶来源价将剩余组织为质量可比、都避开原两来源的实际父族；未将不同辅助来源产生的族证明为全局不重复，故不是完整根阶闭合。

## 1. 闭秩只在保留父上达到半数

沿原 \(\Pi\)、\(\Pi_A=t(A)\sigma\)、\(0\le t\le S\)，所有历史留原记录 \(\xi=(A,y,z,\ldots)\)。完整质量区间分成 \(N\) 个对数宽至多 \(L\) 的半开带 \(J_j\)，最后带含右端点；
\[
 N\le1+\frac{\log r+n\log(b/a)}L.
\]
原附源 \(x\sim\pi_A\) 后定义
\[
 u_j(x)=\int_{J_j}\frac{t(B)c_B(x)}{m_B}d\sigma(B),\quad
 P_{x,j}(dB)=\frac{1_{J_j}(B)t(B)c_B(x)}{m_Bu_j(x)}d\sigma(B).
\]
零 \(u_j\) 无相应原质量。令
\(\beta_j(A,x)=P_{x,j}\{m_B\le m_A\}\)。**并非所有父的 \(\beta_j\ge1/2\)**；实际保留 \(\beta_j\ge1/2\)。对每个 \((x,j)\)，原父条件分布恰为 \(P_{x,j}\)，闭 CDF 性质给保留概率至少 \(1/2\)，包含质量原子。保留后使用概率核
\[
 Q_{x,j,A}(dB)=\frac{1_{m_B\le m_A}}{\beta_j(A,x)}P_{x,j}(dB).
                                                               \tag{1}
\]
\(\beta^{-1}\le2\) 只在保留域使用，不重新生成原来源或历史。

取 \(L_0=256rS\)，仅在 \(u_j(x)>L_0\) 抽样。所有低带的原质量
\[
 R_{\rm lowband}=\sum_j\int u_j1_{u_j\le L_0}d\mu\le NL_0W. \tag{2}
\]
这是完整全带一次结算，不是对每个阶段重复收费。设高带原质量为 \(R_{\rm high}\)，闭秩保留量至少 \(R_{\rm high}/2\)。\(S=0\) 时全流为零，以下假设 \(S>0\)。

## 2. 几何好事件和原 \(y,z\) 捕获费用

固定保留记录，令 \(\alpha=4rS/u_j(x)\)、\(k=\lfloor u_j/(256rS)\rfloor\ge1\)。来源 CDF 行界给任意实际父 \(B\)
\[
 \int\gamma_{BC}\,Q_{x,j,A}(dC)\le2\alpha,
 \qquad\gamma_{BC}=I_{BC}/\sqrt{m_Bm_C}.
\]
抽 \(k\) 个独立 \(Q\) 父，\(O=\sum_{a\ne b}\gamma_{B_aB_b}\)。若 \(k>1\)，事件
\[
 O\le8\alpha k(k-1)                                        \tag{3}
\]
概率至少 \(3/4\)；\(k=1\) 取必然事件。在 (3) 上删去原行和 \(>1/2\) 的索引，删除数至多
\(2O\le16\alpha k(k-1)\le(k-1)/4\)，因为 \(\alpha k\le1/64\)。

再令 \(p_{\rm hit}=Q\{c_B(y)=1\text{ 或 }c_B(z)=1\}\)。捕获任一原来源的样本数期望为 \(kp_{\rm hit}\)，故其大于 \(k/4\) 的概率至多 \(4p_{\rm hit}\)。原来源没有重采。

R476 的 inclusive CDF 计算，对每个 \(j\) 及固定 \(x\) 给
\[
 \int_{m_A\ge m_B}\frac{c_A(x)I_{AB}}{m_A^2}d\sigma(A)\le2r.
\]
保全部原 \(\ell(A,y,z)\) 后，仅估捕获支时上放 \(\ell\le S\)，并用 (1) 的归一化帽二，得到
\[
 \int_{\rm high,rankkeep}p_{\rm hit}\,d(\Pi\pi_A)
 \le8rS\sum_j\mu\{u_j>L_0\}\le8rSNW.                      \tag{4}
\]
其中单个原 \(y\) 与 \(z\) 各为 \(4rS\) 每带来源价；未归一版本各为 \(2rS\)。再乘捕获数 Markov 的四，才是 \(32rSNW\)，不是八。

在同一抽样上取 (3) 且捕获数 \(\le k/4\)，然后删掉坏行及所有捕获旧源的索引。所留族至少 \(k/2\) 个，满足
\[
 x\in Q_{B_a},\quad y,z\notin Q_{B_a},\quad
 e^{-L}m_A\le m_{B_a}\le m_A,\quad
 \sum_{b\ne a}\gamma_{B_aB_b}\le\tfrac12.                   \tag{5}
\]
全体映射可测：\(k\) 可测取整、有限乘积核、按索引确定删除；不条件化成功事件后忘记成功概率。设这条实际正扩充子流的质量为 \(R_{\rm pack}\)，则
\[
 R_{\rm pack}\ge\tfrac38R_{\rm high}-32rSNW,
 \qquad
 \boxed{R\le\tfrac{1024}{3}rSNW+\tfrac83R_{\rm pack}.}       \tag{6}
\]
取 \(L=\sqrt n\)，固定 \(r\) 时显式来源费为根阶。它并未支付最后一项；\(B_a\) 无原历史。旧原门全部仍在 \(\xi\) 上，未重扣旧费用。

## 3. 族质量与原局部门的准确连接边界

由 (5) 的真实来源 Gram 行和，
\[
 \mu\Big(\bigcup_aQ_{B_a}\Big)\ge\frac23\sum_a m_{B_a}
 \ge\frac{k m_A}{3e^L}.                                   \tag{7}
\]
证明为 \(\int(\sum c_{B_a})^2d\mu\le(3/2)\sum m_{B_a}\) 后的 Cauchy–Schwarz。没有体积换质量。

\(m_{B_a}\le m_A\) 与真实匹配只保证 \(R_{B_a}\le r^{1/n}R_A\)。故若 \(V_t(x)=\mu(x+[-t,t]^n)\)，
\[
 V_{r^{1/n}R_A}(x)\ge\frac23\sum_a m_{B_a}
 \ge\frac{k m_A}{3e^L}.                                   \tag{8}
\]
这是可直接核验的局部增长量，但在根阶带宽下恢复到 \(m_A\) 有 \(e^{\sqrt n}\) 损失。原低 \(T_{\rm loc}\) 使用原 \(y,z\) 上的 \(V_{R_A}\)，不是 (8)；将并集包含到原 \(y\) 周围最多得到尺度 \((1+r^{1/n})R_A\)，不能无代价退回 \(R_A\)。且低 \(T_{\rm loc}\) 给局部质量的下界，与 (8) 同向，不给来源列上界。原 \(U(y)\) 要求存在捕获 \(y\) 的实际共同父；族父都排斥 \(y,z\)，所以不能凭该族把其全部来源质量计入 \(U(y)\) 或 \(U(z)\)。

因此全带/秩费用和可比族构造成立，但本稿未从原低 \(T_G/T_{\rm loc}\) 获得额外联合付款。仍须在保原接受测度下结算不同 \(x\) 的 (7) 重复；不以 (8) 代替该缺失比较，也不再另拆阈值支。

## 4. 已实际运行的有理量词/常数检查

以下仅核闭秩原子、删行预算和全带系数，不认证 native 场或原历史。stdout：`PASS 42 Fraction closed-rank and full-band constant checks; no native history simulation`。

```python
from fractions import Fraction as F
checks=0
for probs in [[F(1,2),F(1,2)],[F(3,4),F(1,4)],[F(1,8),F(1,8),F(3,4)],[F(1,3)]*3]:
 c=F(0); kept=F(0)
 for p in probs:
  c+=p
  if c>=F(1,2):
   kept+=p
   assert 1/c<=2;checks+=1
 assert kept>=F(1,2);checks+=1
for k in [1,2,4,16,64]:
 for ratio in [F(1),F(1,2)]:
  alpha=ratio/(64*k)
  threshold=8*alpha*k*(k-1)
  assert 2*threshold<=F(k,4);checks+=1
  assert F(k)-2*threshold-F(k,4)>=F(k,2);checks+=1
  if k>1:
   expected=2*alpha*k*(k-1)
   assert expected/threshold==F(1,4);checks+=1
assert F(3,4)*F(1,2)==F(3,8);checks+=1
assert 4*(2*2*2)==32;checks+=1
assert 256+F(8,3)*32==F(1024,3);checks+=1
print('PASS',checks,'Fraction closed-rank and full-band constant checks; no native history simulation')
```
