"""Shared-origin shell with exact integer first-hit ordinals; float geometry."""
import functools,json,math,os,random,socket,sys
from multiprocessing import get_context

@functools.lru_cache(None)
def data(n):
    a=32*n
    p=[1];q=[1]
    for j in range(n):
        p.append(p[-1]*a);q.append(q[-1]*(a-2))
    m=p[-1]-q[-1];root=math.isqrt(n);assert root*root==n
    N=root*p[-1];k=math.ceil(math.log2(math.log(n)))
    return a,p,q,m,N,k,math.log1p(-2/a)

def layer_sample(lo,hi,m,vstep,rng):
    first=lo//m;end=(hi-1)//m
    ls=list(range(first,end+1))
    spans=[(max(lo,l*m)-l*m,min(hi,(l+1)*m)-l*m) for l in ls]
    w=[(b-a)/m*math.exp((l-first)*vstep) for l,(a,b) in zip(ls,spans)]
    h=rng.choices(range(len(ls)),weights=w)[0]
    return ls[h],rng.randrange(*spans[h])

def word(rank,p,q,a):
    out=[];hit=False
    for j in range(len(p)-2,-1,-1):
        tail=p[j];boundary=tail-q[j]
        if hit: digit,rank=divmod(rank,tail)
        elif rank<tail: digit=0;hit=True
        elif rank>=tail+(a-2)*boundary:
            rank-=tail+(a-2)*boundary;digit=a-1;hit=True
        else:
            digit,rank=divmod(rank-tail,boundary);digit+=1
        out.append(digit)
    assert hit and rank==0
    return out

def loss(x,u,y,s):
    marks=[];half=(1+6/len(x))*s
    for xi,yi in zip(x,y):
        lo=(yi-half-xi)/u;hi=(yi+half-xi)/u
        if lo>-1:marks.append((lo,0))
        if hi<1:marks.append((hi,1))
    blocks=[]
    for _,b in sorted(marks):
        blocks.append((b,1))
        while len(blocks)>1:
            p,m=blocks[-2];q,n=blocks[-1]
            if p*n<=q*m:break
            blocks[-2:]=[(p+q,m+n)]
    return -sum(k*math.log(k/m) for p,m in blocks for k in (p,m-p) if k)

def run(job):
    n,seed=job;a,p,q,M,N,K,g=data(n)
    rng=random.Random(7342708+100000*n+seed);end=(K+2)*N
    def geo(l,rank):
        s=math.exp(l*g)
        return s,[s*((2*j+1)/a-1) for j in word(rank,p,q,a)]
    def target(lo):
        l,r=layer_sample(lo,end,M,n*g,rng);s,y=geo(l,r)
        return (s,[v+s/a*rng.uniform(-1,1) for v in y],
                [v+s/a*(1 if k%2 else -1)*rng.uniform(.5,1) for k,v in enumerate(y)])
    def high(x,s,idx):
        si,y=geo(*divmod(idx,M))
        return si<=2*(1+1/a)*n*s/math.log(n) and loss(x,(1+1/a)*s,y,si)>.375*math.log(n)
    while True:
        i=rng.randrange(N)
        if rng.random()<2**(-i/N):break
    sj,x,corner=target(N);deep,xd,_=target(K*N)
    # Conditional positive-volume near-corner sub-box within this same owner type
    # has relative volume 4**(-n); no additional weight enters V_T.
    pre=[high(xd,deep,rng.randrange(h*N,(h+1)*N)) for h in range(K)]
    def volume(lo):
        f=lo//M;e=(end-1)//M
        return math.exp(n*g*f)*sum((min(end,(l+1)*M)-max(lo,l*M))/p[-1]*math.exp(n*g*(l-f)) for l in range(f,e+1))
    lam=M/N*math.log(2);J,e=divmod(end,M);z=n*g-lam
    D=(-math.expm1(-lam))*(-math.expm1(J*z))/(-math.expm1(z))+ math.exp(J*z)*(-math.expm1(-e/N*math.log(2)))
    return [n,seed,int(high(x,sj,i)),int(high(xd,deep,i)),list(map(int,pre)),volume(N),volume(K*N),D,int(high(corner,sj,i)),os.getpid()]

if __name__=='__main__':
    parity,w,reps=map(int,sys.argv[1:4]);dims=list(map(int,sys.argv[4:]))
    jobs=[(n,j) for n in dims for j in range(parity,reps,2)]
    with get_context('fork').Pool(w) as pool: rows=pool.map(run,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,args=sys.argv[1:],workers=len(set(v[-1] for v in rows)),rows=[v[:-1] for v in rows])))
