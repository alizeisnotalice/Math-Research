"""Interval sums over every true radius layer, comparison with float ledger."""
import json,math
from flint import arb,ctx
ctx.prec=256
data=json.load(open('mini2.json'))['rows']
out={}
for n in sorted(set(r[0] for r in data)):
    a=32*n;root=math.isqrt(n);b_inv=a**n
    M=b_inv-(a-2)**n;N=root*b_inv
    K=math.ceil(math.log2(math.log(n)));end=(K+2)*N
    g=(arb(a-2)/a)**n
    D=arb(0);V=arb(0);Ddeep=arb(0)
    for l in range((end-1)//M+1):
        start=l*M;stop=min((l+1)*M,end)
        d=g**l
        clock=-(arb(2).log()/N)
        D+=d*(clock*start).exp()*(-(clock*(stop-start)).expm1())
        V+=d*max(0,stop-max(start,N))/b_inv
        Ddeep+=d*max(0,stop-max(start,K*N))/b_inv
    r=next(r for r in data if r[0]==n)
    for truth,v in zip([V,Ddeep,D],r[5:8]):
        assert abs(arb(v)/truth-1)<arb('1e-12')
    cap=V/(4*root*D)
    out[n]=dict(normalization='all volumes divided by 2^n',initial_ord='N=sqrt(n)*a^n',
        depth_exponent=K,total_layers=(end-1)//M+1,VT=str(V),deep_volume=str(Ddeep),
        greedy_value=str(D),normalized_excess_upper=str(cap))
print(json.dumps(out,indent=2))
