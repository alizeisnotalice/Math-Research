# Exact sorted-threshold geometry (parent draft)

Status: exact representation, awaiting independent audit. This is not a new global bound or an extremizer theorem.

Fix 0<ell<g, xi_t proportional to t, T=log(g/ell), and a measurable core C of positive finite nu mass inside the FULL initial source support. Write C_i(v)>0 for the physical coordinate overlaps. Set a_i(v)=min(T,max(0,log(C_i(v)/xi_ell))), and sort them increasingly a_(1)<=...<=a_(n). Define b_i=ess sup_{v in C} a_(i)(v). These are constants for this fixed row and core, not receiver-independent universal parameters.

For Lebesgue-a.e. s in (0,T), k_v(ell exp s)=#{i:a_i(v)<s}, for nu-a.e. v. Let r_C(s)=ess inf_C k_v(ell exp s). Then

    r_C(s)=#{i:b_i<s}  (a.e. s),
    Gamma_C(v)=integral_0^T (k_v-r_C) ds
              =sum_i (b_i-a_(i)(v)) >=0  (nu-a.e. v in C).

Proof. For fixed s, r_C(s)>=i iff a_(i)(v)<s for almost every core source. If s>b_i this holds; if s<b_i it fails on a positive measure set. The only unclassified s are the finite set {b_i}; therefore the score identity holds almost everywhere. Fubini applies to bounded measurable integrands on finite measure spaces. Integrating 1_{a<s} over (0,T) gives T-a, hence the formula. Clipping correctly handles coordinates already saturated at ell and those not saturated before g. Strict equality at a threshold has zero log-time measure and does not remove any source deletion charge.

Interpretation. The common-clock loss is the L1 deficiency of a sorted threshold signature below the core's coordinatewise essential upper envelope. Sorting uses the common scalar threshold only; it is not a physical coordinate permutation or a change of the receiver x. This can be used to evaluate a proposed core without guessing an exponent.

Unpaid global issues. A partition into such cores still requires each core's FULL-initial complementary source growth, including subsequently deleted sources. Neither the existence of inexpensive cores nor an affordable cover follows from this identity. An entropy count of boxes in signature space would require its own dimension and receiver/source accounting. No new root-order conclusion is inferred here.
