# R174: a canonical capacity core with its complement and deletion charge paid

Status: proved constructive reduction for the original J-share positive traffic. The construction uses the original common input and requires no assumed source moment or low-score ordering. It pays the removed sources and guarantees an affordable mass-clock charge for all remaining rows. The remaining core threshold heterogeneity is explicit and is not proved globally affordable. The general weak bound remains open.

## 1. Original scope and construction

Keep the complete R174 contract. In particular nu_V<=beta_V, sum_V beta_V<=f, p_y=P_{s,L}(x-y), Q=(K1+K2+J)/3, J=P_{1,b}, and all three constituents of Q are common legal original future kernels at the fixed receiver. Thus

    int Q_v nu_V(dv)<=q,
    p_y e_g(y)>=2Kq on high.

The original J-slot is A_v=1_good rho_v J_v/(3Q_v), with the same alpha and residual rho as before. The original posteriors, supports and weights are never replaced. Fix a number eta in (0,1), independently of the row. On each original high row set

    S=Z_{ell+},
    B_eta={u in S: Q_u>=p_y/(2K eta)},
    C_eta={u in S: Q_u<p_y/(2K eta)}.                       (GC1)

This is a measurable, time-fixed partition of the entire initial support. In particular it includes sources that will later be deleted. It is a deterministic prescription from the original row, not a search for a favorable subset. Membership may depend on x,y,V,j through the original data; it does not depend on the integration clock t. Both groups stay in every original Pi_t.

## 2. Same-input capacity controls unweighted removed mass

Positivity, the original FIRST inequality and high give

    nu(B_eta)<= (2K eta/p_y) int_{B_eta} Q_u nu(du)
             <=2K eta q/p_y<=eta e_g.                      (GC2)

This bounds the full-initial unweighted mass, not just terminal posterior mass. Because w_g<=1 and Z_g subset S,

    nu(C_eta)>=nu(S)-nu(B_eta)>=(1-eta)e_g>0,
    int_{Z_g intersect C_eta} w_g dnu>=(1-eta)e_g>0.         (GC3)

Thus the core and its terminal mass are automatically nonzero on every nonzero high row. There is no undefined-essential-infimum exception. Deleted B sources are included in (GC2); their expense will not disappear when a source is deleted.

## 3. The growth charge is bounded without ordering assumptions

For the canonical core define the fixed-support clock

    r(t)=essinf_{C_eta} k_t,
    c(t)=exp(-int_ell^t r(s) ds/s),   c(ell)=1,
    Gamma_C(v)=int_ell^g [k_t(v)-r(t)] dt/t,
    lambda=(c(g)/e_g)int_ell^g int_{B_eta}
                  (r(t)-k_t(u))_+ w_t(u)/c(t) nu(du) dt/t.

The R173 theorem retains this exact charge, including every source in full initial B throughout the time integral. There is a useful general inequality for any fixed removed group B, regardless of score order:

    int_B (r-k_u)_+ w_t(u)/c(t) nu(du)
                    <= r(t)nu(B)/c(t),
    int_ell^g r(t)/c(t) dt/t = 1/c(g)-1.

The first line uses only k_u>=0 and w_t<=1; the second uses c(ell)=1 and absolute continuity. Consequently

    lambda<=(1-c(g))nu(B_eta)/e_g
           <=eta(1-c(g))<eta<1.                            (GC4)

This eliminates the lambda>=1 branch of the R173 theorem for this explicit core. No statement that the reduced total mass is monotone is required. No moving support clock or uncharged jump is introduced. All original deletions are covered by the full-initial growth numerator.

For v in C_eta set

    R_C=int_ell^g r(t)dt/t,   c(g)=exp(-R_C),
    Theta_eta(v)=Gamma_C(v)-log(1-eta+eta exp(-R_C)).         (GC5)

The exact effective R173 loss Gamma_C-log(1-lambda) is at most Theta_eta. In terms of the physical endpoint weight ratio,

    exp Theta_eta(v)
        =[w_ell(v)/w_g(v)]/[(1-eta)exp(R_C)+eta].

All these quantities are computed from the original physical support and its canonical cut. They do not require an unknown posterior moment. The proven R173 inequality now gives, for every time-fixed terminal source gate H supported in C_eta,

    I[HA] <=e_g^(-1)int_{C_eta} HA w_g
                                      [exp Theta_eta-1]dnu. (GC6)

As in R173, I is the original positive score-pair integral, other original pair gates can remain, and the v slot is the good slot in (k_v-k_u)_+. Gamma_C>=0 and Theta_eta>=0 almost everywhere on the core.

## 4. The entire removed group has a root-order J price

On B_eta the original coefficient satisfies, without a condition on blocker mass,

    p_y^2 A_v^2/J_v
       =1_good rho_v^2 p_y^2 J_v/(9Q_v^2)
       <=(4K^2 eta^2/9)J_v.                                (GC7)

Use the independently proved original global energy and zero-order bounds

    E_J<=n W_beta/(2K),   Z_J<=log(2)W_beta/(2K).

They include the original eligible/high masks, actual dx and time measure. The masked companion on B_eta is bounded by (4K^2 eta^2/9)Z_J because its posterior lower-score mass is at most one. Cauchy on the original positive pair measure, followed by the original hard cap 16/3 and outer factor 2Lambda, therefore gives

    RawPositive_J[B_eta]
       <=(32Lambda/9) eta sqrt(n log 2) W_beta.             (GC8)

This pays every active removed slot, including ones with arbitrarily large original Gamma. It does not remove the B sources from either posterior when paying core traffic. Q is used only in the capacity inequality (GC2) and the coefficient comparison (GC7). No spatial normalization of the adaptive Q is asserted. J is the fixed probability kernel used in E_J and Z_J.

## 5. Complete disjoint accounting after the canonical cut

Let S_v=log(P_{s,b}(x-v)/J_v), with the original common legal future kernel. Choose M>=0 and h real. Partition terminal core slots into

    P_eta={Theta_eta<=M},
    Q_eta={Theta_eta>M and S_v-Theta_eta>=h},
    R_eta={Theta_eta>M and S_v-Theta_eta<h}.                (GC9)

The original good inequality p A_v w_g(v)<=KJ_v/3 and (GC6) give

    p I[HA]<= K/(3e_g)int H J_v[exp Theta_eta(v)-1]nu(dv).

On P_eta the last factor is at most exp(M)-1. On Q_eta, J_v[exp Theta_eta(v)-1]<=exp(-h)P_{s,b}(x-v). Drop source gates only from nonnegative integrands, then use the original high/FIRST inequality

    int_high beta_V(dy)/e_g
       <=(2Kq)^(-1)int p_y beta_V(dy)<=1/(2K).

Retain the unique original j indicator until the upper bound is independent of j. For the source price integrate J in the actual x variable; for the receiver price sum V first and use sum_V P_{s,b}nu_V<=q. Counting hard16/3 and outer2Lambda once yields

    RawPositive_J[P_eta]<=(16Lambda/9)(exp M-1)W_beta,
    RawPositive_J[Q_eta]<=(16Lambda/9)exp(-h)E int_D q dx.  (GC10)

Thus the unconditional disjoint reduction is

    RawPositive_J[all]
      <= (16Lambda/9)[2eta sqrt(n log2)+exp M-1]W_beta
         +(16Lambda/9)exp(-h)E int_D q dx
         +RawPositive_J[R_eta].                           (GC11)

Every original terminal slot is assigned exactly once: B_eta, P_eta, Q_eta or R_eta. There is no unassigned B group, no lambda>=1 row and no extra charge for deleted sources. The only remaining term within this J-share is R_eta. Negative terms in the original signed row have not been consumed or duplicated.

For example take eta=1/2, M=(log n)/2 and h=log(16Lambda/(9epsilon)). The displayed paid price is

    (16Lambda/9)[(1+sqrt(log2))sqrt(n)-1]W_beta
                                      +epsilon E int_D q dx.

For a factor L_n>=1 use M=(log n)/2+log L_n. The remaining term in (GC11) is not asserted to satisfy either price. Constants are within the original common a,b window; no free summation of independent windows or new history-normalization statement is introduced. The result concerns the J share. A root source price for the other mother-kernel shares is not proved.

## 6. Exact physical form of the remaining core loss

The remaining obstacle is now a specified geometric quantity on a core selected by the original shared capacity. Let Tlog=log(g/ell), and for each physical source z define clipped coordinate thresholds

    a_i(z)=clip(log(C_i(y,z)/xi_ell),0,Tlog).

Write a_(1)(z)<=...<=a_(n)(z) for their increasing rearrangement and

    b_i=esssup_{z in C_eta} a_(i)(z).

For almost every logarithmic clock s in (0,Tlog),

    r(ell exp s)=#{i:b_i<s},
    R_C=n Tlog-sum_i b_i,
    Gamma_C(v)=sum_i [b_i-a_(i)(v)].                       (GC12)

To verify the first equality, the essential lower bound on the number of a_i(z)<s is the largest index i for which a_(i)(z)<s almost everywhere. This agrees with b_i<s except at the finite set of b_i endpoints, which are null in logarithmic time. Integration gives the other two formulas. All essential extrema use the actual nu restricted to the full initial canonical core. Each b_i is a measurable essential supremum; a single common full-measure set handles the finitely many coordinates.

Consequently the remaining region is exactly described by the original gates, Q_v<p_y/(2Keta), and

    sum_i[b_i-a_(i)(v)]-log(1-eta+eta exp(-R_C))>M,
    S_v<sum_i[b_i-a_(i)(v)]-log(1-eta+eta exp(-R_C))+h.     (GC13)

This identity is a description, not a concentration bound. A scalar low-Q test can arise from highly anisotropic sources, and the essential threshold envelope can use different positive-mass witnesses at different times. No inequality controlling the sum in (GC13) by log n follows merely from (GC2). The original good and positive-residual conditions are still imposed on active v; they have not been replaced by independent threshold arrays.

## 7. Bounded checkpoint and the next exact obligation

This round has a concrete selection and complete payment for its removed group and growth correction. The further proposed implication that the remaining sum of threshold deficits is generally small has not been proved. The same-input numerical certificate reported by the parent has no positive active slot at its certified old sample (good or residual removes those candidates); it therefore supplies neither a counterexample nor a proof of the remaining estimate. No toy A=1 replacement is used here.

For the original remaining region R_eta, one exact sufficient energy obligation is to control the masked companion with its original coefficient. The integral below runs only over the original eligible/high rows and retains their original history masks and unique j selection:

    E sum_V int dx beta_V(dy) dt/t int_{Z_t} nu(dv)
      1_{R_eta}(v)1_good rho_v^2 p_y^2 J_v/(9Q_v^2)
      [w_t(v)/e_t^2]
      int_{Z_t}1_{k_t(u)<k_t(v)}w_t(u)nu(du).               (GC14)

An O(polylog(n)W_beta) bound for (GC14) would combine with the already paid E_J to give the desired root source price for this remainder. It is not asserted here. The alternative is an epsilon receiver price for a portion of this actual same-input domain together with an energy bound on its complement. Either route must use the joint receiver geometry, original residual alpha and shared source masses; controlling Q or threshold signatures separately is insufficient to complete the present proof.

The next mathematical decision is therefore concentrated: analyze the physical Q-sublevel core's multicoordinate threshold spread under actual good/rho and receiver integration, or pay the explicit original companion (GC14). There is no need to revisit core existence, the removed-slot ledger, or the deletion charge. No new conditional moment has been counted as a theorem, and no broader search or auxiliary route is part of this checkpoint.
