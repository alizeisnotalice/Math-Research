# R174 same-atomic-input physical coefficient probe

The selected common atomic input does not produce positive original-form traffic in these28 rows. At both directed-interval refinements N64 and N128, eight rows pass the high gate, but every such row has all terminal A=good*rho*J/(3Q) slots certified zero. The other20 fail high. Thus the high-gated original positive integral and both masked and unmasked Cauchy companions are exactly zero throughout this finite list.

This conclusion uses the physical kernels and the same q,nu in alpha. It does not replace A by1, omit alpha, or borrow the zero-beta external y=0 row. The atomic beta is the full frozen R169 completion, with its positive completion mass defined by the original exact formula. It remains a synthetic atomic source measure, not an original beta_V lineage or positive L1 input.

## Stages and decisive gates

The four actual outer beta locations are used in every configuration. There are no newly chosen C arrays.

| Stage/configuration | High-pass rows out of4 | Positive A on a high row |
|---|---:|---:|
| Certified x0 geometry, diagnostic K1 | 2 | 0 |
| Same point, K4 | 1 | 0 |
| Same point, K16 or K64 | 0 each | 0 |
| Receiver x0 minus .01 e1 | 2 | 0 |
| Receiver x0 plus .01 e1 | 2 | 0 |
| x0 with L=.85 | 1 | 0 |

At baseline K1, outer y=x0 is high but all three inner sources fail good. At outer y=r, the first inner source fails good; the two good inner sources have rho=0. The positive raw rho on a bad source is not an original A-positive slot. This is why the earlier large terminal-ratio/average-gain point diagnostics do not automatically exhibit original positive traffic.

K1,4,16,64 are diagnostic parameter choices. The theorem-level K is unverified. This round separately checks j=0 through the actual ratio-bin inequalities, D4=1 through the inherited D formula for every epsilon_G<=1, and strict softness. These are new calculations, not claims that R169/R171 had instantiated all those original gates.

## What is computed

For each actual outer row, the JSON retains p_y, all physical C(y-v), wg, Delta,TDelta,K0,J,Q, original-form good and high margins, U, same alpha, rho,A, terminal Pi, lower-score posterior bounds and explicit terminal future expectations. Future expectations with and without good are named separately. None is declared a new paid moment bound.

The positive integral is int p_y A_v delta+ Pi_v Pi_u dlogxi. Cb is int(p_y^2 A_v^2/J_v)b_v Pi_v dlogxi; C0 removes b_v. The unmasked J-weighted squared energy is retained separately: A=0 does not imply EJ=0. Its eight high-row enclosures are valid but coarse and are marked unresolved at the displayed accuracy target. No further integration refinement is needed to certify zero positive traffic/companions.

Physical C intervals and all score thresholds are retained. Where integration is required, positive rectangle/Darboux bounds cover every threshold-uncertainty band and the uncertain terminal clock endpoint, using directed arithmetic and certified logarithms. There is no ordinary-quadrature error estimate disguised as an interval proof. The initial far-window endpoint is xi=.5 and its upper endpoint is h=g exp(-1/400); terminal Pi uses g. Z=all is explicitly conditional, without an original history or deletion construction.

Bad inner-source diagnostics also retain p_u,Q_u,p_y wg(y-u)/p_u and membership in the current L and enlarged Lplus hard cubes. There is no actual positive v-to-u traffic to assign to those bad slots on a high row in this sample.

## Input and receiver qualifications

At x0,L=.9 the exact current equality and all-u/all-scale pointwise completion assertion are inherited from the R169 atomic certificate. This is not original global FIRST for an L1 input. The moved receiver rows do not inherit that continuum certificate; their finite current/future tests have independent statuses. In particular the positive receiver perturbation fails the displayed current upper test. The L=.85 row does not inherit current equality even though the original atomic all-future assertion at x0 remains available. q is never reset to q(x).

Run `python3 centered-cube-upper-bound/rounds/174/work/physical_companion_probe.py`. Both N64/128 outputs and all28 rows are retained. HERE-local dependency keys are filenames for migration; external frozen dependencies retain absolute paths and SHA256 hashes. No packages are installed, receiver integral computed, exponent fitted, or FULL claim made. The finite conclusion is lack of original-form positive-pressure intersection in this certified seed and its selected diagnostics, not general coverage of R173 gates.
