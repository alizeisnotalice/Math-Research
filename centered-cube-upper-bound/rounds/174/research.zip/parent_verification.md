# Parent verification, R174

The parent read the complete final global_core_geometry.md and source_moment_geometry.md, retained the unproved R_eta remainder, and checked the raw constant against the R173 frozen energy proof. Independent Sol audit is separately bound by SHA.

Actual isolated replay directory: /Users/zhengzhihao/Desktop/T/output/r174_parent_driver_replay_20261016. Both scripts were copied there with their HERE-local dependencies and run using bundled Python 3.12. Physical run completed in 16.878 seconds: 28 rows at each N64/128, 8 high-pass per level, 0 high-positive-A intersection; high-gated positive and both companions exactly zero. Unmasked EJ retains its coarse accuracy-unresolved intervals. Core script returned 60 exact passes.

Parent loaded both original and replay JSON files, removed only runtime metadata, and asserted all remaining fields identical; both passed. Sol separately read and replayed core script and compared its full JSON. No finite result is a general proof or original history/L1 realization. No PDF compiled.

The replay driver repeats these two commands, verifies archive bytes, and compares non-runtime JSON. External frozen kernels and completion inputs remain absolute local dependencies; their actual hashes are in physical_companion_probe.json. This bundle is not independently portable without them.
