#!/usr/bin/env python3
"""R174 common atomic-input physical-form coefficient probe; no FULL claim."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from decimal import Decimal
import importlib.util,json,hashlib,sys,time
HERE=Path(__file__).resolve().parent
BACK=Path('/Users/zhengzhihao/Desktop/T/output')
TOOL=BACK/'centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py'
COMPLETION=BACK/'centered_cube_round169_20261016_final_checkpoint/completion_certificate.json'
POINT=BACK/'centered_cube_round171_20261016_final_checkpoint/numeric_point_certificate.json'
LOCATORS=BACK/'centered_cube_round172_20261016_final_checkpoint/geometry_contract_locators.md'
sp=importlib.util.spec_from_file_location('r174_frozen_interval',TOOL);ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct)
I=ct.I;ZERO=Decimal(0);ONE=Decimal(1)
N=4;S=F(1,4);QFIX=F(9,2500);A_SCALE=F(1,2);B_SCALE=F(1);LAM=F(128,119)
X0=(F(51,100),F(2,5),F(2,5),F(2,5))
POS=((F(53,50),F(19,20),F(19,20),F(19,20)),(F(-3,5),)*4,X0)
RPOS=tuple(x+F(9,20) for x in X0);OUTER=POS+(RPOS,)
NU=(F(3,25),F(2749,3125),F(1,3125))

def fs(x):return str(x)
def ivec(x):return x.out()
def minimum(a,b):return I(min(a.lo,b.lo),min(a.hi,b.hi))
def clip(a,lo=ZERO,hi=ONE):return I(max(lo,min(hi,a.lo)),max(lo,min(hi,a.hi)))
def status(a):return 'pass' if a.lo>=0 else ('fail' if a.hi<0 else 'ambiguous')
def convert(a):return I(a.lo,a.hi)
def lograt(q):return ct.log_rational(F(q))
def dot(weights,values):return sum((I(w)*v for w,v in zip(weights,values)),I(0))
@lru_cache(None)
def Cphysical(d,Nq):return I(1) if d==0 else ct.iv.C(abs(d),Nq)
@lru_cache(None)
def kernel(s,lo,hi,delta,Nq):return ct.kern(s,I(lo,hi),delta,Nq)
def kern(s,scale,x,v,Nq):return kernel(s,scale.lo,scale.hi,tuple(a-b for a,b in zip(x,v)),Nq)
def weights(C,xi):return [ct.prod((z/xi).capped_one() for z in row) for row in C]
def params(L):
    g=I(L).sqrt();ell=I(1)+lograt(F(4));cj=F(1);cp=F(4,5)
    Dbranch=ell.sqrt()/(I(8)*I(LAM))-I(16)/(I(3)*ell.sqrt());assert Dbranch.hi<1
    margins=dict(bin_lower=I(L)-I(cp)*g,bin_upper=g-I(L),tau_to_g=g-I(F(1,2)),g_to_b=I(1)-g)
    assert all(z.lo>=0 for z in margins.values())
    return dict(g=g,ell=ell,D=I(1),D_branch_upper_epsilon_le_1=Dbranch,margins=margins,cj=cj,j=0,Lplus=min(F(1),F(5,4)*L))
def Hparams(par,Nq):
    H0=par['g']*(I(F(3,4))+I(F(1,4))*ct.phi_range(I(F(1,2)),Nq))*par['ell'].sqrt().sqrt().sqrt()
    H=clip(H0,I(F(1,2)).lo,I(1).hi)
    return H0,H

def common_completion(Nq):
    knu=[kern(S,I(F(9,10)),X0,v,Nq) for v in POS]
    kr=kern(S,I(F(9,10)),X0,RPOS,Nq)
    mass=(I(QFIX)-dot(NU,knu))/kr;assert mass.lo>0
    return mass

def score_bounds(C,xi):
    return [(sum(z.hi<xi.lo for z in row),sum(z.lo<xi.hi for z in row)) for row in C]
def posterior(C,xi):
    wt=weights(C,xi);e=dot(NU,wt);assert e.lo>0
    return wt,e,[clip(I(m)*w/e) for m,w in zip(NU,wt)]
def lower_mass(C,xi):
    wt,e,pi=posterior(C,xi);ks=score_bounds(C,xi);b=[]
    for v in range(3):
        lo=sum((F(pi[u].lo) for u in range(3) if ks[u][1]<ks[v][0]),F(0))
        hi=sum((F(pi[u].hi) for u in range(3) if ks[u][0]<ks[v][1]),F(0))
        b.append(clip(I(I(lo).lo,I(hi).hi)))
    return pi,b,ks

def bound_integrand(row,C,xi):
    pi,b,ks=lower_mass(C,xi);out={key:I(0) for key in ('positive_pA','EJ','Cb','C0')}
    for v in range(3):
        coeff=row['p']**2*row['A'][v]**2/row['J'][v]
        out['Cb']=out['Cb']+coeff*b[v]*pi[v];out['C0']=out['C0']+coeff*pi[v]
        for u in range(3):
            dlo=max(0,ks[v][0]-ks[u][1]);dhi=max(0,ks[v][1]-ks[u][0]);d=I(dlo,dhi)
            out['positive_pA']=out['positive_pA']+row['p']*row['A'][v]*d*pi[v]*pi[u]
            out['EJ']=out['EJ']+row['J'][v]*(d**2)*pi[v]*pi[u]
    return out

def rigorous_integrals(row,C,upper,subdivisions):
    # Rectangle/Darboux enclosure, including C-uncertainty bands and endpoint uncertainty.
    if row['high']=='fail':
        reason='high gate fails'
        return dict(method='exact zero after original-form gates',reason=reason,values={k:I(0).out() for k in ('positive_pA','EJ','Cb','C0')},resolved=True)
    lo=F(1,2);uhi=F(upper.hi);ulo=F(upper.lo)
    cuts={lo,uhi,ulo}
    for cs in C:
        for c in cs:
            cuts.update(q for q in (F(c.lo),F(c.hi)) if lo<q<uhi)
    knots=sorted(cuts);tot={key:I(0) for key in ('positive_pA','EJ','Cb','C0')}
    for a,b in zip(knots,knots[1:]):
        for j in range(subdivisions):
            aa=a+(b-a)*F(j,subdivisions);bb=a+(b-a)*F(j+1,subdivisions)
            vals=bound_integrand(row,C,I(I(aa).lo,I(bb).hi));length=lograt(bb/aa)
            for key,value in vals.items():
                contribution=value*length
                if bb>ulo:contribution=I(0,contribution.hi)
                tot[key]=tot[key]+contribution
    if row['high']=='ambiguous':tot={key:I(0,z.hi) for key,z in tot.items()}
    return dict(method='directed positive rectangle/Darboux enclosure, score/C bands retained',positive_companion_exact_zero=all(z.hi==0 for z in row['A']),subdivisions_per_threshold_band=subdivisions,
                values={key:z.out() for key,z in tot.items()},resolved=all(F(z.hi)-F(z.lo)<=max(F(1,10**40),abs(F(z.hi))*F(1,1000)) for z in tot.values()))

def compute(config,yindex,Nq):
    x,L,K=config['x'],config['L'],config['K'];par=params(L);g=par['g'];H0,H=Hparams(par,Nq)
    h=g*ct.iv.exp_neg(F(1,400));T=1/(g**4*par['ell'].sqrt());mass=common_completion(Nq);beta=[I(z) for z in NU]+[mass]
    y=OUTER[yindex];C=[[Cphysical(a-b,Nq) for a,b in zip(y,v)] for v in POS]
    wg=weights(C,g);w0=weights(C,I(F(1,2)));wh=weights(C,h);Delta=[(a-b).nonnegative() for a,b in zip(w0,wh)];TD=[T*z for z in Delta]
    p=kern(S,I(L),x,y,Nq);J=[kern(F(1),I(1),x,v,Nq) for v in POS]
    K1=[kern(S,I(L),x,v,Nq) for v in POS];K2=[kern(S,I(par['Lplus']),x,v,Nq) for v in POS]
    K0=[kern(S,H,x,v,Nq) for v in POS];Kstar=[kern(S,I(1),x,v,Nq) for v in POS]
    Qv=[(a+b+c)/3 for a,b,c in zip(K1,K2,J)];goodmargin=[I(K)*q-p*w for q,w in zip(Qv,wg)];good=[status(z) for z in goodmargin]
    U=[I(0) if flag=='fail' else minimum(td,k) if flag=='pass' else I(0,minimum(td,k).hi) for flag,td,k in zip(good,TD,K0)]
    QJ=dot(NU,J);alpha=(I(QFIX)-dot(NU,U))/QJ
    rho=[]
    for td,k,j in zip(TD,K0,J):
        if td.hi==0:rho.append(I(0))
        elif td.lo>0:
            value=(1-(k+alpha*j)/td).nonnegative();rho.append(clip(value) if alpha.lo>=0 else value)
        else:rho.append(I(0,1) if alpha.lo>=0 else I(0,'Infinity'))
    A=[I(0) if flag=='fail' else ro*j/(3*q) if flag=='pass' else I(0,(ro*j/(3*q)).hi) for flag,ro,j,q in zip(good,rho,J,Qv)]
    eg=dot(NU,wg);highratio=p*eg/I(2*K*QFIX);high=status(highratio-I(1))
    row=dict(p=p,A=A,J=J,high=high)
    integrals=rigorous_integrals(row,C,h,8 if Nq==64 else 16)
    pig,bg,kg=lower_mass(C,g)
    moment=lambda vals:sum((pv*z for pv,z in zip(pig,vals)),I(0))
    moments=dict(E_J=moment(J),E_Kstar=moment(Kstar),E_Kstar_over_J=moment([a/b for a,b in zip(Kstar,J)]),
                 E_J_over_wg2=moment([j/(w**2) for j,w in zip(J,wg)]),
                 E_rho2_J_over_wg2=moment([r**2*j/(w**2) for r,j,w in zip(rho,J,wg)]),
                 E_rho2_b_J_over_wg2=moment([r**2*b*j/(w**2) for r,b,j,w in zip(rho,bg,J,wg)]),
                 E_good_rho2_J_over_wg2=moment([I(0) if flag=='fail' else r**2*j/(w**2) if flag=='pass' else I(0,(r**2*j/(w**2)).hi) for flag,r,j,w in zip(good,rho,J,wg)]),
                 E_good_rho2_b_J_over_wg2=moment([I(0) if flag=='fail' else r**2*b*j/(w**2) if flag=='pass' else I(0,(r**2*b*j/(w**2)).hi) for flag,r,b,j,w in zip(good,rho,bg,J,wg)]))
    fcur=sum((b*kern(S,I(L),x,z,Nq) for b,z in zip(beta,OUTER)),I(0))
    future=[]
    for u in (F(1,4),F(5,8),F(1)):
        for scale in (F(1,2),F(3,4),F(1)):
            value=sum((b*kern(u,I(scale),x,z,Nq) for b,z in zip(beta,OUTER)),I(0))
            future.append(dict(u=str(u),scale=str(scale),value=value.out(),upper_qualification=status(I(QFIX)-value)))
    reciprocal=[]
    for ui,(flag,pu,qu,w) in enumerate(zip(good,K1,Qv,wg)):
        if flag!='pass':
            reciprocal.append(dict(inner_index=ui,good_status=flag,p_u=pu.out(),Q_u=qu.out(),R_yu=(p*w/pu).out(),
                inside_current_L_cube=all(abs(a-b)<=L/2 for a,b in zip(x,POS[ui])),
                inside_Lplus_cube=all(abs(a-b)<=par['Lplus']/2 for a,b in zip(x,POS[ui])),
                possible_actual_positive_pair=any(z.hi>0 for z in A) and high!='fail',
                traffic_status='no original-form A-positive v on this high row' if high=='pass' and all(z.hi==0 for z in A) else 'conditional diagnostic; lower-score pairing not asserted'))
    # For whole-window rho^2 b/wg^2 use a conservative band enclosure; exact-zero A does not require this gate.
    cuts=sorted({F(1,2),F(h.hi)}|{q for cs in C for c in cs for q in (F(c.lo),F(c.hi)) if F(1,2)<q<F(h.hi)})
    gate_upper=I(0);gate_lower=I(0)
    for a,b in zip(cuts,cuts[1:]):
        pi,bl,k=lower_mass(C,I(I(a).lo,I(b).hi))
        for flag,r,bu,w in zip(good,rho,bl,wg):
            if flag=='fail':continue
            value=r**2*bu/(w**2)
            gate_upper=I(max(gate_upper.lo,value.lo),max(gate_upper.hi,value.hi))
    for t in (I(F(1,2)),h):
        pi,bl,k=lower_mass(C,t)
        for flag,r,bu,w in zip(good,rho,bl,wg):
            if flag=='fail':continue
            value=r**2*bu/(w**2);gate_lower=I(max(gate_lower.lo,value.lo),max(gate_lower.hi,value.hi))
    integrals['positive_and_companions_certified_zero']=all(F(integrals['values'][key][1])==0 for key in ('positive_pA','Cb','C0'))
    integrals['EJ_precision_status']='coarse rigorous bound; no accuracy claim' if not integrals['resolved'] else 'within displayed tolerance or exact gate zero'
    L1='pass' if gate_upper.hi<=1 else ('fail' if gate_lower.lo>1 else 'ambiguous')
    return dict(subdivisions=Nq,stage=config['stage'],config=config['name'],x=list(map(str,x)),L=str(L),K=str(K),outer_index=yindex,outer_position=list(map(str,y)),beta_mass=beta[yindex].out(),
        completion_mass=mass.out(),parameters=dict(n=4,s=str(S),a='1/2',b='1',R='1',q=str(QFIX),j=0,D=par['D'].out(),D_branch_upper_epsilon_le_1=par['D_branch_upper_epsilon_le_1'].out(),
        scale_margins={key:z.out() for key,z in par['margins'].items()},strict_soft_margin=(I(S)-1+I(ct.iv.exp_neg(F(lograt(F(2)).hi)/4).lo,ct.iv.exp_neg(F(lograt(F(2)).lo)/4).hi)).out(),g=g.out(),H0=H0.out(),Hhat=H.out(),T=T.out(),hscale=h.out(),Lplus=str(par['Lplus'])),
        good=good,good_margins=[z.out() for z in goodmargin],high=high,high_ratio=highratio.out(),alpha=alpha.out(),alpha_nonnegative=status(alpha),
        U=[z.out() for z in U],rho=[z.out() for z in rho],A=[z.out() for z in A],wg=[z.out() for z in wg],Delta=[z.out() for z in Delta],TDelta=[z.out() for z in TD],
        K0=[z.out() for z in K0],J=[z.out() for z in J],Q=[z.out() for z in Qv],C_coordinates=[[z.out() for z in cs] for cs in C],eg=eg.out(),terminal_Pi=[z.out() for z in pig],terminal_score_bounds=kg,terminal_b=[z.out() for z in bg],
        terminal_future_moments={key:z.out() for key,z in moments.items()},reciprocal_bad_slots=reciprocal,
        posterior_gate=dict(L1=L1,whole_clock_upper=gate_upper.out(),endpoint_lower=gate_lower.out(),scope='rho frozen; good slots only; threshold-band uncertainty retained'),
        integrals=integrals,current_convolution=fcur.out(),current_upper_qualification=status(I(QFIX)-fcur),
        current_equality=('symbolic exact R169 completion' if x==X0 and L==F(9,10) else 'not inherited; original current equality unverified'),
        future_status=('inherited R169 atomic pointwise all-u/all-scale certificate' if x==X0 else 'finite grid only; no continuum certificate'),future_grid=future,
        source_status='one common atomic beta=F completion, nu<=beta; no L1/original-source lineage',Z_status='conditional Z=all; no original history or deletion certificate')

def main():
    start=time.monotonic();configs=[dict(name='baseline_K1',stage='stage1',x=X0,L=F(9,10),K=1)]
    configs +=[dict(name='point_K'+str(k),stage='stage2',x=X0,L=F(9,10),K=k) for k in (4,16,64)]
    configs +=[dict(name='receiver_'+str(sign),stage='stage3',x=(X0[0]+F(sign,100),)+X0[1:],L=F(9,10),K=1) for sign in (-1,1)]
    configs +=[dict(name='scale_L85',stage='stage3',x=X0,L=F(17,20),K=1)]
    refinements=[]
    for Nq in (64,128):
        rows=[compute(config,y,Nq) for config in configs for y in range(4)]
        refinements.append(dict(subdivisions=Nq,rows=rows,summary=dict(row_count=len(rows),high_pass=sum(z['high']=='pass' for z in rows),
            high_positive_A_possible=sum(z['high']!='fail' and any(F(a[1])>0 for a in z['A']) for z in rows),
            exact_zero_traffic=sum(F(z['integrals']['values']['positive_pA'][1])==0 for z in rows),
            positive_integral_upper_count=sum(F(z['integrals']['values']['positive_pA'][1])>0 for z in rows))))
    deps=[TOOL,Path(ct.DEP),COMPLETION,POINT,HERE/'task_contract.md',HERE/'physical_contract_index.md']
    if LOCATORS.exists():deps.append(LOCATORS)
    out=dict(scope='Physical-form kernels and same-alpha/good/high computed on one common frozen atomic input. K is diagnostic; no L1 source lineage, positive dx, original Z/history, or FULL claim.',
        constants='j0 and D4=1 are newly checked from inherited formulas, not claims that old point certificates instantiated them.',
        definitions=dict(positive='int p_y sum A_v delta+ Pi_v Pi_u dlogxi',EJ='int sum J_v delta+^2 Pi_v Pi_u dlogxi',Cb='int sum p_y^2 A_v^2/J_v b_v Pi_v dlogxi',C0='same as Cb with b removed',
            moment='All E_ labels are terminal Pi_g finite expectations; no inferred moment bound.'),
        arithmetic='Frozen directed Decimal interval kernels, exact rational parameters and certified log/exp/sqrt. Positive rectangle/Darboux integration if needed; exact-zero gates bypass it.',
        inputs={(p.name if p.parent==HERE else str(p)):hashlib.sha256(p.read_bytes()).hexdigest() for p in deps},refinements=refinements,
        limitations=['K1/4/16/64 are parametric diagnostics; theorem-level K remains unknown.','F and beta are atomic, not L1 densities and not an original beta_V lineage.',
        'Current equality is inherited only at x0,L=.9; moved receiver/scale rows retain their own statuses.','Zall is conditional and no original deletion/history is synthesized.',
        'No receiver integration, source-budget payment, or general bound follows.'],runtime=dict(python=sys.version,seconds=round(time.monotonic()-start,3)))
    (HERE/'physical_companion_probe.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(output=str(HERE/'physical_companion_probe.json'),summary=[z['summary'] for z in refinements],seconds=out['runtime']['seconds']),indent=2))
if __name__=='__main__':main()
