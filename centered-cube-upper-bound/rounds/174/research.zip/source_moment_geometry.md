# R174：原 posterior 矩、物理 score 事件弱 majorant 与来源费用

## 1. 技能范围、原量词与结论范围

本稿读本轮合同及所需R173冻结稿，并使用当前 B03 `math-b03-generalized-moments/SKILL.md`、`references/provenance.md`、`references/cube-interface.md` 的范围筛查：允许逐点majorant积分得到弱对偶；强对偶、矩锥闭性、有限原子表示均另有条件。本稿只自证初等弱对偶，不引用任何未复核外部强对偶或极点定理，也不把有限原子可行点称为一般L1来源。

固定同一个真实receiver行 (ω,V,j,x,y、原history、共同window与selectors)。p=p_y=P_s,L(x−y)>0，q>0，原ν≤β≤f，当前/所有合法future对同一f测试均≤q；high给peg≥2Kq。记

\[
\Pi_t(du)=\frac{1_{Z_t}w_t(y,u)\nu(du)}{e_t},\quad e_t\ge e_g>0,
\qquad w_t=\prod_i\min(1,C_i/\xi_t),\quad
\xi_t=c_jt/b\in[1/2,1].
\tag{M1}
\]

terminal Πg 是原归一化后的概率；这不是额外来源概率假设。原ν、β不被概率化。物理C严格为正，故有限位置上wt,wg>0；所有核矩的有限性来自原f测试，不凭1/w有界。

本稿的新几何估计是原低-score事件的显式逐点J-majorant，给 actual blocker b_t(v) 的确定上界，也给包含全部已删除来源的冻结core-growth费用一个合法上界。由此得到已有正交通付款定理的明确物理充分子支；未证明该子支一般覆盖或具有新增FULL正测度覆盖。常数的指数损失和所有补集均保留。

## 2. 同一高行的准确source矩

任一**共同**合法future核 Ki=P_{u_i,L_i}，u_i≥s、L_i∈[a,b]，在整段内源积分u上固定。于是

\[
\int\frac{K_i(x-u)}{p\,w_t(y,u)}d\Pi_t(u)
=\frac1{pe_t}\int_{Z_t}K_i(x-u)d\nu(u)
\le\frac q{pe_t}=:r_t\le\frac1{2K}.
\tag{M2}
\]

t=g即父级所问的terminal矩，分母是实际wg与eg。所有future矩共享同一个r_t，不能给各测试重选q/eg。K1、K2、J及合法K0均可用；Q=(K1+K2+J)/3是三个合法测试的凸组合，所以其矩预算仍为r_t，不能多算三份。

特别在terminal good集合 G 上，RQ=Q/(pwg)≥1/K。由(M2)得

\[
\Pi_g(G)\le Kr_g\le\tfrac12,
\qquad
\int A\,d\Pi_g\le\frac K3\int\frac J{pwg}d\Pi_g
\le\frac{Kr_g}3\le\tfrac16,
\tag{M3}
\]

其中A=1goodρJ/(3Q)，ρ≤1。这只约束总质量；它不强制bad在任何score上尾，不等于R171的可用bad池条件。

### 2.1 actual same-α的额外矩及其限制

原U≥0与same-α满足

\[
\int(U+\alpha J)d\nu=Dq,\quad\alpha\ge0.
\]

故对所有actualt还有

\[
\int\frac{U+\alpha J}{p w_t}d\Pi_t\le D r_t\le\frac D{2K}.
\tag{M4}
\]

这是原捕获等式的后果，**不是**声称U+αJ是一条合法future卷积。精确地，ν=νg+νout、νg=egΠg/wg给

\[
e_g\int\frac{U+\alpha J}{w_g}d\Pi_g
+\int_{Z_g^c}(U+\alpha J)d\nu=Dq.
\tag{M5}
\]

外部νout项非负，但不能在重建原模型时丢掉。固定actualα、几何、terminal masks时，(M2)/(M4)是Π的线性必要矩。若把来源、eg、α或masks当优化变量，α∫Jν是双线性，ρ=[1−(DK0+αJ)/(TΔ)]+带分段非线性，且U/min及good、history、共同future可行性亦不能自由指定。终端矩外放松不等价于共同f的可实现性。

## 3. 可用的弱对偶及禁止的测试选择

若非负目标g(u)在原允许物理来源集合上有逐点majorant

\[
g(u)\le\lambda_0+\sum_{i=1}^m\lambda_i\frac{K_i(x-u)}{p w_t(y,u)},
\quad\lambda_i\ge0,
\tag{M6}
\]

则直接积分给

\[
\int g\,d\Pi_t\le\lambda_0+r_t\sum_i\lambda_i.
\tag{M7}
\]

λ0是质量等式Πt1=1的系数，可取实数，只要majorant成立且右端定义良好。可另加(M4)的非负乘子，成本相应为Dr_t。本文不声称inf对偶等于任何source上确界，不主张达到、原子数或一般L1强对偶。

测试与乘子可依固定外参数、t和被界定的target score k；但在同一次u积分中必须共同固定。不能对每个u单独挑最有利Ki，再把∫maxKiν算成q；不能把不同坐标各自选scale/softness的乘积当一条原合法future。有限混合∑λKi的真实成本是∑λ，所有计数均留在(M7)。该式只是逐行弱界：在外β或dx积分时，不能把依外参数自适应的future核当成固定概率核，也不能丢掉乘子总质量费用。下文只用一条固定合法J=P1,b，不新增future数、列数或菜单费。

## 4. 物理φ/C比较：完整初等证明

写

\[
\phi_a(r)=\int_{-1/2}^{1/2}e^{-|r-z|/a}dz,\qquad
\phi(r)=\int_0^1\phi_a(r)da.
\]

对固定r，φa随a非减；φ偶、严格递减于r>0、0<φ(r)<1。F=max(h,φ)因此在硬内为1、硬外为φ。C=h*F满足C(0)=1、C(r)>0且r>0时严格递减至0：其a.e.导数F(r+1/2)−F(r−1/2)<0，跨硬跳仍绝对连续。因此Rξ=C^{-1}(ξ)对ξ∈(0,1]唯一有限，R1=0。C,F均不是概率密度；本段没有概率化它们。相对地∫φ=∫h∫w=1，故J确为固定b的概率核。

取任意辅助常数κ>1，令

\[
c_\kappa=1-1/\kappa>0.
\]

对任意r,z∈R，三角不等式及混合参数a≥1/κ给

\[
\begin{split}
\phi(r+z)&\ge e^{-\kappa|z|}\int_{1/\kappa}^1\phi_a(r)da\\
&\ge c_\kappa e^{-\kappa|z|}\phi(r).
\end{split}
\tag{M8}
\]

最后一步来自a↦φa(r)非减：上端长度cκ的积分至少占总积分cκ；可按上下两段的平均大小直接证明。它不是逐个a的统一下界，也未交换未经证明的极限。

在硬内φ≥φ(1/2)，硬外F=φ，故全域F≤φ/φ(1/2)。再由(M8)反向应用于r−z到r、|z|≤1/2，得

\[
C(r)\le\frac1{\phi(1/2)}\int_{-1/2}^{1/2}\phi(r-z)dz
\le\frac{e^{\kappa/2}}{\phi(1/2)c_\kappa}\phi(r).
\tag{M9}
\]

合并(M8)/(M9)，对r,d≥0有明确正下界

\[
\boxed{\frac{\phi(r+d)}{C(r)}\ge
\gamma_\kappa e^{-\kappa d},\qquad
\gamma_\kappa=\phi(1/2)c_\kappa^2e^{-\kappa/2}>0.}
\tag{M10}
\]

所有常数与n、来源相关性、q、eg无关。κ趋1时cκ趋0，γ恶化，不能声称把尾指数无代价降至1。

## 5. 原score事件的显式空间majorant

固定actualt，ξ=ξt、R=Rξ、di=|x_i−y_i|/b。内源u的第i坐标记ri=|y_i−u_i|/b，wi=min(1,C(ri)/ξ)。共同x,y,u的三角关系给|x_i−u_i|/b≤di+ri。

若该坐标score0，即C(ri)≥ξ，则ri≤R、wi=1，故

\[
\frac{b^{-1}\phi((x_i-u_i)/b)}{w_i}
\ge a_i^0:=b^{-1}\phi(d_i+R).
\tag{M11}
\]

硬阈值等号属于score0，与原严格count一致。若score1，即ri>R，则由(M10)得

\[
\frac{b^{-1}\phi((x_i-u_i)/b)}{w_i}
\ge a_i^1:=\frac\xi b\gamma_\kappa e^{-\kappa d_i}>0.
\tag{M12}
\]

可选更锐的一维常数为(ξ/b)inf_{r>R}φ(di+r)/C(r)，但下文只用已完全证明的显式(M12)，不依靠浮点inf或未经认证数值拟合。

对整数h=1,…,n+1，设

\[
M_h(d,\xi;\kappa)=
\min_{S\subset\{1,\ldots,n\},\ |S|\le h-1}
\prod_{i\notin S}a_i^0\prod_{i\in S}a_i^1>0.
\tag{M13}
\]

它是有限可直接计算的几何量，无分布优化：令zi=a_i1/a_i0，排序z(1)≤…≤z(n)，取m=min(h−1,#{i:zi<1})，则

\[
M_h=\left(\prod_i a_i^0\right)\prod_{i=1}^m z_{(i)}.
\tag{M14}
\]

这是对**坐标状态下界的有限最小值**的准确公式，不宣称是一般moment问题的强对偶或实际来源极值。Rξ连续、有限乘积/排序和原整数score均可测，因此这些majorant与后文源门可测；不需要新增选择器定理。每个真实u的坐标可能完全相关；只要ku<h，其score1集合大小≤h−1，(M11)/(M12)逐点相乘给

\[
\boxed{1_{\{k_t(u)<h\}}\le
\frac{J_b(x-u)}{M_h\,w_t(y,u)}.}
\tag{M15}
\]

右端全域非负，事件外亦是majorant。由原(M2)而非新来源假设，

\[
\Pi_t\{k_u<h\}\le
B_h:=\min\left\{1,\frac{p}{2K M_h}\right\}.
\tag{M16}
\]

准确预算q/(etMh)可保留代替p/(2KMh)。定义B0=0，则实际blocker

\[
b_t(v)=\Pi_t\{k_u<k_v\}\le B_{k_v}.
\tag{M17}
\]

h=n+1事件为全部来源，故actual high行还必须满足

\[
M_{n+1}\le p/(2K).
\tag{M18}
\]

若严格违反，整条高行不可能存在；等号不作额外排除。此为真正的receiver几何必要条件，未使用自由C数组或新核选择。

### 5.1 显式指数损失

(M8)还给a_i0≥b^{-1}cκφ(R)e^{-κdi}。因而

\[
M_h\ge b^{-n}e^{-\kappa\sum_i d_i}
\min_{0\le m\le h-1}
[c_\kappa\phi(R)]^{n-m}[\xi\gamma_\kappa]^m.
\tag{M19}
\]

取h=n+1时即≥b^{-n}e^{-κΣdi}min(cκφ(R),ξγκ)^n。故majorant成本可以含一个常数的n次方及e^{κΣdi}，一般非常大；κ→1还会产生cκ^{-2n}损失。有限排序(M14)保留各实际di，通常比(M19)强，但本文未证明其全局为n^o(1)。这一指数损失不能被记成无常数、无维数费用的根阶控制。

## 6. 对原正交通与全初始core费用的合法用途

### 6.1 已付款定理的确定物理子支

R173已审正交通定理规定：原ρ²b_t(v)≤L²wg(v)²的部分，真实raw正J-share价格为

\[
\frac{16\Lambda}{9}L\sqrt{n\log2}\,W_\beta.
\tag{M20}
\]

由(M17)，下列完全明确的物理/actualρ充分门推出该原付款门：

\[
H^{geom}_L(t,v)=1_{\{\rho_v^2 B_{k_t(v)}(d,\xi_t;\kappa)
\le L^2 w_g(y,v)^2\}}.
\tag{M21}
\]

所以该子支确由(M20)同价支付。它不要求直接知道source下尾质量b，只用同一x,y,v的物理位置、当前score与实际same-α残余；ρ不可重新选择。若用ρ²≤1进一步删去ρ，则得到更保守的纯几何充分门。

费用完整沿R173：actual平方能量nWβ/(2K)、零阶J槽log2Wβ/(2K)，good给系数K/3，hard16/3及外2Λ各一次；合为(M20)。固定b的J空间积分、原∑ν≤∑β与唯一j保留，无新增j列费、future数费、source坐标独立假设或score层数费。时间依原正Cauchy方法处理，(M21)可随t变动；它不被塞入冻结A的导数公式，亦不重复领取任何signed负项。

没有证明(M21)涵盖一般剩余middle、所有大比值源或新增FULL正交通。若Mh指数小，Bh=1，这个几何证书可能不比已有ρ/wg门更好；失败补集就是原正交通中Hgeom=0者，完整保留。

### 6.2 全初始B含已删除来源：core-growth费用上包络

此处不选择core，保持父级/Astra已经给定的原初始S=Ccore⊔B、整数clock r(t)∈{0,…,n}、c(t)=exp(−∫r dlogt)。R173费用为

\[
\lambda=\frac{c(g)}{e_g}
\int\frac1{c(t)}\int_{B\subset S}
(r(t)-k_t(u))_+w_t(y,u)d\nu(u)\frac{dt}t.
\tag{M22}
\]

B包含以后删除的全部来源；不能把(M16)的currentΠt直接套给已删除者。正确方法是直接对同一原ν应用未归一(M15)：每个h，

\[
\int_B1_{\{k_u<h\}}w_t d\nu
\le\frac1{M_h}\int_BJ_b(x-u)d\nu\le q/M_h.
\]

整数层恒等式(r−ku)+=∑h=1^r1ku<h因此给

\[
\boxed{\lambda\le
\frac{c(g)q}{e_g}\int\frac1{c(t)}
\sum_{h=1}^{r(t)}M_h^{-1}\frac{dt}t
\le\frac{c(g)p}{2K}\int\frac1{c(t)}
\sum_{h=1}^{r(t)}M_h^{-1}\frac{dt}t.}
\tag{M23}
\]

保留∫B Jν可比q更强。此式包括假想继续演化的deleted B权，故没有移动支持漏洞。h求和是原整数deficit的准确层分解，不免费省成一次，也不另乘一个未经计算的n。本文未证明(M23)小于1，未据它重选core，未把右端改名成已付款预算。它仅提供由真实future矩导出的显式几何上包络，供core主线检验。

## 7. 剩余条件与停止

可用source约束为(M2)的全部共同future矩、(M4)/(M5)的actual捕获矩及(M3)的good/J-share质量限制。新的空间证书为(M15)–(M18)与其全初始费用版本(M23)，来自同一x,y,u的真实C层与固定J，而非任意独立C数组或有限atomic extremizer。

仍未付款/未构造：指数弱majorant导致Bh=1的部分、Hgeom失败部分、(M23)不能使λ<1的core费用、全部原adaptive系数/receiver积分与共同history/完整L1实现。矩可行不推出原common-f可行；固定actualα的线性外约束不允许自由调α、eg、q、来源masks。没有强对偶、原子达到或一般极值族结论。

候选在长证明前已发独审，最终绑定由父级记录。本稿仅写指定source_moment_geometry.md，不Git、spawn、PDF，不重复core选择算法，不开展新反例扫描；交付有界检查点后停止。
