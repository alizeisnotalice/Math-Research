# R174 共同输入与全局几何独立审计

责任范围仅本文件；无Git、无额外代理、无PDF、新实验或他人改动。先只读本轮task_contract，复用已亲核R170–R173原合同；以下未借本轮作者结论。一般根阶弱型上界仍开放。

## 1. 作者前检查点：终端Pi的真实线性future矩

固定原完整行，记pi=Pi_g=1_Zg wg nu/e_g，p_y>0，e_g>0。对同一x的每一个合法current/future测试K_theta=P_(u,Lprime)，由原nu≤f及完整FIRST，有

    e_g integral [K_theta(x−v)/wg(y,v)] pi(dv)
      =integral_Zg K_theta(x−v)nu(dv)≤K_theta f(x)≤q.

因此high上严格给

    integral [K_theta/(p_y wg)] dpi≤q/(p_y e_g)≤1/(2K).

这是以终端pi为变量、在原外参数与原e_g冻结时的线性矩约束。wg严格正；没有把C/F或原nu/beta概率化。当前P_s,L测试也只给这一**上界**，一般没有等号，因为nu只是f子测度且Zg又限制来源。Pcurrent f=q不能改写成Pcurrent nu=q或pi的某个矩等于q/e_g。

原Q是三项合法测试的共同正混合，故同样

    integral Q/(p_y wg) dpi≤1/(2K).

终端good是Q/(p_y wg)≥1/K，bad为严格反向，Markov即给pi(good)≤1/2、pi(bad)≥1/2。这是可实际使用的几何矩约束，但只约束这个特定kernel比，不自动约束k或其低score层概率，也不保证R173上尾逆容量。

所有theta共享**同一个原f**、同一x与同一receiver当前s/L/q。在固定x,y的这一个nu来源矩比较里，可以按外参数y选择合法theta，因为theta仍对正在积分的v共同；这与逐v选择theta不同。随后若theta(y)进入外beta(y)积分，不能再把这一自适应核族当成一个共同future而只领一次q；须保留实际外质量、证明共同majorant或支付sup菜单容量。若改用sup_future，不能从逐theta的FIRST上界直接交换sup与来源积分。

## 2. same-alpha可提供的真实约束与丢不掉的外部质量

原alpha QJ=Dq−integral U dnu，QJ=Jnu，U=1_good,Delta>0 min(TDelta,DK0)。D及全部原捕获参数沿既定预算冻结。由U≤DK0、K0nu≤q，alpha≥0。

给定alpha、原good/Delta等外参数后，alpha恒等式可写成

    integral (U+alpha J) dnu=Dq.

但将nu换成终端pi时必须保留Zg之外：

    e_g integral_Zg [(U+alpha J)/wg] dpi
      +integral_(outside Zg)(U+alpha J)dnu=Dq.

丢去非负外部部分只得到≤Dq的矩上界，不能保留等号。alpha不是一个可逐source任选的对偶系数；若改变nu，alpha、QJ及由nu质量构造的支持/历史也随之变化。冻结alpha时rho(v)是固定的pointwise函数，线性moment relaxation可成立；alpha同时优化时约束含alpha·Jnu，不能假称联合问题仍是同一线性凸集。

精确reserve还给

    alpha QJ/D=q−K0nu+integral K0(v)[1−c_y(v)]nu(dv),
    c_y=U/(D K0)∈[0,1].

实际bad来源有c_y=0，因此

    integral_bad K0 dnu≤alpha QJ/D.

这只控制bad的K0加权质量，不能免费去掉K0得到后验bad或低score概率。若转换到原Pi_t，还留wt/(e_t K0)。一般masked b_t(v)还包括low-score good和later-deleted来源，这些不都在bad reserve内。必须保留来源槽和资格，而非用一个bad总质量替代所需前缀质量。

原Pcurrent f=q与每个future≤q还蕴含共同正remainder：

    f dx=1_Zg nu+eta,  eta≥0,
    e_g integral K_theta/wg dpi+K_theta eta≤q,

其中当前测试满足总和等号。所有theta的eta必须是同一真实正测度；不能逐测试另填一个独立缺口。跨不同y的pi_y也都来自同一nu、同一f，不是可独立选择的一族概率表。跨V还有nu_V≤beta_V、sum beta_V≤f，beta不能在外积分中替成nu。

## 3. 有限原子与弱对偶：可核的范围

原L1输入下nu≤f dx，实际来源没有原子。有限原子对象可以是一个扩大可行域的moment relaxation或有限核诊断，不能直接声称是原输入的极值或FULL实现。

对一个**有限**测试菜单，若所有外参数、alpha、支持及gate均固定，所选moment constraints是线性的。可以另行研究有限moment向量的原子表示；这与在所有原输入上取得非线性rho目标的最大值是两件事。若使用有限凸包归约，须明确保留哪些矩、归一质量、目标、外部remainder及其可积性/闭性条件。紧域连续函数是一个易核的充分环境，不意味着非紧情况一概不可能；非紧/不连续情况下需给对应的独立表示或逼近论证。

本轮原future菜单是连续的，且原Zg/alpha/历史依赖同一来源；故不能从“有有限个写出的约束”就断言一般极值只需有限原子。当前可先合法使用的只是**弱对偶**：若在原允许v域逐点有

    F(v)≤a+integral [K_theta/(p_y wg)] sigma(dtheta),

sigma为正有限测度，则

    integral F dpi≤a+||sigma||/(2K).

归一质量乘子a可为实数；future上界的乘子必须非负。sigma须在正在积分的v上共同，不得逐v换成另一个测试却仍只付一个总质量。加入alpha-reserve等上界同样用非负乘子；加入真正保留外部部分的等式才可讨论有符号乘子。

不需强对偶、最优attainment或原子化就能验证这个正majorant。若拟由数值LP产生对偶，须验证其在连续真实物理位置/全部legal参数上的逐点majorant，不能只认证有限网格。有限原子违反某个放松命题也不是原FULL反例。

## 4. 终端矩不能直接取代initial/deletion数据

R173core分区覆盖整个初始S=Z_ell，Pi_g只看Zg。当前Pi_t在Zg上的密度相对pi_g为

    (e_g/e_t)(wt/wg),

但另有E_t=Zt\Zg的真实来源部分。选定的masked b_t(v)=Pi_t{ku<kv}可能见到E_t；initial blocker费用更明确包含

    e_g^(-1) integral_(B intersect (S\Zg)) wg dnu.

它不是terminal pi_g的质量，不能从pi_g(B)小推出该项小。某些原bad pair门可排除E_t这个u槽，但如要利用它必须重做对应的精确masked companion；不能一边使用完整Pi前缀定义、一边默默删除其E_t成分。

同样，原same-alpha矩里nu在Zg外的测试容量仍存在。终端pi可用于建立必要的线性约束、对偶包络或上界放松，但不携带完整core-clock和删除的全部数据。

## 5. masked companion的全局付款量词

已核原实际post-hard正J-share满足

    I_H≤sqrt(E_J C_b,H),   E_J≤nW_beta/(2K),
    C_b,H=E sum_(V,j) integral 1_j dx integral_high beta_V(dy)
             integral_actual dt/t integral H_t(v)
                       [p_y²A_y(v)²/J_v] b_t(v)Pi_t(dv).

若要全域root J来源价，须在一个已明确分配的不交原剩余域证明这个真实C_b=O(n^{o(1)}W_beta)或其他充分可积对偶。不能把C_b的定义、平均值、有限原子最优值或某个未证tail moment改名后就登记预算。

R173点态门rho²b≤L²wg²只支付该正子支。它可依t/v，因为纯正Cauchy无需冻结终端mask；但core选择/mass-clock FTC须一条完整行只用一个time-fixed分区。若换time-dependent core必须计共同clock/normalizer的变化，不可免费插入旧定理。

合法的全局majorant/选择结论必须对每个共同f、原seed/叶、receiver和同一source体系成立；保留全外beta、实际dx、high资格、et及原Pi。固定J空间归一只有在其余y/v依赖已结算后可用，Q自适应不能作dx概率核。原uniquej须保留到一致行价；hard16/3和outer2Lambda各一次，原窗口/来源/history总费不能独立重领。

## 6. 后审计划与停止

等待父级准确命题及Astra/Sol成稿后，只审：共同f约束是否原始可用、moment/对偶的连续域与符号、alpha与外部质量的一致性、initial/terminal/删除、core/measurable选择、rho/low-score slot、所有真实空间/scale/window费用。数值仅有限证据，不重复实验。

作者前检查点完成。只认证上述必要约束与弱对偶，不认证有限原子极值归约、一般core存在或全masked companion付款。停止等准确成稿。


## 7. Sol 显式phi/C majorant的先行独审（未读成稿）

固定a>1，theta=(a−1)/a。对phi_t(r)=integral_h exp(−|r−u|/t)du，t↦phi_t(r)非减，故其上段[1/a,1]积分至少theta phi(r)。单component triangle给

    phi(r+z)≥theta exp(−a|z|)phi(r).

又0<phi(1/2)<1，硬内phi≥phi(1/2)，所以F≤phi/phi(1/2)。利用前式反向比较phi(r−u)和phi(r)，得到

    C(r)≤exp(a/2)phi(r)/[phi(1/2)theta].

两次比较结合，任意d,r≥0有

    phi(d+r)/C(r)
      ≥phi(1/2)theta² exp(−a/2)exp(−ad)>0.

没有把F/C当概率核，也没有漏归一化尺度。

固定合法J=P1,b，xi∈[1/2,1]，R=C^{-1}(xi)，d_i=|x_i−y_i|/b。对score0坐标C(r_i)≥xi（含等号），r_i≤R且w_i=1，故

    J_i/w_i≥a_i0=b^−1 phi(d_i+R).

对score1坐标r_i>R、w_i=C(r_i)/xi，则

    J_i/w_i≥a_i1
      :=(xi/b)phi(1/2)theta² exp(−a/2)exp(−a d_i).

物理triangle保证同一x,y,u关系；未独立填写C数组。每个因子均正且尺度为b^−1。

对整数k≥1，令M_k为所有至多k−1个score1 pattern的上述乘积最小值。用基准product a_i0，再选至多k−1个小于1的最小ratio a_i1/a_i0即可；不能在ratio>1时仍强制选恰好k−1个。于是

    1_{k_u<k}≤J_b(x−u)/[M_k wt(y,u)].

当前Pi_t的真实moment（先在原eligible/high行）给

    integral J/(p_y wt)dPi_t≤1/(2K),
    Pi_t{k_u<k}≤min(1,p_y/(2K M_k)).

k=0的事件为空，必须单独置0。每个M_k可能指数小，不由正性推出全局有用常数；不得把该显式物理充分门说成一般masked companion已付。

对固定x,y,t及查询v，可以选择对源u共同的正future系数；不能对正在积分的u自适应选择测试再只付一次q。若将外beta积分里的不同future核族当共同测试，则另需共同majorant或菜单总质量费用。已将因子/量词判定反馈作者，等待后审。

## 8. Astra canonical core准确命题的先行独审（未读成稿）

固定0<eta<1与同一原完整行，令

    B={u∈S:Q_x(u)≥p_y/(2K eta)},    C=S\B,
    S=Z_(ell+).

Q是在同一x上、对正在积分的u共同的原三测试混合。由Qnu≤q，

    nu(B)≤2K eta q/p_y≤eta e_g.

这覆盖全部initial B，包括后来删除源，不使用terminal pi替代原nu。且

    nu(C)≥nu(S)−nu(B)≥(1−eta)e_g>0,
    integral_(Zg intersect C) wg dnu≥(1−eta)e_g.

所以高行的core不会零质量，r=essinf_C k有定义；nu/e_g退化行依原零交通约定跳过。

对该固定core用R173时钟c，任意blocker score都有

    G_B(t)=integral_B(r−k_u)_+ wt/c_t dnu≤r(t)nu(B)/c_t.

由于d(1/c_t)/dlogt=r/c_t，

    lambda=(c_g/e_g)integral G_B dt/t
      ≤(1−c_g)nu(B)/e_g≤eta(1−c_g)<eta.

这不要求B低score、无删除或额外moment假设。全部later-deleted B仍被同一容量支付；原Pi/et/alpha/rho/Delta保持。B虽随receiver x、外y与原initial支持变化，但对整条辅助时间固定。

B的J正槽系数有

    p_y² A_v²/J_v≤4K²eta²J_v/9.

已核E_J和Z_J给C_B≤2K eta²log2 W_beta/9；两者Cauchy后posthard32Lambda/3给

    RawPositive_J[B]≤32Lambda eta sqrt(nlog2)W_beta/9.

无需对Q作空间概率积分；使用的是pointwise未来容量Qnu≤q。uniquej在一致行价后合并，fixedJ真dx、fullbeta、hard一次、来源总质量/窗口/history价格完整。该价格只适用于J份额；无chiJ母式的B不能直接套这个系数。

因此对每个实际原输入确实有一个可测、正质量core，其lambda自动小于eta，且B正交通本身有显示root来源价。这比假定好core存在多了一条实际构造，但剩余Gamma_core与低future放大部分仍未统一受控，不是一般闭合。

## 9. 父级排序阈值结构的独立核验

令T=log(g/ell)≥0，时间s=log(t/ell)∈[0,T]，

    a_i(v)=clip(log(C_i(v)/xi_ell),0,T),
    a_(1)(v)≤...≤a_(n)(v),
    b_i=esssup_(v∈core) a_(i)(v).

core须正nu质量；canonical core已由第8节保证。对0<s<T，准确有k_s(v)=#{i:a_(i)(v)<s}。端点clipping可能改变单个端点的严格score，但不影响任何dlogt积分。

r(s)≥i等价a_(i)(v)<s对core-nu几乎处处成立。若s>b_i必成立，若s<b_i必不成立；s=b_i时因本质上确界是否被取到可不同。因此除有限集合{b_1,...,b_n}外，

    r(s)=essinf_core k_s=#{i:b_i<s}.

这里只能作a.e.时刻声明，不能把未取到sup的等号面强制成相同score值。有限n允许同一nu-null集上所有a_(i)(v)≤b_i；于是

    Gamma_core(v)=integral_0^T(k_s(v)−r(s))ds
                 =sum_i[b_i−a_(i)(v)]≥0   (core-nu a.e.).

排序是每个来源内部先排序，再取各rank的本质上确界，保留rank相关结构；不能偷换成原坐标分别sup。b向量一般未由同一个来源同时实现，但本公式不要求它实现。原可测nu核下，有限order statistics与本质sup的有理superlevel tests均可测；T=0时各量为0、a.e.时刻命题真空成立。

只认证这个精确结构，不由此推出sum gap≤log n或任何新全局来源/接收价格。

先行独审完成，接续只读指定作者稿并绑定，不另扩研究。


## 10. source_moment_geometry 成稿后审

已先完成第7节独立筛查，再实读M1–M23全稿。绑定最终SHA256：

    f31e920cfa7b7f2a5eb1eea4bb76c4612ef92e62df74553515b16318d17c507c

判定：M1–M23在明确量词下通过，无实质修订。后审新增核验如下。

### 10.1 原矩约束和有限弱对偶

M2对每个共同legal测试给原current/terminal矩q/(p e_t)，所有测试共享这个actual budget；高行上≤1/(2K)。Q是合法测试的凸混合，不多算三份。M3除good≤1/2外，还正确用good上的1/Q≤K/(pwg)得到

    integral A dPi_g≤K/3 integral J/(pwg)dPi_g≤K r_g/3≤1/6.

M4不把U+alphaJ冒称future核，只由原捕获等式及正截取Zt得到Dr_t。M5完整保留Zg外nu质量；固定actual alpha后的线性必要约束与同时优化alpha/source的非线性问题明确区分。没有从这些矩声称共同f可实现、强对偶、finite-atom extremizer或L1原子来源。

M6–M7是逐点majorant积分的弱对偶。测试和乘子只须在同次u来源积分中共同，可依固定外参数/t/查询score；有限组合支付全部非负乘子总质量。外beta或dx不能把这些自适应kernels假作固定概率核。稿件只用一条固定J推新空间证书，没有隐藏future菜单费用。

### 10.2 物理majorant、端点及维数价格

M8用混合参数上段的单调平均比例c_kappa，M9反向shift与F≤phi/phi(1/2)，合成gamma_kappa=phi(1/2)c_kappa²exp(−kappa/2)，与独立推导相同。C逆的正/严格递减依据充分，xi=1给R=0也保持score0闭端点。

M11在score0的w_i=1；M12在score1的w_i=C_i/xi；物理triangle同时保留x,y,u，不独立设C。M13/M14对至多h−1个状态乘积取最小的排序公式正确，ratio=1可省、ratio>1不强选。M15事件外右端非负，故确为全域majorant；M16应用原矩后给min(1,p/(2KM_h))，h=0单独0。h=n+1事件全域，故M18的M_(n+1)≤p/(2K)是原高行必要条件，等号未误排除。

M19显式保留b^(−n)、exp(−kappa sum d_i)及常数n次方。正majorant不意味着多项式价格；kappa趋1的c_kappa退化没有免费忽略。稿件未由有限排序或physical sublevel cert外推一般根阶。

M21只是rho² B_(k_v)≤L²wg²推出R173已付CS门的物理充分支，原rho不可重选，时间依赖用在正Cauchy而非终端FTC。原16Lambda/9 L sqrt(nlog2)价格完整继承，无新slot/层数/source独立性。

### 10.3 full-initial B的lambda系数和删除

M22准确写成

    lambda=(c_g/e_g) integral [1/c_t]
                integral_fullinitialB (r−k_u)_+wt(u)nu(du) dt/t.

M23的关键是将M15乘wt后直接对原nu积分：

    integral_B 1_{k_u<h}wt dnu≤Jnu(B)/M_h≤q/M_h.

这处理了所有later-deleted B，而没有套只看Zt的current Pi矩。整数层(r−k)+的h=1,...,r求和完整保留，因此

    lambda≤(c_g q/e_g) integral c_t^(−1)sum_(h=1)^r M_h^(−1)dt/t
           ≤(c_g p/(2K)) integral c_t^(−1)sum M_h^(−1)dt/t.

c_g/e_g、time内1/c_t、高行q/e_g≤p/(2K)、层求和及M_h指数成本均正确，没有省成一次q测试。M23未证明小于1，稿件不把其右端命名成已付预算，也不据此宣称全局core已构造。

本稿的新增是可核物理event majorant及费用上界，未宣称一般masked-companion付款。其与Astra另行canonical core构造的角色不同，不能把两个conditional/upper-bound表述相乘就称一般大Gamma已付。

## 11. sorted_threshold_geometry 成稿后审

已先完成第9节独立筛查，再实读完整父稿。其r_C(s)与Gamma公式、finite exceptional set、一般相关nu、core正质量和有限时间Fubini完全正确。排序不是物理coordinate permutation，也不改变x或核位置。b向量不须由同一来源实现，仍可准确表示逐时essinf。

原score在b_i面是否取到本质上确界导致的等号歧义已严格限为a.e.时刻；clipping不删除source或deletion费用。末节明确没有inexpensive cover、entropy box或稳定性结论。该精确表示通过，不认证新全局界。

## 12. 主LaTeX公式对读

已实读 `proof.tex.txt` 全部主要公式。canonical B的nu质量≤eta e_g、terminalweighted core质量≥(1−eta)e_g、lambda≤eta(1−c_g)<eta均与独立证明相同；没有core零质量漏洞。

B的伴随系数4K²eta²J/9，与EJ=nW/(2K)、ZJ=log2W/(2K)共同Cauchy给未乘外因子eta sqrt(nlog2)W/3；原hard16/3及outer2Lambda恰一次，raw为32Lambda eta sqrt(nlog2)W/9。Q只做容量/点态比，不作空间概率归一。全部nu/beta/窗口/history与uniquej范围按既有能量引理保留。

eta=1/2时，B费用是16Lambda sqrt(nlog2)W/9。core的Gamma≤log(n)/2槽，lambda<1/2使expGamma/(1−lambda)−1≤2sqrt(n)−1，所以费用≤16Lambda(2sqrt(n)−1)W/9。两支不交，其合计可明确上放为

    (16Lambda/9)[(2+sqrt(log2))sqrt(n)−1] W.

主稿没有把这个partial价格宣称全部流量已付；大Gamma core及原无chiJ母式的其他份额仍留账。阈值rank式的T是时间长度log(g/ell)，不是原捕获幅度T，两种量未在公式中混用。

有限模型仅作代数检查、physical/FIRST/FULL证据层次分开。主稿不推finite-atom一般极值，不从数值拟合给n指数。本独审不运行或重复数值实验。


## 13. global_core_geometry 完整成稿后审及GC11精确结算

已在第8节独立证明之后实读GC1–GC14完整成稿，并对读当前主LaTeX新增的精确不交结算。结论：指定范围通过，无必须修订。原R173冻结正文明确terminal A支持于Z_g；本轮所有“terminal source gate”继承此支持，不能将后来删除的v重新放入正交通槽。完整initial B只用于增长补偿分子及其质量上界，位置正确。

GC1–GC4的分割在实际行固定，Q是同一实际共同future平均；允许依x,y,V,j，但不依积分时刻t。nu(B)控制的是完整初始未归一质量。由于wg≤1、Zg包含于S，core的nu质量与terminalweighted质量均至少(1−eta)eg，故r的本质下确界处处有合法定义（零eg行排除）。任意原删除均不改变full-initial B的增长上界；没有把fullinitial质量冒充current Pi。c_g≥exp(−n log(g/ell))>0，故lambda≤eta(1−c_g)<eta严格有效，s趋0、原硬面或原score等号均不产生额外假设。

GC5的两个精确恒等式可直接由well/wg=exp(integral k)验证：

    Theta_eta=Gamma_C−log(1−eta+eta c_g),
    expTheta_eta=(well/wg)/[(1−eta)exp(R_C)+eta].

由lambda≤eta(1−c_g)可得原R173有效放大因子不超过expTheta_eta−1；core上Gamma_C≥0及0<1−eta+eta c_g≤1保证此上界非负。GC6因此对任意固定terminal来源门成立。它仍使用原Pi和原rho/alpha，不重建来源或借用signed负信用。

GC7–GC8的B全槽费用与第8节完全一致：伴随不多乘score层数，低分数质量只用≤1；原EJ、ZJ的固定J真实dx、高行、时间和唯一j范围均继承。正Cauchy后乘一次hard16/3及outer2Lambda恰得32Lambda eta sqrt(nlog2)W/9；不要求Q有空间概率归一，也不替其他mother份额付款。

GC9中P、Q、R以“先Theta门、再future门”顺序定义，是terminal core的互斥完备切分；加B后覆盖全部原terminal J槽。GC10的来源门用expTheta−1≤expM−1；接收门用

    J(expTheta−1)≤J expTheta≤exp(−h)P_(s,b).

future P_(s,b)在同一实际x上对各V共同，允许先以sum nu_V≤f和FIRST得到sum Pnu_V≤q；不能改为逐来源独立future测试。高行beta/e_g≤1/(2K)的积分、固定J空间积分及唯一j在统一上界后合并均与原计价次序相容。阈值门对正项可按行/来源切，不消耗负账。独立窗口没有无费合并。

故GC11准确保留

    RawPositive_J[all]
    ≤(16Lambda/9)[2eta sqrt(nlog2)+expM−1]W_beta
       +(16Lambda/9)exp(−h) E integral_D q dx
       +RawPositive_J[R_eta].

eta=1/2、M=log(n)/2、h=log[16Lambda/(9epsilon)]给来源系数

    (16Lambda/9)[(1+sqrt(log2))sqrt(n)−1]

及epsilon接收价。此精确Theta分支比第12节记录的保守Gamma分支更大，但二者不能同时累计付款；主稿把旧Gamma门保留为独立有效参照，并仅在新的P/Q/R完整分割中使用新常数，未双计。n=1的M=0也合法，P的放大费为0，无需附加n>1。

GC12的排序恒等式已在第9、11节严格独审；本质极值的等号只在有限时刻例外，相关nu、不同来源分别实现不同rank上包络均保留。GC13只是未付域的精确表达，不给免费小Gamma。GC14的w_t(v)/e_t^2乘来源内低分数w_t质量，正是原masked companion展开；没有把delta能量、概率归一或时间长度漏入系数。其O(polylog(n)W)控制仍是待证义务，不能由GC2的标量Q容量或排序恒等式推出。

本轮已证的是一般实际输入上的可执行canonical核心、完整B正J槽root价格、无lambda异常支及明确P/Q价格。未付R_eta、其他mother核份额及一般弱型结论均没有认证。有限有理/物理实验不参与以上证明，本独审未重复运行数值。

## 14. 最终文件绑定与停止

本次实读并绑定的SHA256如下；仅对这些准确版本及上述明确范围出具通过结论。

| 文件 | SHA256 |
| --- | --- |
| global_core_geometry.md | 17517cd0b8b5f0c828a116582e4cb591f24c391475706f2b6bbd4aeb5ab4568a |
| source_moment_geometry.md | f31e920cfa7b7f2a5eb1eea4bb76c4612ef92e62df74553515b16318d17c507c |
| sorted_threshold_geometry.md | 548d8143e78a33be0a21befd40bdfa50d0d692e83c29f8e612ea682c810bc10f |
| proof.tex.txt | a6aed7b49f78ea550538f25e5327fb7c21b3a498f67c597a57c938017666d402 |

最终结论：本轮指定几何/能量局部与全外费用审计通过；没有得到完整交通或一般上界闭合认证。本文件是独立审计记录，作者结论和有限数值本身均未被用作数学证据。交付后停止，不扩展研究，不修改作者文件。
