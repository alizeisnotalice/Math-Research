"""Exact finite checks of the new core clock bound, not physical/FIRST certificates."""
from fractions import Fraction as F
from pathlib import Path
import json, random, argparse

def evaluate(n, thresholds, masses, core, survivors):
    points=sorted({F(1),F(2)}|{a for row in thresholds for a in row if 1<a<2})
    def weight(j,t):
        w=F(1)
        for a in thresholds[j]: w*=min(F(1),a/t)
        return w
    c=F(1); growth=F(0)
    for l,h in zip(points,points[1:]):
        mid=(l+h)/2
        k=[sum(a<mid for a in row) for row in thresholds]
        r=min(k[j] for j in core)
        cnext=c*(l/h)**r
        for j in range(len(masses)):
            if j not in core and k[j]<r:
                growth+=masses[j]*(weight(j,h)/cnext-weight(j,l)/c)
        c=cnext
    eg=sum((masses[j]*weight(j,F(2)) for j in survivors),F(0))
    mb=sum((masses[j] for j in range(len(masses)) if j not in core),F(0))
    lam=c*growth/eg
    upper=(1-c)*mb/eg
    assert 0<=lam<=upper<=mb/eg
    # Finite sorted-signature identity without logarithms:
    # exp Gamma = product min(g,max(ell,C_i)) envelopes / source signature.
    clipped=[[min(F(2),max(F(1),a)) for a in row] for row in thresholds]
    sortedrows=[sorted(row) for row in clipped]
    envelope=[max(sortedrows[j][i] for j in core) for i in range(n)]
    product=F(1)
    for a in envelope: product*=a/F(2)
    assert product==c
    for j in core:
        deficit=F(1)
        for a,b in zip(envelope,sortedrows[j]): deficit*=a/b
        assert deficit==c*weight(j,F(1))/weight(j,F(2))
    return {'n':n,'sources':len(masses),'core':core,'terminal_survivors':survivors,
            'lambda':str(lam),'bound':str(upper),'c_g':str(c),
            'later_deleted_blockers':[j for j in range(len(masses)) if j not in core and j not in survivors],
            'thresholds':[[str(a) for a in row] for row in thresholds],
            'masses':[str(a) for a in masses], 'status':'exact_pass'}

def main():
    rng=random.Random(174)
    rows=[]
    # Initial exploration, deliberately adversarial score patterns/deletion, wider dimension.
    for stage,dims,reps in [('initial',[1,2,4],4),('pressure',[4,8,16],8),('expanded',[32,64,128],8)]:
        for n in dims:
            for rep in range(reps):
                m=6
                th=[[F(rng.randint(1,12),4) for _ in range(n)] for j in range(m)]
                if stage=='pressure':
                    th[0]=[F(1,2)]*n;th[1]=[F(3)]*n
                    th[2]=[F(1) if i%2 else F(2) for i in range(n)]
                mass=[F(rng.randint(1,20),20) for _ in range(m)]
                core=[0,2,4] if rep%2 else [0,4]
                survivors=[0,2,4,5] if rep%2 else list(range(m))
                row=evaluate(n,th,mass,core,survivors);row.update(stage=stage,rep=rep)
                rows.append(row)
    out={'scope':'Finite rational threshold algebra only; not physical overlaps, common f/FIRST, real receiver measure or general root bound. Deleted blockers remain in initial clock integral.','seed':174,'count':len(rows),'all_exact_pass':True,'rows':rows}
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=parser.parse_args()
    Path(args.output).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(f'{len(rows)} exact checks passed')
if __name__=='__main__':main()
