# R174 global-core and same-input coefficient budget

Start clean main af38b79d64fa751ca8c9f3e330e8e14f087b362e, correct origin. R173 progress independently audited/pushed. General n^(1/2+o(1)) weak bound remains open. Do not count another unknown moment/conditional gate as global closure. Need actual global geometry selection or original same-input coefficient budget.

Necessary context only: /Users/zhengzhihao/Desktop/T/output/centered_cube_round173_20261016_final_checkpoint/{report.md,task_contract.md,mass_sensitive_geometry.md,blocker_mass_energy.md}. R172 backup task_contract has physical kernels/residual exact definitions. f positiveL1 common;nu_V<=beta_V,sum beta_V<=f;common window a,b precedes V;Pcurrent f=q,alllegalfuture f<=q. p_y=P_s,L(x-y);J=P1,b,Q=(K1+K2+J)/3;high p_y eg>=2Kq;good p_y wg<=KQ;rho=[1−(DK0+alphaJ)/(TDelta)]+ same originalalpha;A=good rho J/(3Q). Original hard16/3 andouter2Lambda once; actualdx,history,j/window fees retained. w_t=product min(1,C((y_i-v_i)/b)/xi_t),xi∈[.5,1];k=#C_i<xi;Pi=1_Zt wt nu/et,nestedZt. C,F are not probabilities.

R173 proved: initialcore split S=Ccore⊔B, r=essinfcorek,c=exp−∫r,lambda=cg/eg∫fullinitialB∫(r−ku)+wt/c dlogt nu. λ<1 givesI[Acore]≤eg^-1∫core A wg(expΓcore/(1−λ)−1)nu;orderedB k≤r makesλ=eg^-1∫fullB(wg−cgwell)nu,includingdeletedB.Θ=Γcore−log(1−λ), Θ≤.5logn givesrootJ price;futurelogratio S−Θ≥h givesepsilon receiver. Core existence and remainingB/λ>=1 unresolved.

Also actual global EJ=∫Jv δ+²Π² beta dx dt<=nWbeta/(2K),ZJ<=log2Wbeta/(2K). Preserve b_t(v)=Pi{ku<kv} inCauchy companion Cb=∫p²A²/J*b Pi beta dx dt. rho²b<=L²wg² givesraw<=16Lambda/9 L sqrt(nlog2)Wbeta. Complement still open. Unmaskedcompanion pays common-decayzero traffic unnecessarily. Any all-traffic companion claim must pass actualsameinputtests, not independent arbitraryC arrays.

R169 completion/R171 receiver certificates are originalphysicalfiniteatoms, with carefully distinguished gate/domain status and no generally converged receiver integral. R172diagnosticK1 andn1s.25invalidsoft rows cannot be calledactualFULL. All numerical tests three stages, conservative errors, no exponentfit. No new generic strong lemma by attractive form.

Task staff max1Astrahigh,2Solhigh,1Solmedium,up to4Lunamedium; only distinct tasks started. Shared checkout: ownonlyassignedround174 files; do not revertothers; no git/spawn/PDF. Finite tasks stopafterdeliverable. Parent owns principalderivation,LaTeX,report,finalverificationandpush.
