# R174 numerical review

## Physical companion probe

The source tuple, nu and completion formula match the frozen R169/R171 point certificates. Beta includes all four actual atomic slots; its zero-mass external y=0 probe is not used. The completion is frozen at x0,L=.9 and remains unchanged when receiver/scale diagnostics change. q is fixed. The same current row computes good,U,alpha,rho,A, and the high gate; no independent C or residual amplitude is supplied.

At both N64 and128, all28 high-gated positive integrals and companions are certified zero: eight high rows have A identically zero;20 rows fail high. Original-form good/residual gates, rather than a small numerical integral, establish that conclusion. At baseline y=x0 all good tests fail; at y=r the only positive raw residual is on a bad slot. The code retains unmasked EJ separately, with coarse rigorous bounds and unresolved precision on its eight high rows. It does not infer EJ=0 from A=0.

Interval operations use the frozen directed Decimal runtime; sums of probability endpoints are accumulated as exact Fractions before outward conversion. C(0)=1 is exact. Threshold uncertainty is kept through score-count intervals, posterior intervals and Darboux bands. The clock endpoint uncertainty is also included positively. There is no signed clipping of an unknown integrand; the only positive-part operations are original rho/Delta or known probability bounds. The good-restricted moments are distinguished from raw rho moments.

j0,D4=1 and strict softness are freshly checked from inherited formulas. K remains diagnostic. Alpha is nonnegative in the displayed rows; current equality and all-future status are not transferred to perturbed receivers. Zall is a conditional model. Therefore this is a physical-form/same-atomic-input coefficient certificate, not an original source/history or FULL certificate. Parent remains responsible for independent migration replay.

## Parent core_capacity_check.py

Independent read and replay pass. On every source, 0<w<=1, k>=0 and r>=0 imply (r-k)_+w/c<=r/c. Integrating on the full initial B gives

    lambda <= c_g nu(B)/e_g * int r/c dlogt
           = (1-c_g)nu(B)/e_g.

Deleting blockers does not change that full-initial integral; the terminal e_g uses the selected survivors. All generated survivor sets include the core. The sorted-signature envelope identity is correct: the count below each time for the coordinatewise maximum of sorted core signatures equals the minimum core score count. Clipping signatures to the clock interval preserves all relevant weights and score integrals. This gives the displayed product formula for c_g and each core expGamma.

I reran the parent script with `--output /tmp/r174_core_capacity_review.json`; its60 exact Fraction rows are identical to the parent JSON. I did not modify either parent file. The seeded stages cover n1 through128 and include terminally deleted blockers, but certify finite threshold algebra only, with no physical overlaps, FIRST or source-budget payment.
