import math
import random

rng = random.Random(284)
checks = 0
for n in [1, 2, 16, 256, 65536]:
    for ratio in [1., 1.5, 2.]:
        a = 1.
        b = ratio
        gamma = 1 + 1 / n
        for k in range(51):
            xi = a / b + (1 - a / b) * k / 50
            astar = max(a, b * xi / gamma)
            A = 1 + n * math.log(b / astar)
            eta = 1 / A
            vals = [rng.random() for _ in range(31)]
            den = sum(vals)
            total = rng.random()
            w = [total * v / den for v in vals]
            G = [rng.random() for _ in vals]
            light = sum(v * g for v, g in zip(w, G) if v <= eta)
            assert light <= eta * sum(G) + 1e-12
            checks += 1
            heavy = sum(v > eta for v in w)
            assert heavy < A + 1e-12
            checks += 1
            ent = sum(v * g * math.log(1 / v)
                      for v, g in zip(w, G) if 0 < v <= eta)
            M = eta * math.log(1 / eta) if eta <= 1 / math.e else 1 / math.e
            assert ent <= M * sum(G) + 1e-12
            checks += 1
            assert A * M <= max(1, math.log(A)) + 1e-12
            checks += 1
            assert abs(A * eta - 1) <= 1e-12
            checks += 1
print({'fraction_clock_checks': checks, 'status': 'PASS'})
