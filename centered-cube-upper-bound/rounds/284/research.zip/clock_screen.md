# R284 independent actual LIGHT clock screen

**PASS.** The proposed LIGHT branch is a genuine positive restriction of the original unpaid near traffic and has the stated source budget. This is not an information surrogate or a claim to pay its HEAVY complement. No R284 author proof was read.

## Exact original allocation

Keep the original frozen outer block, actual selectors, original current positive masks, original good-upper R2<=D condition, full posterior pair, original outside 2Lambda, and the original unique j(x). Let xi=c_jt/b on the actual clock. Define

r_*(xi)=max(a,bxi/gamma),
A_xi=1+nlog(b/r_*(xi)).

On the actual clock xi is in [a/b,1], so r_*<=b and A_xi>=1. Retain the actual clock-domain receiver gate E_xi until after proving R(x),L(x)>=r_*(xi). If an enlarged xi integral is used, it is a positive extension of that gate, not a license to impose a physical lower-scale bound on unrelated receivers.

For a probability-one independent shifted coarse d-grid, define the ACTUAL full soft response

F_C(x)=integral_C p_y(x)rho(dy), w_C(x)=F_C(x)/q(x),
G_C(x)=integral_C h_R(x-z)nu(dz).

These are fixed measurable functions at each shift and receiver; F_C is not a latent component or a replacement source. Actual FIRST gives sum_C w_C<=1. Put

ell_C(x,xi)=1{w_C(x)<=1/A_xi}.

On original near define the normalized source-pair allocation

A_LIGHT(x,y,z,t)=E_shift[sum_C 1_C(y)1_C(z)ell_C(x,xi)]/P_d(y-z).

Here xi uses the actual j(x) before any change of variable. P_d>=1/2 on near. The numerator is between 0 and P_d, so A_LIGHT is an exact [0,1] original positive allocation. It depends on the actual clock and analysis grid, but not on auxiliary posterior slots v,u. If some traffic has already been paid, multiply by its actual remaining positive mask; no formerly paid left-hand allocation is reintroduced. The complementary allocation is exactly 1-A_LIGHT on the surviving near domain, not a change of source/posterior law.

## Proof of the complete positive price

The original good-upper score under R2(y,v)<=D is pointwise bounded by f_D(xi)=min(n,D/(1-xi)^2), with the D=0 zero convention. Integrate the two COMPLETE posterior probabilities only after this bound. This removes them before the receiver-dependent time transformation; no unjustified posterior/source independence is used.

Replace 1/P_d by its upper bound 2, drop the near and other positive pair masks for the upper estimate, and apply Tonelli at fixed xi and shift. The source product becomes

sum_C ell_C (F_C/q)G_C = sum_C ell_C w_C G_C
 <=A_xi^(-1) sum_C G_C
 =A_xi^(-1)(h_R(x)*nu)(x).

This pointwise step uses no cap on individual latent components. In fact neither sum w_C<=1 nor the receiver hard cap 4lambda is needed for this particular upper inequality; they are legitimate original qualifications and useful for describing the HEAVY complement. It is essential that the right side sums the actual source partition once, not a copied per-cell column budget.

On the retained actual clock receiver set, R(x)>=r_*(xi). Therefore

integral_E_xi sum_C ell_C w_C G_C dx
 <=A_xi^(-1) integral sup_[r_*(xi),b] h_r(x-z) dx nu(dz)
 =W_nu.

The exact strong envelope mass is 1+nlog(b/r_*)=A_xi. Only after dominating by this explicit envelope is the receiver integration extended to all space. This is an arbitrary actual measurable hard-scale selector, not a fixed-scale assumption or an unproved adjoint normalization.

Outside 2Lambda times the coarse factor 2 yields

P_LIGHT <=4Lambda W_nu integral_valid xi f_D(xi) dxi/xi
 <=4Lambda B_D W_nu
 <=16Lambda sqrt(nD) W_nu,

where the original clock is enlarged to the common valid interval [a/b,1] subset [1/2,1], and B_D<=min(nlog2,4sqrt(nD)). The original j(x) is unique when xi=c_jt/b is made. It is not subsequently summed as a separate copy of this source price. Additional original time masks, including a preexisting middle-clock restriction, reduce the estimate. D=0 gives zero original score traffic; zero source mass is also trivial.

The gate can thus be inserted before changing time, even though it depends on xi. It is not legitimate to freeze it at another time or claim its auxiliary-clock independence; none is needed because the score bound is pointwise at the same xi.

## Original source ledger and exact leftover

For outer expectation and terminal leaves, sum the actual W_nu once on the SAME original collection. The known original domination nu_V<=1_V f dx on disjoint terminal V gives W_nu_total<=||f||_1. Under a proved common D this yields the same source-paid bound with input mass. If D varies without a common bound, retain B_D in its original weighted source sum. No comparison nu<=rho or nu<=beta is used. This is a real general-source positive branch; it does not prove a positive coverage fraction.

The HEAVY side at the same actual shift/receiver/time is F_C>q/A_xi. Its normalized near-pair weight is the complementary conditional shift average. Actual FIRST implies fewer than A_xi heavy cells at each receiver/shift (unless none), but that count does not pay their source/score traffic or permit projecting the shift-dependent cell gate to a new fixed source subset. No negative credit or independent second source extraction is introduced.

## Actual bounded diagnostic

I ran 12 exact Fraction checks of the pointwise LIGHT inequality and the strict HEAVY-count consequence, on three finite weight/source arrays and four rational A values. Output: PASS 12. This is finite algebra only, not FULL geometry or the proof of the continuous source estimate.

```python
from fractions import Fraction as F
cases=[([F(1,8),F(1,4),F(1,2)],[F(7),F(2),F(3)]),
       ([F(0),F(1)],[F(11),F(5)]),
       ([F(1,100)]*50,[F(i+1) for i in range(50)])]
n=0
for w,g in cases:
 assert sum(w)<=1
 for A in [F(1),F(4,3),F(4),F(10)]:
  lhs=sum(ww*gg for ww,gg in zip(w,g) if ww<=1/A)
  assert lhs<=sum(g)/A
  assert sum(1 for ww in w if ww>1/A)<A or sum(1 for ww in w if ww>1/A)==0
  n+=1
print('PASS',n,'exact LIGHT-cap and heavy-count diagnostics')
```

Independent screen complete. No new author file, repository, Git operation or PDF was used.
