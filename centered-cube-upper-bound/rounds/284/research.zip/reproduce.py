from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
p=Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--check-only',action='store_true');a=arg.parse_args()
m=json.loads((p/'manifest.json').read_text())
for name,digest in m.items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest, name
print('PASS manifest',len(m),'files',flush=True)
if not a.check_only:
 for name in ['faces_checks.py','mass_checks.py','clock_checks.py','clock_screen_checks.py','support_checks.py']:
  subprocess.run([sys.executable,str(p/name)],check=True)
 with tempfile.TemporaryDirectory() as t:
  for script,expected in [('numeric.py','numeric.json'),('envelope_checks.py','envelope.json')]:
   out=Path(t)/expected
   subprocess.run([sys.executable,str(p/script),'--output',str(out)],check=True)
   assert out.read_bytes()==(p/expected).read_bytes(),expected
   print('PASS byte-identical',expected,flush=True)
 print('ALL PASS; finite checks do not certify the general theorem',flush=True)
