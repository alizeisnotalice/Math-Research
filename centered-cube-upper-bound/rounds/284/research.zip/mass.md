# R284 mass extension: a local weak estimate from capped information tiers

This note is separate from the frozen `/tmp/r284_faces.md` (SHA256 `221e2dea296325f7980c996a16e06fb0c2f436fb550d462b3e4d705dbc1c4318`). It changes no formula in that file. The new conclusion is a source-linear receiver-mass bound, followed by a genuine local maximal weak estimate for arbitrary positive L1 packets. It is not a free summation theorem over packets.

## 1. Same-response capped mass

Let pi be an arbitrary Borel probability supported in B_1(z,r), let mu=m pi with m>0, and let the measurable selected scale satisfy a<=L(x)<=b, where 0<a<=b<infinity. Put
\[
p(x)=\pi(Q_{L(x)}(x)),\qquad F(x)=mL(x)^{-n}p(x).
\]
Let E be measurable and suppose the **same response** satisfies
\[
c\lambda\le F(x)\le\lambda\quad(x\in E),\qquad
\lambda>0,\quad0<c\le1.
\]
Set
\[
\ell=\log(1/c),\quad A=2+\ell,\quad
B=\ell+2\sqrt{2nr/a}.
\]
Then
\[
\boxed{\quad
\int_E F(x)dx\le mA(B+3),\qquad
\lambda|E|\le \frac m c A(B+3).
\quad}                                                       \tag{1}
\]
The bound is independent of b/a. At r=a/(16 sqrt(n)) it becomes
\[
\int_EF\le m(2+\ell)
\left(3+\ell+\frac{n^{1/4}}{\sqrt2}\right).                   \tag{2}
\]
For fixed c this is an O(n^(1/4)m) receiver-response estimate. It is stronger than the root-order information estimate because there is no factor k+1 in the tier sum.

Proof. Use the tiers E_k={e^(-k-1)<p<=e^(-k)} intersected with E. The proven short-window and exact l1-support-volume arguments give, for every k>=0,
\[
\int_{E_k}F\le m\min\{A,e^{B-k}\}.                          \tag{3}
\]
Explicitly, the response cap forces n log(u_k/l_k)<=1+ell; the full-space positive hard envelope over that window has mass at most mA. Also E_k lies in Q_(u_k)(z)+B_1(r), whose volume is at most u_k^n exp(2 sqrt(2nr/u_k)); using F<=lambda and u_k^n<=me^-k/(c lambda) gives the second term. These use the same original measure mu, not normalized copies of its tiers.

Let K=ceil(B). Sum A for 0<=k<=K and e^(K-k) for k>K:
\[
\sum_{k\ge0}\min(A,e^{B-k})
\le A(K+1)+\frac1{e-1}
\le A(B+3).
\]
This proves the first bound; c lambda|E|<=int_E F proves the second. The cases m=0 are zero. At r=0 the estimates remain valid, though nonsharp.

## 2. A genuine local weak maximal theorem

Assume now that mu is an arbitrary nonnegative finite L1 density, supported in B_1(z,r), of mass m. Define the centered, normalized hard maximal operator with a lower scale cutoff by
\[
\mathcal M_{[a,\infty)}\mu(x)
=\sup_{R\ge a}R^{-n}\mu(Q_R(x)).
\]
For every lambda>0,
\[
\boxed{\quad
\lambda\big|\{\mathcal M_{[a,\infty)}\mu>\lambda\}\big|
\le 2m\left(3+2\sqrt{2nr/a}\right).
\quad}                                                       \tag{4}
\]
In particular, the same bound holds for M_[a,b] for every finite b>=a. At the original radius,
\[
\lambda|\{\mathcal M_{[a,b]}\mu>\lambda\}|
\le (6+\sqrt2\,n^{1/4})m,
\qquad r=a/(16\sqrt n).                                    \tag{5}
\]
This is a uniform weak estimate for all within-packet L1 shapes, not just a point mass or a product input.

### 2.1. Continuity and measurable near-threshold selection

For fixed x, R -> R^-n mu(Q_R(x)) is continuous on [a,infinity). Indeed the boundaries of each cube are Lebesgue-null, so they have zero mu mass; dominated convergence applies to the cube indicators as R varies. Also this response is bounded by m/R^n and tends to zero as R tends to infinity. For fixed R it is measurable in x.

Let E_lambda={M_[a,infinity)mu>lambda}. Density of rational scales together with continuity shows this is a countable union of measurable sets. Fix epsilon>0. For every x in E_lambda there is a scale at which the response lies strictly between lambda and (1+epsilon)lambda: either an initial response already lies there, or continuity and decay give a crossing from above. The strict interval persists in a neighborhood of the chosen scale, so a rational scale also works. Enumerate the rationals in (a,infinity), and choose the first qualifying rational. This defines a measurable selector L_epsilon(x) on E_lambda.

If m<=lambda a^n, then E_lambda is empty. Otherwise every chosen scale obeys
\[
a\le L_\epsilon(x)<(m/\lambda)^{1/n}=:b_*<\infty,             \tag{6}
\]
because its response exceeds lambda. Thus the selector falls within a finite common window, even though the maximal function was defined using all R>=a. Extend it by a outside E_lambda if needed.

### 2.2. Apply the same-response theorem and take a scalar limit

Use Section 1 with upper cap lambda'=(1+epsilon)lambda and c=(1+epsilon)^-1. Its lower cap is precisely lambda. Consequently,
\[
\lambda|E_\lambda|
\le\int_{E_\lambda}F_\epsilon
\le m[2+\log(1+\epsilon)]
 [3+\log(1+\epsilon)+2\sqrt{2nr/a}].                         \tag{7}
\]
Let epsilon decrease to zero in this numerical upper bound. The set E_lambda does not change with epsilon; convergence of the selectors or responses is not required. This gives (4). The proof has used absolute continuity only for the scale-continuity step; it asserts (4) for arbitrary positive L1 sources without an additional atom-crossing argument.

## 3. Exact scope relative to the original selected problem

The weak theorem for M_[a,b] follows by inclusion in M_[a,infinity). The measurable witness used in its proof may be larger than the original b. It is an analysis device, not a replacement for the actual physical selector, and receives no new FIRST cap. Section 1, in contrast, directly treats an actual selector when its own packet response has the stated two-sided cap.

An upper cap for a larger source does pass to a positive packet restriction. Its lower cap does not. Formula (4) avoids assuming a packet lower cap by constructing a new threshold witness for that packet, but it bounds only the packet's maximal level set. Summing (4) over many packets is not a free weak-L1 inequality for their sum. Likewise applying it to rho restricted to B_1(z,r) and integrating in nu(dz) still repeats source mass unless an additional mass-conserving allocation is supplied. Neither the original auxiliary posterior nor its normalization is altered. No full original traffic estimate is claimed here.

## 4. Bounded local diagnostic

The following code was actually run and returned PASS 18. It tests the unweighted scalar series used in (1); the theorem is proved analytically above, and these floating-point tests are not interval certificates.

```python
import math
count=0
for c in (1.,.5,.01):
    for v in (0.,.1,1.,4.,12.,40.):
        ell=math.log(1/c); A=2+ell; B=ell+v
        S=math.fsum(min(A,math.exp(B-k))
                    for k in range(int(B)+150))
        assert S<=A*(B+3)
        count+=1
print('PASS',count,'unweighted series diagnostics; not interval certificates')
```
