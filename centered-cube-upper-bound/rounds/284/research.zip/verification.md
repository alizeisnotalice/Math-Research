# Verification scope

Parent read all three proofs and all three final independent audits, and replayed the advertised scripts. The full package reproduction is run before archival; successful output is recorded in the final report. No PDF is compiled.

Author hashes: clock b8929c1a7eb8532c0dbca782215e34ee246d7441160c9b795547037659d99587; faces 221e2dea296325f7980c996a16e06fb0c2f436fb550d462b3e4d705dbc1c4318; mass 4acab79c70051cc2d9164b9a395011bb5d728750bc40280efa15e7a0898a4fa3.

Final independent receipts: clock cc2935d0a4bed773e3497dc13cc76623daa9ebfa3ba4eb53af8a03f6ff369dbd; faces b6c13b08f2ea52a060170fdc3e4c3294dfe869fb950f05fe5669b7fefd7a0968; mass 789399ca6ba92ff17374de593f6019fa185c807b3c8823ae842ea91defdc08b4.

The runtime used is /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 with PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor (mpmath1.3.0). Archive script names omit their /tmp/r284_ prefix; script contents and source hashes are unchanged.

Ordinary multiprecision is not directed interval arithmetic. Artificial finite cell weights do not constitute an original source/receiver geometry. The radial two-atom model verifies one cap mechanism and is not a general L1/FULL input. Infinite tier sums are proved by explicit geometric tails, not by finite floating samples. A complete heavy-traffic theorem is absent.

Actual default reproduce.py run: ALL PASS; numeric.json and envelope.json independently recomputed byte-identically. Exit code 0.
