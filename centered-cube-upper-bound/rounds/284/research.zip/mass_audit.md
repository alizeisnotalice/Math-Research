# R284 independent audit: packet mass and genuine cluster weak bound

## MA1. Independent statement screen before author proof

**Independent screen: PASS.** This section was written and sent to the parent before reading `/tmp/r284_mass_extension.md`. Author binding and final receipt follow after the proof is supplied.

Retain the already audited tier estimates for a source mu=m pi supported in B1(z,r), with its own selected response F and same-response cap c Lambda<=F<=Lambda. Write ell=log(1/c), A=2+ell, v=2sqrt(2nr/a), B=ell+v. For each tier exp(-k-1)<p<=exp(-k), the established bounds are

`integral_Ek F <=m min(A,exp(B-k))`.

Dropping the entropy factor k+1, choose K=ceil B. Then

`sum_(k>=0)min(A,exp(B-k))`

` <=A(K+1)+1/(e-1) <=A(K+2)<=A(B+3)`.

Here A>=2 and e-1>1. Thus

`integral_E F <=m(2+ell)(3+ell+2sqrt(2nr/a))`.

The same-response lower cap gives

`Lambda |E| <=(m/c)(2+ell)(3+ell+2sqrt(2nr/a))`.

This step requires that lower cap on this same packet, not a larger total source.

Now let mu be any finite positive L1 source supported in B1(z,r), and define the genuine hard maximal operator over all L>=a. For every x, F_L(x)=L^-n mu(Q_L(x)) is continuous in L>0: the source is absolutely continuous and each cube boundary has zero source mass. Also F_L(x)<=m/L^n tends to zero as L tends to infinity. Consequently if sup_(L>=a)F_L(x)>lambda, continuity and decay supply a scale L>a with lambda<F_L(x)<2lambda. An open neighborhood of that scale contains a rational such scale.

Enumerate rational scales greater than a and choose the first satisfying that strict band. The resulting selector is measurable because each fixed-scale response is Borel. Every chosen scale obeys L<(m/lambda)^(1/n). If m<=lambda a^n the event is empty. Otherwise b_lambda=(m/lambda)^(1/n)>a is a fixed finite upper scale for the selector, and the previously proved mass estimate applies uniformly to this [a,b_lambda] window.

Use its upper cap Lambda=2lambda and c=1/2. Directly lambda|E|<=integral_E F, so

`lambda |{sup_(L>=a) h_L*mu>lambda}|`

` <=m(2+log 2)(3+log 2+2sqrt(2nr/a))`.

There is **no additional factor 2**. Equivalently the general measure bound's Lambda=2lambda and 1/c=2 cancel. At r=a/(16sqrt(n)), the last square-root term equals n^(1/4)/sqrt(2), so this is a true source-cluster weak bound of order 1+n^(1/4).

If the event originally involves only [a,b], its inclusion in the all-scales event gives the same upper bound. The proof may select a larger scale solely for that standalone upper estimate; it transfers no original FIRST, posterior, or traffic qualification to that selected scale. A fixed-z near restriction remains a source packet charged by its own mass; summing such packets over a second source still needs an authentic source allocation.

### MA1a. Independently screened epsilon refinement

For every epsilon>0, continuity and decay allow the same maximal event to be witnessed by rational scales with lambda<F<(1+epsilon)lambda. Use upper cap Lambda=(1+epsilon)lambda and c=1/(1+epsilon), hence ell=log(1+epsilon). The same finite b_lambda bounds every such witness. The unchanged event measure obeys

`lambda |E| <=m(2+ell)(3+ell+v)`

for every epsilon>0. Taking the infimum as epsilon decreases to zero gives

`lambda |E| <=2m(3+2sqrt(2nr/a))`.

At r=a/(16sqrt(n)) this is `(6+sqrt(2)n^(1/4))m`. No convergence of the chosen selectors is required: only the right-hand constants vary, while the left-hand event is the same. This argument must not be misread as passage to a limit in an entropy functional whose selected F,p change with epsilon. It gives no new original-selector or soft-cap qualification.

## MA2. Final author proof and binding

**Final verdict: PASS, no correction requested.**

Author file read in full and SHA actually verified:

`/tmp/r284_mass_extension.md`

SHA256 `4acab79c70051cc2d9164b9a395011bb5d728750bc40280efa15e7a0898a4fa3`.

The author statement and proof agree with the independent screen in MA1 and MA1a. Specifically:

1. The mass series drops the entropy factor k+1 and retains both tier bounds. With K=ceil B, its exponential tail is at most 1/(e-1), so A(K+1)+1/(e-1)<=A(B+3). No constant source fee is summed infinitely without the geometric cutoff.
2. The same-response lower cap is used exactly once for the receiver-measure conclusion. No lower bound for a total response is transferred to a packet.
3. The genuine maximal weak theorem is expressly restricted to positive L1 sources for the continuity step. Absolute continuity makes every fixed cube boundary source-null, so scale continuity holds for every x. Mass decay to zero is uniform in x by m/R^n.
4. The open near-threshold band contains a rational scale greater than a even when the first above-threshold response occurs at a. First qualifying enumeration gives a measurable selector. Its upper scale is bounded by the same fixed b_*=(m/lambda)^(1/n), independently of epsilon. If b_*<=a, the superlevel event is empty.
5. Each epsilon proof bounds the unchanged maximal superlevel set. Taking the scalar infimum of the numerical upper bounds is legitimate; it does not require convergence of L_epsilon or an entropy functional under changing kernels.
6. The refined coefficient is exactly 2m(3+v), with v=2sqrt(2nr/a). There is no missing extra factor 2. At r=a/(16sqrt(n)) the coefficient becomes 6+sqrt(2)n^(1/4), as stated.
7. A witness scale beyond an original finite b is used only to upper-bound the standalone maximal level set. The author explicitly does not transfer actual FIRST, source/history qualifications or the original physical selector to that witness.
8. The weak estimate charges each packet mass. Summing arbitrary packets or repeating rho|B1(z,r) over nu still needs an actual mass-conserving allocation. This is explicitly retained, so the theorem is not presented as general original-traffic closure.

## MA3. Actual diagnostic replay

The author's one embedded block was independently extracted and run without edits. Actual output:

```text
AUTHOR_SHA256 4acab79c70051cc2d9164b9a395011bb5d728750bc40280efa15e7a0898a4fa3
PASS 18 unweighted series diagnostics; not interval certificates
```

The 18 cases are three c values times six v values. They use ordinary binary floating point and truncate the diagnostic sum at `int(B)+149`; they do not themselves certify an infinite series. The independent analytic geometric-tail calculation in MA1 and the author's corresponding proof establish the full infinite sum. No new interval or FULL-input claim is made.

Exact replay:

```python
from pathlib import Path
import hashlib
p=Path('/tmp/r284_mass_extension.md')
s=p.read_text()
print('AUTHOR_SHA256',hashlib.sha256(s.encode()).hexdigest())
blocks=[x.split('\n```')[0] for x in s.split('```python\n')[1:]]
assert len(blocks)==1
exec(compile(blocks[0],str(p)+' diagnostic','exec'),{})
```

**Final status: PASS, frozen at the author hash in MA2. Only this owned audit file was written. No author/repository/Git/PDF state was changed, and no further task or numerical expansion is needed.**
