#!/usr/bin/env python3
"""R284 diagonal atomic radial-selector cap mechanism, finite diagnostics."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as m

def enc(x):return m.nstr(x,90)
MENU=[('initial',2),('initial',8),('initial',32),('stress',128),('stress',512),('expanded',2048)]
CS=['.75','.1','.001']
def primitive_integral(n,q,loglo,loghi):
 # Finite exact polynomial identity for integer n; evaluated in ordinary mp.
 length=loghi-loglo;value=length;coef=m.mpf(1)
 for k in range(1,n):
  coef*=-(n-k)*q/k
  value+=coef*m.exp(-k*loglo)*(-m.expm1(-k*length))/k
 return value

def run(dps):
 with m.workdps(dps):
  log2=m.log(2);logpivot=m.log(m.mpf('1.2'));rows=[];uncap=[];tol=m.mpf(10)**(-dps+10)
  for phase,n in MENU:
   nn=m.mpf(n);r=1/(16*m.sqrt(nn));eps=r/nn;q=2*eps;logmass=m.log(2)+nn*logpivot
   fn=lambda logL:m.exp((nn-1)*m.log1p(-q*m.exp(-logL)))
   unc_quad=nn/2*m.quad(fn,[0,log2/2,log2]);unc_primitive=nn/2*primitive_integral(n,q,m.mpf(0),log2)
   assert abs(unc_quad-unc_primitive)/max(1,abs(unc_quad))<tol and unc_quad<=nn/2*log2
   uncap.append({'phase':phase,'n':n,'r':enc(r),'epsilon':enc(eps),'log_mass_m_lambda1':enc(logmass),'uncapped_safe_integral_over_mass_quad':enc(unc_quad),'uncapped_safe_integral_over_mass_primitive':enc(unc_primitive),'uncapped_upper_n_log2_over2':enc(nn/2*log2),'uncapped_over_n':enc(unc_quad/nn)})
   for cs in CS:
    c=m.mpf(cs);loglo=max(m.mpf(0),logpivot);loghi=min(log2,logpivot-m.log(c)/nn);xhi=nn*(loghi-logpivot);empty=loghi<=loglo
    if empty:actual=direct=closed=m.mpf(0)
    else:
     # x=nlog(L/1.2), all cap spans are resolved on an O(log1/c) interval.
     actual=m.quad(lambda x:fn(logpivot+x/nn)/2,[0,xhi/2,xhi])
     direct=nn/2*m.quad(fn,[loglo,(loglo+loghi)/2,loghi])
     closed=nn/2*primitive_integral(n,q,loglo,loghi)
    capbound=-m.log(c)/2;strong=nn*(loghi-loglo)/2 if not empty else m.mpf(0)
    assert abs(actual-direct)/max(1,abs(actual))<tol and abs(actual-closed)/max(1,abs(actual))<tol
    assert actual<=strong+tol and strong<=capbound+tol
    lowF=m.exp(nn*(logpivot-loglo));hiF=m.exp(nn*(logpivot-loghi))
    assert lowF<=1+tol and hiF>=c-tol
    row={'phase':phase,'n':n,'c':cs,'empty_cap_window':empty,'upper_clipped_by_b':loghi==log2}
    for k,v in [('log_L_lower',loglo),('log_L_upper',loghi),('L_lower',m.exp(loglo)),('L_upper',m.exp(loghi)),('x_upper',xhi),('F_over_lambda_at_lower',lowF),('F_over_lambda_at_upper',hiF),('capped_safe_integral_over_mass_xquad',actual),('capped_safe_integral_over_mass_logLquad',direct),('capped_safe_integral_over_mass_primitive',closed),('cap_upper_log1c_over2',capbound),('actual_span_upper',strong),('cap_margin',capbound-actual),('capped_to_uncapped_ratio',actual/unc_quad),('scaled_closed_quad_difference',abs(actual-closed)/max(1,abs(actual)))]:row[k]=enc(v)
    rows.append(row)
  return {'uncapped':uncap,'capped_cases':rows}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(60)
 with m.workdps(110):
  diff={}
  for family in ['uncapped','capped_cases']:
   for i,(x,y) in enumerate(zip(lo[family],hi[family])):
    for k,v in x.items():
     if not isinstance(v,str) or k in ['phase','c']:continue
     diff[family+'/'+str(i)+'/'+k]=abs(m.mpf(v)-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  worst=max(diff,key=diff.get);maximum=enc(diff[worst]);assert diff[worst]<m.mpf('1e-27')
 out={'schema':'R284-radial-selector-cap-finite-mechanism-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'dimensions':6,'capped_cases':18,'capped_stage_cases':{'initial':9,'stress':6,'expanded':3},'uncapped_cases':6,'precisions':[40,60],'precision_fields':len(diff)},'mp40':lo,'mp60':hi,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'definitions':{'a':'1','b':'2','lambda':'1','radial_selector':'L=2max_i |x_i| on shell1<=L<=2','r':'1/(16sqrt n)','epsilon':'r/n','mass_log':'log m=log2+nlog1.2','safe_integral':'(mn/2)int_Llo^Lhi (1-2epsilon/L)^(n-1)dL/L','cap':'c lambda<=F=m/(2L^n)<=lambda','normalized_cap_bound':'safe_integral/m<=.5log1/c'},'scope':['Twoatoms at plus/minus epsilon times all-ones vector; singular diagnostic, not L1/FULL. Safe region is |x_other|<L/2-epsilon at the unique max face, equivalently full-side gap L-2max_other|x|>2epsilon; this ensures one atom is selected with p=.5. Integral is not a general source theorem.','Ordinary40/60mp not intervals; independent log-variable quadratures and finite binomial primitive agree. No tail truncation; all scale intervals bounded and actual clipped cap endpoints retained.','All quantities are mass-normalized; logmass avoids overflow. Uncapped growth versus capped values is recorded at finite dimensions without an asymptotic fit or general source-budget assertion.','No original FIRST/high/history or theorem/root certification; no repository/Git/PDF changes.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maximum,'worst':worst}))
if __name__=='__main__':main()
