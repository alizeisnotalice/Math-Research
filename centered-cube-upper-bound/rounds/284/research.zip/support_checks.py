import math
checks=0
for ell in (0.,math.log(2),math.log(10),math.log(1000)):
 for n in (1,2,8,32,128,512,2048):
  r=1/(16*math.sqrt(n)); v=2*math.sqrt(2*n*r); A=2+ell; B=ell+v
  vals=[min(A,math.exp(B-k)) for k in range(math.ceil(B)+160)]
  tail=math.exp(B-len(vals))/(1-math.exp(-1))
  assert math.fsum(vals)+tail<=A*(B+3)
  assert math.fsum((k+1)*v for k,v in enumerate(vals))<=A*(B+3)**2
  checks+=2
print('PASS',checks,'ordinary scalar support-tier checks; no interval certification')
