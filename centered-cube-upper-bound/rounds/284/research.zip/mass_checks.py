import math
count=0
for c in (1.,.5,.01):
    for v in (0.,.1,1.,4.,12.,40.):
        ell=math.log(1/c); A=2+ell; B=ell+v
        S=math.fsum(min(A,math.exp(B-k))
                    for k in range(int(B)+150))
        assert S<=A*(B+3)
        count+=1
print('PASS',count,'unweighted series diagnostics; not interval certificates')
