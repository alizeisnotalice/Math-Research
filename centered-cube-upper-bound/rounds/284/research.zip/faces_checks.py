import math
checks=0
for n in (1,2,8,64,512):
    for rr in (1e-6,1/(16*math.sqrt(n)),.125,1.0):
        terms=[1.0]
        for j in range(n):
            terms.append(terms[-1]*(n-j)*2*rr/(j+1)**2)
        logvol=math.log(math.fsum(terms))
        assert logvol <= 2*math.sqrt(2*n*rr)+1e-12
        checks+=1
for c in (1.0,.5,.01):
    for B0 in (0.,.1,1.,4.,12.,40.):
        A=2+math.log(1/c); B=B0+math.log(1/c)
        val=math.fsum((k+1)*min(A,math.exp(B-k))
                     for k in range(int(B)+150))
        assert val<=A*(B+3)**2
        checks+=1
print('PASS',checks,'bounded scalar diagnostics; not interval certificates')
