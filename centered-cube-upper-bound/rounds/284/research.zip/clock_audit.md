# R284 actual LIGHT author audit

**Final PASS. No necessary correction remains.** The LIGHT theorem and optional entropy/source statements pass. The sole previously requested display repair has been checked in the final bound version: its posterior score inequality now explicitly retains `1_{R2(y,v)<=D}`. No constant or proof mechanism changed. The HEAVY branch is not paid.

## Version binding and independent chronology

Author `/tmp/r284_adaptive.md` SHA256:
`b8929c1a7eb8532c0dbca782215e34ee246d7441160c9b795547037659d99587`.

Superseded first-read version: `9eb66874d9384f56b7f72a043988f7e79a22f7b43969351c2d88ed257bfdac1d`. Only the explicit R2 display repair was requested and rechecked; no earlier proof step was repeated.

Independent pre-author actual-traffic screen `/tmp/r284_clock_screen.md` SHA256:
`c4d0e85dc2e2601df215884d8a81dcdbfa2f95e399c6f0ab9435031a7e08615f`.

The screen was saved before reading the author file; its proof matches the author's actual LIGHT mechanism. The author hash was verified before the complete read. No author or repository file was modified.

## Resolved narrow display correction

The superseded LIGHT proof displayed expectation read

E_{Pi_t x Pi_t}[(k_t(v)-k_t(u))_+ 1_good(v)] <= f_D(xi).

The words before it say the original upper-slot R2 restriction is retained, and Proposition P1 also explicitly requires it. The standalone displayed inequality nevertheless needs `1_{R2(y,v)<=D}` (or a precise definition of its displayed good indicator as already including that current mask). Terminal classifier-good alone does not imply the R2 score bound. The final hash-bound file now has the required corrected display:

E_{Pi_t x Pi_t}[(k_t(v)-k_t(u))_+ 1_good(v) 1_{R2(y,v)<=D}]
 <=min(n,D/(1-xi)^2).

Additional original masks can remain or be discarded positively AFTER this pointwise bound. This is a notation/domain repair, not a gap in the already stated intended theorem. For D=0 use the zero score convention; the xi=1 endpoint has zero continuous clock measure.

## 1. Nonnegative exact original allocation

F_C and G_C are the actual full soft and actual hard responses of genuine source restrictions. Actual summed FIRST gives sum_C F_C/q<=1. No latent rectangle, new soft node or replacement source is assigned FIRST. The normalized conditional-shift LIGHT numerator lies between 0 and P_d; hence both LIGHT and HEAVY are [0,1] allocations on original near and split its positive integrand exactly. Off-near zero conventions do not affect that original domain.

The gate depends on physical xi and can be inserted before changing time through xi=c_jt/b. It is independent of auxiliary v,u, which is what the posterior step requires; it need not be time independent. The actual currently unspent mask must remain in the LEFT-HAND allocation, even though it is dropped positively for the upper estimate. No old top/interior/single-cut/latent portion is charged again.

## 2. Physical scale envelope and raw/source constants

At fixed xi, keep the actual clock-domain receiver set E_xi until the original scale qualification yields L,R>=a_xi=max(a,bxi/gamma). Both scales are still in [a,b]. On that receiver set,

sum_C 1_light w_C G_C <=A_xi^(-1)sum_C G_C
                         =A_xi^(-1)(h_R(x)*nu)(x).

The sum uses each original source restriction once. The exact all-scale hard envelope over [a_xi,b] has L1 mass A_xi=1+nlog(b/a_xi), including a degenerate single scale. Thus its integral cancels the LIGHT threshold exactly and gives W_nu, with no cell count, hidden hard-source copy, receiver expansion or unproved normalization. Extension of dx to all space occurs only after the envelope domination. Actual hard cap 4lambda is preserved but not needed in this step. No nu<=rho comparison is used.

With the required R2 score indicator explicit, the full posterior pair is bounded pointwise before changing to a receiver-dependent transformed clock. The actual j(x) remains unique until that step. The coarse same-cell upper estimate contributes 2, and the original outside coefficient contributes 2Lambda once. Thus

P_cur,light<=4Lambda W_nu integral_middle f_D(xi)dxi/xi
           <=4Lambda B_D W_nu<=16Lambda sqrt(nD)W_nu.

Every original extra positive history, terminal hard-carrier or middle-clock mask only lowers this estimate. It may be dropped for the majorant without restricting or renormalizing the original complete Pi_t. No new j-source sum, seed factor or signed credit appears.

For the original same disjoint terminal collection, sum W_nu once and then take the original outer expectation. The already bound original domination nu_V<=1_V f dx supplies W_nu_total<=||f||_1. The author's careful formulation in terms of the original W_nu is valid even before this conversion. Repeated ancestors or arbitrary overlapping source families would not inherit it. If D varies without a proved common bound, B_D must remain inside the source-weighted expectation, as stated. The theorem asserts no positive coverage fraction; LIGHT can have zero current mass.

## 3. Exact HEAVY remainder and simultaneous constraints

The conditional-shift formula (4) is exactly complementary to LIGHT because the two threshold events partition the same actual coarse-pair event; equality belongs to LIGHT. Its original source pair, current masks and full auxiliary posterior remain intact. Only for an upper estimate is 1/P_d replaced by 2.

HEAVY implies F_C/q>1/A_xi with F_C/q<=1. Therefore the two same-response inequalities (5) are correct for variable q(x). Since sum w_C<=1, the number of HEAVY cells at fixed receiver/shift/clock is strictly less than A_xi. This is a local count, not a source-global cardinality bound or a capacity payment.

The actual soft density satisfies p_y<=L^(-n): h<=1, w has mass one, and phi=h*w<=1, so f_s<=1 for all s in [0,1]. Hence F_C<=rho(C)L^(-n), giving the strict mass lower bound (6), including L>=a_xi. This step is valid for genuine full source cells; it gives no lower cap to individual latent components. None of (4)-(6) pays HEAVY traffic, and the note does not claim otherwise.

## 4. Fraction entropy and source-diagnostic KL

For eta in (0,1], M(eta)=sup_[0,eta] wlog(1/w) has precisely the displayed two branches. Zero weights use the usual zero convention. Each coefficient of G_C in (7) is at most M(eta), so summing the ORIGINAL hard responses gives the same column A_xi. For eta=1/A_xi,

A_xi M(1/A_xi)<=max(1,log A_xi):

it equals log A_xi for A_xi>=e, and is A_xi/e<=1 for 1<=A_xi<=e. This is a genuine bound independent of any source-cell prior entropy. It does not assert sum_C M_i or sum_C hard caps is dimension free; it sums the actual G_C once. The original score-clock and conditional-shift constants then yield (8) exactly. If desired the inserted fraction-log factor can be defined by its conditional-shift average at the original source pair. It is not a posterior replacement.

For m_C>0 and F_C(x)>0, pi_C=rho|C/m_C and pi_C,x=p_y rho|C/F_C are legitimate diagnostic probability measures. Under a hard input kernel its posterior is the prior conditioned on Q_L(x), so KL=log[m_C/(L^nF_C)]=log(c_C/w_C). For the actual soft input, its Radon-Nikodym density relative to pi_C is bounded above by m_C/(L^nF_C), proving the KL upper bound in (9). That constant is >=1 because F_C<=m_C L^(-n), so there is no negative-log contradiction. The further inequality log(c_C/w_C)<=log_+c_C+log(1/w_C) is correct since w_C<=1. Undefined zero-mass/zero-response cases carry zero source-response cost and are excluded from the diagnostic definition.

These diagnostic posteriors are NOT the original auxiliary Pi_t. The author explicitly retains this distinction and warns that inserting arbitrary source-dependent near/history masks into a signed KL integrand does not preserve the displayed KL inequality. Only the fraction-log part is paid by (7); the amplitude log_+c_C remains explicit and unpaid. This optional information discussion is not used to prove the raw P1 payment.

## 5. Diagnostic evidence and scope

The supplied diagnostic script `/tmp/r284_clock_checks.py` has SHA256 `d7a4c6fc627f9613461e519c00a9a4516521b021a715e53eb4aebce3a8d5d7f2`. After checking its hash and reading the complete code, I actually ran it. Output: `fraction_clock_checks=3825, status=PASS`. These are five ordinary floating assembly inequalities on each of 5 dimensions, 3 scale ratios and 51 clock nodes, with seeded artificial nonnegative cell arrays; the name does not make the arithmetic Fraction-exact. It is not actual receiver/source geometry or a FULL original-history construction. The script checks its advertised elementary LIGHT, heavy-count, fraction-log and reciprocal-factor statements, not source coverage or a PDE/physical kernel theorem. My independent pre-author screen additionally contains an actually run 12-case exact Fraction LIGHT/count diagnostic and complete code. The analytic proof above, not either finite suite, is the basis for PASS. No interval certificate or universal coverage is asserted.

The unconditional adaptive-information paragraph is an auxiliary arbitrary-selector observation, explicitly not a FULL original instance and not part of the actual payment proof. The actual achievement is the source-paid original LIGHT allocation. The exact HEAVY positive remainder remains unpriced; the general root-order goal is not certified.

Audit complete and frozen for the final bound version; the explicit R2 display repair is resolved. No repository change, Git, PDF, new route or repeated broad test.
