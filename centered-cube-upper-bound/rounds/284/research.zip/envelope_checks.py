#!/usr/bin/env python3
"""R284 supplemental envelope identity and bounded scalar clock; not FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as m

def enc(x):return m.nstr(x,90)
def exact_envelope():
 rows=[];a=F(1);b=F(2)
 for n in [1,2,8]:
  for radial in [F(0),a/2,a,(a+b)/2,b,b+F(1,8)]:
   # radial=2||u||infty is cube side threshold, not ||u||infty.
   lower=max(a,radial);sup=lower**(-n) if radial<=b else F(0)
   hb=b**(-n) if radial<=b else F(0);integral=lower**(-n)-b**(-n) if lower<b else F(0)
   assert sup==hb+integral
   rows.append({'n':n,'a':'1','b':'2','radial_2norm_exact':str(radial),'sup_h_exact':str(sup),'h_b_exact':str(hb),'integral_n_h_t_dt_over_t_exact':str(integral),'rhs_exact':str(hb+integral)})
 return rows

def clock_primitive(h):return m.log(h)-1/h-m.log1p(-h)
def run(dps):
 with m.workdps(dps):
  tol=m.mpf(10)**(-dps+10);rows=[];masses=[]
  for n in [1,2,8]:
   # Volume of {2||u||infty<=r} is r^n; radial Jacobian is nr^(n-1).
   value=m.quad(lambda r:n*r**(n-1),[0,1])+m.quad(lambda r:n/r,[1,2]);closed=1+n*m.log(2)
   assert abs(value-closed)<tol
   masses.append({'n':n,'radial_mass_quad':enc(value),'mass_closed_1_plus_nlog2':enc(closed)})
  for n in [2,8,32,128,512,2048]:
   nn=m.mpf(n)
   for kind in ['.001','1','log(n+2)','n']:
    D=m.log(n+2) if kind=='log(n+2)' else nn if kind=='n' else m.mpf(kind);q=m.sqrt(D/nn);cut=min(m.mpf('.5'),q)
    terminal=-nn*m.log1p(-cut)
    closed=terminal if q>=m.mpf('.5') else terminal+D*(clock_primitive(m.mpf('.5'))-clock_primitive(q))
    direct=m.quad(lambda x:nn*cut/(1-cut*x),[0,1])
    if q<m.mpf('.5'):
     top=m.log(m.mpf('.5')/q)
     direct+=m.quad(lambda v:D/(q*m.exp(v)*(1-q*m.exp(v))),[0,top/2,top])
    bound=4*m.sqrt(nn*D)
    assert abs(closed-direct)/max(1,abs(closed))<tol and closed<=bound+tol*max(1,bound)
    rows.append({'n':n,'D_kind':kind,'D':enc(D),'split_h_sqrt_D_over_n':enc(q),'split_xi_1_minus_sqrt':enc(1-q),'whole_window_saturated':q>=m.mpf('.5'),'B_D_closed':enc(closed),'B_D_quad':enc(direct),'bound_4sqrt_nD':enc(bound),'margin':enc(bound-closed),'ratio_to_bound':enc(closed/bound)})
  return {'envelope_mass_checks':masses,'clock_cases':rows}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args();exact=exact_envelope();lo=run(40);hi=run(60)
 with m.workdps(110):
  diffs={}
  for family in ['envelope_mass_checks','clock_cases']:
   for i,(x,y) in enumerate(zip(lo[family],hi[family])):
    for k,v in x.items():
     if not isinstance(v,str) or k=='D_kind':continue
     diffs[family+'/'+str(i)+'/'+k]=abs(m.mpf(v)-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  worst=max(diffs,key=diffs.get);maximum=enc(diffs[worst]);assert diffs[worst]<m.mpf('1e-28')
 out={'schema':'R284-supplement-envelope-and-clock-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'Fraction_envelope_nodes':18,'envelope_mass_checks_per_precision':3,'clock_cases_per_precision':24,'precision_fields':len(diffs)},'exact_envelope':exact,'mp40':lo,'mp60':hi,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'proof_scope':['Exact envelope identity at finite nodes uses radial=2||u||infty. At radial=b the integral is0 and h_b remains positive; beyond b both vanish. h_t uses the closed cube convention at equality; endpoint integral values do not affect dt measure.','Envelope mass is1+nlog(b/a) by radial volume derivative nr^(n-1), checked numerically at n1/2/8. This is a hard-kernel envelope, not an original FULL source model.','Clock h=1-xi splits at sqrt(D/n). Closed primitive and independent quadrature in h=cut*x and h=qexp(v) agree. B_D<=4sqrt(nD) follows analytically from1/(1-h)<=2 and int_0^.5 min(n,D/h²)dh<=2sqrt(nD), not from finite samples.','Ordinary40/60 mpmath, no outward interval certificate. No old main numerical file or repository/Git/PDF changed.']}
 text=json.dumps(out,sort_keys=True,indent=2)+'\n'
 if a.output:a.output.write_text(text)
 else:print(text,end='')
if __name__=='__main__':main()
