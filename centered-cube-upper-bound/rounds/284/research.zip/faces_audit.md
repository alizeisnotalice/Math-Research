# R284 independent audit: same-response capture entropy

## FA1. Independent screen recorded before reading the author proof

**Independent statement screen: PASS.** The proof below was derived before reading `/tmp/r284_faces.md` and was sent to the parent first. Final author binding and replay results are recorded after FA2.

Assume lambda>0, 0<c<=1, m>0, a>0, b>=a, and pi any Borel probability supported in B1(z,r), r>=0. Let L(x) in [a,b] be measurable, p(x)=pi(Q_L(x)), and F(x)=m L(x)^(-n)p(x). On the same measurable E assume c lambda<=F(x)<=lambda. Set ell=log(1/c), M=2sqrt(2nr/a), A=ell+M. All logarithms are natural. The m=0 case has a null receiver set; r=0 gives zero actual entropy. Joint measurability of p follows by integrating the Borel indicator of the closed cube against pi.

Partition E into E_k where exp(-k-1)<p<=exp(-k), k>=0. Then

`(m exp(-k-1)/lambda)^(1/n) < L(x)`

`                   <=(m exp(-k)/(c lambda))^(1/n)`.

After clipping this interval to [a,b], either E_k is empty or its endpoints alpha_k<=beta_k satisfy n log(beta_k/alpha_k)<=1+ell. The exact positive hard-column envelope has mass 1+n log(beta_k/alpha_k), so Tonelli gives

`integral_Ek F <=m(2+ell)`.

This is valid for singular pi as well as L1 sources. It is an upper bound for the actual selector, not a cap supplied to every frozen scale.

The exact Minkowski-volume identity is

`|Q_t(z)+B1(0,r)|=sum_(j=0)^n binom(n,j)t^(n-j)(2r)^j/j!`.

To prove it, partition by the j coordinates outside the cube, choose their signs, and integrate their nonnegative l1 excesses over a j-simplex of volume r^j/j!. The remaining coordinates occupy intervals of length t. Bound binom(n,j)<=n^j/j! and use

`sum x^j/(j!)^2 <=cosh(2sqrt(x))<=exp(2sqrt(x))`.

The first inequality follows coefficientwise from binom(2j,j)<=4^j. Thus this Minkowski volume is at most t^n exp(2sqrt(2nr/t)). If E_k is nonempty, positive capture implies E_k subset Q_beta_k(z)+B1(0,r), where beta_k>=a. Using F<=lambda gives

`integral_Ek F <=m exp(ell+M-k)`.

Since log(1/p)<=k+1 on E_k,

`integral_E F log(1/p)`

` <=m(2+ell) sum_(k>=0)(k+1)min(1,exp(A-k))`

` <=m(2+ell)(A+3)^2`.

For the last inequality let K=floor A and q=exp(-1)<1/2. The sum through K is (K+1)(K+2)/2. Its tail is exp(A-K-1)[(K+2)/(1-q)+q/(1-q)^2], at most 2(K+2)+2. Their sum is at most (K+3)^2<=(A+3)^2. The theorem's constants follow exactly, including

`(3+ell+M)^2 <=2(3+ell)^2+16nr/a`.

This argument does not require b<=2a, although that restriction holds in the intended octave application. It requires the lower and upper response gates on this exact F. It cannot replace the lower gate by a lower bound for a different total response.

## FA2. Author-proof audit and exact binding

**Final verdict: PASS, no mathematical or scope repair requested.**

Author file actually read in full and SHA verified:

`/tmp/r284_faces.md`

SHA256 `221e2dea296325f7980c996a16e06fb0c2f436fb550d462b3e4d705dbc1c4318`.

The author theorem matches the independently screened statement. Specific potentially delicate points pass as follows:

- The hard input-source posterior is exactly pi conditioned on the selected closed cube, so its KL is log(1/p) for any Borel pi. This is explicitly distinguished from the original auxiliary clock posterior.
- Positive p and the l1 support imply membership in the exact Minkowski sum. The simplex decomposition in (4) has coefficient binom(n,j)(2r)^j/j!, with full cube side U; there is no missing factor two or hidden coordinate-product source hypothesis. The exponential bound is coefficientwise valid.
- The tier interval (6) follows from the two caps on the **same F**. Relaxing its strict lower endpoint is legitimate. Empty or singleton scale windows are handled by (5), with column mass respectively zero or at most m. Clipping to [a,b] cannot increase the logarithmic ratio beyond (1+ell)/n.
- The column estimate (5) remains valid for singular finite source measures by positivity and nonnegative Tonelli. It is an envelope bound and assigns no FIRST cap to separate scales. Endpoint atoms are included by the closed-cube convention and the explicit point-source radial envelope.
- The two independent tier prices (7) and (8) are both upper bounds for the original same selected response. Taking their minimum and then summing all tiers is valid. No infinite repetition of a constant source fee is discarded.
- For the author's K=ceil(B), the tail is exactly bounded by `(K+2)/(e-1)+1/(e-1)^2`. The middle inequality to A(K+2)^2 holds for A>=2; K<=B+1 gives the stated A(B+3)^2. This is consistent with the independent floor-phase proof in FA1.
- The second displayed theorem bound follows from `(x+y)^2<=2x^2+2y^2`; at r=a/(16sqrt(n)) its `16nr/a` term is exactly sqrt(n). Thus the near-radius constant in (3) is correct.
- The degenerate cases m=0, r=0, p=1 and c=1 have the stated harmless interpretations. The lower same-response cap excludes p=0 on E. No density, entropy or coordinate-independence assumption on the source was inserted.

## FA3. Actual embedded diagnostic replay

The one Python block was independently extracted from the exact author file and actually executed without changes. It returned:

```text
AUTHOR_SHA256 221e2dea296325f7980c996a16e06fb0c2f436fb550d462b3e4d705dbc1c4318
PASS 38 bounded scalar diagnostics; not interval certificates
```

The count is 20 support-volume comparisons (five dimensions times four radius values) plus 18 finite tier-series comparisons (three c values times six B0 values). The code uses ordinary binary floating point. Its tier diagnostic sums only the displayed finite range through `int(B)+149`; it is not an independent certificate for an infinite series. The analytic tail calculation, separately checked above, proves the full series estimate. No directed-interval claim or FULL original-input test is made.

Exact replay procedure:

```python
from pathlib import Path
import hashlib
p=Path('/tmp/r284_faces.md')
s=p.read_text()
print('AUTHOR_SHA256',hashlib.sha256(s.encode()).hexdigest())
blocks=[x.split('\n```')[0] for x in s.split('```python\n')[1:]]
assert len(blocks)==1
exec(compile(blocks[0],str(p)+' diagnostic','exec'),{})
```

## FA4. What this audit certifies and does not certify

The result is a genuine source-linear information estimate for one packet on its own two-sided selected-response band. It holds for arbitrary measurable scale selectors and even b/a>2. The same-packet lower cap is essential to its proved tier localization; a lower cap for a larger total source does not supply it.

Applying it separately to every near-anchor restriction rho|B1(z,r) still charges `integral rho(B1(z,r)) nu(dz)` unless a separate mass-conserving packet allocation is proved. Neither that pair mass, the packet-low-response complement, nor a response/entropy-to-original-traffic bridge is paid by the theorem. The author explicitly retains all three gaps and makes no general weak-maximal or score-clock closure claim. This scope is correct.

**Audit frozen at the author hash in FA2. Only this owned audit file was written; no author/repository/Git/PDF state was changed.**
