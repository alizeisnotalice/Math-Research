# R284 — actual source-fraction selection coupled to the physical clock

## Proposition: a paid light allocation of the current original traffic

Retain the actual sources rho,nu, actual q in [3lambda/4,lambda], actual measurable s,L,R, original FIRST and hard cap, and the original full auxiliary posterior and positive score. Let d=a/(8sqrt(n)); the original near event is ||y-z||_1<=d/2. Use the same uniform shifted side-d coarse grid and its exact same-cell probability P_d>=1/2 on near.

For a coarse cell C and actual receiver x put

    F_C(x)=integral_C P_{s(x),L(x)}(x-y)rho(dy),
    G_C(x)=integral_C h_{R(x)}(x-z)nu(dz),
    w_C(x)=F_C(x)/q(x).

These use the FULL actual soft response, without restricting it to latent interiors. Original FIRST gives

    0<=w_C<=1,    sum_C w_C<=1.                               (1)

This is a consequence of the actual summed FIRST, not a new component FIRST.

At physical clock xi=c_j t/b define

    a_xi=max(a,b xi/gamma), gamma=1+1/n,
    A_xi=1+n log(b/a_xi), eta_xi=1/A_xi.                     (2)

Every actual contributing receiver has L(x),R(x)>=a_xi. On near define

    A_light(x,y,z,xi)
      =E_shift sum_C 1_C(y)1_C(z)1{w_C(x)<=eta_xi}/P_d(y-z),
    A_heavy=1-A_light.

Set the allocations to zero off near. They lie in [0,1] and split the original near positive integrand exactly, at each actual clock. Neither changes the full posterior or any source. They are independent of the auxiliary upper/lower slots v,u.

Let P_cur denote the CURRENT original positive middle-clock traffic, after all previously paid allocations, with all its current unspent masks. Its light part, obtained by multiplying its actual integrand by A_light, obeys

    P_cur,light <=4Lambda B_D W_nu
                 <=16Lambda sqrt(nD) W_nu,                   (P1)

where B_D<=min(n log2,4sqrt(nD)), and the original upper-score restriction R2(y,v)<=D is retained until applying that bound. The original outer factor 2Lambda appears exactly once. This is a new admissible positive payment of part of the R283 current remainder; it is not a root bound for P_cur,heavy or for the entire problem. No positive coverage fraction is guaranteed; the light allocation may have zero mass on a particular current instance.

The jointly clock-dependent choice (2) is the parent-proposed strengthening of the initially examined fixed threshold 1/(n+2). Its proof is given below. No hard cap at an expanded scale is used.

## Why the unconditional adaptive-information target had to be narrowed

The unrestricted hard-channel estimate cannot have a uniform polylog bound. For each fixed n choose a smooth centrally symmetric probability density pi_epsilon supported in an arbitrarily small l1 ball about z, and on a<2||x-z||_infinity<b choose L(x)=2||x-z||_infinity. At almost every such x the largest coordinate is unique; as epsilon tends to zero the selected cube captures exactly one half of the source. Thus the contribution of this annulus to integral F KL(pi_x||pi)dx tends to (log2/2)n log(b/a). The selected columns were never normalized to one. This is only a screen of the auxiliary arbitrary-selector claim, not a FULL original-history construction or a statement that original caps permit that entire regime. No further counterexample search is used here.

## Proof of the light payment, with original dx and source masses

Fix xi and one coarse-grid shift. Remove only nonnegative original restrictions for an upper bound. Since w_C<=eta_xi on a light cell,

    sum_C integral_{E_xi} 1_light w_C(x)G_C(x) dx
       <=eta_xi integral_{E_xi}(h_{R(x)}*nu)(x)dx.

The actual R(x)>=a_xi qualification allows the exact common-window envelope

    K_{a_xi,b}(u)=sup_{a_xi<=R<=b}h_R(u),
    ||K_{a_xi,b}||_1=A_xi.

Hence, preserving the original hard source,

    sum_C integral_{E_xi}1_light w_C G_C dx
       <=eta_xi A_xi ||nu||=||nu||.                          (3)

There is no factor counting cells: sum_C G_C=h_R*nu uses the original partition exactly once. The hard source need not be comparable with rho. The original hard cap is preserved but is not needed for (3).

At fixed actual x,y,j and t, the unchanged full pair posterior and the original upper-slot R2 restriction give

    E_{Pi_t x Pi_t}[(k_t(v)-k_t(u))_+1_good(v)1{R2(y,v)<=D}]
       <=f_D(xi):=min(n,D/(1-xi)^2).

The light gate does not depend on v,u, so this probability bound is applied before any source integration. Then change dt/t to dxi/xi in the actual row, retaining the unique j(x) mask until its sum is at most one. The conditional-grid factor satisfies P_d^(-1)<=2. Thus (3), averaged over the original grid shifts, gives

    P_cur,light <= (2Lambda) * 2 * W_nu
                       integral_middle f_D(xi) dxi/xi
                  <=4Lambda B_D W_nu.

This proves P1. The actual current mask can depend on source, clock, or history; it is merely discarded positively for this upper estimate. In particular the original hard source cut 1_{Z_g(y)} may be retained in the actual integrand and discarded in the majorant; the full auxiliary Pi is never restricted or renormalized.

For the original common outer seed/terminal expectation, use its original W_nu=E sum_V||nu_V||. The threshold and all estimates are uniform for frozen outer data. If D varies, retain B_D inside that outer sum until a genuine uniform bound is used. No ancestor source copy, new j menu, or second Lambda factor is introduced.

## Exact heavyweight target and the new joint constraints

On near there is also the exact formula

    A_heavy=E_shift sum_C 1_C(y)1_C(z)
                       1{A_xi F_C(x)>q(x)}/P_d(y-z).          (4)

Therefore the only unpriced part introduced by this split is the SAME original current integrand times (4). Its grid majorant replaces 1/P_d by 2 and otherwise retains the actual near condition, original sources, current unspent masks, actual selectors, full Pi_t pair, original score, and physical middle clock. It is not a different source norm.

Every contributing heavy cell satisfies the genuine actual-response comparability

    q(x)/A_xi < F_C(x) <= q(x),
    3lambda/(4A_xi) < F_C(x) <= lambda.                       (5)

At each receiver and physical clock, the number of heavy cells is strictly less than A_xi, since their w_C sum is at most one. This is a receiver-local count, not a bound on the global number of source cells. It does not allow a repeated hard-source or first-containment depth charge.

Because p_y(x)<=L(x)^(-n), writing m_C=rho(C) additionally gives

    m_C > q(x)L(x)^n/A_xi >= 3lambda a_xi^n/(4A_xi).          (6)

Equations (2), (5), and (6) are simultaneous actual clock/source constraints on the exact remainder. They do not grant lower bounds to individual latent rectangles. Near xi=1 the scale-window factor A_xi is small and the comparable-response threshold is correspondingly large. This is the concrete correlation preserved by the split rather than an independent full-window score payment.

Neither the receiver-local number bound nor (6) pays the heavyweight traffic. A source-paid estimate using (5) with the actual cut geometry remains required.

## The source-fraction entropy term has no H(C) loss

This ancillary estimate addresses the original information motivation without replacing the positive-traffic proof. For any eta in (0,1] define

    M(eta)=sup_{0<=w<=eta}w log(1/w)
          =eta log(1/eta) if eta<=e^(-1), and e^(-1) otherwise.

For every shift and fixed physical clock,

    sum_C integral_{E_xi}1{w_C<=eta_xi}
                         w_C G_C log(1/w_C)dx
       <=M(eta_xi)A_xi W_nu
       <=max(1,log A_xi)W_nu.                               (7)

The zero-weight convention is 0 log(1/0)=0. This follows pointwise by bounding each coefficient by M(eta_xi), then summing the ORIGINAL G_C. It does not sum the entropy of the source-cell prior. Including the coarse near normalization and original outside coefficient, an inserted nonnegative fraction-log factor on the light branch has source price at most

    4Lambda W_nu integral_middle f_D(xi)max(1,log A_xi) dxi/xi
       <=4Lambda B_D max(1,log[1+n log(b/a)])W_nu.             (8)

Thus even this extra light-fraction logarithm has a root-polylog price. Formula P1 is stronger for the raw traffic and needs no information functional at all.

For comparison with conditional channel information, let pi_C=rho|C/m_C and pi_{C,x}=p_y(x)rho|C/F_C(x), when these are defined. These are source-diagnostic posteriors, never replacements for the original auxiliary Pi_t. Set

    c_C(x)=m_C/[q(x)L(x)^n],  w_C=F_C/q.

The hard kernel gives the exact receiver-level identity

    KL(pi_{C,x}||pi_C)=log(c_C/w_C).

For the actual soft kernel, the bound p_y<=L^(-n) instead gives

    KL(pi_{C,x}||pi_C)<=log(c_C/w_C)
                       <=log_+c_C+log(1/w_C).                (9)

Here c_C>=w_C wherever F_C>0. The fraction-log part of (9) is paid on the light branch by (7). The amplitude term log_+c_C is not paid by this calculation and remains explicit. Also, (9) is a receiver-level KL statement for the full restricted source law. Arbitrary source-dependent near/history masks cannot be inserted into its signed log-density integrand and then claimed to preserve the same KL inequality. The raw proof of P1 avoids that issue entirely.

## What has changed and what has not

The initial arbitrary-selector information problem permits order-n adaptive face information, so a fixed-channel small-information lemma alone could not be transferred as requested. Under the ORIGINAL actual FIRST, however, the source-cell fractions w_C form a subprobability vector. Pairing that actual vector with the common physical clock envelope produces the exact eta_xi A_xi cancellation in (3), and pays all light traffic at the desired root order, including full-soft input and current latent-face failures.

This split is additive to the current R283 accounting only on the current unspent integrand. No earlier top/interior/single-cut/latent allocation is paid again. The resulting heavyweight target is precisely (4)-(6). General closure and a source-linear payment of that target remain unproved here.

## Actual local diagnostic

The following exact structure was checked with Python floating arithmetic, seeded by 284. For n in {1,2,16,256,65536}, b/a in {1,1.5,2}, and 51 physical clocks in [a/b,1], the script formed A_xi and eta_xi and 31 nonnegative weights whose sum is at most one, together with nonnegative G_C values. It checked the light raw inequality, heavy-cell count, fraction-log inequality, A_xi M(1/A_xi)<=max(1,log A_xi), and eta_xi A_xi=1. Actual output: fraction_clock_checks=3825, status=PASS. These finite diagnostics verify the elementary assembly algebra, not a FULL original-history model or an interval certificate. The analytic proof is (1)-(8).
