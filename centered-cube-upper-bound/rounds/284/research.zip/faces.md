# R284: a cap-restricted adaptive information bound

This is a source-linear bound for one arbitrary source packet supported in an l1 ball. It uses a lower and an upper cap on **that same packet's selected response**. It does not give a free lower cap to a restricted source, nor does it pay repeated packets indexed by another source. The unrestricted selector question was screened and set aside; no further counterexample investigation is used below.

## 1. Exact functional and theorem

Let n>=1, 0<a<=b, r>=0, and let pi be an arbitrary Borel probability supported in
\(B_1(z,r)=\{y:\|y-z\|_1\le r\}\). No density or product assumption is imposed on pi. Let m>0 and write mu=m pi. For a measurable selector L(x) in [a,b], set
\[
p(x)=\pi(Q_{L(x)}(x)),\qquad
F(x)=mL(x)^{-n}p(x).
\]
Here Q_L is the centered cube of full side length L. On p(x)>0 the input-source posterior is pi conditioned on Q_L(x), and hence
\[
\operatorname{KL}(\pi_x\|\pi)=\log(1/p(x)).
\]
This is not the original auxiliary clock posterior.

Fix lambda>0 and 0<c<=1, and let E be any measurable set on which
\[
c\lambda\le F(x)\le\lambda.                                      \tag{1}
\]
Define
\[
\mathcal I_E=\int_E F(x)\log(1/p(x))\,dx,\quad
v=2\sqrt{2nr/a},\quad \ell=\log(1/c),\quad A=2+\ell.
\]
Then, uniformly over pi, L, E, m, lambda, and b,
\[
\boxed{\mathcal I_E\le mA(3+\ell+v)^2
\le m(2+\ell)\{2(3+\ell)^2+16nr/a\}.}                         \tag{2}
\]
In particular, at the original near radius r=a/(16 sqrt(n)),
\[
\mathcal I_E\le m(2+\ell)\{2(3+\ell)^2+\sqrt n\}.              \tag{3}
\]
Thus fixed c gives a root-order adaptive information price, with no number of selector nodes or source atoms. The theorem even allows b/a>2. Its gain comes from the response cap, not from replacing actual selection by a normalized fixed channel. For m=0 the response and information are zero. If r=0, pi is a point mass and the information is identically zero; (2) remains a valid nonsharp bound.

## 2. Exact support volume

For U>0 the Minkowski sum of Q_U(z) with B_1(0,r) has volume
\[
|Q_U+B_1(r)|
=U^n\sum_{j=0}^n {n\choose j}\frac{(2r/U)^j}{j!}
\le U^n\exp\bigl(2\sqrt{2nr/U}\bigr).                         \tag{4}
\]
For the identity, specify the j coordinates lying outside the original cube, choose their signs, and integrate the nonnegative excess distances over the simplex of total excess at most r. The other n-j coordinates range freely over intervals of length U. Boundaries have zero Lebesgue volume. For the inequality, use binom(n,j)<=n^j/j! and
\[
\sum_{j\ge0}\frac{x^j}{(j!)^2}
\le\left(\sum_{j\ge0}\frac{x^{j/2}}{j!}\right)^2=e^{2\sqrt x}.
\]
This retains the common l1 displacement constraint. Replacing this sum by the volume of Q_(U+2r) would introduce an unnecessarily large exponential in nr/U.

## 3. A short scale window costs source mass only once

For 0<l<=u and any finite positive measure mu of mass m,
\[
\int_{\mathbb R^n}\sup_{l\le R\le u}(h_R*\mu)(x)\,dx
\le m[1+n\log(u/l)].                                         \tag{5}
\]
Indeed, positivity and Tonelli reduce to one source point y. If q=2||x-y||_infinity, its kernel envelope equals l^-n for q<=l, q^-n for l<q<=u, and zero otherwise. The distribution of q under Lebesgue measure has volume q^n, giving 1+n log(u/l) exactly. No selected-response cap or source density is needed in (5).

## 4. Combine information tiers, the common response cap, and l1 support

Partition E measurably into
\[
E_k=E\cap\{e^{-k-1}<p(x)\le e^{-k}\},\qquad k=0,1,\ldots.
\]
The set p=0 contributes nothing and is absent under (1). At endpoints choose the displayed half-open convention; p=1 belongs to k=0.
On E_k, (1) forces
\[
\max\{a,(me^{-k-1}/\lambda)^{1/n}\}\le L(x)
\le \min\{b,(me^{-k}/(c\lambda))^{1/n}\},                       \tag{6}
\]
where the scalar strict lower endpoint from p has been relaxed to a closed one, and the original endpoint L=a remains allowed. Let l_k and u_k denote these bounds. If l_k>u_k, the tier is empty; otherwise
\[
n\log(u_k/l_k)\le1+\ell.
\]
Consequently (5), applied to the **original same mu**, yields
\[
\int_{E_k}F\le mA.                                           \tag{7}
\]
This is one bounded scale-window estimate per information tier, not a normalization or subdivision of the source measure.

Whenever p(x)>0 and L(x)<=u_k, the support assumption gives
\(x\in Q_{u_k}(z)+B_1(r)\). Use F<=lambda, (4), u_k>=a, and
\(u_k^n\le me^{-k}/(c\lambda)\) to obtain the independent bound
\[
\int_{E_k}F\le\frac m c e^{-k+v}.                             \tag{8}
\]
Thus the common cap and the support geometry together provide a summable tier estimate:
\[
\mathcal I_E
\le m\sum_{k\ge0}(k+1)\min\{A,e^{B-k}\},\qquad B=v+\ell.     \tag{9}
\]
No infinite collection of constant source fees is discarded: the whole series is explicitly summed.

For completeness, put K=ceil(B)>=0. For k<=K use A; for k=K+j, j>=1, use e^-j. Hence the series in (9) is at most
\[
\frac A2(K+1)(K+2)
+\frac{K+2}{e-1}+\frac1{(e-1)^2}
\le A(K+2)^2\le A(B+3)^2.
\]
The middle inequality follows from A>=2 and e-1>1. Finally (x+y)^2<=2x^2+2y^2 gives the second bound in (2). This proves the theorem, including arbitrary measurable adaptive selectors, with no source-product hypothesis.

## 5. Exact relation to the original geometric task

The hypothesis is checkable on a packet mu: restrict receivers to
\(E\cap\{c\lambda\le h_{L(x)}*\mu\le\lambda\}\). On that set (2) applies with its unchanged selected source posterior. An upper cap for a larger source does pass to mu, but a lower cap for the larger source does **not** imply (1) for mu. The source packet must itself meet the lower cap, or its lower-response complement remains to be charged.

For near-hard conditioning mu_z=rho restricted to B_1(z,r), the theorem holds separately where its own selected response meets (1). Integrating this conclusion against the original hard source nu gives a bound proportional to
\[
\int \rho(B_1(z,r))\,\nu(dz),
\]
unless an additional mass-conserving packet allocation is proved. This pair mass is not silently replaced by W_rho+W_nu. Nor does the theorem bound the original traffic merely because it bounds an information integral: the response/entropy-to-weak-price bridge must still preserve the actual caps, selectors, source weights, and clock posteriors.

The concrete improvement over the unrestricted adaptive calculation is that the cap restricts each information tier to logarithmic scale width (1+log(1/c))/n. The exact l1 support volume then makes the tier sum finite at the root-order price (3). What remains is how to apply this packet theorem with one source charge while covering the original packet-low-response region. This statement makes no new FIRST claim for arbitrary parameter nodes, does not compare nu with rho, and consumes no signed credit.

## 6. Bounded local diagnostics

The following standard-library Python block was actually run. It checked 20 support-volume inequalities and 18 tier-series bounds: PASS 38. These are floating-point diagnostics only; the proofs above do not rely on them. There is no original FULL input or traffic verification in this code.

```python
import math
checks=0
for n in (1,2,8,64,512):
    for rr in (1e-6,1/(16*math.sqrt(n)),.125,1.0):
        terms=[1.0]
        for j in range(n):
            terms.append(terms[-1]*(n-j)*2*rr/(j+1)**2)
        logvol=math.log(math.fsum(terms))
        assert logvol <= 2*math.sqrt(2*n*rr)+1e-12
        checks+=1
for c in (1.0,.5,.01):
    for B0 in (0.,.1,1.,4.,12.,40.):
        A=2+math.log(1/c); B=B0+math.log(1/c)
        val=math.fsum((k+1)*min(A,math.exp(B-k))
                     for k in range(int(B)+150))
        assert val<=A*(B+3)**2
        checks+=1
print('PASS',checks,'bounded scalar diagnostics; not interval certificates')
```
