# R284 radial cap mechanism: finite atomic model

Completed six dimensions and18 capped cases at both mp40 and mp60, plus six uncapped comparisons. Stages: initial n2,8,32 (nine capped rows); stress128,512 (six); expanded2048 (three). Each dimension uses c=.75,.1,.001. Independent transformed quadrature, log-L quadrature and a finite-binomial primitive agree in all rows. Across312 numerical fields the maximum scaled40/60 difference is2.24791875921325e-39, at the n2048,c.75 transformed endpoint. This is ordinary multiprecision, not an outward interval certificate or general source theorem.

## Geometry and the exact cap interval

Take a=lambda=1,b=2. There are two atoms, each of mass m/2, at plus/minus epsilon times the all-ones vector; r=1/(16sqrt n),epsilon=r/n. The radial selector is L(x)=2max_i|x_i|,1<=L<=2. On a unique face, use the directly specified safe region |x_other|<L/2-epsilon. Exactly the atom whose sign matches that face is included, and F=m/(2L^n).

Here a 'gap>2epsilon' is interpreted in full-side coordinates L-2max_other|x|>2epsilon. If gap instead means max|x|-secondmax|x|, this region requires gap>epsilon; gap>2epsilon would be a stricter region with a different factor. The script and all values use the explicit coordinate safe region, avoiding a hidden factor2 convention.

On each max-face shell the (n-1) transverse directions have sideL-2epsilon. Summing faces and using L=2max gives the safe receiver volume element n(L-2epsilon)^(n-1)dL. Hence the exact safe-region response integral is

(mn/2) int (1-2epsilon/L)^(n-1)dL/L.

No claim is made that this is the whole receiver response outside this safe region. The model is singular atomic, not L1/FULL, and the selector construction is not asserted to satisfy original historical/FIRST/high conditions.

Set logm=log2+nlog1.2, so m=2lambda(1.2a)^n. This is stored in log form; all reported integrals are divided by m. The cap c lambda<=F<=lambda restricts the exact scale interval to

[Llo,Lhi]=[1.2,min(2,1.2c^(-1/n))].

Endpoint response ratios and actual clipping by b are saved. In particular several low-dimensional small-c rows hit b; they are not treated as an untruncated interval. Empty-interval logic exists but none of this prescribed menu is empty. With x=nlog(L/1.2), the capped normalized integral becomes .5int_0^xhi (1-2epsilon/(1.2exp(x/n)))^(n-1)dx. This change resolves the thin large-n cap interval without naive sampling.

## Independent primitive and safe bound

For q=2epsilon, the finite binomial identity gives

int_Llo^Lhi (1-q/L)^(n-1)dL/L
 =log(Lhi/Llo)
 +sum_(k=1)^(n-1) binom(n-1,k)(-q)^k (Llo^(-k)-Lhi^(-k))/k.

The script evaluates coefficients by recurrence and endpoint differences with expm1 for stability, independently of both quadratures. No infinite series is truncated. The factor is between0 and1, so

safe_integral/m <=(n/2)log(Lhi/Llo) <=.5log(1/c).

The uncapped comparator is the same safe integral over the whole octave[1,2], with upper nlog2/2. These are elementary bounds for this specified mechanism, not conclusions fitted from dimensions.

## Actual values

|n|uncapped safe integral/m|c.75 capped/m|c.1 capped/m|c.001 capped/m|
|---:|---:|---:|---:|---:|
|2|.671050093648|.138906955732|.496094232491|.496094232491|
|8|2.69620336825|.139349427990|1.11944092771|1.99230873124|
|32|10.9204259608|.141308414591|1.13164059498|3.39889071196|
|128|44.0120549979|.142534420233|1.14091597870|3.42329722033|
|512|176.741406711|.143181846491|1.14602678619|3.43815097655|
|2048|708.370651518|.143510510875|1.14864834653|3.44595393972|

The c-specific normalized bounds are respectively.143841036226,1.15129254650,3.45387763949. All actual clipped intervals and margins passed. Mass normalization matters: choosing m exponentially with n does not itself demonstrate a large source-normalized payoff. No general order, global source cap or FULL counterexample/closure is inferred from this table.

## Replay

Python3.12.14, mpmath1.3.0 and standard library only:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r284_numeric.py --output r284_numeric.json
```

The deterministic JSON binds the source SHA and contains no timestamp/runtime/output path. Ninety-digit strings retain the actual40/60 working errors, not90-digit accuracy. The complete final menu was actually run after clarifying the face-gap convention. No old experiment, repository file, Git or PDF was used. Finite numerical consistency is separated from the elementary interval derivation above; neither certifies the full original source problem.
