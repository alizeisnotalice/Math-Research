from fractions import Fraction as F
cases=[([F(1,8),F(1,4),F(1,2)],[F(7),F(2),F(3)]),
       ([F(0),F(1)],[F(11),F(5)]),
       ([F(1,100)]*50,[F(i+1) for i in range(50)])]
n=0
for w,g in cases:
 assert sum(w)<=1
 for A in [F(1),F(4,3),F(4),F(10)]:
  lhs=sum(ww*gg for ww,gg in zip(w,g) if ww<=1/A)
  assert lhs<=sum(g)/A
  assert sum(1 for ww in w if ww>1/A)<A or sum(1 for ww in w if ww>1/A)==0
  n+=1
print('PASS',n,'exact LIGHT-cap and heavy-count diagnostics')
