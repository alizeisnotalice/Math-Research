"""R719: real single-site retirement, exact incidence trees, and corner kernel.

Only audit.json is generated. Remote branch uses standard Python exact
fractions, integer binomials, and Decimal110; no remote files are created.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from math import comb
import hashlib,json,platform,socket,subprocess,sys

NS=[4,16,64,256,1024,4096,16384,65536,1<<20,1<<32,1<<48,1<<64]


def kernel_exact():
    beta_checks=0
    for n in range(1,13):
        for k in range(1,n+1):
            integral=sum((F((-1)**j*comb(k,j)*n,n+j) for j in range(k+1)),F(0))
            assert integral==F(1,comb(n+k,k));beta_checks+=1
    recurrence=[]
    for n in [4,16,64,256]:
        term=total=F(1)
        for k in range(1,n+1):
            term*=F(n-k+1,n+k);total+=term
        central=comb(2*n,n);closed=F((1<<(2*n))+central,2*central)
        assert total==closed
        recurrence.append({'n':n,'S_exact':str(closed)})
    corners=[]
    for n in [4,6,8]:
        a=F(3,5);h=1+F(1,32*n);kappa=h**n
        prefactor=2*kappa*(h/(2*a))**n
        vertices=list(product([-1,1],repeat=n))
        values={k:prefactor/comb(n+k,k) for k in range(1,n+1)}
        expected=prefactor*(F((1<<(2*n))+comb(2*n,n),2*comb(2*n,n))-1)
        for v in vertices:
            row=sum((values[sum(x!=y for x,y in zip(v,w))] for w in vertices if w!=v),F(0))
            assert row==expected
        corners.append({'n':n,'corner_count':len(vertices),'a_exact':str(a),
                        'off_diagonal_kernel_row_sum_exact':str(expected),
                        'all_rows_equal':True})
    return {'exact_beta_integral_checks':beta_checks,'recurrence_vs_closed_form':recurrence,
            'finite_corner_matrices':corners}


def graph_components(demands,sources,active,live=None):
    live=set(demands) if live is None else set(live)
    unseen=set(live);result=[]
    while unseen:
        first=min(unseen);sites={first};src=set();todo=[first];unseen.remove(first)
        while todo:
            w=todo.pop()
            for name in active:
                if w not in sources[name]['sites'] or name in src:continue
                src.add(name)
                for v in sources[name]['sites']:
                    if v in live and v not in sites:
                        sites.add(v);unseen.discard(v);todo.append(v)
        result.append((sites,src))
    return result


def tree_tests():
    models=[];factor=F(4);kappa=(1+F(1,512))**16
    def make_private(demands,sources):
        for w,v in demands.items():sources['private_'+w]={'sites':{w},'d':v*F(63,256),'theta':F(1,2)}
    demands={f'w{i}':v for i,v in enumerate([F(1,2),F(1),F(3,2),F(1,2),F(1),F(1,2)])}
    sources={f'edge{i}':{'sites':{f'w{i}',f'w{i+1}'},'d':d,'theta':F(1,4)} for i,d in enumerate([F(3),F(4,5),F(2),F(1,2),F(3,5)])}
    make_private(demands,sources);models.append(('path',demands,sources))
    demands={f'w{i}':F(1) for i in range(8)}
    sources={'shared':{'sites':{'w0','w2','w4','w6'},'d':F(5),'theta':F(1,8)}}
    for j in range(4):sources[f'pair{j}']={'sites':{f'w{2*j}',f'w{2*j+1}'},'d':F(1),'theta':F(1,16)}
    make_private(demands,sources);models.append(('repeated_source_branching_tree',demands,sources))
    demands={f'w{i}':F(1) for i in range(7)}
    sources={'hub':{'sites':set(demands),'d':F(2),'theta':F(1,2)}}
    models.append(('shared_star_incidence_payment',demands,sources))
    rows=[]
    for name,demands,sources in models:
        active=set(sources);initial=graph_components(demands,sources,active)
        edges=sum(len(s['sites']) for s in sources.values())
        assert len(initial)==1 and edges==len(demands)+len(sources)-1
        for w,v in demands.items():
            neighbors=[s for s in sources.values() if w in s['sites']]
            assert sum((s['theta'] for s in neighbors),F(0))>=F(1,2)
            assert v<=4*kappa*min(s['d'] for s in neighbors)
        rounds=[];retired=set();live=set(demands);removed_sites=set();source_ledger={}
        accumulated={w:F(0) for w in demands};site_ledger={w:F(0) for w in demands}
        while True:
            components=graph_components(demands,sources,active,live);remove=set();record=[]
            for sites,src in components:
                demand=sum((demands[w] for w in sites),F(0));threshold=demand/factor
                large={i for i in src if sources[i]['d']>=threshold}
                remove|=large
                record.append({'sites':sorted(sites),'sources':sorted(src),'demand_exact':str(demand),
                               'retirement_threshold_exact':str(threshold),'retired_now':sorted(large)})
            if not remove:
                rounds.append({'components_before':record,'new_source_ledger':{},'removed_sites':[]});break
            assert not(retired&remove);retired|=remove;active-=remove
            payments={}
            for i in sorted(remove):
                neighbors=sources[i]['sites']&live
                payment=sources[i]['theta']*sum((demands[w] for w in neighbors),F(0))
                cap=factor*sources[i]['d']*sources[i]['theta']
                assert payment<=cap and i not in source_ledger
                source_ledger[i]=payment
                payments[i]={'currently_connected_sites':sorted(neighbors),'paid_incidence_exact':str(payment),
                             'single_source_capacity_exact':str(cap)}
                for w in neighbors:
                    accumulated[w]+=sources[i]['theta'];site_ledger[w]+=sources[i]['theta']*demands[w]
            deleted={w for w in live if accumulated[w]>=F(1,4)}
            for w in deleted:assert demands[w]<=4*site_ledger[w]
            live-=deleted;removed_sites|=deleted
            unused={i for i in active if not(sources[i]['sites']&live)}
            active-=unused
            rounds.append({'components_before':record,'new_source_ledger':payments,
                           'removed_sites':sorted(deleted),'unused_sources_dropped_without_charge':sorted(unused)})
            if not live:break
        components=graph_components(demands,sources,active,live)
        seen=set()
        for sites,src in components:
            assert not(seen&src);seen|=src
            threshold=sum((demands[w] for w in sites),F(0))/factor
            assert all(sources[i]['d']<threshold for i in src)
        for w in live:
            assert accumulated[w]<F(1,4)
            assert sum((sources[i]['theta'] for i in active if w in sources[i]['sites']),F(0))>=F(1,4)
        paid=sum(source_ledger.values(),F(0))
        removed_volume=sum((demands[w] for w in removed_sites),F(0))
        assert removed_volume<=4*paid
        distinct_capacity=sum((factor*s['d']*s['theta'] for s in sources.values()),F(0))
        wrongly_duplicated=sum((factor*s['d']*s['theta']*len(s['sites']) for s in sources.values()),F(0))
        rows.append({'name':name,'abstract_dimension':16,'C_s_exact':'1','sqrt_n_exact':'4',
                     'site_demands_exact':{w:str(v) for w,v in demands.items()},
                     'sources':{i:{'sites':sorted(s['sites']),'d':str(s['d']),'theta':str(s['theta'])} for i,s in sorted(sources.items())},
                     'actual_incidence_is_tree':True,'pool_half_mass_and_site_volume_bound_pass':True,
                     'distinct_source_total_capacity_exact':str(distinct_capacity),
                     'incorrect_per_incidence_duplicated_capacity_exact':str(wrongly_duplicated),
                     'actual_incidence_retirement_rounds':rounds,
                     'single_source_paid_incidence_ledger':{i:str(v) for i,v in sorted(source_ledger.items())},
                     'total_paid_incidence_exact':str(paid),'retired_source_ids_unique':True,
                     'removed_site_volume_exact':str(removed_volume),'four_times_paid_incidence_exact':str(4*paid),
                     'removed_volume_bound_pass':True,'surviving_sites':sorted(live),
                     'surviving_volume_exact':str(sum((demands[w] for w in live),F(0))),
                     'surviving_sources':sorted(active),'survival_tests_pass':True,
                     'surviving_sites_have_remaining_pool_theta_at_least_quarter':True})
    return rows


def remote_numbers():
    from decimal import Decimal as D,localcontext
    with localcontext() as c:
        c.prec=110
        ga=D(1);gb=1/D(2).sqrt();gt=D(1)/4;gp=D(1)
        for _ in range(9):
            an=(ga+gb)/2;gb=(ga*gb).sqrt();gt-=gp*(ga-an)**2;ga=an;gp*=2
        pi=(ga+gb)**2/(4*gt)
        out=[]
        for n in NS:
            if n<=65536:
                central=comb(2*n,n);S=(1+D(1<<(2*n))/D(central))/2
            else:
                x=D(n)
                # Independent Stirling expansion, omitted terms O(n^-9).
                correction=1/(8*x)-1/(192*x**3)+1/(640*x**5)-D(17)/(14336*x**7)
                ratio=(D('.5')*(pi*x).ln()+correction).exp();S=(1+ratio)/2
            out.append({'n':str(n),'ratio':str(S/D(n).sqrt())})
        real=[]
        for b in [32,48,64]:
            n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
            g=(1-D(2)/a).ln();lh=(1+D(1)/a).ln();Q=(D(n-1)*g).exp();W=(1-Q)/8+Q/a
            JA=int(D(root)/W);eA=D(root)-JA*W;lp=D(n)*g-W/t
            for K in [4,8,16]:
                JB=int(D(K*root)/W);lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(JA)*g
                logVR=-D((3*b//4+4)*n)*l2
                f=(1-(-W/t).exp())/(1-lp.exp())
                logDA=D(n)*l2+D(n)*lRA+f.ln()
                volume_margin=D(n)*(l2+lAmin)-logVR+D('.5')*D(n).ln()
                capacity_margin=D('.5')*D(n).ln()+logDA-logVR
                real.append({'b':b,'K':K,'values':[str(volume_margin),str(capacity_margin)]})
        return {'S_rows':out,'real_rows':real}


if '--remote' in sys.argv:
    print(json.dumps({'host':socket.gethostname(),'python':sys.version,'kernel_exact':kernel_exact(),
                      'tree_tests':tree_tests(),'numbers':remote_numbers()}))
    raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def sum_certificate(n,bits):
    ctx.prec=bits;A=arb
    logratio=2*n*A(2).log()+2*A(n+1).lgamma()-A(2*n+1).lgamma()
    ratio=(1+logratio.exp())/(2*A(n).sqrt())
    limit=A.pi().sqrt()/2
    assert ratio>limit
    if n<=65536:
        central=comb(2*n,n);exact=(1+A(1<<(2*n))/central)/(2*A(n).sqrt())
        assert ratio.overlaps(exact)
    return {'n':str(n),'range':'pilot_exact' if n<=256 else 'stress_exact' if n<=65536 else 'expanded_Arb',
            'S_over_sqrt_n':st(ratio),'sqrt_pi_over_2':st(limit),'difference':st(ratio-limit),
            'difference_times_sqrt_n':st((ratio-limit)*A(n).sqrt()),'precision_bits':bits,'_value':ratio}


def real_retirement(b,K,bits):
    ctx.prec=bits;A=arb;n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();L=b*l2;t=A(root)/l2
    g=(-A(2)/a).log1p();lh=(A(1)/a).log1p();beta=(-n*A(a).log()).exp()
    Q=((n-1)*g).exp();W=-((n-1)*g).expm1()/8+Q/a
    JA=floor_unique(A(root)/W);eA=root-JA*W;JB=floor_unique(A(K*root)/W);eB=K*root-JB*W
    lRB=lh-JB*g;lAmin=lRB+l2/n+lh;lRA=lAmin-JA*g;lp=n*g-W/t
    assert lRA<l2 and n*(lAmin-lRB)-l2>0
    def fD(J,e):return (-(-W/t).expm1())*(-(J*lp).expm1())/(-lp.expm1())+(J*lp).exp()*(-(-e/t).expm1())
    logDA=n*l2+n*lRA+fD(JA,eA).log()
    receiver_clock=(-A((3*b//4+5)*n)*l2).exp()
    scaled=fD(JA,eA)+(n*(lRB-lRA)).exp()*fD(JB,eB)+(-K*l2-n*lRA).exp()*(-(-receiver_clock/t).expm1())
    logD=n*l2+n*lRA+scaled.log()
    logVR=-A((3*b//4+4)*n)*l2
    s=(1+A(1)/a)*(l2/n).exp();tau=2*s/n;f,rem=divmod((b//4)*n,b+3)
    partial=(1<<rem)*A(2)/a
    logcap=2*L+f*(2*tau).log()+min(A(0),(tau/partial).log())
    assert logcap<0
    remaining_fraction=-logcap.expm1()
    logdmin=n*(l2+lAmin)
    volume_margin=logdmin-logVR+L/2
    capacity_margin=L/2+logDA-logVR
    assert volume_margin>l2 and capacity_margin>0
    return {'b':b,'n':f'2^{b}','K':K,'C_s_exact':'1','aggregate_A_demand_upper':st(logVR.exp()),
            'remaining_A_fraction_after_density_cap_lower':st(remaining_fraction),
            'block_alone_capped_A_demand':st(logVR.exp()*remaining_fraction),
            'retired_A_pool_theta_sum_exact':'1/2',
            'actual_single_A_incidence_ledger':st(logVR.exp()*remaining_fraction/2),
            'four_times_actual_incidence_ledger':st(2*logVR.exp()*remaining_fraction),
            'site_removed_after_cumulative_retired_theta_reaches_quarter':True,
            'log10_density_cap_paid_fraction':st(logcap/A(10).log()),
            'single_A_min_source_volume':st(logdmin.exp()),
            'log10_min_source_over_full_demand_retirement_threshold':st(volume_margin/A(10).log()),
            'A_original_pool_weight_exact':'1/2','A_source_budget_DA':st(logDA.exp()),'full_D':st(logD.exp()),
            'log10_A_capacity_sqrt_n_DA_over_full_demand':st(capacity_margin/A(10).log()),
            'all_original_A_sources_retired_at_root':True,
            'explicit_single_budget_allocation':'source i pays2*theta_i*VR; sum_i2theta_i=1; each payment<=sqrt(n)*d_i*theta_i',
            'allocation_capacity_log_slack_min':st(volume_margin-l2),
            'retirement_residual_for_this_block_exact':'0 after the explicit payment',
            'active_component':'one positive-demand site A adjacent to all original A sources; no copies per receiver',
            'precision_bits':bits,'_values':(volume_margin,capacity_margin),
            '_remote_values':[float(volume_margin),float(capacity_margin)]}


def main():
    exact=kernel_exact();trees=tree_tests();srows=[];real=[]
    for n in NS:
        lo=sum_certificate(n,256);hi=sum_certificate(n,384)
        assert lo['_value'].overlaps(hi['_value']);del hi['_value'];srows.append(hi)
    for b in [32,48,64]:
        for K in [4,8,16]:
            lo=real_retirement(b,K,256);hi=real_retirement(b,K,384)
            for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
            del hi['_values'];real.append(hi)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=50)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        assert exact==remote['result']['kernel_exact'] and trees==remote['result']['tree_tests']
        for local,other in zip(srows,remote['result']['numbers']['S_rows']):
            assert local['n']==other['n'] and abs(float(arb(local['S_over_sqrt_n']))-float(other['ratio']))<1e-12
        for local,other in zip(real,remote['result']['numbers']['real_rows']):
            assert local['b']==other['b'] and local['K']==other['K']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in real:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'corner_kernel':exact,'S_rows':srows,'real_single_A_rows':real,'abstract_tree_tests':trees,'remote':remote,
            'corner_proof':['For k>=1, the normalized pair factor is n*integral_0^1 t^(n-1)(1-t)^k dt=1/binom(n+k,k). Multiplication by2*kappa*(h/(2a))^n gives the requested untruncated corner kernel.',
                            'binom(n,k)/binom(n+k,k)=binom(2n,n-k)/binom(2n,n). Summing k0..n gives S_n=(1+4^n/binom(2n,n))/2 exactly.',
                            'Stirling implies S_n/sqrt(n)=sqrt(pi)/2+1/(2sqrt(n))+sqrt(pi)/(16n)+O(n^-2). The exact k=0 term is included in S, whereas the checked pair matrices exclude diagonal pairs.',
                            'Thus the corner row sum grows on the root scale, with coefficient sqrt(pi)/2; the finite corner model is pure geometry, not a greedy history.'],
            'tree_scope':['Tree fixtures are abstract weighted source-site incidence trees, not actual cube histories. They satisfy pool mass>=1/2 and the necessary single-site volume bound h_w<=4*kappa*min d_i at dimension16.',
                          'In each actual connected component U, retire sources with d_i>=V_U/(C_s sqrt(n)). Charge source i ONCE by theta_i times the demand of all currently connected live sites; each exact charge is bounded by its single capacity C_s sqrt(n)d_i theta_i.',
                          'A site is removed only when its cumulative retired source theta reaches1/4. Its removed volume is at most4 times its own previously charged incidence. Summing this inequality does not repeat source charges.',
                          'After source and site removals, recompute the actual bipartite connected components. A repeated source is a single vertex and cannot be copied into different branches.',
                          'At termination every remaining source strictly satisfies d_i<V_U/(C_s sqrt(n)); every remaining site has retired theta<1/4 and remaining pool theta>=1/4. Small sources are not paid directly. The branching fixture deliberately retains such survivors.'],
            'real_scope':['Real rows are the exact R717 truncated two-center family with R718 A-first ranking and m=n. Its leftover A demand is between VR*(1-cap_fraction) andVR, so the whole VR is conservatively reserved at the root.',
                          'All original A-source volumes exceed the retirement threshold by enormous certified factors. The explicit2theta_i*VR allocation pays the full root demand within each single true source capacity.',
                          'After this payment the A block has no remaining site demand. Other actual bad labels and other possible site components are not declared paid; their budget is still included in fullD.',
                          'All local Arb results use384 bits, crosschecked against256 bits; remote exact tree/kernel calculations agree, and Decimal110 checks the real aggregate margins and wide-n Stirling values.',
                          'Only audit.py and audit.json are created locally; no Git, remote files or remaining processes.']}
    output=BASE/'audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'S_rows':[{k:r[k] for k in ['n','range','S_over_sqrt_n','difference_times_sqrt_n']} for r in srows],
                      'tree_ledgers':[{ 'name':r['name'],'paid_incidence':r['total_paid_incidence_exact'],
                                        'removed_volume':r['removed_site_volume_exact'],'surviving_volume':r['surviving_volume_exact']} for r in trees]},indent=2))


if __name__=='__main__':main()
