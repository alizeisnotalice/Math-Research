# R363 independent audit — preliminary proof review

Status: FINAL PASS for the stated matched-hard proposition, the stronger multiplicative localization, the final integration and its stated evidence scope. This is not a general root bound or a fresh audit of historical reductions. Only this audit file is owned by the reviewer. All bindings below refer to the bytes read for this final review.

## Frozen contract and independent check
Full f>=0 is integrable and is BOTH sources, alpha=1, s=0, L=R, actual real receiver du, m_u=f(Q_u)=q_u R_u^n, q_->0, a<=R_u<=b<=2a. All physical prefixes E_r, original full J_r and high-J gate H>0 remain frozen. General soft or unequal-source slots are outside this identity.

For fixed y,z let s(u)=max(a,2||u-y||inf,2||u-z||inf). The actual integrand is bounded by 1_{s<=r}/(q_- s^n); extending only the positive receiver-center integral is legal. Its sublevel volume at t>=a is V_t=product(t-|y_i-z_i|)_+. Thus integration by parts gives G=V_r/r^n+n integral_a^r V_t/t^(n+1), including the base a block. It also covers r=a and every actual receiver radius atom. V_t/t^n<=exp(-||y-z||1/t)<=exp(-||y-z||1/r), hence A<=A_n(r)e^(-distance/r)/q_-. No source boundary-density bound is used.

A<=J pointwise. For delta in (0,1), on the ORIGINAL J>=H row, distance>=r log_+(A_n(r)/(delta q_-H)) implies p=A/J<=delta. If the logarithm is zero then J<=A_n(r)/q_-<=delta H<H, so the high row is empty. Equality in distance or threshold causes no error. J=0 rows have A=0 and are defined as zero; H>0 excludes them from the original loss.

With Near/Far a measurable complementary partition at each same physical r, define Bnear as the ORIGINAL positive variance loss A(1-p) restricted Near, Ffar as the positive first moment A restricted Far and Qfar as A p restricted Far, retaining f(y)f(z), high-row gate and ell throughout. Then exactly B_H=Bnear+Ffar-Qfar, 0<=Qfar<=delta Ffar. LOCAL=Bnear+Ffar satisfies B_H<=LOCAL<=B_H/(1-delta) (equivalently (1-delta)LOCAL<=B_H). This uses positivity of Bnear, not a lower overlap hypothesis. LOCAL is a positive surrogate, not merely Bnear. The far FIRST MOMENT remains unpaid. The weaker author statement LOCAL<=B_H+delta X_q also holds. No arbitrary receiver-pair restriction may be inserted while retaining a whole original square.

The inclusive physical clock ell=b^-n delta_b+n r^-n-1 dr gives integral_[R,b]ell=R^-n, including R=a,b. Therefore the ungated matched first moment is exactly X_q=integral_E q_u du. High-row restriction only decreases it. This endpoint identity is needed for Qfar<=delta X_q. At fixed r the symmetric-difference formula has factor 1/2 and the same two receiver measures du/m; expansion gives J M minus the original square. No extra completion, source copy, or negative-credit reuse is allowed.

## Author review and evidence
Read /tmp/r363_variance.md in full. Its statements, proof, gate directions and scope agree with the above. It presents the additive form, which is consistent with the stronger multiplicative form. Original general soft/mismatched source difficulty is explicitly retained.

Parent reports fresh 416 checks = 96 exact Fraction variance checks plus 320 Decimal/zero-branch center-envelope checks; these do not turn the continuum proof into numerical evidence. Parent also reports 1110 exact clock/split checks. Reviewer did not rerun either pipeline. A separate reviewer-local Python Fraction exercise actually checked 81 nonnegative near/far/square configurations for the multiplicative implication; this is scalar algebra only and is not part of the parent count.

## Final integration and auxiliary review
Read /tmp/r363_main.md, /tmp/r363_ledger.md, /tmp/r363_readme.md and /tmp/r363_astra.md in full, plus both standalone parent check scripts. PASS without a substantive correction request.

The final main adopts the stronger positive comparison Bnear+(1-delta)Ffar<=B_H<=Bnear+Ffar, hence B_H<=B_loc<=B_H/(1-delta), and fixes delta=1/4 only as an optional comparison constant. No delta X_q charge is added, no inherited path fee is multiplied by 4/3, and no original square is spent again in the R362 path reduction. A future bound on B_loc would enter through B_H<=B_loc, with the original entrance factor 2 and outer Lambda unchanged. Near restrictions in source variables need not preserve an HS/PSD feature representation, even though their scalar variance integrands remain nonnegative. The manuscript explicitly avoids that inference.

The inherited R362 ledger retains the D-count head, the initial-top-rank C_init W_ex receipt, the subsequent recomputed direction columns, the unproved F_(>L,deep), all original hard/soft contract exclusions and historical/time/scale fees. C_init remains a R362 fee, head a R361 fee, and this round adds none. Same-X qualification of the old CZ 1/256 and the unused absorption margin are retained. The conditional future gamma estimate is not inserted. Inherited b_*, r_p and Lambda_p definitions match the preceding audited contract. This review checks consistency of inheritance, not every historical reduction afresh.

Astra support is the measurable essential incidence set {A_r(y,z)>0}, with W_D its actual f mass. Completing the source-row square gives B_D=M_D(1-eta_D)-J integral f(p-eta_D)^2, eta_D=M_D/(J W_D); zero W_D has zero contribution. Thus eta_D>=1-epsilon pays only that original (r,y) slice by epsilon X_q, and leaves its complement. The geometric containment is support subset Q_(2r)(y), so W_D<=f(D intersect Q_(2r)(y)); it gives no source density cap. In Far, eta_D<=delta, so for delta<1-epsilon the proposed absorption slice is empty up to zero contribution. This auxiliary estimate is not entered as a new ledger payment or a second credit. Its arbitrary measurable D must be formed from the same frozen data and the complete original square.

The standalone variance script matches the author embedded code up to whitespace; its 96 variance checks use exact Fraction and the other 320 use Decimal/zero branches. The split script uses exact rational matched finite-incidence data, positive layer clock weights whose tails equal R^-n including the last atom, and verifies the full first moment, both positive inequalities and the multiplicative direction in three 370-check stages. It defines numerical Far by p<=delta, rather than claiming the finite data realize the continuum distance predicate. Parent reports actual fresh 416 mixed plus 1110 Fraction checks. Astra 2289 exact scalar checks are author-reported only and are not part of the parent rerun count. Reviewer 81 Fraction implication checks remain separate. No full pipeline was repeated for this final audit; no numerical finite-incidence result is treated as high-dimensional cube/lowpe/history realization.

No new source or receiver payment, general B_H bound, root-order closure, TeX compilation, ZIP integrity or Git state is certified here. All unpriced complements remain explicit.

## Final SHA256 bindings

- `/tmp/r363_variance.md` — `cb6fca2f3ac79aa316e44be4e8f31ad14598be2bf9e8ccb94dcb1c9e9c26cdb5`

- `/tmp/r363_main.md` — `92da3a63643aedcb10f43b2e4cf488ddbaa80acd3216f13f96867930c33b76a4`

- `/tmp/r363_ledger.md` — `951c3fd22ffe368788e29444c70b4e273d0162d5513e3b254eb335eb38d7783d`

- `/tmp/r363_readme.md` — `7be30a315b7fbead4f646f5005e3b14046fa2bb84f88f7ec16f30f7b74902438`

- `/tmp/r363_astra.md` — `1e25c24f7c0dfe06aa60d2d988e2f1ba180cec3086a7bcfcaf5c057994094061`

- `/tmp/r363_variance_check.py` — `98f19f6ea04519c2cb85ef5a994cc2f21177c5fe2091f6e6adf39e581e5987b8`

- `/tmp/r363_split_check.py` — `b3f00e843ce31a2b81d552f52b7907c0de2da83463c013424da01955d8750cb4`

- `/tmp/r362_audit.md` — `de0b0b973913df5dfbddee7bb3f420aa4125432db2fc8048bf64f1f06604f7c1`

- `/tmp/r362_ledger.md` — `5993727cb5c38834dd7e6287fef7e5743823243c71510dae9c5e0325bef54552`
