# R363 — Exact hard variance and source-distance localization of its existing square

## 1. Scope and equality

This note works only in the matched hard slot alpha=1, s=0, L=R, beta=nu=f. The actual full f, E, R and q are frozen, with f>=0 integrable,

    m_u=integral_(Q_u) f=q_u R_u^n,
    q_-<=q_u<=lambda, a<=R_u<=b<=2a,
    E_r={u in E:R_u<=r}, dmu(u)=du/m_u,
    c_u(y)=1_(Q_u)(y),
    J_r(y)=integral_(E_r)c_u(y)dmu(u),
    A_r(y,z)=integral_(E_r)c_u(y)c_u(z)dmu(u),
    M_r(y)=integral f(z)A_r(y,z)dz.

Write a_r(y)=1_{J_r(y)>=H}/J_r(y), with zero value on zero rows and H>0. The proposed fixed-physical-time identity is correct:

    B(r)=integral f(y)1_{J_r(y)>=H}
                  [M_r(y)-integral f(z)A_r(y,z)^2 dz/J_r(y)]dy
        =1/2 integral_(E_r^2) dmu(u)dmu(v)
             f(Q_u symmetric_difference Q_v)
             integral f(y)a_r(y)c_u(y)c_v(y)dy.              (1)

Here f(S) means integral_S f, not an evaluation of f at a point. Both receiver measures in (1) are the SAME matched du/m. Expanding |c_u(z)-c_v(z)|=c_u(z)+c_v(z)-2c_u(z)c_v(z), the first two terms contribute J_r(y)M_r(y); the last contributes integral f(z)A_r(y,z)^2 dz. Positive Tonelli justifies the expansion. No arbitrary receiver-pair mask is inserted while retaining the same square.

Integrate against the unchanged physical clock

    ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr

to obtain the original hard B_H. The equality is the hard full-source specialization of the R302 identity, not a new payment. General soft U or different beta,nu require their original separate-source formula; (1) cannot simply be substituted there.

## 2. A real cube-geometry bound for the shared-source capture

For two source positions y,z put d_i=|y_i-z_i| and

    V_t(y,z)=product_i (t-d_i)_+,
    G_r(y,z)=V_r/r^n+n integral_a^r V_t/t^(n+1)dt,
    A_n(r)=1+n log(r/a).

Then the ACTUAL capture kernel satisfies

    A_r(y,z)<=G_r(y,z)/q_-
              <=A_n(r) exp(-||y-z||_1/r)/q_-.               (2)

Proof. A center u capturing y,z at side length R_u has

    R_u>=max(a,2||u-y||_infinity,2||u-z||_infinity)=s(u).

For u in E_r this s(u)<=r, and

    c_u(y)c_u(z)/m_u <=1_{s(u)<=r}/[q_-s(u)^n].

Extend the positive CENTER integral to all real u. The sublevel volume {s(u)<=t}, t>=a, is exactly V_t: it is the intersection of the two center cubes Q_t(y) and Q_t(z). Layer cake, including the base t=a contribution, gives

    integral_{s<=r}s^(-n)du
       =r^(-n)V_r+n integral_a^r t^(-n-1)V_t dt=G_r.

This argument bounds an actual receiver dx integral. It does not bound source boundary mass by boundary volume. Since

    V_t/t^n=product_i(1-d_i/t)_+
             <=exp(-sum_i d_i/t)<=exp(-||y-z||_1/r),

(2) follows. It is valid at r=a, including actual receiver radius atoms, and if any d_i>=r the overlap is zero up to null boundaries.

## 3. Quantitative use: the far-source part of the EXISTING credit is small

Fix 0<delta<1, and at each physical r define

    ell_star(r)=r log_+(A_n(r)/(delta q_- H)),
    Far_r={(y,z):||y-z||_1>=ell_star(r)}.

On a high row J_r(y)>=H, (2) implies for Far_r

    A_r(y,z)/J_r(y)<=delta.                               (3)

If the logarithm is truncated to zero, the same conclusion follows from A_n(r)/q_-<=delta H; indeed such a high row must then be empty. Thus no division or exceptional threshold case is hidden.

Let E_far be the far-source portion of the ORIGINAL negative square:

    E_far=integral ell(dr) integral f(y)f(z)a_r(y)
                              A_r(y,z)^2 1_(Far_r) dy dz.

Then

    0<=E_far<=delta X_q,  X_q=integral_E q_u du.            (4)

Indeed (3) gives E_far<=delta integral ell integral f(y)1_high M_r(y)dy. The full first moment, with the high gate removed, is EXACTLY X_q:

    integral ell(dr) integral f(y)M_r(y)dy
       =integral_E [m_u^2/m_u] ell([R_u,b])du
       =integral_E m_u R_u^(-n)du=X_q.                    (5)

The same physical clock and terminal b atom are indispensable to (5). The full-source mass m_u in both source integrations is exactly the matched mass used in mu.

If E_near denotes the complementary square credit and F denotes the full high-row positive first moment, define B_local=F-E_near. Equations (1) and (4) give

    B_H<=B_local<=B_H+delta X_q.                           (6)

Thus the original square can be localized, with a controlled receiver error, to source pairs within ell^1 distance ell_star(r) at the SAME physical r. This keeps its conditional row normalization J_r(y); it does not replace it by J_max. The near square is still subtracted once and the far square is not spent a second time.

## 4. What is still missing

There is no new root-order payment of B_H in this note. Formula (6) is a genuine quantitative localization of its existing energy, but the direction is important: deleting far credit raises an upper bound. It does not pay the positive far-source traffic. In particular, an upper bound on A_r cannot be read as a lower bound on E_near.

After the source-distance truncation the unresolved geometric estimate is a lower bound for the original near-source credit sufficient to cancel the high-row positive first moment, with the original matched source measure and actual receiver set. Pointwise facts

    I_uv=integral f c_u c_v<=min(m_u,m_v),
    integral f(y)a_r(y)c_u(y)c_v(y)dy<=I_uv/H

alone do not supply that lower bound. Replacing source symmetric-difference mass by the volume of a thin receiver boundary would require an unavailable source density bound. No such replacement has been made.

The localization narrows the range in which useful shared-source square credit can reside; it does not establish that a substantial fraction resides there. No entrance, path, directional or source-budget ledger is altered here. Were (6) used in the original outer entrance, its sole new approximation error would be 2 Lambda delta X_q, and all other old source, aspect, softness and clock fees would remain.

## 5. Local computation and reproducibility

The following checks compare two independent layer-cake formulae for the actual cube-center envelope, verify its exponential bound, and verify the variance identity with exactly matched rational masses. The latter finite incidence calculations are algebra checks, not realizations of real receiver dx.

~~~python
from decimal import Decimal, getcontext
from fractions import Fraction as Q
from itertools import product
getcontext().prec=65
cnt={'center_layer':0,'exponential':0,'variance':0}
def ck(ok,k):
    assert ok,k
    cnt[k]+=1
def D(x):return Decimal(x.numerator)/Decimal(x.denominator)
def esym(ds):
    e=[Q(1)]
    for d in ds:
        e.append(Q(0))
        for k in range(len(e)-1,0,-1):e[k]+=d*e[k-1]
    return e
for n in range(1,9):
    for seed in range(1,21):
        a=Q(1);r=Q(3,2) if seed%2 else Q(2)
        ds=[Q((seed*(i+3)+i*i)%19,12) for i in range(n)]
        if max(ds)>=r:
            ck(True,'center_layer');ck(True,'exponential');continue
        low=max([a]+ds);e=esym(ds)
        vr=Q(1);vl=Q(1)
        for d in ds:vr*=1-d/r;vl*=1-d/low
        lr=(D(r)/D(low)).ln()
        # Integrate r^-n V(r)+n integral V(t)t^-n-1.
        first=D(vr)+Decimal(n)*lr
        # Integrate the Stieltjes volume derivative plus the base block.
        second=D(vl)+Decimal(n)*lr
        for k in range(1,n+1):
            term=((-1)**k)*e[k]*(low**(-k)-r**(-k))/k
            first+=Decimal(n)*D(term)
            second+=Decimal(n-k)*D(term)
        ck(abs(first-second)<Decimal('1e-52'),'center_layer')
        bound=(1+Decimal(n)*(D(r)/D(a)).ln())*(-D(sum(ds))/D(r)).exp()
        ck(-Decimal('1e-52')<=first<=bound+Decimal('1e-52'),'exponential')
for seed in range(1,25):
    f=[Q(1+(seed+j*3)%7,3) for j in range(5)]
    C=[[int((seed+u*3+j*j+j)%7<4) for j in range(5)] for u in range(4)]
    C=[row for row in C if any(row)]
    masses=[sum((x*c for x,c in zip(f,row)),Q(0)) for row in C]
    mu=[Q(u+1,7)/m for u,m in enumerate(masses)]
    J=[sum((mu[u]*C[u][y] for u in range(len(C))),Q(0)) for y in range(5)]
    A=[[sum((mu[u]*C[u][y]*C[u][z] for u in range(len(C))),Q(0)) for z in range(5)] for y in range(5)]
    for H in [Q(1,10),Q(1,2),Q(1),Q(2)]:
        direct=pair=Q(0)
        for y in range(5):
            if not J[y] or J[y]<H:continue
            direct+=f[y]*sum((f[z]*(A[y][z]-A[y][z]**2/J[y]) for z in range(5)),Q(0))
            for u in range(len(C)):
                for v in range(len(C)):
                    diff=sum((f[z]*abs(C[u][z]-C[v][z]) for z in range(5)),Q(0))
                    pair+=f[y]*mu[u]*mu[v]*C[u][y]*C[v][y]*diff/(2*J[y])
        ck(direct==pair,'variance')
print('PASS variance-geometry checks',cnt,'total',sum(cnt.values()))
~~~


Actual execution of the final embedded script returned:

~~~text
PASS variance-geometry checks {'center_layer': 160, 'exponential': 160, 'variance': 96} total 416
~~~

The matched-mass variance calculations use exact `Fraction` arithmetic. The cube-center integrals and exponential envelopes use 65-digit `Decimal` evaluation of their analytic formulae. Only these finite checks are reported as computational evidence; the continuum bound follows from the layer-cake proof.
