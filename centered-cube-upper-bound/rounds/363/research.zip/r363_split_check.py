from fractions import Fraction as F
checks=0;stages={}
for stage,nr,nz,dim in [('initial',3,2,1),('thresholds',5,4,3),('expanded',9,8,9)]:
 start=checks
 for seed in range(1,11):
  f=[F(1+(seed+3*z)%7,3) for z in range(nz)]
  C=[[int((seed+u*3+z*z+z)%7<4 or z==u%nz) for z in range(nz)] for u in range(nr)]
  m=[sum(f[z]*C[u][z] for z in range(nz)) for u in range(nr)]
  dx=[F(u+1,3*nr) for u in range(nr)]
  R=[1+F(u,2*nr) for u in range(nr)]
  ell=[R[u]**(-dim)-(R[u+1]**(-dim) if u+1<nr else 0) for u in range(nr)]
  X=sum(dx[u]*m[u]*R[u]**(-dim) for u in range(nr));full=F(0)
  for j in range(nr):
   mu=[dx[u]/m[u] for u in range(j+1)]
   A=[[sum(mu[u]*C[u][y]*C[u][z] for u in range(j+1)) for z in range(nz)] for y in range(nz)]
   full+=ell[j]*sum(f[y]*f[z]*A[y][z] for y in range(nz) for z in range(nz))
  assert full==X;checks+=1
  for H in [F(1,10),F(1,2),F(1)]:
   for delta in [F(1,16),F(1,4),F(1,2)]:
    B=N=Ffar=Qfar=F(0)
    for j in range(nr):
     mu=[dx[u]/m[u] for u in range(j+1)]
     A=[[sum(mu[u]*C[u][y]*C[u][z] for u in range(j+1)) for z in range(nz)] for y in range(nz)]
     for y in range(nz):
      J=A[y][y]
      if J<H:continue
      for z in range(nz):
       p=A[y][z]/J;traffic=ell[j]*f[y]*f[z]*A[y][z];var=traffic*(1-p)
       B+=var
       if p<=delta:Ffar+=traffic;Qfar+=traffic*p
       else:N+=var
    assert B==N+Ffar-Qfar;checks+=1
    assert 0<=Qfar<=delta*Ffar<=delta*X;checks+=1
    assert N+(1-delta)*Ffar<=B<=N+Ffar;checks+=1
    assert B<=N+Ffar<=B/(1-delta);checks+=1
 stages[stage]=checks-start
print('PASS',checks,'exact full-clock positive-split checks',stages)
