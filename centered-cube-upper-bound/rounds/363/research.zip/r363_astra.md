# R363 — Exact source-row variance and its conditional absorption

**Status.** This note verifies a positive source-union Jensen estimate, its exact variance remainder, and the precise condition under which it pays a receiver slice of the ORIGINAL B_H. It is standard conditional-variance algebra, not a new cube-geometric theorem or a new root-order payment. No claim of concavity of the original B is needed or made. The missing far-source first moment is not replaced by source volume.

## 1. Correct normalization on the actual receiver layer

At original physical time r use exactly E_r, mu(du)=du/m_u, full f and

    A_r(y,z)=integral_(E_r)c_u(y)c_u(z)mu(du),
    J_r(y)=A_r(y,y),
    M_r(y)=integral f(z)A_r(y,z)dz.

Tonelli and the true matched masses give the useful exact normalization

    M_r(y)=integral_(E_r)c_u(y)du.                         (1)

This is a real receiver volume, not an estimate on f. On J_r(y)>0,

    rho_(r,y)(du)=c_u(y)mu(du)/J_r(y),
    p_(r,y)(z)=A_r(y,z)/J_r(y)
             =rho_(r,y){u:z in Q_u},   0<=p<=1.          (2)

The original hard source-row contribution is therefore

    B_r(y)=M_r(y)-(1/J_r(y))integral f(z)A_r(y,z)^2dz
          =J_r(y)integral f(z)p(z)(1-p(z))dz.             (3)

It is integrated against f(y)1_(J_r(y)>=H)dy. Equations (1)–(3) use the complete matching f. No marked one-sided replacement of the negative square is inserted.

## 2. Exact source-union Jensen bound, including any fixed near/far split

Let D_(r,y) be any measurable source set chosen from the original fixed data, for example the same near/far set used in another original-square calculation. Define the essential incidence support

    S_(r,y)={z:A_r(y,z)>0},
    W_D(r,y)=integral_(D_(r,y) intersection S_(r,y)) f(z)dz,
    M_D(r,y)=integral_(D_(r,y)) f(z)A_r(y,z)dz,
    eta_D=M_D/[J_r(y)W_D]                                (4)

when W_D>0; a zero W_D contributes zero. This avoids a potentially nonmeasurable literal union over receivers. Since p is supported on S, 0<=eta_D<=1.

Let B_D(r,y) be (3) restricted to D. Completing the square gives the EXACT identity

    B_D=M_D(1-eta_D)
          -J_r(y) integral_(D intersection S) f(z)
                         [p_(r,y)(z)-eta_D]^2dz.          (5)

In particular,

    0<=B_D<=M_D-M_D^2/[J_r(y)W_D].                       (6)

The subtracted term in (5) is part of the ORIGINAL negative square; it is not a new source of credit. At fixed J, W_D and M_D, the right side of (6) is the maximum permitted by these scalar moment constraints, with equality exactly when p=eta_D for f-almost every z in D intersection S. Such scalar equality is not asserted to be geometrically attainable by a particular actual cube field.

The actual cube geometry implies only the following support localization here: if A_r(y,z)>0, some contributing cube of side at most r contains y and z, so

    ||z-y||_infinity<=r,
    W_D(r,y)<=integral_(D intersection Q_(2r)(y)) f(z)dz. (7)

The right side remains a FULL-f local mass. No density cap, uniformity, or shell-volume replacement follows from (7).

## 3. Exactly payable condition, with the original clock

For 0<epsilon<1 take the original source-row/time slice

    G_epsilon={ (r,y):J_r(y)>=H,
                M_D(r,y)>0, eta_D(r,y)>=1-epsilon }.

Equations (5)–(6) give the conditional receiver payment

    integral_(G_epsilon) f(y)B_D(r,y)dy ell(dr)
       <=epsilon integral_(G_epsilon)f(y)M_D(r,y)dy ell(dr)
       <=epsilon X_q.                                   (8)

The last inequality uses M_D<=M and the ORIGINAL positive first moment:

    integral ell(dr) integral f(y)1_(J_r(y)>=H)M_r(y)dy
       <=integral ell(dr) integral_(E_r)m_u du
       =integral_E m_u R_u^(-n)du=X_q.                   (9)

Here E_r is the original radius-cutoff receiver layer. The clock is exactly

    ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,

and its inclusive tail ell([R_u,b])=R_u^(-n) includes the terminal atom.

Equivalently, the sufficient hypothesis for (8) is the strong local-incidence mass condition

    W_D(r,y)<=M_D(r,y)/[(1-epsilon)J_r(y)].               (10)

This is a genuine conditional slice bound, but no estimate paying its complement has been established. It is not entered as an additional receipt in the already reduced path ledger. To use it, one must partition the original B_H at the point where the original negative square is still available, and spend that square only once.

## 4. Compatibility with the actual far-source obstruction

On a source/time region where a separately proved true pair-capacity estimate yields p_(r,y)(z)<=delta, the same normalization gives

    eta_D<=delta,
    (1-delta)M_D<=B_D<=M_D.                              (11)

Thus the variance/Jensen estimate supplies no substantial contraction on that region. For delta<1-epsilon it cannot even satisfy the absorption predicate eta_D>=1-epsilon except on zero contribution. The actual far-source first moment M_D still requires a budget. Replacing W_D by the volume of D, or treating source support localization as an upper bound on f mass, would not provide that budget.

This identifies the limit of the tested positive approach concretely. The exact source-row normalization and conditional variance are valid for all matching f; what is unavailable is a general-f geometric argument making (10) prevalent, or paying the true far first moment outside it. No new root-order claim follows.

## 5. Actual local computation, preserved for reproduction

The following Python Fraction code was actually executed inline. It checks the exact variance identity, its Jensen inequality and the conditional payment with zero-support handling. These are scalar algebra diagnostics, not cube-realization evidence.

```python
from fractions import Fraction as F
from itertools import product
checks={'variance_identity':0,'jensen_bound':0,'conditional_payment':0}
for weights in [[F(1),F(2),F(3)],[F(1,2),F(3,4),F(5,6)]]:
  for J in [F(1,3),F(1),F(5)]:
    for p in product([F(0),F(1,4),F(1,2),F(3,4),F(1)],repeat=3):
      support=[i for i in range(3) if p[i]>0]
      W=sum((weights[i] for i in support),F(0))
      M=J*sum(weights[i]*p[i] for i in range(3))
      B=J*sum(weights[i]*p[i]*(1-p[i]) for i in range(3))
      if not W:
        assert M==B==0
        continue
      eta=M/(J*W)
      var=sum(weights[i]*(p[i]-eta)**2 for i in support)
      assert B==M*(1-eta)-J*var
      checks['variance_identity']+=1
      assert 0<=B<=M-M*M/(J*W)
      checks['jensen_bound']+=1
      for eps in [F(1,4),F(1,2)]:
        if eta>=1-eps:
          assert B<=eps*M
          checks['conditional_payment']+=1
print('PASS',checks,'total',sum(checks.values()))
```

Actual output:

```text
PASS {'variance_identity': 744, 'jensen_bound': 744, 'conditional_payment': 801} total 2289
```

Only /tmp/r363_astra.md was written. Work stops at the stated conditional estimate and its unpriced complement.
