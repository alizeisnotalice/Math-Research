"""Exact receiver breakpoints and product-kernel chi-square for positive nodes."""
from collections import defaultdict
from fractions import Fraction as F
from itertools import accumulate, product
from math import prod
import sys


def nodes(m, count, shift=F(0), heterogeneous=False):
    gaps = (F(3, 4), F(5, 4)) if heterogeneous else (F(1),)
    weights = (F(3, 4), F(5, 4), F(1)) if heterogeneous else (F(1),)
    locations = accumulate((gaps[i % len(gaps)] / m for i in range(count - 1)),
                           initial=shift)
    return [(x, weights[i % len(weights)]) for i, x in enumerate(locations)]


def cells(source, s, t):
    events = defaultdict(lambda: [F(0), F(0)])
    for x, w in source:
        for i, side in enumerate((s, t)):
            events[x - side / 2][i] += w
            events[x + side / 2][i] -= w
    ordered = sorted(events)
    ns = nt = F(0)
    for lo, hi in zip(ordered, ordered[1:]):
        delta_s, delta_t = events[lo]
        ns += delta_s
        nt += delta_t
        assert 0 <= ns <= nt
        if nt:
            yield lo, hi, ns, nt


def totals(source, s, t, region=None):
    weight = sum(w for _, w in source)
    shell = chi = ps = pt = peak = first = F(0)
    for lo, hi, ns, nt in cells(source, s, t):
        if region is not None:
            lo, hi = max(lo, region[0]), min(hi, region[1])
        if hi <= lo:
            continue
        width = hi - lo
        probability = nt * width / (t * weight)
        ratio = t * ns / (s * nt)
        assert 0 <= ratio <= t / s
        peak = max(peak, ratio)
        ps += probability * ratio
        pt += probability
        gap = nt - ns
        first += width * gap / weight
        shell += width * gap ** 2 / (nt * weight)
        chi += probability * (ratio - 1) ** 2
    assert chi == (t / s - 1) ** 2 * pt - 2 * (t / s - 1) * first / s + t * shell / s ** 2
    if region is None:
        assert ps == pt == 1 and first == t - s
        assert chi == t * shell / s ** 2 - ((t - s) / s) ** 2
    return chi, shell, peak


def decimal(q, digits=8):
    """Nonnegative display rounded down exactly; error < 10^(-digits)."""
    scale = 10 ** digits
    numerator = q.numerator * scale // q.denominator
    whole, tail = divmod(numerator, scale)
    return f"{whole}.{tail:0{digits}d}"


def equal_shell(m, count, h):
    harmonic = sum(F(1, j) for j in range(1, min(m + 1, count) + 1))
    interior = F(max(0, count - m - 1), m + 1)
    return h * (harmonic + interior) / count


def rank_checks():
    print("INITIAL AND EXPANDED / s=1, m=16; B/W=∫(Nt−Ns)^2/(W Nt) dx")
    print("kind H h*m global_chi B/W peak_ratio interior_chi")
    s, m = F(1), 16
    for heterogeneous in (False, True):
        for count in (m, 4 * m, 16 * m):
            source = nodes(m, count, heterogeneous=heterogeneous)
            for step in (F(1, 2), F(1), F(3, 2)):
                t = s + step / m
                result = totals(source, s, t)
                if not heterogeneous and step <= 1:
                    assert result[1] == equal_shell(m, count, t - s)
                region = (source[0][0] + t / 2, source[-1][0] - t / 2)
                inner = totals(source, s, t, region)[0]
                print("mixed" if heterogeneous else "equal", count, step,
                      *(decimal(z) for z in (*result, inner)))
    source = nodes(8, 8)
    values = totals(source, F(1), F(17, 16))
    print("Exact equal-grid check m=8 H=8 h=1/16:", *values)


def edge_checks():
    print("SENSITIVITY / equal-grid shifts in the same anchored edge receiver")
    m, s, t = 16, F(1), F(33, 32)
    receiver = (-s / 2, -s / 2 + F(1, 2 * m))
    whole = totals(nodes(m, 4 * m), s, t)[0]
    for shift in (F(0), F(1, 3 * m), F(2, 3 * m)):
        source = nodes(m, 4 * m, shift)
        assert totals(source, s, t)[0] == whole
        print("shift", shift, "edge_chi B/W max_ratio", *totals(source, s, t, receiver))
    print("OBSTRUCTION / last point weight H^2, other weights 1; h=1/(2m)")
    for m in (8, 16, 32, 64):
        t = 1 + F(1, 2 * m)
        source = nodes(m, 4 * m)
        flat = totals(source, s, t)[0]
        last, _ = source[-1]
        heavy = F(len(source) ** 2)
        source[-1] = (last, heavy)
        total = totals(source, s, t)[0]
        one_edge = (last + s / 2, last + t / 2)
        pure = totals(source, s, t, one_edge)[0]
        h = t - s
        assert pure == h * heavy / (2 * t * sum(w for _, w in source))
        print("m", m, "flat chi/h", decimal(flat / h), "heavy chi/h", decimal(total / h),
              "pure outer edge chi/h", decimal(pure / h))


def product_check():
    n, s, t = 3, F(1), F(9, 8)
    axes = [nodes(4, 3, heterogeneous=True), nodes(2, 2), nodes(3, 2)]

    def likelihoods(source):
        q = sum(w for _, w in source)
        return [(nt * (hi - lo) / (t * q), t * ns / (s * nt))
                for lo, hi, ns, nt in cells(source, s, t)]

    exact = sum(prod(p for p, _ in item) * (prod(r for _, r in item) - 1) ** 2
                for item in product(*(likelihoods(source) for source in axes)))
    assert exact == prod(1 + totals(source, s, t)[0] for source in axes) - 1
    print("Independent 3D cell enumeration chi =", exact)
    print("EXACT PRODUCTS / n=m^2, h=1/(2m), coarse four nodes/unit")
    for m in (8, 16, 32):
        n, t = m ** 2, 1 + F(1, 2 * m)
        fine, shell, _ = totals(nodes(m, 4 * m), s, t)
        long, long_shell, _ = totals(nodes(m, n), s, t)
        assert shell == equal_shell(m, 4 * m, t - s)
        assert long_shell == equal_shell(m, n, t - s)
        coarse = totals(nodes(4, 16), s, t)[0]
        for bad in (0, m, n // 4):
            exact = (1 + fine) ** (n - bad) * (1 + coarse) ** bad - 1
            print("n", n, "H_fine", 4 * m, "coarse_axes", bad, "chi", decimal(exact))
        print("n", n, "H_fine", n, "coarse_axes", 0, "chi", decimal((1 + long) ** n - 1))


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; 8-place output rounded down.")
    rank_checks()
    edge_checks()
    product_check()
