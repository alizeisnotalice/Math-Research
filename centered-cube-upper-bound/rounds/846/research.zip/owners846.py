"""R846. Shared real old receivers and source layers on one positive two-dimensional cut."""
from fractions import Fraction as F
from itertools import product


def main():
    w = F(1, 64)
    g = F(3, 4)
    base = (2*w)**2
    # sigma has density 3/2 on [-4,4]^2. eta is its restriction to the
    # two diagonal small squares, of half-width w, centered at (0,0),(g,g).
    mass = F(3, 2)*base
    scales = (F(1), F(2))
    areas = (base, 5*base)
    centers = (F(3, 8), F(11, 16))
    halfwidths = ((w,w),(5*w,w))
    assert centers[1]-centers[0] > w+5*w
    for c,hw,s in zip(centers,halfwidths,scales):
        assert all(abs(c-v)+max(hw)+w < s/2 for v in (F(0),g))
        assert c+max(hw)+1 < 4
    # Actual positive subflow F is restricted to the common right packet and
    # has first-slot density multiplier 1/3 on the common packet, 1 on the far one.
    true_receipts = []
    row_bounds = {}
    for k,(side,area) in enumerate(zip(scales,areas)):
        D = side**2
        row = []
        for name,center,fraction in (("common",F(0),F(1,3)),("far",g,F(1))):
            dlo, dhi = max(F(0),center-2*w), center+2*w
            Hlo, Hhi = (1-dhi/side)**2, (1-dlo/side)**2
            assert 0 < Hlo <= Hhi <= 1
            h = area*fraction/D**2
            lo,hi = (D*h/4*min(4,1/tent) for tent in (Hhi,Hlo))
            assert 0<lo<=hi<=1
            row_bounds[k,name]=(lo,hi)
            row.append(h*mass**2)
        true_receipts.append(sum(row))
        print("Actual witness side", side, "disjoint receiver area", area,
              "two ordered source masses", *map(str,row))
    print("Original total on the tested subflow", sum(true_receipts))
    assert row_bounds[1,"common"][0] > row_bounds[0,"common"][1]
    assert row_bounds[0,"far"][0] > row_bounds[1,"far"][1]
    for p in (1,2):
        small = tuple(mass*sum(row_bounds[0,label][i]**p for label in ("common","far"))
                      for i in (0,1))
        merged = tuple(mass*(row_bounds[1,"common"][i]**p+row_bounds[0,"far"][i]**p)
                       for i in (0,1))
        separate = tuple(mass*sum(row_bounds[k,label][i]**p
                                  for k,label in product((0,1),("common","far")))
                         for i in (0,1))
        assert small[1] < merged[0] < merged[1] < separate[0]
        print("p",p,"uniform exact enclosure for old then merged pool",small,merged,
              "pairwise separate sum",separate)
    # Certified score bounds. For c>=0, c/(1+t*c) <= log(1+t*c)/t <= c.
    # The middle bin is empty. Previous-pool enclosures are uniform in z.
    pot_seed = F(1,16)
    for p in (1,2):
        paid = F(0)
        for k,(side,area) in enumerate(zip(scales,areas)):
            ti = area * F(4,3) * mass / side**4
            previous = tuple(F(0) if k==0 else
                             mass*sum(row_bounds[0,label][i]**p for label in ("common","far"))
                             for i in (0,1))
            for label,weight in (("common",F(1,3)),("far",F(1))):
                h_density = area*weight/side**4
                lo,hi = row_bounds[k,label]
                c0 = lo**p/(h_density*(pot_seed+previous[1]))
                c1 = hi**p/(h_density*(pot_seed+previous[0]))
                lower,upper = c0/(1+ti*c0), c1
                assert lower**2 > 2 or upper**2 < 2
                if lower**2>2:
                    paid += h_density*mass**2
        assert paid == (sum(true_receipts) if p==1 else 0)
        print("Entire true mass certified above score sqrt(2), p",p,":",paid)
    probabilities = (F(1,4),F(0),F(0),F(3,4))
    def layers(weights, threshold):
        heights = tuple(b/p for b,p in zip(probabilities,weights))
        breaks = sorted(set((F(0), *heights)))
        taken = completed = F(0)
        for low,high in zip(breaks,breaks[1:]):
            occupied = sum(p for p,h in zip(weights,heights) if h>=high)
            if occupied>=threshold:
                taken += (high-low)*occupied
                completed += high-low
        assert taken <= 1 and completed*threshold <= taken
        return taken,completed
    for weights in ((F(1,4),)*4, (F(9,16),F(3,16),F(3,16),F(1,16))):
        for threshold in (F(1,4),F(1,2),F(5,8),F(1)):
            taken,finished=layers(weights,threshold)
            print("Threshold",threshold,"template",weights,"true layer mass",taken,
                  "completion",finished,"unconditional selected record mass",taken*sum(true_receipts))
    assert layers((F(1,4),)*4,F(1,2)) == (F(1,2),F(1))
    for n in (4,16,64,256,1024):
        # Uniform law on the two diagonal binary words: every axis uniform,
        # joint occupied fraction of a uniform product is only 2^{1-n}.
        assert F(2,2**n) < F(1,2) and F(1,2)*2 == 1
        print("Binary correlation stress n",n,"single-coordinate occupied fraction 1,",
              "joint occupied fraction 2^",1-n,sep=" ")
    print("All checks use exact fractions. Pool enclosures cover every point in the real right packet.")


if __name__ == "__main__":
    main()
