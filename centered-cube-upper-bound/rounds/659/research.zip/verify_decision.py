from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,time,platform
import sympy as sp
import flint
from flint import arb,ctx

start=time.monotonic()
x=sp.symbols('x',positive=True)
g=x-1-sp.log(x)
assert sp.simplify(sp.diff(g,x)-(1-1/x))==0
assert sp.simplify(sp.diff(g,x,2)-1/x**2)==0
assert g.subs(x,1)==0
log_phases={
 'initial':[F(1,2),F(1),F(2)],
 'stress':[F(1)+sign*F(1,2**k) for k in (1,8,64,256) for sign in (-1,1)],
 'expanded':[F(2)**k for k in (-1024,-512,-64,-8,8,64,512,1024)]+[F(1)+sign*F(1,2**k) for k in (512,1024) for sign in (-1,1)]+[F(3,7),F(7,3)]
}
log_records=[]
for phase,vals in log_phases.items():
 for val in vals:
  ctx.prec=max(256,4*max(val.numerator.bit_length(),val.denominator.bit_length())+128)
  a=arb(str(val));d=a-1-a.log()
  if val==1:assert d==0
  else:assert d>0,(phase,str(val),str(d))
  log_records.append({'phase':phase,'x':str(val),'precision_bits':ctx.prec,'residual_enclosure':d.str(30),'status':'exact equality' if val==1 else 'strictly positive interval'})

grid_phases={
 'initial':[(n,t) for n in (1,2,3) for t in (F(1),F(33,32),F(2))],
 'stress':[(n,F(1)+F(1,2**k)) for n in (1,3,16) for k in (1,32,256)],
 'expanded':[(n,t) for n in (1,2,7,32,128,512) for t in (F(1)+F(1,2**1024),F(3,2),F(2)**32,F(2)**1024)]
}
grid_records=[]
for phase,vals in grid_phases.items():
 for n,t in vals:
  a=32*n;h=t-1;r=t/a
  if h==0:q=0;spacing=F(0);centers=[F(0)]
  else:
   z=h/r;q=(z.numerator+z.denominator-1)//z.denominator
   spacing=2*h/q
   assert 1<=q<=a and spacing<=2*r
   assert -h-r==-(h+r) and -h+q*spacing+r==h+r
   centers=[-h+k*spacing for k in range(q+1)] if phase=='initial' else None
  if centers is not None:
   assert centers[0]-r==-(h+r) and centers[-1]+r==h+r
   assert all(centers[j]+r>=centers[j+1]-r for j in range(len(centers)-1))
  assert q+1<=a+1
  grid_records.append({'phase':phase,'n':n,'t':str(t),'centers_per_axis':q+1,'exact_spacing_le_two_r':True,'exact_endpoints':True,'full_tensor_enumerated':False})

out={'scope':'Finite implementation checks, not a general dimension estimate. Analytic proofs and independent audit are separate. Expanded grid checks verify a single coordinate; the n-dimensional covering follows from the product proof, not enumerated points.','command':f'{sys.executable} verify_decision.py','python':platform.python_version(),'executable':sys.executable,'versions':{'sympy':sp.__version__,'python_flint':flint.__version__},'elapsed_seconds':time.monotonic()-start,'worker_count':1,'symbolic_checks':{'g_prime':'1-1/x','g_second':'1/x^2','g_at_1':'0'},'arb_checks':log_records,'exact_grid_checks':grid_records,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'software_sources':['https://python-flint.readthedocs.io/en/latest/arb.html','https://flintlib.org/doc/arb/index.html'],'proof_state':'No new full-D improvement; pure sqrt upper bound remains unproved'}
Path('decision_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'arb_count':len(log_records),'grid_count':len(grid_records),'max_precision':max(z['precision_bits'] for z in log_records),'phases':['initial','stress','expanded'],'elapsed_seconds':out['elapsed_seconds'],'scope':out['scope']},ensure_ascii=False,indent=2))
