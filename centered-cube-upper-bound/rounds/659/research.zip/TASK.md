# R659 frozen full-gain target — 2026-11-15

Latest user guidance: pure C_n <= K sqrt(n), same-radius centered axis-parallel cubes, Lebesgue measure, arbitrary L1. R658 completed and pushed c70ef672f604e77f876286c45266d6a1b7bbaa83. Its REPORT.tex and audits are in /Volumes/data/CodexTemp/centered-cube-sqrt-20261114/release. Do not re-read entire history. New research workspace is this directory, no Git writes by agents.

## Frozen objects
n>=1, a=32n. Finite A_j=Q(y_j,s_j), B_j=A_j/a; genuine positive disjoint owners I_j cover union B_j, v_j=|I_j|, V=sum v. K_A={lambda>=0:sum lambda_j 1_Aj<=1 Leb-a.e.}. d_j=|A_j|. Use global calibrated epsilon_* from R658 theorem2, not a per-model choice. Actual optimizer lambda maximizes d.lambda+eps sum v log lambda. AC KKT source mu has m_j=mu(A_j)=d_j+eps v_j/lambda_j, M=mu(R^n)=Q+eps V, Q=d.lambda, R=V/Q, kappa=eps R<=4. t_j=(m_j/d_j)^(1/n).
Score F=R-sqrt(n)H/M; H=(1+kappa)eps sum v_j h_j, h_j=m_j^-1 int_Aj ||z-y_j||infty^2/s_j^2 dmu, so 0<=H/M<=4. T_*=sup R=4/eps; choose one eta-near-F-maximizing state/source. We need not prove an estimate on every arbitrary low-R state, nor require a new unused balancing condition.

## Legal finite action
Any finite nonempty output labels i, parent pi(i), arbitrary cube C_i containing A_pi, |C_i|=m_pi. Thus center c_i within full box ||c_i-y_pi||infty <= (t_pi-1)s_pi. Repeated parents permitted. Arbitrary genuine positive full ownership J_i within C_i/a, p_i=|J_i|, W=sum p=|union C_i/a|. Actual SAME-eps optimizer alpha, Q'=sum m_pi alpha_i, D=W-RQ'. R658 proves Q'<=M and full all-scale general-L1 recovery.

## Exact goal
Absolute c>0,C<infty, for every n and sufficiently small eta, find one near-F state and one legal finite action with D>=cV-C sqrt(n) M. Or a same-action quantitative improvement that truly advances this inequality. Allow state-dependent finite output count, no hidden constants. A new numerical sample is not a theorem; variable coefficients and dimension exponents cannot be guessed.

## Already proved / not new
Full center window/full owners are historical (R644–646). Calibration/bridge proved. Writing D=W-RM+R(M-Q') is identity. For any same-action AC cover nu, ||nu||-Q'=U_nu+sum alpha_i(nu(C_i)-m_i), U_nu>=0. Local first-order Gamma_i=min(component entropy total, P_neighborhood+eps W_neighborhood) bounds alpha_i>=eps p_i/Gamma_i. Once-paid source: sum p_i m_i/Gamma_i <= (1+1/a)^n M. Gamma_i<=5mu(union neighboring inherited A) uses global calibration. This payment also works for arbitrary symmetric convex shapes; it supplies no cube-specific sqrt gain. Do not rename it as a new global bound.

## Candidate geometry to examine, not an assumed lemma
All admissible centers of a parent have receiver union G_j=Q(y_j,[(t_j-1)+t_j/a]s_j). A finite dense net approximates union G_j in Lebesgue measure but its true Q' changes; do not ignore that. Is a complete center-selection plus cube product structure able to create gain, or can a near-F stationary state force a quantitative source/receiver relation that implies R=O(sqrt(n))? Need one actual action; no combining one law's W and another law's Q'.

## Limits / stopping
No reproof of existing interface, no unbounded report creation, no unfocused counterexample sweep. First deliver one concrete formula/mechanism with exact remaining step; then author/auditor exchange. Report failure scope honestly. Own only assigned file. Shared codebase: do not revert others. Do not initiate heavy computation; numerical owner gets one frozen decision task. Do not use finite atomic states as globally calibrated near-F states. Complete then wait.
