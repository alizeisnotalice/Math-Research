# R659 精简研究包

一般纯 sqrt(n) 上界和旧一般目标均未证明。本轮关闭同价上界下受线性预算支配的对数熵改写；有限张量网格精确覆盖只是合法动作工具，没有新增维数阶收益。先读 REPORT.tex 及 FINAL_REVIEW.md。

详细代数、独立支配审计、来源分支停止原因、实际数值输入与结果随包保留。没有编译PDF，没有复制历史证明。

重放：将 verify_decision.py 复制到 /Volumes/data/CodexTemp 下新建的空目录，在该目录用配有 SymPy 和 python-flint 的解释器运行。原运行解释器为 /Users/zzh/.local/share/math-research-tools/venv/bin/python。脚本生成新的 decision_results.json；时间和解释器路径可以不同。原报告的25项Arb残差和42项有理网格检查已实际运行。有限点与有限参数不替代一般证明。最高精度4228比特；扩大网格检查只验证单坐标边，张量覆盖靠解析证明。

manifest.json 提供所有包内文件的 SHA-256。源码和结果中只记录本轮实际计算，不将其他项目CPU负载列为本轮使用量。
