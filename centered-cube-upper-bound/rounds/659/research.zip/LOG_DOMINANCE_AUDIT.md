# Log 证书支配：独立原子审计

2026-11-15。仅审本原子命题，未读作者稿或 `REPORT.tex`，未重复整稿审查。结论：命题通过，无实质缺口；下面列出必要的共同参数量词。

## 1. 精确恒等式与方向

固定同一动作及其实际 entropy 最优解 \(\alpha\)，\(p_i>0\)、\(\varepsilon>0\)、\(R\ge0\)、\(\kappa=R\varepsilon\)，令
\[
g_i=\varepsilon p_i/\alpha_i>0,
\quad Q'=\sum_i m_i\alpha_i,\quad W=\sum_i p_i.
\]
对同一有限 AC cover \(\nu\)，令 \(h_i=\nu(C_i)-m_i>0\)、\(U_\nu=\|\nu\|-\sum_i\alpha_i\nu(C_i)\ge0\)。有限求和直接给出
\[
D=W-RQ'=W-R\|\nu\|+RU_\nu
       +\kappa\sum_i p_i h_i/g_i.
\]
若 \(0<g_i\le b_i\)，定义 \(x_i=h_i/b_i>0\)，则
\[
L_\nu=W-R\|\nu\|+\kappa\sum_i p_ix_i,
\qquad
F_\nu=(1+\kappa)W-R\|\nu\|
             +\kappa\sum_i p_i\log x_i.
\]
精确剩余项为
\[
D-L_\nu=RU_\nu+
 \kappa\sum_i p_i h_i(1/g_i-1/b_i)\ge0,
\]
\[
\boxed{L_\nu-F_\nu
 =\kappa\sum_i p_i(x_i-1-\log x_i)\ge0.}
\]
因为 \(x-1-\log x\) 在 \(x=1\) 取最小值 0，故 \(D\ge L_\nu\ge F_\nu\)。\(\kappa>0\) 时第二个等号要求所有正 owner 行 \(h_i=b_i\)。符号与 \((1+\kappa)W\) 系数均正确。

## 2. Owner 选择与正 reserve

几何、\(\nu\)、\(b_i\) 固定时，\(x_i\) 固定，真实 full owners 满足 \(\Omega=\cup_i C_i/a\)、\(W=|\Omega|\)。每点最大 score 规则给线性项 \(\max_{i:x\in C_i/a}x_i\)；log 单调，log 规则有同一 argmax。于是逐点仍有
\[
\max_i(1+\log x_i)\le\max_i x_i,
\]
积分和取 supremum 不改变支配。

某些标签的最大-score 区域可能为零，故不保证严格正 owner 的最优划分被取到。有限正体积 receivers 内可给每个标签预留两两不交、总量任意小的正体积 pieces，再在剩余区域按 score 分配；有限正 scores 及其 logs 均有界，损失趋于 0。这证明正 reserve 不改变 supremum，不能擅自把它说成无损最大值取得。

**必须保留的量词：** 每次改变 owners 后，都须使用该 owner 选择的实际重优化 \(\alpha\)，并有同一个几何 \(b_i\) 对该选择仍满足 \(g_i\le b_i\)。只在一个既定 owner 上证明的界，不能直接用于自由优化 owners。若 \(\nu\) 随 owners 改变，逐点 score 计算时须先固定它，或把结论放在共同合法 pair 集上的联合 supremum 中。

## 3. Cover 优化与 \(k\mu\) 的端点支配

在任何相同合法参数集上，逐项 \(F_\nu\le L_\nu\) 蕴含 \(\sup F_\nu\le\sup L_\nu\)；优化 cover、owners 或共同额外参数不能逆转支配。对任意 cover 的 supremum，不能无证明改成与某个固定 cover 的线性值比较。

对特别的 \(\nu=k\mu\)，固定动作、owners 与随 \(k\) 不变的 \(b_i\)，令 \(a_i=\mu(C_i)\ge m_i>0\)、\(M=\|\mu\|\)。当 \(k>1\) 时 \(h_i(k)=ka_i-m_i>0\)。共同向量
\[
\theta_i=\varepsilon p_i/b_i\le\alpha_i
\]
因 packing 的向下封闭性而可行；由 \(\mu\) AC，
\[
\sum_i\theta_i a_i
=\int\sum_i\theta_i1_{C_i}\,d\mu\le M.
\]
因此
\[
L(k)=W-\kappa\sum_i p_im_i/b_i
     +kR\left(\sum_i\theta_i a_i-M\right)
\]
随 \(k\) 不增，严格得到
\[
\boxed{\sup_{k>1}F(k\mu)\le L(\mu).}
\]
\(k=1\) 若有零行余量，log 可能无定义，但线性端点仍合法；这不影响上述比较。此结论要求 \(b_i\) 随 \(k\) 固定，不能为每个 \(k\) 偷换分母后沿用同一斜率证明。

## 4. “更强”的准确范围

无新假设时，可保留第 1 节显示的 \(U_\nu\) 与 \(g_i<b_i\) 正剩余项；这是精确公式已有的信息，不是 log 带来的新收益。仅凭 \(g_i\le b_i\)、\(U_\nu\ge0\)，不存在对所有实例严格改进 \(L_\nu\) 的统一正增益：单容器实际最优 \(\alpha=1\)，取 \(b=g=\varepsilon p\) 且 AC cover 支持在该容器内，就有 \(U_\nu=0\)、\(D=L_\nu\)。这个等号例只说明证书的普遍改进范围，不反驳原几何目标。

**核验记录。** 本机 Python `Fraction` 实跑一次有限精确核对：两重复同容器、\(m=M=2\)、\(W=1/16\)、\(p=(W/3,2W/3)\)、\(\varepsilon=3\)、\(R=5\)、\(b_i=1/4\)，在 \(k=3/2,2,7\) 时精确恒等式全部通过；线性斜率为 \(-5/2\)。log 的普遍支配由上述解析不等式证明，不依赖这些有限实例或主流程的网格/残差结果。
