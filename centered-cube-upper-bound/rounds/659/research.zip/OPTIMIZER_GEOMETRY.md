# R659：真实熵对偶预算与严格支配审计

日期：2026-11-15。责任文件仅本文件。状态：**完整 `D ≥ cV − C sqrt(n) M` 未证明。本次关闭“全局缩放旧源 + 熵对偶对数改写 + 同一价格上界”的分支。** 关闭理由是下文的严格支配定理；不是数值样本，也不是把一般对偶恒等式作为方体新进展。

## 1. 固定同一个合法动作

使用 TASK.md 的全部冻结条件，特别是全局校准的同一个 `epsilon`，并固定一个合法有限输出动作及其真实 positive full owners。记

\[
 m_i=m_{\pi(i)},\quad p_i=|J_i|>0,\quad
 W=\sum_i p_i,\quad
 Q'=\sum_i m_i\alpha_i,\quad
 D=W-RQ',\quad \kappa=\epsilon R.
\]

`alpha` 是这个动作、这些 owners、同一个 `epsilon` 的真实熵最优解。旧 AC KKT 源为 `mu`，质量 `M`，且

\[
 u_i:=\mu(C_i)=m_i+e_i,\qquad
 e_i:=\mu(C_i\setminus A_{\pi(i)})\ge0.
\tag{1}
\]

没有混用另一动作的 `W`、`alpha` 或 `Q'`。后文的 `k` 只缩放一个用于验证的全局对偶源，不改变动作、owners 或真实最优解。

## 2. 新问题的实际熵价格

对有限方体 arrangement 作有限 LP 的 KKT 表述，可选择新问题的 AC 对偶源 `nu_*`，满足

\[
 g_i:=\nu_*(C_i)-m_i=\frac{\epsilon p_i}{\alpha_i}>0,
\tag{2}
\]

以及互补关系

\[
 \int\left(1-\sum_i\alpha_i1_{C_i}\right)d\nu_*=0.
\]

因此

\[
 N:=\|\nu_*\|=Q'+\epsilon W.
\tag{3}
\]

`g_i` 是实际优化价格，不是单独父行重求的问题的价格。单父行的共同交约束不能与别行分别解后拼为全图解。

## 3. 对偶目标与完整非负余项恒等式

对任意 AC 有限非负源 `nu`，若

\[
 h_i:=\nu(C_i)-m_i>0\quad\text{对所有 }i,
\]

定义熵对偶目标

\[
 \mathcal J(\nu)
 =\|\nu\|+\epsilon\sum_i p_i
       \left(\log\frac{\epsilon p_i}{h_i}-1\right).
\tag{4}
\]

这来自对各 `alpha_i>0` 计算

\[
 \sup_{x>0}\{-h_i x+\epsilon p_i\log x\}
 =\epsilon p_i\left(\log\frac{\epsilon p_i}{h_i}-1\right).
\]

令

\[
 U_\nu=\int\left(1-\sum_i\alpha_i1_{C_i}\right)d\nu\ge0.
\]

这里非负性使用了 **同一真实 `alpha` 的全空间共同可行性以及 `nu` 的绝对连续性**。由 `(2)`，

\[
 \begin{aligned}
 \|\nu\|-N
 &=U_\nu+\sum_i\alpha_i h_i-\epsilon W\\
 &=U_\nu+\epsilon\sum_i p_i\left(\frac{h_i}{g_i}-1\right).
 \end{aligned}
\]

所以有精确恒等式

\[
 \boxed{\quad
 \mathcal J(\nu)-\mathcal J(\nu_*)
 =U_\nu+\epsilon\sum_i p_i
 \left[\frac{h_i}{g_i}-1-\log\frac{h_i}{g_i}\right]\ge0.
 \quad}
\tag{5}
\]

这既核对了熵对偶比较的符号，也展示了比较中真正被丢掉的非负余项。它不是一个未支付的额外收益。

由 `(4)`–`(5)` 可得正确的对数价格上界

\[
 N\le\|\nu\|+\epsilon\sum_i p_i\log\frac{g_i}{h_i}.
\tag{6}
\]

等价地，完整预算有

\[
 \boxed{\quad
 D\ge(1+\kappa)W-R\|\nu\|
       +\kappa\sum_i p_i\log\frac{h_i}{g_i}.
 \quad}
\tag{7}
\]

`(7)` 的确保留真实 `Q'`，但 `(5)` 表明它来自已知线性 cover gap 与 `x−1−log x ≥0`。正确性本身不意味着它优于原预算。

## 4. 全局缩放旧源的正确式子

取一个共同 `k>1`，令 `nu=k mu`。这是同一个全局 AC 源，非逐父行拼接。此时

\[
 h_i(k)=ku_i-m_i=(k-1)m_i+ke_i>0,
\]

故 `(7)` 给出

\[
 D\ge(1+\kappa)W-RkM
       +\kappa\sum_i p_i
            \log\frac{(k-1)m_i+ke_i}{g_i}.
\tag{8}
\]

早期推导中曾用粗界 `g_i ≤ N−m_i` 把分母变为全局 `N`；该界虽正确，但远分离复制会使它人为恶化，不宜作为几何尺度。本报告保留实际 `g_i`，或仅使用已经证明的同一动作局部上界，例如 TASK/R658 允许的 `g_i ≤ Gamma_i−m_i`。

## 5. 同价上界下：对数证书必被线性证书支配

固定一组有限正数 `b_i`，满足

\[
 b_i\ge g_i,
\tag{9}
\]

并且当 `k` 变化时 `b_i` 不变。特别地，可用一个已证、同一动作的局部价格上界。若该上界还与 owner 选择无关，当然仍适用；以下固定动作的证明其实只需要其与 `k` 无关。

定义对数证书

\[
 B(k)=(1+\kappa)W-RkM
       +\kappa\sum_i p_i\log\frac{ku_i-m_i}{b_i},
 \qquad k>1,
\tag{10}
\]

和线性证书

\[
 L(k)=W-RkM
       +\kappa\sum_i p_i\frac{ku_i-m_i}{b_i},
 \qquad k\ge1.
\tag{11}
\]

`(8)` 与 `(9)` 保证 `D ≥ B(k)`。已知的线性 cover gap

\[
 kM-Q'=U_{k\mu}+\sum_i\alpha_i(ku_i-m_i)
\]

结合 `alpha_i=epsilon p_i/g_i ≥ epsilon p_i/b_i`，保证 `D ≥ L(k)`。这里 `ku_i−m_i ≥0` 对全部 `k≥1` 成立，故替换方向合法。

逐项应用 `1+log x ≤ x`，得到

\[
 \boxed{\qquad B(k)\le L(k)\quad(k>1).\qquad}
\tag{12}
\]

因此，若最后依旧使用同一个价格上界 `b_i`，对数重写没有补回任何此前因极小 `alpha_i` 丢失的付款。

## 6. 额外关键结论：优化 `k` 也无法补救

令

\[
 \theta_i=\frac{\epsilon p_i}{b_i}.
\]

由 `(2)`、`(9)`，`0≤theta_i≤alpha_i`，所以 **同一组 `theta` 全空间共同可行**：

\[
 \sum_i\theta_i1_{C_i}\le1\quad\mathrm{Leb.a.e.}
\]

旧源 `mu` 是 AC，故可积分得到

\[
 \sum_i\theta_i u_i
 =\int\sum_i\theta_i1_{C_i}\,d\mu\le M.
\tag{13}
\]

对 `(11)` 求关于 `k` 的斜率，

\[
 \begin{aligned}
 L'(k)
 &=-RM+\kappa\sum_i\frac{p_i u_i}{b_i}\\
 &=R\left(\sum_i\theta_i u_i-M\right)\le0.
 \end{aligned}
\tag{14}
\]

所以

\[
 \boxed{\qquad
 \sup_{k>1}B(k)\le\sup_{k\ge1}L(k)=L(1)
 =W-RM+\kappa\sum_i\frac{p_i e_i}{b_i}.
 \qquad}
\tag{15}
\]

右侧正是 `k=1` 的原线性实际亏损预算。即使 `e_i=0` 导致 `B(1)` 不有限，也不影响 `(15)`；其线性端点 `L(1)` 始终有定义。

这个结论并不假设 owners 均匀，也不假设各父行独立、平衡或局部可行权可拼接。它依赖的共同可行权只是实际 `alpha` 的逐坐标减小，因而不存在量词偷换。

## 7. 方体乘积几何检查与关闭范围

对某父行 `j`，允许中心窗

\[
 T_j=Q(y_j,(t_j-1)s_j)
\]

内均匀选择中心时，固定源点 `z` 的捕获概率确实具有区间乘积公式

\[
 \phi_j(z)=\prod_{r=1}^n
 \left(1-\frac{(|z_r-y_{j,r}|-s_j)_+}
                   {2(t_j-1)s_j}\right)_+.
\tag{16}
\]

这是逐坐标求
`[-(t_j−1)s_j,(t_j−1)s_j]` 与
`[z_r−y_{j,r}−t_js_j,z_r−y_{j,r}+t_js_j]`
的交长，再除以 `2(t_j−1)s_j` 得到。`t_j>1` 在冻结正 owners、正 epsilon 下成立。

但真实 full owners 的 `p_i` 未必是均匀中心权。即使先获得正确的 owner 加权算术捕获，凹性也不允许直接用它下界对数。一个合法但有限的修复是弦下界：若

\[
 E_j^{\max}
 =\mu\bigl(Q(y_j,(2t_j-1)s_j)\setminus A_j\bigr),
\]

则所有该父行标签满足 `0≤e_i≤E_j^max`，从而对 `delta>0`，

\[
 \log(\delta m_j+(1+\delta)e_i)
 \ge\log(\delta m_j)
 +\frac{e_i}{E_j^{\max}}
  \log\left(1+\frac{(1+\delta)E_j^{\max}}{\delta m_j}\right).
\tag{17}
\]

`E_j^max=0` 时直接使用左侧等于 `log(delta m_j)`。式 `(17)` 方向正确，但必须保留 baseline 及实际 owner 权重。更关键的是：**即使用 `(16)`–`(17)` 正确完成这一步，只要最终使用同一个 `(9)`，所得对数证书仍受 `(15)` 支配。** 因而不能将该弦修复、全角点或稠密窗本身算作完整预算的改善。

`(5)`–`(15)` 的支配证明完全不使用方体乘积结构，对一般有限集合的同类熵 packing 也成立。这准确解释了本分支为什么没有产生方体特有的 `sqrt(n)` 因子。

关闭范围是：**全局标量源 `k mu`，通过对偶对数比较，再用同一个已证实际价格上界来估计完整预算。** 这不否定完整目标，不否定同一动作的真实 source/receiver 几何收益，也不排除未来直接控制实际 `g_i` 与中心、owners 的联合关系。但本轮没有建立这种联合关系；按 root 指令不再添加其他候选局部源或前缀权机制。

## 8. 实际核验与结论

采用 `math-d02-gibbs-entropy-duality` 的有限量对偶符号、积分域与共同参数审计原则；全部论证在上面独立给出，不依赖未核外部定理。

实际运行了轻量本机 Python 算术审计：在一个仅用于代数核对的二标签数据上求出实际共同交价格，并验证 `sum theta≈1`、`sum theta_i u_i≈2.88860009≤M=3`、`L'(k)≈−1.48533208`。在 `k=1.001,1.1,2,10` 均得到 `B(k)≤L(k)≤L(1)`。此数据不是全球校准 near-F 几何状态，不作为目标反例；严格证明为 `(12)`–`(15)`。

最终交付是一个确定的分支决策：**原候选对数预算正确，但在拟用的同价上界下受原线性预算严格支配，优化 `k` 也无益。一般完整 D 目标未闭合。**
