# R447 — the remaining source comparison after removing the first marginal

**Bounded conclusion.** Removing the constraint on the first analysis marginal is legitimate and eliminates the R446 cell-marginal imbalance. Exact projection over the old source is also legitimate and may improve the deficiency further (Section 3a). This attachment examines whether the resulting column cancellation has a source price. It does not prove an additional geometric payment: the full-matching estimates available here control the total available capacity from above, whereas the attempted cancellation requires a comparison of that capacity with the actual retained load in the same columns. No further remainder or price is added to the parent ledger.

## 1. The precise candidate screened

Use the unchanged R445 base \(\xi=(e,A,y,z,t)\), finite measure \(\Lambda\), and actual receiver measures
\[
\mu_\xi(dw)=1_{\{Z_w(y)\le h,\ m_w<m_A/K^2\}}
                 c_w(y)\frac{dw}{h m_w},\qquad
\nu_\xi(dv)=1_{\{Z_v(z)\le h,\ m_v<m_A/K^2\}}
                 c_v(z)\frac{dv}{h m_v}.
\]
The actual pushforward is \(\Lambda(d\xi)\Gamma_\xi(dw,dv)\), with
\(\Gamma_\xi=\vartheta_\xi\,\mu_\xi\otimes\nu_\xi\), \(0\le\vartheta_\xi\le1\).
Every original stage, current, acceptance and future restriction is still in
\(\vartheta\). These restrictions are not asserted for an analysis pair.

Write
\[
g_\xi(v)=\int\vartheta_\xi(w,v)\,\mu_\xi(dw),\qquad
k_\xi(v)=\int\bar\psi(w,v)\,\mu_\xi(dw),
\quad
\bar\psi=\min\{1,(\alpha_0/\Delta)^n\}.
\]
The proposed whole-budget step is a source-integrated upper estimate for
\[
\int(g_\xi-Ck_\xi)_+\,d\nu_\xi\,d\Lambda,
\tag{1}
\]
with \(C=\sqrt n\), using the actual mass gap, low-common capture and low
\(T_G,T_{\rm loc}\) indicators. This is now a one-column comparison, not a
two-sided Hall problem. The exact column construction and its pullback are
proved in the parent account; they are not claimed again as this attachment's
geometric advance.

## 2. The actual cancellation that the new freedom makes available

At fixed \((\xi,v)\), put
\[
P_+(\xi,v)=\int(\vartheta_\xi-C\bar\psi)_+\,d\mu_\xi,\qquad
P_-(\xi,v)=\int(C\bar\psi-\vartheta_\xi)_+\,d\mu_\xi.
\]
All these quantities are finite, and
\[
(g_\xi-Ck_\xi)_+
 =P_+-\min(P_+,P_-).
\tag{2}
\]
Indeed \(g-Ck=P_+-P_-\). Thus capacity at an old receiver with low actual
acceptance can compensate load at another old receiver in the **same**
new-terminal column. This is the real improvement over keeping the first
actual marginal. It does not require changing either fixed source or the
original histories used in the eventual pullback.

The native weighted capacity gives the rigorous estimate
\[
\begin{split}
\int P_-\,d\Lambda\,d\nu
&\le C\int\bar\psi\,d\Lambda\,d\mu\,d\nu\\
&\le
\frac{CS\varepsilon_0^2}{s^2}\Phi(A_n^2)X_q
\le
\frac{CS\varepsilon_0^2A_n}{s^2}\Phi(A_n^2)W,
\end{split}
\tag{3}
\]
where \(\Phi(B)=B\) for \(B\le2\), and
\(\Phi(B)=2[1+\log(B/2)]\) for \(B>2\).
This is an **upper** bound for the available negative pool. It is not a
lower bound for the cancellation \(\min(P_+,P_-)\), and therefore does not
bound (1). In particular subtracting the right side of (3) from the positive
load would reverse the valid inequality. Equation (3) is an existing capacity
price, not another source fee.

## 3. Where the attempted geometric source integration stops

Let
\[
\mathcal B=\{(\xi,v):g_\xi(v)>Ck_\xi(v)\}.
\]
This is measurable. To expose the exact source issue, expand the capacity
term on these columns without removing the old-source weight. Its value is
\[
\frac{C}{h^2}\sum_e\int\sigma(dA)
\int\frac{c_A(z)1_{\{f(z)>t\}}}{m_A^2}\,dz\,dt
\int\frac{c_v(z)1_{\{Z_v(z)\le h,\ m_v<m_A/K^2\}}}{m_v}\,dv
\int\frac{1_{\{m_w<m_A/K^2\}}\bar\psi(w,v)}{m_w}
       \mathcal I_{A,w;v,z,t,e}\,dw,
\tag{4}
\]
where the actual weighted source capture is
\[
\mathcal I_{A,w;v,z,t,e}
=\int f(y)c_A(y)c_w(y)a_0^e(A,y)
 1_{\{Z_w(y)\le h\}}
 1_{\mathcal B}(e,A,y,z,t,v)\,dy.
\tag{5}
\]
Equations (4)–(5) follow by positive Tonelli; they keep Lebesgue \(dw,dv\)
and the complete matched masses. They are not an independence assertion.
The base measure is
\[
d\Lambda=\sigma(dA)\pi_A(dy)a_0^e(A,y)
\frac{c_A(z)}{m_A}1_{\{f(z)>t\}}\,dz\,dt.
\]
Any additional certified single-terminal gates can simply remain in (4)–(5).

Full matching gives \(I_{Aw}=f(Q_A\cap Q_w)\le m_w\). This yields the known
upper bounds after positive relaxation. The attempted proof, however, needs
a **lower comparison of (5) with the actual positive column load**. Replacing
(5) by \(I_{Aw}\) is only an upper relaxation (up to the known \(a_0\) cap);
it cannot establish that comparison. Moreover \(\mathcal B\) depends on
the old source \(y\), so one cannot first integrate \(y\) to \(I_{Aw}\) and
subsequently keep the same bad-column restriction.

The original low \(T_G,T_{\rm loc}\) indicators constrain full-source common
support and local mass. They remain true in this argument, as do the strict
terminal mass gap and original low-common condition. I have not proved that
they force (5) to supply enough capacity where the actual retained \(g\) is
large. Such a claim needs an assignment of actual old-source retained load to
nearby real \(y\)-capturing receivers, with a lower coverage estimate and a
controlled source-integrated reuse cost. A mere upper bound on \(\mu(E)\), or
on the source columns of the unfiltered terminal kernel, is the wrong
direction.

This is the single failed step of the attempted proof. It is narrower than
the R446 two-marginal balance question: there is no longer any need to match
the actual first marginal. Nevertheless, no estimate of the required
coverage/reuse is established here. Consequently neither (2) nor (4) is
reported as a new root-order payment, and the whole target remains open.

## 3a. Exact old-source pooling is allowed

The preceding warning is about keeping a source-dependent bad set after
relaxing its weight. It is **not** a prohibition on integrating the old source.
The original signed integrand is independent of \(y\) at fixed
\(\xi_0=(e,A,z,t,v)\). With
\[
d\Lambda_0=\sigma(dA)\frac{c_A(z)}{m_A}1_{\{f(z)>t\}}\,dz\,dt,
\qquad \omega_A^e(dy)=\pi_A(dy)a_0^e(A,y),
\]
one can first take the exact projections
\[
\widetilde\mu=\int\mu_y\,d\omega_A^e(y),\quad
\widetilde\Gamma=\int\Gamma_y\,d\omega_A^e(y),\quad
\widetilde g(v)=\int g_y(v)\,d\omega_A^e(y).
\]
Since \(\nu\) depends on the new source and parent, not on \(y\),
\(\widetilde\Gamma\le\widetilde\mu\otimes\nu\). Put
\(\widetilde k=\int\bar\psi\,d\widetilde\mu\).
Convexity of the positive part gives
\[
(\widetilde g-C\widetilde k)_+
\le\int(g_y-Ck_y)_+\,d\omega_A^e(y).
\tag{6}
\]
This requires no probability normalization of \(\omega_A^e\). The new bad
column is defined **after** projection. A second-marginal RN fraction then
pulls back to all the original \(y\)-labelled records, preserving their
actual restrictions. One must not claim that each individual source's
conditional terminal marginal is preserved; that is unnecessary for this
signed integrand.

The cancellation in (2) applies directly to
\(\widetilde\vartheta=d\widetilde\Gamma/
d(\widetilde\mu\otimes\nu)\), and the price (3) is unchanged.
The relevant old-source capture is now exactly
\[
\widetilde{\mathcal I}_{Aw}^e
=\int f(y)c_A(y)c_w(y)a_0^e(A,y)
        1_{\{Z_w(y)\le h\}}\,dy.
\tag{7}
\]
The pooled bad-column indicator is outside this integral. Thus pooling
removes the bad-set dependence from this particular source integration;
it is a real simplification and is not obstructed by (4)–(5).

What remains unproved is a lower coverage comparison between the
\(\bar\psi\)-convolution of (7) and the **exact pooled retained** load
\(\widetilde g\), with a source-integrated error at the requested scale.
The original matching identity still gives only an upper estimate for
(7). The actual low \(T_G,T_{\rm loc}\), rank and history conditions remain
inside the projected load; they cannot be assigned pointwise to the
unfiltered analysis capacity. No such comparison is proved here. This
attachment therefore stops at the pooled version of this specific
geometric gap, without declaring the pooled construction a whole-budget
estimate.

## 4. Executed finite check and its limits

The specified local Python executed `/tmp/r447_geometry_check.py`; output is
saved in `/tmp/r447_geometry.result.txt`. Three small exact Fraction cases
verify (2), the single-column optimum, and that its deficiency is no larger
than the two-marginal capacitated Hall deficiency. They include strict
improvement and positive deficiency. These are conditional-measure algebra
checks, not native cube instances and not realizations of the original mass,
rank or history gates. No geometric parameter scan was undertaken.

This bounded attempt ends here. The parent may use the proved one-column
receipt, but this attachment supplies no additional charge or cancellation
to add to it.
