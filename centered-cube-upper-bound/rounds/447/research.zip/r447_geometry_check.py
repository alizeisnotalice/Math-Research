from fractions import Fraction as F
from itertools import product


def positive(x):
    return max(F(0), x)


mu = [F(1, 2), F(1, 3), F(1, 6)]
nu = [F(1, 3), F(2, 3)]
cases = [
    (F(1), [[F(0), F(1)], [F(1), F(0)], [F(1, 2), F(1)]],
     [[F(1), F(1, 8)], [F(1, 8), F(1)], [F(1, 4), F(1, 2)]]),
    (F(2), [[F(1), F(1)], [F(0), F(0)], [F(0), F(0)]],
     [[F(1, 8), F(1, 8)], [F(1), F(1)], [F(1), F(1)]]),
    (F(1), [[F(1), F(1)], [F(1), F(1)], [F(1), F(1)]],
     [[F(1, 8), F(1, 16)], [F(1, 4), F(1, 8)], [F(1, 2), F(1, 4)]]),
]

for index, (cap, theta, psi) in enumerate(cases, 1):
    gamma = [[mu[i] * nu[j] * theta[i][j] for j in range(2)] for i in range(3)]
    capacity = [[cap * mu[i] * nu[j] * psi[i][j] for j in range(2)] for i in range(3)]
    eta = [sum(row) for row in gamma]
    zeta = [sum(gamma[i][j] for i in range(3)) for j in range(2)]
    mass = sum(eta)
    deficiency = F(0)
    matched = F(0)
    for j in range(2):
        g = zeta[j] / nu[j]
        k = sum(mu[i] * psi[i][j] for i in range(3))
        pp = sum(mu[i] * positive(theta[i][j] - cap * psi[i][j]) for i in range(3))
        pm = sum(mu[i] * positive(cap * psi[i][j] - theta[i][j]) for i in range(3))
        assert positive(g - cap * k) == pp - min(pp, pm)
        deficiency += nu[j] * positive(g - cap * k)
        matched += nu[j] * min(g, cap * k)
    assert mass == matched + deficiency
    hall = F(0)
    for rows in product((0, 1), repeat=3):
        for cols in product((0, 1), repeat=2):
            cut = sum(eta[i] for i in range(3) if rows[i])
            cut += sum(zeta[j] for j in range(2) if cols[j])
            cut -= mass
            cut -= sum(capacity[i][j] for i in range(3) for j in range(2)
                       if rows[i] and cols[j])
            hall = max(hall, cut)
    assert deficiency <= hall
    print(f"case {index}: mass={mass}, column matched={matched}, "
          f"column deficit={deficiency}, two-marginal deficit={hall}: PASS")
print("Scope: exact finite conditional-measure algebra; no native cube or full-history claim.")
