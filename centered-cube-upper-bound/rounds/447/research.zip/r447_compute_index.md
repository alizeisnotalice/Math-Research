# R447 计算索引（冻结）

责任numeric；无其他文件/repo/git/spawn操作。

输入：`r447_numeric_input.json`，从R446已认证最小fixture及ψ上下界提取，并记录源证书SHA256；含R446双边lower/upper作严格改善比较。仅本轮input为脚本依赖。

计算：3个support前缀、固定C2，Fraction精确单列min公式及0/1 primal-dual；Arb复核whole-block ψ上下界和terminal-only U。构造auxiliary H（无H₁约束）与b(v)Γ pullback，检查cap/新column/实际旧row/质量/原far support。没有LP、solver或额外geometry。

命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r447_numeric.py`
Python3.12.14、flint0.9.0、Arb256bit；实际运行资源在resources。所有优化值为有理下模型精确值，连续误差来自已认证whole-block上下界，不由浮点mask决定。

归档白名单（全部`/tmp`）：
- `r447_numeric.py`
- `r447_numeric_input.json`
- `r447_numeric_certificate.json`
- `r447_numeric_run.txt`
- `r447_numeric_resources.txt`
- `r447_numeric.md`
- `r447_compute_index.md`

状态完成冻结。所有质量除θ²，actual mass须乘回；原masscut失败，只作同场有限选择证据，不认证原完整history/U预算。
