"""R447 single-column canonical capacity; no LP or new geometry.
Exact finite column formula plus whole-block continuous lower/upper bridge.
"""
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256
inp=json.loads((ROOT/'r447_numeric_input.json').read_text());old=inp['fixture_source']['fixture']
a=list(map(F,old['raw_normalized_a']));b=list(map(F,old['raw_normalized_b']))
eta=list(map(F,old['actual_row_scaled']));zeta=list(map(F,old['actual_column_scaled']))
plo=[[F(x) for x in row] for row in inp['psi_lower']];phi=[[F(x) for x in row] for row in inp['psi_upper']]
shell=inp['layer_matrix'];m=len(a);k=len(b);assert (m,k)==(4,5)
A=lambda x:arb(str(F(x).numerator))/arb(str(F(x).denominator))
raw=[[x*y for y in b] for x in a]
gamma=[[raw[i][j] if shell[i][j]>0 else F(0) for j in range(k)] for i in range(m)]
assert eta==[sum(row,F(0)) for row in gamma]
assert zeta==[sum((gamma[i][j] for i in range(m)),F(0)) for j in range(k)]
r=sum(zeta,F(0));assert r==F(31,50)
scale=F(old['all_pair_masses_scale']);assert scale==F(old['raw_sourcewise_scale_rho_over_h'])**2
for i in range(m):
 for j in range(k):
  dl,du=map(F,old['whole_block_distance_bounds'][i][j])
  if shell[i][j]==0:assert plo[i][j]==phi[i][j]==1 and A(du)<arb(1).exp()
  else:
   assert A(dl)>arb(1).exp()
   assert A(plo[i][j])<arb(4).exp()/A(du)**4
   assert A(phi[i][j])>arb(4).exp()/A(dl)**4
  assert 0<plo[i][j]<=phi[i][j]<=1

rows=[]
for prefix in [1,2,3]:
 C=F(2)
 caplo=[[C*plo[i][j]*raw[i][j] if shell[i][j]<prefix else F(0) for j in range(k)] for i in range(m)]
 caphi=[[C*phi[i][j]*raw[i][j] if shell[i][j]<prefix else F(0) for j in range(k)] for i in range(m)]
 colcaplo=[sum((caplo[i][j] for i in range(m)),F(0)) for j in range(k)]
 colcaphi=[sum((caphi[i][j] for i in range(m)),F(0)) for j in range(k)]
 targetlo=[min(zeta[j],colcaplo[j]) for j in range(k)]
 targethi=[min(zeta[j],colcaphi[j]) for j in range(k)]
 lower=sum(targetlo,F(0));upper=sum(targethi,F(0));assert lower<=upper<=r
 # Construct lower H with no actual old-row constraint. Uniform block lift
 # satisfies Cpsi raw exactly by the certified whole-block lower bounds.
 H=[[F(0)]*k for _ in range(m)]
 for j in range(k):
  remain=targetlo[j]
  for i in range(m):H[i][j]=min(caplo[i][j],remain);remain-=H[i][j]
  assert remain==0
 hr=[sum(row,F(0)) for row in H];hc=[sum((H[i][j] for i in range(m)),F(0)) for j in range(k)]
 assert hc==targetlo and all(0<=H[i][j]<=caplo[i][j] for i in range(m) for j in range(k))
 # Exact one-column LP dual: min(zeta, sum cap) independently in each column.
 dz=[F(zeta[j]<=colcaplo[j]) for j in range(k)]
 de=[[1-dz[j] for j in range(k)] for _ in range(m)]
 assert all(dz[j]+de[i][j]>=1 for i in range(m) for j in range(k) if caplo[i][j])
 dual=sum((dz[j]*zeta[j] for j in range(k)),F(0))+sum((de[i][j]*caplo[i][j] for i in range(m) for j in range(k)),F(0))
 assert dual==lower
 # Pullback keeps the ACTUAL original old marginal dominated, even when the
 # auxiliary near/soft witness has an old marginal exceeding actual eta.
 keep=[hc[j]/zeta[j] if zeta[j] else F(0) for j in range(k)]
 assert all(0<=x<=1 for x in keep)
 pull=[[gamma[i][j]*keep[j] for j in range(k)] for i in range(m)]
 assert all(sum((pull[i][j] for i in range(m)),F(0))==hc[j] for j in range(k))
 assert sum((sum(row,F(0)) for row in pull),F(0))==lower
 assert all(0<=pull[i][j]<=gamma[i][j] for i in range(m) for j in range(k))
 assert all(sum(pull[i],F(0))<=eta[i] for i in range(m))
 assert sum((pull[i][j] for i in range(m) for j in range(k) if shell[i][j]==0),F(0))==0
 # Same actual geometric terminal-only U probe as R445/R446, no history claim.
 U=[(A(F(3,2)**4)/A(F(v['mass']))).log() for v in old['right_receivers']]
 hu=sum((A(hc[j])*U[j] for j in range(k)),arb(0))
 pu=sum((A(sum((pull[i][j] for i in range(m)),F(0)))*U[j] for j in range(k)),arb(0))
 assert (hu-pu).contains(0)
 ref=inp['two_sided_reference']['canonical_soft_prefix_'+str(prefix)]
 oldlo,oldhi=F(ref['matched_lower']),F(ref['matched_upper'])
 improvement_lower=lower-oldhi;improvement_upper=upper-oldlo
 assert improvement_upper>=0
 tab=lambda z:[[str(x) for x in row] for row in z]
 out={'prefix_layers':prefix,'C_input':'2','normalized_column_caps_lower':list(map(str,colcaplo)),
 'normalized_column_caps_upper':list(map(str,colcaphi)),
 'normalized_actual_columns':list(map(str,zeta)),
 'continuous_single_column_matching_lower':str(lower),'continuous_single_column_matching_upper':str(upper),
 'continuous_deficit_lower':str(r-upper),'continuous_deficit_upper':str(r-lower),
 'lower_H_scaled':tab(H),'lower_H_old_marginal_scaled':list(map(str,hr)),
 'old_row_excess_scaled':[str(max(F(0),x-y)) for x,y in zip(hr,eta)],
 'one_column_dual_column':list(map(str,dz)),'one_column_dual_edge':tab(de),
 'exact_lower_primal_dual_value':str(dual),
 'pullback_by_terminal':list(map(str,keep)),'pullback_Gamma_scaled':tab(pull),
 'pullback_old_marginal_scaled':list(map(str,[sum(row,F(0)) for row in pull])),
 'pullback_actual_near_mass':'0','auxiliary_U_probe_Arb':str(hu),'pullback_U_probe_Arb':str(pu),
 'two_sided_matching_reference_lower':str(oldlo),'two_sided_matching_reference_upper':str(oldhi),
 'certified_improvement_over_two_sided_lower':str(improvement_lower),
 'certified_improvement_over_two_sided_upper':str(improvement_upper),
 'original_masscut_not_satisfied':True}
 rows.append(out)
 print('prefix',prefix,'single-column continuous match in',float(lower),float(upper),
       'deficit in',float(r-upper),float(r-lower),'old-row excess',list(map(str,out['old_row_excess_scaled'])),
       'improvement in',float(improvement_lower),float(improvement_upper))
report={'environment':{'executable':sys.executable,'python':platform.python_version(),'flint':flint.__version__,'Arb_bits':ctx.prec},
 'input_dependency':'r447_numeric_input.json','source_certificate_sha256':inp['source_certificate_sha256'],
 'mass_scale_theta_squared':str(scale),'actual_mass_scaled':str(r),
 'raw_sourcewise_scale_theta':old['raw_sourcewise_scale_rho_over_h'],
 'same_actual_old_marginal_scaled':list(map(str,eta)),
 'single_column_formula':'sum_j min(zeta_j, C sum_i psi_ij raw_ij); continuous bounds via whole-block psi lower/upper',
 'cases':rows,'scope':'One real R445 geometry interface only. Original masscut fails; auxiliary old marginal intentionally unconstrained; no full-history or U-bound claim.'}
(ROOT/'r447_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: 3 exact column formulas/primal-dual/pullbacks; no LP, new geometry, or row-constraint assumption.')
