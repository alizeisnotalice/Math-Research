# R447 independent final audit

FINAL PASS（限定范围）：通过撤旧边缘约束的显式列最优计划、同原P的可测RN拉回、精确old-source pooling、仅辅助μfree扩大及同价缺额链。未证明Dfree的整体来源预算、固定覆盖比例、完整U上界或一般根阶弱型闭合。没有必要修复项；以下绑定最终14文件。独立PRE及其pooling追加先于作者新稿阅读，后附保留。

## 1. 原测度和改进的合法性

对固定原ξ，g=dζ/dν可取联合可测版本，k=∫ψbar dμ。显式H=Cψbar min(1,g/(Ck))μν，k=0取零，恰有H₂=min(g,Ck)ν；任意同cap且仅H₂≤ζ计划逐列均受这两个上限，故其缺额Dcol精确最优，无需连续maxflow。H₁可以超过η；原选中部分却是b(ξ,v)P，b=min(1,Ck/g)∈[0,1]，保全部original oldw/source/path/current/early/clock/history。辅助w不冒充原w，也不向其转授资格。当前U只依(ξ,v)，其相应积分在同new-v子边缘下相等，不存在cheapplan上界actualcost的方向错误。

pooled记录(e,A,z,t)使用共同ν_{A,z}；y-dependent新端门留原Γ密度。原new-v测度精确为gtilde ν𝓛，gtilde=∫π_A a0 g_y，不是刷新后验。原a0不依t；即使允许依赖也须保原函数及uniform帽。有限两方向base总2X，X≤AnW；旧来源非概率权无需归一，由positivepart正齐次次可加性得Dpool≤Dcol。b(e,A,z,t,v)乘原记录保其实际y/history，不声称每个y条件边缘不变。

实际读R413:83–85及R434合同，原a_i^e≤B_e，B_u=β、B_v=C_col，ΣB_e=S，适用于a0。去掉仅辅助old-own-low并以a0≤B_e，Tonelli严格给

μtilde≤μfree=B_e 1_{m_w<m_A/K²} I_Aw dw/(h m_A m_w)。

辅助w仍是真实E、完整f匹配质量；原gtilde及其own-low/future门完全不改。μfree(E)≤B_e An/(hq)有限，B_e=0时原需求亦零。新cap的显式列公式可再按同pooled RN乘原P。故Dfree≤Dpool≤Dcol≤Dsoft成立。无需source×history产品AC，也无需让freew拥有原路径。

## 2. 费用与未付项

扩大容量积分先对t用∫1_{f>t}dt=f，正放new-own-low，然后ΣB_e=S，恰为CS/h²∫σ∫ψbar dQ_A。不是对方向数另乘2，也不重复a0或多一份S。R446全域ψbar的Φ价及真实X≤AnW给相同Ω(C)=CSε₀²AnΦ/s²；C=√n时≤Sε₀²√nΦW，无r/τ损失。

当前只是替代原R槽的不同nested分拆。入口正确为64Λ₀Fhat[Sε₀²√nΦW+Dfree]，旧初始/删除/尺度及C433/V433费用保持，不能叠旧near/Hall收据。geometry的同列P±恒等式及源展开保真实权重，负池上价不是其覆盖正池的下界；sourceprobe(10)的capture下界和scalar(12)方向正确，但未证明覆盖原余量比例，不额外记付款。Dfree需求到cap的全局下覆盖仍未证。

## 3. 实际复现与数值限定

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r447_audit_isolated_elc6dkno` 实际运行三脚本：三stdout逐字节一致，numeric生成JSON逐字节一致。未改作者文件。另独立从最小input重算full-f m=R⁴、中心volume、sourcepacket整块捕获、wholeblock Δ上下界与mass-gap失败，并核其来源证书SHA对当前R446原证书一致；这些是输入复核，不计新样本。

mainproof 291 Fraction(17/30/244)、geometry 3条件测度表均只核有限capacity/positivepart/pullback/scalar接口，非native-history。numeric 3 support前缀无LP，Fraction列min及0/1 dual精确；Arb256整块ψ界验证方向正确。constantproduct下H连续lift不要求旧row；column ζ/ν在每block恒定，uppercap逐列给任意连续H上界。下H旧row超额是辅助量，实际bΓ旧row仍≤η，仍全far。所有表质量归一θ²，actual须乘回；旧R446双边参考只用于同场改进区间。

最小input含所需数据，无旧文件运行依赖。n4 masscut明确失败、原high-rank/history未构造，形式source价不直接作用此fixture，不作为完整P非空或全缺额阶证据。资源文件仅记录原实际运行，复现不添加覆盖或模型消费估计。

## 4. SHA256 byte bindings

- `r447_main.md`: `88f01d13c077838a971da7e655962aa24bc10bbaee62002177b4dfa1a61ef345`
- `r447_geometry.md`: `ee8d664b5ac40fe98a842a4c48c6d29cc66131b792458acbabc666ac3de596b3`
- `r447_geometry_check.py`: `e9a91f31361c31f055a7b0e607f065e91f8c1dc1b00422d5bd86d8f54b3dee19`
- `r447_geometry.result.txt`: `30c6022613f8d80cd38c970630640b1d6b9972f4bc5f66ec4848b4995c5b7aea`
- `r447_mainproof.md`: `68fa255f6c0e716d120888049374b1b0ab821ddcb8de49cd3824abece5118196`
- `r447_mainproof_check.py`: `df6e32369d8b29cea3569b5eb9ad72fb6d5f9d20b2c08d34433e3fddae5948fd`
- `r447_mainproof.result.txt`: `b31c9c8944992706656f9176f6f604b836eed2df9a43a8e88ba138db1e7dc3f2`
- `r447_numeric.md`: `5712764c0400b5de924a78414b01006edb4e4e6d127b42404f9e89b3f76da962`
- `r447_numeric.py`: `3d911b5a5185402ff5b4e28fbd8ae89ce0d282216cd2bcdf8b019c28d31f52c0`
- `r447_numeric_input.json`: `5099e22d29b475c68bc67e187e07bc37442d4b125290780c4b283817947a5340`
- `r447_numeric_certificate.json`: `03e71430018f475cb62f4751d3304661b5d05398ffd6539a5b3f7ba31c6cf6ae`
- `r447_numeric_run.txt`: `3e69d55c8911728b001155c72555e67e56d079b8864f6610efbf1b40f72f4a0b`
- `r447_numeric_resources.txt`: `b38c27c61f70cb6332fa585bc2cc90768c7191e30c1dd7e87da98d9bcd2b41db`
- `r447_compute_index.md`: `74dce011a7106bf83d7664df0b786445619136e920941232d148e0723c3501ff`

## 5. 独立 PRE 留档

# R447 independent audit — PRE

PRE ONLY。先独立检查给定命题并读继承R446原定义，未读本轮新作者证明。结论：对支付同一原R的正质量，H₁≤η不是必须；只需H₂≤ζ并使用实际new-v的RN系数拉回。下述one-sided机制合法，但column缺额的来源价仍未证明，不认证全目标。

## 1. 原记录、帽与显式计划

固定同一原ξ=(e,A,y,z,t)，P推前Λ(dξ)Γξ(dw,dv)，η=Γ₁、ζ=Γ₂，质量r。μ、ν仍为真实Lebesgue receiver的ρ_y/h、ρ_z/h帽，保own-low和m_terminal<m_A/K²；原initial-active是whole-terminal帽的必要继承条件。Γ≤μ⊗ν使ζ≪ν，且可测g=dζ/dν满足0≤g≤μ(E)。所有original early/current/clock/history/future限制仍在Γ，不把μ、ν当重新生成的概率。

令ψbar全域取值[0,1]、Δ=0时1，kξ(v)=∫ψbar(w,v)μξ(dw)。有限可测核的积分可测。定义

Hξ(dw,dv)=Cψbar(w,v) min(1,gξ(v)/(Ckξ(v))) μξ(dw)νξ(dv)，

k=0时系数任取0并令H=0，C>0。无须把g/(Ck)解释为概率路径。直接积分旧辅助w得

H₂(dv)=min(g,Ck)ν(dv)≤ζ(dv)。

同时H≤Cψbar μ⊗ν。一般H₁不受η支配，不能声称保留实际old终端边缘；但该旧边缘不是本次拉回的必要约束。零Γ、零ν、零μ行均使gν或相应H为0；若k=0但g>0，该列全部进入缺额，不作非法除零。

## 2. 为什么不丢原来源或history

取bξ(v)=min(g,Ck)/g（g=0时0），则0≤b≤1可测，P_match=bξ(v)P。它是原完整记录的正限制，原oldw及其路径不变，所有源y,z、父A、t、首次删除、时钟、全部历史继续保留。辅助H上的w不是原oldw，不能把ψbar的关系或某条history转授给它。

质量精确为 |P_match|=∫H₂dΛ=∫H dΛ。固定ξ后当前U的逐记录函数仅依new-v，故在其已证绝对可积范围内，∫Urecord dP_match=∫Urecord(v)dH dΛ。该等式并非廉价plan上界原有joint成本；只是同一保留new-v子边缘的恒等式。支付原R质量可直接进入原R槽，也不必先给匹配支的未控signedlog作上界。

R445要求H₁≤η，是为了双边缘partial matching/其Hall问题。此次既不要求辅助计划重现原old marginal，也不把它直接当原history联合律，故移除该约束没有漏掉母账或U所需资格。若今后目标包含old-w相关成本、原joint几何事件、条件路径law或必须保持旧终端边缘的后验，则仅H₂条件不够；不能把本结论外推到那些目标。

## 3. 精确缺额与相对Hall的改进

对任何H≤Cψbar μ⊗ν且H₂≤ζ，逐列质量都≤min(g,Ck)ν。上述显式计划逐列达到此界，因此无需连续max-flow选择定理便有精确最优缺额

D_col(ξ)=∫(gξ−Ckξ)_+ dνξ，
R=|P_match|+∫D_col dΛ。

旧two-marginal soft Hall方案是此one-sided问题的子类，所以D_col≤d_Hall逐ξ成立。也可直接在Hall公式取B=E得到sup_T[ζ(T)−C∫_T k dν]_+=D_col。改进是严格放松一个先前不必要的约束，不是给原未匹配费用重命名后默认已付。

完整column覆盖的准确条件是g≤Ck ν-a.e。足够的可吸收预算为∫(g−Ck)_+dνdΛ≤εX+QεW（或含θR< R的可吸收版本）。Γ≤μν只给g≤μ(E)，本身未给ψ平均k相对g的根价下界；旧sourcewise上容量/总量SX不能自动替代此条件。实际g保ξ全部源及history选择偏差，不得换成来源无关平均或归一后的新后验。

## 4. 来源价与完整账

H仍被同一个R446 canonical容量支配，故不需要H₁≤η也有

|P_match|≤∫Cψbar μνdΛ≤CSε₀² An Φ(An²)W/s²。

C=√n、An≤s²得≤Sε₀²√nΦ(An²)W。来源帽S和clipping一次结算，未额外损失τ、r或union2；原真实X=∫q_A dA≤AnW不变。此替换旧R446匹配收据，不能对同一R再叠原near/Hall收费。

入口只改原64Λ₀FhatR槽为64Λ₀Fhat[Sε₀²√nΦW+∫D_col dΛ]；其余旧费用不变。若另证D_col≤εX+QεW才相应增加64Λ₀FhatεX及64Λ₀FhatQεW；当前未有此估计。不认证整体root目标或任何固定匹配比例。

## 5. 实际本机辅助与停止范围

指定math-research-tools Python/Fraction实际核了一个两态全正kernel接口：μ=ν=(1/2,1/2)，Γ仅old0/new1有1/4，ψ对角1/offdiag1/4。one-sided构造匹配1/4、辅助old1行1/5而原old1行为0；同new-v拉回仍恰为原Γ，双边缘约束仅能匹配1/16。这只是代数说明删旧边缘约束确可扩大可行类，不是原生cube/history实例或几何反例。另核零容量列约定，未扫描参数、不计新增正式样本。

PRE结论：候选显式列匹配成立，原history拉回与原费用范围相容；相比Hall有真正更小的精确缺额。其来源加权D_col预算仍为尚未证明的全局义务。停止等待冻结作者稿和root整合后再FINAL。

## 6. 追加独立 PRE：精确 old-source pooling

此追加仍在作者新稿阅读之前，仅按root精确命题核验。令新base ξ₀=(e,A,z,t)，

Λ₀(dξ₀)=σ(dA)c_A(z)1_{f(z)>t}dzdt/m_A，
ωξ₀(dy)=π_A(dy)a₀ᵉ(A,y,t)。

原a₀若本来不依t则保持其原定义；若允许原有t依赖，必须逐点保留，不能换成另一stage或抽掉该依赖。原Γ_y仍含所有y-dependent current/history/acceptance。原e是有限两方向，故Λ₀总质量=2X（不含方向时X），由∫dt1_{f>t}=f及m_A=f(Q_A)；X≤A_nW保证有限。此2不是新增费用因子，source价格仍保ω内a₀的原逐来源Σ_e上帽S一次。

选择新端共同帽ν_{A,z}=1_{ownlow(z),m_v<m_A/K²}ρ_z/h，与y无关。任何y相关的新端必要门必须留在Γ_y密度内，不可放入一个随后被误称共同ν的帽。如果原证明用更窄ν_y，先正上放到此共同ν，再取真实RN密度g_y即可；不得直接平均不同底测度下的数值密度。

对相同共同ν有精确推前等式：

P_{ξ₀,v}=Λ₀(dξ₀) gtilde_{ξ₀}(v)ν_{A,z}(dv)，
gtilde(v)=∫ω(dy)g_y(v)，
μtilde(dw)=∫ω(dy)μ_{A,y}(dw)，
ktilde(v)=∫ψbar(w,v)μtilde(dw)=∫ω(dy)k_y(v)。

所有核可测且有限，由标准Borel原核、Tonelli及wholeterminal帽给出；没有产品history AC假设。a₀总权不必为1，gtilde也不是新的概率后验。各y上g_y≤μ_y(E)给gtilde≤μtilde(E)。ν共同的限定是该式成立的实质条件。

用 μtilde、共同ν及gtilde按上节显式列公式构造H，得H₂=min(gtilde,Cktilde)ν。取b(ξ₀,v)=min(gtilde,Cktilde)/gtilde（零处0），仍直接乘原完整P。原y及其路径/历史没有换成新来源；在给定ξ₀,v下oldsource的原条件分布也未因乘此共同系数而改变。当前Urecord不依y，故与H相应的new-v积分仍相等；原若有y相关成本则不能用仅此投影冒称全部成本不变。

由于(t)_+的正齐次次可加性，任意有限非概率ω也严格有

(gtilde−Cktilde)_+≤∫ω(dy)(g_y−Ck_y)_+。

因此Dpool≤Dcol（在原对应Λ₀与Λ权下积分），且可能严格改进；无需把ω归一后遗失其总量。可用的exactcolumn条件变成gtilde≤Cktilde，而不是逐y条件。其实际投影gtilde仍包含全部原保留选择偏差，不得换成fullsource平均帽。

capacity总价保持精确等式：

∫Λ₀ C∫ψbar dμtilde dν =∫Λ C∫ψbar dμ_y dν。

故仍为CSε₀²AnΦW/s²，C=√n时≤Sε₀²√nΦW；无额外2、r、τ。原R精确拆为此实际bP的质量加Dpool。母账可将Dcol替为Dpool，旧价只替换不叠加；Dpool本身的全来源价仍未证明。

指定Python/Fraction实际核两组有限非概率权（包含总权5/2）下精确投影、正部不等式与RN拉回质量，得到Dpool=0而Dcol分别1/6、3/8，仅为接口代数审查，不是原生history证书。结论：该pooling是原同测度的精确推前，不是刷新g或history，数学命题通过PRE。停止等待FINAL稿与白名单。
