# 第447轮：撤去辅助旧边缘约束，保原历史的单列交叠容量

2026-10-21。核心一般n^(1/2+o(1))一致弱型上界仍未证明。本轮纠正了上一机制中过强的辅助约束：原历史拉回并不要求辅助旧终端具有原旧边缘。撤去该约束、精确聚合旧来源并扩大辅助容量，可以在不增加来源价格的情况下减小真实未付款余量。没有将这种改善写成一般闭合。

## 1. 同一原始输入与总账

P仍是原完整R433剩余流，R=|P|，包含真实来源、stage、early、first-deletion、原初始active和双路径、当前及future筛选。W=||f||1，σ=q_A dA，X=∫σ，m_A=f(Q_A)=q_AR_A^n，a≤R_A≤b≤2a，q≤q_A≤λ，A_n=1+nlog(b/a)，K=e^{√n}，s=1+√n，h=s/(ε0q)。S=β+C_col。

固定ξ=(e,A,y,z,t)，原推前Λ(dξ)Γξ(dw,dv)，Γξ≤μξ⊗νξ，μ、ν为实际接收中心上的原ρ/h帽。η、ζ为实际旧、新终端边缘，g=dζ/dν≤μ(E)。所有旧来源依赖门都留在Γ中；为聚合旧来源，ν只能含依(A,z)的own-low和严格mass门。

使用R446全域权ψbar=min(1,(α0/Δ)^n)，α0=e^{2/√n}，Δ=2||w−v||∞/max(R_w,R_v)，Δ=0处取1。R446原真实双捕获容量价格为
\[
\int C\bar\psi\,d\mu d\nu d\Lambda\le
 {CS\epsilon_0^2\over s^2}\Phi(A_n^2)X
 \le\Omega(C)W,
\quad\Omega(C)={CS\epsilon_0^2A_n\over s^2}\Phi(A_n^2),
\]
Φ(v)=v（v≤2），Φ(v)=2[1+log(v/2)]（v≥2）。此价只使用原完整质量匹配及实际中心，不是来源密度帽。

## 2. 显式单列计划不需要辅助旧边缘

令kξ(v)=∫ψbar(w,v)μξ(dw)。取
\[
H_\xi(dw,dv)=C\bar\psi(w,v)
 \min\{1,g_\xi(v)/(Ck_\xi(v))\}\,\mu_\xi(dw)\nu_\xi(dv).
\]
Ck=0处取零。此时H≤Cψbar μ⊗ν，且
\[
(H_\xi)_2=\min(g_\xi,Ck_\xi)\nu_\xi\le\zeta_\xi.
\]
任何可行计划的新列质量都不超过这两个上限，因此这是只约束新边缘时的显式最优计划。辅助H第一边缘可以超过η，但这不转移到原流。

定义bξ(v)=min(1,Ckξ(v)/gξ(v))（g=0处取0）。原正部分bP仍保留每一条原历史，质量与H相同，实际旧边缘仍不超过η。原U的逐记录函数log[m_A B_vC(t)/(m_v B_AC(t))]只依ξ,v，所以其相应积分也被保留；不使用“便宜运输上界实际成本”这种错误方向。

因此
\[
R\le\Omega(C)W+D_{\rm col}(C),\qquad
D_{\rm col}(C)=\int(g-Ck)_+\,d\nu d\Lambda
\le D_{\rm soft}(C).
\]
这已经消除了双边Hall切割搜索，但Dcol仍需完整来源预算。

## 3. 精确旧来源聚合及完整父交叠容量

U还与旧来源y无关。记θ=(e,A,z,t)，这里θ只是记录标签而非接受率，令
\[
d\mathcal L(\theta)=\sigma(dA){c_A(z)\over m_A}1_{\{f(z)>t\}}\,dzdt,
\quad
\widetilde g=\int\pi_A(dy)a_0^e(A,y)g_y,
\quad
\widetilde\mu=\int\pi_A(dy)a_0^e(A,y)\mu_y.
\]
ν取共同的z参考帽。原P的新终端精确投影为gtilde ν𝓛，未刷新接受权或来源。正部分的正齐次次可加性给Dpool≤Dcol；相应按(θ,v)的同一乘子拉回，保留原y、路径及历史。

原R413合同给a_i^e≤B_e，B_u=β，B_v=C_col，Σ_eB_e=S；本轮实际复核该原稿及审计，不从名称推测。故
\[
\widetilde\mu\le\mu^{\rm free}_{Ae},\qquad
\mu^{\rm free}_{Ae}(dw)=
 {B_e\over h m_A}\,1_{\{m_w<m_A/K^2\}}
 {I_{Aw}\over m_w}\,dw,
\quad I_{Aw}=f(Q_A\cap Q_w).
\]
这里仅扩大辅助旧接收容量，去掉的是辅助own-low限制。原需求gtilde和原P的所有门保持不变；辅助w仍属于实际E、质量仍为完整f(Q_w)，没有虚构路径资格。

定义真实父交叠列
\[
k^{\rm free}_{Ae}(v)= {B_e\over h m_A}
\int_{m_w<m_A/K^2}\bar\psi(w,v){I_{Aw}\over m_w}\,dw.
\]
再次用显式列计划及原RN拉回，得到本轮最强分拆
\[
\boxed{R\le\Omega(C)W+D_{\rm free}(C),\quad
D_{\rm free}(C)=\int(\widetilde g-Ck^{\rm free})_+\,d\nu_zd\mathcal L,}
\]
\[
D_{\rm free}\le D_{\rm pool}\le D_{\rm col}\le D_{\rm soft}.
\]
扩大后的整个容量仍只有同一个Ω(C)W价格：积分clipping一次，正上放new-own-low，ΣB_e=S，恰回到R444完整父双来源行Q_A。没有增加方向因子、阶段数或新的S。各版本是替代分拆，不能叠加付款。

## 4. 尚未证明的全局几何步骤

剩余问题现在直接是实际需求gtilde与完整父交叠列kfree的比较，而非辅助旧边缘失衡。需要证明
\[
\int(\widetilde g-\sqrt n\,k^{\rm free})_+\,d\nu_zd\mathcal L
\le\varepsilon X+C_\varepsilon\sqrt n\log^A(n+2)W,
\]
或给出可吸收的θR加受控来源费用。现有匹配证明的是容量积分上界，不是需求下的覆盖下界，不能反向使用。

几何附件保留同列正负池的准确抵消；尚未证明负池覆盖实际正池的整体机制。TG/Tloc静态低指标及原接受权仍在原需求中，没有因辅助容量扩大而给新历史赋权。主证明的真实来源距离下界可识别自动覆盖列，但未证明其覆盖原余量的比例，故不另记局部分支付款。

## 5. 母账、验证及结论边界

原入口为
\[
\Lambda_0\{8\lambda HW+2d_{eff}A_{entrance,n}W_\nu/H+64\widehat F R
 +(2E387+64\widehat F C433)X+(2S390+16s+64\widehat F V433)W\},
\]
此处Λ0=128/119；Fhat=(1−32δ−16η)^−1。取C=√n、A_n≤s²，本轮只将R槽替为
\[
64\Lambda_0\widehat F S\epsilon_0^2\sqrt n\,\Phi(A_n^2)W
+64\Lambda_0\widehat F D_{\rm free}(\sqrt n).
\]
原初始、跳跃、删除、尺度及其他X/W费用都不变，总ε吸收未完成。一般上界未闭合。

本轮实际1 Astra high、2 Sol high、1 Sol medium；无独立Luna任务不补人数。使用本机指定Python，291项Fraction主证明接口核验、3组几何代数核验；有限连续中心模型无需新LP，Arb整块界和有理列证书核验single-column最优区间。全soft归一匹配量为[.5581319696,.5581686372]，较R446双边方案有严格改善，但仍有至少.0618313628的归一缺额；真实质量须乘θ²。该模型原质量门失败，不能认证完整原历史，也不能直接套来源价格定理。

精确旧来源pooling的严格改善另有有限代数测试，非新原生模型。所有数值只支持对应接口，不能外推全维。没有新增原文定理引用；沿用64项工具的正测度/费用方向守卫，推导逐式给出。保详细LaTeX源及必要最小复现材料，不编译PDF。无实际模型扣额数据，不猜成本比例。
