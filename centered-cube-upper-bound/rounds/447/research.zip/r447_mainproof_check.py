from fractions import Fraction as F
from itertools import product
counts=[0,0,0]
def check(x,stage):
    assert x
    counts[stage]+=1

def psi(x): return F(1) if x<=1 else 1/x

def evaluate(mu,nu,Gamma,weight,C,stage):
    nr,nc=len(mu),len(nu)
    raw=[[mu[i]*nu[j] for j in range(nc)] for i in range(nr)]
    for i,j in product(range(nr),range(nc)):
        check(0<=Gamma[i][j]<=raw[i][j],stage)
    eta=[sum(row) for row in Gamma]
    zeta=[sum(Gamma[i][j] for i in range(nr)) for j in range(nc)]
    r=sum(zeta)
    g=[zeta[j]/nu[j] if nu[j] else F(0) for j in range(nc)]
    k=[sum(weight[i][j]*mu[i] for i in range(nr)) for j in range(nc)]
    cap=[[C*weight[i][j]*raw[i][j] for j in range(nc)] for i in range(nr)]
    mult=[min(F(1),g[j]/(C*k[j])) if C*k[j] else F(0) for j in range(nc)]
    H=[[mult[j]*cap[i][j] for j in range(nc)] for i in range(nr)]
    b=[min(F(1),C*k[j]/g[j]) if g[j] else F(0) for j in range(nc)]
    pulled=[[b[j]*Gamma[i][j] for j in range(nc)] for i in range(nr)]
    dcol=sum(max(F(0),g[j]-C*k[j])*nu[j] for j in range(nc))
    for j in range(nc):
        check(sum(H[i][j] for i in range(nr))==min(g[j],C*k[j])*nu[j],stage)
        check(sum(H[i][j] for i in range(nr))==sum(pulled[i][j] for i in range(nr)),stage)
    check(sum(map(sum,H))+dcol==r,stage)
    for i,j in product(range(nr),range(nc)):
        check(H[i][j]<=cap[i][j] and pulled[i][j]<=Gamma[i][j],stage)
    test=[F((-1)**j*(j+1),3) for j in range(nc)]
    check(sum(H[i][j]*test[j] for i in range(nr) for j in range(nc))==sum(pulled[i][j]*test[j] for i in range(nr) for j in range(nc)),stage)
    dhall=F(0)
    for Bs in product([0,1],repeat=nr):
        for Ts in product([0,1],repeat=nc):
            dhall=max(dhall,sum(eta[i]*Bs[i] for i in range(nr))+sum(zeta[j]*Ts[j] for j in range(nc))-r-sum(cap[i][j]*Bs[i]*Ts[j] for i in range(nr) for j in range(nc)))
    check(dcol<=dhall,stage)
    M=sum(mu)
    bound=sum(g[j]*max(F(0),1-C*k[j]/M)*nu[j] for j in range(nc)) if M else F(0)
    check(dcol<=bound,stage)
    return r,dcol,dhall

# A full column plan may deliberately violate the old row marginal.
mu=[F(1,2),F(1,2)];nu=[F(1,2),F(1,2)]
Gamma=[[F(1,4),F(0)],[F(0),F(0)]]
wt=[[F(1,8),F(1)],[F(1),F(1)]]
result1=evaluate(mu,nu,Gamma,wt,F(1),0)
check(result1==(F(1,4),F(0),F(7,32)),0)
# Zero rows/columns/capacity and original zero flow.
zeros=[([F(0),F(0)],[F(1)],[[F(0)],[F(0)]],[[F(1)],[F(1)]]),
       ([F(1)],[F(0),F(1)],[[F(0),F(1,2)]],[[F(1),F(0)]]),
       ([F(1)],[F(1)],[[F(0)]],[[F(1)]])]
for args in zeros: evaluate(*args,F(2),1)
# All exact capacities below use finite abstract normalized distance powers.
mu=[F(1,3),F(2,3)];nu=[F(1,4),F(1,2),F(1,4)]
Gamma=[[F(0),F(0),F(1,12)],[F(1,6),F(0),F(0)]]
x=[[F(1,2),F(2),F(6)],[F(7,2),F(2),F(2)]]
results=[]
for scale,C in product([F(1),F(2),F(8)],[F(1),F(2),F(4)]):
    wt=[[psi(scale*v) for v in row] for row in x]
    ans=evaluate(mu,nu,Gamma,wt,C,2)
    results.append((str(scale),str(C),*[str(v) for v in ans]))
# Scalar capture geometry Delta <= 1+2dist(y,v)/Rv.
for rw,rv,dyv in product([F(1),F(3,2),F(2)], [F(1),F(3,2),F(2)], [F(0),F(1,4),F(2)]):
    upper=(rw+2*dyv)/max(rw,rv)
    check(upper<=1+2*dyv/rv,2)
# Pool old-source labels with one common new-terminal reference.
pooled=[]
for weights in [[F(1,2),F(1,2)], [F(1,4),F(3,4)], [F(0),F(2)]]:
    for gs,ks in [([F(1),F(0)],[F(1,8),F(7,8)]),
                  ([F(1,2),F(3,4)],[F(1,8),F(1,4)]),
                  ([F(0),F(0)],[F(1),F(1)])]:
        gp=sum(w*g for w,g in zip(weights,gs)); kp=sum(w*k for w,k in zip(weights,ks))
        dp=max(F(0),gp-kp)
        dc=sum(w*max(F(0),g-k) for w,g,k in zip(weights,gs,ks))
        check(dp<=dc,2)
        bp=min(F(1),kp/gp) if gp else F(0)
        check(sum(w*g*bp for w,g in zip(weights,gs))==min(gp,kp),2)
        if weights==[F(1,2),F(1,2)] and gs==[F(1),F(0)]:
            check((dp,dc)==(F(0),F(7,16)),2)
            pooled=[str(dp),str(dc)]
print('Pooling strict fixture (Dpool,Dcol):',pooled)
print('PASS exact Fraction assertions:',sum(counts),'stages:',counts)
print('Strict row-release fixture (R,Dcol,Dhall):',tuple(map(str,result1)))
print('scale,C,R,Dcol,Dhall:',results)
print('Scope: finite capacity/pullback and scalar geometry only; not a native original-history realization.')
