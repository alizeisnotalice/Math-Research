# R447 单列canonical容量：同场精确比较

只复用R446的最小真实center/source数据与已认证whole-block ψ上下界。指定独立Python实际运行，无LP、扫描或新geometry。n=4、完整f=1于[-4,4]^4、变side的完整质量m=R^4及positive center blocks不变；原masscut仍失败，不声称原完整流非空。

所有下表flow mass和缺额均**除θ²归一**，θ=1/120000000000000；真实质量乘θ²。

## 放松接口与精确column公式

raw reference为μ⊗ν，actual新terminal边缘ζ=gν。只保H₂≤ζ及H≤Cψ μ⊗ν，允许auxiliary H₁超过actual旧边缘η。令

`k(v)=∫ψ(w,v)μ(dw)`，则最大匹配质量恰为

`∫min(g(v),Ck(v))ν(dv)`。

逐column的上界来自两项容量；按ψμ比例分配该column即可达到，k=0处置零。此为有限/测度容量接口，不涉及重赋原history。

同一C=2下，block离散公式为

`Σ_j min(ζ_j, CΣ_i ψ_ij raw_ij)`。

代码用Fraction分别算ψ下／上容量，逐column构造下H，并用“选ζ_j或全部edge cap”0/1 dual严格证最优。没有保留H₁≤η的隐含约束。

## 连续上下桥与结果

实际ψ在center块内变化。whole-block lowercap的constant-density H可连续lift且H₂≤实际ζ；uppercap逐column给任意连续H的上界。由于本场Γ=raw·1_far在每对block上constant，ζ/ν在每个新端block恒定，`min`与这些常数界可直接积分。因此以下为真实连续容量的严格夹界，并非只离散近似。

|support|单列匹配质量区间|单列缺额区间|较R446双边匹配的改善区间|
|--|--|--|--|
|single near|[.32,.32]|[.30,.30]|[0,0]|
|两距离层soft|[.5149958630,.5150266566]|[.1049733434,.1050041370]|[.0007042252,.0007567012]|
|全部soft|[.5581319696,.5581686372]|[.0618313628,.0618680304]|[.0006983512,.0007625752]|

所以取消不必要旧row约束确有有限可验证改善，但此场C=2仍不能覆盖r=.62：全soft缺额至少.0618313628θ²。没有从这一小模型推断原缺额阶数。

## Pullback实际检查

下H采用逐column贪心分配，auxiliary旧row确实超过η：near证书第一row excess为39/200；soft为639314769/2500000000。这是本轮允许的auxiliary放松，不把它说成实际原旧边缘。

令b_j=H₂(j)/ζ_j，零ζ处取0；精确核0≤b≤1及

`Γ_match(i,j)=b_j Γ(i,j)≤Γ(i,j)`。

三例均通过：Γ_match质量=H质量，新terminal column相同，**其实际旧row仍≤η**。原Γ全支持far，Γ_match也全far；near case的auxiliary H全near而其pullback actual near质量为0，二者不混同。

固定parent/source/t后U只依新terminal。沿用真实source cell完全包含于parent和相关新terminal的probe，U_j=log(mA/mvj)；Fraction先核新column相等，Arb核辅助H与pullback的相同U费用。该检查不证明一般原history合法性，但也没有把auxiliary旧row超额转移到actual flow。

## 范围与冻结

本轮改进仅为固定模型的single-column容量比较。原massgate/high-rank未满足，R444真实费定理不对该fixture直接生效，未证明原U付款或整体R433。root独立审核去掉H₁的原接口适用性；本任务仅提交数学容量与pullback证书。

复现文件：`r447_numeric.py`、`r447_numeric_input.json`、`r447_numeric_certificate.json`、`r447_numeric_run.txt`、`r447_numeric_resources.txt`、本报告与`r447_compute_index.md`。输入含R446源证书hash与必要数据，无旧文件运行依赖。冻结停止。
