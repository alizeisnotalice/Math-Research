# R447 — releasing the old marginal: an explicit column-capacity receipt

**Result.** For the same complete original P, only the new-terminal marginal is needed for the matching pullback. Removing the auxiliary old-marginal constraint gives an explicit optimal plan and a deficit no larger than R446's Hall deficit, with exactly the same source price. Exact pooling of the old source and then a certified full-parent auxiliary capacity further reduce that deficit at the same price. A true source-capture lower bound is also recorded. These results do not yet control the complete deficit at root scale.

## 1. Original contract and explicit plan

Use R445 geometry §§1–4 and R446 mainproof §§1–2 without changing any original field. The base ξ=(e,A,y,z,t) has

    dΛ=σ(dA)π_A(dy)a0^e(A,y)c_A(z)/m_A 1{f(z)>t} dz dt.

Here σ=q_A dA, m_A=f(Q_A)=q_A R_A^n, q≤q_A≤λ, a≤R_A≤b≤2a. All masses use full f. The actual pushforward is Λ(dξ)Γξ(dw,dv), with Γξ≤μξ⊗νξ, where the finite actual-center hats are

    μξ(dw)=1{Z_w(y)≤h, m_w<m_A/K²} c_w(y) dw/(h m_w),
    νξ(dv)=1{Z_v(z)≤h, m_v<m_A/K²} c_v(z) dv/(h m_v).

Certified additional single-terminal gates may remain. Γ retains every original current, early, source, clock, stage, deletion and future restriction. Neither raw hat is assigned an independent refreshed history.

Let ζξ=(Γξ)₂ and gξ=dζξ/dνξ. Choose the joint measurable density Fξ=dΓξ/d(μξ⊗νξ), 0≤Fξ≤1. Then gξ(v)=∫Fξ(w,v)μξ(dw) is a measurable version, and

    0≤gξ(v)≤Mξ:=μξ(E).

Set ψbar=min(1,(α0/Δ)^n), Δ=2||w−v||∞/max(R_w,R_v), α0=K^(2/n), with ψbar=1 at Δ=0. For any fixed C>0 define

    kξ(v)=∫ψbar(w,v)μξ(dw),
    τξ(v)=min(1,gξ(v)/(Ckξ(v))) if Ckξ(v)>0, and 0 otherwise,
    Hξ(dw,dv)=τξ(v) Cψbar(w,v) μξ(dw)νξ(dv).             (1)

All functions are jointly measurable by integration of measurable kernels. The hats are finite, so k is finite. Formula (1) gives exactly

    (Hξ)₂(dv)=min(gξ(v),Ckξ(v))νξ(dv)≤ζξ(dv).           (2)

It also gives H≤Cψbar μ⊗ν. No condition on H₁ is asserted or needed. Zero g, zero k and zero fibers are included by these conventions.

This is optimal among all nonnegative plans with capacity Cψbar μ⊗ν and second marginal at most ζ: any such plan has column density at most both g and Ck. Thus the exact missing mass is

    Dcol(C)=∫Λ(dξ)∫(gξ(v)−Ckξ(v))_+ νξ(dv).             (3)

No infinite-dimensional optimization theorem is needed for this construction.

## 2. Pullback, original history, and the unchanged source price

Define bξ(v)=min(1,Ckξ(v)/gξ(v)) when gξ(v)>0, and b=0 otherwise. Then

    dPcol=bξ(v)dP,       R=|Pcol|+Dcol(C).               (4)

Every original record and its history remains in Pcol. Its new-terminal pushforward is exactly ΛH₂. Therefore, for any integrable signed integrand ℓξ(v),

    ∫ℓξ(v)dPcol = ∫Λ(dξ)∫ℓξ(v)dHξ(w,v).               (5)

This includes the original signed U integrand. The auxiliary old terminal in H need not have its actual old marginal or any original pair history. It is only an analysis variable; (5) never asserts new histories or bounds the original cost by a cheaper transport cost. The actual unmatched original flow is (1−b)P.

R446's full-support layer-cake estimate is applicable to this same capacity:

    ∫Λ∫ψbar dμdν ≤ S ε0² Φ(An²) Xq/s²,
    Φ(v)=v (v≤2),  2[1+log(v/2)] (v≥2),
    An=1+n log(b/a), s=1+sqrt(n), h=s/(ε0 q).

Consequently

    |Pcol|≤C S ε0² Φ(An²) Xq/s²
           ≤Ωcol(C)W,
    Ωcol(C)=C S ε0² An Φ(An²)/s².                      (6)

The last inequality uses the actual matching identity Xq≤An W. At C=sqrt(n),

    |Pcol|≤S ε0² sqrt(n) Φ(An²) W.                      (7)

The source price is unchanged from R446. Equations (6)'s X and W prices are alternatives, not cumulative charges. Any old two-marginal matching plan is feasible for the relaxed column problem; hence

    Dcol(C)≤Dsoft(C).                                   (8)

Its achieved mass can be strictly larger. This receipt replaces the R446 matching receipt on the same original R slot. It does not add another fee for a part already removed. In the stated mother ledger the R slot becomes

    64 Λ0 Fhat Ωcol(C)W + 64 Λ0 Fhat Dcol(C),             (9)

with every earlier fee unchanged.

## 3. Pooling the old source and enlarging only the auxiliary capacity

The signed original integrand is

    ell=log[m_A B_{v,C(z)}(t)/(m_v B_{A,C(z)}(t))].

It is independent of y, not just of w. Hence retain theta=(e,A,z,t), and use

    dΛ0(theta)=σ(dA)c_A(z)/m_A 1{f(z)>t} dz dt.

Use a common ν_z with its z-own-low and strict mass gates. Any optional old-y-dependent terminal restriction must remain in Γ's actual density, not in this common reference ν_z. Define the exact projections

    gtilde(theta,v)=∫π_A(dy)a0^e(A,y) g_(theta,y)(v),
    μtilde_theta(dw)=∫π_A(dy)a0^e(A,y) μ_(theta,y)(dw),
    ktilde(theta,v)=∫ψbar(w,v) μtilde_theta(dw).

The projected **original** new-terminal measure is gtilde ν_z dΛ0. The same explicit formula (1), with μtilde and gtilde, yields a positive original pullback using b(theta,v)=min(1,Cktilde/gtilde). This retains all original y and history labels in P; it merely assigns them the same multiplier at fixed theta,v. It preserves the corresponding signed integral because ell has this same dependence. Positive homogeneity and convexity of the positive part give

    Dpool(C):=∫(gtilde−Cktilde)_+ dν_z dΛ0 ≤ Dcol(C).    (P1)

No normalization of the old-source weight is needed. R445's actual a0^e(A,y) has no t dependence. More generally any such dependence must be retained under the integral and the original uniform endpoint bound must still be verified; it cannot be silently replaced by a t-independent weight.

There is a further legitimate enlargement. The audited original directional contract is 0≤a_i^e≤B_e, with B_u=β and B_v=C_col, and Σ_e B_e=S: see `/tmp/r413_main.md` lines 83–85 and `/tmp/r434_contract.md` line 7. In particular this applies to a0. Therefore

    μtilde_theta ≤ μfree_Ae,
    μfree_Ae(dw)= B_e 1{m_w<m_A/K²} I_Aw dw/(h m_A m_w),
    I_Aw=f(Q_A∩Q_w).                                    (P2)

Only the **auxiliary** old-terminal measure loses the own-low gate here. The projected demand gtilde and the original P keep their own-low and all other history gates. Since H has no old-marginal requirement, it may use the larger capacity Cψbar μfree_Ae⊗ν_z. Set

    kfree_Ae(v)=B_e/(h m_A)∫_{m_w<m_A/K²}ψbar(w,v)I_Aw/m_w dw.

The explicit multiplier min(1,gtilde/(Ckfree)) constructs H; the original pullback is min(1,Ckfree/gtilde). Thus

    Dfree(C)=∫(gtilde−Ckfree)_+ dν_z dΛ0
             ≤Dpool(C)≤Dcol(C)≤Dsoft(C).                (P3)

Zero B_e implies both original demand and capacity vanish. Other zero conventions remain those of §1. No terminal in μfree is declared an original path endpoint.

The source price is still exactly (6), not a new factor S. Indeed, integrate clipping t once, drop the new-terminal own-low gate positively, and sum B_e=S. The resulting parent row is precisely the full posterior raw Q_A of R444:

    ∫Λ0∫ Cψbar dμfree dν_z
       ≤ CS/h² ∫σ(dA)∫ψbar dQ_A
       ≤ CS ε0² Φ(An²) Xq/s² ≤ Ωcol(C)W.                (P4)

Consequently the strongest proved receipt here is R≤Ωcol(C)W+Dfree(C). Replace Dcol by Dfree in the mother-slot formula (9); these are nested alternatives, not additive payments.

The remaining comparison is now a genuine parent-overlap column problem, not an old-source balance condition: one must control the positive excess of the exact original projected demand gtilde over C times kfree in (P3). Matching controls the integrated capacity from above, but does not supply this demand-to-capacity lower coverage. No complete budget for Dfree is proved.

## 4. Actual-source probe: a geometric lower bound and its limitation

There is a useful capture-based estimate that does not use any density assumption. On the support of μξ, w captures the fixed old source y. Hence

    Δ(w,v)≤(R_w+2||y−v||∞)/max(R_w,R_v)
           ≤1+2||y−v||∞/R_v.

Writing

    d_y(v)=min(1,[α0/(1+2||y−v||∞/R_v)]^n),

we obtain the **pointwise lower** column-capacity bound

    kξ(v)≥Mξ d_y(v).                                    (10)

Additional positive masks in μ do not invalidate (10). For C≥1, every column with

    1+2||y−v||∞/R_v ≤ α0 C^(1/n)                        (11)

is completely matched: Ck≥M≥g. This is a real source-to-terminal geometric condition, not an assumed correlation or a source-volume estimate. It has not been shown to cover a fixed fraction of the current complete residual; it is not given an additional standalone source charge here.

For Mξ>0 set aξ(v)=gξ(v)/Mξ and dξ(v)=kξ(v)/Mξ. These are an actual retained-acceptance fraction and a soft-distance average under the original old-source hat μξ/Mξ, respectively. This normalization is solely analytical and generates no new path. Then

    Dcol(C)=∫Λ∫ Mξ(aξ−Cdξ)_+ dνξ
       ≤∫Λ∫ gξ(1−Cdξ)_+ dνξ
       ≤∫Λ∫ gξ(1−C d_y(v))_+ dνξ.                     (12)

The scalar inequality follows from 0≤a≤1: (a−x)_+≤a(1−x)_+. Zero M contributes zero. The original source dependence and all marks in g remain in (12).

The decisive missing comparison is now specific. Actual matching and the R444 geometry pay the **upper integral** ∫Λ∫Mξdξ dνξ. They do not give a lower bound for dξ relative to the retained fraction aξ on those columns with large accepted mass. Neither g≤M nor the local mass identities m_w=f(Q_w) supply that lower comparison. The source/parent/current weights cannot be discarded to replace g by a fresh posterior. Thus no estimate of the form Dcol≤epsilon Xq+Cepsilon sqrt(n)polylog(n+2)W has been proved. Equations (10)–(12) identify a measurable joint-source comparison to investigate, rather than claiming that the explicit deficit formula itself is a paid bound.

This differs substantively from enforcing old-marginal balance: no old-marginal cut remains. Any remaining obstruction is a shortage of soft raw capacity in an individual retained **new** column, integrated with the true source/history weights.

## 5. Actual local checks and scope

`r447_mainproof_check.py` was actually run with the designated local Python. Its stdout is `r447_mainproof.result.txt`: **291 exact Fraction assertions** in stages 17,30,244. These verify explicit column optimality, original pullback, signed new-terminal-only cost equality, zero rows/columns/capacity, all-subsets two-marginal cut comparison, inequality (12), and the scalar capture bound underlying (10).

A finite test has R=1/4, Dcol=0 and old Dsoft=7/32, demonstrating strict benefit from releasing the old marginal. A pooling test has Dpool=0 and Dcol=7/16, with the original-source weights and demand retained exactly. Another test at its doubled distance scale has Dcol=0 and Dsoft=1/28; larger scales retain positive Dcol. These are finite capacity identities and scalar geometry checks, not realizations of the complete native history, q-band, strict K² gap or cube field. The actual geometric proof is (10), and the original source price is the analytic estimate (6). No general closure follows from the tests.
