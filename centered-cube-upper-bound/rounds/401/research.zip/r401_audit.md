# R401 independent audit — FINAL PASS

FINAL PASS for the all-selector coordinate-sensitive pair-tail lemma, the exact bilateral-moment expansion and its conditional connection to R400. No root-order budget for the receiver-pair moment is certified, and no new payment is added to the original ledger. Only this audit file was edited.

Only this file is edited. The following argument was completed before reading any new R401 author proof. It screens the proposed two-source native-center lemma; it does not certify an exclusive-moment or general core budget.

## Exact assertion and independent proof

Let n>=1, 0<q_-<=q_a<=lambda, actual measurable selected cube Q_a with side R_a, m_a=q_a R_a^n, and M>0. Integrate actual receiver-center Lebesgue da over any measurable allowed E. Fix finite source positions y,z in R^n; write d_j=|y_j-z_j| and R0=(M/q_-)^(1/n). Then the proposed inequality is valid:

    integral_E q_a c_a(y)c_a(z)1_{m_a>M} da/m_a^2
      <= [2lambda/(q_-M)] integral_0^1
                     product_j(1-(d_j/R0)t^(1/n))_+ dt.

To prove it, retain the true mass cutoff and use the positive identity

    1_{m_a>M}/m_a^2
      =integral_M^infinity 2r^(-3)1_{M<m_a<=r} dr.

The use of <=r or <r at the integration endpoint does not affect this Lebesgue r integral, even when the actual mass selector has atoms. Tonelli and q_a<=lambda therefore give the upper bound

    2lambda integral_M^infinity r^(-3)
       |{a in E: c_a(y)c_a(z)=1, M<m_a<=r}| dr.

If m_a<=r, actual matching implies R_a<=(r/q_-)^(1/n). Every center capturing both fixed sources consequently belongs to the intersection of two center cubes of that enlarged common side. Its volume is exactly

    V(r)=product_j((r/q_-)^(1/n)-d_j)_+.

This is an outer bound on the set of actual selected centers. It does not integrate a chosen radius as an independent parameter, nor bound the source density or assume coordinate independence of f. Enlarging the true center set to this intersection and retaining positivity gives

    2lambda integral_M^infinity r^(-3)V(r) dr.

Factor V(r)=(r/q_-)product_j(1-d_j(q_-/r)^(1/n))_+. The substitution t=M/r now yields the displayed claim with the factor 2lambda/(q_-M) and t^(1/n). In particular no factor n is lost: it is avoided by using the mass variable r and t=M/r; in the equivalent radius variable x=t^(1/n), dt=n x^(n-1)dx.

All quantities are measurable under the frozen original receiver field. The finite right side, bounded by 2lambda/(q_-M), proves finiteness without any new integrability of f or source-product density. Points off E are not assigned a selector, and no new receiver gets old clock/history qualifications. If E is empty the integral is zero. No positive source mass assumption is needed for this purely geometric fixed-source lemma.

## Strength and exact limits of the conclusion

For y=z the integral factor is exactly 1 and the bound reduces to the R399 native squared-mass tail. For y!=z that factor lies strictly between zero and one for finite d_j; hence it is a strict improvement of that universal numerical envelope at each pair of distinct fixed source positions. It is the exact integral of this particular enlarged positive envelope, NOT an identity for the actual selected-center integral or a proof of optimality under a shared full-f field. Finite original upper-radius constraints or absent actual captures can make the left side zero while the displayed envelope remains positive.

Thus arbitrary actual selector masses, strict mass cutoff atoms and all source positions are covered. This lemma alone does not establish that integrating it against the current two-source switching law gives a root-order bound for either exclusive high-rank remainder. Those labels, their weights and any future proposed budget require a separate audit. No R399/R400 paid fraction or original negative square is spent a second time.

## Actual bounded local arithmetic

Before reading the new proof, reviewer actually executed 45 Fraction checks: 15 exact polynomial expansions of the envelope in dimensions 1 through 5, including distances larger than R0, and 30 constant-radius actual-center comparisons. For the expansions, x=t^(1/n) is integrated exactly as n sum_k c_k x_max^(n+k)/(n+k), x_max=min(1,R0/max d_j). The identical positive mass-layer integral equals twice that value in the normalization q_-=lambda=M=1. All comparisons passed. The fixed-radius comparisons can be realized with compact uniform f on a sufficiently large cube and capture-center regions; they do not implement the original core, historical gates or a positive surplus source. No separate test file was saved, and these reviewer checks are not added to future author/parent experiment counts.

Independent statement screen: PASS. The final author and report review below supersedes the preliminary waiting status.


## Final review of the actual bilateral interface

The additional interface was independently screened before reading the author proof. On positive external residual set a=Z_u(y)/h>2, b=Z_u(z)/h>L; on positive small-end residual set a=Z_v(y)/h>2-epsilon0, b=Z_v(z)/h>L-epsilon0. In both cases c=C/h is in [0,1), epsilon0<=1/2 and L>=4 ensure the lower constants A,B satisfy AB>=A+B. The exact scalar identity

    (A-c)(B-c)-AB(1-c)=c(AB-A-B+c)>=0

and the monotonicity from a>=A,b>=B give the claimed bound by the actual exclusive product. At c>=1 the soft residual is zero; the exclusive product remains nonnegative. Consequently, sourcewise beta/C_col capacities and the globally fixed sum b_i<=1 give

    R400 <= [beta/(2L)+C_col/((2-epsilon0)(L-epsilon0))] J_ex/h^2.

The two endpoint bills are distinct actual terms with their original source/time/history labels. This is an unpaid-moment interface, not a new absorption receipt. If a dimension-uniform J_ex<=C n Xq/q_-^2 is later proved, its stated conditional consequence follows from h=(1+sqrt(n))/(epsilon0 q_-). Increasing L retains the existing P_L source price; it is not a free change of a frozen ledger or proof of that missing moment bound.

## Author proof and exact receiver-pair expansion

Read the complete frozen r401_geometry.md. Its layer-cake proof and coordinate factor agree with the independent screen. The positivity/support/monotonicity statements for F_n and split exponential estimate (6) are valid, including theta=0,1. The exact equal-coordinate beta-integral value 1/binom(2n,n) and its a>=1 scaling are analytic identities for the envelope, not fits or actual-field sharpness claims.

Expanding the two exclusive occupations gives the nonnegative source product

    c_w(y)(1-c_t(y)) c_t(z)(1-c_w(z)),

with both strict far gates equivalent to m_a>K max(m_w,m_t). Formula (8) is therefore exact. Its intersection-mass expression is (I_aw-I_awt)(I_at-I_awt)/m_a^2, not the already-paid common square. Apply the proved pair tail at M_wt=K max(m_w,m_t), and then cancel the true mu(dw),mu(dt) masses against their full posterior normalizations. This gives precisely formula (9), with prefactor 2lambda/q_-, denominator M_wt, actual dw dt and the full pi_w tensor pi_t source law. The necessary cutoff ||y-z||infinity<=b is valid for any original cube capturing both and can be retained before taking the upper bound. No missing K, q or receiver-mass factor was found.

Formula (10) is a sufficient unpaid receiver-pair budget of exactly the units and magnitude needed for J_ex<=C n Xq/q_-^2. None of the proved decay estimates asserts it. Source posteriors can concentrate, and neither a coordinate envelope nor its small equal-coordinate values authorize dropping complete source weights or repeated pair usage. The author correctly retains this gap and all of R400.

## Auxiliary potential checkpoint

Read frozen r401_aux.md. Its r_i is a positive source-incidence restriction of the actual incoming endpoint occupancy, hence r_i<=D_i. Nested stage restrictions give decreasing r_i, while D_i decreases and the multiplier (1-s/D_i)_+ increases with D_i. Thus e_i is decreasing, and e_i<=(D_i-s)_+. Finite summation-by-parts identities (4),(5) and the two nonnegative losses (6) are correct. The common full-source versions can be chosen simultaneously across countably many stages.

Under the inherited clearing and diverging density thresholds, the positive limiting argument yields initial tail potential minus the positive drop sum. Finiteness follows from the bound by integral fD0=2G0, not an unstated LlogL assumption. The vanished terminal term does not pay the initial tail or supply a new dissipation lower bound. The author correctly identifies this as a marked restriction of earlier potential accounting rather than independent credit. The nine author-only scalar checks were reviewed as reported; this reviewer did not claim a rerun of an absent separate auxiliary script.

## Actual code execution and evidence scope

Reviewer read and actually reran r401_pairtail_check.py, exit 0:

    PASS initial64+boundary32+expanded84 = 180
    PASS bilateral kernel1323 + soft rank multiplier60 = 1383.

The 180 cases evaluate positive-part distance truncations, exact coordinate polynomials, support, diagonal/equal-coordinate limits and monotonicity through n=64. They do not construct a native mass-selector atom CDF; mass-atom safety is proved by the positive layer cake. The 1323 cases check a finite posterior Boolean exclusive-source identity, not coordinate independence of f; the 60 cases check the scalar interface. All arithmetic is Fraction. The conditional-posterior kernel uses the same full source law and its exclusion factors correctly.

Reviewer also read and actually reran r401_geometry_check.py, exit 0:

    PASS soft_bilateral90 + native_pair_centers108 = 198.

The latter cases are genuine constant-radius continuous-center comparisons, with compact uniform matched source on a sufficiently large finite box and q_-=lambda=1, M=1. The actual center-intersection volume is evaluated exactly in dimensions 1-6. They are not complete original positive-surplus/high-history core examples, and some capture intersections may be empty. The scalar boundary epsilon0=0 is a harmless diagnostic enlargement, not a changed theorem assumption.

Thus the two frozen scripts contain 1761 Fraction checks in total; parent and reviewer reruns are not additional independent parameter sets. The earlier 45 reviewer pre-screen checks are separate, not added to that author/parent total. No new MATLAB execution or numerical evidence for the missing full receiver-pair budget is asserted.

## Final report and unchanged ledger

Read final main/readme after their execution-record update. Mathematical statements, exact constants, conditional language and numeric scopes agree with the reviewed proof. The R400 entrance keeps 64R400 and 64zeta_n Xq inside the original Lambda factor, together with all earlier source/outer fees. No conditional J_ex bound is inserted, no new Xq or W payment is entered, and low-dimensional slot substitution remains the earlier alternative. The original negative square and positive common-past receipts are not deducted again. The general root-order target is expressly still open.

Historical full reductions remain inherited rather than reaudited wholesale in this round. The new all-selector geometric upper tool and valid conditional interface pass; a general budget for its right-hand receiver-pair integral does not follow from this audit.

## Frozen byte bindings

SHA-256 binds the exact reviewed final files. Later edits require an updated audit.

- `/tmp/r401_main.md`: `da4bef0de44b2aff98f44fabff572ce1bbd3aae46827621c681981e3402500a7`
- `/tmp/r401_readme.md`: `9a838f4097a6cb633dfbabcdb31800fe34f16571759f250b9256b1cb5a88614a`
- `/tmp/r401_geometry.md`: `ea28d2fa8acb65c03f7d9cc38748724c6e054d1ceb2de2a09074e0dd03d471b0`
- `/tmp/r401_geometry_check.py`: `eb90175ffe4c0ac7940ec189501fd2736070605c4f38e8fac9b6a87fa6cc7e07`
- `/tmp/r401_geometry.result.txt`: `6bf2addef942e3d68eabaf29565fcf11dd5e58fe2e947fde7cd88558478e17a7`
- `/tmp/r401_aux.md`: `e74b35bfea13168c97b99b53599414627e7d8fa6c9b4452825ab953f43eadd3e`
- `/tmp/r401_pairtail_check.py`: `8231ef439ead899110fb6767402f89e0f42a6fd8a141e624e8482bb55aba8803`
- `/tmp/r401_pairtail.result.txt`: `fb45a2d7944fc8fdeabffd5fc631e84b643ba2f2e620e3acde67be29ce88fc39`


FINAL PASS within the stated scope. No new root-order payment or general closure is certified. Freeze this audit and stop; no additional numerical search or proof expansion was undertaken.
