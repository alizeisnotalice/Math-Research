# R401 — A coordinate-sensitive native pair tail and the remaining bilateral budget

**Outcome.** A stronger all-selector geometric pair-tail inequality is proved below and inserted into the actual two-sided exclusive moment. No root-order price for that remaining receiver-pair integral is proved, so no additional R400 payment or absorption is entered. This note pursues only this bilateral route.

## 1. Precise candidate and its relation to the actual bill

Keep all R398–400 data and stage marks. For any actual endpoint a define

 Z_a(y)=∫c_w(y)1_{m_w<m_a/K}μ(dw),
 C_a(y,z)=∫c_w(y)c_w(z)1_{m_w<m_a/K}μ(dw),
 E_a(y,z)=[Z_a(y)−C_a(y,z)][Z_a(z)−C_a(y,z)],
 J_ex=∫σ(da) E_(π_a⊗π_a) E_a(y,z).                      (1)

This E_a is an exclusive-pair product and is distinct from R390's normalization E_uv. It contains both strict far-mass gates, rather than a single exclusive-source marginal.

The screened new budget was

                 J_ex ≤ C n X_q/q_-²,                  (2)

with a dimension-independent C (allowing the frozen q-band ratio). This is a stronger geometric moment statement, not yet proved. Its relevance to the actual marked remainder can be made exact: if L≥4 and ε_0≤1/2, then

 R_400 ≤ [β/(2L)+C_col/((2−ε_0)(L−ε_0))] J_ex/h².       (3)

To prove (3), retain the original stage kernel ℓ_i(u,y,dv) or k_i(v,y), and the original b_i(z). On the external remainder the original rank conditions give Z_u(y)>2h, Z_u(z)>Lh. On the small-end remainder, the actual closed mass-window estimate T_v−Z_v≤ε_0h gives

 Z_v(y)>(2−ε_0)h,  Z_v(z)>(L−ε_0)h.

Set c=C_a(y,z)/h. For c<1 and numbers A,B satisfying A+B≤AB,

 (A−c)(B−c)−AB(1−c)=c(AB−A−B)+c²≥0.                   (4)

Apply this with (A,B)=(2,L) at the external end and (2−ε_0,L−ε_0) at the small end. Both satisfy the condition for the stated L and ε_0. For c≥1 the actual factor (1−c)_+ is zero. Thus the actual soft complements in R400 are bounded by E_a/(ABh²), on their original rank supports. Only after this step use the proved sourcewise bounds ℓ_i(E)≤β and k_i≤C_col, and sum ∑b_i(z)≤1. The result is (3).

Consequently (2), if proved, would give a small multiple of X_q by choosing L in terms of the desired absorption and the frozen constants, since n/(q_-²h²)=ε_0² n/(1+√n)²≤ε_0². The existing R398 low-rank price remains proportional to LhW. But (3) by itself is not a new payment. The available pointwise estimate only gives J_ex≤J_max²X_q, generally of order n²X_q/q_-², which does not supply (2). Neither of the two original rank conditions has been silently discarded before using it.

## 2. A strictly stronger native center pair-tail lemma

For two fixed source points y,z let d_j=|y_j−z_j|, and let M>0. Define

 R_0=(M/q_-)^(1/n),
 F_n(a)=n∫_0^1 x^(n−1)∏_(j=1)^n(1−a_jx)_+ dx,
 a_j=d_j/R_0.

For every actual measurable selected-radius field with the q-band,

 ∫_E q_v c_v(y)c_v(z)1_{m_v>M}dv/m_v²
                   ≤ [2λ/(q_-M)] F_n(d/R_0).            (5)

Proof. Use the exact positive layer cake on the actual mass, not an independent integration of the selector radius:

 1_{m_v>M}/m_v²=∫_M^∞2r^(-3)1_{M<m_v≤r}dr.

On m_v≤r, matching implies R_v≤(r/q_-)^(1/n). Centers of cubes capturing both y and z therefore belong to the intersection of two center boxes of this side length. Its exact volume is

                 V_r=∏_j((r/q_-)^(1/n)−d_j)_+.

Bounding q_v by λ and enlarging to that actual center sublevel envelope gives

 left side of (5) ≤2λ∫_M^∞r^(-3)V_r dr.

The change t=M/r, then x=t^(1/n), evaluates this last envelope exactly as the right side of (5). The envelope evaluation is exact; equality with the original selected-field integral and sharpness are not claimed. Strict mass cuts and arbitrary mass atoms require no correction: the layer variable is integrated against dr, and all exchanges are positive Tonelli.

The factor F_n is measurable, coordinatewise decreasing, and satisfies

 0<F_n(a)≤min{1,a_max^(−n)}

for finite nonnegative a, with the second term omitted when a_max=0. For every θ∈[0,1],

 F_n(a)≤θ^n+(1−θ^n)exp(−θ∑_j a_j).                     (6)

Indeed split the integral at θ and use (1−r)_+≤e^(−r). The support bound gives the a_max estimate. If all a_j=1, the beta integral gives the exact value

                  F_n(1,…,1)=1/binom(2n,n).             (7)

More generally, if all a_j=a≥1, substitute ax to obtain a^(−n)/binom(2n,n). If d=0 then F_n=1 and (5) recovers the R399–400 single-source squared tail. For any nonzero d the envelope factor is strictly below one. No conclusion about arbitrary f-mass of separated or boundary sources is inferred.

## 3. Insertion into the bilateral receiver integral

Expanding both exclusive factors in (1), and keeping both original source points, gives

 J_ex=∫μ(dw)μ(dt)∫f(y)f(z)c_w(y)c_t(z)
        (1−c_t(y))(1−c_w(z))
        [∫q_a c_a(y)c_a(z)1_{m_a>K max(m_w,m_t)}da/m_a²]
        dy dz.                                         (8)

The products before the inner brackets are nonnegative. In particular w=t cannot contribute; no artificial ordering or disjoint partition of receiver sets was assumed. This is the receiver-pair form of the exclusive intersection product, but the following estimate keeps its native joint center geometry.

Set

 M_wt=K max(m_w,m_t),
 R_wt=(M_wt/q_-)^(1/n).

Any actual a capturing y,z has ||y−z||_∞≤b. Applying (5) in (8), retaining this necessary source separation cutoff, and converting μ(dw)f(y)c_w(y)dy into dw π_w(dy), yields

 J_ex ≤ (2λ/q_-)∫_E dw∫_E dt E_(π_w⊗π_t)
   [ (1−c_t(y))(1−c_w(z))1_{||y−z||_∞≤b}
      ·F_n(|y−z|/R_wt)/M_wt ].                          (9)

Both receiver masses are cancelled against their actual full-f posterior normalizations in this equation. The remaining denominator M_wt and the complete coordinate product are retained. No W² replacement, source density cap, new history for w,t, or independent-coordinate hypothesis has been used. Arbitrary concentration of f is allowed.

Formula (9) is a new general geometric upper estimate, but its right side is still unpaid. To obtain the candidate (2), it would suffice to prove that the actual receiver-pair integral in (9), without its 2λ/q_- prefactor, is at most

                        C n X_q/(2λq_-).                (10)

This is the specific unresolved step. The factor F_n strongly suppresses some multicoordinate source separations. It does not by itself control how the two complete posteriors concentrate on small-separation points, nor the repeated use of such pairs by actual w,t. Dropping F_n and integrating a free receiver variable gives no certified n-order bound. Conversely, imposing a source density cap to exploit coordinate volume would change the problem. The same issue prevents treating the exponential values in (7) as a general price.

Thus the gain in (5) is an all-class geometric tool; (9) connects it to the two-sided actual remainder route. Neither (5), (9), nor the conditional implication (2)⇒(3) is counted as a new root-order receipt. The frozen R400 ledger, its η_tot coefficient and its entire R_400 complement remain unchanged.

## 4. Executed checks and boundaries

I actually ran the parent's `/tmp/r401_pairtail_check.py`:

    PASS {'initial': 64, 'boundary': 32, 'expanded': 84} total 180

This exact Fraction script expands the coordinate polynomial, checks positivity, support bounds and coordinate monotonicity, and verifies (7) and its equal-a extension through n=64. Its exact polynomial integration is over the native center-envelope variable. It does not realize all original core marks or prove (10).

I also wrote and ran `/tmp/r401_geometry_check.py`:

    PASS {'soft_bilateral': 90, 'native_pair_centers': 108} total 198

The first part checks (4) with the actual two choices of A,B, including c=1 and nearly saturated c. The second part uses matched, continuous-center cube fields with f=1 on a sufficiently large finite box, fixed side R>1, q_-=λ=1 and M=1. It evaluates their actual center intersection volume exactly and compares the resulting squared-mass tail to (5), in dimensions 1–6 with rational coordinate separations. These are native Lebesgue center integrals, but not complete original high-rank or history examples. All arithmetic is Fraction; no floating-point fitting or density assumption is used.

The parent's separate finite exclusive-kernel checks are not counted as executions by this author. The mathematical contribution here is (5) with its exact coordinate attenuation and the legitimate insertion (9), not the check totals. No further route is opened after this bounded result.
