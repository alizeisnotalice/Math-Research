from fractions import Fraction as F
from itertools import product

def attenuation(a):
    n=len(a)
    upper=min(F(1),1/max(a)) if max(a)>0 else F(1)
    coeff=[F(1)]
    for value in a:
        out=[F(0)]*(len(coeff)+1)
        for j,c in enumerate(coeff):
            out[j]+=c
            out[j+1]-=value*c
        coeff=out
    return n*sum(c*upper**(n+j)/F(n+j) for j,c in enumerate(coeff))

counts={'soft_bilateral':0,'native_pair_centers':0}
for eps,L,c in product([F(0),F(1,4),F(1,2)], [F(4),F(8),F(16)],
                       [F(0),F(1,8),F(1,2),F(999,1000),F(1)]):
    for a,b in [(F(2),L),(2-eps,L-eps)]:
        assert a*b>=a+b
        assert (a-c)*(b-c)>=a*b*(1-c)
        assert 1-c<=(a-c)*(b-c)/(a*b)
        counts['soft_bilateral']+=1

# Native continuous-center fields, fixed R, matched f=1 on a sufficiently
# large finite box. The center intersection volume is evaluated exactly.
# q_-=lambda=1, M=1; R>1 ensures the strict mass tail is live.
for n,seed,R in product(range(1,7),range(1,7),[F(5,4),F(3,2),F(2)]):
    d=[F((seed*(j+2)+j*j)%9,4) for j in range(n)]
    volume=F(1)
    for dj in d: volume*=max(F(0),R-dj)
    actual=volume/R**(2*n)
    upper=2*attenuation(d)
    assert 0<=actual<=upper
    if any(d): assert upper<2
    counts['native_pair_centers']+=1
print('PASS',counts,'total',sum(counts.values()))
