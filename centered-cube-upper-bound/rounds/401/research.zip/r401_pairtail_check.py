from fractions import Fraction as F
from math import comb
from itertools import product

def kernel(a):
 n=len(a);upper=min(F(1),1/max(a)) if max(a)>0 else F(1)
 p=[F(1)]
 for v in a:
  out=[F(0)]*(len(p)+1)
  for k,c in enumerate(p):out[k]+=c;out[k+1]-=v*c
  p=out
 return n*sum(c*upper**(n+k)/F(n+k) for k,c in enumerate(p))
counts={'initial':0,'boundary':0,'expanded':0}
for a in product([F(0),F(1,2),F(1),F(3,2)],repeat=3):
 value=kernel(a);upper=min(F(1),1/max(a)**3) if max(a)>0 else F(1)
 assert 0<value<=upper
 counts['initial']+=1
for n in [1,2,3,4,8,16,32,64]:
 assert kernel([F(0)]*n)==1
 assert kernel([F(1)]*n)==F(1,comb(2*n,n))
 for a in [F(1,2),F(1),F(3,2),F(2)]:
  value=kernel([a]*n)
  assert 0<value<=min(F(1),a**(-n))
  if a>=1:assert value==F(1,comb(2*n,n))*a**(-n)
  counts['boundary']+=1
for n,seed in product([1,2,3,4,8,16,32],range(1,13)):
 a=[F((seed*(j+3)+j*j)%13,6) for j in range(n)]
 value=kernel(a)
 increased=[x+F(1,7) for x in a]
 assert 0<kernel(increased)<=value<=1
 # One-coordinate envelope is independently integrated exactly.
 one=[max(a)]+[F(0)]*(n-1)
 assert value<=kernel(one)
 counts['expanded']+=1
print('PASS',counts,'total',sum(counts.values()))
print('all_coordinates_equal_one_exact')
for n in [1,2,4,8,16,32,64]:print(n,str(kernel([F(1)]*n)))
# Independent exact expansion of the two-sided exclusive source kernel.
bilateral=0
for masses in product([F(1,5),F(1,3),F(7,15)],repeat=3):
 p=[v/sum(masses) for v in masses]
 for w,t in product(range(1,8),repeat=2):
  cw=[bool(w&(1<<j)) for j in range(3)];ct=[bool(t&(1<<j)) for j in range(3)]
  iw=sum(p[j] for j in range(3) if cw[j]);it=sum(p[j] for j in range(3) if ct[j]);iwt=sum(p[j] for j in range(3) if cw[j] and ct[j])
  direct=sum(p[y]*p[z] for y in range(3) for z in range(3) if cw[y] and not ct[y] and ct[z] and not cw[z])
  assert direct==(iw-iwt)*(it-iwt)
  bilateral+=1
soft=0
for eps,L,c in product([F(1,8),F(1,2)],[F(4),F(5),F(8)],[F(0),F(1,4),F(1,2),F(3,4),F(1)]):
 for a,b in [(F(2),L),(2-eps,L-eps)]:
  assert a*b>=a+b
  assert (a-c)*(b-c)>=a*b*(1-c)
  soft+=1
print('PASS bilateral kernel',bilateral,'soft rank multiplier',soft,'total',bilateral+soft)
