# R401 — retaining the low-common stage marks in the clearing potential

**Result boundary.** The original low-common double-source marks admit a decreasing source occupation and an exact two-part dissipation identity. This preserves more information than first replacing Σb_i by 1. It does not supply a new payment: the necessary quantitative dissipation lower bound remains unproved. This is a marked restriction of the R397 potential accounting, not a new general entropy inequality or an additional negative credit.

## 1. Original marked source occupation

Keep the full field and all original marks of R399–400. In particular γ_i decreases by actual endpoint restriction; f,m,q,π, the inclusive ranks T, common far-past C, and ψ=min(1,C/h) stay fixed. Let

φ(x)=(1−s/x)_+ for x>0, φ(0)=0,
a_i(z)=min(f(z),T_i),
b_i(z)=[a_i(z)−a_{i−1}(z)]φ(D_i(z))/f(z),

with the usual zero convention at f=0. Here T_i is the density cutoff, distinct from the source mass rank T_v(z). Define

r_i(z)=∫_E σ(dv) [c_v(z)/m_v]1_{T_v(z)>Lh}
                 ∫π_v(dy) k_i(v,y)(1−ψ_v(y,z)).          (1)

The original low-common high-small switching bill is exactly

H_rem=Σ_{i≥1}∫[a_i(z)−a_{i−1}(z)]e_i(z) dz,
e_i(z)=r_i(z)φ(D_i(z)).                                  (2)

No source or clock is replaced in (1). It retains the old-source k_i, the new-source high-rank gate, and the actual two-source common-past deficit.

Nested endpoint restrictions imply k_i(v,y)≤k_{i−1}(v,y). Thus r_i decreases pointwise. Also r_i is at most the actual incoming endpoint occupation, and therefore r_i≤D_i. Since D_i decreases and φ is increasing,

0≤e_i≤e_{i−1},  e_i≤(D_i−s)_+.                          (3)

All assertions are for common full-source almost-everywhere versions; countably many stages cause no exceptional-set problem. They do not require monotonicity of r_i/D_i, which need not hold.

## 2. Finite identity and the two actual losses

For every finite N, positive summation by parts yields

H_N:=Σ_{i=1}^N∫(a_i−a_{i−1})e_i
 =∫(a_N−a_0)e_0−Σ_{j=1}^N∫(a_N−a_{j−1})(e_{j−1}−e_j).   (4)

Equivalently, with its terminal term retained,

H_N=∫(a_N−a_0)e_N
       +Σ_{j=1}^N∫(a_{j−1}−a_0)(e_{j−1}−e_j).           (5)

There is no atom approximation: each actual density-cutoff increment is retained in full. The decrement in these identities has the exact decomposition

e_{j−1}−e_j
 =(r_{j−1}−r_j)φ(D_{j−1})
   +r_j[φ(D_{j−1})−φ(D_j)].                              (6)

Both terms are nonnegative. The first is removal of the actual marked low-common occupation. The second is the change in its high-occupancy multiplier caused by removal of ANY actual endpoint traffic. Neither is a new free square credit. They are precisely the decrement already accounted for when (4) telescopes the marked potential.

The same argument applies to the sum with H_ext: its unmultiplied source occupation is also a positive restriction of the decreasing γ_i, its rank/external masks are frozen, and the combined occupation is bounded by the two-endpoint D_i. This observation does not transplant old-source qualifications to the witness source.

## 3. Initial and terminal costs; the missing estimate

R397 clearing gives D_N↓0 for f dz-almost every source and ∫fD_N=2G_N↓0. Therefore

0≤∫(a_N−a_0)e_N≤∫fD_N→0.

If T_N→∞, monotone convergence in (4) gives

H_rem=I_init−Q_drop,
I_init=∫(f−T_0)_+e_0,
Q_drop=Σ_{j≥1}∫(f−T_{j−1})_+(e_{j−1}−e_j).              (7)

All these quantities are finite: I_init≤∫fD_0=2G_0. Alternatively (5) identifies H_rem as the sum of occupancy deletions weighted by the amount of source density ALREADY exposed at that deletion. Thus eventual deletion alone does not pay H_rem; it only removes the terminal term. Late deletions can have small weight in Q_drop and large weight in (5).

For a root receipt, the proposed route would need a quantitative lower bound for Q_drop approaching I_init to within the desired δX_q plus source budget. The original posterior deletion criterion, as currently proved, provides stage potential inequalities and eventual clearing. It supplies no such lower bound for the two terms in (6) with the frozen low-common double-source marks. The coarse source-tail bound is still

I_init≤M∫(f−T_0)_+,  M=S A_n,

which is already part of the R397 analysis and is not uniformly a root price for arbitrary L1 f. No L log L hypothesis is introduced, and the issue is not divergence of an infinite entropy: the complete switching bill is already finite at the original traffic scale.

Consequently retaining b_i does expose exactly where source-density and occupancy losses interact, but no extra geometric depletion estimate has been obtained. Equations (4)–(7) are the restricted old potential accounting, not independent credit to add to it. The R400 first-moment tail has not been paid. The original H_rem, H_ext, and all existing ledger coefficients remain unchanged.

## 4. Minimal finite check

A local standard-library Fraction run checked nine combinations of three decreasing (D_i,r_i) paths and f∈{3,7,13}, using s=2 and density cutoffs (1,2,5,16). It verified (3), (4), and the exact two-term identity (6), including zero terminal occupancy and crossing D=s. Output: `PASS marked decreasing-occupation paths: 9`. This is finite potential algebra, not certification of a native core or a new dissipation lower bound. No additional numerical exploration was undertaken.
