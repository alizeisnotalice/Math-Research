import sys
expanded="--expanded" in sys.argv
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
counts={'score_mean':0,'winsor_tail_bounds':0,'winsor_second_moment_diagnostics':0,'ratio_constant_diagnostics':0,'marked_decomposition':0,'zero_mass_defects':0}
def dec(x):return D(x.numerator)/D(x.denominator)
for r in [F(1,4),F(1,2),F(3,4),F(1)]:
 assert r*(F(1)-F(1))==0
 counts['score_mean']+=1
 for L in [F(1),F(3,2),F(2),F(4),F(10),F(100)]:
  w0=1/(2*(L+1))
  tailprob=r*w0*w0
  rawtail=r*(w0-w0*w0)
  excess=rawtail-L*tailprob
  assert tailprob==r/(4*(L+1)**2)
  assert excess==r/(4*(L+1))
  capmean=-rawtail+L*tailprob
  assert capmean==-excess
  counts['winsor_tail_bounds']+=1
  with localcontext() as ctx:
   ctx.prec=80
   rawsecond=dec(r)*(D('0.5')*(2*(dec(L)+1)).ln()-1+2*dec(w0)-dec(w0)**2)
   capsecond=rawsecond+dec(L*L*tailprob)
   formula=dec(r)*(D('0.5')*(2*(dec(L)+1)).ln()-D('0.75')+1/(2*(dec(L)+1)))
   bound=dec(r)*(D('0.25')+D('0.5')*(1+dec(L)).ln())
   assert abs(capsecond-formula)<D('1e-75')
   assert 0<=capsecond<=bound
   counts['winsor_second_moment_diagnostics']+=1
with localcontext() as ctx:
 ctx.prec=80
 for n in ([1,2,3,4,16,64,256,4096,10000,1048576] if expanded else [1,4,16,64,256]):
  N=D(n);root=N.sqrt();A=(D('0.25')+D('0.5')*(1+root).ln()).sqrt()
  universal=1+N/(2*(root+1))+2*root*A
  for ratio in ([F(1),F(3,4),F(1,2),F(1,4),F(1,100),F(1,10**6),F(1,10**12)] if expanded else [F(1),F(3,4),F(1,2),F(1,4),F(1,100)]):
   eta=dec(ratio)
   exact=1+N*(1-eta)/(2*(root+1))+2*root*A*(1-eta.sqrt())
   assert 1<=exact<=universal
   counts['ratio_constant_diagnostics']+=1
sets=[{0,1},{1,2,3},set(range(8)),set(range(4,12)),set(range(12)),{0,2,4,6,8,10}]
V=[F(len(A)) for A in sets]
du=[F(i+1,3) for i in range(len(sets))]
levels=sorted(set(V))
clock=[1/levels[k]-(1/levels[k+1] if k+1<len(levels) else F(0)) for k in range(len(levels))]
for phase in range(3):
 f=[F(6+(y+phase)%3,8) for y in range(12)]
 m=[sum(f[y] for y in A) for A in sets]
 q=[m[i]/V[i] for i in range(6)]
 mu=[du[i]/m[i] for i in range(6)]
 for v in range(6):
  assert sum(f[y]-q[v] for y in sets[v])==0
  counts['zero_mass_defects']+=1
 K=F(2)
 J=[[sum(mu[u] for u in range(6) if V[u]<=R and y in sets[u]) for y in range(12)] for R in levels]
 past=[[sum(mu[v] for v in range(6) if m[v]<m[u]/K and y in sets[v]) for y in range(12)] for u in range(6)]
 for H in [F(0),F(1,4),F(1,2),F(1),F(2)]:
  for h in [F(1,8),F(1,4),F(1,2),F(1),F(2)]:
   omega=[[F(0) for y in range(12)] for u in range(6)]
   original=F(0)
   for k,R in enumerate(levels):
    for u in range(6):
     if V[u]>R:continue
     for y in range(12):
      if J[k][y] and J[k][y]>=H and past[u][y]>h:
       assert J[k][y]>h
       omega[u][y]+=h*V[u]*clock[k]/J[k][y]
     for v in range(6):
      if V[v]>R or not(m[u]>K*m[v]) or (u+2*v)%3==0:continue
      for y in sets[u]&sets[v]:
       if J[k][y] and J[k][y]>=H and past[u][y]>h:
        original+=clock[k]*f[y]*(m[u]-m[v])*mu[u]*mu[v]/J[k][y]
   assert all(0<=z<=1 for row in omega for z in row)
   template=F(0);plus=F(0);minus=F(0);floor=F(0)
   for u in range(6):
    for v in range(6):
     if not(m[u]>K*m[v]) or (u+2*v)%3==0:continue
     assert V[v]<V[u]
     coeff=du[u]*du[v]*(1-m[v]/m[u])/(h*V[u])
     for y in sets[u]&sets[v]:
      template+=coeff*omega[u][y]/V[v]
      plus+=coeff*omega[u][y]*max(F(0),f[y]-q[v])/m[v]
      minus+=coeff*omega[u][y]*max(F(0),q[v]-f[y])/m[v]
      floor+=coeff*omega[u][y]*min(f[y],q[v])/m[v]
   assert original==template+plus-minus==floor+plus
   assert floor==template-minus and 0<=minus<=template and 0<=plus<=original
   counts['marked_decomposition']+=1
print('PASS',counts,'total',sum(counts.values()))
