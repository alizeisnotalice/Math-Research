# R370 bounded history check — shared-radius overlap floor

## Search scope

Read `/tmp/r338_main.md` (the R338 original hard-slot receipt), `/tmp/r336_directional.md` and `/tmp/r336_audit.md` (directed mass receipts), `/tmp/r364_main.md`, `/tmp/r364_audit.md` and `/tmp/r364_clock.md` (shared-selector/stopped-clock route), and `/tmp/r370_source.md` (current two-source cut decomposition). This is a targeted comparison, not a full-history search.

## Prior results and their limits

- **R338, §§ “精确合同” and “统一可付膨胀区域,” especially `/tmp/r338_main.md` lines 34–47, 49–64:** for the original hard slot with arbitrary measurable common radius selector `a≤R_u≤b≤2a`, it pays the center-dilation pair region `||v−u||∞≤αR_u/2`, using only true receiver-center volume and `I_uv=f(Q_u∩Q_v)≤m_v`. The complement `G_out`, with the original mass-ratio, global-past, J, clock, common-source and outer-center gates retained, is explicitly still unpaid (lines 43, 61–64). This is not the proposed overlap integral on the outer complement.
- **R336, `/tmp/r336_directional.md` lines 1–23 and `/tmp/r336_audit.md` §§2–3, 5:** it pays ordered positive capture/miss components using `ν(Q_u\Q_v)≤m_u`, actual center-volume estimates, a strict low-J split and a mass-ratio split. The receipt is for the *directed missing-source* term and its specified favorable mass orientation. It does not state or pay `∫dv |Q_R(u)∩Q_{s(v)}(v)|/s(v)^n` for an arbitrary radius selector, nor the `min(f,q_v)` portion of the current outer hard remainder.
- **R364, `/tmp/r364_main.md` and `/tmp/r364_clock.md`:** retains a common actual-radius selector, same-r high-source marks and the original stopped clock; the stopped kernel remains a two-source geometric kernel. Its audit explicitly says the shared finite selector diagnostic is not a source-linear receipt and the remaining near/high core is unpaid (`/tmp/r364_audit.md` lines 20, 27, 31). It does not furnish the proposed variable-small-radius overlap floor payment.
- **R370, `/tmp/r370_source.md` §§1–5:** retains the actual pair mask and defines the exact cut identity. It identifies `E_boundary(t)` as a product of two actual source masses and says both that error and the separated-source term remain unpaid; no root-order receipt is supplied. This is consistent with the candidate being a new way to pay only a distinguished floor component, not an already settled R370 term.

## Bounded verdict

Within these sources, I found no prior receipt for the arbitrary-selector overlap template

`∫_E |Q_R(u)∩Q_{s(v)}(v)| / s(v)^n dv ≤ R^n C_n`,

with `s(v)∈[a,R]`, `R/a≤2`, and the proposed `C_n=1+log(2)√n(1+√(.25+.5log(1+√n)))`; nor a previous application to the source-floor part of the **outside-dilation, `¬B+`** remainder. R338 had already paid the geometrically different inside-dilation region, so any genuinely new coverage is confined to the stated remaining mask and must retain its original gates. The proposed split `f=min(f,q_v)+(f−q_v)+` uses the same complete original `f` to define `q_v`; its floor term is bounded by `q_v|Q_R(u)∩Q_{s(v)}(v)|`, and after `μ(dv)=dv/(q_vs(v)^n)` this yields precisely the displayed overlap kernel. The positive excess part remains unpaid by this argument.

This is a bounded-history identification, not a verification of the proposed `C_n` inequality, its low-clock summation, or the claim that the selected remainder is nonempty. The uniform-f, n=10000 modified-V diagonal example is noted as a positive-traffic diagnostic for `G_out∩¬B+`; it does not by itself certify all original gates or establish a general receipt.
