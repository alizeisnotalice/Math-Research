# R370 independent audit — FINAL PASS

Status: FINAL PASS for the global uniform-overlap geometry theorem, the exact positive floor-component payment on the original remainder, the marked source identities, final main/ledger and bounded code/evidence review. No unresolved correction was found. The independent screens below preceded the author proof; the final review follows them. The arbitrary concentrated-source excess and global theorem remain unpaid. Only this audit file was modified; no author/repository file was edited.

## Quantifiers and normalization
Fix one axis-parallel cube Q_R(u), R>0, n>=1, 0<a<=R and R/a<=2. The actual smaller side selector s(v) is any measurable map into[a,R], common across coordinates. Define theta_s(v)=|Q_R(u) intersect Q_s(v)|/s^n and p_s(v)=theta_s(v)/R^n. Then p_s is the convolution of two probability cube densities, integral1. The claim concerns integral over all receiver centers v in R^n of theta_{s(v)}(v), bounded by R^n integral sup_s p_s. Restriction to any actual measurable receiver set can only decrease this positive integral. Uniformity belongs to this comparison convolution, not to f or to a source posterior. No selector/history qualification is changed.

The intended constant is 1+(log 2)*sqrt(n)*[1+sqrt(1/4+(1/2)log(1+sqrt(n)))]. The log2 here must mean natural log of2, not base-2 logarithm of sqrt(n). If a=R the selector is fixed and the exact answer is R^n. Continuity in s gives a measurable pointwise supremum via rational scales and the endpoints. No measurable maximizing selector is necessary for the upper bound.

## Independent score proof
Translate u=0. The one-dimensional probability density is ell_{R,s}(x)/(Rs), with plateau1/R on |x|<=(R-s)/2 and linear tails d/(Rs), d=(R+s)/2-|x| in(0,s). Its log-scale derivative score Y is0 on the plateau and s/(2d)-1 on the tails. It satisfies Y>=-1/2, E Y=0, and, for t>=0,

P(Y>t)=s/[4R(t+1)^2] <=1/[4(t+1)^2].

The score is singular at the moving support endpoint but has finite first absolute moment; its full second moment is infinite. Thus an untruncated Fisher-variance argument is invalid. The density itself is continuous at its knots, with an integrable scale derivative and no delta-face jump. For fixed x it is absolutely continuous in log s. Its tensor product has derivative p_s sum_i Y_i, where independence is ONLY under this center probability density.

For cutoff L>0, Z=min(Y,L), tail b=E(Y-L)+<=1/[4(L+1)], and
E Z^2 <=1/4+(1/2)log(1+L).
Indeed the negative score is bounded by1/2 and the positive clipped second moment is integral_0^L 2t P(Y>t)dt. Centering the truncated variables gives

E|sum_iY_i| <=sqrt(n[1/4+(1/2)log(1+L)])+2nb.

With L=sqrt(n), this is <=sqrt(n)[sqrt(1/4+(1/2)log(1+sqrt(n)))+1/2]. FTC/Tonelli therefore gives

integral sup_{a<=s<=R}p_s <=1+log(R/a)*sqrt(n)[sqrt(1/4+(1/2)log(1+sqrt(n)))+1/2],

which is stronger than the proposed constant (whose final additive term inside brackets is1). One can also use the zero-mean positive-derivative half-L1 refinement, but it is unnecessary. Any final author proof may use a looser safe bound; it must not invoke the divergent untruncated score variance or silently replace a common scale by independent coordinate scales.

## n=1 and endpoints
In one dimension the density increases with s only for |x|>R/2 and decreases/holds elsewhere. The exact envelope integral is1+(R-a)/(4R)<=9/8. Thus n=1 is valid; the displayed proposed constant is generous. At s=R the plateau vanishes, but no positive-measure mass or singular delta derivative appears. Cube boundaries have zero receiver-Lebesgue measure. The ratio endpoint R/a=2 is included.

## Frozen-source substitution and missing payment
An exact baseline-plus-signed-excess substitution is legal only inside the SAME original positive source kernel: f(y)=c+[f(y)-c], with all actual m,q,J,H,past/physical-prefix/clock/exterior masks fixed, and with sufficient absolute integrability. If a compact comparison template is used instead, write f=c1_F+[f-c1_F] with its support explicit. The signed excess need not be positive or small. A valid upper bound may use its positive part, at its own explicit cost.

In particular, when the original integrand retains source-dependent 1/J_y(r) and gates, one cannot replace that weighted overlap by an unweighted I_uv, alter the m_u-m_v coefficient to a uniform-source mass difference, or compute J/q from the reference density. The geometric theta envelope is for ordinary uniform overlap over actual receiver centers. A connection to the original arbitrary-f G_out notBplus requires a legal positive relaxation of those source-dependent factors and a bound for the signed/excess contribution. This screen gives no such dispersion estimate, no new root source fee, and no general absorption.

## Actual local arithmetic evidence and next step
A local Python standard-library Fraction exercise actually passed30 assertions: five ratios R/a=1,5/4,3/2,7/4,2 checked the exact one-dimensional envelope; five nonnegative tail levels at each ratio checked the exact score-tail integral and its bound. This is bounded scalar arithmetic, not a multidimensional or arbitrary-source computation. The independent analytic derivation above is the proof evidence. No author file was read before this initial screen. The later final author review and byte bindings are recorded below.

## Additional independent screens: original floor branch and all-scale envelope

These screens were completed before reading the forthcoming geometric author proof. The previous warning concerned applying a bare template without a legal source decomposition; the following explicit decomposition supplies a genuine positive original subbranch.

For each actual small receiver v, split the source factor pointwise as f(y)=min(f(y),q_v)+(f(y)-q_v)+, leaving ALL original full-f fields, mass ordering, source-dependent J/highpast gates, actual pair restrictions, and clock unchanged. This is a pair-dependent positive split, not a replacement input g whose q or J is recomputed. If T is the same original weighted integral with source factor q_v, D_minus with (q_v-f)+, and D_plus with (f-q_v)+, exact G_floor=T-D_minus>=0 and G=G_floor+D_plus. The negative term is exhausted by this identity and may not be reused as a separate credit.

For the floor branch, first use the ORIGINAL live highpast support J>h*. Then positively drop the other source/pair gates and use m_u-m_v<=m_u. In original mu_u mu_v, m_u cancels, while q_v from the template cancels the q_v in m_v=q_v R_v^n. Tonelli over physical r with R_v<R_u gives inclusive tail R_u^-n, including b atom. Thus

G_floor <=h*^-1 integral_E du R_u^-n integral_{v:R_v<R_u} |Q_u intersect Q_v|/R_v^n dv
<= C_geom |E|/h* <= C_geom X_q/(q_-h*).

The variable-R_v integral is exactly the screened center-selector template; extending actual E to all centers and dropping actual source-dependent gates is justified only for this positive upper bound, after bounding J. It is not an equality that removes those gates from D_plus. With h*=(1+sqrt(n))/(epsilon0 q_-), the paid positive original part costs epsilon0 C_geom X_q/(1+sqrt(n)), and the remainder D_plus retains all original marks. At fixed epsilon0 there is no new source fee. If its sqrt(log n) coefficient is absorbed by changing epsilon0, C338 and h* must be recomputed; no global absorption is granted. This can apply directly to R369's still-unpaid positive G restriction with the same actual contract, without recharging its already-paid branch.

The strengthened all-scale template also passes independently. Write r=s/R (this r is a dimensionless side ratio, not the original physical clock). The exact tail is r/[4(t+1)^2], the negative clipped second moment is at most r/4 because all nonzero score lies on the tails of total probability r, and the positive clipped second moment is at most (r/2)log(1+L). At L=sqrt(n), A_n=sqrt(1/4+(1/2)log(1+sqrt(n))) is a temporary template constant, unrelated to the historical clock A_n=1+nlog(b/a). The same centered truncation gives

||s partial_s p_s||_1 <= n(s/R)/[2(sqrt(n)+1)]+sqrt(n s/R) A_n.

Integrating in ds/s for ANY0<a<=R yields

integral sup_{a<=s<=R}p_s <=1+n(1-a/R)/[2(sqrt(n)+1)]+2sqrt(n)A_n(1-sqrt(a/R))
<=1+sqrt(n)/2+2sqrt(n)A_n.

No hidden log(R/a) remains. The original density is scale-absolutely-continuous with integrable variation; the bound also survives a decreasing-to-zero cutoff by monotone convergence of the scale supremum. Neither individual-source Fisher variance nor arbitrary-source density is bounded by this argument. For the octave application one may use the minimum of the octave and global template constants. The main original hard contract and all excess/other slots remain as before.

A separate reviewer-local Python Fraction exercise actually passed42 scalar checks for the exact floor/excess identities and proportional tail quantities. Together with the earlier30, this is72 reviewer scalar assertions, separately recorded and not an author/main pipeline count.

## Auxiliary source note — bounded author review
Read /tmp/r370_source.md in full after the independent weighted-source substitution screen. PASS for its stated auxiliary identities, not a new payment. With A=Qu intersect Qv, B=Qu minus Qv, C=Qv minus Qu, M=m_u,m=m_v,I=f(A), the equality (M-m)I_omega=(M-I)I_omega-(m-I)I_omega is exact with y's original omega retained. The overhang is nonnegative and used once; source z introduced in the cut product does not receive y's gates. Dropping the positive pair gates and integrating v recovers original J, so D_cut<=X_q and the signed identity has finite positive terms.

The first maximizing coordinate of the actual receiver displacement is measurable. The exterior-center gate and q-band give d>(alpha-gamma)R/2>0, all common y lie on the chosen one-sided cap, and the actual opposite-source cap lower-bounds the separated fraction. This is a lower-bound dispersion criterion, not an upper payment. For near cut pairs, crossing the small cube boundary forces inner/outer depth<t, giving the product of ACTUAL weighted inner and actual outer f boundary masses. Its integral is at most D_cut, which is merely an order-X bound. No density ceiling, coordinate independence, duplicated n-face charge or extra negative-square credit was used. The468 Fraction cases are finite scalar/point geometry diagnostics actually rerun by the parent in the final evidence record; they are not an actual matched hard field and were not rerun by this reviewer. Frozen source-note SHA256:309ae4d0090c202313a6a08e5e543b3d9b191ddc6a56b2b17095205e9ddddcef.

## Main/ledger and actual remaining-branch witness review
Read /tmp/r370_main.md and /tmp/r370_ledger.md in full, and checked their unchanged final hashes below. Their stronger octave constant Gamma_n=1+n/[4(sqrt(n)+1)]+2sqrt(n) a_n(1-1/sqrt2) is exactly the all-scale bound at a/R>=1/2. The source-integrated omega=h*R_u^n integral_[R_u,b]ell gates/J is in[0,1] and its displayed exact G coefficient is correct. Pair-dependent min(f,q_v) produces a positive original subbranch; D_minus has already been used and D_plus<=G. With L_n=2+(72+Gamma_n)/(1+sqrt(n)), epsilon0=eta/L_n bounds just this hard-slot coefficient. The changed h*,C338, entrance2, outerLambda and remaining H/d_eff/other slots are all retained. No correction was required; the final byte bindings below apply to these reviewed files.

Read /tmp/r370_witness.md and its complete46-assertion exact script. The modified small center is(.6,.5,...,.5), n10000, all other field parameters as R369. Every coordinate retains positive room to capture all y in Y, both boxes remain inside actual E and all actual cubes lie in the constant source support. Baseline R0 on V is still below1.25, all non-U sides<=1.5, so the same strict global-past capacity>9794/3>H=h*=310272/119 is valid. The first coordinate still maximizes pair displacement and certifies the original alpha exterior condition. The remaining coordinates now each contribute .25 plus/minus4rho excess; the full sum lower625299/250 exceeds the exact Tplus by more than2000. Thus it is actual positive-volume G_out notBplus at its stated parameters, with the original terminal atom and full source retained. Because f=q_v=1 on every actual cube, the signed excess vanishes throughout its actual source kernels; after the audited exact floor split this entire positive remainder is indeed on the new floor side. It does not witness arbitrary reallocations, a useful covered proportion, all historical contracts or any global obstruction. The report's conditional template-migration wording is cautious and consistent. The final parent evidence record reports the46 exact witness assertions actually rerun; no reviewer duplicate run is claimed.


## Final geometry author review and consistent integration
Read the final /tmp/r370_geometry.md in full (SHA fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a). PASS. Its renamed a_score,n avoids confusing the temporary score constant with historical clock A_n. Equations(6)-(10) give the correct zero-mean score, exact ramp law, proportional s/R tail, capped second moment and the two tail/mean-centering terms. The score itself has infinite untruncated variance; the proof does not use it. For a>0 each fixed-center trapezoid product is absolutely continuous with matching zero boundary values, so FTC/Tonelli applies. Rational-scale measurability of the supremum and monotone extension to all positive smaller scales are legitimate. Keeping s/R in both terms removes the log(R/a) loss. The global theorem is a deterministic receiver-center template theorem; no arbitrary source distribution is declared independent or bounded.

The final author exact physical-clock omega, source floor/excess decomposition and finite signed integrals agree with the independent derivation. Original strict past implies J>h* on every live row without changing original H or global/source gates. The clock starts at R_u because actual far mass gives R_v<R_u, and its inclusive tail includes the b atom. The replacement f/m_v=R_v^-n+(f-q_v)/m_v is inside the same actual source-dependent omega; no unweighted source-overlap equality is substituted. T and D_minus are finite, D_plus<=G<=X_q, so no undefined signed subtraction arises.

Final main and ledger use Gamma_n=C_n(1/2), pay only G_floor within the original R369 remainder and retain D_plus exactly. At fixed epsilon0 the new receiver increment is epsilon0 Gamma_n/(1+sqrt(n)) and there is no additional W fee. The explicit allocation L_n=2+(72+Gamma_n)/(1+sqrt(n)), epsilon0=eta/L_n changes BOTH h* and C338 consistently. The resulting O_eta(sqrt(n log(n+2)))W is the inherited C338 evaluated at the new parameter, not an uncharged epsilon change. The original entrance8lambda H W+2d_eff A_n Wnu/H+2B_H and full outer Lambda=128/119 remain. This controls only this slot at2Lambda eta; total independent absorption and all H/entry/source-scale fees are not certified. Old D/N/A/C, old square and old path credits are not recharged.

Read the final bounded history note; its search scope and limited novelty conclusion are explicitly restricted. This audit does not independently repeat every historical search or certify comprehensive novelty. The note's initial weaker octave template formula is a historical candidate description, not the final sharp constant used in main/ledger.

## Final code/results scope and actual execution record
Read the final three standalone scripts and numeric notes. The source script equals its unique final embedded block after stripping outer whitespace. The geometry script differs from its unique author block ONLY by importing sys, defining --expanded and conditionally enlarging the listed dimension/ratio grids; the default mathematical logic is unchanged. The witness code and analytic continuum construction agree as reviewed above. No external solver, randomized fitting, source-independence inference or undisclosed new kernel realization is used.

The parent reports actual successful local executions: default geometry170, expanded geometry215, source468 and witness46. Default/expanded overlapping checks are not added. The maximum configuration therefore totals729 counted checks:635 Fraction and94 ordinary80-digit Decimal diagnostics. The94 comprise24 capped-moment checks and70 dimension/ratio comparisons. The Fraction subtotal includes4 explicitly trivial score-mean scalar formula checks,24 exact tail/mean checks,75 marked decomposition cases and18 zero-defect checks from geometry, plus468 source and46 witness. These are assertion counts, not independent actual matched fields or theorem proofs. The author incipient SymPy import failure is honestly disclosed and no SymPy dependence remains. The reviewer72 actual scalar Fraction checks are separate and not included in729. No full pipeline was redundantly rerun during this final audit.

The source incidence arrays and geometry marked-clock arrays are finite quadrature/algebra diagnostics, not the original high-dimensional actual cube field. Decimal outputs are not interval certificates. Only the specified n10000 analytic witness certifies actual full-f, positive source/receiver boxes, continuum selector, strict past/high-J/exterior/notBplus gates; its particular H/epsilon0 and tiny probe limitation remain explicit. It shows the new floor branch is nonempty and can include all source traffic in that field, not a guaranteed fraction for every input or every reallocation.

## Remaining obligations and final disposition
Exact unpaid object: original G_out notBplus with ONLY its source factor replaced by(f-q_v)+, keeping the original full-f m/q/J, pair masks, strict past, physical clock and endpoints. Alternatively a signed estimate of D_plus-D_minus may be attempted, but D_minus cannot be spent again after the floor identity. The actual source-correlation test F_v is not constant; matching integral_Qv(f-q_v)=0 does not cancel it. The auxiliary separated-source cut term and actual inner/outer boundary-mass product also remain unbudgeted.

All general soft/crossing, original entrance compatibility, contract-exterior/distance/low-pe/scale/threshold regimes, historical initial/deletion/future-source time atoms, H selection, source and physical-scale aggregation, outer integration, truncation and limiting interfaces remain unresolved as explicitly listed in the final ledger. The all-scale template theorem is not an all-scale maximal-operator proof. No PDF compilation, archive packaging, Git operation or publication is certified by this audit. No outstanding correction; bounded final disposition PASS.

## Final frozen byte bindings
SHA256 applies to the exact reviewed bytes. Audit-file hash is supplied separately after saving.

- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`
- `/tmp/r370_source.md` — `309ae4d0090c202313a6a08e5e543b3d9b191ddc6a56b2b17095205e9ddddcef`
- `/tmp/r370_main.md` — `150cea9386d50fd023f66948992b86ee482857888ed7e027802cab2aaaf26ed1`
- `/tmp/r370_ledger.md` — `a926a7c33566bddb4fd7858c3aeabd118b7221ab7d9223179fa0ec8a1858731e`
- `/tmp/r370_witness.md` — `86c0587e3481921eb84b05e459ea64146bb1b815a6765423cd23054a793062ab`
- `/tmp/r370_history.md` — `62d7e2ebc42947bdbf70b86877988d51112abe4e4378ad4f06cd693e4e58d9b6`
- `/tmp/r370_numeric.md` — `fbb43071c6e921ce60a7581e87437182875ef04c95ab58333ee54f0b2d7814ea`
- `/tmp/r370_readme.md` — `4ae229ef9c3c7123af544fbac9506457d571ac6c5e9a1d3f11f28d83ec87a03f`
- `/tmp/r370_geometry_check.py` — `1212a64071e8d22ee1b261ebb1aa45f66c772331393d5fd456002885c2fb462a`
- `/tmp/r370_source_check.py` — `f35fd7ed48c1bc3232c799ec0781825d4b56d378e23116d8ba3b2e81b0c96cfa`
- `/tmp/r370_witness_check.py` — `68c2fc9ccd3e8c8d50675d5e422683edad63ddb6f89e86966ff0bdf697e1e02e`

Necessary inherited contracts (bounded dependency review, not a new full-history audit):

- `/tmp/r338_main.md` — `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`
- `/tmp/r369_main.md` — `12d0c216cf1dab0ec7b975b0b622aa7d64efc0a0a2e08f1cda50cfcfa2491c45`
- `/tmp/r369_ledger.md` — `dad79013a378bb021da53d4d02f87d7d3eb9bc204e08b2825bf4577d416ef538`
- `/tmp/r369_audit.md` — `b508a69e70f9f7a86cbc0ae9437a22b21ec07bc7b8c9c632a196f2c21c53f2c2`

Frozen FINAL PASS. Further mathematical or byte changes to reviewed files require renewed binding/review; no further task work remains.
