from fractions import Fraction as F
from itertools import product

checks=0
points=[(F(i,4),F(j,4)) for i in range(-5,6) for j in range(-5,6)]
u=(F(0),F(0)); R=F(2)

def inside(z,center,side):
    return all(abs(x-c)<=side/2 for x,c in zip(z,center))

def dist(z,w):
    return max(abs(a-b) for a,b in zip(z,w))

for center in ((F(3,4),F(0)),(F(1),F(1,4)),(F(-1),F(1,2))):
    for side in (F(1,2),F(1),F(3,2)):
        i=min(range(2),key=lambda j:(-abs(center[j]),j))
        sign=1 if center[i]>0 else -1
        d=abs(center[i])-side/2
        for pattern in range(4):
            weights={z:F((k*(pattern+1)+3)%9) for k,z in enumerate(points)}
            marks={z:F((k+pattern)%5,4) for k,z in enumerate(points)}
            A=[z for z in points if inside(z,u,R) and inside(z,center,side)]
            B=[z for z in points if inside(z,u,R) and not inside(z,center,side)]
            C=[z for z in points if inside(z,center,side) and not inside(z,u,R)]
            I=sum((weights[z] for z in A),F(0))
            b=sum((weights[z] for z in B),F(0))
            c=sum((weights[z] for z in C),F(0))
            Iw=sum((weights[z]*marks[z] for z in A),F(0))
            assert (I+b-I-c)*Iw==b*Iw-c*Iw
            checks+=1
            for t in (F(1,8),F(1,4),F(1,2),F(1)):
                sep=sum((weights[y]*marks[y]*weights[z] for y in A for z in B if dist(y,z)>=t),F(0))
                near=sum((weights[y]*marks[y]*weights[z] for y in A for z in B if dist(y,z)<t),F(0))
                assert sep+near==b*Iw
                checks+=1
                cap=sum((weights[z] for z in points if inside(z,u,R) and sign*z[i]<=d-t),F(0))
                assert sep>=cap*Iw
                checks+=1
                inner=sum((weights[y]*marks[y] for y in A if min(side/2-abs(y[j]-center[j]) for j in range(2))<t),F(0))
                outer=sum((weights[z] for z in B if max(max(abs(z[j]-center[j])-side/2,F(0)) for j in range(2))<t),F(0))
                assert near<=inner*outer
                checks+=1
print('PASS',checks,'exact Fraction checks')
