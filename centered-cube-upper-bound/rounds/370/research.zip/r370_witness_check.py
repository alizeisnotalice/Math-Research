#!/usr/bin/env python3
"""R370 exact whole-box witness margins; prints results, writes no other file."""
from fractions import Fraction as F
from collections import Counter
from math import factorial
import json
n=10000;root=100;delta=F(1,10**6);rho=F(1,10**7);Ru=F(2);Rv=F(5,4);eps=F(119,3072);q=F(1);lam=F(4,3);qminus=3*lam/4
u_first=F(-1,2);v_first=F(3,5);u_other=F(0);v_other=F(1,2);a=F(1);b=F(2)
checks={};stages=Counter()
def ck(stage,name,value):
 assert value,name
 checks[name]=True;stages[stage]+=1
def logbounds(x,N=80):
 z=(x-1)/(x+1);lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return lo,lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
def main():
 st='initial_geometry'
 ck(st,'dimension_exact_square',root*root==n)
 ck(st,'q_band_lambda_qminus',qminus==q==1 and qminus<=q<=lam)
 ck(st,'receiver_domain_positive',F(3,4)-delta>0)
 ck(st,'positive_source_and_receiver_boxes',0<rho<delta<F(1,100))
 for label,u,v in [('first',u_first,v_first),('other',u_other,v_other)]:
  ck(st,'U_'+label+'_inside_E',abs(u)+rho<F(3,4)-delta)
  ck(st,'V_'+label+'_inside_E',abs(v)+rho<F(3,4)-delta)
  ck(st,'common_Y_U_'+label,abs(u)+rho+delta<Ru/2)
  ck(st,'common_Y_V_'+label,abs(v)+rho+delta<Rv/2)
 ck(st,'U_override_baseline_below_three_halves',2*(max(abs(u_first),abs(u_other))+rho)+2*delta<F(3,2))
 ck(st,'V_override_baseline_below_selected_radius',2*(max(abs(v_first),abs(v_other))+rho)+2*delta<Rv)
 ck(st,'baseline_on_all_E_between_a_and_three_halves',2*(F(3,4)-delta)+2*delta==F(3,2) and a==1)
 ck(st,'all_actual_cubes_within_full_source',F(3,4)-delta+b/2<3)
 ck(st,'baseline_captures_common_Y',delta>0 and a>=2*delta)
 ck(st,'U_V_positive_boxes_disjoint',v_first-u_first>2*rho)
 st='old_gates_pressure'
 ck(st,'strict_mass_gap_base',F(4,3)**4>3)
 e_upper=sum((F(1,factorial(k)) for k in range(11)),F(0))+F(1,factorial(11))*F(12,11)
 ck(st,'rigorous_exp_one_upper_below_three',e_upper<3)
 ck(st,'strict_mass_gap_global_past_exponent',n%4==0 and n//4>root)
 ck(st,'all_nonU_actual_radii_below_three_halves',Rv<=F(3,2)<Ru)
 ck(st,'mass_threshold_strict_for_all_nonU',(F(4,3)**n)>3**root)
 ck(st,'Bernoulli_baseline_factor',1-2*delta*(n-1)>F(49,50))
 l32,u32=logbounds(F(3,2));ck(st,'radial_log_lower',l32>F(1,3))
 ck(st,'removed_override_volumes_each_below_one',0<2*rho<1)
 Z=F(49*n,150)-2;H=(1+root)/(eps*qminus)
 ck(st,'original_H_hstar_value',H==F(310272,119))
 ck(st,'strict_global_past_and_terminal_highJ',Z>H)
 ck(st,'strict_alpha_upper_power',F(21,20)**100>101 and n>=100)
 separation_lo=v_first-u_first-2*rho
 ck(st,'outside_actual_expanded_center',separation_lo>F(21,20))
 ck(st,'big_center_outside_small_cube',separation_lo>Rv/2)
 ck(st,'first_coordinate_still_max_separation',separation_lo>v_other-u_other+2*rho)
 ck(st,'physical_terminal_atom_positive',b**(-n)>0)
 l2,u2=logbounds(F(2));ck(st,'actual_global_J_upper',u2<1)
 ck(st,'outside_old_radius_ratio_branch',Rv<F(3,4)*Ru)
 st='expanded_excess_and_positive_margin'
 first_lo=2*(v_first-u_first-2*rho)-(Ru-Rv);first_hi=2*(v_first-u_first+2*rho)-(Ru-Rv)
 other_lo=2*(v_other-u_other-2*rho)-(Ru-Rv);other_hi=2*(v_other-u_other+2*rho)-(Ru-Rv)
 ck(st,'first_excess_exact_interval',first_lo==F(29,20)-4*rho and first_hi==F(29,20)+4*rho)
 ck(st,'all_other_excesses_now_strictly_positive',other_lo==F(1,4)-4*rho>0)
 total_lo=first_lo+(n-1)*other_lo;total_hi=first_hi+(n-1)*other_hi
 ck(st,'whole_box_sum_excess_interval',total_lo==F(29,20)+(n-1)*F(1,4)-4*n*rho and total_hi-total_lo==8*n*rho)
 beta=F(n+1,n);w=max(a,Rv/beta);Tplus=F(n,4)*((1+beta)*w-Ru)**2/(beta*w)
 ck(st,'effective_radius_matches_floor',w==F(12500,10001) and beta*w==Rv)
 ck(st,'adaptive_threshold_positive',((1+beta)*w-Ru)>0 and Tplus>0)
 ck(st,'outside_paid_Bplus_on_entire_UV',total_lo>Tplus)
 ck(st,'excess_gap_greater_than_two_thousand',total_lo-Tplus>2000)
 ck(st,'old_N_and_A_tiny_masks_fail',first_lo>F(19,4*n) and first_lo>F(361,64*n))
 ck(st,'far_mass_difference_strict_positive',Ru**n>Rv**n)
 ck(st,'positive_full_source_and_probe_factors',F(2)*delta>0 and F(2)*rho>0 and 6>0 and n>0)
 ck(st,'constant_f_minus_qv_zero_on_all_actual_cubes',q==1 and F(3,4)-delta+b/2<3)
 result=dict(status='PASS',count=len(checks),stage_counts=dict(stages),checks=checks,n=n,delta=str(delta),rho=str(rho),H_and_hstar=str(H),strict_past_lower=str(Z),sum_excess_interval=[str(total_lo),str(total_hi)],Tplus=str(Tplus),strict_excess_gap_lower=str(total_lo-Tplus),positive_probe_lower_bound='2^(-n)*(2delta)^n*(2rho)^(2n)*(2^n-(5/4)^n)/(2^n*(5/4)^n*(1+n))',full_source_mass='6^10000',template_scope='f-qv vanishes on all actual cube-supported source kernels. Equality of a newly proposed signed-template residual with original G is conditional on its exact same-kernel formula audit.',scope='Actual n10000 common full-L1 source and positive Lebesgue receiver/source boxes, original highpast/far/exterior/clock gates, outside paid Bplus. Only a positive probe lower bound, not a useful full-G fraction or general closure.')
 print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
