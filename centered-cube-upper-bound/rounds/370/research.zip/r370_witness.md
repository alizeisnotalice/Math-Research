# R370: positive-volume actual hard-gate witness outside B-plus

The R369 witness is modified only by moving the remaining coordinates of the small receiver center to 1/2. The resulting true L1/receiver-Lebesgue witness lies in the actual remaining G_out outside the paid B-plus branch. This proves nonemptiness, not a useful fraction of the full remainder or a general estimate.

Set n=10000, a=1, b=2, lambda=4/3, q_-=1, epsilon0=119/3072, K=exp100, alpha=101^(1/10000), H=h_*=310272/119. Let delta=10^-6, rho=10^-7 and

- f=1_[-3,3]^n, W=6^10000;
- E=[-3/4+delta,3/4-delta]^n;
- baseline R0(w)=max(1,2||w||_infinity+2delta);
- Y=[-delta,delta]^n;
- U=(-1/2,0,...,0)+[-rho,rho]^n;
- V=(3/5,1/2,...,1/2)+[-rho,rho]^n.

The actual selector is R=2 on U, R=5/4 on V, and R=R0 elsewhere. These boxes are positive-volume, disjoint and inside E. Both overrides exceed their respective baseline values: the baseline on U is below 3/2, and that on V is below 5/4. No assertion that U's baseline equals 1 is used. Every actual cube lies inside [-3,3]^n, so its full-source m=R^n and q=1 exactly. Hence q is in [3lambda/4,lambda].

Every y in Y is captured by every receiver. The baseline definition gives |w_i-y_i|<=||w||_infinity+delta<=R0(w)/2. For U and V, the exact worst-coordinate inequalities are |center_i|+rho+delta<R/2, separately checked for their first and other coordinates. In particular the newly nonzero V coordinates do not break common capture or full-source support.

## Original high-past, mass, clock and exterior gates

All receivers outside U have actual side at most 3/2. The exact inequalities (4/3)^4>3>exp1 imply (4/3)^10000>exp100, so all their masses are strictly below 2^n/K. The strict exp1 upper bound is also checked by a rational Taylor remainder. Thus they all belong to the original GLOBAL strict past for every u in U and y in Y.

The baseline inverse-mass capacity is

integral_E R0(w)^(-n)dw
 = (1-2delta)^n + n integral_1^(3/2) (r-2delta)^(n-1) r^(-n)dr
 >49n/150.

Indeed Bernoulli gives (1-2delta)^(n-1)>=1-2delta(n-1)>49/50, while log(3/2)>1/3. Both numerical margins are certified rationally. Removing the baseline contributions of U,V loses less than 2 since R0>=1 and both volumes are below 1. Consequently

Z_y(2^n/K-)>49n/150-2=9794/3>310272/119=H=h_*.

At the actual terminal clock atom r=b, J_y(b)>=Z_y>H. Both override sides are at most b; the physical atom has its actual positive weight 2^(-n). No menu replaces the continuum baseline selector, and no source probe is substituted for this global-past integral.

The first coordinate separation on U times V is in [11/10-2rho,11/10+2rho]; other coordinate separations are in [1/2-2rho,1/2+2rho]. The first remains maximal. From (21/20)^100>101, alpha<21/20, and the separation lower bound exceeds 21/20. Hence 2||u-v||_infinity>alpha R_u throughout U times V. The far mass gate holds by the stronger all-non-U estimate above. The ratio R_v/R_u=5/8<3/4 also continues to exclude the former R368 ratio branch.

## New strict excess complement

With actual R_u=2, R_v=5/4, define e_i=(2|u_i-v_i|-(R_u-R_v))_+. The entire first-coordinate excess lies in [29/20-4rho,29/20+4rho]. Unlike R369, every other coordinate now has a strictly positive excess in [1/4-4rho,1/4+4rho]. Therefore the WHOLE-BOX sum obeys

sum_i e_i in [625299/250,625301/250] = [2501.196,2501.204].

For beta=1+1/n and w=max(a,R_v/beta)=12500/10001, the actual paid threshold is

Tplus=n[(1+beta)w-R_u]^2/(4 beta w)
     =49985001125/100020001.

The strict lower gap is

625299/250 - Tplus =50046156324049/25005000250 >2000.

Thus every actual pair in U times V has sum_i e_i>Tplus, and lies OUTSIDE B-plus, not on its paid equality boundary. The near-zero old N/A excess thresholds also fail. All remaining pair masks in the R370 source formula are simultaneously satisfied on the same positive-volume product Y times U times V.

## Positive probe, full source and conditional signed-template statement

Using the actual terminal clock atom and the actual-center bound J_b<=1+n log2<1+n yields the original positive probe lower bound

2^(-n) (2delta)^n (2rho)^(2n)
 *[2^n-(5/4)^n]/[2^n (5/4)^n (1+n)] >0.

This is a positive lower bound for the FULL source/receiver integral, obtained by retaining its nonnegative part on the positive-volume boxes; f is not replaced by an isolated source packet. Its factors are extremely small and W=6^10000. No lower bound on a significant full-G fraction, no optimality and no general obstruction to an upper estimate is claimed. The construction uses the stated epsilon0/H; it is not asserted to pass every later absorption allocation or all terminal-path qualifications.

For this particular constant full source, f(y)-q_v=0 on ALL actual cube-supported source kernels, not only on Y: all actual cubes lie inside the region f=1, and q_v=1. Thus a proposed exact same-kernel substitution f=q_v+(f-q_v) would have globally zero signed deviation on its actual source support. The assertion that any NEW signed-template expression is exactly the original remainder is CONDITIONAL on independent audit of that precise formula and its unchanged J/past/clock/mass masks. The witness does not certify that algebraic migration by numerical positivity or permit a reference-density renormalization.

## Actual local execution

Two fresh local standard-library Python processes passed 46 exact Fraction assertions: initial geometry 18, old-gate pressure 17, expanded excess/positive-margin 11. The script prints a small JSON certificate, writes no extra result file, and has no historical-script import dependency. Reproduce with

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r370_witness_check.py
```

The local arithmetic checks accompany the analytic continuum argument above. They do not replace its actual-Lebesgue/global-source reasoning or establish a root-order theorem. Only r370_witness_check.py and this note were authored.
