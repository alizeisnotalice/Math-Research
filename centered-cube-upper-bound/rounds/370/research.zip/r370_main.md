# 第370轮：全半径交叠极值包络与原来源截平预算

## 结论与边界

本轮的主要新结果是对真实中心 Lebesgue 测度及任意可测共同半径选择器的交叠极值上界。它保留立方体交叠，而不把每个半径层都用独立的满体积支付。该几何定理对任意半径跨度成立，常数为 $O(\sqrt{n\log(n+2)})$，不含尺度层数或 $\log(R/a)$ 损失。

它在第369轮尚未支付的原交通上给出一个真实正部分的预算：把小立方体的来源因子精确分为 $\min(f,q_v)$ 与 $(f-q_v)_+$，支付前者。实际质量、选择器、$J$、严格过去和物理时钟都继续由完整 $f$ 定义。后一项仍未支付。一般一致弱型上界并未闭合。

## 1. 全半径极值几何定理

固定边长 $R$ 的轴平行立方体 $Q_R(u)$，任意 $0<a\le R$，及任意可测选择器 $s(v)\in[a,R]$。设
\[
\Theta_s(v)=\frac{|Q_R(u)\cap Q_s(v)|}{s^n},\qquad
\mathfrak a_n=\sqrt{\tfrac14+\tfrac12\log(1+\sqrt n)}.
\]
则
\[
\int_{\mathbb R^n}\Theta_{s(v)}(v)\,dv
\le R^n\left[1+\frac{n(1-a/R)}{2(\sqrt n+1)}
+2\sqrt n\mathfrak a_n(1-\sqrt{a/R})\right].
\]
特别地，右端不超过 $R^n[1+\sqrt n/2+2\sqrt n\mathfrak a_n]$。任意小的正下限都使用同一常数；单调极限也控制所有 $0<s\le R$ 的上包络。这里的张量概率仅表示中心的体积，绝不假定真实来源 $f$ 的坐标独立。

在当前单 octave 合同中 $a/R\ge1/2$，可统一使用
\[
\Gamma_n=1+\frac{n}{4(\sqrt n+1)}
+2\sqrt n\mathfrak a_n(1-1/\sqrt2).
\]

证明的关键是对归一化一参数梯形乘积密度 $p_s=\Theta_s/R^n$ 保留零均值对数导数。令 $r=s/R$，单坐标得分 $X=s\partial_s\log p_s^{(1)}$ 在平台为零，在斜坡（边界深度 $d$）为 $s/(2d)-1$，满足
\[
\mathbb EX=0,\quad X\ge-1/2,\quad
\mathbb P(X>t)=\frac{r}{4(t+1)^2}\quad(t\ge0).
\]
其全二阶矩发散，不能直接使用 Fisher 信息。取 $L=\sqrt n$，令 $Y=\min(X,L)$、$Z=(X-L)_+$，则
\[
\mathbb EZ=\frac{r}{4(L+1)},\quad \mathbb EY=-\mathbb EZ,
\quad \mathbb EY^2\le r\left[\tfrac14+\tfrac12\log(1+L)\right].
\]
对中心乘积测度的独立坐标，中心化后使用 Cauchy--Schwarz：
\[
\|s\partial_s p_s\|_1\le \sqrt{nr}\mathfrak a_n
+\frac{nr}{2(\sqrt n+1)}.
\]
逐点绝对连续、非负积分及基本微积分给出 $\int\sup_{a\le s\le R}p_s\le1+\int_a^R\|\partial_s p_s\|_1ds$。积分 $\sqrt{s/R}/s$ 和 $(s/R)/s$ 即得主式。平台、斜坡的连接连续；零密度边界按零处理，不引入边界原子。详证及有限检查在 geometry 附件。

## 2. 同一原积分的真实来源拆分

保持第369轮原合同，记 $G=G_{out,\neg B^+}$。小端半径小于大端由远质量门和完整 $q$ 带保证。将只依赖接收对的全部原几何与质量门记为 $S(u,v)$。定义
\[
\omega_u(y)=h_*R_u^n\int_{[R_u,b]}\ell(dr)
\frac{\mathbf1_{J_r(y)\ge H}\mathbf1_{Z_y(m_u/K-)>h_*}}{J_r(y)}.
\]
分母为零时取零。原严格过去已包含在物理前缀中，故非零处 $J_r(y)>h_*$，而 inclusive 时钟尾等于 $R_u^{-n}$；于是 $0\le\omega_u\le1$。原积分精确为
\[
G=\frac1{h_*}\int_E\frac{du}{R_u^n}\int_Edv\,S(u,v)(1-m_v/m_u)
\int_{Q_u\cap Q_v}\omega_u(y)\frac{f(y)}{m_v}\,dy.
\]
在此式中逐点替换 $f=\min(f,q_v)+(f-q_v)_+$，定义 $G_{floor}$、$G_{excess}$，得到精确正分解
\[
G=G_{floor}+G_{excess},\qquad
G_{floor}\le\frac{\Gamma_n}{h_*}|E|
\le\frac{\varepsilon_0\Gamma_n}{1+\sqrt n}X_q.
\]
这里只截平来源积分中的一个因子；没有对输入作截断后重算任何对象。证明利用 $\min(f,q_v)/m_v\le R_v^{-n}$，正丢门，使用几何定理，再积分真实大端 $du$。

亦可在原 $\omega$ 内精确保留有符号式 $G=T+D_+-D_-$，其中 $T$ 使用均匀模板 $R_v^{-n}$，$D_\pm$ 使用 $(f-q_v)_\pm/m_v$。$D_+=G_{excess}$，$T-D_-=G_{floor}$。负项已在这一分解中使用一次，不可再次支付旧平方或旧来源费。$D_+\le G\le X_q$ 且 $D_-\le T<\infty$，不存在无穷减无穷。

## 3. 仍需攻坚的实际对象

新的未付交通 $G_{excess}$ 保留原所有门及真实权，来源因子是 $(f(y)-q_v)_+$。该因子允许任意集中；本轮没有用薄层体积控制其质量。固定各个 $v$ 虽有 $\int_{Q_v}(f-q_v)=0$，但共同捕获区域、$J^{-1}$ 与严格过去依赖 $y$，因此不能免费取消偏差。

二来源附件给出另一精确工具：$G=D_{cut}-O_{overhang}$；近配对误差用内外两侧真实边界质量的乘积控制。分离来源量和该边界乘积均没有新的根阶预算。它不是本轮 floor 付款的追加负信用。

本轮全半径几何定理不自动连接全尺度原极大算子的入口、软层或历史时间项。完整费用、参数重分配与未付接口另见 ledger；一般证明仍未完成。
