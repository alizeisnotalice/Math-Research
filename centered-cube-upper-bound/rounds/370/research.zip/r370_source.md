# R370 — Two-source cut identity with a measurable separating face

**Result and limit.** The exact residual admits a two-source cut representation with a nonnegative overhang subtraction. Its outside-center gate selects one actual coordinate, without an n-fold union bound, and forces a definite one-sided displacement of every common source. This gives a quantitative separated-source fraction in terms of an explicit posterior cap mass. An exact near-pair error is bounded by a product of two actual source boundary masses. Neither that product nor the separated-source integral is paid here. In particular this note supplies no additional root-order receipt to R369's ledger.

## 1. Original field and residual, unchanged

Keep f≥0 in L1, actual receivers u∈E with a≤R_u≤b≤2a,

    Q_u=u+[-R_u/2,R_u/2]^n, m_u=f(Q_u)=q_u R_u^n,
    q_-=3λ/4≤q_u≤λ, μ(du)=du/m_u,
    J_y(r)=∫_(R_w≤r) 1_(Q_w)(y) μ(dw),
    Z_y(t-)=∫_E 1_(Q_w)(y)1_(m_w<t) μ(dw),
    ell=b^(−n)δ_b+n r^(−n−1)1_(a,b)dr,
    X_q=∫_E q_u du, W=∫f.

Set K=exp(√n), α=(1+√n)^(1/n), β=1+1/n and h_*=(1+√n)/(ε_0q_-). The receiver-pair mask χ_r(u,v) is exactly

    R_u,R_v≤r; m_u>K m_v;
    2||u−v||_∞>αR_u;
    Σ_i (2|u_i−v_i|−(R_u−R_v))_+ > T_+(u,v),

where, with w=max(a,R_v/β),

    T_+(u,v)=n[(1+β)w−R_u]^2/(4βw).

Thus χ retains the complement of R369's paid B^+; equality remains on the paid side. Put

    ω_(r,u)(y)=1_(J_y(r)≥H)1_(Z_y(m_u/K-)>h_*)/J_y(r),

with zero on J=0. The exact current remainder is

    G=∫ell(dr)∫ μ(du)μ(dv) χ_r(u,v)
                      (m_u−m_v) ∫_(Q_u∩Q_v) f(y)ω_(r,u)(y)dy.       (1)

All subsequent identities retain this ω. In particular the strict past is not moved from y to a second source z, and J is neither recomputed nor symmetrized.

## 2. Exact two-source identity, including the overhang

Fix an actual pair and abbreviate

    A=Q_u∩Q_v, B=Q_u\Q_v, C=Q_v\Q_u,
    M=m_u, m=m_v, I=f(A), b=f(B)=M−I, c=f(C)=m−I,
    I_ω=∫_A f(y)ω(y)dy.

Then

    (M−m)I_ω = b I_ω − c I_ω
       = ∫_(A×B) f(y)ω(y)f(z)dy dz − f(C)I_ω.          (2)

Consequently G=D_cut−O_overhang exactly, where both terms integrate the corresponding right-hand expressions against the SAME χ μ(du)μ(dv)ell(dr). Both are nonnegative, and O_overhang≤D_cut on the far-mass domain. The unweighted identity requested in the task is simply

    f(Q_u\Q_v)f(Q_u∩Q_v)=∫_(A×B)f(y)f(z)dy dz.         (3)

The useful distinction in (2) is that the small-cube mass in the original loss is m, not I: replacing it silently by I discards precisely O_overhang. Also I≤m<M/K, so b≥(1−1/K)M. These facts do not imply that all cut pairs have a positive spatial separation bounded below uniformly.

No undefined subtraction is used. Indeed D_cut≤X_q: replace b by M, drop χ and the past/high-J restrictions, integrate v first to recover J_y(r), cancel J, and use m_uμ(du)=du and ell([R_u,b])=R_u^(−n). This is only the old first-moment bound, not a new small-X estimate. It also proves finiteness of every positive term below.

## 3. A single separating coordinate and a quantitative source fraction

Choose i=i(u,v) as the smallest index attaining max_j|v_j−u_j|, and let ε=sign(v_i−u_i). This is a measurable selection fixed by the actual receiver pair, with no source-dependent receiver choice and no sum over n faces. Write R=R_u, s=R_v and

    d=ε(v_i−u_i)−s/2 > (αR−s)/2.

Every y∈A satisfies

    ε(y_i−u_i)≥d.                                    (4)

Matching gives s/R<γ, where

    γ=(λ/(q_-K))^(1/n)<1,
    d>d_*=(α−γ)R/2>0.                               (5)

The scale d_* is explicit; no asymptotic constant has been discarded. For t>0 let

    B_t^−={z∈Q_u: ε(z_i−u_i)≤d−t},
    C_t=f(B_t^−).

This cap is disjoint from A up to Lebesgue-null cube boundaries, and every (y,z)∈A×B_t^− has ||y−z||_∞≥t. Thus the actual weighted separated-source integral

    S_t=∫_(A×B) f(y)ω(y)f(z)1_(||y−z||_∞≥t)dy dz

satisfies the quantitative lower bound

    S_t≥C_t I_ω,
    S_t/(b I_ω)≥C_t/b whenever b I_ω>0.               (6)

For example t=d_* permits using the simpler opposite-center half-cube

    {z∈Q_u: ε(z_i−u_i)≤0} ⊂ B_(d_*)^−.

If this half-cube has posterior mass at least θM, then

    S_(d_*)≥θM I_ω≥θ b I_ω.                          (7)

This is a genuine quantitative dispersion criterion using the same f and actual pair, not a source-volume criterion. The q-band alone has not been shown to ensure θ>0, even after integrating the original residual. Formula (7) is a lower bound for a retained source-pair quantity, not an upper budget for G.

## 4. Exact near-pair complement and actual boundary-mass error

Define inner depth δ_v(y)=dist_∞(y,Q_v^c) for y∈Q_v. For t>0 put

    B_in,ω(t)=∫_A f(y)ω(y)1_(δ_v(y)<t)dy,
    B_out(t)=∫_(Q_u\Q_v) f(z)1_(dist_∞(z,Q_v)<t)dz.

Let N_t be the same integral as S_t with ||y−z||_∞<t. Then

    b I_ω=S_t+N_t,
    0≤N_t≤B_in,ω(t) B_out(t).                         (8)

The proof is pointwise: a near cut pair crosses the boundary of Q_v, so y has inner depth <t and z lies in the outer t-neighborhood. Tonelli then bounds its two-source integral by the product of these two ACTUAL source masses. There is no estimate by strip volume or by a density ceiling.

For any measurable pair-dependent t>0, substitute (8) into (2) under the original receiver and clock measure. With the resulting integrated quantities denoted by the same letters,

    G = S_t + N_t − O_overhang
      ≤ S_t + E_boundary(t) − O_overhang,
    E_boundary(t)=∫ell∫χ μ(du)μ(dv) B_in,ω(t)B_out(t). (9)

All terms retain q, m, full J, strict past, actual du and the terminal clock atom. E_boundary(t)≤D_cut≤X_q. This last estimate is not absorbable for arbitrary small ε; it is the precise remaining cost of converting the cut product into uniformly separated source pairs. The other term S_t also has no root budget established here. One cannot claim payment by retaining its positive value as if it were an available negative square: R369's positive residual has no such extra subtraction.

The exact identity (9), together with (6), identifies two separate requirements for a future proof: control the original weighted near-face source product using matching, and settle the separated-source term with the shared actual receiver selector. No hypothesis of independent source coordinates, source density, or source-posterior symmetry is made. The source z is an additional integration variable only; it does not inherit y's past or high-J gate.

## 5. Local checks and their scope

The embedded Fraction script checks (2), (6), and (8) on finitely supported weighted scalar data, including zero overlap, zero marks, boundary ties, one-sided marks, and positive outer overhang. These are exact checks of the algebra and pointwise geometric implications, not purported actual L1/q-band/high-past fixtures and not evidence of a general root estimate. The proofs above apply to actual L1 sources by Tonelli. No original receiver field is replaced by these diagnostic arrays.

~~~python
from fractions import Fraction as F
from itertools import product

checks=0
points=[(F(i,4),F(j,4)) for i in range(-5,6) for j in range(-5,6)]
u=(F(0),F(0)); R=F(2)

def inside(z,center,side):
    return all(abs(x-c)<=side/2 for x,c in zip(z,center))

def dist(z,w):
    return max(abs(a-b) for a,b in zip(z,w))

for center in ((F(3,4),F(0)),(F(1),F(1,4)),(F(-1),F(1,2))):
    for side in (F(1,2),F(1),F(3,2)):
        i=min(range(2),key=lambda j:(-abs(center[j]),j))
        sign=1 if center[i]>0 else -1
        d=abs(center[i])-side/2
        for pattern in range(4):
            weights={z:F((k*(pattern+1)+3)%9) for k,z in enumerate(points)}
            marks={z:F((k+pattern)%5,4) for k,z in enumerate(points)}
            A=[z for z in points if inside(z,u,R) and inside(z,center,side)]
            B=[z for z in points if inside(z,u,R) and not inside(z,center,side)]
            C=[z for z in points if inside(z,center,side) and not inside(z,u,R)]
            I=sum((weights[z] for z in A),F(0))
            b=sum((weights[z] for z in B),F(0))
            c=sum((weights[z] for z in C),F(0))
            Iw=sum((weights[z]*marks[z] for z in A),F(0))
            assert (I+b-I-c)*Iw==b*Iw-c*Iw
            checks+=1
            for t in (F(1,8),F(1,4),F(1,2),F(1)):
                sep=sum((weights[y]*marks[y]*weights[z] for y in A for z in B if dist(y,z)>=t),F(0))
                near=sum((weights[y]*marks[y]*weights[z] for y in A for z in B if dist(y,z)<t),F(0))
                assert sep+near==b*Iw
                checks+=1
                cap=sum((weights[z] for z in points if inside(z,u,R) and sign*z[i]<=d-t),F(0))
                assert sep>=cap*Iw
                checks+=1
                inner=sum((weights[y]*marks[y] for y in A if min(side/2-abs(y[j]-center[j]) for j in range(2))<t),F(0))
                outer=sum((weights[z] for z in B if max(max(abs(z[j]-center[j])-side/2,F(0)) for j in range(2))<t),F(0))
                assert near<=inner*outer
                checks+=1
print('PASS',checks,'exact Fraction checks')
~~~

Execution record: the embedded script was actually run with local Python 3 and returned `PASS 468 exact Fraction checks` (exit status 0).
