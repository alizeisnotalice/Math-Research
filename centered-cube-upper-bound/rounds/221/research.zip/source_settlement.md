# R221：共同 q 下的真实来源结算与尚未付的接收占用

本稿没有取得原剩余的根阶付款。已撤回“外分母随接收点变化”的错误障碍，并给出保全硬来源位置的两路截断界、原正交通的完整联合上界，以及固定物理状态下接收胞可以怎样合法合并。单胞质量已有原容量价格；未解决的是原自适应物理状态与接收胞的实际加权占用，不能把每胞常数直接求和后称为来源预算。

## 1. 原分母与测度：明确纠正

实际核读 R128 `proof.md:604–658` 的 RT1–RT5：外分母为共同 $q\in[3\lambda/4,\lambda]$。它不是 $Q_x^*$，也不能因符号省略误认成任意 $Q(x)$。三腿测试核另记

\[
Q_x^*(v)=(K_1(x-v)+K_2(x-v)+J(x-v))/3.
\]

原 $\nu_V\le f$，原 hardband 给 $h_H*f(x)\le4\lambda$，因此在合法 hardband 锚点及允许尺度上

\[
q^{-1}(h_H*\nu_V)(x)\le16/3.
\tag{SS1}
\]

$\nu_V\le f$ 不意味着 $\nu_V\le\beta_V$。原 FIRST 为同一接收点上的 $\int p_y\,d\beta_V\le q$、$\int Q_x^*\,d\nu_V\le q$；后者只给 $K_1\nu+K_2\nu\le3q-J\nu$。

以下保留原正量

\[
P=2\Lambda\mathbb E\sum_{V,j}\int
\frac{a_\omega(x,y,z)}q p_y(x)h_R(x-z)
M\rho_0(v)\delta_t(v,u)
\,dx\,\beta_V(dy)\nu_V(dz)\Pi_t(dv)\Pi_t(du)\frac{dt}{t},
\tag{SS2}
\]

其中 $\delta_t=(k_t(v)-k_t(u))_+$。$M$ 包含原 high、good×bad、mixed、FA、后缀、历史和当前浮动带之外的全部门；$\rho_0(w_t-h_0)>L_0J/p$ 保持原定义。两份 $\Pi_t$ 已含两个 $e_t$ 分母。固定 $(\omega,V,j,y,t)$ 后 $\Pi_t$ 独立 $x,z$，但物理 $L,R,s,g$、终端门、捕获及 $a_\omega$ 仍须按其实际依赖保留。

## 2. 保硬来源位置的共同核截断

先固定全部物理参数 $\theta=(L,R,s,A,\sigma,g,j,b)$，$A\in[L,b]$；这不是对原自适应参数的免费冻结。记

\[
\mathcal H_\theta(x;y,v,z)
=h_R(x-z)\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)},
\quad c_\theta=(c_j/g)^n,
\]

\[
\Lambda_\theta(y,v,z)
=\min\left\{1,\sqrt{\frac{w_g(y,z)w_g(v,z)}{w_g(y,v)}}\right\}.
\]

有效来源上 $w_g(y,v)>0$。R220 新定理与旧分离几何取较小，严格给

\[
\int\mathcal H_\theta(x;y,v,z)\,dx
\le c_\theta\sqrt{w_g(y,v)}\Lambda_\theta(y,v,z).
\tag{SS3}
\]

$w_g(v,z)$ 只是同一几何核改中心后的值，不是原后验。

对任意可测接收集 $E$，令

\[
E^{+R}=\{z:\operatorname{dist}_\infty(z,E)\le R/2\}.
\]

这是闭邻域，因距离函数连续而可测；约定空集的距离为 $+\infty$。若 $Q_R(z)\cap E\ne\varnothing$，则 $z\in E^{+R}$；本稿只使用这一包含关系上界，不声称对任意 Lebesgue 可测 $E$ 两集合相等。不论是否保留原 $B=0$，非负 Tonelli 与 SS3 给

\[
\frac1q\int\nu_V(dz)\int_E
\frac{\mathcal H_\theta(x;y,v,z)}{\sqrt{w_g(y,v)}}\,dx
\le\frac{c_\theta}q
\int_{E^{+R}}\Lambda_\theta(y,v,z)\,\nu_V(dz).
\tag{SS4}
\]

这是真实局部硬来源积分，未改成 $\|\nu_V\|/q$。

若 $E$ 中每个接收点均满足该固定尺度 $R$ 的原 hardband，SS1 又给第二路上界

\[
\frac1q\int\nu_V(dz)\int_E
\frac{\mathcal H_\theta}{\sqrt{w_g(y,v)}}\,dx
\le\frac{16}{3\sqrt{w_g(y,v)}}
\int_E\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)}\,dx.
\tag{SS5}
\]

因此 SS4 与 SS5 可取较小，完整保留共同 $q$、硬来源位置与真实 $dx$。这不是一个已付全局来源价。特别，若 $a_\omega$、历史或捕获权随 $x,z$ 变化，不能先套无权 SS4 后将这些权当成常数移出；必须留在下一节联合积分中。

## 3. 原正交通的合法共同半密度上界

在原 good 端，

\[
p_y(x)w_g(y,v)\le\frac K3\sum_{a=1}^3K_a(x-v).
\]

于是逐点有

\[
p_y(x)\le\sqrt{K/3}\sum_{a=1}^3
\frac{\sqrt{p_y(x)K_a(x-v)}}{\sqrt{w_g(y,v)}}.
\tag{SS6}
\]

定义三个实际目标腿的原联合接收项

\[
\begin{split}
\mathfrak J_a={}&\mathbb E\sum_{V,j}\int
\delta_t(v,u)\,\beta_V(dy)\nu_V(dz)\Pi_t(dv)\Pi_t(du)\frac{dt}{t}\\
&\quad\times\int
\frac{a_\omega(x,y,z)}q M(x,y,z,v,u,t)\rho_0(v)
\frac{h_{R(x)}(x-z)\sqrt{p_y(x)K_a(x-v)}}{\sqrt{w_{g(x)}(y,v)}}\,dx .
\end{split}
\tag{SS7}
\]

$K_a$ 使用该接收点实际选取的参数，不能在这里预先冻结。非负 Tonelli 与 SS6 无附加条件地给

\[
\boxed{\quad P\le2\Lambda\sqrt{K/3}\sum_{a=1}^3\mathfrak J_a.\quad}
\tag{SS8}
\]

SS7 保留两份后验、正变差、bad 端、同一捕获、时间窗、原历史与全部接收点权。没有使用 $\delta\le n$、没有把 $\nu$ 换成 $\beta$、没有消耗负信用。它明确指出新核工具要控制的实际联合项，而不是引入一个假定满足 Schur 条件的新问题。

## 4. 接收胞合计中可以严格取消的部分

考虑一个真正固定的物理状态 $\theta$，以及任意有限或可数个两两不交的接收胞 $U_i$。定义保原硬门的子测度

\[
\mathcal K_{\theta;y,v,z}(dx)
=\frac{1_{\{B(v)=0\}}\mathcal H_\theta(x;y,v,z)}
{c_\theta\sqrt{w_g(y,v)}}\,dx.
\]

其总质量由 SS3 不超过 $\Lambda_\theta(y,v,z)\le1$。因此

\[
\sum_i\mathcal K_{\theta;y,v,z}(U_i)
=\mathcal K_{\theta;y,v,z}(\cup_iU_i)
\le\Lambda_\theta(y,v,z).
\tag{SS9}
\]

所以固定状态下，胞的几何数量本身不必逐个支付：应先合并实际截断积分，再调用一次 SS3。若每胞先换成同一个常数，便主动丢失了 SS9 的互斥质量。

对于实际剩余权

\[
W(x,y,z,v,u,t)=a_\omega(x,y,z)M(x,y,z,v,u,t)\rho_0(v),
\]

正确的合计对象仍是

\[
\sum_i\int_{U_i}W\,d\mathcal K_{\theta;y,v,z}
=\int_{\cup_iU_i}W\,d\mathcal K_{\theta;y,v,z}.
\tag{SS10}
\]

SS9 不使右侧等于一，也不授权去掉 $W$。特别原 $a_\omega$ 没有在本稿被假定小于一；原 high/good/bad/history 对不同胞也没有被认作相同。

若实际选择的物理状态随胞变化，则存在不同 $\mathcal K_{\theta_i;y,v,z}$；SS9 不再给 $\sum_i\mathcal K_{\theta_i}(U_i)\le1$。对任意接收点依赖的连续状态映射，也不能通过对状态“条件化”来规避此问题：状态水平集上的条件接收测度通常不是原 $dx$，固定核的 Lebesgue 积分定理不能直接套给它。公共 soft 网格只支付固定尺度下的软度选择，不能同时支付 $L,R,g$ 或 $W$。

## 5. 原局部容量确实消除了什么

来源结构审计给出如下合法单胞结算（详见同轮来源定位稿）：固定原状态、原 hardband 锚点 $x_0$，$U\subset Q_\ell(x_0)$，$R+\ell\le b$ 且 $\ell\le\kappa R/n$。所有能贡献的硬来源满足 $z\in Q_{R+\ell}(x_0)$。用原 $\nu_V\le f$ 和锚点处合法尺度的 SS1，

\[
\nu_V(Q_{R+\ell}(x_0))
\le\frac{16}{3}q(R+\ell)^n.
\]

故 SS4 的右侧至多

\[
\frac{16}{3}\left[\frac{c_j(R+\ell)}g\right]^n
\le\frac{16}{3}\left[\gamma(1+\kappa/n)\frac R{\max(L,R)}\right]^n
\le\frac{16}{3}e^{1+\kappa}.
\tag{SS11}
\]

这里最后两步使用实际唯一比例带 $c_j\le\gamma\min(L,R)/g$。这一价格没有全 $\nu$ 质量，也没有未命名的指数常数。$R=b$ 不允许任何正 $\ell$ 满足 $R+\ell\le b$；不能将端点强塞进 SS11。

SS11 消除了局部接收核中 $c_\theta\|\nu_V\|/q$ 的虚大成本，但它是每胞价格。把它代入 SS7 并求和，会保留至少如下实际量：

\[
\mathbb E\sum_{V,j}\int
\delta_t(v,u)\,\beta_V(dy)\Pi_t(dv)\Pi_t(du)\frac{dt}{t}
\sum_i\frac{c_{\theta_i}}q
\int\nu_V(dz)\int_{U_i}W\,d\mathcal K_{\theta_i;y,v,z}.
\tag{SS12}
\]

这只是将原实际选取状态可合法固定的部分按胞写出；若需尺度包络，必须先证明其支配与费用，再得到对应的 SS12。SS12 中的来源互斥、$\delta_t$、bad 端和 $W$ 决定最终价格。不能将 $\sum_i$、$\int\beta\Pi_t^2\delta_t\,dt/t$ 或 $W$ 各自换成一。若有公共 soft 网格，还须保其 $4|S_n|$ 费用；若有物理尺度网格，费用另外保留。

## 6. 最早尚未证明的具体结算步骤

原根阶目标要求控制的是 SS7，或在已证状态包络下等价上控的 SS12。最早尚缺的步骤是：**把实际接收位置、其物理状态、完整历史权及原双后验正交通，联合压到一次来源质量预算。**

现在可以严格区分三个层面：

1. 共同 $q$ 已由原文确认，不能再列为接收点变权的障碍。
2. 每个有合法 hardband 锚点且满足尺度余量的小胞，硬来源质量由 SS11 支付；不需要全 $\nu$ 范数。
3. 原 SS12 的加权合计没有由前两项推出。固定状态内可用 SS9 合并互斥胞，但跨实际状态的共同接收占用、原 $W$ 和正交通尚未有根阶价格。任意每胞常数或有限状态菜单都没有授予这个联合价格。

一个真正完成结算的后续命题必须直接对 SS7/SS12 的原权给出 $\varepsilon X+C_\varepsilon\sqrt n\,\mathrm{polylog}(n)W_A$（或明确不交新增子支的相应价格），且覆盖 $R=b$、全部实际尺度状态与 clock 域。不应改写成一个未经验证的抽象 Schur 假设。原 negative 仍未消费，R218 浮动已付带不重复领取。

本稿实际使用本机 Python `fractions.Fraction` 运行8个有理参数组合：$n=4,8,16,32$，$L,R$ 为 $1,9/16$ 的两种顺序，$b=9/8,g=3/4,\kappa=1/4$，并设 $\gamma=1+1/n$、$c_j=\gamma\min(L,R)/g$、$\ell=\kappa R/n$。逐项断言 $b/2\le L,R\le b$、$R+\ell\le b$，以及精确等式 $c_j(R+\ell)/g=\gamma(1+\kappa/n)R/\max(L,R)$；8项全部通过。该运行仅检查 SS11 的有理尺度代数，不认证这些参数是全部原历史实例，也不代替一般来源结算证明。没有进行反例搜索。最终状态：单胞真实来源价与固定状态胞合并均严格；全原正剩余尚未付款。
