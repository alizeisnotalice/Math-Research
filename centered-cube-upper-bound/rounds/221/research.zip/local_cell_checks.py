#!/usr/bin/env python3
"""Exact finite local-cell checks, not a universal proof or global budget.

Definition audit: n positive integer, kappa>=0, ell>=0, b/2<=L,R<=b,
g^2=LR, m=min(L,R), gamma=1+1/n; a=cj/g is rationally bracketed by
m/(LR)<=a<=gamma*m/(LR). No sqrt or float is required.
The last comparison with exp(1+kappa) is analytic log(1+x)<=x, not numerical.
"""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent

def rat(x):return f'{x.numerator}/{x.denominator}'
def ceil_fraction(x):return -((-x.numerator)//x.denominator)
def case(n,b,L,R,kappa,ell_choice,a_choice):
    gamma=F(n+1,n);m=min(L,R);ellmax=min(kappa*R/n,b-R)
    ell=F(0) if ell_choice=='zero' else ellmax if ell_choice=='maximum_feasible' else ellmax/F(10**9)
    B=R+ell;alo=m/(L*R);ahi=gamma*alo;a=alo+a_choice*(ahi-alo)
    left=a*B;right=gamma*(1+kappa/n);ratio=left/right
    # Direct integer power comparison; large exact powers are never serialized.
    numerator_power=pow(ratio.numerator,n);denominator_power=pow(ratio.denominator,n)
    checks={'n_positive_integer':n>=1,'b_positive':b>0,'scale_ranges':b/2<=L<=b and b/2<=R<=b,'kappa_nonnegative':kappa>=0,'ell_range':0<=ell<=kappa*R/n,'B_le_b':B<=b,'a_exact_interval':alo<=a<=ahi,'base_nonnegative':left>=0,'aB_le_gamma_one_plus_kappa_over_n':left<=right,'direct_integer_power_comparison':numerator_power<=denominator_power}
    assert all(checks.values())
    vals={'b':b,'L':L,'R':R,'g_squared':L*R,'m':m,'gamma':gamma,'kappa':kappa,'ell':ell,'ell_max_feasible':ellmax,'B':B,'a_min':alo,'a_max':ahi,'a':a,'a_choice_fraction':a_choice,'aB':left,'gamma_times_one_plus_kappa_over_n':right,'base_ratio':ratio,'base_slack':right-left,'m_over_L':m/L}
    return {'n':n,'ell_choice':ell_choice,'branch':'R_le_L' if R<=L else 'R_gt_L','values':{k:rat(v) for k,v in vals.items()},'checks':checks,'power_check':{'exponent':n,'exact_ratio_expression':f'({rat(ratio)})^{n}','ratio_numerator_power_bit_length':numerator_power.bit_length(),'ratio_denominator_power_bit_length':denominator_power.bit_length(),'direct_integer_power_comparison_passed':True},'last_exponential_comparison':'gamma^n*(1+kappa/n)^n <= exp(1+kappa) follows analytically from log(1+x)<=x'}

def feasibility(n,kappa,delta):
    b=F(1);r=(1-delta)*b;ell=kappa*r/n;B=r+ell;threshold=kappa/(n+kappa);by_B=B<=b;by_delta=delta>=threshold
    assert by_B==by_delta
    if delta>0:
        minimum_n=max(1,ceil_fraction(kappa*(1-delta)/delta));assert (n>=minimum_n)==by_B
        before=minimum_n-1;minimality=minimum_n==1 or (1-delta)*(1+kappa/before)>1
        assert minimality
    else:
        minimum_n=1 if kappa==0 else None
    return {'n':n,'kappa':rat(kappa),'delta':rat(delta),'r_over_b':rat(r/b),'ell_over_b':rat(ell/b),'B_over_b':rat(B/b),'delta_threshold_kappa_over_n_plus_kappa':rat(threshold),'B_le_b':by_B,'delta_ge_threshold':by_delta,'minimum_positive_integer_n':minimum_n,'delta_zero_no_finite_n_if_kappa_positive':delta==0 and kappa>0,'condition_equivalence_exact':True}

def main(output):
    menus=[('initial',(2,4),F(1),[(F(1,2),F(1)),(F(1),F(1,2))],(F(1,4),F(1)),('zero','maximum_feasible'),(F(0),F(1))),('pressure',(16,128),F(1),[(F(1),F(1)),(F(1,2),F(1)),(F(1),F(1,2)),(F(3,4),F(1,2))],(F(0),F(1),F(2)),('zero','maximum_feasible','tiny'),(F(0),F(1,2),F(1))),('expanded',(10000,),F(3,2),[(F(1,2),F(1)),(F(1),F(1,2)),(F(3,4),F(1,2)),(F(1,2),F(3,4))],(F(1,4),F(1),F(2)),('zero','maximum_feasible','tiny'),(F(0),F(1,2),F(1)))]
    stages=[]
    for name,ns,b,scales,ks,ells,ach in menus:
        rows=[case(n,b,b*l,b*r,k,ell,ac) for n in ns for l,r in scales for k in ks for ell in ells for ac in ach]
        worst=max(rows,key=lambda row:F(row['values']['base_ratio']))
        stages.append({'stage':name,'case_count':len(rows),'maximum_base_ratio':worst['values']['base_ratio'],'maximum_case_index':rows.index(worst),'cases':rows});print(name,len(rows),'exact checks passed',flush=True)
    feas=[feasibility(n,k,delta) for n in (1,4,16,128,10000) for k in (F(0),F(1,4),F(1),F(2)) for delta in (F(0),F(1,10000),F(1,1000),F(1,100),F(1,10),F(1,2))]
    result={'schema':'R221_local_cell_exact_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Fraction and arbitrary-precision integers; no floating-point arithmetic','definition_audit':{'g_definition':'g^2=LR, g>0','a_definition':'a=cj/g','a_rational_interval':'m/(LR)<=a<=gamma*m/(LR)','coefficient_identity':'cj*B/g=a*B','length_constraint':'0<=ell<=kappa*R/n and B=R+ell<=b','last_inequality':'log(gamma^n*(1+kappa/n)^n)<=1+kappa by log(1+x)<=x','delta_uniform_sufficient_and_boundary_necessary':'for all r<=(1-delta)b, ell=kappa*r/n is feasible iff delta>=kappa/(n+kappa); necessity evaluated at boundary r=(1-delta)b','delta_degeneracy':'delta>0 requires n>=kappa*(1-delta)/delta; at delta=0,kappa>0 boundary r=b has no feasible positive cell length'},'stages':stages,'sample_count':sum(s['case_count'] for s in stages),'global_sample_maximum_base_ratio':max((s['maximum_base_ratio'] for s in stages),key=F),'boundary_feasibility_case_count':len(feas),'boundary_feasibility_cases':feas,'scope':['Finite exact sample and integer-power checks only, not a universal proof or global closure.','No sqrt approximation, no dimension-order fit, no original source budget or FULL certification.','The final exponential comparison is an explicitly stated analytic implication, not a computed exp enclosure.','For r below the boundary, the delta criterion is uniform sufficient; a particular smaller r can be feasible even if the boundary fails.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'local_cell_checks.json');args=ap.parse_args();main(args.output)
