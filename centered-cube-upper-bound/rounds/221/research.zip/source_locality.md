# R221：原来源支持、共同分母及可实际使用的小接收胞来源价

本稿只恢复与来源结算直接有关的定义，并给一条不含未知 `C_*` 的真实局部核估计。结论是：原外分母是共同常数 `q`，不是依接收点变化的测试核 `Q_x^*`；硬尾 `ν_V` 支持于边长 `256na` 的终端叶，原 hard `z` 还保留实际硬窗口以及原来源对承载门。叶的低均值不足以把整个 `||ν_V||/(q b^n)` 变成根阶。另一方面，原完整 hard band 给每个真实接收锚点处的**全部合法物理尺度**局部质量帽，结合 R220 共同核可在边长 `O(R/n)` 的小接收胞上以显式常数结算全 hard 来源。此单胞结论没有支付所有接收胞的共同重叠，也没有支付连续尺度或 clock。

## SL1 查阅范围与原文证据

首读本轮 task_contract。对指定 R128 proof.md 先 `rg` 定位，只读 RT1–5、支持/原件状态及其必要定义引用；R128 本身并不包含 ν_V、V 的最初构造。因此沿其 R117→R112→R107 的明确引用只恢复下面这些条款，没有通读其余历史证明。

原文记号中 `q` 是标量，`Q_x=x+[-R(x)/2,R(x)/2]^n` 是硬 winner 立方体，`Q_x^*` 是三个合法 future 核的平均。这三者须区分。

| 对象 | 原文位置及实际内容 | 本轮能用的范围 |
|---|---|---|
| 原完整输入与共同 FIRST | [GENERAL_CURRENT_REDUCTION.md:5](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:5)，[同稿:9–13](/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:9)：全边长尺度 `[a,b]`、共同 `q∈[3λ/4,λ]`；`G_s=sup_{a≤L≤b}P_s,L f`，`2λ<G_0≤4λ`；`P_σ,L f=q` 且全部合法 future `P_s,R f≤q` | FIRST 不在 ν、β 或局部子源上重启；`G_0` 的上帽同时控制全部合法 hard 尺度 |
| 本轮原外分母 | [R128 proof.md:604–611](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604)，RT1 明写 `q^−1 p h_R aω dx dβ_V(y)dν_V(z)`，611行重申共同 `q` 与 `ν_V≤f` | 外分母是标量 `q`，不是测试函数的值；不能由后来的大写记号制造其 `x/soft` 依赖 |
| 三腿容量核 | [R128 proof.md:653–658](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:653)，RT5：`Q_x^*=(K1+K2+J)/3`，FIRST 给 `∫Q_x^*dν≤q`、`∫Jdν≤q` 及合法 `K0` 容量 | `Q_x^*` 依实际 x、soft、尺度；它是正核，不是原外标量。只授 `K1ν+K2ν≤3q−Q_J`，不授各核容量为 q |
| 原软/硬叶来源 | [R112 proof.tex.txt:508–530](/Users/zhengzhihao/Desktop/T/output/centered_cube_round112_20261014/proof.tex.txt:508)：`α_V=μ_hi,ω|_V`、`σ_V≤α_V`、`ν_V≤σ_V`；每个正行至多一个 V，整个 Q_x 与 y 都在 V，软核由 `q^−1P_s,L dα_V` 支配 | 这是真实来源支持和正测度支配，不是 ν 与后来 β 的一般比较 |
| V 的几何与均值 | [R107 proof.md:973–1012](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:973)，R9–12：共同格最细全边长 `256na`，终端 V 为该尺寸叶；树质量用 σ，`σ_V=σ_ω|_V`，`||σ_V||<4e^(1/128) λ|V|/√n`；原 Q_x、y 同叶 | V 是宏叶，不是 b 级局部窗口，也不是后验轻块；均值帽作用于原硬输入 σ，不是 f 的点态密度帽 |
| 当前硬尾的来源身份 | [R107 proof.md:1075–1118](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:1075)，R22：从同一 σ_V 的多尺度提取余源删去 top-k pieces 得 ν_V；接收点前冻结，之后不重建 ν | `supp ν_V⊂V`，`ν_V≤σ_V≤1_V f dx`；叶不交，`EΣ_V||ν_V||≤W_hi` |
| 真正的原来源对距离 | [R113 proof.tex.txt:69–77](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:69)，B5：`D_V(y)=V∩{||z−y||_1≤17na}∩{||z−y||_∞≤b(5log n+1/2)}`，原实际来源对由它承载 | 当保留其原门时可保 `z∈D_V(y)`；该范围仍远大于 b，不是一个免费小盒 |
| block 的含义 | [R114 ratio_settlement.md:28–43](/Users/zhengzhihao/Desktop/T/output/centered_cube_round114_20261014/ratio_settlement.md:28)：`H_j(t)=q max(t^n,√n c_(j+1)^n t^n,√n(t²/b)^n)`；`A_j,t(y)` 是原森林路径上最粗 `h(A)≤H_j(t)` 节点，无轻节点时补原最细格 | block 按原合格硬质量 h 阈值选，不按 b 或 R 的物理边长定义；不是终端 V、maxflow cut 或运输 piece |
| 原 forest 质量 | [R113 proof.tex.txt:100–120](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:100)：`h(A)=μ_hi(A∩B)`，`B={t_C≤b}`；`Z_V(y,t)=D_V(y)∩(T_0(y)\A_t(y))` | 不可把 h(A) 换为 β(A) 或 ν(A)，不可把“质量小”翻成“几何边长小” |

R128 [1128–1135行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:1128)明确当时四份20261013原附件未找到，派生接口不冒充原附件逐字原文。上表区分了实际可读的 master/构造稿与 R128 的继承说明，不从未读附件补预算。

## SL2 两项记号/修订冲突

1. **ν 与 β。** R113 最初 B2 明写没有假定 `ν≤β`（[proof.tex.txt:40–47](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:40)）。同轮后附 C/I 用新的耦合最大流重新构造 `β^c`，才证明 `ν≤β^c`（[同稿:578–587](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/proof.tex.txt:578)）；并明确旧任意flow余项不能与新余项混为同一对象。R114 第9行、R117 TASK_CONTEXT 第7行沿新构造简写了 `ν≤β`。本轮合同明确不授这一步，所以本稿只用 `ν≤f dx` 和 `ν≤σ_V`，不将 β 替换为 ν，也不反向替换。若以后恢复耦合版本，必须绑定相应新软流与整套删除账，不能只引用那一行不等式。

2. **原 q 与 R220 的 Q_F。** R220 冻结稿把外分母记为 `Q_F`，其有限费用桥又允许 `Q_F(x)` 并要求正下界；这是一条较宽的条件桥，不是 RT1 的原定义。[R128:604–611](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604)及 master 第5、9–13行可恢复原共同 `q`。因此在回代原 RT1 时直接取 `Q_F=q`，不额外购买未知 `inf_x Q_F`；`Q_x^*` 仍是依 x 的容量核。此修订只消除多引入的一份分母条件，没有给整份 `ν_V(V)/(q b^n)` 上界。

## SL3 hard z 的合法局部化与 FIRST 实际授予的质量帽

原正项非零时，hard 密度先给 `z∈Q_R(x)`；共同叶再给 `Q_R(x)⊂V`，故 hard z 在 `V∩Q_R(x)`。保原 aω/history 时还可保上表 `D_V(y)` 的原来源对资格。外 hard z 与两个辅助后验来源 v,u 不同，不能把它限制到本轮 terminal `Z_g` 或 eligible 集，也不能把后验轻块删除自动移交给 hard z。

从原 hard band 而非新假设得到：对每个实际接收点 x0 和每个 `B∈[a,b]`，

\[
 \nu_V(Q_B(x_0))\le\int_{Q_B(x_0)}f(z)\,dz
 =B^n(h_B*f)(x_0)\le4\lambda B^n\le\frac{16}{3}qB^n. \tag{SL1}
\]

这比只写当前 winner 的硬帽更适合做局部几何结算：同一锚点可使用全部合法 B。它不依赖 ν≤β，不要求 hard z∈Z_g，不含 e_g 或 bar e_g。硬 band 的上帽若已在某一步被删除，不能对任意扩大的新锚点使用 SL1。

同时 FIRST 的原响应上帽只是 `∫K_x dμ≤q`（`μ≤f dx`，K_x 为同一实际行的合法 future 或共同混合核），不是 `μ(V)≤q`。对任意来源集合 S，只能严格推出

\[
 \mu(S)\le q/\inf_{z\in S}K_x(z)\quad\text{若该下界严格为正}, \tag{SL2}
\]

或更一般 `q^−1∫Ψ_x dμ≤esssup_z Ψ_x(z)/K_x(z)`。核具有长度的 −n 次方单位，不能把 SL2 中的核下界换成无量纲1。V 宏叶的核下界可极小；K_x 在 S 上的下界、源/接收 x 量词均须保留。

原叶均值也仅给

\[
 \frac{\nu_V(V)}{qB^n}
 \le\frac{16e^{1/128}}{3\sqrt n}
       \left(\frac{256na}{B}\right)^n,\qquad a\le B\le b. \tag{SL3}
\]

它不是根阶本地质量帽。R107 R5 [940–945行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/proof.md:940)给参与原正行的出生细格质量 `H_C<e²qR(x)^n e^(−√n)/√n`；此资格依实际出生门，不能在删门后授予任意 source piece，也不能由 cell 质量帽无成本求和所有细格。

## SL4 一个实际可用的小接收胞来源结算

此定理不要求未知统一 C_*。它使用原可用局部质量帽，直接对全 hard ν 积分；付出的范围是一份已固定的实际小接收胞与物理尺度。不能由它免费覆盖全部连续尺度或所有小胞。

**命题。** 固定原种子、V、比例 j，以及实际物理尺度 L,R∈[a,b]，`b≤2a`，`g=√LR`，保原完整比例带。取一个真实接收锚点 x0（满足原 hard band）。若 `U⊂Q_ℓ(x0)`，并且

\[
 B=R+\ell\le b,\qquad 0\le\ell\le\kappa R/n \quad(\kappa\ge0), \tag{SL4}
\]

则对任意 y,v、任意 A∈[L,b] 和独立 s,σ∈[0,1]，令 `w_g(y,v)` 为原共同几何权，有

\[
\begin{aligned}
 &\frac1q\int_{\mathbb R^n}\!\nu_V(dz)
 \int_U\!1_{\{B_{\rm hard}=0\}}
 \frac{\sqrt{P_{s,L}(x-y)P_{\sigma,A}(x-v)}}{\sqrt{w_g(y,v)}}
 h_R(x-z)\,dx\\
 &\quad\le\frac{16}{3}\left(\frac{c_jB}{g}\right)^n
 \le\frac{16}{3}\gamma^n\left(\frac{R+\ell}{\max(L,R)}\right)^n
 \le\frac{16}{3}e^{1+\kappa}. \tag{SL5}
\end{aligned}
\]

同样可保原来源对 gate 或任何其他 [0,1] 正门，右边仍有效；没有重算其 history。若某坐标缺口可对该胞全部参数与来源一致使用，可继续保其收益，但这里不用额外缺口。

**证明。** 若 x∈U 且 hard h_R(x−z)>0，则三角不等式给 z∈Q_(R+ℓ)(x0)=Q_B(x0)。所以全 hard ν 积分首先准确限制到该真实局部盒；不限制 Z_g。对其每个固定 z，把 U 上的非负 receiver 积分上放到全空间，使用 R220 已证共同积分及原 B 精确乘积差，得上界 `(c_j/g)^n`。于是左边≤`(c_j/g)^n ν_V(Q_B(x0))/q`；SL1 给第一个显式界。原下向比例带 `min(L,R)≥c_jg/γ` 给 `c_j/g≤γ/max(L,R)`。最后 `R/max(L,R)≤1`、`γ^n<e`、`(1+ℓ/R)^n≤e^κ`，完成全部常数。所有来源 y,v,z 任意，没有假设 ν 的坐标独立。证毕。

SL5 的软度自适应扩展也是真价：固定这些物理尺度与胞，用 R220 公共 soft 节点对两条同 soft 半密度腿，得到该胞积分内 `sup_s` 的来源价

\[
 \frac{16}{3}e^{1+\kappa}\,4|S_n|
 \le\frac{16}{3}e^{1+\kappa}
      [32+16\sqrt n\log(n-1)]\quad(n\ge2). \tag{SL6}
\]

J 腿 σ=1 亦可用同一保守常数。此处 sup 只取核的共同 soft，原 Q/capture/good/history 不在节点重算。R221 原外标量 q 已固定，故不需要 R220 BB 的未知分母下界；若保ρ、其他门与外权只作 [0,1] 正上放，它们不扩大 SL5/6。

### b端点与越窗边界胞的真实费用

若 R=b、ℓ>0，hard 来源并集可延伸至 Q_(b+ℓ)(x0)，所以锚点 h_b 上帽仅管 Q_b，不能直接延伸 SL1。仍有不缺资格的备选价：合法全soft future J_(x0)=P_1,b(x0−·) 满足 `∫J_(x0)dν_V≤q`。φ偶径向非增，故对任意 B=R+ℓ，

\[
 \nu_V(Q_B(x_0))\le q b^n\phi(B/(2b))^{-n}. \tag{SL7}
\]

以它替代 SL5 证明中的局部质量，得同一左侧的价格

\[
 (c_j b/g)^n\phi((R+\ell)/(2b))^{-n}. \tag{SL8}
\]

特别 R=b、ℓ≤κb/n 时，此价≤`γ^n φ(1/2+κ/(2n))^−n`。它有限，但明确随 n 指数增长；不能称根阶费用。若需完全初等常数，对 h≥0 有

\[
 \phi(1/2+h)=\int_0^1r(1-e^{-1/r})e^{-h/r}\,dr
 \ge e^{-2h}(1-e^{-1})\int_{1/2}^1r\,dr
 \ge\frac3{16}e^{-2h}.
\]

因此 R=b 的 SL8≤`e^(1+κ)(16/3)^n`。更一般，若 R+ℓ>b 且 ℓ≤κR/n，则 b/max(L,R)≤1+κ/n，故 SL8≤`e^(1+2κ)(16/3)^n`。这些边界价只使用原 J 容量一次，不另叠硬帽。没有将缺失的正ℓ端点藏在闭边界约定中。

## SL5 可以接入哪里，仍不能授予哪一步

SL5/6 真正替代了 **每一个已固定小接收胞**中 BB 的全质量 `(c_j/g)^n||ν_V||/q`：现在全 hard 来源已经以 `(16/3)e^(1+κ)` 实际结算，保任意 y,v 和全部三腿，且没有另乘一次硬帽16/3。原 factor 2Λ、good 的 √(K/3)、三腿和、两份完整 Π、δ、原clock仍照原式保留；不是多领一份来源价。

限制准确为：锚点须来自原 hard band，R+ℓ须仍为合法尺度，L,R及该胞已固定。对 R=b 不能取正ℓ而沿用常数版 SL5；SL7/8提供其明确有价备选，尚非根阶。一般 receiver 的 n维小胞覆盖和连续尺度离散化仍可能产生大量重复；ν(Q_B(x0)) 的局部盒不同、可重叠，不能给每盒各领一次总 Wν。仅有 FIRST、叶不交或唯一 j，不消去这份共同占用费用。此处没有宣称这些胞价可直接无重叠相加成一般根阶预算，没有删掉两后验、δ、bad端、signed负账或原浮动带外资格。

因此本次恢复得到两项可直接修订主线的事实：原分母 q 无需未知 `inf_Q`；原 hard band 允许 SL1 的全合法尺度局部帽，从而给 SL5/6 的显式小胞来源价。下一步若要扩成原一般付款，须让保 z 定位的共同几何或原门控制这些真实局部盒的共同占用，而不是重新假设一个未知 C_*。

本机实际用 Python Fraction 核对 `4/(3/4)=16/3`、`∫_(1/2)^1 r dr=3/8`、`(3/8)(1/2)=3/16`，并对128组有理 L,R 比例参数核对 `min(L,R)/(LR)=1/max(L,R)`。一般不等式由以上原文定义及自足证明承担，不新增普通数值探路。
