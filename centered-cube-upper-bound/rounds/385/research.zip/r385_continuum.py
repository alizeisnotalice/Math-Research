from fractions import Fraction as F
from itertools import product
from math import factorial
import json
from pathlib import Path
checks=0

def ck(x):
 global checks
 assert x
 checks+=1

s=sum((F(2**j,factorial(j)) for j in range(11)),F(0))
ck(s+F(2**11,factorial(11))/(1-F(2,12))<8)

def run(eta,d,P,delta):
 n=4; bg=F(3,4); rv=F(1,2); ru=F(1); volD=F(1,100)**4
 fD=bg+P/volD; mv=bg*rv**4+P; mu=bg+P
 qv=mv/rv**4;qu=mu;w=eta**4;Z=w/mv;J=Z+w/mu
 ck(F(3,4)<=qv<=1 and F(3,4)<=qu<=1)
 ck(mu>8*mv)
 # D=[.22,.23] x [0,.01]^3 captured by every actual receiver.
 ck(d+eta/2-F(1,2)<=F(11,50) and rv/2-eta/2>=F(23,100))
 ck(eta/2+F(1,100)<=rv/2)
 ck(d+eta/2+F(1,2)<2)
 ck(fD>4*max(qu,qv) and bg<4*min(qu,qv))
 distmin=d-eta;distmax=d+eta
 ck((2*distmin)**4>3)
 ck(eta<F(1,4) and distmin>F(1,4) and distmax<F(3,4))
 # one protruding coordinate; exact d_1=2*distance-1/2.
 ck(F(1)>F(4,8) and 2*distmin-F(1,2)>F(4,20))
 beta=F(5,4);bplus=4*((1+beta)*rv-ru)**2/(4*beta*rv)
 ck(2*distmin-(ru-rv)>bplus)
 ck(Z>F(1,10**8) and J>=F(1,10**8))
 # All nonzero traffic starts at R_u=b=1, hence normalized clock atom=1.
 c=Z/J*(1-mv/mu)*(1-qv/fD)
 lossmean=2*d-F(1,2)
 losslow=lossmean-eta;losshigh=lossmean+eta
 piD=fD*volD/mu
 amin=piD*c*losslow;amax=piD*c*losshigh
 ck(c*losslow>delta and amin>2*delta)
 # Small-receiver capture union is cube side rv+eta, up to null boundary.
 unionSide=rv+eta
 overlapMean=F(3,4)+eta/2-d
 Umin=(bg*(overlapMean-eta/2)*unionSide**3+P)/mu
 Umax=(bg*(overlapMean+eta/2)*unionSide**3+P)/mu
 ck(0<Umin<=Umax<F(1,3))
 ck(amax<=Umin)
 ck(amax<=2*(1-Umax))
 # Independent integration of all original u,v/source/clock factors.
 original=w*w*(1-mv/mu)*(fD-qv)*volD/(mv*J)*lossmean
 posterior=qu*w*piD*c*lossmean
 ck(original==posterior and original>0)
 # Entire high-source packet has s=mv; mu>K mv, so old window cost=0.
 ck(mu>8*mv and original>0)
 return {'eta':str(eta),'d':str(d),'P':str(P),'delta':str(delta),
         'U_range':[str(Umin),str(Umax)],'A_range':[str(amin),str(amax)],
         'G':str(original),'old_window_cost':'0','new_residual':'0',
         'W':str(bg*4**4+P),'Xq':str(w*(qu+qv)),
         'Z':str(Z),'J':str(J)}

stages={}
stages['initial']=[run(F(1,100),F(27,40),F(1,100),F(1,1000))]
stages['pressure']=[run(e,d,p,F(1,1000)) for e,d,p in product(
 [F(1,200),F(1,100),F(1,50)],[F(17,25),F(69,100),F(7,10)],
 [F(1,200),F(1,100),F(3,200)])]
stages['expanded']=[run(e,d,p,de) for e,d,p,de in product(
 [F(1,200),F(1,100),F(1,50)],[F(17,25),F(69,100),F(7,10)],
 [F(1,200),F(1,100),F(3,200)],[F(1,2000),F(1,1000),F(3,2000)])]
out={'scope':'Exact continuum box integration; literal diagnostic h=H=1e-8, not synchronized historical qualification',
     'counts':{k:len(v) for k,v in stages.items()},'assertions':checks,'stages':stages}
Path(__file__).with_suffix('.result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS',out['counts'],'Fraction assertions',checks)
print('baseline',stages['initial'][0])
