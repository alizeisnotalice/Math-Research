# R385 independent audit — FINAL PASS

Owner scope: only this audit; no author/repository edits. This exact global source-window construction was independently derived before reading new R385 author proofs. One complete original R379/R383/R384 full-f field, actual finite-measure receiver set E and the same actual plan/core are fixed. The result is a real paid family and explicit remaining receiver condition, not a general root closure or a conditional source-moment reduction. Final author proof, continuum code/result/notes and integrated main/ledger/readme have now been reviewed. PASS is for the exact paid branch and accounting below; the general upper bound remains open. No author or repository file was changed.

## 1. Measurable original capturing-mass infimum

Let m_-=q_-a^n>0 and m_+=lambda b^n<infinity. For each source y define the finite measurable receiver kernel

    rho_y(du)=1_E(u)c_u(y)du/m_u,
    J_b(y)=rho_y(E),
    Z_y(t-)=rho_y{m_u<t}.

It is finite since J_b<=|E|/m_-, and its joint evaluations are measurable by nonnegative Tonelli. Use ORIGINAL E, f, matched m and captures, not only core/high rows or a newly retained receiver family. Its original source-clock identities are unchanged. Set, on J_b>0,

    s(y)=inf{t in positive rationals: Z_y(t-)>0},

and set s=m_- when J_b=0. The set is nonempty because all actual receiver masses<=m_+ and a larger rational t has positive occupation. By monotonicity this infimum equals ess inf_(rho_y)m and lies in[m_-,m_+]. Countable sublevel tests establish measurability, with no uncountable argmin or assumed attained minimum. A non-attained essential infimum is permitted.

For J_b(y)>0 and every real t>0,

    Z_y(t-)=0 iff t<=s(y).

At t=s no mass is STRICTLY below the essential infimum, even if a positive atom sits exactly at s. At t>s the definition of essential infimum forces positive mass below t; no receiver attaining s is needed. This is the reason the original STRICT far comparison and CLOSED source window have compatible endpoint conventions.

## 2. The global source window and exact posterior complement

Take original K=exp(sqrt(n))>lambda/q_- and source-only closed window I(y)=[s(y),K s(y)]. It is one globally measurable map fixed for every receiver; its width is exactly log K=sqrt(n). It is not a private anchor chosen separately for u.

Positive Tonelli gives

    integral_E du integral pi_u(dy)1_{s(y)>m_u}=0,
    pi_u(dy)=f(y)c_u(y)dy/m_u.

Indeed for each positive-J source row the inner capturing receiver mass below its essential infimum is zero. The zero-J rows also have zero joint du*pi_u mass since integral f(y)J_b(y)1_{J_b=0}dy=0. Thus s(y)<=m_u holds for du*pi_u-a.e captured pair, including all original radius/mass atoms. Outside this common joint null set,

    m_u in[s(y),K s(y)]
       iff s(y)>=m_u/K
       iff Z_y(m_u/K-)=0.

Consequently for actual du-a.e u,

    F_u:=pi_u{m_u in I(y)}=1-U_u,
    U_u:=pi_u{Z_y(m_u/K-)>0} in[0,1].

This is an equality of the FULL posterior, not a measure of cost or a normalized high-source tail. U is measurable because the actual Z at the measurable threshold m_u/K is a joint positive integral. It is the full-f fraction captured by u that lies in the union of positively occupied original strictly smaller-mass receiver captures. It is not the size of that occupation or a Markov transition probability, and no condition is transferred to those smaller receivers.

## 3. Core cost support and zero-traffic witnesses

Original alpha_u(y) is zero unless the original strict mass-past Z_y(m_u/K-)>h, with h>0. The same-plan core density a_u=integral alpha_u 1_Y d pi_u therefore satisfies

    0<=a_u<=pi_u{Z>h}<=U_u.

Set a=0 for receivers outside the actual core if integrating over all E. All fields, high-source/pair/history masks and the complete physical clock remain those of the original full input. The inequality uses their genuine positive support and alpha<=1; it does not replace h by zero in the actual residual.

An important exact consequence is that this SAME source window has ZERO actual core traffic: I corresponds to Z=0 whereas every positive original cost source has Z>h>0. In the R384 notation b_u=0 almost everywhere. Thus the full-F witness is not an old paid current-source window branch relabeled. It uses captured zero-traffic source mass to pay some other actual source's cost through the explicit receiver bound. The narrower Y-restricted witness would be vacuous here. No source density cap or independence is used, and the plan/target is not changed by marking cost.

## 4. Actual root-price fractional receipt and exact remainder

Apply the already proved R384 fractional positive decomposition to this ONE fixed same-plan core and window. For C>=1 its paid density is min(a_u,C F_u); if a>0 the fractional payment is a rowwise mark min(1,C F_u/a_u), and a=0 is a zero-cost convention. Because b=0 all retained actual traffic remains source-window-exterior. The exact remaining density is

    r_u=(a_u-C F_u)_+=(a_u-C(1-U_u))_+.

By a_u<=U_u,

    r_u<=((C+1)U_u-C)_+.

The actual source price is

    P_C=C lambda(1+sqrt(n))W/q_-.

It follows by the actual-center window estimate for integral q_uF_u du, not by treating witness sources as actual flow inputs or assuming that different receivers use disjoint source sets. The full-f normalization and matching m=qR^n are indispensable. There is no B_star, new X coefficient, target-cap multiplier or delta inverse.

All surviving core rows with U_u<=C/(C+1) are completely paid, including equality. If the exact fractional remainder is positive, then U_u>C/(C+1) and a_u>C(1-U_u). These statements are only necessary conditions for remaining traffic; U above the threshold does not imply positive cost. C=log(n+2)>1 for n>=1, so the displayed fee is O(sqrt(n)log(n+2))W at fixed lambda/q_-=4/3, and a surviving receiver must have more than1-1/[1+log(n+2)] of its full-f mass in the original positive far-smaller-occupation union. This is the claimed real global window construction, not a free arbitrary cluster-selection assumption.

The upper envelope integral q_u((C+1)U_u-C)_+du is not proved root-small. In particular positivity of far-smaller occupation can be caused by arbitrarily small receiver occupation and does not itself provide a source-W capacity or endpoint inheritance. The original residual retains strict past>h, all high-J/space/source/history gates and original positive cost marks; it is not replaced by a new flow with only Z>0.

## 5. Full ledger and non-reuse conditions

The safest complete entry starts from the original pre-this-window G, performs R383's actual epsilon383 X_q screening once, then applies this SAME-plan fractional receipt. Its new exact remainder is R_385=integral q_u(a_u-C(1-U_u))_+du. The preferred hard bound is

    BH<=R_385+(eta+sigma_n+epsilon383)X_q+(C338+P_C/W)W.

Here P_C/W denotes the displayed coefficient C lambda(1+sqrt(n))/q_-; if W=0 use the zero-cost convention rather than divide. The original entrance has2R_385, twice the relevant receiver/source costs,8lambda H W and2d_eff A_n W_nu/H, followed by Lambda. The new source addition is exactly2Lambda P_C. No old optional source-window F2, R384 lift fee or negative square is added again on the same traffic; this is a new explicit choice of that complete receipt. The old epsilon/epsilon-prime Hall approximation errors are not charged when retaining actual same-plan cost.

The R384 trigger/fractional factor still uses the actual chosen plan's a_u. The global source-only s,F,U do not themselves change with the plan if the full field is fixed, but changing plans can change a and the actual residual. Source exactness does not transfer an old trigger as a newly valid actual-cost statement. The sufficient whole-row sublevel U<=C/(C+1) is plan-independent within the stated family because a<=U holds for each eligible original flow; that limited domination does not prove any further source/target/history property for new endpoints.

The old H-selection, soft/crossing/entry, tail/wide-distance/low-pe/extreme-scale and threshold complements, initial/deleted/future-deleted histories, source/scale aggregation, truncation and limit obligations remain. Choosing source anchors is now explicit, but neither the near-full-U receiver family nor its exact cost has a general root budget. A coupled spatial/source argument is still needed for it. No new input is reconstructed from the witness sources.

## 6. Bounded local mathematical-tool evidence

Reviewer actually ran1260 standard-library Fraction cases:648 atomic capturing-mass spectra checked the essential-infimum/STRICT-tail/CLOSED-window equivalence including bottom atoms;612 scalar positive-part/threshold cases checked r<=((C+1)U-C)_+ and full payment when U<=C/(C+1). These are finite measure/algebra diagnostics, not actual native cube/history realizations or proofs of the continuum center integral. Their successful execution supports only the specified bounded identities and is separate from author/parent counts. No author pipeline was repeated.

Final conclusion: PASS for the precise measurable global bottom-mass window, exact F=1-U and actual fractional root-price subbranch. The unweighted near-full-U complement and global closure remain unproved.


## 7. Final author proof and complete-ledger review

Read the final R385 geometry proof in full, followed by the main, ledger and readme. Its rational-threshold definition, null-source Tonelli argument, atom-safe closed window and original strict-past support agree with the independent derivation above. The actual-center estimate in (13) follows from capture implying m_u>=q_-(2||u-y||_infinity)^n. Integrating 1/max(s,z) up to z=Ks against dz/q_- gives (1+log K)/q_-; multiplying by q_u<=lambda gives precisely the stated fee. The measurable anchor may depend on the full field, but not separately on the receiver being integrated. No density bound on f or receiver-count substitute is used.

The final ledger starts before deletion of this window, applies R383 once, and replaces the R384 window choice with this canonical one. Its preferred exact remainder is R_min=integral q[a-C(1-U)]_+. The source coefficient is C338+C lambda(1+sqrt(n))/q_-, and the original entrance doubles these hard-slot quantities before multiplication by Lambda. The inherited 8lambda H W and 2d_eff A_n W_nu/H terms are present. There is no additional F2, second R384 source fee, Hall approximation fee, old negative-square credit, target-cap change, or new X_q charge in this exact-cost version.

For 0<kappa<=1, eta=kappa/(6Lambda), epsilon383=kappa/(4Lambda) and sigma<=eta/2 give 2Lambda(eta+sigma+epsilon383)<=kappa. This remains only a local slot allocation. C=2 and C=log(n+2) are alternative choices; switching C changes the exact remainder and fee together, and does not upper-bound the fixed C=2 remainder by the smaller remainder for a larger C. All old unpaid source/history/soft/scale/limit interfaces remain explicitly listed. No inherited full reduction was re-proved in this bounded audit.

## 8. Independent review of the real-du example and numerical evidence

Read the complete continuum script, its saved result, and its explanation. This is genuine positive-volume receiver Lebesgue integration, rather than replacing du by weights. For n=4, f=(3/4)1_Q4+(P/|D|)1_D, D=[.22,.23]x[0,.01]^3, all actual receiver cubes contain D and stay inside Q4. Thus m_v=3/64+P, m_u=3/4+P, q_v=3/4+16P and q_u=3/4+P are correct and share the same full input. The supplied legal parameter domains give the actual q band, strict mass gap, outside/dense/deep/not-Bplus shape masks and literal h/H conditions on whole center boxes.

For u_1=d+x, averaging the smaller actual centers gives capture fraction 3/2-2(d+x), hence target loss 2d-1/2+2x. The stated alpha coefficient (Z/J)(1-m_v/m_u)(1-q_v/f_D), with Z=eta^4/m_v and J=Z+eta^4/m_u, therefore gives the exact row. Every positive far pair starts at R_u=b=1: the full normalized physical clock is its actual terminal atom; there is no omitted positive continuous-clock contribution. Both displayed formulas for G agree by algebra and include the actual source, both center measures, target loss and clock.

The positive-occupation union of the smaller cubes is Q_(1/2+eta)(0), up to null boundary. Its intersection with each actual large cube has first-coordinate length 3/4+eta/2-d-x and three full lengths 1/2+eta. This proves the displayed U_u interval and shows that the script is integrating continuous centers exactly rather than evaluating a nominal center. The packet lies in the union, so its actual cost is entirely outside the bottom window, while the background outside the union supplies zero-traffic witnesses. All tested large rows have U<1/3 and are completely paid with C=2. The baseline rational U and A intervals, positive G, W=19201/100 and X_q=167/10^10 match the saved result.

The example uses literal h=H=10^-8 and diagnostic receiver/source screening thresholds. It does NOT certify synchronized R379 parameter/history qualification, a near-extremizer, a fixed positive covered fraction, or a general budget. Both the theorem and the final notes retain this distinction. The initial invalid outside pressure domain was rejected and changed before the successful run; that failed attempt is not counted as passing evidence.

Read the finite incidence geometry-check script as well. It derives all finite masses from one source measure and checks strict mass thresholds, bottom atoms, zero occupation, same-field fractional marking and both positive and zero residual cases. Receiver incidence/quadrature in that script is not an original continuous cube/high-history realization. Parent reports actual runs of 7289 Fraction assertions there and 1854 in the continuum script, total 9143. The continuum stages are 1+27+81=109 parameter-field executions, with overlap between stages; they are not 109 distinct models. Reviewer bounded 1260 checks above are separate and are not added to 9143. No full parent pipeline was repeated for this file review.

## 9. Freeze and limitations

FINAL PASS. No outstanding mathematical correction was found in the stated R385 construction, actual-du example or final same-plan accounting. The accurate remaining quantity is R_min, not merely a union-volume proxy. There is no proven root budget for receivers with near-full U and positive actual a, and no claim that this resolves the general centered-cube weak-type bound. This audit does not certify LaTeX typesetting or compilation.

The following hashes bind the final files read, plus the specific inherited proof interfaces used. Historical interfaces are dependencies of this bounded audit, not a claim that the whole historical reduction was freshly re-audited.

| File | SHA256 |
| --- | --- |
| `/tmp/r385_geometry.md` | `f39ec03b200b8954695da179d5d24183a1420081a96aaee61f34fb09c353c8eb` |
| `/tmp/r385_main.md` | `3015bf25141c8466068f36ec27a70af02fd6a7db992a9dd553acdcf058d11805` |
| `/tmp/r385_ledger.md` | `481d851517df6cc6653810cde374bdef62e72fb0636c62f17d6ab950e4b89c45` |
| `/tmp/r385_readme.md` | `8d5a0fa4e641e2354140ef14445b0466c5f77b5637d1db177b9885f99b0fd776` |
| `/tmp/r385_continuum.md` | `a45c890a0d6cd6c25c44a8eb91ca09bbc8031dede9c0e3abd9786c5764df0b9e` |
| `/tmp/r385_continuum.py` | `035e9d0e5fd41562d5b0b6c073a06f93161dce36fb68ffdae6bf214ccb1502c1` |
| `/tmp/r385_continuum.result.json` | `0c643fc01f30b9c9d2fb8f356621c1015979305409b3a8b80df829f500de47e5` |
| `/tmp/r385_geometry_check.py` | `19fc18959fd4da7f5042588dd014b6f444b9c74f620c824ff4b2b2d55deb5b5d` |
| `/tmp/r384_fractional.md` | `efb108db097035acf964613d14d2f4df69e10a3946c7d02892b4bf29df42eb6b` |
| `/tmp/r384_geometry.md` | `34a95c9a1059d6f9c181f8d610fed3931c2af4953b39bfa0a1d4dc783402732a` |
| `/tmp/r383_flow.md` | `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd` |
| `/tmp/r382_geometry.md` | `e596a311e4eca9be309c10aafe75db0e1938aa815dd258538461bdf0d47f2944` |
