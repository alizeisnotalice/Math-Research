from fractions import Fraction as F
counts={'essential_support_and_boundary':0,'fractional_payment':0,'zero_occupancy':0}
positive=0;covered=0;remaining=0
for seed in range(1,31):
 ns=9; nr=5
 dy=[F(1,10)]*ns
 f=[F(1+(3*y+seed)%11,3) for y in range(ns)]
 # Last source atom has J_b=0. Every receiver captures at least one source.
 c=[[int(y<8 and ((y+2*v+seed)%(v+2)!=0 or y==v)) for y in range(ns)] for v in range(nr)]
 m=[sum(f[y]*dy[y]*c[v][y] for y in range(ns)) for v in range(nr)]
 w=[F(1+(seed+v)%4,7) for v in range(nr)]
 J=[sum(w[v]*c[v][y]/m[v] for v in range(nr)) for y in range(ns)]
 anchor=[min(m[v] for v in range(nr) if c[v][y]) if J[y] else min(m) for y in range(ns)]
 for y in range(ns):
  if not J[y]:
   assert all(c[v][y]==0 for v in range(nr))
   counts['zero_occupancy']+=1
  else:
   # Include thresholds exactly equal to all mass atoms, including the infimum.
   for t in set(m+[anchor[y],2*anchor[y],anchor[y]/2]):
    Z=sum(w[v]*c[v][y]/m[v] for v in range(nr) if m[v]<t)
    assert (Z==0)==(t<=anchor[y])
    counts['essential_support_and_boundary']+=1
 Ks={F(3,2),F(2),F(4)}
 Ks.update(m[u]/m[v] for u in range(nr) for v in range(nr) if m[u]>m[v])
 for K in Ks:
  for u in range(nr):
   pi=[f[y]*dy[y]*c[u][y]/m[u] for y in range(ns)]
   Z=[sum(w[v]*c[v][y]/m[v] for v in range(nr) if m[v]<m[u]/K) for y in range(ns)]
   mark=[int(anchor[y]<=m[u]<=K*anchor[y]) for y in range(ns)]
   witness=sum(pi[y]*mark[y] for y in range(ns))
   union=sum(pi[y]*int(Z[y]>0) for y in range(ns))
   assert witness==1-union
   counts['essential_support_and_boundary']+=1
   for h in (F(1,100),F(1,10)):
    # Actual mass increment and reciprocal J, with a [0,1] source/target mark.
    alpha=[]
    for y in range(ns):
     val=F(0)
     if c[u][y] and J[y]>0 and Z[y]>h:
      for v in range(nr):
       if m[v]<m[u]/K and c[v][y]:
        # Uniform target on captured finite source cells; preserve current y.
        loss=sum(F(c[v][z]*(1-c[u][z]),sum(c[v])) for z in range(ns))
        thin=F(1+(y+u+v)%3,3)
        val+=w[v]/m[v]*(1-m[v]/m[u])*loss*thin/J[y]
     alpha.append(val)
    assert all(0<=val<=1 for val in alpha)
    delta=F(1,1000)
    A=sum(pi[y]*alpha[y] for y in range(ns))
    if A<=2*delta:continue
    Y=[int(alpha[y]>delta) for y in range(ns)]
    a=sum(pi[y]*alpha[y]*Y[y] for y in range(ns))
    inside=sum(pi[y]*alpha[y]*Y[y]*mark[y] for y in range(ns))
    assert inside==0 and a<=union and a>delta
    positive+=1
    for C in (F(1),F(3,2),F(2),F(3),F(5)):
     paid=min(a,C*witness);res=max(a-C*witness,F(0))
     assert paid+res==a
     assert res<=max((C+1)*union-C,F(0))
     assert paid<=C*witness
     if union<=C/(C+1):
      assert res==0;covered+=1
     if res>0:
      assert union>C/(C+1);remaining+=1
     counts['fractional_payment']+=1
print('PASS',counts,'total',sum(counts.values()),'positive core rows',positive,
      'guaranteed covered row/C pairs',covered,'positive residual row/C pairs',remaining)
