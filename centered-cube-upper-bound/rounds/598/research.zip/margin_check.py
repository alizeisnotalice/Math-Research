#!/usr/bin/env python3
"""R598: algebra only, all locked R597 events, no geometry recomputation."""
import argparse,hashlib,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import flint
from flint import arb,ctx
EXPECTED='a70f09898b9ef6a664f662bef96d18257900e36559a85c4da20dfab1aece2e09'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=Path(__file__).with_name('margin_input.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=ap.parse_args();start=time.perf_counter();ctx.prec=512
 raw=a.input.read_bytes();assert hashlib.sha256(raw).hexdigest()==EXPECTED;data=json.loads(raw)
 zero=(F(0),F(0));one=(F(1),F(0))
 def read(d):
  terms=dict(d['exact_squarefree_radical_terms']);assert set(terms)<= {1,2};return (F(terms.get(1,0)),F(terms.get(2,0)))
 def add(x,y):return tuple(x[i]+y[i] for i in (0,1))
 def neg(x):return tuple(-v for v in x)
 def sub(x,y):return add(x,neg(y))
 def mul(x,y):return (x[0]*y[0]+2*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
 def div(x,y):
  den=y[0]**2-2*y[1]**2;assert den;return mul(x,(y[0]/den,-y[1]/den))
 def ball(x):return arb(x[0].numerator)/x[0].denominator+arb(2).sqrt()*arb(x[1].numerator)/x[1].denominator
 def sign(x):
  if x==zero:return 0
  b=ball(x)
  if b>0:return 1
  if b<0:return -1
  raise ArithmeticError('Unresolved Arb512 sign; no floating fallback')
 def out(x):return {'exact_a_plus_b_sqrt2':list(map(str,x)),'Arb512':ball(x).str(65)}
 def minimum(xs):
  v=xs[0][1]
  for _,x in xs:
   if sign(sub(x,v))<0:v=x
  return v,[i for i,x in xs if x==v]
 def maxzero(x):return x if sign(x)>0 else zero
 results=[];event_count=0
 for model in data['models']:
  q=read(model['q']);assert sign(sub(q,one))>0;kappa=div(one,q);probes=[]
  for p in model['probes']:
   assert not p['inside_E'];ts=[];ss=[];events=[];oldmax=zero;oldids=[];signedmax=None;signedids=[]
   for i,e in enumerate(p['all_unique_positive_source_entry_events']):
    event_count+=1;r=F(e['r_exact']);r2=(r*r,F(0));m=(F(e['captured_mass']),F(0));deficit=sub(r2,m);assert sign(deficit)>=0
    holes=read(e['exterior_area']);assert holes==sub(r2,read(e['covered_area']));sg=sign(holes);assert sg>=0
    sourceT=div(mul(q,deficit),r2);ss.append((i,sourceT))
    old=read(e['actual_qF'])
    if signedmax is None or sign(sub(old,signedmax))>0:signedmax=old;signedids=[i]
    elif old==signedmax:signedids.append(i)
    assert old==sub(neg(mul(q,deficit)),neg(mul((F(1,4),F(0)),holes)))
    if sign(sub(old,oldmax))>0:oldmax=old;oldids=[i]
    elif old==oldmax:oldids.append(i)
    record={'event_index':i,'r_exact':str(r),'captured_mass':e['captured_mass'],'holes':out(holes),'source_only_T':out(sourceT),'ignored_zero_holes':not sg}
    if sg:
     T=div(deficit,mul(kappa,holes));assert T==div(mul(q,deficit),holes);ts.append((i,T));record['T']=out(T)
    events.append(record)
   assert ts;T,ids=minimum(ts);H=maxzero(sub(one,T));ST,sids=minimum(ss);SH=maxzero(sub(one,ST))
   assert (sign(sub((F(1,4),F(0)),T))>0)==p['A_theta_member']
   probes.append({'tag':p['tag'],'x':p['x'],'events':events,'minimum_T':out(T),'minimum_T_event_indices':ids,'minimum_T_radii':[events[i]['r_exact'] for i in ids],'H':out(H),'H_squared':out(mul(H,H)),'recovers_for_some_theta_strictly_below_1':sign(sub(one,T))>0,'theta_quarter_member':p['A_theta_member'],'old_theta_quarter_maximum_positive_qF_event_indices':oldids,'old_theta_quarter_maximum_signed_qF_event_indices':signedids,'minimum_T_event_matches_old_signed_maximizer':bool(set(ids)&set(signedids)),'minimum_T_event_matches_old_positive_maximizer':bool(set(ids)&set(oldids)),'source_only_minimum_T':out(ST),'source_only_H_squared':out(mul(SH,SH)),'source_only_minimum_event_indices':sids})
  results.append({'name':model['name'],'q':out(q),'kappa':out(kappa),'probes':probes})
 assert sum(len(x['probes']) for x in results)==19
 d={'scope':'Exactly the 19 locked R597 exterior probes and all recorded source-entry events; no geometry, source, spatial or theta grid scan.','definition':'kappa=1/q; T=(r^2-m)/(kappa*(r^2-I)); theta reception iff theta>min T. H=max(0,1-min T). Source-only comparison replaces holes with r^2.','scale_certificate':'For every theta in (0,1), q>1 gives 1-theta/q>0. Between source entries F_theta strictly decreases. All tied entries included by inherited R597 certificate.','qualification_limit':'q>1 certified; q>=2 is false for these inputs and no global upper-price or dimensional conclusion is certified.','input_sha256':EXPECTED,'input_provenance':data['provenance'],'all_assertions_passed':True,'probe_count':19,'event_count':event_count,'models':results,'execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':512,'processes':1,'runtime_scope':'Timed main calculation after imports and argparse, including input read/check and arithmetic; excludes output serialization/write.','runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,*sys.argv])}}
 a.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
 for mod in results:
  for p in mod['probes']:
   if 'frozen_anchor' not in p['tag']:print(mod['name'],p['tag'],p['minimum_T']['Arb512'],p['H_squared']['Arb512'],p['minimum_T_radii'],p['recovers_for_some_theta_strictly_below_1'])
 print('events',event_count,'runtime',d['execution']['runtime_seconds'])
if __name__=='__main__':main()
