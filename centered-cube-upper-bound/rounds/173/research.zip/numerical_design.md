# R173 frozen bounded mass-sensitive numerical design

Implementation handoff: r171_numeric_impl owns mass_clock_check.py/json/md. Sol owns this design and numerical_review.md. Maximum 22 selected inputs, including one rejected invalid input. No physical C, good/rho, J normalization, common-input FIRST, carrier/history or FULL claim. No exponent fitting or unrelated search.

## 1. Fixed finite row and exact candidate formulas

Every valid case has rational positive nu, fixed rational C_vi in (0,1] (an inherited C>1 may be clipped to1 with explicit provenance), clocks ell=1/2 and g<=1, fixed partition initial S=Cset disjoint-union B, A=1_Cset and rho=1. Define

    w_v(xi)=product_i min(1,C_vi/xi), k_v=#{i:C_vi<xi},
    e_xi=sum_(v in Z_xi) nu_v w_v, Pi_v=1_Z nu_v w_v/e_xi,
    I=int sum_vu A_v(k_v-k_u)_+ Pi_v Pi_u dlogxi.

All Cset sources survive to g. Nested support deletes only A=0 sources. The finite INITIAL support includes every positive tiny mass and every later-deleted source. Require e_g>0. Right-continuous support at deletion endpoints changes no continuous integral.

R172 reference: m=min_initialS k, Gamma_v=int(k_v-m)dlogxi and

    B_Gamma=(1/e_g) sum A_v nu_v w_g(v)(expGamma_v-1).

Astra mass-clock candidate (mass_sensitive_geometry.md): r=min_Cset k, c_ell=1, c=exp(-int r dlogxi), GammaC_v=int(k_v-r)dlogxi,

    lambda=(c_g/e_g) sum_(u in FULL INITIAL B) nu_u
           int (r-k_u)_+ w_u/c dlogxi,
    B_mass=(1/e_g) sum_Cset A_v nu_v w_g(v)
            [expGammaC_v/(1-lambda)-1], if lambda<1,
    I<=B_mass.

FULL INITIAL B is mandatory in lambda, even after a source is deleted. Its w_u/c continues as an envelope. This differs from b_v below, which uses ACTUAL current support. If all B scores satisfy k_u<=r throughout, check the exact static identity

    lambda=(1/e_g) sum_fullinitialB nu_u [w_g(u)-c_g w_ell(u)].

For deleted B, this integral of w_g is not its actual terminal posterior mass. Never substitute Pi_g(B), which is zero for deleted sources. Unordered B uses the positive derivative segment integral and the static formula is marked inapplicable.

## 2. Parent energy and masked companions

Freeze p=1,K=3 and abstract J_v=A_v w_g(v), solely as algebraic good-equality data. J may vanish. On A>0 use p^2 A^2/J=A/w_g; on A=0 define coefficient zero, avoiding 0/0. Define exactly

    delta_+=(k_v-k_u)_+,
    b_v=Pi_actualZ{u:k_u<k_v},
    E_J=int sum_vu J_v delta_+^2 Pi_v Pi_u dlogxi,
    C_b=int sum_v (A_v/w_g(v)) b_v Pi_v dlogxi,
    C_0=int sum_v (A_v/w_g(v)) Pi_v dlogxi.

Check I^2<=E_J C_b and C_b<=C_0. This is the specified parent Cauchy pair; do not replace it by a different weighted energy/companion. Separately check Ewhole=int e_xi Var_Pi(k)dlogxi <=n e_ell. Ewhole is a calibration, not a sufficient global payment argument.

Posterior branch diagnostic: rho=1 gives b_v<=L^2 w_g(v)^2 for v in Cset. Report Lmin_squared=max_(time,v in Cset) b_v/w_g(v)^2 and row-wide passes at L in {1,2}, alongside I. On any fixed-score/current-support open segment the lower-score group has strictly smaller scores than its complement, so its posterior b_v is nondecreasing; its supremum is at the right endpoint limit. Thresholds and deletions change the group/support, so inspect both adjacent segment endpoint limits. This computes the row-wide gate exactly with rational arithmetic. It does not claim the gate holds on all original rows or compute a time-varying terminal A.

## 3. Exact clocks and rigorous integration

Split at all rational coordinate thresholds, deletion times, ell,g. On each open segment, scores and support are fixed and nu_v w_v=a_v xi^(-k_v), a_v rational. The quantities c_g, expGamma, expGammaC and B_Gamma are exact rational products of endpoint ratios to integer powers. Lambda is exact rational too: whenever r>k_u, the integral of (r-k_u)w_u/c dlogxi equals the increase of w_u/c between endpoints. Include deleted full-initial B in this calculation. Check c continuity at every threshold.

The integrals I,E_J,C_b have the form int P(xi)/E(xi)^2 dxi, with nonnegative rational monomial coefficients, where E=sum_current a_v xi^-kv. C0 and Ewhole have denominator E^1; for Ewhole use the symmetric formula

    e Var=(1/(2e)) sum_vu(k_v-k_u)^2 nu_v w_v nu_u w_u.

For f=P/E^d, d in {1,2}, use rational midpoint quadrature with an outward interval second-derivative remainder:

    f''=P''/E^d-2d P'E'/E^(d+1)
         +P[d(d+1)(E')^2/E^(d+2)-d E''/E^(d+1)].

Monomial endpoint bounds enclose all derivatives and E stays strictly positive. A subinterval [a,b] has midpoint contribution (b-a)f(mid), plus/minus sup|f''|(b-a)^3/24. Adaptively bisect rational endpoints, prioritizing the largest error contribution. Before evaluation factor the same current minimum score from every weight, updating numerator powers consistently. Existing frozen directed Decimal arithmetic and exact rational coefficients only; ordinary float quadrature is not a certificate. A slower exact-rational Darboux fallback is valid. Common mass rescaling must preserve I,EJ,Cb,C0 and lambda/Bmass; Ewhole scales with the mass (so compare Ewhole/(n eell)).

Tolerance/cost: I absolute width <=1e-6*max(1,n); EJ,Cb,C0 widths use displayed natural scales and target relative 1e-4 away from zero, not a hidden absolute1 floor for exponentially large/small quantities. At most20,000 adaptive leaves per row and recorded runtime without a wall-clock abort; on budget exhaustion retain valid intervals and mark unresolved. Select at most4 difficult valid rows for a second tighter enclosure; do not rerun all cases at larger precision without a failure. Exact zero pair coefficients bypass quadrature.

### Exact two-source calibration (all high-n blocker rows)

Target: nu=1,A=1,C_i=1/2, score n on (ell,g). Blocker: nu=epsilon,A=0,C_i=1, score0. Take g=1. Let a=w_g(target)=2^-n, J=a, and let b be g or the pre-deletion time if blocker is deleted. Then

    I=Pi_target(ell)-Pi_target(b),
    E_J=n a I, C_b=I/(n a), hence E_J*C_b=I^2 exactly,
    C0_before=(1/(n a)) log[Pi_block(b)/Pi_block(ell)],
    Ewhole=n epsilon log[Pi_block(b)/Pi_block(ell)].

After deleting the blocker, I,EJ,Cb,Ewhole vanish; C0 adds log(g/delete_time)/a. Enclose the logarithm of the exact rational posterior ratio with the existing frozen certified log runtime. For no deletion, GammaC=0, lambda=epsilon(1-a)/(a+epsilon)<1 and B_mass=I EXACTLY. This is a mandatory identity check. With deletion, full-initial lambda remains the same numerator but has the actual smaller terminal e_g=a, so B_mass is a conservative envelope and lambda may fail its <1 gate. Tiny terminal posterior cannot be inferred merely from deletion.

Equal-score sources have I=EJ=Cb=Ewhole=0 exactly; C0 can remain positive. These checks demonstrate why the masked companion matters.

## 4. Frozen minimal case manifest (22 inputs)

Stage1 (8 two-source calibration inputs; the invalid input is counted):

1. common_perm_n2: permutations of(2/5,4/5), masses(1,3), both Cset.
2. common_soft_n4: two all-soft profiles below1/2, masses(1,2^-16), both Cset; equal scores give zero traffic.
3–5. blocker_n2 with epsilon=1,2^-2,2^-4, no deletion.
6. blocker_n4 with epsilon=2^-8, no deletion.
7. same as6, blocker deleted at3/4.
8. intentional attempt to delete its A-positive target: reject, never integrate.

Stage2 (6 inputs):

9–10. frozen R172 all_below_half_n8 and mixed_1 from /Users/zhengzhihao/Desktop/T/output/centered_cube_round172_20261016_final_checkpoint/common_clock_check.py. Preserve nu/C, g=9/10, deletion grouping/times; replace terminal amplitude by1_Cset with Cset=original keep sources and record this change. Algebraic control only.
11–12. competing trajectories: v all C_i=3/5, u half2/5 and half9/10, both Cset; (n,mass_u/mass_v)=(4,1),(8,2^-8).
13. unordered B: same competing profiles, n4,masses(1,1), only v in Cset and u in B. Static lambda identity is inapplicable.
14. three profiles[3/8]^n,[3/4]^n,[7/8]^n, n8,masses(1,epsilon,epsilon^2),epsilon2^-8; first two Cset, third B deleted at13/16.

Stage3 (8 inputs, exact blockers first):

15–16. blocker n32,epsilon2^-32 and2^-64, no deletion.
17. blocker n64,epsilon2^-128, no deletion.
18. blocker n64,epsilon2^-192 (epsilon=a^3), no deletion; this tests the full-clock L1 posterior gate despite large Gamma.
19. blocker n128,epsilon2^-256, no deletion.
20. same as19 with blocker deleted at3/4.
21. competing two-Cset profiles at n64,mass ratio2^-64.
22. unordered B at n32,epsilon2^-32.

For epsilon=a^3 the terminal b=a^2/(1+a^2)<=a^2, so the entire clock passes L1 by monotonicity. Epsilon=a^2 does not automatically pass the full-clock square gate. Do not confuse small raw mass with the required relative posterior mass.

No Cartesian expansion. All high-n constant-score blocker rows are exact FTC/log. Prioritize exact calibrations, then the few noncalibration interval rows. At most22 total inputs; it is acceptable to mark a difficult integral unresolved at the declared budget rather than enlarge the suite or hide error.

## 5. Output, interpretation and review

Per case preserve exact nu,C,A/partition, support/deletion schedule, breakpoints, eell,eg, cg, expGamma/expGammaC, lambda exact and applicability, Bmass/BGamma, I/EJ/Cb/C0/Ewhole enclosures, pair contributions where cheap, Lmin_squared and L1/L2 flags, exact-identity checks, derivative bounds/error width, precision/leaves/runtime and unresolved status. Record dependencies with SHA256 and write HERE siblings for migration. Do not represent a ratio involving an unresolved denominator as a precise decimal. Interval signs decide inequalities only when separated; exact structural identities can be checked independently.

Meaningful result: distinguish tiny-mass overpayment by fixed-initial infimum, exact repair by lambda for ordered blockers, heterogeneity/competing scores when Cset itself has a range, legal deletion effects, and quantitative masking Cb/C0. The new branch is not claimed to cover every finite row. These tests cannot certify original physical good/J/FIRST or the general weak bound. Parent owns final theorem scope; Sol independently audits implementation and selected certificate outputs before integration.

This design is frozen for implementation after the parent-specified formulas above. No additional energy functional or exponent fit is authorized.
