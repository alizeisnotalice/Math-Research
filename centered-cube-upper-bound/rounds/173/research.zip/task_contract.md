# R173: mass-sensitive global extremal geometry

Parent verified clean main e66d5a720be545f6b308e7647f08224ffb755d56. R172 is progress, independently audited and remotely pushed. Goal remains general n^(1/2+o(1)) weak bound, not solved. Priority constructive large heterogeneity geometry.

Read only R172 final backup /Users/zhengzhihao/Desktop/T/output/centered_cube_round172_20261016_final_checkpoint/{task_contract.md,joint_extremal_geometry.md,report.md} as needed. Fixed original row S=Zell includes all later deleted sources; wt=product min(1,C_i/xi_t), k=#C_i<xi_t, et=int_Zt wt nu, Pi=1_Zt wt nu/et; e_g>0. Terminal A=1_good rho J/(3Q), support Zg, p A wg<=KJ/3; mother A0=1_good rho has p A0 wg<=KQ. high p e_g>=2Kq; complete same-input FIRST; hard16/3, outer2Lambda; common b before leaves, unique j, actual dx. All original gates, alpha, source mass, histories remain.

R172 m(t)=essinf_initial k; Gamma(v)=int(kv-m) dt/t; original positive pair <=eg^-1 int A wg(expGamma-1)nu. Gamma<=.5logn J-share paid root; Sfuture-Gamma>=h paid epsilon qdx; others open. Essential infimum can overpay if its low-score sources have tiny actual mass. Need exploit mass and normalization rather than assume concentration/independence. F,C not probability kernels; J is fixed probability; Q adaptive cannot space-integrate freely. No unseen theorem or guessed n exponent.

Numerical initial/existing-stress/expanded stages; finite evidence distinct from proof. Read assigned relevant skills before invoking results. Allowed methods elementary finite/continuous probability, exact original contracts, R172 audited statements. Known risk: raw ratio2^n, arbitrary strong covariance/soft-tail independence, moving-support clocks gain uncharged jump variation, fixed kernels do not normalize adaptive ones. Physical triplet examples are not FULL counterexamples.

All agents share checkout: own only assigned file(s) under rounds/173/work, do not revert others. No git, PDF, external messaging or spawning. Stop after bounded deliverable. Final claims require independent Sol review; parent owns integration/LaTeX/commit.
