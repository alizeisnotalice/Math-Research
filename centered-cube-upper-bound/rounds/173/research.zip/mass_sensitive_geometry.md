# R173: an explicit mass charge for low-score sources

Status: a proved mass-sensitive original-row inequality, with complete J-share source and receiver prices on its stated branches. The unrestricted weak bound remains open. The numerator of the charge below is a linear source-growth integral for a frozen clock, divided by an explicit original endpoint mass; in the score-ordered case its numerator is a static endpoint mass difference. It is not a renamed positive-traffic moment. All measures, posteriors, alpha and original gates remain unchanged.

## 1. Quantifiers and the original quantity

Fix an original row (including x,y,V,j and all original outer selectors). On ell<=t<=g, let S=Z_{ell+} be the entire initial support, including all later deleted sources. The original finite measure is nu, the nested supports are Z_t, and

    w_t(z)=product_i min(1,C_i(y,z)/xi_t),
    k_t(z)=#{i:C_i(y,z)<xi_t},
    e_t=int_{Z_t} w_t dnu,   Pi_t=1_{Z_t}w_t nu/e_t.

We work on e_g>0. The initial endpoint uses the original right-hand support. The weights are continuous and strictly positive on this finite interval, and -d log w_t/d log t=k_t almost everywhere. Original terminal masks are supported on Z_g. For the J share,

    A=1_good rho J/(3Q),   0<=A<=1,
    p A_v w_g(v)<=K J_v/3.

For the mother share put A0=1_good rho, so p A0_v w_g(v)<=KQ_v. The score orientation is the audited original one: v is the good terminal slot and delta_+=(k_t(v)-k_t(u))_+. Other original pair indicators in [0,1] may be retained on the left below. The row quantity is

    I[A]=int_actual int int A_v delta_+(v,u) Pi_t(dv)Pi_t(du) dt/t.

The actual far interval can be extended positively to [ell,g]. No negative signed credit is used.

Choose any measurable partition S=C disjoint-union B, fixed for the whole row before the time integration. It may depend on the original outer parameters. Neither C nor B is removed from the original Pi. The theorem first pays terminal slots in C; slots in B remain explicitly present in the complementary account. Assume nu(C)>0, and define

    r(t)=essinf_{z in C} k_t(z),
    c(t)=exp(-int_ell^t r(s) ds/s),   c(ell)=1,
    v_t(z)=w_t(z)/c(t),   E_t=e_t/c(t),
    E_g=e_g/c(g).

The symbol C for a source group is distinct from the physical scalar kernel C_i(y,z). The clock c is continuous and does not change at any deletion. For nu-almost every z in C, v_t(z) is nonincreasing. No such monotonicity is assumed on B or on E_t.

## 2. The source-growth charge and the actual denominator

Define the positive growth of the reduced weights of the full initial group B:

    G(t)=int_B (r(t)-k_t(u))_+ v_t(u) nu(du),
    L(t)=int_t^g G(s) ds/s,
    lambda(t)=L(t)/E_g,   lambda=lambda(ell).                 (MG1)

In particular B in this definition includes deleted sources after their deletion times. This deliberately charges their hypothetical later reduced-weight growth using the same physical w_t. It prevents an uncharged downward jump of a moving-support clock. The growth numerator has no factor 1/e_t or original pair traffic inside it; for the frozen clock it is a linear source integral. Its explicit normalization by E_g makes lambda a mass ratio, not a linear functional of a varying input.

For every t,

    E_g-E_t
       <=int_{Z_g} [v_g(u)-v_t(u)] nu(du)
       <=int_B [v_g(u)-v_t(u)]_+ nu(du)
       <=L(t).

The first line uses Z_g subset Z_t; the second uses reduced-weight monotonicity on C; the third integrates positive derivatives on B. Thus

    E_t>=E_g[1-lambda(t)].                                  (MG2)

This argument includes arbitrary original deletions and does not require E_t to be monotone. If lambda<1, the lower bound is positive throughout the interval.

For v in C define

    Gamma_C,t(v)=int_t^g [k_s(v)-r(s)] ds/s,
    Gamma_C(v)=Gamma_C,ell(v)>=0.

Then v_t(v)=v_g(v)exp Gamma_C,t(v) exactly. For almost every such v and t,

    int (k_t(v)-k_t(u))_+ Pi_t(du)
       <=k_t(v)-r(t)+G(t)/E_t.                              (MG3)

Indeed (k_v-k_u)_+<=(k_v-r)+(r-k_u)_+ when k_v>=r. The second summand vanishes almost everywhere on C; on surviving B it is bounded by the full-initial-B integral defining G. This is the only enlargement of the obstructing source in (MG3).

## 3. Exact mass-sensitive original-pair estimate

Suppose lambda<1. Let H(v) be any measurable terminal source gate in [0,1], supported in C and fixed in time. Combining (MG2)--(MG3) and applying Tonelli gives

    I[HA]
      <=int_C H(v) A_v w_g(v)/e_g nu(dv)
         int_ell^g exp Gamma_C,t(v)
           { [k_t(v)-r(t)]/[1-lambda(t)]
                         +[G(t)/E_g]/[1-lambda(t)]^2 } dt/t.

The expression inside the last time integral is exactly

    -d/d log t {exp Gamma_C,t(v)/[1-lambda(t)]}.

Both Gamma_C,t and lambda(t) are absolutely continuous in log t. Therefore

    I[HA] <=(1/e_g)int_C HA w_g F_C(v) dnu,
    F_C(v)=exp Gamma_C(v)/(1-lambda)-1.                     (MG4)

This is the central inequality. It has no extra n, time-length factor, deletion count, or lower bound on individual source masses. Every actual posterior is still the original Pi. The same proof applies to A0. No claim is made that arbitrary partitions satisfy lambda<1.

Measurability and null sets are handled as in R172: r(t) is the minimum integer a for which int_C 1_{k_t<=a}dnu>0. This is measurable jointly in the original parameters and t. Tonelli supplies a single nu-null set for the almost-everywhere score inequalities. Continuous versions of the reduced weights then give the endpoint comparisons for all t. The physical finite interval and 0<=k,r<=n bound all reduced weights by 2^n, so the source-growth integrals are finite for finite nu. Parameter-dependent gates below are measurable by these integral formulas. No new measurable selector theorem is invoked.

## 4. Static endpoint mass formula for ordered low-score sources

A particularly useful geometric case is

    k_t(u)<=r(t) for nu-almost every u in B
                  and almost every t in [ell,g].            (MG5)

In this case every reduced weight on B is nondecreasing. Its positive growth is its full endpoint difference, so

    lambda=(1/e_g)int_B [w_g(u)-c(g)w_ell(u)] nu(du)
           <= (1/e_g)int_B w_g(u) nu(du) =: eta_B.          (MG6)

The endpoint mass on the right is calculated on the full initial B, including later deleted sources. It is not silently replaced by Pi_g(B). If no B source is deleted, eta_B=Pi_g(B); with deletions the full-initial mass can be larger. Thus arbitrary original deletions are supported at their actual explicit cost.

If eta_B<=eta<1, then (MG4) implies the completely explicit bound

    F_C(v)<=exp Gamma_C(v)/(1-eta)-1.                       (MG7)

This charges tiny or comparable low-score source mass instead of treating a single arbitrarily small source as a full essential-infimum obstruction. The score-order condition (MG5) has a concrete physical sufficient condition: for each coordinate, C_i(y,u)>=esssup_{z in C} C_i(y,z) for almost every u in B. Then every soft coordinate of u is soft for every source in C. Since the physical scalar C is decreasing with distance, coordinatewise closer-to-y blockers satisfy this sufficient condition. The score condition itself is more general and retains cross-coordinate correlations.

A bounded algebraic calibration illustrates the improvement. Suppose every source in C is soft in all n coordinates throughout [ell,g], while every source in B is hard in all coordinates. Then r=n, Gamma_C=0, c(g)=(ell/g)^n, and

    lambda=(1-(ell/g)^n)nu(B)/e_g.

If nu(B)/e_g<=eta<1, all C slots have F_C<=eta/(1-eta), whereas the original full-support essinf clock assigns Gamma=nlog(g/ell) to them. B slots have zero outgoing positive score difference, including under arbitrary deletions. This demonstrates a strict mass-sensitive improvement of the original-row bound. It is not a certification of a FULL high/FIRST/history instance; no artificial two-point input is substituted in the theorem.

## 5. Complete global prices on the stated source branches

Keep the same original source measures, alpha, high and FIRST. For lambda<1 define

    Theta_C(v)=Gamma_C(v)-log(1-lambda),
    F_C(v)=exp Theta_C(v)-1,
    S_v=log(P_{s,b}(x-v)/J(x-v)).

Choose M>=0 and h real. On each such row, partition terminal C slots into

    P_C={Theta_C<=M},
    Q_C={Theta_C>M and S_v-Theta_C>=h},
    R_C={Theta_C>M and S_v-Theta_C<h}.                      (MG8)

These gates are fixed during the row's time integration. From (MG4) and the original good inequality,

    p I[HA] <= K/(3e_g) int_C H(v) J_v F_C(v) nu(dv).       (MG9)

On P_C, F_C<=exp M-1. On Q_C, J F_C<=exp(-h)P_{s,b}. At the moment the remaining integrand no longer depends on y, original high and FIRST give

    int_high beta(dy)/e_g
       <=(2Kq)^(-1)int p_y beta(dy)<=1/(2K).

All indicators are dropped only from nonnegative integrands. Apply the original hard cap 16/3 once and the original factor 2Lambda. Keep the unique j indicator until its dependence disappears; then sum it. Integrating the common probability kernel J in x, and using sum_V nu_V<=sum_V beta_V, yields

    RawPositive_J[P_C] <=(16Lambda/9)(exp M-1) W_beta.       (MG10)

For Q_C first sum V, using the same common future kernel P_{s,b} and sum_V nu_V<=f. Complete FIRST gives sum_V P_{s,b}nu_V<=q. Therefore

    RawPositive_J[Q_C] <=(16Lambda/9)exp(-h) E int_D q dx.   (MG11)

Original histories and window conventions are exactly those used in the audited R172 passage; no new history normalization, extra window merge or adaptive-kernel spatial normalization is asserted. These bounds use real dx and the full beta, not nu in place of beta.

Take M=(log n)/2+log L_n, L_n>=1, and h=log(16Lambda/(9epsilon)). Then (MG10)--(MG11) cost at most

    (16Lambda/9)sqrt(n)L_n W_beta + epsilon E int_D q dx.

For the explicit ordered-mass case eta_B<=eta<1, it suffices on P_C that

    Gamma_C(v)<=M+log(1-eta).

For example eta<=1/2 and Gamma_C<=log(sqrt(n)L_n/2), where the latter threshold is nonnegative, give the stated root-source fee. There is no summation over independently chosen core partitions: one measurable partition per original row is chosen for this statement. If several candidate partitions are to be used, assign each row/source once before invoking these prices.

## 6. Mother traffic has an explicit receiver absorption branch

Replace A by A0 and keep the active terminal domain C intersect {A0>0} until its gate is applied. From (MG4) and good,

    p I[H A0] <=K/e_g int_{C intersect {A0>0}} H Q_v F_C(v) nu(dv).

On any terminal source gate H supported where F_C<=zeta, high gives zeta Qnu_V/2. Summing V uses the common legal future tests constituting Q, not its spatial integral. Hence

    RawPositive_mother[H] <=(16Lambda/3)zeta E int_D q dx.   (MG12)

Taking zeta=3epsilon/(16Lambda) gives an actual epsilon receiver-price branch. In the ordered case Gamma_C=0 and eta_B<=eta, the explicit sufficient condition is eta<=3epsilon/(16Lambda+3epsilon), equivalently eta/(1-eta)<=3epsilon/(16Lambda). This can absorb rows for which the R172 full-support Gamma is of order n. As always, unassigned B slots remain unless their original positive score traffic vanishes, as it does in the calibration above. J-share and mother estimates are alternative accounts or must be assigned disjointly; their same positive traffic must not be charged twice.

## 7. What is paid and the precise remaining tasks

For a single fixed measurable core/blocker partition, the complete original source/time domain is partitioned into:

1. Rows lambda<1 and terminal slots P_C: paid by (MG10).
2. Rows lambda<1 and terminal slots Q_C: paid by (MG11).
3. Rows lambda<1 and terminal slots R_C: not paid here.
4. Terminal slots in B, and all rows lambda>=1: not paid here, apart from any separately established original branch applied on a disjoint assignment.

The low-score source mass is genuinely used in (MG1)--(MG7); no bound on the original I or its posterior hazard has been assumed. The static ordered-source estimate (MG6) makes this distinction explicit. Nevertheless, the original assumptions have not been proved to supply a partition with affordable lambda and Gamma_C on the entire remaining middle region. The exact unresolved geometric problem is to control the full-initial blocker growth

    (c(g)/e_g) int_B int_ell^g (r-k_t(u))_+
                                      [w_t(u)/c(t)] dt/t nu(du)

jointly with the core losses Gamma_C and the common future comparison S_v, or to pay the unassigned B and R_C traffic directly. This source-growth integral is a specified kernel of the original nu, with all deleted-source cost visible. Calling it small without deriving it from geometry/mass is not a proof of the general estimate.

No independent new numerical examples, broad counterexample search, unknown-moment axiom, signed-credit reuse, or moving-support clock is needed for this result. The parent's separate paid energy/companion route may be combined only after a disjoint assignment; it is not re-proved or claimed to be closed here.
