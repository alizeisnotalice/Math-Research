# R173 independent numerical review

Status: parent identity script and final mass-clock implementation reviewed; final producer completed. These are finite algebraic/interval tests, not physical or FULL certificates.

## Parent identity_check.py

Independent formula audit passes. Its V is the unnormalized e Var_Pi(k), not Var alone. Along a fixed-score segment mu'_v=-k_v mu_v, the displayed expression for V' equals -sum mu_v k_v(k_v-m)^2<=0. Its normalized filtered covariance derivative equals f V/e-VA. The A-weighted two-slot square moment equals VA+f V/e. Both threshold-jump identities follow by expanding the shifted scores about the old mean. The variance mixture identity is exact; its filtered deletion identity uses deleted A=0 slots, as in the input.

There are seven identities per model and 30 models, so 210 is the correct count. The cubic factorization (d-3b)^2(4d-3b)=4d^3-27b(d-b)^2 is exact; b in [0,d] makes its factors nonnegative, including d=0. These checks verify the formulas on finite rational data. They do not substitute for their general proof or a source-budget estimate.

## Planned mass-clock audit

Verify full-initial B in lambda after deletion, actual active support in b_v and Pi, exact rational clocks/expGamma/lambda, original partition and deletion legality, J=A wg zero-slot convention, parent EJ/Cb/C0 orientation, midpoint derivative error enclosure, and two-source exact FTC/log calibration. In particular epsilon=a^3, a=2^-n, is a sufficient full-clock L1 blocker calibration; epsilon=a^2 is not. No quadrature midpoint is a certified integral without its remainder enclosure.

## Posterior-gate endpoint certification

On an open segment with fixed active support and scores, fix active v and G={u:k_u<k_v}. If either G or its complement has zero posterior mass, b_v is identically0 or1. Otherwise let m_G,m_comp be their conditional mean scores. Differentiating the finite normalized product weights gives

    d b_v / dlogxi = b_v(1-b_v)(m_comp-m_G) >=0,

because every score in G is strictly less than k_v and every complement score is at least k_v. Therefore each segment's right endpoint limit certifies its supremum. At every score threshold or deletion recompute G and the active measure; the whole-window supremum is the maximum over these segment limits, not merely the terminal posterior. Frozen rho and w_g introduce no further time derivative. This justifies the exact rational Lmin-squared calculation specified in the design.


## Final mass-clock implementation and results

Sol took ownership after the implementer explicitly stopped. The final code corrects the derivative rising factorial for inverse powers, dlog-to-dxi exponent, repeated denominator powers, A in the companion, per-segment posterior support, exact blocker initial-posterior ratio, the inherited three-event deletion schedule, high-n exact-branch dispatch, and mass-rescaling coefficients. The derivative supremum uses exact Fraction conversions of Decimal endpoints, avoiding ambient-context downward rounding. Comparisons use lower bounds on the claimed right side, with exact Fraction identities/rational comparisons used where available; comparing upper endpoints to upper endpoints is not accepted.

The generalized two-source segment FTC independently follows from dPi_h/dlogxi=-(k_h-k_l)Pi_hPi_l on each fixed-score segment. For posterior drop D and score gap d>0 it gives Iseg=A_h D, EJseg=J_h d D and Cbseg=A_h D/(wg_h d). Legal deletion leaves one source and no further pair traffic. The implementation stores these exact segment contributions and their exact sums; C0 and Ewhole retain directed logarithm or midpoint/second-derivative enclosures.

Final manifest:22 inputs,21 valid and one actual validator rejection of deleting an A-positive source. Eighteen valid rows use exact rational two-source pair integrals. All21 pass the mass-clock inequality (13 exact equalities,5 exact strict rational comparisons,3 directed interval comparisons), all21 pass Cb<=C0 and Ewhole<=n eell. Cauchy is an exact equality in18 rows and a separated interval comparison in3. No primary integral misses its declared tolerance, and no comparison is reported ambiguous or failed. These counts are finite evidence only; they do not enlarge the theorem's scope.

The n64 epsilon=a^3 calibration passes the entire-clock L1 posterior gate, with I approximately2.9387358771e-39 despite Gamma=64log2. The epsilon=a^2 counterpart fails that gate and has I approximately5.4210108624e-20. Thus small raw blocker mass alone is not confused with the square posterior criterion. For undeleted constant-score blockers the mass-clock envelope equals I exactly; legal deletion keeps full-initial B in lambda and gives a conservative bound. The unordered-B cases correctly use the dynamic positive-part formula rather than the inapplicable static identity.

A common mass-rescaling check preserves lambda,Bmass,I,EJ,Cb,C0 and scales Ewhole,eell,eg by the same factor. No normalized-J, physical-kernel, good/rho, FIRST, source-budget, hardcarrier or FULL claim is attached to these algebraic rows. Parent retains final proof audit and reproduction responsibility.
