# R173 finite mass-clock and masked-energy certificate

The final producer checks22 selected inputs:21 valid finite algebraic rows and one rejected attempt to delete an A-positive source. All21 valid rows satisfy the stated mass-clock comparison, Cb<=C0, weighted Cauchy comparison and Ewhole<=n eell, using exact rational identities or separated directed interval bounds. No primary integral misses its declared tolerance. This is finite evidence; it is not a physical-kernel, FIRST, source-budget, carrier/history or FULL certificate.

Eighteen rows have two sources. On every fixed-score/support segment, with higher score h, gap d>0 and posterior drop D=Pi_h(left)-Pi_h(right), the exact contributions are

    Iseg=A_h D,
    EJseg=J_h d D,
    Cbseg=A_h D/(wg_h d).

The JSON retains these exact Fraction contributions, including score-order reversals. For a deleted A-zero blocker, subsequent one-source pair traffic is zero. Common-score models have I=EJ=Cb=0 while C0 can remain positive.

The other integrals use rational midpoint quadrature with an outward directed second-derivative remainder on every threshold/deletion segment. C0 and whole energy for the constant-score blocker use certified logarithms of rational posterior ratios. The interval precision is42 decimal digits. Adaptive integrations use a deterministic maximum20,000 leaves per functional; runtime is recorded rather than used as a nonreproducible stopping rule. The final run took about one second on this host.

The fixed-initial mass clock and posterior blocker mass have different supports. Lambda always includes the full initial B, extending w/c after deletion. The posterior b_v uses only actual current survivors. The ordered-B static identity is checked exactly where applicable; both unordered-B cases use the dynamic positive-part formula. Frozen R172 controls reproduce three deletion events at3/5,7/10,4/5, while explicitly replacing their old amplitude by the fixed keep-mask A=1_C.

The most useful calibrations are exact:

- For an undeleted constant-score blocker, the mass-clock bound equals I, even though the R172 essential-infimum envelope can greatly overpay a tiny blocker.
- For n64, a=2^-64 and epsilon=a^3, the full clock satisfies b<=a^2 (L=1), despite Gamma=64 log2. Its I is approximately2.9387358771e-39. The epsilon=a^2 case fails that full-clock square gate; its I is approximately5.4210108624e-20.
- Deleting B does not turn its full-initial lambda contribution into zero terminal posterior mass. The deletion bound remains conservative.

All21 Cauchy comparisons are certified:18 exact equalities and3 separated interval comparisons. The mass-clock comparisons comprise13 exact equalities,5 exact strict rational comparisons and3 separated interval comparisons. All21 Cb<=C0 and Ewhole<=n eell comparisons have separated or exact bounds. The common mass-rescaling check preserves lambda,Bmass,I,EJ,Cb,C0 and scales Ewhole,eell,eg together.

Run `python3 centered-cube-upper-bound/rounds/173/work/mass_clock_check.py`. The script writes its JSON beside itself through HERE and records frozen dependency hashes. It uses only existing Fraction and directed Decimal runtimes, with no installation. Scope and formula details are in numerical_design.md; independent implementation/formula review is in numerical_review.md. Numerical passes do not establish universal coverage of the lambda<1 or posterior-gate branches.
