#!/usr/bin/env python3
"""R173 exact mass-clock and rigorous finite integral checks; algebraic models only."""
from fractions import Fraction as F
from decimal import Decimal
from pathlib import Path
from functools import lru_cache
import heapq
import hashlib, importlib.util, json, math, platform, sys, time

HERE=Path(__file__).resolve().parent
R172=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round172_20261016_final_checkpoint')
SOURCE=R172/'common_clock_check.py'
DEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round166_20261015_final_checkpoint/window_certificate.py')
LOGDEP=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py')
sp=importlib.util.spec_from_file_location('r173_interval',DEP);iv=importlib.util.module_from_spec(sp);sp.loader.exec_module(iv)
I=iv.I; XI_L=F(1,2); XI_G=F(1)
sp=importlib.util.spec_from_file_location('r168_log_runtime',LOGDEP);logmod=importlib.util.module_from_spec(sp);sp.loader.exec_module(logmod)
sp=importlib.util.spec_from_file_location('r172_common_clock',SOURCE);cc=importlib.util.module_from_spec(sp);sp.loader.exec_module(cc)

def fs(x): return f'{x.numerator}/{x.denominator}' if isinstance(x,F) else str(x)
def qinterval(x): return I(F(x))
def imid(x): return I((x.lo+x.hi)/2)
def iout(x): return {'interval':x.out(),'mid':str((F(x.lo)+F(x.hi))/2)}
def prod(xs):
    z=F(1)
    for x in xs:z*=x
    return z
def wt(Cs,x): return prod(min(F(1),c/x) for c in Cs)
def kval(Cs,x): return sum(c<x for c in Cs)
def intervals(row):
    cuts={row['ell'],row['g']}
    for Cs in row['C']:
        cuts.update(c for c in Cs if row['ell']<c<row['g'])
    cuts.update(t for t in row['deletions'] if row['ell']<t<row['g'])
    return sorted(cuts)

def normalize(row):
    n=len(row['C'][0]); m=len(row['nu'])
    assert len(row['C'])==m==len(row['A']) and all(len(c)==n for c in row['C'])
    assert all(x>0 for x in row['nu']) and all(0<=a<=1 for a in row['A'])
    assert all(0<c<=1 for Cs in row['C'] for c in Cs)
    assert row['Cset'] and set(row['Cset'])=={i for i,a in enumerate(row['A']) if a>0}
    removed=set()
    for t,ids in row['deletion_groups']:
        assert row['ell']<t<=row['g']
        assert all(row['A'][i]==0 and i not in removed for i in ids), 'only previously undeleted A-zero sources may be deleted'
        removed.update(ids)
    return n

def interval_exp_fraction_power(r):
    # Exact rational power; all clock exponents are integers.
    return F(r)

def row_clocks(row):
    n=normalize(row); cuts=intervals(row); S=range(len(row['nu']))
    Cset=row['Cset']; rsegs=[]; c_at={row['ell']:F(1)}; ccur=F(1)
    for a,b in zip(cuts,cuts[1:]):
        m=(a+b)/2; ks={v:kval(row['C'][v],m) for v in S}
        r=min(ks[v] for v in Cset); mn=min(ks.values())
        rsegs.append((a,b,r,ks));
        ccur*= (a/b)**r
        c_at[b]=ccur
    # exp(Gamma) uses rational endpoint powers directly, without numerical logs.
    egammaC={v:prod((b/a)**(k[v]-r) for a,b,r,k in rsegs) for v in Cset}
    egamma={}
    for v in S:
        egamma[v]=prod((b/a)**(k[v]-min(k.values())) for a,b,r,k in rsegs)
    cg=ccur
    wg={v:wt(row['C'][v],row['g']) for v in S}
    eell=sum((row['nu'][v]*wt(row['C'][v],row['ell']) for v in range(len(S)) if v in row['active_initial']),F(0))
    eg=sum((row['nu'][v]*wg[v] for v in row['active_terminal']),F(0))
    assert eg>0
    # Initial-support mass clock lambda, including B sources deleted before g.
    lam=F(0); lam_terms=[]
    B=[v for v in S if v not in Cset]
    for a,b,r,ks in rsegs:
        ca=c_at[a]
        for u in B:
            d=r-ks[u]
            if d>0:
                coeff=row['nu'][u]*prod(c for c in row['C'][u] if c<(a+b)/2)
                # w/c = coeff*a^-r/c(a) * xi^(r-ku); integrate d*(w/c)dlog.
                val=(cg/eg)*coeff*(a**(-r))/ca*(b**d-a**d)
                lam+=val; lam_terms.append(dict(segment=[fs(a),fs(b)],source=u,r=r,ku=ks[u],value=fs(val)))
    bmass=None if lam>=1 else sum((row['A'][v]*row['nu'][v]*wg[v]*(egammaC[v]/(1-lam)-1) for v in Cset),F(0))/eg
    bgamma=sum((row['A'][v]*row['nu'][v]*wg[v]*(egamma[v]-1) for v in S),F(0))/eg
    static_applicable=all(ks[u]<=r for a,b,r,ks in rsegs for u in B)
    static_rhs=sum((row['nu'][u]*(wg[u]-cg*wt(row['C'][u],row['ell'])) for u in B),F(0))/eg if static_applicable else None
    if static_applicable: assert lam==static_rhs
    return dict(n=n,cuts=cuts,rsegs=rsegs,cg=cg,wg=wg,eell=eell,eg=eg,egammaC=egammaC,egamma=egamma,
        GammaC={v:fs(x) for v,x in egammaC.items()},Gamma={v:fs(x) for v,x in egamma.items()},lam=lam,lam_terms=lam_terms,
        bmass=bmass,bgamma=bgamma,static_applicable=static_applicable,static_rhs=static_rhs)

# Certified rational midpoint enclosure f=P/E^d. Coefficients are exact Fractions;
# the runtime interval endpoints are directed decimals from the frozen R166 module.
def poly_interval(poly,x,der=0):
    z=I(0)
    for p,c in poly.items():
        if c==0 or (p==0 and der>0):continue
        ff=math.prod(p+j for j in range(der)) if der else 1
        cc=c*ff*((-1)**der)
        # x^-p derivative: (-1)^d (p)_d x^(-p-d)
        lo,hi=F(x[0]),F(x[1]); u=lo**(-(p+der));v=hi**(-(p+der))
        il=I(min(u,v));ih=I(max(u,v));term=I(cc)*I(il.lo,ih.hi);z=z+term
    return z

def frac_poly_at(poly,x): return sum((c*x**(-p) for p,c in poly.items()),F(0))
def fn_interval(P,E,d,a,b):
    def f2_bound(l,r):
        pv=[poly_interval(P,(l,r),j) for j in (0,1,2)]
        ev=[poly_interval(E,(l,r),j) for j in (0,1,2)]
        e0=ev[0]
        assert e0.lo>0
        return pv[2]/(e0**d)-I(2*d)*pv[1]*ev[1]/(e0**(d+1))-I(d)*pv[0]*ev[2]/(e0**(d+1))+I(d*(d+1))*pv[0]*(ev[1]**2)/(e0**(d+2))
    m=(a+b)/2; fm=I(frac_poly_at(P,m))/(I(frac_poly_at(E,m))**d)
    f2=f2_bound(a,b); M=max(abs(F(f2.lo)),abs(F(f2.hi)))
    w=b-a; rem=I(M)*I(w**3/F(24))
    return I(w)*fm+I(-rem.hi,rem.hi)

def sum_intervals(xs):return sum(xs,I(0))
def width_fraction(x):return F(x.hi)-F(x.lo)

def integrate_function(specs, row, clocks, tol, max_leaves=20000):
    """Each segment spec gives P,E,d. Refine exact-rational leaves by largest certified error."""
    heap=[]; serial=0; total_lo=F(0);total_hi=F(0);leaf_count=0
    for a,b,E,P,d in specs:
        if not P:continue
        val=fn_interval(P,E,d,a,b)
        w=width_fraction(val);heapq.heappush(heap,(-w,serial,a,b,E,P,d,val));serial+=1
        total_lo+=F(val.lo);total_hi+=F(val.hi);leaf_count+=1
    while total_hi-total_lo>tol and leaf_count<max_leaves and heap:
        negw,_,a,b,E,P,d,val=heapq.heappop(heap)
        total_lo-=F(val.lo);total_hi-=F(val.hi);m=(a+b)/2
        for l,r in ((a,m),(m,b)):
            child=fn_interval(P,E,d,l,r);w=width_fraction(child)
            heapq.heappush(heap,(-w,serial,l,r,E,P,d,child));serial+=1
            total_lo+=F(child.lo);total_hi+=F(child.hi);leaf_count+=1
    val=I(I(total_lo).lo,I(total_hi).hi);width=total_hi-total_lo
    return dict(interval=val.out(),width=str(width),leaf_count=leaf_count,resolved=width<=tol,
        target=str(tol),max_leaves=max_leaves)

def initial_enclosure(specs):
    return sum_intervals([fn_interval(P,E,d,a,b) for a,b,E,P,d in specs if P])

def segment_specs(row, clocks):
    specs={k:[] for k in ('I','EJ','Cb','C0','Ewhole')}; pair_specs={}
    for a,b,r0,ks0 in clocks['rsegs']:
        mid=(a+b)/2; active=[v for v in row['active_initial'] if not any(t<=mid for t,vs in row['deletion_groups'] if v in vs)]
        # A segment is normalized by the same current minimum score in every monomial.
        kvals={v:ks0[v] for v in active}; m=min(kvals.values())
        aa={v:row['nu'][v]*prod(c for c in row['C'][v] if c<mid) for v in active}
        E={}
        for v in active:E[kvals[v]-m]=E.get(kvals[v]-m,F(0))+aa[v]
        def add(poly,p,c):poly[p]=poly.get(p,F(0))+c
        P={k:F(0) for k in []}
        for v in active:
            for u in active:
                dv=max(kvals[v]-kvals[u],0); coeff=row['A'][v]*dv*aa[v]*aa[u]
                add(P,kvals[v]+kvals[u]-2*m+1,coeff)
                if coeff:
                    key=f'{v},{u}'; pair_specs.setdefault(key,[]).append((a,b,E,{kvals[v]+kvals[u]-2*m+1:coeff},2))
        specs['I'].append((a,b,E,P,2))
        PJ={};PB={};P0={};PW={}
        for v in active:
            for u in active:
                d=max(kvals[v]-kvals[u],0)
                if d:
                    add(PJ,kvals[v]+kvals[u]-2*m+1,clocks['wg'][v]*row['A'][v]*d*d*aa[v]*aa[u])
                if kvals[u]<kvals[v] and row['A'][v]>0:
                    add(PB,kvals[v]+kvals[u]-2*m+1,row['A'][v]*aa[v]*aa[u]/clocks['wg'][v])
                add(PW,kvals[v]+kvals[u]-m+1, F(1,2)*(kvals[v]-kvals[u])**2*aa[v]*aa[u])
            add(P0,kvals[v]-m+1,row['A'][v]*aa[v]/clocks['wg'][v])
        specs['EJ'].append((a,b,E,PJ,2));specs['Cb'].append((a,b,E,PB,2));specs['C0'].append((a,b,E,P0,1));specs['Ewhole'].append((a,b,E,PW,1))
    return specs,pair_specs

def posterior_gate(row,clocks):
    vals=[]
    for a,b,r,ks in clocks['rsegs']:
        mid=(a+b)/2;active=[v for v in row['active_initial'] if not any(t<=mid for t,vs in row['deletion_groups'] if v in vs)]
        for v in row['Cset']:
            if v not in active:continue
            for x in (a,b):
                den=sum((row['nu'][u]*wt(row['C'][u],x) for u in active),F(0))
                low=sum((row['nu'][u]*wt(row['C'][u],x) for u in active if ks[u]<ks[v]),F(0))
                val=low/den/(clocks['wg'][v]**2)
                vals.append((val,v,x,'left_limit' if x==b else 'right_limit'))
    mx=max(vals,default=(F(0),None,None,None))
    return dict(Lmin_squared=fs(mx[0]),max_source=mx[1],at=fs(mx[2]) if mx[2] else None,
        endpoint_side=mx[3],L1_pass=mx[0]<=1,L2_pass=mx[0]<=4)

def blocker_exact(row,clocks):
    target=row['Cset'][0];block=next(v for v in range(len(row['nu'])) if v!=target)
    n=clocks['n'];a=clocks['wg'][target];eps=row['nu'][block]/row['nu'][target];end=min([t for t,_ in row['deletion_groups']] or [row['g']])
    # At end^- the blocker is still present; deletion then leaves a one-point posterior.
    wend=wt(row['C'][target],end); pi0=eps/(1+eps); pib=eps/(wend+eps)
    Ival=F(1)/(1+eps)-wend/(wend+eps)
    EJ=F(n)*a*Ival;Cb=Ival/(F(n)*a)
    lratio=logmod.log_rational(F(pib/pi0))
    C0=I(lratio.lo,lratio.hi)/(I(n*a))
    if end<row['g']:
        lg=logmod.log_rational(F(row['g']/end));C0=C0+I(lg.lo,lg.hi)/I(a)
    Ewhole=I(n*row['nu'][block])*I(lratio.lo,lratio.hi)
    return dict(I=I(Ival).out(),I_exact=fs(Ival),EJ=I(EJ).out(),Cb=I(Cb).out(),C0=C0.out(),Ewhole=Ewhole.out(),
        exact_product_check=(EJ*Cb==Ival*Ival),calibration='two-source FTC; certified logs for C0/Ewhole',stop=fs(end),
        posterior_blocker_ratio=[fs(pi0),fs(pib)])

def exact_two_source_pairs(row,clocks):
    assert len(row['nu'])==2
    totals={key:F(0) for key in ('I','EJ','Cb')};pieces=[]
    for a,b,_,ks in clocks['rsegs']:
        mid=(a+b)/2
        active=[v for v in row['active_initial'] if not any(t<=mid for t,vs in row['deletion_groups'] if v in vs)]
        if len(active)<2:continue
        h=max(active,key=lambda v:ks[v]);u=next(v for v in active if v!=h);d=ks[h]-ks[u]
        if d==0:continue
        def posterior(x):
            den=sum((row['nu'][v]*wt(row['C'][v],x) for v in active),F(0))
            return row['nu'][h]*wt(row['C'][h],x)/den
        delta=posterior(a)-posterior(b);assert delta>=0
        vals=dict(I=row['A'][h]*delta,EJ=row['A'][h]*clocks['wg'][h]*d*delta,
                  Cb=row['A'][h]*delta/(clocks['wg'][h]*d))
        for key in totals:totals[key]+=vals[key]
        pieces.append(dict(segment=[fs(a),fs(b)],higher=h,lower=u,score_gap=d,posterior_drop=fs(delta),
                           values={key:fs(value) for key,value in vals.items()}))
    assert totals['I']**2<=totals['EJ']*totals['Cb']
    return totals,pieces


def equal_score_C0(row,clocks):
    total=I(0)
    for a,b,_,ks in clocks['rsegs']:
        mid=(a+b)/2
        active=[v for v in row['active_initial'] if not any(t<=mid for t,vs in row['deletion_groups'] if v in vs)]
        assert len({ks[v] for v in active})==1
        den=sum((row['nu'][v]*wt(row['C'][v],mid) for v in active),F(0))
        coeff=sum((row['A'][v]*row['nu'][v]*wt(row['C'][v],mid)/clocks['wg'][v] for v in active),F(0))/den
        lg=logmod.log_rational(b/a)
        total=total+I(coeff)*I(lg.lo,lg.hi)
    return dict(interval=total.out(),method='exact segmentwise constant posterior times certified log',resolved=True)


def fam(name,n,nu,C,A,Cset,delgroups=(),g=XI_G,stage='stage1',tag='custom'):
    return dict(name=name,n=n,nu=list(map(F,nu)),C=[list(map(F,x)) for x in C],A=list(map(F,A)),Cset=list(Cset),
        deletion_groups=[(F(t),list(vs)) for t,vs in delgroups],deletions=[F(t) for t,vs in delgroups],
        active_initial=list(range(len(nu))),active_terminal=[v for v in range(len(nu)) if v not in {z for _,vs in delgroups for z in vs}],
        ell=XI_L,g=F(g),stage=stage,tag=tag)

def manifest():
    R=[]
    R.append(fam('common_perm_n2',2,[1,3],[[F(2,5),F(4,5)],[F(4,5),F(2,5)]],[1,1],[0,1],tag='equal_score_permutation'))
    R.append(fam('common_soft_n4',4,[1,F(1,2**16)],[[F(1,5)]*4,[F(2,5)]*4],[1,1],[0,1],tag='equal_score_common_soft'))
    for eps in (1,F(1,4),F(1,16)):
        R.append(fam('blocker_n2_eps_'+fs(eps),2,[1,eps],[[F(1,2)]*2,[F(1)]*2],[1,0],[0],tag='constant_score_blocker'))
    R.append(fam('blocker_n4_eps_2^-8',4,[1,F(1,256)],[[F(1,2)]*4,[F(1)]*4],[1,0],[0],tag='constant_score_blocker'))
    R.append(fam('blocker_n4_delete_3/4',4,[1,F(1,256)],[[F(1,2)]*4,[F(1)]*4],[1,0],[0],[(F(3,4),[1])],tag='constant_score_blocker_deletion'))
    invalid=fam('reject_delete_A_positive_target',4,[1,F(1,256)],[[F(1,2)]*4,[F(1)]*4],[1,0],[0],[(F(3,4),[0])],tag='invalid_input')
    invalid['invalid_reason']='attempted deletion of an A-positive source';R.append(invalid)
    # Two frozen R172 finite algebraic controls, with terminal amplitude replaced by the original keep mask.
    for name in ('all_below_half_n8','mixed_1'):
        src=next((x for x in cc.scenarios() if x[0]==name),None)
        if src is None:continue
        rows=src[1]; n=len(rows[0][3]);nu=[x[0] for x in rows];A=[F(int(x[2])) for x in rows]
        C_original=[list(x[3]) for x in rows];C=[[min(F(1),z) for z in cs] for cs in C_original]
        num_events=len(src[2]);groups=[];delids=[i for i,a in enumerate(A) if a==0]
        del_times=[F(1,2)+(F(9,10)-F(1,2))*F(i+1,num_events+1) for i in range(num_events)]
        # Preserve the source generator's deletion batches and event schedule.
        remaining=list(delids)
        for j,t in enumerate(del_times):
            batch=max(1,(len(remaining)+(num_events-j)-1)//(num_events-j));take=remaining[:batch];remaining=remaining[batch:]
            if take:groups.append((t,take))
        row=fam(name,n,nu,C,A,[i for i,a in enumerate(A) if a>0],groups,g=F(9,10),stage='stage2',tag='R172 algebraic control; A replaced by keep mask')
        row['C_source_original']=[[fs(z) for z in cs] for cs in C_original]
        row['C_clip_applied']=any(z>1 for cs in C_original for z in cs)
        R.append(row)
    # Crossing models: two terminal sources, optionally a B blocker.
    for name,n,ratio,Cset in [('cross_n4_r1',4,F(1),[0,1]),('cross_n8_r2^-8',8,F(1,256),[0,1]),('unordered_B_n4',4,F(1),[0])]:
        v=[F(3,5)]*n;u=[F(2,5)]*(n//2)+[F(9,10)]*(n//2)
        A=[1 if i in Cset else 0 for i in range(2)]
        R.append(fam(name,n,[1,ratio],[v,u],A,Cset,stage='stage2',tag='competing score trajectories'))
    R.append(fam('three_profile_n8_delete_B',8,[1,F(1,256),F(1,65536)],[[F(3,8)]*8,[F(3,4)]*8,[F(7,8)]*8],[1,1,0],[0,1],[(F(13,16),[2])],stage='stage2',tag='threshold crossing and legal B deletion'))
    # Exact high-dimensional blocker calibrations.
    for n,eps,name,delete in [
        (32,F(1,2**32),'blocker_n32_eps_a',None),(32,F(1,2**64),'blocker_n32_eps_a2',None),
        (64,F(1,2**128),'blocker_n64_eps_a2',None),(64,F(1,2**192),'blocker_n64_eps_a3',None),
        (128,F(1,2**256),'blocker_n128_eps_a2',None),(128,F(1,2**256),'blocker_n128_eps_a2_delete',F(3,4))]:
        groups=[] if delete is None else [(delete,[1])]
        R.append(fam(name,n,[1,eps],[[F(1,2)]*n,[F(1)]*n],[1,0],[0],groups,stage='stage3',tag='exact FTC/log calibration'))
    for name,n,ratio,Cset in [('competing_n64',64,F(1,2**64),[0,1]),('unordered_B_n32',32,F(1,2**32),[0])]:
        v=[F(3,5)]*n;u=[F(2,5)]*(n//2)+[F(9,10)]*(n//2);A=[1 if i in Cset else 0 for i in range(2)]
        R.append(fam(name,n,[1,ratio],[v,u],A,Cset,stage='stage3',tag='competing trajectories'))
    return R

def main():
    start=time.monotonic(); models=manifest(); outputs=[]; max_leaves=20000
    localdeps=[HERE/'task_contract.md',HERE/'numerical_design.md',HERE/'mass_energy_audit.md']
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in localdeps}
    hashes.update({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (SOURCE,DEP,LOGDEP)})
    for row in models:
        if row['tag']=='invalid_input':
            try:normalize(row)
            except AssertionError:pass
            else:raise AssertionError('invalid deletion was not rejected by validator')
            outputs.append(dict(name=row['name'],stage=row['stage'],status='rejected_input',reason=row['invalid_reason'],integrated=False));continue
        clocks=row_clocks(row); n=clocks['n']
        outrow=dict(name=row['name'],stage=row['stage'],tag=row['tag'],n=n,nu=list(map(fs,row['nu'])),C=[[fs(x) for x in z] for z in row['C']],A=list(map(fs,row['A'])),
            Cset=row['Cset'],B=[i for i in range(len(row['nu'])) if i not in row['Cset']],g=fs(row['g']),deletion_groups=[dict(time=fs(t),sources=ids) for t,ids in row['deletion_groups']],
            support=dict(initial=row['active_initial'],terminal=row['active_terminal']),breakpoints=list(map(fs,clocks['cuts'])),
            e_ell=fs(clocks['eell']),e_g=fs(clocks['eg']),c_g=fs(clocks['cg']),wg={str(k):fs(v) for k,v in clocks['wg'].items()},
            exp_Gamma_initial={str(k):fs(v) for k,v in clocks['egamma'].items()},exp_Gamma_C={str(k):fs(v) for k,v in clocks['egammaC'].items()},
            lambda_exact=fs(clocks['lam']),lambda_lt_1=clocks['lam']<1,lambda_static_identity_applicable=clocks['static_applicable'],
            lambda_static_rhs=None if clocks['static_rhs'] is None else fs(clocks['static_rhs']),lambda_segment_terms=clocks['lam_terms'],
            B_mass_exact=None if clocks['bmass'] is None else fs(clocks['bmass']),B_Gamma_exact=fs(clocks['bgamma']),
            posterior_gate=posterior_gate(row,clocks))
        if row.get('C_source_original') is not None:
            outrow['C_source_original']=row['C_source_original'];outrow['C_clip_applied']=row['C_clip_applied']
        if row['tag'] in ('constant_score_blocker','constant_score_blocker_deletion','exact FTC/log calibration'):
            exact=blocker_exact(row,clocks)
            outrow.update({k:v for k,v in exact.items() if k not in ('I','EJ','Cb','C0','Ewhole')})
            outrow['integrals']={k:dict(interval=v,method='exact two-source FTC / directed certified log',resolved=True) for k,v in {z:exact[z] for z in ('I','EJ','Cb','C0','Ewhole')}.items()}
            # Validate candidate identity exactly when lambda applies.
            if clocks['bmass'] is not None and row['deletions']==[]:
                ivalue=F(exact['I_exact']);assert clocks['bmass']==ivalue
                outrow['B_mass_equals_I_exact']=True
            else:outrow['B_mass_equals_I_exact']=None
        elif row['tag'] in ('equal_score_permutation','equal_score_common_soft'):
            outrow['integrals']={'I':dict(interval=I(0).out(),method='exact equal-score cancellation',resolved=True),
                'EJ':dict(interval=I(0).out(),method='exact equal-score cancellation',resolved=True),
                'Cb':dict(interval=I(0).out(),method='exact equal-score cancellation',resolved=True),
                'Ewhole':dict(interval=I(0).out(),method='exact equal-score cancellation',resolved=True)}
            outrow['integrals']['C0']=equal_score_C0(row,clocks)
            outrow['pairwise_I']={}
        else:
            specs,pairs=segment_specs(row,clocks); integrals={}
            for key in ('I','EJ','Cb','C0','Ewhole'):
                if len(row['nu'])==2 and key in ('I','EJ','Cb'):
                    continue  # Replaced below by exact segmentwise posterior FTC.
                # I has an n-scaled absolute target; positive companions use a relative target with a tiny explicit floor.
                coarse=initial_enclosure(specs[key]);lo,hi=coarse.lo,coarse.hi
                midabs=abs((lo+hi)/2)
                tol=(F(max(1,n),10**6) if key=='I' else F(max(Decimal('1e-80'),midabs*Decimal('1e-4'))))
                integrals[key]=integrate_function(specs[key],row,clocks,tol,max_leaves) if specs[key] else dict(interval=I(0).out(),width='0',leaf_count=0,resolved=True,target=fs(tol),max_leaves=max_leaves,method='exact zero coefficients')
                integrals[key]['method']='rational midpoint with directed second-derivative remainder'
            outrow['integrals']=integrals
            # Pairwise oriented positive traffic is retained for all <=3 source crossing models.
            if len(row['nu'])<=3:
                pi={}
                for key,ps in pairs.items():
                    pi[key]=integrate_function(ps,row,clocks,F(max(1,n),10**6),max_leaves)
                outrow['pairwise_I']=pi
        if len(row['nu'])==2:
            exact_pairs,pieces=exact_two_source_pairs(row,clocks)
            outrow['two_source_FTC_segments']=pieces
            outrow['two_source_exact_values']={key:fs(value) for key,value in exact_pairs.items()}
            oriented={}
            for piece in pieces:
                key=str(piece['higher'])+','+str(piece['lower'])
                oriented[key]=oriented.get(key,F(0))+F(piece['values']['I'])
            outrow['pairwise_I']={key:dict(exact=fs(value),interval=I(value).out(),resolved=True,method='exact rational segmentwise two-source FTC') for key,value in oriented.items()}
            outrow['exact_product_check']=exact_pairs['I']**2==exact_pairs['EJ']*exact_pairs['Cb']
            outrow['exact_Cauchy_check']=exact_pairs['I']**2<=exact_pairs['EJ']*exact_pairs['Cb']
            for key,value in exact_pairs.items():
                outrow['integrals'][key]=dict(interval=I(value).out(),method='exact rational segmentwise two-source posterior FTC',resolved=True)
        ints=outrow['integrals']
        try:
            Iiv=I(Decimal(ints['I']['interval'][0]),Decimal(ints['I']['interval'][1]))
            EJiv=I(Decimal(ints['EJ']['interval'][0]),Decimal(ints['EJ']['interval'][1]))
            Cbiv=I(Decimal(ints['Cb']['interval'][0]),Decimal(ints['Cb']['interval'][1]))
            C0iv=I(Decimal(ints['C0']['interval'][0]),Decimal(ints['C0']['interval'][1]))
            I2margin=EJiv*Cbiv-Iiv**2;cbmargin=C0iv-Cbiv
            def decision(z):return 'pass' if z.lo>=0 else ('fail' if z.hi<0 else 'ambiguous')
            i2_decision=('pass_exact_identity' if outrow.get('exact_product_check') else 'pass_exact_rational') if outrow.get('exact_Cauchy_check') else decision(I2margin)
            cap=(clocks['n']*clocks['eell'])
            ew=I(Decimal(ints['Ewhole']['interval'][0]),Decimal(ints['Ewhole']['interval'][1]))
            cap_dec='pass' if ew.hi<=I(cap).lo else ('fail' if ew.lo>I(cap).hi else 'ambiguous')
            massdec=None
            if clocks['bmass'] is not None:
                if 'two_source_exact_values' in outrow:
                    exact_I=F(outrow['two_source_exact_values']['I'])
                    massdec='pass_exact_identity' if exact_I==clocks['bmass'] else ('pass_exact_rational' if exact_I<clocks['bmass'] else 'fail_exact_rational')
                else:
                    massdec='pass' if Iiv.hi<=I(clocks['bmass']).lo else ('fail' if Iiv.lo>I(clocks['bmass']).hi else 'ambiguous')
            outrow['checks']=dict(I2_le_EJ_Cb=i2_decision,I2_margin=I2margin.out(),
                Cb_le_C0=decision(cbmargin),Cb_C0_margin=cbmargin.out(),
                I_le_Bmass=massdec,Ewhole_le_n_eell=cap_dec,Ewhole_cap=fs(cap),
                I_interval_nonnegative=Iiv.lo>=0,
                all_primary_integrals_resolved=all(ints[k]['resolved'] for k in ('I','EJ','Cb','C0','Ewhole')))
        except Exception as exc:outrow['checks']={'status':'not_comparable','reason':str(exc)}
        # Per-case inherited fixed-initial comparison and exact mass-scaling invariance.
        outrow['R172_comparison']='B_Gamma_exact uses fixed initial support; deleted B remains in Gamma, not in e_g.'
        outputs.append(outrow)
    # Independently check common mass rescaling on a small exact calibration model.
    first=next(r for r in models if r['name']=='blocker_n2_eps_1'); scaled=dict(first);scaled['nu']=[3*x for x in first['nu']]
    c1=row_clocks(first);c2=row_clocks(scaled)
    z1=blocker_exact(first,c1);z2=blocker_exact(scaled,c2)
    scale_check=dict(lambda_unchanged=c1['lam']==c2['lam'],Bmass_unchanged=c1['bmass']==c2['bmass'],
        I_unchanged=z1['I_exact']==z2['I_exact'],EJ_unchanged=z1['EJ']==z2['EJ'],Cb_unchanged=z1['Cb']==z2['Cb'],
        C0_unchanged=z1['C0']==z2['C0'],Ewhole_scales_by3=scaled['nu'][1]==3*first['nu'][1] and scaled['nu'][1]/scaled['nu'][0]==first['nu'][1]/first['nu'][0],
        eg_scaled=c2['eg']==3*c1['eg'],eell_scaled=c2['eell']==3*c1['eell'])
    result=dict(title='R173 mass-sensitive clock and squared-score finite check',scope='Finite exact product-threshold algebra only; no physical kernel, history, FIRST, receiver integral, or FULL claim.',
        arithmetic=dict(coefficients='exact Fraction',integration='frozen R166 outward-directed Decimal interval runtime; rational midpoint quadrature plus interval f-second-derivative remainder',precision_digits=iv.PREC,interval_runtime=str(DEP),
            max_adaptive_leaves=max_leaves,runtime_policy='deterministic fixed leaf budget; runtime recorded, no wall-clock abort'),dependencies=hashes,case_count=len(outputs),cases=outputs,
        mass_rescaling_check=scale_check,summary=dict(rejected=sum(x['status']=='rejected_input' for x in outputs if 'status' in x),
            exact_calibrations=sum('exact' in x.get('tag','') or 'blocker' in x.get('tag','') for x in outputs),
            unresolved_integrals=sum(1 for x in outputs for z in x.get('integrals',{}).values() if not z.get('resolved',False))),
        limitations=['Only curated finite rational models are tested.','No physical C/good/rho, normalized J, common-input FIRST, carrier/history, or FULL coverage is modeled.','A finite candidate-bound pass is not a theorem; unresolved integrations remain interval enclosures at their leaf budget.'],
        runtime=dict(python=sys.version,platform=platform.platform(),seconds=round(time.monotonic()-start,3)))
    target=HERE/'mass_clock_check.json';target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(output=str(target),case_count=len(outputs),elapsed=result['runtime']['seconds'],
        unresolved=result['summary']['unresolved_integrals'],scale_check=scale_check,
        case_summary=[dict(name=x['name'],lambda_lt_1=x.get('lambda_lt_1'),Bmass=x.get('B_mass_exact'),I=x.get('integrals',{}).get('I',{}).get('interval')) for x in outputs[:8]]),indent=2))

if __name__=='__main__': main()

