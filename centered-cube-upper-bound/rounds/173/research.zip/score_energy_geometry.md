# R173：平方 score 能量、原归一化及未吸收阈值项

## 1. 筛查结果与本稿范围

目标是原相关来源的平方 score 差能量，不能假定 VarΠ(k)=O(n)，也不能把未归一能量帽当成原双Π帽。本稿独立推导其精确流，区分连续软权衰减、物理阈值穿越与真实删除；随后给 actual J 能量的双向配套及 same-α 截断系数包络。

结论范围：有一个准确的维数线性未归一能量预算，删除对该能量势始终有利；其转为原归一双来源平方能量时仍有具体未付款项。父级独审已经另证 actual J 单槽全局帽，本稿引用其准确接口而不重复证明，不将它包装为已付的原 raw。主代理/Astra负责尚未支付的 Cauchy系数列。本稿不扩展该主线、不声称一般根阶闭合或 FULL/L1 正覆盖。

固定原完整行、原区间 I=(t0,t1)，令 σ=logt，所有端点按原一侧约定；Θ与删除求和只计I内事件，端点事件由原端点账单列。原

\[
\mu_t=1_{Z_t}w_t\nu,\quad e_t=\mu_t1\ge e_g>0,
\quad\Pi_t=\mu_t/e_t,\quad
k_t(v)=\#\{i:C_i(v)<c_jt/b\}\in\{0,\ldots,n\}.
\tag{E1}
\]

Zt递减且包含终端 Zg；原冻结 A(v)=1good ρvχJv 支持于Zg，0≤A≤1，包含同一个原 α。score与source都不独立；全部实际dx、共同future/FIRST、history、high与唯一j保留。原 w_t绝对连续，a.e.有 −∂σwt=ktwt，阈值处wt连续。

(E2)–(E17)的支持变化范围明确限于原R117 JG1的有限树/有限禁块共同截断：Zt在删除事件之间恒定，仅有有限个真实删除原子。本文没有声称任意nested支持的连续删除已被删除求和包含；推广为一般BV删除须另列Dr的连续损失和V/covariance强迫，本稿不作该推广。先在此原截断上证明所有signed恒等式。ν可以一般相关、连续或原子；这只影响物理来源阈值Θ的总体BV分布，不能把连续ν阈值强迫缩成有限节点表，也不能与连续支持删除混淆。

## 2. 原未归一矩的完整测度恒等式

置

\[
M_r(t)=\int_{Z_t}w_t k_t^r d\nu\quad(r\ge1),\qquad M_0=e_t.
\]

以 Θr 记录**活着时**的原阈值穿越：每个源的每个 k跳把 w_t d(k_t^r)ν 加到 Θr。若同一源一次跨 j个坐标，它贡献 (k+j)^r−k^r，而不是只加 j。以 Dr 记录真实删除集合 H_t 的 ∫Ht wt k_t^rν；若删除与阈值同刻，以“原删除前支持先更新score、再删除”作纯代数中间态。这样从原左右态到原左右态精确，阈值权wt不变，并未重选实际支持。Θ0=0。

同刻事件统一约定：先以原删除前支持 Zt−作阈值更新，再删除。阈值积分使用该未删除支持的 eθ=∫Zt−wtν=e_before 与 Πθ、Fθ；score均值在(E9)的 mθ,−明确取阈值更新前score，阈值后/删除前均值另用于删除的 before 态。阈值更新不改变w、e、Π或F；它们都不能改用原右连续et的删除后值。非同刻/非原子阈值处这些记号等于当时原量。以下Θ积分均沿此约定，删除损失则从阈值已更新的中间态计算。

精确矩流为

\[
dM_r=-M_{r+1}d\sigma+d\Theta_r-dD_r\quad(r\ge1),
\qquad de=-M_1d\sigma-dD_0.
\tag{E2}
\]

特别地

\[
\int M_1d\sigma=e_0-e_1-D_0(I),
\]
\[
\int M_2d\sigma=M_1(t0+)-M_1(t1-)+\Theta_1(I)-D_1(I).
\tag{E3}
\]

每源初始score加以后所有阈值增量至多n，权又不增加，故

\[
\Theta_1(I)\le n e_0-M_1(t0+),\qquad
\Theta_2(I)\le n^2e_0-M_2(t0+).
\tag{E4}
\]

真实删除之后的阈值不再计入。更直接且更强的非负能量帽来自 k²≤nk：

\[
\boxed{\int M_2d\sigma\le n[e_0-e_1-D_0(I)]\le ne_0.}
\tag{E5}
\]

这不需方差或坐标概率模型，也没有删除次数、阈值次数、log2或新来源归一化费用。它本身是未归一原质量预算。

## 3. e Var 的准确耗散、阈值与删除

令 m=M1/e，V=e VarΠ(k)=M2−M1²/e。无阈值/删除强迫的连续部分满足

\[
\boxed{V'=-\int k(k-m)^2d\mu\le0.}
\tag{E6}
\]

证明只用e′=−M1、M1′=−M2、M2′=−M3。相对地，归一方差的连续导数为

\[
(\operatorname{Var}_{\Pi}k)'=-\Pi[(k-m)^3],
\tag{E7}
\]

符号不定，不能从(E6)推出原双Π的方差单调。

### 3.1 物理阈值强迫

纯阈值时 e和μ不变。记 j(v)=k+(v)−k−(v)≥0，以前态m计算，则

\[
\Delta V=2\int(k_--m_-)j\,d\mu+\int j^2d\mu
-\frac{(\int j\,d\mu)^2}{e}.
\tag{E8}
\]

它可以为正或负；同时跨多坐标的j²不可丢，亦不能假设各坐标Bernoulli独立来把它减成j。

在Θ的非原子部分，V的阈值强迫为 dΘ2−2m dΘ1；在阈值原子还须减 (ΔΘ1)²/e。因而原有限截断的完整式可写为

\[
\begin{split}
V_1-V_0={}&-\int\!\int k(k-m)^2d\mu\,d\sigma
+\int(d\Theta_2-2m_{\theta,-}d\Theta_1)\\
&-\sum_{\rm threshold}\frac{(\Delta\Theta_1)^2}{e_\theta}
-\sum_{\rm deletion}\mathcal L_{del}.
\end{split}
\tag{E9}
\]

Θ已按(E2)约定处理同刻事件。一般ν的连续阈值分布完整保留在Stieltjes积分中；仅列阈值原子求和是不完整的。

### 3.2 真实删除始终降低未归一方差势

若删除H的质量为d，剩余质量e，删除前为e+d，剩余/删除块各自均值为mR、mH，块内未归一方差为VR、VH，则准确分解

\[
V_{before}=V_R+V_H+\frac{ed}{e+d}(m_R-m_H)^2.
\tag{E10}
\]

故(E9)中 Ldel=VH+ed/(e+d)(mR−mH)²≥0。d=0时取0；剩余e≥eg>0，无0/0。这个有利方向与被删除块均值大小无关。它只对**未归一V**成立；删除对m、归一方差及后文filtered covariance可有任意符号。

### 3.3 真正的维数线性平方差预算及其精确缺口

因为

\[
\frac1{2e_t}\iint(k_v-k_u)^2d\mu_t(v)d\mu_t(u)=V_t,
\]

(E5)给

\[
\boxed{\int V_td\sigma
\le n[e_0-e_1-D_0(I)]-\int\frac{M_1^2}{e}d\sigma
\le ne_0.}
\tag{E11}
\]

这是完整原权重下的维数线性平方能量，不依赖(E9)的阈值符号。然而原归一双Π需要

\[
\int\iint(k_v-k_u)^2d\Pi_t^2d\sigma
=2\int\frac{V_t}{e_t}d\sigma.
\tag{E12}
\]

(E11)只立刻给≤2ne0/eg，额外的 e0/eg 不能免费取消，也不能把e0换成Jν。另一个准确展开来自m的矩流：

\[
\int\operatorname{Var}_{\Pi_t}k\,d\sigma
=m_0-m_1+\int\frac{d\Theta_1}{e_\theta}
+\sum_{del}(m_{after}-m_{before}).
\tag{E13}
\]

阈值时m增量为ΔΘ1/eθ，连续阈值亦按测度计入；同刻删除的before均值为阈值已更新、尚未删除的中间态。删除均值跳是具体额外项，不能因(E10)有利而删去。阈值总质量的(E4)经过1/e后会再次产生e0/eg损失。这些都是原量而非新命名的已付残差。

## 4. 带原 A 的归一平方能量与具体未付款项

为保留原receiver滤波，置

\[
F=\Pi A,\quad C_A=\operatorname{Cov}_{\Pi}(A,k),\quad
V_A=\Pi[A(k-m)^2],\quad
\mathscr E_A=\iint A(v)(k_v-k_u)^2d\Pi^2.
\]

这里CA是covariance，不是下文Cauchy全局系数。精确有

\[
\mathscr E_A=V_A+F\operatorname{Var}_{\Pi}k,
\quad C_A'=F\operatorname{Var}_{\Pi}k-V_A
\tag{E14}
\]

（第二式指无阈值/删除的连续流）。纯阈值j给

\[
\Delta C_A=\operatorname{Cov}_{\Pi_\theta}(A,j),
\tag{E15}
\]

因为A、eθ、Fθ在阈值更新瞬间不变，尚未执行同刻删除。非原子阈值强迫准确为

\[
d\mathcal Q_A=\frac{d\Theta_{A,1}-F_\theta\,d\Theta_1}{e_\theta},
\qquad d\Theta_{A,1}=\int_{alive}Aw\,dk\,d\nu.
\]

在阈值原子，这一表达也恰等于(E15)。删除H时A在H上为0，但CA仍可上跳或下跳。沿(E10)的剩余态记FR、CR，则

\[
\Delta_{del}C_A=
\frac d{e+d}C_R-
\frac{ed}{(e+d)^2}F_R(m_R-m_H).
\tag{E16}
\]

因而原完整归一filtered平方能量为

\[
\boxed{\int\mathscr E_A d\sigma
=2\int F\operatorname{Var}_{\Pi}k\,d\sigma
+C_A(t0+)-C_A(t1-)
+\mathcal Q_A(I)+\sum_{del}\Delta C_A.}
\tag{E17}
\]

这是同一原A、Π、et与same-α下的精确恒等式。尚未吸收的项清楚是：F加权归一方差、实际阈值covariance流、实际删除covariance跳和两个端点。各项一般无确定好符号；原Rrev也不能被平方化后再次领用。本文没有证明其actual dx外积分的一致根阶价格。

仅给A加权初末质量比门并不构成新能量进展。事实上，令a0=∫Awt0ν、a1=∫Awt1ν，由δ+≤kv及A支持Zg，已有更强一阶界

\[
\int\iint A(v)\delta_+d\Pi^2d\sigma
\le\frac{a_0-a_1}{e_g}.
\tag{E18}
\]

因此“a0/ag有界再CS给√n”比直接一阶付款更弱；本稿明确不将其当新根阶分支。

## 5. 对齐已审 actual J 平方槽，双向范围与 same-α 系数包络

父级独审 `mass_energy_audit.md` 的已证接口是原实际测度（去原hard帽一次后）

\[
\mathcal E_J=
\mathbb E\sum_{V,j}\int1_{\{j(x)=j\}}dx\int_{high}d\beta_V(y)
\int_{actual}\!\iint J_b(x-v)\delta_+(v,u)^2d\Pi_t^2\frac{dt}t
\le\frac n{2K}W_\beta.
\tag{E19}
\]

它保持原high与共同FIRST，最后使用固定b的J空间积分及唯一j，不是将adaptive Q当概率核。本稿不重复该单槽证明。特别地，(E19)不证明Jv(kv−ku)²全双向能量，因为Jv ku²交叉槽未付。

合法的双向配套只有如下方向对称版本：设 D=kv−ku，

\[
\mathcal W(v,u)=J_vD_+^2+J_uD_-^2.
\]

同一原Π²内完整交换两个积分哑变量使第二项等于第一项，因此该实际全局能量≤nWβ/K。又 min(Jv,Ju)D²≤W，故其能量同价。这不把外y与source交换，不变α/来源，也不证明JvD²已付；Cauchy逆槽换成minJ通常更差，不能据此声称新付款。可保留的另一向量平方为(√Jv kv−√Ju ku)²≤Jvkv²+Juku²；若用它替回√JvD，必须另留 (√Ju−√Jv)ku核差项，本文不支付该项。

对原正交通作Cauchy后，真正仍需结算的是父级/Astra负责的系数

\[
\mathcal C_J=\mathbb E\sum_{V,j}\int dx1_{\{j(x)=j\}}
\int_{high}\!d\beta_V(y)\int_{actual}\!\int
\frac{p_y^2A(v)^2}{J_v}\,d\Pi_t(v)\frac{dt}t.
\tag{E20}
\]

原post-hard正项≤√(EJ CJ)；hard16/3与外2Λ只恢复一次。没有证明CJ≤n^o(1)Wβ，不能只凭(E19)宣称根阶。

这里可独立提供一个准确的same-α平方截断包络。在TΔ>0处设

\[
d=\left[1-\frac{DK_0}{T\Delta}\right]_+,\quad
b_\alpha=\frac{\alpha J}{T\Delta}.
\]

则ρ=(d−bα)+，且对α>0，

\[
b_\alpha(d-b_\alpha)_+^2\le\frac4{27}d^3
\quad\Longrightarrow\quad
J\rho^2\le\frac{4T\Delta}{27\alpha}d^3.
\tag{E21}
\]

证明是对0≤bα≤d的三次式微分，最大在bα=d/3；超过d时为0。于是实际Cauchy系数满足

\[
\boxed{\frac{p^2A^2}{J}
\le1_{good}\frac{p^2}{9Q^2}
\min\left\{Jd^2,\frac{4T\Delta}{27\alpha}d^3\right\}.}
\tag{E22}
\]

α=0时仅保留第一项Jd²，绝不取1/α；Δ≤0为原零正交通。该上界只改变原系数的可用估计，没有重选ρ或α。三次capture-gap保留K0补偿，等号标量极值不代表原good/FIRST等门可共同重实现。尚未付款的量依然是adaptive Q、微小α以及同一物理Π/et的真实列积分。不得以(E22)把这些未证积分换名为已付能量。

## 6. 本轮有界结论

已完成的独立内容是原V=eVar的连续耗散、物理阈值BV强迫、删除方差分解、准确维数线性能量和原归一损失；保留终端A后得到(E17)的每一个具体未吸收项。actual J单槽价格引用另行独审接口；本稿只给合法双向范围及(E21)–(E22)的same-α平方包络。

没有新的全局原source/receiver付款分支被本稿证明。特别是初末平均比门被一阶恒等式严格压过，已撤回为进展候选；未以静态variance假设、独立坐标、移动支持免费clock或重复suffix负账补这个缺口。一般根阶上界、剩余CJ与真实FULL/history覆盖继续开放。

候选在长证明前已送独审；最终审计绑定由父级负责。只写本责任稿，无Git、spawn、PDF或新扫描；交付后停止，不与父级/Astra的质量clock、熵/秩和系数列路线重复。
