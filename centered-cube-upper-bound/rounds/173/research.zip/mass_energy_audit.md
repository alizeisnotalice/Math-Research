# R173 独立质量—平方能量审计

责任范围仅本文件；无 Git、无额外代理、不改他人文件。以下作者前检查点先只读 R173 task_contract，复用已亲核 R170–R172 原合同；未读本轮作者稿。一般上界未闭合。

## 1. 固定原归一化与质量敏感的准确量

固定完整原行，mu_t=1_Zt wt nu，e_t=mu_t(total)，Pi_t=mu_t/e_t。原 high 上 e_t≥e_g>0、p_y e_g≥2Kq；beta、nu不归一，M_x=p_y beta/q只为子概率。原 A=1_good rho chiJ在辅助时间冻结，支撑于Zg，且p_y A_v wg≤KJ_v/3。实际正差方向为delta_plus=(k_v−k_u)_+，J附在v这个好源槽。

对固定v，原未门控正差均值有准确CDF表示

    L_t(v)=integral(k_v−k_u)_+Pi_t(du)
          =sum_(a=0)^(k_v−1) Pi_t{k_u≤a}.

带原bad/Psi门时，右端每项改为同一原bad来源上的Psi加权低score质量；不能把这些源换成独立分布。于是

    L_t(v)≤k_v Pi_t{k_u<k_v}≤k_v,
    L_t(v)^2≤integral(delta_plus)^2Pi_t(du).

这说明tiny低score质量应以真实后验前缀质量进入，不能只用essinf定义它的影响，也不能把bad总质量当成所有相关低score层的质量。任何新prefix/质量门仍须在原y,v,t上共同积分，不能逐y领新q。

令bar k_t=Pi_t k，V_t=Var_Pi(k)。另有

    L_t(v)=1/2[k_v−bar k_t+integral|k_v−k_u|Pi_t(du)],
    integral(k_v−k_u)^2Pi_t(du)=(k_v−bar k_t)^2+V_t.

因此用均值替换essinf后，单靠k_v−bar k不能上界正差；反向绝对偏差/方差是精确剩余项。总体无权delta均值≤sqrt(V_t/2)，但这尚不是原带A与实际外测度的付款。

## 2. 可真正全局支付的未归一平方score能量

对固定y,v、固定b，先完全不归一wt。原连续clipped乘积满足

    −dwt/dlogt=k_t(v)wt(v) a.e.,    0≤k_t(v)≤n.

所以任意有限原连续clock段[t0,t1]上

    integral k_t(v)^2 wt(y,v)dt/t
      ≤n integral k_t(v)wt(y,v)dt/t
      =n[wt0(y,v)−wt1(y,v)]≤n.

这里仅微分连续wt，不微分k；阈值面有任意source质量仍不产生额外原子。该界允许任意相关nu，不使用独立坐标概率；wt的乘积定义只用于准确导数。实际区间上加Zt、history或其他[0,1]正门只会减小此未归一积分，删除次数也不收费。

换元xi=c_jt/b后dt/t=dxi/xi，全部原合法clock在xi∈[1/2,1]。上式因此给一个对x,y,v,j、原s/L及所有删除模式一致的未归一时间包络≤n。

### 2.1 high/FIRST与固定J的真实dx结算

定义原eligible时间内的单后验能量

    E_J=E sum_(V,j) integral_dx 1_{j(x)=j}
        integral_high beta_V(dy)
        integral_actual dt/t integral J_b(x−v) k_t(y,v)^2Pi_y,t(dv).

先在**原eligible时间**用1/e_t≤1/e_g，再正上放Zt和其他门，才把未归一时间积分扩大到完整xi∈[1/2,1]。这样得到

    E_J≤n E sum_(V,j) integral_dx 1_j Jnu_V(x)
                                      integral_high beta_V(dy)/e_g(y).

high与同一当前FIRST给

    integral_high beta_V/e_g≤(2Kq)^−1 integral p_y beta_V≤1/(2K).

故保留unique j到一致行价后合并，再用固定b的真实J空间归一化，

    E_J≤n/(2K) E sum_V||nu_V||≤n/(2K)W_beta.

这没有给每叶额外q；每V留下Jnu_V再合并原来源总质量。无需soft/scale菜单，因为当前核测试与固定J就是原合同对象；也不免费跨额外a,b窗口。

重要顺序：不能先把**归一**Pi时间延伸到原e_t≥e_g资格之外；允许延伸的是去掉该分母之后的未归一正权wt积分。此处全beta保持原值，未用无权列界去直接测试依y的k。实际y依赖先由同一个未归一时间包络处理，之后才使用high/FIRST。

### 2.2 原正差平方能量可用同价

原score非负且原正差方向为v减u，故

    (delta_plus(v,u))^2≤k_t(v)^2.

第二份原Pi总质量为1，于是

    E sum_(V,j) integral_dx 1_j integral_high beta
      integral_actual dt/t integral integral
                J_b(x−v)(delta_plus)^2 Pi_t(dv)Pi_t(du)
      ≤n/(2K)W_beta.

原bad/Psi/FA/rho等[0,1]门可正保留或上放；没有把原u或其支持换掉。此式是目前可独立认证的全局平方能量价，不是对原pA正交通的直接结论。

若该平方能量本身再携原hard carrier，则只能使用一次16/3；再连外2Lambda会成为16Lambda n/(3K)W_beta。把它用于Cauchy拆分时则应在同一原carrier上共同处理，不能给两个因子各领一次硬帽。

## 3. 不能把上述能量免费换成原raw

一次原hard16/3之后，待付正J-share是(32Lambda/3)乘

    P=E sum_(V,j) integral 1_j dx integral_high beta(dy)
                       integral_actual dt/t p_y integral A_v delta_plus Pi_t².

在原同一正积分测度上Cauchy可给

    P≤sqrt(E_pair,J * C_J),
    C_J=E sum_(V,j) integral 1_j dx integral_high beta(dy)
          integral_actual dt/t integral [p_y^2 A_y(v)^2/J_b(x−v)]Pi_t(dv).

第二份Pi在上放原pair门后总质量1，故这里准确剩一份Pi。J严格正，商有定义；C_J是实际非负可能无限的系数积分，尚未受控，不是新的已付范数。若要由已证E_pair,J≤nW_beta/(2K)取得root来源价，还必须给C_J=O(polylog(n)^2 W_beta)之类的真实预算或其他可核配对；不能只展示平方能量已付就结束。

同一个困难在直接good放松中表现为

    p_y integral A_v(delta_plus)^2Pi_t²
      ≤ K/(3e_t) integral_active J_v k_v^2 [wt(y,v)/wg(y,v)]nu(dv).

可支付能量含wt，而这里含wt/wg，额外1/wg没有消失。无权high列、J概率性或Q的FIRST总容量都不允许直接删除它。Q是receiver自适应混合，不能作对x的概率核。

若把delta_plus平方改成整个(k_v−k_u)^2，还新增另一端项

    integral integral J_v k_u^2 Pi_t(dv)Pi_t(du).

它的J挂在v而score在u；不能通过交换哑变量后无费变成J_u k_u²，因为原A/good/rho/alpha/qualification也挂在原v槽。已证单槽能量不直接覆盖它。用Var或对称平方时必须保留这笔准确交叉槽费用，不能假设坐标独立或来源可逆。

## 4. 归一化均值/方差流还必须计面项和删除

在无删除、避开阈值面的连续段，归一化posterior导数给

    dPi_t(v)/dlogt=−(k_t(v)−bar k_t)Pi_t(v).

但对bar k求导会遇到k的阈值面。完整测度意义为

    d bar k=dFace−V_t dlogt+dDeletion.

Face含原各坐标C_i=xi交叉处、同一原wt/e_t的阈值质量。删除H时

    Delta bar k=(d_t/e_after)(bar k_before−mean_k_on_deleted_mass).

此跳可正可负；不能把它当成A支持存活时那种一律非负F上跳。对V积分若要由端点score≤n收费，必须额外控制这些真实Face和删除项；微分k后忽略它们是不成立的。第2节的未归一k²wt包络避免了微分k及这些归一化面费用，但它也不能免费替代含1/wg的原能量。

所有signed差仍先在原有限截断成立，不借infinity−infinity。原negative信用、同alpha储备、已消费suffix与R172的正来源分区保持原账，不因质量/能量新表示再分配一次。

## 5. 作者后审计划与停止点

待父级给准确候选/指定成稿后，只核以下明确义务：

- 均值或质量权是否使用同一原nu、et、Pi及完整低score前缀，是否确实改善tiny-mass的essinf过付；
- 平方能量是哪一个源槽、是否未归一、是否保留原J位置及正确delta方向；
- 是否解释1/wg或C_J等实际系数，而非把它改名成能量预算；
- 原初始、阈值面、删除、时间资格及共同future测试是否逐项保持；
- 原真实dx、unique j、固定b、hard一次、outer2Lambda、来源/窗口/history全部费用是否显示；
- 有限有理/数值仅作有限证据，FULL新覆盖与一般上界分别核实。

作者前独立检查点完成。此时仅认证第2节显示的全局平方能量及本节精确剩余项；不认证原正交通已整体支付。未读本轮作者证明，停止等待准确命题。


## 6. Astra 准确质量敏感命题的作者前独审

先按父级给出的准确命题独立推导，尚未读 mass_sensitive_geometry.md。固定同一全初始支持 S=C disjoint_union B，C为正nu质量的固定可测集合；只估计原正项的A1_C来源槽。r(t)=essinf_C k_t、c(t)=exp(−integral_ell^t r)，r对原完整行冻结定义，不能随当前删除支持改选。

记

    V_t(v)=wt(v)/c_t,       E_t=e_t/c_t,
    g_B(t)=integral_B (r(t)−k_t(u))_+ V_t(u)nu(du),
    L_B=integral_ell^g g_B(t)dt/t,
    lambda=L_B/E_g=(c_g/e_g)L_B.

这里B是**全初始**B，包含所有后来删除的来源。r与共同null集的可测性可按R172有限整数阈值及Tonelli恢复；nu(C)=0时该C槽本身为0，直接跳过相关essinf定义。

连续时间原质量满足 `E'_t≤g_B(t)`，所有真实删除使E向下跳。因此对任意t≤g，

    E_t≥D_t:=E_g−integral_t^g g_B(r)dr/r.

lambda<1时D_t≥(1−lambda)E_g>0，且D'_t=g_B(t)。对终端活跃v∈C，令a_t(v)=k_t(v)−r(t)≥0，原正差均值满足

    integral(delta_plus(v,u))Pi_t(du)
      ≤a_t(v)+g_B(t)/E_t.

于是

    [V_t(v)/E_t] integral delta_plus Pi_t(du)
      ≤[V_t(v)/D_t][a_t(v)+g_B(t)/D_t]
      =−d[V_t(v)/D_t]/dlogt.

这是必须联合使用的分母和质量forcing。若分别把两个分母都上放成(1−lambda)E_g再积分，会错误地多付一个(1−lambda)^−1；准确FTC仅给一次倒数。

原v∈Zg全窗存活、A冻结，积分即得

    I[A1_C]≤1/e_g integral_C A_v wg(v)
                  [exp(Gamma_C(v))/(1−lambda)−1]nu(dv),
    Gamma_C(v)=integral_ell^g[k_t(v)−r(t)]dt/t.

包含任意原删除时刻与正时间门；未更改原Pi、rho、alpha、Delta或history。只使用原正项，负信用完全未取。C外的活跃A1_B槽不因此支付，lambda≥1行也不能使用该正分母。

### 6.1 特殊低score B 的终端质量必须包含已删源

若全初始B在全窗几乎处处有k_t(u)≤r(t)，则V_t(u)非减，积分精确给

    lambda=1/e_g integral_B[wg(u)−c_g w_ell(u)]nu(du)
           ≤1/e_g integral_B wg(u)nu(du).

右端是整个初始B的terminal-weight质量，**不是**一般的实际Pi_g(B)。后来删除的B仍在该积分，只有B⊂Zg（没有B删除）时才等于终端后验质量。实际Pi_g(B)很小并不自动保证lambda<1。已把这个必要范围发给作者和父级。

### 6.2 原J与接收价的准确接口

定义有效损失 `Theta_C(v)=Gamma_C(v)−log(1−lambda)≥0`。则上述真实正来源积分具有R172同样的exp(Theta)−1形式。

对时间固定正来源槽Theta≤M，good/high及原真实外积分给

    RawPositive_Jshare≤(16Lambda/9)(exp(M)−1)W_beta.

对同一槽中 `S_v−Theta_C(v)≥h`，S_v=log(Kstar_v/J_v)、Kstar=P_s,b共同future，给

    RawPositive_Jshare≤(16Lambda/9)exp(−h) E integral_D qdx.

先用点态J expTheta≤exp(−h)Kstar，再drop来源门、high配对beta、sum_V Kstar nu_V≤q。不能逐y更换future；lambda的行依赖也不能略去它带来的−log(1−lambda)。

原无chiJ母正项同法在源Theta≤log(1+zeta)上给 `16Lambda zeta/3 E integral qdx`，不是W_beta价。两种J来源槽可不交分区；其余A1_B、lambda≥1、大Theta且低future放大补集原位保留。没有将新有效损失仅改名为已知受控量；lambda/Theta仍需由这些准确可测来源条件筛选。

## 7. 父级质量门Cauchy命题的作者前独审

令原完整Pi低score质量

    b_v(t)=Pi_t{k_t(u)<k_t(v)}.

逐v的Cauchy严格给

    [integral delta_plus(v,u)Pi_t(du)]^2
      ≤ b_v(t) integral(delta_plus)^2Pi_t(du).

所有原bad/Psi/FA正门≤1，可正保留或上放。因此第3节系数可以替换为精确的伴随

    C_b=integral [p_y² A_v²/J_v] b_v(t)Pi_t(dv)
                         dt/t high_beta(dy)dx  (原期望、V/j及uniquej同前).

若在任意可测的正时间/来源子支上

    rho_y(v)^2 b_v(t)≤L² wg(y,v)^2,

原good给

    [p_y² A_v²/J_v] b_v
      =1_good p_y² rho² b_v J_v/(9Q_v²)
      ≤K²L²J_v/9.

L必须统一或保留其平方在实际积分；不能在最终常数里隐藏行依赖。原完整high列对固定t、同一x的共同J测试给

    integral_high beta(dy) integral J_vPi_y,t(dv)≤Jnu/(2K).

对原eligible行作零延拓，换元到共同xi∈[1/2,1]后付log2；保持uniquej到一致行帽再合并、fixedJ真dx积分，故

    C_b,branch≤K L² log2/18 W_beta.

与已核平方能量nW_beta/(2K)共同Cauchy，posthard32Lambda/3严格给

    RawPositive_Jshare(branch)
      ≤(16Lambda/9)L sqrt(n log2)W_beta.

两个Cauchy因子没有各领硬帽，原16/3只在完整正交通上用一次。分支可以依t、v，因为这里是点态正积分Cauchy，不是需要冻结门的FTC；无需新增端点，也不切分任何signed信用。若改成源对u依赖门，应仍用完整b_v作正上界，不能无定义地将门后的量当作同一概率。

该条件支与R172/第6节的时间固定来源FTC分区要区分：可任意按t筛CS正项，不代表可任意按t重启mass-clock FTC。互补子支rho² b_v>L²wg²未付；不能断言这个显示门普遍成立。到此只认证这一准确来源/时间分解的价格。


## 8. mass_sensitive_geometry 成稿后审

先完成第6节独立筛查，再实读全稿。绑定当前冻结 SHA256：

    2bfd4807f05bb377f83031f7593b5b065dbbc87fd1bfd4f5fdeb696d3ee52b3e

MG1–MG12 在其明示量词与原合同下通过。关键核验如下。

- MG2直接用Zg⊂Zt，将Eg−Et上放为Zg上reduced-weight差，再用C非增和全初始B的正增长控制。这个证明不需要Zt只有删除原子，因此任意原nested支持的连续删除也不产生漏项。分区固定、B含后来删除源，正是避免移动支持clock免费增益的必要条件。
- MG3的正差质量forcing是G/E_t，而不是未归一G。MG4联合使用同一个D_t=E_g(1−lambda(t))，其导数G，得到一次(1−lambda)^−1的准确FTC。指数与分母随t都AC，k/r阈值跳不产生权重原子；nu任意相关或连续均可。
- nu(C)>0、r的本质极值与共同null集、lambda<1、time-fixed H和原good-slot方向均明确。C槽没有新选择原source；C/B的行依赖不改变原nu、et/Pi、rho、alpha或Delta。全部[0,1]原门只能正放松。
- MG6已明确full-initial B的terminal wg质量包含删除源，不误当Pi_g(B)。score-order物理充分条件Ci(B)≥esssup_C Ci的方向正确：B的每个soft坐标同时属于所有C来源的soft坐标，故k_B≤r。一般rscore条件仍允许坐标相关。
- MG8使用Theta=Gamma_C−log(1−lambda)，不是遗漏质量分母的Gamma_C。来源P/Q/R互斥固定于整条原行；lambda≥1和所有B槽明列未付。future Q槽在逐点J expTheta≤e^(−h)Kstar后才放松y/V来源门，随后同一个P_s,b对所有叶共同FIRST，符合原共同输入量词。
- MG10/11分别准确恢复16Lambda/9(exp(M)−1)W_beta和16Lambda/9 e^(−h)E integral qdx。唯一j、固定b真dx、原hard一次、outer2Lambda、原history与原窗口费均未省略。未声称跨独立窗口免费合并。
- MG12保留C intersect {A0>0}到源门应用后，给无chiJ母正项16Lambda zeta/3的qdx价。eta/(1−eta)≤3epsilon/(16Lambda)等价eta≤3epsilon/(16Lambda+3epsilon)，方向与显示常数正确；不把Q当空间概率核。

有界soft/hard校准只验证质量收费比全初始essinf更细：C全soft、B全hard时Gamma_C=0，而lambda=(1−(ell/g)^n)nu(B)/eg。它不认证FULL/high/FIRST联合可实现；B槽score0时正流确为0，不把这个特殊消失推广到一般B。

本稿是新质量敏感原正项比较与准确分解价格，未假定原交通矩已经有界。一般输入能否选到足够好的core partition、控制lambda/Gamma_C或支付未分配B和R_C，仍为明确缺口。没有把这些前提伪装成一般结论。

## 9. parent blocker_mass_energy 成稿后审

绑定 SHA256：

    95eb95dc95250a4b5c4109d7c5c2f6bd627e942fe3c488eb7e5b45180fa24205

E1–E4与本审计第2、7节独立证明一致，严格通过。

E1保留原正方向delta_plus≤k_v，先e_t≥eg再延伸**未归一**wt时间，使用∫k²wt≤n∫kwt≤n；原有限阈值面连续wt没有原子。这给实际J_vPi²的n/(2K)W_beta，而非完整无权方差或错误J_v k_u²槽。E2同理给log2/(2K)W_beta。

E3在同一完整原pair测度Cauchy，两个平方因子都保留1_{delta>0}；第二个u积分恰产生完整Pi的b_t(v)。fractional H可分sqrt(H)，没有额外source独立性。所有pair额外门仍≤1，去门只使能量与伴随变大。

E4点态gate用good将伴随上放为K²L²J/9，故伴随总价K L²log2 W_beta/18；与E1相乘开根后是L sqrt(nlog2)W_beta/6，原32Lambda/3只恢复一次，最终16Lambda L sqrt(nlog2)/9正确。更锐B门的系数16Lambda B/(3K)及B=KL/3代入也正确。

时间依赖H_L只用于纯正Cauchy，因此合法且无FTC新增端点；它不可插成mass-clock theorem的变动terminal mask。H_L=0互补集明确未付，L=n^{o(1)}也须为预定统一价格，不能事后把未受控sup命名成小L。

只分配已经未付的原正子集；先旧R172、再mass-clock、再H_L补集作不交归属可以使用这些价，原负账保持完整一次。没有新的母K1/K2根阶来源价或FULL实现性声明。

## 10. score_energy_geometry：独立推导与成稿后审

已先按作者准确三式独立推导，再实读E1–E22。初次完整后审版本已补finite-atomic-removal范围，SHA256：

    932858903d3a50b50711952773558c28e62aa6927dd6ca2eaaf57de37ab4b3aa

### 10.1 支持变化范围与原矩BV式

亲核的原R117 JG1以有限树/有限禁块截断保证Zt在事件间恒定且仅有限删除原子。作者现明确E2–E17限于此原截断；连续或原子nu只改变threshold forcing Θ的BV分布，不意味着一般nested支持的连续删除也被有限求和涵盖。推广连续BV删除需再补Dr连续损失及方差/covariance forcing，本文没有作此推广。此限制不作用于第8节mass主lemma，其MG2是任意nested的点态终端包含比较。

对moment Mr，原权重连续导数−k wt给−M_(r+1)dlogt；score跃迁必须计d(k^r)，不是r k^(r−1)dk的无原子简写。同源同时j坐标cross时包含(k+j)^r−k^r。阈值总体可有连续或奇异连续分布，作者保留Θ Stieltjes测度，未只列有限source事件。

E4从每源初始k加其后增量≤n、wt不增取得；删除后的cross不计。E5的更强直接帽∫M2≤n∫M1=n(e0−e1−D0)正确，不需阈值强迫符号或坐标独立。

### 10.2 V=eVar、阈值与删除

无forcing部分原矩微分给

    V'=−integral k(k−m)^2dmu≤0,
    Var_Pi'=−Pi[(k−m)^3].

后者符号不定。纯阈值j≥0在同一旧mu下给

    Delta V=2integral(k−m)j dmu+integral j²dmu
                      −(integral j dmu)²/e.

等价于DeltaΘ2−2m_pre DeltaΘ1−(DeltaΘ1)²/e_pre；该forcing可正可负，j²与原子平方不能丢。非原子部分是dΘ2−2m dΘ1，按BV链式完整保留。

删除分块的方差分解

    V_before=V_R+V_H+e_R d/(e_R+d)(m_R−m_H)^2

准确，故未归一V的删除耗散非负；这不使归一方差或filtered covariance删除变号。E11为已知∫M2扣∫M1²/e，E12转回双Pi需2∫V/e，e0/eg不能免费消失。E13的阈值forcing及删除均值跳都是原具体额外项。

### 10.3 frozen A covariance与同刻状态

独立微分C_A=Pi(Ak)−F m，得到

    C_A'=F Var−Pi[A(k−m)^2],
    E_A=Pi²[A(kv−ku)^2]=2F Var−C_A'.

原A冻结是必要条件；否则新增A导数项。纯阈值jump是Cov_Pi(A,j)。若删除后质量e、删除质量d，A在被删除块为0，则

    Delta_del C_A=d/(e+d) C_R
                  −ed/(e+d)^2 F_R(m_R−m_H),

与E16一致，符号不定。积分解出E_A后，E17是2∫FVar+C_initial−C_final+Q_A+sum Delta_del C_A，所有正负号正确。

同刻threshold/delete必须先在原删除前支持更新score，再删除，只作代数中间状态。已要求最后明文统一：所有Θ forcing的e、m、F/Pi均用阈值更新时尚未删除的状态；尤其E13的dΘ1/e_t不能按原右连续删除后e_t字面取值。原子二次项也用e_before。作者已有事件顺序，但该分母说明须明确后最终绑定。

E18一阶界由delta_plus≤kv、A全窗存活、et≥eg和−dwt=kwt dlogt直接得到，确实压过所谓平均初末比再CS的平方候选。撤回其为新进展的措辞正确。

### 10.4 双向槽与same-alpha cubic包络

E19引用本审计已核单槽能量，不重复一般付款。完整无额外pair门的原Pi²中，交换v/u给J_u D_minus²和J_v D_plus²同积分，所以方向对称W能量≤nW_beta/K；若原pair资格不对称，应先正放松到这个完整pair能量再交换。min(Jv,Ju)D²≤W成立，但不是J_v D²已付。向量平方及其额外kernel差项也完整，未隐藏u端J转移。

alpha>0时令b_alpha=alpha J/(TDelta)、d=[1−DK0/(TDelta)]_+，原rho=(d−b_alpha)_+。三次式b(d−b)²在b=d/3最大4d³/27，给J rho²≤4TDelta d³/(27alpha)。连p²/(9Q²)得到E22的min{Jd²,4TDelta d³/(27alpha)}，系数和方向正确。alpha=0只用第一项；Delta≤0按原零正交通处理，不造商。

这些是准确的流恒等式与原系数上包络，未提供其真实外测度总价。一般归一方差、threshold covariance、删除covariance、adaptive Q、微小alpha仍留待付；原负信用没有被平方化再领一次。

## 11. 主LaTeX公式对读

已实读 `proof.tex.txt`，SHA256：

    a3f72bcc5015af9abda84433aedb6895fb2863a0772b76ce4ee3363b68ada09d

两条主定理和证明与已审mass/energy稿一致。mass theorem直接使用Eg−Et终端包含式，明确无atomic删除假设；lambda用全部初始B，真实Pi不改。Theta的source两价、原mother的Qf接收价、energy的n/(2K)与log2/(2K)、b_v伴随、16Lambda/9 L sqrt(nlog2)及time-dependent CS门与time-fixed FTC门区别均正确。

末尾两来源精确校准也核算一致：C阈值1/2、质量1，B阈值1、质量epsilon，a=2^(−n)，则原I=1/(1+epsilon)−a/(a+epsilon)，lambda=(1−a)epsilon/(a+epsilon)，Gamma_C=0；质量clock上界确取等。固定n、epsilon正且趋0时旧essinf Gamma仍nlog2，此仅为有限代数校准，不宣称物理共同FIRST/FULL输入。

主稿保留所有互补未付域，未把数值fit或finite energy证书当作一般源浓度。数值由另行独审负责；本审计未运行任何新实验。


## 12. 最终SHA绑定、修正落实与停止

已亲读score稿最后的同刻状态约定，全部Theta forcing现在使用阈值更新、尚未删除时的e_theta/Pi_theta/F_theta，E9使用阈值前m_theta_minus；删除before则是阈值已更新的中间态。E9原子平方、E13的1/e、E15与Q_A的covariance状态均落实，原atom次序不再与右连续删除后e_t混淆。

最终绑定如下：

- `mass_sensitive_geometry.md`

      2bfd4807f05bb377f83031f7593b5b065dbbc87fd1bfd4f5fdeb696d3ee52b3e

- `blocker_mass_energy.md`

      95eb95dc95250a4b5c4109d7c5c2f6bd627e942fe3c488eb7e5b45180fa24205

- `score_energy_geometry.md`

      3cad8f3fc88d370897eb27bc4ed0a6827c46e7bf4e835a2c10c758b899c25d4b

- `proof.tex.txt`

      a3f72bcc5015af9abda84433aedb6895fb2863a0772b76ce4ee3363b68ada09d

判定：四稿在各自明确范围内通过，无剩余实质修订要求。MG1–MG12对任意原nested支持成立；score的矩/BV/signed恒等式E2–E17严格限原有限atomic删除截断，但完整保留连续nu导致的全部threshold BV。两种支持变化范围不能混同。

准确新增付款是mass-clock的低有效损失J来源价与放大来源接收价，以及质量门rho²b_v≤L²wg²的 `16Lambda/9 L sqrt(nlog2)W_beta` 正交通价。全局单槽平方能量 `nW_beta/(2K)` 和零阶 `log2 W_beta/(2K)` 已独立从未归一wt、high/FIRST及固定J真dx证明。所有费用保留原hard16/3一次、outer2Lambda、uniquej、源总质量、原窗口/history，未消费任何signed负信用。

一般好core分区的存在/可支付lambda与Gamma、未分配blocker源、质量门失败补集、其它母kernel份额及一般根阶弱型上界仍开放。没有FULL新正体积实现认证，也没有把有限数值、variance假设或新命名矩当成一般结论。

仅修改责任审计文件，无Git、spawn、PDF、新数值或他人文件改动。指定独审完成，冻结停止。
