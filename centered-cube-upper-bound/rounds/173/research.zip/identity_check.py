#!/usr/bin/env python3
"""Exact Fraction algebra checks; finite evidence, not a theorem substitute."""
from fractions import Fraction as F
from pathlib import Path
import json

def moments(mu,k,A):
 e=sum(mu);m=sum(w*x for w,x in zip(mu,k))/e
 V=sum(w*(x-m)**2 for w,x in zip(mu,k))
 f=sum(w*a for w,a in zip(mu,A))/e
 C=sum(w*a*(x-m) for w,a,x in zip(mu,A,k))/e
 return e,m,V,f,C
out=[]
for n in (2,8,64):
 for z in range(10):
  mu=[F(z+1,7),F(2*z+3,11),F(z+2,13),F(1,2**(z+1))]
  k=[F((z+i*3)%(n+1)) for i in range(4)]
  A=[F(1),F(1,3),F(0),F(0)]
  e,m,V,f,C=moments(mu,k,A)
  M1=e*m;M2=sum(w*x*x for w,x in zip(mu,k));M3=sum(w*x**3 for w,x in zip(mu,k))
  Vprime=-M3+2*M1*M2/e-M1**3/e**2
  assert Vprime==-sum(w*x*(x-m)**2 for w,x in zip(mu,k))<=0
  Ak=sum(w*a*x for w,a,x in zip(mu,A,k))/e
  Ak2=sum(w*a*x*x for w,a,x in zip(mu,A,k))/e
  Cprime=-Ak2+m*Ak+C*m+f*V/e
  VA=sum(w*a*(x-m)**2 for w,a,x in zip(mu,A,k))/e
  assert Cprime==f*V/e-VA
  pair=sum(w*v*a*(x-y)**2/e**2 for w,a,x in zip(mu,A,k) for v,y in zip(mu,k))
  assert pair==VA+f*V/e
  jumps=[F(min(n-int(x),(i+z)%3)) for i,x in enumerate(k)]
  en,mn,Vn,fn,Cn=moments(mu,[x+j for x,j in zip(k,jumps)],A)
  assert Vn-V==2*sum(w*(x-m)*j for w,x,j in zip(mu,k,jumps))+sum(w*j*j for w,j in zip(mu,jumps))-sum(w*j for w,j in zip(mu,jumps))**2/e
  assert Cn-C==sum(w*(a-f)*j for w,a,j in zip(mu,A,jumps))/e
  er,mr,Vr,fr,Cr=moments(mu[:2],k[:2],A[:2]);d,mh,Vh,fh,Ch=moments(mu[2:],k[2:],A[2:])
  assert V==Vr+Vh+er*d/e*(mr-mh)**2
  assert Cr-C==d/e*Cr-er*d/e**2*fr*(mr-mh)
  out.append({'n':n,'case':z,'variance_decay':str(Vprime),'threshold_variance_jump':str(Vn-V),'deletion_variance_loss':str(V-Vr),'filtered_deletion_jump':str(Cr-C),'all_seven_identities':True})
cubic=[]
for d in (F(0),F(1,5),F(1)):
 for i in range(28):
  b=d*F(i,27)
  assert 4*d**3-27*b*(d-b)**2==(d-3*b)**2*(4*d-3*b)>=0
  cubic.append([str(d),str(b)])
result={'scope':'finite exact algebra; no FIRST/physical/source-budget certification','cases':out,'identity_count':210,'cubic_points':len(cubic),'all_pass':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: 210 exact moment identities; 84 exact cubic-factorization checks')
