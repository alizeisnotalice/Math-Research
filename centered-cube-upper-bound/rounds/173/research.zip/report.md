# 第173轮：质量敏感极值几何与已付平方能量

2026-10-16。上一轮已独审并推送，属于实质进展。本轮继续一般中心立方体 n^(1/2+o(1)) 上界目标，尚未闭合。主攻原剩余中间区域的来源质量与联合几何，不扩张反例目录。

## 新结果一：对少量低分数来源收费，而不是取无质量的最坏源

R172用全初始支持的最小score建立单调共同钟。任何极小质量低score源都可能使这一最小值下降，给其他来源增加很大的Gamma。R173允许归一化后的总质量增长，但明确支付增长费用。

每个原行只选择一个可测、时间固定的划分 S=C⊔B；不改变原nu、Z、Pi、alpha或good/high。C是核心来源组，B是其余初始来源。令r(t)=essinf_C k_t、c(t)=exp(-int r dlogt)，定义

lambda=(c_g/e_g) int_ell^g int_B (r-k_t(u))_+ [w_t(u)/c_t] nu(du) dlogt。

B必须包括后来删除的来源，并继续用原物理wt计算其假想后续增长。若lambda<1，则原C槽正交通满足

I[A1_C]≤e_g^{-1}int_C A wg {exp(Gamma_C)/(1-lambda)-1}dnu，
Gamma_C=int(k-r)dlogt。

证明不是把未知交通重新命名：lambda的分子是指定共同钟下未归一来源的一次线性增长积分，原分母有明确下界 E_t≥E_g-int_t^g G；对(v_t/D_t)准确求导消掉两项费用，只有一次(1-lambda)逆因子，没有另乘n或删除次数。

当B在全窗满足k_B≤r时，lambda精确化为

lambda=e_g^{-1}int_B[wg-cg well]dnu≤eta_B=e_g^{-1}int_Bwg dnu。

因此有序低score来源的真实质量可支付费用。eta_B是整个初始B的终端权质量，只有没有B删除才等于实际Pi_g(B)。删除后实际Pi_g(B)=0并不免除此费用。坐标wise更靠近y是score排序的一个物理充分条件，但定理本身只需score排序，允许相关坐标。

令Theta_C=Gamma_C-log(1-lambda)。对Theta_C≤M的核心来源，原J-share总价为(16Lambda/9)(exp(M)-1)Wbeta；对其余满足Sfuture-Theta_C≥h的来源，价为(16Lambda/9)exp(-h)E int qdx。取M=.5logn、适当h即得根阶和epsilon接收分支。原无chiJ母式在expTheta_C-1≤zeta上得到(16Lambda/3)zeta接收价；当Gamma_C=0且eta_B≤3epsilon/(16Lambda+3epsilon)，直接epsilon吸收，即使R172全支持Gamma为线性n。

## 新结果二：真正全局支付的平方能量及质量门根阶支

保持原真实外积分和完整来源，已证单槽能量

E_J=int J_v (k_v-k_u)_+² Pi_t² dlogt beta(dy)dx dP≤n Wbeta/(2K)。

理由是delta_+≤kv，int kv²wt dlogt≤n int kvwt≤n，high配对给1/(2K)，最后只有固定J可以用真实dx积分归一。唯一j和原窗口范围保留。零阶同理Z_J≤log2 Wbeta/(2K)。没有假定相关score有O(n)方差。

Cauchy时不能抛掉原低score质量 b_t(v)=Pi_t{k_u<k_v}。精确配套系数为

C_b=int [p²A²/J] b_t(v) Pi_t(dv)dlogt beta dx dP。

对任意统一L≥0，实际正时间/来源子支 rho² b_t(v)≤L²wg²，由good使C_b≤KL²log2 Wbeta/18。因此该支原正交通价≤(16Lambda/9)L sqrt(nlog2)Wbeta。L=n^o1时达到根阶；这是一项一般输入上的原交通子支，未断言该门总成立。原时间相关门只用于非负Cauchy，不插入要求终端冻结的共同钟导数公式。

这些结果分别见mass_sensitive_geometry.md、blocker_mass_energy.md；详细LaTeX见proof.tex.txt。独审见mass_energy_audit.md。

## 辅助能量审计与未采纳的捷径

score_energy_geometry.md记录未归一V=e Var的精确耗散、一般BV阈值强迫和原有限删除跳。删除总降低V，但未必降低归一方差或带A covariance；因此归一平方能量有实际阈值和删除费用，不能偷换。原有限树截断范围明确；主质量钟定理仍可处理任意nested支持。

同alpha截断还给精确三次包络 J rho²≤4TDelta d³/(27alpha)，d=[1-DK0/(TDelta)]+，alpha>0；alpha0必须保留原Jd²。它没有支付自适应Q与小alpha，不计为新的全局分支。

曾筛查A加权初末质量比+CS路线，但其sqrt(n)界被直接一阶(aell-ag)/eg界严格压过，未列为进展。没有把这一否定作为主要成果；它避免继续重复无效归约。

## 统一账本与仍未闭合的部分

所有付款保留同一f/FIRST、nu≤beta且sum beta≤f、实际勒贝格dx、原alpha/rho、高层分母与删除、history、共同a,b窗口。hard16/3与outer2Lambda只付一次；Cauchy两因子不分别领hard信用。未跨窗口免费求和，不把adaptiveQ当概率核。

可以先给R172已付源槽归属，再给一个固定核心划分的已付槽归属，最后在剩余正交通上使用质量门；只删正门即可继承上界。所有原负信用留在完整行，不复用。若用多个核心候选，必须先制定互斥归属并核对其费用，不能将多个来源帽免费叠加。

仍缺：从任意正L1共同输入几何推出可付的核心划分，或直接支付lambda≥1、未分配B、较大Theta且future放大不足以及质量门失败的联合交通。母式K1/K2的一般根阶来源价也未闭合。新估计没有自动证明这组补集为空或有根阶预算；一般n^(1/2+o(1))仍未证明。

下一关键工作是构造受共同输入约束的核心选择/共同来源容量估计，并保留完整初始阻碍质量和真实接收测度。不得把这个存在性写作已知几何覆盖引理。

## 数值与复现

最终质量钟清单22输入：21合法模型，1个删除A-positive来源的非法输入被校验器拒绝。按初步校准、R172历史压力与交叉/删除、n32/64/128扩大三阶段实施。18个合法行的I/EJ/Cb采用逐阈值和删除段的二源FTC精确有理公式，其余采用有严格二阶导数余项的有理中点区间积分。21行质量钟比较均通过（13精确等式、5严格有理比较、3分离区间比较），Cauchy为18精确等式和3区间比较；Cb≤C0、Ewhole≤n eell各21通过。无未达容差、模糊比较或失败。

n64、a=2^-64、epsilon=a³的模型满足整个时间窗的L=1后验质量门，I约2.9387358771e-39，尽管原Gamma=64log2；epsilon=a²对应模型不满足此门，I约5.4210108624e-20。质量钟在未删除二源定score模型上精确取等；删除模型保留完整初始B费用。无序B模型使用一般正增长积分，不偷用静态有序公式。共同质量缩放不改变后验积分与lambda，并按比例改变未归一能量。所有模型均为有限代数，不认证物理三点、good/rho、共同f/FIRST、hardcarrier/history或FULL。

另已完成主代理210个Fraction精确矩/阈值/删除恒等式检查及84个三次因式分解检查，全部通过。普遍结论来自证明，不来自这些有限验证。Sol接管最终实现修订并完成数值审查，主代理随后在独立目录重放。

本轮使用1 Astra high、2 Sol high、1 Sol medium、1 Luna medium，各自独立责任文件。D02 Gibbs工具用于核查有限归一化的适用边界，没有援引一般无穷域变分定理；M03当前不含可迁移的一般稳定性定理，未据其假设核心集中。实际证明为自含微分、Tonelli、Cauchy和原合同。没有可按模型归属的扣额数据，不推测成本比例。

最终按白名单压缩归档，完整工作先逐字节备份仓库外，独立提交并推送。本轮不编译PDF。
