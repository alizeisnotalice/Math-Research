# R173: a paid square energy and a posterior blocker-mass branch

Parent proof, pending independent final audit. All raw expressions are original ones from R172; no new selector or source replaces the originals. Let \(W=\mathbb E\sum_V\|\beta_V\|\), \(\Lambda=128/119\). The measure before the original hard-source factor and outer factor is original \(d\mathbb P\,dx\,\beta_V(dy)\,dt/t\,\Pi_t(dv)\Pi_t(du)\), with all original admissibility indicators. Only drop nonnegative gates. The hard-source cap is16/3 and outer factor2Lambda, counted once after the estimates below.

## 1. Global energy, with dimension and time costs

Write \(\delta_+=(k_t(v)-k_t(u))_+\). Because the scores are nonnegative and at most n,
\[
 \delta_+^2\le k_t(v)^2,\qquad
 \int_{\rm actual}k_t(v)^2w_t(v)\,dt/t
 \le n\int_{\rm actual}k_t(v)w_t(v)\,dt/t\le n.
\]
For the last inequality extend positively to the original full range \(\xi\in[1/2,1]\) and use \(-dw=k w\,d\log t\). The scalar product weights are absolutely continuous; score threshold faces contribute no atom to w. Source deletions only remove nonnegative integrands.

Original nestedness gives \(e_t\ge e_g\), and high plus complete FIRST gives
\[
 \int_{\rm high}\frac{\beta_V(dy)}{e_g}
 \le\frac1{2Kq}\int p_y\,\beta_V(dy)\le\frac1{2K}.
\]
Retain unique original j until this bound eliminates its dependence. J=P1,b is fixed in x in the common window. Summing source measures then integrating real dx yields
\[
 E_J:=\mathbb E\sum_V\int J_v\delta_+^2\,d\Pi_t(v)d\Pi_t(u)\,\frac{dt}{t}\,\beta_V(dy)dx
 \le\frac{n}{2K}W. \tag{E1}
\]
Likewise \(0<w_t\le1\), time length≤log2, and the same argument give
\[
 Z_J:=\mathbb E\sum_V\int J_v\,d\Pi_t(v)\,\frac{dt}{t}\,\beta_V(dy)dx
 \le\frac{\log2}{2K}W. \tag{E2}
\]
The original eligible/high masks are retained in both left sides. Neither statement is a bound for all unweighted adaptive kernels. The direction of delta is essential to E1: a bound for the symmetric square with the same J_v slot would leave the cross-slot k_u term.

## 2. Retain actual lower-score source mass in Cauchy

Define the original posterior obstruction mass
\[
 b_t(v)=\Pi_t\{u:k_t(u)<k_t(v)\}\in[0,1].
\]
For any measurable time/source gate \(0\le H_t(v)\le1\), the original positive J-share satisfies, before the two outer constants,
\[
 I_H\le \sqrt{E_J\,C_H},\quad
 C_H=\mathbb E\sum_V\int H_t(v)\frac{p_y^2A_v^2}{J_v}b_t(v)\,d\Pi_t(v)\,\frac{dt}{t}\,\beta_V(dy)dx. \tag{E3}
\]
Proof: Cauchy on the full pair measure, writing the integrand as \((\sqrt{J_v}\delta_+)(p_yA_v/\sqrt{J_v})\), retaining \(1_{\delta_+>0}\) in both factors. Integrating the u-slot in the second square gives b_t(v) exactly. Fractional H can be split as sqrt(H) in each factor. No source independence is used. In particular b=0 gives zero traffic even if the unmasked companion is large. This improvement is quantitative mass dependence, not a new assumption that posterior tails are small.

## 3. A genuinely paid branch of the original nonnegative traffic

The original A=1_good rho J/(3Q) and good inequality give
\[
 p_y^2 A_v^2/J_v\le K^2\rho_v^2J_v/(9w_g(v)^2).
\]
For any prescribed L≥0 let
\[
 H_L(t,v)=1_{\{\rho_v^2b_t(v)\le L^2w_g(v)^2\}}.
\]
This is a measurable sublevel of the original posterior and original terminal residual; it does not recompute alpha, rho, support or normalization. On this branch E2 bounds the companion by \(K L^2\log2\,W/18\). E1 and E3 therefore imply
\[
 \operatorname{RawPositive}_J[H_L]
 \le\frac{16\Lambda}{9}L\sqrt{n\log2}\,W. \tag{E4}
\]
This applies to arbitrary original inputs on this branch, allowing arbitrarily large R172 Gamma. It is not a claim that all sources satisfy the gate. Taking L=n^{o(1)} gives the requested order for this branch without borrowing negative credit. For L=0 its original positive integrand is zero: either rho=0 or b=0.

The exact sharper gate \(p_y^2A_v^2b_t(v)\le B^2J_v^2\) gives the price \((16\Lambda/(3K))B\sqrt{n\log2}W\); the displayed rho/wg gate is a transparent sufficient condition with B=KL/3. For the universal decomposition, the unpaid complement is precisely H_L=0 and all other inherited unpaid traffic. No tail exponent or global companion moment is postulated as proved.

## 4. How to combine with R172 and a mass-clock branch

All these cuts are cuts of the nonnegative original positive integrand. Assign source regions already paid by R172 first, then any paid mass-clock branch, then H_L on their complement; removing positive gates only strengthens E1/E2 and the source estimates. Preserve all original negative terms in the full row. Do not split or consume them again. Time-dependent H_L is legal for the positive Cauchy argument; it must not be inserted as a time-varying terminal A in R172's derivative proof.

Window, histories, source expectations and unique j stay in their inherited original scope. Root payment for this J-share does not price K1/K2 parts of the earlier mother. Global concentration of the remaining obstruction mass or a uniform payment of H_L=0 remains unproved. No numerical model in this round alone verifies common f/FIRST or physical realizability.
