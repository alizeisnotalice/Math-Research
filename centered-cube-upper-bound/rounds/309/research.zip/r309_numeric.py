#!/usr/bin/env python3
"""R309 posterior low-degree tensor bounds and fixed-full-bad payment diagnostics."""
import sys,json,itertools,math,hashlib
from fractions import Fraction as F
from pathlib import Path
from decimal import Decimal,localcontext
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
COUNTS={};FAIL=[];EPS=F(1,16)
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def poly(factors):
 coeff=[F(1)]
 for a,b in factors:
  new=[F(0)]*(len(coeff)+1)
  for k,v in enumerate(coeff):new[k]+=v*a;new[k+1]+=v*b
  coeff=new
 return coeff
def cdf(n,p,K):
 if K<0:return F(0)
 if K>=n or not p:return F(1)
 if p==1:return F(0)
 a=p.numerator;b=p.denominator;B=b-a;term=B**n;total=term
 for k in range(K):term=term*(n-k)*a//((k+1)*B);total+=term
 return F(total,b**n)
def markov(n,s,K):return F(2)**K*(1-s/8)**n
def tensor_case(n,s,hard,phi):
 factors=[((1-s)*h,s*v) for h,v in zip(hard,phi)];coeff=poly(factors);P=math.prod(a+b for a,b in factors)
 direct=[F(0)]*(n+1)
 for bits in itertools.product([0,1],repeat=n):direct[sum(bits)]+=math.prod(factors[i][bit] for i,bit in enumerate(bits))
 ck(coeff==direct and sum(coeff)==P,'exact_tensor_coefficients_vs_subset_expansion',{'n':n,'s':str(s),'hard':hard})
 forced=sum(not h for h in hard);ck(all(coeff[k]==0 for k in range(forced)),'outside_coordinates_force_minimum_degree',{'n':n,'s':str(s),'forced':forced})
 if not P:
  ck(all(v==0 for v in coeff),'zero_P_all_tensor_components_zero_no_posterior_division',{'n':n,'s':str(s),'hard':hard})
  return {'n':n,'s':s,'hard':hard,'phi':phi,'P':P,'forced_outside_degree':forced,'posterior_defined':False}
 pi=[b/(a+b) for a,b in factors];pc=poly([(1-p,p) for p in pi]);pmin=s/(4-3*s)
 ck(all(v/P==q for v,q in zip(coeff,pc)),'exact_conditional_independent_posterior_coefficient_identity',{'n':n,'s':str(s)})
 for h,v,p in zip(hard,phi,pi):
  ck((not h and p==1) or (h and p==s*v/(1-s+s*v)),'exact_inside_outside_posterior_formula',{'n':n,'s':str(s)})
  ck(p>=pmin>=s/4,'exact_uniform_posterior_lower_bounds',{'n':n,'s':str(s)})
 expectation=math.prod(1-p/2 for p in pi);ck(expectation<=((1-s/8)**n),'exact_half_laplace_product_bound',{'n':n,'s':str(s)})
 for K in sorted(set([0,min(1,n),min(2,n),n])):
  low=sum(pc[:K+1]);strong=cdf(n,pmin,K);weak=cdf(n,s/4,K);M=F(2)**K*expectation;R=markov(n,s,K)
  ck(low<=strong<=weak<=R and low<=M<=R,'exact_low_degree_CDF_and_rational_Markov_bounds',{'n':n,'s':str(s),'K':K})
 return {'n':n,'s':s,'hard':hard,'phi':phi,'P':P,'forced_outside_degree':forced,'posterior_defined':True,'pi':pi,'posterior_degree_coefficients':pc}
initial=[]
for n in [1,2,4,8]:
 for hard in [[1]*n,[int(i%2==0) for i in range(n)],[0]*n]:
  phi=[F((i%4)+1,4) for i in range(n)]
  for s in [F(0),F(1,16),F(1,2),F(1)]:initial.append(tensor_case(n,s,hard,phi))
boundary=[]
for n in [1,4,16]:
 for s in [F(0),F(1)]:
  for h in [0,1]:
   if n<=8:boundary.append(tensor_case(n,s,[h]*n,[F(1,4)]*n))
   else:
    P=((1-s)*h+s/4)**n
    ck((s or h) or P==0,'boundary_zero_P_guard_large_dimension',{'n':n,'s':str(s),'h':h})
    if P:
     p=(s/4)/(1-s+s/4) if h else F(1);expected=[F(int(k==(0 if s==0 else n))) for k in range(n+1)]
     ck(poly([(1-p,p)]*n)==expected,'s_zero_or_one_posterior_point_degree',{'n':n,'s':str(s)})
    boundary.append({'n':n,'s':s,'hard_value':h,'P':P,'posterior_defined':bool(P)})
expanded=[]
for n in [16,64,256,1024,4096]:
 for s in [F(0),F(1,1024),F(1,64),F(1,4),F(1)]:
  for K in sorted(set([0,1,8,32,n])):
   weak=cdf(n,s/4,K);strong=cdf(n,s/(4-3*s),K);R=markov(n,s,K);cert=R<=EPS
   ck(strong<=weak<=R,'expanded_exact_binomial_CDF_vs_rational_bound',{'n':n,'s':str(s),'K':K})
   if cert:ck(strong<=weak<=EPS,'exact_rational_epsilon_threshold_certificate',{'n':n,'s':str(s),'K':K})
   if n==16:
    dp=poly([(1-s/4,s/4)]*n);ck(sum(dp[:min(K,n)+1])==weak,'small_binomial_CDF_independent_exact_DP',{'n':n,'s':str(s),'K':K})
   expanded.append({'n':n,'s':s,'K':K,'weak_lower_pi_s_over_4_CDF':weak,'strong_actual_pmin_CDF':strong,'rational_Markov':R,'epsilon':EPS,'epsilon_certified_by_rational_bound':cert,'epsilon_certified_by_strong_exact_CDF':strong<=EPS,'epsilon_certified_by_weak_exact_CDF':weak<=EPS,'Markov_vacuous_R_ge_one':R>=1,'epsilon_target_not_certified':not cert})
actualphi=[]
for xtext in ['-0.5','-0.49999999999999999999','-0.25','0','0.25','0.49999999999999999999','0.5']:
 vals=[]
 for dp in [40,60]:
  with mp.workdps(dp):
   x=mp.mpf(xtext);phi=1-mp.expint(3,mp.mpf('.5')+x)-mp.expint(3,mp.mpf('.5')-x)
   quadrature=mp.quad(lambda t:t*(2-mp.exp(-(mp.mpf('.5')+x)/t)-mp.exp(-(mp.mpf('.5')-x)/t)),[0,mp.mpf('0.125'),mp.mpf('0.5'),1])
   ck(mp.mpf('0.25')<=phi<=1,'actual_phi_inside_analytic_bounds_ordinary_mp',{'x':xtext,'precision':dp})
   ck(abs(phi-quadrature)<mp.mpf('1e-30'),'actual_phi_E3_vs_direct_integral_ordinary_mp',{'x':xtext,'precision':dp});vals.append(phi)
 with mp.workdps(70):
  error=abs(vals[0]-vals[1]);ck(error<mp.mpf('1e-30'),'actual_phi_40_60_refinement',{'x':xtext})
  actualphi.append({'x':xtext,'phi_60digits':mp.nstr(vals[1],60),'absolute_40_60_difference':mp.nstr(error,15),'scope':'ordinary mpmath, not interval certification'})
# Finite positive-flow interface: only the capturing end is split. Full bad,
# J,A, original lowp/middle labels and the source target remain frozen.
flow=[];slist=[F(1,4),F(1),F(1,1024),F(0)];alpha=[cdf(1024,s/(4-3*s),8) for s in slist];paid=[markov(1024,s,8)<=EPS for s in slist];totalpaid=totaltarget=totallow=totalunpaid=F(0)
for label,u,sigma,beta in [('lowp',[F(1,100),F(1),F(1),F(1)],[1,0,0,0],F(2,3)),('middle',[F(1),F(1),F(1),F(1)],[1,0,1,0],F(3,5))]:
 J=sum(u);A=sum(v*s for v,s in zip(u,sigma));bad=[v*(1-s) for v,s in zip(u,sigma)];badmass=sum(bad);L=sum(v*s*a for v,s,a in zip(u,sigma,alpha));Lpaid=sum(v*s*a*p for v,s,a,p in zip(u,sigma,alpha,paid));Lunpaid=L-Lpaid
 ck((A/J<F(1,32)) if label=='lowp' else (F(1,32)<=A/J<F(7,8)),'original_lowp_middle_labels_frozen_full_capture',{'label':label})
 Blo=L*badmass/J;Bpaid=Lpaid*badmass/J;Bunpaid=Lunpaid*badmass/J
 ck(Blo==Bpaid+Bunpaid and Bpaid<=EPS*A*badmass/J<=EPS*A,'fixed_full_bad_one_sided_capturing_payment',{'label':label})
 ck(all((not p) or a<=EPS for a,p in zip(alpha,paid)),'capturing_lowdegree_fraction_paid_only_when_certified',{'label':label})
 totalpaid+=beta*Bpaid;totallow+=beta*Blo;totalunpaid+=beta*Bunpaid;totaltarget+=beta*A
 flow.append({'original_label':label,'full_U':u,'full_sigma':sigma,'full_J_unchanged':J,'full_A_unchanged':A,'full_bad_U_unchanged':bad,'row_beta':beta,'capturing_low_degree_fractions':alpha,'paid_receiver_flags':paid,'B_low_degree':Blo,'B_paid':Bpaid,'B_unpaid':Bunpaid,'full_actual_capturing_target_A':A})
ck(all(row['B_paid']>0 for row in flow) and flow[1]['B_unpaid']>0,'both_original_lowp_and_middle_have_nonzero_paid_flow',{})
ck(totalpaid>0 and totalunpaid>0 and totalpaid+totalunpaid==totallow,'nontrivial_paid_and_unpaid_fixed_full_bad_split',{})
ck(totalpaid<=EPS*totaltarget,'one_epsilon_T_payment_across_lowp_and_middle_union',{})
def encode(x):
 if isinstance(x,F):
  if x.numerator.bit_length()+x.denominator.bit_length()<=1250:return str(x)
  a=abs(x.numerator).to_bytes(max(1,(abs(x.numerator).bit_length()+7)//8),'big');b=x.denominator.to_bytes(max(1,(x.denominator.bit_length()+7)//8),'big')
  with localcontext() as ctx:ctx.prec=40;value=str(Decimal(x.numerator)/Decimal(x.denominator))
  return {'decimal40':value,'exact_binary_rational_sha256':hashlib.sha256(bytes([x.numerator<0])+len(a).to_bytes(8,'big')+a+b).hexdigest()}
 raise TypeError(type(x).__name__)
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Finite actual tensor coefficient/posterior algebra, rational stochastic/Markov bounds and a fixed-full-bad capturing-flow payment interface. Rational phi tensors satisfy the analytic inside bound but are not all asserted actual kernel samples. Actual phi is separately checked by ordinary highprecision1D integration. No complete original low/e/m/history, component-FIRST or root certificate.','posterior':'Inside h=1:pi=s phi/(1-s+s phi)>=s/(4-3s)>=s/4 for1/4<=phi<=1. Outside h=0 and P>0:pi=1. Conditional coordinates independent. If P=0 no posterior or P_low/P is defined; all coefficients are checked zero.','bounds':'Two valid chains: P_low/P<=Pr[Bin(n,s/(4-3s))<=K]<=Pr[Bin(n,s/4)<=K]<=2^K(1-s/8)^n; and P_low/P<=2^K product(1-pi/2)<=2^K(1-s/8)^n<=2^K exp(-ns/8). The exact tests use the rational Markov expression; no floating exponential decides a payment.','expanded_scope':'n16,64,256,1024,4096; s0,1/1024,1/64,1/4,1; K0,1,8,32,n with duplicates removed; epsilon1/16. Exact binomial CDF uses integer numerator recurrence and common denominator. Smalln16 is independently compared to tensor polynomial DP. A bound>=1 is marked vacuous; R>epsilon is separately marked not certified.','payment_scope':'Only original capturing U_low is split. Original full bad U, J,A, chi and lowp/middle labels are frozen; one uniform epsilon payment for their union. No reapplication of FIRST to components. This is a finite positive-flow algebra interface, not a claim that these flow rows realize the full original kernel/history.','serialization':'Small Fraction exact strings; large values40digit display and exact canonical binary rational SHA256(sign byte,8byte numerator-length,absolute numerator bytes,denominator bytes). Checks retain full Fractions.','check_counts':COUNTS,'failures':FAIL,'stages':[{'name':'initial_exact_tensor','cases':initial},{'name':'boundary_s0_s1_P0','cases':boundary},{'name':'expanded_exact_CDF_and_payment_threshold','cases':expanded}],'actual_phi_checks':actualphi,'fixed_full_bad_flow_cases':flow,'aggregate_one_epsilon_payment':{'paid':totalpaid,'unpaid':totalunpaid,'target_T':totaltarget,'epsilon':EPS}}
base=Path(__file__);base.with_suffix('.json').write_text(json.dumps(out,default=encode,sort_keys=True,indent=2)+'\n');lines=['# R309 exact posterior and low-degree diagnostics','',out['scope'],'',out['posterior'],'',out['bounds'],'',out['expanded_scope'],'','|n|expanded cases|rational epsilon certificates|vacuous R>=1|','|---:|---:|---:|---:|']
for n in [16,64,256,1024,4096]:
 records=[r for r in expanded if r['n']==n];lines.append(f"|{n}|{len(records)}|{sum(r['epsilon_certified_by_rational_bound'] for r in records)}|{sum(r['Markov_vacuous_R_ge_one'] for r in records)}|")
lines+=['',out['payment_scope'],'','Both lowp and middle rows have positive paid flow; the middle row also has positive unpaid low-degree flow. Their combined paid fee is bounded by one epsilon times the same original capturing target.','', 'Actual phi inside evaluations use E3 and a direct scale integral at40/60digits, including +/-1/2 and nearby points. These are numerical evidence, not interval arithmetic. All other displayed comparison decisions are exact Fraction.']
base.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'initial_cases':len(initial),'boundary_cases':len(boundary),'expanded_cases':len(expanded),'rational_epsilon_certificates':sum(r['epsilon_certified_by_rational_bound'] for r in expanded),'vacuous_cases':sum(r['Markov_vacuous_R_ge_one'] for r in expanded)},indent=2));assert not FAIL,FAIL
