# R309：实际高softness低次数付款与剩余稀疏面几何

## 原目标与范围

一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮沿用R308原low-pe、m>M、v>=v0槽，保留任意原正L1来源、真实dx、q、FIRST、同尺度硬帽、完整e_g/m/history、原J/p前缀及R307分配M。没有把低次数当成低维问题。

以S表示实际softness参数s(x)，以s_sep表示R307尺度分离比，避免混用。共同theta仍只积分一次。K是R308按原n,epsilon_degree,eta_mid,q_-H选出的统一捕获端次数截断；可能为n。

## 1. 真实乘积核的条件次数

原一维h=1_[-1/2,1/2]，w(t)=∫_0^1 exp(−|t|/v)dv，phi=h*w。其偶单调性给|u|<=1/2时
phi(u)>=phi(1/2)=∫_0^1 v(1−exp(−1/v))dv >=(1−exp(−1))/2>1/4；且phi<=1。

固定原x,y,L,S，若P_(S,L)(x−y)>0，则展开标签的条件分布是独立Bernoulli，坐标软标签概率
pi_i=S phi(u_i)/[(1−S)h(u_i)+S phi(u_i)]，u_i=(x_i−y_i)/L。

在硬核外h=0，pi_i=1；硬核内pi_i>=S/(4−3S)>=S/4。此独立性仅是同一个固定原乘积核的标签恒等式，不是重新给每个坐标选softness，也不对原来源作独立假设。P=0时每个非负分量也为0，预先归零。

令P_lo=Σ_(k<=K)b_nk(S)q_k,L。精确恒等式P_lo/P=Pr(N<=K)，以及Markov对2^(-N)给

P_lo/P <= min(1, 2^K product_i(1−pi_i/2))
 <= min(1,2^K[1−S/(2(4−3S))]^n)
 <= min(1,2^K exp(−nS/8))。

因此只要nS>=8[K log2+log(1/delta)]，就有原实际U_lo<=delta U点态。无需源密度、尺度替换或单分量FIRST。

固定delta=1/128，可采用纯有理充分门
G_K(x)={n s(x)>=(28/5)(K+7)}。

因为exp(7/10)>1+7/10+(7/10)^2/2+(7/10)^3/6=12013/6000>2，故log2<7/10。K=n或门阈值>n时G_K为空，不能宣称这一实例有非零收益。也可保留更锐实际pi乘积证书，不与保守门混用。

## 2. 原余项上的统一正分裂

用R_theta(F;D)表示R307原有向pair积分：捕获端密度改为F_y(w)，原prefix另限制D；非捕获端U_y(u)(1−sigma_u)、原J、chi=1_{J>=H,p<7/8}、M<=1均不改变。其原有向结构为

∫ell(dt)beta(dy)nu(dz) chi/J
  ×∫_(Rw,Ru<=t) F_y(w)sigma_w U_y(u)(1−sigma_u)M(y,z,w,u)dwdu。

R308已付middle高次数后，保留
R_lowp(U)+R_mid(U_lo)，lowp={p<eta_mid}、mid={eta_mid<=p<7/8}均在原prefix上判断。

将lowp(U)=lowp(U_hi)+lowp(U_lo)，再将全部p层的U_lo按原capturing w是否属于G_K分开。得到精确正分裂

R_lowp(U)+R_mid(U_lo)
 =R_lowp(U_hi)+R_allp(U_lo 1_{G_K^c})+R_allp(U_lo 1_{G_K})。

最后一项<=delta T_theta：点态U_lo1_G<=delta U，且原full有向pair费用逐层至多A(J−A)/J<=A。低p和mid在prefix上互不交，所以合并只付一份delta T，不是两份。theta总权重1，来源不复制。R308已付middle高次数不再支付。

原入口Lambda T<=(2048/3)Lambda lambda dW_beta+(64/3)Lambda ∫theta[R_lowp(U)+R_mid(U_lo)]给出

Lambda T <=(4096/5)Lambda lambda dW_beta
 +(128/5)Lambda ∫theta[R_lowp(U_hi)+R_allp(U_lo1_{G_K^c})]。

delta=1/128使左侧剩余系数5/6。Lambda=128/119；d=kappa0 psi_inf/(q_-v0)保留所有逆尺度比费用。仍是内部T吸收，全局X误差系数新增0。

由此原中捕获未付端满足低次数且实际 n s<(28/5)(K+7)。低捕获中高次数部分完整保留；不能称所有捕获端都已限制到小softness。

## 3. 小softness与原高度的真实支撑联系

完整硬核内x−y∈Q_L，有P_(S,L)(x−y)L^n>=(1−3S/4)^n。原low-pe/high-m高度给
P_(S,L)L^n<=kappa0(L/R)^(n/2)，并可保留原带c_j更强因子；另一已证全局高度给<=kappa0 G(L/R)^(3n/4)，G=gamma^(n/2)。

令tau为上述原带高度与全局高度上界的较小值。在这些高度均适用的原分支，若tau小于(1−3S/4)^n，该原合资格硬核内部为空。对S<=S0也可用更弱阈值(1−3S0/4)^n，S0<=1。低次数k<=K的捕获端在硬核外最多有K个坐标，因为每个硬核外坐标必须使用软标签。于是只有在上述高度条件成立时，可定位到1至K个外侧坐标；条件不成立的内部与全部外侧来源费用仍保留。

这是几何支撑约束，不是来源付款。不得以薄层体积或有限面数代替任意来源质量。特别不能按binom(n,K)面逐份花同一个来源质量。

## 4. 低捕获尝试的具体未闭合点

辅助稿核回：按p分层可逐层选择K并保留一份epsilon T，但深度未受控，K最终可到n。累计捕获rank给单个(y,z)的min(A,tau)裁剪界，积分后仍需原source-weighted容量预算，否则产生beta×nu或A_n W_nu。没有从原门得到统一正捕获质量下界。本轮不将这种再分层当作新根阶进展。

全局总账继续保留R304原入口、完整采用误差表、极小尺度比、宽距离连续、初始、真正删除时间原子、未来被删来源和负项一次结算。小softness低次数核心及低p高次数都还需要共同来源极值几何预算。

## 实际计算与技能

本轮用H05的指数矩纪律，先证明真实条件标签乘积，再应用Markov，不引用未经适用性核验的集中定理。主cutoff_probe用Fraction联动R308截断与本轮softness门，三阶段n16..1024、qH=n^-2,1,n²，18配置、22个精确检查通过。以epsilon_degree1/64、eta_mid1/16为例，n1024,qH1时K122，高softness门为s>=903/1280；n1024,qH=n^-2时K251，门阈值903/640>1，分支为空。不能由有限表拟合维数指数。

完整真实核后验数值、有限pair分裂、作者证明和独立审计另附。高精度求积不冒充区间证明；严格phi下界由上述解析积分给出。无PDF编译，无实际扣额数据。
