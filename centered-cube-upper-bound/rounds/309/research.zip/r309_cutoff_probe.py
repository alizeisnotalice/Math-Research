from fractions import Fraction as F
from math import comb,factorial
import json
assert sum((F(7,10)**j/F(factorial(j)) for j in range(4)),F(0))==F(12013,6000)>2
records=[];checks=0
for stage,ns in [('initial',(16,64)),('parameter_pressure',(128,256)),('expanded',(512,1024))]:
 for n in ns:
  coeff=[F(1) if k in (0,n) else comb(n,k)*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
  tails=[F(0)]*(n+1)
  for k in range(n-1,-1,-1):tails[k]=tails[k+1]+coeff[k+1]*F(9,10)**(k+1)
  for qH in (F(1,n*n),F(1),F(n*n)):
   K=next(k for k in range(n+1) if (n+1)*tails[k]<=F(1,64)*F(1,16)*qH)
   threshold=F(28,5)*(K+7)/n
   assert (n+1)*tails[K]<=qH/F(1024);checks+=1
   if threshold<=1:
    assert F(2)**K*(1-threshold/8)**n<=F(1,128);checks+=1
   records.append({'stage':stage,'n':n,'qH':str(qH),'K':K,'high_softness_threshold':str(threshold),'nonempty':threshold<=1})
remaining=1-F(64,3)*F(1,128)
assert F(2048,3)/remaining==F(4096,5) and F(64,3)/remaining==F(128,5)
print(json.dumps({'status':'PASS','checks':checks,'analytic_log_guard':'exp(7/10)>12013/6000>2','scope':'Exact sufficient K via An<=n+1,rho<=9/10,epsilon_degree1/64,eta_mid1/16. No fitted dimension exponent. Large threshold means empty high-softness branch.','records':records,'coefficients':['4096/5','128/5']},indent=2))
