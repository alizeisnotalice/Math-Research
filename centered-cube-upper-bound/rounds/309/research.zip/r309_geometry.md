# R309 — true shared-soft posterior geometry pays a new original positive component

## 1. Target, exact original remainder and the new payment

The target remains the general original source-linear root budget. It is NOT closed here. This note proves a new payment on the ACTUAL R308 remainder and constructs an explicit analytic shared receiver potential for that positive component. It does not restate the R308 LP or replace the remainder by the old full variance.

Fix the original outer data and keep the full sources, the fixed positive restriction nu_*<=nu, original q_-=3lambda/4<=q(x)<=lambda, a<=L(x),R(x)<=b<=2a, common actual softness s(x), original low-pe/m>M/full e_g, source/history and aspect qualifications, FIRST and SAME-R hard cap. All those quantities remain computed from the full original inputs. At each common binary level theta>0 write

    U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x),
    sigma_theta(x,y,z)=original binary qualified hard capture,
    0<=sigma_theta<=1{z in Q_R(x)(x)},
    J_y(t)=integral_{R(x)<=t}U_y(x)dx,
    A_theta(y,z;t)=integral_{R(x)<=t}U_y(x)sigma_theta(x,y,z)dx,
    p_theta=A_theta/J_y when J_y>0,
    chi_theta=1{J_y(t)>=H,p_theta<7/8},
    ell_n(dt)=b^(-n)delta_b(dt)+n t^(-n-1)1_(a,b)dt.

Here H=8d and d=kappa0 psi_inf/(q_-v0) are the ORIGINAL constants. The actual true soft-coordinate expansion is

    P_(s,L)=sum_(k=0)^n b_(n,k)(s)Q_(k,L),
    b_(n,k)(s)=binom(n,k)s^k(1-s)^(n-k).

Let K_* be EXACTLY the uniform cutoff already chosen in R308; it is not reoptimized by row or source. Distinguish this degree cutoff from the original constant K_orig in kappa0=2K_orig/(ell M). Put

    U_y,lo=alpha1_E/q sum_(k<=K_*) b_(n,k)(s)Q_(k,L),
    U_y,hi=U_y-U_y,lo.

The genuine R307 pair allocation M_theta(y,z,t,w,u) is retained, including all earlier gain/near/quiet/rapid/source/history masks. It obeys 0<=M_theta<=1. In every expression below the NONcapturing density remains the complete original U_y(u)[1-sigma_theta(u,y,z)], and J,chi,M are not recomputed.

For a capturing density V_y(w), define the positive pair functional with a prefix domain D by

    P_theta[D;V]=integral beta(dy)nu_*(dz)ell_n(dt)
       chi_theta 1_D/J_y(t)
       integral_{R(w),R(u)<=t} V_y(w)sigma_theta(w,y,z)
          U_y(u)[1-sigma_theta(u,y,z)]M_theta dwdu.       (1)

The zero-denominator case has chi=0. R308 leaves exactly

    R_old,theta=P_theta[p_theta<eta_mid;U]
                    +P_theta[eta_mid<=p_theta<7/8;U_lo]. (2)

Its high-degree middle-capture part has ALREADY been paid and is not charged again. The exact positive identity

    R_old,theta=P_theta[p_theta<eta_mid;U_hi]
                                    +P_theta[all;U_lo] (3)

is obtained by splitting ONLY the low-p capturing density in (2). Therefore this note can pay a UNION of low-p and middle-p low-degree capture once, without pretending all low-p traffic is small.

For epsilon in (0,1), define

    p_min(s)=s/(4-3s),
    D_(n,K_*)(s)=sum_(j=0)^(K_*) binom(n,j)
                              p_min(s)^j[1-p_min(s)]^(n-j),
    Gamma_epsilon={x:D_(n,K_*)(s(x))<=epsilon}.          (4)

Then the new genuine positive component satisfies

    0<=R_paid,theta:=P_theta[all;U_lo 1_Gamma_epsilon]
                                                    <=epsilon T_theta. (5)

It follows that R_old,theta=R_new,theta+R_paid,theta EXACTLY, where

    R_new,theta=P_theta[p_theta<eta_mid;U_hi]
                         +P_theta[all;U_lo 1_(Gamma_epsilon^c)]. (6)

The low-p high-degree contribution is fully retained. So are the full original bad endpoint, denominator, all radius atoms, M and chi in the second term. The new degree/softness statement concerns only the capturing endpoint.

A completely explicit sufficient subgate of Gamma_(1/128) is

    n s(x)>=(28/5)(K_*+7).                             (7)

Thus (5) can alternatively use this rational-threshold subgate alone. Using the sharper (4) only enlarges the paid set; its complement still satisfies n s<(28/5)(K_*+7). If the right side exceeds n, the sufficient subgate (7) is empty. This is not evidence against (4), which may still have points when K_*<n. If K_*=n then D=1 and (4) is empty for epsilon<1.

## 2. Pointwise posterior theorem for the TRUE common-soft kernel

Use the actual profile from R308:

    h=1_[-1/2,1/2], w(v)=integral_0^1 exp(-|v|/u)du,
    phi=h*w, f_s=(1-s)h+s phi.

Phi is positive, even and nonincreasing on [0,infinity). The last fact follows, for example, from phi'(x)=w(x+1/2)-w(x-1/2)<=0 for x>=0, with the usual integral interpretation at endpoints. On the hard interval,

    phi(x)>=phi(1/2)
      =integral_0^1 u[1-exp(-1/u)]du >=1/4.            (8)

Indeed exp(-1/u)<=exp(-1)<=1/2 for 0<u<=1, using e>=2, and integral_0^1 u/2 du=1/4. No fitted or modified soft profile is introduced.

At a fixed physical point v=(x-y)/L, suppose P_s(v)=product_i f_s(v_i)>0. The common-soft tensor expansion identifies independent latent soft/hard labels BEFORE conditioning on the point. Conditioning on this actual point preserves independence and gives soft-label probabilities

    pi_i=s phi(v_i)/[(1-s)h(v_i)+s phi(v_i)].          (9)

When h(v_i)=1, (8) and monotonicity of the fraction in phi imply

    pi_i>=s/(4-3s)>=s/4.

When h(v_i)=0 and P_s(v)>0, necessarily s>0 and pi_i=1. Thus EVERY posterior coordinate stochastically dominates Bernoulli(p_min(s)). This statement uses the same common actual s on all coordinates; it does not maximize coordinate softenings independently.

The exact ratio of the sum of degrees <=K_* to the full kernel is the probability that the sum of the independent posterior labels in (9) is <=K_*. Coordinatewise coupling therefore proves

    [sum_(k<=K_*) b_(n,k)(s)Q_k(v)]/P_s(v)
       <=D_(n,K_*)(s).                               (10)

The factor L^(-n) cancels. If P_s(v)=0, every positive component is zero; set the ratio to zero. This covers s=0 outside the hard cube. At s=0 inside the hard cube all posterior labels are zero. At s=1 all labels are one. Boundary hard indicators are taken with the same convention as the original cube; they do not alter the inequalities.

A simple exponential-moment estimate makes (10) explicit. If X is the sum of these posterior Bernoulli variables, then

    Pr(X<=K_*)<=2^(K_*) E[2^(-X)]
       =2^(K_*) product_i(1-pi_i/2)
       <=2^(K_*)[1-p_min(s)/2]^n
       <=2^(K_*)[1-s/8]^n
       <=exp(K_* log2-ns/8).                          (11)

The bound may exceed one; use its minimum with one if desired. Since

    exp(7/10)>1+7/10+(7/10)^2/2+(7/10)^3/6
              =12013/6000>2,

one has log2<7/10. Under (7), (11) is at most 1/128. More generally

    ns>=8[K_* log2+log(1/epsilon)]                     (12)

is a sufficient condition for membership in Gamma_epsilon. These thresholds are derived analytically, not inferred from numerical fits.

## 3. Exact original pair payment; no component FIRST or altered bad endpoint

Applying (10) at the actual (x,y,s(x),L(x)), and multiplying by the original alpha1_E/q, gives the pointwise inequality

    U_y,lo(x)1_Gamma_epsilon(x)<=epsilon U_y(x)         (13)

for EVERY y and actual receiver x. It does not require an independent FIRST for Q_k or for an unweighted soft component. It is valid even when a single latent component by itself would violate a hypothetical component cap.

At fixed original y,z,t, define the paid capturing prefix

    A_paid=integral_{R(w)<=t}U_y,lo(w)1_Gamma_epsilon(w)
                                      sigma_theta(w,y,z)dw.

Then A_paid<=epsilon A_theta. Drop only the positive upper mask M<=1 AFTER keeping its original values in the paid component. The pair integral in (1) divided by J is at most

    A_paid[J-A_theta]/J
          <=epsilon A_theta[J-A_theta]/J<=epsilon A_theta. (14)

Integrating gives (5), since the exact original target identity is

    integral beta nu_* ell_n A_theta=T_theta.

The union in (3) uses all original p<7/8 levels once. There is no second epsilon for the low-p and middle-p pieces: they occupy disjoint prefix domains before recombination. The separate R308 high-degree middle receipt is unchanged. Averaging the common theta with total measure one proves

    R_old=R_new+R_paid, 0<=R_paid<=epsilon T.            (15)

All zero rows, selected-radius atoms and source/history qualifications are preserved. This is a positive component split, not a subtraction of two nonmonotone variance expressions. The proof uses actual dx throughout.

## 4. An explicit analytic shared receiver potential and its source price

The proof of (14) works separately for every y before beta integration. Let R_paid,y and T_y be their original common-theta averages. Then

    R_paid,y<=epsilon T_y.

Consequently the ORIGINAL actual hard response gives an explicit shared potential

    P_epsilon(x)=epsilon 1_E(x)[h_(R(x))*nu_*](x).      (16)

It is independent of y, and

    R_paid,y<=integral U_y(x)P_epsilon(x)dx.            (17)

Indeed the qualified hard response inside T_y is bounded by h_R*nu_*; no original gate is recomputed. This is a genuine analytic instance of the R308 signed-FIRST certificate with zero beta fee for this positive component. Applying the SAME original FIRST once and then the legal finite hard-scale envelope yields

    R_paid<=integral_E P_epsilon(x)dx
                       <=epsilon A_n W_nu*.           (18)

The potential is not an assumed density cap. Its column mass is paid by the integral of the actual selected hard kernel, bounded by its scale envelope; nu_* is charged once after all rows and scales. The same-R hard cap also ensures P_epsilon<=4lambda epsilon on E, but this pointwise fact alone is not used to infer a finite source cost.

Choose, for example, epsilon=min(1/128,A_n^(-1/2)). The exact posterior gate (4), or the sufficient threshold (12), then gives

    R_paid<=sqrt(A_n) W_nu*.                           (19)

This is a source-linear root payment for the newly identified positive component on arbitrary original inputs, with no beta-density assumption or spatial source separation. It is not a root bound on R_new. Alternatively use (15) for internal T absorption; (18) and (15) are alternative receipts for the same component and are not spent twice.

## 5. Original full budget and the remaining actual geometry

The already audited R308 entry, AFTER its own middle/high-degree payment, is

    Lambda T<=(2048/3)Lambda lambda d W_beta
                                +(64/3)Lambda R_old.

With epsilon=1/128 in (15), the new internal expense is Lambda T/6. Hence

    Lambda T<=(4096/5)Lambda lambda d W_beta
                                +(128/5)Lambda R_new. (20)

Here lambda d=(4/3)kappa0 psi_inf/v0 and kappa0=2K_orig/(ell M). Every original aspect, low-m, q and outer multiplier cost is retained. An epsilon smaller than 1/128, as in (19), permits the same displayed upper coefficients. The finite-target absorption is legitimate because original FIRST gives T<=A_nW_nu*. This is not a newly asserted absorption into lambda|E| or proof of a missing global entry.

R_new is EXACTLY the sum in (6):

* low-p high-degree capturing traffic, with all actual softness values;
* low-degree capturing traffic at every original p<7/8, on the complement of (4), hence in particular ns<(28/5)(K_*+7) for the fixed epsilon=1/128.

The noncapturing endpoint remains unrestricted full U in both terms. Its source/history failures, J, M, chi, rare-scale and atom phenomena are unchanged. The original R308 cutoff K_* depends on n, eta_mid, its tail tolerance and q_-H; no new polynomial lower bound on q_-H is assumed. If those parameters imply K_*=O(log n), then the SECOND capturing endpoint has ns=O(log n), but the first term remains and no whole-input small-softness conclusion follows. If K_*=n the posterior payment is empty and the proof accurately reports that fact.

## 6. Original low height forces a precise remaining coordinate-exterior condition

This auxiliary consequence records the actual height/geometry interaction without claiming to pay the exterior sectors. It uses the two previously audited ORIGINAL point heights, valid on original positive target support:

    p_y(x)<=kappa0 (LR)^(-n/2),
    p_y(x)<=kappa0 G L^(-n/4)R^(-3n/4), G=gamma^(n/2).

Thus

    L^n p_y(x)<=tau(L/R),
    tau(t)=kappa0 min(t^(n/2),G t^(3n/4)).              (21)

No orientation or inverse-aspect factor has been discarded. If all coordinates satisfy |x_i-y_i|<=L/2, (8) gives

    L^n p_y(x)=product_i[1-s+s phi((x_i-y_i)/L)]
                                         >=(1-3s/4)^n. (22)

For a surviving low-degree capture at epsilon=1/128, let S=(28/5)(K_*+7) and s_bar=min(1,S/n). Then s<=s_bar. If

    tau(L/R)<(1-3s_bar/4)^n,                           (23)

(21),(22) exclude the all-hard-coordinate interior. Moreover if MORE than K_* coordinates have |x_i-y_i|>L/2, the low-degree density is identically zero: every such coordinate forces a soft label in the exact expansion. Under (23), any nonzero surviving low-degree capture therefore has between 1 and K_* exterior hard coordinates.

These are coordinate-exterior sectors, not thin sets endowed with a density cap; the exterior coordinates may be arbitrarily far away, and the number of possible coordinate sets has not been paid. Conditions (21)–(23) do not bound the residual by a source root price. They identify the next actual geometric obstruction after the new payment: a small-actual-softness, low-degree capturing endpoint, coupled to the full bad endpoint and all original history. Treating this as a free low-dimensional problem would drop both coordinate multiplicity and the retained bad endpoint, and is not licensed.

## 7. Actual bounded diagnostics and reproduction

A fresh local Fraction run checked the exact tensor/posterior identity for 52 positive-profile cases, 247 stochastic binomial-CDF dominations, 12 zero-profile cases, 60 forced-degree zeros, and 24 nonvacuous rational-threshold payments. It also checked the exact rational exponential lower sum 12013/6000>2. The points use inside phi values in [1/4,1] and positive outside values; these algebraic tests exercise the proved profile inequalities, not a claim that every chosen rational tuple is realized by actual phi at specified points. The TRUE phi bound is proved analytically in (8). The diagnostic does not establish the unpaid source-root estimate. The reproduction writes no files:

```python
from fractions import Fraction as F
from itertools import product
from math import comb
ct={'posterior_identity':0,'uniform_cdf':0,'zero_profile':0,
    'forced_degree':0,'rational_threshold':0,'exp_lower':0}
for n in (1,2,4,8):
 for s,kind in product((F(0),F(1,4),F(3,4),F(1)),range(4)):
  hard=[int(not(kind and i<min(kind,n))) for i in range(n)]
  phi=[(F(1,4),F(1,2),F(3,4))[i%3] if hard[i] else F(1,5+i) for i in range(n)]
  coeff=[F(1)]
  for hi,ph in zip(hard,phi):
   aa=(1-s)*hi;bb=s*ph;nxt=[F(0)]*(len(coeff)+1)
   for j,v in enumerate(coeff):nxt[j]+=aa*v;nxt[j+1]+=bb*v
   coeff=nxt
  P=sum(coeff)
  if not P:
   assert all(v==0 for v in coeff);ct['zero_profile']+=1;continue
  probs=[s*ph/((1-s)*hi+s*ph) for hi,ph in zip(hard,phi)]
  post=[F(1)]
  for pp in probs:
   nxt=[F(0)]*(len(post)+1)
   for j,v in enumerate(post):nxt[j]+=(1-pp)*v;nxt[j+1]+=pp*v
   post=nxt
  assert all(coeff[j]/P==post[j] for j in range(n+1));ct['posterior_identity']+=1
  pmin=s/(4-3*s)
  for K in range(n+1):
   cdf=sum(post[:K+1])
   lower=sum(F(comb(n,j))*pmin**j*(1-pmin)**(n-j) for j in range(K+1))
   assert cdf<=lower;ct['uniform_cdf']+=1
   if sum(1-v for v in hard)>K:
    assert cdf==0;ct['forced_degree']+=1
for n,K,s in product((32,128,1024),(0,1,4,16),(F(1,10),F(1,2),F(3,4),F(1))):
 if n*s>=F(28,5)*(K+7):
  assert F(2)**K*(1-s/8)**n<=F(1,128);ct['rational_threshold']+=1
lower=sum(F(7,10)**j/F((1,1,2,6)[j]) for j in range(4))
assert lower==F(12013,6000)>2;ct['exp_lower']+=1
print('PASS',ct)
```

Only /tmp/r309_geometry.md was written. No other author's file, earlier frozen proof or Git state was modified.
