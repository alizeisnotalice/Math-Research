from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(2)]
profiles=[[F(1,10),F(1,5),F(2)],
          [F(1),F(1,100),F(1,2)],[F(1,3)]*3]
ct_rank=ct_low=0
for n,U,f in product([1,2,8,32],profiles,product([0,1],repeat=3)):
 J=[sum(U[:i+1]) for i in range(3)]
 A=[sum(U[j]*f[j] for j in range(i+1)) for i in range(3)]
 w=[R[i]**(-n)-(R[i+1]**(-n) if i<2 else 0) for i in range(3)]
 for tau in [F(1,100),F(1,10),F(1,2),F(1),F(2)]:
  stopped=[sum(U[j]*f[j] for j in range(i+1) if A[j]<tau)
           for i in range(3)]
  direct=sum(U[i]*f[i]*R[i]**(-n) for i in range(3) if A[i]<tau)
  assert direct==sum(w[i]*stopped[i] for i in range(3))
  assert all(stopped[i]<=min(A[i],tau) for i in range(3))
  assert direct<=sum(w[i]*min(A[i],tau) for i in range(3))
  ct_rank+=1
 for eta in [F(1,8),F(1,4),F(1,2)]:
  tau=eta*J[-1]
  low=sum(w[i]*A[i]*(1-A[i]/J[i])
          for i in range(3) if A[i]/J[i]<eta)
  rank=sum(U[i]*f[i]*R[i]**(-n) for i in range(3) if A[i]<tau)
  assert low<=rank
  ct_low+=1
print('PASS',dict(capture_rank_atom_checks=ct_rank,
                 lowp_containment_checks=ct_low))  # actual: 480, 288
