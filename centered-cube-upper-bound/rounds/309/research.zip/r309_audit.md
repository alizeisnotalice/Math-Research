# R309 independent preauthor audit

Independent screen: PASS for the proposed pointwise posterior-tail payment and its precise positive residual insertion. This section was saved before reading any new R309 author proof.

## True profile and exact latent identity

Use the ORIGINAL h=1_[-1/2,1/2], normalized w(t)=integral_0^1 exp(-|t|/v)dv and phi=h*w. The profile phi is positive, even and nonincreasing on [0,infinity), since w has these properties. Also phi<=1 because h<=1 and integral w=1. Hence on |u|<=1/2,

phi(u)>=phi(1/2)=integral_0^1 v(1-exp(-1/v))dv >=(1-exp(-1))/2>1/4.

The last strict inequality follows already from e>2. On a coordinate with h(u)=0 and positive mixture f_s(u), the latent softness posterior is exactly one. Inside the hard interval it is pi=s phi/(1-s+s phi)>=s/4, since the denominator is at most one. Boundary conventions h=1 at |u|=1/2 are consistent; if another a.e. boundary representative sets h=0, the outside posterior case still works.

At P_s,L(x-y)>0, the positive product expansion defines INDEPENDENT posterior Bernoulli variables, one per coordinate, with those actual pi_i. Their degree N obeys exactly P_<=K/P=Pr(N<=K), using the ACTUAL common-soft binomial weights (not coefficient envelopes or independent coordinate maximizations). If P=0, every nonnegative component vanishes and U_lo=U=0, so the desired inequality is automatic without defining a ratio. At s=0 positive P requires every hard coordinate; pi=0 and low degree ratio is one. At s=1 every pi=1, so N=n exactly. K=n has ratio one and therefore cannot generate a nonempty high-softness gate at epsilon<1.

Markov at 2^-N gives

Pr(N<=K)<=2^K product_i(1-pi_i/2)<=2^K exp(-sum_i pi_i/2)<=2^K exp(-ns/8).

Consequently ns>=8[K ln2+ln(1/epsilon)] implies U_lo<=epsilon U pointwise at the ACTUAL original receiver and source, for all normalized coordinates. This is an identity/inequality for the original positive expansion, not a new latent random choice in the original history. If alpha=0, x outside E or P=0 the row inequality remains zero trivially. No component FIRST or density assumption is involved.

## Positive insertion in the exact R308 remainder

Keep the entire R308 low-p term all-soft. In the original-middle retained low-degree term, split ONLY its already-low-degree capturing anchor by the actual high-softness gate. On that gate U_lo<=epsilon_s U. Original bad-receiver density, missed capture, full J, all original prefix/rho/quiet/rapid/history masks and common-theta weights remain fixed. Its high-softness positive subfee is bounded per prefix by epsilon_s A(J-A)/J<=epsilon_s A, hence totals <=epsilon_s T. The retained low-degree/low-actual-softness capturing term is still coupled to a FULL original bad receiver. No old paid branch is charged twice and no low-p cutoff is silently granted.

The original candidate epsilon_s=3/256 gives 1-(64/3)epsilon_s=3/4, and coefficients 8192/9 and 256/9 after inserting in the R308 entry. The main adopted alternative is epsilon_s=1/128, giving denominator 5/6 and coefficients 4096/5 and 128/5. Both follow from the same unchanged R308 source/incidence coefficients 2048/3 and 64/3. Original Lambda occurs once and all inverse aspect/height costs remain. This is internal finite-T absorption, ZERO new original-X error, not global event absorption.

## Adopted rational high-softness gate

The exact positive Taylor sum through degree3 at 7/10 is 12013/6000>2, so exp(7/10)>2 and ln2<7/10. Therefore the purely rational gate

ns >= (28/5)(K+7)

implies ns/8>=(7/10)(K+7)>ln2(K+7), and the posterior bound is <=2^-7=1/128. A threshold exceeding n means the high-softness branch is EMPTY. In particular K=n yields no automatic payment. The actual softness cutoff is O(K+1), and is polylogarithmic only under whatever proved parameter conditions make the inherited R308 K polylogarithmic; no upstream legal parameter can be chosen freely.

## Actual bounded diagnostics and scope

Executed 55-digit local real-phi quadrature and posterior product-expansion diagnostics: 229 positive-kernel degree cases, 11 zero-kernel corners, 15 nonempty rational-high-softness tests; all PASS. Profile values used the actual h*w integral (with inside/outside formulas), not a surrogate kernel. Separately executed the exact degree3 Taylor comparison and adopted coefficient arithmetic using Fraction. Numerical quadrature/product evidence does not replace the analytic profile, posterior and Markov proofs above and does not realize the full original low/e/m/history field.

Remaining gap: general original-source root pricing of all-low-p traffic and the retained low-degree/low-softness capturing endpoint against the full original noncapture endpoint, plus the independent original source/aspect/outer/entry ledger obligations. No general root theorem, all-input coverage fraction, or new global epsilon X is asserted.

## Additional independent screen: combine the low-degree part across ALL original p gates

The adopted stronger primary allocation starts from the exact R308 remainder R_lowp(U_full)+R_mid(U_lo). Split R_lowp positively into high- and low-degree capturing anchors; combine its low-degree part with the middle low-degree part. The original prefix predicates p<eta_mid and eta_mid<=p<7/8 are disjoint and exhaust the original chi gate, so the resulting all-p low-degree component has ONE common pair mask M<=1, with original full J and full bad receiver. Split its capturing endpoint by actual high softness. Pointwise U_lo 1_high<=epsilon_s U yields a single prefix bound epsilon_s A(J-A)/J<=epsilon_s A and hence ONE epsilon_s T for the UNION, not two copies.

The exact new unpaid allocation is R_lowp,high-degree + R_allp,low-degree,low-actual-softness. The previous middle-high-degree payment is not spent again. Low-p high degree remains entirely unpriced. Capturing degree and actual softness are restrictions on ONE endpoint only; the noncapture endpoint retains all degrees, scales and original qualification. Actual Fraction checks of 144 disjoint-low/middle prefix allocations and high-softness coefficients PASS.

## Actual shared-potential source receipt for the paid component

The same proof is valid row by row before beta integration: Paid_y<=epsilon_s T_y<=integral U_y(x)P_shared(x)dx, with P_shared=epsilon_s 1_E(h_R(x)*nu_*)(x). This uses the ACTUAL selected R on E and hard qualification <=geometric capture. Thus it is an explicit feasible signed certificate with C_beta=0 for this paid positive component, costing integral_E P_shared<=epsilon_s A_n W_nu*. It does not construct a root-priced certificate for the unpaid complement. Taking epsilon_s=min(1/128,A_n^-1/2) gives a root source receipt for the corresponding component ONLY, and requires adjusting the high-softness gate to that epsilon_s. The fixed rational K+7 gate belongs specifically to epsilon_s=1/128; a smaller epsilon_s needs a larger log threshold (or an appropriate integer dyadic exponent). Source receipt and internal absorption are alternatives for the same component.

## Independently screened auxiliary support structure

Inside the original hard soft-coordinate cube Q_L(y), every mixture factor is >=1-3s/4, so full p_y L^n>=(1-3s/4)^n. Original low-pe/high-m support heights give p_y L^n<=kappa0 c_j^(n/2)(L/R)^(n/2), and also the audited weaker all-orientation upper bound kappa0 min((L/R)^(n/2),G(L/R)^(3n/4)). Incompatible inequalities exclude that interior original traffic, retaining kappa0/ratio costs. This is support exclusion, not a source-mass budget. A nonzero retained degree<=K term has at most K coordinates outside Q_L(y), because each outside hard coordinate must be selected soft. Such exterior sparsity does not pay its faces or boundary mass, nor the full bad endpoint.

## Author comparison: low-capture attempt and support structure

Read `/tmp/r309_low_capture.md`, SHA256 `ef3c049492a608a0cf2bb853d5a7a230ff7d85854d235d3d883b03e710f2a80f`. PASS in its explicitly limited scope. The original low-p prefix forces A(R_anchor)<eta J_star, and the strict inclusive-postjump rank excludes the whole crossing atom. The stopped cumulative identity, domination by min(A,tau), and sharp scalar clipped/Poisson comparison are correct. The dyadic strata are disjoint, so their tail error costs one epsilon T, but the full clipped-capacity remainder and uncontrolled K=n depth remain unpaid. This auxiliary correctly records a failed extension to a general root low-p payment.

The true phi interior lower bound and original height comparison retain all original kappa0, ratio and actual-band factors; they only exclude incompatible support. The at-most-K outside-coordinate support statement holds for the capturing low-degree component and grants no source mass or boundary payment. It is not extended to the full bad receiver or to low-p high-degree traffic. Actually executed the embedded reproduction: 480 exact rank/atom and 288 low-p containment checks PASS. These are finite incidence diagnostics, not complete original histories.

## Author comparison: actual shared-soft posterior and union payment

Read `/tmp/r309_geometry.md`, SHA256 `94ed934034b0716974e4a671121d1e9bca815d1f2c5826a7f4fa9c15fa2d0edb`. PASS for (1)-(23), retaining the original R308 row-gate/FIRST interface. Exact posterior identity, stronger uniform p_min=s/(4-3s), outside forced-soft coordinates, P=0 and s endpoints are correct. Uniform binomial-CDF Gamma is a legitimate sufficient gate for the same pointwise low-degree inequality; the rational ns gate is a SUBGATE, not an equivalent threshold. Its empty-subgate case does not imply Gamma empty unless K=n.

The whole-low-degree union is positively recombined across disjoint original p predicates before charging one epsilon T. Full bad U, original J/chi/M and original degree cutoff stay fixed. Source potential (16) is shared across y and provides a real analytic signed certificate for the new PAID component, not for its complement. Its epsilon A_n W_nu source receipt and finite-T absorption are alternatives. Epsilon=min(1/128,A_n^-1/2) uses its adjusted Gamma/threshold; the fixed K+7 small-softness conclusion in the last support section is expressly for epsilon=1/128. The source/incidence coefficients 4096/5 and 128/5 are correct.

The full-height interior exclusion and at-most-K exterior support are conditional structure, not a source price; original ratios/height parameters and the full bad endpoint remain. Actually executed the fresh embedded Fraction reproduction: 52 posterior identities, 247 binomial dominations, 12 P=0 corners, 60 forced-degree zeros, 24 rational-threshold payments, and one exact exponential lower sum, all PASS. Chosen rational phi tuples are explicitly algebraic tests, not all actual sampled phi values or original full histories.

## Numeric-code and scope inspection

Read `/tmp/r309_numeric.py` and its note. The exact coefficient DP is compared to subset expansion; the rational binomial CDF uses integer binomial-term recurrence with its p=0,p=1,K>=n corners guarded. Coefficient division occurs only for P>0. The stochastic and rational Markov chains have the correct direction, and a bound above one is explicitly marked vacuous. The real phi formula 1-E3(1/2+x)-E3(1/2-x) is used only inside the hard interval and compared against the true scale integral at 40/60 digits. It is ordinary high precision, not interval arithmetic; analytic phi inequalities supply the proof. Rational tensor tuples are not all claimed actual kernel samples.

The fixed-full-bad flow fixture tests one combined lowp/middle epsilon payment at epsilon=1/16. It is explicitly finite conditional algebra, not a complete original kernel/history sample or a claim that its chosen low-degree fractions are physical profile values. The primary rational gate at epsilon=1/128 is supported separately by the analytic theorem and author threshold checks; these parameter choices must not be conflated. No component FIRST is used.

Completed numeric artifact: 925 checks, status PASS, empty failures; SHA256 `6ab349758f1c882d91ba4da9d3dba2e8efd254dfe34a6bfe22781ef0f3e94268`. This audit inspected the code/output and performed the independent true-phi diagnostics recorded above; it did not unnecessarily rerun the full n=4096 artifact sweep. Main cutoff probe has 22 exact checks and status PASS; SHA256 `e1851971919ff9ad4e02e42be9a5272f8ce1ba4343fa146123411871b071f9ee`. Its degree/mass-parameter examples and empty high-s gates are finite conditional data, not fitted dimension asymptotics or a general root proof.

## Final integration verdict — frozen

PASS. Read the final main combined note, README and static TeX without compilation. Primary integration uses the CONSERVATIVE rational gate G_K at epsilon=1/128; the author's sharper binomial-CDF gate is a separately justified alternative and is not silently substituted into the primary residual. The exact all-p low-degree union is paid ONCE, while the low-p high-degree term and low-degree small-actual-softness term remain with the complete full noncapture endpoint, original J, every predicate and common-theta/source weight. No previously paid middle-high-degree, far-loss, quiet or rapid component is charged again.

The R308 coefficients 2048/3 and 64/3 give internal expense T/6; the final coefficients 4096/5 and 128/5 are correct. Lambda occurs once, all inverse-aspect/height costs remain, and new global-X error is ZERO. The analytic shared potential epsilon 1_E h_R*nu_* is valid for the PAID component row by row; its epsilon A_n W_nu source price is an ALTERNATIVE to internal absorption. If epsilon is reduced to min(1/128,A_n^-1/2), the gate and component are correspondingly adjusted. The fixed K+7 gate is not used unchanged for a smaller epsilon.

The final tau in main/TeX is the minimum of the actual unique-band height and the audited all-orientation height, applied only where BOTH original heights hold. Neither kappa0, actual c_j nor L/R is freely chosen. Interior exclusion and 1..K exterior-coordinate support are conditional geometric information, not source payment or a free sum over coordinate faces. K may equal n; an empty rational gate is explicitly reported. No entire-input small-softness or low-dimensional conclusion is asserted.

Final SHA256 bindings (large numeric JSON are external reproducible results, not promised inside the ZIP):

- `/tmp/r309_geometry.md`: SHA256 `94ed934034b0716974e4a671121d1e9bca815d1f2c5826a7f4fa9c15fa2d0edb`.
- `/tmp/r309_low_capture.md`: SHA256 `ef3c049492a608a0cf2bb853d5a7a230ff7d85854d235d3d883b03e710f2a80f`.
- `/tmp/r309_combined.md`: SHA256 `b3e9be2441e02a6767e585573620d81afd82fd172623d0fb8c73aa504b0218a4`.
- `/tmp/r309_README.md`: SHA256 `1a47c90ec3d743233e6f449411a7741697cf7f5312ebad7a745e533d03f33347`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/research.tex`: SHA256 `1e05b9ea59617c11943f743ca112751173df3deacb1552b421c5c5c929f524f4`.
- `/tmp/r309_numeric.md`: SHA256 `2c9b640741534b1e045312da0828fd7b64a09fcad3cac8a4751be998104e181c`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/geometry_checks.py`: SHA256 `728ddb4addddd409698f451d865a49e8b9fee7b66ab87db9c4c487bd036c1d99`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/low_capture_checks.py`: SHA256 `3a99a5c0cca92c8aff1eaf750bc6d0b61989202e8afbfe1be2e36f5d3ecd28d4`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/r309_cutoff_probe.py`: SHA256 `9e44fe325945dd479fbca1666965b7efe52925d5c9de5f767a8512d0229d5fde`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/r309_numeric.py`: SHA256 `7117a86c8f8430f70bc497fd1cd0b95676388a827e8125da9526df4c16eac503`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/r309_cutoff_probe.json`: SHA256 `e1851971919ff9ad4e02e42be9a5272f8ce1ba4343fa146123411871b071f9ee`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/r309_numeric.json`: SHA256 `6ab349758f1c882d91ba4da9d3dba2e8efd254dfe34a6bfe22781ef0f3e94268`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/geometry_checks.log`: SHA256 `e5a46af3d104028dc36dd40e8ca71a9ca0752f07edbbd3f311d1519d36543b2b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/low_capture_checks.log`: SHA256 `81a6dd6c5151249b34c6d096e89ba4fa478a48e7734a128db90f773deb529e6b`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round309_20261018_final_checkpoint/numeric_checks.log`: SHA256 `79270905c6a98dadc8ad2c8667ebfe12c9151e3415ab22b2c53cf634b3d20def`.

Staged numeric/cutoff code and outputs are byte-identical to the frozen /tmp originals. Completed numeric artifact: 925 PASS, empty failures, comprising 890 exact rational checks and 35 ordinary high-precision phi checks. Its finite flow epsilon=1/16 is a general-interface diagnostic, not mislabeled as the primary epsilon=1/128 test. Cutoff artifact: 18 parameter configurations and 22 counted exact checks, including empty rational gates. Parent reports fresh process reruns; observed logs/data support the reported status. This audit independently executed the author posterior/threshold block (52/247/12/60/24/1), auxiliary rank block (480/288), actual true-phi posterior checks and exact arithmetic recorded above, without unnecessarily repeating the large-n full numeric sweep.

Exact remaining gap: general original-source root pricing for low-p high-degree capturing traffic and retained low-degree/small-actual-softness capturing traffic against the FULL original bad endpoint and history. The low-capture rank/dyadic attempt only returns the old unpaid clipped capacity; it is not counted as a new payment. Independent original entry, source outer integration, extreme aspect, wide/suffix, initial/deletion/future and complete error-adoption obligations remain. No global weak-type closure is claimed. Only this audit file was modified; no author, repository, TeX or PDF files were edited and no PDF was compiled. This receipt is frozen.
