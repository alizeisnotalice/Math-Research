# R309 — low capture reaches the existing clipped-capacity gap

## 1. Scope and outcome

Keep the exact R307 binary residual, its original full-soft U_y, selected fields, full-source qualifications, sources beta,nu_*, J_y,A_yz,p=A/J, and original ell_n. Its oriented form has captured endpoint w, noncaptured endpoint u, the ORIGINAL J>=H,p<7/8 gate and a fixed multiplier 0<=M<=1. No gate is recomputed componentwise. Original FIRST and SAME-radius hard caps remain available only at their original receivers.

No new all-source root payment for p<eta is established here. The bounded attempt yields an exact rank containment and a finite no-copy stratification, but the former returns the already existing clipped-capacity budget and the latter has uncontrolled degree depth. These are recorded as the precise failed extension, not renamed as a new payment.

## 2. Exact low-p capture-rank containment, including atoms

The original full-soft envelope supplies the uniform row bound

    J_y(r)<=I_y<=J_star=A_n Csoft_n/q_-,
    A_n=1+n log(b/a), Csoft_n=sum_(k=0)^n c_(n,k).

This uses the actual common-soft envelope, not component FIRST. Fix eta>0 and put tau=eta J_star. On an oriented residual prefix with p_yz(r)<eta, every capturing anchor w in that prefix satisfies

    A_yz(R(w))<=A_yz(r)<eta J_y(r)<=tau.

After dropping M<=1 and using noncapturing-prefix mass divided by J<=1, positive Tonelli therefore gives

    R_lowp<=T_rank(tau),
    T_rank(tau)=integral beta(dy)nu_*(dz)
       integral_[a,b] t^(-n)1{A_yz(t)<tau}dA_yz(t).    (1)

The cumulative A is inclusive. The ENTIRE atom that reaches or crosses tau is excluded by the strict post-jump gate in (1). No fractional part of that atom is invented.

Define its genuine stopped capture cumulative

    A^<tau_yz(r)=integral_[a,r]1{A_yz(t)<tau}dA_yz(t).

Then A^<tau(r)<=min(A(r),tau), and ell_n([t,b])=t^(-n) gives

    T_rank(tau)=integral beta nu_* ell_n A^<tau
       <=O_tau:=integral beta(dy)nu_*(dz)ell_n(dr)
                                             min(A_yz(r),tau). (2)

This is exactly the old qualified clipped-capacity family, at parameter tau; it is not a newly paid source norm. If C_t=integral beta nu_* ell_n[1-exp(-tA)], the sharp scalar clip/Poisson comparison also gives

    O_tau<=tau C_(1/tau)/(1-exp(-1)).                  (3)

It follows by comparing min(u,1) with [1-exp(-u)]/[1-exp(-1)] for u>=0. A sharp scalar constant is not an integrated source payment.

The available unconditional source-linear alternatives remain the old ones:

    O_tau<=T<=A_n W_(nu_*),
    O_tau<=T<=4lambda integral I_y beta(dy).           (4)

Neither improves to root order merely because tau is small. Replacing min(A,tau) by tau and then integrating beta nu_* would introduce the forbidden unpriced two-source product. SAME-radius hard caps do not settle how many different sources acquire their first tau of capture at different actual receivers.

For a fixed finite input O_tau tends to zero as tau decreases to zero by dominated convergence, using min(A,tau)<=A and finite T. Choosing a data-dependent tiny tau can thus remove low capture pointwise, but gives no uniform lower bound on eta and no uniform degree cost. This convergence is not a root theorem.

## 3. Dyadic p strata have no source copies, but unbounded depth

For l=0,...,L partition p in [eta 2^(-l-1),eta 2^(-l)); retain the complete deeper part p<eta 2^(-L-1). At each stratum use the actual R308 component decomposition, with a cutoff K_l satisfying

    S_(n,K_l)(rho_bar)
              <=epsilon eta 2^(-l-1)q_-H/A_n.         (5)

Only the CAPTURING component is split. The noncapturing U, miss factor, M, original J and original full-p gates remain unchanged. R308 gives a positive high-degree stratum expense <=epsilon integral_stratum A d(beta nu_* ell_n). These prefix strata are disjoint, so their total expense is <=epsilon T; it is not (L+1) source fees.

Consequently the exact finite bookkeeping is

    R_lowp<=R_(finite strata,low capturing degree)
                     +epsilon T+O_(eta 2^(-L-1)J_star). (6)

The final capacity in (6) has NOT been paid. The degree cutoffs grow with l and can reach n: since c_(n,n)=1, K_l=n exactly when

    rho_bar^n>epsilon eta 2^(-l-1)q_-H/A_n.

No lower positive capture intensity or uniform stopping depth is supplied by the existing original gates. Thus infinitely refining (5), or choosing L large enough for fixed-input convergence in (2), can leave the full n-degree problem. It does not materially settle low capture.

An additional actual source-capacity estimate for O_tau, with a quantitative rate allowing a controlled eta, is the precise missing bridge. It must retain original FIRST, capture overlap and qualification and cannot use arbitrary source boundary density. All formulas above multiply by the original incidence coefficient and Lambda once; there is no free global absorption entry or source copy. This auxiliary produces no new root-priced low-p branch beyond R308.

## 4. Actual minimal exact checks

A standard-library Fraction run passed 480 atom/rank checks and 288 low-p containment checks. It retained post-jump strictness and terminal scale atoms. These finite incidence tests validate the algebra, not a new original-kernel realization or source estimate. Reproduction:

```python
from fractions import Fraction as F
from itertools import product
R=[F(1),F(3,2),F(2)]
profiles=[[F(1,10),F(1,5),F(2)],
          [F(1),F(1,100),F(1,2)],[F(1,3)]*3]
ct_rank=ct_low=0
for n,U,f in product([1,2,8,32],profiles,product([0,1],repeat=3)):
 J=[sum(U[:i+1]) for i in range(3)]
 A=[sum(U[j]*f[j] for j in range(i+1)) for i in range(3)]
 w=[R[i]**(-n)-(R[i+1]**(-n) if i<2 else 0) for i in range(3)]
 for tau in [F(1,100),F(1,10),F(1,2),F(1),F(2)]:
  stopped=[sum(U[j]*f[j] for j in range(i+1) if A[j]<tau)
           for i in range(3)]
  direct=sum(U[i]*f[i]*R[i]**(-n) for i in range(3) if A[i]<tau)
  assert direct==sum(w[i]*stopped[i] for i in range(3))
  assert all(stopped[i]<=min(A[i],tau) for i in range(3))
  assert direct<=sum(w[i]*min(A[i],tau) for i in range(3))
  ct_rank+=1
 for eta in [F(1,8),F(1,4),F(1,2)]:
  tau=eta*J[-1]
  low=sum(w[i]*A[i]*(1-A[i]/J[i])
          for i in range(3) if A[i]/J[i]<eta)
  rank=sum(U[i]*f[i]*R[i]**(-n) for i in range(3) if A[i]<tau)
  assert low<=rank
  ct_low+=1
print('PASS',dict(capture_rank_atom_checks=ct_rank,
                 lowp_containment_checks=ct_low))  # actual: 480, 288
```

## 5. Conditional small-softness support structure, not a payment

For the MAIN author's separately paid high-actual-softness removal, the following checks what the remaining small softness can force geometrically. It does not assume or reprove that payment. The true phi is even and decreasing away from zero, and

    min_(|t|<=1/2)phi(t)=phi(1/2)
       =integral_0^1 u[1-exp(-1/u)]du
       >=[1-exp(-1)]/2>1/4.

Thus if the ACTUAL point x lies inside Q_L(y), then

    p_y(x)L(x)^n>= [1-3sigma(x)/4]^n.                 (7)

On the ORIGINAL low-pe,m>M qualified support the actual low-height bound gives

    p_y(x)L(x)^n
       <=kappa0 c_j^(n/2)(L(x)/R(x))^(n/2)
       <=kappa0(L(x)/R(x))^(n/2).                     (8)

Here kappa0=2K/(ell M), and c_j<=1 is the ACTUAL unique-band coefficient. In particular whenever

    kappa0(L/R)^(n/2)<[1-3sigma/4]^n,                (9)

the ORIGINAL qualified target has no inside-Q_L(y) support. If sigma<=sigma0<=1 is already established, the stronger uniform sufficient condition replaces the right side by [1-3sigma0/4]^n. One may retain the actual c_j factor in (8) for a sharper condition; it is never freely chosen. Neither kappa0 nor L/R is discarded, and the original aspect price is unchanged. If (9) fails there is no conclusion that inside traffic is small.

For a retained capturing component of degree k<=Kcap, its exact product support has at most Kcap coordinates with |x_i-y_i|>L/2: each such coordinate must be one of its genuinely soft coordinates, since h vanishes there. Consequently, WHEN the independently verified small-softness condition and (9) both hold, the low-degree capturing endpoint is outside its source cube in at least one and at most Kcap coordinates. This is a statement about actual receiver/source support, not a fixed-convolution replacement or a cap on source boundary mass. All original gates are evaluated using the full kernel, including when applying (7) to rule out a component's original support. No source-linear price for these exterior strips is established here.

Only /tmp/r309_low_capture.md was written. Other authors and Git were preserved.
