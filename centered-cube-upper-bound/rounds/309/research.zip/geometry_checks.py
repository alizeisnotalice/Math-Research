from fractions import Fraction as F
from itertools import product
from math import comb
ct={'posterior_identity':0,'uniform_cdf':0,'zero_profile':0,
    'forced_degree':0,'rational_threshold':0,'exp_lower':0}
for n in (1,2,4,8):
 for s,kind in product((F(0),F(1,4),F(3,4),F(1)),range(4)):
  hard=[int(not(kind and i<min(kind,n))) for i in range(n)]
  phi=[(F(1,4),F(1,2),F(3,4))[i%3] if hard[i] else F(1,5+i) for i in range(n)]
  coeff=[F(1)]
  for hi,ph in zip(hard,phi):
   aa=(1-s)*hi;bb=s*ph;nxt=[F(0)]*(len(coeff)+1)
   for j,v in enumerate(coeff):nxt[j]+=aa*v;nxt[j+1]+=bb*v
   coeff=nxt
  P=sum(coeff)
  if not P:
   assert all(v==0 for v in coeff);ct['zero_profile']+=1;continue
  probs=[s*ph/((1-s)*hi+s*ph) for hi,ph in zip(hard,phi)]
  post=[F(1)]
  for pp in probs:
   nxt=[F(0)]*(len(post)+1)
   for j,v in enumerate(post):nxt[j]+=(1-pp)*v;nxt[j+1]+=pp*v
   post=nxt
  assert all(coeff[j]/P==post[j] for j in range(n+1));ct['posterior_identity']+=1
  pmin=s/(4-3*s)
  for K in range(n+1):
   cdf=sum(post[:K+1])
   lower=sum(F(comb(n,j))*pmin**j*(1-pmin)**(n-j) for j in range(K+1))
   assert cdf<=lower;ct['uniform_cdf']+=1
   if sum(1-v for v in hard)>K:
    assert cdf==0;ct['forced_degree']+=1
for n,K,s in product((32,128,1024),(0,1,4,16),(F(1,10),F(1,2),F(3,4),F(1))):
 if n*s>=F(28,5)*(K+7):
  assert F(2)**K*(1-s/8)**n<=F(1,128);ct['rational_threshold']+=1
lower=sum(F(7,10)**j/F((1,1,2,6)[j]) for j in range(4))
assert lower==F(12013,6000)>2;ct['exp_lower']+=1
print('PASS',ct)
