# R309 exact posterior and low-degree diagnostics

Finite actual tensor coefficient/posterior algebra, rational stochastic/Markov bounds and a fixed-full-bad capturing-flow payment interface. Rational phi tensors satisfy the analytic inside bound but are not all asserted actual kernel samples. Actual phi is separately checked by ordinary highprecision1D integration. No complete original low/e/m/history, component-FIRST or root certificate.

Inside h=1:pi=s phi/(1-s+s phi)>=s/(4-3s)>=s/4 for1/4<=phi<=1. Outside h=0 and P>0:pi=1. Conditional coordinates independent. If P=0 no posterior or P_low/P is defined; all coefficients are checked zero.

Two valid chains: P_low/P<=Pr[Bin(n,s/(4-3s))<=K]<=Pr[Bin(n,s/4)<=K]<=2^K(1-s/8)^n; and P_low/P<=2^K product(1-pi/2)<=2^K(1-s/8)^n<=2^K exp(-ns/8). The exact tests use the rational Markov expression; no floating exponential decides a payment.

n16,64,256,1024,4096; s0,1/1024,1/64,1/4,1; K0,1,8,32,n with duplicates removed; epsilon1/16. Exact binomial CDF uses integer numerator recurrence and common denominator. Smalln16 is independently compared to tensor polynomial DP. A bound>=1 is marked vacuous; R>epsilon is separately marked not certified.

|n|expanded cases|rational epsilon certificates|vacuous R>=1|
|---:|---:|---:|---:|
|16|25|0|20|
|64|25|3|18|
|256|25|6|16|
|1024|25|8|14|
|4096|25|10|13|

Only original capturing U_low is split. Original full bad U, J,A, chi and lowp/middle labels are frozen; one uniform epsilon payment for their union. No reapplication of FIRST to components. This is a finite positive-flow algebra interface, not a claim that these flow rows realize the full original kernel/history.

Both lowp and middle rows have positive paid flow; the middle row also has positive unpaid low-degree flow. Their combined paid fee is bounded by one epsilon times the same original capturing target.

Actual phi inside evaluations use E3 and a direct scale integral at40/60digits, including +/-1/2 and nearby points. These are numerical evidence, not interval arithmetic. All other displayed comparison decisions are exact Fraction.
