# R182 reversible-source locator index

Scope: three narrow checks in the R114/R116/R117 archives. This records source text and exact applicability conditions for later independent review; it does not certify a new estimate.

## 1. Fixed-parameter forbidden sets and symmetric weights

R114 `rounds/114/research.zip::proof.md`, S1–S4 (lines 220–250), fixes the ratio-band menu before receivers: `j` indexes the half-open ratio bands, each actual receiver belongs to exactly one band (S1, lines 220–225), and for that `j` defines `A_{j,t}(y)` as the coarsest original-tree node containing `y` with `h(A)≤H_j(t)`, using the original finest-grid fallback when no light node exists (S4, lines 244–250). Its source set is

`Z_{j,V}(y,t)=D_V(y)∩(T_0(y)\A_{j,t}(y))`.

Thus after fixing `(ω,V,j,y,t)`, the block partition and `Z` are constructed from the original tree/source data and `t`; they do not depend on the receiver variable `x`. In an actual receiver integral, `j=j(x)` and `t=g(x)` select which member of this family is used, so one must not claim a single set is constant over varying `x`.

R117 `rounds/117/research.zip::proof.md`, JG1 (lines 29–43), repeats the post-R114 definition exactly: `A_i(y,z')=bC(|y_i-z'_i|/b)/c_j`, `w_t(y,z')=∏_i min(1,A_i(y,z')/t)`, `Z_t=D_V(y)∩(T_0(y)\A_{j,t}(y))`, then `μ_t=1_{Z_t}w_t dν_V`, `e_t=μ_t(R^n)`, `Π_t=μ_t/e_t`. Since `C` is evaluated at `|y_i-z'_i|/b`, `w_t(y,z')=w_t(z',y)` wherever the same fixed `j,t` is used. JG1 lines 43–52 states that the original finite-tree light-block/fallback version is right-continuous with finitely many jumps; `A_{j,t}` expands in `t`, while `w_t` is nonincreasing, so `μ_t` decreases in measure order. R114 S5 (lines 254–259) gives the equivalent `\widetilde w_{j,t}` formula with `C(|y_i-z_i|/b)`.

## 2. The threshold K

The general R116 extraction lemma `rounds/116/research.zip::proof.md`, F13–F14 (lines 125–136), explicitly starts “给定 `K>0`” and defines the strict bad set by `p(x,y)W(x,y,z')>KQ_b(x,z')`; the inequality is valid for every positive `K`. R117 JG4 (lines 59–65) gives the corresponding general `D_K={z'∈Z_g:p w_g(z')>KQ_x^*(z')}` and high branch `p e_g≥2Kq`.

However, the checked concrete R117 low-branch application `rounds/117/research.zip::proof.md`, lines 264–277, explicitly says “取 K=1”. I found no concrete original application in these checked clauses choosing `K>3`. The abstract decomposition parameter can be set to a value above 3 in F13, but that changes both the bad set and the paired high cutoff; no checked source says the existing actual branch or its price is unchanged under that replacement. Treat “choose K>3 for the original paid branch” as unverified pending the independent reviewer, not as an inherited fact.

## 3. Hard-tail qualification and light-block/fallback distinction

R113 `rounds/113/research.zip::proof.md`, B8–B10 (lines 75–90), defines the original hard qualification `h(A)=μ_hi(A∩{t_C≤b})`; it builds each `A_t(y)` from the coarsest original-tree node with `h(A)≤H(t)`, filling uncovered points with the original finest-grid fallback. R117 JG14 (lines 155–162) records the checked born-source consequence

`ν_V≤ν_h=1_{t_C≤b}μ_hi`, and `ν_V(A)≤h(A)` for every original forest node `A`.

It explicitly says this is source-qualification evidence, not a consequence of `ν≤β≤μ_hi`, and β itself does not inherit the born qualification. In JG-B's proof, R117 lines 183–200 distinguishes the cases: if the heavy fallback persists without expansion, every deletion jump is zero, and one may **not** assign that fallback a fictitious `h(A)≤H_j(t)` bound; if the block expands, the terminal block `A_*` is a genuinely light block, so deleted sources are contained in it and `ν_V(A_*)≤h(A_*)≤H_j(T)` (JG17–18). At a right-end jump root, the last block counted is the left-side block still inside the heavy interval (lines 183–190). Do not use the light-block mass bound on an unchanged finest heavy fallback.

These quotations support only the original `ν`-hard-tail/tree-node qualification and the named R114/R117 sets. A final claim that transports these qualifications through a new reversible source split still needs the assigned Sol audit.
