# R182任务合同：联合储备与全局列几何

目标保持任意正L1输入中心立方体n^(1/2+o(1))一致弱型界；本轮攻R181 NB20，不把局部接口算闭合。上一轮已提交推送1f8138b；本轮开始仓库main干净。

允许工具：R181 CP共同父来源及正部余源、RS同储备加权稳定、NB固定原删除集的完整归一中心冻结。原β、ν均≤共同父来源A；不假ν≤β，不假每叶λb^n质量帽，不免费更换删除集、score、history或负信用。保留真实dx、唯一j、far钟长及全部维数和窗口费用。

Astra负责global_column_geometry.md：实际NB20全局列预算，给新可证几何估计及回代；不能仅改名余项。Sol辅助负责joint_reserve_kernel.md：直接联合S(v)μ(du)估计，保留bad/capture交换，避免人工inversealpha。Sol审计负责independent_audit.md：先独立审命题后读作者；主代理负责归一与物理联系及整合。数值Sol在准确命题形成后启动，初探、压力、扩大三阶段精确核验。没有独立任务的Luna不启动。

各Agent只写指定文件，不互改，不提交，交付后停止。最终只归档经审最终文件、详细LaTeX、必要复现材料；无PDF。单轮独立提交推送。有限数值不证明原历史实现或一般预算。

联合量：k=DK0,QJ=Jν, alpha QJ=Dq−∫E min(a,k)ν；S=1E alpha J[1−(k+alpha J)/a]_+²；μ=k1Bν/(alpha QJ)。a0余权0，alpha0联合量0。B与E不交及K0ν≤q保证k(B)≤alpha QJ。作者要核验固定门与变门的合法路径、零分支和常数；全局作者保留原NB20外乘子。
