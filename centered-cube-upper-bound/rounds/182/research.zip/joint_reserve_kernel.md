# R182：同储备 Sμ 的联合稳定、尖锐 1/2 常数与原冻结列接口

本稿只处理实际 RS7 联合量，不重复单独 S 的稳定性。已读 R182 合同和冻结 R181 reserve_weighted_stability RS1–7、normalized_joint_bridge NB1–20；准确命题先发独审。所有来源、核及重构系数在比较中保持原定义；不假 ν≤β，不加质量帽，不改历史或 score。只写本文件，不提交/spawn/PDF，完成有界结果后停止。

## JK1. 固定对象、门与零分支

固定同一个 x,V,j 及有限正 ν，固定 J,k=DK0≥0、c=Dq≥∫k dν、Q=Q_J=∫J dν∈(0,∞)。本稿 Q 始终表示 Q_J，原 target 混合核仍写 Q_v，二者不同。两行 i=0,1 有非负可积阈值 a_i、capture 指示 ε_i=1_{E_i}、bad 指示 b_i=1_{B_i}，满足 E_i∩B_i为空。置

\[
U_i=\varepsilon_i\min(a_i,k),\quad
\alpha_iQ=c-\int U_i\,d\nu,\quad
\rho_i(v)=\left[1-{k(v)+\alpha_iJ(v)\over a_i(v)}\right]_+,
\tag{JK1}
\]

a=0时rho取0。rho是全域辅助式，乘capture后才是原指定RC余权；在capture中 U=min(a,k)，故与R127/R181所核原余权相同。额外任意减小的余权不能自动继承本稳定性。

记 B_i^k=∫_{B_i}k dν。因为 U_i≤k，且bad上U_i=0，

\[
0\le B_i^k\le\alpha_iQ,\qquad\alpha_i\ge0.
\tag{JK2}
\]

Q=0的实际原行先作零来源处理，不用下式除法。以下固定Q>0；实际strictsoft使J,K0严格正，但本联合引理只需写明的非负性和JK2。

## JK2. 先取消 alpha 的准确联合测度

原 S_i=ε_i alpha_i J rho_i²，mu_i(du)=k(u)b_i(u)ν(du)/(alpha_i Q)。定义

\[
\mathcal M_i(dv,du)=S_i(v)\nu(dv)\mu_i(du).
\]

alpha_i>0时直接相消；alpha_i=0时按合同令整个联合量为0，JK2给k b_iν=0，故同一个公式仍成立：

\[
\boxed{\mathcal M_i(dv,du)
={J(v)\over Q}\varepsilon_i(v)\rho_i(v)^2\nu(dv)
\otimes k(u)b_i(u)\nu(du).}
\tag{JK3}
\]

没有除alpha的连续性问题，也没有将mu当成与行无关的概率。特别令

\[
C_i={1\over Q}\int_{E_i}J\rho_i^2d\nu\in[0,1],
\quad \|\mathcal M_i\|=C_i B_i^k\le B_i^k\le\alpha_iQ\le c.
\tag{JK4}
\]

因此alpha趋0时整个联合量的质量趋0（固定Q），即使mu本身无稳定极限。这里总变差范数是signed测度的**完整变差质量**，不是概率距离的一半。

## JK3. 精确变差分拆与必须保留的 bad 交换

令 Bcap=B_0∩B_1，Bcap^k=∫_{Bcap}k dν，并定义

\[
X_B=C_0\int_{B_0\setminus B_1}k\,d\nu
+C_1\int_{B_1\setminus B_0}k\,d\nu.
\tag{JK5}
\]

按u的共同/独占bad支持分拆JK3，准确得到

\[
\boxed{\|\mathcal M_0-\mathcal M_1\|_{TV}
={Bcap^k\over Q}\int J|\varepsilon_0\rho_0^2-\varepsilon_1\rho_1^2|d\nu+X_B.}
\tag{JK6}
\]

X_B是端点真实目标余量平均乘bad来源交换质量，不是任意新容量门。它≤∫k|b_0−b_1|dν，但主式保留C_i。若Bcap^k=0，联合变差**恰等于X_B**；无需定义任何中间导数或除alpha。这也覆盖一端alpha=0的情况。

## JK4. 固定 capture/bad 的 1/2 稳定定理

若 E_0=E_1=E、B_0=B_1=B，记 A=∫|a_1−a_0|dν，则

\[
\boxed{\|\mathcal M_1-\mathcal M_0\|_{TV}\le\tfrac12 A.}
\tag{JK7}
\]

证明如下。B^k=0时两联合量为0。否则沿a_theta=(1−theta)a_0+theta a_1，依同一capture定义alpha_theta Q=c−∫_E min(a_theta,k)dν，JK2在整个路径给alpha_theta Q≥B^k>0。

在活跃支a>k+alpha J上令z=alpha J/a，rho=1−k/a−z。共同bad质量乘rho²直接a导数的积分核满足

\[
{B^k\over Q}J\partial_a\rho^2
\le2z(1-\rho)\rho\le8/27.
\tag{JK8}
\]

而alpha导数的总系数满足

\[
{B^k\over Q}\int_E2J^2\rho/a\,d\nu
\le\int_E2Jz\rho\,d\nu\le Q/2,
\tag{JK9}
\]

因为z+rho≤1，zrho≤1/4。另一方面dot alpha Q=−∫_{E,a_theta<k}dot a dν。JK8只在a_theta>k活跃，与该储备调整来源a_theta<k不交。因此沿路径的变差速率≤

(8/27)∫_{E,a_theta>k}|dot a|dν+(1/2)∫_{E,a_theta<k}|dot a|dν≤A/2。

再积分theta即得JK7，不能把两个系数先各估A后相加。min折点对非恒定a路径每槽至多一个；恒定接触槽dot a=0。rho²在活跃边界导数为0；B^k>0时alpha有正下界，J=0槽目标质量为0，a=0不产生额外项。绝对连续链法/Fubini由上述可积界保证。alpha0路径不需要人为正则化。

## JK5. 一般 capture、bad、阈值变化的 alpha-free 费用

令 Ec=E_0∩E_1，a_theta同前，定义

\[
L_E=\int|\varepsilon_1-\varepsilon_0|
\left[\int_0^1\min(a_\theta,k)d\theta\right]d\nu
\le\int k|\varepsilon_1-\varepsilon_0|d\nu,
\tag{JK10}
\]
\[
Y_E={Bcap^k\over Q}
\left[\int_{E_0\setminus E_1}J\rho_0^2d\nu
+\int_{E_1\setminus E_0}J\rho_1^2d\nu\right].
\tag{JK11}
\]

则

\[
\boxed{\|\mathcal M_0-\mathcal M_1\|_{TV}
\le\tfrac12 A+\tfrac12 L_E+Y_E+X_B.}
\tag{JK12}
\]

常数不含inversealpha、inversea或ν质量；A/L_E/Y_E/X_B本身是实际来源积分，不能据此称它们已有全局费用。

证明：Bcap^k=0时使用JK6即可。否则令epsilon_theta=(1−theta)ε_0+theta ε_1，alpha_theta Q=c−∫epsilon_theta min(a_theta,k)dν。此分数capture仅为证明路径，不是改原行。共同bad在两个capture外，故alpha_theta Q≥Bcap^k始终成立。只对目标Ec比较rho²，直接a项与储备a项依旧不交；链法给

|dot alpha|Q≤∫epsilon_theta1_{a_theta<k}|dot a|dν+∫|epsilon_1−epsilon_0|min(a_theta,k)dν。

JK8–9应用于Ec，第一组仍≤A/2，第二组积分≤L_E/2。Ec外的两个capture独占端点就是Y_E，u的bad独占端点就是X_B，故JK12。

可用但不必放松的附加界为

Y_E≤min{(Bcap^k/Q)∫_{E_0△E_1}Jdν,
 (4/27)[∫_{E_0\E_1}a_0dν+∫_{E_1\E_0}a_1dν]}。

后一个界来自Bcap^k/Q≤alpha_i及alpha_iJrho_i²≤4a_i/27，不引入新alpha分母。L_E还能用concavity界∫min((a_0+a_1)/2,k)|δε|dν，但endpoint费用Y_E不能因此删除。整个变差也可与∥M_0∥+∥M_1∥≤2c取小；这不是来源概率假设。

## JK6. 1/2 的有限有理尖锐族

本节只证明JK7在所列代数合同中的最佳统一常数，不认证这些系数来自原mixed物理核或实现FULL/history。

三原子(reserve,target,bad)，ν各质量1，取N≥2、ε=1/N、h=ε/2，

k=(1,ε,1)，J=(ε,1,ε)，c=2+ε=kν，Q=1+2ε，E={reserve,target}，B={bad}。

定义alpha_0=(1+ε)/Q、a_target=ε+2alpha_0，阈值端点

a_0=(1−ε,a_target,0)，a_1=(1−ε+h,a_target,0)。

均满足原代数重构，alpha_1=alpha_0−h/Q。reserve槽a<k所以rho0；仅target–bad联合元素非零，

rho_0=alpha_0/a_target，rho_1=rho_0+h/(Q a_target)。

因A=h，准确比例为

\[
{\|\mathcal M_1-\mathcal M_0\|_{TV}\over A}
={2\rho_0\over Q^2a_{target}}+{h\over Q^3a_{target}^2}
\longrightarrow\tfrac12.
\tag{JK13}
\]

例如N=2,4,16,64,256分别给13/128、112/529、94208/236883、91226112/193393739、92073361408/186859864363，均为精确有理值。故不能在该一般代数范围把1/2改成更小统一常数；没有声称原物理几何也必须达到此极限。

## JK7. 两类交换费不能省：极小精确例子

bad-only：三原子(v,u1,u2)，ν=J=k=1，c=Q=3，E={v}，a=(3,0,0)，B_0={u1}、B_1={u2}。alpha=2/3，rho_v=4/9，C_i=16/243。A=L_E=Y_E=0但联合支持互斥，TV=X_B=32/243>0，故bad交换不能被固定门稳定性覆盖。

capture-only：两原子(v,u)，ν质量1，k=(ε,1)、J=(1,ε)、c=Q=1+ε、a=(4,0)、两bad均为{u}。令E_0={v}、E_1为空。alpha_0=1/Q、alpha_1=1，A=X_B=0，L_E=ε，却有TV=Y_E=rho_{0,v}²/Q→9/16。故不能仅按k加权capture交换而丢掉真实目标支持费用Y_E。这些是最小代数压力例，不是原来源或历史的反例。

## JK8. 物理运输的有效范围与需要数值的公式

在共同固定capture与bad的实际行族，R181 RS3已证A≤T∥ν∥min(1,4∥y−y'∥₁/b)。JK7因而给

\[
\|\mathcal M_y-\mathcal M_{y'}\|_{TV}
\le2T\|\nu\|\sqrt n\,\|y-y'\|_2/b.
\tag{JK14}
\]

此物理系数仍含实际ν质量；代数Lipschitz常数1/2本身没有ν质量放大。变capture/bad时必须加JK10–12的费用，不能凭来源距离把离散门跳免费抹掉。固定x运输界也不是原全局dx预算。

有限数值只需对固定原子权ν_l、k_l、J_l,c及二进制E/B，先算alpha和rho，再从JK3双矩阵绝对差求TV，与JK6因式算法独立比较；JK10的theta积分是min(affine,k)的精确分段有理积分。JK13有理族、JK7两个交换例和alpha0/badweighted0边界足够作有限三阶段检查，不需要物理核quad或新source搜索。有限例不认证原L1/FIRST/history；本稿证明不依赖其浮点误差。

## JK9. 对原NB20的精确回代和剩余外乘子

在同一个冻结中心cell、保留实际y行的Z和normalizer，RS7/NB20的原companion可写成外β、dx、dt/t、原期望/唯一j求和下的

\[
\int G_y(v,u)\,\mathcal M_y(dv,du),\quad
G_y=H_y\,{p_y^2Q_J\over9D Q_v^2\widehat e_{y,t}^{\,2}}
\,w_t(r(y),v)\,{w_t(r(y),u)\over K0(u)}.
\tag{JK15}
\]

H仍含两个实际1_Z、原score/eligible/high、middle、history和其他原门；capture/bad已在M内，重复幂等指示不改变积分。固定x的K0/J/Q_J与原innerν均未动，原alpha由JK1给定。strictsoft K0>0才允许此原密度反换；alpha0时原bad槽先作零分支。式中没有新增1/a或1/alpha，但反K0、Q_v²、hat e²和p_y均真实存在。

对同一个固定测试0≤G≤L，JK12直接给|∫GdM_0−∫GdM_1|≤L TV，无重新分离S和mu。若测试也随行变化，令m_i=dM_i/d(ν⊗ν)，准确将共同密度和独占密度分开；在有限正截断处得到

\[
\left|\int G_0dM_0-\int G_1dM_1\right|
\le L\|M_0-M_1\|_{TV}
+\int\min(m_0,m_1)|G_0-G_1|d(\nu\otimes\nu)
\tag{JK16}
\]

（G_0,G_1≤L）。未有界测试须保留相应加权变差/外乘子交换和补集，不可把其上确界免费设成L。尤其JK15的wt_u/K0、hat e_y²、原H_y与terminal系数并非已证统一有界；中心同cell也不改变实际Z_y,t、hat e_y,t的y依赖。直接将反K0乘入JK3会消去k坏源权，并失去JK2的同储备容量，必须有额外物理来源比较，不能再从mu≤1领回它。

本轮真正取得的是整个Sν⊗mu的JK3/JK7/JK12：容量及稳定一起控制alpha趋零，不必估mu差后再付inversealpha。要用于NB20总预算，还须共同支付JK15的真实外乘子/门交换、外β与全dx、原time/j/window费用；共同父预算仅控制来源总量，不给这些列积分。未将辅助行赋予新history、未重选bad/capture、未借负信用或宣布一般middle付款。交独审后停止。
