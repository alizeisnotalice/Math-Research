#!/usr/bin/env python3
"""R182 finite exact joint reserve and reversible Green checks; no physical claim."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,sys,hashlib
HERE=Path(__file__).resolve().parent
def fs(xs):return [F(x) for x in xs]
def sm(xs):return sum(xs,F(0))
def case(name,stage,nu,J,k,c,a,ap,E,B,Ep=None,Bp=None,expected=None):return dict(name=name,stage=stage,nu=fs(nu),J=fs(J),k=fs(k),c=F(c),a0=fs(a),a1=fs(ap),E0=list(E),B0=list(B),E1=list(E if Ep is None else Ep),B1=list(B if Bp is None else Bp),sharp_expected=expected)
def min_integral(x,y,k):
 lo,hi=min(x,y),max(x,y)
 if hi<=k:return (x+y)/2
 if lo>=k:return k
 return k-(k-lo)**2/(2*(hi-lo))
def min_integral_alt(x,y,k):
 if x==y:return min(x,k)
 return (x+y)/2-(max(y-k,0)**2-max(x-k,0)**2)/(2*(y-x))
def joint_row(c,side):
 nu,J,k=c['nu'],c['J'],c['k'];a,E,B=c['a'+str(side)],c['E'+str(side)],c['B'+str(side)];Q=sm(j*v for j,v in zip(J,nu));capture=sm(e*min(x,kk)*v for e,x,kk,v in zip(E,a,k,nu));alpha=(c['c']-capture)/Q;bad=sm(b*kk*v for b,kk,v in zip(B,k,nu));assert alpha>=0 and bad<=alpha*Q
 rho=[F(0) if x==0 else max(0,1-(kk+alpha*j)/x) for x,kk,j in zip(a,k,J)];L=[e*j*r*r*v for e,j,r,v in zip(E,J,rho,nu)];R=[b*kk*v/Q for b,kk,v in zip(B,k,nu)];M=[[l*r for r in R] for l in L]
 if alpha==0:assert bad==0 and all(v==0 for row in M for v in row);mu=None;S=[F(0)]*len(nu);decomp=True
 else:
  mu=[b*kk*v/(alpha*Q) for b,kk,v in zip(B,k,nu)];S=[alpha*l for l in L];decomp=all(M[i][j]==S[i]*mu[j] for i in range(len(nu)) for j in range(len(nu)))
 mass=sm(v for row in M for v in row);assert mass==sm(L)*bad/Q and mass<=bad<=alpha*Q
 return dict(Q=Q,capture=capture,alpha=alpha,bad_k_nu=bad,rho=rho,left=L,right=R,M=M,mass=mass,S=S,mu=mu,decomposition=decomp,alpha0_no_division=alpha==0)
def scaled(c,mass=F(1),amplitude=F(1)):
 cc=dict(c);cc['nu']=[mass*v for v in c['nu']];cc['c']=mass*amplitude*c['c'];cc['k']=[amplitude*v for v in c['k']];cc['a0']=[amplitude*v for v in c['a0']];cc['a1']=[amplitude*v for v in c['a1']];return cc
def check_joint(c):
 nu,J,k=c['nu'],c['J'],c['k'];n=len(nu);assert all(v>=0 for v in nu+k+c['a0']+c['a1']) and all(v>0 for v in J) and sm(j*v for j,v in zip(J,nu))>0 and c['c']>=sm(kk*v for kk,v in zip(k,nu))
 assert all(e in (0,1) and b in (0,1) and not(e and b) for side in ('0','1') for e,b in zip(c['E'+side],c['B'+side]))
 x,y=joint_row(c,0),joint_row(c,1);Q=x['Q'];L1=sm(abs(x['M'][i][j]-y['M'][i][j]) for i in range(n) for j in range(n));cap=sm(kk*v*int(b and bp) for kk,v,b,bp in zip(k,nu,c['B0'],c['B1']));only0=sm(kk*v*int(b and not bp) for kk,v,b,bp in zip(k,nu,c['B0'],c['B1']));only1=sm(kk*v*int(bp and not b) for kk,v,b,bp in zip(k,nu,c['B0'],c['B1']));C0=sm(x['left'])/Q;C1=sm(y['left'])/Q;X=C0*only0+C1*only1;Y=cap/Q*(sm(l*int(e and not ep) for l,e,ep in zip(x['left'],c['E0'],c['E1']))+sm(l*int(ep and not e) for l,e,ep in zip(y['left'],c['E0'],c['E1'])));A=sm(abs(a-ap)*v for a,ap,v in zip(c['a0'],c['a1'],nu));pieces=[min_integral(a,ap,kk) for a,ap,kk in zip(c['a0'],c['a1'],k)];LE=sm(abs(e-ep)*p*v for e,ep,p,v in zip(c['E0'],c['E1'],pieces,nu));factor=cap/Q*sm(abs(a-b) for a,b in zip(x['left'],y['left']))+X;bound=A/2+LE/2+Y+X
 scale_checks={}
 for label,m,h in [('source_mass',F(2**20),F(1)),('capture_amplitude',F(1),F(1,1024))]:
  cc=scaled(c,m,h);r0,r1=joint_row(cc,0),joint_row(cc,1);scale_checks[label]=all(r['M'][i][j]==m*h*z['M'][i][j] for r,z in [(r0,x),(r1,y)] for i in range(n) for j in range(n)) and r0['alpha']==h*x['alpha'] and r1['alpha']==h*y['alpha']
 fixed=c['E0']==c['E1'] and c['B0']==c['B1'];checks=dict(exact_factorization=L1==factor,changed_gate_bound=L1<=bound,fixed_gate_half=(not fixed or L1<=A/2),min_integral_independent=all(p==min_integral_alt(a,ap,kk) for p,a,ap,kk in zip(pieces,c['a0'],c['a1'],k)),LE_cap=LE<=sm(kk*abs(e-ep)*v for kk,e,ep,v in zip(k,c['E0'],c['E1'],nu)),S_mu=x['decomposition'] and y['decomposition'],Bcap0=(cap!=0 or L1==X),scaled=all(scale_checks.values()),signed_alpha=(y['alpha']-x['alpha'])*Q==x['capture']-y['capture'])
 sharp_formula=None
 if c['sharp_expected'] is not None:
  N=c['sharp_N'];h=F(1,2*N);av=c['a0'][1];sharp_formula=2*x['rho'][1]/(Q**2*av)+h/(Q**3*av**2);closed=F(N**4*(4*N+5),2*(N+2)*(2*N*N+3*N+2)**2);checks['sharp_fraction']=L1/A==c['sharp_expected']==sharp_formula==closed
 return dict(input=c,row0=x,row1=y,A=A,L_E=LE,L_E_pieces=pieces,Bcap=cap,X_bad=X,Y_E=Y,total_L1=L1,half_L1=L1/2,factorized_L1=factor,bound=bound,fixed_gates=fixed,L1_over_A=L1/A if A else None,sharp_derived_formula=sharp_formula,without_X_bad=L1<=A/2+LE/2+Y,without_Y_E=L1<=A/2+LE/2+X,scale_checks=scale_checks,checks=checks,scope='Finite algebra, total L1 (not half-TV); no physical FIRST/history qualification')
def joint_cases():
 E=[1,1,0];B=[0,0,1];out=[case('identical','initial',[1]*3,[1]*3,[F(1,2),F(1,5),1],F(17,10),[F(1,4),3,0],[F(1,4),3,0],E,B),case('fixed_capture_change','initial',[1,2,F(1,2)],[1]*3,[F(1,2),F(1,5),1],F(7,5),[F(1,4),3,0],[F(3,8),3,0],E,B),case('fixed_active_change','initial',[1]*3,[1]*3,[F(1,2),F(1,5),1],F(17,10),[F(1,4),2,0],[F(1,4),3,0],E,B)]
 out +=[case('all_a0','stress',[1]*3,[1]*3,[1]*3,3,[0]*3,[0]*3,E,B),case('alpha0_joint_zero','stress',[1]*3,[1]*3,[1,0,0],1,[2,4,0],[3,5,0],E,B),case('alpha0_to_positive_gate','stress',[1,1],[1,1],[1,1],2,[2,2],[2,2],[1,1],[0,0],[1,0],[0,1]),case('bad_only_exchange','stress',[1]*3,[1]*3,[1]*3,3,[3,0,0],[3,0,0],[1,0,0],[0,1,0],Bp=[0,0,1]),case('capture_only_exchange','stress',[1,1],[1,F(1,1024)],[F(1,1024),1],1+F(1,1024),[4,0],[4,0],[1,0],[0,1],[0,0],[0,1]),case('changed_capture_crosses_k','stress',[1]*3,[1]*3,[1]*3,3,[2,F(1,2),0],[2,F(3,2),0],E,B,[1,0,0],B)]
 expected=[F(13,128),F(112,529),F(94208,236883),F(91226112,193393739),F(92073361408,186859864363)]
 for N,want in zip((2,4,16,64,256),expected):
  ep=F(1,N);Q=1+2*ep;alpha=(1+ep)/Q;a=[1-ep,ep+2*alpha,0];ap=[1-ep/2,a[1],0];c=case('sharp_N'+str(N),'expanded',[1]*3,[ep,1,ep],[1,ep,1],2+ep,a,ap,E,B,expected=want);c['sharp_N']=N;out.append(c)
 for den in (4,64,1024):
  ep=F(1,den);al=ep/3;out.append(case('alpha_small_'+str(den),'expanded',[1]*3,[1]*3,[1,0,ep],1+ep,[1,2*al,0],[1,3*al,0],E,B))
 return out

# Exact matrix routines are independent of the reserve factorization above.
def eye(n):return [[F(int(i==j)) for j in range(n)] for i in range(n)]
def mm(A,B):return [[sm(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def madd(A,B):return [[x+y for x,y in zip(a,b)] for a,b in zip(A,B)]
def inverse(A):
 n=len(A);r=[list(row)+list(e) for row,e in zip(A,eye(n))]
 for j in range(n):
  p=next(i for i in range(j,n) if r[i][j]);r[j],r[p]=r[p],r[j];pivot=r[j][j];r[j]=[x/pivot for x in r[j]]
  for i in range(n):
   if i!=j:
    h=r[i][j];r[i]=[x-h*y for x,y in zip(r[i],r[j])]
 return [row[n:] for row in r]
def ldl(A):
 n=len(A);L=eye(n);d=[]
 for j in range(n):
  dj=A[j][j]-sm(L[j][k]**2*d[k] for k in range(j));d.append(dj);assert dj>=0
  for i in range(j+1,n):
   r=A[i][j]-sm(L[i][k]*L[j][k]*d[k] for k in range(j))
   if dj==0:assert r==0;L[i][j]=F(0)
   else:L[i][j]=r/dj
 recon=[[sm(L[i][k]*d[k]*L[j][k] for k in range(n)) for j in range(n)] for i in range(n)];assert recon==A
 return dict(L=L,diagonal=d,reconstruction_exact=True,all_pivots_nonnegative=all(v>=0 for v in d))
def chainK(n):
 K=[[F(0)]*n for _ in range(n)]
 for i in range(n-1):K[i][i+1]=K[i+1][i]=F(1,2)
 K[0][0]=K[-1][-1]=F(1,2);return K
def graph(name,stage,K,nu,p,c=F(3,4),witness=None,gate=None):
 K=[fs(row) for row in K];nu,p=fs(nu),fs(p);c=F(c);n=len(nu);assert all(v>0 for v in nu+p) and 0<c<1 and all(0<=K[i][j]<=1 and K[i][j]==K[j][i] for i in range(n) for j in range(n))
 e=[sm(k*v for k,v in zip(row,nu)) for row in K];m=[x*v for x,v in zip(e,nu)];active=[i for i in range(n) if e[i]>0];isolated=[i for i in range(n) if e[i]==0];P=[[K[i][j]*nu[j]/e[i] for j in active] for i in active];B=[[P[ii][jj]*(int(p[j]<c*p[i]) if gate is None else F(gate[i][j])) for jj,j in enumerate(active)] for ii,i in enumerate(active)];assert gate is None or all(not gate[i][j] or p[j]<c*p[i] for i in range(n) for j in range(n));w=[m[i] for i in active];N=len(active);I0=eye(N);A=[[I0[i][j]-B[i][j] for j in range(N)] for i in range(N)];G=inverse(A);power=eye(N);neumann=eye(N)
 for _ in range(1,N):power=mm(power,B);neumann=madd(neumann,power)
 nil=mm(power,B);adj=[[w[j]*B[j][i]/w[i] for j in range(N)] for i in range(N)];PSD=[[4*w[i]*int(i==j)-sm(w[k]*G[k][i]*G[k][j] for k in range(N)) for j in range(N)] for i in range(N)];cert=ldl(PSD);v=fs(witness if witness is not None else [1]*n);v=[v[i] for i in active];gv=[sm(a*b for a,b in zip(row,v)) for row in G];wr=sm(ww*y*y for ww,y in zip(w,gv))/sm(ww*x*x for ww,x in zip(w,v));plain=sm(y*y for y in gv)/sm(x*x for x in v)
 checks=dict(stochastic=all(sm(row)==1 for row in P),detailed_balance=all(w[i]*P[i][j]==w[j]*P[j][i] for i in range(N) for j in range(N)),oriented_adjoint=all(B[i][j]+adj[i][j]<=P[i][j] for i in range(N) for j in range(N)),inverse_both=mm(A,G)==mm(G,A)==I0,neumann_exact=G==neumann and all(x==0 for row in nil for x in row),weighted_PSD=cert['reconstruction_exact'] and cert['all_pivots_nonnegative'],weighted_witness=wr<=4,isolates_no_edges=all(K[i][j]==0 for i in isolated for j in range(n)))
 return dict(name=name,stage=stage,K=K,nu=nu,p=p,c=c,extra_fixed_gate=gate,e=e,m=m,active_indices=active,zero_e_indices=isolated,P=P,B=B,G=G,weighted_PSD_matrix=PSD,LDL=cert,witness=v,weighted_witness_ratio_squared=wr,plain_Euclidean_witness_ratio_squared=plain,checks=checks,scope='Finite symmetric graph kernel, weighted L2(e*nu); not physical C/FIRST/history or a nu-to-m payment')
def green_checks():
 half=[[F(1,2)]*3 for _ in range(3)];isol=[row+[0] for row in chainK(3)]+[[0]*4];star=[[0,0,0,F(1,2)],[0,0,0,F(1,2)],[0,0,0,F(1,2)],[F(1,2),F(1,2),F(1,2),F(1,1024)]]
 out=[graph('complete_three','initial',half,[1]*3,[4,2,1]),graph('chain_three','initial',chainK(3),[1]*3,[4,2,1]),graph('strict_gate_equality','initial',half,[1]*3,[2,1,1],F(1,2)),graph('isolated_e0','stress',isol,[1,2,3,4],[8,4,2,1]),graph('unequal_nu_e_star','stress',star,[F(1,1024)]*3+[1024],[8,16,32,1],witness=[1,1,1,2]),graph('chain_eight','expanded',chainK(8),[1]*8,[F(1,2**i) for i in range(8)]),graph('dense_twelve','expanded',[[F(1,1+abs(i-j)) for j in range(12)] for i in range(12)],[F(i+1,12) for i in range(12)],[F(1,2**i) for i in range(12)])]
 n=128;rowsums=[2-F(1,2**k) for k in range(n)];direct=sm(x*x for x in rowsums)/n;closed=(4*n-8*(1-F(1,2**n))+F(4,3)*(1-F(1,4**n)))/n;assert direct==closed<4
 witness=dict(n=n,K='nearest-neighbor1/2,boundaryself1/2',nu='all1',p='2^-i',c='3/4',matrix_built=False,row_sums='2-2^-k, k0..n-1 (reverse row order)',direct_squared_ratio=direct,closed_squared_ratio=closed,gap_to_four=4-closed,pass_exact=direct==closed<4,scope='Exact closed-form witness for sharpness of2; not fitted from graph menus')
 assert next(g for g in out if g['name']=='unequal_nu_e_star')['plain_Euclidean_witness_ratio_squared']>4
 return out,witness

def bad_decomposition(name,stage,n,p,Q,wg,wt,nu,Z):
 p,Q,nu=map(fs,(p,Q,nu));wg=[fs(r) for r in wg];wt=[fs(r) for r in wt];N=len(p);a=(1+F(n,n+1)**n)/3
 assert all(x>0 for x in p+Q+nu) and all(q>=a*x for q,x in zip(Q,p)) and all(0<=wg[i][j]<=wt[i][j]<=1 and wg[i][j]==wg[j][i] and wt[i][j]==wt[j][i] and Z[i][j] in (0,1) and Z[i][j]==Z[j][i] for i in range(N) for j in range(N))
 bad=[[int(p[i]*wg[i][j]>Q[j]) for j in range(N)] for i in range(N)];A=[[bad[i][j]*(1-bad[j][i]) for j in range(N)] for i in range(N)];R=[[bad[i][j]*bad[j][i] for j in range(N)] for i in range(N)];score=[x*q for x,q in zip(p,Q)];ratios=[score[j]/score[i] for i in range(N) for j in range(N) if A[i][j]];cA=(1+max(ratios,default=F(0)))/2;recip=[]
 for i in range(N):
  for j in range(N):
   if R[i][j]:recip.append(dict(i=i,j=j,wg=wg[i][j],Ka=a,p_ratio=p[j]/p[i],lower=a/wg[i][j],upper=wg[i][j]/a,strict_crossmultiplication=(a*p[i]<wg[i][j]*p[j] and a*p[j]<wg[i][j]*p[i])))
 Kgraph=[[Z[i][j]*wt[i][j] for j in range(N)] for i in range(N)];cert=graph('A_only_'+name,stage,Kgraph,nu,score,cA,gate=A)
 checks=dict(exact_split=all(bad[i][j]==A[i][j]+R[i][j] and A[i][j]*R[i][j]==0 for i in range(N) for j in range(N)),antisymmetric=all(A[i][j]+A[j][i]<=1 for i in range(N) for j in range(N)),reciprocal_symmetric=all(R[i][j]==R[j][i] for i in range(N) for j in range(N)),strict_score_descent=all(not A[i][j] or score[i]>score[j] for i in range(N) for j in range(N)),reciprocal_wg_lower=all(r['wg']>a for r in recip),reciprocal_ratio_interval=all(r['lower']<r['p_ratio']<r['upper'] and r['strict_crossmultiplication'] for r in recip),A_Green=all(cert['checks'].values()))
 return dict(name=name,stage=stage,ambient_n_parameter=n,source_slots=N,K_good_constant=1,a_n=a,p=p,Q=Q,wg=wg,wt=wt,nu=nu,Z_symmetric=Z,bad=bad,asymmetric_A=A,reciprocal_R=R,score_pQ=score,reciprocal_edges=recip,cA_finite_witness=cA,A_only_Green=cert,checks=checks,scope='Finite original-form bad qualification with symmetric abstract weights; A only receives Green, R remains unpaid; no physical C/FIRST/history or uniform gap cA')
def bad_checks():
 one=lambda n:[[1]*n for _ in range(n)]
 w2=[[F(3,4)]*2 for _ in range(2)];w3=[[F(3,4)]*3 for _ in range(3)];w4=[[1,F(3,4),F(1,2),F(1,4)],[F(3,4),1,F(7,8),F(3,4)],[F(1,2),F(7,8),1,1],[F(1,4),F(3,4),1,1]];t4=[[(1+F(v))/2 for v in row] for row in w4];Z4=one(4);Z4[0][3]=Z4[3][0]=0
 return [bad_decomposition('mutual_two','initial',2,[1,1],[F(1,2)]*2,w2,w2,[1,1],one(2)),bad_decomposition('mixed_three','stress',3,[1,1,F(1,4)],[F(1,2),F(1,2),F(1,8)],w3,w3,[1]*3,one(3)),bad_decomposition('nonuniform_four','expanded',8,[4,2,1,F(1,2)],[3,1,F(3,4),F(1,2)],w4,t4,[F(1,8),2,F(1,2),3],Z4)]

def deletion_case(name,stage,nu,R,w,times,scores,deletes):
 nu,w,times=map(fs,(nu,w,times));R=list(R);N=len(nu);assert len(scores)==len(times)-1==len(deletes) and all(v>=0 for v in nu) and all(0<x<=1 for x in w) and all(r in (0,1) for r in R) and all(1<=t<=2 for t in times) and all(a<b for a,b in zip(times,times[1:])) and all(k>=0 and int(k)==k for pair in scores for k in pair)
 assert all(scores[i][g]<=scores[i+1][g] for i in range(len(scores)-1) for g in (0,1))
 initial=list(w);alive=[True]*N;stops=[None]*N;Rinitial=sm(v*x*r for v,x,r in zip(nu,w,R));einitial=sm(v*x for v,x in zip(nu,w));assert einitial>0;b_initial=Rinitial/einitial;trace=[];delete_trace=[];Pplus=Pminus=continuous_R_loss=deleted_R_stop=F(0)
 def state(weights):
  masses=[v*x*int(z) for v,x,z in zip(nu,weights,alive)];e=sm(masses);assert e>0;return e,sm(m*r for m,r in zip(masses,R))/e,[m/e for m in masses]
 for step,(t0,t1,ks,batch) in enumerate(zip(times,times[1:],scores,deletes)):
  before=list(w);oldalive=list(alive);e0,b0,_=state(w);end=[x*(t0/t1)**ks[0 if r else 1] for x,r in zip(w,R)];e1,b1,_=state(end);Rloss=sm(v*(a-b)*r*int(z) for v,a,b,r,z in zip(nu,w,end,R,alive));dp=max(b1-b0,0);dm=max(b0-b1,0);assert (ks[1]>=ks[0] and dm==0) or (ks[1]<=ks[0] and dp==0)
  probes=[]
  for t in (t0,(t0+t1)/2,t1):
   wt=[x*(t0/t)**ks[0 if r else 1] for x,r in zip(before,R)];ee,bb,pi=state(wt);kp=[ks[0 if r else 1] for r in R];directplus=sm(pi[v]*pi[u]*R[u]*max(kp[v]-kp[u],0) for v in range(N) for u in range(N));directminus=sm(pi[v]*pi[u]*R[u]*max(kp[u]-kp[v],0) for v in range(N) for u in range(N));fp=max(ks[1]-ks[0],0)*bb*(1-bb);fm=max(ks[0]-ks[1],0)*bb*(1-bb);assert directplus==fp and directminus==fm
   probes.append(dict(t=t,b_R=bb,direct_plus_rate=directplus,direct_minus_rate=directminus,class_plus_rate=fp,class_minus_rate=fm))
  Pplus+=dp;Pminus+=dm;continuous_R_loss+=Rloss;w=end;assert len(set(batch))==len(batch) and all(alive[i] for i in batch);d=sm(nu[i]*w[i] for i in batch);r=sm(nu[i]*w[i]*R[i] for i in batch)
  for i in batch:alive[i]=False;stops[i]=w[i]
  ep,bp,_=state(w);jump=bp-b1;formula=(b1*d-r)/(e1-d);assert jump==formula and ep==e1-d and e0>=e1>=ep;neg=max(-jump,0);pos=max(jump,0);assert neg<=r/e1
  trace.append(dict(step=step,t0=t0,t1=t1,R_score=ks[0],nonR_score=ks[1],alive_start=oldalive,b_start_postdelete=b0,b_end_predelete=b1,e_start=e0,e_end_predelete=e1,continuous_plus=dp,continuous_minus=dm,continuous_R_weight_loss=Rloss,rate_probes=probes))
  delete_trace.append(dict(t=t1,deleted_indices=batch,e_before=e1,e_after=ep,b_before=b1,b_after=bp,deleted_weight_total=d,deleted_R_stop_weight=r,signed_jump=jump,jump_formula=formula,negative_jump=neg,positive_jump=pos,negative_jump_r_over_e=r/e1));deleted_R_stop+=r
 eg,bg,_=state(w);Rfinal=sm(nu[i]*w[i]*R[i]*int(alive[i]) for i in range(N));nR=sm(v*r for v,r in zip(nu,R));
 for i in range(N):
  if alive[i]:stops[i]=w[i]
 jumps=sm(z['signed_jump'] for z in delete_trace);neg=sm(z['negative_jump'] for z in delete_trace);pos=sm(z['positive_jump'] for z in delete_trace);bound=Rinitial/eg-b_initial;source_stop_R=sm(v*x*r for v,x,r in zip(nu,stops,R));checks=dict(continuous_integral_signed=Pplus-Pminus==sm(z['b_end_predelete']-z['b_start_postdelete'] for z in trace),complete_flux_identity=Pplus==bg-b_initial+Pminus-jumps,positive_negative_jump_identity=jumps==pos-neg,stopping_mass_ledger=Rinitial==continuous_R_loss+deleted_R_stop+Rfinal and source_stop_R==Rfinal+deleted_R_stop,continuous_loss_payment=all(z['continuous_minus']<=z['continuous_R_weight_loss']/eg for z in trace),negative_delete_payment=all(z['negative_jump']<=z['deleted_R_stop_weight']/eg and z['e_before']>=eg for z in delete_trace),Pplus_bound=Pplus<=bound,nu_R_bound=bound<=nR/eg,beneficial_positive_jumps=Pplus+pos<=bound,monotone_e=all(z['e_start']>=z['e_end_predelete']>=eg for z in trace))
 return dict(name=name,stage=stage,nu=nu,R_fixed=R,w_initial=initial,times=times,scores_R_nonR=scores,delete_after=deletes,trace=trace,deletions=delete_trace,initial_R_weight=Rinitial,nu_R=nR,e_initial=einitial,e_g=eg,b_initial=b_initial,b_g=bg,Pplus=Pplus,Pminus=Pminus,sum_signed_jumps=jumps,sum_negative_jumps=neg,sum_positive_jumps=pos,continuous_R_loss=continuous_R_loss,deleted_R_stop_weight=deleted_R_stop,terminal_survivor_R_weight=Rfinal,source_stop_weights=stops,terminal_virtual_weights_all=w,terminal_alive=alive,flux_bound_initialR_over_eg_minus_b=bound,nu_R_over_eg=nR/eg,wrong_terminalR_only_bound=Rfinal/eg-b_initial,wrong_terminalR_only_pass=Pplus<=Rfinal/eg-b_initial,checks=checks,scope='Fixed R labels and same-group integer scores, exact abstract clock; terminal deleted weights are virtual only, actual eg uses survivors; not physical C/FIRST/history')
def deletion_checks():
 return [deletion_case('continuous_R_low','initial',[1,1],[1,0],[1,1],[1,2],[(0,1)],[[]]),deletion_case('continuous_R_high','initial',[1,1],[1,0],[1,1],[1,2],[(1,0)],[[]]),deletion_case('mixed_batch_and_terminal_positive','stress',[1]*4,[1,1,0,0],[1,F(1,2),1,F(1,4)],[1,F(3,2),2],[(0,1),(1,2)],[[0,3],[2]]),deletion_case('near_empty_R_extinct','stress',[1,1,F(1,2**30)],[1,0,0],[1,1,1],[1,F(3,2),2],[(0,1),(1,2)],[[0,1],[]]),deletion_case('alternating_flow_four_segments','expanded',[1,2,3,5],[1,0,1,0],[F(1,2),F(1,3),F(1,4),F(1,5)],[1,F(5,4),F(3,2),F(7,4),2],[(0,1),(2,1),(2,3),(4,3)],[[1],[],[2],[3]]),deletion_case('large_mass_ratio_three_segments','expanded',[1,2**20,F(1,2**20),3],[1,0,1,0],[1,F(1,2),F(1,4),F(1,8)],[1,F(4,3),F(5,3),2],[(0,1),(1,1),(1,2)],[[1],[0],[3]])]

def main():
 joints=[check_joint(c) for c in joint_cases()];greens,long=green_checks();badcases=bad_checks();deletion=deletion_checks();fail=[r['input']['name'] for r in joints if not all(r['checks'].values())]+[g['name'] for g in greens if not all(g['checks'].values())];fail += [r['name'] for r in badcases if not all(r['checks'].values())]+[r['name'] for r in deletion if not all(r['checks'].values())]
 bad=next(r for r in joints if r['input']['name']=='bad_only_exchange');capture=next(r for r in joints if r['input']['name']=='capture_only_exchange');expected=dict(terminal_R_only_flux_bound_fails=not next(r for r in deletion if r['name']=='near_empty_R_extinct')['wrong_terminalR_only_pass'],without_X_bad_fails=not bad['without_X_bad'],without_Y_E_fails=not capture['without_Y_E'],plain_Euclidean_2_fails=next(g for g in greens if g['name']=='unequal_nu_e_star')['plain_Euclidean_witness_ratio_squared']>4);assert all(expected.values())
 data=dict(scope='Exact finite algebra and graph certificates only; no original physical FIRST/history/receiver budget certification.',joint=joints,green=greens,bad_decomposition=badcases,deletion_flux=deletion,long_chain=long,expected_failures_of_wrong_omissions=expected,unexpected_failures=fail,all_exact_pass=not fail,definitions=dict(joint_M='1E(v)1B(u) Jv*ku/Q*rho_v^2*nu_v*nu_u; totalL1, not half-TV',alpha='(c-sum E min(a,k)nu)/Q, c>=k nu',variable_gate_bound='A/2+L_E/2+Y_E+X_bad',fixed_gate_bound='A/2',Green='G=(I-B)^-1, m=e nu, exact PSD 4diag(m)-G^Tdiag(m)G',zero_rows='e0 has m0, omitted before normalization; alpha0 jointzero before mu division'),local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},runtime=dict(python=sys.version),limitations=['All source arrays/graphs are abstract finite models, not original kernel or history constructions.','No raw receiver multiplier, dx/j/window cost or nu-to-m change is paid.','Strict same gates and the two explicit exchange prices remain; alpha0 and Bcap0 branches are not divided through.','No physical quadrature, stochastic search, or fitted asymptotic order.'])
 (HERE/'joint_checks.json').write_text(json.dumps(data,indent=2,default=str)+'\n');print(json.dumps(dict(joint_cases=len(joints),green_graphs=len(greens),bad_decomposition_cases=len(badcases),deletion_flux_cases=len(deletion),max_graph_n=max(len(g['nu']) for g in greens),long_chain_n=long['n'],all_exact_pass=not fail,expected_failures=expected,unexpected_failures=fail)))
 if fail:raise SystemExit(1)
if __name__=='__main__':main()
