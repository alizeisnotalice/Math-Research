# R182 joint reserve and reversible Green certificates

All17 selected joint-reserve cases, seven baseline Green graphs, three original-form bad qualification cases, six fixed-R deletion clocks and the n128 closed-form witness pass exact Fraction checks. Each new bad case also has an A-only Green certificate. The joint constant1/2 is approached by the author's three-atom family; both gate-exchange prices are necessary. Green certificates use the actual weighted space L2(e nu), and an explicit graph fails the same constant in plain Euclidean space. These are finite algebraic/graph results, not physical FIRST/history inputs or a global column payment.

Run `python3 joint_checks.py` from any directory. Only Python's standard library and the adjacent task contract are required. The script writes `joint_checks.json` beside itself; no old JSON, vendor runtime, physical kernel or quadrature is used. Unexpected inequality failures are recorded and cause a nonzero exit. Matrix reconstruction assertions also fail with nonzero exit if a purported certificate is invalid.

## Joint definitions and independent algorithms

Use nonnegative finite nu,k,a0,a1, positive J, Q=sum Jnu>0, and c>=sum k nu. Each row has disjoint binary capture/bad masks E_i,B_i. Retain

`alpha_i=(c-sum E_i min(a_i,k)nu)/Q`,
`rho_i=[1-(k+alpha_i J)/a_i]_+`, with rho=0 at a=0,
`M_i(v,u)=1Ei(v)1Bi(u) Jv*ku/Q*rho_i(v)^2*nu_v*nu_u`.

The script verifies bad capacity k(B_i nu)<=alpha_i Q before any normalized bad density is formed. At alpha0, the raw joint matrix is already zero by this capacity; mu is left undefined. At positive alpha it independently factors M=S tensor mu, with S=alpha1E J rho^2 nu and mu=k1B nu/(alpha Q). Total mass is also checked by its separate rank-one product and bounded by k(Bnu)<=alpha Q.

Throughout this section, TV denotes **total L1 mass**, not half-L1 probability distance. Define

`Bcap=k nu(B0 intersect B1)`,
`Ci=sum Ei J rhoi^2 nu/Q`,
`Xbad=C0*k nu(B0 minus B1)+C1*k nu(B1 minus B0)`,
`Y_E=Bcap/Q*[sum_(E0 minus E1) J rho0^2 nu + sum_(E1 minus E0) J rho1^2 nu]`,
`A=sum|a0-a1|nu`,
`L_E=sum|E0-E1|nu*integral_0^1 min((1-theta)a0+theta a1,k)dtheta`.

The independently screened formulas are

`||M0-M1||L1 = Bcap/Q*sum J|E0 rho0^2-E1 rho1^2|nu + Xbad`,
`||M0-M1||L1 <= A/2+L_E/2+Y_E+Xbad`.

With fixed E/B this gives A/2. When Bcap0, the exact answer is Xbad; no alpha derivative path is used.

Algorithm1 sums every absolute entry of the two explicitly formed matrices. Algorithm2 uses the common/exclusive-bad factorization. The S-mu representation, signed capture/alpha identity and mass formula provide further independent checks. The capture interpolation integral is evaluated in two different closed forms, including equal endpoints, endpoints on k, and crossing k. At the crossing1/2->3/2,k1 it equals7/8 exactly.

Every case also checks two homogeneities: scaling nu and c by2^20 scales M by2^20; scaling a,k,c by1/1024 scales alpha and M by1/1024. This tests the original single Q denominator rather than accidentally treating the joint mass as quadratic in source scaling.

## Three stages and necessary prices

The17 joint fixtures consist of three initial fixed-gate cases; six pressure cases for a0, alpha0, changing capture/bad gates and crossing k; and eight expanded cases, comprising the five prescribed sharp parameters and three alpha-small rows. There is no source or receiver scan.

Two intended failures establish why the final prices remain:

- Bad-only exchange has A=L_E=Y_E=0 but total L1=Xbad=32/243. Omitting Xbad fails exactly.
- Capture-only exchange has A=Xbad=0 and L_E=1/1024, yet total L1=Y_E=9914935142401/17643776000000, approximately.56195. Omitting Y_E fails despite the small capture amount.

A zero-alpha endpoint followed by a changed gate produces joint mass1/32 entirely through Xbad. It is not included in a fixed-gate claim. The three alpha-small fixtures have alpha=epsilon/3 for epsilon1/4,1/64,1/1024. Their mu mass can remain1 while their joint masses remain bounded by epsilon and tend to zero by the explicit algebraic family. No artificial inverse-alpha blowup is introduced.

For the author's three-atom sharp family, nu=(1,1,1), epsilon1/N, k=(1,epsilon,1), J=(epsilon,1,epsilon), c=2+epsilon, E={r,v}, B={u}. Set alpha0=(1+epsilon)/(1+2epsilon), a0=(1-epsilon,epsilon+2alpha0,0), and increase only a_r by epsilon/2. Direct matrix L1/A, the rho-based formula, the closed rational expression

`N^4(4N+5)/[2(N+2)(2N^2+3N+2)^2]`

and all five author-supplied exact fractions agree. The ratios for N2,4,16,64,256 are approximately .1015625,.2117202,.3976984,.4717118,.4927402. The closed formula has limit1/2. N changes a three-atom algebraic parameter, not ambient dimension; no dimensional order or physical realization follows.

## Weighted reversible Green operator

For finite positive nu, symmetric0<=Kij<=1, set

`ei=sum Kij nu_j`, `mi=ei nu_i`, `Pij=Kij nu_j/ei`,
`Bij=Pij*1{p_j<c p_i}`, with positive p and0<c<1.

Zero-e indices have zero m and no K edges; they are removed before division. The code separately verifies stochastic P, exact detailed balance m_iPij=m_jPji and the weighted adjoint entry bound B+B*<=P. It never uses plain Euclidean symmetry of P.

For each graph with at most12 vertices, rational Gaussian elimination constructs G=(I-B)^-1. A separate finite Neumann polynomial gives the same G, and B^n=0 is checked from the strict orientation. The code then forms

`A4=4diag(m)-G^T diag(m)G`.

An exact unit-lower LDL decomposition has nonnegative diagonal pivots and reconstructs A4 entrywise. This is a finite PSD certificate for weighted operator norm<=2. The full rational matrices, pivots and reconstruction flags are retained in JSON.

The seven graphs are split into three stages:

- Initial: complete3, chain3, and a strict-threshold equality graph with B0.
- Pressure: an isolated e0 row and a strongly unequal nu/e star.
- Expanded: chain8 and a dense12 symmetric rational kernel.

The star has a plain Euclidean witness norm ratio squared31/7>4, while its weighted ratio is approximately1.002924. Thus a plain-norm version of the constant2 statement fails even in this finite class. This expected failure is recorded separately from the valid weighted certificates.

For the nearest-neighbor1/2 chain with boundary self1/2, nu1, p_i=2^-i and c3/4, G acts on the constant vector with row sums2-2^-k, k0..n-1 in reverse row order. At n128 the exact witness squared ratio is

`[4n-8(1-2^-n)+(4/3)(1-4^-n)]/n ≈3.9479166667`.

The script verifies the closed sum against the128 row-sum squares, without constructing or factorizing a128 matrix. Its explicit limit is4, supporting sharpness of norm2 for this graph class; this is not an asymptotic fit. The finite graph certificates do not identify physical C, realize original support/history, or pay the conversion from original nu to m=e nu. True dx, current gates, unique j and window costs remain outside the checker.

## Three original-form bad qualification examples

After independent screening, three additional fixed examples check the parent's exact bad split. There is no physical input search. For ambient parameter n, let `a_n=(1+(n/(n+1))^n)/3`, K_good=1, positive p,Q with Q_i>=a_n p_i, and symmetric0<=wg<=wt<=1. With a fixed symmetric binary Z, define

`b_ij=1{p_i wg_ij>Q_j}`,
`A_ij=b_ij(1-b_ji)`, `R_ij=b_ij b_ji`.

The code verifies b=A+R disjointly, A+A^T<=1 including the zero A diagonal, symmetry of R, and strict score descent `p_iQ_i>p_jQ_j` on every A edge. Every R edge satisfies

`wg_ij>a_n`,
`a_n/wg_ij < p_j/p_i < wg_ij/a_n`.

Both ratio inequalities are also checked by exact cross multiplication. No floating logarithm or log certificate is used.

The three named examples are: mutual2 with p=(1,1),Q=.5p,wg=.75; mixed3 with p=(1,1,.25),Q=.5p,wg=.75; and a nonuniform four-node example with ambient parameter n8, unequal nu, Q/p, nonconstant wg<=wt and an excluded symmetric Z edge. All hypotheses and conclusions pass exactly.

For A alone, take symmetric Kgraph=Z*wt, retain its degree e, measure m=e nu and transitions P, and set the Green B=P*A. The same exact inverse/Neumann/LDL routine certifies its weighted norm<=2. The score vector is pQ; a finite rational c_A between the largest A-edge score ratio and1 witnesses strict descent for this finite graph. This c_A is not claimed to be a uniform original gap or new source/history eligibility. The Green bound itself uses the antisymmetric-mask property.

R is retained separately and does not receive Green payment. In particular the mutual2 example has A0 and nonempty reciprocal R: its successful A-only identity operator certificate says nothing about the reciprocal traffic. These are original-form finite qualification arrays, not actual physical C/FIRST inputs or a full treatment of the original bad branch.

## Final six fixed-R deletion clocks

The last small addition uses the author's independently screened RF1 flux statement. R is a fixed label set, including sources deleted later. On the original alive support Z_t, form the complete posterior `Pi_i=1_Zt w_i nu_i/e_t`. The flux has R in its low-score u slot:

`P_R^plus=integral Pi_v Pi_u 1_R(u) (k_v-k_u)_+ dlog t`,

with the analogous negative part. The continuous identity is `b_R'=Pplus-Pminus`. For a simultaneous deletion batch, let e,b be its pre-deletion mass/proportion, d its total deleted weight and r its deleted R weight. The exact signed jump is

`Delta b=(b*d-r)/(e-d)`.

Negative jumps satisfy `(-Delta b)_+<=r/e_before<=r/e_g`. Initial state is post-initial-deletion, and terminal endpoint deletions are included once before e_g is evaluated. The checker records every signed, positive and negative jump, and verifies

`Pplus=b_g-b_initial+Pminus-sum Delta b`,
`Pplus<=initial_weighted_mass(R)/e_g-b_initial<=nu(R)/e_g`.

No division is made at a zero normalizer: every fixture retains e_g>0 and every intermediate normalizer is positive.

There are exactly six named cases in three stages: two continuous low/high-R score baselines; two pressure cases with mixed concurrent deletion, a terminal nonR positive jump and near-empty e_g with all R extinct; and two expanded cases with four alternating-flow segments or a source mass ratio spanning2^20 and2^-20. All clocks lie in[1,2], have integer scores0..4, and each class's scores are nondecreasing. R is never renamed after a deletion.

Within each segment all R sources have one common score and all nonR sources another. Thus the cross flow has one sign and its integral is exactly `max(b_end_predelete-b_start_postdelete,0)`, while the reverse difference gives Pminus. The implementation independently compares the full normalized v,u double-sum rates with the two-class factor at each segment's start, midpoint and end. This is an analytic endpoint integration for these restricted score classes, not quadrature or a method for heterogeneous within-class scores.

Each weight is propagated continuously as c_i*t^-k_i. Deleted weights continue to a virtual terminal value to make that convention explicit, but they are excluded from actual e_g. Each deleted source instead contributes its weight at its actual stop. The per-source stop ledger independently verifies

`initial_R_weight = continuous_R_weight_loss + deleted_R_stop_weight + terminal_survivor_R_weight`.

Continuous Pminus is bounded by continuous R loss/e_g, and negative deletion jumps by deleted R stop weight/e_g. The complete identity retains beneficial positive jumps with their correct negative sign; it does not charge them as extra positive flux.

The low-R no-deletion baseline has Pplus=1/6 and exactly saturates initial_R/e_g-b_initial=1/6. The mixed pressure case has Pplus13/77, positive jumps1/2 and negative jumps3/14. The extinction case has e_g=3/8589934592 and positive continuous flux despite terminal R weight0. Replacing the fixed initial-R budget by a terminal-R-only budget fails exactly there; this intended failure is recorded. The four-segment case has both continuous signs and both deletion signs, preventing a terminal-minus-initial shortcut.

These are exact abstract deletion-clock certificates only. They do not assert realization by physical clipped C weights, history selection, FIRST or actual high predicates. The restriction to two homogeneous score classes is retained. No additional kappa/high/kernel fields or original global budget is inferred.

## Isolated replay

Copied only the final checker and contract to `/tmp/r182_joint_review/` and ran it. The complete JSON matches exactly, including17 joint cases, seven baseline plus three A-only Green/LDL certificates, bad/reciprocal qualification, six deletion clocks, signed jumps, stopping ledgers, scaling checks and the closed long-chain witness. No numerical runtime, historical input or new case was introduced. The pre-addition checkpoint remains in `/tmp/r182_joint_checkpoint/`. All unexpected-failure lists are empty.
