# R182 原同储备联合权重：作者前独审

仅写本文件；不改他人、不Git、不spawn、不数值重跑、不编译PDF。初次检查时task_contract.md尚未落盘，以下依父级准确任务与已亲核R181指定RC定义独立推导，未读本轮作者稿。真实NB20完整系数不因本页联合无权稳定消失。

## 1. 联合对象先消去归一，而不把两因子分开

固定有限正ν、q,D>0、k=DK0≥0、Q=Jν∈(0,∞)，K0ν≤q，k/J积分有限。原capture ε=1_E、bad χ=1_B，E与B不交；a≥0可测有限ν-a.e.。同一原alpha定义

    alpha Q=Dq−∫ε min(a,k)dν≥0,
    ∫kχ dν≤alpha Q.

令rho(a,alpha)=[1−(k+alpha J)/a]_+，a0取0，S=ε alpha J rho²；alpha>0时μ=kχ ν/(alpha Q)，alpha0时原bad联合槽取0。准确联合测度是

    mathcalQ(dv,du)=S(v)ν(dv)μ(du)
      =[ε(v)J(v)rho(v)² k(u)χ(u)/Q]ν(dv)ν(du).      (I1)

alpha0时∫kχ=0，因此右侧同样为零，可直接以I1定义整个联合对象，而不分别比较μ/alpha。此公式不改变来源、原score、指定RC或任何support；k0处不反向重构未捕获的bad源。实际strictsoft k>0另保证alpha0时badν0，但I1作为加权对象在允许k0的一般有限代数中也无除零。

## 2. 固定capture/bad的可行无奇异稳定尺度

两行只改a为a'，固定ε、χ。记A=∫|a−a'|dν，可为扩展值。沿aθ=(1−θ)a+θa'定义原alphaθ；全线段alphaθ≥b:=∫kχ/Q，且Q dot alpha=−∫ε1_(aθ<k)dot a dν。alpha>0时对rho²有

    ∂a rho²=2(k+alphaJ)rho/a²,
    ∂alpha rho²=−2Jrho/a.

对I1积分u后系数为b。令z=alpha J/a、u=(k+alphaJ)/a，0≤z≤u≤1。直接a项

    b J ∂a rho²≤alpha J ∂a rho²
       =2zu(1−u)≤8/27,

只在a>k出现。alpha变化的L1系数满足

    2b∫ε J²rho/a dν
      ≤2∫ε J zrho dν≤Q/2,

因为zrho≤1/4。储备变化由a<k产生，与直接a支不交。因此

    ||mathcalQ_a−mathcalQ_a'||TV
       ≤(1/2)∫|a−a'|dν.                            (I2)

这里TV为联合有限测度总质量范数，不是概率TV的一半。常数1/2为安全上界，不声明最优。此比单独S稳定再估μ的1/alpha放大更准确，且不需要任意未知posterior门。

## 3. 允许两类原门变化的完整显式费用

两端ε,χ均为0/1且ε+χ≤1。可在证明中用εθ=(1−θ)ε+θε'、χθ=(1−θ)χ+θχ'的分数门，保持εθ+χθ≤1；alphaθ仍按εθ min(aθ,k)定义，故∫kχθ≤alphaθQ。该虚拟路径仅用于证明端点比较，不赋予分数门原history身份。

令B_E=∫K0|ε−ε'|ν、B_B=∫K0|χ−χ'|ν，并明确保留capture直接交换费用

    Z_E=∫_0^1dθ∫ alphaθ J rhoθ² |ε−ε'| dν.

联合密度微分有四项：a直接项、alpha调整项、ε直接项、χ直接项。前两项按§2的不交支合计≤A/2+D B_E/2；ε直接项≤Z_E（用bθ≤alphaθ）；χ直接项≤D B_B（用∫ερ²J≤Q）。得到安全的一般候选

    ||mathcalQ−mathcalQ'||TV
      ≤A/2+D B_E/2+D B_B+Z_E.                       (I3)

Z_E是显式原capture交换，不能从K0门差推掉；安全Z_E≤(2/27)∫(a+a')|δε|ν，也有Z_E≤Dq。若ε固定只保留A/2+D B_B；若两门均固定则退化I2。所有费用均无1/alpha。

alpha0与a0可先在rho中用alphaθ+δ正则化：仍有bθ≤alphaθ+δ，以上导数估计一致；δ→0时联合密度由k(u)J(v)/Q支配（总积分有限），原alpha0处bθ0联合为零，故L1极限合法。J0槽对v贡献0，无需除J；a=k折点按AC/Fubini处理。若A∞，不声称有限费；原a≤T、ν有限时A有限。以上为作者前自证的可行尺度，待合同/作者准确命题核对后定稿。

## 4. 原交通范围仍须逐项保留

I1–I3只比较固定同ν/q/D/K0/J下的无权联合有限测度。实际companion还乘p_y²QJ wt_v wt_u/(9D Q_v²et²K0_u)并带H/1_Zt/score/history、原dx、β、time、uniquej/window。该系数不是本联合TV的有界测试常数；capture/bad门交换之外，改变H、Z、后验归一和物理乘子仍产生实际费用。NB20原source/receiver耦合不能由本页稳定自动支付。一般middle/raw根阶预算不作认证。作者前检查点完成，等待父级/作者精确稿后一次后审，不扩展研究。


## 5. 作者准确joint候选的先行筛查与原Z几何

随后已读本轮task_contract.md，与§§1–4量词一致。Sol作者先发的端点费用版本也独立筛查通过：Bcap=∫k1_(B0∩B1)ν，Ci=Q^−1∫Ei J rhoi²ν，精确联合L1为

    Bcap/Q∫J|ε0rho0²−ε1rho1²|ν
      +C0 kν(B0\B1)+C1 kν(B1\B0).

后两项记Xbad。commoncapture上用aθ、εθ路径，Bcap>0保证alphaθQ≥Bcap；直接a与储备支不交给A/2，储备门变另付L_E/2，其中L_E=∫|δε|∫0¹min(aθ,k)dθν。commonbad上两个独占capture端项Y_E=Bcap/Q[∫E0\E1 Jrho0²ν+∫E1\E0 Jrho1²ν]。因此作者更锐候选为TV≤A/2+L_E/2+Y_E+Xbad。Bcap0直接仅Xbad，无需边界除alpha；固定两门退化A/2。这取代§3较保守路径费用，不声称sharpfamily未交之前已认证最优常数。

对Astra的原Z可逆候选，已直接打开R113 research.zip::proof.md 154–199、R114 research.zip::proof.md 233–250、R117 JG1既核定义。R113第174行明确原A_t是半开分区及fallback；R114 S3/S4使用同一q的H_j(t)阈值、同一森林最粗轻块和原最细格补齐，故仍是共同分区。T0是共同top格，A_jt细化它。原D_V(y)的两种norm距离限制对称，且两点同V。因此固定同omega,V,j,t,a,b,q，在y,u∈V上

    1_(u∈Z_y,t)=1_(y∈Z_u,t),
    calK(y,u)=1_Zy(u)wt(y,u)=calK(u,y).

半开块给唯一归属、h≤H闭阈值同取、strict/closed norm门同向，边界不留不对称缺口。由e_y=∫calK(y,u)νdu，得到原精确detailedbalance

    e_yν(dy)Π_y(du)=calK(y,u)ν(dy)ν(du)
                  =e_uν(du)Π_u(dy).

e0行零延拓Π0，m=eν也0，恒等式为测度身份。stationarymeasure是eν而非ν；原outerβ不能无费用，CP只将其正上放为νouter支并另留ζ_plus。heavy、terminal、原score/history均属测试门，不因kernel对称而变对称；两条邻居腿和et²仍需完整回代。不同j、receiverdependent H_x或不同窗口不能混为一图。bad给p_u<3p_y wg/K≤3p_y/K，K>3时才得到严格降p的orientation。

## 6. 父级可逆bad Green候选：作者前独筛

假定上述calK对称，P_y=calK(y,·)ν/e_y，m=eν有限（calK≤1、ν有限）。固定x,t等全部graph参数，令B为原bad orientation的子核，支持p_u<c p_y，0≤c<1，允许附加[0,1]原门。反向坏门不能同时成立，故以m为伴随有逐点kernel不等式B+B*≤P。关键不能把kernelorder误作一般PSD order；对任意复L²测试g，应先正化：

    Re<g,Bg>≤<|g|,B|g|>
      =1/2<|g|,(B+B*)|g|>
      ≤1/2<|g|,P|g|>≤||g||²/2.

P在m上Markov/可逆，B≤P给||B||≤1。0≤r<1时Neumann保证(I−rB)可逆，上述coercivity给resolvent范数≤1/(1−r/2)。对正g，G_r g=Σr^kB^k g单调且L²范数≤2||g||；Fatou得Gg=ΣB^k g∈L²，随后DCT给强收敛。复g由G|g|支配，故G为范数≤2的正算子，且有限和telescoping再取强极限给(I−B)G=G(I−B)=I，无层数费用。

e0隔离点m0直接忽略；m总质量0情形平凡。该证明不需要ν原子/坐标独立，不额外占原signed负信用。只在同一fixedgraph的L²(eν)成立，不能把ν测度无费换成eν，不能迭代跨x/t变图，也不能单凭Green2把原NB20未控系数认作已支付。候选已先筛通过，等待准确成稿及有限对称图检验说明后审。


## 7. JK全文及原来源K资格后审

已完整实读joint_reserve_kernel.md JK1–16，通过。alpha0/Bcap0联合零支、exact完整TV分拆、A/2不交支证明、L_E/Y_E/X_B端点费用和全factor单位均准确。Bcap>0给沿路alpha正下界，原a0/J0折点不产生额外项；Bcap0不求导。两个门费必要性例的32/243与capture极限9/16正确。三原子族可化为N^4(4N+5)/[2(N+2)(2N²+3N+2)²]，趋1/2，给一般代数类常数sharp而非物理实现。JK14运输常数2T||ν||sqrt(n)/b准确；JK15实际反K0/Q²/hatet²及原H未被TV抹去，JK16有界双测试的共同密度交换正确。

JK作者限a_i可积，已经涵盖原a≤T。若本任务的‘任意a’理解为有限可测且A可∞，安全扩展是共同截断a_i∧R：capture的min≤k使alpha_R收敛，joint密度由J(v)k(u)/Q支配，A_R≤A；故L1/DCT得到同一扩展值上界。此为本审补充，不要求作者扩大已足实际范围的正文。当前仅修JK5积分排版的最终SHA256为`1a8c32d32f77254674e3a2a413ae0284ef9dd8a1838ab9349fe2b18f0d1d877d`。

同时已读reversible_source_index.md，并直接打开R116 research.zip::proof.md 125–137、R117 proof.md 59–67/264–278/155–162/183–201。R116允许一般K>0，但R117具体低/高拆分第272行明确取K=1；没有将原既定分支免价改成K>3的继承。一般bad只推出p_u<3p_y wg≤3p_y。Green方向互斥实际仅需p_u<p_y，不需要统一c<1；因此原bad必须至少分为严格降响应支与p_y≤p_u<3p_y的未付近可比支，等响应边不纳入Green。此覆盖修正已发父级/Astra，不能把Green用于全部原bad。

R117 JG14的原born资格和ν(A)≤h(A)已实读；183–200行明确heavy fallback未扩张不能冒充light帽，只有真light节点可套h(A)≤H_j(t)。这些条件用于Astradegree分解时须保留原heavy资格及fallback补集。


## 8. Green全文与完整bad切分的最终范围

已完整实读reversible_green_budget.md G1–G7，通过其固定图数学。正化后用kernelorder而不误称PSD order；Neumann、coercivity、正函数单调/Fatou及复函数支配给Green2和两边inverse均充分。G7从L²(eν)转原ν的F²/e、eH²代价精确，e0原ν的k0项单留；参数直积分不等于跨变图的乘积。抽象半移位长链族确实使||G1||/sqrt(N)趋2，只证明该抽象类常数sharp，不认证原C图实现。

父级随后提出比§7‘仅p下降’更完整的原bad切分，已先独筛再读修订全文：基本bad d(y,u)=1{p_y wg>KQ_u}，asym=d(1−dT)，recip=ddT，d=asym+recip正不交，asym+asymT≤1，因此Green2可用于全部非互反基本bad，无需换K>3。正p/Q下asym还严格沿pQ下降，来自forward严格坏式和reverse-notbad的非严格式。原H/terminal/history不转置，只作为原测试保留；不能把互反或任意第三槽直接领成Green付款。

Lplus/L≤gamma及径向单调（含hard闭面）给P_s,Lplus≥gamma^(−n)p，Q≥a_n p，a_n=(1+gamma^(−n))/3。互反两坏式给wg>K a_n、Ka_n/wg<p_u/p_y<wg/(Ka_n)；Ka_n≥1互反空。K1只得到常数总阈值亏损，属于y-u bad边，不能移给y-v good边。此新exact切分覆盖全部基本bad，取代§7较保守下降支建议；两支的原weighted费用仍未因此完整支付。

## 9. 全strictsoft根阶包络的必要筛查（已撤回）

父级曾提出δ=log2/n并以phi+δh包络全strictsoft。独审即时捕获方向错误：原s>1−2^(−1/n)约为log2/n，不能推出1−s≤δ。合法s可接近下门，此时(1−s)^n趋1/2，而P_s,L≥(1−s)^n h_L^tensor n。固定b/a>1时hard尺度上确界的真实积分为1+nlog(b/a)，由内核质量1及径向立方壳n dr/r直接得到。所以全原strictsoft的这种无权L1 kernelcolumn不可能统一O(sqrt n)。

此为准确回代义务的解析筛查，不是一般弱型目标反例，也未扩大为反例扫描。父级已移除该全域包络草稿，最终scale_budget_screen.md如实记录，未以其支付RF来源根价；本轮不继续研究nearfullysoft特例。若另有限制1−s≤δ，qδ的scale-BV推导可自洽，但这不是本轮原全域资格，不能偷换。

## 10. Astra degree几何与完整删除通量全文审

已完整实读global_column_geometry.md GC1–20及RF1–4。原Z symmetry来源已在§5实读，GC7 star→path精确带e_u/e_y，η外槽须保rη(y)，ζ+无ν路径身份；auxhatΠ必须保R_y(u)R_y(v)，不能声称新中心图可逆。相邻同top时Zu的commonneighbor/lightblock/carrierboundary三分穷尽且互斥，GC9 ratio及GC10严格壳包含正确。light节点可用ν(A)≤h(A)≤H_j；heavyfallback不可套light帽。GC11几何和、GC12全soft L_n=C0sqrt(n)(1+nlog2)及GC13真实但粗O(n³/ell)来源费通过，时间须保持原[a/cj,bcj]交可定义域才有barρ_j，且真实Σj不因uniform行价后source概率已变而免费消失。

优先核验RF完整删除：固定R⊂Z_ell0（允许后来删除）、b_R=N_R/e，连续b_R'=P_R+−P_R−。一次原删除前e,b、删总质量d、删R质量r，负跳(r−bd)_+/(e−d)≤r/e，恰用r≤be；原并发删除整体计一次。e_after≥eg>0使≤r/eg。负连续flux先用et≥eg去分母，再把每个R source的ktwt积分到其原stop，得well−wstop。terminal survivor wg、deleted wstop及continuousloss合计恰为initialRwell；没有把已删source的虚拟wg算进survivor。positive跳保利好符号后上放，初端删除已在Zell0、末端删除按实际Zg只计一次；开放端点由原区间内截断。故RF1的initialRwell/eg−b_R(ell0)及≤νR/eg正确，不借原signed负信用。

互反reversebad给p_u>κ_n p_y，FIRST当前核ν容量与原high给νR/eg≤1/(2Kκ_n)。R固定于整条clock、可依x/y/g；原far正子集及A/H≤1上放后，RF3常数16Λ/(3Kκ_n)乘真实Erec上的pβ/high积分正确。先逐行统一界后保留uniquej合并，无n或time长度残费；该步骤直接覆盖原外β的η与ζ+互反部分。RF4使用已证全soft L_n给O(n^1.5)来源费，未误领sqrt n。固定接收费不是任意小epsilon吸收，NB冻结版本只经原RN比较乘e4epsilon0，不对新score套FTC。

发现一处来源身份表述需窄修：GC19外β与GC8外ν上界不能称同一个全functional；只有在同ν外槽才是两种等价表示，原β须先GC1精确η/ζ+拆分并正上放η。已反馈作者/父级；这是本稿最后来源范围修订，不影响RF1–4的直接全β粗价。等待修订句最终hash后绑定。


## 11. 修订来源句与整合稿最终范围

已实读GC19/GC8修订：只在同ν外槽上是两种等价表示；原β先按η/ζ+拆分，Cη≤Cν为正放大。末段ζ+未付明确限companion及根阶路线，不否定RF3–4的直接全β互反粗价。修订稿实算SHA待最终表统一绑定。

已完整实读父级proof.tex.txt及report.md。联合储备使用Q_J=Jν、实际companion保留Q_v²，未混淆两者；alpha0由原bad质量零处理。全bad非互反/互反切分准确，Green2仍只在原固定图L²(eν)，ν配对的F²/e、eH²与e0项保留。RF3直接对全部β正raw给16Λ/(3Kκ_n)的真实接收费，RF4只是O(n^(3/2))来源价；唯一j先行门与同窗口共同输入均明确。已撤回的全strictsoft根阶包络没有进入付款。报告保留general未闭合、RF固定系数不可任意ε吸收、非互反带权列及thirdslot同alpha几何未付，结论范围通过。

主Green G5也已实读改为‘非互反bad槽作为B’，无全bad误领。一般积分身份与本轮有限原子/图/分段钟的证据标签分离；source_provenance仅归档字节定位，不等于全部原稿通读。未运行数值，未改作者文件，未扩展研究。


## 12. 有限代码的静态后审（不代替一般证明）

已逐函数实读joint_checks.py当前主体及joint_checks.md：17个joint例以逐矩阵完整L1和common/exclusive bad因式独立比较；alpha0先验bad质量零后不除alpha；capture插值积分有两套闭式；源质量/幅度两种齐次缩放及尖锐三原子公式单位一致。测试J取正，不因此替代解析J0边界。7个baselineGreen图及3个basicbad资格例都保留Kgraph=Z·wt对称、完整e与m=eν，Green仅A非互反槽；精确inverse/有限Neumann/加权矩阵4diag(m)−Gᵀdiag(m)G的LDL重构正确。e0先从m支移除，未对原ν零度k0免费付款。plain Euclidean失败例及128链仅为抽象范数资格，未伪称物理C/FIRST/history实例。

代码3个bad例的Q≥a_n p、wg≤wt对称、pQ下降、互反比界和A-only Green测试准确；其有限c_A仅严格下降witness，不是原统一gap。JSON中的R未领Green标签限制为该图证书，不能覆盖掉解析RF另得的粗价。当前代码不检实际raw外乘子或一般物理历史；上述审核未执行脚本，也未以有限结果认证解析定理。

最后6个固定R删除钟的预筛已回作者：精确signed式Pplus=b_g−b_ell−ΣΔb+Pminus；只有每段R/非R各同score、从而导数符号固定时，连续Pplus才可用正的端点增量替代。R固定不重选，后来删除源在其stop处结束连续损失；虚拟terminal权不算survivor。待最终新增代码与父级复现说明到齐后仅核该段及证据标签，再统一冻结hash。


## 13. 原固定q的窄范围补核

父级终审提出并已修GC/TeX：q为原共同阈值，不能因书写q(x)而将接收依赖导入原Z阈值；RF只需单核上界，不需P_s,L f=q等号。本审已直接实读R117 JG3–4及R128 RT4–5：其中显写平均Q*ν≤q，不能仅凭该平均式推出单核pν≤q（单靠平均仅给3q）。RF2和RF3准确使用的资格分别是原FIRST每个合法current测试∫pν≤q，以及同窗口全共同输入的Σ_V∫pβ≤q。父级正核原fullFIRST定义定位；最终结论只在该原有资格下成立，不重定义q，也不从β/ν共同父支配本身补造核容量。以上是本轮最后窄补核，非扩展研究。

原容量疑义已消除：随后按父级准确定位，直接打开R107 research.zip::proof.md 899–917。R1第905–910行明定整个E共同常数q∈[3λ/4,λ]且P_{s(x),L_s(x)}f(x)=q；第913行σ≤μ_hi≤f。结合本轮已核ν≤f及同一窗口不交叶Σβ≤f，即得到RF2单current和RF3外全输入容量，均无需3倍。该依据是原R107共同current身份，不是Q*平均反推。故本轮保守使用≤q且原Z继续依共同固定q的修订通过，RF常数不变。


## 14. 最后固定R钟代码及证据标签

已静态全文读新增deletion_case/deletion_checks及main接线、md说明。各段R/非R同score且为非减整数，权重按(t0/t)^k传播；连续正负积分的端点公式与完整双槽rates在段内三个点的独立恒等式相符。并发删除后才推进alive、末端删除一次后计算eg；已删权可虚拟延拓，但实际eg/终端survivor显式排除。每个已删source固定一次stop，Rloss只在alive期累计。代码的signed总式、负跳r/e_before、逐source停止质量、Pplus及nuR上界方向均通过静态审核。

读取最终JSON摘要（未运行producer）：17 joint、7 baselineGreen、3 bad（各附A-onlyGreen）、6 flux，all_exact_pass=true且unexpected_failures为空；另有128链闭式。预期失败为漏X_bad、漏Y_E、错用无权欧氏范数、错用terminal-R-only预算，均为错误省略的准确标签，不是原输入反例。数值作者报告仅checker+合同隔离重放完整JSON相同，本审只核该声明与文件范围，执行真实性由父级重放记录另证。没有从这些有限证书认证全维物理核、FIRST或FULL/history。


## 15. 最终绑定与冻结

最后实读parent_verification.md、numerical_validation.md及reproduce.py。父级记录实际隔离退出0、全部非runtime JSON一致，和本审静态见到的17+7+3+6=33例及128链见证相符；三个A-only Green随bad例附带，不另冒充独立物理输入。复现入口先校验inventory，再仅复制checker/合同到全新目录执行、去runtime比较，流程与声明一致。本审未运行该入口或producer。source_provenance新增R107窄读定位正确，字节来源与通读认证仍分开。理论/代码最后修订均已读取，无待修实质问题。

冻结结论：JK固定门1/2联合稳定及显式变门费、原Z对称和degree分解、非互反固定图Green2、完整删除RF正通量与全β互反固定接收费/粗来源价通过。一般全局根阶列预算未闭合；原带权test、变图/窗口、第三槽与同alpha几何不能由本审认证为已付。全strictsoft无权根包络已撤回。以下为本审实际计算的最终SHA256，不含本审自身哈希；后者另回父级。未改任何责任外文件，冻结后停止。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `1e69a7a6718107c4887c0f94f229953a866e0e2370ec3f745fe2f002400bb26b` |
| joint_reserve_kernel.md | `1a8c32d32f77254674e3a2a413ae0284ef9dd8a1838ab9349fe2b18f0d1d877d` |
| global_column_geometry.md | `6bc6b2b5a66fbf219a86fbf42d077859ea20f9fb0f5a0444ae8637a1d40aeab7` |
| reversible_green_budget.md | `9ad6f63da5886100f551abbadcde635f8ed71c01cb91faf8608385989f26dc5f` |
| scale_budget_screen.md | `af7d10f4c8c85f5f02e463063f894fca142f4dfc11e6e7339ea04b68a45bbce1` |
| proof.tex.txt | `e90e345f2a05e64a72cc646163ec980441b88e39e3ffd644c049ebdb6a0c3914` |
| report.md | `34e62ec10ee97e400c0e8234a5d66b32a548bbbff946cb36cdcf3a03d06f0603` |
| reversible_source_index.md | `f2465f85baa0d986aa3f5b87d246ed070407fb123c39985eab6b3cedb9fb44cd` |
| source_provenance.json | `79ed813e28a22de15a69dfb303bbb875f28c1cb7af0aa66489e49cd01ec6fb11` |
| joint_checks.py | `7a232708e02730a87d9bf631aae1a83bb0c0e8ec5f3331561f49c88c787d2b35` |
| joint_checks.json | `bb5c697519354107c570e9d7631dd78add95e9c5d6d41e0fd850d8e873ab0873` |
| joint_checks.md | `bd26e3cc446f07f2b688f122e896e60c92b79e9b3ec46c97b203a55195734637` |
| numerical_validation.md | `cebc6b57c60bb21f84578410cfb5dae5adbd256ed3ce6fd14417ede63dc57bec` |
| parent_verification.md | `1f667265c9d0a6bc71d4efb639b14b0042afbb3fdbb93c565074d592b88bc21c` |
| reproduce.py | `cf12fea7d01e6b641528eb19950b7659c94e5fd541089e4eeceeb31f5c433339` |
