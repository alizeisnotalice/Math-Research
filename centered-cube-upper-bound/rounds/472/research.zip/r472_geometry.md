# R472：实际全部阶段的特征核与加权迹恢复缺陷

**结果与界限。** R471 的 Schur 界可合法带入全部实际 \(a_i^e,b_i,\theta_i^e\)，且不收阶段数。本稿把原费用精确识别为加权迹，并给同一真实中心分割的恢复公式。尚未构造同时控制共享来源重数和实际标记方差的分割，因此没有新增完整根阶付款。

沿原合同，\(\mu=f\,dx\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(\sigma=q_A\,dA\)、\(X=\sigma(E)\)。实际费用为
\[
 R=\sum_{i,e}\int\sigma(dA)\int\pi_A(dy)\pi_A(dz)
 a_i^e(A,y)b_i(z)\theta_i^e(A,y,z).
\tag{1}
\]
其中 \(0\le a_i^e\le B_e\)、\(S=\sum_eB_e\)、\(\sum_i b_i(z)\le1\)、\(0\le\theta_i^e\le1\)。\(\theta\) 是原合同中的真实历史 RN 平均；没有替换实际流、更新阶段或赋辅助父历史。

## 1. 父依赖标记无需伪装成全局来源函数

取 Hilbert 空间
\(\mathcal H=L^2(\{(i,e)\}\times\mathbb R^{2n},\text{counting}\otimes\mu\otimes\mu)\)，定义
\[
 \Phi_A(i,e,y,z)=\frac{c_A(y)c_A(z)}{m_A^{3/2}}
 \sqrt{a_i^e(A,y)b_i(z)\theta_i^e(A,y,z)}.
\]
它保留全部父依赖。令 \(I_{AB}=\mu(Q_A\cap Q_B)\)。逐点
\[
 \sum_{i,e}b_i(z)
 \sqrt{a_i^e(A,y)a_i^e(B,y)\theta_i^e(A,y,z)\theta_i^e(B,y,z)}
 \le S.
\]
故实际 Gram 核满足
\[
 0\le\langle\Phi_A,\Phi_B\rangle_{\mathcal H}
 \le S\frac{I_{AB}^2}{(m_Am_B)^{3/2}}=:S H(A,B).\tag{2}
\]
固定 \(A\)，R471 的真实质量 CDF 计算给
\(\int H(A,B)\sigma(dB)\le4r\)；核对称。于是
\[
 \mathcal U g=\int\sigma(dA)g(A)\Phi_A,
 \qquad \|\mathcal U\|_{L^2(\sigma)\to\mathcal H}\le2\sqrt{rS}.\tag{3}
\]
这是将 \(\sum_i b_i\le1\) 在同一来源 \(z\) 上使用一次，不是逐阶段 Schur 后求和。对有符号 \(g\) 用绝对值及正核，所有可数和按 Tonelli。有限实际中心集、\(m_A\ge qa^n>0\) 保证此处定义良好。

但是原费用不是 (3) 对某个免费测试函数的二次型。令
\(\Psi_A=\sqrt{m_A}\Phi_A\)，则
\[
 \boxed{\quad R=\int\|\Psi_A\|_{\mathcal H}^2\sigma(dA)
       =\int m_A\|\Phi_A\|_{\mathcal H}^2\sigma(dA).\quad}\tag{4}
\]
这是加权迹。\(\|\Psi_A\|^2\le S\) 只给旧界 \(R\le SX\)；不能删除 \(\sqrt{m_A}\)，也不能将迹直接用算子范数代替。

## 2. 同一中心分割的准确恢复及全部成本

取实际中心集的可数可测分割 \(E=\bigsqcup_j C_j\)，删除 \(\sigma\)-零块，写 \(s_j=\sigma(C_j)>0\) 和
\[
 \overline\Psi_j=s_j^{-1}\int_{C_j}\Psi_A\sigma(dA),\qquad
 \mathcal V_{\mathcal C}
 =\sum_j\int_{C_j}\|\Psi_A-\overline\Psi_j\|^2\sigma(dA).
\]
Hilbert 方差恒等式与 (3) 给
\[
\begin{split}
 R&=\sum_j s_j\|\overline\Psi_j\|^2+\mathcal V_{\mathcal C},\\
 \sum_j s_j\|\overline\Psi_j\|^2
 &=\sum_j\left\|\mathcal U\!\left(
        \frac{\sqrt{m_A}1_{C_j}(A)}{\sqrt{s_j}}\right)\right\|^2
 \le4rS\sum_j\frac{\int_{C_j}m_A\sigma(dA)}{s_j}.\tag{5}
\end{split}
\]
同一个完整匹配把右侧准确写为一次来源积分：
\[
 N_{\mathcal C}(x)=\sum_j\frac{\int_{C_j}c_A(x)\sigma(dA)}{s_j},
 \qquad
 \boxed{R\le4rS\int N_{\mathcal C}\,d\mu+\mathcal V_{\mathcal C}.}\tag{6}
\]
没有把每块平均质量估成独立 \(W\)，也不需要块内 \(m_A\) 上确界。方差另有准确形式
\[
 \mathcal V_{\mathcal C}
 =\frac12\sum_j\frac1{s_j}
 \int_{C_j\times C_j}\|\Psi_A-\Psi_B\|^2\sigma(dA)\sigma(dB).\tag{7}
\]
其中交叉项保留同一个 \((i,e)\)、\(b_i\) 及真实 \(\sqrt{a_i(A,y)a_i(B,y)\theta_i(A,y,z)\theta_i(B,y,z)}\)。它不是已支付的旧负平方信用，没有重复扣费。

还能把几何与标记缺陷同时显式保留。令
\(e_A(y,z)=c_A(y)c_A(z)/m_A\)、
\(v_A(i,e;y,z)=\sqrt{a_i^e b_i\theta_i^e}\)，在原域外零延拓，故 \(\Psi_A=e_Av_A\)、\(\sum v_A^2\le S\)。写
\[
 \mathcal M_A(A,B)=\int e_A(y,z)^2\sum_{i,e}|v_A-v_B|^2d\mu(y)d\mu(z).
\]
用 \(\Psi_A-\Psi_B=(e_A-e_B)v_A+e_B(v_A-v_B)\)、平方三角不等式，再交换 \(A,B\) 平均，得到
\[
 \|\Psi_A-\Psi_B\|^2
 \le4S\left(1-\frac{I_{AB}^2}{m_Am_B}\right)
       +\mathcal M_A(A,B)+\mathcal M_B(A,B).\tag{8}
\]
几何项来自准确的 \(\|e_A-e_B\|_2^2=2(1-I_{AB}^2/(m_Am_B))\)。标记项包括实际阶段和历史的变化；不能因两父几何接近而删掉它。将 (8) 放入 (7) 只给正上界，不额外提供可扣信用。


若能对**同一分割**证明
\[
 \int N_{\mathcal C}d\mu\le C_1(\epsilon)s\log^a(n+2)W,
 \qquad
 \mathcal V_{\mathcal C}\le\epsilon X+C_2(\epsilon)s\log^a(n+2)W,
\]
则 (6) 给完整原费用，来源系数准确为 \(4rS C_1+C_2\)。本稿未证明该共同几何条件。粗分块减少来源重复，却可能留下真实阶段/接受差异；细分可利用可测性逼近特征、减小方差，却会增加 \(N_{\mathcal C}\)。仅凭父 cube 邻近不能免费控制 \(\theta\) 差异，薄边界体积也不能控制 \(f\) 质量。缺口因此是同一中心分割对**实际特征方差与完整来源重数**的同时控制，不是再证明无标记算子界。到此停止。

## 3. 有限实际中心/来源接口检查

指定 Python 实际运行下面的 Fraction 检查。完整非均匀 \(f\) 位于三个长度 \(1/50\)、中心 \(-.83,0,.83\) 的区间，质量 \((3,1,8)\)。父中心块在 \(-.4,.4\)，长度各 \(1/100\)，边长 \(1,9/5\)，精确捕获 \(\{1,2\},\{2,3\}\)，质量 \(4,9\)、\(q_A=4,5\)。三个有限标记模型仅满足本节用到的真实静态界，不认证原 stage/clock/strict-gap 历史；不能作为原目标的实例或反例。代码核同阶段 Gram、(4)–(7) 和共享来源成本。

```python
from fractions import Fraction as F
from itertools import product
mu=list(map(F,(3,1,8)))
capture=[(1,1,0),(0,1,1)]
mass=[F(4),F(9)];roots=[F(2),F(3)]
qa=[F(4),F(5)];sigma=[q/F(100) for q in qa]
r=F(5,4);S=F(5,4);X=sum(sigma)
labels=list(product(range(2),range(2),range(3),range(3)))
weights=[mu[y]*mu[z] for i,e,y,z in labels]
def inner(x,y):return sum(w*a*b for w,a,b in zip(weights,x,y))
def addavg(vectors,cell):
    sj=sum(sigma[a] for a in cell)
    return [sum(sigma[a]*vectors[a][j] for a in cell)/sj
            for j in range(len(labels))]
checks=0
for seed in range(3):
    psi=[]
    for a in range(2):
        row=[]
        for i,e,y,z in labels:
            active=(a+y+i+seed)%3!=0
            theta=(a+i+y+2*z+e+seed)%4!=0
            sqrt_ab=F(1,2) if e==0 else F(1,4)
            row.append(capture[a][y]*capture[a][z]*active*theta
                       *sqrt_ab/mass[a])
        psi.append(row)
    gram=[[inner(psi[a],psi[b])/(roots[a]*roots[b])
           for b in range(2)] for a in range(2)]
    for a,b in product(range(2),repeat=2):
        I=sum(mu[y]*capture[a][y]*capture[b][y] for y in range(3))
        H=I**2/(roots[a]*roots[b])**3
        assert gram[a][b]<=S*H;checks+=1
        diff=[x-y for x,y in zip(psi[a],psi[b])]
        va=[mass[a]*x for x in psi[a]]
        vb=[mass[b]*x for x in psi[b]]
        mark=[]
        for parent in (a,b):
            value=F(0)
            for j,(i,e,y,z) in enumerate(labels):
                ep=F(capture[parent][y]*capture[parent][z])/mass[parent]
                value+=weights[j]*ep**2*(va[j]-vb[j])**2
            mark.append(value)
        assert inner(diff,diff)<=4*S*(1-I**2/(mass[a]*mass[b]))+sum(mark)
        checks+=1
    for a in range(2):
        assert sum(sigma[b]*gram[a][b] for b in range(2))<=4*r*S
        checks+=1
    R=sum(sigma[a]*inner(psi[a],psi[a]) for a in range(2))
    assert R<=S*X;checks+=1
    for partition in ([[0,1]],[[0],[1]]):
        meanenergy=F(0);variance=F(0);cost=F(0);sourcecost=F(0)
        for cell in partition:
            sj=sum(sigma[a] for a in cell)
            avg=addavg(psi,cell)
            meanenergy+=sj*inner(avg,avg)
            cost+=sum(sigma[a]*mass[a] for a in cell)/sj
            for a in cell:
                diff=[x-y for x,y in zip(psi[a],avg)]
                variance+=sigma[a]*inner(diff,diff)
            sourcecost+=sum(mu[y]*sum(sigma[a]*capture[a][y]
                                for a in cell)/sj for y in range(3))
        assert R==meanenergy+variance;checks+=1
        assert meanenergy<=4*r*S*cost;checks+=1
        assert sourcecost==cost;checks+=1
print('PASS',checks,'Fraction actual-block/interface assertions; no original-history claim')
```

实际运行 stdout（指定本机 Python）：

```text
PASS 51 Fraction actual-block/interface assertions; no original-history claim
```
