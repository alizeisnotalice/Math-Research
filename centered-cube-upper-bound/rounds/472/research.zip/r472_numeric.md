# R472：真实Gram算子、项目分解费用与有价中心分组

结论：本场的H确为T T*，Schur/Gram界可精确结算；但父依赖a的最优Hilbert项目费用是核范数，不能用Frobenius替代。新增的Ψ-trace分组公式给出另一合法有价接口：trace=variance+mean，mean按来源质量的cell平均付款。阶段来源不交仍不会自动消去cover重复。未认证原history或root价格。

## 实际连续场

来源packets中心(-83/100,0,83/100)，半宽1/100，质量(25,144,81)，f在每包为常密度，W=250。实际父centerblocks中心(-2/5,2/5)，长度(1/100,9/500)，side(1,9/5)。整个中心块分别捕获{左,中}、{中,右}，严格capture/miss边距逐项核验；各域内部不交，跨域允许相交。

完整父质量m=(169,225)，sqrt m=(13,15)，q=(169,125)，r=169/125，σ-cell质量=(169/100,225/100)，τ=volume/R=(1/100,1/100)，X=197/50。为真实qband、单octave、L1 full f；原strict-K²、高rank、stage/history未实现。所有有限矩阵都是整块连续积分，非任意incidence。

## 1. H与真正T

Tu(A)=m_A^-3/2∫c_A(y)c_A(z)u(y,z)dμ²。用连续source-pair常值子空间的标准正交基直接得到有理T矩阵；其余正交方向被T消去。Gram精确为

H(A,B)=I_AB²/(m_A m_B)^(3/2)，T T*=H（parent测度σ）。

规范父基下两个特征值为1921/422500、6529/422500，所以

||T||=sqrt(6529)/650≈.12431111952625。

实际Schur rows为17897/1098500、2393/162500，最大值≥||T||²且≤4r。Gram/特征根/正定性全为精确有理证书，未使用浮点SVD。

## 2. 原m^-2与项目费用

原积分为R_i=∫σ(dA)m_A^-2∫c_A(y)c_A(z)a_i(A,y)b_i(z)dμ²。

若a=Σα_j(A)u_j(y)，准确分解是Σ⟨α_j/√m,T(u_j⊗b_i)⟩。父范数中的1/√m不可遗漏。对已给a，最优费用

C_i=infΣ||α_j/√m||_L2σ ||u_j||_L2μ
=||M_i||_*，M_Aj=sqrt(σ_A μ_j/m_A)a_i(A,j)。

本场所有M_i有理。rank1用显式分解和rank1 norm1 dual；rank2用正交行分解和正交行dual，pairing达到相同值，故得到严格最优核范数证书。这亦认证连续空间最优值，因为cell-constant投影为收缩。

| a模式 | C_i | Frobenius | 原R（b=整中包） | ||T||C_i||b||界 |
|---|---:|---:|---:|---:|
| 两父中包权(1,1/2)，rank1 | 3/sqrt5 | 同C_i | 1.687782… | 2.001370… |
| 父1只选左包、父2只选右包，rank2 | 7/5 | sqrt(106)/10≈1.02956 | .731418… | 2.088427… |

确有F²≤X，但这不是核范数费用，不能据此把Σ项目乘积换成平方和。此例用于区分费用，不声称已否定任何额外结构下的一般界。

## 3. 来源阶段不交及共同输入

令b1、b2分别为中包左/右半段，各质量72，b1+b2≤1，Σ||b_i||²=144≤W。阶段1用rank2 a；阶段2在父1左包权1/2、父2右包权1/3。实际a均保留且≤1。

C1=7/5、C2=11/20。逐stage项目总费为117sqrt2/10≈16.54630；擅用Frobenius会给约12.04974，未获得该较小费用的证明。原阶段总R=53379/105625≈.5053633；合法逐stage算子界≈2.056889。

把同一实际(y,z)整体作为共同输入重新做项目分解，仍付其自己的核范数：M_pair为两行正交，最优费3sqrt10/2+18sqrt5/5≈12.79326，算子界≈1.590345。它确实比逐stage求和低，但仍非Frobenius，更没有被证明按原W预算支付。

## 4. 新root有价cover接口

同一两阶段取静态theta=1（没有赋原接受/history权），定义

Ψ_i(A;y,z)=m_A^-1 c_A(y)c_A(z)sqrt(a_i(A,y)b_i(z))。

令Γ_i(A,B)=⟨Ψ_i(A),Ψ_i(B)⟩/sqrt(m_A m_B)，J_AB,i=∫overlap b_i dμ。实际核验

Γ_i≤Be I_AB J_AB,i/(m_A m_B)^(3/2)，
Σ_Bσ_BΓ_i(A,B)≤4rBe β_i(A)，β_i=μ_bi(QA)/mA，Be=1。

因此traceΣσ_A||Ψ_i(A)||²精确等于原R_i。对每个中心分组C按σ取均值，标准Hilbert variance恒等式准确成立。由sqrt(m_A m_B)≤(m_A+m_B)/2、Γ对称及row界，

meanenergy_C≤4rBe avg_σ,C μ_bi(QA)。

程序核两个实际partition：两父同组或各自分组，逐stage以及sumstage全部保留。

| partition | 总trace | 总variance | 总meanenergy | Σ_i,C avg_C μ_bi(QA) |
|---|---:|---:|---:|---:|
| 两父同组 | 53379/105625 | 9966051/41616250 | 2619/9850 | 144 |
| 各自分组 | 53379/105625 | 0 | 53379/105625 | 288 |

每行精确满足trace=variance+mean，且mean≤4rBe乘最后列。b1+b2≤1仍只控制来源预算，cover把同一中包重复平均：分组cover价288甚至大于W=250。它不是原目标的反例，而是明确的cover重叠/variance权衡；不能把cell平均和直接改成一次W。这一接口可绕开直接项目范数，但必须同时支付variance及cover multiplicity，尚未完成原根阶结算。

## 运行与冻结

实际108项exact/interval断言（含geometry、Gram、attaining projective dual、normalization与partition），不是108个独立模型。仅一个实际连续场，两单stage模式、一组disjoint stages及同场两个partition。SymPy1.14.0作精确有理/根式证书，Arb224bit比较与显示，无solver/新扫描。

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r472_numeric.py
```

Python3.12.14，运行约.10秒。JSON含全部矩阵、dual、原R、cover/root身份及compute_index。输入自含，输出自身目录；decimal和计时仅元数据。

冻结白名单：r472_numeric.py、r472_numeric.json、r472_numeric.md。完成停止。所有原接受history资格、全局项目/cover预算和root恢复仍未认证。
