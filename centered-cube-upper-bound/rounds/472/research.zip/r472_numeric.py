from fractions import Fraction as F
from pathlib import Path
import json,sys,platform,time
import sympy as s
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=224;start=time.perf_counter();checks=0

def ck(z):
 global checks
 assert z
 checks+=1

def eq(a,b):ck(s.simplify(a-b)==0)
def A(x):
 x=s.sympify(x)
 if x.is_Rational:return arb(int(x.p))/arb(int(x.q))
 if x.is_Add:return sum((A(t) for t in x.args),arb(0))
 if x.is_Mul:
  z=arb(1)
  for v in x.args:z*=A(v)
  return z
 if x.is_Pow:
  b,e=x.args
  if e==s.Rational(1,2):return A(b).sqrt()
  if e==s.Rational(-1,2):return 1/A(b).sqrt()
  if e.is_Integer:return A(b)**int(e)
 raise ValueError(x)

sources=[-s.Rational(83,100),0,s.Rational(83,100)];mu=list(map(s.Integer,(25,144,81)))
centers=[-s.Rational(2,5),s.Rational(2,5)];side=[s.Integer(1),s.Rational(9,5)]
volume=[s.Rational(1,100),s.Rational(9,500)];halfsource=s.Rational(1,100)
capture=[];margins=[]
for a in range(2):
 row=[];mr=[]
 for j in range(3):
  distance=abs(centers[a]-sources[j]);maxdist=distance+volume[a]/2+halfsource;mindist=max(0,distance-volume[a]/2-halfsource)
  if maxdist<side[a]/2:row.append(1);mr.append(side[a]/2-maxdist)
  else:ck(mindist>side[a]/2);row.append(0);mr.append(mindist-side[a]/2)
 capture.append(row);margins.append(mr)
ck(capture==[[1,1,0],[0,1,1]])
ck(abs(centers[0]-centers[1])>(volume[0]+volume[1])/2)
m=[sum(mu[j]*capture[a][j] for j in range(3)) for a in range(2)]
q=[m[a]/side[a] for a in range(2)];sig=[q[a]*volume[a] for a in range(2)];tau=[volume[a]/side[a] for a in range(2)];X=sum(sig);W=sum(mu);r=max(q)/min(q)
ck(m==[169,225]);ck(tau==[s.Rational(1,100)]*2)
for mass in mu+m:ck(s.sqrt(mass).is_Rational)
I=s.Matrix(2,2,lambda a,b:sum(mu[j]*capture[a][j]*capture[b][j] for j in range(3)))
H=s.Matrix(2,2,lambda a,b:I[a,b]**2/(m[a]*m[b])**s.Rational(3,2))
# Continuous normalized source-pair cell basis and L2(sigma) parent basis.
T=s.Matrix(2,9,lambda a,jl:s.sqrt(sig[a]*mu[jl//3]*mu[jl%3])*capture[a][jl//3]*capture[a][jl%3]/m[a]**s.Rational(3,2))
G=(T*T.T).applyfunc(s.simplify)
weightedH=s.diag(*map(s.sqrt,sig))*H*s.diag(*map(s.sqrt,sig))
ck(G==weightedH);ck(G[0,0]==G[1,1]==s.Rational(1,100))
lamplus=s.factor(G[0,0]+G[0,1]);lamminus=s.factor(G[0,0]-G[0,1]);ck(lamminus>0)
ck((G-s.eye(2)*lamplus).det()==0 and (G-s.eye(2)*lamminus).det()==0)
op=s.sqrt(lamplus)
rowschur=[sum(sig[b]*H[a,b] for b in range(2)) for a in range(2)];schur=max(rowschur)
ck(lamplus<=schur<=4*r)

def projective(M):
 gram=(M*M.T).applyfunc(s.simplify);frob2=s.factor(s.trace(gram))
 if s.simplify(gram.det())==0:
  cost=s.sqrt(frob2);dual=M/cost;kind='rank1 decomposition; dual Gram eigenvalues 1,0'
  QG=(dual*dual.T).applyfunc(s.simplify);eq(s.trace(QG),1);eq(QG.det(),0)
 else:
  ck(gram[0,1]==gram[1,0]==0)
  rownorm=[s.sqrt(gram[a,a]) for a in range(2)];cost=sum(rownorm);dual=s.diag(*[1/z for z in rownorm])*M
  ck((dual*dual.T).applyfunc(s.simplify)==s.eye(2));kind='orthogonal-row decomposition; dual rows orthonormal'
 dualpair=s.simplify(sum(dual[a,j]*M[a,j] for a in range(2) for j in range(M.cols)))
 eq(dualpair,cost)
 # Explicit row/rank1 projective decomposition gives the same upper, so nuclear optimum certified.
 nonnegative=s.simplify(cost**2-frob2);ck(nonnegative.is_nonnegative or A(nonnegative)>0)
 return dict(cost=cost,frob2=frob2,dual=dual,gram=gram,dual_pairing=dualpair,certificate=kind)

def solve_one(name,aa,g_mass):
 aa=s.Matrix(aa)
 ck(all(0<=aa[a,j]<=capture[a][j] for a in range(2) for j in range(3)))
 M=s.Matrix(2,3,lambda a,j:s.sqrt(sig[a]*mu[j]/m[a])*aa[a,j])
 cert=projective(M);ck(cert['frob2']<=X)
 original=sum(sig[a]/m[a]**2*sum(mu[j]*capture[a][j]*aa[a,j] for j in range(3))*g_mass for a in range(2))
 # All z input is in the shared central packet, captured by both actual parents.
 direct_factor=0
 for a in range(2):
  for j in range(3):
   alpha_over_root=aa[a,j]/s.sqrt(m[a])
   Tu_g=capture[a][j]*mu[j]*g_mass/m[a]**s.Rational(3,2)
   direct_factor+=sig[a]*alpha_over_root*Tu_g
 eq(original,direct_factor)
 bound=op*cert['cost']*s.sqrt(g_mass);ck(A(bound-original)>0)
 return dict(name=name,a=aa,source_g_mass=g_mass,M=M,projective_certificate=cert,original_R=s.factor(original),factorized_exact_R=s.factor(direct_factor),
 factor_bound=bound,factor_bound_arb=str(A(bound)),original_R_arb=str(A(original)),
 projective_cost_arb=str(A(cert['cost'])),frob_arb=str(A(s.sqrt(cert['frob2']))))
rank1=solve_one('common_rank1',[[0,1,0],[0,s.Rational(1,2),0]],s.Integer(144))
rank2=solve_one('parent_dependent_rank2',[[1,0,0],[0,0,1]],s.Integer(144))
stage1=solve_one('stage1_left_half_z',[[1,0,0],[0,0,1]],s.Integer(72))
stage2=solve_one('stage2_right_half_z',[[s.Rational(1,2),0,0],[0,0,s.Rational(1,3)]],s.Integer(72))
stages=[stage1,stage2]
sourcebudget=2*s.Integer(72);ck(sourcebudget<=W)
perstage_cost=sum(z['projective_certificate']['cost']*s.sqrt(72) for z in stages)
naive_frob_cost=sum(s.sqrt(z['projective_certificate']['frob2'])*s.sqrt(72) for z in stages)
ck(A(perstage_cost-naive_frob_cost)>0)
# A legitimate common SOURCE-PAIR input factorization, retaining stage disjointness.
# This is a new projective norm on (y,z), not replacing nuclear by Frobenius.
Mpair=s.Matrix(2,6,lambda a,col:s.sqrt(sig[a]*mu[col//2]*72/m[a])*stages[col%2]['a'][a,col//2])
jointcert=projective(Mpair)
ck(A(perstage_cost-jointcert['cost'])>0)
Rstages=sum(z['original_R'] for z in stages);stagebound=op*perstage_cost;jointbound=op*jointcert['cost']
ck(A(stagebound-jointbound)>0);ck(A(jointbound-Rstages)>0)
# Homogeneity and denominator bridge: m^-2 = m^-1/2 * m^-3/2.
mm=s.Symbol('mm',positive=True);eq(mm**(-2),mm**(-s.Rational(1,2))*mm**(-s.Rational(3,2)))
# Per-stage Frobenius budgets do not certify sum of nuclear costs.
for z in stages:ck(z['projective_certificate']['cost']**2>=z['projective_certificate']['frob2'])
# Root's paid cover interface: Psi=m^-1 captured sqrt(a_i(y)b_i(z)).
# b_i are the same two disjoint central half-packets, each mass72.
Be=s.Integer(1);cover_stages=[]
for stage in stages:
 aa=stage['a'];Jab=s.Matrix(2,2,lambda a,b:s.Integer(72)*capture[a][1]*capture[b][1])
 Ya=s.Matrix(2,2,lambda a,b:sum(mu[j]*capture[a][j]*capture[b][j]*s.sqrt(aa[a,j]*aa[b,j]) for j in range(3)))
 Gamma=s.Matrix(2,2,lambda a,b:s.simplify(Ya[a,b]*Jab[a,b]/(m[a]*m[b])**s.Rational(3,2)))
 PsiGram=s.Matrix(2,2,lambda a,b:s.simplify(Ya[a,b]*Jab[a,b]/(m[a]*m[b])))
 beta=[s.Integer(72)/m[a] for a in range(2)]
 actualrow=[sum(sig[b]*Gamma[a,b] for b in range(2)) for a in range(2)]
 for a in range(2):
  for b in range(2):ck(Gamma[a,b]<=Be*I[a,b]*Jab[a,b]/(m[a]*m[b])**s.Rational(3,2))
  ck(actualrow[a]<=4*r*Be*beta[a])
 trace=sum(sig[a]*PsiGram[a,a] for a in range(2));eq(trace,stage['original_R'])
 partition_results=[]
 for label,partition in (('one_group',[[0,1]]),('separate',[[0],[1]])):
  meanenergy=0;variance=0;budget=0;cells=[]
  for C in partition:
   sc=sum(sig[a] for a in C)
   mean=sum(sig[a]*sig[b]*PsiGram[a,b] for a in C for b in C)/sc
   var=sum(sig[a]*sig[b]*(PsiGram[a,a]+PsiGram[b,b]-2*PsiGram[a,b]) for a in C for b in C)/(2*sc)
   massaverage=sum(sig[a]*72 for a in C)/sc
   rowbridge=sum(sig[a]*m[a]*sum(sig[b]*Gamma[a,b] for b in C) for a in C)/sc
   ck(mean>=0 and var>=0);ck(mean<=rowbridge);ck(rowbridge<=4*r*Be*massaverage)
   meanenergy+=mean;variance+=var;budget+=massaverage
   cells.append(dict(parent_indices=C,sigma_mass=sc,meanenergy=mean,variance=var,average_source_b_mass=massaverage,row_bridge=rowbridge))
  eq(trace,variance+meanenergy);ck(meanenergy<=4*r*Be*budget)
  partition_results.append(dict(partition=label,cells=cells,trace=trace,variance=variance,meanenergy=meanenergy,cover_mass_budget=budget,geometry_bound=4*r*Be*budget))
 cover_stages.append(dict(stage=stage['name'],J_AB=Jab,source_sqrt_overlap=Ya,normalized_Gram=Gamma,Psi_Gram=PsiGram,
  beta=beta,Schur_rows=actualrow,row_bound=[4*r*Be*z for z in beta],partitions=partition_results))
cover_aggregate=[]
for k in range(2):
 total_trace=sum(z['partitions'][k]['trace'] for z in cover_stages)
 total_variance=sum(z['partitions'][k]['variance'] for z in cover_stages)
 total_mean=sum(z['partitions'][k]['meanenergy'] for z in cover_stages)
 coverbudget=sum(z['partitions'][k]['cover_mass_budget'] for z in cover_stages)
 eq(total_trace,Rstages);eq(total_trace,total_variance+total_mean)
 ck(total_mean<=4*r*Be*coverbudget)
 partition=([[0,1]] if k==0 else [[0],[1]])
 allmass_budget=sum(sum(sig[a]*m[a] for a in C)/sum(sig[a] for a in C) for C in partition)
 ck(coverbudget<=allmass_budget) # b1+b2=1 on shared packet and zero elsewhere.
 cover_aggregate.append(dict(partition=cover_stages[0]['partitions'][k]['partition'],trace=total_trace,variance=total_variance,
  meanenergy=total_mean,sumstage_cover_mass_budget=coverbudget,source_partition_budget_bound=allmass_budget,geometry_bound=4*r*Be*coverbudget))

def enc(x):
 if isinstance(x,s.MatrixBase):return [[str(x[a,j]) for j in range(x.cols)] for a in range(x.rows)]
 return str(x)
out=dict(scope='Exact continuous wholecapture static operator and Hilbert projective factorization diagnostics; no original stage/history/root payment',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,arb_precision_bits=ctx.prec,checks=checks,
 geometry=dict(source_centers=sources,source_halfwidth=halfsource,source_masses=mu,source_density=[z/(2*halfsource) for z in mu],
 parent_centers=centers,parent_sides=side,parent_center_volumes=volume,capture=capture,strict_margins=margins,masses=m,q=q,sigma=sig,tau=tau,X=X,W=W,qband_ratio=r,
 original_gate='original strict K^2/high-rank/history not satisfied or claimed'),
 paid_cover_interface=dict(Be=Be,stage_certificates=cover_stages,sumstage_partitions=cover_aggregate,
 source_budget='b1+b2=1 on central packet, 0 elsewhere; sum_i int b_i dmu=144',
 warning='cover budget is a sum of per-cell sigma-averaged source masses, not automatically W'),
 operator=dict(H=H,T_normalized_basis=T,Gram=G,eigenvalues=[lamminus,lamplus],opnorm=op,opnorm_arb=str(A(op)),
 actual_Schur_rows=rowschur,actual_Schur_bound=schur,known_square_root_bound=4*r),
 single_stage_cases=[rank1,rank2],stage_disjoint=dict(z_intervals=['[-1/100,0]','[0,1/100]'],z_mass_each=72,
 source_L2_budget=sourcebudget,stages=stages,direct_R=Rstages,perstage_projective_fee=perstage_cost,
 wrong_Frobenius_replacement=naive_frob_cost,common_source_pair_matrix=Mpair,common_pair_projective_certificate=jointcert,
 perstage_factor_bound=stagebound,common_pair_factor_bound=jointbound,perstage_bound_arb=str(A(stagebound)),common_pair_bound_arb=str(A(jointbound)),
 direct_R_arb=str(A(Rstages))),
 identities=dict(T='Tu(A)=m_A^-3/2 int c_A(y)c_A(z)u(y,z)dmu²',Gram='TT*=H(A,B)=I_AB²/(m_A m_B)^3/2 on L²(sigma)',
 projective='inf sum ||alpha_j/sqrt(m)||L²sigma ||u_j||L²mu = nuclear norm M_Aj=sqrt(sigma_A mu_j/m_A)*a_Aj',
 denominator='Original m_A^-2 requires alpha/sqrt(m_A) in parent norm; omitting it changes the integral',
 stage='Source z supports disjoint gives sum ||g_i||²=144 but does not replace sum projective fees by Frobenius',
 joint='A separate common (y,z) projective factorization can reduce perstage sum; its own nuclear fee remains, not claimed to have global W budget'),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r472_numeric.py',
 arithmetic='SymPy exact rational/radical Gram, eigen and attaining projective primal/dual; Arb224 inequalities; no SVD solver or scan',seconds=time.perf_counter()-start))
(ROOT/'r472_numeric.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',s.__version__)
print('m',m,'X',X,'qband',r,'lambda+',lamplus,'op',A(op))
for z in (rank1,rank2,stage1,stage2):print(z['name'],'C*',z['projective_cost_arb'],'F',z['frob_arb'],'R',z['original_R_arb'],'bound',z['factor_bound_arb'])
print('stage R',A(Rstages),'perstage fee',A(perstage_cost),'wrong F fee',A(naive_frob_cost),'common pair fee',A(jointcert['cost']))
print('stage factor bound',A(stagebound),'commonpair bound',A(jointbound))
for z in cover_aggregate:print('cover',z['partition'],'trace',z['trace'],'variance',z['variance'],'mean',z['meanenergy'],'massbudget',z['sumstage_cover_mass_budget'])
print('PASS',checks,'exact/interval assertions; 1 actual continuous field, 2 single-stage patterns and 1 disjoint-stage comparison')
