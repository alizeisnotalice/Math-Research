# R472：原接受权到二来源 \(L^2\) 算子的费用核查

本稿没有得到新的原全余付款。已核准一个保父依赖的正因子分解接口，并定位其不可省的费用：原合同控制的是 Hilbert–Schmidt 能量，而所需配对一般是 projective/trace 费用；两者不能因 \(T\) 的维度无关算子界而互换。

设 \(\mu=f\,dx,\ \sigma=q_A\,dA,\ W=\mu(\mathbb R^n),\ X=\sigma(E),\ r_0=\lambda/q\)，
\[
 Tg(y,z)=\int_E\frac{c_A(y)c_A(z)}{m_A^{3/2}}g(A)\sigma(dA),
 \qquad \|T\|_{L^2(\sigma)\to L^2(\mu^2)}\le C_0=2\sqrt{r_0}.
\]
这里采用本轮已证算子界，不重复其证明。原费用准确为
\[
 R=\sum_{i,e}\int \sigma(dA)\pi_A(dy)\pi_A(dz)\,
 a_i^e(A,y)b_i(z)\theta_i^e(A,y,z),                         \tag{1}
\]
其中 \(a_i^e\le B_e,\ \sum_eB_e=S,\ 0\le\theta_i^e\le1\)，
\(b_i=(\delta g_i/f)(1-s/D_i)_+\)，在 \(f=0\) 处置零，
\(\sum_i b_i\le1\)。全部旧门仍在 \(\theta_i^e\) 中。

## 1. 合法的正因子配对与其真实费用

若在实际捕获集上有可测非负分解
\[
 a_i^e(A,y)=\sum_j\alpha_{iej}(A)u_{iej}(y),
\]
且以下右侧有限，则只将 \(\theta\) 正上放为1，Tonelli 与 \(T\) 的界给
\[
\begin{split}
R
&\le \sum_{i,e,j}
 \left\langle T\!\left(\frac{\alpha_{iej}}{\sqrt{m}}\right),
                  u_{iej}\otimes b_i\right\rangle_{\mu^2}\\
&\le C_0\sum_{i,e,j}
 \left\|\frac{\alpha_{iej}}{\sqrt m}\right\|_{L^2(\sigma)}
 \|u_{iej}\|_{L^2(\mu)}\|b_i\|_{L^2(\mu)}.                 \tag{2}
\end{split}
\]
不要求各父使用同一旧来源权，但不能把 \(\alpha/\sqrt m\) 改成
\(\alpha\)，也不能将右侧的和改为各项平方和的平方根。
若只找到支配分解 \(a_i^e\le\sum_j\alpha_j u_j\)，同样成立，但新增外放松也保留在 (2) 的费用中。未证明任意原 \(a_i^e\) 有廉价正分解。

为明确原合同为何不足，定义一个阶段的捕获加权核
\[
 G(A,y)=\frac{c_A(y)a(A,y)}{\sqrt{m_A}}.
\]
实际已知的能量是
\[
 \|G\|_{L^2(\sigma\otimes\mu)}^2
 =\int\sigma(dA)\int\pi_A(dy)a(A,y)^2\le B^2X.             \tag{3}
\]
这是 HS 量。令
\[
 T_b^*u(A)=\frac1{m_A^{3/2}}
       \left(\int_{Q_A}u\,d\mu\right)\left(\int_{Q_A}b\,d\mu\right).
\]
其算子范数不超过 \(C_0\|b\|_2\)，但它的 HS 范数准确为
\[
 \|T_b^*\|_{\rm HS}^2
 =\int\sigma(dA)\,[\pi_A(b)]^2.                           \tag{4}
\]
按旧来源正交基展开后，原父依赖配对需要 trace/HS 配对；
(3) 与 (4) 只能恢复
\[
 R_{\rm one\ stage}\le B\sqrt X
       \left(\int[\pi_A(b)]^2d\sigma\right)^{1/2},         \tag{5}
\]
仍是父占用费用。只知道 \(T_b^*\) 的算子范数不能在 (5) 中删去 rank 或 HS 费用。
原 \(D_i\) 单调、\(\sum_i b_i\le1\) 也没有在合同中给出 (2) 的可求和 projective 范数。

## 2. 不按阶段重付的合法粗界

可先在原 (1) 中整体聚合
\[
 A(A,y,z)=\sum_{i,e}a_i^e(A,y)b_i(z)\theta_i^e(A,y,z)
 \le S.
\]
因此无需按阶段重复算子费用，便有
\[
 R\le S\langle1,T(m^{-1/2})\rangle
 \le C_0 S W\left(\int_E\frac{\sigma(dA)}{m_A}\right)^{1/2}
 \le C_0 S W\sqrt{\frac X{qa^n}}.                         \tag{6}
\]
所有门是正上放而非重新赋给辅助父。(6) 的 Young 形式是
\[
 R\le\varepsilon X+
       \frac{C_0^2S^2}{4\varepsilon\,qa^n}W^2.            \tag{7}
\]
它不是一次 \(W\) 的根阶价格；\(W/(qa^n)\) 没有维度一致上界。
这里明确保住了质量的半次幂，没有把缺失的来源尺度隐藏在常数中。

若要仅通过 (2) 得到目标，一个足够但尚未证明的**具体**比较是：
对保同一原接受权的正因子支配，能把该 projective 总费用控制为
\(C n^{1/4}\log^A(n+2)\sqrt{XW}\)，或给出与原门对应的等价 trace 预算。
Cauchy–Schwarz 后才可得到
\(\varepsilon X+C_\varepsilon\sqrt n\,\mathrm{polylog}(n)W\)。
本稿没有取得这个比较，也不把它作为新定理。

高 \(Z_A\)、低 \(C_A(y,z)\) 是带父质量前缀的条件，
既不把 \(a_i^e(A,y)\) 变成全局 \(u(y)\)，也未提供上述 trace 费用。
当前实际缺口是将原接受流的父—来源相关性转换成有来源总账的正分解；
不能以无标记 \(T\) 的 \(L^2\) 有界性直接宣称已完成这个恢复。
旧平方、删除或时钟信用没有在本稿再次扣除。

## 3. 实际有限代数核验

以下 Fraction 检查已实际运行，共通过 15 项断言。第一组仅核 trace 与 operator/HS 的区别；
第二组直接核父分母的半次幂，使用 \(m=t^2\) 避免浮点。
它们不是原匹配场反例或高秩历史模型。

~~~python
from fractions import Fraction as F
checks=0
# Identity map: operator norm 1, HS norm squared N, trace N.
for N in [1,2,4,8]:
    trace=F(N); hs2=F(N); op2=F(1)
    assert trace*trace==F(N)*hs2*op2
    if N>1:
        assert trace*trace>hs2*op2
        checks+=1
    checks+=1
# A single parent integrates c(y)c(z) against source mass m^2.
# T(alpha/sqrt(m)) has precisely the original m^-2 density.
for t in [F(1,2),F(1),F(2),F(3)]:
    m=t*t; alpha=F(3,5)
    original=alpha/m**2
    correct=(alpha/t)/t**3
    dropped=alpha/t**3
    assert correct==original
    assert dropped/original==t
    checks+=2
print("PASS",checks,"Fraction trace/scaling assertions; no native-history claim")
~~~
