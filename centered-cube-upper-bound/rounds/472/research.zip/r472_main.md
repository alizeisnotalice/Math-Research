# 第472轮：真实阶段加权的共同来源覆盖与特征方差

## 结论范围与本轮决策

本轮对同一个原接受积分建立阶段加权 Schur 行界及精确的分割恢复公式。不同阶段可采用不同中心分割，来源预算仍在同一来源上利用累计阶段容量，不含阶段数。恢复式保留真实接受标记、历史权和组内方差。

这是一项一般接口估计，不是一般根阶上界闭合：尚未构造同时具有低来源重复费用与小实际特征方差的分割族。下一步应研究这两个量的联合几何预算，而非再次证明无标记算子有界性。原全局宽距离、低强度、初始、删除跳跃、未来被删来源、极端尺度、全比例带拼接和总吸收系数的既有未付项目全部保留。

## 1. 冻结原合同与来源

令 \(\mu=f\,dx\)，\(f\ge0\)、\(W=\mu(\mathbb R^n)<\infty\)。实际 Lebesgue 中心 \(A\in E\) 的可测单值边长满足 \(a\le R_A\le b\le2a\)，\(a>0\)；\(Q_A\) 为以 \(A\) 为中心、边长 \(R_A\) 的立方体。记
\[
 c_A=1_{Q_A},\quad m_A=\mu(Q_A)=q_AR_A^n,\quad
 0<q\le q_A\le\lambda,\quad r_0=\lambda/q,\quad
 \sigma(dA)=q_A\,dA,\quad X=\sigma(E),\quad \pi_A=c_A\mu/m_A.
\]
所有来源质量由完整 \(f\) 计算；没有截断后重算 \(m_A\)。原阶段标记
\[
 b_i(z)=\frac{\delta g_i(z)}{f(z)}(1-s/D_i(z))_+,\qquad
 \sum_i b_i(z)\le1
\]
在 \(f=0\) 处置零。原端点密度 \(a_i^e(A,y)\) 满足 \(0\le a_i^e\le B_e\)。第413轮主稿第3b节明确定义 \(B_u=\beta,B_v=C_{\rm col}\)，故 \(\sum_eB_e=S=\beta+C_{\rm col}\)，不另乘端点数。真实历史、两条路径、soft、early、初始严格质量间隔及当前全部正限制保留于其原 RN 条件平均 \(0\le\theta_i^e(A,y,z)\le1\)。本轮研究的同一个积分为
\[
 R=\sum_{i,e}\int_E\sigma(dA)\int\pi_A(dy)\pi_A(dz)
 a_i^e(A,y)b_i(z)\theta_i^e(A,y,z). \tag{1}
\]
此处对原流使用精确表示；证明中的核支配只用于上界。辅助父不继承任何原历史。一般静态模型仅能检查这些代数接口，不能认证原全流的历史门。

现有合同给 \(X\le A_nW\)，\(A_n=1+n\log(b/a)\)，故 \(R\le SX<\infty\)。固定比例带内 \(m_A\ge qa^n>0\)，\(m_A\le W\)，\(\sigma\) 有限。本轮所有 Hilbert 积分可先在有限阶段/简单函数上证明，再用正性、\(L^2\) 收敛或 Tonelli 扩展到可数阶段；不进行有符号无控制极限交换。

## 2. 逐阶段来源加权行界

对每 \((i,e)\) 定义 \(\mathcal H_0=L^2(\mu\otimes\mu)\) 中的真实特征
\[
 \Phi_{A,i,e}(y,z)=\frac{c_A(y)c_A(z)}{m_A^{3/2}}
       \sqrt{a_i^e(A,y)b_i(z)\theta_i^e(A,y,z)},\qquad
 K_{i,e}(A,B)=\langle\Phi_{A,i,e},\Phi_{B,i,e}\rangle.
\]
令
\[
 I_{AB}=\mu(Q_A\cap Q_B),\quad
 J_{AB,i}=\int c_Ac_B b_i\,d\mu,\quad
 \beta_i(A)=m_A^{-1}\int c_A b_i\,d\mu.
\]
这里 \(\beta_i\) 不同于端点容量常数 \(\beta\)。由接受权正性，
\[
 0\le K_{i,e}(A,B)\le
 \frac{B_e I_{AB}J_{AB,i}}{(m_Am_B)^{3/2}}. \tag{2}
\]
核对称，即便 \(a\) 和 \(\theta\) 强烈依赖父也成立。

**命题。** 对每个实际父 \(A\)，
\[
 \int_EK_{i,e}(A,B)\sigma(dB)\le4r_0B_e\beta_i(A). \tag{3}
\]
证明保留真实中心测度。固定来源 \(z\)，Lebesgue 质量 CDF 为
\[
 F_z(t)=|\{B\in E:z\in Q_B,\ m_B\le t\}|\le t/q. \tag{4}
\]
因为这些中心全部位于以 \(z\) 为中心、边长 \((t/q)^{1/n}\) 的立方体内；只扩大中心集合，不对扩大后的父声明原质量条件。对 \(m>0\) 令
\[
 w_m(t)=\frac1t\sqrt{\frac{\min(m,t)}{\max(m,t)}}.
\]
此函数递减，\(\int_0^\infty w_m(t)dt=4\)。Stieltjes 分部积分与 (4) 给
\(\int w_m(t)dF_z(t)\le4/q\)。闭 CDF 包含质量原子，分部积分合法：零端 \(w_m(t)F_z(t)\le\sqrt{t/m}/q\to0\)，无穷端趋零；实际 \(m_B\) 还具有正下界和有限上界。

以 \(I_{AB}\le\min(m_A,m_B)\) 展开 (2) 的 \(J\)，并用 \(q_B\le\lambda\)：
\[
\begin{split}
 \int K_{i,e}(A,B)\sigma(dB)
 &\le\frac{B_e}{m_A}\int_{Q_A}b_i(z)\,d\mu(z)
       \int_{z\in Q_B}w_{m_A}(m_B)q_B\,dB\\
 &\le4r_0B_e\beta_i(A).
\end{split}
\]
全过程不将边界体积替代来源质量。

对任意实或复 \(g\in L^2(\sigma)\)，正核、对称性和 \(2|g(A)g(B)|\le|g(A)|^2+|g(B)|^2\) 随即给
\[
 \left\|\int g(A)\Phi_{A,i,e}\sigma(dA)\right\|^2
 \le4r_0B_e\int\beta_i(A)|g(A)|^2\sigma(dA). \tag{5}
\]
这是保阶段来源权的估计，不将每阶段的右侧都换成 \(X\) 再相加。

## 3. 原费用的精确恢复与可变阶段分割

置 \(\Psi_{A,i,e}=\sqrt{m_A}\Phi_{A,i,e}\)，则
\[
 R=\sum_{i,e}\int\|\Psi_{A,i,e}\|^2\sigma(dA). \tag{6}
\]
这是实际特征的迹，不能单用 \(\Phi\) 所定义算子的范数界替代。对每个 \((i,e)\) 任选一个实际中心的可数可测分割 \(\mathcal C_{i,e}=\{C_{i,e,j}\}\)，各块 \(s_{i,e,j}=\sigma(C_{i,e,j})>0\)，忽略零块。所有分割仍作用于同一原 \(E\) 和原标记；允许随 \(i,e\) 变化，不要求父独立。

按 \(\sigma\) 平均，而不是按 \(m\sigma\) 平均：
\[
 \bar\Psi_{i,e,j}=s_{i,e,j}^{-1}\int_{C_{i,e,j}}\Psi_{A,i,e}\sigma(dA),\quad
 V=\sum_{i,e,j}\int_{C_{i,e,j}}\|\Psi_{A,i,e}-\bar\Psi_{i,e,j}\|^2\sigma(dA).
\]
Hilbert 方差恒等式准确给
\[
 R=\sum_{i,e,j}s_{i,e,j}\|\bar\Psi_{i,e,j}\|^2+V. \tag{7}
\]
在 (5) 中取 \(g=\sqrt{m_A}1_{C_{i,e,j}}/\sqrt{s_{i,e,j}}\)，得
\[
 s_{i,e,j}\|\bar\Psi_{i,e,j}\|^2
 \le\frac{4r_0 B_e}{s_{i,e,j}}
          \int_{C_{i,e,j}}\int_{Q_A}b_i(x)d\mu(x)\sigma(dA).
\]
定义实际平均捕获重数
\[
 N_{i,e}(x)=\sum_j\frac1{s_{i,e,j}}\int_{C_{i,e,j}}c_A(x)\sigma(dA),\quad
 \mathcal B=\int\sum_{i,e} B_e b_i(x)N_{i,e}(x)d\mu(x).
\]
得到本轮主式
\[
 \boxed{R\le4r_0\mathcal B+V.} \tag{8}
\]
即便 \(\mathcal B=\infty\) 仍为合法扩展值上界，不隐含存在便宜分割。实际 \(V\le R\le SX\)。若能对同一族分割证明 \(N_{i,e}\le L\)，则 \(\mathcal B\le SLW\)，因为在同一个 \(x\) 上 \(\sum_i b_i(x)\le1\)。更一般可直接估加权 \(\mathcal B\)，不必要求逐点统一 \(L\)。

同一块的方差也等于
\[
 \frac1{2s_{i,e,j}}\int_{C_{i,e,j}^2}
 \|\Psi_{A,i,e}-\Psi_{B,i,e}\|^2\sigma(dA)\sigma(dB). \tag{9}
\]
(9) 保完整共同来源上的标记差；父几何邻近并不保证真实历史权邻近。几何附件给共同分割的来源重数版本及几何—标记分裂，所有项均为正费用，不把它们当作已付旧平方信用。

## 4. 总账及尚缺的准确几何命题

目标是对同一族分割证明
\[
 4r_0\mathcal B+V\le\varepsilon X+
 C_\varepsilon\sqrt n\log^A(n+2)W. \tag{10}
\]
本轮未证明 (10)。例如充分条件为 \(\mathcal B\le C_1\sqrt n\log^A(n+2)W\) 且 \(V\le\varepsilon X+C_2\sqrt n\log^A(n+2)W\)，常数实为 \(4r_0C_1+C_2\)。不能分别为两个量选择不同的分割再拼接结论。细分降低方差但增加来源重复，粗分反之；需利用原历史/高独占低共同捕获等门来同步控制。

原第458轮已保留的中间恢复母式为
\[
 R_{433}\le[S\zeta+2S\varepsilon_0/s+2S\delta_{\rm round}]X+|P|.
\]
对其任何实际正保留积分应用 (8) 时仍须保住该 \(P\) 的原 RN 标记。当前没有新的已支付 \(\varepsilon X\) 信用，不能声称上述系数与全局母账的系数和已可吸收；早期母账的乘数、全尺度和原子费用都不因本轮恢复恒等式而消失。本轮 (1) 对完整原接受积分自身成立，不需局部祖先或固定新尺度归约。

辅助稿进一步说明正因子配对的准确代价是带 \(\alpha/\sqrt m\) 的 projective 总费用；原 HS 能量不足以删除秩。其合法粗界 \(R\le2\sqrt{r_0}SW\sqrt{\int\sigma/m}\) 仍含规模比，不能算根阶来源预算。这个结果仅用于选择接下来应攻坚的桥，不新增反例筛查任务。

## 5. 实际计算与复现范围

使用用户指定独立 Python 环境，按已加载 L03 有理证书技能区分精确算术与原问题的一般证明。本轮计算决策是核对质量幂、阶段累计、来源重复与方差的兼容性；不运行无关参数扫描或编译 PDF。

初步核验：辅助附件15项 Fraction 恒等式，区分 operator/HS/trace 并确认半次质量权。压力核验：几何附件51项真实连续块接口检查，保非均匀来源、父依赖接受标记。扩大接口范围：数值附件108项，包括共享来源秩1、父依赖秩2、两阶段分源及两种分割；全部保真实正 Lebesgue 中心块。它们验证有限模型中的等式/证书，不覆盖所有维数，更未认证原 strict-gap/early/clock 历史。不存在已验证的一般阶数外推。

本轮原始计算结果、解释器版本和输入在数值附件；主代理将全部附件代码隔离重放并记录 stdout/JSON。最终以独审绑定的文件和 manifest 为准。未使用求解器“optimal”状态代替证书。子任务只在临时目录产出，主代理统一精简归档；不改变其他项目文件。

主代理补充的符号核验验证 (3) 的质量幂换算及 Stieltjes 权的两个积分，分别对 \(t<m\) 和 \(t>m\) 检查，不数值猜测常数4。

```python
import sympy as sp
m,t=sp.symbols('m t',positive=True)
wlo=1/sp.sqrt(m*t)
whi=sp.sqrt(m)/t**sp.Rational(3,2)
checks=0
assert sp.simplify(sp.integrate(wlo,(t,0,m))-2)==0;checks+=1
assert sp.simplify(sp.integrate(whi,(t,m,sp.oo))-2)==0;checks+=1
assert sp.simplify(t/(m*t)**sp.Rational(3,2)-wlo/m)==0;checks+=1
assert sp.simplify(m/(m*t)**sp.Rational(3,2)-whi/m)==0;checks+=1
assert sp.diff(wlo,t).is_negative;checks+=1
assert sp.diff(whi,t).is_negative;checks+=1
assert sp.limit(t*wlo,t,0)==0;checks+=1
assert sp.limit(t*whi,t,sp.oo)==0;checks+=1
print('PASS',checks,'SymPy weighted-row identities/endpoints; no partition construction')
```
