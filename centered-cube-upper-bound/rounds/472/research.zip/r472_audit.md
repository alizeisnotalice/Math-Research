# R472 FINAL PASS（限定实际特征核、阶段加权均值及方差恢复式）

先独立 PRE，后审冻结作者稿与主稿。通过下述一般接口及其复现；未证明存在同时使来源重数与实际标记方差可付的同一分割族，未得到原全流的根阶付款或一般弱型闭合。原母账与所有既有未付费用保留。

1. **真实行界。** R471 的质量 CDF 比较确为逐来源点/逐父界，给无标记 Gram 行界 (4r_0) 及 (T) 范数 (2\sqrt{r_0})。本轮逐 stage/end 的实际 Gram 由 (B_eI_{AB}J_{AB,i}/(m_Am_B)^{3/2}) 支配；展开带 (b_i) 的 (J)，保完整匹配与下降平方根质量权，确得 (4r_0B_e\beta_i(A))。核对称，故 (2|gg'|\le|g|^2+|g'|^2) 给主稿(5)的加权二次型；没有用不成立的普通“加权 Schur”替代。闭质量原子及两端分部积分合法。已核原 R413 第3b节的 (B_u=\beta,B_v=C_{\rm col})，端点只收 (S) 一次。

2. **原迹与同族分割。** (\Psi=\sqrt m\Phi) 的平方迹精确为原 (R)，质量半次幂不可省。对每个 ((i,e)) 独立选择可数实际中心分割，按 (sigma) 均值的 Hilbert 恒等式给 (R=\text{mean}+V)。用 (g=\sqrt m1_C/\sqrt{\sigma C}) 得均值项的来源价，合计准确为 (4r_0\mathcal B)，其中 (\mathcal B=\int\sum_{i,e}B_eb_iN_{i,e},d\mu)。若**同一族**有 (N_{i,e}\le L)，才由同源 (\sum_i b_i\le1) 给 (\mathcal B\le SLW)。不收阶段数，但未证明这样的便宜分割或对应小 (V) 存在。扩展值 (\mathcal B=\infty) 也未隐藏。零块删除、有限 (sigma)、可数阶段 Tonelli 与 (L^2) 方差极限均合法。

3. **作者补充接口。** 全 stage 特征 Gram 的 (SH) 支配及共同分割公式正确；几何/标记差异拆分的 (4S(1-I^2/(m_Am_B))) 常数与两个标记项均正确，后者不能由 cube 邻近免费删除。它们是正方差费用，不是已付旧负平方。辅助 projective 配对保 (alpha/\sqrt m)，HS式(4)及整体粗界正确；HS、trace、projective 总费用不能直接互换。正因子配对只是一个充分接口，主稿的特征/方差路径并不要求先将真实双源接受权分成独立因子。所有操作仍保原 RN 接受权，没有给辅助父 history。

4. **有限证据范围。** numeric 的 (T) 是主稿 (T) 的伴随，范数/Gram一致。所列连续整块的完整质量、核范数 attaining primal/dual、两种分割的均值加方差身份均正确。来源 stage 不交仍不消除 cell-average 重复。一个真实静态场及有限标记未认证原 strict-gap、early、clock/history；没有将有限证书外推一般分割定理。

## 独立隔离复现

指定本机 Python；目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r472_audit_119mxrgt`。提取 geometry/complement/main 内嵌代码并运行 numeric.py：51、15、8、108项断言通过，四份 stdout 与冻结 replay 逐字节一致。numeric JSON 仅删除 `compute_index.seconds` 后完全一致，规范化 SHA256 为 `410429c3bda19b7aba92fced19c1a99ad64e741b4bc6be8a26f27b30d15ff93d`。PRE辅助34项不计入本轮归档数，未增加测试范围。geometry 已修复式(5)的 TeX typo，绑定当前字节。

## 冻结输入 SHA256

- `r472_main.md`: `2ba6cb1f4c4e330cd7becd04029ad1c4038889e59246168a6a3b02efdd4fe555`
- `r472_geometry.md`: `30441e9653443bea3256344b96025fcfae1e558ec1e3dcf732a786fdccc4d344`
- `r472_complement.md`: `720d6acb950166180acca3f38d51ca21382e38b9f6b9af7225f1b57c0c898ad9`
- `r472_numeric.md`: `c01d5b20bb14a34345194a8591c6c1784d2bff6b94819c55db793d442f2bab4b`
- `r472_numeric.py`: `d24815d50a01fbfa366b8be6027a7350d005ca3d2a4502fb3340f584178c0fbc`
- `r472_numeric.json`: `1c7a9959e3bb339a1569933a4038e7c8196930e5667e6805b5500369cd6422ea`
- `r472_replay.json`: `349988843dd77a2823bfe657db2db534580a55f9a45bd19b6f692df0dd274bfe`
