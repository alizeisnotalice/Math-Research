#!/usr/bin/env python3
"""R218 finite floating-band/capture rational certificate, not FULL."""
import argparse, hashlib, json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def rat(x): return f'{x.numerator}/{x.denominator}'
def calc(n,rho):
    a=F(1,8);lo=F(1,2);hi=lo*(1+F(1,8*n));deleted=(lo+hi)/2;tau=F(1,4);h=F(3,4);g=F(1)
    w=lambda t:(a/t)**n
    h0=w(hi);drop=w(lo)-w(hi);HJ=rho*drop;HK=h0-HJ;delta=w(tau)-w(h);T=h0/((1-rho)*delta);kappa=1/T
    wg=w(g);eg=wg+(a/g)**(n-1);capture=max(F(0),1-(HK+HJ)/(T*delta));upper=HJ/eg
    primitive=lambda t,m:-rho*a/(m*a+t)
    pair=primitive(deleted,2)-primitive(lo,2)+primitive(hi,1)-primitive(deleted,1)
    checks={'HK_positive':HK>0,'HJ_positive':HJ>0,'T_positive':T>0,'capture_rho_exact':capture==rho,'kappa_T_one':kappa*T==1,'h0_HJ_plus_HK':h0==HJ+HK,'band_max_equals_HJ':rho*(w(lo)-h0)==HJ,'FTC_rho_drop_equals_HJ':rho*drop==HJ,'mixed_hi_boundary':w(hi)==h0,'mixed_lo_strict':w(lo)>h0,'pair_le_HJ_over_eg':pair<=upper,'scalar_d_less_than_one_entire_collar':wg/w(hi)<1,'scalar_d_lo_less_than_one':wg/w(lo)<1}
    assert all(checks.values())
    integrations=[]
    for dps in (40,70):
      with mp.workdps(dps):
        m=lambda z:mp.mpf(z.numerator)/z.denominator
        aa,rr,ll,dd,hh=map(m,(a,rho,lo,deleted,hi))
        def f(t,mult):
          wv=(aa/t)**n;wu=(aa/t)**(n-1);et=mult*wv+wu
          return rr*wv*wu/(et*et*t)
        value=mp.quad(lambda t:f(t,2),[ll,dd])+mp.quad(lambda t:f(t,1),[dd,hh])
        integrations.append({'dps':dps,'rho_pair_integral':mp.nstr(value,dps),'abs_error_vs_exact_fraction':mp.nstr(abs(value-m(pair)),dps),'HJ_over_eg_upper':mp.nstr(m(upper),dps),'pair_over_upper':mp.nstr(value/m(upper),dps)})
    with mp.workdps(80):diff=mp.nstr(abs(mp.mpf(integrations[0]['rho_pair_integral'])-mp.mpf(integrations[1]['rho_pair_integral'])),40)
    vals=locals(); keys=['a','lo','hi','deleted','tau','h','g','rho','h0','drop','HJ','HK','delta','T','kappa','wg','eg','capture','upper','pair']
    return {'n':n,'rational_values':{k:rat(vals[k]) for k in keys},'fixed_parameters':{'p':'1/1','L0':'1/1','kappa_T':'1/1','D':'1/1','alpha0':'1/1','epsilon':'1/1','K':'3/1','J':'HJ','K0':'HK'},'rational_checks':checks,'d_lo':rat(wg/w(lo)),'d_hi':rat(wg/w(hi)),'sources':[{'name':'target','mass':'1/1','alpha':['1/8']*n,'deletion':None,'terminal_bad':False},{'name':'bad','mass':'1/1','alpha':['1/8']*(n-1)+['1/1'],'deletion':None,'terminal_bad':True},{'name':'extra','mass':'1/1','alpha':['1/8']*n,'deletion':rat(deleted),'terminal_bad':False}],'weight_definition':'product_i min(1,alpha_i/t), independent of deletion; alive/deleted mask is separate','full_et_before_deletion':'2*(a/t)^n+(a/t)^(n-1)','full_et_after_deletion':'(a/t)^n+(a/t)^(n-1)','eg_definition':'a^n+a^(n-1)','band_support':'lo<=t<hi; mixed endpoint hi excluded; rho*(wv-h0)<=HJ','target_kv':n,'positive_pair_delta_target_minus_bad':1,'FTC_source_integral':'integral rho*n*wv dt/t = rho*(wlo-whi) = HJ','integrations':integrations,'precision_40_70_abs_difference':diff}

def main(output):
    stages=[{'stage':name,'cases':[calc(n,rho) for n in ns for rho in (F(1,4),F(1,2),F(9,10))]} for name,ns in [('initial',[2,4]),('stress',[8,16]),('expanded',[32,64])]]
    result={'schema':'R218_floating_band_finite_clock_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'stages':stages,'limitations':['Finite scalar clock and baseline capture algebra only; no real spatial kernel, global FIRST/high, source budget, or FULL claim.','d<1 verifies old scalar PG is inapplicable on this collar; it does not certify strict FULL coverage expansion.','Exact Fraction values certify these cases; ordinary mpmath quadrature is not an interval proof.','Source weights are original min products; deletion is a separate given mask.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
    print('complete',sum(len(stage['cases']) for stage in stages),'configurations')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'floating_band_checks.json');args=ap.parse_args();main(args.output)
