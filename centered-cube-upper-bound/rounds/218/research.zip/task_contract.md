# R218：捕获核差中间层与大时钟比的原预算

R217已核验推送0180bb40708140bfa40b65995e3bf3ab7f86324f；其冻结材料在/Users/zhengzhihao/Desktop/T/output/centered_cube_round217_20261016_final_checkpoint。一般任意正L1的根阶弱型目标保持。已付支为mixed内d=(3L0/K)wg/wt>=1且rho0 H+<=1，H=(K1+K2)/J−pK0/(κTL0J)，完整价格16ΛL0/(3K)WA。补域d<1与rho0H+>1必须保留。

准确任务先审后做：Astra复用r217_peak，负责原剩余中间层rho0H+>1的实际共同来源容量，保CG3双侧区间，寻找可回代预算。Sol high复用r217_compare，负责大时钟比d<1的原时钟下降/捕获/好坏联合预算，禁止仅给重复单源FTC。Sol high复用r217_audit独立先审命题与量词后看作者稿。Sol medium r217_numeric只在明确命题/计算方案后启动有限证书或物理数值。主代理负责共同预算、来源FIRST联合约束与整合。

所有分支保真实dx、来源、high/FIRST、hard一次16/3、唯一j、窗口和负信用一次；不能ν<=β，Wν<=WA。原ρ0辅助时间固定，但g/history/p依x，不能误移。先前已用w不能再归一；本轮可以从原未付正项另给备选上界。任何新负账消费必须精确不交。

文件职责仅本轮各自文件：Astra middle_capacity.md，辅助large_clock.md，独审audit.md，数值按后续指定；主代理其它。大家共享工作区，不能覆盖他人、Git、自增Agent或无限扩任务。交付准确命题/完整证明/费用/成功或具体缺口。完成停等。不要求满员。不编译PDF。核验后精简归档，单独commit/push。

最终主命题调整为全soft、任意shift、0<L≤b的半密度hard-face根阶以及积分内soft选择的包络；保留真实hard内上迹，不将核几何冒充原来源预算。辅助为capture加权浮动mixed带的真实J来源价；相同正集只支付一次。主代理soft_face_envelope.md；Sol整合proof.tex.txt；Astra另写traffic_bridge.md精确辨别aux clock与physical面流。以上均属于本轮未完成归档，未预报推送。
