# R218 精准桥接诊断：辅助时钟交通不等于物理尺度硬面生产

结论：原 RT1–6、R170、R211 中，辅助 t 与当前物理 L 是不同变量。可证明的准确时钟变差身份和来源壳层换元如下；它们都没有产生接收点 x 的 hard 面测度。全软度面包络因此尚未连到原 middle 正交通。缺的第一步是原泛函到物理尺度变化的实际恒等式或单向支配，早于 Hellinger 权/来源列预算。本稿不写反例，也不把这个尚不存在的桥替换成“某来源测度总质量≤W_A”的抽象要求。

已读本轮 soft_face_envelope.md，并窄读 R128 proof.md 604–669（RT1–6）、R170 research.zip::shell_traffic_bridge.md S1–S7 与 source_pair_tool_contract.md SP3、R211 research.zip::joint_capacity.md JC28–30。只写本文件，无 Git、无其它 agent、不改别人文件。

## TB1　原准确对象及变量冻结

在原有限截断上，记完整行 r=(ω,V,j,x,y,z,history)，原外测度为

\[
 d\mathcal T(r)=1_I1_{\{j(x)=j\}}Q^{-1}p_y(x)h_{R(x)}(x-z)
 a_\omega(x,y,z)\,dx\,\beta_V(dy)\nu_V(dz).
 \tag{TB1}
\]
外有 EΣ_V,j；Q 为原共同 FIRST 水平。为避免与外 hard 来源 z 混淆，原 bad 辅助来源记 u。当前未付正项准确具有

\[
 \mathcal P=\mathbb E\sum_{V,j}\int1_{high}\,d\mathcal T(r)
 \int_{J_{far}}\iint
 M(r,t,v,u)\rho_0(r,v)(k_t(v)-k_t(u))_+
 \,\Pi_t(dv)\Pi_t(du)\,{dt\over t},
 \tag{TB2}
\]
其中 M∈[0,1] 只收集实际 G×B、mixed、FA、Ψ、middle/浮动超额及剩余历史指示，不新增独立性。ρ0 是 R211 已有基线；该替换的恢复价已付，所有依原 ρ 的门保持原值。原完整 Π_t=1_Zt wtν/e_t，两个分母均保留。

固定 r 后，s(x)、L(x)、R(x)、g=√(LR)、T、K0、当前核 K1/K2/J、capture α0 和 ρ0 都固定。t∈J_far⊂[τ_j,h]，τ_j=a/c_j、h=gexp(−u0/n)，只是原来源时钟。其作用是

\[
 \alpha_i(y,v)={b\over c_j}C(|y_i-v_i|/b),\quad
 w_t(v)=\prod_i\min(1,\alpha_i(y,v)/t),\quad
 k_t(v)=\#\{i:\alpha_i(y,v)<t\}.
 \tag{TB3}
\]
**当前 p_y=P_s,L(x−y) 在这一 t 变化中不变化。** g 对 t 的上端约束不等于 L=t，亦不提供一个 L(t) 的演化路径。

## TB2　真实的时钟变差与 source-pair 身份

避开有限 source 阈值或按 a.e. 意义，

\[
 -\partial_{\log t}w_t(v)=k_t(v)w_t(v).
\]
权严格正时，因 w_t 连续局部绝对连续，得到准确身份

\[
 \boxed{(k_t(v)-k_t(u))_+w_t(v)w_t(u)
 =w_t(u)^2\left[-\partial_{\log t}
 {w_t(v)\over w_t(u)}\right]_+.}
 \tag{TB4}
\]
正部是 a.e. 导数正部；来源阈值处 w_t 本身连续，没有 physical hard 跳。把 TB4 代回 TB2 可精确写成

\[
 \int_{J_{far}}\iint
 M\rho_0\,{1_{Z_t}(v)1_{Z_t}(u)\over e_t^2}\,w_t(u)^2
 \left[-\partial_{\log t}{w_t(v)\over w_t(u)}\right]_+
 \,\nu(dv)\nu(du)\,{dt\over t}.
 \tag{TB5}
\]
这保原归一化、支持和全部 gate。它是来源对权比的正变差，不是 ∂_logL p 或 x 的 coarea 流。w_t(u)^2/e_t²、M 和 Z_t 仍随 t 变，不能把正变差积分直接换成一份免费端点差。

在无删除跳的固定支持子段还有

\[
 \partial_{\log t}(\Pi_t\otimes\Pi_t)(v,u)
 =[2\bar k_t-k_t(v)-k_t(u)](\Pi_t\otimes\Pi_t)(v,u),
 \tag{TB6}
\]
故 pair 概率的导数是分数的和及归一化漂移，不是差的正部。实际 Z_t 删除另有支持/归一化跳。R170 的 covariance/signed 身份能够连接某些固定来源测试与 k_t 差，但必须带其 G×G、删除、suffix 和反向项；本稿未调用或消费这些负账。即使采用该身份，导数仍是来源时钟导数，而非物理 L 导数。

## TB3　唯一直接合法的阈值换元及其 Jacobian

原 RT4 的准确函数是 F(u)=max{1_[−1/2,1/2](u),φ(u)}，C(r)=∫_[−1/2,1/2]F(u−r)du，r≥0。故 C(0)=1；在0<r<1时 C′(r)=φ(r+1/2)−1<0；C(1)=∫_[1/2,3/2]φ≤∫_[1/2,∞)φ=(1−m)/2<1/2。这里 F 不是概率密度，不对它另行归一化。

原 t≥τ_j=a/c_j、t≤h≤g≤bc_j，故非空时窗准确给 ξ=c_jt/b∈[a/b,c_j²]⊂[1/2,1]（若保 h 的严格缩短，上端还可更低）。因 C 严格递减，令 r_ξ=C^−1(ξ)，并定义辅助长度

\[
 \ell(t)=2b r_\xi,\qquad
 t(\ell)={b\over c_j}C(\ell/(2b)).
 \tag{TB7}
\]
这里 ℓ 特意不用原 L 或原外 hard 尺度 R 命名。准确地

\[
 k_t(v)=\sum_i1_{\{|y_i-v_i|>\ell(t)/2\}}.
\]
由正部次可加性，逐点有

\[
 (k_t(v)-k_t(u))_+
 \le\sum_i1_{\{|y_i-u_i|\le\ell(t)/2<|y_i-v_i|\}}.
 \tag{TB8}
\]
strict k 保证外侧严格、内侧闭；原来源有面质量也无需删掉等号。

在 ξ≥1/2 的内部，rξ∈(0,r_(1/2)] 且 r_(1/2)<1：C(1)≤∫_(1/2)^∞φ=(1−m)/2<1/2。对 0<r<1，C'(r)=φ(r+1/2)−1<0。因此 t→ℓ 严格递减、局部绝对连续，Jacobians 为

\[
 \left|{dt\over t}\right|
 ={1-\phi(\ell/(2b)+1/2)\over2bC(\ell/(2b))}\,d\ell
 =\mathcal J(\ell)\,{d\ell\over\ell},
\]
\[
 \mathcal J(\ell)=
 {r[1-\phi(r+1/2)]\over C(r)},\quad r=\ell/(2b).
 \tag{TB9}
\]
由 r<1、C(r)≥1/2 以及 φ(r+1/2)≤aφ，这一原窗口内还具有有用的统一 Jacobian 控制：

\[
 {1-a_\phi\over2b}
 \le {1-\phi(r+1/2)\over2bC(r)}\le {1\over b},
 \qquad 0\le\mathcal J(\ell)\le2r<2.
 \tag{TB9a}
\]
因此实际换元不会进入 C 的远尾，也没有尾部 inverse-Jacobian 爆炸。这里是 dℓ 的 Jacobian；当 ℓ→0 时相对 logℓ Jacobian 可趋零，不能凭 TB9a 又把两个 log 变量双向等价。ξ=1 的单个端点由极限处理，log t 积分不赋额外原子。

将 TB8 与 TB9 代入 TB2 的 inner 量，得到真实单向不等式

\[
 \begin{aligned}
 &\int_{\ell(J_{far})}\sum_i\iint
 M(r,t(\ell),v,u)\rho_0(r,v)
 1_{\{|y_i-u_i|\le\ell/2<|y_i-v_i|\}}\\
 &\qquad\cdot {1_{Z_{t(\ell)}}(v)1_{Z_{t(\ell)}}(u)
 w_{t(\ell)}(v)w_{t(\ell)}(u)\over e_{t(\ell)}^2}
 \,\nu(dv)\nu(du)\,\mathcal J(\ell){d\ell\over\ell}.
 \end{aligned}\tag{TB10}
\]
不等式方向是原 inner 量≤TB10；外仍完整乘 TB1。时间集合按测度像解释，不要求原 J_far 或额外 gate 连通。

TB10 是 **两个来源位置相对 y 的壳层占用**。接收点 x 没有被置到任何面上，原 p_y(x) 仍是所选 L(x) 的体积密度。ℓ(t) 不等于 L(x)；ℓ 甚至可低于 a 或高于 b。只在单个对齐值 t=(b/c_j)C(L/(2b)) 才有 ℓ=L，该值通常在辅助时钟中是零测点，不能承载整段正交通。

若对 k_t 再作 Stieltjes 微分，得到的是 source 阈值 t=α_i(y,v) 上的原子，仍不是 x_i=y_i±L/2 的 receiver 面。把 v 或 u 换成 x 会改变 ν、Π、e 和全部 good/bad/capture，原定义没有允许这样的变量置换。

## TB4　与物理 hard 面生产的准确比较

固定 s,y，对光滑紧支测试函数 ψ(x) 且 ψ 不依 L，物理核确实满足分布身份

\[
 \partial_{\log L}(p_{s,L,y}(x)dx)
 =[-np_{s,L,y}(x)+A_{s,L,y}(x)]dx
   +d\mu^{hard}_{s,L,y}(x),
 \tag{TB11}
\]
\[
 A_{s,L,y}(x)=sL^{-n}\sum_i[-r_i\phi'(r_i)]
 \prod_{j\ne i}f_s(r_j),\quad r=(x-y)/L,
\]
\[
 d\mu^{hard}_{s,L,y}
 ={1-s\over2}\sum_{i,\sigma}
 \delta_{y_i+\sigma L/2}(dx_i)
 \prod_{j\ne i}[L^{-1}f_s((x_j-y_j)/L)dx_j].
 \tag{TB12}
\]
φ 的 a.e. 导数足够；局部绝对连续与指数尾可用分布积分证明。normalization、smooth dilation、hard jump 三部分均必须保留。积分总质量依次为 −n、ns、n(1−s)，总和零，符合核归一化。

TB11 没有在 TB2 中出现，因为原 t 演化固定 L。若人为定义 L=ℓ(t)，链式法则会额外带 dlogℓ/dlogt，且必须同时把原 p、K1/K2/K0、g、T、ρ0、high/FIRST、history 和 selector 改为一条新路径；这不是原时钟换元。对依 L 的实际交通乘子，还必须计其 ∂_logL、入口/退出及跳项。原 RT1–6 只定义当前行，未提供这条合法演化及其费用，也没有宣告该更换保原 FIRST/捕获资格。

SE1/MC10 处理的是真实 TB12 的 core 内上迹 p_y^+：

\[
 \int\sqrt{J_v/p_y^+}\,d\mu^{hard}_{s,L,y}
 =\sqrt{(L/b)/a_s}\,\Gamma_{s,L/b}((v-y)/b).
\]
TB10 中既没有 μhard，也没有这个 normal trace 因子。即使补出了 TB11 型尺度流，仍须另外证明原权如何产生 √(J/p^+)；两步不能合并为一个未说明的“coarea”。

## TB5　已有 R170 接收壳层桥能做到哪里

R170 S1 已有准确的几何比较

\[
 \delta_t\le S_\xi(x,y;\eta)+F_\eta(x,v)+F_\eta(x,u),
\]
其中 Sξ 是 ||x_i−y_i|−brξ|≤ηL 的壳层计数，Fη 是来源偏离 |x_i−v_i|>ηL 的计数。只有另交对齐门

\[
 br_\xi-\eta L>L/2,\qquad
 br_\xi+\eta L\le Le^h/2
\]
时，壳层才被物理跨界数 N_+(x,y;h) 控制。两端偏离余项和未对齐时间均保原 Π²、capture 与真实外测度，不是可删除误差。这是可用的单向桥，但它的输出是带厚度的体积壳层，不是 TB12。

即使暂只保这一壳层，也不能令厚度趋零而直接使用 SE1。对固定 s∈(0,1)、L、y，及具有外侧迹的合适非负测试 W，有准确单侧薄壳极限

\[
 \lim_{h\downarrow0}{1\over h}
 \int p_{s,L,y}(x)W(x)
 \sum_i1_{\{L/2<|x_i-y_i|\le Le^h/2\}}dx
 = {s\phi(1/2)\over2}\sum_{i,\sigma}
 \int W^{out}_{i,\sigma}\prod_{j\ne i}P_{s,L}(x_j-y_j)dx_{\hat i}.
 \tag{TB13}
\]
normal coarea 厚度为 Lh/2、旧核 normal 外迹为 sφ(1/2)/L，两者给 sφ(1/2)/2。相反 TB12 的系数是 (1−s)/2。故若 s<1，其比例是 sφ(1/2)/(1−s)，而且 TB13 用 W 的外迹，不是 SE1 的内迹。s→1 比例发散；s=1 时壳层仍有体积而 μhard=0。s=0 时旧核外壳为零而 hard 面非零。这里描述的是量和迹不同，不能据此把 R170 壳层费直接解释为已被 SE1 支付的面费。

对包含 Mρ0 及两份 Π 来源密度的实际乘子 W（Π 已各含一份 e 分母，不再额外除 e²），薄壳交换还需真实单侧迹和可积支配；这些乘子依当前 p、L、history，原合同未给此极限。若改用一个任意可测 L(x) 的空间 coarea，连所需的正则性与 |∇(|x_i−y_i|−L(x)/2)| Jacobian 都尚未定义，不能从其可测选择性推得。

## TB6　确定缺失的等式与停止结论

现有对象给出的完整链是：原时钟交通 TB2 → source-pair 权比正变差 TB5，或 source 壳层占用 TB10；加 R170 的真实偏离/对齐误差后可转为体积薄壳。没有一步生成 receiver 物理面 TB12。

因此要继续走 SE1 路线，最先需要新增而尚未给出的具体内容是：

1. 在原同一实际正积分域内，指定一个物理尺度路径或合法体积到尺度变差的比较；明确它如何从 TB2 的 δ_t 产生 TB11 的 μhard，同时计 −np、smooth dilation、原 Z/e、gate/history 和 selector 的全部变化项。
2. 若采用 R170 厚壳路线，给原权下的两端来源偏离预算、对齐窗口及 TB13 的实际迹/厚度控制，并解决其 sφ/(1−s) 比例；不能只保 N_+ 后声称其就是 μhard。
3. 仅在上述实际面关系成立后，再证明带原共同来源权的 √(J/p^+) 支配或列估计，以调用 SE1。mixed/capture 本身给的是 J/p 上界，未自动提供该半密度权。

这些是缺失的定义/恒等式，而不是已知但尚未优化的常数。本稿没有签署不存在的 coarea、没有构造新 stochastic jump process，也没有从 auxiliary source 阈值跳借用 physical hard jump compensation。没有消耗任何负账、没有得到新的 raw middle 付款。

本机 Python Fraction 对三组 k_v/k_u 符号核对 TB4，正值、负值、零值均准确；另对 (n,s)=(1,0),(16,1/3),(64,1) 核对 TB11 的总质量平衡 −n+ns+n(1−s)=0。数值仅查符号与归一化，不代替上述证明。完成后停止。
