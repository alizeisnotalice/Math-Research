# R218 辅助：大时钟支的浮动混合阈值带

状态：独立核验父级随后给出的强候选。它比先筛出的 good/clock 带更强，下面只登记这一份备选正上界，不另叠加辅助带价格。**准确结果是原 mixed 补域内一个新可回代子集的完整来源价；不是整个 $d_t<1$ 已付。** 不调用 R170 的排序或任何免费 GG 负账，不重领 R211 恢复槽。仅写本文件，未修改别人文件或 Git/spawn。

## LC1　先审实际对象及辅助时间资格

读本轮 task_contract、R217 冻结 peak_good_geometry/capture_geometry，窄核 R211 research.zip::joint_capacity JC19–30、audit §7–11，R128 research.zip::joint_receiver_tail RT1–6，R170 source_pair_tool_contract SP3 及 bridge_energy_audit §8.3–8.5；最后专门对照 R214 mixed_cap_budget/audit §5、7–8 的旧加法帽覆盖。

固定完整实际 $(\omega,V,j,x,y,g,\mathrm{history})$ 行，保同一实际 receiver $p=p_y$、核 $J_v,K_{0v}$、$T>0$、实际来源 $\nu_V$ 与 terminal target $G\subset Z_g$。FIRST 水平记 $Q_F$，与 $Q_J=\int Jd\nu$ 区分。正行中 $p,J_v,w_g(v),e_g>0$；其余零行先按原合同处理。

捕获权严格取原 R211 baseline，且只在原 eligible 集中使用：
\[
\Delta_v=w_\tau(v)-w_h(v),\quad \tau\le t\le h<g,
\quad\alpha_0=DQ_F/Q_J,
\]
\[
\rho_0(v)=\left(1-\frac{DK_{0v}+\alpha_0J_v}{T\Delta_v}\right)_+.
\tag{LC1}
\]
$T\Delta_v=0$、非eligible、$Q_J=0$ 等按原定义先零。不能另选 $\alpha_0$。所有右端均来自实际终端/历史行，**不依辅助时钟 $t$**，即使它们依赖 $x,y,g$。从原 $\rho$ 到 $\rho_0$ 的恢复差已经由 R211 的独立额度处理，本稿不再消费这份额度，也不以 $\rho_0$ 重算任何原资格或 history。

记原完整 mixed 每端阈值
\[
 h_v^0=\frac{L_0J_v}{p}+\frac{K_{0v}}{\kappa T},
\quad a_v^J=\frac{L_0J_v}{p}>0,
\quad c=3L_0/K,
\quad d_t(v)=c\frac{w_g(v)}{w_t(v)}.
\tag{LC2}
\]
完整 target mixed 正好为 $w_t(v)>h_v^0$，不是两单门的并。$h_v^0,a_v^J,\rho_0$ 固定于辅助时间；原 $w_t$ 连续非增，a.e. $-\partial_{\log t}w_t=k_t w_t$，$k_t\ge0$。$\Pi_t=1_{Z_t}w_t\nu/e_t$，terminal survival 给 $e_t\ge e_g>0$。$\Pi_t$ 本身不按测度序单调，不对此作微分。

## LC2　强候选及严格时钟证明

共同预定 $\varepsilon>0$，在当前尚未消费的实际 mixed 正交通中，保全部原两端门而截取
\[
\mathcal B_\varepsilon(v,t)=
\left\{\rho_0(v)>0,\quad
0<\rho_0(v)[w_t(v)-h_v^0]\le\varepsilon a_v^J\right\}.
\tag{LC3}
\]
可以额外交 $d_t<1$；下述强命题不需要它，也不需要用 good 门。原 good/bad、capture、FA、$\Psi$、high/FIRST、唯一 $j$ 和全部历史仍是同一实际积分的门，证明中只有对非负项的上放。先与既往已付正集不交化。

**命题。** 恢复一次原硬来源 $16/3$ 和外系数 $2\Lambda$ 后，
\[
\boxed{R^+_{\mathrm{mixed}\cap\mathcal B_\varepsilon}
\le\frac{16\Lambda L_0\varepsilon}{3K}W_\nu
\le\frac{16\Lambda L_0\varepsilon}{3K}W_A.}
\tag{LC4}
\]
取原预定 $L_0=K\sqrt n$，LC4 的来源价为 $(16\Lambda/3)\varepsilon\sqrt n\,W_A$，不附时钟长度或菜单因子。若用本命题整体替代 R217 的被包含子支，上界只取一份，不能把旧价与本价再相加。

证明首先逐实际来源固定 $x,y,v$。$\rho_0=0$ 的交通本来为零；在正行置
$\ell_v=\varepsilon a_v^J/\rho_0(v)$。LC3 给真实值域
\[
h_v^0<w_t(v)\le h_v^0+\ell_v.
\]
对任一原合法可测辅助时钟子域 $I\subset[\tau,h]$，单调下降测度给
\[
\begin{aligned}
\rho_0(v)\int_I k_t(v)w_t(v)1_{\mathcal B_\varepsilon}\frac{dt}{t}
&\le\rho_0(v)
 [\min\{w_\tau(v),h_v^0+\ell_v\}
       -\max\{w_h(v),h_v^0\}]_+\\
&\le\rho_0(v)\ell_v
=\varepsilon\frac{L_0J_v}{p}.
\end{aligned}\tag{LC5}
\]
全 $[\tau,h]$ 上第一行的未截时钟积分恰等于该夹断长度；子域只减小它。平台 $k_t=0$ 不贡献，连续 $w_t$ 的阈值端点没有额外跳质量；$h_v^0\ge1$ 时因 $w_t\le1$ 自动为空。该证明保住 **下端 $h_v^0$ 的减项**，不是重复写整段 $\int k_tw_t=\Delta$ 后丢掉它。

## LC3　保原两份来源到真实 $dx$ 的完整付款

令 $\mathrm{clock}_\varepsilon(x,y)$ 表示带 LC3 及原正门的当前行时钟/来源双积分。用
$\delta_t(v,u)=(k_t(v)-k_t(u))_+\le k_t(v)$，先只对 bad 端 $u$ 的原 $\Pi_t$ 上放其非负门并归一化，再用 $e_t\ge e_g$，得到
\[
\begin{aligned}
\mathrm{clock}_\varepsilon(x,y)
&\le\frac1{e_g}\int_G\rho_0(v)
 \int_I k_t(v)w_t(v)1_{\mathcal B_\varepsilon}
 \frac{dt}{t}\,\nu(dv)\\
&\le\frac{\varepsilon L_0}{pe_g}\int_GJ_v\nu(dv).
\end{aligned}\tag{LC6}
\]
第一步准确使用 $\int d\Pi_t(u)=1$，即原 $w_t(u)/e_t^2$ 留下一份 $1/e_t$。另一份 target $w_t(v)$ 由 LC5 消费，没有拿 R215 已吸收的权再归一化。bad 不继承 target 的 capture；其门仅在正上放中删除。真实删除只影响 $Z_t,e_t$，terminal target 始终存活，不需借原 $N_{del}$。

乘回原外 receiver $p$ 后，
\[
p\,\mathrm{clock}_\varepsilon(x,y)
\le\frac{\varepsilon L_0}{e_g(y)}J\nu_V(x).
\tag{LC7}
\]
同一原 high/FIRST 给
\[
\frac{1_{\rm high}}{e_g(y)}\le\frac{p_y}{2KQ_F},
\qquad\int p_y\,\beta_V(dy)\le Q_F.
\]
故对每个固定 $x,V,j$，在同一当前 $p,Q_F$ 下
\[
\int\beta_V(dy)1_{\rm high}\,p_y
 \mathrm{clock}_\varepsilon(x,y)
\le\frac{\varepsilon L_0}{2K}J\nu_V(x).
\tag{LC8}
\]
所有 $x$ 自适应参数已从右端消去；唯一 $1_{\{j(x)=j\}}$ 保留到此才合并，不支付虚构 $j$ 菜单，也不将 $p_y$ 当成可对 $x$ 直接归一化的固定核。固定原 block 的 $J=P_{1,b}$ 满足
$\int J\nu_V(x)dx=\|\nu_V\|$，从而 LC8 在真实 $dx$ 下闭合。恢复原硬帽和 signed 外系数只一次：
\[
(2\Lambda)(16/3)\frac{\varepsilon L_0}{2K}
=\frac{16\Lambda L_0\varepsilon}{3K}.
\]
这给 LC4。$W_\nu\le W_A$ 是原共同父账，不使用 $\nu\le\beta$ 或 $W_\nu\le W_\beta$。不同独立窗口仍按自身实际总来源账；不存在额外免费窗口。所有步骤为正上界，不消费任何存活、删除或 GG 负账；有限截断后以非负单调极限处理。

## LC4　准确包含关系：R217 和辅助候选只选一份价

沿用 R217
\[
S_v=1+B_v=1+(K_{1v}+K_{2v})/J_v,\quad
z_v=\frac{pK_{0v}}{\kappa TL_0J_v},\quad H_v=B_v-z_v.
\]
同一 good 门为 $S_v\ge3pw_g/(KJ_v)$，所以
\[
\frac{pw_t}{L_0J_v}\le\frac{S_v}{d_t}.
\tag{LC9}
\]
把 LC3 除 $a_v^J$，实际判据为
\[
0< E_t(v):=\rho_0(v)
\left[\frac{pw_t(v)}{L_0J_v}-(1+z_v)\right]\le\varepsilon.
\tag{LC10}
\]
而在 mixed/good 上
\[
0<E_t(v)\le\rho_0(v)
\left[\frac{S_v}{d_t(v)}-(1+z_v)\right].
\tag{LC11}
\]
因此 R217 的 $d_t\ge1$ 且 $\rho_0H_{v,+}\le\varepsilon$ 整体包含于 LC3：此时右端至多 $\rho_0H_v\le\varepsilon$，mixed/good 同时强迫 $H_v>0$。本命题可用同一价格替代旧支并新增 $d_t<1$ 的覆盖，而非再加一份来源价。

本辅助最初从 good 推出的统一带为 LC11 右端不超过 $\varepsilon$；它也包含于父级强带，故不再单独登记。若只取 $d_t<1$ 的较粗条件
$\rho_0S_v(d_t^{-1}-1)\le\varepsilon$，它**不一定**以同一 $\varepsilon$ 被 LC3 包含，因为 LC11 还含 $\rho_0H_v$；必须同时保该余量，或按各自阈值之和支付，不能漏项。

LC10 对 $d_t<1$ 的新增区域可直接写成
\[
cw_g(v)<w_t(v)\le
h_v^0+\frac{\varepsilon L_0J_v}{p\rho_0(v)},
\qquad w_t(v)>h_v^0.
\tag{LC12}
\]
其非空与否由同一实际行判定，不假设 FULL 实现或来源独立；若该区间为空，其交通自然为零。$\rho_0$ 小会准确拓宽可付带，仍完整保持原 capture 权。

## LC5　与 R214 的边界：新覆盖，不冒称新 FTC

R214 的固定加法帽为同一 $h_v^0$，已付事件是至少一端 $w_t\le h^0$；其未付补域两端均严格 $w_t>h^0$。LC3 在 target 上正交于旧帽，且仍交 bad 端原 mixed，因而不属于 R214 **固定原参数的字面已付子集**。旧 sourcewise 分段 FTC 已含 LC5 所用的 primitive；这里新的是保下端减项、保实际 $\rho_0$ 并将该差值回代固定 $J$ 的覆盖，不是发明新 FTC。

若 $\rho_0\equiv1$ 且 $\varepsilon=1$，在相同其它门下，新 band 与旧 target-low 的 target 时钟值域联合正是 $w_t\le 2L_0J_v/p+K_{0v}/(\kappa T)$；在这种特殊情形，重选旧帽 $2L_0$ 已能给同阶来源价，所以不能夸成新一般阶数。一般实际 $\rho_0$ 可任意小，此带的有效上帽含 $L_0(1+\varepsilon/\rho_0)$，不再是可共同预选的 $L_0$；直接套旧定理会丢失恰被 LC5 消去的 $\rho_0^{-1}$。若已有 $\rho_0\ge r_*>0$ 的实际支，旧帽也可用 $(1+\varepsilon/r_*)L_0$ 覆盖，但须明确支付该更粗价格。本稿不声称该有限覆盖相对于所有历史工具有新的 FULL 实现。

## LC6　深大时钟补域与负账保持

在父级采用 LC4 替代包含的 R217 支后，$d_t<1$ 的准确剩余为
\[
\rho_0(v)[w_t(v)-h_v^0]>\varepsilon L_0J_v/p.
\tag{LC13}
\]
它仍有两端完整 mixed、原 target good/capture、bad 和所有 actual 门。在 $C_v=DK_{0v}+\alpha_0J_v$、$T\Delta_v>C_v$ 的原正支持上，等价地
\[
(T\Delta_v-C_v)
\left[pw_t(v)-L_0J_v-\frac{pK_{0v}}{\kappa T}\right]
>\varepsilon L_0J_v T\Delta_v.
\tag{LC14}
\]
这给后续必须真正处理的共同 capture/clock 乘积；并非将一个未知积分换名为“容量”。

还可将该深层与父级其它旧补域统一为一个准确的逐点低核边界。为避免与 LC4 的 $z_v$ 混淆，本段重新显式记
\[
z=K_{0v}/J_v>0,\quad \zeta=p/(\kappa TL_0)>0,
\quad b=pw_t(v)/(L_0J_v)-1,
\]
\[
A=1-\frac{\alpha_0J_v}{T\Delta_v},\qquad
 a=\frac{DJ_v}{T\Delta_v}>0,
\quad \mathscr S_t=(A-az)_+(b-\zeta z).
\tag{LC15}
\]
实际 $\rho_0=(A-az)_+$，mixed 保 $b-\zeta z>0$，并且 $\mathscr S_t=E_t$。在实际正 target 上，$\mathscr S_t>\varepsilon$ 必须且（保原 mixed 的前提下）恰好满足 $A>0,b>0,Ab>\varepsilon$ 以及
\[
\boxed{0<z<z_\varepsilon:=
\frac{2(Ab-\varepsilon)}{
 A\zeta+ab+\sqrt{(A\zeta-ab)^2+4a\zeta\varepsilon}}.}
\tag{LC16}
\]
纯标量允许 $z=0$ 时可将左端放为 $0\le z$；实际 strictsoft 为严格 $z>0$。等号 $z=z_\varepsilon$ 属于已付 $\mathscr S_t\le\varepsilon$，不能移入剩余。

自足证明：实际 $\mathscr S_t>\varepsilon>0$ 先强迫
$0\le z<\min(A/a,b/\zeta)$，此区间上正部可以准确去掉。展开得
\[
(A-az)(b-\zeta z)-\varepsilon
=a\zeta z^2-(A\zeta+ab)z+Ab-\varepsilon.
\]
乘积在该区间从 $Ab$ 严格下降至 $0$：其导数为
$-(A\zeta+ab)+2a\zeta z<0$，因为
$2a\zeta z<2\min(A\zeta,ab)\le A\zeta+ab$。
所以超过 $\varepsilon$ 必须 $Ab>\varepsilon$，且解集是从 $0$ 至唯一较小根的严格区间。判别式准确为
$(A\zeta-ab)^2+4a\zeta\varepsilon$；将较小根有理化就得 LC16。该根严格小于 $\min(A/a,b/\zeta)$，因为阈值 $\varepsilon>0$ 的穿越发生在零点以前，故反向也成立。不能在两个因子均负的大根外支误去正部。

LC16 的 $b$ 实际含同一来源的 $w_t(v)$，$a,A$ 含同一 $\Delta_v,Q_J$ 与原 FIRST/history。这里“固定其余量”仅是逐点解二次不等式，**不授权独立改变 $z$ 或 $b$ 生成另一物理输入**；更不将低 $z$ 带当成已有来源容量。它改变了深层剩余的准确必要几何，但不另登记付款。
本稿没有证明 LC13/LC16 的一般来源或可吸收接收预算，也没有因大终端比就授予 R170 的 GG/suffix/删除排序。原所有未消费负项保留原位一次，R211 恢复槽不返回。

曾筛出的 ramp 势仅为 R170 filtered test 的时间变权版本；从全来源对限制回原 good×bad 仍需真实 GG/互补来源项、$\Psi$/FA 交换及删除跳，初末势亦未付。故不登记该旧机制的时间权改写，不假设免费 GG 负账。本稿实际付款仅 LC4。

## LC7　本机算术核对范围

实际用 Python 标准库 Fraction 对 240 组满足标量 good/mixed 前提的有理数组核对 LC10≤LC11，并核算 $(2\Lambda)(16/3)(1/2)=16\Lambda/3$，$\Lambda=128/119$ 时为 $2048/357$。返回 `conditional_rational_inclusion_checks: 240`。另以 81 组正有理 $A,a,\zeta,b$，取 $z_0=\min(A/a,b/\zeta)/3$、$\varepsilon=(A-az_0)(b-\zeta z_0)$，用 Fraction 与整数平方根准确核对 LC16 返回 $z_0$，并核对 $z_0/2$、$2z_0$ 的严格两侧；返回 `exact_rational_root_boundary_checks: 81`。这些只是代数核对，没有共同空间核、FIRST/history 或 FULL 资格，不替代 LC2–4 的解析证明；未新增模拟或空间数值结论。

结论：一个已完整付原 $dx$ 和来源的浮动阈值带可吸收旧 R217 支并延伸到部分大时钟区；深层 LC13 及父级其它未付分支仍原位。一般根阶目标尚未闭合。完成停等。
