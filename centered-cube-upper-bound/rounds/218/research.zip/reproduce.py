#!/usr/bin/env python3
"""R218: verify packaged files and replay complete finite evidence JSONs."""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STEMS=('floating_band_checks','affinity_checks','adaptive_face_checks')
def verify():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    required={'proof.tex.txt','report.md','audit.md','reproduce.py'}|{s+e for s in STEMS for e in ('.py','.json')}
    if not required.issubset(manifest): raise ValueError('Missing required manifest files')
    for name,digest in manifest.items():
        rel=Path(name); f=(ROOT/rel).resolve()
        if rel.is_absolute() or '..' in rel.parts or not f.is_relative_to(ROOT): raise ValueError('Unsafe manifest path')
        if not re.fullmatch('[0-9a-f]{64}',digest): raise ValueError('Invalid hash')
        if hashlib.sha256(f.read_bytes()).hexdigest()!=digest: raise ValueError('Hash mismatch: '+name)
    print('verified',len(manifest),'hashes',flush=True)
    return manifest

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--numeric-python',default=sys.executable)
    parser.add_argument('--verify-only',action='store_true')
    a=parser.parse_args(); manifest=verify()
    if a.verify_only:return
    if a.output_dir is None:parser.error('--output-dir required')
    out=a.output_dir.expanduser().resolve()
    if out==ROOT or ROOT in out.parents:parser.error('Replay output must be outside package')
    if out.exists():parser.error('Use a new output directory')
    out.mkdir(parents=True)
    receipt={'scope':'finite replay only; not a proof of general upper bound','manifest_sha256':hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),'runs':[]}
    with tempfile.TemporaryDirectory(prefix='r218_replay_') as d:
        work=Path(d)
        for stem in STEMS:
            source=ROOT/(stem+'.py'); target=work/source.name
            shutil.copyfile(source,target); dest=out/(stem+'.json')
            start=time.monotonic()
            subprocess.run([a.numeric_python,str(target),'--output',str(dest)],cwd=work,env=os.environ.copy(),check=True)
            equal=dest.read_bytes()==(ROOT/(stem+'.json')).read_bytes()
            if not equal:raise ValueError('Complete JSON differs: '+stem)
            receipt['runs'].append({'script':source.name,'seconds':time.monotonic()-start,'complete_json_byte_identical':True,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
            print(stem,'complete JSON byte-identical',flush=True)
    verify();receipt['all_passed']=True
    (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print('all three complete JSONs reproduced',flush=True)
if __name__=='__main__':main()
