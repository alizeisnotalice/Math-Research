# R218 floating-band 有限证书：运行前方案

只验证指定clock和capture代数，不认证global FIRST/high或真实空间核，不称FULL。三阶段n=(2,4)/(8,16)/(32,64)，每个n均取rho=1/4,1/2,9/10，共18个配置。每配置以Fraction核恒等式与有理不等式，以mpmath 40/70dps积分核完整正pair。

原权为product_i min(1,alpha_i/t)，另乘alive/deleted mask。target和extra均有n个alpha_i=1/8；bad有n−1个alpha_i=1/8及一个alpha_i=1。各源质量1，extra在collar中点删除且不作terminal bad。原权独立于删除；et保留删除前全部三个源，删除后target+bad；eg保留终端target+bad。

固定a=1/8,g=1,lo=1/2,hi=(1/2)(1+1/(8n)),tau=1/4,h=3/4。h0=w(hi),HJ=rho(w(lo)−w(hi)),HK=h0−HJ>0；p=L0=kappaT=D=alpha0=epsilon=1,J=HJ,K0=HK,T=h0/[(1−rho)(w(tau)−w(h))],kappa=1/T。核原capture rho0=(1−(DK0+alpha0J)/(T Delta))+恰等rho。核band：mixed wt>h0，rho(wt−h0)<=HJ；核FTC rho(wlo−whi)=HJ以及完整pair<=HJ/eg。取K=3则d=wg/wt<1，属于旧scalar PG未覆盖，不能推论FULL扩张。

完整pair在删除前/后分别为rho*a/(2a+t)^2和rho*a/(a+t)^2，故有独立有理原函数−rho*a/(ma+t)。同时直接用原始权与完整et作40/70dps积分，保留删除点分片。脚本--output，JSON无耗时和输出路径；重复运行核逐字节一致。

## 实际运行结果

18配置的全部Fraction断言通过：HK>0、capture精确等rho、严格mixed内部与band入口等式、FTC rho drop=HJ、完整rho pair<=HJ/eg，以及整个collar上的d<1。选择所有rho覆盖每个阶段，未删extra对et的贡献。

下表取rho=1/2；其它rho的pair及upper同比例变化，ratio不变。

|n|rho pair|pair/(HJ/eg)|
|---|---|---|
|2|0.00402356064377|0.158564867189|
|4|0.00206356301822|0.0200453278816|
|8|0.001045228818|0.000630028391785|
|16|0.000526041749122|1.23410227162e-06|
|32|0.000263886082587|9.42920097616e-12|
|64|0.000132160401691|1.09850659097e-21|

40/70dps最大绝对差 4.94e-43；70dps结果与独立Fraction精确积分的最大绝对差 1.77e-74。完整有理结果与每配置原始积分值在JSON；不将浮点复核本身称作区间证书。

每个配置0<rho<1且rho0由同一T、Delta、D、alpha0、K0、J准确重建；没有把capture自由替换成数值rho。辅助t中的参数均固定。原w_t只由alpha数组给定，extra删除mask独立。

n维真min-product实现与有限clock只说明新band的scalar支可有d<1，R217旧scalar PG不能覆盖这些clock行；不认证原good/FIRST/high、真实几何或FULL扩张。源质量均1，未把其余来源删去或转成terminal bad。

完整可复现检查：以显式--output原路径再次运行，JSON前后逐字节相同。SHA256=0746413f5470c5a7557b362527f9d8dcfc280877d9590d24538f7dfa1d3858c4。无耗时或路径字段。

复现命令：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/218/work/floating_band_checks.py
```

## 物理affinity核：运行前方案

新增affinity_checks.py/json，只核物理核，不认证原traffic接入。这里epsilon=1−s。共10个唯一配置：initial为s=.25,.75、lambda=1、d=0,.5四种组合；stress为s=.01,.95分别配(lambda,d)=(.5,1),(.75,3)，四种组合；expanded新增s=.999,.9999、lambda=1,d=0，并重跑两个代表压力配置(.01,.5,1)、(.95,.75,3)。每配置25/40dps；initial/stress使用48/96阶Gauss-Legendre，expanded使用96/192阶。

m以1/3+2E4(1)和直接核心phi积分独立校验。A在hard端点±lambda/2、phi端点d±.5、0、d和几何外尾分片；Z=80+|d|，明确保留两尾上界2 sqrt(s/lambda) exp(.5+|d|/2) exp(−aZ)/a，a=(1/lambda+1)/2。检查A≤rho_s以及rho_s≤exp[−(1−m)^2 epsilon²/2]。对每个扩大精度配置，n=1,4,16,64,256,1024用同一配置的真实A计算完整Gamma，检查Gamma≤n epsilon rho_s^(n−1)；n≥2再核uniform sqrt(2n)/[(1−m)sqrt(e)]。不拟合维数阶。

求积非有向区间，解析尾界的浮点评值及多精度差不能合称严格数值证明。脚本--output，JSON无runtime/路径字段，完成后重复运行核逐字节一致。

## Affinity实际运行结果

10个唯一配置、24次精度运行完成。m的E4公式和直接核心phi积分在25/40dps输出一致：m=0.5054583159824547898379612549542666952869；绝对差输出为0（仅表示该精度的浮点结果一致）。

|s|lambda|d|A（高精度摘录）|rho_s−A|
|---|---|---|---|---|
|.25|1|0|0.912250022267462|0.0005775523|
|.25|1|.5|0.828787180663665|0.08404039|
|.75|1|0|0.992075516869331|0.0001078845|
|.75|1|.5|0.933413581458178|0.05876982|
|.01|.5|1|0.338738136436814|0.4199118|
|.01|.75|3|0.118312481005205|0.6403374|
|.95|.5|1|0.696954365772419|0.3027395|
|.95|.75|3|0.315195797847516|0.6844981|
|.999|1|0|0.999999875252413|2.445915e-09|
|.9999|1|0|0.999999998752502|2.449401e-11|

所有24次A+尾界≤rho_s及rho_s≤指数界的浮点检查通过。最大25/40dps（同时扩大GL阶数）A绝对差 6.986e-12；最大解析双尾上界 5.951e-35。压力代表配置的96→192阶A差分别约1.260e−14与1.378e−14。有限求积精度与尾项保留分别记账，不据此宣称区间证书。

对所有高低精度配置均计算n=1,4,16,64,256,1024的真实全同坐标Gamma，保留全部i与两侧face和；连同A尾上界核Gamma≤n epsilon rho_s^(n−1)，n≥2的后者≤sqrt(2n)/[(1−m)sqrt(e)]均通过。所有数值保存在JSON，不拟合维数阶。n=1明确不援引仅对n≥2的uniform界。

最靠近s=1的.9999配置，rho_s−A≈2.4494e−11、指数界−rho_s≈1.4707e−13，均为有限数值核验；不从接近等号宣称精确误差界。该物理核结果尚未认证原traffic/FIRST/high或source-selector接入。

显式--output再次运行，JSON前后逐字节一致。最终SHA256=1108c09445566cbbdca047fd5e739fb2d78bdd70c445c8e3579670b9d3a6c59b。没有runtime或输出路径字段。

复现命令：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/218/work/affinity_checks.py
```

## Adaptive face：运行前方案

仅新增adaptive_face_checks.py/json。三阶段dyadic检查n=(2,4)/(16,64,256)/(1024,65536,1000000)，各用40/70dps。令m=1/3+2E4(1),c=(1−m)^2/2,a=c/32,x_k=sqrt(n)2^−k，累加k≥2直到首次x_k<1e−12（该项包含），并对剩余尾用下一个x的显式几何上界2x+(4/3)x²；不得把截断结果冒充全和。分别核p=1,2的sum x_k^p exp(−a x_k²)及其共同和不超过给定unimodal解析界S_p=2[p/(2ae)]^(p/2)+Gamma(p/2)/[2a^(p/2)log2]。不拟合n阶。

另直接计算n=2、sup位于积分内的物理face核，(lambda,d)=(1,0),(.5,1),(.75,3)，25/40dps和GL48/96阶，端点分片，Z=80+|d|，保解析双尾。核心|x|≤lambda/2上(1−s)sqrt[f_s(x/lambda)/lambda]的最大值为s=0处1/sqrt(lambda)；核心外为s=1/3处[2/(3sqrt3)]sqrt[phi(x/lambda)/lambda]。用此精确pointwise最大公式计算Iadapt与两坐标同位移Gammaadapt，不用s网格最大替代积分内sup。该有限例不证原traffic接入。--output无runtime/路径字段，完成后逐字节重复检查。

## Adaptive face实际运行结果

8个dyadic维度均完成40/70dps，p=1,2的有限和+显式几何尾≤各自S_p检查全部通过。下表给70dps联合上界（不是单纯截断和）：

|n|kMax|联合和+尾|几何尾|S1+S2|
|---|---|---|---|---|
|2|41|0.873516802152|6.4311e-13|415.857162066|
|4|41|1.33253300423|9.0949e-13|415.857162066|
|16|42|3.3249047303|9.0949e-13|415.857162066|
|64|43|9.23388782786|9.0949e-13|415.857162066|
|256|44|28.0476645201|9.0949e-13|415.857162066|
|1024|45|84.4265457321|9.0949e-13|415.857162066|
|65536|48|207.783305176|9.0949e-13|415.857162066|
|1000000|50|207.829979702|8.8818e-13|415.857162066|

联合截断和40/70dps最大绝对差 3.631e-38。解析几何尾使用下一项x，包含全部k>kMax项；指数项仅用≤1，未漏尾。

真正n=2积分内sup的物理核结果：

|lambda|d|Iadapt|Gammaadapt|25/40dps Gamma差|Gamma解析尾上界|
|---|---|---|---|---|---|
|1|0|0.9004681081964|1.125128372404|1.6279e-12|2.8622e-35|
|.5|1|0.4816288209099|0.4012135420908|2.5205e-12|2.8118e-53|
|.75|3|0.1908753069499|0.04185306966644|9.2862e-14|1.0896e-42|

core精确最大值来自s=0（phi≤1使(1−s)sqrt(1−s+s phi)非增）；outside最大化(1−s)sqrt(s)，唯一内部最大s=1/3。故这些积分是真正pointwise sup，不能解释为固定s的Gamma最大值。Gamma按两坐标同位移、全部两侧face求和。物理求积非有向区间，表中差与尾分开保留；不认证原traffic接入。

显式--output复跑后JSON逐字节一致，SHA256=253c4e16f215b9a080fe0650f9b8829ae70d7649343cfd62e185d29824906f01。JSON无运行时或输出路径，不拟合n阶。

复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/218/work/adaptive_face_checks.py
```

## 主代理常数实算（有限浮点评值）

主代理实际使用同一本机runtime、mpmath50位，根据SE显式公式直接计算 C_hi≈46782.51923629863532、C_lo≈1286.21576120564959，乘物理上迹因子后的当前粗常数约76941.19876140096472。固定s、n≥2的物理常数约2.776266219447797，与解析统一上放4一致。自适应常数较大，本文只证明其绝对有限及根阶，不声称常数最优；这些浮点评值不是有向区间边界，证明仅使用显式解析常数。
