#!/usr/bin/env python3
"""Finite deterministic physical affinity checks; no original traffic assertion."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def calc(config,dps,degree):
  with mp.workdps(dps):
    s,lam,d=map(mp.mpf,config);eps=1-s;m=mp.mpf(1)/3+2*mp.expint(4,1);rho=mp.sqrt(m*(1-s+s*m))+(1-m)*mp.sqrt(s);exponential=mp.exp(-(1-m)**2*eps**2/2);Z=80+abs(d)
    cuts=[-Z,Z,-lam/2,lam/2,d-mp.mpf('.5'),d+mp.mpf('.5'),mp.mpf(0),d]
    for t in (1,2,4,8,16,32,64):
      if t<Z:cuts.extend([mp.mpf(t),mp.mpf(-t)])
    cuts=sorted(set(cuts));nodes,weights=mp.gauss_quadrature(degree,'legendre');A=mp.mpf(0)
    for lo,hi in zip(cuts,cuts[1:]):
      mid=(lo+hi)/2;half=(hi-lo)/2
      A+=half*sum(w*mp.sqrt(fs((mid+half*z)/lam,s)*phi(mid+half*z-d)/lam) for z,w in zip(nodes,weights))
    a=(1/lam+1)/2;pref=mp.sqrt(s/lam)*mp.exp(mp.mpf('.5')+abs(d)/2);tail=2*pref/a*mp.exp(-a*Z)
    face=(mp.sqrt(phi(lam/2-d))+mp.sqrt(phi(-lam/2-d)))/2
    table=[]
    for n in (1,4,16,64,256,1024):
      Gamma=n*eps*face*A**(n-1);bound=n*eps*rho**(n-1);uniform=mp.sqrt(2*n)/((1-m)*mp.sqrt(mp.e)) if n>=2 else None
      table.append({'n':n,'Gamma_actual_homogeneous':mp.nstr(Gamma,dps),'Gamma_with_affinity_tail_upper_numerical':mp.nstr(n*eps*face*(A+tail)**(n-1),dps),'n_epsilon_rho_power':mp.nstr(bound,dps),'Gamma_over_rho_bound':mp.nstr(Gamma/bound,dps),'Gamma_tail_upper_le_rho_bound_numerical':n*eps*face*(A+tail)**(n-1)<=bound,'uniform_root_bound_n_ge_2':mp.nstr(uniform,dps) if uniform else None,'rho_bound_le_uniform':bound<=uniform if uniform else None})
    return {'s':config[0],'lambda':config[1],'d':config[2],'dps':dps,'degree':degree,'Z':mp.nstr(Z,dps),'cuts':[mp.nstr(x,dps) for x in cuts],'m_formula':mp.nstr(m,dps),'A_finite_window':mp.nstr(A,dps),'A_tail_upper':mp.nstr(tail,dps),'rho_s':mp.nstr(rho,dps),'exponential_upper':mp.nstr(exponential,dps),'rho_minus_A_finite':mp.nstr(rho-A,dps),'exponential_minus_rho':mp.nstr(exponential-rho,dps),'face_average_sqrt_phi':mp.nstr(face,dps),'A_plus_tail_le_rho_numerical':A+tail<=rho,'rho_le_exponential_numerical':rho<=exponential,'homogeneous_faces':table}

def main(output):
    initial=[(s,'1',d) for s in ('.25','.75') for d in ('0','.5')];stress=[(s,lam,d) for s in ('.01','.95') for lam,d in [('.5','1'),('.75','3')]];expanded=[('.999','1','0'),('.9999','1','0'),stress[0],stress[-1]]
    stages=[]
    for stage,configs,degrees in [('initial',initial,(48,96)),('stress',stress,(48,96)),('expanded',expanded,(96,192))]:
      rows=[]
      for cfg in configs:
        vals=[calc(cfg,dps,deg) for dps,deg in zip((25,40),degrees)]
        with mp.workdps(50):difference=mp.nstr(abs(mp.mpf(vals[0]['A_finite_window'])-mp.mpf(vals[1]['A_finite_window'])),30)
        assert all(v['A_plus_tail_le_rho_numerical'] and v['rho_le_exponential_numerical'] for v in vals)
        assert all(t['Gamma_tail_upper_le_rho_bound_numerical'] and (t['rho_bound_le_uniform'] is not False) for v in vals for t in v['homogeneous_faces'])
        rows.append({'config':list(cfg),'precision_runs':vals,'A_low_high_absolute_difference':difference});print(stage,cfg,vals[-1]['A_finite_window'],flush=True)
      stages.append({'stage':stage,'cases':rows})
    mchecks=[]
    for dps in (25,40):
      with mp.workdps(dps):
        formula=mp.mpf(1)/3+2*mp.expint(4,1);direct=mp.quad(phi,[-mp.mpf('.5'),0,mp.mpf('.5')])
        mchecks.append({'dps':dps,'m_E4_formula':mp.nstr(formula,dps),'m_direct_phi_integral':mp.nstr(direct,dps),'absolute_difference':mp.nstr(abs(formula-direct),dps)})
    result={'schema':'R218_physical_affinity_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'unique_config_count':10,'precision_run_count':24,'epsilon_definition':'1-s','m_independent_checks':mchecks,'stages':stages,'limitations':['Finite quadrature without directed interval rounding; analytic tails evaluated in ordinary arbitrary precision.','Physical affinity and homogeneous face examples only, no original traffic/FIRST/high/source-selector entry certified.','No general-n order fit.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'affinity_checks.json');args=ap.parse_args();main(args.output)
