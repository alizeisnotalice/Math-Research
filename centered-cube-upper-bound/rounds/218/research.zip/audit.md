# R218 独立审查

## 作者稿前的独立检查点

先读R218 task_contract.md；未读本轮作者新稿。窄读R217冻结capture_geometry.md及已审原R128 RT1–6、R170 soft_threshold_energy的固定终端/时间流接口。当前一般目标仍为任意正L1输入的根阶弱型预算，不能以条件单行或子域代替。

### 1. 当前精确剩余对象

共同预定L0、κ与原baseline背景不改变。固定实际完整receiver/history行后，p、K1、K2、K0、T、g、Δ=wτ−wh、α0、ρ0均在辅助t中固定；w_t、Z_t、e_t、Π_t与δ_t变化。真实原正量仍含p dx、β、硬来源、完整Π_t⊗Π_t（两份Π已合含e_t^−2）、ρ0、FA/suffix、高门、唯一j及窗口。

    c=3L0/K, d_t=c wg/wt,
    B=(K1+K2)/J, ζ=p/(κTL0), H=B−ζK0/J.

R217已付mixed内d≥1且ρ0H+≤1（零权行先零）。本轮必须分别保d<1与d≥1、ρ0H+>1；后者在aligned尺度只有CG3必要双侧区间，不是已付。任何新支须从上述未付正域不交剥离，已用负信用不得重领。

### 2. 中间层可用与不可免费使用的FIRST信息

R217实际精确正包络为

    p·clock ≤ cK/(3e_g) ∫ J(v)ρ0(v)H(v)+ ν(dv).

若ρ0H+被共同常数ε点态控制，才可直接转成固定J来源价。当前超额支需控制同一联合权，而非再声明这个积分存在。H+对应真实差

    JH+ = (K1+K2−pK0/(κTL0))+.

原Q*=(K1+K2+J)/3、J的FIRST容量在每个实际x给源积分上界；仅用RT5明示接口至少有∫(K1+K2+J)dν≤3Q及∫Jdν≤Q。若作者使用更强的分别∫K1ν≤Q、∫K2ν≤Q，需准确引用其共同当前FIRST资格，不能只从Q*帽无价推出。更重要的是，即便取得上述源容量，删ρ0、删减项只给∫Jρ0H+ν≤O(Q)，它本身不是对dx可积的固定核。高门给Q/e_g≤p/(2K)，后续真实x上的p仍是自适应核；不能把该量当归一概率而丢掉soft/scale/j费用。

合法的已有high列帽是固定同一x,V,j先用

    ∫1_high β(dy)/e_g(y) ≤ (2KQ)^−1∫p_y β(dy) ≤1/(2K).

它可乘一个已证明与y无关的可积receiver核。当前Jρ0H一般依y，故不能先分别取p、Δ、α0、C_H最坏值后仍称保留共同来源几何。需给实际联合核列、可积receiver包络，或有资格的signed结算。

### 3. α0、Δ与中间二次约束

原同参数

    QJ=∫Jdν, α0=DQ/QJ,
    ρ0=(1−(DK0+α0J)/(TΔ))+.

QJ≤Q授α0≥D，但没有ν≤β、没有QJ/e_g或Δ/w_g的统一反向质量帽。正ρ0强制TΔ>DK0+α0J；Δ、wg和wτ、wh属于同一来源时钟，α0须同一整源QJ。对每个v另选α0、另选Δ、重算capture/history或把ρ0替换成合法空捕获史均不允许。

aligned Hhat≥Lplus时，B≤C_H z、z=K0/J，C_H=(Hhat/L)^n+(Hhat/Lplus)^n。置A=1−α0J/(TΔ)、a=DJ/(TΔ)、C=C_H−ζ，才有ρ0H+≤(A−az)+(Cz)+。未付支要求A,C>0、CA²>4a及z位于CG3严格两根间；C_H维数费和Hhat<Lplus补域都要保。完成平方不能把来源相关的A、a、C变成独立标量参数，再将最大值当通用来源价。

本机Python/Fraction已对两组固定有理参数核验ρ0TΔ=(TΔ−DK0−α0J)+及Jρ0H+：输出α0=2、ρ0=79/90、H=25/6、Jρ0H+=79/108；另一组α0=4/3、ρ0=0、H=5/2、权为0。此仅检查同参数代数和零支，不认证真实空间/history或付款。

### 4. d<1的准确障碍与可用方向

d<1等价wt>c wg，是terminal/current比偏小、反向wt/wg偏大的支。固定来源FTC最多把该域的下降控制为(w入口−cwg)+；乘原pρ0/e_g后，若用good把pwg换J(1+B)，仍留下入口/wg与B等费用。重复单源FTC、仅给有限时窗或单位行端点，都不是一般根阶来源价。

捕获确与Δ=wτ−wh相关，可能与原下降量联合，但必须证明同一来源、同一入口/终端与实际far窗的关系。R211修复差已付不意味着baseline可删；不能用已付款额度重新支付整ρ0。R170终端比值边界价依赖其完整时间段、排序/suffix、内部及删除项资格，不自动控制当前正δ。若新稿用signed时间流，要精确列出所有端点、删除上跳、已消费suffix回加及新消费负项的不交账。

### 5. 真实测度、选择器与来源账

任何新结论须给全部实际s、L、Hhat、来源位移及任意正L1来源量词；固定product receiver结论不能免费用于x依赖selector。原hard源依赖权先固定hard标签推导，获得独立上界后才用一次16/3硬帽。唯一j必须保至右边独立j才合并；独立窗口依各自WA归属，不能多窗重复领取一份总源。

两个原w仅在其从原尚未付正项出发的备选上界中使用。若用了R215位移吸收后的余式，不能再当完整Π²归一。ν不得换成β或假设ν≤β；最终仅用Wν≤WA。任何负余额留一次；正门上放只可增加正量，不赋予bad端target good/capture资格。

## 本轮作者稿审核

待主代理给准确新命题及作者稿后，再按上述预先筛查点核验；当前未预判本轮作者结论。

## 新浮动加权slack带：作者稿前准确命题独审

收到主代理准确命题后独立核验如下，尚未读作者稿。

固定原实际终端target v及0<R(v)≤1，R可为原ρ0；HJ=L0J_v/p>0，HK=K0v/(κT)，h0=HJ+HK。全部在固定实际receiver/history行后不依辅助t。严格mixed给wt>h0。选

    0<R(v)(wt(v)−h0(v))≤ε HJ(v).

此即单来源wt落在(h0,h0+εHJ/R]的值域；原wt连续非增，−dwt=kt wt dlogt，因此对任意实际辅助时间子域

    ∫ R kt wt 1_band dlogt ≤R·(εHJ/R)=εHJ.

R=0原正交通先零，不构造1/R。平台和阈值点不产生下降原子；删除只改变Z_t/e_t。h0与R可依v及hard源/history，不需source独立、good或d≥1，也不需C_H比较。原terminal target支持保证v存活；坏端完整Π归一、e_t≥e_g后乘回外p，得

    p·clock_band≤ε L0/e_g ∫J_vν(dv).

同当前high/FIRST β列帽、一次hard帽16/3、保到右式独立j才合并uniquej、固定b的真实dx积分，准确价为16ΛL0ε/(3K)Wν≤同系数WA。其量词涵盖原全部实际s、尺度和任意合法来源，R冻结资格与R211/R217相同；若R依hardz，先固定z作统一上界后才硬来源积分。该证明不先积分自适应p，不产生新的selector菜单费。

与R217包含关系核验：在PG旧已付支，d≥1给wt≤cwg，good给pwg≤KJ(1+B)/3，合用pwt≤L0J(1+B)。因此

    R(pwt−ph0)≤L0J R H+≤εL0J.

所以新带包含R217相同ε的已付支，以同一份价格取代旧PG分类；不能旧PG价再加新带价。若讨论R217已付域之后的实际剩余，仅将新带与当前剩余相交；原负余额仍一次。

与R214边界核验：同一固定L0、κ下，R214已付目标低帽为wt≤h0，严格mixed中的新带在wt>h0，与该低帽不交。改变L0后旧大cap可以提供另一粗上界，但不能从两个上界相减得到本带仅εL0、无需再收HK的增量价。新内容应表述为同一单调值域FTC的更强应用及原正子支包含关系，不把已知FTC本身登记为新定理，不宣称已认证旧工具之外的FULL实例。

未付仍为严格mixed下R(wt−h0)>εHJ（及原尚未涉及块）；这项依wt随t变化，不能把它免费带出time积分。新带价格本身不证明该超额交通的空间/来源容量。因此本命题通过不等于一般root已闭合。

## 全soft affinity与所定义hardface sqrttrace：准确命题预审

收到主代理准确核命题后独审，仍未读本轮作者稿。定义m=∫_{−1/2}^{1/2}φ，0<m<1；λ=L/b≤1。对E=[y−b/2,y+b/2]，真实归一P_s,L的质量a≥a0=1−s+sm；φ偶、径向非增使任意平移J_b,v在E的质量j≤m。a0≥m。按E及补集作Cauchy，affinity≤√(aj)+√((1−a)(1−j))；在a≥a0、j≤m上两项和最大于(a0,m)，所以

    affinity≤ρ_s=√[m(1−s+sm)]+(1−m)√s.

二点概率的Hellinger/TV恒等给ρ_s≤√(1−(a0−m)^2)≤exp[−(1−m)^2(1−s)^2/2]。端点s=0、1均合法，s=1时只有上界1，不虚构正gap。固定共同物理product receiver及固定参数下tensor给全shift ρ_s^n；这不授予原source独立或免费x依赖selector包络。

对命题明确所定义的归一trace

    Γ=(1−s)/2 Σ_{i,±} √φ(±λ/2−d_i)
       ∏_{j≠i} ∫√[p_s,λ(t)φ(t−d_j)]dt,

φ≤1使每个face值因子≤1、其它n−1坐标各≤ρ_s，因此Γ≤n(1−s)ρ_s^(n−1)。n≥2时对ε=1−s∈[0,1]正上放到ε≥0最大化εexp[−(1−m)^2(n−1)ε²/2]，得Γ≤n/[(1−m)√(e(n−1))]≤√(2n)/[(1−m)√e]；n=1两face直接给Γ≤1。此处只证明命题所定义核trace的界；原positive hardface交通如何抽出该sqrttrace、余下Radon–Nikodym因子与来源/selector/clock费用仍需另证，不能据Γ的根阶立刻登记一般付款。

独审实际调用本机mpmath45dps，通过

    m=2∫_0^1(a−a²+a²exp(−1/a))da

得到m≈0.5054583159824547898379612549542666952869，trace粗系数√2/[(1−m)√e]≈1.73446225602749250087493824339。对s=0,.01,.5,1计算ρ_s与指数上界，均符号相符；这只是有限浮点sanity check，不是m的有向舍入区间证书或全参数证明。解析资格来自上面的事件质量、二点Cauchy与标量最大化。

## adaptive-soft hardface sqrttrace：主代理准确命题预筛

仍在读作者稿之前，对新增全soft自适应s命题独立筛查。固定λ、位移和一个face，把所有与s无关的φ因子及λ幂留在外面，s函数为F_s=(1−s)∏_{j≠i}f_s(r_j)^(1/2)。以下论证控制的是“先逐face被积函数取sup_s、再积分、再求face和”，强于只对固定s积分后的Γ取上确界；书写时不能混同。

高s部分：s≥1/2时，core上φ≥m0=e^(−2)/2、f_s≥φ/2，core外|∂s log f_s|=1/s≤2，因此统一C0=2/m0合法。于是(logF)''≥−(1−s)^−2−C0²(n−1)/2。对ε=1−s∈[δ/2,δ]、δ=2^−k(k≥2)，扩带ε∈[δ/4,2δ]仍s≥1/2，曲率下界可取−M，M=16/δ²+C0²n/2。按logF'正负选择单侧方向时，两侧至少有δ/4可用空间；取h=min(δ/4,1/√M)，Taylor给该单侧0≤u≤h上F(s±u)≥e^(-1/2)F(s)。因此sup_band F≤e^(1/2)/h ∫expanded F≤C(√n+δ^−1)∫expanded F。

先对非负空间积分与face求和，再用固定s已证Γ_s≤nεexp[−c(n−1)ε²]，c=(1−m)²/2。扩带积分≤4nδ²exp[−c(n−1)δ²/16]。n≥2时以x=√nδ归一√n，dyadic项为C(x²+x)exp(−c'x²)。x≤1项按几何级数和，x>1项按各二进制壳超指数衰减和，二者给与n无关常数。因此高s总价C√n，未再乘免费Jeffreys √n因子。

低s部分：对s≤3/4、0≤u≤h=1/(8n)，core有f_s≥1−s≥1/4，外部f_s随s非减，故处处f_{s+u}≥(1−4u)f_s，且1−s−u≥(1−4u)(1−s)。所以F_{s+u}≥(1−4h)^((n+1)/2)F_s≥F_s/2。s+h≤7/8，给sup_low F≤16n∫_0^(7/8)F。积分后的Γ上界≤nexp[−c(n−1)/64]，故低s价≤16n²exp[−c(n−1)/64]≤C'√n；最后常数可很大但确与n无关。n=1直接Σfaces≤1。

原正hardface测度若乘√(J/p_s^+)时，p_s^+=λ^−1 a_s∏_{j≠i}p_s,λ、a_s=1−s+sφ(1/2)，精确多出√(λ/a_s)。a_s≥φ(1/2)、λ≤1，因此可用φ(1/2)^−1/2移出。该权恒等式本身正确；真实原traffic是否有资格被此权控制、余下√(p_s^+/J)如何支付，仍是独立未证接缝，不能因weighted trace根阶宣称原hardface交通已付。

λ固定时上述常数对λ∈[1/2,1]一致，可对dlogλ积分支付log2。它不授予自由adaptive-L上确界，原来源、选择器、clock及history映射仍需回代。本机Python实际算dyadic归一粗和：n=2,16,256,4096,10^6约0.8735,3.3176,26.8430,109.4500,109.8255；仅为有限算术sanity，所有n一致性由上述几何壳求和证明。

## 作者稿后审核：SE、MC与LC

已通读soft_face_envelope.md、middle_capacity.md、large_clock.md。

SE1–7通过：命题确为Σfaces∫sup_s，不误换成sup_s∫；s参数连续、可测资格正确。高s的hδ=Mδ^−1/2≤δ/4、单侧Taylor与√e包络、扩带积分7nδ²/2、n−1≥n/2产生a=c/32均匹配。显式S_p(a)用log坐标上的单峰求和至多两峰值加积分/log2，Gamma积分与常数正确。低s的指数≤n、Bernoulli下界1/2合法；积分εexp(−c(n−1)ε²)得到n/[2c(n−1)]exp(−c(n−1)/64)，后续C_lo=(16/c)e^(c/64)√(32/(ce))正确。n=1及s=1零面单列。真实hard上迹和√(λ/a_s)配平、固定L后dlogL费用正确。来源权、原traffic转换与free adaptive-L仍明确未证。

MC1–13及MC15通过：全shift affinity、m/aφ解析常数、固定s半密度面根阶、MC10真实上迹单位均准确；MC13只写未证支配接口，未当现有付款。MC14初稿2Q超出RT5明示资格，已通知修订。最终文本已实际核为∫(K1+K2)ν≤3Q−QJ≤3Q，并明确未假设单独两核各≤Q；容量表额外加强的K1f,K2f≤Q不等同原FIRST。这个问题已解决。容量表与同α0的有理例只排除纯标量推理，不作为物理L1/FULL反例；其capture、mixed和时钟表达式核对正确。

LC1–14通过：浮动带准确保下端h0，夹断值域长度和R固定资格正确；另一腿完整Π归一、high/FIRST、hard源依赖权先固定后统一上界、uniquej/window顺序完整，价16ΛL0ε/(3K)WA。LC9–12的PG包含关系及d<1新增条件正确；旧PG与新带只取一份备选价，与R214固定参数字面域相离，但不夸称新FTC或严格FULL扩张。LC15–16对剩余的低K0/J必要且充分标量边界通过：在混合的正因子区间上乘积严格下降；判别式(Aζ−ab)^2+4aζε、小根有理化、Ab>ε与严格端点均正确，没有错误加入两因子均负的高根外支。其余量保持同一来源相关，不被当自由物理参数或已付容量。

## 三套数值证书独审及实际复跑

已完整静审floating_band_checks.py、affinity_checks.py、adaptive_face_checks.py及numeric_notes。独审实际使用指定本机runtime与vendor mpmath，将三组脚本分别重跑到/tmp/r218_audit_{floating_band_checks,affinity_checks,adaptive_face_checks}.json；三份完整JSON与当前作者JSON逐字节一致，complete=true、每份script_sha256与实际脚本匹配。

floating：18个n/rho配置保真实min-product权（删除mask另乘）、完整Pi²分母及中点extra删除；rho由同T、Δ、HJ、HK、D、alpha0准确重建。ρdrop=HJ及完整pair≤HJ/e_g为Fraction精确证据，原函数−ρa/(ma+t)与40/70dps直接完整权积分一致。d<1只认证该标量collar而非FULL扩张。

affinity：10唯一物理配置、24精度运行；E3φ分段、hard端点/来源核端点切片、A双尾2√(s/λ)e^(.5+|d|/2)e^(−aZ)/a正确。m用E4及直接核心积分双核对。全同坐标Gamma=nε·face_average·A^(n−1)，保全部i与两侧，n=1不套n≥2根阶常数。数值检查含A尾，但普通GL/mpmath非区间证书；未据此授予原source/FIRST/high资格。

adaptive：dyadic后续尾由nextx的几何和2nextx、(4/3)nextx²覆盖，未把截断和当全和。40/70dps的8维sum+tail与S_p比较核实现；它不代替SE全n证明。真实n=2三配置先解析逐点最大化：core为s=0、outside为s=1/3及系数2/(3√3)，因此确算积分内sup而非网格下界或sup在积分外。Gamma=两face平方根和乘Iadapt的n=2全face因子正确；物理双尾保留。所有有限证据均无一般n阶拟合、无区间或FULL夸大。

## report 当前稿审核

已通读report.md；其主次结论和量词与经审SE/MC/LC相符：主结果为全soft、全shift、积分内soft选择的半密度面核，浮动带给独立的原正子支价格；两者没有合并成一般原目标闭合。报告明确未建立原middle到sqrt(J/p^+)权的转换，未将自由adaptive-L、来源或历史选择器当免费。MC14修正、所有费用一次、数值非区间与非FULL、包外driver回执不预报通过均表述准确。详细proof及traffic_bridge尚待就绪后全文绑定审核。

## traffic_bridge 全文审核与最早未证接口

已通读traffic_bridge.md，并窄核R170 shell_traffic_bridge.md S1–S7。

TB1–6通过：原外测度、ρ0替换范围、完整Π²和mask准确；δwvwu=wu²[−∂logt(wv/wu)]+ a.e.身份正确，不把来源阈值分数的正部改成pair概率导数。无删除段pair概率漂移为2kbar−kv−ku，删除另有跳；比值正变差前的wu²/e_t²、支持与gate不能删成端点差。

TB7–10换元方向与Jacobian通过：score等价|y−v|>bC^−1(cjt/b)，t增大时来源半径减小；实际窗ξ∈[a/b,cj²]⊂[1/2,1]，r<1，因而dlogt绝对值的dℓ密度为[1−φ(r+.5)]/[2bC(r)]，介于(1−aφ)/(2b)与1/b；相对logℓ密度r[1−φ]/C≤2r<2但可趋零。TB8闭内/严格外指示方向正确。它们都是两来源相对y的壳层，不是x receiver面，ℓ不必在原L窗内，单个ℓ=L的对齐点不能承载整段交通。

为使TB正文自足，已通知补明原C定义：F=max{1_core,φ}、C(r)=∫coreF(u−r)du。则C(0)=1，0<r<1有C'=φ(r+.5)−1<0，C(1)=∫_.5^1.5φ≤(1−m)/2<.5。现有TB用到的结论方向正确；这项只需补定义，不能只凭C名理解。由该定义，源壳层换元确未进入远尾，不存在实际窗内逆Jacobian爆炸。

TB11–13通过：固定s的物理尺度分布导数包含−np体积项、smooth dilation项A与真实正hard面；其总质量−n+ns+n(1−s)=0。原辅助t没有物理L路径，若强行L=ℓ(t)还会改变kernel、T、g、capture及history并引入路径导数/跳项。R170 S1/S2保偏离与对齐误差，输出是厚体积壳层。旧核外侧薄壳每面系数为sφ(.5)/2且用W外迹；hard生产系数为(1−s)/2且SE使用p内迹。二者比例sφ(.5)/(1−s)在s→1发散，s=1/0端点也说明不能互换。真实含Π²的乘子已有两份e分母，不额外再除e²；该措辞当前已修。

报告追加桥接定位与本稿一致：最早未证处早于半密度权，是原source-clock交通如何通过有费用的恒等式/单向比较产生physical receiver尺度面流。SE核工具本身严格，但当前TB未证明此转换，也未消费负项或登记raw middle付款。下一步优先联合估计原来源权比正变差/真实接收几何是准确的问题定位，不能借壳层/coarea名称跳过这条接缝。

## 详细proof全文审核

已通读proof.tex.txt全文并补读首次长输出截断的浮动带中段。Hellinger、固定面、SE积分内soft选择、真实上迹/单位、LC完整来源价、PG包含、深层小根、MC容量与TB桥接均与经审作者稿一致。全部soft几何与原实际strictsoft资格分开；SE是固定λ但全shift的一致核界，不被偷换成free adaptive-L。一般目标未闭合与clock→physical面→半密度来源权两层缺口明确保留。数值摘要范围未夸大。Python静态核了39个label，无重复或未定义引用，begin/end环境计数平衡；未编译PDF。

记录三项小修：本audit首段出现的“Π²/e²”重复简写已改为“完整Π_t⊗Π_t（两份Π已合含e_t^−2）”。proof的Xi来源及末段同类两处已通知作者统一。proof eq:shelljacobian应写|dlogt/dℓ|而非d|logt|/dℓ，后者依t是否大于1可能符号不同；正确绝对Jacobian公式本身及TB对应式未错。另建议在浮动带proof明确先固定hard z、统一上界后才使用硬帽，避免完整行tuple漏列该标签的歧义。待最终修订实际核消除后冻结。

## 最终绑定与冻结

阶段记录保留先审后读的过程；本节覆盖先前“待补/待修”状态。已实际核最终proof.tex.txt共837行，SHA256为9d4073d5dd198f1a2634aa30a416f9335ebb0f5ba2e493cb9c3a58470c1aea1d。39个label各唯一、无未定义引用。两处重复Π分母已统一为Π_t⊗Π_t（两份Π各含e_t^−1）；eq:shelljacobian已改为|dlogt/dℓ|；浮动带明列hard z完整标签并说明先固定到统一无z上界后才硬帽。traffic_bridge TB3已补原F=max(h,φ)、C=∫coreF(u−r)、C(0)、C(1)及C′方向，并明确F不归一。以上修订均已实际核消除，未留阻断项。

最终SE全soft积分内选择硬面半密度包络、MC物理affinity/上迹、LC浮动带来源预算及小根边界、TB真实时钟与面流区分，连同report/proof和三套有限数值算法，均通过本次独立审核。主成果严格为固定任意λ与全shift下的Σfaces∫sup_s根阶核工具；辅助LC可按16ΛL0ε/(3K)WA支付原浮动正带并以同价包含R217支。两者没有被连接成一般middle或一般弱型上界付款。最早未证处仍是来源时钟交通到物理尺度面流的合法有价转换，随后还有半密度来源权、任意位置相关尺度、capture/history等实际预算。

三套当前JSON已再次确认script_sha256与源码一致，并与独审此前完整实际重放结果逐字节不变。有限GL/mpmath非区间证书，给定clock或加强容量表非FULL空间实现；所有窗口、已耗w、capture恢复和负信用一次账保留。没有以核工具更名支付旧HH或超额交通。

本audit在最终manifest生成之前冻结。主代理后续整包迁移driver、前后manifest、外部备份及commit/push状态，由轮次README及包外回执记录；本文件不提前声称这些未执行动作通过，也不再为后续回执改写而使最终清单失效。
