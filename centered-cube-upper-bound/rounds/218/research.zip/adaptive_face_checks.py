#!/usr/bin/env python3
"""Dyadic normalized sums and true n=2 supremum-inside-integral physical faces."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def dyadic(n,dps):
  with mp.workdps(dps):
    m=mp.mpf(1)/3+2*mp.expint(4,1);c=(1-m)**2/2;a=c/32;sums=[mp.mpf(0),mp.mpf(0)];k=2
    while True:
      x=mp.sqrt(n)*mp.mpf(2)**(-k);factor=mp.exp(-a*x*x)
      sums[0]+=x*factor;sums[1]+=x*x*factor
      if x<mp.mpf('1e-12'):break
      k+=1
    nextx=x/2;tails=[nextx/(1-mp.mpf('.5')),nextx**2/(1-mp.mpf('.25'))]
    bounds=[2*(p/(2*a*mp.e))**(mp.mpf(p)/2)+mp.gamma(mp.mpf(p)/2)/(2*a**(mp.mpf(p)/2)*mp.log(2)) for p in (1,2)]
    assert all(s+t<=b for s,t,b in zip(sums,tails,bounds))
    return {'n':n,'dps':dps,'m':mp.nstr(m,dps),'c':mp.nstr(c,dps),'a_c_over_32':mp.nstr(a,dps),'k_first':2,'k_max_included':k,'last_x_included':mp.nstr(x,dps),'next_x':mp.nstr(nextx,dps),'components':[{'p':p,'finite_sum':mp.nstr(s,dps),'geometric_tail_upper':mp.nstr(t,dps),'infinite_sum_upper_numerical':mp.nstr(s+t,dps),'unimodal_bound_Sp':mp.nstr(b,dps),'finite_plus_tail_le_Sp_numerical':s+t<=b} for p,s,t,b in zip((1,2),sums,tails,bounds)],'combined_finite_sum':mp.nstr(sum(sums),dps),'combined_tail_upper':mp.nstr(sum(tails),dps),'combined_infinite_sum_upper_numerical':mp.nstr(sum(sums)+sum(tails),dps),'combined_S1_S2_bound':mp.nstr(sum(bounds),dps)}

def physical(lam0,d0,dps,degree):
  with mp.workdps(dps):
    lam,d=map(mp.mpf,(lam0,d0));Z=80+abs(d);co=2/(3*mp.sqrt(3));nodes,weights=mp.gauss_quadrature(degree,'legendre');cuts=[-Z,Z,-lam/2,lam/2,mp.mpf(0),d,d-mp.mpf('.5'),d+mp.mpf('.5')]
    for z in (1,2,4,8,16,32,64):
      if z<Z:cuts.extend((mp.mpf(z),mp.mpf(-z)))
    cuts=sorted(set(cuts));core=mp.mpf(0);outside=mp.mpf(0)
    for lo,hi in zip(cuts,cuts[1:]):
      half=(hi-lo)/2;mid=(hi+lo)/2;iscore=abs(mid)<lam/2
      def f(x):
        if iscore:return mp.sqrt(phi(x-d)/lam)
        return mp.sqrt(phi(x/lam)*phi(x-d)/lam)
      val=half*sum(w*f(mid+half*z) for z,w in zip(nodes,weights))
      if iscore:core+=val
      else:outside+=val
    a=(1/lam+1)/2;tail=2/mp.sqrt(lam)*mp.exp(mp.mpf('.5')+abs(d)/2-a*Z)/a;I=core+co*outside;face=mp.sqrt(phi(lam/2-d))+mp.sqrt(phi(-lam/2-d));G=face*I
    return {'lambda':lam0,'d':d0,'dps':dps,'degree':degree,'Z':mp.nstr(Z,dps),'cuts':[mp.nstr(x,dps) for x in cuts],'core_integral':mp.nstr(core,dps),'outside_integral_before_coefficient':mp.nstr(outside,dps),'outside_sup_coefficient':mp.nstr(co,dps),'outside_raw_tail_upper':mp.nstr(tail,dps),'Iadapt_finite_window':mp.nstr(I,dps),'Iadapt_tail_upper':mp.nstr(co*tail,dps),'sum_two_face_sqrt_phi':mp.nstr(face,dps),'Gammaadapt_n2_same_d_both_coordinates':mp.nstr(G,dps),'Gammaadapt_tail_upper':mp.nstr(face*co*tail,dps),'pointwise_max_core':'s=0, maximum=1/sqrt(lambda)','pointwise_max_outside':'s=1/3, maximum=(2/(3sqrt(3)))*sqrt(phi(x/lambda)/lambda)'}

def main(output):
    stages=[]
    for name,ns in [('initial',[2,4]),('stress',[16,64,256]),('expanded',[1024,65536,1000000])]:
      rows=[]
      for n in ns:
        vals=[dyadic(n,p) for p in (40,70)]
        with mp.workdps(80):diff=mp.nstr(abs(mp.mpf(vals[0]['combined_finite_sum'])-mp.mpf(vals[1]['combined_finite_sum'])),40)
        rows.append({'n':n,'precision_runs':vals,'precision_40_70_absolute_difference':diff})
      stages.append({'stage':name,'cases':rows})
    geo=[]
    for lam,d in [('1','0'),('.5','1'),('.75','3')]:
      vals=[physical(lam,d,p,deg) for p,deg in [(25,48),(40,96)]]
      with mp.workdps(50):diff=mp.nstr(abs(mp.mpf(vals[0]['Gammaadapt_n2_same_d_both_coordinates'])-mp.mpf(vals[1]['Gammaadapt_n2_same_d_both_coordinates'])),30)
      geo.append({'lambda':lam,'d':d,'precision_runs':vals,'Gamma_low_high_absolute_difference':diff})
    result={'schema':'R218_adaptive_face_checks_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'dyadic_stages':stages,'physical_n2_sup_inside_integral':geo,'proof_constants':{'C0':'4*exp(2)','high_soft_M':'16/delta^2+C0^2*n/2','low_soft_envelope':'16*n*integral_0^.875','dyadic_exponent':'a=c/32, c=(1-m)^2/2'},'limitations':['Floating sum and physical quadrature checks, not directed interval certificates.','Infinite dyadic remainder retained as an explicit geometric upper bound; physical infinite tails retained separately.','Pointwise analytic maximizers used, not a grid maximum under the integral.','Only physical n=2 examples; no original traffic integration or general-n order fit.']}
    output.write_text(json.dumps(result,indent=2)+'\n');print('complete 8 dyadic dimensions and 3 physical configurations',flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'adaptive_face_checks.json');args=ap.parse_args();main(args.output)
