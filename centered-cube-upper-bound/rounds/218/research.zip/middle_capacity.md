# R218：全软度 Hellinger 硬面根阶与原中间层的回代接口

状态：本稿证明全软度、全部来源位移和 L≤b 下的明确 Hellinger 缺口，以及真实 hard 上迹加平方根密度权后的根阶面核。它们给出“n(1−s) 与共同接收重叠相乘”的严格根阶机制。尚未证明原正余项拥有该平方根权或一个足够的实际来源列上界；因此不报告原中间层已付。FIRST 三个核和同 α0 的标量容量不能单独补上该步，下面给一次有理筛查，目的仅为排除这一不充分推理。

已先读 R218 task_contract、R217 冻结 capture_geometry.md，沿用经审 PG 的原来源/时间接口。只写本责任文件，无 Git、无额外 agent、不修改他人文件。未引入 ν≤β、未重新使用已耗 w 或已付 capture 恢复额度。

## MC1　准确命题与物理核

写 ε_s=1−s，h=1_[−1/2,1/2]，f_s=ε_s h+sφ，其中原 φ=h*w、w(x)=∫_0^1exp(−|x|/r)dr。φ 是归一、偶、径向非增的连续正密度，且 φ≤1。设

\[
 m=\int_{-1/2}^{1/2}\phi(r)\,dr\in(0,1),\quad r_0=1-m>0,
 \quad a_\phi=\phi(1/2)>0,
\]
\[
 \rho_s=\sqrt{m(1-s+sm)}+(1-m)\sqrt{s}.
 \tag{MC1}
\]
注意 ρ_s 是本稿的核常数，不是实际 capture 余权 ρ0。

**命题 A（全软度正核缺口）。** 对每个 s∈[0,1]、0<L≤b 和任意 y,v∈R^n，

\[
 \int_{\mathbb R^n}\sqrt{P_{s,L}(x-y)P_{1,b}(x-v)}\,dx
 \le\rho_s^n
 \le\exp\{-\tfrac12r_0^2 n(1-s)^2\}.
 \tag{MC2}
\]
这是两个正物理核之间的实际 dx 积分，无 inverse-K、无来源概率假设，也没有来源位移常数。

**命题 B（hard 面的半密度 trace 核）。** 在 b 归一后的坐标 z=(x−y)/b、λ=L/b≤1、d=(v−y)/b 中，令

\[
 p_{s,\lambda}(z)=\lambda^{-1}f_s(z/\lambda),\qquad
 A_j=\int_{\mathbb R}\sqrt{p_{s,\lambda}(z)\phi(z-d_j)}\,dz,
\]
\[
 \Gamma_{s,\lambda}(d)=\frac{1-s}{2}
 \sum_{i=1}^n\sum_{\sigma\in\{-1,1\}}
 \sqrt{\phi(\sigma\lambda/2-d_i)}\prod_{j\ne i}A_j.
 \tag{MC3}
\]
则

\[
 \Gamma_{s,\lambda}(d)\le n(1-s)\rho_s^{n-1}.
 \tag{MC4}
\]
特别 n≥2 时，

\[
 \boxed{\Gamma_{s,\lambda}(d)
 \le{\sqrt{2n}\over r_0\sqrt e}.}
 \tag{MC5}
\]
n=1 时 Γ≤1；s=1 时 Γ=0。这是全 shift、全 λ≤1、全 soft 的根阶面核，而不是把 n(1−s) 单独上放成 n 后再补一个未证平均。

## MC2　命题 A 的完整证明

先看一维并取事件 E=[y−b/2,y+b/2]。归一密度 p=P_s,L(·−y)、j=P1,b(·−v) 满足

\[
 P(E)\ge1-s+s m=m+(1-s)r_0,\qquad J(E)\le m.
 \tag{MC6}
\]
第一式因为 hard 核在 E 内有全质量，且 L≤b 时 scaled φ 在 E 内至少有 m 的质量。第二式因为偶递减 φ 在给定长度区间上的质量，以中心区间最大；这可由层蛋糕表示的区间交长度直接证明，故任意 v 均合法。

两块 Cauchy–Schwarz 给

\[
 \int\sqrt{p j}\le F(P(E),J(E)),\quad
 F(P,Q)=\sqrt{PQ}+\sqrt{(1-P)(1-Q)}.
\]
在 P≥Q 上，F 对 P 非增、对 Q 非减（在端点以连续性解释）。由 MC6，最坏值恰不超过 F(m+(1−s)r0,m)=ρ_s。这里使用的是 P、Q 的联合顺序；不能分别任意放大两块质量。

再用二点概率的初等不等式

\[
 |P-Q|\le\sqrt{1-F(P,Q)^2}.
\]
例如把 P−Q 写成平方根向量差与和的内积并作 Cauchy 即得。于是

\[
 \rho_s\le\sqrt{1-r_0^2(1-s)^2}
 \le e^{-r_0^2(1-s)^2/2}.
 \tag{MC7}
\]
最后只有物理 product receiver 按坐标分解；固定 y,v,L,s 时正 Tonelli 给 affinity 为 n 个一维 affinity 的乘积，得到 MC2。此处完全未把 β、ν、Π 或其来源坐标独立化。

常数可不经数值计算明确控制。正 Tonelli 给

\[
 m=\frac13+2\int_0^1 r^2e^{-1/r}\,dr
 \le\frac13+\frac2{3e}<1,
\quad
 a_\phi=\frac12-\int_0^1r e^{-1/r}\,dr
 \ge\frac{1-e^{-1}}2>0.
 \tag{MC8}
\]
这些界给绝对可用常数，非拟合所得。用 e≥8/3 还可取 r0≥5/12、aφ≥5/16。

## MC3　命题 B 与真实 hard 上迹的单位

每个 A_j≤ρ_s，normal 的 √φ≤1，故 MC3 的 2n 项直接给 MC4。对 n≥2 令 u=1−s∈[0,1]，则

\[
 n u\rho_s^{n-1}
 \le nu\,e^{-r_0^2(n-1)u^2/2}
 \le{n\over r_0\sqrt{e(n-1)}}
 \le{\sqrt{2n}\over r_0\sqrt e}.
\]
中间一步对 u≥0 的标量函数求极大；若其极大点在 [0,1] 外，仍是合法上界。n=1 的空乘积按 1，直接用 φ≤1，不对 n−1 除法。

Γ 本身是 b 归一坐标中的无量纲半密度 trace 核。若仅把 normal 的 √φ 换回物理 √[b^−1φ]，则相应物理 trace 等于 b^−1/2Γ；这一因子不能凭空消失。下面给与实际 hard 面测度的准确关系，从而明确何种密度权才真正能用 MC5。

固定 s,L,y，当前核对 log L 的正 hard 面生产测度是

\[
 d\mu^{hard}_{s,L,y}(x)
 ={1-s\over2}\sum_{i,\sigma}
 \delta_{y_i+\sigma L/2}(dx_i)
 \prod_{j\ne i}\big[L^{-1}f_s((x_j-y_j)/L)dx_j\big].
 \tag{MC9}
\]
其总质量 n(1−s)。令 a_s=f_s(1/2)=1−s+s aφ，p_y^+ 为对应面的 core 内上迹。严格 soft 下所有涉及核正；s=0 只用 hard 支持上的迹或合法极限，不授实际 FULL 身份。则直接按切向坐标分解给

\[
 \boxed{\int
 \sqrt{P_{1,b}(x-v)/p_y^+(x)}\,
 d\mu^{hard}_{s,L,y}(x)
 =\sqrt{\lambda/a_s}\,\Gamma_{s,\lambda}(d).}
 \tag{MC10}
\]
证明：normal 的 p 上迹是 L^−1 a_s，故平方根比的 normal 因子为 √[λφ(σλ/2−d_i)/a_s]；每个切向积分正是 A_j。物理 b^−1/2 与 √L 恰好在 √λ 中配平。闭 hard 面必须取这一真实上迹，不能换成 core 外值 sφ(1/2)。

因 λ≤1、a_s≥aφ，n≥2 时

\[
 \int\sqrt{J_v/p_y^+}\,d\mu^{hard}_{s,L,y}
 \le{\sqrt{2n}\over r_0\sqrt{e a_\phi}};
 \tag{MC11}
\]
n=1 的界为 aφ^−1/2。用 MC8 的粗数值常数，可统一上放为 4√n（e≥8/3 给 n≥2 常数 24√(3/5)/5<4，n=1 也<4）。这是真实加权 hard 面测度的严格结论。

## MC4　为什么尚不能把 MC11 计入原 middle 预算

R217 实际未付子支为 mixed、d_t≥1、ρ0H_+>1；主代理当前进一步的浮动时钟带把原未付对象缩成

\[
 \rho_0(v)\left[
 {p_yw_t(v)\over L_0J_v}-1-
 {p_yK_{0v}\over\kappa TL_0J_v}\right]>\varepsilon.
 \tag{MC12}
\]
这里保原 ρ0、TΔ、α0=DQ/QJ，以及真实 good/bad、high/FIRST、来源和所有门；不把主代理的浮动带当新负信用。

MC10–11 所需的是原 hard 面交通中 **√(J_v/p_y^+) 的实际权**。MC12 和 mixed 只给 J_v/p_y 相对于 w_t 的上界；这与要把一个正交通权上放为 C√(J_v/p_y^+) 的方向相反。capture 公式

\[
 \rho_0=\left(1-{DK_{0v}+\alpha_0J_v\over T\Delta(v)}\right)_+
\]
也没有提供这样的平方根上界；J 很小时，α0 含同一个 QJ，必须保持联合，不能擅自说 ρ0 很小。middle 中 good 可由 K1+K2 项承担，不能把 good 的整个右端改成 J。R128 的旧 hard/J Hellinger 缺口也不授予这种来源/交通转换。

若 MC11 要支付原面，应证明如下类型的**实际支配证书**，而不能仅写其形式后声称成立：在同一原正子支、保真实 hard 面迹及原外测度后，将正面交通支配为

\[
 C_*\int \Xi(d\omega,dV,dj,ds,dL,dy,dv)
 \int\sqrt{J_v/p_y^+}\,d\mu^{hard}_{s,L,y},
 \qquad \Xi(\mathrm{全部})\le W_A.
 \tag{MC13, 未证}
\]
Ξ 必须由实际原 wt、Π_t⊗Π_t（两份 e_t 分母已包含）、δ、ρ0、capture 与历史产生，是对固定 s,L,y,v 的合法非负分解；不能人为换来源、将接收点相关的权移出面积分，或无费混合 selector。若这一证书成立，MC11 立即给 4C_*√n W_A，再恢复尚未计入 C_* 的一次 hard16/3、外2Λ及实际窗口账。不能把这些常数重复计入。

也可用直接的原来源列估计替代 MC13，但须在同一半密度面测度下控制剩余乘子；例如写原权 W=√(J/p^+)·[W√(p^+/J)] 后，后面这个 inverse-ratio 乘子不能删去。现有 good/mixed/capture 支持没有给其统一上帽。

另外，MC2、MC11 是固定 s,L 的真实积分，不是 ∫sup_(s,L) 的界。一个随 x 选择 s,L 的面/尺度生产若未先获得 MC13 这样的合法分解，仍有 selector/时钟占用费；全参数统一常数不等于 supremum 可以移出积分。这是来源权之外另一条不能省略的接口。

## MC5　FIRST 与共同 α0 的一次有限容量筛查

原 RT5 只明示 Q*=(K1+K2+J)/3 的共同容量及 J 容量；不假设单独 K1ν、K2ν 各≤Q。确定能用的推论为：

\[
 \int J_v\rho_0H_+\,\nu(dv)
 \le\int(K_{1v}+K_{2v})\nu(dv)\le3Q-Q_J\le3Q.
 \tag{MC14}
\]
PG 的 good、高行/外 β 回代会把它变成 O(L0)·Q dx 的体积价；这既不是任意小 εX，也不能直接作为固定 J 的 W_A 价。α0 与 TΔ 的关联仍在，不能凭“capture 总量≤DQ”从 MC14 再无条件取一个小因子。

以下一次有理筛查额外施加更强的 K1f,K2f≤Q，说明即使加强这些标量容量和各门的代数形式，也不能做该取小步骤；这组加强条件并不是原 FIRST 的等同表述。它不是物理核或 FULL 历史反例，故不否定任何利用真实 y−v 与 receiver 重叠的新证明。

取 n=16,K=1,L0=4,κ=1,Q=1,D≥1,T=2D。三个抽象位置 y,v,u 上，用同一个非负承载 f=β+ν，β=(1/8)δ_y、ν=δ_v+δ_u。令 η∈(0,1/100]，赋核表

|位置|K1|K2|K0|J|
|---|---:|---:|---:|---:|
|y|4|4|η|η|
|v|1/2−η|1/2−η|η|η|
|u|η|η|η|η|

于是 K1f=K2f=1、K0f=Jf=17η/8≤1；p_y=4、∫p_yβ=1/2。整个筛查使用同一个 f 同时承载 β、ν，没有假设 ν≤β。

取 terminal g=1，v 的单项 clock w_t=(a/t)^16 于 t≥a、a=24^(−1/16)，之前 w=1。令 τ=a、h=2^(−1/16)、当前 t=4^(−1/16)，故

\[
 w_\tau(v)=1,\quad w_t(v)=1/6,\quad w_h(v)=1/12,
 \quad w_g(v)=1/24,\quad\Delta(v)=11/12.
\]
u 的 clock 恒为1。它们是实际 min-product 型单项 clock 数值，可取 v 的16个阈值均为 a，u 的阈值均≥1；这不证明它们与表中物理核同一空间实现。

有 e_g=25/24，high 为 p_y e_g=25/6≥2；target good 为 3p_ywg(v)=1/2≤1−η，u 为 bad。d_t(v)=3≥1。两腿 mixed 分别为 η(6+3/D)<1、η(1+1/(2D))<1。共同 QJ=2η、α0=D/(2η)，从而

\[
 \rho_0(v)={8-6\eta\over11},\quad
 J_v\rho_0H={8-6\eta\over11}
 [1-2\eta-\eta/(2D)]\longrightarrow8/11.
 \tag{MC15}
\]
同时 MC12 左端为

\[
 {8-6\eta\over11}[1/(6\eta)-1-1/(2D)]\longrightarrow\infty.
\]
而 √(J_v/p_y)=√η/2→0；原 clock/source 正权也并未在此标量模型中趋零。因此既不能从容量表和共同 α0 推任意小源核剩余，也不能仅由这些门推出无额外几何的 ρ0≤C√(J/p)。真正要用的是这些标量能否同时来自实际物理核、位移、receiver 与当前 FIRST/history；MC2/MC10 提供的正是可以继续利用的物理重叠信息。

## MC6　本机证据、费用与停止点

实际运行本机 Python Fraction，对 D=1、η=1/100,1/1000,1/10000 核对 MC5 的共同 FIRST、high/good/mixed 和精确表达式。得到 JρH 分别为 15483/22000、1594803/2200000、159948003/220000000；浮动超额分别为 36127/3300、3961027/33000、399610027/330000。它们只筛查一个容量论证，不声称物理可实现。本机默认 Python 的 mpmath 不可用，未伪报高精度核积分；MC8 和最终常数均由解析不等式给出，不依赖该库。

本稿没有消费任何 signed negative，原所有负项仍原位一次。R217 已付 ρ0H≤1 支与主代理新增浮动带保持各自原账；MC2–11 不另领取正项预算。Hhat<L+、lower clamp、CG3 以外的所有实际尺度均未删除；核缺口甚至只要求 L≤b。对 middle 支，CG3 的 A,a,C,z、CH 的维数费用仍保原联合值，不把它们分别极值化。

本轮实质结论是全 soft 的 explicit root hard-face kernel MC10–11；最早未证位置是原来源/时钟/selector 的半密度支配或列预算 MC13。没有证明完整原 middle 或一般根阶弱型目标。完成后停止，不继续扩为反例目录或用窄 selector 菜单替代一般推进。
