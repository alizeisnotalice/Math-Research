#!/usr/bin/env python3
"""Round 51: exact finite dyadic regularization and receiver certificates.

Only the standard library is used. Fraction assertions certify the finite
instances. Decimal logarithms are display values, not interval certificates.
Uniform-cloud and cap examples are symbolic volume/parameter guards; they are
not numerical estimates of a general weak constant.
"""
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
from pathlib import Path
from random import Random
from decimal import Decimal, localcontext
import json
import time


def power2(k):
    return F(2**k) if k >= 0 else F(1, 2**(-k))


def cell_at(point, level):
    side = power2(level)
    return (level, tuple(x // side for x in point))


def bounds(cell):
    level, index = cell
    side = power2(level)
    return tuple((i*side, (i+1)*side) for i in index)


def inside(point, cell, closed=False):
    return all(l <= x <= h if closed else l <= x < h
               for x, (l, h) in zip(point, bounds(cell)))


def maximal_bad(points, weights, H):
    """Scan every relevant level: being bad need not be monotone upward.

    Standard dyadic ancestors of points on opposite sides of zero need not
    merge. No common ancestor is used. All cells above high are nonbad by the
    total mass bound, and every atom's cell at low is bad by its own mass.
    """
    n = len(points[0]); W = sum(weights); amin = min(weights)
    low = 0
    while H * power2(low)**n >= amin:
        low -= 1
    high = 0
    while H * power2(high)**n < W:
        high += 1
    tables = {}
    for level in range(low, high+1):
        mass = defaultdict(F)
        for p, w in zip(points, weights):
            mass[cell_at(p, level)] += w
        tables[level] = dict(mass)
    selected = set()
    for p in points:
        bad = [level for level in range(low, high+1)
               if tables[level][cell_at(p, level)] > H*power2(level)**n]
        assert bad and bad[-1] < high
        selected.add(cell_at(p, bad[-1]))
    cells = sorted(selected)
    masses = [tables[c[0]][c] for c in cells]
    labels = []
    for p in points:
        hits = [j for j, c in enumerate(cells) if inside(p, c)]
        assert len(hits) == 1
        labels.append(hits[0])
    assert len(cells) <= len(points) and sum(masses) == W
    for j, c in enumerate(cells):
        side = power2(c[0]); density = masses[j]/side**n
        assert H < density <= 2**n*H
        # The parent is explicitly checked, rather than inferred from a run
        # of bad levels. Its mass includes all original labels.
        parent = cell_at(points[labels.index(j)], c[0]+1)
        parent_mass = sum(w for p, w in zip(points, weights) if inside(p, parent))
        assert parent_mass <= H*(2*side)**n
        assert H*side**n < masses[j]
        assert sum(w for w, label in zip(weights, labels) if label == j) == masses[j]
        for c2 in cells[j+1:]:
            assert any(h <= l2 or h2 <= l
                       for (l, h), (l2, h2) in zip(bounds(c), bounds(c2)))
    return cells, masses, labels, low, high


PATTERNS = ('boundary', 'signed', 'near', 'multiscale', 'seeded', 'tiny')


def fixture(n, N, pattern):
    rng = Random(510000 + 10000*n + 100*N + PATTERNS.index(pattern))
    if pattern == 'boundary':
        points = [tuple(F(j-N//2, 4) if i == 0 else F(j % (i+2)-i, 2)
                        for i in range(n)) for j in range(N)]
    elif pattern == 'signed':
        points = [tuple(F((-1)**(j+i)*(j+1)*(i+1), 7)
                        for i in range(n)) for j in range(N)]
    elif pattern == 'near':
        points = [tuple(F((-1)**i, 2) + F((j+1)*(i+1), 2**16)
                        for i in range(n)) for j in range(N)]
    elif pattern == 'multiscale':
        points = [tuple((-1)**(j+i)*power2(j % 10-5) + F(i, 64)
                        for i in range(n)) for j in range(N)]
    else:
        points = [tuple(F(rng.randint(-80, 80), rng.choice((2, 3, 7, 16)))
                        for _ in range(n)) for _ in range(N)]
    raw = [F(rng.randint(1, 97)) for _ in range(N)]
    if pattern == 'tiny':
        raw[0] = F(1, 2**40)
    W = sum(raw)
    return tuple(points), tuple(w/W for w in raw)


def discrete_cloud(cells, masses):
    """A real positive three-point measure in each cell's closed support.

    Upper corners can be shared by closures. Labels and mass are retained
    separately; the exact maximal calculation sums all captured atoms.
    """
    points = []; weights = []; labels = []
    for j, (c, m) in enumerate(zip(cells, masses)):
        bb = bounds(c)
        pp = (tuple(l for l, h in bb), tuple(h for l, h in bb),
              tuple((l+h)/2 for l, h in bb))
        for p, fraction in zip(pp, (F(1, 7), F(2, 7), F(4, 7))):
            assert inside(p, c, closed=True)
            points.append(p); weights.append(m*fraction); labels.append(j)
    assert sum(weights) == sum(masses)
    return tuple(points), tuple(weights), tuple(labels)


def maximal(points, weights, x):
    """Exact all-scale finite-atomic maximal value, with grouped entry ties.

    None denotes infinity at an atom. Otherwise the optimum is reached at a
    distance-group entry side, since mass stays constant between entries.
    """
    n = len(x); groups = defaultdict(F)
    for p, w in zip(points, weights):
        d = max(abs(a-b) for a, b in zip(p, x))
        groups[d] += w
    if groups.get(F(0), F(0)):
        return None, F(0), groups[F(0)]
    accumulated = F(0); best = F(0); side = F(0); captured = F(0)
    for d in sorted(groups):
        accumulated += groups[d]
        value = accumulated/(2*d)**n
        if value > best:
            best = value; side = 2*d; captured = accumulated
    assert best > 0 and side > 0 and best == captured/side**n
    return best, side, captured


def expanded_certificate(source, source_w, source_labels, target, target_w,
                         cells, masses, H, x, source_max, target_max):
    """No radical comparison: verify the rational witness used by the proof."""
    value, side, captured = source_max; n = len(x)
    if value is None:
        atom = next(j for j, p in enumerate(source) if p == x)
        label = source_labels[atom]; touched = [label]
        m = masses[label]; ell = power2(cells[label][0]); expanded = 2*ell
        assert H*ell**n < m
        assert target_max[0] is None or target_max[0]*2**n > H
    else:
        touched = sorted({label for p, label in zip(source, source_labels)
                          if max(abs(a-b) for a, b in zip(p, x)) <= side/2})
        m = sum(masses[j] for j in touched)
        ell = max(power2(cells[j][0]) for j in touched)
        expanded = side + 2*ell
        assert m >= captured and H*ell**n < m
    got = sum(w for p, w in zip(target, target_w)
              if max(abs(a-b) for a, b in zip(p, x)) <= expanded/2)
    assert got >= m
    assert target_max[0] is None or target_max[0] >= m/expanded**n
    return dict(source_infinite=value is None, labels=len(touched),
                completed_mass=str(m), expanded_side=str(expanded),
                counterpart_capture=str(got))


@lru_cache(None)
def root_interval(q, n, bits=48):
    q = F(q)
    if q == 0:
        return F(0), F(0)
    assert q > 0
    if n == 1:
        return q, q
    hi = F(1)
    while hi**n < q:
        hi *= 2
    if hi**n == q:
        return hi, hi
    lo = F(0) if hi == 1 else hi/2
    for _ in range(bits):
        mid = (lo+hi)/2
        if mid**n == q:
            return mid, mid
        if mid**n < q:
            lo = mid
        else:
            hi = mid
    assert lo**n <= q <= hi**n
    return lo, hi


def inverse_interval(value, n):
    return (F(0), F(0)) if value is None else root_interval(1/value, n)


def decimal_display(q):
    with localcontext() as ctx:
        ctx.prec = 50
        return str(Decimal(q.numerator)/Decimal(q.denominator))


def log_display(q):
    with localcontext() as ctx:
        ctx.prec = 50
        return str((Decimal(q.numerator)/Decimal(q.denominator)).ln())


def interval_union_length(intervals):
    union = []
    for l, h in sorted((l, h) for l, h in intervals if l < h):
        if not union or l > union[-1][1]:
            union.append([l, h])
        elif h > union[-1][1]:
            union[-1][1] = h
    return sum((h-l for l, h in union), F(0))


def main():
    started = time.monotonic(); records = []; metric_sources = []
    for n in range(1, 9):
        for N in (2, 3, 8, 16, 32):
            for pattern in PATTERNS:
                points, weights = fixture(n, N, pattern)
                for H in (F(1, 8), F(1), F(8)):
                    cells, masses, labels, low, high = maximal_bad(points, weights, H)
                    density = [m/power2(c[0])**n for c, m in zip(cells, masses)]
                    records.append(dict(stage='dyadic_cells', n=n, N=N, pattern=pattern,
                        H=str(H), low_level=low, high_level=high, cells=len(cells),
                        mass=str(sum(masses)), density_min=str(min(density)),
                        density_max=str(max(density)),
                        cell_data=[dict(level=c[0], index=list(c[1]), mass=str(m))
                                   for c, m in zip(cells, masses)]))
                    if N in (2, 8, 32) and pattern in ('boundary', 'near', 'multiscale') and H != 1:
                        metric_sources.append((n, N, pattern, H, points, weights, cells, masses, labels))
    # An explicit gap of nonbad levels followed by a larger bad ancestor.
    p = ((F(0),), (F(3, 4),)); w = (F(1, 20), F(19, 20)); H = F(1, 2)
    cells, masses, labels, low, high = maximal_bad(p, w, H)
    states = []
    for k in (-4, -3, -2, -1, 0, 1):
        c = cell_at(p[0], k)
        m = sum(a for z, a in zip(p, w) if inside(z, c))
        states.append(m > H*power2(k))
    assert states == [True, False, False, False, True, False]
    assert cells == [(0, (0,))] and masses == [F(1)]
    records.append(dict(stage='nonmonotone_bad_regression', levels=list(range(-4, 2)),
                        bad=states, maximal_level=0))
    p = ((F(1, 4),), (F(5, 4),)); w = (F(1, 10), F(3)); H = F(1)
    cells, masses, labels, low, high = maximal_bad(p, w, H)
    states = [sum(a for z, a in zip(p, w) if inside(z, cell_at(p[0], k)))
              > H*power2(k) for k in (0, 1, 2)]
    assert states == [False, True, False]
    assert cells == [(1, (0,))] and masses == [F(31, 10)]
    records.append(dict(stage='nonmonotone_bad_regression', levels=[0, 1, 2],
                        bad=states, maximal_level=1, source_mass='31/10'))
    for r in (F(1, 2), F(1, 32), F(1, 1024)):
        costs = []
        for scaled in (F(1, 4), F(1, 2), F(5, 8), F(3, 4), F(7, 8), F(1), F(2)):
            lam = scaled/(2*r)
            intervals = ((-r-F(1, 4)/lam, -r+F(1, 4)/lam),
                         (r-F(1, 4)/lam, r+F(1, 4)/lam),
                         (r-F(1, 2)/lam, -r+F(1, 2)/lam))
            cost = lam*interval_union_length(intervals)
            expected = (1-scaled if scaled <= F(1, 4) else
                        scaled+F(1, 2) if scaled <= F(3, 4) else
                        2-scaled if scaled <= 1 else F(1))
            assert cost == expected
            costs.append(cost)
            records.append(dict(stage='two_atom_threshold_oracle', n=1, N=2,
                radius=str(r), scaled_threshold=str(scaled), threshold=str(lam), cost=str(cost),
                scope='exact three-subset interval union at listed thresholds; analytic all-threshold formula proved separately'))
        assert max(costs) == F(5, 4)
    ratios = []
    for n, N, pattern, H, points, weights, cells, masses, labels in metric_sources:
        cloud, cloud_w, cloud_labels = discrete_cloud(cells, masses)
        bb = bounds(cells[0]); center = tuple((l+h)/2 for l, h in bb)
        boundary = (bb[0][1],) + center[1:]
        receivers = (points[0], points[-1], cloud[0], cloud[-1], center,
                     boundary, tuple(F(100+i, 3) for i in range(n)))
        for rid, x in enumerate(receivers):
            A = maximal(points, weights, x); B = maximal(cloud, cloud_w, x)
            ca = expanded_certificate(points, weights, labels, cloud, cloud_w,
                                      cells, masses, H, x, A, B)
            cb = expanded_certificate(cloud, cloud_w, cloud_labels, points, weights,
                                      cells, masses, H, x, B, A)
            da = inverse_interval(A[0], n); db = inverse_interval(B[0], n)
            hh = root_interval(1/H, n)
            difference_upper = max(abs(da[0]-db[1]), abs(da[1]-db[0]))
            assert difference_upper <= 2*hh[0]
            ratio = difference_upper/(2*hh[0]); ratios.append(ratio)
            records.append(dict(stage='inverse_metric', n=n, N=N, pattern=pattern,
                H=str(H), receiver=rid, x=list(map(str, x)),
                M_original='infinity' if A[0] is None else str(A[0]),
                M_discrete_cloud='infinity' if B[0] is None else str(B[0]),
                inverse_original=list(map(str, da)), inverse_cloud=list(map(str, db)),
                normalized_error_upper=str(ratio), original_to_cloud=ca, cloud_to_original=cb,
                scope='exact finite discrete cloud; no continuous uniform-cell M enumeration'))
    for n in range(1, 9):
        theta = F(1, 100*n)
        for N in (2, 8, 32, 128):
            normalized_centers = [F(-theta+2*theta*j/(N-1)) for j in range(N)]
            assert len(set(normalized_centers)) == N
            assert all(abs(x) <= theta for x in normalized_centers)
            for delta in (F(1, 2*n), F(1, n)):
                for lam in (F(1, 8), F(1), F(8)):
                    packet_density = lam/(2*delta)**n
                    core_volume = (2*delta)**n/(N*lam)*(1-theta)**n
                    core_mass = N*packet_density*core_volume
                    assert core_mass == (1-theta)**n >= F(99, 100)
                    records.append(dict(stage='uniform_splat_overlap', n=n, N=N,
                        delta=str(delta), reference_threshold=str(lam), theta=str(theta),
                        packet_density=str(packet_density), core_density=str(N*packet_density),
                        core_volume=str(core_volume), core_mass=str(core_mass), overlap_count=N,
                        scope='symbolic exact mass of a common subcube; not a weak-cost test'))
    for n in tuple(range(1, 9)) + (16, 32, 64, 128, 256):
        for c in (F(1, 4), F(1, 2), F(1)):
            delta = c/n; lam = F(1); H = lam/delta**n
            coverage = (1+2*delta)**n; tau = lam/coverage
            upper_density = 2**n*H
            ratio = upper_density/tau
            assert ratio == (2/delta+4)**n and coverage <= 9
            necessary_density = lam/(2*delta)**n
            assert upper_density/necessary_density == 4**n
            assert necessary_density*(2*delta)**n == lam
            records.append(dict(stage='parameter_and_cap_budget', n=n, c=str(c), delta=str(delta),
                reference_threshold='1', H=str(H), coverage_factor=str(coverage),
                matched_threshold=str(tau), density_upper=str(upper_density),
                density_ratio=str(ratio), log_density_ratio_display=log_display(ratio),
                metric_error=str(2*delta), necessary_density=str(necessary_density),
                uniform_cube_density=str(necessary_density), cap_ratio=str(4**n),
                scope='bounded-density necessity for inverse metric; not a weak-constant lower bound'))
    counts = {}; phase_counts = {}
    for r in records:
        n = r.get('n', 1); N = r.get('N', 2)
        phase = 'initial' if n <= 2 and N <= 8 else (
            'pressure' if n <= 4 and N <= 32 else 'expanded')
        r['phase'] = phase
        phase_counts[phase] = phase_counts.get(phase, 0)+1
        counts[r['stage']] = counts.get(r['stage'], 0)+1
    result = dict(round=51, status='PASS', cases=len(records), counts=counts,
        phase_counts=phase_counts,
        phase_definition='parameter groups in one complete execution, not three independent runs: initial n<=2,N<=8; pressure n<=4,N<=32 outside initial; expanded remaining cases',
        seed=510000, exact_arithmetic='Fraction; 48-bit rational nth-root enclosures',
        proof_status='finite guards for proved coverage/metric lemmas; square-root weak bound unproved',
        ranges=dict(n_dyadic=[1, 8], N_dyadic=[2, 32], H=['1/8', '1', '8'],
                    metric_source_cases=len(metric_sources), metric_receivers_per_source=7,
                    n_symbolic_max=256, overlap_N_max=128,
                    tiny_unnormalized_weight='1/1099511627776',
                    normalized_metric_error_upper_max=str(max(ratios)),
                    normalized_metric_error_upper_max_display=decimal_display(max(ratios))),
        records=records)
    Path(__file__).with_name('results.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print(json.dumps(dict(status=result['status'], cases=result['cases'], counts=counts,
                          phase_counts=phase_counts,
                          runtime_seconds=round(time.monotonic()-started, 3)), sort_keys=True))


if __name__ == '__main__':
    main()
