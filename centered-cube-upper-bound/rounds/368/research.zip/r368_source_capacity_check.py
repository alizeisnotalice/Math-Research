from fractions import Fraction as F
from itertools import product
from math import factorial
counts={'interval_product':0,'tail_volume':0,'sign':0,'nesting':0}
def ck(ok,k):
    assert ok,k
    counts[k]+=1
def overlap(l,r,L,R):return max(F(0),min(r,R)-max(l,L))
def parts(x,t,L,clip=None):
    l=x-t/2;r=x+t/2
    atom=overlap(l,r,-L/2,L/2)
    out=[('atom',F(0),F(0),atom)]
    for lo,hi in [(max(F(0),2*l-L),max(F(0),2*r-L)),
                  (max(F(0),-2*r-L),max(F(0),-2*l-L))]:
        if clip is not None:hi=min(hi,clip)
        if hi>lo:out.append(('interval',lo,hi,F(1,2)))
    return out
def convolution_mass(P,T):
    ans=F(0)
    for choices in product(*P):
        coeff=F(1);intervals=[]
        for kind,l,h,w in choices:
            coeff*=w
            if kind=='interval':intervals.append((l,h))
        k=len(intervals)
        if not k:ans+=coeff;continue
        vol=F(0);base=T-sum((l for l,h in intervals),F(0))
        for bits in product([0,1],repeat=k):
            rem=base-sum(((h-l)*bit for (l,h),bit in zip(intervals,bits)),F(0))
            vol+=(-1)**sum(bits)*max(F(0),rem)**k
        ans+=coeff*vol/factorial(k)
    return ans
def profile(xs,t,R,hN,tA):
    L=R-t;P=[parts(x,t,L) for x in xs]
    Pc=[parts(x,t,L,hN) for x in xs]
    vn=F(1);vn_alt=F(1)
    for x,pp in zip(xs,Pc):
        vn*=overlap(x-t/2,x+t/2,-(L+hN)/2,(L+hN)/2)
        vn_alt*=sum((w if k=='atom' else w*(h-l) for k,l,h,w in pp),F(0))
    ck(vn==vn_alt,'interval_product')
    va=convolution_mass(P,tA);van=convolution_mass(Pc,tA)
    tail=t**len(xs)-vn-va+van
    ck(0<=van<=min(vn,va) and 0<=tail<=t**len(xs),'tail_volume')
    return tail
for n in [1,2,3]:
  for seed in range(1,13):
    R=F(2);xs=[F((seed*(i+2)+i)%9-4,4) for i in range(n)]
    hN=F(1,4);tA=F(1,2)
    for t in [F(1),F(5,4),F(3,2),F(7,4)]:
        v=profile(xs,t,R,hN,tA)
        vm=profile([-x for x in xs],t,R,hN,tA)
        ck(v==vm,'sign')
    for seedv in range(1,17):
        center=[F((seedv*(i+3)+i)%17-8,4) for i in range(n)]
        prev=False
        for t in [F(1),F(5,4),F(3,2),F(7,4)]:
            cap=all(abs(v-y)<=t/2 for v,y in zip(center,xs))
            excess=[max(F(0),2*abs(v)-R+t) for v in center]
            live=cap and max(excess)>hN and sum(excess)>tA
            ck(not prev or live,'nesting')
            prev=live
print('PASS source-depth capacity checks',counts,'total',sum(counts.values()))
