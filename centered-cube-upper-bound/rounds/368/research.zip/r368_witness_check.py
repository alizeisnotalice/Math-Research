from fractions import Fraction as F
from pathlib import Path
import json
n=10000;delta=F(1,100*n);rho=F(1,10**7);u=F(-2,5);v=F(7,10);s=F(3,2)
checks={}
def ck(k,b):
 assert b,k
 checks[k]=bool(b)
ck('U_inside_E',abs(u)+rho<F(3,4)-delta)
ck('V_inside_E',abs(v)+rho<F(3,4)-delta)
ck('U_baseline_one',2*(abs(u)+rho)+2*delta<1)
ck('V_baseline_below_three_halves',2*(abs(v)+rho)+2*delta<s)
ck('common_source_U',abs(u)+rho+delta<1)
ck('common_source_V',abs(v)+rho+delta<s/2)
ck('alpha_upper_power',F(21,20)**100>101)
ck('alpha_upper_exponent',n>=100)
ck('outside_old_expanded_center',v-u-2*rho>F(21,20))
ck('big_center_outside_small',v-u-2*rho>s/2)
ck('ratio_gate',s==F(3,4)*2)
e_lo=2*(v-u-2*rho)-(2-s);e_hi=2*(v-u+2*rho)-(2-s)
ck('joint_excess_gate',e_hi<n*s/64)
ck('other_excess_zero',4*rho<2-s)
ck('not_old_N',e_lo>F(19,4*n))
ck('not_old_A',e_lo>F(361,64*n))
ck('log_upper',F(8,3)**19>10002**2)
ck('massgap_base',F(4,3)**4>3)
ck('massgap_exponent',n//4>100 and n%4==0)
ck('removed_baseline_capacity',0<2*rho<1)
Z=F(49*n,150)-2;H=F(310272,119)
ck('strict_past_and_highJ',Z>H)
ck('positive_boxes_disjoint',v-u>2*rho>0)
result={'n':n,'exact_checks':checks,'count':len(checks),'past_lower':str(Z),'H_and_hstar':str(H),'excess_interval':[str(e_lo),str(e_hi)],'joint_excess_threshold':str(n*s/64),'scope':'original R338 exterior highpast branch intersect new D; not full general upper bound'}
Path(__file__).with_name('r368_witness_result.json').write_text(json.dumps(result,indent=2))
print('PASS',len(checks),'exact actual-domain checks','past',Z,'H',H)
