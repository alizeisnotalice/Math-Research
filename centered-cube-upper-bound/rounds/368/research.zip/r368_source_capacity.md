# R368 — Source-depth-conditioned capacity of the exact geometric tail

## Scope and result

Retain the original hard matched field and the exact R367 tail: strict m_u>K m_v, original global strict-past source gate, full J_y(r)>=H, and not N(u,v) AND not A(u,v). Here K=exp(sqrt(n)), q_-<=q_u<=lambda, a<=R_u<=b<=2a, and u is the larger-radius receiver. The two frozen geometric tolerances are

    h_N=a log(n+2)/(2n), t_A=a log(n+2)^2/(16n),
    e_i(u,v)=(2|u_i-v_i|-(R_u-R_v))_+,
    N={max e_i<=h_N}, A={sum e_i<=t_A}.

The result is an explicit REAL center capacity conditioned on the original source's coordinate depths in the large cube. It gives the quantitative posterior-depth criterion in §3. That criterion is sufficient and can be evaluated from the actual f; it has NOT been proved for all inputs. No unconditional new root receipt or fixed coverage fraction is claimed. No old inner-shell or N/A payment is charged again.

## 1. Exact nested tail center sets

Fix an actual larger receiver u, with R=R_u, and a source y in Q_R(u). Define

    U=(m_u/(K q_-))^(1/n)<R.

If U<=a, there are no strictly smaller-mass receivers in the original slot and set C_u(y)=0. Otherwise put, for a<=t<=U,

    S_tail(t;u,y)={v in Q_t(y):
       max_i(2|v_i-u_i|-R+t)_+>h_N,
       sum_i(2|v_i-u_i|-R+t)_+>t_A},
    V_tail(t;u,y)=|S_tail(t;u,y)|.                        (1)

These sets increase with t: the capturing center cube Q_t(y) increases, and each protrusion expression is nondecreasing in t. Strict inequalities cause no loss; center level boundaries are null for these positive tolerances. The closure gives the same volume if an entry boundary is needed in layer cake.

The actual mass-gap condition gives R_v<U. Matching at THAT receiver gives 1/m_v<=1/(q_-R_v^n). Extending only the positive receiver-center integral therefore proves

    integral_{v: m_v<m_u/K, not N, not A} c_v(y)mu(dv)
       <=C_u(y),                                        (2)
    C_u(y)=q_-^(-1)[V_tail(U;u,y)/U^n
                   +n integral_a^U V_tail(t;u,y)t^(-n-1)dt].

All original further receiver/past/physical-time predicates may be retained on the left of (2). They are dropped only for this upper bound. The formula is the exact integral of sup_(a<=t<=U) t^(-n)1_(S_tail(t)) over REAL centers, divided by q_-. It includes the base-radius volume and uses no source density cap.

The finite interval formulas below and positive integration show that C_u(y) is measurable in the actual measurable receiver parameters and y; the posterior sets used later are therefore measurable.

In particular

    0<=C_u(y)<=C_max(u):=[1+n log(U/a)]/q_-               (3)

when U>a. This pointwise coarse bound can still be of order n. The new profile in (2) retains all coordinate depths rather than replacing it by (3).

## 2. An exact interval-product/simplex expression for the profile

Translate u to zero and write x_i=y_i-u_i. Let

    I_i=[x_i-t/2,x_i+t/2], L=R-t>=0.

The source's two face depths are R/2-x_i and R/2+x_i. All formulae below depend only on |x_i|, equivalently on the smaller depth delta_i=R/2-|x_i|; changing source-coordinate signs changes no volume.

The volume removed by N alone inside the capturing center box is the exact product

    V_N(t)=product_i |I_i intersect [-(L+h_N)/2,(L+h_N)/2]|.
                                                               (4)

For the A part, push Lebesgue measure on I_i through e=(2|v_i|-L)_+. Its measure nu_i on [0,infinity) has:

* an atom at zero of mass |I_i intersect [-L/2,L/2]|;
* density 1/2 on each of the two positive intervals obtained from the positive and negative sides of I_i by e=2|v_i|-L, retaining multiplicity if the intervals overlap.

Thus the two exact mixed-center volumes are

    V_A(t)=integral 1_{sum e_i<=t_A} product_i nu_i(de_i),
    V_AN(t)=integral 1_{sum e_i<=t_A, all e_i<=h_N}
                                               product_i nu_i(de_i).

Inclusion-exclusion gives the desired joint profile, without double counting the already-paid union:

    V_tail(t)=t^n-V_N(t)-V_A(t)+V_AN(t).                  (5)

These products concern the center variable dv. They make no claim that f or its conditional source coordinates factor. Formula (5) uses the TRUE tail complement of N union A, rather than pricing either old branch again.

For a direct finite formula, choose in each nu_i either its zero atom or one of its constant-density intervals. If k continuous intervals [l_j,h_j] are chosen, their constrained volume is

    (1/k!) sum_(B subset {1,...,k}) (-1)^|B|
           (t_A-sum_j l_j-sum_(j in B)(h_j-l_j))_+^k,     (6)

times the chosen atom masses and density factors 2^(-k). For k=0 it is the zero-atom product. For V_AN clip each interval at h_N before applying (6). This is an explicit, finite source-depth profile, not an unspecified geometric predicate.

## 3. A true posterior-depth criterion, with its exact bill

Let pi_u(dy)=f(y)c_u(y)dy/m_u be the unchanged full-source posterior in the actual larger cube, and define

    Cbar(u)=integral C_u(y)pi_u(dy).                      (7)

Keep any measurable subset B of actual larger receivers. Applying (2) to the original G tail, then m_u-m_v<=m_u, and only afterward 1/J_y(r)<=1/H, yields

    G_tail[large u in B]
       <=(1/H) integral_B q_u Cbar(u)du.                 (8)

Proof of the source integration: before integrating physical time, the upper expression is

    (1/H) integral ell(dr) integral_(E_r intersect B)du
                       integral f(y)c_u(y)C_u(y)dy.

The inclusive clock tail gives R_u^(-n). Since the inner source integral is m_u Cbar(u), their product is exactly q_u Cbar(u). This is the original matching mass, not f times a boundary volume. The b atom, original J and original strict-past predicate were never reset. Dropping the past predicate in this upper bound does not assert a new qualified entrance.

For example fix eps>0 and, for each u with U>a, use the entirely geometric source-depth set

    D_good(u)={y in Q_u:C_u(y)<=eps H/2}.

The ACTUAL posterior concentration condition

    pi_u(Q_u minus D_good(u))
          <=min(1,eps H/[2 C_max(u)])                    (9)

implies Cbar(u)<=eps H, by (3),(7). Consequently the whole original tail on larger receivers satisfying (9) is paid by

    G_tail[condition (9)]<=eps X_q[condition (9)].        (10)

More generally (8) works directly without the two-level quantile bound. Condition (9) is a source concentration criterion on an explicit depth-profile capacity, not a restatement of the original pair integral or a f-density assumption. Its validity for a given field must be checked using that field's true posterior. No assertion is made that the condition holds for all, or any fixed fraction of, actual high-past receivers. If its selected subdomain is empty, (10) is simply vacuous.

The exact complement is the SAME G_tail with its larger receiver failing (9), retaining not N, not A, strict high past, mass gap and the original full J/time. Neither the old N/A union bill nor the old inner-source stopping bill is charged in (10). If used as a new positive split in the original entrance, only the new eps X_q contribution is multiplied by the original exterior factors.

## 4. Missing unconditional estimate

The explicit depth capacity still admits only the coarse O(n) bound (3) in general. In particular, the cap controls possible REAL receiver centers, while (9) controls source MASS under pi_u; the two are different measures. A small-volume source-depth set cannot be declared to have small f mass. Nor does nesting of center sets across t imply disjoint source use across different u.

What is missing for the desired unconditional result is a source-matched aggregate estimate for the large-receiver population failing (9), or a direct estimate of the weighted profile integral in (8) that gains over (3). This note supplies neither. The old R355 inner-shell center envelope and the already-paid R367 union volume do not by themselves imply the needed posterior statement. Thus (2)-(8) are a concrete refinement of the geometric capacity, and (9)-(10) give its exact conditional price, but are not presented as a new unconditional root-order payment. Work stops at this explicit source-mass concentration gap.

## 5. Local checks

The script checks the mixed interval/atom formula, the N intersection product, source-sign invariance, and nesting of the ACTUAL tail sets using exact rational arithmetic. It is a geometry-interface test. It does not verify (9) for arbitrary f or realize the original high-past contract.

~~~python
from fractions import Fraction as F
from itertools import product
from math import factorial
counts={'interval_product':0,'tail_volume':0,'sign':0,'nesting':0}
def ck(ok,k):
    assert ok,k
    counts[k]+=1
def overlap(l,r,L,R):return max(F(0),min(r,R)-max(l,L))
def parts(x,t,L,clip=None):
    l=x-t/2;r=x+t/2
    atom=overlap(l,r,-L/2,L/2)
    out=[('atom',F(0),F(0),atom)]
    for lo,hi in [(max(F(0),2*l-L),max(F(0),2*r-L)),
                  (max(F(0),-2*r-L),max(F(0),-2*l-L))]:
        if clip is not None:hi=min(hi,clip)
        if hi>lo:out.append(('interval',lo,hi,F(1,2)))
    return out
def convolution_mass(P,T):
    ans=F(0)
    for choices in product(*P):
        coeff=F(1);intervals=[]
        for kind,l,h,w in choices:
            coeff*=w
            if kind=='interval':intervals.append((l,h))
        k=len(intervals)
        if not k:ans+=coeff;continue
        vol=F(0);base=T-sum((l for l,h in intervals),F(0))
        for bits in product([0,1],repeat=k):
            rem=base-sum(((h-l)*bit for (l,h),bit in zip(intervals,bits)),F(0))
            vol+=(-1)**sum(bits)*max(F(0),rem)**k
        ans+=coeff*vol/factorial(k)
    return ans
def profile(xs,t,R,hN,tA):
    L=R-t;P=[parts(x,t,L) for x in xs]
    Pc=[parts(x,t,L,hN) for x in xs]
    vn=F(1);vn_alt=F(1)
    for x,pp in zip(xs,Pc):
        vn*=overlap(x-t/2,x+t/2,-(L+hN)/2,(L+hN)/2)
        vn_alt*=sum((w if k=='atom' else w*(h-l) for k,l,h,w in pp),F(0))
    ck(vn==vn_alt,'interval_product')
    va=convolution_mass(P,tA);van=convolution_mass(Pc,tA)
    tail=t**len(xs)-vn-va+van
    ck(0<=van<=min(vn,va) and 0<=tail<=t**len(xs),'tail_volume')
    return tail
for n in [1,2,3]:
  for seed in range(1,13):
    R=F(2);xs=[F((seed*(i+2)+i)%9-4,4) for i in range(n)]
    hN=F(1,4);tA=F(1,2)
    for t in [F(1),F(5,4),F(3,2),F(7,4)]:
        v=profile(xs,t,R,hN,tA)
        vm=profile([-x for x in xs],t,R,hN,tA)
        ck(v==vm,'sign')
    for seedv in range(1,17):
        center=[F((seedv*(i+3)+i)%17-8,4) for i in range(n)]
        prev=False
        for t in [F(1),F(5,4),F(3,2),F(7,4)]:
            cap=all(abs(v-y)<=t/2 for v,y in zip(center,xs))
            excess=[max(F(0),2*abs(v)-R+t) for v in center]
            live=cap and max(excess)>hN and sum(excess)>tA
            ck(not prev or live,'nesting')
            prev=live
print('PASS source-depth capacity checks',counts,'total',sum(counts.values()))
~~~


Actual execution of the final embedded script returned:

~~~text
PASS source-depth capacity checks {'interval_product': 288, 'tail_volume': 288, 'sign': 144, 'nesting': 2304} total 3024
~~~

All checks use exact Fraction arithmetic. They validate the mixed center-volume and nesting formulas only; they are not a numerical certificate of the posterior condition for the general original source field.
