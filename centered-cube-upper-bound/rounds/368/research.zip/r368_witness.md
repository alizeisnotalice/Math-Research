# R368: Actual exterior-center high-past witness

This construction proves positive original G traffic in the new D branch OUTSIDE the entire old R338 expanded-center region. It is not a general upper bound or a quantitative covered fraction. It retains actual Lebesgue receiver measure and a continuum radius menu.

Set n=10000,a=1,b=2,lambda=4/3,q_-=1,f=1_[-3,3]^n,epsilon0=119/3072. Thus K=exp(100), h_*=(1+sqrt(n))/(epsilon0 q_-)=310272/119; take the original H to be this same value. Let delta=10^-6,rho=10^-7,

    E=[-3/4+delta,3/4-delta]^n,
    R0(w)=max(1,2||w||inf+2delta), Y=[-delta,delta]^n,
    U=(-2/5,0,...,0)+[-rho,rho]^n,
    V=(7/10,0,...,0)+[-rho,rho]^n.

Define the actual selector R=2 on U, R=3/2 on V, and R=R0 elsewhere. U,V are disjoint positive-volume boxes inside E; baseline R0=1 on U and R0<3/2 on V. Every selected cube lies within support [-3,3]^n, so exactly m_w=R_w^n and q_w=1. Every y in Y is captured by every receiver, since the baseline includes a delta margin and the two overrides also capture Y.

For u in U,v in V the first center separation belongs to [11/10-2rho,11/10+2rho]; others are at most2rho. Hence the only nonzero excess is in [17/10-4rho,17/10+4rho]. Actual radius ratio is Rv/Ru=3/4, and

    sum e_j <=17/10+4rho < nRv/64=1875/8.

Thus every such pair satisfies D. Both centers are outside the other cube. More strongly, for the old expanded-center alpha=(1+sqrt(n))^(1/n)=101^(1/10000), the exact rational inequality (21/20)^100>101 gives alpha<21/20. Thus ||u-v||inf>alpha Ru/2 throughout the two boxes. This proves the old R338 exterior predicate, not just failure of N/A. The pairs also fail N and A: the upper log bound log10002<19/2 gives h_N<19/(4n) and t_n<361/(64n), both much smaller than the excess lower bound.

For all w outside U, actual Rw<=3/2. As (4/3)^4>3>exp(1), (4/3)^10000>exp(100), so m_w<2^n/K. All those receivers lie in the strict global mass past of each u in U. A convenient lower bound uses only E minus (U union V). The baseline capacity is

    integral_E R0^(-n)dw
      =(1-2delta)^n+n integral_1^(3/2)(r-2delta)^(n-1)r^(-n)dr
      >49n/150.

The last inequality uses Bernoulli and log(3/2)>=1/3 as in the R367 certificate. Removing each box costs at most its volume<1, since baseline R0>=1. Therefore for y in Y,

    Z_y(2^n/K-)>49n/150-2=9794/3>310272/119=h_*=H.

At the original terminal clock atom b, J_b(y)>=Z>H. All original high-J, high-past, far-mass, common-source and exterior-center gates therefore hold on Y times U times V. The actual radius-2 receivers enter at the terminal atom; this atom is not discarded. From the universal center bound J_b<=1+n log2<1+n, the positive contribution is at least

    2^(-n)|Y||U||V| [2^n-(3/2)^n]/[2^n(3/2)^n(1+n)] >0.

The scale and mass factors in both receiver measures remain explicit. W=6^n is finite; the lower bound is tiny relative to W and is not a useful covered-fraction estimate. The witness does not certify R355 terminal-shell path qualifications or novelty across every historical alternative.

Local exact Fraction verification checks21 parameter inequalities, including whole-box margins, the exponential bound for alpha, the actual ratio, strict mass-past threshold and original H. Those finite checks support the displayed analytic construction; the general D budget is proved separately for arbitrary f. This is a high-dimensional compressed geometric certificate, not sampling a sparse global radius menu or treating an incidence matrix as cubes.
