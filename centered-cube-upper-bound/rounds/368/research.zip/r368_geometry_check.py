from fractions import Fraction as F
from math import comb,factorial
from itertools import product
from random import Random
rng=Random(368)
counts={'selector_envelope':0,'polynomial_coefficients':0,'bin_coverage':0,'new_outside_centers':0}
for n in [8,9,16,32,64,128]:
 rho=F(n+1,n)
 assert rho**n>=2
 for j in range(n):
  s=rho**j
  for vscale in [s,(s+s*rho)/2,s*rho]:
   for ratio in [F(1),F(7,6),F(4,3)]:
    large=vscale*ratio
    if large>2 or vscale>2:continue
    c=(large-s)/s; z=n*rho/F(64)
    assert F(0)<=c<=F(1,2) and z<=F(9*n,512)
    for k in range(n+1):
     assert F(comb(n,k))*c**(n-k)*z**k/factorial(k)<=F(1,2)**n * F((2*n)**k)*z**k/factorial(k)**2
     counts['polynomial_coefficients']+=1
    for trial in range(2):
     center=[F(rng.randrange(-64,65),64) for _ in range(n)]
     original=sum(max(F(0),2*abs(x)-(large-vscale)) for x in center)
     envelope=sum(max(F(0),2*abs(x)-(large-s)) for x in center)
     assert envelope<=original
     if original<=n*vscale/F(64):assert envelope<=n*rho*s/F(64)
     counts['selector_envelope']+=1
 for k in range(101):
  r=1+F(k,100)
  labels=[j for j in range(n) if rho**j<=r and (r<rho**(j+1) or (j==n-1 and r<=rho**n))]
  assert len(labels)==1
  counts['bin_coverage']+=1
for n in [128,256,512]:
 large=F(2);small=F(3,2);d=F(11,10);source=F(1,2)
 excess=max(F(0),2*d-(large-small))
 assert excess==F(17,10) and excess<n*small/F(64)
 assert F(11,10)**n>1+n/F(10) and n*n>100*n
 assert d>small/2 and source<large/2 and abs(source-d)<small/2
 assert small>=3*large/F(4)
 counts['new_outside_centers']+=1
print('PASS',counts,'total',sum(counts.values()))
