# 第338轮：高拥挤交通的中心体积预算

## 精确合同与本轮新付款

沿第337轮完整 hard 槽：n≥1，f≥0 属于 L¹，ν≤f dx，有限真实勒贝格接收集 E，可测半径 a≤R_u≤b≤2a，Q_u 为以 u 为中心、边长 R_u 的立方体，q_u=R_u^{-n}∫_{Q_u}f∈[q_-,λ]，q_-=3λ/4。令 m_u=q_u R_u^n，μ(du)=du/m_u，c_u=1_{Q_u}，E_r={R≤r}，J_y(r)=∫_{E_r}c_u(y)dμ(u)，ell=b^{-n}δ_b+nr^{-n-1}dr。零行按零计，X_q=∫Eq，W=∫f。

固定 K>λ/q_-、h>0，令 Z_y(t-)=∫_E c_v(y)1_{m_v<t}dμ(v)。上一轮剩余的高过去交通是
\[
 G_{K,>h}=\int\ell(dr)\int f(y)\frac{1_{J_y(r)\ge H}}{J_y(r)}
 \iint_{E_r^2:m_u>Km_v}c_uc_v(m_u-m_v)1_{Z_y(m_u/K-)>h}\,d\mu(u)d\mu(v)dy.
\]
对任意可测的中心关系 D⊂E×E，若逐 u 有
\[
 |\{v\in E:m_v<m_u/K,\ (u,v)\in D\}|\le L R_u^n,
\]
则加上 D 子门的原积分满足
\[
 \boxed{G_{K,>h;D}\le L|E|/h\le L X_q/(q_-h).}
\]
D 可以依赖 u、原半径和选定接收场，但这里的体积条件不能只逐来源 y 成立；用于此式的 D 必须在积分 y 之前固定。

## 证明：来源交叠与真实接收中心体积

m_v<m_u/K 蕴含 R_v^n<(λ/(Kq_-))R_u^n<R_u^n。因此全部严格小质量过去已经在每个 r≥R_u 的原前缀中，Z_y(m_u/K-)≤J_y(r)。高过去门上 1/J≤1/h。

先在该门上使用这个分母界，再正放掉高过去门和原 H 门，且用 m_u−m_v≤m_u。此时积分 y 的真实交叠满足 I_uv=∫f c_uc_v≤m_v，于是
\[
 G_D\le\frac1h\int\ell(dr)\int_{E_r}m_u\,d\mu(u)
       \int_{E_r:m_v<m_u/K,(u,v)\in D}I_{uv}\,d\mu(v)
 \le\frac1h\int\ell(dr)\int_{E_r}m_u L R_u^n\,d\mu(u).
\]
包含端点的原尾 ell([R_u,b])=R_u^{-n}，所以末式正是 L|E|/h。真实 dv 来自 m_v dμ(v)=dv；没有以边界体积代替来源质量，没有给 f 加密度帽，也没有引入独立来源。所有积分为非负，Tonelli 可用。物理终端原子按原式保留。

## 一个统一的可付膨胀区域

取任意 ε>0，设
\[
 K=e^{\sqrt n},\qquad h=\frac{1+\sqrt n}{\varepsilon q_-},\qquad
 \alpha=(1+\sqrt n)^{1/n}.
\]
用 D={||v−u||∞≤αR_u/2}，中心区域体积为 α^n R_u^n=(1+√n)R_u^n，得到 G_D≤εX_q。条件是小立方体的中心在膨胀区域内，**不要求整颗小立方体包含于大立方体**。

精确补集 G_out 是同一 G_{K,>h} 再加上 ||v−u||∞>αR_u/2。两者完整分割，边界归内侧。它同时保留严格质量远比、高全局过去、原物理前缀、原 J、原 H、共同来源及外侧中心条件。

几何相交只给 ||v−u||∞≤(R_u+R_v)/2，因此补集必有 R_v/R_u>α−1。该必要条件不支付补集。本合同本来有 R_v/R_u≥1/2，在高维中“极小半径比”分支可能为空，不能把该空子域计作新进展，也不能迁移到其他比例带而省略其费用。

更一般可以逐 u 选择固定坐标膨胀 α_i(u)≥1，若 ∏α_i(u)≤1+√n，同样付款。若要对所有坐标选择取并集，必须核算并集真实体积；不能免费重复该信用，也不能按 y 事后选择中心区域。

## 回到完整原 B_H，而非仅局部祖先

第337轮在 ν≤f 正支配到完整 f 槽后证明 B_H(f,f)=B_near+2B_fav+G_K，其中真实 I_uv 保留并精确相消。近质量和两次有利向联合预算为
\[
 B_{near}+2B_{fav}\le\varepsilon X_q+
 \frac{\lambda}{q_-\varepsilon}(1+2\log K+2/K)W.
\]
全局低过去分支费用≤λ[h+(1+logK)/q_-]W。将本轮新高过去中心区域付款加入，得到
\[
 \boxed{B_H(f,\nu)\le G_{out}+2\varepsilon X_q+C_{\varepsilon,n}W,}
\]
\[
 C_{\varepsilon,n}=\frac{\lambda}{q_-}
 \left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon}+1+\sqrt n\right].
\]
这是完整 hard 槽的严格根阶已付部分；G_out 仍未得到一般根阶预算。新结果是一个真实几何子域的付款，不是把 G_out 本身宣布可付。其他 soft、尺度和历史时间槽不由该合同自动覆盖。任意额外来源或端点掩码需先合法正支配到完整槽，不能直接套精确质量相消。
