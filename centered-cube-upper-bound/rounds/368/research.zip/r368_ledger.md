# 第368轮优先完整硬槽账：恢复R338，直接吸收真正外侧D分支

固定同一full-f、E、实际R与q/m。K=exp(√n)，h_*=(1+√n)/(ε0q_-)，α=(1+√n)^(1/n)。原G_out包含严格远质量、Z_y(m_u/K-)>h_*、原J≥H、共同来源及clock，并要求2||u−v||∞>αR_u。D为n≥8时Rv≥3Ru/4且sum e≤nRv/64；n<8 D为空。

原高过去门给所有非零行J>h_*：m_w<m_u/K且K>λ/q_-保证Rw<Ru≤r，所以全局past已经在物理前缀内。实际半径分箱的行容量给g_D≤d_nV/(q_-J)，因而直接付款
\[
G_{out,D}\le\frac{d_n}{q_-h_*}X_q=\frac{\varepsilon_0d_n}{1+\sqrt n}X_q.
\]
无需新增来源费或独立ε1。优先完整预算为
\[
B_H(f,\nu)\le G_{out,\neg D}+
\varepsilon_0\left[2+\frac{d_n}{1+\sqrt n}\right]X_q+C_{338}W,
\]
\[
C_{338}=\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right],
\qquad d_n=ne^{-n/4}\ (n\ge8),\quad d_n=0\ (n<8).
\]
低维D空且增量为零。旧past提升来源费用已包含于C338，不在外层再加λh_*。旧N/A/C都属R338已付中心族；不新增这些费用，不沿用较弱337→367账上的付款加总。没有使用同一负平方两次。

完整原入口：
\[
T\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{out,\neg D}
+2\varepsilon_0\left[2+\frac{d_n}{1+\sqrt n}\right]X_q+2C_{338}W,
\quad A_n=1+n\log(b/a).
\]
全式再乘Λ=128/119。因此硬槽接收系数为2Λε0[2+d_n/(1+√n)]，新增来源费为零。n≥8时d_n<2且1+√n>3，故括号<3；可取ε0=ε/3，使该硬槽系数≤2Λε，而C338仍O_ε(√n)。这不代表其他槽已支付或总吸收已证明；H、d_eff、来源外积分等原参数未隐去。

一般h合同的low-clock备用收据G_D≤ε1X_q+4d_nW/(3ε1)仍成立，但不是本优先账的追加项。本轮利用已有h_*即可取消这笔不必要的来源费用；没有改变原H。

n≥8时未付补集的精确谓词：原G_out所有门 AND [Rv<3Ru/4 OR sum e>nRv/64]。边界归已付D；中心外侧门严格。n<8保留全部G_out，非遗忘补集。旧clock末端原子完整保留。

独立未付接口：一般soft C_H−S_H和crossing I_H、原始入口与不同硬合同连接、硬合同外的重尾与所有质量分支、宽距离/低pe/极端尺度比及阈值补集、原初始与删除跳跃及未来被删来源、H选择、来源/物理尺度/分层聚合、外积分、截断与极限。旧历史CZ吸收系数只在同一认证X账中可用，不自动授予本轮额外信用。

source_capacity后验条件尚无全输入保证，未列为付款。R355路径余流及后续路径总账仍是独立备选；不得把其祖先回捕、内部停止或终端费用与上述原G分解相加。用户355轮建议强调的完整源边缘及跨路径预算仍未获得一般结论。

以下保留第367轮及此前完整备选费用，仅供追溯。第366/367轮N/A界为有效工具，但相对于恢复的R338较强总账不构成新增覆盖；它们不再是本轮优先路线。以下任何公式都不是上面右端追加项。

# 第367轮优先总账：联合外突与近包含一次结算

同第337轮原G合同，K=exp(√n)，h=√n/q_-。定义G_tail=G_{K,>h,¬N∩¬A}，N与A见main及geometry。准确正分解为G_high=G_union+G_tail。采用一次联合收据替换上一轮N费用：
\[
B_H(f,\nu)\le G_{tail}+(\varepsilon_0+\varepsilon_1)X_q+
\left[F_{337}+\frac{8\sqrt{n+2}}{3\varepsilon_1}\right]W,\qquad \nu\le f,
\]
\[
F_{337}=\frac{\lambda}{q_-\varepsilon_0}(1+2\log K+2/K)
+\lambda h+\frac\lambda{q_-}(1+\log K).
\]
所有q/m、真实接收测度、full-f、原J≥H、全局严格过去、原物理clock及其末端原子不变。未添加任何负平方信用。若只用单独A减N估计，其费用4√(n+2)/(3ε_1)W是另一个顺序拆分选项，不能和联合收据重复相加。

原入口完整回代：
\[
T\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{tail}
+2(\varepsilon_0+\varepsilon_1)X_q
+2\left[F_{337}+\frac{8\sqrt{n+2}}{3\varepsilon_1}\right]W,
\qquad A_n=1+n\log(b/a).
\]
全式再乘Λ=128/119；此处A_n是原时钟常数，与本轮几何门A不同。硬槽接收系数为2Λ(ε0+ε1)，若二者取ε/2则为2Λε。不能由此宣布全部独立槽的ε总和已可吸收；仍须在同一X总账中核验。原H和d_eff费用不自动根阶。

未付量：G_tail保留原高过去、远质量、共同来源和高J，同时max e>h_N且sum e>t_n。没有统一份额或下界要求。独立的一般soft C_H−S_H、crossing I_H、入口兼容、硬合同外重尾、宽距离/低pe/极端尺度比、初始/删除/未来被删时间原子、H选择、来源/物理尺度/分层聚合、外积分、截断与极限，全部仍须独立证明。连续或末端clock工具不替代历史原子。

本轮native-clock势仅为辅助恒等式；正跨接收势未付，没有添加收据。用户355轮后建议保留的路径Fshell共同来源账仍可作为备选；本轮没有用它代替G_tail。下面原样保存第366轮及更早完整备选账供追溯，所有旧路线是替代账，不是本轮右端的追加项。

# 第366轮优先总账：支付高质量过去中的近包含部分

优先衔接第337轮已经认证的原槽估计，而非重新留下已付near mass族。令K=e^{√n}，h=√n/q_-，Z_y(s-)=∫E c_v(y)1_{m_v<s}μ(dv)。G_{K,>h}为同J同clock下mu>Kmv、Z_y(mu/K-)>h的原正质量差m_u−m_v交通。

N为本轮对称nearcontainment mask。Ghigh,N≤B_N，因为每对只计一次且m_large−m_small≤f(Q_large△Q_small)。所以
\[
B_H(f,\nu)\le G_{K,>h,\neg N}+(\varepsilon_0+\varepsilon_1)X_q+(F_{337}+C_N)W,
\]
\[
F_{337}=\frac{\lambda}{q_-\varepsilon_0}(1+2\log K+2/K)
+\lambda h+\frac\lambda{q_-}(1+\log K),\quad
C_N=\frac{4(\sqrt{n+2}+1)}{3\varepsilon_1}.
\]

第337轮完整合同包括ν≤f正支配；本轮新几何证明只用于full-f后的G。此前已付P及G低过去与此次G高过去N不交。原入口回代为
\[
T\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{K,>h,\neg N}
+2(\varepsilon_0+\varepsilon_1)X_q+2(F_{337}+C_N)W.
\]
再整体乘Λ。新增接收系数（相对第337轮）为2Λε1，新增来源系数2ΛC_N。ε0、ε1仍须与其余同X总账预分配；不默认全部历史账可叠加。若ε0=ε1=ε/2，则此硬槽接收系数2Λε，来源系数按上述显式式计算，均O_ε(√n)。

剩余高质量过去G_{K,>h,¬N}明确未付，及所有独立soft、尺度、时间/入口接口仍未闭合。新N不保证占任何固定比例。face分支属于第336轮已付near质量族，只有更小常数；不再作为优先账的新增分支或费用。

下面保存本轮合法的另一原式不交分解作为辅助工具；它与上述优先账互为替代，不能相加。

本轮采用原B_H正有向积分的全新不交分解。N为按实际边长定向的近包含对（边长容差a log(n+2)/(2n)）；L为face附件的质量可比、少失配、远来源有向门。

\[
B_H=B_N+B_{\neg N,L}+B_{\rm rest},\quad B_{\rm rest}=B_{\neg N,\neg L}\ge0.
\]

这里mask N在交换u,v后不变，所以对称差证明与有向face证明可合法接合。face界对额外正限制仍成立；无重叠计费。定义

\[
C_{366}=\frac{4(\sqrt{n+2}+1)}{3\varepsilon_1}
       +\frac4{\varepsilon_2(n+2)}.
\]

\[
B_H\le B_{\rm rest}+(\varepsilon_1+\varepsilon_2)X_q+C_{366}W.
\]

两个ε均可任意预分配，C366与n的关系显式；证明没有更改原H、q带、f、E或R。原入口回代为

\[
T_{entrance}\le8\lambda HW+2d_{eff}A_n W_\nu/H
+2B_{\rm rest}+2(\varepsilon_1+\varepsilon_2)X_q+2C_{366}W.
\]

再整体乘Λ=128/119。因此本路线新增接收系数恰2Λ(ε1+ε2)，新增来源系数2ΛC366。选ε1=ε2=ε/2时合计接收系数2Λε，来源价为

\[
2\Lambda\left[\frac{8(\sqrt{n+2}+1)}{3\varepsilon}
+\frac8{\varepsilon(n+2)}\right]W.
\]

这不是默认全局还有2Λε空间；必须与相同X的其余入口、软层、时间及原历史系数统一审定。未证明剩余Brest任何一般预算，故不宣布总吸收完成。

不把本式与第364轮3λHW、旧路径head/recapture等费用相加，也不把已支出的捕获平方再扣一次。本轮是替代原B_H槽的一条合法部分付款。旧路径与近远来源分解仍是备选，各自费用完整保留下方，不能混合无证明的接口。

剩余精确条件：在原有向共同来源交通内，小cube至少一坐标越出大cube容差，且mass不比、k>p或来源距离<4pUu至少一项成立。原k≥1仍保留。没有把多失配支凭1/k分摊自动付清。一般soft C_H−S_H、crossing I_H、入口兼容、宽距离/低pe/极端尺度比、初始/删除/未来被删时间原子、全尺度聚合、H选择与极限等独立槽全部保持未付状态。

以下是截至第365轮的完整历史备选账，原文保存便于追溯，不作为本轮右端追加项。

# 第365轮：无新增付款，完整继承第364轮总账

本轮共同来源矩、半径差额及充分证书均未给新的预算。以下第364轮替代账及旧路径账全部保留，不相加，不再次使用平方信用。全部未付槽保持未付。

# 第364轮总账增量：替代原槽，不叠加旧路径付款

本轮从尚未拆用平方的原B_H出发，新增明确分支费3λHW，无新增接收吸收项。由原入口
T≤8λHW+2d_eff A_n Wν/H+2B_H
得到替代界
\[
T\le14\lambda HW+2d_{eff}A_nW_\nu/H+2B_{near}+2F_{core}.
\]
全部再乘原外因子Λ=128/119。没有把旧路径的来源费、recapture信用或平方信用与该式叠加。原H必须服从完整入口预算；3λHW不自动为根阶。

若将来两项未付量分别≤ε_i X_q+C_i√n log^A(n+2)W，新增接收系数才是2Λ(ε_1+ε_2)。目前未证明这些假设，不占用总吸收空间。停止几何核、有限共同选择诊断不增加任何付款。

下面完整保留原路径账，作为另一条尚未闭合路线及历史费用记录；不是本轮替代式右端的追加项。

# 第363轮总账状态：继承既有付款，不新增平方信用

第363轮没有新增来源付款或接收吸收项。下列路径总账完整继承第362轮；本轮乘法局部化是从原B_H重新出发的替代路线，不能再次扣除路径归约已使用的平方。

本账对应原始 \(B_H\)。继承第360轮完整迁移、全路径高面停止及费用。令 L=ceil(log(n+2))。沿用第361轮先支付D次数0至L的路径；随后仅在次数大于L的实际正常终端中，按初始旧来源的target剩余秩ell0是否≤w分拆，支付近顶端部分，最后在深秩部分重算方向来源列。高维剩余 F_{>L,deep} 仍未付。
设 \(x=\sqrt n,s=1+x,W=\int f,W_{ex}=\int g_{ex},X_q=\int_Eq\le X=\lambda|E|\)，\(\varepsilon=119/3072,\Lambda=128/119,\beta=\varepsilon/16,q_-=3\lambda/4\)。
\[
B_H\le F_{>L,deep}+
[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+8s+C_{dir}^{eff}+C_{path}+C_{terminal}]W
+(D_{top}+C_{hit}+s+C_{init})W_{ex}.
\]
这里
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3x+2e^{-x}}\varepsilon+1+x\right],\quad
D_{top}=s+\log(4/3),\quad C_{hit}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
保留 \(A_n=1+n\log(b/a)\)、\(N=\max(1,\lceil\log[(\lambda/q_-)(b/a)^n]/x\rceil)\)、\(\alpha^n=\min(1,s/(NA_n))\)、\(L_n=\log(n+2)\)，
\[
C_{dir}=N[(1-\alpha)+(n(1-\alpha)+\alpha)\log(b/a)]L_n,
\]
\[
C_{path}=2NC_m,\quad C_m=\Pr\{\operatorname{Bin}(n,1-\alpha)\ge m\}
+n\log(b/a)\Pr\{\operatorname{Bin}(n-1,1-\alpha)\ge m-1\},
\quad m=1+\lceil8L_n\rceil.
\]
这些binomial项来自真实接收体积，不是实际来源独立性。非空原highpast分支上，
\[
\gamma_{eff}=2(\lambda/q_-)e^{-x}<\varepsilon/16,\quad
c_{eff}=(\lambda/q_-)e^{-x}\max(1,A_n/s)<\varepsilon/16,\quad
\alpha_{rec}=N/(e^x-1)<\varepsilon/16,
\]
且 \(C_{dir}\le3\sqrt n L_n^2\)，\(C_{path}\le2\sqrt n\)。原必要条件使入口为空时相应新流与这些有效分支系数置零，不给后续新来源重新授予原资格。

终端费用采用分段定义：n≥2^32 时，C_terminal=(L+1)b_*/(1−c_col)≤(8/5)(L+1)b_*，c_col=1/4+r_p≤3/8，C_dir^eff=C_dir；n<2^32 时，C_terminal=N b_*≤786432√n，C_dir^eff=0，F_{>L,deep}=0。原困难入口为空则新增实际分支费用为零。有限维付款仅限本硬余项。

高维十一项实际正分解及费用：

|新流部分|费用|
|---|---|
|级联删除|β X_q+4sW|
|初始旧clock近端|c_eff X_q|
|初始旧来源inner|s W_ex|
|首次rich或实际inner来源联合停止|4sW|
|首次当前来源高面|N C_m W|
|首次祖先回捕|α_rec X_q|
|首次成功目标高面|N C_m W|
|D续跳次数0至L的正常终端|C_terminal W|
|D次数大于L且初始旧来源剩余秩≤w的正常终端|C_init W_ex|
|D次数大于L且初始剩余秩>w后，重新计算的方向来源删除|C_dir W|
|剩余正常终端|F_{>L,deep}，未付|

第362轮不增加接收吸收系数。不逐代再收费正常终止；首次D之后不能重新授予原入口或重复已有来源预算。C+B 的L2预解是估计工具，不能冒充全部相关路径的实际付款。

原始入口与外乘不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
入口2和外乘 \(\Lambda\) 作用于全体新旧费用。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
仅当历史CZ项 \(1/256\) 属于同一认证 \(X\) 账时，合计才有
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
其余 \(1415/2304\) 以上的吸收空间不是任何未付积分的预算。若未来以 \(F_{>L,deep}\le\delta X_q+b_*W/(2\gamma\delta)\) 回代，新增接收系数将是 \(2\Lambda\delta\)，新增来源费是 \(\Lambda b_*W/(\gamma\delta)\)；第362轮仍没有证明条件 \(\gamma>0\) 对实际来源平方成立，因此没有插入该项。

独立未付槽：一般软层 \(C_H-S_H\)、越阈 \(I_H\)、硬层合同之外的质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；原初始时间原子、删除跳跃、未来被删来源；H选择、来源及物理尺度分层、外积分、截断和极限。旧物理时钟末端原子完整保留，新秩核正常终止不替代任何历史时间原子。

一般一致弱型上界与整个 \(B_H\) 仍未闭合。

继承第361轮的高维总head费为(L+1)b_*W/(1−c_col)，其中k=0是第360轮已有付款，不叠加旧noD费；第361轮净新增k=1至L的预算为L b_*W/(1−c_col)。原入口及外乘后总head费为2Λ C_terminal W。低维处理不变。共同列容量给每个k同一预算，但对所有k求和仍可能产生路径长度N费用，不能把有限head付款说成一般闭合。

第362轮新增 C_init=w²/(6Δ)（n≥2^32），其中w=Δ−D0，Δ=2(1+√n)，D0=1+√n+log(4/3)。n<2^32已由原整支费用支付，故C_init=0；原入口为空同样置零。此费专属原来源g_ex，不是后续终端来源f的密度帽，且W_ex≤W。回代新增来源费2Λ C_init W_ex。初始rank mark在整条真实历史保留，不能用后续source rank替代；初始深秩补集未付。

原入口source capacity现在可保留更强的分段函数C_eta(D)：D≤Δ为0，D>Δ为D−Δ−Δlog(D/Δ)。这是同一原注入的上界，并不另加费用或替换本总账中的未付流；D大时仍可达线性阶。近顶端费先于最终方向筛选，避免删流后借用旧比例。第362轮辅助first-hit差估计仅重述已有recapture控制，不收第二次recapture费。

其中b_*=(D0+Δ)/2；r_p=min(1,Λ_p/w)，p=min(n,m−1)，Λ_p=1−α^p+[n−(n−p)α^p]log(b/a)。这些为第360轮已审真实接收容量常数，未另引来源密度帽。

第363轮新工具：对于同一完整hard matched原B_H，B_H≤B_loc≤B_H/(1−δ)，B_loc=B_near+F_far。固定δ=1/4时比较常数4/3。该式本身没有新增X费用；亦没有证明B_loc的根阶上界。条件性Jensen切片费若将来采用，必须从原B_H作不交分拆并保留补集，不在上表另加一份平方信用。
