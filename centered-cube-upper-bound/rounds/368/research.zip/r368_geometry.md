# R368 — Actual-radius binning pays a macroscopic joint-protrusion branch

**Outcome.** A substantive new branch of the exact high-past, far-mass remainder is paid. After recovering the stronger R338 ledger, the preferred application is directly to its genuinely OUTSIDE-center remainder G_out with h*=(1+sqrt(n))/(epsilon_0 q_-). The new D proof is valid for every h_past>0. Section 5B gives the final preferred substitution with NO new source fee; Section 5A records the valid low-clock alternative; the older R367 union line is retained only as a superseded alternative, not an additional fee. For n>=8 retain actual pairs satisfying

    R_v >= (3/4)R_u,
    sum_j (2|u_j-v_j|-(R_u-R_v))_+ <= n R_v/64,          (D)

where m_u>K m_v and K=exp(sqrt(n)). Actual smaller radii are partitioned into at most n multiplicative bins. The joint center capacity of each bin is exponentially small in n; the full selected capacity is at most D_n/q_-, where

    D_n=n exp(-n/4)<=8 exp(-2)<2.

Consequently, for every epsilon>0, this part of the current residual satisfies

    G_(rem,D)<=epsilon X_q+[4 D_n/(3 epsilon)]W
              <=epsilon X_q+8W/(3 epsilon).             (1)

This criterion allows total protrusion of order n R_v, not the old order a log(n)^2/n. It uses actual-radius localization jointly with the coordinate-volume polynomial. It includes geometrically open families outside both old N/A and outside center recapture u in Q_v. No uniform covered proportion or complete global theorem is claimed. Original strict past, full f, original J and clock remain unchanged.

## 1. Contract and precise claim screening

All definitions are the frozen R367 ones. E is a measurable Lebesgue receiver set of finite measure; f>=0 is in L1; Q_u is the actual centered cube of SIDE LENGTH R_u; a<=R_u<=b<=2a. Put

    m_u=f(Q_u)=q_u R_u^n, q_-=3lambda/4<=q_u<=lambda,
    mu(du)=du/m_u, c_u(y)=1_(Q_u)(y), E_r={u in E:R_u<=r},
    J_r(y)=integral_(E_r)c_u(y)mu(du),
    V_r(y)=integral_(E_r)c_u(y)du,
    X_q=integral_E q_u du, W=integral f.

The clock is exactly ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr, with ell([R,b])=R^(-n). Define

    K=exp(sqrt(n)), h_past>0 arbitrary,
    Z_y(s-)=integral_E c_v(y)1_(m_v<s)mu(dv).

Let dGamma denote the original positive measure including its loss:

    dGamma=ell(dr) f(y)dy [1_(J_r(y)>=H)/J_r(y)]
      1_(u,v in E_r)c_u(y)c_v(y)(m_u-m_v)
      1_(m_u>K m_v)1_(Z_y(m_u/K-)>h_past)mu(du)mu(dv).   (2)

Zero-J rows are zero. Since K>lambda/q_-, the mass condition implies R_u>R_v. Set

    e_j(u,v)=(2|u_j-v_j|-(R_u-R_v))_+,
    h_N=a log(n+2)/(2n), t_A=a log(n+2)^2/(16n),
    N={max_j e_j<=h_N}, A={sum_j e_j<=t_A}.

The originally assigned R367 remainder is G_rem=integral 1_(not N and not A)dGamma. The preferred R338 outside-center remainder is specified in Section 5A, with its stronger h*; the proof below applies unchanged. The branch D is (D) above for n>=8, and is defined to be empty for n<8. The newly paid part is G_(rem,D)=integral 1_(not N and not A and D)dGamma. Thus near-mass pairs and already-paid N/A pairs are not charged again in (1).

The screened claim is the following deterministic, selector-uniform capacity bound: for each FIXED actual large endpoint u and source y,

    integral_E c_v(y)1_(R_v<R_u)1_D(u,v)mu(dv)
       <=D_n/q_-.                                     (3)

The actual radius field remains fixed. We will prove (3) by a finite partition of its values; no independent dR integration is introduced. Extra actual mass, time or strict-past masks can only decrease its left side. The A02 positive-relaxation checklist was used to verify the set inclusion and bound direction; no external theorem or optimization certificate is assumed.

## 2. Legal actual-radius partition

Fix n>=8 and rho=1+1/n. Partition [a,a rho^n] into n intervals with lower endpoints

    s_j=a rho^j,  j=0,...,n-1.

Use [s_j,s_(j+1)) for j<n-1, and [s_(n-1),s_n] for the last interval; intersect with [a,b]. Since rho^n>=1+n/n=2>=b/a, these cover every actual R_v exactly once. Empty intervals cause no problem, and endpoints—including b=a—are assigned once. For a receiver in bin j,

    s_j<=R_v<=rho s_j.

This is a partition of the actual receiver domain, NOT integration over independently selected radii. We retain the safe upper endpoint <=rho s_j in all estimates.

Fix u and one bin with nonempty selected pairs. Put s=s_j. The first condition of D gives

    R_u<=4R_v/3<=4rho s/3,
    0<=c:=(R_u-s)/s<=4rho/3-1<=1/2.                  (4)

The lower inequality uses R_v<R_u and s<=R_v. For the joint protrusion predicate,

    sum_j(2|v_j-u_j|-(R_u-s))_+
       <=sum_j e_j(u,v)
       <=n R_v/64<=n rho s/64.                         (5)

Thus every actual selected center in the bin lies in

    C_j=u+[-(R_u-s)/2,(R_u-s)/2]^n
             +(n rho s/128) B_1^n.                    (6)

This is a positive outer envelope in the real center variable v. The source-capture indicator c_v(y) is retained in (3), then may be dropped when bounding the center volume. No source f mass is replaced by a volume, and the q_v lower bound is used only as 1/m_v<=1/(q_-s^n).

## 3. Exact joint volume and all-bin cost

The cube-plus-crosspolytope volume formula proved by a disjoint face partition is

    |[-L/2,L/2]^n+(t/2)B_1^n|
       =sum_(k=0)^n binom(n,k)L^(n-k)t^k/k!.

For (6), normalized volume is P_n(c,z), where

    P_n(c,z)=sum_(k=0)^n binom(n,k)c^(n-k)z^k/k!,
    z=n rho/64<=(9/512)n.                              (7)

Here rho<=9/8 for n>=8. By monotonicity in c and binom(n,k)<=n^k/k!,

    P_n(c,z)<=2^(-n)sum_(k=0)^n (2nz)^k/(k!)^2
             <=2^(-n) exp(2sqrt(2nz))
             <=2^(-n) exp(3n/8)
             <=exp(-n/4).                              (8)

The infinite-series bound follows by retaining the diagonal terms of [sum_(k>=0)(sqrt(2nz))^k/k!]^2. The last step uses log 2>=5/8; for example log 2>=2/3 follows by integrating the nonnegative derivative of log x-2(x-1)/(x+1) for x>=1. Thus all exponential estimates are analytic, not numerical evidence.

Within each bin, (6)–(8) and the actual mass lower bound give

    integral_(selected actual v in bin j)c_v(y)mu(dv)
       <=|C_j|/(q_-s_j^n)<=exp(-n/4)/q_-.

Summing the disjoint actual bins proves (3) with D_n=n exp(-n/4). All scale costs have been paid: the only multiplicity is n, and it is multiplied by the exponentially small per-bin bound. Since x exp(-x/4) decreases for x>=4,

    D_n<=8exp(-2)<2 for n>=8.                           (9)

In particular we do not use the naive n log 2 capacity as if it were root-order, and we never identify a radius-selector measure with dv dR.

The gain that R367's uniform bound lost is the factor c^(n-k) with c=(R_u-s)/s<=1/2. Replacing every s by a can make this ratio as large as 1 and destroys (8). This is why the new macroscopic allowance nR_v/64 can be paid without merely enlarging the old N/A tolerances.

## 4. Payment on the exact original positive remainder

Let g_D(r,y) be the inner pair integral for G_(rem,D), divided by J_r(y) but excluding f(y) and its high-J gate. By m_u-m_v<=m_u, (3), and m_u mu(du)=du,

    g_D(r,y)<=D_n V_r(y)/(q_- J_r(y)).                 (10)

Also g_D<=V_r(y), because after dropping the positive restrictions the smaller-endpoint capture integral is J_r(y). Hence

    0<=g_D<=V min(1,D_n/(q_-J)).                       (11)

Use the unchanged original-clock identities

    integral ell integral f V=X_q,
    integral ell integral f 1_(J<T)V<=lambda T W.        (12)

For the second, inclusive tail R_u^(-n) gives q_u<=lambda; the radius-pushforward increments retained by J_(R_u)<T have total mu mass at most T. A whole radius atom reaching or crossing T is excluded. Thus the old terminal clock atom and all endpoint conventions are retained.

One split at T=D_n/(q_-epsilon), without changing H, proves

    G_(rem,D)<=epsilon X_q+lambda D_n W/(q_-epsilon),

which is (1). For n<8 the branch is empty and its contribution is zero. The strict global-past gate in (2) is never changed to a non-strict or truncated gate; it is only omitted inside a positive upper bound. No negative square or overlap credit is used in this proof.

## 5. Former R367 union ledger — superseded alternative only

Alternatively, apply one low-clock split directly to G_high=integral dGamma with the union U=N union A union D. The inherited N and A small-endpoint capacities are each at most sqrt(n+2)/q_-; (3) supplies the extra D_n/q_-. The true union counts each pair once. Bounding its capacity by the sum is legitimate even when envelopes overlap.

Consequently, for n>=8,

    G_high<=G_rest+epsilon X_q
                +[4/(3epsilon)](2sqrt(n+2)+D_n)W,       (13)
    G_rest=integral 1_(not N and not A and not D)dGamma.

For n<8 set D_n=0 in this ledger convention because D is empty. Formula (13) REPLACES the R367 N union A receipt. Do not add both its old fee and (13), and do not add the sequential standalone fee (1) to (13). The separate center-recapture candidate is contained in the recovered R338 already-paid center region and receives NO new charge. The stronger Section 5A ledger takes priority over this former R367 alternative.

For n>=8 the exact unpaid complement consists of original pairs satisfying max e>h_N, sum e>t_A, and at least one of

    R_v<3R_u/4,
    sum e>nR_v/64.

All original high-J, common-source, strict mass, strict-past and physical-clock predicates remain. The complement is unpaid; no fraction or global bound for it is inferred.

## 5A. Preferred R338 outside-center ledger: genuine new application

The recovered R338 theorem uses, for epsilon_0>0,

    h*=(1+sqrt(n))/(epsilon_0 q_-),
    alpha=(1+sqrt(n))^(1/n),
    D0={2||u-v||_infinity<=alpha R_u}.

Its whole D0 contribution has already been paid. The exact remaining G_out is integral 1_(not D0)dGamma, with h_past=h* in (2). It satisfies the inherited complete hard-slot estimate

    B_H(f,nu)<=G_out+2epsilon_0 X_q+C338 W,  nu<=f,
    C338=(lambda/q_-)[(2+3sqrt(n)+2exp(-sqrt(n)))/epsilon_0
                     +1+sqrt(n)].                     (14)

Both old N and A are contained in D0: their respective uniform coordinate excess bounds are h_N<a and t_A<a, while R_v>=a, so 2|u_j-v_j|<=R_u-R_v+e_j<R_u for every coordinate. Thus old N/A and contracted-center recapture are already paid in this preferred ledger and MUST NOT receive a new fee.

Define the genuinely new branch and its complement by

    G_(out,D)=integral 1_(not D0 and D)dGamma,
    G_(out,not D)=integral 1_(not D0 and not D)dGamma,

both with the original R338 value h_past=h*. Equation (3) was proved for every actual u,y, and the proof (10)–(12) never used a numerical value of h_past. Hence

    G_(out,D)<=epsilon_1 X_q+4D_n W/(3epsilon_1),
    B_H(f,nu)<=G_(out,not D)+(2epsilon_0+epsilon_1)X_q
                      +[C338+4D_n/(3epsilon_1)]W.       (15)

Use D_n=0 and D empty for n<8. For n>=8 the extra source fee is <8/(3epsilon_1)W. This is the preferred new receipt. It appends only D outside the already-paid D0 to the recovered R338 ledger. Do not add (13), an old N/A fee, a center-recapture fee, or a second old-past fee to (15).

The exact unpaid G_(out,not D) retains the higher strict-past gate h*, mass ratio, H, J, common source and original clock, and additionally satisfies

    2||u-v||_infinity>alpha R_u,
    R_v<3R_u/4 OR sum e_j>nR_v/64.

For n<8 it is all G_out. This is a full positive decomposition, not a reduction of the old past threshold. No root estimate for this final complement is asserted.

## 5B. Final preferred receipt: the existing strict-past gate pays D with no new source fee

The actual high-past gate supplies a stronger payment than a new low-clock split. Fix any h_past>0. If a term of the pair integrand (2) is nonzero, u belongs to E_r and Z_y(m_u/K-)>h_past. For EVERY actual w counted by this global strict past,

    R_w^n=m_w/q_w<m_u/(Kq_-)
             <=[lambda/(Kq_-)]R_u^n<R_u^n,

because K>lambda/q_-. Hence w belongs to E_r. This proves, using the original global strict gate without deleting any past receivers,

    Z_y(m_u/K-)<=J_r(y),
    any active pair row has J_r(y)>h_past.              (16)

In particular, when J_r(y)<=h_past, the entire g_D row vanishes. On other rows the already-proved capacity estimate (10) applies. Consequently, for any further positive geometric mask such as not D0,

    g_(out,D)(r,y)<=D_n V_r(y)/(q_-h_past),
    G_(out,D)<=D_n X_q/(q_-h_past).                    (17)

The last step uses the original complete clock identity integral ell integral f V=X_q. This argument imposes no new H value, uses no new negative square, and does not increase or replace the original past threshold. It exploits the threshold already present in the recovered R338 contract. Empty rows and zero-J rows contribute zero.

At that contract's h*=(1+sqrt(n))/(epsilon_0 q_-), (17) becomes

    G_(out,D)<=epsilon_0 D_n X_q/(1+sqrt(n)).           (18)

Thus the FINAL PREFERRED replacement of (15) is

    B_H(f,nu)<=G_(out,not D)
           +epsilon_0[2+D_n/(1+sqrt(n))]X_q+C338 W.     (19)

There is NO additional source fee and NO epsilon_1 parameter in (19). For n<8 use D empty and D_n=0. The exact remaining integral is the one in Section 5A, with unchanged h*, H, J, mass gap and all clock atoms. The low-clock formula (15) remains a valid alternative for an arbitrary past threshold, but its source fee is not added to (19). All earlier union receipts are likewise alternative, not additive, accounting.

This improvement is structural: the original strict mass past lies fully within the current physical-radius prefix, so the existing high-past denominator is already large enough to convert the new actual-radius capacity directly into an X_q receipt.

## 6. Actual new geometric coverage and relation to earlier paths

For n>=128, in the allowed band b=2a take

    R_u=2a, R_v=3a/2, u=0, v=(11a/10)e_1, y=(a/2)e_1.

The common source is strictly inside both cubes. There is one nonzero excess, e_1=17a/10<nR_v/64. Thus D holds with a strict excess-budget margin. The radius condition holds at equality; perturb R_v slightly upward for an open neighborhood while preserving all strict conclusions below. The large center u is outside Q_v, hence also outside every contracted sigma Q_v with sigma<=1. More importantly, these pairs lie outside the recovered D0: (11/10)^n>=1+n/10>1+sqrt(n) for n>=128, so alpha<11/10 and 2||u-v||_infinity=(11/5)a>alpha R_u. All these inequalities persist under small perturbations.

For all n>=1, log(n+2)<2sqrt(n), so t_A<a/4; also h_N<a. Thus this example is outside both old N and A by a wide margin. Uniform full f on a sufficiently large containing box has matching q=1 and m_u/m_v=(4/3)^n>exp(sqrt(n)) for n>=128. This checks genuine far-mass geometric coverage outside D0, beyond N/A and center recapture. It does NOT purport to realize arbitrary specified H and high-past gates; no full hard-domain realization or covered fraction is claimed from this illustration.

This proof is a static actual-pair capacity receipt in the original G ledger. It makes no path, ancestry, freshness, stopping-core, or source-shell selection and uses no previously charged path transition. The radius condition R_v>=3R_u/4 is not a source-core membership condition. In particular the exhibited pairs have u outside Q_v, so the argument is not a hidden inner-center recapture bound. Possible set overlap with some alternative historical path decomposition does not authorize adding those alternative path fees here. The new fee is used only through the original positive G partition above.

## 7. Actual local exact-arithmetic checks

The following preserved Fraction code was actually run and returned

    PASS {'selector_envelope': 2558, 'polynomial_coefficients': 109774,
          'bin_coverage': 606, 'new_outside_centers': 3} total 112941

These checks validate the finite bin endpoint assignments, actual-radius envelope inequality, rational polynomial coefficient bounds, and explicit common-source/outside-center geometric examples. They are not numerical realizations of arbitrary H/high-past gates and do not substitute for the analytic exponential/clock proof. The seeded finite checks were not an optimization or counterexample search.

```python
from fractions import Fraction as F
from math import comb,factorial
from itertools import product
from random import Random
rng=Random(368)
counts={'selector_envelope':0,'polynomial_coefficients':0,'bin_coverage':0,'new_outside_centers':0}
for n in [8,9,16,32,64,128]:
 rho=F(n+1,n)
 assert rho**n>=2
 for j in range(n):
  s=rho**j
  for vscale in [s,(s+s*rho)/2,s*rho]:
   for ratio in [F(1),F(7,6),F(4,3)]:
    large=vscale*ratio
    if large>2 or vscale>2:continue
    c=(large-s)/s; z=n*rho/F(64)
    assert F(0)<=c<=F(1,2) and z<=F(9*n,512)
    for k in range(n+1):
     assert F(comb(n,k))*c**(n-k)*z**k/factorial(k)<=F(1,2)**n * F((2*n)**k)*z**k/factorial(k)**2
     counts['polynomial_coefficients']+=1
    for trial in range(2):
     center=[F(rng.randrange(-64,65),64) for _ in range(n)]
     original=sum(max(F(0),2*abs(x)-(large-vscale)) for x in center)
     envelope=sum(max(F(0),2*abs(x)-(large-s)) for x in center)
     assert envelope<=original
     if original<=n*vscale/F(64):assert envelope<=n*rho*s/F(64)
     counts['selector_envelope']+=1
 for k in range(101):
  r=1+F(k,100)
  labels=[j for j in range(n) if rho**j<=r and (r<rho**(j+1) or (j==n-1 and r<=rho**n))]
  assert len(labels)==1
  counts['bin_coverage']+=1
for n in [128,256,512]:
 large=F(2);small=F(3,2);d=F(11,10);source=F(1,2)
 excess=max(F(0),2*d-(large-small))
 assert excess==F(17,10) and excess<n*small/F(64)
 assert F(11,10)**n>1+n/F(10) and n*n>100*n
 assert d>small/2 and source<large/2 and abs(source-d)<small/2
 assert small>=3*large/F(4)
 counts['new_outside_centers']+=1
print('PASS',counts,'total',sum(counts.values()))
```

Only /tmp/r368_geometry.md is written. This bounded delivery stops with the final preferred (19), its exact unpaid outside-center complement, and the checked finite-scale proof.
