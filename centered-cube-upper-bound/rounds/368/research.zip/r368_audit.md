# R368 independent final audit

Status: FINAL PASS for the actual-radius D capacity, its preferred direct high-past absorption, the restored R338 integration, the positive-volume exterior witness, the conditional source-depth profile and the stated numerical scope. Only this audit file is reviewer-owned. General weak-type/root closure, a useful covered fraction and exhaustive historical novelty are NOT certified.

## 1. Independent screen and frozen contract
Before reading the new geometry author proof, independently checked the bin count, normalized mixed-volume coefficients, original-G row bound and clock payment. Preserve real measurable finite-Lebesgue-measure E, full nonnegative L1 f, actual a<=R<=b<=2a, m=f(Q)=qR^n, q_-=3lambda/4<=q<=lambda, mu=du/m, original J,H and same-source capture. The positive G integrand has one mass-oriented endpoint u with m_u>K m_v,K=e^sqrt(n)>lambda/q_-, so R_u>R_v. All global strict-past and physical-prefix gates, and original clock ell=b^-n delta_b+n r^-n-1 dr, remain fixed. The proof pays m_u-m_v directly by m_u and uses m_u mu(du)=du; it does not require the extra weighted-volume term needed when bounding a full symmetric difference by m_u+m_v. No old negative-square credit is reissued.

D is enabled for n>=8 and means R_v>=3R_u/4 and sum e_j<=nR_v/64, e_j=(2|u_j-v_j|-(R_u-R_v))_+. For n<8 D is empty, not an omitted difficult complement. Boundaries in the two D predicates belong to the paid side.

## 2. Actual-radius bins and center geometry
Let rho=1+1/n. Disjoint intervals with lower endpoints a rho^j,0<=j<n, final endpoint closed, cover all actual R_v because rho^n>=2>=b/a; clipping to[a,b] and empty bins cause no duplication. This is a partition of actual receiver values, not independent integration over freely assigned radii. In a bin s<=R_v<=rho s, any selected pair has0<=(R_u-s)/s<=4rho/3-1<=1/2. The joint excess relative to the larger center-cube side R_u-s is <=n rho s/64<=9ns/512. Thus real center v lies in that cube plus an l1 ball of radius n rho s/128.

The exact normalized volume is P_n(c,z)=sum binom(n,k)c^(n-k)z^k/k!, c<=(1/2),z<=9n/512. The factorial and binomial include all outside-coordinate subsets and signs. By binom(n,k)<=n^k/k!, P<=2^-n sum(2nz)^k/(k!)^2<=2^-n exp(2sqrt(2nz))<=2^-n exp(3n/8)<=exp(-n/4), using log2>=2/3>5/8. This is an analytic positive-series estimate, not a numerical fit. The actual receiver density1/m_v<=1/(q_-s^n) gives a per-bin mu capacity exp(-n/4)/q_-. Summing at most n bins gives d_n/q_-, d_n=n exp(-n/4)<=8exp(-2)<2 for n>=8. Source-capture, mass/past/time restrictions only reduce these center sets. No source f mass is bounded by geometric volume.

For the original D row, the two simultaneous bounds are g_D<=V and g_D<=d_n V/(q_-J). The first follows from the full small-end capture integral/J=1 after positive relaxation. The second integrates the actual small-center capacity and cancels m_u mu(du)=du. These bounds apply under any further original positive mask, including R338's exterior-center gate. The standalone strict-low-T split therefore correctly proves epsilon1 X_q+4d_nW/(3epsilon1), with original H unchanged and the entire crossing radius atom excluded on the strict side. The full first moment and the b clock atom are retained. This remains a valid BACKUP receipt but is not the final charged budget.

A reviewer-local Python Fraction run actually verified21 scalar bin/normalization inequalities for n=8,9,16,32,64,128,10000. It is separate from parent/author counts, not a native input or full pipeline rerun.

## 3. Historical correction and exact priority source
The preliminary contracted-center C capacity is mathematically valid, but not a new paid family: C implies2dist<=sigma R_v<=R_u. Likewise N implies2dist<=R_u-R_v+h_N<R_u because h_N<a<=R_v; A implies the same strict conclusion using t_A<a/4<=R_v. Thus N,A,C all lie within the larger R338 center-dilation paid region. Their later alternative-route estimates remain true, but cannot establish new coverage relative to that stronger original route.

Read /tmp/r338_main.md in full and actually read its authoritative ZIP member main.md. Archive /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/338/research.zip SHA f86cab6035c70f44d83655981dcf34750b257ad9f8f4c4f50e1bde6fd5728820; member SHA69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357 is byte-identical to the tmp copy. This is the checked source of the retained contract, not a new proof imported from an unverified name.

The correct base is B_H(f,nu)<=G_out+2epsilon0 X_q+C338 W,nu<=f, with K=e^sqrt(n),h*=(1+sqrt(n))/(epsilon0 q_-),alpha_out=(1+sqrt(n))^(1/n), C338=(lambda/q_-)[(2+3sqrt(n)+2e^-sqrt(n))/epsilon0+1+sqrt(n)]. G_out retains full f, original J>=H, common capture, strict mass gap, STRICT GLOBAL past>h*, and2dist>alpha_out R_u. The cost of raising the past threshold is ALREADY in C338. W is the full f mass; the initial nu<=f domination does not change q,m or the source used to define J.

The final history appendix has the R338 correction and confines its searches to named archives. Its earlier absence-of-a-mask finding is explicitly restricted to the initially searched rounds and is not a novelty theorem. The D illustration beyond cited geometric masks is only geometric in that appendix; full original gate verification is supplied by the separate witness. No global first-ever coverage across all alternative historical ledgers is certified.

## 4. Final preferred receipt: exploit the existing high-past gate
Independently screened this stronger argument before reading new author section5B, then read sections5A/5B and final main/ledger. PASS. If an original pair row is nonzero, every receiver w in its global strict mass past has m_w<m_u/K, hence R_w^n<m_u/(Kq_-)<R_u^n because K>lambda/q_-. Since u is in E_r, every such w is already in E_r, and Z_y(m_u/K-)<=J_r(y). Therefore every live D row has J_r(y)>h*. If J<=h*, the entire row is zero. This support fact may be used before relaxing other positive gates; no y-dependent private receiver field or new threshold is introduced.

Combining the proven capacity with the original denominator gives G_out,D<=d_n X_q/(q_-h*)=epsilon0 d_n X_q/(1+sqrt(n)). This adds NO SOURCE FEE and needs NO independent epsilon1. The standalone low-clock fee, old N/A/C fees and old unions are valid alternatives only, not charged on top. The preferred exact positive split is G_out=G_out,D+G_out,notD, so B_H(f,nu)<=G_out,notD+epsilon0[2+d_n/(1+sqrt(n))]X_q+C338W. For n<8 use d_n=0 and all G_out remains. Empty live rows also contribute zero.

Original entrance8lambda H W+2d_eff A_n W_nu/H+2B_H and whole outerLambda=128/119 are retained. The hard-slot receiver coefficient is2Lambda epsilon0[2+d_n/(1+sqrt(n))], with no new source coefficient. Since n>=8 gives d_n<2 and1+sqrt(n)>3, the bracket is<3; epsilon0=epsilon/3 yields at most2Lambda epsilon for this SLOT only. No general absorption room, parameter choice for H/d_eff, or payment for independent slots is inferred. The exact remaining gate is original G_out AND[R_v<3R_u/4 OR sum e>nR_v/64]. All source/time/past data remain frozen.

## 5. Full positive-volume exterior witness
Read /tmp/r368_witness.md, final script and result JSON in full. PASS for n10000,a1,b2,lambda4/3,q_-1,f=1_[-3,3]^n,epsilon0=119/3072 and H=h*=310272/119. The continuum baseline R0=max(1,2||w||inf+2delta) on E has upper radius1.5 and captures the WHOLE positive-volume Y source box. Override U centered at-.4e1 to radius2 and V centered at.7e1 to radius1.5; both remain inside E, have actual q1, and strictly capture all Y. All selected cubes are inside the source support. No atomic receiver approximation or small global menu replaces the actual field.

For U times V, first separation is1.1 plus/minus2rho and only one excess is positive,1.7 plus/minus4rho. Rv/Ru=.75 is the correctly included D boundary; the excess is below nRv/64=1875/8. Rational upper log bound gives failure of oldN/A. The exact(21/20)^100>101 with n>=100 proves alpha_out<21/20, and separation>21/20 proves the full old expanded-center EXTERIOR gate, not merely failure of N/A or contracted C.

Every actual receiver outside U has radius<=1.5, so mass<2^n/e^100 by(4/3)^4>3>e. Thus all are in U's STRICT global mass past. The baseline radius1 block plus density n(r-2delta)^(n-1) gives capacity>49n/150. Removing U,V costs<2 because baseline R0>=1. Therefore Z>9794/3>H=h*, with actual J_b>=Z. This realizes mass ratio, high-J, strict high-past, exterior-center and D simultaneously on Y times U times V of positive Lebesgue volume. Source/receiver matching is full f, not a formal incidence matrix.

The generic J_b<=1+nlog2<1+n and the terminal b atom give the correct rigorous lower bound2^-n |Y||U||V|[2^n-(3/2)^n]/[2^n(3/2)^n(1+n)]>0. Both receiver masses are present. This proves nonemptiness for the stated epsilon0/H, not for every possible later epsilon allocation. It supplies no useful covered fraction, R355 terminal-shell/path realization, or first-ever historical novelty. Older finite-dimensional alternative bounds may already price that dimension at a larger constant and are not added here.

## 6. Conditional source-depth auxiliary
Read /tmp/r368_source_capacity.md in full. PASS only as a conditional interface, not a general receipt. U=(m_u/(Kq_-))^(1/n)<R_u; U<=a makes the strict small-mass domain empty. For U>a, the capturing center cube Q_t(y) expands with t and both tail excess predicates increase; S_tail(t) is nested. Its actual-center layer formula includes the a base block and the U endpoint. Original Rv<U may be extended positively to<=U.

The coordinate pushforward of center Lebesgue measure has a zero-excess atom and two density1/2 positive intervals, retaining multiplicity. Product/simplex convolution and clipping at h_N correctly give V_tail=t^n-V_N-V_A+V_AN. This product is for center dv, not for f or its posterior coordinates. Capacity is measurable and C<=Cmax=[1+nlog(U/a)]/q_-. For original H>0, keeping the unchanged source posterior and using1/J<=1/H yields G_tail[B]<=H^-1 integral_B q E_pi C du after the original clock. The two-level posterior condition implies E_pi C<=epsilon H, including epsilon H>=2Cmax. It is not known for all f, cannot follow from source-volume smallness, and is NOT inserted into the priority ledger. R338's outside tail is a positive further restriction of this auxiliary notN/notA ancestor tail.

## 7. Final files, evidence and limitations
Read final /tmp/r368_main.md, ledger, numeric, readme and history in full, including the final zero-new-source-fee changes. The ledger preserves older full accounts as historical ALTERNATIVES only. It does not append path/head/recapture costs, spend the original square twice or repurchase oldN/A/C. General soft C_H-S_H,crossing I_H, hard-contract/entry connections, heavy-tail/distance/lowpe/extreme-scale and threshold complements, chronological initial/deletion/future-source atoms, H/source/physical-scale/outer aggregation and limits remain explicit. Old CZ absorption is conditional on the same certified X account. No global root/weak-type closure follows.

Read all three final scripts and witness JSON. Geometry and source-capacity standalone scripts match their author embedded Python blocks up to whitespace. Parent reports actual fresh112941 geometry Fraction assertions,3024 source-profile Fraction assertions,21 witness Fraction assertions, total115986. Geometry finite checks cover bin endpoints, selector envelopes and polynomial coefficients, not arbitrary source high-past fields. Source-profile checks cover exact interval/atom algebra and nestedness, not the posterior condition. The witness combines its analytic continuum field with21 exact parameter assertions; it is not a high-dimensional exhaustive numerical integral. No Decimal/float comparisons are mislabeled as interval or exact evidence in this round's parent count. Reviewer21 Fraction bin checks remain separate. No full pipeline was needlessly rerun, and unchanged scripts were not rerun just because the stronger analytic section5B was added.

Final PASS does not independently certify the main's skill/PDF-reading claims, comprehensive historical novelty, TeX/PDF compilation, ZIP packaging integrity or Git state. No author or repository file was edited. All hashes below bind the final reviewed bytes.

## Final SHA256 bindings

- `/tmp/r368_geometry.md` — `4d4276d650b571d5679cd50f82709d29fb9116677bf7f21e50bb089d2fabe418`

- `/tmp/r368_source_capacity.md` — `e511ecc6789e63314dba7089e0ad7de0c7318df7bba386c00f30a7a73babdbf6`

- `/tmp/r368_witness.md` — `89c7cd3f9308bfe9855d0ec506028ff625646812e06c6b537f2898a5729b08cf`

- `/tmp/r368_main.md` — `a9df78394ca8181c3f585cb14145b6d536751e9ed8ed668d6bbf806eee2213bc`

- `/tmp/r368_ledger.md` — `9e89db5695cb96db4e7b4736b792ea67fd6414baf230e2be295f236e58c31894`

- `/tmp/r368_numeric.md` — `ba38cd7248f3785aa60d69172a5b148901ae639ef4ecb9989c82c4736a54dfcb`

- `/tmp/r368_readme.md` — `64d23c56ed06cec2200aaafa6dc3fa2000c177362896409be1b5e555197fa23f`

- `/tmp/r368_history.md` — `dbf18e2ca6bfcef6035b21742da2173a2fee3d439f3d934b8129739e986303cd`

- `/tmp/r368_geometry_check.py` — `e744757c096843081b07d0ecef2a947f28aaf2130a29056c99c0c56974e92acf`

- `/tmp/r368_source_capacity_check.py` — `01f0bce4905c24ab39ac49eddcfb9aecd73282c250200a0dbe907f24de135fc3`

- `/tmp/r368_witness_check.py` — `d451f0fe0e18a1d2129cd9d872c3f3d0d8639bee842aa756f2e9684e86aeb4e7`

- `/tmp/r368_witness_result.json` — `da429ddfc2d1906b6b6f6c17061ef253524f69e33948d0cdfca0ef27ad288d8b`

- `/tmp/r338_main.md` — `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`

- `/tmp/r367_audit.md` — `e011e5007565829c17154effe9c7a6ef50f9e95426a3889dae052f71240b68c3`

- `/tmp/r367_ledger.md` — `530c22b9e009f333f51b3b62c74dfecca366310e75386f047a3cee2102fea470`

- Authoritative R338 archive `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/338/research.zip` — `f86cab6035c70f44d83655981dcf34750b257ad9f8f4c4f50e1bde6fd5728820`; member `main.md` — `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`.
