#!/usr/bin/env python3
"""Round 50. Finite micro-split dominance and continuous-profile remainder guards.
Finite-difference checks concern listed finite inputs only. No exponent fitting,
global weight optimization claim, external packages, or randomized sampling.
"""
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from pathlib import Path
import json
from math import isqrt

class I:
    def __init__(self, lo, hi=None):
        self.lo=F(lo); self.hi=F(lo if hi is None else hi); assert self.lo<=self.hi
    def __add__(self,o):
        if not isinstance(o,I): o=I(o)
        return I(self.lo+o.lo,self.hi+o.hi)
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self,o): return self+-o if isinstance(o,I) else self+I(-o)
    def __mul__(self,o):
        if not isinstance(o,I): o=I(o)
        vals=[x*y for x in (self.lo,self.hi) for y in (o.lo,o.hi)]
        return I(min(vals),max(vals))
    __rmul__=__mul__
    def __truediv__(self,q):
        q=F(q); assert q!=0
        return self*I(1/q)
    def data(self): return [str(self.lo),str(self.hi)]
    def contains_zero(self): return self.lo<=0<=self.hi

@lru_cache(None)
def root(q,n,bits):
    q=F(q); assert q>0
    if n==1: return I(q)
    h=F(1)
    while h**n<q: h*=2
    if h**n==q: return I(h)
    l=F(0) if h==1 else h/2
    for _ in range(bits):
        mid=(l+h)/2
        if mid**n==q:return I(mid)
        if mid**n<q:l=mid
        else:h=mid
    assert l**n<=q<=h**n
    return I(l,h)

def family(points,weights):
    n=len(points[0]); out=[]
    for mask in range(1,1<<len(points)):
        ids=[j for j in range(len(points)) if mask>>j&1]
        m=sum((weights[j] for j in ids),F(0))
        lo=tuple(min(points[j][i] for j in ids) for i in range(n))
        hi=tuple(max(points[j][i] for j in ids) for i in range(n))
        out.append((mask,m,lo,hi))
    return out

def cost_enclosure(points,weights,lam,bits=48):
    n=len(points[0]);inner=[];outer=[]
    for mask,m,lo,hi in family(points,weights):
        if not m:continue
        rr=root(m/lam,n,bits)
        for target,r in ((inner,rr.lo),(outer,rr.hi)):
            target.append(tuple((hi[i]-r/2,lo[i]+r/2) for i in range(n)))
    return I(lam*union_volume(inner),lam*union_volume(outer))


def boxes(points,weights,lam,bits,shrink=F(0)):
    n=len(points[0]);out={}
    for mask,m,lo,hi in family(points,weights):
        if not m:continue
        rr=root(m/lam,n,bits)
        out[mask]=tuple((I(hi[i])+shrink-rr/2,I(lo[i])-shrink+rr/2) for i in range(n))
    return out

def volume_boxes(bb):
    inner=tuple(tuple((l.hi,h.lo) for l,h in b) for b in bb)
    outer=tuple(tuple((l.lo,h.hi) for l,h in b) for b in bb)
    return I(union_volume(inner),union_volume(outer))

def union_volume(boxes):
    boxes=tuple(sorted(set(b for b in boxes if all(l<h for l,h in b))))
    boxes=tuple(b for j,b in enumerate(boxes) if not any(k!=j and all(c[i][0]<=b[i][0] and b[i][1]<=c[i][1] for i in range(len(b))) for k,c in enumerate(boxes)))
    if not boxes:return F(0)
    cuts=sorted({x for b in boxes for x in b[0]});total=F(0)
    for l,h in zip(cuts,cuts[1:]):
        active=[b[1:] for b in boxes if b[0][0]<=l and h<=b[0][1]]
        if active:total+=(h-l)*(F(1) if not active[0] else union_volume(active))
    return total


def cdf(u,p):
    if u<=-1:return F(0)
    if u>=1:return F(1)
    return (1+u)**p/2 if u<0 else 1-(1-u)**p/2

def main():
    records=[]
    for n in (1,2,4,8):
        for N in ((1,2,3) if n<=2 else (1,2)):
            ws=tuple(F(2**j,2**N-1) for j in range(N))
            pts=tuple(tuple(F(j*(i+1),7*max(1,N-1)*n) for i in range(n)) for j in range(N))
            for lam in (F(1,7),F(1),F(5,3),F(7)):
                for b in (F(1,2),F(1,7)):
                    finews=tuple(t for w in ws for t in (w*b,w*(1-b)))
                    eta=min(finews)
                    for factor in (1,8):
                        eps=eta/(16*n*max(F(1),lam)*factor)
                        finepts=tuple(tuple(q[i]+sign*eps for i in range(n)) for q in pts for sign in (-1,1))
                        for bits in (32,48):
                            fine=boxes(finepts,finews,lam,bits);coarse=boxes(pts,ws,lam,bits,eps)
                            minimum_margin=None
                            for mask,rect in fine.items():
                                coarse_mask=sum(1<<j for j in range(N) if mask & (3<<(2*j)))
                                full_mask=sum(3<<(2*j) for j in range(N) if coarse_mask>>j&1)
                                full=fine[full_mask]
                                if mask!=full_mask:
                                    for (l,h),(L,H) in zip(rect,full):
                                        margin=min(l.lo-L.hi,H.lo-h.hi)
                                        assert margin>0
                                        minimum_margin=margin if minimum_margin is None else min(minimum_margin,margin)
                                target=coarse[coarse_mask]
                                assert all((l-L).contains_zero() and (h-H).contains_zero() for (l,h),(L,H) in zip(full,target))
                            finecost=volume_boxes(list(fine.values()))*lam;fullcost=volume_boxes(list(coarse.values()))*lam
                            assert (finecost-fullcost).contains_zero()
                            base=cost_enclosure(pts,ws,lam,bits)
                            assert fullcost.hi<=base.lo
                            records.append(dict(stage='finite_split',n=n,N=N,lam=str(lam),split_weight=str(b),eps=str(eps),bits=bits,
                                micro_subsets=len(fine),cost=finecost.data(),full_box_cost=fullcost.data(),dominance_margin=str(minimum_margin)))
    # Heterogeneous, noncentered three-point clouds: compare with true barycenter motion.
    for n in (1,2,3,5):
        for N in (1,2):
            ws=tuple(F(j+1,N*(N+1)//2) for j in range(N));pts=tuple(tuple(F(j*(i+1),9*n) for i in range(n)) for j in range(N))
            fractions=(F(1,2),F(1,3),F(1,6))
            for lam in (F(1),F(3,7)):
                finews=tuple(w*t for w in ws for t in fractions);eps=min(finews)/(16*n*max(F(1),lam))
                offsets=tuple(tuple(tuple((F(-1,j+1) if k==0 else F(j+1,4*N) if k==1 else F(1,2)+F(j,4*N))*(-1)**i for i in range(n)) for k in range(3)) for j in range(N))
                fp=tuple(tuple(pts[j][i]+eps*offsets[j][k][i] for i in range(n)) for j in range(N) for k in range(3))
                mp=tuple(tuple(pts[j][i]+eps*sum(fractions[k]*offsets[j][k][i] for k in range(3)) for i in range(n)) for j in range(N))
                fine=boxes(fp,finews,lam,48);means=boxes(mp,ws,lam,48)
                for mask,rect in fine.items():
                    cm=sum(1<<j for j in range(N) if mask & (7<<(3*j)));fm=sum(7<<(3*j) for j in range(N) if cm>>j&1)
                    full=fine[fm]
                    if mask!=fm:assert all(l.lo>L.hi and H.lo>h.hi for (l,h),(L,H) in zip(rect,full))
                    assert all(l.lo>=L.hi and H.lo>=h.hi for (l,h),(L,H) in zip(full,means[cm]))
                fc=volume_boxes(list(fine.values()))*lam;mc=volume_boxes(list(means.values()))*lam
                assert fc.hi<=mc.lo
                records.append(dict(stage='barycenter_comparison',n=n,N=N,lam=str(lam),eps=str(eps),split_cost=fc.data(),mean_cost=mc.data()))
    # A real kink: opening two old zero-measure seams adds four first-order faces.
    for denominator in (16,32,64,128,256,1024,4096,65536):
        eps=F(1,denominator)
        pts=tuple((y+sign*eps,) for y in (F(0),F(1)) for sign in (-1,1))
        value=cost_enclosure(pts,(F(1,4),)*4,F(3,4))
        expected=F(5,4)-F(9,2)*eps
        assert value.lo==value.hi==expected
        records.append(dict(stage='seam_dissipation',eps=str(eps),cost=str(expected),difference='-9/2',exterior_only='-3/2',old_mixture='-3'))
    # Shrinking a fragment mass invalidates a profile-uniform erosion expansion.
    for power in (4,6,8,10,14,20):
        eps=F(1,2**power);b=eps**2
        original=((-eps,),(eps,));centered=((-2*eps*(1-b),),(2*eps*b,))
        value=cost_enclosure(original,(b,1-b),F(1));cv=cost_enclosure(centered,(b,1-b),F(1))
        assert value.lo==value.hi==cv.lo==cv.hi==1-b/2
        records.append(dict(stage='vanishing_fragment',eps=str(eps),tiny_mass=str(b),cost=str(value.lo),loss_over_eps=str(b/(2*eps)),formal_fixed_profile_loss_over_eps='2'))
    # Exact continuous profiles: roots are made rational by choosing epsilon.
    for p in (2,3,4,8,16,32,64,128):
        for q in (2,4,8,16,32):
            eps=F(p,4*q**(p-1))
            if eps>F(1,16):continue
            v=F(1,q);ustar=1-v;xstar=F(1,2)-eps+eps*v-v**p/4
            expected=1-2*eps+2*eps*(1-F(1,p))*v
            assert 2*xstar==expected and p*v**(p-1)/4==eps and xstar>eps
            largest=F(0)
            for k in range(129):
                u=F(k,64)-1;candidate=cdf(u,p)/2-eps*u
                assert candidate<=xstar
                largest=max(largest,candidate)
            for eta in (F(1,2),F(1,4)):
                beta=eta**p/2
                if eps<beta/4:
                    assert 1-2*eps<=expected<=1-2*(1-eta)*eps
            records.append(dict(stage='continuous_profile',p=p,q=q,eps=str(eps),value=str(expected),core_value=str(1-2*eps),
                correction_over_eps=str((expected-1+2*eps)/eps),stationary_cut=str(ustar),grid_candidates=129,largest_grid_boundary=str(largest)))
    # At an attaining threshold: inclusion under a raised threshold certifies the direction of the dissipation bound.
    for n in (1,2,4,8,16,32,64,128):
        for denominator in (16,64,256):
            eps=F(1,denominator)
            ratio=(1-2*eps)**n
            assert 0<ratio<1 and 1-ratio<=2*n*eps
            records.append(dict(stage='threshold_rescaling',n=n,eps=str(eps),volume_ratio=str(ratio),note='symbolic necessary loss bound; not a global high-dimensional numerical optimizer'))
    # Exact mass inflation: arbitrary subsets gain at least c in capture radius.
    for n in (1,2,4,8):
        for N in (1,2,3):
            old=tuple(F(j+1)**n for j in range(N));W=sum(old)
            for c in (F(1,16),F(1,256),F(1,65536)):
                new=tuple((F(j+1)+c)**n for j in range(N))
                for mask in range(1,1<<N):
                    a=sum(old[j] for j in range(N) if mask>>j&1);b=sum(new[j] for j in range(N) if mask>>j&1)
                    gap=root(b,n,64)-root(a,n,64)-I(c)
                    assert gap.lo>=0
                total_bound=root(W,n,64)+root(F(N),n,64)*c-root(sum(new),n,64)
                assert total_bound.lo>=0
                records.append(dict(stage='mass_compensation',n=n,N=N,c=str(c),old_mass=str(W),new_mass=str(sum(new)),
                    budget_residual=total_bound.data(),first_variation=str(n*sum(F(j+1)**(n-1) for j in range(N)))))
    result=dict(round=50,status='PASS',cases=len(records),counts={},records=records,random_seed=None,
        proof_status='finite split dominance and fixed-source continuous first variation proved; no dimension-uniform remainder or square-root upper bound')
    for r in records:result['counts'][r['stage']]=result['counts'].get(r['stage'],0)+1
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:result[k] for k in ('status','cases','counts')},sort_keys=True))
if __name__=='__main__':main()
