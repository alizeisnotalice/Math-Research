"""R742. Exact tests of the two-point calculation and the R741 two-scale history."""
from fractions import Fraction as Q
import json
import platform
import sys

import flint
from flint import arb, ctx

ctx.prec = 192


def overlap(left, right):
    width = max(Q(0), min(left[1], right[1]) - max(left[0], right[0]))
    return width / ((left[1] - left[0]) * (right[1] - right[0]))


def kernel_check(count):
    # Disjoint translates of clusters. Each contains both nested and shifted
    # intervals of unequal widths, with deliberately unequal receiving masses.
    intervals = []
    masses = []
    for index in range(count):
        group, offset = divmod(index, 4)
        base = Q(5 * group)
        width = (Q(1, 64), Q(1, 32), Q(1), Q(1, 16))[offset]
        left = base + (Q(0), Q(1, 128), Q(0), Q(2))[offset]
        intervals.append((left, left + width))
        masses.append(Q((1, 3, 2, 1)[offset], 4))
    energy = [
        sum(mass * overlap(box, other) for other, mass in zip(intervals, masses))
        for box in intervals
    ]
    limit = Q(5)
    paid = [min(Q(1), limit / value) for value in energy]
    cut = [index for index in range(count) if index % 3 != 1]
    weighted = [paid[i] * masses[i] if i in cut else Q(0) for i in range(count)]
    total = sum(weighted)
    pair_energy = sum(weighted[i] * weighted[j] * overlap(box, other)
                      for i, box in enumerate(intervals) for j, other in enumerate(intervals))
    # Independent Lebesgue cell integration without using the overlap formula.
    breaks = sorted({end for box in intervals for end in box})
    direct = Q(0)
    for lo, hi in zip(breaks, breaks[1:]):
        mid = (lo + hi) / 2
        density = sum(weighted[i] / (box[1] - box[0]) for i, box in enumerate(intervals)
                      if box[0] < mid < box[1])
        direct += (hi - lo) * density ** 2
    assert direct == pair_energy <= limit * total
    assert any(d < 1 for d in paid) and any(d == 1 for d in paid)
    return dict(rows=count, cut_mass=str(total), square_integral=str(direct),
                bound=str(limit * total))


def genuine_history():
    n = 64
    a = 32 * n
    volume = Q(3, 16) ** 4 * Q(21, 8) ** 60
    source = 2 ** n
    theta = 1 - Q(1, a ** 256)
    bill_lower = theta * source
    bill_upper = bill_lower + volume / a ** 192
    core_lower = theta * (volume - 6 * source) - volume / 32
    assert (volume / a ** 192) ** 4 < Q(1, n) < theta ** 4
    bound_per_axis = max((1 + Q(2, n) + radius - Q(9, 8)) / (2 * radius)
                         for radius in (Q(1, 2), Q(3, 4)))
    assert bound_per_axis == Q(7, 16)
    old_fraction_upper = n * bound_per_axis ** 8
    assert (1 + Q(1, a)) ** 2 * 5 / (64 ** 2 * n) < Q(1, 8) ** 2
    assert arb(n).log() < 5
    residual_lower = (1 - old_fraction_upper) ** 2 * (core_lower - volume / 8)
    assert 0 < residual_lower < core_lower <= theta * volume
    assert volume / source < 942 < n ** 2
    def bracket(value):
        return [(10 ** 8 * value).__floor__(), (10 ** 8 * value).__ceil__()]
    return dict(n=n, V_T="(3/16)^4*(21/8)^60", R_high="theta*V_T",
                D_bounds=["theta*2^64", "theta*2^64+V_T/2048^192"],
                M_bounds=["theta*(V_T-6*2^64)-V_T/32", "theta*V_T"],
                row_allowance="1/4", M_normalized_excess_outer=[
                    bracket((core_lower - volume / 4) / (8 * bill_upper))[0],
                    bracket((theta * volume - volume / 4) / (8 * bill_lower))[1]],
                old_B="1/2", old_sigma="1/4", old_paid_endpoint_upper=str(old_fraction_upper),
                old_residual_over_V_lower=bracket(residual_lower / volume),
                new_B=2, normalized_overlap_upper=bracket(volume / source),
                new_unpaid_exact=0, scale=10 ** 8)


def strip_check(n, b):
    L = arb(b + 1) + arb(n + 2).log()
    assert L <= arb(n) / 64
    root = (n * L).sqrt()
    geometric = 8 - 2 * (2 * arb(1).exp()).sqrt()
    slack = (geometric - 2) * root - 2 * b
    assert slack > 0
    return dict(n=n, b=b, exponential_slack=str(slack))


if __name__ == '__main__':
    out = dict(python=sys.executable, python_version=platform.python_version(),
               python_flint=flint.__version__, arb_bits=ctx.prec,
               interval_tests=[kernel_check(size) for size in (4, 12, 48, 96)],
               mixed_strips=[strip_check(n, b) for n, b in
                             ((4096, 1), (4096, 48), (65536, 2), (65536, 1010),
                              (1048576, 8192), (1048576, 16367))],
               genuine=genuine_history())
    print(json.dumps(out, indent=2))
