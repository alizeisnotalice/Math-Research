"""Public R91 neutral Mellin diagnostics; standard library, no private data.

All transcendental values are floating diagnostics, not directed intervals.
General statements are proved in parent_mellin.md, independently of this code.
"""
import cmath
import json
import math
from pathlib import Path
import time


def exprel(z):
    if abs(z) >= 0.25:
        return (cmath.exp(z) - 1) / z
    result = term = 1 + 0j
    for k in range(1, 80):
        term *= z / (k + 1)
        result += term
        if abs(term) < 1e-18 * max(1, abs(result)):
            break
    return result


def atom(n, xi):
    return 1 / complex(n, 2 * math.pi * xi)


def mollified(n, eps, xi):
    z = complex(n, 2 * math.pi * xi)
    loga = math.log1p(-2 * eps)
    dlog = math.log1p(2 * eps) - loga
    return cmath.exp((1-z) * loga) * dlog * exprel((1-z)*dlog) / (4 * eps * z)


def direct_orbit(n, eps, xi, steps=2048):
    z = complex(n, 2 * math.pi * xi)
    # Exact change of variable on the ramp, followed by its exact infinite tail.
    def integrand(t):
        return (1+t) * cmath.exp(-(z+1) * math.log1p(2*eps*t))
    total = integrand(-1) + integrand(1)
    for j in range(1, steps):
        total += (4 if j % 2 else 2) * integrand(-1 + 2*j/steps)
    return eps * total * 2/(3*steps) + cmath.exp(-z * math.log1p(2*eps))/z


def simpson_log_band(fn, a, b, steps=2048):
    # 2 integral_a^b |fn(xi)| dxi, using logarithmic frequency coordinates.
    lo, hi = math.log(a), math.log(b)
    def integrand(v):
        xi = math.exp(v)
        return 2 * abs(fn(xi)) * xi
    total = integrand(lo) + integrand(hi)
    for j in range(1, steps):
        total += (4 if j % 2 else 2) * integrand(lo+(hi-lo)*j/steps)
    return total*(hi-lo)/(3*steps)


def band(n, a, b):
    return (math.asinh(2*math.pi*b/n) - math.asinh(2*math.pi*a/n))/math.pi


def run():
    started = time.perf_counter()
    rows, counts = [], {}
    stages = {
        "pilot": [(n, 2.0**(-q), xi) for n in (1, 2, 8) for q in (8, 12) for xi in (0, .125, 1, 8)],
        "jump_pressure": [(n, 2.0**(-max(12, n.bit_length()+8)), c*n) for n in (3,16,128) for c in (0,.25,1,16)],
        "expanded": [(n, 2.0**(-q), c*n) for n in (1024,65536) for q in (32,48,64) for c in (0,1,16)]
    }
    for stage, cases in stages.items():
        count = 0
        max_rel = 0
        for n, eps, xi in cases:
            value, quadrature = mollified(n,eps,xi), direct_orbit(n,eps,xi)
            rel = abs(value-quadrature)/max(abs(value),1e-300)
            assert rel < 2e-10, (stage,n,eps,xi,rel)
            bound = math.exp(-n*math.log1p(-2*eps)) * (math.log1p(2*eps)-math.log1p(-2*eps))
            assert abs(value-atom(n,xi)) <= bound + 2e-14
            max_rel = max(max_rel, rel)
            count += 2
        rows.append({"stage":stage,"transform_cases":len(cases),"max_relative_quadrature_error":max_rel})
        counts[stage] = count
    # Enlarging actual frequency bands: checks a proved analytic lower bound.
    band_rows=[]
    for n in (1,3,16,1024,65536):
        for factor in (4,16,256):
            a,b=n,factor*n
            exact = band(n,a,b)
            numerical=simpson_log_band(lambda xi:atom(n,xi),a,b)
            lower=math.log(factor)/(math.pi*math.sqrt(2))
            assert abs(exact-numerical)<2e-10
            assert exact>=lower
            band_rows.append({"n":n,"factor":factor,"exact_formula_float":exact,"lower_float":lower})
            counts["jump_pressure"] += 2
    # New positive-L1 approximations; B=epsilon^(-1/2), all n fixed per row.
    positive_rows=[]
    for n in (1,16,1024):
        previous=-math.inf
        for q in (32,40,48,56):
            eps=2.0**(-q)
            a,b=n,eps**(-.5)
            error=2*(b-a)*math.exp(-n*math.log1p(-2*eps))*(math.log1p(2*eps)-math.log1p(-2*eps))
            lower=band(n,a,b)-error
            numerical=simpson_log_band(lambda xi:mollified(n,eps,xi),a,b)
            assert numerical+2e-9>=lower
            assert lower>previous
            previous=lower
            positive_rows.append({"n":n,"epsilon_power":q,"finite_band_lower_float":lower,"quadrature_float":numerical,"error_budget_float":error})
            counts["expanded"] += 2
    return {"status":"PASS", "evidence":"floating diagnostics; not interval certificates", "counts":counts,"checks":sum(counts.values()),"transform_stages":rows,"bands":band_rows,"positive_L1_bands":positive_rows,"runtime_seconds":time.perf_counter()-started}


if __name__ == "__main__":
    result=run()
    target=Path(__file__).with_name("parent_mellin_results.json")
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({key:result[key] for key in ("status","evidence","counts","checks","runtime_seconds")},ensure_ascii=False))
