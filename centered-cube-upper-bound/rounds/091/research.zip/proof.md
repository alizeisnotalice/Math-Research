# 中心立方体第91轮：共同来源交换、有限集中轮廓与完整原门证书

日期：2026-10-12。目标仍为任意非负 L1 输入、真实勒贝格接收测度下的 `C_n^square <= sqrt(n)n^{o(1)}`。**一般目标尚未证明**；保留的一般基准为 O(n log n)。本轮没有将固定输入、有限正体积单元或条件性递推当作一般闭合。

覆盖路线证明：真实来源闭包允许消去人为删源产生的平移跳跃；共同最小密度提供精确抵消；完成接收割保留来源质量。对侧仍满足原前缀的一类流可以按其真实接收需求支付，但该需求尚未由当前主来源质量控制，另两类对侧缺口也未支付。抽象图只用来否定从邻接关系推断正交换流的逻辑跳步。

递推路线从实际来源筛选和环带质量中推出有限尺度的多坐标集中轮廓、共同来源子集及真实捕获份额，并据此支付、删除一部分原接收点。包数和逐层费用均显式保留；完整指定阶段带的进度结论没有支付退出该阶段带后的费用，现有费用也不是根号阶。

替代路线完整定义卷积再居中链及其补偿：在自然停止时刻，逐步求绝对补偿的费用仍可达到线性维数，且结论对事先依据输入选择的正转移核统一。这限定了该种记账方式，未否定保留跨步符号抵消的方案。另一个独立计算说明方体尺度轨道的真实跳跃阻止直接移植热轨道的绝对高 Mellin 频率预算。

文献组重新核对更新技能所需的原始定理、实际加权来源树与跳跃投影条件，并给出精确的余维纤维—提升极大接口。读到的提升定理常数不能提供所需维数估计；自证的保守方体版本也不改进现有局部费。仅文件哈希通过不作为文献适用性的证明。

数值组保持原输入和共同阈值，先做12个确定性浮点候选筛选，再冻结3个新的全维正体积接收单元。它们通过连续最早接触、整个原尺度窗口的平滑上门、原接触处粗平滑低门及对应后验条件的联合验证，**完整资格只在原包指数的已证范围 `0<p<=n` 内成立**；域外未知，中间下限的证明独立于 p。这些单元的真实连续运输容量有上下包络，但容量极小，不是高负载或一般最坏割数据，也不产生接收概率推断。

本轮复用八个角色：三条 Astra high 路线、Astra high 与 Sol high 独立审核、两名 Sol high 数值角色、一名 Sol high 原文与技能角色。替代路线作者遇到服务中断后，由同配置恢复角色接管已有双稿及检验，没有增加重复路线。审核者先独立检查准确命题，再审完整推导；最终执行与冻结收据见文末。

GitHub 仅保存本轮入口和一个精简归档，详细 LaTeX 文本不编译。私人来源模型、接收相位配方及其实际程序留在本地；公开包保留匿名结果范围、完整通用证明、独立审核代码及中性 Mellin 复现程序。


## 第91轮主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；第90轮薄片分支及本轮有限浓缩轮廓均未证明覆盖并支付整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮保留工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。

### 第91轮新增结论的实际范围

来源闭包允许在真正活跃的四重相交几何中消去来源限制制造的跳跃；完成接收割不会自动纳入不合原门、过早停止或捕获新来源的对侧行。交换配对的共同最小密度可抵消，剩余流和这些行的真实需求仍须支付。

实际递推给出当前来源的多坐标局部集中轮廓与正捕获份额，较弱极限平均原子数更精确；共同包覆盖数、原接收需求定价、每阶段阈值和终项仍保留，不把这种必要结构当成一般根阶容量界。

卷积再居中链具有精确的真实勒贝格结算，但在其自然停止时按步求绝对补偿仍可线性收费。因此后续必须证明跨步有符号抵消或不同状态空间的结算；本结论不是极大算子的弱型下界。独立 Mellin 核验则否定直接移植热轨道的绝对高频尾预算，连固定维数的正L1逼近都不能获得该强预算的统一界。

新接收单元使用原输入和原阈值，严格证书的最终状态见数值节。固定 p>0 的原包定义保留；任何仅证明在0<p<=n范围的有限维全门结论均显式标注该范围，n<p不作合格声明。三个正体积单元及其局部运输测量不覆盖整个余集，不构成一般高负担割或渐近阶数证据。


## 1. Result and scope

The requested root-order payment of the entire $\delta=1/2$ remainder is **not proved**. The attempted principal-cut exchange fails at a specific step: four valid capture incidences do not supply four positive edges of the optimizing transport, and principal source closure does not make the source law invariant under the geometric exchange.

The new rigorous conclusions are: restriction-created source jumps vanish on the actual paired disagreement; a concrete involution identifies the maximal exactly cancelling subdensity; all-cut completion removes omitted eligible rows without increasing source mass; and an actual prefix estimate pays one escape component by its opposing receiver demand. That last demand is not bounded by the principal source mass, and two other components remain. No source-only translation-modulus argument is used as a proposed repair.

Fix the original $f\ge0$ in $L^1(\mathbb R^n)$, $n\ge2$, $\lambda>0$, and the unchanged measurable event $F=F_{\rm new}$ with original selector $\tau$. For an original positive principal pair $(A,S)$ from a regular compact $B\subset F$, put
\[
 g=f1_S,\quad M=\int g>0,\quad D=\lambda|A|,\quad
 \chi(x,L)=1_A(x)1_{\{1<L<\tau_x\}}.
 \tag{1}
\]
The retained source closure is
$\mu(Q(x,\tau_x)\setminus S)=0$ for almost every $x\in A$.
The source is not reselected, and all row predicates refer to the original input. In particular no smooth lower gate or later witness is claimed for $g$.

R90 gives $D-a=F_{1/2}+E_{1/2}$, $a\le M$, and
\[
 |F_{1/2}|\le a_n(1/2)(\log2)M
 \le \tfrac12\sqrt n(\log2)M.                           \tag{2}
\]
This paid term is a retained dependency, not a new R91 gain.

## 2. A geometric involution using the same source and rows

Let $d\Omega$ be Lebesgue measure $du$ times the following probability measures: $L$ has density $dL/(L\log2)$ on $[1,2]$; $i$ is uniform in $\{1,\ldots,n\}$; $\sigma$ is a uniform sign; $v$ is uniform on $[0,1]$; and $z_{-i}$ is uniform on its unit transverse cube, with coordinate $i$ zero. Define
\[
 b=L/2,\quad a=(1-v/2)L/2,\quad s=b-a=vL/4,
\]
\[
 r_f=u+Lz_{-i}+\sigma b e_i,\qquad
 r_a=u+Lz_{-i}-\sigma a e_i,\qquad
 H=\chi(r_f,L)-\chi(r_a,L).                             \tag{3}
\]
The second row uses the opposite sign of the adjacent-slab point. Its marginal is still the same uniform slab law because $\sigma$ is uniform. Therefore
\[
 E_{1/2}=n\log2\int g(u)H\,d\Omega.
 \tag{4}
\]
The measure $g(u)d\Omega$ has total mass $M$.

For fixed other variables define
\[
 T(u,\sigma)=(u+\sigma s e_i,-\sigma).
 \tag{5}
\]
Then $T^2={\rm id}$, $T$ preserves $d\Omega$, and
$r_f\circ T=r_a$, $r_a\circ T=r_f$, $H\circ T=-H$.
These assertions follow by substitution and the identity $s=b-a$; translations preserve $du$ and sign reversal preserves its uniform law.

Let $u'=u+\sigma s e_i$. All four source/row incidences are actual side-$L$ incidences:
\[
 u,u'\in Q(r_f,L)\cap Q(r_a,L).
 \tag{6}
\]
In coordinate $i$ their distances from the rows are $a$ or $b$; every transverse distance is at most $L/2$. In particular, if either row is stopped-active, both source points lie strictly inside that row's original contact cube because $L<\tau$.

### 2.1 The source-null-set issue

The resulting assertion is integrated-almost-everywhere, not a claim obtained by restricting a product null set to one fixed face:
\[
 [g(u)-g(u')]H=[f(u)-f(u')]H
 \quad\text{for }d\Omega\text{-almost every state}.
 \tag{7}
\]
Here is a full justification. Remove the receiver-null exceptional set on which source closure fails, obtaining $A_{\rm good}$. Form the open set
$U=\bigcup_{x\in A_{\rm good}}\operatorname{int}Q(x,\tau_x)$.
Second countability provides a countable subcover by members of this family. Each such contact cube has zero $\mu$ mass outside $S$, so $\mu(U\setminus S)=0$. Hence $f1_{S^c}=0$ Lebesgue-almost-everywhere on $U$.

For fixed auxiliary variables each row map in (3) is a translation of $u$, so the bad receiver set has zero $du$ preimage. If $H\ne0$, one good row is active; (6) and $L<\tau$ place both $u,u'$ in $U$. The two source maps are also translations of $u$, so the exceptional Lebesgue-null subset of $U$ is avoided almost everywhere. Fubini proves (7).

Thus artificial jumps created by restricting $f$ to $S$ do not contribute to this paired difference. This does not replace the mass budget $M$ by the full mass of $f$, and does not make the original density equal at the two source points.

## 3. What cancels exactly, and what does not

Write $\widetilde g=g\circ T$, $m=\min(g,\widetilde g)$ and
$\rho=(g-\widetilde g)_+$. Then
\[
 m\circ T=m,\qquad
 \int mH\,d\Omega=0,
\]
\[
 E_{1/2}=n\log2\int\rho H\,d\Omega
 =\frac{n\log2}{2}\int(g-\widetilde g)H\,d\Omega .
 \tag{8}
\]
Also
\[
 \int\rho\,d\Omega=\tfrac12\int|g-\widetilde g|\,d\Omega
 \le M.                                               \tag{9}
\]
All integrals are finite because $|H|\le1$ and $T$ preserves the integral of $g$.

The density $m$ is the **maximal** nonnegative $T$-invariant density dominated by $g$: if $0\le h\le g$ and $h\circ T=h$, then $h\le g\circ T$, hence $h\le m$. Thus full cancellation of $g\,d\Omega$ cannot be asserted from support closure. It would require a property of the actual density or of its correlation with $H$.

These are cancellations of a signed measurement integral. The augmented density $m$ can depend on the scale, coordinate, sign and other kernel variables; it is not generally a new physical source density. Removing it is not a transport reallocation preserving receiver marginals and is not a source-reselection step. Equation (7) only removes artificial restriction jumps where $H\ne0$.

## 4. Completing cuts without an attainment assumption

For a measurable row set $A\subset F$, define its essential source neighborhood by
\[
 N(A)=\left\{y:\int_A1_{Q(x,\tau_x)}(y)\,dx>0\right\}.
 \tag{10}
\]
Null changes in rows do not affect this set modulo $\mu$. For a measurable source set $S$ define
\[
 C(S)=\{x\in F:\mu(Q(x,\tau_x)\setminus S)=0\}.
 \tag{11}
\]
The integrand defining this condition is jointly measurable; therefore $C(S)$ is measurable with the usual completed-measure conventions.

If $S=N(A)$ modulo $\mu$, then
\[
 A\subset C(S)\ \text{a.e.},\qquad N(C(S))=S\pmod\mu .
 \tag{12}
\]
Indeed Tonelli gives
$\int_A\mu(Q(x,\tau_x)\setminus S)dx=0$, proving the first assertion. Applying Tonelli to (11) gives $N(C(S))\subset S$ modulo $\mu$, and the inclusion of rows gives the reverse inclusion. For positive $M=\mu(S)$,
\[
 \frac{\lambda|C(S)|}{M}\ge\frac{\lambda|A|}{M}.
 \tag{13}
\]
The finite-window bound ensures $|F|<\infty$. Thus the global supremum of Hall ratios over measurable cuts can be taken over completed cuts; no maximizing cut need exist.

If compact continuous-selector approximants are required, Lusin's theorem and inner regularity give compact $K_j\subset C(S)$ with continuous $\tau|_{K_j}$ and $|K_j|\to|C(S)|$. Their neighborhoods have mass at most $M$, so their ratios approach or exceed the ratio in (13). No Lipschitz selector is inferred.

Completion retains the original input and gates, but it need not preserve the optimizing column for the earlier ambient $B$. It is not asserted that every strict principal superlevel cut already equals $C(S)$; an essential row minimum may equal the level while all captured source values exceed it. Completion is an all-cut reduction, not a fresh-variance inheritance theorem.

## 5. The exact inactive-row defects

Use a completed cut $C(S)$ for this section. On $H\ne0$, let $x_{\rm act}$ and $x_{\rm in}$ be the active and inactive physical rows of (3). The inactive row belongs to exactly one of these classes:

1. $x_{\rm in}\notin F$.
2. $x_{\rm in}\in F$ and $\tau_{x_{\rm in}}\le L$.
3. $x_{\rm in}\in F$, $L<\tau_{x_{\rm in}}$, and
   $\mu(Q(x_{\rm in},\tau_{x_{\rm in}})\setminus S)>0$.

Let $\mathcal B_j$ denote these disjoint subsets of the augmented space. They are $T$-invariant because $T$ exchanges row labels but leaves the physical active and inactive rows unchanged. Set
\[
 c_j=M^{-1}\int\rho H1_{\mathcal B_j}\,d\Omega,\qquad
 \eta_j=M^{-1}\int\rho1_{\mathcal B_j}\,d\Omega.
 \tag{14}
\]
Then the complete accounting is
\[
 E_{1/2}=n(\log2)M\sum_{j=1}^3c_j,\quad
 |c_j|\le\eta_j,\quad \sum_j\eta_j\le1.
 \tag{15}
\]
No disagreement state or sign has been discarded.

There is a real quantitative constraint on the third, still-stopped branch. For any measurable $R\subset F$, consider its **positive** current with $H=1$, $r_a\in R$ and $L<\tau_{r_a}$. It is at most
\[
 \min\left\{
 2n\lambda\int_R\log\tau_x\,dx,\quad
 n\lambda\int_R\log\tau_x\,dx+
       a_n(1/2)(\log2)M\right\}.                        \tag{16}
\]
**Proof.** Since $\rho\le g$, drop the active-face condition and integrate the remaining opposite-slab indicator. Its marginal is the actual $\delta=1/2$ slab kernel. The density of that kernel relative to the cube is at most $2$, and the original prefix gives $A_Lg\le A_Lf\le\lambda$ for $x\in R$, $L<\tau_x$. This proves the first bound. Alternatively split that slab marginal into volume plus its signed slab-minus-volume term. The volume integral is at most $n\lambda\int_R\log\tau_xdx$, and R90's uniform finite-thickness estimate applied to the same $g$ and row set $R$ bounds the other term by the second term in (16).

For class 3 take $R=F\setminus C(S)$. Bound (16) is an actual receiver-measure constraint missing from an arbitrary finite adjacency graph. However the demand of this opposing row set has no established bound in terms of the particular $M$; it cannot be charged to this source block for free.

Class 1 may include a known paid event or rows with no hard witness at all. A weak bound in $\lambda\,dx$ on a gate-failure event does not automatically bound its pushed paired-current measure. Class 2 does not have the two current side-$L$ incidences as edges of the earlier stopped row's selected cube. Class 3 supplies only positive fresh mass, not a fixed fraction. None of these deficits is covered by principal source closure alone. The remaining cost is precisely the joint current in (14), with the genuine opposing-demand payment (16) retained; no root estimate of their complete sum has been obtained.

## 6. Principal optimality does not create exchange flow

The following is a **NONPHYSICAL finite graph**, not a claimed cube/source/gate realization. It pressures exactly the attempted implication from adjacency and principal flatness to a flow cycle.

There are two high sources of masses $m_1,m_2>0$ and one low source of mass $m_0>0$. The high row sees only the two high sources and has demand $K(m_1+m_2)$. The low row sees all three sources and has demand $km_0$, where $K>k>0$. The optimal squared-load column is $K$ on both high sources and $k$ on the low source; the low row assigns zero flow to both high sources.

To prove this, let $z\ge0$ be its total flow to the high block and put $m_H=m_1+m_2$. The quadratic objective is at least
\[
 \frac{(Km_H+z)^2}{m_H}+\frac{(km_0-z)^2}{m_0}
 =K^2m_H+k^2m_0+2(K-k)z+
       (m_H^{-1}+m_0^{-1})z^2.                         \tag{17}
\]
The lower bound is attained at $z=0$ by distributing the high row proportional to $m_1,m_2$. The strict increase for $z>0$ proves the assertion. For any level strictly between $k$ and $K$, the high row and the two high sources form the principal pair, and this row cut is already complete in the finite graph.

There are four high-source capture edges, but the optimizing flow uses none of the two low-row/high-source edges. A proposed cycle cannot subtract flow from such zero edges. The same graph permits an abstract two-state swap on the high sources with row difference $+1,-1$. Its normalized source-weighted current is
\[
 \frac{m_1-m_2}{m_1+m_2},
 \tag{18}
\]
which tends to one while both optimized high column loads stay equal to $K$. This is not a model of physical prefix averages or of the actual paired-current density. In particular the physical receiver-demand constraint (16) cannot be omitted when trying to realize it. The graph disproves the claimed *logical consequence* of flat optimized loads and adjacency; it does not disprove the actual root-order target.

## 7. Status and verification scope

The true new source-closure constraint (7) removes an artificial obstacle, but it does not pay the original oscillation correlated with receiver disagreement. The maximal invariant cancellation (8) is exact, yet the unmatched density is not a transport plan or a stationary source. Completion gives the right all-cut reduction, while (16) exposes a real opposing-row demand fee that is still unpriced by $M$. The finite graph identifies why principal optimality cannot supply the missing exchange by itself.

Thus this component does not meet the all-input quantitative-gain success criterion. The target
$E_{1/2}\le C\sqrt n\log^a(n+2)M+D/2$
and the fresh principal variance budget remain open. No localization factor or original background-layer fee has been removed.

Both auditors received the exact statements before proof. New author exact rational checks used dimensions $2,3$; $8,16$; and $64,128$ in three stages, with finite completion graphs of 3, 5 and 7 rows. The run covered 108 four-incidence/involution models, 12 paired-state cancellation models, 165 completion models and 36 principal-leakage models. All 1,635 assertions passed (401/473/761 by stage) in 0.034266750 seconds. These are nonphysical algebra checks, not repetitions of R90's binomial or source-modulus tests, and they do not certify actual gates or capacity. Both independent auditors completed full mathematical reads of this MD file and the matching TeX: PASS. Their receipts cover the source-null-set proof, exact invariant cancellation, completion scope, actual opposing-demand estimate and the strictly nonphysical graph pressure. The separate audit report is the authority for independent arithmetic receipts; the author counts above are not an independent replay receipt.

Both numerical owners received the optional opposite-face/slab observable without a request to interrupt original all-gate qualification. Exact source law, original selector, and actual row membership are required; unresolved predicates remain UNKNOWN. No physical experiment or fully gated counterexample is claimed here. No actual new private input recipe was constructed.

The current D01 and G03 scope and M04 measurability limits were checked. All maps and cross terms used here are explicitly defined; no capture Gram theorem, transport duality, stationarity, or general selection theorem is imported from a skill name. Only the two owned R91 coverage files were written; no Git or PDF work was performed.

## 1. Result, actual masses, and terminal

This note proves a finite-stage coordinate concentration profile for the actual q_i>K recursion. It does not assume a uniform normalized marginal modulus, a source cover, coordinate independence, or a special source model. The profile gives a common source subset carrying definite annular traffic, an explicit shared packet decomposition, and a positive fraction of original receivers that can be paid and removed. The payment is not root order. Its coordinate/packet complexity and threshold-weighted repetition remain explicit.

The complete-band argument below has an actual vanishing terminal and an explicit non-root bound. Stages outside the stated band are not covered by that argument. We also strengthen the retained limiting statement to a sourcewise profile and explain why forgetting actual capture constraints cannot solve the problem by atomic support alone. The general arbitrary-positive-L1 target remains open; the retained general bound is O(n log n).

Fix n≥2, H_n=1+n log2, alpha=epsilon0=1/[10log(n+2)], c=1−alpha−epsilon0, beta=c/2, and K>0. At every stage mu_i=f_i dy, W_i=mu_i(R^n), lambda_i=beta^i lambda_0. The current B_i is a measurable subset of the freshly recomputed whole original residual Fnew_i. Every original gate, earliest contact and paid branch is recomputed after source restriction. Put

    Q_i(x)=Q(x,L_i(x)),  1≤L_i≤2,  mu_i(Q_i)=lambda_i L_i^n,
    D_i=lambda_i|B_i|,  R_i=D_i/W_i,  t_i=beta^(−i),
    b_i(y)=∫_Bi L_i(x)^(−n)1_Qi(x)(y)dx≤H_n,
    S_i={q_i>K},  mu_{i+1}=mu_i|S_i,  rho_i=W_{i+1}/W_i.

Here q_i is the original captured-stop column, 0≤q_i≤b_i, and every stopped row mass is strictly greater than c lambda_i. Importantly, R_i=D_i/W_i; it is NOT the retained source capture C_i/W_i. Write C_i=p_i D_i for that separate quantity. Let Bhat_{i+1}⊂B_i be the tentative child after the usual bad-row test and fresh classification, before the new deletion in this note. Its actual new selector satisfies L_{i+1}<L_i on Bhat_{i+1}. Define shat_i=|Bhat_{i+1}|/|B_i|.

Zero masses terminate the relevant branch and no ratios are evaluated there. For positive stages R_i≤min(H_n,|B_i|). The exact source tree is a survival spine: mu_i=mu_0|Z_i, reach mass m_i=W_i/W_0, survival probability rho_i, and exit leaf mass m_i(1−rho_i). In contrast, its compensated mass is

    v_i=t_i W_i,  v_{i+1}=(rho_i/beta)v_i.                  (1)

It can increase. Receiver deletion is not a decrease of this source transition. A finite horizon retains the terminal H_n v_ell unless the remaining receiver event is empty or another proved payment is supplied. No Bellman constant or source martingale is imported from a tree with different masses.

## 2. An actual finite-stage profile

Suppress the stage index. Let W'=rho W, mu'=mu|{q>K}, pi=mu'/W', V=|B|, D=lambda V, R=D/W. Let Bhat' be the tentative continuing receivers. Assume the actual stage satisfies

    R≥8K/c,  shat≥1−c/16,  c/4≤rho≤3c/4.                   (2)

The retained exact annular identity and q>K estimate give

    A=∫_Bhat' L(x)^(−n)mu'(Q(x,L)\Q(x,L'))dx,
    A≥5cD/16,  A/W'≥5R/12.                                (3)

For completeness, with C=∫_B L^(−n)mu'(Q)dx=pD, the q threshold gives p>c−(K/R)(1−rho)≥7c/8. Splitting old capture on continuing rows into new cubes and annuli yields A≥D[p−beta shat−(1−shat)], since dropped-row old capture is at most (1−shat)D and the kernel inflation on new cubes is nonnegative. This proves (3). Every L and L' here is the corresponding original actual selector.

Fix 0<h≤1/n. Set

    C_h=exp((n−1)h)(log2+h),
    varepsilon=5R/(96nV),  d=5R/(48C_h),  k=ceil(d),
    T_j={z: pi_j([z−2h,z+2h])≥varepsilon},
    r_h(y)=Σ_(j=1)^n 1_Tj(y_j),  U={r_h≥k}.                (4)

pi_j is the j-th coordinate marginal of the SAME actual normalized child source. All these sets are measurable. R≤V and R≤H_n imply 0<varepsilon<1 and 1≤k≤n. Let

    E(h)={x∈Bhat':log(L(x)/L'(x))≥h},
    zeta=5c/192,  gamma=zeta/2=5c/384.

Then the following alternative is proved without any additional source regularity:

    either |E(h)|≥zeta V,
    or ∫_U∫_(Bhat'\E(h)) L^(−n)1_(Q\Q')(y)dx dpi(y)
          ≥5R/48,  and pi(U)≥5R/(48H_n).                  (5)

Thus the second branch has a sourcewise count of k comparable to 1+R concentrated coordinate values (and comparable to R when R≥1), not just an average atomic count in a limiting law. It is still only a definite traffic/source fraction; it does not assert a uniform profile on the entire child source.

Proof of the geometric estimate. Define the j-th thin face column

    F_(j,h)(y)=∫_Bhat' L(x)^(−n)1_Q(x,L)(y)
          1_{exp(−h)L(x)/2<|x_j−y_j|≤L(x)/2}dx.

For every fixed y,

    F_(j,h)(y)≤C_h.                                       (6)

Indeed put r=|x_j−y_j|. A contributing row has exp(−h)/2<r≤1 and 2r≤L<2exp(h)r. Its kernel is at most (2r)^(−n), and its other receiver coordinates occupy volume at most (2exp(h)r)^(n−1). Both signs of x_j−y_j therefore give exp((n−1)h)∫_(exp(−h)/2)^1 dr/r=C_h. No smoothness of the selector is needed.

On a small-drop row, the removed annulus is contained in the union of these face layers. Each of its two j-coordinate intervals has length at most (L−L')/2≤h. If such an interval contains a point z outside T_j, the interval is contained in [z−2h,z+2h] and its pi_j-mass is less than varepsilon. If it contains no such point its mass outside T_j is zero. Consequently all unconcentrated-coordinate face traffic is at most

    Σ_j∫1_{y_j∉T_j}F_(j,h)(y)dpi(y)≤2nV varepsilon=5R/48.

On U^c, r_h<ceil(d) implies r_h<d. Equation (6) bounds its concentrated-coordinate face traffic by d C_h=5R/48. Finally, if |E(h)|<zeta V, its normalized annular traffic is at most

    lambda |E(h)|/W' = (R/rho)|E(h)|/V ≤5R/48.

This conversion uses R=lambda V/W, not C/W. Subtract these three terms from A/W'≥20R/48 to obtain the first inequality in (5). The annular column is bounded by b_B≤H_n, which gives pi(U)≥5R/(48H_n).

There is also a genuine finite common cover. In each T_j select successively points at mutual distances greater than 4h. Their disjoint radius-2h intervals each have marginal mass at least varepsilon, so at most floor(1/varepsilon) points can be selected. Maximality covers T_j by their radius-4h intervals. Taking k coordinate choices gives a cover of U by at most

    binom(n,k) floor(1/varepsilon)^k

partial slabs of width 8h. This is an actual cover derived from the common child source. Its global cardinality depends on V/R and is not silently treated as dimension-only. The next section instead uses a dimension-only LOCAL packet count.

## 3. Shared packets, captured shares, and paid receiver progress

Suppose the thin alternative of (5) holds. Define the actual subsource mu_U=mu'|U. Its small-annulus traffic at the OLD kernel and threshold is at least

    (5R/48)W'=(5rho/48)D≥zeta D.                            (7)

Hence the old captured share p_U(x)=A_L(x)mu_U(x)/lambda satisfies 0≤p_U≤1 and ∫_Bhat' p_U dx≥zeta V. The receiver set

    E_U={x∈Bhat':p_U(x)≥gamma}

has |E_U|≥gamma V. This is an actual captured-share conclusion; it is not inferred from pi(U) alone.

Construct one countable disjoint partition of mu_U as follows. Assign each source y the lexicographically first k coordinates among its concentrated coordinates. In those coordinates assign it to the fixed half-open grid of width w=8h. A packet has k-coordinate support widths w and arbitrary remaining coordinates. The labels and source assignment are common to all receivers. Every cube of side at most two meets at most

    N_loc=binom(n,k)[ceil(2/w)+2]^k                          (8)

such packets. This counts all coordinate tags and all potentially intersecting grid cells; there is no hidden choice factor or source replication.

The proved R90 projection fee for each packet is C_slab=(1+w)^k H_(n−k). Normalize each packet's old captured average by lambda. Their sum is p_U≤1; mu_U itself is not falsely declared to have contact lambda. On E_U the sum is at least gamma. Choosing a=gamma/(2N_loc), shares below a sum to at most gamma/2, so their dominant-share total is at least gamma/2. The packet layer-cake estimate therefore proves

    lambda |E_U| ≤ P_i mu_U(R^n),
    P_i=(2/gamma)(1+8h)^k H_(n−k)
                     [1+log(2N_loc/gamma)].                (9)

The same bound applies to every subcut of E_U after the genuine source-neighborhood restriction: old captured shares and packet support survive by Fubini, and no other gate is used by this payment.

One may now remove E_U from the tentative child, at the OLD demand lambda dx, and continue with B'=Bhat'\E_U and the same selected source mu'. This gives |B'|≤(1−gamma)|B|. It leaves the immediate source transition W'/W=rho, and hence rho/beta in (1), unchanged. Subsequent q columns must use the newly reduced receiver set. On the large-radius alternative no extra E_U deletion is performed.

This is new finite actual geometric progress. Its current payment is not root order. At h=1/n, k is comparable to 1+R with absolute constants, and to R when R≥1, but log N_loc has a k log n cost. Even granting the unproved exact-plane coefficient n/k in place of the slab coefficient, the displayed packet route would have coefficient at least

    (2/gamma)n log(n/4),  n>4,                              (10)

because N_loc≥(n/4)^k. This is a limitation of the displayed payment, not a lower bound on the optimal physical capacity. Proving the plane coefficient alone would not pay this route's common packet complexity.

## 4. Complete-band finite budget and the source-flow obstruction

Define B_i after any preceding new deletion, then construct q_i, mu_{i+1}, and the tentative Bhat_{i+1} as in Section 1. Apply the profile alternative only to stages in (2). The source tree reach masses are the m_i in (1); row removal is separate. For a fixed h, the E_U sets removed on thin stages are disjoint subsets of B_0 and have size at least gamma|B_i|. Thus

    Σ_thin t_iD_i ≤D_0/gamma.

On a large stage E_i(h) is a subset of the FINAL continuing child because that branch has no extra E_U deletion. The real nested cube radii along any continuing original receiver have total logarithmic drop at most log2. Hence

    Σ_large t_iD_i ≤[192 log2/(5ch)]D_0,
    Σ_band t_iD_i ≤Q_h D_0,
    Q_h=1/gamma+192 log2/(5ch).                             (11)

These sums can be over any finite horizon, with other stages interspersed. Equation (11) controls only the in-band terms and remains D_0-priced.

Let E_init denote the original initial receiver event before the retained stage-zero paid branches; B_0 is its current residual after those branches. The complete-band bounds below assume |B_0|>0. If B_0 is empty, the original event is paid directly by A_old W_0 and no D_0-priced bound is asserted. Let A_old be the complete retained paid-branch coefficient and G=2K/c. With P_i=0 off the thin branch, the full finite ledger is

    lambda_0|E_init|
       ≤Σ_(i<ell)[A_old v_i+G t_i(W_i−W_{i+1})
                        +P_i t_i mu_{i+1}(U_i)]
                        +H_n v_ell.                       (12)

A stage not in (2) remains in this sum and follows the retained original recursion/classification. No outside stage is erased by (11). Each new charge is at old lambda_i, which is why it is multiplied by t_i, not t_{i+1}.

There is also a finite stage-count consequence. Each in-band term obeys t_iD_i=lambda_0|B_i|≥lambda_0 R_min whenever R_i≥R_min. Thus the number of such stages is at most Q_h|B_0|/R_min, even with other stages interspersed. The band itself permits R_min=8K/c>0. Consequently a positive run cannot remain in this band indefinitely: it terminates or exits the band within that many band stages. An out-of-band exit still retains its terminal and all subsequent fees.

For a COMPLETE run ending with empty receiver demand and no out-of-band exit, sum only over its active stages. Equation (11) gives the occupation bound below. For a hypothetical infinite complete-band run it would also force the displayed zero terminal limit; the preceding stage count already rules out such indefinitely positive behavior:

    Σ_i v_i ≤Q_h D_0/R_min,  and v_ell→0.                   (13)

If P_i≤P_max, all repeated fees in (12) then sum to at most

    (A_old+G+P_max) Q_h D_0/R_min.                          (14)

Here t_i mu_{i+1}(U_i)≤v_i and t_i(W_i−W_{i+1})≤v_i. For a completed finite run the empty receiver event has zero terminal demand; the formal infinite-run implication also pays the terminal by summability. For a finite unfinished horizon the terminal remains in (12). For only a subset of in-band stages, (13)'s full-sequence conclusion is unavailable.

At h=1/n one explicit dimension-only bound is

    P_max=(2/gamma)e^8 H_n
        [1+log(2/gamma)+n log2+n log(ceil(n/4)+2)].           (15)

Use k≤n, (1+8/n)^k≤e^8, binom(n,k)≤2^n and (8). Thus the complete-band estimate is finite and every term is paid, but it is much worse than root order and is not an improvement on the retained general baseline. Substituting D_0≤H_n W_0 does not change that conclusion.

On the actual source probability space mu_0/W_0, the new charges have the exact occupation representation

    Σ_i t_i P_i mu_{i+1}(U_i)
      =∫Σ_i t_i P_i 1_(Z_(i+1)∩U_i)(y)dmu_0(y).            (16)

Common disjoint packets at one stage do not make these sets disjoint across stages. E03's node-mass and terminal requirements are respected by keeping m_i, v_i and receiver demand distinct. Its specific Bellman increment hypotheses have not been proved for this chain, so constants from that theorem are not invoked. General root-order control of (12), including intervening stages, remains missing.

## 5. A sourcewise limiting consequence of actual q>K

For the retained unmodified recursion, or any recursion with additional receiver deletions that still meets the following hypotheses, suppose an infinite subsequence has R_i≥R_*≥8K/c and rho_i≤3c/4. Let nu be a weak subsequential limit of normalized CHILD sources. The R89 compact-support argument applies: q_i(y)≤|B_0∩Q(y,2)|, so all selected sources have common bounded support. Since R_i≤|B_i|, the persistent receiver set B_infty has positive volume, and its measurable decreasing radii have limit L_infty. Write

    b_infty(y)=∫_B∞ L_infty^(−n)1_Q∞(y)dx,
    F(y)=∫_B∞ L_infty^(−n)1_∂Q∞(y)dx,
    r_nu(y)=#{j:nu_j({y_j})>0},  a_*=5R_*/12.

Then

    nu{b_infty≥K}=1,  F(y)≤(log2)r_nu(y) for nu-a.e. y,
    ∫F dnu≥a_*.                                          (17)

The first assertion uses the actual source filter and is stronger than an unsupported support assumption. For fixed m let

    G_m(y)=|B_m\B_infty|
          +∫_B∞ L_infty(x)^(−n)1_Qm(x)(y)dx.

It is bounded upper semicontinuous in y by reverse Fatou; every Q_m(x) is closed. For i≥m, b_i≤G_m, while the normalized child source is supported on q_i>K. Weak convergence places nu on the closed set {G_m≥K}. Intersect over m and use G_m↓b_infty.

For the second assertion, the j-coordinate face column is at most log2 for each fixed source point: integrate the two signs of |x_j−y_j|∈[1/2,1] and the unrestricted transverse cube volume. On source points whose j-coordinate is not an atom of nu_j, that face column vanishes nu-a.e. by Tonelli. Sum the remaining coordinate columns. The last inequality is the R89 fixed-m closed-annulus/Portmanteau result; its limit order and hypotheses are retained, not replaced by multiplication of varying weak limits.

Define the boundary-traffic probability eta=F nu/∫F. Equation (17) yields

    eta{r_nu≥a_*/(2log2)}≥1/2,
    nu{r_nu≥a_*/(2log2)}≥a_*/(2n log2).                    (18)

Indeed the complementary traffic is at most a_*/2, and F≤n log2. More generally ∫_{r_nu<d}F dnu≤d log2. These are sourcewise and boundary-traffic-weighted statements. They are not a uniform codimension count or an original captured posterior share, and they give no finite packet-cardinality bound. In particular near-full codimension cannot be inferred from (18).

## 6. Why an unrestricted atomic profile is not an easier endpoint class

There is an exact scope obstruction to paying concentration solely from the statement r_nu=n. The optimal LOCAL [1,2] cube weak1 constant over ALL finite positive atomic measures equals the constant over ALL positive L1 sources.

Atomic-to-L1 direction: truncate an L1 source to a bounded box and push each fine grid cell's mass to one point. These finite atomic measures have the same mass and converge weakly to the truncated source. Every fixed cube is a continuity set because its boundary has zero L1 mass. At any receiver where the truncated local maximal function is strictly above lambda, one fixed witnessing scale therefore eventually remains above lambda. Fatou gives the uniform atomic weak bound for the truncated L1 source. Increase the truncation to recover the full source by monotone convergence.

L1-to-atomic direction: mollify a finite atomic source with nonnegative compactly supported approximate identities. For each rational scale in [1,2], together with the endpoint 2, cube averages converge at every receiver outside finitely many atom-boundary hyperplanes. Excluding their countable union is harmless for Lebesgue receiver measure. Scales approaching a given scale from above show that this countable set recovers the atomic local supremum. Fatou transfers any uniform L1 weak bound to the atomic source.

All finite atomic measures have maximal coordinate-atomic profile on their source support. Therefore a uniform endpoint argument for that UNRESTRICTED profile must still control the genuine common-source packet geometry. This equivalence is not asserted for the smaller class satisfying {b_infty≥K}, actual-chain admissibility or all original Fnew gates. Removing those restrictions would be an unjustified relaxation. No actual gated counterexample or private lower construction is asserted here.

## 7. Full gates, constants, and validation scope

At every genuine reselection retain original anchor, all-L original P1 upper, strict later hard witness, earliest contact, original exp(−s_n)/2 middle lower, original theta=log⁻²(n+2), and every original kappa stratum used. The whole residual remains Fnew=Fdiff∩{C_h*<3/4,Hbar_h*>sqrt n} before any newly paid receiver deletion. Current B_i is its subset; no variance subset monotonicity is used. Fixed h0=1/(16n²), a0=n^(−p) with original fixed p, rho0=n^(−1/2), h*=1/(16n^(3/2)), and the retained fees are

    B_base=4+2(log2)sqrt(7n/3),  B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta^(−1)+4theta/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*),  B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt n],
    A_old=B_base+B_ext+T_soft/alpha+P_dom+P_phys.

P_phys pays its collision/entropy union once. All-scale return still pays C_loc log(n+2); separate original-kappa summation pays J_n=O(log n). These factors are not absorbed into an unproved source budget.

Pilot validation: the actual finite thin-face column and the four traffic quarters in (5) were independently prechecked. The audit explicitly distinguished R=D/W from C/W before accepting the conversions.

Obstruction pressure: packet complexity (10), compensated source flow (1), and the precisely unrestricted atomic transference in Section 6 block three tempting promotions. No nongated toy is called an actual high-burden chain. The stronger exact-plane fee remains unproved and would not alone settle the displayed packet payment.

Expansion: the proofs hold for every n≥2, all 0<h≤1/n, arbitrary measurable original selectors and correlated current L1 sources, all fixed-grid packet labels, and arbitrary finite horizons with actual receiver deletions. The complete-band terminal is paid only under its explicit full-run assumptions. Numerical owners were given the same-child marginal/profile/annulus observable conditional on a qualified high-q child. No such measurement or full-chain experiment is claimed here; tiny certified cells need not have enough actual R to enter the band. All new proof checks are analytic or independent finite algebra, not reused R90 runs.

The general root-order cube weak bound remains unproved. This note identifies a quantitative obstruction to one proposed stopped-flow payment: a scale-inhomogeneous convolution Markov chain cannot approximate the successive cube averages with a root-order budget obtained by summing absolute predictable errors. The expense is linear even at the chain's natural first-threshold stopping time, with the actual Lebesgue receiver measure. This is not a lower bound for the cube maximal operator and does not exclude cancellation between different steps, a different state space, or a different payment for the stopped signed sum.

The R84 source-conditioned boundary-reset process, its graph occupation identity and renewal formula are retained results, not re-proved here. J05 was read as an interface checklist. It supplies no private frozen-coordinate rule or endpoint theorem. The finite chain below is explicitly defined independently, including its atomic-clock compensator.

## 1. A sharp shell bound for every positive recentering

Use full side lengths and probability densities
\[
 U_r(x)=r^{-n}1_{[-r/2,r/2]^n}(x),\qquad B_rf=U_r*f.
\]
Fix $0<\epsilon\le1$, put $q=1+\epsilon$, and let
\[
 E= [-q/2,q/2]^n\setminus[-1/2,1/2]^n,
 \qquad S_n(\epsilon)=1-(1-\epsilon/2)^n.
\]
For every probability measure $\nu$ on $\mathbb R^n$,
\[
 (\nu*U_1)(E)\le S_n(\epsilon).
 \tag{1}
\]
The bound is attained by a single translation with every coordinate of the translation vector equal to $\epsilon/2$.

To prove it, first translate the unit cube by a fixed vector $z$. In coordinate $i$, write $o_i$ for the length of its overlap with the larger interval and $a_i$ for its overlap with the unit interval. Direct interval geometry gives
\[
 o_i=\min\{1,(1+\epsilon/2-|z_i|)_+\},\qquad
 a_i=(1-|z_i|)_+,\qquad a_i\ge(o_i-\epsilon/2)_+.
\]
The translated cube's shell mass is $\prod_i o_i-\prod_i a_i$. The function
\[
 (o_1,\ldots,o_n)\longmapsto
 \prod_i o_i-\prod_i(o_i-\epsilon/2)_+
\]
is nondecreasing in every variable on $[0,1]^n$: above the clipping point its partial derivative is the difference of two products with the first factors coordinatewise larger; below the clipping point the derivative is nonnegative as well. Its maximum is therefore $1-(1-\epsilon/2)^n$. The stated corner translation attains it. Integrating over $\nu$ proves (1).

For a finite signed measure of total mass zero, define its half-variation by
\[
 \delta(\sigma)=\tfrac12\|\sigma\|_{\rm TV}
               =\sup_A|\sigma(A)|.
\]
Here $\|\sigma\|_{\rm TV}$ is its full total variation norm. Since $U_q(E)=1-q^{-n}$, (1) yields
\[
 \delta(U_q-\nu*U_1)\ge d_n(\epsilon),\qquad
 d_n(\epsilon)=\big[(1-\epsilon/2)^n-(1+\epsilon)^{-n}\big]_+.
 \tag{2}
\]
Scaling gives the same inequality between sides $r$ and $qr$. The proof also applies row by row to an arbitrary receiver-dependent positive recentering kernel: fix the receiver and push its centers forward by their difference from that receiver. This last statement is only a rowwise variation bound; no receiver-column or $L^1$ operator estimate is inferred from it.

At the dimension-dependent step $\epsilon=1/n$, for every $n\ge2$,
\[
 d_n(1/n)\ge\frac9{16}-\frac49=\frac{17}{144}.
 \tag{3}
\]
Indeed $(1-1/(2n))^n$ increases with $n$, while $(1+1/n)^{-n}$ decreases. For real $x$, these monotonicities follow by differentiating $x\log(1-c/x)$ and $x\log(1+1/x)$, respectively. The relevant derivative inequalities are $\log(1-z)+z/(1-z)\ge0$ and $\log(1+z)-z/(1+z)\ge0$; each follows by differentiating once more from value zero at $z=0$. Evaluating at $n=2$ proves (3).

## 2. A complete finite stopped-flow contract

Fix $n\ge2$, set $q=1+1/n$, and let
\[
 J=\left\lfloor\frac{\log2}{\log q}\right\rfloor,
 \qquad r_j=q^j\quad(0\le j\le J).
\]
If $r_J<2$, append $r_{J+1}=2$ and put $K=J+1$; otherwise put $K=J$. Thus $r_0=1$, $r_K=2$, every side lies in $[1,2]$, and the first $J$ ratios are exactly $q$. Moreover $J\ge n/4$. For $n\ge4$ this follows from $\log q\le1/n$, $\log2\ge1/2$ and $J\ge n/2-1$; $n=2,3$ are checked directly. The possible final shorter ratio is not used in the lower bound.

Choose any probability measures $\nu_1,\ldots,\nu_K$ before running the path. They may depend on the input, but are then frozen and do not depend on the evolving receiver. Let $V_j$ be independent with law $\nu_j$. Starting from the actual receiver $Z_K=x$, run the reverse-index chain
\[
 Z_{j-1}=Z_j-V_j,\qquad j=K,K-1,\ldots,1.
 \tag{4}
\]
The state is the pair $(r_j,Z_j)$. At chronological step $k$, $j=K-k$, and the filtration contains the initial receiver and all increments already used. The next increment has exactly law $\nu_j$, independent of that filtration. There are precisely $K$ scheduled transitions, so there is no explosion. The integer-valued jump measure has predictable compensator equal to the sum of the deterministic step-time atoms with mark laws $\nu_j$; this is an atomic clock, not an unproved intensity with respect to continuous time.

Integrate the initial receiver against Lebesgue measure $dx$. Each convolution transition preserves this same measure, so every $Z_j$ has Lebesgue marginal in the resulting sigma-finite path measure. Conditional statements can equivalently be made for each fixed initial receiver, then integrated. The quantities below are integrable over that measure; no probability normalization of the entire Euclidean space is being assumed.

For nonnegative $f\in L^1$, define the signed probability-density residual and observed payoff
\[
 e_j=U_{r_j}-\nu_j*U_{r_{j-1}},\qquad
 H_k=B_{r_{K-k}}f(Z_{K-k}),\quad0\le k\le K.
 \tag{5}
\]
The sign in (4) gives
\[
 \mathbb E[H_{k+1}\mid\mathcal F_k]
   =H_k-(e_{K-k}*f)(Z_{K-k}).
\]
Consequently
\[
 M_k=H_k+\sum_{\ell=0}^{k-1}
                (e_{K-\ell}*f)(Z_{K-\ell})
 \tag{6}
\]
is the exact compensated martingale. All predictable terms, including the final transition, are present. For each fixed initial receiver the payoffs are bounded by $\|f\|_1$ because all sides are at least one; the finite chain therefore needs no limiting optional-stopping argument.

For a bounded stopping time $\tau\le K$, its absolute predictable expense is
\[
 \mathcal C_\tau(f;\nu)=
 \int_{\mathbb R^n}\mathbb E_x
 \sum_{k=0}^{\tau-1}|(e_{K-k}*f)(Z_{K-k})|\,dx.
 \tag{7}
\]
Lebesgue invariance gives
\[
 \mathcal C_\tau(f;\nu)\le\sum_{j=1}^K\|e_j*f\|_1
                 \le\sum_{j=1}^K\|e_j\|_{\rm TV}\|f\|_1.
 \tag{8}
\]
Integrating stopped (6) is legitimate: $H_\tau\le\sum_{k=0}^K H_k$, whose integral is $(K+1)\|f\|_1$, and (8) bounds the absolute compensator. It follows that the first-hit rule
\[
 \tau_\lambda=\min\big(\{k:H_k\ge\lambda\}\cup\{K\}\big)
\]
satisfies the genuine moving-chain endpoint
\[
 \lambda\int\Pr_x\{\max_{0\le k\le K}H_k\ge\lambda\}\,dx
 \le\|f\|_1+\mathcal C_{\tau_\lambda}(f;\nu).
 \tag{9}
\]
This endpoint observes moving $Z_j$. It has not been identified with $\sup_j B_{r_j}f(x)$ at a fixed receiver. No transport, multiplicity or Jacobian fee is silently discarded.

## 3. The natural stopped absolute expense is necessarily linear

The following is the quantitative failure theorem. For every $\eta>0$ there is a nonnegative unit-mass $f\in L^1$ such that, simultaneously for every choice of the probability transitions in (4),
\[
 \mathcal C_{\tau_{1/2}}(f;\nu)
   \ge\frac{17J}{72}-\eta
   \ge\frac{17n}{288}-\eta.
 \tag{10}
\]
Thus even input-dependent choices of convolution transitions, frozen before the path, cannot make this absolute payment root order for all inputs. The assertion concerns the payment (7), not the true signed stopped sum or the weak norm of any cube maximal operator.

First observe that for every unit-mass nonnegative input, at every preterminal step,
\[
 H_k\le r_{K-k}^{-n}\le q^{-n}\le\frac49<\frac12,
 \qquad k<K.
 \tag{11}
\]
Therefore the natural first-hit rule capped at the terminal step is exactly $\tau_{1/2}=K$ on every path, including paths that never hit the threshold. The equality case of (8) is then
\[
 \mathcal C_{\tau_{1/2}}(f;\nu)
                         =\sum_{j=1}^K\|e_j*f\|_1.
 \tag{12}
\]
This proves that stopping itself does not remove any of the absolute compensation expense in this test.

For each of the first $J$ transitions, (2)--(3) give
\[
 \|e_j\|_{\rm TV}\ge\frac{17}{72}.
 \tag{13}
\]
To pass from a kernel norm to an actual input uniformly in the transition choices, take any nonnegative unit-mass approximate identity $\phi_a$, with $a\downarrow0$. For the finite list of cube densities, $U_{r_j}*\phi_a\to U_{r_j}$ in $L^1$. Probability convolution is an $L^1$ contraction, so
\[
 \|e_j*\phi_a-e_j\|_1
 \le\|U_{r_j}*\phi_a-U_{r_j}\|_1
       +\|U_{r_{j-1}}*\phi_a-U_{r_{j-1}}\|_1.
 \tag{14}
\]
The right side is independent of $\nu_j$. Choose a single $a$ so that the sum of these finitely many right sides is less than $\eta$. Equations (12)--(14), with $f=\phi_a$, prove (10) uniformly over all positive transition choices, including choices made after seeing this $f$. The approximate identity is used as a generic $L^1$ norm test. It is not claimed to satisfy the original residual-event gates or to furnish a new maximal-operator lower construction.

For transitions fixed independently of the input, the same argument also gives the exact identity
\[
 \sup_{f\ge0,\,\|f\|_1=1}
       \mathcal C_{\tau_{1/2}}(f;\nu)
                     =\sum_{j=1}^K\|e_j\|_{\rm TV}.
 \tag{15}
\]
The upper bound is (8), and the common approximate identity attains the supremum in the limit. No interchange of infinitely many scales is used.

The grid is already sufficient for a fixed-receiver maximal comparison on the local interval: for $r\in[r_{j-1},r_j]$, positivity and cube containment give $B_rf\le(r_j/r)^nB_{r_j}f\le q^nB_{r_j}f$, and $q^n\le e$. Thus a successful fixed-receiver estimate on this grid would cover all $r\in[1,2]$ at constant cost. The missing transport from (9) to that fixed-receiver grid maximum remains a separate issue. Even before paying it, the absolute-compensator certificate has the linear obstruction (10). This does not say that a signed compensator estimate has the same cost.

## 4. Signed transitions have an explicit variation tradeoff

One might try to remove the positive shell deficit by allowing signed recentering. Let $\nu$ now be a finite signed measure of total mass one, and let $\beta=\nu^-(\mathbb R^n)$, so $\nu^+$ has mass $1+\beta$. Since every translated unit cube has shell mass between zero and $S_n(\epsilon)$,
\[
 (\nu*U_1)(E)\le(1+\beta)S_n(\epsilon).
\]
The residual still has total mass zero. Hence, with its half-variation denoted by $\delta$,
\[
 \delta+S_n(\epsilon)\beta\ge d_n(\epsilon).
 \tag{16}
\]
In particular, over the $J$ full steps at ratio $1+1/n$,
\[
 \sum_{j=1}^J\delta_j+\sum_{j=1}^J\beta_j
                                      \ge\frac{17J}{144}.
 \tag{17}
\]
Thus making all local residuals and all negative masses small simultaneously is impossible in this class. If each $\delta_j\le17/288$, then $\beta_j\ge17/288$, because $S_n\le1$, and
\[
 \|\nu_j\|_{\rm TV}=1+2\beta_j\ge\frac{161}{144}.
 \tag{18}
\]
The certificate obtained by multiplying the separate convolution-operator variation norms is therefore at least $(161/144)^J$. This is a statement about that multiplicative certificate, not a lower bound for the norm of the actual composed signed convolution: cancellation can reduce the latter. Signed measures are not transition probabilities for the chain (4); (16)--(18) only audit an alternative signed-kernel proposal.

## 5. Exact cube propagation is rigid, even without positivity

For completeness, a separate exact rigidity fact clarifies why one cannot simply impose zero local error. If $q>1$ and a finite signed measure satisfies
\[
 U_q=\nu*U_1,
 \tag{19}
\]
then $q$ is an integer. With Fourier convention $e^{-ix\cdot\xi}$, evaluate on the axis $\xi=2\pi e_1$. The transform of $U_1$ vanishes, while that of $U_q$ is $\operatorname{sinc}(\pi q)$. Thus $\sin(\pi q)=0$, proving the claim. No division by a zero Fourier multiplier is performed.

Conversely, if $q=m$ is a positive integer, the uniform measure on the $m^n$ grid translations with each coordinate in
\[
 \left\{k-\frac{m-1}{2}:\ k=0,\ldots,m-1\right\}
\]
convolves $U_1$ to $U_m$, by a tiling into unit cubes up to null faces. This measure is unique even among finite signed measures: away from the coordinate Fourier-zero hyperplanes, its transform is the forced quotient $\widehat U_m/\widehat U_1$; that set is dense, so continuity determines the transform everywhere, and uniqueness of the Fourier transform of finite measures finishes the argument. The latter uniqueness follows, for example, by convolution with Gaussian approximate identities and Fourier inversion, followed by weak convergence.

The obstruction does not require an a priori translation-covariance assumption. If a receiver-dependent finite signed recentering kernel gives the operator identity $B_qf(x)=\int B_1f(z)K(x,dz)$ for all bounded test functions at a fixed receiver, translating its row by $-x$ gives a measure satisfying (19), up to the harmless reflection dictated by the convolution convention. Hence the same integer restriction holds rowwise. This exact fact alone supplies no dimension-dependent weak estimate; the stronger quantitative content is (10) and its signed tradeoff.

## 6. Verification scope and the remaining payment

Both independent auditors inspected the exact shell statement and the strengthened stopped-chain statement before reading this proof. Their prechecks required the explicit restriction to convolution steps for the Lebesgue settlement, the reverse-increment sign, and the floor grid with a possible final endpoint step. Those corrections are built into the contract above. Receiver-dependent kernels retain only the rowwise statement (2); they are not silently included in the $L^1$ stopped theorem.

New three-stage exact checks were executed with Python's standard-library rational arithmetic. Shell checks directly intersect translated intervals, including clipping boundaries and the attaining corner; reflection and coordinate-permutation symmetry reduce the finite enumeration. Chain checks use actual Euclidean cube averages of a unit-mass small cube, nonsymmetric two-atom transition laws and complete path enumeration at each listed rational receiver. They verify the reverse sign, compensated stopped expectation, the moving-chain endpoint inequality, terminal stopping at $\lambda=1/2$, and genuine nonterminal hits after a transition at the additional threshold $(2^{-n}+q^{-n})/2$. A deliberately reversed sign gives discrepancies, so the test detects that convention error.

The stages increase shell resolution, dimensions, receiver count and source concentration. Scalar checks reconstruct $J$ using exact rational powers, verify the $17/144$ deficit, $4J\ge n$, the final shortened ratio, all preterminal caps and the signed-norm constant. They also verify the uniform approximate-identity error budget using $\|U_r*U_a-U_r\|_1\le na/r$, which follows by averaging cube translation differences for $|h_i|\le a/2$; the chosen $a=\eta/(4Kn)$ makes the sum of adjacent errors less than $\eta$ for every probability shift choice.

| Stage | Shell shift vectors | Constant dimensions | Rational receivers | Enumerated path nodes | Nonterminal stopped leaves | Half-threshold terminal leaves | Wrong-sign witnesses |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Pilot | 28 | 2–8 | 9 | 114 | 6 | 36 | 21 |
| Stress | 891 | 2–32 | 392 | 9,684 | 646 | 2,940 | 1,872 |
| Resolution | 24,454 | 2–128 | 2,793 | 151,992 | 3,923 | 41,356 | 22,594 |

All exact assertions passed. Shell grid denominators are 4, 8 and 16; source sides are 1/8, 1/32 and 1/128. The stress stage includes the edge case $\epsilon=1$. The final stage includes chain dimensions 2, 3 and 4. Counts include both stopping thresholds; early leaves count only the additional threshold and terminal leaves only $1/2$. These finite checks do not establish continuum Lebesgue invariance or universal quantifiers; those are proved above. They do not qualify any original Fnew event. The complete executable code and exact per-dimension receipt are in the private appendix of the companion Markdown file.

Both independent auditors subsequently read the complete proof and matching TeX and returned mathematical PASS with no further correction. Those full-proof receipts are separate from the author's executed finite checks.

The result isolates a precise failure of the proposed payment. Defining a legitimate positive Markov chain and compensating its drift is insufficient: at the natural capped hitting time, the termwise absolute predictable expense can already be at least $17n/288$ per unit source mass on one local scale interval. A successful continuation must control the stopped signed sum by a cancellation mechanism not bounded by (7), or change the state and observation structure with a proved fixed-receiver settlement. It must also pay the moving-to-fixed receiver transfer and then every all-scale and layer cost. No such root-order payment is proved here, and neither the R90 Gamma shortcut nor the R89 specified-family comparison is revived.

## S1. Exact new source and reading boundary

The requested Dai–Li–Yang–Yuan–Zhao paper is *Sharp weak-type estimate for local lifted Hardy–Littlewood maximal operators with applications to generators of linear operator families and Hardy(–Sobolev) spaces*, Advances in Mathematics 490 (2026), 110822, [DOI 10.1016/j.aim.2026.110822](https://doi.org/10.1016/j.aim.2026.110822). Publisher full and abstract fetches returned 403; the original 55-page proof was not read. Its author's [conference abstract](https://eventos-spm.pt/event/1/contributions/52/contribution.pdf) verifies topic and attribution, not theorem constants.

A readable author-primary companion is Yang–Yuan–Zhao, [arXiv:2607.08277v1](https://arxiv.org/pdf/2607.08277v1). We read the PDF definition and statements on pp.3–4, the positive-gamma decomposition/proof on pp.6–7, 11, 13–14, and their corresponding dependencies in the HTML §2.1–2.3. The served HTML carries a different internal final-version date from the v1 PDF; page claims refer to the 33-page v1 PDF, not an assumed identical later manuscript. Its Theorem 2.5 gives, for d>=2, gamma>0 or gamma<−d, and Omega in L(log L) of the sphere,

\[
 \sup_{\lambda>0}\lambda\iint_{\mathcal M^\Omega_1 f(x,t)>\lambda t^\gamma}
 t^{\gamma-1}\,dt\,dx\le C(d,\gamma)[1+|\Omega|_{L(\log L)}]\|f\|_1.
\]

Here the supremum uses BALL RADII r in [t,2t), and is taken before integrating the lifted level set. Constants depend on dimension and gamma. The companion quotes the requested paper's Theorems 2.3/2.6; that quotation is not our reading of its original proof. The positive-gamma proof uses a dyadic-parent mass factor 2^(d+gamma) and enlarged bad-cube volumes. We do not infer a dimension-free constant, a cube estimate, or a fixed-receiver trace from its title.

Our cost audit retains the geometric-sum denominator (1−2^(−gamma))^−1 and the height cutoff's O((j+1)/gamma) count. For standard Euclidean distance, the small-cube containment is safely Q subset B(x,(2+sqrt(d))t), using diameter sqrt(d)ell(Q); the printed B(x,3t) containment is not used. This repair preserves a fixed-d estimate, not uniform dimension control or a refutation of the theorem. The cube proof below uses exact sup-norm geometry instead.

## S2. A cube version with every dimension cost visible — own proof

Let m>=1 be an integer, k>0, g>=0 in L1(R^m), W=||g||1, and use full-side cubes
\[
 A_L^m g(z)=L^{-m}\int_{Q(z,L)}g(y)dy,\qquad
 \mathcal L g(z,t)=\sup_{t\le L<2t}A_L^m g(z).
\]
The following independently proved consequence uses the positive-gamma bad-cube idea, with corrected explicit cube geometry:
\[
 \lambda\iint_{\mathcal Lg(z,t)>\lambda t^k}t^{k-1}dt\,dz
 \le {24^m2^k\over k}W \quad(\lambda>0).                 \tag{S2}
\]
This is our conservative constant, not the printed ball constant or an optimal estimate. All scales t>0 are included.

Proof. Put D=m+k and eta=(2^D4^m)^−1. In one fixed half-open dyadic grid take the maximal cubes with
\[
 \int_Qg>\eta\lambda\ell(Q)^D.
\]
Large cubes are nonbad since their mass is at most W, so every bad cube has a maximal bad ancestor. At almost every Lebesgue point with g>0, sufficiently small cubes are bad because D>m. Thus the pairwise disjoint maximal family covers all g-mass up to a null set. Its parents are nonbad, hence
\[
 \eta\lambda\ell(Q)^D<\int_Qg\le 2^D\eta\lambda\ell(Q)^D. \tag{S2a}
\]
Let the exceptional tube be the union of
\[
 (Q+[-\ell(Q),\ell(Q)]^m)\times(0,\ell(Q)).
\]
Its weighted measure is at most
\[
 {3^m\over k}\sum_Q\ell(Q)^D\le {3^mW\over k\eta\lambda}.
\]
Outside this union, any Q intersecting Q(z,2t) must have ell(Q)<=t: otherwise z is within sup-norm distance t<ell(Q) of Q and lies in its tube. Every such Q is contained, up to harmless boundaries, in Q(z,4t). Disjointness gives
\[
 \sum_{Q\cap Q(z,2t)\ne\varnothing,\,\ell(Q)\le t}\ell(Q)^D
 \le t^k\sum_Q|Q|\le 4^m t^D.
\]
Since L<2t and L>=t, (S2a) bounds
\[
 A_Lg(z)\le t^{-m}\int_{Q(z,2t)}g
 \le 2^D\eta\lambda4^m t^k=\lambda t^k.
\]
Therefore the strict level set is contained in the exceptional union, proving (S2). All exchanges involve positive integrands. Half-open dyadic boundaries and L=2t endpoints have no effect; continuity of L↦A_Lg permits the stated supremum. When m=0, a single scalar mass W has the exact lifted constant 1/k instead, by integrating 1{W>lambda t^k}.

The factors 3^m (tube enlargement), 4^m (small-cube packing), and 2^(m+k) (parent mass) account for the entire displayed loss. This proof cannot supply C(1+m/k) by hiding them in an implicit constant. It also does not refute a sharper cube-lift theorem.

## S3. The exact codimension lifting interface — own proof

Let k>=1 be an integer and m>=0. The singular prototype is mu=delta_0^k tensor g(z)dz. This is not an original positive-L1 input; no gate inheritance is asserted. For receiver (u,z) in R^k times R^m,
\[
 A_L^{m+k}\mu(u,z)=L^{-k}1_{\{2\|u\|_\infty\le L\}}A_L^m g(z).
\]
Set
\[
 \mathcal T_k g(z,r)=\sup_{L\ge r}L^{-k}A_L^m g(z).
\]
Since |{u:2||u||_infty<=r}|=r^k, the exact normal-shell identity is
\[
 \lambda|\{M_{\rm cube}\mu>\lambda\}|=
 k\lambda\int_{\mathbb R^m}\int_0^\infty
 1_{\{\mathcal T_kg(z,r)>\lambda\}}r^{k-1}dr\,dz.         \tag{S3}
\]
Suppose one has the cube-lift upper estimate in (S2) with some constant C_(m,k). Then
\[
 \lambda|\{M_{\rm cube}\mu>\lambda\}|
 \le {kC_{m,k}\over1-2^{-k}}W.                          \tag{S3a}
\]
Indeed, a strict witness L>=r belongs to one of [2^j r,2^(j+1)r), j>=0. It implies
\[
 \mathcal Lg(z,2^jr)>\lambda(2^jr)^k.
\]
Apply a countable union bound in the positive integral and change t=2^j r. The jth contribution is at most 2^(−jk) C_(m,k)W/lambda. Sum the geometric series and multiply by k. Supremum measurability follows by rational-scale approximation for g in L1; no chosen witness has to be measurable. Infinite values cause no problem for the positive integral.

This quantifies the actual receiver fibre, rather than applying an L1 kernel envelope to a weak supremum. A theorem with
\[
 C_{m,k}\le C(1-2^{-k})(1+m/k)/k
\]
would pay the proposed global exact-plane branch. The primary theorem read above does not give this estimate. Our bound gives only 24^m2^k/(1−2^−k). Even a sharp singular-plane theorem would still need a positive-width approximation, common packet cover/captured share, unchanged actual gates, and payment of every recursive threshold and complementary branch. R90's local slab bound remains a separate retained result; this is no improvement of it.

For clarity on tracing in the other direction, any fixed-window family A_L, L∈[1,2], with a lifted positive-gamma upper C_gamma satisfies
\[
 \lambda|\{\sup_{1\le L\le2}A_Lg>\lambda\}|
 \le {2^\gamma\gamma\over1-2^{-\gamma}}C_\gamma W.        \tag{S3b}
\]
For each strict witness L, every t∈(L/2,L] contains it in [t,2t). On this interval t<=2, so the lifted threshold lambda2^(−gamma)t^gamma is at most lambda, and its t^(gamma−1) measure is at least (1−2^(−gamma))/gamma. Integrate this pointwise lower bound and apply the lifted estimate at lambda2^(−gamma). This works for the SAME family; replacing balls by cubes is a separate missing comparison. It is not a free graph trace.

## S4. E03 original theorem versus the actual compensated source tree

[Arcozzi–Holmes–Mozolyako–Volberg, arXiv:1809.03397v2](https://arxiv.org/pdf/1809.03397v2), Theorem 1.3 and Lemma 1.5, pp.3–9, were read, as was Theorem 2.1's stopping proof on pp.9–10. With nonnegative atomic tree measure lambda_I, Lambda(I)=sum_(J subset I)lambda_J, v_I=Lambda(I)/|I|, the hypothesis is the ALL-subtree Carleson test
\[
 |I|^{-1}\sum_{J\subset I}\alpha_Jv_J^2\le v_I.
\]
The L2 embedding constant is 4; its ancestor maximal version has constant 32 under the stated packing test. The proof uses
\[
 B(F,f,A,v)=4(F-f^2/(v+A)),\quad f^2\le Fv,\quad0\le A\le v,
\]
and coupled parent increments (b²,ab,c,a²) above child averages, with a,c>=0. Our use retains positive-denominator guards; no 0/0 convention is imported. These are quadratic tree embeddings, not a generic threshold-budget theorem.

The following is our exact bookkeeping audit. For a finite rooted tree with potentials P_v>=0 and local charges q_v<=P_v−sum_children P_w at internal nodes, and arbitrary weights t_v>=0,
\[
 \sum_{v\ {\rm internal}}t_vq_v\le
 t_oP_o+\sum_{v\ne o}(t_v-t_{\rm parent(v)})P_v
       -\sum_{v\ {\rm leaf}}t_vP_v.                    \tag{S4}
\]
The nonroot sum includes leaves. Expand both sums: every internal nonroot coefficient is t_v−t_parent, every leaf coefficient is −t_parent, exactly as on the left. Hence the displayed formula is immediate from the local inequalities. Nonnegative weights are necessary for multiplying them. For increasing thresholds, the switch terms are positive; nonnegative terminal potential cannot cancel them for free.

In the actual source chain W_child=rho_i W_i and t_i=beta^−i, 0<beta<1. For ell>=1,
\[
 \sum_{i=0}^{\ell-1}t_i(W_i-W_{i+1})+\beta t_\ell W_\ell
 =W_0+(1-\beta)\sum_{i=1}^{\ell-1}t_iW_i.              \tag{S4a}
\]
This follows by shifting the second finite sum. For ell=0 the terminal is W0 and is treated separately, not by (S4a). Source arrival mass decreases, while compensated mass obeys t_(i+1)W_(i+1)=(rho_i/beta)t_iW_i and can increase. If the additional ACTUAL hypothesis rho_i<=q beta holds at every continuing stage with q<1, then sum_i t_iW_i<=W0/(1−q), and the compensated terminal is at most q^ell W0. The retained q_i>K and annular inequalities do not prove that shrinkage. Nor do they provide E03's common dyadic state, coupled increments or all-subtree Carleson test. This identifies the exact budget missing from an E03 transfer; it is not a new failure example for physical inputs.

## S5. J05 original scope: a marginal projection is not stopped-path settlement

[Feinberg–Mandava–Shiryaev, arXiv:1603.02367v2](https://arxiv.org/pdf/1603.02367v2) was read on pp.2–14. Its Theorems 1–2, pp.6–7, use previous proofs/Jacod's construction; those external proofs were not independently read. For a measurable conservative Q-function on a standard Borel space (or after adjoining the absorbing cemetery state), local time integrability at each state gives the minimal backward transition. Local boundedness gives the forward equation on (q,s)-bounded sets; Theorems 3–4, pp.8–14, prove its equivalence with the positive last-jump integral equation. Regularity is needed for probability-preserving uniqueness. The integrals cannot be replaced by an undefined infinity-minus-infinity expression.

Our applicability inference is precise. A measurable conservative projected rate bounded by n on the finite scale-time interval satisfies both rate conditions and makes every set rate-bounded. A rate-n Poisson construction supplies nonexplosion. For the same initial probability law, a projected one-time density solving the forward integral equation has the Markov evolution's marginals: the forward signed-measure operator has total-variation norm at most 2n, so subtraction and Gronwall give uniqueness for that initial law. This does not identify the original hidden-source conditional path law or stopping law. One-time conditioning on X_t does not generally equal conditioning on the entire observed history. It also does not produce a generator common to all original sources, a reverse martingale, a frozen-coordinate compensator, or a fixed-receiver weak endpoint.

The alternative author's actual receiver projection and signed Duhamel remainder remain their responsibility. Coverage's actual mixed translation pairing retains off-diagonal row/source dependence; no source-to-vector Gram map or martingale map was supplied, so neither this theorem nor E03 is applied to that pairing. No blanket literature absence is claimed.

## S6. New three-stage exact check record and residual

All candidates were sent to both independent auditors before proof drafting. Both blind checks accepted (S2)–(S3a) and the weighted tree/chain identities, with the corrections that the nonroot tree sum includes leaves and ell=0 is separate.

The following NEW standard-library Fraction checks ran in this round, taking 0.009310 seconds and passing 767 exact assertions. They are finite algebra checks, not gate or capacity certificates.

1. Guarded local Bellman stress: child states (F,f,A,v)=(1,1/2,1/4,1) and (2,−1/2,1/2,2); parent equals their average plus (b²,ab,c,a²). Enumerate a∈{0,1/2,1}, b∈{−2,−1,0,1,2}, c∈{0,1/4,1/2,1}. All 60 parents satisfy the domain. Check f²<=Fv, positive denominator, and cf²/v²<=B_parent−average(B_children): 180 assertions.
2. Threshold stress: beta∈{1/4,1/2,3/4}, rho∈{0,1/4,1/2,3/4,1}, ell=1,...,6, W_i=rho^i, t_i=beta^−i. All 90 exact instances satisfy (S4a), including immediate source disappearance and zero exits. A separate assertion checks compensated growth at rho=3/4,beta=1/4 through depth3: 91 assertions. The empty-stage guard is stated, not hidden in this enumeration.
3. Increased depth/resolution: complete binary trees of depths1,...,4 and seeds0,...,63, node charge q_i=(7i+3seed) mod5, potential P_i=q_i+sum_children P_j, and weight t_i=[1+(seed+3i) mod11]/[1+i mod3], with heap indexing from0. All 256 exact telescoping checks pass. For k∈{1,2,4,8,16}, j=0,...,7, r∈{1/3,1,7/4}, t=2^jr, check r^k=2^(−jk)t^k and integral k r^(k−1)dr=r^k: 240 further exact coefficient checks. These last checks verify coefficients and shell volume, not a continuum level-set theorem; that theorem is proved in S3.

What remains is quantitative: a sharp C_(m,k) capable of paying actual concentration fibres, a common physical concentration cover with all capture/width fees, the threshold-weighted source tree budget, and the actual signed mixed-pairing/Duhamel settlement. The new source audit exposes these costs; it supplies no n-capacity gain and does not remove any original gate or paid-branch fee.

# Parent: the precise Mellin interface that cannot be transplanted

Status: elementary proved obstruction to one proposed analytic interface, **not** a counterexample to the desired weak bound. Public neutral input; no private lower-model recipe. Both auditors independently checked the statements before receiving this proof.

## Source and skill scope

The parent read the current F04 entry and its provenance, method and cube-interface files, and directly read the primary HTML of Spector–Stockdale, arXiv:2609.05377v1, Introduction, Section 2 and Section 3 through the main part of 3.4 (through displayed (3.17)). This is a selected-section reading, not a full-paper certification. The paper concerns Euclidean balls and the heat semigroup. Its Theorem 1.4 includes an absolute high-Mellin-frequency integral for a heat orbit after cap balayage. That estimate has no automatic cube analogue. Source: https://arxiv.org/html/2609.05377v1 . The following calculations and obstruction are independently proved here; no part of the paper's proof is reproduced.

## Exact obstruction

Fix integer n>=1. Write B_L nu(x)=L^{-n} nu(x+[-L/2,L/2]^n), for all L>0, and use Fourier transform in logarithmic scale v=log L with phase exp(-2 pi i xi v). At a receiver x!=0 put r=2||x||_infinity>0. For the unit atom at zero,

F_x(v)=B_{exp(v)} delta_0(x)=exp(-nv) 1_{v>=log r}.

Changing the value at the single endpoint does not affect any integral. F_x is integrable, and direct integration gives

Fhat_x(xi)=r^{-n-2 pi i xi}/(n+2 pi i xi).

Consequently every Lambda>0 satisfies

integral_{|xi|>Lambda}|Fhat_x(xi)| dxi=infinity.

More explicitly, for 0<=A<B,

I_n(A,B)=integral_{A<|xi|<B}|Fhat_x(xi)| dxi
=r^{-n}/pi [asinh(2 pi B/n)-asinh(2 pi A/n)].

If A>=n/(2pi), then I_n(A,B)>=r^{-n} log(B/A)/(pi sqrt(2)). This is an exact inequality, not an order inferred from experiments.

The obstruction survives subtraction of a cap density. Let mu have an L1 density, and suppose v -> B_exp(v) mu(x) is integrable. It is continuous: on any compact positive L interval this follows from absolute continuity of the Lebesgue integral over the symmetric differences of the nested cubes, together with continuity of L^{-n}. Its subtraction leaves a nonzero jump of size r^{-n} at log r. If the Fourier transform of this difference were integrable, Fourier inversion would give a continuous representative. On each side of log r, equality almost everywhere between continuous functions implies equality everywhere; their incompatible one-sided limits yield a contradiction. The Fourier transform is bounded since the orbit is L1, so each finite frequency band has finite absolute integral. Therefore the absolute integral outside every finite band diverges.

A sufficient integrability assumption is dist_infinity(x,supp mu)>0: the orbit vanishes at all sufficiently small L and is bounded by ||mu||_1 L^{-n} at large L. Thus the statement applies, in particular, to delta_0-kappa 1_Omega dx on any bounded positive-measure receiver set at positive distance from the bounded cap domain Omega containing zero. Tonelli then makes the space-frequency absolute high-tail integral infinite on that receiver set. No claim that arbitrary exterior boundary points have positive distance is needed.

## This is not cured by merely returning to positive L1 inputs

Let nu_epsilon be a nonnegative probability approximation to delta_0 supported in [-epsilon,epsilon]^n. At each fixed x!=0, for sufficiently small epsilon the logarithmic orbits have a common integrable bound, vanish below one fixed positive side length and converge at every L!=r to the atomic orbit. Dominated convergence gives convergence in L1(dv), hence uniform convergence of their Fourier transforms. The same holds after subtracting any fixed cap density satisfying the preceding integrability assumption. On every fixed finite frequency band, absolute Fourier integrals converge. Since the limiting high tail diverges, there can be no bound uniform in epsilon for the whole absolute high tail with any fixed finite cutoff, even when n is fixed. This statement concerns a strong Fourier budget, not the desired weak maximal bound. It does not assert that an arbitrary approximation preserves a particular obstacle problem; such preservation is unnecessary for the claimed interface obstruction.

There is also an explicit neutral positive-L1 check. Let nu_epsilon be uniform on [-epsilon,epsilon]^n, 0<epsilon<1/4, and x=(1/2,0,...,0). Its captured mass is zero for L<=a=1-2epsilon, equals (L-a)/(4epsilon) for a<L<b=1+2epsilon, and equals one for L>=b. Integration by parts gives, with z=n+2 pi i xi,

Fhat_epsilon(xi)=[b^{1-z}-a^{1-z}]/[4epsilon z(1-z)],

using its continuous value when 1-z=0. Also

||F_epsilon-F_0||_{L1(dv)} <= b_epsilon := (1-2epsilon)^{-n} log[(1+2epsilon)/(1-2epsilon)].

Indeed their difference is supported in [log a,log b] and has magnitude at most a^{-n}. Therefore on A<|xi|<B,

integral |Fhat_epsilon| >= I_n(A,B)-2(B-A)b_epsilon.

For fixed n and fixed A>=max(Lambda,n), choose B=epsilon^{-1/2}. The right-hand side diverges as epsilon tends to zero: its first term grows logarithmically and its error tends to zero. This is a quantitative proof of failure of a uniform strong high-frequency budget for positive L1 cube inputs. The input has no claimed original Fnew gate qualification.

## Three-stage verification and remaining route

The companion parent_mellin_probe.py runs three genuinely new finite diagnostic stages: small dimensions and low frequencies; hard-jump pressure using the displayed formulas and enlarging frequency bands; larger dimensions and thinner positive-L1 approximations. It compares the closed form with direct numerical quadrature of the explicit positive-L1 orbit and checks the analytic finite-band comparison. Cap-subtraction continuity is proved analytically above, not represented by a numerical cap experiment. The actual run passed 162 floating checks: 48 pilot, 54 jump-pressure, and 60 expanded checks, in 0.0372265 seconds. All nonrational transcendental computations are **floating diagnostics**, not interval certificates; the general proof above does not rely on their rounding. Runtime and actual case counts are recorded in parent_mellin_results.json. No private input and no previous-round test count is reused.

The heat-paper high-frequency interface therefore cannot be imported verbatim. A cube route must retain scale-jump geometry, use a different summability/maximal reconstruction, or establish a paid smoothing remainder. This calculation neither rules out the lower-frequency absorption mechanism in another valid setting nor pays the actual geometric remainder. The general root-order upper bound remains open.

本轮在不改变共同来源与阈值的条件下，先作有界确定性候选筛选，再认证新的正体积接收格。选择过程不是独立抽样；不报告接收概率、置信区间或高负载。一般非负 L1 输入的目标维数界仍未证明。

三阶段分别为 12 个候选的浮点初筛、3 个冻结候选的完整连续早期硬平均检查、同格尺度分辨率从 2^-20 提高至 2^-26 的检查。三个新格均有原始最早接触证书：较细版本合计 35 个无缝严格前缀区间，局部导数下界为正；包括后续捕获源盒查询在内，共 97 次尺度点计算。它们不是 R90 已付费格的重放。源及共同阈值均未变化。

三个新格均通过本轮同格账本中的原始全窗软上门、原始首触处粗门低分支、原中门及后验标量门。完整资格只在原固定参数 0<p<=n 的已证域内成立；n<p 和整个残余事件的补集仍未认证。极小正格不能替代完整 Fnew 的高负载或主割压力数据。

另有实际连续接收格的输运上下界，而非采样点图。若 B 的每个坐标独立变化于中心 c 的半宽 h 区间，原始接触边长位于 [l,u]，且 l>2h，则共同源盒 G− 的各坐标区间为 [c_i−l/2+h,c_i+l/2−h]，外包源盒 G+ 为 [c_i−u/2−h,c_i+u/2+h]。有 G− 包含于每个实际捕获立方体，实际捕获并集包含于 G+。正源质量给出

λ|B|/μ(G+) ≤ K(B) ≤ λ|B|/μ(G−).

上界由每行按同一实际 μ|G− 比例分配的连续可行耦合给出；下界是全 B 的源邻域割。原始规范列 b(y)=∫B L*(x)^−n 1_Q*(y) dx 的 μ-essential 上确界满足

|B|u^−n ≤ esssup b ≤ |B|l^−n.

三个新格的实际连续容量与原规范列都有这个双向包络；它们只测得极微小容量。所有量使用相同原始接触、来源和接收测度，实际体积完整保留；除以体积后的列密度不是高负载。此证书不计算所有主割，也不证明一般 Hall 容量界。

接收程序连同浮点筛选和三格证书耗时约 1.03 秒，结果可逐字节重放。浮点筛选、向外区间证明、实际连续输运见证及未知补集分别记录；没有由零命中或窄小数区间推断全局结论。

New positive-volume receiver cells of one fixed positive input were tested with a common threshold. Continuous original first-contact and whole-window smoothing certificates, together with the physical posterior bounds, qualify these cells in the explicitly stated range of the original packet exponent. The selection was deterministic, so this supplies no receiver probability or whole-residual estimate. The cells have very small volume and do not provide high-load or capacity evidence for the desired general root-order bound, which remains unproved.

R91 independent Astra audit: the general arbitrary-positive-L1 bound C_n <= sqrt(n) n^{o(1)} remains OPEN. Full mathematical MD and matching TeX reviews passed for coverage, adaptive, alternative, sources' own transfer arguments, and the parent Mellin note. Parent ledger and TeX introduction preserve every original gate, the one-time physical collision/entropy union fee, fixed packet exponent, all-scale localization, and any separate original-kappa layer cost. Primary reading receipts are attributed to their readers; author or Sol checks are not relabelled as this auditor's experiments.

- Coverage proves an actual four-incidence source-closure identity with a valid null-set argument, an exact involution and maximal cancelling subdensity, all-cut completion, and an opposing-receiver-demand bound. The cancelling density is an augmented measurement object, not a new physical source or transport flow. Principal flatness and adjacency do not supply an exchange cycle. The full common-source signed current remains unpaid at root order.
- Adaptive proves a finite actual coordinate-concentration profile, a common packet decomposition with explicit complexity, and an actual positive receiver fraction that can be paid and removed. The cost is non-root and preserves all threshold weights and repeated source occupation. The count of in-band stages is finite under the stated burden threshold; completed runs pay their terminal, while out-of-band exits retain it. The sourcewise weak-limit profile is stronger than an average atom count, but is not an original posterior share. Atomic equivalence is stated only for the unrestricted class of all finite atomic sources.
- Alternative constructs a legitimate finite reverse convolution chain with actual Lebesgue marginals and its full compensator. Its natural stopped termwise absolute expense has a linear-dimensional obstruction, even for input-dependent positive transitions frozen before paths. This is not a cube maximal weak lower bound, an obstruction to signed cancellation, or an unproved moving-to-fixed receiver identification. Signed variation products are certificate costs, not norms of the true composition.
- Sources give an explicit conservative cube-lift bound and exact codimension-fibre/trace fees, with ball and cube families separated. Weighted tree switch costs and terminal terms remain visible. Conservative bounded-rate marginal uniqueness does not identify hidden-source path or stopping laws. The Mellin note establishes a hard-scale high-frequency absolute-integrability obstruction, including nonuniform positive-L1 approximation; it does not refute the desired weak endpoint.
- New finite numerical qualification is real but local: three newly selected full-dimensional positive-volume cells of the same positive input and common threshold have certified earliest hard contact, strict later witness, original ALL-L smoothing upper gate and original-root coarse LOW gate. The fresh middle bound is independent of the packet exponent. Complete listed residual qualification is proved only for 0<p<=n; n<p and the unselected complement remain unknown. Their genuine continuum transport/canonical bounds retain the tiny receiver volume. There is no high-burden, principal-cut, whole-residual, asymptotic or general-capacity conclusion.

Independent nonwriting replay receipts: all three saved receiver/root and continuum source-coupling records matched exactly in 0.348680917 seconds; the full new soft-certificate replay matched exactly in 91.163548167 seconds after removing only its two timing fields. Grouped phase multiplicities retain the full dimension and independent-coordinate perturbation fees. Lower-resolution UNKNOWN results remain recorded. No deterministic candidate selection is described as iid sampling or a probability estimate.

The retained fresh-principal canonical-variance implication remains conditional: its all-input, all-positive-principal-cut hypothesis has not been established. Neither actual concentration progress nor the newly qualified tiny cells closes that hypothesis, the common signed-current payment, or the complete recursive/global ledger.

## R91 independent Sol audit — final PASS within stated scope

The general arbitrary-positive-L1 centered-cube sqrt(n)n^{o(1)} weak bound remains UNPROVED. Sol read the complete contract, independently checked all six precise statements before proofs, and full-read the matching coverage, adaptive, alternative, sources and neutral Mellin MD/TeX proofs. The final finite-stage-count/empty-residual and marginal-uniqueness deltas pass. Intro, complete ledger and TeX header preserve the original gates and expenses. Primary-source reading belongs to the source author or parent; Sol does not claim to have reread those papers.

Coverage's four-incidence identity is integrated-a.e under the original strict prefix closure. The invariant minimum density cancels exactly, but its remaining joint current and three opposing-row defects are unpaid. Completion is an all-cut reduction with the original selector; it does not inherit principal status or canonical variance bounds. The actual opposite-slab estimate is priced by the opposing lambda dx demand, which is not bounded by the current cut's source mass. Finite graphs are NONPHYSICAL logical pressure tests.

Adaptive's actual finite concentration profile, old-selector captured share and common tagged packets give a genuine paid receiver deletion. Packet count, all source occupation, rho/beta threshold compensation and complementary stages remain explicit. The complete specified band has a finite stage-count bound and a D0-priced budget; unfinished or out-of-band exits retain their terminal. Empty initial residual retains the already-paid event expense. This is not root-order payment. The atomic-source equivalence is unrestricted and does not erase actual-chain or original-gate conditions.

Alternative's positive convolution chain uses a genuine filtration and Lebesgue-preserving marginals. Its natural stopped absolute compensation can cost linearly in dimension, uniformly over transitions frozen from the input. Rowwise receiver-dependent kernels have no automatic column settlement. Signed-step norm products are only separate-norm certificates, not lower bounds for the composed operator. Neither these statements nor the Mellin jump/high-frequency obstruction is a cube weak-type lower bound; cross-step signed cancellation and different state geometry remain open.

The source proofs retain explicit lifted dimension factors, normal-shell and SAME-family trace costs, leaf-inclusive weighted-tree switch terms, and the separate empty-depth case. Conservative bounded-rate projection with the SAME initial probability law identifies one-time marginals only; it does not identify hidden-source stopping laws or settle fixed receivers. The retained original all-cut fresh canonical I_T hypothesis, all-scale C_loc log(n+2), original kappa-layer J_n where used, packet/physical union fees and every recursive terminal remain unproved or payable as stated.

Sol full-read the current numerical algorithms and reports, then independently replayed every new receiver JSON value in1.591391750 seconds with no exclusions, and every soft JSON value in88.047553042 seconds after removing only the two explicitly volatile runtime fields. Both exited0 with empty stderr. The three new full-dimensional positive-volume cells pass ORIGINAL continuous first-contact, whole-window and coarse/scalar gates only for the original parameter domain0<p<=n; n<p remains UNKNOWN and middle is independent of p. Deterministic selection is not iid sampling. Their actual continuous transport and canonical-column sandwiches retain the microscopic volume; no whole-residual probability, high-load, principal-cut or I_T conclusion follows.

The independent standard-library public guard imports no producer or private algorithm. It passed989 NEW exact finite assertions: coverage282, convolution/shell106, concentration/packet282, lifted/tree180, Mellin structures108, grouped full-dimensional sums27, and public binding4. Its three new stages contain319/327/339 mathematical checks. Models are generic/NONPHYSICAL and do not certify continuum gates or general capacity. No old-round or author-run count is added. The bound Mellin producer's162 checks remain FLOATING diagnostics.

A mock archive containing only the five intended public members and the unique extracted proof Python fence passed992 exact assertions in0.008832291 seconds internal /0.033977625 seconds wall, exit0/stderr0. The additional3 checks verify required public members, unique fence and byte-identical guard. Final guard SHA256: 3c9fda93d8f5b90dd2661e51522edb93584acca40e7f5ad9d5a8396511cd1e1f. Its frozen neutral code/result pair is bound by SHA256; no private input, recipe, parameter or program path is needed to replay it. The parent will separately record the actual assembled archive replay.

## 第91轮验证、复现与保留范围

所有通用数学命题均先做独立命题及反例检查，再审完整 Markdown 与相应 LaTeX 文本。作者的通过结论不作为独审依据。Astra 与 Sol 分别完成覆盖、实际有限集中轮廓、卷积补偿、文献接口和主代理 Mellin 推导的全文检查。作者的有限算术次数、独立审核程序次数和浮点诊断次数分开记录，不合并制造一个证明强度数字。

主代理在新临时目录复制冻结依赖后，实际执行以下重放；未在原目录覆盖作者结果：

- 新接收程序：1.703489458 秒；完整 JSON 相同，没有忽略字段。包含确定性浮点初筛、三个全维新单元的两级连续最早接触验证、35个最终严格前缀区间，以及真实内外来源盒质量和连续运输包络，共97次尺度点计算。不是概率抽样。
- 原软条件程序：91.761452250 秒；全部 JSON 在仅递归移除 `runtime_seconds` 和 `runtime_seconds_diagnostic` 后相同。原全窗口上门、原接触处粗平滑低门及同源同格标量账本保留。较粗频率试验的 UNKNOWN 状态未被重写。三个完整原条件资格仅在原包指数 `0<p<=n` 内成立，中间下限独立于 p，域外未知。
- 替代路线中性有理算术程序：12.551165875 秒；三个阶段的 JSON 全部相同，无排除字段。检查25373个平移壳向量及161790个实际方体路径节点，包含自然末端停止和额外阈值下的提前停止；这些是测试对象计数，不是断言数，也不以有限接收网格代替连续测度证明。
- 中性 Mellin 程序：0.056827375 秒；162项浮点诊断的全部非时间结果一致。48项初步、54项跳跃压力、60项扩大参数检查均为浮点诊断，不是区间证书。一般发散结论由独立解析证明给出。

四次执行均 exit0、stderr 为空；冻结的输入与代码字节在重放前后相同。两位审核者各自的实际重放范围见独审节，不能把读取保存结果与重新计算物理因子混写。公开独立程序的最终计数在后续归档重放收据中给出。

公开复现：将压缩包解至空目录，执行 `python3 parent_mellin_probe.py` 可重建中性浮点结果；将 `proof.md` 中唯一的 Python 代码块保存为 `audit_guard.py`，执行 `python3 audit_guard.py`。审核程序仅依赖标准库和本归档公开文件。若审核程序核对冻结结果哈希，应先运行它，再运行会重写时间字段的浮点程序，或将浮点程序放入另一个空目录执行。归档以原始冻结结果为准。

实际来源、接收配方及其计算代码仅在本地私人记录中复现；公開包没有这些内容，也没有新的未发表下界结论。其匿名资格记录不能作为整个余集的概率、质量、一般主割或高列方差界。代码重放成功不构成任意输入的证明。

当前安装的64个数学技能入口另做哈希快照，仅证明所用入口字节；实际读取的技能与原始论文范围分别列出。来源解析器的默认注册路径失效，本轮经明确指定现存完整包根目录后完成所需文件校验，未修改全局注册配置。SHA通过不能替代原文阅读或定理适用性检查。

LaTeX 只检查环境、花括号、标签引用和控制字符；不编译，不生成 PDF。完整有符号余项、退出已分析阶段带的费用、共同来源的重复占用以及一般全尺度回代仍未闭合。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""R91 independent exact finite guard; standard library, no author imports.

All finite models below are generic or NONPHYSICAL. Analytic proofs supply
continuum/null-set/limit assertions. The bound public producer's 162 checks
are FLOATING diagnostics and are never added to this guard's exact count.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import math
import re
import time

COUNTS = {}
STAGES = {}


def check(value, route, stage):
    assert value, (route, stage)
    COUNTS[route] = COUNTS.get(route, 0) + 1
    STAGES[stage] = STAGES.get(stage, 0) + 1


def prod(xs):
    answer = F(1)
    for x in xs:
        answer *= x
    return answer


def coverage(stage, dims):
    for n, L, v, sign in product(dims, [F(7,6), F(13,8)], [F(1,5), F(4,7)], [-1,1]):
        u = [F(j-2,11) for j in range(n)]
        b, a = L/2, (1-v/2)*L/2
        s = b-a
        rf, ra, ut = u.copy(), u.copy(), u.copy()
        rf[0] += sign*b
        ra[0] -= sign*a
        ut[0] += sign*s
        tf, ta = ut.copy(), ut.copy()
        tf[0] -= sign*b
        ta[0] += sign*a
        check(tf == ra and ta == rf, 'coverage', stage)
        check(ut[0]-sign*s == u[0], 'coverage', stage)
        check(all(abs(y[0]-x[0])<=L/2 for y in [u,ut] for x in [rf,ra]), 'coverage', stage)
        check(L-abs(rf[0]-ra[0]) == 2*(s/2), 'coverage', stage)
    # Different finite paired laws: exact maximal invariant minorant/current.
    for weights in [(2,7,5,1),(11,3,2,9),(1,19,13,4)]:
        g = list(map(F, weights)); T = [1,0,3,2]; H = [1,-1,-1,1]
        minor = [min(g[i],g[T[i]]) for i in range(4)]
        rho = [max(F(0),g[i]-g[T[i]]) for i in range(4)]
        current = sum(g[i]*H[i] for i in range(4))
        check(sum(minor[i]*H[i] for i in range(4))==0, 'coverage', stage)
        check(current==sum(rho[i]*H[i] for i in range(4)), 'coverage', stage)
        check(sum(rho)==sum(abs(g[i]-g[T[i]]) for i in range(4))/2, 'coverage', stage)
        check(all(minor[i]==minor[T[i]] and minor[i]<=g[i] for i in range(4)), 'coverage', stage)
    # Completion is a graph analogue only: positive columns, all original rows.
    for mask in range(1,17):
        edges = [{j for j in range(4) if (mask+3*i+5*j)%(i+3)!=0} for i in range(5)]
        A = {i for i in range(5) if (mask>>i)&1}
        S = set().union(*(edges[i] for i in A)) if A else set()
        C = {i for i,e in enumerate(edges) if e<=S}
        N = set().union(*(edges[i] for i in C)) if C else set()
        check(A<=C and N==S, 'coverage', stage)
    for mH,m0,K,k,z in [(F(7,3),F(5,2),F(9,2),F(1,2),F(1,3)),
                          (F(13,5),F(11,3),F(7),F(2),F(3,7))]:
        delta=(K*mH+z)**2/mH+(k*m0-z)**2/m0-K*K*mH-k*k*m0
        check(delta==2*(K-k)*z+(1/mH+1/m0)*z*z and delta>0, 'coverage', stage)


def overlap(z, radius):
    return max(F(0),min(z+F(1,2),radius/2)-max(z-F(1,2),-radius/2))


def alternative(stage, dims):
    for n in dims:
        eps=F(1,n); q=1+eps; S=1-(1-eps/2)**n
        d=(1-eps/2)**n-q**(-n)
        check(d>=F(17,144), 'alternative', stage)
        for zs in [(F(0),)*n, (eps/2,)*n, tuple(F((j%3)-1,3) for j in range(n))]:
            shell=prod(overlap(z,q) for z in zs)-prod(overlap(z,F(1)) for z in zs)
            check(shell<=S, 'alternative', stage)
        check(prod(overlap(eps/2,q) for _ in range(n))-prod(overlap(eps/2,F(1)) for _ in range(n))==S, 'alternative', stage)
        J=0; r=F(1)
        while r*q<=2:
            J+=1; r*=q
        check(r<=2<r*q and 4*J>=n, 'alternative', stage)
        check(q**(-n)<=F(4,9) and 2*d>=F(17,72), 'alternative', stage)
        beta=F(17,288)
        check(d-S*beta>=F(17,288) and 1+2*beta==F(161,144), 'alternative', stage)
    # Exact finite convolution process, separate from the Euclidean shell test.
    size=[5,7,11][stage]
    f=[F((3*j+2)%7+1) for j in range(size)]
    kernels=[[F(1,size)]*size,
             [F(2 if j==0 else 1,size+1) for j in range(size)],
             [F(3 if j==1 else 1,size+2) for j in range(size)]]
    shifts=[[(1,F(2,3)),(2,F(1,3))],[(0,F(1,4)),(3,F(3,4))]]
    H=[[sum(k[(x-y)%size]*f[y] for y in range(size)) for x in range(size)] for k in kernels]
    for j,nu in enumerate(shifts,1):
        error=[H[j][x]-sum(p*H[j-1][(x-v)%size] for v,p in nu) for x in range(size)]
        check(sum(error)==0, 'alternative', stage)
        for x in range(size):
            nxt=sum(p*H[j-1][(x-v)%size] for v,p in nu)
            check(nxt+error[x]==H[j][x], 'alternative', stage)
        # Lebesgue/counting marginal preservation pays absolute residual.
        check(sum(sum(p*abs(error[(x-v)%size]) for v,p in nu) for x in range(size))==sum(map(abs,error)), 'alternative', stage)


def adaptive(stage, dims):
    c=F(3,5); zeta=5*c/192; gamma=zeta/2
    for n,R,V,rho in product(dims,[F(2,3),F(5,4)],[F(3),F(7)],[c/4,3*c/4]):
        W=V/R; Wchild=rho*W; D=V
        check((5*R/48)*Wchild==5*rho*D/48>=zeta*D, 'adaptive', stage)
        check((R/rho)*zeta<=5*R/48, 'adaptive', stage)
        check(2*F(n)*V*(5*R/(96*n*V))==5*R/48, 'adaptive', stage)
        # Ch is symbolic: any positive Ch; ceiling strictness is exact.
        Ch=F(7,5); d=5*R/(48*Ch); k=math.ceil(d)
        check(F(k-1)<d<=k and (k-1)*Ch<5*R/48, 'adaptive', stage)
        check(5*R/12-3*(5*R/48)==5*R/48, 'adaptive', stage)
    for n in dims:
        w=F(8,n); cap=math.ceil(2/w)+2
        for left in [F(-11,7),F(0),F(13,9)]:
            # Enumerate half-open grid cells intersecting a closed side-two row.
            labels=[j for j in range(math.floor(left/w)-2,math.ceil((left+2)/w)+2)
                    if j*w<=left+2 and (j+1)*w>left]
            check(len(labels)<=cap, 'adaptive', stage)
        k=min(2,n); N=math.comb(n,k)*cap**k; a=gamma/(2*N)
        check(N*a==gamma/2, 'adaptive', stage)
        # Disjoint common tags, no replication, with each source's first k labels.
        tags={}
        for j in range(n+3):
            coords=tuple(sorted({j%n,(j+1)%n})[:k])
            tag=(coords,tuple((3*j+t)//4 for t in coords))
            tags.setdefault(tag,[]).append(j)
        check(sorted(v for values in tags.values() for v in values)==list(range(n+3)), 'adaptive', stage)
    # Receiver deletion lowers row demand, not rho/beta compensated source mass.
    beta=c/2; rho=3*c/4; W=F(1)
    check(rho/beta>1 and rho<1, 'adaptive', stage)
    mass=[W*rho**i for i in range(4)]; compensated=[mass[i]/beta**i for i in range(4)]
    check(all(compensated[i+1]>compensated[i] for i in range(3)), 'adaptive', stage)
    # Finite complete-band stage count/occupation: no arbitrary chain claimed.
    lam=F(7,3); Rmin=F(2,5); volumes=[F(3,2),F(1),F(2,3)]
    demands=[lam*v for v in volumes]; total=sum(demands)
    check(all(d>=lam*Rmin for d in demands) and len(demands)<=total/(lam*Rmin), 'adaptive', stage)
    check(sum(d/Rmin for d in demands)==total/Rmin, 'adaptive', stage)


def sources(stage, dims):
    for m,k in product(dims,[1,3,5]):
        eta=F(1,2**(m+k)*4**m)
        check(F(3**m,k)/eta==F(24**m*2**k,k), 'sources', stage)
        check(2**(m+k)*eta*4**m==1, 'sources', stage)
        for r in [F(2,7),F(5,3)]:
            t=2**(stage+2)*r
            check(r**k==F(1,2**((stage+2)*k))*t**k, 'sources', stage)
            window=(r**k-(r/2)**k)/k
            check(window==r**k*(1-F(1,2**k))/k, 'sources', stage)
    # Asymmetric finite tree, fresh potentials and weights, leaves included.
    for seed in range(1,8):
        parent=[None,0,0,1,1,2,3,3,5,8][:4+stage*3]
        length=len(parent); kids=[[] for _ in parent]
        for v in range(1,length): kids[parent[v]].append(v)
        charges=[F((seed+2*v)%5,7) for v in range(length)]
        P=[F(0)]*length
        for v in reversed(range(length)): P[v]=charges[v]+sum(P[w] for w in kids[v])
        t=[F(2+(seed+v)%7,1+v%4) for v in range(length)]
        lhs=sum(t[v]*charges[v] for v in range(length) if kids[v])
        rhs=t[0]*P[0]+sum((t[v]-t[parent[v]])*P[v] for v in range(1,length))-sum(t[v]*P[v] for v in range(length) if not kids[v])
        check(lhs==rhs, 'sources', stage)
    for beta,rho,ell in product([F(2,7),F(3,5)],[F(1,3),F(4,5)],range(1,stage+4)):
        W=[rho**i for i in range(ell+1)]; t=[beta**(-i) for i in range(ell+1)]
        check(sum(t[i]*(W[i]-W[i+1]) for i in range(ell))+beta*t[ell]*W[ell]==1+(1-beta)*sum(t[i]*W[i] for i in range(1,ell)), 'sources', stage)
    check(F(2,7)!=1, 'sources', stage)  # ell=0 cannot use beta-terminal identity.


def mellin(stage, dims):
    # Squared denominator bound for |xi|>=n/(2pi), taking safe pi>=3.
    for n,x in product(dims,[F(1),F(3),F(11)]):
        xi=n*x
        check(n*n+(6*xi)**2<=2*(6*xi)**2, 'mellin', stage)
        eps=F(1,2**(20+stage*8)); a=1-2*eps; b=1+2*eps
        # log(b/a)<= (b-a)/a by integral monotonicity; exact positive budget.
        upper=a**(-n)*(b-a)/a
        check(a>0 and upper>0 and b-a==4*eps, 'mellin', stage)
        B=2**(10+stage*4); A=F(n)
        check(2*(B-A)*upper>=0, 'mellin', stage)
        # Unit atom normalization, linear capture continuity, removable z=1.
        check((b-a)/(4*eps)==1 and (a+(b-a)/2-a)/(4*eps)==F(1,2), 'mellin', stage)


def grouped(stage):
    # Exact integer outward summation on independently varying coordinates.
    weights=[3+stage,11+2*stage]; n=sum(weights); scale=2**(8+stage)
    centers=[F(2,7),F(5,11)]; widths=[F(1,100),F(1,70)]
    lower=[math.floor((x-w)*scale) for x,w in zip(centers,widths)]
    upper=[math.ceil((x+w)*scale) for x,w in zip(centers,widths)]
    check(sum(F(v,scale)*w for v,w in zip(lower,weights))<=sum(x*w for x,w in zip(centers,weights))<=sum(F(v,scale)*w for v,w in zip(upper,weights)), 'grouped', stage)
    check(sum(weights)==n and sum(w*d for w,d in zip(weights,widths))>=min(widths)*n, 'grouped', stage)
    # Whole-cell common/outer cube widths and genuine row-demand sandwich.
    half=F(1,2**(8+stage)); lo=F(9,8); hi=F(19,16)
    for x in [-half,F(0),half]:
        check(x-lo/2<=-lo/2+half and lo/2-half<=x+lo/2, 'grouped', stage)
        check(-hi/2-half<=x-hi/2 and x+hi/2<=hi/2+half, 'grouped', stage)
    inner,outer=(lo-2*half)**n,(hi+2*half)**n
    check(0<inner<=outer and F(2)/outer<=F(2)/inner, 'grouped', stage)


PUBLIC_HASHES = {
    'parent_mellin_probe.py':'d549858222cd87aeaad96d296ae811b621230205533e956d8109b8a4e73c14cf',
    'parent_mellin_results.json':'c018d34280bd29ef984a1ceacae88b3f98ad4fc8b0d1d52cab43ccc44e792c99',
}


def portable(root):
    if (root/'proof.md').exists():
        check(all((root/name).is_file() for name in
                  ['proof.tex.txt','parent_mellin_probe.py','parent_mellin_results.json','inventory.json']),
              'portability', 3)
    for name, expected in PUBLIC_HASHES.items():
        if (root/name).exists():
            check(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, 'public_binding', 3)
    if (root/'parent_mellin_results.json').exists():
        data=json.loads((root/'parent_mellin_results.json').read_text())
        check(data['status']=='PASS' and data['evidence']=='floating diagnostics; not interval certificates', 'public_binding', 3)
        check(data['checks']==162==sum(data['counts'].values()), 'public_binding', 3)
    if (root/'proof.md').exists():
        source=(root/'proof.md').read_text()
        fences=re.findall(r'^```python\s*\n(.*?)^```\s*$',source,re.M|re.S)
        check(len(fences)==1, 'portability', 3)
        check(fences[0].strip()==Path(__file__).read_text().strip(), 'portability', 3)


def main():
    started=time.perf_counter()
    for stage,dims in enumerate([[2,5],[9,17],[33,65]]):
        coverage(stage,dims)
        alternative(stage,dims)
        adaptive(stage,dims)
        sources(stage,[stage+1,stage+3])
        mellin(stage,[1,3,9])
        grouped(stage)
    portable(Path(__file__).resolve().parent)
    print(json.dumps({'status':'PASS','assertions':sum(COUNTS.values()),
                      'route_counts':COUNTS,'stage_counts':STAGES,
                      'scope':'NEW exact generic finite algebra; no physical gate, high-load or full principal certificate',
                      'bound_producer_checks':'162 FLOATING diagnostics, excluded from exact count',
                      'runtime_seconds':time.perf_counter()-started},sort_keys=True))


if __name__=='__main__':
    main()
```
