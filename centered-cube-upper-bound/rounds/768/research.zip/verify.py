"""R768 exact 1D price-rank interface and Arb exponential-cut certificates."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(c,r):
    return c-r,c+r


def meet(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def length(I):
    return max(Q(0),I[1]-I[0])


def contains(I,x):
    return I[0]<=x<=I[1]


def absolute_band(r):
    j = r.numerator.bit_length()-r.denominator.bit_length()
    return j if Q(2)**j<=r else j-1


def build(phase):
    base = [(Q(0),Q(1)),(Q(-1,2),Q(1,8)),(Q(-1,4),Q(1,2)),
            (Q(1,4),Q(1,2)),(Q(1),Q(2))]
    if phase=="pressure":
        parents = [(Q(-5),Q(1)),(Q(-4),Q(1)),(Q(0),Q(1,2)),(Q(1),Q(1))]
        p0 = Q(27253179303401,10**14)
        p1 = Q(27253179303402,10**14)
        density = [((Q(-7),Q(3)),Q(1)),((Q(-6),Q(-5)),1/p0-2),
                   ((Q(-4),Q(-3)),1/p1-2),((Q(1),Q(3,2)),Q(1))]
        return parents,density,Q(13,10),("full","atom_boundary","gated")
    parents = base
    density = [((Q(-6),Q(6)),Q(1)),((Q(-3,4),Q(-1,4)),Q(2)),((Q(1,8),Q(3,4)),Q(3))]
    batches = ("full","gated")
    if phase=="expanded":
        parents += [(Q(3,8),Q(1,16)),(Q(-3,4),Q(1,4)),(Q(2),Q(3)),(Q(-1,8),Q(1,4))]
        density.append(((Q(1,4),Q(1,2)),Q(2)))
        batches += ("reordered_gate",)
    return parents,density,Q(3),batches


def price_experiment(phase):
    parents,density,c,batches = build(phase)
    delta,tau,L = Q(1,4),Q(1,12),Q(1,64)
    assert 0<tau<Q(1,4) and all(w>0 for P,w in density)
    A = [interval(y,r) for y,r in parents]
    E = [interval(y,r/32) for y,r in parents]
    s = [r for y,r in parents]
    v = list(map(length,E))
    assert all(w>0 for w in v)
    assert all(length(meet(I,J))==0 for I,J in combinations(E,2))

    def mu(I):
        return sum(d*length(meet(I,P)) for P,d in density)

    m = list(map(mu,A))
    assert all(mi>=length(I) for mi,I in zip(m,A))
    a = [vi/mi for vi,mi in zip(v,m)]
    J = range(len(A))
    order = sorted(J,key=lambda i:(s[i],i))
    bands_index = [absolute_band(s[j]) for j in J]
    neighborhood = -absolute_band(delta)
    assert 0<Q(2)**(-neighborhood)<=delta
    V_b = {k:sum(v[j] for j in J if bands_index[j]==k) for k in sorted(set(bands_index))}
    assert sum(V_b.values())==sum(v)
    band_gate_cut = (-ball(c/2)).exp()
    ranks = {j:r for r,j in enumerate(order)}
    intersections = {(i,j):mu(meet(A[i],A[j])) for i,j in product(J,repeat=2)}

    def threshold(probe,other):
        scale = max(delta,min(Q(1),probe/s[other]))
        return (-ball(c*scale)).exp()

    @lru_cache(None)
    def decide(t,u,probe):
        target = (threshold(probe,u),threshold(probe,t))
        actual = (intersections[t,u]/m[t],intersections[t,u]/m[u])
        margins = [ball(p)-q for p,q in zip(actual,target)]
        assert all(w>0 or w<0 for w in margins)
        return tuple(w>0 for w in margins),tuple(margins)

    def gate(mode,x,j):
        if mode=="full":
            return Q(1)
        if mode=="atom_boundary":
            return tau*a[3]/((1-tau)*a[2]) if j==2 else Q(1)
        if mode=="gated":
            return Q((j+2)%4+1,4) if x<0 else Q((2*j+1)%5,4)
        return Q((3*j+1)%5,4) if x<Q(1,2) else Q((j+3)%4+1,4)

    pieces = sorted({Q(0),Q(1,2)}|{x for I in A for x in I}|{x for P,w in density for x in P})
    cells = [(p,q,mu((p,q))) for p,q in zip(pieces,pieces[1:]) if mu((p,q))>0]
    result = []
    for mode in batches:
        totals = defaultdict(Q)
        n_atoms = n_boundary = n_window_split = n_repeated = n_equal_delta = 0
        min_exp_gap = None
        actual_gate_ledger = [Q(0)]*len(A)
        E_b = defaultdict(Q)
        neighbor_energy = Q(0)
        bin_quantile_tests = bin_threshold_tests = 0
        for lo,hi,mass in cells:
            x = (lo+hi)/2
            b = [a[j]*gate(mode,x,j) if contains(A[j],x) else Q(0) for j in J]
            assert all(0<=w<=cap for w,cap in zip(b,a))
            for j,w in enumerate(b):
                actual_gate_ledger[j] += mass*w
            B = sum(b)
            if not B:
                continue
            n_atoms += 1
            active = [i for i in order if b[i]>0]
            groups = {g:[i for i in active if bands_index[i]==g] for g in V_b}
            by_band = {g:sum(b[i] for i in ids) for g,ids in groups.items()}
            for g,ids in groups.items():
                if not ids:
                    continue
                B_band = by_band[g]
                E_b[g] += mass*B_band**2
                prefix = Q(0)
                for tick in ids:
                    prefix += b[tick]
                    if prefix>=tau*B_band:
                        break
                q_band = s[tick]
                assert Q(2)**g <= q_band < Q(2)**(g+1)
                bin_quantile_tests+=1
                for t,u in product(ids,repeat=2):
                    assert min(s[t],s[u])/max(s[t],s[u])>Q(1,2)>=delta
                    assert min(q_band/s[t],q_band/s[u])>Q(1,2)
                    sides = decide(t,u,q_band)[0]
                    for i,pass_cut in zip((t,u),sides):
                        if ball(intersections[t,u]/m[i])>band_gate_cut:
                            assert pass_cut
                            bin_threshold_tests+=1
            neighbor_energy += mass*sum(by_band[g]*by_band[k] for g,k in product(V_b,repeat=2)
                                        if abs(g-k)<=neighborhood)
            p = {i:b[i]/B for i in active}
            left = Q(0)
            bands = {}
            for i in active:
                bands[i] = (left,left+p[i])
                left += p[i]
            assert left==1
            quantile = next(i for i in active if bands[i][1]>=tau)
            if any(hi==tau for lo,hi in bands.values()):
                n_boundary += 1
            q_tau = s[quantile]
            high = {j:length(meet(bands[j],(2*tau,Q(1)))) for j in active}
            middle = {j:length(meet(bands[j],(tau,2*tau))) for j in active}
            assert sum(high.values())==1-2*tau and sum(middle.values())==tau
            n_window_split += sum(0<w<p[j] for j,w in middle.items())
            measure = mass*B*B
            totals["E"] += measure
            D = {}
            for t,u in product(active,repeat=2):
                hits,margins = decide(t,u,q_tau)
                D[t,u] = any(hits)
                local_min = min(abs(w) for w in margins)
                min_exp_gap = local_min if min_exp_gap is None else min(min_exp_gap,local_min)
                if D[t,u]:
                    totals["E_D"]+=measure*p[t]*p[u]
                    totals["E_D_high_ranks"]+=measure*high[t]*high[u]
                ratio = min(s[t],s[u])/max(s[t],s[u])
                if ratio<delta:
                    totals["E_far"]+=measure*p[t]*p[u]
                else:
                    assert abs(bands_index[t]-bands_index[u])<=neighborhood
                if ratio==delta:
                    totals["E_scale_at_exact_delta"]+=measure*p[t]*p[u]

            allowed = {k:[j for j in active if ranks[k]<=ranks[j] and s[k]/s[j]>=delta] for k in active}
            U = {k:sum(b[j] for j in group) for k,group in allowed.items()}
            assert all(0<w<=B for w in U.values())
            for k,w in U.items():
                nu_sum = sum(b[j]/w for j in allowed[k])
                assert nu_sum==1
                totals["dominating_row_total"]+=mass*b[k]*w
                totals["dominating_row_high_tail"]+=mass*b[k]*max(Q(0),w-L)

            # Independent actual three slots recover all three original pair marginals.
            margins = [defaultdict(Q) for _ in range(3)]
            cell_probe = good_probe = bad_probe = Q(0)
            cell_legals = cell_dom = Q(0)
            for k,t,u in product(active,repeat=3):
                raw = measure*p[k]*p[t]*p[u]
                for ledger,edge in zip(margins,((k,t),(k,u),(t,u))):
                    ledger[edge] += raw
                legal = t in allowed[k] and u in allowed[k]
                if legal:
                    upper = mass*b[k]*U[k]*(b[t]/U[k])*(b[u]/U[k])
                    assert raw<=upper
                    cell_legals += raw
                    cell_dom += upper
                    if k==t==u:
                        n_repeated+=1
                    if s[k]/s[t]==delta or s[k]/s[u]==delta:
                        n_equal_delta += 1
                    # Independent continuous ties give order probability 1/2 or 1/3.
                    tie_count = sum(j==k for j in (t,u))
                    totals["raw_legal_if_continuous_k_min"]+=raw/(1+tie_count)
                    large = any(decide(t,u,s[k])[0])
                    if large:
                        totals["E_large_legal_raw"]+=raw
                        totals["E_large_legal_dom"]+=upper
                        totals["E_large_legal_dom_tail"]+=upper*max(Q(0),1-L/U[k])
                probe = measure*middle[k]*high[t]*high[u]
                if probe and D[t,u]:
                    assert ranks[k]<=min(ranks[t],ranks[u]) and s[k]>=q_tau
                    cell_probe+=probe
                    if legal:
                        assert any(decide(t,u,s[k])[0])
                        good_probe+=probe
                    else:
                        assert s[k]/s[t]<delta or s[k]/s[u]<delta
                        bad_probe+=probe
            assert cell_legals<=cell_dom==mass*sum(b[k]*U[k] for k in active)
            assert cell_probe==tau*measure*sum(high[t]*high[u] for t,u in product(active,repeat=2)
                                              if D[t,u])==good_probe+bad_probe
            totals["raw_legal"]+=cell_legals
            totals["probe_large"]+=good_probe
            totals["probe_far_union"]+=bad_probe
            assert all(M[i,j]==mass*b[i]*b[j] for i,j in product(active,repeat=2) for M in margins)
        x = totals
        assert all(w<=vi for w,vi in zip(actual_gate_ledger,v))
        lopping = x["dominating_row_total"]-x["dominating_row_high_tail"]
        assert 0<lopping<=L*sum(actual_gate_ledger)<=L*sum(v)
        assert 0<x["dominating_row_high_tail"]
        assert x["raw_legal_if_continuous_k_min"]<x["raw_legal"]<=x["dominating_row_total"]
        assert x["probe_large"]<=x["E_large_legal_raw"]<=x["E_large_legal_dom"]
        assert x["E_large_legal_dom"]-x["E_large_legal_dom_tail"]<=lopping
        assert x["probe_far_union"]<=2*x["E_far"]
        assert tau*x["E_D_high_ranks"]==x["probe_large"]+x["probe_far_union"]
        assert x["E_D"]-x["E_D_high_ranks"]<=(1-(1-2*tau)**2)*x["E"]<=4*tau*x["E"]
        upper = 4*tau*x["E"]+(x["E_large_legal_raw"]+2*x["E_far"])/tau
        assert x["E_D"]<=upper
        if mode=="atom_boundary":
            assert n_boundary>0
        E_same = sum(E_b.values())
        E_cross = x["E"]-E_same
        assert 0<E_same<=x["E"] and bin_threshold_tests>0
        assert x["E"]-x["E_far"]<=neighbor_energy<=(2*neighborhood+1)*E_same
        if mode=="full":
            assert E_cross>0
        result.append({
            "gate_batch":mode,"priced_active_cells":n_atoms,"ranks_with_tau_exactly_at_cut":n_boundary,
            "partial_tau_window_hits":n_window_split,"repeated_legal_triples":n_repeated,
            "legal_triples_at_delta":n_equal_delta,"min_certified_exp_test_gap":min_exp_gap.str(15),
            "true_integral_b":list(map(str,actual_gate_ledger)),
            "masses":{k:str(w) for k,w in sorted(x.items())},
            "exact_D_bound_raw_legal":str(upper),"lopping_loss":str(lopping),"lopping_bound_L_sum_v":str(L*sum(v)),
            "absolute_radius_bands": {
                "E_by_band":{str(band):str(E_b[band]) for band in V_b},
                "same_band_E":str(E_same),"different_band_E":str(E_cross),
                "neighbor_energy":str(neighbor_energy),"E_far_plus_band_bound":str(x["E_far"]+(2*neighborhood+1)*E_same),
                "per_band_quantile_checks":bin_quantile_tests,
                "within_band_large_threshold_checks":bin_threshold_tests,
            },
        })

    special = {}
    if phase=="pressure":
        forward,margins = decide(0,1,Q(1))
        assert forward==(False,True)
        ordinary,gaps = decide(2,3,Q(1,2))
        swapped = (ball(intersections[2,3]/m[3])>threshold(Q(1,2),3),
                   ball(intersections[2,3]/m[2])>threshold(Q(1,2),2))
        assert ordinary==(False,False) and swapped==(False,True)
        special = {"close_equal_radius_two_margins":[x.str(18) for x in margins],
                   "true_small_big_gate":list(ordinary),"swapping_original_denominators":list(swapped)}
    if phase in ("initial","expanded"):
        assert Q(result[0]["masses"]["E_far"])>0 and Q(result[0]["masses"]["probe_far_union"])>0
        assert Q(result[0]["masses"]["E_scale_at_exact_delta"])>0
    return {
        "phase":phase,"parent_center_and_radius":[[str(x),str(r)] for x,r in parents],
        "price_intervals_and_density":[[list(map(str,I)),str(w)] for I,w in density],
        "m":list(map(str,m)),"v":list(map(str,v)),"order_s_and_label":order,
        "delta":str(delta),"tau":str(tau),"c":str(c),"L_test":str(L),"num_certified_direction_calls":2*decide.cache_info().currsize,
        "decision_pressure":special,"gate_runs":result,
        "absolute_band_J":neighborhood,"V_b_actual_owners":{str(k):str(w) for k,w in V_b.items()},
        "within_band_sufficient_threshold":band_gate_cut.str(17),
    }


def report():
    return {
        "scope":(
            "Three finite 1D AC priced families, disjoint closed shrink-core owners, and displayed original root gates. "
            "All geometric mass and continuous rank intervals are rational; exponential signs are certified at 256-bit Arb. "
            "The diagnostic L and c are finite parameters."
        ),
        "python":python_version(),"python_flint":flint_version,"arb_bits":ctx.prec,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "experiments":[price_experiment(name) for name in ("initial","pressure","expanded")],
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    r = report()
    data = (json.dumps(r,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for experiment in r["experiments"]:
        print(f"{experiment['phase']}: {len(experiment['v'])} parents, {len(experiment['gate_runs'])} gates, "
              f"{experiment['num_certified_direction_calls']} certified exponential tests")


if __name__=="__main__":
    main()

