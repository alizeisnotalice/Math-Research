# R193 独立审计

本文件仅由独审维护。范围：原 row 的有序部分耦合与同一来源 cut 容量；尚不认证一般中间层交通闭合。以下 §1–3 在阅读本轮作者证明之前形成；已读共同 task_contract.md 与作者准确命题消息，未以作者结论为证。

## 1. 紧空间有序部分耦合：独立证明检查点

令 X={0≤b1≤…≤bn≤T}，τ、σ为有限正 Borel 测度，c≥0 有限。关系为 supply z≥target v（逐坐标）。存在正测度 π，target 边缘=cτ、supply 边缘≤σ、支撑于该闭关系，当且仅当对每个相对 X 的 Borel upper set U 有 σ(U)≥cτ(U)。方向正确：target 位于 upper U 的质量只能由 U 内的 supply 提供。

充分性的自含路线可行。T>0 时共同 dyadic 向下舍入 q_m 保持排序与坐标序；有限格 upper set 的原像仍为 Borel upper set。任意有限 target 子集 A 的邻居为 ↑A，故 Hall 容量条件由 cτ(A)≤cτ(↑A)≤σ(↑A) 得到。有限部分匹配允许 supply 剩余。将每条格边的质量按原盒内条件测度提升（零质量盒先隔离），得到 target 恰为 cτ、supply≤σ，且 z_i≥v_i−δ_m。X² 紧，固定总质量的弱极限保持两边缘条件；闭序关系由任意正间隔的违序开集或连续距离检验排除。不得声称每个有限提升已满足精确序。

c=0 或 τ=0 取 π=0；τ=0 的物理 target 行本身为零。σ=0、τ≠0 时 U=X 强制 c=0。T=0 为单点标量条件，须单列，不能除以 T。τ(X)>0 时 X cut 给 c≤σ(X)/τ(X)，故有限最优参数有界。

可测性不要求为原 receiver 选择 π。全部 dyadic 格 upper cuts 构成一个可数且充分的检验族，理由是它们已足以运行上述充分性证明。c*=inf_{τ(U)>0} σ(U)/τ(U) 可由该族定义；测度核给出可测标量。变动 T>0 的行可先归一至共同 [0,1] 排序空间，T=0 另账。若作者使用这个可数族，不得将任意 Borel upper set 的不可数 inf 直接称可测。

原 w_t/w_ell 在排序阈值 b 上等于 exp(−Σ(r−b_i)+)，为 b 的坐标递增函数。因此上述存在性只证明 G_N(t)≥cG_A(t)，不重排原 Π、来源、删除或交通。后续沿用 R192 同一完整 target、同一 e_t 的逐 u FTC。cut 条件本身仍须由实际来源几何支付。

## 2. target 分片候选：独立检查点

保持原 χ、A、α不变，A=A_m+A_d 可依固定 bad u，但各分片须沿积分 t 固定。若 neutral 只对 A_m 的 well 加权测度有 c 倍有序部分耦合，则逐 u 原正交通上界为 well(u)/e 乘 min{ψ_A,2/(1+c)+ψ_d}，ψ_d=D_d/(e+D_d)。这是先线性拆实际 target 积分，再分别使用匹配分母界及 e_t≥e+z_d，最后与完整 A 的既有 ψ_A 界取 min；不得将 χ−A_mν 偷换为新 neutral。

τ_d=well A_dν 时 D_d=∫(1−e^(−Ω))dτ_d，Ω=Σ(T−b_i)。原 Ω≤r target 子片满足 D_d/e≤(e^r−1)G_A(g)/e≤(e^r−1)/6，故真实正 J-share 接收费≤C_rec(e^r−1)/6∫q，C_rec=16Λ/(3Kκ)。r=log(1+6ε/C_rec) 给 ε 价。此价可能与历史低放大分支重叠，不证明严格新增 FULL 覆盖。

若只点态存在某个 target 分片，却要将其实际 ψ_d 保留在 λ 积分中，须给可测分片或可测标量包络；只证明统一 row 常数时不必选择可测 π。M_m=0 的匹配部分先取零交通，不能除零。

## 3. 作者准确 cut 候选的独立筛查（尚未全文后审）

**保护 target 的 neutral 下界。** 写 θ=Aν，θ≤χ≤Λ≤μ_hi，R=αQJ，R0=∫k(μ_hi−Λ)，B=R−R0≥0，η=Λ−θ，N=χ−θ。实际 N 满足 0≤N≤η 且 ∫k(η−N)≤B。任意 C=P_u∩B_born∩b^{-1}(U) 有

L_η(C)=sup_{a≥0}{∫_C min(well,ak)dη−aB}≤∫_C well dN=σ(U)。

每个 a 的弱界直接由同一实际 N 得到。相对旧 CG 下界减 target 后的同 a 差为 aR0−∫_C min(well,ak)d(μ_hi−Λ)+∫_C(well−min(well,ak))dθ≥0，故确有改进。若写连续单 cut 的精确 knapsack，须处理 k=0 免费删除、B 足以删尽时值零、B=0 时 supremum 可能只在极限达到。所有 cut 可使用不同检验系数 a_U，却须使用同一个 c；不得逐 cut 更换实际 N 或来源。有限 target 支撑时仅检验 target-generated 上集 ↑S 足够，因 target 质量保持且 L_η 单调。此有限结论本身不是连续量化极限证明。

**parent 最坏阈值几何。** r_i 为固定 y 到 P_u 第 i 坐标两 face 的最大距离，b^P=sort clip(log(C(r_i/b)/ξ_ell),0,T)。每个 z∈P_u 的排序阈值≥b^P。upper U 若含 b^P，parent 内 neutral 全在 U，供给可由 [L_P−M_A(P)]_+ 下界；若不含 b^P，U 内 target 至少一个排序坐标 b_i(v)>b_i^P。b_i^P<T 时这强制至少 n−i+1 个原坐标 C_l(v)>ξ_ell exp(b_i^P)。

原 tiny target 每坐标 log_+(ξ_g/C_l)≤M_n，因此该 inversion 与 wg<δ 同时成立须满足 log(1/δ)<(i−1)M_n+(n−i+1)(T−b_i^P)。b_i^P=T 时 inversion 不可能。若全部 index 排除，只对所限 tiny target 分片得到完整 order；不自动控制原整体 A，也未支付剩余实际面/位移质量。

## 4. 当前状态

§1 的抽象定理及 §2–3 的准确接口独筛可用。等待作者全文与整合稿，尚无本轮一般交通上界或 FULL 认证。原 dx、window/source/j 重用及 cut 失败的实际费用须在全文后审保留。


## 5. 主稿全文后审与有限数值静态审

已实读 compact_transport_geometry.md 全文。共同舍入的 c_m 单调递减，因为 q_m∘q_{m+1}=q_m；每个精确有序耦合都投影可行，反向用最优格匹配及弱极限得 lim c_m=c*。finite Hall、partial supply、零盒提升、变 T 的归一、无可测 π 选择及原 C_rec 回代均通过。已建议将“disjoint in the measure sense”改为 χ 的正互补子测度（它们不必互相奇异），并明示 λ 含原唯一 j 指示；这不改变公式。

额外候选独筛：若同原输入的 full-current slack S0=Dq−∫kμ_hi≥0 已知，可用精确预算 B=R−R0−S0=∫k(Λ−χ)≥0，且 B≤∫kη；较旧预算同 a 增加 aS0。不得换用不同 kernel 的 slack。保守 continuous 有限证书可用互斥 Borel supply/target cells，仅在逐坐标 inf(supply cell)≥sup(target cell) 时连接；全部 target-subset cuts 成立后在实际 supply cell 质量上求一份 flow，再条件测度提升得真正有序耦合。这只是内关系充分证书，不声称随 mesh 自动收敛。

已静态读 ordered_transport_checks.py 与 numerical_review.md。15 个有限模型的 Fraction 邻域 cuts、共享容量 Edmonds–Karp、BIG 边容量、边缘/支撑断言和增加 c 后的紧 cut 反证一致；指数曲线按同一 plan 核验，25/40 dps 被准确标为非区间经验检查。零质量 atom 已处理，但未将整份 τ=0/σ=0 冒称为已测案例。没有运行本机数值，也不从该代码认证连续匹配或原 FULL 资格。


## 6. TD 与主 LaTeX 全文后审

已实读 transport_defect_geometry.md 全文。TD6 的逐 u 完整 target/分片正积分上界、TD7 原 λ 回代、TD9 同一合法 J 的 FIRST 及 terminal 1/6 归一、TD10–11 low-Ω 与 fast-target 的两半 ε 账均通过。TD12–18 将 closed upper cut 分成 b^P 属于/不属于 U 两类，父块质量只通过同 α 的物理下包络进入；strict inversion 与 tiny-good 指标限制准确。未使用有限数值认证 closed-cut 达到性，也未把未付的面/位置 union 当小测度。

已实读当前 proof.tex.txt 全文，主 compact 稿的两处措辞修订也已实际核对：正互补子测度不必互相奇异；λ 明确带原唯一 j 指示。LaTeX 的 Hall、lifting、c_m 极限可测性、原 C_rec 以及 window/receiver 范围与主稿一致。未编译 PDF。


## 7. OC 全文及最终整合后审

已实读 ordered_transport_capacity.md 全文。OC5 的精确 optional 预算须减去同一个 K0/μ/Dq 的 S0；OC7–10 直接 neutral 弱证书及同 a 非负增益正确。OC11 在放松删除类中确为精确：零 cost 免费删除，预算足够时值零，预算零用 a→∞，内部预算按 cost 测度的 w/k 分位点及可分数原子层构造；不将该放松最优当成可实现的新原 capture。OC12 的有限 target-generated 上集必须用整个上集 target 质量，OC13–15 互斥 cell 的保守内关系证书及实际 supply 条件提升均通过。原 h 的 OC16 保留全部扣项，未把失败 robust 证书误称实际不可匹配。

已复读 proof.tex.txt 新增 TD 与 protected-neutral 详细段，常数、原 fixed q、同 α、原 λ/唯一 j、时间固定 target 和局部/全局量词与三份详细稿一致。report.md 当前结论未将接口或有限例提升为一般闭合。reproduce.py 静态审通过：依 manifest 验字节，再继承环境和同 Python 入口隔离输出、全 JSON bytes 比对；本独审不运行实验，也不提前认证尚待 manifest 的最终 driver。


## 8. 最终有限检查、结论与冻结绑定

已静态核新增 protected_capacity_checks.py：三阶段各一例、2/3/4 原子，同 Dq/χ 的精确预算、同 a 三项非负增益与实际 neutral 弱界一致；独立 box 顶点/预算平面截边 primal 和完整有限断点 dual 相等，命中零核、零预算、部分删除与饱和预算。该三例的 cut 仅为整个有限载体，不是多 cut、实际 physical/FIRST 或连续证明。最终 report 准确列出旧 15 例与新增 3 例及父级两次完整 JSON 字节重放；最终 reproduce.py 已接入两脚本。父级声明的单脚本重放已完成；本独审不重复运行。最终 manifest 后的总 driver 尚待父级运行，不提前认证。

**通过范围：** 紧排序空间的部分有序耦合等价判据及可测最优系数；受保护 neutral 的同核 reserve/cut 下界及单 cut 精确放松算法；保守有限 inner-cell 证书；原同一分母下的部分 target/future-loss 和条件 ε 接收预算。所有原来源、α、Π、删除、真实 dx、唯一 j 及独立 window 费用保持。已实际核对最终限制 neutral 满足 Aν+N_u≤χ，而非误称受限 parent neutral 与全 target 之和等于 χ。

**未通过为一般结论的内容：** 实际快 target 的失败 upper cuts 在原 λ 与全部 window 下的根阶价格仍未证明；本轮不是一般 weak-type/FULL 闭合，也不从有限例认证一般维数阶或严格扩大原 FULL 覆盖。

以下 SHA256 由最终文件实算，排除本审计自身及尚未生成的 manifest，避免循环绑定。冻结后不再扩展研究。

| 文件 | SHA256 |
|---|---|
| task_contract.md | `b212dc7fc9209d8e9d4d65f9eba1375308a35349063c79fa3e4d040c67c961b9` |
| compact_transport_geometry.md | `3541b0e53a4de496e2b33ff7d81f90e9adade904b1727a071bed45866c9e6718` |
| transport_defect_geometry.md | `d4dab6f212c2ffa4e092fabd9df83dfe5d2ca1e3fa9d230f06c69755ffe6ae82` |
| ordered_transport_capacity.md | `8e8cb9dc45c0ca9ead1d8d94ea67ee80263688824038761a7395cc9e4022420d` |
| proof.tex.txt | `0dd2b582d280936b02f6b5e600cbfcd389d76f6c4ff5d6597cdcee21d53c4571` |
| report.md | `1fe275d4efb6ee452b3ad1ac75acc647a012f6d2cff54352a96f7d7768faf24f` |
| ordered_transport_checks.py | `69d1e76ccc53f192794a0725f11c988e1aaeced0d3416186a1cc6f95f2ca85b8` |
| ordered_transport_checks.json | `ae8429727042fbbc197a7e9582e4a2fcf6f4cf9c36bffa7165be4bc92e58b575` |
| protected_capacity_checks.py | `27d2e0c0c7c955b82ecbdf8c8a2d2f698255b6663603bbe609f8ddb0fd653afe` |
| protected_capacity_checks.json | `8fc4609159dcc947c2743b212897923d872e335ef140953b341ede14fb6971c1` |
| numerical_review.md | `8d065e63bc7a3d6d9253ad26a10d8ca5bbf39244ecc5e83ef5117201cfb176cb` |
| reproduce.py | `6dcf9c908614f5dbdd8bdc3d136deb288894a65272ddf7d3aeeb4a65060fdcd4` |
