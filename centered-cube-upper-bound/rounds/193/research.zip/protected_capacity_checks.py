#!/usr/bin/env python3
"""Exact finite OC5/OC10/OC11 checks; no physical/history qualification."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path


def dot(x, y):
    return sum((a*b for a,b in zip(x,y)), F(0))


def fs(xs):
    return [F(x) for x in xs]


def encode(x):
    if isinstance(x, F):
        return str(x)
    if isinstance(x, dict):
        return {k:encode(v) for k,v in x.items()}
    if isinstance(x, (list,tuple)):
        return [encode(v) for v in x]
    return x


def vertices(eta, k, budget):
    """Enumerate box corners and intersections of budget plane with box edges."""
    n=len(eta)
    out=set()
    for bits in product((0,1),repeat=n):
        d=tuple(eta[i]*bits[i] for i in range(n))
        if dot(k,d)<=budget:
            out.add(d)
    for j in range(n):
        if not k[j]:
            continue
        others=[i for i in range(n) if i!=j]
        for bits in product((0,1),repeat=len(others)):
            d=[F(0)]*n
            for i,b in zip(others,bits):
                d[i]=eta[i]*b
            d[j]=(budget-dot(k,d))/k[j]
            if 0<=d[j]<=eta[j]:
                out.add(tuple(d))
    return sorted(out)


def check(case):
    stage,name,mu,cap,chi,theta,k,w,c=case
    mu,cap,chi,theta,k,w=map(fs,(mu,cap,chi,theta,k,w))
    c=F(c)
    n=len(mu)
    assert all(mu[i]>=cap[i]>=chi[i]>=theta[i]>=0 for i in range(n))
    assert all(x>=0 for x in k) and all(0<=x<=1 for x in w)
    assert c>=dot(k,mu)
    eta=[x-y for x,y in zip(cap,theta)]
    neutral=[x-y for x,y in zip(chi,theta)]
    missing=[x-y for x,y in zip(cap,chi)]
    R=c-dot(k,chi)
    R0=dot(k,[x-y for x,y in zip(mu,cap)])
    S0=c-dot(k,mu)
    B=R-R0-S0
    assert B==dot(k,missing) and 0<=B<=dot(k,eta)
    actual=dot(w,neutral)
    breaks=sorted({F(0)}|{w[i]/k[i] for i in range(n) if k[i]>0})
    def values(a):
        f=[min(w[i],a*k[i]) for i in range(n)]
        la=dot(f,eta)-a*B
        oa=dot(f,mu)-a*R-dot(w,theta)
        terms=[a*R0-dot(f,[x-y for x,y in zip(mu,cap)]),a*S0,
               dot([x-y for x,y in zip(w,f)],theta)]
        assert la-oa==sum(terms,F(0))
        assert all(t>=0 for t in terms)
        assert actual>=la
        return {'a':a,'new':la,'old':oa,'difference_terms':terms}
    test_a=sorted(set(breaks+[(x+y)/2 for x,y in zip(breaks,breaks[1:])]+[2*breaks[-1]+1]))
    checks=[values(a) for a in test_a]
    dual=max(values(a)['new'] for a in breaks)
    old=max([F(0)]+[values(a)['old'] for a in breaks])
    assert dual>=old and actual>=dual>=0
    vs=vertices(eta,k,B)
    objectives=[dot(w,[x-y for x,y in zip(eta,d)]) for d in vs]
    primal=min(objectives)
    minimizers=[d for d,obj in zip(vs,objectives) if obj==primal]
    assert primal==dual
    partial=any(any(k[i]>0 and 0<d[i]<eta[i] for i in range(n)) for d in minimizers)
    if name=='zero_budget_strict_improvement':
        assert B==0 and dual==F(5,8) and old==0
    if name=='zero_kernel_fractional_deletion':
        assert dual==F(1,10) and partial
    if name=='saturated_budget':
        assert B==dot(k,eta) and dual==actual==0
    return {'stage':stage,'name':name,'atom_count':n,
        'inputs':{'mu':mu,'Lambda':cap,'chi':chi,'Theta':theta,'k':k,'w':w,'Dq':c,'cut':'all atoms'},
        'reserve':{'R':R,'R0':R0,'S0':S0,'B':B,'missing_cost':dot(k,missing),'eta_cost':dot(k,eta)},
        'actual_neutral':actual,'dual_breakpoints':breaks,'same_a_checks':checks,
        'vertex_count':len(vs),'vertices':vs,'vertex_objectives':objectives,
        'minimizing_vertices':minimizers,'positive_cost_partial_minimizer':partial,
        'primal':primal,'dual':dual,'old_clipped_dual':old,
        'strict_optimized_improvement':dual>old,'status':'PASS'}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=ap.parse_args()
    cases=[
      ('initial','zero_budget_strict_improvement',[1,1],['3/4','3/4'],['3/4','3/4'],['1/2',0],[1,2],[1,'1/2'],4),
      ('stress','zero_kernel_fractional_deletion',[1,1,1],['3/4']*3,['1/2','7/10','1/2'],['1/4',0,'1/4'],[0,1,2],[1,'1/2',0],'7/2'),
      ('expanded','saturated_budget',[1,2,1,1],['3/4','3/2','3/4','1/2'],['1/4','1/2','1/4','1/4'],['1/4','1/2','1/4','1/4'],[1,2,0,3],[1,'3/4','1/2','1/4'],9),
    ]
    rows=[check(c) for c in cases]
    result={'schema':'r193-protected-capacity-v1','arithmetic':'stdlib fractions.Fraction only',
      'scope':['Three abstract finite measure examples, not physical kernels, FIRST or history instances.',
       'All cuts are the entire finite carrier; actual chi is fixed. The independent OC11 minimizers are relaxations, not new actual captures.',
       'R uses the same Dq and chi; no division by alpha. No general theorem is certified by finite fixtures.',
       'Dual enumerates every finite w/k breakpoint plus zero; primal independently enumerates box corners and budget-plane/box-edge intersections.'],
      'case_count':len(rows),'stage_counts':{'initial':1,'stress':1,'expanded':1},
      'cases':rows,'failures':[],'status':'PASS'}
    args.output.write_text(json.dumps(encode(result),indent=2,sort_keys=True)+'\n')
    print('PASS: 3 exact cases; independent vertex/dual equality, reserve and same-a identities')

if __name__=='__main__':
    main()
