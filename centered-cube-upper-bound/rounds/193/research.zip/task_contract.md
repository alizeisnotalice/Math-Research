# R193：分布式时钟输运与原中间层容量

起点main0d42ca2a3626a51930371a45c4a9322e0fcaf7e8，开始干净。上轮为已独审并推送的实质进展。一般目标未闭合。本轮不再要求每个neutral点优于全部target，改用质量匹配以保持整个target在同一e_t中的支配。

准确对象：固定原row和bad u，原well-weighted target τ=w_ell Aν，neutral σ_u=w_ell(χ−Aν)|Pu∩B，二者推至排序阈值紧空间0≤b1≤...≤bn≤Tlog。若存在positive π with target marginal cτ、neutral marginal≤σ_u，supported z≥v coordinatewise，则G_N(t)≥cG_A(t)，原R192逐u FTC/λ给2/(1+c)真实receiver乘子。source/kernel/current/α/真实dx/原window完全保留。π仅证明分母比较，不重新分配原实际交通或Pi。

主证明该弱匹配接口及continuous compact合法性/原预算。Sol辅助研究可计算cut容量和同α reserve robust下界（有限或一般资格明确）；Astra唯一攻坚在LS小LCA/late/tiny/lowFtree实际剩余上如何支付匹配失败的cut，不只写条件性匹配门。Sol独审先命题筛再读证明；Sol medium本机Fraction matching/cut/curve三阶段。文件独占，不Git/spawn、不互改，完成停止。

允许R192 LS、CG、IF以及R183/188/190/191冻结工具。警惕σ与τ非equalmass，neutral不能依running v或t重选；quantized有限LP不能无费提升连续最优，closed relation和compact/zero masses须证明。没有源坐标独立、ν≤β、固定尺度替一般输入或免费grid/层数。重要数值只认证实际运行有限证据。
