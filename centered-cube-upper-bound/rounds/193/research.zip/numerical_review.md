# R193 finite ordered-transport review

All 15 cases pass: 4 initial, 5 stress, and 6 expanded cases, with sorted rational threshold vectors in dimensions 2 through 6. Every case has positive but unequal total supply and target mass, with explicit zero atoms permitted. Exact Fraction calculations certify the finite cut, plan, marginal and edge constraints. The 25/40-dps exponential curves are numerical checks, not intervals. No original FULL/FIRST/history construction, continuous transport certificate, all-input matching guarantee, or dimension-order fit is claimed.

## Exact shared-capacity algorithm

A source z can send mass to target v exactly when b_z≥b_v coordinatewise. All nonempty target subsets of positive target mass are enumerated. For each subset T the code records its complete source neighborhood N(T) and ratio sigma(N(T))/tau(T). The minimum is c*. Zero-target-only subsets are skipped before division; adding zero-target atoms does not create demand.

Independently, a Fraction Edmonds–Karp residual network reconstructs a plan at c*. Source edges have capacity sigma_i; target sink edges have capacity c*tau_j; allowed source-target edges have capacity BIG=sum sigma+c*sum tau+1. BIG exceeds all supply and demand and cannot introduce a spurious edge bottleneck. Every source marginal is at most its original capacity, every target marginal equals c*tau, and positive plan entries occur only on allowed edges. The total maxflow equals the required total demand exactly.

The recorded dual subset satisfies c*tau(T)=sigma(N(T)). Raising c by 1/1000 violates that exact cut, supplying an independent finite upper certificate. The source capacities are shared by the entire target measure, not reset for each target. Neither measure is renormalized to the other.

## Three-stage findings and capacity reuse

The initial incomparability example has sources and targets at (1/5,9/10) and (3/5,7/10), with supply masses (1,1) and target masses (1,1/2). No source dominates both positive targets, so the old all-target-esssup supply mass is zero. Yet the diagonal plan gives c*=1 and leaves supply 1/2 unused. This is a strict finite improvement over that stronger eligibility test, not an assertion about general original rows.

The shared-supply example has one source of mass 1 dominating two targets of mass 1 each. Both singleton cuts allow c=1, but the whole-target cut gives c*=1/2. A separate maxflow at the unsafe singleton value delivers only 1 against demand 2. The expected failure is retained explicitly, rather than counted as a successful independent per-target payment.

Stress cases include zero supply and target atoms, an inaccessible zero-mass target, inaccessible positive demand (c*=0), duplicate threshold vectors with equality edges, and mass ratios giving c*=10^12 and c*=10^-6. These large/small coefficients are not clipped to [0,1]. Expanded cases use dimensions 2,3,4,5,6 with multiple source/target atoms and differing bottleneck cuts, plus a sparse six-dimensional example. Representative exact values are:

| Case | c* | Old all-target c | Bottleneck target subset |
|---|---:|---:|---|
| initial incomparable pair | 1 | 0 | {0} |
| shared single supply | 1/2 | 1/2 | {0,1} |
| zero-mass edges | 1/3 | 1/5 | {1} |
| duplicate thresholds | 5/6 | 5/18 | {0,1,2} |
| expanded n=4 | 25/32 | 5/31 | {0,2} |
| sparse n=6 | 2/5 | 0 | {1} |

These are finite interfaces, not a numerical estimate of any general dimensional rate or a guarantee that a particular original neutral measure has enough matching mass.

## Correct logarithmic-clock curves

The curves use the confirmed well-weighted ratio form

`G_N(r)=Σ sigma_z exp[−Σ_i(r−b_zi)+]`,

`G_A(r)=Σ tau_v exp[−Σ_i(r−b_vi)+]`, for r∈[0,1].

Each case uses 3–5 rational clocks: 0,1/2,1 and selected actual threshold coordinates. At every sampled clock the positive-plan edges are first checked exactly to have source loss≤target loss. The numerical chain then retains the same plan:

`G_N ≥ Σ pi_zv g_z ≥ Σ pi_zv g_v = c*G_A`.

Both precision blocks, both curve values and their ratio are saved. Tolerances scale with mass to avoid imposing an inappropriate absolute error on the 10^6 supply case. The GN relative precision check is below 1e-18; the individual positivity/equality checks use working-precision residual allowances. These controls are empirical, not rigorous exponential error bounds. The plan proves denominator comparison only; it does not redistribute the original positive traffic or Pi.

## Environment and deterministic replay

Standard import uses existing mpmath 1.3.0 through the external local path:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 ordered_transport_checks.py
```

The script accepts `--output /tmp/result.json`. All exact arithmetic is standard-library Fraction. The JSON records the adjacent filename-only task-contract hash and relative-name `.py` mpmath source hash, excluding bytecode. No absolute dependency path or runtime timing enters the JSON, and no library was installed. All failed checks exit nonzero.

An isolated replay copies only the script and adjacent task contract to `/tmp/r193_ordered_transport_review/`, supplies the same external PYTHONPATH, and compares the entire JSON byte-for-byte. The finite task is complete; no extension to continuous compact measures or original source/kernel/receiver qualifications is inferred from these cases.
