#!/usr/bin/env python3
"""Verify archived inputs and replay the finite certificates; no general proof claim."""
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
manifest=json.loads((ROOT/'manifest.json').read_text())
for name,digest in manifest.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest),'file hashes')
if not a.verify_only:
    if a.output_dir is None: p.error('--output-dir is required for replay')
    a.output_dir.mkdir(parents=True,exist_ok=True)
    for stem in ['ordered_transport_checks','protected_capacity_checks']:
        out=a.output_dir/(stem+'.json')
        if out.exists(): p.error('Use an output directory without an existing result')
        subprocess.run([sys.executable,str(ROOT/(stem+'.py')),'--output',str(out)],check=True,env=os.environ.copy())
        assert out.read_bytes()==(ROOT/(stem+'.json')).read_bytes()
        print(stem+': complete numerical JSON replay is byte-identical')
