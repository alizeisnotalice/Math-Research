# R193 compact ordered transport and actual receiver budget

Status: proof submitted for independent review. General root-order closure is not asserted.

Fix one original row and bad u as in task_contract.md. All source measures, original alpha, window, selector and actual receiving Lebesgue measure are unchanged. Set tau=w_ell A nu, sigma=w_ell(chi-A nu)|_{P_u intersect B}. These are finite positive measures, not normalized probabilities. Push both by the sorted clock vector b onto X_T={0<=b_1<=...<=b_n<=T}, T=log(g/ell). If T=0 the time integral is zero. Otherwise rescale b by T for the compact-order argument only.

## Compact matching theorem
For finite positive sigma,tau on X={0<=b_1<=...<=b_n<=1} with tau(X)>0, the largest c>=0 for which a positive measure pi on X times X exists with first marginal <=sigma, second marginal c tau, and support {(z,v):z_i>=v_i for all i}, is

c_* = inf_{U Borel upper, tau(U)>0} sigma(U)/tau(U).

An upper set is relative to X. The whole-space cut bounds c_* by sigma(X)/tau(X); zero supply gives c_*=0. Zero target carries no original A traffic and is handled separately.

Necessity: if v belongs to an upper U and z>=v, then z belongs to U. Thus c tau(U)<=pi(U times X)<=sigma(U).

Sufficiency and attainment: apply the same coordinatewise dyadic floor map q_m to both measures, leaving endpoint 1 equal to 1. It preserves X and order. Preimages of grid upper sets are Borel upper. For any set D of target grid vertices its neighbor set is upward closure(D). The cut assumption gives sigma_m(up D)>=c tau_m(up D)>=c tau_m(D). The finite capacitated bipartite flow problem therefore has a flow with all target demands c tau_m met. This finite Hall statement follows by maximizing flow over its compact polytope and considering the residual reachable cut if any target demand is unmet; it needs no algorithmic termination assertion for irrational capacities.

Lift each edge flow to the product of the normalized restrictions of original sigma and tau to its two grid cells. Zero-mass cells carry no edge flow. This lift has second marginal exactly c tau and first marginal <=sigma. Its support has z_i>=v_i-2^{-m}. Its total mass is c tau(X), hence compactness of finite measures on compact X times X gives a weakly convergent subsequence. Marginal equalities pass by continuous test functions; the first marginal domination passes by nonnegative continuous tests and regularity. The limiting support lies in the closed order relation, since every compact subset of its complement has a positive distance from that relation. This proves feasibility for every c satisfying all cuts, including c_*.

## Countable characterization and measurable row coefficient
Let c_m be the optimum for the finite common dyadic grid. Equivalently take the minimum ratio over its finitely many upper sets with positive target mass. Because q_m composed with q_{m+1} equals q_m, c_{m+1}<=c_m. Every genuine ordered coupling projects to every grid, so c_*<=c_m. Lift optimal grid couplings at c_m as above. Their uniformly bounded masses and c_m decreasing to c_infty give a limit feasible at c_infty. Hence c_infty=c_*.

Consequently c_* is a countable decreasing limit of finite minima of measurable cell-mass ratios for the original measurable row kernels. Normalize by T before forming cells when T varies. The zero-target branch is declared separately. No measurable selection of pi is required: pointwise existence yields the deterministic denominator inequality for all times. No finite-mesh convergence rate is claimed. These grids characterize a coefficient; they do not sum replicated source measures or introduce new averaging menus.

## Actual denominator and raw traffic
For r=log(t/ell), let F_r(b)=exp(-sum_i(r-b_i)_+), now using unscaled physical clocks b in X_T. F_r is increasing coordinatewise and w_t/w_ell=F_r. Therefore

G_N(t):=integral F_r d sigma >= c_* integral F_r d tau = c_* G_A(t).

The actual neutral measure is time-fixed, supported in the original terminal support and a positive submeasure of chi-A nu; in particular A nu + N_u <= chi. It therefore remains available throughout the original interval. Original e_t >= (1+c_*)G_A(t), and the inherited terminal inequality e_t>=e+G_A(t)-G_A(g) also remains valid. The coupling certifies these inequalities only; it neither changes actual Pi_t nor reassigns original traffic.

Apply R192 CG's one-row FTC, with G=G_A and D=G(ell)-G(g), psi=D/(e+D). For each u its contribution is bounded by its original initial bad weight divided by e, times

min{psi, 2/(1+c_*(u))}.

After exactly the R188 lambda domination (sum_V lambda mass <=1 at the same receiver and original window), the reciprocal raw is bounded by

C_rec E sum_{V,j} integral q dx integral min{psi,2/(1+c_*(u))} d lambda,

C_rec=16 Lambda/(3K kappa). The lambda measure retains the original unique-j indicator; the displayed j sum is not a sum of unrestricted posteriors. On the measurable branch 1+c_*>=2 C_rec/epsilon this costs at most epsilon E integral q dx, with all original windows retained. This is an actual conditional receiving-measure budget, not a proof that the branch covers all inputs.

R192's all-target ordered subset is a special feasible plan: its initial neutral mass divided by tau(X) can be coupled to tau by a product measure. Distributional matching can strictly improve that sufficient condition. Finite examples establish this interface distinction only, not a strict enlargement of verified original FULL coverage.

## Remaining global gap
Neither compact matching nor finite flow forces c_* large on every small-LCA hard row. The actual low-capacity upper cuts must still receive a root-order source or receiving-measure bound. The neutral supply must retain original chi, K0, alpha reserve and P_u; replacing it by an abstract freely chosen supply would change the question. No dimension asymptotic follows from the finite examples.
