# R193：按真实未来损失支付匹配缺口与 upper-cut 的原位置约束

本稿不重证连续时钟 coupling 的存在定理。它证明两个与实际原积分直接相接的结论：一是允许部分 target 匹配，未匹配部分按原未来损失而非裸质量付费；特别地，低放大 target 可统一支付小接收费。二是将原小 LCA 上匹配失败的 upper-cut 分成整块供给不足与明确的排序阈值倒置，并用 tiny-good 的真实载体限制这些倒置指标。后者目前仍是必要几何，未取得一般来源价。

## TD1. 固定原行与不改变的对象

固定原 (omega,V,x,j,y)，初始 ell、终端 g，e=e_g(y)>0，原接收域 E_rec。保持原 A(v)=1_good rho_y(v)J_v/(3Q_v)、同一 alpha、capture、K0=P_(s,Hhat)、全部 Pi_y,t 和删除、history、current FIRST、唯一 j(x)。0≤A≤1，supp(A nu)⊂Z_g。所有 dx 都在原 E_rec 上；本稿不扩大空间域。

沿用 R191/R192 的实际 fractional capture chi：

    A nu≤chi≤nu≤mu_hi,  supp chi⊂Z_g,
    k_z=DK0_z, R_alpha=alpha QJ,
    ∫k_z(mu_hi-chi)(dz)≤R_alpha.                       (TD1)

不假设 nu≤beta，不使用每叶质量帽。严格软核的零支沿用原合同；若原 A nu=0，则本文交通先取0。

记原完整 reciprocal bad 集为 R_y⊂Z_ell，可含后来删除的 u。令

    kappa=K(1+gamma^(-n))/3, gamma=1+1/n,
    C_rec=16Lambda/(3K kappa),
    G_A(t)=∫A(v)w_t(y,v)nu(dv),
    D_A=G_A(ell)-G_A(g), psi_A=D_A/(e+D_A).

实际 K=1；kappa≥1 时互反域空。原 high/reciprocal/FIRST 给

    ∫_Ry w_ell(y,u)nu(du)/e≤1/(2K kappa).              (TD2)

以下 H∈[0,1] 保留原全部剩余 positive pair 门，包括 middle s、late LCA、near outer-bad、tiny good、low Ftree、history 等。没有把依 u 的门并入一个重新计算的 target。

## TD2. 部分匹配需要支配的真实对象

对每个固定 u∈R_y，允许可测、沿辅助时间不变的拆分

    A=A_m,u+A_d,u,  0≤A_m,u,A_d,u≤A.

拆分可以依原 x,y,u 和整个 target 测度，不能随 t 改换。定义

    G_m,u(t)=∫A_m,u w_t dnu,
    G_d,u(t)=∫A_d,u w_t dnu,
    D_d,u=G_d,u(ell)-G_d,u(g),
    psi_d,u=D_d,u/(e+D_d,u).                           (TD3)

原父块 P_u=LCA(y,u)，neutral 初始测度为

    sigma_u=w_ell(y,z)(chi-A nu)|_(P_u∩B).

设主稿的正 coupling 仅对 matched target

    tau_m,u=w_ell A_m,u nu

证明存在原时间固定 N_u≤(chi-A nu)|_(P_u∩B)，满足

    G_N,u(t):=∫w_t dN_u≥c_u G_m,u(t)
      for all t∈[ell,g],  c_u≥0.                     (TD4)

例如原 sorted-threshold 空间上 target marginal=c_u tau_m,u、source marginal≤sigma_u、且 source threshold≥target threshold 的正 coupling 蕴含 TD4。本文只使用已证明的 TD4；没有借此重新分配实际 Pi 交通。完整 measurability/compactness/coupling 存在范围由主稿核验，不以有限 LP 替代。

若 G_m,u(ell)=0，matched 交通为0，可省去其项。以下为清楚起见保留一个可能较粗的非负上界。因为 A_m,u nu+N_u≤nu 且均 terminal-surviving，

    e_t≥max(e,(1+c_u)G_m,u(t)),
    e_t≥e+G_d,u(t)-G_d,u(g).                          (TD5)

两个分母都是同一个原 e_t，未将 bad 部分条件归一，也没有改变 alpha。

## TD3. 原缺口收费定理

对固定 u，先保留其原 alive 指示和 w_t(y,u)，然后正上放为 w_ell(y,u)。score 差满足 (score_v-score_u)_+≤score_v。两个 target 部分都无删除跳，故

    -dG_m,u=∫A_m,u score_v w_t dnu dt/t,
    -dG_d,u=∫A_d,u score_v w_t dnu dt/t.

由 TD5，

    ∫(-dG_m,u)/e_t²≤2/[e(1+c_u)],
    ∫(-dG_d,u)/e_t²≤D_d,u/[e(e+D_d,u)]=psi_d,u/e.

第一式用 ∫_0^∞dG/max(e,(1+c_u)G)²=2/[e(1+c_u)]；第二式是同一原 target 缺口的 FTC。另对完整 A 使用原分母补偿得到 psi_A/e。于是实际完整正行满足

    I_H≤(1/e)∫_Ry w_ell(y,u)
         min{psi_A, 2/(1+c_u)+psi_d,u}nu(du).         (TD6)

这是将两个正片分别上界后再与整行上界取 min，不是将两份负信用相加。所有后来删除与 pair-dependent H 只正减少原被积式。TD6 允许 u-dependent 拆分，但各拆分必须可测、沿 t 固定，仍使用完整原 e_t。

沿用 R188 的实际接收点相关测度

    lambda_x,V(dy,du)
      =(2K kappa/q)(p_y/e_g(y))1_high(y)1_Ry(u)
                  w_ell(y,u)beta_V(dy)nu_V(du),

其共同 current 容量给原求和次序下 EΣ_V||lambda_x,V||≤1。保留唯一 j(x) 及该行原 ell,g，回代一次 hard 帽和外系数，得到

    Raw^+[H]≤C_rec EΣ_V∫_Erec q dx
           ∫min{psi_A,2/(1+c_u)+psi_d,u}lambda_x,V.   (TD7)

这没有空间参考替换、固定尺度上确界或新的 LCA 层数费。各独立窗口仍须按原总账分配费用。若拆分只逐点存在而未作可测选择，不能把未经证明可测的 psi_d,u 放进 TD7；可改为使用一个已证明可测的 scalar 上界，或直接使用统一的原行 bound。

## TD4. 匹配缺口的正确代价是 future loss

写 Tlog=log(g/ell)，并使用 R192 CG 的原 clipped sorted threshold

    b_i(v)=clip(log(C((y_i-v_i)/b)/xi_ell),0,Tlog),
    b_(1)(v)≤...≤b_(n)(v), xi_t=c_jt/b.

令

    Omega(v)=Σ_i(Tlog-b_i(v))=log(w_ell(y,v)/w_g(y,v)).

原 initial target 测度 tau=w_ell A nu 及其未匹配部分 tau_d,u=w_ell A_d,u nu 满足准确身份

    D_d,u=∫[1-exp(-Omega(v))]tau_d,u(dv).              (TD8)

因此不能把裸 missing mass tau_d,u 的大小直接说成原交通缺口；一个 initial 质量大的慢 target 可能有很小的 TD8。反之，也不能用 G_A(g)/e 的上界冒充任何 missing mass 的下界。

原 good/high/同一合法 J 的 FIRST 给

    G_A(g)/e
      =e^(-1)∫A(v)w_g(y,v)nu(dv)
      ≤K QJ/(3p_y e)≤QJ/(6q)≤1/6.                   (TD9)

现在只取低放大 target 片 A_low=A 1_{Omega≤r}，r≥0。其未来损失满足

    D_low/e≤(exp(r)-1)G_A(g)/e≤(exp(r)-1)/6.

对该真实 target 片直接使用 TD6 的缺口 FTC（没有 matched 部分），得到

    Raw^+[H;Omega(v)≤r]
      ≤C_rec (exp(r)-1)/6 · E∫_Erec q dx.             (TD10)

给定预分配 epsilon_low>0，r=log(1+6epsilon_low/C_rec) 即支付 epsilon_low 接收费。此结论可与旧低放大付款重叠；本稿不据此认证对全部旧 FULL 分支的严格扩大。

更有用的组合是：只对 A_fast=A 1_{Omega>r} 做部分匹配，并把 A_low 留为缺口。若该原 fast-target 匹配有

    1+c_u≥4C_rec/epsilon,
    r=log(1+3epsilon/C_rec),                          (TD11)

则 2/(1+c_u)≤epsilon/(2C_rec)，psi_low≤epsilon/(2C_rec)，TD7 对相应实际 u 子域给总 epsilon 接收价。只需匹配快 target，完全不需匹配 low-Omega target 的裸质量。它是有全部费用的条件匹配结论，不声称原 fast-target 匹配必然存在；父稿的 cut 判据应对 tau_fast，而不是再用 tau 全质量阻挡这个已合法的正分割。

## TD5. 原 LCA 的最坏时钟及 closed upper-cut 分类

下面只分析原位置，不证明新的 coupling 存在定理。设 P=P_u 为原半开 LCA cube，side(P)=S。对每个坐标令

    r_i(P,y)=max{y_i-left_i(P),right_i(P)-y_i},
    b_i^P=clip(log(C(r_i(P,y)/b)/xi_ell),0,Tlog),
    b^P=sort(b_1^P,...,b_n^P).

即使用半开 cube，右端点的 supremum 距离仍给合法闭上界。物理 C 偶且径向非增，因此对所有 z∈P

    b(z)≥b^P coordinatewise after sorting.             (TD12)

排序保支配的证明是：若未排序的每个坐标均大于对应下界，则对任意实数 r，左向量小于 r 的坐标个数不多于下界向量，从而每个 order statistic 也不小于下界。这里没有源坐标独立性。

令 U 为 sorted-threshold 紧空间中的 closed upper set；即 b∈U、b'≥b 蕴含 b'∈U。对相应推前测度仍记 tau、sigma_u。一个被主 cut 判据检测的失败是

    c tau(U)>sigma_u(U).                              (TD13)

这里只从一个给定的失败 cut 推导必要性质，不自行宣称所有失败必由一个 closed U 达到。

**情形一：b^P∈U。** TD12 使原 P 上全部 neutral 落入 U，因此

    sigma_u(U)=sigma_u(total).

令 M_A(P)=∫_(P∩B)A w_ell dnu，并定义实际标量下包络

    L_P=sup_(c_cap≥0){∫_(P∩B)min(w_ell,c_cap DK0)dmu_hi
                         -c_cap R_alpha}.

R192 CG16–17 的同一 reserve 证明给

    sigma_u(total)≥[L_P-M_A(P)]_+.

故 TD13 必须满足

    c tau(U)>[L_P-M_A(P)]_+.                          (TD14)

L_P 使用实际 K0、同一 alpha，sup 可取非负有理 c_cap。h(P) 对它的准确进入为

    ∫_(P∩B)min(w_ell,c_cap DK0)dmu_hi-c_cap R_alpha
      =h(P)-∫_(P∩B)[1-min(w_ell,c_cap DK0)]dmu_hi
             -c_cap R_alpha.

所以本类 cut 若仍失败，至少不能从该真实父块的低核/初始权衰减和 reserve 扣费后得到足够 neutral 质量。未将 h(P) 当成 nu(P)。

**情形二：b^P不在U。** 对每个 b(v)∈U，若 b(v)≤b^P，则 upper 性迫 b^P∈U，矛盾。故必存在 i 使

    b_(i)(v)>b_i^P.                                   (TD15)

这把失败 cut 的 target 限定于真实排序倒置域 O_P，而不是任意 missing mass。它并不意味着每个坐标都离父块更近；只意味着至少一个 order statistic 更慢。下面给其可检验的坐标含义和 tiny-good 限制。

## TD6. tiny-good 对倒置指标的额外物理约束

设 beta_i=b_i^P<Tlog。TD15 意味着至少 m=n-i+1 个真实坐标满足

    C(|y_l-v_l|/b)>xi_ell exp(beta_i).

对应的 terminal loss 严格小于 Tlog-beta_i：

    log_+(xi_g/C_l(v))<Tlog-beta_i.                   (TD16)

beta_i=0 时严格 b_(i)(v)>0 仍给相同 strict 条件；beta_i=Tlog 时 TD15 不可能。以上是物理 C 的原阈值，没有把它替换成自由坐标变量。

R192 IF4 由原 active target 支持 v∈Z_g⊂D_V(y) 得到

    log_+(xi_g/C_l(v))≤M_n:=10log n+3+log2

对每个坐标成立。该界保留原载体 |y_l-v_l|/b≤5log n+1/2，来自 C(d)≥(1/2)exp[-2(d+1)]，而不是来源密度或独立性。因此若当前实际 target 还满足 w_g(y,v)<delta，则 log(1/w_g)>L_delta:=log(1/delta)。与 TD16 联合，任何可能的倒置指标必须满足

    beta_i<Tlog,
    L_delta<(i-1)M_n+(n-i+1)(Tlog-beta_i).             (TD17)

否则该指标的实际 target 子域为空。定义 I_allow(P,delta) 为满足 TD17 的有限指标集合。对不含 b^P 的失败 upper-cut，其 tiny-good 部分准确支持于

    {v: w_g(y,v)<delta,
        b_(i)(v)>b_i^P for some i∈I_allow(P,delta)}.   (TD18)

这不是一次额外的 n 层付款，也未将 union 当成有小测度。它仅将未来需支付的真实位置进一步限制。若 I_allow 为空，则所有实际 tiny-good target 都 b(v)≤b^P；整个父块 neutral 在时钟上支配这一个 tiny target 片，可使用主 coupling/旧排序机制，但仍须检查真实 neutral 质量。不能由该结论替换原非 tiny target；若分析只保留 tiny 片，应把它作为原 A 的合法正限制，保持同一 chi、alpha 与分母。

## TD7. 与 LS/late 约束的接缝及第一处未付积分

先用主已核 LS 大 LCA 失真接收费后，原余域保 side(P_u)≤2A_grid||y-u||_1。TD12 使用该真实 P_u，故其 r_i≤side(P_u) 可代入。但 n 个坐标的 C、实际 K0 和 hard 面费用都仍存在；这个边长界不保证 TD17 的全部指标消失。

R190 late 条件还给 h(P_u) 的原阈值下界。它在情形一通过 TD14 的物理衰减/储备扣除进入；在情形二，h(P_u) 大不能保证其质量处于失败 upper-cut U 内。因而不能将该 h 下界直接填进 sigma_u(U)，这是最早一个不能成立的无权质量替换。

TD6–11 已经给出实际缺口的原接收账，尤其允许统一支付 low-Omega target，而只匹配其余快 target。对仍未匹配的快 target，必须支付

    D_d,u=∫_{Omega>r}(1-exp(-Omega))tau_d,u,

在原 beta、lambda、history 和真实 dx 下的贡献。TD14、TD18 精确指出它可来自的两种物理配置：整父块扣除 low K0/初始衰减/同 alpha reserve 后的供给不足，或允许指标上的排序倒置。尚未证明这些配置的加权接收占用小，也未证明它们有 sqrt(n)polylog 来源价。

当前新内容是正确的 future-loss 缺口收费及上述具体 upper-cut 位置分类；它们不把未知 defect 换名为已付范数。一般 middle 层结论仍未闭合。本稿不再扩展新的 cutoff 或反例搜索，等待这些实际剩余几何的下一步预算。
