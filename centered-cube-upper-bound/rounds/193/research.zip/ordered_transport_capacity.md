# R193：受保护 target 的有序输运 cut 容量

本文只证明固定原 row、固定原 bad 来源 u 的可计算容量下界及有限证书。一般连续匹配的 compact 等价性与原 FTC 回代见本轮 `compact_transport_geometry.md`；本文不另假无限维强对偶。所有来源、capture、current、α、原空间接收积分和 window 均保持不变。结论没有支付一般匹配失败的 cut，也没有闭合一般目标。

## OC1. 原对象与量词

固定原 `(ω,V,x,j,y)` 及 initial-alive bad u。写 μ=μ_hi、ν=ν_V、w=w_ell(y,·)∈[0,1]、k=DK0，其中 K0=P_{s,Hhat}(x−·) 是该 row 的同一个合法共同 future 核。原值 q、D、α、QJ 及 capture 集 E 固定，令

\[
 R=\alpha QJ=Dq-\int k\,d\chi,\qquad
 \chi=1_E\min(1,T\Delta/k)\nu.
 \tag{OC1}
\]

零核按已审 capture 约定处理，使 kχ=1_E min(k,TΔ)ν。令 Θ=Aν 为**未加 w 的受保护 target 测度**。使用 R191/R192 已审的原有效 terminal-good 资格，有

\[
 0\le\Theta\le\chi\le\nu\le\mu,
 \qquad \int k\,d\mu\le Dq.
 \tag{OC2}
\]

这里不使用 ν≤β。β、ν 只有原共同父来源预算；本文不改变 β、history 或任何内槽 ν。记 P=P_u=LCA(y,u)，B_born 为原 born 集，h(P)=μ(P∩B_born)。不能把 h 换成 ν 质量。

令 b(z)=(b_(1)(z),…,b_(n)(z)) 为原 clipped、升序排列阈值，值域为紧集

\[
 \mathcal D=\{0\le b_1\le\cdots\le b_n\le T_{\log}\},
 \qquad T_{\log}=\log(g/\ell).
\]

原时钟恒等式为

\[
 {w_t(z)\over w(z)}
 =\exp\!\left[-\sum_i(r-b_i(z))_+\right],
 \quad r=\log(t/\ell).
 \tag{OC3}
\]

target 和本 u 的 neutral supply 推前为

\[
 \tau=b_\#(w\Theta),\qquad
 \sigma=b_\#\bigl(w(\chi-\Theta)|_{P\cap B_{\rm born}}\bigr).
 \tag{OC4}
\]

它们不必等质量。所求是**一个共同 c≥0、一个共同正测度 π**，target 边缘 cτ、supply 边缘≤σ，且 π 支持 z≥v 的闭坐标序。π 只证明原分母比较，不替换原 traffic/Pi。T_log=0 时阈值空间是单点，以下质量结论仍成立，原时间积分则为零。

## OC2. 先扣除已确定的预算占用

选择任一已知共同测度包络 Λ_cap，满足

\[
 \Theta\le\chi\le\Lambda_{\rm cap}\le\mu.
\]

例如可取 Λ_cap=ν，或已确定原 E 时取 1_Eν；不可逐 cut 改变实际 χ。设

\[
 \eta=\Lambda_{\rm cap}-\Theta,\quad
 R_0=\int k\,d(\mu-\Lambda_{\rm cap}),\quad
 S_0=Dq-\int k\,d\mu\ge0.
\]

S0 必须来自**同一个 K0、μ、Dq**，不能借另一 future 或局部 current 的 slack。定义

\[
 \boxed{\mathfrak B=R-R_0-S_0
       =\int k\,d(\Lambda_{\rm cap}-\chi)\ge0.}
 \tag{OC5}
\]

令 N=χ−Θ、d_miss=Λ_cap−χ。则

\[
 0\le N\le\eta,\qquad d_{\rm miss}=\eta-N\ge0,
 \quad \int k\,d d_{\rm miss}=\mathfrak B
 \le\int k\,d\eta.
 \tag{OC6}
\]

这是原同 α 的恒等式，没有 1/α。若 S0 仅知非负而未认证其值，可以保守使用较大的预算 R−R0；后续界方向不变。

## OC3. 直接 neutral 的 cut 下界

对任意 Borel 物理集 C⊂P∩B_born，定义可计算标量函数

\[
 \mathcal L(C;\mathfrak B)
 =\sup_{a\ge0}\left\{
   \int_C\min(w,ak)\,d\eta-a\mathfrak B\right\}.
 \tag{OC7}
\]

于是

\[
 \int_C w\,dN\ge\mathcal L(C;\mathfrak B)\ge0.
 \tag{OC8}
\]

证明：对每个同一标量 a≥0，w≥min(w,ak)，故

\[
 \int_C w\,dN
 \ge\int_C\min(w,ak)\,d\eta
       -\int_C\min(w,ak)\,d d_{\rm miss}
 \ge\int_C\min(w,ak)\,d\eta-a\mathfrak B.
\]

取上确界；a=0 给非负性。实际 N 同时满足所有 C 的式子。不同 cut 可以选不同的**对偶测试数** a，不能据此重选供给测度或输运 π。

对上集 U⊂D，令 C_U=P∩B_born∩b^{-1}(U)，则

\[
 \sigma(U)\ge\mathcal L(C_U;\mathfrak B).
 \tag{OC9}
\]

因此同一 c 若满足所有上集的 L(C_U)≥cτ(U)，便给出父稿 compact 匹配判据的充分 cut 证书。τ(U)=0 的 cut 不作除法。本文没有证明这些不等式在全部实际 row/u 上普遍成立。

## OC4. 严格加强原 CG 标量下界

原形式的同 a 下界为

\[
 O_a(C)=\int_C\min(w,ak)\,d\mu-aR-\int_Cw\,d\Theta.
\]

本文对应 L_a(C) 与之的差**精确**为

\[
 L_a(C)-O_a(C)
 =aR_0-\int_C\min(w,ak)\,d(\mu-\Lambda_{\rm cap})
  +aS_0+\int_C[w-\min(w,ak)]\,d\Theta\ge0.
 \tag{OC10}
\]

前三项按全域 R0、同核 S0 和 min(w,ak)≤ak 判断。改进来自保护实际 target、扣除强制未捕获质量和已知 current slack；不是另命名同一个未知 cut。严格改善只在上述非负差确为正且改变最优值时成立，不据此宣称实际剩余区域已被覆盖。

## OC5. 单 cut 的精确分数背包计算

OC7 不仅是弱界。对有限 η、可积 k 及 0≤w≤1，它等于下列**放松 capture 类**的最坏 neutral 质量：

\[
 \mathcal L(C;\mathfrak B)
 =\inf_{0\le d\le\eta,\ \int k\,dd\le\mathfrak B}
       \int_Cw\,d(\eta-d).
 \tag{OC11}
\]

这里允许的 d 不必由原 TΔ/capture 实现；所以单 cut 的放松最优，不是重新构造原实际 χ。只需在 C 内删除；C 外设 d=0。

证明和算法如下。k=0 的部分可免费全部删除，对保证值贡献零。w=0 的部分无目标价值。记 C+=C∩{k>0,w>0}，K_C=∫C+ k dη。若预算≥K_C，删除 C+ 即得值零，且 OC7 每项≤0。若预算为零，只能免费删除零核，保证值为 ∫C∩{k>0}w dη；OC7 由 a→∞ 的单调收敛达到此值，上确界未必有限 a 取到。

余下 0<预算<K_C。对有限 cost 测度 kη|C+，按 ratio w/k 从大到小删除。存在阈值 a∈(0,∞)，使

\[
 \int_{C_+\cap\{w/k>a\}}k\,d\eta
 \le\mathfrak B
 \le\int_{C_+\cap\{w/k\ge a\}}k\,d\eta.
\]

删除 ratio>a 的全部质量，并对 ratio=a 层作常数比例删除，恰耗尽预算；即使 η 有原子，分数密度仍合法。保留值等于 ∫C min(w,ak)dη−a预算，因而与 OC8 弱界相等。这是直接构造，不使用无限维强对偶。

有限有理数据时，每个 atom i 的质量 η_i、价值 w_iη_i、cost k_iη_i 均精确有理。先免费删除 k_i=0，再按 w_i/k_i 降序排序，依次消耗预算，最多一个 atom 部分删除。所有比较、截断和最终 L 可用 Fraction 算术认证；不要求相等 atom 质量。有限数值数据只有在这些输入本身已认证时才给严格实际 cut 证书。

## OC6. 有限实际阈值支持的完整 cut 列表

当 τ 的阈值支持有限，对任意上集 U，令 S 为 U 中全部 target sites，U_S=↑S。则 U_S⊂U、τ(U_S)=τ(U)，且 L(C_U_S)≤L(C_U)。所以只需枚举有限 target sites 子集产生的不同上集 U_S。分母必须取**整个生成上集**的 target 质量，不能只加最初选出的 sites 而漏掉其上方 target。

当 η 的相关支持也有限时，逐 U_S 用 OC5 精确计算，便得到

\[
 c_{\rm cert}=\min_{\tau(U_S)>0}
 {\mathcal L(C_{U_S};\mathfrak B)\over\tau(U_S)}.
 \tag{OC12}
\]

这是明确的枚举与排序算法。任意 0≤c≤c_cert 对同一实际供给同时满足所有上集 cut；父稿有限/compact 判据可据此使用。若 c>c_cert，只表示这个 robust 下界不能认证 c；不能推出原实际 χ 不可匹配。不同 cut 的放松最坏删除无需同时实现，也没有被当作同一个实际删除。

## OC7. 一般连续来源的保守有限证书

不作量化极限，也可对一般实际测度给有限**充分**证书。将 threshold 空间划分为互斥 Borel supply cells B_i 和互斥 Borel target cells D_j；可先将重叠族拆交成分区。令 s_i=σ(B_i)、t_j=τ(D_j)。只允许边 i→j 满足

\[
 \inf_{z\in B_i}z_l\ge\sup_{v\in D_j}v_l
 \quad\text{对每个坐标 }l.
 \tag{OC13}
\]

这是所有 cell 内点对均有序的内关系。对每个 target 索引子集 J，令 N(J) 为至少连向一个 j∈J 的 supply cells，C_N=P∩B_born∩b^{-1}(∪_{i∈N(J)}B_i)。若**同一 c** 满足有限全部条件

\[
 \mathcal L(C_N;\mathfrak B)\ge c\sum_{j\in J}t_j,
 \tag{OC14}
\]

则实际供给邻域满足 finite Hall 容量。有限 flow 可用实际 s_i 构造 f_ij≥0，行和≤s_i、列和=c t_j、非边为零；有限 max-flow/min-cut 或显式已验证 primal flow 均可作为证书。对正质量 cells，置

\[
 \pi_{ij}=f_{ij}
 \left({\sigma|_{B_i}\over s_i}\right)
 \otimes\left({\tau|_{D_j}\over t_j}\right).
 \tag{OC15}
\]

零质量 cells 先隔离，不作除法。求和 π_ij 的 supply 边缘≤σ，target 边缘=cτ，且支持原闭坐标序。这个提升保留同一个实际 supply；不是逐 cut 各自挑一个来源。已认证下界若用于验证 OC14，也只作 actual s_i 的保守容量，最终 flow 必须有一个共同合法来源实现。

该内证书可能丢掉 cell 边界上的实际可匹配质量；本文不声称网格细化自动收敛，不认证一般连续最优值，也不从有限抽象 Fraction 例子推出 FULL。无穷上集判据的合法性另属父稿。

## OC8. h、空间和核衰减的全部成本

对 C⊂P∩B_born 及 f_a=min(w,ak)，OC7 的每个候选值可写成

\[
 \begin{aligned}
 L_a(C)={}&h(P)-\mu((P\cap B_{\rm born})\setminus C)
 -(\mu-\Lambda_{\rm cap})(C)-\Theta(C)\\
 &-\int_C(1-f_a)\,d\eta-a\mathfrak B.
 \end{aligned}
 \tag{OC16}
\]

这来自 μ(C)−(μ−Λ_cap)(C)−Θ(C)=η(C)。所有显示扣项非负：order/空间截断损失、来源包络缺失、不能重复供给的 protected target、真实 w 与 DK0 衰减、原同 α 未捕获预算。Θ(C) 在此为未加权质量，不是 τ(C)。P 的 heavy 质量不能自动删除任一扣项；特别 h 中被 V、born、order cut 或 K0/w 排除的质量没有成为 neutral。

所有 cut 共享同一个预算 B，不按 ancestor、cut、target 重新领取 reserve。检验多个 a 或 cut 本身不是把多个正来源价相加；要支付实际交通，仍须一个共同 c 的全部条件。反之，独立运行不同原 windows/carriers/j 时，必须保留原来源重用与菜单费用，本文不新增无费 disjointness。

## OC9. 原 FTC 接口与首个未付费用

若上述证书提供 π，则 OC3 在每个配对上给 neutral 的衰减不快于 target。因此原**同一分母**中的 G_N(t)≥cG_A(t)。沿原 R192 逐 u FTC，保留原删除、h_stop/cutoff、same α、reciprocal 和外支持，可使用

\[
 \mathrm{Raw}\le C_{\rm rec}\,\mathbb E\sum_V\int q\,dx
 \int\min\!\left\{\psi,{2\over1+c_u}\right\}\,d\lambda,
 \quad C_{\rm rec}={16\Lambda\over3K\kappa}.
 \tag{OC17}
\]

这里 q 是原共同固定值；λ 是原 HB 校准实际交通，始终保留原 unique-j 选择与全部原 mask，共同 receiver 上总质量≤1。本文不重新按接收点归一来源，不把 π 当作 λ 或 Pi。若实际每个被选择 row/u 的共同匹配比例满足 2C_rec/(1+c_u)≤ε，该子支付 ε∫q dx。τ=0 时原 target 交通为零先除；零 α、零核等边界按 OC1–2 和 OC5 分支，不除以它们。

尚未证明的是：实际剩余 late/tiny/low-tree 域内，OC14 或全上集 OC9 能达到所需同一大 c，或其失败 cut 能由线性共同父来源根阶预算支付。OC16 给出可逐项核查的具体障碍而非一个新命名未知 moment。对单 cut 的 exact robust 值、有限完整 cut 算法和保守 continuous 内证书是本稿新增工具；一般全局付款仍缺这些实际几何扣项的控制。
