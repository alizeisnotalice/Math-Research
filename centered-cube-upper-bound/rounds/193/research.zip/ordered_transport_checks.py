#!/usr/bin/env python3
"""Exact finite ordered transport cuts/plans and numerical ratio-curve checks."""
from fractions import Fraction as F
from collections import deque
from pathlib import Path
import argparse,hashlib,json
import mpmath as mp
HERE=Path(__file__).resolve().parent
Z=F(0)
def sm(xs):return sum(xs,Z)
def fs(xs):return list(map(F,xs))
def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x

def flow_plan(sigma,tau,edge,c):
 ns,nt=len(sigma),len(tau);N=ns+nt+2;source=0;sink=N-1;cap=[[Z]*N for _ in range(N)];BIG=sm(sigma)+c*sm(tau)+1
 for i,v in enumerate(sigma):cap[source][1+i]=v
 for i in range(ns):
  for j in range(nt):
   if edge[i][j]:cap[1+i][1+ns+j]=BIG
 for j,v in enumerate(tau):cap[1+ns+j][sink]=c*v
 residual=[row[:] for row in cap];value=Z;augmentations=0
 while True:
  previous=[None]*N;previous[source]=source;queue=deque([source])
  while queue and previous[sink] is None:
   u=queue.popleft()
   for v in range(N):
    if residual[u][v]>0 and previous[v] is None:previous[v]=u;queue.append(v)
  if previous[sink] is None:break
  path=[];v=sink
  while v!=source:path.append((previous[v],v));v=previous[v]
  amount=min(residual[u][v] for u,v in path)
  for u,v in path:residual[u][v]-=amount;residual[v][u]+=amount
  value+=amount;augmentations+=1
 plan=[[cap[1+i][1+ns+j]-residual[1+i][1+ns+j] if edge[i][j] else Z for j in range(nt)] for i in range(ns)]
 assert all(x>=0 for row in plan for x in row)
 return plan,value,augmentations

def evaluate(name,stage,source_vectors,target_vectors,sigma,tau):
 bz,bv=[fs(v) for v in source_vectors],[fs(v) for v in target_vectors];sigma,tau=fs(sigma),fs(tau);n=len(bz[0]);ns,nt=len(bz),len(bv)
 assert len(sigma)==ns and len(tau)==nt and sm(sigma)>0 and sm(tau)>0 and sm(sigma)!=sm(tau) and all(x>=0 for x in sigma+tau)
 assert all(len(v)==n and v==sorted(v) and all(0<=x<=1 for x in v) for v in bz+bv)
 edge=[[all(z>=v for z,v in zip(x,y)) for y in bv] for x in bz];cuts=[]
 for mask in range(1,2**nt):
  targets=[j for j in range(nt) if mask>>j&1];demand=sm(tau[j] for j in targets)
  if demand==0:continue
  neighbors=[i for i in range(ns) if any(edge[i][j] for j in targets)];supply=sm(sigma[i] for i in neighbors);cuts.append(dict(target_subset=targets,source_neighbors=neighbors,supply=supply,target_mass=demand,ratio=supply/demand))
 dual=min(cuts,key=lambda x:x['ratio']);c=dual['ratio'];plan,value,iterations=flow_plan(sigma,tau,edge,c);source_marg=[sm(row) for row in plan];target_marg=[sm(plan[i][j] for i in range(ns)) for j in range(nt)]
 assert value==c*sm(tau)==sm(source_marg) and all(x<=s for x,s in zip(source_marg,sigma)) and target_marg==[c*t for t in tau]
 assert all(not plan[i][j] or edge[i][j] for i in range(ns) for j in range(nt))
 assert c*dual['target_mass']==dual['supply'] and (c+F(1,1000))*dual['target_mass']>dual['supply']
 old_good=[i for i in range(ns) if all(tau[j]==0 or edge[i][j] for j in range(nt))];old_mass=sm(sigma[i] for i in old_good);old_c=old_mass/sm(tau);singletons=[x['ratio'] for x in cuts if len(x['target_subset'])==1];naive=min(singletons)
 clocks={F(0),F(1,2),F(1)};inside=sorted({x for v in bz+bv for x in v if 0<x<1})
 if inside:clocks.update([inside[0],inside[-1]])
 clocks=sorted(clocks);curve=[]
 for r in clocks:
  loss_z=[sm(max(r-x,0) for x in v) for v in bz];loss_v=[sm(max(r-x,0) for x in v) for v in bv]
  assert all(not plan[i][j] or loss_z[i]<=loss_v[j] for i in range(ns) for j in range(nt))
  values=[]
  for prec in [25,40]:
   mp.mp.dps=prec
   def mm(x):return mp.mpf(x.numerator)/x.denominator
   gz=[mp.exp(-mm(x)) for x in loss_z];gv=[mp.exp(-mm(x)) for x in loss_v];GN=sum(mm(s)*g for s,g in zip(sigma,gz));GA=sum(mm(t)*g for t,g in zip(tau,gv));transportZ=sum(mm(plan[i][j])*gz[i] for i in range(ns) for j in range(nt));transportV=sum(mm(plan[i][j])*gv[j] for i in range(ns) for j in range(nt));rhs=mm(c)*GA;scale=max(mp.mpf(1),abs(GN),abs(rhs));tol=scale*mp.mpf(10)**(-prec+5)
   assert GN+tol>=transportZ and transportZ+tol>=transportV and abs(transportV-rhs)<tol and GN+tol>=rhs
   values.append(dict(dps=prec,GN=mp.nstr(GN,prec+5),GA=mp.nstr(GA,prec+5),transport_source=mp.nstr(transportZ,prec+5),transport_target=mp.nstr(transportV,prec+5),c_GA=mp.nstr(rhs,prec+5),GN_over_GA=mp.nstr(GN/GA,prec+5)))
  relative=abs(mp.mpf(values[0]['GN'])-mp.mpf(values[1]['GN']))/max(1,abs(mp.mpf(values[1]['GN'])));assert relative<mp.mpf('1e-18')
  curve.append(dict(r=r,source_losses=loss_z,target_losses=loss_v,values=values,GN_relative_precision_difference=mp.nstr(relative,12)))
 result=dict(name=name,stage=stage,n=n,source_thresholds=bz,target_thresholds=bv,sigma=sigma,tau=tau,total_sigma=sm(sigma),total_tau=sm(tau),edge_relation=edge,enumerated_positive_demand_cuts=cuts,c_star=c,dual_cut=dual,dual_epsilon_infeasible=F(1,1000),plan=plan,source_marginal=source_marg,target_marginal=target_marg,unused_supply=[s-x for s,x in zip(sigma,source_marg)],maxflow_value=value,augmentations=iterations,old_all_target_dominating_source_indices=old_good,old_all_target_source_mass=old_mass,old_all_target_c=old_c,unsafe_independent_singleton_c=naive,curve_checks=curve,all_checks_pass=True)
 if name=='shared_supply_cannot_be_reused':
  _,naive_value,_=flow_plan(sigma,tau,edge,naive);assert naive>c and naive_value<naive*sm(tau);result['expected_failure_of_independent_target_reuse']=dict(unsafe_c=naive,required_total=naive*sm(tau),delivered=naive_value,correct_whole_target_c=c)
 return result

def run():
 Q=F;rows=[]
 rows.append(evaluate('matching_positive_old_esssup_zero','initial',[[Q(1,5),Q(9,10)],[Q(3,5),Q(7,10)]],[[Q(1,5),Q(9,10)],[Q(3,5),Q(7,10)]],[1,1],[1,Q(1,2)]))
 rows.append(evaluate('shared_supply_cannot_be_reused','initial',[[Q(9,10)]*2],[[Q(1,5),Q(3,10)],[Q(3,10),Q(2,5)]],[1],[1,1]))
 rows.append(evaluate('one_source_dominates_all','initial',[[Q(4,5),Q(9,10)]],[[Q(1,10),Q(1,5)],[Q(1,2),Q(7,10)]],[1],[Q(1,2),Q(1,4)]))
 rows.append(evaluate('inaccessible_positive_target','initial',[[0,0]],[[Q(1,10),Q(1,10)]],[1],[Q(1,2)]))
 rows.append(evaluate('zero_mass_edges','stress',[[0,Q(1,2),1],[Q(1,5),Q(3,5),Q(9,10)],[Q(4,5),Q(9,10),1]],[[Q(1,10),Q(2,5),Q(4,5)],[Q(3,10),Q(7,10),Q(19,20)],[0,0,0]],[0,Q(3,4),Q(1,4)],[Q(1,2),Q(3,4),0]))
 rep=[Q(1,5),Q(1,2),Q(4,5)];hi=[Q(2,5),Q(7,10),1]
 rows.append(evaluate('repeated_thresholds','stress',[rep,rep,hi],[rep,rep,hi],[Q(1,5),Q(3,10),Q(1,4)],[Q(2,5),Q(2,5),Q(1,10)]))
 rows.append(evaluate('zero_target_with_inaccessible_vector','stress',[[Q(1,2)]*4, [1]*4],[[Q(1,4)]*4,[1]*4],[Q(3,10),0],[Q(1,5),0]))
 rows.append(evaluate('large_mass_ratio','stress',[[Q(3,4)]*4],[[Q(1,4)]*4],[10**6],[Q(1,10**6)]))
 rows.append(evaluate('small_mass_ratio','stress',[[Q(3,4)]*5],[[Q(1,4)]*5],[Q(1,1000)],[1000]))
 for n in range(2,7):
  bz=[[Q(1,4)]*(n-1)+[Q(3,4)],[Q(1,2)]*n,[Q(3,4)]*n,[1]*n];bv=[[Q(1,5)]*(n-1)+[Q(2,3)],[Q(2,5)]*n,[Q(2,3)]*n,[1]*n]
  rows.append(evaluate('expanded_dimension_'+str(n),'expanded',bz,bv,[Q(1,n),Q(1,2),Q(1,n+2),0],[Q(1,3),Q(1,2),Q(1,n+1),0]))
 a=[0,Q(1,5),Q(2,5),Q(3,5),Q(4,5),1];b=[Q(1,10),Q(3,10),Q(1,2),Q(7,10),Q(9,10),1];c=[Q(1,2)]*6
 rows.append(evaluate('expanded_sparse_long_vector','expanded',[a,b,c,[1]*6],[a,c,b],[Q(3,10),Q(1,5),Q(1,10),0],[Q(2,5),Q(1,4),Q(3,20)]))
 assert rows[0]['old_all_target_source_mass']==0 and rows[0]['c_star']==1 and rows[1]['c_star']==Q(1,2)
 root=Path(mp.__file__).resolve().parent;sha=hashlib.sha256()
 for p in sorted(root.rglob('*.py')):sha.update(p.relative_to(root).as_posix().encode());sha.update(p.read_bytes())
 return enc(dict(schema='r193_ordered_transport_v1',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependencies=dict(mpmath_version=mp.__version__,mpmath_source_tree_sha256=sha.hexdigest()),cases=rows,summary=dict(cases=len(rows),initial_cases=4,stress_cases=5,expanded_cases=6,dimensions=list(range(2,7)),all_exact_plan_cut_checks_pass=True,all_numerical_curve_checks_pass=True),limitations=['Finite sorted rational threshold model, not original FULL/FIRST/history or a continuous transport theorem certificate','Sigma and tau are finite unequal-total positive measures with possible zero atoms; neither is normalized to the other','All target demands c tau use the same source capacities jointly; independent per-target reuse is explicitly rejected','Exp curves use 25/40 dps numerical controls, not interval errors; exact edges/marginals/cuts use Fraction','The transport plan certifies denominator comparison only and does not reassign original traffic or Pi','No general n growth or unconditional all-input matching guarantee is inferred']))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'ordered_transport_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
