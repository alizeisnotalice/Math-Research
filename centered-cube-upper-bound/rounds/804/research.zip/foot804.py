"""Exact four-price / three-receiver footprint checks for research round 804."""
from argparse import ArgumentParser
from fractions import Fraction as F
from itertools import product
from math import comb, factorial, prod
from pathlib import Path
import json
import platform

import sympy as sp
import flint


def box(q, t):
    return (1 + q * t) ** 2 * (1 + 4 * q * t)


def symbolic():
    q, t, a = sp.symbols("q t a", positive=True)
    # Positive/negative excursions are from opposite faces of a fixed interval.
    ans = 0
    for positive in range(4):
        for negative in range(4 - positive):
            k = positive + negative
            ways = comb(3, k) * comb(k, positive)
            if positive and negative:
                simplex = sp.integrate(positive * a ** (positive - 1) *
                                       (q * t - a) ** negative, (a, 0, q * t))
            else:
                simplex = (q * t) ** k
            ans += ways * simplex
    assert sp.expand(ans - box(q, t)) == 0
    return str(sp.factor(ans))


def lattice(a, t):
    ints = range(-a - t, a + t + 1)
    return sum(max(0, max(w) - a) + max(0, -min(w) - a) <= t
               for w in product(ints, repeat=3))


def volume_probe(a, t):
    # Direct grid count. This leading coefficient is an independent
    # finite polynomial check, separate from the symbolic integration.
    vals = [lattice(k * a, k * t) for k in range(4)]
    leading = F(vals[3] - 3 * vals[2] + 3 * vals[1] - vals[0], 6)
    expected = (2 * a) ** 3 * box(F(t, 2 * a), 1)
    assert leading == expected
    return dict(half_width=a, excursion_limit=t, lattice_counts=vals,
                recovered_true_volume=str(leading))


def compositions(n, parts):
    if parts == 1:
        yield (n,)
    else:
        for first in range(n + 1):
            for tail in compositions(n - first, parts - 1):
                yield (first,) + tail


def norm_check(n, m, q):
    boundaries = [F(j, m) for j in range(m + 1)]
    volumes = [F(1)] + [box(q, b) - box(q, a) for a, b in zip(boundaries, boundaries[1:])]
    total_types = comb(n + m, m)
    raw_volume = F(0)
    unit = F(0)
    total_sequences = 0
    positive_types = 0
    # All coordinate volumes and the mass assigned to each histogram
    # are computed separately in exact arithmetic.
    powers = [[v ** j for j in range(n + 1)] for v in volumes]
    fac = [factorial(j) for j in range(n + 1)]
    for hist in compositions(n, len(volumes)):
        multinomial = fac[n] // prod(fac[k] for k in hist)
        vol = multinomial * prod(ps[k] for ps, k in zip(powers, hist))
        total_sequences += multinomial
        raw_volume += vol
        density = 1 / (total_types * vol)
        unit += density * vol
        positive_types += 1
    assert total_sequences == len(volumes) ** n
    assert unit == 1 and raw_volume == box(q, 1) ** n
    # A positive-width mixed pattern with inefficient allocation. Choose
    # a type of maximal weighted volume on 1/4 <= a <= 1/2.
    clipped = [F(0)] + [max(F(0), box(q, min(b, F(1, 2))) -
                                  box(q, max(a, F(1, 4))))
                         if max(a, F(1, 4)) < min(b, F(1, 2)) else F(0)
                         for a, b in zip(boundaries, boundaries[1:])]
    denom, badtype = max(
        (fac[n] // prod(fac[c] for c in hist)
         * prod(b ** c for b, c in zip(clipped, hist)), hist)
        for hist in compositions(n, len(volumes)))
    assert total_types * denom >= sum(clipped) ** n
    eps = F(1, 512 * n)
    h = 1 + F(1, 32 * n)
    span_factor = F(1)
    for index, count in enumerate(badtype):
        if count:
            assert index
            lo = max(F(1, 4), boundaries[index - 1])
            hi = min(F(1, 2), boundaries[index])
            forced = (lo + hi) / 2
            step = 2 * h * q * forced + h - 1 + eps
            prices = (F(0), step / 3, 2 * step / 3, step)
            owners = (prices[0] - 1 + eps, prices[1] - 1 + eps,
                      prices[2] + 1 - eps, prices[3] + 1 - eps)
            forced_check = (max(0, max(owners[1:]) - h) +
                            max(0, -min(owners[1:]) - h)) / (2 * h * q)
            assert forced_check == forced
            assert max(abs(p - w) for p, w in zip(prices, owners)) < 1
            assert max(abs(p - step / 2) for p in prices) < q
            span_factor *= (1 - step / (2 * h * q)) ** count
    actual_type_volume = (fac[n] // prod(fac[c] for c in badtype)
                          * prod(v ** c for v, c in zip(volumes, badtype)))
    scarce_cost = total_types * actual_type_volume * span_factor
    # Compare with a second geometry with the same source prices and
    # three genuinely disjoint receiver centres in the anchor box.
    # Place each centre at half its original price.  Each is inside
    # its own unit-radius cube, including the extremal fourth price.
    assert q <= F(3, 2) and (h * q + h - 1 + eps) / 2 < 1
    compact_cost = total_types * span_factor
    assert scarce_cost > compact_cost
    # This rational threshold separates two receiver layouts on the
    # same four prices; it is a diagnostic threshold, distinct from e^J.
    threshold = (compact_cost + scarce_cost) / 2
    assert compact_cost < threshold < scarce_cost
    return dict(n=n, positive_bins=m, q=str(q), weak_compositions=total_types,
                positive_type_volumes=positive_types, normalization=str(unit),
                total_dimensionless_Lebesgue_volume=str(raw_volume),
                selected_type=list(badtype), source_span_product=str(span_factor),
                outer_receiver_cost=str(scarce_cost), compact_receiver_cost=str(compact_cost),
                exact_ratio=str(scarce_cost / compact_cost), diagnostic_threshold=str(threshold))


def margin_probe(n, delta):
    from flint import arb, ctx
    ctx.prec = 256
    h = 1 + F(1, 32*n)
    height = delta + h - 1
    active = height / (2*h)
    mean = n * height**2/(4*h)
    threshold = min(height/2, mean/8)
    # In the stated range the positive conditional component is uniform.
    # For j positives the simplex has volume threshold**j/j!.
    probability = sum(comb(n,j) * active**j * (1-active)**(n-j)
                      * (threshold/height)**j / factorial(j) for j in range(n+1))
    def rigorous(x):
        return arb(x.numerator) / arb(x.denominator)
    gap = rigorous(probability).log() + rigorous(mean)/10
    assert gap < 0
    return dict(n=n,delta=str(delta),mean=str(mean),threshold=str(threshold),
                exact_tail=str(probability),certified_log_tail_plus_mean_over_ten=str(gap))


def main():
    p = ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--output", type=Path)
    g.add_argument("--check", type=Path)
    args = p.parse_args()
    stages = [(4, 2, F(5, 4)), (9, 3, F(4, 3)), (18, 4, F(3, 2))]
    result = dict(python=platform.python_version(), machine=platform.machine(),
                  sympy=sp.__version__, flint=flint.__version__, arb_bits=256, symbolic_volume=symbolic(),
                  same_scale_small_parent_margin=[margin_probe(n,d) for n,d in [(8,F(1,4)),(48,F(1,2)),(160,F(3,4))]],
                  physical_grid=[volume_probe(*x) for x in [(1, 0), (1, 1), (1, 2), (2, 3)]],
                  histogram_and_geometric_checks=[norm_check(*x) for x in stages],
                  scope="Exact geometric receiver placements and Lebesgue volumes; finite cutoffs are diagnostic and do not certify all original history conditions.")
    data = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if args.output:
        args.output.write_text(data)
    else:
        assert args.check.read_text() == data
        print("byte-identical")
    print(result["symbolic_volume"], [v["recovered_true_volume"] for v in result["physical_grid"]])
    for v in result["histogram_and_geometric_checks"]:
        print(v["n"], v["weak_compositions"], v["selected_type"], v["exact_ratio"])


if __name__ == "__main__":
    main()
