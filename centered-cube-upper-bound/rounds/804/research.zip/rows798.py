#!/usr/bin/env python3
"""Actual two-arm marked rows and public witness/source budgets, exactly."""
import argparse
from collections import defaultdict, deque
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path
import platform


SOURCE=(F(-8),F(8))
PERIOD=F(1,2)
PUBLIC=[(F(1,8),F(3,16)),(F(69,16),F(71,16))]
SHRINK=32


def total(x):
    return sum(x,F(0))


def iv(a,b):
    return F(a),F(b)


def length(a):
    return max(F(0),a[1]-a[0])


def point(a):
    return total(a)/2


def clip(*x):
    return max(a[0] for a in x),min(a[1] for a in x)


def inside(a,b):
    return b[0]<=a[0]<=a[1]<=b[1]


def volume_bucket(m):
    d=F(1)
    while m>=2*d:
        d*=2
    while m<d:
        d/=2
    return d


def owner(q,share):
    h=share*length(q)/(2*SHRINK)
    m=point(q)
    return m-h,m+h


def real_mass(box,amplitude):
    lo,hi=clip(box,SOURCE)
    if lo>=hi:
        return F(0)

    def primitive(z):
        r=z%PERIOD
        return z+amplitude*min(r,PERIOD-r)

    return primitive(hi)-primitive(lo)


def normal(row):
    m=total(row)
    assert m>0
    return [x/m for x in row]


def metric(p,q):
    return total(abs(a-b) for a,b in zip(p,q))/2


def top_integral(scores,masses,cap):
    """Greedy physical mass up to cap and its independent threshold dual."""
    left=cap
    value=F(0)
    partial=None
    for k in sorted(range(len(scores)),key=lambda j:(-scores[j],j)):
        m=masses[k]
        used=min(m,left)
        value+=used*scores[k]
        left-=used
        if 0<used<m:
            partial=dict(atom=k,whole=m,used=used,score=scores[k])
        if not left:
            break
    dual,q=min((cap*q+total(m*max(F(0),p-q) for m,p in zip(masses,scores)),q)
               for q in {F(0),*scores})
    assert value==dual
    return dict(value=value,threshold=q,partial=partial,unused=left)


def public_match(p,m,bits):
    """Maximize matched source under the actual two prescribed marginals."""
    assert total(p)==total(m)==1
    n,k=len(p),len(m)
    s=n+k
    end=s+1
    G=[[] for _ in range(end+1)]
    cap={}

    def edge(a,b,c):
        G[a].append(b)
        G[b].append(a)
        cap[a,b]=c
        cap[b,a]=F(0)

    for i,pi in enumerate(p):
        edge(s,i,pi)
    for j,mu in enumerate(m):
        edge(n+j,end,mu)
        for i in bits[j]:
            edge(i,n+j,F(2))
    paid=F(0)
    while True:
        seen={s:-1}
        wait=deque([s])
        while wait and end not in seen:
            u=wait.popleft()
            for v in G[u]:
                if cap[u,v]>0 and v not in seen:
                    seen[v]=u
                    wait.append(v)
        if end not in seen:
            break
        path=[]
        v=end
        while v!=s:
            u=seen[v]
            path.append((u,v))
            v=u
        step=min(cap[e] for e in path)
        for a,b in path:
            cap[a,b]-=step
            cap[b,a]+=step
        paid+=step
    dual,cut=min((total(p[i] for i in range(n) if not flag[i])+
                  total(m[j] for j,b in enumerate(bits) if any(flag[i] for i in b)),flag)
                 for flag in product((0,1),repeat=n))
    assert paid==dual
    paid_plan={(i,j):cap[n+j,i] for j,b in enumerate(bits) for i in b if cap[n+j,i]}
    assert total(paid_plan.values())==paid
    p_left=[p[i]-total(x for (a,_),x in paid_plan.items() if a==i) for i in range(n)]
    m_left=[m[j]-total(x for (_,b),x in paid_plan.items() if b==j) for j in range(k)]
    assert min(p_left+m_left)>=0 and total(p_left)==total(m_left)==1-paid
    assert all(not(p_left[i] and m_left[j]) for j,b in enumerate(bits) for i in b)
    completed=paid_plan.copy()
    if paid<1:
        for i,j in product(range(n),range(k)):
            add_mass=p_left[i]*m_left[j]/(1-paid)
            if add_mass:
                completed[i,j]=completed.get((i,j),F(0))+add_mass
    assert [total(w for (a,j),w in completed.items() if a==i) for i in range(n)]==p
    assert [total(w for (i,b),w in completed.items() if b==j) for j in range(k)]==m
    assert total(w for (i,j),w in completed.items() if i in bits[j])==paid
    return dict(success=paid,dual=dual,cut_labels=[i for i,chosen in enumerate(cut) if chosen],
                complete_actual_marginal_transport=[(i,j,w) for (i,j),w in sorted(completed.items())],
                paid_arcs=[(i,j,w) for (i,j),w in sorted(paid_plan.items())])


def one_case(name,T,U,shares,parts,gates,amplitude):
    owned_t=[owner(A,s) for A,s in zip(T,shares)]
    owned_u=[owner(A,F(1)) for A in U]
    ordered=sorted(owned_t+owned_u)
    assert all(a[1]<b[0] for a,b in zip(ordered,ordered[1:]))
    m_t=list(map(length,T))
    m_u=list(map(length,U))
    assert [real_mass(A,amplitude) for A in T+U]==m_t+m_u
    I_t=list(map(length,owned_t))
    I_u=list(map(length,owned_u))
    bins=list(map(volume_bucket,m_t))
    dset=sorted(set(bins))
    nt=len(T)

    cuts=sorted({*SOURCE,*(x for A in T+U+PUBLIC for x in A),
                  *(x for a in gates.values() for x in a if x is not None)})
    prices=list(zip(cuts,cuts[1:]))
    price_mu=[real_mass(a,amplitude) for a in prices]
    assert min(price_mu)>0
    A_price=[{t for t,A in enumerate(T) if inside(a,A)} for a in prices]
    public_indices=[i for i,a in enumerate(prices) if any(inside(a,F0) for F0 in PUBLIC)]
    public_mu=total(price_mu[i] for i in public_indices)
    assert public_mu==total(real_mass(x,amplitude) for x in PUBLIC)

    # Same true intersection-price / physical owner reference on both arms.
    refs=[]
    lookup={}
    for u,B in enumerate(U):
        extent=owned_u[u]
        step=length(extent)/parts
        for k in range(parts):
            R=(extent[0]+k*step,extent[0]+(k+1)*step)
            for a,x in enumerate(prices):
                if inside(x,B):
                    lookup[u,k,a]=len(refs)
                    xi=I_u[u]*length(R)*price_mu[a]/(m_u[u]*length(extent))
                    refs.append(dict(u=u,k=k,a=a,receiver=R,price=x,xi=xi))
    xis=[r["xi"] for r in refs]
    assert total(xis)==total(I_u)

    neighbors={}
    for t,u in product(range(nt),range(len(U))):
        X=clip(T[t],U[u])
        mx=real_mass(X,amplitude)
        if m_u[u]<m_t[t] and mx:
            neighbors[t,u]=(mx/(m_t[t]*m_u[u]),X,mx)
    d=[total(I_u[u]*q[0] for (j,u),q in neighbors.items() if j==t) for t in range(nt)]
    assert min(d)>0
    law=[{} for _ in T]
    admitted=[set() for _ in T]
    for t in range(nt):
        for i,r in enumerate(refs):
            u,k,a=r["u"],r["k"],r["a"]
            if (t,u) not in neighbors or t not in A_price[a]:
                continue
            K,X,mx=neighbors[t,u]
            true=I_u[u]*K/d[t]*price_mu[a]/mx*length(r["receiver"])/length(owned_u[u])
            assert true==xis[i]/(m_t[t]*d[t])>0
            law[t][i]=true
            stop=gates.get((t,u),(None,)*parts)[k]
            accepted=X if stop is None else (X[0],min(X[1],stop))
            if inside(prices[a],accepted):
                admitted[t].add(i)
        assert total(law[t].values())==1 and admitted[t]

    raw={D:defaultdict(F) for D in dset}
    marked={D:defaultdict(F) for D in dset}
    physical_row={D:{} for D in dset}
    for t in range(nt):
        D=bins[t]
        W=I_t[t]*d[t]
        for i,pi in law[t].items():
            if i in admitted[t]:
                p=physical_row[D].setdefault(i,[F(0)]*nt)
                p[t]+=W*pi
                assert W*pi==I_t[t]*xis[i]/m_t[t]
            for j,pj in law[t].items():
                edge=W*pi*pj
                raw[D][i,j]+=edge
                if i in admitted[t]:
                    marked[D][i,j]+=edge

    # Independent order: price/owner reference atoms first, then labels and
    # the original denominator of the actual two-arm law.
    summary={}
    for D in dset:
        labels=[t for t in range(nt) if bins[t]==D]
        both_raw=F(0)
        transposed_same_gate=F(0)
        asymmetry=0
        peak_rows=physical_row[D]
        h={i:total(ps) for i,ps in peak_rows.items()}
        max_density=F(0)
        for i,j in product(range(len(refs)),repeat=2):
            parent_ok=[t for t in labels if i in law[t] and j in law[t]]
            base=xis[i]*xis[j]*total(I_t[t]/(m_t[t]**2*d[t]) for t in parent_ok)
            assert raw[D].get((i,j),F(0))==raw[D].get((j,i),F(0))==base
            both_raw+=base
            left=xis[i]*xis[j]*total(I_t[t]/(m_t[t]**2*d[t]) for t in parent_ok if i in admitted[t])
            swapped=xis[i]*xis[j]*total(I_t[t]/(m_t[t]**2*d[t]) for t in parent_ok if j in admitted[t])
            assert marked[D].get((i,j),F(0))==left
            assert marked[D].get((j,i),F(0))==swapped
            transposed_same_gate+=swapped
            asymmetry+=(left!=swapped)
            if i in h:
                post=peak_rows[i]
                reference_density=total(post[t]/h[i]/(m_t[t]*d[t]) for t in parent_ok)
                assert left==h[i]*xis[j]*reference_density
                max_density=max(max_density,reference_density)
        true_unmarked=total(I_t[t]*d[t] for t in labels)
        marked_total=total(marked[D].values())
        assert both_raw==true_unmarked==total(raw[D].values())
        assert transposed_same_gate==marked_total==total(h.values())<=true_unmarked
        assert all(total(marked[D].get((i,j),F(0)) for j in range(len(refs)))==h[i] for i in h)
        summary[D]=dict(unmarked_total=true_unmarked,unmarked_sorted_swap=both_raw,
                        one_arm_mark_total=marked_total,transposed_with_same_mark_total=transposed_same_gate,
                        nonsymmetric_marked_entries=asymmetry,nonzero_marked=len(marked[D]),
                        rows=len(h),rows_with_determined_parent=sum(sum(v>0 for v in p)==1 for p in peak_rows.values()),
                        maximal_conditional_right_density_relative_to_xi=max_density)

    comparisons={}
    extrema={D:dict(price_only=F(0),receiver_only=F(0),wrong_redraw_U=F(0)) for D in dset}
    for D in dset:
        by_price=defaultdict(lambda:[F(0)]*nt)
        by_recv=defaultdict(lambda:[F(0)]*nt)
        for i,r in physical_row[D].items():
            u,k,a=refs[i]["u"],refs[i]["k"],refs[i]["a"]
            for t,w in enumerate(r):
                by_price[u,a][t]+=w
                by_recv[u,k][t]+=w
        for i,p in physical_row[D].items():
            u,k,a=refs[i]["u"],refs[i]["k"],refs[i]["a"]
            actual=normal(p)
            only_z=normal(by_price[u,a])
            only_U=normal(by_recv[u,k])
            right_rows=[lookup[u,b,a] for b in range(parts) if lookup[u,b,a] in physical_row[D]]
            geometric=[length(refs[j]["receiver"])/length(owned_u[u]) for j in right_rows]
            data_weights=normal([total(physical_row[D][j]) for j in right_rows])
            assert [total(w*normal(physical_row[D][j])[t] for w,j in zip(data_weights,right_rows))
                    for t in range(nt)]==only_z
            fake_weights=normal(geometric)
            fake=[total(w*normal(physical_row[D][j])[t] for w,j in zip(fake_weights,right_rows)) for t in range(nt)]
            fields=dict(actual=actual,price_only=only_z,receiver_only=only_U,wrong_redraw_U=fake)
            for tag in extrema[D]:
                extrema[D][tag]=max(extrema[D][tag],metric(actual,fields[tag]))
            fields.update(redraw_geometric_rejection=1-total(geometric),data_weights_of_U_given_z=data_weights,
                          normalized_geometric_weights_of_U=fake_weights)
            comparisons[D,i]=fields

    # A deliberately shared genuinely observed old price and the first U slab.
    where=next(a for a,q in enumerate(prices) if q[0]<F(7,10)<q[1])
    chosen_ref=lookup[0,0,where]
    assert 4 in dset and chosen_ref in physical_row[4]
    chosen=comparisons[4,chosen_ref]
    assert sum(v>0 for v in chosen["actual"])>=2
    assert all(metric(chosen["actual"],chosen[x])>0 for x in ("price_only","receiver_only","wrong_redraw_U"))
    assert chosen["price_only"]!=chosen["wrong_redraw_U"]
    for key in extrema[4]:
        assert extrema[4][key]>0

    probes={}
    for D in dset:
        if chosen_ref not in physical_row[D]:
            continue
        profiles=comparisons[D,chosen_ref]
        p=profiles["actual"]
        original_amount=total(physical_row[D][chosen_ref])
        S=[total(p[t] for t in a) for a in A_price]
        assert S[where]==1
        caps=D
        hits={}
        for tag in ("actual","price_only","receiver_only","wrong_redraw_U"):
            p0=profiles[tag]
            score=[total(p0[t] for t in a) for a in A_price]
            solved=top_integral(score,price_mu,caps)
            hits[tag]=dict(optimum=solved["value"]/caps,capacity=caps,certificate=solved)

        # Public source F is preassigned. A genuine old z is a full-domain
        # single witness, but neither its location nor its law is used here.
        public_points=[point(prices[a]) for a in public_indices]
        endpoints=sorted({v for A in PUBLIC for v in A})
        point_masks=[{t for t,A in enumerate(T) if A[0]<=q<=A[1]} for q in public_points+endpoints]
        assert public_points
        witnesses={}
        for k in (1,2):
            value,choice,labels=max((total(p[t] for t in labels),idx,tuple(sorted(labels)))
                                    for i in range(1,k+1)
                                    for idx in combinations(range(len(point_masks)),i)
                                    for labels in [set().union(*(point_masks[j] for j in idx))])
            witnesses[k]=dict(coverage=value,points=[(public_points+endpoints)[j] for j in choice],
                              captured_labels=labels)
        public_caps=[price_mu[a]/public_mu for a in public_indices]
        public_masks=[A_price[a] for a in public_indices]
        independent=total(v*S[a] for v,a in zip(public_caps,public_indices))
        own_public=[total(price_mu[a] for a in public_indices if t in A_price[a]) for t in range(nt)]
        assert independent==total(p[t]*m/public_mu for t,m in enumerate(own_public))
        transported=public_match(p,public_caps,public_masks)
        assert independent<=transported["success"]<=witnesses[2]["coverage"]

        actual_right=[marked[D].get((chosen_ref,j),F(0))/original_amount for j in range(len(refs))]
        public_right=total(x for j,x in enumerate(actual_right) if refs[j]["a"] in public_indices)
        assert total(actual_right)==1
        assert public_right==total(p[t]*total(w for j,w in law[t].items() if refs[j]["a"] in public_indices)
                                   for t in range(nt))
        assert 0<=public_right<1
        by_z=defaultdict(F)
        by_F_and_owner=defaultdict(F)
        for j,w in enumerate(actual_right):
            a,u=refs[j]["a"],refs[j]["u"]
            by_z[a]+=w
            if a in public_indices:
                by_F_and_owner[u]+=w
        public_conditional_density=(max(by_z[a]*public_mu/(public_right*price_mu[a])
                                        for a in public_indices) if public_right else None)
        cap_xi=total(xis)/8
        right_top=top_integral([w/q for w,q in zip(actual_right,xis)],xis,cap_xi)
        cut=right_top["partial"]
        if cut:
            cell=refs[cut["atom"]]
            a,b=cell["receiver"]
            U_piece=(a,a+(b-a)*cut["used"]/cut["whole"])
            assert cell["xi"]*length(U_piece)/(b-a)==cut["used"]
            cut["actual_receiver_slice"]=U_piece
        probes[D]=dict(physical_row=refs[chosen_ref],unconditional_this_row_amount=original_amount,
                       exact_posteriors=profiles,active_labels=[t for t,w in enumerate(p) if w],
                       cap_mu_scores=hits,full_parent_coverage_using_known_old_z=1,
                       public_F=PUBLIC,actual_mu_F=public_mu,actual_terminals_public_mu=own_public,
                       publicly_selected_witnesses=witnesses,independent_public_F_capture=independent,
                       best_coupled_public_F_transport=transported,actual_remaining_old_z_in_F=public_right,
                       actual_right_F_and_one_old_owner_capture=dict(by_F_and_owner),
                       conditional_actual_zprime_density_inside_F_vs_public=public_conditional_density,
                       right_top_given_eighth_xi_budget=right_top,right_xi_budget=cap_xi)
    assert probes[4]["publicly_selected_witnesses"][1]["coverage"]<1
    if name=="expanded":
        assert len(dset)>=2 and 2 in probes

    return dict(stage=name,terminal_A=T,actual_old_A=U,terminal_owners=owned_t,old_owners=owned_u,
                real_source_amplitude=amplitude,original_true_d=d,terminal_absolute_mass_bins=bins,
                directional_old_z_caps=[(t,u,row) for (t,u),row in sorted(gates.items())],
                common_xi_mass=total(xis),left_and_right_reference_atoms=len(refs),
                exact_price_cells=prices,actual_price_cell_mu=price_mu,
                by_absolute_bin={str(D):v for D,v in summary.items()},
                maximum_distance_to_actual_posterior={str(D):v for D,v in extrema.items()},
                same_actual_observation_comparison={str(D):v for D,v in probes.items()})


def suite():
    A=[iv(0,4),iv("1/4","17/4"),iv("1/2","9/2")]
    U=[iv(-1,1),iv(3,5),iv("9/8","25/8")]
    G={(0,0):(None,F(5,8),F(7,8),F(3,4)),
       (1,0):(F(7,8),None,F(9,16),F(11,16)),
       (2,0):(None,None,F(5,8),F(15,16))}
    return [
      one_case("initial",[A[0],A[2]],[U[0],iv("5/2","9/2")],[F(1),F(3,4)],2,
               {(0,0):(None,F(5,8))},F(1,4)),
      one_case("pressure",A,U,[F(1),F(3,4),F(1,2)],4,G,F(1,2)),
      one_case("expanded",A+[iv("3/8","27/8"),iv("7/8","31/8")],U,
               [F(1),F(3,4),F(1,2),F(7,8),F(5,8)],4,
               {**G,(3,0):(None,F(13,16),None,F(7,8)),(4,0):(None,None,F(15,16),None)},F(3,4)),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    act=p.add_mutually_exclusive_group()
    act.add_argument("--output",type=Path)
    act.add_argument("--check",type=Path)
    args=p.parse_args()
    stages=suite()
    result=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
                command="python -B rows798.py --check rows798.json",precision="exact library Fraction",
                scope=dict(true_support=SOURCE,phase_period=PERIOD,source_density="alternating positive 1±amplitude",
                           physical_rows="physical old u, actual Lebesgue receiving slab U, true old source cell z, and central absolute dyadic mass bin",
                           joint_geometry="both originally independent true old half-edges given their exact central father and complete old d; one directional source screen afterward",
                           wrong_U="average posteriors at new uniform physical U-cell, conditional on a compatible redraw, without true accepted U|z weights",
                           public_witness_scope="F is fixed before seeing a row and point selection uses only the row; the coupled transport is a separate benchmark with both prescribed marginals",
                           excluded="finite one-dimensional old screen only; the original high-dimensional masks are outside this diagnostic",
                           boundaries="closed original parents; exact slab and price endpoints are true nulls"),
                stages=stages)
    payload=json.dumps(result,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(payload)
    if args.check:
        assert args.check.read_text()==payload
    if args.output or args.check:
        for S in stages:
            r=S["same_actual_observation_comparison"]["4"]
            print(S["stage"],"posterior",list(map(str,r["exact_posteriors"]["actual"])),
                  "best1/2",[str(w["coverage"]) for w in r["publicly_selected_witnesses"].values()],
                  "actual z' in F",r["actual_remaining_old_z_in_F"])
        if args.check:
            print("byte-identical")
    else:
        print(payload,end="")


if __name__=="__main__":
    main()
