#!/usr/bin/env python3
"""Exact shared external-source coupling of real oriented two-old-arm records."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
EPS=F(1,64)


def widened(I,base):
    c=base.point(I)
    r=(1+EPS)*base.length(I)/2
    return c-r,c+r


def external(G,D,base):
    return [box for box in ((G[0],min(G[1],D[0])),(max(G[0],D[1]),G[1]))
            if base.length(box)>0]


def coupling(rows,y_mass,M,base,selected=None):
    """Two orders: fixed y then two posterior labels, and fixed ordered labels."""
    n=len(rows)
    Fload=[base.total(M[i]*rows[i][b] for i in range(n)) for b in range(len(y_mass))]
    selected=set(range(len(y_mass))) if selected is None else set(selected)
    pair=[[F(0)]*n for _ in range(n)]
    for b in sorted(selected):
        if not Fload[b]:
            continue
        density=[M[i]*rows[i][b] for i in range(n)]
        assert base.total(density)==Fload[b]
        for i,k in product(range(n),repeat=2):
            pair[i][k]+=y_mass[b]*density[i]*density[k]/Fload[b]
    for i,k in product(range(n),repeat=2):
        assert pair[i][k]==M[i]*M[k]*base.total(
            y_mass[b]*rows[i][b]*rows[k][b]/Fload[b] for b in selected if Fload[b])
        assert pair[i][k]==pair[k][i]
    margins=[M[i]*base.total(y_mass[b]*rows[i][b] for b in selected) for i in range(n)]
    assert margins==[base.total(row) for row in pair]
    assert margins==[base.total(row[i] for row in pair) for i in range(n)]
    total=base.total(margins)
    assert total==base.total(Fload[b]*y_mass[b] for b in selected)
    return Fload,pair,margins,total


def geometry(P,T,A,D,cells,records,keys,M,base):
    n=len(keys)
    total=base.total(w for row in P for w in row)
    assert total>0
    cross_t=F(0)
    cross_u=F(0)
    strict_u=F(0)
    old_hit=F(0)
    old_hit_cross=F(0)
    old_hit_strict=F(0)
    avoid_z=F(0)
    avoid_two=F(0)
    avoid_D_z=F(0)
    avoid_D_two=F(0)
    def expectation(i,predicate):
        return base.total(x["mass"] for x in records[i] if predicate(x))/M[i]
    old_cache={(i,u):expectation(i,lambda r:base.inside(cells[r["z"]],A[u]))
               for i,u in product(range(n),range(len(A)))}
    center_cache={}
    for i,t in product(range(n),range(len(T))):
        center_cache[i,t]=[
          expectation(i,lambda r:base.length(base.clip(cells[r["z"]],box))==0 and (
              not both or base.length(base.clip(cells[r["q"]],box))==0))
          for box in (T[t],D[t]) for both in (False,True)]
    for i,k in product(range(n),repeat=2):
        weight=P[i][k]
        if not weight:
            continue
        t,u=keys[i]
        v,w=keys[k]
        current=(i,w) if (base.length(A[u]),-u)>=(base.length(A[w]),-w) else (k,u)
        p=old_cache[current]
        old_hit+=weight*p
        if t!=v:
            cross_t+=weight
        if u!=w:
            cross_u+=weight
            old_hit_cross+=weight*p
        if base.length(A[u])!=base.length(A[w]):
            strict_u+=weight
            old_hit_strict+=weight*p
        f0,f1,f2,f3=center_cache[i,v]
        g0,g1,g2,g3=center_cache[k,t]
        avoid_z+=weight*f0*g0
        avoid_two+=weight*f1*g1
        avoid_D_z+=weight*f2*g2
        avoid_D_two+=weight*f3*g3
    assert 0<=old_hit_cross<=cross_u<=total and 0<=old_hit_strict<=strict_u<=total
    assert 0<=avoid_D_two<=min(avoid_two,avoid_D_z)<=avoid_z<=cross_t<=total
    return dict(total=total,actual_cross_middle_mass=cross_t,actual_cross_old_mass=cross_u,
                strict_old_size_mismatch_mass=strict_u,
                larger_old_true_z_hit_mass=old_hit,larger_old_true_z_hit_fraction=old_hit/total,
                old_hit_given_distinct=old_hit_cross/cross_u if cross_u else None,
                old_hit_given_strict_size_difference=old_hit_strict/strict_u if strict_u else None,
                actual_middle_mutual_avoid_z_fraction=avoid_z/total,
                actual_middle_mutual_avoid_z_and_q_fraction=avoid_two/total,
                expanded_middle_mutual_avoid_z_fraction=avoid_D_z/total,
                expanded_middle_mutual_avoid_z_and_q_fraction=avoid_D_two/total,
                true_mutual_avoid_z_mass_on_cross_middle=avoid_z)


def diagnostic(name,T,A,G,shares,amp,base):
    N=len(T)
    E=[base.owner(q,s) for q,s in zip(T,shares)]
    O=[base.owner(q,F(1)) for q in A]
    all_E=sorted(E+O)
    assert all(a[1]<b[0] for a,b in zip(all_E,all_E[1:]))
    D=[widened(I,base) for I in T]
    mu=lambda I:base.real_mass(I,amp)
    m=list(map(base.length,T))
    small=list(map(base.length,A))
    I=list(map(base.length,E))
    j=list(map(base.length,O))
    assert list(map(mu,T+A))==m+small
    assert all(base.inside(c,a) for c,a in zip(G,A))
    neighbor={}
    for t,u in product(range(N),range(len(A))):
        whole=base.clip(T[t],A[u])
        v=mu(whole)
        if v and small[u]<m[t]:
            neighbor[t,u]=whole,v,v/(m[t]*small[u])
    d=[base.total(j[u]*row[2] for (r,u),row in neighbor.items() if r==t) for t in range(N)]
    assert all(v>0 for v in d)
    keys=sorted(neighbor)
    ext=[external(G[u],D[t],base) for t,u in keys]
    ext_mass=[base.total(mu(B) for B in row) for row in ext]
    assert min(ext_mass)>0
    assert any(t!=v and u==w and ext[i]!=ext[k]
               for i,(t,u) in enumerate(keys) for k,(v,w) in enumerate(keys))
    ends=sorted({*base.SOURCE,*(F(i,4) for i in range(-32,33)),
                 *(l for B in T+A+G+D for l in B),*(x for group in ext for B in group for x in B)})
    cells=list(zip(ends,ends[1:]))
    y_mass=list(map(mu,cells))
    assert all(w/base.length(B) in (1+amp,1-amp) for w,B in zip(y_mass,cells))
    recv=[[(q[0],base.point(q)),(base.point(q),q[1])] for q in O]
    by_key={q:i for i,q in enumerate(keys)}
    records=[[] for _ in keys]
    for t in range(N):
        both_sides=[]
        for (v,u),(joint,whole,K) in neighbor.items():
            if v!=t:
                continue
            for a,h in product(range(len(cells)),(0,1)):
                if base.inside(cells[a],joint):
                    old_leg=j[u]*K*y_mass[a]/whole*base.length(recv[u][h])/j[u]
                    assert old_leg==y_mass[a]*base.length(recv[u][h])/(m[t]*small[u])
                    both_sides.append((u,a,h,old_leg))
        assert base.total(mass for u,a,h,mass in both_sides)==d[t]
        full=F(0)
        for (u,z,h,w),(v,q,k,r) in product(both_sides,repeat=2):
            if h!=k:
                continue
            value=I[t]/d[t]*w*r
            records[by_key[t,u]].append(dict(t=t,u=u,z=z,q=q,U=recv[u][h],w=recv[v][k],g=v,mass=value))
            full+=value
        assert full==I[t]*d[t]/2
    M=[base.total(e["mass"] for e in group) for group in records]
    assert min(M)>0
    true_r=[[F(1)/ext_mass[i] if any(base.inside(cell,B) for B in ext[i]) else F(0)
            for cell in cells] for i in range(len(keys))]
    freeze_mu=[[F(1)/small[u] if base.inside(cell,A[u]) else F(0) for cell in cells] for t,u in keys]
    freeze_leb=[[base.length(cell)/small[u]/y_mass[b] if base.inside(cell,A[u]) else F(0)
                 for b,cell in enumerate(cells)] for t,u in keys]
    assert all(base.total(w*p for w,p in zip(y_mass,row))==1
               for kernel in (true_r,freeze_mu,freeze_leb) for row in kernel)
    load,P,marg,whole=coupling(true_r,y_mass,M,base)
    assert marg==M
    assert whole==base.total(M)==base.total(I[t]*d[t]/2 for t in range(N))
    # Marginals hold for each full first/second record, without enumerating their product.
    for i,group in enumerate(records):
        for record in group:
            assert record["mass"]*marg[i]/M[i]==record["mass"]
    for i,(t,u) in enumerate(keys):
        assert all(not s or base.length(base.clip(cells[b],D[t]))==0 for b,s in enumerate(true_r[i]))

    pos=[b for b,L in enumerate(load) if L]
    candidate=[]
    for b in pos:
        A0={t for i,(t,u) in enumerate(keys) if true_r[i][b]}
        if len(A0)>1:
            candidate.append(b)
    assert candidate
    y0=max(candidate,key=lambda b:load[b])
    threshold=(min(load[b] for b in pos)+load[y0])/2
    assert 0<threshold<load[y0]
    low={b for b in pos if load[b]<threshold}
    kept=set(pos)-low
    _,_,deleted_marg,loss=coupling(true_r,y_mass,M,base,low)
    S=base.total(y_mass[b] for b in pos)
    assert 0<loss<threshold*base.total(y_mass[b] for b in low)<=threshold*S
    _,high,_,high_mass=coupling(true_r,y_mass,M,base,kept)
    assert high_mass+loss==whole
    # A second scan after dropping a real input class. These physical source
    # cells are new; the first-deleted cells cannot pay twice.
    probe=None
    for i in range(len(keys)):
        M2=[w if v!=i else F(0) for v,w in enumerate(M)]
        L2=[load[b]-M[i]*true_r[i][b] for b in range(len(cells))]
        newly={b for b in kept if 0<L2[b]<threshold}
        if newly:
            probe=(i,M2,L2,newly)
            break
    if probe is None:
        scale=threshold/(2*max(load[b] for b in kept))
        M2=[scale*w for w in M]
        L2=[scale*v for v in load]
        probe=(None,M2,L2,set(kept))
    removed,M2,L2,fresh=probe
    assert low.isdisjoint(fresh)
    Lcheck,_,_,loss2=coupling(true_r,y_mass,M2,base,fresh)
    assert Lcheck==L2
    assert 0<loss2<threshold*base.total(y_mass[b] for b in fresh)
    assert loss+loss2<=threshold*base.total(y_mass[b] for b in low|fresh)<=threshold*S

    witness_y=defaultdict(F)
    for i,(t,u) in enumerate(keys):
        witness_y[t]+=M[i]*true_r[i][y0]/load[y0]
    assert base.total(witness_y.values())==1 and sum(w>0 for w in witness_y.values())>=2
    options=[i for i,(t,u) in enumerate(keys) if true_r[i][y0]]
    i,k=next((i,k) for i,k in product(options,repeat=2) if keys[i][0]!=keys[k][0])
    v,w=records[i][0],records[k][0]
    direct=base.total(v["mass"]*w["mass"]*true_r[i][b]*true_r[k][b]*y_mass[b]/load[b]
                      for b in pos)
    factored=P[i][k]*v["mass"]*w["mass"]/(M[i]*M[k])
    witness_cell_pair=(y_mass[y0]*v["mass"]*w["mass"]*true_r[i][y0]*true_r[k][y0]
                       /load[y0])
    assert 0<witness_cell_pair<=direct==factored

    def freeze_comparison(rows):
        _,pp,marginal,mass=coupling(rows,y_mass,M,base)
        assert marginal==M and mass==whole
        invalid=base.total(M[i]*r*y_mass[b] for i,row in enumerate(rows) for b,r in enumerate(row)
                           if base.inside(cells[b],D[keys[i][0]]))
        assert invalid>0
        delta=base.total(abs(pp[i][k]-P[i][k]) for i,k in product(range(len(keys)),repeat=2))/2
        assert delta>0
        return dict(original_mass=mass,physically_wrong_inside_D_t_source_mass=invalid,
                    actual_same_y_pair_variation_vs_true_exterior=delta,
                    geometry=geometry(pp,T,A,D,cells,records,keys,M,base))
    geom=geometry(P,T,A,D,cells,records,keys,M,base)
    geom_hi=geometry(high,T,A,D,cells,records,keys,M,base)
    assert geom_hi["actual_cross_middle_mass"]>0
    assert 0<geom["expanded_middle_mutual_avoid_z_and_q_fraction"]<1
    if name!="initial":
        assert 0<geom["old_hit_given_strict_size_difference"]<1
    return dict(stage=name,physical_middles=T,physical_olds=A,true_old_owners=O,actual_middle_owners=E,
                geometrical_D=D,source_pockets_G=G,source_amplitude=amp,full_original_d=d,
                source_cells=cells,actual_source_cell_mu=y_mass,actual_L1_source_load=load,
                physical_joint_type_keys=keys,real_input_w_by_type=M,
                genuine_external_sets_by_type=ext,genuine_external_mu_by_type=ext_mass,
                original_directed_record_count=base.total(len(l) for l in records),
                shared_actual_y_pair_matrix=P,shared_pair_marginals=marg,
                high_load_cross_middle_witness=dict(actual_y_cell=cells[y0],F=load[y0],posterior_by_actual_middle=witness_y,
                                                   actual_two_complete_record_atoms=[v,w],
                                                   pair_mass_on_witness_cell=witness_cell_pair,
                                                   pair_mass_integrated_over_all_y=direct),
                fixed_low_load_threshold=threshold,real_external_union_S=S,
                initially_deleted_low_load_mu=base.total(y_mass[b] for b in low),initial_loss=loss,
                second_scan_after_removing_actual_type=keys[removed] if removed is not None else None,
                second_scan_uses_uniform_thinning=removed is None,second_new_set_mu=base.total(y_mass[b] for b in fresh),
                second_first_deleted_source_mass=loss2,total_source_first_deletion_charges=loss+loss2,
                first_delete_capacity_bound=threshold*S,first_cut_retained_mass=high_mass,
                physical_geometry_on_all_original_source=geom,physical_geometry_on_high_first_cut_source=geom_hi,
                comparison_frozen_full_old_mu=freeze_comparison(freeze_mu),
                comparison_frozen_full_old_Lebesgue=freeze_comparison(freeze_leb))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    p.add_argument("--rows-dir",type=Path,default=here)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=args.rows_dir/"rows798.py"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    T=[base.iv(0,4),base.iv(-4,"-1/2"),base.iv("1/2",4),base.iv("-9/2",-1),base.iv("-1/4","13/4")]
    A=[base.iv(-1,1),base.iv("-3/4","7/4"),base.iv(-2,"1/2")]
    G=[base.iv("-7/8","7/8"),base.iv("-5/8","13/8"),base.iv("-7/4","3/8")]
    shares=[F(1),F(3,4),F(1,2),F(7,8),F(5,8)]
    data=[
      diagnostic("initial",T[:2],A[:1],G[:1],shares[:2],F(1,4),base),
      diagnostic("pressure",T[:3],A[:2],G[:2],shares[:3],F(1,2),base),
      diagnostic("expanded",T,A,G,shares,F(3,4),base),
    ]
    obj=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             command="python -B source804.py --check source804.json",dependency={"rows798.py":ROWS_SHA},
             scope=dict(precision="standard-library exact Fraction",
                 records="true oriented original old-arm product with I_t/d_t, after the diagnostic nonproduct rule that the two actual receiving halves agree",
                 exterior="r_e=one_(G_u minus the closed (1+1/64)A_t) / true mu of that set, relative to common mu on real price atoms",
                 coupling="x-oriented record e retains its entire original record, draws a true y through r_e and samples another complete original from the actual m_e r_e(y)/F(y) posterior. Both marginals checked. No own original z or q rewritten.",
                 charging="first passing cutoff removes 0<F<P cells. A second scan changes the true input subflow, with no redistribution of the first-removed source cells.",
                 geometry="larger physical old father supplies its own true z for re-hit in smaller old A. Ties use lower old label. Mutual central avoidance is measured separately for z, then z and q, under both original and expanded middles.",
                 diagnosis="physical one-dimensional finite model, with a stated gate; does not presume the high-dimensional screen"),
             stages=data)
    text=json.dumps(obj,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for c in data:
            g=c["physical_geometry_on_all_original_source"]
            print(c["stage"],"paired mass",g["total"],"cross middle",g["actual_cross_middle_mass"],
                  "large old true-z rehit",g["larger_old_true_z_hit_fraction"],
                  "expanded two-price mutual avoidance",g["expanded_middle_mutual_avoid_z_and_q_fraction"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
