#!/usr/bin/env python3
"""Exact true-root rectangles, chronological closure peeling, and price spans."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"


def gap(I,J):
    return max(F(0),I[0]-J[1],J[0]-I[1])


def max_gap(I,J):
    return max(abs(I[0]-J[1]),abs(I[1]-J[0]))


def mat_copy(h):
    return [list(r) for r in h]


def grammar(p,h,base):
    return [[base.total(w*h[x][y]*h[z][y] for y,w in enumerate(p))
             for z in range(len(p))] for x in range(len(p))]


def closure(p,h,x,y,base,check=True):
    partial=base.total(p[z]*h[z][y]*base.total(w*h[x][q]*h[z][q] for q,w in enumerate(p))
                       for z in range(len(p)))
    if check:
        assert partial==base.total(p[z]*p[q]*h[x][q]*h[z][q]*h[z][y]
                                   for z,q in product(range(len(p)),repeat=2))
    return partial


def rectangles(p,h):
    n=len(p)
    for x,y,z,q in product(range(n),repeat=4):
        indices=((x,y),(x,q),(z,y),(z,q))
        if not all(h[i][j] for i,j in indices):
            continue
        w=p[x]*p[y]*p[z]*p[q]*h[x][y]*h[x][q]*h[z][y]*h[z][q]
        if w:
            yield indices,w


def energy(cases,H,base):
    M=F(0)
    T4=F(0)
    J=F(0)
    W=base.total(v["w"] for v in cases)
    for v,h in zip(cases,H):
        p=v["tau"]
        w=v["w"]
        m=base.total(p[i]*p[j]*h[i][j] for i,j in product(range(len(p)),repeat=2))
        by_rect=base.total(g for _,g in rectangles(p,h))
        G=grammar(p,h,base)
        by_row=base.total(p[x]*p[z]*G[x][z]**2 for x,z in product(range(len(p)),repeat=2))
        assert by_rect==by_row>=m**4
        M+=w*m
        T4+=w*by_rect
        J+=w*m**4
    assert T4>=J>=M**4/W**3
    return dict(raw_weight_W=W,total_edge_mass=M,T4=T4,
                middlewise_Jensen_lower=J,global_Jensen_lower=M**4/W**3)


def physical_cases(name,T,A,shares,amp,base):
    E=[base.owner(A0,s) for A0,s in zip(T,shares)]
    R=[base.owner(A0,F(1)) for A0 in A]
    physical=sorted(E+R)
    assert all(a[1]<b[0] for a,b in zip(physical,physical[1:]))
    mT=list(map(base.length,T))
    mA=list(map(base.length,A))
    I=list(map(base.length,E))
    j=list(map(base.length,R))
    mu=lambda I:base.real_mass(I,amp)
    assert list(map(mu,T+A))==mT+mA
    windows=[
      (0,base.iv("1/2",1),0),
      (1,base.iv(3,"27/8"),1),
      (0,base.iv("7/8","15/16"),1),
      (1,base.iv("25/8","13/4"),0),
    ]
    if name!="initial":
        windows.extend([(2,base.iv(2,"9/4"),0),(2,base.iv("3/2","13/8"),1)])
    if name=="expanded":
        windows.extend([(3,base.iv(1,"5/4"),0),(4,base.iv("5/2","11/4"),1)])
    cases=[]
    for v,Tv in enumerate(T):
        old={}
        for u,B in enumerate(A):
            overlap=base.clip(Tv,B)
            mass=mu(overlap)
            if mA[u]<mT[v] and mass:
                old[u]=(overlap,mass,mass/(mT[v]*mA[u]))
        down=base.total(j[u]*k for u,(_,_,k) in old.items())
        full=down
        extra=[]
        if name=="expanded":
            # A real central neighbor participates in the original full
            # degree. Neither old arm is allowed to sample this extra class.
            for other,B in enumerate(T):
                if other==v:
                    continue
                mass=mu(base.clip(Tv,B))
                if mass:
                    k=mass/(mT[v]*mT[other])
                    extra.append(dict(non_old_central=other,true_intersection_mu=mass,
                                      directed_K=k,degree_part=I[other]*k))
                    full+=I[other]*k
            assert full>down
        w=I[v]*down**2/full
        marks=[]
        probs=[]
        raw=[]
        for u,X,side in windows:
            actual=base.clip(old[u][0],X)
            price_weight=mu(actual)
            assert price_weight>0
            Y=R[u]
            midpoint=base.point(Y)
            U=(Y[0],midpoint) if side==0 else (midpoint,Y[1])
            K=old[u][2]
            k=j[u]*K*price_weight/old[u][1]*base.length(U)/j[u]
            assert k==price_weight*base.length(U)/(mT[v]*mA[u])
            p=k/down
            marks.append(dict(physical_old=u,true_price=actual,true_receiver=U,
                              price_mu=price_weight,true_raw_K_atom=k))
            probs.append(p)
            raw.append(k)
        for i,a in enumerate(marks):
            for b in marks[i+1:]:
                if a["physical_old"]==b["physical_old"]:
                    assert mu(base.clip(a["true_price"],b["true_price"]))==0 or base.length(
                        base.clip(a["true_receiver"],b["true_receiver"]))==0
        p0=1-base.total(probs)
        assert p0>0
        probs.append(p0)
        raw.append(down*p0)
        marks.append(dict(complement_of_fixed_mark_windows=True))
        assert base.total(probs)==1 and base.total(raw)==down
        n=len(probs)
        h=[[F(0)]*n for _ in range(n)]
        h[0][0],h[0][1],h[1][0],h[1][1]=F(1),F(3,4),F(1,2),F(7,8)
        h[2][2],h[2][3]=F(1),F(1,2)
        if name!="initial":
            h[4][4],h[4][5],h[5][5]=F(1,4),F(1,8),F(3,4)
        if name=="expanded":
            h[0][6],h[6][1],h[6][6],h[1][7],h[7][6]=F(1,4),F(1,2),F(3,4),F(3,8),F(1,4)
        for i,k in product(range(n),repeat=2):
            assert 0<=h[i][k]<=1
            assert I[v]*raw[i]*raw[k]*h[i][k]/full==w*probs[i]*probs[k]*h[i][k]
        cases.append(dict(v=v,owner=E[v],m=mT[v],actual_original_I=I[v],original_full_d=full,
                          actual_old_d_minus=down,additional_non_old_degree_terms=extra,
                          w=w,wrong_w_if_using_old_total_as_denominator=I[v]*down,
                          actual_mark_atoms=marks,tau=probs,finite_path_h=h,
                          actual_old_K={u:K for u,(_,_,K) in old.items()}))
    return cases,E,R


def guaranteed_price_advantage(cases,H,base):
    thresholds=[F(1),F(3)]
    results={z:dict(four_only=F(0),two_diagonal_only=F(0),both=F(0),neither=F(0),indeterminate=F(0))
             for z in thresholds}
    for v,h in zip(cases,H):
        for corners,w in rectangles(v["tau"],h):
            p=v["actual_mark_atoms"]
            (x,y),_,_,(z,q)=corners
            A,B,C,D=[p[i]["true_price"] for i in (x,y,z,q)]
            items=(A,B,C,D)
            min_four=max(F(0),max(l for l,r in items)-min(r for l,r in items))
            max_four=max(r for l,r in items)-min(l for l,r in items)
            min_two=gap(A,B)+gap(C,D)
            max_two=max_gap(A,B)+max_gap(C,D)
            for s,group in results.items():
                if min_four>s and max_two<=s:
                    kind="four_only"
                elif min_two>s and max_four<=s:
                    kind="two_diagonal_only"
                elif min_four>s and min_two>s:
                    kind="both"
                elif max_four<=s and max_two<=s:
                    kind="neither"
                else:
                    kind="indeterminate"
                group[kind]+=v["w"]*w
    assert results[F(1)]["four_only"]>0 and results[F(3)]["two_diagonal_only"]>0
    return {str(z):v for z,v in results.items()}


def peel(cases,H,kappa,base):
    current=[mat_copy(h) for h in H]
    old={i:matrices for i,matrices in enumerate(H)}
    ranks={}
    at_deletion={}
    rounds=[]
    while True:
        batch=[]
        for v,h in zip(cases,current):
            for i,j in product(range(len(h)),repeat=2):
                if h[i][j]>0:
                    c=closure(v["tau"],h,i,j,base)
                    if c<kappa:
                        batch.append((v["v"],i,j,c))
        if not batch:
            break
        moves=[]
        for index,i,j,prior in batch:
            v=cases[index]
            h=current[index]
            actual=closure(v["tau"],h,i,j,base)
            assert actual<=prior<kappa and h[i][j]==old[index][i][j]>0
            mass=v["w"]*v["tau"][i]*v["tau"][j]*h[i][j]
            ranks[index,i,j]=len(ranks)
            at_deletion[index,i,j]=(mass,actual)
            moves.append(dict(v=index,x=i,y=j,closure_at_round_start=prior,
                              closure_at_removal=actual,deleted_actual_edge_mass=mass))
            h[i][j]=F(0)
        rounds.append(moves)
    positive_terminal=[]
    for v,h in zip(cases,current):
        terminal=[(i,j,closure(v["tau"],h,i,j,base))
                  for i,j in product(range(len(h)),repeat=2) if h[i][j]]
        assert all(c>=kappa for i,j,c in terminal)
        positive_terminal.append(dict(v=v["v"],surviving_edge_count=len(terminal),
                                      min_actual_closure=min((c for i,j,c in terminal),default=None)))
    deleted=[[[w if (i,x,y) in ranks else F(0) for y,w in enumerate(row)]
               for x,row in enumerate(h)] for i,h in enumerate(H)]
    data=energy(cases,deleted,base)
    tail=energy(cases,current,base)
    origin=energy(cases,H,base)
    D=data["total_edge_mass"]
    W=origin["raw_weight_W"]
    assert D==base.total(m for m,_ in at_deletion.values())
    assert origin["total_edge_mass"]==D+tail["total_edge_mass"]
    charged=defaultdict(F)
    for v,h in zip(cases,deleted):
        for a,w in rectangles(v["tau"],h):
            endpoints=[(v["v"],x,y) for x,y in a]
            winner=min(endpoints,key=lambda i:ranks[i])
            charged[winner]+=v["w"]*w
    assert base.total(charged.values())==data["T4"]
    assert all(charged[key]<=4*m*c for key,(m,c) in at_deletion.items())
    assert data["T4"]<=4*kappa*D and D**3<=4*kappa*W**3
    if D:
        assert data["T4"]<4*kappa*D
    return dict(kappa=kappa,rounds=rounds,removed_mass=D,terminal=tail,removed_graph=data,
                terminal_positive_support_and_closures=positive_terminal,
                earliest_corner_charges=[dict(edge=k,actual=v,bound=4*at_deletion[k][0]*at_deletion[k][1])
                                        for k,v in sorted(charged.items())],
                D_cubed=D**3,uniform_deleted_mass_cubic_bound=4*kappa*W**3)


def cemetery_version(cases,H,old_energy,old_peeling,kappa,base):
    """Keep the full-degree one-arm law, with all forbidden arms at one atom."""
    cemetery_cases=[]
    comparisons=[]
    for v,h in zip(cases,H):
        p=v["tau"]
        full=v["original_full_d"]
        r=v["actual_old_d_minus"]/full
        tau=[r*x for x in p]+[1-r]
        n=len(p)
        h_with_cemetery=[list(row)+[F(0)] for row in h]+[[F(0)]*(n+1)]
        weight=v["actual_original_I"]*full
        assert 0<r<=1 and base.total(tau)==1 and v["w"]==weight*r**2
        assert all(tau[i]==mark["true_raw_K_atom"]/full
                   for i,mark in enumerate(v["actual_mark_atoms"][:-1]))
        converted=dict(v,v=v["v"],tau=tau,w=weight,finite_path_h=h_with_cemetery)
        cemetery_cases.append(converted)

        def edge_masses(p0,h0,w0):
            return [[w0*p0[i]*p0[j]*h0[i][j] for j in range(len(p0))] for i in range(len(p0))]

        old=edge_masses(p,h,v["w"])
        new=edge_masses(tau,h_with_cemetery,weight)
        assert new==[row+[F(0)] for row in old]+[[F(0)]*(n+1)]
        left=[base.total(row) for row in old]
        right=[base.total(row[j] for row in old) for j in range(n)]
        assert left+[F(0)]==[base.total(row) for row in new]
        assert right+[F(0)]==[base.total(row[j] for row in new) for j in range(n+1)]
        old_rect=dict(rectangles(p,h))
        new_rect=dict(rectangles(tau,h_with_cemetery))
        assert old_rect.keys()==new_rect.keys()
        assert all(weight*value==r**2*v["w"]*old_rect[q] for q,value in new_rect.items())
        old_four=v["w"]*base.total(old_rect.values())
        new_four=weight*base.total(new_rect.values())
        corners=[]
        for i,j in product(range(n),repeat=2):
            if h[i][j]:
                old_c=closure(p,h,i,j,base)
                new_c=closure(tau,h_with_cemetery,i,j,base)
                assert new_c==r**2*old_c
                corners.append(dict(x=i,y=j,old_c=old_c,full_degree_c=new_c))
        comparisons.append(dict(v=v["v"],real_old_arm_probability=r,cemetery_probability=1-r,
                                tau_full_degree=tau,full_degree_weight=weight,
                                unchanged_left_edge_marginal=left,unchanged_right_edge_marginal=right,
                                cemetery_left_right_edge_marginals=[F(0),F(0)],
                                four_corner_count=len(old_rect),old_weighted_T4=old_four,
                                full_degree_weighted_T4=new_four,T4_and_closure_scaling=r**2,
                                true_corner_closures=corners))

    H_full=[v["finite_path_h"] for v in cemetery_cases]
    full_energy=energy(cemetery_cases,H_full,base)
    full_peeling=peel(cemetery_cases,H_full,kappa,base)
    assert old_energy["total_edge_mass"]==full_energy["total_edge_mass"]
    assert old_energy["T4"]==base.total(v["old_weighted_T4"] for v in comparisons)
    assert full_energy["T4"]==base.total(v["full_degree_weighted_T4"] for v in comparisons)
    assert full_peeling["removed_mass"]>=old_peeling["removed_mass"]
    if all(v["cemetery_probability"]==0 for v in comparisons):
        assert old_energy==full_energy and full_peeling==old_peeling
    else:
        assert 0<full_energy["T4"]<old_energy["T4"]
    return dict(per_middle=comparisons,unpeeled=full_energy,chronological_peeling=full_peeling,
                full_degree_T4_over_old_only_T4=full_energy["T4"]/old_energy["T4"])


def diagnostic(name,T,A,shares,amp,base):
    cases,E,R=physical_cases(name,T,A,shares,amp,base)
    H=[v["finite_path_h"] for v in cases]
    initial=energy(cases,H,base)
    marks=cases[0]["actual_mark_atoms"]
    p=cases[0]["tau"]
    before=closure(p,H[0],2,2,base)
    minus=mat_copy(H[0])
    minus[2][3]=F(0)
    after=closure(p,minus,2,2,base)
    assert after<before
    if name=="initial":
        kappa=(before/2+after)/2
    else:
        kappa=(before+after)/2
    r=peel(cases,H,kappa,base)
    assert r["removed_mass"]>0 and r["terminal"]["total_edge_mass"]>0
    if name!="initial":
        assert any(m["v"]==0 and (m["x"],m["y"])==(2,3) for m in r["rounds"][0])
        assert any(m["v"]==0 and (m["x"],m["y"])==(2,2) for m in r["rounds"][1])
    missing=[(0,0),(2,2)]
    absent=[(0,2),(2,0)]
    assert all(H[0][i][j]>0 for i,j in missing) and all(H[0][i][j]==0 for i,j in absent)
    real_edge_mass=lambda i,j:cases[0]["w"]*p[i]*p[j]*H[0][i][j]
    S=[marks[i] for i in (0,1)]
    certificate=guaranteed_price_advantage(cases,H,base)
    assert all(base.total(c.values())==initial["T4"] for c in certificate.values())
    actual_quad_weight=cases[0]["w"]*p[0]**2*p[1]**2*H[0][0][0]*H[0][0][1]*H[0][1][0]*H[0][1][1]
    assert actual_quad_weight>0
    cemetery=cemetery_version(cases,H,initial,r,kappa,base)
    return dict(stage=name,true_middle=T,true_old=A,middle_owners=E,old_owners=R,
                nonuniform_true_mu_amplitude=amp,physical_roots=cases,unpeeled=initial,
                chronological_peeling=r,full_degree_cemetery=cemetery,tail_trigger=dict(v=0,tail_self_before=before,tail_after_losing_light_corner=after),
                missing_cross=dict(actual_v=0,positive_two_paths=[real_edge_mass(*q) for q in missing],
                                   zero_diagnostic_cross=[real_edge_mass(*q) for q in absent],
                                   actual_two_price_owner_atoms=[marks[0],marks[2]]),
                four_corner_geometry=dict(actual_two_price_owner_atoms=S,actual_true_four_corner_weight=actual_quad_weight,
                    minimum_four_span_on_two_diagonal_peaks=gap(S[0]["true_price"],S[1]["true_price"]),
                    maximum_sum_of_two_original_diagonal_price_spans=base.length(S[0]["true_price"])+base.length(S[1]["true_price"]),
                    interval_certified_mass_by_threshold=certificate))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    here=Path(__file__).resolve().parent
    p.add_argument("--rows-dir",type=Path,default=here)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    rows=args.rows_dir/"rows798.py"
    assert sha256(rows.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",rows)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    stages=[
      diagnostic("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],F(1,4),base),
      diagnostic("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),base),
      diagnostic("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
           U+[base.iv("1/2",3),base.iv(2,"9/2")],[F(1),F(3,4),F(1,2),F(7,8),F(5,8)],F(3,4),base)]
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
              command="python -B switch804.py --check switch804.json",
              dependency={"rows798.py":ROWS_SHA},
              scope=dict(precision="standard-library exact Fraction",
                  weight="Use the two original old arms with tau normalised by d_minus and w=I_v*d_minus^2/d_v. All d_v remain original within the stated model.",
                  full_degree_cemetery="The genuine full-degree arm law places all non-old arms at one atom, where the gate is zero. Weighted actual edge marginals are unchanged. Within each root, the weighted rectangle mass and actual-corner closure are both multiplied by (d_minus/d_v)^2, with the same numerical peeling threshold.",
                  actual_h="A fixed rational retention multiplier on real complete (price, owner, old label) atom pairs. This is the diagnostic gate, separate from the frozen family geometry.",
                  peeling="Remove positive h cells with c<kappa, preserving tau and original d. Assign each removed-graph rectangle once to its earliest deleted actual corner, including repeated cells.",
                  geometry="Four-span and sum of original relative diagonal price spans use actual interval bounds; the histogram counts only decisions certified throughout each true four-price atom.",
                  scope="finite one-dimensional nonuniform geometry and stated diagnostic gates, without implementing the original high-dimensional screens."),
              stages=stages)
    text=json.dumps(data,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for x in stages:
            p=x["chronological_peeling"]
            print(x["stage"],"M,T4",x["unpeeled"]["total_edge_mass"],x["unpeeled"]["T4"],
                  "del/terminal",p["removed_mass"],p["terminal"]["total_edge_mass"],
                  "peel rounds",[len(g) for g in p["rounds"]])
            full=x["full_degree_cemetery"]
            fp=full["chronological_peeling"]
            print("  full-degree cemetery T4",full["unpeeled"]["T4"],
                  "T4 ratio",full["full_degree_T4_over_old_only_T4"],
                  "del/terminal",fp["removed_mass"],fp["terminal"]["total_edge_mass"],
                  "peel rounds",[len(g) for g in fp["rounds"]])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
