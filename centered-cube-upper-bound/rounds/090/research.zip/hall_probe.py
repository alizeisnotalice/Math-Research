"""PUBLIC R90 neutral continuous-prefix certificates. Standard library only.
Scalar polynomial examples are NONPHYSICAL and do not qualify original gates.
"""
from fractions import Fraction as F
import json,math
from pathlib import Path

def add(p,q):
    r=[F(0)]*max(len(p),len(q))
    for i,v in enumerate(p):r[i]+=v
    for i,v in enumerate(q):r[i]+=v
    return r
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for i,v in enumerate(p):
        for j,w in enumerate(q):r[i+j]+=v*w
    return r
def val(p,x):return sum(c*x**j for j,c in enumerate(p))
def derivative(p):return [j*p[j] for j in range(1,len(p))]
def bernstein(p,a,b):
    d=len(p)-1
    q=[sum(p[k]*math.comb(k,j)*a**(k-j)*(b-a)**j for k in range(j,d+1)) for j in range(d+1)]
    beta=[sum(q[j]*F(math.comb(i,j),math.comb(d,j)) for j in range(i+1)) for i in range(d+1)]
    return min(beta),max(beta),beta

def segment(p,a,b):
    dl,du,_=bernstein(derivative(p),a,b)
    # FTC works for absolutely continuous functions with a.e. derivative bound.
    upper=min(val(p,a)+max(F(0),du)*(b-a),val(p,b)+max(F(0),-dl)*(b-a))
    return {'a':str(a),'b':str(b),'endpoint_p':[str(val(p,a)),str(val(p,b))],
      'derivative':[str(dl),str(du)],'upper':str(upper)}
def bracket(p,witness,tol=F(1,4096)):
    work=[(F(1),witness)];prefix=[]
    while work:
        a,b=work.pop();r=segment(p,a,b)
        if F(r['upper'])<0:prefix.append(r);continue
        if b-a<=tol:
            assert (not prefix and a==1) or F(prefix[-1]['b'])==a
            strict=val(p,b)>0
            return {'state':'CERTIFIED' if strict else 'UNKNOWN','lo':str(a),'hi':str(b if strict else witness),
              'prefix':prefix,'first_possible_segment':r,
              'reason':'strict prefix plus later witness' if strict else 'possible earlier contact not eliminated; wide conservative bracket'}
        m=(a+b)/2;work.append((m,b));work.append((a,m))
    raise AssertionError('positive witness cannot be discarded')

def fixture(name,roots,factor,mesh):
    p=[factor]
    for root in roots:p=mul(p,[-root,F(1)])
    h=add([F(1)],p)
    assert val(h,F(1))<F(1,2) and val(p,F(2))>0
    # Polynomial factorization separately knows root locations and multiplicities.
    first=min(roots)
    multiplicity=roots.count(first)
    grid=[(x,val(p,x)) for x in mesh]
    positivegrid=next(x for x,v in grid if v>0)
    certificate=bracket(p,F(2))
    lo=F(certificate['lo']);hi=F(certificate['hi'])
    assert lo<first<=hi
    for r in certificate['prefix']:assert F(r['upper'])<0
    # Gapless prefix reaches lo; no one-sided nodal-sign proof is used.
    assert certificate['prefix'][0]['a']=='1'
    for a,b in zip(certificate['prefix'],certificate['prefix'][1:]):assert a['b']==b['a']
    assert certificate['prefix'][-1]['b']==certificate['lo']
    return {'name':name,'scope':'NONPHYSICAL scalar continuous function',
      'lambda':'1','H_coefficients':list(map(str,h)),'p_coefficients':list(map(str,p)),
      'factor':str(factor),'roots_with_multiplicity':list(map(str,roots)),
      'actual_earliest_contact_exact':str(first),'earliest_multiplicity':multiplicity,
      'first_positive_mesh_node':str(positivegrid),
      'mesh_records':[[str(x),str(v)] for x,v in grid],
      'mesh_misses_earlier_contact':positivegrid>first,
      'certificate':certificate}
def main():
    cases=[fixture('pilot_monotone',[F(6,5)],F(4),[F(1),F(3,2),F(2)]),
      fixture('tangent_before_strict_witness',[F(5,4),F(5,4),F(7,4)],F(16),[F(1),F(3,2),F(2)]),
      fixture('multiple_crossing_alias',[F(6,5),F(3,2),F(7,4)],F(8),[F(1),F(13,8),F(2)])]
    out={'schema':'R90-public-continuous-prefix-v1',
     'scope':'Neutral exact scalar interface, not physical source or actual gate certificate',
     'uniform_cell_premises':['joint continuity','uniform anchor below','positive log-factor denominator',
       'a.e. derivative bounds on each entire cell times scale interval','gapless strictly subthreshold prefix',
       'uniform strict later witness'],
     'conclusion':'Every original earliest contact lies in the saved bracket; uniqueness is not needed. Tangent uncertainty must not be replaced by a later strict root.',
     'cases':cases,'remaining_physical_gap':'No original smooth/coarse/middle or whole-Fnew coverage follows from this scalar exercise.'}
    path=Path(__file__).with_name('hall_results.json');path.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':'PASS','cases':len(cases),'prefix_segments':sum(len(c['certificate']['prefix']) for c in cases),
      'states':[c['certificate']['state'] for c in cases]}))
if __name__=='__main__':main()
