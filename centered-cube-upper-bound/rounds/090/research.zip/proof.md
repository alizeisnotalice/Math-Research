# 中心立方体第90轮：有限厚度通量、集中来源费用与原门连续证书

日期：2026-10-12。一般正 L1 输入的目标 `C_n^square <= sqrt(n) n^{o(1)}` **尚未证明**，一般基准仍为 `O(n log n)`。本轮不改变原事件、真实勒贝格接收测度或已有尺度和分层费用。

本轮得到有限厚度通量的无条件根阶费用，同时精确保留其共同来源余项，并证明单独优化来源平移模量的证书仍有线性障碍。坐标薄片包给出带有完整补集费用的支付，但没有证明一般输入具备所需覆盖。Gamma 平滑路线得到一个一般转移定理及全尺度误差的必要费用，未得到上界闭合。

数值工作继续使用同一冻结输入、原阈值和原抽样单元，新增的是连续首次接触与原平滑门的可复查区间证书。所有未通过或未判定的门如实保留；节点命中率不充当余集测度。私人输入、配方、原目录应用和新推导的私人下界不公开。完整报告区分证明、条件结论、精确计算、概率置信和浮点诊断。

使用用户指定的八个已有 Agent：三名 Astra high 路线作者、Astra high 与 Sol high 各一名独立审核者、两名 Sol high 数值作者、一名 Sol high 原文与更新64技能作者。命题先送独立风险检查再读证明；主代理负责整合及隔离复现。每份审阅回执限于实际阅读范围。

全边长约定始终为 `Q(x,L)=x+[-L/2,L/2]^n`，原窗口 `[1,2]`；Gamma 参数使用 `t=L/(2n)`，形状参数 `n+1`。薄片正常坐标数为 k、自由坐标数为 m；这些不改变原 κ 分层。规范耦合与最优容量耦合分开，规范方差不假定对子集单调。

更新后的64技能按具体接口使用，入口字节快照仅记录安装内容，不代表全库定理验收。本轮详细 LaTeX 仅静态核验，不编译 PDF。


## 第90轮主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；本轮未证明新薄片分支覆盖整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮新增有效工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。


## 1. Outcome, scope and quantities

The general root-order Hall estimate is **not proved**. This component proves an unconditional root-order bound for a finite-thickness replacement of the actual face flux, derives its exact same-source remainder, and proves that a source-translation-modulus payment cannot give a sublinear bound even when the thickness is chosen adaptively for the input. The obstruction concerns that certificate, not the actual signed remainder or the cube maximal operator.

Fix $n\ge2$, an original $f\ge0$ in $L^1(\mathbb R^n)$, $\lambda>0$, a regular compact $B\subset F_{\rm new}$, and an original positive principal pair $A=A_s$, $S=S_s$. Write
\[
 g=f1_S,\quad M=\int g>0,\quad D=\lambda|A|,\quad
 \chi(x,L)=1_A(x)1_{\{1<L<\tau_x\}},\qquad \tau_x=L_*(x).
 \tag{1}
\]
The row set and selector retain their original meaning. Source restriction preserves the old contact cubes and hard prefixes, but no new middle or later-witness gate is inferred for $g$. Regular compact means compact with continuous restricted original selector, not a Lipschitz boundary or selector.

Let $C=[-1/2,1/2]^n$. At a source $y$ and side $L$, let $p_y(L)$ be the average of $\chi(y+Lz,L)$ over $z\in C$, and $q_y(L)$ its average over the $2n$ unit-area faces. The retained actual identity is
\[
 D-a=n\int_1^2\int g(y)[q_y(L)-p_y(L)]\,dy\,\frac{dL}{L},
 \qquad a=\int_A A_1g(x)\,dx\le M.                       \tag{2}
\]
All the comparisons below apply to this same source and this same $\chi$. In fact their analytic statements hold for every measurable $0\le\chi\le1$; contact is used when invoking (2). They apply to every actual principal cut without any attainment, smooth-boundary or source-coordinate independence assumption beyond the retained existence of that principal pair.

## 2. A genuinely paid finite-thickness part

For $0<\delta\le1$, replace a chosen face coordinate by a uniform coordinate in its adjacent edge slab of total relative width $\delta$. More explicitly, sample $I$ uniformly in $\{1,\ldots,n\}$, a sign $\Sigma$ uniformly, $V$ uniformly in $[0,1]$, and the other coordinates $Z_{-I}$ uniformly in their unit cube. Use coordinate $\Sigma(1-\delta V)/2$ in position $I$. Denote the resulting average of $\chi(y+Lz,L)$ by $q_{\delta,y}(L)$.

Relative to uniform volume on $C$, this law has density
\[
 R_\delta(z)=\frac1{n\delta}\sum_{i=1}^n
 1_{\{|z_i|>(1-\delta)/2\}}.
 \tag{3}
\]
Only these explicitly constructed kernel coordinates are independent. The physical coordinates of $y$ need not be independent.

Let $K\sim{\rm Binomial}(n,\delta)$ and define
\[
 a_n(\delta)=\frac{\mathbb E(K-n\delta)_+}{\delta}.
 \tag{4}
\]
Then the actual regularized flux
\[
 F_\delta=n\int_1^2\int g(y)
       [q_{\delta,y}(L)-p_y(L)]\,dy\,\frac{dL}{L}
 \tag{5}
\]
satisfies
\[
 |F_\delta|\le a_n(\delta)(\log2)M
 \le\frac{\log2}{2}\sqrt{\frac{n(1-\delta)}{\delta}}\,M.
 \tag{6}
\]
In particular $\delta=1/2$ costs at most $(\log2)\sqrt n\,M/2$.

**Proof.** Under uniform $z$, the sum in (3) has law $K$, so
$\mathbb E R_\delta=1$ and
$\operatorname{Var}(R_\delta)=(1-\delta)/(n\delta)$.
For any mean-zero integrable $Z$ and $0\le h\le1$,
$|\mathbb E Zh|\le\mathbb E Z_+=\mathbb E|Z|/2$.
Apply this with $Z=R_\delta-1$ and
$h(z)=\chi(y+Lz,L)$, at each fixed $y,L$. Multiplying by $n$ gives the first constant in (6). Cauchy gives
$\mathbb E|R_\delta-1|\le\sqrt{\operatorname{Var}(R_\delta)}$,
which gives the second. Integration in $g(y)dy\,dL/L$ proves (6).
The binomial constant is sharp for unrestricted cube test functions, attained by $h=1_{\{R_\delta>1\}}$. We do not assert that actual stopped cuts simultaneously attain these pointwise optimizers.

For later pressure checks, when $n\delta\le1$ there is the exact formula
\[
 a_n(\delta)=n(1-\delta)^n.                              \tag{7}
\]
Indeed the positive part is supported on $K\ge1$, and
$\mathbb E(K-n\delta)_+=n\delta-n\delta P(K\ge1)
=n\delta P(K=0)$. Thus the exact paid constant stays linear as $\delta\downarrow0$; the square-root upper estimate alone should not be interpreted as its small-thickness asymptotic.

## 3. Exact error: a common source and two receiver rows

Define the full signed error, without dropping its positive or negative part,
\[
 E_\delta=n\int_1^2\int g(y)
       [q_y(L)-q_{\delta,y}(L)]\,dy\,\frac{dL}{L}.
 \tag{8}
\]
Then (2) is exactly
\[
 D-a=F_\delta+E_\delta.                                 \tag{9}
\]
There is a useful exact expression which keeps the source and receiver changes together. For each $i,L,v,z_{-i}$ put
\[
 b=L/2,\quad a_v=(1-\delta v)L/2,\quad
 c=(a_v+b)/2,\quad h=(b-a_v)/2=\delta vL/4,
\]
\[
 \Phi(y)=\chi(y+Lz_{-i}+ce_i,L)
              -\chi(y+Lz_{-i}-ce_i,L),
 \qquad g_\pm(y)=g(y\pm he_i).
 \tag{10}
\]
The vector $z_{-i}$ has zero coordinate in position $i$. With uniform measure on its transverse cube,
\[
 E_\delta=\frac12\sum_{i=1}^n\int_1^2\frac{dL}{L}
  \int_0^1dv\int_{C_{-i}}dz_{-i}
  \int_{\mathbb R^n}[g_-(y)-g_+(y)]\Phi(y)\,dy.
 \tag{11}
\]
This is a joint geometric identity, not a product of separately averaged ranks.

**Proof.** For fixed $i,L,v,z_{-i}$, the face-minus-slab contribution, averaged over its two signs, is
\[
 \frac12\int g(y)\{
 \chi(y+Lz_{-i}+be_i,L)+\chi(y+Lz_{-i}-be_i,L)
 -\chi(y+Lz_{-i}+a_ve_i,L)-\chi(y+Lz_{-i}-a_ve_i,L)\}\,dy.
\]
Expand the right side of (11) before its outer integrations and change variables separately in its four terms. The positions become
$c+h=b$, $c-h=a_v$, $-c-h=-b$, and $-c+h=-a_v$, with the displayed signs. This proves the identity. The coordinate average $1/n$ in the face law cancels the leading $n$ in (8). Every term is absolutely integrable since $|\chi|\le1$ and translations preserve $\int g=M$; Fubini and these changes of variables are therefore valid for $L^1$ sources and measurable row cuts.

An explicit bound retaining both factors is obtained by setting
\[
 H_{i,h}(g)=\int(\sqrt{g_-}-\sqrt{g_+})^2dy,\qquad
 J_{i,L,v,z}(g,\chi)
   =\int(\sqrt{g_-}+\sqrt{g_+})^2\Phi^2dy .
 \tag{12}
\]
Each inner half-pairing in (11) has absolute value at most
$\frac12\sqrt{H_{i,h}J_{i,L,v,z}}$. This follows by factoring
$g_--g_+=(\sqrt{g_-}-\sqrt{g_+})(\sqrt{g_-}+\sqrt{g_+})$
and applying Cauchy. The elementary bounds are only $H_{i,h}\le2M$ and $J_{i,L,v,z}\le4M$. They do not give the needed dimension gain.

The exact missing quantity is the signed sum in (11), or a genuinely paid estimate of its correlated factors. Source closure and the old prefix inequalities have not been shown to force this estimate. Replacing $\Phi$ by its absolute upper bound discards potentially essential cancellation between the two receiver positions.

## 4. The source-only modulus route has a linear barrier

Define the coordinate translation modulus of the actual restricted source
\[
 \omega_g(t)=\max_{1\le i\le n}\sup_{|r|\le t}
        \|g(\,\cdot+re_i)-g\|_1 .
 \tag{13}
\]
Since $2h=\delta vL/2\le\delta$, (11) gives the valid bound
\[
 |E_\delta|\le\frac{n\log2}{2}\,\omega_g(\delta).
 \tag{14}
\]
Consequently the source-only certificate for (2) is
\[
 D\le M+(\log2)\,C_g(\delta),\qquad
 C_g(\delta)=a_n(\delta)M+\frac n2\omega_g(\delta).
 \tag{15}
\]
For any fixed $g\in L^1$, $\omega_g(t)\to0$ as $t\to0$. This pointwise continuity does not yield a uniform dimension scale, and restriction to $S$ does not inherit a modulus bound of the original density.

Here is a precise obstruction even to choosing $\delta$ after seeing $g$.

**Proposition.** If for some coordinate and $0<r\le1/(2n)$,
$g$ and $g(\cdot+re_i)$ have disjoint supports up to null sets, then
\[
 \inf_{0<\delta\le1}C_g(\delta)\ge\frac n2M.              \tag{16}
\]
**Proof.** If $\delta\ge1/(2n)$, the supremum in (13) contains this translation and $\omega_g(\delta)=2M$, so $C_g(\delta)\ge nM$. If $\delta\le1/(2n)$, (7) and Bernoulli's inequality imply
$a_n(\delta)=n(1-\delta)^n\ge n(1-n\delta)\ge n/2$.
The second summand of $C_g$ is nonnegative. These cases prove (16).

This is a lower bound on the *upper certificate* in (15), not on $E_\delta$, $D/M$, or optimized capacity. In particular a rapidly varying source may still have small signed error in (11) because the receiver factor cancels. The proposition rules out finishing the task by optimizing (15) alone.

## 5. Averaged data do not supply the missing source modulus

The following stability fact makes the preceding limitation precise. Suppose two nonnegative sources of equal mass $W$ have a mass coupling supported on
$\|y-y'\|_\infty\le\varepsilon$. Let the first source be $f\,dy$. For $0<\varepsilon\le1/4$, at every $x$ and $L\in[1,2]$ their cube masses differ by at most
\[
 \int_{Q(x,L+2\varepsilon)\setminus Q(x,L-2\varepsilon)}
       f(y)\,dy
 \le \alpha_f(C_n\varepsilon),\qquad
 C_n=4n(5/2)^{n-1},                                    \tag{17}
\]
where $\alpha_f(t)=\sup_{|E|\le t}\int_E f$ and $\alpha_f(t)\to0$.

**Proof.** A pair can disagree about membership in $Q(x,L)$ only when its first endpoint lies in the displayed shell. Its volume is at most $C_n\varepsilon$ by the mean-value bound for $s^n$. Absolute continuity of the integral of $f$ gives the final uniform convergence. Division by $L^n\ge1$ preserves it for hard averages.

For a uniformly bounded kernel family with common spatial modulus
$\Omega(t)=\sup_K\sup_{\|z-z'\|_\infty\le t}|K(z)-K(z')|\to0$,
the same coupling gives the uniform convolution bound
\[
 \sup_{K,x}|K*f(x)-K*f'(x)|\le W\Omega(\varepsilon).
 \tag{18}
\]
This follows by integrating the kernel difference along the coupling.

An internal construction proves that, for every fixed $n$ and nonzero nonnegative $f\in L^1$, there are actual $L^1$ sources with the same mass, couplings of displacement tending to zero, and a disjoint coordinate translate tending to zero. Hence all observations in (17)–(18) converge, while those sources satisfy (16). The construction and exact support check are kept outside the public region. No original gate, earliest selector, principal pair, or high burden is asserted for these approximants. In particular uniform convergence of hard averages alone does not prove stability of first contact at tangencies. There is no all-input, full-gated counterexample to the requested joint error bound here.

## 6. Complement and remaining requirement

The paid part (6) is uniform over the whole actual cut; it does not discard receiver rows or sources. Its complement is exactly (11), with the same source, side and original selector. At $\delta=1/2$ the paid part is root-order, but the remainder still has only a linear general budget. Letting $\delta\downarrow0$ recovers the face law for a fixed source after source integration, but (7) restores a linear paid constant and (16) forbids a uniform benefit from the source-modulus certificate.

Thus no branch or error is silently omitted. A completion requires a quantitative estimate on the *joint* source/receiver difference in (11), retaining the original contact and principal source closure. Neither the separate translation modulus nor independent auxiliary kernel coordinates provide such an estimate. This component does not meet the general Hall-gain success criterion. The fresh principal-cut variance budget and the root-order signed-flux target remain open. No full-scale or background-layer factor is removed: these estimates concern the normalized window and original cut, and any later use retains the existing localization and layer accounting.

## 7. Verification and numerical scope

Both independent auditors received the exact finite-thickness, joint-difference and optimized-certificate statements before proof drafting, then completed formal full mathematical reads of this MD file and the matching TeX, including the private construction: PASS.

The author ran new exact rational checks in three stages: dimensions $2,3,4$; $8,16,32$; and $64,128,256$, each at $\delta=1/8,1/2,7/8,1/(4n)$. The 36 binomial laws produced 206 assertions; 27 cyclic-array signed-shift models produced 54 assertions. All 260 assertions passed in 0.049727625 seconds. These are nonphysical algebra checks, including the small-thickness obstruction; they do not certify any actual receiver gate, source capacity or high-load event. The independently reconstructed Sol guard separately passed 431 coverage-specific assertions: 148 pilot, 142 pressure and 141 expanded checks, comprising 54 binomial laws (including small thickness and $\delta=1$) and 27 four-shift/Hellinger models. It imports no author algorithm and has the same nonphysical algebra scope. Its counts are separate from the author’s 260 checks.

Both numerical owners received the face-versus-adjacent-slab observable while their original first-contact and coarse-gate work was ongoing. No additional physical scan was requested, and no absent or uncertified predicate was assigned a value. Optional evaluations require the actual source law, original selector and all row-event conditions; UNKNOWN remains UNKNOWN. This component claims no executed, fully qualified physical sampling experiment.

D01 and G03 skill, method and cube-interface instructions were read, and M03's current limited stability scope was checked. The proofs use explicit positive mass couplings and explicit mixed differences, not an unnamed tree, transport duality or near-extremizer theorem. No external theorem is imported. Only the two owned R90 coverage files were written; no Git or PDF compilation was performed.

## 1. Result and scope

A positive source supported in narrow intervals in k chosen coordinates, with unrestricted correlations and n−k unrestricted coordinates, has an unconditional local cube weak fee at most

    C_slab = [1+(n−k)log 2] ∏_(j∈J)(1+h_j).                (1)

The h_j are full interval lengths in the normalized full-side window L∈[1,2]. This is a newly proved source projection estimate; it does not invoke an unknown lower-dimensional weak constant. It gives a paid partial-slab packet branch, including every measurable receiver subcut, and a full-source finite-cover estimate with the uncovered source mass paid explicitly.

These results do not remove the general R89 concentration obstruction. The number of narrow coordinates, the number of source packets, their actual captured shares, repeated threshold fees and the terminal cannot be inferred from a lower bound on total coordinate atomic marginal mass. The stronger exact-plane fee 1+(n−k)/k remains unproved. This note records the precise failure of a scalar drift proof and the remaining geometric term. The arbitrary-positive-L1 root-order theorem remains open.

## 2. Direct partial-slab projection theorem

Let mu=f dy≥0 have mass W<∞. Choose J⊂{1,…,n}, |J|=k, and let m=n−k. Suppose mu is supported, in each coordinate j∈J, in an interval I_j of full length h_j≥0 and center a_j. The coordinates outside J are unrestricted. For actual nonzero L1 sources one can take positive widths; zero widths are also meaningful for finite measures whose projection onto the free coordinates has a density, including m=0. No product factorization or independence is assumed.

Write x=(u,z) in the chosen and free coordinates, and let g be the marginal of mu on R^m. Put A_L^(m)g(z)=L^(−m)g(Q(z,L)). Let M_[1,2]^(n) be the n-dimensional local centered cube maximal operator. Then for every t>0,

    t |{M_[1,2]^(n)mu≥t}| ≤ C_slab W.                       (2)

For m=0, R^0 has mass one, A_L^(0)g=W, and H_0=1. Thus (2) includes sources narrowly supported in all n coordinates.

Proof. If A_L^(n)mu(u,z)≥t, the cube meets the normal support, so

    |u_j−a_j|≤(L+h_j)/2  (j∈J),
    A_L^(m)g(z)≥t L^k.

For fixed z, take the supremum T(z) of qualifying L∈[1,2], with an empty set contributing zero receiver volume. The normal receiver boxes have a common center and are nested as L increases. Their union has volume at most ∏_(j∈J)(T(z)+h_j). Approximate the supremum by qualifying scales if it is not attained. Since T≥1,

    t normal_volume(z)
      ≤∏_(j∈J)(1+h_j) sup_(1≤L≤2) A_L^(m)g(z).             (3)

The elementary positive kernel envelope in m dimensions is

    E_m(v)=sup_(1≤L≤2) L^(−m)1_{2||v||∞≤L},
    ∫E_m(v)dv=1+m log 2=:H_m.

For m≥1 this follows from the central unit cube of mass one and the radial shell integral ∫_1^2 m dr/r. Tonelli gives ∫sup_L A_L^(m)g≤H_m W. Integrating (3) proves (2). The zero-dimensional convention gives the same proof. The strict-superlevel version follows immediately; the non-strict version can alternatively be obtained by lowering the threshold and taking a limit. For L1 sources the scale averages are continuous and the local supremum is measurable.

The proof uses an explicit pointwise source projection and exact normal receiver volume. Replacing the union volume by a fixed side-two box would introduce an unnecessary 2^k factor. Conversely the free-dimensional H_m is an actual expense, not a lower-dimensional endpoint constant assumed to be small. A window [r,2r] has widths h_j/r in (1); the later all-scale reduction is still charged.

## 3. Countable common packets and every receiver subcut

Let mu=Σ_nu mu_nu be a countable disjoint source partition, or more generally a positive fractional splitting whose sum is exactly mu. Packet nu has its own chosen coordinate set J_nu and widths h_(nu,j), and let

    C_nu=H_(n−|J_nu|)∏_(j∈Jnu)(1+h_(nu,j)),
    W_nu=mu_nu(R^n).

Different coordinate choices are fixed packet labels. They do not cause a binomial factor. Using many overlapping copies of the same source without a fractional splitting does cause multiplicity and is not permitted for free.

On any measurable receiver set B with a common threshold lambda and an actual contact selector satisfying A_L(x)mu(x)=lambda, define

    p_nu(x)=A_L(x)mu_nu(x)/lambda,  Σ_nu p_nu(x)=1,
    eta_a(x)=Σ_nu p_nu(x)1_{p_nu(x)≥a},   0<a≤1.

For 0<rho≤1, the partial-slab branch E={x∈B:eta_a(x)≥rho} satisfies

    lambda |E| ≤ [1+log(1/a)]/rho · Σ_nu C_nu W_nu.         (4)

Proof. For each packet,

    p 1_{p≥a}=a1_{p≥a}+∫_a^1 1_{p>t}dt.

Each receiver with p_nu≥t belongs to the packet maximal event at t lambda. Applying (2), including its non-strict endpoint, gives

    lambda∫_B p_nu1_{p_nu≥a}dx
      ≤ C_nu W_nu [1+log(1/a)].

Sum by Tonelli and use eta_a≥rho. Countably many packets introduce no packet-count loss beyond their actual source masses.

If C_nu≤C_* uniformly, this is also an all-subcut bound on the original capture graph:

    lambda |A| ≤ P_slab mu(N_A),
    P_slab=C_*[1+log(1/a)]/rho,
    N_A={y:b_A(y)>0},
    b_A(y)=∫_A L(x)^(−n)1_Q(x,L(x))(y)dx,   A⊂E.           (5)

Indeed restricting each mu_nu to N_A preserves the packet slab support. Tonelli shows that almost every row in A captures no mass from N_A^c; by countability its contact and every packet share are unchanged simultaneously. Apply (4) to the restricted source. No smooth or later gate is transferred under this restriction: the proof only needs the preserved hard contact. Formula (5) is a capacity inequality for this paid branch, not for its unproved complement.

One concrete root-scale choice is h_(nu,j)≤1/n and at most m_0=ceil(sqrt n) free coordinates per packet. Then C_*≤eH_m0. Taking a=n^(−p) for fixed p>0 and fixed rho>0 gives P_slab=O_p(sqrt n log(n+2)). This is unconditional payment of the stated branch; its coverage fraction is not assumed.

## 4. A finite geometric cover with its complement paid

Suppose the source is decomposed as

    mu=mu_bad+Σ_(nu=1)^N mu_nu,   N≥1,

where the good packets satisfy C_nu≤C_*. A finite union of slab supports may be disjointified in a fixed order before forming these packets; restriction preserves support. Put W_bad=mu_bad(R^n), W_good=Σ W_nu. For any 0<tau<1 the entire hard-contact receiver event satisfies

    lambda |B|
      ≤ H_n W_bad/tau
       +[2C_*/(1−tau)] [1+log(2N/(1−tau))]W_good.           (6)

Proof. Rows with bad-source captured share at least tau belong to the local maximal event of mu_bad at tau lambda. The ordinary positive envelope H_n pays them by the first term. On the other rows the good captured share exceeds 1−tau. Set a=(1−tau)/(2N). The sum of the N good shares below a is at most Na=(1−tau)/2. Thus their eta_a is at least (1−tau)/2, and (4) pays the remaining rows. Both source masses in (6) are the actual ones.

The same estimate holds for the whole strict local maximal event: choose a measurable witnessing scale with A_L mu>lambda and normalize the packet shares by A_L mu instead of lambda. Then lambda p_nu≤A_L mu_nu, so all superlevel and layer-cake arguments remain valid. A countable rational scale selection is available for L1 sources. Hence (6) is a genuine weak bound for this finite-cover class, not an assumed property of a selector.

For example, if h_(nu,j)≤1/n, each good packet has at most ceil(sqrt n) free coordinates, N≤n^q for fixed q, and W_bad≤W/sqrt n, take tau=1/2. Formula (6) gives O_q(sqrt n log(n+2))W for the entire local event, including the uncovered source. The retained all-scale cost and original paid branches still apply in the general reduction. No assertion is made that an arbitrary input or an actual recursive child has such a cover.

## 5. Why R89 concentration does not provide this cover

R89 proves that a persistent actual high-burden band forces every normalized child-source weak limit nu to have

    Σ_j atom(nu_j) ≥5R_*/(12 log 2).

This controls total atomic marginal mass, not the size of an atom, a joint slab packet, the number of relevant packets, or its captured posterior share. It cannot be used to infer (4)'s coverage or (6)'s near-full-coordinate finite cover.

Here is precise pressure on that implication, at the level of a generic normalized LIMIT LAW only. For integers 0≤r<k≤n let

    nu=delta_0^(tensor r) tensor Unif([0,1]^(n−r)).

Its total atomic marginal mass is r. Every set pinning k coordinates to intervals of width at most h<1 has nu-mass at most h^(k−r), regardless of coordinate choices and centers. At least k−r pinned coordinates are uniform; each contributes at most h. Therefore a union of N such partial slabs has mass at most N h^(k−r).

In particular covering mass 1−epsilon requires

    N≥(1−epsilon)h^(−(k−r)).                               (7)

With h=1/n, r of root order, and k=n−O(sqrt n), this forces log N of order n log n. The explicit finite-cover fee (6) then does not have a root-order coefficient. This is a limitation of that inference and displayed payment, not a lower bound for the true cube weak constant. A singular normalized limit with these marginals is allowed by the R89 conclusion. Absolutely continuous approximations exist, but no original gates, high-load receiver event or actual recursive chain is claimed for this law. Source-cell mass alone also cannot be substituted for the captured p_nu.

## 6. The stronger exact-plane conjecture and its scalar obstruction

For a source delta_0^(tensor k) tensor g in n=k+m dimensions, the exact normal receiver fiber is governed by

    T_lambda(z)=sup{L∈[1,2]: A_L^(m)g(z)>lambda L^k},

with an empty fiber contributing zero. Its weak demand is lambda∫T_lambda(z)^k dz. The stronger proposed coefficient 1+m/k, k>0, is NOT proved here and is not disproved by the finite geometric diagnostics. The proved coefficient from Section 2 remains H_m. The parent's separate normal-fiber accounting note retains the distinction between a strong bound for sup L^(−k)A_Lg and this weak fiber integral; those quantities cannot be identified.

A tempting proof using only mass conservation and negative scale drift fails rigorously. This is a NONPHYSICAL receiver-label model, not a common-source cube convolution. Fix m,k>0, T>0, W>0 and lambda>0. Use a disjoint initial receiver block of measure W/lambda and new receiver labels s∈(0,T] with measure

    dxi(s)=(mW/lambda)e^(−ks)ds.

For 0≤t≤T put h_t=lambda e^(−mt) on the initial block, and

    h_t(s)=lambda e^(ks)e^(−m(t−s))1_{s≤t}

on the new labels. Direct integration gives ∫h_t dxi=W for every t. Distributionally in t, partial_t h_t≥−m h_t because the births are positive. Nevertheless, with the NON-STRICT last-threshold time

    ell(xi)=sup{t∈[0,T]:h_t(xi)≥lambda e^(kt)},

one has ell=0 on the initial block and ell=s on label s, so

    lambda∫e^(k ell)dxi = W(1+mT).                          (8)

Thus mass and this correct negative-drift inequality do not yield 1+m/k: for T=log 2 and k>1/log 2, (8) exceeds that coefficient. Equality at a birth is not misidentified as a strict exceedance. Any universal strict-superlevel estimate would imply its non-strict version by lowering the threshold and taking a limit on this finite receiver space; equivalently small amplitude inflation gives the same limiting obstruction. This model does not satisfy the additional relation h_t=A_(e^t)^(m)g for a single physical g, and therefore does not disprove the exact-plane conjecture. A proof of that conjecture must use an actual common-source, cross-scale geometric restriction absent from this model.

## 7. Actual recursion, repeated payment, and terminal

Retain the complete original current-input classification. Let H_n=1+n log2, theta=log⁻²(n+2), alpha=epsilon=1/[10log(n+2)], c=1−alpha−epsilon, delta=1/2, beta=c/2. At every source restriction recompute all original gates, earliest contact, original kappa layer when used, the old dominant-packet shares, physical collision and mean shifted-grid entropy. The old whole residual is exactly

    Fnew_i=Fdiff_i∩{C_h*<3/4,Hbar_h*>sqrt n}.

The old parameters remain h0=1/(16n²), a0=n^(−p), rho0=n^(−1/2), h*=1/(16n^(3/2)). If using (4), choose one common partial-slab partition for the current input and remove its paid event before constructing current B_i. Source restriction preserves each fixed packet support but changes every packet mass, free projection and captured share. They must be recomputed. The new whole residual is Fnew_i minus that branch; current B_i is a subset, not the whole event.

Define q_i from the actual captured-stop kernel, S_i={q_i>K}, mu_{i+1}=mu_i|S_i, lambda_{i+1}=beta lambda_i, t_i=beta^(−i). Bad rows retain more than delta of their stopped mass; fresh classification gives nested continuing cubes as before. With G=2K/c and the retained paid coefficient

    B_base=4+2(log2)sqrt(7n/3),  B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta^(−1)+4theta/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*),  B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt n],
    A_old=B_base+B_ext+T_soft/alpha+P_dom+P_phys,

the finite recursion keeps the complete bound

    lambda_0|E_init|
      ≤Σ_(i<ell)t_i[A_old W_i
          +(1+log(1/a))/rho ·Σ_nu C_(i,nu)W_(i,nu)
          +G(W_i−W_{i+1})]+H_n t_ell W_ell.                (9)

P_phys pays its union once. Add any other used deletion fee; none is introduced here. If the robust full cover (6) is verified at a stopping input ell, replace the final H_n t_ell W_ell by the completely paid terminal

    t_ell{H_n W_(ell,bad)/tau
      +[2C_*/(1−tau)][1+log(2N/(1−tau))]W_(ell,good)}.      (10)

No residual is silently discarded. If a cover holds already at stage zero, (6) gives direct payment and no recursion is needed. If it first holds later, every preceding term of (9) still remains. On a fixed disjoint partition the repeated packet expense is exactly a threshold-weighted source occupation,

    Σ_(i<ell)t_iΣ_nu C_nu W_(i,nu)
      =∫ [Σ_(i<ell)t_i C_(nu(y))1_(Z_i)(y)]dmu_0(y),        (11)

where mu_i=mu_0|Z_i and the Z_i are nested. Disjoint packets do not make this cross-stage sum disjoint. There is no established bound for (11), intervening stages or the general terminal at root scale. R89's conditional marginal-modulus budget is not assumed.

The return to the all-scale bound costs C_loc log(n+2); separate original-kappa-layer summation pays its J_n=O(log n). The general baseline remains O(n log n). The paid slab branch and full finite-cover class are new valid reductions; the general concentration/recurrence payment and stronger exact-plane conjecture remain open.

## 8. Three-stage validation

Pilot: both auditors independently checked the normal fiber volume, exact free-dimensional envelope, packet layer cake, all-subcut source restriction and robust-cover complement before reading this proof.

Pressure: the normalized limit-law calculation (7) prevents promotion of coordinate atomic totals into near-full-coordinate finite covers. The nonphysical birth model (8) excludes a proof of the stronger fee using only mass and negative drift. Neither is represented as an actual gated high-burden counterexample.

Expansion: the proofs include anisotropic widths, arbitrary coordinate labels and correlations, zero free coordinates, countable positive partitions, all measurable subcuts, leaked source mass, and every finite recursive horizon with its terminal. Bounded floating diagnostics of singular exact-plane sources found no violation of the stronger conjecture; they neither certify that conjecture nor an original gated chain. Actual source/test recipes and numerical sampling details are excluded from this public section. No PDF compilation or Git operation was performed by this author.

The general cube weak bound of order $\sqrt n\,n^{o(1)}$ remains unproved. This note does not assume a subpower weak bound for the Gamma-smoothed cube maximal family. It proves an explicit transfer test for that premise and a necessary all-scale error budget for any proposed positive ergodic approximation. The transfer uses a single common threshold, actual probability densities and a quantified discarded-event cost. It gives no new general upper bound. Specific lower-catalog applications and their unpublished conclusions are kept outside this public theorem.

## 1. Kernels, full sides and the precise transfer statement

Write
\[
 B_L f(x)=L^{-n}\int_{[-L/2,L/2]^n}f(x-y)\,dy,
 \qquad
 \Psi_{n,t}(x)=\frac{e^{-\|x\|_\infty/t}}{2^n n!t^n},
 \qquad M_\Psi f=\sup_{t>0}\Psi_{n,t}*|f|.
 \tag{1}
\]
Thus $L$ is the full cube side. If $G$ has Gamma density $z^ne^{-z}/n!$ on $z>0$, then
\[
 \Psi_{n,t}*f=\mathbb E[B_{2tG}f],\qquad f\ge0.
 \tag{2}
\]
Indeed, at a spatial point of infinity norm $r$, the mixture density is the integral of $(2tz)^{-n}z^ne^{-z}/n!$ from $r/t$ to infinity, which equals (1). The shape parameter is $n+1$. Positivity and this scale-mixture identity do not assert a semigroup law for $\Psi$.

Here is the exact generic statement. Fix $n\ge4$, constants $0<m\le1\le M<\infty$, and a one-periodic measurable density $\rho$ with
\[
 m\le\rho\le M\quad\hbox{almost everywhere},\qquad
 \int_0^1\rho=1.
\]
Set
\[
 a_L(x)=\frac1L\int_{-L/2}^{L/2}\rho(x-y)\,dy,
 \qquad F(x)=\prod_{i=1}^n\rho(x_i),
 \qquad A_L(x)=B_LF(x)=\prod_{i=1}^na_L(x_i).
 \tag{3}
\]
Let $P$ be normalized Haar measure on $[0,1)^n$. Fix a list of $N\ge1$ sides $L_j\in[1,2]$, a real $h$, numbers $u\ge1$, $b>0$, and measurable events $E_j$ satisfying
\[
 E_j\subseteq\{A_{L_j}>e^h\},\qquad
 P\!\left(\bigcup_{j=1}^NE_j\right)
                 \ge\frac{bN}{u}e^{-h}.
 \tag{4}
\]
This is an assumption about the actual union, not a sum of marginal probabilities. No disjointness or independence of the events is assumed. Define
\[
 D_0=2(M-m),\qquad C_0=\frac{D_0}{m}+\frac{D_0^2}{m},
 \qquad R_{\rm M}=\frac{2C_0u}{b},
\]
\[
 R_{\rm H}=\frac{D_0^2}{m}
       +\frac{D_0}{m}\sqrt{2\log_+(2u/b)},
 \qquad R=\min\{R_{\rm M},R_{\rm H}\},
 \qquad \log_+v=\max\{0,\log v\}.
 \tag{5}
\]
Then there is an actual nonnegative $L^1(\mathbb R^n)$ input, obtained by truncating this same periodic $F$, whose $M_\Psi$ weak budget is at least
\[
 \mathcal B_{\rm finite}
       =\frac{bN}{96u}e^{-R}.
 \tag{6}
\]
Taking larger integer truncation boxes shows that the full weak constant of $M_\Psi$ is at least
\[
 \mathcal B=\frac{bN}{48u}e^{-R}.
 \tag{7}
\]
All constants in these claims are explicit. When the bounds $m,M$ or the union parameter $b$ vary, their full dependence through (5)--(7) must be retained. Mere positivity of each finite input is not a dimension-uniform lower bound on $m$.

## 2. Tilted logarithmic stability in a physical side window

Every $a_J$ is a normalized one-dimensional periodic probability density and lies in $[m,M]$. For $J\in[1/2,5/2]$, its derivative in $J$, wherever it exists, is
\[
 \partial_Ja_J(x)=\frac{\rho(x+J/2)+\rho(x-J/2)}{2J}
                         -\frac{a_J(x)}J.
\]
The numerator difference is at most $M-m$ in absolute value. The integral definition is absolutely continuous in $J$, so it follows for all sides in this interval that
\[
 |a_J(x)-a_L(x)|\le D_0|J-L|.
 \tag{8}
\]
Changing an almost-everywhere representative of $\rho$ does not change any average. The displayed derivative identity is used only almost everywhere; the resulting Lipschitz inequality is valid for the integral representative.

Define the actual tilted probability $Q_L$ on the torus by $dQ_L=A_L\,dP$. It is normalized because $\int_0^1a_L=1$, and its coordinates are independent with density $a_L$. This independence belongs to the specified product input; it is not a claim about arbitrary physical source densities.

For a single coordinate with law $a_L(x)dx$, write $Z(x)=\log(a_J(x)/a_L(x))$ and $\Delta=J-L$. The standard elementary entropy estimate here follows directly from $\log v\le v-1$:
\[
 -\mathbb E_{a_L}Z
 =\int a_L\log\frac{a_L}{a_J}
 \le\int\frac{(a_L-a_J)^2}{a_J}
 \le\frac{D_0^2}{m}\Delta^2.
 \tag{9}
\]
The integral on the left is nonnegative by Jensen, so its absolute value obeys the same bound. Also the logarithm is $1/m$-Lipschitz on $[m,M]$, whence
\[
 \operatorname{Var}_{a_L}(Z)\le\mathbb E_{a_L}Z^2
                         \le\frac{D_0^2}{m^2}\Delta^2.
 \tag{10}
\]
The normalization of both one-coordinate densities is essential in (9): replacing the relative entropy by a first-order pointwise estimate would lose the quadratic mean term.

Under the genuine product law $Q_L$, the log ratio of the full cube averages is a sum of independent copies of $Z$. Centering that sum and using Cauchy--Schwarz gives
\[
 \mathbb E_{Q_L}\left|\log\frac{A_J}{A_L}\right|
 \le \frac{D_0}{m}\sqrt n\,|\Delta|
       +\frac{D_0^2}{m}n\Delta^2
 \le C_0
 \quad\hbox{if }|J-L|\le n^{-1/2}.
 \tag{11}
\]
The side window lies in $[1/2,5/2]$ for $n\ge4$ and $L\in[1,2]$. Thus every density, normalization and derivative bound used above holds on the entire window.

## 3. The actual Gamma window has constant mass

Fix one tested side $L$ and use the deterministic clock
\[
 t_L=\frac{L}{2n},\qquad J=2t_LG=\frac LnG.
 \tag{12}
\]
Let $\omega_L$ be the probability that $|J-L|\le n^{-1/2}$, and let $\pi_L$ be the conditional distribution of $J$ on that window. Since $L\le2$, the Gamma interval $G\in[n,n+\sqrt n/2]$ lies inside the window. The retained elementary factorial bound $n!e^n/n^n\le6\sqrt n$ gives, for $z=n+s\sqrt n$ and $0\le s\le1/2$,
\[
 \frac{z^ne^{-z}}{n!}
 \ge\frac1{6\sqrt n}
        \exp\!\left(n\log(1+s/\sqrt n)-s\sqrt n\right)
 \ge\frac{e^{-1/8}}{6\sqrt n}.
\]
The last step uses $\log(1+x)\ge x-x^2/2$ for $x\ge0$. Integration over an interval of length $\sqrt n/2$ yields
\[
 \omega_L\ge\frac{e^{-1/8}}{12}\ge\frac1{24}.
 \tag{13}
\]
No normal approximation or asymptotic Gamma tail is used. This is a uniform finite-dimensional lower bound with the true shape and clock.

Set
\[
 W_L(x)=\int\log\frac{A_J(x)}{A_L(x)}\,\pi_L(dJ).
\]
These logarithms are measurable and bounded for each fixed dimension; Fubini and (11) give
\[
 \mathbb E_{Q_L}|W_L|\le C_0.
 \tag{14}
\]
Retain only the positive Gamma-window contribution in (2), then apply Jensen to this conditional probability measure:
\[
 \Psi_{n,t_L}*F(x)
 \ge\omega_L\int A_J(x)\,\pi_L(dJ)
 \ge\omega_L A_L(x)e^{W_L(x)}.
 \tag{15}
\]
Only this restricted positive integral will be used after finite truncation. We do not identify the full Gamma convolution of a truncated input with its periodic counterpart.

## 4. A common threshold and the complete union-loss payment

Suppose first $D_0>0$. We give two separately valid thresholds and use their deterministic minimum without an additional union fee. From (14), Markov's inequality gives $Q_L\{W_L<-R_{\rm M}\}\le b/(2u)$.

A sharper threshold comes from the same genuine product tilt. The window measure $\pi_L$ is deterministic, so
\[
 W_L(x)=\sum_{i=1}^n w_L(x_i),\qquad
 w_L(v)=\int\log\frac{a_J(v)}{a_L(v)}\,\pi_L(dJ).
\]
These coordinate functions are independent under $Q_L$. Equations (8)--(9) and the side window give
\[
 |w_L|\le\frac{D_0}{m\sqrt n},\qquad
 \mathbb E_{Q_L}W_L\ge-\frac{D_0^2}{m}.
 \tag{15a}
\]
For completeness, the required bounded-variable exponential inequality has a short direct proof. If a real variable $V$ lies in an interval of length $d$, the second derivative of $H(s)=\log\mathbb E e^{sV}$ is its variance under the exponentially tilted law. That variance is at most $d^2/4$, by subtracting the midpoint of its interval. Integrating twice from zero gives $\log\mathbb E e^{s(V-\mathbb EV)}\le s^2d^2/8$ for every real $s$. Applying this to the independent $w_L(x_i)$, whose squared interval lengths sum to at most $4D_0^2/m^2$, and optimizing the exponential Markov inequality proves
\[
 Q_L\{W_L<-D_0^2/m-z\}
       \le\exp\!\left(-\frac{m^2z^2}{2D_0^2}\right),
       \qquad z\ge0.
 \tag{15b}
\]
When $b/(2u)<1$, choose $z=(D_0/m)\sqrt{2\log(2u/b)}$ to obtain $Q_L\{W_L<-R_{\rm H}\}\le b/(2u)$. When $b/(2u)\ge1$, the same conclusion follows from the trivial probability bound by one, with the declared $\log_+$ convention. Therefore both thresholds are valid, and whichever equals their fixed minimum $R$ gives
\[
 Q_{L_j}\{W_{L_j}<-R\}\le\frac{b}{2u}.
 \tag{15c}
\]
On $E_j$ the density $A_{L_j}$ is larger than $e^h$. Therefore the original Haar probability of the discarded part is
\[
 P(E_j\cap\{W_{L_j}<-R\})
 \le e^{-h}Q_{L_j}\{W_{L_j}<-R\}
 \le\frac{b}{2u}e^{-h}.
 \tag{16}
\]
Each event uses its own normalized tilt, while the conversion factor $e^{-h}$ and final threshold are common. Summing these losses over all $N$ events and subtracting them from the actual union in (4) gives
\[
 P\!\left(\bigcup_j(E_j\cap\{W_{L_j}\ge-R\})\right)
                  \ge\frac{bN}{2u}e^{-h}.
 \tag{17}
\]
This subtraction does not require disjointness; the removed part of the union is contained in the union of the removed parts. If $D_0=0$, then $\rho=1$ almost everywhere, $W_L=0$ identically and there is no discarded part; (17) still holds.

On the retained union, (13) and (15) imply a strict exceedance of the single threshold
\[
 \lambda_\Psi=\frac1{24}e^{h-R}.
 \tag{18}
\]
For the periodic model, multiplying this threshold by (17) gives $bN e^{-R}/(48u)$. The $N$-fold deletion cost has been paid explicitly; a single-scale expectation estimate alone would not have sufficed.

To produce a genuine $L^1$ input, let $B>2$ be an integer and set $f_B=1_{[-B,B]^n}F$. Periodicity gives exactly $\|f_B\|_1=(2B)^n$. On the integer-period receiver box $[-B+2,B-2]^n$, every cube with side in a retained window $J\le5/2$ stays inside the source box. Thus its average equals the corresponding periodic $A_J$. The positive window argument proves the same strict threshold exceedance on every translate of the retained torus event in this box. Its actual receiver volume is the Haar probability multiplied by $(2B-4)^n$. Consequently
\[
 \frac{\lambda_\Psi|\{M_\Psi f_B>\lambda_\Psi\}|}{\|f_B\|_1}
 \ge\left(1-\frac2B\right)^n
              \frac{bN}{48u}e^{-R}.
 \tag{19}
\]
Taking $B=n^2$, Bernoulli's inequality gives $(1-2/n^2)^n\ge1-2/n\ge1/2$, proving (6). Letting integer $B$ tend to infinity proves (7). Only the retained bounded side windows were matched to the periodic source; the rest of the Gamma mixture is nonnegative and was discarded.

## 5. What a paid ergodic error must actually pay

The common probability-convolution Cesàro maximal operator $M_{\rm erg}$ from the retained endpoint theorem has weak $(1,1)$ constant one. Suppose a proposed comparison, for every nonnegative $f\in L^1$, takes the form
\[
 M_\Psi f\le A M_{\rm erg}f+\mathcal E^*f,
 \qquad
 |\{\mathcal E^*f>\lambda\}|\le\frac{D\|f\|_1}{\lambda},
 \tag{20}
\]
where $A,D\ge0$ are uniform over all scales and inputs. Here $\mathcal E^*$ must control the supremum of the actual scale errors. A separate $L^1$ or total-variation error for each fixed scale is not (20).

For $0<\theta<1$, a threshold split gives
\[
 \lambda|\{M_\Psi f>\lambda\}|
 \le\left(\frac A\theta+\frac D{1-\theta}\right)\|f\|_1.
\]
Optimizing at $\theta=\sqrt A/(\sqrt A+\sqrt D)$, with zero cases obtained by limits, gives total weak budget $(\sqrt A+\sqrt D)^2$. Hence every instance of the transfer theorem forces the quantitative necessary expense
\[
 D\ge\left(\sqrt{\mathcal B}-\sqrt A\right)_+^2,
 \qquad
 \mathcal B=\frac{bN}{48u}e^{-R}.
 \tag{21}
\]
This is a proved obstruction test for any claimed all-scale error estimate, not such an estimate. It applies to the same actual input and threshold through (19), followed by the large-box limit. It does not charge a list of input-dependent errors against unrelated receivers or assume that several weak-type costs add linearly.

The retained cube comparison $M_{\rm cube}\le c_nM_\Psi$, with $c_n\le6\sqrt n$, would yield a cube weak bound at cost $c_n(\sqrt A+\sqrt D)^2$ if (20) were established. No subpower value of this parenthesized budget is proved here. The generic transfer (7) must be checked before postulating it; the private lower-catalog qualification exercise is recorded separately, without publishing a new actual-model lower construction or conclusion.

## 6. Three-stage verification and the remaining route

The author executed 387 new generic checks in 0.040636 seconds, separate from the analytic proof. The pilot contained 80 checks on normalized finite rational tilted laws, with logarithms enclosed by rational series and explicit remainder bounds; these checked the quadratic entropy and logarithmic second-moment inequalities. Obstruction pressure contained 240 checks on overlapping-event union deletion, conversion from tilted to reference mass, and the optimized weak threshold split. The expanded stage contained 67 checks at $n=4,9,16,64,256,1024$, including the exact full-side clock, the retained Gamma subwindow, the factorial normalization with a rational exponential upper bound, and the finite-box factor. These are public finite-law or scalar checks, not physical source tests, an asymptotic lower proof or a certificate of the original Fnew gates. All model-specific conclusions rest on the analytic theorem and the separately qualified retained input, not these tests. After independent prechecks of the sharper threshold, a further 132 exact rational checks passed in 0.001853 seconds. These tested the interval-variance bound under arbitrary positive rational tilts, the dimension cancellation in the sum of squared ranges, and the optimizing exponential parameter through $n=1024$. The analytic proof of (15a)--(15c), not these finite checks, supplies the general concentration assertion. The total author count is 519 new checks. Both auditors received the exact transfer statement before the proof, including the actual union premise, normalization of every tilt, Gamma shape and clock, finite truncation and all-scale error norm.

The route has isolated a concrete necessary expense: local Gamma smoothing can preserve a supplied common-threshold union after paying the exponential factor in (7), and any ergodic error comparison must pay at least (21). It has not supplied a general upper estimate for that expense. A further upper-bound route must avoid treating a direct subpower bound for $M_\Psi$ as an available tool; it needs a different intermediate family or a decomposition in which the cube target and the paid error are controlled jointly. Such a decomposition and its all-scale budget remain open.

## S1. 结论和保留账

本轮给出 ORIGINAL P1 与 ORIGINAL coarse 核的精确 Fourier 乘子、统一级数尾界、连续相位/尺度包络和有限空间截断误差。这些是从原定义独立证明的证书工具；它们本身没有认证某个实际输入的全门，也没有一般容量或根阶弱型收益。R82 全部门、R87 付费分割、R89 全部费用和 EXACT Fnew 均保留；一般 O(n log n) 基准不变。

已读 R90 合同、R81 soft 原核定义以及 R87/R89 flux 的原门约定；数值作者确认 coarse 是原宽度 η=θ=log^{-2}(n+2)，不是把某个新软度混合核代替它。已读 updated64 F02 的 SKILL、method、cube-interface 与 provenance；使用的仅是可积张量/Fourier 约定核验，未迁移其目录中圆上严格正定性或 stretched-Gaussian 定理。A03 本轮只读入口范围，用于核对归一化集中不被普通 AC 排除；未声称重新阅读其全部来源。

实际物理输入与 Fourier 系数赋值、抽样和接收单元均由数值作者拥有，配方不进入此公共节。以下 g 或 τ 为一般周期密度/测度，不等于已认证的实际源。

## S2. 原核、归一化与 2π/full-side 乘子

采用 Fourier 约定 f̂(ξ)=∫e^{-2πiξz}f(z)dz。定义

\[
 h=\mathbf1_{[-1/2,1/2]},\quad
 w(z)=\int_0^1 e^{-|z|/r}\,dr,\quad
 w_\eta(z)=\eta^{-1}w(z/\eta),\quad \phi_\eta=h*w_\eta.
\]

所有 η>0；所有函数为真实空间非负核。令 h_L(z)=L^{-1}h(z/L)，w_{η,L}(z)=L^{-1}w_η(z/L)，φ_{η,L}=h_L*w_{η,L}。这里 L 是 FULL SIDE。n 维原平滑为 Φ_{η,L}=φ_{η,L}^{⊗n}，P_{η,L}=f*Φ_{η,L}。P1 是 η=1；coarse 是上述 θ，且必须在 ORIGINAL 最早选中的 L* 评价。

Tonelli 给出 ∫w=∫_0^1 2rdr=1，故 h、w_η、φ_η 及其尺度/张量全都质量 1。对 r>0，直接积分正、负半轴得到

\[
 \widehat{e^{-|\cdot|/r}}(\xi)
 =\frac{2r}{1+(2\pi r\xi)^2}.
\]

Fubini 再给出，令 q(a)=log(1+a²)/a²、q(0)=1，

\[
 \widehat w(\xi)=q(2\pi\xi),\qquad
 \widehat\phi_{\eta,L}(\xi)
 =\operatorname{sinc}(\pi L\xi)q(2\pi\eta L\xi),
 \quad\operatorname{sinc}(v)=\frac{\sin v}{v}. \tag{S2}
\]

在 n 维只是这些乘子的乘积，由可积性和 Fubini 得出。q 正且随 |a| 递减，sinc 可为负；例如 L=3/2、ξ=1 时 sinc=−2/(3π)。非负空间核不等于正 Fourier 乘子。把半边长 r 写成 full-side L=2r 之后 sinc 才相应变为 sinc(2πrξ)，不能遗漏这一倍数。

## S3. 一般周期测度的绝对尾界

设 τ 是圆 R/Z 上正有限测度，一周期真实总质量 M。令 τ̂(k)=∫e^{-2πiky}dτ(y)，则 |τ̂(k)|≤M。记 G_{η,L} 为 φ_{η,L} 对 τ 的周期卷积。以下均匀适用于 L≥L0>0、η≥η0>0，令 c=2πη0L0。整数 K≥1 的 Fourier 截断保留 |k|≤K，尾是 |k|>K。

由 |sinc(πLk)|≤1/(πL|k|)、q 单调性，

\[
 |G_{\eta,L}(x)-\sum_{|k|\le K}\widehat\tau(k)
 \operatorname{sinc}(\pi Lk)q(2\pi\eta Lk)e^{2\pi ikx}|
 \le\frac{2M}{\pi L_0c^2}\sum_{k>K}
 \frac{\log(1+c^2k^2)}{k^3}. \tag{S3a}
\]

函数 log(1+c²x²)/x³ 正且递减：其导数的符号由 2z/(1+z)−3log(1+z)<0 决定，因 log(1+z)≥z/(1+z)。故级数不超过从 K 到无穷的积分。分部积分给出

\[
 I_3(K,c)=\frac{\log(1+c^2K^2)}{2K^2}
 +\frac{c^2}{2}\log(1+(cK)^{-2}).
\]

因此可执行的统一尾包络为

\[
 T_3(K)=\frac M{\pi L_0}
 \left[\frac{\log(1+c^2K^2)}{c^2K^2}
       +\log(1+(cK)^{-2})\right]. \tag{S3b}
\]

这里没有把 M 偷换成 1，也没有把归一化物理源的总质量移除。尾包络不依赖相位或窗口中的 L、η；不能删除 η0^{-2} 依赖后用于任意窄 coarse。

若另有已证明的真实系数界 |τ̂(k)|≤A/|k| 对所有 |k|>K，则同样得到

\[
 T_4(K)=\frac{2A}{\pi L_0c^2}I_4(K,c),
\quad I_4(K,c)=\frac{\log(1+c^2K^2)}{3K^3}
 +\frac{2c^2}{3}\left[\frac1K-c\left(\frac\pi2-\arctan(cK)\right)\right]. \tag{S3c}
\]

证明是对 log(1+c²x²)/x⁴ 分部积分，余项为 (2c²/3)∫_K^∞[x²(1+c²x²)]^{-1}dx。这也显示 I4 正。大 cK 时括号有消去；程序须用稳定积分表示或有向/有理包络，不能把浮点正差直接当证书。实际输入如何满足 A/k 界由其数值作者另证，公共节不给物理配方。

## S4. 连续窗口与相位的两个不同预算

**只有总质量 M 的版本。** 由 q(a)=∫_0^1 2r/(1+a²r²)dr，可得

\[
 -a q'(a)=2[q(a)-(1+a^2)^{-1}]\in[0,2q(a)].
\]

对 s(L)=sinc(πkL)，有 Ls'=cos(πkL)−s，于是 |L(sq)'|≤4q，且 |2πk sq|≤(2/L)q。q(cx) 递减，∑_{k≥1}q(ck)≤∫_0^∞q(cx)dx=π/c；最后一个积分可再由分部积分算出。因此整个连续周期场满足

\[
 |\partial_LG|\le\frac{4M}{\eta_0L_0^2},\qquad
 |\partial_xG|\le\frac{2M}{\eta_0L_0^2}. \tag{S4a}
\]

零频率导数为零。导数级数一致绝对收敛，所以这些不仅是有限节点的导数。它们是对给定 η0 的界，不是免费任意 η 统一界。

**有真正 L∞ 源界的较强版本。** 若 τ=gdy，且周期密度 0<b0≤g≤B0，则 G∈[b0,B0]。空间 h_L 的分布导数为两边界原子之差，TV=2/L，故 |∂xG|≤2B0/L。尺度导数 h_L 的 TV=2/L；另一方面

\[
 w_{\eta,L}=\int_0^1 2r\,p_{\eta Lr}\,dr,
 \qquad p_b(z)=\frac{e^{-|z|/b}}{2b}.
\]

p_b 的 L 尺度导数 L1 范数等于 E|E−1|/L=2/(eL)，其中 E 是单位指数变量；积分 E|E−1|=2/e 可在 [0,1]、[1,∞) 直接分部计算。卷积求导和概率归一化于是给出

\[
 |\partial_xG|\le\frac{2B_0}{L},\quad
 |\partial_LG|\le\frac{(2+2/e)B_0}{L}<\frac{3B_0}{L},
 \qquad\text{ALL }\eta>0. \tag{S4b}
\]

仅声明 Lipschitz 时无需 g 可微；可先用分布导数/积分绝对连续证明再取连续代表。这个版本比 M 版本强的原因是真实 L∞ 界，而不是窄核自动平滑掉所有复杂度。

若真实周期源确实为各坐标正密度的乘积，则周期平滑场为 ∏_iG_i。对共同 b0,B0 与参数区间 L≥L0，其 log 的相位和尺度误差分别最多

\[
 \frac{2B_0}{b_0L_0}\sum_i|\Delta x_i|,
 \qquad \frac{3nB_0}{b_0L_0}|\Delta L|. \tag{S4c}
\]

每个相位偏差≤d 时第一项为 2nB0d/(b0L0)。绝对误差也可用逐因子非负区间相乘，或 ∑ε_i∏_{j≠i}U_j；不可把单因子误差直接当 n 维误差。原 λ 所需的严格/非严格门必须依据完整区间端点判定，没有 margin 时留 UNKNOWN。任意正 L1 输入没有这个乘积分解。

## S5. 正有限空间截断：上界与下界方向

若周期非负场 g∞ 在真实空间上有定义，实际有限源为 f=g∞1_J、且不重新改变幅度归一化，则 f≤g∞，正卷积给 P_{η,L}f≤P_{η,L}g∞。因此周期场可以给实际有限截断的上界；这不是一个自动的下界，也不能在源重新归一化后无系数沿用。

若实际截断为矩形 J=∏I_i，源和周期场真为坐标乘积 0≤g_i≤B_i，接收点离 I_i 两边至少 d_i，且 d_i/L−1/2>0，则一维缺失量 ε_i 满足

\[
 \varepsilon_i\le B_i\exp[-(d_i/L-1/2)/\eta]. \tag{S5a}
\]

证明：h 的位移≤1/2；w_η 的两侧尾为 ∫_0^1 2r exp[−D/(ηr)]dr≤exp(−D/η)。故遗漏源必须穿过 D=d_i/L−1/2 的 w_η 尾。对 L≤L1、η≤η1 可使用 D_i=d_i/L1−1/2>0 的统一指数。逐因子相减给

\[
 0\le P_{\eta,L}g_\infty-P_{\eta,L}f
 \le\Big(\prod_iB_i\Big)\sum_i e^{-D_i/\eta_1}. \tag{S5b}
\]

下界若使用 log，还须因子下端严格正，例如 b_i−ε_i>0。上述 n 个遗漏事件的费用没有被无偿取消。非矩形/非乘积源需重证其空间尾，不从本式外推。

**原 coarse 参数。** 若 ℓ=log(n+2) 用严格区间 [ℓ−,ℓ+] 包住，0<ℓ−≤ℓ+，则

\[
 \theta\in[(\ell_+)^{-2},(\ell_-)^{-2}],\quad
 \alpha\in[(10\ell_+)^{-1},(10\ell_-)^{-1}]. \tag{S5c}
\]

q 随 |a| 单调，但 sinc/源系数可带符号，整个周期场不随 η 单调；有限 Fourier 项要作带符号区间计算，尾用统一 η0。P1 的上门是 ALL L∈[1,2]，coarse 的门是 ORIGINAL L*，两者不能混成有限节点门或换用另一核。

## S6. Gamma-mixture 的有限 n 窗口常数

本节复核 alternative 需要的常数，不复制其新概率倾斜/尾桥。保留 Ψ_{n,t}(x)=exp(−∥x∥∞/t)/(2^n n!t^n)。直接对层蛋糕积分，若 G~Gamma(n+1,rate1)，

\[
 \Psi_{n,t}=\mathbb E\,U_{\mathrm{fullside}\,2tG}. \tag{S6a}
\]

确实混合密度是 ∫_{s≥∥x∥∞/t}(2ts)^{-n}s^ne^{-s}/n! ds，即原 Ψ。保留 c_n=n!e^n/n^n≤6√n；令 t=L/(2n)，则 G 的窗口 [n,n+√n/2] 对应 full-side [L,L(1+1/(2√n))]。对 G=n(1+δ)、0≤δ≤1/(2√n)，

\[
 \frac{G^ne^{-G}}{n!}
 =\frac1{c_n}\exp\{n[\log(1+\delta)-\delta]\}
 \ge\frac{e^{-1/8}}{6\sqrt n},
\]

因为 log(1+δ)−δ≥−δ²/2。积分长度 √n/2 得到

\[
 \mathbb P\{n\le G\le n+\sqrt n/2\}
 \ge e^{-1/8}/12>1/24. \tag{S6b}
\]

这对所有整数 n≥1 成立，无 CLT 误差、无格点假设。另有一般对称版本：0<a≤1/2 时，Pr(|G−n|≤a√n)≥ae^{-a²}/3；用 |δ|≤a/√n 时 log(1+δ)−δ≥−δ² 得出。若实际硬平均在 ENTIRE full-side 窗口 L(1±a/√n) 上≥bλ，则 Ψ_{n,L/(2n)}*f≥bλae^{-a²}/3。有限 winner 节点、单点尾或 per-row posterior 的均匀秩都不提供这个窗口前提。

**实际 primary 支持。** 直接浏览 Robbins 的原始扫描论文 pp.26–29：公式(1)–(2) 的整数阶乘余项 1/(12n+1)<r_n<1/(12n)，公式(5)–(7) 的展开/上下比较，以及 pp.28–29 编辑给出的单调证明。该证明令 U_n=n!e^n/n^{n+1/2}、W_n=U_n exp[−1/(12n+1)] 递减，且 W_1=e^{12/13}；因此本轮另可直接推出 U_n≤e、c_n≤e√n<3√n，足以支持保留的 6√n 常数。本文仍使用已核的宽松 6，不把常数改善称为维数收益。原文将极限常数识别为 √(2π) 归于通常方法，本轮未重读该外引 Wallis 类证明，所用单调上界不依赖这一识别。[Robbins, *A Remark on Stirling's Formula*, American Mathematical Monthly 62(1), 26–29 (1955), 原始扫描](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf)。

本轮针对精确 Ψ dilate endpoint 的 primary 检索未找到已验证、可给 subpower weak1 的定理；未用未读摘要或改变底测度的类似题名代替它。R89 共同 Cesàro 定理不自动控制这族 Ψ 的个别 dilation 最大值。Alternative 的真实 product-tilt 窗口桥由其作者独立证明；任何实际下界应用均保留私人范围。Adaptive 的 elementary slab 投影由其作者负责，其源集中、坐标数和跨 epoch 费用不能由 A03 的名称支付。

## S7. 三阶段检验与剩余项

Pilot：S2–S6 的精确命题先送双审；核质量 1、full-side/2π、两侧尾以及真正共同的 η/L 范围。Known-obstruction：保 sinc 负号；有限空间截断仅自动给上界；没有 L∞ 真源界时不能使用 S4b；单因子误差不能忽略 n；I4 浮点消去不能当区间证书；有限节点不等于原 all-window 或首触门。Expanded：任意 K、相位和连续参数域由完整证明与统一级数控制承担；数值作者另行实跑真实窗口/单元，不属于本源角色的运行收据。

本轮新执行 56 个 NONPHYSICAL 浮点诊断（0.005164 秒）：q 的 Laplace-mixture 积分 6 组；c=0.01,0.1,1,10 与 K=1,3,17,64 的 I3/I4 稳定变量替换积分 32 组；n=1,2,4,16,256,4096 各三个 Gamma 中心窗口密度值 18 组。均通过预设浮点容差，属于诊断而非有向区间证明。另在 c=10^{20},K=1 压力下，I4 原式直接浮点计算为约 6.67×10^{39}，稳定积分约 30.9234，相差 2.16×10^{38} 倍；这是已测出的消去失败，精确公式仍正确，程序不能使用该直接结果认证尾界。积分诊断采用独立变量 y=K/x，使 Ij=K^{1−j}∫_0^1 y^{j−2}log(1+(cK/y)²)dy，零点连续值为 0。一般量词由证明承担，没有未运行物理实验的声明。

本轮这些公式可把原门数值计算做成可审查的连续包络，但没有断言实际候选通过 P1、coarse 或完整 Fnew。没有一般 I_T、signed flux、归一化浓缩或阈值付费上界从中推出。公共 scalar 检查与最终双审回执由本轮 source 收据另列，不复用 R89 的 96/72 检查为本轮新证据。

This auxiliary calculation does not prove the general upper bound. It separates a valid weighted maximal estimate from the stronger weak estimate one might mistakenly infer from its prefactor. It uses a singular source only to examine a possible concentration-payment mechanism; it asserts no original gate, source-selection or limiting transfer.

Fix $\lambda>0$. Let integers $m,k\ge1$, $n=m+k$, and $g\ge0$ belong to $L^1(\mathbb R^m)$, with $W=\int g$. Put $\mu=\delta_0^{\otimes k}\otimes g(x')\,dx'$. All cubes have full side $L\in[1,2]$. Define
\[
 A_L^m g(x')=L^{-m}\int_{Q_m(x',L)}g(y')\,dy',\qquad
 T_\lambda(x')=\sup\{L\in[1,2]:A_L^m g(x')>\lambda L^k\},
\]
with $T_\lambda=0$ if the set is empty. For $a\in[1,2]$ let
\[
 G_a(x')=\sup_{a\le L\le2}L^{-k}A_L^m g(x').
\]

**Exact normal-fiber identity.** For the local centered cube maximal operator applied to this finite measure,
\[
 D_\lambda:=\lambda|\{M_{[1,2]}\mu>\lambda\}|
 =\lambda\int_{\mathbb R^m}T_\lambda(x')^k\,dx'.                 \tag{F1}
\]
Indeed its side-$L$ average at $(z,x')$ is
$1_{\{2\|z\|_\infty\le L\}}L^{-k}A_L^m g(x')$.
For a fixed $x'$, the union of the qualifying normal cubes is a nested union with volume exactly $T_\lambda(x')^k$. Whether some boundary is included does not change its volume. Tonelli gives (F1). The map $(x',L)\mapsto A_L^m g(x')$ is continuous for $L\in[1,2]$: spatial translations are controlled by $L^1$ translation continuity of $g$, and side changes by absolute continuity of its integral over shells whose volumes tend uniformly to zero. Consequently all the suprema and strict exceedance sets in this note are measurable; a countable dense set of sides, including endpoints where necessary, gives the same strict event and supremum.

**A valid weighted maximal estimate.** One has
\[
 \int G_a\,dx'\le
 a^{-k}\left[1+\frac m k\left(1-(a/2)^k\right)\right]W.       \tag{F2}
\]
For $r=2\|v\|_\infty$, the pointwise supremum of the positive kernels is
\[
 h_a(v)=\max(a,r)^{-(m+k)}1_{\{r\le2\}}.
\]
Thus $G_a\le h_a*g$. The normalizing identity $|\{2\|v\|_\infty\le r\}|=r^m$ yields
\[
 \int h_a=a^{-k}+m\int_a^2r^{-k-1}\,dr
 =a^{-k}+\frac m k(a^{-k}-2^{-k}).
\]
Integration of the convolution proves (F2). This is a complete kernel-envelope argument, uniform over $g$.

**Why the prefactor in (F2) is not the desired fiber fee.** Since $T_\lambda$ lies in $\{0\}\cup[1,2]$, layer cake and Markov give
\[
 D_\lambda
 =\lambda|\{T_\lambda\ge1\}|+
 \int_1^2 k r^{k-1}\lambda|\{T_\lambda>r\}|\,dr
 \le\int G_1+\int_1^2 k r^{k-1}\int G_r\,dx'\,dr.          \tag{F3}
\]
The first Markov use is valid because $T_\lambda\ge1$ means that some side qualifies, hence $G_1>\lambda$. If $T_\lambda>r$, some qualifying side exceeds $r$, so $G_r>\lambda$ as well. Substituting (F2), the total coefficient is
\[
 \begin{split}
 &1+\frac m k(1-2^{-k})+
 \int_1^2\frac{k}{r}\left[1+\frac m k(1-(r/2)^k)\right]dr\\
 &=1+\frac m k(1-2^{-k})+(m+k)\log2
       -\frac m k(1-2^{-k})
 =1+(m+k)\log2.                                        \tag{F4}
 \end{split}
\]
The gain $m/k$ in the weighted single-envelope coefficient is lost in this full receiver-volume calculation. It cannot be quoted as the coefficient of (F1).

There is a better established bound in this singular model. For nonempty qualifying sets, choose qualifying sides tending to their supremum. This gives
$\lambda T_\lambda^k\le\sup_{1\le L\le2}A_L^m g$ pointwise. The same kernel calculation with exponent $m$ gives
\[
 D_\lambda\le (1+m\log2)W.                              \tag{F5}
\]
In particular this note does not refute a possible sharper estimate, such as a bound with coefficient $1+m/k$ for the true weak demand. It proves that (F2) plus fiberwise Markov does not establish such an estimate. Any stronger gain needs another fact about the common spatial source across sides. Nor does (F5) by itself transfer a coordinate-atom count of a weak limit into a payment for the original arbitrary $L^1$ sources; common packet mass, transverse coordinates, source approximation and all residual branches would still have to be controlled.

Verification is recorded in the parent integration ledger after both independent statement and full-proof reviews. These identities are exact analytic computations, not a numerical estimate of the high-dimensional weak norm.

本轮在同一冻结实际输入的六个正 Lebesgue 体积接收小格上，认证了**原始连续最早接触**的区间。新增证据是覆盖全部更早尺度的严格前缀证书，含 844 个无间隙区间；上一轮的有限节点正样本只是选定小格的依赖，没有重复计作本轮进展。没有得到完整新残余集的体积、实际 Hall 容量或高负载径向预算。

令 \(H(x,L)=\log A_L(x)\)。在一个接收小格和尺度段 \([a,b]\) 上，若端点上界为 \(H_a^+,H_b^+\)，且几乎处处导数满足 \(D^-\le\partial_L H\le D^+\)，绝对连续性给出整段上界
\[
 H(x,L)\le U:=\min\{H_a^++\max(0,D^+)(b-a),
                  H_b^++\max(0,-D^-)(b-a)\}.
\]
源密度的跳跃不要求全局连续可微；导数区间覆盖所有跳跃分支，使用几乎处处导数及绝对连续性的基本定理。正因子分母的统一下界也是证书前提。

程序按从左到右的顺序划分尺度。如果无间隙覆盖 \([1,\ell]\) 的每一段均满足 \(U<\log\lambda\)，则更早的 crossing 和 tangent 都被排除。再有全小格统一的严格见证 \(A_h>\lambda\)，连续性保证每个潜在接收点的原始最早接触都在 \((\ell,h)\)。根可以随接收点变化，不需预先假设唯一性。无法排除的早期区间保留为 UNKNOWN，不能用后面的严格穿越替换可能更早的切触。

这六个小格的根附近还均有统一正的几乎处处导数。因此在各自剩余区间内，接触唯一；结合接收点和尺度的联合连续性，原始接触选择器在该小格上连续。这是局部结论，不是全事件的跨行几何估计。

公开标准库程序只提供三阶段**非物理**标量接口检查：单调初检、较早切触压力、多次穿越的网格混叠。它以有理 Bernstein 系数认证 22 个前缀段，结果分别为 CERTIFIED、UNKNOWN、CERTIFIED。切触例明确保留较宽的未知区间，即便较晚已有严格正节点。程序不含实际来源配方，也不认证实际软门。

软门角色在同一输入和相同接收小格上另行检查整窗原平滑门及新粗门。已检查的前三个相同小格的原整窗上门都通过，但新粗门均被认证为 HIGH，属于已收费分支；相应证明见软门报告，其余三个小格及整个残余集没有由此判定。本接收程序没有把原根通过写成完整残余门控通过。即使某些小格以后全部门控成立，有限节点事件的补集仍未覆盖。

公开重放：`python3 hall_probe.py`，输出 `hall_results.json`。这些准确接口及局部实际根证书不证明一般平方根弱型界。

Rigorous continuous-scale smoothing tests were applied to previously saved positive-volume receiver cells of one frozen positive input, with its common threshold unchanged. The original whole-window smooth upper gate was certified; the original coarse gate failed on the tested candidates. This is a gate-exclusion result, not a weak-type counterexample, an estimate of the full residual receiver set, or a source-capacity bound. The full residual set and the desired general root-order estimate remain unresolved.

R90 independent mathematical audit: complete coverage, adaptive, alternative and sources Markdown and matching TeX proofs, plus parent_fiber in both formats, have been read. The following dispositions concern their stated hypotheses; none proves the arbitrary-positive-L1 root-order theorem.

- Coverage PASS. Uniform auxiliary cube coordinates give the exact binomial edge-slab cost a_n(delta), at most one half of sqrt(n(1-delta)/delta). The remainder is an exact common-source, displaced-row pairing. Its Hellinger and translation-modulus estimates retain their full factors. A source-modulus certificate can remain linear even with input-dependent thickness; this does not lower-bound the actual signed remainder or Hall capacity. The joint cancellation payment is open.
- Adaptive PASS. A source confined in k chosen coordinate intervals has local weak fee H_(n-k) times product(1+h_j). Genuine countable or fractional source packets incur their actual mass once within a stage; all measurable subcuts of the dominant-share branch satisfy the displayed Hall bound. The finite-cover result pays uncovered source mass. Coordinate atomic totals alone do not provide this cover or its captured shares. The complete finite recursion retains the earlier branch fees, the physical collision/entropy union fee once, threshold-weighted repeated packet expenses and the terminal. No cross-stage occupation bound is inferred from disjoint packets.
- Alternative PASS. The generic bounded periodic product transfer uses an actual normalized product tilt, an actual union probability, a common weak threshold and a Gamma(shape n+1) window at the stated full-side clock. Both Markov and Hoeffding bad-window estimates justify their minimum without extra deletion cost. Finite truncation retains its interior-volume loss. The displayed maximal-error comparison needs a uniform weak-type error budget; single-scale kernel approximation does not supply it. Actual private applications are excluded from this summary.
- Sources PASS. Original smoothing normalization, signed sinc multiplier, absolute Fourier tails, continuous phase/scale envelopes, positive finite-truncation directions, original coarse parameter intervals and finite-dimensional Gamma-window constants agree in both formats. Dimension and narrow-kernel costs are explicit. These tools do not themselves certify a physical input. Primary reading receipts belong to their named source author; this audit does not claim an additional original-scan reading.
- Parent fiber PASS after explicitly stating lambda>0. The singular exact-plane fiber identity is valid, but integrating its weighted envelope by Markov loses the tempting m/k gain. The proved full fiber fee remains 1+m log(2); the stronger geometric conjecture is neither proved nor disproved by this computation.

Numeric scope: the new original continuous first-contact algorithm was read and independently replayed without file writes on all six stored positive-volume receiver cells; every exact certificate matched its saved record (71.078034334 seconds). It uses strict gapless prefix exclusion and a later witness, not a finite-node substitute or an assumed unique root. The frozen source is byte-identical to the preceding round. The soft algorithm's original-window Fourier and outward interval-FFT coarse logic, including its read-only local root refinement, have been reviewed. The complete frozen soft mathematical payload was independently replayed without writes in 98.310694417 seconds: pilot, generic FFT pressure and all three local-root-refinement/original-window/coarse records matched exactly after removing only the two runtime fields. On those three tested cells the original whole-window upper gate passes and the original coarse gate is uniformly HIGH, so they belong to the already-paid coarse branch and are excluded from Fnew. The input, common threshold and original selectors were retained. The other saved cells and the whole residual are not classified by this test. Current parent introduction and ledger were read; the wording now distinguishes the new paid slab branch from an unproved general payoff. No whole residual measure, high canonical load, original-cut variance or unrestricted Hall estimate is certified by these cell tests. Generic scalar/program guards and author floating diagnostics are distinct from physical qualification and from this auditor's own executions.

The retained all-scale and any separately used layer costs remain. The general target is open; the new unconditional payment applies to the explicitly specified slab branch or source-cover class.

## R90 independent Sol audit — completed

The arbitrary positive-L1 centered-cube sqrt(n)n^{o(1)} weak bound remains **UNPROVED**; the retained general baseline is O(nlogn). Sol read the complete new contract and checked exact statements before reading author proofs. The complete coverage, adaptive, alternative, sources and parent normal-fiber Markdown/TeX proofs, parent introduction/fee ledger, and actual receiver/soft code and reports pass within their stated scopes. Original common source, actual lambda dx demand, full-side lengths, original gates, all-principal conditions, prior branch fees, all-scale localization, possible kappa-layer fee and terminal expense remain. No full conditional canonical-variance hypothesis or arbitrary-input residual payment was proved.

Finite-thickness flux has a root-order scalar expense with an exact unpaid mixed source/row remainder. Its adaptive source-modulus certificate has a restricted linear obstruction, not an actual gated principal-cut counterexample. Tagged partial slabs have a complete branch payment and a finite-cover leakage fee; general inputs have no such cover proved here. The singular normal-fiber computation correctly distinguishes a weighted envelope prefactor from receiver-volume demand and leaves a stronger weak fee open. The generic bounded-periodic Gamma transfer and its sharpened true-product-law loss are proved, including finite truncation and the necessary ALL-scale error expense; no general upper error bound was obtained. Gamma mixing uses shape n+1, J=2tG and t=L/(2n). Original Fourier multiplier, positive tails, continuous phase/scale costs and finite-support lower errors were verified; naive floating cancellation is never treated as an interval certificate.

The new independent standard-library guard passed **1525 assertions** standalone: coverage431, alternative243, adaptive132, own continuum-prefix pressure164, normal-fiber264, source scalar141 and saved public scalar certificates150. Its three stages have404/442/529 assertions. Saved public certificates are checked by independent exact quadratic extrema and polynomial factorization, and both public file hashes are bound. These are NONPHYSICAL finite-law/scalar checks. A temporary five-member mock public archive and byte-exact sole-fence extraction passed **1528 assertions**, exit0 and empty stderr (.136819s internal/.161683s wall). This mock receipt does not claim execution of the parent's eventual final archive. No old-round or author-run count is attributed to Sol.

Six already selected positive-volume receiver cells have certified continuous original earliest-contact brackets with844 gapless strictly-below prefix segments. Sol fully read the interval implementation and independently checked4292 saved-data consistency assertions; the parent's complete physical replay and Astra's recomputation are separate receipts. Sol additionally executed the complete three-stage soft certificate program in98.286457s, with exact saved JSON agreement after recursively removing only its two runtime fields. Three selected cells pass the original whole-window upper gate but FAIL the original coarse gate uniformly over each cell and every possible original first selector; the initial UNKNOWN pilot is retained. This is a paid gate-exclusion result. It gives no full residual measure, unknown-mass bound, confidence statement, canonical I_T, actual Hall capacity or general weak estimate. Private formulas, input parameters and catalog application conclusions are excluded from this public audit.

Frozen independent guard SHA256:6480334202ab1aa97eb7ecb8b38ef3bc6371417bbf4a98bafc0ce6bd55c2846a.

## 主代理整合、独立复现与隐私边界

各路线和父纤维记账命题先经两名审核者独立检查，再逐份阅读全文及匹配 LaTeX。主代理保留所有假设、各分支补集和原始费用，不以作者结论代替审计。检查中补明父命题的 λ>0，并分开原中间门与依赖固定 p 的后验包分支；未发生隐藏的数值放宽。

主代理实际执行了以下隔离重放，均 exit0、stderr为空：

- 公开三种连续前缀标量模型：0.019150 秒，JSON 完全一致；22 个有理前缀段，较早切触保留 UNKNOWN。其为非物理接口。
- 私人原连续首次接触：71.884759 秒，JSON 完全一致；六个原接收单元、844 个无间隙严格前缀段、1750 个尺度点计算。没有新采样或新置信区间。
- 私人原平滑门三阶段：97.205379 秒，仅删除两种运行时间字段后全部 JSON 精确一致；原有有界初检、精确 Fourier 方向压力、扩大模式数与原根精度均保留。三个单元的原全窗口上门通过，粗平滑低门确定失败，属于已支付分支。尚未检查的单元及整个 Fnew 没有因此判定。
- 私人奇异平面原型诊断：1.897090 秒，31800 个有限浮点案例的18组已记录最大值逐一复现。组合包络结构精确，半径和体积为浮点；没有把未发现反例提升为一般阶数证明。

Astra 另独立非写入重算六个首触证书（71.078034秒）和完整软门三阶段数学输出（98.310694秒）；Sol 另以98.286457秒独立重放完整软门三阶段，并用4292项检查核对保存的六份首触数据；后者为保存证书的一致性核验，不声称重新计算六份物理包络。其全文检查及独立程序范围在公开审计节记录。各组运行属于各自验证范围，不把旧轮检查或作者检查再加作本轮独立证据。公开 guard 从有限有理模型独立构造，并独立核查公开标量证书；其总数及组装后重放列在归档清单和本轮 README。

公开包仅保留公共证明、详细 LaTeX 文本、一个可复现的中性标量程序及结果、字节清单。独立 guard 位于 proof.md 唯一 Python 代码块，提取后运行 python3 audit_guard.py；另运行 python3 hall_probe.py 可逐字段重现公共结果。公开代码只用标准库，私人物理证书保留原本地代码、数据和 NumPy 环境，未复制到 GitHub。未发表目录应用、私人配方及新下界推论均不公开。

LaTeX 仅做环境、花括号、标签/引用和控制字符的静态检查，不编译 PDF。所有64技能入口记录 SHA 快照；具体阅读范围由各作者注明，快照不等于全库定理认证。

剩余问题明确：共同来源混合余项的根阶支付；从实际高负担条件推出可支付的集中来源分解；跨阶段阈值费用及终项；全 Fnew 的规范高列方差或每个真实主割容量；最后原尺度与分层回代。一般正 L1 的 n^(1/2+o(1)) 上界没有完成。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""R90 independent new exact certificates; NONPHYSICAL finite laws only.
Standard library, no producer imports or private recipe. This does not certify
an original continuum gate, principal capacity or general cube upper bound.
"""
from fractions import Fraction as F
from math import comb, factorial, isqrt
from pathlib import Path
from itertools import product
import hashlib
import json
import re
import time

COUNT = 0
DETAIL = {}
STAGES = {}


def ck(condition):
    global COUNT
    assert condition
    COUNT += 1


def expectation(P, values):
    return sum((p * v for p, v in zip(P, values)), F(0))


def log_interval(x):
    ck(x > 0)
    k = 0
    while x > F(3, 2):
        x /= 2
        k += 1
    while x < F(3, 4):
        x *= 2
        k -= 1
    def series(v):
        z = (v - 1) / (v + 1)
        partial = 2 * sum((z ** (2 * j + 1) / (2 * j + 1) for j in range(72)), F(0))
        tail = 2 * abs(z) ** 145 / (145 * (1 - z * z))
        return partial - tail, partial + tail
    lo, hi = series(x)
    alo, ahi = series(F(2))
    return (lo + k * (alo if k >= 0 else ahi),
            hi + k * (ahi if k >= 0 else alo))


def score(n, delta):
    P = [F(comb(n, k)) * delta ** k * (1 - delta) ** (n - k) for k in range(n + 1)]
    r = [F(k, n) / delta for k in range(n + 1)]
    a = expectation(P, [max(k - n * delta, 0) for k in range(n + 1)]) / delta
    ck(sum(P) == 1 and expectation(P, r) == 1)
    ck(expectation(P, [(v - 1) ** 2 for v in r]) == (1 - delta) / (n * delta))
    ck(n * expectation(P, [abs(v - 1) for v in r]) / 2 == a)
    ck(n * expectation(P, [(v - 1) * (v > 1) for v in r]) == a)
    ck(a * a <= n * (1 - delta) / (4 * delta))
    if n * delta <= 1:
        ck(a == n * (1 - delta) ** n)
    if n * delta <= F(1, 2):
        ck(a >= n * (1 - n * delta) >= F(n, 2))
    if delta == 1:
        ck(a == 0)


def joint_shift(size):
    # Exact four-shift identity on a cyclic finite model, not a physical source.
    roots = [F(1 + (j * j + 3 * j) % 7) for j in range(size)]
    g = [v * v for v in roots]
    chi = [int((j * j + j + 1) % 5 < 2) for j in range(size)]
    M = sum(g) / size
    for c in (1, 3, 5):
        for h in (0, 1, 2):
            lhs = sum((g[j] * (chi[(j+c+h) % size] + chi[(j-c-h) % size]
                   - chi[(j+c-h) % size] - chi[(j-c+h) % size]) for j in range(size)), F(0)) / (2 * size)
            row = [chi[(j+c) % size] - chi[(j-c) % size] for j in range(size)]
            diff = [g[(j-h) % size] - g[(j+h) % size] for j in range(size)]
            rhs = sum((v * w for v, w in zip(diff, row)), F(0)) / (2 * size)
            H = sum((roots[(j-h) % size] - roots[(j+h) % size]) ** 2 for j in range(size)) / size
            J = sum((roots[(j-h) % size] + roots[(j+h) % size]) ** 2 * row[j] ** 2 for j in range(size)) / size
            ck(lhs == rhs)
            ck(rhs * rhs <= H * J / 4)
            ck(H <= 2 * M and J <= 4 * M)
            ck(abs(rhs) <= sum(map(abs, diff)) / (2 * size))


def tilted_stability(size, error):
    # Two normalized one-coordinate densities on the same finite reference law.
    P = [F(1, size)] * size
    a = [1 + error * (2 * j - size + 1) / size for j in range(size)]
    b = list(reversed(a))
    Q = [p * v for p, v in zip(P, a)]
    ck(expectation(P, a) == expectation(P, b) == sum(Q) == 1)
    m = min(a + b)
    pairs = [log_interval(y / x) for x, y in zip(a, b)]
    mean_lo = expectation(Q, [v[0] for v in pairs])
    mean_hi = expectation(Q, [v[1] for v in pairs])
    kl_bound = expectation(P, [(x-y) ** 2 / y for x, y in zip(a, b)])
    ck(-mean_lo <= kl_bound)
    # Jensen sign checked with interval uncertainty rather than a false exact sign.
    ck(mean_lo <= 0 and mean_hi <= F(1, 2 ** 180))
    second_hi = expectation(Q, [max(abs(lo), abs(hi)) ** 2 for lo, hi in pairs])
    drift = max(abs(x-y) for x, y in zip(a, b))
    ck(second_hi <= drift * drift / (m * m))


def overlapping_union(size):
    P = [F(j + 1, size * (size + 1) // 2) for j in range(size)]
    events = [{j for j in range(size) if (j + k) % 3 != 0} for k in range(3)]
    union = set().union(*events)
    for j in range(size):
        bad = [{j}.intersection(event) for event in events]
        kept = set().union(*(event - cut for event, cut in zip(events, bad)))
        full = sum((P[i] for i in union), F(0))
        loss = sum((sum((P[i] for i in cut), F(0)) for cut in bad), F(0))
        ck(sum((P[i] for i in kept), F(0)) >= full - loss)
    for sa, sd in ((F(0), F(3)), (F(1), F(1)), (F(2), F(7))):
        A, D = sa * sa, sd * sd
        optimum = (sa + sd) ** 2
        for theta in (F(1, 8), F(1, 2), F(7, 8)):
            ck(A / theta + D / (1 - theta) >= optimum)
        if sa and sd:
            theta = sa / (sa + sd)
            ck(A / theta + D / (1 - theta) == optimum)


def gamma_window(n):
    # Square dimensions make the new clock/window/finite-box tests exact.
    root = isqrt(n)
    ck(root * root == n and n >= 4)
    for L in (F(1), F(3, 2), F(2)):
        t = L / (2 * n)
        for G in (F(n), n + F(root, 4), n + F(root, 2)):
            J = 2 * t * G
            ck(abs(J-L) <= F(1, root) and F(1, 2) <= J <= F(5, 2))
    ck((1 - F(2, n*n)) ** n >= 1 - F(2, n) >= F(1, 2))
    # e^(-1/8)>=1-1/8 makes the true Gamma mass factor larger than1/24.
    ck(F(7, 8) / 12 > F(1, 24))
    D0, m, z = F(2), F(1, 2), F(3)
    ranges_squared = n * (2 * D0 / (m * root)) ** 2
    ck(ranges_squared == 4 * D0 * D0 / (m * m))
    alpha = m * m * z / (D0 * D0)
    exponent = -alpha*z + alpha*alpha*ranges_squared/8
    ck(exponent == -m*m*z*z/(2*D0*D0))


def tilted_interval_variance(size):
    P = [F(1, size)] * size
    V = [F(j, size-1) for j in range(size)]
    for skew in (1, 7, 1000):
        weights = [p * skew ** j for j, p in enumerate(P)]
        Q = [v / sum(weights) for v in weights]
        mean = expectation(Q, V)
        ck(expectation(Q, [v*v for v in V]) - mean*mean <= F(1, 4))


def slab_share(size):
    # Layer-cake finite shares and an explicit bad/good partition, not cube gates.
    shares = [F(j+1, size*(size+1)//2) for j in range(size)]
    ck(sum(shares) == 1)
    for tau in (F(1, 8), F(1, 2), F(7, 8)):
        threshold = (1-tau)/(2*size)
        good = [(1-tau/F(2))*v for v in shares]
        eta = sum(v for v in good if v >= threshold)
        ck(sum(good) > 1-tau and eta >= (1-tau)/2)
        for p in good:
            cuts = sorted({F(0), threshold, p, F(1)})
            integral = sum((hi-lo for lo,hi in zip(cuts,cuts[1:]) if lo>=threshold and hi<=p), F(0))
            ck(p * (p>=threshold) == threshold * (p>=threshold) + integral)
    for r, k in ((0, 2), (1, 3), (2, 5)):
        h = F(1, size)
        # Independent equal-mass bins: explicitly enumerate a pinned box and
        # a union of distinct diagonal boxes; atoms contribute no extra cost.
        points = list(product(range(size), repeat=k-r))
        pinned = sum(all(v == 0 for v in point) for point in points)
        union = sum(len(set(point)) == 1 for point in points)
        ck(F(pinned, len(points)) == h ** (k-r))
        ck(F(union, len(points)) == size * h ** (k-r))
        ck(F(union, len(points)) <= min(F(1), size*h**(k-r)))


def fiber_account(size):
    # A finite receiver-volume law checks the T>=1 atom and strict layer cake.
    T = [F(0), F(1), F(3,2), F(2)]
    weights = [F(1), F(size), F(2), F(3)]
    log2 = log_interval(F(2))
    for k in (1, 2, 7):
        direct = expectation(weights, [t**k for t in T])
        base = sum(w for w,t in zip(weights,T) if t>=1)
        integral = F(0)
        cuts = [F(1),F(3,2),F(2)]
        for a,b in zip(cuts,cuts[1:]):
            integral += (b**k-a**k)*sum(w for w,t in zip(weights,T) if t>b or t==b)
        ck(direct == base+integral)
        ck(direct != integral)  # dropping the first receiver block is false
        for m in (1, 3, size):
            for a in (F(1),F(3,2),F(2)):
                # Exact radial envelope mass, including the inner a-ball.
                envelope = a**(-k)+F(m,k)*(a**(-k)-F(2)**(-k))
                ck(envelope == a**(-k)*(1+F(m,k)*(1-(a/2)**k)))
                ck(envelope > 0 and (a!=2 or envelope==F(2)**(-k)))
            boundary = F(m,k)*(1-F(2)**(-k))
            # F4: the boundary correction cancels, leaving (m+k)log2.
            for ell in log2:
                ck(1+boundary+(m+k)*ell-boundary == 1+(m+k)*ell)
            ck(1+m*log2[1] < 1+(m+k)*log2[0])


def source_scalar(size):
    # New positive q and tail inequalities, enclosed entirely in Fractions.
    for a in (F(1,size),F(1),F(size)):
        x=a*a
        lo,hi=log_interval(1+x)
        qlo,qhi=lo/x,hi/x
        ck(1/(1+x) <= qlo <= qhi <= 1)
        derivative=(2/(1+x)-2*qhi,2/(1+x)-2*qlo)
        ck(-2*qhi <= derivative[0] <= derivative[1] <= 0)
        for ratio in (F(1),F(3,2),F(4)):
            upper=log_interval(1+x)[1]+2*log_interval(ratio)[1]
            actual=log_interval(1+x*ratio*ratio)[0]
            ck(actual <= upper)
    # Direct-kernel product interpolation must retain every coordinate fee.
    n=size*size
    b,B,L=F(1,2),F(3,2),F(1)
    coordinate=2*B/(b*L)
    scale=3*B/(b*L)
    ck(sum([coordinate]*n)==2*n*B/(b*L))
    ck(sum([scale]*n)==3*n*B/(b*L))


def public_saved_prefix(root):
    # Independently verify the producer's saved polynomial certificates using
    # exact quadratic extrema, rather than its Bernstein-basis algorithm.
    names={'hall_probe.py':'028a586b6d4793157fec8ce285957b35fc5b7812544b787ee3dbe3a821630698',
           'hall_results.json':'b69479995a820db2600acae262f90755c9d615c06c35d7104f6e44240e12ea73'}
    for name,digest in names.items():
        ck(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest)
    data=json.loads((root/'hall_results.json').read_text())
    ck(data['schema']=='R90-public-continuous-prefix-v1' and len(data['cases'])==3)
    total_segments=0
    def value(coeff,x):
        return sum((v*x**j for j,v in enumerate(coeff)),F(0))
    for case,expected in zip(data['cases'],('CERTIFIED','UNKNOWN','CERTIFIED')):
        p=list(map(F,case['p_coefficients']))
        H=list(map(F,case['H_coefficients']))
        ck(H[0]==p[0]+1 and H[1:]==p[1:])
        roots=list(map(F,case['roots_with_multiplicity']))
        factor=[F(case['factor'])]
        for r in roots:
            new=[F(0)]*(len(factor)+1)
            for j,v in enumerate(factor):
                new[j]-=r*v;new[j+1]+=v
            factor=new
        ck(factor==p)
        first=min(roots);cert=case['certificate']
        ck(first==F(case['actual_earliest_contact_exact']))
        ck(cert['state']==expected and F(cert['lo'])<first<F(cert['hi']))
        derivative=[j*v for j,v in enumerate(p) if j]
        next_a=F(1)
        segments=cert['prefix']+[cert['first_possible_segment']]
        for index,s in enumerate(segments):
            a,b=F(s['a']),F(s['b'])
            ck(a==next_a and a<b);next_a=b
            lo,hi=map(F,s['derivative'])
            test=[a,b]
            if len(derivative)==3 and derivative[2]:
                vertex=-derivative[1]/(2*derivative[2])
                if a<=vertex<=b:test.append(vertex)
            vals=[value(derivative,x) for x in test]
            ck(lo<=min(vals)<=max(vals)<=hi)
            pa,pb=value(p,a),value(p,b)
            ck([pa,pb]==list(map(F,s['endpoint_p'])))
            upper=min(pa+max(0,hi)*(b-a),pb+max(0,-lo)*(b-a))
            ck(upper==F(s['upper']))
            if index<len(cert['prefix']):
                ck(upper<0);total_segments+=1
            else:
                ck(a==F(cert['lo']) and upper>=0)
                if expected=='CERTIFIED':ck(b==F(cert['hi']) and pb>0)
                else:ck(pb==0 and b==first and case['earliest_multiplicity']==2)
        mesh=case['mesh_records']
        ck(all(value(p,F(x))==F(y) for x,y in mesh))
        positive=min(F(x) for x,y in mesh if F(y)>0)
        ck(positive==F(case['first_positive_mesh_node']) and positive>first)
    ck(total_segments==22)


def derivative_prefix(size):
    # A tangent contact hidden between nodes: endpoint scans cannot exclude it.
    c, r = F(5, 4), F(7, 4)
    def H(x): return (x-c)**2*(x-r)
    def dH(x): return 3*x*x-(2*r+4*c)*x+c*c+2*c*r
    def derivative_interval(a,b):
        points = [a,b]
        stationary = (r+2*c)/3
        if a<=stationary<=b: points.append(stationary)
        values = [dH(x) for x in points]
        return min(values),max(values)
    def upper(a,b):
        lo,hi=derivative_interval(a,b)
        return min(H(a)+max(F(0),hi)*(b-a),H(b)+max(F(0),-lo)*(b-a))
    a,b=c-F(1,8),c+F(1,8)
    ck(H(a)<0 and H(b)<0 and H(c)==0)
    ck(upper(a,b)>=0)
    for j in range(size):
        a=1+F(j,size);b=1+F(j+1,size);U=upper(a,b)
        for k in range(5):
            ck(H(a+(b-a)*F(k,4))<=U)
    ck(H(F(2))>0)


def main():
    started=time.perf_counter()
    for name, ns, size in (('pilot',(2,3,4),5),('pressure',(8,16,32),9),('expanded',(64,128,256),17)):
        start=COUNT
        begin=COUNT
        for n in ns:
            for delta in (F(1,8),F(1,2),F(7,8),F(1,4*n),F(1,2*n),F(1)):
                score(n,delta)
        joint_shift(2*size)
        DETAIL.setdefault('coverage',{})[name]=COUNT-begin
        begin=COUNT
        tilted_stability(size,F(1,16))
        tilted_stability(size,F(1,4))
        overlapping_union(size)
        tilted_interval_variance(size)
        for n in {'pilot':(4,9),'pressure':(16,64),'expanded':(256,1024)}[name]:
            gamma_window(n)
        DETAIL.setdefault('alternative',{})[name]=COUNT-begin
        begin=COUNT
        slab_share(size)
        DETAIL.setdefault('adaptive',{})[name]=COUNT-begin
        begin=COUNT
        derivative_prefix(size)
        DETAIL.setdefault('continuum_prefix',{})[name]=COUNT-begin
        begin=COUNT
        fiber_account(size)
        DETAIL.setdefault('parent_fiber',{})[name]=COUNT-begin
        begin=COUNT
        source_scalar(size)
        DETAIL.setdefault('sources',{})[name]=COUNT-begin
        STAGES[name]=COUNT-start
    root=Path(__file__).resolve().parent
    begin=COUNT
    public_saved_prefix(root)
    DETAIL['saved_public_prefix']=COUNT-begin
    if (root/'proof.md').exists():
        proof=(root/'proof.md').read_text()
        fences=re.findall(r'^```python\n(.*?)^```\s*$',proof,re.M|re.S)
        ck(len(fences)==1 and fences[0].encode()==Path(__file__).read_bytes())
        for value in (proof,(root/'proof.tex.txt').read_text()):
            ck(not any(ord(c)<32 and c not in '\n\t' for c in value))
    print(json.dumps({'status':'PASS','assertions':COUNT,'stages':STAGES,'components':DETAIL,
        'scope':'New R90 NONPHYSICAL arithmetic and saved public scalar certificates; no private recipe, actual original gate, capacity or general upper-bound certificate.',
        'elapsed_seconds':time.perf_counter()-started},sort_keys=True))


if __name__=='__main__':
    main()
```
