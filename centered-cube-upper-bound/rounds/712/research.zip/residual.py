"""R712 real-history full-score residual: Arb bounds and remote Decimal check.

Only residual.json is written. Astronomical label counts remain symbolic.
Run with the existing Python3.13 environment and python-flint PYTHONPATH.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx


def st(x):return x.str(38)


def floor_unique(x):
    v=x.floor().unique_fmpz();assert v is not None
    return int(v)


def calculate(b,multiplier,bits):
    ctx.prec=bits;A=arb
    n=1<<b;a=32*n;clock=1<<(b//2);passive=b//4;active=multiplier*b;C=65536
    assert active%2==0 and active+passive<n
    ln2=A(2).log();L=b*ln2;t=A(clock)/ln2;h=1+A(1)/a
    beta=(-n*A(a).log()).exp();g=(-A(2)/a).log1p()
    W=-(n*g).expm1();Wp=W/(1<<passive)
    J=floor_unique((clock-beta)/Wp);e=clock-beta-J*Wp
    assert e>0 and e<Wp
    logR=ln2-(J+1)*g;R=logR.exp()
    logP=n*g-Wp/t
    early=(n*logR).exp()*((-(-Wp/t).expm1())*(-(J*logP).expm1())/(-logP.expm1())+(J*logP).exp()*(-(-e/t).expm1()))
    trigger=(n*ln2-(clock-beta)/t).exp()*(-(-beta/t).expm1())
    logNrec=A(active//2)*ln2;receiving_clock=(logNrec+beta.log()).exp()
    receiving=A('0.5')*(-(-receiving_clock/t).expm1())
    Dnorm=early+trigger+receiving
    logVTnorm=logNrec+beta.log();logVT=n*ln2+logVTnorm
    logD=n*ln2+Dnorm.log();logratio=Dnorm.log()-logVTnorm
    q0=3*b//16+1
    favorable=max(0,floor_unique(A(a)/2*((A('0.5')-A(1)/a)/R-A('0.1'))-1))
    p=A(favorable)/a;B=active//2
    mass=(B*(-p).log1p()).exp();tail=mass
    for j in range(1,q0):
        mass*=A(B+1-j)/j*p/(1-p);tail+=mass
    fail=2*tail/W
    fullmass=-(-J*Wp/t).expm1()
    bad_full_upper=fullmass*(Wp/t).exp()*fail
    partial_upper=Wp/t
    missing_upper=(receiving_clock+beta)/t
    robust_retained=fullmass-bad_full_upper-missing_upper
    bin_ratio=(ln2/n).exp()*h
    assert bin_ratio<A('1.01')
    log_penalty=q0*(C*(A('0.1')/A('1.01'))**2).log1p()
    inverse_penalty=(-log_penalty).exp()
    # For each bin and each subset: score<=all nonrobust mass + robust mass/P.
    # This stays valid when the maximizing subset contains no robust donor.
    score_upper=bad_full_upper+partial_upper+missing_upper+A('0.5')*inverse_penalty
    rho=(-L/6).exp()*L**(A(1)/3)
    residual_lower=robust_retained-score_upper/rho
    if residual_lower<0:residual_lower=A(0)
    assert robust_retained>0 and robust_retained<A('0.5')
    assert log_penalty>L
    assert fail<(-3*L).exp()
    # Robust sources are original high, thick, short, and outside R709 aperture.
    assert 2*q0*ln2>A('0.375')*L
    assert A('0.2')*q0>L/(384*C)
    assert h*(L/n).sqrt()/64<A('0.1')
    assert R<2*h*n/L
    assert R>2 and (R*(J*g).exp())>2
    assert A('0.5')>A(1)/a and A('0.75')+A(1)/a<1
    # Shift -y_j sends E_j exactly to Q(0,1/a), contained even in original Ai.
    assert (R*((J+1)*g).exp()-2).contains(0)
    assert A(1)/a<2/a
    # Fixed origin pool mass is exactly1/2; every qualified pool inherits the
    # robust retained lower after subtracting all possible late+trigger mass.
    normalization=(-logratio-A(4*clock).log())/A(10).log()
    excess_lower=((robust_retained-A('0.25')).log()-A(clock).log()-logratio)/A(10).log()
    residual_normalized=(residual_lower.log()-A(clock).log()-logratio)/A(10).log() if residual_lower>0 else None
    return {'stage':{128:'preliminary',1024:'stress',2048:'expanded'}[multiplier],
            'b':b,'n':f'2^{b}','active_count':active,'passive_count':passive,
            'receiver_count':f'n^{multiplier//2} = 2^{active//2}',
            'J':str(J),'R':st(R),'favorable_digits':str(favorable),
            'favorable_mu_per_sign':st(B*p),'q0':q0,
            'log_failure_upper_boundary_conditioned':st(fail.log()),
            'failure_less_than_n_minus_3':True,
            'robust_retained_weight_lower_every_qualified_pool':st(robust_retained),
            'nonrobust_full_early_weight_upper':st(bad_full_upper),
            'partial_early_weight_upper':st(partial_upper),
            'late_plus_trigger_weight_upper':st(missing_upper),
            'log_penalty_lower':st(log_penalty),'log_penalty_over_log_n':st(log_penalty/L),
            'sum_full_masked_scores_upper':st(score_upper),'rho':st(rho),
            'R711_pointwise_residual_lower_including_min':st(residual_lower),
            'R711_pointwise_residual_upper_for_origin_menu':'1/2',
            'VT':st(logVT.exp()),'D':st(logD.exp()),
            'log_D_over_VT':st(logratio),'log10_VT_over_4sqrt_n_D':st(normalization),
            'log10_original_positive_excess_over_sqrt_n_D_lower':st(excess_lower),
            'log10_R711_residual_over_sqrt_n_D_lower':st(residual_normalized) if residual_normalized is not None else None,
            'shift_count_cost':f'n^{multiplier//2} possible center vectors; each sends the full owner to Q(0,1/a)',
            'precision_bits':bits,'_values':(robust_retained,residual_lower,score_upper,logratio,normalization),
            '_remote_values':[float(robust_retained),float(residual_lower),float(logratio),float(normalization)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext
import json,socket,sys
with localcontext() as c:
 c.prec=110
 rows=[]
 for multiplier in [128,1024,2048]:
  for b in [48,64,80]:
   n=1<<b;a=32*n;clock=1<<(b//2);m=b//4;active=multiplier*b;C=65536
   l2=D(2).ln();L=D(b)*l2;t=D(clock)/l2;g=(1-D(2)/a).ln()
   W=1-(D(n)*g).exp();Wp=W/D(1<<m);J=int(D(clock)/Wp);e=D(clock)-J*Wp
   logR=l2-D(J+1)*g;R=logR.exp();nf=max(0,int(D(a)/2*((D('.5')-D(1)/a)/R-D('.1'))-1))
   p=D(nf)/a;B=active//2;q0=3*b//16+1
   mass=(D(B)*(1-p).ln()).exp();tail=mass
   for j in range(1,q0):
    mass*=D(B+1-j)/j*p/(1-p);tail+=mass
   fail=2*tail/W;full=1-(-D(J)*Wp/t).exp();bad=full*(Wp/t).exp()*fail
   retained=full-bad # beta0 and all receiver/trigger mass are beyond relevant precision
   lp=D(q0)*(1+D(C)*(D('.1')/D('1.01'))**2).ln()
   score=bad+Wp/t+D('.5')*(-lp).exp()
   rho=(-L/6).exp()*L**(D(1)/3);res=max(D(0),retained-score/rho)
   logP=D(n)*g-Wp/t
   assert D(J)*logP<-1000
   logearly=D(n)*logR+((1-(-Wp/t).exp())/(1-logP.exp())).ln()
   logratio=logearly-(-D(n)*D(a).ln()+D(active//2)*l2)
   norm=(-logratio-D(4*clock).ln())/D(10).ln()
   rows.append({'b':b,'multiplier':multiplier,'favorable_digits':str(nf),'values':[str(retained),str(res),str(logratio),str(norm)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 approximate; beta0 and negligible partial D-tail omitted','rows':rows}))
'''


def main():
    rows=[]
    for multiplier in [128,1024,2048]:
        for b in [48,64,80]:
            low=calculate(b,multiplier,256);high=calculate(b,multiplier,384)
            assert low['favorable_digits']==high['favorable_digits'] and low['J']==high['J']
            for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
            del high['_values'];rows.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=30)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['favorable_digits']==other['favorable_digits']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'rows':rows,'remote':remote,
            'real_history':['n=2^b,a=32n,t=sqrt(n)/log2,m=b/4 passive positive folded coordinates. Early clock and shell construction agree exactly with R710.',
                            'Early count N-1 with N=sqrt(n)*a^n; each owner has weight a^-n. All early parents have radius>2, trigger radius2, receiver radius1. Every parent contains a common positive origin cell, so this is the actual greedy order.',
                            'Trigger center has passive coordinates-7/4. It is exactly the Nth update and first hits load1/2. Receiver centers have passive coordinates3/4, paired active coordinates+1/2 and-1/2, and zero elsewhere.',
                            'All full tiny cores are mutually disjoint: early shells have inner radius2; receiver cores lie inside radius1; trigger core lies strictly inside radius2 and on negative passive coordinates. Receiver patterns differ by1 in an active coordinate.',
                            'Receiver count changes with active count: 128b gives n^64,1024b gives n^512,2048b gives n^1024. Clock and donor budget do not change, apart from the correctly included full receiving contribution to D.',
                            'Translation by minus each receiver center maps its entire real owner to Q(0,1/a), already contained in every original initial donor (minimum origin margin>s_i/a>2/a), hence also in (1+4/n) dilates.'],
            'uniform_score_bound':['The favorable digit floor guarantees exterior distance>0.1*s_i in each favorable coordinate for every point of the full receiver owner and every early scale<=R.',
                                   'Each robust donor has at least q0 favorable positive and q0 favorable negative active coordinates. It is original high loss, thick in R711, and cannot have any common witness in the R709 close aperture.',
                                   'The two active lower-tail events are independent before boundary conditioning. Their union costs<=2*tail; dividing by W handles the whole boundary conditioning. Passive folding preserves W. Actual weight tilt within a full layer costs at most exp(W_prime/t).',
                                   'All partial last-layer weight is conservatively nonrobust, at cost<=W_prime/t. Trigger and all later receiver weights cost<= (beta0+Nrec*beta0)/t. This also bounds omitted robust early weight for ANY qualified pool with weight>=1/2.',
                                   'For any nonempty subset in any bin, presence of one robust donor forces penalty>=(1+C*(0.1/1.01)^2)^q0. A subset containing no robust donor is paid entirely by nonrobust mass.',
                                   'Consequently sum of the FULL maximized masked scores<=bad_full+partial+late_trigger+(1/2)/penalty. No enumeration of subsets is used and nonrobust subsets are included.',
                                   'Subtract rho^-1 times this full-score upper from the robust retained lower. The result holds for every receiver point and every eligible pool, so it survives min over all qualified witness menus. Integrating multiplies it by actual VT.'],
            'scope':['All local bounds use Arb256/384-bit overlapping enclosures and uniquely certified floors. No receiver sampling or artificial pool is used.',
                     'VT and D are raw Lebesgue volume and full greedy budget, not volumes divided by2^n. The displayed normalization cancels common factors only algebraically.',
                     'Remote CPU Decimal110 is an approximate independent crosscheck with explicitly negligible terms omitted; the local Arb calculations retain these terms.',
                     'Positive residual in these real histories is not a counterexample to a source-budget bound: VT/(sqrt(n)D) is extremely small, as reported.',
                     'No remote files or GPU processes are created. Only this script and residual.json are written in the assigned local folder.']}
    output=Path(__file__).with_name('residual.json');output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['stage','b','R711_pointwise_residual_lower_including_min','log_penalty_over_log_n','log10_VT_over_4sqrt_n_D']} for r in rows]},indent=2))


if __name__=='__main__':main()
