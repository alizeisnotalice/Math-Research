# R393: bounded feasibility probe for a large-J actual hard-matched field

**Outcome:** the proposed integer-cell construction is feasible. Exact local computation gives a positive original R329 B_H sub-integral with an entire positive-volume central source cell in the declared high-J set H=sqrt(n). This is a useful contrast with R388's positive true-du branch at tiny diagnostic h/H; it is not a claim of the first positive remainder construction, original historical first selection, a synchronized high-past core, a new payment, or a near-extremizer.

## Frozen finite L1 construction

Use n in {4,16,36,64}, a=4n,b=8n, delta=1/(100n^2), lambda=1. At each integer j in {-b,...,b}^n put the disjoint cube j+[-delta,delta]^n with mass 1, hence density (2delta)^(-n). Let f be their finite sum; beta=nu=f. Full W=(2b+1)^n is retained, including cells not used by the probe.

For every integer k=a,...,b define

C_k=[-k/2+delta,k/2-delta]^n,
allowed_k={u: dist(u_i-k/2,Z)>delta for every i},
E_k=(C_k minus C_(k-1)) intersect allowed_k.

The first E_a is also a shell; no artificial full initial cube is inserted. These actual Lebesgue receiver sets are disjoint. Set R=L=k, softness zero, alpha=1. Integer side length makes the two capture boundaries have the same phase modulo Z. The guard removes every partial-source-cell crossing, so every coordinate captures exactly k complete cells. All those cells are inside the finite support index range. Thus actual m=k^n and q=m/k^n=1 on E_k. The same full f gives actual q<=lambda and hard cap<=lambda<4lambda, without a new source or diagnostic edge measure. It does not certify an old historical FIRST selector.

All E_k capture the entire central source cell, not just its center. Hence its true f-mass is 1 and every y in it has the same prefix J_y. The guard also makes capture of each neighboring source cell constant over the entire cell.

## Independently checked exact volumes

Write c=1-2delta. Shifting a coordinate by k/2 reduces the strip calculation to integer-period allowed intervals [j+delta,j+1-delta]. The outer/inner allowed lengths are

L_k=kc,
I_k=(k-1)c-2delta=kc-1.

Therefore |E_k|=L_k^n-I_k^n, with no neglected delta or dimension loss. For the source cell at e1 the first-coordinate allowed capture lengths are

O_k=(k-1)c,
N_k=(k-2)c+1/2-2delta.

Its capture volume in E_k is O_k L_k^(n-1)-N_k I_k^(n-1). Reflection/permutation give the same value for all 2n adjacent cells. The script independently integrates actual one-dimensional allowed intervals at k=a,a+1,b, covering both parities, to check all four formulas. It then uses them for every layer.

The exact prefixes are

J=sum |E_k|/k^n,
A=sum [O_k L_k^(n-1)-N_k I_k^(n-1)]/k^n.

Construction-only checks also confirm

c^n sum n/(kc+n) <=J<= n c^(n-1) sum 1/k.

These are occupancy checks for this field, not new global estimates.

## Declared high-J and a genuinely positive B_H contribution

Only H=sqrt(n) is tested, exactly by squared comparisons. Original synchronized h and the historical/root-selected H are **not verified**. The full central source cell belongs to Y_b because J_b>H. Its physical clock is the one in R329: weight k^(-n)-(k+1)^(-n) on each prefix interval [k,k+1), and a genuine terminal atom b^(-n).

Since the whole central source cell and each adjacent cell have f-mass 1, the terminal contribution alone gives the exact positive lower bound

B_H(f,f) >= 2n b^(-n) [A_b-A_b^2/J_b] >0.

It is only this central-y/neighbor-z physical terminal sub-integral. It is neither full B_H, a full central-row evaluation, a full-field upper bound, nor a historical atom payment. All other nonnegative B_H terms are simply unused in this lower bound.

| n | J_b | A_b/J_b | first k with J>=sqrt(n) | terminal sub-integral lower | actual X/W |
|---|---:|---:|---:|---:|---:|
| 4 | 2.754454 | .848709 | 27 | 2.69835e-6 | .0556922 |
| 16 | 10.360464 | .960713 | 84 | 2.40998e-33 | 1.43190e-5 |
| 36 | 23.046754 | .982422 | 173 | 8.30023e-88 | 1.36636e-11 |
| 64 | 40.808749 | .990089 | 294 | 2.07239e-172 | 5.09116e-20 |

Here X=lambda|E| is the exact sum of actual shell volumes. W is enormous; the tiny X/W and partial lower bounds do not exhibit a near-extremizer and do not support a dimension-exponent inference. The advantage over previous tiny-h examples is the explicit large-J comparison at a declared sqrt(n) threshold, not a general-budget conclusion.

## Operation scale and next step

The present probe needs 4n+1 layers, at most 257, and runs in about .25 seconds locally. No n-dimensional source-cell enumeration occurs. A central-row full-nu second moment is a plausible next bounded calculation: after swapping two receiver integrations, each outer/inner shell pair has a product of one-dimensional lattice sums over common captured cells, with four inclusion-exclusion terms. This would require roughly (4n+1)^2 shell pairs (about 66,000 at n64), and should start at n4/16 before larger exact-integer work. It has **not** been run or certified in this probe. Full beta integration of the varying J_y is a separate issue; a central-row computation must not be relabelled a full-field bound.

## Reproduction

Run `python3 r393_native_probe.py`; standard library only, no old /tmp imports or optimizer. It writes a small `r393_native_probe.result.json` beside itself. Large exact fractions are computed but stored as sign, numerator/denominator digit counts, SHA256 and 40-digit Decimal displays, avoiding enormous raw JSON. Displays are not interval certificates; all inequalities and positivity assertions use exact Fraction arithmetic.

**556 exact checks** passed: 48 independent one-dimensional geometry checks, 484 positive prefix-increment checks, 24 global accounting/high-H checks. A fresh second process reproduced output bytes. Only the owned R393 native-probe files were changed; no other-agent or repository/Git edits. This is preparation for subsequent geometry verification, not a new theorem or a claim that all original core/history gates have been implemented.
