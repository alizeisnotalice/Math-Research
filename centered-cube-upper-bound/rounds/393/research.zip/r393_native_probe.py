"""R393 bounded actual lattice-cell hard-matched BH probe; stdlib only."""
from fractions import Fraction as F
from decimal import Decimal,localcontext
from pathlib import Path
from math import isqrt
import hashlib,json,sys
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
COUNTS={'independent_1d_geometry':0,'prefix':0,'global_account':0}
def ck(x,k):
 assert x,k
 COUNTS[k]+=1

def allowedlength(lo,hi,k,d):
 lo+=F(k,2);hi+=F(k,2)
 return sum((max(F(0),min(hi,F(j+1)-d)-max(lo,F(j)+d)) for j in range(lo.numerator//lo.denominator-1,hi.numerator//hi.denominator+2)),F(0))

def display(q):
 with localcontext() as c:
  c.prec=40
  return str(Decimal(q.numerator)/q.denominator)

def compact(q):
 raw=str(q)
 return {'decimal40':display(q),'positive':q>0,'numerator_digits':len(str(abs(q.numerator))),'denominator_digits':len(str(q.denominator)),'fraction_sha256':hashlib.sha256(raw.encode()).hexdigest()}

def case(n):
 a=4*n;b=8*n;delta=F(1,100*n*n);c=1-2*delta;H=isqrt(n)
 ck(H*H==n and 0<delta<F(1,4),'global_account')
 for k in [a,a+1,b]:
  outer=(-F(k,2)+delta,F(k,2)-delta)
  inner=(-F(k-1,2)+delta,F(k-1,2)-delta)
  capture=(1-F(k,2)+delta,1+F(k,2)-delta)
  L=k*c;I=(k-1)*c-2*delta;O1=(k-1)*c;I1=(k-2)*c+F(1,2)-2*delta
  ck(allowedlength(*outer,k,delta)==L,'independent_1d_geometry')
  ck(allowedlength(*inner,k,delta)==I,'independent_1d_geometry')
  ck(allowedlength(max(outer[0],capture[0]),min(outer[1],capture[1]),k,delta)==O1,'independent_1d_geometry')
  ck(allowedlength(max(inner[0],capture[0]),min(inner[1],capture[1]),k,delta)==I1,'independent_1d_geometry')
 J=A=X=F(0);first=None;Jlower=Jupper=F(0)
 for k in range(a,b+1):
  L=k*c;I=L-1;O1=(k-1)*c;I1=(k-2)*c+F(1,2)-2*delta
  volume=L**n-I**n;neighbor_volume=O1*L**(n-1)-I1*I**(n-1)
  dJ=volume/F(k**n);dA=neighbor_volume/F(k**n)
  ck(0<dA<dJ,'prefix')
  prev=J;J+=dJ;A+=dA;X+=volume
  if first is None and J*J>=n:
   first={'k':k,'J_before':display(prev),'J_after':display(J)}
  Jlower+=c**n*F(n)/(k*c+n)
  Jupper+=n*c**(n-1)/k
 ck(Jlower<=J<=Jupper,'global_account')
 ck(J*J>n and first is not None,'global_account')
 ck(0<A<J,'global_account')
 W=(2*b+1)**n
 ck(X<=(b-2*delta)**n-(a-1-2*delta)**n and X>0,'global_account')
 # Every central source cell y has mass1 and the same J. Every +/-e_i source
 # cell has mass1 and the same A. Keep ONLY the genuine terminal clock atom.
 terminal_lower=F(2*n,b**n)*(A-A*A/J)
 ck(terminal_lower>0,'global_account')
 return {'n':n,'a':a,'b':b,'menu_count':b-a+1,'delta':str(delta),'declared_H':H,
 'original_synchronized_h_or_historical_H_verified':False,
 'Jcentral':compact(J),'Acentral_neighbor':compact(A),'A_over_J':compact(A/J),
 'first_declared_H_crossing':first,'J_lower':compact(Jlower),'J_upper':compact(Jupper),
 'full_source_cell_count_and_W':str(W),'one_source_cell_volume':str((2*delta)**n),
 'central_source_mass':'1','q_actual':'1','X_lambda_E':compact(X),'X_over_W':compact(X/W),
 'BH_central_times_2n_neighbors_terminal_lower':compact(terminal_lower),
 'lower_over_full_W':compact(terminal_lower/W)}

def main():
 cases=[case(n) for n in [4,16,36,64]]
 result={'scope':'Actual compact positive L1 lattice-cell source, actual Lebesgue shell receivers with all boundary-near strips removed, actual q=1 and m=k^n. The original hard-matched BH of r329_core at explicitly declared H=sqrt(n) has a positive terminal central-cell/neighbor partial lower bound. It is not full BH, not a full-field upper bound, not original historical FIRST/synchronized h qualification, and not a near-extremizer.',
 'exact_fraction_assertions':COUNTS,'total_assertions':sum(COUNTS.values()),'cases':cases}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNTS,'total',sum(COUNTS.values()))
 for v in cases:print(v['n'],'J',v['Jcentral']['decimal40'],'A/J',v['A_over_J']['decimal40'],'X/W',v['X_over_W']['decimal40'],'terminalBHlower',v['BH_central_times_2n_neighbors_terminal_lower']['decimal40'])
if __name__=='__main__':main()
