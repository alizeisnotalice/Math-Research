# R393 native construction audit — FINAL PASS

FINAL PASS for the explicit real-du construction, exact matching/capture volumes, declared H=sqrt(n) qualification and positive original BH terminal subintegral. No new source budget, near-extremizer, synchronized entrance or filtered gamma/core is certified. The independent screen below preceded the author proof. Only this audit file was edited.

## Actual matching and source support: PASS

Let n>=2, a=4n, b=8n, delta=1/(100n^2), w=1-2delta. Use full f equal to (2delta)^(-n) on the disjoint small cubes centered at integer j in [-b,b]^n and zero elsewhere. Each packet has mass one and total W=(2b+1)^n. E_k lies in C_k\C_(k-1), so the receiver layers are pairwise disjoint up to irrelevant boundaries, have positive finite Lebesgue measure, and the actual selector R=k is measurable.

The strip test dist(u_i-k/2,Z)>delta keeps both endpoints of the integer-length capture interval away from every packet boundary. For every allowed center, each coordinate interval contains exactly k complete packets and meets no partial packet. Tensor capture therefore gives f(Q_k(u))=k^n, q=1, m=k^n, with the same full source throughout. The selected receiver range and capture radii require only lattice centers within [-b,b]^n, so no missing source at the support boundary is used. The entire central packet [-delta,delta]^n is captured by every selected receiver since u belongs to C_k.

These are actual Lebesgue receiver sets, not receiver quadrature or center substitution. The construction realizes q=1 within the band [3/4,1] when lambda=1. No first-crossing property beyond that matching is inferred.

## Exact source-packet capture volumes: PASS

For the period-one good strips of phase k/2, direct interval intersection gives the one-dimensional lengths

- C_k: k w;
- C_(k-1): (k-1)w-2delta;
- C_k intersect the centers capturing the neighbor packet e_1: (k-1)w;
- C_(k-1) intersect those neighbor centers: (k-2)w+1/2-2delta.

The neighbor restriction affects only coordinate one. Consequently

    |E_k|=(kw)^n-[(k-1)w-2delta]^n,

    |E_k capturing neighbor|=
      (k-1)w (kw)^(n-1)
      -[(k-2)w+1/2-2delta][(k-1)w-2delta]^(n-1).

In particular 0<neighbor volume<|E_k|. This comparison concerns actual source-packet capture, not volume as a bound on an arbitrary f. Here f is explicitly the packet source, so the complete-capture property makes the volume formulas exact.

## Original BH subintegral and clock: PASS with explicit H condition

For y in the entire central packet and z in the entire e_1 packet, J_y(r)=J_k and A_yz(r)=A_k are constant on the packet product when k<=r<k+1. They equal the cumulative sums of the two displayed volumes divided by ell^n for integer layers ell=a,...,k. Both packets have f-mass one, so their original double-source integral is exactly A_k(1-A_k/J_k), not a point-source approximation. All other positive original integrands may be dropped to obtain a lower bound.

The physical clock on [a,b] has continuous density n r^(-n-1) and its terminal b^(-n) atom. Thus a rigorous lower bound for the original full-f hard-matched BH is

    sum_(k=a)^(b-1) [k^(-n)-(k+1)^(-n)]
         1_{J_k>=H} A_k(1-A_k/J_k)
    +b^(-n)1_{J_b>=H} A_b(1-A_b/J_b).

Every J_k>A_k>0. Hence ANY stated 0<H<=J_b gives a strictly positive original BH contribution, including H=J_b via the terminal atom. At r=b there is no subtraction of that atom. This is only a lower bound, not a replacement of the full BH by its central row or its central-neighbor subintegral.

A diagnostic small H does not certify the synchronized high-J/high-past thresholds of the current upper-bound reduction. If an author uses a prescribed H such as (1+sqrt(n))/(epsilon q_-), it must establish the actual comparison J_b>=H for the tested dimensions. The universal upper bound J_b<=(1+n log 2)/q_- and the finite common-menu necessary bound remain applicable. q=1 alone does not imply nonempty high-J at a prescribed H. Strict global masspast, far mass, source-surplus, dense/deep, outside/notBplus and core/history qualifications must each be checked if claimed; they are not supplied by a positive original BH example.

## Actual independent local arithmetic

Reviewer ran exact Fraction interval intersections for n=2,3,4,8,16 and every integer k=4n,...,8n: 827 assertions, exit 0. These independently verify all four interval lengths, positive neighbor/full layer volumes and 0<A_b<J_b. Display terminal values (ordinary decimal displays of exact rational calculations):

    n=2: J=1.49531550094919, A=1.06743726215025;
    n=3: J=2.12314723096675, A=1.70246468322468;
    n=4: J=2.75445372926785, A=2.33772886175057;
    n=8: J=5.28757652670427, A=4.87719803949499;
    n=16: J=10.3604635141749, A=9.95343162766514.

These are bounded formula checks, not high-dimensional synchronized-gate certificates. No author proof/code was read before this screen. The completed author audit and byte bindings follow below.


## Completed code and parent integration review

Read the entire final native_probe.py, its result JSON, parent main and readme. Reviewer actually reran the script locally: exit 0, 556 Fraction assertions (48 independent 1D, 484 layer-prefix, 24 global-account). These are the same executed cases as the parent's 556 and are NOT added to them. The independent pre-proof 827 interval assertions remain a separate bounded reviewer check.

The executable's n=4,16,36,64 are perfect squares, so its isqrt H is exactly sqrt(n). First crossings 27,84,173,294 and terminal J_b>H use exact comparisons J^2>=n or >n. Source-volume identities, J and A sums, positivity and the complete W are exact Fraction computations; Decimal40 strings and rational hashes are compact displays, not a replacement for the exact regenerated fractions.

The factor 2n in the terminal lower bound is correct: sign reflections and coordinate permutations preserve the selected receiver layer, and the 2n source packets at +/-e_i are disjoint with full source mass one each. Only y in the central packet and z in these neighbors is counted. No extra reverse-source factor two or missing clock normalization is introduced. With J_b>=H the terminal atom has exact weight b^(-n), giving the stated strictly positive lower bound.

Jlower/Jupper are valid algebraic enclosures of the layer increment c^n[1-(1-1/(kc))^n]: the lower follows from (1-x)^(-n)>=1+nx, and the upper from 1-(1-x)^n<=nx. X is the actual sum of disjoint receiver-layer volumes, bounded above by the full C_b\C_(a-1) volume. No selected receiver volume or source W is reset.

Main/readme correctly report a calibration for the original hard-matched nonnegative BH with the explicitly chosen H, not an upper bound, near-extremizer, positive final gamma/core realization, or synchronized entrance certificate. The very small X/W in the tested higher dimensions and all historical/filter qualifications remain explicit. The inherited R392 ledger and 2G_core/4Lambda coefficients are unchanged, and this diagnostic parameter choice does not replace a term in that ledger. No new W receipt, X absorption or old capture-square credit is booked.

The bounded historical/source retrieval indexes and stopped-candidate checkpoint are descriptive only; this reviewer does not certify their history exhaustiveness or re-audit prior source constructions. The checkpoint itself records no mathematical computation, separately from this round's native script. The final author note was subsequently read in full; its matching, parity/strip, physical-clock, positive-lower-bound and evidence-scope statements agree with the independent derivation and code. Its suggested central-row second-moment computation is explicitly unrun and is not counted as a result.


## Final proof and ledger conclusion

The author's native_probe.md correctly retains E_a as a shell rather than replacing the initial receiver layer by a whole cube. The strip phase at k=a,a+1,b checks both integer parities. The exact q=1 statement comes from the actual full source, not a freely assigned finite edge kernel. The central source packet and adjacent packets have positive Lebesgue volume, so the lower bound is a genuine nonzero original hard-matched functional contribution, in contrast with a center-only calculation.

The finite-support truncation is exact for these selected cubes; no asymptotic periodic-to-L1 migration is required. Nonetheless W is (2b+1)^n, and the reported small X/W remains material. The declared H is an allowed input of this BH diagnostic. Nothing proves that it is the threshold selected in the current synchronized reduction; all additional original high-past/FIRST/far/middle/spatial/self-support/history gates remain unverified here. A lower bound on this subintegral cannot substitute for the current G_core or for a general upper bound.

The old r392 ledger remains unchanged. There is no new source W fee paid, X absorption, core deletion, additional negative capture-square credit or fitted dimension exponent. A lower calculation of the original A-A^2/J subintegral does not spend that negative square again in an unrelated upper argument. FINAL PASS is limited to these exact construction and presentation claims; the general root upper bound is still open.

## Frozen SHA256 bindings

The dependencies below are context contracts, not a fresh audit of all historical reductions. The bounded source/prior indexes and stopped-candidate checkpoint are bound for provenance only; no claim of exhaustive novelty screening is endorsed.

- `r393_main.md`: `b6f3c1c1ba6e8ab033ef45732b1ccaac7d9b7b78c1d196264b736668fe2a21db`
- `r393_readme.md`: `cbd0aaa589482c93909d86431b60da9425433758af9244ad3881ef1daa659c5a`
- `r393_native_probe.md`: `f7cac74bb435ac8ef85a0827432715d039f0391e6dd7e94e80fcf18c0a6e091d`
- `r393_native_probe.py`: `5b5ebd81be63a4eb10c02025c266f648922f5b030757fbfb1e5e83a0f005fa6d`
- `r393_native_probe.result.json`: `87102a7f9f5b62e81e22ce4dbb95586de2169525a9110fb5f23156e8310c5b11`
- `r393_geometry.md`: `9443c0f00d107bbd7e024553ce9547bad85b356a2f7714ac7e6040d74ce5156b`
- `r393_native_index.md`: `c5643621c8a322af4516834569465876fb366537e869866f2931e57a0e23e5f7`
- `r393_prior_index.md`: `53fb8b0c68ea3230de3f7991c3a461f28bca35a2bf0a24f09a16d33b65f4757f`
- `r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
- `r329_core.md`: `a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc`
