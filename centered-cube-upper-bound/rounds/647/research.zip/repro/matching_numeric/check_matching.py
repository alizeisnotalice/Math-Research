import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import json,sys,hashlib,time,resource,platform,concurrent.futures
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
D=Path(__file__).resolve().parent

def profile(m,k):
 if k==0:return [F(1)]*m
 if k==1:return [F(j+1) for j in range(m)]
 if k==2:return [F(2**j) for j in range(m)]
 if k==3:return [F(1,2**(100*j)) for j in range(m)]
 raise ValueError(k)

def test(m,edges,c):
 r=c[:];b={}
 for i,j in edges:
  d=min(r[i],r[j]);b[i,j]=d;r[i]-=d;r[j]-=d
 row=[F(0)]*m
 for (i,j),v in b.items():row[i]+=v;row[j]+=v
 assert all(x>=0 for x in b.values())
 assert all(F(0)<=row[i]<=c[i] and row[i]+r[i]==c[i] for i in range(m))
 assert all(not(r[i]>0 and r[j]>0) for i,j in edges)
 assert 2*sum(b.values(),F(0))<=sum(c,F(0))
 P=sum((row[i]/c[i] for i in range(m)),F(0));s=sum((r[i]/c[i] for i in range(m)),F(0));assert P+s==m
 if s>=1:
  scale=F(1);eligible=P;ineligible=s-1;remaining=ineligible;extra=[F(0)]*m
  for i in range(m):
   extra[i]=min(r[i]/c[i],remaining);remaining-=extra[i]
  assert remaining==0 and all(F(0)<=extra[i]*c[i]<=r[i] for i in range(m))
  assert sum(extra,F(0))==ineligible and eligible+sum(extra,F(0))==m-1;branch='s_ge_1'
 else:
  assert m>=2 and P>m-1 and P>0
  scale=F(m-1)/P;assert F(0)<scale<1
  eligible=scale*P;ineligible=F(0);assert eligible==m-1;branch='s_lt_1'
 b2={e:scale*v for e,v in b.items()};row2=[F(0)]*m
 for (i,j),v in b2.items():row2[i]+=v;row2[j]+=v
 # One unordered edge value represents both symmetric matrix entries.
 for i in range(m):
  for j in range(m):
   u=b2.get((min(i,j),max(i,j)),F(0)) if i!=j else F(0)
   v=b2.get((min(j,i),max(j,i)),F(0)) if i!=j else F(0)
   assert u==v
 assert all(F(0)<=x<=c[i] for i,x in enumerate(row2))
 assert 2*sum(b2.values(),F(0))<=sum(c,F(0))
 assert sum((row2[i]/c[i] for i in range(m)),F(0))==eligible
 assert eligible+ineligible==m-1
 return branch,s,P

def task(m,k):
 st=time.monotonic();cpu=time.process_time();all_edges=list(combinations(range(m),2));c=profile(m,k);n=1<<len(all_edges);counts={'s_ge_1':0,'s_lt_1':0,'s_eq_1':0};witness=[]
 for mask in range(n):
  edges=[e for j,e in enumerate(all_edges) if mask>>j&1]
  try:
   branch,s,P=test(m,edges,c);counts[branch]+=1;counts['s_eq_1']+=s==1
  except Exception as exc:
   witness.append({'m':m,'profile':k,'mask':mask,'edges':edges,'c':list(map(str,c)),'exception':repr(exc)});break
 return {'m':m,'profile':k,'graphs_expected':n,'graphs_checked':sum(counts[x] for x in ('s_ge_1','s_lt_1')),'counts':counts,'failures':witness,'cpu_seconds':time.process_time()-cpu,'wall_seconds':time.monotonic()-st,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 fixtures=[('m1',1,[],[F(7,3)],'s_ge_1',F(1)),('exact_s1',3,[(0,1),(1,2)],[F(1)]*3,'s_ge_1',F(1)),('s_less_1',2,[(0,1)],[F(1)]*2,'s_lt_1',F(0)),('empty_s_gt_1',3,[],[F(1)]*3,'s_ge_1',F(3))];fix=[]
 for name,m,edges,c,branch,s in fixtures:
  a,b,P=test(m,edges,c);assert a==branch and b==s;fix.append({'name':name,'m':m,'c':list(map(str,c)),'edges':edges,'branch':a,'s':str(b),'P':str(P)})
 start=time.monotonic();jobs=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=8) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,m,k) for m in range(1,7) for k in range(4)]):
   x=f.result();jobs.append(x);print('complete',x['m'],x['profile'],x['graphs_checked'],'failures',len(x['failures']),flush=True)
   doc={'command':sys.executable+' '+str(Path(__file__).name),'python':sys.version,'platform':platform.platform(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'workers':8,'wall_seconds':time.monotonic()-start,'worker_cpu_seconds':sum(q['cpu_seconds'] for q in jobs),'worker_peak_rss_bytes':max(q['peak_rss_bytes'] for q in jobs),'completed_jobs':len(jobs),'fixtures':fix,'jobs':jobs}
   tmp=D/'results.tmp';tmp.write_text(json.dumps(doc,indent=2));tmp.replace(D/'results.json')
if __name__=='__main__':main()
