#!/usr/bin/env python3
from fractions import Fraction as F
import itertools,json,sys,time,resource
from pathlib import Path

def eval_graph(c,edges):
 c=list(map(F,c));N=len(c);assert N and min(c)>0
 edges=sorted(set(tuple(sorted(e)) for e in edges));assert all(0<=i<j<N for i,j in edges)
 remaining=c.copy();weights={}
 for i,j in edges:
  amount=min(remaining[i],remaining[j]);weights[i,j]=amount;remaining[i]-=amount;remaining[j]-=amount
 rows=[sum((b for (i,j),b in weights.items() if k in (i,j)),F(0)) for k in range(N)]
 assert all(0<=rows[i]<=c[i] and rows[i]+remaining[i]==c[i] for i in range(N))
 assert all(remaining[i]*remaining[j]==0 for i,j in edges)
 P=sum((rows[i]/c[i] for i in range(N)),F(0));s=sum((remaining[i]/c[i] for i in range(N)),F(0))
 assert P+s==N and sum(weights.values(),F(0))<=sum(c,F(0))/2
 assert P==sum((b*(1/c[i]+1/c[j]) for (i,j),b in weights.items()),F(0))
 factor=F(1) if s>=1 else F(N-1)/P
 if s>=1:
  need=s-1; allocations=[]
  for i in range(N):
   spend=min(remaining[i]/c[i],need);allocations.append(spend);need-=spend
  assert need==0 and sum(allocations,F(0))==s-1 and all(allocations[i]*c[i]<=remaining[i] for i in range(N))
 if s<1: assert N>=2 and P>N-1 and 0<=factor<1
 scaled={e:factor*b for e,b in weights.items()};r=[c[i]-factor*rows[i] for i in range(N)];afterP=sum((factor*rows[i]/c[i] for i in range(N)),F(0));afterS=sum((r[i]/c[i] for i in range(N)),F(0))
 assert afterP+afterS==N and all(v>=0 for v in r)
 assert (afterP==N-1 and afterS==1) if s<1 else (afterP==P and afterS==s)
 return {'m':N,'s':str(s),'P':str(P),'scale':str(factor),'original':list(map(str,remaining)),'scaled_residual':list(map(str,r)),'scaled_support_independent':all(r[i]*r[j]==0 for i,j in edges)}
if __name__=='__main__':
 test=[('single-vertex',[1],[]),('empty-three',[1]*3,[]),('path-three',[1]*3,[(0,1),(1,2)]),('single-edge',[1,1],[(0,1)]),('skew-path',[1,2,8],[(0,1),(1,2)]),('triangle-skew',[1,3,7],[(0,1),(0,2),(1,2)])]
 out={name:eval_graph(c,e) for name,c,e in test};assert out['single-vertex']['s']=='1';assert out['empty-three']['s']=='3';assert out['path-three']['s']=='1';assert out['single-edge']['s']=='0' and not out['single-edge']['scaled_support_independent'] and out['single-edge']['scaled_residual']==['1/2','1/2']
 (Path(__file__).parent/'independent_results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
