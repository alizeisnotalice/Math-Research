import importlib.util,json,math,sys,itertools,hashlib,time,resource
from pathlib import Path
from fractions import Fraction as F
from check import eval_graph
p=Path(__file__).resolve().parent.parent/'matching_numeric';src=p/'check_matching.py';data=json.loads((p/'results.json').read_text());spec=importlib.util.spec_from_file_location('author',src);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
assert hashlib.sha256(src.read_bytes()).hexdigest()==data['script_sha256'];jobs=data['jobs'];assert data['completed_jobs']==len(jobs)==24 and {(z['m'],z['profile']) for z in jobs}==set(itertools.product(range(1,7),range(4)))
for z in jobs:
 expect=2**(z['m']*(z['m']-1)//2);assert z['graphs_expected']==z['graphs_checked']==expect and not z['failures'];assert sum(z['counts'][x] for x in ('s_ge_1','s_lt_1'))==expect and 0<=z['counts']['s_eq_1']<=z['counts']['s_ge_1']
assert sum(z['graphs_checked'] for z in jobs)==135468
for m in range(1,7):
 for k in range(4):
  want=[[F(1) for j in range(m)],[F(j+1) for j in range(m)],[F(2**j) for j in range(m)],[F(1,2**(100*j)) for j in range(m)]][k];assert mod.profile(m,k)==want
  all_edges=list(itertools.combinations(range(m),2));subsets=[[],all_edges,[(i,i+1) for i in range(m-1)]]
  for edges in subsets:
   own=eval_graph(want,edges);branch,s,P=mod.test(m,edges,want);assert (branch,str(s),str(P))==('s_lt_1' if F(own['s'])<1 else 's_ge_1',own['s'],own['P'])
for fixture in data['fixtures']:
 a=eval_graph(fixture['c'],fixture['edges']);assert a['s']==fixture['s'] and a['P']==fixture['P'] and fixture['branch']==('s_lt_1' if F(a['s'])<1 else 's_ge_1')
print('PASS 24 jobs, 135468 reported cases, 4 profiles x 6 sizes x 3 graph samples, 4 fixtures; no failure witnesses in supplied results')
