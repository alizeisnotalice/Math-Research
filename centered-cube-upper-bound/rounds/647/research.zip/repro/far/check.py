from fractions import Fraction as F
from itertools import product
import json

Z=F(0); O=F(1)
def pos(x): return max(Z,x)
def run(stage):
    # Two unit cells, two rows; |C_i|=m_i and ∫D_i=m_i.
    masks=[(1,0),(0,1),(1,1)]
    levels=range(3) if stage != 'initial' else range(2)
    weights=[Z,O] if stage=='initial' else [Z,F(1,2),O]
    rs=[F(2)] if stage != 'expanded' else [F(3,2),F(2),F(3)]
    count=local=hinges=ledgers=0
    for c0,c1 in product(masks,repeat=2):
      c=(c0,c1)
      for dflat in product(levels,repeat=4):
       d=(dflat[:2],dflat[2:]); m=tuple(F(sum(x)) for x in c)
       if any(sum(d[i])!=m[i] for i in range(2)): continue
       for alpha in product(weights,repeat=2):
        if any(sum(alpha[i]*c[i][x] for i in range(2))>1 for x in range(2)): continue
        for bflat in product((0,1),repeat=4):
         b=(bflat[:2],bflat[2:])
         if any(b[i][x]>c[i][x] for i in range(2) for x in range(2)): continue
         for R in rs:
          for hmode in (0,1):
           s=[F(max([d[i][x] for i in range(2) if c[i][x]] or [0])) for x in range(2)]
           h=[min(O,R*v) if hmode else Z for v in s]
           L=[sum(alpha[i]*c[i][x] for i in range(2)) for x in range(2)]
           w=[sum(alpha[i]*b[i][x] for i in range(2)) for x in range(2)]
           rx=[F(max([d[i][x] for i in range(2) if alpha[i]>0 and b[i][x]] or [0])) for x in range(2)]
           for x in range(2):
            assert 0<=h[x]<=1 and s[x]>=h[x]/R and L[x]<=1 and 0<=rx[x]<=s[x]
            lhs=s[x]-sum(alpha[i]*d[i][x]*c[i][x] for i in range(2))
            split=s[x]*(1-L[x])+sum(alpha[i]*(s[x]-d[i][x])*c[i][x] for i in range(2))
            assert lhs==split and lhs>=h[x]/R*(1-L[x])+w[x]*(s[x]-rx[x]); local+=1
           # Two singleton packages: q_{\{i\}}=D_i, so e_i is the mass outside C_i.
           for e0,e1 in [(sum(F(d[i][x])*(1-c[i][x]) for x in range(2)) for i in range(2))]:
            assert e0<=m[0] and e1<=m[1]
            r=e0+e1; u=r-alpha[0]*e0-alpha[1]*e1
            assert u>=0
            M=sum(m); B=sum(s)+r; Q=sum(alpha[i]*m[i] for i in range(2))
            if Q>min(B,M): continue
            Bstar=min(B,M); delta=pos(B-M); T=M-Bstar
            J=sum(w[x]*(s[x]-rx[x]) for x in range(2))+u
            H=sum(h)
            assert B-Q==sum(s[x]-sum(alpha[i]*d[i][x]*c[i][x] for i in range(2)) for x in range(2))+u
            assert sum(L)==Q and R*(B-Q)>=H-Q+R*J
            a=R/(R-1); X=H-Bstar-R*delta+R*J
            assert R*(Bstar-Q)>=a*pos(X); hinges+=1
            # Algebraic ledger with κ=4, ε=4/R, V=1/8, Ffill=1/4.
            V=F(1,8); lam=F(55,16); overlap=F(0); fill=F(1,4)
            if H<lam*V-overlap: continue
            Ehi=F(2); Elo=F(3); A=F(1); eps=F(4)/R
            K=2*overlap+R*delta; Klo=-F(3,2)*A/eps; Khi=K-Klo
            assert eps*R==4 and Klo<=Elo-F(3,2)*A/eps
            P=fill+R*T+a*pos(X)-(lam*V-overlap-M-R*delta)
            assert P>=fill+(R+1)*T+(H-lam*V+overlap)+R*J>=0
            D=Ehi+Elo-overlap+fill+R*(M-Q)
            target=Ehi+lam*V-M-Khi+F(3,2)*A/eps+P
            assert D>=target
            ledgers+=1; count+=1
    return dict(stage=stage,local_cell_checks=local,hinge_cases=hinges,complete_ledger_cases=ledgers)
if __name__=='__main__':
 import sys
 print(json.dumps(run(sys.argv[1]),sort_keys=True))
