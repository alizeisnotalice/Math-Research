# Far-credit rational audit

Frozen plan: `PLAN.md`. Run `python3 check.py initial`, `python3 check.py boundary`, `python3 check.py expanded`. Executed 2026-10-29 04:52 UTC, CPython 3.15.0, `fractions.Fraction` (standard library, no floating point). Counts are exact; stages overlap.

| stage | local cell checks | hinge cases | complete ledger cases |
|---|---:|---:|---:|
| initial | 1,856 | 928 | 408 |
| boundary | 9,984 | 4,992 | 2,376 |
| expanded | 29,952 | 14,976 | 7,128 |

Independent algebra: setting S=∫(s−ΣαD 1_C), singleton or general packages give B−Q′=S+U by ∫D_k=m_k. The exact local split is s(1−L)+Σα(s−D)1_C. Because B′⊂C, the receiver terms contribute at least w(s−s_rx), and s≥h/R yields the stated slack. With h≤1, ∫hL≤∫L=Q′; hence R(B−Q′)≥H−Q′+RJ. Substitute B=B_*+δ: (R−1)(B_*−Q′)≥X=H−B_*−Rδ+RJ. Since B_*−Q′≥0, R(B_*−Q′)≥a_R X_+.

For P+, a_R≥1 implies a_R X_+≥X; substitute B_*=M−T to obtain P+≥F+(R+1)T+(H−ΛV+O)+RJ≥0. In the full ledger, R(M−Q′)=RT+R(B_*−Q′), the hinge is used once, and 2O+Rδ=K_L+K_H with K_L≤E_low−3A_L/(2ε) gives the stated target. This is an algebraic check conditional on the report's hypotheses, not an independent proof of those hypotheses.

The finite fixtures enumerate two unit cells and two rows, eligible/receiver incidence, nonnegative integral densities and rational packing weights; |C_i|=m_i=∫D_i. Their actual return masses arise from the two singleton packages q_{\{i\}}=D_i; their U is nonnegative. They check all hypotheses used by the local inequality, hinge, and algebraic ledger, including εR=κ=4 and the density-cap inequality when applicable. The ledger fixtures assign E_low, E_high, A_L, V and F independently subject to the ledger inequalities; they do not construct the report's growth/transport data or enforce the original geometric definitions. Singleton packages do not exercise a nontrivial multi-row package. No global cubes, full μ, or theorem are established by the enumerated fixtures.

SHA-256: PLAN.md `6e37252f97b0edb14197abcd0c2b47002a88b5ca236f9e1b6e881de695a1b2eb`; check.py `64e0fb2ee16e3de15e2188202db88718a621d9b9599234de16ba28f68a0966d9`; historical pre-integration report snapshot (not the final report binding) `22cc90272b8d797cdd7bf92a9603547f5bdee71566ea98a2e62633ccf1db2497`.

Main-agent reproduction: all three stages subsequently executed with the requested local Python 3.12.14 interpreter; exact counts agree. See results.json for executable, script hash and measured per-stage wall times. This verifies reproducibility, not the missing global geometric bridge.

The final report is independently bound by FINAL_LEDGER_AUDIT.md and FINAL_GEOMETRY_AUDIT.md to SHA-256 a3d7aa053f960175a6675cf7e376ad3ec9af2f9064a408da6f865f6a1e6d4910. The earlier snapshot hash above is deliberately preserved as historical provenance; it is not evidence of checking a later file.
