# Frozen plan

1. Implement an independent exact-rational finite atomic model of two rows and two unit-measure cells. Enumerate nonnegative densities, receiver subsets of eligible cells, admissible packing weights, and capped h.
2. Check all local assumptions, the exact B−Q′ identity, its slack decomposition and strengthened local bound; independently check return slack, the hinge, P+ and the complete ledger when their hypotheses hold.
3. Execute initial, boundary and expanded stages separately and report exact counts and reproducibility metadata. The finite model is algebraic only; it does not construct the global cube geometry, μ, or prove the theorem.
