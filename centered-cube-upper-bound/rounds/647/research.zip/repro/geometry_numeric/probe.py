from fractions import Fraction as F
import json, platform, hashlib

def q(x): return str(x)
def run(n, stage):
 a=32*n
 lo=F(1)+F(1,10*n if stage=='initial' else 10000*n)
 hi=F(6) if stage!='stress' else F(20)
 t=[lo,hi,hi+1]
 rho=[F(1),F(1),F(1)] if stage!='stress' else [F(1),F(3,4),F(1,2)]
 s=[rho[i]/t[i] for i in range(3)]
 u=[z**n-1 for z in t]
 d=[(2*z)**n for z in s]
 # v0/v1+v2 makes harmonic mean of u equal 4.
 ratio=(F(1,4)-(1/u[1]+1/u[2])/2)/(1/u[0]-F(1,4))
 vraw=[ratio,F(1,2),F(1,2)]
 # Rectangular old pieces: common narrow widths on n-1 axes, first widths proportional to vraw.
 delta=F(1,1000*a)
 widthscale=delta/(100*(hi+3)*max(vraw))
 widths=[widthscale*x for x in vraw]
 h=F(1,10000*a)
 v=[w*h**(n-1) for w in widths]
 y=[F(0),delta,delta*(1+hi)/(2+hi)]
 X=[F(0)]*3
 assert all(y[i]<=s[i] and widths[i]/2<=s[i]/a and (n==1 or h/2<=s[i]/a) for i in range(3))
 assert all(abs(y[i]-y[j])>(widths[i]+widths[j])/2 for i in range(3) for j in range(i+1,3))
 # Choose eps so all old A overlap at 0 and sum lambda is exactly one.
 eps=1/sum(v[i]/(u[i]*d[i]) for i in range(3))
 lam=[eps*v[i]/(u[i]*d[i]) for i in range(3)]
 m=[d[i]*(1+u[i]) for i in range(3)]
 mass=[lam[i]*m[i] for i in range(3)]
 V=sum(v); Q=sum(lam[i]*d[i] for i in range(3)); M=sum(mass)
 kap=eps*V/Q
 assert kap==4 and all(m[i]==d[i]+eps*v[i]/lam[i] for i in range(3))
 assert sum(lam)==1
 b=[(z-1)/2 for z in t]; c=[(1+b[i])*y[i] for i in range(3)]
 edges=[(j,k) for j in range(3) for k in range(3) if j!=k and rho[k]<=rho[j] and abs(c[j]-c[k])<= (rho[j]+rho[k])/a]
 assert edges
 e_collisions=[(j,k) for j in range(3) for k in range(j+1,3) if abs(c[j]-c[k]) <= (t[j]*widths[j]+t[k]*widths[k])/2]
 assert e_collisions
 # Box is centered on y_k, and X_j=0; inclusion is coordinatewise exact.
 margins=[(1+F(1,a))*rho[j]-(abs(y[k])+widths[k]/2) for j,k in edges]
 margins += [(1+F(1,a))*rho[j]-h/2 for j,k in edges] if n>1 else []
 assert min(margins)>=0
 P0=(1+F(1,a))**n
 budgets=[]; loads=[]
 for j in range(3):
  ks=[k for jj,k in edges if jj==j]
  budgets.append((sum(v[k] for k in ks),P0*m[j]))
  loads.append((sum(lam[jj] for jj,k in edges if k==j),F(1)))
 assert all(x<=y for x,y in budgets+loads)
 # Actual product flow upper bound with directed edges, including correct n-th power d and P0.
 lhs=sum(u[k]*lam[j]*mass[k] for j,k in edges)/eps
 eg=sum(v[i]*(u[i]-kap)**2/u[i] for i in range(3))
 rhs=eg+P0*(1+2*kap)*M
 assert lhs<=rhs
 return {'n':n,'stage':stage,'edges':len(edges),'transformed_piece_collisions':len(e_collisions),'kappa':q(kap),'min_coordinate_margin':q(min(margins)), 'volume_budget_max_ratio':q(max((x/y for x,y in budgets),default=0)), 'reverse_lambda_max':q(max(x for x,y in loads)), 'lhs_over_rhs':q(lhs/rhs), 'u_min':q(min(u)),'u_max':q(max(u))}

rows=[run(n,stage) for stage in ('initial','edge','stress') for n in (1,2,3,7,16,32)]
# Separate near-sharp inclusion: y_k=s_k, X_j=0, rho_k=1, t_k>1.
near=[]
for n in (1,2,3,7,16,32):
 a=32*n;t=1+F(1,10**6*n); s=1/t
 gap=(1+F(1,a))-(s+s/a)
 assert gap>0
 near.append({'n':n,'near_boundary_gap':q(gap)})
print(json.dumps({'python':platform.python_version(),'fixtures':rows,'separate_near_boundary':near},indent=2))
