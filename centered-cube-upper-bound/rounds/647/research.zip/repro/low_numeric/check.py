#!/usr/bin/env python3
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json,time,resource,sys
import sympy as S
start=time.perf_counter();cpu=time.process_time();u,k=S.symbols('u k',positive=True);h=(u-k)**2/(1+u)-(2*u+k+S.Rational(3,2));decomp=(k-S.Rational(7,2))*(k+1)+(S.Rational(1,2)-u)*(3*k+4+u)
assert S.simplify((1+u)*h-decomp)==0
assert S.simplify(S.diff(decomp,u)-(-3*k-S.Rational(7,2)-2*u))==0 and S.simplify(S.diff(decomp,k)-(2*k-1-3*u))==0
# First identity from actual m=d+eps*v/lambda and u=eps*v/(lambda*d).
eps,lam,d,v=S.symbols('eps lam d v',positive=True);uu=eps*v/(lam*d);m=d+eps*v/lam
assert S.simplify(lam*m-eps*(1+uu)*v/uu)==0
# Exact full-sum identity eps*Egrow = sum lambda*m*(u−kappa)^2/(1+u).
q1,q2,v1,v2=S.symbols('q1 q2 v1 v2',positive=True);Q=q1+q2;V=v1+v2;kap=eps*V/Q;us=[eps*v1/q1,eps*v2/q2];q=[q1,q2];vs=[v1,v2];
rhs=sum(q[i]*(1+us[i])*(us[i]-kap)**2/(1+us[i]) for i in range(2));egrow=eps*(v1*v1/q1+v2*v2/q2-V*V/Q)
assert S.factor(rhs-eps*egrow)==0
phases=[('initial',[(kk,uu) for kk in (F(7,2),F(4)) for uu in (F(1,10),F(1,4),F(1,2))]),('boundary',[(kk,uu) for kk in (F(7,2),F(7,2)+F(1,10**6),F(4)) for uu in (F(1,2),F(1,2)-F(1,10**6),F(1,2)-F(1,10**9))]),('wide',[(kk,uu) for kk in (F(7,2),F(18,5),F(37,10),F(15,4),F(19,5),F(39,10),F(4)) for uu in [*(F(1,10**i) for i in range(1,10)),F(1,2)]])]
stages=[]
for name,pts in phases:
 rows=[]
 for K,U in pts:
  assert 0<U<=F(1,2) and F(7,2)<=K<=4
  N=(K-F(7,2))*(K+1)+(F(1,2)-U)*(3*K+4+U);H=(U-K)**2/(1+U)-(2*U+K+F(3,2));assert N==(1+U)*H and H>=0
  rows.append({'kappa':str(K),'u':str(U),'h':str(H),'numerator':str(N)})
 stages.append({'name':name,'count':len(rows),'rows':rows})
# Positive rational two-row full-growth audit: low-u row and high-u row coexist.
e=F(1,10);qs=[F(1),F(3)];us=[F(1,4),F(19,4)];vv=[qs[i]*us[i]/e for i in range(2)];kap=e*sum(vv)/sum(qs);assert kap==F(29,8)
A=[qs[i]*(1+us[i]) for i in range(2)];V=sum(vv);Q=sum(qs);E=e*(sum(vv[i]**2/qs[i] for i in range(2))-V**2/Q);lhs=e*E;rhs=sum(A[i]*(us[i]-kap)**2/(1+us[i]) for i in range(2));assert lhs==rhs and lhs>0
out={'symbolic':{'nonnegative_numerator':str(decomp),'du':str(S.diff(decomp,u)),'dk':str(S.diff(decomp,k)),'aj_identity':'residual=0','growth_identity':'residual=0'},'stages':stages,'rational_growth_example':{'epsilon':str(e),'q':list(map(str,qs)),'u':list(map(str,us)),'v':list(map(str,vv)),'kappa':str(kap),'a':list(map(str,A)),'epsilon_Egrow':str(lhs)},'run':{'python':sys.version,'sympy':S.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}}
print(json.dumps(out,indent=2))
