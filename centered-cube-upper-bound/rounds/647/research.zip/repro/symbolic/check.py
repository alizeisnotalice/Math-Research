#!/usr/bin/env python3
import sys, platform, time, hashlib
from fractions import Fraction as F
import sympy as s
start=time.perf_counter()
print('python:',sys.executable,sys.version.replace('\n',' '))
print('platform:',platform.platform(),'sympy:',s.__version__)
print('script_sha256:',hashlib.sha256(open(__file__,'rb').read()).hexdigest())
u,k,e,a,Q,M,V,E=s.symbols('u k epsilon a Q M V E', nonzero=True)
R,T,H,Lam,O,delta,Bstar,fill,ar,x,z,h,K,CL,c=s.symbols('R T H Lambda O delta Bstar fill aR x z h K CL c')
checks={}
def check(name,expr):
    val=s.factor(expr); checks[name]=val
    assert val==0,(name,val)
    print(name,':',val)
low=(u-k)**2-(1+u)*(2*u+k+s.Rational(3,2))
low_fact=(k-s.Rational(7,2))*(k+s.Rational(5,2)-3*u)+(s.Rational(1,2)-u)*(u+s.Rational(29,2))
check('low_factorization',low-low_fact)
v=u*a/(e*(1+u))
check('v_growth_identity',v*(u-k)**2/u-a/e*(u-k)**2/(1+u))
check('child_exact_remainder',1+u-(1+2*k+(u-k)**2/u-k**2/u))
# Algebra for arbitrary finite sums: sum(a/(1+u))=Q and sum(a)=M.
S=s.symbols('S')
check('growth_division',(u-k)**2/(1+u)-(u-(1+2*k)+(1+k)**2/(1+u)))
check('sum_ua_identity', (e*E+(1+2*k)*M-(1+k)**2*Q).subs(e*E,S-(1+2*k)*M+(1+k)**2*Q)-S)
check('normalization_reduction',((1+2*k)*M-(1+k)**2*Q-k*M).subs(M,(1+k)*Q))
check('mass_normalization',(Q+e*V-(1+k)*Q).subs(e*V,k*Q))
check('ledger_x_minus_z',(H-Bstar-R*delta)-(Lam*V-O-M-R*delta)-((H-Lam*V+O)+(M-Bstar)))
# Abstract positive part p=[x]+, n=[-x]+, so x=p-n.
p,neg=s.symbols('p neg')
check('positive_part_exact_gap',ar*p-(p-neg)-((ar-1)*p+neg))
P=fill+R*T+ar*p-(Lam*V-O-M-R*delta)
original=E-O+fill+R*T+ar*p
Kdef=2*O+R*delta
check('full_ledger_rearrangement',original-(E+Lam*V-M-Kdef+P))
EH,KH,SL=s.symbols('EH KH SL')
check('final_coefficient',(EH+Lam*V-M+SL-(EH+(Lam-c)*V+SL+(CL-1)*M))-(c*V-CL*M))
print('boundary low residual:',low.subs({u:s.Rational(1,2),k:s.Rational(7,2)}))
print('boundary child exact remainder:',(-k**2/u).subs({u:s.Rational(1,2),k:s.Rational(7,2)}))
print('boundary high packing factor (1+u)/u:',((1+u)/u).subs(u,s.Rational(1,2)))
# Targeted exact rational grid; no matching or configuration enumeration.
ks=[F(i,8) for i in range(28,33)]
us=sorted({F(i,j) for j in range(1,13) for i in range(1,10*j+1)}|{F(1,2)})
count=0
for K0 in ks:
 for U in us:
  residual=(U-K0)**2-(1+U)*(2*U+K0+F(3,2))
  fac=(K0-F(7,2))*(K0+F(5,2)-3*U)+(F(1,2)-U)*(U+F(29,2))
  assert residual==fac
  if U<=F(1,2): assert residual>=0
  assert 1+U==1+2*K0+(U-K0)**2/U-K0**2/U
  if U>F(1,2): assert (1+U)/U<3
  count+=1
print('targeted rational grid:',len(ks),'kappa x',len(us),'u =',count,'pairs; passed')
print('elapsed_seconds:',round(time.perf_counter()-start,6))
