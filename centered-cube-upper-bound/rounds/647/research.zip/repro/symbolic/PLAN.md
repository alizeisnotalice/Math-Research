# Frozen verification plan

1. Symbolically verify the low residual decomposition and its positivity factors on 0<u<=1/2, 7/2<=kappa<=4, and the per-label growth identity.
2. Verify the full same-action P ledger algebra, x-z=h+T, its exact positive-part gap, and the final coefficient CL-1, retaining all credits. Treat inequalities as assumptions, not symbolic proof of geometry.
3. Verify the exact child product remainder and derive sum u a=epsilon E+ kappa M from M=(1+kappa)Q and epsilon V=kappa Q. Verify the high-child parent-price packing factor and resulting combined coefficient, without inferring matching domination.
4. Check the boundary u=1/2,kappa=7/2 exactly; then perform a targeted rational grid on these identities and inequalities only, no matching enumeration. Record interpreter, versions, command, script hash, and execution time. Deliver script, output, and concise README; no claim of general bound closure.
