"""Archive consistency only; does not prove the open geometric estimate."""
from pathlib import Path
import ast, hashlib, json, re, subprocess, sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'}
assert actual==set(manifest['files']), (actual-set(manifest['files']),set(manifest['files'])-actual)
for name,digest in manifest['files'].items():
 p=ROOT/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
s=(ROOT/'REPORT.tex').read_text();stack=[]
for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',s):
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env,(kind,env)
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
assert all(ord(c)>=32 or c in '\n\t' for c in s)
assert '^{,2}' not in s
# Small, portable assertions only; never rerun the whole graph enumeration here.
checks=[('repro/low_numeric/check.py',[]),('repro/matching_independent/check.py',[]),('repro/matching_independent/audit_author.py',[]),('repro/symbolic/check.py',[]),('repro/geometry_numeric/probe.py',[]),('repro/far/check.py',['initial']),('repro/far/check.py',['boundary']),('repro/far/check.py',['expanded'])]
for name,args in checks:
 result=subprocess.run([sys.executable,'-B',str(ROOT/name),*args],cwd=ROOT/name.rsplit('/',1)[0],capture_output=True,text=True,check=True)
 print('PASS',name,*args)
print('PASS manifest',len(actual),'files; LaTeX structure',len(labels),'labels; Python syntax; eight bounded replay commands')
print('NO claim of general weak-type theorem, global geometric bridge, Arb execution or PDF compilation.')
