# R647 signed transport score 的低 incoming 支付独审

先独立审题给命题，再定点对照 `/tmp/ccu_r647/transport.md`。仅写本文件，不改他人文件或仓库。

**独立结论：signed transport、product-anchor 条件积分与增长方差恒等式成立；\(u_j\le1/2\) 的全部 incoming score 能由其增长方差份额支付，且留下 \(3a_j/(2\epsilon)\) 信用。这是实际分项支付，不只是重写恒等式。它不删除低 target 行，也未支付高 incoming 的完整剩余项，故不能认证全 \(F\)。**

## 1. 同次 \(Z\) 的 signed 精确分解

固定一次完整动作 \(Z\)。所有旧行参与 \(s_Z\) 和返回最大值。取可测的固定序 tie-breaking：\(a_Z(K)\in K\) 最大化积分逃逸量，\(b_Z(y)\) 在 \(y\in C_k\) 的全部旧行中最大化 \(D_k(y)\)。无 row 可接收时可取 dummy 标签；该区域 \(\sum_Kq_K=0\)，不影响积分。

由于 \(s_Z(y)=\sum_K1_{\{b_Z(y)\in K\}}q_K(y)\)，而返回质量为 \(\sum_K\int 1_{C_{a_Z(K)}^c}q_K\)，

\[
B-M=\sum_K\int q_K(y)
 [1_{\{b_Z(y)\in K\}}+1_{\{y\notin C_{a_Z(K)}\}}-1],dy.
\]

括号精确等于题给的两项 signed 指标差。插入 \(q_K=z_K\sum_{j\in K}\lambda_j1_{E_j}/\ell_j\)，得到

\[
B-M=\sum_K z_K\sum_{j\in K}\lambda_j s_{Kj},\qquad -1\le s_{Kj}\le1.
\]

\(a_Z(K)\)、\(b_Z(y)\)、\(f_j(Z)\) 均可适应完整同一次动作。它们无需独立；也不能按 \(K,j\) 另选更有利动作。这里是先逐包积分后选最坏 target，不是将逐点最坏逃逸错误积分。

令 \(\eta(Z)=1_{\{B>M\}}\)、\(\pi(K\mid j)=z_K/m_j\)（仅 \(K\ni j\)）。完整旧矩使其总和为一，故

\[
\mathcal K(Z):=2O+R(B-M)_+
=\frac1\epsilon\sum_j a_j
 \left[2u_jf_j+\kappa\eta\sum_{K\ni j}\pi(K\mid j)s_{Kj}\right].
\tag{1}
\]

这里 \(a_j=\lambda_jm_j>0\)、\(\ell_j=u_ja_j/\epsilon\)，\(O=\sum_j\ell_jf_j\)。\(\eta\) 必须留在和式内，对正部不交换期望、不逐包取正部。各 incoming 分项可以为负，只有完整 \(\mathcal K\) 必然非负。

## 2. 共同 product anchors 的积分与有限性

在固定最优分配 \(\gamma\) 后，全部 anchors 按同一个乘积律取样，\(X_j\sim\gamma_j/a_j\)。\(\theta_j=d\gamma_j/d\mu\)、\(\sum_j\theta_j=1\) 仅描述这份共同输入分解。

对(1)中第 \(j\) 项，先冻结 \(X_j=x\)，再对全部其余 anchors 取真实条件积分，得到准确题给式

\[
\mathbb E\mathcal K
=\frac1\epsilon\int\sum_j\theta_j(x)
\mathbb E_{-j}\!\left[
2u_jf_j+\kappa\eta\sum_{K\ni j}\pi(K\mid j)s_{Kj}
\right]d\mu(x).
\tag{2}
\]

\(\mathbb E_{-j}\) 的 integrand 中，所有适应性选择仍使用 \(X_j=x\) 与同一批其他 anchors；不能将 \(\eta\)、\(a_Z(K)\) 或 \(b_Z\) 再独立取样。因为有限 \(N\)、固定 \(u_j\) 且 \(f_j\in[0,1]\)、\(|\sum\pi s|\le1\)，每项绝对值至多 \(2u_j+\kappa\)，总积分有限。故 signed Fubini合法；若援引 Tonelli，须先分别处理正负部，二者在此都有限。任意所选 loss partition/optimizer 必须可测；有限 incidence 上固定 tie-breaking 足以支撑本式。

增长方差份额为

\[
E_j=\frac{a_j}{\epsilon}\frac{(u_j-\kappa)^2}{1+u_j},\qquad
E_{\rm grow}=\sum_jE_j.
\]

由 \(\int\theta_jd\mu=a_j\)，题给 \(\epsilon E_{\rm grow}\) 积分式精确成立，不要求 \(\theta_j\) 与几何损失独立。

## 3. 低 incoming 的实际支付

对 \(0<u\le1/2\)、\(7/2\le\kappa\le4\)，有

\[
\begin{aligned}
&(u-\kappa)^2-(1+u)(2u+\kappa+3/2)\\
&=(\kappa-7/2)(\kappa+5/2-3u)
 +(1/2-u)(u+29/2)\ge0.
\end{aligned}
\]

因此 \((u-\kappa)^2/(1+u)\ge2u+\kappa+3/2\)。这不是概率估计。对每一次实际 \(Z\)，\(\eta\sum\pi s\le1\)、\(f_j\le1\)，故对于所有低 incoming 行

\[
\frac{a_j}{\epsilon}
\left[2u_jf_j+\kappa\eta\sum\pi s\right]
\le E_j-\frac{3a_j}{2\epsilon}.
\tag{3}
\]

该完整分项包含其 raw collision 份额及 signed 最坏返回份额；即使两者和式为负，方向仍成立。不需先取期望、不需 swap 收益或谱隙。边界 \(u=1/2,\kappa=7/2\) 保留，标量证书在那里取等。

这是按 incoming 片标签 \(j\) 的支付：**所有低 target 行仍参与 \(a_Z(K)\)、\(b_Z\) 和完整需求。** 高 incoming 的运输可以逃离某个低 target，该费用仍在高 incoming 剩余中，不能借此删掉或声称全部低 target 返回已消失。

## 4. 完整账回代与准确未付项

设 \(L=\{j:u_j\le1/2\}\)、\(G=L^c\)，\(A_L=\sum_{j\in L}a_j\)，并将(1)按 incoming 分成 \(\mathcal K_L+\mathcal K_G\)。由(3)，

\[
\mathcal K_L\le E_L-3A_L/(2\epsilon).
\]

若沿用 R646 已审同次完整下界
\(D\ge E_{\rm grow}+\Lambda_\kappa V-M-\mathcal K\)，则每次即有

\[
D\ge E_G+\Lambda_\kappa V-M
  +\frac{3A_L}{2\epsilon}-\mathcal K_G.
\tag{4}
\]

取同一个乘积 law 的期望也成立。支付消耗的是 \(E_L\)；不得再把该增长份额单独加回其他费用账。\(\mathcal K_G\) 仍是带同次 \(\eta\)、最坏 target 及全部共成员关系的 signed 高 incoming score，没有被免费取正或丢弃。

例如要由(4)得到 \(\mathbb ED\ge V/2-M\)，尚须证明

\[
\mathbb E\mathcal K_G
\le E_G+(\Lambda_\kappa-1/2)V+3A_L/(2\epsilon).
\]

现有低 incoming 证书没有证明此式；尤其所有 \(u_j>1/2\) 的分支完全保留。故本轮确有统一的低 incoming 实际支付，但不能据此报告一般根阶界或完整 \(F\) 已证。

本机 SymPy 只核上述非负分解恒等式残差为零及边界取等；未进行数值扫描。严格支付由(3)的逐次界证明。

## 5. 作者稿对照及保留全部指定信用

作者稿落盘后已定点核验：(1)–(8)的 signed cut、全局正部选择、incoming 分解、普通条件积分及低支逐次支付与独立证明一致。\(\pi(K\mid j)=z_K/m_j\) 是旧 \(q_K\) 分解的固定混合权，不应再理解为给定新 anchor \(X_j=x\) 后的物理包 posterior；作者未作该替换，且明确不改 \(q_K\)。

作者§4新增的同次信用 \(\mathcal P_Z\) 也准确。令 \(a_R=R/(R-1)>1\)、\(x=H_Z-B_*-R\delta\)，并定义

\[
\mathcal P_Z=F_{\rm fill}+RT+a_R[x]_+
 -(\Lambda V-O-M-R\delta).
\]

因为 \(a_R[x]_+\ge x\)、\(M-B_*=T\)，有

\[
\mathcal P_Z\ge F_{\rm fill}+(R+1)T
 +(H_Z-\Lambda V+O)\ge0.
\]

这使用 R646 剥离下界的明示 \(R>1\) 前提。代数回代得到作者准确的

\[
D\ge E_G+\Lambda V-M-\mathcal K_G
 +3A_L/(2\epsilon)+\mathcal P_Z.
\]

因而本文件(4)是较保守下界，不能用它的粗 score 失控来否定保留 \(\mathcal P_Z\) 的完整账。作者最终保留 \(\mathcal P_Z\) 的真实定义值，未将 fill、\(RT\)、精确 \(H_Z\) 或正部免费丢失。尚未纳入下界的非负 actual 剩余亦不能反向作为负费；这里始终是下界而非把余量设零的等式。

作者(11)对 \(\mathbb E[\mathcal K_G-\mathcal P_Z]\) 的充分估计，连同 \((CL_n-1)M\) 系数，回代确得 \(\mathbb ED\ge cV-CL_nM\)。该估计尚未证明。作者§5对自适应 target 边缘、交叉 eligibility 及 supply owner 与 receiver owner 不同的限制表述准确，没有将交换不等式外推到不合法对象。

**最终判定：所审一般 signed 身份与低 incoming 实际支付通过，作者保留全部指定同次信用后的归并亦通过；高 incoming 联合几何仍未支付，不认证全 \(F\)。审核完成停止。**
