# R647 final independent audit of the complete ledger and actual far-source credit

**Verdict: PASS for the stated finite-contract identities, inequalities, and sufficient reduction; the general upper bound and the remaining physical/unweighted bridge remain unproved.** No mathematical correction to the final section 3 is required.

This audit owns only this file. I did not modify REPORT.tex, other workers' files, Git state, or any PDF. I independently derived the new section 3 argument and its full-ledger substitution before reading `/tmp/ccu_r647/LEDGER_AUDIT.md`; that earlier audit covers the predecessor credit and does not itself certify the new far-source theorem. I then compared the inherited definitions and density proof in `/tmp/ccu_r646_final/REPORT.tex`.

The final complete byte read of `/tmp/ccu_r647_final/REPORT.tex` had **26912 bytes** and SHA-256:

`a3d7aa053f960175a6675cf7e376ad3ec9af2f9064a408da6f865f6a1e6d4910`

This verdict binds that snapshot, including the explicit self-row proof of `s >= h/R`, the defined product quantity `Y_H`, the final `mathcal N_j` notation, and the accurately separated Python 3.15.0 / 3.12.14 far-credit certificate provenance. The final numerical addendum does not enlarge the mathematical claims certified by this audit. A subsequent edit requires rebinding the audit.

## 1. All-old transport is preserved, including deleted rows

The original packet identities imply
\[
\sum_Kz_K=\sum_Kz_K\sum_{j\in K}\lambda_j
=\sum_j\lambda_jm_j=M.
\]
Therefore the definitions using **all** old labels give
\[
\int q_K=z_K,\qquad \int D_k=m_k,\qquad
\int s\le\int\sum_Kq_K=M.
\]
For the last inequality, at any point with an available maximizing row, `D_k` is a sub-sum of the nonnegative `q_K`; outside all `C_k`, all `q_K` vanish because every `E_j` lies in `C_j`. Thus an arbitrary convention for an empty maximizing index contributes nothing. Returns satisfy `0 <= r_K <= z_K`, so `B <= 2M`. The source covers every old demand, including eventual zero-owner/deleted rows, exactly as in R646. The actual retained optimizer is extended by zero to these rows; consequently
\[
Q'=\sum_k\alpha_km_k,\qquad 0\le Q'\le B_*:=\min(B,M).
\]
No source or row is silently discarded when the new receiver set is formed.

The signed return/merge decomposition also survives unchanged. With the integrated return maximizer `a_Z(K)` and the supply maximizer `b_Z(y)`,
\[
B-M=\sum_K\int q_K\left(1_{b\in K}+1_{y\notin C_{a(K)}}-1\right).
\]
The displayed two-indicator identity in REPORT.tex is exact. Substitution of `q_K` gives
\[
\mathcal K=2O+R(B-M)_+
=\epsilon^{-1}\sum_ja_j\bigl(2u_jf_j+\kappa\eta\bar s_j\bigr).
\]
Here `eta` is one common action-dependent scalar. Individual input components remain signed; taking their positive parts separately would change this identity. The mixture `z_K/m_j` is the original old-source mixture, with no anchor posterior substitution.

## 2. The density lower bound genuinely belongs to s

This is stronger provenance than merely knowing `tau >= h/R dy`. For `y in E_j`, the self-row terms in `D_j` give directly
\[
D_j(y)\ge\sum_{K\ni j}z_K\lambda_j/\ell_j
=\lambda_jm_j/\ell_j=\epsilon/u_j
=\kappa/(Ru_j).
\]
Since `E_j subset C_j`, this row is eligible for the definition of `s`. Consequently
\[
s(y)\ge R^{-1}\min(1,\kappa/u_j)1_{E_j}(y)
\]
for every old label, and maximizing over `j` proves `s >= h/R`. No returned packet is used in this argument. This is exactly the premise needed for the new split of the **continuous** slack.

For completeness, the inherited `H_Z >= Lambda V - O` follows from the old harmonic identity `sum v_j/u_j = V/kappa` and
\[
\min(1,\kappa/u)(1+u)-\kappa+\frac{(\kappa-1)^2}{4u}
=\begin{cases}(2u-\kappa+1)^2/(4u),&u\le\kappa,\\
(\kappa+1)^2/(4u),&u\ge\kappa.
\end{cases}
\]
At each physical point, `sum omega_j 1_Ej - max omega_j 1_Ej <= (m_E-1)_+`, since each `omega_j <= 1`. Integration subtracts at most the actual full overlap `O`. This uses no cap on the density of the old auxiliary source.

## 3. Actual alpha, packet intersections, and nonnegative return credit

For a positive **actual AC old packet**, its common old intersection has positive Lebesgue measure: the packet is a positive submeasure of the AC old source supported there. This AC provenance, inherited from the full contract, is essential; an arbitrary singular probability on a null common intersection would not suffice.

Because `A_k subset C_k`, the common new intersection for that same packet also has positive measure. Outside the null exceptional set of the actual new a.e. packing, every point of that intersection gives
\[
\alpha(K):=\sum_{k\in K}\alpha_k\le1.
\]
Deleted rows have `alpha_k=0`, so the statement applies unchanged to packets containing them. For each packet,
\[
\sum_{k\in K}\alpha_ke_{Kk}\le r_K\alpha(K)\le r_K.
\]
Hence `U_ret >= 0`. This uses the actual retained optimizer, not old `lambda`, a uniform fictitious optimizer, or another ownership.

Since `B'_k subset C_k`, the receiver maximum satisfies `0 <= s_rx <= s`, with empty maximum understood as zero. Also
\[
0\le w=\sum_k\alpha_k1_{B'_k}\le L_\alpha\le1
\]
a.e. Thus `J_far >= 0`. All relevant integrals are finite: `J_far <= int s <= M` and `U_ret <= sum r_K <= M`. These estimates establish finiteness, not a lower bound for unweighted far mass.

## 4. Exact B-Q' identity and the stronger positive part

Using the **all-old** identities `int D_k=m_k`, and then exchanging only finite nonnegative sums,
\[
\sum_k\alpha_km_k
=\int\sum_k\alpha_kD_k1_{C_k}
 +\sum_K\sum_{k\in K}\alpha_ke_{Kk}.
\]
Subtracting this equality from `B=int s+sum r_K` proves exactly
\[
B-Q'=\int\left(s-\sum_k\alpha_kD_k1_{C_k}\right)+U_{\rm ret}.
\]
No inequality or independent source is hidden in this identity.

The continuous integrand is exactly
\[
s(1-L_\alpha)+\sum_k\alpha_k(s-D_k)1_{C_k}.
\]
Both summands are nonnegative a.e. The first is at least `(h/R)(1-L_alpha)`. In the second one may retain only receiver regions `B'_k`; on such a region with `alpha_k>0`, `D_k <= s_rx`. It follows that
\[
s-\sum_k\alpha_kD_k1_{C_k}
\ge(h/R)(1-L_\alpha)+w(s-s_{\rm rx}).
\]
The same `L_alpha` appears throughout, so the density baseline and the far receiver excess use distinct nonnegative summands of one exact slack decomposition. They are not two independently spent copies of `B-Q'`.

Since `0<=h<=1` and `int L_alpha=sum alpha_k |C_k|=Q'`, integration yields
\[
R(B-Q')\ge H_Z-\int hL_\alpha+RJ
\ge H_Z-Q'+RJ.
\]
Set `delta=(B-M)_+`, `B_*=min(B,M)`. The identity `B=B_*+delta` holds on both sides of `B=M`. Rearrangement gives
\[
(R-1)(B_*-Q')\ge X,
\quad X:=H_Z-B_*-R\delta+RJ.
\]
Because `B_*-Q'>=0` and `R>1`, this is precisely
\[
R(B_*-Q')\ge\frac R{R-1}[X]_+.
\]
This certifies the new theorem. The old positive part is recovered by dropping `RJ`, and the new one is at least as large; equality is possible, so the final wording “不小于” is correct.

## 5. Pplus is nonnegative and is used once

Write
\[
T=M-B_*,\quad a_R=R/(R-1),\quad
z=\Lambda V-O-M-R\delta,\quad
\mathcal P_Z^+=F_{\rm fill}+RT+a_R[X]_+-z.
\]
The exact difference between this credit and the lower bound claimed in REPORT.tex is
\[
\mathcal P_Z^+-\left(F_{\rm fill}+(R+1)T+H_Z-\Lambda V+O+RJ\right)
=a_R[X]_+-X\ge0.
\]
The equality uses `B_*=M-T`. The last expression is `-X` when `X<=0`, and `X/(R-1)` when `X>=0`. Because `F_fill,T,H_Z-Lambda V+O,J` are nonnegative, `Pplus>=0` follows.

The full original ledger and the stronger hinge give
\[
D\ge E_{\rm grow}-O+F_{\rm fill}+RT+a_R[X]_+
=E_{\rm grow}+\Lambda V-M-\mathcal K+\mathcal P_Z^+.
\]
Thus `RJ` enters only through the replacement positive part. Although `Pplus` admits the displayed lower bound involving `RJ`, one cannot add another `RJ` to this same lower bound for `D`, or add the old and new peeling positive parts. The final report correctly prohibits that double spending.

## 6. Low input payment and final target coefficient

For `u<=1/2` and `kappa>=7/2`, the stated exact factorization proves
\[
\frac{(u-\kappa)^2}{1+u}\ge2u+\kappa+3/2.
\]
Since `Xi_j<=2u_j+kappa`, it follows for each actual action that
\[
\mathcal K_L\le E_L-\frac{3A_L}{2\epsilon}.
\]
This concerns the original input-piece index. It does not remove low target rows from `D_k`, `s`, returns, the new optimizer, or the receiver maximum. Substitution into the immediately preceding full ledger gives exactly
\[
D\ge E_H+\Lambda V-M-\mathcal K_H
 +\frac{3A_L}{2\epsilon}+\mathcal P_Z^+.
\]
The action law is still the single frozen optimal-source product law. All adaptive actual objects stay inside the same expectation. Its quantities are integrable under the finite contract.

Consequently the final sufficient estimate must have the displayed coefficient
\[
\mathbb E[\mathcal K_H-\mathcal P_Z^+]
\le E_H+(\Lambda-c)V+\frac{3A_L}{2\epsilon}+(CL_n-1)M.
\]
Substitution cancels `E_H`, the low payment, and the existing `-M`, leaving `E D >= cV-CL_n M`. The coefficient `(CL_n-1)M` is correct. Replacing it by `CL_n M` would lose an additional `M`. This is a sufficient unproved condition, not a newly proved estimate or a necessary characterization of every possible successful action.

## 7. The unpaid bridge remains specific and substantial

`J_far` is exactly
\[
\int w(y)(s(y)-s_{\rm rx}(y))\,dy.
\]
It controls this **actual receiver-load-weighted** excess. Neither `w<=1` nor positivity for a fixed retained finite family provides a uniform positive lower bound across all inputs, dimensions, labels, or deletions. Therefore this theorem does not bound an arbitrary unweighted positive cut by `J_far`. A supply maximizer is a row satisfying `y in C_b`; it need not be a receiver at `y in B'_b`, and must not be treated as one. The actual `alpha` weights in `U_ret` also cannot be deleted or replaced by old `lambda`.

The oriented product child budget remains a separate valid budget. Its restricted `Y_H` only debits high-child growth, so it can avoid spending `E_L` a second time. Nevertheless the input label in `K_H` and the child label in `Y_H` differ. A comparison assigning the former to the latter and to `Pplus` is still required. Row/column masses do not imply edgewise domination of physical `f_jk` by `lambda_j a_k` or by the actual transpose flow. Moreover the physical price has **both** endpoints `(u_j+u_k)f_jk/epsilon`, whereas the child budget directly pays only `u_k lambda_j a_k/epsilon`. Ineligible residual loss and the signed return/merge term remain in the full same-action comparison.

The report's parent-price observation is consistent with this stop point: the bound adds `3P_0 epsilon E_grow` to a child coefficient already equal to one, so automatic absorption is not established. The final text does not claim otherwise.

Thus the new actual far-source theorem strengthens the available complete same-action credit but does not close the unweighted/physical bridge, the final sufficient target, or inherited initial/contact/terminal recovery. The final stated “一般非负 L1 根阶上界仍未证明” is the correct outcome.

## 8. Actual local verification and evidence boundary

I used the installed L03 skill only for its exact-residual and evidence-boundary workflow. I actually ran `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (Python **3.12.14**, SymPy **1.14.0**) in a heredoc, without creating a script or changing another file. Seven exact symbolic residuals were zero:

1. low-growth factorization;
2. `Pplus` lower-bound gap on the inactive hinge branch;
3. the same gap on the active hinge branch;
4. the full `D` rearrangement;
5. the low/high combined substitution;
6. the final `(CL_n-1)M` target coefficient;
7. the stronger hinge rearrangement.

The process ended with `PASS 7 exact symbolic residuals`. These are actual algebra checks. No fresh exhaustive graph enumeration, MATLAB, interval-arithmetic certification, PDF compilation, or numerical proof of the missing bridge was performed or claimed. The AC packet argument, all-old provenance, actual-alpha constraints, pointwise receiver split, and uniformity limitations above were audited mathematically rather than inferred from zero symbolic residuals.
