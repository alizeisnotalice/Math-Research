# R647 independent ledger, geometric-budget, and integration audit

Audit scope: `/tmp/ccu_r647/FROZEN.md`, `/tmp/ccu_r647/transport.md`, and the source/peeling definitions of `/tmp/ccu_r646_final/REPORT.tex`. I first checked the identities independently, then compared `/tmp/ccu_r647/LOW_SCORE_AUDIT.md`. No other worker file or Git state was changed.

**Verdict:** the incoming split, low incoming payment, complete credit \(\mathcal P_Z\), and sufficient target (11) are correct under the frozen finite contract and \(R>1\). The new oriented geometric product estimate is also correct. These are compatible only with an explicit allocation of growth credit; unrestricted addition spends low growth twice. Neither result yet proves the missing matching/return bridge or the general bound.

## 1. Incoming split and full same-action credit

Take the measurable choices \(a_Z(K)\) and \(b_Z(y)\) in transport.md. Since
\(s_Z=\sum_Kq_K1_{\{b_Z\in K\}}\),
\[
B-M=\sum_K\int q_K[1_{\{b_Z\in K\}}+1_{\{y\notin C_{a_Z(K)}\}}-1].
\]
The bracket equals the two signed indicators in transport (1). The return maximizer is chosen after the integral, exactly as required by the actual source. Substituting the original \(q_K\) gives (2). The common scalar \(\eta_Z=1_{\{B>M\}}\) gives (3); taking positive parts separately on incoming components would be invalid.

Write
\[
e_j:=\frac{a_j}{\epsilon}\frac{(u_j-\kappa)^2}{1+u_j},\qquad
k_j(Z):=\frac{a_j}{\epsilon}\Xi_j(Z).
\]
Then \(\sum e_j=E_{\rm grow}\), \(\sum k_j=\mathcal K=2O+R\delta\). Each \(k_j\) is signed, and its label is the incoming original piece. It is not the target chosen for the worst return. The same fixed product law permits the conditional integral in (5); finiteness follows from finitely many labels and \(|\Xi_j|\le2u_j+\kappa\). The old mixture \(z_K/m_j\) is not replaced by an anchor-conditioned posterior.

The low certificate is exact:
\[
(u-\kappa)^2-(1+u)(2u+\kappa+3/2)
=(\kappa-7/2)(\kappa+5/2-3u)+(1/2-u)(u+29/2).
\]
Thus for \(L=\{u_j\le1/2\}\), \(H=L^c\), and \(S_L=3A_L/(2\epsilon)\),
\[
\mathcal K_L\le E_L-S_L
\]
for every admissible sampled action. All low target rows remain in the full geometry and source.

For the full credit, put
\[
x=H_Z-B_*-R\delta,\quad z=\Lambda V-O-M-R\delta,
\quad h=H_Z-\Lambda V+O\ge0.
\]
Then \(x-z=h+T\). Since \(a_R[x]_+\ge x\), the actual definition in transport (9) satisfies
\[
\mathcal P_Z=F_{\rm fill}+RT+a_R[x]_+-z
\ge F_{\rm fill}+(R+1)T+h\ge0.
\]
The original same-action peeling lower bound is
\[
D\ge E_{\rm grow}-O+F_{\rm fill}+RT+a_R[x]_+.
\]
Its exact rearrangement is
\[
D\ge E_{\rm grow}+\Lambda V-M-\mathcal K+\mathcal P_Z
\ge E_H+\Lambda V-M-\mathcal K_H+S_L+\mathcal P_Z.\tag{A}
\]
This is a lower bound, not a declaration that all further actual slack vanishes. One must retain the actual value of \(\mathcal P_Z\), including its positive part and exact \(H_Z\).

## 2. Quantifiers and sufficient general hypothesis

All objects in (A), including ownership, deletion, reoptimization, return choices, \(\eta_Z\), \(H_Z\), and fill, belong to the same sampled action. The action law is fixed by one optimal \(\gamma\), before averaging. An estimate on another action or with different source choices cannot be inserted.

Let \(L_n=\sqrt n\,\operatorname{polylog}(n+2)\), with a fixed intended logarithmic exponent. For uniform constants \(c>0,C<\infty\), the remaining sufficient statement is exactly
\[
\boxed{\mathbb E[\mathcal K_H-\mathcal P_Z]
\le E_H+(\Lambda-c)V+S_L+(CL_n-1)M.}\tag{B}
\]
It must hold for every frozen admissible finite input under that same law (or a permitted, explicitly chosen optimal law). Substitution gives \(\mathbb ED\ge cV-CL_nM\), hence some admissible action attains that lower bound. The coefficient is \((CL_n-1)M\): the \(-M\) already present in (A) must be included. This proves only the stated finite-output target; the inherited contact/terminal recovery remains conditional.

(B) is sufficient, not a necessary condition for success of the original method, since (A) may leave further favorable actual slack unused.

## 3. New oriented product estimate: valid proof and exact budget

Let \(N_j(Z)\) be the frozen oriented smaller-radius neighbors. Put
\[
Y(Z)=\epsilon^{-1}\sum_j\sum_{k\in N_j}u_k\lambda_j a_k,
\quad C_0=P_0(1+2\kappa)\le18,
\quad\beta_k(Z)=\sum_{j:k\in N_j(Z)}\lambda_j.
\]
Every \(k\in N_j\) has \(X_j\in A_k\) and \(s_k\le\rho_j\). Thus
\(I_k\subset Q(X_j,(1+1/a)\rho_j)\), and disjointness of the old pieces gives
\[
\sum_{k\in N_j}v_k\le P_0m_j.
\]
Further, \(k\in N_j\) implies \(X_k\in A_j\). Since \(X_k\ll\mu\) and the old load equals one \(\mu\)-a.e.,
\(0\le\beta_k\le1\) simultaneously for all finitely many \(k\), almost surely. No independence of the sets \(N_j\) is used.

Using \(u_ka_k/\epsilon=(1+u_k)v_k\) and
\[
1+u\le1+2\kappa+(u-\kappa)^2/u
\]
gives the sharper pointwise budget
\[
\boxed{Y(Z)\le C_0M+\sum_k\beta_k(Z)e_k\le C_0M+E_{\rm grow}.}\tag{C}
\]
The actual Eulerian transpose \(F_{jk}=\lambda_j\gamma_k(A_j)\) is a valid fixed transport with row and column masses \(a\), and \(F_{jk}\le\lambda_ja_k\). Hence its oriented child-price sum also satisfies (C). This does not turn \(F\), \(\lambda_ja_k\), or their restrictions into the random physical matching.

## 4. Admissible combined ledgers

The low incoming estimate already spends \(E_L\). Therefore one cannot apply \(Y\le E_{\rm grow}+C_0M\) to a second expense and add the two conclusions while keeping only one \(E_{\rm grow}\).

There are three valid integration patterns.

1. **Restrict the new product budget by child label:**
\[
Y_H=\epsilon^{-1}\sum_j\sum_{k\in N_j\cap H}u_k\lambda_ja_k
\le C_0M+\sum_{k\in H}\beta_ke_k\le C_0M+E_H.
\]
Both parent labels and all geometric/return target labels still remain; only the budget's charged child index is restricted. To use this with (A), a sufficient missing bridge is
\[
\mathbb E[\mathcal K_H-\mathcal P_Z-Y_H]
\le (\Lambda-c)V+S_L+(CL_n-1-C_0)M.\tag{D}
\]
Then (B) follows. No such bridge has been proved. It includes any physical costs whose children lie in \(L\); those costs cannot simply be discarded because their incoming labels lie in \(H\).

2. **Split growth credit explicitly:** choose measurable \(0\le\alpha_j(Z)\le1\). Multiplying the low inequality gives
\[
\sum_{j\in L}\alpha_j k_j
\le\sum_{j\in L}\alpha_je_j-
\sum_{j\in L}\alpha_j\frac{3a_j}{2\epsilon}.
\]
Charge a second expense only to \(\sum_j(1-\alpha_j)e_j\). Any uncharged \((1-\alpha_j)k_j\) stays in the residual score. To invoke (C) without double spending, the selected product debit must satisfy \(\beta_j\le1-\alpha_j\), or be restricted/scaled to enforce that rowwise condition. Taking \(\alpha_j=1\) for \(j\in L\) forces zero product variance debit on those children.

3. **Keep exact debits:** use \(\sum\beta_je_j\) from (C), and retain the remaining rowwise amounts \((1-\beta_j)e_j\). A full low incoming payment is admissible only if it actually fits those remaining amounts plus explicitly retained low slack. The slack \(S_L\) may be spent once, by an explicitly proved comparison; it is not another copy of \(E_L\).

These are bookkeeping rules, not proofs that the physical score admits the needed allocation.

## 5. Precise unclosed bridge

The balanced physical collision matching pays
\[
\epsilon^{-1}\sum_{j<k}f_{jk}(u_j+u_k),
\]
with both endpoint prices. After orienting by radius, (C) pays only the smaller-radius endpoint price \(u_k\lambda_ja_k/\epsilon\). There are two independent gaps:

* The physical matching mass \(f_{jk}\) need not be dominated by \(\lambda_ja_k\) or by \(F_{jk}\). Row/column feasibility with marginals \(a\) does not give such edgewise domination.
* Even a bound for the child-price half does not pay the parent-price half \(u_jf_{jk}\). Radius order does not bound \(u_j/u_k\), because the original scales vary. Reversing the orientation loses the local small-radius packing estimate used in (C).

In addition, residual ineligible loss and the full signed return term remain. The return supply owner has only \(y\in C_b\), not receiver membership in \(C_b/a\) or \(E_b\). Thus receiver collision geometry cannot be assigned to it for free. The adaptive selected target marginals need not equal \(a_j\); crosseligibility cannot be assumed. Swap optimality gives nonnegative expected cost gap, not vanishing gap or free physical-price payment.

The exact remaining general hypothesis is (B), or the stronger sufficient bridge (D) together with the proved restricted budget. A successful full argument must assign both matching endpoint prices, residual loss, and signed return costs while respecting these rowwise credit allocations and retaining \(\mathcal P_Z\). The audited results presently do not establish that assignment.

## 6. Verification and comparison

The installed local Python/SymPy runtime was actually run on the low certificate, the full \(\mathcal P_Z\) rearrangement, and the final \((CL_n-1)M\) coefficient. All three symbolic residuals were zero. No enumeration or new numerical evidence was used as a substitute for the missing geometry.

The independent derivation agrees with LOW_SCORE_AUDIT.md, including its final full-credit addendum. That audit certifies the low incoming payment and algebraic reduction; it does not certify the new matching bridge or the arbitrary-input weak bound.
