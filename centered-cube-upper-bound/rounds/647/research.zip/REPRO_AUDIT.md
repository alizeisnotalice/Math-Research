# R647 reproducibility receipt audit

## Outcome and boundaries

The low-u script was reproduced in an isolated copy: all 85 declared checks (6 + 9 + 70), its SymPy assertions, and its rational two-row example completed. The separately written matching check was reproduced on six fixtures and its output exactly matches its existing JSON. The 135,468 graph-profile cases and four boundary fixtures are a **prior run receipt**, not an independently reproduced full enumeration here. Neither finite checks nor the receipt by themselves establish a general operator bound or spatial/covering hypothesis. The low-u report supplies a separate exact algebraic decomposition over its stated continuous domain; the matching report supplies a separate general finite-graph argument, whose applicability to the wider problem remains a distinct question.

## Receipt verification

- `low_numeric/SHA256SUMS` matches the present four listed files. Script SHA-256 `e057259b79af6d290f36b90b504843cc1e5fa74296c978648729609df85984c7` agrees with the existing JSON and isolated run. Prior results state Python 3.12.14 and SymPy 1.14.0.
- `matching_numeric/results.json` reports 24 completed jobs, 135,468 checked graph-profile cases and four fixtures; summing its jobs yields 95,958 cases with s >= 1, of which 1,990 have s = 1, and 39,510 with s < 1. `run.log` lists all 24 jobs with zero failures, with 32,768 cases for each of four m=6 jobs. The current matching source hash `d7073dea05470cd03367eedce30978c9b31713dc1c265ba98187415ff9269bf3` matches the JSON's recorded script hash. This establishes consistency of supplied artifacts, not independent provenance or a replay of each case.
- Matching receipt records Python 3.12.14, 8 configured worker processes, 3.171692833 s wall, 9.484109 aggregate worker CPU seconds, and 25,821,184 bytes peak individual worker RSS. Source uses `ProcessPoolExecutor(max_workers=8)` and JSON records `workers: 8`; neither confirms actual simultaneous worker utilization. Current `os.cpu_count()` reports 15 logical CPUs; this is a live observation, not a historical CPU count or evidence of full CPU usage.
- The earlier independent `audit.log` claims 72 samples (4 profiles × 6 sizes × 3 graph selections), matching source/result hash and four fixture comparisons. That is a prior audit receipt; it was not rerun for this audit. Some selected graphs can coincide for small sizes, so 72 means checks, not necessarily distinct graphs.
- Inspected scripts use Python `fractions.Fraction`; low-u additionally uses SymPy. No inspected script imports or calls python-flint/Arb, and the low-u report expressly says Arb was not run. Do not describe these receipts as Arb or python-flint calculations. Availability of a library is not evidence of its use.

## Isolated reproduction

Copies and outputs are in `/tmp/r647_repro_receipt_terra/`; prior results were not overwritten. Exact commands:

```sh
mkdir -p /tmp/r647_repro_receipt_terra/low /tmp/r647_repro_receipt_terra/independent
cp /tmp/ccu_r647/low_numeric/check.py /tmp/r647_repro_receipt_terra/low/check.py
cp /tmp/ccu_r647/matching_independent/check.py /tmp/r647_repro_receipt_terra/independent/check.py
cd /tmp/r647_repro_receipt_terra/low
OPENBLAS_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python check.py > results.json
cd /tmp/r647_repro_receipt_terra/independent
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python check.py > check.log
```

Both exited successfully. Low-u stages: initial 6, boundary 9, wide 70; Python 3.12.14, SymPy 1.14.0, CPU 0.05448 s, wall 0.05799 s, peak RSS 72,794,112 bytes. The independent script produced six named fixtures identical as parsed JSON to the prior output. In the single-edge case s=0, P=2, scale=1/2, and both scaled residuals are 1/2, so scaled support is not independent.

## Missing evidence

No independent full scan was performed, no separate process-level utilization trace was provided, and no Arb/python-flint execution record was found in the inspected calculation scripts. Existing timing and resource figures are self-reported receipts; this audit cannot establish historical full utilization. The finite rational examples do not establish assertions for arbitrary geometric inputs.
