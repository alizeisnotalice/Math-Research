# R647 artifact and provenance audit

## Result

The archive is compact: 29 files at inspection, with no PDF, LaTeX build output, Python cache, or scratch log. Its active set is the report, eight audit/receipt documents, one verifier, and focused plans, sources, and results. Scope and open-claim boundaries are stated consistently: the general centered-cube root-order bound, complete high-incoming payment, physical-flow comparison, and general recovery remain unproved. I do not certify the mathematics.

## Binding and source variants

`REPORT.tex` currently hashes to `a3d7aa053f960175a6675cf7e376ad3ec9af2f9064a408da6f865f6a1e6d4910`. Both `FINAL_GEOMETRY_AUDIT.md` and `FINAL_LEDGER_AUDIT.md` record that exact hash and say their verdicts bind it. The older ledger/geometry records explicitly concern predecessor snapshots, so they are not mistaken for final-source certification.

`repro/far/README.md` preserves `22cc9027…f1db2497` as a historical pre-integration report snapshot, explicitly says it is not the final report binding, and separately gives the current final report SHA recorded by both final audits. This provenance is clear and consistent; the historical hash is not a claim that the final report was checked at the earlier run. The far plan and script hashes also match their current files. Far `results.json` records Python 3.12.14, the current `check.py` hash, all three stages, and matching counts. The README accurately retains the initial CPython 3.15.0 provenance and distinguishes the 3.12.14 rerun.

The source-variant notes are adequate: `matching_numeric/check_matching.py` is identified as the retained original full enumeration source; `matching_independent/audit_author.py` is documented as a scratch-path-only rewrite, and its historic scratch hash difference is disclosed. Other retained sources are described as unchanged. `REPRO_AUDIT.md` labels the 135,468-case matching run as a prior receipt, not a fresh replay. The geometry fixtures and far-ledger fixtures are explicitly classified as relaxed/algebraic models; the latter use singleton packages and do not model general multirow package geometry. The report does not promote those fixtures into theorem evidence.

## Reproduction and disposition

`verify_archive.py` contains the documented manifest/hash checks, Python AST parsing, LaTeX environment/reference checks, and eight bounded replay commands. Its replays use `sys.executable` and paths relative to the extracted archive, so they are portable with Python and the required installed dependencies. The exact interpreter path in `AUDIT.md`, the historic geometry-plan command, and logged original-run commands are environment-specific provenance, not portable replay instructions; the archive verifier is the portable replay entry point. It deliberately does not compile a PDF or rerun the expensive graph enumeration.

No Arb or MATLAB run is claimed. The report and audits correctly identify the numerical evidence as exact-rational/SymPy checks, separate the relaxed fixtures from proof, and avoid claiming full CPU saturation. With the manifest including this audit, the artifact/provenance package is ready for final verification.
