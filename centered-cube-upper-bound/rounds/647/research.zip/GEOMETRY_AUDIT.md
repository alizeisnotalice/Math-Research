# R647 independent geometry and averaged-coupling audit

Audit scope: the frozen finite-label contract in `FROZEN.md`, with the half-law definitions checked against `/tmp/ccu_r646_final/REPORT.tex`, section 7. The arguments in sections 1–5 below were completed before reading `MATCHING_NUMERIC_AUDIT.md`. I own only this file and made no Git changes. No general centered-cube weak bound or closure of transport equation (11) is claimed.

**Verdict.** The proposed oriented product-flow estimate is valid, pathwise outside one anchor null set, in arbitrary dimension and with arbitrary positive growth. The matching decomposition and the averaged-coupling energy bound are also valid with the qualifications below. These are different flows and different prices. They do not identify the physical matching \(f\) with the Eulerian flow \(F\), do not pay the whole physical two-end price, and do not close the remaining signed-return/residual problem.

## 1. Old load at every sampled anchor

Write \(L(x)=\sum_i\lambda_i\mathbf1_{A_i}(x)\). The hypotheses give \(L\le1\) Lebesgue-a.e. and \(L=1\) \(\mu\)-a.e. Since each \(\gamma_k\) is nonnegative and \(\sum_k\gamma_k=\mu\), we have
\[
 \gamma_k\le\mu\ll dx.
\]
Thus \(X_k\sim\gamma_k/a_k\) avoids the common exceptional set for the old load almost surely. There are finitely many labels, so simultaneously
\[
 X_k\in A_k,\qquad L(X_k)=1\quad\text{for every }k
 \tag{1}
\]
on one probability-one event. The weaker \(L(X_k)\le1\) is all that the geometric estimate uses. No independence of the random neighbor sets is needed; independence is needed later only to transfer the pairwise optimizer null sets to the sampling law.

In particular, for any sample-dependent subset \(J_k(Z)\subseteq\{j:X_k\in A_j\}\),
\[
 \sum_{j\in J_k(Z)}\lambda_j\le1.                 \tag{2}
\]
This remains true when selection depends on every anchor, on collisions, and on radius comparisons.

## 2. Exact local packing bound and the oriented estimate

Let \(N_j\) be the frozen neighbor set, either with all equal-radius neighbors admitted in both directions or with a fixed tie orientation. For \(k\in N_j\), crosseligibility gives \(X_j\in A_k\), while
\[
 s_k\le\rho_k\le\rho_j.
\]
For any \(z\in I_k\), using the cube norm,
\[
 \|z-X_j\|_\infty
 \le\|z-y_k\|_\infty+\|y_k-X_j\|_\infty
 \le s_k/a+s_k\le(1+1/a)\rho_j.
\]
Consequently all such old cores lie inside one cube:
\[
 \bigcup_{k\in N_j}I_k\subseteq
 Q\bigl(X_j,(1+1/a)\rho_j\bigr).
\]
The old \(I_k\) are disjoint (disjoint a.e. suffices). Hence their volumes, rather than the volumes of their generally overlapping ambient cubes, add, giving
\[
 \boxed{\sum_{k\in N_j}v_k
 \le (1+1/a)^n(2\rho_j)^n=P_0m_j,\qquad
 P_0=(1+1/a)^n.}                                  \tag{3}
\]
Here \((2\rho_j)^n=t_j^nd_j=(1+u_j)d_j=m_j\). No growth comparability, density bound, lower bound on \(\lambda_j\), or packing of the \(A_k\) has been assumed. In fact (3) does not need the small-cube collision condition; that restriction merely makes \(N_j\) smaller.

The exact scalar identity is
\[
 1+u=1+2\kappa+\frac{(u-\kappa)^2}{u}
                 -\frac{\kappa^2}{u}
 \le1+2\kappa+\frac{(u-\kappa)^2}{u}.              \tag{4}
\]
Because \(u_ka_k/\epsilon=(1+u_k)v_k\), the desired left side for \(G_{jk}=\lambda_ja_k\) equals
\[
 \begin{aligned}
 \mathcal C_G(Z)
 &=\epsilon^{-1}\sum_j\sum_{k\in N_j}u_kG_{jk}\\
 &=\sum_j\lambda_j\sum_{k\in N_j}(1+u_k)v_k\\
 &\le(1+2\kappa)\sum_j\lambda_j\sum_{k\in N_j}v_k
   +\sum_kv_k\frac{(u_k-\kappa)^2}{u_k}
                  \sum_{j:k\in N_j}\lambda_j.
 \end{aligned}
\]
The first term is at most \(P_0(1+2\kappa)\sum_j\lambda_jm_j\) by (3). For the second term, crosseligibility gives \(X_k\in A_j\) whenever \(k\in N_j\), so (2) bounds its inner sum by one. Therefore
\[
 \boxed{\mathcal C_G(Z)\le
 E_{\rm grow}+P_0(1+2\kappa)M.}                    \tag{5}
\]
Since \(a=32n\), \(P_0\le e^{1/32}<2\); with \(\kappa\le4\), the stated weaker bound
\[
 \mathcal C_G(Z)\le E_{\rm grow}+18M               \tag{6}
\]
follows. Formula (5) is valid for any positive \(\kappa\); the range \([3.5,4]\) is used only for the final numerical constant.

**Equal-radius counts.** There is no extra factor two, even if both orientations of an equal-radius pair are kept. Bound (3) is a per-receiver bound, and the reversed sum at each \(k\) is still a subset of the old load at \(X_k\). Removing one of the tied orientations only reduces the nonnegative left side.

**True Eulerian flow.** For
\[
 F_{jk}=\lambda_j\gamma_k(A_j),
\]
we have, including the diagonal,
\[
 \sum_kF_{jk}=\lambda_j\mu(A_j)=a_j,
 \qquad
 \sum_jF_{jk}=\int L\,d\gamma_k=a_k,
 \qquad 0\le F_{jk}\le\lambda_ja_k=G_{jk}.          \tag{7}
\]
The column identity uses \(\gamma_k\ll\mu\) and \(L=1\) \(\mu\)-a.e. Thus the very same oriented estimate (5) holds with \(F\) in place of \(G\), by the genuine pointwise domination in (7). The product majorant \(G\) itself need not have row and column masses \(a\); its only role here is as a majorant.

## 3. Balanced collision decomposition, with the scaling qualification

For a fixed sample \(Z\) and physical point \(x\), let \(J(x,Z)=\{j:x\in E_j\}\) and \(m=|J|\). Give each active vertex the positive capacity \(h_j=\epsilon/u_j\). The graph on \(J\) has precisely the crosseligible pairs as edges. An edge at such \(x\) automatically joins colliding small cubes, since \(E_i\subseteq B'_i\).

Process the finitely many unordered edges in a fixed global order. At an edge, assign the minimum of the two current endpoint residual capacities, and deduct that same mass from both endpoints. Denote the resulting symmetric edge masses by \(b^0_{jk}\), row masses by \(q^0_j=\sum_{k\ne j}b^0_{jk}\), and residuals by \(r^0_j=h_j-q^0_j\). They satisfy
\[
 b^0_{jk}\ge0,\quad q^0_j\le h_j,
 \quad P:=\sum_{j\in J}q^0_j/h_j
 =\sum_{j<k}b^0_{jk}(1/h_j+1/h_k),
 \quad s:=\sum_{j\in J}r^0_j/h_j,
 \quad P+s=m.                                    \tag{8}
\]
After an edge is processed, at least one endpoint residual is zero and remains zero. Thus the support of the **unscaled** positive residuals \(r^0_j\) is an independent set.

For \(m\ge2\), the loss of physical copies is \(m-1\), and the following two cases give an exact decomposition.

* If \(s\ge1\), retain \(b=b^0\). The eligible price is \(P=m-s\le m-1\). Put \(\alpha_j=r^0_j/h_j\) and allocate the remaining \(s-1\) copies by
  \(d_j=((s-1)/s)\alpha_j\). Then \(0\le d_j\le\alpha_j\), \(\sum_jd_j=s-1\), and their positive support is independent. Eligible plus residual price equals \(P+s-1=m-1\).
* If \(s<1\), then \(P=m-s>m-1>0\). Put
  \(b=\theta b^0\), where \(\theta=(m-1)/P\in(0,1)\). Its rows remain at most \(h_j\), and its eligible price is exactly \(\theta P=m-1\). Assign zero additional residual price.

For \(m=0\), take every quantity and price zero. For \(m=1\), there are no graph edges; take \(b=0\), \(s=1\), and zero loss price. These conventions avoid every division by zero.

**The residual after scaling need not be independent.** With two unit-capacity vertices joined by one edge, the unscaled assignment is \(b^0_{12}=1\), \(P=2\), \(s=0\). Scaling to \(b_{12}=1/2\) leaves residuals \(1/2\) at both adjacent vertices. The independent-support statement applies only to (r^0) in the first case or before scaling; the second case needs no residual charge.

Integrate the final edge masses:
\[
 f_{jk}(Z)=\int b_{jk}(x,Z)\,dx=f_{kj}(Z),\qquad j\ne k.
\]
Since \(|E_j|=\ell_j=(1+u_j)v_j=u_ja_j/\epsilon\),
\[
 \sum_{k\ne j}f_{jk}\le\int_{E_j}h_j\,dx=a_j,
 \qquad \sum_{j<k}f_{jk}\le M/2.                  \tag{9}
\]
The exact eligible part of the **physical volume-loss price**, under this unordered-pair convention, is
\[
 \boxed{O_{\rm elig}(Z)=
  \epsilon^{-1}\sum_{j<k}f_{jk}(Z)(u_j+u_k).}      \tag{10}
\]
The allocated residual part \(O_{\rm res}=\int\sum_jd_j\,dx\) is nonnegative and satisfies
\[
 O=\int(m-1)_+\,dx=O_{\rm elig}+O_{\rm res}.       \tag{11}
\]
If a ledger charges (2O), it must charge twice (10)–(11). There is no implicit convention that discards that factor.

**Measurability.** Work with Borel representatives of the finitely many old measurable \(I_j\). Null modifications have no effect on any translated/dilated volume integral for any fixed sample. Then \(\mathbf1_{E_j(Z)}(x)\), graph-edge indicators, finite greedy minima, the two-case scale, and \(d_j\) are jointly measurable. Fixed edge and tie orders are essential to this explicit selection. Tonelli gives measurable \(f_{jk}(Z)\). No measurable choice of a graph optimum or an uncountable matching is required.

## 4. Swap inequality and the full center identity

For an optimizer \(\gamma\), fix \(j\ne k\). If the set of crosseligible pairs \((x,y)\) with
\[
 \Delta_{jk}(x,y)=F_j(x)+F_k(y)-F_j(y)-F_k(x)<0
\]
had positive \(\gamma_j\otimes\gamma_k\) measure, restrict that product measure to this set and multiply by \(1/\max(a_j,a_k)\). Its two marginals \(\nu_1,\nu_2\) satisfy \(\nu_1\le\gamma_j\), \(\nu_2\le\gamma_k\) and have equal total mass. Replacing
\[
 \gamma_j\mapsto\gamma_j-\nu_1+\nu_2,
 \qquad \gamma_k\mapsto\gamma_k-\nu_2+\nu_1
\]
preserves source, row masses, nonnegativity and allowed supports, and strictly increases the objective by \(-\int\Delta_{jk}\,d\nu\). This contradicts optimality. Hence \(\Delta_{jk}\ge0\) for product-a.e. crosseligible pair. The independent product anchor law and finiteness of the pairs make all these inequalities simultaneous a.s.

With \(d=X_j-X_k\),
\[
 A=A_{jk}=\sigma_jy_j-\sigma_ky_k
                -(b_j-b_k)(X_j+X_k)/2,
 \qquad \bar b=(b_j+b_k)/2,
\]
direct expansion gives the exact signed identities
\[
 \Delta_{jk}=-A\cdot d,\qquad
 c_j-c_k=A-\bar b d,
\]
and therefore
\[
 \boxed{|c_j-c_k|_2^2
 =|A|_2^2+\bar b^2|d|_2^2+2\bar b\Delta_{jk}.}    \tag{12}
\]
The sign of the final term is positive. Also \(u_j,u_k>0\) implies \(t_j,t_k>1\), so \(b_j,b_k>0\) and \(\bar b>0\). Thus all three terms on the right of (12) are nonnegative on a crosseligible sample. If growth below one were permitted, this sign inference would need to be reconsidered; it is valid under the frozen contract.

If \(f_{jk}>0\), the labels are crosseligible and \(B'_j\cap B'_k\ne\varnothing\). Therefore
\[
 \|c_j-c_k\|_\infty\le(\rho_j+\rho_k)/a,
 \qquad
 \frac{|c_j-c_k|_2^2}{(\rho_j+\rho_k)^2}
 \le\frac n{a^2}=\frac1{1024n}.                  \tag{13}
\]

## 5. Averaged allocation and energy: exactly what is proved

Complete the symmetric matching matrix by setting
\[
 f_{jj}=a_j-\sum_{k\ne j}f_{jk}\ge0.
\]
Then all rows and all columns equal \(a\) for each sample. Define a deterministic averaged allocation by its action on Borel sets:
\[
 \widetilde\gamma_j(H)
 =\mathbb E\sum_k f_{jk}(Z)\mathbf1_H(X_k).
                                                        \tag{14}
\]
It is nonnegative, has total mass \(a_j\), and is supported on \(A_j\): diagonal mass uses \(X_j\in A_j\), and offdiagonal positive mass uses crosseligibility, hence \(X_k\in A_j\). Moreover
\[
 \sum_j\widetilde\gamma_j(H)
 =\mathbb E\sum_k a_k\mathbf1_H(X_k)
 =\sum_k\gamma_k(H)=\mu(H).                       \tag{15}
\]
This is a feasible competitor for the optimizer **after expectation**. At a fixed sample its total source is the atomic measure \(\sum_ka_k\delta_{X_k}\), generally not \(\mu\). No samplewise replacement of the source is justified.

Using the row identities and symmetry, its objective gap is exactly
\[
 \begin{aligned}
 \sum_j\int F_j\,d\gamma_j-
 \sum_j\int F_j\,d\widetilde\gamma_j
 &=\mathbb E\sum_{j,k}f_{jk}
                        [F_j(X_j)-F_j(X_k)]\\
 &=\mathbb E\sum_{j<k}f_{jk}\Delta_{jk}\ge0.
 \end{aligned}                                      \tag{16}
\]
Optimality gives a nonnegative gap, **not a zero gap**; a feasible competitor may have a smaller objective. Integrability follows from finite labels, bounded old cubes/costs and the row bound (9).

Finally, (9), (12) and (13) give the stronger pathwise statement
\[
 \sum_{j<k}f_{jk}(Z)
 \frac{|A_{jk}|_2^2+\bar b_{jk}^{\,2}|X_j-X_k|_2^2
                  +2\bar b_{jk}\Delta_{jk}}
      {(\rho_j+\rho_k)^2}
 \le\frac1{1024n}\sum_{j<k}f_{jk}(Z)
 \le\frac M{2048n}.                              \tag{17}
\]
Taking expectation proves the frozen \(M/(2048n)\) bound, including its constants. Every displayed energy summand is nonnegative a.s., so (17) also bounds any one component or their nonnegative partial sum. It does not convert the energy into the unweighted growth price (10).

## 6. Comparison with the finite matching audit

Only after establishing the arguments above, I read `MATCHING_NUMERIC_AUDIT.md`. Its graph-theoretic conclusions agree with section 3: the exact identity \(P+s=m\), capacity preservation, the two cases, independent residual support before scaling, and the explicit two-unit-vertex counterexample after scaling. Its stated computation is a finite graph/price-ledger audit, not a proof of geometric realization, domination by \(F\) or \(G\), the averaged-source argument, or a general cube estimate. I did not repeat its 135468-case enumeration or independently verify its logged aggregate counts; none is needed for the finite-graph proof above.

As required by the user's local-mathematics preference, I ran the existing local Python/SymPy runtime `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` for an independent scalar expansion. It returned:

```
scalar exact remainder: k**2/u
gap sign identity residual: 0
center-energy identity residual: 0
```

These are actual symbolic checks of (4) and the one-coordinate versions of the identities in (12); summing coordinates yields (12). They support algebraic bookkeeping only. The geometric, measure-theoretic and matching claims rest on the proofs above.

## 7. Precise surviving gap

The following substitutions are not licensed by this audit.

1. \(f\) is a random symmetric matrix created from **physical overlap** and equal endpoint deductions. \(F_{jk}=\lambda_j\gamma_k(A_j)\) is a deterministic Eulerian source-allocation matrix and need not be symmetric. Having the same row/column masses after diagonal completion does not identify them and does not give \(f_{jk}\le F_{jk}\) or \(f_{jk}\le\lambda_ja_k\). Row capacities alone imply only \(f_{jk}\le\min(a_j,a_k)\), which is generally larger than the product cap. A domination theorem would be an additional result, not a consequence of (7), (9), or (14).
2. Estimate (5) pays the oriented price \(u_k\lambda_ja_k/\epsilon\) where \(\rho_k\le\rho_j\). The physical price (10) contains **both** \(u_j\) and \(u_k\) with coefficient \(f_{jk}\). In unequal-radius pairs, the second price cannot be obtained by silently reversing the orientation: the local packing proof used \(s_k\le\rho_j\). An expectation-only comparison would also need proof, not only matching marginals.
3. Estimate (17) pays squared Euclidean displacement and swap-gap energy. No proved inequality relates that dimensionally normalized energy to the full price (10) for arbitrary growth. Nonnegative swap gaps need not vanish and do not themselves supply the missing physical source mass.
4. The independent residual portion of (11) still needs an ineligible-geometry payment. The positive part of the signed return/merge score, and the mismatch between supply owners in \(C_k\) and receiver owners in \(C_k/a\), remain outside (5) and (17).
5. Formula (5) spends \(E_{\rm grow}\) once. It cannot be added as a fresh budget to the already paid low-incoming estimate or another growth payment without a joint accounting argument. The actual fill, \(RT\), exact \(H_Z\), actual-slack positive part and all signed resupply/merge credits in `transport.md` equation (11) must remain in the same action and same ledger.

Thus there is a fully proved new auxiliary inequality, (5) with either \(G\) or the true \(F\le G\), and a fully proved matching-energy inequality (17). The comparison from these auxiliary statements to the actual two-end collision cost and the remaining signed-return ledger is still missing.
