# 连续扩张下并集体积：文献条件定位

## 直接回答

R646 若只掌握 **Euclidean strong monotonicity / continuous expansion**，对固定半径但可不同的欧氏球有直接来源定理；对不同半径轴平行立方体，所核来源不能直接给出体积单调或同类误差估计。一般范数来源确实覆盖轴平行立方体这一特殊范数球，但只证明同半径且满足 uniform contraction 的离散配置比较，另有 `N≥2^d` 条件。不能把球的逐点对连续距离扩张结论改写成异半径立方体结论。

## 1. Csikós：任意固定半径的欧氏球，连续中心收缩

原文：Balázs Csikós, “On the Volume of the Union of Balls,” *Discrete & Computational Geometry* 20 (1998), 449–461。

- 引言 p.450 将 `r=(r_1,…,r_N)∈R_+^N` 定为一组球半径；允许各半径不同。摘要及引言 §1 pp.449–450 说明对象为标准欧氏空间中的球。
- Theorem 4.1, p.453：`X(t)` 光滑，半径向量固定；在相应球互异的时刻，
  `V'(t)=Σ_{i<j} d'_{ij}(t) V_{n−1}(W_{ij})`，其中 `d_{ij}=|x_i−x_j|`，`W_{ij}` 是截断 Voronoi cells 的公共墙，墙的 `(n−1)` 维体积非负。
- Theorem 4.2, pp.454–455：分段光滑连续运动、所有中心点对距离函数单调不增，任意固定半径向量 `r∈R_+^N` 均有 `V(∪B(x_i(a),r_i))≥V(∪B(x_i(b),r_i))`。
- Theorem 5.4, pp.459–460：将路径正则性降到连续；仍要求每个 `d_{ij}(t)` 在路径上单调不增，结论对任意固定半径向量成立。因此反向路径的 continuous expansion 给并集体积单调不减。
- Lemma 5.2, pp.456–457 给局部二次上界：在其假设下 `V(Q,r)−V(P,r)≤c||P−Q||²`。该引理要求端点配置满足逐点对收缩 `d(p_i,p_j)≥d(q_i,q_j)`，归一化尺度下距离上界 `1`、正下界 `δ`，且 `||P−Q||<min{1,δ/2}`；`c` 依赖半径向量、距离上界和正下界（文中式 (8) 给出表达）。证明将中心作线性插值，再对路径作时间尺度修正以获得距离单调。它是欧氏球的局部估计，不能直接赋予 cube union。

本核验读取了 Springer 提供的 13 页原文 PDF：Theorem 4.1 在 PDF 第 4 页/印刷页 453，Theorem 4.2 在 PDF 第 6 页/印刷页 455，Lemma 5.2 在 PDF 第 7–8 页/印刷页 456–457，Theorem 5.4 在 PDF 第 11 页/印刷页 460。题录与摘要由 [Springer 原文页](https://link.springer.com/article/10.1007/PL00009395) 核验。阅读结论限于这些定理与相邻证明条件。

## 2. Bezdek：一般 Minkowski 球；同半径 uniform contraction

原文：Károly Bezdek, “On Uniform Contractions of Balls in Minkowski Spaces,” *Mathematika* 66 (2020), no. 2, 448–457；作者提交版本 [arXiv:1903.03106v4](https://arxiv.org/abs/1903.03106)。

- 定义 2、Theorem 2（arXiv v4 PDF p.2；期刊版 pp.449–450）：`K⊂R^d` 是任意原点中心对称凸体，范数球为 `x+rK`。若 `Q` 是 `P` 的 uniform contraction，即存在 `λ>0` 使每个收缩后点对满足 `||q_i−q_j||_K≤λ`、每个原点对满足 `||p_i−p_j||_K≥λ`，且 `d>1, N≥2^d, r>0`，则同半径球并集满足 `V_d(Q_r^K)≤V_d(P_r^K)`。
- 取 `K=[−1,1]^d` 即为按坐标轴对齐的立方体（半边长 `r`、边长 `2r`）。因此文献中有一个立方体并集单调性特例，但只用于**共同半径**、uniform contraction 和 `N≥2^d`。uniform contraction 要求两组的全部点对距离由同一 `λ` 分隔；仅逐点对有一条连续不增/不减路径，并不自动给出此假设。
- Theorem 4（arXiv v4 PDF p.2；期刊版约 p.450）针对球交集而非并集，另要求 `K` 为 generating set 及 `N≥3^d`；不应把这一条件误加到并集 Theorem 2，也不应误认为它处理了异半径。

题名、作者、arXiv 版本及摘要由 [arXiv 原文页](https://arxiv.org/abs/1903.03106) 核验；期刊卷期页码和 DOI 由该卷期索引核对。全文核读定义 2 与 Theorems 2、4，不据此声称任意范数的异半径球结果。

## 范围判定

这两条来源共同给出的可用边界是：

| 几何对象 / 路径条件 | 来源结论 | 可否直接覆盖 R646 的异半径 axis-parallel cubes |
|---|---|---|
| 欧氏球，半径可不同但沿路径固定；每个中心点对距离连续单调 | Csikós Theorem 5.4：并集体积单调 | 否，立方体不是欧氏球 |
| 一般范数球、含轴平行 cube；半径相同；uniform contraction，且 `N≥2^d` | Bezdek Theorem 2：并集体积单调 | 仅同半径且满足更强分隔条件时可用 |
| 异半径 axis-parallel cubes；仅逐点对连续距离扩张 | 本次所核两条原始定理均未覆盖 | 未找到可直接引用的体积单调/同类误差定理；有限检索不构成整个领域的不存在性结论 |

因此，对 R646 的不同半径 axis-parallel cube union，需要独立证明相应体积不等式，或另找具有完全匹配假设的原始来源。上述两条文献都不能单独授权该迁移。
