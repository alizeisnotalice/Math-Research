# R494 独立终审

FINAL PASS（限定范围）。认证完整实际停止云的统一 cloud-to-child cut 比较、固定 M 的一次可吸收误差及精确条件回代；同时认证互补 max-parent 势账的适用范围。不认证 Δ_mix／Δ_child 的根阶来源价格、完整停止付款或一般弱型上界闭合。

独立 PRE 在作者阅读前形成，并于新主代理候选到达后独立追加。逐式核对一般几何证明：对称 Gram 行界给∫N(N−1)≤G/2，真实 μ 下 Cauchy 给 t≥h²/(h+1/2)≥2h²/3；mass-weighted child hinge 的 Jensen 方向正确，完成平方给3L²/(8M)。它对同一完整ρ、所有同一全局来源D统一成立，不需逐D选择子族或重复收费。L=2及M≥max(3/2,3/(2ε_mix))保证误差≤ε_mix R及局部行容量≥1。M与维数／深度无关，但它是新的终端分析边帽，不继承原自然列帽一。

Θ由与D无关的m_C/G子父选择定义，仍保全部原记录；其单代列估计须先max Palm正支配再natural lower Campbell，m_C/G≤m_C/m_B使系数为I_BC/(Tm_B²)，闭尾原子界给b0。累计深度仍在，不能把Θ认作ν或f1_D的原接受流。来源局部化(7)–(9)只有粗高维价格，未冒充root价。

主稿式 M 正确保留ε_mix R的恢复系数2，取代而不叠加R493的大族tail；后续aR、ε_cut及原一次M(e)均按完整分母回代。两个未付缺额没有已证排序，最终文辞已明确。互补proof的有符号停止恒等、初始停止减项、p-Jensen负信用及bad补集项正确；H固定的是最大父，因此不能转授Θ子父。原母账倍率、初始／跳跃／删除／未来来源与全尺度未付槽保留。

复现分级：本审计独立隔离重放geometry内嵌代码（输出112个cut比较及1个符号恒等式）与proof的36项有理核验，stdout与冻结replay一致。按本轮任务不重复整套数值运行；已逐段审阅numeric脚本、4437项报告、主代理隔离日志，并重新核对冻结JSON去compute_index.seconds后的canonical SHA256为 `afe09da9016d59b08d982627c336fa2e0e0fa47d38de35bb72b84a239de8972b`。五个有限原子来源／实际区间方形族、120个整原子来源子集与1080个需求比较只认证指定接口；排除Gram失败族，裸根与capped根比较及256-bit Arb范围表述正确。它们不是连续接收场、实际Γ或history证书，不外推一般阶数。

## 冻结输入 SHA256

- `r494_main.md`: `4fb8e42f7d1fb9e6e3561bd1e7a99467cf6d77770ac321e322149df4a763ee22`
- `r494_geometry.md`: `7530eb9040cd941b77b7cd264507bf8fa5e4b2e2b43d91ea4dd1c58195d85893`
- `r494_proof.md`: `09b0a755e2a608f6e6204ce32d83c5b52faf02c7870f07dbe859ff606951af49`
- `r494_numeric.md`: `7bff62e9a8a06d626bb17f409845481ee1fdb51a33c0c2be5da3bb1d5c610746`
- `r494_numeric.py`: `8bee41d5af00b51d4df0732c189a5aa5361d7ad56c53745625d69b9e416fddd6`
- `r494_numeric.json`: `c6801b990dcbd9c73bb19ce1ec7556d9ac250515b331dd20b277275db225f5fa`
- `r494_replay.json`: `a92cff354a51b39d4fcfe7eaa5822c0c3bc783a1aceb8e1fef375714fcaf8ff1`
