# 第494轮：完整停止流的整族来源割比较与一次误差预算

## 本轮目标与状态

沿用R493的原自然配置链P=JH、实际完整记录rho=sum_j Gamma_j，目标仍为任意非负L1输入的一般中心立方体弱型n^(1/2+o(1))上界，未完成。本轮改进同一完整来源割的几何比较：直接保留整个成功族，付可任意减小的一次epsilon R误差，不先排除大族，也不增加质量分层。新全族累计来源价仍未证明；这是比旧最大父接口保留更多几何的替代路线，不声称两个未付缺额互相支配。

冻结合同：mu=f dx，W=||f||1，sigma=q_A dA为真实Lebesgue中心测度，nu=t sigma且0≤t≤S，总量R=nu(E)、X=sigma(E)。a≤R_A≤b≤2a，q≤q_A≤lambda，r=lambda/q；原阶段、质量mark、旧pair、删除和未来历史随Jrec保留。零流为零。q_j=(P*)^j1，e=1−J1，A_p=sum_j ∫q_j^p e，R491给(1−eta_rec)R≤2A_p，rho总量=A_p−M(e)≤R。附加来源或子父标签不自动继承旧pair历史。

## 一个直接作用于全体来源割的几何引理

每条实际成功记录的族F有限，m_C=mu(Q_C)>0，G=sum_C m_C，U=union_C Q_C。已证低Gram门为每行 sum_(D≠C) I_CD/sqrt(m_C m_D)≤1/2。令N(z)=sum_C 1_QC(z)。保留全部交叉项，以2sqrt(m_C m_D)≤m_C+m_D得
\[
 \int N(N-1)d\mu\le G/2.
\]
固定任意mu可测来源集合D，令v=mu(U\D)、H=sum_C mu(Q_C\D)，t=v/G、h=H/G。Cauchy应用于真实来源测度给
\[
 H^2\le v(H+G/2),\qquad
 h\le\min\{1,(t+\sqrt{t^2+2t})/2\},\qquad t\ge 2h^2/3.
\]
没有使用来源密度帽、薄层体积，亦未把真实交集换成独立事件。这个根界在数值稿的合法四方形族达到等号；没有声称每个原成功门都由该有限模型实现。

令L≥1，定义实际整族按质量加权的厚来源需求
\[
 \psi_D(F)=\sum_{C\in F}\frac{m_C}{G}(1-L\pi_C(D^c))_+.
\]
Jensen给psi_D≥(1−Lh)_+。任取M>0，有
\[
 \boxed{(1-M\mu(U\setminus D)/G)_+
 \le\psi_D(F)+\frac{3L^2}{8M}.} \tag{G}
\]
证明：两正部之差≤(Lh−Mt)_+≤sup_h[Lh−2Mh²/3]_+=3L²/(8M)。本式对所有D、同一族逐点成立；无需cut后再选择子族。固定L=2，M≥max(3/2,3/(2epsilon_mix))即可使误差≤epsilon_mix。

## 全记录混合、连续分配与完整回代

先定义与D无关的真实标记混合测度
\[
 \Theta(d\omega,dC)=\rho(d\omega)\sum_{C\in F(\omega)}(m_C/G_F)\delta_C,
 \qquad |\Theta|=|\rho|.
\]
保留omega所有标签；C只作终端收据。它不是原J的最大父输出，也不是输入f1_D的原接受流。定义
\[
 \Delta_{\rm mix}(\Lambda)=\sup_D\left[
 \int(1-2\pi_C(D^c))_+d\Theta-\Lambda\mu(D)\right]\ge0.
\]
R493连续分配定理用于全rho、k=M1_U/G、行帽1；M≥3/2保证局部行容量≥1，且k可积。由(G)对所有D的统一比较，其缺额至多Delta_mix+epsilon_mix|rho|，所以
\[
 A_p\le\mathsf M(e)+\Lambda W+\Delta_{\rm mix}(\Lambda)+\epsilon_{\rm mix}R,
\]
\[
 \boxed{(1-\eta_{\rm rec}-2\epsilon_{\rm mix})R
 \le2\mathsf M(e)+2\Lambda W+2\Delta_{\rm mix}(\Lambda).} \tag{M}
\]
这是完整rho的替代回代，不再加R493的大族尾费。M只依局部容许误差，不含n；更换的是辅助终端边帽，原链与停止权不变。Theta根阶预算仍为本轮唯一主路线缺口，不因得到(M)就视为已付款。

原一次停止账保留
\[
 \mathsf M(e)\le c_{\rm fail}X+\kappa T N_{\rm band}W,
 \quad c_{\rm fail}=\tau+\delta_{\rm succ}S+4rS^2/T+S^2b_n/T,
\]
T=1024rS²/(tau delta_succ)，tau≤S，delta_succ≤1/4，b_n≤3^(−n)，kappa=8log(4/delta_succ)，N_band≤1+[log r+n log(b/a)]/sqrt n。

若日后证明Delta_mix≤aR+epsilon_cut X+B_n，Lambda=O(sqrt n log^A(n+2))、B_n=O(sqrt n log^A(n+2)W)，且d0=1−eta_rec−2epsilon_mix−2a>0，则
\[
 R\le2(c_{\rm fail}+\epsilon_{\rm cut})X/d_0+
 2(\kappa T N_{\rm band}W+\Lambda W+B_n)/d_0.
\]
此为条件式，不能充当未知厚来源估计。全入口乘数仍为64(128/119)(1−32delta_old−16eta_old)^−1，须先分配局部epsilon；原初始、删除跳跃、未来来源、宽距离、低强度、极端比例与全尺度未付槽不从账中消失。

## 本轮明确不成立的自动推理与下一决策

已证一代Theta_j父边缘≤(1+b0)a_j nu，b0=2rS/T。证明先对原最大父投影使用Palm支配，再对自然lower PPP作Campbell；lower权m_C/G≤m_C/m_B使其核为I_BC/(Tm_B²)，真实中心闭尾给b0。不是成功后条件PPP。累计仍含sum_j a_j，不能丢掉该系数或把Theta当nu。

因此后续须集中研究Theta的跨记录容量，保留分母G以利用最大父权损失与lower权增加的共同结算；直接把两部分分别上放到1与b0，虽合法却丢弃潜在抵消。此处仅指定下一证明决策，不宣称精确列帽一已经成立。

独立互补证明稿还给旧maxparent厚来源势的准确起点+有向通量−p-Jensen差−坏支式。它未产生新付款，也不能直接搬到Theta子父，因为刷新H保持的是最大父。该未闭思路只保存必要公式与适用范围，不以余项改名计成果。

## 工具、核验范围与归档

沿用64项工具B01对偶规范；本轮查看G03并仅采用已明确输入的有限Gram矩阵算术，不调用其中未定义的私有捕获树定理。一般几何比较由上面的显式来源函数与Gram门直接证明。原始论文没有提供本轮的项目专用结论。

本机指定Python进行Fraction、SymPy与256位Arb核验。数值使用五个真实有限原子区间/方形族、120个来源子集；九组(L,M)共1080个需求比较，包含初探、Gram边界压力与扩大四方形族。裸根界只在t<2/3优于旧sqrt(1.5t)，报告保min(1,·)以免错误全域比较。一个Gram失败族只标资格不入定理。有限模型不认证原连续接收场、原Gamma或历史，更不外推一般维数。实际总断言、解释器、规范哈希与解压复现以r494_replay.json为准。保详细LaTeX、独审和必要复现，不编译PDF。
