from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import math,json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def subs(v):
 for k in range(len(v)+1):yield from combinations(v,k)

def data(name,phase,centers,atoms,mu):return dict(name=name,phase=phase,centers=[tuple(map(F,c)) for c in centers],atoms=[tuple(map(F,x)) for x in atoms],mu=list(map(F,mu)))
cent1=[(0,),(F(3,4),)];atom1=[(0,),(F(2,5),),(1,),(3,)]
fixtures=[data('initial_equal_mild','initial',cent1,atom1,[3,1,3,1]),data('pressure_row_boundary','pressure',cent1,atom1,[2,2,2,1]),data('pressure_mass_ratio25','pressure',cent1,atom1,[3,1,99,1]),data('two_dimensional_three','expanded',[(0,0),(F(3,4),0),(0,F(3,4))],[(0,0),(1,0),(0,1),(F(2,5),0),(0,F(2,5)),(F(2,5),F(2,5)),(3,3)],[13,14,14,1,1,1,1]),data('expanded_four_boundary','expanded',[(0,0),(F(3,4),0),(0,F(3,4)),(F(3,4),F(3,4))],[(0,0),(F(3,4),0),(0,F(3,4)),(F(3,4),F(3,4)),(F(3,8),F(3,8)),(3,3)],[30,30,30,30,6,1]),data('discard_row_failure','discard',cent1,atom1,[1,3,1,1])]
# Exact scalar identities underlying the root and its comparison with the coarse bound.
t,h=sp.symbols('t h',nonnegative=True)
f=(t+sp.sqrt(t*t+2*t))/2
ck(sp.simplify(f*f-t*f-t/2)==0)
ck(sp.simplify((sp.sqrt(6*t)-t)**2-(t*t+2*t))==4*t-2*t*sp.sqrt(6*t))
records=[];total_D=0
for f0 in fixtures:
 cs=f0['centers'];xs=f0['atoms'];mu=f0['mu'];n=len(cs[0]);nc=len(cs);nx=len(xs)
 B=[]
 for c in cs:
  row=[]
  for x in xs:
   dif=[abs(x[j]-c[j])-F(1,2) for j in range(n)];ck(all(z!=0 for z in dif));row.append(int(all(z<0 for z in dif)))
  B.append(row)
 m=[sum(mu[i]*B[c][i] for i in range(nx)) for c in range(nc)];roots=[]
 for z in m:
  a=math.isqrt(z.numerator);b=math.isqrt(z.denominator);ck(a*a==z.numerator and b*b==z.denominator);roots.append(F(a,b))
 I=[[sum(mu[i]*B[c][i]*B[d][i] for i in range(nx)) for d in range(nc)] for c in range(nc)]
 row=[sum(I[c][d]/(roots[c]*roots[d]) for d in range(nc) if c!=d) for c in range(nc)]
 mult=[sum(B[c][i] for c in range(nc)) for i in range(nx)]
 common=[i for i in range(nx) if mult[i]==nc];ck(bool(common))
 G=sum(m);Q=sum(mu[i]*mult[i]*(mult[i]-1) for i in range(nx));gate=max(row)<=F(1,2)
 rec=dict(name=f0['name'],phase=f0['phase'],dimension=n,side='1',centers=[[str(z) for z in c] for c in cs],source_atoms=[[str(z) for z in x] for x in xs],mu=list(map(str,mu)),capture=B,mass=list(map(str,m)),offdiagonal_Gram_rows=list(map(str,row)),G=str(G),multiplicity=list(mult),factorial_moment_Q=str(Q),common_source_indices=common,row_gate=gate)
 if not gate:
  ck(f0['phase']=='discard');rec['scope']='Excluded from the lemma: row gate fails; no cut inequality certified.';records.append(rec);continue
 # Symmetric AM-GM reduction of the Gram row bound to the unweighted factorial moment.
 ck(Q==sum(I[c][d] for c in range(nc) for d in range(nc) if c!=d))
 ck(Q<=sum(m[c]*row[c] for c in range(nc)));ck(sum(m[c]*row[c] for c in range(nc))<=G/2)
 U=[i for i in range(nx) if mult[i]];cuts=[];equalities=[];improved=0
 for D in subs(U):
  total_D+=1;out=[i for i in U if i not in D]
  v=sum((mu[i] for i in out),F(0));H=sum((mu[i]*mult[i] for i in out),F(0));Qout=sum((mu[i]*mult[i]*(mult[i]-1) for i in out),F(0))
  ck(H*H<=v*(H+Qout));ck(Qout<=Q);ck(Q<=G/2);ck(H<=G)
  slack=v*(H+G/2)-H*H;ck(slack>=0)
  tt=v/G;hh=H/G
  root=(ar(tt)+(ar(tt*tt+2*tt)).sqrt())/2;coarse=ar(F(3,2)*tt).sqrt()
  ck(root.is_finite() and coarse.is_finite())
  if slack==0:ck((root-ar(hh)).contains(0));equalities.append(dict(D=list(D),v=str(v),H=str(H),t=str(tt),H_over_G=str(hh)))
  else:ck(root>ar(hh))
  ck(hh*hh<=F(3,2)*tt)
  rootcap=root if tt<F(2,3) else arb(1);coarsecap=coarse if tt<F(2,3) else arb(1)
  improvement=coarsecap-rootcap
  if 0<tt<F(2,3):ck(improvement>0);improved+=1
  else:ck(improvement.contains(0))
  cuts.append(dict(D=list(D),outside_indices=out,v=str(v),H=str(H),t=str(tt),H_over_G=str(hh),quadratic_slack=str(slack),sharp_root=str(root),coarse_sqrt=str(coarse),capped_root=str(rootcap),capped_coarse=str(coarsecap),capped_improvement=str(improvement)))
 rec.update(union_indices=U,union_mass=str(sum(mu[i] for i in U)),enumerated_D=len(cuts),strictly_improved_cuts=improved,root_equality_cases=equalities,all_cuts=cuts)
 records.append(rec)
# Fixed-data global-route demand comparison; no new geometric cases.
LL,MM,hh=sp.symbols('L M hh',positive=True)
ck(sp.expand(3*LL**2/(8*MM)-LL*hh+2*MM*hh**2/3-(2*MM/3)*(hh-3*LL/(4*MM))**2)==0)
demand_summary=[]
for LLv in (F(1),F(2),F(4)):
 for MMv in (F(2),F(8),F(32)):
  error=3*LLv*LLv/(8*MMv);maxgap=F(0);maxactive=None;witness=[];active_count=0;positive_count=0
  for rec in records:
   if not rec['row_gate']:continue
   Gv=F(rec['G']);mass=list(map(F,rec['mass']));mu=list(map(F,rec['mu']));B=rec['capture']
   for cut in rec['all_cuts']:
    outside=cut['outside_indices'];tt=F(cut['t']);hv=F(cut['H_over_G'])
    psi=sum((mass[c]/Gv*max(F(0),1-LLv*sum(mu[i]*B[c][i] for i in outside)/mass[c]) for c in range(len(mass))),F(0))
    demand=max(F(0),1-MMv*tt);gap=demand-psi
    ck(psi>=max(F(0),1-LLv*hv));ck(tt>=F(2,3)*hv*hv);ck(demand<=psi+error)
    if gap>0:positive_count+=1
    if gap>maxgap:maxgap=gap;witness=[dict(family=rec['name'],D=cut['D'],t=str(tt),h=str(hv),d=str(demand),psi=str(psi))]
    elif gap==maxgap and gap>0:witness.append(dict(family=rec['name'],D=cut['D'],t=str(tt),h=str(hv),d=str(demand),psi=str(psi)))
    if demand>0 and tt>0:
     active_count+=1;maxactive=gap if maxactive is None else max(maxactive,gap)
    cut.setdefault('demand_comparisons',[]).append(dict(L=str(LLv),M=str(MMv),d=str(demand),psi=str(psi),gap=str(gap),error=str(error)))
  demand_summary.append(dict(L=str(LLv),M=str(MMv),universal_additive_error=str(error),maximum_positive_gap=str(maxgap),positive_gap_cut_count=positive_count,nontrivial_active_cut_count=active_count,maximum_nontrivial_active_gap=None if maxactive is None else str(maxactive),maximizers=witness))
result=dict(scope='Finite atomic-source, finite actual interval/square families. Common-source checked, but no original active cloud/Gamma/history or Lebesgue receiver certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r494_numeric.py',seconds=time.perf_counter()-start),checks=checks,legal_families=5,discarded_families=1,total_source_subsets_D=total_D,formulas=dict(Gram='sum_D!=C I_CD/sqrt(mC*mD)<=1/2',factorial_moment='Q=int mult(mult-1)<=sum_C mC rowgamma_C<=G/2',quadratic='H^2<=v int_out mult^2=v(H+Qout)<=v(H+G/2)',root='H/G<=(t+sqrt(t^2+2t))/2,t=v/G',comparison='Root alone is better only for0<t<2/3; min(1,root)<=min(1,sqrt(1.5t)) always, strict for0<t<2/3.',interpretation='H is family mass outside D; small outside volume v/G forces most total family mass inside D. This is not an original active-cut flow estimate by itself.'),demand_parameter_cases=1080,demand_summary=demand_summary,global_error_scope='Integrating d_D<=psi_D+epsilon against the full record measure rho costs epsilon*R. No tail restriction is needed for this algebra; actual original rho and geometric reduction remain proof obligations.',records=records,decision='The exact root improves the coarse information for small outside volume. Both the 2-parent boundary and 4-parent common-source boundary attain a nonzero equality, giving useful finite sharpness evidence. No global/history budget follows from these examples.',errors='All captures, masses, Gram conditions and quadratic inequalities exact Fraction; only root diagnostics use256-bit Arb. No LP rerun, random scan or new dimensions beyond2.')
(ROOT/'r494_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;5 legal families,120 source subsets,1080 demand comparisons,1 excluded family;no LP')
