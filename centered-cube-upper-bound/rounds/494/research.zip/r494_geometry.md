# R494：全实际停止云的固定容量 cut 比较

本稿给出一项统一于来源集的定量比较：利用整族低 Gram，把原 cloud cut 转为同一实际记录上的质量加权子父厚来源需求，误差为可任意缩小的 \(aR\)。它不先丢掉 large-cloud 尾，不要求由最大父承担整族需求，也不把新的子父标签当作来源限制后的原接受流。子父累计需求的根阶来源价仍未证明。

## 1. 同一实际流与两个明确 cut 函数

取 R492 完整真实停止前一跳流
\[
\rho=\sum_{j=0}^{N-2}\Gamma_j,\qquad
|\rho|=A_{p,N}-\langle1,e\rangle\le R.
\]
论证也适用于其任意原正限制，包括 R493 good；若使用完整 \(\rho\)，本稿是 R493 large-cloud 处理的替代，不再叠加其尾费。\(J,H\)、原来源、阶段、接受记录及历史完全不变。

每条记录保实际族 \(F_0\)，记
\[
U_F=\bigcup_{C\in F_0}Q_C,\quad
G_F=\sum_Cm_C,\quad
\sum_{E\ne C}\gamma_{CE}\le\tfrac12.
\]
允许局部来源密度上帽 \(M1_{U_F}/G_F\)，行质量至多1，统一来源列容量为 \(\Lambda\mu\)。其 cut 函数定义为
\[
\Delta_{\rm cloud}(M,\Lambda)=
\sup_D\left[\int\left(1-M\frac{\mu(U_F\setminus D)}{G_F}\right)_+d\rho
-\Lambda\mu(D)\right].
\tag{1}
\]
先定义与 \(D\) **无关**的实际子父需求测度
\[
\Theta(dC)=\int\sum_{C\in F_0}\frac{m_C}{G_F}\delta_C(dC)\,d\rho,
\qquad |\Theta|=|\rho|.
\tag{2}
\]
这是给原记录附一个真实子父标签，不改变链。设
\[
\Delta_{\rm child}(L,\Lambda)=
\sup_D\left[\int(1-L\pi_C(D^c))_+\,d\Theta(C)-\Lambda\mu(D)\right].
\tag{3}
\]
(3) 不是最大父 cut，也不是重新按 \(f1_D\) 构造的接受流。

## 2. 整族几何给统一可吸收误差

固定一条记录和任意可测来源集 \(D\)，写
\[
t=\frac{\mu(U_F\setminus D)}{G_F},\quad
h=\sum_C\frac{m_C}{G_F}\pi_C(D^c)\in[0,1],\quad
N_F(z)=\sum_Cc_C(z).
\]
由低 Gram 及 \(2\sqrt{m_Cm_E}\le m_C+m_E\)，
\[
\int N_F(N_F-1)d\mu
=\sum_{C\ne E}\gamma_{CE}\sqrt{m_Cm_E}\le G_F/2.
\]
Cauchy 在 \(U_F\setminus D\) 上给
\[
(G_Fh)^2\le G_Ft\int_{D^c}N_F^2d\mu
\le G_F^2t(h+1/2).
\]
于是包括 \(t=0\) 情形在内，
\[
\boxed{t\ge\frac{h^2}{h+1/2}\ge\frac23h^2.}
\tag{4}
\]
这是同一任意集中来源的质量估计，不使用边界体积或密度帽。

对任意 \(L\ge1\)，凸性给
\[
\sum_C\frac{m_C}{G_F}(1-L\pi_C(D^c))_+\ge(1-Lh)_+.
\]
另一方面，
\[
\begin{split}
(1-Mt)_+-(1-Lh)_+
&\le(Lh-Mt)_+\\
&\le\left(Lh-\tfrac23Mh^2\right)_+
\le\frac{3L^2}{8M}.
\end{split}
\]
最后一步是完成平方，不假设最大值点落在 \([0,1]\)。因此逐记录、逐 \(D\) 都有
\[
\boxed{(1-Mt)_+
\le\sum_C\frac{m_C}{G_F}(1-L\pi_C(D^c))_+
+\frac{3L^2}{8M}.}
\tag{5}
\]
积分再取同一个 \(\sup_D\)，得到本稿主式
\[
\boxed{\Delta_{\rm cloud}(M,\Lambda)
\le\Delta_{\rm child}(L,\Lambda)+\frac{3L^2}{8M}R.}
\tag{6}
\]
特别 \(L=2\)、\(M\ge3/(2a)\) 时，附加误差至多 \(aR\)。\(M\) 与维数和累计代数无关。\(M\ge3/2\) 又确保各记录局部容量总质量至少1。此误差统一于所有来源集，不是逐 cut 各收一笔 \(R\)。

该比较在完整 \(\rho\) 上成立，故无需 R493 的 \(G_F/m_B\) 对数截断。它是一笔可吸收的 cut 比较误差，并不声称整条原流已有来源付款。

## 3. 真实中心局部化能做到哪里

对 \(L>1\)，(3) 的正需求只来自
\[
E_D^{1/L}=\{C:\mu(Q_C\setminus D)<m_C/L\}.
\]
在这些同一真实中心上，令 \(m_C^D=\mu(Q_C\cap D)\)，则
\[
(1-1/L)m_C<m_C^D\le m_C,
\quad (1-1/L)q< m_C^D/R_C^n\le\lambda.
\tag{7}
\]
这是来源 \(f1_D\) 的真实质量匹配，半径和中心不变。但旧 \(y,z\notin U_F\) 不蕴含 \(y,z\notin D\)，原停止权也没有成为新场的接受权。

目前合法的需求列仍只如下。置
\[
a_j=\min(1,e^{\sqrt n}b_0^j),\quad b_0=2rS/T,\quad
\mathfrak d_{p,N}=\sum_{j=0}^{N-2}a_ja_{j+1}^{p-1}=O(\sqrt n+1).
\]
实际 \(\Gamma_j\) 的停止权至多 \(a_{j+1}^{p-1}\)，最大父 Palm 输出密度至多 \(a_j\)。最大父子项的质量权至多1；其余子项 \(m_C/G_F\le m_C/m_B\)。自然参考下的 lower PPP 和真实闭尾给
\[
\frac{\nu(dC)}T\int_{m_B\ge m_C}\frac{I_{BC}}{m_B^2}\nu(dB)
\le b_0\nu(dC).
\]
于是，保全部标记到正上放步骤后，
\[
\Theta\le(1+b_0)\mathfrak d_{p,N}\nu.
\tag{8}
\]
再用 (7) 与真实 selector 中心容量，只有
\[
\int(1-L\pi_C(D^c))_+d\Theta
\le\frac{S(1+b_0)\mathfrak d_{p,N}A_n}{1-1/L}\mu(D),
\quad A_n=1+n\log(b/a).
\tag{9}
\]
它仍为 \(O(n^{3/2})\) 源列，不能当作所需 \(\Lambda=O(\sqrt n\,\mathrm{polylog}\,n)\)。成功输出只在实际 Palm 正支配后使用自然 PPP，没有声称条件独立。

## 4. 完整费用和唯一剩余步骤

若后续能在同一 \(\Theta\) 上证明
\(\Delta_{\rm child}(2,\Lambda)\le\varepsilon X+B_\varepsilon W\)，则 (6) 给整族缺额至多
\(aR+\varepsilon X+B_\varepsilon W\)。接入 R491 的恢复时要保 \(2a<1-\eta_{\rm rec}\)；若已经采用 R493 尾分拆，则相应为 \(2a<1-\eta_{\rm rec}-2\varepsilon_{\rm tail}\)，不能把两种替代路径的费用都默认消失。现有初始 \(\langle1,e\rangle\) 仍按原一次价计。

本轮没有证明上述子父需求预算。唯一具体缺桥是用原共同来源、old-pair 排斥与真实成功条件，在 **(2) 的累计停止加权子父测度** 上改善 (9)，而不是把它当作 \(f1_D\) 的原接受流。式 (6) 保留全族而非只用最大父；两种未付缺额没有已证排序。附加误差已明确可吸收；剩余 \(\Delta_{\rm child}\) 仍未付，不以其改名宣布闭合。

## 5. 本机精确核验

指定 Python 数学环境实际运行以下代码，输出 `PASS 112 exact full-cloud/child cut comparisons and 1 symbolic square; no history certification`。有限模型只有共同及私有来源质量，核一般证明的代数接口；不是连续 receiver 场或成功历史证据。

```python
from fractions import Fraction as F
from itertools import product
checks=0
for l in (2,3,4):
 c=F(1,4*l); priv=1-c; G=F(l)
 for bits in product((0,1),repeat=l+1):
  outside=[c*(1-bits[0])]+[priv*(1-bits[i+1]) for i in range(l)]
  t=sum(outside)/G
  ac=[outside[0]+outside[i+1] for i in range(l)]
  h=sum(ac)/G
  assert t>=F(2,3)*h*h
  for M in (F(4),F(16)):
   L=F(2)
   cloud=max(F(0),1-M*t)
   child=sum(max(F(0),1-L*a) for a in ac)/G
   assert cloud<=child+3*L*L/(8*M)
   checks+=1
import sympy as s
h,L,M=s.symbols('h L M',positive=True)
assert s.expand(3*L**2/(8*M)-(L*h-s.Rational(2,3)*M*h*h)
 -s.Rational(2,3)*M*(h-3*L/(4*M))**2)==0
print(f'PASS {checks} exact full-cloud/child cut comparisons '
      'and 1 symbolic square; no history certification')
```
