# R494：厚来源占比势的同链有符号停止账

本稿是实际最大父占比势的独立互补路线；它不适用于未经原 \(H\) 对齐的全族 child 混合势，不能直接替代主路线的质量加权全族 cut。

本稿保 R493 的完整 \(\rho=\sum_j\Gamma_j\)、good 门及 \(k^*\)，不改 \(J,H\) 或来源历史。得到一个确切的 cut 通量测试；未取得新的根阶付款。关键是原来源刷新本身正确，却不保证成功选择后的父占比漂移有利。

## 1. 占比势和保来源的实际转移

固定任意 \(\mu\)-可测 \(D\)，定义
\[
 s_D(A)=\pi_A(D),\quad f_D(A)=(2s_D(A)-1)_+,\quad
 \chi_D(\xi)=1_D(x),\quad \phi_D=\chi_D-s_D(A).
\]
其中 \(x\) 是原自然状态的附加来源，不能换成旧 \(y,z\)。R486 的 \(H\) 保父而新来源恰按 \(\pi_A\) 采样，故
\[
 H\chi_D=s_D,\qquad Hf_D=f_D,\qquad H\phi_D=0.
\]
实际成功 \(J\) 从原 raw 族选最大父，保同一个 \(x\)，所以
\(J\chi_D=\chi_D J1\)。这些性质不要求配置与来源独立；实际成功及旧记录均留在 \(J^{\rm rec}\) 中。

取 R491 的 \(p>1\)，定义原非负凸性差
\[
 r_j=\mathcal P^*(q_j^p)-q_{j+1}^p\ge0,
 \qquad \mathcal P=JH.
\]
它是完整 \(p\)-Jensen 差的密度，不是停止密度，也不是 R490 的入列线性缺陷。对任意有界非负父势 \(f\)，直接换序得
\[
\begin{aligned}
 \sum_{j<N}\int q_j^pef\,d\mathsf M
 ={}&\int f\,d\mathsf M-\int q_N^pf\,d\mathsf M
       -\sum_{j<N}\int r_jf\,d\mathsf M\\
 &+\sum_{j<N}\int q_j(\xi)^p
       J^{\rm rec}(\xi,d\omega)
       [f(B)-f(A)]\,d\mathsf M(\xi). \tag{1}
\end{aligned}
\]
此处使用 \(Hf=f\)，没有把 \(q_j^pe\) 换成反向 density death。R491 分带终端界给 \(\sum_j\int q_jd\mathsf M<\infty\)，故有界势的最后项绝对可和、终端趋零；(1)没有 \(\infty-\infty\)。

## 2. 原 thick cut 的准确净账

记(1)最后一项的无限和为 \(\mathcal J_p(D)\)，取 \(f=f_D\)。记
\[
 \mathcal E_p(D)=\sum_j\int r_j f_Dd\mathsf M\ge0,
 \quad \mathcal B_p(D)=\int_{\mathrm{bad}}f_D(B)d\rho\ge0.
\]
这两个量不是新收费槽；它们是同一个原式中保留的负项。由 \(\Gamma_j\) 的原到达停止密度定义，\(B\) 与刷新后状态具有相同父，故精确有
\[
\boxed{\begin{aligned}
 \int_{\mathrm{good}}f_D(B)d\rho-\Lambda\mu(D)
 ={}&\int f_D(1-e)d\mathsf M-\Lambda\mu(D)\\
 &+\mathcal J_p(D)-\mathcal E_p(D)-\mathcal B_p(D).
\end{aligned}} \tag{2}
\]
初始停止 \(\mathsf M(ef_D)\) 已减掉，不能再付一次。已有 large-cloud 坏支也没有重新收费。源起点满足
\[
 \int f_D(1-e)d\mathsf M\le\int s_Dd\mathsf M
 =\int_D D_t(z)d\mu(z),\qquad
 D_t(z)=\int t(A)c_A(z)\frac{dA}{R_A^n}\le SA_n,\quad A_n=1+n\log(b/a). \tag{3}
\]
这仍是线性维数帽，不是目标 \(\Lambda=O(\sqrt n\,\mathrm{polylog})\)。尤其不能先丢 \(-\mathcal E_p\) 再把(3)当根价。

## 3. 净漂移的双向来源通量及真正缺步

定义对称差商
\[
 c_D(A,B)=\begin{cases}
 [f_D(B)-f_D(A)]/[s_D(B)-s_D(A)],&s_D(B)\ne s_D(A),\\
 0,&s_D(B)=s_D(A).
 \end{cases}
 \qquad 0\le c_D\le2.
\]
对同一成功边，有精确源积分
\[
 s_D(B)-s_D(A)=
 \int\pi_A(du)\pi_B(dv)
 [1_{u\notin D,v\in D}-1_{u\in D,v\notin D}]. \tag{4}
\]
将(4)乘 \(c_Dq_j^p\) 并对原 \(\mathsf M J^{\rm rec}\) 积分，即为 \(\mathcal J_p(D)\)。这保完整原附源 \(x\)、当前父和 history；\(u,v\) 只是计算占比差的辅助积分，未取得任何旧历史。由于实际边质量有方向且接受权偏置，(4)两通量没有对称相消依据。

也可先看线性势：
\(s_D(B)-s_D(A)=\phi_D(\xi)-\phi_D(\omega)\)，因为 \(J\) 保 \(x\)。因此“来源刷新平均为零”只消掉 \(H\phi_D\)，没有消掉成功选择前后的这笔偏差。对 \(f_D\) 还必须保差商 \(c_D\)，不能把线性势的消去直接套到正部厚门。

当前需要的、可按原数据检验的比较是：对所有 \(D\)，用**同一**负 Jensen 差及成功排斥几何，控制
\[
 \int f_D(1-e)d\mathsf M+\mathcal J_p(D)-\mathcal E_p(D)
 \le\Lambda\mu(D)+aR+\epsilon X+C_\epsilon\sqrt n\log^A(n+2)W
       +\mathcal B_p(D). \tag{5}
\]
(2)说明(5)足以付原全部 cut；本稿没有证明(5)。这并非另一个分配余项定义，而是确定了占比势路线不可省的有向边通量及其应与起点、负项共同比较的位置。仅凭源刷新、列支配和 \(p\)-凸性差不足以判定它的符号。

R488 的 \(O(W)\) 方差是特定径向中心测试的结论，不可授给任意 \(D\)。此处对应来源测试的静态方差只是
\(\|\phi_D\|_2^2=\int\nu(dA)s_D(A)(1-s_D(A))\le\int_DD_t\,d\mu\)，仍为(3)量级。没有已证的统一几何测试价可补(5)。故本轮不宣称占比势给完整收缩或新增来源付款。

## 4. 一个有限代数判别，非原成功场反例

以下脚本中的 \(p=3\) 只核一般 \(p>1\) 的凸性恒等式，不调用后续 \(1<p\le2\) 的能量范围。

以下三状态模型保来源 incidence：\(A\) 捕获两个等质量来源，\(B\) 只捕获第一个；自然状态为 \(A0,A1,B0\)，参考权均为1。\(H\) 平均 \(A0,A1\)，在 \(B0\) 恒等；\(J(A0,B0)=c\)，其余为零。它是有限次双随机、保来源成功核，未实现原连续中心/low-Gram/旧 pair 等成功门。

取 \(D=\{0\}\)，则 \(f_D=(0,0,1)\)。\(q_1=(0,0,c),q_2=0\)，实际厚停止需求为 \(c^p\)，(2)起点项为零，漂移为 \(c\)，负 Jensen 项为 \(c-c^p\)。特别 \(c=1\) 时凸性差为零而漂移为一。它只证明抽象核与刷新代数不能无条件把该漂移付入 Jensen 差；不是针对原几何合同的反例。

```python
from fractions import Fraction as F
checks=0
def ck(x):
    global checks
    assert x
    checks+=1
for c in (F(1,4),F(3,4),F(1)):
    for p in (2,3):
        P=[[F(0),F(0),c],[F(0),F(0),F(0)],[F(0),F(0),F(0)]]
        f=[F(0),F(0),F(1)]
        q=[F(1)]*3;e=[1-sum(row) for row in P]
        lhs=F(0); drift=F(0); loss=F(0)
        for j in range(2):
            nxt=[sum(P[i][k]*q[i] for i in range(3)) for k in range(3)]
            lifted=[sum(P[i][k]*q[i]**p for i in range(3)) for k in range(3)]
            residual=[lifted[k]-nxt[k]**p for k in range(3)]
            ck(all(x>=0 for x in residual))
            lhs+=sum(q[i]**p*e[i]*f[i] for i in range(3))
            drift+=sum(q[i]**p*P[i][k]*(f[k]-f[i]) for i in range(3) for k in range(3))
            loss+=sum(residual[i]*f[i] for i in range(3))
            q=nxt
        ck(q==[F(0)]*3)
        ck(lhs==sum(f)+drift-loss)
        ck(lhs-sum(e[i]*f[i] for i in range(3))==c**p)
        ck(drift==c and loss==c-c**p)
print(f'{checks} exact Fraction assertions PASS; incidence/operator algebra only.')
```

本机实际隔离重放：`36 exact Fraction assertions PASS; incidence/operator algebra only.`。正文解析证明不依赖有限检查，未认证原几何成功场。
