#!/usr/bin/env python3
"""R519 real-Lebesgue periodic small-cube sources: actual alpha and slow mass."""
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import json,sys,platform,time
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,p,targets):
 S=sum(p,arb(0));remaining=S;dp=[arb(0) for j in range(n+1)];dp[0]=arb(1);P=[]
 for prob,target in zip(p[:-1],targets):
  ratio=prob/remaining;ck(ratio>0 and ratio<1);nd=[arb(0) for j in range(n+1)];hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-ratio)**m
   for inc in range(m+1):
    z=mass*w;nr=r+inc
    if nr==target:hit+=z
    else:nd[nr]+=z
    if inc<m:w=w*(m-inc)/(inc+1)*ratio/(1-ratio)
  P.append(hit);dp=nd;remaining-=prob
 out=[x*S**n for x in P];none=sum(dp,arb(0))*S**n
 ck((sum(out,arb(0))+none-S**n).contains(0))
 return out,none

def model(n,qpower,stage):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(1,10000*n*K);G=Q(4,3)
 base=arb(2).root(n);grow=aa(G).root(n);R=[base**(k-qpower) for k in ks];V=[grow*r for r in R]
 oldA=[r-1-2*aa(delta) for r in R];oldB=[r-1+2*aa(delta) for r in R]
 newA=[v-1-2*aa(delta) for v in V];newB=[v-1+2*aa(delta) for v in V]
 ck(all(1+2*aa(delta)<r<2-2*aa(delta) for r in R))
 ck(all(oldB[j]<newA[j] for j in range(K)));ck(all(newB[j]<oldA[j+1] for j in range(K-1)));ck(newB[-1]<1)
 Fold=[oldA[j]-8*j*aa(delta) for j in range(K)]
 Fnew=[newA[j]-(8*j+4)*aa(delta) for j in range(K)]
 S=1-8*K*aa(delta)
 bins=[Fold[0]]+[Fold[j]-Fold[j-1] for j in range(1,K)]+[S-Fold[-1]]
 ck(all(z>0 for z in bins));ck((sum(bins,arb(0))-S).contains(0))
 asc,none=firsthit(n,bins,ks)
 d_rev,none2=firsthit(n,list(reversed(bins)),[n-k for k in reversed(ks)]);desc=list(reversed(d_rev))
 ck((none-none2).contains(0));ck((desc[-1]-Fold[-1]**n).contains(0))
 C=1+arb(4).log();An=1+n*arb(2).log();threshold=1/An;baseK=arb(2).root(4)
 L=1000*n;factor2=Q(L-2,L)**n;factor3=Q(L-3,L)**n;beta_cell=Q(2*n,L+3)
 ck(beta_cell<Q(1,500));ck(Q(2*n)/beta_cell==L+3)
 def st(x):return x.str(35,radius=True)
 results=[]
 for name,P in [('ascending_k',asc),('descending_k',desc)]:
  ell=[q*p for p in P];beta_k=[ell[j]+(ell[j-1]/2 if j else 0)+(ell[j+1]/2 if j+1<K else 0) for j in range(K)];alpha=[b/C for b in beta_k]
  energy=sum((l*b for l,b in zip(ell,beta_k)),arb(0));discrete=sum((l*l for l in ell),arb(0))
  high=[];low=[];unclassified=[]
  for j,a in enumerate(alpha):
   if a>threshold:high.append(j)
   elif a<threshold:low.append(j)
   else:unclassified.append(j)
  ck(not unclassified)
  highP=sum((P[j] for j in high),arb(0));highScore=sum((ell[j]*beta_k[j] for j in high),arb(0))
  rows=[{'k':k,'P_arb':st(P[j]),'ell_arb':st(ell[j]),'alpha_arb':st(alpha[j]),'An_alpha_arb':st(An*alpha[j]),'class':'high' if j in high else 'low','K_target_arb':st(baseK.max(An*alpha[j]))} for j,k in enumerate(ks)]
  out={'shared_selector':name,'rows':rows,'real_window_Q_over_W_periodic_arb':st(energy),'discrete_label_sum_ell_squared_arb':st(discrete),'finite_Q_over_W_lower_arb':st(aa(factor2)*energy),'finite_Q_over_W_upper_arb':st(energy),'high_k':[ks[j] for j in high],'high_P_arb':st(highP),'high_receiver_nu_per_cell_arb':st(q*highP),'high_score_per_cell_arb':st(highScore),'high_score_fraction_periodic_arb':st(highScore/energy)}
  if name=='ascending_k':
   slowP=rapidP=unknownP=arb(0);slowScore=rapidScore=unknownScore=arb(0);details=[]
   for j in high:
    k=ks[j];remaining=n-k;prob=(Fnew[j]-Fold[j])/(S-Fold[j]);ck(prob>0 and prob<1)
    w=(1-prob)**remaining;target=baseK.max(An*alpha[j]);sp=rp=up=arb(0)
    for inc in range(remaining+1):
     z=P[j]*w;ratio=arb(2)**inc
     if ratio<target:sp+=z
     elif ratio>target:rp+=z
     else:up+=z
     if inc<remaining:w=w*(remaining-inc)/(inc+1)*prob/(1-prob)
    ck((sp+rp+up-P[j]).contains(0))
    slowP+=sp;rapidP+=rp;unknownP+=up;slowScore+=q*sp*beta_k[j];rapidScore+=q*rp*beta_k[j];unknownScore+=q*up*beta_k[j]
    details.append({'k':k,'additional_coordinate_probability_arb':st(prob),'slow_P_arb':st(sp),'rapid_P_arb':st(rp),'unresolved_P_arb':st(up)})
   out['full_high_classification']={'slow_P_arb':st(slowP),'rapid_P_arb':st(rapidP),'unresolved_P_arb':st(unknownP),'slow_receiver_nu_per_cell_arb':st(q*slowP),'slow_oldscore_per_cell_arb':st(slowScore),'slow_score_fraction_periodic_arb':st(slowScore/energy),'rapid_score_fraction_periodic_arb':st(rapidScore/energy),'finite_safe_slow_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*slowP),'finite_safe_slow_score_over_W_lower_arb':st(aa(factor3)*slowScore),'details':details,'reason':'ascending first-hit filters only earlier coordinates; above current radius remaining coordinates retain categorical conditional law'}
  else:
   ck(K-1 in high)
   tp=P[-1];ts=ell[-1]*beta_k[-1];kt=baseK.max(An*alpha[-1]);ck(kt>1)
   out['top_high_slow_certified_subset']={'k':n,'P_top_arb':st(tp),'alpha_top_arb':st(alpha[-1]),'K_top_arb':st(kt),'mass_ratio_mV_over_m':1,'reason':'each coordinate already contains both adjacent source cubes; V<2-2delta reaches no third source cube','receiver_nu_per_cell_arb':st(q*tp),'oldscore_per_cell_arb':st(ts),'score_fraction_periodic_Q_arb':st(ts/energy),'finite_safe_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*tp),'finite_safe_score_over_W_lower_arb':st(aa(factor3)*ts),'finite_safe_top_score_fraction_full_Q_lower_arb':st(aa(factor3)*ts/energy),'unclassified_remainder':'other high descending layers not given rapid/slow classification'}
  results.append(out)
 print('MODEL',stage,'n',n,'q',q,'C',st(C),'1/An',st(threshold),'top alpha',results[1]['top_high_slow_certified_subset']['alpha_top_arb'],'top slow score/Q',results[1]['top_high_slow_certified_subset']['score_fraction_periodic_Q_arb'],flush=True)
 return {'stage':stage,'n':n,'q0':q,'candidate_k':ks,'delta':str(delta),'G':str(G),'h':'1/8','1_plus_u_arb':st(baseK),'a':1,'b':2,'An_arb':st(An),'C_arb':st(C),'threshold_1_over_An_arb':st(threshold),'R_top_arb':st(R[-1]),'V_top_arb':st(V[-1]),'combined_allowed_coordinate_mass_arb':st(S),'combined_survival_probability_arb':st(S**n),'combined_stripe_discard_upper_bound_exact':str(8*n*K*delta),'no_eligible_P_arb':st(none),'selectors':results,'finite_embedding':{'L':L,'W':str(L**n),'source_cell':'[-2,L+1]^n, one R516-valid real source cell','source_cell_side':L+3,'beta_exact':str(beta_cell),'cell_side_identity':'ell=n*b/beta=L+3 with b=2','center_distance_to_macro_cell_boundary_at_least':2,'source_grid':'{0,...,L-1}^n, cubes halfdelta, each mass1','old_receiver_cells':'[0,L-1]^n repeated selected admissible phase region','safe_receiver_cells':'[1,L-2]^n','safe_receiver_factor_over_W_exact':str(factor3),'interior_source_factor_over_W_exact':str(factor2),'alpha_error_on_safe_centers':0,'scope':'safe old parent source indices all interior, where finite L equals periodic L exactly; not an arbitrary small source-cell claim'}}

def main():
 start=time.perf_counter();models=[model(16,1,'probe'),model(64,2,'pressure'),model(64,4,'expanded_density')]
 out={'scope':'bounded true-Lebesgue positive small-cube sources; exact geometric combinatorics and strict Arb alpha/high/slow certificates, not a general asymptotic theorem','environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r519_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS real-window alpha, positive high-slow receivers, actual mass-neighborhood classification and finite-cell embedding')
if __name__=='__main__':main()
