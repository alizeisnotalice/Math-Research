# R519：完整体积概率律的真实平方与捕获延迟缺陷

本稿只研究一个候选：在整个非端点 slow 动作区间取显式体积概率律，端点统一选 b。已得到端点的一次 W 付款及一个真实 grouped 平方上界；尚未得到 bulk 的多对数来源付款。旧盒系数变小不构成净收缩，下面明确核对这一点。

## 1. 固定数据与同一个概率族

完全沿 /tmp/r518_proof.md：原 μ、源格、L_i、α_i、真实质量 m_B、t_B≤S 不变；slow 已与 low、rapid 互斥。令

K_B=max{1+u,A_n α_i(B)},   m(B,V_B)<K_B m_B,
V_B=min{G^(1/n)R_B,b},   1<G≤2,
C_*=S[1+log(G γ^(1+h)r)].

保原相位 j=floor(log_γ(m(B,R)/m_B)/h)，真实 A_ij 与 B=Σ_ij||A_ij||²。概率动作在来源抽样前确定。

将 slow 分成 top={R_B≥b/G^(1/n)} 与 bulk=slow\top。在 top 取 δ_b。在 bulk 写 g=(R/R_B)^n∈[1,G]，取

π_B(dg)=2g/(G²−1) dg.                                      (1)

这是质量为 1、支持完整 [R_B,V_B] 的概率核。它不使用来源点，也不假设扩大盒继承原密度帽。相位密度帽仍由 R518 的真实质量分组给出。

## 2. 端点已经可以实付

对剩余 top，q_B≤G q(B,b)，故固定原测试场的费用

E_top=Σ_i∫top ψ_i(B)dB≤CG∫top t_B q(B,b)dB≤CSGW.             (2)

最后一步仅用固定 b 的 Lebesgue 中心卷积列≤S。top 与此前 low、rapid 互斥，不重新收其费用。

若将 top 保留在上述完整概率族中，它的实际 grouped 平方也满足

B_top≤S²W.                                                (3)

证明：每格 top 各相位场相加为实际窗场 A_i,top。逐点 A_i,top≤S，且 ∫A_i,top(y,σ)dσ≤S，均由共同半径 b 的空间卷积给出；真实质量窗的起点任意，不影响这两个界。因相位场非负，Σ_j||A_ij,top||²≤||A_i,top||²≤S²μ(C_i)。源格互斥后只付 W。不能把 bulk 与 top 在同一格的交叉项省略；第 5 节保留它。

## 3. 一个可证明的 bulk 平方估计

对 bulk 的每个真实动作，将空间盒分成 Q_B 与 Q(B,R)\Q_B，真实新质量窗保持原样。得到

A_ij,bulk=O_ij+J_ij,

其中 O 为旧空间盒部分，J 为实际新壳部分。置

L_i,bulk=∫bulk k_B dB,   Q_bulk=Σ_i||L_i,bulk||²,
a=Eπ[g^−1]=2/(G+1),

Γ_B=2/(G²−1) ∫_1^G [m(B,g^(1/n)R_B)/m_B−1] dg,
D_cap=Σ_i∫bulk t_B q_B Γ_B dB.                              (4)

**已证命题：**

B_bulk≤a²(1+3h)Q_bulk+2C_* D_cap.                           (5)

这是同一个实际概率族的相位平方估计；D_cap 不是已付来源预算。

### 证明旧盒项

将每个 O_ij 的窗共同移回 jh。对单个动作剩余位移 δ∈[0,h)，空间系数是旧系数/g。由 (1)，π(dg)/g=2dg/(G²−1)，其总质量恰为 a，且归一后是 [1,G] 上均匀概率律。因此移回后的全部旧盒场为 a 倍旧父场的概率窗平移。

这里需要的上界只用正窗几何。令 T(x)=(1−|x|)_+。对 |d|≤h≤1，有

T(x+d)≤T(x)+h[T(x)+T(x−1)+T(x+1)].                         (6)

在 |x|≤1 时括号≥1；在 1<|x|≤1+h 时，所需增量 h−(|x|−1)≤h(2−|x|)；其余处显然。固定来源 y，对旧质量坐标正测度应用 (6)，每个平移相关项由 Hilbert Cauchy≤旧窗平方，得随机剩余窗场的平方≤(1+3h)旧平方。动作之间的概率独立积分保每父总权 1，不重新选择半径。

各 O_ij 经酉平移后仍非负，因此

Σ_ij||O_ij||²≤Σ_i||Σ_j U_(-jh)O_ij||²
              ≤a²(1+3h)Q_bulk.                            (7)

这一步无额外 J 倍数，亦未将移回场冒作实际质量窗。

### 证明新壳项

每个实际相位 A_ij,bulk≤C_*，所以逐点

(O_ij+J_ij)²−O_ij²=J_ij(2O_ij+J_ij)≤2C_*J_ij.             (8)

真实新质量窗的 σ 积分为 1。Tonelli 保真实 μ、原 t 和原中心标签，给

Σ_ij∫J_ij dμ dσ
=Σ_i∫bulk∫ [t_B/(gR_B^n)] [m(B,g^(1/n)R_B)−m_B] π(dg)dB
=D_cap.                                                   (9)

将 (7)—(9) 合并即 (5)。没有以薄 Lebesgue 壳推断小 μ 质量。

## 4. Γ 的确切几何收益与 slow 能给的上界

对 y∈Q(B,G^(1/n)R_B)\Q_B 定义真实进入体积参数

g_B(y)=(2||y−B||_∞/R_B)^n∈(1,G].

径向质量连续，Tonelli 给精确的捕获延迟公式

Γ_B=2/[(G²−1)m_B] ∫_(Q(B,G^(1/n)R_B)\Q_B) [G−g_B(y)] dμ(y). (10)

因此同样数量的新质量，越靠近候选区间末端进入，对实际平均壳的费用越小；末端的集中来源必须按真实进入参数计权，而不是忽略其质量。这是概率平均在原积分中的明确收益。

仅用本轮 slow 条件，严格可得的仍只有

0≤Γ_B<a(K_B−1).                                          (11)

在 D={bulk: K_B=A_nα_i(B)} 上，写 E_D=Σ_i∫_(D∩E_i)ψ_i(B)dB，则

∫_D t_Bq_B Γ_B≤a[A_n E_D/C−∫_D t_Bq_B],                   (12)

若 max 由 1+u 取得，则 Γ_B<au。保正截断或分支后使用 (12)，不可将其套到全部 slow。式 (12) 右端一般带 A_n，未给多对数付款；它明确显示 α 的旧源相关尚未在平均壳重复中兑现。积分延迟权可改善具体输入，但 slow 的末端质量上界没有自动限制质量集中在候选区间前部。

## 5. whole slow 的实际预算及不成立的收缩推论

同一个完整概率族由 (1) 与 top 的 δ_b 构成。在相位 Hilbert 直和中用三角不等式，而非删掉 top/bulk 交叉项，得到

√B≤√B_bulk+√B_top
   ≤sqrt[a²(1+3h)Q_bulk+2C_*D_cap]+S√W.                    (13)

或对任意 ε>0，

B≤(1+ε)[a²(1+3h)Q_bulk+2C_*D_cap]+(1+ε^−1)S²W.            (14)

这给一个完全合法、无 miss 的候选及其真实误差账。

**a<1 不能被报成同 Q 的净收缩。** 在纯旧盒、窗无残移的代数极限，比较场是 aL，其 cross score 为 aQ、平方为 a²Q。Cauchy 恰好是 (aQ)²=Q(a²Q)；归一化后系数完全抵消。若直接套 R518 的更粗 G、J 回代，还多出 G²J，(5) 的固定系数更不足以吸收。故即使只看 Γ 很小，也不能由 (5) 宣称完整目标已闭合。

本候选唯一未付的几何环节可准确写成：对同一个原 α 与 (1) 的动作族，联合控制 **旧盒—新壳的实际相位交叉** 与 (10) 的同来源重复，强到打破上述等号情形，或直接得到 B_bulk≤polylog(n)W。单独将 D_cap 换成另一个名称、仅用 Γ≤a(K_B−1)、或把 a² 当信用，均不能完成这一步。

已获得的实际付款是 (2)/(3)；新的准确几何连接是 (5)/(10)，它保留进入时刻对原来源积分的折扣。当前未证明 bulk 多对数来源预算，也未证明可吸收的同 Q 递推。本轮到此停止。

## 6. 本机精确检查

实际运行本机 Python Fraction，输出 `PASS 36 Fraction checks: capture-delay, phase positivity, shell square, no-gain normalization; algebra only`。这些是有限代数检查，不冒作任意 μ 几何定理或高维实验。

```python
from fractions import Fraction as F
T=lambda x:max(F(0),1-abs(x))
def ip(A,B): return sum(w*v*T(s-t) for s,w in A for t,v in B)
checks=0
G=F(2);a=2/(G+1);h=F(1,12)
for capture in (F(1),F(5,4),F(3,2),F(2)):
 for dm in (F(0),F(1,3),F(3)):
  gamma=2*dm*(G-capture)/(G*G-1)
  assert gamma>=0 and gamma<=a*dm;checks+=1
for shift in (F(0),F(1,24),h):
 L=[(F(0),F(1)),(F(2,3),F(3,2)),(F(5,4),F(2,3))]
 Q=ip(L,L)
 for phase in ((0,1,2),(2,0,1),(1,1,1)):
  O=[[] for _ in range(3)];aligned=[]
  for k,(s,w) in enumerate(L):
   O[phase[k]].append((s+phase[k]*h+shift,a*w))
   aligned.append((s+shift,a*w))
  BO=sum(ip(x,x) for x in O)
  assert BO<=ip(aligned,aligned);checks+=1
  assert ip(aligned,aligned)<=a*a*(1+3*h)*Q;checks+=1
for O,J,C in ((F(1,4),F(1,3),F(1)),(F(2,3),F(1,3),F(1)),(F(0),F(1),F(1))):
 assert (O+J)**2-O**2<=2*C*J;checks+=1
for Q in (F(1),F(7,3),F(25)):
 B=a*a*Q
 assert (a*Q)**2==Q*B;checks+=1
print('PASS',checks,'Fraction checks: capture-delay, phase positivity, shell square, no-gain normalization; algebra only')
```
