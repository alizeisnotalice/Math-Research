# R519 独立 PRE：真实分相最小平方的对偶与可实现逼近

先独立审命题，未读r519作者。可用接口是：真实概率动作的phase字段集合凸；对其Hilbert范数闭包取最近场即给精确对偶，不需假设连续动作π达到最小值。分相物理核虽不连续，但从右连续，归一半径的dyadic向上取整保实际phase并强逼近所有真实字段。有限动作可给实际最小概率核、可测线性oracle及可核gap；不自动产生多对数预算。仅本文件写入。

## 1. 真实对象与基本条件

保R518同一slow输入：真实μ=f dx、W有限、固定原t_B≤S与R_B、V_B=min(G^(1/n)R_B,b)、a>0。旧m_B≥qa^n>0，E_slow真实Lebesgue且有限测度。源格可有限截断或可数；H取各格、各实际phase的L²(μ_i×dσ)直和，J有限。

对实际R∈[R_B,V_B]，定义

K(B,R)=e_(i,j(B,R)) k_t(B,R)，
j(B,R)=floor{log_γ[m(B,R)/m_B]/h}。

所有新源盒、真实新mass窗及原t保留。概率核π_B联合可测、来源pair前选定，每父总概率1。A(π)=∫K(B,R)π_B(dR)dB，目标B(π)=||A(π)||²=Σij||Aij||²。它不是相位移回后的比较场平方。

可取a.e. Borel版本；质量随(B,R)连续，t/R_B等参数可测，H可分。单父核有统一界||K||≤Sa^(−n)√W，故Bochner积分与下面支配极限成立。零中心/零场单列。不同μ、维数下这些存在性常数不提供统一预算。

## 2. 相位边界：右逼近保实际可实现性

固定B，m(B,R)连续非减且在动作域正。物理k_t(B,R)在H本体中连续：立方体边界μ零，质量窗端点连续。但乘e_j后在阈值可能跳跃。

关键是**从右连续**：z(R)连续非减，floor在z=jh时采用新phase j，从R的右侧逼近时phase最终相同；平台也不破此性质。令R_s(B)=R_B+s(V_B−R_B)，s∈[0,1]；用s_k=ceil(2^ks)/2^k向上取整，显式包含1。则K(B,R_s_k)→K(B,R_s)强H，V=R_B时全部为同一动作。

对任意真实π，将每个动作向上量化到这些2^k+1个moving-radius候选，得真实概率π_k，所有候选仍在本父动作域、每父总概率1。由统一核界及有限中心测度，A(π_k)→A(π)强H。因此有限嵌套候选的最优值下降到原实际问题的inf，可能没有统一速率。

这不是有限**公共固定半径**ρ覆盖：候选R_s(B)随B变化，不能据其个数认证R518的共同测度费用。

直接把每phase复制为闭区间[jh,(j+1)h]则不保证等价。它在阈值把同一半径额外放到下phase；若质量在该阈值有平台，平台内部的下phase副本不必由本父合法动作逼近。只凭物理核L2连续不能删除这个label问题。除非另证每个所用副本的fiberwise可测单边逼近，否则该闭复制是外松弛，小最小值不提供原实际π的上界见证。右网格方案不需要这种松弛。

## 3. 不假设π达到的精确对偶

令C={A(π):π真实可行}，它非空、凸、有界。取其H范数闭包Cbar，Hilbert最近点A*存在且唯一；可由凸性与平行四边形使最小化列Cauchy直接证明。并有

〈A*,A−A*〉≥0（A∈Cbar）。

记 b*=inf_(π实际) B(π)=||A*||²。对任意F∈H，定义

m_F(B)=inf_(R∈[R_B,V_B])〈F,K(B,R)〉。

右候选族给此inf等于一个可数可测cost的inf；可选首个cost≤m_F+ε的候选，得到来源前可测ε-oracle。因此

inf_(A∈C)〈F,A〉=∫m_F(B)dB，

b*=sup_(F∈H){2∫m_F dB−||F||²}。                        (D1)

弱对偶是平方完成；取F=A*由投影变分式得到相等，不用无价minimax或π的紧性/达成。上确界在闭包投影场达到，但不据此宣称存在真实最优π。可数oracle一般是inf，不必达到min。

单独dual是下界工具，不能由一个小dual值证明最小平方小。实际π的字段平方才是可行上界；本接口提供几何最优条件和可核上下gap，不是把未付预算换名。

## 4. 有限动作存在性、一阶条件与真实改进方向

对有限moving-radius候选，π由有限个可测simplex权p_l(B)给出。若各候选核强可测且有统一H界，权集合在L∞(E)有限乘积中weak-*紧；其字段映射对每个H测试向量weak连续。故弱下半连续平方取得最小字段，实际概率核存在，字段唯一而动作权未必唯一。

实际最优π*的一阶条件为

〈A*,A(π)−A*〉≥0，所有π可行；
π*_B几乎处处只在〈A*,K(B,R)〉=m_(A*)(B)的动作上取权。 (D2)

有限候选min可测且达到。一般连续半开phase若真实最优π存在，同式仍必要充分；没有π时不能虚构argmin。**最小化不能沿用R512最大化的同场确定性选择技巧**：线性score最小选择仅给一阶等号，平方正余项可使其比混合更大，不能免费纯化。

给定实际π与A，令r=||A||²−∫m_A≥0。dual下界D(A)给

0≤B(π)−b*≤B(π)−D(A)=2r。                              (D3)

有限候选的可测最小score选择ν给Δ=A(ν)−A，则保持实际可行的概率混合π_τ有

B(π_τ)=B(π)−2τr+τ²||Δ||²。

这是实际可用的线性oracle方向/最优gap见证；近似oracle保其明确误差。它只优化辅助raw平方，不改变原history，也不提供根阶目标所需的统一数值上界。

## 5. 有限网格证书不得倒向连续问题

有限网格可行上界B_N≥b*有效。其dual D_N(F)=2∫min_grid cost−||F||²只保证是有限网格最优值的下界；因为min_grid≥m_full，D_N(F)≥D_full(F)，不能直接当连续问题下界。

若实际另证ε_N(F)≥∫(min_grid−m_full)，则D_N(F)−2ε_N(F)才是连续问题的有效下界。固定输入、固定F时右网格与支配收敛给ε_N趋0，但没有统一维数/输入速率。有限网格stationarity也不等于全动作stationarity。这个方向必须留在任何数值或优化证书中。

## 6. 实际数学核验与停止范围

实际使用指定本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`。SymPy精确核一中心两候选(1,0)、(0,2)的混合最优p=4/5、字段(4/5,2/5)、平方4/5及dual等值，核4组非最优权的gap系数2。Fraction在含平台、阈值与终端的连续非减z样例上核63组向上dyadic候选phase与连续核误差。stdout `PASS exact finite convex optimum/dual-gap constants; 63 right-dyadic phase tests including plateau and terminal boundary`，退出0。

有限向量/label模型只核凸代数及边界机制，不是原子接收几何，也不认证真实预算。可用结果为(D1)—(D3)、保实际右网格及有限动作可实现最优。尚缺对真实slow几何的统一平方上界；交付后再按授权核作者，当前未读作者。

## 7. 作者proof/geometry追加后审

独立PRE完成后获授权读取 `/tmp/r519_proof.md`、`/tmp/r519_geometry.md`。端点T⊂slow的实际原score付款CSGW正确：qold≤Gq_b、α≤1且固定b全空间中心卷积积分W。low/rapid/T互斥，完整已付常数CS(1+2G)W不重复；新候选P只在剩余U优化。

proof采用闭包投影而不声称π达到，非负dual优化场及m(F)可测countable oracle方向正确；有限网格下证书警示、gap与实际混合下降公式准确。§4支持不等式是P≤B0的等价几何要求，未被声称已证。最小化没有虚构确定性同场纯化。

geometry的bulk体积律π(dg)=2g/(G²−1)dg归一正确。π/g总质量a=2/(G+1)，归一后uniform g；分相移回的旧空间窗残移均在[0,h)，两父残移差绝对值≤h。tent上界(6)及正场合并给旧项Σ||Oij||²≤a²(1+3h)Qbulk，无额外J且不把相比场当物理窗。真实phase帽及A=O+J非负给壳平方差≤2C*J，故 Bbulk≤a²(1+3h)Qbulk+2C*Dcap。Dcap为同一µ的实际进入时刻折扣，尚非已付预算。

捕获延迟公式Γ=2/[(G²−1)m]∫shell(G−g_B(y))dµ正确；Tonelli中的y只用于分析既定动作律，不是来源后选择半径。slow只给Γ<a(K−1)，按K=Anα的分支(12)仍带An，不自动收缩。top实际grouped平方≤S²W亦正确；whole候选中的top/bulk cross用三角或带ε不等式保留。proof先付top删去、geometry保完整top概率是两种账法，不得双取信用。

a²绝不单独构成净Q收缩：同概率律的旧score也缩为aQ，归一抵消的等号核查正确；作者未声称Dcap或平方已多对数付清。几何窗口能量可用实际软平方更细估计，不要求列L1帽，全部原history/来源保持。

本人实际以指定Python-I从正文经stdin执行，输出 `PASS 96 exact finite-oracle gap and descent checks; no geometric budget claim` 及 `PASS 36 Fraction checks: capture-delay, phase positivity, shell square, no-gain normalization; algebra only`，均退出0。这些是有限代数证书，不代替真实高维输入预算。当前主proof/geometry未见实质错误；numeric真highslow尚待另审及最终冻结。
