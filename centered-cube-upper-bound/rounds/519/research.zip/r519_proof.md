# R519 主稿：固定原慢支的实际平方选择与可核验误差

本稿保持 R518 的真实来源、源格、窗口和每父概率，不把辅助优化的数值最优当作一般预算。设 H=直和_{i,j} L²(μ|C_i×dσ)，v(B,s) 是实际半径 R=R_B+s(V_B−R_B) 的原 t_B 核，置于真实相位 j=floor(log_γ(m(B,R)/m_B)/h)；其余分量为零。域为完整 slow。所有符号与 R518 相同。

## 1. 端点不占用未知平方信用

先从 slow 中取 T={R_B≥b/G^(1/n)}，其余为 U，三类 low/rapid/T 依此互斥。固定外半径 b 给 m(B,b)≥m_B 且 b^n/R_B^n≤G，故 q_B≤G q(B,b)。于是原交叉 score

E_T=C∫_T α_B t_B q_B dB≤CG∫_T t_B q(B,b)dB≤CSGW。

最后一步直接由真实 Lebesgue 中心和 Tonelli：∫_{R^n} b^(−n)μ(Q(B,b))dB=W。此付款不需要新密度位于原带，不需要来源密度帽，不重算 α。现在 U 上完整 g∈[1,G] 可用，低层、rapid、T 共价≤CS(1+2G)W。若在 U 上使用 R518 比较，原式中的 1+G 换为1+2G，其他因子原样保留。

## 2. 不预设无限维强对偶的实际字段优化

令 C 为所有来源抽样前可测概率动作形成的 A=∫_U∫v(B,s)π_B(ds)dB，定义 P=inf_{A∈C}||A||²。这仍是实际相位平方和，不是比较场。C凸非空。固定输入 n,a,q>0，E的Lebesgue测度≤A_nW/q；slow动作质量≤Kmax λ b^n，故单父H范数有有限统一界 S sqrt(Kmax λ b^n)/a^n。可积性在固定输入成立，常数不拿来声称维数一致预算。

取范数闭包 cl C。最小化序列由平行四边形恒等式是Cauchy，故存在唯一最小范数点 A*∈cl C，||A*||²=P。沿线段微分给 <A*,A−A*>≥0 对所有 A∈cl C。所有实际字段非负，故A*非负。

定义 m(F)=inf_{A∈C}<F,A>。平方完成给任何F∈H与A∈C，||A||²≥2m(F)−||F||²。在F=A*处等号，因此

P=sup_{F∈H, F≥0}[2m(F)−||F||²].

不宣称最优概率核达到，不引用未核验minimax交换。若A*仅为极限，任意正容差可用实际C中的字段逼近。

## 3. 可测动作 oracle 与准确证书

归一半径s取D=([0,1]∩Q)∪{1}。固定B，质量函数连续非减；原核在L²中连续，相位标签从右连续。包括端点1后，每个动作由D从右逼近，故对任何F，inf_{s∈[0,1]}<F,v(B,s)>=inf_{s∈D}<F,v(B,s)>。

可数成本均可测。选择第一个成本≤inf成本+δ的动作，得到真实中心可测选择；利用E有限，δ→0后

m(F)=∫_U inf_{s∈D}<F,v(B,s)>dB。

窗口L²连续依赖真实质量的正下界 qa^n；源盒对μ的边界测度为零，因为μ≪Lebesgue。没有将离散半径网格自动当作全动作域。

对任意实际可行A，Q_A=||A||²，g_A=Q_A−m(A)≥0，得到严格夹逼

max(0,Q_A−2g_A)≤P≤Q_A。

若只有有限半径子集D_N，所得m_N≥m；Q_A−2(Q_A−m_N)不能冒充全连续域的下证书。必须另给m_N−m上界或精确连续oracle。这个方向决定数值证书是否合法。

取达到或近似m(A)的真实动作场V，Δ=Q_A−<A,V>。任意η∈[0,1]的混合仍真实可行，且

||(1−η)A+ηV||²=Q_A−2ηΔ+η²||V−A||²。

故可直接给下降量和余隙，不以求解器状态代替证书。所有核均在同一个原输入上，不另选来源或历史。

## 4. 这对当前几何目标的具体要求

如果能对上述同一成本证明 m(F)≤sqrt(B0)||F||，对所有非负F∈H成立，则P≤B0。反之P≤B0也给该支持不等式（用A*）。这提供精确的几何见证要求，但本稿未证明它：B0须是polylog(n)W，或者给足够小、能通过R518的G²J/(1−3h)²回代的同Q系数。

不能只证明某平均外半径把旧盒系数变为a_G<1，就声称获得收缩：若比较旧score也相应缩小a_G，归一化会抵消。真正收益必须来自同一实际场的联合交集结构或有来源价格的oracle控制。

本轮完整母账仍未闭合。上述优化方法与端点付款不证明慢支平方P的根阶所需预算，也不移用486链的谱能量。

## 5. 本机精确证书接口检查

下列有限正向量仅验证优化证书的方向及混合恒等式，不声称是立方体输入。四列代表两父各两个动作；矩形上的二次最小值通过内点、四边与四角精确枚举。它不替代完整连续动作oracle。

```python
from fractions import Fraction as F
from itertools import product
from random import Random

def dot(x,y):return sum((a*b for a,b in zip(x,y)),F(0))
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def scale(t,x):return tuple(t*a for a in x)
def sub(x,y):return add(x,scale(-1,y))
def clamp(t):return max(F(0),min(F(1),t))
checks=0
for seed in range(8):
 rng=Random(seed)
 v=[tuple(F(rng.randrange(1,9),8) for _ in range(4)) for _ in range(4)]
 b=add(v[0],v[2]);d=sub(v[1],v[0]);e=sub(v[3],v[2])
 def field(p,q):return add(b,add(scale(p,d),scale(q,e)))
 dd=dot(d,d);ee=dot(e,e);de=dot(d,e);bd=dot(b,d);be=dot(b,e)
 cand=list(product((F(0),F(1)),repeat=2));det=dd*ee-de*de
 if det:
  p=(-bd*ee+be*de)/det;q=(-be*dd+bd*de)/det
  if 0<=p<=1 and 0<=q<=1:cand.append((p,q))
 for p in (F(0),F(1)):
  cand.append((p,clamp(-(be+p*de)/ee) if ee else F(0)))
 for q in (F(0),F(1)):
  cand.append((clamp(-(bd+q*de)/dd) if dd else F(0),q))
 optimum=min(dot(field(p,q),field(p,q)) for p,q in cand)
 for p,q in ((F(1,4),F(3,4)),(F(1,2),F(1,2)),(F(1),F(0))):
  A=field(p,q);Q=dot(A,A)
  V=add(min(v[:2],key=lambda x:dot(A,x)),min(v[2:],key=lambda x:dot(A,x)))
  gap=Q-dot(A,V);D=dot(sub(V,A),sub(V,A))
  assert gap>=0;checks+=1
  assert max(F(0),Q-2*gap)<=optimum<=Q;checks+=1
  eta=min(F(1),gap/D) if D else F(0)
  new=add(scale(1-eta,A),scale(eta,V));actual=dot(new,new)
  assert actual==Q-2*eta*gap+eta*eta*D;checks+=1
  assert actual<=Q;checks+=1
print('PASS',checks,'exact finite-oracle gap and descent checks; no geometric budget claim')
```
