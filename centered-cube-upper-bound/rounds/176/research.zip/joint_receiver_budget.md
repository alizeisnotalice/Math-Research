# R176：共享储备联合亏损与接收点覆盖的准确费用

本次有界攻坚未证明低 capture 原正交通的一般根阶预算。新结果是固定接收点的实际双储备联合容量界：两份归一测度不能同时饱和，其联合质量至多 1/4，更一般幂矩有显式最优标量常数。它没有独立支付 raw。另对本次尝试的“去掉原门后以共同 K0 正尺度包络覆盖 receiver”步骤，核出该包络必有线性 n 的 L1 费用；这定位了此步骤为何不能给所需 polylog companion，而不是原一般命题的反例。

## 1. 量词及本次实际对象

沿用 R176 task_contract 与冻结 R175 core_joint_geometry.md CJ1–11，不重建模型。固定原 seed/window、x、V、j，nu≤beta、zeta=beta−nu；sum_V beta_V≤f。原 K0_j 对整个外 y 积分共同，但可以依 x,j；原 nu、beta 在 y 积分前冻结。actual soft s>1−2^(−1/n)>0，故有限点 K0>0。所有下式均用原 actual alpha、U、q、同一来源及原 D，不做独立来源选择。

原低 capture companion 在 canonical target R_eta、原 bad 内槽、严格低 score、原 Z_t、high/good/rho、history、唯一 j 与原时间窗上取值。记其原值为 C_low。仍保留两个外来源部分 C_nu+C_zeta，不将 nu 外槽遗漏；所用三点核分别是冻结 CJ9 与 CJ10（可采用 CJ11 的较粗 quartic 项）。以下关于 tau、mu 的结论只对这些实际密度成立，不先取独立来源上确界。

R173 已付能量仍只给

\[
\operatorname{Raw}^{J,+}_{low}
\le {32\Lambda\over3}\sqrt{{nW_\beta\over2K}\,C_{low}}.
\tag{JR1}
\]

hard16/3、outer2Lambda 各一次；负信用完全不动。目标仍是 C_low=O(polylog(n))W_beta，或直接对原正交通证明 source 根阶价加 epsilon E∫q dx；下文不假设这些结论。

## 2. 实际双储备的联合容量定理

令

\[
A_0=\int K0(x-y)\zeta(dy),\quad
G_0=q-\int K0\,d\nu,\quad
B_y=\int_{\mathsf B_y}K0\,d\nu,\quad
\gamma_y={\alpha_yJ\nu\over D_y}.
\tag{JR2}
\]

共同 FIRST 与原 same-alpha 恒等式不仅分别给 gamma_y≥G0、gamma_y≥B_y，而且给更强的加法关系

\[
0\le A_0\le G_0,\qquad
\gamma_y=G_0+\int(K0-U_y/D_y)d\nu\ge G_0+B_y.
\tag{JR3}
\]

理由是原 bad_y 上 U_y=0，补集上 K0−U_y/D_y≥0；A0≤G0 来自 zeta≤f−nu 与 K0f≤q。这没有从 signed 账另扣负项。

当 G0>0 时，按原实际密度定义

\[
\tau(dy)={K0(x-y)\over\gamma_y}\zeta(dy),\qquad
\mu_y(du)={K0(x-u)1_{\mathsf B_y}(u)\over\gamma_y}\nu(du),
\quad m_y=\|\mu_y\|={B_y\over\gamma_y}.
\tag{JR4}
\]

**定理。** 对每个 r>0，在固定 x,V,j 下有

\[
\boxed{\int m_y^r\tau(dy)
\le {A_0\over G_0}\,{r^r\over(r+1)^{r+1}}.}
\tag{JR5}
\]

特别，实际联合测度满足

\[
\boxed{\int\tau(dy)\mu_y(du)\le {A_0\over4G_0}\le{1\over4}.}
\tag{JR6}
\]

证明：直接保留实际密度，而非先把两份测度分别替换为质量一，得到

\[
\int m_y^r\tau(dy)
=\int K0(x-y)\zeta(dy)\,{B_y^r\over\gamma_y^{r+1}}
\le\int K0(x-y)\zeta(dy)\,{B_y^r\over(G_0+B_y)^{r+1}}.
\]

令 z=B_y/G0。标量 z^r/(1+z)^(r+1) 在 z=r 处达到最大 r^r/(r+1)^(r+1)，故得 JR5。r=1 给 JR6。常数是这个标量放松的准确常数，不声称原物理输入能够达到等号。

等价地，JR3 给 1/gamma_y≤(1−m_y)/G0，故外密度受内来源占比的缺口控制：

\[
\tau(dy)\le {1-m_y\over G_0}K0(x-y)\zeta(dy).
\tag{JR7}
\]

因此内储备接近饱和时，外储备实际密度必同时变小。这是原共同输入的联合约束，不是两份独立 subprobability 的性质。JR5 使用 full actual bad 质量；再限制到原 Z_t、低 score 和低 capture 只能减小联合质量，但没有改变 mu 的定义或原 Pi。

边界：G0=0 时严格 K0>0 和 A0≤G0 强制 zeta=0，联合外 zeta 部分为零，JR6 左端取零而不计算 A0/G0。对所有 gamma_y>0 的行仍定义 mu_y，包括 G0=0 的情形；gamma_y=0 时 bad 的 nu 质量为零，取 mu_y=0。故 C_nu 不会因 G0=0 被错误删掉。若人为扩展到 K0 可零的 hard 端点，零 K0 来源必须另留；本定理不处理该扩展。

## 3. 为什么这个联合亏损还没有列价

R175 CJ10 的 actual x,y,t,v,u 核不是一个与 y,u 无关的常数。即使使用其 quartic 项，仍为

\[
F_{x,y,t,v,u}=
{p_y^2(J\nu)^2(T\Delta_v)^2d_v^4w_t(y,v)w_t(y,u)
\over144D_y^2Q_v^2J_ve_t(y)^2K0(x-y)K0(x-u)},
\tag{JR8}
\]

并必须保留原门以及 CJ8 中与原粗界的 min。JR6 仅控制 ∫tau mu；不能据它断言 ∫F tau mu≤某个共同核，更不能在 actual dx 积分中免费收取 1/4 的总费用。事实上把 JR4 密度展开后两个 K0 分母恰抵消，回到原 same-input 系数；这说明密度本身有用，但单独的质量帽不能替代其与 F 的空间相关性。

固定 j 的 JR5–7 也不能直接对 j 求和免价。tau_j 的分母及 K0_j 均随 j 改变；若逐 j 各收常数，原菜单可能给 n+2 的费用。这里保留原 sum_j、唯一指示、window/history 与 actual dx，不据联合质量改善宣称消除了它们。

## 4. 范围注记：去门正尺度包络的费用

这只核查本次尝试的一个步骤，不是实际输入反例。取 n≥3、b=2a、j=0、L=R=g∈[a,b]、合法 s*=1−4^(−1/n)，令 ell=1+log n 及 c=(1−s*+s*phi(1/2))ell^(1/(2n))。原 RT6 给 Hhat(g)=max(a,min(b,cg))。由 0≤phi(1/2)≤1，有 4^(−1/n)≤c≤ell^(1/(2n))，从而 1/2<c<2；实际尺度范围恰为

\[
H_-=a\max(1,c),\quad H_+=b\min(1,c),\quad
\log(H_+/H_-)=\log2-|\log c|.
\tag{JR9}
\]

产品核的 hard 项权重为 (1−s*)^n=1/4。对 h_H=H^(−n)1_(2||z||infty≤H)，按立方体尺度壳直接积分得 ∫sup_(H∈[H_-,H_+])h_H=1+nlog(H_+/H_-)。因此

\[
\int\sup_{g\in[a,b]}P_{s_*,\widehat H(g)}(z)dz
\ge\tfrac14\{1+n\log2-n|\log c|\}
\ge\tfrac14\{1+n\log2-\max(\log4,\tfrac12\log\ell)\}.
\tag{JR10}
\]

所以若先删掉 high/residual/来源相关门，再以这个正尺度包络的 L1 常数支付 companion，仅此步骤已有线性 n 费。这里没有断言同一输入在这整个尺度族满足 FIRST/high/residual，没有给原 traffic 下界，也没有反驳保留物理门或只处理 bulk 的根阶路线。此注记只排除本次尝试中“去门后靠共核归一免费恢复 dx”的推理。

## 5. 明确未证步骤及检查点结论

实际缺口仍是对 C_nu 与 C_zeta 同时证明接收点预算。其中 zeta 部分现在可以使用 JR5–7 的联合亏损，但必须把它与 JR8、原 min、high、same-alpha residual 和 actual hard/source 资格一起积分；nu 外槽没有这份外储备亏损，仍用冻结 CJ9 的实际密度。没有证明它们的和≤polylog(n)W_beta，也没有证明 epsilon receiver 吸收。

本次尝试的具体断点在“逐 x 的实际储备质量控制”到“自适应 receiver 空间覆盖”之间：若去门正包络，JR10 有线性 n 费；若保留门，尚缺利用其物理三点位置削减该覆盖费的估计。JR6 的 1/4 常数不能抵消维数费，也不能凭它给几何级数吸收，除非另建原交通到同一未付量的可迭代支配；本稿没有该支配。

未重新跑数值、未扩大反例搜索、未改原 Pi/alpha/source 或消费 signed 负项。最终交付为 JR5–7 的实际共同输入中间引理与 JR10 的具体步骤成本核验；一般根阶结果保持未证，不登记新的已付 raw 分支。
