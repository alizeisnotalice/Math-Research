"""Finite numerical checks; the analytic inequalities are proved in the notes."""
from pathlib import Path
from fractions import Fraction as F
import json, sys, time
sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
start=time.time()
stages={'initial':['1','.5','.1'], 'pressure':['.999','.01','.001'], 'expanded':['.0001','.000001','.25','.75']}
rows=[]
for dps in (40,60):
 mp.mp.dps=dps
 c0=(1-mp.exp(-1))/2
 for stage, aa in stages.items():
  for astr in aa:
   a=mp.mpf(astr); T=1/(2*a)
   def integrand(t):
    E=mp.exp(-t); B=mp.exp(-1/a+t)
    return (mp.mpf('.5')-a*t)**2 * ((E-B)/2)**2/(1-(E+B)/2)
   nodes=sorted(set([mp.mpf(0),min(T,mp.mpf(1)),min(T,mp.mpf(8)),min(T,mp.mpf(64)),T]))
   ji=2/a*mp.quad(integrand,nodes)
   jo=(1-mp.exp(-1/a))*(1/(4*a)+1+2*a)
   bound=1/(16*c0*a)
   A=mp.mpf('.25')+1/(8*(1-mp.exp(-1)))
   rows.append(dict(stage=stage,a=astr,dps=dps,J_inside=str(ji),J_outside=str(jo),inside_bound_pass=bool(ji<=bound),fisher_bound_pass=bool(ji+jo-1<=A/a+2*a)))
# Exact arithmetic tests of the shared-source capacity scalar maximum.
capacity=[]
for stage, rs in [('initial',[1,2,3]),('pressure',[4,8]),('expanded',[16,32])]:
 for r in rs:
  ceiling=F(r**r,(r+1)**(r+1))
  zs=[F(j*r,100) for j in range(501)]+[F(1,10**9),F(10**9)]
  assert all(z**r/(1+z)**(r+1)<=ceiling for z in zs)
  assert F(r)**r/(1+F(r))**(r+1)==ceiling
  capacity.append(dict(stage=stage,r=r,points=len(zs),exact_pass=True))
assert F(11,6)+F(2,5)==F(67,30)<F(9,4)
assert all(r['inside_bound_pass'] and r['fisher_bound_pass'] for r in rows)
out=dict(scope='Finite scalar quadrature and exact rational checks, not a global bound or interval certificate.',fisher=rows,capacity=capacity,rational_constant='e>8/3 implies I(phi)<67/30<9/4',runtime_seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(fisher_cases=len(rows),capacity_cases=len(capacity),all_pass=True,runtime_seconds=out['runtime_seconds'])))
