# R176 独立几何审查：尺度bulk、硬面及实际外费用

状态：已读本轮task_contract.md；以下先于本轮作者稿独立筛查准确命题，不认证一般交通根阶预算。仅修改责任文件，不运行数值、不改作者、Git/spawn/PDF。等待指定成稿一次后审。

## 1. 原核及尺度导数的精确量词

沿原h=1_[−1/2,1/2]，w(r)=integral_0^1 exp(−|r|/a)da，phi=h*w，b_s=(1−s)h+s phi。三者h,w,phi均为概率密度。固定s∈[0,1]，q_(s,H)(z)=H^(−1)b_s(z/H)，P_(s,H)=product_i q_(s,H)。以下导数是保持s固定的d/dlogH，不能偷偷包含原s(x)的变化，也不是对x求导后把H写为H(x)。

对s>0定义

    kappa_s(r)=−1−r s phi'(r)/b_s(r),
    psi_s(r)=kappa_s(r)+(1−s).

s=0时在b_0有质量的hard core上kappa=−1、psi=0；core外0/0不定义而不影响其加权积分。phi'=w(r+1/2)−w(r−1/2)连续。hard边界的密度取值不影响分布导数，不能把边界跳误当作普通phi导数。

一维分布/有限signedmeasure准确恒等式为

    d q_(s,H)/dlogH
    =kappa_s(z/H)q_(s,H)(z)dz
       +(1−s)/2[delta_(H/2)+delta_(−H/2)].               (S1)

每面系数是(1−s)/2；正面项没有多乘H或1/H。积分分部integral r phi'=−1（指数尾消去端点）给

    integral kappa_s b_s=−(1−s),
    integral psi_s b_s=0.

令Fbar_(s,H)为均匀选择i∈{1,...,n}及符号±，该坐标固定为±H/2，其余坐标按q_(s,H)独立分布的概率测度。product规则因此给

    d(P_(s,H)dz)/dlogH
      =[sum_i psi_s(z_i/H)]P_(s,H)(z)dz
         +n(1−s)[Fbar_(s,H)−P_(s,H)(z)dz].             (S2)

S2中“面”必须与其减去的体积项一起保留，平均2n面与外面的n(1−s)不能混成单面费用。该product独立性只用于核本身的Lebesgue积分，不假设原nu、beta或Pi坐标独立，更不把其score当成原delta阈值score。

固定H的Fbar与Pdz互相奇异，面总质量n(1−s)，bulk总质量−n(1−s)。全导数total variation（signedmeasure绝对质量口径）至少2n(1−s)。所以即使中心化bulk是root，整个尺度导数仍可能线性；原strictsoft下界s>1−2^(−1/n)并不强迫1−s=O(n^(−1/2))。

## 2. uniform二阶矩：9/4常数独立核算

父级在作者稿前提供精确标量候选，本节逐式独立核算。设Laplace_a(r)=exp(−|r|/a)/(2a)，g_a=h*Laplace_a，a∈(0,1]，则phi=integral_0^1 2a g_a da，权重积分1。记

    J(g)=integral r² g'(r)²/g(r)dr,
    I(g)=J(g)−1=integral(−1−r g'/g)²g dr.

对|r|≤1/2，

    g_a(r)=1−exp(−1/(2a))cosh(r/a)
          ≥c0=(1−e^(−1))/2,
    |g_a'(r)|≤exp(−(1/2−|r|)/a)/(2a).

用r²≤1/4及双侧指数积分≤a，得到J_in≤1/(16c0 a)。对|r|≥1/2，直接积分单指数尾得

    J_out=(1−exp(−1/a))(1/(4a)+1+2a).

因此

    I(g_a)≤A/a+2a,
    A=1/4+1/[8(1−e^(−1))].

尺度score对同一混合权2a满足逐点Jensen/Cauchy，故

    I(phi)≤integral_0^1 2a I(g_a)da
           ≤11/6+1/[4(1−e^(−1))]<9/4.                  (S3)

a趋0的1/a误差恰被原混合权2a积分，不遗漏小a费用。s>0时精确有

    integral psi_s² b_s
      =s²[integral r²phi'²/b_s−1]
      ≤s[I(phi)+1]−s²≤9/4.                             (S4)

最后一步因I(phi)+1≤13/4，s(13/4)−s²在[0,1]递增，端点为9/4。s=0按psi=0直接成立，不写0·infinity。该常数对所有s∈[0,1]有效，不只strictsoft，s趋0/1无退化。

在固定product核下，psi独立同分布且均值0；所以

    integral |sum_i psi_s(z_i/H)|P_(s,H)(z)dz
      ≤sqrt(n integral psi_s²b_s)≤(3/2)sqrt(n).          (S5)

这是核的绝对质量界，不能据此认证原来源交通或输入f重加权之后的坐标独立。

## 3. 正L1输入、adaptive H的可用与不可用形式

对任意f∈L1，固定s,H的bulk signedkernel与f卷积合法，S5及Tonelli/Young给其L1 norm≤(3/2)sqrt(n)||f||1。固定H的face概率卷积也给L1 norm≤||f||1（固定面按Fubini定义a.e.）。S1/S2可先对光滑测试函数证，再按有限measure与L1卷积的分布身份解释。

令B_(s,H)(z)=[sum psi]P。对任意可测H(x)∈[a,b]及固定anchor H0∈[a,b]，若对象是bulk路径积分，则

    integral dx |integral_H0^H(x)(B_(s,u)*f)(x)du/u|
      ≤integral_a^b ||B_(s,u)*f||1 du/u
      ≤(3/2)sqrt(n)log(b/a)||f||1.                      (S6)

可测端点的正向/反向路径绝对值都由完整区间控制，无须H(x)正则。该证明适用于任意正L1，取绝对值后Tonelli；不是在adaptive H(x)处瞬时导数的L1界，也不是sup_H|B_(s,H)*f|的相同界。

原s=s(x)也自适应。S5虽逐s常数统一，S6的proof仍用同一个固定s的卷积核对全dx积分；不能把逐s L1界变为对s(x)的同价。若用s菜单/正包络，必须证点态比较并列出节点总数与比较误差；由P的网格比较不能直接省掉signedscore或hardface误差。当前没有新增“adaptive s免费”定理。

对face项，若直接在H(x)处取面卷积，则选择了依x变化的超平面trace。固定H的a.e.x/Fubini并不自动对任意measurableH(x)保留相同代表元或列界。可先用光滑f写点态式，任意L1的推广仍须有共同尺度积分/原选择几何的uniform控制；不能仅靠固定face是概率测度就写adaptiveface算子的L1 norm为1。

## 4. 可合法取得的尺度积分face费用仍是线性

本节先固定一个不依x变化的s，任意正L1输入下在该s的共同a.e.x集合上把辅助H于[a,b]积分；光滑f时则可逐x使用其原s(x)。sameinput FIRST给F(H)=(P_(s,H)*f)(x)≤q(x)。因为kappa_s≥−1，非负f下S1/S2可写

    n(1−s)(Fbar_(s,H)*f)(x)≤dF(H)/dlogH+nF(H).

对光滑f逐点，或对固定s的任意L1输入按非负尺度积分/Fubini，可得

    n(1−s) integral_a^b(Fbar_(s,H)*f)(x)dH/H
      ≤F(b)−F(a)+n integral_a^b F(H)dH/H
      ≤[1+nlog(b/a)]q(x).                              (S7)

任意L1且s=s(x)的推广须另证所有s共享的好集/尺度AC：仅逐s的a.e.x命题不能直接代入s(x)。本检查点在S7只认证光滑f的自适应s或任意L1的固定s；不声称已完成公共好集证明。它控制尺度积分而非任意选定尺度的face值，费用是O(n)q，不是root。这保留原真实receiver qdx，不把face反向负体积项重复当信用。对一般原正交通还需匹配其实际系数和history/来源槽；S7本身不等于R175 lowcapture budget。

同一face/scale区间若在不同j或不同window重复覆盖，S7和S6都须按实际overlap或共同预算计费。原唯一j只有在保留原共同门并得到与j无关的一致原行上界后才可合并；分别归一的tau_j仍不能免费求和。

## 5. Astra新双储备联合质量：作者前筛查

固定x,V,j，K0在整个y积分共同，zeta=beta−nu，A0=K0zeta，G0=q−K0nu≥A0，B_y=integral_bad_y K0nu。原samealpha精确给

    gamma_y=G0+integral(K0−U_y/D_y)nu≥G0+B_y.

这是比R175分别两个下界更强的同时和下界。沿实际密度tau=K0_y zeta/gamma_y，mu_y=K0_u nu_bad/gamma_y，对r>0、G0>0，

    integral tau(dy)||mu_y||^r
      =integral K0_y zeta(dy) B_y^r/gamma_y^(r+1)
      ≤(A0/G0) r^r/(r+1)^(r+1).                       (S8)

原因是x^r/(1+x)^(r+1)最大在x=r。r=1时实际联合tau(dy)mu_y(du)总质量≤A0/(4G0)≤1/4。strictsoft下G0=0强制zeta0，联合量0；mu仍在gamma>0定义，不能省掉nu外槽。硬K0zero端点另留，不据0/0归一。

S8是固定j行质量，不是CJ9–11带kernel后的列预算。其r是正实矩参数，非本轮clock斜率r(t)。mu依y且tau依x,V,j，原实际密度不能换成自由独立概率来源。没有无费sum_j、receiver dx或window积分，也没有因此支付nu外槽。

## 6. 可覆盖正尺度包络的明确线性成本：作者前筛查

Astra准确修订候选取n≥3，b=2a，s*=1−4^(−1/n)，j0，L=R=g∈[a,b]。记ell=1+logn，

    c=(1−s*+s*phi(1/2))ell^(1/(2n)),
    Hhat(g)=clip_[a,b](cg).

有4^(−1/n)≤c≤ell^(1/(2n))，n≥3给1/2<c<2。因此Hhat的准确全范围是

    Hlo=a max(1,c),  Hhi=b min(1,c),
    Hhi/Hlo=2exp(−|logc|).

原先拟直接包含[a,b4^(−1/n)]的说法在c>1时下端失败，不采用；特别nlogc的上项含(1/2)logell，无理由对所有n断言c≤1。修订范围无此错误。

混合product核的全hard组权(1−s*)^n=1/4。对H∈[Hlo,Hhi]，正kernel尺度包络满足

    integral dz sup_g P_(s*,Hhat(g))(z)
      ≥(1/4) integral dz sup_H H^(−n)1_(||z||infty≤H/2)
      =(1/4)[1+nlog(Hhi/Hlo)]
      ≥(1/4)[1+nlog2−max(log4,(1/2)logell)].             (S9)

中间等式由内cube质量1及外shell的n dH/H积分得到；闭/开边界差Lebesgue零。该下界随n线性，准确记录拟用正scale-envelope工具的费用。它不证明原actualFIRST可实现反例，也不证明交通难度下界；它与固定s的bulk路径root界相容，因为整kernel包含硬面及取sup操作。

## 7. 检查点与后审义务

主命题独立筛查结论：S1/S2面常数与方向正确；uniform Varpsi≤9/4通过；固定s的bulk路径积分可用S6；实际adaptive s(x)不能由统一常数免费替换；面项和j/window费用必须单列。S8、S9准确候选成立，但仅给行容量常数与工具成本，未给lowcapture一般付款。

等待父级/Astra/Sol准确成稿后逐式审真实source/receiver系数、同input/alpha、边界和全部外费用。当前没有将连续root估计当作general root，也没有使用新未知gate掩盖R175余项。先行检查点交付后停止等待，不扩研究。


## 8. joint_receiver_budget.md完整后审

已在第5–6节作者前独筛之后，实读JR1–JR10及全部范围说明；本次实读版本已将尺度工具下界压为§4范围注记。绑定SHA256：

    04b94a3ff60ebaa493847887e07b5208a76ea7463ce68619d187a5783cd3892f

判断：明确量词下通过，无需实质修订。JR1是原EJ与actual companion的接口，不预先给C_low收费；hard16/3及outer2Lambda各一次，source/beta/receiver measure和nu外槽保留。

JR2–JR4的samealpha加法储备gamma≥G0+B_y是准确原捕获恒等式推论，A0/G0用同一固定j、对整y共同的K0容量。JR5的r任意正实数，其标量最大值及A0/G0系数正确；JR6的1/4是联合实际tau(dy)mu_y(du)质量，而非两个自由probability分布的独立乘积。JR7不等式方向正确：gamma−B≥G0给1/gamma≤(1−m)/G0。限制原Zt、strictscore或lowcut只减小实际联合质量，不改变归一密度。

G0=0的strictsoft边界明确使zeta=0而非强制alpha0；mu仍在所有gamma>0定义，gamma0使badnu0才取零。因此nu外槽不会漏掉。硬zero-K情形未纳入该扩展，文中明确另留，没有除零或免费消失。

JR8 quartic核144系数、两个K0分母、Jv分母、et²与d⁴完全与R175已核结构一致，说明1/4质量不能单独控制带该核的列积分；没有把min原/cubic/quartic比较省成一般独立常数。逐j归一的费用与潜在n+2、window/history及actualdx均完整保留。

JR9的clip范围使用1/2<c<2，lower端max及upper端min方向正确；未沿用早期可能失败的全[a,b4^(−1/n)]覆盖断言。JR10立方壳积分、hard组权1/4及n|logc|界正确。它只记录删门正尺度包络的明确线性费用，没有宣称同一个原输入满足该整族FIRST/high/rho，也没有给原traffic反例或bulk根界反例。

末节正确区分固定x的联合容量与原自适应receiver列预算，并保留C_nu+C_zeta及samealpha物理核。1/4常数不能自动几何级数吸收，没有原量到同一未付量的可迭代映射就不能领取root价格。故本稿中间引理成立，但不登记新增raw付款，不闭合R175余项。

继续等待尺度成稿后审，不跑数值、不扩研究。


### 8.1 S7适用范围纠正

父级指出先行S7若只按每个固定s分别Fubini，则不能直接声称任意L1下可代入实际s(x)。已将第4节准确收窄为光滑f的逐点adaptive s及任意L1的固定s。若成稿需一般adaptive s的尺度积分，可将P_s展开为有限2^n个hard/phi子集核，对这些核及其face/scale导数取共同好集，证明同一集合上全s的尺度AC后再代入；这个有限展开若仅用于公共零集不产生2^n预算，但若当作正包络求和则必须另收费。后审会核此点；不以逐s一致二阶常数替代公共好集或实际adaptive积分预算。


## 9. scale_face_geometry.md完整后审与端点修正验收

已先完成第1–4节作者前独立筛查，再实读SF1–SF14及全部适用范围。判断：明确量词下通过。独审指出的唯一待修句为SF12绝对face路径费原写log(H2/H1)，而两端点未假定有序；作者已改为|log(H2/H1)|，本次实读确认。FTC本身继续用oriented积分，没有改符号或漏反向边界。

SF2–SF4的mean、product微分、每面(1−s)/2及n(1−s)项与第1节一致，完整TV至少2n(1−s)也正确。SF5–SF9的core/outer精确Laplace卷积、混合CS、a趋0可积、s0直接处理及uniform9/4完整通过。SF7最后严格界用e>5/2即可，主稿另给e>8/3推出67/30也准确，二者不矛盾。

SF10比主稿的“绝对值在路径外”版本更强，确实给路径内绝对值积分；固定s及任意可测H*(x)的Tonelli证明合法，真实dx没有被换成任意probability measure。不是在adaptive H处瞬时导数，也不免费支付原s(x)。若原不同j只选一个端点、无额外j相关密度，可先合成H*再用同一界；对R175分别归一的tau_j不适用，作者已准确区别。

SF11的分布transport符号正确：−partial_x(xh_H)=eta_H−h_H，mixed修正须再加s(h_H−phi_H)。对C1测试的梯度项及后一个signed修正都保留，没有对任意L1假设梯度。SF12的固定s端点身份是全kernel尺度导数积分，不以中心bulk的root界覆盖face；反向绝对路径费已修。面不属于原legal future测试，不能逐V各自领取q再免费相加，正文完整保留共同输入次序。

### 9.1 SF13公共好集的严格核验

这解决先行第8.1节指出的合法性缺口。每个有限component P_E的soft尺度导数可用(3/2)sqrt(|E|)的核绝对质量界，hard每坐标给TV≤2；故所有component导数与f卷积在dx dH/H中可积，统一有限上界足够。component关于H的分布导数给a.e.x的绝对连续路径代表；有限2^n个component取交集，不产生随s变化的例外集。

物理P_E,H*f对每个x关于H连续：a≤H≤b上kernel一致有界，给定H0只有有限hyperplane的source边界例外，对L1来源是零测，DCT适用。取可数稠密端点使物理卷积与路径代表相合，再由连续性延至全部H。因此同一receiver满测集上，有限s多项式展开给所有s的signed路径身份，允许合法代入measurable s(x)、H*(x)。这不只是逐固定s Fubini的偷换。

有限展开仅为公共集/代表元证明，不用来估计范数；故这里不产生2^n费用，也没有据此得到adaptive s的root预算。SF14对预定N值菜单只给朴素N乘代价，连续s(x)选择费仍未解决。后续若把同一有限展开改作正kernel包络求和，必须另收其实际成本。

SF13保证符号身份的L1合法性，而SF10仍仅固定s预算；正文没有将二者混成一般lowcapture付款。实际三点系数、hardface traces、masks/selector BV与同alpha的receiver相关费用完整留账。

最终绑定scale_face_geometry.md SHA256：

    740deada0f5ecfddc63af995bf28093d0d4bc7c91b91f21648b5aba82ac7c57b

## 10. proof.tex.txt及report结论范围整合审查

已在两份作者稿全文后审之后实读主LaTeX全部定理、证明与未付项，再读report.md结论范围。无新增数学问题，无过称。

主稿分布尺度式、variance9/4、固定s的连续路径积分及3/2常数均与SF稿相同；主稿把绝对值置于路径外是已证较强SF10的直接推论。s0核零区不作除法，固定H面的正singular质量仍n(1−s)。由e>8/3给1−e^(−1)>5/8，所以

    I(phi)<11/6+2/5=67/30<9/4

严格成立，没有新数值/外部工具依赖。原s(x)、瞬时adaptive H、face及j/window未付项均显式保留。

联合储备定理在固定原receiver/window/j的共同K0下陈述，gamma≥G0+B及G0≥A0由实际同输入恒等式；r矩常数和联合1/4与JR5–7一致。G0=0只消去zeta外槽，不能删nu外槽；主稿明确留后者。K0inverse三点核、实际density和全部masks使1/4质量不能替列预算，正文没有声称收缩吸收。

report准确称“已证明结构”，明确固定s、真实dx的路径预算与实际联合容量，而不登记lowcapture原交通付款。numerical scope保留有限future、原子输入/单盒与一般L1/history/全空间的区分；本独审不复核新数值字段，不运行脚本。数值由父级与专责数值审查另行验证，不作为以上一般公式依据。

## 11. 最终文件绑定与冻结停止

本次实读并实算的最终理论文件SHA256：

| 文件 | SHA256 |
| --- | --- |
| scale_face_geometry.md | 740deada0f5ecfddc63af995bf28093d0d4bc7c91b91f21648b5aba82ac7c57b |
| joint_receiver_budget.md | 04b94a3ff60ebaa493847887e07b5208a76ea7463ce68619d187a5783cd3892f |
| proof.tex.txt | 36416e5fcbf20bb97b899cb92f10b8e4992257e2b0cf46aaf406addf79245e89 |

本轮指定命题及整合范围通过；唯一反向端点费用问题已修，公共代表元义务由SF13完成。新结构不是一般root交通定理：adaptive s选择、硬面、两外来源列积分、j/window/history以及R175 lowcapture余项继续未付。没有从有限数值或作者结论认证FULL/一般上界。

仅编辑本责任文件，未运行数值、改作者、Git、spawn或PDF。有限审查完成，现冻结停止，不扩展研究。
