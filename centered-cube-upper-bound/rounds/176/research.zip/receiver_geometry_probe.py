#!/usr/bin/env python3
"""R176 fixed-input receiver geometry; bounded samples and one directed interval box."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from functools import lru_cache
import importlib.util,json,math,time,hashlib,sys
HERE=Path(__file__).resolve().parent
SEED=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round175_20261016_final_checkpoint/active_geometry_probe.py')
sp=importlib.util.spec_from_file_location('r175_fixed',SEED);p=importlib.util.module_from_spec(sp);sp.loader.exec_module(p)
ct=p.ct;I=p.I;S=F(1,4);EPS=F(1,2**32);R=F(1);NU=(F(3,25),F(22,25));CP=F(9,20)
INPUTS={4:dict(n=4,y=F(-2,5),v=F(21,40),u=F(-9,10),m=F(589533716533,73598208837274)),16:dict(n=16,y=F(-7,20),v=F(21,40),u=F(-9,10),m=F(1553944690,29396674824873))}
BASE=[(s,l) for s in p.US for l in p.SCALES]
def source(c):return [c['v'],c['u'],c['y'],CP],list(NU)+[EPS,c['m']]
def status(z):return 'pass' if z.lo>0 else ('fail' if z.hi<=0 else 'undecided')
def clip(z):return p.clip(z)
def positive(z):return z.nonnegative()
def fsum(xs):return math.fsum(xs)
@lru_cache(None)
def one(ss,ll,dd):return p.kfast(1,ss,ll,dd)
def fast_kernel(ss,ll,x,z):
 return math.prod(one(ss,ll,t-z) for t in x)
def plain(c,x):
 n=c['n'];pos,masses=source(c);L=2*max(abs(t-CP) for t in x);g=math.sqrt(float(L));ell=1+math.log(n)
 j=0
 while min(float(L),1)<(n/(n+1))**(j+1)*g:j+=1
 cj=F(n,n+1)**j;cjf=float(cj);xi=cjf*g;h=xi*math.exp(-.01/n);lp=min(F(1),F(n+1,n)*L)
 H0=g*cjf**(-.5)*(1-float(S)+float(S)*p.phi(F(1,2)))*ell**(1/(2*n));H=F(str(max(.5,min(1,H0))));T=cjf**(n/2)/(g**n*math.sqrt(ell))
 C=[p.cfast(c['y']-z) for z in pos[:2]];wg=[min(1,a/xi)**n for a in C];w0=[min(1,a/.5)**n for a in C];wh=[min(1,a/h)**n for a in C];TD=[T*(a-b) for a,b in zip(w0,wh)]
 kn=lambda ss,ll,z:fast_kernel(ss,ll,x,z)
 py=kn(S,L,c['y']);J=[kn(F(1),F(1),z) for z in pos[:2]];K0=[kn(S,H,z) for z in pos[:2]];K1=[kn(S,L,z) for z in pos[:2]];K2=[kn(S,lp,z) for z in pos[:2]];Q=[(a+b+d)/3 for a,b,d in zip(K1,K2,J)]
 q=fsum(float(a)*kn(S,L,z) for a,z in zip(masses,pos));eg=fsum(float(a)*b for a,b in zip(NU,wg));Jnu=fsum(float(a)*b for a,b in zip(NU,J));good=[py*w<=qq for w,qq in zip(wg,Q)]
 U=[min(td,k0) if gg else 0 for td,k0,gg in zip(TD,K0,good)];alpha=(q-fsum(float(a)*b for a,b in zip(NU,U)))/Jnu
 rho=[max(0,1-(k+alpha*jv)/td) if td>0 else 0 for k,jv,td in zip(K0,J,TD)];A=[r*jv/(3*qq) if gg else 0 for r,jv,qq,gg in zip(rho,J,Q,good)]
 core=[qq<py for qq in Q];profile=C[0]<.5<C[1]<h
 drop=(float(NU[0])*w0[0]/(float(NU[0])*w0[0]+float(NU[1]))-float(NU[0])*(C[0]/C[1])**n/(float(NU[0])*(C[0]/C[1])**n+float(NU[1]))) if profile else 0
 Gamma=n*math.log(C[1]/.5);cg=(C[1]/xi)**n;Theta=Gamma-math.log(.5+.5*cg);Sf=n*math.log(.25)
 d=max(0,1-K0[0]/TD[0]) if TD[0]>0 else 0
 sigma=Q[0]**2/(py**2*d**2) if d else math.inf
 Mcubic=2*py**3*TD[0]*d**3/(27*Q[0]**2*J[0]) if d else 0
 # Sharp inverse reserve envelope; d includes no alpha. Cubic applies sigma<=4/9.
 Msharp=Mcubic if sigma<=4/9 else (py*TD[0]*d/(2*J[0]))*(1-math.sqrt(sigma)) if sigma<1 else 0
 kap=K0[1]/wg[1];low=Msharp>kap
 menu=BASE+([(S,lp)] if (S,lp) not in BASE else [])+[(S,H)]
 future=[dict(s=str(ss),scale=str(ll),ratio=fsum(float(a)*kn(ss,ll,z) for a,z in zip(masses,pos))/q) for ss,ll in menu]
 high=py*eg/(2*q);hardmass=sum((a for a,z in zip(masses,pos) if all(abs(t-z)<=R/2 for t in x)),F(0))
 checks=dict(common_window=F(1,2)<=L<=1 and F(1,2)/cj<=F(str(g))<=cj,j0=j==0,strict_soft=float(S)>1-2**(-1/n),D1=math.sqrt(ell)/(8*(128/119))-16/(3*math.sqrt(ell))<1,high=high>1,target_good=good[0],alpha_nonnegative=alpha>=0,target_A_positive=A[0]>0,canonical_core=all(core),profile=profile,Gamma_above_root=Gamma>.5*math.log(n),Reta=Theta>.5*math.log(n) and Sf-Theta<0,finite_future=max(a['ratio'] for a in future)<=1+2e-13,hard_16over3=float(hardmass)<16*q/3,whole_clock_lowcapture=low)
 active=all(checks.values());ival=py*A[0]*drop;Cb=py**2*A[0]**2/J[0]*drop/n;EJ=n*J[0]*drop;gamma=alpha*Jnu;mu_bad=float(NU[1])*K0[1]/gamma;tau_y=float(EPS)*kn(S,H,c['y'])/gamma
 return dict(x=[str(a) for a in x],L=str(L),Lplus=str(lp),j=j,cj=str(cj),D=1,Hhat=str(H),q=q,p_y=py,high_ratio=high,good=good,alpha=alpha,rho=rho,A=A,K0=K0,J=J,Q=Q,TDelta=TD,wg=wg,Gamma=Gamma,Theta=Theta,S=Sf,sigma=sigma,Msharp=Msharp,kappa_bad=kap,posterior_drop=drop,gamma=gamma,mu_bad=mu_bad,tau_outer_y=tau_y,EJ=EJ,Cb=Cb,hard_R_mass=str(hardmass),I_original=ival,outer_beta_weighted_positive=float(EPS)*ival,finite_future=future,checks=checks,active_lowcapture_finite=active,rejected=[k for k,v in checks.items() if not v])

# Interval kernels for a true receiver box. All input box endpoints are rational.
def absiv(z):
 a,b=F(z.lo),F(z.hi)
 return I(I(0 if a<=0<=b else min(abs(a),abs(b))).lo,I(max(abs(a),abs(b))).hi)
def ikernel(ss,ll,box,z,N,completion_current=False):
 out=I(1)
 for xx in box:
  dd=absiv(xx-I(z))
  if completion_current:hard=I(1) # exact selector identity: |x_i-r|<=L(x)/2
  elif (I(2)*dd).hi<=ll.lo:hard=I(1)
  elif (I(2)*dd).lo>ll.hi:hard=I(0)
  else:hard=I(0,1)
  out=out*((I(1-ss)*hard+I(ss)*ct.phi_range(dd/ll,N))/ll)
 return out

def box_certificate(N):
 c=INPUTS[4];n=4;bounds=[(F(1,1000),F(11,10000))]+[(F(2,1000),F(21,10000))]*3;box=[I(I(a).lo,I(b).hi) for a,b in bounds];pos,masses=source(c)
 # x1 is the unique smallest coordinate; this is a Cartesian box, Jacobian=1.
 L=I(F(9,10))-2*box[0];g=L.sqrt();ell=I(1)+ct.log_rational(F(n));lp=p.minimum(I(1),I(F(5,4))*L)
 er=ct.log_interval(ell)/I(2*n);eroot=I((1/ct.iv.exp_neg(F(er.lo))).lo,(1/ct.iv.exp_neg(F(er.hi))).hi)
 H0=g*(I(1-S)+I(S)*ct.phi_range(I(F(1,2)),N))*eroot;H=I(max(I(F(1,2)).lo,min(I(1).lo,H0.lo)),max(I(F(1,2)).hi,min(I(1).hi,H0.hi)))
 h=g*ct.iv.exp_neg(F(1,100*n));T=1/(g**n*ell.sqrt());C=[ct.iv.C(abs(c['y']-z),N) for z in pos[:2]]
 wg=[(a/g).capped_one()**n for a in C];w0=[(a/I(F(1,2))).capped_one()**n for a in C];wh=[(a/h).capped_one()**n for a in C];TD=[T*(a-b).nonnegative() for a,b in zip(w0,wh)]
 kn=lambda ss,ll,z:ikernel(ss,ll,box,z,N,ss==S and ll is L and z==CP)
 py=kn(S,L,c['y']);J=[kn(F(1),I(1),z) for z in pos[:2]];K0=[kn(S,H,z) for z in pos[:2]];K2=[kn(S,lp,z) for z in pos[:2]];Q=[(kn(S,L,z)+k2+j)/3 for z,k2,j in zip(pos,K2,J)]
 gm=[qq-py*w for qq,w in zip(Q,wg)];good=[status(a) for a in gm];U=[p.minimum(td,k0) if gg=='pass' else I(0) if gg=='fail' else I(0,p.minimum(td,k0).hi) for td,k0,gg in zip(TD,K0,good)]
 q=sum((I(a)*kn(S,L,z) for a,z in zip(masses,pos)),I(0));Jnu=sum((I(a)*j for a,j in zip(NU,J)),I(0));eg=sum((I(a)*w for a,w in zip(NU,wg)),I(0));alpha=(q-sum((I(a)*u for a,u in zip(NU,U)),I(0)))/Jnu
 rho=[clip(1-(k+alpha*j)/td) for k,j,td in zip(K0,J,TD)];A=[r*j/(3*qq) if gg=='pass' else I(0) if gg=='fail' else I(0,(r*j/(3*qq)).hi) for r,j,qq,gg in zip(rho,J,Q,good)]
 pi0=I(NU[0])*w0[0]/(I(NU[0])*w0[0]+I(NU[1]));wend=(C[0]/C[1])**n;pie=I(NU[0])*wend/(I(NU[0])*wend+I(NU[1]));drop=(pi0-pie).nonnegative();ival=py*A[0]*drop
 Gamma=I(n)*ct.log_interval(C[1]/I(F(1,2)));cg=(C[1]/g)**n;Theta=Gamma-ct.log_interval(I(F(1,2))+I(F(1,2))*cg);Sf=I(n)*ct.log_rational(S);root=ct.log_rational(F(n))/2
 d=(1-K0[0]/TD[0]).nonnegative();sigma=Q[0]**2/(py**2*d**2);Mcubic=2*py**3*TD[0]*d**3/(I(27)*Q[0]**2*J[0]);kap=K0[1]/wg[1]
 menu=[(ss,I(ll),str(ll)) for ss,ll in BASE];
 if lp.lo!=1 or lp.hi!=1:menu.append((S,lp,'actual Lplus'))
 menu.append((S,H,'actual Hhat'));future=[]
 for ss,ll,label in menu:
  val=sum((I(a)*kn(ss,ll,z) for a,z in zip(masses,pos)),I(0));margin=q-val
  future.append(dict(s=str(ss),scale_label=label,scale=ll.out(),margin=margin.out(),status=status(margin)))
 # Original hard cap is h_R with R=b=1, not h_Hhat. Prove every membership.
 hardstatuses=[]
 for z in pos:
  maxdist=I(max(absiv(xx-I(z)).lo for xx in box),max(absiv(xx-I(z)).hi for xx in box));hardstatuses.append('inside' if (2*maxdist).hi<=I(R).lo else 'outside' if (2*maxdist).lo>I(R).hi else 'undecided')
 hardmass=sum((I(a) for a,hs in zip(masses,hardstatuses) if hs=='inside'),I(0));hardupper=sum((I(a) for a,hs in zip(masses,hardstatuses) if hs!='outside'),I(0))
 margins=dict(common_L_lower=L-I(F(1,2)),common_L_upper=I(1)-L,j0_lower=L-I(F(4,5))*g,j0_upper=g-L,tau_to_g=g-I(F(1,2)),g_to_b=I(1)-g,high=py*eg-2*q,target_good=gm[0],target_A=A[0],alpha=alpha,core_good=py-Q[0],core_bad=py-Q[1],profile_good=I(F(1,2))-C[0],profile_bad=C[1]-I(F(1,2)),profile_end=h-C[1],Gamma_above_root=Gamma-root,Theta_above_root=Theta-root,S_minus_Theta_negative=Theta-Sf,hard16over3=I(F(16,3))*q-hardupper,S_good_outside_R=I(min(F(absiv(xx-I(c['v'])).lo) for xx in box))-I(F(1,2)),sigma_cubic=I(F(4,9))-sigma,whole_clock_lowcapture=Mcubic-kap,positive=ival)
 checks={k:status(v) for k,v in margins.items()};checks['finite_future']='pass' if all(r['status']=='pass' for r in future) else 'undecided' if all(r['status']!='fail' for r in future) else 'fail';checks['bad_good_status']=good[1]
 Dupper=ell.sqrt()/(I(8)*I(F(128,119)))-16/(3*ell.sqrt());checks['D1']='pass' if Dupper.hi<1 else 'undecided';soft=I(S)-1+I(ct.iv.exp_neg(F(ct.log_rational(F(2)).hi)/n).lo,ct.iv.exp_neg(F(ct.log_rational(F(2)).lo)/n).hi);checks['strict_soft']=status(soft)
 volume=math.prod((b-a for a,b in bounds));weighted=I(EPS*volume)*ival;Cb=py**2*A[0]**2/J[0]*drop/I(n);EJ=I(n)*J[0]*drop;gamma=alpha*Jnu;mu_bad=I(NU[1])*K0[1]/gamma;tau_y=I(EPS)*kn(S,H,c['y'])/gamma
 # Unconditional partial original-positive integral is bounded by interval coefficients.
 # Restricting to all requested masks is positive only if every gate passes (bad source must fail good).
 certified=all(v=='pass' for k,v in checks.items() if k!='bad_good_status') and good[1]=='fail'
 masked=weighted if certified else I(0,weighted.hi)
 return dict(N=N,bounds=[[str(a),str(b)] for a,b in bounds],jacobian='1',volume=str(volume),completion_current_hard_identity='all |x_i-r|<=max_j|x_j-r|=L(x)/2; closed cube includes equality',L=L.out(),Lplus=lp.out(),j=0,cj='1',g=g.out(),Hhat=H.out(),D=1,D_upper=Dupper.out(),q=q.out(),p_y=py.out(),Q=[a.out() for a in Q],J=[a.out() for a in J],K0=[a.out() for a in K0],good=good,alpha=alpha.out(),rho=[a.out() for a in rho],A=[a.out() for a in A],TDelta=[a.out() for a in TD],wg=[a.out() for a in wg],Gamma=Gamma.out(),Theta=Theta.out(),S=Sf.out(),posterior_drop=drop.out(),sigma=sigma.out(),M_cubic=Mcubic.out(),kappa_bad=kap.out(),margins={k:v.out() for k,v in margins.items()},checks=checks,finite_future=future,hard_kernel='h_R, R=b=1',hard_R_mass=hardmass.out(),hard_R_mass_upper=hardupper.out(),hard_memberships=hardstatuses,gamma=gamma.out(),mu_bad=mu_bad.out(),tau_outer_y=tau_y.out(),EJ=EJ.out(),Cb=Cb.out(),partial_outer_companion_integral=(I(EPS*volume)*Cb).out(),all_requested_gates_certified=certified,I_original=ival.out(),partial_outer_receiver_integral=weighted.out(),masked_partial_outer_receiver_integral=masked.out(),scope='one Cartesian receiver box, only outer y atom, fixed atomic F/nu/beta and diagnostic K1; finite future, conditional Zall; no continuumFIRST/history/L1')

def main():
 start=time.monotonic();replay=[]
 for n,x in [(4,[F(0)]*4),(4,[F(1,1000)]+[F(2,1000)]*3),(16,[F(0)]*16),(16,[F(2,1000)]*16),(16,[F(1,1000)]+[F(2,1000)]*15)]:replay.append(dict(n=n,**plain(INPUTS[n],tuple(x))))
 grids=[]
 for order in (3,5):
  rows=[];nodes=[F(-1,200)+F(2*i+1,200*order) for i in range(order)];dx=F(1,100)**4/order**4
  for x in product(nodes,repeat=4):
   if time.monotonic()-start>120:break
   rows.append(plain(INPUTS[4],x))
  active=[r for r in rows if r['active_lowcapture_finite']];reject={k:sum(not r['checks'][k] for r in rows) for k in rows[0]['checks']}
  grids.append(dict(order=order,expected_nodes=order**4,evaluated_nodes=len(rows),cell_dx=str(dx),receiver_box_volume='1/100000000',active_nodes=len(active),sampled_active_volume=float(dx)*len(active),sampled_outer_positive_integral=float(dx)*fsum(r['outer_beta_weighted_positive'] for r in active),sampled_outer_companion_integral=float(dx*EPS)*fsum(r['Cb'] for r in active),rejection_counts=reject,rows=rows))
 prescreen_seconds=time.monotonic()-start;certificates=[box_certificate(N) for N in (128,256)]
 seedjson=SEED.with_suffix('.json');frozen=json.loads(seedjson.read_text())
 for entry in frozen['certificates']:
  old=entry['input'];c=INPUTS[old['n']]
  assert all(F(old[key])==c[key] for key in ('y','v','u')) and F(old['completion_mass'])==c['m'] and F(old['eta'])==NU[0]
 deps=[SEED,seedjson,p.TOOL,Path(ct.DEP)];out=dict(scope='Fixed R175 atomic common inputs; real n-dimensional receiver measures retained; diagnostic K1 and conditional Zall; no continuumFIRST/history/L1 or general bound.',inputs={str(a):hashlib.sha256(a.read_bytes()).hexdigest() for a in deps},local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},fixed_inputs={str(n):{k:str(v) for k,v in c.items()} for n,c in INPUTS.items()},fixed_nu=[str(a) for a in NU],epsilon=str(EPS),completion_position=str(CP),s=str(S),a='1/2',b='1',R='1',K='1 diagnostic',eta='1/2',selector='L(x)=2||x-r||infinity; q(x)=P_s,L(x)f, fixed f,nu,beta; all physical coefficients recomputed per receiver',budget=dict(prescreen_seconds_cap=120,orders=[3,5],n4_grid_nodes=706,n16_comparison_points=3,interval_boxes=1,interval_N=[128,256]),replay_and_comparison=replay,grids=grids,box_certificates=certificates,limitations=['Grid values are quadrature evidence without rigorous global discretization error.','Box certificate retains Cartesian volume; no curve/coarea volume shortcut.','Only the selected outer y atom contribution is measured; other outer atoms and j sums are not paid.','Atomic mass on a moving closed hard face does not provide L1 stability.','Finite future menu is necessary evidence only; no continuumFIRST or original history certificate.','K1 remains diagnostic and conditional Zall is used.'],runtime=dict(prescreen_seconds=round(prescreen_seconds,3),total_seconds=round(time.monotonic()-start,3),python=sys.version))
 (HERE/'receiver_geometry_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(grids=[{k:v for k,v in g.items() if k!='rows'} for g in grids],box=[dict(N=c['N'],certified=c['all_requested_gates_certified'],checks=c['checks'],integral=c['masked_partial_outer_receiver_integral']) for c in certificates],runtime=out['runtime']),indent=2))
if __name__=='__main__':main()
