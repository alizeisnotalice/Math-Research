# R176 numerical review

## Physical receiver probe

Reviewed the fixed R175 source positions/masses against its frozen JSON; the program asserts exact Fraction equality. The new selector changes the receiver-dependent coefficients only. Actual Lplus is recomputed for each point and box. In particular the n16 baseline is153/160, and the two shifted n16 values are119/125 and7633/8000, not1.

The finite node budget is81+625 n4 grid nodes and3 n16 comparison points, with2 n4 calibration points. Prescreen time is0.224s, within the approved120s cap. One fixed Cartesian box is evaluated at N128/256; no second box or extra search is used. Grid weights sum to(.01)^4=10^-8 and the box measure is10^-16. The actual y atom mass2^-32 multiplies all reported outer integrals.

All interval arithmetic uses the existing frozen R168/R166 directed Decimal runtime. Interval absolute values convert Decimal endpoints to exact Fractions before arithmetic, avoiding ambient Decimal rounding. Products, kernel ratios, clipping and endpoint comparisons stay in interval arithmetic. Current completion hard membership uses the exact selector relation, and the original hard cap is evaluated at R=1 with separately proved atom memberships. The parent caught and we corrected an unused noncubic inverse-envelope branch: for4/9<sigma<1 it is p*TDelta*d/(2*K*J)*(1-sqrt(sigma)). Actual cases use sigma<4/9 throughout, so this correction leaves all reported numbers unchanged.

The box check proves the j0 bin inequalities, common window, original softness, D1, positive high/good/alpha/A, both core memberships, score profile, Gamma and Theta above root, S-Theta<0, original h_R cap, all finite future margins, and whole-clock lowcapture. Source bad has a strictly negative good margin. Source good remains outside the R hard cube coordinatewise, so its physical kernel ratio is exactly s^n. The FTC clock integral requires no quadrature: the sole positive pair stops when the bad threshold is crossed. No source is deleted in this conditional Zall diagnostic.

The final N256 partial original integral is enclosed by [3.1410648578104150e-29,3.1750046286652128e-29]. N128 and N256 both certify positive lower bounds and all stated masks. No grid-derived integral is labeled rigorous. The rigorous statement concerns one selected outer atom and one receiver box, under finite future and diagnostic K1; it does not imply continuumFIRST/history/L1 validity, an original j-sum bound, or the general target.

## Independent replay of parent scalar checks

Read `scalar_geometry_check.py` and copied it to `/tmp/r176_numeric_review/scalar_geometry_check.py`; ran that copy without editing the parent file. All mathematical JSON fields match the parent's JSON exactly after removing runtime_seconds.

The code has20 mpmath quadratures:10 Laplace mixture scale a values at40/60 decimal digits, split at scaled tail landmarks. These numerically check the two displayed scalar Fisher bounds; neither precision agreement nor finite quadrature is an interval proof. Seven Fraction cases r=1,2,3,4,8,16,32 each compare503 nonnegative grid/tail points with r^r/(r+1)^(r+1), and check exact equality at z=r. They are exact finite checks, not a proof of the continuum maximum. The final Fraction constant check67/30<9/4 is exact; its preceding analytic premise e>8/3 is stated, not established numerically by this script. The code imports mpmath from the existing vendor path and has no scipy dependency. No installation was performed.

## HERE migration replay

Copied the final probe and unchanged task contract to `/tmp/r176_receiver_replay/` and ran once. All JSON fields except the recorded runtime object agree exactly, including both raw interval resolutions, all706 receiver nodes, fixed dependency hashes and all volume factors. No additional cases were evaluated.
