# R176 fixed-input receiver geometry

The active lowcapture row persists on a Cartesian receiver box of positive four-dimensional measure for the fixed R175 atomic input. This certifies a local finite-future diagnostic, not the original FIRST/history/L1 construction or a general budget.

Run `python3 receiver_geometry_probe.py` from any directory. The script locates its output with HERE, records external frozen dependency hashes and the local contract hash, and verifies its two fixed inputs against the frozen R175 JSON. No software installation is needed. The final run used 0.224 seconds for the prescreen and 16.752 seconds overall; the deterministic node and interval budgets matter, not this recorded timing.

## Fixed construction and receiver selector

Keep nu=(3/25)delta_(.525^n)+(22/25)delta_(-.9^n), epsilon=2^-32, and

`f=beta=nu+epsilon delta_(y^n)+m delta_(.45^n)`.

For n4, y=-.4 and m=589533716533/73598208837274. For n16, y=-.35 and m=1553944690/29396674824873. No atom or mass is fitted anew. Take s=1/4, a=1/2, b=R=1, diagnostic K=1. At each receiver x use L(x)=2||x-.45^n||infinity and actual q(x)=P_s,L(x)f. Recompute j, g, Hhat, actual Lplus=min(1,(1+1/n)L), TDelta, physical Q, original good, U, alpha, rho and A. All sampled and certified receivers lie in legal j=0 and D=1 regimes. D=1 follows from the original upper branch with eps<=1 and Lambda=128/119, rather than being fitted.

The finite future menu has s in {1/4,5/8,1} and radius in {1/2,5/8,3/4,.9,1}, plus actual Hhat and actual Lplus where new. Current q is an exact defining equality. These tests do not certify the continuum future condition. The hard 16/3 check uses the original h_R with R=1, not h_Hhat; both nu atoms are outside and the y/completion atoms are inside throughout the certified box.

## Three bounded stages

1. Replay n4 x=0 and x=(.001,.002,.002,.002), and compare n16 at x=0, x=.002^16 and x=(.001,.002,...,.002). Every test passes the sampled active-lowcapture/future conditions. The n16 points carry no inferred sixteen-dimensional receiver volume.
2. Use full Cartesian midpoint grids of orders3 and5 on X=[-.005,.005]^4. There are exactly81 and625 nodes, with cell dx=(.01)^4/order^4. All nodes pass the stated finite diagnostic masks. Preserve the outer beta weight epsilon.
3. Certify only the predeclared box B=[.001,.0011] times [.002,.0021]^3, with directed Decimal arithmetic at N128 and N256 in the frozen kernel routine. No adaptive search or second box is used. All requisite margins pass at both resolutions, and the second nu atom strictly fails good. B is Cartesian: Jacobian1 and volume10^-16. The unique minimum coordinate is x1, so L=.9-2x1 exactly. Completion belongs to the closed current hard cube identically; replacing this selector identity by independent interval tests would introduce a false ambiguity.

| Grid | Active nodes | Sampled epsilon integral I dx | Sampled epsilon integral Cb dx |
|---|---:|---:|---:|
| order3 |81/81|3.2412571549e-21|1.1018756596e-20|
| order5 |625/625|3.2408783266e-21|1.1016772496e-20|

These are quadrature observations, with no certified error over X. Their agreement does not certify X.

## Exact clock integration and box result

The actual physical scalar thresholds satisfy Cgood<.5<Cbad<xi_h throughout B. Both sources are in the canonical Q-sublevel core, and source good has score n while source bad has score0 before Cbad; after Cbad their scores agree. Therefore, with terminal original A fixed in time, the positive clock integral is exactly

`I(x)=p_y(x) A_good(x) [Pi_good(.5)-Pi_good(Cbad)]`.

The bracket is computed with directed intervals from the two actual source thresholds and masses. No time quadrature or free coefficient arrays occur. The companion is exactly `Cb=p_y^2 A_good^2/J_good * drop/n`, with `EJ=n J_good drop`; the Cauchy factorization is structural. These are the original positive pair and masked companion on this conditional Zall model.

At N256, all requested gates hold on B. In particular, Gamma is in [.91192675859,.91196807315], Theta in [1.42859303315,1.42871308844], and S=4log(1/4). The source v remains outside every coordinate of the R hard cube, proving the S identity on B. Sigma is below4/9, so the exact sharp threshold uses the cubic branch. M is in [2685.9999,2703.0743], whereas K0_bad/wg_bad is in [2.22390e-5,2.22921e-5]. Since wt_bad>=wg_bad, the sole positive pair stays in the lowcapture complement for the entire clock.

The rigorous partial receiver integrals, including actual outer mass epsilon and volume, are

- epsilon integral_B I dx in [3.1410648578104150e-29, 3.1750046286652128e-29].
- epsilon integral_B Cb dx in [1.0186153008103280e-28, 1.0413951085350663e-28].

Raw directed endpoints are preserved in JSON. The same-alpha quantities gamma=alpha Jnu, mu_bad=nu_bad K0_bad/gamma and tau_y=epsilon K0_y/gamma are also retained. On B, mu_bad is about5.94e-4 and tau_y about3.07e-8; neither is treated as an independent free measure.

This answers a local geometric question: the active lowcapture mechanism survives on positive receiver measure, rather than only at x0. It does not decide a global receiver/source estimate. Only the y atom contribution is measured; the other outer atoms, the original j sum, continuum FIRST, history eligibility and L1 stability remain unpaid or unavailable. The completion atom lies exactly on a moving hard face, so atomic validity cannot be promoted to a stable L1 realization. No wider scan or exponent fit follows from this experiment.
