# R176：mixed尺度导数的连续路径预算与原硬面账

## 1. 命题范围

本稿只证明：固定全空间共同软度s∈[0,1]、任意正L1输入f时，尺度导数的中心化连续部分具有准确的sqrt(n)路径预算；硬面部分保留为原有符号面差，不丢负体积项。原receiver软度若为s(x)，不能直接套用逐固定s的统一L1界。没有证明R175低capture三点余项的一般receiver预算，也没有将s=1光滑特例称为闭合。

已读R176合同、冻结R175所需三点核范围，以及N04当前SKILL和来源/课题接口。这里只使用其“误差与总费用必须保留”的筛查，不引用外部熵或望远镜定理。以下全部计算自证，不用来源Π的独立性；出现张量积分是物理核本身的准确乘积结构。

记h=1[-1/2,1/2]、φ=h*w，w(r)=∫0¹exp(−|r|/a)da。局部混合参数a是积分dummy，不是原window下端点。置

\[
b_s(r)=(1-s)h(r)+s\phi(r),\qquad
P_{s,H}(x)=H^{-n}\prod_i b_s(x_i/H),\quad 0<a\le H\le b.
\tag{SF1}
\]

h、φ、bs的积分都是1；F、C没有被概率化。物理φ指数尾保证下列积分分部合法。

## 2. 准确的一维及张量面系数

对bs>0处定义

\[
\kappa_s(r)=-1-\frac{r s\phi'(r)}{b_s(r)},\qquad
\psi_s(r)=\kappa_s(r)+(1-s).
\]

s=0的零密度区域取ψ0=0，不作0/0。连续部分的平均准确为

\[
\int\kappa_s b_s=-1-s\int r\phi'=-(1-s),\quad
\int\psi_s b_s=0.
\tag{SF2}
\]

一维尺度微分是有限signed测度

\[
\partial_{\log H}[H^{-1}b_s(x/H)dx]
=\kappa_s(x/H)H^{-1}b_s(x/H)dx
+\frac{1-s}{2}(\delta_{H/2}+\delta_{-H/2}).
\tag{SF3}
\]

两面各系数(1−s)/2，无额外H因子；可对C1紧支撑测试函数换元、积分分部直接核验。

令ηH=(δH/2+δ−H/2)/2为一维概率面测度，

\[
\mathsf F_{i,s,H}=\eta_H(dx_i)\prod_{j\ne i}H^{-1}b_s(x_j/H)dx_j,
\quad\overline{\mathsf F}_{s,H}=n^{-1}\sum_i\mathsf F_{i,s,H}.
\]

每个Fi和平均面都是概率测度。定义中心化连续核

\[
\mathcal B_{s,H}(x)=P_{s,H}(x)\sum_i\psi_s(x_i/H).
\]

完整原尺度恒等式为

\[
\boxed{\partial_{\log H}[P_{s,H}dx]
=\mathcal B_{s,H}dx+n(1-s)
[\overline{\mathsf F}_{s,H}-P_{s,H}dx].}
\tag{SF4}
\]

第一项质量0；方括号质量0。不能仅保留正面后宣称n(1−s)已被centered bulk消掉。事实上正singular面质量为n(1−s)，原ac部分质量为−n(1−s)，故完整尺度导数的TV范数至少2n(1−s)。这是一般mixed核不能由瞬时TV免费变成root的准确费用边界。

## 3. 方差统一界9/4的完整初等证明

置ga=uniform[-1/2,1/2]*Laplace_a，其中Laplace_a(r)=exp(−|r|/a)/(2a)。则

\[
\phi(r)=\int_0^1 2a\,g_a(r)da.
\]

ga是概率密度；在|r|≤1/2有

\[
g_a(r)=1-e^{-1/(2a)}\cosh(r/a)\ge c_0:=\frac{1-e^{-1}}2,
\quad |g_a'(r)|\le\frac{e^{-(1/2-|r|)/a}}{2a}.
\]

于是

\[
\int_{|r|\le1/2}\frac{r^2g_a'^2}{g_a}dr
\le\frac1{16c_0a}.
\tag{SF5}
\]

具体用r²≤1/4及两侧对称，积分e^{−(1−2r)/a}即可；没有a→0的未计发散。

在外部r=1/2+t，ga=(1−e^{−1/a})e^{−t/a}/2、|ga′|=ga/a，两侧精确积分给

\[
\int_{|r|>1/2}\frac{r^2g_a'^2}{g_a}dr
=(1-e^{-1/a})\left(\frac1{4a}+1+2a\right).
\tag{SF6}
\]

令Iscale(g)=∫(−1−rg′/g)²g=∫r²g′²/g−1。由(SF5)/(SF6)，

\[
I_{scale}(g_a)\le\frac A a+2a,
\qquad A=\frac14+\frac1{8(1-e^{-1})}.
\]

混合Cauchy逐点给(∫2a[−ga−rga′]da)²/φ≤∫2a[−ga−rga′]²/ga da，故

\[
I_\phi:=\int\left(-1-\frac{r\phi'}\phi\right)^2\phi dr
\le2A+\frac43
=\frac{11}6+\frac1{4(1-e^{-1})}<\frac94.
\tag{SF7}
\]

积分先在a≥ε截断或直接用非负Tonelli，上述2a(A/a+2a)可积，故没有正则化余费。最后一个严格界只需e>5/2，可由指数级数初项验证。

由ψs=−s−rsφ′/bs及∫rφ′=−1，s>0时

\[
\operatorname{Var}_{b_s}\psi_s
=s^2\left(\int\frac{r^2\phi'^2}{b_s}dr-1\right)
\le s(I_\phi+1)-s^2\le\frac94.
\tag{SF8}
\]

最后一步可把Iφ换成(SF7)的上界B∈(1,9/4)，并用B−[s(B+1)−s²]=(1−s)(B−s)≥0。s=0时方差为0。

物理P是bs的张量积，ψ均值0，故交叉积分准确为0，

\[
\boxed{\|\mathcal B_{s,H}\|_1
\le\left(\int P_{s,H}[\sum_i\psi_s]^2\right)^{1/2}
=\sqrt{n\operatorname{Var}_{b_s}\psi_s}\le\tfrac32\sqrt n.}
\tag{SF9}
\]

这是kernel张量的计算，不是任何原posterior/source坐标独立假设。

## 4. 固定s、一般L1的实际receiver路径预算

取任意正f∈L1和任意measurable终点H*(x)∈[a,b]。定义bulk绝对路径

\[
\mathcal V_{s,H_*}(x)=\int_a^{H_*(x)}
|(f*\mathcal B_{s,H})(x)|\frac{dH}H.
\]

固定s后，Tonelli与卷积三角不等式直接给

\[
\boxed{\|\mathcal V_{s,H_*}\|_1
\le\int_a^b\|f*\mathcal B_{s,H}\|_1\frac{dH}H
\le\tfrac32\sqrt n\log(b/a)\|f\|_1.}
\tag{SF10}
\]

原窗口b≤2a时log(b/a)≤log2。H*(x)无需平滑、无需与f独立。这是**路径内绝对值积分**的真实dx预算；不是瞬时adaptive核范数∫|(f*B_s,H*(x))(x)|dx，也不是任意adaptive s(x)的预算。

如果一组Hj(x)只通过原唯一j(x)选择一个终点，可先合成H*(x)，(SF10)不新增j列数。若放松为所有j独立求和或另有j相关密度，必须保留其真实求和费；本稿不替R175的tau_j/mu_j合并付账。

## 5. 原面transport身份与共同来源容量的准确接口

一维记 h_H(x)=H^{-1}h(x/H)、φ_H(x)=H^{-1}φ(x/H)。原硬面有分布恒等式

\[
\eta_H-h_Hdx=-\partial_x[xh_H(x)dx],
\]

所以mixed面差准确为

\[
\eta_H-H^{-1}b_s(x/H)dx
=-\partial_x[xh_H(x)dx]+s(h_H-\phi_H)dx.
\tag{SF11}
\]

张量中只把其余坐标乘原mixed概率密度。对C1紧支撑测试G，面差等于∫x_i hH P_-i ∂iG加s∫(hH−φH)P_-iG；没有删掉后一个signed修正，也没有对任意L1输入假设梯度。

对固定s、固定端点H1,H2，(SF4)与一般f卷积后在L1中给原FTC：

\[
f*P_{s,H_2}-f*P_{s,H_1}
=\int_{H_1}^{H_2}f*\mathcal B_{s,H}\frac{dH}H
+n(1-s)\int_{H_1}^{H_2}
[f*\overline{\mathsf F}_{s,H}-f*P_{s,H}]\frac{dH}H.
\tag{SF12}
\]

各面概率核的L1卷积范数≤∥f∥1，故面差的绝对路径只先得到2n(1−s)|log(H2/H1)|∥f∥1；若保持signed积分，(SF12)可保留端点与bulk的真实抵消，但不能对面项先取正部再免费沿用抵消。

对同一原ν≤f，所有共同合法future仍给P_s,Hν(x)≤q；面测度本身并非合法future测试，不能声称F_i,Hν(x)≤q。若对(SF12)使用FIRST，能控制的是合法端点和体积项，并需同时保留面/体积的signed差。逐V分别取得一个q也不能免费相加；只有共同核/端点时可先用∑VνV≤f，再用同一q。没有证明这些端点、面差乘R175真实三点系数后的总价格为ε∫q或root W。

在lowcapture核中把(SF11)的测试G取成含1/K0_y、1/K0_u、Q、原masks及receiver selectors的系数，需要其梯度/BV跳、hard-face traces和selector变化项；这些并不由(SF10)自动控制。本文不对它作无费用积分分部，不把自适应K0当固定空间概率核，不提出新的假定梯度门。未付款的正硬面及其共同来源/receiver相关性继续留给原三点问题。

## 6. 一般L1公共代表元：合法性不等于adaptive-s预算

为避免逐固定s的例外集随s变化，用有限子集展开

\[
P_{s,H}=\sum_{E\subset\{1,\ldots,n\}}
 s^{|E|}(1-s)^{n-|E|}P_{E,H},
\tag{SF13}
\]

其中E坐标用φH，其余用hH。每个PE是概率核，其logH导数的TV可用soft项≤(3/2)√|E|及每个hard坐标面差≤2相加，故≤(3/2)√n+2n；在[a,b]可积。与f卷积后Tonelli给H路径AC的一个receiver满测集。对有限2^n个E交这些集合，得到同一个满测集；在此集合上所有s的有限多项式展开都满足(SF12)的路径身份。

端点物理卷积PE,H*f对H连续：H在紧窗口中核一致有界，逐源位置的边界例外为有限超平面、对L1 f零测，dominated continuity适用。以可数稠密端点再延拓，路径代表元与物理端点对所有H一致。因此可合法代入measurable s(x)、H*(x)到**有符号路径身份**，不需要平滑f，也不会遗漏一个随s变化的零集。

此2^n展开仅用于公共零集/代表元，不用于任何root范数估计。它不证明

    adaptive s(x) 的bulk路径L1 <= (3/2)sqrt(n)log(b/a)||f||1。

逐s的统一L1范数不能在x积分内免费取selector。若s(x)只取预定N个值，朴素非负分割给准确费用至多

\[
\tfrac32 N\sqrt n\log(b/a)\|f\|_1.
\tag{SF14}
\]

连续原s(x)未取得有限N/polylog选择预算，本稿不把其普遍成立作为新假设。公共代表元解决合法性，未减少这项范数费用。

## 7. bounded结论与停止

已证(SF3)/(SF4)全部面常数、连续平均、uniform方差9/4，以及固定s、任意measurable H*(x)、一般正L1 f的真实bulk路径预算(SF10)。原面项保留(SF11)/(SF12)的signed transport/端点身份；固定s与adaptive s(x)、路径与瞬时范数、合法future体积容量与非future面容量均明确区分。

没有正则化后宣称免费误差消失：一般L1由有限component公共AC直接处理。若后续对实际三点系数或masks作平滑，必须另给所有差项的可积/可求和费用；N04不允许仅凭形式抵消领取总价。本文未证明低capture remainder、新FULL覆盖或一般weak bound闭合。

父级常数候选已独立核算并送审；全文最终绑定由独审/父级记录。仅写scale_face_geometry.md，不Git、spawn、PDF、不改他人文件；本有界稿完成后停止，不扩新子路线。
