"""R607 endpoint-oracle lower bound on the full-action gap; frozen R606 read-only."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,time,resource
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=512
source_path=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/tmp/ccu_r606_numeric.py')
raw=source_path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
assert sha=='7c70064d72fa1cb03b73a4dd1be0dbfd4749fd818896158313d9d8b18ae7047e'
# Execute definitions only, with the function's return extended in memory.
# Never execute R606's bottom-level compute/output statements; never alter its files.
source=raw.decode().split('\ninitial=compute(',1)[0]
assert source.count(' return report\n')==1
source=source.replace(' return report\n',' return report, M, w, parents, slots\n')
ns={'__name__':'r606_definitions_for_r607'}
exec(compile(source,str(source_path)+' [definitions only; extended return in memory]','exec'),ns)
def A(x):
 x=F(x);return arb(x.numerator)/x.denominator
def iv(x):return {'lo':str(x.lower().fmpq()),'hi':str(x.upper().fmpq()),'display':x.str(32)}
configs=[{'n':256,'s':F(33,32),'bg_right':F(-189,1000),'target_left':F(-1,100000),'new_lo':F(51,100),'new_hi':F(5101,10000),'bg_lo':F(-703,1000),'bg_hi':F(-702,1000)},
 {'n':56,'s':F(9,8),'bg_right':F(-3,20),'target_left':F(-1,100),'new_lo':F(27,50),'new_hi':F(541,1000),'bg_lo':F(-141,200),'bg_hi':F(-88,125)}]
rows=[]
for cfg in configs:
 report,M,w,parents,slots=ns['compute'](cfg)
 E=sum((A(w[i]*w[j])*M[i][j] for i in range(8) for j in range(8)),arb(0))
 prices=[sum((A(w[u])*M[u][v] for u in range(8)),arb(0)) for v in range(8)]
 # Each candidate V_pk includes the true Lebesgue parent volume V_p.
 # All parents share their block's true original R,t,m and each slot's actual phase/window.
 best=[];perparent=[]
 for p in range(4):
  old,endpoint=prices[2*p:2*p+2]
  if old<endpoint:k=0
  elif endpoint<old:k=1
  else:
   raise AssertionError('endpoint minimum ordering unresolved; do not claim PASS')
  best.append(prices[2*p+k])
  perparent.append({'name':parents[p]['name'],'old_price':iv(old),'endpoint_price':iv(endpoint),'certified_endpoint_set_minimizer':k,'chosen_mixed_probabilities':[str(w[2*p]),str(w[2*p+1])],'chosen_average_price':iv(A(w[2*p])*old+A(w[2*p+1])*endpoint)})
 Kdisc=E-sum(best,arb(0));margin=Kdisc-E/16
 assert Kdisc>=0 and margin>0
 # Exact probability law gives E=sum_p E_pi[p] price; cross-check the ledger.
 avg=sum((A(w[v])*prices[v] for v in range(8)),arb(0));assert (avg-E).contains(0)
 rows.append({'n':cfg['n'],'R606_status':report['status'],'law':'R606 frozen rational mixture over {1,G}, all four original bulk blocks covered','E':iv(E),'sum_endpoint_set_min_prices':iv(sum(best,arb(0))),'K_discrete':iv(Kdisc),'K_discrete_over_E':iv(Kdisc/E),'threshold_E_over_16':iv(E/16),'K_discrete_minus_E_over_16':iv(margin),'all_parent_prices':perparent,'conclusion':'STRICTLY_NOT_LOW_FULL_GAP: K_full >= K_discrete > E/16','identity_average_price_equals_E_difference_contains_zero':True,'full_gap_bounds':{'lower':iv(Kdisc),'upper':iv(E),'upper_reason':'All kernels and A are nonnegative, so every action price is nonnegative and K_full<=E.'},'full_gap_oracle_run':False,'new_intermediate_actions':0})
out={'status':'PASS_BOTH_R606_MIXTURES_EXCLUDED_FROM_LOW_FULL_GAP','meaning':'For each frozen finite construction only; no assertion about general inputs or all possible laws on these inputs.','gap_definition':'K_full=E-sum_p integral_{H_p} inf_{1<=g<=G}<A,v(B,g)> dB. V_pk=integral_{H_p} v(B,g_k)dB denotes only the certified endpoint block action, g_k in {1,G}.','direction':'Pointwise in B, inf_full action price <= min of endpoint prices. Certified endpoint fields are constant in each H_p, hence integral_{H_p} min_k price(B,k) dB = min_k <A,V_pk>. Therefore K_full >= K_discrete=E-sum_p min_k <A,V_pk>. Strict K_discrete>E/16 excludes K_full<=E/16. No interchange of a general infimum and block integral is assumed.','center_reduction':'R606 entire-block signatures make both endpoint action fields constant across B within each actual block. Endpoint inf can be selected measurably blockwise. No claim that intermediate g has a constant signature is used.','source_code_sha256':sha,'source_definition_import':'Read-only R606 source, compile only prefix before bottom-level initial=compute; extend function return in memory. No R606 output code executed.','rows':rows,'python_flint_version':flint.__version__,'source_script_path':str(source_path),'arithmetic':'512-bit Arb; geometry/probabilities Fraction; every price minimum branch ordered by strict Arb comparison. No floating PASS.','interpreter':sys.executable,'processes':1,'runtime_seconds':time.perf_counter()-START,'maxrss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'R606_source_after_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest()}
assert out['source_code_sha256']==out['R606_source_after_sha256']
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r607_gap.json')
output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'n':r['n'],'K_discrete_over_E':r['K_discrete_over_E']['display'],'margin':r['K_discrete_minus_E_over_16']['display'],'conclusion':r['conclusion']} for r in rows],'runtime_seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
