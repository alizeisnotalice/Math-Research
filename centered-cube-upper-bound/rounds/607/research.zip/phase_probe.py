from fractions import Fraction as F
from pathlib import Path
import json,sys,flint
from flint import arb,ctx
ctx.prec=256
n=128;h=F(1,12);eta=F(1,n*n);G=F(2**30)
V=F(4,n)*(1-2*eta)**(n-1);H=(1+F(12,n)+eta)**n
def A(x):
 x=F(x);return arb(x.numerator)/x.denominator
def iv(x):return {'lo':str(x.lower().fmpq()),'hi':str(x.upper().fmpq()),'display':x.str(24)}
# Exact one-coordinate extremal distances; other coordinates are easier.
assert F(2,n)+eta/2<F(1,2)
assert F(1,2)+F(4,n)-eta/2>F(2,n)+F(1,2)
assert (1+F(12,n)+eta)/2==F(1,2)+F(4,n)+eta/2+F(2,n)
assert H<G<2**n
An=1+n*arb(2).log();C=1+arb(2).log();alpha=A(V)/C
assert An*alpha>A(F(3,2))
assert F(3,2)**12>2**7 and F(3,2)**12<2**8
assert F(3,2)**12>2
coefficient=(1-h)*G*G/(G*G+7*H*H)
assert coefficient>F(9,10)
qoverw=V*V/F(3,2);endpointoverw=V*V/(G*G)
assert endpointoverw<1
out={'n':n,'h':str(h),'eta':str(eta),'G':str(G),'V':str(V),'H':str(H),
 'An_alpha':iv(An*alpha),'H_decimal':iv(A(H)),
 'phase_max':7,'lower_coefficient_G2E_over_Q':str(coefficient),
 'lower_coefficient_decimal':iv(A(coefficient)),
 'Q_over_W':str(qoverw),'Q_over_W_decimal':iv(A(qoverw)),
 'endpoint_E_over_W':str(endpointoverw),'endpoint_E_over_W_decimal':iv(A(endpointoverw)),
 'scope':'One actual n128 input; contracts checked. All-law lower bound follows analytic proof, not enumeration. W payment is possible; no general upper bound.',
 'python':sys.version.split()[0],'interpreter':sys.executable,'python_flint':flint.__version__,'arb_bits':ctx.prec}
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r607_phase_probe.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['An_alpha','H_decimal','phase_max','lower_coefficient_decimal','Q_over_W_decimal','endpoint_E_over_W_decimal']},indent=2))
