# R197 physical scalar moment diagnostics

The approved menu contains 21 cases, each evaluated at 25 and 40 decimal digits. Initial/stress/expanded stages use s=1/4,1/2,9/10 for the nine primary shifted moments and three negative-q tests. Centered controls add s=1/2 and s=1. The stage totals are 5/8/8. No new dimension or source/history scan was performed.

The actual moment is M(q,z;d,s)=integral f_s(x-d)^(1+q) phi(x)^(z-q) f_s(x)^(-z) dx, with L=b=1, y=d and v=0. phi uses the inherited E3 representation and the hard core has explicit closed membership. Both current kernels have strictly positive s, so the log-power evaluation never divides by a zero tail. All cases satisfy -1<q<=1 and 0<=z<=1+q.

Each finite quadrature is split at both hard-face pairs, both centers and additional fixed tail points. For |x|>X>|d|+1/2 the supplied analytic log-Lipschitz bound gives the integrand upper s^(1+q-z) exp((1+q)Lphi|d|) phi(x), with Lphi=2/(1-exp(-1)). Together with integral_|x|>X phi <=2 exp(1/2-X), this bounds the omitted tails. The cutoff is chosen with one extra unit of slack to make the displayed analytic tail contribution below 1e-20 or 1e-30, respectively. This controls mathematical truncation, not finite quadrature or floating rounding. No directed interval claim is made.

All 21 precision comparisons pass 1e-16, with maximum observed difference below 2.93e-23. The exact q=z=0 normalization and centered s=1 controls agree with unity up to truncation and numerical differences. The centered s=1/2,q=z=1/2 point is evaluated without prescribing a value and numerically agrees with unity; the centered q=1,z=1/2 moment is about 1.094911. None of these scalar controls constructs original good, same-alpha, FIRST or FULL eligibility.

All nine selected positive-q shifted moments exceed one, approximately 1.161 through 41.024. Their bare tensor moment factors therefore carry an exponential cost, rather than providing decay alone. The added q=-1/4,z=0,d=2 moments are approximately 0.554404, 0.609771, 0.671000 for s=1/4,1/2,9/10: these do provide bare moment decay. However the correctly C-normalized values C(2)^q M are about 1.212693, 1.333801, 1.467735, all above one. Here C(2)=E4(1)-2E4(2)+E4(3), not phi(2). Conversely several positive-q C^q M values are below one, including about 0.522293 at s=.9,d=2,q=1,z=.5. These are finite diagnostics, not far-shift limits, optimal Chernoff parameters or a completed original price.

The JSON retains the entire symbolic price wt U^(1-q) delta^z product_i M_i, with U=K/[3(1-eta)wg], delta=eta/[a_n(1-eta)] and original clipped wt,wg factors. No xi_t,xi_g,n or original eta is silently selected; C^q M is only a separate useful diagnostic and does not replace those factors or the actual two-cut qualification. A finite M below one cannot be declared a paid branch.

Reproduce with existing Python and mpmath 1.3.0, without installing anything:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 kernel_moment_checks.py --output kernel_moment_checks.json
```

Relocation needs only the script and local task_contract.md. JSON records the contract filename hash and mpmath version/entry SHA, not absolute mathematical input paths or runtime. The 21-case run took about 5.1 seconds. A fresh temporary-directory copy was independently replayed and its complete JSON matched byte-for-byte. Only the assigned three numerical files were written. The results are finite physical scalar kernel calculations with analytic truncation control and empirical quadrature comparisons, not a uniform theorem, dimension-order fit, multidimensional integral, or physical FULL source/history certificate.
