# R197：逆 K0 占用的接收域截断与同尺度尾部障碍

本稿检验 R196 CG11–14 中一个具体接缝：能否把低 K0/w 的占用用一个全空间接收核积分直接支付。结果是一个保留真实 high 的全 selector 有限核界，以及一个精确同尺度尾部障碍。有限界的维度、来源位置与质量/阈值费用全部保留，尚不能支付一般 CC22 或其尾项；没有更换原 α、来源或 capture。

## OK1. 原参数与被估计的物理核

在一个原共同窗口保持 q 固定，a≤L(x),Hhat(x)≤b≤2a，原 s(x)≥s0>0，s0 是原严格软下门的一个统一正下界。J_v=P_{1,b}(x−v)，K0_z=P_{s(x),Hhat(x)}(x−z)，p_y=P_{s(x),L(x)}(x−y)。Hhat 仍是原 clamp，不另选。

A、A_d、α、χ、ν、μ、Pi、history 与全部 source/cell 数据均为原对象。c>0 是 R196 的同一个匹配比例，

\[
 A_d(v)={[(c+1)A(v)-1]_+\over c}\in[0,1].
\]

所有原无效 target 槽先取零。下面的主核工具估计

\[
 \mathcal K(x;y,v,z)
 ={p_y(x)^2 A_d(v)^2\over J_v(x)K0_z(x)}.
 \tag{OK1}
\]

这是含实际 capture target 因子的物理 Cauchy 核构件，**不是** CC22 的完整被积式。CC22 还含 original e、outer β、Mi^tar、occupation 和不同的 target/来源系数；不能把 OK1 的界直接叫作该原 raw 的价格。若需 w_t(y,z)/k_z，其中 k=DK0，则须保实际 D；只有 D 在所积 receiver 域固定时才能将 1/D 提出。一般可用原 D≥1 正上放为 w_t(y,z)/K0，不能免费提出 receiver-dependent D。

ν=ν_V 是原来源，Nν=ν(V)<∞。原 high 给 p_y e_g(y)≥2Kq，且 e_g(y)≤Nν。若 Nν=0 或原 high 为空，该行先取零。μ、ν、β 没有新的排序，不使用 ν≤β。

## OK2. 真实 high 的共同 rounded-cube 包含

记 f_s(r)=(1−s)h(r)+sφ(r)，h=1[-1/2,1/2]，φ=h*w，w(r)=∫_0^1e^{−|r|/t}dt。因为 w≤1，φ≤1；在 |r|>1/2，φ(r)≤e^{−(|r|−1/2)}。故对所有 s∈[0,1]

\[
 f_s(r)\le\exp[-(|r|-1/2)_+].
\]

由于 L≤b、L^{-n}≤a^{-n}，对原任意自适应 `(s(x),L(x))` 点态有

\[
 p_y(x)\le a^{-n}\exp\!\left[-\sum_i
             (|x_i-y_i|/b-1/2)_+\right].
 \tag{OK2}
\]

定义

\[
 R=\log{N_\nu\over2Kq a^n}.
\]

若 R<0，原 high 为空；若 R≥0，真实 high 接收点都在

\[
 \mathcal R_R(y)=\left\{x:\sum_i(|x_i-y_i|/b-1/2)_+\le R\right\}.
 \tag{OK3}
\]

这是对实际 high 的正包含，无须固定 s、L、Hhat，也没有参数菜单费。它不是原森林的来源密度结论。

该集合体积精确为

\[
 |\mathcal R_R(y)|=b^n\mathcal V_n(R),\qquad
 \mathcal V_n(R)=\sum_{j=0}^n\binom nj{(2R)^j\over j!}.
 \tag{OK4}
\]

证明：按恰有 j 个坐标在单位中心盒外分解；选择坐标、两侧符号后，j 个非负超出距离落在和≤bR 的 simplex 中，体积为 (bR)^j/j!，其余坐标总长度 b^{n−j}。边界零测不改变结果。R=0 时体积 b^n。特别原 high 上

\[
 \|x-y\|_1/b\le n/2+R.
 \tag{OK5}
\]

## OK3. 全原尺度/软度的有限接收界及真实费用

采用已审原 log-Lipschitz 界 |φ'|≤Lφφ，Lφ=2/(1−e^{−1})，令 φ0=φ(0)>0。于是

\[
 J_v\ge b^{-n}\phi_0^n e^{-L_\phi\|x-v\|_1/b}.
\]

又因 f_s≥s0φ、Hhat∈[a,b]、φ 偶且径向非增，

\[
 K0_z\ge s_0^n b^{-n}\phi_0^n
                  e^{-L_\phi\|x-z\|_1/a}.
 \tag{OK6}
\]

py≤a^{-n}，Ad≤1；由 OK5 与三角不等式，在原 high 上

\[
 \mathcal K(x;y,v,z)\le\mathcal C_n(R;y,v,z),
\]
\[
 \boxed{\mathcal C_n=
 (b/a)^{2n}s_0^{-n}\phi_0^{-2n}
 \exp\!\left\{L_\phi\left[
 (1+b/a)(n/2+R)+\|y-v\|_1/b+\|y-z\|_1/a\right]\right\}.}
 \tag{OK7}
\]

因此实际自适应 receiver 子域上的明确工具为

\[
 \boxed{\int_{E_{\rm rec}\cap\rm high}\mathcal K(x;y,v,z)\,dx
 \le b^n\mathcal V_n(R)\mathcal C_n(R;y,v,z).}
 \tag{OK8}
\]

原 unique-j、capture/history/good/reciprocal 及其余 nonnegative masks 可全部保留在左边；右边正上放才删去。原 α 未被独立选择；本估计只对实际 Ad 用≤1，故也没有假装利用其全部抑制。

这是全原 selector 的点态统一界，**没有免费取 supremum 的步骤**。其价格却通常很大：s0约为常数/n 时已有 s0^{-n} 的 n^n 量级；还保留 V_n(R)、exp[O(n+R)]、source–target 距离及 source–source 距离指数。Nν/q 也不能在原窗族免费统一。这些费用不等于 n^{o(1)}，不登记根阶付款。

固定原 `(j,y,t)` 下的 w_t(y,z) 不依 receiver；对含 w_t/k 的工具，一般先用 D≥1 正上放，再令 OK8 右侧同乘 w_t。仅在认证 D 也固定时，可进一步同乘 1/D。若再对一个真正不依 receiver x 的正联合来源测度 Γ(dy,dv,dz) 积分，可以直接 Tonelli 并保留右侧全部来源权。但原 CC22 的 M_x、Mi^tar(x)^{-1}、failure/cell 判定通常依 x，不能把它们冒充这种固定 Γ。即便 M_x≤μ 可正上放，逆 Mi^tar 仍需单独控制，本文不删去它。

## OK4. 同尺度保留 signed 硬面的较细构件

若原实际子域 L=Hhat=b，固定 s 时令

\[
 B_s=s+(1-s)/\phi(1/2),\qquad
 j_s=\log{1-s+s\phi(1/2)\over s\phi(1/2)}.
\]

对任意 r，f_s(r)/φ(r)≤B_s。因此

\[
 {p_y\over J_v}\le B_s^n e^{L_\phi\|y-v\|_1/b}.
\]

同核去跳比较给

\[
 {p_y\over K0_z}\le
 \exp\!\left[L_\phi\|y-z\|_1/b
  +j_s\{N_b(y;x)-N_b(z;x)\}\right],
\]

其中 N_b(z;x)=#{i:|x_i−z_i|≤b/2}；闭面属于 inside。因此若该原接收子域认证有向计数差≤m_+，

\[
 \int_{\rm high}\mathcal K\,dx
 \le b^n\mathcal V_n(R)B_s^n
 e^{L_\phi(\|y-v\|_1+\|y-z\|_1)/b+j_s m_+}.
 \tag{OK9}
\]

这里可用 L=b 时更小的 R=log[Nν/(2Kq b^n)]。s 自适应但 s≥s0 时可点态用 B_s≤1/φ(1/2)、j_s≤j_s0；无需另付 soft 菜单，但这些指数损失仍保留。不能把该 endpoint 工具移植为一般 L/Hhat 相等或 hard crossing 为零。

## OK5. 一条精确尾部障碍：不能先丢 high 再积逆核

这只检验一种拟议的 kernel enlargement，不构造违反原 FIRST/high 的输入，也不下界原 core 交通。取同尺度 L=Hhat=b、s>0，固定有限源 y,v,z 及其余 n−1 个 receiver 坐标，让 x1→+∞。原核尾可直接证明：

\[
 w(r)\sim e^{-r}/r,\qquad
 \phi(r)\sim A_\phi e^{-r}/r,\quad A_\phi=2\sinh(1/2).
 \tag{OK10}
\]

第一式令 t=r(1/a−1)，得到

\[
 w(r)={e^{-r}\over r}\int_0^\infty e^{-t}(1+t/r)^{-2}dt;
\]

受 e^{-t} 支配，积分趋于1。第二式在 φ=h*w 的有限区间上用 dominated convergence；r/(r−a) 有统一界，极限因子为 ∫_{−1/2}^{1/2}e^a da。没有拟合或数值渐近推断。

记 P_y^perp、J_v^perp、K0_z^perp 为其余 n−1 个坐标的真实乘积密度。由于第一坐标最终在所有 current hard cores 外，准确有

\[
 {p_y(x)^2\over J_v(x)K0_z(x)}
 \longrightarrow
 s\,{(P_y^{\perp})^2\over J_v^{\perp}K0_z^{\perp}}
       e^{(2y_1-v_1-z_1)/b}>0.
 \tag{OK11}
\]

对其余坐标任一避开有限硬面的紧盒，该极限可取统一正下界。因此丢去 high 后的全空间裸逆核积分无限。n=1 时无需其余盒。它说明把 Ad≤1、high 也丢掉之后，不能依靠“都是概率核”获得该 inverse-K0 构件的 L1 价格。

R196 的 same-α quadratic 也不能被误读为一个额外衰减核：其 Fc=[c−r−(c+1)k/a]+²/[4c(c+1)(1+r)] 是有界代数系数，未包含保证接收尾衰减的结论。本稿不冻结或重新选择实际 α 来强造 Ad 的正尾；若要证明原 Ad、good、FIRST 等共同杀掉这个 resonance，必须在实际 receiver 积分中另证。OK11 只否定上面的全空间 enlargement，而不否定原真实截断积分可被更精确支付。

## OK6. 与当前余域的接缝与首个缺口

父 R195 的实际定位保留 `(1−s)^2D1(y,u)<r1_n`，给合格原 outer–bad pair 的完整 l1 近，但它没有 v、z；不能删除 OK7/9 的 y−v、y−z 费用。R194 的邻点 capture 率还要求真实 z−v 半径、Δ 时间对比度及 signed Hhat crossing，不能由该 outer–bad 定位补出。

原 CC22/R196 CG11 的 tail 实际包含 w(z)/k_z、Mi^tar(x)^{-1} 和 receiver-dependent source-cell membership。OK8 在不丢 high 的条件下给了一个明确有限核成本；OK11 说明为什么不能简单去掉其 level/体积截断。下一步若要将此构件接入 CC22，必须同时保持原 Cauchy/target 系数并控制这些来源权，而不能把一个 fixed Γ 下的 kernel estimate 当成实际 double-source 总账。

本路线没有取得 polylog 来源费，也没有证明一般 occupation tail 可积到目标阶数。准确障碍是逆核的同尺度尾部与原 high 截断不可随意交换，伴随实际 source normalizers 仍未被几何控制。除本稿全费用构件与此单一范围检查外，不扩大反例或参数搜索。到此停止。
