#!/usr/bin/env python3
"""Bounded physical scalar Chernoff moments; not interval or FULL evidence."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
import hashlib,json,time
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def runtime(dps):
    mp.mp.dps=dps
    def val(q):return mp.mpf(q.numerator)/q.denominator
    def out(x):return mp.nstr(x,dps+5)
    half=mp.mpf(1)/2
    @lru_cache(maxsize=65536)
    def phi(x):
        x=abs(x)
        return 1-mp.expint(3,half-x)-mp.expint(3,half+x) if x<=half else mp.expint(3,x-half)-mp.expint(3,x+half)
    def C(x):
        x=abs(x)
        return 1-x+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,x)+mp.expint(4,x+1) if x<=1 else mp.expint(4,x-1)-2*mp.expint(4,x)+mp.expint(4,x+1)
    def evaluate(sq,dq,qq,zq):
        s,d,q,z=map(val,(sq,dq,qq,zq))
        assert 0<s<=1 and -1<q<=1 and 0<=z<=1+q
        Lphi=2/(1-mp.exp(-1))
        logpref=(1+q-z)*mp.log(s)+(1+q)*Lphi*abs(d)
        target_digits=20 if dps==25 else 30
        # An additional unit gives slack in this floating choice of cutoff.
        X=max(abs(d)+half+1,mp.ceil(mp.log(2)+logpref+half+target_digits*mp.log(10))+1)
        tailbound=2*mp.exp(logpref+half-X)
        assert tailbound<mp.mpf(10)**(-target_digits)
        def fs(x):return (1-s)*(abs(x)<=half)+s*phi(x)
        def integrand(x):
            p,j,f=fs(x-d),phi(x),fs(x)
            assert p>0 and j>0 and f>0
            return mp.exp((1+q)*mp.log(p)+(z-q)*mp.log(j)-z*mp.log(f))
        cuts=sorted(set([-X,X,-half,mp.mpf(0),half,d-half,d,d+half]+[v for v in map(mp.mpf,(-32,-16,-8,-4,-2,-1,1,2,4,8,16,32)) if -X<v<X]))
        moment=mp.quad(integrand,cuts)
        assert moment>0
        control=(qq==0 and zq==0) or (sq==1 and dq==0)
        if control:assert abs(moment-1)<mp.mpf('1e-18')+tailbound
        return {'dps':dps,'cutoff_X':out(X),'finite_quad':out(moment),'analytic_truncation_upper':out(tailbound),
            'target_truncation_digits':target_digits,'log_finite_moment':out(mp.log(moment)),
            'C_d':out(C(d)),'C_power_q_times_finite_moment':out(mp.exp(q*mp.log(C(d)))*moment),'unity_control':control,
            'moment_above_one_by_more_than_1e_minus_16':moment>1+mp.mpf('1e-16'),
            'moment_below_one_by_more_than_1e_minus_16':moment<1-mp.mpf('1e-16'),
            'finite_seams':[out(x) for x in cuts],
            'tail_bound_log_prefactor':out(logpref),'L_phi':out(Lphi)}
    return evaluate

def run():
    specs=[]
    for stage,s in [('initial',F(1,4)),('stress',F(1,2)),('expanded',F(9,10))]:
        for d,q,z in [(F(1,2),F(1,2),F(0)),(F(1,2),F(1,2),F(1,2)),(F(2),F(1),F(1,2))]:
            specs.append((stage,'selected_shift_moment',s,d,q,z))
    for q,z in [(F(0),F(0)),(F(1,2),F(1,2)),(F(1),F(1,2))]:
        specs.append(('stress','centered_mixed_control',F(1,2),F(0),q,z))
        specs.append(('expanded','centered_pure_soft_unity',F(1),F(0),q,z))
    for stage,s in [('initial',F(1,4)),('stress',F(1,2)),('expanded',F(9,10))]:
        specs.append((stage,'shifted_q_z_zero_unity',s,F(2),F(0),F(0)))
    for stage,s in [('initial',F(1,4)),('stress',F(1,2)),('expanded',F(9,10))]:
        specs.append((stage,'negative_q_strategy',s,F(2),F(-1,4),F(0)))
    rows=[{'stage':stage,'label':label,'s':str(s),'d':str(d),'q':str(q),'z':str(z),'runs':[]} for stage,label,s,d,q,z in specs]
    for dps in (25,40):
        evaluate=runtime(dps)
        for row,(_,_,s,d,q,z) in zip(rows,specs):row['runs'].append(evaluate(s,d,q,z))
    for row in rows:
        lo,hi=row['runs'];diff=abs(mp.mpf(lo['finite_quad'])-mp.mpf(hi['finite_quad']))
        assert diff<mp.mpf('1e-16')
        row['absolute_precision_difference']=mp.nstr(diff,12)
    main=[r for r in rows if r['label']=='selected_shift_moment']
    return {'schema':'r197_kernel_moment_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'formula':'M(q,z;d,s)=integral f_s(x-d)^(1+q) phi(x)^(z-q) f_s(x)^(-z) dx',
        'exponent_domain_checked':'-1<q<=1, 0<=z<=1+q',
        'fixed_geometry':{'L':1,'b':1,'y':'d','v':0,'s_strictly_positive':True},
        'retained_tensor_bound':{'generic':'wt * U^(1-q) * delta^z * product_i M(q,z;d_i,s)',
            'original_U':'K/[3(1-eta) wg]','original_delta':'eta/[a_n(1-eta)]',
            'original_weights':'wt=product_i min(1,C(d_i)/xi_t); wg=product_i min(1,C(d_i)/xi_g)',
            'qualification':'Only applies on the stated two ratio cuts; no original good/alpha/FIRST/full eligibility is numerically constructed.'},
        'tail_argument':{'domain':'X>|d|+1/2; both f arguments outside their hard cores',
            'integrand_upper':'s^(1+q-z) exp((1+q)Lphi |d|) phi(x)',
            'tail_mass_upper':'integral_|x|>X phi(x) <= 2 exp(1/2-X)',
            'combined_upper':'2 s^(1+q-z) exp((1+q)Lphi |d|+1/2-X)',
            'status':'Analytic truncation bound evaluated with mpmath, not a directed-rounding interval for either cutoff or quadrature.'},
        'case_count':len(rows),'stage_counts':{stage:sum(r['stage']==stage for r in rows) for stage in ('initial','stress','expanded')},'precision_dps':[25,40],'cases':rows,
        'summary':{'selected_shift_moments':len(main),'selected_above_one':sum(r['runs'][1]['moment_above_one_by_more_than_1e_minus_16'] for r in main),
            'selected_below_one':sum(r['runs'][1]['moment_below_one_by_more_than_1e_minus_16'] for r in main)},
        'status':'PASS','limitations':['Finite actual scalar density moments only; no original multidimensional integral or FULL source/history instance.',
            'Analytic truncation control does not certify finite quadrature or mpmath rounding; two-precision differences are empirical.',
            'The displayed tensor bound keeps wt,wg and both cut factors. M alone is not the full price.',
            'No dimension substitution, asymptotic fit, uniform moment theorem, or optimized Chernoff parameter is claimed.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'kernel_moment_checks.json');args=ap.parse_args()
    t=time.monotonic();r=run();args.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'case_count':r['case_count'],'summary':r['summary'],'seconds':round(time.monotonic()-t,3)},sort_keys=True))
