from fractions import Fraction as F
from math import comb
from pathlib import Path
import argparse,json
p=F(1,64)
rows=[]
for stage,ms in [('initial',[0,1,2]),('stress',[8,32,128]),('expanded',[256,512,1024])]:
 for m in ms:
  weights=[F(comb(m,k))*p**k*(1-p)**(m-k) for k in range(m+1)]
  assert sum(weights)==1
  aa=[F(comb(k,k//2),2**k) for k in range(m+1)]
  assert all(a*a<=F(2,k+1) for k,a in enumerate(aa))
  r=sum(w*a for w,a in zip(weights,aa))
  e=sum(w/F(k+1) for k,w in enumerate(weights))
  closed=(1-(1-p)**(m+1))/((m+1)*p)
  assert e==closed and r*r<=2*e and r<=1 and r*r<=F(128,m+1)
  rows.append({'stage':stage,'m':m,'r_display':float(r),'r_squared_le_128_over_m_plus_1':True,'exact_inverse_binomial_identity':True})
# Rational physical interval constants only; not quadrature.
mass=F(1,16)*F(1,8);gap=F(3,16)-F(1,16);h=F(1,16)
assert mass==F(1,128) and gap==F(1,8) and gap>h
result={'status':'PASS','arithmetic':'Fraction','cases':rows,'physical_constants':{'interval_mass_lower':str(mass),'loglikelihood_gap_lower':str(gap),'bin_width':str(h)},'scope':'Finite exact checks of the binomial mixture and interval constants, not a full geometric or adaptive-source proof.'}
a=argparse.ArgumentParser();a.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=a.parse_args();args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
