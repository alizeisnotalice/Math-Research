# R197: two-cut physical moments, negative powers and the far-displacement clock

This manuscript gives an explicit physical kernel bound, its full positive selector enlargement, and a far-displacement decision formula with the overlap constants retained. It does not declare the resulting source column paid. The complementary finite-displacement anti-concentration estimate is proved in `finite_displacement_geometry.md`; its role and remaining fees are recorded below.

## TK1. The original necessary cuts and normalization

Fix original sources y,v and a common window with b fixed. For a fixed current pair `(s,L)`, put `lambda=L/b in [1/2,1]` and use the normalized coordinate `z=(x-y)/b`, `d=(v-y)/b`. Define

    p_i(z)=lambda^(-1) f_s(z/lambda),
    q_i(z)=lambda^(-1) f_s((z-d_i)/lambda),
    j_i(z)=phi(z-d_i),
    p=product_i p_i, qv=product_i q_i, j=product_i j_i.

The physical densities all have the same factor b^(-n); it cancels in their ratios and in `integral P_y^2/J_v dx`. No extra power of b is omitted. The scalar definitions are the original

    h=1_[-1/2,1/2], w(r)=integral_0^1 exp(-|r|/t)dt,
    phi=h*w, f_s=(1-s)h+s phi, C=h*max(h,phi).

Write the original same-clock source weights as

    w_t=product_i min(1,C(d_i)/xi_t),
    w_g=product_i min(1,C(d_i)/xi_g),
    1/2<=xi_t<=xi_g<=1.

Here fixed g is part of the fixed-parameter kernel statement, not a new terminal selection. On the original good, high-A region `A>=1-eta`, `0<eta<1`, R196 TD2 and TD11 imply the necessary cuts

    p/j <= B0/w_g,       qv/j <= R0,
    B0=K/[3(1-eta)],     R0=eta/[a_n(1-eta)],
    a_n=1+gamma^(-n).                              (TK1)

The first cut safely enlarges the sharper actual bound with rho in its numerator by using rho<=1. Keeping rho would require retaining its original receiver dependence. We never replace it by an independently selected value. Other original masks can only reduce the positive integral considered here.

The kernel to be bounded is

    I(s,lambda,d;xi_t,xi_g)
       = w_t integral (p^2/j)
            1_{p/j<=B0/w_g} 1_{qv/j<=R0} dz.       (TK2)

This is a receiver integral for fixed source positions. Product structure used below belongs to the receiver densities; no independence of source coordinates is assumed.

## TK2. A two-cut product bound that allows negative powers

For `0<s<=1`, choose common parameters

    -1<theta<=1,       0<=beta<=1+theta.

Define the completely specified scalar moment

    M_(theta,beta)(s,lambda,d)
       = integral p_lambda(z)^(1+theta)
           phi(z-d)^(beta-theta)
           p_lambda(z-d)^(-beta) dz.              (TK3)

Then

    I <= w_t (B0/w_g)^(1-theta) R0^beta
                     product_i M_(theta,beta)(s,lambda,d_i).  (TK4)

Proof: on the first cut `r=p/j<=B0/w_g`,

    r^2 <= (B0/w_g)^(1-theta) r^(1+theta).

This inequality requires theta<=1, not theta>=0. The second cut gives `1_{qv/j<=R0} <= R0^beta (qv/j)^(-beta)`. Multiplication by j and Tonelli prove TK4. Positivity of the original strictsoft kernels makes the negative powers legitimate. The s=0 endpoint is not included when beta>0, since the target current kernel then has a zero tail. For beta=0 it is legitimate with `p^(1+theta)=0` at p=0.

For fixed finite d the scalar moments are finite. Indeed phi(r) is comparable, with positive absolute constants, to `exp(-|r|)/(1+|r|)`. For s>0 the current density has the corresponding scale-lambda tail. The total exponential decay rate of the TK3 integrand in either far tail is

    (1+theta-beta)/lambda + beta-theta >= 1,        (TK5)

because `1+theta-beta>=0` and lambda<=1. Its combined polynomial power is -1. Constants may depend on the fixed s,lambda,d and exponents; finiteness is not a uniform source price.

The negative theta range is useful for a capped *lower* likelihood tail. It should not be removed merely because the untruncated expression is often called a positive-order moment. Optimizing over any countable menu of these explicit bounds is valid; it incurs no union cost for a fixed kernel. This does not license choosing a different physical selector or source law.

## TK3. An explicit route through all current selectors

The beta=0 bound admits a positive selector enlargement without dividing by an adaptive target current kernel. This enlargement sacrifices the second cut; that loss is explicit.

Since `w_g>=C_*:=product_i C(d_i)`, every original good high-A point satisfies `p/j<=B0/C_*`, even when its original g depends on x. Put `a_theta=1+theta>0`. For each lambda,

    sup_s p_(s,lambda)^a_theta
       <= exp(a_theta)(n+1) integral_0^1 p_(r,lambda)^a_theta dr.  (TK6)

For a given s, every `r in [ns/(n+1),(ns+1)/(n+1)]` has `f_r>=n f_s/(n+1)`. Its interval has length 1/(n+1), proving TK6 including the soft endpoints. Raising a nonnegative kernel to the positive power a_theta preserves this argument.

At fixed receiver z, `lambda^(n a_theta) sup_s p_(s,lambda)^a_theta` is nondecreasing, with the original closed-face convention. The positive radial Stieltjes envelope therefore bounds its scale supremum by the lambda=1 endpoint plus `n a_theta` times the logarithmic scale integral. Multiplication by the fixed `j^(-theta)` and Tonelli yield the following genuinely adaptive upper bound:

    w_t integral sup_(s,lambda) [
        p_(s,lambda)^2/j 1_{p_(s,lambda)/j<=B0/C_*}] dz
      <= w_t (B0/C_*)^(1-theta) exp(a_theta)(n+1)
          [ integral_0^1 product_i M_(theta,0)(s,1,d_i) ds
            + n a_theta integral_(1/2)^1 integral_0^1
                product_i M_(theta,0)(s,lambda,d_i) ds dlambda/lambda ]. (TK7)

The right side may be infinite; in that case TK7 is only a valid extended upper bound, not a budget. When finite it is an explicit integral of the physical one-dimensional moments. The powers, softness cost, scale cost and enlarged terminal cap are all displayed. Moving hard faces were retained through monotonicity; they were not discarded as null sets.

TK7 is not obtained for beta>0 by the same proof: the inverse target current factor in TK3 then changes with the selector. Nor may the fixed-g cap of TK4 be silently used in TK7 while g is adaptive. The replacement by C_* is the explicit price paid for that issue here.

## TK4. Correct physical far-tail constants

Let `H1=integral_[-1/2,1/2] exp(r)dr=2sinh(1/2)`. The exact asymptotics are

    w(d) ~ exp(-d)/d,
    phi(d) ~ H1 exp(-d)/d,
    C(d) ~ H1^2 exp(-d)/d,            d -> +infinity.          (TK8)

In particular C is not phi. To prove the first assertion, substitute `u=d(1/t-1)`:

    d exp(d) w(d)
      = integral_0^infinity exp(-u) d^2/(d+u)^2 du -> 1.

Dominated convergence proves the limit. Convolving once with h supplies the factor H1. For d>=1, `C(d)=(h*phi)(d)`, since `max(h,phi)=phi` on the relevant interval up to irrelevant endpoints. A second convolution supplies the second H1.

For fixed `p_lambda=lambda^(-1)f_s(./lambda)` and beta=0, if

    theta > -1/(1+lambda),                         (TK9)

then the C-normalized physical moment has the limit

    C(d)^theta M_(theta,0)(s,lambda,d)
       -> H1^theta integral p_lambda(z)^(1+theta) exp(-theta z) dz.
                                                               (TK10)

The same limit holds for d->-infinity by reflection. For each fixed z, TK8 gives `C(d)/phi(z-d)->H1 exp(-z)`.

Here is a dominating bound, including negative theta. Elementary integration gives two-sided absolute bounds for w, and hence phi, by `exp(-|z|)/(1+|z|)`. For example the t interval `[1-1/(2(1+|z|)),1]` gives the lower bound for w, and `1/t>=1+(1-t)` gives the upper bound. These bounds imply

    max(phi(d)/phi(d-z), phi(d-z)/phi(d))
       <= C exp(|z|)(1+|z|).

The ratio C(d)/phi(d) is bounded above and below for d>=1. Thus the normalized TK10 integrand is at most a constant times

    p_lambda(z)^(1+theta)
        exp(|theta||z|)(1+|z|)^|theta|.

Its exponential rate is `(1+theta)/lambda-|theta|`, which is positive for theta>=0 and precisely under TK9 for negative theta. This proves dominated convergence. The larger finite-d moment range TK5 must not be confused with the smaller range required by this far-displacement limit: outside TK9, mass can move with the displaced center.

## TK5. The full saturated clock factor and a quantitative entropy decision

Consider identical coordinate displacements d, with n fixed during d->infinity. Eventually `C(d)<xi_t<=xi_g`, so the physical weights are saturated:

    w_t=(C(d)/xi_t)^n, w_g=(C(d)/xi_g)^n.

For beta=0 the complete TK4 upper bound is then exactly

    B0^(1-theta)
      [ (xi_g^(1-theta)/xi_t)
                C(d)^theta M_(theta,0)(s,lambda,d) ]^n.       (TK11)

Both B0^(1-theta) and the xi factors are essential. Define under `X~p_lambda`

    Z_g(X)=log(H1 p_lambda(X)/xi_g)-X,
    m_g=E Z_g=log(H1/xi_g)-h(p_lambda),
    V_g=E[Z_g^2 exp(|Z_g|/4)],
    h(p_lambda)=-integral p_lambda log p_lambda.

The mean of X is zero by symmetry. These moments are finite for `0<s<=1`, `lambda in [1/2,1]`: the exponential rate for the extra quarter-power factor is still positive. Moreover `h(p_lambda)=h(f_s)+log lambda`, so the effect of changing physical scale on the mean is explicit. The limiting per-coordinate bracket in TK11 is

    (xi_g/xi_t) E exp(theta Z_g).                  (TK12)

If m_g is nonzero, set

    theta_*=-sign(m_g) min(1/4, |m_g|/V_g),
    Delta_g=|theta_* m_g|/2 >0.

The case V_g=0 would force m_g=0 and is excluded here. Taylor's inequality gives, for |theta|<=1/4,

    E exp(theta Z_g)<=1+theta m_g+theta^2 V_g/2.

Therefore

    E exp(theta_* Z_g)<=exp(-Delta_g),
    limiting bracket <=exp[log(xi_g/xi_t)-Delta_g]. (TK13)

This is a quantitative physical entropy-versus-clock decision, with all its quantities specified by a one-dimensional kernel. It explains why negative theta can be the appropriate cap exponent in a hard-dominated parameter regime, while positive theta can be appropriate in a different regime. A gain is obtained only when the actual clock loss is smaller than Delta_g. The parameters in TK13 are not free source-density assumptions.

If m_g=0, Jensen gives `E exp(theta Z_g)>=1` throughout its finite range. This only states that this exponential-moment upper bound loses a possible critical-layer prefactor. It does not assert that the actual truncated kernel lacks decay. The finite-displacement anti-concentration estimate below treats precisely information discarded by such a moment bound.

TK10--13 are fixed-parameter, fixed-n far-displacement statements. No uniform relation between the displacement threshold and n is asserted. They cannot be inserted into the full selector integral TK7 without uniform control on the actual parameter region, and the saturated formula cannot be used where a coordinate weight remains clipped at one.

## TK6. Finite displacement supplies information beyond the moment bound

The independently screened finite geometry in `finite_displacement_geometry.md` gives a useful complementary bound. For m coordinates with `|d_i|>=3/4`, the original current receiver probability has two intervals of mass at least 1/128 whose scalar log-likelihood values are separated by at least 1/8, uniformly in `s in [0,1]` and `lambda in [1/2,1]`. An elementary Bernoulli-pair/antichain argument gives, for the sum of the log likelihoods and `h0=1/16`,

    sup_a Prob(sum_i log(p_i(X_i)/j_i(X_i)) in [a,a+h0])
       <= min(1,sqrt(128/(m+1))).                  (TK14)

This is independence under the fixed product receiver density, not an independence assumption on sources. The remaining coordinates may have arbitrary displacements. Partitioning the region below the cap into intervals of length h0 gives

    I <= [B0/(1-exp(-h0))] (w_t/w_g)
                         min(1,sqrt(128/(m+1))).   (TK15)

The target-current cut in TK2 can only decrease this upper bound; it is not credited with an additional unproved suppression. This supplies a finite-displacement prefactor even in a moment-critical regime. It retains the physical clock factor w_t/w_g and is still a fixed-selector kernel estimate. When the original g varies with receiver x, the parent manuscript instead uses the fixed-source lower bound `w_g>=C_*` in the cap; the corresponding factor is `w_t/C_*`, not a receiver-dependent w_g pulled through the integral. The parent manuscript contains the proof and the exact scope of these statements, so it is not repeated here.

The approved scalar numerical diagnostics in `numerical_review.md` examine 21 fixed lambda=1 cases at two precisions with explicit truncation-tail bounds. In the three d=2, theta=-1/4, beta=0 cases, the bare moments are below one but the correct values C(2)^theta M are above one. Several positive-theta normalized moments are below one. These are finite physical scalar observations, not optimal parameters, far-displacement limits, directed interval certificates or a FULL source/history realization. They support retaining C and the clock factors explicitly; they do not pay a source column.

## TK7. Actual source and time ledger: the still missing step

For fixed `(omega,V,j,y,t)`, the original e_t and posterior carrier Z_t are independent of x. Before any enlargement, the companion has the corresponding source factor

    beta_V(dy) 1_{Z_t}(v) nu_V(dv)/e_t(y),

multiplied by the kernel containing w_t and by the remaining bad-source probability and original masks. Thus a bound `I<=C` is **not** a C W_beta price: `nu_V/e_t` is not a probability. Its probability normalization is `w_t nu_V/e_t`. In particular TK15, after dividing by the weight already present in that probability, still costs `1/(w_g sqrt(m))` up to its displayed constant.

If a uniform genuinely adaptive kernel bound of the stronger form `I<=C w_t` were proved on a retained region, positive integration against the unchanged fixed posterior would cost at most

    C Tstar W_beta,
    Tstar=sup_windows sum_j log_+(b c_j^2/a)
         <=log 2+(n+1)(log 2)^2/4.                 (TK16)

This is an implication with its full fee, not an assumption asserted here. A root-polylog conclusion from the repaired J-energy needs the resulting companion fee to be polylogarithmic, so even the full Tstar must be counted. Extra original windows keep their original ledger. Unique j does not delete this sum after the frozen receiver-dependent indicators have been enlarged.

Alternatively the exact R196 TD10 high-column identity keeps the original current input subprobability, h_t, alive indicator and bad-source mask inside the receiver integral. That route may exploit more common-input geometry, but it cannot be combined with a fixed-source moment by silently freezing that receiver-dependent current subprobability.

The proved advances here are the full two-cut negative-power range, its explicit all-selector positive enlargement, the correct physical tail constants and the entropy-clock decision. Together with the finite-displacement prefactor, they specify which scalar mechanisms are available and what fees survive. The missing general step remains the actual source-weighted and time-weighted column integration; no general root closure or free replacement of the original alpha, masks or posterior has been claimed.
