# R197 独立审计

仅维护本文件，非独占仓库；无 Git/spawn/他人编辑。先读 task_contract.md，窄读 R196 冻结 TD11–12 与 CG11–12；以下独推在本轮作者证明之前。一般原中间层目标未闭合。

## 1. 实际两个 likelihood 门的方向

在原 good、high A≥1−η 的有效 target，令 U=p_y/J_v、V=p_v/J_v、qη=η/[a_n(1−η)]。原份额给 V≤qη；good 与 S/J=ρ/A 给 U≤Kρ/[3(1−η)w_g(y,v)]。均为正确上门。ρ≤1 可正放宽第一个门，不可把原同 α 的 ρ另行优化；reciprocal y/u 的 w_g 不能替成 y/v 的 target overlap。

原 w_t(y,v) 在固定 (ω,V,j,y,t,v) 先于 receiver；w_g、ρ、s,L 和门通常依 x。若要 source-fixed cap，可进一步用原 ξ_g≤1 下 w_g≥Cprod=∏C(|y_i−v_i|/b)，得到 B=K/[3(1−η)Cprod]。这是真正的放宽，但 tiny Cprod 的费用必须完整保留。不能在 x 积分外抽出尚未固定的 actual w_g/ρ。

## 2. 固定参数张量 Chernoff 的准确形式

先固定原 source y,v、固定共同 s>0 与 λ=L/b∈[1/2,1]。在 r=(x−v)/b、d_i=(y_i−v_i)/b 中，Jdx 是 ∏φ(r_i)dr_i，U=∏f_{s,λ}(r_i−d_i)/φ(r_i)，V=∏f_{s,λ}(r_i)/φ(r_i)。对任何 0≤a≤2、β≥0，

∫J U²1_{U≤B}1_{V≤qη}dx
≤B^(2−a) qη^β ∏_i∫ φ(r)^(1−a+β) f_{s,λ}(r−d_i)^a f_{s,λ}(r)^(−β)dr。

证明逐点为 U²≤B^(2−a)U^a，且1_{V≤qη}≤(qη/V)^β。这里a、β仅为测试指数，不是 window/capture参数。β=0、a=1恢复cap·current的一般界；没有凭空得到小量。固定source后的receiver核可张量，但β/ν来源坐标、cut和history没有独立化。

矩的有限性本身须核验。原 strict s>0 时，沿已证的exp/r核尾，对 λ<1 一维无穷端要求 1+(a−β)(1/λ−1)>0；等号时 integrand∼const/|r|仍发散，负时指数发散。λ=1无此tail障碍，但hard/source位移费用仍存在。s=0的V可为0，负幂表达不能免费沿用；s↓0的uniform费用也必须另证。不能用一个发散或极大的矩声称 Chernoff小概率。

小V事件在J测度下不由概率归一自动小；E_JV=1只给另一方向的Markov上尾。若另有实际U≤R V关系，才可把两个门合成U≤min(B,Rqη)，在fixed参数下得到相应简单界；父任务没有免费给这个y/v关系。

## 3. 原自适应及source回代的必要费用

likelihood门随s,L改变，带负幂的moment核不自动继承原P或sqrt(PP)的scale/soft单调性。fixed参数的product矩不能直接授给 actual s(x),L(x)；必须给对同一截断核的pointwise正支配/完整参数包络，或保原selected gate的真实receiver积分。仅将U²1U≤B≤B U并放掉V门时可沿已有current包络收费，但这留下B/Cprod，未支付目标几何。

真正待付的是原TD10列中 b_H、1_Z、h_t、actual w_t与该截断receiver核的联合平均。P_beta=p_yβ/q依receiver，不能冻结为source参考；同V sources仅共父，没有ν≤β、每leaf帽或自由三来源product。原Γ+只在其既定fixed-time正流定义下使用，完整j/time质量、window重用及原Lebesgue dx必须保。不能把y/u已付近距离替换为y/v近。

R196 capture路线仍保同M=μ−χ与joint target抑制、完整1/M_i标签、lowk/w和tail；任何source occupation majorant须在同一真实来源/capture下认证，不能为了Chernoff矩另采样来源或复制reserve。

## 4. 阶段结论

两个实际门、固定参数tensor-Chernoff形式通过独筛；尚无uniform selector-moment/source价格认证。等待作者准确候选及完整证明，不把标量截断或条件门改名登记为一般闭合，不扩展无关反例搜索。


## 5. 准确候选的独筛及作者后读

本节区别于§§1–4的作者前检查。收到准确候选后，先独推下列结论，再全文读三份责任稿。

- 两门矩取 a=1+theta，允许 -1<theta<=1、0<=beta<=1+theta。固定严格正s下尾指数率为 (1+theta-beta)/lambda+beta-theta>=1；负theta合法。beta=0可含purehard，但beta>0的零尾不能沿用。C-normalized远移极限另需theta>-1/(1+lambda)，不把固定d的有限性误当远移一致控制。
- 对beta=0，Cprod给真正来源固定cap。soft窗口确实支付exp(1+theta)(n+1)，正Stieltjes尺度包络支付端点及n(1+theta)倍尺度积分，闭硬面跳保留。beta>0不能由同一单调性免费处理；右侧可能无穷，未被称为预算。
- w、phi、C尾常数分别为1、H1、H1²，H1=2sinh(1/2)。domination保两侧exp/r比值，远移固定n；熵测试保B0^(1-theta)、xi_g/xi_t和有限V_g。Taylor改进仅在真实clock损失小于所得亏损时有效，临界Jensen不等于实际截断核无衰减。

全文核验 truncated_kernel_geometry.md 的TK1–16通过。尤其TK16明确nu/e_t不是概率：I<=C本身不给CW_beta；只有合格的全selector I<=C wt才经原posterior给CTstar W_beta，仍保窗口重用。实际x-dependent current外列没有被冒充固定来源参考。

## 6. 有限位移反集中：自含证明通过

全文核验 finite_displacement_geometry.md 及其LaTeX整合。对|d|>=3/4，两个真实current中央区间各质量>=1/128；分母phi在同侧outsidecore有log斜率>=1，故likelihood间隔>=1/8。purehard先去p零集，端点可保。

Bernoulli提取概率1/64，条件反链/Sperner及中央二项式递推均正确；长度1/16窗口浓度

Q<=r_m=E a_Bin(m,1/64)<=min(1,sqrt(128/(m+1)))。

独立性只来自固定产品receiver密度。几何分箱保所有原子，给真实Lebesgue积分 integral p²/j 1{p/j<=B}<=B r_m/(1-exp(-1/16))。其fixed参数全软度资格正确；actual g依receiver时须以Cprod固定下界替cap，不能提出更小的actual wt/wg。m=0与附加独立坐标均覆盖。此结论尚未支付selector及原source列。

曾直接核对 Juškevičius arXiv:2201.09861 Theorem 1.1 的共同窗口形式；最终证明采用上述自含反链论证，不以该外部定理或未知常数为依赖。[原文](https://arxiv.org/pdf/2201.09861)

## 7. 实际high逆核工具及整合范围

occupation_kernel_geometry.md全文通过。原high与e_g<=nu(V)给rounded-cube包含；体积b^n sum_j binom(n,j)(2R)^j/j!准确。原所有s>=s0、a<=L,Hhat<=b的点态统一有限界没有隐去selector费，但完整保s0^-n、体积、距离与level指数，不是root来源费。D依receiver时不能提出1/D；最终稿两处已准确限定固定D，通常用D>=1正放。

同尺度裸p_y²/(J_v K0_z)有正尾，严格只否定先删high的全空间enlargement；未冻结实际alpha、未构造FIRST/core反例。实际CC22的target系数、Mi^-1、source-cell及occupation仍未付。

proof.tex.txt全文与三份数学稿一致；report.md准确区分主反集中因子、负幂矩/熵构件、昂贵high工具与未闭合一般目标。未认证all-mother或一般n^(1/2+o(1))弱型界。没有新的无费来源排序、source独立性、window合并或selector交换。

## 8. 数值和复现静态核验

逐行静核两脚本，不另运行。

kernel_moment_checks.py：21项、阶段5/8/8，固定lambda=1、s>0；tail方向、hard seams、正负指数和正确C的E4式均核对。25/40位截断尾界控制数学遗漏，不认证有限quad及浮点舍入；C^theta M不替代wt/wg、clock和两门。JSON及notes的非interval、非FULL证据标签准确。

anticoncentration_checks.py：9个m的Fraction二项式权重、inverse-binomial恒等式、a_k²<=2/(k+1)、Cauchy常数与区间有理常数均正确。小数仅显示；这些有限检查不替代连续几何证明。

父报告已分别实际重跑并逐字节匹配两JSON；本审计没有重复运行。reproduce.py静态通过：验证manifest后在新output目录运行两脚本，非零退出传递并完整比较JSON字节；依赖mpmath和原contract哈希仍需满足。最终总driver在manifest/归档生成后运行，当前未提前记为已通过；其实际结果由父另记README。

## 9. 最终冻结

上述独立命题筛查、三作者/主证明全文、最终tex/report、两脚本及reproducer范围核验通过，无必须修项。通过范围是明确的核几何与完整费用接口；实际原source/time加权列的一般支付仍开。以下绑定当前12个其他work文件；不哈希本文件自身或尚未生成manifest。到此冻结停止。

| 文件 | SHA256 |
|---|---|
| anticoncentration_checks.json | `61817996e44aa858c3f96746e99ab1905171d0b021ee7f9edf491f178acce21d` |
| anticoncentration_checks.py | `c987863b1b077c7adab9cf0f87c8dfe9fb7b03cc1a6d8d654e84f2102fe2f624` |
| finite_displacement_geometry.md | `5cc649c842b7796ffb6aa3505be8b2f424f0ec591594ac792f02121ed951d1cb` |
| kernel_moment_checks.json | `2ca22c9f466168cbdf4693beba57bf5e51bbb98b70c26639bf0499c76a7f7740` |
| kernel_moment_checks.py | `3f924b1de146ed6f53b96ee0840aebb81d027dbfa988178bd58a22b8e3da895f` |
| numerical_review.md | `fe081d7adfb062f8390ded90b8fefda3f8aacc5b2d88c5653471e7d809bbf299` |
| occupation_kernel_geometry.md | `205e1b62f8ea5db1e81bf143e1ac4daa6f3ec57c45779d8cbe083d0b9b66fa92` |
| proof.tex.txt | `d06cb94a24b848dde9b72f5b36b211b6c1931126f3b491d80a03b651b2add12b` |
| report.md | `7bbc3a59cb588e9eee384ad4ee8d9a0489bd19feeeb88d3aeac546e21e4dd0bb` |
| reproduce.py | `f723db24ddd7c723fea386606e74d426328158dff5bf452d9948cd34ea29c714` |
| task_contract.md | `a0c4b64b0db6fa4ec59c0f5260463589a841904c22f119f4f95ecd910674459c` |
| truncated_kernel_geometry.md | `46a117bac98eaf0625fb96ca9c8460e04e4f805fac8ff3c69b326fc06c4c865b` |
