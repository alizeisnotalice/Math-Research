"""R98 neutral actual partial capture and common physical-source certificates.
No Fnew/PDE/energy-grid proxy. Every source/receiver is genuine continuum.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations,product
from math import prod
from pathlib import Path
import json,time,zlib,base64,hashlib

TH=F(1,6);D=1<<128;OUT=1<<64

def fl(q):return q.numerator//q.denominator
def ce(q):return -fl(-q)
def down(q):return F(fl(q*OUT),OUT)
def up(q):return F(ce(q*OUT),OUT)
def iv(l,u):
    assert 0<=l<=u
    return {'lower':str(l),'upper':str(u),'display_only':[float(l),float(u)]}
def unitlog(q):
    assert 1<=q<=2
    t=(q-1)/(q+1);l=fl(t*D);u=ce(t*D);vl=l*l//D;vu=(u*u+D-1)//D;pl=l;pu=u;sl=su=0
    for j in range(60):
        sl+=2*pl//(2*j+1);su+=(2*pu+2*j)//(2*j+1)
        pl=pl*vl//D;pu=(pu*vu+D-1)//D
    tail=ce(D*F(2,121)*F(1,3)**121/F(8,9))
    return F(sl,D),F(su+tail,D)
LOG2=unitlog(F(2))
@lru_cache(None)
def logs(q):
    assert q>0
    k=q.numerator.bit_length()-q.denominator.bit_length();z=q/F(2)**k
    if z<1:k-=1;z*=2
    if z>=2:k+=1;z/=2
    l,u=unitlog(z)
    if k>=0:return l+k*LOG2[0],u+k*LOG2[1]
    return l+k*LOG2[1],u+k*LOG2[0]
def logplus(q):
    if q<=1:return F(0),F(0)
    l,u=logs(q);return max(F(0),l),max(F(0),u)
def vol(b):return prod((u-l for l,u in b),start=F(1))
def intersection(a,b):
    x=tuple((max(l,s),min(u,t)) for (l,u),(s,t) in zip(a,b))
    return None if any(l>=u for l,u in x) else x

def box(n,e,center=F(0)):return ((center-e,center+e),)+tuple((-e,e) for _ in range(n-1))
def Q(n,center=F(0)):return box(n,F(1,2),center)
def P(n,center=F(0)):return ((center-F(1,4),center+F(1,2)),)+tuple((F(-1,2),F(1,2)) for _ in range(n-1))
def Ctarget(n,center=F(0)):return ((center-F(1,2),center-F(1,4)),)+tuple((F(-1,2),F(1,2)) for _ in range(n-1))
def payload(b):
    runs=[]
    for j,interval in enumerate(b):
        pair=[str(v) for v in interval]
        if runs and runs[-1]['bounds']==pair:runs[-1]['end_coordinate_exclusive']=j+1
        else:runs.append({'first_coordinate':j,'end_coordinate_exclusive':j+1,'bounds':pair})
    assert sum(x['end_coordinate_exclusive']-x['first_coordinate'] for x in runs)==len(b)
    return {'dimension':len(b),'coordinate_runs':runs,'actual_volume':str(vol(b))}
def piece(b,m,name):return {'box':b,'mass':m,'name':name}
def pieces_payload(ps):return [{'name':p['name'],'mass':str(p['mass']),'source_box':payload(p['box']),'actual_density':str(p['mass']/vol(p['box']))} for p in ps]
def codec(rows):
    b=json.dumps(rows,separators=(',',':')).encode()
    return {'codec':'base85 zlib compact JSON','payload':base64.b85encode(zlib.compress(b,9)).decode(),'sha256':hashlib.sha256(b).hexdigest(),'record_count':len(rows)}

def complement(big,small):
    assert intersection(big,small)==small
    out=[]
    for j in range(len(big)):
        for interval in ((big[j][0],small[j][0]),(small[j][1],big[j][1])):
            if interval[0]==interval[1]:continue
            b=tuple(small[k] if k<j else interval if k==j else big[k] for k in range(len(big)))
            out.append(b)
    assert all(intersection(b,small) is None for b in out)
    assert all(intersection(a,b) is None for a,b in combinations(out,2))
    assert sum((vol(b) for b in out),F(0))==vol(big)-vol(small)
    return out

def clearance(p,cap):
    assert intersection(p['box'],cap)==p['box']
    return 2*min(min(l-s,t-u) for (l,u),(s,t) in zip(p['box'],cap))

def subset_r(ps,aa,mask):
    inds=[j for j in range(len(ps)) if mask>>j&1]
    span=max(max(ps[j]['box'][k][0] for j in inds)-min(ps[j]['box'][k][1] for j in inds) for k in range(len(ps[0]['box'])))
    return max(max(aa[j] for j in inds),span,F(0))

def whole_piece(ps,caps,n):
    aa=[max(clearance(p,c) for c in caps if intersection(p['box'],c)==p['box']) for p in ps]
    groups=[[j for j,p in enumerate(ps) if intersection(p['box'],c)==p['box']] for c in caps]
    assert sorted(j for inds in groups for j in inds)==list(range(len(ps)))
    xx=[F(0)]*len(ps);dual_groups=[];upper_total=F(0)
    for inds in groups:
        order=sorted(inds,key=lambda j:aa[j]);ret=F(0)
        for j in order:
            xx[j]=min(ps[j]['mass'],max(F(0),TH*aa[j]**n-ret));ret+=xx[j]
        mass=sum((ps[j]['mass'] for j in inds),F(0));choices=[(mass,[])]
        for k,j in enumerate(order):
            choices.append((TH*aa[j]**n+sum((ps[t]['mass'] for t in order[k+1:]),F(0)),order[:k+1]))
        upper,prefix=min(choices,key=lambda v:v[0]);assert upper==ret
        upper_total+=upper
        dual_groups.append({'clearance_prefix_source_indices':prefix,'remaining_mass_cap_indices':[j for j in inds if j not in prefix],'dual_upper':str(upper)})
    rows=[]
    for mask in range(1,1<<len(ps)):
        cap=TH*subset_r(ps,aa,mask)**n;used=sum((x for j,x in enumerate(xx) if mask>>j&1),F(0));assert used<=cap
        rows.append([mask,str(cap),str(used)])
    R=sum(xx,F(0));mass=sum((p['mass'] for p in ps),F(0));assert R==upper_total
    return {'retained_optimum':str(R),'residual_mass':str(mass-R),'fixed_source_fractions':[str(x/p['mass']) for x,p in zip(xx,ps)],'retained_masses':[str(x) for x in xx],'doubled_clearances':[str(a) for a in aa],'all_nonempty_source_cuts':len(rows),'all_cut_witness':codec(rows),'matching_exact_dual':{'type':'sum actual within-block prefix cuts and remaining source mass bounds; each source once','groups':dual_groups,'upper':str(upper_total)}}

def face_profile(n,m_bg,peaks):
    r=(1+F(1,n))/2
    assert all(0<e< F(1,2*n) and 2*e<=2*(r-e) for e,m in peaks)
    pts={F(1),2*(r-F(1,2)),2*(r+F(1,2))}
    for e,m in peaks:pts.update((2*(r-e),2*(r+e)))
    pts=sorted(pts);segments=[];maxvalue=F(0);maxwhere=None
    for lo,hi in list(zip(pts,pts[1:]))+[(pts[-1],None)]:
        L=lo+1 if hi is None else (lo+hi)/2
        if L<1:
            a=m_bg/2;b=m_bg*(F(1,2)-r);form='a+b/L'
            func=lambda x:a+b/x
            candidates=[lo,hi]
        else:
            a=b=F(0);form='(a*L+b)/L^n'
            if m_bg:
                if L<2*(r+F(1,2)):a+=m_bg/2;b+=m_bg*(F(1,2)-r)
                else:b+=m_bg
            for e,m in peaks:
                if L<=2*(r-e):continue
                if L<2*(r+e):a+=m/(4*e);b+=m*(e-r)/(2*e)
                else:b+=m
            func=lambda x:(a*x+b)/x**n
            candidates=[lo]+([] if hi is None else [hi])
            if a:
                critical=-n*b/((n-1)*a)
                if critical>lo and (hi is None or critical<hi):candidates.append(critical)
            if hi is None:assert a==0 and b==m_bg+sum(m for e,m in peaks)
        vals=[func(x) for x in candidates]
        for x,v in zip(candidates,vals):
            if v>maxvalue:maxvalue=v;maxwhere=x
        segments.append([str(lo),None if hi is None else str(hi),form,str(a),str(b),[[str(x),str(v)] for x,v in zip(candidates,vals)]])
    return {'actual_exterior_supremum':str(maxvalue),'boundary_limit_side':str(maxwhere),'full_scale_profile':segments,'maximum_reduction':'coordinatewise capture monotonicity gives face-center exterior supremum; source is centered and positive','stationary_points':'exact affine numerator derivative root; early a+b/L monotone; infinity tail decreases','all_original_scales_included':True}

def pair_score(S,T,cap,n):
    far=max(max(abs(l-z),abs(u-z)) for (l,u),(s,t) in zip(S,cap) for z in ((s+t)/2,))
    near=max(max(F(0),l-(s+t)/2,(s+t)/2-u) for (l,u),(s,t) in zip(S,cap))
    r=(cap[0][1]-cap[0][0])/2
    hlo=r-far;hhi=r-near;assert 0<hlo<=hhi
    dlo=max(max(F(0),l-t,s-u) for (l,u),(s,t) in zip(S,T))
    dhi=max(max(abs(l-t),abs(u-s)) for (l,u),(s,t) in zip(S,T))
    result=[]
    for c in (4,8):
        lower=logplus(c*n*dlo/hhi)[0] if dlo else F(0)
        upper=logplus(c*n*dhi/hlo)[1] if dhi else F(0)
        result.append((lower,upper))
    return result,[hlo,hhi,dlo,dhi]

def split_axis(ps,mesh=16):
    out=[]
    for p in ps:
        b=p['box'];l,u=b[0];edges={l,u}
        if u-l<F(1,mesh):edges.add((l+u)/2)
        else:edges.update(F(i,mesh) for i in range(ce(l*mesh),fl(u*mesh)+1) if l<F(i,mesh)<u)
        ed=sorted(edges)
        for a,z in zip(ed,ed[1:]):
            part=((a,z),)+b[1:];out.append(piece(part,p['mass']*vol(part)/vol(b),p['name']))
    assert sum((p['mass'] for p in out),F(0))==sum((p['mass'] for p in ps),F(0))
    return out

def depth_proxies(blocks,n):
    totals=[[F(0),F(0)] for _ in range(2)];rows=[];matrices=[];pi_total=F(0);diagonal=F(0)
    for block in blocks:
        bp=block['b'];cp=block['c'];B=sum((p['mass'] for p in bp),F(0));assert B==sum((p['mass'] for p in cp),F(0))
        mat=[[s['mass']*t['mass']/B for t in cp] for s in bp]
        assert all(sum(row,F(0))==s['mass'] for row,s in zip(mat,bp))
        assert all(sum((row[j] for row in mat),F(0))==t['mass'] for j,t in enumerate(cp))
        matrices.append([[str(v) for v in row] for row in mat]);pi_total+=B
        diagonal+=sum((p['mass'] for p in block['diagonal']),F(0))
        # Small genuine 2n-dimensional rectangles, transverse coordinates
        # remain entire physical intervals, with exact full mass ratios.
        source=split_axis(bp);target=split_axis(cp)
        for s in source:
            for t in target:
                w=s['mass']*t['mass']/B
                scores,geo=pair_score(s['box'],t['box'],block['cap'],n)
                for j,(l,u) in enumerate(scores):totals[j][0]+=w*l;totals[j][1]+=w*u
                rows.append([block['id'],payload(s['box']),payload(t['box']),str(w),[str(x) for x in geo],[[str(l),str(u)] for l,u in scores]])
    W=sum(block['W'] for block in blocks);assert pi_total+diagonal==W
    return {'quantity':'P0=integral_pi log_+(4n*d_infty/depth_Omega(y)), P1 similarly8n; depth-log proxies, NOT exact screened exterior occupation M0/M1','proxy_intervals':[iv(down(l),up(u)) for l,u in totals],'genuine_coupling_total_mass':str(W),'diagonal_identity_mass':str(diagonal),'nonidentity_product_mass':str(pi_total),'source_target_component_marginal_matrices':matrices,'full_2n_dimensional_joint_rectangles':len(rows),'geometric_log_enclosure_witness':codec(rows),'actual_screened_exterior_M0_M1_computed':False,'diagonal_log_score_zero':True,'same_global_cap':True}

def traffic(n,block,e):
    r=(1+F(1,n))/2;h=F(1,64*n);center=block['center'];L=2*(r+e+2*h)
    # Face coordinate 1 (zero-based index1), leaving source slab coordinate0
    # saturated. This is a genuine n-dimensional receiver rectangle.
    E=((center-h,center+h),(r,r+h))+tuple((-h,h) for _ in range(n-2))
    V=vol(E);assert V==h*(2*h)**(n-1);A=L/2-r+F(1,2)
    if block['kind']=='central':
        ptotal=F(1,4);rho=F(1,4);Cmass=ptotal+rho*(2*e)**n
        bC=sum((p['mass'] for p in block['b']),F(0));btotal=bC
        original=V*(ptotal+rho*(A-h/2))/L**n
        bflow=V*bC/L**n
    else:
        g=block['gamma'];ptotal=g/32;rho=g*F(15,32)
        Cmass=g*(F(1,32)+F(13,24)*(2*e)**n)
        bC=g*(F(1,32)+F(1,24)*(2*e)**n)
        btotal=g*(F(1,32)+F(1,32)*(A-h/2))
        original=V*(ptotal+rho*(A-h/2))/L**n;bflow=V*btotal/L**n
    centralflow=Cmass*V/L**n
    qtop=ptotal+rho*A;qbottom=ptotal+rho*(A-h)
    ll,uu=logs(qtop/qbottom);pl=Cmass*ll/(rho*h);pu=Cmass*uu/(rho*h)
    assert 0<pl<=pu<=1
    return {'receiver_box':payload(E),'receiver_boundary_null_face_excluded':True,'scale':str(L),'scale_is_fixed_not_original_selector':True,'actual_original_source_average_integral':str(original),'actual_positive_surplus_average_integral':str(bflow),'physical_central_source_region':payload(box(n,e,center)),'actual_original_central_source_mass':str(Cmass),'actual_surplus_central_source_mass':str(bC),'physical_central_original_traffic':str(centralflow),'central_source_column_constant':str(V/L**n),'mean_genuine_captured_posterior_central_share':iv(down(pl),up(pu)),'source_region_common_for_every_receiver':True}

def epsilon_ledger(n,W,Bold,inside_density,V,peak_mass,regions):
    # In every declared fixture f>1 throughout the peak support and f<=1/2
    # (central) or f<=13/24 (boundary) outside. Thus this is an exact tail.
    epsilon=F(1,n);v=1-epsilon
    assert inside_density<v and inside_density+peak_mass/V>1
    Bk=peak_mass-(1-inside_density)*V
    Bv=peak_mass-(v-inside_density)*V
    Dv=v-W+Bv
    assert 0<Bk<=Bv<=W and Dv>=Bv and Bv<=epsilon*W+(1-epsilon)*Bk
    a_mass=W-Bv;beta=Bv/Dv
    assert sum(vv for label,vv,rho in regions)==1
    assert sum(vv*rho for label,vv,rho in regions)==W
    assert sum(vv*max(F(0),rho-v) for label,vv,rho in regions)==Bv
    assert sum(vv*max(F(0),v-rho) for label,vv,rho in regions)==Dv
    assert sum(vv*max(F(0),rho-1) for label,vv,rho in regions)==Bk
    cells=[]
    for label,vv,rho in regions:
        aa=min(rho,v);ee=max(F(0),rho-v);tt=max(F(0),v-rho);target=aa+beta*tt
        assert rho==aa+ee and 0<=target<=v
        cells.append({'actual_region':label,'volume':str(vv),'original_density':str(rho),'identity_density_a':str(aa),'surplus_density_e':str(ee),'deficit_density_t':str(tt),'target_density':str(target)})
    assert a_mass+beta*Dv==W and 0<=beta<=1
    return {'epsilon':str(epsilon),'v_equals_1_minus_epsilon':str(v),'positive_tail_B_at_kappa_1':str(Bk),'positive_tail_B_epsilon':str(Bv),'B_at_fixed_sigma_half_distinct':str(Bold),'deficit_t_mass_D':str(Dv),'identity_a_mass':str(a_mass),'target_deficit_fraction_B_over_D':str(beta),'moving_target_total_mass':str(W),'moving_target_pointwise_upper':str(v),'pointwise_target_argument':'a=min(f,v), t=(v-f)+, 0<=B/D<=1, so a+(B/D)t<=a+t=v','true_epsilon_tail_upper_from_kappa_tail':str(epsilon*W+(1-epsilon)*Bk),'B_epsilon_over_epsilon_W':str(Bv/(epsilon*W)),'moving_coupling_identity_plus_e_tensor_t_over_D_mass':str(W),'moving_coupling_moments_or_absorption_not_computed':True,'actual_constant_density_region_mass_witness':cells,'moving_reference_near_cut_if_used':'epsilon*L/(8n); fixed-half-reference quantities are not transferred','moving_reference_depth_log_if_used':'must include 1/epsilon; this program computes no moving-reference moment'}

def central_case(n,es,ms,name,stage):
    r=(1+F(1,n))/2;cap=box(n,r);q=Q(n);largest=box(n,max(es));v=vol(largest)
    assert sum(ms)==F(1,4) and all(0<e<F(1,2*n) for e in es)
    order=sorted(zip(es,ms),reverse=True);es=tuple(e for e,m in order);ms=tuple(m for e,m in order)
    fparts=[piece(q,F(1,4),'background')]+[piece(box(n,e),m,'peak'+str(j)) for j,(e,m) in enumerate(zip(es,ms))]
    assert F(1,4)+ms[0]/v>1  # Every point in largest peak support is above kappa.
    bm=[ms[0]-F(1,4)*v]+list(ms[1:]);assert bm[0]>0
    bparts=[piece(box(n,e),m,'positive_surplus'+str(j)) for j,(e,m) in enumerate(zip(es,bm))]
    cparts=[piece(x,F(1,4)*vol(x),'deficit') for x in complement(q,largest)]
    diag=[piece(q,F(1,4),'identity_base'),piece(largest,F(1,4)*v,'identity_extra')]
    block={'id':0,'kind':'central','center':F(0),'W':F(1,2),'b':bparts,'c':cparts,'diagonal':diag,'cap':cap}
    regions=[('Q outside largest central cube',1-v,F(1,4))]
    cumulative=F(1,4)
    for j,(e,m) in enumerate(zip(es,ms)):
        cumulative+=m/(2*e)**n
        vv=(2*e)**n-(2*es[j+1])**n if j+1<len(es) else (2*e)**n
        regions.append(('central shell '+str(j),vv,cumulative))
    rawprofile=face_profile(n,F(1,4),tuple(zip(es,ms)));bprofile=face_profile(n,F(0),tuple(zip(es,bm)))
    norm=F(rawprofile['actual_exterior_supremum']);bnorm=F(bprofile['actual_exterior_supremum'])
    rawfraction=min(F(1),TH/norm);bfraction=min(F(1),TH/bnorm)
    B=sum(bm,F(0));assert B==sum(p['mass'] for p in cparts)
    return {'name':name,'stage':stage,'dimension':n,'actual_source_blocks':1,'W':'1/2','kappa':'1','theta':'1/6','actual_global_cap_volume':str(vol(cap)),'cap_volume_charged_once':True,'source':pieces_payload(fparts),'reference':pieces_payload([piece(q,F(1,2),'sigma')]),'positive_surplus':pieces_payload(bparts),'deficit':pieces_payload(cparts),'surplus_deficit_equal_mass':str(B),'identity_common_mass':str(F(1,2)-B),'moving_epsilon_reference_ledger':[epsilon_ledger(n,F(1,2),B,F(1,4),v,F(1,4),regions)],'original_bad_block_reference_average':'1/2','original_bad_grid_parent_average':'1/4','raw_whole_piece':whole_piece(fparts,[cap],n),'raw_actual_safe_retained_interval':iv(rawfraction/2,F(1,2)),'raw_actual_optimum_exact_if_full_safe':'1/2' if rawfraction==1 else None,'raw_actual_fixed_common_fraction':str(rawfraction),'raw_actual_face_profile':rawprofile,'after_precancel_whole_piece':whole_piece(bparts,[cap],n),'after_precancel_actual_safe_retained_interval':iv(bfraction*B,B),'after_precancel_actual_optimum_exact_if_full_safe':str(B) if bfraction==1 else None,'after_precancel_actual_face_profile':bprofile,'after_precancel_actual_fixed_common_fraction':str(bfraction),'actual_excess_outside_cap_zero_if_surplus_safe':bfraction==1,'coupling_depth_log_proxies':depth_proxies([block],n),'traffic_records':[traffic(n,block,es[0])],'original_Fnew_qualified':False,'no_general_small_residual_conclusion':True}

def boundary_case(n,gammas,name,stage):
    r=(1+F(1,n))/2;e=F(1,16*n);blocks=[];fparts=[];bparts=[];cparts=[];sigmas=[];caps=[]
    for j,g in enumerate(gammas):
        center=F(4*j);q=Q(n,center);p=P(n,center);c=Ctarget(n,center);peak=box(n,e,center);cap=box(n,r,center)
        assert vol(p)==F(3,4) and vol(c)==F(1,4) and intersection(p,c) is None
        assert intersection(peak,p)==peak
        fp=[piece(q,g/4,'background'+str(j)),piece(p,g*F(7,32),'wide'+str(j)),piece(peak,g/32,'peak'+str(j))]
        bp=[piece(p,g/32,'wide_surplus'+str(j)),piece(peak,g/32,'peak_surplus'+str(j))]
        cp=[piece(c,g/16,'deficit'+str(j))]
        dp=[piece(q,g/4,'identity_base'+str(j)),piece(p,g*F(3,16),'identity_extra'+str(j))]
        B=g/16;assert sum(p['mass'] for p in bp)==sum(p['mass'] for p in cp)==B
        assert sum(p['mass'] for p in dp)+B==g/2
        blocks.append({'id':j,'kind':'boundary','center':center,'gamma':g,'W':g/2,'b':bp,'c':cp,'diagonal':dp,'cap':cap})
        fparts+=fp;bparts+=bp;cparts+=cp;caps.append(cap);sigmas.append(piece(q,g/2,'sigma'+str(j)))
    assert all(intersection(a,b) is None for a,b in combinations(caps,2))
    W=sum(gammas,F(0))/2;B=sum(gammas,F(0))/16;a=2*(r-e)
    pk_one=max(gammas)/32/a**n
    pk_multiple=sum(gammas,F(0))/32/(4-2*e)**n if len(gammas)>1 else F(0)
    pk=max(pk_one,pk_multiple)
    b_upper=F(1,24)+pk;assert b_upper<TH
    alpha=min(F(1),max(F(0),(TH-pk)/F(13,24)))
    rawret=alpha*sum(gammas,F(0))*F(15,32)+sum(gammas,F(0))/32
    assert alpha*F(13,24)+pk<=TH
    tr=[traffic(n,b,e) for b in blocks]
    if len(gammas)>1:assert F(tr[0]['scale'])<2*(4-F(1,2)-F(1,64*n))
    return {'name':name,'stage':stage,'dimension':n,'actual_source_blocks':len(blocks),'W':str(W),'kappa':'1','theta':'1/6','block_centers':[str(4*j) for j in range(len(gammas))],'unequal_block_weights_gamma':[str(g) for g in gammas],'actual_global_cap_volume':str(sum(vol(c) for c in caps)),'individual_cap_volume_sum_equals_union':True,'caps':[payload(c) for c in caps],'source':pieces_payload(fparts),'reference':pieces_payload(sigmas),'positive_surplus':pieces_payload(bparts),'deficit':pieces_payload(cparts),'surplus_deficit_equal_mass':str(B),'identity_common_mass':str(W-B),'moving_epsilon_reference_ledger':[epsilon_ledger(n,g/2,g/16,g*F(13,24),(2*e)**n,g/32,[('Q outside wide P',F(1,4),g/4),('wide P outside central C',F(3,4)-(2*e)**n,g*F(13,24)),('central C',(2*e)**n,g*F(13,24)+g/32/(2*e)**n)]) for g in gammas],'original_bad_block_reference_averages':[str(g/2) for g in gammas],'original_bad_grid_qualification':'unit translated dyadic Qj, centers4j; every proper cyclic ancestor average<=1/4 by spacing4 and aspect<=2','raw_whole_piece':whole_piece(fparts,caps,n),'raw_actual_safe_retained_interval':iv(rawret,W),'raw_actual_fixed_fractions_background_and_wide':str(alpha),'raw_actual_fixed_fraction_peak':'1','raw_actual_uniform_average_upper':str(alpha*F(13,24)+pk),'raw_actual_optimum_not_claimed':True,'after_precancel_whole_piece':whole_piece(bparts,caps,n),'after_precancel_actual_optimum':str(B),'after_precancel_actual_retained_fraction':'1','global_peak_one_capture_upper':str(pk_one),'global_peak_multiple_capture_upper':str(pk_multiple),'global_peak_average_upper':str(pk),'multiple_peak_minimum_side':str(4-2*e) if len(gammas)>1 else None,'wide_surplus_global_density_upper':'1/24','after_precancel_actual_global_average_upper':str(b_upper),'all_exterior_receivers_all_scales_certificate':True,'actual_excess_outside_cap_zero':True,'coupling_depth_log_proxies':depth_proxies(blocks,n),'traffic_records':tr,'no_foreign_block_capture_on_measured_receiver_patches':True,'original_Fnew_qualified':False,'no_general_small_residual_conclusion':True}

def build():
    cases=[central_case(2,(F(1,32),),(F(1,4),),'central_calibration','pilot'),central_case(2,(F(1,2048),),(F(1,4),),'deep_central','stress'),central_case(4,(F(1,32),F(1,128),F(1,512)),(F(1,8),F(1,16),F(1,16)),'three_overlapping_scales','stress'),boundary_case(4,(F(1),),'boundary_after_precancel','stress')]
    cases.append(boundary_case(8,(F(1),),'boundary_after_precancel','expanded'))
    for n in (16,64):cases.append(boundary_case(n,(F(3,4),F(1),F(7,8)),'unequal_three_cluster_boundary','expanded'))
    for c in cases:
        ledgers=c['moving_epsilon_reference_ledger'];c['moving_epsilon_global_positive_tail_B']=str(sum((F(x['positive_tail_B_epsilon']) for x in ledgers),F(0)));c['moving_epsilon_global_kappa_tail_B0']=str(sum((F(x['positive_tail_B_at_kappa_1']) for x in ledgers),F(0)));c['moving_epsilon_global_B_over_epsilon_W']=str(F(c['moving_epsilon_global_positive_tail_B'])*c['dimension']/F(c['W']))
    return {'round':98,'public_neutral_only':True,'input_menu_fixed_before_execution':True,'actual_source_dimension_instances':len(cases),'source_absorption_scope':'one source restriction for all exterior receivers/scales; wholepiece sufficient relaxation vs actual partial capture; no Hall-demand/Fnew/PDE claim','depth_log_scope':'P0/P1 are actual integrals of a geometric log proxy under actual coupling, bounded on continuous 2n-dimensional rectangles; true screened/exterior M0/M1 NOT COMPUTED','arithmetic':'Fraction exact polynomial critical points;128-bit directed atanh60terms;64-bit final outward interval endpoints','cases':cases,'counts':{'pilot':1,'stress':3,'expanded':3,'actual_source_blocks':sum(c['actual_source_blocks'] for c in cases),'source_subset_constraints_checked_raw_and_surplus':sum(c['raw_whole_piece']['all_nonempty_source_cuts']+c['after_precancel_whole_piece']['all_nonempty_source_cuts'] for c in cases),'full_joint_source_target_rectangles':sum(c['coupling_depth_log_proxies']['full_2n_dimensional_joint_rectangles'] for c in cases),'true_receiver_boxes':sum(len(c['traffic_records']) for c in cases)},'general_target':'UNRESOLVED'}
if __name__=='__main__':
    t=time.perf_counter();result=build();p=Path(__file__).with_name('numeric_results.json');p.write_text(json.dumps(result,sort_keys=True,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'elapsed_seconds':time.perf_counter()-t,'bytes':p.stat().st_size,'cases':len(result['cases'])}))
