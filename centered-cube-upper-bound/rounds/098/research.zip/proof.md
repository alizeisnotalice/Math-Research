# 中心立方体第98轮：阈值保留的共同运输与真实非线性演化接口

2026-10-12。任意非负 L1 输入、真实勒贝格接收测度及全部尺度上的 C_n≤sqrt(n)n^{o(1)} 仍未证明。保留一般 O(n log n) 基准。各模块的条件性结论、一般工具与有限检验分别记录，未付预算不计零。

本轮在共同来源路线中保留来源与参考的重合质量，按实际位移和真实帽外捕获计费，区分来源局部筛选与接收点真实超阈值事件。参考密度的高度、一个共同帽的体积、全部尺度持续费用均进入主账。软层路线检查固定捕获质量所产生的接收点变换，明确加权需求的雅可比方向与截断噪声的概率费用。

替代路线研究实际晶体能量梯度流，逐项核验解类、通量、质量与多来源比较；单剖面卷积不等于一般输入的演化。非线性最大函数和轨道平均分开处理，保留时间窗口及近似费用。数值端进一步核验原固定输入的联合门事件，并以公开的中性来源模型检查真实部分捕获。

原有八个角色保留上下文；针对实际非线性最大估计这一独立瓶颈，增设一名 Astra xhigh。两名独立审计先检查命题与潜在反例，再阅读完整证明及程序。主代理另行审核、隔离复现并负责本轮唯一提交。私人配方、程序和未公开的定量方法下界仅留本地；公开包只纳入明确 PUBLIC 内容和必要复现材料。详细 LaTeX 文本只做静态核验，不编译 PDF。


## 原目标、同输入分支与维度账

统一 Q(x,L)=x+[-L/2,L/2]^n、A_L=L^-n integral_Q、mu=f dy、W=||f||1。原局部事件保留 L*∈[1,2]、单位锚点、后来严格硬见证、最早硬接触 A_L*f=lambda、整个窗口 P1<lambda/2、原中间下限以及包和物理删除。theta=log^-2(n+2)，alpha=[10log(n+2)]^-1；原粗门仅在原 L* 成立。帽能量阈值 kappa、分层强度和来源残留质量使用不同符号，不互相代换。

原账：H_n=1+n log2，Cext=2H_n/sqrt(n+2)，Bbase=4+2log2 sqrt(7n/3)，Tsoft=1+log2 min{2n,sqrt[n(theta^-1+4theta/3)]}。固定 p0>0，a0=n^-p0、rho0=n^-1/2、Pdom=[5+3log(1/a0)]/rho0。h*=(16n^(3/2))^-1，E*=exp(nh*)，B*=1+E*[1+(2n²+n)h*]，Pphys=2[E*+B*+2(1+E*)sqrt n]，物理并集只付一次。Aold=Bbase+Cext+Tsoft/alpha+Pdom+Pphys。

设 b_n=exp(-s_n)/2 为原极低截点。新分支 Ecap={捕获的 P1≤b_n lambda} 另付 Cext；其与已付的全来源 P1 极低分支不同。于是局部总账为 (Aold+Cext)W+lambda|Frem|。Frem 上实际已捕获后验满足 E F>b_n 与 E G<alpha。原门未重选、来源未替换。全尺度回代仍保留 C_loc log(n+2)，若另按原强度作二进分层，另付 J_n=O(log n) 及实际重叠。第88轮方差常数和第94轮薄环累计费用仍未证明。

|接口|本轮可用结论|仍需支付的一般费用|
|---|---|---|
|同一质量与参考|参考上界 (1−ε)κ，逐块保留 min(f,(1−ε)κ) 并重新安置全部超出质量；Bε≤εW+(1−ε)B0，B0=integral(f−κ)+|B0/W 对一般输入可以很大；原参考下的必要筛选仍可能计入没有真实超额的接收点|
|真实外部占用|两个一阶占用量 M0、M1 包括同一帽外全部接收点和全部尺度；能量系数为 c_n M0 M1/W²|没有任意输入上的子幂乘积界；深度对数仅为上界代理|
|可调参考的完整费用|ε=1/n 时，B_energy≤c_n[1/n+(1−1/n)B0/W]² log(16n³)log(32n³)，帽系数≤4e+1；无额外1/ε因子|尚无统一控制高密度尾的几何预算|
|实际接收门|以 beta=1+1/n 保留实际超阈值与松弛门，持续费用 c_(n,beta)=n/(1−beta^(−n))|联合占用乘积尚未控制，不能把原问题改写当作解决|
|接收需求变换|固定质量半径 r_m 是2-Lipschitz；推送 m r_m^(−n)dx 的密度为 [r_m(Tx)/r_m(x)]^n/J|小空间雅可比不能消去归一化幂；小位移限制的概率、原捕获图和质量标签转换均未付|
|实际晶体演化|明确凸能量与实际轨道，逐项验证通量和质量接口；保序与固定时刻收缩有其准确适用类|一般立方体到真实演化的多来源比较、真实最大函数弱端点均未证明|
|非线性轨道 L2 时间变化|2次齐次凸梯度流有 integral t norm(u_t)²≤norm(f)²/4，轨道与时间平均的上确界差 L2≤norm(f)/(2sqrt2)|一般 L1 输入的振幅费用及非线性两轨道差的控制未付|
|非线性时间平均|守恒时单向系数一的叠加比较强迫等号；有限窗口估计保留完整时间费用|不能导入线性遍历、谱分解或叠加步骤；一般全时间费用未付|
|原首次接触数值资格|同一固定模型的联合已选门排除得到连续过程证书，全部尾项、有限来源、原根和似然转换费用保留|尚未分类的原余集及其一般共同来源容量仍开放|

共同帽回代须对同一任意 f 和每个 kappa 同时成立：|Omega|≤A W/kappa、原全尺度超额能量≤B_energy kappa W。对 q=lambda/kappa≥4，费用≤qA+16nB_energy/(qlog2)，从而≤4A+8sqrt(nAB_energy/log2)。第95轮另有其原假设下的较锐返回 4A+2sqrt(2nAB_energy)；本轮未把两种证明中的符号或假设混用。无论用哪一式，A、B_energy 的一般子幂预算均未完成。

可选全窗口粗门需另付 Tsoft/alpha，可选近锚删除付 1+nlog(1+1/sqrt n)。反复用于新输入 f_i、阈值 lambda_i 时，转换至 lambda_0 的费用为 (lambda_0/lambda_i) times 当前费用 times ||f_i||1；终端接收需求不能省略。本轮没有证明这些费用可和，也没有给私人原门未知补集计零。

本轮所有修复必须回到同一任意输入、同一阈值和实际接收测度。分拆参考、改变演化或截断噪声均不自动继承原首次接触的联合门条件。完整一般上界仍是工作目标。


## 1. What is proved, and what remains open

Let \(n\ge2\), \(f\ge0\) belong to \(L^1(\mathbb R^n)\), \(W=\int f>0\), and \(\kappa>0\). Write \(Q(x,L)=x+[-L/2,L/2]^n\) and \(A_Lf=L^{-n}\int_{Q(x,L)}f\). All receiver integrals below use actual Lebesgue measure. The same original input, one transport plan, and one scale-independent cap are used throughout.

We prove a general refinement of the retained common-transport construction: construct a mass-preserving reference below a tunable ceiling, leave its common source part in place, transport only the surplus, and charge actual displacement and exterior capture. A necessary local-mass screen retains the original threshold and can remove scales that a whole-piece estimate would charge. These improvements apply to arbitrary inputs, but their remaining occupation product has no uniform subpower bound.

A new obstruction shows that this source-local screen can still charge substantial occupation when the true excess is identically zero. For the fixed half-threshold reference, the obstruction survives every admissible difference pairing and every common cap within the stated volume class. Its recipe and quantitative conclusion are PRIVATE. An explicit change of reference repairs that failure without losing mass; the general high-density source tail remains unpaid. We also give a fully paid next interface retaining the actual receiver threshold and identify its unpaid product explicitly. The general root-order theorem remains OPEN.

The R95 displacement-tail inequality (PT1)–(PT2) in its integrated proof already restricts one common coupling by actual displacement. That fact is not new here. The additions are identity preservation, the exterior occupation/depth budget, and the distinction between a necessary source-local screen and the actual common receiver threshold. No optimal-transport existence theorem is assumed.

## 2. One reference and an explicit identity-preserving coupling

Retain the original R95 maximal cyclic bad rectangles \(Q\), their longest-side labels \(\ell_Q\), and their disjoint union \(U\). Their aspect ratios are at most two, their averages satisfy
\[
 \kappa/4<|Q|^{-1}\int_Qf\le\kappa/2,
 \qquad f1_{U^c}\le\kappa/4\quad\hbox{almost everywhere}. \tag{1}
\]
Fix one parameter \(0<\varepsilon\le1/2\) for the entire input, cap, all pieces and all scales. Put \(v=(1-\varepsilon)\kappa\). Within each original rectangle define
\[
 a_Q=\min(f,v)1_Q,\quad b_Q=(f-v)_+1_Q,\quad
 t_Q=(v-f)_+1_Q,\quad B_Q=\int b_Q,\quad D_Q=\int t_Q. \tag{2}
\]
Because \(D_Q-B_Q=v|Q|-\int_Qf\ge0\), there is sufficient actual target capacity for every surplus. If \(B_Q>0\), put \(c_Q=(B_Q/D_Q)t_Q\); otherwise put \(c_Q=0\). This includes \(D_Q=0\), which forces \(B_Q=0\). Define
\[
 s=f1_{U^c}+\sum_Q(a_Q+c_Q),\qquad
 \pi=({\rm id},{\rm id})_\#\left[\left(f1_{U^c}+\sum_Qa_Q\right)dy\right]
       +\sum_{Q:B_Q>0}\frac{(b_Qdy)\otimes(c_Qdz)}{B_Q}. \tag{3}
\]
Here \(0\le c_Q\le t_Q\), so \(s\le v\); the good part is also below \(v\). The source marginal of \(\pi\) is exactly \(fdy\), its target marginal is exactly \(s dz\), and its mass is \(W\). In particular clipping alone is not used: every clipped surplus is redistributed into genuine deficit capacity. The moving mass is exactly
\[
 B_\varepsilon=\sum_QB_Q=\int_{\mathbb R^n}(f-(1-\varepsilon)\kappa)_+\le W. \tag{4}
\]
The equality is global because the source outside \(U\) is below the clipping level. One may replace each displayed product by any positive coupling of the same \(b_Q,c_Q\). Nothing assumes that the product is optimal. Moving pairs remain in their original rectangle, so their displacement \(d(y,z)=\|y-z\|_\infty\) is at most \(\ell_Q\). The common part has displacement zero for every scale and is not charged again as a separate reference source.

For \(B_0=\int(f-\kappa)_+\), the elementary pointwise inequality
\[
 (f-(1-\varepsilon)\kappa)_+
 \le\varepsilon f+(1-\varepsilon)(f-\kappa)_+,
 \qquad B_\varepsilon\le\varepsilon W+(1-\varepsilon)B_0 \tag{4a}
\]
holds by splitting \(f\le\kappa\) and \(f>\kappa\); in the second case it is equality. Thus bounded inputs \(f\le\kappa\) have moving mass at most \(\varepsilon W\), while no smallness is asserted for the general high-density tail \(B_0\).

Start with the original common cap
\[
 \Omega_0=\bigcup_Q(1+1/n)Q,\qquad
 |\Omega_0|\le4eW_{\rm bad}/\kappa. \tag{5}
\]
The cap may later be enlarged or replaced by a specified measurable cap \(\Omega\), but its entire physical union volume must be paid. For \(y\in Q\), the original cap has depth
\[
 h_0(y)=\operatorname{dist}_\infty(y,\Omega_0^c)
 \ge\ell_Q/(4n). \tag{6}
\]
The factor follows from half the padding times the shortest side, which is at least \(\ell_Q/2\). Countable sums and all restrictions of (3) are nonnegative measures; no finite first displacement moment is required.

## 3. Actual displacement and the same-input local screen

At scale \(L\), split the fixed plan by \(d\le\varepsilon L/(8n)\) and its complement. The short target is a submeasure of \(s dz\). If its source is captured by \(Q(x,L)\), its target lies in \(Q(x,L+\varepsilon L/(4n))\). Thus its total source average satisfies
\[
 A_L\nu^{\rm short}_L(x)
 \le(1-\varepsilon)\kappa\left(1+\frac\varepsilon{4n}\right)^n
 \le(1-\varepsilon)e^{\varepsilon/4}\kappa\le(1-\varepsilon/2)\kappa. \tag{7}
\]
For the last inequality, use \(e^{\varepsilon/4}\le(1-\varepsilon/4)^{-1}\le1+\varepsilon/2\), valid here, and multiply by \(1-\varepsilon\). This single estimate includes the good part and every zero-displacement common part. It does not add independently reserved thresholds for different rectangles.

Define the mass of the original input in a source-centered cube by
\[
 m(y,L)=\int_{Q(y,2L)}f. \tag{8}
\]
If \(y\in Q(x,L)\) and \(A_Lf(x)>\kappa\), then \(Q(x,L)\subset Q(y,2L)\), so \(m(y,L)>\kappa L^n\). Define the two fields
\[
 N_0(x,L)=L^{-n}\int 1_{Q(x,L)}(y)1_{\{d>\varepsilon L/(8n)\}}
                 1_{\{m(y,L)>\kappa L^n\}}\,d\pi, \tag{9}
\]
\[
 N_1(x,L)=L^{-n}\int 1_{Q(x,L)}(y)1_{\{d>\varepsilon L/(16n)\}}
                 1_{\{m(y,L)>\kappa(L/2)^n\}}\,d\pi. \tag{10}
\]
Every truly active receiver retains every captured near pair in (9); on an inactive receiver the excess is zero. Consequently
\[
 (A_Lf-\kappa)_+^2\le(N_0-\varepsilon\kappa/2)_+^2\le N_0^2. \tag{11}
\]
The screen always uses the full original \(f\), including every other source cluster. It is not recomputed from the particular transported part or from a chosen receiver.

For \(t\in[L,2L]\), cube nesting, displacement nesting, and monotonicity of \(m(y,t)\) give
\[
 N_1(x,t)\ge(L/t)^nN_0(x,L),\qquad
 N_0(x,L)\le c_nH(x),\quad
 H(x)=\int_0^\infty N_1(x,t)\,dt/t,\quad
 c_n=\frac n{1-2^{-n}}. \tag{12}
\]
Indeed a pair passing (9) has \(d>\varepsilon t/(16n)\) and \(m(y,t)\ge m(y,L)>\kappa L^n\ge\kappa(t/2)^n\). Integrating \((L/t)^n\) over that one interval proves the constant. This is a pointwise common-source comparison, with no probabilistic independence assumption.

## 4. Exact exterior occupation and its paid cap

For one fixed measurable cap \(\Omega\), let
\[
 p_\Omega(y,L)=\frac{|Q(y,L)\setminus\Omega|}{L^n},\qquad
 M_i=\int_{\Omega^c}\int_0^\infty N_i(x,L)\,dL/L\,dx. \tag{13}
\]
Tonelli gives the exact formula
\[
 M_i=\int d\pi(y,z)\int_0^\infty
      1_{\{L<a_i n d(y,z)/\varepsilon\}}
      1_{\{m(y,L)>\kappa(L/b_i)^n\}}
      p_\Omega(y,L)\,dL/L,
 \quad(a_0,b_0)=(8,1),\ (a_1,b_1)=(16,2). \tag{14}
\]
These quantities have units of source mass, not energy. They include the full exterior receiver space and every scale; they are not receiver-grid measurements. Their exact receiver fraction uses the same union cap for all source pieces. In particular overlapping caps are not counted repeatedly.

For a cap with positive depth \(h(y)=\operatorname{dist}_\infty(y,\Omega^c)\) on the moving source, exterior capture is impossible when \(L<2h(y)\). Dropping the screen and bounding the receiver fraction by one yields
\[
 M_0\le\int\log_+\frac{4nd}{\varepsilon h(y)}\,d\pi,
 \qquad M_1\le\int\log_+\frac{8nd}{\varepsilon h(y)}\,d\pi. \tag{15}
\]
Every diagonal contribution is defined to be zero, including when its depth is zero. The depth estimate is only an upper certificate for (14), not its definition. For the base cap, (6) and \(d\le\ell_Q\) imply
\[
 M_0\le B_\varepsilon\log(16n^2/\varepsilon),\qquad M_1\le B_\varepsilon\log(32n^2/\varepsilon). \tag{16}
\]
The local screens also force \(L<(W/\kappa)^{1/n}\) in (9) and \(L<2(W/\kappa)^{1/n}\) in (10). A separated group can enjoy a smaller effective window because (8) contains only mass that can actually enter that source-centered cube; neighboring groups are automatically included whenever they can enter it. No independent per-cluster threshold is added.

Assume \(0<M_1<\infty\). Add the one set
\[
 D=\{x\in\Omega^c:H(x)>\kappa M_1/W\},\qquad
 \Omega^*=\Omega\cup D. \tag{17}
\]
Markov and (13) give \(|D|\le W/\kappa\). Outside this set, (11)–(12) and then (13) give
\[
 \mathcal E_\kappa(f;\Omega^*)
 :=\int_{(\Omega^*)^c}\int_0^\infty(A_Lf-\kappa)_+^2\,dL/L\,dx
 \le c_n\kappa\frac{M_0M_1}{W}. \tag{18}
\]
If \(M_0=0\), (11) gives zero energy without adding a cap. If \(M_1=0\), (12) gives the same conclusion. Infinite moments do not provide a finite certificate. With \(\Omega=\Omega_0\), both moments are finite by (16), and \(|\Omega^*|\le(4e+1)W/\kappa\). The case \(W=0\) is trivial.

All functions here are jointly measurable: they are integrals of nonnegative measurable cube indicators and the jointly measurable function (8). Countable source sums, scale endpoints, unbounded spatial support and extended first moments are handled by Tonelli and monotone convergence. After the finite first-moment bound, exceptional infinite values of \(H\) lie in a null set or in the paid cap. No scale-dependent cap or new stopping label is introduced.

For example choose \(\varepsilon=1/n\) and write \(\eta=B_0/W\). The completely explicit all-input consequence is
\[
 \mathcal E_\kappa(f;\Omega^*)\le
 c_n\kappa W\,[1/n+(1-1/n)\eta]^2
 \log(16n^3)\log(32n^3),\qquad
 |\Omega^*|\le(4e+1)W/\kappa. \tag{18a}
\]
There is no factor \(1/\varepsilon\) in the added cap volume or the square-energy step: the smaller excess margin was bounded by \(N_0^2\), and only the scale window enlarged logarithmically. This proves a quantitative improvement for every supplied value of the actual source tail. It does not bound \(\eta\) uniformly for arbitrary inputs.

## 5. The obstruction, the reference repair, and the remaining receiver problem

At the fixed half-threshold reference (the special case \(\varepsilon=1/2\) on the PRIVATE pressure input), the PRIVATE proof shows that the necessary source-local screen can create a large exact occupation product even for inputs whose true excess vanishes everywhere. This is not merely loss in the depth bound (15). The conclusion holds for every difference coupling within the fixed identity-preserving class and for arbitrary one-cap shapes with the stated volume budget. It is a failure of that fixed-reference moment budget, not a weak-type or optimal cap-energy lower bound. The tunable construction (2)–(4a) repairs this specific failure on the very same source: its moving mass shrinks with \(\varepsilon\), and the added scale cost is only logarithmic. This repair is fully mass-preserving and common to all clusters. It leaves the genuinely high-density tail \(B_0\) unbounded.

The following conditional interface removes that false payment by retaining the actual receiver threshold. It does not assert a new uniform bound for its moments. Put \(\beta=1+1/n\) and define
\[
 F(x,L)=L^{-n}\int1_{Q(x,L)}(y)1_{\{d>\varepsilon L/(8n)\}}d\pi,
 \quad P(x,L)=F(x,L)1_{\{A_Lf(x)>\kappa\}}, \tag{19}
\]
\[
 R(x,t)=t^{-n}\int1_{Q(x,t)}(y)1_{\{d>\varepsilon t/(8n\beta)\}}d\pi
                  1_{\{A_tf(x)>\kappa\beta^{-n}\}}. \tag{20}
\]
For \(t\in[L,\beta L]\), an active cube has \(A_tf(x)\ge(L/t)^nA_Lf(x)>\kappa\beta^{-n}\), and every pair in (19) persists in (20). Hence
\[
 P(x,L)\le c_{n,\beta}\int R(x,t)dt/t,
 \qquad c_{n,\beta}=\frac n{1-\beta^{-n}}. \tag{21}
\]
Let \(\mathsf P=\int_{\Omega^c}\int P\) and \(\mathsf R=\int_{\Omega^c}\int R\), with scale measure \(dL/L\). The same single-height-cap proof gives
\[
 |\Omega^*\setminus\Omega|\le W/\kappa,
 \qquad \mathcal E_\kappa(f;\Omega^*)
 \le c_{n,\beta}\kappa\frac{\mathsf P\mathsf R}{W}. \tag{22}
\]
The threshold is \(\kappa\mathsf R/W\). If either moment is zero, the energy is zero without the extra cap. On the base cap these moments are finite: dropping the receiver gates gives the same depth windows, with displacement constants \(8n/\varepsilon\) and \(8n\beta/\varepsilon\). The upper scale cuts from the actual receiver gates are \((W/\kappa)^{1/n}\) and \(\beta(W/\kappa)^{1/n}\). In particular the relaxed receiver threshold is at least \(\kappa/e\), not an exponentially small threshold.

For a bounded input \(f\le\kappa\), \(\mathsf P=0\) exactly. This repairs the exhibited false payment, but does not control \(\mathsf P\mathsf R\) on general inputs. Proving such a joint estimate with one feasible coupling and one paid cap is the remaining nonlinear receiver problem. Replacing it by separate cluster thresholds, independent receiver optima, or an equivalent unproved Hall program is not a proof.

## 6. Return, numerical scope, and audit status

The retained return formula is
\[
 C_n\le4A_n+2\sqrt{2nA_nB_n}, \tag{23}
\]
provided the cap and actual excess-energy bounds hold uniformly for every input and every threshold of that same input. In (18), \(B_n=c_nM_0M_1/W^2\); in (22), \(B_n=c_{n,\beta}\mathsf P\mathsf R/W^2\). Neither product has the required uniform bound here. The original selector, coarse, smooth and earliest-root gates are not transferred to the changed source pieces or relaxed receiver threshold.

D01 was used to verify a genuine positive coupling and its exact marginals. No dual value, vector-measure transport theorem or optimal-plan existence theorem is imported. Its skill, provenance and cube-interface instructions were read; no new primary-paper reading is claimed.

The pilot, pressure and expanded stages actually completed on 12 distinct positive L1 densities on continuum space, in dimensions 4, 8, 16, 32, 48, 64, 96 and 128. The stage counts are 6, 3 and 3. Three author executions give 36 fixture executions on the same 12 sources. The final extension checked 36 parameterized reference configurations on those same inputs, with exact source/target marginal masses, target ceilings and short-transport margins; no new physical sources were added. In the final run, eight distinct dimension-dependent occupation integrals were enclosed using 512 computed cells; those enclosures were applied in 560 cells across the physical fixtures, including one reused dimension. The integrands represent genuine exterior receiver-volume probabilities over nondegenerate scale intervals. These are lower certificates for a moment, not energy measurements. Separately, 496 exact marginal equalities verified 744 split-coupling matrix entries. Of 27 finite cap-volume certificate attempts on the same sources, 14 succeeded; the others remain unresolved by that finite rational grid. Global cap volumes count overlaps once. No receiver-energy integral was computed. The zero true excess and zero actual receiver-gated first moment follow from the proved density bound. Recipes, quantitative method pressure, code and exact output remain PRIVATE.

Both auditors independently passed the complete Markdown and matching TeX mathematics, PRIVATE proofs, embedded program and entire saved results. Both also extracted and replayed the program: all mathematical JSON agreed after removing only the total and per-stage timing fields. Astra reported external elapsed time 0.070372708 seconds and Sol 0.071477833 seconds. These are two auditor replays, separate from the three author runs and 36 author fixture executions on 12 distinct sources; they add no new physical inputs. Neither replay is an independent reconstruction of the algorithm or a receiver-energy integration. The final reviews retain the exact scope: the tunable reference is mass-preserving, the fixed-reference obstruction does not reject that repair, and the general high-density tail and receiver-moment product remain unpaid.

## 1. Outcome and original target

No uniform root-order common column for the original captured-middle residual is proved in this round. The new result is an exact, general common-receiver transport calculation: fixed captured-mass radii admit a dimension-free spatial Jacobian, but the measure carrying the actual hard demand has a different Radon–Nikodym derivative. Its normalization cost, a bounded-displacement repair, the discarded-noise cost and the original-threshold return are all explicit below. This is a strategy audit, not a replacement of the open target by a conditional score bound. In particular, a small hard share is not a high common column: receiver volume remains in every integral.

Let n>=2, mu=f dy be a finite nonzero positive L1 measure, W=mu(R^n), Q(x,L)=x+[-L/2,L/2]^n, and A_L f=L^-n mu(Q(x,L)). At the original earliest contact L_x in [1,2], A_(L_x)f(x)=lambda, the anchor is A_1 f<lambda/2, all earlier scales in [1,L_x) are strictly below lambda, and a later scale has a strict witness above lambda. Original full-window P1, selected coarse, middle, packet and physical gates are retained, with the additional paid R97 captured-middle deletion. Write H_n=1+n log 2, theta=log^-2(n+2), alpha=1/[10 log(n+2)], and b_n=e^-s_n/2 as in the retained R82/R97 definitions.

On the actual captured posterior pi_x=1_Q mu/(lambda L_x^n), put F_x(y)=Phi_1((x-y)/L_x), G_x(y)=Phi_theta((x-y)/L_x). The remaining event has E_pi F>b_n and E_pi G<alpha. Its ratio-only set S_x={G_x/F_x<=4alpha/b_n} satisfies d_x=E_pi(F_x 1_S)>3b_n/4. Thus

    a_x(y)=L_x^-n 1_Q(x,L_x)(y) F_x(y) 1_Sx(y)/d_x,       integral a_x dmu=lambda.                 (1)

The unresolved conjecture is a uniform root-order bound for esssup_(y,mu) integral_B a_x(y)dx, for every measurable original receiver cut B. A counter to (1), if obtained, would only refute this fixed allocation, not optimal common capture. No such qualified counter is asserted here. R97's two-cutoff example, or its ratio-only repair, does not decide this column because it does not remove the actual dx integral.

## 2. A general mass radius and the correct transported measure

For every fixed 0<m<W, define

    r_m(x)=inf{L>0: mu(Q(x,L))>=m}.                                                       (2)

It is finite, positive, satisfies mu(Q(x,r_m(x)))=m, and is 2-Lipschitz in the sup norm. Indeed capture mass is continuous in L and x by absolute continuity of mu; it tends to zero as L decreases to zero and to W as L increases. If h=||x-x'||_infty, Q(x,L) is contained in Q(x',L+2h). Apply this at r_m(x) and exchange x,x'. These arguments do not require compact source support or bounded density.

Let z be fixed with q=2||z||_infty<1, and T_z(x)=x+r_m(x)z. This is a global bi-Lipschitz bijection, with lower and upper sup-norm constants 1-q and 1+q. For a prescribed u, x=u-r_m(x)z is a contraction equation, proving surjectivity and uniqueness. Almost everywhere,

    J_z(x)=det DT_z(x)=1+z dot grad r_m(x),       1-q<=J_z<=1+q.                            (3)

The gradient has l1 norm at most 2. Alternatively, choose the direction of z as the first coordinate: the map fixes transverse coordinates and is increasing on each line, so the ordinary one-dimensional substitution formula gives the same area formula. No process law, martingale or independence is introduced.

The relevant fixed-mass hard demand measure is nu_m(dx)=m r_m(x)^-n dx, not Lebesgue measure alone. For any Borel B and nonnegative test function, substitution gives TWO different identities:

    nu_m(T_z B)=integral_B J_z(x)[r_m(x)/r_m(T_z x)]^n dnu_m(x),                            (4)
    d(T_z#nu_m)/dnu_m(T_z x)=[r_m(T_z x)/r_m(x)]^n/J_z(x)=:R_z(T_z x).                     (5)

Equation (4) is an image-weight/pullback comparison. Equation (5) is the pushed-demand density, which is the direction needed to dominate transported demands by an available image-receiver reference measure. They are reciprocal at corresponding points and must not be interchanged. Since r_m(T_z x)/r_m(x) lies in [1-q,1+q],

    (1-q)^n/(1+q) <= R_z <= (1+q)^n/(1-q)=:C_n(q).                                      (6)

These statements hold for sigma-finite measures; on every compact receiver set r_m has a positive minimum. They extend to arbitrary nonnegative integrals by monotone convergence.

The fixed-mass identity really connects to an original contact, but only with a receiver-dependent mass:

    m_x=lambda L_x^n in [lambda,2^n lambda],        r_(m_x)(x)=L_x.                         (7)

The strict later witness implies m_x<W. For s<1 the anchor gives mu(Q(x,s))<lambda/2<m_x; for 1<=s<L_x, firstness gives mu(Q(x,s))<lambda s^n<m_x. This proves (7). It does not identify a common fixed m across B, nor preserve original gates at T_z x.

## 3. What a genuine common-capacity transfer would pay

Here is the precise positive-coupling use of (5). Fix a measurable receiver domain D of finite nu_m measure and a measurable B with T_z(B) contained in D. Suppose a measurable family of probability source laws kappa_u(dy), defined for u in D and supported in a specified admissible source graph, obeys

    integral_D kappa_u(E) dnu_m(u) <= C mu(E)    for every measurable source set E.            (8)

This is a localized receiver hypothesis: nu_m on all of R^n has infinite mass, since r_m(x)<=r_m(0)+2||x||_infty and the resulting radial lower bound has a logarithmically divergent integral. Thus imposing a finite-capacity probability kernel globally would be vacuous. Transport receiver demands in B by T_z and use kappa_(T_z x). Formula (5) implies a source-column bound C_n(q) C mu(E). This follows directly by Tonelli and measure domination, and does not invoke an optimal-transport existence or duality theorem. The sharp receiver-measure multiplier for this generic argument is esssup R_z on the transported region: domination of every receiver cut is equivalent to the corresponding Radon–Nikodym bound.

This is a precise transfer lemma, not a proof of (8). Moreover, the source graph at the image receiver need not be the original Q(x,L_x). An admissibility return must be proved independently before using this transfer as an original Hall allocation. Also, the original shifted average A_(r_m(x))f(T_z x) uses the old side, whereas the image reference demand uses r_m(T_z x); they cannot be silently identified.

A bounded repair exists for the MEASURE TRANSFER itself. If q<=1/(4n), then

    R_z<=C_n(q)<=3/2.                                                                    (9)

For n>=3, use (1+1/(4n))^n<=1/(1-1/4)=4/3 and 1/(1-1/(4n))<=12/11. For n=2 the exact endpoint is (9/8)^2/(7/8)=81/56<3/2. This dimension-free repair applies to the fixed-mass receiver measure only; it does not prove graph preservation, remove mass labels, or inherit the original joint gates.

## 4. Noise truncation is not free

The physical one-dimensional noise density is w(t)=integral_0^1 exp(-|t|/v)dv. It is a probability density with w<=1. For theta>0 let w_theta^(n)(z)=theta^-n product_j w(z_j/theta). Then, for any original side L,

    P_(theta,L)f(x)=integral A_L f(x-Lz) w_theta^(n)(z)dz.                                 (10)

The safe region from (9) is E_n={||z||_infty<=1/(8n)}. Its positive probability p_n satisfies

    p_n<=min(1,[1/(4n theta)]^n).                                                         (11)

This is a density-times-volume bound on the actual common noise law. If P_small is the conditional average over E_n, positivity yields only

    P_small<=P_(theta,L)/p_n< (alpha/p_n) lambda                                           (12)

on an original selected coarse-low receiver. Thus conditioning changes the threshold. If p_n<alpha, the conclusion does not retain the original small coarse threshold. Alternatively retaining the unnormalized small part retains only probability p_n; one must keep the complementary integral in (10). Neither an unproved comparison with a truncated noise kernel nor a missing probability mass is a paid branch.

For theta=log^-2(n+2), the upper bound in (11) tends to zero faster than any fixed inverse power of n. Indeed log(n+2)^2/(4n) tends to zero, and its n-th power is eventually below n^-A for each fixed A. The exact finite probes below verify the relevant inequality without a floating decision. This observation concerns the attempted generic transport repair, not an original-operator lower bound.

Fixed mass labels introduce a separate return. The masses in (7) range over a factor 2^n. A fixed geometric ratio g>1 therefore permits at most 1+ceil(n log 2/log g) elementary bins; this count is not subpower for fixed g. Approximating m_x by a lower bin endpoint changes the contact and generally the threshold. Any fresh anchor/coarse/packet classification and its repeated source fee must then be included. No such bin sum is claimed to be free or to be a necessary lower bound for all possible reorganizations.

## 5. Complete original-event fallback and recursion accounting

All claims above use the same input mu. They neither delete a subset of the original event nor change its original selector. If the transport route is not completed, an unconditional actual-capture repair remains the canonical hard coupling

    k_x(y)=L_x^-n 1_Q(x,L_x)(y),        integral k_x dmu=lambda.

For each y, it is bounded by the full-window hard envelope psi(x-y)=max(1,2||x-y||_infty)^-n 1_{2||x-y||_infty<=2}. Its integral is H_n. Therefore every original receiver subcut B satisfies lambda|B|<=H_n mu(N_B), where N_B is the essential common capture neighborhood. This is a fully paid general linear bound, not a new root bound.

For completeness retain the R97 local ledger. Set

    Bbase=4+2 log2 sqrt(7n/3),       Cext=2H_n/sqrt(n+2),
    Tsoft=1+log2 min(2n,sqrt(n(theta^-1+4theta/3))),
    a0=n^-p0, rho0=n^-1/2, Pdom=(5+3log(1/a0))/rho0     (fixed p0>0),
    h*=1/(16n^(3/2)), E*=exp(nh*), B*=1+E*[1+(2n^2+n)h*],
    Pphys=2[E*+B*+2(1+E*)sqrt(n)],
    Aold=Bbase+Cext+Tsoft/alpha+Pdom+Pphys.

The R97 captured-middle deletion adds another Cext; Pphys is charged once for its prescribed union. With F_rem the resulting original residual,

    lambda|E_initial| <= (Aold+Cext)W+lambda|F_rem|
                       <= (Aold+Cext+H_n)W.                                              (13)

The optional full-window coarse refinement costs another Tsoft/alpha, and the optional near-anchor branch costs 1+n log(1+1/sqrt(n)); neither is used or silently inherited here. An additional R83 registered-width union, if used, retains its stated extra Cext. The all-scale return retains its C_local log(n+2) factor; any actual kappa-layer sum retains J_n and its overlap factors.

If a future implementation repeats any new branch at input mu_i and threshold lambda_i, its original-threshold charge is t_i times its current charge, t_i=lambda_0/lambda_i. In particular the captured-middle classification contributes t_i Cext W_i; a transport of a plan with current source fee C_i would contribute t_i C_n(q_i) C_i W_i only after graph admissibility and all reclassifications are proved. Conditioning a noise branch must retain p_i and its complement as in (10)--(12). The unfinished receiver demand keeps its actual terminal; the generic full-window terminal is t_m H_n W_m. No summability or terminal vanishing is deduced from the dimension-free spatial Jacobian. Equation (13) is a single-input fallback with no recursive terminal.

## 6. Evidence and remaining gap

The updated D01 and A02 skills were read: this text uses an explicit positive common coupling and an exact measure comparison, not vector-measure transport, a process superposition theorem or an unproved relaxation return. No external theorem beyond elementary one-dimensional substitution and Tonelli is imported. No captured-posterior coordinate independence is assumed.

Three stages checked six compact positive-L1 physical source formulas, exact fixed-mass first radii and positive Lebesgue receiver volumes. There are 151 exact assertions: 50/50/50 in the physical stages and one separate n=2 repair check. Author final execution took 5.519344708 seconds. Rational outward log intervals and positive Taylor bounds make every decision exact; printed decimals are only displays. The tests explicitly reject original coarse qualification, so they are NOT samples of F_rem and do not disprove (1). The PRIVATE section gives the recipes and quantified transport consequences. Auditors' statement checks preceded the proof. Astra's full MD and matching TeX review passed after localizing (8) to a finite-demand receiver domain; its independent extracted replay passed 151 checks in 5.527142500 seconds internally and 5.545854042 seconds externally. This replays the same six nongated physical sources and exact analytic certificates, not an independent integration of the original operator.

Independent Sol review also passed the full MD and matching detailed TeX, including the finite-domain localization, both transfer directions and the PRIVATE physical quantile, positive-volume and coarse-failure proofs. Its single extracted replay passed 151 checks (50/50/50 plus the separate n=2 check), internal 5.524055708 seconds and external 5.542551541 seconds. This uses the same six physical sources and does not certify original common-threshold/Fnew qualification or perform original-operator numerical integration. The deferred averaged-noise candidate is not part of this round.

The unresolved issue is still a uniform common-source column for the original joint-gated captured-middle event, or a different admissible allocation with root-priced source cost. The fixed-mass construction supplies neither: its spatial Jacobian omits the demand normalization, the repaired small displacement has a probability/threshold cost, and its mass label and capture-graph return are unpaid. These are precise failure points for this pointwise-transfer route, rather than a claimed new geometric root reduction. They do not exclude a separately proved averaged-noise transport estimate; a bound for each displacement and a bound for their actual average are different assertions.

## A1. Exact interface and result status

For nonnegative integrable sources on \(\mathbb R^n\), write
\[
 A_Rf(x)=(2R)^{-n}\int_{x+[-R,R]^n}f(y)\,dy,
 \qquad M_\square f=\sup_{R>0}A_Rf.
\]
The proposed actual evolution is the \(L^2\) gradient flow of
\[
 E(u)=\frac12\int_{\mathbb R^n}\|\nabla u\|_1^2,
 \qquad F(\xi)=\tfrac12\|\xi\|_1^2.
 \tag{A1}
\]
The domain in (A1) is \(H^1(\mathbb R^n)\), with value \(+\infty\) outside it in \(L^2\). The general existence, positive order, contraction, flux selection and whole-space mass extension are the separately owned `sources.md` module. Here the exact required interface is: for nonnegative \(f\in L^1\cap L^2\), \(u=S_tf\) is strongly continuous in \(L^2\), nonnegative, contracts \(L^1,L^2\), and solves \(\partial_tu=\operatorname{div}z\), \(z\in\partial F(\nabla u)\), with the usual local energy chain rule. In particular
\[
 \int_0^T\!\|z(t)\|_2^2dt\le\frac n2\|f\|_2^2,
 \tag{A2}
\]
because \(z\cdot\nabla u=\|\nabla u\|_1^2\), \(|z|_2^2\le n\|\nabla u\|_1^2\), and testing by \(u\) gives dissipation. Our profile construction below is independent of existence for arbitrary data and identifies its own actual orbit by monotonicity. No primary theorem for a smooth, strongly convex norm is silently applied to \(\ell^1\).

The result is an actual cube-shaped Gaussian orbit with a root-order geometric coefficient and an explicit account of what a general multisource repair would cost. A general comparison \(M_\square f\le B M_Sf\), where \(M_Sf=\operatorname*{ess\,sup}_{t>0}S_tf\), has **not** been proved. A weak estimate for this actual nonlinear maximal operator is a separate unresolved interface, owned by `nonlinear_maximal.md`. No endpoint improvement follows here.

## A2. Actual crystalline Gaussian, including its flux

Put \(a=n/2\), \(r=\|x\|_\infty\), and for \(t>0\) set
\[
 U_t(x)=\frac{e^{-r^2/(4t)}}{4^n\Gamma(a+1)t^a},
 \qquad z_t(x)=-\frac{x}{2t}U_t(x).
 \tag{A3}
\]
The cube shell formula is
\[
 \int h(\|x\|_\infty)dx=n2^n\int_0^\infty h(r)r^{n-1}dr.
 \tag{A4}
\]
Substitution \(s=r^2/(4t)\) yields \(\int U_t=1\) and \(\int r^2U_t=2nt\). All integrals are positive and finite. Away from the null union of tie faces, there is a unique maximizing coordinate \(j\), and
\[
 \nabla U_t=-\frac{x_jU_t}{2t}e_j,
 \quad \|\nabla U_t\|_1=\frac{rU_t}{2t}.
\]
The subdifferential at a vector \(\xi\) is \(\|\xi\|_1\partial\|\xi\|_1\): its nonzero coordinates have the prescribed sign and magnitude, and its zero coordinates may have any magnitude at most \(\|\xi\|_1\). Thus \(z_t\in\partial F(\nabla U_t)\). The flux \(-xU_t/(2t)\) is locally Lipschitz across every tie face; there is no omitted surface distribution. Direct differentiation gives
\[
 \operatorname{div}z_t
 =U_t\left(-\frac n{2t}+\frac{r^2}{4t^2}\right)
 =\partial_tU_t.
 \tag{A5}
\]
For every \(\varepsilon>0\), \(U_\varepsilon\in L^1\cap L^2\cap H^1\), \(z_t\in L^2\), and \(\operatorname{div}z_t\in L^2\) on time intervals bounded away from zero. The subgradient inequality for \(F\), integrated by parts, proves \(-\operatorname{div}z_t\in\partial E(U_t)\). Hence this is an actual strong gradient-flow solution. If \(u,v\) share initial data, monotonicity gives
\[
 \frac12\frac d{dt}\|u-v\|_2^2
 =-\int(z_u-z_v)\cdot(\nabla u-\nabla v)\le0.
\]
Therefore the actual semigroup, whenever defined by (A1), satisfies
\[
 S_tU_\varepsilon=U_{t+\varepsilon}.
 \tag{A6}
\]
Translations and nonnegative amplitude multiples also give actual solutions by spatial invariance and degree-one homogeneity of the flux graph. Their sums are not identified as solutions.

## A3. Geometric cost and its precise limit

For \(r>0\), maximizing (A3) in \(t\) gives \(t=r^2/(2n)\) and
\[
 \sup_{t>0}U_t(x)=\frac1{B_n(2r)^n},
 \qquad B_n=\Gamma(a+1)(e/a)^a.
 \tag{A7}
\]
For \(n\ge2\), the elementary bounds
\[
 \frac{\sqrt n}{3}\le B_n\le6\sqrt n
 \tag{A8}
\]
follow without an asymptotic theorem. Indeed
\(B_n=a\int_0^\infty e^{a(\log s-s+1)}ds\).
On \([1,1+a^{-1/2}]\), \(\log(1+h)\ge h-h^2/2\), giving the lower bound \(e^{-1/2}\sqrt a\). On \((0,2]\), the phase is at most \(-(s-1)^2/8\); on \([2,\infty)\), its derivative is at most \(-1/2\). Thus \(B_n\le\sqrt{8\pi a}+2\le6\sqrt n\).

At time \(t=R^2/(2n)\), the minimum of \(U_t\) over \([-R,R]^n\) is exactly \((2R)^{-n}/B_n\). Consequently
\[
 A_Rf\le B_n(U_{R^2/(2n)}*f)
 \tag{A9}
\]
for every nonnegative \(f\), by positive integration. This is a **linear convolution inequality**. Equations (A3)–(A6) provide no equality between \(U_t*f\) and \(S_tf\) for general \(f\). Thus (A9) does not establish the required actual nonlinear multisource bridge. Its geometric factor would be acceptable if such a bridge and the actual maximal budget, together with all return costs, had product \(\sqrt n\,n^{o(1)}\).

## A4. Why coefficient-one superposition cannot be inserted

Let \(T:L^1_+\to L^1_+\) preserve every input mass. If either \(T(f+g)\le Tf+Tg\) for all nonnegative \(f,g\), or the reverse inequality holds for all such inputs, then equality holds almost everywhere: the nonnegative difference has integral zero. Thus either global coefficient-one assumption already makes \(T\) additive on the positive cone. This statement does not address larger comparison factors, signed inputs, or mass-losing maps. Order preservation alone does not supply either inequality.

## A5. A conditional multisource repair with all fees retained

Suppose \(S\) is order preserving and \(M_S\) has a genuine weak \((1,1)\) coefficient \(H\). Suppose, uniformly for every nonnegative \(f\in L^1\), one can choose
\[
 f=\sum_{j=1}^Ng_j+r,\qquad g_j,r\ge0,
 \quad\|r\|_1\le\rho\|f\|_1,\quad0\le\rho<1,
 \tag{A10}
\]
with a uniform finite \(N\), and each actual component has an already proved bridge \(M_\square g_j\le B M_Sg_j\). This assumption is not supplied by the single profile calculation. Order and cube sublinearity give
\[
 M_\square f\le NB M_Sf+M_\square r.
\]
Let \(C_n<\infty\) denote the existing cube weak constant, retaining the benchmark rather than assuming its desired improvement. For \(\rho<\theta<1\), the threshold split gives
\[
 C_n\le\frac{NBH}{1-\theta}+\frac\rho\theta C_n,
 \quad
 C_n\le\frac{NBH}{(1-\theta)(1-\rho/\theta)}.
 \tag{A11}
\]
To justify the first inequality, apply the level-set estimate to every \(f,\lambda\), divide by \(\|f\|_1/\lambda\), and take the supremum. Finite \(C_n\) permits the absorption. Choosing \(\theta=\sqrt\rho\) gives
\[
 C_n\le\frac{NBH}{(1-\sqrt\rho)^2}\quad(0<\rho<1);
 \qquad C_n\le NBH\quad(\rho=0).
 \tag{A12}
\]
For \(\rho=0\), take \(\theta\downarrow0\). The multiplicity, weak-flow coefficient, and residual loss are all charged. No qualifying uniform decomposition or actual component bridge has been established here. In particular, an unpaid remainder or a source-dependent unbounded \(N\) cannot be discarded.

## A6. Executed scope and remaining boundary

Three disjoint exact checks used even dimensions \(8,12\), then \(16,32\), then \(64,128\). Each stage contained two genuine normalized Gaussian inputs and two finite positive box inputs, with four positive-volume receiver boxes. Across all stages: 12 actual inputs, 12 receiver boxes, 36 rational normalized flux checks, and 36 interval-enclosed barrier-time checks. The program uses only Python's standard library, exact fractions, and proved exponential enclosures. It performs **zero general nonlinear PDE solves**. Profile identities and localized comparison prove the continuous statements; finite regression points do not prove a general multisource or weak maximal estimate. The complete program, pressure recipes, quantitative pressure conclusions, and receipts are in the private appendix.

The retained gain is a verified actual orbit and an explicit paid interface. A universal adaptive-time cube-to-flow comparison, a suitable decomposition with uniform fees, and the direct nonlinear maximal budget remain unresolved. The general \(\sqrt n\,n^{o(1)}\) goal is not proved.

## S0. Result and dependency boundary

For every dimension n≥1, the energy
\[
 F(v)=\tfrac12\|v\|_1^2,\qquad
 \mathcal E(u)=\begin{cases}\int_{\mathbb R^n}F(\nabla u)\,dx,&u\in H^1(\mathbb R^n),\\+\infty,&\text{otherwise}\end{cases}                 \tag{1}
\]
generates a genuine nonlinear flow S_t on L², and extends to a positive, order-preserving, mass-conserving strongly continuous contraction semigroup on positive L¹. For positive f∈L¹∩L² its actual solution has the weak flux and energy class proved below. This supplies a general solution contract for the crystalline covector norm H=ℓ¹, whose dual spatial norm is ℓ∞. It does not supply a maximal estimate, a source-independent linear generator, a convolution formula for several sources, or a cube-to-flow comparison. Those are separate interfaces owned by the alternative and nonlinear-maximal modules.

The abstract Hilbert subgradient generation theorem is an external dependency: a proper, nonnegative, convex, lower semicontinuous functional with dense domain generates the unique strongly continuous L² contraction flow of −∂E; its resolvents minimize E(v)+||v−f||²/(2τ), and the exponential resolvent formula constructs the flow. Cipriani–Grillo use this theorem through their cited Brezis theory. We read their projection and Markov proofs, and verify the specific functional and all additional whole-space assertions here. We do not claim to have reproduced or independently reread that full generation monograph.

## S1. Actual primary reading and applicable statements

**Cipriani–Grillo**, *Nonlinear Markov semigroups, nonlinear Dirichlet forms and applications to minimal surfaces*, J. reine angew. Math. 562 (2003), 201–235, DOI 10.1515/crll.2003.074. The author-uploaded manuscript was read as HTML full text, rather than as an unrestricted publisher PDF. Selected printed manuscript pp.5–13 cover Definitions 2.1–2.2/3.1, Theorem 2.4, Lemma 3.3, and complete proofs of Theorems 3.4 and 3.6. Theorem 3.4 identifies invariance of a closed convex set with decrease of the energy under its orthogonal projection. Theorem 3.6 converts the corresponding order and L∞ pair projections into a nonlinear Markov flow and Lp difference contractions, 1≤p≤∞. Its measure space is countably generated and σ-finite; our Lebesgue space qualifies. Theorem 4.11 and its short proof on printed p.23 were also read, but its external relaxation references are not substituted for our direct closure proof. Later applications and external Brezis/Browder dependencies were not fully reread. [Author manuscript](https://www.researchgate.net/publication/233748187_Nonlinear_Markov_semigroups_nonlinear_Dirichlet_forms_and_applications_to_minimal_surfaces).

**Ohta–Sturm**, *Heat Flow on Finsler Manifolds*. Actual version: arXiv:0808.1166v4, header 26 September 2012, internal date 30 October 2018; publication CPAM 62 (2009), 1386–1433. Read printed pp.1–3 and 6–18: norm/Legendre hypotheses, energy and Lemma 2.4, Chapter 3 including Theorems 3.4/3.7 and their proofs, and Chapter 4 statements and body proofs. Appendix regularity proofs, later compact entropy-flow chapters, and external Harnack proofs were not read. The basic Hessian hypothesis (1.2) requires positive finite ellipticity constants away from zero. Chapter 3 weakens some construction assumptions to differentiable strictly convex norms; neither version automatically includes crystalline ℓ¹/ℓ∞. Theorem 3.7 gives Lp contraction with rate 4(p−1)κ_Mχ_M/p²; χ_Rn=0 leaves norm contraction. Lemma 2.4 and Proposition 4.5 have solution-dependent linearized coefficients. Compact mass remarks and smooth regularity do not prove our whole-space crystalline conservation. [Primary v4](https://arxiv.org/pdf/0808.1166v4).

The located Calvo–Marigonda–Orlandi *Anisotropic tempered diffusion equations* manuscript was actually read on pp.1–10 through Assumptions 2.1, Definition 2.3, Lemma 2.5 and its proof, Lemma 2.6, and the examples. It concerns a different flux-limited equation u_t=div[u∇Φ(∇u/u)], with C² convex even Φ and finite positive recession function. Its entropy appendix and external existence framework were not read. A derivative implication in the printed Lemma 2.5 needs a separate check; the exact local check is outside the public portion. This paper is not used to generate (1). [Institutional primary](https://iris.univr.it/retrieve/e14ff6e5-14d6-0209-e053-6605fe0ad24c/Anisotropies24.pdf).

Targeted updated64 reading this round: A02, E01, E02 and N02 entries. A02 still needs actual domination and a paid remainder; an occupation identity does not give nonlinear superposition; the nonlocal HJB interface is a different generator; log-concavity of one profile does not imply log-concavity or a kernel representation of arbitrary solutions. The explicit authorized evidence root in the contract was used read-only. The old registry root remains missing and was not repaired. Reading a skill or verifying a hash is not reading a primary proof.

## S2. Convex energy, actual generation and contraction

The norm comparison
\[
 \tfrac12\|\nabla u\|_2^2\le\mathcal E(u)
 \le\tfrac n2\|\nabla u\|_2^2                                      \tag{2}
\]
shows the finite domain is exactly H¹. E is nonnegative and convex. If u_j→u in L² and liminf E(u_j)<∞, a subsequence is bounded in H¹, its gradients converge weakly to ∇u, and weak lower semicontinuity of the convex integral gives E(u)≤liminf E(u_j). Smooth compact functions are dense in L². They also approximate each H¹ function in energy, because
\[
 |F(a)-F(b)|\le\tfrac n2(|a|_2+|b|_2)|a-b|_2.
\]
Thus (1) satisfies the exact abstract generation hypotheses, with no smoothness or strict convexity of the norm assumed.

For u,v∈H¹ and a Lipschitz p with p(0)=0 and 0≤p'≤1 almost everywhere, set w=u−v and
\[
 \widetilde u=u-p(w),\quad \widetilde v=v+p(w).
\]
The Sobolev chain rule gives the two gradients as convex combinations of ∇u and ∇v with coefficients t=p'(w) and 1−t. Convexity of F therefore gives
\[
 \mathcal E(\widetilde u)+\mathcal E(\widetilde v)
 \le\mathcal E(u)+\mathcal E(v).                                  \tag{3}
\]
For infinite pair energy the assertion is immediate. Taking p(r)=r_+/2 gives the orthogonal projection of (u,v) onto {u≤v}. Taking p(r)=(r−clip_[−a,a](r))/2 gives the projection onto {||u−v||∞≤a}, for every a>0. Their derivatives are 0 or 1/2, and all projected functions remain in L² and H¹. Apply the read projection criterion to E⊕E. It follows from the read Markov theorem that
\[
 u\le v\Longrightarrow S_tu\le S_tv,\qquad
 \|S_tu-S_tv\|_p\le\|u-v\|_p\quad(1\le p\le\infty),               \tag{4}
\]
whenever the initial L² functions have finite indicated difference norm. Since S_t0=0, positive inputs stay positive and their L¹ norm never increases. The contraction constants are exactly 1. The source's general interpolation/duality dependencies remain external; (3) is our explicit check of its actual premises.

Amplitude homogeneity is also exact: E(cu)=c²E(u) and ∂E(cu)=c∂E(u) for c>0, so uniqueness gives S_t(cf)=cS_tf. This is degree-one amplitude homogeneity of a nonlinear operator, and is not additivity.

## S3. Jointly measurable weak flux and the complete energy class

Write ξ(t)=−∂_tu(t)∈∂E(u(t)). Standard Hilbert gradient-flow regularity gives ξ∈L²([δ,T];L²) and u∈L²([δ,T];H¹) for every 0<δ<T. The finite energy identity below extends the latter integrability down to t=0. We construct a joint measurable flux rather than assuming that a crystalline gradient is single valued.

On a fixed interval I away from zero, put v=∇u and let
\[
 \mathfrak F(v)=\int_I\int_{\mathbb R^n}F(v)\,dx\,dt.
\]
This is a continuous finite convex functional on the vector Hilbert space L²(I×Rn;Rn). On the range of the gradient map from L²(I;H¹), define
\[
 \ell(\nabla h)=\int_I\int\xi h.
\]
The range kernel is zero: an H¹ function on Rn with zero gradient is an L² constant, hence zero. The pointwise-in-time subgradient inequality extends to every h∈L²(I;H¹), by integration. Scaling h by positive numbers yields
\[
 \ell(w)\le D\mathfrak F(v;w),\qquad
 |D\mathfrak F(v;w)|\le n\|v\|_2\|w\|_2.
\]
The directional derivative is continuous and sublinear. Dominated Hahn–Banach extends ℓ to the entire vector Hilbert space; Riesz represents it by z∈L²(I×Rn;Rn). Since D𝔽(v;w)≤𝔽(v+w)−𝔽(v), the extension satisfies the full subgradient inequality for every vector w. Localizing to measurable space-time subsets and a countable dense family of vector perturbations gives
\[
 z(t,x)\in\partial F(\nabla u(t,x))\quad\text{a.e.},\qquad
 -\operatorname{div}_x z=\xi.                                   \tag{5}
\]
Localization is legitimate because the integrand is finite and continuous; failure of any pointwise inequality has a positive-measure subset detected by a rational perturbation. Equality on the original gradient range gives the distributional divergence identity, including tests supported in time. Countably partition (0,∞) into intervals bounded away from zero, carry out this construction on each, and patch their L² representatives. This produces one jointly measurable flux on all positive times. No measurable-selection or unique-flux assertion is required.

For a=||v||₁, finite-dimensional duality gives F*(z)=||z||∞²/2 and
\[
 z\in\partial F(v)\Longrightarrow
 z\cdot v=a^2,\quad |z|_2^2\le n a^2.                          \tag{6}
\]
If a>0, nonzero coordinates satisfy z_j=a sign(v_j), while zero coordinates satisfy |z_j|≤a; if v=0 then z=0. The coefficient n in (6) is retained.

Euler homogeneity, applied to the scalar variations (1+s)u, gives ⟨ξ,u⟩=2E(u). On intervals away from zero,
\[
 \tfrac12\frac d{dt}\|u(t)\|_2^2
 =-2\mathcal E(u(t))=-\int\|\nabla u(t)\|_1^2.
\]
Strong initial L² continuity lets δ↓0, and hence for every f∈L² and T>0,
\[
 \int_0^T\int\|\nabla u\|_1^2
 =\tfrac12(\|f\|_2^2-\|u(T)\|_2^2),\qquad
 \int_0^T\int|z|_2^2\le\tfrac n2\|f\|_2^2.                    \tag{7}
\]
In particular
\[
 u\in C([0,\infty);L^2)\cap L^2(0,T;H^1),\quad
 u_t=\operatorname{div}z\in L^2(0,T;H^{-1}).                   \tag{8}
\]
We do not assert u_t∈L²(0,T;L²) for arbitrary L² initial data; its L² regularity is only away from zero. The usual H¹–L²–H⁻¹ chain rule applies to (8). Conversely, two solutions in this weak energy class with their respective subgradient fluxes and the same initial datum agree: testing their difference gives
\[
 \tfrac12\frac d{dt}\|u-v\|_2^2
 =-\int(z-w)\cdot(\nabla u-\nabla v)\le0.
\]
This is uniqueness of the physical weak solution, even though its flux need not be unique.

## S4. Bounded weights, whole-space mass, and L¹ extension

Let 0≤f∈L¹∩L² have compact support. Fix α>0 and first use only the bounded Lipschitz weight ψ_N=min(α|x|₂,N). The test e^{2ψ_N}u lies in H¹ for a.e. time. The H⁻¹ time derivative in (8), bounded multiplication on H¹, and the quadratic chain rule (or time Steklov approximation) justify
\[
 Y_N=\int e^{2\psi_N}u^2,\quad
 G_N=\int e^{2\psi_N}\|\nabla u\|_1^2,\qquad
 \tfrac12Y_N'=-G_N-2\int e^{2\psi_N}u\,z\cdot\nabla\psi_N.
\]
Using |∇ψ_N|₂≤α, (6), and 2√nα|u|a≤a²/2+2nα²u² gives
\[
 Y_N'+G_N\le4n\alpha^2Y_N.
\]
Integrate this differential inequality and Gronwall; both conclusions are
\[
 Y_N(t)\le e^{4n\alpha^2t}Y_N(0),\qquad
 \int_0^T G_N\le e^{4n\alpha^2T}Y_N(0).                       \tag{9}
\]
The second follows by integrating Y_N'+G_N, using the first inequality in the right side, and retaining the nonnegative final Y_N. Compact L² data have Y₀=∫e^{2α|x|₂}f²<∞. Monotone convergence in N yields the same bounds for the unbounded weight, and
\[
 \int_0^T\int e^{2\alpha|x|_2}|z|_2^2
 \le n e^{4n\alpha^2T}Y_0.
\]
No unbounded weight was used before these justified limits. If ω_n is the Euclidean unit-ball volume, then
\[
 I_{n,\alpha}=\int e^{-2\alpha|x|_2}dx
 =\frac{\omega_n n!}{(2\alpha)^n}<\infty,\qquad
 \int_0^T\int|z|_2
 \le\big[T I_{n,\alpha}n e^{4n\alpha^2T}Y_0\big]^{1/2}.        \tag{10}
\]
This is an explicit source-, time-, dimension- and α-dependent integrability estimate. It is used for conservation, not claimed to be a weak maximal fee.

By (4), u(t)≥0 and ||u(t)||₁≤W=||f||₁ at every time. Let η_R be compact cutoffs tending to 1, with ||∇η_R||∞≤C/R. The weak equation and L² time continuity give, for every t≥0,
\[
 \int u(t)\eta_R-\int f\eta_R
 =-\int_0^t\int z\cdot\nabla\eta_R.
\]
The right side tends to zero by (10); dominated convergence on the two L¹ terms proves ||u(t)||₁=W. This argument uses the whole-space flux estimate, rather than using the constant test 1 in an L² formulation.

Strong L¹ time continuity for compact data follows as well. The unbounded-weight bound controls the L¹ tail uniformly for 0≤t≤T, by Cauchy–Schwarz with ∫_{|x|>R}e^{−2α|x|}→0. Local L² continuity controls L¹ on each bounded ball. Together they give global L¹ continuity.

For positive f∈L¹∩L², compact truncations converge in both norms. The L¹ difference contraction is uniform in time, while the L² contraction identifies the limiting flow with the original Hilbert flow. Conservation and strong L¹ continuity pass to this limit. Finally approximate any positive L¹ datum by positive L¹∩L² data. The L¹ contraction produces a unique uniform-on-bounded-time limit; the semigroup law, order, amplitude homogeneity, conservation and strong L¹ continuity pass through that limit. This is the claimed positive L¹ semigroup extension. No global finite weighted flux, H¹-from-time-zero assertion, or bound (10) is claimed for every pure L¹ datum. Zero input gives the zero trajectory; T=0 makes the time integrals zero; α=0 is excluded from (10).

## S5. Linearization and degeneration: exact directions

For each actual chosen flux in (5), define A=z zᵀ/a² where a=||∇u||₁>0, and A=I where a=0. Equations (6) imply
\[
 A\nabla u=z,\qquad 0\le A\le nI.                             \tag{11}
\]
Thus this trajectory solves u_t=div(A∇u). This is an own algebraic representation, not the smooth Hessian formula: A can have rank one and depends on the initial source and on the chosen flux. For general sources in dimensions n≥2, this representation supplies no positive uniform lower ellipticity. It supplies no source-independent transition kernel or superposition rule. Ohta–Sturm's smooth linearization also follows the solution gradient and requires its stated regularity; it does not remove these logical distinctions.

For H_p(v)=||v||_p, 1<p<2, direct differentiation at v=(1,…,1) gives
\[
 D^2(\tfrac12 H_p^2)
 =n^{2/p-1}\big[(p-1)I+(2-p)\mathbf1\mathbf1^\top/n\big].      \tag{12}
\]
The radial and transverse eigenvalues are respectively n^{2/p−1} and (p−1)n^{2/p−1}; their ratio is 1/(p−1). At a coordinate axis the transverse second difference quotient contains |h|^p/h² and is unbounded, so H_p² is not C² with a finite uniform upper Hessian bound there. Its dual q>2 has the complementary lower-Hessian degeneration. Formula (12) follows by differentiating (Σv_j^p)^{2/p}/2 on the positive orthant. These formulas explain exactly why a smooth uniform-ellipticity/Harnack estimate cannot be transferred to the crystalline limit with undeclared constants. The nonsmooth construction S2–S4 does not require that transfer.

## S6. Three-stage executed checks and actual scope

The pivotal new check is the projection premise (3) on actual positive compact H¹ sources, followed by exact matrix/flux checks. Use the genuine tent h(x)=(1−||x||∞)_+. Direct shell integration gives
\[
 \int h=2^n/(n+1),\quad
 \int h^2=2^{n+1}/[(n+1)(n+2)],\quad
 \int\|\nabla h\|_1^2=2^n.
\]
Its gradient has one nonzero coordinate almost everywhere. For (u,v)=(a h,b h), a,b∈{(3,1),(1,3),(2,2)}, the order projection energies are exact. For an L∞ difference band α, the active cube has radius (1−α/|a−b|)_+; its volume is 2^n times that radius to the n-th power. Pair energy decreases by |a−b|² times this volume divided by 4. These are actual full-Lebesgue integrals of compact functions, not point sampling or a nonlinear PDE run.

| Stage | Dimensions | Positive source pairs | Band projections | Exact assertions |
|---|---:|---:|---:|---:|
| Pilot | 2,3 | 6 | 18 | 86 |
| Known-condition pressure | 5,8 | 6 | 18 | 86 |
| Expanded | 16,32 | 6 | 18 | 86 |
| Total | six dimensions | 18 | 54 | 258 |

The balanced Hessian check constructs every normalized matrix entry and verifies its action on the all-ones vector and (1,−1,0,…), with eigenvalues 1 and 1/(q−1), at q=2,n²,n³. The flux check constructs v=e₁, z=(1,…,1) and A=zzᵀ/||v||₁², verifies the subgradient/Fenchel identity, ||z||₂²=n||v||₁², and Av=z. Execution used exact Fraction arithmetic, wall 0.03794691699931718 seconds measured inside the author run. This is an author execution receipt; independent auditor replay must be reported separately. The deliberately repeated dimensions/source cases are checks, not 258 independent theorems. The full proofs S2–S5 establish arbitrary-datum claims; these finite checks do not establish them.

```python
from fractions import Fraction as Q
import time
s=time.perf_counter(); count=0; physical=0; bands=0
for stage, ns in [('pilot',(2,3)),('pressure',(5,8)),('expanded',(16,32))]:
 c0=count;p0=physical;b0=bands
 for n in ns:
  vol=Q(2**n); mass=vol/Q(n+1); l2=2*vol/Q((n+1)*(n+2)); energy=vol/2
  assert mass>0 and l2>0 and energy>0;count+=1
  for a,b in [(Q(3),Q(1)),(Q(1),Q(3)),(Q(2),Q(2))]:
   physical+=1; before=(a*a+b*b)*energy
   pa,pb=((a+b)/2,)*2 if a>b else (a,b)
   after=(pa*pa+pb*pb)*energy
   assert after<=before;count+=1
   for alpha in [Q(1,4),Q(1),Q(4)]:
    delta=abs(a-b); radius=max(Q(0),1-alpha/delta) if delta else Q(0)
    active=vol*radius**n; drop=delta*delta*active/4
    assert 0<=before-drop<=before;count+=1;bands+=1
   for q in [2,n*n,n**3]:
    p=Q(q,q-1); transverse=p-1
    matrix=[[(p-1)*int(i==j)+(2-p)/n for j in range(n)] for i in range(n)]
    assert all(sum(row)==1 for row in matrix);count+=1
    tangent=[Q(1),Q(-1)]+[Q(0)]*(n-2)
    assert all(sum(matrix[i][j]*tangent[j] for j in range(n))==transverse*tangent[i] for i in range(n));count+=1
    assert transverse>0 and 1/transverse==q-1;count+=1
  v=[Q(1)]+[Q(0)]*(n-1);z=[Q(1)]*n; norm1=sum(abs(x) for x in v)
  dot=sum(z[i]*v[i] for i in range(n))
  assert dot==norm1**2 and norm1**2/2+max(abs(x) for x in z)**2/2-dot==0;count+=1
  assert sum(x*x for x in z)==n*norm1**2;count+=1
  actual_A=[[z[i]*z[j]/norm1**2 for j in range(n)] for i in range(n)]
  assert all(sum(actual_A[i][j]*v[j] for j in range(n))==z[i] for i in range(n));count+=1
 print(stage,'dimensions',ns,'assertions',count-c0,'physical_pairs',physical-p0,'band_projections',bands-b0)
print('TOTAL',count,'physical_pairs',physical,'band_projections',bands,'wall',time.perf_counter()-s)
```

Three-stage applicability boundary: first the exact energy and projection hypotheses hold for all H¹ functions; second the flux and compact weighted mass arguments apply to genuine positive L¹∩L² sources and then pass by L¹ approximation; third the requested weak maximal/cube comparison remains a separate unpaid assertion. Neither one explicit Gaussian, fixed-time contraction, nor the source-dependent matrix (11) meets that last requirement. No original hard/smooth/coarse gate is inherited by this evolution.

## Public result and exact unpaid assertion

Let
\[
 \mathcal E_H(v)=\frac12\int_{\mathbb R^n}H(\nabla v)^2\,dx,
 \qquad \partial_tu+\partial_{L^2}\mathcal E_H(u)\ni0,
\]
where `H` is a norm, the integral functional is proper, lower semicontinuous and convex, and `S_t` denotes its unique gradient flow, extended to nonnegative `L¹` data when that extension has been proved. The current candidate is `H_n=||·||₁`, or specified smooth approximations; all anisotropy and approximation constants must be included in the final `K_n`. The desired maximal assertion is
\[
 |\{x:\sup_{t>0}S_tf(x)>\lambda\}|
 \le K_n\frac{\|f\|_1}{\lambda}
 \quad(f\ge0,\ f\in L^1,\ \lambda>0),\qquad K_n=n^{o(1)}.
 \tag{NM}
\]
The supremum uses a jointly measurable representative continuous in time for almost every receiver, or an explicitly declared temporal essential supremum. Fixed-time order preservation, complete accretivity, homogeneity and conservation have not proved (NM). No proof or qualified counterexample to (NM) for the full stated energy class is obtained here. A general cube-to-actual-flow comparison is a separate unpaid assertion.

**Conservation forbids an unpaid sum or Jensen step.** Suppose `T:L¹₊→L¹₊` preserves integrals. If, for every nonnegative `f,g`, either
\[
 T(f+g)\le Tf+Tg
 \quad\hbox{or}\quad T(f+g)\ge Tf+Tg
\]
holds in one fixed direction, then equality holds. Indeed, the nonnegative difference has integral zero. If `T` is also positively homogeneous, this makes it additive on the positive cone and gives a unique positive linear extension by `L(f-g)=Tf-Tg`; additivity makes this definition independent of the representation, and positivity plus conservation gives its `L¹` contraction. The same zero-integral argument makes any universal one-sided Jensen inequality an equality. Consequently these extra hypotheses cannot be added for free to a genuinely nonlinear conservative flow.

**Two valid finite-window replacements.** Let `u(t,x)≥0` be jointly measurable and `∫u(t)≤M` for almost every time. For `0<δ≤R<∞`,
\[
 \left\|\sup_{\delta\le T\le R}\frac1T\int_0^Tu(t)\,dt\right\|_1
 \le M\bigl(1+\log(R/\delta)\bigr).
 \tag{FW-A}
\]
For each `T` in the window, its average is bounded pointwise by
\[
 \delta^{-1}\int_0^\delta u(t)\,dt+
 \int_\delta^R\frac{u(t)}t\,dt;
\]
Tonelli proves (FW-A). This requires no semigroup, kernel, or linearity.

If additionally `u∈W^{1,1}([δ,R];L¹)` and `∫u(t)=M`, its pointwise absolutely continuous representative satisfies
\[
 \left\|\sup_{\delta\le t\le R}u(t)\right\|_1
 \le M+\frac12\int_\delta^R\|\partial_tu(t)\|_1\,dt.
 \tag{FW-S}
\]
Use `sup_t u(t,x)≤u(δ,x)+∫(∂_t u)_+dt`, followed by `∫∂_tu=0`. Both give weak (1,1) bounds with their displayed fees by Chebyshev. Neither bound is uniform as the time window exhausts `(0,∞)`; mass conservation alone supplies no summability across windows. Thus these are usable, fully paid replacements only when the time window or an additional variation budget is part of the theorem.

**Dimension-free `L²` action and orbit discrepancy.** Let `E:L²(X)→[0,∞]` be proper, lower semicontinuous and convex, with dense domain, `E(0)=0`, and `E(cv)=c²E(v)` for `c>0`. Let `u(t)=S_tf` be its `L²` subgradient flow with strong initial trace `f∈L²`. Assume the usual strong positive-time solution formulation: `u` is locally absolutely continuous in `L²` on `(0,∞)`, `−u_t∈∂E(u)` almost everywhere, and the convex energy chain rule holds. These are stated solution assumptions, not an assertion about an unconstructed `L¹` extension. Then
\[
 \int_0^\infty t\|u_t(t)\|_2^2\,dt
 =\frac{\|f\|_2^2-\lim_{t\to\infty}\|u(t)\|_2^2}{4}
 \le\frac{\|f\|_2^2}{4}.
 \tag{L2-A}
\]
Indeed, scaling in the subgradient inequality gives `⟨ξ,u⟩=2E(u)`. Thus
\[
 \frac d{dt}\|u(t)\|_2^2=-4E(u(t)),\qquad
 \frac d{dt}E(u(t))=-\|u_t(t)\|_2^2.
\]
Integrating the first identity from positive time and using the strong `L²` initial trace shows `∫₀^∞E(u(t))dt=(||f||₂²−lim||u(t)||₂²)/4`. The energy is nonincreasing, nonnegative and integrable. Hence `tE(u(t))→0` at both endpoints: at zero use `tE(t)≤∫₀^tE`, and at infinity use `(t/2)E(t)≤∫_{t/2}^tE`. Integrating `−tE'(t)` by parts proves (L2-A), including when `f` has infinite initial energy.

Put `A_tf=t⁻¹∫₀^tS_sf ds` and `R*f=sup_{t>0}|S_tf−A_tf|`. Then
\[
 \|R^*f\|_2\le\frac{\|f\|_2}{2\sqrt2}.
 \tag{L2-R}
\]
For the zero-time justification, first integrate by parts on `[ε,t]` in Bochner `L²`. The term `εu(ε)` tends to zero in `L²`, while `∫₀^t s u_s ds` converges in `L²` by (L2-A) and weighted Cauchy–Schwarz. Thus
\[
 u(t)-A_tf=\frac1t\int_0^t s u_s(s)\,ds
\]
holds in `L²`. Choose the common version first at positive rational times. Positive-time local `L²` absolute continuity and Fubini provide a pointwise locally absolutely continuous representative there. On an infinite-measure space the required integrability near zero follows explicitly from
\[
 \left\|\int_0^T|u(s,\cdot)|\,ds\right\|_2^2
 \le T\int_0^T\|u(s)\|_2^2\,ds\le T^2\|f\|_2^2;
\]
thus `∫₀^T|u(s,x)|ds<∞` almost everywhere without any spatial `L¹` assumption. The identity therefore extends to all positive times, without requiring a pointwise initial trace. Pointwise Cauchy–Schwarz now gives
\[
 (R^*f(x))^2\le\frac12\int_0^\infty s|u_s(s,x)|^2\,ds.
\]
Tonelli and (L2-A) prove (L2-R). This is an energy proof; it uses no linear spectral or Poisson–Gamma identity.

Even **conditionally** granting an orbit-average weak bound `|{A*f>λ}|≤K_n||f||₁/λ`, this gives for `f≥0` in `L¹∩L²` only
\[
 |\{S^*f>\lambda\}|
 \le\frac{K_n\|f\|_1}{(1-\theta)\lambda}
       +\frac{\|f\|_2^2}{8\theta^2\lambda^2},
 \quad 0<\theta<1.
 \tag{L2-M}
\]
This follows from `S*f≤A*f+R*f`. The second term is not a uniform `L¹` budget. The exact good/bad and linearization obstructions are analyzed privately below; (NM) remains unpaid.

本轮是一般方法的真实来源压力与校准，不是新的一般维数估计。七个输入都是正、紧支撑 L1 密度。源点、接收点、帽和全部尺度使用原连续空间；固定一个来源限制，不能按接收点或尺度重新挑选。我们分别比较原来源的整块费用与实际部分捕获、参考抵消后的两种费用，以及实际来源—目标耦合的深度对数代理。它们不是同一个量，不能相互偷换。

固定 kappa=1、theta=1/6。原参考是每个单位坏块 Q 上的常数平均 sigma=f(Q)/|Q|<=1/2，帽是 ONE union of (1+1/n)Q。定义 b=(f-sigma)_+、c=(sigma-f)_+。后文另有 epsilon=1/n 的移动参考；它与这个半高度参考独立。

关键判别是：背景抵消可修复许多原整块费用，但还不够。边界混合输入在抵消以后仍有宽正剩余，整块系统因其很小的边界净空拒绝大部分质量；实际部分捕获却给同一个 g=b 的全部外部接收点、全部尺度证书。这个结论只针对本有限输入类，不是一般小残余定理。其真实外部超额能量在所列例子中为零，因此也不是原 Fnew 高负载证据。

## 三阶段、输入及准确单位

1. 初探校准：n=2，f=(1/4)1_Q+(1/4)Unif(C)，中心峰半宽 1/32。
2. 压力：n=2 把中心峰半宽固定为 1/2048；n=4 使用三个重叠中心峰，质量 1/8、1/16、1/16，半宽 1/32、1/128、1/512；另在 n=4 执行边界混合输入。
3. 扩大参数：n=8 的一个边界块；n=16、64 的三个不等质量边界块，其第一坐标中心为 0、4、8，权重 gamma=3/4、1、7/8。

中心校准均取 Q=[-1/2,1/2]^n、W=1/2。边界块定义

```text
P=[-1/4,1/2] times [-1/2,1/2]^(n-1), |P|=3/4,
C=[-e,e]^n, e=1/(16n), C subset P,
f = (1/4)1_Q + (7/32)Unif(P) + (1/32)Unif(C).
```

多簇把整段实际密度乘 gamma 并平移，所有源支撑与帽彼此分离。没有把不同簇分别领取一个新的 kappa。每个块的平均为 gamma/2，始终严格大于 1/4 且不超过 1/2。

正式冻结菜单含 7 个来源—维数组合，11 个原来源块、11 个真正正体积接收盒、1198 个原来源及正剩余的非空源子集约束，以及 696 个完整 2n 维来源—目标矩形。九个原来源分量的多簇问题确实检查 511 个子集；六个正剩余分量检查 63 个子集。没有把有限子集数冒充连续接收点数。源码第一次实现检查在第六例的多簇对偶分组断言处停止、未写正式结果；按实际块修正分组后完成七例，并为质量账及明确密度前提执行了两次同菜单完整生产检查。均未增加新来源；最终执行收据以下文冻结运行为准。

## 同一帽与原块资格

单位 Q 在兼容的平移循环二分格中是最大坏块：其直接父块平均不超过 1/4。中心输入只有一个原块。多簇的单位块中心间距 4；若一个 proper cyclic ancestor 的第一坐标宽度是 1 或 2，至多含一个来源块，体积至少 2，所以平均不超过 1/4。若宽度 A>=4，A 为二进幂，兼容网格的区间最多含 A/4 个来源块；质量不超过 A/8。循环长宽比不超过 2，故体积至少 A*(A/2)^(n-1)，平均仍不超过 1/4。来源在这些块之外为零。原标签 ell_Q=1 不随拆分改变。

取 r=(1+1/n)/2。各帽是源块中心平移的 [-r,r]^n；间距 4 大于其直径，所以帽没有重叠，全空间帽体积恰为 K*(1+1/n)^n。多簇的 W=(1/2)sum gamma，不能把它改成单簇质量。原参考各块密度 gamma/2，支撑不相交，所以同一个 sigma<=1/2，且总质量与 f 完全相同。

## 1. 整块系统与实际部分捕获

对非负测度分解 nu=sum mu_j，质量 m_j，选择固定 0<=x_j<=m_j，令 g=sum (x_j/m_j)mu_j。这些密度分解即使支撑重叠，也精确加回同一物理 nu；不是重复领取来源质量。

实际捕获分数是 q_j(x,L)=mu_j(Q(x,L))/m_j。真实安全条件为

```text
sum_j x_j*q_j(x,L) <= theta*L^n
for EVERY exterior receiver x and EVERY L>0.
```

既有整块外放松用支撑盒 S_j 和 doubled clearance a_j。令

```text
R(I)=max(max_{j in I} a_j,
         max_coordinate (max_{j in I} lower_j - min_{j in I} upper_j)_+).
```

并要求每个非空 I 有 sum_I x_j<=theta*R(I)^n。它是充分条件：实际捕获到的每块来源可选取一个源点；共同 exterior receiver 强迫 L>=a_j 和支撑间距不超过 L。所以 R(I)<=L，而捕获质量不超过整块保留质量 sum_I x_j。这一步给所有外部接收点和尺度、从而所有接收集合的安全分配，但将仅仅部分捕获的块按全部质量收费。

代码的 whole_piece 是这个有限外放松的精确最优值，不是原连续问题的精确 Hall 值。每个原块内支撑相互嵌套，R(I) 等于所选最大净空。按净空排序后的 prefix constraints 加来源质量上限，给精确贪心可行解。对每块取一个 prefix cut 加余下分量的质量上限，就是对应对偶上界。组合这些真实块的对偶，每个来源仅计一次；共同候选再精确核对全部跨簇子集约束。可行值与对偶值相等，才称整块最优值。

实际问题的上界来自不超过 nu 总质量的平凡质量对偶。若 g=nu 确实外部安全，就得到实际保留量最优值等于 nu 的全部质量；这里并非解一个采样 LP。如果只找到一个安全限制，代码返回其质量下界与 nu 总质量上界，不声称最优。

## 2. 中心校准的全接收、全尺度证书

对均匀中心立方体，单坐标捕获随 |x_i| 不增。正混合各分量具有相同性质。帽外至少一条坐标绝对值大于 r；把该坐标减至 r、其余坐标减至零，只会增大捕获。因此 exterior supremum 由面中心的外侧极限 (r,0,...,0) 给出；它不是在闭帽外声称已取到最大值。

在该边界点，背景在 L<1 的平均是

```text
m_bg*(1/2-(r-1/2)/L), once L>=2(r-1/2).
```

每个峰的初始捕获尺度为 2(r-e)。本菜单严格保证 e<1/(2n)，因而它的所有横向坐标在初始轴向捕获前已经饱和。L>=1 的总平均在每个物理区间为 (a*L+b)/L^n。它的唯一非端点临界候选是

```text
Lcritical = -n*b / ((n-1)*a), when a is nonzero.
```

程序包含全部开始捕获、横向饱和、完全捕获折点，核对每段端点和属于该段的精确临界点。最后完全捕获尾是 W/L^n，严格下降至零。早段 a+b/L 的单调性同样显式使用。没有浮点找根，也没有把任意高次多项式根假装为有理数。这个化简只用于所声明的中心盒类。

三个中心校准输入的原来源 g=f 全部通过 theta 安全判据，实际原来源保留最优值均为 W=1/2。原整块系统分别只能保留 7/24、7/24、约 0.25065104。原背景损失并不能直接算作新一般改进：参考预抵消已经去掉这些平背景。正剩余在这些中心例中，整块系统也能全部保留，二者残余都为零。这里校准了算法，没有把易例当作主结果。

中心最大峰 C0 上的最外层密度已经严格大于 1，源码直接核对最大的单峰质量除以 |C0| 再加 1/4。于是

```text
b = sum peak densities - (1/4)1_C0,
c = (1/4)1_(Q outside C0),
|b|=|c|=1/4-(1/4)|C0|.
```

把外峰质量减去 |C0|/4 后，b 是正的嵌套均匀盒混合，不用把负系数当正来源。Q outside C0 按首个离开 C0 的坐标分为 2n 个不重叠矩形；精确验证其总体积和不交性。

## 3. 预抵消后仍需要部分捕获的边界压力

边界混合的参考是 sigma=(1/2)1_Q。P 上背景加宽分量的密度为 13/24，大于 1/2；P 外为 1/4。因此精确分解是

```text
b=(1/24)1_P + (1/32)Unif(C),
c=(1/4)1_(Q outside P),
|b|=|c|=1/16.
```

权重 gamma 同时乘在三个密度上，不改变这些恒等式。宽正剩余的双倍净空是 1/n，峰的双倍净空是 a=2(r-e)。整块系统给宽部分很小的 theta/n^n 上限，即使它在短尺度只被捕获一小片。

实际分配固定取 g=b。所有 P 位于不同原块，故宽剩余在整个空间的总密度不超过 1/24，它的任何平均同样不超过 1/24。峰的部分捕获用真实共同几何区分：

* 若只捕获一个峰，outside the ONE cap union 意味着 L>=a，因此峰平均不超过最大峰质量除以 a^n。
* 若捕获至少两个峰，其第一坐标中心间距至少 4，源点距离至少 4-2e，所以 L>=4-2e；总捕获峰质量不超过所有峰的真实质量之和。

于是所有外部接收点和所有尺度都有

```text
A_L b <= 1/24 + max(max_peak_mass/a^n,
                    total_peak_mass/(4-2e)^n).
```

单簇不使用第二项。所有菜单值用 Fraction 严格验证小于 1/6；六十四维上界约 0.05477105。g=b 是一个完成的共源限制，而非在不同接收点重新分配。因此正剩余实际最优保留量等于全部 B；固定整块程序仍留下正残余。

以下小数仅为精确 Fraction 结果的近似显示。

|边界压力|n|原块数|W|半参考正剩余 B|整块保留 b|实际保留 b|
|---|---:|---:|---:|---:|---:|---:|
|单块|4|1|1/2|1/16|约 0.03190104|1/16|
|单块|8|1|1/2|1/16|约 0.03125001|1/16|
|不等质量多簇|16|3|21/16|21/128|约 0.08203125|21/128|
|不等质量多簇|64|3|21/16|21/128|约 0.08203125|21/128|

后二行整块值的精确形式是 sum gamma/32 + 3/(6*n^n)，略大于显示的第一项，不能把微小有理增量舍弃。source intervals 所有尺寸仍是真实 n 维尺寸。整块每个宽块的质量上限、源子集上界与保留量均在 JSON 中明确保存。

原来源 raw actual 仅给可行下界，未声称最优：保留全部峰，把原背景与宽分量共同乘

```text
alpha=min(1,(theta-peak_bound)/(13/24)).
```

不同块支撑不交，所以原宽总密度乘 alpha 后不超过 alpha*13/24。加同一个真实峰上界即不超过 theta。实际 raw safe 质量下界在六十四维三簇例约为 0.43086865；上界仍为 W=1.3125。原整块最优保留质量仅约 0.08203125。这个区间不是 raw continuous optimum 的数值解。

这些边界例还满足 A_L f=A_L sigma+A_L b-A_L c<=1/2+1/6 outside cap，故原 kappa 超额能量为零。这只证明本菜单来源的外部安全；一般来源的 positive surplus 不能免费继承本密度/峰间距假设。

## 4. 实际参考耦合及深度对数代理

在每个原块上构造真正测度

```text
pi_Q = diagonal pushforward of min(f,sigma) dy
       + b(y)c(z)/B_Q dy dz.
```

源边际为 min(f,sigma)+b=f；目标边际为 min(f,sigma)+c=sigma。产品部分源分量质量 m_i、目标分量质量 t_j 给共同权重 m_i*t_j/B_Q。代码逐行、逐列核对边际；identity plus product 的总质量为原 W。不是只检验两端总质量相等。旧参考块的对角密度与 b/c 的逐点恒等式由上述真实区域分解给出，矩形补集的覆盖、不交性和全维体积均精确验证。

记录的两种量是

```text
P0 = integral_pi log_+(4n*d_infty(y,z)/depth_Omega(y)),
P1 = integral_pi log_+(8n*d_infty(y,z)/depth_Omega(y)).
```

它们是实际耦合下真实几何对数函数的积分，被证明型区间包围。但它们只是外部占用量的深度对数上界代理，不是 coverage 新局部屏蔽定义的真实 M0/M1。程序没有计算真实 screened/exterior occupation，也没有把 P0/P1 的乘积称作一般能量定理。

将源和目标的第一坐标按预先固定的有理面分片，其余 n-1 个坐标保留完整物理区间。一个保存的片是完整的 S times T，维数为 2n，不是二维抽样。其权重用真实全维体积比例产生，全部 transverse normalization 已计算，未丢掉任何 n 维宽度。

每个源目标盒满足

```text
d_lower=max_coordinate interval-gap,
d_upper=max_coordinate far endpoint distance,
h_lower=r-max_coordinate far source distance from block center,
h_upper=r-max_coordinate nearest source distance from block center.
```

故 log_+(c*n*d_lower/h_upper) 与 log_+(c*n*d_upper/h_lower) 给整个联合盒的上下界。帽不相交且相隔正距离，所以 source inside its own cap 的深度恰是该帽内深度，使用的是同一个全局帽。源的 h_lower>0，全部对数有限；对角距离 d=0 的贡献严格为零。696 个联合矩形覆盖产品耦合的全部质量，没有遗留源目标尾。

六十四维多簇例的 P0 区间近似 [0.88762106,1.30681992]，P1 近似 [1.00015594,1.42053938]。这些粗代理仍为正，而另一条实际部分捕获证书已使半参考正剩余残余为零；这只是说明代理不等于必要费用，没有反驳一般代理上界，也没有证明一般占用费用增长。

## 5. 同一原输入的 epsilon 参考质量账

本轮额外记录 coverage 已审符号定义的输入账，不换原 f 或帽。固定 epsilon=1/n、v=1-epsilon，令

```text
a=min(f,v), e=(f-v)_+, t=(v-f)_+,
B_epsilon=integral e, D=integral t,
sigma_epsilon=a+(B_epsilon/D)t,
pi_epsilon=diagonal a + e(y)t(z)/D dy dz.
```

每块 |Q|=1，有 D=v-W_Q+B_epsilon>=B_epsilon，因为原平均 W_Q<=v。故 0<=B_epsilon/D<=1，target density 不超过 a+t=v，其质量严格等于 W_Q。产品部分来源边际是 e，目标边际是 (B_epsilon/D)t；不能错误使用分母 B_epsilon 而制造 D 的质量。

所有来源均按真正的常密度区域记录 rho、体积及 min/positive parts。中心多尺度输入使用嵌套壳层，边界输入使用 C、P outside C、Q outside P。源码逐项验证其体积和为 1、原质量为 W_Q、正尾/负尾质量、目标密度上界及目标总质量。

B0 在这个账中专指 integral(f-1)_+，不是固定半参考的 integral(f-sigma_half)_+。一般点态恒等比较为

```text
(f-(1-epsilon))_+ <= epsilon*f+(1-epsilon)*(f-1)_+,
B_epsilon <= epsilon*W+(1-epsilon)*B0.
```

f>=1 时两侧相等；f<1 时按 f 是否超过 1-epsilon 分两段验证，积分即可。程序在全部输入上也精确核对。这个已知比较仍保留 B0，不能把它丢弃而宣称只付 epsilon W。

六十四维多簇例保留的准确账为

```text
W=21/16,
B_at_fixed_sigma_half=21/128,
B0=21/256 - 101/(64*2^576),
B_epsilon=21/256 - 49/(32*2^576),
B_epsilon/(epsilon*W)=4-224/(3*2^576), strictly between 3 and 4.
```

所以提高参考以后，此例仍有明显的高密度尾需要支付；其很小的支持体积不能让真实源质量消失。这不是一般维数指数结论。移动参考的 near cutoff 应为 epsilon*L/(8n)，对应深度代理必须另含 1/epsilon；本程序没有计算它们。旧半参考 P0/P1、theta 安全分配及原门资格全部不转移到这个新参考。

## 6. 真正的 Lebesgue 接收与中心源交通

每个原块使用同一个物理中央区域 C0（中心校准取最大峰，边界输入取 C），不按查询改变 source set。令 h=1/(64n)，选择第二坐标的外面接收盒：第二坐标在 (r,r+h]，第一坐标在源中心加 [-h,h]，其余坐标在 [-h,h]。它是完整 n 维正体积盒

```text
V_receiver=h*(2h)^(n-1).
```

固定尺度 L=2(r+e_max+2h)。这个尺度使全部中央源被每个接收点完全捕获，全部背景横向坐标也饱和，只剩外面坐标的真实 partial overlap。多簇此尺度又严格小于捕获外国来源所需的尺度，源交通没有跨块误算。

设 A=L/2-r+1/2，外面接收偏移 u in (0,h]。中心校准原捕获质量是 m_peak+rho*(A-u)，其中 m_peak=1/4、rho=1/4。边界输入为 gamma*[1/32+(15/32)(A-u)]。积分 u 并乘其余 n-1 个宽度，给完整原平均交通；正剩余平均交通单独计算，二者不混。

中央物理质量明确包括背景，而非只取峰标签：边界例

```text
mu_f(C)=gamma*[1/32+(13/24)*(2e)^n],
mu_b(C)=gamma*[1/32+(1/24)*(2e)^n].
```

它们乘 V_receiver/L^n 就是实际原来源与正剩余的中央交通。对 y in C，真实来源列 integral_receiver L^(-n)1_capture dx 恰为 V_receiver/L^n。捕获后验的中央平均份额还按原 mu_f(Q(x,L)) 归一，解析积分为一个对数比值；保存其严格区间。没有来源坐标后验独立性假设。

这些盒很小，尤其六十四维接收体积为 2^-705；没有把它除掉后宣称大体积、高负载、原 first-contact 选择器或原 Fnew 资格。这里是共同吸收分配的真实交通核验，不是指定 Hall row demands 的运输最优性证书。

## 7. 数值误差、成功范围与未解项

所有几何、源质量、LP 可行/对偶残差、中心临界尺度、帽体积、moving-reference density 账使用 Fraction。对数用 128 位整数向外取整的 atanh 正级数 60 项，归一化参数不超过 1/3；统一余项上界为

```text
(2/121)*(1/3)^121/(1-1/9).
```

负整数倍 log(2) 正确交换端点；最后向外舍入到 64 位。只有展示小数与计时用浮点。区间跨过阈值不视作通过。本程序不要求通用浮点区间 API 已验证。

本轮成功的是特定来源的 common all-receiver/all-scale feasible allocation 及精确质量比较：中心输入给全来源安全校准，边界输入说明 pre-cancellation 后仍要保留 actual partial capture，多簇输入保留实际单帽和源目标边际。未得到一般 small surplus residual、root-order weak bound、真正 screened M0/M1、小交通核必要费用、非线性 PDE 桥或原 joint gates。

## 复现和冻结

```text
python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round098_20261012/numeric_probe.py
```

标准库、自包含；不写其他角色文件、不导入旧轮、不操作 Git。最终真实运行 0.264656458 秒，结果 259191 字节。JSON 不保存波动计时，可逐字节重放。子集与联合盒见证使用 base85(zlib(compact JSON))，记录数和 SHA256 全部保存；coordinate_runs 明确记录维数、每段坐标索引及真实体积，保持全部 n 维宽度。

代码 SHA256：`107d9aa088caff2322a973ea9c662d55dd7b86ad943c6988016f918ad88e3eea`。
结果 SHA256：`1d0acd33112a028e1c775c844fb764543729748a086fc2a4adf559c4ac448310`。

A covariance-based continuous-process estimate now certifies the joint selected-gate exclusion in the fixed numerical model. The argument retains the actual earliest selector and all tail, source and likelihood costs. Remaining residual qualification and the general weak-type bound are still open.

## 独立 Astra 审核

本轮五个理论模块均完成 Markdown 与详细 TeX 全文独立审核；公开数值报告、程序及全部结果，私人原门程序的完整证明与冻结实现也已核验。审查先检查准确命题、量词和可能反例，再阅读作者证明。审计没有把作者的 PASS 当作证明，也没有把条件性接口或有限输入成功当作一般端点。

共同参考的质量守恒、逐点高度和一个共同帽的全尺度费用成立；一般高密度尾和实际接收门的占用乘积仍未支付。固定捕获质量变换的推送密度方向已核对，其中容量传输须限制在有限需求域，不能使用全空间无限需求下的空假设。晶体演化的解类、通量、质量与正 L1 延拓通过审核，但多来源立方体比较及全时间弱型预算未完成。新的 L2 加权作用量及轨道—平均差估计成立；它们尚不能无费转成一般 L1 或两解差的预算。

公开数值采用七个正 L1 输入、真实全维接收盒及来源—目标矩形。整块充分放松的最优值、实际部分捕获证书和未加筛选的对数代理分别保留其范围。新参考仅有其单独验证的质量与密度账，旧参考的代理量不自动转移。原固定模型的联合原门排除证书严格保留最早接触、同一来源和概率转换；没有把被排除的子集误记成满足粗门的余集，未知补集没有计零。

本审计实际隔离重放了各模块注明的程序。公开数值最终 JSON 逐字一致，不排除字段；私人过程程序仅排除明确列出的计时字段。重放不增加来源数，也不是独立算法重构或一般 PDE 求解。另一审计者的公开守卫由本审计全文审读并独立核对径向矩，但本审计没有运行该守卫。原文阅读范围沿用各作者明确的来源记录，不声称独立重读全部引文。一般目标仍为 UNPROVED；私人构造和定量方法障碍不进入本公开摘要。

## Independent R98 audit

Statement-first screens and full Markdown/TeX mathematical reviews passed in the stated scopes. The genuine crystalline flow's existence contract, positive contraction, measurable flux, whole-space mass conservation and L1 extension are established with their declared external generation/projection dependencies. The new dimension-free L2 orbit-discrepancy result retains energy endpoints and time representatives. It does not pay the arbitrary-amplitude L1 residual or nonlinear weak maximal budget; a generic pair-action shortcut fails only in its qualified abstract nonlocal class.

The common epsilon reference preserves the original mass and pays one cap plus an explicit high-density-tail/occupation product. That general product remains unpaid. Actual screened exterior moments, depth-log upper proxies and receiver-gated moments are distinct. Fixed-mass transport keeps the correct pushforward normalization and all noise/graph/threshold costs; nongated physical diagnostics do not refute the original common-column conjecture.

The private covariance program now certifies a SAME-input joint selected-gate exclusion at the original earliest contact. It retains full P1, source, infinite tail, covariance and likelihood costs. This certifies coarse HIGH, while the remaining coarse LOW/Fnew class and general capacity stay open. Replaying the program does not create a new physical source.

The NEW standalone guard reconstructs one genuine positive crystalline input in four dimensions by direct cubical-shell integration: whole-space initial L2 squared and the full continuous weighted time-derivative action. Their exact values are 1/2048 and 1/8192, attaining the one-quarter action bound. This is an independent physical integral, without author imports, stored-result algebra, a general PDE solver or prior-round tests. Its isolated run passed externally in 0.018291750 seconds.

The public numeric program has seven actual source-dimension instances, 11 true receiver boxes and 696 full source-target rectangles. Its same-cap/source allocations, exact primal/dual checks and geometric proxy brackets are finite certificates; it computes no true screened occupation or energy integral. All counts, author repetitions, auditor replays and independent reconstruction are separated. General C_n<=sqrt(n)n^{o(1)} remains unproved; no private recipes or unpublished quantified lower constructions are included here.

## 主代理审核与实际隔离复现

以下都是本轮实际执行结果。重放不增加来源数；有限输入、精确积分、浮点诊断和一般证明分开。两名审计先保存命题审查，再阅读作者证明；主代理另行检查完整数学正文和关键程序。

|模块|主代理隔离重放秒数|实际覆盖与边界|
|---|---:|---|
|numeric|0.251372708|7 个公开中性输入实例、11 个来源块；1198 个充分来源子割、696 个完整联合来源—目标矩形、11 个真实接收盒。全部结果字节一致，无排除字段。部分捕获和深度对数代理不冒充一般占用或能量。|
|phase|3.909655083|一个原固定来源；26 个连续单坐标过程围栏，15 个只读依赖。全部数学及描述 JSON 一致，只移除三个计时字段；原联合已选门排除成立，其他余集未知。|
|coverage|0.061326666|12 个正 L1 来源、36 个可调参考配置；512 个实际计算的外部体积分数积分单元（应用560次），496 个边际等式；JSON 除秒数和各阶段秒数外一致。没有计算接收能量。|
|adaptive|5.375104459|6 个有正勒贝格接收体积的来源实例，151 项精确检查。样例不满足原粗门；它们只检查一般传输前置命题。|
|alternative|0.028981166|12 个真实初值实例、36 个通量代数检查和36个时间屏障检查；精确阶段摘要一致，未进行一般非线性 PDE 数值求解。|
|sources|0.042899333|18 对正的紧支撑 H1 来源、54 个投影，258 项精确检查（86/86/86），包含实际矩阵—向量和通量关系。|
|nonlinear_maximal|0.154271375 / 0.010334792|两段独立浮点程序：11 个 Gamma 参数维数、8 个有限非局部模型参数；所有表格显示与实际输出一致。解析证明与浮点表分开，不声称区间证书。|
|独立公开审核程序|0.014744417|重新从径向积分构造一个 R4 中的真实 U1 初值，完整空间 L2 平方为1/2048，完整时间加权导数作用量为1/8192；不导入作者程序，不检查已有结果代数。|

公开数值程序只依赖 Python 标准库。压缩包中的 numeric_probe.py 会在同目录生成 numeric_results.json；其公开来源、真正接收盒、常数密度区域和全部精确证书在结果中保留。独立审核代码位于 proof.md 的“独立公开审核程序”标题下。其结果来自单独重建，不算作对公开数值生产程序的独立算法复现。

文献核验保留已读范围：主代理另行查读 Cipriani–Grillo 作者稿第11–13页的投影判据、Markov 定理及格点条件的充分性证明，未把所引专著标成全文重读。相关适用条件和自证部分见 sources 模块。64项技能入口做当前字节快照，本轮只按需要阅读 A02、F04、N04 及各作者明确列出的技能和接口，不声称64项定理整体已验收。

完整一般结论仍为 UNPROVED。可调参考留下高密度尾质量；实际接收门留下占用乘积；软层留下原门共同列；非线性路线留下多来源比较、时间最大值及 L1 振幅／解差预算。归档只包含公开区域与必要中性复现材料，私人程序、配方和未公开定量方法下界不在包内。LaTeX 不编译 PDF；最终静态检查与归档重放另有回执。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""R98 independent actual crystalline-flow space/time integral, stdlib only.
One genuine positive L1/L2 source in R4. No author imports, saved data,
point sampling, general PDE solver or weak-maximal conclusion.
"""
from fractions import Fraction as F
from math import factorial
import json


def gaussian_radial_moment(power, denominator):
    # Integral_0^infinity r^(2k+1) exp(-r^2/denominator) dr
    # follows by z=r^2/denominator and k integrations by parts.
    assert power >= 1 and power % 2 == 1
    k = (power-1)//2
    return F(factorial(k),2)*denominator**(k+1)


def reconstruct():
    n=4
    shell=n*2**n
    # Actual profile f=U_1: exp(-||x||inf^2/4)/512, mass one.
    normalization=shell*gaussian_radial_moment(3,F(4))
    amplitude=1/normalization
    mass=amplitude*normalization
    initial_l2=shell*amplitude**2*gaussian_radial_moment(3,F(2))
    assert mass==1 and amplitude==F(1,512)
    # U_s derivative is U_s*(r^2/(4s)-2)/s.
    # Integrate its SQUARE over all actual R4 receivers at s=1.
    derivative_coefficient=shell*amplitude**2*(
        gaussian_radial_moment(7,F(2))/16
        -gaussian_radial_moment(5,F(2))
        +4*gaussian_radial_moment(3,F(2)))
    assert derivative_coefficient==F(3,4096)
    # Spatial dilation r=sqrt(s)*v proves ||d_s U_s||2^2=coef*s^-4.
    # The actual initial datum is f=U_1, its orbit is u(t)=U_(1+t).
    # Integral_0^infinity t/(1+t)^4 dt = 1/2-1/3 = 1/6.
    time_integral=F(1,2)-F(1,3)
    weighted_action=derivative_coefficient*time_integral
    assert initial_l2==F(1,2048)
    assert weighted_action==F(1,8192)==initial_l2/4
    return dict(scope='ONE actual positive crystalline Gaussian input in R4; full spatial L2 and full continuous time-weighted derivative action',
                physical_inputs=1, initial_full_space_l2_integrals=1,
                continuous_full_space_time_action_integrals=1,
                source_mass=str(mass), profile_amplitude=str(amplitude),
                initial_l2_squared=str(initial_l2),
                derivative_l2_squared_coefficient=str(derivative_coefficient),
                derivative_time_law='coefficient*(1+t)^(-4)',
                weighted_action=str(weighted_action),
                two_homogeneous_action_upper_is_attained=True,
                author_program_reconstructions=0, saved_arithmetic_checks=0,
                general_weak_maximal_bound='UNPROVED')


if __name__=='__main__':
    print(json.dumps(reconstruct(),sort_keys=True))
```
