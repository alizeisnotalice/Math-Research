"""Replay R150 from archived inputs, then run independent rational verification."""
from pathlib import Path
import argparse,json,zipfile,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--rounds',required=True,type=Path);ap.add_argument('--destination',required=True,type=Path);a=ap.parse_args();rounds=a.rounds.resolve();dst=a.destination.resolve();dst.mkdir(parents=True,exist_ok=False)
for n,member,rel in [(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json')]:
 with zipfile.ZipFile(rounds/str(n)/'research.zip') as z:
  p=dst/'inputs'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(member))
for name in ['mass_scan.py','numeric_plan.md','mass_verify.py']:shutil.copy2(ROOT/name,dst/name)
subprocess.run([sys.executable,str(dst/'mass_scan.py'),'--input-root',str(dst/'inputs'),'--stage','all'],check=True)
def norm(v):
 if isinstance(v,dict):return {k:norm(x) for k,x in v.items() if k!='elapsed_seconds'}
 if isinstance(v,list):return list(map(norm,v))
 return v
assert norm(json.loads((dst/'mass_scan.json').read_text()))==norm(json.loads((ROOT/'mass_scan.json').read_text()))
print('VERIFIED all 1210 producer rows and point diagnostics; elapsed_seconds alone excluded',flush=True)
r=subprocess.run([sys.executable,str(dst/'mass_verify.py'),'--input-root',str(dst/'inputs'),'--certificate',str(dst/'mass_scan.json'),'--profile-certificate',str(dst/'numeric_profile_certificate.json')],check=True,capture_output=True,text=True)
v=json.loads(r.stdout);assert v['status']=='PASS';(dst/'verification.json').write_text(r.stdout);print(r.stdout)
print('PASS fresh producer and independent verifier')

assert json.loads((dst/'numeric_profile_certificate.json').read_text())['records']==json.loads((ROOT/'numeric_profile_certificate.json').read_text())['records']
print('PASS exact original FA integral certificates')
