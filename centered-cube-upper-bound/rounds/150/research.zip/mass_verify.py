#!/usr/bin/env python3
"""Independent rational R150 mass/profile verifier, never imports mass_scan.
The frozen 70-digit true-kernel model is necessary-only, not FULL/dx certified.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,hashlib,sys
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent

def f(x):
    return F(int(x['numerator']),int(x['denominator'])) if isinstance(x,dict) else F(str(x))
def contains(iv,x): assert f(iv[0])<=x<=f(iv[1]),('interval misses exact value',iv)
def mass_state(c,rc,a,b,cc):
    nu0=list(map(f,rc['nu_exact']));raw=[nu0[i]*F(2)**(a if i<3 else b if i==3 else cc if i==5 else 0) for i in range(6)];nu=[z/sum(raw) for z in raw]
    ker=next(x for x in rc['verifications'] if x['id']==0 and x['distribution']=='control')
    p=f(ker['p']);k0=list(map(f,ker['K0']));qv=[sum(f(ker[z][i]) for z in ['K1','K2','J'])/3 for i in range(6)];j=list(map(f,ker['J']))
    q0=sum(nu[i]*k0[i] for i in range(6));qj=sum(nu[i]*j[i] for i in range(6));qs=sum(nu[i]*qv[i] for i in range(6));q=max(q0,qj,qs)
    ats=c['atoms'];par=c['parameters'];der=c['derived'];K=f(par['K']);D=f(par['D']);T=f(der['T'])
    good=[p*f(at['wg'])<=K*qv[i] for i,at in enumerate(ats)];E=[good[i] and f(at['A'])>0 for i,at in enumerate(ats)]
    U=[min(T*f(at['A']),D*k0[i]) if E[i] else F(0) for i,at in enumerate(ats)];alpha=(D*q-sum(nu[i]*U[i] for i in range(6)))/qj
    rho=[max(F(0),1-(U[i]+alpha*j[i])/(T*f(at['A']))) if E[i] else F(0) for i,at in enumerate(ats)]
    eg=sum(nu[i]*f(at['wg']) for i,at in enumerate(ats));mu=[qv[i]*nu[i]/q for i in range(6)]
    hard=sum(nu[i] for i,at in enumerate(ats) if all(abs(f(z))<=f(par['b'])/2 for z in at['position']))
    gates=dict(lambda_identity=True,hard_positive=hard>0,hard_cap=hard<=4*q,high=p*eg>=2*K*q,heavy=eg>f(der['ell'])*f(der['cj'])**(-c['n']//2)*f(der['g'])**c['n']*q,qJ_positive=qj>0,alpha_nonnegative=alpha>=0,FIRST_three=True,Hhat_less_Lplus=f(der['Hhat'])<f(der['Lplus']))
    for z in ['strict_s','scale','tau_h_g']:gates[z]=c['gates'][z]
    first=[None]*6;firstw=[F(0)]*6;caps=[];loeta=[F(0)]*6;upeta=[F(0)]*6;jointlo=[F(0)]*6
    names=[at['name'] for at in ats];psi={(names.index(z['v']),names.index(z['z_prime'])):bool(z['Psi']) for z in c['pairs']}
    def profile(seg,t,v):
        ks=seg['k'];cs=list(map(f,seg['c']));e=sum(nu[i]*cs[i]*t**(-ks[i]) for i in range(6));kv=ks[v]
        S=sum(nu[u]*cs[u]*t**(-ks[u])*(1-F(ks[u],kv)) for u in range(6) if not good[u] and kv>ks[u]) if kv else F(0)
        return e,S,cs[v]*t**(-kv)
    for si,seg in enumerate(c['score_segments']):
        lo,hi=f(seg['lo']),f(seg['hi']);ks=seg['k'];cs=list(map(f,seg['c']))
        for v in range(6):
            elo,slo,_=profile(seg,lo,v);ehi,shi,_=profile(seg,hi,v)
            loeta[v]=max(loeta[v],eg*slo/elo**2,eg*shi/ehi**2);upeta[v]=max(upeta[v],eg*slo/ehi**2)
            for u in range(6):
                if not (good[v] and not good[u] and rho[v]>0 and psi[v,u] and ks[v]>ks[u]):continue
                delta=ks[v]-ks[u]
                if f(par['B_FA'])*delta*p*cs[v]<=qv[v]*lo**ks[v]:continue
                caps.append((si,v,u,lo,hi,delta))
                first[v]=lo if first[v] is None else min(first[v],lo)
                firstw[v]=max(firstw[v],cs[v]*lo**(-ks[v]))
                jointlo[v]=max(jointlo[v],2*(2*c['n']+3)*nu[v]*rho[v]*cs[v]*lo**(-ks[v])*slo/elo**2)
    N=2*c['n']+3;costlo=sum(2*N*nu[v]*rho[v]*firstw[v]/eg*loeta[v] for v in range(6));costup=sum(2*N*nu[v]*rho[v]*firstw[v]/eg*upeta[v] for v in range(6))
    return locals()

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--certificate',default=str(ROOT/'mass_scan.json'));ap.add_argument('--profile-certificate');ap.add_argument('--input-root',default='/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015');args=ap.parse_args();base=Path(args.input_root)
    sb=(base/'centered_cube_round136_20261014/active_traffic_v2.json').read_bytes();rb=(base/'centered_cube_round142_20261015/numeric_receiver.json').read_bytes();cert=Path(args.certificate).read_bytes()
    sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de';assert sha(rb)=='c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'
    src={x['id']:x for x in json.loads(sb)['cases']};rc=json.loads(rb)['cases'];j=json.loads(cert);counts={};seen=set();exact_lower_costs={}
    for row in j['rows']:
        tid=row['template'];key=(tid,row['a'],row['b'],row['c']);assert key not in seen;seen.add(key)
        st=mass_state(src[tid],rc[tid],*key[1:])
        for key2 in ['q','eg','alpha','rho','hardmass','m','M_rho']:
            if key2=='rho':
                for iv,x in zip(row['rho'],st['rho']):contains(iv,x)
            elif key2=='m':contains(row[key2],sum(st['mu'][i] for i in range(6) if st['E'][i] and st['rho'][i]>0))
            elif key2=='M_rho':contains(row[key2],sum(st['mu'][i]*st['rho'][i] for i in range(6) if st['E'][i] and st['rho'][i]>0))
            else:contains(row[key2],st[{'hardmass':'hard'}.get(key2,key2)])
        assert list(map(bool,row['good']))==st['good'];assert row['gates']==st['gates']
        assert row['necessary_pass']==all(st['gates'].values());assert row['fa_caps']==len(st['caps']);assert {str(v):f(z[0]) for v,z in row['firstFA'].items()}=={str(v):x for v,x in enumerate(st['first']) if x is not None}
        contains(row['C_ell'][0],st['costlo']);assert f(row['C_ell'][1][1])>=st['costup']
        contains(row['C_joint_diag'][0],sum(st['jointlo']));assert sum(st['jointlo'])<=st['costup'];exact_lower_costs[key]=st['costlo'];assert row['candidate']==(all(st['gates'].values()) and bool(st['caps']) and st['costlo']>1)
        counts.setdefault(tid,[0,0,0]);counts[tid][0]+=1;counts[tid][1]+=row['necessary_pass'];counts[tid][2]+=row['candidate']
    if j.get('stage')=='all':
        menuE=[-16,-12,-8,-4,-2,0,2,4,8,12,16]
        expected_models={(tid,a,b,cc) for tid in ('I1','P1') for a in menuE for b in menuE for cc in (0,-16,-8,8,16)}
        assert seen==expected_models and len(seen)==1210
    # Independently check predeclared top-three selection and all interior point gates.
    expected=[]
    for tid in ('I1','P1'):
        candidates=[r for r in j['rows'] if r['template']==tid and r['candidate']]
        candidates.sort(key=lambda r:(-exact_lower_costs[(r['template'],r['a'],r['b'],r['c'])],r['a'],r['b'],r['c']))
        expected.extend((r['template'],r['a'],r['b'],r['c']) for r in candidates[:3])
    assert expected==[(r['template'],r['a'],r['b'],r['c']) for r in j['top3_per_template']]
    point_count=0;gate_counts={};neighborhood=None;joint_exact_diagnostics=[];profile_integral_diagnostics=[];rowmap={(r['template'],r['a'],r['b'],r['c']):r for r in j['rows']}
    for block in j.get('point_checks',[]):
        key=(block['template'],block['a'],block['b'],block['c']);assert key in expected
        row=rowmap[key];c=src[key[0]];st=mass_state(c,rc[key[0]],*key[1:]);N=2*c['n']+3
        m=sum(st['mu'][i] for i in range(6) if st['E'][i] and st['rho'][i]>0)
        if key[0]=='I1':
            byv={};true_I=F(0);pair_integrals=[]
            for si,v,u,lo,hi,delta in st['caps']:
                sg=c['score_segments'][si];ks=sg['k'];cs=list(map(f,sg['c']));assert set(ks)=={0,4} and ks[v]==4
                A=sum(st['nu'][i]*cs[i] for i in range(6) if ks[i]==4);B=sum(st['nu'][i]*cs[i] for i in range(6) if ks[i]==0)
                C=sum(st['nu'][i]*cs[i] for i in range(6) if not st['good'][i] and ks[i]==0)
                cutpow=f(c['parameters']['B_FA'])*delta*st['p']*cs[v]/st['qv'][v]
                zl=max(hi**-4,1/cutpow);zh=lo**-4;assert zl<zh
                zz=[zl,zh]
                if zl<=B/A<=zh:zz.append(B/A)
                # d/dz[z/(Az+B)^2]=(B-Az)/(Az+B)^3: complete candidate set.
                assert delta==4 and ks[u]==0
                pairI=st['rho'][v]*st['nu'][v]*st['nu'][u]*cs[v]*cs[u]*(zh-zl)/((A*zh+B)*(A*zl+B))
                assert pairI>0
                true_I+=pairI;pair_integrals.append(dict(segment=si,v=st['names'][v],u=st['names'][u],z_start=str(zh),z_end=str(zl),I_exact=str(pairI)))
                value=2*N*st['nu'][v]*st['rho'][v]*max(cs[v]*C*z/(A*z+B)**2 for z in zz)
                byv[v]=max(byv.get(v,F(0)),value)
            je=sum(byv.values());assert f(row['C_joint_diag'][0][0])<=je<=f(row['C_joint_diag'][1][1])
            scaled=2*N*true_I;grid=10**10
            profile_integral_diagnostics.append(dict(model=list(key),N=N,I_exact=str(true_I),two_N_I_exact=str(scaled),two_N_I_interval=[str(F(scaled.numerator*grid//scaled.denominator,grid)),str(F(-(-scaled.numerator*grid//scaled.denominator),grid))],comparison_to_one='greater' if scaled>1 else 'equal' if scaled==1 else 'less',outer_factor_included=False,pair_integrals=pair_integrals,method='Exact two-score integral cv*cu*(z_start-z_end)/(e_start*e_end); delta=d cancels dz/dlogt.'))
            joint_exact_diagnostics.append(dict(model=list(key),exact_joint_interval=[str(F(je.numerator*grid//je.denominator,grid)),str(F(-(-je.numerator*grid//je.denominator),grid))],method='two-score derivative B-Az; rational FA-power endpoints'))
        for pt in block['points']:
            v=st['names'].index(pt['v']);u=st['names'].index(pt['u_bad']);si=pt['segment'];seg=c['score_segments'][si];ks=seg['k'];cs=list(map(f,seg['c']));t=f(pt['t']);lo,hi=f(seg['lo']),f(seg['hi']);kv=ks[v]
            assert lo<t<hi and st['good'][v] and not st['good'][u] and st['rho'][v]>0 and st['psi'][v,u] and kv>ks[u]
            cutpow=f(c['parameters']['B_FA'])*(kv-ks[u])*st['p']*cs[v]/st['qv'][v]
            assert t**kv<cutpow
            num=pt['fraction'];assert num in (1,2,3);capend=lo+(t-lo)*4/num
            if cutpow>=hi**kv:assert capend==hi
            else:
                assert capend**kv<cutpow and (capend+(hi-lo)/2**90)**kv>=cutpow
            ee,ss,ww=st['profile'](seg,t,v);et=st['eg']*ss/ee**2;R=st['qv'][v]*st['eg']/(st['q']*ww);Et=ee/st['eg'];assert Et>=1
            for field,value in [('E',Et),('R',R),('eta_t',et)]:contains(pt[field],value)
            etaL=f(row['eta_by_v'][v][0][0]);etaU=f(row['eta_by_v'][v][1][1]);assert etaL<=st['loeta'][v]<=st['upeta'][v]<=etaU
            factor=2*N*m*st['rho'][v];d1=(R-factor*etaU,R-factor*etaL)
            d2=(R**2-4*factor**2*etaU*et,R**2-4*factor**2*etaL*et)
            layer=0
            while F(2)**(layer+1)<=Et:layer+=1
            assert pt['layer']==layer;d3=R-factor*F((layer+1)*(layer+2),2**layer)
            classify=lambda d:'pass' if d[0]>=0 else 'fail' if d[1]<0 else 'unresolved'
            result=dict(uniform=classify(d1),geometric_mean=classify(d2),layer='pass' if d3>=0 else 'fail')
            assert pt['gates']==result
            if neighborhood is None and all(z=='fail' for z in result.values()):
                assert F(2)**layer<Et<F(2)**(layer+1)
                assert all(st['nu'][i]>0 for i in range(6)) and ee>0 and ss>0 and st['hard']>0
                assert d1[1]<0 and d2[1]<0 and d3<0
                neighborhood=dict(model=list(key),v=pt['v'],u_bad=pt['u_bad'],segment=si,fraction=num,t=pt['t'],layer=layer,E_interval=pt['E'],gate_delta_upper_intervals=pt.get('gate_deltas'),conclusion='Continuity inside this strict score/FA/layer cell gives an unspecified positive-length time interval outside all three gates, with positive original traffic. No explicit radius or full-window coverage claim.')
            if 'gate_deltas' in pt:
                for name,delta in [('uniform',d1),('geometric_mean',d2),('layer',(d3,d3))]:
                    assert f(pt['gate_deltas'][name][0])<=delta[0]<=delta[1]<=f(pt['gate_deltas'][name][1])
            for name,label in result.items():
                z=key[0]+':'+name+':'+label;gate_counts[z]=gate_counts.get(z,0)+1
            point_count+=1
        assert block['point_count']==len(block['points'])
    if j.get('point_checks'):assert point_count==54
    if args.profile_certificate:
        Path(args.profile_certificate).write_text(json.dumps(dict(scope='Selected original three I1 models; full original positive FA/Psi/rho time traffic with all six sources in e; exact frozen rational kernels, no outer factor, no FULL/dx claim',mass_scan_sha256=sha(cert),records=profile_integral_diagnostics),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status='PASS',scope='Frozen true-kernel rational necessary model only; no FULL/dx or complete-time-profile coverage claim',row_count=len(seen),counts=counts,point_count=point_count,point_gate_counts=gate_counts,joint_exact_diagnostics=joint_exact_diagnostics,profile_integral_summary=[{k:r[k] for k in ('model','N','two_N_I_interval','comparison_to_one','outer_factor_included')} for r in profile_integral_diagnostics],positive_neighborhood_witness=neighborhood,certificate_sha256=sha(cert),verifier_sha256=sha(Path(__file__).read_bytes())),indent=2))
if __name__=='__main__':main()
