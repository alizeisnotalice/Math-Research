# R150 有限历史索引：ν质量倍率与后验时间profile预算

检索范围：定向实读 R136 active-traffic/容量材料、R139 selector预算、R141历史索引、R142接收方案及结果说明，共8个相关文档/脚本；没有重跑producer，也没有遍历全史。

## 已定位的接口与证据

### R136：最适合做同步 `ν` 重算的入口，未做质量倍率扫描

- [active_traffic_v2.py](/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/package/centered_cube_round136_20261014/active_traffic_v2.py) 的 `calc(row,dps)` 在一个入口中从源质量表开始重算：逐源核与阈值、`w_g,w_τ,w_h,A,K_0,K_1,K_2,J,Q`；由质量积分算 `e_g,Q_J,q`；逐源重判 `good/E/U`；然后重算共同 `alpha` 与 `rho`；最后重建 score 段、FA端点、Psi后缀与交通积分。这是若测试 `ν` 质量倍率，应插入倍率并完整调用这条链的合适历史接口。不能只对已算交通乘质量因子，也不能固定旧 `q/alpha/rho`。
- 当前生产输入是预定的12个有限原子实例；脚本质量为前4源 `ε=10^-8`、B源 `1−4ε−10^-300`、CORE源 `10^-300`，总质量恰为1。位置/维数/软度也在 `MENU` 中预定。结果记录 `nu_total`、质量舍入差、门与积分，并保留 E3 失败案例；这是固定菜单，不是按 `ν` 质量倍率扫描。
- 同脚本将 `q=max(∫K_0dν,∫Jdν,∫Qdν)`，`alpha=(Dq−∫U dν)/Q_J` 同步重算，`rho=[A−(U+alpha J)/T]_+/A`。good 资格依赖新 `Q`，所以改变来源质量会改变来源标签、`alpha`、`rho`、FA/Psi对和门；只重算后验或只改 `e_t` 不完整。
- 其声明范围是 true kernels 的 necessary finite-source FA/Psi model；JSON/script 明确 `FULL_certified=False`、无完整 history/外层接收积分认证。需要物理完整模型时，还缺实际 `x,y,z` 行支撑、hard receiver、原历史/存活负项、完整 β−ν 与外层 `dx` 等合同。
- [ordered_score_capacity.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/ordered_score_capacity.md) 给同一 `alpha` 的 score 平均层分解。它确认各层 bad 权重重叠，不能逐层重复领取一份 `alpha Q_J`；必要的核比较/外层预算仍未闭合。[active_capacity_audit.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_capacity_audit.md) 进一步强调同一行共同 `alpha`，且一些候选是逆核矩/容量估计，不是完整付款。

### R142：真实 receiver 点上同步重算，但固定来源质量

- [numeric_receiver_plan.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/numeric_receiver_plan.md) 规定固定 R141 的原六源位置和质量、固定 `λ=q(x0)`，随接收点 `x` 同步重算 `q(x),alpha(x),rho(x)`、good/bad、FA、Psi及hard/high/heavy门；采样为 I1/I2/P1 三个有限必要模型，uniform-core 与真实 `p(x)dx` 两流，6951个 receiver 记录。方案明确没有mass/n菜单变化。
- [numeric_receiver_notes.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/numeric_receiver_notes.md) 记录R142观察范围：I1正点uniform 4/1152、p流7/1152；I2两流0；P1 uniform 163/1152、p流0。多达1990–2242个点发生good标签改变；P1 163个uniform正点中153个包含far B变good产生的额外交通。反映接收点移动会改变模型标签，但不是质量倍率扫描，也不能当作倍率方向反例。
- R142核为 R135 E3 软核与对应混合密度；方案列出 `K0,K1,K2,J,Q`、真实 `p`、阈值、门与交通公式。抽样与浮点/高精核对不是区间证书；本轮明确不认证FULL、forest、连续 `ν` 或维数阶。
- [history_receiver.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round142_20261015/history_receiver.md) 对 R134–141 检索的是另一个双门正幂Chernoff目标，未定位相同付款。它可用于区分相邻历史容量与完整接收费用，不是本次质量扫描证据。

### R139：有固定selector预算材料，但不是后验全时间profile门

- [selector_budget_check.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round139_20261015/selector_budget_check.md) 核对共同 `S,λ_S` 固定在外hard来源积分前的selector合同；硬壳Chernoff还需保留实际偏移相关的坐标费用。没有 source-specific posterior profile 或随未来时间变化的预算门。
- [history_targets.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round141_20261015/history_targets.md) 对R139 hard-reserve/好来源联合估计、R139 hard-shell坐标数的分布式界有较广定向总结；这些分别是核心储备/逆核壳费用对象，不是目标的 `L_t` 后验全时间profile价格。

## 对 Luna / Solmedium / r149_numeric 的直接接口建议

若要做固定来源模型上的压力扫描，可把倍率参数放在 R136 `calc` 质量向量构造处，至少区分：

1. 全部 `ν_i` 同乘 `c`（但要显式标出 `nu_total=c`，并判断是否还满足输入来源质量归一化合同）；
2. 指定 bad / far 源乘 `c`，同时说明从哪个good/core质量扣回以维持总质量1；
3. 指定 good/core 源乘 `c` 并从bad源扣回。

每个倍率点都必须从原子权重开始同步重算 `q,Q_J,e_t,good,E,U,alpha,rho,FA,Psi,hardmass`，并重核 original gates。固定全量乘子时，形式上的 `Π_t∝ν/e_t`可能消去共同倍数，但 `q`、储备余量 `alpha`、`rho`、hardmass门与输入质量规范仍要重算；若只改bad子集，`Π_t`本身也变。不要将这一消去误当作交通不变性。

最小的必要合同可照 R136 gate 列表：严格软度/尺度与时间窗、非负 `alpha`、真实 good 与终端 `E`、hard mass 与 `q` 关系、high/heavy、FIRST三核、`e_t>0`、原 score/FA/Psi资格，以及真实正rho交通。完整实现还须原 `x,y,z` 来源支撑、硬接收分母、历史/终端条件、被保留的负项、外 `dx`、唯一 j、β−ν和可测统一选择器；这些不由有限六原子试验提供。

已有有限试验范围只覆盖 R136 的12个离散菜单（n=4–128，固定列出的软度和源位置/质量）与 R142 的三个固定质量案例（n=4/16，固定 `s=.25,L=.9`）的有限receiver点。没有记录显示试过任意倍率的连续区间扫描、保持总质量的bad-good交换曲线或对 `rho` 的真实质量剖面。可作为压力点的既有现象是 R142 的 receiver 移动会显著切换good标签，而非质量变化的反例；尚无对应的同步倍率反例。若产生扫描图，务必将“必要有限模型的失效门/反例”与“FULL模型反例”严格分开。

## future `ell_t` 查询

定向搜索 R128、R136、R139–142 的相关接收、active traffic、时间门及历史索引文件，并查阅上述R136时间/容量代码与R142 receiver方案；未定位到使用
`ell_t = esssup_{r≥t} L_r B_r`
作为 future-posterior profile 的预算门。现有材料有固定 `L_g`/共同源预算、逐时 `Π_t`、原时间积分和给定目标时间集的固定预算上确界等相邻接口，但不是这个依未来时间变化的门。此结论仅限本次定向文件范围，不断言更早档案不存在。
