# R150 Sol 独立审计

状态：先审；仅审上一轮辅助 GR12–GR13 与本轮主代理发送的 E 层候选，尚未读取本轮作者正文。唯一修改本文件。不以作者摘要作为证明，不重新审核已通过的 R149 ℓ 门定理。

## 1. GR12–GR13 的独立重推及准确边界

固定原实际行 (ω,V,j,x,y)，时间窗 [τ,h]⊂[τ,g)，同一原 ν、参数和共同储备 α。令 E₊ 为原 terminal good 再交 {ρ>0}，D₀ 为原 terminal bad。以下所有时刻/来源都是原行，不重新选择核或归一来源。非零行上 p,q,e_g>0；E₊⊂Z_g⊂Z_t，且 ρ、A=wτ−wh、α 都沿时间固定。原软核 K₀,J>0。

在 E₊ 上，原正支意味着 U=DK₀，因此准确有

\[
a_v=\left(1-\frac{DK_{0,v}}{TA_v}\right)_+,\qquad
\rho_v=a_v-\frac{\alpha J_v}{TA_v}>0,\qquad
a_v-\rho_v=\frac{\alpha J_v}{TA_v}.
\tag{AS1}
\]

这里 a_v 是实际标量余量，不是可分配预算密度。共同坏储备为
\(\int_{D_0}K_0d\nu\le\alpha Q_J/D\)。

对 k_r(v)>0 定义
\[
\mathcal H_r(v)=\int_{D_0\cap Z_r}
  \left(\frac{\delta_r(v,u)}{k_r(v)}\right)^2
  \frac{w_r(u)^2}{K_{0,u}}\,d\nu(u),\qquad
\mathcal S_v=\operatorname*{ess\,sup}_{r\in[\tau,h]}
  \frac{\mathcal H_r(v)}{e_r^4}.
\]
k_r(v)=0 时该切片置零。实际后验 B_r 中一次 CS 给
\[
 B_r(v)\le \frac{\sqrt{\alpha Q_J/D}}{e_r}
           \sqrt{\mathcal H_r(v)}.
\]
乘 \(L_r=Kq/(pe_r)\) 后再取整窗上确界，故
\[
 \ell_v\le\frac{Kq}{p}\sqrt{\alpha Q_J/D}\sqrt{\mathcal S_v},
\quad
 \rho_v\ell_v\le\frac{Kq}{p}
 \sqrt{\frac{TA_vQ_J}{DJ_v}}\,
 \rho_v\sqrt{a_v-\rho_v}\sqrt{\mathcal S_v}.
\tag{AS2}
\]
因此 e_r^{-4} 准确：B 的后验归一给一份 e_r^{-1}，L 再给一份 e_r^{-1}，之后平方进入 S。不能写成 e_r^{-2} 的 S。

新门严格补集
\(r_t(v)<2Nm\ell_v\rho_v\)，其中
\(r_t=KQ_v/(pw_t)\)、\(m=Q_E/q\)，于是
\[
 Q_v^2J_v<
 4N^2Q_E^2w_t(v)^2\frac{TA_vQ_J}{D}
 \rho_v^2(a_v-\rho_v)\mathcal S_v.
\tag{AS3}
\]
这里 q,p,K 只在这一必要条件的代数中取消。Q_E、Q_J、α 与 S 都仍取自实际行；没有消除完整接收积分中的 p dx 或来源费用。原实际储备因子不能独立替成一个可优化参数。标量
\[
 \rho^2(a-\rho)\le4a^3/27
\]
在 \(\rho=2a/3\) 达等；它是进一步放松，不能再同时领取一份被放弃的储备收益。

同一实际 α 同时出现在 AS2 的必要局部化和当前坏源 CS 中，本身不造成重复付款：它们是对同一实际数值同时成立的不等式。但不得将二者当作两份独立可支配储备，不得对每个 v 或见证 r 分别重选 α，也不得在最终积分中把同一共同坏容量逐来源/逐时刻重复相加。

令 Ξ_t(v) 为 AS3 右侧除以 Q_v²J_v。原补集蕴含 Ξ>1。当前 FA 矩必须是
\[
 \mathcal H_t^{FA}(v)=\int_{D_0\cap Z_t}
 \left(\frac{\delta_t(v,u)}{k_t(v)}\right)^2
 1_{\{\delta_t(v,u)>r_t(v)/(KB_{FA})\}}
 \frac{w_t(u)^2}{K_{0,u}}\,d\nu(u).
\]
当前原坏源积分由 CS 上界为
\[
 \rho_vk_t(v)B_t^{FA}(v)
 \le\frac{\rho_vk_t(v)}{e_t}
      \sqrt{\alpha Q_J/D}\sqrt{\mathcal H_t^{FA}(v)}.
\tag{AS4}
\]
再乘当前好源 \(d\Pi_t(v)=w_t(v)d\nu(v)/e_t\)，准确留下 e_t^{-2}。先在原外 hard 来源 z 积分中保留 history aω，用原实际 hard 帽16/3一次，可得对任何固定 θ>0，
\[
\begin{aligned}
2\Lambda P(\Omega_-)\le\frac{32\Lambda}{3}
\mathbb E\sum_{V,j}\int&
 p\,dx\,d\beta_V(y)\frac{dt}{t}
 \frac{\sqrt{\alpha Q_J/D}}{e_t^2}\\
&\times\int_{E_+}\rho_vk_t(v)w_t(v)
 \sqrt{\mathcal H_t^{FA}(v)}
 \min\{1,\Xi_t(v)^\theta\}\,d\nu(v).
\end{aligned}
\tag{AS5}
\]
省略显示的原合法选择器仍应保留。这独立重现 GR12。所用门比较为
\(1_{\Omega_-}\le1_{\{\Xi>1\}}\le\min(1,\Xi^\theta)\)。
在真实余域上最后因子等于1；它只可能改善放松后的全域 CS 帽，并不在真实余域上自动提供逐点折扣。此 RHS 尚须支付完整 dx、β、外期望、V,j、soft/scale 和来源负权矩；没有新增根阶结论。

见证时间 r 与当前时间 t 必须分开。若一个实际 r 满足
\(L_rB_r(v)\ge\eta L_g\)，0<η≤1，则由
\(L_r/L_g=e_g/e_r\) 和 B_r≤严格低-score坏后验质量≤1，
\[
 1\le e_r/e_g\le1/\eta,\qquad
 \Pi_r(D_0\cap\{k_r(u)<k_r(v)\})
 \ge B_r(v)\ge\eta e_r/e_g\ge\eta.
\tag{AS6}
\]
这独立重现条件式 GR13。若只知 \(\ell_v>\eta L_g\)，可取正时间测度的严格超水平见证；若仅 \(\ell_v=\eta L_g\)，esssup 不必达到，不能声称存在 ≥η 的见证。可改用任意 η<ℓ_v/L_g。上述 e_r 和 Π_r 结论不能转用于当前 t；来源依赖的见证选择还须保证可测性，或直接使用超水平集而不作选择。尤其不能用晚时的大 ℓ 与早时的大 w_t/w_g 当作同一时刻的数据。

零 α 时原正软 K₀ 迫使坏源 ν 质量为零，故 B=ℓ=0，相关余域为空；先作此拆分，不计算0·∞。S=∞ 时 AS2–AS5 至多是扩展上界，不认证有限价格。截断必须保留原 ν 和原归一常数，不得重新归一。

## 2. 本轮 E 分层候选：独立源—时间证书

以下只审主代理发来的准确命题，不依据作者正文。仍固定原实际行；层号用 ℓ，避免与原几何选择 j 混淆。定义
\[
 d\mu(v)=Q_vd\nu(v)/q,\quad
 m=\mu(E_+),\quad
 E_t=e_t/e_g\ge1,\quad
 I_\ell=\{t:2^\ell\le E_t<2^{\ell+1}\},\quad
 \gamma_\ell=\frac1{(\ell+1)(\ell+2)}.
\]
μ 是同一原来源的次概率，不重新归一。m 是整 terminal E₊ 的同一质量；不得改成随 t、score 或本层筛选变化的质量。

假定原非零行 e_t 有限且 e_g>0。则 I_ℓ 可测、互不交并覆盖原时间窗（除原约定的零测端点），且
\[
 L_t=L_g/E_t\le L_g2^{-\ell}\quad(t\in I_\ell),
 \qquad \sum_{\ell=0}^\infty\gamma_\ell=1.
\tag{AS7}
\]
每个 v 的阈值
\[
 c_\ell(v)=\frac{2Nm\rho_vL_g}{2^\ell\gamma_\ell}
\tag{AS8}
\]
沿时间固定。新门为原正域再交 \(t\in I_\ell,\ r_t(v)\ge c_\ell(v)\)。

先把原坏源积分保留为同一 Π_t，再用
\(\int_{D_0}\delta_t(v,u)d\Pi_t(u)\le k_t(v)\)。
由实际后验恒等式 \(d\Pi_t(v)=L_t\,d\mu(v)/r_t(v)\)，本层完整来源—时间正量（尚未乘外 hard 接收量）满足
\[
\begin{aligned}
I_\ell^{src}
&\le\int_{E_+}\rho_v\,d\mu(v)
 \int_{[\tau,h]\cap I_\ell}
 \frac{L_tk_t(v)}{r_t(v)}
 1_{\{r_t(v)\ge c_\ell(v)\}}\frac{dt}{t}\\
&\le L_g2^{-\ell}\int_{E_+}\rho_v\,d\mu(v)
 \int_{\tau}^{h}\frac{k_t(v)}{r_t(v)}
 1_{\{r_t(v)\ge c_\ell(v)\}}\frac{dt}{t}\\
&\le L_g2^{-\ell}\int_{E_+}\frac{\rho_v}{c_\ell(v)}d\mu(v)
 =\frac{\gamma_\ell}{2N}.
\end{aligned}
\tag{AS9}
\]
最后一步使用原 terminal good 来源整窗存活，\(r_t=KQ_v/(pw_t)\) 单调不减且
\[
 -d(1/r_t)=\frac{k_t(v)}{r_t(v)}\frac{dt}{t},
 \qquad
 \int_\tau^h\frac{k_t(v)}{r_t(v)}
 1_{\{r_t(v)\ge c\}}\frac{dt}{t}\le1/c\quad(c>0).
\tag{AS10}
\]
k 的有限跳变不产生 r 的跳跃；k=0 段贡献零。无需假定 I_ℓ 连通，因为第二行仅放大非负积分。FA、Ψ、原余域等正门可保留，或在上界中取≤1；不改变原负项、future bad 或删除项。

m=0 时 E₊ 为 μ 零集，来源正量为零；ρ=0 来源原正量也为零。先排除这些点再使用 AS8 的倒数，不作0/0。原非零高行保证 L_g>0；零 p,q,e_g 的行须沿原问题约定单列，不以新比值补定义。

可数 Tonelli 与 AS9 给
\[
 \sum_{\ell\ge0}I_\ell^{src}\le\frac1{2N}.
\tag{AS11}
\]
这里没有 log E 的层数费。e_g,m,ρ、Q 和层集合可以依原 x、y、s,L 等外参数，因为先对每条实际行证明统一帽。它们必须不依外 hard 来源 z，才能在之后按原合同进行 hard/history 聚合；该独立性应在作者定义中明示。

与旧 R149 ℓ 门的并集可用两个非负上界之和付款，最多两份对应整覆盖费用。两门交集不能重复报成新增覆盖，也不能将 ℓ 层的阈值与 E 层的 L_t 帽交叉拼接以声称单份费用。新 E 门在早时 E_t 大而 ℓ 由晚时见证时可能增加覆盖，但 AS11 本身不证明严格增益或完整覆盖原正域。

## 3. 后审验收边界

本先审接受 AS5、AS6 以及 AS11 的上述精确合同。作者正文还须做到：

- 始终保留原 terminal E₊、同一 m、ρ、ν 与实际 posterior；阈值只随层号和时间固定的来源参数变化。
- 无限 E 层在来源—时间阶段先总和为1，再进入外接收与 R148 soft 包络；不得把每层外价另加，亦不得把归一错误藏进“层数无费”。
- R148 外包络及 softness 层的原合法范围、N 的固定层合同、history hard 帽和实际几何选择必须逐项沿用。AS11 证明不自行补出这些外价，也不允许把 β 换成 dy。
- 若最终取旧 ℓ 门与新 E 门并集，记账至多增加一份对应完整门价；保持原先已删 high/FA/TOP 的划分，所有真实负项原样。
- GR12 路线若作为进一步改进，必须对 AS5 的完整实际 RHS 给出全局付款；核值或一个固定参数积分不能替代该任务。

本文件后续只追加指定主稿的绑定后审，不开展一般历史复核。

## 4. 主代理追加的 current-coefficient H 门：独立先审

设 \(h_t(v)=L_tB_t(v)\)，此处 B_t 为原完整 terminal D₀ 的实际后验 score 比例，不额外改变来源测度。整窗
\(\ell_v=\operatorname*{ess\,sup}_{t\in[\tau,h]}h_t(v)\)，故 \(0\le h_t(v)\le\ell_v\) 对时间几乎处处成立。令 \(z_t(v)=\rho_v/r_t(v)\)。原 terminal good 来源沿时间存活，ρ 固定，故 z 连续、绝对连续且非增，并有
\[
 -dz_t(v)=k_t(v)z_t(v)\frac{dt}{t}.
\tag{AS12}
\]
先积实际坏来源、再用 \(d\Pi_t(v)=L_t\,d\mu(v)/r_t(v)\)，完整原 score 正量恰为
\[
 \int_{E_+}d\mu(v)\int_\tau^h h_t(v)(-dz_t(v)).
\tag{AS13}
\]
原 FA、Ψ 和其他额外正门取≤1只会减少左侧，不会改变负项；不把这些门用来另定义一个外 hard z 依赖的 h 后再套用独立 hard 帽。

固定每来源 \(c>0\) 和 \(0<\theta<1\)，考虑当前确定门
\[
 z_t(v)\le c\left(\frac{\ell_v}{h_t(v)}\right)^\theta.
\tag{AS14}
\]
h=0 的切片原交通零，先拆后不作除法。对 h>0，门蕴含
\[
 h_t(v)1_{\mathrm{gate}}
 \le\ell_v\min\{1,(c/z_t(v))^{1/\theta}\}.
\tag{AS15}
\]
因 z 单调绝对连续，-dz 的推前是其值区间上的 Lebesgue 测度；于是非负积分可放大到整个正轴：
\[
 \int_\tau^h h_t(v)1_{\mathrm{gate}}(-dz_t(v))
 \le\ell_v\int_0^\infty\min\{1,(c/z)^{1/\theta}\}\,dz
 =\frac{\ell_v c}{1-\theta}.
\tag{AS16}
\]
无需 h 单调，不取 esssup 的导数，也不把见证时间当当前时间。ℓ 的零测例外对 dt/t、因而对 -dz 都为零。

取 θ=1/2，\(c_v=1/(4Nm\ell_v)\)，原非零 ℓ,m,ρ 来源上，门等价于
\[
 \boxed{r_t(v)\ge4Nm\rho_v\sqrt{\ell_vh_t(v)}}.
\tag{AS17}
\]
AS16 给每来源 \(1/(2Nm)\)，再用原同一 \(\mu(E_+)=m\)，得
\[
 \int_{E_+}d\mu(v)\int_\tau^h
 h_t(v)1_{\mathrm{AS17}}(-dz_t(v))
 \le1/(2N).
\tag{AS18}
\]
m=0 或 ρ=0 先按零交通处理；ℓ=0 则 h=0 时间几乎处处，亦无此正交通。所有比值只在正分母域计算，不以0·∞补定义。ℓ、m、ρ依原行/来源但不依当前时间或外 hard 来源。若原允许扩展无限行，须先依原截断合同保证相关量有限后才能使用 AS14；本门不免费解决无限归一量。

在 \(0<h_t(v)<\ell_v/4\) 上，AS17 的阈值严格低于旧门 \(2Nm\rho_v\ell_v\)。两门并不相互包含；与旧门并集可用两份对应完整覆盖价。再加入第2节质量分层门，三个门全并的通用记账至多三份单门价，不宣称免费并集或普遍严格新覆盖。

预审绑定：旧辅助 r149_geometric_remainder.md 的 SHA256 为
\(\texttt{43390528c65884f730531eac41f7789af3639073698c8a886298c8e04c92c5be}\)。
当前未绑定本轮作者文件，等待指定冻结稿。

## 5. 冻结主稿绑定后审

已实际通读 joint_geometry.md 的 JG1–JG14，并对照本文件先审 AS7–AS18 独立核算。最终绑定 SHA256：

\[
\texttt{bf360aabc1f66d8aa9416e3e9464ad9106c808c440ec81949b48a0054d5a0fd6}.
\]

结论：接受两种门各自的完整来源—时间帽及其按原 R148 合同的接收转接；接受三门全并最多三份 CₙΛ√nWβ 的去重上界，剩余未闭合。具体核对如下。

1. Q 门 JG6 在互斥 E 层上使用 L_t≤L_g2^{-κ}，每层只领 γκ 份源时预算；原固定 m 与 E₊ 未重归一，Σγκ=1 后才走外 hard/soft 价。JG8 三核写法准确，f₆=7/8、f₇=9/16 的例值准确，不声称所有早段都覆盖。
2. H 门 JG9 的一般 θ 阈值准确；JG10 的正轴包络积分为 ℓc/(1−θ)，θ=1/2 后得 JG11。JG12 三核式准确。证明不微分 esssup，不要求当前容量单调，也没有见证时刻等于当前时间的假设。
3. JG6 外价顺序先完成来源及整窗积分，再保持原 history 用 hard 帽，然后合并原唯一 j，最后用 R148 softness 接收包络。每 near-soft 带的 512/3 常数和一份 far/小维48常数给正文所列 Cₙ。本后审沿用原 R148 已证外包络合同，不将新的同行证明说成重证该旧合同。
4. JG14 的严格余域确为三个 ≥ 门补集相交，即 r 小于三阈值的最小值。L+Q 或 L+H 至多两份，三门全并至多三份；没有一份预算免费并集或将旧交集报成新增覆盖。原负项、α/ρ、history 以及更早已付补集维持原合同。

发现并已修正的实际表述问题：初稿把“有限截断”与后续 Tonelli 推广相连，未明确截断是否重算原后验和门。这不足以保证极限合法，因为截断 ν 后 m、ℓ 及门未必单调。已要求作者限定原合法有限行，并明确固定原 ν、e_t、μ、m、ρ、ℓ 和 gate，仅截断非负被积项；一般无限行不在此扩证。最终第46行已实际复读并确认修正，最终 SHA 如上，旧 d8eafb… 版本不作为绑定版本。

未新增数值菜单、未运行 Git、未修改任何其他文件。指定主估计后审完成；GR12 的完整逆矩 RHS 仍未付款，最终三门余域仍保留，不能据本审计宣称全问题闭合。


## 6. 双稿最终一致性绑定

已实际通读 research.tex，核对其 Q/H 两门、一般 θ 包络积分、同一 terminal E₊ 与 m、固定原数据截断、Cₙ 和三门严格 min 余域，与第5节已审 joint_geometry.md 一致。

另发现并已修正第二处实际合同冲突：research.tex 初稿公共通量段将“合法 history 门”与 FA、Ψ 并称可丢弃，可能误删后续 hard16/3 必需的 aω。已要求保留 hard/history，最终第21行实际复读为：“外 hard 聚合所需的原 aω 始终保留，不删除其 history 合同。”因此该问题在最终版关闭。

最终双稿 SHA256：

- joint_geometry.md：\(\texttt{bf360aabc1f66d8aa9416e3e9464ad9106c808c440ec81949b48a0054d5a0fd6}\)。
- research.tex：\(\texttt{9b1ba384f5dd254695ea1508fa8aadf046a7170a82f79f386c43f536abd2ed71}\)。

数学正文后审通过；一般全剩余仍未付款。数值段当前只给 scope 和证据界限，本后审不据此登记尚未冻结的数值结果，亦未编译 PDF。指定双稿审核结束。




