#!/usr/bin/env python3
"""R150 fixed-geometry rational mass scan; no inherited alpha/rho."""
from fractions import Fraction as F
from pathlib import Path
import json, hashlib, argparse, math, sys, time
sys.set_int_max_str_digits(0)
ROOT=Path(__file__).resolve().parent
DEFAULT_INPUT_ROOT=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015')
BASE=DEFAULT_INPUT_ROOT
P136=BASE/'centered_cube_round136_20261014/active_traffic_v2.json'
P142=BASE/'centered_cube_round142_20261015/numeric_receiver.json'
def q(x):
    if isinstance(x,F): return x
    if isinstance(x,dict) and 'numerator' in x:return F(int(x['numerator']),int(x['denominator']))
    return F(str(x))
def fs(x):return str(x.numerator) if x.denominator==1 else f'{x.numerator}/{x.denominator}'
def iv(x,d=10):
    s=10**d; lo=x.numerator*s//x.denominator; hi=-((-x.numerator*s)//x.denominator)
    return [f'{lo}/{s}',f'{hi}/{s}']
def add(a,i,x):
    while len(a)<=i:a.append(F(0))
    a[i]+=x
def ev(a,x):
    z=F(0)
    for c in reversed(a):z=z*x+c
    return z
def profile(seg):return [(q(c),int(q(k))) for c,k in zip(seg['c'],seg['k'])]
def eta_bounds(case,nu,eg,good,v):
    """Whole-window rigorous bounds, segment-local score profiles and positive coefficient boxes."""
    tau=q(case['derived']['tau']); h=q(case['derived']['h']); low=F(0); up=F(0); boxes=0
    for seg in case['score_segments']:
        lo=max(tau,q(seg['lo'])); hi=min(h,q(seg['hi']))
        if lo>=hi:continue
        prof=profile(seg); kv=prof[v][1]
        if kv<=0:continue
        d=math.gcd(*(k for _,k in prof if k))
        P=[F(0)]; S=[F(0)]
        for i,(c,k) in enumerate(prof):add(P,k//d,nu[i]*c)
        for u,(c,k) in enumerate(prof):
            coeff=1-F(k,kv)
            if not good[u] and coeff>0:add(S,k//d,nu[u]*c*coeff)
        xl=hi**(-d); xh=lo**(-d)
        L=max(ev(S,xl)/ev(P,xl)**2,ev(S,xh)/ev(P,xh)**2)
        U=ev(S,xh)/ev(P,xl)**2
        low=max(low,eg*L);up=max(up,eg*U);boxes+=1
    return low,up,boxes


def point_checks(rows,cases,rec):
    out=[]
    for row in rows:
        tid=row['template'];case=cases[tid];receiver=rec[tid];atoms=case['atoms'];pars=case['parameters'];der=case['derived'];n=int(case['n'])
        a,b,c=row['a'],row['b'],row['c'];nu0=[q(x) for x in receiver['nu_exact']]
        raw=[(F(2)**a)*nu0[i] if i<3 else (F(2)**b)*nu0[i] if i==3 else nu0[i] if i==4 else (F(2)**c)*nu0[i] for i in range(6)];ss=sum(raw);nu=[x/ss for x in raw]
        base=next(x for x in receiver['verifications'] if x['id']==0);p=q(base['p']);K0=list(map(q,base['K0']));K1=list(map(q,base['K1']));K2=list(map(q,base['K2']));J=list(map(q,base['J']))
        Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)];q0=sum(nu[i]*K0[i] for i in range(6));qj=sum(nu[i]*J[i] for i in range(6));qs=sum(nu[i]*Q[i] for i in range(6));qv=max(q0,qj,qs)
        wg=[q(x['wg']) for x in atoms];A=[q(x['A']) for x in atoms];good=[p*wg[i]<=q(pars['K'])*Q[i] for i in range(6)];E=[good[i] and A[i]>0 for i in range(6)]
        U=[min(q(der['T'])*A[i],q(pars['D'])*K0[i]) if E[i] else F(0) for i in range(6)]
        alpha=(q(pars['D'])*qv-sum(nu[i]*U[i] for i in range(6)))/qj;rho=[max(F(0),1-(U[i]+alpha*J[i])/(q(der['T'])*A[i])) if E[i] and A[i] else F(0) for i in range(6)]
        eg=sum(nu[i]*wg[i] for i in range(6));mu=[Q[i]*nu[i]/qv for i in range(6)];m=sum(mu[i] for i in range(6) if E[i] and rho[i]>0);N=2*n+3
        # Rebuild active per-segment caps exactly, then rationalize each algebraic cut from below.
        nameidx={x['name']:i for i,x in enumerate(atoms)}; caps=[];B=q(pars['B_FA'])
        for pair in case['pairs']:
            v=nameidx[pair['v']];u=nameidx[pair['z_prime']]
            if not(good[v] and not good[u] and rho[v]>0 and pair['Psi']):continue
            for si,seg in enumerate(case['score_segments']):
                prof=profile(seg);cv,kv=prof[v];cu,ku=prof[u];lo=q(seg['lo']);hi=q(seg['hi'])
                if kv<=ku or kv<=0:continue
                delta=F(kv-ku);R=B*delta*p*cv/Q[v]
                if R<=lo**kv:continue
                if R>=hi**kv:capend=hi
                else:
                    L=lo;H=hi
                    for _ in range(90):
                        mid=(L+H)/2
                        if mid**kv<R:L=mid
                        else:H=mid
                    capend=L
                if capend<=lo:continue
                for num in (1,2,3):
                    t=lo+(capend-lo)*F(num,4)
                    e=sum(nu[i]*prof[i][0]*t**(-prof[i][1]) for i in range(6))
                    S=sum(nu[u0]*prof[u0][0]*t**(-prof[u0][1])*(1-F(prof[u0][1],kv)) for u0 in range(6) if not good[u0] and prof[u0][1]<kv)
                    eta_t=eg*S/e**2;w=cv*t**(-kv);Rnorm=Q[v]*eg/(qv*w);Etime=e/eg
                    # eta_v box endpoints from row (outward 1e-10 rationals)
                    elo=q(row['eta_by_v'][v][0][0]);ehi=q(row['eta_by_v'][v][1][1])
                    rho_v=rho[v]
                    g1rhs=2*N*m*rho_v*elo;g1pass=Rnorm>=2*N*m*rho_v*ehi;g1delta=(Rnorm-2*N*m*rho_v*ehi,Rnorm-2*N*m*rho_v*elo)
                    lhs2=Rnorm**2; fac=4*N*m*rho_v
                    g2fail=lhs2<(fac**2)*elo*eta_t;g2pass=lhs2>=(fac**2)*ehi*eta_t;g2delta=(lhs2-(fac**2)*ehi*eta_t,lhs2-(fac**2)*elo*eta_t)
                    if Etime<1: layer=None;g3=None
                    else:
                        layer=Etime.numerator.bit_length()-Etime.denominator.bit_length()
                        while F(2)**layer>Etime:layer-=1
                        while F(2)**(layer+1)<=Etime:layer+=1
                        g3rhs=2*N*m*rho_v*F((layer+1)*(layer+2),2**layer)
                        g3=Rnorm>=g3rhs;g3delta=Rnorm-g3rhs
                    caps.append({'v':atoms[v]['name'],'u_bad':atoms[u]['name'],'segment':si,'fraction':num,'t':fs(t),
                      'E':iv(Etime),'layer':layer,'R':iv(Rnorm),'eta_t':iv(eta_t),'eta_v':row['eta_by_v'][v][:2],
                      'gate_deltas':{'uniform':iv(g1delta[0]) if g1delta[0]==g1delta[1] else [iv(g1delta[0])[0],iv(g1delta[1])[1]],
                         'geometric_mean':[iv(g2delta[0])[0],iv(g2delta[1])[1]],
                         'layer':None if layer is None else iv(g3delta)},
                      'gates':{'uniform': 'pass' if g1pass else 'fail' if Rnorm<g1rhs else 'unresolved',
                               'geometric_mean':'pass' if g2pass else 'fail' if g2fail else 'unresolved',
                               'layer':'unresolved' if g3 is None else ('pass' if g3 else 'fail')},
                      'union_payment':'three separate C budgets if unioned'})
        out.append({'template':tid,'a':a,'b':b,'c':c,'point_count':len(caps),'points':caps})
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['initial','pressure','expanded','all'],default='all');ap.add_argument('--input-root',default=str(DEFAULT_INPUT_ROOT),help='root containing the frozen centered_cube_round136_20261014 and centered_cube_round142_20261015 input directories');args=ap.parse_args()
    global BASE,P136,P142
    BASE=Path(args.input_root);P136=BASE/'centered_cube_round136_20261014/active_traffic_v2.json';P142=BASE/'centered_cube_round142_20261015/numeric_receiver.json'
    d136=json.loads(P136.read_text());d142=json.loads(P142.read_text())
    cases={x['id']:x for x in d136['cases'] if x['id'] in ('I1','P1')}; rec={k:v for k,v in d142['cases'].items() if k in cases}
    init=[-4,-2,0,2,4]; E=[-16,-12,-8,-4,-2,0,2,4,8,12,16]
    def stage_menu(stage):
      for tid in ('I1','P1'):
       if stage=='initial': pairs=[(a,b,0) for a in init for b in init]
       elif stage=='pressure':pairs=[(a,b,0) for a in E for b in E if a not in init or b not in init]
       else:pairs=[(a,b,c) for a in E for b in E for c in (-16,-8,8,16)]
       for z in pairs:yield tid,*z
    allrows=[];attempts=0;started=time.time();stages=['initial','pressure','expanded'] if args.stage=='all' else [args.stage]
    for stage in stages:
      for tid,a,b,c in stage_menu(stage):
        attempts+=1; case=cases[tid]; receiver=rec[tid]; atoms=case['atoms']; pars=case['parameters']; der=case['derived']; n=int(case['n'])
        nu0=[q(x) for x in receiver['nu_exact']]
        raw=[(F(2)**a)*nu0[i] if i<3 else (F(2)**b)*nu0[i] if i==3 else nu0[i] if i==4 else (F(2)**c)*nu0[i] for i in range(6)]
        sm=sum(raw);nu=[x/sm for x in raw]
        base=next(x for x in receiver['verifications'] if x['id']==0)
        p=q(base['p']);K0=list(map(q,base['K0']));K1=list(map(q,base['K1']));K2=list(map(q,base['K2']));J=list(map(q,base['J']))
        Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)]
        q0=sum(nu[i]*K0[i] for i in range(6));qj=sum(nu[i]*J[i] for i in range(6));qs=sum(nu[i]*Q[i] for i in range(6));qv=max(q0,qj,qs)
        wg=[q(x['wg']) for x in atoms]; A=[q(x['A']) for x in atoms]
        good=[p*wg[i]<=q(pars['K'])*Q[i] for i in range(6)];Eplus=[good[i] and A[i]>0 for i in range(6)]
        T=q(der['T']);D=q(pars['D']);U=[min(T*A[i],D*K0[i]) if Eplus[i] else F(0) for i in range(6)]
        alpha=(D*qv-sum(nu[i]*U[i] for i in range(6)))/qj if qj else F(-1)
        rho=[max(F(0),1-(U[i]+alpha*J[i])/(T*A[i])) if Eplus[i] and T*A[i] else F(0) for i in range(6)]
        eg=sum(nu[i]*wg[i] for i in range(6));mu=[Q[i]*nu[i]/qv for i in range(6)]
        hard=sum(nu[i] for i,x in enumerate(atoms) if all(abs(q(y))<=F(1,2) for y in x['position']))
        gates={'lambda_identity':True,'hard_positive':hard>0,'hard_cap':hard<=4*qv,
          'high':p*eg>=2*q(pars['K'])*qv,'heavy':eg>q(der['ell'])*q(der['cj'])**(-n//2)*q(der['g'])**n*qv,
          'qJ_positive':qj>0,'alpha_nonnegative':alpha>=0,
          'FIRST_three':all(x<=qv for x in (q0,qs,qj)),
          'Hhat_less_Lplus':q(der['Hhat'])<q(der['Lplus'])}
        # Static source qualifications are copied from the original audited template.
        for name in ('strict_s','scale','tau_h_g'):
          gates[name]=bool(case['gates'][name])
        # FA windows: source profiles and delta are recomputed separately on each original score segment.
        active=[];B=q(pars['B_FA']);nameidx={x['name']:i for i,x in enumerate(atoms)}
        for pair in case['pairs']:
          vi=nameidx[pair['v']];ui=nameidx[pair['z_prime']]
          if not(good[vi] and not good[ui] and rho[vi]>0 and pair['Psi']):continue
          for si,seg in enumerate(case['score_segments']):
            prof=profile(seg);cv,kv=prof[vi];cu,ku=prof[ui];lo=q(seg['lo']);hi=q(seg['hi'])
            if kv<=ku or kv<=0 or lo>=hi:continue
            delta=F(kv-ku);Qv=Q[vi]
            if B*delta*p*cv/Qv>lo**kv:active.append((vi,ui,si,lo,hi,cv,kv,cu,ku,delta,Qv))
        first={}
        for cap in active:
          vi,ui,si,lo,hi,cv,kv,*_=cap
          if vi not in first or lo<first[vi][0]:first[vi]=(lo,si,cv,kv)
        N=2*n+3; CLo=F(0);CUp=F(0);maxeta=F(0);eta_cert=[]
        for v in range(6):
          elo,eup,bc=eta_bounds(case,nu,eg,good,v);maxeta=max(maxeta,elo);eta_cert.append((elo,eup,bc))
          if v in first and rho[v]>0 and eg>0:
            lo,si,cv,kv=first[v];w=cv*lo**(-kv)
            CLo+=2*N*nu[v]*rho[v]*w/eg*elo
            CUp+=2*N*nu[v]*rho[v]*w/eg*eup
        # Joint diagnostic: per-source maximum over actual cap-start right limits.
        joint={}
        for vi,ui,si,t,*rest in active:
          prof=profile(case['score_segments'][si]);cv,kv=prof[vi]
          e=sum(nu[i]*prof[i][0]*t**(-prof[i][1]) for i in range(6))
          ss=sum(nu[u]*prof[u][0]*t**(-prof[u][1])*(1-F(prof[u][1],kv)) for u in range(6) if not good[u] and prof[u][1]<kv)
          val=2*N*nu[vi]*rho[vi]*cv*t**(-kv)*ss/e**2
          joint[vi]=max(joint.get(vi,F(0)),val)
        JLo=sum(joint.values(),F(0))
        m=sum(mu[i] for i in range(6) if Eplus[i] and rho[i]>0)
        allrows.append({'template':tid,'n':n,'a':a,'b':b,'c':c,'q':iv(qv),'q_components':[iv(q0),iv(qs),iv(qj)],'eg':iv(eg),'alpha':iv(alpha),'rho':[iv(x) for x in rho],
          'hardmass':iv(hard),'gates':gates,'necessary_pass':all(gates.values()),'good':[int(x) for x in good],'m':iv(m),'M_rho':iv(sum(mu[i]*rho[i] for i in range(6) if Eplus[i] and rho[i]>0)),
          'fa_caps':len(active),'firstFA':{str(v):[fs(x) for x in z[:2]] for v,z in first.items()},
          'C_ell':[iv(CLo),iv(CUp)],'C_joint_diag':[iv(JLo),iv(CUp)],'eta_by_v':[[iv(x),iv(y),z] for x,y,z in eta_cert],
          'candidate':all(gates.values()) and bool(active) and CLo>1})
      print(stage,'done',flush=True)
    summary={}
    for tid in ('I1','P1'):
      rr=[r for r in allrows if r['template']==tid]
      summary[tid]={'count':len(rr),'necessary_pass':sum(r['necessary_pass'] for r in rr),'positive_FA':sum(r['fa_caps']>0 for r in rr),'C_ell_lower_gt_1':sum(q(r['C_ell'][0][0])>1 for r in rr),'candidate_count':sum(r['candidate'] for r in rr)}
    top=[]
    for tid in ('I1','P1'):
      rr=sorted((r for r in allrows if r['template']==tid and r['candidate']),key=lambda r:(-q(r['C_ell'][0][0]),r['a'],r['b'],r['c']))
      top.extend(rr[:3])
    out={'status':'completed','stage':args.stage,'attempt_count':attempts,'successful_count':len(allrows),'failed_count':0,'elapsed_seconds':round(time.time()-started,3),
      'inputs':{'R136_sha256':hashlib.sha256(P136.read_bytes()).hexdigest(),'R142_sha256':hashlib.sha256(P142.read_bytes()).hexdigest()},
      'model':'mp70 decimal kernel strings frozen as Fractions; Q=(K1+K2+J)/3; all nu-dependent quantities rebuilt',
      'plan_sha256':hashlib.sha256((ROOT/'numeric_plan.md').read_bytes()).hexdigest() if (ROOT/'numeric_plan.md').exists() else None,
      'producer_invocations_total':10,'producer_invocations_failed':2,'producer_invocations_completed':8,'adopted_result_invocation':10,
      'eta_certificate':'score-segment-local positive-coefficient polynomial box; exact endpoint lower witness; C bounds outward decimal rationals at 1e-10',
      'joint_diagnostic':'per-source exact cap-start lower limit; C_ell upper bound; diagnostic only',
      'summary':summary,'top3_per_template':[{'template':r['template'],'a':r['a'],'b':r['b'],'c':r['c'],'C_ell':r['C_ell'],'necessary_pass':r['necessary_pass']} for r in top],'point_checks':point_checks(top,cases,rec),'rows':allrows}
    outpath=ROOT/'mass_scan.json';outpath.write_text(json.dumps(out,separators=(',',':'))+'\n');print('wrote',outpath,outpath.stat().st_size)
if __name__=='__main__':main()
