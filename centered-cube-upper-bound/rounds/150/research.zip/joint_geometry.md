# R150：当前时间与容量见证错时的两种完整付款

状态：取得两种新的、任意原来源上可付的确定门。质量分层门 JG6 与当前/整窗容量几何均值门 JG11，各自完整费用均为一份 CₙΛ√n Wβ，Cₙ=O(log(2+n))。与旧 ℓ 门任取一种并集最多两份，三门全并最多三份。全剩余仍未闭合。原 α、ρ、三核 Q*、两后验、真实 dx 和全部资格保持原定义。

## JG1. 先核 GR12，并明确改变的估计顺序

实读本轮副本 r149_geometric_remainder.md。GR6 的 CS、GR7 平方消去 q/p/K、GR12 的 hard 系数32Λ/3和当前 e_t^{-2} 均代数成立，使用范围是原正有限域及零交通约定。其 bad 逆矩含 w_r(u)²/K₀(x-u)，而 good 端的 Q_x(v)²J(x-v) 属于另一来源 v；共同 Q_E 的来源也限制在 E₊，与 D₀ 互斥。不能把这些核按“同一接收 x”直接逐来源约掉。原 α 余额给的是 ∫D₀K₀dν，与 CS 后的逆矩相乘，并非每个 u 的核因子。

本稿因此回到 CS 之前的原 bad 后验，保留当前容量，不再上界 GR12 的逆矩。新估计直接支付原正交通的子支，所以不需要把两个时间 r,t 的 e 分母拼成同一个；也不声称 GR12 的整个正放松已经付款。这一顺序变化使见证错时成为可付的实际门，而非再定义一个逆矩。

## JG2. 原行、测度和准确目标

固定合法原行 (ω,V,j,x,y) 和实际窗口 [τ,h]。沿原值定义

\[
Q_v=Q_x^*(v),\quad d\mu(v)=Q_vd\nu(v)/q,
\quad E_+=S_g\cap\{\rho_v>0\},\quad m=\mu(E_+),
\]
\[
r_t(v)=\frac{KQ_v}{p w_t(v)},\quad
L_t=\frac{Kq}{p e_t},\quad L_g=\frac{Kq}{p e_g}\le\tfrac12,
\quad d\Pi_t=\frac{L_t}{r_t}1_{Z_t}d\mu.
\tag{JG1}
\]

Q 是原三个 n 维核的平均，ν 任意相关；不是重新选择核或重新归一化 μ。E₊、m、ρ、g 及所有实际参数整窗固定，且 E₊⊂Z_g⊂Z_t。原 ρ 保留同一 α 和 bad 储备。定义

\[
B_t(v)=\int_{D_0}\left(1-\frac{k_t(u)}{k_t(v)}\right)_+d\Pi_t(u),
\quad \mathfrak h_t(v)=L_tB_t(v),
\quad \ell_v=\mathop{\rm ess\,sup}_{\tau\le r\le h}\mathfrak h_r(v).
\tag{JG2}
\]

k_t(v)=0 时 B_t=𝔥_t=0。𝔥_t 来自同一原 bad 集和后验，不能依外 hard 来源 z；0≤𝔥_t≤ℓ_v≤L_g 几乎处处。ess sup 不需要可测选出见证时刻，不对其微分。

在证明上放松 Ψ、FA 和其他额外正门后，原两来源交通的准确上式是

\[
\int_{E_+}k_t(v)\frac{\rho_v}{r_t(v)}\mathfrak h_t(v)\,d\mu(v).
\tag{JG3}
\]

原未付正域 Ω 中这些门在定义时全部保留，正上界时才用≤1。所求的是 Ω 与新门相交的原完整时间、hard、dx、β、j 费用。旧 ℓ 门为 r_t≥2Nmρ_vℓ_v；新的有意义覆盖是各新门与其严格补集 r_t<2Nmρ_vℓ_v 的交集。

m=0、ρ=0、ℓ=0、e_g=0 等零交通情形先按原合同处理；非零行 e_g>0。本稿在原合法有限行上工作，e_t<∞，没有未定义的∞/∞。使用非负积分截断或 Tonelli 时，固定原 ν 以及全部 e_t、μ、m、ρ、ℓ 和 gate，只截断被积项；不得截断 ν 后重算归一量与 gate，再声称由单调收敛推广。一般无限行另依原既有合同处理，本稿不扩证。

## JG3. 唯一使用的时间通量身份

对固定 v∈E₊，置 z_t(v)=ρ_v/r_t(v)。原 w_t 连续且绝对连续，故 z_t 非增，并有

\[
-dz_t=k_t(v)z_t(v)\frac{dt}{t}.
\tag{JG4}
\]

对任意 c≥0，任何可测时间子集 I 均满足

\[
\int_I1_{\{z_t\le c\}}(-dz_t)
\le\min\{z_\tau,c\}-\min\{z_h,c\}\le c.
\tag{JG5}
\]

这里不微分 e_t；Z_t 导致的 e_t 跳变不影响 JG4。时间子集可以依实际 x、v、e_t、history，不要求为区间。每一次费用均基于原同一 z 轨迹，下面显式付清多层使用。

## JG4. 主门 Q：按总质量放大倍数分层

令 E_t=e_t/e_g≥1，并对 κ=0,1,2,…定义互斥时间层

\[
I_\kappa=\{t:2^\kappa\le E_t<2^{\kappa+1}\},\qquad
\gamma_\kappa=\frac1{(\kappa+1)(\kappa+2)},\qquad
f_\kappa=\frac{2^{-\kappa}}{\gamma_\kappa}.
\]

Σκγκ=1 为精确望远镜和，无需上界 e_τ/e_g 或限制层数。在 Iκ 上 L_t≤L_g2^{-κ}。定义确定的新门

\[
\boxed{\mathcal Q(t,v)=
\{r_t(v)\ge2Nm\rho_vL_g f_{\kappa(t)}\}.}
\tag{JG6}
\]

每条行、每层、每来源的阈值整窗固定；E₊ 与 m 不按层重新归一。用 B_t≤1、JG5 得

\[
\begin{aligned}
\int_{I_\kappa}\!\mathfrak h_t(v)1_{\mathcal Q}(-dz_t)
&\le L_g2^{-\kappa}
 \int1_{\{z_t\le\gamma_\kappa2^\kappa/(2NmL_g)\}}(-dz_t)\\
&\le\frac{\gamma_\kappa}{2Nm}.
\end{aligned}
\]

对同一 μ 积分，再将所有时间层非负相加，得到

\[
\boxed{\int_\tau^h\!\int_{E_+}
\mathfrak h_t(v)k_t(v)\frac{\rho_v}{r_t(v)}
1_{\mathcal Q}\,d\mu(v)\frac{dt}{t}
\le\sum_\kappa\frac{\gamma_\kappa}{2N}=\frac1{2N}.}
\tag{JG7}
\]

没有 log(e_τ/e_g) 或无限层费用遗漏。不同层确实重复使用同一 μ，但每层只获 γκ 份预算，完整费用已经相加。

原三核写法为

\[
\mathcal Q\iff Q_ve_g\ge2N\rho_vw_t(v)Q_E f_{\kappa(t)},
\qquad Q_E=\int_{E_+}Q_vd\nu.
\tag{JG8}
\]

q、p、K 消去，e_g、e_t、原来源、Q_E 和实际 ρ 未删除。相对旧 ℓ 门有潜在新增覆盖的准确条件是 L_g fκ<ℓ_v；例如 f₆=7/8、f₇=9/16，而 fκ→0。它处理当前 e_t 很大、当前 L_t 很小、但 ℓ_v 在另一个时间较大的情形。没有假定所有早时都通过新门。

## JG5. 主门 H：保留当前 bad 容量的单一积分包络

质量分层门只用当前 L_t；以下保留完整 𝔥_t=L_tB_t。固定 0<θ<1，定义

\[
\boxed{\mathcal H_\theta(t,v)=
\left\{r_t(v)\ge\frac{2Nm\rho_v}{1-\theta}
\ell_v^{1-\theta}\mathfrak h_t(v)^\theta\right\}.}
\tag{JG9}
\]

θ 必须在该次证明中共同固定，不逐来源或时间取并集优化。ℓ_v=0 或当前 𝔥_t=0 的正交通为零，先拆去。对其余来源令

\[
q_t=\mathfrak h_t/\ell_v\in(0,1],\qquad
c_v=\frac{1-\theta}{2Nm\ell_v}.
\]

门 JG9 等价于 z_t≤c_v q_t^{-θ}。因而逐时刻

\[
\mathfrak h_t1_{\mathcal H_\theta}
\le\ell_v\min\{1,(c_v/z_t)^{1/\theta}\}.
\]

即使 q_t 不单调，该点态不等式仍成立。以 JG4 变换单调通量，并在正上界中扩展 z 的积分区间，得到

\[
\begin{aligned}
\int\mathfrak h_t1_{\mathcal H_\theta}(-dz_t)
&\le\ell_v\int_0^\infty\min\{1,(c_v/z)^{1/\theta}\}\,dz\\
&=\ell_v c_v\left(1+\frac{\theta}{1-\theta}\right)
=\frac1{2Nm}.
\end{aligned}
\tag{JG10}
\]

积分包络仅用于证明原 gate，不改变原后验或引入另一份来源。对 μ 积分后仍是完整 1/(2N) 帽。本文确定选择 θ=1/2，得到

\[
\boxed{\mathcal H(t,v)=
\{r_t(v)\ge4Nm\rho_v\sqrt{\ell_v\mathfrak h_t(v)}\}.}
\tag{JG11}
\]

与旧门相比，新增覆盖仅可能出现在 𝔥_t<ℓ_v/4。这明确比较当前与整窗见证容量，不把晚时最大容量当作当前容量。𝔥_t 仍是原当前 bad 后验，不是人为权重。

若记 M_v=ess sup_r B_r(v)/e_r，则 ℓ_v=(Kq/p)M_v，JG11 有准确三核形式

\[
\boxed{Q_v\ge4N\rho_vw_t(v)Q_E
\sqrt{M_v B_t(v)/e_t}.}
\tag{JG12}
\]

所有参数取原同行值，未换 β/ν，没有使用 uniform α。

## JG6. 两门各自的真实接收外费

对 Q 或 H 单独，JG7 或 JG10 已给固定实际行的来源及整窗帽1/(2N)，不依外 hard z。仍保留原 aω 后用
q^{-1}∫h_R aωdν≤16/3，得到8/(3N)。到此才合并原唯一 j；不能在仍含 Π、ℓ 或时间层时提前删 j。原 p 是实际选择的 kernel，随后按 R148 的 softness 层支付连续 (s,L) 包络。

具体沿 R148：n<64 全取 N₀=2n+3；n≥64 在 d=1−s≤1/4 的互斥带取 N_k=(1+√nD_k)²，D_k=min(2^k/√n,1/4)，k=0,…,ceil(log₂(√n/4))；far 带 d>1/4 取 N₀。历史 CS10 给每个 near-soft 带 Env≤32√nN_k，故每门每带完整价为

\[
2\Lambda P_{\text{one gate},k}
\le\frac{16\Lambda}{3N_k}\operatorname{Env}_n(D_k)W_\beta
\le\frac{512}{3}\Lambda\sqrt nW_\beta.
\]

far 或小维用旧 JT13 给48Λ√n。定义

\[
B_n=\begin{cases}0,&n<64,\\1+\lceil\log_2(\sqrt n/4)\rceil,&n\ge64,\end{cases}
\qquad C_n=48+\frac{512}{3}B_n.
\]

两种新门分别满足

\[
\boxed{2\Lambda P(\Omega\cap\mathcal Q)\le C_n\Lambda\sqrt nW_\beta,
\qquad
2\Lambda P(\Omega\cap\mathcal H)\le C_n\Lambda\sqrt nW_\beta.}
\tag{JG13}
\]

Ω 允许任意原旧已付补集，因此也直接支付这两门在旧 ℓ 门严格补集中的新差集。实际 dx、β、原固定比例带及所有 Wβ 来源归集按旧合同保留；没有改 β 为 ν。时间已完整积分，不另乘 log2。所有 α/ρ 与原负项保持原位。

## JG7. 去重、总价与准确剩余

记旧 ℓ 门为 L={r_t≥2Nmρℓ_v}。单独登记 Q 或 H 是一份 JG13；将任意一种同 L 取并集，上价是两份 Cₙ。若三门都采用，则逐次只收尚未支付的差集，有

\[
\boxed{2\Lambda P(\Omega)
\le3C_n\Lambda\sqrt nW_\beta+
2\Lambda P\!\left(\Omega\cap
\left\{r_t<2Nm\rho_v
\min\!\left(\ell_v,L_gf_{\kappa(t)},
                  2\sqrt{\ell_v\mathfrak h_t(v)}\right)\right\}\right).}
\tag{JG14}
\]

这不是同一份预算免费支付三门的并集。若只采用旧 L 与新 Q，就删去 H 项、将3改2；若只采用 L 与新 H，同理。所有更早已经支付的 TOP、FA 高支、R147/R148 子支按原 ledger 去重，不重复领取。

JG14 的剩余仍保留全部原三核/来源/时间/接收几何。特别是在当前容量接近整窗最大值、且 e_t/e_g 不大时，两种门未必改善旧阈值。没有证明该补集为空或已付。本轮不新增自由 Q 反例、数值菜单或论文引理；新结果是可检验的确定门与其完整外价。
