# R150 固定真实几何质量扫描：独立核证

结论：最终1210模型及54个预声明内点检查通过。存在通过全部已实现必要门、但新固定ell全覆盖成本严格大于1的质量模型；选中I1的联合time-profile成本也严格大于1。结论限冻结的70位真实核有理模型，不认证FULL、真实核区间误差或dx外预算。

## 独立性与输入

独立程序为本目录 `mass_verify.py`，只用标准库，从原R136/R142 JSON及质量参数重新构造所有字段；没有import/re跑producer，无浮点核或新receiver抽样。精确输入SHA为R136 `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`、R142 `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`。冻结控制id0的mp70产品核值，Q精确重建为(K1+K2+J)/3；核不是自由参数。

审核期间阻断并要求修正了good-good代替good-bad、跨score段冻结首段c/k、m误含rho0来源、high公式漏K以及将跨端点盒下界称作端点下界等问题；所有早期输出作废。当前审核对象最终JSON SHA256为 `692b743ff06bfdd6e4015fb175ad07b57fbb8f5739fea0870c819ad58ad1f632`。producer登记10次调用、2次执行失败、8次完成，其中早期完成结果也经修订作废；本审查只采用最终第10次结果，不把历史执行次数当数学证据。

## 全菜单核验

逐项检查预声明集合恰为每模板121个(a,b)×5个c（含c=0），两模板合计1210个不同参数，无加样。每row重新归一化nu，核验q三容量、eg、alpha、rho、hardmass、m与M_rho的有理区间包含，动态high/heavy/hard/alpha门，原静态资格引用，以及good/bad。保持全部六源的共同e，逐真实score段用自己的c/k重建S、真实端点eta下界和正系数盒上界；不只用原FA的G4替代terminalbad。

36对原Psi、good-v/bad-u、正delta及FA不等式 `B_FA delta p w_v(t)>Q_v` 逐段重建，验证正长度与每source首端；C_ell的来源成本加权和上下方向通过。C_joint保存的cap首端下界也独立复核；它的上端仍用C_ell上端，跨1的诊断不得据此判小。

| 模板 | 模型数 | 必要门通过 | 通过必要门且正FA且C_ell下界>1 |
|---|---:|---:|---:|
| I1 n4 | 605 | 319 | 14 |
| P1 n16 | 605 | 506 | 67 |

这些是预声明质量模型计数，不是空间比例。I1初探已有(a,b,c)=(4,0,0)的合法必要模型C_ell约1.94455；选中最终top3的C_ell下界约3.77959、3.73883、3.73479。P1 top3的下界约83.6227，上界仍宽；下界>1已足够认证此固定ell门全覆盖成本不足，不声称得到其最优数值。

## 54内点与三门：点数和门分类分开

独立核对每模板按精确端点成本下界排序取top3、参数字典序决同值，未增加ν模型。每个实际正FA cap取预声明1/4、1/2、3/4点；所有实际有理t严格处于原score/FA开窗，代数FA截端向内近似及90次二分包围亦核验。

归一化R=r/Lg、eta_t=h/Lg、整窗eta=ell/Lg均从同一nu重建。固定门采用eta上界认证pass、下界认证fail；几何均值门先核非负再作精确平方比较；层门精确核2^l<=e/eg<2^(l+1)与原常数。保存的残差有理区间包围实际残差。

| 模板/点数 | fixed uniform | geometric mean | layer |
|---|---|---|---|
| I1：27点 | 27 fail | 27 fail | 27 fail |
| P1：27点 | 18 fail，9 unresolved | 18 fail，9 unresolved | 27 fail |

因此I1是81次门分类全部fail；P1是63 fail、18 unresolved，共81次门分类。P1的“21 fail+6 unresolved”只适用于每一条选中row（9点×3门），不能当P1总体。没有确定pass；unresolved不是fail。三门若并集仍按三份预算，不合并成一份。

## 一个正长度严格补集的解析证书

采用JSON `point_checks` 第一条I1参数(12,8,8)、G1→G4、segment0、fraction1。独立核：所有nu严格正，rho_G1>0、delta=4>0、原Psi成立、共同e>0、hardmass>0；有理t严格处于score段与原FA开窗。E=e/eg的保存精确包围为

    5.6122451822 <= E <= 5.6122451823，严格位于(4,8)，l=2。

固定门差、几何均值平方差、层门差的区间上端分别为

    −0.5363567577，−2.0652308101，−14.0473402366。

全部严格负；前两差使用eta下界，因此对真实整窗eta也严格失败。该score段内w、e、S、R均为正分母有理函数，连续；E严格避开2幂层边界，FA/score资格也严格。因此有限多个严格不等式在该点附近存在共同正长度时间邻域仍成立，原正交通密度rho delta Pi_v Pi_u严格正。由此在**同一冻结必要模型**中可登记“存在正长度原FA交通处于三门并集之外”。未给显式半径，不声称整个cap或整窗比例；这不是从point标签无条件外推。

## time-profile损失的额外精确诊断

对三条选中I1，所有有效正FA段为scores{0,4}。置z=t^-4，e=Az+B，terminalbad的S=C为常数，每source目标为c_v C z/(Az+B)^2。其导数符号恰B−Az，所以完整极值候选只有实际FA的两端及区间内的有理z=B/A；FA端的t^4由原核/参数给出有理数，故不需浮点开根。按source在全部实际cap取max，再求成本和，独立得到：

| I1参数(a,b,c) | 精确C_joint的向外1e-10区间 |
|---|---|
| (12,8,8) | [2.7288477752, 2.7288477753] |
| (16,12,8) | [2.6918535845, 2.6918535846] |
| (16,12,0) | [2.6878463206, 2.6878463207] |

全部严格大于1且在原C_joint诊断括区间内。这排除了这些记录“只因把w首端与ell全窗sup拆开而产生上帽缺口”的简单解释。C_joint仍只是一项联合上帽诊断，不登记移动门的FTC付款定理，不能作新增已付分支。

## 复现与边界

运行 `python3 rounds/150/work/mass_verify.py`，支持`--certificate`、`--input-root`。输出完整菜单核对、54point门分类、三条精确C_joint区间、正邻域见证与输入/结果/自身SHA。此程序不依赖producer代码或历史大JSON副本。

存在新必要模型余部不等于FULL反例，也不支付原forest/history、真实Z_t删除/top/light资格、连续FIRST、原beta/unique j和真实接收dx。真实核值冻结误差未做向外E3区间认证。此处数值工作完成停止。

## 父追加：原裸行完整FA时间量I（精确，不用C_joint替代）

在同一已选三条I1上，直接计算

    I=∫Σ_{原good,bad正delta与Psi/FA} rho_v delta_vu Pi_v Pi_u dt/t，

不乘outer p·hardmass/q。每个实际cap仍保留其原rho、Psi、正delta和实际FA截端，完整六源共同e。两score正pair的delta=d=4、z=t^-4，e=Az+B，故严格原函数给

    I_vu = rho_v nu_v nu_u c_v c_u (z_start−z_end)
           / [(A z_start+B)(A z_end+B)]。

这里z_start=lo^-4，z_end=max(score_hi^-4,Q_v/(B_FA delta p c_v))，全部有理；delta与dlogt变换中的4相消。各pair正性、真实FA截端及总和方向逐项验证。

| I1参数(a,b,c) | 精确2N I的向外1e-10区间（N=11） |
|---|---|
| (12,8,8) | [1.9213301914, 1.9213301915] |
| (16,12,8) | [1.8979467628, 1.8979467629] |
| (16,12,0) | [1.8955069003, 1.8955069004] |

三条均严格大于1。对应**完整实际时间profile本身**超过统一裸行1/(2N)帽；这比“新门留点外”更强，表明不能只改门的阈值形式便将这三条裸行全付为同一1/(2N)价，仍须接收外几何或另一个准确费用结构。这不是FULL或一般上界反例。

精确有理I与2NI分子/分母、逐pair有理积分及cap的z端点均保存于 `numeric_profile_certificate.json`，SHA256 `1d4bb66a86121cf818e196b1d9af11d86d9608b2e4752ebc4188637b642fd515`。复现命令：

    python3 rounds/150/work/mass_verify.py --profile-certificate rounds/150/work/numeric_profile_certificate.json

最终verifier SHA256 `2dd84c226ac1d8abadff70411396c977b607ca75d0551b1ed9b6d45910d92038`；该版已实际运行exit0/PASS，同时复核1210模型、54point、三条C_joint、严格正邻域见证与原裸行I。没有新增模型/接收点/时间网格或原179优化。审核交付完成停止。
