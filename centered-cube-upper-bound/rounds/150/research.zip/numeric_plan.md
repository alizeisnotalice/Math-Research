# R150 固定真实几何的共同质量扫描（待父审；未运行）

负责人仅写本计划、后续numeric_audit及必要独立verifier。不重复R149原179行，不新抽样接收点，不做dx积分。目标是寻找新ell整窗固定预算无法全覆盖的、通过原全部**已实现必要门**的新质量模型，并识别是否只是把时间相关量分别取sup造成的成本。

## 1. 已有入口及固定几何

核读R142 `numeric_receiver.py` 的Model构造、scan、traffic及mp_record。固定I1(n4)、P1(n16)原六源位置、x=(0,...,0)、y、s/L/Hhat/Lplus/b/R、K/D/T/B_FA、tau/h、threshold、score c/k和原未归一化后缀Psi。来源记录取R142每case的control id0；原ν以该case nu_exact为准，不能取R136默认质量。原源质量严格正、总和1。

输入：R136 active_traffic_v2.json（SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de），R142 numeric_receiver.json（SHAc46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55），可用目录 `/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/` 下相应round子目录。原producer只读，不import执行其main。

真实核固定为R142的E3产品核定义，p=P_s,L(x-y)，K0=P_s,Hhat(x-v)，K1=P_s,L(x-v)，K2=P_s,Lplus(x-v)，J=P_1,b(x-v)，Q=(K1+K2+J)/3；**不得以自由Q构造新反例**。最小实现可读取control的70位verifications核值，按十进制精确有理冻结p/K0/K1/K2/J，再精确重建Q；保留与原Q的舍入差。它是原真实核的高精度冻结模型，不是数学区间真核证书。若新候选接近任何关键门，必须标未决；需要声称对实际连续核严格成立时，另补E3向外包围，不能用100/160位一致性冒称区间。

## 2. 预声明三阶段质量菜单

记原ν=(ν0,...,ν5)，固定源名G1,G2,G3,G4,B,CORE。倍率是**固定源索引组**，不依据每个模型good/bad标签重新分组：

    raw_i = A*ν_i (i=0,1,2), Bmult*ν_3 (i=3), ν_4 (far), C*ν_5 (CORE);
    ν'_i=raw_i/sum raw.

A、Bmult、C全为2的整数次幂，有理精确，总质量恢复1。归一化前后的q/e/hardmass均同阶缩放，应显式检查所有应不变的比值，不能漏更新q或alpha分子。P1 far虽原菜单末期可有交通，仍不调其质量，避免另开维数。

阶段1：每模板C=1，a,b∈{-4,-2,0,2,4}，A=2^a、Bmult=2^b；25模型/模板，共50。

阶段2：每模板C=1，a,b取E={-16,-12,-8,-4,-2,0,2,4,8,12,16}，只执行阶段1以外96模型/模板，共192新增；累计242。

阶段3：每模板a,b取同一E，c∈{-16,-8,8,16}，C=2^c；484模型/模板，共968新增；累计**1210个不同质量模型**。阶段按顺序完整执行，不因命中/未命中更换参数；不继续扩展网格或接收位置。本菜单最多1210模型，核固定，主要代价为有理代数。原A=Bmult=C=1为新producer输入恢复控制，不重新做179菜单。

## 3. 每模型从原定义重建的字段和必要资格

逐ν'重算q0=Σν'K0，qJ=Σν'J，qstar=Σν'Q，q=max三者；eg=Σν'wg，共同e_t=Σν'c t^-k，mu_i=Q_iν'_i/q。新的ν代表新的整个输入模型，预声明lambda=q_ν'(x0)，因此当前单接收点的3lambda/4<=q<=lambda为符号恒等；不能拿原lambda舍入差排除控制。若将来扫描x，必须在每个ν模型固定该lambda，不能逐x重置。

good_i⇔p wg_i<=KQ_i，bad为补集；E=good且A_i>0，其中按原R136字段A_i=w_tau-w_h（须直接读/复核，不由wg替代）。U_i=min(T A_i,D K0_i)在E上，否则0；alpha=(Dq−Σν'U)/qJ；rho_i=[1−(U_i+alpha J_i)/(T A_i)]_+在E上。来源rho/alpha绝不能沿用旧值。固定几何下good/bad及Psi/FA核门理论上不依ν，仍逐模型按原定义求出并与此不变性核对；rho=0会改变实际正交通来源，不从原Gplus继承。

按原hard源支持重算hardmass=Σν' 1_{|x-v_i|_∞<=R/2}。重算并保存所有门：hardmass/R^n<=4lambda、hardmass>0、high p eg>=2Kq、heavy eg>ell_old cj^(-n/2)g^n q、qJ>0、alpha>=0、原strict_s/scale/tau/h/剩余几何资格、FIRST三测试。变量ell_old是R136原heavy参数，不与本轮ell_v混淆。所有失败门共现及首失败均保留，不把相关门称为独立原因。

从36对原Psi及各真实score段重建正delta、原FA端点（B_FA delta p c_v/Q_v）^(1/kv)截段，保留good/bad/rho资格；不得把旧690cap复制到新模型。FA根需要代数有理区间；支撑正长度即可确定正交通，不必为本轮预算判别重复求时间积分。每个source实际FA union的首端t_first取所有原正交通cap的最小有效起点，空交通成本0；完整e仍留全部六源。

## 4. 主要判别C_ell及共同矩记录

沿R149定义、**完整terminalbad而不是只取FA bad**：

    S_v(t)=Σterminalbad_u ν'_u c_u t^-ku (1−ku/kv)_+, kv=0时0;
    H_v(t)=L_t B_t(v)=(Kq/p)S_v(t)/e_t²;
    ell_v=sup整窗 H_v(t), eta_v=eg sup整窗 S_v/e²;
    bfull_v=2N ν'_v rho_v w_v(t_first)/eg * eta_v;
    C_ell=Σv bfull_v, N=2n+3.

不对a再次优化。C_ell.upper<=1为本固定ell门可全覆盖；C_ell.lower>1证明该门的最小全覆盖预算不足；区间跨1为未决，不以浮点大于1判失败。还须必要门全部通过、有正原FA交通才称“新合法必要模型严格补集候选”。C_ell>1不推出一般交通不可付。

同步保存m=Σ_{E+}mu、M_rho=Σ_{E+}mu rho、max eta、各source firstFA权、成本分解，以及首时/ell极值时刻的Pi_terminalbad、eligible bad、E_Pi k及score方差；这些都用同一nu'/共同e计算。共同矩只是诊断，若父有指定更精准矩请另冻结其定义，不能从结果临时命名。

## 5. 保留time-profile的联合成本诊断

为判别C_ell>1是否纯粹来自分别取sup，额外计算

    C_joint=2N Σv ν'_v rho_v sup_{t in 实际FA_union(v)} [w_v(t) S_v(t)/e_t²].

它保留同一t上的w_v和bad时间因子，且C_joint<=C_ell应严格核验。C_joint<=1<C_ell说明ell整窗上帽存在可见松弛；C_joint>1排除这一个联合逐source上帽的简单修复。**C_joint本身只作预算诊断，不声明移动门/多次进入时间集合已有同一份FTC付款定理**；该理论需另审。

不预设极值都在端点。每score段x=t^-d，e=P(x)、S为非负系数多项式；eta比值S/P²，joint比值c_v x^(kv/d)S/P²。候选含段端/FA边界单侧值与导数分子全部实根。原R149独立Bernstein系数符号法若严格同号即证单调；不成立时可用有理自适应盒上下界，不研发通用Sturm也可。对代数FA端点包围，并逐渐细分到预算分类不跨1，预算耗尽保留未决。只认证保存有理核模型。

## 6. 结果、审核与停止合同

每阶段保存每参数全部nu及重建字段的可复现简表、所有失败/未决，按阶段/模板报告通过必要门且有正交通的数量、C_ell>1候选数、C_joint对照以及最大预算参数；不得只报命中点。若阶段无C_ell>1候选，继续既定下一阶段；全部无命中照实报告。父审计划后再交Luna编码，最多固定1210模型，无新接收或dx实验。

独立审核不import producer：从原模板与参数重建nu/q/alpha/rho和门，从共同分母重建极值界；逐source核验C_ell乘权、FA首端与成本方向，再检查C_joint<=C_ell及候选合法必要资格。保存输入/archive/member/script/plan SHA、实际attempt/成功失败、精确恢复控制及最终证书。通用根库未触发或未审不能写已验证。

FULL明确缺项仍为原forest/history/a_omega门、真实Z_t删源/top/light资格、连续FIRST及beta/unique j外价。当前新模型至多是保持真三核几何的必要模型，不把必要门通过冒充FULL实例或一般上界反例。

## 7. 父审通过与三门后处理（实施冻结追加）

父已批准1210菜单及每新ν模型lambda=q(x0)合同。先跑完整菜单找必要门全通过、有正原FA且C_ell.lower>1的记录。然后**每模板按C_ell.lower降序取前三条**，相同值按(a,b,c)字典序升序；若不足三条则取实际数量。选择数最多6，不另开ν或x菜单。若无C_ell>1记录，三门后处理为空并报告，不挑失败必要门的模型补数。

三门均使用同一row N=2n+3、m=Σ_{E+}mu及rho（整行固定）；h_v(t)=L_tB_t(v)，ell_v=sup全窗h_v。父当前独审的新候选门是：

1. 固定ell的uniform分配门：r_v(t)>=2N m rho_v ell_v。
2. 几何均值门：r_v(t)>=4N m rho_v sqrt(ell_v h_v(t))；不要求h随时间单调。
3. 层门：E_t=e_t/eg，l为唯一整数2^l<=E_t<2^(l+1)，gamma_l=1/[(l+1)(l+2)]，门r_v(t)>=2N m rho_v Lg (l+1)(l+2)/2^l。

第1门是a=1/m版本；C_ell则是可优化固定a的全覆盖最小成本，二者不能混名。每门独立领一份父已审C预算；三门并集若报告覆盖，必须标费用为三份，不能只付一份。C_joint不是第4门，不将其<=1当成已付覆盖。

稳定精确比较可全用Lg归一化：

    R_v(t)=r_v/Lg=Q_v eg/(q w_v(t));
    eta_v(t)=h_v/Lg=eg S_v(t)/e_t²;
    eta_v=ell_v/Lg.

第1门比较R>=2N m rho eta；第2门先核两边非负，再比较R²>=(4N m rho)² eta_v eta_v(t)，不浮点sqrt；第3门比较R>=2N m rho (l+1)(l+2)/2^l。eta未知精确值时，上端给“确定通过”的足够条件，下端给“确定失败”的足够条件；跨界保持未决。层边界采用上述左闭右开；E>=1须与原e>=eg核对。

优先交付三门完整原FA时间覆盖的有理/代数区间证书（每score段还需按E=2^l分层），但不得为此无限扩工作。若实现成本超预算，先做固定point菜单：每入选row每个正FA cap，在其开区间内取1/4、1/2、3/4三个相对点，用代数FA端点向内有理近似确保t确在原窗；保存实际有理t、共同e、S/R及三门差值区间。没有确定内点时标未决，不外推或换窗口。point比较只表明这些点的分类，不称整窗覆盖率/残量；严格失败且远离所有边界的点可以进一步通过有理邻域证书证明正长度缺口，须另保存该邻域，不能由点值自动推断全时间。

后处理保存每模板入选参数和排序证据、每cap实际t/score/FA合法性、m/rho/eta界、E层与三门精确比较方向、是否费用三份的并集；不做非预声明“再找更强点”搜索。独立核证将从冻结真核有理值及ν倍率重建所有字段，再分别核验C_ell候选合法性和三门point/时间证书，不import producer。
