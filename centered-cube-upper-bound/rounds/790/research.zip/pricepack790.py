"""R790: source probe costs for actual right-parent demand after a visible arm."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


def total(xs):
    return sum(xs, F(0))


def grouped_demand(n, stage, original, geom):
    parents, records, base, cells, _, degrees, before = original.original_records(n, stage)
    scale = [geom.floor_log2(x.m) for x in parents]
    demands, direct, ungrouped = (defaultdict(lambda: defaultdict(F)) for _ in range(3))
    lambda_a = {}
    total_energy = F(0)
    for r in records:
        v = r.middle
        a, _, q = r.left
        b, _, qr = r.right
        g = b[0]
        assert q == qr == geom.floor_log2(degrees[v])
        key = a, q, scale[v], scale[g]
        value = base[0, r.left]
        assert lambda_a.setdefault(a, value) == value
        raw = parents[v].m * degrees[v] * r.mass
        total_energy += raw
        demands[key][g] += raw / value
        survival = F((a[0] + b[0] + v + len(a[1]) * len(b[1])) % 5, 4)
        # Independent cancellation from the true right mark and old actual degree.
        direct[key][g] += base[1, r.right] * parents[v].owner * survival / parents[v].m
        ungrouped[key][r] += raw / value
    assert demands == direct
    assert total(lambda_a[key[0]] * total(w.values()) for key, w in demands.items()) == total_energy
    return parents, records, lambda_a, demands, ungrouped, total_energy, cells, before


def source_geometry(n, parents, tags, geom):
    cuts = sorted({parents[g].c + side * parents[g].s for g in tags for side in (-1, 1)})
    radii = sorted({F(0)} | {parents[g].s for g in tags})
    lines = []
    true_members = defaultdict(F)
    lebesgue = defaultdict(F)
    low = {g: parents[g].c - parents[g].s for g in tags}
    high = {g: parents[g].c + parents[g].s for g in tags}
    for lo, hi in zip(cuts, cuts[1:]):
        covering = tuple(g for g in tags if low[g] <= lo < hi <= high[g])
        if covering:
            lines.append((lo, hi, covering))
            for a, b in zip(radii, radii[1:]):
                actual = tuple(g for g in covering if b <= parents[g].s)
                if actual:
                    size = (2 * b)**(n - 1) - (2 * a)**(n - 1)
                    true_members[actual] += geom.price(lo, hi) * size
                    lebesgue[actual] += (hi - lo) * size
    bound = {g: [j for j, (_, _, M) in enumerate(lines) if g in M] for g in tags}
    assert all(cells == list(range(min(cells), max(cells) + 1)) for cells in bound.values())
    # With this fixture, even endpoints are dominated by positive price cells.
    for x in cuts:
        closed = {g for g in tags if low[g] <= x <= high[g]}
        if closed:
            assert any(closed <= set(c) for _, _, c in lines)
    for i, j in product(tags, repeat=2):
        assert total(mu for cell, mu in true_members.items() if i in cell and j in cell) == (
            geom.intersection(parents[i], parents[j], n))
    return lines, bound, true_members, lebesgue


def exact_cover(parents, tags, lines, bound):
    # Raise the deficit at the rightmost possible probe of each true interval.
    probe_mass = defaultdict(F)
    for g in sorted(tags, key=lambda g: (max(bound[g]), min(bound[g]), g)):
        deficit = parents[g].m - total(probe_mass.get(j, F(0)) for j in bound[g])
        if deficit > 0:
            probe_mass[max(bound[g])] += deficit
    cover = {g: total(probe_mass.get(j, F(0)) for j in bound[g]) for g in tags}
    assert all(cover[g] >= parents[g].m for g in tags)
    cost = total(probe_mass.values())
    # Independent exact dual. Nonzero dual weights only on mutually disjoint
    # original labels. Enumerate the very small family to find a certificate.
    dual = []
    for size in range(1, len(tags) + 1):
        for selected in combinations(tags, size):
            if all(sum(g in members for g in selected) <= 1 for _, _, members in lines):
                dual.append((total(parents[g].m for g in selected), selected))
    optimum, witness = max(dual)
    assert cost == optimum
    return probe_mass, cover, cost, witness


def support_by_member(lines, measures):
    out = defaultdict(F)
    for j, mass in measures.items():
        out[lines[j][2]] += mass
    return out


def evaluate(measure, W, old_records, parents):
    reached = {g: total(mass for labels, mass in measure.items() if g in labels) for g in W}
    by_arm = total(W[g] * reach / parents[g].m for g, reach in reached.items())
    by_price = total(mass * total(W[g] / parents[g].m for g in tags)
                     for tags, mass in measure.items())
    raw_by_price = total(mass * total(value / parents[r.right[0][0]].m
                                      for r, value in old_records.items() if r.right[0][0] in tags)
                         for tags, mass in measure.items())
    paid = total(W[g] * min(F(1), reach / parents[g].m) for g, reach in reached.items())
    assert by_arm == by_price == raw_by_price > 0
    assert paid == total(W.values()) and paid <= by_arm
    return dict(cost=total(measure.values()), captured_by_parent=reached,
                linear_checked_both_orders=by_arm, actual_capped_payment=paid,
                linear_per_unit_probe_mass=by_arm / total(measure.values()))


def best_fixed_points(lines, W):
    def candidate(choice):
        covered = set().union(*(set(lines[i][2]) for i in choice))
        return total(W[i] for i in covered), choice

    one = max(candidate((j,)) for j in range(len(lines)))
    two = max(candidate(ids) for count in range(1, min(2, len(lines)) + 1)
              for ids in combinations(range(len(lines)), count))
    assert 0 < one[0] <= two[0] <= total(W.values())
    return one, two


def realizations(n, parents, lines, cover, geom):
    period = F(1, 16)
    radius = min(x.s for x in parents) / 2
    rows = []
    for j, weight in sorted(cover.items()):
        lo, hi, labels = lines[j]
        assert lo % period == 0 and hi - lo >= period
        # A strictly interior high-density half-period provides a genuine AC
        # implementation of the same finite probe weights.
        a, b = lo + period * F(5, 8), lo + period * F(7, 8)
        x = (a + b) / 2
        assert lo < a < x < b < hi
        actual_mu = geom.price(a, b) * (2 * radius)**(n - 1)
        actual_lebesgue = (b - a) * (2 * radius)**(n - 1)
        assert actual_mu == F(3, 2) * actual_lebesgue > 0
        ac_weight = weight / actual_mu
        assert ac_weight * actual_mu == weight
        rows.append(dict(point_first_coordinate=x, other_point_coordinates_zero=True,
                         true_probe_parents=labels, weight=weight,
                         equivalent_AC_box_first_coordinate=[a, b],
                         equivalent_AC_box_passive_radius=radius,
                         actual_mu_of_box=actual_mu, true_Leb_of_box=actual_lebesgue,
                         AC_density_relative_to_mu=ac_weight))
    return rows


def group(n, parents, key, W, geometry, old_records, lam, geom):
    labels = tuple(sorted(W))
    lines, bound, cells, lebesgue = geometry
    opt_weights, quotas, atom_cost, dual = exact_cover(parents, labels, lines, bound)
    separate = {tags: len(tags) * mass for tags, mass in cells.items()}
    fractional = support_by_member(lines, opt_weights)
    assert total(separate.values()) == total(parents[g].m for g in labels)
    assert all(sum(m for tags, m in cells.items() if g in tags) == parents[g].m for g in labels)
    assert total(fractional.values()) == atom_cost <= total(cells.values()) <= total(separate.values())
    additive = evaluate(separate, W, old_records, parents)
    union = evaluate(cells, W, old_records, parents)
    optimum = evaluate(fractional, W, old_records, parents)
    assert optimum["captured_by_parent"] == quotas
    assert union["linear_checked_both_orders"] == total(W.values())
    one, two = best_fixed_points(lines, W)
    a, q, d, h = key
    return dict(
        left_mark=a, actual_degree_q=q, middle_D_bin_power=d, right_G_bin_power=h,
        lambda_a=lam, right_parents=list(labels), true_m_by_right_parent={g: parents[g].m for g in labels},
        right_parent_demand_W_over_left_base=W, total_W=total(W.values()),
        geometric_union_Leb=total(lebesgue.values()),
        per_parent_sum=additive, true_mu_union=union, optimal_shared_probe=optimum,
        primal_cover_points_and_equivalent_AC=realizations(n, parents, lines, opt_weights, geom),
        dual_one_on_labels=dual,
        best_single_point_capture_W=one[0], best_two_points_capture_W=two[0],
        best_single_support=lines[one[1][0]], best_two_supports=[lines[j] for j in two[1]])


def case(n, stage, original, geom):
    parents, records, lam, W, raw, energy, numcells, old = grouped_demand(n, stage, original, geom)

    @cache
    def cached(labels):
        return source_geometry(n, parents, labels, geom)

    counts = Counter()
    witness = {}
    rows = []
    for key, demands in W.items():
        shape = cached(tuple(sorted(demands)))
        row = group(n, parents, key, demands, shape, raw[key], lam[key[0]], geom)
        rows.append(row)
        approx, union, exact = (row[k]["cost"] for k in ("per_parent_sum", "true_mu_union",
                                                         "optimal_shared_probe"))
        counts["all"] += 1
        counts["multiple_right_labels"] += len(demands) > 1
        counts["actual_union_strictly_cheaper_than_sum"] += union < approx
        counts["shared_probe_strictly_cheaper_than_union"] += exact < union
        counts["strict_both"] += exact < union < approx
        counts["two_points_strictly_better_than_one"] += (
            row["best_two_points_capture_W"] > row["best_single_point_capture_W"])
        counts["two_points_cover_all_right_labels"] += row["best_two_points_capture_W"] == row["total_W"]
        if len(demands) > 1 and "multi_label_without_any_sharing" not in witness and exact == approx:
            witness["multi_label_without_any_sharing"] = row
        if exact < union < approx:
            current = witness.get("strongest_fractional_saving_over_union")
            if current is None or exact / union < (
                    current["optimal_shared_probe"]["cost"] / current["true_mu_union"]["cost"]):
                witness["strongest_fractional_saving_over_union"] = row
        if exact < union < approx and row["best_two_points_capture_W"] > row["best_single_point_capture_W"]:
            current = witness.get("both_shared_families_and_two_probe_gain")
            if current is None or row["best_single_point_capture_W"] / row["total_W"] < (
                    current["best_single_point_capture_W"] / current["total_W"]):
                witness["both_shared_families_and_two_probe_gain"] = row
    totals = {k: total(row[k]["cost"] for row in rows)
              for k in ("per_parent_sum", "true_mu_union", "optimal_shared_probe")}
    assert totals["optimal_shared_probe"] < totals["true_mu_union"] < totals["per_parent_sum"]
    assert counts["strict_both"] > 0 and counts["two_points_strictly_better_than_one"] > 0
    assert "multi_label_without_any_sharing" in witness
    return dict(n=n, actual_parent_count=len(parents), positive_original_R=len(records),
                n_true_price_cells=numcells, actual_ungated_original_Q=old,
                total_true_M_v_weighted_R=energy,
                count_by_savings_and_point_hit=counts, exact_checked_witnesses=witness,
                geometry_family_count=cached.cache_info().currsize,
                descriptive_totals_over_keys=totals,
                these_totals_count_each_diagnostic_key_as_one_problem=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry-dir", type=Path)
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    opt = parser.parse_args()
    if opt.geometry_dir:
        sys.path.insert(0, str(opt.geometry_dir))
    import core789 as original
    import merges789 as geom
    result = dict(
        arithmetic="Exact Fraction; zero roundoff",
        python={"executable":sys.executable, "version":platform.python_version(),
                "architecture":platform.machine()},
        command="python -B pricepack790.py --check pricepack790.json",
        dependencies={name:sha256(Path(module.__file__).read_bytes()).hexdigest()
                      for name, module in (("core789.py", original), ("merges789.py", geom))},
        scope=("R789 nonproduct original records with actual full degree and nonuniform true prices. "
               "Each selected left mark, q, D, G key is a separate diagnostic problem. "
               "The finite probe measure has freely chosen masses. Its listed atoms can be "
               "replaced by normalized actual AC price in one positive piece of the same membership cell. "
               "D and G are frozen volume bins. Integers count selectable probe locations; "
               "their objective is physical right-parent demand captured at least once."),
        cases=[case(n, stage, original, geom) for stage,n in enumerate((4,8,16), 1)])
    result_bytes=(json.dumps(result, sort_keys=True, indent=2, default=str)+"\n").encode()
    if opt.output:
        opt.output.write_bytes(result_bytes)
    elif opt.check:
        if opt.check.read_bytes() != result_bytes:
            raise SystemExit("certificate differs")
        print("pricepack790: fixed left demand, true source coverage and primal-dual costs agree")
    else:
        print(result_bytes.decode(), end="")


if __name__=="__main__":
    main()

