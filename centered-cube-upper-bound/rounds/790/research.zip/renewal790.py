"""R790: exact source-overlap renewal on stationary two-arm peak records."""

import argparse
from bisect import bisect_right
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys


def total(xs):
    return sum(xs, F(0))


def side_mark(record, side, keep_layer):
    arm, level, q = record.left if side == 0 else record.right
    return (arm, level, q) if keep_layer else (arm, q)


def scale_level(record):
    return record.left[1], record.right[1]


def conditional_shift(records, parents, side, delta, keep_layer=False):
    """Randomize uniformly over the true record's rank interval; shift mod 1."""
    fibers = defaultdict(list)
    for k, rec in enumerate(records):
        fibers[side_mark(rec, side, keep_layer)].append(k)
    P = [{} for _ in records]
    for block in fibers.values():
        order = sorted(block, key=lambda i: (parents[records[i].middle].m, records[i].middle, i))
        end = [F(0)]
        for i in order:
            end.append(end[-1] + records[i].mass)
        M = end[-1]
        shift = delta * M
        for k, i in enumerate(order):
            raw = defaultdict(F)
            for wrap in (-M, F(0), M):
                lo = max(F(0), end[k] + shift + wrap)
                hi = min(M, end[k + 1] + shift + wrap)
                if lo >= hi:
                    continue
                l = bisect_right(end, lo) - 1
                while end[l] < hi:
                    raw[order[l]] += min(hi, end[l + 1]) - max(lo, end[l])
                    l += 1
            assert sum(raw.values()) == records[i].mass
            P[i] = {j: w / records[i].mass for j, w in raw.items()}
    check = [F(0)] * len(records)
    for i, row in enumerate(P):
        for j, p in row.items():
            assert side_mark(records[i], side, keep_layer) == side_mark(records[j], side, keep_layer)
            check[j] += records[i].mass * p
    assert check == [r.mass for r in records]
    return P, fibers


def exact_adjoint(Fwd, Back, weights):
    for (A, B) in ((Fwd, Back), (Back, Fwd)):
        for i, row in enumerate(A):
            for j, p in row.items():
                assert weights[i] * p == weights[j] * B[j].get(i, F(0))


def root_tag(r):
    return r.middle, scale_level(r)


def one_step(K, records, weights):
    G = defaultdict(F)
    cross_entry = F(0)
    for i, row in enumerate(K):
        for j, p in row.items():
            a, b = records[i], records[j]
            amount = weights[i] * p
            cross_entry += amount if scale_level(a) != scale_level(b) else 0
            G[a.middle, b.middle] += amount
    assert total(G.values()) == 1
    return G, cross_entry


def two_steps(L, R, records, weights):
    # Aggregate the incoming physical midparent and first entry at each actual
    # intermediate record, then the outgoing law. No triple-record sweep.
    inflow_tags = [defaultdict(F) for _ in records]
    out_tags = [defaultdict(F) for _ in records]
    for i, (row_l, row_r) in enumerate(zip(L, R)):
        for j, a in row_l.items():
            inflow_tags[j][root_tag(records[i])] += weights[i] * a
        for k, b in row_r.items():
            out_tags[i][root_tag(records[k])] += b
    G = defaultdict(F)
    cross_entry = F(0)
    partial = []
    for j, (incoming, outgoing) in enumerate(zip(inflow_tags, out_tags)):
        assert total(incoming.values()) == weights[j]
        assert total(outgoing.values()) == 1
        p, q = defaultdict(F), defaultdict(F)
        for (v, lev), a in incoming.items():
            p[v] += a
            for (w, endlev), b in outgoing.items():
                if lev != endlev:
                    cross_entry += a * b
        for (w, _), b in outgoing.items():
            q[w] += b
        for v, w in product(p, q):
            G[v, w] += p[v] * q[w]
        partial.append((records[j].middle, p, q))
    assert total(G.values()) == 1
    start = defaultdict(F)
    end = defaultdict(F)
    target = defaultdict(F)
    for (v, w), a in G.items():
        start[v] += a
        end[w] += a
    for r, a in zip(records, weights):
        target[r.middle] += a
    assert start == end == target
    return G, partial, cross_entry


def price_cells(n, parents, labels, geom):
    endpoints = sorted({parents[i].c + s * parents[i].s for i in labels for s in (-1, 1)})
    radii = sorted({F(0)} | {parents[i].s for i in labels})
    cells = defaultdict(F)
    for x, y in zip(endpoints, endpoints[1:]):
        for r, s in zip(radii, radii[1:]):
            mask = tuple(i for i in labels if s <= parents[i].s and
                         parents[i].c - parents[i].s <= x < y <= parents[i].c + parents[i].s)
            if mask:
                cells[mask] += geom.price(x, y) * ((2 * s)**(n - 1) - (2 * r)**(n - 1))
    return cells


def pair_overlap(G, J, m):
    start = total(a * J[v, w] / m[v] for (v, w), a in G.items())
    end = total(a * J[v, w] / m[w] for (v, w), a in G.items())
    upper = total(a * J[v, w] / min(m[v], m[w]) for (v, w), a in G.items())
    return start, end, upper


def measure_overlap(cells, partial, m):
    start = end = min_upper = one = union = intersection = F(0)
    for members, mu in cells.items():
        order = sorted(members, key=lambda v: (m[v], v))
        inv = {i: 1 / m[i] for i in order}
        local_start = local_end = local_min = local_one = local_union = local_intersection = F(0)
        for j, p, q in partial:
            ap = [(i, p.get(i, 0), q.get(i, 0)) for i in order]
            left = total(x for _, x, _ in ap)
            if left == 0:
                continue
            right = total(y for _, _, y in ap)
            old = total(x * inv[i] for i, x, _ in ap)
            new = total(y * inv[i] for i, _, y in ap)
            local_start += old * right
            local_end += left * new
            if j in inv:
                local_one += old
                local_union += old
                local_intersection += old * right
            else:
                local_union += old * right
            # Run backward in actual volume order; smaller endpoint pays.
            beyond_left = beyond_right = F(0)
            for i, x, y in reversed(ap):
                local_min += inv[i] * (x*y + x*beyond_right + y*beyond_left)
                beyond_left += x
                beyond_right += y
        start += mu * local_start
        end += mu * local_end
        min_upper += mu * local_min
        one += mu * local_one
        union += mu * local_union
        intersection += mu * local_intersection
    assert union == one + start - intersection
    return start, end, min_upper, one, union, intersection


def comparison(G, J, m, cross_entry):
    old, new, upper = pair_overlap(G, J, m)
    return dict(
        successive_source_draw_hit_original_denominator=old,
        reversed_denominator_same_order=new,
        upper_using_smaller_denominator=upper,
        excess_of_smaller_denominator_over_original=upper - old,
        probability_final_physical_parent_changes=total(a for (v, w), a in G.items() if v != w),
        probability_final_volume_increases=total(a for (v, w), a in G.items() if m[v] < m[w]),
        probability_true_first_entry_layer_changes=cross_entry)


def case(n, stage, original, geom):
    parents, rec, _, full_cells, epochs, degrees, peak = original.original_records(n, stage)
    R = total(r.mass for r in rec)
    pi = [r.mass / R for r in rec]
    assert sum(pi) == 1
    size = [p.m for p in parents]
    actual = sorted({r.middle for r in rec})
    coords = price_cells(n, parents, actual, geom)
    J = {(v, w): geom.intersection(parents[v], parents[w], n) for v, w in product(actual, repeat=2)}
    for (v, w), mass in J.items():
        assert total(mu for cell, mu in coords.items() if v in cell and w in cell) == mass
    delta = F(1, 4)
    L, lf = conditional_shift(rec, parents, 0, delta)
    K, rf = conditional_shift(rec, parents, 1, delta)
    LL, _ = conditional_shift(rec, parents, 0, -delta)
    KK, _ = conditional_shift(rec, parents, 1, -delta)
    exact_adjoint(L, LL, pi)
    exact_adjoint(K, KK, pi)

    G1, cross1 = one_step(L, rec, pi)
    G2, middle, cross2 = two_steps(L, K, rec, pi)
    GR, reverse_middle, reverse_cross = two_steps(KK, LL, rec, pi)
    # Exact reverse-order transpose on the aggregated true physical parents.
    assert G2 == {(w, v): a for (v, w), a in GR.items()}
    assert reverse_cross == cross2
    by_pair = pair_overlap(G2, J, size)
    first, last, capped, one, union, both = measure_overlap(coords, middle, size)
    assert (first, last, capped) == by_pair
    assert one == pair_overlap(G1, J, size)[0]
    assert 0 < both <= min(first, one) <= max(first, one) <= union <= 1
    reverse_pairs = pair_overlap(GR, J, size)
    assert measure_overlap(coords, reverse_middle, size)[:3] == reverse_pairs
    assert reverse_pairs == (last, first, capped)
    assert capped > max(first, last)
    unequal = [(v, w, u) for (v, w), u in G2.items() if size[v] != size[w] and J[v, w] > 0]
    assert unequal
    sample = max(unequal, key=lambda x: x[-1])
    v, w, mass = sample
    # Two-step count when still requiring the original first-entry label.
    WL, Lfp = conditional_shift(rec, parents, 0, delta, keep_layer=True)
    WR, Rfp = conditional_shift(rec, parents, 1, delta, keep_layer=True)
    GF, _, cross_fine = two_steps(WL, WR, rec, pi)
    assert cross_fine == 0
    fine = comparison(GF, J, size, cross_fine)
    cgroup = [sum(len({scale_level(rec[i]) for i in ids}) > 1 for ids in fs.values())
              for fs in (lf, rf)]
    return dict(
        n=n, frozen_nonproduct_original_R_mass=R, original_unscreened_peak_mass=peak,
        physical_parent_count=len(parents), original_true_price_cells=full_cells,
        actual_center_count=len(actual), actual_membership_cells_for_renewal=len(coords),
        real_degree_bins_count=len({r.left[2] for r in rec}), epochs=epochs,
        true_original_record_count=len(rec), delta=delta,
        coarse_L_R_node_counts=[len(lf), len(rf)], original_first_entry_node_counts=[len(Lfp), len(Rfp)],
        coarse_nodes_that_merge_actual_first_entry_layers=cgroup,
        coarse_one_step=comparison(G1, J, size, cross1),
        coarse_two_step=comparison(G2, J, size, cross2),
        joint_one_or_two_hits_on_same_true_original_source_draw=union,
        joint_both_hits_on_same_true_original_source_draw=both,
        coarse_reverse_right_then_left_one_sided_fractions=list(reverse_pairs),
        fine_two_step_preserving_actual_first_entry_node=fine,
        two_step_current_hit_raw_mass=R * first,
        unequal_size_sample_with_forward_and_other_denominator=dict(
            v=v, w=w, normalized_pair_path_probability=mass, m_v=size[v], m_w=size[w],
            exact_intersection=J[v, w], true_common_source_fraction_by_origin=J[v,w]/size[v],
            other_common_source_fraction=J[v,w]/size[w]),
        maximum_physical_parent_joint_asymmetry=max(
            abs(a-G2.get((w,v), F(0))) for (v,w),a in G2.items()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--geometry-dir", type=Path,
                        help="directory with unchanged core789.py and merges789.py; defaults to normal import search")
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    args = parser.parse_args()
    if args.geometry_dir:
        sys.path.insert(0, str(args.geometry_dir))
    import core789 as original
    import merges789 as geom
    dependencies = {p: sha256(Path(module.__file__).read_bytes()).hexdigest()
                    for p, module in (("core789.py", original), ("merges789.py", geom))}
    result = dict(
        arithmetic="Exact Fraction, no floating point",
        python={"executable":sys.executable, "version":platform.python_version(),
                "architecture":platform.machine()},
        portable_command="python -B renewal790.py --check renewal790.json",
        local_option="--geometry-dir PATH to the unchanged R789 geometry scripts",
        same_directory_dependency_hashes=dependencies,
        scope=("R789 finite true cubes and their nonuniform AC prices. Use the fixed "
               "nonproduct residual R with true full degree, before R789's pruning. "
               "Positive shifts at fixed real (arm,q) choose entire records. q is the "
               "actual degree bin. Source redraw at the original middle parent is "
               "independent of the path, and the same point is used for both tested hits. "
               "Finite diagnostic hard and marking gates apply."),
        cases=[case(n, j, original, geom) for j, n in enumerate((4, 8, 16), 1)])
    data = (json.dumps(result, sort_keys=True, indent=2, default=str) + "\n").encode()
    if args.output:
        args.output.write_bytes(data)
    elif args.check:
        if args.check.read_bytes() != data:
            raise SystemExit("certificate differs")
        print("renewal790: true stationary paths, source cells and reverse denominators agree")
    else:
        print(data.decode(), end="")


if __name__ == "__main__":
    main()

