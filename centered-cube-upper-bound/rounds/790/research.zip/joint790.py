"""Check the product receiver envelope on the actual marked conditional price traffic."""
import argparse
import json
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import product
from pathlib import Path

import core789
import merges789 as geom
from lens790 import cap
from pricepack790 import grouped_demand

def contains(p, point):
    x, tail = point
    return abs(x-p.c)<=p.s and abs(tail)<=p.s

def probes(parents, n):
    points=set()
    for p in parents:
        for side,radial in product((-1,0,1),(-1,0,1)):
            points.add((p.c+side*F(7,8)*p.s+F(1,4096),radial*F(7,8)*p.s+F(1,4096)))
    return sorted(points)

def shifted(i,j,d):
    l,r=i
    a,b=j
    return sum(max(F(0),min(r+d+k,b)-max(l+d+k,a)) for k in (-1,0,1))

def band(i,j,L,H):
    cuts={L,H}
    for c,d,k in product(i,j,(-1,0,1)):
        switch=d-c-k
        if L<switch<H:
            cuts.add(switch)
    grid=sorted(cuts)
    return sum((r-l)*(shifted(i,j,l)+shifted(i,j,r))/2 for l,r in zip(grid,grid[1:]))/(H-L)

def smooth_check(records, parents):
    theta=F(1,8)
    checks=[]
    for side in (0,1):
        nodes=defaultdict(list)
        for num,r in enumerate(records):
            arm,_,q=(r.left,r.right)[side]
            nodes[arm,q].append(num)
        use=max((group for group in nodes.values() if 2<=len(group)<=12),key=len)
        order=sorted(use,key=lambda j:(parents[records[j].middle].m,records[j].middle,j))
        tot=sum(records[j].mass for j in order)
        ends=[F(0)]
        for j in order:
            ends.append(ends[-1]+records[j].mass/tot)
        intervals=list(zip(ends,ends[1:]))
        mass=[r-l for l,r in intervals]
        P=[[band(i,j,theta,2*theta) for j in intervals] for i in intervals]
        assert all(sum(P[i])==p and sum(row[i] for row in P)==p for i,p in enumerate(mass))
        top=F(0)
        fixed=F(0)
        for i,j in product(range(len(order)),repeat=2):
            assert P[i][j]==band(intervals[j],intervals[i],-2*theta,-theta)
            top=max(top,P[i][j]/(mass[i]*mass[j]))
            fixed=max(fixed,shifted(intervals[i],intervals[j],theta)/(mass[i]*mass[j]))
        assert top<=1/theta
        checks.append(dict(side=side,records=len(order),theta=str(theta),max_smooth_density=str(top),max_fixed_density=str(fixed)))
    return checks

def case(n, stage):
    parents, records, lam, W, _, _, _, _ = grouped_demand(n,stage,core789,geom)
    ids=range(len(parents))
    down={v:{u for u in ids if parents[u].m<parents[v].m and
              0<geom.intersection(parents[u], parents[v], n)<=F(3,4)*parents[u].m} for v in ids}
    bounds=sorted({p.c+sg*p.s for p in parents for sg in (-1,1)})
    radii=sorted({F(0)}|{p.s for p in parents})
    marks=defaultdict(list)
    dilation=16384
    for (l,r),(a,b) in product(zip(bounds,bounds[1:]),zip(radii,radii[1:])):
        y=( (l+r)/2,(a+b)/2 )
        member={i for i,p in enumerate(parents) if contains(p,y)}
        for u in member:
            marks[u,tuple(sorted(v for v in member if u in down[v]))].append(y)
        assert all((k*dilation).denominator==1 for k in (l,r,a,b,*y))
        assert geom.price(l,r)==r-l
    xs=probes(parents,n)
    scales={geom.floor_log2(p.m) for p in parents}
    rad={d:(1+F(1,32*n))*max(p.s for p in parents if geom.floor_log2(p.m)==d)
         for d in scales}
    for x,tail in xs:
        assert all((v*dilation).denominator==1 for v in (x,tail))
        for p in parents:
            assert min(abs(abs(x-p.c)-p.s),abs(abs(tail)-p.s))*dilation>=2
    @cache
    def axis(i,j,x):
        return cap(x,rad[i],rad[j])
    tested=nonzero=small=0
    largest=F(0)
    mins=F(1)
    maxs=F(0)
    for (arm,q,d,g), weights in W.items():
        ylist=sorted(marks[arm])
        for y in set((ylist[0],ylist[-1])):
            for x in xs:
                value=sum((w/parents[i].m for i,w in weights.items() if contains(parents[i],x)),F(0))
                factor=axis(d,g,x[0]-y[0])*axis(d,g,x[1]-y[1])**(n-1)
                bound=F(3,4)*(2*rad[d])**n*(2*rad[g])**n/F(2)**(d+g)*factor
                assert 0<=value<=bound
                tested+=1
                if value:
                    nonzero+=1
                    small+=factor<F(3,4)
                    mins=min(mins,factor)
                    maxs=max(maxs,factor)
                    largest=max(largest,value/bound)
    assert tested>nonzero>small>0 and 0<mins<maxs<=1 and 0<largest<1
    return dict(n=n,smooth_rank_examples=smooth_check(records,parents),condition_groups=len(W),physical_test_pairs=tested,
                positive_traffic=nonzero,positive_with_product_below_three_quarters=small,
                smallest_positive_traffic_product=str(mins),largest_positive_traffic_product=str(maxs),
                max_actual_over_proved_bound=str(largest),period_fixture_dilation=dilation)

def main():
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--output",type=Path)
    g.add_argument("--check",type=Path)
    args=p.parse_args()
    obj=dict(method="Exact Fraction; actual volume-bin receiver radii enlarged by h. Each positive mark uses at most two interior source positions and all listed physical probes. Original finite hard fraction is 3/4.",cases=[case(n,stage) for stage,n in enumerate((4,8,16),1)])
    content=(json.dumps(obj,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(content)
    else:
        assert args.check.read_bytes()==content
        print("joint790: true price traffic satisfies the exact two-receiver product on every tested group")
if __name__=="__main__":
    main()
