"""Exact cube receiver geometry and interval checks for round 790."""
import argparse
import json
import platform
from fractions import Fraction as F
from pathlib import Path
from flint import arb, ctx

def cap(d, s, t):
    d = abs(d)
    positive = lambda a: max(a, F(0))**2
    return 1 - (positive(d) - positive(d-2*s) - positive(d-2*t)
                + positive(d-2*s-2*t))/(8*s*t)

def polygon(q, d):
    """Clip [0,2s]x[0,2t] by the admissible half-plane x+y>=d."""
    result = []
    for a, b in zip(q, q[1:] + q[:1]):
        ra, rb = sum(a)-d, sum(b)-d
        if ra >= 0:
            result.append(a)
        if ra*rb < 0:
            f = ra/(ra-rb)
            result.append(tuple(x+f*(y-x) for x,y in zip(a,b)))
    if len(result)<3:
        return F(0)
    cross = sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(result,result[1:]+result[:1]))
    return abs(cross)/2

def scan(s,t):
    q = [(F(0),F(0)),(2*s,F(0)),(2*s,2*t),(F(0),2*t)]
    grid = sorted({F(i,32) for i in range(int(64*(s+t))+5)}
                  | {2*s, 2*t, 2*(s+t), F(0)})
    for d in grid:
        a = cap(d,s,t)
        assert a == polygon(q,d)/(4*s*t) and 0 <= a <= 1
        if d<=2*(s+t):
            assert 1-a >= min(d,2*s,2*t)**2/(8*s*t)
    # k is piecewise quadratic, so Simpson's rule is exact on each piece.
    breaks=sorted({F(0),2*s,2*t,2*(s+t)})
    integral = 2*sum((r-l)*(cap(l,s,t)+4*cap((l+r)/2,s,t)+cap(r,s,t))/6
                     for l,r in zip(breaks,breaks[1:]))
    assert integral==2*(s+t)
    return dict(s=str(s),t=str(t),tested=len(grid),integral=str(integral))

def ai(f):
    return arb(f.numerator)/f.denominator

def enclosure(x, bits=42):
    scale=2**bits
    lo=int((x*scale).lower().floor().unique_fmpz())
    hi=int((x*scale).upper().ceil().unique_fmpz())
    assert ai(F(lo,scale)) <= x and x <= ai(F(hi,scale))
    return [str(F(lo,scale)),str(F(hi,scale))]

def grown(n,k):
    assert k*k==n
    dense=ai(cap(F(1,k),F(1),F(1)))**n
    sparse=ai(cap(F(1),F(1),F(1)))**k
    assert dense>arb(7)/8 and sparse<dense
    return dict(n=n,one_norm=k,dense_prob=enclosure(dense),sparse_prob=enclosure(sparse))

def main():
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--output",type=Path)
    g.add_argument("--check",type=Path)
    a=p.parse_args()
    ctx.prec=256
    result=dict(python=platform.python_version(), precision_bits=ctx.prec,
                geometry=[scan(F(1), F(1)),scan(F(3,2),F(1)),scan(F(15,8),F(17,16))],
                stress=[grown(k*k,k) for k in (4,16,64,512)],
                limits="Uniform Lebesgue rectangles used for the receiver majorant. Not the true source law or the high-dimensional weak type constant.")
    out=(json.dumps(result,sort_keys=True,indent=2)+"\n").encode()
    if a.output:
        a.output.write_bytes(out)
    else:
        assert a.check.read_bytes()==out
        print("lens790: rational polygons, exact mass, and anisotropic Arb bounds agree")
if __name__=="__main__":
    main()
