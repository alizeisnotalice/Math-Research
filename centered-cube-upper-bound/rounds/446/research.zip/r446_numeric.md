# R446 多距离层：同一来源预算的精确选择证据

只复用R445第三个真实4×5 center/source场。紧凑输入`r446_numeric_input.json`保存必要几何与边缘数据，并记录原证书SHA256及case3索引；不依赖R445整证书。脚本重新核完整质量m=R^4、正center体积、实际source捕获、整块distance上下界。仍是n=4、f=1大box的marginal接口；原masscut失败，不能声称原完整流非空。

**下列所有匹配质量、缺额和raw pair积分均除以θ²归一**，θ=1/120000000000000；真实质量须乘θ²。density系数Cψ及形式X费用系数无此归一。

## 设计与联合预算

三层为Δ≤α0=e、e<Δ≤7/2、7/2<Δ≤9/2。每次总H的row≤同一η、column≤同一ζ，r=31/50；各层不重新领取来源预算。

先比较3个support前缀：single near、前两层、全部三层。每个前缀比较unweighted cap 2raw与root canonical cap `2ψ raw`，ψ=min(1,(α0/Δ)^4)。另仅一个all-layer shellfloor对照，共7比较、6个不同tiny LP；相同near容量缓存，不重复求解。未做Bcrit扩展。

ψ在正体积center pair内部变化。canonical下容量用Δ的**整块上界**算ψ的严格有理下界（10^8分母）；相应上容量由整块下界算严格有理上界。全shellfloor用各shell最远端代替实际Δ，故更保守。Arb256bit核所有rounding方向。

## 精确结果与连续桥

|support/cap|匹配质量|缺额|证书Cψ|
|--|--|--|--|
|single near（两cap相同）|.3200000000|.3000000000|2|
|两层unweighted|.6200000000|0|≤4.800282|
|两层canonical soft下容量|.5142699554|.1057300446|2|
|三层unweighted|.6200000000|0|≤9.378108|
|三层canonical soft下容量|.5574060620|.0625939380|2|
|三层shellfloor soft|.4967774048|.1232225952|2|

每个浮点HiGHS值由独立Fraction residual-network maxflow复核；exact primal与其可达cut生成的0/1 Hall dual相等。全部row/column/cap逐项严格核验，故不是只报浮点optimal。

连续模型下的桥是严格的：

- 每个block的raw reference为常密度product。下容量满足`H_ij≤2 ψ_lower μ_iν_j`，按各block product作constant-density lift后仍被实际`2ψ(w,v) μ⊗ν`支配，且其连续边缘受原η、ζ支配。因此离散下容量最优值是可构造的连续下界。
- 任意连续canonical H聚合到block后，其edge容量≤`2 ψ_upper μ_iν_j`。把同一个lower最优cut用于这组upper容量，得到全连续匹配的upper dual，无额外LP。

由此真正连续canonical最优质量严格被夹在：

`two layers: [.5142699554, .5142916378]`，

`three layers: [.5574060620, .5574336184]`。

所以此同模型可核实选择是：near .32提升至soft至少.557406062，但**缺额仍≥.0625663816**。canonical逐edge改善shellfloor至少.0606286572，且始终保持同一个Cψ=2。

联合最优会重分配层间流量；例如canonical三层的near分量约.025869921，不是把原near .32额外加到新两层流上。把独立层最优值相加会重复来源预算。

## 真实distance指数与费用单位

canonical/shellfloor的合并H都满足同一个`H≤2ψ raw`，因此root理论的收费应统一用`2 Φ(A_n²)`，无需逐层加最坏α_k^n/K²。

本场实际side带含parent1.5和最小terminal1.1，故b/a=15/11。若条件性代入R444 receipt，S=3、eps0=1/4、s=3时，Cψ=2对应形式X系数约.160030；为unweighted前两层和三层的已选full-matching primal认证的Cψ上界分别4.800282和9.378108，形式系数约.384094和.750388。ψ使用真实距离的四次方，而不是只按距离本身计价。

**真实R444费定理不适用于这个masscut-failing fixture。** 上述仅比较符合root canonical费用形状的条件系数，不能把它记作本场或原U的已付款。此场实际raw ψ积分另以整块上下界直接核为[.70940390555,.70946571690]θ²，未借用不适用的质量门定理。

## 范围与冻结

结果支持继续研究joint canonical weighted Hall：同一Cψ费用下，多距离层确能扩大可匹配部分；该有限场中仍有严格正缺额。它不证明原history中的缺额价格，也不证明H控制原U。原massgate/high-rank未实现，有限LP不能认证全R433。

复现命令、环境、输入责任与输出白名单见`r446_compute_index.md`。原计划已并入本稿；不新增geometry、scan或solver范围。冻结停止。
