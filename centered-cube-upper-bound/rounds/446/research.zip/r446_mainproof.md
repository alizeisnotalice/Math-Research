# R446 — one canonical capacity dominates bounded radial mixtures

**Conclusion.** The extended soft capacity below dominates every simultaneous distance-window plan with the specified uniform fiber budget. It has a single root-log source price, without summing layer prices. This eliminates the need to tune bounded-budget radial mixtures. It does **not** establish full coverage of the actual terminal marginals: the capacitated Hall deficiency remains unestimated.

## 1. The unchanged original measures

Use precisely R445 geometry §§1–4: the complete original measure P, base record ξ=(e,A,y,z,t), base measure Λ, actual terminal submeasure Γξ≤μξ⊗νξ, and its marginals ηξ,ζξ of common mass rξ. All current, source, clipping-stage, early, clock, deletion and future gates remain in Γ. The raw hats μ,ν use actual Lebesgue receiver centers, original full-f masses, own-low terminal gates and m_w,m_v<m_A/K². They are not refreshed probability laws.

Write q for the original lower q-band bound, σ=q_A dA,

    s=1+sqrt(n), h=s/(epsilon0 q), K=exp(sqrt(n)),
    alpha0=K^(2/n), An=1+n log(b/a), Xq=σ(E), W=∫f.

At fixed ξ let Δ=2||w−v||∞/max(R_w,R_v). Define on **all** pairs

    ψbar(w,v)=min(1,(alpha0/Δ)^n),                         (1)

with value 1 at Δ=0. This differs from the R444 far-only ψ, which was zero on the near region.

## 2. Extending the capacity to near pairs costs no extra term

The native raw parent measure Q_A of R444 geometry (2) satisfies, for every a>0,

    Q_A{Δ≤a} ≤ 2a^n/(K²q²),      Q_A(1)≤An²/q².         (2)

For 0<t<1, {ψbar>t}⊂{Δ≤alpha0 t^(−1/n)}. Since alpha0^n=K², layer cake gives

    ∫ψbar dQ_A ≤ q^(−2)∫_0^1 min(An²,2/t)dt
                = q^(−2) Φ(An²),                       (3)

where Φ(v)=v for 0≤v≤2 and Φ(v)=2[1+log(v/2)] for v≥2. This proves the near extension directly; it does not add an independent near price to the old far price.

Integrating the original clipping increment once, using the original sourcewise bound Σ_e a0^e≤S, and the two terminal hats gives

    ∫Λ(dξ)∫ψbar dμξ dνξ ≤ S epsilon0² Φ(An²) Xq/s².     (4)

All discarded masks in this upper estimate are positive restrictions. No terminal receives a new history. Actual matching also gives Xq≤An W: indeed Xq=∫f(x)∫c_A(x)R_A^(−n)dA dx, and the actual-center radial layer bound on the inner integral is An.

Thus the single capacity

    aξ = C ψbar μξ⊗νξ                                   (5)

has total mass at most Ωsoft(C)W, where

    Ωsoft(C)=C S epsilon0² An Φ(An²)/s².                 (6)

For C=sqrt(n), octave b/a≤2 implies An≤s², so

    Ωsoft(sqrt(n))≤S epsilon0² sqrt(n) Φ(An²)
                   =O(S epsilon0² sqrt(n) log(n+2)).     (7)

Equations (4) and (6) are alternative prices for one capacity, not two charges.

## 3. Exact dominance of simultaneous radial mixtures

Allow finite or countable ξ-measurable coefficients cξj≥0 and radii aξj≥alpha0. Assume the **uniform fiberwise** budget

    Bξ=Σ_j cξj(aξj/alpha0)^n ≤ C,   Λ-a.e. ξ.            (8)

Then, pointwise on the actual receiver pair space,

    kξ(Δ):=Σ_j cξj 1{Δ≤aξj} ≤ Bξ ψbar(Δ) ≤ C ψbar(Δ).   (9)

Proof: if Δ≤alpha0, each radius weight is at least one and k≤Σc≤B. If Δ>alpha0, each active radius a≥Δ obeys 1≤(a/alpha0)^n(alpha0/Δ)^n. Sum this inequality; monotone convergence handles countably many layers. Source/history-dependent choices of radii and coefficients cause no problem provided (8) holds with the same C. A mere integrated budget or an unbounded adaptive fiber budget is not covered.

Suppose layers Hξj have capacities cξj1{Δ≤aξj}μξ⊗νξ and their **sum** has marginals bounded by ηξ,ζξ. Then ΣHξj≤aξ by (9), and is a feasible partial plan for (5). Independent layer optima cannot be added unless this shared marginal condition is checked. Conversely any H≤kξ μξ⊗νξ decomposes into the layers by multiplying its density by cξj1{Δ≤aξj}/kξ, zero where kξ=0. Hence simultaneous window allocation is precisely one summed capacity, with no extra source reuse allowed.

For arbitrary positive radii, (9) remains valid under the repaired budget Σcξj max(1,(aξj/alpha0)^n)≤C. It need not hold under the cheaper volume-only budget when a<alpha0. For example normalized radius power a^n/alpha0^n=1/4, coefficient 1, and Δ^n/alpha0^n=1/8 give k=ψbar=1 but B=1/4. This is a scope check, not a native counterexample to the target.

We do not claim the canonical capacity itself has a bounded-cost window-mixture representation, or dominates every possible nonradial geometric capacity. Its direct native price (3) is what makes this outer class useful.

## 4. Original-flow payment and the exact unproved complement

Apply the measurable capacitated matching construction of R445 geometry §2 to (5). Its proof uses only finite measurable capacity and actual marginals; (4) supplies the necessary global finiteness. The maximum partial mass is rξ−dξ, with

    dξ=sup_{B,T measurable}[ηξ(B)+ζξ(T)−rξ
                            −C∫_{B×T}ψbar dμξdνξ]_+.    (10)

Zero fibers have dξ=0. Let H be a measurable optimum. Pull its second marginal back to the original histories with bξ(v)=dH₂/dζξ∈[0,1]. Then Pmatch=bξ(v)P is an actual positive part of the same original P, and

    R=|Pmatch|+Dsoft(C),       Dsoft(C)=∫dξ dΛ,
    |Pmatch|≤Ωsoft(C)W.                                  (11)

The original matched pairs need not be near. Only the auxiliary comparison plan has capacity (5); no future qualification is transferred to it. The original signed U is split with the same pullback, using its dependence on ξ and v. Its unmatched part is not bounded by claiming that a cheaper comparison transport has cheaper original cost.

By (9), Dsoft(C) is no larger than the uncovered mass of any simultaneous mixture in (8), including ξ-adaptive mixtures with that uniform budget. This is the proved selection improvement. There is still no proof that Dsoft(C)=0 or has the desired source price. For example every actual cut must still satisfy the lower coverage requirement

    ηξ(B)+ζξ(T)−rξ ≤ C∫_{B×T}ψbar dμξdνξ                 (12)

to obtain full coverage. If Δ≥d>alpha0 on the rectangle, the right side is at most C(alpha0/d)^n μξ(B)νξ(T). Existing matching and low-common estimates are upper capacities and do not furnish (12) for all retained, source-dependent cuts.

This soft matching may **replace** the R445 single-near matching receipt; it is not stacked with that receipt on the same original mass. Earlier source/clock/history fees remain unchanged. In a mother ledger with R coefficient 64Λ0 Fhat, the new source term is 64Λ0 Fhat Ωsoft(C)W and the remaining term is 64Λ0 Fhat Dsoft(C). No general root closure is claimed.

## 5. Actual local verification

The local Python executable ran `r446_mainproof_check.py`; stdout is `r446_mainproof.result.txt`. It passed **141 exact Fraction assertions**, in three stages (17,83,41): pointwise mixture dominance and decomposition; zero/below-base/budget endpoint checks; all-cut 2×3 capacity comparisons plus an explicit feasible full soft plan. For scale multipliers 1,2,8,32, (mixture defect,soft defect) were respectively (1/12,0), (1/6,1/28), (1/4,347/2016), (1/4,1859/8064). Thus the tests include both strict improvement and a remaining positive deficit.

These are finite capacity and marginal-algebra checks, not native cube realizations or certification of original history gates. The actual-center geometry and all constants in (2)–(7) are established analytically using the audited R444 native lemma. This bounded task stops at (11)–(12).
