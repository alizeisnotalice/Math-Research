# R446 计算索引（冻结）

责任numeric；只写本前缀/index，不编辑他人、repo、git或spawn。

输入：`r446_numeric_input.json`，从R445原证书case3提取必要几何/边缘数据；含原文件名、SHA256和one-based索引3。脚本无R445外部文件依赖。

设计与实际：同一4×5真实center场，3距离层，固定ηζ联合maxflow。7比较（6 distinct tiny HiGHS LP）：3prefix×unweighted/canonical-soft，外加1 shellfloor。Fraction独立maxflow与exact cut dual；canonical continuous lower/upper由整块ψ上下界及同一cut认证。无Bcrit拓展、几何样本扫描或重复旧fixture求解。

命令：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r446_numeric.py`
环境Python3.12.14、SciPy1.18.1、flint0.9.0，Arb256bit。float值仅交叉核（误差<1e−10），所有优化等式由有理primal/dual认证。

文件白名单（全部`/tmp`，归档只需这七个）：
- `r446_numeric.py`
- `r446_numeric_input.json`
- `r446_numeric_certificate.json`
- `r446_numeric_run.txt`
- `r446_numeric_resources.txt`
- `r446_numeric.md`
- `r446_compute_index.md`

状态：运行通过、冻结。所有flow mass按θ²归一；实际乘回θ²。fixture明确不满足原masscut，R444真实费定理不对该fixture生效；条件费用只用于机制选择，无全history/全U预算声明。
