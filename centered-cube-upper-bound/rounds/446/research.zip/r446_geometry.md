# R446 — a constructive deficiency upper bound; no new source payment

This bounded attempt constructs a feasible local plan from the **actual retained marginals**, giving an upper bound for the R445 Hall deficiency rather than another weak-cut lower bound. The remaining source-averaged imbalance is not estimated at the requested scale. The plan is already included in R445's maximal matching, so its construction is not counted as an additional payment.

## 1. An explicit plan on actual nearby centers

Keep the R445 base ξ=(e,A,y,z,t), entering measure Λ, actual terminal submeasure Γξ≤μξ⊗νξ, and actual marginals ηξ,ζξ. All original current, early, history and source gates remain in Γξ. Fix a capacity multiplier c>0. Below all measures are at the same ξ; write
\[
 M=\mu(E),\quad N=\nu(E),\quad
 r=\eta(E)=\zeta(E),\qquad d=MN/c.
\]
If MN=0, domination forces r=0, and every quantity below is defined as zero.

Partition the **receiver-center space**, not the clipping-source space, into fixed half-open grid cells E_j of side length α₀a/2, intersected with the actual E. Every pair of centers in one cell satisfies
\[
 2\|w-v\|_\infty\le\alpha_0 a
                 \le\alpha_0\max(R_w,R_v),
\]
so it belongs to the original analysis-near relation. There is no replacement of an actual cube and no bound on f from the cell volume.

Set e_j=η(E_j), f_j=ζ(E_j), and
\[
 H_j=\frac{\eta|_{E_j}\otimes\zeta|_{E_j}}
               {\max(e_j,f_j,d)},\qquad H=\sum_jH_j.
 \tag{1}
\]
The original domination gives
\[
 \frac{d\eta}{d\mu}\le N,\qquad
 \frac{d\zeta}{d\nu}\le M.
\]
Thus H_j has density at most MN/max(e_j,f_j,d)≤c relative to μ⊗ν. Its first marginal is at most η|E_j because f_j≤max(e_j,f_j,d); its second marginal is at most ζ|E_j for the analogous reason. Disjoint cells imply
\[
 H\le c1_{N_{\alpha_0}}\mu\otimes\nu,
 \qquad H_1\le\eta,\quad H_2\le\zeta.
 \tag{2}
\]
All kernels and cell masses are measurable. This countable sum needs no optimal-selection theorem and has mass at most r.

## 2. The exact loss of this construction

Write Dξ(c) for the optimal R445 deficiency. Since (1) is feasible,
\[
 D_\xi(c)\le r-|H|=\mathcal I_\xi+\mathcal F_\xi,
 \tag{3}
\]
where
\[
 \mathcal I_\xi=\frac12\sum_j|e_j-f_j|,
\]
\[
 \mathcal F_\xi=\sum_j\min(e_j,f_j)
        \left(1-\frac{c\max(e_j,f_j)}{MN}\right)_+.
 \tag{4}
\]
This is an equality for the loss of the constructed plan, not an equality for the optimal deficiency. To check it, use
\[
 \frac{e_jf_j}{\max(e_j,f_j,d)}
 =\min(e_j,f_j)\min\{1,\max(e_j,f_j)/d\}
\]
and r−Σmin(e_j,f_j)=½Σ|e_j−f_j|. Both terms in (4) are nonnegative and their sum is at most r. The first is actual cell-marginal imbalance; the second is the capacity loss of this particular product construction. It may exceed the optimal loss even within the same cells.

The same R445 pullback by the second marginal turns H into an original positive fraction. Its mass has the already proved price
\[
 |P_H|\le\frac{2cS\varepsilon_0^2A_n}{s^2}W.
 \tag{5}
\]
For c=√n this is at most 2Sε₀²√nW. This is a substitute feasible plan within the old matching receipt, **not** a second fee to be added to it. The exact mass splitting for this plan gives the valid but possibly weaker bound
\[
 R\le\frac{2cS\varepsilon_0^2A_n}{s^2}W
       +\int(\mathcal I_\xi+\mathcal F_\xi)\,d\Lambda(\xi).
 \tag{6}
\]
No new original-history qualification is assigned to an auxiliary pair. The pullback retains the old records; the analysis-near property belongs only to H.

## 3. Checking the original geometric gates against the unpaid term

The original low T_G and T_loc indicators depend on A,y,z and the full original field. They remain true on the supported ξ fibers in this construction. Explicitly they involve
\[
 T_G=\frac{m_Ae^{\|y-z\|_1/R_A}}
              {\sqrt{\mathsf U(y)\mathsf U(z)}},
 \qquad
 T_{\rm loc}=\frac{m_Ae^{\|y-z\|_1/R_A}}
              {\max(V_{R_A}(y),V_{R_A}(z))},
\]
with the same original thresholds. The strict terminal mass gap and own-low restrictions are retained in μ,ν. This argument has not replaced them by arbitrary receiver marginals; η,ζ are still precisely the marginals of the actual accepted Γξ.

What is missing is a source/parent estimate for the single final integral in (6). In particular:

- The full-field support degrees and local masses in T_G,T_loc do not directly give a lower bound for retained ζ(E_j) where retained η(E_j) is large. They concern full f and actual capture support, whereas e_j,f_j also contain original current and future acceptance.
- Replacing η,ζ by their upper bounds Nμ,Mν cannot give an upper bound on their difference. Such a replacement would remove the acceptance-sensitive part of the proposed estimate.
- Neither the number of center cells nor their small volume is a source budget. Counting the cells would lose the dimension dependence that this construction was meant to avoid.

A successful continuation would therefore need a genuine integrated comparison between these retained marginal imbalances and full-field source mass, with a proved cross-parent reuse bound. For example, charging cell imbalance to external source mass suggested by T_G would require an actual assignment with a controlled source column; positive support or a large external degree alone is not such an assignment. None is constructed here. Nor is the capacity-loss term in (4) shown to be summable from low-common capture.

Accordingly (3) is a useful constructive test of the missing balance, but not a new global estimate. The mother ledger is unchanged, and the original general root bound remains unproved. This attempt stops at this specific source-averaged comparison rather than adding further local branches or asserting that the whole Hall problem has been solved.

## 4. Executed check and scope

The specified local Python ran `/tmp/r446_geometry_check.py`; stdout is `/tmp/r446_geometry.result.txt`. Three exact Fraction conditional-marginal models verify (2), the equality in (3) for the constructed loss, and its direction relative to the exact all-subsets Hall deficiency. All original finite test couplings are off the analysis-near diagonal. The outputs are:

- c=1: constructed loss 49/144; exact Hall deficiency 5/24.
- c=2: constructed loss 49/288; exact Hall deficiency 5/48.
- c=3: constructed loss 137/576; exact Hall deficiency 11/72.

These are finite construction checks, not native cube/high-rank/history realizations or evidence of a general source price. They verify the upper-bound direction and show explicitly why the local product plan is not assumed optimal. No geometric parameter scan was performed, and no other author's file or repository was modified.
