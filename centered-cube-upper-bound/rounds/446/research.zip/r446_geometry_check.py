from fractions import Fraction as F
from itertools import product
mu=[F(1,2),F(1,3),F(1,6)]
nu=[F(1,4),F(1,2),F(1,4)]
M,N=sum(mu),sum(nu)
tables=[[(0,1,F(1)),(1,2,F(1)),(2,0,F(1))],
        [(0,2,F(1)),(1,0,F(1,2)),(2,1,F(1,4))],
        [(0,1,F(1,2)),(0,2,F(1)),(1,0,F(1)),(2,0,F(1,3))]]
for k,(entries,C) in enumerate(zip(tables,[F(1),F(2),F(3)]),1):
    G=[[F(0) for j in range(3)] for i in range(3)]
    for i,j,t in entries:G[i][j]=mu[i]*nu[j]*t
    e=[sum(row) for row in G]
    f=[sum(G[i][j] for i in range(3)) for j in range(3)]
    r=sum(e); d=M*N/C
    h=[e[j]*f[j]/max(e[j],f[j],d) for j in range(3)]
    for j in range(3):
        assert h[j]<=min(e[j],f[j],C*mu[j]*nu[j])
    imbalance=sum(abs(e[j]-f[j]) for j in range(3))/2
    fragment=sum(min(e[j],f[j])*max(F(0),1-max(e[j],f[j])/d) for j in range(3))
    assert r-sum(h)==imbalance+fragment
    # Exact Hall deficiency for this three-cell diagonal near relation.
    hall=F(0)
    for B in product((0,1),repeat=3):
        for T in product((0,1),repeat=3):
            hall=max(hall,sum(e[i]*B[i]+f[i]*T[i]-C*mu[i]*nu[i]*B[i]*T[i] for i in range(3))-r)
    assert hall<=r-sum(h)
    print('case',k,'C',C,'mass',r,'local matched',sum(h),'imbalance',imbalance,'fragmentation',fragment,'Hall',hall,'PASS')
print('Scope: three exact conditional-marginal construction checks; no native cube/history instance and no source-budget certificate.')
