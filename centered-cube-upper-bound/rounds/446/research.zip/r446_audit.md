# R446 independent final audit

FINAL PASS（限定范围）：通过全域软距离容量价格、逐纤维预算径向混合的容量支配、一次可测匹配及原 P 拉回、实际缺额分解；通过附件局部 product plan 的构造损失上界。未证明 Dsoft 的全局来源价、统一匹配比例、U 上界或一般根阶弱型闭合。无实质修复项。PRE 形成于本轮作者阅读之前，后附留档。

## 1. 数学范围与母账

ψbar=min(1,(α0/Δ)^n) 定义在全 pair 空间，Δ=0取1。作者重新对全域做 layercake，非直接套用R444的far-only结果；原 raw CDF≤2α^n/(K²q²)、total≤An²/q²给 ∫ψbar dQ_A≤q⁻²Φ(An²)。Φ的near/base部分已在同一积分内，不能再加一份near价。原clipping积分一次、逐来源S一次、两whole-terminal帽h⁻²，得到联合容量总价 CSε₀²ΦX/s²。完整匹配 X=∫q_A dA≤AnW，无r；C=√n、An≤s²给 Sε₀²√nΦW。所有原终端strict质量门/own-low、同父双来源及初始active资格保持；任意有限表不是这些资格的替身。

逐ξ统一预算 Σc_j(a_j/α0)^n≤C、a_j≥α0确给点态Σc_j1_{Δ≤a_j}≤Cψbar；可数层由非负极限，ξ依赖可测而不丢预算。层H必须共同满足同一η、ζ总边缘约束；不能相加独立最优值。小于α0的半径须max(1,(a_j/α0)^n)修正预算，未被较便宜volume-only版本涵盖。没有声称覆盖所有非径向容量或存在反向等价表示。

联合容量有限，所以R445可测最大部分流定理适用。只在最终以H₂/ζ一次RN拉回原P；不把辅助近pair/soft容量赋给原old终端，也不将分析残余当实际逐轮old残余。实际 matched 是同P的正部分，精确R=matched+Dsoft。由于容量支配，Dsoft≤同预算任何联合径向方案的余量；这不自动使含全部价格的总RHS逐输入更小。

geometry构造使用receiver格、η/μ≤ν(E)、ζ/ν≤μ(E)，其分母max(e_j,f_j,MN/c)给真实可行near子计划。构造损失恰I+F，故Dnear≤I+F且Dsoft≤Dnear；不将构造损失当最优缺额，也不对I/F宣布来源价。

主母账正确只替换64Λ₀Fhat R槽为64Λ₀Fhat Sε₀²√nΦW+64Λ₀Fhat Dsoft。旧C433/V433及初始/删除/尺度/外费保持，无near双收，无未证明ε吸收或缺额结算。

## 2. 实际复现与证据限定

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 于新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r446_audit_isolated_0818782f` 实际运行三个冻结脚本，stdout分别与白名单逐字节一致；numeric生成JSON也逐字节一致。最小输入独立包含原case3必要参数和出处SHA，不读取R445外部证书。资源文件仅原实跑记录，本次不改写或新增样本覆盖。

mainproof 141 Fraction断言(17/83/41)只验证有限容量/分拆/cut接口；geometry 3 Fraction conditional-marginal构造只核可行性与损失方向，均非native-history证据。

numeric仅同一个n4、uniform full-f、真实正体积receiver/source块场：7比较、6 distinct tiny HiGHS候选，再以独立Fraction residual-network流/可达cut及整数dual严格认证。ψ下界来自整块Δ上界，product常密度lift满足真实连续cap和相同实际边缘；真实连续流聚合后受整块ψ上界控制，用同一cut给upper dual。这两方向正确，未把离散点解外推到连续场。三层canonical连续最优量的归一夹界 [.5574060620,.5574336184]与剩余正缺额均有证书，所有质量须乘θ²；density系数无该归一。

输入重新核m=R⁴、完整来源捕获/中心体积、整块距离与实际ηζ。原K² masscut失败，故形式R444费用系数只是机制比较，不适用于该fixture的原付款定理；独立rawψ整块界不借用此失败门。未实现原high-rank/history，不认证完整P非空或全缺额预算。

## 3. SHA256 byte bindings

- `r446_main.md`: `111ac5f239c40989262ec8e815a96566e520927e12e5478cfd11a00ada59942f`
- `r446_geometry.md`: `53643f515695a3f23c3fde8ceebca6b5eaaa0288deeb117967beb370802c3e5b`
- `r446_geometry_check.py`: `529253fa61bd1ca2214a008803d8a119fff5316b3657cbe03d6da3209255d9d2`
- `r446_geometry.result.txt`: `10763cd85357ef072625cd524e507a2d4f3abd8fcb33fe3d526f88f9c43266df`
- `r446_mainproof.md`: `3f6f8ec268e7ec99a15058ce9bc7509dc6d752ee02d9d12e041e669b036311ec`
- `r446_mainproof_check.py`: `ee1edee06b5f049b48ea633f03d485d01d654c4101cd690fe7adb4dead5213d0`
- `r446_mainproof.result.txt`: `d9c1af63e75021283dcbb7c6697ba81e5c989c0162565d10e0bef5c8b49a534a`
- `r446_numeric.md`: `78ffb55fee0ad2408d7045ed373df8d5786179b94cecbd50cb75b2031eb25704`
- `r446_numeric.py`: `4a95fe8eb6487212671a138baa59367006067b909efabdb865ca1647b854a44d`
- `r446_numeric_input.json`: `4f6461266a9bcb758ecbd17eca80ccc9e63ceee4acb7aa8efdff27f8af51bcb2`
- `r446_numeric_certificate.json`: `f87e95a18efadf5a3562be4c9f0484fa251f2c1b53ff2a494c5157253b24ff7f`
- `r446_numeric_run.txt`: `9654fedff3e1378a17ea0ad0ef3f692554c792b767038343ac033319faadd84f`
- `r446_numeric_resources.txt`: `ad640d58232366835d7a8aa2a2df964c758cd5b67c634f7ab055cde2181a85a1`
- `r446_compute_index.md`: `d691a7ec6b835b82962ccbca9cf6a93d9ed78e7eec9cb5a302b9affb32b75e44`

## 4. 独立 PRE 留档

# R446 independent audit — PRE

PRE ONLY。先读继承的 R445 主稿，未读本轮作者新证明。任务限同一实际 ηξ、ζξ 的多距离层容量/收缩合同；没有证明完整缺额预算或一般根阶闭合。

## 1. 可联合使用的容量与可核 cut 条件

保原完整 P、ξ=(e,A,y,z,t)、有限进入量 Λ、Γξ 的实际边缘 ηξ、ζξ（共同质量 rξ），及 μξ、νξ 为真实 whole-terminal ρ/h 帽。对确定的可测距离层阈值 a_l>0、系数 C_l≥0，记

N_l={Δ≤a_l}, c_l=C_l 1_N_l μξ⊗νξ, c_Σ=Σ_l c_l。

H≤c_Σ、H₁≤η、H₂≤ζ 的可测最优匹配，其缺额按 R445 连续实现合同精确为

d_Σ(ξ)=sup_{B,T}[ηξ(B)+ζξ(T)−rξ−c_Σ(B×T)]_+。

因此 d_Σ≤θ rξ+eξ（0≤θ<1,eξ≥0）的准确、可检验充分且必要条件是对同一 ξ 的所有实际可测 cuts：

c_Σ(B×T)≥ηξ(B)+ζξ(T)−(1+θ)rξ−eξ。

必须是所有 cuts 或一个严格外包全部 cuts 的证书。仅测若干源无关集合/粗分割、只验证逐点上容量、或只验证某几层价格便宜，均不足；有限分割 cut 上升趋近全缺额，有限小缺额本身不是全缺额上界。简单邻域 Hall 平衡仅是不带边容量的必要约束，不能省略 C_l μν 的 bottleneck。

原 Γ≤μν 只提供上支配，不自动给便宜 N_l 上的实际邻域下覆盖，因而不能单独推出根价层的几何收缩。它在足够宽的全支持层上可保证完全可匹配：同父来源满足 |y−z|∞≤R_A，真实捕获给 |w−v|∞≤(R_w+R_v)/2+R_A≤2b，故 Δ≤4b/a≤8；a_l=8,C_l=1 时 Γ 本身可行。但其通用来源价含 8^n/K²，不能当作根阶结算。此是有界 octave 的可用终点，不是对便宜层收缩的证明。

## 2. 层费用与可测极限

每个 raw 层保真实 strict terminal mass<m_A/K²，native 双捕获矩给 ≤2a_l^n/(K²q²)。先合原 clipping/stage 一次、再用原 sourcewise S，任意 H≤c_Σ 的总质量有

∫|Hξ|dΛ≤B_Σ W,
B_Σ=2S ε0² A_n/(s²K²) Σ_l C_l a_l^n。

这里 X=∫σ≤A_nW，无 r 损失。对于嵌套 N_l，直接累加容量是合法但可能冗余的上包络；若只用最大/分段容量，须按实际容量重新定价，不重复支付同一 H。countable 层须 Σ C_l a_l^n<∞ 或另证联合容量有限，以支撑可测最优存在/极限；C_l、a_l 若依 ξ，不得直接提出积分，须有确定包络或实际加权层价格。

该 matched 质量能按最终 H₂/ζ 的可测 RN 系数一次拉回原 P，保全部 history，未把辅助近 pair 强加给原 w，也未借此支付 U 的未控 log 值。

## 3. 逐级方案最容易遗漏的边缘问题

可以在分析计划中递推 η_{l+1}=η_l−H_{l,1}、ζ_{l+1}=ζ_l−H_{l,2}，同一原 ξ 不刷新。此时 H_total=ΣH_l 是原 η、ζ 的部分匹配，容量≤Σc_l；只在最后一次用 H_total,2/ζ 拉回原 P 即合法。

但若每步先把 H_l 以 new-v 系数拉回原 P，则实际删去的 old-w 边缘一般不等于 H_l,1。下一步不能继续把分析 η_l−H_l,1 冒称实际剩余 old 边缘。必须（a）保持整个分析匹配到最终再拉回，或（b）按真实原剩余 P 重算两实际边缘并逐轮证明 cut 条件。不能一边声称每步原历史保留，一边无代价沿用另一套分析残余边缘。

对合法分析残余，若每轮所有残余 cuts 证得 d_l≤θ_l r_l+e_l，则 r_{l+1}≤θ_l r_l+e_l；积分后按真实递推保乘积及误差。这个收缩是待证几何输入，不由 raw 上帽传承。未来标记可在正上界中删除，不能据此归一改变实际 η、ζ 或继承新历史。

## 4. 完整费用如何入母账

联合 cut 若仅给 D_Σ=∫d_ΣdΛ≤ηX+QW，则原 R≤ηX+(B_Σ+Q)W。若给更弱但可吸收的 D_Σ≤θR+ηX+QW，θ<1，则

R≤[ηX+(B_Σ+Q)W]/(1−θ)。

现有入口的 64Λ0 Fhat R 槽可按此替换，新增 X/W 系数分别为 64Λ0 Fhat η/(1−θ)、64Λ0 Fhat(B_Σ+Q)/(1−θ)。所有原 C433、V433、初始/删除/尺度及外费仍保留，不退款旧 near，也不把层费用或收缩误差藏入 U。只有层价、没有全 cut 余量结算时，必须保留 64Λ0 Fhat D_Σ，不能宣布整体闭合。

## 5. 实际本机辅助核验与停止

指定 math-research-tools Python/Fraction 实际核两项有限接口：同 v 拉回保持匹配质量1/4，但分析 H old边缘=(1/4,0)、实际 pullback old边缘=(0,1/4)，确认上述残余差别；另一两态 diagonal capacity 表枚举全部16 cuts，缺额1/2与半质量匹配一致。仅是测度/算术审查，不是原生几何/history 样本，不作广泛反例扫描，也不计新增正式实验覆盖。

PRE 结论：多距离层可合法联合，并有显式来源价；真正需要的是同一实际边缘的全 capacitated-cut 条件或其原权重集成版本。raw domination 不提供根价层的下覆盖/收缩。当前没有独立提出已证的此类几何收缩。停止等待冻结作者稿后再 FINAL。
