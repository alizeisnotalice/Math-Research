"""One R445 native field, joint distance-layer capacity with exact flow/cut proof.
Seven comparisons, six distinct tiny LPs (identical near capacities cached).
R445 fixture fails original masscut; no original-flow nonemptiness claim.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import deque
import json,sys,platform,math
import numpy as np
from scipy.optimize import linprog
import scipy
from flint import arb,ctx
import flint
ROOT=Path(__file__).resolve().parent;ctx.prec=256
input_data=json.loads((ROOT/'r446_numeric_input.json').read_text())
assert input_data['source_case_one_based']==3
old=input_data['fixture']
A=lambda x:arb(str(F(x).numerator))/arb(str(F(x).denominator))
m=len(old['raw_normalized_a']);k=len(old['raw_normalized_b']);assert (m,k)==(4,5)
a=list(map(F,old['raw_normalized_a']));b=list(map(F,old['raw_normalized_b']))
eta=list(map(F,old['actual_row_scaled']));zeta=list(map(F,old['actual_column_scaled']))
r=sum(eta,F(0));assert r==sum(zeta,F(0))==F(31,50)
raw=[[x*y for y in b] for x in a]
dbounds=[[[F(x) for x in v] for v in row] for row in old['whole_block_distance_bounds']]
assert old['n']==4
# Recompute whole-block distances and full uniform-density matching from the
# compact input, rather than trusting a detached incidence table.
left=[{key:F(value) for key,value in row.items()} for row in old['left_receivers']]
right=[{key:F(value) for key,value in row.items()} for row in old['right_receivers']]
for receivers,weights,source in [(left,a,F(-7,10)),(right,b,F(7,10))]:
 for v,weight in zip(receivers,weights):
  assert v['mass']==v['side']**4
  assert v['volume']==v['first_width']*v['other_width']**3
  assert abs(v['center_x1'])+v['first_width']/2+v['side']/2<4
  assert abs(v['center_x1']-source)+v['first_width']/2+F(1,2000)<v['side']/2
  assert v['rho_own_source']==v['volume']/v['mass']==F(1,10**13)*weight
for i,w in enumerate(left):
 for j,v in enumerate(right):
  d=abs(w['center_x1']-v['center_x1']);half=(w['first_width']+v['first_width'])/2
  assert dbounds[i][j]==[2*(d-half)/max(w['side'],v['side']),2*(d+half)/max(w['side'],v['side'])]
assert F(old['all_pair_masses_scale'])==F(old['raw_sourcewise_scale_rho_over_h'])**2
assert (F(3,2)**4)/min(v['mass'] for v in left+right)<13
alpha0=arb(1).exp();K2=arb(4).exp();thresholds=[alpha0,A(F(7,2)),A(F(9,2))]
scale=10**8

def rational_bounds(v):
 lo=F(math.floor(float(v.mid())*scale)-1,scale)
 hi=F(math.ceil(float(v.mid())*scale)+1,scale)
 while not v>A(lo):lo-=F(1,scale)
 while not v<A(hi):hi+=F(1,scale)
 assert 0<lo<hi
 return lo,min(F(1),hi)

shell=[];plo=[];phi=[]
for i in range(m):
 sr=[];lr=[];ur=[]
 for j in range(k):
  dl,du=dbounds[i][j];assert 0<dl<du
  found=False
  for z,limit in enumerate(thresholds):
   if A(du)<limit:
    if z:assert A(dl)>thresholds[z-1]
    sr.append(z);found=True;break
  assert found
  if z==0:ll,uu=F(1),F(1)
  else:
   ll,_=rational_bounds(K2/A(du)**4)
   _,uu=rational_bounds(K2/A(dl)**4)
   assert ll<uu
  lr.append(ll);ur.append(uu)
 shell.append(sr);plo.append(lr);phi.append(ur)
assert [[x==0 for x in row] for row in shell]==old['near_matrix']
assert eta==[sum((raw[i][j] for j in range(k) if shell[i][j]>0),F(0)) for i in range(m)]
assert zeta==[sum((raw[i][j] for i in range(m) if shell[i][j]>0),F(0)) for j in range(k)]
shell_floor=[F(1),rational_bounds(K2/A(F(7,2))**4)[0],rational_bounds(K2/A(F(9,2))**4)[0]]
assert all(shell_floor[shell[i][j]]<=plo[i][j] for i in range(m) for j in range(k))

cache={};lp_count=0

def exact_flow(caps):
 N=m+k+2;s=0;t=N-1;R=[[F(0) for _ in range(N)] for _ in range(N)]
 for i in range(m):R[s][1+i]=eta[i]
 for i in range(m):
  for j in range(k):R[1+i][1+m+j]=caps[i][j]
 for j in range(k):R[1+m+j][t]=zeta[j]
 while True:
  parent=[None]*N;parent[s]=s;Q=deque([s])
  while Q and parent[t] is None:
   u=Q.popleft()
   for v in range(N):
    if parent[v] is None and R[u][v]>0:parent[v]=u;Q.append(v)
  if parent[t] is None:break
  aug=None;v=t
  while v!=s:
   u=parent[v];aug=R[u][v] if aug is None else min(aug,R[u][v]);v=u
  v=t
  while v!=s:
   u=parent[v];R[u][v]-=aug;R[v][u]+=aug;v=u
 H=[[caps[i][j]-R[1+i][1+m+j] for j in range(k)] for i in range(m)]
 reachable={s};Q=deque([s])
 while Q:
  u=Q.popleft()
  for v in range(N):
   if v not in reachable and R[u][v]>0:reachable.add(v);Q.append(v)
 I=[1+i in reachable for i in range(m)];J=[1+m+j not in reachable for j in range(k)]
 return H,I,J

def solve(label,prefix,mode):
 global lp_count
 C=F(2)
 factor=[[F(1) if mode=='unweighted' else plo[i][j] if mode=='canonical' else shell_floor[shell[i][j]]
          for j in range(k)] for i in range(m)]
 caps=[[C*raw[i][j]*factor[i][j] if shell[i][j]<prefix else F(0) for j in range(k)] for i in range(m)]
 key=tuple(x for row in caps for x in row)
 if key in cache:H,I,J,floatval=cache[key];cached=True
 else:
  mat=np.zeros((m+k,m*k))
  for i in range(m):
   for j in range(k):mat[i,i*k+j]=1;mat[m+j,i*k+j]=1
  res=linprog(-np.ones(m*k),A_ub=mat,b_ub=np.array(list(map(float,eta+zeta))),
       bounds=[(0,float(v)) for row in caps for v in row],method='highs')
  assert res.success;lp_count+=1
  H,I,J=exact_flow(caps);floatval=-res.fun;cache[key]=(H,I,J,floatval);cached=False
 hr=[sum(row,F(0)) for row in H];hc=[sum((H[i][j] for i in range(m)),F(0)) for j in range(k)]
 value=sum(hr,F(0));assert abs(float(value)-floatval)<1e-10
 assert all(x<=y for x,y in zip(hr,eta)) and all(x<=y for x,y in zip(hc,zeta))
 assert all(0<=H[i][j]<=caps[i][j] for i in range(m) for j in range(k))
 du=[F(not x) for x in I];dv=[F(not x) for x in J]
 de=[[F(I[i] and J[j]) for j in range(k)] for i in range(m)]
 assert all(du[i]+dv[j]+de[i][j]>=1 for i in range(m) for j in range(k) if caps[i][j])
 dual=sum((du[i]*eta[i] for i in range(m)),F(0))+sum((dv[j]*zeta[j] for j in range(k)),F(0))+sum((de[i][j]*caps[i][j] for i in range(m) for j in range(k)),F(0))
 assert dual==value
 layers=[sum((H[i][j] for i in range(m) for j in range(k) if shell[i][j]==z),F(0)) for z in range(3)]
 assert sum(layers,F(0))==value
 # A single Cpsi cap covers ALL disjoint layers together, not a fee sum.
 effective=max((C*factor[i][j]/plo[i][j] for i in range(m) for j in range(k) if caps[i][j]),default=F(0))
 if mode!='unweighted':assert effective<=2
 primal_factor=max((H[i][j]/(raw[i][j]*plo[i][j]) for i in range(m) for j in range(k) if H[i][j]),default=F(0))
 assert primal_factor<=effective
 # Native continuous psi is variable inside blocks. Same lower mincut gives
 # an upper certificate for true canonical capacity, with no extra LP.
 true_upper=None
 if mode=='canonical':
  uppercaps=[[C*raw[i][j]*phi[i][j] if shell[i][j]<prefix else F(0) for j in range(k)] for i in range(m)]
  upperdual=sum((du[i]*eta[i] for i in range(m)),F(0))+sum((dv[j]*zeta[j] for j in range(k)),F(0))+sum((de[i][j]*uppercaps[i][j] for i in range(m) for j in range(k)),F(0))
  true_upper=min(r,upperdual);assert true_upper>=value
 tab=lambda z:[[str(v) for v in row] for row in z]
 out={'label':label,'prefix_layers':prefix,'mode':mode,'C_input':'2',
   'edge_caps_scaled':tab(caps),'primal_H_scaled':tab(H),'matched_mass_scaled':str(value),
   'remaining_deficit_scaled':str(r-value),'per_layer_mass_scaled':list(map(str,layers)),
   'Hall_cut_rows':I,'Hall_cut_columns':J,'dual_row':list(map(str,du)),
   'dual_column':list(map(str,dv)),'dual_edge':tab(de),'dual_exact_value_scaled':str(dual),
   'float_LP_value':float(floatval),'cached_identical_LP':cached,'exact_primal_dual':True,
   'certified_Cpsi_density_factor':str(effective),'selected_primal_Cpsi_density_factor':str(primal_factor),
   'canonical_true_capacity_maxflow_lower':str(value) if mode=='canonical' else None,
   'canonical_true_capacity_maxflow_upper':str(true_upper) if true_upper is not None else None}
 print(label,'matched=',value,'deficit=',r-value,'layers=',','.join(map(str,layers)),
       'Cpsi=',float(effective),'canonical true upper=',true_upper)
 return out

rows=[]
for prefix in [1,2,3]:
 rows.append(solve('unweighted_prefix_'+str(prefix),prefix,'unweighted'))
 rows.append(solve('canonical_soft_prefix_'+str(prefix),prefix,'canonical'))
rows.append(solve('shellfloor_soft_full_support',3,'shellfloor'))
# Conditional R444 geometric receipt, not a theorem for this masscut-failing field.
S=F(3);eps0=F(1,4);s=F(3);ratio=F(15,11)
An=1+4*A(ratio).log();B=An*An;assert B>2
Phi=2+2*(B/2).log();receipt=A(S*eps0*eps0/(s*s))*Phi
for row in rows:
 row['formal_R444_Phi_An2_Arb']=str(Phi)
 row['formal_R444_Cpsi_fee_X_coefficient_Arb']=str(A(F(row['certified_Cpsi_density_factor']))*receipt)
 row['formal_R444_selected_primal_fee_X_coefficient_Arb']=str(A(F(row['selected_primal_Cpsi_density_factor']))*receipt)
 row['receipt_is_conditional_not_applied_to_fixture']=True
rawpsi_lo=sum((raw[i][j]*plo[i][j] for i in range(m) for j in range(k)),F(0))
rawpsi_hi=sum((raw[i][j]*phi[i][j] for i in range(m) for j in range(k)),F(0))
report={'environment':{'executable':sys.executable,'python':platform.python_version(),'scipy':scipy.__version__,'flint':flint.__version__,'Arb_bits':ctx.prec},
 'input_dependency':'r446_numeric_input.json',
 'input_source_certificate_sha256':input_data['source_certificate_sha256'],
 'input_source_case_one_based':3,
 'same_actual_row_scaled':list(map(str,eta)),'same_actual_column_scaled':list(map(str,zeta)),
 'actual_mass_scaled':str(r),'pair_mass_scale':old['all_pair_masses_scale'],
 'whole_block_distance_bounds':old['whole_block_distance_bounds'],'layer_matrix':shell,
 'distance_thresholds':['exp(1)','7/2','9/2'],
 'psi_edge_lower':[[str(v) for v in row] for row in plo],
 'psi_edge_upper':[[str(v) for v in row] for row in phi],
 'shell_psi_lower':list(map(str,shell_floor)),
 'raw_pair_psi_integral_scaled_lower':str(rawpsi_lo),'raw_pair_psi_integral_scaled_upper':str(rawpsi_hi),
 'comparison_records':rows,'comparison_count':len(rows),'distinct_float_LP_solves':lp_count,
 'scope':'One true center/source field from R445; original masscut fails. Exact finite layered capacity evidence only, no native fullflow or U comparison claim.'}
(ROOT/'r446_numeric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',len(rows),'comparisons,',lp_count,'distinct tiny LPs, exact rational primal/mincut; all layers share source budgets.')
