from fractions import Fraction as F
from itertools import product

counts = [0, 0, 0]
def ck(ok, stage):
    assert ok
    counts[stage] += 1

def psi(x):
    return F(1) if x <= 1 else 1 / x

# Exact normalized variables x=(Delta/alpha0)^n and a=(radius/alpha0)^n.
xs = [F(0), F(1,8), F(1,2), F(1), F(3,2), F(2), F(7,2), F(6), F(20)]
windows = [(F(1), F(1,3)), (F(2), F(2,5)), (F(6), F(1,7))]
B = sum(a*c for a,c in windows)
for x in xs:
    k = sum(c for a,c in windows if x <= a)
    ck(k <= B*psi(x), 0)
    if k:
        pieces = [c/k if x <= a else F(0) for a,c in windows]
        ck(sum(pieces) == 1, 0)

# Below-base scope: native volume budget alone does NOT dominate.
a,c,x = F(1,4), F(1), F(1,8)
ck(c > a*c*psi(x), 1)
ck(c <= max(F(1), a)*c*psi(x), 1)
for a,c,x in product([F(1,4),F(1),F(3)], [F(0),F(1,3),F(2)], xs):
    ck((c if x <= a else 0) <= c*max(F(1),a)*psi(x), 1)

mu, nu = [F(1,3), F(2,3)], [F(1,4), F(1,2), F(1,4)]
raw = [[u*v for v in nu] for u in mu]
Gamma = [[F(0), F(0), raw[0][2]], [raw[1][0], F(0), F(0)]]
eta = [sum(row) for row in Gamma]
zeta = [sum(Gamma[i][j] for i in range(2)) for j in range(3)]
r = sum(eta)
xbase = [[F(1,2),F(2),F(6)], [F(7,2),F(2),F(2)]]
def deficit(cap):
    vals=[]
    for B in product([0,1],repeat=2):
        for T in product([0,1],repeat=3):
            val=sum(eta[i]*B[i] for i in range(2))+sum(zeta[j]*T[j] for j in range(3))-r-sum(cap[i][j]*B[i]*T[j] for i in range(2) for j in range(3))
            vals.append(max(F(0),val))
    return max(vals)
results=[]
for scale in [F(1),F(2),F(8),F(32)]:
    xmat=[[scale*x for x in row] for row in xbase]
    mix=[[raw[i][j]*(xmat[i][j]<=2) for j in range(3)] for i in range(2)]
    soft=[[2*psi(xmat[i][j])*raw[i][j] for j in range(3)] for i in range(2)]
    for i,j in product(range(2),range(3)):
        ck(mix[i][j]<=soft[i][j],2)
    dm,ds=deficit(mix),deficit(soft)
    ck(ds<=dm,2)
    results.append((str(scale),str(dm),str(ds)))
ck(results[0][1:] == ('1/12','0'),2)
ck(F(results[-1][2]) > 0,2)
# Explicit full soft plan in first case, confirming zero cut defect constructively.
H=[[F(1,12),F(0),F(0)],[F(1,12),F(0),F(1,12)]]
for i in range(2): ck(sum(H[i])==eta[i],2)
for j in range(3): ck(sum(H[i][j] for i in range(2))==zeta[j],2)
for i,j in product(range(2),range(3)):
    ck(H[i][j]<=2*psi(xbase[i][j])*raw[i][j],2)
print('PASS exact Fraction checks:',sum(counts),'stage counts:',counts)
print('scale, mixture deficiency, canonical deficiency:',results)
print('Scope: finite capacity/cut algebra only; no native cube or original-history realization.')
