"""Exact positive-width witnesses and certified integer-neighbour counts for R840."""

from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from functools import lru_cache
from itertools import pairwise, product
from math import comb, isqrt
import sys


BITS = 64
TERMS = 22
EPS = F(1, 2048)


def ceil(x):
    return -(-x//1)


def log_series(x):
    u = (x-1)/(x+1)
    assert 0 <= u <= F(1, 3)
    low = 2*sum(u**(2*j+1)/(2*j+1) for j in range(TERMS))
    return low, low+2*u**(2*TERMS+1)/((2*TERMS+1)*(1-u*u))


LN2 = log_series(F(2))


@lru_cache(maxsize=4096)
def log_bounds(x):
    assert x >= 1
    power = x.numerator.bit_length()-x.denominator.bit_length()
    power -= x < F(2)**power
    a, b = log_series(x/(F(2)**power))
    a += power*LN2[0]
    b += power*LN2[1]
    t = 1 << BITS
    return F(a*t//1, t), F(ceil(b*t), t)


def dec(iv):
    a, b = iv
    assert a <= b
    with localcontext() as ctx:
        ctx.prec = 13
        ctx.rounding = ROUND_FLOOR
        low = Decimal(a.numerator)/Decimal(a.denominator)
        ctx.rounding = ROUND_CEILING
        high = Decimal(b.numerator)/Decimal(b.denominator)
    return f"[{low}, {high}]"


@dataclass(frozen=True)
class Packet:
    center: F
    mass: F
    width: F = EPS

    @property
    def interval(self):
        return self.center-self.width/2, self.center+self.width/2

    def amount(self, lo, hi):
        left, right = self.interval
        return self.mass*max(F(0), min(right, hi)-max(left, lo))/self.width


def index(x, step, phase):
    return (x-phase)//step


def phases(points, step):
    cuts = sorted({F(0), step, *(x % step for x in points)})
    return pairwise(cuts)


def shift_law(x, y, step):
    cases = {}
    for lo, hi in phases((x, y), step):
        p = (lo+hi)/2
        h = abs(index(x, step, p)-index(y, step, p))
        cases[h] = cases.get(h, F(0))+(hi-lo)/step
    assert sum(cases.values()) == 1
    assert sum(h*p for h, p in cases.items()) == abs(x-y)/step
    return cases


def packet_law(p, q, step):
    if p == q:
        assert p.width < step
        # Two independent uniform points in one interval have E|x-y|=width/3.
        drift = p.width/(3*step)
        max_dist = p.width
        return {0: 1-drift, 1: drift}, max_dist
    first, second = sorted((p, q), key=lambda r: r.center)
    lo1, hi1 = first.interval
    lo2, hi2 = second.interval
    assert hi1 < lo2
    low, high = lo2-hi1, hi2-lo1
    old = low//step
    assert high//step == old
    # On this entire positive-width product the high cell jump probability
    # is affine in distance; its expectation is attained at the mean gap.
    p_up = (second.center-first.center)/step-old
    for a, b in product(first.interval, second.interval):
        law = shift_law(a, b, step)
        assert law == {old: 1-(b-a)/step+old, old+1: (b-a)/step-old}
    return {old: 1-p_up, old+1: p_up}, high


def assert_band(law, max_distance, theta, B):
    assert max_distance <= B
    k = ceil(2*B/theta)
    good = sum(p for h, p in law.items() if h <= k)
    assert good >= F(1, 2)
    return k, good


def grid_census(packets, step, phase):
    # Physical grid source masses from the actual Lebesgue densities.
    low = min(index(p.interval[0], step, phase) for p in packets)
    high = max(index(p.interval[1], step, phase) for p in packets)
    cells = {i: sum(p.amount(phase+i*step, phase+(i+1)*step) for p in packets)
             for i in range(low, high+1)}
    assert sum(cells.values()) == sum(p.mass for p in packets)
    return {i: w for i, w in cells.items() if w}


def certify_core(packets, X, length, contained):
    assert length > 0 and X[0] < X[1]
    for p in contained:
        lo, hi = p.interval
        assert X[1]-length/2 < lo < hi < X[0]+length/2
    for p in packets:
        if p not in contained:
            lo, hi = p.interval
            assert hi < X[0]-length/2 or X[1]+length/2 < lo


def charge(i, j, cells, k):
    assert abs(i-j) <= k
    # Larger actual grid mass pays. At equality choose the lower index.
    heavy = min((i, j), key=lambda a: (-cells[a], a))
    light = j if i == heavy else i
    assert cells[light] <= cells[heavy]
    allowed = {g for g, w in cells.items() if abs(g-heavy) <= k
               and (-cells[heavy], heavy) <= (-w, g)}
    actual_pool = sum(cells[g] for g in allowed)
    assert len(allowed) <= 2*k+1 and actual_pool <= (2*k+1)*cells[heavy]
    return heavy, light, actual_pool


def whole_packet_phases(packets, step):
    points = tuple(x for p in packets for x in p.interval)
    for a, b in phases(points, step):
        phase = (a+b)/2
        if all(index(p.interval[0], step, phase) == index(p.interval[1], step, phase)
               for p in packets):
            yield phase, (b-a)/step


def unit_window():
    packets = (Packet(F(-1, 4), F(3, 4)), Packet(F(1, 4), F(3, 4)))
    X, witness = (F(-1, 8), F(1, 8)), F(5, 4)
    certify_core(packets, X, F(1), packets)
    m = sum(p.mass for p in packets)
    theta, B = F(2, 7), F(2, 3)
    step = theta
    phase = step/2
    cells = grid_census(packets, step, phase)
    assert m/witness == F(6, 5) > 1 and m/2 == F(3, 4)
    by_packet, by_arm, mass_all = {}, [F(0), F(0)], F(0)
    print("1D strict [1,2] witness at L=5/4; J_X(left)=9/100, top A_2=3/4, external top source mass 0.")
    for p, q in product(packets, repeat=2):
        law, distance_max = packet_law(p, q, step)
        k, good = assert_band(law, distance_max, theta, B)
        i, j = (index(r.center, step, phase) for r in (p, q))
        heavy, light, pool = charge(i, j, cells, k)
        J = (X[1]-X[0])*p.mass*q.mass/witness**2
        mass_all += J
        arm = 0 if i == heavy else 1
        by_arm[arm] += J
        by_packet[heavy] = by_packet.get(heavy, F(0))+J
        print("  ordered source", (p.center, q.center), "J_X", J, "shift law", law,
              "k", k, "good", good, "heavy/light index", (heavy, light),
              "heavy cell mass", cells[heavy], "unique accepted pool", pool, "K*m", (2*k+1)*cells[heavy])
    assert mass_all == F(9, 25) and by_arm == [F(27, 100), F(9, 100)]
    assert sorted(by_packet.values()) == [F(9, 100), F(27, 100)]
    print("  J_X full", mass_all, "oriented mass once by source arm at phase", phase,
          by_arm, "by physical charged cell", by_packet)
    safe = F(0)
    for candidate, weight in whole_packet_phases(packets, step):
        safe += weight
        cell_map = grid_census(packets, step, candidate)
        left_i, right_i = (index(p.center, step, candidate) for p in packets)
        assert left_i < right_i and cell_map[left_i] == cell_map[right_i] == F(3, 4)
        assert charge(right_i, right_i, cell_map, k)[2] == F(3, 4)
        assert charge(right_i, left_i, cell_map, k)[0] == left_i
    assert safe == 1 - 2*EPS/step
    print("  whole-packet phase probability", safe, "uniform-shift arm mass enclosures",
          [(safe*w, safe*w+(1-safe)*mass_all) for w in by_arm])


def multiband():
    z1 = Packet(F(-1, 4), F(1, 2))
    q = Packet(F(1, 4), F(1))
    z2 = Packet(F(-15, 16), F(3, 2))
    packets = z1, q, z2
    X1 = F(-1, 32), F(1, 32)
    X2 = F(-11, 64), F(-9, 64)
    rows = ((z1, X1, F(5, 4), 1, (z1, q)), (z2, X2, F(2), 2, packets))
    assert X2[1] < X1[0]
    theta, B = F(2, 7), F(3, 2)
    phase = theta/2
    cells = grid_census(packets, theta, phase)
    charged = {}
    print("Two strict witnesses in the same [1,2] window, lambda 1, same physical grid step",
          theta, "and phase", phase, "shared q of mass", q.mass)
    near_mass, total_mass = z1.mass+q.mass, sum(p.mass for p in packets)
    assert near_mass == F(3, 2) and total_mass == 3
    print("  witness lengths are fixed, D denotes the dyadic band of the witness volume.")
    for z, X, length, D, inside in rows:
        certify_core(packets, X, length, inside)
        m = sum(p.mass for p in inside)
        assert 1 <= length <= 2 and m/length > 1 and D <= length < 2*D
        distance_to_third = X[0]-z2.interval[1]
        assert distance_to_third > F(3, 4)
        # For l<=3/2, the far packet is absent and A_l <= near_mass/1.
        # For l>=3/2, A_l <= total_mass/(3/2). Both cover the whole window.
        M_upper = max(near_mass, total_mass/F(3, 2))
        assert M_upper == 2
        assert z.interval[1] < X[0] < X[1] < q.interval[0]
        law, far = packet_law(z, q, theta)
        k, good = assert_band(law, far, theta, B)
        i, j = (index(p.center, theta, phase) for p in (z, q))
        heavy, light, pool = charge(i, j, cells, k)
        assert (cells[i], cells[j]) == (z.mass, q.mass)
        assert cells[heavy] == max(z.mass, q.mass)
        owner = q.center if j == heavy else z.center
        pair_mass = (X[1]-X[0])*z.mass*q.mass/length**2
        charged[owner] = charged.get(owner, F(0))+pair_mass
        safe = F(0)
        for candidate, probability in whole_packet_phases(packets, theta):
            safe += probability
            cell_map = grid_census(packets, theta, candidate)
            i_alt, j_alt = (index(p.center, theta, candidate) for p in (z, q))
            selected, _, _ = charge(i_alt, j_alt, cell_map, k)
            assert (q.center if j_alt == selected else z.center) == owner
        assert safe >= 1-3*EPS/theta
        print("  D", D, "X", X, "L", length, "mu(Q)", m, "A_L", m/length, "J_X", pair_mass,
              "law", law, "k", k, "good", good, "heavy/light", (heavy, light),
              "heavy mass", cells[heavy], "pool", pool, "K*m", (2*k+1)*cells[heavy],
              "fixed orientation phase mass >=", safe, "min distance to third", distance_to_third,
              "M_[1,2] upper", M_upper)
    assert charged == {q.center: F(1, 50), z2.center: F(3, 256)}
    print("  fixed q participates in both bands; assigning both row masses to q gives",
          sum(charged.values()), "at the tested phase; actual charges", charged)


def pressure():
    theta, n = F(1, 8), 16
    q, z = Packet(F(-1, 1024), F(1), F(1, 16384)), Packet(F(1, 1024), F(1), F(1, 16384))
    single, max_dist = packet_law(q, z, theta)
    p = single[1]
    distribution = {h: comb(n, h)*p**h*(1-p)**(n-h) for h in range(n+1)}
    assert sum(distribution.values()) == 1 and sum(h*w for h, w in distribution.items()) == n*p
    B = n*max_dist
    k = ceil(2*B/theta)
    good = sum(w for h, w in distribution.items() if h <= k)
    assert k < n and good > F(1, 2)
    assert index(q.interval[1], theta, F(0)) == -1 and index(z.interval[0], theta, F(0)) == 0
    # Independent axial shifts on the two actual n-dimensional product boxes.
    # A neighbourhood of the fixed zero shift sends every point pair across n axes.
    print("16D positive boxes straddling all fixed grid seams: H=16 at phase zero,",
          "mean under random vector shift", n*p, "P(H=16)", distribution[n],
          "k", k, "P(H<=k)", dec((good, good)))
    for weights in ((F(1),)*4, (F(1), F(1, 2), F(1, 4), F(1, 8))):
        sources = tuple(Packet(F(j, 4), x) for j, x in enumerate(weights))
        grid = grid_census(sources, F(1, 4), F(1, 8))
        a = index(sources[0].center, F(1, 4), F(1, 8))
        charges = [charge(a, index(p.center, F(1, 4), F(1, 8)), grid, 3) for p in sources]
        assert all(heavy == a and pool == sum(weights) for heavy, _, pool in charges)
        print("  fixed heavy anchor mass", grid[a], "neighbour masses", weights,
              "deduplicated pool", sum(weights), "K*m", 7*grid[a])
    inner = (Packet(F(-1, 4), F(31, 32)), Packet(F(1, 4), F(31, 32)))
    outer = Packet(F(33, 32), F(10))
    X, L, pad = (F(-1, 128), F(1, 128)), F(15, 8), F(1, 8)
    whole = inner+(outer,)
    certify_core(whole, X, F(1), inner)
    certify_core(whole, X, F(2), inner)
    certify_core(whole, X, L+2*pad, whole)
    local = sum(p.mass for p in inner)
    padded = (local+outer.mass)/(L+2*pad)
    assert L+2*pad > 2 and local/L > 1 and local/2 < 1 and padded > local
    print("  top pressure L", L, "L+2*pad", L+2*pad, "M_[1,2]", local,
          "A_2", local/2, "genuine padded average", padded,
          "outside-[1,2] positive source mass", outer.mass,
          "J_X(full at strict L)", (X[1]-X[0])*(local/L)**2)


def exact_count(n, k):
    return sum(2**j*comb(n, j)*comb(k, j) for j in range(min(n, k)+1))


def mode(n, k):
    lo, hi = 0, min(n, k)
    while lo < hi:
        j = (lo+hi)//2
        if 2*(n-j)*(k-j) > (j+1)**2:
            lo = j+1
        else:
            hi = j
    assert lo == 0 or 2*(n-lo+1)*(k-lo+1) >= lo**2
    assert lo == min(n, k) or 2*(n-lo)*(k-lo) <= (lo+1)**2
    return lo


def binom_bounds(n, j):
    if j in (0, n):
        return F(0), F(0)
    a, b = log_bounds(F(n, j)), log_bounds(F(n, n-j))
    # Binomial atom j maximizes the probability at parameter j/n.
    return j*a[0]+(n-j)*b[0]-log_bounds(F(n+1))[1], j*a[1]+(n-j)*b[1]


def count_bounds(n, k):
    j = mode(n, k)
    a, b = binom_bounds(n, j), binom_bounds(k, j)
    lo = j*LN2[0]+a[0]+b[0]
    hi = j*LN2[1]+a[1]+b[1]+log_bounds(F(min(n, k)+1))[1]
    # Independent generating-function upper bound with a rational near-saddlepoint.
    if k:
        r = F(k, n+isqrt(n*n+k*k))
        assert 0 < r < 1
        c, e = log_bounds((1+r)/(1-r)), log_bounds(1/r)
        hi = min(hi, n*c[1]+k*e[1])
    assert lo <= hi
    return max(F(0), lo), hi


def optimise(n, B, cap):
    grid = sorted({x for x in (F(1, 256), F(1, 128), *(F(i, 64) for i in range(1, 65))) if x <= cap}
                  | {cap})
    results = []
    for theta in grid:
        k = ceil(2*B/theta)
        lo, hi = count_bounds(n, k)
        results.append((theta, k, lo, hi))
    # On each interval K decreases as theta increases. The first interval
    # extends all the way to zero; it needs no extrapolation.
    lo = min(n*a+x[2] for a, x in zip((F(0), *grid[:-1]), results, strict=True))
    theta, k, _, log_hi = min(results, key=lambda row: n*row[0]+row[3])
    hi = n*theta+log_hi
    assert lo <= hi
    if n <= 256:
        exact = log_bounds(F(exact_count(n, k)))
        c = count_bounds(n, k)
        assert c[0] <= exact[0] <= exact[1] <= c[1]
    print("  n", n, "B", B, "theta cap", cap, "selected theta", theta, "k", k,
          "log K selected", dec(count_bounds(n, k)), "(n*theta+log K)/n optimum", dec((lo/n, hi/n)))


def growing():
    for n, k in product(range(1, 4), range(5)):
        brute = sum(sum(map(abs, v)) <= k for v in product(range(-k, k+1), repeat=n))
        exact = exact_count(n, k)
        assert brute == exact
        a, b = count_bounds(n, k)
        lo, hi = log_bounds(F(exact))
        assert a <= lo <= hi <= b
    print("Integer ball K cross-check passed on 15 complete lattice enumerations.")
    print("B=ceil(sqrt(n))*ceil(log(n+2)); finite interval certificates, no asymptotic extrapolation.")
    for n in (16, 256, 4096, 65536, 2**20, 2**24):
        a, b = log_bounds(F(n+2))
        assert ceil(a) == ceil(b)
        B = ceil(a)*(isqrt(n)+(isqrt(n)**2 != n))
        for cap in (F(1, 2), F(1, 4)):
            optimise(n, B, cap)


def main():
    print("Python", sys.version.split()[0], sys.executable, "Fraction +", TERMS, "log terms,", BITS, "bits")
    unit_window()
    multiband()
    pressure()
    growing()
    print("Finite exact geometry and growth tests; general historical eligibility not asserted.")
    print("PASS")


if __name__ == "__main__":
    main()
