# R654 最终整合独立总账审核

**结论：PASS（限定于已审核部分预算、符号、适用域及未证范围的正确整合）；无阻塞项。一般中心立方体 `n^(1/2+o(1))` 弱 `(1,1)` 上界、完整正期望增量、good-alpha 相关项和受控全状态递推仍未证明。**

## 冻结绑定与本次范围

已实际读取并用本机 SHA-256 核对：

| 冻结文件 | SHA-256 |
| --- | --- |
| `/tmp/ccu_r654/REPORT.tex` | `ff8690fcd400a5361d3a2ebf2fe3ddc7903ddeb88ae0997a84a8106ae9665f38` |
| `/tmp/ccu_r654/NEXT_TARGET.md` | `0ea0c11a6d86bf5394e2e193e0ef03e9f0d6df357b1a2591a5d53b1fd64bf56f` |

本次只做最终整合审核，沿用此前 `CORRELATION_AUDIT.md`／`RESTORATION_AUDIT.md` 中已经独立完成的解析及实际数学工具核验，不重复已通过的计算、不扩展研究。重点是完整 D 与辅助 B 值比较的符号、双配置 bad 常数、good 残项及 r14 后继域。产品源／kernel 的独立专项审查和数值证书真实性不在本次重审范围；本文件只核它们在终稿中的用途与结论边界。

## 1. 完整对象与 high-only reserve — PASS

终稿始终保留

`D=E-O+F+RS=W-RQ'=W-(1+kappa)V+RS`，

全部旧／删除 incoming 行、真实独立 Euler anchors、实际 joint owner／alpha，以及固定 delta baseline。没有固定 alpha 后重分 owner 或把 irregular-image 损失与补偿 fill 拆开冒称未付。

tag K 从所有旧行按 `a_k/M` 抽取，q 独立 uniform 于真实 `I_K`。高 tag 只通过 indicator 限制，没有在 H 内重归一化。high-only ghost 分解和完整期望式保留同一 reserve 的 `S_low^ghost>=0`、实际物理 `u/epsilon` loss、全部 F 和 Delta_low，并保留原 `11/12 E_low`。

low-covariance `7/12` 吸收只作为替代账本，终稿与 NEXT_TARGET 均明确不能再领取为新信用。旧低行清理仍需旧 `kappa>=7/2`，未自动传给任意后继。

## 2. 两配置 bad-alpha 常数及边界 — PASS

实际 correction 的对称式有正确 factor 1/2。bad event 为

`alpha_k(Z)>=tau OR alpha_k(Z^(k))>=tau`，

swap 对称，两个配置分别完整重算且 unavailable 行分别置零。四个固定旧-cube 测试在 [0,1] a.s. 的边界论证和高行 `sum_H a_k alpha_k <=(2epsilon/a^n)Q'` 均按已审范围整合。

正确 bound 为

`|Gamma_H,bad|<=4epsilon M/(tau a^n)`，

`R|Gamma_H,bad|<=4kappa M/(tau a^n)`。

tau=1/4 给 `16kappa M/a^n<=64M/a^n`，已经包括两配置；没有误用单配置 factor 8。它只支付一次 signed-correction expense，可并入单一 CLM，未被称为完整物理损失付款。

经验源是合法 a.s. packing probe，而非实际下一代 KKT 源；固定测试无偏没有被用于断言自适应 coverage 无偏。相关性缺口没有被边界合法性掩盖。

## 3. B 比较费用与完整 D 的相反删除符号 — PASS

REPORT 的 adding-row 部分使用真实 feasible comparison `p_tilde^+,beta` 给实际 `B^+_*` 的**上界**。正 baseline 的统一 recipient floor 保留为 `d_k=m_k/(1+u_k)`，没有误换成 m_k；新 unavailable 行先被删除，新增正 owner 由合法 simplex floor 支持，包括 k unavailable 的情形。

该 B 值上界保留 `Qdel/epsilon`、精确 donor Xi、global/local mass ratio。它们没有被压成无 mass-range 的局部面积费，也没有被称为实际 alpha／owner map 稳定性。固定原 p 的两配置 `36epsilon M/a^n`（B 对应部分 `36M/a^n`）明确只是条件费用，原 p 可能不可行、support 仍可能变化，不能升级为整个 joint repair 或 Gamma_good 界。

在**同一 full tuple Z**、固定旧 R,mu,m 的删 k 参考域上，终稿正确写为

`Q'(Z)-Q^(-k)=a'_k+B_ret,k-Qdel_k`，

`D(Z)-mathscrD^(-k)=Delta W_k+R Qdel_k-R a'_k-R B_ret,k`。

`mathscrD^(-k)` 仅为比较 functional，不是新的独立校准 Euler gain；每个 minus 配置没有新源预算。删除源质量对全 D 的符号是有利的 `+R Qdel`。报告明确禁止把 B 中正 `Qdel/epsilon` 升格为物理障碍，也禁止将比较 beta 代替实际 alpha 来计算 D。

所有 plus 共用同一 Z 的实际 alpha，故高 tag own-row 费 `<=2kappa M/a^n` 的 aggregate 正确。未证明的是净 survivor rebound 相对有利删除的实际联合控制；终稿没有声称 Q' 单调。

`S=T+C` 的固定-probe 删除补偿和换-probe 对消均保留，并强调 high-only population 行质量应为 `integral_Aj w_H dmu`，low reserve 加回后才恢复 m_j。没有孤立地把 adverse Gamma availability 既收费、又忽略其匹配 reserve；也没有由补偿恒等式宣称实际重优化已付款。

## 4. Good 部分与完整未付目标 — PASS 作为未证合同

REPORT 最后未付表达式恰为

`-E D+R Gamma_H,bad`。

所以证明其 `<=-cV+CLM`，再扣一次 bad 费，才会给完整目标；这个联合估计尚未提供。正文与 NEXT_TARGET 一致保留：good-alpha／availability 的净效应、物理 loss／coverage、fill、全部层／siblings／旧标签、uniform-in-N 要求，以及全状态后继损失和终端／可和性费用。

既有全状态望远镜保留真实质量权重、`E'=(1+kappa_next)E_next` 和每个下一步 O/F/S。低-kappa 不被自动宣布 terminal。四倍最终势能只付一次，不能逐 receiver／层／path／comparison 重新领取。没有把表示式、receiver marginal product、local B value fee 或 coefficient headroom 当成 leading cV 证明。

## 5. r14 后继 kappa'>4 与数值范围 — PASS

终稿与 NEXT_TARGET 明确说明严格 n=2、r14、正宽 fixture 虽有旧 `kappa=1755/457` 位于数值临界带，但

`R=711/935936<1`，无全局 near-score 证书，且实际

`u'_j=kappa'=390/79>4`。

因此它不属于要求 same-class calibrated successor cap `kappa'<=4` 的域，不能验证该域的定理。特别 fixed-p `36epsilon M/a^n` 费用所用 `epsilon W<=4Q'` 不可由此 fixture 验证。报告没有将其 `S=Gamma=0,D>0` 当成 near-score、普遍相关性符号或完整 branch theorem 的证据。

r64 的 width-zero 浮点探索、完整 mean 为正且部分 tags 为负、无正宽 AC 证书、失败 SCS 检查及撤回的 Q=M 归一化错误均明确保留。此次没有重跑或独立认证数值 artifact；认证的是终稿对这些证据的范围表述没有越界。

## 6. 恢复桥与最后交付边界 — PASS

终稿准确继承已独审桥

`C_n<=sup_N T_N(0)<=P C_n`，

`C_n<=sup_N T_N(epsilon_N)<=5P C_n`，`P=(1+1/(32n))^n<2`。

正向恢复直接从原 bad-set 中心的 receiver 开覆盖选有限子覆盖，没有最终 a^n 乘子；有限 N 的 a^n 只进入校准规模。统一 surrogate 上界及完整几何假设仍未证明。产品源选择没有被表述成特殊几何假设，也没有把原输入替换成辅助 KKT 源。

**最终 PASS：可以按“合法源选择／精确表示、若干已定价部分预算与完整剩余问题”交付；不能按一般弱型改善、完整正增量或闭合递推已证交付。** 无阻塞项，无需为了本次整合修改作者文件。仅写此审计，未用 Git/API/PDF/子代理，未读取凭据；交付后停止。
