# R654 frozen tensor computation

## Decision and scope

All 64 independent Euler tags were evaluated separately for each of r=64 and r=14 at width zero, with actual receiver/C arrangements, capture eligibility, delta=1/100 baseline and per-tuple joint owner/entropy optimization. **This is an atomic-limit diagnostic, not an absolutely continuous source certificate.** Neither the observed mean nor a single negative tag establishes a general Gamma theorem, a positive-width counterexample, a near-score state, or an arbitrary-dimensional result. At r=64 the old kappa is above 4; at r=14 it lies in the critical band but R is small and near-score is not established.

| Parameter | exact Q | exact R | exact kappa | complete 64-tag Gamma mean | S mean | D mean |
|---|---|---|---|---:|---:|---:|
| r=64 | 4019/359 | 3231/4115456 | 87885/4019 | 0.45454607497 | 105.93707005 | 0.11656221652 |
| r=14 | 914/79 | 711/935936 | 1755/457 | 0, analytically | 0, analytically | 0.01214612965 |

The r=64 values in this table use the independent scalar KKT check below, which is more accurate than the raw CVXPY output. Its per-tag Gamma ranges approximately from -1.3929637781 to 2.3020559281. These individual negative tags do not make the complete mean negative. The r=14 analytic identities concern the width-zero geometry, whose incidence was enumerated using floating square roots: they do not certify a positive-width anchor box.

For r=64 the complete mean W=0.234375, E=0.04901716845, O=0.015625, F=0, RS≈0.08317004807, Q'≈150.06292995; the complete mean S−Gamma≈105.48252398 is the tagged slack. For r=14 W=0.0546875, E≈0.01214612965, O=F=RS=0, Q'=56, S=0. We checked the same-tuple ledger D=E−O+F+RS=W−RQ' to floating residual below 4e-18. All nine old weights remain in Gamma even when a new label is unavailable.

## Frozen stages and validation

1. **r=64:** n=2, a=64, r=64 and 64 equally weighted corner-tag tuples; no scan and no symmetry substitution. A three-tuple cost probe was followed by all tuples. Each tuple has strict origin margin 69/128=0.5390625, proving the simplex packing for these finite atomic tags once the radii/centers are evaluated; enumeration gave exactly one nine-row maximal C incidence for all 64. All eligible image atoms were singleton sets in this calculation. Consequently ownership and q are forced, including the positive baseline. No α was frozen before optimization.
2. **R653 pressure test:** the input protocol's independent analytic positive-width two-branch calculation gives Γ=18/25, with actual KKT α=(7/10,3/10) and old inputs retained. This is a scope/normalization comparison, not another run of the old four scripts and not a proof for the tensor family.
3. **r=14:** all 64 tags, with actual positive-area C incidence enumerated separately per tuple; the r=64 simplex was not reused. There are four maximal packing cells, the four old 2×2 index blocks. Each eligible image atom is singleton and p_j=m_j/4096. Thus α_j=1/4 satisfies all four packing constraints and the entropy KKT with common positive dual multiplier `14*(1+e)` in gradient units `m+epsilon*p/alpha`. The resulting Q'=Σm/4=56=M. Each old anchor tag lies in exactly four old A rows, whence Σ_j G_j=4Σ_k a_k−Σ_j m_j=0 and each tag has Γ=0. This KKT check is conditional on the stated atomic incidence, rather than an interval proof of that incidence or a positive-width assertion.

The strict geometry checks use midpoint arrangements and floating arithmetic; cells with side width ≤1e−12 are discarded. No rigorous enclosure of square roots or topology changes is asserted. All rows are high (`m/4−1>1/2`), so each image atom admits an owner only when its new C contains every incoming old A. The minimum nonzero capture-containment margin measured was 0.34405 (r=64) and 0.44222 (r=14); this does not certify that no equality occurs or prove uniform stability for positive widths.

Computational review thresholds were specified after execution, rather than frozen before execution as requested; the raw residuals below and the independent KKT checks are therefore the evidence. The retrospective thresholds were: packing violation ≤1e−8, atom-conservation residual ≤1e−8, minimum-price mismatch ≤1e−7, and raw primary alpha stationarity residual ≤2e−5 in the objective's scaled units. All 128 Clarabel primary and secondary statuses were `optimal`, and all met these thresholds. Maximum observed primary packing violation was zero; maximum owner/secondary residual 1.88e−13; minimum-price mismatch zero; alpha stationarity residual max 1.07e−5 (r=64), 1.87e−6 (r=14). These are numerical acceptance tolerances, not proof tolerances. A posteriori scalar/closed-form KKT checks provide sharper evidence for the recorded values.

## Independent KKT and solver cross-check

For r=64, simplex KKT with forced p gives `alpha_j=epsilon*p_j/(nu−m_j)` on retained rows and `Σ alpha=1`; an independent SciPy Brent solve computed nu for each tuple. Maximum KKT gradient residual was 9.1e−13, and the largest alpha difference from Clarabel was 7.18e−6; the raw Clarabel Γ mean was 0.45453388347, so the refined result above is preferred. The differing reported significant digits are numerical effects, not bounds. The independent check verifies every singleton eligible atom and simplex incidence before applying this equation.

For r=14 the exact 1/4 solution above gives maximum floating reconstruction residual 9.1e−13; Clarabel α differed from 1/4 by up to 1.47e−5, so its tiny reported nonzero S and Γ should not be mistaken for true signs. SCS also solved four r=14 tags as `optimal`; its α agreed within 6.12e−6 with Clarabel. A requested SCS cross-check of r=64 encountered an `optimal_inaccurate` warning and a secondary Clarabel failure, producing no valid result; it is not included as evidence. The separate scalar check does not depend on SCS.

## Commands, execution, limitations

The frozen old-state exact values were obtained using Python Fraction, with old λ fixed by the supplied saturated-cell KKT construction. `Q=Σ4λ`, `V=9/1024`, `M=4r`, `R=V/Q`; every normalized value agrees with the coordinator's independent `parameter_screen.json`. An initial draft mistakenly used `Q=Σλm=M`; its D and κ were withdrawn and both runs replaced after correction. The Gamma objective itself does not depend on Q, but the final full reruns and checks are the only results reported here.

Run with `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`:

```sh
python /tmp/ccu_r654/numeric/tensor_gamma.py 64 > /tmp/ccu_r654/numeric/r64_all.json
python /tmp/ccu_r654/numeric/tensor_gamma.py 14 > /tmp/ccu_r654/numeric/r14_all.json
python /tmp/ccu_r654/numeric/independent_kkt.py > /tmp/ccu_r654/numeric/independent_kkt.json
CROSS_SCS=1 python /tmp/ccu_r654/numeric/tensor_gamma.py 14 0 5 31 63 > /tmp/ccu_r654/numeric/r14_scs.json
```

The `python` in each line denotes the absolute interpreter above. The full runs took 0.443 and 0.509 seconds respectively inside the processes, after initialization. Single-process peak RSS in the one-tuple measured probe was 111,116,288 bytes (≈106 MiB); all runs used one process with OpenBLAS and OMP set to 1. Environment CPython 3.12.14, CVXPY 1.9.3, Clarabel 0.11.1, NumPy 2.5.4, SciPy 1.18.1. No MATLAB job, geometry scan, random draw, or high-dimensional quadrature was run.

The code partitions the receiver union and new cubes into positive-area rectangular cells, aggregates identical eligibility masks, enforces the positive baseline and genuine packing constraints, solves the joint relative-entropy program, then applies a least-squared atom-allocation selector at the primary p and α. Each JSON records tags, availability, allocation, packing, primary and secondary statuses/residuals and complete ledger. Because equality in the second numerical optimization is imposed at approximate primary q, these results remain numerical; here every eligible mask is a singleton and the selector is forced.

## Artifact SHA-256

| Artifact | SHA-256 |
|---|---|
| tensor_gamma.py | 5de2a1a48cc7e0b68ba2c420aa7cb7dfd06111a089f831d3b8fdad191219b430 |
| independent_kkt.py | 6ff0b9cb05dd77e4098f8cb9b5bbbfc58525b311a1bac06a8e1fcfba66569bf7 |
| r64_all.json | ef0b5af76bac100ac3389701349b19a06250da98c884d6b45df17272dd15cb7b |
| r14_all.json | f6a62345158c0b86b468f5975a2b205588032df7c3c363689b7627906d52777e |
| independent_kkt.json | df2db187e32994e6121d703a2d4466abb288d7ba89cc7394d92a10e0f0a1eb38 |
| r14_scs.json | 80f51b6ac784f9027b2161feb277527a44c8591f9ecc7ea523f49512738d39b8 |

## Supplemental rigorous positive-width r=14 certificate

After the atomic runs, the separately authorized positive width `w=1/65536` was checked by `/tmp/ccu_r654/numeric/r14_ac_certificate.py`, without rerunning CVXPY. For each radius the script brackets its square root by consecutive rational numbers of denominator 10^32 using `math.isqrt` and verifies each squared bound. All subsequent arithmetic is exact Python Fraction. For a zero-coordinate old row, it conservatively encloses both disconnected anchor boxes by the full interval [-1,1]; for nonzero coordinates it uses the actual inward box. Center ranges follow `c=y+(t−1)(y−X)/2`. Thus every allowed continuous anchor tuple is included.

The exact per-pair and per-clique bounds are recorded in `r14_ac_certificate.json`:

- All 36 distinct receiver pairs have a separating coordinate, with smallest rational gap `2443423255390501616235538400055243/2560000000000000000000000000000000 > 0` (about 0.95446). Every B' is disjoint, so each image owner is forced, the fill is zero and `p_j=|B'_j|=t_j²/1024=m_j/4096`.
- Each of 16 pairs of old row indices with opposite nonzero signs in some coordinate has a separating coordinate for its new C, with smallest rational gap `951308239040080580869748800672341/3200000000000000000000000000000000 > 0` (about 0.29728). Any set with a common new C point therefore cannot contain opposite signs in either coordinate, so has at most four labels: the rows in one of the four 2×2 sign blocks.
- Each of those four blocks has positive common intersection in both coordinates; the smallest intersection-width lower bound is `839327224625361956403241279838147679/655360000000000000000000000000000000 > 0` (about 1.28071). Rectangle coordinate intersection, or interval Helly, gives positive-area four-row cells. Together with the preceding pair separation these four constraints fully describe packing: no larger or additional maximal clique can occur.

Here `e=390/79`, `epsilon=399360/79`, `M=56`, `Q=914/79`, and `R=711/935936`. Since `p_j=m_j/4096` and `alpha_j=1/4`, every new entropy gradient is `m_j+epsilon*p_j/alpha_j=m_j(1+e)`. Give each of the four sign-block cells the positive dual multiplier `14(1+e)`; each corner, side, and center row occurs in one, two, and four blocks, respectively, exactly matching its gradient. This proves the actual unique entropy optimizer and the forced joint-program solution at every anchor tuple, with delta=1/100. Then `Q'=sum_j m_j/4=56=M` and `S=0`.

For each source sign box, exactly the four corresponding old cubes contain its points throughout the box. Therefore `sum_j G_j=4 sum_k a_k−sum_j m_j=4M−4M=0`, so `Gamma=0` for each tuple and hence under the full continuous independent Euler law. The genuine source is uniform of mass 14 on each positive-area box; this is an actual AC check, not an atomic continuity argument. The result remains restricted to this one low-R finite model and does not establish a near-score or dimension theorem.

Reproduce: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r654/numeric/r14_ac_certificate.py > /tmp/ccu_r654/numeric/r14_ac_certificate.json`. SHA-256: script `e4f2a159a4499cce4312da9f073eec000e4649f5cbbeba0a8b96168828d70050`; JSON `3af940f4cda75a9aa61d89a9b1fde7ae443c118b2f664131adc343eec848ae67`.

## Calibration scope correction

For the certified r=14 successor, `p_j=m_j/4096`, `alpha_j=1/4`, and `epsilon=1024e`, so every actual `u'_j=epsilon p_j/(m_j alpha_j)=e=390/79>4`. Since `sum_j m_j=224`, `W=224/4096=56/1024` and `Q'=56`, so `kappa'=epsilon W/Q'=epsilon/1024=390/79>4`. Although old `kappa=1755/457` lies in the critical band, this fixed-epsilon state does not satisfy the successor `kappa'<=4` condition of the calibrated hard class. The r=64 old `kappa=87885/4019>4` is also outside that class. The rigorous r=14 `S=Gamma=0` conclusion remains valid for the genuine low-R finite AC model; it is not a calibrated hard-state result.
