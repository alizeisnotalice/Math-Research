# R654 independent numerical audit

## Verdict and actual scope

**PASS for the fixed r=14, w=1/65536 positive-width geometry and its exact conclusions alpha_j=1/4, S=Gamma=0.** This is a genuine full-support AC Euler model, not an atomic continuity inference. I first reviewed the mathematical structure, then inspected the author scripts/JSON, independently reran only `r14_ac_certificate.py`, obtained identical JSON bytes, and performed an independent exact Fraction postcheck of the old KKT constants and new entropy dual witness. No full CVXPY run, 64-tag solve, MATLAB job, geometry scan, PDF, API call or Git operation was rerun.

The original r=64 and r=14 64-tag outputs remain floating atomic-limit diagnostics. The later r14 certificate independently resolves the width/packing/KKT issue for ONE positive width; it does not retroactively turn every floating claim into a rigorous certificate. The r14 model has old kappa=1755/457 in the intended numerical band but R=711/935936<1 and is not a certified near-score hard state. Its actual successor kappa is 390/79>4, so it also fails the same-class calibrated successor bound; matching the old kappa band does not make it an admissible calibrated hard-state test. Near-old-source optimality was not certified here either. The r64 old kappa exceeds four, and no positive-width r64 Gamma sign is accepted by this audit.

## 1. Independent mathematical review of the old state

There are nine n=2 old cubes with halfside one and centers y=(127/64)(h_1,h_2), h_i in {−1,0,1}; a=64. The old owners I_j=B_j have area 1/1024 and are pairwise disjoint. The four inward source squares at (±1,±1) have width 1/65536 and mass 14 each; their densities are finite and positive. Each coordinate is in exactly its zero old interval and its corresponding signed old interval throughout the source box. Thus a corner row sees one source square, a side row two, and the central row four. Its actual source demands are respectively 14,28,56.

For r=14, e=390/79 and epsilon=1024e=399360/79. Set lambda_j=e/(m_j−4). Each four-row saturated source block has load lambda_corner+2lambda_side+lambda_center=1. The old interval incidence has at most two consecutive indices per coordinate; all old positive-area cell loads are subsets of one such 2 by 2 block. Hence the old packing inequality holds globally and is saturated source-a.e. The exact moment relation

    mu(A_j)=m_j=4+epsilon(1/1024)/lambda_j

is a supporting-gradient entropy KKT witness. Strict concavity with all old v_j>0 establishes the actual unique old lambda. No freely assigned new m or atomic source is used. Independently checked exact values are

    Q=914/79, V=9/1024, M=56,
    R=711/935936, kappa=1755/457,
    sum_j lambda_j m_j=M=Q+epsilon V, sum_j m_j=4M.

These are the correct Q=4 sum lambda values. The report's withdrawn draft Q=sum lambda m=M is not used in this audit or its accepted conclusions.

## 2. Why the rational geometry script certifies ALL anchor tuples

I inspected `r14_ac_certificate.py` before rerunning it. It has no CVXPY dependency and uses `math.isqrt` and exact `Fraction` arithmetic. For each true radius t=sqrt(m/4), it obtains consecutive rational bounds with denominator 10^32 and explicitly asserts lo^2<=m/4<hi^2. Every subsequent interval operation is outward by exact endpoint arithmetic.

The actual center identity is c=y+(t−1)(y−X)/2. A nonzero row coordinate uses its real inward source interval. A zero coordinate is enclosed by [−1,1], the convex hull of both disconnected possible source intervals. This is conservative: it includes every actual tag and every continuous allowed anchor. The proof does not assume independence of coordinate hull choices or freeze a representative anchor. Dependency loss from interval multiplication only enlarges the enclosure.

For two row-center coordinate intervals [l_i,u_i] and [l_j,u_j], the script's lower distance is max(0,l_i−u_j,l_j−u_i), and its upper distance is max(|l_i−u_j|,|u_i−l_j|). These are valid uniform bounds. Subtracting radius upper bounds from a distance lower bound gives a safe separation certificate.

### Receiver separation and forced owners

Every one of the 36 distinct B' pairs has a certified separating coordinate. The minimum rational separation is

    2443423255390501616235538400055243 /
    2560000000000000000000000000000000 > 0

(about 0.9544622091). Therefore all receivers are pairwise disjoint for the entire anchor support. Because each old I is the full old receiver, its affine image E_j is exactly B'_j, so there is no fill and no lost copy. Every actual image owner is forced to its own row. Own-source capture follows from A_j subset C_j under the real half action; there are no other incoming images at its points. Hence all nine rows have genuine positive baseline/free ownership, with

    p_j=|B'_j|=t_j^2/1024=m_j/4096, O=F=0.

No zero-measure old source endpoint affects these volume conclusions. No secondary-selector ambiguity remains in the forced owner allocations.

### Complete max-four packing and the four positive-area block cells

Every pair of old row indices with opposite nonzero signs in at least one coordinate has a certified separating coordinate for its NEW C cubes. There are 16 such pairs. The minimum C separation is

    951308239040080580869748800672341 /
    3200000000000000000000000000000000 > 0

(about 0.2972838247). Thus a common-new-C-point family cannot contain both signs in either coordinate. It is contained in one of the four 2 by 2 sign blocks and has at most four labels. This accounts for all possible common-point sets, not merely the ones seen by floating midpoint enumeration.

Conversely, for each of those four blocks, the script bounds the common intersection width in a coordinate from below by min_{i,j}(t_i,lo+t_j,lo−dist_upper(i,j)). For actual intervals this bounds every upper endpoint minus every lower endpoint, so it bounds their intersection length. Both coordinate lower bounds are strictly positive; their minimum is

    839327224625361956403241279838147679 /
    655360000000000000000000000000000000 > 0

(about 1.2807117075). The product rectangle therefore has positive area for every allowed anchor tuple. Another row cannot cover a point there, because it would be incompatible with a member of the full four-row block. Thus these are actual positive-area four-row membership cells.

The separation and intersection arguments together prove that the full a.e. new packing polytope is exactly the four block inequalities sum_{j in block}alpha_j<=1 with alpha>=0. No nine-row simplex is used. There are no extra maximal common-point constraints hidden by the finite cell topology.

## 3. Actual entropy KKT and exact Gamma, without CVXPY tolerances

All p_j=m_j/4096 are forced. At alpha_j=1/4, each of the four block constraints is tight and each actual entropy gradient is

    m_j+epsilon p_j/alpha_j=m_j(1+e).

Place dual multiplier 14(1+e)>0 on each of the four positive-area block constraints. A corner, side or central row belongs to one, two or four blocks respectively, so the sum of its dual multipliers is exactly m_j(1+e). Primal feasibility, dual nonnegativity, stationarity and complementary slackness are exact. The objective sum m_j alpha_j+epsilon sum p_j log alpha_j is strictly concave, hence alpha=1/4 is its unique actual optimizer. With forced owners it is also the actual joint capture-owner program solution, including delta=.01. There is no optimization at a trial fixed p that is later changed.

It follows pointwise on the whole anchor support that

    Q'=sum_j m_j/4=56=M, S=0.

For each actual old anchor X_k, exactly four OLD A_j contain it. Since sum a_k=M and sum m_j=4M,

    sum_j [sum_k a_k 1_Aj(X_k)−m_j]=4M−4M=0.

The actual alpha is the proved constant 1/4, so the correlation remainder is ZERO FOR EACH tuple, not just on average:

    sum_j alpha_j [sum_k a_k 1_Aj(X_k)−m_j]=0,
    Gamma=0 under the complete independent AC Euler law.

Pulling alpha out of this expression is legitimate here because its tuplewise value has been proved; it is not a general independence argument. All nine old a_k and anchors are retained. The full ledger independently gives

    W=7/128, O=F=RS=0,
    D=E_old=W−RQ'=1421/116992.

Thus this fixture has positive old growth but no lost-copy pressure at this r and width. It verifies a genuine zero-correlation boundary case and correct actual packing/KKT bookkeeping. It does not establish a generally favorable Gamma sign or the missing physical multiplicity payment.

## 4. Floating 64+64 atomic records: accepted only as exploration

I inspected `tensor_gamma.py`, `independent_kkt.py`, their JSONs and the report. I did not execute either numerical optimizer script. Each full atomic JSON contains precisely 64 distinct indices, all primary statuses `optimal` and all secondary statuses `optimal`. The recorded maxima reconstructed from those JSONs are:

| Recorded quantity | r64 | r14 |
|---|---:|---:|
| packing residual | 0 | 0 |
| owner residual | 1.8730851e−13 | 1.8178558e−13 |
| minimum-price residual | 0 | 0 |
| alpha stationarity residual, scaled objective | 1.0636852e−5 | 1.8683834e−6 |
| secondary residual | 1.8732932e−13 | 1.8178558e−13 |

These thresholds were chosen AFTER execution, as the author explicitly reports. I do not treat them as frozen acceptance tolerances, exact topology tests, or mathematical sign bounds. The arrangement code discards cell widths below 1e−12, uses floating square roots and relaxed containment comparisons, and accepts solver statuses including `optimal_inaccurate` in its code path. Although the retained outputs all say `optimal`, that status is not a proof.

The stored raw Clarabel r64 mean Gamma is 0.4545338834688852; raw per-tag extrema are approximately −1.3930754665 and 2.3023670823. The separate scalar simplex-KKT check improves the numerical mean to 0.4545460749676106 with gradient residual 9.0949471e−13. Its alpha differs from the raw output by up to 7.1757053e−6. This scalar solve uses floating Brent arithmetic and stored singleton-eligibility/simplex data. It checks those recorded fields; it does not independently recertify the underlying arrangement with exact geometry. Its refined numbers are useful diagnostics, not rigorous enclosures.

For r14 the stored raw mean Gamma is 9.4562379e−14 and its tiny per-tag signs are numerical noise; the closed-form alpha differs from Clarabel by as much as 1.4645667e−5. The separate floating reconstruction residual is 9.0949471e−13. The later exact positive-width proof above, rather than those small floating residuals, is what establishes Gamma=S=0. Same-tuple floating D residuals are zero for r64 and at most 3.4694470e−18 for r14; these check implementation consistency, not general inequalities.

`r14_scs.json` has four rows, indices [0,5,31,63], all reported `optimal`. It is a limited floating cross-check. The reported r64 SCS `optimal_inaccurate`/secondary failure generated an empty `r64_scs.json` (zero bytes), so it supplies NO valid result. I did not independently replay that failure or infer any sign from it. Neither successful SCS status nor failed cross-check changes the rigorous scope.

The r64 mean is positive despite some negative atomic tags. No negative-tag event is promoted to a negative complete expectation. None of these r64 calculations constructs an AC source expectation or enters the critical old kappa class. At r14 the 64-tag floating geometry did not itself certify positive width; the separate full-support rational certificate supplies that missing finite-model step.

## 5. Actual independent rerun and postcheck

The sole author computation rerun was

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python \
      /tmp/ccu_r654/numeric/r14_ac_certificate.py

It ran under Python 3.12.14, exited zero, emitted no stderr, and its stdout was compared IN MEMORY byte-for-byte with the existing `r14_ac_certificate.json`. They were identical. No source or numeric output file was overwritten. I additionally parsed its exact fractions, checked all 36 receiver gaps, all 16 incompatible-C gaps and all eight block coordinate bounds were positive, and independently recomputed the old constants, source mass, four saturated old loads, new dual-gradient identities, Q'=M, W and exact D above using Fraction. This exact postcheck supplements the analytic argument; it does not run CVXPY.

The script itself certifies its interval geometry, while old-source membership/KKT and the actual entropy/ Gamma consequences are supplied by the independent mathematical derivations above. Its JSON scope line correctly says the old source/KKT hypotheses come from the frozen old state. Do not describe the script alone as mechanically checking every line of the full KKT/Gamma proof.

Actual verification summary returned:

    REPLAY PASS exact bytes; Python 3.12.14; exit 0; stderr bytes 0
    COUNTS 36 receiver pairs, 16 incompatible pairs, 4 blocks
    e Q V M R kappa W D =
    390/79, 914/79, 9/1024, 56, 711/935936, 1755/457,
    7/128, 1421/116992

## 6. Final artifact binding

All hashes below were actually recomputed during this audit; these identify the inspected files. The first two are the rigorously replayed pair. The other solver artifacts were inspected/aggregated, not rerun.

| Artifact under `/tmp/ccu_r654/` | SHA-256 |
|---|---|
| numeric/r14_ac_certificate.py | e4f2a159a4499cce4312da9f073eec000e4649f5cbbeba0a8b96168828d70050 |
| numeric/r14_ac_certificate.json | 3af940f4cda75a9aa61d89a9b1fde7ae443c118b2f664131adc343eec848ae67 |
| numeric/tensor_gamma.py | 5de2a1a48cc7e0b68ba2c420aa7cb7dfd06111a089f831d3b8fdad191219b430 |
| numeric/independent_kkt.py | 6ff0b9cb05dd77e4098f8cb9b5bbbfc58525b311a1bac06a8e1fcfba66569bf7 |
| numeric/r64_all.json | ef0b5af76bac100ac3389701349b19a06250da98c884d6b45df17272dd15cb7b |
| numeric/r14_all.json | f6a62345158c0b86b468f5975a2b205588032df7c3c363689b7627906d52777e |
| numeric/independent_kkt.json | df2db187e32994e6121d703a2d4466abb288d7ba89cc7394d92a10e0f0a1eb38 |
| numeric/r14_scs.json | 80f51b6ac784f9027b2161feb277527a44c8591f9ecc7ea523f49512738d39b8 |
| COMPUTE_REPORT.md | 08db3edd202bb354a8c6d2271a0db93ef17881bed76ea42de7fb32d59e02b74c |

## Stop

The fixed positive-width r14 conclusion passes this independent audit. A general Gamma>=0 statement, a useful joint Gamma/lost-copy lower bound, a near-score construction, restoration to the original arbitrary-L1 weak constant, and the root-order theorem remain outside the accepted evidence. No further scan or solver run was undertaken.


## Supplemental calibrated-domain correction

The strict finite-model proof itself gives a further exact scope limitation. Since p_j=m_j/4096 and alpha_j=1/4,

    u'_j=epsilon p_j/(alpha_j m_j)=epsilon/1024=e=390/79,
    kappa'=epsilon W/Q'=390/79>4.

Thus the genuine r14 AC fixture does not satisfy the successor restriction kappa'<=4 of the calibrated successor-closed class, even though its OLD kappa=1755/457 lies between 7/2 and 4. Its S=Gamma=0, packing and actual-entropy conclusions remain exact; they do not validate any conditional good-alpha repair bound that assumes epsilon W<=4Q', a full same-class score theorem, or a near-score reduction. In particular the 36 epsilon M/a^n conditional fee uses that successor cap and is not certified by this fixture. The bad-alpha physical price uses its separately stated old-parameter/domain assumptions and is proved analytically rather than by this out-of-class example. The r64 atomic family is also outside the calibrated domain.

COMPUTE_REPORT's execution owner added the calibrated-domain correction. Its final amended SHA-256 is bound in section 6. An independent exact Fraction check here gives epsilon/1024=epsilon(7/128)/56=390/79>4; no solver or new geometry run is involved.
