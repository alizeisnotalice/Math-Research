"""R654 integrity and bounded reproduction; does not certify a general bound."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--replay', action='store_true')
args = parser.parse_args()
manifest = json.loads((root / 'MANIFEST.json').read_text())
names = {p.relative_to(root).as_posix() for p in root.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
assert names == set(manifest) | {'MANIFEST.json'}, 'Unexpected/missing file'
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
tex = (root / 'REPORT.tex').read_text()
labels = re.findall(r'\\label\{([^}]+)\}', tex)
assert len(labels) == len(set(labels)), 'Duplicate TeX label'
assert set(re.findall(r'\\(?:ref|eqref)\{([^}]+)\}', tex)) <= set(labels)
assert not [c for c in tex if ord(c) < 32 and c not in '\n\t']
for name in ['FINAL_GEOMETRY_AUDIT.md', 'FINAL_LEDGER_AUDIT.md']:
    audit = (root / name).read_text()
    assert manifest['REPORT.tex'] in audit, name
    assert manifest['NEXT_TARGET.md'] in audit, name
for name in ['r14_ac_certificate.py', 'r14_ac_certificate.json']:
    assert manifest['numeric/' + name] in (root / 'NUMERIC_AUDIT.md').read_text()
result = {'manifest_files': len(manifest), 'latex_labels': len(labels),
          'tex_compiled': False, 'replay': []}
if args.replay:
    env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    with tempfile.TemporaryDirectory(prefix='r654-replay-') as tmp:
        scratch = Path(tmp)
        shutil.copytree(root / 'numeric', scratch / 'numeric')
        def run(name):
            cp = subprocess.run([sys.executable, str(scratch / 'numeric' / name)],
                                env=env, cwd=scratch, capture_output=True,
                                check=True, timeout=120)
            assert not cp.stderr, (name, cp.stderr.decode())
            return cp.stdout
        exact = run('r14_ac_certificate.py')
        assert exact == (root / 'numeric/r14_ac_certificate.json').read_bytes()
        result['replay'].append('r14 positive-width rational geometry: byte-identical JSON')
        fresh = json.loads(run('independent_kkt.py'))
        old = json.loads((root / 'numeric/independent_kkt.json').read_text())
        for r in ['14', '64']:
            assert len(fresh[r]['rows']) == 64
            assert fresh[r]['max_kkt_grad_residual'] < 1e-8
            for a, b in zip(fresh[r]['rows'], old[r]['rows']):
                assert a['index'] == b['index']
                assert abs(a['gamma'] - b['gamma']) < 1e-8
                assert abs(a['S'] - b['S']) < 1e-8
        result['replay'].append('128 archived atomic cases: independent KKT numerical reproduction')
print(json.dumps(result, indent=2))
