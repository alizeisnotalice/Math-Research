import math,itertools,json
from fractions import Fraction as F
w=F(1,65536); d=F(127,64); N=10**32; rows=list(itertools.product((-1,0,1),repeat=2))
def root_bounds(a):
 t=math.isqrt((a.numerator*N*N)//a.denominator); lo=F(t,N); hi=F(t+1,N); assert lo*lo<=a<hi*hi; return lo,hi
def mul(a,b):
 z=[x*y for x in a for y in b]; return min(z),max(z)
def sub(a,b): return a[0]-b[1],a[1]-b[0]
def add(a,b): return a[0]+b[0],a[1]+b[1]
def anchor(v):
 if v==-1: return (-F(1),-F(1)+w)
 if v==1: return (F(1)-w,F(1))
 return (-F(1),F(1)) # conservative hull of both allowed components
T=[]; C=[]
for row in rows:
 m=14*2**sum(v==0 for v in row); tr=root_bounds(F(m,4)); br=((tr[0]-1)/2,(tr[1]-1)/2); T.append(tr); C.append([add((d*v,d*v),mul(br,sub((d*v,d*v),anchor(v)))) for v in row])
def dist_lower(i,j,k):
 a,b=C[i][k],C[j][k];return max(F(0),a[0]-b[1],b[0]-a[1])
def dist_upper(i,j,k):
 a,b=C[i][k],C[j][k];return max(abs(a[0]-b[1]),abs(a[1]-b[0]))
recv=[]; incompat=[]
for i,j in itertools.combinations(range(9),2):
 vals=[dist_lower(i,j,k)-(T[i][1]+T[j][1])/64 for k in range(2)]; k=max(range(2),key=lambda x:vals[x]); recv.append({'rows':[i,j],'axis':k,'lower':str(vals[k])})
 # Distinct old labels are compatible iff each coordinate does not use opposite signs.
 if any(rows[i][k]*rows[j][k]==-1 for k in range(2)):
  vals=[dist_lower(i,j,k)-T[i][1]-T[j][1] for k in range(2)]; k=max(range(2),key=lambda x:vals[x]); incompat.append({'rows':[i,j],'axis':k,'lower':str(vals[k])})
cliques=[]
for sx,sy in itertools.product((-1,1),repeat=2):
 I=[i for i,r in enumerate(rows) if all(r[k] in (0,(sx,sy)[k]) for k in range(2))]; assert len(I)==4
 widths=[min(T[i][0]+T[j][0]-dist_upper(i,j,k) for i in I for j in I) for k in range(2)]
 cliques.append({'sign':[sx,sy],'rows':I,'coordinate_width_lower':[str(x) for x in widths]})
rv=min(F(x['lower']) for x in recv); iv=min(F(x['lower']) for x in incompat); cv=min(F(v) for x in cliques for v in x['coordinate_width_lower']);
out={'width':str(w),'r':14,'rational_root_denominator':str(N),'rows':rows,'receiver_pair_separation':recv,'incompatible_pair_separation':incompat,'cliques':cliques,'min_receiver_gap':str(rv),'min_incompatible_C_gap':str(iv),'min_clique_intersection_width':str(cv),'all_receiver_separated':rv>0,'all_incompatible_C_separated':iv>0,'all_four_cliques_positive':cv>0,'scope':'conservative source anchor coordinate hull; rectangle interior geometry; source membership and KKT hypotheses from frozen old state'}
print(json.dumps(out,indent=2)); assert rv>0 and iv>0 and cv>0
