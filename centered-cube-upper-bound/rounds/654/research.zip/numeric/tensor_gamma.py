import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
import sys, json, time, itertools, math
import numpy as np, cvxpy as cp
from fractions import Fraction as F
from collections import defaultdict
D=F(127,64); signs=(-1,0,1); ys=list(itertools.product(signs,repeat=2)); tags=list(itertools.product((-1,1),repeat=2))
def old(r):
 e=1/(1/F(r-4)+2/F(2*r-4)+1/F(4*r-4)); lam=np.array([float(e/F(r*2**sum(z==0 for z in y)-4)) for y in ys]); m=np.array([r*2**sum(z==0 for z in y) for y in ys],float); a=lam*m; Q=sum(4*e/F(r*2**sum(z==0 for z in y)-4) for y in ys); V=F(9,1024); M=F(4*r); eps=1024*e; R=V/Q; return e,lam,m,a,Q,V,M,eps,R
def assignments():
 opts=[[tag for tag in tags if all(y[i]==0 or y[i]==tag[i] for i in range(2))] for y in ys]
 return list(itertools.product(*opts))
def cells(rects):
 xx=sorted(set(v for rec in rects for v in (rec[0],rec[1]))); yy=sorted(set(v for rec in rects for v in (rec[2],rec[3]))); out=defaultdict(float)
 for l,h in zip(xx,xx[1:]):
  for b,t in zip(yy,yy[1:]):
   if h-l<1e-12 or t-b<1e-12: continue
   x=(l+h)/2; y=(b+t)/2; mask=tuple(i for i,(a,c,d,e) in enumerate(rects) if a<x<c and d<y<e)
   if mask: out[mask]+=(h-l)*(t-b)
 return out
def run(r,idx):
 e,lam,m,a,Q,V,M,eps,R=old(r); tag=assignments()[idx]; y=np.array(ys,float)*float(D); X=np.array(tag,float); t=np.sqrt(m/4); b=(t-1)/2; c=(1+b[:,None])*y-b[:,None]*X
 rect=lambda radii:[(c[i,0]-radii[i],c[i,0]+radii[i],c[i,1]-radii[i],c[i,1]+radii[i]) for i in range(9)]
 images=cells(rect(t/64)); packing=cells(rect(t)); maximal=[v for v in packing if not any(set(v)<set(w) for w in packing)];
 # C_i contains old A_k iff coordinate max abs(center-oldcenter)+1<= radius
 margins=t[:,None]-1-np.max(np.abs(c[:,None,:]-y[None,:,:]),axis=2)
 eligible=defaultdict(float)
 for incoming,area in images.items():
  allow=tuple(i for i in incoming if all(margins[i,j]>=-1e-11 for j in incoming))
  if not allow: raise RuntimeError(('no capture owner',idx,incoming))
  eligible[allow]+=area
 avail=sorted(set(i for row in eligible for i in row)); position={j:i for i,j in enumerate(avail)}; p0=np.zeros(len(avail)); edges=[]
 for eligible_set,area in eligible.items():
  for j in eligible_set: p0[position[j]]+=area/len(eligible_set); edges.append((eligible_set,j,area))
 z=cp.Variable(len(edges),nonneg=True); alpha=cp.Variable(len(avail),nonneg=True); cons=[]; q=[]
 for eligible_set,area in eligible.items(): cons.append(cp.sum([z[l] for l,(es,j,ar) in enumerate(edges) if es==eligible_set])==area)
 for j in avail: q.append(cp.sum([z[l] for l,(es,i,ar) in enumerate(edges) if i==j]))
 q=cp.hstack(q); p=.01*p0+.99*q
 for cell in maximal:
  inds=[position[j] for j in cell if j in position]
  if inds: cons.append(cp.sum(alpha[inds])<=1)
 prob=cp.Problem(cp.Minimize(cp.sum(cp.rel_entr(p,cp.multiply(m[avail],alpha)))-m[avail]@alpha/float(eps)),cons)
 st=time.monotonic(); prob.solve(**({'solver':'SCS','eps_abs':1e-9,'eps_rel':1e-9,'max_iters':100000} if os.getenv('CROSS_SCS') else {'solver':'CLARABEL','tol_gap_abs':1e-10,'tol_gap_rel':1e-10,'tol_feas':1e-10,'max_iter':300})); runtime=time.monotonic()-st
 if prob.status not in ('optimal','optimal_inaccurate'): raise RuntimeError((idx,prob.status))
 av=np.asarray(alpha.value); pv=np.asarray(p.value); qv=np.asarray(q.value); zv=np.asarray(z.value).copy(); aa=np.zeros(9); aa[avail]=av
 # KKT alpha stationarity using the packing-constraint multipliers.
 pc=cons[len(eligible):]; dualgrad=np.zeros(len(avail)); activecells=[cell for cell in maximal if any(j in position for j in cell)]
 for cell,con in zip(activecells,pc):
  for j in cell:
   if j in position: dualgrad[position[j]]+=float(con.dual_value)
 stationarity=float(np.max(np.abs(-pv/av-m[avail]/float(eps)+dualgrad)))
 # Fix the primary unique p and alpha; select the least-squared-norm atom allocations.
 zz=cp.Variable(len(edges),nonneg=True); sc=[]
 for es0,area in eligible.items(): sc.append(cp.sum([zz[l] for l,(es,j,ar) in enumerate(edges) if es==es0])==area)
 for j in avail: sc.append(cp.sum([zz[l] for l,(es,i,ar) in enumerate(edges) if i==j])==qv[position[j]])
 secondary=cp.Problem(cp.Minimize(cp.sum_squares(zz)),sc); secondary.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_feas=1e-10,tol_gap_rel=1e-10,max_iter=300)
 if secondary.status not in ('optimal','optimal_inaccurate'): raise RuntimeError(('secondary',idx,secondary.status))
 zv=np.asarray(zz.value); secondary_res=max(max(abs(sum(zv[l] for l,(es,j,ar) in enumerate(edges) if es==es0)-area) for es0,area in eligible.items()),max(abs(sum(zv[l] for l,(es,i,ar) in enumerate(edges) if i==j)-qv[position[j]]) for j in avail))
 brackets=np.array([sum(a[k] for k in range(9) if all(abs(X[k,d]-y[j,d])<=1+1e-12 for d in range(2)))-m[j] for j in range(9)])
 W=sum(images.values()); Qp=float(m@aa); S=float(M)-Qp; ell=float(sum((t/32)**2)); E=ell-float(R*M); O=ell-W; DD=E-O+float(R)*S; G=float(aa@brackets)
 # support minimum-price residual, primal feasibility
 prices=pv/(m[avail]*av); priceerr=max([max(0.,prices[position[j]]-min(prices[position[k]] for k in es)) for l,(es,j,ar) in enumerate(edges) if zv[l]>1e-7] or [0]); packerr=max([sum(aa[j] for j in cell)-1 for cell in maximal]+[0]); ownererr=max(abs(sum(zv[l] for l,(es,j,ar) in enumerate(edges) if es==es0)-area) for es0,area in eligible.items()); grads=m[avail]+float(eps)*pv/av
 return dict(index=idx,tags=tag,status=prob.status,time=runtime,alpha=aa.tolist(),p={str(j):float(pv[position[j]]) for j in avail},q={str(j):float(qv[position[j]]) for j in avail},available=avail,packing_maximal=[list(x) for x in maximal],origin_margin=float(min(t-np.max(abs(c),axis=1))),min_nonzero_capture_margin=float(min(abs(x) for x in margins.flatten() if abs(x)>1e-10)),Gamma=G,brackets=brackets.tolist(),Qprime=Qp,S=S,W=W,E=E,O=O,F=0.,RS=float(R)*S,D=DD,tagged_slack=S-G,packing_residual=packerr,owner_residual=float(ownererr),price_residual=float(priceerr),entropy_gradients=grads.tolist(),alpha_stationarity_residual=stationarity,secondary_status=secondary.status,secondary_residual=float(secondary_res),atom_allocations=[{'eligible':list(es),'owner':j,'area':area,'q':float(zv[l])} for l,(es,j,area) in enumerate(edges)],objective=prob.value)
if __name__=='__main__':
 r=int(sys.argv[1]); indices=list(map(int,sys.argv[2:])) or list(range(64)); t0=time.monotonic(); rows=[run(r,i) for i in indices]; e,lam,m,a,Q,V,M,eps,R=old(r); output=dict(r=r,indices=indices,elapsed=time.monotonic()-t0,e=str(e),epsilon=str(eps),Q=str(Q),V=str(V),R=str(R),kappa=str(eps*R),M=str(M),gamma_mean=sum(x['Gamma'] for x in rows)/len(rows),S_mean=sum(x['S'] for x in rows)/len(rows),D_mean=sum(x['D'] for x in rows)/len(rows),rows=rows); print(json.dumps(output,indent=2))
