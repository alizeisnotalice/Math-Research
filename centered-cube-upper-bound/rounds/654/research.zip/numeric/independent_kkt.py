import json, pathlib, math
import numpy as np
from scipy.optimize import brentq
from fractions import Fraction
from tensor_gamma import old, ys
root=pathlib.Path(__file__).parent
results={}
for r in (64,14):
 data=json.loads((root/f'r{r}_all.json').read_text()); e,lam,m,a,Q,V,M,eps,R=old(r); rows=[]
 for row in data['rows']:
  assert all(len(x['eligible'])==1 for x in row['atom_allocations'])
  pp=np.zeros(9)
  for x in row['atom_allocations']: pp[x['owner']]+=x['area']
  avail=[i for i in range(9) if pp[i]>1e-12]; al=np.zeros(9)
  if r==64:
   assert row['origin_margin']>0 and len(row['packing_maximal'])==1 and len(row['packing_maximal'][0])==9
   nu=brentq(lambda v:sum(float(eps)*pp[j]/(v-m[j]) for j in avail)-1, max(m[avail])+1e-9,10000,xtol=1e-12)
   al[avail]=[float(eps)*pp[j]/(nu-m[j]) for j in avail]
   residual=max(abs(m[j]+float(eps)*pp[j]/al[j]-nu) for j in avail)
  else:
   al[:]=1/4
   targets={frozenset([0,1,3,4]),frozenset([1,2,4,5]),frozenset([3,4,6,7]),frozenset([4,5,7,8])}
   assert set(map(frozenset,row['packing_maximal']))==targets
   assert np.max(abs(pp-m/4096))<1e-12
   dual=14*(1+float(e)); residual=max(abs(m[j]+float(eps)*pp[j]/al[j]-dual*sum(j in z for z in targets)) for j in avail)
  g=float(al@np.array(row['brackets'])); rows.append(dict(index=row['index'],gamma=g,alpha_max_diff=float(np.max(abs(al-np.array(row['alpha'])))),kkt_grad_residual=residual,S=float(M)-float(m@al)))
 results[str(r)]=dict(gamma_mean=sum(x['gamma'] for x in rows)/64,S_mean=sum(x['S'] for x in rows)/64,alpha_max_diff=max(x['alpha_max_diff'] for x in rows),max_kkt_grad_residual=max(x['kkt_grad_residual'] for x in rows),rows=rows)
print(json.dumps(results,indent=2))
