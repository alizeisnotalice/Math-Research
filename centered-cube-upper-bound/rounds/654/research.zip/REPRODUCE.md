# R654 reproduction and scope

The general centered-cube root-order weak bound remains unproved. The report separates a legal source-selection theorem, actual paid portions of the correlation account, conditional repair fees, and the complete still-unpaid physical budget. Two final independent reviews bind the exact report and next-target hashes. No PDF is compiled.

After unpacking, run:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py --replay
```

The first checks the exact manifest/file set, hashes, TeX labels and audit bindings. Integrity checks do not establish mathematical correctness. The replay uses a temporary copy: the positive-width rational geometry certificate must reproduce its JSON byte-for-byte; the independent KKT script recomputes all 128 archived atomic cases. Its 1e-8 comparisons are reproduction tolerances, not rigorous error bounds or a posteriori proof of the original convex solver's optimality.

The strict r=14 positive-width certificate uses Python integer square roots and Fraction arithmetic at w=1/65536. Its proof of receiver separation, packing incidence and positive intersection margins is independently audited in NUMERIC_AUDIT.md. Actual source KKT and the four-cell dual prove alpha=1/4 and S=Gamma=0 for the entire continuous anchor support. This is a finite low-R model, not a near-score state. Although its old kappa lies in the critical interval, its actual successor kappa'=390/79 exceeds 4, so it also lacks the full successor-calibrated hypothesis; it cannot test a theorem requiring that hypothesis.

The floating exploration is separately reproducible with the same interpreter:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python numeric/tensor_gamma.py 64 > /tmp/r654-r64-exploration.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python numeric/tensor_gamma.py 14 > /tmp/r654-r14-exploration.json
```

Here `python` denotes the absolute interpreter above. The files include elapsed times and floating results, so repeated full outputs need not be byte-identical. To test independent_kkt.py on regenerated rather than archived geometry records, copy numeric/ to a scratch folder and replace only its r64_all.json and r14_all.json there before running it. Do not overwrite the archived evidence.

Recorded runtime: Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1, CVXPY 1.9.3 and Clarabel 0.11.1. The full exploration used all 64 tag tuples at each of the two prescribed parameters. COMPUTE_REPORT.md discloses the corrected initial Q error, retrospective floating acceptance tolerances, Clarabel/KKT differences, and failed r=64 SCS cross-check. No result from that failed cross-check is used. The r=64 mean is a width-zero numerical result, not a positive-width theorem; negative individual tags do not determine its full mean. No MATLAB job was run this round.

The archive includes only final numeric inputs/code/results needed for the report and the independent scalar check. Cost probes, cache directories, the empty failed SCS output, intermediate algebra notes and unsuccessful API requests are excluded. The source tools' analytic proofs in REPORT.tex carry the general parameter claims; finite calculations never stand in for the missing global estimate.
