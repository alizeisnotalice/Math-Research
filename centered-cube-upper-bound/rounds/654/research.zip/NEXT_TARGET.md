# Next target: actual good-alpha/availability and the complete gain

The general centered-cube n^(1/2+o(1)) weak (1,1) bound remains UNPROVED. Continue the same full-owner surrogate class, a=32n, the same fixed calibrated epsilon, actual old entropy lambda/AC KKT source, independent Euler anchors, and the R652 fixed-delta=.01 actual joint capture/minimum-price owner policy. All old/deleted incoming rows remain sampled and charged. The optimizer, eligibility, positive baseline and availability must be recomputed from each entire anchor tuple. No fixed-alpha reassignment is allowed.

The complete target is E D>=cV-C L M, L=C0 sqrt(n) polylog(n), with constants uniform in label count and scale range. Exactly

    D=E_growth-O+F+RS=W-RQ'=W-(1+kappa)V+RS.

Equivalently pay E[O-F-RS] against the SAME old growth and one CLM account. A new representation or a bound on a positive outer term is not that payment. The single global successor potential costs at most 4LM; no source allowance can be renewed per point, row, layer, band, path, threshold or comparison configuration.

## Lawful source freedom now available on the entire geometry class

For every required near-score geometry/owner/row datum, retain all geometry and I and choose the old AC source BEFORE sampling. The full coordinate arrangement, actual cell-mass LP and rectangular minimum sets supply mixtures of uniform inner boxes with

    H(mu_theta)<=Phi+theta kappa M.

Selecting an eta/2-near-score state and theta<=min(1/2,eta/(2 kappa L)) gives an eta-near-score source in this product-within-cell subclass. This is equality of score suprema on the full old geometry class, not a special-input assumption. Coordinates factor only conditional on a source-cell tag, and the row law is a mixture of products. Widths may collapse as eta→0; no uniform density, normalized positive width, common contact coordinate or anti-concentration scale is available. Collision/owner conditioning need not preserve coordinate independence.

The exact full-receiver marginals q_j(x) are the mixture, OUTSIDE the coordinate product, of coordinate-window intersection probabilities. Independent ROWS give E W=int[1-prod_all_old_j(1-q_j(x))]dx. It remains to couple that union to the SAME adaptive f_Z=sum alpha_j(Z)1_Aj and S=int(1-f_Z)dmu. The complete equivalent joint target is

    int[1-prod_j(1-q_j)] + R int E[1-f_Z]dmu
       >=(1+kappa+c)V-C L M.

The receiver kernel is not an image/lost-copy kernel for irregular I_j. Never replace the actual lost indicator by fullincoming or multiply unconditioned one-coordinate mixture marginals.

## High-only transport and the once-paid correction

With K drawn from all old rows with probability a_k/M, draw q uniformly from the real I_K independently of anchors and retain the actual loss ell_K=1_{actual recomputed owner at T_K(q,X_K) differs from K}. The tag's source marginal is mu/M and E O_high=(M/epsilon)E[u_K 1_H ell_K]. This keeps the physical u/epsilon and all layers/siblings.

Use the exact high-only ghost allocation

    E S=E sum_H a_k delta_Z(X_k)+Gamma_H+S_low^ghost,
    delta_Z=1-f_Z, S_low^ghost>=0,
    Gamma_H=(1/2)sum_H a_k E[(f_Z-f_Z^(k))(X_k)
                              -(f_Z-f_Z^(k))(Y_k)].

Both configurations use the true joint recomputation, with unavailable labels separately zeroed; old tags are not deleted. For G_k=(u_k-kappa)^2/(1+u_k)[1_H+(11/12)1_low], the full exact ledger is

    E D=(M/epsilon)E[G_K-u_K 1_H ell_K+kappa 1_H delta_Z(X_K)]
        +E F+E Delta_low+R Gamma_H+R S_low^ghost.

The low loss estimate and Delta_low>=0 need OLD kappa>=7/2. This ghost allocation retains all 11/12 low growth. The empirical low-covariance 7/12 absorption is an ALTERNATIVE ledger, not another credit.

The pair bad event is alpha_k(Z)>=1/4 OR alpha_k(Z^(k))>=1/4. Both configurations are already included in

    R|Gamma_H,bad|<=16 kappa M/a^n<=64M/a^n

on the calibrated old domain. This signed-correction expense may be paid once by CLM. The remaining good-alpha correlation must be studied jointly with the displayed actual physical loss/reserve and fill, not isolated as an automatically nonnegative covariance.

## Correctly signed availability: deleted mass HELPS full D

At fixed old R,mu,m and one full tuple Z, omit a high row k and recompute the actual minus joint program. It is a comparison configuration, not a new independently calibrated state or a fresh source budget. Let Qdel_k be the minus optimized source mass of old labels becoming unavailable on adding k; let B_ret,k=sum_common m_j[alpha_j(Z)-alpha_j^(-k)] be the signed optimized survivor rebound, and a'_k=m_k alpha_k(Z), zero if k is unavailable. Then exactly

    Q'(Z)-Q^(-k)=a'_k+B_ret,k-Qdel_k,
    D(Z)-mathscrD^(-k)=Delta W_k+R Qdel_k-R a'_k-R B_ret,k,
    mathscrD^(-k)=W^(-k)-R Q^(-k),
    0<=Delta W_k<=m_k/a^n.

The own-row high-tag cost is already at most 2kappa M/a^n. The unpaid question is the NET survivor rebound relative to the favorable deletion, coupled to actual coverage and the full old growth/loss/fill. Do not require an upper bound for Qdel merely because a separate B-value comparison charges Qdel/epsilon. Do not replace actual alpha in D by a comparison packing beta.

The empirical identities make the same cancellation explicit: T=int(1-f)dhatmu, C=int f(dhatmu-dmu), S=T+C. Removing alpha_j changes T+C by +alpha_j m_j, although its C part alone may be adverse. Changing an empirical probe produces opposite terms in T and C that cancel. Keep the matching tagged reserve when interpreting an availability term in Gamma. Any proposed proof must price the genuine retained-optimizer net rebound or the equivalent actual good-alpha/full-loss combination with a leading cV margin.

## What the local repair formulas do NOT establish

A one-anchor swap permits a target feasible volume vector with l1 difference <=4m_k/a^n. This is a fractional baseline/free feasibility statement, not stability of actual optimized p. Packing-only/fixed-original-p repairs cost at most 36epsilon M/a^n over both configurations (36M/a^n in the corresponding B part), conditional on their stated domains including epsilon W<=4Q'. They are not a complete joint repair or a Gamma_good estimate.

The actual adding-row B* upper bound now has a legal support floor and no explicit log N. For repaired comparison p+, define common q_j, removed s_j and added r_j. Positive recipients satisfy only m_j>=d_k=m_k/(1+u_k); the baseline prevents replacing this by m_j>=m_k. With alpha_ret removing newly unavailable labels and zeta_j=r_j/r, beta=(1-theta)alpha_ret+theta zeta is a legal comparison, including unavailable k. The resulting B* value bound retains Qdel/epsilon, the exact donor entropy Xi, and r[1+log((q+Qret/epsilon+r)/d_k)]. These are costs of that auxiliary stability argument. They neither establish a physical D obstruction nor price the actual surviving optimizer response. The perspective Hessian has a moving-(p,alpha) null direction, so fixed-p strong concavity and a vanishing secondary tie penalty do not fill the gap.

## Domain, restoration and numerical boundaries

The restoration audit confirmed the inherited full-class bridge C_n<=sup_N T_N(0)<=P C_n and C_n<=sup_N T_N(epsilon_N)<=5P C_n, P=(1+1/a)^n<2. The forward implication from a genuinely uniform calibrated surrogate bound to C_n has NO a^n multiplier. It starts from a finite receiver cover centered at the original bad-set points, not by shrinking an already chosen large-cube cover. The outstanding theorem is the uniform surrogate budget, not a missing dimensional repair of this bridge. Special geometry/source restrictions still need the full score approximation already described; no count/scale dependence is acceptable.

The strict n=2 r14,w=1/65536 tensor fixture proves whole-support actual packing, alpha=1/4, S=Gamma=0 and D=1421/116992. It has low R, no near-score certificate, AND actual successor kappa'=390/79>4, so it is outside a same-class calibrated successor-closed domain despite OLD kappa=1755/457 being critical-band. It cannot validate theorems requiring that successor cap. r64 is width-zero floating exploration, with positive complete mean Gamma about .454546 and some negative tags; no AC expectation or critical-state counterexample follows. Post-hoc solver thresholds, the failed r64 SCS run and the withdrawn initial Q=M normalization bug remain documented. No new unrelated fixture or scalar coefficient scan is the next proof task.

The next decisive result must bound the true good-alpha/availability net contribution and complete physical loss/coverage on the lawful full near-score class, or provide a fully priced whole-state recursion. If using the latter, retain E'=(1+kappa_next)E_next, every next O/F/S, actual whole-state mass weights, high-R/low-kappa intermediate states, and genuine terminal/summability costs. A low-kappa successor is not automatically terminal. Stop at an explicit unproved joint inequality if no proof is available; do not call another representation, source-selection interface or local repair fee a dimension improvement.
