# R654 numerical decision gate: the actual correlation remainder

The source-window author has now supplied the precise Gamma candidate below. This file freezes a genuine old entropy/KKT/AC-source tensor construction and two strictly separated execution stages. It replaces the previous undecidable common-point test; the old equal-mass four-cube model has Gamma identically zero and is retired. No tensor solver or new Gamma experiment was executed by this worker. The primary numerical question is the full stated sign or JOINT lower bound, with actual same-tuple owner/alpha recomputation; the complete physical O-F-RS/growth ledger remains the theorem target.

There are only two current designs: the tensor experiment, and a secondary restoration LP that remains gated by the independent restoration audit. Do not launch an unannounced r/width/geometry scan. The candidate author must still state its exact domain (unconditional, critical-kappa, near-source or genuinely near-score), constants, and every allowed resource before a finite sign is interpreted as a proof decision. In particular no near-score state is promised here.

## New decision quantity and exact R653 check

The source-window candidate now supplies an actual falsifiable quantity. Write

    Gamma = sum_j E[alpha_j(Z) (sum_k a_k 1_Aj(X_k) − m_j)],
    a_k=lambda_k m_k.

With all old anchor rows retained and the actual joint-program alpha extended by zero on unavailable new labels, its exact decomposition is

    E S = E sum_k a_k [1 − sum_j alpha_j(Z) 1_Aj(X_k)] + Gamma.

The inner old-cube load is at most one for each realized tuple because A_j subset C_j and actual new packing holds everywhere off the finite null-boundary strata. The question is whether Gamma is nonnegative, or admits a useful JOINT lower bound with the complete physical loss/growth ledger. It is not enough to replace its adaptive alpha by E alpha: alpha depends on all anchors. All weights a_k remain present, including deleted old inputs.

The R653 k=1 value Gamma=18/25 is independently confirmed analytically, without rerunning that fixture. On the central-right event a_L=28/5,a_C=24/5,a_R=28/5, alpha_L=0,alpha_C=7/10,alpha_R=3/10. The central old A contains every anchor, so its centered bracket is 16−16=0. The retained right old A contains X_R and X_C, giving its bracket 28/5+24/5−8=12/5. Thus the realized correlation sum is (3/10)(12/5)=18/25. Reflection gives the SAME number on the other half-event. These old-source membership facts and actual alpha hold throughout the positive-width support, so this is an exact full Euler expectation, not merely the atomic limit. It does not imply a general sign theorem.

The earlier four equal-mass common-source cube proposal has Gamma identically zero: every old A_j contains every X_k, sum a_k=M=m_j. They therefore cannot distinguish the new sign claim. **Do not execute that retired proposal for the Gamma decision.** The tensor protocol below is the primary experiment.

## Design 1, primary: actual 3 by 3 tensor geometry

This is the newly authorized frozen candidate, not permission to launch a parameter search. Keep n=2, a=64, d=127/64. The nine old cubes have y in {−d,0,d}^2, halfside one, and I_y=B_y=Q(y,1/64), volume 1/1024. All old I are genuinely disjoint. At each sign pair eta in {−1,+1}^2 put source mass r on the inward square

    K_eta(w)=J_eta1(w) times J_eta2(w),
    J_−(w)=[−1,−1+w], J_+(w)=[1−w,1], 0<w<1/64.

The actual source is uniform on each K_eta(w), with density r/w^2. Each corner old row contains exactly one source box and has m=r, each side row exactly two and has m=2r, and the central row all four and has m=4r. Define

    e=[1/(r−4)+2/(2r−4)+1/(4r−4)]^(−1),
    lambda_corner=e/(r−4), lambda_side=e/(2r−4),
    lambda_center=e/(4r−4), epsilon=1024 e.

These are positive for r>4. Every source cell has load lambda_corner+2lambda_side+lambda_center=1. The one-dimensional old interval incidence has at most two consecutive coordinates at a point; in the product, every maximal four-row load is one corner, two sides and the center. Consequently the old packing inequality holds on all positive-volume old cells, and source saturation holds AC-a.e. Moreover d_j=4 and 4+epsilon v_j/lambda_j=m_j. This is a genuine supporting-gradient entropy KKT certificate; strict concavity fixes the actual old lambda. The total actual source mass is 4r, not the sum of all nine overlapping row masses.

The actual Euler law is independent over all nine old labels. A corner anchor has its fixed source-box sign; each side row independently selects one of its two boxes with probability 1/2; the central row independently selects one of four with probability 1/4. Conditional on tags, anchors are uniform on their indicated positive-width boxes. Thus there are exactly 2^4 times 4 = 64 equally likely tag combinations, each of weight 1/64. This is a complete finite mixture; symmetry representatives may be used only with explicit orbit weights.

For each row use its actual t_y=sqrt(m_y/4), b_y=(t_y−1)/2, c_y=sigma_y y−b_y X_y and rho_y=t_y. Since I=B, images equal receivers E_y=B'_y, so F=0; lost OLD images, including unavailable rows, must still be counted. Do not infer capture eligibility from the old tensor incidence alone.

### Stage A: r=64, 64 zero-width tag combinations, exploration only

At r=64 the three expansion radii are t_corner=4, t_side=4sqrt(2), t_center=8. First set each anchor equal to its tagged corner point eta. This is an ATOMIC LIMIT used only to explore the sign; it is not an actual AC Euler action. No Gamma sign at this stage is a certificate for any positive w.

Every resulting C contains the origin strictly, so the new packing polytope is the simplex sum alpha<=1. This statement should be checked by the execution owner at all 64 tags; do not infer it for a different r. Nevertheless p,q,eligibility and alpha must be recomputed for EVERY full tuple: m differs between corner/side/center rows, so alpha is not generally p/W. Use the genuine capture-admissible image-priority joint convex program, delta=.01, its actual eligible baseline, free allocations q and the declared canonical secondary tie selector. The finite rectangular arrangement supplies exact image/eligibility atom areas. Deleted new rows have alpha=0, while all nine old a_k and X_k remain in the Gamma brackets. Do not fix an alpha and then reassign owners.

For a tag tuple tau let

    G_j(tau)=sum_k a_k 1_Aj(eta_tag(k,tau)) − m_j,
    gamma(tau)=sum_j alpha_j(tau) G_j(tau).

The complete atomic exploration value is (1/64)sum_tau gamma(tau). Record every tuple value, availability, packing regime, p,q,alpha, Q',S,O,F,E,D, plus primary/secondary optimality residuals. The exact old membership table is stable on the inward boxes for sufficiently small positive w; the NONTRIVIAL width issue is the adaptive new geometry/eligibility/optimizer, not replacing old a_k by new weights. An ownership-volume solver status alone does not establish a sign.

This stage is deliberately one r value, one fixed geometry, one finite 64-tag sum. Precompute unique incidence/symmetry classes and estimate cost before solving all 64 programs. Initially solve at most one representative from each of a SMALL identified class set, report the number and runtime estimate, and reuse exact symmetry only after verifying the full geometry/source/selector equivariance. If the same declared secondary selector breaks a proposed symmetry, retain the actual distinct tuples. No unannounced r sweep, width scan, random anchors or high-dimensional quadrature.

**Critical scope:** at r=64, every u_j is at least 15, so old kappa is at least 15 (approximately 22), outside the calibrated old band kappa<=4. R is also small. A negative Gamma here would refute an unconditional same-object sign assertion on this actual geometry AFTER positive-width certification; it cannot refute a sign theorem restricted to critical near-score states. A positive atomic value would only identify a promising local sign, not prove Gamma>=0 generally. Neither outcome pays lost-copy multiplicity by itself.

### Stage B, conditional contrast only: r=14 and actual packing

The proof author/root has identified r=14 as a critical-kappa contrast (kappa approximately 3.84) with low R. Do not treat this numerical approximation as a recorded certificate: calculate the exact rational Q,V,kappa from the displayed old data before use. At r=14 the expansion radii are sqrt(7/2),sqrt(7),sqrt(14). The C do NOT generally share a common point. The actual new packing incidence, on positive-volume membership cells, must be constructed for each tested full tuple; the Stage-A simplex reduction is invalid here.

Stage B is authorized only after Stage A's cost/sign report and a decision by the coordinator. Start with a few explicitly selected symmetry representatives (for example all side tags pointing toward the central tag, all pointing away, and a mixed cycle), with exact definitions and no claim of a complete expectation. Recompute the entire actual joint program and Gamma brackets there. If it becomes necessary to infer the mean, enumerate ALL 64 tags with verified orbit weights or certify all omitted contributions; representative signs alone cannot determine E Gamma.

This r=14 family may enter the old critical kappa interval, but it is still a low-R diagnostic. No near-score hard-state hypothesis is satisfied merely by matching kappa. If the candidate additionally assumes near-old-source optimality, compute the actual old H infimum and the AC source gap on its true saturated rectangles; do not assume that shrinking w toward the corner tags automatically approaches its minimum sets. No near-score state is promised by this parameter change.

### Positive-width certification and stopping criteria

After an exploration result actually distinguishes a stated candidate, choose ONE rational positive width and certify it. It must satisfy the old source-box constraints and every required new packing/capture incidence margin on the relevant full anchor supports. Zero-margin topological changes cannot be declared harmless: they need their own continuity/one-sided or direct box argument. Even if membership topology is stable, p and alpha vary with anchors; freeze neither one. For an expectation sign use exact/interval parameterized KKT bounds for the true joint program, sum all tag contributions with weights 1/64, and retain every unresolved anchor region with a rigorous remainder. Atomic-to-AC passage needs an actual proved continuity/uniform bound applicable to this joint optimizer; do not reuse an unproved global minset-limit theorem.

The main recorded decision quantity is Gamma together with the exact E S decomposition using the SAME actual alpha, all old a_k and full tuple law. If only a conditional tag event is certified, call it conditional. A negative complete Gamma may decide an unqualified sign claim, but a proposed joint lower bound must be tested against its complete E/O/F/RS/H resources, constants and domain. A positive result on this finite family is not a general covariance sign, near-score lemma, positive full D margin, or dimension improvement.

This addendum is an execution PROTOCOL only. No 64-tag solver, atomic Gamma sum, new numerical sign, positive-width test, r14 computation or API call has been executed by this worker. The only new R653 value given above is an independent exact analytic check of its already certified full-support two-branch data. Hand this protocol to the designated Terra executor; stop here rather than launch another model.


## Design 2, secondary only: finite actual-geometry LP for restoration scale factors

The independent main restoration audit has priority. Do not run this in parallel with its proof work unless it supplies a specific questionable power/factor or a finite inequality to test. This is not a substitute for that audit and not a second capacity campaign.

For a fixed finite rational cube geometry and a specified halfside shrink a, form the exact positive-volume cells. For each chosen small selected-cube set J, minimize the original nonnegative piecewise-constant input mass sum_T |T| f_T subject to the actual cube constraints sum_T |T intersect A_j| f_T >= |A_j|, j in J. The covered union |union_{j in J} B_j| is computed geometrically, not optimized as an additional linear variable. Its ratio to the LP minimum is then a finite witness/upper certificate for the precise claimed implication. A normalization sum |T| f_T=1 can instead be used as a feasibility test. If selection itself matters, enumerate the few fixed subsets explicitly; do not hide a selection integer program inside a continuous LP.

Those displayed average constraints certify the selected centered averages only at y_j. They do not by themselves prove that every x in B_j has centered maximal average at level one. If the questioned restoration uses recentered test cubes, include their actual halfsides, incidences and volume powers in the finite implication; for example recentering a cube of halfside s_j at x in B_j must track the extra radius allowance. Do not replace this geometric step by the statement B_j is automatically a bad set at the same level. If original-input and auxiliary-source variables differ in the claimed restoration, keep them distinct with the actual asserted map.

A rational primal/dual pair can expose a missing finite factor or certify the stated finite instance. Failure is decisive only for the exact finite implication it realizes. Success proves neither a uniform original L1 theorem nor that a small shrinking-receiver surrogate R implies the desired original weak constant. The main audit must still account for all powers, arbitrary inputs, covering selection and limit/restoration steps.


Stop after protocol handoff. The designated Terra executor/coordinator owns execution and any new computed evidence.
