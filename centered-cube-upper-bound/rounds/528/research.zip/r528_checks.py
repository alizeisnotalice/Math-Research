#!/usr/bin/env python3
"""R528 bounded symbolic/rational reproducibility checks, not a geometric budget."""
from pathlib import Path
from fractions import Fraction as Q
import json,random,sys,platform,time
import sympy as sp
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def square_expansion():
 t=sp.symbols('t',real=True)
 ff,fv,fe,vv,ve,ee=sp.symbols('FF FV FE VV VE EE',real=True)
 G=sp.Matrix([[ff,fv,fe],[fv,vv,ve],[fe,ve,ee]])
 coeff=sp.Matrix([1,t,1]);delta=sp.Matrix([0,t,1])
 full=sp.expand((coeff.T*G*coeff)[0]-ff)
 delta_square=sp.expand((delta.T*G*delta)[0])
 expected=2*t*fv+2*fe+t*t*vv+2*t*ve+ee
 ck(sp.expand(full-expected)==0)
 ck(sp.expand(delta_square-(t*t*vv+2*t*ve+ee))==0)
 ck(sp.expand(full).coeff(ve)==2*t)
 omitted=sp.expand(full-2*t*ve)
 ck(sp.expand(full-omitted)==2*t*ve)
 return {'symbols':'FF=<F,F>, FV=<F,V>, FE=<F,E>, VV=<V,V>, VE=<V,E>, EE=<E,E>; t real; one complete Gram field',
 'Delta':'t V+E','Delta_norm_squared_exact':str(delta_square),'full_energy_increment_exact':str(full),'mandatory_mixed_term':'2*t*VE','error_if_mixed_term_omitted_exact':str(sp.expand(full-omitted)),
 'scope':'Exact formal symmetric bilinear algebra; no assumptions of orthogonality, independent fields or geometric payment.'}

def singleton_radius_example():
 R=sp.symbols('R',positive=True);q=sp.sqrt(2)/4
 source_left=-sp.Rational(1,4);source_right=sp.Rational(1,4)
 centre_left=-sp.Rational(1,10);centre_right=sp.Rational(1,10)
 mass=source_right-source_left;centremeasure=centre_right-centre_left
 max_distance=max(abs(source_left-centre_right),abs(source_right-centre_left))
 ck(max_distance==sp.Rational(7,20));ck(max_distance<sp.Rational(1,2))
 # For every centre and every R in [1,2], the entire source interval is captured.
 density=mass/R;solutions=sp.solve(sp.Eq(density,q),R)
 ck(solutions==[sp.sqrt(2)]);ck(1<solutions[0]<2)
 selected=solutions[0];D=sp.simplify(centremeasure/selected)
 energy=sp.simplify(mass*D**2)
 ck(sp.simplify(D-sp.sqrt(2)/10)==0);ck(energy==sp.Rational(1,100))
 ck(sp.simplify(density.subs(R,selected)-q)==0)
 return {'n':1,'source_function':'1_[-1/4,1/4]','centre_interval_exact':['-1/10','1/10'],'radius_interval_exact':['1','2'],'q_exact':str(q),'r_exact':'1','source_mass_exact':str(mass),'centre_Lebesgue_measure_exact':str(centremeasure),'maximum_centre_source_distance_exact':str(max_distance),'density_for_every_centre_exact':str(density),'complete_qualified_radius_set_exact':[str(s) for s in solutions],'selected_radius_exact':str(selected),'D_on_source_exact':str(D),'D_energy_exact':str(energy),'scope':'All actual centres in the interval; unique admissible radius, so a radius choice on a finite prescribed grid can miss all of them. This is a measurable-selection boundary example, not a geometric budget or order example.'}

def covariance_case(stage,shape,seed,stress):
 rng=random.Random(seed);nz,nx,ny=shape
 x=[Q(rng.randint(-9,9),rng.randint(1,9)) for _ in range(nx)]
 y=[Q(rng.randint(-9,9),rng.randint(1,9)) for _ in range(ny)]
 if stress:
  x[0]=Q(-10**6);x[-1]=Q(10**6)
  y[0]=Q(1,10**6);y[-1]=Q(-10**6)
 raw=[]
 for z in range(nz):
  layer=[]
  for j in range(nx):
   row=[]
   for k in range(ny):
    v=Q(rng.randint(1,19),rng.randint(1,19))
    if stress:v*=Q(10)**(12*((z+j+2*k)%5-2))
    row.append(v)
   layer.append(row)
  raw.append(layer)
 total=sum((raw[z][j][k] for z in range(nz) for j in range(nx) for k in range(ny)),Q(0))
 p=[[[v/total for v in row] for row in layer] for layer in raw]
 ck(total>0);ck(all(v>0 for layer in p for row in layer for v in row))
 ck(sum((v for layer in p for row in layer for v in row),Q(0))==1)
 pz=[sum((v for row in layer for v in row),Q(0)) for layer in p]
 ck(all(v>0 for v in pz))
 stats=[]
 for z in range(nz):
  ex=sum((p[z][j][k]*x[j] for j in range(nx) for k in range(ny)),Q(0))/pz[z]
  ey=sum((p[z][j][k]*y[k] for j in range(nx) for k in range(ny)),Q(0))/pz[z]
  exy=sum((p[z][j][k]*x[j]*y[k] for j in range(nx) for k in range(ny)),Q(0))/pz[z]
  cov=exy-ex*ey
  direct=sum((p[z][j][k]*(x[j]-ex)*(y[k]-ey) for j in range(nx) for k in range(ny)),Q(0))/pz[z]
  ck(cov==direct);stats.append((ex,ey,cov))
 ex=sum((pz[z]*stats[z][0] for z in range(nz)),Q(0));ey=sum((pz[z]*stats[z][1] for z in range(nz)),Q(0))
 covariance=sum((p[z][j][k]*(x[j]-ex)*(y[k]-ey) for z in range(nz) for j in range(nx) for k in range(ny)),Q(0))
 within=sum((pz[z]*stats[z][2] for z in range(nz)),Q(0))
 between=sum((pz[z]*(stats[z][0]-ex)*(stats[z][1]-ey) for z in range(nz)),Q(0))
 ck(covariance==within+between)
 # Conditional version: H=Z refines coarse G=Z mod 2. Keep all original atoms.
 conditional=[]
 for g in sorted(set(z%2 for z in range(nz))):
  indices=[z for z in range(nz) if z%2==g];pg=sum(pz[z] for z in indices)
  gx=sum(pz[z]*stats[z][0] for z in indices)/pg;gy=sum(pz[z]*stats[z][1] for z in indices)/pg
  gcov=sum((p[z][j][k]*(x[j]-gx)*(y[k]-gy) for z in indices for j in range(nx) for k in range(ny)),Q(0))/pg
  gwithin=sum(pz[z]*stats[z][2] for z in indices)/pg
  gbetween=sum(pz[z]*(stats[z][0]-gx)*(stats[z][1]-gy) for z in indices)/pg
  ck(gcov==gwithin+gbetween)
  conditional.append({'coarse_group':g,'fine_Z_values':indices,'probability_exact':str(pg),'conditional_covariance_exact':str(gcov),'mean_fine_conditional_covariance_exact':str(gwithin),'conditional_covariance_of_fine_means_exact':str(gbetween),'identity_residual_exact':'0'})
 vals=[v for layer in p for row in layer for v in row]
 if stress:ck(max(vals)/min(vals)>10**40)
 return {'stage':stage,'shape_Z_X_Y':list(shape),'seed':seed,'all_atoms_strictly_positive':True,'all_atom_count':nz*nx*ny,'X_values_exact':[str(v) for v in x],'Y_values_exact':[str(v) for v in y],'raw_weight_table_exact':[[[str(v) for v in row] for row in layer] for layer in raw],'probability_table_exact':[[[str(v) for v in row] for row in layer] for layer in p],'normalizing_raw_total_exact':str(total),'minimum_probability_exact':str(min(vals)),'maximum_probability_exact':str(max(vals)),'ratio_max_to_min_exact':str(max(vals)/min(vals)),'probability_Z_exact':[str(v) for v in pz],'conditional_Z_statistics':[{'z':z,'E_X_given_Z_exact':str(v[0]),'E_Y_given_Z_exact':str(v[1]),'Cov_XY_given_Z_exact':str(v[2])} for z,v in enumerate(stats)],'total_covariance_exact':str(covariance),'mean_conditional_covariance_exact':str(within),'covariance_of_conditional_means_exact':str(between),'identity_residual_exact':'0','coarse_conditional_checks':conditional,'scope':'Finite positive rational probability table; every atom retained, no tiny-weight cutoff or independence assumption.'}

def main():
 start=time.perf_counter();expansion=square_expansion();selection=singleton_radius_example()
 models=[covariance_case('initial',(2,2,3),52801,False),covariance_case('extreme_nonuniform_weights',(3,4,5),52802,True),covariance_case('expanded_random_rational_table',(6,7,8),52803,False)]
 out={'scope':'R528 bounded symbolic and exact rational reproducibility certificate only; no new model scan, no geometric budget or general-order evidence','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'arithmetic':'SymPy exact symbolic and fractions.Fraction'},'reproduction_command':[sys.executable,'-I',str(Path(__file__).resolve())],'input_range':{'geometry_n':1,'geometry_radius_interval':['1','2'],'covariance_stages':3,'covariance_atom_counts':[12,60,336],'seeds':[52801,52802,52803]},'full_field_expansion':expansion,'singleton_radius_example':selection,'conditional_covariance_tables':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r528_checks.json').write_text(json.dumps(out,indent=2)+'\n')
 print('EXPANSION',expansion['full_energy_increment_exact'])
 print('UNIQUE_RADIUS',selection['selected_radius_exact'],'D_ENERGY',selection['D_energy_exact'])
 for m in models:print('COVARIANCE',m['stage'],'atoms',m['all_atom_count'],'residual',m['identity_residual_exact'])
 print('PASS',checks,'exact R528 algebra/selection-boundary checks; no geometric-budget or order claim')
if __name__=='__main__':main()
