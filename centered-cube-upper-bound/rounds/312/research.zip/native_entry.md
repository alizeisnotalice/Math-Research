# R312 — direct canonical-FIRST entry and a whole-event degree corridor

## 1. Native inputs and exact provenance

This note starts from the alternative whole-softness mixed-witness route, not from an unverified identification of the R300-series auxiliary history fields. The general root weak bound remains unproved. The new statements below are unconditional on the inputs of the cited native reduction, whose existing analytic tools are taken as the audited starting point.

The authoritative original interface is `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md`, sections 1–2 and 7–9. In particular its lines 9–11 state, for the COMPLETE original f and the SAME common q,

    P_(sigma(x),L_s(x))*f(x)=q,
    P_(s',R')*f(x)<=q for every s'>=sigma(x), R' in [a,b]. (1)

Its lines 19 and 38 define the fixed source mu=mu_hi=f 1{f>q sqrt(n)}dy and explicitly inherit all upper row/future caps by positivity. Thus mu<=f, W_hi<=W, and

    P_(s',R')*mu(x)<=q on the same original rows.       (2)

This is a given original-input property, not FIRST recomputed for mu or for a kernel component. There is no need to identify it with the conditional fields of R311. In particular the condition left unresolved there is verified HERE by (1),(2).

The true profile is given in `full_soft_l2_extension/noise_parameter_route.md`, NP1:

    h=1_[-1/2,1/2], w(v)=integral_1^infinity e^(-u|v|)u^(-2)du,
    phi=h*w, psi_s=(1-s)h+s phi,
    P_(s,L)(v)=L^(-n) product_i psi_s(v_i/L).

The substitution t=1/u gives w(v)=integral_0^1 e^(-|v|/t)dt, exactly the profile used in R309–R311. All scales are FULL SIDES, a<=L_s,R_h<=b=2a. The original hard band is 2lambda<G0<=4lambda and q in [3lambda/4,lambda]. Put

    A_n=1+n log(b/a)=1+n log2, C_h=16/3.

`GENERAL_MIXED_POTENTIAL_LEDGER.md` lines 7–12 and 48–67 specify the remaining event E, the actual winners, the positive kernels and the original high-potential residual:

    k_s(x,y)=P_(sigma(x),L_s(x))(x-y) GOOD(x-y),
    k_h(x,z)=h_(R_h(x))(x-z) GOOD(x-z),
    R_HP=(1/q)integral_E integral k_s(x,y)k_h(x,z)
                                      I_HP(x,y,z) mu(dy)mu(dz)dx. (3)

GOOD is the original homogeneous angular mask. I_HP is the ORIGINAL indicator of

    C_yz(L_s,R_h)>T_yz, ||y-z||_1>H0,
    M(y)>q min(L_s,R_h)^n(n+2).

Here C_yz is the full-H correlation, T_yz and M use the original fixed high source, and H0 is the already audited radius in that ledger. No one of these quantities is recomputed after a degree split. All that the new payment uses of I_HP and GOOD is their positivity and upper bound one, but they remain in the exact residual being split.

Write X=lambda|E_band| and let the ENTIRE already-paid coefficient be

    A_paid=(2C_base+8)sqrt(n)W +(32/3)kappa_n W
           +(256/3)K_*^2 sqrt(n)W_lo
           +(64/63)(epsilon+Q_mix)W_hi, epsilon=1/16. (4)

The native whole-band entry is exactly

    X<=A_paid+(64/63)R_HP.                            (5)

In (4), K_* is the absolute L2 constant, NOT a degree cutoff. Near and low-correlation payments already appear once in A_paid. The marked alternative in section 9 is not added to (5). If W_hi=0, the retained event is empty and no new argument is needed.

## 2. A native higher-degree receipt with no conditional history bridge

Use the genuine positive common-soft expansion

    P_(s,L)=sum_(k=0)^n b_(n,k)(s)Q_(k,L),
    b_(n,k)(s)=binom(n,k)s^k(1-s)^(n-k),

where Q_k is the normalized average of the tensor products with k phi coordinates and n-k hard coordinates. Fix 1<=k0<=n and p=k0/n. For s<=p/2, positivity gives

    sum_(k>=k0)b_(n,k)(s)Q_(k,L)<=r_(n,k0)P_(p,L),   (6)

with

    r_(n,k0)=2^(-k0)[(1-p/2)/(1-p)]^(n-k0), p<1,
    r_(n,n)=2^(-n).

Indeed the coefficient ratio is decreasing in k>=k0 and increasing in s<=p, so its maximum is at k=k0,s=p/2. At p=1 ONLY degree n is involved and its coefficient is s^n; there is no division by zero coefficients of other degrees. At s=0 all retained positive degrees vanish. The elementary entropy bound gives

    r_(n,k0)<=exp[-(log2-1/2)k0]<=exp(-k0/6).          (7)

For completeness, log(1+p/[2(1-p)])<=p/[2(1-p)] bounds the non-p term in -log r by k0/2; log2>2/3 follows by integrating 2/(1-t^2) on [0,1/3].

Define R_HP,up(k0) by replacing ONLY the soft capturing kernel in (3) by its degree>=k0 part and multiplying by 1{sigma<=k0/(2n)}. From (1),(2), its unqualified aggregate soft response is at most r q. Therefore

    R_HP,up(k0)
       <=r integral_E [h_(R_h(x))*mu](x)dx
       <=r A_n W_hi.                                (8)

The first inequality is applied to the actual x integral after dropping I_HP and GOOD only positively. The last inequality is the exact finite hard-scale envelope integral

    integral sup_(a<=R<=b)h_R(x-z)dx=1+n log(b/a).

There is a single hard-source price, not one per degree, source pair, parameter band or receiver. This is the R311 source receipt now directly applied to the authentic complete-event remainder. Its target fee is (64/63)r A_n W_hi in (5), with the exact complementary components of R_HP retained.

## 3. One moving cutoff across all actual softness values

A fixed k0 is not necessary. The original cap (1) holds simultaneously for EVERY higher softness, so a measurable receiver-dependent p(x)>=sigma(x) is legal. It is an auxiliary kernel for an upper estimate, not a replacement of the original FIRST winner.

Choose one integer m>=7, fixed for the whole original outer instance, and put

    k_plus(x)=ceil(2n sigma(x)+m),
    k_minus(x)=floor(n sigma(x)/8-m).                 (9)

Let the upper kernel be the actual sum over k>=k_plus, with the sum empty if k_plus>n. Let the lower kernel be the actual sum over k<=k_minus, empty if k_minus<0. The remaining degrees k_minus<k<k_plus form the corridor kernel. All three kernels are multiplied by the original GOOD factor and use the actual sigma,L_s. Since k_minus<k_plus, they partition the original positive soft kernel EXACTLY, including integer ties and the degrees 0,n.

When the upper sum is nonempty, k_plus>=m and p(x)=k_plus/n satisfies sigma<=p/2. Equations (6),(7) and the same higher-softness cap yield, pointwise after mu integration,

    integral k_s,upper(x,y)mu(dy)<=e^(-m/6)q.

On the empty branch the response is zero, so no nonexistent p>1 is queried. Consequently the actual positive R_HP upper part satisfies

    R_upper<=e^(-m/6) A_n W_hi.                      (10)

There is no softness-window sum: at each receiver the original full future cap is used once, and the same hard-scale column pays all receivers together.

## 4. The lower tail and legitimate whole-event absorption

We recall the pointwise true-kernel fact needed here, rather than transferring a historical residual identity. On the hard interval phi>=1/4: phi(1/2)=integral_0^1 t(1-e^(-1/t))dt>=(1-e^(-1))/2>1/4, and phi is even decreasing. At a point with P_s>0 the positive tensor expansion has independent posterior label probabilities

    pi_i=s phi(v_i)/[(1-s)h(v_i)+s phi(v_i)]>=s/4.

Outside the hard interval the corresponding probability is exactly one. This is independence in the fixed product kernel, not independence of original sources or posteriors. Thus the density of degrees <=k, divided by the full kernel, is at most

    2^k product_i(1-pi_i/2)<=2^k(1-s/8)^n
                                      <=2^k exp(-ns/8). (11)

At zero full kernel every component is zero. If k=k_minus>=0, (9) implies

    2^k exp(-n sigma/8)
       <=2^(-m)exp[-(1-log2)n sigma/8]<=2^(-m).

After multiplying by GOOD this gives k_s,lower<=2^(-m)k_s pointwise, without using a component FIRST. The unqualified original mixed total obeys

    (1/q)integral_E [integral k_s dmu][integral k_h dmu]dx
       <=4lambda |E|<=4X.                           (12)

Here the original selected soft response is <=q and the SAME original hard winner response is <=4lambda. Therefore

    R_lower<=4*2^(-m) X.                             (13)

This is a whole-event error, not a source price and not an assumption about R_HP itself. It retains all positive masks until the upper estimate. It does not delete outputs without accounting for their measure.

Define R_corr by (3) with precisely the corridor soft kernel. Then

    R_HP=R_upper+R_lower+R_corr                       (14)

is an exact positive identity. Inserting (10),(13) into (5) gives the sharper full ledger

    [1-(256/63)2^(-m)]X
       <=A_paid+(64/63)e^(-m/6)A_n W_hi+(64/63)R_corr. (15)

For m>=7 the bracket is at least 61/63. In particular

    X <=(63/61)A_paid
          +(64/61)e^(-m/6)A_n W_hi+(64/61)R_corr.     (16)

All constants in the original complete-event entry have now been carried through. Finiteness for absorption follows directly from the original hard band: 2lambda|E_band|<=integral G0(x)dx<=A_n W by the hard-scale envelope, hence X<=A_n W/2<infinity. The strict band inequality implies this non-strict bound. No epsilon is absorbed into an undefined surrogate target. One may choose

    m=max(7,ceil(6 log_+(A_n/eta)))

to make the new source fee at most (64/61)eta W_hi. For example eta=sqrt(A_n) gives m=max(7,ceil(3 log A_n)). The previously paid coefficient in (4) remains of root-polylog order after the constant 63/61 enlargement. This is a newly paid part of the COMPLETE native event, not a relabelling of the old auxiliary low-pe target.

## 5. Exact connection to the spatial payments, and their limitation

The full-H column/near theorem was already used in constructing (5). Each degree part retains the same actual high-C, far and high-potential qualifications, with the original C_yz,T_yz,M,H0 untouched. Positivity allows these masks to be dropped for (8),(10),(13); it does not allow replacing full H in the high-C test by an actual degree correlation. No second near or low-C fee is added.

There is also a directly composable spatial source receipt inside R_corr. Set

    E_b(x-y)=sum_i (|x_i-y_i|/b-1/2)_+,
    c_(n,k)=max_(0<=s<=1)b_(n,k)(s),
    C_(n,K)=sum_(k=1)^K c_(n,k)(8/5)^k.

For fixed S in [0,1] and D>=0, the corridor at sigma<=S has degrees at most

    K_S=min(n,ceil(2nS+m)-1).

The native corridor contribution with sigma<=S and E_b>D satisfies

    R_corr,deep(S,D)<=(16/3)A_n C_(n,K_S)e^(-D/2)W_hi. (17)

Here is the full interface rather than an unsupported transfer. For the actual phi, if V=H+W with H uniform on [-1/2,1/2] and W density w, then (|V|-1/2)_+<=|W| and E exp(|W|/2)=8log2-4<8/5. Therefore the normalized Q_k has exponential total exterior-depth moment <=(8/5)^k. For each L<=b the COMMON-b depth is no larger than the depth after scaling by L. Apply the full ray-decreasing scale envelope

    Q_(k,L(x))(x-y)<=Q_(k,b)(x-y)
                        +n integral_a^b Q_(k,L')(x-y)dL'/L'

BEFORE restricting to E_b>D. Its tail integral is at most A_n(8/5)^k e^(-D/2). The k=0 tail is zero for D>=0. Drop only the positive coefficient/GOOD/masks, using b_(n,k)(sigma)<=c_(n,k); then use the original hard response <=4lambda at the actual receiver and 4lambda/q<=16/3. This proves (17) with true dx and a single soft-source mass W_hi. It does not presume that a tail-truncated profile is ray-decreasing.

Let R_corr,rest(S,D) be the EXACT complement within R_corr: sigma>S, or sigma<=S and E_b<=D. Equations (16),(17) give

    X <=(63/61)A_paid
       +(64/61)[e^(-m/6)A_n+(16/3)A_n C_(n,K_S)e^(-D/2)]W_hi
       +(64/61)R_corr,rest(S,D).                     (18)

Thus the full-soft spatial tail can enlarge the actually paid branch without rebuilding sources. Taking S=1 covers every actual softness but may force K_S=n and D of order n for a root source fee. Taking S=O(log n/n) keeps K_S=O(log n), but leaves all sigma>S corridor traffic. These costs are explicit; neither option is a full root payment of R_HP.

In particular E_b<=D is NOT the already-paid source-pair condition ||y-z||_1<=H0. Hard capture only implies

    sum_i (|y_i-z_i|/b-1)_+<=E_b(x-y),

so the existing near theorem cannot be reapplied to the whole remaining shallow corridor at radius H0. The potentially large n*b hard-interior displacement is still present. Native high potential is not a source-density cap. The concrete remaining challenge after (16), or the optional (18), is a root spatial price for the original high-C/far/high-potential traffic carried by the degree corridor. For sigma of order one this corridor can still contain degrees of order n. The theorem does not claim it is a uniformly low-dimensional source problem.

## 6. Sharper optional upper cutoff without any additional source copies

The simple corridor suffices for the whole-event statement. A sharper upper tail can be obtained in the same native fields. For u>0 and 0<sigma<1 set

    k_u(sigma)=min{k in {1,...,n}: k/n>=sigma,
                                nD(k/n||sigma)>=u},

with k_u=n+1 if the set is empty. Define k_u(0)=1 (the positive-degree kernel is zero), k_u(1)=n+1. At a nonempty cutoff p=k_u/n, the degree ratio for every j>=k_u is at most exp[-nD(p||sigma)]<=e^(-u). The cap (2) at this p then pays the actual upper tail by e^(-u)A_n W_hi, with no parameter-band sum. The defining finite tests make k_u measurable. This can replace the upper tail if its exact complementary degree set is used; it is an alternative bound, not an extra fee added to (16).

Its scale is explicit: writing mu0=n sigma and Delta=k-mu0, the elementary relative-entropy lower bound

    nD(k/n||sigma)>=(k-mu0)^2/(2k)

follows from D(p||sigma)>=p log(p/sigma)-p+sigma and log(t/sigma)>=(t-sigma)/p for sigma<=t<=p. Hence, if the following integer is <=n,

    ceil(mu0+u+sqrt(u^2+2mu0 u))

is a sufficient cutoff. Otherwise the exact finite definition remains. This improves the upper edge of the corridor but supplies no bound for the retained central traffic. Endpoint and empty-tail conventions are essential.

## 7. Executed three-stage diagnostics and scope

The following standalone Fraction calculation checks small dimensions, boundary dimensions and expanded dimensions. It checks coefficient comparisons, the exact degree partition, lower-tail scalar bounds, the p=1 endpoint and the complete-event absorption constants. It does not simulate canonical FIRST or certify the old near theorem; the actual-input applicability is established by the cited original assumptions and the analytic argument above. The script writes no files.

```python
from fractions import Fraction as F
from math import comb,ceil,floor
ct={'coefficient':0,'partition':0,'lower_tail':0,'endpoint':0,'absorption':0}
for dims in ((1,2,4),(8,16,32),(64,128,256)):
 for n in dims:
  for m in (7,11):
   for s in (F(0),F(1,2*n),F(1,16),F(1,4),F(1,2),F(1)):
    kp=ceil(2*n*s+m);km=floor(n*s/8-m)
    assert km<kp
    bins=[F(comb(n,k))*s**k*(1-s)**(n-k) for k in range(n+1)]
    lower=sum(bins[k] for k in range(n+1) if k<=km)
    upper=sum(bins[k] for k in range(n+1) if k>=kp)
    middle=sum(bins[k] for k in range(n+1) if km<k<kp)
    assert lower+upper+middle==1;ct['partition']+=1
    if 1<=kp<=n:
     p=F(kp,n)
     r=F(1,2)**n if p==1 else F(1,2)**kp*((1-p/2)/(1-p))**(n-kp)
     assert s<=p/2 and kp>=m
     for k in range(kp,n+1):
      bp=F(comb(n,k))*p**k*(1-p)**(n-k)
      assert bins[k]<=r*bp;ct['coefficient']+=1
     if p==1:assert bins[n]<=F(1,2)**n;ct['endpoint']+=int(p==1)
    if km>=0:
     assert F(2)**km*(1-s/8)**n<=F(1,2)**m
     ct['lower_tail']+=1
    else:assert lower==0
for m in (7,8,11,16,32):
 factor=1-F(256,63)*F(1,2)**m
 assert factor>=F(61,63)>0
 assert 1/factor<=F(63,61)
 assert F(64,63)/factor<=F(64,61)
 ct['absorption']+=1
print('PASS',ct)
```

Only /tmp/r312_native_entry.md is owned and modified. The canonical archive, other agents' proofs and Git are unchanged.
