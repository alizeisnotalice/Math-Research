# R312 exact degree-band certificates

Finite exact Fraction coefficient, posterior-exponential and absorption diagnostics. Rational Taylor enclosures certify every exponential comparison in these finite cases; they do not replace the independent all-input analytic proof. Native FIRST has been verified by this round’s independent analytic original-document audit; these numerical checks do not establish or replace that proof. Atomic coefficient fixtures need not satisfy every native selector constraint. Complete source/root closure is not certified here; corr remains explicitly unpaid.

j=ceil(2n sigma+m). Ifj<=n,p=j/n; retained coefficient ratio maximal atdegreej. p1 onlydegreen; j>n is an empty tail with no p>1. Uniform endpoint ratio rhat=2^-j[(1-p/2)/(1-p)]^(n-j) (p1:2^-n) boundsactualrj. rhat*TaylorUpperExp(j/6)<=1 certifies rj<=exp(-j/6)<=exp(-m/6).

ell=floor(n sigma/8-m). Ifell>=0, TaylorLowerExp(nsigma/8)>=2^(ell+m) certifies2^ell exp(-nsigma/8)<=2^-m. Empty lower tails are separate.

Forx>=0 chooseh withy=x/2^h<=1/2; L=sum_(k0..8)y^k/k!, U=L+(y^9/9!)/(1-y/10). Positive-series remainder gives L<=exp(y)<=U; raise both to2^h. All arithmetic rational. Displayed decimal values are diagnostics only.

An=1+nlog2<=n+1 sincee>2. m>=7 is chosen by exact(n+1)/TaylorLowerExp(m/6)<=eta1/128; previousm fails even withTaylorUpperExp. Hence m>=ceil(6log(An/eta)) conservatively, without floating log decisions.

|n|recorded m|conservative source price upper|
|---:|---:|---:|
|1|34|0.006918754692385318515085553678717061252188|
|4|39|0.007517196034240481392621745385692501735800|
|16|47|0.006737138875474497364537334689588425081061|
|64|55|0.006790169355072604386939965644776427803099|
|256|63|0.007076867503374144876059661345234427871343|
|1024|71|0.007439992534376552567185824554959043940681|
|4096|80|0.006635488210444246600774759722380810230492|

whole mixed<=4X and c=64/63 give a=c*4*2^-m<=2/63; 1/(1-a)<=63/61 and c/(1-a)<=64/61. Retain corr; no payment is inferred for it.

Initial21 cases n8/16/32,m7; boundary cases floor/ceil exact and±rational perturbations,p1,emptytails,sigma near1 and hard-margin annotation; expanded24 cases n256/1024/4096 with recorded source-pricing m. Coefficients exhaustive only whenn<=32; otherwise selected endpoint/interior degrees, not a large sweep.

Every model retains the full degree partition lower+upper+corr. Floor/ceil equality decisions, source-price targets and absorption are exact rational decisions. Only the stated finite configurations are certified here.
