# Current general reductions: marked inside and all-softness mixed witnesses

Status: the full centered-cube sqrt(n)n^{o(1)} weak bound is UNPROVED. Two independently valid general routes are retained: the marked/critical route in sections1–6 and the whole-softness mixed-witness route in sections7–8. Their full-event fees are not added. This integrates the independently accepted FULL joint-softness L2 theorem, full-soft near-pair Schur theorem and full-soft actual-volume lens proof. The full joint L2 reviews are signed_band_geometry/noise_parameter_geometry_audit.md and full_soft_l2_extension/noise_parameter_review.md. Both the earlier critical-only ledger and the present strengthened whole-event low-density deletion passed GENERAL_CURRENT_REDUCTION_REVIEW.md (upgrade in section6). It does not assert that either remainder below is bounded. The previously accepted detailed inside/padded tools remain available in UNCUT_FIRST_LEDGER.md and signed_band_probability/adaptive_padded_lens_payment.md.

All physical scales here are FULL SIDES in one octave [a,b], b=2a. All thresholds and output fees use one original complete input f>=0, mass W, and a common level q. The original family is P_s,L=psi_s^tensor-n dilated by L. No FIRST is recomputed on a cut or restricted source.

## 1. Original hard band and complete positive process

Work on 2lambda<G0<=4lambda, G_s=sup_(a<=L<=b)P_s,L*f. The already proved fully-soft baseline and physical endpoint branches cost at most (2C_base+8)sqrt(n)W in lambda-units. Remaining rows carry an original interior global FIRST at a common q in [3lambda/4,lambda]:

    P_sigma,L*f=q,  P_s,R*f<=q for every s>=sigma and R in [a,b].

The hard band supplies G0/q<=16/3 and sigma>1−2^(−1/n)>c0/n, with c0=log2/2. This lower margin is derived from the FULL original source at its hard winner, not from a later restricted source.

Apply the accepted allsoft angular deletion once: badresponse B_all f>q/8 costs q-fee<=8kappa_nW, hence lambda-fee<=(32/3)kappa_nW. On all other rows the COMPLETE GOOD response is at least7q/8. Here kappa_n=O(n^(−5/2)) and the literal angular threshold is the already audited one; no posterior independence is invoked.

## 2. All-softness low-density payment, then the critical split

Let f_lo=f1_{f<=q sqrt(n)}, f_hi=f1_{f>q sqrt(n)}, and mu_hi=f_hi dy, with W_lo+W_hi=W. This decomposition is fixed by the common q and does not vary with x.

The proved full_soft_l2_extension/noise_parameter_route.md gives an ABSOLUTE bound for the entire joint maximal family with 0<=s<=1 and all L>0:

    ||M_all g||2<=K_*||g||2,  K_* independent of n and softness.

Its proof uses the exact signed softness derivative, the actual cube Fourier factor, the dimension-free annular scale Sobolev estimate, and strong L2 Minkowski. All masks remain present. The earlier critical_soft_l2/proof.md remains valid but is no longer needed for this payment.

Delete from the WHOLE remaining event the outputs where M_all f_lo>q/8, before splitting softness. This is a genuine original-source payment

    q|E_lo|<=64K_*²sqrt(n)W_lo,
    lambda|E_lo|<=(256/3)K_*²sqrt(n)W_lo.

On ALL remaining rows, the COMPLETE original-kernel GOOD response from mu_hi is

    T_hi(x)=integral P_sigma,L(x−y)GOOD(x−y)dmu_hi(y)>=3q/4.

This follows from q minus at mostq/8 BAD response minus at mostq/8 total low-source response. It does not require the auxiliary mask/rank stop or positive-cell deletion. Those accepted tools are retained for later use, not charged again in this reduction.

The selected sigma,L,q are unchanged. Positivity gives row/future responses of mu_hi<=q, which are exactly the upper hypotheses used by the soft Schur proof and its whole-source-cell intensity cap. Equality q is not asserted for mu_hi. The independently proved allsoft_weighted_cell_cap.md further makes that cell cap uniform in sigma, but the varying-softness column envelope is not thereby removed.

For n>=4 set C_n=sqrt(log(2+n)) and now split the retained rows into E_crit={sigma<=C_n/n} and E_large={sigma>C_n/n}. Keep BOTH sets. The definition of E_large now excludes the paid all-softness low-source exception; its high-source GOOD response is at least3q/4.

## 3. Whole critical row: actual-volume soft potential plus a far-pair remainder

Use H=H_(C_n/n), the complete UNCUT critical coefficient envelope, with mass D<=1+sqrt(2C_n). Put N1=1+2nlog2 and fix epsilon=1/16 and A=1. For the fixed hi source define

    M_exp,hi(y)=integral exp(−||y−z||1/(64b))dmu_hi(z),
    h_yz(L)=L^(−n) C_H((y−z)/L),
    t(y,z)=epsilon q exp(−||y−z||1/(64b))/(N1 M_exp,hi(y)),
    H0=64b log[D²N1(2+n)/epsilon].

If W_hi=0 the retained event is empty. Otherwise this potential is strictly positive. The threshold t is source-only and directed; no source threshold is chosen from an observation's posterior.

Take EXACTLY k_x(y)=P_sigma,L(x−y)GOOD(x−y). The full-soft qualified Abel lemma pays its ordered-pair sublevel branch h_yz(L(x))<=t(y,z) by epsilon W_hi after dividing the spatial integral by q. Then pay ALL pairs with ||y−z||1<=H0 by the accepted full-soft Schur theorem. Its explicit SS8 bound gives

    Q_n=O(sqrt(n)log^(9/4)(2+n))

with constants independent of input, threshold, source count, grid and depth. This growing-C consequence uses D, additive2C_n and the displayed H0 in SS8, not an implicit fixed-C constant from SS9.

The remaining directed qualification is

    h_yz(L(x))>t(y,z),
    ||y−z||1>H0,
    M_exp,hi(y)>qL(x)^n(2+n).                           (Rcrit)

The third inequality follows from the first two and the proved exponential correlation bound. Keep the nonnegative quantity

    R_crit=(1/q)integral_Ecrit,remaining integral_(Rcrit)
                  k_x(y)k_x(z)dmu_hi(y)dmu_hi(z)dx.

It is NOT asserted rare or paid. Since T_hi>=3q/4, the exact squared-response back-substitution is

    q|E_crit,remaining|<=16/9[(epsilon+Q_n)W_hi+R_crit].

This treats inside, outside and mixed source pairs together. Every soft mask and never-entering soft tail is retained. The broad exponential potential may still be large for hi sources; the paid low-density deletion removes one artificial background contribution, not the remaining mathematical difficulty.

## 4. Complete band inequality and the unchanged large-softness branch

Combining only the actual positive output deletions above yields

    lambda|E_band|
    <=(2C_base+8)sqrt(n)W +(32/3)kappa_nW
       +(256/3)K_*²sqrt(n)W_lo
       +(64/27)(epsilon+Q_n)W_hi
       +(64/27)R_crit +lambda|E_large|.                 (GENERAL-REDUCTION)

The explicit paid coefficient is now O(sqrt(n)log^(9/4)(2+n)): K_* is absolute and Q_n has the displayed near-pair bound. Thus it has the required sqrt(n)n^{o(1)} order. The finitely many n<4 are covered by the existing full hard-octave column bound with an absolute constant. This bookkeeping establishes the target order ONLY for the already paid branches.

For E_large, the full selected hard-inside response I satisfies

    I/q<=(16/3)exp(−beta n sigma)<(16/3)exp(−beta C_n),
    beta=1−phi(0)>0.

For n above the fixed explicit threshold where (16/3)exp(−beta C_n)<=1/8, the retained HIGH-SOURCE GOOD outside response is at least5q/8: its complete GOOD response is at least3q/4 and its inside response is at most the full-source I<=q/8. The historical full-source outside fraction3/4 must not be copied into this high-source version. Hence the asymptotically remaining large-softness branch is truly outside-dominant. This is a qualification, not its spatial fee. For smaller n either retain the whole E_large as displayed or use the existing general bound with a finite absolute adjustment; no output is dropped.

## 5. Remaining proof obligations

The full target now still requires source-W payments at sqrt(n)n^{o(1)} order for BOTH R_crit and lambda|E_large|. The inside padded-lens/cylinder tools can be applied to further incidence subbranches, with their actual source and q preserved. They do not by themselves bound R_crit, and the high padded or high soft-potential source mass cannot be assumed doubling or small.

After those estimates are actually proved, the prior threshold-band and Naor–Tao localization bookkeeping would introduce at most the already allowed logarithmic losses. Until then, the unconditional general upper bound retained from the research package remains O(n log n). There is no claimed improved general exponent and no completed endpoint proof.

## 6. Marked-source improvement inside the critical remainder

The general marked-source lemma and INSIDE_MARKED_LEDGER.md can now refine the critical remainder without altering the preceding whole-family argument; the lemma, inside ledger and substitution below passed marked_source_lens/independent_review.md. Let E_I be the retained critical rows where the complete GOOD hi INSIDE response is at least3q/8. Use the fixed source mu_hi and the same original sigma,L,q. Its original hard ceiling is at most C_h q, C_h=16/3. The inside ledger uses c0=3/8 and gives

    q|E_I|<=A_h W_hi+(64/9)R_mark,
    A_h=e sqrt(n)+(8/3)Ntop+(64/9)(epsilon+Q_h),
    Ntop<=11/3, Q_h=O(C_h sqrt(n)log²(n+2)).

R_mark is the exact high MARKED-potential/far inside-pair response remaining after the paid all-physical cell exception and top collar. The source-cell mark is t_C=(mu_hi(C)/(e²q/sqrt(n)))^(1/n), and the marked potential keeps only points with both source distance and cell birth at most (1+1/n)L. It removes no retained actual inside incidence. Sources, q and FIRST remain unchanged.

Partition the ORIGINAL R_crit by rows into R_crit,I and R_crit,out. Since its full hi row response is at most q,

    R_crit,I<=q|E_I|.

Thus in GENERAL-REDUCTION its term (64/27)R_crit can be replaced by

    (64/27)A_h W_hi +(4096/243)R_mark +(64/27)R_crit,out.

This is a substitution inside the previous remainder, not a second full-event fee or a second FIRST. On the complementary retained critical rows, hi GOOD outside response is at least3q/8. The paid coefficient remains O(sqrt(n)log^(9/4)(n+2)). The unresolved terms are now explicitly the high marked inside response R_mark, the critical outside-row soft-pair remainder R_crit,out, and the large-softness high-source output lambda|E_large|. All three remain unproved at the desired order.

The older heavy-parent thinning payment is contained in moderate marked potential (ML6) and is NOT added again. No repeated thinning or source-amplitude-depth budget is assumed. For n<4 use the already stated finite-dimensional treatment.

## 7. Alternative whole-softness mixed-witness reduction

The independently accepted signed_band_geometry/hard_soft_witness_route.md and hard_soft_witness_review.md prove an actual mixed NEAR spatial payment for all moving sigma>=c0/n. Apply it directly after sections1–2's whole-event deletions, before the critical/large split. Let R_h be the ORIGINAL hard winner and L_s the ORIGINAL soft FIRST winner at the same output. The pure homogeneous angular GOOD qualification is valid at both physical scales. The fixed high-source hard GOOD response is at least G0−q/8−q/8>=7q/4; its soft GOOD response is at least3q/4. Their upper bounds remain C_hq and q. No source, level or FIRST is changed.

With k_h and k_s the corresponding complete positive high-source kernels, the normalized product back-substitution has q factor16/21 and lambda factor64/63. For H0=A0 a log(n+2), the entire moving-softness near-pair term is paid by

    Q_mix W_hi,   Q_mix=O(sqrt(n)log²(n+2)).

The proof uses the hard-reference raw cell cap, a one-sided weighted Schur column, and a source-only light-partner union of mass at most W_hi/sqrt(n). The full softness envelope has mass J=O(n^(3/2)), but enters as J^p and ultimately only through logJ; it is not assigned mass1. All source cells, soft masks and tails remain. Define the ORIGINAL far integral

    R_mix,far=(1/q) integral_E integral_(||y−z||1>H0)
                         k_s(x,y)k_h(x,z)dmu_hi(y)dmu_hi(z)dx.

The alternative whole-band bound, detailed in MIXED_WITNESS_LEDGER.md, is

    lambda|E_band| <=(2C_base+8)sqrt(n)W +(32/3)kappa_n W
                     +(256/3)K_*²sqrt(n)W_lo
                     +(64/63)Q_mix W_hi +(64/63)R_mix,far.

This does not compare R_mix,far with the three earlier remainders. It is another complete-event reduction, not an additional disjoint branch to be charged on top of section6. The mixed FAR integral remains UNPAID. Different-scale plateaux forbid a free exponential gap factor under Rmax^(-n) normalization, but do NOT forbid a min-scale normalized correlation bound: the ratio Rmin/Rmax supplies an exponential dimension factor. No mixed-lens bound was needed for this near theorem.

The three registered stages and independently reviewed supplements include576 kernel/shape ingredients,24 complete-source rows,9 mass graphs and90 radial/top edges. The same-octave captured supplement has432 exact-Gamma/softness-qualified rows. These are diagnostics, not a continuous-FIRST or spatial operator certificate; the stated order follows from the analytic proof. The general endpoint and any improved unconditional exponent remain unproved.

## 8. General full-H spatial column refines the mixed far remainder

The independently accepted mixed_far_geometry_route.md MF1–4 and joint_mixed_lens_payment.md JM1–11 now refine section7 to a single HIGH actual weighted-potential remainder. Their separate reviews and GENERAL_MIXED_POTENTIAL_REVIEW.md verify the complete integration in GENERAL_MIXED_POTENTIAL_LEDGER.md. The new argument covers ALL original softness and BOTH independently moving original physical scales; it does not assume a new restricted source class or a new FIRST.

For the complete full-softness envelope H and each original ordered source pair, put g=||y−z||1, X=g/a, B_yz=10^5(n²+n+X),

    C_yz(L,R)=integral H_L(u−y)h_R(u−z)du,
    N_yz=e^4[1+ceil(B_yz log2)]²,
    M(y)=integral exp(−||y−z||1/(64b))dmu_hi(z),
    T_yz=epsilon q exp(−g/(64b))/(N_yz M(y)).

The full-H adjacent-mask coefficient ratio is at most en. Replacing each hard parameter boundary trace by its positive soft sibling gives bounded logarithmic correlation variation O(n²+g/a). A pair-fixed finite physical grid then simultaneously dominates the actual kernels and controls the rounded correlation. This proves the qualified SPATIAL column <=N_yz T, not merely a fixed correlation bound. Tonelli and the displayed source-only threshold pay the ACTUAL branch C_yz(L_s,R_h)<=T_yz by epsilon W_hi. Qualification is for FULL H; smaller actual-sigma correlation does not imply it.

Meanwhile C_yz(L,R)<=D min(L,R)^(-n)exp(−g/(16b)), D<=1+pi sqrt(n)/2. Define the input-independent near radius EXACTLY as in GENERAL_MIXED_POTENTIAL_LEDGER.md section3: K=128/3, C_D=1+pi/2, C_N=e^4(2+2*10^5log2)², B_n=log(C_D C_N/epsilon)+(A+9/2)log(n+2), H0=2Ka[B_n+2log(4K)], with epsilon1/16 and A1. The correlation bound, N_yz<=C_N n^4(1+g/a)² and explicit log absorption show that every high-C but moderate-potential pair is within H0. Use the HS near coefficient computed at THIS radius; it remains O(sqrt(n)log²(n+2)).

Let R_HP be the original normalized mixed spatial integral restricted to C_yz(L_s,R_h)>T_yz, g>H0, and M(y)>q[min(L_s,R_h)]^n(n+2). The last inequality follows from the first two. Then the refined whole-band inequality is

    lambda|E_band| <=(2C_base+8)sqrt(n)W +(32/3)kappa_n W
                     +(256/3)K_*²sqrt(n)W_lo
                     +(64/63)(epsilon+Q_mix)W_hi +(64/63)R_HP.

This splits the former unqualified mixed far term into the paid low-C part and the HIGH-potential remainder. Near costs are not charged twice. The earlier marked/critical three-remainder route remains independently valid and is not added. R_HP IS STILL UNPAID; no rarity, doubling, posterior independence, new source or weak quasi-triangle is assumed. The target endpoint and any improved unconditional general exponent remain unproved.

The proof also preserves a useful audited counterexample: arbitrary hard-hard two-scale sublevel columns are false, even in dimension1, due to thin moving overlaps. This does not contradict the new FULL H theorem, whose positive soft sibling masks regularize that obstruction. Three registered stages, actual closed-grid supplements and independent reviews distinguish numerical step checks from the analytic all-input theorem.


## 9. 全软度仅硬端出生标记的一般替代总账（已独审）

GENERAL_MARKED_MIXED_LEDGER.md 与 signed_band_probability/marked_mixed_lens_payment.md 给出新的全输入替代分解：先支付原整格输出与原硬顶层输出，只给硬来源 z 固定出生标记；软来源 y 完整保留。加权闭出生累计的 S 个壳与双尺度空间网格 N_pair 都在低相关来源预算中消去。S≤2(n+2) 只增加近半径中的 log(n+2)，完整已付系数仍为 O(√n log²(n+2))。

这是独立替代总账，不与第8节无标记总账相加，也不宣称新旧余项互相包含。新的唯一显式余项为 R_HMP：原实际混合乘积，保持所有原资格、仅硬端 t(z)≤R_h、完整H的高相关资格、g>H_mark 及相对于实际 min(L_s,R_h)^n 的高出生累计势。R_HMP 尚未支付。主端点仍未证明，无条件一般基线仍为 O(n log n)。

解析与证据分别见 signed_band_probability/marked_mixed_lens_review.md、GENERAL_MARKED_MIXED_REVIEW.md 及 marked_mixed_radius/。新的27累计/567合格对/1701逐点请求是有标签标量与核压力，不是实际整格 FIRST 或输出体积实验；仅1647逐点比较实际非零，54浮点边界请求不活跃。显式半径9+117代数记录也不代替一般证明。


## 10. 一般路线筛选：晶体逐点桥已严格否定，局部化空间支付仍开放

anisotropic_cube_flow/route.md、flowmax_supplement.md 与 independent_review.md 给出新考察的晶体能量 E=.5∫||∇u||₁² 的全局弱流证书。质量1的正源 f=K_t、x=√(8nt)e₁、全边长L=√(8nt)满足实际cube平均/全时间flow最大值=2^n∫₀¹exp[−2n(v+v²)]dv≥2^(n−1)e^(−5/4)/n。故一般输入下任意亚指数费用的逐点cube→此flow比较均不成立；时间优化已包括在内。这不是cube弱型反例，也没有支付R_HMP。全局flux、603+27预登记记录与主tex集成均独审PASS；必须考虑新的分布/空间弱形式及非线性flow原W预算，不能再用被否定的逐点桥。

high_marked_cover/localized_marked_packing.md 与 independent_review.md：实际同一硬捕获排上的局部逆质量预算≤1，但降至固定源出生半径后，逆质量归一化能在固定维度、完整有限质量L1源上发散。三阶段163个完整盒独立65位复核通过。这只否定无资格的逆源质量预算；保留min(NT,真实列)的实际空间方向仍有效待加强。文档给出双端源质量均收费的随机receipt充分目标，其构造未证，不算新的上界。


## 11. 归一化相关核的逐行接口审计（已独审；不产生空间费用）

signed_band_probability/correlation_weight_route.md、correlation_weight_review.md 及主tex对应节已通过独立审查。两完整正均匀盒构造满足原连续全未来约束、真实FIRST、原整格质量限制与出生条件；质量一相关核 T_b=(h_b*phi_b)^tensor-n 的实际软后验势仍可指数大。完整H归一化自相关也由其全硬正项给出指数下界。因此“核质量归一化+future cap自动给逐行poly(n)势”这一强接口不成立。

该构造没有证明角向GOOD，且硬赢家R_h=a可落在此前支付的物理端点分支；不能称为保留R_HMP样本或cube空间弱型反例。完整来源质量本身指数大，大行势并不支付或否定空间W预算。幂温度质量公式只针对0<theta<=1的单一固定幂族，不排除新的分层弱形式。

六个预登记完整源记录分三阶段检查核与整格量。数值质量按有限物理扫描峰值调节，不是连续FIRST的数值证书；连续FIRST由解析存在性论证。完整H自相关的后续算术单独记录，没有重标为原预登记实验。当前一般端点仍未证明。


## 12. 源固定双向容量的部分空间支付（解析已独核）

high_marked_cover/next_spatial_capacity.md SC1–5 给出适用于原全部 R_HMP 交通的一般部分分解；独立审查见 next_spatial_review.md。固定 mu=mu_hi、B={t<=b}，N_h=1+nlog2，J_s=D_full(1+2nlog4)。软来源分区C_i的质量m_i若配硬子测度nu_i<=mu|B且|nu_i|<=m_i/√n，则原soft row与hard spatial column付N_h W_hi/√n。反向硬来源分区质量h_j若配soft子测度tau_j<=mu、|tau_j|<=h_j/n，则原hard row与full-soft spatial column付C_h J_s W_hi/n。两者都是Tonelli下的实际空间费；软端没有出生cut，重复mass包含在求和中。

具体取ell1直径<=Hmark/2的固定可数分区。A_i为距C_i>Hmark/2的eligible硬源，质量M_i；B_j'为距C_j>Hmark/2的全软源，质量T_j。系数p_i=min(1,m_i/(√nM_i))、r_j=min(1,h_j/(nT_j))，零分母取1。任何原far对y in C_i,z in C_j同时属于这两个对应关系。以ell=1−(1−p_i)(1−r_j)分裂原dPi，得到

    R_HMP = R_paid + R_heavy,
    R_paid <= [N_h/√n + C_h J_s/n] W_hi = O(√n)W_hi,
    R_heavy = integral (1−p_i)(1−r_j) dPi.

仅在第9节原余项中替换，费用和heavy均乘64/63；不重复添加另一整事件总账。未证ell的固定正下界，未证R_heavy目标费用，主端点不变。三个完整正源数值阶段仅为容量/原始条件屏幕，硬赢家均为底端a，没有被证实属于保留事件。旧notLOW记录中Nmax取界方向错误，原记录保留，Nmin保守下界另存 next_spatial_posthoc_notlow.json；完整scope见next_spatial_scope.json。不能把样本全部支付外推为一般heavy支付。


## 13. 有限随机源森林归约（解析已独审，余项未付）

high_marked_receipts/route.md HR1–9 及 independent_review.md 给出具体source-fixed coins构造。原出生整格质量与全格指数权几何和先证明，所有原R_HMP对均满足g<G_n=O(anlog(n+2))；这不是原near半径，不能直接代入HS目标费。取从a/n到D_top>=2G_n的共同随机平移嵌套格，只有J=O(log(n+2))层，来源支撑可以无界。每个实际远对以至少1/2概率同顶格，并在该种子下有唯一LCA。

在每个child C/parent P上，p_C=min(1,m(C)/(√n h(P\C)))、r_C=min(1,h(C)/(n m(P\C)))；h仅计原birth<=b，m计全部softsource。每方向一枚独立辅助coin在全部输出上固定。期望forward硬重复mass每层<=W_hi/√n，reverse软重复mass每层<=W_hi/n；另两端质量也记录，不能把种子独立性叫posterior独立性。

R_bal=E_shift integral 1_sameTop(1−p_Cy)(1−r_Cz)dPi 保留完整实际资格，且

    R_HMP <=2J[N_h/√n+C_h J_s/n]W_hi+2R_bal.

完整代入式见 GENERAL_CAPACITY_TREE_LEDGER.md §3。只替换一次原余项，费用仍为O(√nlog²(n+2))W；R_bal目标空间费未证。这与第12节是替代整余项归约，不相加、不声称余项包含。HR数值三阶段的执行/证据审核状态按其独审文件为准，源指派样本不是原FIRST/HMP样本。


## 14. 平方核列与最大轻祖先的一般空间支付（解析审查，数值状态见独审）

high_marked_receipts/balanced_analytic.md 与 balanced_analytic_review.md 给出新的真实空间部分支付。完整G_n=sup_s P_s²通过tensor导数+FTC得到∫G_n<=C2=1+2√2/beta，beta3/(4e)；ray-BV给joint squarecolumn<=2C2a^(−n)，hard squarecolumn<=2a^(−n)。任意固定来源群质量M的完整原mixed空间费<=C_sq M²/(qa^n)，C_sq=2√C2，不要求原f属于L2，未将LebesgueL2冒充L2(mu)。

按原HR LCA parentmass M_*=qa^n√n分割R_bal。在每个共同shift下，所有最大(最粗)lightcells是disjoint antichain，所有smallmass LCA pair均落在其中一个A，ΣmuA<=W_hi。平方列于是支付R_bal,small<=C_sq√nW_hi，**没有J因子**，也没有小直径条件。完整加强总账见GENERAL_CAPACITY_TREE_LEDGER.md §4，新的未付项为(128/63)R_bal,big。该余项仍保留全部原资格和fractionalweight，另加mu(LCA)>qa^n√n，未得目标费。旧SC为独立替代，不相加。


## 15. 硬端合格质量的实际物理门槛（PA已独审）

high_marked_receipts/physical_adapted_parent.md 及 review 给出一般分支的实际空间支付。每个sourcefixed parent质量M、eligiblehard质量h，设rho=max(a,[h/(q√n)]^(1/n))。在actual min(L_s,R_h)>=rho上，两个平方列从rho起给Csq M h/(q rho^n)<=Csq√nM。逐层ΣM=W_hi，故整个R_bal中h<=q minactual^n√n分支付Csq J√nW_hi。源测度始终fixed，rho=b保留端点，rho>b为空，h0无hardtraffic。

完整替代整账见 GENERAL_CAPACITY_TREE_LEDGER.md §6：P_MM+(128/63)J[A_n+Csq√n]W_hi+(128/63)R_bal,phys-heavy。它替换BA整个balanced付款，不再叠加BA小mass费；SC仍独立替代。余项h(P)>q minactual^n√n仍含原全部资格与fractionalweight，尚未付。三stage重构17192parents/68768thresholdchecks（455 h0），不是actualHMP或空间norm实验；独立边界补充另存，scope以review末节为准。


## 16. 软度尾与物理门槛联合替代（BT+PA）

balanced_tail_extension.md/review证明完整平方shape尾∫sup_(s>=s_j)P_s²<=C2(1−beta s_j)^n。分原σ为K_s=O(logn)半开dyadic带，v_j=(1−beta s_j)^(n/2)，sourcefixed rho_(P,j)=max(a,[v_j h(P)/(q√n)]^(1/n))。两个实际尺度均>=rho时实际spacefee<=Csq√nM(P)，每层ΣM=W_hi，JK_s总费Csq JK_s√nW_hi。

combined_parent_threshold.md 给出完整原交通分割，GENERAL_CAPACITY_TREE_LEDGER.md §7为最新替代：P_MM+(128/63)J[A_n+Csq K_s√n]W_hi+(128/63)R_*。R_*保持完整原资格/weight，另有v_j h(P)>q minactual^n√n。它没有目标支付，不能由whole eligible mass推实际capture或空间gain。BA/BT/PA旧balanced费用不重复加；SC仍独立替代。联合门槛的342/2916个70位新算术记录仅检查组合语义，不是actualHMP/空间norm，审查见combined_parent_review.md。

## 17. 原全future约束下的窗口熵—漂移工具（已独审，无空间费用）

high_marked_cover/next_spatial_entropy.md ES1–15及review已PASS。实际phi正规径向score通过inside concavity/outside Laplace convexity得s_phi<=−logphi+Cbar，严格有理证书Cbar<=1−log2−9367/2875000。Bernoulli/source Gibbs给sourcegroup正规score上界；固定原x,σ,q与一个原来源group，对整个R窗口的unnormalized latentmask tilt有B(t)^nP_(σ_t,R)ν<=qB(t)^n，无需每R完整source等q。以π_R=F_G(R)/q得E_GK<=nσ+sqrt(2nσlog1/π_R)+(1/3)log1/π_R。

因此原固定σ路径上差measure Φ_G−dF_G=(nF_G−S_G)dlogR有明确entropy deficit下界，完整BV硬trace与groupderivative保留，可对窗口测试函数积分。未把选中cusp密度当pointvalue，未把F′_G当0，未得Φ_G或dF_G各自sourceW Carleson费。294scalar/6group/30groupmgf/15fullmgf档案已独核；全窗口是另行解析强化，不重标为原数值项目。这个新工具尚未支付R_*。


## 18. 全软度补偿输出支付与精确高面迹余项（CS已独审）

next_spatial_compensated_split.md 以原完整smooth FIRST的物理stationarity，结合真实kernel centered tilt的poly二参数强包络，支付away-from-one LOWTRACE输出；sigma>1−A_*sqrt(log(n+2)/n)的整个参数带由observed-score mixedBV支付。全部新增outputfee为O(sqrt(n)log(n+2))W。解析、三stage核算术、独立集成审查PASS；证据范围见原proof、scope及review，不认证actualFIRST样本。

GENERAL_CAPACITY_TREE_LEDGER.md §8为最新完整替代：旧CP已付项一次保留，另加4/3(T_n+L_n)W，余项128/63 R_H为原R_*只限制到sigma<=1−d且Phi_full>n(1−sigma)q/2的原输出上。先删输出再把原CP用于子集，不能直接把交通量当输出体积。有限维用既有整强包络吸收；原任意L1弱逼近保持。所有已付项仍O(sqrt(n)log²(n+2))W，R_H未付，C_n的一般指数仍未改善。


## 19. 二维熵特征线及体积抵消（EC工具已独审，无新费用）

signed_band_probability/entropy_characteristic_route.md与review已PASS：来源群固定、原future允许的descendingR/increasings路径上，有精确正hard-exit BV测度及signed group导数，Phi_ch+dF=F[n(1−Cs)+logZ+D]dt，D>=0且Z=R^nF/m。完整积分保留两端响应与时间权导数。自然体积权R^n/m恰取消正n项，归一化式为(R^n/m)Phi_ch+dZ=Z[logZ−Cns+D]dt；不能据此支付源质量。

原octave只许T<=log2，odds增益<=2^C，不能从sigma~1/n流到near1已付带。固定参数的无资格空间flux质量仍n(1−s)m每单位time。这是全输入归一化排错与路径工具，不是actualFIRST反例或R_H支付。294+6+9冻结记录补充算术独审通过，非新quadrature/实际trace/空间norm。上一节总账不变。


## 20. 固定来源自身物理赢家与放大比（GR已独审，余项未付）

high_marked_cover/next_spatial_group_receipts.md GR1–7、group_receipts_review.md及group_integration_draft.md已PASS。一个source-fixed可数紧支撑光滑partition满足sum m_j=W_full。原sigma下M_j=max_R Pnu_j，是辅助物理最大值，不是新FIRST；endpoint ties优先paid，否则least内部max可测且群自身stationary。令B_j为finite fallback/endpoint/near-one/own-lowtrace。可变群响应Jensen与旧CS强包络给int sup_sigma B_j M_j<=G_n m_j，大维数G_n=2D+T_n+L_n，小维数G_n=J_s=D(1+2nlog4)。G_n=O_A sqrt(n)logn。

原actual合格软行S_j=int k_s eta_j dmu_hi，含原GOOD资格。先付M_j>n S_j，原hardrow一次上限Chq给Ch J_s/n W；再付B_j=1补集给Ch G_n W。无groupcount/J/source-depth费用；旧dPi_H已含一次q^-1，不再重复。定义R_GH=int dPi_H sum_j eta_j(y)1_(M_j<=n S_j)(1−B_j)。它保留原full-hightrace及全部原pair/parent/birth/forest/coin资格，非零群新满足M_j/n<=S_j<=M_j<=q且Phi_j>n(1−sigma)M_j/2的自身内部物理赢家。one-coordinate compact-support collar不等于wholecapture/birth/scalecloseness。

大维数最新整账为

    lambda|E_band|<=P_MM+(128/63)J[A_n+Csq K_s sqrt(n)]W_hi
       +(4/3)(T_n+L_n)W+(128/63)Ch[G_n+J_s/n]W+(128/63)R_GH.

这是替换前一CS账唯一R_H项；旧费用各一次，CS direct output仍4/3，新traffic128/63。有限维仍由原strong envelope直接覆盖。已付仍O(sqrt(n)log²(n+2))W，R_GH仍未付；一般统一指数未改善。

三stage25群(2/6/17)及另行preregistered12boundary controls全独审PASS，main result hash1a260a0483d8a703687d4783d65bd19e1e9742077df3fe0bee115f665d9e3d2e。所有source dims均finite CS regime，22facefree内部+3endpoint ingredients，3amplified；不是保留HMP/fullhightrace/actualGOOD或空间范数实验。20极小near posterior指数下溢但log保留；少量logM−logS有−3.64e−12浮点误差，computedmax非continuum证书。三阶段账与边界控制不替代解析统一阶。


## 21. 原birth-cell平滑内部分割（OP已独审；新具体R_cell,H未付）

high_marked_receipts/own_winner_partition_audit.md OP1–6及review已PASS。这是从原CS R_H选择GR的具体分割的一次替代，不在任意既有R_GH上复制GR费用。原d=a/n birthgrid不换；一次选finite k>=5使w=d2^-k的全格面2w邻域U_w满足int_U f<=W/n。完整L1来源对格面零质量及DCT保证k存在，无统一模/最小质量要求。eta_C compact smooth支持于ONE原C内部，eta_res=1−sumetaC，mres<=W/n，sum mC+mres=W。k及cutoff derivatives不进入已证GR/strong envelope费用。

只分配原soft y，原hard z不变。先付boundary soft traffic<=Ch Js mres<=Ch Js W/n；随后在compact subpartition eta_C上付GR boost Ch Js/n W和ownpaid Ch G_n W，各一次。actual S_C仍含原k_s/GOOD，完整groupnu_C用f而非不光滑f_hi。每群原whole hi H_C=e²q t_C^n/sqrt(n)，t_C无clamp；m_C<=H_C+q sqrt(n)d^n。H_C=0没有原hi交通，不能说m_C=0；unborn softC仍保留，t_C<=b不推出<=R_C/Ls/Rh。

定义R_cell,H=int dPi_H sum_C eta_C(y)1_(M_C<=n S_C)(1−B_C)，保留全部原fullhightrace/CP/far/notLOW/bornhard/parent/coin/seed/两赢家资格，追加原cell质量关系和GR ownhightrace/actualresponse比。大维数最新整账：

    lambda|E_band|<=P_MM+(128/63)J[A_n+Csq K_s sqrt(n)]W_hi
      +(4/3)(T_n+L_n)W+(128/63)Ch[G_n+2Js/n]W+(128/63)R_cell,H.

这是用具体cell partition替代前节GR费，两个Js/n各有不同一次费用；G_n不复制。finite维照旧fullstrong回退，已付仍O(sqrt(n)log²(n+2))W。R_cell,H真正空间费、born与ownphysical尺度耦合仍未证，一般指数未改善。

新3stage6gridrows/318component checks只复用冻结完整来源，精确有理数解释保存JSON十进制数据（非binary位重建），Decimal80乘积；独审另一interval-overlap算法与Decimal100全核，最大差5.62e-76。k28/29、30/31、32/33，最坏n倍fraction .9994354421839888；逐component保守<=1/n条件避免tiny witness质量被floor，非literalleast完整weightedk。原boxes是L1边界算账，不是smooth群/actualFIRST/HIGHTRACE/空间范数样本；两phase分别固定诊断，不保持旧marks的重画格操作。结果hashe6d1369281b24702a8f29c258a3ca2a73583b8f49384b7fbe76f63c9cdc29ffc。


## 22. 固定掩码先验信息尾工具（PI已独审；可选，当前费用不变）

high_marked_cover/pair_information_route.md及pair_information_review.md已PASS。原ks=chi P精确positive mask lift，固定pair/A/L/R的normalized lens为product PRIOR，非sourceposterior。|logphi|沿hardinterval的osc<=10，故centered I_A MGF<=exp(12.5|A|u²)。完整c_A正和保留FULL-H C，无2^n union。原pair-fixed JM两尺度向上ceil网J，maskkernel<=e nodekernel；阈值r=sqrt(50n log_+[2eJ² Ctheta/T_yz])的实际liftedtail列<=T_yz。取原closedmarkCDF T_yz=epsilon q w_y(z)/(S F_y(max(a,ct(z))))，onlyhardborn<=b，sourceTonelli恰付epsilon W_hi。无Ch、无第二q^-1、无残留J²/S。若采用，只替换128/63 R为128/63 epsilon W_hi+128/63 Rcentral；本节作为保留工具，未在当前OP主账加费。

精确mean项log(b_A,L/C_A)=I_A+D(Q_A||uniformhardcube)保留。全hard mask I=0但D=sumlog(R/overlap_i)可在rank-GOOD fixedpair sliver上任意大；该例不是actualFIRST/CP/R_GH/空间counter。中央交通没有coveragefraction或contraction，deterministic Ctheta Fpotential仍在tail阈值内。

3stage54kernel/324MGF/216threshold+6旧完整CWguards已独核，result4dc1a68e19e21ffdbdc4ae559f70543fcc1d10103899d2d5f38cfc50cc1c5fb5。全216positive-log，只是full-octave J算术非实际ceil赢家lookup；zero-log和b=a解析-only。CW均finiteCS且非GOOD/hightrace认证。相对熵sliver为后加解析检查，非已登记新source实验。未改变一般统一指数。


## 23. 实际源点全软度分数尾支付（SST已独审；重排替换OP账）

high_marked_receipts/source_score_truncation.md SST1–6 与 source_score_truncation_review.md 全解析、三阶段及重排审计PASS。真实核先验混合给 Ew_sigma=sigma、Ew_sigma²<=28sigma；t<=1/20时 centered MGF<=exp(3000sigma t²)。该独立性只属核先验。闭带 I_j=[max(1/(4n),s_j/2),s_j]、s_j=2^-j，U_j=1000[sqrt(ns_j log(n+2))+log(n+2)]，t_j=min(.05,U_j/(6000ns_j))。旧CS完整radialBV（含硬face原子）及带内poly softness网格给总实际source-tail列<=e2856000 n^5/(n+2)^25<1/100，所有n>=1。实际score资格在原sigma,L_s,y处，非网格/own/hard参数。

从ORIGINAL CS R_H开始先付actual source-score tail Ch W_hi/100，再OP边界，再ONE GR。令ksgood=ks 1_scoregood，S_Cgood=int ksgood eta_C dmu_hi；完整固定nu_C=f eta_C、M_C、B_C不截断。boundary Ch Js/n W、boost Ch Js/n W、ownpaid Ch G_n W各一次。新余项 R_cell,H,score=int dPi_H 1_scoregood sum_C eta_C(y)1_(M_C<=n S_Cgood)(1−B_C)，保留全部原资格。实际保留y的score<=n sigma+1000[sqrt(2n sigma log(n+2))+log(n+2)]，不能迁移到ownR/hardR。

大维数最新primary整账 REPLACES OP整笔：

    lambda|E_band|<=P_MM+(128/63)J[A_n+Csq K_s sqrt(n)]W_hi
      +(4/3)(T_n+L_n)W
      +(128/63)Ch[(G_n+2Js/n)W+W_hi/100]
      +(128/63)R_cell,H,score.

旧GR/OP费用不能再加；PI仍optional、未另收费。finite维仍fullstrong回退，已付仍O(sqrt(n)log²(n+2))W，余项一般空间费未证，一般统一指数未改善。

三stage61scalar/183tilt/134band/402 labelled ingredient nodes/9总费/18cusp。独审重建8145派生字段与exact rational带网格计数；未重跑原probe。9singleton bands的3标签是相同位置，不是3不同网点；10 below-floor矩行不参与CS5。真实连续E1/E2核、显式正尾，非finite latent混合；quad非interval、无actualFIRST或空间norm实验。结果ee1c980704747ebdf1739784883bdcb3d8ebb7865141d499d616cb254c9769b7，独审71509267ef9f552d5d22f03ffdfbea4ffb24ef993805471a7e65d9838914926f。


## 24. 实际源点分数到原整格出生尺度（BC已独审；软顶端优先）

high_marked_cover/source_score_birth_bridge.md BC1–6及source_score_birth_review.md PASS。真实phi在outside的hazard>=1、phi(r)>=(e−1)e^(-2r)/4，canonical inside psi>=5^(-sigma)。令kappa=(e−1)/4、T=n sigma+U_s，实际scoregood给-logPsi<=B=n sigma log5+2T[1+log(1/kappa)+log1/sigma]。L_s+2d<=b时同原整格WC e7及原complete future cap给H_C<=q L_s^n exp(B+7)，故原未clamp出生t_C<=L_s exp[(B+5+.5logn)/n]。是WHOLE originalhi cell，非eta群质量；ownR/hardR不能替代右侧原Ls。

原floor sigma>=1/(4n)下Gamma_n(sigma)=sigma log5+2[sigma+1000(sqrt(2sigma ell/n)+ell/n)](d0+log1/sigma)+(5+.5logn)/n，ell=log(n+2),d0=1+log1/kappa。uniform Gamma_n^*=log5+2d0+2000sqrt(2ell/n)(d0+2/e)+2000ell/n(d0+log4n)+(5+.5logn)/n。保留softcells t_C<=b exp(Gamma_n^*)，全sigma渐近constantinflation~200.212；只有原floor<=sigma<=c_n/n、辅助序列c_n=n^o(1)才Gamma→0。无belowfloor临界结论，无t<=Ls/Rh/b或born≈ownR，不把radius inflation当免费volume。

原CS R_H依次支付：original softtop Ls>b−2d（4ChD Whi）；SST实际源分数尾（ChWhi/100）；OP边界、ONE GR（Ch(G_n+2Js/n)W）。actualksgood含两个原soft参数/源点gate，固定完整nu_C/M_C/B_C不变。等号Ls=b−2d保留。新精确R_BC=int dPi_H 1_(Ls<=b−2d)1_scoregood sum_Ceta_C1_(M_C<=nS_Cgood)(1−B_C)，全部原资格仍在。

最新大维数整账 REPLACES 先前SST/OP/GR整笔：

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63)Ch[(4D+.01)Whi+(G_n+2Js/n)W]
      +(128/63)R_BC.

softtop是traffic128/63，不是directoutput4/3；没有第二次GR/boost/partition费。有限维原fullstrong回退，已付仍O(sqrt(n)log²n)W。R_BC真实空间费和一般统一指数仍未证；PI保持optional，不另加。

3stage360核行（60belowfloor确定性-only）、144旧完整双源新增点；原两个正logweights、各自q均保留。330scoregood中278eligible（原270仅修文，数据未改）；144点无unbornfixture/continuousFIRST。独审9592派生字段、保存binary端点的exact Fraction格交、dyadic索引与source复用；未重跑quad。belowfloor tinyinside logpsi可舍入0；闭面padding独立无消去式差至多2.87e−8，已小于1e−6执行容差，保存negative margin非interval证书。result f60eb2afb3cceb861027210f2eb65cfda5f787cdf213b14e2cfa9af0f9df982f。OU/OS双侧own尺度桥正在另审，尚未作本账premise。


## 25. 自身分数支付与双侧尺度桥（OS+OU已独审；R_scale未付）

signed_band_probability/own_score_scale_bridge.md及review，high_marked_cover/own_soft_scale_upper.md及review均PASS；OS review §7审过BC组合草稿。开始于accepted R_BC，固定完整nu_C/M_C/R_C/B_C与actual S_Cgood不变，不再做GR。先付own R_C>b−2d群<=4ChD W；再定义NEW own Qtail_C=int P_(sigma,R_C)nu_C 1_scoretail，以SST真正全参数sourcecolumn Delta_n<.01付 Qtail_C>=M_C/2群<=2ChDelta_n W。不是将原Ls scoregate搬到ownR；余群有正own-scoregood完整响应，等号half属paid，R_C=b−2d保留。

own-good v +samecell WC R_C+2d<=b，使用OWN MAXIMUM（不是原future）得m_C<=M_C R_C^n e^(B+7)。actual S_Cgood<=m_C Ls^-n与M_C<=nS_Cgood给lower R_C>=Ls exp[-(B+7+logn)/n]。另一方面原scoregood y+原Ls padding对全nu_C给M_C>=m_C Ls^-n e^(-B-7)，psi<=1给M_C<=m_C R_C^-n，从而upper R_C<=Ls exp[(B+7)/n]。同原sigma/同SST带阈值T使B=B(sigma,T)一致，两个合格源点不必相同。上侧本身对所有maximizers含endpoint ties成立，不需q/boost；下侧用的是新付费补集。完整group masscap不冒充wholecell HC。

保留ownhightrace且sigma<1给某ownface supportpoint，因此每个原C点都有一坐标在原Ls相对collar [.5e^(-gamma_minus)−d/Ls,.5e^(gamma_plus)+d/Ls]，gamma_plus=(B+7)/n,gamma_minus=(B+7+logn)/n。正下端时Omega=log[(e^gamma_plus+2d/Ls)/(e^-gamma_minus−2d/Ls)]，原GOOD把该单个位移的候选坐标数界为min(n,(k−1)(1+ceil(nOmega)))；下端非正只用n。这不是跨群occupancy、spatialWfee、wholecapture或核替换。

新精确R_scale是原R_BC群交通附加R_C<=b−2d与Qtail_C<M_C/2。最新大维数primary账：

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63)Ch[(4D+.01)Whi+(G_n+2Js/n+4D+2Delta_n)W]
      +(128/63)R_scale.

原Ls顶端与ownR顶端是不同prioritybranches，分别Whi与completeW；旧OP/boost/ownpaid GR各一次。每个newtraffic128/63，CSdirectoutput4/3。finitefallback不变，已付O(sqrt(n)log²n)W；R_scale目标空间费与一般指数未证。只有原floor与n sigma=O(logn)合用才gamma=O(log²n/n)；一般floor<=sigma<=c_n/n,c_n=n^o仅o(1)。即使窄范围的e^O(log²n)体积损失也不是polylog。

OS3stage1080conditional kernel/scale+60half-tail+10collar，990good/834floor-good/745conditionally feasible；不是实际群max/FIRST/空间实验。独审20415字段；216closedface消去差<=2.87e−8，30savedpositivepadding最大2.39e−8<tolerance1e−6，符号由解析WC给。运行早期失败只有摘要history，非完整旧脚本归档。OU3stage144完整mass1单格box/36belowfloor，独审2934字段；32/64/128 mixture Gauss+8point source平均+含paddedscale有限物理screen，非truecontinuousmax/ownhightrace/actualFIRST证明。OS result18b1483d04e63a10b10ae005154245c0b9fc5982f3655e863d9de73f39189c24，OU resultb6065ec2bf66d0d4041f687bcbd3cd46672a63ac2342c03bc515b0c306033c1c。


## 26. 带内正掩码分配（SB已独审工具；INC未证，主账不变）

high_marked_cover/scale_bridge_spatial_route.md SB4–9与scale_bridge_spatial_review.md PASS。单固定闭band I=[u,v],0<u<=v<=1,v<=2u：c_A=max_I a_A，D_I=sumc_A，theta_A=c_A/D_I，mu_CA=theta_A mu_hi|C。sum_A mu_CA=mu_C，actual a_A b_A mu_C=(a_A/theta_A)b_A mu_CA，ratio<=D_I；zero theta必zeroactual，sigma1 positiveallocation/zeroactual合法。群nu/M/RC、原FIRST和hardbirth全不改。

Bernoulli系数正变差给D_I<=1+sqrt(n)(asin sqrtv−asin sqrtu)；critical v<=2C/n<=.5时<=1+2sqrtC，全sigma不能设1。每个band份额总mass仍Whi，跨band复用显式计费。实际mask含所有outside O(k)，m>=k，c_A<=v^m<=(2sigma)^m，从而wholeallocatedcell H_CA/(qLs^n)<=exp[7+nσlog5+klog1/kappa+2Rout]2^m sigma^(m−k)/D_I。消去sigma^-k但不消去radialinverse、2^m、D或各向异性几何；int e^(2r)phi(r)=infinity，原hardbirth不能换成maskedbirth。

唯一尚未证明的空间接口：source-fixed V_CA允许共享coveratoms/parentgroup，union U_I需|U_I|<=K_I sqrt(n)Whi/q；actual original lifted uncovered traffic<=eta_I R_I。原两rowcap才给R_I<=Ch K_I sqrt(n)Whi/(1−eta_I)。sum_CA volumes只是更强OPTIONAL充分条件；目标还需sum_I K_I/(1−eta_I)=n^o。不假uniformpercell occupancy，不把prior标签概率/label空间体积当实际incidence或x投影。连续density不是参数化不变mass，按同权分配q可能抵消mass收益。INC-a/b与sum均未证，CAPACITY§13/CURRENT§25主账保持，无新W费/新一般指数。

三stage42band、全262850sizecoeff，独审重构并匹配42arrayhash。2559positiveallocationcontrols、51zeroalloczeroactual，另117positivealloczeroactual。lgamma独立和误差logD1.30e−11/selectedfields5.43e−10<tolerance1e−7。serialization repair前登记、diff仅zero -inf→null+flag，未改输入/容差或加positivefloor。result6851d0d16140c9e94e9730a40b9cff6f8ab3af0ab009170aaa9e9438fc11b1e0。仅算术/系数，不是sourceFIRST或coverage实验。


## 27. 原格群联合弱包络的实际响应截层支付（LV已独审；R_tiny未付）

high_marked_cover/shared_cover_level_receipt.md LV1–6及shared_cover_level_review.md PASS；root已全文核对。固定原OP完整群nu_C=f eta_C、side d=a/n、center cC、sum mC<=W。epsilon1/(2n)把每个even decreasing factor变为b^epsilon(t)=b((|t|−epsilon)_+)；full-softness系数包络H^epsilon质量<=eD。每个R>=a、所有sigma、v∈C均有P_(sigma,R)(x−v)<=R^-n H^epsilon((x−cC)/R)。

沿射线单调的G满足A(theta)=sup_t t^nG(t theta)<=n int t^(n−1)G(t theta)dt。齐次Z_C=mC sup_(R>0)R^-nG((x−cC)/R)因此u|{Z_C>u}|<=eD mC，零质量Z=0，径向有理数从下逼近保证可测。这个全参数弱包络支配原M_C，不是强L1列。

只在ORIGINAL fullfuture cap有效输出上M_C<=q。任意固定0<tau<1，layercake精确给int_E M_C1_(M_C>=tau q)<=eD mC[1+log(1/tau)]，包括低阈值等号及Z>q的cap区。原pair/forest/band唯一分配总权重<=1在hardrow前合并，actualS_Cgood<=M_C与原Chq/唯一q^-1给实际交通

    R_level<=Ch eD[1+log(1/tau)]W_full.

一次OP partition，不按mask/band/forest/group数复制W。所有原FIRST/两winner/硬出生/GOOD/score/ownfullhightrace/parent/coins/CP/far/notLOW/双侧scale资格均留在原traffic；包络仅用于上界，不重选实际核。

定义R_tiny(tau)为原R_scale添加分配群M_C<tau q的精确补集。最新primary整账仅替换CAPACITY §13唯一余项：

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63)Ch[(4D+.01)Whi
        +(G_n+2Js/n+4D+2Delta_n+eD[1+log(1/tau)])W]
      +(128/63)R_tiny(tau).

选择tau=exp[−log²(n+2)]，已付仍O(sqrt(n)log²(n+2))W。旧费各一次，无第二GR；新费128/63，非directoutput4/3。finite n原完整strongfallback不变。每个实际余群仍有0<M_C/n<=S_Cgood<=M_C<tau q，因此仅对同输出余群求和sumM_C<=nq；已付群不保证nonboost。

R_tiny合作空间费尚未证明。弱列直接取union损失tau^-1，所有微小层无限相加可能产生不可控来源熵；不能据此宣称收缩、共享覆盖或目标端点。一般统一指数仍未改善，无条件基线O(n log n)。

三stage固定n8/64/512、实验tau=n^-2：3mass/144完整正cellbox比较/9ray/45layercontrols，25hardzero保留。独审28859字段，最大归一化差5.77e−14<1e−7，非独立重复求积。有限raymax/截断quad不认证完整ray积分/真实连续核，layer是齐次算术，不是actualFIRST/ownhightrace/空间norm样本。解析任意tau结论允许上述最终选择无需为指数拟合重跑。结果95ca43027cdfff2cb7cdbbb68f9655c8e67567ca18810991bd5740f6aa5c54ac。


## 28. 固定软度接触梯度工具（GC独审及集成草稿PASS，零费用）

high_marked_cover/group_contact_gradient_route.md/review与group_gradient_integration_review.md已PASS。main追加相应完整工具节；primary仍CAPACITY§14/CURRENT§27的R_tiny账，不增加任何费用。

n>=4、完整smooth群支撑原side a/n cell。own硬面接触坐标x_i在整格外，soft常规与hard空间导数同号，|∂xiF|>=2Phi_i/R。一个原actual homogeneousGOOD y限制owncontact坐标j<=K_n=min(n,6(k−1))，因为n log[(R+2d)/(R−2d)]<=4log3<5。固定s最大M在可微点每个tiedmax共享gradient，ownhightrace给|∂xM|>n(1−s)M/(R√K_n)。仅fixeds a.e，不从ambient null删actualσ图。

真实interiorownstationarity Phi+Sreg=nM且Sreg>=0；|phi'/phi|<=5给上界(2n+5√n)M/R，不含cutoff导数。只有同输出余群M<tau q、nonboost与原partition才ΣM<=nq并Σ|∂xM|²<=(2n+5√n)²n tau q²/a²；不是随机一致集中或source-W空间费。

实际合法regular图导数为∂xM+M_s∇sigma；fullFIRST q接触/物理驻点/F_full,s≠0才给∇sigma=−∂xF_full/F_full,s，可能coherent抵消。该逻辑障碍不冒称actual残余反例。fixeds coarea切片需明确ownhightrace/GOOD且M(s,x)<=q（不能从原movingcap自动得），右端真实levelsurface面积、movingprojection、异常trace、multiplicity全未付；s1 positivehard分支空。

3stage440fixedR普通jet(36positivePhi)、144独立压缩GOODgeometry、36rawboxendpointskip；独审6002保存字段误差0，未独立重算quad。不是smoothownmax/原FIRST/空间norm样本，GCstationarity/投影全是解析工具。results56c365f9c88141c51de5a267dade0216932562a9dd91e9c1005a8a255eae31dd。


## 29. 一个固定粗块的局部合作支付（TG已独审；整笔替换LV，R_block未付）

tiny_group_geometry_receipt.md TG1–4及review PASS，root已全文读；TG5仅条件工具，optional粗顶端条带未入账。一个与原side d=a/n grid对齐的整数h粗partition，block B side ell=ha/n，nu_B=Σ_{C⊂B}nu_C、mB=ΣmC，ΣmB<=W。原完整未来cap给原σ处M_B=max_[a,b]Pnu_B<=q；所有原fine nu_C/M_C/R_C/GR与oldsource/pairgate不变，不给粗群新FIRST/stationarity/hightrace。正性M_B>=M_C、Σ_C⊂B S_Cgood<=P_Ls nu_B<=M_B。

coarsepadding eps=h/(2n) full-H质量<=K_(n,h)=D(1+h/n)^n<=e^hD；沿ray弱包络Z_B>=M_B且u|Z_B>u|<=K mB。与LV相同的原qualified截层+唯一hardrow/一次q^-1给真实实际交通R_coarse,paid<=Ch K_(n,h)[1+log1/tau]W。只有ONE sourcepartition，不乘h^n、mask/band/forestlevel数。同tau下coarsepaid包含finepaid，因此整笔从R_scale替换LV，不另收fine费或所有中间层费。

固定h_n=ceil(4loglog(n+e^e))、tau=exp[−log²(n+2)]，e^h<=e log^4(n+e^e)。定义R_block为原R_scale的分配traffic增加M_{B(y)}(x,σ(x))<tau q，全部原细格与pair资格保留。最新primary整账替换CAPACITY§14的整个LVpair：

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63)Ch[(4D+.01)Whi
        +(G_n+2Js/n+4D+2Delta_n+K_(n,h_n)[1+log(1/tau)])W]
      +(128/63)R_block.

旧费用各一次；新fee128/63，非CSdirect4/3。已付O(sqrt(n)log^6(n+2))W，finitefallback不变。R_block⊂R_tiny(同tau)但反向不成立；每个实际余finegroup仍0<M_C/n<=S_Cgood<=M_C<tau q，仅这些余finegroups可ΣM_C<=nq。不能声称M_B<=nΣsurvivingS_C，因为完整block可含已付finegroups。

实际scoregoodpoint y∈B、原核lower Ls^-n e^-Bscore、额外Ls+2ell<=b时，对所有v∈B的WC给P_(σ,Ls+2ell)(x−v)>=e^-7h P_(σ,Ls)(x−y)，损失5n ell/(Ls+2ell)+nlog(1+2ell/Ls)<=7h。故mB<tau q Ls^n e^(Bscore+7h)。仅nu_B完整群质量，非原wholehi H_C/硬birth；原finepadding不蕴含coarsepadding，未免费删条带，optional D(1+4h)粗top费不含在上账。Bscore可O(n)，不推moderatepotential/空间费。

三stage n8/64/512，h5/6/8；3mass36completepositivecoarsebox288padding。tensor保留全部h^n cells各massh^-n；source mass1/q1，所有σ,R>=1 kernelheight<=1给真全futurecap。finealltiny/criticalparentlarge得到实际正source cooperation压力，不认证原FIRST/hardband/ownhightrace/远HMP。192paddingeligible（n8零个），36oldhardzero，closedface用exactidentity。独审17352字段，maxnormalized1.14e−13，非重跑quad/空间norm。results62d65673fd6f3fc6b9b5c801b4b6788428bebe2ed65202bca7ed06c21657f17b。

大量不同粗块的合作仍未付；不能把h增至物理尺度h~n而不收exp(Theta(n))，不能声称覆盖率/收缩。全一般指数仍未改善，无条件O(n log n)基线不变。LV仍作为独立较小fee/较大residual的alternative，不与本节wholeledger相加。


## 30. 原整格来源平衡与 eligible-GOOD 阴影（SBL独审PASS）

从当前R_block作正的按序分解。原OP固定 j_C=int eta_C dmuhi、r_C=H_C-j_C，sum r_C<=W/n。来源BAD iff H_C>2j_C，等号与H0为GOOD；这与角度GOOD不同。sum_BAD j_C<=W/n，sum_BAD H_C<=2W/n，GOOD原whole H_C<=2j_C<=2m_C；只比较质量，不能作measure domination，原raw t_C不改。

当前postOP依次支付bad assignedsoft Ch Js W/n、remainingbad wholehard 2NhW/n。再固定原forest seed，沿原E_b={t_C<=b}分原h(P)=hg(P)+hb(P)，选positiveh且hb>=hg的coarsest/maximal节点Q。判据可非monotone，但有限层保证selectedQ为disjoint antichain。sourcefixed shadow=muhi restricted to E_b∩GOODcells∩unionQ，mass=sumhg(Q)<=sumhb(Q)<=2W/n。任何bad-dominated原父P的good actualhard endpoint落在该影子。原softrow与hardstrongcolumn支付2NhW/n，先合并唯一原pair/forest权重再作行估计，对probability-one seeds平均无J。

精确R_balblock为R_block排除上述badsoft、badhard、per-seed eligible-GOOD shadowhard后的交通；原h/threshold/coins/parent/mark/来源/全部旧门保持。剩余实际parent hb<hg，h<2hg，因此oldheavy h>T推出hg>T/2，是支付后的推论；hg仍eligible来源质量，非capture。

    R_block<= (Ch Js+4Nh)W/n +R_balblock.

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63){Ch[(4D+.01)Whi
        +(G_n+3Js/n+4D+2Delta_n+K_(n,h_n)[1+log(1/tau)])W]
        +(4Nh/n)W}
      +(128/63)R_balblock.

本节postOP新fee仅第三份Js/n与4Nh/n，后者不乘Ch；旧OPboundary/GRboost保持各一次，无第二GR。preOP备选(2ChJs+4Nh)W/n包含替换oldboundary，不能叠加。已付总阶仍O(sqrt(n)log^6(n+2))W，原finitefallback保留。R_balblock空间合作未付，目标及一般指数仍未证，unconditional O(n log n)不变。

任固定coarse B有H_good(B)<=2mB；仅在TG5的实际scoregood及额外Ls+2ell<=b成立时得H_good(B)<2tau qLs^n exp(Bscore+7h)。不是免费加coarsepadding，Bscore仍可能O(n)，block外势未付。

三阶段9完整positivefamilies/168cells/174components，OP0/1支撑原边界质量恰1/n，3864 DISTINCT orderedcellpairs（无diagonal）、94shadowcaptures、232remainingparentcomparisons、6antichainnodes。zeroown保留原positivehard，bornendpoint与GOOD equality保留。原L1 rawboxes全部hi；平滑可保持complete masses/eta support，但sameq的hi/H/birth一般改变。records是source/tree算账，不是FIRST/ownhightrace/空间norm证书。独立重建34890字段，maxnormalized7.13e-80，不重跑kernel。results b788216b25fe895cc3bc4b6fe75232b0fea8ebeee5cb6379c0737785762ce176；review source_balance_review.md SHA6bd7acefa03c8d4e8ee5308ccdff086cf41bcfeec9d0a4b07b6af40f83b99c7d，root全文读并核draft。


## 31. 双端时钟、完整共同来源币场及原资格传输（TP独审PASS）

TP1–10及proof/data review PASS，root全文读；root integration draft在soft网格显式限定s>=原sigma后独审PASS。当前n>=4、sigma>=1/(4n)、b2a、d=a/n。原完整f同时有future soft capq和wholeoctave hardcapChq，后者来自originalhardband。MM2已付Rh>b−2d OUTPUTS，E_int及当前全部子余项继承Rh+2d<=b，本节不另收standalone3Whi。

一次完整sourcepartition mu_C=f1_C，F_C=intmu_C，sumF=W_full；softfutureclock mathsfH_C=sup_(s>=sigma,R∈[a,b])Pmu_C，hardclock mathsfK_C=max_R hRmu_C，fixedweakconstants eD F_C/eF_C；E上H<=q,K<=Chq。与originalwholehi H_C区别命名。原OPnu_C是保留子测度。ell=log(n+2),tau=exp(-ell²),A=1000ell,eta=1/A,p=min(.25,tau A²),us=eta pq,uh=eta pq/sqrt(n)。fine actualSCgood<=MC<tauq仍成立。

从R_balblock顺序删除softH>=us、softK>=uh、hardK>=uh、remaininghardH>=us，四项实际交通fee分别Ch eD tau/(eta p)W、Ch e tau sqrt(n)/(eta p)W、e[1+log(Ch sqrt(n)/(eta p))]W、eD/sqrt(n)W。第三项无额外Ch，第四项必须在Ksmall后；both actual endpoint cells必须bothclockssmall。旧pair/seed权重先合并，只有一个q^-1。

sourcefixed iid Bernoulli(p) xi_C共用于所有x，fomega=sumxi_C f1_C，E mass=pW。combinedghost B(x)为任一selectedcell任一clocklarge。q intP(B)<=e(D+sqrt(n))W/eta，Ebad={P(B)>=1/4}满足q|Ebad|<=4e(D+sqrt(n))W/eta。本文选traffic4Ch e(D+sqrt(n))W/eta；directoutput16/3 e(D+sqrt(n))W/eta可替代，但不叠加、不乘traffic128/63。

闭soft网格[1/(4n),1] ceil(10n²(1−1/(4n)))intervals，仅测试s>=原sigma的futureeligible节点；hardphysical loggrid[a,b]ceil(nlog2)intervals全测试。upwardrounding保future、closedendpoints；softlogderivative<=5n²、loss e^.5，physical<=e，合计<5。概率计算仅restrictrow-dependentbothsmallfamily，不能据此定义sourcebudget；noghost时等于fullsample。强制至多2个distinct端点，softmean<=(1+2eta)pq,var<=eta p²q²，hardmean<=(Ch+2eta)pq,var<=Ch eta p²q²。阈值4pq/4(Ch+1)pq、combinednodes<=22n³给delta<=22n³exp(-6/(5eta))<1/16。Ebad外条件G成功>=1/2；differentcell inclusionp²，同格只一coin inclusionp>=p²，故E xi_y xi_z 1G>=p²/2。G上wholefuture<=32pq,hardmax<=32(Ch+1)pq；没有所有x同时成功或sourceposteriorindependence。

已继承hardpadding下actualcapturedz∈C使wholeC被Rh+2d捕获，Ksmall推出F_C<=e²eta pq Rh^n/sqrt(n)。selectedcell新hi H'_C<=F_C，raw unclamped t'=(H'_Csqrt(n)/(e²pq))^(1/n)<=eta^(1/n)Rh；zero0，max(a,t')只是auxiliaryfloor。只断言actualhardendpoint。sourcefixedsmooth chi_C,eps=1 on suppeta_C，0<=chi<=1，chi↑1_C a.e.，同OPinner margin给统一eps；smoothg<=fomega并exactly包含oldselectednu_C，caps/birth保持，chi1旧hi在pq√n更低cut仍hi，hardregions穷尽模source-nullfaces，MCT/DCT恢复traffic不收derivativefee，不造newFIRST。

    U_n=e{Ch(D+sqrt(n))tau/(eta p)
           +1+log(Ch sqrt(n)/(eta p))+D/sqrt(n)
           +4Ch(D+sqrt(n))/eta}.
    R_balblock<=U_n W+R_clock.

R_clock精确保留四项clock删除及Ebad之外的oldR_balblock，全旧fixedsource/mark/FIRST/winners/ownhightrace/score/GOOD/parent/forest/coins/far/notLOW/scale等全部gates不变。当前唯一primary整账是：

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63){Ch[(4D+.01)Whi
        +(G_n+3Js/n+4D+2Delta_n+K_(n,h_n)[1+log(1/tau)])W]
        +(4Nh/n+U_n)W}
      +(128/63)R_clock.

U含e，在Ch大括号之外；只加一次128/63U_nW，旧费各一次，不叠soft-onlyTP/OP/GR/MM2硬top。uncapped tau/(eta p)=1/A，log1/p=ell²−2logA；capped只ell<5有限维。U=O(sqrt(n)log²n)，所有已付仍O(sqrt(n)log^6(n+2))W，oldfinitefallback保留。

令A(x,y,z)为R_clock的全部原gate/weights及新deterministicdeletions，Tomega=(pq)^−1 int1G xi_Cy xi_Cz A P_(原sigma,原Ls) h_(原Rh) dmuhi(y)dmuhi(z)dx，包括oldseed平均。Tonelli/Palm给R_clock<=2/p E Tomega。oldselectednu_C/oldownR/hightrace原样保留，但newFIRST/newparent/weights/newlowhi不自动获得。只有另证Tomega<=C(n)||fomega||才得2C(n)W；当前该HIGH空间fee未证，expectedpW与恢复1/p抵消，无收缩/新一般指数。unconditional O(n log n)仍唯一一般基线。

soft三stage9param/324Palm/18compressedfiniteBinomial/108net；hard另注册3stage9param/2430dualPalm(243same)/81conditionalbirth/27layer。54bothsmallcontrol仍需Ebad外，2376forcedfailure保留。巨整数和极小概率Decimal/log无floors，一次hardexponentrange修复保parameters。独审14769字段：maxabsolute约1.03e−672，relative1仅接近0被有限精度舍去项，非interval/exactzero证书；未重跑作者实验。数组不联合认证actualFIRST/HIGH/tiny完整source或空间norm。softresult f2f9d474736b12b87a9ee01fa5eec804c6e9d4695c6e946757993c6a69589f1d；hardresult870fa04d5ec051a187489c7b186503561b902d78e22b08e48d4e779e952e47c9。proof/data review97a98476d67f349f9cc88caa8fc11e922fcb7db68284397968a5088532203a17；draftcorrespondencereview cf4bb8fcf17a2d3e4f9e1252dc57ca7e655fabc92b7d9642bfe0e8a514a3135f。

sampling_closure_obstruction.md记录确切p/层权抵消与response-shell非sourcepartition；齐次全尺度Z每log层收费κm log2，仅否定该包络无限求和推论，非实际FIRST反例。该诊断不另产生费用。继续目标是实际空间共享覆盖/合作预算，不是把现有随机传输改名闭合。


GP解析、完整来源层级及另行登记的闭端点修复均已通过独审；本节替换上一主账余项。

## 32. 按两尺度几何平均支付完整父组（GP独审PASS）

保留原mu_hi、q、FIRST、两实际赢家、原birth eligibility B={t_C<=b}、原森林种子与唯一LCA父组P。M(P)=mu_hi(P)，h(P)=mu_hi(P∩B)均为来源固定的完整质量；实际OP软子源不超过mu_hi。原完整正系数包络H质量D，且D<=1+pi sqrt(n)/2。H沿射线递减。

r=sqrt(L_s R_h)。当L_s<=R_h，原核乘积由r^(-2n)H((x-y)/r)控制；反序由r^(-2n)h((x-z)/r)控制，两中心不合并。HS径向层蛋糕p=1给源对空间列上界2(D+1)rho^(-n)。取rho_P=max(a,(h(P)/q)^(1/n))，在闭分支h(P)<=q(L_s R_h)^(n/2)上，完整parent交通不超过2(D+1)M(P)。h=0无硬端，rho>b为空，rho=b保留闭端点。每个原parent层ΣM=W_hi，J层和种子平均只得2(D+1)J W_hi，无额外深度或源对复制。

将此分支在当前R_clock内最后优先删除，定义R_geom为全部旧gate/weight加严格h(P)>q(L_s R_h)^(n/2)的补集。于是

    R_clock<=2(D+1)J W_hi+R_geom.

旧CP_sigma重质量条件同时保留，不以GP重算原来源/时钟/自群性质；旧费用均一次。当前唯一primary账为

    lambda|Eband|<=P_MM+(128/63)J[A_n+Csq Ks sqrt(n)+2(D+1)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63){Ch[(4D+.01)Whi
        +(G_n+3Js/n+4D+2Delta_n+K_(n,h_n)[1+log(1/tau)])W]
        +(4Nh/n+U_n)W}
      +(128/63)R_geom.

所有符号、tau、h_n、TP币参数及finite fallback沿用上一主账。新费用是traffic而非directlambda输出，128/63只乘一次。已付总阶仍O(sqrt(n)log^6(n+2))W，R_geom仍未付；一般目标未证明，无条件一般基线仍O(nlogn)。NS替代抽样、ON及其spatial工具不同时加入本primary费用。

GP与CP分支非嵌套；阈值比为(max/min)^(n/2)v_j/sqrt(n)。优先删旧CP再删GP保证覆盖与不重复计费。有限源/核/树算术记录不认证实际FIRST、高迹余项或完整空间范数；一般结论依赖解析证明。


## 33. 共同早期退出与常数临界存活的完整输出账（已独审接入）

从原 GP 完整账出发，B_paid 指其全部已付项。固定原 fine cell C、原初始 y 标签和参考 b，t<=1/2 上的共同正比较过程 zeta'=(2B_t-nI)zeta/(1-t) 同时支配各 L 的 actual killed live。B_t=Σ_i1_C G_(1-t,b)^i1_C，||B_t||<=8。完整来源质量 m_C 给 ||zeta_t||<= (1-t)^(n-16)m_C，一份共同 labelled early exit measure barκ_C=2E_(t,b)zeta_t dt 支配所有 L 的实际 first-exit，且Σ||barκ_C||<=3W。初始y、oldpointgates、q、两winner、birth、owntrace、forest/LCA、clock、CP/GP等不在新位置重判。

对原s>=1/2，在1/2截断Duhamel。整个late部分（后续live+lateexit）由K_(s,1/2),L zeta_(1/2)支配。其joint(s,L)强列<=Nh D_n2^(-n+16)m_C。合并原唯一pair/seed权重后dropgates，用原hardrow Chq和一次q^-1，付

    V_nW, V_n=Ch Nh D_n2^(-n+16).

n>=32时Nh<=n、D_n<=2sqrt(n)、n2^(-n+16)<=1/2048，所以V_n<=Ch sqrt(n)/1024。此费用外层仅128/63一次。

对s<1/2，保留actual killed live与earlyexit。NL actual指数n-8在s>=12/n时给live行<=e²Chq e^-9；交通行<=Ch²e^-7q。定义R_live,<为s<12/n的原labelled live交通；定义R_exit,early^act为所有s的实际early交通(0<=t<=min(s,1/2))，保留原各L实际κ及原y,z全gate和原hardkernel，不先扩大。于是

    R_geom<=V_nW+Ch²e^-7 q|Eband|+R_live,<+R_exit,early^act.

这个输出吸收只用于完整Eband账，R_geom自身没有cq行下界。q<=lambda、Ch16/3给alpha=(128/63)Ch²e^-7<27/448<1/16（e>8/3有理认证），从而新的完整账为

    lambda|Eband| <=(16/15){P_MM
      +(128/63)J[A_n+Csq Ks sqrt(n)+2(D+1)]Whi
      +(4/3)(T_n+L_n)W
      +(128/63){Ch[(4D+.01)Whi
        +(G_n+3Js/n+4D+2Delta_n+K_(n,h_n)[1+log(1/tau)])W]
        +(4Nh/n+U_n+V_n)W}
      +(128/63)(R_live,<+R_exit,early^act)}.

V_n放在外层Ch括号之外，因为其定义已含Ch。所有旧paid（包括P_MM、direct4/3项、GPfee）与新余项整体统一乘一次16/15。不是逐阶段或逐深度重乘；原finite fallback维持。所有旧TP参数、tau,h_n,U_n原封保留，不叠NS alternative。已付阶仍O(sqrt(n)log^6(n+2))W。

主账中的R_exit,early^act是原正Duhamel分解的实际子交通，逐点核<=原P，因此保留原row和自群的正上包络。共同来源另给可选R_exit,early^act<=barR_exit；后者才是正扩大，而非等同原R_geom。完整h_L*K_(s,t),L仍使用原输出选择和原初始y标签。只有使用barκ扩大时，新的响应不自动<=q，也不自动有旧MC、owntrace、nonboost或score的点核上界；保留gate名字不能转移这些估计。Σbarκ<=3W不支付空间列，通用强包络仍NhD_n。

R_live,<及R_exit,early^act均未付；一般目标仍未证明，无条件一般基线O(nlogn)不变。旧GP整账仍作为备选保留。主账不要求新landing继承oldFIRST，也不将可选bar扩大误作精确分解。

NE正式稿53ef5eb5ad3313c6a5965faf376f0057b1b1316395f01e86ce61945794cfea37；独审a19d1c5ac7a532de995a3b9e813eb4c06fd2f9ed95ba44e5eaf624a9ee7e8454及接入预审b19c43ae17875afe2456af68a8ca083ea7fa6bc3432edcfbc45cc4e5fd82975a均已全文核读。三阶段432核/135有限演化/720比/45端点/9系数/9费用/6完整来源；独审9440派生字段及32489系数max5.332e-12。没有重跑raw矩阵，不是连续路径、FIRST或空间norm证书。无未披露修复。旧GP保留，当前新主账余项为critical LIVE与actual EARLY。


## 34. 临界 LIVE 内部跳跃的固定小来源（CJ，已独审接入）

n>=512,T12/n，eta_s,L−(1−s)^n nu_C是实际至少一次内部跳跃且尚未退出的正路径子源，逐初始y、所有s<=T和L同时由固定χ_C=∫0^T2(1−t)^(-n−1)B_tζ_tdt支配。||χ_C||<=[(1−T)^−16−1]m_C<=384m_C/n。Nh<=n，一次完整来源预算给真实强空间费384W，mixed为384ChW（已含Ch，外层128/63一次）。

用该费替换上一NE的critical LIVE，当前完整账为

    lambda|Eband| <= (16/15){B_paid+(128/63)(V_n+384Ch)W
                         +(128/63)(R_nojump,<+R_exit,early^act)}.

B_paid是旧GP全部已付项；V_n=Ch NhDn2^(-n+16)已经含Ch；所有旧费用及新余项统一乘16/15，不叠第二个吸收。R_nojump,<为原nsigma<12上的c_sigma^n h_Ls，保留原initialy/hardz及所有gate。actual early含所有softness，不能把共享barκ当继承旧row上界。小维数使用既有fallback。已付阶仍O(sqrt(n)log^6(n+2))W，两余项未付，整体目标未证明。NJ尚待审，不在此删除nojump。

CJ正式d4a816c74d348774248ceb19bc083b61bbcd7843e2d3c4c261ad369896a9f4d1；独审08f1f758c038cd6eb4a8a5ea2cb3c58943e975192290a14e3d345effcabd1939全文已核。4484保存派生/范围/provenance独立检查max1.602e-16，不复跑raw矩阵/求积。三阶段288核/90正内部路径/11边界预算/6完整source。just-below门槛注册但未执行，原文scopefix已明确，保留before_scope_fix；不能以NE旧门槛冒充CJ新检查。有限矩阵不是连续路径/FIRST空间norm证书。短转录critical_jump_integration_draft.tex SHA2ac33c65fa93850df5e75f1285d9c96cd9b69509ec967b842c4b680548faaa81已独审对应PASS，接入只改候选状态标题；不改数学。


## 35. 原完整硬带剔除 no-jump（NJ，已独审接入）

原a0=phi(.5)>3/8，原complete future在硬赢家Rh给b_sigma^nG0<=q<G0/2，凹性给theta=(c/b)^n<2^(-3/5)<2/3。full nojump响应<2q/3；原softGOODhi>=3q/4因而jumpGOODhi>=q/12，hardGOODhi>=7q/4，初始back64/7=9*(64/63)。原输出删除及全source/gate/winner/score/clock不重算，旧正链逐项单调复用。它不是从旧黑箱直接缩余项。

J=P−c^nh。乘w_J只用于旧positive receipt复用；实际删除no-jump须重写正路径：s<.5为LIVE−c^nnu + actualearly，s>=.5为actualearly+完整late减其确切no-jump。CJ付临界非零LIVE，NE付完整late的上界，coarse LIVE仍原NL占用。新九倍回代使alpha变9alpha<9/16，整账吸收16/7。

当前n>=512完整primary：

    lambda|Eband| <= (144/7){B_GP+(128/63)(V_n+384Ch)W
                                +(128/63)R_exit,early^act}.

B_GP明确为NE吸收之前GP§18/§32全部paid，不包含NE/CJ的V/384及16/15。144/7=9*16/7；不能叠旧16/15。V_n=Ch NhDn2^(-n+16)、384Ch均已含Ch，内128/63一次，外144/7统一包含P_MM/direct4/3等旧所有费用。旧GP/NE/CJ账保留alternative不加总。actualearly保留原x,y,z全部门限、原σ,L,R、t<=min(σ,.5)，没有先变barκ；其空间费仍未证。已付阶O(sqrt(n)log^6(n+2))W不变，不代表目标完成；有限n回既有fallback。

解析与完整旧收据重放formal5ad10002089cdf766a59737a1452db44ccdb43411b9e52eb7723554530c64096，转录conditional对应d5614c4de652a071c088df24fbd048fb171d0dcbd3f816a8b4ed61e2ab265908；数值终审已PASS并root全文核读后接入。新三stage72完整tensorbox/1152future/576点核/216条件GOOD/288操作区分/30controls，results2dc1405e028860df301ec05575664d064592fcc1d51fe58c233c967f87b89e51。19177独立派生/profile/闭式原函数检查和548设计/历史检查，不复跑作者probe/旧实验。box精确来源在x0连续FIRST有解析证书，保存sigma仅quad近似，不是GOOD/OP/current/正体积输出/空间norm认证。两条s=.5控制theta下溢非exact0；s1nojump0才exact。parse及summarymetadata失败历史保留，登记/门槛/容差不变。


## 36. 早期退出前有内部跳跃的小来源费用（EI，已独审接入）

原actual killed eta与common ζ有相同zero-internal项c_t^nν_C，逐初始y正Dyson删除该项给eta_int<=ζ_int。共同barκint=2E_(t,b)(ζ_t−c_t^nν_C)dt同时allL支配actual首次早退出之前至少一次internaljump的路径。它是fixed source-time domination，不是comparison的概率退出律。mass<=2n∫0^.5[c^(n−17)−c^(n−1)]dt m<=32m/(n−16)<=64m/n (n>=32)。只扩正标量积分到1，不延长Gc适用范围。

每fixed退出t的h*K_s,t双shape完整系数包络Dn与物理列Nh给NhDn，先定t后Tonelli对单份共同来源积分，无sup_t/网格复制。原hardrow Chq和唯一q^-1给实际mixed费用

    E_n W, E_n=(64Ch/n)NhDn<=384Ch sqrt(n), n>=32.

该actual history与CJ尚未退出LIVE、NE无早退出late块不重叠。原EARLY精确分成本项与第一跳即EXIT（此前无internaljump，退出前源c_t^nν_C，退出后仍完整自由传播）。

当前primary n>=512为

    lambda|Eband| <=(144/7){B_GP+(128/63)(V_n+384Ch+E_n)W
                              +(128/63)R_firstjump,exit^act}.

B_GP仍preNE原GP§18/§32全部paid；不叠旧16/15或重收NE/CJ。E_n、V_n、384Ch都已含Ch，内128/63各一次，整体144/7=9*16/7一次。原各x,y,z/σ/Ls/Rh/FIRST/完整硬带/GOOD/score/owntrace/forest/LCA/clock/strictCP/GP资格完全保留在实际新余项；不先换common bar，不重判landing资格。第一跳即EXIT的sum n坐标来源质量不是O(W/n)。已付O(sqrt(n)log^6(n+2))W，余项未付、整体目标未证明、无条件O(nlogn)基线不变。小维数既有fallback。

EI正式38fa2e30a7fb3bb1ef519d2753c86571a2b00e65f3ef7cb238e5bdb8d75d8912；最终独审e3241469c1aa69ce85ad2b8201e0e4adec8b41cdaac4a13227d9a994682d547c与转录对应c93b793f8618fa3356e0c8c2faa4ede07db8d028611e706778308f9ef29809bc均已全文核读。独立42965派生/静态及21862系数递推项maxnorm1.688e-12，不复跑raw求积或作者probe。n32/64,256/1024,4096/16384三阶段3456核/288路径/144时间pair/6费用/41472作者来源率。只重建保存192步矩阵，96步仅保存汇总/pair不冒充raw重建。half-cell初始histogram投影不保持literal半格支撑，两个projectedtensor保留相关性；before_scope_fix快照保留，reg/data未改。u>32标量尾非有限reinjection离散误差。NJnumeric前提review9ee79dcc5834bf42304c6d5a1762831ab874f4b5c8a3fcd55952d54ccb37a4d2已scopedPASS；本主账不包含未证明的firstjump空间费用。



## 37. 晚首次跳跃的固定小来源（FJL，已审接入）

原actual firstjump按T_n=(12+log(n+2))/n分为t<T_n与t>=T_n（均还要求t<=min(σ,.5)）。参考b的同一逐initialy共同晚时源给全部n坐标合计质量<=2[(1−T_n)^n−2^(-n)]W<=2e^-12W/(n+2)。每固定t完整continuation包络NhDn，Tonelli积分单份source-time，再用原hardrow Chq与唯一q^-1，付

    J_n^late W, J_n^late=2e^-12 ChNhDn/(n+2)<=4e^-12 Ch sqrt(n).

此费用已含Ch；原σ<T_n晚分支为空。原x,y,z、FIRST、硬带、winner、GOOD、score、owntrace、birth、forest/LCA、clock、strictCP/GP与唯一来源分配均保留，支付时正性去门。共同扩大源不继承旧q行cap，不重判landing。

当前primary n>=512为

    lambda|Eband| <=(144/7){B_GP+(128/63)(V_n+384Ch+E_n+J_n^late)W
                              +(128/63)R_firstjump,t<T_n^act}.

B_GP仍preNE原GP全部paid，E_n=64ChNhDn/n保持；不叠旧16/15，不再次收费NE/CJ/EI。唯一未付为原第一跳即退出且t<T_n的实际完整后续传播；已付阶仍O(sqrt(n)log^6(n+2))W，一般目标未证，无条件O(nlogn)基线未变。小维数既有fallback。

FJL正式a7e6f1a274c3a84fd31df6d8e6572f3d0374422ad3e6c120528e562b4e1081db、转录17b5f94a6ddbef9db086d4e4a8aab6c0632d47a2a197b1928b64b7950b6c39b5均root全文审查PASS。新三stage450核/3780面/540continuation/30时钟/6费用/6系数/6完整来源，results dcdd86cd187e546df630edd42b73466f61331204ff19137bff187fab6c53b771；独立19152保存字段/几何/完整来源/系数递推项max5.379e-12。不重跑谱求积，不认证连续FIRST或mixednorm。初版转录漏EI费用在接入前修复，修前字节按原hash验证恢复并保存；正式解析与数值未改。


## 辅助工具 RC 已审接入；primary费用不变

完整正有限来源（near mass3+全部far mass）给原octave连续FIRST与内点物理winner，但uniform frozen-coordinate future response在1.9超过1.2q，尽管原平均导数为0。此仅否定未加SST/GOOD等资格的免费1+C/n transfer。不是实际剩余firstjump/SST counter或weakendpoint counter；不收新费、不缩小当前primary CAPACITY23/CURRENT37余项。

root全文核正式已审snapshot5f8abd72761b9bda8150e9496bf966b118dc9f863c8e97d752df03f5340e7da1、review16802097b3584fca5452770ccae82d820b56cd4b4ebefb52888b973db4521c82以及转录29f38eeb0add033ddfc69c5bde3c7db5afb226c3c3f64ec891cab1546aecee86。低端物理导数遗漏n因子已放宽为10(n+1)^2 1.1^n/[nΓ(n)]，修前快照保留，执行数据未改。当前作者7965721…只状态/引用更新，已审snapshot为逆变换精确恢复并验证旧hash。独立770字段85位检查maxnorm6.601e-15，未重跑source/spectralquad；连续证书来自解析，不来自有限网格。


## 辅助工具 FD 与再包含限制已审接入；primary费用不变

已接受任意原标签核上界 T_prefix<=B_n(P_sigma,L*W_L)，W_L为均匀单轴w概率测度，tau=min(sigma,T_n),U=tau/(1−tau)，B_n=n∫0^U[1−a(1−sigma)u]^n du，a可为认证1/5或exacta0。保持原g与唯一q^-1，sigma1/tau0端点精确，不重付survival，不作新space费。

原complete hardband使sigma>1/n；phi logLip5给ψ*w>=ψ/5，B_n>=1/2，因此majorant>=P/10，逐原正gate/source保持。它重新包含原full-P traffic，不能称缩小了未付空间接口；不是actualprefix下界或endpoint counter。primary仍CAPACITY23/CURRENT37，不删除actual earlyfirstjump余项。

正式0728dd9f…、reviewffc7d48a…、转录38deba8d…均root全文读。新三stage5040/120/24/15记录；独审86704字段、时间节点/weights与tensor重组maxnorm4.167e-13，不复跑rawGc/sourcequad。来源24行只核保存算术和geometry/mass/pairlogs。登记换元多n的文字及pending状态标题已scope修复并保留历史，data/reg/probe冻结。FD和RC均作为可用工具/路线限制，不增加主账费用。
