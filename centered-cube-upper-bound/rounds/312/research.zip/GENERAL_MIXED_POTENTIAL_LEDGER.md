# Whole-softness mixed lens: a single high-potential remainder

Status: ACCEPTED general reduction. HS, MF, JM, registered records, the explicit radius and this ledger passed their independent reviews, including GENERAL_MIXED_POTENTIAL_REVIEW.md and signed_band_probability/joint_mixed_lens_review.md. The general sqrt(n)n^{o(1)} endpoint remains UNPROVED. This refines MIXED_WITNESS_LEDGER.md and is an ALTERNATIVE to the earlier marked/critical three-remainder route, not an additional fee added to that route.

## 1. Original event and exact kernels

Keep the original complete input f, W, common q in[3lambda/4,lambda], hard band2lambda<G0<=4lambda and original global FIRST from GENERAL_CURRENT_REDUCTION.md sections1–2. Charge its baseline/endpoints, all-soft BAD and all-soft low-source output exceptions ONCE. The remaining whole event E is not split by softness. The source is the single fixed mu=mu_hi, mass W_hi. At each original output retain BOTH original winners L=L_s and R=R_h in[a,b], b=2a, sigma>=c0/n. With pure homogeneous angular GOOD Gamma set

    k_s(x,y)=P_sigma,L(x-y)Gamma(x-y),
    k_h(x,z)=R^(-n)1_Q(x,R)(z)Gamma(x-z).

Their responses are at least3q/4 and7q/4, at most q andC_hq, respectively. Thus q-volume back factor is16/21 and lambda-volume back factor64/63. No source, q, angular threshold or FIRST is recomputed.

## 2. Source-only threshold and the full-H qualification

Let H be the complete coefficient envelope over ALL softness, mass D<=C_D sqrt(n), C_D=1+pi/2. For each ordered source pair define

    g=||y-z||1, X=g/a,
    B_yz=10^5(n²+n+X),
    N_yz=e^4[1+ceil(B_yz log2)]²,
    C_yz(L,R)=integral H_L(u-y)h_R(u-z)du,
    M(y)=integral exp(-||y-z||1/(64b))dmu(z),
    T_yz=epsilon q exp(-g/(64b))/(N_yz M(y)).

Take epsilon=1/16 and A=1. If W_hi=0 the retained event is empty. Otherwise M(y)>0. Every displayed pair quantity is source-only except the actual arguments L(x),R(x). The exact qualified column JM7 pays the original branch C_yz(L(x),R(x))<=T_yz by epsilon W_hi after division by q. This qualification is for FULL H; the smaller actual fixed-sigma correlation does not imply it. The grid count N_yz cancels inside the source-normalized threshold, not by discarding its cost.

## 3. Explicit input-independent near radius

Let

    K=128/3,
    C_N=e^4(2+2*10^5 log2)²,
    B_n=log(C_D C_N/epsilon)+(A+9/2)log(n+2),
    H0=2K a[B_n+2log(4K)].

Indeed N_yz<=C_N n^4(1+X)² for n>=1. The full mixed correlation bound is

    C_yz(L,R)<=D min(L,R)^(-n)exp(-g/(16b)).

If C_yz(L,R)>T_yz and M(y)<=q min(L,R)^n(n+2)^A, its logarithm gives

    X<K[B_n+2log(1+X)].

For every X>=0, 2Klog(1+X)<=X/2+2Klog(4K); one can maximize the difference explicitly at X=4K-1. Therefore X<2K[B_n+2log(4K)]=H0/a. This is an analytic order calculation, not an exponent fitted to samples. H0/a=O(log(n+2)) with fixed absolute constants, so HS12 pays ALL true near pairs by Q_mix W_hi, Q_mix=O(sqrt(n)log²(n+2)). The coefficient Q_mix is evaluated at THIS H0, rather than silently reusing a smaller-radius constant.

## 4. Exact remaining branch and full-band inequality

After low-C and all-near payments, retain the actual directed pair qualification

    C_yz(L(x),R(x))>T_yz,
    g>H0,
    M(y)>q[min(L(x),R(x))]^n(n+2)^A.

The last condition follows from the first two; it is not an additional source deletion. Define

    R_HP=(1/q) integral_E integral_(the displayed qualifications)
                     k_s(x,y)k_h(x,z)dmu_hi(y)dmu_hi(z)dx.

All original FIRST, hard-band, angular and high-source qualifications are retained. In particular R_HP includes inside, outside and mixed source pairs and every original softness. No posterior coordinate independence, new source draw or boundary trace is substituted for its actual output integral. The positive product yields

    q|E| <=(16/21)[(epsilon+Q_mix)W_hi+R_HP].

Thus the refined alternative whole-band ledger is

    lambda|E_band| <=(2C_base+8)sqrt(n)W +(32/3)kappa_n W
                     +(256/3)K_*²sqrt(n)W_lo
                     +(64/63)(epsilon+Q_mix)W_hi +(64/63)R_HP.

The paid coefficient is O(sqrt(n)log²(n+2)). This is an exact refinement of the old unqualified mixed far integral: choose its H0 as above, then split its far pairs into low-C (paid by epsilon W_hi) and high-C (which satisfy the high-potential condition). No near fee is charged twice. The older marked/critical route remains valid independently; no comparison of its remainders to R_HP is presumed.

## 5. What is still not proved

R_HP has not been shown <=sqrt(n)n^{o(1)}W_hi. High actual potential is not automatically rare, low occupation, independent, doubling, or geometrically near. The accepted hard-only two-scale antichain counterexample does not refute this positive-H column theorem, but it explains why its explicit soft-sibling trace argument was necessary. The new correlation/column/near combination is a general reduction, not a proof of the requested endpoint. The unconditional general baseline remains O(n log n); no improved unconditional exponent is claimed.
