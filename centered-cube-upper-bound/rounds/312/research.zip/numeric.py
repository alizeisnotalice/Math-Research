#!/usr/bin/env python3
"""R312 finite exact upper/lower degree bands and absorption certificates."""
import json,math,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
COUNTS={};FAIL=[];ETA=F(1,128);EXP_CACHE={}
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def floor(q):return q.numerator//q.denominator
def ceil(q):return -((-q.numerator)//q.denominator)
def summary(q,display=True):
 a=abs(q.numerator).to_bytes(max(1,(abs(q.numerator).bit_length()+7)//8),'big');b=q.denominator.to_bytes(max(1,(q.denominator.bit_length()+7)//8),'big');out={'binary_rational_sha256':hashlib.sha256(bytes([q.numerator<0])+len(a).to_bytes(8,'big')+a+b).hexdigest(),'numerator_bits':q.numerator.bit_length(),'denominator_bits':q.denominator.bit_length()}
 if q.numerator.bit_length()+q.denominator.bit_length()<=1200:out['exact_fraction']=str(q)
 if display:
  with localcontext() as ctx:ctx.prec=40;val=Decimal(q.numerator)/Decimal(q.denominator);out['decimal40_diagnostic']=str(val)
 return out
def exp_bounds(x):
 """Exact Taylor enclosure: reduce0<=y<=1/2,degree8,raise to2^h."""
 if x in EXP_CACHE:return EXP_CACHE[x]
 if x<0:raise ValueError('nonnegative exponent required')
 y=x;h=0
 while y>F(1,2):y/=2;h+=1
 N=8;term=F(1);lo=F(1)
 for k in range(1,N+1):term*=y/k;lo+=term
 nextterm=term*y/(N+1);hi=lo+nextterm/(1-y/(N+2))
 lo=lo**(2**h);hi=hi**(2**h);result=(lo,hi,h,N);EXP_CACHE[x]=result;return result
# Taylor's positive series gives e>2 and therefore log2<1, used in An<=n+1.
ck(exp_bounds(F(1))[0]>2,'rational_Taylor_e_lower_gt_two_for_An_and_posterior',{})
SOURCE_M={};source_cases=[]
for n in [1,4,16,64,256,1024,4096]:
 Arat=F(n+1);m=7
 while Arat/exp_bounds(F(m,6))[0]>ETA:m+=1
 L,U,h,N=exp_bounds(F(m,6));price=Arat/L
 ck(price<=ETA,'exact_source_price_eta_with_recorded_integer_m',{'n':n,'m':m})
 if m>7:ck(Arat/exp_bounds(F(m-1,6))[1]>ETA,'previous_m_fails_conservative_An_exponential_target',{'n':n,'m':m})
 SOURCE_M[n]=m;source_cases.append({'n':n,'eta':str(ETA),'An_actual_symbolic':'1+n log2','An_rational_upper':str(Arat),'m_recorded':m,'definition':'minimal tested integer>=7 with(n+1)/TaylorLowerExp(m/6)<=eta','source_price_rational_upper':summary(price),'exp_m_over6_lower':summary(L,False),'exp_m_over6_upper':summary(U,False),'range_reduction_h':h,'Taylor_degree':N})
def test(n,m,sigma,label):
 ck(m>=7 and 0<sigma<1,'input_m_ge_seven_sigma_strict_unit_interval',{'n':n,'m':m,'sigma':str(sigma)})
 j=ceil(2*n*sigma+m);ell=floor(n*sigma/8-m);upper=set(range(j,n+1)) if j<=n else set();lower=set(range(ell+1)) if ell>=0 else set();corr=set(range(n+1))-upper-lower
 ck(not upper.intersection(lower) and upper|lower|corr==set(range(n+1)) and not(corr&upper or corr&lower),'exact_disjoint_lower_upper_and_complete_unpaid_corr_partition',{'n':n,'m':m})
 ck(sum(k+1 for k in lower)+sum(k+1 for k in upper)+sum(k+1 for k in corr)==F((n+1)*(n+2),2),'exact_positive_degree_mass_partition_no_corr_drop',{'n':n,'m':m})
 ck(j>=m and j>=2*n*sigma+m and j-1<2*n*sigma+m,'exact_ceiling_upper_boundary',{'n':n,'m':m})
 ck(ell<=n*sigma/8-m<ell+1,'exact_floor_lower_boundary',{'n':n,'m':m})
 if (1-sigma)**n==F(1,2):ck(not ((1-sigma)**n<F(1,2)),'conditional_hard_margin_equality_is_not_strict',{'n':n,'sigma':str(sigma)})
 record={'label':label,'n':n,'m':m,'sigma':str(sigma),'upper_j':j,'lower_ell':ell,'upper_empty':not bool(upper),'lower_empty':not bool(lower),'corr_degree_count_unpaid':len(corr),'original_margin_annotation_only':{'test_one_minus_sigma_power_n':summary((1-sigma)**n),'sigma_above_margin_1_minus_2_power_minus_one_over_n':(1-sigma)**n<F(1,2),'applicability':'Native FIRST was checked by the independent analytic original-document audit in this round. This annotation only locates the coefficient fixture relative to the hard-margin root; numerical tests do not prove selector applicability.'}}
 if upper:
  p=F(j,n)
  if p==1:
   ck(j==n and upper=={n},'p_one_only_degree_n_upper_tail',{'n':n,'m':m});ractual=sigma**n;rhat=F(2)**(-n);degrees=[n]
  else:
   ractual=(sigma/p)**j*((1-sigma)/(1-p))**(n-j);rhat=F(2)**(-j)*((1-p/2)/(1-p))**(n-j);degrees=list(range(j,n+1)) if n<=32 else sorted(set([j,min(n,j+1),(j+n)//2,n]))
  ck(sigma<=p/2 and ractual<=rhat,'exact_upper_actual_ratio_below_uniform_endpoint_ratio',{'n':n,'j':j})
  for k in degrees:
   ratio=sigma**n if p==1 else (sigma/p)**k*((1-sigma)/(1-p))**(n-k)
   ck(ratio<=ractual,'exact_retained_degree_ratio_le_rj',{'n':n,'j':j,'k':k})
   if p<1 and k<n:ck(sigma*(1-p)<=p*(1-sigma),'exact_degree_ratio_nonincreasing_cross_product',{'n':n,'j':j,'k':k})
  Lj,Uj,h,N=exp_bounds(F(j,6));ck(rhat*Uj<=1,'rational_Taylor_certificate_rj_le_exp_minus_j_over6',{'n':n,'j':j})
  ck(j>=m,'exp_minus_j_over6_le_exp_minus_m_over6_by_exact_order',{'n':n,'j':j,'m':m})
  Lm,Um,hm,Nm=exp_bounds(F(m,6));price=F(n+1)/Lm
  ck(ractual*(n+1)<=rhat*(n+1)<=price,'upper_tail_conservative_source_price_chain',{'n':n,'j':j,'m':m})
  record.update({'reference_p':str(p),'tested_upper_degrees':degrees,'actual_rj':summary(ractual),'uniform_endpoint_rj_upper':summary(rhat),'exp_j_over6_upper_certificate':summary(Uj,False),'exp_range_h':h,'Taylor_degree':N,'conservative_source_price_bound':summary(price),'source_eta_certified':price<=ETA})
 else:ck(j>n,'upper_tail_empty_without_illegal_p_above_one',{'n':n,'j':j})
 if lower:
  x=n*sigma/8;Lx,Ux,h,N=exp_bounds(x)
  ck(x>=ell+m and Lx>=F(2)**(ell+m),'rational_Taylor_lower_posterior_exponential_certificate',{'n':n,'m':m,'ell':ell})
  bound=F(2)**ell/Lx;ck(bound<=F(2)**(-m),'exact_lower_posterior_bound_le_two_minus_m',{'n':n,'m':m,'ell':ell})
  record.update({'lower_posterior_rational_upper':summary(bound),'lower_posterior_target_two_minus_m':summary(F(2)**(-m)),'exp_nsigma_over8_lower_certificate':summary(Lx,False),'lower_exp_range_h':h})
 return record
initial=[]
for n in [8,16,32]:
 for sigma in [F(1,8*n),F(1,2*n),F(1,n),F(1,4),F(1,2),F(3,4),1-F(1,8*n)]:initial.append(test(n,7,sigma,'initial'))
boundary=[test(1,7,F(1,2),'n_one_hard_margin_strict_equality_guard')]
for n,m in [(16,7),(64,7),(64,8),(128,7)]:
 sigmas=set([F(1,2*n),F(1,n),1-F(1,1024*n)])
 for target in [m+1,n]:
  center=F(target-m,2*n)
  for delta in [-F(1,16*n),F(0),F(1,16*n)]:
   if 0<center+delta<1:sigmas.add(center+delta)
 for ell_target in [0,1]:
  center=F(8*(m+ell_target),n)
  for delta in [-F(1,16*n),F(0),F(1,16*n)]:
   if 0<center+delta<1:sigmas.add(center+delta)
 for sigma in sorted(sigmas):boundary.append(test(n,m,sigma,'ceil_floor_p1_margin_boundary'))
expanded=[]
for n in [256,1024,4096]:
 m=SOURCE_M[n]
 for sigma in [F(1,2*n),F(1,n),F(1,64),F(1,8),F(1,4),F(1,3),F(1,2),1-F(1,2*n)]:expanded.append(test(n,m,sigma,'expanded_source_priced_m'))
# Exact absorption constants; corr is carried, never paid by this step.
absorption=[];c=F(64,63)
for m in sorted(set([7,8]+list(SOURCE_M.values()))):
 a=c*4*F(2)**(-m);inverse=1/(1-a);factor=c/(1-a)
 ck(a<=F(2,63) and inverse<=F(63,61) and factor<=F(64,61),'exact_whole_mixed_fourX_absorption_and_final_factors',{'m':m})
 if m==7:ck(a==F(2,63) and inverse==F(63,61) and factor==F(64,61),'m_seven_absorption_boundary_equalities',{})
 absorption.append({'m':m,'whole_mixed_assumption':'<=4X','posterior_factor':str(F(2)**(-m)),'c':str(c),'absorption':str(a),'inverse_factor':str(inverse),'c_over_one_minus_absorption':str(factor),'corr_status':'original corr remains unpaid and is retained with its coefficient'})
for base in [F(0),F(1,7),F(1000)]:
 for corr in [F(0),F(1,5),F(16)]:
  X=F(64,61)*(base+corr);ck(X==F(64,63)*(base+corr)+F(2,63)*X,'exact_final_factor_boundary_with_corr_retained',{'base':str(base),'corr':str(corr)})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Finite exact Fraction coefficient, posterior-exponential and absorption diagnostics. Rational Taylor enclosures certify every exponential comparison in these finite cases; they do not replace the independent all-input analytic proof. Native FIRST has been verified by this round’s independent analytic original-document audit; these numerical checks do not establish or replace that proof. Atomic coefficient fixtures need not satisfy every native selector constraint. Complete source/root closure is not certified here; corr remains explicitly unpaid.','upper':'j=ceil(2n sigma+m). Ifj<=n,p=j/n; retained coefficient ratio maximal atdegreej. p1 onlydegreen; j>n is an empty tail with no p>1. Uniform endpoint ratio rhat=2^-j[(1-p/2)/(1-p)]^(n-j) (p1:2^-n) boundsactualrj. rhat*TaylorUpperExp(j/6)<=1 certifies rj<=exp(-j/6)<=exp(-m/6).','lower':'ell=floor(n sigma/8-m). Ifell>=0, TaylorLowerExp(nsigma/8)>=2^(ell+m) certifies2^ell exp(-nsigma/8)<=2^-m. Empty lower tails are separate.','exp_certificate':'Forx>=0 chooseh withy=x/2^h<=1/2; L=sum_(k0..8)y^k/k!, U=L+(y^9/9!)/(1-y/10). Positive-series remainder gives L<=exp(y)<=U; raise both to2^h. All arithmetic rational. Displayed decimal values are diagnostics only.','source_m':'An=1+nlog2<=n+1 sincee>2. m>=7 is chosen by exact(n+1)/TaylorLowerExp(m/6)<=eta1/128; previousm fails even withTaylorUpperExp. Hence m>=ceil(6log(An/eta)) conservatively, without floating log decisions.','absorption':'whole mixed<=4X and c=64/63 give a=c*4*2^-m<=2/63; 1/(1-a)<=63/61 and c/(1-a)<=64/61. Retain corr; no payment is inferred for it.','coverage':'Initial21 cases n8/16/32,m7; boundary cases floor/ceil exact and±rational perturbations,p1,emptytails,sigma near1 and hard-margin annotation; expanded24 cases n256/1024/4096 with recorded source-pricing m. Coefficients exhaustive only whenn<=32; otherwise selected endpoint/interior degrees, not a large sweep.','check_counts':COUNTS,'failures':FAIL,'source_m_cases':source_cases,'stages':[{'name':'initial','cases':initial},{'name':'floor_ceil_endpoint_pressure','cases':boundary},{'name':'expanded_source_priced','cases':expanded}],'absorption_cases':absorption}
path=Path(__file__);path.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');lines=['# R312 exact degree-band certificates','',out['scope'],'',out['upper'],'',out['lower'],'',out['exp_certificate'],'',out['source_m'],'','|n|recorded m|conservative source price upper|','|---:|---:|---:|']
for r in source_cases:lines.append(f"|{r['n']}|{r['m_recorded']}|{r['source_price_rational_upper']['decimal40_diagnostic']}|")
lines+=['',out['absorption'],'',out['coverage'],'','Every model retains the full degree partition lower+upper+corr. Floor/ceil equality decisions, source-price targets and absorption are exact rational decisions. Only the stated finite configurations are certified here.']
path.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'stage_sizes':[len(initial),len(boundary),len(expanded)],'source_m':[(r['n'],r['m_recorded']) for r in source_cases],'upper_active':sum(not r['upper_empty'] for s in out['stages'] for r in s['cases']),'lower_active':sum(not r['lower_empty'] for s in out['stages'] for r in s['cases']),'both_active':sum(not r['upper_empty'] and not r['lower_empty'] for s in out['stages'] for r in s['cases'])},indent=2));assert not FAIL,FAIL
