# R312 independent preauthor audit

Independent screen PASS for the stated native alternative route. Saved BEFORE reading /tmp/r312_native_entry.md. Own audit only; no Git or other-author changes.

## Original native entry checked directly

Read GENERAL_CURRENT_REDUCTION.md sections 1--2 and 7--8. They specify the SAME full original f, common q in [3lambda/4,lambda], original interior sigma/L_s with all higher-softness/all-octave response caps, and mu_hi=f_hi dy<=f fixed by q. The alternative mixed route is applied after whole-event deletions, before a critical/large-softness split. Its actual normalized positive mixed integral uses the original soft FIRST winner and hard winner at the same receiver, full high source on both sides, and original positive GOOD masks. Section 8 restricts this exact traffic by the original full-H high-correlation, far-distance and high-potential qualifications to R_HP. Its full-band entry is X<=A_paid+(64/63)R_HP. Q_mix/epsilon/near/correlation fees already present in A_paid must not be charged again. This is an ALTERNATIVE complete-event route, not an extra term in old Rout.

## Independent variable-cutoff proof

For fixed integer m>=7, kplus(x)=ceil(2n sigma(x)+m), kminus(x)=floor(n sigma(x)/8-m) are Borel integers because the original selector sigma is measurable. Their thresholds depend only on original x, not y,z or observed latent source labels. Degree k is partitioned EXACTLY into upper k>=kplus, lower k<=kminus, and remaining corridor, intersected with 0..n; kminus<kplus always. Empty upper/lower tails use zero rather than illegal cutoffs. All full-H/GOOD/source/history qualifiers and original physical fields stay fixed.

When kplus<=n, choose the receiver-dependent reference p(x)=kplus(x)/n>=2sigma(x). Original full-f future response cap holds simultaneously for every p>=sigma and physical L', so it applies pointwise to this measurable reference at the SAME L_s(x); mu_hi inherits it by positivity. The R311 coefficient comparison gives actual degree-upper kernel<=r(x)P_p,L_s, with r(x)<=exp[-kplus(x)/6]<=exp(-m/6). For p=1 only degree n is compared and r=2^(-n). If kplus>n the tail is empty; p>1 is never defined. Source integration FIRST gives aggregate upper soft response/q<=exp(-m/6), then the SAME actual hard field is integrated via its positive scale envelope A_n=1+n ln2. Thus R_HP,upper<=exp(-m/6)A_n W_hi, with one hard-source mass, no softness-band copies and no component FIRST. Receiver-dependent p causes no source-selection problem.

For lower degree, at each positive actual full kernel the latent coordinates are independent Bernoulli: outside a hard coordinate the soft posterior is one; inside phi>=1/4 yields posterior>=sigma/4. Hence P_(degree<=k)/P<=2^k exp(-n sigma/8). At k<=floor(n sigma/8-m), this is <=2^(-m) since ln2<1. At sigma=0 or vanishing kernels use direct zero/support conventions; at sigma=1 all labels are soft. Multiplication by original nonnegative qualifications only decreases the positive bound; full qualified traffic is split, not redefined.

The normalized unqualified mixed product is pointwise <=4lambda: original soft-source response<=q, original hard response<=G0<=4lambda. Therefore R_HP,lower<=4*2^(-m)X with X=lambda|E_band|. This is a local X absorption in THIS native alternative route. It is not a source-W payment and is not an epsilon-X insertion into the old unrelated ledger.

Consequently

(1-(256/63)2^(-m))X <= A_paid+(64/63)[exp(-m/6)A_n W_hi+R_corr].

For m>=7, the left coefficient is at least61/63, giving exactly

X <= (63/61)A_paid+(64/61)exp(-m/6)A_n W_hi+(64/61)R_corr.

Finite X is legitimate: the full hard envelope has L1 mass A_n, so G0>2lambda implies X<=A_n W/2. No infinity subtraction is used. Corridor is the exact unremoved positive traffic on ALL original qualifications. No claim it is root-priced, near, low-p, or a legacy R309 remainder is made.

## Actual local diagnostics

{'upper_coefficient_Fraction': 3218, 'partition_Fraction': 70, 'lower_CDF_Fraction': 6, 'absorption_Fraction': 2, 'upper_rate_mp50': 35}

Executed exact Fraction coefficient, partition, lower CDF and absorption checks, plus ordinary 50-digit upper-rate comparisons. All PASS. Finite tests support the algebra and posterior bounds, not any general source-root bound for the corridor or full operator closure.

## Author comparison and exact native provenance

After saving the independent derivation, read /tmp/r312_native_entry.md in full. Also directly read GENERAL_MIXED_POTENTIAL_LEDGER.md sections1--4 and NP1 in full_soft_l2_extension/noise_parameter_route.md. These confirm the exact k_s=P_sigma,L GOOD and k_h=h_R GOOD, single fixed mu_hi, original full-H C/T/M qualification, true h/phi profile and the 64/63 whole-band entry. This is a certified direct native interface, not a presumed identity with R309/R310 auxiliary fields. Previously accepted analytic tools are starting hypotheses of the reduction, not reaudited here.

Author core theorem PASS: upper tail uses the actual source-integrated full higher-softness cap at the measurable receiver-dependent reference, lower tail uses the true product posterior, and the exact degree split preserves all original masks and data. The whole normalized mixed traffic<=4X and finite X<=A_n W/2 justify only the stated local absorption. A_paid is enlarged once by63/61, with its near/correlation/output fees not duplicated. No old Rout/B_H term is declared paid by this argument.

Optional spatial-tail composition PASS for explicitly S in [0,1] and D>=0. On sigma<=S the corridor degrees are <=K_S=min(n,ceil(2nS+m)-1). The true depth moment, full profile ray envelope and original SAME-receiver hard cap give (16/3)A_n C_(n,K_S)e^(-D/2)W_hi; k=0 contributes zero. The exact complement sigma>S OR (sigma<=S,E_b<=D) remains. For S=1, K_S=n may require D of order n; for S=O(log n/n), all larger-sigma corridor remains. Shallow common-b depth does not imply the existing source-pair near qualification, so no second near payment is imported.

Optional KL cutoff PASS. For u>0 the finite k_u(sigma) tests are measurable and use p>=sigma; p=1 is handled by its single surviving degree, sigma=0 gives zero positive-degree tail, sigma=1 gives empty upper tail. Coefficient ratios decrease beyond k_u and equal exp[-nD(p||sigma)] at the cutoff. Thus the original simultaneous future cap pays this alternative upper tail once by e^(-u)A_n W_hi. The entropy inequality D(p||sigma)>=p ln(p/sigma)-p+sigma>= (p-sigma)^2/(2p) and the rounded quadratic cutoff are correct. It is an ALTERNATIVE cutoff with its own exact complementary degree set, not an extra fee added to the simple corridor theorem.

Final author minor clarifications were requested and verified: D>=0 for the spatial tail, explicit phi(1/2)>1/4 lower bound, and finite-X via hard envelope. These change no diagnostic code. The parent reports a fresh separate-process run of 3024 coefficient+108 partition+9 lower-tail+2 endpoint+5 absorption checks, total3148 PASS. This auditor's independent executed checks are separately recorded above. Neither finite evidence certifies a source-root corridor budget.

Author frozen binding: /tmp/r312_native_entry.md SHA256 17df4b001101095301f3ce6f43fe828e46b40acb464f230e5828e1b47b92ec84. Final README/TeX integration bindings remain pending.

## Final combined/TeX and numeric-scope comparison

Read checkpoint combined.md and research.tex without compilation. A_paid exactly preserves the native original baseline/endpoints, allsoft angular, allsoft low-source output, and already paid epsilon+Q_mix terms. The corridor entry, source-m choice and 63/61,64/61 constants match the author proof. No near, low-correlation or soft-window copy is added. The TeX now explicitly states the original hard band 2lambda<G0<=4lambda, needed for 4X and finite X.

The old R304 ledger summary is kept as a separate alternative. It now writes X_old=lambda|E0| explicitly and does NOT identify it with native X=lambda|E_band|. Old T_low wide/extreme-aspect traffic, initial I_rem, true-deletion atoms J_rem, future-deleted continuous D_rem, suffix and once-only negative terms remain. Its original total adoption/absorption connector remains uncertified. B_H^near is explicitly an unpaid upper-budget fee using full original J_y, actual nu_h cube symmetric-difference mass and original near/prefix gates; it is not an exact residual traffic, density-weighted boundary volume, or a fee paid by the native corridor theorem.

Reviewed final numeric source logic: reduce nonnegative exponent x to y=x/2^h<=1/2; the degree8 positive Taylor sum is a lower bound and the ninth-term geometric remainder with denominator1-y/10 is an upper bound. Raising these nonnegative rational bounds to2^h is valid. Thus the finite upper-rate and lower-posterior certificates are genuine exact rational enclosures; decimal displays are diagnostic only. Source m uses An<=n+1, and previous-m failure is explicitly for that conservative target. Large-n coefficients are sampled endpoint/interior cases, not exhaustively tested. The fixture does not realize all original FIRST/history/source conditions; analytic applicability is supplied by the directly inspected native originals. Final numeric author reports1301 exact checks with independently identical runs; parent fresh rerun is recorded separately on completion.

The optional R312 entry-sources index describes a distinct October7 current-joint chain and limits its own scope. No identity between that chain, native R_HP corridor and old B_H is inferred in this audit. The native theorem's actual provenance was directly checked in the October3 current and mixed-potential ledgers, as detailed above.

Remaining gap: source-root price for the original masked high-C/far/high-potential degree corridor, or optional corridor-rest after its explicitly priced depth tail; additionally all separately retained old B_H/source/outer/entry slots. General root weak bound remains unproved.

## Final README, fresh-run receipt and freeze

Final checkpoint README matches native_entry, combined and TeX: full A_paid and source-nu fee, lower-tail local absorption, exact unpriced corridor, native-vs-old X distinction and no addition of alternative ledgers are all explicit. It correctly prioritizes original B_H for subsequent work without claiming this round pays it. The final numeric text now says native FIRST applicability has been analytically checked against the original documents this round; numerical fixtures do not establish it. The absorption notation correctly uses a=(64/63)4*2^(-m), then1/(1-a)<=63/61 and (64/63)/(1-a)<=64/61.

Parent confirms a fresh isolated local subprocess run of final numeric.py1301 and geometry_checks.py3148, both PASS, with checkpoint numeric.json byte-identical to frozen /tmp/r312_numeric.json SHA2566ab72ea3ff3a5f61481fd03f86a0519fc19d12baae5e96f02f215b183ccb767d. Actual output logs are retained in the checkpoint; this receipt is attributed to the parent rather than mislabeled as a second audit run. I inspected the numeric script/enclosures and output scope; my independently executed cases are separately recorded above. No additional checks are needed for these final textual revisions.

Final verdict PASS for the scoped native alternative corridor reduction and its two optional refinements. General root weak bound, native corridor source-root expense, old B_H and every independent old-ledger/identity/outer obligation remain unproved. Audit FROZEN.

### Final byte bindings
- /tmp/r312_native_entry.md: 17df4b001101095301f3ce6f43fe828e46b40acb464f230e5828e1b47b92ec84
- /tmp/r312_entry_sources.md: 38efcf011d4d5289025173f8e393a7418e1a1a732ac71b6115a9bce1fd3ed8ca
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/combined.md: 069a77cd4d7ff6807f35f095f252e3ceb680cd0bbf4270ddbd5e4c84c07384af
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/research.tex: 23ba4459e47fd8aff17bdfced8c8b2ed68b5b6bfe9905385b420b83749d5b49e
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/README.md: 57f718a8803c8f05c2a04b5a4ea40e80aa5658986f1d54a5d52aed866f0d3cf2
- /tmp/r312_numeric.py: e5283619e722fe9148ab7a1c4e79d39c47ca2d8748027b61ee707a730870c6e0
- /tmp/r312_numeric.json: 6ab72ea3ff3a5f61481fd03f86a0519fc19d12baae5e96f02f215b183ccb767d
- /tmp/r312_numeric.md: 018ec1950872a2ebea1d835f3718f64690f56eaa9f18d88d11761e335910eabf
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/numeric.py: e5283619e722fe9148ab7a1c4e79d39c47ca2d8748027b61ee707a730870c6e0
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/geometry_checks.py: 6eaf97af74c471c35e197066be8ff1abf45d4d6dae68b04e578af4bf9658bc43
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/numeric_checks.log: 61d71bd0cc5f740483abded8929db2f8a6fae2472b4462bb051b00053258e9a5
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round312_20261018_final_checkpoint/geometry_checks.log: 91b1633a16d7e6864897f5320d8e18baf5620c8e14ac21933351cf0b2ae4ce8d
