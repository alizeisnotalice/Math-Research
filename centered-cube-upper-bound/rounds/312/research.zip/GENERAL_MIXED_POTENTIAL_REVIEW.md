# Independent review: whole-softness mixed-potential ledger

Status: PASS for GENERAL_MIXED_POTENTIAL_LEDGER.md as a general reduction. The complete high ACTUAL minimum-scale-potential remainder remains unpaid. This does not prove the centered-cube sqrt(n)n^{o(1)} weak endpoint.

Reviewed dependencies: my independent HS mixed-near and MF fixed-correlation reviews; the completed JM analytic/record PASS in signed_band_probability/joint_mixed_lens_review.md; original GENERAL_CURRENT_REDUCTION.md sections1–2 and MIXED_WITNESS_LEDGER.md. This report audits their composition, constants, measurable source-only thresholds, remaining branch, and the separate registered radius algebra screen. It does not replace the JM owner's independent review or modify any proof/ledger.

## 1. Original event, full envelope and source-W payment

All source quantities use ONE fixed positive measure mu=mu_hi, ONE original common q, and the original selected physical scales L_s,R_h in[a,2a]. The original FIRST is not recomputed for H, the high source, an angular restriction or a pair branch. Retaining the pure homogeneous Gamma allows the already proved HS near theorem at both scales. The full original source supplies the sigma>=c0/n margin; restricting the source only preserves upper caps, not FIRST equality. Whole low-source and whole angular exceptions are the same prior deletions, each paid once.

The retained soft GOOD_hi response is at least3q/4 and at mostq. The retained hard GOOD_hi response is at least7q/4: original G0>2lambda>=2q, less at mostq/8 BAD and q/8 low-source. Its upper cap is C_hq with C_h=16/3. Therefore the mixed product is at least(21/16)q². This lower response statement is actual; it is not inferred from domination by H.

H is the COMPLETE coefficient envelope over all softness, including every mask and both endpoints. Its mass obeys D<=1+(pi/2)sqrt(n)<=C_Dsqrt(n), C_D=1+pi/2, for n>=1. The actual positive product k_s k_h is dominated by H_L h_R even with its original Gamma cuts. Its fixed full-H correlation C_yz is strictly positive. Qualification C_yz(L(x),R(x))<=T_yz is therefore sufficient for the accepted JM7 column bound. A smaller actual fixed-sigma correlation does NOT imply this qualification; the ledger explicitly uses the correct direction.

For nonzero finite mu, M(y)=integral exp(−||y−z||_1/(64b))dmu(z) is finite, strictly positive and measurable (indeed continuous), and N_yz is finite and source-only. Thus T_yz is positive and measurable for finite y,z. The correlation is continuous in source difference and the two physical parameters. Original measurable selectors and Gamma make every retained actual pair branch measurable. Zero source mass makes the retained event empty by its positive response lower bounds. No zero denominator convention or missing source component is required.

JM7 bounds the integral of the QUALIFIED two-scale spatial supremum by N_yz T_yz. Positivity/Tonelli and the source-only denominator cancel exactly:

    q^(−1) integral_E integral_(C<=T) k_s k_h dmu(y)dmu(z)dx
    <=epsilon integral dmu(y) integral exp(−g/(64b))dmu(z)/M(y)
    =epsilon W_hi.

The potentially large N_yz is inside T, so it cancels in this actual source-W payment. It is not discarded. The qualification is imposed on the existing output/source incidences, not on a reconstructed FIRST event. No weak triangle over parameter nodes or source redraw is used.

## 2. The explicit grid coefficient and logarithmic backsolve

Put X=g/a, B_yz=10^5(n²+n+X), K=128/3. Since ceil(t)<=t+1 for every real t,

    1+ceil(B_yz log2)<=2+10^5(n²+n+X)log2.

For n>=1, n²+n+X<=2n²(1+X) and 2<=2n²(1+X). Hence

    N_yz<=e^4(2+2*10^5log2)^2 n^4(1+X)^2
          =C_N n^4(1+X)^2.

This is an exact real inequality; no large-n floating ceil decision is needed. C_N is one fixed absolute constant, not a dimension-dependent hidden constant.

On C_yz>T_yz, MF's bound with the essential MIN-scale prefactor m^(−n), m=min(L,R), gives

    3g/(64b)<log[D N_yz M(y)/(epsilon q m^n)].

The difference1/16−1/64=3/64 accounts for this exact exponent. With b=2a, moderate actual potential M(y)<=q m^n(n+2)^A consequently gives

    X<K[log(C_D C_N/epsilon)+(A+9/2)log(n+2)
                                      +2log(1+X)]
      =K[B_n+2log(1+X)].

The4 comes from n^4, the1/2 from D<=C_Dsqrt(n), and A from the moderate potential. Replacing logn by log(n+2) only enlarges the bound. K=128/3 is exactly the b/a=2 conversion. Using max(L,R)^n instead of min(L,R)^n here would not be justified by MF and would weaken the residual incorrectly.

For X>=0, the maximum of2Klog(1+X)−X/2 occurs at X=4K−1 and equals2Klog(4K)−2K+1/2. Because this K>1/4, it is bounded by2Klog(4K). Therefore

    X<2K[B_n+2log(4K)]=H0/a.

The ledger's constants and strict inequality are correct. B_n is positive at the fixed A1,epsilon1/16. The resulting radius is independent of input, q, source count, mass, depth, selectors and softness. An explicit uniform coefficient is

    H0/a<=A0 log(n+2),
    A0=2K[(A+9/2)
       +{log(C_D C_N/epsilon)+2log(4K)}/log3].

All parameters in A0 are fixed absolute constants. The large numerical size of A0 does not affect its asymptotic qualification.

## 3. Near fee, exact remainder and weak back-substitution

HS12 must be evaluated at THIS H0, as the ledger states. Its graph degree, gap/J* allowance and ratio constant are not those of a formerly smaller chosen radius. The explicit uniform A0 above is admissible in HS12: logdegree and logratio remain O(sqrt(n)log²(n+2)), with constants depending only on this fixed A0,c0,C_h. Thus Q_mix at the new radius remains O(sqrt(n)log²(n+2)) uniformly over every original moving softness sigma>=c0/n. The full D enters this new composition logarithmically in H0; no extra D factor multiplies Q_mix or the epsilon fee.

An exact positive partition may first take C<=T, next C>T and g<=H0, and finally C>T and g>H0. The second branch is bounded by the already paid ALL-near energy; this enlargement is legal. On the last branch moderate potential is impossible by the backsolve, so M(y)>q min(L,R)^n(n+2)^A automatically. Consequently the displayed three qualifications define precisely the residual last branch, not an additional source deletion. The boundary C=T goes to the paid sublevel branch and g=H0 to the near branch. These conventions retain all incidences, including inside/outside/mixed sources.

Dividing the positive product byq gives

    q|E|<=(16/21)[(epsilon+Q_mix)W_hi+R_HP].

Since the SAME common q lies in[3lambda/4,lambda], lambda/q<=4/3 and (16/21)(4/3)=64/63. Restoring the once-paid original exceptions gives exactly

    lambda|E_band|<=(2C_base+8)sqrt(n)W
       +(32/3)kappa_n W +(256/3)K_*²sqrt(n)W_lo
       +(64/63)(epsilon+Q_mix)W_hi +(64/63)R_HP.

The all-soft BAD fee uses the complete W, the low-source L2 fee uses W_lo, and the new pair fees use W_hi. This is an alternative WHOLE-event route, with no softness split and no charge for the older marked/critical paid branches. It refines the old mixed far integral only after choosing that ledger's near radius to be the same H0: its far low-C energy is paid by JM and its far high-C energy is R_HP. No comparison to the older soft-soft/marked/large-softness remainders is established or required. Those other full-event ledgers must not be added as disjoint partitions.

The paid coefficient has the claimed O(sqrt(n)log²(n+2)) order. The original finite-dimensional treatment covers the finitely many small n where that bookkeeping was stated separately. The exact high-potential response integral can still be large; neither its rarity nor its source-W bound has been proved. The unconditional general endpoint status remains UNPROVED.

## 4. Registered radius algebra screen

The separate mixed_potential_radius registration fixes A1,epsilon1/16, three dimension stages (1,4,16),(64,256,1024),(4096,10^6,10^12), and ten fixed X pressures. The script adds three derived pressures per dimension: the positive boundary root, H0/a and4K−1. There are9 radius records and117 pressure records, with3/39 per stage. The unique positive boundary root exists analytically: X−K[B_n+2log(1+X)] is negative at0, first decreases, is convex and eventually increases to infinity. The floating bisection only diagnoses that root; the radius proof above is independent of its approximation.

I inspected all scripts/records and recomputed every saved formula/summary without executing its writer. Hashes match the embedded provenance:

- registration.json: e814f50400b07e5d4bf6361eb426878e73ca84c3400109d11a3d86a9c5b9c455.
- probe.py: f503954c231cf56d8b55a030a21e2bb7f24906a4e10b973011b60c73baf38175.
- results.json: cd39b815180926e0edf35a23f52b99fe920ed58c0c3a1dcbb4da5d98b15e5c5d.
- run.jsonl: 1619443bb7f4569ff61fd8180ae3655ea817d3f925641c1fec415e0b61966a9f.

All9 domain keys, all117 pressures, N and absorption formulas, outside-radius flags, stage cumulative counts, root residuals and final summary agree. The minimum stored H0/positive-root ratio is1.804681629338227, the maximum N-bound log excess is−6.291685167525429e−6, and the maximum absorption excess is−84.83333333333337. The last matches the exact global maximizing value−2K+1/2 at4K−1.

These are ordinary-double algebra checks. In particular ceil at enormous n is evaluated after floating rounding and is not an exact integer-grid certificate; the file explicitly discloses that qualification. The exact analytic ceil inequality in section2 supplies the general guarantee. The computed dimension range does not prove an exponent by fitting, and the recorded positive boundary root is not an interval-certified numerical root. No source/output geometry, posterior, original FIRST, spatial norm or operator-W payment is simulated in this package. Under that stated algebra-only scope, all three stages pass.
