from fractions import Fraction as F
from math import comb,ceil,floor
ct={'coefficient':0,'partition':0,'lower_tail':0,'endpoint':0,'absorption':0}
for dims in ((1,2,4),(8,16,32),(64,128,256)):
 for n in dims:
  for m in (7,11):
   for s in (F(0),F(1,2*n),F(1,16),F(1,4),F(1,2),F(1)):
    kp=ceil(2*n*s+m);km=floor(n*s/8-m)
    assert km<kp
    bins=[F(comb(n,k))*s**k*(1-s)**(n-k) for k in range(n+1)]
    lower=sum(bins[k] for k in range(n+1) if k<=km)
    upper=sum(bins[k] for k in range(n+1) if k>=kp)
    middle=sum(bins[k] for k in range(n+1) if km<k<kp)
    assert lower+upper+middle==1;ct['partition']+=1
    if 1<=kp<=n:
     p=F(kp,n)
     r=F(1,2)**n if p==1 else F(1,2)**kp*((1-p/2)/(1-p))**(n-kp)
     assert s<=p/2 and kp>=m
     for k in range(kp,n+1):
      bp=F(comb(n,k))*p**k*(1-p)**(n-k)
      assert bins[k]<=r*bp;ct['coefficient']+=1
     if p==1:assert bins[n]<=F(1,2)**n;ct['endpoint']+=int(p==1)
    if km>=0:
     assert F(2)**km*(1-s/8)**n<=F(1,2)**m
     ct['lower_tail']+=1
    else:assert lower==0
for m in (7,8,11,16,32):
 factor=1-F(256,63)*F(1,2)**m
 assert factor>=F(61,63)>0
 assert 1/factor<=F(63,61)
 assert F(64,63)/factor<=F(64,61)
 ct['absorption']+=1
print('PASS',ct)
