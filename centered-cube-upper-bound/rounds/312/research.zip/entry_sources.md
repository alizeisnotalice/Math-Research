# R312 原始入口来源索引

范围：只核对 2026-10-07 的当前 joint budget 及其三份直接上游稿；这是来源索引，不是新数学认证或一般主定理证明。

## 原件定位与完整性

`current_joint_budget_20261007.md`及三份上游稿在以下目录都有副本：

- `/Users/zhengzhihao/Desktop/T/Math-Research/centered-cube-upper-bound/`
- `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/geom_20261006/`
- `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/`

三份上游 Markdown 在上述位置逐字节同一，SHA-256：

| 原件 | SHA-256 |
|---|---|
| `nonconcentrated_actual_far_interface_20261007.md` | `a47a695bc820f7380d0ee5331f93b1a4b6805a18dc66dc31ac0f1b3f18765b59` |
| `future_softness_moment_budget_20261007.md` | `65b7b74272606fc2433a9d32de6d1019564aecd4528fffbc4ca66bb196badfc9` |
| `joint_future_scale_budget_20261007.md` | `c182e55ae61944a32ce18b3fb180ce16dd25d52006216f12c8fef5a64d9e1f63` |

current joint budget 的 Desktop/T/Math-Research 与 output 副本 SHA-256 为 `1ff06b70a0d0d684a8adbe62bc59d571d41816b03a6c5815598401fa9a4c1d9f`。专用 repo 副本 SHA-256 为 `9a96880b3cee15dd3d3331d1fbbaf47020e3341b7fd1c86cbdabce248b81cbeb`；它在相同的入口段后另附续记，入口部分行 1–85 一致。

Rounds ZIP 定位到 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/002/research.zip::current_joint_budget_20261007.md`，内容对应 hash `1ff06b...`。对该 ZIP 成员名做定向检查，没有发现三份上游稿的同名成员；三份原件由上述工作目录副本提供。本次没有遍历全部 rounds 历史。

## FIRST 与 future-cap 桥

1. `nonconcentrated_actual_far_interface_20261007.md` §1，第 7–13 行：在完整正输入 `μ)、共同 `q∈[3λ/4,λ]` 下冻结实际硬赢家 `R(x)`、软度 `σ(x)`、物理尺度 `L_s(x)`；第 13 行明确写“原未截断 FIRST 给 `P_{σ,L_s}*μ(x)=q`”，并声明 future cap、GOOD、score、owntrace、出生、森林、唯一 LCA、共同重捕获、CP/GP、删除门均保留。
2. `future_softness_moment_budget_20261007.md` §1，第 7–17 行把这个合同完整写成
   `P_{σ,L_s}*μ(x)=q`，`P_{s,L}*μ(x)≤q (σ≤s≤1,L∈[a,b])`，以及硬带 `2λ<u(x)≤4λ`、`3λ/4≤q≤λ`、`C_h=16/3`。它还明确说这里只从当前 residual 切输出子集，“不为它重新选 FIRST”。第 19 行给核定义 `P_{s,L}=[(1−s)h+sφ]_L^{⊗n}`。
3. `joint_future_scale_budget_20261007.md` §1，第 11–29 行再次将 same actual selector 用于 `R_{far,lowav})：保留完整 `μ,W`、同一个 `q`、`σ(x)>1/n)、全部历史几何门；第 15–20 行给 `p_x(y)=P_{σ(x),L_s(x)}(x-y)>0)、`ρ_x=p_x,dμ/q` 和 `P_{σ,L_s}*μ=q`；第 25 行明确保留完整 future cap `s≥σ(x), L∈[a,b]Rightarrow P_{s,L}*μ(x)≤q`。
4. `current_joint_budget_20261007.md` 第 39 行明确说明 `R_lowS` 保留“原完整 FIRST/futurecap”及两个赢家、出生、共享森林、唯一 LCA、容量失败权、CP/GP、实际 early/history/continuation 和之前所有门。故对这条 2026-10-07 账链，`σ` 是被上游明确称为“当前实际 FIRST”的参数；完整 future cap 也随其同一 selector 逐层保留。这里不是从旧记号 `s(x)` 猜测 `s=σ`。

这解决的是该组 2026-10-07 接口文本内部的 selector 身份桥。它本身没有提供把 R107/R112/R292/R309 的所有旧 `s(x)` 逐一追溯为此 `σ` 的原始构造证明；若当前目标特指旧账而非这组冻结接口，历史跨版本身份链仍须另证。

## 入口式及其准确性质

`current_joint_budget_20261007.md` §3，第 74–85 行给出：

`λ|E| ≤ 2 B_paid + (4096/49) R_heavy`

并同时使用 §1 的来源账（第 34–39 行）：

`R_heavy ≤ F_n W + (49/8192) λ|E| + R_lowS.`

代回后 `(4096/49)(49/8192)=1/2`，所以其后续式为 `λ|E|≤4B_paid+(8192/49)F_nW+(8192/49)R_lowS`，再可按第 64–85 行对 lowS 使用容量放大分解。故题目所给入口系数的作用是将来源账中的半份 `λ|E|` 回代消去；单独看它不是 `B_paid` 的无条件全局上界，也不是闭合结论。第 3 行自述本稿是对所列上游接口的严格回代，不声称一般平方根定理。

## 原始门目标与缺口

上游非集中稿第 250–255 行（式 (27)）的结果含显式未支付项 `R_far,new`；第 255、257 行明言目标未闭合，且余项仍带 actual 门、source-once 和真实 first-jump 条件。future-softness 稿第 247 行说低平均支的实际付款/吸收仍待 hardband、nonconcentration、短壳、actual FIRST/future cap 等几何桥；joint-future 稿第 139 行也说 selector 未闭合空间目标、完整 actual 历史门仍未知。current joint budget 则把低支留作 `R_lowS`，并最终保留 `R_lowS,ℓ<δ`（第 85 行）。

因此，已有且可引用的桥是：真实完整输入上的 canonical actual FIRST 等式、完整 future cap、共同 `q`、以及实际 hard-layer target 所保留的完整历史筛选器；尚缺的是把剩余 actual hard/far/lowS 交通以已付费用控制或吸收的空间—几何闭合。不能把这条入口回代或 `R_far,new/R_lowS` 的登记当作该缺口已解决。
