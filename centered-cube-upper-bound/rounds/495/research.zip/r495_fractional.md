# R495：分数质量共轭的真实列收缩与累计失败账

本稿独立补充 `/tmp/r495_proof.md`，不修改其未闭质量势账。已证新结论是同一自然配置参考下的分数质量列收缩，以及由此得到的 \(O(1+L/T)\) 累计占用帽。非 rank 失败可以在明确的一次费用假设下吸收；rankhead 累计来源价尚未由此证明。

## 1. 合同及可合法重建的范围

沿 R486 geometry (1)–(3)：
\[
 \mu=f\,dx,\quad m_A=q_AR_A^n,\quad q\le q_A\le\lambda,
 \quad r=\lambda/q,\quad \nu=t\sigma,\quad0\le t\le S.
\]
自然状态为 \((A,s_A,x,F)\)，\(s_A\) 是独立 uniform mark，\(F\) 是增广序低于父的全部 raw PPP。\(J\) 是实际成功最大父核，\(H\) 是固定父、mark 的交集留点/差集补点来源刷新，\(P=JH\)。成功及历史限制只在正上界处丢掉，不转授给新父。

可先在原父边缘删除 \(t<\tau\)，一次损失至多 \(\tau X\)，再**明确重建**候选域也限制于 \(E_\tau=\{t\ge\tau\}\) 的分析链。其 \(t,m,q,f\) 均为原量，\(t\) 不重新归一；这不是声称旧链轨迹未变。下文对这条重建链以及原任意不可跨质量窗均成立。设当前窗口
\[
 0<m_-\le m_A\le m_+<\infty,\qquad L=\log(m_+/m_-).
\]
单个全 octave 窗可取 \(L=\log r+n\log(b/a)\)。\(\tau>S\) 时原流整体可用 \(\tau X\) 支付；以下取 \(0<\tau\le S\)。零流直接结束。

## 2. 闭尾原子及分数列

对固定来源 \(x\)，实际中心 CDF 为
\[
 G_x(u)=\int_{m_A\le u}t(A)c_A(x)\sigma(dA)\le rSu.
\tag{1}
\]
证明保 Lebesgue 中心：该集合包含于以 \(x\) 为中心、边长 \((u/q)^{1/n}\) 的盒，而 \(tq_A\le S\lambda\)。没有来源密度帽。

对任意 \(\alpha>0\)、\(m>0\)，含左端质量原子的 Stieltjes 分部积分给
\[
 \int_{[m,\infty)}u^{-1-\alpha}dG_x(u)
 =-m^{-1-\alpha}G_x(m-)
 +(1+\alpha)\int_m^\infty u^{-2-\alpha}G_x(u)du
 \le\frac{(1+\alpha)rS}{\alpha m^\alpha}.
\tag{2}
\]
无穷端项为零；实际质量有上界，更无边界问题。必须是 \(G(m-)\)，不能用 \(G(m)\) 丢掉阈值原子。

令 \(\mathsf M_\alpha=m_A^{-\alpha}\mathsf M\)。R486 整配置 Palm 分解显示，相对输出 \(\mathsf M_\alpha\) 的 raw 列密度准确为
\[
 d_\alpha(B,s_B,x)=\frac{m_B^\alpha}{T}
 \int_{\widehat A\succ\widehat B}
 m_A^{-\alpha}e^{-(v_x(\widehat A)-v_x(\widehat B))/T}
 \rho_x(d\widehat A).
\tag{3}
\]
删 void、mark 及窗口限制后，(2) 给
\[
 \mathsf M_\alpha J\le b_\alpha\mathsf M_\alpha,
 \qquad b_\alpha=\frac{(1+\alpha)rS}{\alpha T}.
\tag{4}
\]
同质量接收者由 uniform mark 展开；其输出前缀只是闭质量原子的一部分，故上述正上放有效。原成功门包括任意额外正限制，仍满足(4)。\(H\) 固定父质量并保持每父自然参考，所以
\[
 \mathsf M_\alpha H=\mathsf M_\alpha,\qquad
 \mathsf M_\alpha P^j\le b_\alpha^j\mathsf M_\alpha.
\tag{5}
\]
普通 Palm 列仍给 \(\mathsf MP\le\mathsf M\)。这保整 raw 配置，不是仅父投影估计。

## 3. 同一自然到达量的改进帽

写 \(q_j=d(\mathsf MP^j)/d\mathsf M\)，\(R=\mathsf M1\)。比较输入 \(\mathsf M\le m_+^\alpha\mathsf M_\alpha\)，得到逐点
\[
 0\le q_j(\xi)\le
 \min\{1,(m_+/m_A)^\alpha b_\alpha^j\}
 \le a_j:=\min\{1,e^{\alpha L}b_\alpha^j\}.
\tag{6}
\]
在 \(T\ge4rS\) 时选
\[
 \alpha=4rS/T\in(0,1],\qquad
 b_\alpha=\frac14+\frac{rS}{T}\le\frac12.
\]
故
\[
 \sum_{j\ge0}a_j\le
 A_*:=\left\lceil\frac{4rSL}{T\log2}\right\rceil+2
 \le3+\frac{4rSL}{T\log2}.
\tag{7}
\]
包括 \(L=0\) 与质量原子；\(j=0\) 计入。由(6)终端趋零，完整停止恒等式 \(R=\sum_j\int q_je\,d\mathsf M\) 继续成立。对 \(p\ge1\)，同样 \(q_j^p\le q_j\le a_j\)，但**一次费用的累计应用须使用同一核及同一静态参考**。

## 4. 可以吸收什么，尚不能支付什么

按实际首次失败互斥拆 \(e=e_{\rm rank}+e_{\rm nr}\)。例如 rankhead 是输入增广秩 \(v<\kappa T\)；高秩空样本可归入非 rank 的 Poisson count 失败。若在本稿重建的候选场及完整成功门下另已核
\[
 \mathsf M e_{\rm nr}\le
 \left(C_1/T+C_2e^{-\kappa/8}\right)R,
\tag{8}
\]
则不需条件独立或每代重置 PPP，直接用真实到达帽得
\[
 \sum_j\int q_je_{\rm nr}\,d\mathsf M
 \le A_*\left(C_1/T+C_2e^{-\kappa/8}\right)R.
\tag{9}
\]
R479 §3 的五项原基本成功门在原合同下给 \(C_1=144rS(S/\tau),C_2=1\) 的一次候选价；**此引用不认证**双中心外置、长边、全 raw no-hit、high-empty 或其他后来门在重建单窗下也自动满足同一常数。若存在额外静态失败项 \(E_{\rm extra}\)，(9)必须再加 \(A_*E_{\rm extra}\)，不得省略。父门完整核验决定(8)对总 \(e_{\rm nr}\) 的适用范围。

以下给(8)成立时无循环的显式参数。给 \(0<\varepsilon<1\)，取
\[
 T\ge\max\left\{4rS,\frac{12C_1}{\varepsilon},
 \sqrt{\frac{16C_1rSL}{\varepsilon\log2}}\right\},
 \quad
 \kappa\ge8\log\max\{e,2C_2A_*/\varepsilon\}.
\tag{10}
\]
于是 \(A_*C_1/T\le\varepsilon/2\)，另一项亦至多 \(\varepsilon/2\)，非 rank 累计价至多 \(\varepsilon R\)。固定 \(r,S,\tau,\varepsilon\) 及 \(C_1,C_2\) 时，\(T=O(\sqrt{1+L})\)、
\(\kappa=O(\log(2+L))\)。这是真正的累计非 rank 收据，**不是**只把一次失败率叫成累计付款。

另一方面，一次 rank 费确有
\[
 \mathsf M e_{\rm rank}
 =\int\min\{U(x),\kappa T\}\,\mu(dx)\le\kappa TW
\tag{11}
\]
（在同一 rankhead 定义下）。但本稿只推出累计价
\[
 \sum_j\int q_je_{\rm rank}\,d\mathsf M
 \le A_*\kappa TW,
\tag{12}
\]
在 \(T\asymp\sqrt L\) 时一般仍是 \(O(L\log L)W\)。不能把(11)直接替换(12)。若(8)覆盖全部其他失败，准确母账为
\[
 (1-\varepsilon)R\le
 \sum_j\int q_je_{\rm rank}\,d\mathsf M,
\]
再另计最初 \(\tau X\)；尚缺对右端的根阶来源结算。本稿改进累计密度深度并给出可吸收的非 rank 部分，未闭合完整目标。

## 5. 本机有理检查及范围

下列代码使用六次方质量，使 \(\alpha=1/3,1/2,2/3,1\) 的分数幂仍为有理数。检查闭尾与阈值原子部分保留、分数收缩参数，以及整数幂指数帽的有限和。不模拟实际成功历史，也不以有限值代替(1)–(12)证明。

```python
from fractions import Fraction as F
checks=0
def ck(x):
    global checks
    assert x
    checks+=1
for bases in [(1,), (1,2), (1,2,3), (2,3,4)]:
    ms=[b**6 for b in bases]
    for frac in [F(1),F(2,3)]:
        jumps=[frac*(m-(ms[i-1] if i else 0)) for i,m in enumerate(ms)]
        for alpha in [F(1,3),F(1,2),F(2,3),F(1)]:
            power=int(6*alpha)
            for i,m in enumerate(ms):
                tail=sum((jumps[j]/(F(ms[j])*bases[j]**power)
                          for j in range(i,len(ms))),F(0))
                cap=(1+alpha)/(alpha*bases[i]**power)
                ck(tail<=cap)
                marked=tail-jumps[i]/(2*F(m)*bases[i]**power)
                ck(0<=marked<=tail<=cap)
for T in [F(4),F(8),F(16),F(64)]:
    alpha=4/T
    ck(0<alpha<=1)
    ck((1+alpha)/(alpha*T)==F(1,4)+1/T<=F(1,2))
for k in range(8):
    sm=sum((min(F(1),F(2**k,2**j)) for j in range(k+20)),F(0))
    ck(sm<=k+2)
    ck(sm+F(2**k,2**(k+19))==k+2)
print(f'{checks} exact Fraction assertions PASS; fractional CDF algebra only.')
```

实际运行 stdout：`168 exact Fraction assertions PASS; fractional CDF algebra only.`。无浮点拟合、无完整原历史认证。
