# R495 独立终审

FINAL PASS（限定范围）。本轮在一次限制原父接受率后重建的全质量窗自然链上，全部非 rank 首次几何失败的真实累计停止费用可付为 ε_g R_τ；线性 rank 前一跳提升及其同一实际流的共同来源割回代成立。累计 rank 割的根阶来源价仍未证明，完整一般目标与原母账未闭合。

独立预审先于读取作者证明；最终复核白名单全部八件。结论仅涵盖以下准确范围。

1. **参考、原子及累计权。** 原父 t<τ 仅删除一次，损失≤τX；候选也限制到 E_τ，保完整 f、真实质量、原 t 及原父条件记录。单窗重建不是旧链同律，不迁移其累计费用。闭尾使用 G(m−)，保质量原子和增广 mark；整配置 Palm 上放给 M_αJ≤[(1+α)rS/(αT)]M_α。来源更新保父、mark 及该参考，故 α=4rS/T 时 q_j≤min(1,e^{αL}2^{-j})，总到达帽≤3+8rSL/T，终端趋零。
2. **全门及参数。** 已核 count、Gram/最大行、旧命中、整 raw no-hit、双中心外置和短边的自然参考联合上界；其中中心外置仅用积分界，不提升为逐状态概率。C_g=512rS(S/τ)+4rS+S 保守覆盖各门。给定 T 的两项吸收分别≤ε_g/2，因此 Σ⟨q_j,e_G⟩≤ε_gR_τ，包含 j=0；固定 r,S,τ,ε_g 时 κT=O(√(L+1)log(L+2))，参数依赖保留。
3. **线性停止与同流割。** 完整后 H 提升保后来源/标签；投影仅用于不依这些后标签的割核。b_R 必须保输出 mark。|ρ_R|=Σ⟨q_j,e_R⟩−M(e_R)≤R_τ，初始 M(e_R)≤κTW。R494 逐族比较及 R493 有限正测度分配在这个同一 ρ_R 上给出主稿无 p 恢复因子 2 的不等式。Λ≥0、ε_mix>0、ε_g+ε_mix<1 及日后回代分母 d>0 均须保留；不能假定 Θ_R≤ν_τ。
4. **另一质量势尝试。** proof 的 raw 最大父恒等式、刷新漂移、正 Jensen 差、负成功/失败项及跨质量补偿符号成立。绝对质量势的单位不同，除回当前质量会恢复未付放大净功；其旧 p-stop 不与本轮线性流混用。原母账所有未付槽和入口倍率继续保留。

实际独立隔离复现使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`：geometry 1 项符号尾积分及 36 组有理参数；fractional 168 项 Fraction；proof 29 项 Fraction；numeric 565 项 exact/Arb。stdout 与冻结 replay 一致，共 799 项报告核验单位，并非独立几何模型数。numeric JSON 仅移除 compute_index.seconds 后逐字段一致，规范 SHA256 为 `27a5bea0ce28133f839afab480d20e7979e8ac2cdddbe1fa35cf1b9a802d93db`。25 组完整参数例与 2 个不合完整选参的边界探针、384-bit Arb ceil/log/exp 证书均在声明范围；不认证连续历史，也不以有限实验外推阶数。

尚未支付的是同一线性 rank 流的全局共同 D 来源割。新收到的研究建议不是证明依据；本报告不认证完整中心立方体根阶上界。

## 最终输入绑定

- `r495_main.md`: `51963105af94f525359adc35f44a46b953918e4474b18ca30b2822a356f665aa`
- `r495_fractional.md`: `f55876ccb590f1e5dd5bfb85cd5697fe548a6bfa55f095d84c154575a88e709d`
- `r495_geometry.md`: `69b22fd812b35756ed249d1655878a399e3e0b7989bb62915c9546d703f3cdf8`
- `r495_proof.md`: `0713bee9791eb55d9a9af3f5b8666d16421e43b87de3b48e2ccf5deb94e33a57`
- `r495_numeric.md`: `2fcaf8329a622c708b0b7e320a4c6fe2544c99be7305d6a748649a6529c65bf6`
- `r495_numeric.py`: `2f82ead6e41fd8bcf51de681e9aa740bc16b8871864adf91db7d64a54980fba3`
- `r495_numeric.json`: `d616ef923eceb1aa604f51ebb4e9d5b6c3f49e345e6336e05ff4702b19a377aa`
- `r495_replay.json`: `35b6161b16e20a13d9148a6f457683835d291bc9ed8c78ecdba0a614697911aa`
