# R495：整族重分配的真实刷新漂移与质量放大净功

保 R494 的全部 \(\Theta\)、\(\rho=\sum_j\Gamma_j\)、分母 \(G\) 和原链 \(P=JH\)。本稿给出一个作用于同一实际 \(p\)-stop 的全 cut 比较：lower 重分配可由低捕获刷新漂移控制，但仍留下带明确负成功质量的质量放大净功。该净功尚未获来源价，故没有证明完整根阶预算。

## 1. 一个原配置上定义的可积分测试

自然状态为 \(\xi=(A,s_A,x,F)\)，\(F\) 是全部 raw lower 点，含原子重复标签。定义
\[
 Y(\xi)=\sum_{C\in F}\frac{m_C}{m_A},\qquad
 c_0=\frac{rS}{T},\quad \theta=\frac12.
\]
当前 \(q_j=(P^*)^j1\)、\(h_j=J^*q_j\)。对真实成功 \(J\)，选 raw 最大父 \(B\)，输出 raw lower 族是 \(F\setminus\{B\}\)，所以逐边精确有
\[
 Y(\omega)=\frac{m_A}{m_B}Y(\xi)-1. \tag{1}
\]
这不是把筛后的 \(F_0\) 冒充自然参考配置。

记 \(p_C=\pi_B(Q_C)\)。给定实际输出状态 \((B,s_B,x,F_{<B})\)，R486 的交集留点/差集补点刷新给准确条件均值
\[
 HY=\sum_{C\in F_{<B}}\frac{m_C}{m_B}p_C
 +\int_{\widehat C\prec\widehat B}
 \frac{m_C}{m_B}p_C[1-c_C(x)]\,\Lambda_B(d\widehat C). \tag{2}
\]
这里 \(\Lambda_B=\nu(dC)ds_C/(Tm_C)\)，包含同带及 mark。第二项由真实 CDF
\(\int_{m_C\le m_B}t(C)c_C(z)\sigma(dC)\le rS m_B\)
及 \(z\sim\pi_B\) 的 Tonelli 积分控制为 \(c_0\)。成功最大父对**全部 raw lower**的 Gram 行和至多 \(1/2\)，且 \(m_C\le m_B\)，故每个实际点 \(p_C\le\gamma_{BC}\le\theta\)。于是
\[
 HY\le\theta Y+c_0\quad\text{在 }h_j>0\text{ 的支持上}. \tag{3}
\]
不声称(3)对任意自然配置成立；它依靠原成功门。未刷新或继承旧 pair。

同一 CDF 给静态初值
\[
 \int Yd\mathsf M\le c_0R. \tag{4}
\]
证明是先固定输入 \(A,x\)，用 PPP 均值
\(E Y=(Tm_A)^{-1}\int_{\widehat C\prec\widehat A}t(C)c_C(x)\sigma(dC)ds_C\le c_0\)，再按原 \(\nu\pi_A\) 积分。它是初值 \(O(c_0R)\)，不是一次 \(W\) 付款。

## 2. p-Jensen 加上原质量边的联合望远镜

对 \(p>1\)，设
\[
 a_j=\int q_j^pYd\mathsf M,\quad
 b_j=\int h_j^pYd\mathsf M,\quad
 m_j=\int q_j^pJ1d\mathsf M,\quad
 z_j=\int q_j^peYd\mathsf M,
\]
以及保原成功边的质量放大项
\[
 c_j=\int q_j(\xi)^p\mathsf M(d\xi)
 J^{\rm rec}(\xi,d\omega)
 \left(\frac{m_A}{m_B}-1\right)Y(\xi). \tag{5}
\]
这里小写 \(m_j\) 是一代成功质量，区别于盒质量 \(m_A\)；没有把两者混用。

由 \(h_j^p\le J^*(q_j^p)\)、(1)，
\[
 b_j\le a_j+c_j-m_j-z_j. \tag{6}
\]
由 \(q_{j+1}=Hh_j\)、\((Hh_j)^p\le H(h_j^p)\)、\(H=H^*\) 及(3)，
\[
 a_{j+1}\le\theta b_j+c_0\int h_j^pd\mathsf M
 \le\theta b_j+c_0m_j. \tag{7}
\]
合并得到完整有限时域账
\[
 \boxed{(1-\theta)\sum_{j<N}b_j
 \le a_0-a_N+\sum_{j<N}c_j
 -(1-c_0)\sum_{j<N}m_j-\sum_{j<N}z_j.} \tag{8}
\]
这是有利的负成功质量与真实失败加权项，不能只保正 \(c_j\) 后宣称改进。若要保完整 Jensen 信用，可定义
\[
 \epsilon_j^J=a_j+c_j-m_j-z_j-b_j\ge0,
 \qquad \epsilon_j^H=\theta b_j+c_0m_j-a_{j+1}\ge0;
\]
(8)的右边再减 \(\sum(\epsilon_j^J+\epsilon_j^H)\) 后恰为等号。它们不是 R491 无权 Jensen 差，不能再把同一信用重复扣入另一账。

原每带质量比至多 \(e^L\)，R491 的几何终端帽保证 \(q_j,h_j\le\min(1,e^Lb_0^j)\)。结合(4)，上述所有和绝对可积，且 \(a_N\to0\)；\(c_j\) 可暂用 \((e^L-1)\int q_j^pY\) 仅证有限性，不把它记作根阶费用。

### 质量加权的准确加强及恢复费用

令 \(V(\xi)=m_AY(\xi)=\sum_{C\in F}m_C\)。同一实际边与刷新满足
\[
 V(\omega)=V(\xi)-m_B,\qquad
 HV\le\theta V+c_0m_B\quad(h_j>0). \tag{8a}
\]
设
\(a_j^{\rm abs}=\int q_j^pV\)、\(b_j^{\rm abs}=\int h_j^pV\)、
\(u_j^B=\int q_j^pJm_B\)、\(z_j^{\rm abs}=\int q_j^peV\)，全部积分仍对原参考/成功核。重复(6)–(7)的正 Jensen 步骤，得到无质量放大项的真预算
\[
 \boxed{(1-\theta)\sum_{j<N}b_j^{\rm abs}
 +(1-c_0)\sum_{j<N}u_j^B+\sum_{j<N}z_j^{\rm abs}
 \le a_0^{\rm abs}-a_N^{\rm abs}
 \le c_0\int m_A\,d\mathsf M.} \tag{8b}
\]
\(c_0<1\) 沿原参数成立。初值用同一 PPP 均值乘 \(m_A\)，没有换参考。右侧单位是“流质量乘盒质量”，不是根阶 \(W\) 价；例如只知其至多 \(c_0m_+R\)，不得免费抹去盒质量。

恢复(10)所需 \(b_j=\int h_j^pV/m_B\) 时，逐边出现的准确补偿是
\[
 \left(\frac1{m_B}-\frac1{m_A}\right)V(\xi)
 =\int_0^\infty \frac{V(\xi)}{t^2}
       1_{\{m_B\le t<m_A\}}\,dt. \tag{8c}
\]
它积分后恰为(5)的 \(c_j\)。质量原子不需补项，等质量时两边均零。按来源/父的细质量层分别除质量，可改善层内比值，但不能漏掉(8c)在每个实际跨层跳上的完整通量。若仅限制到原不可跨带，再以其最小质量除(8b)，得到
\(\sum_jb_j\le2c_0\sum_b\kappa_bR_b\)，其中 \(\kappa_b\le e^L\)；这不是可用根价。暂无已证可求和的跨层误差能将(8b)恢复为(10)所需无权预算。

## 3. 直接回到同一 \(\Theta\) 的全来源 cut

固定任意可测 \(D\)，写 \(b_D(C)=(1-2\pi_C(D^c))_+\in[0,1]\)。同一记录的 signed lower 重分配是
\[
 \delta_D=\sum_{C\in F_0\setminus\{B\}}
 \frac{m_C}{G}[b_D(C)-b_D(B)].
\]
保 \(G\) 给逐记录一致上界
\[
 (\delta_D)_+\le\frac{G-m_B}{G}
 \le\frac{Y(\omega)}{1+Y(\omega)}=:r_Y(\omega)\le\min(1,Y(\omega)). \tag{9}
\]
最大父仍有原份额，未把 child 当作 \(H\) 固定的父。

R492 的实际记录权是
\(q_j\mathsf M J^{\rm rec}H\,q_{j+1}^{p-1}e\)。对(9)作正上放后可投影到 \(\omega\)，得到
\[
 \int (\delta_D)_+d\Gamma_j
 \le\int h_j(\omega)H(\omega,d\xi')
 q_{j+1}(\xi')^{p-1}e(\xi')r_Y(\omega)d\mathsf M(\omega).
\]
在这个同参考二点积分上应用数值 Young
\(uv^{p-1}\le u^p/p+(p-1)v^p/p\)，第一项用 \(He\le1,r_Y\le Y\)，第二项用 \(Hr_Y\le1\) 和 \(\mathsf MH=\mathsf M\)，严格得
\[
 \boxed{\sum_{j<N}\int (\delta_D)_+d\Gamma_j
 \le\frac1p\sum_{j<N}b_j
 +\frac{p-1}{p}\sum_{j<N}\int q_{j+1}^pe\,d\mathsf M.} \tag{10}
\]
此式对所有 \(D\) 使用同一右端，无逐 cut 更换原流。第二项至多 \((p-1)R/p\)，R491 可以选择 \(p-1\) 小以吸收；第一项由(8)控制，但其质量放大净功仍未付。

因此，若定义同一全 \(\rho\) 的 maxparent cut（不加 R493 good 门），其到 full-mixture cut 的增加至多
\[
 \frac{p-1}{p}R+
 \frac{1}{p(1-\theta)}
 \left[a_0+\sum_j c_j-(1-c_0)\sum_jm_j-\sum_jz_j\right]. \tag{11}
\]
可以继续保(8)的两笔负余量。式(11)是实际全流比较，不是把 \(\Theta\) 假装成 \(\nu\)。它本身仍不能付最大父的净来源通量。

## 4. 本轮确定的缺桥与适用限制

一个有内容的下一比较必须在同一实际边上支付
\(\sum c_j-(1-c_0)\sum m_j\)，或与 R494 的 maxparent signed 通量联合抵消；只以 \(m_A/m_B\le e^L\) 控制它会丢失目标。\(H\) 的真实低捕获漂移已由(2)–(3)进入账，不能再次以“刷新独立”把 \(c_j\) 删除。

静态(4)可给小 \(c_0R\)，但只直接使用每代自然列帽会回到 \(\sum_j\min(1,e^Lb_0^j)\) 深度损失。这里尚无 \(\mu(D)\) 或一次 \(W\) 价控制质量放大净功，也尚无将其与 maxparent 源通量共同结算的定理。本稿保留新联合漂移工具及实际 Young 接口，不把它们称为完整付款。

## 5. 本机精确小检查

核验只针对条件刷新均值、原 raw 最大父的质量恒等式和 Young 方向。取 \(m_A=8,m_B=4,m_C=1\)，\(\pi_B(Q_C)=1/16\)，候选 latent 强度 \(1/8\)。它们可来自非均匀完整来源的相交区间质量；脚本不认证统一 qband、Lebesgue 接收选择器或原成功历史。

```python
from fractions import Fraction as F
from itertools import product
checks=0
def ck(x):
    global checks
    assert x
    checks+=1
pC=F(1,16); intensity=F(1,8); ratio=F(1,4)
for count,cold in [(0,0),(0,1),(1,1),(2,1),(4,1)]:
    # Conditional source refresh; positive count requires current capture.
    direct=pC*(count*ratio+intensity*ratio*(1-cold))
    formula=count*ratio*pC+intensity*ratio*pC*(1-cold)
    ck(direct==formula)
    ck(formula<=F(1,2)*count*ratio+F(1,64))
for count in (1,2,4):
    Yin=F(4+count,8); Yout=F(count,4)
    ck(Yout==2*Yin-1)
for h,v,e,r in product((F(1,3),F(1)),(F(1,4),F(1)),
                        (F(1,2),F(1)),(F(1,3),F(1))):
    ck(h*v*e*r <= (h*h+v*v)*e*r/2)
print(f'{checks} exact Fraction assertions PASS; local conditional algebra only.')
```

实际隔离重放 stdout：`29 exact Fraction assertions PASS; local conditional algebra only.`。上述一般证明不依赖有限检查。
