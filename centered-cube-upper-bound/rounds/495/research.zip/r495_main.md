# 第495轮：分数质量共轭支付全部非低秩累计几何失败

## 目标与结论状态

对原实际接受记录保真实来源 μ=f dx、勒贝格接收测度 σ=q_A dA、父边缘 ν=tσ（0≤t≤S）、质量 m_A=q_AR_A^n、单比例带 a≤R_A≤b≤2a、q≤q_A≤λ、r=λ/q。W=μ(全空间)，X=σ(E)。一般中心立方体一致弱型 n^(1/2+o(1)) 上界仍未证明。

本轮严格新增的付款：在原父 t≥τ 上重建的单个全质量窗自然链中，全部非低秩几何首次失败在真实到达密度下的累计费用不超过 ε_g R_τ。这里保原条件历史，不声称与旧 K 或原多窗链同律。初始低秩价格 κTW 达到根阶乘对数；累计低秩共同来源割仍未付。不是整个原剩余积分闭合。

## 完整当前账

先删原父 t<τ，一次损失 R_orig−R_τ≤τX。所有候选也限制到 E_τ；原 t、质量、来源与条件记录不重新归一。令 P_0=rS、H_0=S/τ、L=log r+n log(b/a)、C_g=512P_0H_0+4P_0+S。

选 0<ε_g<1，
\[
 T\ge\max\{4096P_0H_0,6C_g/\varepsilon_g,
 \sqrt{16P_0C_g(L+1)/\varepsilon_g}\},\quad
 \alpha=4P_0/T,\quad
 \delta_{\rm succ}=1024P_0H_0/T,\quad
 \kappa=8\log(4/\delta_{\rm succ}).
\]
T 可向上取整。自然测度 M 总量为 R_τ；真实成功核 J 与固定父/mark 来源更新 H_src 定义 P=JH_src。原子安全闭尾和保完整 raw 配置的 Palm 公式给
\[
 M_\alpha P\le b_\alpha M_\alpha,\quad
 M_\alpha=m_A^{-\alpha}M,\quad
 b_\alpha=\tfrac14+P_0/T\le\tfrac12.
\]
同时 MP≤M，故真实到达密度 q_j 满足
\[
 q_j\le\min(1,e^{\alpha L}2^{-j}),\qquad
 \sum_j\|q_j\|_\infty\le3+8P_0L/T.
\]
完整首次停止 e=1−J1 按低秩先检测分为 e_R 和 e_G。全成功门自然积分 M(e_G)≤C_gR_τ/T；其依据包括原 count、Gram、旧命中、整 raw no-hit、中心外置及短边门，详见 geometry。中心外置价格只为积分界，不误用逐状态条件界。于是
\[
 \sum_j\int q_je_G\,dM\le\varepsilon_gR_\tau.
\]
包括 j=0，无额外初始 geo 费用。固定 r,S,τ,ε_g 下 T=O(√(L+1))、κT=O(√(L+1)log(L+2))，常数依赖不能隐藏成绝对常数。

终端 q_j→0 给精确线性恢复 R_τ=Σ_j⟨q_j,e⟩。保后 H 的实际低秩停止权，定义完整提升
\[
 d\widetilde\rho_{R,j}
 =q_j(s)M(ds)J^{\rm rec}(s,d\omega)H_{\rm src}(\omega,ds')e_R(s').
\]
其前状态投影 ρ_R,j=q_j M Jrec b_R(\widehat B)，其中 b_R=∫π_B(dz)1_{v_z(\widehat B)<κT}，保输出 mark。完整提升保后来源与历史；只在定义来源割核不依后标签时投影。总质量 |ρ_R|=Σ_j⟨q_j,e_R⟩−M(e_R)≤R_τ，且 M(e_R)≤κTW。

对同一实际成功低 Gram 族 F_0，以权 m_C/G_F 预定义 Θ_R（不依 D）。R494 逐族割比较及 R493 连续分配对有限 ρ_R 适用。取来源容量 Λ≥0，固定 ε_mix>0 和 M_mix≥max(3/2,3/(2ε_mix)) 后
\[
 \Delta_{\rm mix,rank}(\Lambda)
 =\sup_{D\text{ 可测}}\left\{
 \int(2\pi_C(D)-1)_+d\Theta_R-\Lambda\mu(D)\right\},
\]
\[
 \boxed{(1-\varepsilon_g-\varepsilon_{\rm mix})R_\tau
 \le\kappa TW+\Lambda W+\Delta_{\rm mix,rank}(\Lambda).}
\]
无需 p 次恢复的因子 2。要求 ε_g+ε_mix<1。若将来同一割得 Δ≤aR_τ+ε_cut X+B_n，且 d=1−ε_g−ε_mix−a>0，才有
\[
 R_{\rm orig}\le(\tau+\varepsilon_{\rm cut}/d)X
 +[(\kappa T+\Lambda)W+B_n]/d.
\]
当前未证明该割估计，尤其不能假定 Θ_R≤ν_τ。粗累计低秩帽仍是 κ(3T+8P_0L)W，非根阶。

## 对新收到第486轮后建议的核对

收到《第486轮后：联合估计攻坚建议》（2026-10-21）。它是研究建议，不作为已证依据或额外用户命令。其优先目标是自然配置链的真实累计停止费用，吻合本轮方向。建议中的逐代低捕获平方和 E1 与高捕获自然强度 H2，均不能单独支付累计停止；本轮不通过它们宣布闭合，也不重做已完成的历史工具搜索。

本轮采取分数质量共轭直接支付非低秩累计费用，补充了建议要求的有价连接；并非已构造其待证测试 B1–B2。剩余低秩流可以继续探索同参考能量配对，但所有测试必须针对上述准确 ρ_R 与全局共同 D。来源—位移相关路线仍仅备选，不从旧链搬运费用。

## 失败尝试与附件分工

fractional 给闭尾、Palm、到达帽的独立推导；geometry 核全成功门和线性割回代。proof 保留一个不可替代的精确质量势障碍：绝对质量势有耗散，除以当前质量后必回生跨层增量；它尚无 W 价格。该附件的 p 次停止权属于另一条尝试，不与本轮线性 rank 流混用。旧共同分母插点尝试须同步改变实际密度、筛后族与 G，未产生可付小量，不计本轮正成果。

## 验证、范围和复现

本机独立 Python 环境实际隔离重放：geometry 1项 SymPy 尾积分及36组有理参数；fractional 168项 Fraction；proof 29项 Fraction；numeric 565项 exact/Arb，共799项报告核验单位（并非799个独立模型）。numeric 覆盖25个完整参数例及2个明确不满足完整选择的边界探针，L 从0至10^24，初探、边界压力与扩大范围分别记载。Arb 384 bits 验证 log/exp 包围与 ceil，T及费用使用有理/整数算术。数值结果不认证原连续历史、也不用于外推一般阶数。

详见 r495_replay.json 的实际解释器、stdout 与数值规范 SHA。numeric.py 解压后在自身目录运行；其 JSON 比较仅排除动态 compute_index.seconds。各证明的 Python 代码块可独立运行。保详细 LaTeX，不编译 PDF。独审在读取作者稿前先检查量词及原成功门，再对最终绑定版本复核。

## 母账与下一步

本轮只替换当前固定比例/密度带的分析机制。原入口倍率仍为 64(128/119)/(1−32δ_old−16η_old)，原初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例及全尺度拼接尚未支付的槽继续保留；分析参数 δ_succ 不等于 δ_old。各 ε 须按总入口倍率分配，不重复使用。

下一步唯一关键目标是上述同一线性 rank 终止流的联合来源割：在保全部实际权、质量分母与标签下证明 ΛW+Δ 的根阶预算，或一个统一收缩且终端有价的递推。不能以进一步减少非 rank 常数替代此目标。当前没有完整一般证明。
