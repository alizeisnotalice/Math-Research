# R495：分数质量权与全质量窗几何失败的累计付款

本稿的正结果是：在保原条件记录、重新构造的单个全质量窗自然链中，**非低秩的全部几何首次失败可累计支付为任意小的 \(\varepsilon_gR\)**。这不是仅一代估计。低秩停止的累计根阶来源价仍未证明；不宣称完整目标闭合。最初的共同分母有符号换序尝试仅在末节保留范围结论。

## 1. 原输入、一次低接受率删除和重建范围

\(\mu=f\,dx\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)，且 \(a\le R_A\le b\le2a\)。原接受记录的父边缘是 \(\nu=t\sigma\)，\(0\le t\le S\)，\(R=|\nu|\)、\(X=|\sigma|\)。零流单列为零。

固定 \(0<\tau\le S\)，先把原记录限制到 \(E_\tau=\{t\ge\tau\}\)。其损失至多 \(\tau X\)。令
\[
 \nu_\tau=1_{E_\tau}\nu,\quad R_\tau=|\nu_\tau|,\quad
 H=S/\tau\ge1,\quad P_0=rS,
 \quad L=\log r+n\log(b/a).
\]
在 \(E_\tau\) 上保原条件记录及其全部历史；旧双来源相对 \(\pi_A^2\) 的条件密度至多 \(H\)。所有候选父也限制在 \(E_\tau\)。以 \(\nu_\tau\) 重建增广质量秩、自然参考 \(\mathsf M\)、实际成功算子 \(J\) 和自然来源更新 \(H_{\rm src}\)，记 \(P=JH_{\rm src}\)。这里 \(H\) 与 \(H_{\rm src}\) 含义不同。

只用一个包含全部父质量的窗口 \([qa^n,\lambda b^n]\)。原成功门仍为样本数、总 Gram 行量、最大父行、旧来源命中、整 raw no-hit、双中心外置和长边等；不将新父赋予旧记录的历史。重建链不是先前多窗口链的同 law，故不迁移旧累计费用；以下重新证明所用预算。自然配置只在参考下为 Poisson，实际成功后的条件配置不作此假设。

## 2. 原子安全的分数质量列界

对任意 \(\alpha>0\)，置 \(\mathsf M_\alpha=m_A^{-\alpha}\mathsf M\)。自然输出最大父 \(\widehat B\) 的质量加权 raw 列密度为
\[
 d_\alpha(\widehat B,x)=\frac{m_B^\alpha}{T}
 \int_{\widehat A\succ\widehat B}
 m_A^{-\alpha}e^{-(v_x(\widehat A)-v_x(\widehat B))/T}
 \rho_x(d\widehat A),\qquad
 \rho_x(d\widehat A)=\frac{c_A(x)}{m_A}\nu_\tau(dA)ds_A.
 \tag{1}
\]
这是保最大点 void 与全部 lower raw 配置的 Palm 公式。原成功门仅在上界中删除。

真实匹配与中心 Lebesgue 体积给
\(G_x(u)=\int_{m_A\le u}c_A(x)\nu_\tau(dA)\le P_0u\)。因此包含下端原子的闭尾满足
\[
 \int_{[m,\infty)}u^{-1-\alpha}dG_x(u)
 =-m^{-1-\alpha}G_x(m-)
 +(1+\alpha)\int_m^\infty G_x(u)u^{-2-\alpha}du
 \le\frac{(1+\alpha)P_0}{\alpha m^\alpha}.
 \tag{2}
\]
增广 mark 只解决质量原子的次序，(2) 没有丢同质量部分。删去 (1) 的 void 与次序限制，得到
\[
 \boxed{\mathsf M_\alpha J\le b_\alpha\mathsf M_\alpha,\qquad
 b_\alpha=\frac{(1+\alpha)P_0}{\alpha T}.} \tag{3}
\]
\(H_{\rm src}\) 保父及 \(\mathsf M\)，也保持 \(\mathsf M_\alpha\)，所以同界适用于 \(P\)。另有原自然列 \(\mathsf MP\le\mathsf M\)。取
\[
 \alpha=4P_0/T\le1,\qquad b_\alpha\le\tfrac12.
\]
质量窗比较遂给真实到达密度
\[
 q_j=(P^*)^j1\le\min\{1,e^{\alpha L}2^{-j}\},\qquad
 \sum_{j\ge0}\|q_j\|_\infty\le
 \frac{\alpha L}{\log2}+3
 \le\mathcal D:=3+\frac{8P_0L}{T}.
 \tag{4}
\]
因此该改进深度为 \(O(1+P_0L/T)\)，不是原固定质量权的 \(O(L/\log T)\)。它使用同一个实际 \(J\)，没有改变停止权。

## 3. 全部非低秩首次失败的自然参考价格

保原参数关系
\[
 T\ge4096P_0H,\qquad
 \delta_{\rm succ}=1024P_0H/T\le1/4,\qquad
 \kappa=8\log(4/\delta_{\rm succ}).
\]
令 \(e=1-J1\)。先把低秩事件 \(v_A<\kappa T\) 定为第一互斥失败，记 \(e_{\rm head}\)；其余实际失败记 \(e_{\rm geo}=e-e_{\rm head}\ge0\)。没有逐代低 \(t\) 事件，因为已在定义参考前删除一次。

在自然参考下、限制 \(v_A\ge\kappa T\) 后，旧工具给以下 union 上界；重叠事件不影响上界：

- Poisson 数目不足：\(e^{-\kappa/8}=256P_0H/T\)。
- R479 其余四类坏事件：总量概率至多 \(144P_0H/T\)；其中旧命中门可与全 raw no-hit 重复，此处保守计价。
- 整 raw 命中旧来源对：固定 \((A,x)\) 用旧 pair 条件帽与真实 Schur 行界，期望命中数至多 \(8P_0H/T\)。
- 双中心包含：**自然参考积分**至多 \(2P_0R_\tau/T\)，不是逐状态概率界。
- 最大父短欧氏边：至多 \(Sb_nR_\tau/T\)，\(b_n\le3^{-n}\le1\)。

这些估计在全质量窗仍有效：中心边长仍为单 octave，Schur/闭尾未要求质量窗窄；删除原次序只用于正上界。故以
\[
 C_g=512P_0H+4P_0+S
\]
得到
\[
 \mathsf M(e_{\rm geo})\le\frac{C_g}{T}R_\tau.
 \tag{5}
\]
特别，(5) 没有把来源质量替换成中心体积，也没有声称每个当前历史下失败概率都如此小。

由 (4) 与 (5)，这次可以完整累计：
\[
 \boxed{\sum_{j\ge0}\langle q_j,e_{\rm geo}\rangle
 \le\mathcal D\frac{C_g}{T}R_\tau.} \tag{6}
\]
对 \(q_j^p\)、\(p\ge1\) 同样成立，因为 \(q_j\le1\)。固定 \(\varepsilon_g>0\)，选择
\[
 \boxed{T=\max\left\{4096P_0H,
 \frac{6C_g}{\varepsilon_g},
 \sqrt{\frac{16P_0C_g(L+1)}{\varepsilon_g}}\right\}.} \tag{7}
\]
则 \(3C_g/T\le\varepsilon_g/2\)，
\(8P_0LC_g/T^2\le\varepsilon_g/2\)，所以 (6) 至多
\(\varepsilon_gR_\tau\)。所有常数依赖均显式；固定 \(r,S,\tau,\varepsilon_g\) 时 \(T=O(1+\sqrt n)\)、\(\kappa=O(\log(n+2))\)。这是本稿实际新增的累计付款。

## 4. 精确剩余：低秩头部，不是全部停止已付

增广秩对每个真实来源把 \(\rho_x\) 推为 \([0,U(x)]\) 上 Lebesgue 测度，质量原子由 mark 摊开。因此单次
\[
 \mathsf M(e_{\rm head})
 =\int\min\{U(x),\kappa T\}\,\mu(dx)
 \le\kappa TW.                               \tag{8}
\]
(3) 保证 \(q_j\to0\)，所以完整停止恒等式为
\[
 R_\tau=\sum_j\langle q_j,e\rangle,\qquad
 (1-\varepsilon_g)R_\tau
 \le\sum_j\langle q_j,e_{\rm head}\rangle.    \tag{9}
\]
原输入只另付一次 \(R-R_\tau\le\tau X\)。

唯一剩余几何步骤是对 (9) 右端的**实际到达权低秩头部**给根阶来源价。直接使用 (4)、(8) 仅得
\[
 \sum_j\langle q_j,e_{\rm head}\rangle
 \le\mathcal D\kappa TW
 =\kappa(3T+8P_0L)W,                          \tag{10}
\]
仍为 \(O(n\log(n+2)W)\)，不能把 (8) 逐代误当一次费用。非低秩累计已经从该缺口中剥离；下一步不必再次支付低 Gram、外置、no-hit 等几何失败。没有证明 \(\Delta_{\rm mix}\) 根价，也没有把新链的参考支配当旧链历史继承。

## 5. 无需 p 次恢复的准确 rank 停止流

低秩事件只依当前父、mark、来源，不依 lower 配置。\(H_{\rm src}\) 保父及 mark，并将来源更新为 \(\pi_B\)，故
\[
 H_{\rm src}e_{\rm head}(\widehat B,x,F)
 =b_R(\widehat B):=
 \int\pi_B(dz)1_{v_z(\widehat B)<\kappa T}.
 \tag{11}
\]
一般必须保输出 mark，不能把 \(b_R\) 误写成与 mark 无关。

展开同一 \(J\) 为保完整成功记录的 \(J^{\rm rec}\)，定义
\[
 d\rho_{R,j}=q_j(s)\mathsf M(ds)J^{\rm rec}(s,d\omega)
 b_R(\widehat B(\omega)),\qquad
 \rho_R=\sum_{j\ge0}\rho_{R,j}.
 \tag{12}
\]
则 \(|\rho_{R,j}|=\langle q_{j+1},e_{\rm head}\rangle\)，
\[
 |\rho_R|=\sum_j\langle q_j,e_{\rm head}\rangle
 -\mathsf M(e_{\rm head})\le R_\tau.
\]
这仍保同一个实际成功族及全部 pre 标签；不是将记录刷新为原历史，也没有删去未来 rank 停止权。

R494 的逐族来源割比较对任意这样的有限正记录测度适用，不要求 \(p>1\)。令
\[
 \Theta_R=\int\rho_R(d\omega)
 \sum_{C\in F_0(\omega)}\frac{m_C}{G_F}\delta_C,
 \quad
 \Delta_{\rm mix,rank}(\Lambda)=\sup_D
 \left[\int(2\pi_C(D)-1)_+d\Theta_R-\Lambda\mu(D)\right].
\]
选辅助分配帽
\(M_{\rm mix}\ge\max\{3/2,3/(2\varepsilon_{\rm mix})\}\)。
原连续分配及 R494 比较给
\(|\rho_R|\le\Lambda W+\Delta_{\rm mix,rank}
 +\varepsilon_{\rm mix}R_\tau\)。结合 (6)、(8)、(12)，得到完整无平方恢复因子的接口
\[
 \boxed{(1-\varepsilon_g-\varepsilon_{\rm mix})R_\tau
 \le\kappa TW+\Lambda W+
 \Delta_{\rm mix,rank}(\Lambda).}              \tag{13}
\]
原输入再加一次 \(R-R_\tau\le\tau X\)。这剔除了全部非低秩累计费用；剩余仍须在同一 \(\rho_R\) 上证明 rank 混合割预算，不能援引旧 \(p\)-链的未付割或假定 \(\Theta_R\le\nu_\tau\)。若日后有
\(\Delta_{\rm mix,rank}\le aR_\tau+\epsilon X+B_n\)，且
\(d=1-\varepsilon_g-\varepsilon_{\rm mix}-a>0\)，则
\[
 R\le\tau X+\frac{\epsilon X+(\kappa T+\Lambda)W+B_n}{d}.
\]
当前没有证明这个最后的 cut 估计；(13) 本身不宣称根阶闭合。

## 6. 原共同分母尝试的范围记录

在旧 \(\rho\) 上，最大父减权与 lower 增权的精确差为
\[
 \int d\rho\sum_{C\ne B}\frac{m_C}{G}
 [b_D(C)-b_D(B)],\qquad b_D(C)=(2\pi_C(D)-1)_+.
\]
自然输出密度为 \(\chi_j=h_jH_{\rm src}(q_{j+1}^{p-1}e)\)。Mecke 插点必须同时把 \(\chi_j,F_0,G\) 改为插点后的值，不能用 raw 总质量替代筛后 \(G\)。仅用原闭尾仍回到 \(b_0\sum_j a_ja_{j+1}^{p-1}R\)，未得统一小量。此路线未计新付款；本稿主结果改为 (6)–(7)。

## 7. 本机复核与可复现范围

指定 Python 实际运行下列自含脚本，输出
`PASS fractional-tail symbolic identity and 36 exact parameter cases; no native-history simulation`。
解析证明包括 CDF、Palm 和全部几何门；有限计算仅核尾积分系数及参数吸收，不替代原生历史证明。较早另运行24项有限 Poisson 系数/共同分母核验，不计本主命题证据，亦不需归档重复脚本。

```python
from fractions import Fraction as F
from math import isqrt
import sympy as sp
u,a,m=sp.symbols('u a m', positive=True)
assert sp.simplify((1+a)*sp.integrate(u**(-1-a),(u,m,sp.oo))
                   -(1+a)/a*m**(-a))==0
checks=0
ceil=lambda x:-(-x.numerator//x.denominator)
def csqrt(x):
 k=isqrt(x.numerator//x.denominator)
 return k if F(k*k)>=x else k+1
for P in [F(1,2),F(1),F(3)]:
 for H in [F(1),F(4)]:
  for L in [F(0),F(1),F(64)]:
   for eps in [F(1,4),F(1,16)]:
    S=P/2; Cg=512*P*H+4*P+S; A=8*P
    T=F(max(ceil(4096*P*H),ceil(6*Cg/eps),
            csqrt(2*A*Cg*(L+1)/eps)))
    alpha=4*P/T; b=(1+alpha)*P/(alpha*T)
    D=3+A*L/T
    assert 0<alpha<=1 and b<=F(1,2)
    assert 1024*P*H/T<=F(1,4)
    assert D*Cg/T<=eps
    assert (256+144+8)*P*H+2*P+S<=Cg
    checks+=1
print('PASS fractional-tail symbolic identity and',checks,
      'exact parameter cases; no native-history simulation')
```
