from pathlib import Path
from fractions import Fraction as F
import math,json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def zero(x):ck(x.is_finite());ck(x.contains(0))
def ceilq(x):return (x.numerator+x.denominator-1)//x.denominator
def ceilsqrt(x):
 k=math.isqrt(x.numerator//x.denominator)
 if k*k*x.denominator<x.numerator:k+=1
 ck(k*k>=x);ck(k==0 or (k-1)*(k-1)<x)
 return k
P,H,S,T,L,A,Cg,eps=sp.symbols('P H S T L A Cg eps',positive=True)
alpha=4*P/T
ck(sp.cancel((1+alpha)*P/(alpha*T)-(sp.Rational(1,4)+P/T))==0)
ck(sp.expand((A*L/T+3)*Cg/T-(A*L*Cg/T**2+3*Cg/T))==0)
ck(sp.simplify((1024*P*H/T)/4-256*P*H/T)==0)
ck(arb(2).log()>ar(F(1,2)))
profiles=[(1,1,F(1),F(1,4)),(3,1,F(1,4),F(1,16)),(1,2,F(2),F(1,16)),(3,2,F(1,2),F(1,4))]
records=[]
for idx,(r,Sv,tau,ep) in enumerate(profiles):
 Pv=F(r*Sv);Hv=F(Sv)/tau;cv=512*Pv*Hv+4*Pv+Sv;av=8*Pv
 scales=[0,1,16,256,10**6,10**12]+([10**24] if idx==0 else [])
 for lv in scales:
  t1=4096*Pv*Hv;t2=6*cv/ep;t3sq=2*av*cv*(lv+1)/ep
  tv=max(ceilq(t1),ceilq(t2),ceilsqrt(t3sq))
  ck(tv>=t1);ck(tv>=t2);ck(tv*tv>=t3sq)
  al=4*Pv/tv;bb=F(1,4)+Pv/tv;de=1024*Pv*Hv/tv
  ck(0<al<=1);ck(bb<=F(1,2));ck(0<de<=F(1,4))
  ck(al<=F(1,1024)/Hv)
  raw=ar(al*lv)/arb(2).log();ceilball=raw.ceil();ci=ceilball.unique_fmpz();ck(ci is not None)
  ci=int(ci);d=ci+2
  if lv==0:zero(raw);ck(ci==0)
  else:ck(raw>ci-1);ck(raw<ci)
  upperD=av*lv/tv+3;ck(d<=upperD)
  fee_linear=3*cv/tv;fee_quad=av*lv*cv/(tv*tv);actual_fee=d*cv/tv
  ck(fee_linear<=ep/2);ck(fee_quad<=ep/2);ck(actual_fee<=fee_linear+fee_quad);ck(fee_linear+fee_quad<=ep)
  kap=8*(ar(4/de)).log();em=(-kap/8).exp()
  zero(em-ar(256*Pv*Hv/tv));ck(kap>0)
  # Exact numerator/tail expressions use no guessed success-geometric gate.
  cost=kap*tv;normal=cost/(ar(lv+1).sqrt()*ar(lv+2).log())
  ck(cost.is_finite());ck(normal.is_finite())
  records.append(dict(profile=idx,r=r,S=Sv,tau=str(tau),eps=str(ep),P=str(Pv),H=str(Hv),Cg=str(cv),A=str(av),L=str(lv),T=str(tv),T_branches=dict(linear_geometry=str(t1),linear_fee=str(t2),quadratic_square=str(t3sq)),alpha=str(al),b_alpha=str(bb),delta=str(de),kappa=str(kap),exp_minus_kappa_over8=str(em),D_ceil_input=str(raw),D_alpha=d,D_upper=str(upperD),fee_3Cg_overT=str(fee_linear),fee_ALCg_overT2=str(fee_quad),actual_nonrankfee_upper=str(actual_fee),total_split_fee=str(fee_linear+fee_quad),kappa_times_T=str(cost),kappaT_over_sqrtL1_logL2=str(normal)))
# Two deliberate algebra boundary probes, not admitted full parameter configurations.
pressure=[]
Pv=Hv=F(1);Sv=1;cv=F(517);ep=F(1,4)
for name,tv in [('alpha_b_boundary',F(4)),('delta_boundary',F(4096))]:
 al=4*Pv/tv;bb=F(1,4)+Pv/tv;de=1024*Pv*Hv/tv
 if name=='alpha_b_boundary':ck(al==1);ck(bb==F(1,2));ck(de>F(1,4))
 else:ck(de==F(1,4));ck(tv<6*cv/ep)
 ck(tv<max(4096*Pv*Hv,6*cv/ep))
 pressure.append(dict(name=name,P='1',H='1',S='1',eps='1/4',L='0',T=str(tv),alpha=str(al),b_alpha=str(bb),delta=str(de),D_alpha=2,actual_fee_at_L0=str(2*cv/tv),admissible_full_choice=False,reason='Boundary algebra only: does not satisfy the complete max choice for T.'))
result=dict(scope='Parameter/ceil/fee certificates only; no original J,H geometry/history gate certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r495_numeric.py',seconds=time.perf_counter()-start),checks=checks,admissible_cases=len(records),boundary_probe_count=len(pressure),formulas=dict(T='ceil max(4096PH,6Cg/eps,sqrt(2ACg(L+1)/eps))',b_alpha='1/4+P/T',D='ceil(alpha L/log2)+2 <= 8P L/T+3',fee='D Cg/T <=3Cg/T+ACg L/T^2 <=eps/2+eps/2',kappa='8 log(4/delta)=8 log(T/(256PH)), NOT (8 log4)/delta',exponential='exp(-kappa/8)=delta/4=256PH/T',growth='For fixedP,H,eps,S, T<=C sqrt(L+1), C=max(4096PH,6Cg/eps,sqrt(2ACg/eps))+1; kappa T=O(sqrt(L+1)log(L+2)). This analytic estimate, not finite-case extrapolation, supplies the order.'),records=records,boundary_probes=pressure,decision='The supplied T formula pays both nonrank fee terms and all advertised parameter inequalities on the fixed tested profiles/scales. Actual full parameter T keeps alpha and delta well inside their loose boundary caps. No original geometric gate follows.',errors='T and rational fee terms exact Fraction/integer sqrt. Ceil certified by unique Arb integer and strict neighboring inequalities (L0 exact). Logs/exponentials384-bit Arb; no float scan.')
(ROOT/'r495_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;25 admissible parameter cases,2 rejected boundary probes;no geometry claim')
