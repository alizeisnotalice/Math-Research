# R495：完整参数选择、ceil 与累计非 rank fee

实际执行 25 个完整参数例和 2 个明确不满足完整 T 选择的边界探针，565 项 exact/Arb 断言通过。仅参数证书，不认证原 J/H、cloud、几何门或 history。断言计数含整数平方根、ceil、有限性和残差，不是 565 个独立模型。

## 输入范围与三阶段

四个代表 profile 为 (r,S,τ,eps)：

(1,1,1,1/4)，(3,1,1/4,1/16)，(1,2,2,1/16)，(3,2,1/2,1/4)。

它们覆盖 r=1,3、S=1,2、τ=S 或 S/4、eps=1/4 或 1/16；不把所有笛卡尔组合机械重复。P=rS、H=S/τ≥1。

初探 L=0,1,16；扩大 L=256,10^6,10^12，另仅 profile 0 取 L=10^24。共 4×6+1=25。压力探针另取 profile 0、L=0 的 T=4P 与 T=4096PH，仅核边界代数并标为 rejected，不列入完整参数通过数。

## 精确参数及解析 fee 账

Cg=512PH+4P+S，A=8P，取

T=ceil max(4096PH,6Cg/eps,√[2ACg(L+1)/eps])。

T 完全由 Fraction、整数平方根及向上取整得到；sqrt 分支不用浮点。每项 T 下界均精确检查。

α=4P/T，bα=(1+α)P/(αT)=1/4+P/T，δ=1024PH/T。

SymPy 核 bα 化简。完整选择蕴含 α≤1、bα≤1/2、δ≤1/4；各例直接精确复核，另核更强 α≤1/(1024H)。本次最大 α=1/3102、最大 δ=512/6157<.084，因此真正完整参数远离 α=1 和 δ=1/4 的松边界。

Dα=ceil(αL/log2)+2。Arb 384 bits 给 ceil 唯一整数，并直接核它位于相邻整数之间；L=0 单独核精确零。由 log2>1/2，

Dα≤8PL/T+3=AL/T+3。

随后有两个独立付款项：

Dα Cg/T≤3Cg/T+ACg L/T²，

3Cg/T≤eps/2，ACg L/T²≤eps·L/[2(L+1)]≤eps/2。

SymPy 核两项拆分代数，每例以 Fraction 核最终 Dα Cg/T≤eps。有限数值不是这一解析估计的证明来源。

## κ 的括号与增长

本任务 κ 必须理解为

κ=8 log(4/δ)=8 log[T/(256PH)]，

所以 exp(−κ/8)=δ/4=256PH/T。不能误读成 (8log4)/δ。各例以 Arb 严格核此指数身份和 κ>0。

固定 P,H,eps（r≥1 给 S≤P）时，Cg≤P(512H+5)。完整 max 与整数向上取整给 T≤C√(L+1)，其中 C 可取

max(4096PH,6P(512H+5)/eps,√[16P²(512H+5)/eps])+1。

故 κT=O(√(L+1)log(L+2))。这是显式解析上界；表中归一化比值只是数值实施检查，不从有限样本外推阶数，也没有把 C 省作绝对常数。

profile 0 的摘要（小数仅便读，严格值见 JSON）：

| L | T | Dα | Dα Cg/T |
|---|---:|---:|---:|
| 0 | 12408 | 2 | 1/12 |
| 1 | 12408 | 3 | 1/8 |
| 16 | 12408 | 3 | 1/8 |
| 256 | 12408 | 3 | 1/8 |
| 10^6 | 181902 | 34 | .09663445 |
| 10^12 | 181901073 | 31727 | .09017461 |
| 10^24 | 181901072014434 | 31724827678 | .09016844 |

各例均保留 κT 及 κT/[√(L+1)log(L+2)] 的 Arb 包围；这些比值依 profile 常数，并非普适数值常数。

## 边界压力与排除

T=4P=4 时 α=1、bα=1/2，但 δ=256，且不满足两个大的 T 下界。它只核 α/b 的边界，不是有效成功参数。

T=4096PH=4096 时 δ=1/4，但 T<6Cg/eps=12408。L=0 实际 fee=517/2048>1/4，也直接说明仅满足 δ 门不足以付款。这两个探针在 JSON 标 admissible_full_choice=false。

决策：给定的完整 max 选择同时支付两项非 rank fee，并确保 ceil 与参数门；本轮没有发现算术冲突。原几何 gate 是否提供这些 fee、是否允许实际选择此 T，仍是作者证明义务。

## 复现

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r495_numeric.py`

实际 Python 3.12.14、SymPy 1.14.0、python-flint 0.9.0；Arb 384 bits。T、ceil 前的有理量和 fee 为 exact Fraction/integer；log、exp、D 的 ceil 输入为严格 Arb 包围。零残差先检查有限性，无 float 容差或随机扫描。

固定 stdout：`PASS 565 exact/Arb assertions;25 admissible parameter cases,2 rejected boundary probes;no geometry claim`。

输出在脚本自身目录；compute_index 记解释器、版本、命令及动态耗时。归档白名单仅 `/tmp/r495_numeric.py`、`/tmp/r495_numeric.json`、`/tmp/r495_numeric.md`。限定任务完成，停止。
