# R658 target: one balanced legal coarse law with a full net gain

The centered-cube `n^(1/2+o(1))` weak-(1,1) upper bound is still unproved. The sole main task is a uniform balanced **coarse full-gain existence theorem**, at the already fixed global `epsilon_*`, for every required finite near-score old state. Choose a legal positive exploratory old source first, then a finite real old partition and a single joint anchor law with each clone's exact Euler marginal. Recompute true images, capture eligibility, availability, the delta=1/100 baseline, real owner volumes and the actual fixed-owner entropy optimizer from the entire tuple.

For every source tolerance zeta, the same law must satisfy

`R E |(hat_mu_H-mu_H)(f_Z)| <= zeta V`,

`E D = E[W-R Q'] >= cV-C L M`, with `L=C0 sqrt(n) polylog(n)`.

Here `f_Z=sum alpha_jl 1_Aj` is the common adaptive old-membership-cell coverage probe. Systematic shifted-grid cell tags already give pathwise coarsened old-cell TV at most `B M_H/(2r)` with the exact continuous row marginals. This is not continuous full TV and does not bound arbitrary new-C, row-dependent or image-loss probes. The outstanding issue is full gain **within** that balanced coupling class, rather than a new stand-alone source-selection interface.

Keep the complete account

`D=E-O+F+RS=W-RQ'`,

`E D=R[(Pi-E P_Z)+E d_Z]-(R-T0)Pi-K-T_r`,

`d_Z=P_Z-Q'_Z`, `K=T0 Pi-Wreach`, `T_r=Wreach-E W`.

Pi is the true reachable-cube linear packing benchmark; it is not actual entropy. No term K, T_r, physical loss indicator, fill, unavailable old tag or sampling row may be dropped. A direct full-D proof needs no extra unused Gamma fee. If a tagged reduction is actually used, charge its single proved source error once. Keep one endpoint allowance at most `4LM`, any used owner error `R E tau`, and exploration/near-score errors in the same physical units; no per-cell, block, clique, scale or LP-iteration M budget.

The R657 fixed-trial constrained LP can detect unused-load/whole-face exclusion missed by all optimal-dual row slacks. For one fixed legal p, use

`ell_j(p,t)=epsilon p_j/min(P-m_j+epsilon W-t, P_Nj+epsilon W_Nj-m_j)`,

`G_p(t)=P-max{m beta: H beta<=1, beta>=ell(p,t)}`.

From zero its feasible nondecreasing iteration remains at most the actual `d(p)`. Its exact dual allows a nonoptimal cover only with the excess-mass penalty `||nu||-P`. Obtain a lower G from a dual upper bound on the constrained LP, not a primal feasible value alone. There is no proved endpoint theorem for switching p to maximize G at every iteration. Compare independent finite fixed-p trial chains or supply a new theorem before switching. Any useful certificate must pay the whole net above. The old mu is a feasible cover of mass M, not a free optimal dual; the gap `g=M-P` in a capped old-source pressure formula is a single genuine price. The heavy old class `mu(A)>M/2` has owner volume `<2M`, which may pay part of the leading cV once while retaining every row in the full action.

Exact common-k synchronized nested refinement is now available: split every coarse piece equally, scale old lambda and a by 1/k, and give all children the SAME parent anchor. Image unions, grouped baseline/owner polytope, actual grouped entropy optimizer, minimum Q', W, total O/F, D and weighted source empirical measure are invariant after a compatible future-owner recut. Thus an already balanced successful coarse witness persists at arbitrarily fine nested common multiples. It creates no balance, independent samples or receiver exhaustion. Independent repetition has source concentration and Wreach convergence but no theorem retaining a small block's optimized full gain. Do not combine those two different laws as if they were one experiment.

The r=2 positive-width coupled improvement and r=4 balanced atomic witness are finite decision evidence. r=3–5 are atomic; none supplies global epsilon_* calibration or near-score status. The toy W=3 branches force kappa'>4. The r=5 candidate's Q' increases and its full gain comes from W; none of the candidates is certified optimal. Do not extend toy scans as the main task or infer a general budget from finite enumeration. The next proof must construct or rule out the simultaneous balanced full-gain mechanism in the actual calibrated class.
