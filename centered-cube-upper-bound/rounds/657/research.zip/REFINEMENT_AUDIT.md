# R657 independent synchronized nested-refinement audit

**Verdict: PASS for the precise common-k synchronized refinement below.** It exactly preserves min-Q, W, full D and the weighted empirical source tuple by tuple after a compatible owner-volume lift. It can retain a legally balanced coarse action's gain at every finite nested multiple. It does not create more independent samples, repair an incorrect/coarsely unbalanced law, or prove a uniform root-order budget.

The derivation below was completed independently before the first attempted read of the author's `JOINT_SCALING_TARGET.md`, when that file was not yet present. The subsequently supplied author proof and its systematic balancing section are independently reviewed and bound in §7 below. No author conclusion is used as a proof premise.

## 1. Precise refinement and old-state legality

Start from one finite coarse labelled state, with actual disjoint positive old pieces I_b, old volumes v_b, actual entropy weights lambda_b, genuine old source mu and one realized anchor tuple X_b. Coarse labels may already be clones. Use the **same integer k** for every coarse label and partition each I_b into k deterministic equal positive pieces `I_(b,l)` before sampling. Give each child its parent's A_b/B_b and set

`v_(b,l)=v_b/k`, `lambda_(b,l)=lambda_b/k`,
`m_(b,l)=m_b`, `u_(b,l)=u_b`, `a_(b,l)=a_b/k`,
`X_(b,l)=X_b` for all l.

The first three identities follow from the actual entropy/KKT cloning theorem: at fixed parent packing total, the child log optimum has equal old weights. The old objective changes by exactly `-epsilon sum_b v_b log k`; its actual aggregate optimizer and all Q,V,M,R,kappa,H,E and old score are unchanged. The same old source is an AC KKT witness for every child.

Every child has its parent's one-row Euler marginal if the coarse law had it, but these k children are synchronized. This is a legal coupled action, not k new independent draws. In the globally calibrated all-finite class every finite refinement remains at the same epsilon_* and near-score tolerance. Refinement cannot cure a coarse state that was outside that calibrated domain.

Because anchors and growth parameters coincide within a parent,

`C_(b,l)=C_b`, `B'_(b,l)=B'_b`,
`E_b=disjoint union_l E_(b,l)` modulo receiver Lebesgue-null sets.

Thus image union, receiver union W and total incoming volume are identical. Only disjointness and coverage modulo null sets are needed: the affine maps preserve the overlap/omission null sets. Arbitrary measurable pieces may have positive-measure topological boundaries; no boundary regularity of the pieces is assumed. The statement is for each finite k, with all ownership equalities understood modulo null sets.

## 2. Eligibility and the delta baseline

On an image point, each incoming parent contributes exactly one incoming child. All its children have the same old A, high/low status and new C. Hence capture of every high incoming cube is equivalent before and after refinement, and each eligible coarse parent contributes exactly one eligible child at that point.

On fill, every covering coarse parent contributes all k covering children. The fine image union equals the coarse one, so fill status itself agrees. Therefore the projected fine eligible set is exactly the coarse eligible set, both on images and fill.

The uniform baseline projects exactly:

`sum_l p0_(b,l)=p0_b`.

On images the eligible count is the same as the coarse count; on fill both each group's count and the total count are multiplied by the **same** k. If a child has zero eligible measure it is unavailable and deleted only from new variables. Such deletions do not change the identity a.e. In particular any parent with positive fill eligibility gives all k children positive eligibility there. A coarse group is available exactly when at least one child is available.

This is why arbitrary variable-multiplicity refinement cannot be assumed equivalent: on fill, k_b children would give parent share `k_b/sum_eligible k_i` rather than the original uniform share. Independent child anchors also destroy the image-partition and repeated-C argument.

## 3. Projection of the owner polytope

Let pi aggregate child owner volumes by parent. Every fine eligible assignment projects to a coarse eligible assignment. Conversely any coarse fractional eligible assignment lifts: on images send its parent density to the unique eligible child; on fill distribute it among the k eligible children. The same lifting applies to free densities. Along with the baseline identity this proves

`pi(P_delta,fine)=P_delta,coarse`.

It holds with all zero-eligible children removed. All remaining child volumes have their positive baseline floors. Finite atom allocations and nonatomic cuts realize the lifted fine volumes; a deterministic finite allocation/tie rule gives the usual measurable lift.

**Necessary scope qualification:** an arbitrary feasible coarse **volume vector** or volume policy can be lifted preserving its aggregate p. It is not generally possible to preserve an already fixed pointwise future-owner partition verbatim: fine atom baselines may force positive child mass in a portion assigned entirely to another parent by that particular coarse cut. Recutting the future partition while preserving the coarse volumes is allowed and is sufficient for Q/D preservation. The old incoming I refinement remains fixed. A theorem claiming pointwise equality of every pre-existing future owner set would be stronger and is not certified here.

## 4. Actual entropy optimization and exact full-gain preservation

Fix any fine feasible p and write `p_b=sum_l p_(b,l)>0` on available groups. Fine packing constraints depend only on `beta_b=sum_l alpha_(b,l)` and are exactly the coarse packing constraints. At fixed beta, maximizing the fixed-p child log terms yields

`alpha_(b,l)=beta_b p_(b,l)/p_b`

on available children, with zero coefficients on unavailable children. The group objective equals

`m_b beta_b+epsilon p_b log beta_b`
` +epsilon sum_l p_(b,l)log[p_(b,l)/p_b]`.

The last term is constant **in beta** for this fixed fine p. Hence beta is precisely the actual coarse entropy optimizer for the projected p, and

`Q_fine(p)=Q_coarse(pi p)`.

This proves the conclusion for the actual optimizer, not a comparison packing. It also records the correct variational constant: the raw new log objective has the displayed allocation-dependent constant, not a universal constant when p varies. If the legacy joint-B perspective objective is considered, its `p log p` terms cancel that constant and the optimized B value equals the coarse perspective value.

Since owner-polytope projection is onto,

`min_(fine p)Q_fine=min_(coarse p)Q_coarse`.

Any particular coarse feasible volume vector can also be lifted with exactly its Q, regardless of whether it minimizes Q. With W and old R unchanged, its full gain `D=W-RQ` is identical. This holds for every coarse anchor tuple and therefore for its expectation under the lifted coupled law. It preserves the exact min-Q value even if different tie choices lead to different partitions.

Total O and F are also unchanged under image priority: incoming image union and total image volume are identical, so `O=sum ell-|union E|` and `F=W-|union E|` agree. More refined label/high-loss allocations need not agree for arbitrary recuts; the certified statements concern the complete gain and compatible aggregated entropy state.

## 5. Empirical source, eta and TV do not improve

Synchronized refinement preserves the weighted empirical measure exactly:

`sum_(b,l)(a_b/k)delta_(X_b)=sum_b a_b delta_(X_b)`.

The same identity holds on the high subfamily because u is unchanged. Under the compatible entropy lift, `sum_l alpha_(b,l)=beta_b`, so the old-A coverage probe f, its signed empirical discrepancy, and its actual high correction are also identical tuple by tuple. No new source or error account is introduced.

Old score and eta are preserved exactly, with no cumulative k-dependent score fee. A coarse tau-near-minimum owner lift has the same Q error tau; it is not multiplied by k. Any genuine positive-width whole-D comparison already proved for the coarse min-Q policy transfers exactly through the compatible refinement, without invoking a new arbitrary-r perturbation constant.

There is **no TV gain**. If the coarse construction had N independent blocks of size b, synchronization produces the same N blocks with size kb and total clone count multiplied by k. The conservative factor `sqrt((kb)B/(kr))` is unchanged, matching exact empirical preservation. A coarse law with incorrect row marginals stays incorrect. A coarse action with uncontrolled empirical correction stays uncontrolled. In particular, this bridge cannot simultaneously retain a small r=2 gain and claim the concentration of many newly independent blocks for free.

For corresponding repeated-C duals, linear P, neighborhood P_N/W_N and row pressure weights also aggregate as in the coarse problem. Together with the baseline/eligible projection, the R656 eligible MAX support values and finite pressure maps are unchanged. This is consistent with exact min-Q preservation; it does not create additional geometric exposure or unused-load credit.

## 6. Conclusion and bounded verification

The synchronization requirement closes the piece-geometry gap for **nested refinements of a fixed coarse experiment**, unlike independent repetition of a small block. Once a coarse globally admissible action is genuinely balanced and has a legal full-gain estimate, every finite common-k synchronized refinement retains it. Finding such a coarse full-class budget, or controlling a different independently repeated large experiment, remains separate work. There is no uniform root-order conclusion.

One bounded installed-Python/SymPy check verified the within-group actual entropy KKT equality and exact joint-perspective cancellation. Eligibility, projection, unavailable-label treatment and empirical identities above were checked analytically. No new numerical pool, solver campaign, author-file edit or Git operation was used.

## 7. Supplied author proof, systematic old-cell balance and binding

**Final consistency verdict: PASS with the a.e.-partition qualification above and the common-old-cell-test scope below.** The actually read author file is `/tmp/ccu_r657/JOINT_SCALING_TARGET.md`, SHA-256

`56cd3466a44ad76282faff3bd95e8e04528c68b0c001e138ada2bdb7dd389815`.

Its §§1–2 agree with the independent eligibility/baseline, owner-polytope and actual-optimizer proofs above. The converse allocation argument proves a lift of coarse feasible volumes; it need not preserve a pre-existing pointwise future-owner cut. Its image partition identity is correctly stated modulo null sets. The phrase about ordinary null boundaries must not be interpreted as assuming every arbitrary measurable I piece has a null topological boundary; no such assumption is required for the result.

The systematic construction in §3 also passes independently. For an old row j, assign its positive-mu old membership cells consecutive half-open probability intervals `[a_s,b_s)` in `[0,1)`, of lengths pi_js. The r points `(U_j+l/r) mod 1` form a uniformly shifted grid. The count in one cell is

`ceil(r(b_s-U_j))-ceil(r(a_s-U_j))`,

interpreting the real shifted lattice over one period. This count belongs to `{floor(r pi_js),ceil(r pi_js)}` for every phase under the half-open convention, and is exactly r pi_js when that number is integral. Uniform marginal U_j makes each clone tag have probability pi_js. Arbitrary dependence among the row phases does not change these facts.

For each positive source cell D_s, sampling `Z_s~mu|Ds/mu(Ds)` **independently of the phases**, and assigning it to all clones with that tag, gives every clone its correct continuous Euler marginal. Old membership is constant on D_s modulo the fixed old cube boundary null sets, so the same conditional cell law applies to every row using that cell. The cell points may depend on one another while preserving these marginals; if they were allowed to depend on the phases without a conditional-law guarantee, the argument would fail. The author explicitly supplies the needed phase independence.

For the high class the weighted cell discrepancy is exactly

`e_s=sum_(j in H)a_j[N_js/r-pi_js]`.

The per-row count bound and the fact that zero-probability cells receive no tags imply

`(1/2)sum_s|e_s| <= (1/(2r))sum_(j in H)a_j B_j <= B M_H/(2r)`

pathwise. Both high empirical and mean measures have mass M_H. This is **coarsened total variation on the fixed finite old membership algebra**, not full continuous-measure TV between an empirical atomic measure and an AC source.

The actual adaptive coverage test `f_Z=sum_j(sum_l alpha_jl)1_Aj` is constant on that old algebra and is in [0,1] there a.s. Actual packing and `A_j subset C_jl` give the old-A packing inequality Lebesgue-a.e.; each positive-mu old membership cell has positive Lebesgue volume, so its constant load cannot exceed one. The conditional AC cell samples avoid the fixed old cube boundaries. This proof does **not** use cross-row independence or a claim that probes avoid every new C boundary.

Consequently the same pathwise coarsened-TV bound applies to the signed discrepancy of this common adaptive old-cell test. Taking expectation and using `MR=(1+kappa)V<=5V` gives the author's conservative

`R|Gamma_H| <= BMR/(2r) <= 5BV/(2r)`.

The normalized full-source TV choice `r>=B/(2 eta)` and the absolute source-mass choice `r>=BM/(2 eta)` are correctly distinguished. Integral row counts make the high and full old-cell discrepancies vanish pathwise without requiring rational a_j.

This conclusion is not a bound for arbitrary row-dependent probes, actual image-loss windows, new-C membership functions, or tests varying within an old cell. Such quantities cannot be substituted for the common old-A coverage f merely because their individual row marginals are correct. The author confines its claim to the finite old algebra and does not make that substitution.

Finally, the author's §§4–5 retain the important gap: systematic balance need not preserve a successful full-D joint law, synchronized refinement does not improve a coarse discrepancy, and its receiver remainder is not driven to zero. Its proposed balanced full-gain existence theorem is expressly unproved. Thus the supplied text is consistent with the certified refinement and balance mechanisms, without a new uniform near-score or root-order budget claim.

Audit complete for this author-file hash and the stated mathematical scope; no further research or computation was launched.
