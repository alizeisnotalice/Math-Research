# R657 numeric artifact metadata audit

Checked every SHA-256 explicitly declared in `/tmp/ccu_r657/numeric/*.md` against the bytes of its named file in that directory, including script/JSON shorthand attached to each report. Three references were inconsistent, all for `race_compare.py`:

- `numeric/race_compare.md`: recorded `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d36ff568182862a978bbf5c1fb`.
- `numeric/balanced_r4.md`: same incorrect value for the required dependency.
- `numeric/scaling_summary.md`: same incorrect value for the required dependency.

The actual current file SHA-256 is `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`. Corrected these three numeric Markdown metadata references only. All other declared numeric-directory file/hash pairs matched their actual bytes, including load_model.py/json, cycle_exact.py/json, race_transport.py/json, race_compare.json, balanced_r4.py/json, scaling_compute.py, scaling_r3.json, scaling_r4.json, scaling_width.py/json, and scaling_r5.py/json/costs/verify.py/verify.json/monitor.jsonl.

**Provenance limitation:** the wrong and actual race_compare.py hash share a long prefix and differ in the remainder, consistent with a bad transcription, but a hash correction alone cannot prove that the present script is byte-for-byte the script used for every earlier result. The saved race_compare.json has no embedded source hash; its script and JSON file modification timestamps are both 2026-10-29 20:46:27 local time (one-second resolution). No evidence examined establishes a substantive change after computation, but the source/output identity is not independently established by this metadata audit. If exact executable provenance is required, replay and compare mathematical output (excluding timestamps) or obtain an independently trusted earlier script hash; changing the recorded hash is not a substitute for replay. Scaling and balanced results that import this script inherit that limitation.

The prior wrong hash also occurs in reports outside numeric/, including AC_COUPLING_AUDIT.md; those files were outside this task's permitted editing scope and were left unchanged. No Python, JSON, data, numeric solver result, or other top-level report was modified; no computation was rerun. All checks used actual SHA-256 over file bytes.

Release follow-up by main agent: full current race_compare.py replay reproduced all five cases (408 tuple records), with every JSON field identical after excluding only time_seconds. See numeric/race_replay_audit.json. Current-script reproducibility is now verified; historical source identity is not inferred solely from the corrected hash.
