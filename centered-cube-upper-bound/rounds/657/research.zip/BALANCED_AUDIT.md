# Independent balanced r=4 audit

The 14-point atomic witness passes the requested support-level checks. It has all twelve correct one-row Euler marginals and each supported tuple assigns exact empirical mass 4 to each of the four old source atoms. Its complete D strictly exceeds the recorded independent mean, conditional on that full-enumeration mean interval. This is a marginal-preserving *dependent* coupling; it does not satisfy an independent-anchor requirement and does not establish positive-width, ε* calibration, near-score, multiple-block or general-dimensional conclusions.

The audit reconstructs the three balanced sequences: 6 outer-left, 24 center, 6 outer-right, totaling 864 possible tuples. Without reevaluating all 864, it checks the balanced/full indices and all 14 supplied anchors. Every support weight is positive, the total is 1, and each of the 12 row coordinates has each required marginal probability exactly. Each tuple has two outer contributions of 7/5 and one center contribution of 6/5 at each source atom, giving 4 exactly. Thus the aggregated empirical atomic measure equals the old μ, so discrepancies vanish for common fixed source-cell probes. This does not independently establish vanishing of a row-dependent or adaptive Γ involving arbitrary new C probes; that requires its precise definition and a separate argument.

Every supported tuple was recomputed with the original `race_compare.py` evaluator using its unmodified 96 Fraction root bisections; each exact W matches and each D bracket is enclosed by the supplied interval. The weighted candidate enclosure is [565216883567/250000000000, 226086753427/100000000000]. Subtracting the saved `scaling_r4.json` independent upper bound gives the strictly positive lower bound 2709976086863467/4096000000000000. Full independent mean is accepted from the earlier audited enumeration code; this check does not recompute its 65536 costs. No 864-case scan, r5 work, solver or CVXPY was run.

Single-process reproduction: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/balanced_audit.py > /tmp/ccu_r657/numeric/balanced_audit.json`, Python 3.12.14 standard-library Fraction. Input script `balanced_r4.md` lists an outdated hash for race_compare.py; the actual bytes and verified binding are in the audit JSON.

SHA-256: `balanced_audit.py` c2762bb8f6ea05a67dabd07bcc572c4ef321d61fcc896395ecf6d804c792df12; `balanced_audit.json` 588024e6e74c82395241e7ba7b41e56c3f1bcb71c24c02ec72955dd688843bc6. Inputs' actual hashes appear in the JSON.

## Suggested R657 numeric archive whitelist and portable dependencies

Preserve the `numeric/` folder layout. Suggested final evidence, subject to the main report's final references:

- Fixed-p finite geometry and floor LP: `cycle_exact.py/json/md`, `load_model.py/json/md`, `floor_inputs.json`, `verify_floor_lp.py`, `floor_audit.json`, `FLOOR_LP_SCHEMA.md`.
- r=2 race and transport: `race_compare.py/json/md`, `race_transport.py/json/md`, `transport_audit.py/json`.
- r=3/4 scaling: `scaling_compute.py`, `scaling_r3.json`, `scaling_r4.json`, `scaling_width.py/json`, `scaling_audit.py/json`, `scaling_summary.md`.
- r=5 if claimed by the final report: `scaling_r5.py/json`, `scaling_r5_costs.npz`, `scaling_r5_verify.py/json`; this audit did not independently replay r=5.
- r=4 balanced: `balanced_r4.py/json/md`, `balanced_audit.py/json`. Keep associated top-level audits including `NUMERIC_AUDIT.md`, `AC_COUPLING_AUDIT.md`, `TRANSPORT_AUDIT.md`, `SCALING_AUDIT.md`, and this file when cited.

The three lightweight audit scripts use paths relative to their own directory; `balanced_audit.py` needs sibling `race_compare.py`, `scaling_r4.json`, `balanced_r4.py/json/md`; `scaling_audit.py` needs `race_compare.py`, `scaling_compute.py`, `scaling_r3.json`, `scaling_r4.json`; `transport_audit.py` needs `race_compare.json` and `race_transport.json`. The floor bundle verifier takes explicit paths to `load_model.json` and `floor_inputs.json`. Python 3.12's standard library suffices for these audits. Producer scripts additionally require their recorded NumPy, SciPy, SymPy and, for the fixed-p numerical optimizer, CVXPY/Clarabel. Producer runtimes and logs can vary; hashes and rational certificate fields should be checked rather than assuming timed JSON files reproduce byte-for-byte. Large r5 checkpoint must remain alongside its verification inputs. Review and update any hard-coded path and stale hash in author docs before claiming portable reproduction; inclusion here does not independently certify r5.

Release follow-up: the erroneous script hash in balanced_r4.md has been corrected. Main-agent rerun of balanced_audit.py passed with identical mathematical fields; only its input-document hash field changed. See REPLAY_CHECK.json and the release manifest for current bindings.
