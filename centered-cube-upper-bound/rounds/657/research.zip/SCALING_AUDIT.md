# Independent scaling candidate audit

The candidate marginal laws and their support costs pass exact recomputation for r=3,4. The gain calculations are correct **conditional on the saved full-enumeration independent expectation intervals**: this audit did not recompute the 4096/65536 independent tuple costs or their averages. These are atomic finite-model alternative couplings, not independent Euler draws, and are not claims about positive-width AC, arbitrary r, near-score states, or calibration.

## Independently rerun

Python Fraction code independently reconstructs the 16 single-replica states and checks they are exactly the product of two left, four center, and two right categories. For each stored candidate, it checks positive rational support weights, sum 1, all categories for all three rows and each replica, and that index base-16 digits reconstruct exactly the stored anchors. The r=3 candidate has 12 support tuples, r=4 has 18. Each support tuple was recomputed through the existing original `race_compare.py` geometry and unmodified 96-step root bracketing function; the recomputed exact W agrees and the resulting rational D interval lies within its saved outward-quantized interval. This uses the existing evaluate implementation and does not independently rewrite that geometry. Weighted lower/upper endpoints and difference from the reported independent upper endpoint exactly match the saved fractions:

- r=3: 116176283389917/256000000000000 > 0.
- r=4: 2709976086863467/4096000000000000 > 0.

The competitor is not certified globally optimal. Each candidate shares all individual Euler marginals, but its anchors have joint dependence and are not the independent construction.

## Audit of enumeration and rounding code

For each r the index range 0..16^r−1 is partitioned into consecutive non-overlapping chunks; each index is decoded with r base-16 digits and covers a unique r-tuple. Thus expected counts 4096 and 65536 are correct. Product law state enumeration is uniform on all 16 categories. The matrix gives normalization and all but the last point in each one-row category; normalization recovers the omitted last category, so the exact rational recheck of constraints is sufficient for all marginals. This was verified directly for all categories from the saved support, not inferred from solver status.

`work` applies exact `Fraction` floor to the lower D bound and ceiling to the upper D bound on scale 10^12, including the correct floor/ceiling directions for negative values. The 52-step root brackets are valid when their preconditions and root monotonicity hold; no strict-sign decision is made on their rounded midpoint. Python integer conversion before summing preserves the exact endpoint sum, and equal 1/16^r weights give the stated outward mean enclosure. Candidate sums are rational weights of rounded endpoints. With W≤r and 0≤Q′≤16 from the simplex, scaled endpoint integers are far inside signed int64 for r=3,4. LP floats only choose a support; exact rational reconstruction and marginal tests decide feasibility. The saved full-independent interval remains dependent on the actual complete execution and exact correctness of the source geometry; neither all its individual values nor aggregate sum were replayed here.

The dynamic exec prefix stops immediately before the unique top-level `out={'python':platform.python_version()` marker in the current `race_compare.py`, so no original costly aggregate loop runs; the one textual replacement changes `range(96)` to `range(52)` only in the root bisection in this current prefix. The audit script checks marker uniqueness and occurrence count, then evaluates support with the unmodified 96 steps. `scaling_compute.py` itself lacks those uniqueness guards, so this is a verification of the current input bytes, not a guarantee if its source changes.

## Reproduction and hashes

Executed single process with thread variables set to 1: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/scaling_audit.py > /tmp/ccu_r657/numeric/scaling_audit.json`. Python 3.12.14; no SciPy or CVXPY solve and no complete enumeration.

- `race_compare.py`: 7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a
- `scaling_compute.py`: 64d7665af670ddeb9f1c09c3713eb3cd3955795b8aecb7633063a81068957eed
- `scaling_r3.json`: 7595f7a637e2907c5127ab830238bd7152292ee11736f6e0ccb6b1955a9c34ee
- `scaling_r4.json`: 384a9cc0ad624c130c66b623698e760a6935f25050c4751469215c8f1c174d4b
- `scaling_audit.py`: 2fcbaeacb4b56137f42002f02e97f9d4e3bb26784767fd3b37e7755035a4dac8
- `scaling_audit.json`: fe654e7b037c2161fafa4d2f65d4930fbd716c31a8c609dbba65b0941f79dd4b
