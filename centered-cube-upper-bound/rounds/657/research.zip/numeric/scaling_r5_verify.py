from fractions import Fraction as F
from pathlib import Path
from itertools import product
import json,hashlib
import numpy as np
P=Path(__file__).parent
code=(P/'race_compare.py').read_text().split("out={'python':platform.python_version()")[0];env={'__name__':'verify_independent'};exec(compile(code,'race_compare.py','exec'),env);evaluate=env['evaluate'];law=env['states'](False)
a=np.load(P/'scaling_r5_costs.npz');lo=a['D_lower_1e12'];hi=a['D_upper_1e12'];width=a['W_units_1_128'];n=16**5;S=10**12
assert len(lo)==len(hi)==len(width)==n and np.all(lo<=hi) and np.max(hi-lo)<=2
x=json.loads((P/'scaling_r5.json').read_text());assert x['checkpoint_sha256']==hashlib.sha256((P/'scaling_r5_costs.npz').read_bytes()).hexdigest()
IL=F(sum(map(int,lo)),n*S);IU=F(sum(map(int,hi)),n*S);assert [str(IL),str(IU)]==x['independent_D_bounds'];assert str(F(sum(map(int,width)),n*128))==x['independent_W']
weights=[F(z['weight']) for z in x['support']];assert sum(weights)==1 and all(w>0 for w in weights)
categories=[[-F(3,4),-F(1,4)],[-F(3,4),-F(1,4),F(1,4),F(3,4)],[F(1,4),F(3,4)]]
for rep,g in product(range(5),range(3)):
 for point in categories[g]:assert sum((w for w,z in zip(weights,x['support']) if F(z['anchors'][rep][g])==point),F(0))==F(1,len(categories[g]))
for z in x['support']:
 idx=z['index']; digs=[(idx//16**(4-j))%16 for j in range(5)]; tup=tuple(law[d] for d in digs);assert [[str(v) for v in t] for t in tup]==z['anchors'];actual=evaluate(5,tup);assert F(int(lo[idx]),S)<=F(actual['D_bounds'][0])<=F(actual['D_bounds'][1])<=F(int(hi[idx]),S);assert F(int(width[idx]),128)==F(actual['W'])
CL=sum((w*F(int(lo[z['index']]),S) for w,z in zip(weights,x['support'])),F(0));CU=sum((w*F(int(hi[z['index']]),S) for w,z in zip(weights,x['support'])),F(0));assert [str(CL),str(CU)]==x['candidate_D_bounds'];gap=CL-IU;assert gap>0 and str(gap)==x['strict_gap_lower']
print(json.dumps({'status':'verified','checkpoint_entries':n,'selected_tuples_recomputed':len(weights),'row_marginals_checked':15,'independent_D_bounds':[str(IL),str(IU)],'coupled_D_bounds':[str(CL),str(CU)],'gap_lower':str(gap),'scope':'certifies aggregate of saved cost arrays, support tuple geometry and all marginals; checking every cost geometry requires rerun of producer'},indent=2))
