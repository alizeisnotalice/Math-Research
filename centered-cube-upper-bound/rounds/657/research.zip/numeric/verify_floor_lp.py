#!/usr/bin/env python3
"""Verify rational packing and floor-constrained LP certificates; see FLOOR_LP_SCHEMA.md."""
import json, sys
from fractions import Fraction as F
from pathlib import Path

def q(x):
    if not isinstance(x,(int,str)) or isinstance(x,bool):
        raise ValueError('rationals must be integer or rational string, never float/bool')
    return F(x)
def vec(values,n,name):
    if not isinstance(values,list) or len(values)!=n:raise ValueError(f'{name}: wrong length')
    return [q(x) for x in values]
def dot(a,b): return sum((x*y for x,y in zip(a,b)),F(0))
def nonneg(v,name):
    if any(x<0 for x in v):raise ValueError(f'{name}: negative entry')
def verify(data):
    names=data['rows']; cells=data['cells']; n=len(names); k=len(cells)
    if not n or not k or len(set(names))!=n or len(set(cells))!=k:raise ValueError('rows and cells must be nonempty and unique')
    m=vec(data['m'],n,'m'); ell=vec(data['ell'],n,'ell'); H=[vec(row,n,'H row') for row in data['H']]
    if len(H)!=k or any(v not in (0,1) for row in H for v in row):raise ValueError('H must be a cell-by-row 0/1 matrix')
    nonneg(m,'m'); nonneg(ell,'ell')
    Pbeta=vec(data['packing_primal'],n,'packing_primal'); Peta=vec(data['packing_dual'],k,'packing_dual')
    beta=vec(data['floor_primal'],n,'floor_primal'); eta=vec(data['floor_dual'],k,'floor_dual')
    for name,v in [('packing_primal',Pbeta),('packing_dual',Peta),('floor_primal',beta),('floor_dual',eta)]:nonneg(v,name)
    if any(dot(row,Pbeta)>1 for row in H):raise ValueError('packing primal infeasible')
    if any(sum((H[i][j]*Peta[i] for i in range(k)),F(0))<m[j] for j in range(n)):raise ValueError('packing dual infeasible')
    P=dot(m,Pbeta)
    if sum(Peta,F(0))!=P:raise ValueError('packing primal/dual do not certify exact P')
    residual=[1-dot(row,ell) for row in H]
    if any(x<0 for x in residual):raise ValueError('ell violates packing and floor LP is infeasible')
    if any(beta[j]<ell[j] for j in range(n)) or any(dot(row,beta)>1 for row in H):raise ValueError('floor primal infeasible')
    if any(sum((H[i][j]*eta[i] for i in range(k)),F(0))<m[j] for j in range(n)):raise ValueError('floor dual infeasible')
    lower=dot(m,beta); upper=dot(m,ell)+dot(eta,residual)
    if lower>upper or upper>P: # P remains a valid fallback upper bound
        if lower>upper:raise ValueError('inconsistent weak duality')
    effective_upper=min(P,upper)
    return {'status':'verified','P':str(P),'floor_feasible_L_lower':str(lower),'floor_dual_L_upper':str(upper),'effective_L_upper':str(effective_upper),'G_lower':str(P-effective_upper),'G_upper':str(P-lower),'strict_positive_G_certified':effective_upper<P,'floor_duality_gap':str(upper-lower),'residual_cell_capacities':[str(x) for x in residual], 'scope':'Algebraic certificates only: no verification of geometry, ell validity, true owner admissibility, or old KKT realization.'}
def geometry_audit(data):
    from itertools import combinations
    out=[]
    for case in data['cases']:
        k=case['twins']; n=k+4
        centers=[(F(10)+F(i*13,64),F(0)) for i in range(k)]+[(F(3),F(10)),(-F(8),F(6)),(-F(8),-F(6)),(F(3),-F(10))]
        assert centers==[tuple(map(q,z)) for z in case['centers']]
        rect=[(x-F(13,2),x+F(13,2),y-F(13,2),y+F(13,2)) for x,y in centers]
        xs=sorted(set(z for r in rect for z in r[:2]));ys=sorted(set(z for r in rect for z in r[2:]));area={}
        for x0,x1 in zip(xs,xs[1:]):
            for y0,y1 in zip(ys,ys[1:]):
                x=(x0+x1)/2;y=(y0+y1)/2
                mask=tuple(j for j,(a,b,c,d) in enumerate(rect) if a<x<b and c<y<d)
                if mask:area[mask]=area.get(mask,F())+(x1-x0)*(y1-y0)
        claimed={tuple(z['rows']):q(z['area']) for z in case['membership_masks']};assert area==claimed
        maximal={S for S in area if not any(set(S)<set(T) for T in area)}
        assert maximal=={tuple(z) for z in case['maximal_packing_cells']}
        assert len(maximal)==5
        p=F(169,4096);m=F(169);P=F(845,2); W=n*p;eps=q(case['epsilon']);e=q(case['e'])
        assert eps==4096*e and q(case['P'])==P and q(case['W'])==W and q(case['p_each'])==p
        assert all(max(abs(x[0]-y[0]),abs(x[1]-y[1]))>=F(13,64) for x,y in combinations(centers,2))
        assert all(sum(F(169,2) for S in maximal if j in S)==m for j in range(n))
        assert sum(F(1,2) for _ in range(5))*m==P
        primal=[F(1,2*k)]*k+[F(1,2)]*4
        assert all(sum(primal[j] for j in S)<=1 for S in maximal) and m*sum(primal)==P
        ellglobal=eps*p/(P+eps*W-m); assert ellglobal==q(case['ell_global'])
        assert all(v>=ellglobal for v in primal)
        values=[]
        for i in range(n):
            N={j for j in range(n) if i==j or any(i in S and j in S for S in maximal)}
            ci=case['neighbors'][i];assert N==set(ci['N'])
            # Two non-overlapping singleton rows furnish a size-2 primal; two actual cells cover N and furnish a size-2 dual.
            pair=next((uv for uv in combinations(sorted(N),2) if not any(set(uv)<=set(S) for S in maximal)),None)
            cover=next((uv for uv in combinations(maximal,2) if N<=set(uv[0])|set(uv[1])),None)
            assert pair and cover
            PN=2*m;WN=len(N)*p; assert q(ci['P_N'])==PN and q(ci['W_N'])==WN
            gd=P+eps*W-m; ld=PN+eps*WN-m; assert gd>0 and ld>0
            assert q(ci['global_den'])==gd and q(ci['local_den'])==ld
            ell=eps*p/min(gd,ld);assert ell==q(case['ell'][i])
            values.append({'N':sorted(N),'P_N':str(PN),'W_N':str(WN),'ell':str(ell),'P_N_primal_pair':list(pair),'P_N_dual_cover':[list(v) for v in cover]})
        out.append({'twins':k,'epsilon':str(eps),'membership_mask_count':len(area),'maximal_cells':sorted(map(list,maximal)),'receiver_disjoint':True,'neighborhoods':values})
    return {'status':'verified','cases':out,'scope':'exact cube incidence and LP geometry, successor fixture; no old source or calibration'}
def bundle_audit(model,bundle):
    geo=geometry_audit(model); results={}
    for name,cert in bundle['cases'].items():
        meta=cert['model_metadata']; eps=q(meta['epsilon']); n=len(cert['rows']); k=n-4
        case=next(c for c in model['cases'] if c['twins']==k and q(c['epsilon'])==eps)
        centers=[tuple(map(q,z)) for z in case['centers']]
        rectangles=[(x-F(13,2),x+F(13,2),y-F(13,2),y+F(13,2)) for x,y in centers]
        receivers=[(x-F(13,128),x+F(13,128),y-F(13,128),y+F(13,128)) for x,y in centers]
        assert [tuple(map(q,z)) for z in meta['cube_rectangles']]==rectangles
        assert [tuple(map(q,z)) for z in meta['receiver_rectangles']]==receivers
        masks=[tuple(j for j,v in enumerate(row) if q(v)==1) for row in cert['H']]
        areas={tuple(z['rows']):q(z['area']) for z in case['membership_masks']}
        assert len(masks)==len(set(masks)) and set(masks)==set(areas)
        assert list(map(q,meta['positive_cell_area']))==[areas[S] for S in masks]
        assert all(q(m)==169 for m in cert['m']) and list(map(q,cert['ell']))==list(map(q,case['ell']))
        assert q(meta['P'])==F(845,2) and q(meta['W'])==n*F(169,4096) and q(meta['t'])==0
        assert list(map(q,meta['p']))==[F(169,4096)]*n
        assert meta['neighborhoods']==case['neighbors']
        result=verify(cert); assert result['floor_duality_gap']=='0' and result['strict_positive_G_certified']
        assert F(result['G_lower'])==q(case['G_neighbor_exact'])
        results[name]=result
    assert len(results)==4 and len(geo['cases'])==4
    return {'status':'verified','geometry':geo,'results':results,'scope':'finite exact geometry and LP; conditional on legitimate ell and fixed-p successor model; no old source/calibration'}
if __name__=='__main__':
    if not (len(sys.argv)==2 or (len(sys.argv)==3 and sys.argv[1]=='--geometry') or (len(sys.argv)==4 and sys.argv[1]=='--bundle')):
        raise SystemExit('usage: verify_floor_lp.py CERT.json | --geometry MODEL.json | --bundle MODEL.json CERTS.json')
    try:
        data=json.loads(Path(sys.argv[-1]).read_text())
        record=bundle_audit(json.loads(Path(sys.argv[2]).read_text()),data) if len(sys.argv)==4 else geometry_audit(data) if len(sys.argv)==3 else verify(data)
        print(json.dumps(record,indent=2))
    except (ValueError, KeyError, TypeError, ZeroDivisionError) as e:
        print('certificate rejected: '+str(e),file=sys.stderr)
        raise SystemExit(1)
