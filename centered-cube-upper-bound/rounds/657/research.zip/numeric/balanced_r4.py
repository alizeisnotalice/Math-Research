import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
from fractions import Fraction as F
from pathlib import Path
from itertools import permutations,combinations
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
import json,time,hashlib,platform
import numpy as np, scipy, sympy as sp
from scipy.optimize import linprog
P=Path(__file__).parent
src=(P/'race_compare.py').read_text().split("out={'python':platform.python_version()")[0].replace('range(96)','range(52)');ctx={'__name__':'balanced_evaluator'};exec(compile(src,'race_compare.py','exec'),ctx);evaluate=ctx['evaluate'];law=ctx['states'](False);SCALE=10**12
L=(-F(3,4),-F(1,4));C=L+(F(1,4),F(3,4));R=(F(1,4),F(3,4));
seqL=sorted(set(permutations(L*2)));seqC=list(permutations(C));seqR=sorted(set(permutations(R*2))); assert (len(seqL),len(seqC),len(seqR))==(6,24,6)
combos=[tuple((lv[i],cv[i],rv[i]) for i in range(4)) for lv in seqL for cv in seqC for rv in seqR];assert len(combos)==864
lookup={tuple(t):i for i,t in enumerate(law)}
def work(i):
 t=combos[i];z=evaluate(4,t);dl=F(z['D_bounds'][0])*SCALE;du=F(z['D_bounds'][1])*SCALE
 return i,dl.numerator//dl.denominator,-((-du.numerator)//du.denominator),z['W']
if __name__=='__main__':
 print('START pid',os.getpid(),'workers14 tuples864',flush=True);t0=time.monotonic()
 with ProcessPoolExecutor(max_workers=14,mp_context=get_context('fork')) as pool: values=list(pool.map(work,range(864),chunksize=8))
 values.sort();low=[z[1] for z in values];high=[z[2] for z in values];W=[F(z[3]) for z in values]
 cats=(L,C,R);A=[[1]*864]; rhs=[F(1)]
 for rep in range(4):
  for g,cat in enumerate(cats):
   for value in cat[:-1]:A.append([int(t[rep][g]==value) for t in combos]);rhs.append(F(1,len(cat)))
 lp=linprog(-np.array([(a+b)/(2*SCALE) for a,b in zip(low,high)]),A_eq=np.array(A,float),b_eq=np.array([float(x) for x in rhs]),bounds=(0,None),method='highs',options={'threads':1});assert lp.success
 sup=np.flatnonzero(lp.x>1e-9).tolist();mat=sp.Matrix([[A[row][i] for i in sup] for row in range(len(A))]);b=sp.Matrix([sp.Rational(x.numerator,x.denominator) for x in rhs]);sol,free=mat.gauss_jordan_solve(b);assert free.rows==0;weights=[F(int(v.p),int(v.q)) for v in sol];assert all(x>0 for x in weights) and sum(weights)==1
 for rep in range(4):
  for g,cat in enumerate(cats):
   for value in cat:assert sum((weights[j] for j,i in enumerate(sup) if combos[i][rep][g]==value),F(0))==F(1,len(cat))
 # All candidate tuples have exact empirical masses (4,4,4,4).
 for i in range(864):
  measured={x:F(0) for x in C}
  for t in combos[i]:
   for g,weight in enumerate((F(7,5),F(6,5),F(7,5))):measured[t[g]]+=weight
  assert all(measured[x]==4 for x in C)
 dl=sum((w*F(low[i],SCALE) for w,i in zip(weights,sup)),F(0));du=sum((w*F(high[i],SCALE) for w,i in zip(weights,sup)),F(0));cw=sum((w*W[i] for w,i in zip(weights,sup)),F(0));old=json.loads((P/'scaling_r4.json').read_text());ind=[F(x) for x in old['independent_D_bounds']];gain=dl-ind[1]
 records=[]
 for w,i in zip(weights,sup):
  index=0
  for t in combos[i]:index=16*index+lookup[t]
  records.append({'balanced_index':i,'full_index':index,'weight':str(w),'anchors':[[str(x) for x in t] for t in combos[i]],'W':str(W[i]),'D_bounds':[str(F(low[i],SCALE)),str(F(high[i],SCALE))]})
 output={'scope':'atomic low-R old model; candidate valid all clone-row marginals and per-tuple Gamma=0; no global optimum, AC, epsilon* or near-score claim','python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'source_files':{'race_compare.py':hashlib.sha256((P/'race_compare.py').read_bytes()).hexdigest(),'scaling_r4.json':hashlib.sha256((P/'scaling_r4.json').read_bytes()).hexdigest()},'balanced_count':864,'support_size':len(sup),'solver_status':lp.message,'elapsed_seconds':time.monotonic()-t0,'empirical_each_source_mass':'4','per_tuple_Gamma':'0','mean_W':str(cw),'candidate_D_bounds':[str(dl),str(du)],'independent_D_bounds':list(map(str,ind)),'gain_lower':str(gain),'strict_improvement':gain>0,'support':records}
 (P/'balanced_r4.json').write_text(json.dumps(output,indent=2)+'\n');print('DONE count864 support',len(sup),'W',cw,'D',float(dl),'ind',float(ind[1]),'gap',float(gain),'sec',round(time.monotonic()-t0,3),flush=True)
