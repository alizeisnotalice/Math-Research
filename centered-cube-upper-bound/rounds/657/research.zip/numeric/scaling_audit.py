import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,hashlib,platform
here=Path(__file__).resolve().parent
source=(here/'race_compare.py').read_text();marker="out={'python':platform.python_version()"
assert source.count(marker)==1
prefix=source.split(marker)[0];assert prefix.count('range(96)')==1
ns={'__name__':'support_audit'};exec(compile(prefix,'race_compare.py','exec'),ns)
evaluate=ns['evaluate'];law=ns['states'](False);assert len(law)==16 and len(set(law))==16
cats=[(-F(3,4),-F(1,4)),(-F(3,4),-F(1,4),F(1,4),F(3,4)),(F(1,4),F(3,4))]
assert set(law)==set(product(*cats))
outputs={}
for r in (3,4):
 z=json.loads((here/f'scaling_r{r}.json').read_text()); assert z['r']==r and z['tuples']==16**r
 s=z['support'];assert len(s)==z['support_size'] and len(set(x['index'] for x in s))==len(s)
 weights=[F(x['weight']) for x in s];assert all(w>0 for w in weights) and sum(weights,F())==1
 for j in range(r):
  for g,category in enumerate(cats):
   for point in category: assert sum((w for w,x in zip(weights,s) if F(x['anchors'][j][g])==point),F())==F(1,len(category))
 for x in s:
  idx=x['index'];assert 0<=idx<16**r
  tup=tuple(law[(idx//16**(r-1-j))%16] for j in range(r))
  assert [[str(v) for v in triple] for triple in tup]==x['anchors']
  exact=evaluate(r,tup); l,h=map(F,exact['D_bounds']);sl,sh=map(F,x['D_bracket'])
  assert sl<=l<=h<=sh and F(exact['W'])==F(x['W'])
 coupled=[sum((w*F(x['D_bracket'][j]) for w,x in zip(weights,s)),F()) for j in (0,1)]
 assert coupled==list(map(F,z['candidate_D_bounds']))
 il,ih=map(F,z['independent_D_bounds']); assert il<=ih
 gap=coupled[0]-ih; assert gap==F(z['strict_gap_lower']) and gap>0
 outputs[str(r)]={'tuple_count':z['tuples'],'support_recomputed':len(s),'strict_gap_lower_conditioned_on_stored_independent_upper':str(gap),'all_marginals':True,'candidate_D_bounds':list(map(str,coupled))}
out={'python':platform.python_version(),'files_sha256':{name:hashlib.sha256((here/name).read_bytes()).hexdigest() for name in ['race_compare.py','scaling_compute.py','scaling_r3.json','scaling_r4.json']},'cases':outputs,'scope':'support exact geometry/root recomputed; full independent mean and all branch costs were not rerun'}
print(json.dumps(out,indent=2))
