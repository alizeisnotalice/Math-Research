# R657 finite coupled-anchor transport witness

A six-point coupled law on the already enumerated r=2 atomic model preserves every one of the six clone-row Euler marginals and strictly improves the complete expected D over independent anchors. HiGHS selected candidate support using the 256 pre-existing tuple costs. The result below is a feasible-coupling certificate; it does not claim that the candidate is globally optimal.

| branch index | probability | replica 1: (L,C,R) | replica 2: (L,C,R) |
|---:|---:|---|---|
| 44 | 1/4 | (−3/4, 1/4, 1/4) | (−1/4, −3/4, 3/4) |
| 61 | 1/8 | (−3/4, 3/4, 1/4) | (−1/4, −1/4, 3/4) |
| 75 | 1/8 | (−3/4, −3/4, 3/4) | (−1/4, 3/4, 1/4) |
| 135 | 1/8 | (−1/4, −3/4, 1/4) | (−3/4, 3/4, 3/4) |
| 210 | 1/4 | (−1/4, −1/4, 3/4) | (−3/4, 1/4, 1/4) |
| 241 | 1/8 | (−1/4, 3/4, 3/4) | (−3/4, −1/4, 1/4) |

The script solves the selected support's linear equations exactly with SymPy rationals, verifies each probability is positive and sums to one, and independently verifies every individual L/R source point has mass 1/2 and every individual C point has mass 1/4 in each replica. It does not impose independence within this two-replica block. Different such blocks could be sampled independently; any TV or analytic budget for such use remains a separate proof obligation.

| law | E W | E Q′ | E D |
|---|---:|---:|---:|
| coupled witness | 2 | ≈12.11894235652 | ≈1.33167597299 |
| independent | 13/8 | ≈12.42555809004 | ≈0.93976701709 |

For every one of the six coupled tuples W=2. Exact Fraction-weighted sums of the previously computed 96-step rational D brackets establish

`E D_coupled − E D_independent > 3919/10000`,

with decimal difference approximately 0.39190895589. The exact bracketing endpoints and exact rational positive gap are in the JSON; the table's rounded values are for display. The input tuple costs recompute capture eligibility, δ-baseline, actual min-Q on the complete simplex packing and the full `E−O+F+RS` ledger, as documented in `race_compare.md`. This witness improves the whole D, rather than optimizing a surrogate W alone.

The finite input is the same atomic old KKT toy with R=15/272; no claim is made that it is an all-finite ε* or near-score state. Extending it to an absolutely continuous source requires the separate uniform geometric and KKT perturbation argument proposed in `race_compare.md`, which is awaiting independent review. This result does not certify its own positive-width lift or any global bound.

Reproduce:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/race_transport.py > /tmp/ccu_r657/numeric/race_transport.json
```

The script reads `race_compare.json` beside itself, SHA-256 `8a56b3fd50ce6aad99ae49f1398d856779bd13fc3954eb7e7d47a4e954599676`; archive both files together. Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1 (HiGHS), SymPy 1.14.0, one process, OpenBLAS and OMP set to one. HiGHS took approximately 0.0039 seconds in the recorded run; exact verification follows it. SHA-256 script `61d963e3651bf6906f0843116382cb849b43de94c0dc155ed1a0bb03e0d78e68`, output JSON `f3a3a0237f9350bb67537b312091433ac3f87a0d81a5ca1f9e7956a875fb6728`.
