# R657 independent-versus-coupled scaling, r=3 and r=4

A single 14-worker process pool enumerated all 4,096 and 65,536 true anchor tuples for r=3 and r=4, respectively, in the frozen R657 one-dimensional old state. Each tuple recomputed actual E/B′/C intervals, capture eligibility, δ=1/100 baseline, low-mass min-Q free allocation, simplex entropy root and the complete D ledger. The independent-law mean uses every tuple equally. A sparse finite marginal transport LP then selected a candidate coupling, and its support and all clone-row marginal equalities were verified with exact rational arithmetic. HiGHS supplied candidates only; no global optimality is claimed.

| r | tuples | candidate support | independent E W | coupled E W | independent E D | coupled E D | strict gain lower bound |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 3 | 4,096 | 12 | 65/32 | 5/2 | ≈1.335312253636 | ≈1.789125860629 | 116176283389917/256000000000000 ≈ 0.453813606992 |
| 4 | 65,536 | 18 | 295/128 | 3 | ≈1.599252278685 | ≈2.260867534268 | 2709976086863467/4096000000000000 ≈ 0.661615255582 |

The independent E D exact outward intervals are `[341839936930851/256000000000000,341839936931107/256000000000000]` for r=3 and `[6550537333493871/4096000000000000,6550537333498261/4096000000000000]` for r=4. Exact candidate bounds, rational weights, anchor tuples and support-specific D brackets are in `scaling_r3.json` and `scaling_r4.json`. Every candidate weight is strictly positive; their exact sum is one; for each individual clone row the L/R marginal has probability 1/2 at each of its two source points and the C marginal has probability 1/4 at each of four. The listed gains subtract the independent **upper** endpoint from the coupled **lower** endpoint.

This is the atomic low-R old KKT model from `race_compare.md`. It does not certify a positive-width action, all-finite epsilon* or near-score class, or a global dimension theorem. The coupled law permits dependence among all clone anchors in a block; no independence within a block is claimed. Expected W for the independent law was recomputed separately using the exact receiver-coverage product formula, while the coupled W is the exact rational support-weighted sum. Thus each D gain is the full physical gain, including the changing W and the actual optimized Q′, not a presumed additional source payment.

## Exact error control and reproducibility

`scaling_compute.py` loads the geometry and evaluator definitions from the adjacent frozen `race_compare.py`, using 52 rather than 96 rational bisection steps for each simplex multiplier. For every tuple it rounds the lower D endpoint down and the upper endpoint up to a multiple of `10^-12`, before summing with rational probabilities. This gives a rigorous aggregate enclosure without accumulating enormous common denominators. The candidate LP is based on those midpoint values, but the sign proof uses only the exact outward bounds and rational marginal checks. The earlier 96-step r=1,2 run is not repeated.

The transport equality matrix is sparse and includes one total-mass equation and all but one category for each clone row; the omitted category follows from total mass. Selected support weights are recovered by exact rational linear algebra and verified against the transport equations. The full original category marginals are implied by these equations and the partition of each row's possible points.

Run from an environment that permits a 14-worker pool:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/scaling_compute.py 2>&1 | tee /tmp/ccu_r657/numeric/scaling_run.log
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/scaling_width.py > /tmp/ccu_r657/numeric/scaling_width.json
```

Archive `scaling_compute.py` and `race_compare.py` together; the script resolves the latter relative to itself. The process sets OpenBLAS, OMP, MKL and NumExpr threads to one and uses one `ProcessPoolExecutor(max_workers=14)`. The actual active main PID was 8273; r=3 completed in about 0.30 s and r=4 in 4.34 s including their LP solves, after process startup. Initial detached launch was reaped by the execution environment, so the completed run used the foreground execution session. HiGHS received its single-thread option; SciPy emitted an option-passthrough warning, not an error. Python 3.12.14; NumPy 2.5.4, SciPy 1.18.1, SymPy 1.14.0.

SHA-256: `scaling_compute.py` `64d7665af670ddeb9f1c09c3713eb3cd3955795b8aecb7633063a81068957eed`; `race_compare.py` `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`; `scaling_r3.json` `7595f7a637e2907c5127ab830238bd7152292ee11736f6e0ccb6b1955a9c34ee`; `scaling_r4.json` `384a9cc0ad624c130c66b623698e760a6935f25050c4751469215c8f1c174d4b`; `scaling_width.py` `ae95e3ac093fbc1ea2b18bcadfaf6fda60d9e285af1d4fbe4f2d9b8925c6d082`; `scaling_width.json` `d2e734725ec5d9d24ab9c9a137867198124476f896c0fd7a6e3ffc067f2a978a`.

## Bounded r=5 extension and measured resource use

A subsequent, separately frozen run executed every `16^5=1,048,576` tuple; r=3 and r=4 were not recalculated. It used one pool of 14 worker processes on the local 15-logical-CPU, 24-GiB machine, with BLAS/OMP/MKL/NumExpr set to one thread. The worker geometry phase completed in 80.78 seconds. The sparse marginal transport had 10,223,616 nonzero matrix entries; the complete run including HiGHS and exact support verification took 109.39 seconds. No r=6 task was launched.

Each tuple's outward-rounded lower and upper D integers (units 10^-12) and exact receiver W (units 1/128) are preserved in `scaling_r5_costs.npz`, all 1,048,576 entries. The first launch failed before any tuple due to an unregistered dynamically imported Python module; it was corrected and the successful run started as PID 8552. `scaling_r5_monitor.jsonl` contains roughly one process-tree sample per second. Excluding the initial startup sample, the 77 samples during geometry show median 1379.7% and peak 1395.9% summed CPU (about 13.8 and 14 logical cores); HiGHS then ran single-threaded. Peak summed RSS for the whole run was 2,113,208,320 bytes, about 1.97 GiB. This RSS sums processes and double-counts shared pages, so it is not a measurement of unique physical RAM. The monitor's reported process-tree count includes its transient `ps` subprocess.

| r | tuples | independent E W | coupled E W | independent E D | candidate E D | strict gain lower |
|---:|---:|---:|---:|---:|---:|---:|
| 3 | 4,096 | 65/32 | 5/2 | ≈1.335312253636 | ≈1.789125860629 | ≈0.453813606992 |
| 4 | 65,536 | 295/128 | 3 | ≈1.599252278685 | ≈2.260867534268 | ≈0.661615255582 |
| 5 | 1,048,576 | 1277/512 | 3 | ≈1.780878295953 | ≈2.260867534268 | `31456574722125349/65536000000000000` ≈0.479989238314 |

For r=5 the independent D enclosure is `[116711640003583263/65536000000000000,116711640003662299/65536000000000000]` and the coupled enclosure is `[565216883567/250000000000,226086753427/100000000000]`. The candidate has 26 positive rational support weights. The r=5 coupled value happens numerically to match the r=4 candidate at the displayed precision; this finite observation does not prove saturation or optimality. Using `D=W−RQ′`, the approximate independent/coupled E Q′ are respectively 12.93382357 and 13.40293538. Thus the improvement in this candidate comes with a Q′ increase and is established only after the complete W and Q′ ledger is combined.

An additional `scaling_r5_verify.py` run checked checkpoint length and aggregate exact bounds, all 15 clone-row marginals at every source point, all 26 support anchors against their base-16 indices, and independently recomputed those 26 tuple geometries with the original 96-step Fraction evaluator. Each recomputed D interval lies within its saved outward bracket; the support gain is strictly positive. This checks the aggregate of the saved arrays and the complete candidate support; independently recomputing all remaining tuple geometries requires rerunning the producer. Inspection of the earlier r=3/4 execution shows every index in every one of 32/32 and 512/512 logged chunks invoked the evaluator, respectively 4,096 and 65,536 times, with no memoization or cache substitution.

Reproduce the r=5 producer and verification, preserving `race_compare.py` and `scaling_compute.py` beside them:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/scaling_r5.py 2>&1 | tee /tmp/ccu_r657/numeric/scaling_r5.log
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/scaling_r5_verify.py > /tmp/ccu_r657/numeric/scaling_r5_verify.json
```

SHA-256: `scaling_r5.py` `10117902eab960406b8b64915a4eed021e750a9d3a12661e81a04bf05770d2cb`; `scaling_r5.json` `fb83d10744514204beba9416d7d72f93a141503cc25d012d031d4b93cc2ae695`; `scaling_r5_costs.npz` `45fdfb7d032d4e6f06eebfe4e61912396be45a973a118d60ad8933cbcc557d21`; `scaling_r5_verify.py` `390f96c4d80592f6fbf1a0996ebd6b47df685c5b3a196da670bf6044a63513fa`; `scaling_r5_verify.json` `af386150e5680bed659b63e586ec38337df1842e88ade287469bed60d61c822e`; `scaling_r5_monitor.jsonl` `763ba8924f5a77cea7b07d099a55bb81798259d634530b7d4823c38b10fa4de7`.
