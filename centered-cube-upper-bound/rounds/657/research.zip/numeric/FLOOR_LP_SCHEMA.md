# Exact finite floor-packing certificate: acceptance schema

`verify_floor_lp.py` consumes a JSON file specified as its sole argument; stdout is the exact rational report, with a nonzero exit and stderr reason on rejection. It reads no external state. Numbers must be integers or rational strings such as `"17/3"`; decimal JSON floats and booleans are rejected. Matrix `H` must be a 0/1 incidence matrix of *all actual positive-volume packing cells* for the available expanded cubes. The verifier checks algebra against the supplied H; an independent geometry audit must prove H complete and correctly attached to these rows. It does not generate cubes or check their Euler/old-state legality.

Required fields (dimensions n rows and k cells):

- `rows`: n distinct row names; `cells`: k distinct cell names.
- `m`: n nonnegative rational cube volumes; `H`: k by n incidence matrix.
- `ell`: n nonnegative rational componentwise certified lower bounds on the actual fixed-p entropy optimizer α. Each must be justified externally from the actual p, ε, actual neighborhood P_N and receiver-union W_N and the supplied parameter t under its required domain, not merely treated as true because this program accepts it. For the R656 bound, `ell_j=ε p_j / min(P-m_j+εW-t, P_Nj+εW_Nj-m_j)` with strictly positive denominators and valid d≥t; endpoint conventions and zero-mass rows require separate care. Use only bounds valid simultaneously for the same p and tuple.
- `packing_primal`: n nonnegative rationals βP satisfying HβP≤1; `packing_dual`: k nonnegative rationals ηP with HᵀηP≥m and ∑ηP=m·βP. These certify exact ordinary packing value P.
- `floor_primal`: n nonnegative rationals β satisfying β≥ell and Hβ≤1. It gives a *lower* bound m·β on L, useful to upper-bound G.
- `floor_dual`: k nonnegative rationals η with Hᵀη≥m. It gives the critical *upper* bound U=m·ell+η·(1−H ell) on L. The verifier requires H ell≤1 and separately confirms the floor primal is feasible. A loose dual for ordinary packing alone does not certify positive G. The residual formula is essential: L=m·ell+max{m·γ: γ≥0,Hγ≤1−H ell}; weak duality gives L≤U. The program also uses P itself as a fallback upper bound, and returns G∈[P−min(P,U), P−m·β]. Strict positive G requires U<P.

`H` incidence, m and `ell` semantics, positive-dimensional geometry, actual p/owner feasibility, strict denominator/domain bounds, prior bound d≥t, source budget and old AC KKT/Euler realization are outside this algebra verifier. Finite geometry/solver results cannot alone establish a general or near-score theorem. No supplied model has yet been evaluated; this is a schema plus implementation pending the independently prepared real-cube instance.
