import json, hashlib, platform
from fractions import Fraction as F
from itertools import product
from pathlib import Path
here=Path(__file__).resolve().parent
source_path=here/'race_compare.json'; witness_path=here/'race_transport.json'
source=json.loads(source_path.read_text())['cases']['r2_independent']; witness=json.loads(witness_path.read_text()); rows=source['rows']
opts=[(F(-3,4),F(-1,4)),(F(-3,4),F(-1,4),F(1,4),F(3,4)),(F(1,4),F(3,4))]
def flat(row):return tuple(F(x) for rep in row['replica_anchors'] for x in rep)
assert len(rows)==256
assert set(map(flat,rows))==set(product(*(opts*2)))
support=witness['support'];assert len(support)==6
weights=[F(item['weight']) for item in support]; assert all(w>0 for w in weights) and sum(weights)==1
idx=[item['branch_index'] for item in support]; assert len(set(idx))==6
for entry in support:
 row=rows[entry['branch_index']]; assert entry['anchors']==row['replica_anchors'] and entry['D_bounds']==row['D_bounds']
for i,choices in enumerate(opts*2):
 for point in choices: assert sum((w for w,j in zip(weights,idx) if flat(rows[j])[i]==point),F())==F(1,len(choices))
def bnd(row):return tuple(map(F,row['D_bounds']))
coupled=[sum((w*bnd(rows[j])[v] for w,j in zip(weights,idx)),F()) for v in (0,1)]
independent=[sum((bnd(row)[v] for row in rows),F())/256 for v in (0,1)]
assert coupled==list(map(F,witness['coupling_D_bounds']))
assert independent==list(map(F,witness['independent_D_bounds']))==list(map(F,source['mean_D_bounds']))
assert all(F(rows[j]['W'])==2 for j in idx)
gap=coupled[0]-independent[1];assert gap==F(witness['gain_strict_lower']) and gap>F(3919,10000)
h=F(1,10**12); error=2*18000*2*h; ac_lower=gap-error
assert error==F(9,125000000) and ac_lower>F(3919,10000)-error>0
out={'python':platform.python_version(),'source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'transport_sha256':hashlib.sha256(witness_path.read_bytes()).hexdigest(),'branches':len(rows),'support_indices':idx,'weights':list(map(str,weights)),'all_six_marginals_verified':True,'atomic_gap_lower':str(gap),'atomic_simple_lower':'3919/10000','two_law_error_upper':str(error),'AC_gap_lower':str(ac_lower),'AC_simple_lower':str(F(3919,10000)-error),'scope':'r=2 prescribed dependent coupling compared to independent, conditional on exact branch costs and existing uniform AC error audit; no independence requirement satisfied by coupling'}
print(json.dumps(out,indent=2))
