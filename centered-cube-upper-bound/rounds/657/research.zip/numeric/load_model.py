import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as F
from itertools import combinations
import json,time,platform
import numpy as np,scipy,cvxpy as cp,clarabel
from scipy.optimize import linprog,brentq
m=F(169);a=64;p=m/F(4096)
def geometry(k):
 centers=[(F(10)+F(i*13,64),F(0)) for i in range(k)]+[(F(3),F(10)),(-F(8),F(6)),(-F(8),-F(6)),(F(3),-F(10))];n=len(centers);radius=F(13,2)
 rect=[(x-radius,x+radius,y-radius,y+radius) for x,y in centers];
 xx=sorted(set(v for q in rect for v in q[:2])); yy=sorted(set(v for q in rect for v in q[2:])); cells={}
 for l,h in zip(xx,xx[1:]):
  for b,t in zip(yy,yy[1:]):
   X=(l+h)/2;Y=(b+t)/2;mask=tuple(i for i,(x0,x1,y0,y1) in enumerate(rect) if x0<X<x1 and y0<Y<y1)
   if mask:cells[mask]=cells.get(mask,F(0))+(h-l)*(t-b)
 maximal=[S for S in cells if not any(set(S)<set(T) for T in cells)];mat=np.array([[float(i in S) for i in range(n)] for S in maximal]);
 B=[(x-radius/64,x+radius/64,y-radius/64,y+radius/64) for x,y in centers];
 gaps=[max(abs(centers[i][0]-centers[j][0]),abs(centers[i][1]-centers[j][1]))-F(13,64) for i,j in combinations(range(n),2)]; assert min(gaps)>=0
 # zero gaps are boundary touching; no positive-area intersection
 lp=linprog(-np.ones(n),A_ub=mat,b_ub=np.ones(len(mat)),bounds=(0,None),method='highs');assert lp.success
 expected={frozenset(list(range(k))+[k]),frozenset([k,k+1]),frozenset([k+1,k+2]),frozenset([k+2,k+3]),frozenset(list(range(k))+[k+3])}
 assert set(map(frozenset,maximal))==expected
 return centers,rect,B,cells,maximal,mat,lp,gaps
def compute(k,e):
 centers,rect,B,cells,maximal,A,lp,gaps=geometry(k);n=len(centers);P=F(5,2)*m;eps=e*4096;W=n*p
 # actual per-row closed neighborhoods from positive area C intersections
 neigh=[];ell=[];local=[]
 for i in range(n):
  N=[j for j in range(n) if j==i or any(i in S and j in S for S in maximal)];sub=A[:,N];res=linprog(-np.ones(len(N)),A_ub=sub,b_ub=np.ones(len(A)),bounds=(0,None),method='highs'); assert res.success
  PN=F(round(-res.fun*2),2)*m; assert abs(float(PN/m)+res.fun)<1e-8;WN=len(N)*p
  global_den=P+eps*W-m;local_den=PN+eps*WN-m; el=eps*p/min(global_den,local_den); neigh.append(N);local.append({'N':N,'P_N':str(PN),'W_N':str(WN),'global_den':str(global_den),'local_den':str(local_den)});ell.append(el)
 lower=np.array([float(q) for q in ell]); constrained=linprog(-np.ones(n),A_ub=A,b_ub=np.ones(len(A)),bounds=[(float(q),None) for q in ell],method='highs');assert constrained.success
 # Exact feasible LP maximizer and matching combinatorial upper bound.
 z=max(F(1,2),k*ell[0]); certified_alpha=[z/k]*k+[1-z,F(1,2),F(1,2),1-z]
 assert all(certified_alpha[j]>=ell[j] for j in range(n))
 assert all(sum(certified_alpha[j] for j in cell)<=1 for cell in maximal)
 exactG=m*(z-F(1,2)); assert abs(float(exactG)-(float(P)-float(m)*(-constrained.fun)))<1e-7
 av=cp.Variable(n,nonneg=True); cv=cp.Problem(cp.Maximize(cp.sum(av)+float(e)*cp.sum(cp.log(av))),[A@av<=np.ones(len(A))]);t0=time.monotonic();cv.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_feas=1e-10,tol_gap_rel=1e-10,max_iter=500);elapsed=time.monotonic()-t0
 x=brentq(lambda x:1+float(e)*(2/x-k/(1-x)),.000001,.499999,xtol=1e-14); analytical=np.array([(1-x)/k]*k+[x,.5,.5,x]); deficit=float(m)*(.5-x)
 # Optimal dual vector half m on each maximal cell, every row gets m.
 incidence=A.T@np.full(len(maximal),.5); assert np.max(abs(incidence-1))<1e-12
 return {'twins':k,'rows':n,'epsilon':str(eps),'e':str(e),'centers':[[str(x),str(y)] for x,y in centers],'receiver_min_signed_gap':str(min(gaps)),'receiver_interiors_disjoint':True,'rectangular_membership_cell_count':len(cells),'membership_masks':[{'rows':list(z),'area':str(area)} for z,area in cells.items()],'maximal_packing_cells':[list(z) for z in maximal],'P':str(P),'P_normalized':-lp.fun,'edge_dual_each':str(m/2),'sigma_all_zero':True,'W':str(W),'p_each':str(p),'neighbors':local,'ell':list(map(str,ell)),'G_neighbor_exact':str(exactG),'G_neighbor_float':float(exactG),'G_neighbor_exact_alpha':list(map(str,certified_alpha)),'G_global_LP':None,'lp_alpha':constrained.x.tolist(),'solver_status':cv.status,'solver_seconds':elapsed,'cvx_alpha':av.value.tolist(),'analytical_alpha':analytical.tolist(),'analytic_x':x,'max_alpha_diff':float(np.max(abs(av.value-analytical))),'stationarity_residual':abs(1+float(e)*(2/x-k/(1-x))),'packing_residual':max(0,float(np.max(A@analytical-1))),'analytic_deficit':deficit,'cvx_deficit':float(P)-float(m)*sum(av.value),'kappa_prime':float(eps*W)/(float(m)*sum(analytical)),'condition':'forced p via disjoint centered receivers; no old KKT/Euler realization or calibrated epsilon* assertion'}
out={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'scope':'actual 2D positive-area cube and receiver incidence, fixed p successor model only','cases':[]}
for k,e in [(3,F(2)),(3,F(6,5)),(4,F(2)),(4,F(6,5))]:
 z=compute(k,e); P=F(z['P']); n=z['rows']; W=F(z['W']); eps=F(z['epsilon']);e0=eps*p/(P+eps*W-m)
 Gglobal=linprog(-np.ones(n),A_ub=geometry(k)[5],b_ub=np.ones(5),bounds=[(float(e0),None)]*n,method='highs');assert Gglobal.success
 z['ell_global']=str(e0);z['G_global_LP']=float(P)-float(m)*(-Gglobal.fun);out['cases'].append(z)
print(json.dumps(out,indent=2))
