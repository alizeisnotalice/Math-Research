import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,platform,time,hashlib
from fractions import Fraction as F
from pathlib import Path
import numpy as np, scipy, sympy as sp
from scipy.optimize import linprog
old=json.loads(Path(__file__).with_name('race_compare.json').read_text());source=old['cases']['r2_independent']; rows=source['rows'];assert len(rows)==256
categories=[[-F(3,4),-F(1,4)],[-F(3,4),-F(1,4),F(1,4),F(3,4)],[F(1,4),F(3,4)]]
def anchor(z,rep,g):return F(z['replica_anchors'][rep][g])
A=[[1]*len(rows)]; b=[F(1)]; labels=['total']
for rep in range(2):
 for g,cat in enumerate(categories):
  for point in cat[:-1]:
   A.append([int(anchor(z,rep,g)==point) for z in rows]);b.append(F(1,len(cat)));labels.append(f'rep{rep}_{"LCR"[g]}_{point}')
assert len(A)==11
cost=np.array([(float(F(z['D_bounds'][0]))+float(F(z['D_bounds'][1])))/2 for z in rows]);t=time.monotonic();lp=linprog(-cost,A_eq=np.array(A,dtype=float),b_eq=np.array([float(v) for v in b]),bounds=(0,None),method='highs');elapsed=time.monotonic()-t
assert lp.success
support=[i for i,p in enumerate(lp.x) if p>1e-9];S=sp.Matrix([[A[j][i] for i in support] for j in range(len(A))]);B=sp.Matrix([sp.Rational(v.numerator,v.denominator) for v in b]); sol,params=S.gauss_jordan_solve(B);assert params.rows==0
weights=[F(int(v.p),int(v.q)) for v in sol];assert all(x>0 for x in weights) and sum(weights)==1
for rep in range(2):
 for g,cat in enumerate(categories):
  for point in cat:assert sum((weights[j] for j,i in enumerate(support) if anchor(rows[i],rep,g)==point),F(0))==F(1,len(cat))
lo=sum((weights[j]*F(rows[i]['D_bounds'][0]) for j,i in enumerate(support)),F(0));hi=sum((weights[j]*F(rows[i]['D_bounds'][1]) for j,i in enumerate(support)),F(0));iblo=F(source['mean_D_bounds'][0]);ibhi=F(source['mean_D_bounds'][1]);gain=lo-ibhi;assert gain>0
W=sum((weights[j]*F(rows[i]['W']) for j,i in enumerate(support)),F(0)); qlo=sum((weights[j]*F(rows[i]['Q_bounds'][0]) for j,i in enumerate(support)),F(0));qhi=sum((weights[j]*F(rows[i]['Q_bounds'][1]) for j,i in enumerate(support)),F(0));assert W==2 and gain>F(3919,10000)
out={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'input':'race_compare.json beside this script; cases.r2_independent','input_sha256':hashlib.sha256(Path(__file__).with_name('race_compare.json').read_bytes()).hexdigest(),'solver_status':lp.message,'solver_seconds':elapsed,'scope':'finite atomic old KKT model; valid six row marginals, no within-block independence or global optimality claimed','marginals':'L,R each two points probability 1/2; C each four points probability 1/4 for each of two replicas','support':[{'branch_index':i,'weight':str(weights[j]),'anchors':rows[i]['replica_anchors'],'D_bounds':rows[i]['D_bounds']} for j,i in enumerate(support)],'coupling_W':str(W),'coupling_Q_bounds':[str(qlo),str(qhi)],'gain_simple_strict_lower':'3919/10000','coupling_D_bounds':[str(lo),str(hi)],'independent_D_bounds':[str(iblo),str(ibhi)],'gain_strict_lower':str(gain),'support_size':len(support),'input_branches':256,'equations_rank':S.rank()}
print(json.dumps(out,indent=2))
