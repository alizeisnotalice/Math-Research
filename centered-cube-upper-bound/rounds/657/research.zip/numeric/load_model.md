# R657 actual cube packing: unused-load test

The fixed-p successor model has seven actual two-dimensional cubes of side 13 and a=64, m_j=169, and `p_j=169/4096`, forced by their pairwise interior-disjoint centered receivers. It is an exact positive-volume cube-incidence model; no old KKT source, Euler action, all-finite epsilon* calibration or near-score realization is asserted. In particular a computed successor kappa′ does not establish calibration.

The first vertex has three centers `(10+k*13/64,0)` for k=0,1,2; the other centers are `(3,10),(-8,6),(-8,-6),(3,-10)`. Enumerating all rectangular coordinate cells with Fraction gives exactly five maximal positive-area packing sets: the two cliques containing all twins and each adjacent singleton, and the three intervening two-row edges. The closest receiver gap is exactly zero: adjacent twins touch only on their boundaries, so their interiors are disjoint. The JSON records every positive-area membership mask, not just the graph.

The LP packing optimum is `P=5*169/2=845/2`. The five actual maximal-cell dual masses `169/2` each supply exactly 169 to every row; consequently `sigma_j=0` for all rows and the R656 sigma-pressure witness is zero. Nevertheless the actual fixed-p entropy optimum has positive deficit `P−Q′`.

| twins | e=epsilon p/m | epsilon | actual deficit P−Q′ | global G_p(0) | neighborhood G_p(0) | kappa′ |
|---:|---:|---:|---:|---:|---:|---:|
| 3 | 2 | 8192 | 12.77151575 | 0 | 169/22 ≈ 7.68181818 | 5.77455581 |
| 3 | 6/5 | 24576/5 | 9.95608846 | 0 | 169/70 ≈ 2.41428571 | 3.44108823 |
| 4 | 2 | 8192 | 24.95285754 | 0 | 39/2 = 19.5 | 6.80170906 |
| 4 | 6/5 | 24576/5 | 22.72294735 | 0 | 1183/82 ≈ 14.42682927 | 4.05826195 |

The r=4 twin case uses `(10+k*13/64,0)` for k=0,1,2,3 and the same four singleton centers. It is a modest check of this one fixed family, not dimension or asymptotic evidence. The reported deficit and kappa′ decimals are numerical evaluations of the KKT solution below; LP and geometric fractions are exact. The value e=6/5 for three twins produces kappa′<4, but does not itself establish membership in any calibrated or near-score class.

## Actual entropy optimum and first-order witness

Let k denote twin count. The strictly concave fixed-p objective is, up to a positive factor 169 and an additive constant, `sum alpha_j+e sum log alpha_j`. Its unique optimum is

`alpha_twins=(1−x)/k`, `alpha_adjacent=x`, `alpha_opposite=1/2`,

where the two adjacent and two opposite singleton values are repeated and x is the unique root in (0,1/2) of

`1+e(2/x−k/(1−x))=0`.

The only positive entropy packing multipliers are `169(1+e/x)` on each twin/adjacent clique and `169(1+2e)` on the opposite/opposite edge. The two remaining edges have slack because x<1/2. The displayed equation makes each twin stationarity equation exact. All multipliers are positive, so these formulas are a genuine KKT certificate and `P−Q′=169(1/2−x)>0`. SciPy Brent evaluates x, and independent Clarabel solves gave maximum alpha discrepancies between 7.9e−7 and 5.7e−6; all statuses were optimal. The JSON gives packing feasibility, α, first-order residuals, and solver status.

## Constrained LP at zero and the missing load

`G_p(0)` here means `P−max{sum_j m_j alpha_j: alpha in K_C, alpha_j>=ell_j(0)}`. For the global denominator, a fractional cycle LP optimum with twin aggregate 1/2 remains feasible under the lower bounds, giving `G_global(0)=0` in all four cases.

For each row the actual C-neighborhood packing LP has `P_N=2*169`; its neighborhood receiver union is the sum of the disjoint receivers in that neighborhood. For three twins the resulting ell values are `2/11` on twins and adjacent singletons, `2/7` on the opposite singletons when e=2, and `6/35`, `6/23` respectively when e=6/5. Four twins give `2/13`,`2/7` and `6/41`,`6/23` respectively. All are exact Fractions; the JSON lists each neighborhood and denominator.

Let z be the sum of twin alphas. The lower bounds force `z>=k*ell_twin`, which exceeds 1/2 in each case. The two clique constraints bound the adjacent singleton sum by `2(1−z)` and the opposite edge bounds the opposite sum by 1. Thus total alpha is at most `3−z<=3−k*ell_twin`. Equality is feasible at twins `ell_twin`, both adjacent `1−k*ell_twin`, and both opposite `1/2`; all individual lower bounds are met. Therefore

`G_neighbor(0)=169(k*ell_twin−1/2)`,

which yields the exact fractions in the table, with no reliance on LP solver accuracy. This exposes positive unused-load pressure even though the chosen optimal LP dual has every sigma zero. It does not prove a uniform physical gain or pay any later loss term.

## Reproduction

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/load_model.py > /tmp/ccu_r657/numeric/load_model.json`

Python 3.12.14; NumPy 2.5.4, SciPy 1.18.1 (HiGHS), CVXPY 1.9.3, Clarabel 0.11.1. The single process sets OpenBLAS and OMP threads to 1. Four specified cases were executed, no parameter scan. Recorded Clarabel solve times were 0.00558, 0.00151, 0.00138, and 0.00134 seconds in table order; these exclude geometric enumeration and process startup. Geometric intervals and the feasible constrained-LP witness use Fraction; the root and CVXPY comparison are floating calculations, with the exact KKT characterization above.

SHA-256: script `46ce55acb715264fff4d81ca1897d70d7077017b6c83b80aede73497b2a4c306`; JSON `c8efdd2e2cd5c80f9cc9009eabfb4d3c8dbf4bbbaa79b2b1cdaf8db753f44bbf`.
