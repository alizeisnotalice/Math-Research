from fractions import Fraction as F
from pathlib import Path
import json
L=(-F(3,4),-F(1,4));C=L+(F(1,4),F(3,4));R=(F(1,4),F(3,4));base=[(-F(1),F(4),F(3,2),L),(F(0),F(8),F(7,2),C),(F(1),F(4),F(3,2),R)]
B=[]
for y,t,b,law in base:
 row=[]
 for x in law:
  c=(1+b)*y-b*x;row.append((c-t/32,c+t/32))
 B.append(row)
pts=sorted(set(v for row in B for lo,hi in row for v in (lo,hi)))
res={}
for r in (3,4):
 W=F(0)
 for lo,hi in zip(pts,pts[1:]):
  x=(lo+hi)/2;qs=[F(sum(a<x<b for a,b in row),len(row)) for row in B];prod=F(1)
  for q in qs:prod*=(1-q)**r
  W+=(hi-lo)*(1-prod)
 result=json.loads(Path(__file__).with_name('scaling_r'+str(r)+'.json').read_text()); wc=sum((F(v['weight'])*F(v['W']) for v in result['support']),F(0));res[str(r)]={'independent_W':str(W),'coupled_W':str(wc)}
print(json.dumps(res,indent=2))
