import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from threading import Thread,Event
import importlib.util,json,time,subprocess,signal,hashlib,sys
import numpy as np,scipy,sympy as sp
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('scale',P/'scaling_compute.py');mod=importlib.util.module_from_spec(spec);sys.modules['scale']=mod;spec.loader.exec_module(mod)
N=16**5;S=10**12;runstart=time.monotonic();stop=Event();memory_stop=Event();monitor_path=P/'scaling_r5_monitor.jsonl';parent=os.getpid()
def cputime(v):
 try:
  parts=v.split(':');return sum(float(x)*60**i for i,x in enumerate(reversed(parts)))
 except ValueError:return 0.0
def monitor():
 prev={};last=time.monotonic()
 with monitor_path.open('w') as out:
  while not stop.is_set():
   raw=subprocess.run(['ps','-axo','pid=,ppid=,time=,rss='],capture_output=True,text=True).stdout; procs={}
   for line in raw.splitlines():
    a=line.split()
    if len(a)==4:
     try:procs[int(a[0])]=(int(a[1]),cputime(a[2]),int(a[3])*1024)
     except ValueError:pass
   ids={parent};changed=True
   while changed:
    new={i for i,(pp,_,_) in procs.items() if pp in ids}-ids;changed=bool(new);ids|=new
   now=time.monotonic();dt=now-last;cpu=sum(max(0,procs[i][1]-prev.get(i,0)) for i in ids if i in procs)/dt*100 if dt>0 else 0; rss=sum(procs[i][2] for i in ids if i in procs);d={'elapsed_seconds':round(now-runstart,3),'processes':len(ids),'cpu_percent_sum':round(cpu,1),'rss_sum_bytes':rss};out.write(json.dumps(d)+'\n');out.flush()
   if rss>12*1024**3:
    memory_stop.set()
    for pid in ids-{parent}:
     try:os.kill(pid,signal.SIGTERM)
     except ProcessLookupError:pass
    return
   prev={i:procs[i][1] for i in ids if i in procs};last=now;stop.wait(1)
Thread(target=monitor,daemon=True).start()
print('START pid',parent,'workers 14','tuples',N,flush=True)
low=np.empty(N,dtype=np.int64);high=np.empty(N,dtype=np.int64);width=np.empty(N,dtype=np.uint16)
try:
 t=time.monotonic();chunks=[(5,i,min(i+256,N)) for i in range(0,N,256)]
 with ProcessPoolExecutor(max_workers=14,mp_context=get_context('fork')) as pool:
  for count,(start,items) in enumerate(pool.map(mod.work,chunks,chunksize=1),1):
   if memory_stop.is_set():raise MemoryError('process-tree summed RSS exceeded 12 GiB')
   for j,(lo,hi,w) in enumerate(items):
    low[start+j]=lo;high[start+j]=hi;v=F(w)*128;assert v.denominator==1 and 0<=v<65536;width[start+j]=v.numerator
   if count%256==0 or count==len(chunks):print('chunks',count,'/',len(chunks),'sec',round(time.monotonic()-t,2),flush=True)
 print('saving checkpoint',flush=True);np.savez(P/'scaling_r5_costs.npz',D_lower_1e12=low,D_upper_1e12=high,W_units_1_128=width)
 print('geometry completed, seconds',round(time.monotonic()-t,2),flush=True)
 # Deterministic categorical digit extraction; sparse rows 0..25, no Python tuple scan.
 idx=np.arange(N,dtype=np.int32); rr=[np.zeros(N,dtype=np.int32)];cc=[idx]; rhs=[F(1)]; row=1; cats=[[-F(3,4),-F(1,4)],[-F(3,4),-F(1,4),F(1,4),F(3,4)],[F(1,4),F(3,4)]]
 for rep in range(5):
  digits=(idx//(16**(4-rep)))%16
  for g,cat in enumerate(cats):
   for point in cat[:-1]:
    matches=np.array([int(z[g]==point) for z in mod.law],dtype=bool);cols=np.flatnonzero(matches[digits]).astype(np.int32);cc.append(cols);rr.append(np.full(len(cols),row,dtype=np.int32));rhs.append(F(1,len(cat)));row+=1
 rows=np.concatenate(rr);cols=np.concatenate(cc);del rr,cc;A=coo_matrix((np.ones(len(rows),dtype=np.float64),(rows,cols)),shape=(26,N)).tocsr();del rows,cols
 print('LP start nnz',A.nnz,'elapsed',round(time.monotonic()-t,2),flush=True)
 lp=linprog(-((low.astype(float)+high.astype(float))/(2*S)),A_eq=A,b_eq=np.array([float(v) for v in rhs]),bounds=(0,None),method='highs',options={'threads':1});assert lp.success,lp.message
 support=np.flatnonzero(lp.x>1e-9).tolist();As=sp.Matrix(A[:,support].toarray().astype(int).tolist());bb=sp.Matrix([sp.Rational(v.numerator,v.denominator) for v in rhs]);sol,free=As.gauss_jordan_solve(bb);assert free.rows==0;weights=[F(int(v.p),int(v.q)) for v in sol];assert all(w>0 for w in weights) and sum(weights)==1
 for j in range(A.shape[0]):assert sum((weights[k]*int(A[j,i]) for k,i in enumerate(support)),F(0))==rhs[j]
 independent=(F(sum(map(int,low)),N*S),F(sum(map(int,high)),N*S));coupled=(sum((w*int(low[i]) for w,i in zip(weights,support)),F(0))/S,sum((w*int(high[i]) for w,i in zip(weights,support)),F(0))/S);gap=coupled[0]-independent[1];assert gap>0
 W_ind=F(int(width.astype(np.uint64).sum()),N*128);W_coupled=sum((w*F(int(width[i]),128) for w,i in zip(weights,support)),F(0))
 rec=[]
 for w,i in zip(weights,support):
  digs=[(i//16**(4-j))%16 for j in range(5)];rec.append({'index':i,'weight':str(w),'anchors':[[str(x) for x in mod.law[d]] for d in digs],'D_bounds':[str(F(int(low[i]),S)),str(F(int(high[i]),S))],'W':str(F(int(width[i]),128))})
 out={'r':5,'tuples':N,'independent_D_bounds':list(map(str,independent)),'candidate_D_bounds':list(map(str,coupled)),'strict_gap_lower':str(gap),'independent_W':str(W_ind),'candidate_W':str(W_coupled),'support_size':len(rec),'support':rec,'LP_status':lp.message,'elapsed_seconds':time.monotonic()-t,'checkpoint_sha256':hashlib.sha256((P/'scaling_r5_costs.npz').read_bytes()).hexdigest(),'scope':'atomic finite model; candidate correct row marginals, not globally optimal or AC/near-score'}
 (P/'scaling_r5.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE ind',float(independent[0]),'coupled',float(coupled[0]),'gap',float(gap),'support',len(rec),'W',W_ind,W_coupled,'sec',round(time.monotonic()-t,2),flush=True)
finally:
 stop.set()
