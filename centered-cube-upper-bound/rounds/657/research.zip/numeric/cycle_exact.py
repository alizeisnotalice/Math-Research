from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json, platform
from itertools import product
import sympy as S
m=F(169); K=3; p=F(169,4096); scale=10**30

def sqrt_bounds(q):
    n=isqrt(q.numerator*scale*scale//q.denominator)
    return F(n,scale),F(n+1,scale)
def bpair(x): return [str(x[0]),str(x[1])]
def dec(x): return float(x)
def case(e):
    D=(5*e-1)**2+8*e
    sl,su=sqrt_bounds(D)
    xl=(1-5*e+sl)/2; xu=(1-5*e+su)/2
    assert 0<xl<xu<F(1,2)
    # λA=λB=1/x+1/e and λ23=2+1/e, normalized by p.
    edge_lambda=(1/xu+1/e,1/xl+1/e)
    slack=(F(1,2)-xu,F(1,2)-xl)
    d=tuple(m*v for v in slack)
    kappa=(7*e/(2+xu),7*e/(2+xl))
    H=[[1,1,1,1,0,0,0],[0,0,0,1,1,0,0],[0,0,0,0,1,1,0],[0,0,0,0,0,1,1],[1,1,1,0,0,0,1]]
    a=e/(1+5*e); b=e/(1+3*e)
    ell=[a,a,a,a,b,b,a]; beta=[a,a,a,1-3*a,F(1,2),F(1,2),1-3*a]
    eta=[m,0,m,0,m]; sigma=[sum(eta[i]*H[i][j] for i in range(5))-m for j in range(7)]
    assert all(v>=0 for v in sigma)
    assert all(beta[j]>=ell[j] for j in range(7))
    assert all(sum(h[j]*beta[j] for j in range(7))<=1 for h in H)
    L=sum(m*v for v in beta); dual=sum(eta)-sum(sigma[j]*ell[j] for j in range(7))
    assert L==dual and F(5,2)*m-L==m*(e-1)/(2*(1+5*e))
    assert all((beta[j]-ell[j])*sigma[j]==0 for j in range(7))
    assert all(eta[i]*(1-sum(H[i][j]*beta[j] for j in range(7)))==0 for i in range(5))
    return {'e':str(e),'epsilon':str(4096*e),'sqrt_discriminant':str(D),
      'x_bounds':bpair((xl,xu)), 'x_approx':dec((xl+xu)/2),
      'inactive_edge_slack_bounds':bpair(slack),'active_outer_multiplier_over_p':bpair(edge_lambda),
      'active_middle_multiplier_over_p':str(2+1/e), 'twin_alpha_bounds':bpair(((1-xu)/K,(1-xl)/K)),
      'actual_d_bounds':bpair(d), 'actual_d_approx':dec((d[0]+d[1])/2),
      'kappa_bounds':bpair(kappa),'kappa_approx':dec((kappa[0]+kappa[1])/2), 'conditional_floor_a':str(a),'conditional_floor_b':str(b),'floor_beta':list(map(str,beta)),'floor_dual_eta':list(map(str,eta)),'floor_dual_sigma':list(map(str,sigma)),'floor_L':str(L),'floor_G':str(F(5,2)*m-L)}
x,e=S.symbols('x e', real=True)
f=1+e*(2/x-3/(1-x))
deriv=S.factor(S.diff(f,x))
assert S.simplify(deriv+e*(2/x**2+3/(1-x)**2))==0
assert S.simplify(-x*(1-x)*f-(x*x+(5*e-1)*x-2*e))==0
# Independent exact 2D rectangle arrangement for the supplied 7-cube centers.
centers=[(F(10),F(0)),(F(653,64),F(0)),(F(333,32),F(0)),(F(3),F(10)),(F(-8),F(6)),(F(-8),F(-6)),(F(3),F(-10))]
half=F(13,2); rh=half/64
coords=[sorted({v+sgn*half for c in centers for v in [c[axis]] for sgn in (-1,1)}) for axis in (0,1)]
areas={}
for x0,x1 in zip(coords[0],coords[0][1:]):
 for y0,y1 in zip(coords[1],coords[1][1:]):
  x=(x0+x1)/2; y=(y0+y1)/2
  mask=tuple(i for i,(a,b) in enumerate(centers) if abs(x-a)<half and abs(y-b)<half)
  if mask: areas[mask]=areas.get(mask,F(0))+(x1-x0)*(y1-y0)
maximal=sorted(mask for mask in areas if not any(set(mask)<set(other) for other in areas))
expected=sorted([(0,1,2,3),(3,4),(4,5),(5,6),(0,1,2,6)])
assert maximal==expected and len(areas)==18
neighbors=[]
for i,(x,y) in enumerate(centers):
 N=[j for j,(a,b) in enumerate(centers) if abs(x-a)<=13 and abs(y-b)<=13]
 neighbors.append(N)
assert list(map(len,neighbors))==[5,5,5,5,3,3,5]
assert all(max(abs(a[0]-b[0]),abs(a[1]-b[1]))>=2*rh for i,a in enumerate(centers) for b in centers[i+1:])
geometry={'centers':[[str(a),str(b)] for a,b in centers],'cube_halfside':str(half),'receiver_halfside':str(rh),'maximal_positive_masks':[list(t) for t in maximal],'all_positive_membership_masks':[{'rows':list(t),'area':str(areas[t])} for t in sorted(areas)],'closed_intersection_neighbors':neighbors,'receiver_interiors_disjoint':True}
out={'task':'R657_CYCLE_EXACT','scope':'conditional abstract C5 with a 3-clique replacing one vertex; no geometric realization or old-state calibration assumed', 'python':platform.python_version(),'sympy':S.__version__,'m':str(m),'p':str(p),'W':str(7*p),'discriminant_formula':'(5e-1)^2+8e','equation':'x^2+(5e-1)x-2e=0','f_derivative':str(deriv),'bound_method':'integer isqrt of exact rational discriminant times 10^60; monotone rational endpoint maps','cases':[case(F(2)),case(F(6,5))],'independent_geometry':geometry}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
for a in out['cases']: print(a['e'], 'x',a['x_approx'],'d',a['actual_d_approx'],'kappa',a['kappa_approx'])
