import os
for v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[v]='1'
from fractions import Fraction as F
from pathlib import Path
from itertools import product, permutations
import hashlib, json, platform
p=Path(__file__).resolve().parent; txt=(p/'race_compare.py').read_text(); marker="out={'python':platform.python_version()"
assert txt.count(marker)==1; ctx={'__name__':'balanced_audit'};exec(compile(txt.split(marker)[0],'race_compare.py','exec'),ctx)
eval=ctx['evaluate'];law=ctx['states'](False); data=json.loads((p/'balanced_r4.json').read_text()); ref=json.loads((p/'scaling_r4.json').read_text());items=data['support']; weights=[F(z['weight']) for z in items]
L=(F(-3,4),F(-1,4));R=(F(1,4),F(3,4));C=L+R; cats=(L,C,R)
seqs=[sorted(set(permutations(L*2))),list(permutations(C)),sorted(set(permutations(R*2)))]
assert [len(v) for v in seqs]==[6,24,6] and data['balanced_count']==864 and len(items)==data['support_size']==14
assert all(w>0 for w in weights) and sum(weights)==1
assert len(set(z['balanced_index'] for z in items))==len(items)
for j in range(4):
 for g,cat in enumerate(cats):
  for v in cat:assert sum((w for w,z in zip(weights,items) if F(z['anchors'][j][g])==v),F())==F(1,len(cat))
for z in items:
 tup=tuple(tuple(F(x) for x in a) for a in z['anchors']); observed=[tuple(t[g] for t in tup) for g in range(3)]
 for seq,values in zip(seqs,observed):assert values in seq
 bi=(seqs[0].index(observed[0])*24+seqs[1].index(observed[1]))*6+seqs[2].index(observed[2]);assert bi==z['balanced_index']
 fi=0
 for t in tup:fi=16*fi+law.index(t)
 assert fi==z['full_index']
 masses={x:F() for x in C}
 for row in tup:
  for x,a in zip(row,(F(7,5),F(6,5),F(7,5))):masses[x]+=a
 assert all(masses[x]==4 for x in C)
 actual=eval(4,tup);lo,hi=map(F,actual['D_bounds']);lo0,hi0=map(F,z['D_bounds']);assert lo0<=lo<=hi<=hi0 and F(actual['W'])==F(z['W'])
bounds=[sum((w*F(z['D_bounds'][i]) for w,z in zip(weights,items)),F()) for i in (0,1)]
assert bounds==list(map(F,data['candidate_D_bounds']))
W=sum((w*F(z['W']) for w,z in zip(weights,items)),F());assert W==F(data['mean_W'])==3
assert data['independent_D_bounds']==ref['independent_D_bounds'];gap=bounds[0]-F(ref['independent_D_bounds'][1]);assert gap==F(data['gain_lower']) and gap>0
out={'python':platform.python_version(),'support_count':len(items),'all_marginals_and_source_point_masses_verified':True,'candidate_D_bounds':list(map(str,bounds)),'independent_reference_bounds':ref['independent_D_bounds'],'gap_conditional_on_independent_mean':str(gap),'scope':'atomic r4; all support recomputed via existing evaluate, not all 864 nor all independent branches','sha256':{x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in ['race_compare.py','scaling_r4.json','balanced_r4.py','balanced_r4.json','balanced_r4.md']}}
print(json.dumps(out,indent=2))
