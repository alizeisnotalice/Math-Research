# R657 coupled Euler action: independent, first-hit and opposite-point

The finite atomic decision uses old intervals `A_j=[y_j−1,y_j+1]` with `y=(-1,0,1)`, disjoint `I_j=B_j=[y_j−1/32,y_j+1/32]`, `m=(8,16,8)`, `lambda=(7/10,3/10,7/10)`, `epsilon=336/5`, `R=15/272`. The common source places mass 4 at each of `−3/4,−1/4,1/4,3/4`. Its row masses are 8,16,8, and the two saturated old cells have loads λL+λC=λC+λR=1, so this is a genuine old KKT witness as a measure. It is atomic, with low R; no near-score, AC or global calibration conclusion is inferred from the atomic run.

For each replica, L and R each independently choose one of their two source points. The independent law samples C independently from all four points; the shared first-hit law chooses the side with probability 1/2 independently of the points, then sets C equal to that side's sampled point. The opposite-point law chooses the same way but sets C to the *other* point of that side. All three have the correct one-row Euler marginals. Replica blocks are independent, and each old I and λ is partitioned equally among r clone labels.

| r | law | complete branches | E W | E Q′, min-Q owner | E D |
|---:|---|---:|---:|---:|---:|
| 1 | independent | 16 | 1 | 12.23725757209056 | 0.32515123683324 |
| 1 | first-hit | 8 | 1 | 12.23725757209056 | 0.32515123683324 |
| 2 | independent | 256 | 13/8 | 12.42555809003635 | 0.93976701709358 |
| 2 | first-hit | 64 | 13/8 | 12.43019627023889 | 0.93951123509712 |
| 2 | opposite-point | 64 | 13/8 | 12.43019627023889 | 0.93951123509712 |

At r=2 the exact rational enclosures in the JSON prove `E D_independent−E D_first-hit>0`, approximately 0.00025578199646. The opposite-point and first-hit mean W and Q′ enclosure endpoints are exactly identical in this enumeration, so the opposite-point law also falls below independent by the same strictly positive amount. The equal W values make the observed difference a change of actual optimized Q′, not extra receiver coverage. The decimals above are rounded; they are not the sign proof.

Every full tuple recomputes exact interval E, B′, C, image-priority capture eligibility for all high incoming rows, fill, deleted old images, and δ=1/100 baseline. All C share a positive interval; the smallest exact common length over the evaluated tuples is 15/4, so the true packing is the simplex. At fixed W, assigning a free atom from mass 8 to mass 16 strictly increases the multiplier ν in `sum epsilon*p_j/(nu−m_j)=1`, hence increases `Q′=nu−epsilon W`. Therefore the actual min-Q policy chooses the smallest eligible mass, with equal-mass ties harmless to Q′; it is not the old joint-B max-m rule. The script uses exact Fraction geometry and 96 rational bisection steps per tuple for ν, retains the lower and upper rational Q′ and D bounds, and verifies the full ledger `D=2/17−O+F+R(16−Q′)=W−RQ′` including fill. No r=4 run or parameter scan was performed.

## Proposed positive-width lift: explicit error budget, pending independent audit

One possible actual AC lift replaces the four atoms by uniform intervals of radius `h=1/10^12` about the same four points, each with mass 4. These intervals remain inside their corresponding saturated old cells; row masses, λ and old KKT remain the same. Couple each new draw to its corresponding atomic point. For the first-hit law use the same chosen outer sample as C; for opposite-point use the side's corresponding opposite-box sample with the same within-box displacement. The latter is uniform in the other box and preserves C's Euler marginal. Each block remains independent across replicas.

The following is an explicit proposed uniform bound for independent checking; it is **not yet an independently audited positive-width certificate**:

1. Every endpoint capture-containment margin is nonzero and has absolute value at least 1/8; the script verifies the finite list. A perturbation by h changes any new-C endpoint by at most `(7/2)h`, so the capture matrix stays fixed. The common-C interval remains positive because the minimum atomic length is 15/4.
2. For r replicas, each E and B′ interval shifts by at most b_j h. The union of their symmetric differences has length at most `4r(3/2+7/2+3/2)h=26rh`. Off this set, incoming and receiver memberships, eligibility, baseline fractions, and the min-m free mass group are unchanged. Thus each aggregate mass-level owner volume changes by at most `26rh`; receiver-union W alone changes by at most `13rh`.
3. All 384 r=2 branch calculations across the independent, first-hit and opposite laws have atomic high-mass p at least 1/2. If `26rh<1/4`, the perturbed high-mass p remains at least 1/4. Also `1/2<=W<=3`. The scalar root obeys `nu−16>=epsilon*p16>=epsilon/4` and `nu−8<=8+3epsilon`. Implicit differentiation then bounds each derivative `|partial nu/partial p_m|` by `(8+3epsilon)^2/[(1/2)(epsilon/4)]=549152/105<6000`. Therefore `|Delta Q′| <= (6000*52+13epsilon)rh`, and `|Delta D|<18000rh` for each tuple/law.
4. For r=2, comparing two laws incurs at most `72000h=0.000000072` in the difference. The atomic independent-minus-first-hit gap is approximately 0.00025578199646, exceeding this error. The JSON records the exact rational lower bracket after subtracting this cost. This would preserve the ordering for the described AC lift if the bound and coupling are independently confirmed; it does not imply an all-finite ε* or near-score claim.

## Reproduction

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/race_compare.py > /tmp/ccu_r657/numeric/race_compare.json`

Python 3.12.14, Fraction exact arithmetic, one process, OpenBLAS and OMP set to one. Measured branch-enumeration times were approximately 0.0094 s (r1 independent), 0.0043 s (r1 first-hit), 0.146 s (r2 independent), 0.0360 s (r2 first-hit), and 0.0361 s (r2 opposite). Output stores every anchor tuple, actual eligibility atoms, W, O, F, aggregate owner masses and rational root/ledger bounds. SHA-256: script `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`, JSON `8a56b3fd50ce6aad99ae49f1398d856779bd13fc3954eb7e7d47a4e954599676`.
