# R657 balanced four-clone coupled witness

The frozen R657 atomic old state has source points `−3/4,−1/4,1/4,3/4`, each of mass 4. For r=4, an anchor tuple is **balanced** when the four L clones use each left source point twice, the four R clones use each right point twice, and the four C clones use each of the four points once. There are exactly `6*24*6=864` such tuples.

All 864 were re-evaluated with the actual interval geometry, image-priority capture eligibility, δ=1/100 baseline, true simplex packing and per-tuple min-Q optimizer. The selected 14-point candidate has exact rational probabilities and every one of the 12 clone rows has its prescribed Euler marginal: 1/2 at each outer source point or 1/4 at each central source point. A finite transport LP picked the candidate; exact rational linear algebra checked all categories, nonnegative weights and total mass. No claim of global optimality is made.

For every balanced tuple, each outer clone has old source weight `(28/5)/4=7/5`, and each central clone has `(24/5)/4=6/5`. Each source point receives two outer contributions and one central contribution, hence empirical weighted mass `2*(7/5)+6/5=4`, exactly the actual old μ mass. Thus the empirical source measure is exactly μ and **Gamma=0 for each tuple**, independently of the selected adaptive α.

The candidate has exact `E W=3`. Its complete D and the previously computed independent-r4 D have these rigorous outward intervals:

| law | complete E D enclosure |
|---|---|
| balanced coupled candidate | [565216883567/250000000000, 226086753427/100000000000] |
| independent r=4 | [6550537333493871/4096000000000000, 6550537333498261/4096000000000000] |

Consequently the coupled improvement is at least

`2709976086863467/4096000000000000 > 0`, approximately 0.661615255582.

The coupled mean D is approximately 2.260867534268, the independent mean approximately 1.599252278685. These rounded values are for display; exact positive gap follows from the rational brackets. The candidate happens to attain the same displayed interval as the previously found unrestricted r=4 candidate, but neither calculation claims global optimality. Full exact probabilities, anchor tuples, W and individual D brackets are in `balanced_r4.json`.

The old model is atomic and low-R (`R=15/272`); this calculation establishes neither a positive-width AC coupling nor an epsilon* calibrated, near-score or global theorem. Whether any synchronous refinement retains the required whole-block TV and continuity properties belongs to the separate proof audit.

## Reproduction

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/balanced_r4.py 2>&1 | tee /tmp/ccu_r657/numeric/balanced_r4.log
```

The script reads the adjacent frozen `race_compare.py` geometry and `scaling_r4.json` independent mean. It computes 864 tuples in a single 14-worker pool, sets BLAS/OMP/MKL/NumExpr threads to 1, uses 52 Fraction bisection steps and outward D rounding to multiples of 10^-12, then solves the fixed finite transport with single-thread HiGHS. Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1, SymPy 1.14.0. Recorded execution inside the script was approximately 0.101 s; the HiGHS thread option generated a SciPy passthrough warning. The transport result is rationalized and verified, rather than accepted by solver status.

SHA-256: `balanced_r4.py` `463d949c5fc2cde01d1f769c86a5f4739389a399732da0e812546370a56f4614`; `balanced_r4.json` `957015cca108cd16bad2be3170deb96e0297f12bc84337e4ee9ebb4ab1aee48f`; required `race_compare.py` `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`; required `scaling_r4.json` `384a9cc0ad624c130c66b623698e760a6935f25050c4751469215c8f1c174d4b`.
