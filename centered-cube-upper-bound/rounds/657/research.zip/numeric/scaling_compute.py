import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from itertools import product
import json,time,platform,sys,math
import numpy as np,scipy,sympy as sp
from scipy.optimize import linprog
from scipy.sparse import lil_matrix
src=Path(__file__).with_name('race_compare.py').read_text().split("out={'python':platform.python_version()")[0].replace('range(96)','range(52)')
namespace={'__name__':'scaling_sub'};exec(compile(src,'race_compare.py','exec'),namespace)
evaluate=namespace['evaluate'];law=namespace['states'](False);SCALE=10**12

def work(payload):
 r,start,stop=payload;arr=[]
 for idx in range(start,stop):
  q=idx;digits=[0]*r
  for j in range(r-1,-1,-1):digits[j]=q%16;q//=16
  z=evaluate(r,tuple(law[d] for d in digits));lower=F(z['D_bounds'][0]);upper=F(z['D_bounds'][1]);flo=(lower*SCALE).numerator//(lower*SCALE).denominator; zup=upper*SCALE; cei=-((-zup.numerator)//zup.denominator);arr.append((flo,cei,str(z['W'])))
 return start,arr

def run(pool,r):
 n=16**r;t0=time.monotonic();chunks=[(r,i,min(i+128,n)) for i in range(0,n,128)];data=[None]*n
 for count,(start,result) in enumerate(pool.map(work,chunks,chunksize=1),1):
  data[start:start+len(result)]=result
  if count%32==0 or count==len(chunks):print('r',r,'computed chunks',count,'/',len(chunks),'seconds',round(time.monotonic()-t0,2),flush=True)
 low=np.array([z[0] for z in data],dtype=np.int64);high=np.array([z[1] for z in data],dtype=np.int64)
 # all categories except last; values follow race_compare.states order
 cats=[[-F(3,4),-F(1,4)],[-F(3,4),-F(1,4),F(1,4),F(3,4)],[F(1,4),F(3,4)]]
 A=lil_matrix((1+5*r,n),dtype=np.float64);A[0,:]=1; rhs=[F(1)];row=1
 for rep in range(r):
  for g,cat in enumerate(cats):
   for val in cat[:-1]:
    for idx in range(n):
     d=(idx//(16**(r-1-rep)))%16
     if law[d][g]==val:A[row,idx]=1
    rhs.append(F(1,len(cat)));row+=1
 A=A.tocsr();print('r',r,'LP start','matrix nnz',A.nnz,'seconds',round(time.monotonic()-t0,2),flush=True)
 lp=linprog(-((low.astype(float)+high.astype(float))/(2*SCALE)),A_eq=A,b_eq=np.array([float(x) for x in rhs]),bounds=(0,None),method='highs',options={'threads':1});assert lp.success,lp.message
 support=np.where(lp.x>1e-9)[0].tolist();As=sp.Matrix(A[:,support].toarray().astype(int).tolist());bb=sp.Matrix([sp.Rational(v.numerator,v.denominator) for v in rhs]);solution,free=As.gauss_jordan_solve(bb);assert free.rows==0
 weights=[F(int(v.p),int(v.q)) for v in solution];assert all(w>0 for w in weights) and sum(weights)==1
 for j in range(A.shape[0]): assert sum((weights[k]*int(A[j,i]) for k,i in enumerate(support)),F(0))==rhs[j]
 independent=(F(sum(int(v) for v in low),n*SCALE),F(sum(int(v) for v in high),n*SCALE));coupled=(sum((w*int(low[i]) for w,i in zip(weights,support)),F(0))/SCALE,sum((w*int(high[i]) for w,i in zip(weights,support)),F(0))/SCALE);gap=coupled[0]-independent[1]
 save=[]
 for weight,idx in zip(weights,support):
  digits=[(idx//16**(r-1-j))%16 for j in range(r)];save.append({'index':idx,'weight':str(weight),'anchors':[[str(a) for a in law[d]] for d in digits],'D_bracket':[str(F(int(low[idx]),SCALE)),str(F(int(high[idx]),SCALE))],'W':data[idx][2]})
 out={'r':r,'tuples':n,'independent_D_bounds':list(map(str,independent)),'candidate_D_bounds':list(map(str,coupled)),'strict_gap_lower':str(gap),'candidate_strictly_better':gap>0,'support':save,'support_size':len(save),'LP_status':lp.message,'elapsed_seconds':time.monotonic()-t0,'scope':'atomic old KKT finite model, correct individual Euler marginals, not AC or globally calibrated; candidate only, not a proven optimum'}
 Path(__file__).with_name('scaling_r'+str(r)+'.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE r',r,'tuples',n,'support',len(save),'ind',float(independent[0]),'candidate',float(coupled[0]),'gap lower',float(gap),'seconds',round(time.monotonic()-t0,2),flush=True)

if __name__=='__main__':
 print('START pid',os.getpid(),'workers 14','python',platform.python_version(),flush=True)
 with ProcessPoolExecutor(max_workers=14,mp_context=get_context('fork')) as pool:
  for r in (3,4):run(pool,r)
 print('FINISH',flush=True)
