import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json,platform,time
R=F(15,272);eps=F(336,5);delta=F(1,100);M=F(16)
L=(-F(3,4),-F(1,4)); H=(F(1,4),F(3,4));
def states(shared):
 out=[]
 for il,ir,side in product(range(2),range(2),range(2)):
  xl,xr=L[il],H[ir]
  for ic in ([None] if shared else range(2)):
   xc=((L[1-il] if side==0 else H[1-ir]) if shared=='anti' else (xl if side==0 else xr)) if shared else ((L if side==0 else H)[ic]);out.append((xl,xc,xr))
 return out
assert len(states(False))==16 and len(states(True))==8
base=[('L',-F(1),F(8),F(4),F(3,2)),('C',F(0),F(16),F(8),F(7,2)),('R',F(1),F(8),F(4),F(3,2))]
def evaluate(r,tuples):
 E=[];B=[];C=[];ys=[];mass=[];labs=[]
 for g,(name,y,m,t,b) in enumerate(base):
  for i in range(r):
   x=tuples[i][g];c=(1+b)*y-b*x;l=y-F(1,32)+F(i,16*r);h=y-F(1,32)+F(i+1,16*r)
   E.append((t*l-b*(y+x),t*h-b*(y+x)));B.append((c-t/32,c+t/32));C.append((c-t,c+t));ys.append(y);mass.append(m);labs.append(f'{name}{i}')
 common=min(h for l,h in C)-max(l for l,h in C);assert common>0
 pts=sorted(set(x for ab in E+B for x in ab));atoms=defaultdict(F);W=F(0);image=F(0)
 for lo,hi in zip(pts,pts[1:]):
  x=(lo+hi)/2; incoming=tuple(i for i,(l,h) in enumerate(E) if l<x<h); receivers=tuple(i for i,(l,h) in enumerate(B) if l<x<h)
  if not receivers:continue
  assert set(incoming)<=set(receivers);v=hi-lo;W+=v
  if incoming:
   image+=v; eligible=tuple(i for i in incoming if all(C[i][0]<=ys[j]-1 and C[i][1]>=ys[j]+1 for j in incoming))
  else:eligible=receivers
  assert eligible;atoms[eligible]+=v
 p0=[F(0)]*len(labs);free=[F(0)]*len(labs)
 for indices,v in atoms.items():
  for j in indices:p0[j]+=v/len(indices)
  low=min(mass[j] for j in indices);winners=[j for j in indices if mass[j]==low]
  for j in winners:free[j]+=v/len(winners)
 p=[delta*p0[j]+(1-delta)*free[j] for j in range(len(labs))]; assert sum(p)==W
 levels={m:sum(p[j] for j in range(len(labs)) if mass[j]==m) for m in (F(8),F(16))};avail=[m for m in levels if levels[m]>0];lo=max(avail);hi=lo+eps*W+1
 def f(nu): return sum(eps*levels[m]/(nu-m) for m in avail)-1
 assert f(hi)<0
 # lower starts just above pole with exact positive sign
 lo+=F(1,10**20); assert f(lo)>0
 for _ in range(96):
  mid=(lo+hi)/2
  if f(mid)>0:lo=mid
  else:hi=mid
 qlo=lo-eps*W;qhi=hi-eps*W; O=F(1)-image;fill=W-image;Dlo=W-R*qhi;Dhi=W-R*qlo
 assert F(2,17)-O+fill+R*(M-qhi)==Dlo
 return {'replica_anchors':[[str(v) for v in x] for x in tuples],'common_C_length':str(common),'W':str(W),'image_union':str(image),'O':str(O),'fill':str(fill),'p_low_mass':str(levels[F(8)]),'p_high_mass':str(levels[F(16)]),'Q_bounds':[str(qlo),str(qhi)],'D_bounds':[str(Dlo),str(Dhi)],'eligible_atoms':[{'labels':[labs[j] for j in idx],'area':str(v)} for idx,v in atoms.items()]}
def aggregate(r,shared):
 law=states(shared);n=len(law)**r;totW=F(0);qlo=qhi=dlo=dhi=F(0);rows=[];start=time.monotonic()
 for tup in product(law,repeat=r):
  z=evaluate(r,tup);totW+=F(z['W']);qlo+=F(z['Q_bounds'][0]);qhi+=F(z['Q_bounds'][1]);dlo+=F(z['D_bounds'][0]);dhi+=F(z['D_bounds'][1]);rows.append(z)
 return {'replicas':r,'law':('opposite-point coupling' if shared=='anti' else 'shared Poisson race') if shared else 'independent Euler','branches':n,'time_seconds':time.monotonic()-start,'mean_W':str(totW/n),'mean_Q_bounds':[str(qlo/n),str(qhi/n)],'mean_D_bounds':[str(dlo/n),str(dhi/n)],'rows':rows}
out={'python':platform.python_version(),'scope':'atomic old KKT exploratory model, not an AC or calibrated-hard-state certificate','old':{'centers':['-1','0','1'],'old_lambda':['7/10','3/10','7/10'],'m':['8','16','8'],'epsilon':str(eps),'R':str(R),'source_points':['-3/4','-1/4','1/4','3/4'],'source_mass_each':'4'},'minQ_owner_rule':'simplex fixed W: increasing p on larger m strictly increases nu and Q, so each eligible free atom selects minimum m; ties may be split','cases':{}}
for r in (1,2):
 for shared in (False,True): out['cases'][f'r{r}_'+('shared' if shared else 'independent')]=aggregate(r,shared)
out['cases']['r2_anti']=aggregate(2,'anti')
# Rigorous positive-width lift: four uniform boxes radius h around the atomic sites.
h=F(1,10**12); rr=2
anchor_values=[L,L+H,H]; capture_margins=[]
for g,(_,y,m,t,b) in enumerate(base):
 for anchor in anchor_values[g]:
  c=(1+b)*y-b*anchor
  for _,old_y,_,_,_ in base:capture_margins.append(t-(abs(c-old_y)+1))
assert min(abs(v) for v in capture_margins)==F(1,8)
indep=out['cases']['r2_independent']; shared=out['cases']['r2_shared']
for key in ('r2_independent','r2_shared','r2_anti'):
 assert min(F(row['p_high_mass']) for row in out['cases'][key]['rows'])>=F(1,2)
 assert min(F(row['common_C_length']) for row in out['cases'][key]['rows'])>=F(15,4)
assert F(7,2)*h<F(1,8) and 26*rr*h<F(1,4)
derivative=(8+3*eps)**2/(F(1,2)*eps/F(4));assert derivative<F(6000)
Dconstant=F(13)+R*(F(6000)*52+eps*13);assert Dconstant<F(18000)
atomic_gap=F(indep['mean_D_bounds'][0])-F(shared['mean_D_bounds'][1]);lift_error=F(2)*18000*rr*h;assert atomic_gap>lift_error
anti=out['cases']['r2_anti']; anti_gap=F(anti['mean_D_bounds'][0])-F(indep['mean_D_bounds'][1]);
out['ac_lift']={'atomic_anti_minus_independent_D_lower':str(anti_gap),'AC_anti_minus_independent_D_lower_conditional':str(anti_gap-lift_error),'box_radius':str(h),'source':'four uniform intervals centered at -3/4,-1/4,1/4,3/4, each mass 4','r':2,'base_capture_margin':'1/8','base_common_C_length_lower':'15/4','base_high_p_lower':'1/2','W_error_per_action_bound':str(13*rr*h),'p_mass_error_each_bound':str(26*rr*h),'nu_partial_derivative_upper':'6000','D_error_per_law_bound':str(18000*rr*h),'difference_error_bound':str(lift_error),'atomic_independent_minus_shared_D_lower':str(atomic_gap),'AC_independent_minus_shared_D_lower_conditional':str(atomic_gap-lift_error),'algebraic_margin_positive_pending_independent_audit':True,'scope':'actual AC source and coupled independent/race marginal laws; fixed low-R state, not near-score or globally calibrated'}
print(json.dumps(out,indent=2))
