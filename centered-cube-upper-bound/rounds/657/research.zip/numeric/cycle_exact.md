# R657 — K3 real-cube geometry and exact fixed-p certificate

The following fixed-p successor program is realized by the seven two-dimensional cubes in load_model.json, but no compatible calibrated old state is established. An independent exact arrangement reconstruction in cycle_exact.py verified every positive-area membership mask and its area, maximal packing masks, receiver interior disjointness, and closed-intersection neighborhoods against the K3 records at both ε values. There are seven labels, ordered T0,T1,T2,A,B,C,D, each m=169 and p=169/4096. The five packing-cell incidences are T0 T1 T2 A; A B; B C; C D; D T0 T1 T2. Each label's receiver has a distinct cell of measure p; N_j is its closed incidence neighborhood. These hypotheses yield W=7p, P=5m/2, each P_N=2m, and W_N=5p for T0,T1,T2,A,D and 3p for B,C. The independent reconstruction uses expanded-cube halfside 13/2, receiver halfside 13/128, and the seven centers saved in cycle_exact.json. It recovers all 18 positive-area masks and all seven closed-intersection neighborhoods exactly. Receiver interiors are pairwise disjoint; each has area 169/4096, so W and W_N follow. Each neighborhood packing optimum 2m follows from its two independent eligible labels and the induced cell constraints.

Write e=ε/4096>0. Strict concavity of Σ_j[p log α_j+(m/ε)α_j], together with symmetric data and existence of a positive feasible point, gives a unique optimizer. By twin and reflection symmetry let each twin α=z/3, A=D=x, B=C=y. For e>1/2 the exact solution has y=1/2, z=1−x, with

x=(1−5e+sqrt((5e−1)^2+8e))/2,
1+e(2/x−3/(1−x))=0.

The active cells T0T1T2A, BC, DT0T1T2 have multipliers, normalized by p, 1/x+1/e, 2+1/e, 1/x+1/e, respectively. Other two cell multipliers are zero and their slack is 1/2−x>0. Every α is positive, so the nonnegativity multipliers vanish. These are complete feasible KKT conditions, not merely the univariate equation; strict concavity proves uniqueness. This full-domain calculation concerns K3 only and does not extend its threshold to K4. The exact boundary follows by inserting x=1/2 into x²+(5e−1)x−2e, which gives (2e−1)/4. For 0<e≤1/2 the solution instead has x=y=z=1/2 (twins each 1/6); all five cell constraints are active, with multipliers/p in listed order 3+1/(2e), 1/(2e)−1, 3+1/(2e), 1/(2e)−1, 3+1/(2e). At e=1/2 the two middle outer multipliers vanish. Thus e=1/2 is the exact full-domain switch.

Q′=m(2+x), d=P−Q′=m(1/2−x), κ′=εW/Q′=7e/(2+x) in the e>1/2 regime. The integer-square-root calculation produces exact rational enclosures preserved in cycle_exact.json (widths of order 10^−28 or smaller); decimal values here are only for readability:

| e | ε | x | d | κ′ |
|---:|---:|---:|---:|---:|
| 2 | 8192 | 0.424428900898 | 12.771515748229 | 5.774555811810 |
| 6/5 | 24576/5 | 0.441088233971 | 9.956088458977 | 3.441088233971 |

For the unconstrained LP P, β=(1/6,1/6,1/6,1/2,1/2,1/2,1/2) and η=(m/2,m/2,m/2,m/2,m/2) are matching feasible primal and dual witnesses. In particular a dual with all floor multipliers σ=0 exists for the unconstrained LP.

For the conditional t=0 floor LP, the denominator min in the supplied definition chooses the restricted-neighborhood term: ℓ=a=e/(1+5e) on T0,T1,T2,A,D and ℓ=b=e/(1+3e) on B,C. For e>1, an exact primal witness is β=(a,a,a,1−3a,1/2,1/2,1−3a). A matching dual witness, in the five-cell order above, is η=(m,0,m,0,m) and σ=(m,m,m,0,0,0,0), with Hᵀη−σ=m1. Both complementary slackness conditions hold. Hence L=m(3−3a) and G_p(0)=m(e−1)/(2(1+5e)); the exact values are 169/22 at e=2 and 169/70 at e=6/5. For 0<e≤1 the unconstrained LP witness satisfies the floors and G_p(0)=0. Thus e=1 is the exact threshold for this conditional initial certificate to be strictly positive. At both requested parameters, exact rational enclosures show 0<G_p(0)<d, so the t=0 certificate is below the actual entropy deficit.

A floor-constrained LP dual with all σ=0 cannot certify the positive values: its objective Ση is at least P, whereas the certified L<P. The σ=0 witness is valid for the unconstrained LP, not for the nontrivial floor certificate. This is a single safe initial bound only; no iteration or MAX switch is claimed.

Run `python cycle_exact.py` in this directory using Python with SymPy. Uses exact Fraction and integer isqrt for enclosures; no CVXPY. Versions are recorded in JSON. SHA-256: cycle_exact.py `1482fedf7d8707a2f934ffebf568d0ced2f632ec17dd93bfb1b7acd6bd37dae6`; cycle_exact.json `67b57b912fd0330be1980a6f706736712c0f9b559196dd6427ebdaad0ba5cd15`.

Compared geometry source: load_model.json SHA-256 `c8efdd2e2cd5c80f9cc9009eabfb4d3c8dbf4bbbaa79b2b1cdaf8db753f44bbf`. The JSON/solver results are fixed-p successor evidence only; old AC/KKT/Euler existence and near-score calibration remain unproved.
