# Independent transport audit

**PASS for the stated two-replica, one-dimensional fixed low-R comparison**, conditional on the pre-existing exact tuple-cost and uniform AC perturbation audits. The six-point law preserves each individual Euler anchor marginal but has dependent anchors. It is therefore a valid marginal-preserving alternative coupling, not the original independent-Euler law, and this comparison cannot by itself replace the independence hypothesis in a theorem that requires it. No claim is made for general dimension, ε* calibration, near-score states, multiple blocks, or global optimality.

## Quantifiers and marginal verification

The single old KKT fixture is fixed first, followed by r=2 and the six-point distribution; each of the six row coordinates must retain its own conditional source marginal. The law intentionally introduces dependence across rows and replicas. The independent comparator is the product of those same six marginals, and the comparison uses the full min-Q owner choice for each realized tuple. This is an existence witness for one specified coupling, not a maximization statement over all couplings.

An independent Fraction script verifies the 256 saved tuples are exactly the Cartesian product of the two left points, four center points and two right points in each replica, without duplicate or missing tuples. It checks the witness's six distinct indices, anchors and probability weights against the recorded rows. The weights (1/4,1/8,1/8,1/8,1/4,1/8) are positive and sum to 1; for every row in each replica, both outer atoms have mass 1/2 and all four center atoms mass 1/4. All six support tuples have W=2.

## Full D gap and AC lift

Using every saved branch's exact rational `D_bounds`, the script independently computes both the weighted six-point lower and upper D endpoints and the 256-term equally weighted independent endpoints. Both pairs exactly match the saved transport JSON. Their strict difference lower bound is

`1351305855028160217912201531789413377437339341431839 / 3448009632620783972071032718622720000000000000000000 > 3919/10000`.

The `D_bounds` are accepted from the separately checked race-compare source and its full receiver, capture, min-Q and ledger calculation; this audit does not rerun the underlying 256-branch geometry. The [AC coupling audit](AC_COUPLING_AUDIT.md) checks those saved root brackets and gives the uniform pathwise perturbation |D_AC−D_atomic|<18000rh for any coupling with the six prescribed one-row marginals, r=2, h=10⁻¹². Its geometry scan is itself explicitly dependent on the pre-existing 256 tuple arrangements.

Construct the AC coupling by first drawing one of the six atomic tuples with its given weight, then drawing a uniform independent displacement in [−h,h] for each of its six coordinates. Each coordinate's mixture is exactly its corresponding AC Euler marginal; applying the same procedure to the product atomic law yields independent AC anchors. The bound applies to both laws separately, so the difference loses less than `72000h=9/125000000`. Consequently

`E D_AC,coupled − E D_AC,independent > 48987491/125000000 > 0`.

This conclusion assumes the min-Q owner policy and uniform perturbation audit's hypotheses; it is a real positive-width AC fixed-model comparison, not evidence that correlated anchors are permitted by an independently sampled Euler construction. No CVXPY, optimization solver, scan, or new tuple geometry was run for this audit.

## Reproduction

Executed `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/transport_audit.py > /tmp/ccu_r657/numeric/transport_audit.json` with Python 3.12.14 and stdlib Fraction.

SHA-256:
- `race_compare.json`: 8a56b3fd50ce6aad99ae49f1398d856779bd13fc3954eb7e7d47a4e954599676
- `race_transport.py`: 61d963e3651bf6906f0843116382cb849b43de94c0dc155ed1a0bb03e0d78e68
- `race_transport.json`: f3a3a0237f9350bb67537b312091433ac3f87a0d81a5ca1f9e7956a875fb6728
- `race_transport.md`: b24ba944de3e7eb57ac539ab0639f1373b5659bcf13d695f53f9d3443d5fe23a
- `AC_COUPLING_AUDIT.md`: ba5d2a53c9ecad30d98c3fa363a238699fbb61a12ebe469ef9305b5522bc24b4
- `transport_audit.py`: 87f6cad6a2c83787595e6e22fb02c1ddebd49f4e39fc72c2c7265028f3f7184d
- `transport_audit.json`: ee1eb212da51982ef1e5753bb8801949ac289caf75cbaebfb5ee02fa697f8281
