# R657 independent fixed-block scaling audit

**Verdict: the empirical bound and scalar Wreach limit extend to arbitrary fixed finite block size b, with effective sample count N=r/b and the stated square-root-b cost. They do not copy a b-clone actual entropy gain into a larger-clone experiment.** This audit covers the quantifiers and scaling interface, not a general cube-budget theorem.

Read `numeric/race_transport.md` and `AC_COUPLING_AUDIT.md`. The six-tuple law is accepted here only as the specified correctly-marginalized b=2 coupling certificate; its positive-width perturbation theorem remains restricted to that r=2 fixture. No enumerations or solver jobs were repeated.

## 1. Exact block experiment

Fix an original finite old state/source before sampling. Partition every genuine old I_j into r=bN deterministic equal positive-volume pieces, where b is a fixed positive integer and N is the number of independent blocks (not a calibration label cap). Each clone has old weight a_j/r, lambda_j/r, volume v_j/r, and the same m_j,u_j as its parent. This preserves the old score exactly.

Block l contains b clones of every original row. Its joint anchor law may be arbitrary, provided **every one** of those individual clones has the exact prescribed marginal `mu|Aj/m_j`. Different blocks are independent. They may have different coupling laws, selected before sampling; identical distribution is unnecessary for the bounds below. All owner/availability/baseline/actual entropy computations still use the full bN-clone tuple.

If unequal clone weights or unequal block sizes are used, the effective variance is governed by the sum of squared total block weights; the simple square-root-b formula below cannot be asserted without the equal-splitting setup. Also, r growing through a single block of size b=r is not increasing the independent sample count.

## 2. High-source TV bound and its constant

For high original rows H, write `M_H=sum_H a_j` and define the normalized block measure

`Y_l=(1/b)sum_(j in H,s=1..b)a_j delta_(X_(j,s,l))`.

It has deterministic total mass M_H and mean `mu_H=(sum_H lambda_j 1_Aj)mu`, solely by the correct individual marginals. For the B positive-mu cells of the fixed original old membership algebra,

`sum_c Var(Y_l(D_c))<=E sum_c Y_l(D_c)^2<=M_H^2`.

The actual high empirical measure is `muhat_H=(1/N)sum_l Y_l`, because each clone's weight is a_j/(bN). Independent blocks give

`sum_c E[muhat_H(D_c)-mu_H(D_c)]^2<=M_H^2/N`.

Both measures have the same deterministic total mass. Every actual adaptive old-A packing probe f lies in [0,1] and is constant on this algebra, regardless of the coupled optimizer. Thus

`E|muhat_H(f)-mu_H(f)| <= (M_H/2)sqrt(B/N)`
`                         = (M_H/2)sqrt(bB/r)`.

In particular the absolute high signed correction has this bound. Since `MR=(1+kappa)V` and kappa<=4 in the genuine calibrated class, the same conservative allocation is valid with

`r>=25 b B/zeta^2` (and r a multiple of b),

giving `R|Gamma_H|<=zeta V`. Equivalently choose N>=25B/zeta^2. Arbitrary dependence within a block is allowed; dependence between blocks is not covered. The original cell count and b determine a finite clone choice, not a final theorem constant. To make the error vanish one must have N=r/b tend to infinity.

## 3. Wreach survives, including nonidentical blocks

Let q_j(x) be the fixed source's one-row full-receiver marginal, and let `q_l(x)=P(block l has some receiver covering x)` over its b clones of all original rows. Independent blocks imply exactly

`E W_(bN)=int [1-product_(l=1)^N(1-q_l(x))]dx`.

For identical block laws this is `int[1-(1-q_block(x))^N]dx`. It is not the old independent-row product. For each block,

`max_j q_j(x)<=q_l(x)<=min(1,b sum_j q_j(x))`.

Consequently every block has the same positivity domain `{some q_j>0}`. Moreover the missing-coverage product is at most `(1-max_j q_j(x))^N`. For the fixed source and old data a bounded receiver envelope exists, so dominated convergence yields `E W_(bN)->Wreach`. This remains valid for independent nonidentical block laws, even if their choices vary with N, because the displayed lower bound is uniform across blocks. No uniform positive probability or rate is asserted.

The source must be fixed first. If exploratory rarity or source support is changed with N, this domination no longer supplies the claimed same Wreach limit without a new quantitative argument. The row-specific support and boundary qualifications from the exploratory-source construction remain. The formula concerns all **full receivers**, not incoming image unions or globally filtered available-owner receivers. Images vary with the clone pieces, but receivers do not.

## 4. Why the six-row actual gain is not additive or preserved

The r=2 experiment allocates each original I_j to two pieces of volume v_j/2. At r=2N those real pieces have volume v_j/(2N). One cannot replicate the old half-pieces N times: that would violate disjoint full ownership and multiply V. Even with a carefully interlaced or repeated-pattern partition, proving an action/optimizer limit would be additional work.

Actual images change with these pieces, while every clone still has a full receiver. Cross-block incoming collisions, capture eligibility, baseline denominators, availability and the global min-Q entropy response all change. W is a union over blocks, not the sum of their union volumes; Q' uses one global source bound M, not N independent budgets. Neither old-score preservation nor the TV bound proves

`E D_(2N)>=E D_2`, an N-fold gain, preservation of the r=2 entropy deficit, or preservation of its advantage over independent anchors.

The r=2 positive-width bound `|D_AC-D_atomic|<18000 r h` was established only at r=2. The recorded mass-level/root and geometry checks do not automatically cover smaller pieces, new availability patterns or a much larger joint program. Its two-law error 72000h cannot be reused as a general bN comparison theorem. In particular a large clone count chosen to eliminate Gamma needs a new full-gain lower bound on that **larger actual experiment**, rather than a copied six-row table.

## 5. A limited receiver-only inheritance which is legal

There is one coarse statement that does not require preserving the small experiment's optimizer. Pathwise `W_(bN)>=W_block` for any block, while actual old-source packing gives `Q'_(bN)<=M`. Hence

`E D_(bN)>=E W_block-RM`.

This retains only a receiver lower bound, not the old block's actual entropy credit or its comparison against another coupling. For the specified six-tuple atomic witness, every block has W_block=2. In its positive-width lift the receiver symmetric-difference bound alone gives `W_block>=2-26h`, independently of how the smaller I pieces are shaped. Therefore a repetition of **that law** with any finite N does have the coarse whole-gain floor

`D_(2N)>=2-26h-RM=19/17-26h`.

This is a new direct receiver/source-cap bound, not the table's approximately 1.33167597 gain or its approximately .39190896 coupling advantage. Its scope is still the same low-R fixture. In fact

`kappa_next>=epsilon(2-26h)/M=42/5-(546/5)h>4`

at h=10^(-12), for every such tuple. The repeated fixture is therefore decisively outside the globally calibrated successor-closed class. It proves no near-score uniform budget even though the coarse finite-state lower bound is positive.

The accepted r=2 comparison itself lifts by its separate r=2 error theorem: the displayed strict atomic lower gap 3919/10000 becomes greater than `3919/10000-72000h=.391899928` at that width. This is not a result for arbitrary bN or an independent-anchor large-N gap.

## 6. What the global theorem still requires

Block coupling is a lawful new action on a fixed genuine near-score state, and its empirical/receiver interfaces can be made accurate with many independent blocks. What is missing is an actual cube-specific joint lower bound for the resulting `W_(bN)-R Q'_(bN)` or the equivalent net expression retaining `(R-T0)Pi`, K, finite T_r and the true entropy/availability gap. A persistence theorem for a chosen finite block's deficit would suffice only if it quantitatively accounts for the changed pieces and global owner response. A direct law-dependent full-gain bound could bypass persistence, but neither correct marginals nor block-TV supplies it.

All whole-state source/endpoint allowances remain single accounts. No per-block M, r=2 error constant, or small-block optimized Q may be transplanted into the large action without this bridge.

## Verification and stop

One lightweight installed-Python Fraction check verified the coarse fixture floor `19/17-26h`, its successor-cap exclusion, and the r=2-only error subtraction. The general variance and receiver-limit proofs above are analytic; no saved tuple enumeration, CVXPY run, new fixture scan or Git operation was performed. Audit complete for the stated scaling question.
