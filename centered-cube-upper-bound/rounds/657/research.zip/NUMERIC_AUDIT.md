# Independent exact geometry and floor-LP audit

Four specified finite fixed-p successor models pass the rational certificate, conditional on the R656 first-order neighborhood floor theorem and the stipulated actual owners. This audit does not construct any old AC KKT source or Euler action and does not establish all-finite ε* calibration, near-score status, or a general gain bound. The separate fixed-p entropy root and active-face audit belongs to the other reviewer; the present conclusions do not rely on the numerical optimizer.

The independent verifier reconstructs all square coordinates from the 3- or 4-twin centers and four singleton centers, each of side 13. Exact rational rectangular arrangements agree in every positive-area membership mask and area with the author data: respectively 18 or 22 masks and exactly five maximal packing sets. It verifies all receiver squares with side 13/64, including boundary-touching twins, have pairwise disjoint interiors. Therefore W=n·169/4096 and each disjoint full receiver contributes p_j=169/4096 under the stipulated full-receiver ownership.

Every row has m=169. The vector with twin coordinates 1/(2k) and singleton coordinates 1/2 is feasible with objective 845/2. Dual weight 169/2 on each of the five actual maximal cells covers every row at equality and totals 845/2. Thus P=845/2 and this genuine whole packing dual has all σ_j=0.

For every row, the verifier constructs its neighborhood from actual positive-area square intersections, not a presumed graph; each neighborhood has a feasible two-row packing of value 338 and a cover by two actual packing cells of total cost 338. These are exact primal and dual witnesses for each P_N=338. Disjoint receivers give W_N=|N|·169/4096. At t=0 and e∈{2,6/5}, ε=4096e, exact global and local denominators and each ell from the declared min formula agree with all supplied records. These ell are valid only if the stated fixed-p first-order result applies to the specified model; no old-state conclusion is inferred.

The bundle contains a separate complete incidence matrix with all positive-area masks, ordinary packing primal and dual certificates, floor-constrained feasible primal β, and floor dual η for each model. After matching the matrix and every area to the independently rebuilt geometry, the verifier checks Hβ≤1, β≥ell, η≥0 and Hᵀη≥m. It computes L_lower=m·β and L_upper=m·ell+η·(1−H ell), with equality in all four cases. Hence their exact positive gaps P−L are:

| twins | e | neighborhood G_p(0) |
|---:|---:|---:|
| 3 | 2 | 169/22 |
| 3 | 6/5 | 169/70 |
| 4 | 2 | 39/2 |
| 4 | 6/5 | 1183/82 |

The independent ordinary-packing primal also meets each global-only floor, proving global G_p(0)=0. This shows why the *floor-adjusted dual upper bound on L* is necessary: an unrelated ordinary-packing dual or a feasible floor primal alone cannot certify positive G. No CVXPY or floating optimization was invoked in this audit.

Reproduction with Python 3.12.14, standard-library Fraction:

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r657/numeric/verify_floor_lp.py --bundle /tmp/ccu_r657/numeric/load_model.json /tmp/ccu_r657/numeric/floor_inputs.json > /tmp/ccu_r657/numeric/floor_audit.json`

SHA-256:
- `verify_floor_lp.py`: 003e1c6e7c2fc6de53856c4d888a261dcd71966dd2e82695b23008fa74f461ea
- `floor_audit.json`: a68aa75aee6b24a97f6c4b9240c466e48df88849b2ca7ab3ffcbc0f0f6ab222f
- `floor_inputs.json`: fe8ee657cdc1a919d1f7ecef369e34b44cce3e929cc18d74868e03e196858073
- `load_model.py`: 46ce55acb715264fff4d81ca1897d70d7077017b6c83b80aede73497b2a4c306
- `load_model.json`: c8efdd2e2cd5c80f9cc9009eabfb4d3c8dbf4bbbaa79b2b1cdaf8db753f44bbf
- `load_model.md`: aba4d83696fb5727a4410e506c54762bdbe2b5379deb2593b500ec0d47e24d9d
