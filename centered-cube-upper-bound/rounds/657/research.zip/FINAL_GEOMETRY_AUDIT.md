# R657 final independent geometry and scaling audit

**Verdict: PASS within the stated partial-result scope.** The fixed-trial constrained-packing certificate, old-source/heavy-cube statements, replacement coupling interfaces, systematic old-cell balance and synchronized refinement are correctly integrated. No blocking error was found. The existence of a uniformly successful balanced near-score law, and hence the root-order weak bound, remains unproved.

## Frozen artifact binding

The following SHA-256 values were actually computed from the reviewed final files:

| File | SHA-256 |
|---|---|
| `/tmp/ccu_r657/REPORT.tex` | `f56d0fbd595a49b53c8eebb73e261d6947531c81ea89a6ae8e81b29a7eacab86` |
| `/tmp/ccu_r657/NEXT_TARGET.md` | `07d662950596ff78ddd928aec1203e0d9af4579771794aa5e595273d9abcd4ad` |

This final review reads the actual report and next-target bytes. The last rebinding checks only the pure TeX notation correction at report line 784, restoring the missing backslash in `\widehat\mu_H` in the target inequality. It changes no mathematical content; the next-target hash is unchanged and the partial-scope PASS remains. The reasoning below is self-contained; preliminary author files are not additional theorem premises. Passed numerical pools and verifier jobs were not rerun by this reviewer.

## Constrained packing and dual direction: PASS

The report fixes one actual positive available owner p throughout each G chain. The proved entropy FO bounds make `ell(p,t)<=alpha(p)` for `0<=t<=d(p)`, with strictly positive denominators. Thus actual alpha is a competitor in the floor-constrained LP, giving `Q(p)<=L(ell)<=P` and `0<=G_p(t)<=d(p)`. Increasing the floor shrinks the feasible set. These facts justify each finite feasible monotone iterate from zero, and its fixed-point limit by finite-LP continuity. A previously certified lower bound can safely be retained with a maximum. No arbitrary change of p inside the chain is authorized.

The shifted LP dual is correctly signed:

`L(ell)=min_y[||y||-(H^T y-m).ell]`,
`G_p(t)=max_y[(H^T y-m).ell-(||y||-P)]`.

Here y is a true positive-volume-cell covering dual. The excess mass is a debit. On feasible floors, the nonnegative shifted RHS makes dual rays unable to improve the minimum; finite dual vertices give the stated continuous piecewise-affine value. A feasible constrained primal alone lower-bounds L and therefore does **not** certify a lower G. The report and next target correctly require an upper L certificate, such as a feasible dual.

The floor may be infeasible near epsilon W. The report does not copy R656's MAX endpoint/chord theorem to this different G map, and selects only among completed fixed-trial chains. Its full expected certificate retains favorable Pi-P_Z, K, finite T_r and the true entropy response. The real cycle/twin example is expressly a conditional cube/receiver program without an old near-score/Euler realization; its stronger LP certificate is not called a global budget.

## Old-source and cube-specific leading-volume bounds: PASS

The old mu is only a feasible expanded-cube cover of mass M. If an optimal available-volume dual also met all old A demands, integrating old packing would force P=M and equality of those demands. The report correctly rejects this identification when P<M. Its signed mismatch identity is a **lower** estimate, not a bound that pays capture prices. All dual arguments require AC/positive-volume-cell representatives rather than arbitrary contact atoms.

The final endpoint clarification was separately checked and rebound above: if P=m_j, the capped old-source numerator is zero, and its possibly 0/0 terminal ratio at t=epsilon W is defined by continuous extension as zero. This is the correct closed-domain convention and creates no new pressure or endpoint credit. The next-target hash is unchanged.

For the old-source capped pressure variant, removing mu on C_j and adding a neighborhood dual proves `mu(C_j)<=P_Nj+(M-P)`. The complete gap g=M-P is retained in the pressure inequality and its startup threshold. The caps validate the quoted endpoint argument; no new independent source allowance is introduced. This variant is explicitly allowed to vanish without paying unused load.

The heavy-source result uses the strict threshold `m_j>M/2` and actual old AC mu. Any two such A have positive mu intersection and therefore positive Lebesgue intersection. For finitely many axis boxes, coordinatewise extrema then prove a common positive-volume intersection; this is the correct box-specific Helly range. With z in that intersection, each B_j lies within `Q(z,(1+1/a)s_*)`. Taking heavy owner volume as `V_H=sum_H v_j`, disjoint real I imply

`V_H<=|union_H B_j|<2M`.

The empty heavy class is trivial. This pays only that portion of the **leading owner volume** once, with every heavy anchor, input and packing variable retained in the full action. It is not a heavy lost-copy estimate or a renewable mass-band payment. The next target preserves this scope.

The whole-face entropy comparison is also correctly conditional. Its objective is affine in p and convex in positive high-volume gamma. Positive baseline makes the boundary coercivity uniform over the compact owner polytope, allowing one compact positive slice and finite convex minimax. A positive minimum then supplies one owner whose actual entropy optimum leaves the high-volume slice. The report constructs no uniform beta/t witness and does not use the alternative as a proved full gain.

## Coupled actions and independent blocks: PASS

Correct row marginals are explicitly distinguished from independent rows. The shared first-hit construction has the stated conditional marginal and almost surely finite sampling of a finite family. Pathwise capture, actual owners, fixed-p entropy, full D, calibration and the score bridge survive. Conditional-on-other-row source-window laws, single-row ghost swaps and within-block row-product receiver formulas are correctly withheld.

For r=bN equal clones, each normalized high block measure has total mass M_H and mean mu_H. Independent blocks give the stated variance/old-cell-TV bound `(M_H/2)sqrt(B/N)`, without assuming within-block independence or freezing actual alpha. The block union probability is used in the receiver formula, and `q_l>=max_j q_j` proves the same Wreach limit at fixed positive source even for nonidentical independent blocks. These are scalar receiver/concentration results, not convergence of Q' or preservation of a small block's optimized gain. The changed v/(bN) piece geometry and one global M are retained.

## Systematic balance and synchronized refinement: PASS

Uniformly shifted r-point grids give each row its prescribed cell-tag marginal and floor/ceiling counts for every half-open cell-probability interval. Sampling the actual conditional mu|cell law independently of phases gives the exact **continuous** row marginal, not merely a discrete tag law. Dependence among phases or among cell points is allowed as stated.

Weighted cell count error gives pathwise old-algebra TV at most `sum_H a_j B_j/(2r)<=BM_H/(2r)`. The actual common coverage `f_Z=sum alpha_jl 1_Aj` is constant on that fixed old membership algebra and in [0,1] there: positive-mu old cells have positive Lebesgue volume, and actual packing together with A_j subset C_jl bounds their constant loads. The fixed old cube boundaries are AC-null. This uses no cross-row independence or new-C boundary probe claim. The resulting signed/absolute distinction and `R|Gamma_H|<=5BV/(2r)` are correct. Neither frozen file extends it to arbitrary row-dependent, image-window, new-C or within-cell-varying probes, or confuses it with continuous full TV.

The synchronized refinement theorem uses a common finite k and genuine nested old pieces. It assumes no null topological boundary for arbitrary measurable pieces: only disjointness/coverage modulo null sets, preserved by the affine action, is used. Images partition their parent image, and C/B' repeat exactly. Image eligibility projects one child per parent; fill projects k per parent. Uniform grouped baseline and the entire P_delta projection are therefore unchanged, including zero-eligible children.

At fixed fine p, repeated-C packing aggregates by parent, and actual entropy gives `alpha_child=beta_parent p_child/p_parent`. The remaining log term is constant in beta, so actual grouped Q equals coarse Q. Surjectivity proves min-Q and full-D invariance. Future owners may be recut; the report does not promise to retain a pre-existing pointwise cut. Weighted source empirical measures are exactly equal under synchronization. This preserves an already balanced coarse correction, but creates no independent samples, new balance, receiver exhaustion or calibration repair.

## Model scopes and final unclosed theorem

The positive-width coupling result is fixed at r=2 and h=10^(-12); it is not extended using only the weaker capture-margin condition h<1/28. The final text uses the corrected opposite-point terminology. Exact six-row Euler marginal and full-D gains are distinguished from global coupling optimality. The r=3–5 results remain atomic producer enumerations with the independently recomputed support scopes stated. The r4 exactly balanced witness is atomic and has no asserted AC upgrade. The report explicitly notes that W=3 forces successor kappa>4, and the AC six-tuple block bound likewise remains outside the calibrated domain. Critical-band old kappa or positive finite gain is not substituted for a near-score/global-epsilon certificate.

The next target demands **the same law** have both small common old-cell correction and full expected gain. It retains K, T_r, the entropy/availability advantage and all actual loss/fill; it does not combine systematic balance with a different successful law or charge a direct full-D proof an unused Gamma fee. Synchronized refinement only preserves a successful balanced witness if one already exists. That uniform coarse existence theorem is the substantive remaining gap.

Audit complete for the two hashes above. No new numerical pool, solver campaign, author-file edit, Git operation or PDF compilation was performed by this reviewer. The partial geometric mechanisms pass; no root-order closure is certified.
