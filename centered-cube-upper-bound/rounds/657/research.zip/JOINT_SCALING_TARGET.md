# R657 joint scaling: exact synchronized refinement and the remaining balanced-gain theorem

**Decisive general result.** A finite coupled full-`D` witness can be refined to arbitrarily many clone labels without changing its actual minimum-`Q` gain **or its source-cell discrepancy**, provided every coarse piece is refined by the same factor and its children inherit its anchor synchronously. Thus a witness that is already sufficiently balanced is compatible with arbitrarily fine nested cloning. This does not balance an unbalanced witness, and does not prove a uniform near-score gain. The exact unresolved task is to find the positive full-`D` witness inside the balanced coupling class in the first place.

No new computation was launched. The finite toy results are not used as evidence for a general-dimensional inequality.

## 1. Key exact formula

Start with any finite legal coarse clone experiment. Index its old labels by `b`; its real positive old owners are `I_b`, with source law `mu|A_b/m_b`, old coefficients `lambda_b`, and `a_b=lambda_b m_b`. Its coarse joint anchor law may be arbitrarily dependent, provided each row has its correct Euler marginal.

Choose an integer `k>=1`. Before sampling, split **each** coarse `I_b` into `k` positive equal-volume measurable pieces `I_bh`. Use old weights `lambda_b/k`, the same `A_b,B_b,m_b,u_b`, and set

\[
 X_{bh}=X_b\qquad(h=1,\ldots,k).
 \tag{1.1}
\]

Then, for every coarse anchor tuple outside the ordinary null boundaries,

\[
 \boxed{\quad
 W_{\rm fine}=W_{\rm coarse},\qquad
 Q^{\min}_{\rm fine}=Q^{\min}_{\rm coarse},\qquad
 D^{\min}_{\rm fine}=D^{\min}_{\rm coarse}.
 \quad} \tag{1.2}
\]

Here `Q^min` uses the true capture/image-priority owner polytope with the same fixed `delta=.01`, and the true fixed-owner entropy optimizer; `D^min=W-R Q^min`. The source empirical measure itself satisfies the pathwise identity

\[
 \boxed{\quad
 \sum_{b,h}\frac{a_b}{k}\delta_{X_{bh}}
       =\sum_ba_b\delta_{X_b}.
 \quad} \tag{1.3}
\]

The same identity holds after restricting to any fixed old row class, including the high class. Consequently any already achieved discrepancy on the old source-cell algebra is preserved exactly. Formula (1.3) asserts equality of the two **empirical measures**; it does not assert that either empirical measure is close to the AC source in full continuous-measure total variation.

## 2. Proof of the full optimizer/owner invariance

The child source laws and old KKT data are legitimate because each child inherits the same correct marginal and has old volume and lambda divided by `k`. Its `m,u,t,b` are unchanged. Therefore all children of `b` have the same expanded cube and receiver as `b`, and their images partition the coarse image:

\[
 C_{bh}=C_b,\qquad B'_{bh}=B'_b,\qquad
 E_b=\bigsqcup_h E_{bh}\quad\text{modulo null sets}.
 \tag{2.1}
\]

The receiver union and its volume are unchanged.

At an **image point**, each incoming coarse label has exactly one incoming child. Every child has the same old `A_b` and high/low status as its parent, so the capture tests are unchanged. The fine eligible set contains exactly one child for each coarse eligible label. Thus uniform baseline sharing among eligible labels has exactly the old **grouped** share.

At a **fill point**, every coarse eligible label has all `k` identical children eligible. Since the factor is common to every coarse label, their grouped baseline share is again exactly the original one. Children with zero eligible measure are subsequently unavailable in the normal way; this does not change either a.e. statement.

It follows that the grouped baseline volumes obey

\[
 \sum_h p^0_{bh}=p^0_b.
\]

Moreover, grouping maps the entire fine owner polytope onto the coarse one:

\[
 \left\{\left(\sum_hp_{bh}\right)_b:
             p_{\rm fine}\in\mathcal P_{\delta,\rm fine}\right\}
       =\mathcal P_{\delta,\rm coarse}. \tag{2.2}
\]

The forward inclusion groups a real fine allocation. For the converse, realize a coarse free allocation; on image points give its selected parent share to the unique incoming child, and on fill points split it among eligible children. Combine it with the prescribed fine baseline. This produces a fine feasible volume vector with the desired grouped volumes. All available fine coordinates remain positive because of the baseline.

For any fixed such fine owner vector, put `p_b=sum_h p_bh` and `beta_b=sum_h alpha_bh`. Identical expanded cubes make the fine packing constraints exactly the coarse constraints on beta. For fixed beta and fixed p, maximizing the fine entropy over the children gives

\[
 \alpha_{bh}=\beta_b\frac{p_{bh}}{p_b},
\]

\[
 \sum_hp_{bh}\log\alpha_{bh}
 =p_b\log\beta_b+
   \sum_hp_{bh}\log\frac{p_{bh}}{p_b}.
 \tag{2.3}
\]

The final term is constant in beta. The grouped actual optimizer is therefore precisely the coarse fixed-`p_b` entropy optimizer, and its linear mass is the same:

\[
 Q'_{\rm fine}(p_{\rm fine})
       =Q'_{\rm coarse}(p_{\rm grouped}). \tag{2.4}
\]

Taking minima using the surjection (2.2) proves (1.2). No old joint-B free minimum-price rule is used. No comparison packing is substituted for the actual optimizer.

Even if one does not compute the nonconvex min-Q optimum, **every** concrete coarse owner witness can be lifted by this argument to a genuine fine owner witness with exactly the same actual `Q'` and `D`. A finite witness selector can therefore use the lifted owner directly.

The common refinement factor matters on fill: unequal numbers of children per parent generally change the grouped uniform baseline. The statement also requires a genuine nested refinement. Small piece volume alone does not make an arbitrary unrelated partition a refinement of the successful coarse pieces.

## 3. General nonrational balancing has a pathwise old-cell error bound

Let `D_s`, `s=1,...,B`, be the finite positive-mu **old membership cells**, and for each original old row let

\[
 \pi_{js}=\frac{\mu(A_j\cap D_s)}{m_j}.
\]

These probabilities sum to one. Order the cells, form their cumulative-probability intervals in `[0,1)`, and for row `j` choose a uniform phase `U_j`. Give clone `l` the cell tag containing

\[
 (U_j+l/r)\pmod1,\qquad l=0,\ldots,r-1.
 \tag{3.1}
\]

Every clone has the exact cell marginal `pi_js`. The row cell counts obey, pathwise,

\[
 N_{js}\in\{\lfloor r\pi_{js}\rfloor,\lceil r\pi_{js}\rceil\},
 \qquad |N_{js}/r-\pi_{js}|\le1/r. \tag{3.2}
\]

The phases may have any joint copula with uniform row marginals; their independence is not needed for (3.2).

To supply continuous anchors, one convenient construction samples, for each positive cell, a random point

\[
 Z_s\sim\mu|_{D_s}/\mu(D_s),
\]

independently of the phases, and gives every clone assigned to that cell the anchor `Z_s`. Correct old membership implies that the conditional law is the required one for every row using the cell. The `Z_s` may themselves have any joint law with these marginals. Thus each clone has its exact full Euler marginal. No uniform distribution within a cell, independent coordinates, or row independence is assumed. Sampling separate conditional points instead of a shared point is another legal choice; no full-gain comparison between those choices is asserted.

Let `B_j` count the positive source cells for row `j`. For the fixed high row class define the weighted empirical measure

\[
 \widehat\mu_{H,r}=\sum_{j\in H}\frac{a_j}{r}
                         \sum_l\delta_{X_{jl}},\qquad
 \mu_H=\sum_{j\in H}\lambda_j\mathbf1_{A_j}\,\mu.
\]

Both have total mass `M_H`. The **coarsened old-cell** total variation satisfies pathwise

\[
 \operatorname{TV}_{\{D_s\}}(\widehat\mu_{H,r},\mu_H)
 :=\frac12\sum_s
       |\widehat\mu_{H,r}(D_s)-\mu_H(D_s)|
 \le\frac1{2r}\sum_{j\in H}a_jB_j
 \le\frac{BM_H}{2r}. \tag{3.3}
\]

This is not full total variation between the atomic empirical measure and an AC measure; that quantity generally does not become small. It is exactly the finite algebra on which the adaptive old-source test `f_Z=sum_j(sum_l alpha_jl)1_Aj` is constant. Its signed empirical discrepancy is therefore bounded by (3.3), even though the actual optimizer depends on all tags and anchors. In particular,

\[
 R|\Gamma_H|\le\frac{BMR}{2r}
 =\frac{B(1+\kappa)V}{2r}\le\frac{5BV}{2r}. \tag{3.4}
\]

For normalized full-source cell TV, `r>=B/(2 eta)` gives error at most eta. For absolute source-mass TV, choose `r>=BM/(2 eta)` instead. All these are finite choices made after the old state and positive exploratory source are fixed; cell count determines the action size, not a final theorem coefficient.

If every `r pi_js` is an integer, then every row's cell counts are exact, so (3.3) is zero state by state, including for the high class. Rationality of the weights `a_j` is unnecessary. With nonrational probabilities only the stated rounding error is claimed.

The tag map is measurable, and conditional sampling uses the actual Borel probability measure on each positive cell. The construction is fixed before the action. It supplies a nonempty admissible balanced coupling class; it does not establish that a coupling optimizing the full-D cost over that class attains its supremum, nor does it claim a positive gain for the displayed particular shared-point construction.

## 4. Exact quantifiers and the first remaining gain theorem

For a chosen coarse partition and coupled law, let

\[
 \mathcal E(\pi)=\mathbb E_\pi[W-RQ'_{\min}],
\]

where both terms come from that **same** whole-tuple law and the actual owner/entropy program. Formula (1.2) says that any uniformly nested synchronized refinement has exactly the same `E(pi)`. Formula (1.3) says that it has exactly the same cell discrepancy. Therefore:

> If one finite coarse coupled law already has old-cell TV at most eta and full expected gain at least g, then arbitrarily large common-multiple nested refinements admit a law with the same correct Euler marginals, the same TV bound, and exactly the same full expected gain g.

This is the general refinement compatibility statement actually proved. It does **not** turn the finite unbalanced gain examples into a family balanced as `eta->0`. Synchronized replication preserves a nonzero coarse discrepancy rather than decreasing it. Stratification decreases the discrepancy, but replacing an existing law by a stratified law can change the whole successor owner geometry and actual `Q'`.

There is also no small physical-gain error merely from the `1/r` count error in (3.2). One changed clone still contributes a full expanded cube and its full receiver, although its old image piece is small. Availability, fill and the actual optimizer can change together. A separate proved comparison is required to bound that change in `D`.

The genuinely missing theorem is therefore

\[
 \text{for every required finite old near-score state and every }\eta>0,
 \quad \exists\text{ a finite balanced coupling }\pi_\eta
 \quad\text{such that}\quad
 \mathbb E_{\pi_\eta}[W-RQ'_{\min}]
      \ge cV-CLM,
 \quad L=C_0\sqrt n\,\operatorname{polylog}n.
 \tag{4.1}
\]

The refinement theorem removes a possible loss of an **already balanced** witness under further legal nested subdivision. It does not supply the dimension-dependent gain in (4.1). The accurate obstacle is the simultaneous optimization of source-cell balance, true image/capture eligibility, and actual entropy deficit inside one coupling—not an inability to make the source-cell discrepancy small by itself.

## 5. Full coverage and entropy terms stay coupled

For any one of these finite coupled actions, keep

\[
 \Delta_\pi=\Pi-\mathbb E_\pi Q',\qquad
 K=T_0\Pi-W_{\rm reach},\qquad
 T_\pi=W_{\rm reach}-\mathbb E_\pi W.
\]

The exact net account remains

\[
 \mathbb E_\pi D
   =R\Delta_\pi-(R-T_0)\Pi-K-T_\pi. \tag{5.1}
\]

Under synchronized refinement, both expected `W` and expected actual `Q'` are invariant, so the corresponding full net account is invariant. The receiver remainder `T_pi` is also preserved; it is not driven to zero by this refinement.

Independent block repetition has a separate receiver-exhaustion proof in `COUPLING_AUDIT.md`, but no theorem that it preserves a coarse full-`D` gain. The balanced shared-point construction above need not exhaust all continuously reachable receivers either. Thus neither receiver convergence nor a finite receiver advantage may be substituted for the entropy term in (5.1).

The audited finite coupled examples demonstrate that joint choice can change complete `D`. The later finite coverage saturation and the exact independent receiver exhaustion formula explain why a finite receiver advantage need not persist with clone count. They do not decide the all-scale actual-`Q'` advantage or (4.1). Any final root-order claim must pay the whole right side of (5.1) under the same balanced law.

**Bounded stop.** The new general mechanism is the exact synchronized-refinement theorem (1.2)–(1.3), together with the precise nonrational old-cell balancing cost (3.3). No general balanced full-gain lower bound or arbitrary-nonnested-partition stability is asserted. Only this assigned file was written; no calculation, scan, Git operation, or further task was started.
