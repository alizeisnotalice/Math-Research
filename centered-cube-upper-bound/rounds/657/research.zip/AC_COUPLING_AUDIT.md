# R657 independent audit — positive-width coupling, r=2

**Conclusion.** For the specified r=2 old state and for any coupling of the six atomic anchors with the prescribed one-row marginals, the uniform bound |D_AC−D_atomic|<18000 r h is valid under the stated min-Q owner policy, with h=10^−12. Consequently the difference of two such expectations changes by <72000h. In particular, the stored exact independent-minus-first-hit atomic lower bound 0.00025578199646… gives an AC lower bound greater than 0.00025570999646. This is an AC lift of this low-R fixture, not a near-score or calibrated-global theorem. The 18000 constant is verified for r=2, not claimed uniformly in arbitrary r.

## Geometry and old state

Old centers y=(−1,0,1), old A_j=[y_j−1,y_j+1], each old receiver I_j=B_j=[y_j−1/32,y_j+1/32], old m=(8,16,8), λ=(7/10,3/10,7/10), ε=336/5, R=15/272. Replacing each atom s in {−3/4,−1/4,1/4,3/4} by a uniform mass-4 interval [s−h,s+h] retains precisely the same old-cube incidence, since h<1/4. Hence the masses stay (8,16,8), the dual source remains supported in the saturated left/central and central/right cells, and λ·m=16 equals total μ mass. This retains the old packing KKT witness and all Euler one-row conditional marginals. These claims do not require the new draws to be jointly independent.

For each allowed old row/anchor, c=(1+b)y−bX, B′=[c−t/32,c+t/32], C=[c−t,c+t], and E is the affine image of its assigned old I piece. Each endpoint of E, B′, C moves at most b h. Independent exact rational enumeration of the 8 possible single-row anchor choices and 3 old high cubes found capture containment signed margins with minimum absolute value 1/8; since max b=7/2, h<1/28 preserves every capture Boolean, including failed captures. Independently bounding all allowed C simultaneously gives min(right endpoints)−max(left endpoints)=15/4 before perturbation, at least 15/4−7h afterward. Thus all true successor cubes share a positive interval, and their packing constraints reduce to the simplex for every coupled realization. E⊂B′ remains exact because the old image piece lies inside I=B.

For r=2 the sum of B′ lengths is r(1/4+1/2+1/4)=2, while a center receiver alone has length 1/2. Hence 1/2≤W≤2 for every atomic and perturbed tuple; the original bound W≤3 is safe. Each interval of fixed length shifted by at most b h has symmetric difference at most 2b h. Summing over all r copies of E and B′ gives bad set measure ≤4r(3/2+7/2+3/2)h=26rh. For B′ alone the bound is 13rh, so |ΔW|≤13rh.

This argument does not assume the order of endpoints or coincident endpoints stays unchanged. Outside that measurable bad set all incoming and receiver membership sets are identical; fixed capture Boolean matrices therefore give the identical eligible-label set. The mass-level δ-baseline share and min-m free-owner share are also identical there, including arbitrary changes in how equally massive eligible labels split a tie. They each lie in [0,1], so each aggregate mass-level total p_8 and p_16 differs by at most 26rh. Labels may become available or unavailable; only aggregate level totals enter the simplex scalar KKT equation, and no fixed label-support assumption is needed.

## Scalar root and bounds

All 256 stored independent r=2 branches cover every possible pair of atomic anchor triples. A separate rational scan of their saved eligible-atom lengths and labels recomputed both mass-level p values and checked their sums, finding min p_16=1/2. The 64+64 saved first-hit and opposite branches were separately checked too. This is a check of the stored geometry records, not an independent rerun of the 256 tuple arrangements; their own correctness remains dependent on the exact source enumeration. Along the linear path between atomic and AC p values, |Δp_16|≤52h<1/4, hence p_16≥1/4; W=p_8+p_16 remains in [1/2,2].

For the actual min-Q owner, the simplex KKT equation for mass levels is Σ_{m=8,16} ε p_m/(ν−m)=1 with ν>16 and Q′=ν−εW. Reassigning free eligible mass from 16 to 8 strictly lowers the root for a fixed total W, which proves the min-m policy; equal-m choices do not change aggregate p or Q′. p_8=0 is allowed and does not cause a singularity because p_16≥1/4. The path satisfies ν−16≥εp_16≥ε/4 and ν−8≤8+εW≤8+2ε<8+3ε. Differentiating the exact equation gives

∂ν/∂p_m = [1/(ν−m)]/[Σ_k p_k/(ν−k)^2]
≤ (8+3ε)^2/[(1/2)(ε/4)] = 549152/105 < 6000.

Therefore |Δν|≤6000·52rh and |ΔQ′|≤(6000·52+13ε)rh. With D=W−RQ′,

|ΔD|≤[13+R(6000·52+13ε)]rh=(293540/17)rh<18000rh.

No solver residual is used as an error bound. The root signs at both recorded rational Q′ endpoints were checked exactly for all 384 saved r=2 branches, using their recomputed p_8,p_16. The bounds on D are uniform over all those states and every within-box displacement |ξ|≤h; averaging preserves them. Two laws each incur <18000·2h, so their difference incurs <72000h=0.000000072.

## Coupling and evidence

For first-hit, use the same outer sample as the center sample; for opposite-point, use the corresponding opposite-box point with the same displacement. Both center samples remain uniform on their required boxes and have the correct unconditional Euler marginal. For any other previously specified joint distribution of atomic anchors, independently draw uniform displacements in [−h,h] for each coordinate conditional on the atomic tuple: this retains each required uniform-box marginal and gives the same uniform pathwise error, regardless of replica dependence. The method therefore applies to any separately certified coupling of the 256 atomic states with the required six marginals; it does not certify that a separately reported coupling is optimal or that its asserted atomic gain has been proved.

Evidence: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 3.12.14, exact `fractions.Fraction`; direct arithmetic checks (1) the capture margin list, common intersection and constants, (2) recomputed aggregate p and both exact root signs from all 384 stored rows, and (3) the gap lower bound. No CVXPY and no new 256-tuple geometry enumeration were run. Checked input race_compare.json SHA-256 `8a56b3fd50ce6aad99ae49f1398d856779bd13fc3954eb7e7d47a4e954599676`; associated script SHA-256 `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`. Exact parent source gap is retained in its JSON.

Release verification: the main agent reran the current script on 2026-10-29 and reproduced all 408 r1/r2 tuple records and every other JSON field except measured time_seconds. The script hash above corrects an earlier transcription error; see numeric/race_replay_audit.json. This does not extend the AC theorem beyond r=2.
