"""Archive integrity and bounded portable certificate replays; no PDF compilation."""
import argparse, ast, hashlib, json, re, shutil, subprocess, sys, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--replay', action='store_true')
args = parser.parse_args()
manifest = json.loads((root / 'manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for p in (root / 'numeric').glob('*.py'):
    ast.parse(p.read_text(), filename=str(p))
tex = (root / 'REPORT.tex').read_text()
labels = re.findall(r'\\label\{([^}]+)\}', tex)
refs = re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', tex)
assert len(labels) == len(set(labels)), 'duplicate labels'
assert set(refs) <= set(labels), sorted(set(refs) - set(labels))
assert '\\begin{document}' in tex and '\\end{document}' in tex
result = {'verified_files': len(manifest['files']), 'tex_labels': len(labels),
          'pdf_compiled': False, 'replays': []}

def stable(x):
    if isinstance(x, dict):
        return {k: stable(v) for k, v in x.items() if k not in {'time_seconds'}}
    if isinstance(x, list):
        return [stable(v) for v in x]
    return x

if args.replay:
    with tempfile.TemporaryDirectory(prefix='ccu-r657-portable-') as tmp:
        dst = Path(tmp) / 'numeric'
        shutil.copytree(root / 'numeric', dst)
        jobs = [
            (['verify_floor_lp.py', '--bundle', 'load_model.json', 'floor_inputs.json'], 'floor_audit.json'),
            (['race_compare.py'], 'race_compare.json'),
            (['transport_audit.py'], 'transport_audit.json'),
            (['scaling_audit.py'], 'scaling_audit.json'),
            (['scaling_r5_verify.py'], 'scaling_r5_verify.json'),
            (['balanced_audit.py'], 'balanced_audit.json'),
        ]
        for command, expected in jobs:
            run = subprocess.run([sys.executable, *command], cwd=dst,
                                 capture_output=True, text=True, timeout=180, check=True)
            assert stable(json.loads(run.stdout)) == stable(json.loads((dst / expected).read_text())), command
            result['replays'].append(command[0])
result['scope'] = ('Finite certificates only. Replays all 408 r1/r2 records, floor geometry/LP certificates, '
                   'and all saved coupled supports; r5 independently checks stored-array aggregation, '
                   'not every tuple geometry. Does not rerun optimizers or certify a general theorem.')
print(json.dumps(result, ensure_ascii=False, indent=2))
