# R657 最终独立费用审计

**最终状态：限定范围 PASS，无阻塞项。最终 REPORT/NEXT 绑定及签核见文末。下文1–5保留先于 REPORT 的独立核对轨迹；一般 `E D>=cV-CLM` 与 root-order 弱型上界仍未证明。**

已按指定读取 SOURCE_BRIDGE、BLOCK_SCALING_AUDIT、numeric/scaling_summary；不扩扫描或重跑旧数值。输入 SHA-256：

- SOURCE_BRIDGE：`5a8a69fc68731609d74815e159fb8c8bc54bbc8784cc80f6db988ef0309541c1`
- BLOCK_SCALING_AUDIT：`6be1f781eeb9c99c243009ffa59f50c764c63f3004bd84a2ce527668edef15cd`
- scaling_summary：`4fc9a74ba741b46f30c488c140d1d1e7f57bdce8d6b56ffe09a5561b4b496f9e`

以下是独立核对标准及已确认的范围，不把输入作者的结论当成一般 theorem。

## 1. 完整总账与全局取序

最终必须保留

`D=E-O+F+RS=W-RQ'`，

`E D=R Delta-(R-T0)Pi-K-T_r`，

其中 `Delta=Pi-E Q'`、`K=T0 Pi-Wreach>=0`、`T_r=Wreach-E W_r>=0`。只控 entropy deficit 的必要弱式不能删除 K/T_r 后冒称充分；Π 仍为 true reachable-cube linear benchmark，不是 actual optimizer。

先固定 all-finite epsilon_*，再取有限 near-score 旧状态、合法 source／正探索、有限 clone/block 数和 anchors。旧 score 精确保留不代表实际后继 D 或 optimizer保留。旧 source H 只按合法 moment/saturation/Hall 变化计一次；current linear dual不能直接当 old或next entropy KKT source。

完整 candidate certificate记为 C_r，若 owner近优误差为 tau，则一次可用 score期望为

`E[D_sel-4LQ'_sel]>=C_r-R E tau-4LM`。

必须严格超过总 near-score误差 eta·M才可取 favorable tuple；选出后再取任意实际 next AC source，不需偷偷假设 measurable source kernel。若直接用 full D，不另扣未使用的 Gamma近似；若用 tagged non-correlation项，则仅扣实际采用的整项 Gamma误差。source/exploration容差、有限coverage误差和tau各只收费一次；不逐row/block/cell更新 M或4LM。

## 2. Fixed-p constrained-floor LP 的准确范围

在一个 frozen tuple 内固定同一真实 p及其 actual alpha(p)，d=P-m.alpha。若 ell_j(t)=epsilon p_j/D_j(t)，则 t<=d 时 `ell(t)<=alpha`，所以

`P_p(t)=max{m.beta:beta in K_C,beta>=ell(t)}`

可行，且 `G_p(t)=P-P_p(t)<=d`。floors随 t增，故 exact G_p非减；从零迭代的 t<=d不变性才是证书。固定 p不等于预先不许看tuple，而是同一tuple的整个该迭代不擅自换 p。

其 dual 方向必须为

`G_p(t)=sup_(nu(C)>=m) [sum_j (nu(C_j)-m_j)ell_j(t)-(||nu||-P)]`。

非optimal dual的 mass excess只扣一次。该 constrained dual不再受“总mass=P的compact optimal face”约束，其 optimal face可无界，不能宣称每个此类nu mass<=M或为真实KKT源。old mu只是mass M的合法candidate。

**不能自动跨owner MAX：** 换 p后原 t<=d(p)不再成立；未经新endpoint/chord／witness证明，不可将上述强 LP map每步在p上最大化。可逐个固定 trial owner独立认证，再比较其actual Q选更好者。

## 3. Actual source cap−g 的独立费用核验

令 g=M-P，sigma_mu,j=mu(C_j)-m_j>=0。真实

`g+d=U_mu+sum sigma_mu,j alpha_j`。

取 `cap_j=min(sigma_mu,j,P-m_j,P_Nj-m_j)` 后，`f_p(t)=epsilon sum p_j cap_j/D_j(t)-g` 满足 actual f_p(d)<=d 和 endpoint f_p(epsilon W)<=epsilon W-g。故 `max(0,max_p f_p)` 才可用R656凸弦／MAX finite-witness论证。它不是将未截断fixed-p LP免费升格MAX。

g在此是一次全局mass费用，不是g·sum alpha；转回S>=g+x后，不能又在Pi-Pgap或D中额外加／减Rg。capture给old-source并集下界，不给optimal nu(Ak)>=mk；P<M时nu覆盖全部old moments甚至与预算矛盾。U_mu依赖同一actual owner，不能把不同owners的unused load和MAX exposure直接相加。

## 4. Block coupling：合法新law，但独立性必须换成block版本

路径上的几何动作与score桥不要求rows独立。保持每个clone的真实AC row marginal、块间独立，可作为新的合法coupled action；它不是原independent-row实验的同一个期望。所有eligibility、baseline、availability、fixed-p optimizer须从整个tuple重算。

等分r=bN、每块含每oldrow的b个clones时，Y_l=(1/b)sum_(high j,s<=b)a_j delta_Xjsl，实际hat_mu_H=(1/N)sum_lY_l。每块mass=M_H，故

`E|hat_mu_H(f)-mu_H(f)|<=(M_H/2)sqrt(B/N)=(M_H/2)sqrt(bB/r)`。

有效独立样本数是N=r/b。r3/r4/r5表各是单大block，不产生Gamma→0；要消去相关项须足够多独立blocks，且新大实验必须重新分析完整gain。

coupling后不可沿用逐row ghost-swap对称式或“Xk独立Cj”的new-C boundary-null论证。Gamma应按signed empirical discrepancy定义；如需swap应重抽整个block。fixed old-A边界仍由单行AC marginals为null，足够支持有限cell TV；不能把new-C contact事件概率零当假设。

receiver关系必须为

`E W=int[1-product_l(1-q_l(x))]dx`，

`max_j q_j(x)<=q_l(x)`保证固定source下Wreach limit；非独立rows的旧product_j公式不可保留。正探索先固定，不能把xi随N趋零再借此交换极限。

## 5. 小block数值与large-block/global量词

指定block审计的有限b=2 AC误差及gain比较仅限那个r=2 fixture。扩成r=bN会改变真实piece大小、跨block collisions、availability与全局alpha。不能复制其actual Q、entropy deficit、D或coupling优势；也不能一block领一个M。

唯一所述粗继承是receiver-only：W_total>=W_oneblock、actual Q'_total<=M，故 `E D_total>=E W_oneblock-RM`。指定低R fixture给 `19/17-26h`，同时每tuple的successor cap已>4；它不在globally calibrated near-score域，正粗gain不认证一般budget。

scaling_summary的r3/r4/r5是atomic低R有限枚举，rational transport仅认证候选coupling与正确marginals，无global最优、正宽gain或large-N persistence定理。特别r5的coupled Q'反而增加，gain仅在完整W−RQ'后为正，不能称作额外source／entropy信用。r5 finite观察不能推饱和或scaling law。摘要中的脚本、aggregate/support重核与全tuple producer重算范围须在最终数值binding中分清。

## 预审阶段结论（最终签核见下）

上述合同和指定审计的主要scope一致，尚无所读材料证明一般full net。最终重点排查三种非法跨越：fixed-p LP→无条件owner MAX；block marginals→逐row独立；小block gain→大clone实际gain。old mu cap−g虽合法仍未给统一geometric强度。

已实际用本机SymPy核验floor dual符号、block empirical权重和sqrt(b)因子零残差。该段记录预审时尚未读REPORT的核对状态；未新跑tuple/solver任务，未改作者/Git/API/PDF。之后的全文补审及最终绑定如下。


## 最终全文补审与冻结绑定

**限定范围 PASS，无数学阻塞；不认证一般上界或完整 uniform cV gain。** 已在预审后实际读取最终全文和 NEXT，并核对最新端点约定及修正的 TeX 记号：

| 冻结文件 | SHA-256 |
| --- | --- |
| `/tmp/ccu_r657/REPORT.tex` | `f56d0fbd595a49b53c8eebb73e261d6947531c81ea89a6ae8e81b29a7eacab86` |
| `/tmp/ccu_r657/NEXT_TARGET.md` | `07d662950596ff78ddd928aec1203e0d9af4579771794aa5e595273d9abcd4ad` |

全文通过以下关键检查：

- fixed-p G 的 primal/dual方向、excess-mass penalty和可行floor迭代正确；其continuity可在可行域以有限cover vertices的value公式核验。未移植成owner-switching MAX，也未将dual mass宣称<=M。
- actual-mu cap−g只扣一次g；P=m_j时cap为零，终端可能0/0的ratio现已明确以连续零延拓处理。未混同mu/optimalnu/entropy源，也未把unused load或不同owner的证书相加。
- whole-face minimax只作有限条件准则：objective对p仿射、对正gamma凸；正baseline给uniform coercivity，可缩到compact positive convex slice后选一个共同owner。没有构造uniform trial beta,t或宣称它已给global budget。heavy-source owner volume<2M的箱体证明成立，但只恢复一次leading-volume费用，全部heavy rows仍留在原action。
- block TV使用跨block独立和正确单行marginals；不再调用逐row独立ghost或新C边界独立性。systematic shifted-grid tags保留真正连续marginals，只控制固定old-cell probe的coarsened TV，不控制full continuous TV、loss windows或new-C probes；它改变law，不带旧gain。
- common-k同步refinement的image partition、grouped baseline和owner-polytope满射成立；固定fine p的实际entropy按p-child proportions聚合，故存在compatible lift保持Q'/W/D/empirical measure，true minimum values也相等。raw entropy常数依赖p，不能用它保joint-B。该细化不增加独立样本、不造平衡或receiver exhaustion，不能与独立block repetition混成同一law。
- 同一law的full net保留Pi−E P、E d、K、T_r与真实O/F/S。新源mass形式 `D=(1+kappa)(W-V)-R(N-M)` 的符号正确，是同一总账，不是第二费用账户。full-D route不额外花unused Gamma；若实际用tagged reduction只扣对应一次误差。tau、old-source/exploration容差及单一4LM的回代明确，未续领每LP/row/block的M。
- unweighted race-class反例确为有限dyadic old-KKT模型中的错误费用screen，不是near-score反例。finite r2 AC改善仅用其已给r2误差；r3–5与balanced r4仍atomic/低R。W=3和AC block粗界的kappa'>4排除域明确。小block optimized gain未复制给largeN，correct marginals／balance／同步细化都未被称为uniform gain证明。

数值证据的producer全枚举与independent support/aggregate重核范围被明确区分，没有把局部复核写成独立重算百万tuples或global transport最优。实际重算的 `race_compare.py` hash为 `7ba64c87e0d23038cbb8f29a0ca2553f3e6879d23d7938644df1d499a445106a`，与正文及当前race_replay记录一致；旧摘要hash转录已被最终修正取代。408-record replay排除timing字段的范围清楚。本审核未重跑numerical campaigns。

另实际SymPy核验同步entropy grouping与signed successor-source identity零残差。最终文本所需证明自足；上方工作稿hash仅保留为预审轨迹，不是未归档 theorem前提。

**最终交付判断：可按限定有限定理、合法新joint laws、同步refinement及未闭合same-law预算交付。仍缺一个合法balanced coarse law在真实global-epsilon_* near-score类上同时取得source accuracy和完整 `cV-CLM`；没有一般root-order或完整递推结论。** 未发现剩余blocking问题。仅更新本审计，未改作者文件/Git/API/PDF；交付后停止。
