# R415 independent audit — frozen

FINAL PASS within the stated R415 scope: native common-source hard/retained-soft capacities, actual-q weighted mass layer cake, source projection and exact terminal mixture. Full proofs, final main/README and three scripts reviewed; all three scripts independently rerun successfully. No new W payment, no general root bound, no P, and no change to the R414 ledger are certified. Only this audit file was edited. Independent screening preceded author reading.

## Independent common-CDF argument

Use actual full matching m_A=q_AR_A^n, true μ=dA/m_A, q_-≤q_A≤λ,0<m_-≤m_A≤m_+<∞, and ORIGINAL s_i(A)≤S. For fixed y,z putρ_yz(dA)=c_A(y)c_A(z)μ(dA), with closed mass CDF T_yz(t). The strict common far past is C_A(y,z)=ρ_yz{m_w<m_A/K}.

At a real parent mass m_A, the difference T_yz(m_A)−C_A is the common-source measure of the CLOSED mass window[m_A/K,m_A]. It is≤the corresponding single-source window, hence≤B0 by the frozen native hypothesis. Equal masses at either boundary are included; no atom is split or removed. Therefore C_A<h implies T_yz(m_A)<h+B0. The right-CDF sublevel capacity gives

∫c_A(y)c_A(z)1_{C_A<h}μ(dA)≤h+B0.

All kernels and CDFs are jointly measurable by positive parameter integration. Zero common measure gives zero; no common source normalization is required. Original soft-positive support C_A<h is exactly legitimate, while C_A=h has zero retained soft cost.

For the weighted hard measureν_i=s_i q_A1_{C_A<h}ρ_yz, its total is≤Sλ(h+B0). This bound concerns a fixed source pair and does not replace the weighted measure by an unweighted set-volume statement.

## Independent sharper retained-soft argument

The SAME original soft factorφ_A=(1−C_A/h)_+ obeys

φ_A≤g(T_yz(m_A)),
g(t)=min(1,(1−(t−B0)/h)_+).

The function g is decreasing, equals1 up toB0 and decreases linearly to0 byB0+h. On each complete mass atom its right-rank value is no larger than values throughout that atom's rank interval. Atom expansion and the continuous/singular CDF part therefore give

∫g(T_yz(m_A))ρ_yz(dA)≤∫_0^{ρ_yz(E)}g(t)dt≤B0+h/2.

This is an inequality, generally strict for atoms, not an assumed continuous-CDF change of variables. The rank used here MUST be the UNWEIGHTED commonρ_yz CDF, not the later weightedν_i CDF. Multiplying bys_i q_A≤Sλ yieldsν_i,soft(E)≤Sλ(B0+h/2). Hard and soft are alternative bounds for their respective measures, not additive payments. h>0 is required; B0=0 and zero common measure cause no division issue.

## Independent exact layer cake and actual-fee interface

For either actual weighted positive measureν_i, define V_i(t)=ν_i{m_A≤t}. Exact positive Tonelli gives

K_i=∫m_A^−1ν_i(dA)
=V_i(m_+)/m_+ +∫_{m_-}^{m_+}V_i(t)dt/t².

This keeps the upper mass atom in the boundary term and the lower mass atom in the integral+boundary decomposition. m_-=m_+ is a valid single-level case with only the boundary term, not an empty field. Closed versus strict CDF values at the Lebesgue layer variable do not change the integral; the terminal boundary term cannot be dropped. No independent radius selector integration is introduced.

On current R414, retain parentA, y,z and the already present low-common soft factor BEFORE projecting the actual high-stage old-source law. The original a_i^e≤s_i^e/τ upper bound, followed only by dropping saved positive restrictions and conditional kernels of mass≤1, gives

actual fee≤τ^−1Σ_i∫f(y)f(z)K_i,soft(y,z)b_i(z)dy dz.

The full original soft is used ONCE in this kernel, not multiplied a second time as a newly paid fraction. Both parent orientations are already in s_i=s_i^u+s_i^v. The hard alternative drops soft but retains its parent-dependent support. One cannot first integrate awayA and then reinsert C_A<h as if it were only a source-pair event. Σb_i remains at the original new z; no old/new swap, history refresh or filtered-density recomputation is allowed.

The exact ν/V/K mass weighting must remain in any stronger source integral. Replacing it only by its pairwise total bound and integrating f(y)f(z) does not create a W-linear price. These capacity and representation statements alone do not control the remaining actual fee or prove P.

## Actual independent local arithmetic

Before author reading, executed192 Fraction atomic configurations checking common-window gap, hard sublevel capacity, retained-soft/CDF comparison and exact right-CDF layer cake (including endpoint atoms). Each finite model uses its own exact mass-window bound, not an unsupported native B0 assertion. All passed. These are abstract atomic measures, not native cube/history fixtures and not added to forthcoming delivered counts.

## Final bounded post-review

Reviewed final main, README, auxiliary proof, terminal proof and all three delivered Python scripts. No required correction remains.

The truncated capacity is also valid: V_i(t;y,z)≤SλΦ(T_yz(t)). The actual q_A factor is retained before mass pushforward. Exact source matching gives 𝓥(t)=Σ_i∫_{m_A≤t}σ(dA)s_i(A)m_A E_{π_A²}[b_i(z)φ_A]. Its two reported coarse bounds StX_q and Sλ(B0+h/2)W² are valid using the ORIGINAL decreasing s_i≤s_0 and same-z Σ_i b_i(z)≤1. Neither is a root-linear W price. Radius extraction uses q_A/m_A=R_A^−n and introduces no extra λ/q_-.

The terminal proof retains all parent/history/source labels in Ξ, removes only final both-terminal-outside before adding its two conditional terminal kernels, and preserves the parent A in their joint integral. Last-active-jump expansion gives H_x(w,db)=1_B ρ_x(db)g_x(w,m_b), only for active starts. Finite mass-descent depth, positive Tonelli and standard-Borel disintegration justify the representation; the terminal 1/h bound is ρ_x|B-a.e and extends to the absolutely continuous initial mixture by Fubini. Stopped Dirac starts are explicitly excluded. The resulting initial-column estimate only gives J(x)/h amplification. The proposed terminal excess estimate is an UNPROVED stronger sufficient condition, not an established budget or necessary equivalence.

The report and README correctly retain the R414 mother G_0≤16 Fhat[R414+C413X_q+V413W], Fhat=(1−32δ−16η)^−1, with unchanged BH/entrance accounting. No duplicate soft factor, negative credit, source-density assumption, new history qualification or source-product-to-W substitution is authorized.

## Delivered computation evidence

Independent reruns on final code returned:

- parent: [24,24,24], 72 atomic configurations, each checked at three decreasing-weight stages; Fraction rank/endpoint algebra only.
- aux: [50,50,32], 132 source-pair/parameter checks, 44 positive hard pair kernels and 40 excluded positive-volume parent-block records. Its center boxes are disjoint up to null boundaries, radii are single-valued on each block, and full f=q 1_{[-4,4]^n} yields m_A=qR_A^n for every selected center. Volume intersections are exact Fraction integrals, not receiver quadrature. 1D/2D K and h are diagnostic; 4D two-mass strict prefixes agree with native K but do not realize the complete original Γ/history contract.
- geometry: 62 mass-axis models, 303 active rows; exact terminal Green identity, cap and same-parent mixture. These are finite mass-axis algebra, not native center/matching/history instances and not tests of the unproved excess bound.

Final rerun stdout matched the three supplied result files. Counts are model/configuration records, not a claim of that many independent native full-contract fields. The earlier 192 reviewer arithmetic configurations were a separate execution, have no standalone archived script, and are not added to delivered experiment counts.

## SHA-256 bindings

The following bindings cover final bytes after review; this audit does not bind a later generated TeX/manifest or package.


- `r415_main.md`: `34a9c8e9f16c4706781333f3239159a713df0ec0107f96cf1dc6b55823e567e2`
- `r415_readme.md`: `0e3ceeb75ab5d447ecbfdbc0a367ac1b127b756ccae4ef18fdf7623779564a1b`
- `r415_aux.md`: `5ae86da00ddb0fd41460270670257cda05bd1802a92386fe9668d470fca24848`
- `r415_geometry.md`: `3460c3050b698df87cfd9711c2f38f1258867ed303ccc4fd8e3d6156ad425f80`
- `r415_parent_check.py`: `5c004221bb74b7abec48d05a2895ce1d1211b3a4885190190984a6d54261f370`
- `r415_aux_check.py`: `b303cb32fd23e6bb25fd2ecc304c936f859a5478ca20c0633dcc475a3a9d5d3e`
- `r415_geometry_check.py`: `3b358e4bf21c7033b4eedc0986b5d45a22b223802694d46d5af6a1c7540e38fd`
- `r415_parent.result.txt`: `2e912e0ce7f50398bc148ea1d71eafd7869428f5b1b32c8f02d77946bd9c774f`
- `r415_aux.result.txt`: `03d329bcd5dd8807b42b31157d2b637ec3dbbaa7d80686878d6e5a22aa26e42e`
- `r415_geometry.result.txt`: `42694cc7b94bba52a39e4815f2bf4e77fc98f17deb57df1f804d056d8dcaf672`
- `r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r412_main.md`: `ffcddcbeadfe45481d6fb52ea953c7e35bf24ae2451fa001bae2c17883fe7fef`

Frozen scope: no new source payment; the source-weighted joint geometric estimate and general root bound remain open.
