from fractions import Fraction as F
from itertools import product
from collections import Counter
C=Counter(); nonzero=0; removed=0

def vol_inter(*boxes):
    v=F(1)
    for ax in range(len(boxes[0])):
        v*=max(F(0),min(B[ax][1] for B in boxes)-max(B[ax][0] for B in boxes))
    return v

def cube(x,R):return [(a-R/2,a+R/2) for a in x]

def field(n,seed):
    cuts=[F(-1),F(0),F(1)]
    boxes=[]
    for ids in product(range(2),repeat=n):
        B=[(cuts[k],cuts[k+1]) for k in ids]
        R=F(1 if (sum(ids)+seed)%2 else 2)
        sw=F(1) if (sum(ids)+seed)%3 else F(1,2)
        boxes.append((B,R,sw))
    # Constant full f=q on [-4,4]^n, zero on its full complement.
    q=F(1) if seed%2==0 else F(3,4)
    return boxes,q

def run(n,seed,y,z,h,K,Bcert,label):
    global nonzero,removed
    boxes,q=field(n,seed); atoms={}; fullatoms={}; weighted={}; weightedq={}; softweights={}; softq={}
    records=[]
    for B,R,sw in boxes:
        support=cube([F(0)]*n,F(8))
        # For every center in this continuous box, its whole selected cube is in support.
        assert all(lo-R/2>=-4 and hi+R/2<=4 for lo,hi in B)
        m=q*R**n
        v=vol_inter(B,cube(y,R),cube(z,R)); ry=vol_inter(B,cube(y,R))/m
        a=v/m
        atoms[m]=atoms.get(m,F(0))+a
        fullatoms[m]=fullatoms.get(m,F(0))+ry
        records.append((m,R,sw,a))
    lo=min(q*R**n for _,R,_ in boxes);hi=max(q*R**n for _,R,_ in boxes)
    for m,R,sw,a in records:
        past=sum((v for mm,v in atoms.items() if mm*K<m),F(0))
        T=sum((v for mm,v in atoms.items() if mm<=m),F(0))
        if a and past>=h: removed+=1
        soft=max(F(0),1-past/h)
        softweights[m]=softweights.get(m,F(0))+sw*a*soft
        softq[m]=softq.get(m,F(0))+q*sw*a*soft
        if past<h:
            assert T<=h+Bcert
            weighted[m]=weighted.get(m,F(0))+sw*a
            weightedq[m]=weightedq.get(m,F(0))+q*sw*a
    def profile(t):
        if t<=Bcert:return t
        if t<Bcert+h:return t-(t-Bcert)**2/(2*h)
        return Bcert+h/2
    assert sum(softweights.values(),F(0))<=Bcert+h/2
    for t in sorted(atoms):
        common=sum((v for m,v in atoms.items() if m<=t),F(0))
        assert sum((v for m,v in softweights.items() if m<=t),F(0))<=profile(common)
    H=h+Bcert;nu=sum(weighted.values(),F(0));nq=sum(weightedq.values(),F(0))
    assert nu<=H
    for t in sorted(atoms):
        cum=sum((v for m,v in weighted.items() if m<=t),F(0))
        assert cum<=min(H,sum((v for m,v in atoms.items() if m<=t),F(0)))
    kernel=sum((v/m for m,v in weightedq.items()),F(0))
    # Exact atomic layer-cake integrates the constant CDF on every interval.
    ticks=sorted({lo,hi,*weightedq})
    layer=nq/hi
    for left,right in zip(ticks,ticks[1:]):
        cum=sum((v for m,v in weightedq.items() if m<=left),F(0))
        layer+=cum*(1/left-1/right)
    assert layer==kernel
    softkernel=sum((v/m for m,v in softq.items()),F(0))
    softlayer=sum(softq.values(),F(0))/hi
    for left,right in zip(ticks,ticks[1:]):
        softlayer+=sum((v for m,v in softq.items() if m<=left),F(0))*(1/left-1/right)
    assert softlayer==softkernel
    dist=max((abs(a-b) for a,b in zip(y,z)),default=F(0))
    rr=max(F(1),dist)
    assert kernel<=H/rr**n
    assert softkernel<=(Bcert+h/2)/rr**n
    positive_m=[m for m,v in weighted.items() if v>0]
    if positive_m: assert kernel<=q*H/min(positive_m)
    nonzero+=kernel>0
    # Outside full-f support points have no captured receiver in these fields.
    if any(abs(v)>4 for v in y+z):assert kernel==0
    C[label]+=1

# Stage 1, continuous 1D center intervals, exact strict mass-prefix atoms.
points1=[[F(v)] for v in (-5,-1,0,1,5)]
for seed in (0,1):
 q=F(1) if seed==0 else F(3,4)
 for y,z in product(points1,repeat=2):
  run(1,seed,y,z,F(1,8),F(3,2),F(3,2)/q,'initial_1d')
# Stage 2, continuous 2D center rectangles; source boundary and zero-f exterior.
points2=[[F(0),F(0)],[F(1),F(0)],[F(0),F(1)],[F(-1),F(-1)],[F(5),F(0)]]
for h in (F(1,16),F(1,2)):
 for y,z in product(points2,repeat=2):
  run(2,1,y,z,h,F(3,2),F(2),'pressure_2d')
# Stage 3, 4D actual cubes with radii 1 or2; mass ratio16.
# K=8 and native exp(sqrt4)=e^2 have identical strict prefix on these two masses.
# 1<e^2<9<16 (e<3), so this statement does not require a floating exponential.
points4=[[F(0)]*4,[F(1,2)]*4,[F(-1,2)]*4,[F(5),F(0),F(0),F(0)]]
for seed in (0,1):
 q=F(1) if seed==0 else F(3,4)
 for y,z in product(points4,repeat=2):
  run(4,seed,y,z,F(1,8),F(8),F(3)/q,'expanded_4d')
print('PASS',dict(C),'total',sum(C.values()))
print('positive pair kernels',nonzero,'excluded positive parent-block records',removed)
print('Exact Fraction integrals over actual continuous center boxes; full f specified on all space.')
print('1D/2D K is diagnostic; 4D two-mass prefix agrees with native K. No full history/stage realization.')
