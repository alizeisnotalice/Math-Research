from fractions import Fraction as F
from itertools import product
counts=[]
for phase in range(3):
 count=0
 for seed in range(24):
  N=4+phase
  masses=[F(1+(seed+2*j)%(N+2)) for j in range(N)]
  rho=[F(1+(seed+j)%4,2+j%3) for j in range(N)]
  q=[F(3,4)+F((seed+j)%4,12) for j in range(N)]
  K=F(3+phase,2);h=F(1+seed%4,2)
  T=[sum(r for m,r in zip(masses,rho) if m<=x) for x in masses]
  C=[sum(r for m,r in zip(masses,rho) if m*K<x) for x in masses]
  B0=max(t-c for t,c in zip(T,C))
  keep=[c<h for c in C]
  assert sum(r for r,k in zip(rho,keep) if k)<=h+B0
  soft=[max(F(0),1-c/h) for c in C]
  J=sum(rho);d=min(max(F(0),J-B0),h)
  Phi=J if J<=B0 else B0+d-d*d/(2*h)
  assert sum(r*x for r,x in zip(rho,soft))<=Phi<=B0+h/2
  for stage in range(3):
   ss=[F(3-stage,3)*F(1+(seed+j)%3,3) for j in range(N)]
   w=[r*qq*s*phi for r,qq,s,phi in zip(rho,q,ss,soft)]
   levels=sorted(set(masses));M=levels[-1]
   direct=sum(v/m for v,m in zip(w,masses))
   stieltjes=sum(w)/M
   for left,right in zip(levels,levels[1:]):
    V=sum(v for v,m in zip(w,masses) if m<=left)
    stieltjes+=V*(1/left-1/right)
   assert direct==stieltjes
   assert sum(w)<=h/2+B0  # s<=1,q<=1
   assert direct<=(h/2+B0)/min(masses)
  count+=1
 counts.append(count)
print('PASS',counts,'atomic prefix/layer-cake models; three stages per model; Fraction exact.')
print('Scope: fixed-pair rank algebra only, not a source-integrated root estimate or native cube realization.')
