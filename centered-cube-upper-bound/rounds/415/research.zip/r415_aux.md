# R415：保留实际 soft 与质量权的共同来源 CDF 包络

2026-10-20。得到一个适用于原匹配场、任意可测半径选择器的共同来源容量公式：原 \((1-C_A(y,z)/h)_+\) 加权的共同捕获中心容量不超过 \(B_0+h/2\)，并有截断 CDF 的完整二次剖面。仅用 indicator 则是 \(B_0+h\)。公式保留质量原子与实际 q 权；**目前没有把它转成新的全局 W 付款**。本文不增加密度门或重收已付分支。

## 1. 原核和质量窗

冻结 full f、实际中心 dA、\(m_A=f(Q_A)=q_AR_A^n\)、\(q_-\le q_A\le\lambda\)、\(a\le R_A\le b\le2a\)。记 \(\mu(dA)=dA/m_A\)，\(\sigma=q_A dA\)，\(\pi_A=f c_A/m_A\)。原 stage 权 \(0\le s_i\le s_0\le S\) 由原边两端供给，不重算。令 \(K=e^{\sqrt n}>1\)，\(h>0\)，

\[
B_0=\frac{1+\log K}{q_-}.
\]

原冻结参数满足 B_0=ε_0h；以下容量证明本身允许任意 h>0。固定两个来源 y,z，定义共同中心测度及其闭质量 CDF：

\[
\rho_{yz}(dA)=c_A(y)c_A(z)\mu(dA),\qquad
T_{yz}(t)=\rho_{yz}\{m_A\le t\}.
\]

原 strict-far 共同过去恰为

\[
C_A(y,z)=\rho_{yz}\{m_B<m_A/K\}.
\tag{1}
\]

这里不把原 C_A 改成 stage 删除后的共同秩。实际质量窗给

\[
0\le T_{yz}(m_A)-C_A(y,z)
=\rho_{yz}\{m_A/K\le m_B\le m_A\}\le B_0.
\tag{2}
\]

为说明真实中心步骤：对任意质量窗 \([t/K,t]\)，捕获 y 的中心 B 满足 \(q_-(2\|B-y\|_\infty)^n\le m_B\le t\)，且

\[
\frac{c_B(y)1_{t/K\le m_B\le t}}{m_B}
\le \min\left\{\frac Kt,\frac1{q_-(2\|B-y\|_\infty)^n}\right\}
1_{q_-(2\|B-y\|_\infty)^n\le t}.
\]

对真实 Lebesgue dB 作径向层积分，基底项为 \(1/q_-\)，其后为 \(\log K/q_-\)。共同捕获是其中正子集，故得 (2)。这不是固定 R 的薄层估计，也没有用来源 f 的密度帽。窗含两端质量原子。

## 2. 原 soft 的精确 CDF 剖面

设

\[
g(t)=\min\{1,(1-(t-B_0)/h)_+\},\qquad
F(t)=\int_0^t g(r)dr
=\begin{cases}
t,&0\le t\le B_0,\\
t-(t-B_0)^2/(2h),&B_0<t<B_0+h,\\
B_0+h/2,&t\ge B_0+h.
\end{cases}
\tag{3}
\]

由 (2)，\(C_A\ge(T_{yz}(m_A)-B_0)_+\)，所以

\[
\phi_A(y,z):=(1-C_A(y,z)/h)_+\le g(T_{yz}(m_A)).
\]

g 非增。对闭 CDF 的一个质量原子，其秩区间为 \([T_-,T]\)，于是

\[
(T-T_-)g(T)\le\int_{T_-}^{T}g(r)dr.
\]

无原子部分按秩积分，原子部分依上式逐块加入。因此对每个 t≥0，

\[
\boxed{\int_{m_A\le t}\phi_A(y,z)\rho_{yz}(dA)
       \le F(T_{yz}(t))\le B_0+h/2.}
\tag{4}
\]

第一跨越原子没有被丢掉，right-endpoint 只用于正确方向的非增函数上界。若共同测度为零，全部量为零。严格 \(C_A<h\) 的 indicator 版本单独为

\[
\int_{m_A\le t}1_{C_A<h}\rho_{yz}(dA)
\le\min\{T_{yz}(t),B_0+h\}.
\tag{5}
\]

因为其支撑满足 \(T_{yz}(m_A)<B_0+h\)，再用闭 CDF 初始段容量。(4)优先保留原费用已有的 soft 因子；不能在已经含该 soft 的费用上再乘一份或再次扣捕获平方信用。

## 3. 保留 q 和实际质量分布，不先取最小覆盖质量

定义原 stage 的**带 q 权质量测度**

\[
\nu_i^{y,z}(dt)=\int s_i(A)q_A\phi_A(y,z)c_A(y)c_A(z)\mu(dA)\,
                        \delta_{m_A}(dt).
\tag{6}
\]

原 pair-source kernel 加上它本来拥有的 soft 后精确为

\[
\mathcal K_i^\phi(y,z)
=\int\frac{s_i(A)c_A(y)c_A(z)\phi_A(y,z)}{q_AR_A^{2n}}dA
=\int\frac1t\nu_i^{y,z}(dt).
\tag{7}
\]

不得把同质量但不同 q 的接收者强行视为一个 q(t)；(6)已在推前前保留实际 q。若改用无 q 推前，则必须保 joint (m,q) 或上下界，不能凭单个 m 恢复 q。

由 (4)，

\[
\nu_i^{y,z}([m_-,t])\le S\lambda F(T_{yz}(t)),\qquad
m_-=q_-a^n,\quad m_+=\lambda b^n.
\tag{8}
\]

所有实际质量在 \([m_-,m_+]\)。正层积分给精确表达

\[
\boxed{\mathcal K_i^\phi(y,z)
=\frac{\nu_i^{y,z}([m_-,m_+])}{m_+}
 +\int_{m_-}^{m_+}\frac{\nu_i^{y,z}([m_-,t])}{t^2}\,dt.}
\tag{9}
\]

该式包括端点原子。\(m_-=m_+\) 时连续积分为0，保留第一项；空场给0。这比将 ν 换成 mass-sublevel 支撑并集保留更多实际中心容量和接收权。

另一个不含额外 λ 的半径包络是：对任意 r0>0，

\[
\int_{R_A\ge r_0}\frac{s_i c_A(y)c_A(z)\phi_A}{q_AR_A^{2n}}dA
\le\frac{S(B_0+h/2)}{r_0^n}.
\tag{10}
\]

这是因为该核等于 \(\int s_i R_A^{-n}\phi_A\,d\rho_{yz}\)。共同捕获必有 \(R_A\ge\|y-z\|_\infty\)，故非空时可取 \(r_0=\max(a,\|y-z\|_\infty)\)；若位移>b，核为0。indicator 对应把 \(B_0+h/2\) 换成 \(B_0+h\)。这些是中心占用改善，不是对 f(y)f(z) 的源积分付款。

## 4. 匹配约束在源积分中精确留下什么

对任意冻结的可测 \(0\le\Psi(y,z)\le1\)，例如已保留的来源远域和两份静态重尾门，令

\[
V_i(t;\Psi)=\int f(y)f(z)\Psi(y,z)
                          \nu_i^{y,z}([m_-,t])\,dy\,dz.
\]

完整匹配给精确 source-exact 式

\[
V_i(t;\Psi)=\int_{m_A\le t}s_i(A)m_A\,\sigma(dA)
       \int\pi_A(dy)\pi_A(dz)\Psi(y,z)\phi_A(y,z).
\tag{11}
\]

所以 (9) 的源积分等于

\[
\frac{V_i(m_+;\Psi)}{m_+}
+\int_{m_-}^{m_+}\frac{V_i(t;\Psi)}{t^2}dt
=\int s_i(A)\sigma(dA)\pi_A^{\otimes2}(\Psi\phi_A).
\tag{12}
\]

这是同一个实际场的等式，不能再把右端当作另外一笔可扣信用。源积分没有把 ν 的质量权、q 或中心体积删掉。

对于原累计费用，在已付 τ 高边缘门后才有 stagewise \(\tau^{-1}M_i b_i(z)\) 支配。保原 soft 后，\(\mathcal K_i^\phi\le\mathcal K_0^\phi\)，在同一个新来源 z 上使用 \(\sum_i b_i(z)\le1\) 可以一次性用 (12)的 i=0 上界；这一步没有阶段数，但会放松剩余的动态与历史标记。它不是把原费用定义成无标记整体能量，更没有证明这个上界已付。

目前没有得到将 (8) 的逐来源对 CDF 控制，与 (11) 的共同实际父匹配，联合变成 \(\varepsilon X_q+C_\varepsilon\sqrt n\,\mathrm{polylog}(n)W\) 的新不等式。粗略把 (8) 总量直接积分只产生来源乘积；例如 (10) 在 r0=a 处给 \(S(B_0+h/2)W^2/a^n\)，它不是合法的根阶 W 收据。

可作比较但不作为下一主攻替代：若 m_*(y,z) 是 positive-center-measure 的共同 low-common 父族的 essential 最小实际质量，则安全上界为 \(S\lambda(B_0+h/2)/m_*\)；空族取0。取这个 essential 最小值及父盒并集会丢 ν 的中心权，可能要求一个过强而不必要的覆盖估计。本文主对象保持 (6)–(12)，不将未证并集质量界当成付款前提或唯一目标。

一般 f 允许高度集中；matching 只确保每个实际 Q_A 的完整质量 m_A，尚不能直接将共同源对在 (8) 的小 CDF 上的集中解释为小来源质量。这个未控的联合加权源积分是本稿止步处。没有增加新密度截断、没有重复绝对低占用策略，也没有将原阴性平方信用再次使用。

## 5. 实际连续中心的三阶段 Fraction 检查

`/tmp/r415_aux_check.py` 实际输出：

```
PASS {'initial_1d': 50, 'pressure_2d': 50, 'expanded_4d': 32} total 132
positive pair kernels 44 excluded positive parent-block records 40
Exact Fraction integrals over actual continuous center boxes; full f specified on all space.
1D/2D K is diagnostic; 4D two-mass prefix agrees with native K. No full history/stage realization.
```

这些不是将接收者替成有限点权：E 是真实中心区间/矩形/四维盒的并，半径在每个中心块取1或2，s取1或1/2；每个中心块中的共同捕获体积由盒交精确积分。完整 f 为 \(q1_{[-4,4]^n}\)，q=1或3/4，并在其整个补集定义为0；所有被选接收盒均在该来源盒内，因此逐中心 m_A=qR_A^n、q-band和 octave 都精确成立。来源测试点包括 f=0 的外部空间。

初步50组一维、压力50组二维、扩大32组四维，均核 indicator/soft 两版容量、CDF二次剖面、实际质量原子层积分(9)、半径包络。44组原pair核正，40条正体积父块因 strict low-common 门被排除。一/二维用诊断 K=3/2；四维只含质量1与16的同比缩放，K=8与原 e^2 都在(1,16)，因此 strict prefix相同，原 B0=3/q 有效。h取诊断值，不声称满足原 h=(1+√n)/(ε_0q_-)或实现原 Γ_i/高秩/历史/密度层合同。证明适用于任意 h>0，数值仅核几何与权的接口，不代替原费用的全合同构造。
