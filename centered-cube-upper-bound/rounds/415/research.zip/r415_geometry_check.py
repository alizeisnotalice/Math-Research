from fractions import Fraction as F
from itertools import product

# Finite mass-axis tests only: no native center or historical-flow assertion.
def check(weights, h, K):
    m = tuple(F(2)**j for j in range(len(weights)))
    rho = tuple(map(F, weights))
    past = [tuple(j for j in range(len(m)) if m[j]*K < m[i]) for i in range(len(m))]
    Z = [sum((rho[j] for j in p), F(0)) for p in past]
    B = tuple(j for j in range(len(m)) if Z[j] <= h)
    H, G = [], []
    for i in range(len(m)):
        if Z[i] <= h:
            H.append({j:F(i==j) for j in B})
            G.append(None)
            continue
        row = {j:F(0) for j in B}
        green = {j:F(0) for j in B}
        for k in past[i]:
            for j in B:
                row[j] += rho[k]/Z[i] * H[k][j]
                if k in B:
                    green[j] += F(k==j)/Z[i]
                else:
                    green[j] += rho[k]/Z[i] * G[k][j]
        assert sum(row.values(), F(0)) == 1
        for j in B:
            assert row[j] == rho[j]*green[j]
            assert 0 <= green[j] <= 1/h
        gs = [green[j] for j in B]
        assert all(a >= b for a,b in zip(gs, gs[1:]))
        H.append(row); G.append(green)
    active = [i for i in range(len(m)) if Z[i] > h]
    if active:
        assert sum((rho[j] for j in B),F(0)) >= h
    # Exact joint mixture with arbitrary parent-dependent terminal restrictions.
    direct = expanded = bound = F(0)
    for label,(u,v) in enumerate(product(active, repeat=2)):
        weight = F(1, (label+1)*(label+2))
        out_y = {j: (j+label)%3 != 0 for j in B}
        out_z = {j: (2*j+label)%4 != 0 for j in B}
        ez = sum((H[v][j] for j in B if out_z[j]), F(0))
        for j,k in product(B, repeat=2):
            if out_y[j] and out_z[k]:
                direct += weight*H[u][j]*H[v][k]
        expanded += sum((weight*rho[j]*G[u][j]*ez for j in B if out_y[j]),F(0))
        bound += weight/h*sum((rho[j] for j in B if out_y[j]),F(0))
    assert direct == expanded <= bound
    return len(active)

stages = [
    [(tuple([1]*n), F(1), F(2)) for n in range(3,11)],
    [(tuple(F(a+(j%2),b) for j in range(8)), F(c,2), F(2))
     for a,b,c in product((1,2,3), repeat=3)],
    [(tuple(F(1+(j%a),b) for j in range(n)), F(3,2), F(3))
     for n,a,b in product((6,9,12), (1,2,4), (1,2,3))]
]
for k,cases in enumerate(stages,1):
    active = sum(check(*case) for case in cases)
    print(f'Stage {k}: PASS, {len(cases)} mass-axis models, {active} active start rows')
print('Scope: exact terminal Green identity, terminal bound, monotonicity and label-preserving joint mixture. No native geometry, matching, history or new budget certified.')
