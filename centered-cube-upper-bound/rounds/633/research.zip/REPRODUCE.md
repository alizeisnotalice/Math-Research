# R633 reproduction and evidence scope
Use `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python verify.py` after extracting this archive. Python 3.12.14, SymPy 1.14.0, NumPy 2.5.4, SciPy 1.18.1 were used. The script checks exact constants, reconstructs all six radius profiles, and reruns six finite floating LPs. It writes a fresh verification JSON; original evidence is in ROOT_CHECKS.json. Runtime counters can differ.

The `numeric/matlab` directory name preserves the independent agent's workspace naming; its files are exact Python, not MATLAB runs. MATLAB batch was tested in R632, not in R633. No PDF compilation is part of this reproduction.

The proof appendices establish only the stated conditional/general structural lemmas. The integral volume payment remains unproved. Exact finite certificates concern their specific inputs and radius polynomials; finite floating LP values are not strict optimality certificates. Expanding these easy receiver profiles was stopped because the exact N/a^n screen makes them irrelevant to the hard branch. No numerical sample is extrapolated to dimension order.

Archive omits superseded exploratory contact/outer drafts, generated cache, large console logs, and duplicate intermediate data. Their lack of global payment is recorded in REPORT.tex. Shared compute index: radius engine and independent reconstruction complete; six volume-cap LP prechecks complete; no live repeated expensive scan. Next heavy computation requires a new accurate candidate on the frozen joint law.
