# R633：双 exposure、双实际 receiver 边缘独立审核

**结论：新增双端修复命题的代数及量词成立。** 它将 low-common-source/high-β 分支转成一个质量有正下界、两个边缘均由真实 receiver 均匀测度常数支配的耦合；不含 λ_min 损失。尚未获得从该耦合到 V/M 根阶付款的几何估计，故不构成一般上界闭合。

## 1. 独立冻结 Π，不能混成 receiver law

有限完整 family，真实不交 increments I_j、v_j>0、V=Σv_j；A_j=aB_j、d_j=|A_j|。同一 R619 正则 packing/source 满足

\[
\lambda>0,\quad L_\lambda\le1,\quad
\mu\text{ 支持于 }\{L_\lambda=1\},\quad
m_j=\mu(A_j),\quad M=Q+\epsilon V,
\quad\lambda_j(m_j-d_j)=\epsilon v_j.
\]

正 source cells C 的概率 p_C=μ(C)/M。对每个有序 cell 对 C,D，取总质量 1 的 label coupling π_CD，行和 λ_j1_{j∈C}、列和 λ_k1_{k∈D}。共同 labels j∈C∩D 全部用 diagonal mass λ_j；余下只在真正不交 A_j∩A_k=∅ 的 pairs 上匹配。有限 Hall 构造存在；可对无序 cell 对选定一次，令 π_DC=π_CD^T 取得对称性。定义

\[
\Pi(C,D,j,k)=p_Cp_D\pi_{CD}(j,k).
\tag{A1}
\]

Π 是质量 1 的未标记两源律；J、K 两端 label 边缘均为

\[
\rho_j=\lambda_jm_j/M,\qquad\sum_j\rho_j=1.
\tag{A2}
\]

此时 ρ_j 一般不等于 v_j/V。特别地，完整 diagonal label mass 准确为

\[
\Pi(J=K=j)=\lambda_j(m_j/M)^2.
\tag{A3}
\]

这依赖共同 labels 已全部对角匹配，不能替换成任意 label coupling。每个 off-diagonal pair 均保留真实 disjoint-star 几何。Π 可同时保留 cells 内的实际 μ source points；不存在每个 clique 重开一份 M 的费用。

## 2. 双 exposure 命题的独立证明

设

\[
e_j=\frac{\epsilon v_j}{\lambda_jm_j}=1-\frac{d_j}{m_j}\in(0,1),\quad
\beta=\sum_j\rho_je_j=\frac{\epsilon V}{M}\in(0,1),\quad
\eta_j=\frac{\rho_je_j}{\beta}=\frac{v_j}{V},
\]

并定义非负 submeasure

\[
d\Gamma=e_Je_K1_{J\ne K}\,d\Pi,\qquad \Omega=\Gamma(\text{全部}).
\tag{A4}
\]

由 (1−e_J)(1−e_K)≥0，EΠ[e_Je_K]≥2β−1。利用 (A3) 与 e_j²≤e_j，删除的 diagonal 质量满足

\[
\begin{aligned}
\sum_j\lambda_je_j^2(m_j/M)^2
&\le\sum_j\lambda_je_j(m_j/M)^2\\
&=\frac{\epsilon}{M^2}\sum_jv_jm_j
=\beta\kappa,
\end{aligned}
\tag{A5}
\]

其中 κ=Σv_jm_j/(VM) 正是 R619 full-family κ。因此

\[
\boxed{\Omega\ge\beta(2-\kappa)-1.}
\tag{A6}
\]

对每个 label j，第一边缘

\[
\Gamma(J=j)=e_j\sum_{k\ne j}e_k\Pi(J=j,K=k)
\le e_j\rho_j=\beta\frac{v_j}{V}.
\tag{A7}
\]

第二边缘同理；此处不需要先假设 partner 有 receiver 边缘，正是双乘 e 的作用。若 Ω>0，按 Γ/Ω 选 label pair，再分别在真实 I_j、I_k 均匀采 Z、Z'，两个 receiver 边缘均满足

\[
\boxed{\mathcal L(Z),\mathcal L(Z')
\le\frac{\beta}{\Omega}\frac{1_U(z)\,dz}{V}.}
\tag{A8}
\]

Ij 是完整族实际 ordered increments；不得换成小立方体均匀测度或实验中的 selected suffix。对 Ω=0 不存在此归一化，但 (A6) 的 hard 分支确保 Ω>0。

当 β≥3/4、κ≤1/4 时，Ω≥5/16。更准确地

\[
\frac\beta\Omega\le\frac\beta{\beta(2-\kappa)-1}\le\frac{12}{5}.
\tag{A9}
\]

最后一步因分式随 β 严格下降、随 κ 严格上升，在 (3/4,1/4) 取 12/5。只将 Ω≥5/16 与 β≤1 分开使用，会得到较差 16/5；不能据那两个粗界直接声称 12/5。

## 3. 真实分离坐标与量词

对 Γ 支持的每个 j≠k，令

\[
S(j,k)=\{i:|y_{j,i}-y_{k,i}|\ge a(r_j+r_k)\}\ne\varnothing.
\]

保留全部 S，取 s_i=sgn(y_{j,i}−y_{k,i})/√|S|（i∈S），余坐标为 0。则 ||s||2=1，且所有 z∈I_j、z'∈I_k 均满足

\[
\langle s,z-z'\rangle\ge(a-1)(r_j+r_k)\sqrt{|S|}.
\tag{A10}
\]

因为每个被选坐标至少留下 (a−1)(r_j+r_k) 的小 receiver 间距。s 依赖同一实际 pair；不能把它当作预先固定的全局方向，也不能省略 pair/source 权再按坐标分别复印预算。整个命题对任意有限维数、任意半径范围和任意正增量数成立；它是 lower-only KKT 来源命题，没有调用原 f 的 canonical 外帽。

## 4. 高 V/Q 门槛与最终常数审核

固定 H_n≥8/3，P=(1+1/a)^n，在构造 μ 之前取 ε=1/(2PH_n)。令 R=V/Q。精确有

\[
\beta=\frac{\epsilon R}{1+\epsilon R}
=\frac{R}{2PH_n+R},\qquad
\beta\ge3/4\iff R\ge6PH_n.
\tag{A11}
\]

由已证共同来源包围 κV≤PM，

\[
\kappa\le P\left(\epsilon+\frac1R\right).
\]

故一旦 R>6PH_n，就有 β>3/4 与 κ<2/(3H_n)≤1/4；上述双 receiver coupling 自动存在，且支配常数 ≤12/5。其逻辑形式是：

> 若 V/Q 已超过 6PH_n，则存在满足 (A4)–(A10) 的完整几何 coupling。

这不是 V/Q≤6PH_n 的证明。后者尚需新证这种 hard coupling 不可能，或对它独立证 V≤L_nM 并有 εL_n<1。若后续能证 L_n≤PH_n，则吸收给 V≤2PH_nQ，与 hard 假设矛盾，最后才可推出 V≤6PH_nQ。取 a≥n 时 P≤e，H_n=√n polylog(n+2)（小 n 用固定常数补齐），最终候选常数为 6eH_n；这个数现在仍是**条件性的最终门槛**。

(A8) 只有边缘上界，没有 receiver/source transport 的体积成本上界；(A10) 是每 pair 的方向分离，没有全族统一方向或正交平方和付款。仅用 coupling 存在性、Markov 或逐坐标相加，不能反向推出 V/M 根阶。

## 5. 实际轻量校验与作者稿对照

本机数学 Python/SymPy 1.14.0 实际运行一次：分式 β/[β(2−κ)−1] 的 β、κ 导数分别为 −1/[βκ−2β+1]^2 与 β²/[βκ−2β+1]^2；hard corner 得 12/5、Ω corner 得 5/16；β−3/4=(R−6PH)/(4(2PH+R))。运行约 0.411 秒。它只检查常数代数，不替代上面的概率/几何证明；没有新增重数值。

作者消息中的 e、ρ、β、κ、Ω 与本审核独立定义一致；其宣称仅为双 receiver 修复而非根阶闭合，与审核结论一致。最终作者文件对照另在下方注明。

**正式稿对照已完成：** 只读 `/tmp/ccu_r633/selection.md`。作者式 (4)–(5) 的 Π 与 (A1) 一致，明确共同 labels 全对角；式 (8) 的两项非负修正也准确：E[e_Je_K]=2β−1+E[(1−e_J)(1−e_K)]，而 diagonal e²=βκ−Σλe(1−e)p²。连续 lift (11)、任意半径标签测试 (13) 与 (A7) 逐行推出，保留 inverse-scale 价格并未宣称其积分有根阶上界。source-pair 边缘由 e_Je_K1_{J≠K}≤1 直接受同一 μ̂⊗μ̂ 支配，归一后常数为 1/Ω≤16/5。全部分离坐标 (14)–(16) 的 source 顺序与 receiver 间距都成立；平均 ss^T 的 PSD/trace=1 也准确，但不提供 uniform direction 或体积预算。作者末段明确保留 hard 分支的几何缺口，与本审核一致。未发现需修改的代数/量词错误；H≥8/3 的小维常数补齐仍需最终主报告保留。
