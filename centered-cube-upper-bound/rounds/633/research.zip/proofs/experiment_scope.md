# R633 geometry/radii experiment scope audit

Scope: read `/tmp/ccu_r633/CONTRACT.md`, the `geometry` and `radii` input/output schemas, runners, and the already proved R632 cover interface in `/tmp/ccu_r632_final/proofs/outer.md` and `REPORT.tex`. This checks model alignment and accounting fields; it does not re-prove the R632 cover or certify a root-order theorem. The R632 interface has (a>2t>2), (b=a(1+1/t)), and (|K|≤[1+(1+1/t+1/a)^n/\tau]S), with the finite-cover reduction at (E_1).

## Interface match

- **Same input (f): yes, within each case.** Each input specifies one (n)-dimensional nonnegative rational box mixture (f=sum_s d_s1_{B_s}). `radii/engine.py` integrates every box to compute each center's mass polynomial; `geometry/run_common.py` uses that same `sources` array for all inner witnesses and all caps. The finite LP rows for all centers share one nonnegative cell-mass vector, not a separate source per center. This is an auxiliary candidate certificate measure, not the input (f) itself. Overlapping input boxes add as densities of the same (f); their full product-box geometry retains coordinate correlations instead of replacing them by marginal profiles. The LP's joint cell masks likewise retain incidences across coordinates. The two variants only add two centers; they keep the same (f).
- **One threshold (lambda=1): yes in execution, implicit in schema.** The mass excess polynomial is `∫_Q f − (2r)^n`; thus every center uses the same unit threshold. There is no `lambda` field in JSON, and the engine hardcodes 1. This is aligned with R632's (E_1), but should be made an explicit schema field before generalizing the experiment.
- **Radius versus side length: consistent.** `r_minus` and `r_plus` are half-side radii in (Q(x,r)=x+(-r,r)^n); volumes are ((2r)^n). Inner demand boxes use `r_minus`. Sampled outer caps use (r_+(1+delta)), (delta\in\{0,1/4,1/2,1,2\}), all at or beyond `r_plus`. The radii engine's piecewise rational excess/root records and tail formula certify the final strict-bad radius and nonpositive excess for every (r\ge r_+); the geometry runner itself only rechecks the five sampled caps, so it relies on the radii-engine all-scale certificate rather than independently verifying its sign bands.
- **Strict witness and outer cap are distinct: yes.** `r_minus` is below the final strict-bad radius and `inner_excess>0` verifies (int_{Q(x,r_-)}f>(2r_-)^n). `r_plus` is above the isolated final root interval, with ((r_+/r_-)^n\le101/100); its purpose is to start legal caps. Do not identify the strict witness radius with the canonical contact (R^*(x)), which is a supremum/contact radius. The exact root/band certificate bridges the two for these finite rational inputs only.
- **True receiver measure: recorded, with a finite-sample interpretation.** `true_receiver_union` is the exact rational inclusion–exclusion volume of (\bigcup_i Q(x_i,r_{-,i}/a)), not the sum of receiver volumes and not a point count. It is an actual Lebesgue receiver union for this finite set of centers. It is not the full level set (E_1), nor a general compact (K\subset E_1). (V/M), (V/P0), and receiver volumes are therefore diagnostic sample ratios, not the weak-type constant or a universal receiver bound.
- **Source-box incidence/correlation: modeled, but LP numerics are not exact certificates.** `dp_patterns.py` builds joint overlap masks of all inner and sampled outer axis boxes, so different coordinate patterns are retained. `P0/P1` are SciPy/HiGHS floating LP results; the printed primal/dual/violation figures are not rationalized certificates. Input integrals and receiver union are rational; solver optimality/gap remains numerical. (P1)'s outer RHS is volume (|O|), as required by the contract, not the actual mixture mass (f(O)).

## (N/a^n) and receiver budget marker

The runner sets (a=\max(2n,8)). Reported (N/a^n):

| (n) | (N=4) | (N=6) |
|---:|---:|---:|
| 2 | (1/16) | (3/32) |
| 3 | (1/128) | (3/256) |
| 7 | (1/26353376) | (3/52706752) |

This marker is explicitly present in every geometry output. The 7D values are tiny because of the (a^{-n}) receiver scaling; the measured receiver-union-to-input-mass ratios are about (9.59\times10^{-9}) (N=4) and (9.82\times10^{-9}) (N=6). Thus these 7D cases trivially pay their own receiver volume from the available mass scale and do not stress the receiver budget. The 2D/3D cases are still fixed finite examples only. No dimension conclusion follows.

## Run accounting

Terra reports six cases run **serially**, one Python process per case, BLAS limited to one thread, with no concurrent case workers. The six solver sections used about 0.303 CPU seconds total; maximum per-case peak RSS was 78.1 MB; process startup included, total wall time was about 1.3 seconds. The result JSON files are `geometry/result_n{2,3,7}_v{0,1}.json`. A contemporaneous process check found no surviving geometry PID; no claim is made that unrelated machine-wide activity was idle or busy. The per-case result files report the SciPy solver's own process CPU/wall and peak-RSS fields.

## Decision

These inputs match the finite canonical-geometry diagnostic intended by R633: one shared (f), one unit level, coherent half-side radii, strict inner witnesses, outer volume caps, correlated box incidence, and true finite receiver-union volume are represented. The most material documentation gap is that (lambda=1) is implicit rather than a schema field. The most material interpretation limit is the extremely small 7D (N/a^n) and receiver budget. The outputs can distinguish finite mechanism behavior; they cannot establish the requested general weak-type bound or any dimension order.
