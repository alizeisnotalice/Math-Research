# R633：高完整族比率下的双 receiver 暴露桥

2026-10-28。这是一个一般定量引理，尚不是根阶体积上界。它将 R619 中只有一个标记端点具有 receiver 边缘的法则，转成两个端点都受完整真实 receiver 均匀测度常数支配的法则。所有源质量、真实增量、半径和全部分离坐标均保留；不使用原输入的 canonical outer caps，不对辅助来源擅加密度帽。

## 1. 完整族、正则来源与共同二源法则

给定完整有限小立方体族 B_j=Q(y_j,r_j)，星 A_j=aB_j，a>1，完整 receiver 集 U=∪B_j。固定一次顺序，取真实不交增量 I_j，v_j=|I_j|>0，V=Σv_j=|U|。删去零增量后的族仍覆盖 U 至零测集。

使用 R619 的同一个正则 packing 与真实 L¹ 辅助来源 μ，记

\[
 d_j=|A_j|,\quad m_j=\mu(A_j),\quad
 Q=\sum_j\lambda_jd_j,\quad M=\mu(\mathbb R^n)=Q+\epsilon V,
\]
\[
 \lambda_j(m_j-d_j)=\epsilon v_j,\qquad
 \sum_j\lambda_j\mathbf1_{A_j}=1\quad\mu\text{-a.e.}
\tag{1}
\]

令

\[
 p_j=\frac{m_j}{M},\quad \rho_j=\lambda_jp_j,\quad
 e_j=\frac{\epsilon v_j}{\lambda_jm_j}=1-\frac{d_j}{m_j}\in(0,1),
 \quad \beta=\frac{\epsilon V}{M}=\sum_j\rho_je_j,
 \quad \eta_j=\frac{v_j}{V}=\frac{\rho_je_j}{\beta}.
\tag{2}
\]

Σρ_j=1。R619 共同来源比例为

\[
 \kappa=\sum_j\eta_jp_j,\qquad
 \beta\kappa=\sum_j\lambda_je_jp_j^2.
\tag{3}
\]

在正 μ 质量的有限 source cells 上，对每一对 source membership cliques 选 R619 的 Hall coupling π_{xy}(j,k)。其条件边缘为

\[
 \sum_k\pi_{xy}(j,k)=\lambda_j\mathbf1_{A_j}(x),\quad
 \sum_j\pi_{xy}(j,k)=\lambda_k\mathbf1_{A_k}(y).
\tag{4}
\]

共享标签全部沿对角配对：\(\pi_{xy}(j,j)=\lambda_j\mathbf1_{A_j}(x)\mathbf1_{A_j}(y)\)。其余支持于真正不交星 A_j∩A_k=∅。因为只有有限个 cells，选择是可测的；必要时将 π_{xy} 与 π_{yx} 的转置平均，保持所有性质并获得对称法则。

定义概率法则

\[
 d\Pi(x,y,j,k)=\frac{d\mu(x)d\mu(y)}{M^2}\,\pi_{xy}(j,k).
\tag{5}
\]

Π 的两个 source 边缘联合为 \(\widehat\mu\otimes\widehat\mu\)，而 J、K 的边缘各为 ρ。没有假定 J、K 独立。

## 2. 双暴露引理

对 Π 同时施加两端的真实曝光权，删除对角：

\[
 d\Gamma=e_Je_K\mathbf1_{J\ne K}\,d\Pi,\qquad
 \Omega=\Gamma(\text{全空间}).
\tag{6}
\]

则

\[
 \boxed{\ \Omega\ge 2\beta-1-\beta\kappa
 =\beta(2-\kappa)-1.\ }
\tag{7}
\]

证明：\((1-e_J)(1-e_K)\ge0\) 给
\(\mathbb E_\Pi(e_Je_K)\ge2\beta-1\)。被删去的对角质量准确为

\[
 \sum_j\lambda_je_j^2p_j^2
 \le\sum_j\lambda_je_jp_j^2=\beta\kappa.
\]

没有用独立性将 \(\mathbb E(e_Je_K)\) 替换成 β²。还可保留准确非负修正：

\[
 \Omega=2\beta-1-\beta\kappa
 +\mathbb E_\Pi[(1-e_J)(1-e_K)]
 +\sum_j\lambda_je_j(1-e_j)p_j^2.
\tag{8}
\]

两端标签边缘均满足

\[
 \Gamma(J=j)\le e_j\rho_j=\beta\frac{v_j}{V},\qquad
 \Gamma(K=j)\le\beta\frac{v_j}{V}.
\tag{9}
\]

这里仅用了另一端 e≤1 和删除对角不会增大边缘。与单端标记法则不同，(9) 对两个端点同时成立。

若 β≥3/4、κ≤1/4，则

\[
 \Omega\ge5/16,\qquad
 \frac{\beta}{\Omega}\le
 \frac{\beta}{\beta(2-\kappa)-1}\le\frac{12}{5}.
\tag{10}
\]

第二个常数由该分式对 β 单调递减、对 κ 单调递增得到；不能仅用 Ω≥5/16、β≤1 推出 12/5。

## 3. 到真实连续 receiver 的双端 lift

在给定 J=j、K=k 后，独立按 I_j、I_k 上均匀 Lebesgue 分布抽取 Z、Z'。这给完整联合有限测度

\[
 d\widetilde\Gamma=
 e_je_k\mathbf1_{j\ne k}\pi_{xy}(j,k)
 \frac{d\mu(x)d\mu(y)}{M^2}
 \frac{\mathbf1_{I_j}(z)dz}{v_j}
 \frac{\mathbf1_{I_k}(z')dz'}{v_k}.
\tag{11}
\]

它的总质量仍是 Ω。任意非负可测测试函数 φ 均满足

\[
 \int\phi(Z)\,d\widetilde\Gamma\le\frac\beta V\int_U\phi(z)dz,
 \qquad
 \int\phi(Z')\,d\widetilde\Gamma\le\frac\beta V\int_U\phi(z)dz.
\tag{12}
\]

故在 (10) 区间，\(\widetilde\Gamma/\Omega\) 的两个 receiver 边缘都至多是完整均匀 receiver 测度的 12/5 倍。

半径标签不被丢弃：对任意非负 ψ(z,r)，准确版本为

\[
 \int\psi(Z,r_J)\,d\widetilde\Gamma
 \le\frac\beta V\sum_j\int_{I_j}\psi(z,r_j)dz,
\tag{13}
\]

另一端同理。因此可在 ψ 内保留任意实际 inverse-scale 价格，例如 \((2ar_j)^{-n}\)，而不会额外引入 \(1/\lambda_{\min}\) 或 \(1/m_{\min}\)。这并不声称该价格的 receiver 积分已有维数一致上界。

源侧也有共同支配：\(\widetilde\Gamma\) 的 source-pair 边缘至多 \(\widehat\mu\otimes\widehat\mu\)，其每个 source 边缘至多 \(\widehat\mu\)。归一化后相应常数为 1/Ω≤16/5。全构造始终使用同一个 μ；没有给每个 pair、组件或尺度另分配一份 M。

## 4. 保留全部分离坐标

Γ 只支持不交星。对每个 (j,k)，定义完整非空分离坐标集合

\[
 S_{jk}=\{i:|y_{j,i}-y_{k,i}|\ge a(r_j+r_k)\},\quad
 h_{jk}=|S_{jk}|,\quad
 s_{jk,i}=\frac{\operatorname{sgn}(y_{j,i}-y_{k,i})\mathbf1_{i\in S_{jk}}}{\sqrt{h_{jk}}}.
\tag{14}
\]

于是 \(\|s_{jk}\|_2=1\)。对 (11) 上全部真实 receiver/source 点，逐坐标有

\[
 \operatorname{sgn}(y_{j,i}-y_{k,i})(Z_i-Z_i')
 \ge(a-1)(r_j+r_k)\quad(i\in S_{jk}),
\]
\[
 \operatorname{sgn}(y_{j,i}-y_{k,i})(X_i-Y_i)
 \ge |y_{j,i}-y_{k,i}|-a(r_j+r_k)\ge0.
\tag{15}
\]

特别得到

\[
 \boxed{\ \langle s_{jk},Z-Z'\rangle
 \ge(a-1)(r_j+r_k)\sqrt{h_{jk}}.\ }
\tag{16}
\]

这保留所有分离方向及其符号，而不是任选一个坐标后丢弃其余方向。平均矩阵 \(\mathsf A=\mathbb E_{\widetilde\Gamma/\Omega}(s s^T)\) 为半正定，trace 为 1；该陈述没有给出 receiver 体积估计。

## 5. β 的高比率分支合法性

预先按 R632/R633 的同一参数选择

\[
 P=(1+1/a)^n,\quad H=\sqrt n\log^A(n+2),\quad
 \epsilon=\frac1{2PH}.
\tag{17}
\]

令 R=V/Q。准确有

\[
 \beta=\frac{\epsilon R}{1+\epsilon R},\qquad
 \beta\ge3/4\iff R\ge\frac3\epsilon=6PH.
\tag{18}
\]

因此只在尚不能以 V≤6PHQ 结账的真正高完整族比率分支上使用 (10)，没有假定所有实例的 β 都大。

更强地，旧共同来源包围式 \(\kappa V\le PM\) 给

\[
 \kappa\le P(1/R+\epsilon).
\]

若 R>6PH，则 \(\kappa<2/(3H)\)。对 H≥8/3 自动有 κ<1/4，因而整个高比率分支均获得 (10)–(16)，无需额外假设来源数、最小权、尺度跨度或相互独立的组件。

**尚未完成的步骤：** 目前没有由 (11)–(16) 排除 R>6PH 的一般 cube 几何定理。存在这个双 receiver 法则本身不是 V/M 上界。它是一个在真正高比率分支成立、无逆权损失的完整族结构结论；后续仍需将源侧一次容量与实际 receiver 空间约束一起转成数量上的矛盾或收缩。
