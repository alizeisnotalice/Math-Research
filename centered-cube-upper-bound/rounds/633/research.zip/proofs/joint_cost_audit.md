# 同对象 lift、退化核与 Γ 成本：精确独立审查

唯一数学输入为 `/tmp/ccu_r633/selection.md` 已冻结的完整 Π、Γ 与 lift。假设其完整族、真实不交增量、packing 恒等式和 Hall 支持合同均成立；不另换来源、不改变选择，不调用 outer cap。三项新增代数均通过。以下没有建立 trace 到 Hilbert–Schmidt 的无条件推论，也没有一般体积上界。

记 `μhat=μ/M`、`ν_U(dz)=1_U(z)dz/V`，并保持原文的 `p_j,ρ_j,e_j,η_j,β,κ`。

## 1. 单端曝光的交叉边缘恰为乘积

令 `Λ_J=e_JΠ`，在给定 J=j 后按真实 I_j 均匀抽 Z，条件独立于其余变量。用 Hall 第一边缘，

\[
\begin{aligned}
\Lambda_J(Y\in dy,J=j)
&=\widehat\mu(dy)\int\widehat\mu(dx)\,e_j\sum_k\pi_{xy}(j,k)\\
&=\widehat\mu(dy)e_j\lambda_jp_j
=\widehat\mu(dy)\,\beta\frac{v_j}{V}.
\end{aligned}
\]

因此准确到保留标签的版本为

\[
\Lambda_J(Y\in dy,Z\in dz,J=j)
=\frac\beta V\widehat\mu(dy)1_{I_j}(z)dz,
\]

求和即得

\[
\boxed{(Y,Z)_\#\widetilde\Lambda_J=\beta\,\widehat\mu\otimes\nu_U.}
\]

同理，单端 `Λ_K=e_KΠ` lift 的 `(X,Z')` 恰为同一乘积。由于 `e_Je_K1_{J≠K}≤e_J` 以及 ≤e_K，使用相同条件 receiver 抽样核后，

\[
(Y,Z)_\#\widetilde\Gamma\le\beta\widehat\mu\otimes\nu_U,
\qquad
(X,Z')_\#\widetilde\Gamma\le\beta\widehat\mu\otimes\nu_U.
\]

这是两个**交叉**边缘；没有声称匹配端 `(X,Z)` 或 `(Y,Z')` 是乘积，也没有声称 Γ 下独立。归一化后支配常数为 β/Ω。

## 2. 固定核 H 的退化性、PSD 与 trace

设

\[
h_j(x)=1_{A_j}(x)-p_j,\qquad
w_j=v_j/d_j>0,\qquad
H(x,y)=\sum_jw_jh_j(x)h_j(y).
\]

因 `∫h_jdμhat=0`，固定核 H 在 **μhat²** 下一级退化：

\[
\int H(x,y)d\widehat\mu(y)=0,
\qquad
\int H(x,y)d\widehat\mu(x)=0.
\]

有限和定义一个 L²(μhat) 上有限秩 PSD 算子：任意实 φ，

\[
\iint\phi(x)H(x,y)\phi(y)d\widehat\mu(x)d\widehat\mu(y)
=\sum_jw_j\left(\int\phi h_jd\widehat\mu\right)^2\ge0.
\]

PSD 是核/算子的二次型陈述，不是 H(x,y) 逐点非负。

其 trace 准确为

\[
T=\int H(x,x)d\widehat\mu(x)
=\sum_jw_jp_j(1-p_j).
\]

利用 `d_j=m_j(1−e_j)=Mp_j(1−e_j)` 与 `v_j=Vη_j`，逐项得到

\[
\boxed{T=\frac VM\mathbb E_\eta\frac{1-p_j}{1-e_j}
\ge\frac VM(1-\kappa).}
\]

不等式只用了 `0<e_j<1` 与 `0≤p_j≤1`，没有引入最小权、最小质量或独立性。

**禁止外推：** trace 下界本身不提供与标签数无关的 Hilbert–Schmidt 下界或算子范数下界。准确的 HS 式为

\[
\|H\|_{HS}^2
=\sum_{j,k}w_jw_k
\left[\widehat\mu(A_j\cap A_k)-p_jp_k\right]^2.
\]

若仅用秩 r，可得 `||H||HS²≥T²/r`，但 r 没有被证明受维数所需尺度控制；不能删除这个费用。

## 3. 自适应交叉核在 Γ 上的正成本

对固定标签 j,k 定义

\[
D_{jk}(X,Y)=h_j(X)h_k(Y)+h_k(X)h_j(Y).
\]

Γ 支持 j≠k、`A_j∩A_k=∅`，同时 X∈A_j、Y∈A_k；因此

\[
h_j(X)=1-p_j,\quad h_k(Y)=1-p_k,
\quad h_k(X)=-p_k,\quad h_j(Y)=-p_j,
\]

从而在 Γ 几乎处处准确有

\[
\boxed{D_{JK}(X,Y)=1-p_J-p_K+2p_Jp_K.}
\]

用原文的 `Γ(J=j)≤βη_j` 及 K 端同一边缘界，

\[
\int p_Jd\Gamma\leβ\kappa,
\qquad
\int p_Kd\Gamma\leβ\kappa.
\]

由于 `2p_Jp_K≥0`，

\[
\boxed{\int D_{JK}d\Gamma
\ge\Omega-2β\kappa
\geβ(2-3\kappa)-1.}
\]

最后一步使用已冻结的 `Ω≥β(2−κ)−1`。故在 `β≥3/4,κ≤1/8` 时，

\[
\boxed{\int D_{JK}d\Gamma\ge7/32.}
\]

此区间还可记录以下准确常数：

\[
\Omega\ge13/32,\qquad
\frac\beta\Omega\le\frac{24}{13},\qquad
\mathbb E_{\Gamma/\Omega}D_{JK}\ge\frac7{13}.
\]

后两个常数使用 `β/[β(2−κ)−1]` 对 β 递减、对 κ 递增；归一化成本则用 `1−2βκ/Ω`，不能仅把不相关的上下界随意相除。

## 4. 退化性适用范围不能改变

固定 j,k 的 D_jk 在 μhat² 下也一级退化。但 `(J,K)` 是由 source pair `(X,Y)` 经 Hall coupling 自适应选出的标签；Γ 又经过曝光和删对角。因此

- 不能从固定核的 product-measure 退化性推出 `∫D_JK dΓ=0`；
- 不能声称 H 或 D 在 Γ 下仍退化；
- 不能把 Γ 上的自适应 D 成本直接等同于固定权核 H 的 trace、HS 范数或其乘积均方；若要连接，必须另证标签权与测度转换的完整不等式。

三项审核给出的是同一完整构造内的精确边缘、核恒等式及正成本，尚没有把这些成本支付成真实 receiver 体积的全局上界。

## 5. 实际工具检查

本机 math venv、SymPy 1.14.0 轻量运行：展开 D 恒等式残差为 0；代入 `d=Mp(1−e)` 的 trace 逐项残差为 0；精确有理计算给 `Ω_min=13/32, cost_min=7/32, β/Ω≤24/13, normalized cost≥7/13`。没有新 LP、数值扫参或仓库改动。
