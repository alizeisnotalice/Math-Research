# R633：同一双 receiver 对象的增长桥独立审核

**判定：所提四项结论通过，常数可按下列精确式取得；尚未得到 V≤PHM。** 仅沿用 `selection.md` 的同一完整有限族、真实 I_j、lower-only KKT 来源 μ 和双 exposure Γ；没有另换输入、selection 或外尺度假设。

## 1. 好标签的真实 receiver 质量

沿用 ρ_j=λ_jm_j/M、e_j=1−d_j/m_j∈(0,1)、β=Σρ_je_j、η_j=v_j/V=ρ_je_j/β。令 G={j:e_j≥1/3}。在 Gc 上 e_j≤(1−e_j)/2，因此

\[
\beta\eta(G^c)=\sum_{G^c}\rho_je_j
\le\tfrac12\sum_{G^c}\rho_j(1-e_j)
\le\frac{1-\beta}{2}.
\]

β≥3/4 时 η(Gc)≤1/6，故

\[
\boxed{\sum_{j\in G}v_j\ge5V/6.}
\tag{G1}
\]

Gc 实际为严格 e<1/3，故某些场合可严格加强；本命题只用安全的非严格界。所有 v_j 都是原完整族真实增量，不能换为 |B_j|。

## 2. Γ 限制至两端都好后，质量及边缘

定义 Γ_G=1_{J∈G,K∈G}Γ，总质量 Ω_G。旧双 exposure 边缘给 Γ(J∈Gc)、Γ(K∈Gc) 各≤βη(Gc)。用并集上界而不假定两端独立，删去质量≤1−β。故

\[
\boxed{\Omega_G\ge\beta(2-\kappa)-1-(1-\beta)
=\beta(3-\kappa)-2.}
\tag{G2}
\]

β≥3/4、κ≤1/4 时 Ω_G≥1/16。限制不会增大任一 label 边缘，仍有 Γ_G(J=j)、Γ_G(K=j)≤βv_j/V。在同一真实 I_j,I_k 内均匀 lift，Γ_G/Ω_G 的两个 receiver 边缘均满足

\[
\boxed{\mathcal L(Z),\mathcal L(Z')
\le\frac\beta{\Omega_G}\frac{1_U dz}{V}
\le12\frac{1_U dz}{V}.}
\tag{G3}
\]

最后常数必须使用完整分式 β/[β(3−κ)−2]：它随 β 下降、随 κ 上升，在 (3/4,1/4) 等于 12。单用 Ω_G≥1/16 与 β≤1 只能给 16。原 Γ 的 off-diagonal/disjoint-star 支持被保留；此限制没有重新申请任何来源质量。

## 3. 六倍小立方体确为同一 μ 的严格坏域

j∈G 给

\[
m_j=\mu(A_j)\ge\tfrac32d_j=\tfrac32(2ar_j)^n.
\]

任意 z∈6B_j=Q(y_j,6r_j)，开立方体 Q(z,(a+6)r_j) 包含 A_j：对 u∈A_j，||u−z||∞<(a+6)r_j。于是其真实 μ 平均满足

\[
\frac{\mu Q(z,(a+6)r_j)}{[2(a+6)r_j]^n}
\ge\tfrac32(1+6/a)^{-n}.
\]

若 a≥16n，则 (1+6/a)^n≤exp(3/8)<3/2，所以该平均**严格大于 1**，即

\[
\boxed{6B_j\subset\{M_{\rm cube}\mu>1\}\quad(j\in G).}
\tag{G4}
\]

严格号在 e_j=1/3 或 a=16n 的端点仍成立。一个纯解析常数验证是 log(3/2)>2/5>3/8；前一不等式来自 log x>2(x−1)/(x+1)（x>1）。因此不依赖浮点近似、边界取值或几乎处处平均。μ 是原 KKT 正体积 cells 上摊放的真实非负 L1 来源，所选半径合法；这里的坏域是 **Mμ 的坏域**，不是原 f 的坏域，不能据此转移原 f 的 canonical 外帽。

又 a≥16n≥16>6，故 6B_j⊂A_j。这立即给

\[
\sum_{j\in G}\lambda_j1_{6B_j}\le\sum_j\lambda_j1_{A_j}\le1
\quad\text{a.e.}
\tag{G5}
\]

Γ_G 支持的每个 pair 原有 A_j∩A_k=∅，所以也有 6B_j∩6B_k=∅。这是支持上的逐 pair 结论，不能宣称所有好标签的六倍立方体两两不交。

## 4. 距离根阶完整付款仍缺哪条估计

令 U_6=∪_{j∈G}6B_j。现有结论只保证

\[
|U_6|\ge\sum_{j\in G}v_j\ge5V/6,
\qquad U_6\subset\{M\mu>1\},
\]

以及 (G3)、(G5) 和支持上的 pair 分离。没有证出 U_6 对原 U 的统一严格体积增长；每个立方体扩大 6 倍不会自动把整个并集体积扩大固定比例。原 receiver 边缘支配也不自动推送为 U_6 上的均匀边缘支配：lift 原本在 I_j，扩张后重叠与 label 权仍需同时支付。(G5) 是 packing 容量，不能将积分方向倒置为 |U_6| 的上界。

所缺的完整一般估计应从**同一个 Γ_G、同一个 μ 与全部真实半径**，支付完整 V（或把未付坏标签作为严格小于 1 的 V 项吸收），例如独立证明 V≤L_nM、L_n≤PH_n；当前没有这样的 cube 几何/列容量估计。仅套用未知弱型常数到 U_6，只得 V≤(6/5)C_nM，仍循环。若能另证 |U_6|≤(5/6)PH_nM，则 (G1) 才直接给 V≤PH_nM；这只是清楚标出充分的完整体积付款，**不是已证结果**。同理，迭代增长若改变 family/source/阈值，需重新保留 Γ_G 边缘和全时钟，不能直接无限重复 (G4)。

在既定 ε=1/(2PH_n) 下，真正取得 V≤PH_nM 才可吸收 M=Q+εV，得 V≤2PH_nQ，从而排除已审 R>6PH_n 的 hard 分支。增长桥本身尚未完成这步。

## 5. 轻量实算与作者交流

本机 math Python/SymPy 1.14.0 一次实际运行给出：η(Gc) 的 hard corner 上界 1/6；Ω_G corner 为 1/16；β/[β(3−κ)−2] corner 为 12；其 β、κ 导数为 −2/[βκ−3β+2]^2 与 β²/[βκ−3β+2]^2；2/5−3/8=1/40。进程约 0.036 秒，无重数值或旧样本重算。一般概率、几何及严格平均由上文证明。

已将独立公式 (G1)–(G5)、常数注意事项及缺口发给 joint_contact_xhigh；未沿用作者结论作为证明依据。正式作者新增式的对照结果在收到后补注。

**正式新增稿对照：** 已只读 `/tmp/ccu_r633/growth_bridge.md`。其 §1–2 与 (G1)–(G5) 一致，source-pair 归一支配 ≤16 μ̂⊗μ̂ 也由 Ω_G≥1/16 得到。作者保留了 a 必须在原族/KKT 构造前选择的限制，正确；不能事后将固定实例的 a 改大。

作者 §3 的新增原始增长式亦独立核清：s_j=m_j/d_j=1+εv_j/(λ_jd_j)，所以 Σv_js_j=V+εΣv_j²/(λ_jd_j)≥V+εV²/Q=(M/Q)V，Cauchy 的分母准确为同一 Q=Σλ_jd_j。各自 homothety T_j 的 Jacobian 为 s_j，故是未扣 overlap 的总量。α_j=s_j^(1/n) 的准确端点只保证 enlarged-star 平均≥1；作者已注明用 1≤α'_j<α_j 的严格略小膨胀，才是 >1 的合法坏 witness，因此没有严格号错误。其 (3.2) 的真实亏损 ∫(N−1)_+ 仍未支付；pairwise Γ_G 支持不交不能替代全族 overlap 控制，也没有已证的同源迭代/全族比较来把原始增长变成 V≤PHM。未发现新增稿的代数/常数错误；缺口描述准确。

## 6. 唯一新增邻居 source-union 包含步骤（a≥32n）

**独立判定：成立，包含有严格半径余量；没有支付跨 j 列预算。** 参数 a≥32n 必须事先用于原完整族与同一 KKT 来源 μ。对 j∈G，设

\[
\mathcal N_j=\{k\in G:r_k\le r_j,\ 6B_j\cap6B_k\ne\varnothing\},
\quad R_j^*=\sup\{R>0:\mu Q(y_j,R)>(2R)^n\},
\quad A_j^*=Q(y_j,R_j^*).
\]

若 k∈Nj，六倍小 cubes 相交给 ||y_k−y_j||∞<6(r_j+r_k)。因此每个 u∈A_k 满足

\[
\|u-y_j\|_\infty
< ar_k+6(r_j+r_k)
\le(a+12)r_j.
\]

故完整邻居族同时有

\[
\bigcup_{k\in\mathcal N_j}A_k\subset Q(y_j,(a+12)r_j).
\tag{N1}
\]

因 j∈G，m_j≥(3/2)(2ar_j)^n。对 ar_j≤R<a(3/2)^(1/n)r_j，同中心 Q(y_j,R) 包含 A_j 且严格坏，因此

\[
R_j^*\ge a(3/2)^{1/n}r_j.
\]

对每个整数 n≥1，exp x−1≥x 给

\[
a[(3/2)^{1/n}-1]
\ge32\log(3/2)>12.
\tag{N2}
\]

最后严格号甚至可用 log(3/2)>2/5>3/8，故 32log(3/2)>64/5>12。于是 (a+12)r_j<R_j^*，从而

\[
\boxed{\bigcup_{k\in\mathcal N_j}A_k
\subset Q(y_j,(a+12)r_j)\subset A_j^*.}
\tag{N3}
\]

**接触与全部外帽。** 同一 μ 是非负 L1，故 R↦μQ(y_j,R) 连续（各立方体边界为 Lebesgue 零集）。坏半径非空，因为原 ar_j 处平均≥3/2；它有限，因为 μQ≤M 而 (2R)^n→∞。因此 0<R_j*<∞，连续性与 supremum 性质严格推出

\[
\mu(A_j^*)=|A_j^*|,
\qquad\mu Q(y_j,R)\le(2R)^n\quad\text{对全部 }R\ge R_j^*.
\tag{N4}
\]

这里不假定所有 R<R_j* 都坏。A_j* 是等值接触 cube，本身不必严格坏；若另需严格坏 witness，因 (N3) 的半径余量，可从趋近 R_j* 的 strict-bad 半径序列中选择仍大于 (a+12)r_j 的一个，保持邻居包含。边界 null 不会引入额外 μ 质量。

最后对**原** packing 积分，而不声称新 canonical stars 仍受同一 packing：

\[
\begin{aligned}
\sum_{k\in\mathcal N_j}\lambda_km_k
&=\int\sum_{k\in\mathcal N_j}\lambda_k1_{A_k}\,d\mu\\
&\le\mu\!\left(\bigcup_{k\in\mathcal N_j}A_k\right)
\le\mu(A_j^*)=|A_j^*|.
\end{aligned}
\tag{N5}
\]

原 packing 的 Lebesgue-a.e. 容量对 μ 亦 a.e. 有效，正因为 μ 为真实 L1。故同一 j 的所有邻居 source union 确实只收费一次，没有邻居数因子。(N4) 的全部大半径帽也确为这个辅助 μ 自身、同一中心 y_j 的合法帽，不是从原 f 转移而来。跨不同 j 的 A_j* 可重叠，当前没有将 (N5) 跨 j 加总的 source-column 容量；本步不声称这一费用已付。已将独立结论告知 contact 作者。

## 7. 同一 Γ 的全局 canonical 交叉筛选（H≥32）

**独立判定：成立，可归档；仍不是 V/M 付款。** 为原完整有限族每个 label j（不只 G）取同一辅助 μ 自身的 canonical cube A_j*=Q(y_j,R_j*)。所有原 rows 有 m_j>d_j，故前节接触论证给 R_j*≥ar_j、μ(A_j*)=|A_j*|≤M，且所有 R≥R_j* 的体积帽有效。令

\[
\kappa^*=\sum_j\frac{v_j}{V}\frac{\mu(A_j^*)}{M}.
\]

对固定 source point y，若 y∈A_j*，则每个 z∈I_j⊂B_j 满足

\[
\|z-y\|_\infty<R_j^*+r_j
\le(1+1/a)R_j^*
\le(1+1/a)M^{1/n}/2.
\]

相关 I_j 真实不交，因此同时包含于上述同一个 cube 的容量给

\[
\sum_{j:y\in A_j^*}v_j\le PM,
\quad P=(1+1/a)^n.
\]

对同一 μ/M 仅积分一次，严格得到

\[
\boxed{\kappa^*V\le PM.}
\tag{C1}
\]

此处不要求新 canonical stars 受原 λ packing；只用 R_j*≥ar_j 与各自 canonical 体积≤M。

**交叉边缘而非 Γ 内独立。** 未标记 Π 的条件 row 和为 λ_j1_Aj(X)，故消去 K、积分 X 后，

\[
(e_J\Pi)(J=j,Y\in dy)
=e_j\rho_j\,\frac{d\mu(y)}M
=\beta\frac{v_j}{V}\frac{d\mu(y)}M.
\tag{C2}
\]

即 e_JΠ 的交叉 (J,Y) 是总质量 β 的乘积边缘；(e_KΠ)(K,X) 对称。Γ=e_Je_K1_{J≠K}Π≤e_JΠ、亦≤e_KΠ，故

\[
\Gamma\{Y\in A_J^*\}\le\beta\kappa^*,
\qquad\Gamma\{X\in A_K^*\}\le\beta\kappa^*.
\]

由 β=εV/M、(C1) 及预先 ε=1/(2PH)，每项均≤Pε=1/(2H)。这不宣称 J,Y 在 Γ 或筛选后法则中独立；独立只在 (C2) 的未归一交叉边缘中使用。

定义同一 Γ 的进一步 submeasure

\[
\Gamma_{\rm far}=\Gamma_G\,1_{Y\notin A_J^*}\,1_{X\notin A_K^*}.
\]

不假设两事件独立，仅用并集上界，

\[
\boxed{\Omega_{\rm far}\ge\Omega_G-1/H
\ge1/16-1/H\ge1/32\quad(H\ge32).}
\tag{C3}
\]

所有 label、真实 receiver、半径、source points 与原 off-diagonal 支持均未改变。若将 Γ_far 重新归一，旧 12 的 receiver 常数不可直接照搬：准确常数仍是 β/Ω_far，安全地≤32；保留联合下界 Ω_far≥β(3−κ)−2−1/H 时，可由同样分式单调在 (β,κ,H)=(3/4,1/4,32) 得≤24。未归一两端 receiver 边缘仍各≤β1_U dz/V。

**距离与严格号。** 在 Γ_far 支持上，j,k∈G，a≥32n；Y∉A_j* 表示 ||Y−y_j||∞≥R_j*（开 cube 的外部允许等号）。但前节已有严格余量 R_j*−ar_j>12r_j，故

\[
\boxed{\operatorname{dist}_\infty(Y,A_j)>12r_j,
\qquad\operatorname{dist}_\infty(X,A_k)>12r_k.}
\tag{C4}
\]

在第一式选择实现 ||Y−y_j||∞ 的坐标 i；因实际 X∈A_j，反三角不等式给同一个坐标 |Y_i−X_i|>12r_j。逆向同理有某坐标 l 满足 |X_l−Y_l|>12r_k。因此确有 ||X−Y||∞>12 max(r_j,r_k)。两方向所用坐标可能不同，也不必等于原 Hall 的完整分离集合 S_jk；不能据 (C4) 自动增加 S_jk 内每个坐标的余量。

所有 canonical 接触及外帽均属于同一个真实 L1 辅助 μ，边界 null 和半径连续性已在 §6 核清；这里没有转移原输入 f 的帽，也没有跨 j 相加一份 M。此筛选给正质量、双端真实 exposure 和 partner-source 的严格远离，但不提供全族膨胀重叠或 source-column 付款，因此仍不能推出 V≤PHM。已告知 contact 作者该结论及新归一常数注意事项。
