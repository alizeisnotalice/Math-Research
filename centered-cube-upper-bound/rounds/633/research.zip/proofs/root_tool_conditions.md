# R633 本机实根隔离与 Arb 接口核验

运行环境：合同指定 venv；Python 3.12；SymPy 1.14.0 (`sympy.__file__` 位于该 venv 的 site-packages)；python-flint 0.9.0。只做本机 API/source/docstring 检查与少量固定有理多项式调用，未运行大量数值。

## SymPy：可用于有理多项式实根隔离

本机入口：`from sympy import intervals, Rational`，调用 `intervals(p, eps=Rational(1, 2**k), inf=..., sup=...)`；文档签名为 `(F, all=False, eps=None, inf=None, sup=None, strict=False, fast=False, sqf=False)`。`Poly.intervals` 文档明确称实根用 Vincent–Akritas–Strzebonski continued-fractions 方法；实现把有理端点转为 QQ，再调用 `dup_isolate_real_roots_list`。结果是有理隔离端点与根重数；恰为有理数的根会返回退化区间 `(q,q)`。核验：`(x-1)(x-3)` 得 `[((1,1),1),((3,3),1)]`；`(x-1)^2(x+2)` 得 `[((-2,-2),1),((1,1),2)]`；`(x-1)(x-2)` 配 `inf=1,sup=3` 仍包含两个端点根。故闭区间端点要显式检查，不能假设被排除。`intervals(0)` 返回空列表，但零多项式代表整段恒零/平台，不是“无根”；先以 `Poly(p,x).is_zero` 单独分支。

精确有理多项式的有理点符号可直接用 `Poly.eval(q)` 得精确有理数，再比较其分子/值与 0。对每个解析段，要隔离该段内全部实根并把定义域分成每个 root-free connected segment；每段取一个有理测试点精确验符号（多项式在无根连通段符号恒定），并单独验闭区间端点。要证明之后不再 positive，必须覆盖 cutoff 之后直到完整定义域终点/无穷远的所有段和所有端点，或用相应尾部界；只找到一个根不能作无正性证书。若有 piecewise 多项式/外帽，逐段各自做同一核验，并将段界接点列入端点检查。对零多项式段单独认定恒零。

API 陷阱：顶层 `intervals` 对单个表达式会转调 `Poly.intervals`，该分支没有转交 `strict` 参数；勿依赖 `strict=True` 排除端点。`inf`/`sup` 有理区间测试实测端点根被纳入。`eps` 要正有理数；根隔离不替代针对所有定义域段的符号覆盖。

## python-flint / Arb：本机不能用于通用精确实根隔离

python-flint 0.9.0 的 `fmpq_poly.real_roots()` 实际调用对有理系数多项式抛 `NotImplementedError: Real roots are not supported for this polynomial`；`arb_poly.real_roots()` 同样抛该错误。`fmpq_poly.roots()` 的官方 docstring 说返回基环中的根及重数，因此只涵盖有理根，不给一般代数实根隔离区间。typing stub 虽声明 `real_roots() -> list[arb]`，与本机实际调用不符，应以本机运行结果为准。

`arb` 是 midpoint-radius 实区间包络；`arb.sgn()` 返回的仍是 Arb 区间，含零输入区间可能给 `+/-1`，不能强造 exact sign。`arb.is_zero()` 仅确认该 ball 精确为零；对包含零的非零宽度 ball 返回 false，既不证明原目标值非零，也不确定其符号。Arb 适合有向舍入区间评估：只有包络严格落在零的一侧才认证严格正/负；跨零则结论未定。对有理多项式的精确零/符号判定，当前宜用 SymPy QQ 精确计算，而非 Arb 近似值。

## 技能边界

L03 `/Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md` 的 L03-API-01 明确未验证任何带向外舍入保证的浮点区间库；上述是本机 API 实测及有限用法说明，不扩展为通用库保证。B02 `/Users/zhengzhihao/.codex/skills/math-b02-semi-infinite-exchange/SKILL.md` 明确有限采样不认证全域约束、局部分离不认证所有索引；因此根隔离/分段点检只有在完整解析段及完整尾域覆盖时才可支持非正性结论。这里仅报告工具接口，不认证目标函数的多项式建模、段覆盖完整性或最终关键数学引理。
