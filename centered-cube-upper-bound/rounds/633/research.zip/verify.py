import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS'): os.environ[k]='1'
import sys,json,subprocess,time,hashlib,platform
from pathlib import Path
import sympy as s
import numpy,scipy
base=Path(__file__).resolve().parent
start=time.monotonic()
b,k=s.symbols('b k')
f=b/(b*(2-k)-1)
assert s.simplify(s.diff(f,b)+1/(b*(2-k)-1)**2)==0
assert f.subs({b:s.Rational(3,4),k:s.Rational(1,4)})==s.Rational(12,5)
assert f.subs({b:s.Rational(3,4),k:s.Rational(1,8)})==s.Rational(24,13)
assert (b*(2-3*k)-1).subs({b:s.Rational(3,4),k:s.Rational(1,8)})==s.Rational(7,32)
# Rational exponential upper bound: terms after degree 8 have ratios <= x/10.
x=s.Rational(3,8)
upper=sum(x**j/s.factorial(j) for j in range(9))+(x**9/s.factorial(9))/(1-x/10)
assert upper<s.Rational(3,2)
# log(3/2)>3/8 follows from the preceding strict exponential bound.
assert 32*s.Rational(3,8)==12
sys.path.insert(0,str(base/'numeric/geometry'))
from run_common import run
checks=[]
for n in (2,3,7):
 for v in (0,1):
  key=f'n{n}_v{v}'
  inp=base/f'numeric/geometry/input_{key}.json';cert=base/f'numeric/radii/{key}.json'
  r=subprocess.run([sys.executable,str(base/'numeric/matlab/compare.py'),str(inp),str(cert)],capture_output=True,text=True)
  assert r.returncode==0,(key,r.stdout,r.stderr)
  out=run(json.loads(inp.read_text()),json.loads(cert.read_text()))
  old=json.loads((base/f'numeric/geometry/result_{key}.json').read_text())
  assert out['status']=='complete'
  assert abs(out['ratio']-old['ratio'])<1e-8
  assert out['true_receiver_union']==old['true_receiver_union']
  checks.append({'case':key,'independent_exact_radius':'PASS','centers':out['N'],'ratio_float':out['ratio'],'V_over_P0_float':out['V_over_P0'],'receiver_union_rational':out['true_receiver_union'],'input_sha256':hashlib.sha256(inp.read_bytes()).hexdigest()})
control=subprocess.run([sys.executable,str(base/'numeric/radii/engine.py'),str(base/'numeric/radii/control.json')],capture_output=True,text=True)
assert control.returncode==0,control.stderr
c=json.loads(control.stdout)
assert [r['last_root_interval'] for r in c['centers']]==[['4','4'],['2','2'],['4','4']]
result={'interpreter':sys.executable,'python':platform.python_version(),'sympy':s.__version__,'numpy':numpy.__version__,'scipy':scipy.__version__,'constants_exact':'PASS','control_exact':'PASS','cases':checks,'wall_seconds':time.monotonic()-start,'scope':'Finite exact radius certificates and floating LP replay only; no general volume theorem.'}
(base/'VERIFICATION_LATEST.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
