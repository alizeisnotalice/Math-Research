import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import json,time,math,resource,sys,hashlib
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix,vstack
from itertools import combinations
from dp_patterns import dp_patterns

def interval_cube(c,r):return (tuple(x-r for x in c),tuple(x+r for x in c))
def volume(box):return math.prod(h-l for l,h in zip(*box))
def integrate(box,source):
 lo,hi=box; total=F(0)
 for s in source:
  length=F(1)
  for l,h,pair in zip(lo,hi,s['box']):length*=max(F(0),min(h,F(pair[1]))-max(l,F(pair[0])))
  total+=F(s['density'])*length
 return total

def run(inp,cert):
 wall=time.monotonic();cpu=time.process_time();n=inp['dimension'];centers=[tuple(map(F,c)) for c in inp['centers']];N=len(centers);rows=cert['centers'];assert cert['dimension']==n and len(rows)==N and all(x['status']=='certified' and tuple(map(F,x['center']))==c for x,c in zip(rows,centers))
 rminus=[F(x['r_minus']) for x in rows];rplus=[F(x['r_plus']) for x in rows];assert all(0<x<=y and (y/x)**n<=F(101,100) for x,y in zip(rminus,rplus))
 ds=[interval_cube(c,r) for c,r in zip(centers,rminus)];delta=[F(0),F(1,4),F(1,2),F(1),F(2)];outer=[interval_cube(c,r*(1+d)) for c,r in zip(centers,rplus) for d in delta];bs=ds+outer
 for x in ds:assert integrate(x,inp['sources'])>volume(x),'strict bad failed'
 for x in outer:assert integrate(x,inp['sources'])<=volume(x),'outer cap contradicts source; check radius cert'
 patterns,meta=dp_patterns(bs,n,1000000)
 if patterns is None:return {'status':'pattern_limit','dp':meta}
 p=sorted(patterns);rr=[];cc=[]
 for col,mask in enumerate(p):
  while mask:
   bit=mask&-mask;rr.append(bit.bit_length()-1);cc.append(col);mask-=bit
 A=csc_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(bs),len(p)));b=np.array([float(volume(x)) for x in bs]);N0=N
 sol0=linprog(np.ones(len(p)),A_ub=-A[:N],b_ub=-b[:N],method='highs');sol1=linprog(np.ones(len(p)),A_ub=vstack([-A[:N],A[N:]],format='csc'),b_ub=np.r_[-b[:N],b[N:]],method='highs')
 def result(sol):
  if not sol.success:return {'status':sol.message}
  v=A@sol.x
  return {'status':'optimal','objective':sol.fun,'max_lower_violation':max(0.,float(np.max(b[:N]-v[:N]))),'max_cap_violation':max(0.,float(np.max(v[N:]-b[N:]))),'primal':[[int(i),format(sol.x[i],'.17g')] for i in np.flatnonzero(sol.x>1e-9)],'dual':[[int(i),format(sol.ineqlin.marginals[i],'.17g')] for i in np.flatnonzero(abs(sol.ineqlin.marginals)>1e-9)]}
 a=max(2*n,8);rec=[interval_cube(c,r/a) for c,r in zip(centers,rminus)];union=F(0)
 for k in range(1,N+1):
  for g in combinations(rec,k):
   w=math.prod(max(F(0),min(x[1][i] for x in g)-max(x[0][i] for x in g)) for i in range(n));union+=(1 if k%2 else -1)*w
 mass=sum((F(s['density'])*math.prod(F(v)-F(u) for u,v in s['box']) for s in inp['sources']),F(0));witness=[integrate(x,inp['sources'])/volume(x) for x in ds]
 return {'status':'complete','dimension':n,'N':N,'a':a,'N_over_a_n':str(F(N,a**n)),'true_receiver_union':str(union),'M':str(mass),'rminus':list(map(str,rminus)),'rplus':list(map(str,rplus)),'volume_ratio_max':str(max((v/u)**n for u,v in zip(rminus,rplus))),'strict_averages':list(map(str,witness)),'patterns':len(p),'dp_stages':meta['sizes'],'P0':result(sol0),'P1':result(sol1),'ratio':sol1.fun/sol0.fun if sol0.success and sol1.success else None,'V_over_P0':float(union)/sol0.fun if sol0.success else None,'V_over_M':float(union/mass),'max_input_cap_difference':str(max(integrate(x,inp['sources'])-volume(x) for x in outer)),'source':inp,'wall_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 raw=Path(sys.argv[1]).read_bytes();inp=json.loads(raw);cert=json.load(open(sys.argv[2]));assert hashlib.sha256(raw).hexdigest()==cert['input_sha256'];out=run(inp,cert);Path(sys.argv[3]).write_text(json.dumps(out,indent=2));print(json.dumps({k:out.get(k) for k in ('status','dimension','N','ratio','V_over_P0','wall_seconds')}))
