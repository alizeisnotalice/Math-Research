import json,sys,hashlib,time,resource
import sympy as sp
from independent import intervals,check,S,r
f,g=sys.argv[1:]; raw=open(f,'rb').read();d=json.loads(raw); cert=json.load(open(g));assert cert['input_sha256']==hashlib.sha256(raw).hexdigest(); t=time.monotonic()
for i,c in enumerate(cert['centers']):
 assert c['status']=='certified',(i,c['status']); assert list(map(S,c['center']))==list(map(S,d['centers'][i])); assert S(c['ratio_power'])==(S(c['r_plus'])/S(c['r_minus']))**d['dimension']; ps=intervals(d,d['centers'][i]);print('CENTER',i)
 lroot,hroot=map(S,c['last_root_interval']); assert S(c['r_minus'])<=lroot<=hroot<=S(c['r_plus']); qroot=next(q for a,b,p,q in ps if a<=lroot and hroot<=b); assert (qroot.eval(lroot)==0 if lroot==hroot else qroot.count_roots(lroot,hroot)==1); print('last_root_verified',lroot,hroot)
 for seg in c['segments']:
  lo=S(seg['left']);hi=S(seg['right']);mid=(lo+hi)/2
  z=[(a,b,p,q) for a,b,p,q in ps if a<=mid and mid<b];assert len(z)==1,(i,lo,hi)
  a,b,p,q=z[0];coef=list(map(S,seg['coefficients'])); supplied=sp.Poly.from_list(coef,r)
  assert supplied==q,(i,lo,hi,supplied,q)
  assert lo>=a and (hi<=b or b==sp.oo),(i,lo,hi,a,b)
  assert q.degree()<=d['dimension']
 assert c['inner_excess']==str(next(q for a,b,p,q in ps if a<=S(c['r_minus'])<=b).eval(S(c['r_minus'])))
 check(d,d['centers'][i],c['r_minus'],c['r_plus'])
 print('coefficient segments compared',len(c['segments']))
print('PASS wall',time.monotonic()-t,'cpu',time.process_time(),'maxrss',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
