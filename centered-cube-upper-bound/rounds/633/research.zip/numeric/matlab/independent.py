import json,sys
from fractions import Fraction as Q
import sympy as sp
r=sp.Symbol('r')
def S(a):
 v=Q(str(a));return sp.Rational(v.numerator,v.denominator)
def intervals(data,c):
 n=int(data['dimension']); c=list(map(S,c)); src=[( [(S(a),S(b)) for a,b in x['box']],S(x['density'])) for x in data['sources']]
 assert len(c)==n and all(len(box)==n and d>=0 and all(a<b for a,b in box) for box,d in src)
 points=sorted({sp.S.Zero}|{abs(z-c[k]) for box,d in src for k,(a,b) in enumerate(box) for z in (a,b)})
 points=list(points)+[sp.oo];out=[]
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2 if hi!=sp.oo else lo+1
  p=sp.S.Zero
  for box,d in src:
   terms=[]
   for k,(a,b) in enumerate(box):
    lower= a if a>=c[k]-mid else c[k]-r
    upper= b if b<=c[k]+mid else c[k]+r
    if (upper-lower).subs(r,mid)<=0:terms=[];break
    terms.append(upper-lower)
   if terms:p+=d*sp.prod(terms)
  p=sp.Poly(p,r);g=p-sp.Poly((2*r)**n,r)
  assert p.degree()<=n
  out.append((lo,hi,p,g))
 return out

def check(data,c,minus=None,plus=None):
 pieces=intervals(data,c)
 for lo,hi,p,g in pieces:
  print('piece',lo,hi,'mass_coeff_desc',list(p.all_coeffs()),'G_coeff_desc',list(g.all_coeffs()))
 if minus is None:return
 minus=S(minus);plus=S(plus);assert 0<minus<plus
 def get(t):
  return next(g for a,b,p,g in pieces if a<=t and (t<=b or b==sp.oo))
 assert get(minus).eval(minus)>0
 print('minus',minus,'excess',get(minus).eval(minus))
 for lo,hi,p,g in pieces:
  a=max(lo,plus)
  if hi!=sp.oo and a>=hi:continue
  if hi==sp.oo:
   # fixed total mass implies excess strictly decreases for positive radii
   assert p.degree()<=0 and g.eval(a)<=0
   print('tail',a,'G',g.eval(a));continue
  # Sturm isolation of all real roots; rational isolating endpoints include distinct roots.
  roots=sp.polys.polytools.intervals(g,eps=sp.Rational(1,2**30)) if not g.is_zero else []
  ends={a,hi}
  for (l,h),mult in roots:
   if a<l<hi:ends.add(l)
   if a<h<hi:ends.add(h)
  xs=sorted(ends)
  # on gaps no root; inside isolator there is at most one distinct root, so
  # nonpositive endpoints imply nonpositive interior (a multiple root cannot be positive).
  for x in xs: assert g.eval(x)<=0,(a,hi,x,g.eval(x))
  for l,h in zip(xs,xs[1:]):assert g.eval((l+h)/2)<=0,(a,hi,l,h)
  print('capped',a,hi,'roots_isolated',len(roots))
 print('VERIFIED')
if __name__=='__main__':
 d=json.load(open(sys.argv[1])); idx=int(sys.argv[2]);check(d,d['centers'][idx],*(sys.argv[3:5]))
