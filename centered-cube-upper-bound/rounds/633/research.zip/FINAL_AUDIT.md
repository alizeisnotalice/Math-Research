# R633 最终完整总账独审（Sol high）

审核对象：`REPORT.tex` 的完整原输入入口、同一 family/source 的 hard 分支、吸收及声明范围；对照 `/tmp/ccu_r633/selection.md`、`double_receiver_audit.md`、`growth_audit.md`、`joint_cost_audit.md` 及必要的 `growth_bridge.md`。先独立核总账，再对照正式稿；没有重推已独审耦合常数或运行数值，没有修改作者文件/仓库。

**总判定：未发现使最终总账失效的实质数学错误。** 报告明确没有证明根阶上界，没有把双 receiver 暴露、cross marginals、trace/自适应正成本、六倍 halo 或 raw growth 误登记为完整付款。真正缺口仍是同一完整对象上的 `V≤PH_n M` 或可回代的等价严格收缩。下面一处 HS 写法宜直接改清，另有三处可选的量词/端点澄清；均不构成新的证明费用。

## 1. 原 f → 同 family 的 Q：入口成立

固定 a≥32n 后，对每个 x∈K⊂{M_square f>1} 选任意一个严格见证半径 R_x>0，令 B_x=Q(x,R_x/a)。这些开 cube 覆盖 K，有限子覆盖保留原星 A_j=aB_j 及其同一 f 的严格见证 `∫_{A_j}f>d_j`。

对同一 finite family 的非负 packing λ，L_λ≤1（Lebesgue-a.e. 即足够），有

    Q=Σλ_jd_j ≤ Σλ_j∫_{A_j}f =∫fL_λ≤||f||_1.

这里没有把辅助 KKT 来源 μ 当成 f，也不需要转移原 f 的 canonical outer caps 给 μ。删除 v_j=0 的增量只会改变原 receiver 并集一个零测集合，故 `|K|≤V` 仍成立；pointwise 仍覆盖 K 并非删除后的必要结论。报告第2节的预算入口正确。

若未来对任意此类 finite family、全部实际正半径证明 `V≤C H_nQ`，则对每个 compact K 有 `|K|≤C H_n||f||_1`。严格超水平集为开集，Lebesgue 内正则性恢复整个超水平集；再用齐次性恢复任意正阈值。所有半径已经在最初任意见证中允许，没有另一个分尺度求和、截断终端、光滑近似或 canonical endpoint 费用。报告是**条件性恢复**，没有声称所需 finite-family 根阶界已经成立。

## 2. ε、hard 分支及唯一可吸收预算：核验通过

a、H_n 和 ε须在正则 packing/KKT 来源构造前固定。对该同一 family 及该 ε 所产生的同一 Q、M，

    P=(1+1/a)^n, ε=1/(2PH_n), M=Q+εV, R=V/Q,
    β=εV/M=R/(2PH_n+R).

所以 R>6PH_n ⇒ β>3/4。继承合同 κV≤PM 给

    κ≤P(1/R+ε)<1/(6H_n)+1/(2H_n)=2/(3H_n).

最终稿用 H_n≥16/3，因此 κ<1/8，足够同时使用弱 hard-corner 常数及报告所列较强常数。这里没有遗漏 P；a≥32n 又给 P≤exp(1/32)，是维数一致的常数。

若 R≤6PH_n，原 receiver 已由 `V≤6PH_nQ≤6PH_n||f||_1` 支付。若 R>6PH_n，**必须另证明**同对象的新估计 `V≤PH_nM`；一旦成立才可写

    V≤PH_nQ+PH_nεV=PH_nQ+V/2,
    V≤2PH_nQ,

从而排除 hard 分支。报告没有倒置这条逻辑，且明确此估计未证。因此当前不能宣布最终的条件性常数 `6PH_n` 已成为一般上界；报告没有这样宣布。

## 3. 新结构、严格端点与未付项：未发现越界声明

对照已有独审，正式稿仍用同一完整族的真实 increments I_j、同一 λ、同一辅助 L1 来源 μ 和同一 Hall pair；没有将 pair-label 法则当作独立 label 乘积，也没有丢掉 inverse-scale 测试价格。双 receiver 上界和 cross-source 乘积边缘各自的测度范围正确。pair-dependent 分离方向没有被升级为全局正交性。

六倍 halo 的严格坏域属于辅助 μ 自己：j∈G ⇒ m_j≥(3/2)d_j；a≥16n 给 (3/2)e^{-3/8}>1，所以即使 e_j=1/3、a=16n 也严格坏。报告没有把这些 μ-witnesses 当成原 f 的 witnesses，也没有声称所有好标签 halos 两两不交。

Raw growth 的 s_j=m_j/d_j、Σ|T_jI_j|≥(M/Q)V 和真实 overlap 扣除项与同一 Q、M 一致。报告保留完整 overlap 亏损，明确它未付；限制 Hall 支持上的 pairs 不交不能控制完整 family overlap。更换 family 后也不能保留旧 KKT 或丢失 M/Q，报告已有提醒。

端点扩大星 α_jA_j（α_j=s_j^{1/n}）只保证中心平均≥1；选 1≤α'_j<α_j 时因仍包含 A_j 而有严格中心平均>1。有限族下 α'_j↑α_j 时对应扩张增量体积收敛，没有累计尺度费用。**这并不单独证明每个 expanded receiver 点都在坏域**；只有另给中心平移后的包含/平均证明才有那种结论。报告没有使用后一种未证结论，建议在文字中明确区分以防后续误接。

## 4. 建议的小修（没有实质错误）

1. **HS square，`REPORT.tex` 第109–111行。** 现句含“norm … after squaring”，其意可读为正确的平方范数，但建议用无歧义公式直接替换：

       Its squared Hilbert--Schmidt norm is
       \[\|H\|_{HS}^2=\sum_{j,k}w_jw_k
       [\widehat\mu(A_j\cap A_k)-p_jp_k]^2.\]

   这是平方范数，不是范数本身。已有 `joint_cost_audit.md` 的写法正确；trace 下界没有被用于无秩费用的 HS 下界，正式稿也明确 effective rank 未证。

2. **零增量，第21行。** 可补 `discard zero-volume increments, preserving U up to a null set`。这样不会让读者误以为删除后的开族仍 pointwise 覆盖原 compact K。预算只需测度包含，不增费用。

3. **参数先后，第24行与第42行。** 可补一句 `Fix the displayed epsilon before applying the regularized packing construction.` 当前 ε先作为合同参数出现、随后取值，在数学上可以一致解释；这一句可避免把既有 μ 事后调 ε 的误读。

4. **扩大端点，第142–143行。** 建议用 `At the exact endpoint, only a non-strict average at the star's own center is guaranteed; strictly smaller star dilations give strict witnesses at that center.` 不应读成 enlarged receiver union 已全部属于坏域。正式稿后续预算没有依赖该误读。

## 5. 完整费用状态

原 f 的 strict-witness → packing Q 入口、同一 μ 的 hard 分支以及报告所述结构均可保留；一般根阶 `V/M` 预算、完整 overlap/cross-layer source capacity 仍未证明。报告正确保留这一状态。R632 的独立 O(nlog n) 覆盖工具仍可用，本文没有用其参数优化假造根阶收益。

本终审没有重跑历史数值或小公式；计算证据的真实性/范围依赖已附各专项审核，未把浮点 LP 当作有理最优性或任意维数定理。没有发现需要撤回最终数学判断的错误；完成上述写法澄清后可作为“结构已审、完整付款未闭合”的最终报告。

## Root integration after audit
Applied the requested explicit HS squared-norm display, zero-increment null-set qualification, epsilon-before-KKT order, and star-center endpoint qualification. Added the same-source canonical neighbor capture and cross exclusion from growth_audit.md §§6–7, independently accepted by joint_proof_sol. Fixed H>=32 at outset. The final trace/HS soft-weight statement follows by the orthogonal centering contraction explained in joint_transport.md; root checked 0<=K0<=1 and its integral beta*kappa directly. None is asserted to pay V/M. The final source-gap coordinates need not be the original Hall separating coordinates.
