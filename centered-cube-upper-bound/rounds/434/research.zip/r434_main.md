# 第434轮：累计来源熵与保双来源转移；完整余流预算未证

2026-10-20。主代理整合；依赖第413轮原阶段合同、第432轮原路径排斥及第433轮两项静态矩。研究目标仍是同一原测度 \(\Pi_{433}\) 的总量
\[
R_{433}\le\varepsilon X_q+C_\varepsilon\sqrt n\log^A(n+2)W.
\]
本轮没有完成该目标，没有新增付款，也不定义新名字的剩余积分。一般中心立方体极大算子的目标上界仍未证明。本轮有效辅助产出为无阶段数损失的累计熵耗散，以及保留双原来源的真实列预算；两者均有明确但尚未证出的整体比较桥。

## 1. 同一输入、同一原费用

\(f\ge0\) 为完整 \(L^1\) 密度，\(\mu=f\,dx,W=\int f\)。中心 \(A\in E\) 用真实Lebesgue测度，单值边长 \(a\le R_A\le b\le2a\)，\(m_A=\mu(Q_A)=q_AR_A^n,\ q\le q_A\le\lambda\)。设 \(\sigma=q_A dA,\pi_A=c_A\mu/m_A,X_q=\sigma(E),s=1+\sqrt n,S=\beta+C_{\rm col}\)。原带阶段、时钟、首次删除、双保源路径、early、soft、相对秩与风险标记的测度仅允许静态推前
\[
(\Pi_{433})_{A,y,z}\le S\sigma(dA)\pi_A(dy)\pi_A(dz).
\]
此帽不能重建原历史。所有实际质量用完整 \(f\)，不能在截断辅助密度或新辅助父上重新授予历史。

原严格低质量占用 \(Z_A\) 和共同捕获 \(C_A\) 使用 \(m_u<m_A/e^{\sqrt n}\)；原保留 \(Z_A(y)>(4-\epsilon_0)h,C_A(y,z)<h\)，以及双相对秩、原阶段高门和proper排斥。原共同父图 \(G\) 不含此质量门。第433轮已付两个高指标支，当前同时有 \(T_G<C_G/s,T_{\rm loc}<C_{\rm loc}/s\)，且已知
\[
\int T_G\,d(\sigma\pi^2)\le C_GW,\qquad
\int T_{\rm loc}\,d(\sigma\pi^2)\le C_{\rm loc}W.
\]
精确定义及原参数见共同合同和几何附件；没有改动旧阈值。

原阶段密度 \(a_i^e(A,y)\le B_e\) 及新来源增量
\[
\Delta g_i=\min(f,T_i)-\min(f,T_{i-1}),\quad
b_i=\frac{\Delta g_i}{f}(1-s/D_i)_+
\]
不重算。原完整标记作条件平均 \(0\le\theta_i^e\le1\)，得到**精确恒等式**
\[
R_{433}=\sum_i\int\Delta g_i(z)L_i(z)dz,
\quad L_i=(1-s/D_i)_+\sum_e\int\sigma(dA)\frac{c_A(z)}{m_A}
\int\pi_A(dy)a_i^e(A,y)\theta_i^e(A,y,z).
\]
\(L_i\le(D_i-s)_+\)，且 \(D_i\le D_0\) 给
\[
\sum_i\int\Delta g_iD_i\le\int fD_0=2G_0\le SX_q.
\]
这些等式/上界使用原sourcewise合同，不能从一个无标签的总质量帽倒推。

## 2. 已证：所有密度阶段只收一次的熵预算

固定边长 \(a\) 的半开网格，邻接格索引的 \(\ell^\infty\) 距离不超过2，邻接对称、含自身、度至多 \(D=5^n\)。只为辅助分析令 \(g_t=\min(f,t)\)，
\[
m_C(t)=\int_Cg_t,\quad N_C(t)=\sum_{D'\sim C}m_{D'}(t),\quad
\ell_C=\log(N_C/m_C),\quad E(t)=\sum_Cm_C\ell_C.
\]
零质量项置零，\(W_t=\sum_Cm_C\)。Jensen及邻接度给 \(0\le E(t)\le(\log D)W_t\)。这不是对原输入施加密度帽。

几乎处处 \(m'_C=|C\cap\{f>t\}|\)。直接微分并交换邻接有限和：
\[
E'=\sum_Cm'_C\left[\ell_C-1+\sum_{D'\sim C}\frac{m_{D'}}{N_{D'}}\right]
\ge\sum_Cm'_C\phi(\ell_C),\quad \phi(u)=u-1+e^{-u}\ge0.
\]
自身项恰为 \(m_C/N_C=e^{-\ell_C}\)。因此
\[
\int_0^\infty\sum_Cm'_C\phi(\ell_C)dt\le n\log5\,W. \tag{E}
\]
此处的可数和及极限并非形式处理：\(m'_C\le m_C/t,N'_C\le N_C/t\)，故在任意 \([u,v]\subset(0,\infty)\) 上，各导数绝对值总和不超过 \((\log D+2)W/t\)，可交换求导、积分与可数和。\(E(t)\le\log D W_t\to0\) 当 \(t\downarrow0\)，再由非负耗散单调放大积分区间得到(E)。无需 \(L\log L\)。有限阈值终端保留 \(E(T_N)-E(T_0)\)；线性版本同样给 \(\int\sum_Cm'_C\ell_C\le(1+n\log5)W\)。

按原 \(\Delta g_i\) 平均(E)定义分数 \(\eta_i(z)\)，完整公式见主证明附件。于是 \(\sum_i\int\Delta g_i\eta_i\le n\log5W\)。阶段数任意，仍只收一次。这是本轮新的辅助估计，不能直接替代 \(L_i\)。

## 3. 未证：从累计熵到完整原交通的桥

一种足够但未证明的整体比较是
\[
\sum_i\int\Delta g_iL_i
\le\alpha\sum_i\int\Delta g_iD_i+
\frac{C_\alpha}{s}\sum_i\int\Delta g_i\eta_i+C_\alpha sW. \tag{M}
\]
若(M)成立，才可推出 \(R_{433}\le\alpha SX_q+C_\alpha(s+n\log5/s)W\)。目前没有证明原负载的父、旧来源、阶段占用及全部历史能被这一辅助熵耗散控制。不能以右端可支付来证明(M)，也不能用 \(g_t\) 重建父质量来填补它。

互补方向保留完整来源，定义小质量父的exclusive比例 \(b_A=(Z_A-C_A)/Z_A\)，原支撑上 \(b_A>c_*=1-1/(4-\epsilon_0)\)。其实际归一跨界容量 \(E_{\rm ex}\) 给 \(R_{433}\le S E_{\rm ex}/c_*\)，但当前仅能证 \(E_{\rm ex}\le\min(X_q,rA_nW/\theta_y)\)。附件给全来源Tonelli恒等式；没有得到所需根阶改进。它与(M)是研究候选，不能把各自不相容的上放拼为一个证明。

## 4. 已证：保双原来源转移列预算；未证其进展率

令
\[
C_2(y,z)=\int_E q_Bc_B(y)c_B(z)m_B^{-2}dB,\quad
\mathcal R_{y,z}(dB)=q_Bc_B(y)c_B(z)dB/(m_B^2 C_2(y,z)).
\]
零共同父边缘不承载原流。把 \(B\) 追加为辅助标签、保留完整原记录，由Tonelli有
\[
\widetilde\Pi_{B,y,z}\le S\sigma(dB)\pi_B(dy)\pi_B(dz).
\]
对第433轮两个静态高指标的并集 \(\mathcal H\)，令 \(p_{\mathcal H}(y,z)=\mathcal R_{y,z}(\mathcal H)\)，两项矩给
\[
\int p_{\mathcal H}\,d\Pi_{433}\le2SsW. \tag{B}
\]
尚缺的是维数一致的平均下界 \(\int p_{\mathcal H}\,d\Pi_{433}\ge c R_{433}\)，或带可吸收误差的替代下界。原单源高秩/低共同捕获并不已经提供该下界。固定来源对重复抽父是同一条件投影；不产生免费收缩。辅助父无需原历史即可使用静态矩，但任何重启原路径的操作都必须另证历史合同。

## 5. 完整账保持不变

本轮不增减第433轮任何已付项。保留
\[
G_0\le16\widehat F(R_{433}+C_{433}X_q+V_{433}W),
\]
\[
B_H\le32\widehat F R_{433}+(E_{387}+32\widehat F C_{433})X_q+
(S_{390}+8s+32\widehat F V_{433})W.
\]
原入口仍为
\[
\Lambda\{8\lambda HW+2d_{\rm eff}A_{\rm entrance,n}W_\nu/H+64\widehat F R_{433}
+(2E_{387}+64\widehat F C_{433})X_q+(2S_{390}+16s+64\widehat F V_{433})W\},
\]
其中 \(\widehat F=(1-32\delta-16\eta)^{-1},\Lambda=128/119\)。只有真正证明 \(R_{433}\le\varepsilon X_q+P_\varepsilon W\)，才可新增 \(64\Lambda\widehat F\varepsilon X_q+64\Lambda\widehat F P_\varepsilon W\)。全局吸收余额、全尺度复用、初始/删除/跳跃/终端和极限要求仍需各自验证；本轮未认证其闭合。

## 6. 计算、协作与复现范围

本轮使用1 Astra high几何、4 Sol high（主证明、互补、连接、独审）及1 Sol medium数值；没有独立Luna任务，未启动。实际模型扣额数据不可得，不估算成本比例。使用已加载数学工具技能D04和L03区分条件核、完整来源与证书边界；正文证明为直接推导，不把技能标题当外部定理。

本机Python实际运行五个有界脚本：主证明9连续格模型、32导数slab、9匹配场；几何3正体积场1935项Fraction断言；连接9 early/late代数例、352层边界例；数值显式5709来源对、5容量尺度和7维数扩展及n=64/256变量尺度诊断；互补5高维参数用70位Decimal诊断。详细输出和证书随包。互补Decimal是高精度浮点，不是区间认证。Fraction及有理区间结果只认证其明确有限模型。

fixed-side星形诊断缺原严格路径/高秩；variable-side核心对明确有 \(C_A=Z_A>h\)，违反低共同捕获soft；都不是完整原余流的反例或闭合证据。诊断结果要求下一步保持原高秩与低共同捕获的联合条件，避免仅依赖support邻域大小。

解压后依次运行 `python3 r434_proof_check.py`、`python3 r434_geometry_check.py`、`python3 r434_bridge_check.py`、`python3 r434_numeric.py`、`python3 r434_complement_check.py`。只需标准库；数值证书写入脚本目录。本轮没有安装新数学包，也没有运行MATLAB或编译PDF。附详细LaTeX源和独审报告。后续核心工作仍是(M)或另一个保持原联合条件的完整积分比较，不能把(B)或(E)单独当作全局成果。
