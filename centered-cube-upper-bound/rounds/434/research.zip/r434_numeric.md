# R434 有限原生数值／有理证书

## 范围、环境、可判别命题

仅诊断完整低指标交集的跨父转移缺桥，不认证原Π433、不付款全余。
已发现系统Python3.14.6、bundle Python3.12.14+numpy；scipy/sympy/flint均未发现。本任务只用stdlib Fraction即可，未安装包。实际运行`python3 /tmp/r434_numeric.py`，输出`/tmp/r434_numeric_run.txt`、机器证书`/tmp/r434_numeric_certificate.json`。指数、对数、平方根采用解析向外有理区间；显示小数仅便读。未使用浮点接受门槛。

准确可判别命题：

1. 仅由低T_G、低T_loc和support邻域U的膨胀，能否推出实际Bayes父转移外逃概率统一正下界？不能；下述fixed-side族给e,e2→0。
2. 若把外逃转移强行归一化成保守转移到实际外部父，能否仍保维数/场一致的Cσ列帽？不能；一个固定n=2正体积模型已令必要C→∞。
3. 原生variable-side场是否可同时具有高J/h、active质量门、双低指标及正外逃？可以；下述独立族给这四者的实际计算，证明它并非单纯fixed-side低rank假象。但原history是否给uniform外逃下界／收缩是未证缺桥。

需要作者进一步给出的可判别命题，是作用在原带history限制上的明确kernel以及拟议下界，例如`e(A,y,z)≥c`（或允许低e支用eps X+CW支付的明确不等式），而不是仅要求“外部父足够多”。本文不声称排除一切W预算或一切其他kernel。

## 1. 完整f和正体积star

n≥2，N=2^n，η=n/N，w=1/(100n)，h=.01，δ=h/scale。
f是N+1个互不相交的均匀source立方体密度之和：core中心0、边长w、质量1；每个sign向量v∈{±1}^n的leaf中心(3/4)v、边长w、质量η。
主父中心块E0=[-h,h]^n；leaf父块Ev=(3/8)v+[-δ,δ]^n；所有实际边长R=1。

源包全体点和父块全体点满足严格捕获／排斥边距：主父仅捕获core；leaf父仅捕获core和对应leaf。故完整匹配m0=q0=1，mv=qv=1+η（可取q=1、λ=1.5），不是任意声明的关联矩阵。

G正体积共同父关系为star加对角线。精确

`Ucore=1+n, Uleaf=1+η, V1(y)=1+n (y在core)`。

对主父任意core/core源，d1≤nw=.01，故

`T_G,T_loc≤exp(.01)/(1+n)<1/(1+√n)`。

这给完整两低指标交集的实际正测度子流。其质量为σ(E0)=(2h)^n。所有其他父质量≤1.5<exp(√n)，所以不提供strict-K质量增长。更强地，没有active严格K质量下降，原高rank路径根本没有实现。

令v0=(2h)^n，vδ=(2δ)^n。对任意core源x，合同单源Bayes核给

`L(x)=v0+Nvδ`, `J(x)=v0+Nvδ/(1+η)`,

`e= Nvδη / [(v0+Nvδ)(1+η)]`。

保持一对core来源时

`C2=v0+Nvδ/(1+η)`,

`e2= Nvδη / [(1+η)^2 C2]`。

因此G/U不变而e,e2→0。n=2，scale=2,10,100,1000,10000时，实际e依次为.16667,.012821,.00013328,.00000133333,.0000000133333；双源e2更小。J/h≪1（eps0≤1）。这不能叫原Π压力测试。

若转移全部主父core/core静态流至捕获外部leaf的父，目标总σ容量为Nvδ(1+η)，故任何列帽`incoming≤Cσ`必须

`C ≥ v0/[Nvδ(1+η)] = (scale/2)^n/(1+η)`。

固定n=2便无统一C。实际Bayes列帽自身完全成立；失败的是把其微小外逃行质量归一化后仍期望统一列帽。这个区分避免把support-degree反例误说成Bayes核反例。

实际有限测试：n=2…6显式坐标生成G并检查5709个source对；固定n=2只压测5个scale；n=2,4,8,12,16,32,64用解析公式延伸。没有原历史搜索，没有无目的counterexample扫描。

## 2. 独立variable-side高占用原生族

取n=64或256，t=1/(100n)，完整f=1于[-2,2]^n，E=[-1+t,1-t]^n，

`R_B=max(1,2||B||∞+2t)`。

则1≤R_B≤2，Q_B完全位于f支撑，m_B=R_B^n且全q_B=1。每个x∈[-t,t]^n被所有Q_B捕获，这是正source体积集。中心R子水平集体积为(r-2t)^n，1≤r≤2。因此

`J_x=(1-2t)^n + ∫_1^2 n(r-2t)^(n-1)/r^n dr`。

记a0=(1-2t)^n，有严格解析包围

`a0(1+n log2) ≤ J_x ≤ 1+n log2`。

eps0=1/2，h=(1+√n)/eps0。任意R_v≥1.99的outer父，其原生active集合至少有

`Z_v ≥ a0[1+n log1.99-√n]`，

因为m_u<m_v/exp(√n)等价R_u<R_v exp(-1/√n)，严格边界为Lebesgue零。实际执行结果：

|n|J包围|J/h下界|Zouter下界|h|
|--|--|--|--|--|
|64|[44.46306,45.36142]|2.47017|36.30705|18|
|256|[174.91208,178.44568]|5.14447|157.97111|34|

且n log1.99>2√n，所以从side1初始记录至outer父的完整initial mass门数值可满足。这里只说明存在质量级差，未生成原两条path或阶段。

对core内y,z，G邻域并集完整填满[-2+t,2-t]^n（每个sign角父的邻域以正中心测度覆盖对应象限内部），故U=(4-2t)^n。任意父的m=R^n，且V_R(y)≥(2R-t)^n。于是对core/core：

`T_G,T_loc ≤ exp(.02)/(2-t)^n`。

运行有理证书的双低指标上界为5.55825e-20(n64)、8.85479e-78(n256)，远低于1/(1+√n)。

实际外逃量也可给下界，而非只报U。对central side1父A，由体积|Q_A|=1，R_B≥1.5时π_B(Q_A^c)≥1-(2/3)^n，因此

`e_A ≥ [1-(2/3)^n] a0 n log(4/3)/(1+n log2)`，

数值为.3978495(n64)、.4045390(n256)。

更关键的是同一highrank outer父也有正外逃：令ζ=.005，取正体积角cap A_i∈[1-t-ζ,1-t]，则R_A≥1.99；Q_A第一坐标下界≥-t-ζ。对B1≤0，均匀source有π_B(Q_A^c)≥1/2-t-ζ。单core Bayes父权为R_B^{-n}dB，双core后验父权为R_B^{-2n}dB，都对B1正负对称，所以同一active角cap上

`e_A,e2_A ≥ 1/4-(t+ζ)/2`，

分别为.247421875(n64)、.24748046875(n256)。这些是同一原生field内的解析积分下界，未用随机模拟。

## 3. 不能越过的证明边界

star族提示：仅低指标和G/U support信息不能保证actual转移收缩。variable-side族提示：高J/h、strict质量active门与低指标并不矛盾，而且某些原生field确有足够actual外逃。这两族合起来辨别出下一桥梁必须利用高占用／variable尺度与原history，而不是重复已付款静态矩。

variable-side族尚未验证所有proper目标的R432实际near排斥、exact-j终端门、两固定source的全路径、first deletion、soft、relative-rank、双远来源、early标签及原sourcewise帽。没有把新增第三source赋予旧history。因此既不是原Π433反例，也不是R433收缩定理；不证明整体closure、W费用可和或原母账X系数可吸收。

补充明确失败门：variable-side族的core/core来源被所有实际父捕获，故在任何active子父集合上，原共同捕获量与单源active量完全相同，即C_A(y,z)=Z_A(y)>h。因而它明确违反原“低共同捕获soft”门；这不只是history尚未实现。两静态低指标T_G、T_loc通过不能替代原低共同捕获soft。这一族只支持actual Bayes外逃与高J共存的诊断。
