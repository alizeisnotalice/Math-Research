from fractions import Fraction as F
from math import log, sqrt, ceil
cases=0
for den in [16,32,128]:
 d=F(1,den)
 for tj in [40,60,80]:
  f=F(100); s=F(5); D=F(20); gate=1-s/D
  cuts=[F(0),F(tj,2),F(tj)]
  b=[(cuts[i]-cuts[i-1])*gate/f for i in [1,2]]
  late=[max(F(0),cuts[i]-max(cuts[i-1],(1-d)*tj))*gate/f for i in [1,2]]
  early=[bi-li for bi,li in zip(b,late)]
  assert sum(b)<=1 and 0<=sum(late)<=d
  assert sum(early)+sum(late)==sum(b)
  assert sum(early)==(1-d)*tj*gate/f
  # identical normalized receiver laws before first deletion have zero Hellinger cost
  assert F(1,3)+F(2,3)==1
  cases+=1
la=F(128,119); delta=F(1,256); eta=F(1,128)
fh=1/(1-32*delta-16*eta)
assert fh==F(4,3)
coef=64*la*fh
assert coef==F(32768,357)
# Occupancy layer decomposition: each original D>s lies in exactly one strict-left layer.
layer_cases=0
for upper in [2,3,8,16,64]:
 for d in [F(j,4) for j in range(5,upper*4+1)]:
  k=0
  while not (2**k<d<=2**(k+1)): k+=1
  assert k<max(1,ceil(log(upper,2)))
  layer_cases+=1
print(f'PASS: {cases} exact scalar early/late dynamic algebra cases')
print(f'PASS: {layer_cases} exact occupancy-layer boundary cases')
print(f'PASS: mother-account factor Fhat={fh}; new X/W multiplier={coef}')
print('Scope: algebra and parameter checks only; no full Lebesgue receiver/history construction, no proof of R433 bound.')
