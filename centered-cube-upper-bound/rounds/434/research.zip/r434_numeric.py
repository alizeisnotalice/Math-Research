"""Native full-f star field. Does NOT implement original stage/path history.
Only stdlib; rational outward intervals certify displayed inequalities.
Run: python3 r434_numeric.py
"""
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json
from pathlib import Path

OUTPUT_DIR = Path(__file__).resolve().parent
CERTIFICATE_PATH = OUTPUT_DIR / "r434_numeric_certificate.json"

def exp_bounds(x, N=60):
    assert 0 <= x < N
    t = s = F(1)
    for k in range(1,N+1):
        t *= x/k; s += t
    first=t*x/(N+1)
    return s, s+first/(1-x/(N+2))

def sqrt_bounds(n, bits=100):
    d=2**bits; k=isqrt(n*d*d)
    return F(k,d),F(k+1,d)

def model(n,scale):
    w=F(1,100*n); h=F(1,100); delta=h/scale
    L=2**n; eta=F(n,L)
    # Every point of every source packet is captured/excluded uniformly.
    assert h+w/2 < F(1,2)             # main captures core
    assert F(3,4)-h-w/2 > F(1,2)    # main excludes all leaves
    assert F(3,8)+delta+w/2 < F(1,2) # satellite captures core and own leaf
    assert F(9,8)-delta-w/2 > F(1,2) # satellite excludes opposite leaf
    assert F(3,4)+w < 1              # core local R-neighborhood captures all
    assert F(3,2)-w > 1              # leaf local R-neighborhood excludes others
    assert delta+h < F(3,8)          # father blocks disjoint
    Ucore=1+L*eta; Uleaf=1+eta
    elo,ehi=exp_bounds(n*w)
    slo,shi=sqrt_bounds(n)
    low=ehi*(1+shi)<Ucore
    # All external fathers lack strict-K mass growth, K=exp(sqrt(n)).
    Klo=exp_bounds(slo)[0]
    assert Uleaf<Klo
    Xmain=(2*h)**n
    Xsat=L*(2*delta)**n*(1+eta)
    lower=Xmain/Xsat
    return {'n':n,'scale':scale,'leaf_count':L,'eta':str(eta),
            'Ucore':str(Ucore),'Uleaf':str(Uleaf),'low_intersection':low,
            'TG_and_Tloc_uniform_upper':float(ehi/Ucore),
            'threshold_lower':float(1/(1+shi)),
            'sat_parent_mass_ratio':float(Uleaf),
            'strict_K_lower':float(Klo),
            'column_constant_lower_bound':str(lower),
            'column_constant_lower_bound_float':float(lower)}

# Stage 1: explicitly construct incidence from coordinates, not declared graphs.
checks=0
for n in [2,3,4,5,6]:
    vs=list(product([-1,1],repeat=n)); zero=(0,)*n
    src=[zero]+[tuple(F(3,4)*v for v in a) for a in vs]
    father=[zero]+[tuple(F(3,8)*v for v in a) for a in vs]
    w=F(1,100*n); h=F(1,100); delta=h/10
    caps=[]
    for p,a in enumerate(father):
        rad=h if p==0 else delta
        cap=[]
        for j,y in enumerate(src):
            ds=[abs(ai-yi) for ai,yi in zip(a,y)]
            inside=all(d+rad+w/2<F(1,2) for d in ds)
            outside=any(d-rad-w/2>F(1,2) for d in ds)
            assert inside or outside
            if inside: cap.append(j)
        assert cap==([0] if p==0 else [0,p])
        caps.append(cap)
    # Common center measure positive exactly for the star plus diagonal.
    for i in range(len(src)):
        for j in range(len(src)):
            common=sum(((2*(h if p==0 else delta))**n for p,c in enumerate(caps)
                        if i in c and j in c),F(0))
            assert (common>0)==(i==0 or j==0 or i==j)
            checks+=1
print('Stage 1 PASS: coordinate-derived positive-volume G and complete f matching;', checks,'pair checks')
# Stage 2: stress the specific column-capacity obstruction in fixed dimension.
fixed=[model(2,s) for s in [2,10,100,1000,10000]]
assert all(x['low_intersection'] for x in fixed)
assert all(F(b['column_constant_lower_bound'])>F(a['column_constant_lower_bound'])
           for a,b in zip(fixed,fixed[1:]))
print('Stage 2 PASS: fixed n=2, U/V and low intersection fixed as satellite center volume shrinks')
# Stage 3: dimension extension using exact formulas, not exponential enumeration.
expanded=[model(n,100) for n in [2,4,8,12,16,32,64]]
assert all(x['low_intersection'] for x in expanded)
print('Stage 3 PASS: n=2,4,8,12,16,32,64; strict-K gain absent in every external parent')
report={'environment':'Python stdlib Fraction; no numerical package installation',
        'original_history_implemented':False,'coordinate_pair_checks':checks,
        'fixed_dimension_stress':fixed,'dimension_extension':expanded,
        'scope':'Static full-f sufficient enlargement only; not original Pi433 counterexample or global closure.'}
CERTIFICATE_PATH.write_text(json.dumps(report,indent=2)+'\n')
print('Certificate:', CERTIFICATE_PATH.name)
for x in expanded:
    print('n=',x['n'],'low upper=',x['TG_and_Tloc_uniform_upper'],
          'threshold lower=',x['threshold_lower'],'parent ratio=',x['sat_parent_mass_ratio'],
          'column C >=',x['column_constant_lower_bound_float'])

# Actual Bayes columns retain center volume; both single/double core sources.
bayes=[]
for scale in [2,10,100,1000,10000]:
    n=2; N=2**n; eta=F(n,N); h=F(1,100); delta=h/scale
    v0=(2*h)**n; vd=(2*delta)**n
    L=v0+N*vd; C2=v0+N*vd/(1+eta)
    e=N*vd*eta/((1+eta)*L)
    e2=N*vd*eta/((1+eta)**2*C2)
    J=v0+N*vd/(1+eta)
    bayes.append(dict(scale=scale,L=str(L),C2=str(C2),e=str(e),e2=str(e2),
                      J=str(J),J_over_h_upper_eps_le_1=float(J/(1+sqrt_bounds(n)[0]))))
print('Bayes single/double external escape:',[(r['scale'],float(F(r['e'])),float(F(r['e2']))) for r in bayes])

def log_bounds(x,N=150):
    assert 1<=x<=2
    z=(x-1)/(x+1)
    lo=sum((2*z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
    return lo,lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))

# Separate native variable-side diagnostic: uniform f=1 on [-2,2]^n.
# E=[-1+t,1-t]^n, R_B=max(1,2||B||inf+2t); q_B=1 exactly.
# Every x in [-t,t]^n lies in every Q_B. This is positive source volume.
# Center sublevel volume |{R_B<=r}|=(r-2t)^n, 1<=r<=2.
# Thus rho_x weighted shell measure n(r-2t)^(n-1)/r^n dr.
# Bounds below are analytic rational enclosures, not Monte Carlo.
variable=[]
for n in [64,256]:
    t=F(1,100*n); eps0=F(1,2)
    factor=(1-2*t)**n
    l2,u2=log_bounds(F(2)); l199,u199=log_bounds(F(199,100))
    l43,u43=log_bounds(F(4,3)); slo,shi=sqrt_bounds(n)
    Jlo=factor*(1+n*l2); Jhi=1+n*u2
    # At all positive-volume outer fathers R_v>=1.99, rho{m_u<m_v/K}.
    Zlo=factor*(1+n*l199-shi)
    hhi=(1+shi)/eps0
    assert Zlo>hhi
    assert n*l199>2*shi # possible original initial mass ratio to side-1 record
    # For any central side-1 father A, its cube volume is 1. Therefore
    # pi_B(Q_A^c)>=1-(3/2)^(-n) whenever R_B>=3/2.
    elo=(1-F(2,3)**n)*factor*n*l43/Jhi
    assert 0<elo<1
    # For any top A, y,z in core, U=(4-2t)^n and m_A<=2^n.
    # Uniform full-packet double-low certificate at actual R_A>=1.
    TGhi=F(2,4-2*t)**n*exp_bounds(2*n*t)[1]
    assert TGhi*(1+shi)<1
    variable.append(dict(n=n,t=str(t),q=1,R_range=[1,2],eps0=str(eps0),
                         J_lower=float(Jlo),J_upper=float(Jhi),
                         J_over_h_lower=float(Jlo/hhi),
                         Z_outer_lower=float(Zlo),h_upper=float(hhi),
                         central_parent_e_lower=float(elo),outer_core_TG_upper=float(TGhi),
                         scope='Native high occupancy and active mass gate only; no actual-near exclusion, terminal/history/soft/sourcewise flags implemented.'))
print('Variable-side diagnostic:',variable)
report.update(actual_Bayes=bayes,variable_side_diagnostic=variable)
CERTIFICATE_PATH.write_text(json.dumps(report,indent=2)+'\n')
# On a positive-volume outer corner cap A_i in [1-t-zeta,1-t],
# R_A>=1.99 and Q_A's first lower face >=-t-zeta.
# For every B with B_1<=0, pi_B(Q_A^c)>=1/2-t-zeta.
# Both single/core-core Bayes parent weights are radial, so half their mass
# has B_1<=0. Hence both e,e2 >= 1/4-(t+zeta)/2 on the SAME active fathers.
for row in variable:
    t=F(row['t']); zeta=F(1,200)
    row['outer_corner_e_and_e2_lower']=str(F(1,4)-(t+zeta)/2)
    assert F(row['outer_corner_e_and_e2_lower'])>F(24,100)
report['variable_side_diagnostic']=variable
CERTIFICATE_PATH.write_text(json.dumps(report,indent=2)+'\n')
print('Same-highrank-corner escape bounds:',[(r['n'],float(F(r['outer_corner_e_and_e2_lower']))) for r in variable])
for row in variable:
    row['original_low_common_capture_soft_passes']=False
    row['soft_failure_reason']='Both core sources are captured by every father; C_A(y,z)=Z_A(y)>h on active outer fathers.'
report['variable_side_diagnostic']=variable
CERTIFICATE_PATH.write_text(json.dumps(report,indent=2)+'\n')
