from fractions import Fraction as F
from itertools import product

def log_bounds(x, terms=120):
    assert x > 0
    if x < 1:
        a,b=log_bounds(1/x,terms); return -b,-a
    k=0
    while x>2: x/=2; k+=1
    z=(x-1)/(x+1); p=z; lo=F(0)
    for j in range(terms):
        lo+=2*p/F(2*j+1); p*=z*z
    hi=lo+2*p/(F(2*terms+1)*(1-z*z))
    if k:
        a,b=log_bounds(F(2),terms);lo+=k*a;hi+=k*b
    return lo,hi

def evaluate(expr,constant=F(0)):
    lo=hi=constant
    for x,c in expr.items():
        if c==0:continue
        a,b=log_bounds(x)
        if c<0:a,b=b,a
        lo+=c*a;hi+=c*b
    return lo,hi

def add(expr,x,c):
    if x and c:expr[x]=expr.get(x,F(0))+c

def primitive_log(expr,A,B,t,sign):
    # Integral log(A t+B) dt, log0 handled by x log x -> 0.
    x=A*t+B
    if A:
        add(expr,x,sign*x/A)
        return -sign*x/A
    add(expr,B,sign*t)
    return F(0)

cases=[
 [(1,{(0,):F(1)}),(1,{(0,):F(1),(1,):F(2)}),(2,{(0,0):F(1),(1,0):F(3)})],
 [(1,{(-3,):F(1,20),(0,):F(20),(2,):F(2)}),(2,{(0,0):F(1,100),(2,2):F(100),(3,0):F(2)}),(3,{(0,0,0):F(1),(2,2,2):F(7),(4,0,0):F(3)})],
 [(1,{(i,):F((i+5)**2,3) for i in range(-4,5)}),(2,{x:F(1+sum(x),7) for x in product(range(3),repeat=2)}),(3,{x:F(1+sum(x),5) for x in product(range(2),repeat=3)})]
]
counts={'finite_entropy':0,'derivative_slabs':0,'native_match':0}
for batch in cases:
 for n,values in batch:
    neighbors={c:[d for d in values if max(abs(x-y) for x,y in zip(c,d))<=2] for c in values}
    W=sum(values.values()); E={};I={};constant=F(0)
    for c,m in values.items():add(E,sum(values[d] for d in neighbors[c])/m,m)
    thresholds=sorted({F(0),*values.values()})
    for left,right in zip(thresholds,thresholds[1:]):
        t=(left+right)/2
        m={c:min(v,t) for c,v in values.items()}
        N={c:sum(m[d] for d in neighbors[c]) for c in values}
        active=[c for c,v in values.items() if v>t]
        # E' - sum m' phi(log N/m) is an exactly nonnegative rational.
        restoration=sum(m[c]*sum(d in active for d in neighbors[c])/N[c] for c in values)
        selfpart=sum(m[c]/N[c] for c in active)
        assert restoration>=selfpart
        counts['derivative_slabs']+=1
        for c in active:
            A=F(sum(d in active for d in neighbors[c]))
            B=sum(values[d] for d in neighbors[c] if d not in active)
            constant+=primitive_log(I,A,B,right,1)+primitive_log(I,A,B,left,-1)
            constant+=primitive_log(I,F(1),F(0),right,-1)+primitive_log(I,F(1),F(0),left,1)
    elo,ehi=evaluate(E);ilo,ihi=evaluate(I,constant)
    log5lo,_=log_bounds(F(5))
    assert elo>=0 and ehi<=n*W*log5lo
    assert ilo>=0 and ihi<=elo+W
    # Actual constant-side receiver centers in the middle quarter of one cell;
    # Q_A has side 1/2, remains in that cell, hence true q equals its density.
    c=next(iter(values));density=values[c]; R=F(1,2)
    mass=density*R**n
    assert mass/R**n==density
    assert all(F(k)+F(3,8)-R/2>=k and F(k)+F(5,8)+R/2<=k+1 for k in c)
    counts['native_match']+=1; counts['finite_entropy']+=1
print('PASS',counts)
# One exact continuous-center occupancy check, not the qualified original cascade.
# f=1_[0,1], E=[1/4,3/4], R=1/2, q=1. D(z)=2 min(z,1-z).
s=F(1,8);weights=[F(1),F(3,4),F(1,2)];thresholds=[F(0),F(1,4),F(3,4),F(1)]
switch=F(0)
for i,k in enumerate(weights):
    switch+=(thresholds[i+1]-thresholds[i])*(k-s)**2/(2*k)
assert switch>0
print('Native monotone-occupation diagnostic: switching=',switch,'; isolated-cell entropy forcing=0.')
print('This is not an original early/history/relative-rank realization and not a counterexample to R434.')
print('All checks use Fraction logarithm bounds; no unrun statistical or general-root claim.')
