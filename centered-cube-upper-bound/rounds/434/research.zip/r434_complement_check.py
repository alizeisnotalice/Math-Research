from decimal import Decimal, localcontext
import json

# Native uniform-density fan has exact one-dimensional radial integral.
# Decimal values diagnose the stated elementary lower bounds; not interval certification.
rows=[]
with localcontext() as c:
 c.prec=70
 for n in [4096,16384,65536,262144,1048576]:
  N=Decimal(n); ell=N.sqrt(); s=1+ell
  delta=N**-3; tau=4*delta; a=Decimal('0.5')
  rmax=(-4/ell).exp()
  # t in [a,rmax-delta], R=t+delta.
  # (t/(t+delta))^n >= (a/(a+delta))^n.
  lower=(N/2)*(a/(a+delta))**n*((rmax-delta)/a).ln()
  h=2*s
  rank_gate=Decimal('3.5')*h
  dmax=1-8*delta+N*delta
  cg=1+2*N*Decimal(2).ln()
  cloc=cg+2*N*Decimal(5).ln()
  eta=(s/(1+ell/2)**2).ln()/N
  eta=eta.exp()
  near_floor=1-9*delta
  # Uniform on [-2,2]^n covers every R<=1 cube from E.
  # Fans have u_1 >= 1/2-tau. Opposite source x_1 <= -1/2+tau+delta/2.
  min_gap=1-2*tau-rmax/2-delta/2
  assert rmax-delta>a
  assert lower>rank_gate
  assert min_gap>0
  assert near_floor>eta
  assert dmax.exp()<cg/s
  assert dmax.exp()<cloc/s
  rows.append(dict(n=n,rank_lower=str(lower),rank_gate=str(rank_gate),h=str(h),
       TG_upper=str(dmax.exp()),CG_over_s=str(cg/s),near_floor=str(near_floor),eta_upper=str(eta),exclusive_gap=str(min_gap),
       source_pair_log10_upper=str(Decimal(2).log10()+2*N*delta.log10()),
       parent_pair_over_W_log10_upper=str(Decimal(2).log10()+3*N*delta.log10()-N*Decimal(4).log10())))
print(json.dumps({'rows':rows,'scope':'Floating high-precision evaluation of analytic lower bounds; not interval arithmetic and not full original-history certification.'},indent=2))
