# R434共同目标与任务边界

唯一成功目标：对同一个原Π433的总量R433证明R433≤εX_q+Cε√n log^A(n+2)W（固定A及受控ε依赖），或构造真实剩余测度递推R_k≤θR_{k+1}+c_k W+ε_k X，θ<1维数一致、费用可和、终端受控。单独又付某个高指标支、换名或反例扫描不算本轮主目标完成。

已完成至R433 commit97808a6，repo /Users/zhengzhihao/Math-Research-centered-cube-work，主稿/tmp/r433_main.md（先只读§1、4目标）；几何/局部矩证明各/tmp/r433_geometry.md、joint.md。R432主稿/tmp/r432_main.md有exact-j和原R432门。只读职责所需片段，不通读完整历史。

f≥0完整L1,W=∫f；真实Lebesgue中心A及single-valued R_A∈[a,b],b≤2a，Q_A中心cube,m_A=f(Q_A)=q_AR_A^n,q≤q_A≤λ,r固定。σ=q_A dA,π_A=f c_A/m_A,X_q=∫σ。原余流Π433带原old/new sources y,z、阶段、时钟、firstdeletion、soft、两条固定source路径；它不是任意σπ²子流。允许原静态推前≤Sσπ²，一次S=β+Ccol。具体来源：R413原a_i^e≤B_e与Σb_i(z)≤1，所有生成核初始subprob、未来权≤1。静态帽不是原历史的完整定义。

新约束：G(y,z)=1{∫E cAy cAz dA>0}, U(y)=∫f(z)G(y,z)dz；V_R(y)=f(y+[-R,R]^n),d=||y-z||1；T_G=m_A exp(d/RA)/√UyUz<C_G/s，C_G=1+2nlog(b/a)；T_loc=m_A exp(d/RA)/max(V_RA(y),V_RA(z))<C_loc/s，C_loc=C_G+2nlog5 (b>a),b=a时1，s=1+√n。已有静态矩∫σπ² T_G≤C_G W，∫σπ² Tloc≤ClocW；两支旧已付款不退款。

原两路径固定source x，strict K=e^√n质量下降，active Z_v(x)=ρ_x{m_u<m_v/K}>h,s/(ε0q)=h，首次Z≤h停。ρ_x=c_v(x)dv/mv，J≤An/q,An=1+nlog(b/a)，完整原初始mA>K²m_v0；proper所有目标满足R432实际near排斥2||A-u||∞/RA>[s(qA/qu)/(1+.5log(mA/(K^(j+2)mu)))²]^(1/n)。原终端Hmass=max(κ_jmw,κ_kmu),mA>e^√nHmass，κ_j=(e²Σ_{l=0}^j e^l)^√n。原低风险/低强度、relative-rank、低共同捕获soft、双远来源、early历史仍保留。原未过滤生成路径给定initial record独立，保future后不能假定独立。

允许工具：R433两静态矩；R432actual-center profilecap；原sourcewise帽；原exact-j terminal kernel≤a_jρ_x|Z≤h/h，Σa_j=Θ(M)=O(logn)，ρ_x{Z≤h}≤(1+eps0)h；active累积Ψ=O(log²n)。若研究更早历史必须按需从repo rounds ZIP读取对应md，不要凭名称补造接口。

已知障碍：U≥mA仅a.e，U−mA=实际其他父捕获的外部source，不能保证其他父更重或有当前历史；几何近parent排斥不表示f边界mass小；新增第三source可π_A抽取但无旧历史；局部质量可高度集中；动态原b_i与占用D_i不能重建；两静态低指标没有已证固定比例收缩。若用上放为更大static对象，必须标注这是充分但可能更强目标，不能当等价。

每任务交付：准确命题及使用合同，完整推导或最小缺桥，实际可重复本机证据及其范围，不写未运行测试。证明/反例类型明确。只写指定/tmp/r434_ROLE*，不改repo不新开subagent；不是独占文件系统，不动别人文件。交付即停等任务。最终主代理负责合并、独审、精简每轮提交推送，不编译PDF。

当前完整母账见r433_main§4，新增X系数必须回代64ΛFhat，未经余额核验不得称可吸收。完整目标仍包括全尺度/原子/限，局部证明不得充当一般闭合。
