from fractions import Fraction as F
from itertools import product

# Actual native block fields from r434_numeric.md: n=2, R=1.
# Packet masses and center-block volumes are integrated exactly.
checks=0
cases=0
for scale in (2,10,100):
    n=2
    signs=list(product((-1,1),repeat=n))
    masses=[F(1)]+[F(n,2**n)]*len(signs)
    h=F(1,100)
    volumes=[(2*h)**n]+[(2*h/scale)**n]*len(signs)
    cap=[{0}]+[{0,j+1} for j in range(len(signs))]
    m=[sum(masses[x] for x in c) for c in cap]
    sigma=[volumes[a]*m[a] for a in range(len(cap))]
    pi=[[masses[x]/m[a] if x in cap[a] else F(0) for x in range(len(masses))] for a in range(len(cap))]
    C=[[sum(volumes[a]/m[a] for a in range(len(cap)) if y in cap[a] and z in cap[a]) for z in range(len(masses))] for y in range(len(masses))]
    R=[[[volumes[b]/m[b]/C[y][z] if C[y][z] and y in cap[b] and z in cap[b] else F(0) for b in range(len(cap))] for z in range(len(masses))] for y in range(len(masses))]
    P=[[sum(pi[a][y]*pi[a][z]*R[y][z][b] for y in range(len(masses)) for z in range(len(masses))) for b in range(len(cap))] for a in range(len(cap))]
    for a in range(len(cap)):
        assert sum(P[a])==1; checks+=1
        for b in range(len(cap)):
            assert sigma[a]*P[a][b]==sigma[b]*P[b][a]; checks+=1
    for b in range(len(cap)):
        assert sum(sigma[a]*P[a][b] for a in range(len(cap)))==sigma[b]; checks+=1
    # Source-pair dependent positive marks; these are NOT original histories.
    for mark_id in range(3):
        def mark(a,y,z):
            return F((a+2*y+3*z+mark_id)%7,6)
        for y in range(len(masses)):
            for z in range(len(masses)):
                nu=sum(sigma[a]*pi[a][y]*pi[a][z]*mark(a,y,z) for a in range(len(cap)))
                for b in range(len(cap)):
                    assert nu*R[y][z][b] <= sigma[b]*pi[b][y]*pi[b][z]; checks+=1
                # Conditional projection is idempotent at fixed old sources.
                if C[y][z]:
                    assert sum(R[y][z])==1; checks+=1
                    for b in range(len(cap)):
                        assert sum(R[y][z][a]*R[y][z][b] for a in range(len(cap)))==R[y][z][b]; checks+=1
    # Actual external third-source probability, old sources both core.
    e2=sum(R[0][0][b]*(1-pi[b][0]) for b in range(len(cap)))
    eta=masses[1]; N=len(signs); vd=volumes[1]; v0=volumes[0]
    formula=N*vd*eta/((1+eta)**2*(v0+N*vd/(1+eta)))
    assert e2==formula; checks+=1
    print('native block field scale',scale,'pair escape',e2)
    cases+=1
print('PASS',checks,'exact Fraction assertions in',cases,'native block fields; auxiliary marks only, no original history certification')
