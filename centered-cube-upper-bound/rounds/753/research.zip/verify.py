from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, combinations_with_replacement, product
from math import comb, factorial, prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


PRECISION = 256
BATCHES = (1, 2, 3, 5)
TAU = F(1, 8)


def point(*values):
    return tuple(F(x) for x in values)


def exact_sum(values):
    return sum(values, F(0))


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def interval(value):
    return value.str(23)


@dataclass(frozen=True)
class Box:
    bounds: tuple

    @property
    def volume(self):
        return prod(max(F(0), hi-lo) for lo,hi in self.bounds)

    def contains(self, z, strict=True):
        if strict:
            return all(lo<x<hi for (lo,hi),x in zip(self.bounds,z))
        return all(lo<=x<=hi for (lo,hi),x in zip(self.bounds,z))

    def contains_box(self, other):
        return all(lo<=a<=b<=hi for (lo,hi),(a,b) in zip(self.bounds,other.bounds))


@dataclass(frozen=True)
class Cube:
    name: str
    position: tuple
    radius: F

    def box(self, dilation=F(1)):
        return Box(tuple((z-dilation*self.radius,z+dilation*self.radius) for z in self.position))


def overlap(*boxes):
    return Box(tuple((max(lo for lo,_ in axis),min(hi for _,hi in axis))
                     for axis in zip(*(A.bounds for A in boxes)))).volume


def native_count(indices, length):
    out = [0]*length
    for i in indices:
        out[i] += 1
    return out


def multiset_multiplicity(counts):
    return factorial(sum(counts)) // prod(factorial(n) for n in counts)


def powers(values, counts):
    return prod(v**c for v,c in zip(values,counts))


def joint_hull(positions, h, S):
    radius = h*S
    spans = list(zip(*positions))
    box = Box(tuple((max(axis)-radius,min(axis)+radius) for axis in spans))
    D = prod(max(F(0),1-(max(axis)-min(axis))/(2*radius)) for axis in spans)
    assert box.volume == (2*radius)**len(spans)*D
    return box,D



def P(u):
    assert 0 <= u <= 1
    return u+u*u/2+u**3/3


def rectangle_lengths(A,B):
    return tuple(max(F(0),min(v,y)-max(u,x))
                 for (u,v),(x,y) in zip(A.bounds,B.bounds))


def energy_view(Z,rho_weights,nu,p,h,S,lengths):
    scaled = tuple(length/(2*h*S) for length in lengths)
    depths = tuple(P(a)/2 for a in scaled)
    U = sum(depths)
    Gamma_axes = [F(0)]*len(scaled)
    mean_distance = [F(0)]*len(scaled)
    moment = F(0)
    old_measure = F(0)
    for i,j in product(range(len(Z)),repeat=2):
        if not (nu[i] and nu[j]):
            continue
        _,D = joint_hull((Z[i],Z[j]),h,S)
        assert D>0
        for l,(x,y,u) in enumerate(zip(Z[i],Z[j],scaled)):
            a = abs(x-y)/(2*h*S)
            assert 0 <= a <= u
            Gamma_axes[l] += nu[i]*nu[j]*P(a)
            mean_distance[l] += nu[i]*nu[j]*a
        moment += p*nu[i]*nu[j]/D
        old_measure += rho_weights[i]*rho_weights[j]/(p*D)
    assert moment==old_measure
    assert all(E<=u/2 for E,u in zip(mean_distance,scaled))
    assert all(g<=depth for g,depth in zip(Gamma_axes,depths))
    gamma=sum(Gamma_axes)
    gap=U-gamma
    assert gap>=0
    if gamma:
        assert ball(p)*ball(gamma).exp() < ball(moment)
    else:
        assert moment==p
    # Here the reference distribution is uniform on this very rectangle.
    gamma_uniform=sum(
        sum(2*a**j/(j*(j+1)*(j+2)) for j in (1,2,3)) for a in scaled
    )
    assert gamma_uniform < U
    return {
        "p":str(p),"normalized_coordinate_widths":list(map(str,scaled)),
        "U":str(U),"Gamma":str(gamma),"Delta":str(gap),
        "Gamma_uniform_intersection_reference":str(gamma_uniform),
        "Delta_uniform_reference":str(U-gamma_uniform),
        "p_exp_Gamma_arb":interval(ball(p)*ball(gamma).exp()),
        "p_times_inverse_D2_moment_arb":interval(ball(moment)),
    }


def reference_polynomial():
    # B has point mass 1-r at 1 and density 2r*b on [0,1].
    powers_0_to_4 = [F(0)]*5
    powers_0_to_4[1] -= F(1,2)
    for j in (1,2,3):
        powers_0_to_4[j] += F(1,2*j)
        powers_0_to_4[j+1] -= F(1,2*(j+2))
    assert powers_0_to_4 == [0,0,F(1,12),F(1,24),-F(1,10)]
    grids = []
    for resolution in (16,256,4096):
        values=[]
        for i in range(resolution+1):
            r = F(i,resolution)
            moments = [(1-r)+2*r/(j+2) for j in (1,2,3)]
            assert moments == [1-j*r/(j+2) for j in (1,2,3)]
            from_distribution = sum(r**j*m/(2*j) for j,m in enumerate(moments,1))-r/2
            direct = sum(r**j*c for j,c in enumerate(powers_0_to_4))
            shape = F(1,12)+r/24-r*r/10
            assert from_distribution==direct==r*r*shape
            assert shape-F(1,40)==(1-r)*(F(7,120)+r/10)>=0
            values.append((shape,r))
        floor,r_star = min(values)
        assert (floor,r_star)==(F(1,40),F(1))
        grids.append({"resolution":resolution,"points":len(values),
                      "minimum_coefficient_after_removing_r2":str(floor),"minimizer":str(r_star)})
    return {
        "powers_0_to_4_of_half_E_P_rB_minus_r_over_2":list(map(str,powers_0_to_4)),
        "exact_factor_of_normalized_excess_above_one_fortieth":"(1-r)*(7/120+r/10)",
        "grids_include_both_endpoints":grids,
    }


def actual_fixture():
    n = 2
    a = 32*n
    h = 1+F(1,a)
    K,G = F(1),F(2)
    cubes = (
        Cube("small",point(0,0),F(15,16)),
        Cube("L0",point("1/16",0),F(1)),
        Cube("L1",point("1/4","-1/8"),F(17,16)),
        Cube("L2",point("-5/16","3/16"),F(9,8)),
        Cube("L3",point(0,"3/8"),F(17,16)),
        Cube("L4",point("3/8","-3/8"),F(3,2)),
        Cube("L5",point("-9/16","1/8"),F(13,8)),
    )
    parents = [c.box() for c in cubes]
    owners = [c.box(F(1,a)) for c in cubes]
    assert all(not overlap(A,B) for A,B in combinations(owners,2))
    d = [A.volume for A in parents]
    v = [A.volume for A in owners]
    prices = [
        (point("-7/8","-7/8"),F(2)),(point("7/8","7/8"),F(3)),
        (point("-7/8","7/8"),F(4)),(point("7/8","-7/8"),F(1)),
        (point(0,0),F(1)),(point(1,0),F(2)),(point(-1,"1/8"),F(2)),
    ]
    assert all(A.contains(z)==A.contains(z,strict=False) for A in parents for z,_ in prices)
    m = [exact_sum(value for z,value in prices if A.contains(z)) for A in parents]
    assert all(mi>=di for mi,di in zip(m,d)) and m[0]>d[0]
    lam = [F(i+2,i+3)*K*vi/(G*mi) for i,(vi,mi) in enumerate(zip(v,m))]
    assert sum(lam)<1 and all(li*mi<=K*vi/G for li,vi,mi in zip(lam,v,m))
    psmall = [(z,weight/m[0]) for z,weight in prices if parents[0].contains(z)]
    Z,rho = zip(*psmall)
    assert exact_sum(rho) == 1
    bands = ((1,2,3,4),(5,6))
    assert sorted(sum(bands,())) == list(range(1,len(cubes)))
    for g,indices in enumerate(bands):
        assert all(2**(2+g)<=d[i]<2**(3+g) for i in indices)
    b_input = {
        "big_to_small": (
             ("1","7/8","1/2","1","1/4"),("0","1/2","1/3","1/4","1/4"),
             ("1/3","0","1/5","1/4","1/2"),("3/4","1/4","1/2","0","1"),
             ("1/2","1/3","1/4","0","1"),("5/8","1","1/3","3/4","1/2"),
        ),
        "small_to_big": (
             ("1","1","1","1","3/4"),("0","3/4","1/6","1/2","1/4"),
             ("1/2","0","3/5","1/4","1"),("3/4","1/2","1/4","0","1/4"),
             ("1/2","3/4","0","1/2","1"),("1","1/3","1/2","5/8","1/4"),
        ),
    }
    b = {direction:{i:tuple(map(F,values[i-1])) for i in range(1,len(cubes))}
         for direction,values in b_input.items()}
    actual_cases = []
    statistical_cases = []
    for indices in bands:
        S = max(cubes[i].radius for i in indices)
        assert all(d[i]>=(2*S)**n/2 for i in indices)
        common_box_volume = (2*h*S)**n
        by_direction = {}
        support = {i:tuple(parents[i].contains(z) for z in Z) for i in indices}
        for direction in b:
            weights = {
                i:tuple(rj*b[direction][i][j] if keep else F(0)
                        for j,(rj,keep) in enumerate(zip(rho,support[i])))
                for i in indices
            }
            p = {i:sum(weights[i]) for i in indices}
            assert all(0<pi<=1 for pi in p.values())
            conditional = {i:tuple(w/p[i] for w in weights[i]) for i in indices}
            assert all(sum(w)==1 for w in conditional.values())
            if direction=="big_to_small":
                coeff = {i:lam[i]*v[0] for i in indices}
                root_base = K*v[0]/G
            else:
                coeff = {i:lam[0]*m[0]*v[i]/m[i] for i in indices}
                root_base = lam[0]*m[0]
            assert all(coeff[i]<=root_base*v[i]/m[i] for i in indices)
            true_source_mass = {i:p[i]*m[0] for i in indices}
            # Raw original price-cell integration uses the original receiver denominator.
            for i in indices:
                explicit = exact_sum(value*b[direction][i][j] for j,(z,value) in enumerate(prices[:len(Z)])
                                     if parents[i].contains(z))
                assert explicit == true_source_mass[i]
                if direction=="big_to_small":
                    receipt = lam[i]*v[0]*explicit/m[0]
                else:
                    receipt = lam[0]*v[i]*explicit/m[i]
                assert receipt == coeff[i]*p[i]
                statistical_cases.append({
                    "label":cubes[i].name,"direction":direction,
                    "bin_radius_upper_S":str(S),
                    "geometry":energy_view(Z,weights[i],conditional[i],p[i],h,S,
                                           rectangle_lengths(parents[0],parents[i])),
                })
            by_direction[direction] = (weights,p,conditional,coeff,root_base)

        for k in BATCHES:
            local_paid = {direction:{i:F(0) for i in indices} for direction in b}
            total_from_batched = {direction:F(0) for direction in b}
            total_in_conditional = {direction:{i:F(0) for i in indices} for direction in b}
            region_min = F(1)
            largest_occupancy = F(0)
            saturated = {direction:0 for direction in b}
            partial = {direction:0 for direction in b}
            present = 0
            represented = 0
            for batch in combinations_with_replacement(range(len(Z)),k):
                counts = native_count(batch,len(Z))
                multiplicity = multiset_multiplicity(counts)
                represented += multiplicity
                product_rho = powers(rho,counts)
                assert product_rho > 0
                hull,D = joint_hull(tuple(Z[j] for j in batch),h,S)
                compatible = tuple(i for i in indices if all(support[i][j] for j in batch))
                if compatible:
                    assert D>0 and all(hull.contains_box(owners[i]) for i in compatible)
                    owner_occupancy = exact_sum(v[i] for i in compatible)/hull.volume
                    assert owner_occupancy<=1
                    assert exact_sum(v[i]/m[i] for i in compatible)<=2*h**n*D
                    largest_occupancy=max(largest_occupancy,owner_occupancy)
                    region_min = min(region_min,D)
                    present += 1

                for direction,(weights,p,conditional,coeff,root_base) in by_direction.items():
                    coalesced = F(0)
                    for i in indices:
                        lhs = p[i]*powers(conditional[i],counts)
                        rhs = p[i]**(1-k)*powers(weights[i],counts)
                        assert lhs == rhs
                        total_in_conditional[direction][i] += lhs*multiplicity
                        if not rhs:
                            continue
                        assert i in compatible and D>0
                        beta = TAU*p[i]**(k-1)/D
                        if beta>=1:
                            saturated[direction]+=1
                        else:
                            partial[direction]+=1
                        paid = multiplicity*coeff[i]*lhs*min(F(1),beta)
                        local_paid[direction][i]+=paid
                        product_b = rhs/(p[i]**(1-k)*product_rho)
                        assert 0<product_b<=1
                        pay_density = coeff[i]*product_b*min(p[i]**(1-k),TAU/D)
                        assert paid == multiplicity*product_rho*pay_density
                        coalesced += pay_density
                    assert coalesced <= 2*h**n*TAU*root_base
                    total_from_batched[direction] += multiplicity*product_rho*coalesced
            assert represented == len(Z)**k
            result = {}
            for direction,(_,p,_,coeff,root_base) in by_direction.items():
                for i in indices:
                    assert total_in_conditional[direction][i]==p[i]
                spent = sum(local_paid[direction].values())
                budget = 2*h**n*TAU*root_base
                original = exact_sum(coeff[i]*p[i] for i in indices)
                assert spent==total_from_batched[direction] <= budget and spent <= original
                result[direction] = {
                    "original_flow":str(original), "paid_by_batch":str(spent),
                    "root_budget":str(budget), "paid_over_budget":str(spent/budget),
                    "saturated_pair_multisets":saturated[direction],
                    "strictly_fractional_pair_multisets":partial[direction],
                    "pair_capture_fractions": {
                        cubes[i].name:str(local_paid[direction][i]/(coeff[i]*p[i])) for i in indices
                    },
                }
            actual_cases.append({
                "bin_labels":[cubes[i].name for i in indices],"bin_radius_upper_S":str(S),"k":k,
                "number_of_ordered_batches_represented":represented,
                "compatible_multisets":present,"lowest_compatible_D":str(region_min),
                "largest_true_owner_occupancy_fraction":str(largest_occupancy),
                "directions":result,
            })

    assert any(
        a["directions"]["big_to_small"]["saturated_pair_multisets"] for a in actual_cases
    )
    by_k = []
    for k in BATCHES:
        records = [a for a in actual_cases if a["k"]==k]
        by_k.append({
            "k":k,
            "cumulative_for_same_small_label": {
                direction:{
                    "paid":str(exact_sum(F(a["directions"][direction]["paid_by_batch"]) for a in records)),
                    "budget_sum_of_both_bins":str(exact_sum(F(a["directions"][direction]["root_budget"]) for a in records)),
                }
                for direction in b
            },
        })
    return {
        "scope":"one finite small cube, six genuine large cubes, two dyadic volume bins; atoms occupy positive-volume parent arrangement interiors",
        "dimension":n,"cap_K":str(K),"cap_G":str(G),"tau":str(TAU),"a":a,
        "cubes":[{"name":c.name,"center":list(map(str,c.position)),"radius":str(c.radius),
                  "v":str(vi),"d":str(di),"m":str(mi),"lambda":str(li)}
                 for c,vi,di,mi,li in zip(cubes,v,d,m,lam)],
        "price_atoms":[{"z":list(map(str,z)),"mu":str(w)} for z,w in prices],
        "conditional_taper_values_in_small_price_order":b_input,
        "per_bin":actual_cases,"cumulative":by_k,"cubic_distances":statistical_cases,
    }


def native_grid_count(n):
    a = 32*n
    unit = F(2,a)
    count_per_axis = a//4
    total_count = count_per_axis**n-2**n
    v_each = unit**n
    V = v_each*total_count
    small_radius = F(7,8)
    assert V == F(1,2)**n-F(4,a)**n
    positions = tuple(-F(1,4)+(i+F(1,2))*unit for i in range(count_per_axis))
    assert positions[0]-unit/2 == -F(1,4) and positions[-1]+unit/2==F(1,4)
    assert all(abs(x)+F(3,4)<1 for x in positions)
    central = [p for p in positions if abs(p)<(1+small_radius)/a]
    assert len(central)==2
    if n==2:
        center_small = Cube("small",(F(0),)*n,small_radius).box(F(1,a))
        actual_volume = F(0)
        count = 0
        for at in product(positions,repeat=n):
            native = Cube("L",at,F(1))
            if all(x in central for x in at):
                assert overlap(native.box(F(1,a)),center_small)>0
            else:
                assert overlap(native.box(F(1,a)),center_small)==0
                actual_volume += native.box(F(1,a)).volume
                count += 1
        assert actual_volume==V and count==total_count
    return total_count,V,v_each


def tensor_family(n):
    a = 32*n
    K,G = F(1),F(2)
    h = 1+F(1,a)
    S = F(1)
    count,V,v_each = native_grid_count(n)
    b = (F(3,4),F(1,2))
    price = F(2**n)
    d_small = (2*F(7,8))**n
    v_small = d_small/a**n
    assert price>d_small
    lam_s = F(3,4)*K*v_small/(G*price)
    lam_one_large = F(1,2)*K*v_each/(G*price)
    assert lam_s+count*lam_one_large < 1
    negative,positive = ((-F(3,4),)*n,(F(3,4),)*n)
    both_hull,D_mixed = joint_hull((negative,positive),h,S)
    assert D_mixed == (1-F(3,4)/h)**n
    assert both_hull.volume == (F(1,2)+F(2,a))**n
    assert V<=both_hull.volume
    assert V/price <= h**n*D_mixed
    assert all(lo<=-F(1,4)<=F(1,4)<=hi for lo,hi in both_hull.bounds)
    observed=[]
    statistics=[]
    for name,rho in (("one_price_atom",(F(1),F(0))),("two_price_atoms",(F(3,5),F(2,5)))):
        p = exact_sum(w*q for w,q in zip(rho,b))
        nu = tuple(w*q/p for w,q in zip(rho,b))
        assert sum(nu)==1
        # All grid parents see the same price; the outermost native center minimizes each joint width.
        s = F(7,8)
        extreme_center = F(1,4)-F(1,a)
        representative = Cube("minwidth_L",(extreme_center,)*n,F(1)).box()
        real_small = Cube("small",(F(0),)*n,s).box()
        widths=rectangle_lengths(real_small,representative)
        expected = 1+s-extreme_center
        assert all(width==expected for width in widths)
        statistics.append({
            "price_model":name,
            "verified_at_gridwide_minimum_intersection_width":energy_view(
                (negative,positive),tuple(w*q for w,q in zip(rho,b)),nu,p,h,S,widths),
        })
        for k in BATCHES:
            probability_coincident = nu[0]**k+nu[1]**k
            c = TAU*p**(k-1)
            fraction = probability_coincident*min(F(1),c)+(1-probability_coincident)*min(F(1),c/D_mixed)
            independent = change_weight = F(0)
            for j in range(k+1):
                D = F(1) if j in (0,k) else D_mixed
                actual = comb(k,j)*nu[0]**j*nu[1]**(k-j)
                measure_before = comb(k,j)*rho[0]**j*rho[1]**(k-j)
                beta = b[0]**j*b[1]**(k-j)
                assert p*actual == p**(1-k)*beta*measure_before
                independent += actual*min(F(1),c/D)
                change_weight += measure_before*beta*min(p**(1-k),TAU/D)
            assert independent == fraction and change_weight == p*fraction
            big_to_small_orig = count*lam_one_large*v_small*p
            small_to_big_orig = lam_s*price*(V/price)*p
            bud_b = 2*h**n*TAU*(K/G)*v_small
            bud_s = 2*h**n*TAU*lam_s*price
            assert big_to_small_orig*fraction<=bud_b and small_to_big_orig*fraction<=bud_s
            observed.append({
                "price_model":name,"k":k,"p":str(p),"conditional_capture_fraction":str(fraction),
                "some_noncoincident_batch_is_saturated": 1-probability_coincident>0 and c>=D_mixed,
                "big_to_small_paid/root_budget":interval(ball(big_to_small_orig*fraction/bud_b)),
                "small_to_big_paid/root_budget":interval(ball(small_to_big_orig*fraction/bud_s)),
            })
    return {
        "dimension":n,"native_noncentral_large_count":str(count),
        "n2_full_grid_centers_enumerated": n == 2,
        "mixed_batch_D_exact_definition":"(1-3/(4h))^n; h=1+1/(32n)",
        "mixed_batch_D":interval(ball(D_mixed)),
        "true_joint_rectangle_occupancy":interval(ball(V/both_hull.volume)),
        "rational_tensor_check":observed,"cubic_distance_pressure":statistics,
    }


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    return {
        "schema":"r753-joint-price-batch-verification-v1",
        "runtime":{
            "python":platform.python_version(),"python_executable":sys.executable,
            "python_flint":flint.__version__,"arb_precision_bits":PRECISION,
            "script_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands":"directory containing verify.py and verify.json",
            "write_command":[sys.executable,"-B",script.name,"--out","verify.json"],
            "rerun_command":[sys.executable,"-B",script.name,"--check","verify.json"],
        },
        "genuine_finite_pair_family_exact_exhaustion":actual_fixture(),
        "genuine_native_grid_tensor_tests":[tensor_family(n) for n in (2,16,64,256)],
        "reference_cubic_polynomial_exact":reference_polynomial(),
        "scope":[
            "Finite changes of measure, all batch multisets, cap charges, and owner volumes are exact rationals.",
            "The second family uses genuine finite grids at all displayed dimensions, but enumerates their centers only at n=2. Higher dimensions use exact powers and binomial multiplicities.",
            "The assigned mass caps use explicit K=1,G=2. No extremal G is estimated.",
            "Neither the finite model nor the grid identities assert a universal conditional capture fraction.",
        ],
    }


def main():
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    raw=json.dumps(report(),indent=2,sort_keys=True)+"\n"
    if args.out:
        args.out.write_text(raw,encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != raw:
            raise SystemExit("rerun differs from saved JSON")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__=="__main__":
    main()
