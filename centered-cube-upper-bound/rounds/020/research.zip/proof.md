# 第20轮：局部质量 Poisson 重采样的已付窗口增益

2026-10-07。**一般 sqrt(n)n^{o(1)} 弱型上界仍未闭合。** 本轮得到一个适用于任意有限正来源的新随机扰动接口，常数不依赖维数、原子数、格数或尺度数。此前扩张赢家与径向积分机制继续作为已知工具；新点是将它们用于格内位置重采样，并保留新增捕获的局部质量加权线性方差。保留的全一般全尺度最终工具仍为 O(n log n)。

## 1. 对象、竞争类及本轮路线变化

Q_L(x)=x+[-L/2,L/2]^n，0<a<b，tau>0。mu为有限正Borel测度，W=mu(R^n)>0。m_L=mu(Q_L)，U_L=m_L/L^n，M=sup_[a,b] U_L，E={M>tau}，R是原输入的可测真实赢家。Phi(mu)=tau integral log_+(M/tau) dx。K先定义为完整非负L1类的Phi/W上确界。近极值条件是Phi(mu)>=(K-epsilon)W，epsilon>=0。

同一个K适用于所有有限正Borel来源：保质量紧支撑mollification mu_h。L<b时用L+2h捕获被平滑的原Q_L质量，给相应响应下极限；L=b时，原mu(partial Q_b(x))=0对Lebesgue几乎处处x成立，因为对y先积边界平移集合的Lebesgue测度为零。故M_mu<=liminf M_mu_h几乎处处，Fatou给Phi(mu)<=KW。无需把原子竞争者误称为L1。窗口正包络给K<=1+n log(b/a)，并保证E有限测度。

全局iid经验重采样虽给线性新增质量方差，但原赢家曲率为(W/m_R-1)/N，其空间积分未自动付款。本轮改为按每格的本地质量标定Poisson点权。不得按每次实现的总质量重新归一化。

使用64项工具中的I02滤过／条件平均、L03精确算术、M04可测选择、A02预算方向。Poisson矩在下文从独立计数直接推导，不把技能的专题证据状态当作本课题结论。查重发现旧材料已有整格死亡时钟或冻结传播核；它们保持格内形状，与本轮格内位置重采样不同。

## 2. 一个共同、非负的随机来源

固定半开空间网格，格的l_infinity直径delta满足

    0<delta<=min(a/(8n),(b-a)/4).

w_C=mu(C)，零质量格略去。对每格独立抽N_C~Poisson(kappa)，kappa>0；给定N_C，在格内按mu|C/w_C独立抽Y_{C,j}，定义

    nu=(1/kappa) sum_C w_C sum_{j=1}^{N_C} delta_{Y_{C,j}},
    mu_t=(1-t)mu+t nu,  0<t<1.

整空间、全部接收点和尺度使用同一次来源实现。E nu=mu，E nu(R^n)=W，故nu总质量几乎处处有限，即使可数格的总点数无限。原子重合正常聚合。mu_t每次实现非负，期望质量W，但并非逐实现质量W。

对固定真实Q_L，记eta_L=nu(Q_L)/m_L-1，m_L>0。则eta_L>=-1，Eeta_L=0，且

    Var eta_L = (1/(kappa m_L²)) sum_C w_C a_C(L),
    a_C(L)=mu(C cap Q_L).

由独立Poisson计数及条件抽样直接展开即得；同格不同位置的抽样属于同一随机来源，并非对接收点重新采样。四阶量也有限，因为w_C<=W、sum w_C=W。

## 3. 原赢家曲率的源质量付款

令c0=exp(2n delta/a)<=exp(1/4)，E_inner={x in E:R<=b-2delta}，E_top为E中去掉E_inner的部分。

若x在内窗且y in C cap Q_R，则整个C被Q_(R+2delta)(x)捕获。扩大尺度合法，所以

    w_C <= M(R+2delta)^n <= c0 m_R,
    m_R>=tau R^n,  R>=2||x-y||_infinity.

以真实来源点y作径向中心，不以格锚点代替。方体径向体积变量s=(2||x-y||_infinity)^n满足dx的径向积分等于ds。因而

    tau integral_Einner w_C 1_{y in Q_R}/m_R² dx
    <=tau w_C integral_0^infinity ds/max(tau s,w_C/c0)^2
    =2c0.

此径向积分仅用于上界，所有被丢掉的限制方向明确。再对mu(dy)积分并除kappa，

    tau integral_Einner Var eta_R dx <= (2c0/kappa) W.   (3.1)

这控制的是sum w_C a_C，不是旧checker的sum a_C²，不能用符号碰撞公式直接替代。

顶窗由固定b支付：A_b mu>=m_R/b^n>tau((b-2delta)/b)^n，故

    tau|E_top| <= (b/(b-2delta))^n W <=c0 W.             (3.2)

b-2delta>=a，且log[b/(b-2delta)]<=2delta/a。顶部费用只用固定尺度L1积分，不引入未知弱型常数。

## 4. 已付的完整尺度精确增益

p_R此处不沿用符号扰动记号。直接定义

    G(x,nu)=log(M_mu_t(x)/(M_mu(x)(1+t eta_R(x))))>=0.

原赢家在扰动后仍合法，因此非负。所有新候选，包括依赖nu的选择，都在M_mu_t的完整sup内。窗口捕获的右连续性允许有理尺度加端点的可测sup，旧赢家使用已有可测选择；随机正测度和积分联合可测。

对z>=-1，

    log(1+tz)>=tz-t²z²/(2(1-t)²).

内窗取期望，线性项消失；用(3.1)。顶窗不用可能巨大的二阶矩，直接log(1+teta_R)>=log(1-t)，用(3.2)。阈值log_+截断及E外贡献只提高下界；期望质量W和竞争上界给E Phi(mu_t)<=KW。于是

    tau integral_E E G dx
    <=[epsilon+c0 t²/((1-t)² kappa)
                 +c0 log(1/(1-t))]W.                  (4.1)

非负G允许Tonelli。基线的负部由内窗二阶积分和顶窗常数控制，正部由log(1+teta)<=teta及有限一阶矩控制，故所用积分合法。

特别t=1/2、kappa=1时，

    tau integral_E E G dx <=(epsilon+3)W.               (4.2)

例如c0<=e^(1/4)<4/3且log2<1，常数严格小于8/3，取3即可。没有n、格数、原子数、尺度网格损失。窗口参数影响允许的物理格宽，但不影响显示常数。

顶部费用为O(t)而非O(t²/kappa)。不能在二阶归一化后让它免费消失；本轮固定t、kappa的合同无需作该极限。

## 5. 原子跳跃与稀有捕获的有限差分

对由原输入预先确定的nested s<L，m_s,m_L>0，Delta=m_L-m_s，定义w(y)=w_C (y in C)，

    A_w=integral_Qs w dmu,
    Delta_w=integral_(QL\Qs) w dmu.

同一来源的差噪声满足

    Var(eta_s-eta_L)
     =(1/kappa)[Delta² A_w/(m_s² m_L²)+Delta_w/m_L²].      (5.1)

新增捕获项对真实局部质量加权的Delta_w线性。不能无条件把Delta_w换为常数乘Delta；若新增小原子各自独占极小格，局部格质量也会小。同格内来源位置重采样使partial capture真实可辨，而整格共同符号可能完全看不到它。

更一般，预先确定候选L与原赢家R，D=eta_L-eta_R、V=ED²、sigma_L²=Eeta_L²、g=log(M/U_L)>=0。Poisson独立增量的四阶展开给

    M4=ED4=3V²+kappa^(-3) integral w(y)^3
       [1_QL/m_L-1_QR/m_R]^4 dmu.

可由有限格的Poisson累积量展开证明，再用有限四阶矩截断推广。若V>0，h0=V^(3/2)/(2sqrt(M4))；若V=0，下界定义为零。则无需截断大正跳，

    E G >=[ t h0²/(h0+t sqrt(V sigma_L²))-g ]_+.          (5.2)

证明：D_+=U，ED=0，插值给EU=E|D|/2>=h0。在D>0上log[(1+teta_L)/(1+teta_R)]>=tU/(1+teta_L)，其余事件对正部给零。加权Cauchy给E[U/(1+teta_L)]>=(EU)^2/E[U(1+teta_L)]，后者分母<=EU+t sqrt(V sigma_L²)。函数z²/(z+A)递增，再对hinge用Jensen即得。候选若依赖随机实现，则不能直接使用固定候选的这些矩；完整sup只是在固定候选下界之上。

将(5.2)在E积分可直接接入(4.1)。但未证明高弱比近极值输入必然有足够多合格候选使该下界大；g和稀有捕获四阶费用都必须保留。

## 6. 多轮数值、准确几何及截断费用

代码local_poisson_guard.py只用标准库；几何、原质量及径向积分用Fraction；Poisson概率与对数用Decimal70/110，两档22位增益和12位尾界显示一致。不是向外舍入区间证书，无Monte Carlo、无随机种子、无幂次拟合。

一般几何压力：n=1,2,4,16,64,256；2或5个物理格，每格3原子，质量深度0或12，两个接收点偏移。共48例，其中32内窗、16顶窗；均以真实l_infinity距离分组得到完整原赢家，检验扩大格包含、双下界、径向潜势恰为2C以及顶部固定尺度付款，C=(1+2delta/a)^n。没有以自由径向曲线替代实际来源。

同格切换检验：n=2,4,16,64，网格宽d=1/(kn)，k=32,256；两原子位于0及-(d/2)e2，同属[-3d/4,d/4)^n。设alpha=1-d/2，质量m_s=alpha^n及1-m_s，接收点x=(alpha/2,1/2-d/2,0,...)。真实捕获尺度为alpha和1，在窗口[1/2,3/2]恰为两个并列全局赢家。该几何不是自由profile：令r在(.9,1.1)，x1=alpha r/2、x2=r/2-d/2，其余坐标满足|x_j|<alpha r/2，仍给出一个真实n-1维切换面片。未声称此输入有高弱比或近极值资格。

旧整格符号的两后验完全相同，差方差为0；新格内Poisson来源在kappa=1,4时差方差为(1-m_s)/(kappa m_s)>0。所有扰动仍保留两点的正原质量，因此完整扰动赢家仍来自两个真实距离，候选无遗漏。在原小尺度赢家基线上，

    G=[log((1-t+tN/kappa)/
            (1-t+tI/(kappa m_s)))]_+,

N~Poi(kappa)，I|N~Bin(N,m_s)。t=1/2。16组，每精度19,464个计数配置。N截断到6kappa+32，不能把截断值直接当完整期望；使用

    gain_tail <= (t/(1-t)) P(Poi(kappa)>=Nmax)
       <= (t/(1-t)) e^-kappa kappa^Nmax/Nmax!
                        /(1-kappa/(Nmax+1)).

依据E[N 1_{N>Nmax}]/kappa=P(Poi(kappa)>=Nmax)。尾界最大约1.44e-43。二、四阶矩的截断误差另用下降阶乘展开及对应Poisson尾界验证。全部16组还检验(5.2)严格正下界不超过已算截断增益。测试结果支持公式，实现核查不替代一般证明。

没有进行整体Lebesgue体积的数值认证；解析(3.1)—(4.2)才是空间预算证明。保持共享来源，没有在不同尺度或面片重抽样。

## 7. 当前最小缺口

这轮同时获得新的可付上预算和固定候选下界，消除了全局iid重采样的未付倒质量曲率，并检测到整格符号的同格盲区。但还需由一般输入的真实方体几何，给出覆盖性的候选选择／分支付款，使总增益随高弱比增长。Delta_w过小、候选g过大、稀有跳四阶费用、顶部二阶归一化都不能略去。本轮没有证明这个空间下界，也没有改善最终一般次数。

每轮归档仍只新增README与research.zip两文件；包内详细说明、LaTeX文本、最终代码、结果、哈希清单。未编译PDF。历史依赖清理未全部完成，本轮不复制原始文献、不删除旧证据。
