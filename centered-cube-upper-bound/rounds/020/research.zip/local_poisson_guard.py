#!/usr/bin/env python3
from fractions import Fraction as F
from decimal import Decimal, localcontext
from math import comb, factorial
from pathlib import Path
import json

def geometry(n,c,depth,shift):
    a=F(1,2);b=F(3,2);d=F(1,32*n)
    atoms=[]
    for j in range(c):
        for k in range(3):
            y=tuple(j*d+F(k+1,5)*d if i==0 else F((j+k+i)%3+1,5)*d for i in range(n))
            w=F(k+j+1,2**(depth*k))
            cell=tuple(v//d for v in y)
            atoms.append((y,w,cell))
    x=(shift,)+tuple(F(1,7) for _ in range(n-1))
    radii=[2*max(abs(yi-xi) for yi,xi in zip(y,x)) for y,_,_ in atoms]
    candidates=sorted(set([a,b]+[r for r in radii if a<=r<=b]))
    masses=[sum(w for (_,w,_),r in zip(atoms,radii) if r<=L) for L in candidates]
    responses=[m/L**n for m,L in zip(masses,candidates)]
    M=max(responses)
    if not M:return None
    R=candidates[responses.index(M)];m=M*R**n;tau=M/2
    cells={cc:sum(w for _,w,ccc in atoms if ccc==cc) for _,_,cc in atoms}
    C=(1+2*d/a)**n
    interior=R<=b-2*d
    if interior:
        for (y,w,cc),r in zip(atoms,radii):
            if r<=R:
                assert cells[cc]<=C*m
                assert m>=max(tau*r**n,cells[cc]/C)
                assert tau*cells[cc]/m**2<=tau*cells[cc]/max(tau*r**n,cells[cc]/C)**2
    else:
        mb=sum(w for (_,w,_),r in zip(atoms,radii) if r<=b)
        assert mb/b**n>tau*((b-2*d)/b)**n
        assert (b/(b-2*d))**n<=C
    # Full radial potential integral is elementary and EXACT:
    # integral_0^infty ds/max(tau*s,w/C)^2 = 2*C/(tau*w).
    for w in cells.values():
        cut=w/(C*tau)
        potential=tau*w*(cut/(w/C)**2+1/(tau**2*cut))
        assert potential==2*C
    return {'n':n,'cells':c,'depth':depth,'x1':str(shift),'winner':str(R),
            'branch':'interior' if interior else 'top','C':str(C),'potential_paid':str(2*C)}

def two_atom(n,k,kappa,precision):
    # One actual physical grid cell contains both atoms; two real winner branches tie.
    d=F(1,k*n);sep=d/2;alpha=1-sep;ms=alpha**n;delta=1-ms
    a=F(1,2);b=F(3,2);assert d<=min(a/(8*n),(b-a)/4)
    # Grid cell [-3d/4,d/4)^n; both points 0 and -sep e2 are in it.
    ys=[tuple(F(0) for _ in range(n)),tuple(-sep if i==1 else F(0) for i in range(n))]
    x=tuple(alpha/2 if i==0 else F(1,2)-sep if i==1 else F(0) for i in range(n))
    radii=[2*max(abs(yi-xi) for yi,xi in zip(y,x)) for y in ys]
    assert radii==[alpha,F(1)]
    assert all(all(-3*d/4<=v<d/4 for v in y) for y in ys)
    assert ms/alpha**n==1 and (ms+delta)==1
    # Same-label checker sees identical posterior. Resampling within cell sees the shell.
    old_checker=F(0);var=delta/(kappa*ms)
    jump4=(ms*(1/ms-1)**4+delta)/kappa**3
    fourth=3*var**2+jump4
    t=F(1,2);Nmax=6*kappa+32
    with localcontext() as ctx:
        ctx.prec=precision
        def D(v):return Decimal(v.numerator)/Decimal(v.denominator)
        p=D(ms);q=D(delta);pk=(-Decimal(kappa)).exp()
        total_gain=Decimal(0);second=Decimal(0);fourth_trunc=Decimal(0);massprob=Decimal(0)
        for N in range(Nmax+1):
            if N:pk*=Decimal(kappa)/N
            for inner in range(N+1):
                prob=pk*comb(N,inner)*p**inner*q**(N-inner)
                noise=D(F(inner,kappa)/ms-F(N,kappa))
                second+=prob*noise**2;fourth_trunc+=prob*noise**4;massprob+=prob
                ratio=(1+D(t)*(D(F(N,kappa))-1))/(1+D(t)*(D(F(inner,kappa)/ms)-1))
                total_gain+=prob*max(Decimal(0),ratio.ln())
        # Tail bound: E[N 1_{N>Nmax}]/kappa = P(Pois(kappa)>=Nmax).
        tail=(-Decimal(kappa)).exp()*Decimal(kappa)**Nmax/Decimal(factorial(Nmax))/(1-Decimal(kappa)/Decimal(Nmax+1))
        gain_tail=D(t/(1-t))*tail
        # Moment tails bounded by E[N^r 1_{N>Nmax}]/(kappa*ms)^r.
        def falling_tail(r):
            out=Decimal(0)
            stir={2:{1:1,2:1},4:{1:1,2:7,3:6,4:1}}[r]
            for j,coef in stir.items():
                start=Nmax+1-j
                pp=(-Decimal(kappa)).exp()*Decimal(kappa)**start/Decimal(factorial(start))/(1-Decimal(kappa)/Decimal(start+1))
                out+=coef*Decimal(kappa)**j*pp
            return out/(Decimal(kappa)*p)**r
        tol=Decimal(10)**(-precision+8)
        assert -tol<=D(var)-second<=falling_tail(2)+tol
        assert -tol<=D(fourth)-fourth_trunc<=falling_tail(4)+tol
        assert total_gain>0 and gain_tail<Decimal('1e-14')
        h0=D(var)**Decimal('1.5')/(2*D(fourth).sqrt())
        lower=D(t)*h0*h0/(h0+D(t)*(D(var)/Decimal(kappa)).sqrt())
        assert total_gain>=lower
        return {'n':n,'grid_k':k,'kappa':kappa,'cell_width':str(d),'shell_mass':str(delta),
          'checker_variance':str(old_checker),'poisson_variance':str(var),'fourth_moment':str(fourth),
          'moment_gain_lower':format(lower,'.22g'),'count_cutoff':Nmax,'truncated_gain':format(total_gain,'.22g'),
          'gain_tail_bound':format(gain_tail,'.12g'),'count_configurations':(Nmax+1)*(Nmax+2)//2}

def main():
    fixtures=[geometry(n,c,h,x) for n in (1,2,4,16,64,256) for c in (2,5) for h in (0,12) for x in (F(1,2),F(749,1000))]
    fixtures=[r for r in fixtures if r]
    params=[(n,k,kap) for n in (2,4,16,64) for k in (32,256) for kap in (1,4)]
    low=[two_atom(*args,70) for args in params]
    high=[two_atom(*args,110) for args in params]
    assert low==high
    data={'status':'all checks passed','arithmetic':'Fraction geometry; Decimal 70/110 probabilities and logs; analytic tail bound, not interval arithmetic',
          'seed':None,'geometry':fixtures,'same_cell_actual_seams':low,
          'scope':'No high-weak-ratio assertion; no numerical spatial integral or asymptotic fit.'}
    Path(__file__).with_name('results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'geometry_cases':len(fixtures),'interior':sum(r['branch']=='interior' for r in fixtures),
          'top':sum(r['branch']=='top' for r in fixtures),'seam_cases':len(low),'count_cases_per_precision':sum(r['count_configurations'] for r in low),
          'max_tail':max(float(r['gain_tail_bound']) for r in low)},ensure_ascii=False))
if __name__=='__main__':main()
