# R516：源格局部化与已付款低score层

## 1. 保完整原场的几何目标

固定μ=f dx≥0，W<∞；真实中心E、0<a≤R_B≤b≤2a、m_B=q_BR_Bⁿ、q≤q_B≤λ=rq、0≤t_B≤S。γ>1固定，H=L²(μ×dσ)，原核k_B=t_B R_B^-n 1_QB(y)1_[logγmB,logγmB+1](σ)，L=∫E k_BdB，Q=||L||²。旧窗帽C=S[1+log(γr)]。原父、来源及历史保持不变，原R_*≤2√(DWQ)，D=1+logγr+nlogγ(b/a)。

所有新的辅助动作R均在[a,b]，允许一次密度带[q/c,cλ]、c>1，使用真实新质量窗；C_c=S[1+log(c²γr)]。不重取极值，不依赖域外EX。Q=0、S=0或W=0单列为零分支。

本轮建立真实空间局部化，并实际支付低相对score层。局部高score覆盖仍待证明，不把分层数当总费用。

## 2. 按原交叉score选择随机网格

取0<β<1/2、ℓ=nb/β。对平移u∈[0,ℓ)ⁿ，取半开立方格u+ℓz+[0,ℓ)ⁿ，z∈ℤⁿ。保留距所在格每个面至少b/2的中心，边界条中心删去。对任意固定B，平移均匀时坏概率准确为
\[
p_{bad}=1-(1-b/\ell)^n=1-(1-\beta/n)^n\le\beta.
\]
以真实原score ψ_B=〈L,k_B〉积分。由于∫E ψ_BdB=Q有限，Tonelli给某平移使
\[
E_\partial:=\int_{bad}\psi_BdB=\langle L,L_{bad}\rangle\le\beta Q.\tag{1}
\]
这个选择发生在原来源对之外。没有按中心数或空壳体积替代score权。

记保留中心在格C_i内者为E_i，L_i=∫E_i k_BdB，L_g=Σ_iL_i。每个保留中心的所有R≤b候选盒都落在同一C_i，故L_i在真实源空间支持于C_i。μ绝对连续使可数格面μ零，各Li在H中正交：
\[
Q_g=\|L_g\|^2=\sum_i\|L_i\|^2.
\]
由〈L,L_g〉=Q−E∂及Cauchy，有比直接展开更强的下界
\[
\boxed{Q_g\ge(1-\beta)^2Q.}\tag{2}
\]
直接式Q−Qg=2E∂−||Lbad||²也保留所有边界交叉项。局部格边长ℓ=nb/β明确依赖n，不能把局部问题当成固定几何尺寸。

## 3. 已证原总列界与一次W低score付款

令A_n=1+nlog(b/a)。对任意固定y，包络
\[
\int_E R_B^{-n}1_{Q_B}(y)dB\le A_n
\]
可直接证明：内区2||B−y||∞≤a的贡献≤1；外区a<2||B−y||∞≤b取系数≤(2||B−y||∞)^−n，径向积分为nlog(b/a)。因此保真实来源
\[
\int_E t_Bq_BdB\le SA_nW.\tag{3}
\]
此线性界只用于支付一个相应小的score层，不宣称已得一般根阶。

在每个原局部场Li上定义ψ_i(B)=〈Li,k_B〉。t_B>0时令
\[
\alpha_i(B)=\frac{\psi_i(B)}{Ct_Bq_B}\in[0,1].
\]
t_B=0为零score。定义low={α_i≤1/A_n}，high为其补集。务必保持Li固定，不能删low之后重算α再沿用原阈值。

低层的真实局部交叉score总量满足
\[
E_{low}=\sum_i\int_{E_i\cap low}\psi_i(B)dB
\le\frac C{A_n}\int_E t_Bq_BdB
\le\boxed{CSW.}\tag{4}
\]
这是一项已证明的一次W付款，不含X或未知覆盖费。若A_n=1，全部α≤1即已支付。剩余α∈(1/A_n,1]可按dyadic层分成O(log(A_n+1))层，但这一层数本身不支付覆盖或来源重数。

## 4. 每格覆盖按本格来源结算，保高层未覆盖费用

各格可使用不同的有限半径测度ρ_i，总质量M_i。good_i是high中被覆盖中心；对这些中心，动作概率π_B≤ρ_i支持扩带内且满足相对**原局部score**门
\[
\langle L_i,k_t(B,R)\rangle\ge(1-\theta)\psi_i(B),\qquad0<\theta<1.
\]
动作先于来源，t_B固定，所有R≤b，所以新场A_i仍只在C_i有来源支持。真实窗帽和共同ρ_i给
\[
\|A_i\|^2\le C_cSM_i\mu(C_i),\qquad
\left\|\sum_iA_i\right\|^2=\sum_i\|A_i\|^2
\le C_cS\Omega,
\quad\Omega=\sum_iM_i\mu(C_i).\tag{5}
\]
不会每格重复付全局W；Ω是否有多对数W上界是剩余几何问题。可数求和均非负Tonelli；Ω=∞时公式仅是无信息上界，不能省略。

令E_miss为high中仍未覆盖中心的原局部交叉score总和。各格相对门相加后，直接在正交直和用Cauchy，得到
\[
(1-\theta)(Q_g-E_{low}-E_{miss})
\le\sum_i\langle L_i,A_i\rangle
\le\sqrt{Q_g C_cS\Omega}.\tag{6}
\]
若实际覆盖满足E_miss≤ηQ_g、0≤η<1，则对√Qg解二次式或Young给
\[
Q_g\le\frac{C_cS\Omega}{(1-\theta)^2(1-\eta)^2}
+\frac{2E_{low}}{1-\eta}.
\]
结合(2),(4)，得到完整原场预算
\[
\boxed{Q\le\frac1{(1-\beta)^2}
\left[\frac{C_cS\Omega}{(1-\theta)^2(1-\eta)^2}
+\frac{2CS}{1-\eta}W\right].}\tag{7}
\]
更一般地可在(6)、(7)把C_cSΩ直接替换为实际B_A=Σ_i||A_i||²；只要证明B_A的来源预算即可，无需先证明更强的列L1或覆盖质量帽。不同质量窗的低幅值可使这一软平方显著更省。

β、θ、η均可固定；它们分别对应空间边界、覆盖动作score及未覆盖高层，不混成一笔可重复使用的吸收额度。E_miss≤ηQg仍须实际证明，不能只由有限网格命中几个中心推出。

## 5. 与实际首达壳的连接

本节固定扩带因子c=2；前面的任意c>1平均场预算不代表以下首达构造自动适用于c<2。在high层，α_i>1/A_n。R515首达构造现在以同一个局部Li为测试场，取vθ=min{1,θlogγ/2}、允许质量增量u_B=vθα_i(B)。真实扩张区间全部留在本格（R≤b），且满足一次扩带与相对局部score门。端点b用原子处理，薄首达区间仍有准确壳质量Δ_B=vθα_i m_B。

所以实际未覆盖高层若由这些首达区间产生，其交叉score可在本格按
\[
\sum_i E_{shell,i}
=\frac C{v_\theta}\int\sum_i\int_{bad_i}
 t_B R_B^{-n}1_{Q(B,T_B)\setminus Q_B}(y)dB\,d\mu(y)
\]
结算。不同格真实源支持不重叠；同一格中跨半径重复仍在内列中，未获统一多对数或严格收缩预算。本轮没有用空间隔离掩盖这个剩余重复。

核心未证目标现在是对各格high层同时构造可付的实际软平方B_A与可吸收E_miss；低源加权成本Ω是一个充分选项，或可用上述首达壳给等价来源付款。不能强求全部中心的原L1列都有polylog帽：平方预算允许许多低幅值质量窗共存，必须保score和平方结构。

## 6. 原余流回代与总账

(7)若能补上实际B_A≤K log^A(n+2)W（例如由Ω上界推出）、E_miss≤ηQg的统一构造，则R_*≤2√(DWQ)给根阶乘对数。当前已支付空间边界的固定比例和低score层O(W)，未支付Ω/剩余壳列，故一般上界仍未完成。

原母账Rτ≤[K_old+Cdeep+Cempty+4SrΦmax log(n+e)+Sκ_old]W+J、入口64(128/119)/(1−32δ_old−16η_old)、原初始、删除跳跃、未来来源、宽距离、低强度、极端比例、全尺度及极限不变；适用H_*倍数保留，509/512收据不重复。所有新动作只是raw估计中的比较，不更改旧history。
