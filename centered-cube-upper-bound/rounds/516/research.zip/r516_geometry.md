# R516：随机源格隔离与低局部 score 的一次来源付款

本轮证明了两个实际连接：随机平移的大源格允许各格使用不同覆盖测度，且按各自真实来源质量结算；低局部 score 中心可用原 selector 总列帽直接支付 O(W)。剩余问题被限定到隔离源格中 O(log n) 个正 score 层的联合覆盖/首达壳预算，没有证明该最后预算。

## 1. 原场与网格参数

保持 R515 的原 t_B≤S、真实 μ、E、半径窗 [a,b]、密度带 [q,λ]。令

\[
L=\int_E k_t(B,R_B)dB,\quad Q=\|L\|_{L^2(\mu\times d\sigma)}^2,
\quad C=S[1+\log(\gamma r)],\quad A_n=1+n\log(b/a).
\]

固定 0<β<1/2，取源格边长

\[
\ell=nb/\beta.\tag{1}
\]

此局部域尺度为 O(nb)，明确依赖 n；不称为维数无关大小的局部问题。以 ξ 在 [0,ℓ)^n 均匀随机，取半开轴平行网格格子

D_j(ξ)=ξ+ℓj+[0,ℓ)^n，j∈Z^n。

保留距所在格每个面至少 b/2 的中心，所得中心集记 E_good(ξ)，其余为 E_boundary(ξ)。这个选择只依赖真实中心和一个整体网格平移，完全在来源抽样之前确定。

## 2. 边界损失按原交叉 score，而非每格重新收 W

固定 B，其每个坐标在随机格中的位置均匀；所以

\[
p_{\rm boundary}=1-(1-b/\ell)^n\le nb/\ell=\beta.
\]

令 ψ_B=〈L,k_t(B,R_B)〉≥0，∫Eψ_BdB=Q。原场和 score 不随网格变化，因此 Tonelli 给准确期望

\[
\mathbb E_\xi\langle L,L_{\rm boundary}(\xi)\rangle
=p_{\rm boundary}Q\le\beta Q.
\]

可选一个平移 ξ₀ 使

\[
\mathcal E_{\rm boundary}:=\langle L,L_{\rm boundary}\rangle\le\beta Q.\tag{2}
\]

从此固定这一个平移，不对每个来源另选网格。μ=f dx 使网格面 μ 零，不产生额外来源边界原子。若 Q=0 直接结束。

令 E_j 为 D_j 中保留的中心，μ_j=μ|D_j，

\[
L_j=\int_{E_j}k_t(B,R_B)dB,\quad Q_j=\|L_j\|^2,
\quad L_0=\sum_jL_j,\quad Q_0=\sum_jQ_j.
\]

对 B∈E_j，全部候选 R∈[a,b] 的盒都在 D_j 中。因而 μ_jQ(B,R)=μQ(B,R)，真实质量窗完全相同；L_j 的来源支持在 D_j。各 j 在 μ×dσ 中支持互斥，故 Q₀=||L₀||²。又

\[
\langle L,L_0\rangle=Q-\mathcal E_{\rm boundary}\ge(1-\beta)Q,
\]

由 Cauchy 得

\[
\boxed{Q_0\ge(1-\beta)^2Q.}\tag{3}
\]

供账目核查的另一精确恒等式是

Q−Q₀=2 E_boundary−||L_boundary||²≤2βQ。

这里的边界费始终是与完整原 L 的交叉 score；不能换成边界场自身平方。

## 3. 局部 score 可独立使用，删除低 score 后不重新计算

从现在起每格的测试场为自己的 L_j，局部 score 为

\[
\psi_j(B,R)=\langle L_j,k_t(B,R)\rangle_{L^2(\mu_j\times d\sigma)},
\quad B\in E_j.
\]

每个局部输入保持原 q 带、真实质量和原 t_B，0≤L_j≤C。对 t_B>0 定义

\[
\alpha_B^{(j)}=\frac{\psi_j(B,R_B)}{C t_Bq_B}\in[0,1].\tag{4}
\]

t_B=0 单列，局部 score 为零。选择阈值 τ=1/A_n，把 α_B^(j)≤τ 的中心记为 Z_j。以下不因删除 Z_j 而重算 L_j、ψ_j 或 α_B^(j)。

低层交叉 score 满足

\[
\begin{aligned}
\mathcal E_{\rm low}
&=\sum_j\int_{Z_j}\psi_j(B,R_B)dB\\
&\le C\tau\int_{E_{\rm good}}t_Bq_BdB\le CS\tau A_nW=\boxed{CSW.}
\end{aligned}\tag{5}
\]

最后一步的原 selector 总列帽可直接核验：对每 y，

\[
\int_E t_BR_B^{-n}1_{Q_B}(y)dB
\le S\int_{\|B-y\|_\infty\le b/2}
[\max\{a,2\|B-y\|_\infty\}]^{-n}dB
=S[1+n\log(b/a)].
\]

再对同一个 μ 积分得到 ∫E t_Bq_BdB≤SA_nW。这是独立来源付款，不是 ζX，也不需要 X 的弱型估计。

因此剩下高 score 中心只需处理 α_B^(j)∈(1/A_n,1]，可分为至多 ceil(log₂A_n)+1=O(log(n+2)) 个二进层。这里仅支付了低层；没有把正层数当成正层覆盖或壳费用已付。

## 4. 任意局部动作律的实际来源列；各格费用可以合并

设 F_j⊂E_j\Z_j 是选择覆盖的高 score 中心。每 B∈F_j 使用一条来源抽样之前选定的概率动作律 π_B，支持于 [a,b]、一次扩大密度带 [q/2,2λ]，且

\[
\int\psi_j(B,R)\pi_B(dR)\ge(1-\theta)\psi_j(B,R_B),
\quad0<\theta<1.\tag{6}
\]

它可由与来源无关的共同随机数实现；每个 B 的动作对所有来源共享。令

\[
A_j(y,\sigma)=\int_{F_j}\int k_t(B,R)(y,\sigma)\pi_B(dR)dB,
\]

\[
K_j(y)=\int_{F_j}\int t_BR^{-n}1_{Q(B,R)}(y)\pi_B(dR)dB.
\tag{7}
\]

所有这些候选盒仍包含于同一 D_j；不同 j 的 A_j 和 K_j 源支持互斥。真实扩大带给 C'=S[1+log(4γr)]，于是

\[
A_j\le C',\quad\int A_j(y,\sigma)d\sigma=K_j(y),
\qquad
\sum_j\|A_j\|^2\le C'\sum_j\int_{D_j}K_jd\mu.\tag{8}
\]

这就是允许 π_B 随中心块变化时的实际源列，不声称 K_j 自动有小帽。各块不同的覆盖测度不再导致重复收同一个 W。

若存在每格自己的有限半径测度 ρ_j，使 π_B≤ρ_j 于 F_j，M_j=ρ_j([a,b])，则真实中心体积给 K_j≤SM_j，因此

\[
\boxed{\sum_j\|A_j\|^2\le C'S\sum_jM_j\mu(D_j).}\tag{9}
\]

右边是一次源质量加权和 Ω=Σ_jM_j μ(D_j)，绝不是 Σ_jM_j W。只需 Ω≤polylog(n)W；不要求 M_j 逐格统一，也不要求全域同一个 ρ。若只知每格有限 M_j，则 Ω 未必有统一界，不能略去这一点。

## 5. 完整同一 Q 的回代

保留高层未覆盖交叉 score

\[
\mathcal E_{\rm high}=
\sum_j\int_{(E_j\setminus Z_j)\setminus F_j}\psi_j(B,R_B)dB.
\]

令 B_A=Σ_j||A_j||²。由(6)，在格指标与来源 Hilbert 空间上一次 Cauchy 得

\[
(1-\theta)(Q_0-\mathcal E_{\rm low}-\mathcal E_{\rm high})
\le\sum_j\langle L_j,A_j\rangle\le\sqrt{Q_0 B_A}.\tag{10}
\]

若高层未覆盖总 score 满足 E_high≤ηQ₀，0≤η<1，则 (5)、(10) 给

\[
Q_0\le\frac{B_A}{(1-\theta)^2(1-\eta)^2}
+\frac{2CS}{1-\eta}W.
\]

结合(3)、(8)，得到实际局部列版本

\[
\boxed{
Q\le\frac{1}{(1-\beta)^2}
\left[
\frac{C'\sum_j\int K_jd\mu}{(1-\theta)^2(1-\eta)^2}
+\frac{2CS}{1-\eta}W
\right].}\tag{11}
\]

若采用局部覆盖测度，再由(9)得

\[
\boxed{
Q\le\frac{1}{(1-\beta)^2}
\left[
\frac{C'S\Omega}{(1-\theta)^2(1-\eta)^2}
+\frac{2CS}{1-\eta}W
\right],\qquad\Omega=\sum_jM_j\mu(D_j).}\tag{12}
\]

所有吸收比例 β,θ,η 可固定。例如都取 1/4，仍为维数无关常数；局部源格边长则是 4nb，不能隐去。若(11)里的实际来源列另能证明 ≤K(n)W+ζQ，且 ζ 小于该式 Q 系数的倒数，则也给严格同一 Q 收缩。当前尚未证明这个列估计。

## 6. 首达壳如何接入；唯一剩余联合几何

每格以保持不变的 L_j、ψ_j、α_B^(j) 运行 R515 的首达构造。原候选的 μ_j 质量等于全局 μ 质量，故一次放宽合法性和相对门无需改动。取 c_θ=min{1,θlogγ/2}，允许增质量 u_B=c_θα_B^(j)。在一个薄首达未覆盖集合 H_j 上，首达半径 T_B 仍属于 D_j 内，准确有

\[
\int_{H_j}\psi_j(B,R_B)dB
=\frac{C}{c_\theta}\int_{D_j}\int_{H_j}
 t_BR_B^{-n}1_{Q(B,T_B)\setminus Q_B}(y)dB\,d\mu(y).
\tag{13}
\]

各格的壳源支持也互斥，故可直接加总，不把同一个来源质量跨格重复收取。高层 u_B>c_θ/A_n，但这一正下界尚不控制同一格内许多父中心对同一来源的重复收费。

本轮剩余的联合几何只有：在这些源隔离局部输入中，利用 α 的 O(log n) 分层及真实首达条件，构造(6)的动作律，使实际列总费 Σ∫K_jdμ 为多对数 W（或具有足够小的同一 Q 系数），并令未覆盖高 score 按固定比例吸收；若使用 ρ_j，则需真实证明 Ω 的源加权预算。空间上相隔的重复覆盖已由网格源隔离结算；同一源格内部的跨半径重叠尚未解决。

还有一个必须保留的质量核查：对任何覆盖中心 F_j 的概率动作律，由扩大带下限和 q_B≤λ，

\[
\int K_jd\mu_j=\int_{F_j}\int t_Bq(B,R)\pi_B(dR)dB
\ge\frac1{2r}\int_{F_j}t_Bq_BdB.
\]

所以不能强求所有中心的 K 列都有多对数 L1 源帽，却不结算其原中心总强度。本稿只对保留高 score 中心求覆盖，低 score 已由(5)实付。若实际软平方 Σ||A_j||²可比 C'Σ∫K_j更省，应直接代回(10)，不必强行经过更强的列 L1 帽。

## 7. 本机精确核验

实际以本机 Fraction 计算 n=1,2,4,16,64 的随机边界概率，核 1−(1−β/n)^n≤β。另用真实一维 μ=1_[−5,5]dy、原中心区间 [−2,0] 取 R=1、[0,2] 取 R=2、γ=4，枚举 8 个真实网格平移。按中心交集长度构造 piecewise 线性来源列，准确积分其乘积及窗重叠权，检验不同格源场正交和

Q−ΣQ_j=2〈L,L_boundary〉−||L_boundary||²。

输出：`PASS 29 exact random-grid probability and real-source window-field localization checks`。一般维数论证由第2—5节给出，有限模型不替代该证明。

```python
from fractions import Fraction as F
count=0
for n in (1,2,4,16,64):
 for beta in (F(1,8),F(1,4)):
  pbad=1-(1-beta/n)**n
  assert 0<pbad<=beta;count+=1
original=[(F(-2),F(0),F(1)),(F(0),F(2),F(2))]
def values(parts,x,R):
 return sum(max(F(0),min(h,x+R/2)-max(l,x-R/2))/R for l,h,r in parts if r==R)
for shift in [F(i,2) for i in range(8)]:
 groups=[]
 for j in range(-2,2):
  left=shift+4*j;right=left+4
  group=[]
  for l,h,R in original:
   lo=max(l,left+1);hi=min(h,right-1)
   if lo<hi:group.append((lo,hi,R))
  if group:groups.append(group)
 good=[part for group in groups for part in group]
 xs={F(-5),F(5)}
 for l,h,R in original+good:xs.update((l-R/2,l+R/2,h-R/2,h+R/2))
 xs=sorted(xs)
 def vec(parts):return {R:[values(parts,x,R) for x in xs] for R in (F(1),F(2))}
 def inner(A,B):
  total=F(0)
  for R in A:
   for T in B:
    weight=F(1) if R==T else F(1,2)
    aa=A[R];bb=B[T]
    total+=weight*sum((xs[k+1]-xs[k])*(2*aa[k]*bb[k]+aa[k]*bb[k+1]+aa[k+1]*bb[k]+2*aa[k+1]*bb[k+1])/6 for k in range(len(xs)-1))
  return total
 L=vec(original);G=vec(good)
 BAD={R:[x-y for x,y in zip(L[R],G[R])] for R in L}
 V=[vec(group) for group in groups]
 for i in range(len(V)):
  for j in range(i):assert inner(V[i],V[j])==0;count+=1
 Q=inner(L,L);Qgood=sum(inner(v,v) for v in V)
 Ebad=inner(L,BAD);Qbad=inner(BAD,BAD)
 assert Q-Qgood==2*Ebad-Qbad;count+=1
 assert Q-Qgood<=2*Ebad;count+=1
print('PASS',count,'exact random-grid probability and real-source window-field localization checks')
```
