# R516 独立 PRE：分块共同测度与来源累计预算

独核结论：父代理所给式在中心块 a.e. 不交（或总分配权≤1）、动作真实合法及支持可测的条件下正确。它把全局共同测度质量 M 换成真实来源上的加权重数，不自动支付该重数。只需 L1(μ) 的累计预算，无需来源上的 supremum 帽；但仍须由实际几何证明预算和坏交叉score。先独立核命题，未读新作者稿。

## 1. 必需的分块与可测性条件

保持原 L、Q、t_B≤S，不需极值；动作使用固定一次扩带 [q/c,cλ] 的真实新质量窗，C'=S[1+log(c²γr)]，旧帽 C=S[1+log(γr)]。设可数可测块 E_i a.e. 不交，good=∪E_i；每块概率动作核 π_B 联合可测、来源pair之前确定，支持真实合法动作并保同一相对score比例 α=1−θ>0。π_B≤同一个块内中心无关有限半径测度ρ_i，质量M_i。

块不能无权重重叠后重复计中心。global窗帽依赖每中心总概率≤1；否则 ΣA_i 不再是合法混合窗场，该帽与平方线性求和可失效。允许更一般的分数权w_i(B)≥0、Σ_iw_i(B)≤1，此时将所有块积分乘w_i，未分配部分保为bad原场；下文对不交块写式。

定义真实场 A_i=∫Ei∫k_t(B,R)π_B(dR)dB，A=Σ_iA_i，以及

a_i(y)=∫A_i(y,σ)dσ。

所有积分非负，countable Tonelli直接适用。由每中心概率总量1、真实质量窗和统一扩带，global A≤C'；不是先逐块取帽再将帽相加。另有 ∫A≤Scλ|Egood|<∞，所以A作为H场良定，即使某个粗局部预算后来为∞。

## 2. 真实支持及一次来源式

由π_B≤ρ_i，固定y积分σ（窗长恰1）后

a_i(y)≤S∫ρ_i(dR)R^(−n)|E_i∩Q(y,R)|≤SM_i。

若Z_i是其真实来源支持的μ可测包络，即对dBπ_B-a.e.的实际盒在Z_i外没有贡献，则 a_i≤SM_i1_Zi。父代理的所有实际Q(B,R)之并是一个可用几何包络；须取可测版本，不可按期望的预算随意缩小。若用Borel输入，其支持图投影可取μ完成下的解析/普遍可测包络。最稳妥也可直接用 Z_i={a_i>0}，它可测且是实际积分支持；这只是定义真实支持，不证明μ(Z_i)小。

令 G(y)=Σ_iM_i1_Zi(y)。准确有

||A||²≤C'∫A dμdσ
 =C'Σ_i∫a_i dμ
 ≤C'S∫Gdμ=C'SΣ_iM_iμ(Z_i)。

最后等式仍是可数Tonelli，允许∞；右侧∞时不能提取定量改进。来源仍为一次真实μ，所有不同块的来源重叠均已在G里累计，不能再将每块各付的W当同一张收据。中心局部化自身不保证来源µ局部化；可用 E_i+Q(0,b) 等真实几何包络，但其来源质量及重数须另核。

## 3. 完整relative回代与bad费用

记 Lbad 为未覆盖原中心的场，Ebad=〈L,Lbad〉=∫badψold dB。块上相同relative门相加给

α(Q−Ebad)≤〈L,A〉≤√(Q C'S∫Gdμ)。

于是无需极值EX：

Q≤(C'S/α²)∫Gdμ+2Ebad。

若确实另证 Ebad≤βQ、β<1，则更强

Q≤[C'S/(α²(1−β)²)]∫Gdμ。

这正是所问局部化公式；没有坏score条件时不能写其分母吸收。bad是与完整L的交叉项，不能换成||Lbad||²、块数或仅中心测度。通用帽仅给 Ebad≤C∫bad t_Bq_BdB≤CSXbad，仍须有价支付。

若实际几何能证 ∫Gdμ≤K(n)W、K多对数，且θ、β固定，则沿原D=1+log_γr+nlog_γ(b/a)得到

R_*≤2√(D C'SK(n))W/[α(1−β)]。

这是条件充分桥，未认证其预算前提。若预算仅为KW+δX，则令F=C'S/[α²(1−β)²]，严格回代为

R_*≤εX+[DFδ/ε+2√(DFK)]W。

没有β占比、但Ebad≤ζX时，则 Q≤C'SKW/α²+[C'Sδ/α²+2ζ]X，再按同一原流Young付D倍数。不得将固定小δ或ζ免费吸收。保原配置不引入X*；其他母账、入口和适用H_*费用仍保留。

## 4. 可用累计预算代替sup重数帽

需要的是实际 ∫Gdμ，不是必要地证明G≤K。可直接证明 Σ_iM_iμ(Z_i)≤KW，或使用layer-cake

∫Gdμ=∫_0^∞ μ{G>s}ds
 ≤L0 W+∫_(L0)^∞ μ{G>s}ds。

因此只要大重数尾的累计µ费用受控，就足以付款；局部高重数允许存在。所有层仍必须按同一个实际G计量，不可逐层重选块或来源。更细的可测权w_i(y)若真实满足 a_i(y)≤S w_i(y)，也可用∫Σ_iw_i dμ替代粗Mi1_Zi；其累计上界仍须独立几何证明，不能只把未付新质量积分换名为budget。

累计控制严格弱于uniform sup：纯测度核查取不交Z_i且μ(Z_i)=4^(−i)、M_i=2^i，则G无有限sup，但W=Σ4^(−i)=1/3，∫G=Σ2^(−i)=1=3W。这里只说明预算条件的逻辑强弱，未声称此抽象集合族已由本问题的合法动作构造。

## 5. 本机数学核验及剩余任务

实际运行指定本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`，SymPy精确核relative二次根；Fraction在N=1,2,8,32的四个累计层模型精确核加权和及layer-cake相等，SymPy核无限和W=1/3、budget=1。退出0；stdout为 `PASS weighted source integral/layer-cake identities: 4 finite exact cases; infinite sums W=1/3, budget=1` 及 `PASS relative-score quadratic constants; measure-budget examples do not certify physical covering families`。一般公式由中心体积、窗帽、Tonelli、Cauchy证明，有限算术不替代几何前提；未运行MATLAB。

下一步准确需证：实际分块/分数分配、块内共同ρ_i及近score动作，在同一构造下满足低累计来源费用与bad交叉score预算。公式已避免globalM的强制最大值，但没有自动控制ΣM_iμ(Z_i)，更未完成一般根阶。交付后等待作者。

## 6. 父代理新增随机格局部化：独立核验

对0<β<1/2，取真实轴平行网格边长ℓ=nb/β，并均匀随机平移。删中心距任意格面<b/2者；固定B被删概率为1−(1−b/ℓ)^n=1−(1−β/n)^n≤β。以原固定场的原ψ_B权积分，Tonelli给某平移满足Ebad=〈L,Lbad〉≤βQ。不需极值、µ正则性以外的密度帽或原history删除。格面本身µ零，边界等号可按半开格分配。

保留中心的全部R≤b盒都在同一真实格中。因此各格原场L_i的y来源支持µ-a.e.互斥，Qgood=Σ_i||L_i||²。准确展开 Q−Qgood=2〈L,Lbad〉−||Lbad||²≤2βQ，故 Qgood≥(1−2β)Q。另由〈L,Lgood〉≥(1−β)Q及Cauchy还可得(1−β)²Q的较强版本；父代理保守系数有效。

每格local score必须用这个固定L_i定义：ψ_i(B)=〈L_i,kold_B〉，α_B=ψ_i/(Ct_Bq_B)∈[0,1]，t_B=0分支为零。将α≤1/A_n者记low，A_n=1+nlog(b/a)。其完整局部交叉score满足

Σ_iElow,i≤(C/A_n)∫E t_Bq_BdB≤CSW，

末步使用真实原selector列帽∫E q_BdB≤A_nW。此项确已付款，包含同格所有low/high的交叉项；不能删low后重算α却沿用原阈值或费用。

若每格对其全部剩余high中心，用同一ρ_i支持真实合法且保ψ_i相对门的动作（R≤b），新源盒仍在该格，故逐格

Qi≤C'SM_iµ(cell_i)/(1−θ)²+2Elow,i。

可数求和后真实完整账为

Q≤[C'SΣ_iM_iµ(cell_i)/(1−θ)²+2CSW]/(1−2β)。

若部分high尚未覆盖，还必须加其与同一L_i的未覆盖交叉score；不得只因low已付而忽略high补集。此处cell是真实源支持，不是虚构局部化。因格子互斥，Σµcell=W，但带权ΣM_iµcell仍无多对数保证。α高段有O(log A_n)个dyadic数值层，不代表共同ρ_i覆盖费已被支付。

已实际用指定Python-I/Fraction核n=1,2,8,64、β=1/8,1/4的8个删概率并用SymPy核正交格场加bad的能量恒等式；stdout `PASS 8 exact random-grid deletion probability checks; orthogonal-cell/bad-field energy identity`，退出0。一般随机格证明是上面的平移概率、Tonelli及盒包含关系，不由有限核验外推。尚未读作者后续，等待稿件。

## 7. 作者新式(7)与实际软平方的追加后审

获授权读 `/tmp/r516_proof.md`、`/tmp/r516_geometry.md`。强 Qgood≥(1−β)²Q 已按原L交叉score及Cauchy正确写入；固定L_i低score层仍实付CSW。若实际未覆盖high score≤ηQgood，则相对门给

(1−θ)[(1−η)Qgood−Elow]≤√(Qgood B_A)，B_A=Σ_i||A_i||²。

先除(1−η)，再作Young，准确有

Q≤{B_A/[(1−θ)²(1−η)²]+2CSW/(1−η)}/(1−β)²。

因此作者(7)中用B_A≤C_cSΩ的全部系数正确。实际软平方B_A是可直接使用的较弱付款条件，不要求先证明通常更强的 Σ∫K_i 或 Ω 的L1帽。源格正交、每格不同ρ_i、countable求和以及high未覆盖交叉项均正确保留。O(log n)正score层未被当作已付覆盖。

已实际用指定Python-I重放作者geometry29项真实源区间及随机概率检查，输出 `PASS 29 exact random-grid probability and real-source window-field localization checks`；另用SymPy核上式Young恒等式，输出 `PASS symbolic high-miss absorption: low coefficient 2/(1-eta), squared coverage denominator`，退出0。有限检查不替代一般几何。

已向父代理指出一个需明确的接口：proof主桥可用任意固定c>1，但直接调用R515首达参数只保证[q/2,2λ]；首达连接节应显式取c=2（geometry本已取2），或为一般c缩参数。此不影响上述主桥代数；等待作者处理和最终冻结。尚不认证hard高score覆盖或任何统一根阶预算。
