#!/usr/bin/env python3
"""R516 tensor reduction, full Q, and expressly slice-only radius exploration."""
from pathlib import Path
from functools import lru_cache
import math,json,time,sys,platform
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.optimize import brentq,minimize_scalar
import sympy as sp
ROOT=Path(__file__).resolve().parent
LOW=5/6;HIGH=.9;e=1/32;LOG4=math.log(4);REF=math.sqrt(3);R515=1.6929363131395196
NQUAD=0;MAXERR=0.

def r0(B):return math.sqrt(12*(1-B*B))
def q(B,R):return B*B+R*R/12

def cfromr(R):
 if 0<R<math.sqrt(12):
  C=math.sqrt(1-R*R/12)
  if LOW<C<HIGH:return C
 return None

def points(n,B,R,reset=False,double=False):
 out=[];p=1 if reset else n;logm=p*math.log(R)+math.log(q(B,R))
 for sign in [-1,0,1]:
  C=cfromr(math.exp((logm+sign*LOG4)/p))
  if C is not None:out.append(C)
 for RR in [R-4*e if double else R-2*e,R,R+4*e if double else R+2*e]:
  C=cfromr(RR)
  if C is not None:out.append(C)
 for y in [B-R/2,B+R/2]:
  disc=12-3*y*y
  if disc>=0:
   for C in [(y-math.sqrt(disc))/4,(y+math.sqrt(disc))/4]:
    if LOW<C<HIGH:out.append(C)
 return sorted(set(out))

def firstmass(B,R,C,Rc):
 lo=max(B-R/2,C-Rc/2);hi=min(B+R/2,C+Rc/2)
 return max(0.,(hi**3-lo**3)/3)

def integrateC(f,pts,tight=False):
 global NQUAD,MAXERR
 z,err=quad(f,LOW,HIGH,points=pts,epsabs=2e-14 if tight else 2e-12,epsrel=2e-11 if tight else 2e-8,limit=120)
 NQUAD+=1;MAXERR=max(MAXERR,err)
 return z,err

@lru_cache(maxsize=None)
def score(n,B,R,reset=False):
 p=1 if reset else n;logm=p*math.log(R)+math.log(q(B,R))
 def f(C):
  Rc=r0(C);over=max(0.,1-abs(logm-p*math.log(Rc))/LOG4)
  J=2*e*min(R,Rc)-max(0.,e-abs(R-Rc)/2)**2
  return firstmass(B,R,C,Rc)/(R*Rc)*(REF*(J/(2*e))/(R*Rc))**(n-1)*over
 return integrateC(f,points(n,B,R,reset))[0]

@lru_cache(maxsize=None)
def oldscore(n,B,reset=False):return score(n,B,r0(B),reset)

def fullQ(n):
 def outer(B):
  R=r0(B)
  def f(C):
   Rc=r0(C);Knorm=min(R,Rc)-max(0.,2*e-abs(R-Rc)/2)**3/(12*e*e)
   over=max(0.,1-n*abs(math.log(R/Rc))/LOG4)
   return firstmass(B,R,C,Rc)/(R*Rc)*(REF*Knorm/(R*Rc))**(n-1)*over
  return integrateC(f,points(n,B,R,double=True))[0]
 scaled,err=quad(outer,LOW,HIGH,epsabs=2e-12,epsrel=2e-8,limit=120)
 normalized=scaled/REF**(n-1)
 return {'Q_actual':normalized*(2*e)**(2*(n-1)),'Q_div_rest_center_measure_squared':normalized,'Q_internal_scaled':scaled,'internal_scale_REF_power':REF**(n-1),'outer_quad_error_estimate_normalized':err/REF**(n-1)}

def regions(fun,pts):
 pts=sorted(set(pts));values=[fun(x) for x in pts];roots=[]
 for a,b,fa,fb in zip(pts,pts[1:],values,values[1:]):
  if fa==0:roots.append(a)
  if fa*fb<0:roots.append(brentq(fun,a,b,xtol=2e-11,rtol=2e-11))
 cuts=sorted(set([pts[0],pts[-1],*roots]));return [(a,b) for a,b in zip(cuts,cuts[1:]) if fun((a+b)/2)>=0]

def merge(intervals):
 out=[]
 for a,b in sorted(intervals):
  if out and a<=out[-1][1]+1e-11:out[-1]=(out[-1][0],max(out[-1][1],b))
  else:out.append((a,b))
 return out

def complement(intervals):
 out=[];a=LOW
 for lo,hi in intervals:
  if lo>a:out.append((a,lo))
  a=max(a,hi)
 if a<HIGH:out.append((a,HIGH))
 return out

def fixed_region(n,R,theta,reset=False):
 xs=list(np.linspace(LOW,HIGH,65));c=cfromr(R)
 if c is not None:xs.append(c)
 return regions(lambda B:score(n,float(B),R,reset)-(1-theta)*oldscore(n,float(B),reset),xs)

def slice_weight(n,regs,reset=False):
 val=err=0.
 for a,b in regs:
  v,z=quad(lambda B:oldscore(n,float(B),reset),a,b,epsabs=2e-12,epsrel=2e-8,limit=100);val+=v;err+=z
 return val,err

def cover_report(n,radii,theta,reset=False):
 hits=[{'R':R,'B1_hit_intervals':fixed_region(n,R,theta,reset)} for R in radii]
 covered=merge([ab for z in hits for ab in z['B1_hit_intervals']]);bad=complement(covered)
 total,te=slice_weight(n,[(LOW,HIGH)],reset);lost,le=slice_weight(n,bad,reset)
 cuts=sorted({LOW,HIGH,*[x for z in hits for ab in z['B1_hit_intervals'] for x in ab]});cs=[]
 for a,b in zip(cuts,cuts[1:]):
  x=(a+b)/2;cs.append(sum(any(lo<=x<=hi for lo,hi in z['B1_hit_intervals']) for z in hits))
 positive=[c for c in cs if c>0]
 return {'theta':theta,'radius_count':len(radii),'slice_B1_hit_regions':hits,'slice_bad_B1_intervals':bad,'slice_oldscore_weighted_bad_fraction':lost/total,'slice_oldscore_integral_internal_scaled':total,'slice_badscore_integral_internal_scaled':lost,'slice_outer_quad_error_estimates':[te,le],'M_on_hit_slice_B1':len(radii)/min(positive) if positive else None,'scope':'B_rest=0 slice only, never full-E Ebad/Q','window_reset_artificial':reset}

def local_widths(n,theta):
 rows=[]
 for B in np.linspace(LOW,HIGH,17):
  B=float(B);R=r0(B);ps=list(np.linspace(1,2,65))+[R]
  hit=regions(lambda z:score(n,B,float(z))-(1-theta)*oldscore(n,B),ps)
  rows.append({'B1':B,'width':sum(b-a for a,b in hit),'R_intervals':hit})
 return {'theta':theta,'minimum_width_on_17_B1_nodes':min(z['width'] for z in rows),'maximum_width_on_nodes':max(z['width'] for z in rows),'rows':rows,'scope':'finite B1 nodes on slice; not a certified infimum'}

def model(n):
 print('BEGIN n',n,flush=True);start=time.perf_counter();fq=fullQ(n)
 xs=list(map(float,np.linspace(LOW,HIGH,33)))
 def quality(R):return min(score(n,B,float(R))/oldscore(n,B) for B in xs)
 rs=np.linspace(1,2,65);v=[quality(R) for R in rs];i=int(np.argmax(v));lo=rs[max(0,i-1)];hi=rs[min(64,i+1)]
 opt=minimize_scalar(lambda R:-quality(R),bounds=(lo,hi),method='bounded',options={'xatol':2e-8})
 bestR=float(opt.x);fineB=list(map(float,np.linspace(LOW,HIGH,129)));bestmin=min(score(n,B,bestR)/oldscore(n,B) for B in fineB)
 old_R515=[];best=[];reset=[];grids=[];width=[]
 for theta in [.1,.01]:
  old_R515.append(cover_report(n,[R515],theta));best.append(cover_report(n,[bestR],theta));reset.append(cover_report(n,[R515],theta,True))
  for K in [8,32,128]:grids.append({'K':K,**cover_report(n,list(map(float,np.linspace(1,2,K+1))),theta)})
  width.append(local_widths(n,theta))
 # Actual mass-window support C1 length at existing old/singleton radii, not artificial geometry volume.
 support=[]
 for B in [LOW,(LOW+HIGH)/2,HIGH]:
  for R in [r0(B),R515,bestR]:
   logm=n*math.log(R)+math.log(q(B,R));a=cfromr(math.exp((logm+LOG4)/n));b=cfromr(math.exp((logm-LOG4)/n))
   Rcmin=math.exp((logm-LOG4)/n);Rcmax=math.exp((logm+LOG4)/n)
   Cmin=LOW if Rcmax>=r0(LOW) else (HIGH if Rcmax<=r0(HIGH) else math.sqrt(1-Rcmax**2/12))
   Cmax=HIGH if Rcmin<=r0(HIGH) else (LOW if Rcmin>=r0(LOW) else math.sqrt(1-Rcmin**2/12))
   support.append({'B1':B,'R':R,'actual_C1_window_support_length':max(0.,Cmax-Cmin),'full_E1_length':HIGH-LOW})
 slice_alpha=[oldscore(n,B)*(2*e/REF)**(n-1)/(1+LOG4) for B in fineB]
 Evolume=(HIGH-LOW)*(2*e)**(n-1);An=1+n*math.log(2);sourceW=18*6**(n-1)
 assert n+1 < 15*16**(n-1) # rational sufficient soft-layer comparison, with log2<1.
 soft={'C':1+LOG4,'A_n':An,'threshold_1_over_A_n':1/An,'slice_alpha_min_on_129_B1_nodes':min(slice_alpha),'slice_alpha_max_on_nodes':max(slice_alpha),'full_E_alpha_upper_bound':Evolume/((1+LOG4)*(math.sqrt(57)/5)**n),'full_E_alpha_upper_divided_by_threshold':Evolume*An/((1+LOG4)*(math.sqrt(57)/5)**n),'whole_E_soft_layer_analytic_reason':'L_infty<=|E|/Rmin^n, ||k_B||_L1=qB=1; alpha<|E|, |E|*(n+1)<1 and A_n<n+1','W':str(sourceW),'full_Q_over_W':fq['Q_actual']/sourceW}
 print('DONE n',n,'Qnormalized',fq['Q_div_rest_center_measure_squared'],'Rbest',bestR,'min ratio fine nodes',bestmin,'oldR515 bad',[z['slice_oldscore_weighted_bad_fraction'] for z in old_R515],'best bad',[z['slice_oldscore_weighted_bad_fraction'] for z in best],flush=True)
 return {'n':n,'full_Q':fq,'soft_layer_relevance':soft,'R515_fixed_radius_reports':old_R515,'optimized_single_radius':{'R':bestR,'coarse_min_ratio_on_33_B1_nodes':quality(bestR),'min_ratio_on_129_B1_nodes':bestmin,'scope':'coarse R scan plus local scalar search; not certified optimal or full-E'},'optimized_single_radius_reports':best,'artificial_reset_n1_window_oldR515_reports':reset,'common_uniform_grid_reports':grids,'local_near_score_widths':width,'actual_window_support_diagnostics':support,'seconds':time.perf_counter()-start}

def main():
 start=time.perf_counter()
 z,gap,ee=sp.symbols('z gap ee',positive=True)
 assert sp.expand(2*sp.integrate((2*ee-z)*(z-gap),(z,gap,2*ee))-(2*ee-gap)**3/3)==0
 assert sp.expand(2*sp.integrate(z-gap,(z,gap,ee))-(ee-gap)**2)==0
 models=[model(n) for n in [1,4,16,64]]
 out={'scope':'exact tensor formulas, floating full Q integral, and expressly slice-only radius coverage exploration; no global asymptotic claim','environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},'model':{'source':'x1^2 1_|x1|<=3 times product 1_|xj|<=3','W':'18*6^(n-1)','E':'[5/6,9/10] times [-e,e]^(n-1)','e':e,'R_original':'sqrt(12(1-B1^2))','a':1,'b':2,'q_original':1,'gamma':4,'expanded_band':[.5,2.],'slice':'B2=...=Bn=0','slice_score_computational_scale':'actual_slice_score*(sqrt(3)/(2e))^(n-1)','full_Q_report_normalization':'Q/(2e)^(2(n-1)); internal quadrature further multiplies by sqrt(3)^(n-1)'},'models':models,'max_inner_quad_error_estimate_internal_scaled':MAXERR,'inner_quad_calls':NQUAD,'seconds':time.perf_counter()-start,'limitations':'quad estimates not rigorous; region root search can miss small components; slice-weighted loss is not full-E Ebad/Q; artificial window reset is not original kernel; no spatial-localization budget tested'}
 (ROOT/'r516_numeric.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE bounded tensor/full-Q/slice experiment; no strict certificate',flush=True)
if __name__=='__main__':main()
