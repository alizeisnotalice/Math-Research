#!/usr/bin/env python3
"""R693 corrected volume-residual rank and genuine first-half-crossing diagnostics."""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import json,hashlib,sys,time,platform
import numpy as np
import scipy
from scipy.optimize import linprog
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;start=time.time();ctx.prec=512
ZERO=(Q(0),);ONE=(Q(1),);BETA=Q(1,2)
FIXTURES=[{'id': 'nested_1D', 'n': 1, 'a': 32, 'parents': [{'center': ['2'], 'radius': '4'}, {'center': ['1'], 'radius': '2'}, {'center': ['1/2'], 'radius': '1'}, {'center': ['1/4'], 'radius': '1/2'}], 'packing_theta': ['1', '0', '0', '0'], 'dual_mask_prices': {'15': '8'}}, {'id': 'two_clusters_partial_core_2D', 'n': 2, 'a': 64, 'parents': [{'center': ['0', '0'], 'radius': '2'}, {'center': ['1/32', '0'], 'radius': '1'}, {'center': ['5', '0'], 'radius': '1'}, {'center': ['5', '1/64'], 'radius': '1/2'}], 'packing_theta': ['1', '0', '1', '0'], 'dual_mask_prices': {'3': '16', '12': '4'}}, {'id': 'multiscale_compass_2D', 'n': 2, 'a': 64, 'parents': [{'center': ['0', '0'], 'radius': '1'}, {'center': ['-5/4', '0'], 'radius': '3/4'}, {'center': ['5/4', '0'], 'radius': '3/4'}, {'center': ['0', '5/4'], 'radius': '1/2'}, {'center': ['0', '-5/4'], 'radius': '1/2'}], 'packing_theta': ['0', '1', '1', '1', '1'], 'dual_mask_prices': {'3': '9/4', '5': '9/4', '9': '1', '17': '1'}}, {'id': 'Sol_chain_1D', 'n': 1, 'a': 32, 'parents': [{'center': ['0'], 'radius': '3'}, {'center': ['4'], 'radius': '2'}, {'center': ['13/2'], 'radius': '1'}], 'packing_theta': ['1', '0', '1'], 'dual_mask_prices': {'3': '6', '6': '2'}}, {'id': 'Sol_star_1D', 'n': 1, 'a': 32, 'parents': [{'center': ['0'], 'radius': '2'}, {'center': ['-5/2'], 'radius': '3/2'}, {'center': ['5/2'], 'radius': '3/2'}], 'packing_theta': ['0', '1', '1'], 'dual_mask_prices': {'3': '3', '5': '3'}}]
# Frozen references to prior actual R692 finite runs; replay does not execute their priority rules.
RECORDED_R692_REFERENCES={'nested_1D': [{'algorithm': 'old_exp_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.45123367250304256965974454826467588449099708706183064709471821268442506725162027764366146915090902630503612545782977841357572183798826555850382920855435 +/- 8.99e-153]', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.45123367250304256965974454826467588449099708706183064709471821268442506725162027764366146915090902630503612545782977841357572183798826555850382920855435 +/- 8.99e-153]', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.45123367250304256965974454826467588449099708706183064709471821268442506725162027764366146915090902630503612545782977841357572183798826555850382920855435 +/- 8.99e-153]', 'order': [0, 1, 2, 3]}, {'algorithm': 'old_exp_volume_order', 'parameter_mode': 'rational_decay', 'objective': '1755/256', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'rational_decay', 'objective': '1755/256', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'rational_decay', 'objective': '1755/256', 'order': [0, 1, 2, 3]}], 'two_clusters_partial_core_2D': [{'algorithm': 'old_exp_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.0038838624306133331947661983315640929314971795936330958057018726264039250638719267282886518729533876025455754397119906974207715483915130828535029494206 +/- 5.81e-152]', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.0038838624306133331947661983315640929314971795936330958057018726264039250638719267282886518729533876025455754397119906974207715483915130828535029494206 +/- 5.81e-152]', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.0038838624306133331947661983315640929314971795936330958057018726264039250638719267282886518729533876025455754397119906974207715483915130828535029494206 +/- 5.81e-152]', 'order': [0, 2, 1, 3]}, {'algorithm': 'old_exp_volume_order', 'parameter_mode': 'rational_decay', 'objective': '125/8', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'rational_decay', 'objective': '125/8', 'order': [0, 1, 2, 3]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'rational_decay', 'objective': '125/8', 'order': [0, 2, 1, 3]}], 'multiscale_compass_2D': [{'algorithm': 'old_exp_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.00181230152590997059824043599437874538301549840768365672198877115978528103684521678235098497601454855574130982746206634165815465100223153657097528716277 +/- 4.11e-153]', 'order': [0, 1, 2, 3, 4]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.00181230152590997059824043599437874538301549840768365672198877115978528103684521678235098497601454855574130982746206634165815465100223153657097528716277 +/- 4.11e-153]', 'order': [0, 1, 2, 3, 4]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.00181230152590997059824043599437874538301549840768365672198877115978528103684521678235098497601454855574130982746206634165815465100223153657097528716277 +/- 4.11e-153]', 'order': [0, 1, 2, 3, 4]}, {'algorithm': 'old_exp_volume_order', 'parameter_mode': 'rational_decay', 'objective': '135/32', 'order': [0, 1, 2, 3, 4]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'rational_decay', 'objective': '135/32', 'order': [0, 1, 2, 3, 4]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'rational_decay', 'objective': '135/32', 'order': [0, 1, 2, 3, 4]}], 'Sol_chain_1D': [{'algorithm': 'old_exp_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.36352162311914528328173505226616949285191465670334906794304402767875566654582008425444411897706393806415079571125792599628827126997229044161544116111311 +/- 5.16e-153]', 'order': [0, 1, 2]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.36357987038186725322433506796937914673417889409584040701166315848963847195248730135933595090028662550937128808546139087594203164708999458993810524158738 +/- 4.63e-153]', 'order': [0, 1, 2]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.36357987038186725322433506796937914673417889409584040701166315848963847195248730135933595090028662550937128808546139087594203164708999458993810524158738 +/- 4.63e-153]', 'order': [0, 1, 2]}, {'algorithm': 'old_exp_volume_order', 'parameter_mode': 'rational_decay', 'objective': '45/8', 'order': [0, 1, 2]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'rational_decay', 'objective': '207/32', 'order': [0, 1, 2]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'rational_decay', 'objective': '27/4', 'order': [0, 2, 1]}], 'Sol_star_1D': [{'algorithm': 'old_exp_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.30198809207183344697795343875887506006136616449645940918668147416916252460299609296404291623368825904890333332386815661795379015694440019590597037004014 +/- 6.21e-153]', 'order': [0, 1, 2]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.30198809207183344697795343875887506006136616449645940918668147416916252460299609296404291623368825904890333332386815661795379015694440019590597037004014 +/- 6.21e-153]', 'order': [0, 1, 2]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'sqrt_dimension', 'objective': '[0.30198809207183344697795343875887506006136616449645940918668147416916252460299609296404291623368825904890333332386815661795379015694440019590597037004014 +/- 6.21e-153]', 'order': [0, 1, 2]}, {'algorithm': 'old_exp_volume_order', 'parameter_mode': 'rational_decay', 'objective': '33/8', 'order': [0, 1, 2]}, {'algorithm': 'remaining_volume_order', 'parameter_mode': 'rational_decay', 'objective': '33/8', 'order': [0, 1, 2]}, {'algorithm': 'remaining_adaptive', 'parameter_mode': 'rational_decay', 'objective': '33/8', 'order': [0, 1, 2]}]}

def cube(y,s):return [(v-s,v+s) for v in y]

def inside(p,B):return all(lo<v<hi for v,(lo,hi) in zip(p,B))

def volume(B):
 out=Q(1)
 for lo,hi in B:out*=hi-lo
 return out

def serial(v):
 if isinstance(v,Q):return str(v)
 if isinstance(v,(list,tuple)):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v

def ab(v):
 v=Q(v);return arb(v.numerator)/v.denominator

def geometry(fixture):
 n=fixture['n'];a=Q(fixture['a']);ps=fixture['parents'];parents=[cube([Q(v) for v in p['center']],Q(p['radius'])) for p in ps];cores=[cube([Q(v) for v in p['center']],Q(p['radius'])/a) for p in ps]
 axes=[]
 for t in range(n):
  ep=sorted(set(v for B in parents+cores for v in B[t]));axes.append([((lo+hi)/2,hi-lo) for lo,hi in zip(ep,ep[1:])])
 cells=[];vi=[Q(0)]*len(ps);V=Q(0);patterns={}
 for xx in product(*axes):
  point=[v[0] for v in xx];mass=Q(1)
  for v in xx:mass*=v[1]
  pb=[int(inside(point,B)) for B in parents];cb=[int(inside(point,B)) for B in cores];owner=next((j for j,b in enumerate(cb) if b),None)
  if owner is not None:vi[owner]+=mass;V+=mass
  if any(pb):
   mask=sum(v<<i for i,v in enumerate(pb));cells.append({'point':point,'mass':mass,'parent_bits':pb,'parent_mask':mask,'core_bits':cb,'owner':owner});patterns.setdefault(mask,pb)
 di=[volume(B) for B in parents];wi=[vi[i]/di[i] for i in range(len(ps))]
 assert sum(vi,Q(0))==V and V>0 and all(Q(0)<=w<=a**(-n) for w in wi)
 masks=sorted(patterns);rows=[patterns[m] for m in masks]
 th=[Q(v) for v in fixture['packing_theta']];prices={int(k):Q(v) for k,v in fixture['dual_mask_prices'].items()}
 assert all(sum((th[i]*row[i] for i in range(len(ps))),Q(0))<=1 for row in rows)
 assert all(m in patterns for m in prices)
 assert all(sum((value*patterns[mask][i] for mask,value in prices.items()),Q(0))>=di[i] for i in range(len(ps)))
 P=sum((d*t for d,t in zip(di,th)),Q(0));assert P==sum(prices.values(),Q(0))
 lp=linprog(-np.array([float(v) for v in di]),A_ub=np.array(rows,dtype=float),b_ub=np.ones(len(rows)),bounds=(0,None),method='highs');assert lp.success and abs(-lp.fun-float(P))<1e-10
 return {'parents':parents,'cores':cores,'cells':cells,'parent_masks':masks,'parent_rows':rows,'v_i':vi,'d_i':di,'w_i':wi,'V':V,'P0':P,'exact_packing_primal':th,'exact_dual_mask_prices':[{'mask':k,'mass':v} for k,v in prices.items()],'HiGHS_P0':float(-lp.fun),'owner_rule':'listed descending-radius order;E_j=B_j minus earlier B_i up to null faces'}

def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return tuple(p)

def add(p,q):return trim([(p[i] if i<len(p) else Q(0))+(q[i] if i<len(q) else Q(0)) for i in range(max(len(p),len(q)))])

def scale(p,c):return trim([Q(c)*v for v in p])

def sub(p,q):return add(p,scale(q,-1))

def mul(p,q):
 r=[Q(0)]*(len(p)+len(q)-1)
 for i,a in enumerate(p):
  for j,b in enumerate(q):r[i+j]+=a*b
 return trim(r)

def monomial(k):return (Q(0),)*k+(Q(1),)

def evaluate(p,z):
 r=Q(0) if isinstance(z,Q) else arb(0)
 for c in reversed(p):r=r*z+(c if isinstance(z,Q) else ab(c))
 return r

def compare(p,q,z):
 diff=sub(p,q)
 if diff==ZERO:return 0
 val=evaluate(diff,z)
 if val>0:return 1
 if val<0:return -1
 if isinstance(z,Q):return 0
 raise ArithmeticError('Unresolved Arb polynomial ordering; no uncertified adaptive branch is accepted')

def maximum(polys,z):
 best=ZERO
 for p in polys:
  if compare(p,best,z)>0:best=p
 return best

def sum_poly(polys):
 out=ZERO
 for p in polys:out=add(out,p)
 return out

def cap_info(j,theta,g,z):
 pairs=[(mask,sum_poly([theta[i] for i,b in enumerate(row) if b])) for mask,row in zip(g['parent_masks'],g['parent_rows']) if row[j]]
 top=maximum([p for mask,p in pairs],z)
 witnesses=[mask for mask,p in pairs if compare(p,top,z)==0]
 return sub(ONE,top),top,witnesses

def corrected_run(f,g,mode):
 n=f['n'];w=g['w_i'];di=g['d_i'];m=len(w);wmax=max(w);remaining=[j for j in range(m) if w[j]>0]
 if mode=='rational_decay':z=Q(1,2);t=ab(wmax)/arb(4).log();tdef='wmax/log4'
 else:t=arb(n).sqrt();z=(-ab(wmax)/(2*t)).exp();tdef='sqrt(n)'
 def num(poly):return str(evaluate(poly,z))
 def toarb(poly):
  v=evaluate(poly,z);return ab(v) if isinstance(v,Q) else v
 alpha=[sub(ONE,monomial(int(2*wj/wmax))) for wj in w]
 theta=[ZERO]*m;steps=[];events=[];crossed=set();all_observed_caps=[]
 maskrows=dict(zip(g['parent_masks'],g['parent_rows']))
 while remaining:
  candidates={j:cap_info(j,theta,g,z) for j in remaining}
  for j,(rj,top,masks) in candidates.items():all_observed_caps.append(rj)
  chosen=remaining[0]
  for j in remaining[1:]:
   c=compare(scale(candidates[j][0],di[j]),scale(candidates[chosen][0],di[chosen]),z)
   if c>0 or(c==0 and j<chosen):chosen=j
  ri=candidates[chosen][0];price=scale(ri,di[chosen]);th=mul(ri,alpha[chosen]);assert compare(ri,ZERO,z)>0 and compare(th,ZERO,z)>0
  theta[chosen]=th;remaining.remove(chosen)
  owner_mass=t*ab(di[chosen])*toarb(th);margin=ab(g['v_i'][chosen])-owner_mass;assert margin>0
  step={'step_one_based':len(steps)+1,'selected_label':chosen,'selected_radius':Q(f['parents'][chosen]['radius']),'selected_d':di[chosen],'r_polynomial':ri,'r_value':num(ri),'priority_polynomial':price,'priority_value':num(price),'theta_polynomial':th,'theta_value':num(th),'owner_portion_mass_t_d_theta':str(owner_mass),'owner_v':g['v_i'][chosen],'unused_owner_mass':str(margin),'before_capacity_by_label':{str(j):{'r_polynomial':candidates[j][0],'r_value':num(candidates[j][0]),'maximizing_masks':candidates[j][2]} for j in candidates}}
  steps.append(step)
  for j in remaining:
   rbefore=candidates[j][0];rafter,load,witnesses=cap_info(j,theta,g,z);all_observed_caps.append(rafter)
   if j in crossed:continue
   if compare(rbefore,(BETA,),z)>0 and compare(rafter,(BETA,),z)<=0:
    crossed.add(j);assert compare(load,(1-BETA,),z)>=0
    assert all(maskrows[mask][chosen] for mask in witnesses)
    decay=monomial(int(2*w[chosen]/wmax))
    assert compare((BETA,),mul(decay,ri),z)>=0
    assert compare((di[chosen],),scale(decay,di[j]),z)>0
    assert compare(price,(BETA*di[j],),z)>0
    witness_data=[]
    for mask in witnesses:
     row=maskrows[mask];contributors=[]
     for prev in steps:
      i=prev['selected_label']
      if not row[i]:continue
      rj_at_source=prev['before_capacity_by_label'][str(j)]['r_polynomial']
      assert compare(rj_at_source,(BETA,),z)>0
      assert compare(prev['priority_polynomial'],scale(rj_at_source,di[j]),z)>=0
      assert di[i]>BETA*di[j]
      contributors.append({'label':i,'source_radius':prev['selected_radius'],'source_d':di[i],'source_r_at_selection':prev['r_value'],'source_priority':prev['priority_value'],'target_r_before_source':num(rj_at_source),'theta_value':prev['theta_value'],'t_theta':str(t*toarb(prev['theta_polynomial'])),'owner_portion_mass':prev['owner_portion_mass_t_d_theta'],'source_d_greater_than_beta_target_d':True})
     witness_data.append({'mask':mask,'actual_positive_cell_representatives':[c['point'] for c in g['cells'] if c['parent_mask']==mask],'field_after':num(load),'t_field_after':str(t*toarb(load)),'t_half_threshold':str(t*ab(1-BETA)),'contributors':contributors})
    events.append({'target_label':j,'target_radius':Q(f['parents'][j]['radius']),'target_d':di[j],'target_owner_v':g['v_i'][j],'trigger_label':chosen,'trigger_step_one_based':len(steps),'r_before':num(rbefore),'r_after':num(rafter),'first_crossing_before_own_processing':True,'trigger_r_i':num(ri),'trigger_decay_exp_minus_wi_over_t':num(decay),'trigger_r_upper_beta_exp_wi_over_t':str(ab(BETA)/toarb(decay)),'trigger_r_bound_verified':True,'trigger_d_strictly_greater_than_decay_target_d':True,'all_source_size_floors_verified':True,'witnesses':witness_data})
 # Monotonicity ensures a low capacity at processing has exactlyone preceding first-cross event.
 for st in steps:
  j=st['selected_label'];assert (compare(st['r_polynomial'],(BETA,),z)<=0)==(j in crossed)
 objective=sum_poly([scale(theta[i],di[i]) for i in range(m)]);D=toarb(objective);assert D>0 and D<ab(g['P0'])
 loads=[]
 for mask,row in zip(g['parent_masks'],g['parent_rows']):
  field=sum_poly([theta[i] for i,b in enumerate(row) if b]);assert compare(ONE,field,z)>0
  loads.append({'mask':mask,'load':num(field),'one_minus_load':num(sub(ONE,field))})
 mincap=ONE
 for p in all_observed_caps:
  if compare(p,mincap,z)<0:mincap=p
 if not events:assert compare(mincap,(BETA,),z)>0
 return serial({'mode':mode,'t_definition':tdef,'t_Arb':str(t),'z':'1/2 exact' if isinstance(z,Q) else str(z),'algorithm':'choose max d_i*r_i;incrementtheta_i=r_i(1-exp(-w_i/t));originalID ties','order':[s['selected_label'] for s in steps],'steps':steps,'first_half_crossings':events,'first_crossing_count':len(events),'crossed_target_labels':sorted(crossed),'bad_owner_volume':sum((g['v_i'][j] for j in crossed),Q(0)),'minimum_unprocessed_capacity_observed':num(mincap),'empty_crossing_interpretation':'No half crossing actually occurs before own processing' if not events else None,'theta_polynomials':theta,'objective_polynomial':objective,'objective':num(objective),'exact_objective':num(objective) if isinstance(z,Q) else None,'D_over_V':str(D/ab(g['V'])),'sqrt_n_D_over_V':str(arb(n).sqrt()*D/ab(g['V'])),'D_over_P0':str(D/ab(g['P0'])),'all_parent_mask_loads':loads,'all_candidate_rank_cellmax_and_trigger_comparisons_certified':True,'all_owner_portion_masses_at_most_real_v':True})

small=[]
for f in FIXTURES:
 g=geometry(f);runs=[corrected_run(f,g,mode) for mode in ('sqrt_dimension','rational_decay')]
 small.append({'input':f,'fixed_owner_geometry':serial(g),'corrected_rank_runs':runs,'recorded_R692_comparisons_not_rerun':RECORDED_R692_REFERENCES[f['id']]})
print('five frozen corrected-rank small inputs completed',flush=True)
# Compressed true nested family: no N-length coordinate or event list.
r=ab(Q(15,16));nested=[]
for N in (64,256,4096):
 V=1-r**N
 for mode in ('sqrt_dimension','rational_decay'):
  if mode=='sqrt_dimension':t=arb(1);x=(-arb(1)/32).exp();count_expr=32*arb(2).log();m=23;assert count_expr>22 and count_expr<23
  else:t=arb(1)/(32*arb(4).log());x=arb(1)/4;count_expr=arb(1)/2;m=1
  assert x**m<arb(1)/2 and x**(m-1)>arb(1)/2
  D=2*(1-x)*(1-(r*x)**N)/(1-r*x);root_r=x**(m-1)
  if m<N:
   bad_count=N-m;bad_volume=r**m-r**N;trigger_d=2*r**(m-1);largest_bad_d=2*r**m
   assert bad_volume>0 and root_r<arb(1)/(2*x) and trigger_d>x*largest_bad_d
   sources=[]
   for i in range(m):
    ss=r**i;ri=x**i;th=(1-x)*ri;owner_v=ss/16;used=t*2*ss*th;assert owner_v-used>0 and 2*ss>largest_bad_d/2
    sources.append({'label_zero_based':i,'radius':str(ss),'d':str(2*ss),'r_at_selection':str(ri),'theta':str(th),'owner_v':str(owner_v),'owner_portion_mass':str(used),'source_size_floor_verified':True})
   event={'trigger_one_based_index':m,'trigger_zero_based_label':m-1,'contributing_source_count':m,'bad_descendant_labels_factorized':str(m)+'..'+str(N-1),'bad_descendant_count':bad_count,'bad_descendant_owner_volume_exact':'(15/16)^'+str(m)+'-(15/16)^'+str(N),'bad_descendant_owner_volume':str(bad_volume),'trigger_r_before':str(root_r),'descendant_r_after':str(x**m),'trigger_r_upper_beta_exp_w_over_t':str(arb(1)/(2*x)),'trigger_d':str(trigger_d),'largest_bad_target_d':str(largest_bad_d),'trigger_d_over_largest_bad_d_exact':'16/15','decay_exp_minus_w_over_t':str(x),'trigger_strengthened_bounds_passed':True,'crossing_t_field':str(t*(1-x**m)),'crossing_t_half_threshold':str(t/2),'source_owner_portions':sources}
  else:bad_count=0;bad_volume=arb(0);event=None
  assert t*D<V
  nested.append({'N':N,'n':1,'a':32,'r':'15/16','mode':mode,'t':str(t),'w_j':'1/32','V_exact':'1-(15/16)^'+str(N),'V':str(V),'P0_exact':'2','D_exact':'2(1-x)(1-((15/16)x)^N)/(1-(15/16)x)','D':str(D),'D_over_V':str(D/V),'raw_load_exact':str(Q(N,32)),'first_cross_count_formula':'m=ceil(32t log2);crossing only ifm<N','m_ceiling_argument':str(count_expr),'m_exact':m,'event':event,'bad_owner_volume':str(bad_volume),'bad_target_count':bad_count,'common_intersection_field':'1-x^m afterm selected sources','corrected_rank_order':'descendingradius since all remaining capacities equal and p_i=d_i*r_i','no_large_N_event_or_coordinate_enumeration':True})
print('six compressed first-crossing diagnostics completed',flush=True)
out={'scope':'Five frozen real-core direct finite entrances plus six compressed nested records. No original high-tau history, global source-reuse payment or uniform root guarantee is inferred. Only corrected priorityd_i*r_i is executed; failed immediate-score priority is not rerun.','python':sys.version,'platform':platform.platform(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'python_flint_version':flint.__version__,'precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'beta':'1/2','first_crossing_definition':'For an unprocessed positive-owner target j, first update fromr_j>1/2 tor_j<=1/2, withr_j computed overALL positive parent cells. All post-update maximizing masks are retained.','strengthened_trigger_checks':'trigger r_i<=beta exp(w_i/t),d_i>exp(-w_i/t)d_j;allprior contributing sources satisfy d_i>beta*d_j and paid owner mass<=v_i','small_fixtures':small,'compressed_nested_family':nested,'fragmentation_scope':'No new fragment-family event computed or grid enumerated. Prior R692 repair parameter certificates are not rerun and do not specify later first-cross events.','summary':{'small_input_count':5,'corrected_small_runs':10,'small_root_parameter_crossings':sum(r['first_crossing_count'] for s in small for r in s['corrected_rank_runs'] if r['mode']=='sqrt_dimension'),'small_rational_parameter_crossings':sum(r['first_crossing_count'] for s in small for r in s['corrected_rank_runs'] if r['mode']=='rational_decay'),'compressed_records':len(nested),'all_feasibility_and_first_crossing_checks_passed':True,'all_strengthened_trigger_and_owner_checks_passed':True},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'small_crossings':[{'id':s['input']['id'],'runs':[{'mode':r['mode'],'order':r['order'],'events':r['first_crossing_count'],'bad_owner_volume':r['bad_owner_volume'],'objective':r['objective']} for r in s['corrected_rank_runs']]} for s in small]},indent=2))
