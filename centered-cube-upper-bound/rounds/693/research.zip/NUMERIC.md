# R693 corrected capacity rank and genuine first-half crossings

## Outcome

Only the correct priority `p_i=d_i r_i` is executed. All five frozen real-core inputs pass the full-cell feasibility, selection-order and strengthened trigger checks. At t=sqrt(n), none of these small inputs has a half crossing before its target's own processing; those event lists are genuinely empty. At t=wmax/log4 there are12 actual first crossings in total.

The compressed nested family supplies the requested nontrivial root-parameter pressure: its first crossing occurs after23 selected parents at t=1, or after one at t=(1/32)/log4. Counts, actual disjoint bad-owner volumes, contributing source sizes and available owner portions are certified without enumerating a4096-parent coordinate/event list.

These are bounded direct finite-entry diagnostics. They do not prove a uniform value guarantee, a source-reuse payment, an original high-tau history or the centered-cube root theorem. In particular, many bad targets can share one trigger; the source floor alone does not pay that multiplicity.

## Fixed input and exact coefficient definitions

The five inputs and owner partitions are exactly the confirmed R692 ones: nested1D, two separated2D clusters with partial core overlap, multiscale2D compass, the1D chain `[-3,3],[2,6],[11/2,15/2]`, and the1D star `[-2,2],[-4,-1],[1,4]`. Every input is embedded in NUMERIC.py. All use a=32n and the original listed descending-radius disjointification

`Ei=Bi minus earlier cores`, `vi=|Ei|`, `wi=vi/di`.

These owners stay fixed under adaptive selection. Joint parent/core endpoint cells recompute the exact Lebesgue ledger. All original parents remain in the packing benchmark and cell constraints. Exact primal/dual certificates give the same P0 as R692; HiGHS only cross-checks those values.

For one common t, initialize F=0. For every positive-owner unprocessed label j, compute

`r_j=1−esssup_(Aj) F`, `p_j=d_j r_j`.

Choose the largest p_j, with original-label tie breaking, and add

`theta_j=r_j(1−exp(−w_j/t))`.

The alpha factor is **not in the rank**. The failed immediate-increment priority is not rerun. Prior R692 finite objectives/orders are frozen reference records only.

At t=wmax/log4 all weights have wi/wmax equal to one or one half. Setting `z=exp(−wmax/(2t))` gives z=1/2, so coefficients and comparisons are Fraction exact. At t=sqrt(n), exact rational polynomials in z are compared by512-bit Arb signs; identical polynomials certify exact ties. No uncertified branch or floating midpoint tie is accepted.

## First-crossing definition and quantities checked

Fix beta=1/2. After each selected increment, recompute every unprocessed target's capacity on **all** positive parent cells. Record j only on its first transition

`r_j_before>beta`, `r_j_after<=beta`.

Every maximizing mask after that crossing is retained, with actual positive cell representatives. Thus the argument does not freeze a witness before the maximum changes. A label whose capacity drops only after it was already processed is not called an unprocessed first-cross target.

At each event the script verifies the trigger i satisfies

`r_i<=beta exp(w_i/t)`,

`d_i>exp(−w_i/t)d_j`.

For every prior contributing source on each recorded crossing mask, it also checks the target had not crossed when that source was selected, its selected priority was at least the target's then-current priority, and `d_i>beta d_j`. The post-cross field is at least1−beta, so its t-weighted source rate is at least t(1−beta).

For every processed source, including sources outside crossing records, the available real owner portion has mass

`t d_i theta_i<=vi`.

The exact owner ledger and certified positive margin are stored. Existence of a measurable portion of that mass follows from Lebesgue nonatomicity. This availability does not authorize charging the same source portion independently to all targets that it influences.

Monotonicity is checked computationally through the equivalent condition: a positive-owner label is processed with capacity at most beta exactly when it has an earlier first-crossing record. Empty event lists are accompanied by a certified observed minimum capacity above beta.

## Five small input results

The following D/V values are displayed rounded; full512-bit balls or exact rational coefficients are retained.

| input | common t | corrected order | D/V | first crossings | real bad-owner volume |
|---|---|---|---:|---:|---:|
| nested1D | sqrt(n) | 0,1,2,3 | 0.962632 | 0 | 0 |
| nested1D | wmax/log4 | 0,1,2,3 | 14.625000 | 3 | 7/32 |
| two clusters2D | sqrt(n) | 0,2,1,3 | 0.707036 | 0 | 0 |
| two clusters2D | wmax/log4 | 0,2,1,3 | 2844.444444 | 2 | 5/8192 |
| compass2D | sqrt(n) | 0,1,2,3,4 | 0.706970 | 0 | 0 |
| compass2D | wmax/log4 | 0,1,2,3,4 | 1645.714286 | 4 | 13/8192 |
| chain1D | sqrt(n) | 0,1,2 | 0.969546 | 0 | 0 |
| chain1D | wmax/log4 | 0,2,1 | 18.000000 | 1 | 1/8 |
| star1D | sqrt(n) | 0,1,2 | 0.966362 | 0 | 0 |
| star1D | wmax/log4 | 0,1,2 | 13.200000 | 2 | 3/16 |

At the rational-decay parameter the exact objectives are1755/256,125/8,135/32,27/4,33/8 in the listed input order. For the chain the corrected order is(0,2,1); the separated clusters use(0,2,1,3). These scoped outputs happen to agree with the previously recorded immediate-score outputs on these five small inputs; that coincidence neither reruns nor validates the failed priority on general inputs.

No half crossing occurs at the root parameter in these small examples. This is reported as an empty event set, not replaced by an invented saturated configuration.

## Compressed true nested family and full counts

Use n=1,a=32,r=15/16, `s_j=r^j`, `y_j=s_j`, j=0,...,N−1, and N=64,256,4096. Parents are `[0,2s_j]`, real cores `[(31/32)s_j,(33/32)s_j]`. The strict rational inequality r<31/33 makes cores disjoint. Hence

`vi=r^j/16`, `wi=1/32`, `V_N=1−r^N`, `P0=2`.

The correct rank selects decreasing radii: every remaining capacity is the same after a nested prefix, so priority differs only by di. Put `x=exp(−1/(32t))`. After m selected parents, the common-intersection load is1−x^m and each unprocessed capacity is x^m. Therefore the first crossing count is exactly

`m=ceil(32t log2)`.

At t=1 the ceiling is23, certified between22 and23. At t=(1/32)/log4 the ceiling argument is exactly1/2, so m=1. If m>=N there would be no unprocessed descendants and the event would be empty; none of the six frozen cases falls in that branch.

The trigger is the m-th selected parent (zero-based label m−1), selected at capacity x^(m−1). Every later label m,...,N−1 crosses at that update. Their actual **disjoint owner volume**, not parent volume or a count surrogate, is

`sum_(j=m)^(N−1)vi=r^m−r^N`.

| N | t | trigger index, one based | bad descendant count | real bad-owner volume | D_N/V_N |
|---|---|---:|---:|---:|---:|
| 64 | 1 | 23 | 41 | 0.210566 | 0.683164 |
| 64 | (1/32)/log4 | 1 | 63 | 0.921425 | 1.991193 |
| 256 | 1 | 23 | 233 | 0.226641 | 0.673647 |
| 256 | (1/32)/log4 | 1 | 255 | 0.937500 | 1.959184 |
| 4096 | 1 | 23 | 4073 | 0.226641 | 0.673647 |
| 4096 | (1/32)/log4 | 1 | 4095 | 0.937500 | 1.959184 |

Each compressed record stores the full trigger/contributor count and the m source capacities, radii, di, theta and available owner masses; m is at most23. For all bad descendants simultaneously, the hardest source-size comparison is with the largest bad target j=m. The trigger ratio is exactly

`d_trigger/d_largest_bad=16/15>exp(−w/t)`.

Also x^m<1/2<x^(m−1), so the trigger capacity obeys `x^(m−1)<(1/2)/x`. These verify both strengthened trigger conditions with their true first-cross location. No later source or cell is substituted.

The value remains

`D_N=2(1−x)(1−(rx)^N)/(1−rx)`.

Raw common-parent loads are2,8,128. Thus a large raw load does not by itself imply a bad value on this family. Conversely, these nested examples do not settle the corrected rule on arbitrary product geometry.

No new fragment-family event is computed, no K/grid is enumerated, and the earlier R692 repair-parameter certificates are not rerun. They do not supply a frozen later tiny-phase first-cross formula.

## Reproducibility and stopping

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r693-20261116/NUMERIC.py
```

The code is standalone: fixed inputs, owner rules and prior reference records are embedded. RESULT.json records Python/platform/NumPy/SciPy/python-flint versions,512-bit precision, exact geometry and P0 certificates, all selected coefficients, all positive-mask loads, every first-cross witness and contributor, and the six compressed formulas and owner counts. No old priority algorithm or historical external file is executed during replay.

The run body took about0.042seconds. Ten corrected small runs and six compressed cases passed every feasibility, ranking, first-cross, strengthened-trigger and owner-portion check; errors are empty and the process exited with code zero. Source SHA-256: `7cd260a09e813879925a18403e699419d966611c0f8ccefe0fa88e8b75a6bf87`. Result SHA-256: `e64c8cd8f56f4aa384be53fb4d2353c5b0140610119feba776b5dbba1ae32245`.

Only the three owned R693 files were written. No extra scan, MATLAB, package installation, Git, PDF or subagent was used. Computation is stopped awaiting acceptance or a new author-frozen budget.
