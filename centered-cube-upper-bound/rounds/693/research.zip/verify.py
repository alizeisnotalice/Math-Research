from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,hashlib
from flint import arb,ctx
ctx.prec=768
p=Path(__file__).resolve().parent
out=json.loads((p/'RESULT.json').read_text())
assert hashlib.sha256((p/'NUMERIC.py').read_bytes()).hexdigest()==out['script_sha256']
def ab(x):
 x=F(x);return arb(x.numerator)/x.denominator
def trim(x):
 x=list(x)
 while len(x)>1 and x[-1]==0:x.pop()
 return tuple(x)
def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def neg(a):return tuple(-v for v in a)
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def sc(a,c):return trim([x*c for x in a])
def ev(a,z):
 v=F(0) if isinstance(z,F) else arb(0)
 for x in reversed(a):v=v*z+(x if isinstance(z,F) else ab(x))
 return v
def cmp(a,b,z):
 d=sub(a,b)
 if all(x==0 for x in d):return 0
 v=ev(d,z)
 if v>0:return 1
 if v<0:return -1
 if isinstance(z,F):return 0
 raise AssertionError('uncertified comparison')
def poly(x):return tuple(map(F,x))
O=(F(1),);Z=(F(0),);B=(F(1,2),)
numruns=events=0
for rec in out['small_fixtures']:
 inp=rec['input'];n=inp['n'];a=inp['a'];ps=inp['parents'];N=len(ps)
 parents=[[(F(y)-F(q['radius']),F(y)+F(q['radius'])) for y in q['center']] for q in ps]
 cores=[[(F(y)-F(q['radius'])/a,F(y)+F(q['radius'])/a) for y in q['center']] for q in ps]
 axes=[]
 for k in range(n):
  xx=sorted({x for b in parents+cores for x in b[k]});axes.append([( (x+y)/2,y-x) for x,y in zip(xx,xx[1:])])
 vi=[F(0)]*N;masks=set()
 for cell in product(*axes):
  x=[u[0] for u in cell];mass=F(1)
  for u in cell:mass*=u[1]
  def isin(b):return all(lo<xx<hi for xx,(lo,hi) in zip(x,b))
  mask=sum(1<<i for i,b in enumerate(parents) if isin(b))
  if mask:masks.add(mask)
  own=next((i for i,b in enumerate(cores) if isin(b)),None)
  if own is not None:vi[own]+=mass
 di=[(2*F(q['radius']))**n for q in ps];wi=[v/d for v,d in zip(vi,di)];wm=max(wi)
 assert vi==list(map(F,rec['fixed_owner_geometry']['v_i']))
 assert sorted(masks)==rec['fixed_owner_geometry']['parent_masks']
 pt=list(map(F,inp['packing_theta']));dual={int(k):F(v) for k,v in inp['dual_mask_prices'].items()}
 assert all(sum(pt[i] for i in range(N) if mask>>i&1)<=1 for mask in masks)
 assert all(sum(v for m,v in dual.items() if m>>i&1)>=di[i] for i in range(N))
 assert sum(d*x for d,x in zip(di,pt))==sum(dual.values())
 for run in rec['corrected_rank_runs']:
  numruns+=1;rat=run['mode']=='rational_decay';t=ab(wm)/arb(4).log() if rat else arb(n).sqrt();z=F(1,2) if rat else (-ab(wm)/(2*t)).exp()
  th=[Z]*N;remaining={i for i in range(N) if vi[i]};selected=[];cross={};rs={}
  def cap(j):
   vals=[]
   for mask in sorted(masks):
    if mask>>j&1:
     v=Z
     for i in range(N):
      if mask>>i&1:v=add(v,th[i])
     vals.append((mask,sub(O,v)))
   best=vals[0][1]
   for _,v in vals:
    if cmp(v,best,z)<0:best=v
   return best,[m for m,v in vals if cmp(v,best,z)==0]
  for st in run['steps']:
   before={j:cap(j)[0] for j in remaining};chosen=min(remaining)
   for j in sorted(remaining):
    if cmp(sc(before[j],di[j]),sc(before[chosen],di[chosen]),z)>0:chosen=j
   assert chosen==st['selected_label'];ri=before[chosen];rs[chosen]=ri
   assert ri==poly(st['r_polynomial'])
   k=2*wi[chosen]/wm;assert k.denominator==1;k=int(k)
   decay=(F(0),)*k+(F(1),);th[chosen]=mul(ri,sub(O,decay));assert th[chosen]==poly(st['theta_polynomial'])
   used=t*ab(di[chosen])*(ab(ev(th[chosen],z)) if rat else ev(th[chosen],z));assert used<ab(vi[chosen])
   selected.append(chosen);remaining.remove(chosen)
   for j in sorted(remaining):
    after,witnesses=cap(j)
    if j not in cross and cmp(before[j],B,z)>0 and cmp(after,B,z)<=0:
     cross[j]=chosen;events+=1
     assert cmp(mul(ri,decay),B,z)<=0
     assert cmp((di[chosen],),sc(decay,di[j]),z)>0
     for mask in witnesses:
      assert mask>>chosen&1
      for i in selected:
       if mask>>i&1:assert di[i]>di[j]/2
  assert len(cross)==run['first_crossing_count']
  assert {e['target_label']:e['trigger_label'] for e in run['first_half_crossings']}==cross
  assert sum(vi[j] for j in cross)==F(run['bad_owner_volume'])
  for j in rs:assert (cmp(rs[j],B,z)<=0)==(j in cross)
  # Independently reconstruct actual threshold forest and one-loss property at beta=1/2.
  for j in cross:
   q=j;seen=set()
   while q in cross:
    assert q not in seen;seen.add(q);i=cross[q]
    if i in cross:assert di[i]>di[q]
    q=i
   root=q
   assert cmp(rs[root],B,z)>0 and cmp(sub(rs[root],th[root]),B,z)<=0
   decay=(F(0),)*int(2*wi[root]/wm)+(F(1),)
   assert cmp((di[root],),sc(decay,di[j]),z)>0
  D=Z;W=Z
  for i in rs:D=add(D,sc(th[i],di[i]));W=add(W,sc(rs[i],vi[i]))
  assert D==poly(run['objective_polynomial'])
  assert th==[poly(v) for v in run['theta_polynomials']]
  for mask in masks:
   load=Z
   for i in range(N):
    if mask>>i&1:load=add(load,th[i])
   assert cmp(load,O,z)<0
  # Exact rational threshold integration by endpoint partition, independently of interval-length formula.
  if rat:
   r={i:ev(rs[i],z) for i in rs};theta={i:ev(th[i],z) for i in rs}
   cuts=sorted({F(0),F(1),*r.values(),*[r[i]-theta[i] for i in r]});roots=bad=F(0)
   for lo,hi in zip(cuts,cuts[1:]):
    beta=(lo+hi)/2
    roots+=(hi-lo)*sum(di[i] for i in r if r[i]-theta[i]<=beta<r[i])
    bad+=(hi-lo)*sum(vi[i] for i in r if r[i]<=beta)
   assert roots==ev(D,z) and bad==sum(vi)-ev(W,z)
for rec in out['compressed_nested_family']:
 N=rec['N'];q=arb(15)/16;x=(-arb(1)/32).exp() if rec['mode']=='sqrt_dimension' else arb(1)/4;m=23 if rec['mode']=='sqrt_dimension' else 1
 assert rec['m_exact']==m and x**m<arb(1)/2<x**(m-1)
 assert rec['bad_target_count']==N-m
 bad=q**m-q**N;assert bad>0 and bad.overlaps(arb(rec['bad_owner_volume']))
 D=2*(1-x)*(1-(q*x)**N)/(1-q*x);assert D.overlaps(arb(rec['D']))
# Exact symbolic coefficient check and independently executed fixed diagnostic from S2.
import sympy as s
u,P,Q=s.symbols('u P Q',positive=True)
assert s.simplify(1+s.integrate(1/u,(u,P,Q))+s.integrate(Q/u**2,(u,Q,s.oo))-(2+s.log(Q/P)))==0
A=1024;x=F(A-1,A);r=F(1);m=0
while r>F(1,2):r*=x;m+=1
assert m==710 and F(A-m)/x**(m-1)>600
assert 2*(1-x**A)==sum(F(2,A)*x**k for k in range(A))
# Certified scalar-threshold minimizers, serving the decision about scalar averaging only.
from scipy.optimize import brentq
for n in (4,16,64,256):
 c=F(32*n+1,32*n)
 root=brentq(lambda b:b**(1+1/n)+2*float(c)*b-float(c),0.1,0.5,xtol=1e-15)
 lo=F(str(root))-F(1,10**12);hi=F(str(root))+F(1,10**12)
 def signfun(b):return (ab(b).log()*(arb(1)+arb(1)/n)).exp()+2*ab(c)*ab(b)-ab(c)
 assert signfun(lo)<0<signfun(hi)
 # For objective enclosure use monotonic factors evaluated at exact bracket endpoints.
 L=(1+ab(c)*(-ab(hi).log()/n).exp())**n/(1-ab(lo))
 U=(1+ab(c)*(-ab(lo).log()/n).exp())**n/(1-ab(hi))
 assert L>2**n and U>L
 print('scalar n=',n,'beta bracket=',str(lo),str(hi),'M/2^n lower/upper=',str(L/2**n),str(U/2**n))
if (p/'MANIFEST.json').exists():
 for name,digest in json.loads((p/'MANIFEST.json').read_text())['sha256'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: independent geometry, exact P0 certificates, 10 corrected-rank runs,',events,'first crossings, actual forests, rational threshold integrals, 6 compressed records; 768-bit Arb. General global geometry remains unproved.')
