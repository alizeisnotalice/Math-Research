"""Full-shell approximation to ordinary first-hit weights; see REPORT.tex."""
import json,sys,random,math,os,socket
from multiprocessing import get_context
def trial(job):
    b,r,alpha,j=job
    n=1<<b; a=32*n; t=math.sqrt(n); L=math.log(n); R=n/(alpha*L)
    step=math.log1p(-2/a); W=-math.expm1(n*step); levels=math.ceil(t*math.log(2)/W)
    rng=random.Random((b*100000+r*1000+round(alpha*100))*99+j)
    lo=[-math.inf]*n; hi=[math.inf]*n
    for donor in range(r):
        # Complete layers before the last partial layer. Density in exposure
        # time is proportional to exp(-time/t); conditional word is uniform.
        exposed=-t*math.log1p(rng.random()*math.expm1(-(levels-1)*W/t))
        layer=int(exposed/W)
        s=R*math.exp(layer*step)
        first=min(n-1,int(math.log1p(-W*rng.random())/step))
        sign_index=(a-1)*rng.randrange(2)
        for k in range(n):
            digit=(rng.randrange(1,a-1) if k<first else sign_index if k==first else rng.randrange(a))
            y=s*((2*digit+1)/a-1)
            lo[k]=max(lo[k],y-s);hi[k]=min(hi[k],y+s)
    mvals=(1,2,4,8)
    penalties=[0.]*len(mvals)
    inv=0.;gap=0.;sites=0; collisions=0
    for k in range(n):
        x=rng.uniform(-1,1)
        gap=max(gap,lo[k]-x,x-hi[k])
        inv+=1/(hi[k]-lo[k])
        l=lo[k]-x;h=hi[k]-x
        if l<=-1 and h>=1:continue
        sites+=1
        if l>-1 and h<1:collisions+=1
        for i,m in enumerate(mvals):
            w=sum(1 if z in (0,m) else 2 for z in range(m+1) if l<=-1+2*z/m<=h)/(2*m)
            penalties[i]+=(-math.log(w) if w else math.inf)
    old=sum(math.log1p(2*gap/(u-l)) for l,u in zip(lo,hi))/(r*L)
    # Sufficient test using fixed admissible shifts inside an adaptive-color bank.
    new=[(v+(m+2)*math.log1p(2*inv)+math.log(m+2)+m*math.log(2))/(r*L) for m,v in zip(mvals,penalties)]
    return [b,r,alpha,sites,collisions,old,[v/(r*L) if math.isfinite(v) else None for v in penalties], [v if math.isfinite(v) else None for v in new],os.getpid()]
if __name__=='__main__':
    parity,cores,lo,hi,reps=map(int,sys.argv[1:])
    jobs=[(b,r,alpha,j) for b in range(lo,hi+1,2) for r in (2,4,8) for alpha in (.65,.80,.95) for j in range(parity,reps,2)]
    with get_context('fork').Pool(cores) as pool:rows=pool.map(trial,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),version=sys.version,args=sys.argv[1:],workers=len(set(y[-1] for y in rows)),rows=[y[:-1] for y in rows]),allow_nan=False))
