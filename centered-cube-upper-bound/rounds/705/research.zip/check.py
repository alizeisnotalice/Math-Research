from fractions import Fraction as F
from itertools import product
from math import comb,prod
from random import Random
import json,sys,flint
from flint import arb,ctx
rng=Random(705);cases=mass=0
for n in range(1,8):
    for _ in range(6):
        iv=[sorted(rng.choices(range(-6,7),k=2)) for k in range(n)]
        lengths=[rng.randint(1,9) for k in range(n)]
        for h in range(1,4):
            for c in product(range(h),repeat=n):
                lc=[(max([-3]+[iv[k][0] for k in range(n) if c[k]==g]),min([3]+[iv[k][1] for k in range(n) if c[k]==g])) for g in range(h)]
                clip=[(max(-3,l),min(3,u)) for l,u in iv]
                pred=all(l<=u for l,u in clip) and all(c[i]!=c[j] or max(clip[i][0],clip[j][0])<=min(clip[i][1],clip[j][1]) for i in range(n) for j in range(i))
                assert pred==all(l<=u for l,u in lc);cases+=1
            c=[rng.randrange(h) for k in range(n)]
            v=[sum((F(1,lengths[k]) for k in range(n) if c[k]==g),F(0)) for g in range(h)]
            b=sum(v)
            coeff=[F(1)]
            for a in v:
                coeff=[x+y for x,y in zip(coeff+[0],[0]+[w*a/b for w in coeff])]
            integral=sum(x/comb(h,k) for k,x in enumerate(coeff))
            assert 1<=integral<=2
            mass+=1
ctx.prec=192
out=[]
for m in (1,2,4,8,16,32,64):
    mean=arb(0)
    for j in range(m):
        x=arb(2*j+1)/(2*m)
        mean-=(x*x.log()+(1-x)*(-x).log1p())/m
    assert mean>arb(1)/2
    out.append([m,str(mean),str(1/(2*mean))])
print(json.dumps(dict(python=sys.version,flint=flint.__version__,precision=ctx.prec,colorings=cases,mass_checks=mass,entropy=out)))
