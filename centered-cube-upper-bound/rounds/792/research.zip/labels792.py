"""R792: private actual price labels under one public inverse-density cap."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys

import price792 as original


ETA = F(3,4)


def total(xs):
    return sum(xs,F(0))


def scaled_physical(n, parents, cells, raw, scale, geom, physical):
    """Pull back the actual density and scale masses of every parent and mark."""
    if scale == 1:
        return parents, cells, raw
    S = scale**n
    translated = [geom.Parent(p.c*scale,p.s*scale,p.m*S,p.owner*S,p.keep) for p in parents]

    def new_overlap(p,q):
        lo=max(p.c-p.s,q.c-q.s)
        hi=min(p.c+p.s,q.c+q.s)
        return scale*physical.mu1(lo/scale,hi/scale,original.AMP)*(2*min(p.s,q.s))**(n-1)

    K0, K1 = {}, {}
    for (i,p), (j,q) in product(enumerate(parents), repeat=2):
        J0 = physical.parent_overlap(n,p,q,original.AMP)
        J1 = new_overlap(translated[i],translated[j])
        assert J1 == S*J0
        if p.m != q.m and 0 < J0 <= ETA*min(p.m,q.m):
            K0[i,j] = J0/(p.m*q.m)
            K1[i,j] = J1/(translated[i].m*translated[j].m)
    d0 = {v:total(parents[u].owner*k for (i,u),k in K0.items() if i==v)
          for v in range(len(parents))}
    d1 = {v:total(translated[u].owner*k for (i,u),k in K1.items() if i==v)
          for v in range(len(parents))}
    assert d1 == d0
    for p,q in zip(parents,translated):
        assert new_overlap(q,q) == q.m == (2*q.s)**n
        assert q.owner == (2*q.s/(32*n))**n
        assert q.keep == p.keep
    for v,state in enumerate(translated):
        if d1[v]:
            a = parents[v].owner/(d0[v]*parents[v].m**2)
            b = state.owner/(d1[v]*state.m**2)
            assert a * S == b * S**2
    return translated,{x:S*m for x,m in cells.items()},{
        x:{r:S*w for r,w in law.items()} for x,law in raw.items()}


def side_totals(block):
    by_v, by_z = defaultdict(F),defaultdict(F)
    for (v,z),w in block.items():
        by_v[v]+=w
        by_z[z]+=w
    return by_v,by_z


def actual_private_cost(law, cap):
    group = total(law.values())
    total_hit = total(r*s/group for (v,z),r in law.items()
                      for (w,_),s in law.items() if w in z)
    direct = total(r*s/(group*cap[z]) for (v,z),r in law.items()
                   for (w,_),s in law.items() if w in z)
    assert 0 <= total_hit <= group
    return direct, total_hit


def row(n, parents, x, d, types, physical, price_cells):
    D=F(2)**d
    xm=price_cells[x]
    pub_v, pub_z = side_totals(physical)
    pop=total(physical.values())
    from_private=defaultdict(F)
    for law in types.values():
        for pair, val in law.items():
            from_private[pair]+=val
    assert from_private==physical
    cap={z:r/(xm*price_cells[z]) for z,r in pub_z.items()}
    assert all(mu>0 for mu in cap.values())
    weights={t:total(law.values())/pop for t,law in types.items()}
    assert sum(weights.values())==1
    original_raw, original = F(0),F(0)
    weighted, same_time_order, public_multiplied_back, live_bound = (F(0) for _ in range(4))
    cap_tests=0
    mark_details=[]
    for t,law in sorted(types.items()):
        s=total(law.values())
        r_t,p_t=side_totals(law)
        q={z:w/(xm*price_cells[z]) for z,w in p_t.items()}
        assert all(0<val<=cap[z] for z,val in q.items())
        cap_tests+=len(q)
        direct, raw=actual_private_cost(law,cap)
        original+=direct
        original_raw+=raw
        weighted+=weights[t]*direct
        weighted_mean=total(
            mass/s*total(price_cells[z]*q[z]/cap[z] for z in p_t if v in z)
            for v,mass in r_t.items()
        )
        from_switched=xm*weighted_mean
        assert direct==from_switched
        assert 0 < from_switched <= xm*total(r/s*parents[v].m for v,r in r_t.items()) < 2*D*xm
        same_time_order+=weights[t]*from_switched
        # Draw the label at its true public marginal, then pay its fixed weight.
        public_multiplied_back+=pop*(s/pop)*weights[t]*(direct/s)
        live_bound+=weights[t]*xm*total(r/s*parents[v].m for v,r in r_t.items())
        mark_details.append(dict(t=t, posterior_w=weights[t], original_label_mass=s,
                                 assigned_middle_labels=sorted(r_t),
                                 true_inverse_cap_hit=direct, true_raw_hit=raw))
    assert weighted==same_time_order==public_multiplied_back<=live_bound<2*D*xm
    unmarked, unmarked_raw=actual_private_cost(physical,cap)
    no_mark_swap=xm*total(m/pop*total(price_cells[z] for z in pub_z if v in z)
                         for v,m in pub_v.items())
    assert unmarked==no_mark_swap
    if len(pub_v)==1:
        assert original==unmarked and original_raw==unmarked_raw==pop
    return dict(x=x,d=d,D=D,mu_of_exact_x_cell=xm,old_public_pop_raw=pop,
                actual_original_middle_labels=sorted(pub_v),
                t_values=mark_details, positive_cap_cells_checked=cap_tests,
                fee_w_times_private_conditional_pair=weighted,
                same_t_without_the_fixed_weight=original,
                ignore_t_use_public_pair=unmarked,
                unweighted_same_t_actual_unweighted_hit_mass=original_raw,
                ignore_t_actual_unweighted_hit_mass=unmarked_raw,
                inverse_cap_bound_from_actual_new_mid_volume=live_bound,
                public_cap=2*D*xm,
                capped_fee_divide_by_D=weighted/D,
                qcap_positive_cells=[(z,mu) for z,mu in sorted(cap.items())])


def certificate(n,stage,scale,private,geom,physical):
    parents=geom.instances(n,stage)
    cells,raw,_,_=original.build_original(n,parents,physical,geom)
    parents,cells,raw = scaled_physical(n,parents,cells,raw,scale,geom,physical)
    frozen=defaultdict(lambda:defaultdict(lambda:defaultdict(F)))
    public=defaultdict(lambda:defaultdict(F))
    for x, records in raw.items():
        for (i,v,g,z),m in records.items():
            d=geom.floor_log2(parents[v].m)
            t=v if private=="middle" else int(0 in z)+2*int(1 in z)
            assert v in z and v in x and F(2)**d<=parents[v].m<F(2)**(d+1)
            frozen[x,d][t][v,z]+=m
            public[x,d][v,z]+=m
    rows=[row(n,parents,x,d,ts,public[x,d],cells)
          for (x,d),ts in sorted(frozen.items())]
    Q=total(r["old_public_pop_raw"] for r in rows)
    assert Q==total(w for records in raw.values() for w in records.values())
    W=total(r["fee_w_times_private_conditional_pair"] for r in rows)
    U=total(r["same_t_without_the_fixed_weight"] for r in rows)
    N=total(r["ignore_t_use_public_pair"] for r in rows)
    assert 0<W<U
    scaled=total(r["capped_fee_divide_by_D"] for r in rows)
    bound=total(r["public_cap"] for r in rows)
    scaled_bound=2*total(r["mu_of_exact_x_cell"] for r in rows)
    assert W<bound and scaled<scaled_bound
    rawt=total(r["unweighted_same_t_actual_unweighted_hit_mass"] for r in rows)
    rawn=total(r["ignore_t_actual_unweighted_hit_mass"] for r in rows)
    witness=max(rows,key=lambda r:(abs(r["same_t_without_the_fixed_weight"] -
                                        r["ignore_t_use_public_pair"])/r["public_cap"],
                                   (r["same_t_without_the_fixed_weight"] -
                                    r["fee_w_times_private_conditional_pair"])/r["public_cap"]))
    shifted=scale != 1
    many=sum(len(r["actual_original_middle_labels"])>1 for r in rows)
    if shifted:
        assert many>0 and U!=N and rawt!=rawn
    else:
        assert many==0 and U==N and rawt==rawn==Q
    return dict(
        n=n,dilation_of_every_coordinate=scale,
        mass_scale=scale**n, phase_period_after_dilation=scale/8, private_rule=private,
        true_record_count=sum(map(len,raw.values())), public_x_d_rows=len(rows),
        public_rows_with_multiple_t=sum(len(r["t_values"])>1 for r in rows),
        public_rows_with_multiple_middle_labels=many,
        checked_positive_private_density_cells=sum(r["positive_cap_cells_checked"] for r in rows),
        total_original_peak_Q=Q,
        weighted_actual_fee=W,no_pay_w_fee=U,ignore_private_label_fee=N,
        weighted_actual_fee_over_its_public_bound=W/bound,
        no_pay_w_fee_over_same_bound=U/bound,ignore_private_label_over_same_bound=N/bound,
        weighted_fee_divided_by_each_its_D=scaled,sum_public_2D_times_mu_x=bound,
        sum_divided_public_bound=scaled_bound,
        weighted_divided_fee_over_its_bound=scaled/scaled_bound,
        raw_hit_rate_same_t=rawt/Q,raw_hit_rate_public=rawn/Q,
        unweighted_rows_going_over_2D=sum(r["same_t_without_the_fixed_weight"]>
                                          r["public_cap"] for r in rows),
        ignoring_t_rows_going_over_2D=sum(r["ignore_t_use_public_pair"]>
                                         r["public_cap"] for r in rows),
        public_rows_distinguishing_same_t_vs_ignore=sum(
            r["same_t_without_the_fixed_weight"]!=r["ignore_t_use_public_pair"] for r in rows),
        exact_nontrivial_left_price_block=witness)


def corner_check():
    rows = []
    for tau in (F(1,4),F(1,2),F(3,4)):
        # An exact low-dimensional physical corner family with same-sign centres.
        for sign in product((-1,1),repeat=4):
            for signs_are_corner in product((2-tau,F(2)),repeat=4):
                assert all(abs(s*z-s)<=1 for s,z in zip(sign,signs_are_corner))
        choices=[]
        for n in (4,16,2**20):
            h=1+F(1,32*n)
            t=(1+tau)*(tau+2*(h-1))/h
            assert (t>1)==(tau==F(3,4)) and (t<1)==(tau!=F(3,4))
            choices.append(dict(n=n,h=h,exact_scalar=t,above_one=t>1))
        rows.append(dict(tau=tau,true_sign_corners_in_n4=16,all_axes_in_the_same_sign_cube=True,
                         scalar_checks=choices))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--phase-dir",type=Path)
    p.add_argument("--geometry-dir",type=Path)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=p.parse_args()
    for path in (args.phase_dir,args.geometry_dir):
        if path:
            sys.path.insert(0,str(path))
    import common791 as physical
    import merges789 as geom
    result=dict(
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        arithmetic=("Exact Fraction throughout. Excessively long outputs are rendered "
                    "as exact outward decimal brackets with an exact fraction checksum."),
        command="python -B labels792.py --check labels792.json",
        dependencies={name:sha256(Path(module.__file__).read_bytes()).hexdigest()
                      for name,module in (("price792.py",original),("common791.py",physical),("merges789.py",geom))},
        scope=("Finite true R791/R792 cubes at source phase amplitude 1/2. "
               "Use the inherited nonproduct gate and actual full degrees. "
               "The ordinary cases use t equal to the private right price's real membership bits in parents 0 and 1. "
               "As a pressure example use a physical common dilation by 31/32, retaining ordinary absolute dyadic bins "
               "and taking the actual middle label as t. The phase period is dilated so actual masses scale by the volume. "
               "The separate corner arithmetic concerns a distinct finite geometry."),
        canonical_cases=[certificate(n,j,F(1),"z_members_in_A0_A1",geom,physical)
                         for j,n in enumerate((4,8,16),1)],
        actual_rescaled_pressure=certificate(4,1,F(31,32),"middle",geom,physical),
        optional_corner_check=corner_check())
    data=(json.dumps(result, sort_keys=True,indent=2,default=original.encode_fraction)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    elif args.check:
        if args.check.read_bytes()!=data:
            raise SystemExit("certificate differs")
        print("labels792: true private-label weights, inverse cap and genuine rescaled pressure agree")
    else:
        print(data.decode(),end="")


if __name__=="__main__":
    main()

