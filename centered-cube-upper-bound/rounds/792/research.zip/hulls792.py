"""Actual ownership bounds, exact side events with exterior points, and scalar checks."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from math import prod
from pathlib import Path
import platform
import sys

from flint import arb, ctx
import common791 as phase
import merges789 as geom

ctx.prec = 256
AMP = F(1, 2)


def boxes(n, stage):
    parents = geom.instances(n, stage)
    h = 1 + F(1, 32*n)
    bins = sorted({geom.floor_log2(p.m) for p in parents})
    tests, both, strict, witness = 0, 0, 0, None
    for d in bins:
        D = F(2)**d
        mids = [p for p in parents if D <= p.m < 2*D]
        s = h*max(p.s for p in mids)
        for cut in (F(3, 4), F(7, 8), F(15, 16)):
            small = [p for p in parents if h*p.s <= cut*s]
            if not small:
                continue
            t = max(h*p.s for p in small)
            for loc in sorted({p.c for p in parents} | {F(0)}):
                for level in (F(1, 32), F(1, 4), F(1, 2), F(3, 4)):
                    rw = [level*s*(1 if j % 2 == 0 else F(2, 3)) for j in range(n)]
                    # The first coordinate carries the true periodic source.
                    endpoint = F(0)
                    charged_owners = F(0)
                    for g in small:
                        lo, hi = max(loc-rw[0], g.c-g.s), min(loc+rw[0], g.c+g.s)
                        clipped = phase.mu1(lo, hi, AMP)*prod(2*min(r, g.s) for r in rw[1:])
                        endpoint += g.keep*g.owner*clipped/g.m
                        if clipped:
                            charged_owners += g.owner
                    central = sum((v.owner/v.m for v in mids
                                   if abs(v.c-loc)+rw[0] <= v.s
                                   and all(r <= v.s for r in rw[1:])), F(0))
                    outer = prod(2*(r+t) for r in rw)
                    inner = prod(2*(s-r) for r in rw)
                    assert endpoint <= charged_owners <= outer
                    assert central <= inner/D
                    joint = endpoint*central/D
                    shape = prod(((r+t)/s)*(1-r/s) for r in rw)
                    sharp = ((1+t/s)/2)**(2*n)
                    assert joint <= ((2*s)**n/D)**2*shape
                    assert shape <= sharp and (2*s)**n/D <= 2*h**n
                    tests += 1
                    if joint:
                        both += 1
                        strict += int(endpoint < charged_owners and central < inner/D)
                        ratio = joint/(((2*s)**n/D)**2*shape)
                        if witness is None or ratio > witness[0]:
                            witness = (ratio, d, cut, loc, level, endpoint, central)
    assert strict and witness
    return dict(n=n, tests=tests, positive_both=both, both_strict=strict,
                representative=[str(w) for w in witness])


def occupancy(points, box, target):
    # Independent Poisson counts of mean log(2), indexed even at coincident locations.
    inside = [all(lo <= p[j] <= hi for j, (lo, hi) in enumerate(box)) for p in points]
    m = len(points)
    assert 0 < sum(inside) < m
    upper_lower = []
    for j, z in enumerate(target):
        for sign in (-1, 1):
            count = sum(ok and sign*p[j] >= sign*z for p, ok in zip(points, inside))
            upper_lower.append(1-F(1, 2)**count)
    no_out = F(1, 2)**(m-sum(inside))
    exact, without_restriction = 0, 0
    for b in product((0, 1), repeat=m):
        if not any(b):
            continue
        chosen = [p for p, bit in zip(points, b) if bit]
        hits = all(min(p[j] for p in chosen) <= v <= max(p[j] for p in chosen)
                   for j, v in enumerate(target))
        without_restriction += int(hits)
        exact += int(hits and all(not bit or ok for bit, ok in zip(b, inside)))
    ans = F(exact, 2**m)
    assert 0 < no_out*prod(upper_lower) <= ans < F(without_restriction, 2**m)
    return dict(points=points, box=box, target=target, probability=str(ans),
                lower_product=str(no_out*prod(upper_lower)), no_outside=str(no_out),
                ignored_outside=str(F(without_restriction, 2**m)))


def signed_boxes(n, level):
    # Direct enumeration of possible central owner signs and of physical small-owner volumes.
    # Deterministic shape factors only, without a claim of an extremizing input.
    h = 1 + F(1, 32*n)
    alpha = F(1)-level
    width = level/8
    bins = {1:(1-width,1+width), -1:(-1-width,-1+width)}
    unit_cost = (1-(1-width)/(2*h))*(alpha+width/h)
    direct = F(0)
    for signs in product((-1,1),repeat=n):
        intervals = [bins[t] for t in signs]
        phi = prod(1-min(abs(l),abs(r))/(2*h) for l,r in intervals)
        charge = prod(alpha+(r-l)/(2*h) for l,r in intervals)
        direct += phi*charge
    assert direct == (2*unit_cost)**n
    return dict(n=n, rational_gap_surrogate=str(level), signs=2**n,
                full_expression=str(direct))


def arb_rows():
    results = []
    for exponent in (112, 128, 160, 224):
        n = arb(2)**exponent
        J = n.sqrt()*(n+2).log()**8
        u = J/n
        h = 1 + 1/(32*n)
        alpha = (-u).exp()
        tau = arb(3).sqrt()-1+u/16
        pair = ((tau+2*(h-1))/h)*(alpha+tau/(2*h))
        square = ((1+(1-alpha)/4+alpha)/2)**2
        assert 0 < u and u < arb(1)/4
        assert -pair.log()/u > arb(1)/4
        assert -square.log()/u > arb(1)/2
        width = u/8
        moderate = (2-(1-width)/h)*(alpha+width/h)
        assert -moderate.log()/u > arb(1)/2
        values = (-pair.log()/u, -square.log()/u, -moderate.log()/u)
        bounds = []
        for y in values:
            # Outward rational enclosure of a quantity evaluated in Arb.
            scale = 2**42
            l = int((y*scale).lower().floor().unique_fmpz())
            r = int((y*scale).upper().ceil().unique_fmpz())
            assert y >= arb(l)/scale and y <= arb(r)/scale
            bounds.append([l, r, scale])
        results.append(dict(n_power_of_two=exponent, corner_soft_box_moderate_rates=bounds))
    return results


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", type=Path)
    group.add_argument("--output", type=Path)
    args = parser.parse_args()
    trials = [occupancy([[-1,-1],[1,1],[-1,1],[3,0]],
                        [[-1,1],[-1,1]],[0,0]),
              occupancy([[0,0],[0,0],[1,-1],[-1,1],[3,0],[0,-2]],
                        [[-1,1],[-1,1]],[0,0]),
              occupancy([[2,-1,-1],[-1,2,-1],[-1,-1,2],[-2,1,1],[1,-2,1],[1,1,-2],[4,0,0]],
                        [[-2,2],[-2,2],[-2,2]],[0,0,0])]
    data = dict(geometry=[boxes(n, i) for i,n in enumerate((4,8,16), 1)],
                exterior_Poisson_occupancy=trials, scalar_Arb=arb_rows(),
                exact_signed_sums=[signed_boxes(n,F(1,d)) for n,d in ((4,5),(8,8),(12,16))],
                interpreter=sys.executable, python=platform.python_version(), arb_bits=ctx.prec,
                scope="True periodic finite boxes test ownership. Poisson examples test exterior and side events. "
                      "Very large dimensions enter only in the analytic scalar formulas.")
    blob = (json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(blob)
    else:
        assert args.check.read_bytes()==blob
    print("PASS real box pairs", [(x["tests"],x["positive_both"]) for x in data["geometry"]],
          "outside events", [x["probability"] for x in trials], "Arb",len(data["scalar_Arb"]))


if __name__ == "__main__":
    main()
