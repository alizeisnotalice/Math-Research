"""R792: two genuine conditional peaks and finite random price rectangles."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import sys


AMP = F(1, 2)
ETA = F(3, 4)


def total(xs):
    return sum(xs, F(0))


def build_original(n, p, physical, geom):
    cells, _ = physical.cells_on_box(n,p,AMP)
    J, d, old, _, unfiltered = physical.marks_and_coefficients(n,p,cells,AMP)
    down = {v: {u for u,g in enumerate(p) if g.m < p[v].m and 0 < J[v,u] <= ETA*g.m}
            for v in range(len(p))}
    arms = {}
    for x, mu in sorted(cells.items()):
        entries = []
        for u in x:
            cap = p[u].keep*p[u].owner*mu/p[u].m
            possible = tuple(v for v in x if u in down[v])
            if possible:
                entries.append((u,possible,cap))
        if entries:
            arms[x] = entries
    by_left_x = {}
    for x, lefts in arms.items():
        out = defaultdict(F)
        for z, rights in arms.items():
            for u, a, wa in lefts:
                for g, b, wb in rights:
                    for v in sorted(set(a)&set(b)):
                        frac = F((u+g+v+len(a)*len(b))%5,4)
                        if frac:
                            out[u,v,g,z] += p[v].owner*wa*wb*frac/(d[v]*p[v].m**2)
        if out:
            by_left_x[x] = out

    def aggregate(fine):
        joint = defaultdict(F)
        for local in fine.values():
            for (u,v,g,z),mass in local.items():
                joint[u,v,g] += mass
        return joint

    coarse_old = defaultdict(F)
    for u,g,v,mass in old:
        coarse_old[u,v,g] += mass
    assert aggregate(by_left_x) == coarse_old
    assert 0 < total(coarse_old.values()) < unfiltered
    # Confirm the inherited finite gate gives a genuine nonproduct law at some middle.
    true_joint = defaultdict(F)
    true_left, true_right, total_v = defaultdict(F), defaultdict(F), defaultdict(F)
    for x, local in by_left_x.items():
        for (u,v,g,z), mass in local.items():
            a,b = (u,x),(g,z)
            true_joint[v,a,b] += mass
            true_left[v,a] += mass
            true_right[v,b] += mass
            total_v[v] += mass
    nonprod = next((v,a,b) for (v,a,b),w in true_joint.items()
                   if w*total_v[v] != true_left[v,a]*true_right[v,b])
    v,a,b = nonprod
    proof_nonprod = (v,a,b,true_joint[v,a,b]/total_v[v],
                     true_left[v,a]*true_right[v,b]/total_v[v]**2)
    return cells, by_left_x, total_v, proof_nonprod


def couple(fibers, middles):
    pair = defaultdict(F)
    q = F(0)
    for x, local in sorted(fibers.items()):
        M = total(local.values())
        assert M > 0
        q += M
        for u, v in product(local, repeat=2):
            pair[u,v] += local[u]*local[v]/M
    assert all(pair[u,v] == pair[v,u] for u, v in pair)
    assert {v:total(w for (u,j),w in pair.items() if j==v) for v in middles} == middles
    assert {v:total(w for (i,u),w in pair.items() if i==v) for v in middles} == middles
    assert q == total(pair.values()) == total(middles.values())
    return pair


def bins(pair, parents, geom):
    pieces = defaultdict(F)
    labels = [geom.floor_log2(x.m) for x in parents]
    crossed = defaultdict(F)
    for (v,w), weight in pair.items():
        gap = abs(labels[v]-labels[w])
        pieces[min(gap,2)] += weight
        crossed[labels[v],labels[w]] += weight
    assert total(pieces.values()) == total(crossed.values()) == total(pair.values())
    Q = total(pair.values())
    return dict(same_adjacent_far_mass=[pieces[k] for k in range(3)],
                same_adjacent_far_share=[pieces[k]/Q for k in range(3)],
                actual_dyadic_bin_pair_masses=[(u,v,w) for (u,v),w in sorted(crossed.items())])


def case(n, stage, physical, geom):
    p = geom.instances(n,stage)
    cells, R, middles, nonprod = build_original(n,p,physical,geom)
    genuine = {}
    events = {}
    split_participating_v = defaultdict(F)
    full_record_margins_checked = 0
    for x, records in sorted(R.items()):
        q = total(records.values())
        local = defaultdict(F)
        right_event = defaultdict(F)
        for (u,v,g,z), w in records.items():
            local[v] += w
            for target in z:
                right_event[target] += w
        # Exact row and column sums on every complete first/second record.
        # Accumulating one dimension of the product gives this shared q once.
        partner_mass = total(local.values())
        for w in records.values():
            assert w*partner_mass/q == partner_mass*w/q == w
            full_record_margins_checked += 2
        for v, value in local.items():
            split_participating_v[v] += value
        genuine[x] = dict(local)
        events[x] = dict(right_event)
    assert split_participating_v == middles
    # Both mechanisms preserve every whole original record. For independent
    # auxiliary price, its (label, original two marks) simply receives x from rho_v.
    for v in middles:
        assert total(mu/p[v].m for x,mu in cells.items() if v in x) == 1
    additional = {x:{v:R_v*mu/p[v].m for v,R_v in middles.items() if v in x}
                  for x,mu in sorted(cells.items()) if any(v in x for v in middles)}
    Q = total(middles.values())
    C, FRESH = couple(genuine,middles), couple(additional,middles)
    distance = total(abs(C.get(key,0)-FRESH.get(key,0)) for key in set(C)|set(FRESH))/(2*Q)
    assert 0 < distance < 1
    labels = sorted(middles)
    fwd = {key:value for key,value in sorted(C.items())}
    old_hit = defaultdict(F)
    for local in R.values():
        for (u,v,g,z), r in local.items():
            for t in z:
                old_hit[v,t] += r
    winner = None
    for v, t in product(labels, range(len(p))):
        real = total(row.get(v,0)*events[x].get(t,0)/total(row.values())
                     for x,row in genuine.items())
        toy = F(0)
        for x,row in additional.items():
            ref = total(value*old_hit[w,t]/middles[w] for w,value in row.items())
            toy += row.get(v,0)*ref/total(row.values())
        cond = real/middles[v]
        cond_fresh = toy/middles[v]
        base = total(old_hit[w,t] for w in labels)/Q
        if 0 < cond < 1 and cond != base and cond_fresh != cond:
            score = abs(cond-cond_fresh)
            if winner is None or score > winner[0]:
                winner = (score,v,t,real,toy,cond,cond_fresh,base)
    assert winner is not None
    _, v,t,real,toy,cond,cond_fresh,base = winner
    check_real = total(w*row.get(v,0)/total(row.values()) for x,row in genuine.items()
                       for (u,mid,g,z),w in R[x].items() if t in z)
    assert check_real==real
    x_star = next(x for x,row in genuine.items() if row.get(v,0)>0 and
                  0<events[x].get(t,0)<total(row.values()))
    px = events[x_star][t]/total(genuine[x_star].values())
    true_posterior_joint_at_x = genuine[x_star][v]*px
    assert true_posterior_joint_at_x/genuine[x_star][v] == px
    # Give one actual changed off-diagonal middle pair with two alternative values.
    gdiff = max(((abs(C.get(key,0)-FRESH.get(key,0)),key,C.get(key,0),FRESH.get(key,0))
                 for key in set(C)|set(FRESH) if key[0]!=key[1]))
    assert gdiff[0]>0
    genuine_mix = bins(C,p,geom)
    fresh_mix = bins(FRESH,p,geom)
    assert sum(genuine_mix["same_adjacent_far_share"]) == 1
    assert all(x>0 for x in genuine_mix["same_adjacent_far_mass"])
    assert genuine_mix["same_adjacent_far_share"] != fresh_mix["same_adjacent_far_share"]
    return dict(n=n, actual_original_price_membership_cells=len(cells),
                actual_active_common_left_price_types=len(genuine),
                complete_peak_records_after_price_cell_refinement=sum(map(len,R.values())),
                both_complete_peak_marginal_terms_checked=full_record_margins_checked,
                true_original_middle_mass=dict(middles), total_original_R=Q,
                same_x_conditionally_independent_middles={
                    "pairs":[(u,v,w) for (u,v),w in fwd.items()], "mass_bin_split":genuine_mix},
                use_extra_mu_given_middle_x_redraw={
                    "pairs":[(u,v,w) for (u,v),w in sorted(FRESH.items())], "mass_bin_split":fresh_mix},
                middle_pair_TV_genuine_vs_extra_price=distance,
                actual_middle_pair_witness=[gdiff[1],gdiff[2]/Q,gdiff[3]/Q],
                sharp_difference_in_original_nonproduct_gate=nonprod,
                given_second_original_peak_middle_first_private_price_test={
                    "actual_second_middle_label":v,
                    "actual_target_parent_label":t,
                    "target_is_cube_center_radius":[p[t].c,p[t].s],
                    "unconditional_original_right_hit_probability":base,
                    "coupled_original_price_conditional_hit_probability":cond,
                    "coupled_extra_price_conditional_hit_probability":cond_fresh,
                    "joint_true_mass":real,"joint_extra_price_mass":toy,
                    "one_shared_exact_x_membership":{
                        "x_members":x_star,"conditional_probability_given_this_x_alone":px,
                        "conditional_probability_given_this_x_and_second_middle":
                        true_posterior_joint_at_x/genuine[x_star][v]}})


def bracket_counts(points, low, high, strict):
    N,n = len(points),len(low)
    all_masks = (1<<N)-1
    lower = [sum(1<<j for j,z in enumerate(points)
                 if (z[k]<low[k] if strict else z[k]<=low[k])) for k in range(n)]
    upper = [sum(1<<j for j,z in enumerate(points)
                 if (z[k]>high[k] if strict else z[k]>=high[k])) for k in range(n)]
    success = []
    for mask in range(1<<N):
        selected = [p for j,p in enumerate(points) if mask&(1<<j)]
        event1 = bool(selected) and all(
            (min(q[k] for q in selected)<low[k] and max(q[k] for q in selected)>high[k])
            if strict else
            (min(q[k] for q in selected)<=low[k] and max(q[k] for q in selected)>=high[k])
            for k in range(n))
        event2 = all(mask&s for s in lower+upper)
        assert event1==event2
        if event1:
            success.append(mask)
    masses = [F((1<<s.bit_count())-1,1<<s.bit_count()) for s in lower+upper]
    bound=F(1)
    for s,mass in zip(lower+upper,masses):
        assert mass == F(sum(bool(mask&s) for mask in range(1<<N)), all_masks+1)
        bound *= mass
    prob=F(len(success),1<<N)
    assert prob>=bound
    # Independently collapse repeated candidate positions before taking a box.
    multiplicity = defaultdict(int)
    for p in points:
        multiplicity[p]+=1
    distinct = sorted(multiplicity)
    compress = F(0)
    for mask in range(1<<len(distinct)):
        amount=F(1)
        occ=[]
        for j,p in enumerate(distinct):
            none = F(1,1<<multiplicity[p])
            if mask&(1<<j):
                occ.append(p)
                amount*=1-none
            else:
                amount*=none
        if occ and all(
            (min(p[k] for p in occ)<low[k] and max(p[k] for p in occ)>high[k]) if strict else
            (min(p[k] for p in occ)<=low[k] and max(p[k] for p in occ)>=high[k])
            for k in range(n)
        ):
            compress+=amount
    assert compress==prob
    return dict(strict=strict,target_coordinatewise_low_high=[low,high],
                positive_subsets=len(success),total_equiprobable_label_subsets=1<<N,
                exact_probability=prob,individual_lowers_and_uppers=masses,
                product_lower_bound=bound,gap=prob-bound,
                collapsing_coincident_price_atoms_matches=compress)


def brackets():
    cases = [
        ("aligned_correlated_coordinates", [(-2,-2),(-1,-1),(1,1),(2,2)], (0,0),(F(1,2),F(1,2))),
        ("two_independent_labels_at_same_price", [(0,0),(0,0),(-1,1),(1,-1),(0,2)], (0,0),(F(1,2),0)),
        ("support_on_plane_with_hidden_price_off_plane",
         [(2,-1,-1),(-1,2,-1),(-1,-1,2),(-2,1,1),(1,-2,1),(1,1,-2)],
         (F(1,2),F(1,2),F(1,2)),(0,0,0))]
    result=[]
    for name, pts, z,x in cases:
        only=bracket_counts(pts,z,z,False)
        strict=bracket_counts(pts,z,z,True)
        both=bracket_counts(pts,tuple(min(a,b) for a,b in zip(x,z)),
                            tuple(max(a,b) for a,b in zip(x,z)),False)
        assert 0<both["exact_probability"]<=only["exact_probability"]
        assert only["exact_probability"]>only["product_lower_bound"]
        if len(set(pts))<len(pts):
            assert strict["exact_probability"]<only["exact_probability"]
        result.append(dict(name=name,labelled_points=pts,hidden_price=z,visible_anchor=x,
                           closed_rectangle_contains_hidden_price=only,
                           strict_rectangle_brackets_hidden_price=strict,
                           closed_rectangle_contains_both_prices=both))
    return result


def encode_fraction(x):
    if not isinstance(x, F):
        raise TypeError(type(x).__name__)
    if max(abs(x.numerator).bit_length(), x.denominator.bit_length()) <= 2048:
        return str(x)
    # Preserve exact checks but report long sums as certified 24-digit bounds.
    absolute = abs(x)
    exponent = (absolute.numerator.bit_length() - absolute.denominator.bit_length()) * 30103 // 100000
    unit = F(10)**exponent
    while absolute < unit:
        exponent -= 1
        unit /= 10
    while absolute >= 10*unit:
        exponent += 1
        unit *= 10
    step = unit / 10**23
    lower = x // step
    upper = lower + int(x != lower*step)
    return {"exact_decimal_bounds": [f"{lower}e{exponent-23}", f"{upper}e{exponent-23}"],
            "exact_fraction_hex_sha256": sha256((hex(x.numerator)+"/"+hex(x.denominator)).encode()).hexdigest()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase-dir",type=Path)
    parser.add_argument("--geometry-dir",type=Path)
    out=parser.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    args=parser.parse_args()
    for path in (args.phase_dir,args.geometry_dir):
        if path:
            sys.path.insert(0,str(path))
    import common791 as physical
    import merges789 as geom
    result=dict(
        arithmetic="Exact Fraction, zero roundoff. Very long fractions are archived as outward decimal bounds and an exact-fraction checksum.",
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine()},
        command="python -B price792.py --check price792.json",
        dependencies={name:sha256(Path(module.__file__).read_bytes()).hexdigest()
                      for name,module in (("common791.py",physical),("merges789.py",geom))},
        true_input=("Reuse R791 actual cube family, full d, nonuniform first-axis price "
                    "with phase amplitude 1/2 and inherited nonproduct screen. All source "
                    "memberships and weights are actual. At a given exact price x, the "
                    "first price conditional density is constant on its physical member type. "
                    "The second independent full record shares this x. An extra independent "
                    "price sampled from mu|A_v/m_v keeps the marks but uses another coupling."),
        Bernoulli_scope=("Separate finite reference: each listed price label is independently "
                        "occupied with probability 1/2, equivalently its Poisson count is positive "
                        "with intensity log(2). The product bound is for coordinate-side events. "
                        "Duplicate labels have distinct counts even at the same physical point."),
        finite_true_cube_cases=[case(n,s,physical,geom) for s,n in enumerate((4,8,16),1)],
        independent_finite_bracket_cases=brackets())
    encoded=(json.dumps(result,sort_keys=True,indent=2,default=encode_fraction)+"\n").encode()
    if args.output:
        args.output.write_bytes(encoded)
    elif args.check:
        if args.check.read_bytes()!=encoded:
            raise SystemExit("certificate differs")
        print("price792: original price fibres, second-peak tests and finite rectangles agree")
    else:
        print(encoded.decode(),end="")


if __name__=="__main__":
    main()

