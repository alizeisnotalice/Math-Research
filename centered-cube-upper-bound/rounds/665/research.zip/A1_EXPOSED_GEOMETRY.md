# R665 A1 — paid regularization and one exposed face per source normal

## Quantitative statement first

The original random history, original source pools `I_h`, original target order and radii, original `L_h`, and original true source weights remain fixed. Introduce independent **auxiliary** points

\[
 u_i\sim |F_i|^{-1}\mathbf1_{F_i}(u)\,du\quad(q_i>0),
 \qquad A_i'=Q(u_i,c_0s_i).
\]
These draws do not redraw any event key. For every choice `u_i in F_i`,
`A_i subset A_i'`. Define `Omega'_m(v)` by the frozen definition of `Omega_m(v)`, replacing only the parent in each intersection by `A_i'`; keep the halo `v c_0 s_h Q` and the original fixed clipping `L_h`.

With the original counts at `b=8`, set

\[
 P'=\bigcup_{N_i(b)\ge1}A_i',\qquad
 Q'=\bigcup_{N_i(b)\ge2}(A_i'+c_0s_iQ),\qquad
 S'_m(v)=\Omega'_m(v)\setminus(P'\cup Q').
\]
Then the following is an actual whole-family bound:

\[
 \boxed{
 \mathbb E|S_8|
 \le \mathbb E|S'_k(1)|+\Delta_n U,
 \quad
 \Delta_n=8(c_0^n-1)
   +32a^{-n}\big[(2c_0)^n-(1+c_0)^n\big]
   <\frac13.
 }
 \tag{1}
\]
Expectation on the right includes auxiliary points as well as the unchanged Poisson law. The containment underlying (1) holds for every auxiliary choice.

There is also a new quantitative geometric restriction on this outer cover. Fix an actual history and almost every auxiliary choice. For almost every `v in (0,1)`, each regular moving exposed face has one common supporting source. More strongly, for a fixed source `i`, coordinate `ell`, oriented normal `sigma`, and transverse point `y`, there is **at most one** moving exposed face on that transverse line. This statement uses the nesting of the actual original `L_h`, and applies to the union, not a sum of target regions.

A precise integrated consequence is (11) below: all target groups that use the same source/normal can be charged once to a single maximum-radius projection. This is a proved bound on geometric multiplicity. An absolute expectation bound on the resulting actual exposed projection flux is still missing. No `AU` bound for the original target is claimed.

## 1. The regularization fee is genuinely paid

Since `u_i in F_i subset B_i`,

\[
 |u_i-y_i|_\infty\le s_i/a,
 \qquad A_i\subset A_i'.
\]
Thus all original common witnesses remain in the new parent intersections, and `Omega_m(v) subset Omega'_m(v)` for the same history. Write `P,Q` for the original paid sets. Then `P subset P'`, `Q subset Q'`, and

\[
 S_8\subset(P'\setminus P)\cup(Q'\setminus Q)\cup S'_k(1).
 \tag{2}
\]
For the first additional set, containment of the individual parents gives

\[
 |P'\setminus P|
 \le\sum_i\mathbf1_{N_i(b)\ge1}(c_0^n-1)d_i,
 \quad
 \mathbb E|P'\setminus P|\le b(c_0^n-1)U.
 \tag{3}
\]
For the second, individual expanded-parent containment gives

\[
 \mathbb E|Q'\setminus Q|
 \le\frac{b^2}{2}\sum_iq_i^2d_i
       \big[(2c_0)^n-(1+c_0)^n\big]
 \le\frac{b^2}{2}a^{-n}
       \big[(2c_0)^n-(1+c_0)^n\big]U.
 \tag{4}
\]
This uses the true cap `q_i<=a^(-n)` and the actual identity `q_i d_i=|F_i|`. No new density cap is assigned to another measure.

For an entirely analytic absolute constant, use

\[
 c_0^n\le e^{1/32}\le\frac{32}{31},
\]

\[
 (2c_0)^n-(1+c_0)^n
 \le n(c_0-1)(2c_0)^{n-1}
 =\frac1{32}(2c_0)^{n-1}.
\]
At `b=8`, the second term of `Delta_n` is at most

\[
 a^{-n}(2c_0)^{n-1}
 =\frac1a\left(\frac{2c_0}{a}\right)^{n-1}\le\frac1{32}.
\]
Hence

\[
 \Delta_n\le\frac8{31}+\frac1{32}
       =\frac{287}{992}<\frac13.
 \tag{5}
\]
The original all-source admission remains part of the input. It also yields the following useful pointwise restriction after regularization, for every allowed auxiliary choice:

\[
 \boxed{
 \sum_{j<i}q_j
  \mathbf1_{Q(u_j,(1-1/a)s_j)}(u_i)\le1.
 }
 \tag{6}
\]
Indeed, membership in the displayed smaller parent implies

\[
 |y_i-y_j|_\infty
 \le s_i/a+(1-1/a)s_j+s_j/a
 =s_j+s_i/a\le c_0s_j,
\]
so its indicator is bounded by the original admission indicator. Here `s_j>=s_i` is the real order constraint.

We do **not** claim the enlarged parents have global load at most `tau`, nor the original standard admission rule with their enlarged radii, nor `q_i=|F_i|/|A_i'|`. Those would be different statements. The exact keys, rates, order and original constraints remain the ones inherited from the task.

## 2. Genericity removes cross-source face ties at a paid cost

Each `u_i` has an absolutely continuous law on its genuine measurable `F_i`. Coordinates within one `F_i` need not be independent. The auxiliary points for different source labels are independent. Consequently, with probability one, the finitely many distinct-source parent-face offsets

\[
 u_{i,\ell}\pm c_0s_i
\]
are unequal when the coordinate and orientation are fixed. Source points almost surely lie in the interior of `B_i`; hence `A_i` is strictly contained in `A_i'`, and every original target witness is in the interior of each of its new parents. In particular the new core intersections are full dimensional.

For fixed history and `m`, let

\[
 K_{h,m}'=\bigcap_{\text{first }m\text{ events for }h} A_i',
 \qquad R_h=c_0s_h.
\]
Potential moving face planes have equations

\[
 x_\ell=u_{i,\ell}+\sigma c_0s_i+\sigma vR_h.
 \tag{7}
\]
Two such planes with different slopes coincide at at most one value of `v`. Equal slopes from different source labels have unequal offsets almost surely. The clipping planes of the original `L_h`, and all planes of `P'` and `Q'`, are fixed in `v`; a moving plane meets one of them at at most one parameter value. There are only finitely many sources, targets, and potential planes. Thus a finite exceptional set of `v` suffices, simultaneously for the finitely many relevant pieces.

At a nonexceptional `v`, discard the codimension-two intersections of face planes and the volume-inessential traces of clipped pieces. A regular moving face point of the union then has the following property: every piece with a positive inside trace at that point has a face in the same oriented plane. Therefore they all share the same supporting source `i`, orientation `sigma`, and halo radius `R_h`. The fixed clipping may suppress a face, but cannot add positive normal velocity.

This is a statement about regular exposed-face traces, not every closed-set boundary point. Tangencies in the original input have been covered by (1), rather than silently assumed absent.

## 3. One moving face per source, normal, and transverse line

Fix `i,ell,sigma`, and use the oriented coordinate `t=sigma x_ell`. Put

\[
 \alpha_i=\sigma u_{i,\ell}+c_0s_i.
\]
Let `H_i` be the actual targets completed to `m` events whose core `K'_{h,m}` has oriented upper face supported by source `i`. For such a target, the core's oriented upper endpoint is the same anchor `alpha_i`, and its oriented lower endpoint is at most `alpha_i`.

For a transverse point `y`, define

\[
 R_i^*(v,y)=\max\{R_h:
      h\in H_i,\ y\in\pi_\ell(K'_{h,m}+vR_hQ)\},
 \tag{8}
\]
with value zero if no target qualifies. This is a maximum over the actual history's cores; it is not a new iid source selection. Its dependence on the fixed `m,ell,sigma` is suppressed in notation.

Suppose a positive-speed exposed face on that line came from a target `h_1` with radius `R_1`, while some qualifying target `h_2` had `R_2>R_1`. Radius order gives `h_2<h_1`, hence

\[
 L_{h_1}\subset L_{h_2}.
 \tag{9}
\]
The `h_2` transverse box contains `y`; its oriented interval contains the anchor and extends to `alpha_i+vR_2`. It therefore contains the smaller alleged face point `alpha_i+vR_1` strictly in its oriented interior. That point belongs to `L_{h_1}` and thus to `L_{h_2}`. At a regular face point it is away from the fixed clipping planes and from transverse box boundaries, so `h_2` covers a full neighborhood across the alleged face. This contradicts exposure.

It follows that an exposed face from this source/normal must have radius `R_i^*(v,y)`. Equal-radius targets give the same plane. There is at most one such moving face on the line. This argument permits arbitrary overlap among groups; it does not allocate a separate fee to each target. It also handles a larger-radius target whose own outer endpoint is cut off by `L_h`: the smaller face lies in `L_{h_1} subset L_{h_2}`, which is the only membership needed for the contradiction.

The transverse boxes expand with `v`, while `H_i` is fixed by the history. Therefore

\[
 R_i^*(v,y)\le R_i^*(1,y)\le c_0s_i.
 \tag{10}
\]
Let `Gamma_{i,ell,sigma}(v)` be the regular moving exposed faces of `S'_m(v)` assigned to this source and normal. Projection onto the transverse coordinates has unit area Jacobian on every cubical face, and the preceding proof makes it injective almost everywhere. Consequently the **actual integrated flux** obeys

\[
 \boxed{
 \int_0^1\int_{\Gamma_{i,\ell,\sigma}(v)}
           R_h\,d\mathcal H^{n-1}\,dv
 \le \int_{\mathbb R^{n-1}} R_i^*(1,y)\,dy.
 }
 \tag{11}
\]
Only sources with `N_i(b)=1` can support such a face: a piece containing a globally repeated source is wholly inside `Q'`, since `s_h<=s_i`.

For a fixed finite history and auxiliary configuration, all clipped union volumes are piecewise polynomial and continuous in `v`. Their moving faces have the normal velocities just described, while fixed clipping faces have zero velocity; `S'_m(0)` is empty. Integrating their exposed growth and then applying (11) yields the sufficient projection bound

\[
 |S'_m(1)|
 \le\sum_{i:N_i(b)=1}\sum_{\ell=1}^n\sum_{\sigma=\pm1}
       \int R_i^*(1,y)\,dy.
 \tag{12}
\]
The important content here is the once-per-source/normal/transverse-line estimate, not the elementary volume-derivative identity. The right side still discards competition between different sources or normals and is only a sufficient upper bound. Replacing each projection by the projection of the whole enlarged parent gives an exponential dimension cost; that replacement is not a payment.

## 4. The support source is pivotal for a spatial move, not for event deletion

At a regular exterior upper-face point `x`, the common support source satisfies

\[
 x_\ell=u_{i,\ell}+c_0s_i+vR_h>u_{i,\ell}+c_0s_i.
\]
For nonempty axis-parallel box intersections, `(intersection A_j') + v R_g Q = intersection (A_j' + v R_g Q)`. All these cores remain nonempty under the small moves considered below.

Move only its auxiliary center to `u_i-delta e_ell`, with `delta>0` sufficiently small. All old covering pieces have the same upper support face and immediately exclude `x`. For **every** other key containing `i`, membership at the fixed point `x` can only get worse: in that coordinate the upper endpoint of `A_i'+vR_g Q` decreases, while the lower-endpoint condition is automatically satisfied because `x_ell>u_{i,ell}+c_0s_i`. Other coordinates and all `L_g` stay fixed. Keys not containing `i` are unchanged. Thus no previously noncovering key can be made covering at `x` by this move.

The lower-face statement uses the opposite shift. The move can be chosen inside `B_i`, since almost every auxiliary point has a positive margin to its boundary, so the original cores remain contained in the new parents throughout this local geometric argument. At exterior faces the support source has global count one; its repeated-parent pruning set is absent, and moving it away from `x` cannot make its marked parent capture `x`. Other paid parents are unchanged.

This proves a genuine **spatial-position pivotal** property for regular exposed points. It does not make the source event deletion-pivotal. Deleting the event can replace it by the next event of the target's pool; that replacement may continue to cover the point or may enlarge the intersection. Hence the already proved time/deletion inequality cannot simply be reversed or substituted here.

There is also no free distributional differentiation. The auxiliary shift may leave `F_i`, even though it remains in `B_i`. For `u_i` uniform on an arbitrary measurable `F_i`, changing variables in a translated integral introduces

\[
 \mathbf1_{F_i+\delta e_\ell}-\mathbf1_{F_i},
\]
whose variation has no supplied bound by `delta |F_i|/s_i`. True owners can be arbitrarily thin and need not have finite perimeter. Absolute continuity removes exact face ties; it does not supply a quantitative density-gradient or boundary-variation bound. No integration by parts across `F_i`, independent-coordinate assumption, or translation-invariance of the source law is used.

## 5. Bounded conclusion and exact outstanding step

The new proved outputs are the whole-family regularization fee (1), the preserved smaller-parent admission (6), the common-support statement, the once-per-source/normal exposed-face bound (11), and the local spatial-pivotal property. They keep the original event law, all original targets and clips, and all source/scale information. The one-face strengthening was suggested by the main agent and independently checked here; S2 independently audited the regularization and generic face statements before reading this proof.

The remaining task is an absolute expected budget for the actual exposed projection flux from the paid small-`v` endpoint to `v=1`, using the full `k`-event cores and all true mutual admission constraints. A bound on the larger projection sum (12) would suffice but is not necessary. Neither (11) nor spatial pivotality currently pays that flux. The obstacles are quantitative projection size and legitimate variation of the actual owner-supported law, rather than cross-group repetition of the same source face.

No final `AU` estimate or summable contraction has been obtained. No numerical run, Git operation, or other author's file was used or changed in this task. Stop after this bounded geometric handoff.
