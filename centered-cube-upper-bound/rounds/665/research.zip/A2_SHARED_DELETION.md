# R665 A2: shared-event deletion, its quantitative direction, and a paid expansion endpoint

**Outcome.** The same shared process gives the quantitative deletion inequality (D1), and source mass pays the small-expansion endpoint (D2). Neither estimate gives E|S_8|<=A U at v=1, m=k. The precise failure is that global deletion pivotals require a common event across all currently covering prefixes, whereas the m-to-(m+1) layer can have many competing prefixes. No lower bound on those global pivotals, or equivalent globally paid control of their absence, has been proved from the actual admission geometry.

## Quantitative statements first

Keep every actual source, target, I_h, L_h, radius, and residual q fixed. Let Omega_m^{(b)}(v) use the first m events by horizon b, for 0<b<=8 and 0<=v<=1, on the same source-label process. Put
\[
 H_m(b,v)=\mathbb E|\Omega_m^{(b)}(v)|.
\]
Then for every integer m>=1,
\[
 \boxed{0\le b\,\partial_b H_m(b,v)
       \le m\,[H_m(b,v)-H_{m+1}(b,v)].}              \tag{D1}
\]
The derivative exists for this finite family. This estimate retains the full union: deleting one event means removing it globally and recomputing every target's first prefix and any group representatives. There are no independent target resamples.

For the actual exterior at horizon b, define
\[
 S_m^{(b)}(v)=\Omega_m^{(b)}(v)
                   \setminus(P_b^{\rm mark}\cup Q_b^{\rm rep}).
\]
The stronger estimate with only P_b removed also holds:
\[
 \boxed{\mathbb E|S_m^{(b)}(v)|
 \le\mathbb E|\Omega_m^{(b)}(v)\setminus P_b^{\rm mark}|
 \le\frac b m\big[(1+c_0v)^n-1\big]U.}             \tag{D2}
\]
Consequently the deterministic endpoint
\[
 v_m=\min\{1,(m^{1/n}-1)/c_0\}
\]
is completely paid:
\[
 \mathbb E|S_m^{(8)}(v_m)|\le8(1-1/m)U\le8U.         \tag{D3}
\]
For m=k approximately sqrt(n), v_m is of order log(m)/n; D2 at v=1 still has an exponential coefficient. D3 is a legitimate small-expansion endpoint for a possible integrated geometric argument, not the required final AU bound.

## Shared deletion: pathwise pivotal bound

Fix a complete finite marked history eta on [0,b]. Every event e includes its source label and time; repeated source labels are distinct events. Let eta minus e delete exactly that event from the entire shared history. All target prefixes are recomputed from eta minus e.

For fixed v define
\[
 G_m(\eta)=\Omega_m(\eta)\setminus\Omega_{m+1}(\eta),
 \quad
 D^-_e(\eta)=\Omega_m(\eta)\setminus\Omega_m(\eta\setminus\{e\}).
\]
Then
\[
 D^-_e(\eta)\subseteq G_m(\eta),\qquad
 \sum_{e\in\eta}1_{D^-_e(\eta)}(x)
       \le m\,1_{G_m(\eta)}(x).                     \tag{D4}
\]

To prove the first inclusion, suppose a target covers x after m+1 events in eta. Its first m+1 cubes all satisfy the full halo constraints at x and it is completed. After any single global event is removed, its first m surviving events are a subset of those first m+1, so it is still completed to m and covers x. L_h and the dilation radius do not change. Hence x cannot be deleted from Omega_m if x belonged to Omega_{m+1}.

For the second assertion, whenever x belongs to Omega_m, let W_m(x) be the nonempty family of actual first-m event prefixes of every target whose own m-halo contains x. If deleting e loses x from the **whole union**, e must belong to every member of W_m(x). Otherwise some covering target has exactly the same first-m prefix after deletion and still covers x. Therefore every globally pivotal event lies in
\[
 J_m(x)=\bigcap_{K\in W_m(x)}K,
 \qquad |J_m(x)|\le m.                              \tag{D5}
\]
This proves D4. Deletion may additionally make a previously failing target cover x, by removing its bad event. Such rescue only decreases the global pivotal count; it cannot invalidate this proof.

This use of own target halos equals the true representative union for each history separately. Shared keys have nested own halos because radii and L_h decrease in original target order. Thus no representative is frozen across deletion and none is treated as an unbiased sample.

## Finite Poisson deletion/insertion formula, proved for this contract

Let Q=sum_i q_i, which is finite. When Q=0 all statements are trivial. Otherwise the total number N of events in [0,b] is Poisson(bQ); conditional on N=r, the r events are independent with source probability q_i/Q and uniform time on [0,b]. Times tie with probability zero.

For any nonnegative measurable functional F(xi,e) of a finite configuration xi and one additional event, symmetry and the identity r Pr(N=r)=bQ Pr(N=r-1) give
\[
 \mathbb E\sum_{e\in\eta}F(\eta\setminus\{e\},e)
   =\sum_iq_i\int_0^b\mathbb E F(\eta,(i,u))\,du.     \tag{D6}
\]
Indeed, condition on N=r, choose one of the r exchangeable points, and then sum r from 1 upward. Reindexing r-1 yields an independent Poisson configuration for the remaining points and an independent point with the displayed label/time density. Tonelli justifies the nonnegative sum. No selected target or selected representative is involved in the independence statement.

Every possible halo is in a fixed bounded spatial envelope for this finite original family. Thus all volume functionals here are uniformly bounded, and total event count has finite expectation; D6 also applies to the relevant signed differences by splitting positive and negative parts.

Apply D6 to
\[
 F(\eta,e)=|\Omega_m(\eta\cup\{e\})\setminus\Omega_m(\eta)|.
\]
Using D4 gives
\[
 \begin{split}
 I_m^+(b,v)
 &:={\sum_iq_i\int_0^b\mathbb E
    |\Omega_m(\eta\cup\{(i,u)\})\setminus\Omega_m(\eta)|\,du}\\
 &=\mathbb E\sum_{e\in\eta}|D^-_e(\eta)|\\
 &\le m\,\mathbb E|G_m(\eta)|
   =m(H_m-H_{m+1}).
 \end{split}                                                   \tag{D7}
\]
The inserted point at time u can change the first prefix of many targets at once; the differences in D7 are whole-union differences after all changes, not sums of their individual volumes.

## Why the horizon derivative has the stated sign and direction

Rescale time to [0,1]. The source intensities become b q_i, while event ordering, full-key equality, completion by the endpoint, and all geometric regions are preserved. Conditional on N=r, the expected union volume is a number a_r independent of b, with 0<=a_r<=M for the fixed envelope volume M. Hence
\[
 H_m(b,v)=e^{-bQ}\sum_{r\ge0}\frac{(bQ)^r}{r!}a_r.
\]
The bounded a_r allow termwise differentiation on compact b intervals. Combining this derivative with D6 gives
\[
 b\partial_bH_m=I_m^+(b,v)-I_m^-(b,v),              \tag{D8}
\]
where
\[
 I_m^-:=\sum_iq_i\int_0^b\mathbb E
 |\Omega_m(\eta)\setminus\Omega_m(\eta\cup\{(i,u)\})|\,du
 \ge0.
\]
A source event inserted at an earlier time can be bad for a formerly successful target, so I_m^- must not be silently discarded from an equality.

On the other hand H_m is nondecreasing in the natural horizon: once a target completes its first m events, its own halo never changes on extending the horizon. The union over completed targets therefore grows. This proves partial_b H_m>=0. Dropping only the nonnegative I_m^- from D8 and using D7 proves D1.

In particular D1 bounds time growth **from above** by the m-layer difference. It is not an upper bound on the m-layer difference and cannot be used with that inequality reversed.

## Source-mass payment of the expansion endpoint

For every marked source event e of label i define its exterior annulus
\[
 R_i(v)=(A_i+vc_0s_i[-1,1]^n)\setminus A_i.
\]
If x belongs to Omega_m(v) minus P_b, choose any one actual target whose completed first-m halo contains x. Every event of its prefix has a source radius s_i>=s_h, so
\[
 x\in A_i+vc_0s_h Q\subseteq A_i+vc_0s_i Q,
 \qquad x\notin A_i.
\]
There are m distinct events in that prefix, even when source labels repeat. Consequently the pathwise whole-union inequality is
\[
 m\,1_{\Omega_m(v)\setminus P_b}(x)
        \le\sum_{e\in\eta}1_{R_{i_e}(v)}(x).         \tag{D9}
\]
Integrate in fixed Lebesgue measure, then take expectation using E N_i(b)=bq_i. The volume of R_i(v) is exactly [(1+c_0v)^n-1]d_i, and sum_i q_i d_i=U. This proves D2. The definition of v_m gives (1+c_0v_m)^n<=m, proving D3.

D9 counts the receiver union once and uses each actual event's source mass once on the right. It is not a key-volume sum. The repeat-pruning set is not needed for this stronger upper bound; it remains in the actual target S_k^{(8)}(1)=S_8.

## Exact stopping point

D4--D7 show where shared overlap obstructs a reverse deletion estimate. A globally pivotal deletion must lie in the intersection J_m(x) of **all** currently covering prefixes. The full layer G_m need not come with an established positive lower bound on this intersection or on the surviving global pivotal count. Even an event in J_m can fail to be pivotal because its deletion creates a new covering target. No actual-input argument using admission, all coordinates and high T_h has been found to pay or exclude these possibilities.

Thus replacing the shared deletion by independent deletion within a selected target would change the problem: it would turn each target's m events into apparent pivotals and lose precisely the cross-key rescue/overlap effect. Likewise, applying an iid tuple estimate after choosing a representative is not justified.

The source-paid endpoint D3 leaves the interval v_m<v<=1. At v=1, D2 is only
\[
 \mathbb E|S_m^{(8)}(1)|
       \le\frac8m[(1+c_0)^n-1]U,
\]
which is exponential for m of order sqrt(n). D1 supplies no upper bound on the unpaid expansion from v_m to 1 and no reverse m-contraction that could remove this factor. A quantitative relation between exposed expansion volume and the actual **global** pivotal deletion gain would be additional content; none is proved here.

No arbitrary incidence counterexample, non-near diagnostic, or numerical experiment was used. The finite Poisson identity and its inequality directions are proved above for the actual contract. Only this assigned file was written. Bounded task complete; no AU or dimensional improvement is claimed.
