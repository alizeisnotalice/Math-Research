# R665 checkpoint: paid regularization, no general closure

Goal: pure general C_n≤K√n, arbitrary L1, all positive centered common-radius cubes, fixed Lebesgue. Both this and the earlier n^(1/2+o(1)) general theorem remain open. Authoritative user guidance is USER_GUIDANCE.md in the R658 temp directory; historical synthesis was completed in R658, not repeated here.

## Actual new content

Keep original q_i, I_h, targets, source order, first-event keys, witnesses and L_h. Independently u_i∼Unif(F_i), A_i'=Q(u_i,c0s_i). The enlarged outer covering incurs only Delta_n U beyond old P and Qrep, where Delta_n≤287/992<1/3. New complete account uses B'_n=8c0^n+32(2c0/a)^n≤5119/496<11. Do not add Delta again on top of that complete fee. q/τ remains feasible only in the original parents, which is all the recovery needs.

At generic v and regular exposed-face points, every covering piece has the same supporting source and velocity. For one source i, coordinate normal (ell,sigma) and transverse line, only one moving exposed face exists: a larger qualifying halo has an earlier/nested L_h and covers any putative smaller face. This is a whole-union multiplicity estimate, with true full first-k cores. Almost-sure randomization removes cross-source offset ties; finitely many v collisions and fixed-face/codimension-two traces are excluded in the exact a.e. statement.

The exposed flux equals |S'_k(1)| and has a source/normal maximum-projection upper bound. Its expectation ≤AU is NOT proved. The projection envelope drops competition across sources and normals, so it is sufficient but may be too strong; the actual flux is the primary target. Source-position pivotality is proved locally. It is not event-deletion pivotality, and Unif(F_i) has no provided boundary-variation bound: a shift may stay in B_i yet leave F_i. No free integration by parts, coordinate independence or arbitrary f density cap.

## Precise remaining proof decision

For all real finite states at τ=16384√n and shared source process by b=8, with k=ceil(2τ), establish an absolute expectation bound for the actual sum over globally single sources and all normal directions of

    integral_0^1 integral_{Gamma_i,ell,sigma(v)} R_h dH^(n-1) dv.

It is exactly E|S'_k(1)|. Keep actual first-k selection, all mutual admission, genuine F_i, original clips and global later-repeat pruning. Alternatively directly pay the original E|S_8| or prove a genuine uniformly contracting, summable recurrence with paid endpoints. The new regularized target is sufficient, not necessary. No uniform conditional per-source cap is required. Do not rederive only the interface identity or replace the projection by an exponential whole-parent envelope.

If the bound A U were proved, the unchanged complete recovery would yield
C_n≤(1+e^(1/16))[16384(23+2A)+2e^(33/32)]√n.
A must be independent of n, label count, scale range, owner shapes, minimum q and every truncation. This is a conditional statement, not closure.

## Tested auxiliary alternatives

A2 proved 0≤b∂_b H_m≤m(H_m−H_(m+1)) for raw Omega; deleting an event may rescue another key. The inequality cannot be reversed or transferred without proof to future-pruned S. Shell count costs b[(1+c0v)^n−1]U/m; v_m=min(1,(m^(1/n)−1)/c0) is paid, the rest to v=1 is not. These formulas are unprimed; changing parents changes their coefficients.
A4 proved only a method-class limitation: finite nonnegative mixtures of this shell certificate, divided by actual completion probabilities, retain a coefficient ≥[(1+c0)^n−1]/τ. It is not an actual-input counterexample or an impossibility theorem. At a deep empty prefix endpoint true unfinished receiver mass survives.

## Evidence and reproducibility

A1+S2 contain the new geometric proof and independent audit, A2+A4+S1 the bounded auxiliary results and audit. REPORT is the main integrated text; FINAL_ACCOUNT_AUDIT binds its final digest. FACE_CHECK covers 12 rational 2-D/3-D first-coordinate line-slice instances at seven v values; 338632 line/time cells, zero violations. It is not a genuine high-T near input or full-v certificate. Actual prescribed Python 3.12 replay matched all mathematical fields of the original Python 3.15 run. REGULARIZATION_CHECK uses 256-bit Arb at six stated n and exact/symbolic algebra; it does not simulate high-dimensional geometry. No need to repeat these passes unless the underlying formulas or code change.

Run verify.py for structural/hash/provenance checks. Optional --replay explicitly reruns both frozen experiments in a new /Volumes/data/CodexTemp directory and compares mathematical fields, retaining interpreter differences. Never fall back to system disk if data is unavailable. No PDF compile.

## Collaboration and resource preference

Latest user configuration: at most 2 Astra and 5 Sol; Terra/Luna may be added for distinct needed tasks, not dummy utilization. The previous R665 workers had finished before the host restart and are not counted active. One fresh Sol reviewed the new full account and final text. Agents may edit only assigned files; no shared Git staging. MATLAB is to be closed promptly after its job and saved outputs. The main thread inspected its currently connected empty MATLAB session (no unsaved documents/pool/workspace), issued normal exit, and confirmed that PID 99819 disappeared. Do not kill other projects' unverified MATLAB sessions. Mathematical R665 evidence is Python only.
