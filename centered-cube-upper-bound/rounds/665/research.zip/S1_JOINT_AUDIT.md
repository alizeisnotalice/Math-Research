# R665 S1 independent audit: Omega_m(v) contract

## Status and exact object

This note independently checks the new fixed-history contract before reading any author proof. No quantitative A1/A2/A4 candidate has yet been supplied to this reviewer. Nothing in this contract check is counted as a new payment.

Fix one original finite actual input and one realization of its unchanged common source processes through b=8. Put

    C_m = {actual near targets h: N_{I_h}(8)>=m},  m>=1,
    K_{h,m} = intersection of the first m actual A_i for target h,
    D_{h,m}(v) = (K_{h,m}+v*c0*s_h*Q) intersect L_h,
    Omega_m(v) = union_{h in C_m} D_{h,m}(v),  0<=v<=1.

Every source event retains its actual identity and time. Repeated labels count as distinct events even though repeating a spatial intersection is redundant. All L_h, s_h, I_h and the original target order are fixed from the actual input.

The paid set is fixed once for the whole history:

    M_8=P_8^mark union Q_8^rep,
    S_m(v)=Omega_m(v) minus M_8.

In particular S_k(1) is exactly the original S_8. This definition neither redraws keys nor changes which sources/events each target uses.

## 1. Fixed-history monotonicity and changing completion collections

For a fixed m, if 0<=v<=w<=1 then D_{h,m}(v) subset D_{h,m}(w) for every completed target h, and hence

    Omega_m(v) subset Omega_m(w),
    S_m(v) subset S_m(w).

For depth, C_{m+1} subset C_m. A target in C_m minus C_{m+1} contributes only at depth m; it must not be forcibly completed at depth m+1. For a surviving target h in C_{m+1},

    K_{h,m+1} subset K_{h,m},
    D_{h,m+1}(v) subset D_{h,m}(v).

Thus, simultaneously over all targets,

    Omega_{m+1}(v) subset Omega_m(v),
    S_{m+1}(v) subset S_m(v).

The own-target union makes these inclusions direct. If an author instead groups identical m-prefixes and uses the earliest representative at each depth, that grouping yields the same own-target union: within a group the earliest h has the largest s_h and largest L_h and therefore contains all other own-target pieces. Representatives may change when m changes, but this does not invalidate the above own-target proof. It would be incorrect to keep the old completed-target collection or old representative group fixed while changing m.

## 2. Zero-halo endpoint and fixed paid-set clipping

For m>=1 and h in C_m, every source in the first m events was marked by b, so

    K_{h,m} subset A_i subset P_8^mark

for each source label i in that prefix. Consequently

    Omega_m(0) subset P_8^mark subset M_8,
    S_m(0)=empty.

This is a set inclusion, including cube boundaries. The deterministic L_h clipping can only shrink the piece. The statement is not asserted at m=0: an empty spatial intersection would be the whole space and would destroy this endpoint.

The same fixed M_8 must be used for every m and v. Replacing it by a paid set that changes with depth or halo size can change both monotonicity and terminal differences. In a time-driven proof M_8 is future-dependent; no predictable-compensator formula for an M_8-filtered set follows merely from the above offline, fixed-history definitions.

## 3. Finite depth and halo endpoints

Let Nmax be the maximum, over the finite target family, of its actual qualifying count by 8; define Nmax=0 when there are no near targets. The common flow has finite total rate and finitely many events on [0,8] almost surely, so Nmax is finite almost surely. For every m>Nmax,

    C_m=empty, Omega_m(v)=empty, S_m(v)=empty.

Thus a sample-depth telescoping argument has a genuine zero terminal endpoint at a sufficiently large depth for each history. A proof using a fixed deterministic truncation must retain its actual terminal term, or justify the subsequent limit with the common finite envelope. It must not use a history-dependent truncation as though it were an independent deterministic stopping level.

All nonempty prefixes lie in the same fixed finite-volume expanded-source envelope. Hence the terminal depth limit also admits bounded convergence in expected volume. This establishes endpoints only, not a summable fee estimate.

Each K_{h,m} is a nonempty box: every selected source contains the same actual witness z_h. Its dilation has coordinate endpoints affine in v. For fixed h,m, its volume change is bounded by a finite constant times |dv| on [0,1]; clipping by fixed L_h can only reduce a nested box increment. Summing over the finite target family shows that v maps to |S_m(v)| is Lipschitz for each fixed history (with no useful uniform dimension constant asserted). Thus a boundary integral is legitimate once its integrand is correctly identified almost everywhere. The mere existence or finiteness of that integral supplies no AU bound.

## 4. What a first quantitative candidate must actually prove

A candidate may use the exact target directly, or a finite depth/halo recurrence, but it must give a quantitative inequality whose paid terms sum to an absolute multiple of the actual U and whose initial and terminal terms are controlled. The relevant quantity is the actual union after fixed M_8 clipping, not a sum over targets or an arbitrary collection of full-k subsets.

In particular:

- An m-to-m+1 deletion difference must account for targets that cease being completed as well as targets whose common box shrinks.
- An exposed-boundary fee must retain all box-coordinate constraints and old union overlap; replacing it by independent face fees requires a new justified aggregate estimate.
- A weighted telescoping or recurrence requires all coefficients, signs, endpoints, and a dimension-uniform recovery coefficient. A summable-looking expression alone does not imply geometric dissipation.
- Selected representatives and fixed M_8 constraints remain history-dependent. Neither the shared sample law nor all-source mutual admission can be dropped while estimating the new fee.

No such quantitative fee inequality has been established in this audit. The author has been asked to supply only the first genuinely quantitative candidate, with its exact parameters and endpoints. This reviewer does not scan or re-derive old interface identities while waiting.

## 5. First quantitative A2 statements: independent verdict before author proof

A2 supplied the following two statements after the contract check above. They were audited independently before reading an author proof. **Both statements PASS within their exact separate scopes.** Neither gives a dimension-uniform estimate for the original S_k(1).

### 5.1. Raw shared-event deletion inequality

For 0<b<=8 define the raw, unfiltered volume

    H_m(b,v)=E|Omega_m^(b)(v)|,

using the same original I_h,L_h,s_h and the first m events completed by the variable horizon b. For every integer m>=1 and 0<=v<=1,

    0 <= b partial_b H_m(b,v)
       <= m[H_m(b,v)-H_{m+1}(b,v)].                 (D1)

Here the derivative is an ordinary derivative of the expected raw volume. It is not a pathwise derivative of a step process.

To justify differentiation, rescale [0,b] to [0,1]. The event process on the latter interval has intensity b q_i du. The spatial functional depends only on event ordering, shared identities, labels and completion, so this rescaling leaves it unchanged. Conditional on the finite total event count, the expected volume is bounded by the same deterministic envelope for every count. The Poisson series therefore differentiates absolutely; in fact it gives a real-analytic function of b. If the total rate is zero all quantities vanish, so no division by that rate is needed.

Poisson insertion/removal then gives the exact signed identity

    b partial_b H_m
      = E sum_{e in eta_b} (|Omega_m(eta_b)|
                              -|Omega_m(eta_b minus e)|).     (D2)

Every deletion is global: all affected targets, their first m events, completion membership, and the union are recomputed. A deletion may create spatial coverage by replacing an early event with a later source. Those negative terms in (D2) cannot be changed into positive insertion gains.

For each fixed history and point x, if x lies in Omega_{m+1}, choose a target witnessing it. Deleting any one global event leaves that target completed to m, and its new first m events are a subset of its old first m+1 events. Their intersection, with the same halo and L_h, still covers x. Thus no deletion loses x.

If x lies in Omega_m but not Omega_{m+1}, choose any one target witnessing its depth-m coverage. Only deletion of one of that target's first m actual events can destroy this witness; every deletion losing x from the entire union must be among these at most m events. A target with exactly m events is included in this argument and may become incomplete after deletion. If x lies outside Omega_m, every signed deletion difference at x is nonpositive. Consequently, pointwise,

    sum_e [1_{Omega_m(eta)}(x)-1_{Omega_m(eta minus e)}(x)]
       <= m 1_{Omega_m(eta) minus Omega_{m+1}(eta)}(x).

Integrating gives the upper bound in (D1). The lower bound follows separately by coupling the original flow through increasing actual horizons: appending later events preserves every already completed target's first m events, so the raw union is increasing in b. It does not follow from arbitrary insertion of an event inside an existing time order.

The derivative statement is on b>0. At b=0 the raw union is empty for m>=1, and the product b partial_b H_m has the trivial zero limit. Zero source counts or an empty completion collection cause no exception.

**Scope restriction:** this proof does not establish (D1) for Omega_m minus M_8, or for any paid set recomputed under deletion. M_8 is future-dependent relative to b and its count-threshold pieces can change under deletion. The raw inequality must not be silently transferred to that different functional.

### 5.2. Paid exterior shell-counting estimate

At fixed horizon 8, retain the same fixed M_8 and S_m(v) from Sections 1–3. Then

    E|S_m(v)| <= (8/m)[(1+c0 v)^n-1] U.              (D3)

For a fixed x in S_m(v), choose any actual target h whose depth-m piece covers x. All labels in its prefix must have global N_i(8)=1: otherwise its whole v-halo lies in the already removed Q_8^rep. Thus the prefix contains m distinct labels. For each such i, s_i>=s_h and

    x in (A_i+v c0 s_i Q) minus A_i.

The outer inclusion uses the same actual coordinate intersection; the exclusion follows because x is outside every marked parent, including sources not in this key. Therefore, with T_i(v)=(A_i+v c0 s_i Q) minus A_i,

    m 1_{S_m(v)}(x) <= sum_i N_i(8) 1_{T_i(v)}(x).

After integration and expectation, E N_i(8)=8q_i and |T_i(v)|=[(1+c0v)^n-1]d_i prove (D3). Independence among selected sources or coordinates is not needed. One can replace N_i on the right by 1_{N_i=1}, yielding the slightly stronger source factor e^{-8q_i}, but this does not remove the exponential halo cost at v=1.

A2's v0=min(1,(m^(1/n)-1)/c0) satisfies E|S_m(v0)|<=8U; its m=1 endpoint is simply v0=0. The slightly larger min(1,((m+1)^(1/n)-1)/c0) also has this property. Neither choice pays the remaining halo interval up to 1 when m=k in general dimension.

These are actual quantitative statements, not identities. Their proofs above retain changing completion collections, all global deletions, fixed exterior clipping, and zero-count cases. However (D1) has the upper-derivative direction shown, and (D3) at v=1 retains [(1+c0)^n-1]/m. No AU closure follows from either one or from merely naming an intermediate halo size.

## 6. Check against the delivered A2 proof and final audit scope

The delivered A2_SHARED_DELETION.md was read after the independent proofs in Section 5. Its SHA-256 is

    b732ecbbd4fd0d1744ab2105340ea780922044c10869b346d60ccb8ba2410433.

Its D4–D8 correctly keep global deletion, possible deletion rescues, the negative insertion term, and time normalization. The author derives nonnegativity from natural-horizon coupling, rather than falsely asserting monotonicity under arbitrary earlier insertion. The raw derivative is never claimed for an M_8-filtered functional. The proof agrees with Section 5.1.

The delivered D2 is stronger than the initial exterior statement received for audit: for every fixed 0<b<=8,

    E|Omega_m^(b)(v) minus P_b^mark|
      <= (b/m)[(1+c0v)^n-1]U.

**PASS also for this stronger version.** Repeat pruning is unnecessary here. Count the m actual events of a successful target, including repeated labels with their event multiplicities, on the right side of the shell indicator inequality. The sum over all global events supplies those m contributions. Taking expectation gives bq_i per source. Thus no distinct-label assumption is needed when only P_b is removed. The statement for S_m follows by further clipping. With the author's v_m, the actual endpoint coefficient is at most b(1-1/m), consistent with its D3.

A local Python Fraction polynomial calculation checked the coefficient m in the Poisson-tail derivative for m=1,...,16, using the exact identity

    lambda*(sum_{r=0}^{m-1}lambda^r/r!
              - derivative_lambda sum_{r=0}^{m-1}lambda^r/r!)
      = m*lambda^m/m!.

Actual output:

    {'poisson_tail_derivative_factor_m_checks': 16,
     'exact': True, 'all_pass': True}

This is only an exact scalar coefficient check, not a geometric experiment or evidence for AU closure.

**Final A2 verdict:** PASS for the two quantitative inequalities in their stated scopes; no absolute budget at the original target follows. No repeated R664 budget audit or new local potential is introduced. The missing content remains an actual joint geometric estimate relating the unpaid expansion to a globally summable deletion or overlap gain.

## 7. Bounded check of A4's method-class obstruction

After the A2 audit, A4 supplied one explicit quantitative screening statement. For a nonempty actual near family let g_n=(1+c0)^n-1, choose finite nonnegative weights w_m not all zero, and suppose

    C_w=min_h sum_m w_m p_m(8T_h)>0,
    p_m(lambda)=Pr(Poisson(lambda)>=m).

Then

    C_w <= 8 tau sum_m w_m/m,
    8 g_n sum_m(w_m/m)/C_w >= g_n/tau.              (D4)

**PASS for this precise method-class statement.** For each h,m,

    m p_m(8T_h) <= E[N 1_{N>=m}] <= E N=8T_h<=8tau.

Multiply by w_m/m and sum. This even bounds each target's weighted completion sum, hence also their minimum C_w. Division by the positive C_w gives (D4). Empty near families are already paid and need no minimum over targets. All-zero weights or zero C_w are excluded because they provide no recovery coefficient.

This only excludes closing the problem by a nonnegative mixture of the already proved 1/m shell upper certificates normalized by those completion probabilities. It is not a lower bound on the actual S_8, and it does not exclude a new shared geometric/deletion estimate. Adding further nonnegative paid-set or unfinished fees to that same upper certificate cannot improve its displayed source coefficient. No broader impossibility statement is signed.

No new complete AU estimate was supplied by either author. This bounded audit stops after the candidates above; any further candidate requires the parent's next assignment.
