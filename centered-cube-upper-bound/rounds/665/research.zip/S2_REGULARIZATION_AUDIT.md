# R665 S2：有费来源正则化与共同支撑审查

**独立statement结论：PASS，按下列量词限定。** 正则化是同一原对象的有费上放松，不是AU闭合；共同exposed-face support不是sample deletion pivotality。先读本轮TASK并独立完成第1–3节，再请求作者A1稿。没有重审旧轮、反例扫描、Git或PDF；只写本文件。

## 1. 同一历史上的包含与两项全族费用

只对q_i>0来源独立抽`u_i∼Unif(F_i)`，其真实Lebesgue体积为`d_iq_i`；q_i=0来源不产生event且可忽略。因`||u_i−y_i||∞≤s_i/a`，`A_i⊂A'_i=Q(u_i,c_0s_i)`。保持全部原I_h、q、first-m event列表、代表和deterministic L_h时，各原交盒及其halo逐路径包含于新盒对应区域。因此`Ω_k(1)⊂Ω'_k(1)`，且P⊂P'。

原S_8点若落入P'，由于它原本不在P，便属于P'\P；否则若落入Qrep'则由该项接收；其余点在`Ω'_k(1)\(P'∪Qrep')`。所以题述三项包含逐路径成立。注意这没有声称整个原halo在扣parents后的exterior内。

`P'\P⊂∪_{marked i}(A'_i\A_i)`，且`|A'_i\A_i|=(c_0^n−1)d_i`。原process的`P(N_i(8)≥1)≤8q_i`给

`E|P'\P|≤8(c_0^n−1)U`。

`A'_i+c_0s_iQ=Q(u_i,2c_0s_i)`，体积`(2c_0)^nd_i`。用全局count、包含完成后的后来event的重复标记，`P(N_i(8)≥2)≤32q_i²`，以及真实`q_i≤a^{-n}`得

`E|Qrep'|≤32(2c_0/a)^nU`。

这些是对全族来源求和的确定体积费用，无target/key multiplicity，也不需要把随机u的坐标独立化。第一个系数因c_0^n≤e^{1/32}受绝对控制；第二项同样受绝对控制。它们只支付两项enclosing unions；新exterior的AU预算仍缺。

## 2. 缩水中心admission：PASS；新父盒的强性质未保留

若j<i且`u_i∈Q(u_j,(1−1/a)s_j)`，由原半径序s_i≤s_j，

`||y_i−y_j||∞≤s_i/a+(1−1/a)s_j+s_j/a=s_j+s_i/a≤c_0s_j`。

该项必被原y_i处admission计数，故

`Σ_{j<i}q_j1_{Q(u_j,(1−1/a)s_j)}(u_i)≤Σ_{j<i}q_j1_{c_0A_j}(y_i)≤1`。

这保留全部来源的相应缩水中心限制，不能更换为新parent的standard admission。原全空间load≤τ只控制原A_i，扩大/平移后的A'_i可增加覆盖，故不能据此宣称新load≤τ；q、I_h、饱和witness等均不重新生成。原L_h继续是固定原load定义。

## 3. 真正共同支撑：PASS的准确量词与证明

固定有限原输入、一个实际有限event history及m。每个已完成target h的原列表（忽略重复标签后的来源集合J_h）不变，新交盒非空，因为包含原共同witness。写其坐标上下端点为

`lower_h,r(v)=max_{i∈J_h}(u_i,r−c_0s_i)−v c_0s_h`，
`upper_h,r(v)=min_{i∈J_h}(u_i,r+c_0s_i)+v c_0s_h`。

再以固定L_h裁剪，并在需要时扣固定P'与Qrep'。**对于抽样u几乎必然，除有限个v外，每个移动exposed union面上H^{n−1}-几乎处处的点，所有覆盖该点的pieces有同一坐标方向、同一侧并共享一个extremal supporting source i。** n=1时H^0就是端点计数，同样只排除有限v。v=0与其他固定端点可以直接列入例外。

证明的两层例外必须区分：

1. 每个u_i的单坐标边际无原子，因F_i是正Lebesgue体积的真实集合；跨来源独立足以使任意不同来源的`u_i,r±c_0s_i`offset相等的事件概率为零。不需要同一F_i内坐标独立，也不使用任意f的密度帽。因此每个交盒上下支撑来源几乎必然唯一（重复event标签仍是同一来源）。
2. 两个不同来源支撑的同向moving-face方程是v的仿射函数；offset不等使它们不会identically相等，只在至多一个v相遇。来源、target、方向和侧都有限，故全部坏v有限。moving faces与L_h、P'、Qrep'的固定坐标界面重合也只发生于有限v；其余相交的不同方向面只在H^{n−1}-零集上发生。

在剩下的v与面上一般位置点，任何覆盖该union边界点的piece都不能在该点为内部，否则点不是exposed union边界。固定裁剪界面和不同方向交线已排除，所以它也必须由同向moving face支撑；上一步排除了不同来源的同面重合，于是所有覆盖pieces共享该支撑来源。整个论证是有限orthogonal-face几何，固定L_h可用原有限cube-face arrangement处理。

此结论对history逐个条件化足以用于联合抽样；几何来源集合/半径选项有限，亦无须对不同target重新抽u。它只认证真正的共同支撑，**不认证删除该source后点从union消失**。删去交集中的限制通常扩大交盒；重新计算first-m列表又可能引入其他来源/child。即便共同支撑已成立，sample deletion、birth/death和first-visible积分仍各需另证定量支配，不能免费替换。

## 4. 唯一新增本机算术检查

使用已有Python数学环境/SymPy 1.14.0，只精确化简新fee与缩水半径的代数，未跑几何或随机扫描。实际输出：

`32*(2*(1+1/a)/a)^n`；中心距离界`s_j+s_i/a`。

对应计算是`(8²/2)(2c_0)^n a^{-n}=32(2c_0/a)^n`以及`s_i/a+(1−1/a)s_j+s_j/a=s_j+s_i/a`。这些只辅助常数检查；第1–3节给出全族与几乎处处证明。

## 5. 作者稿对照状态

已向A1 `/root/r663_minvolume` 发送独立结论，明确要求其共同支撑命题注明有限v例外、H^{n−1}几乎处处、fixed-interface排除及非pivotal范围；随后请求稿件完成状态与准确段落。收到后仅在此补充针对性差异，不先把未见作者稿当作已审。

## 6. 新增独立审核：每source/normal/横向线至多一面

主代理另给此命题，审核时未引用作者结论。**PASS，限generic移动exposed faces。** 固定jitter、i、坐标ℓ、正法向、v>0和横向`x_{−ℓ}`；只考虑该横向线确实穿过的pieces。设同来源i支撑两面，其代表半径r_1<r_2，轴向core upper同为`α=u_i,ℓ+c_0s_i`，则两轴向face位置为`t_j=α+v c_0r_j`。

大piece的交盒非空，故其core lower≤α；于是expanded axial lower≤`α−v c_0r_2<t_1<t_2`。横向点已在该大piece的box crosssection内，所以小面点在大piece的box内。r_2>r_1使大piece target在原半径序更早，故其固定L_2包含L_1；小面点既属L_1也属L_2。

为从“被覆盖”推出“非exposed”，须保留generic限定：横向点不在box端面、点不在任一固定L_h/P'/Qrep'界面。此时小面点实际上是大piece及共同exterior内的局部内部点，不可能是union boundary。固定mask不能另造正速度面；它的boundary只形成被排除的零速度部分或低维交线。等半径时两face轴向位置相同，算同一个面而非两个不同面。负法向同理由下端点对称成立。

因此没有L_h裁切漏洞，也没有横向条件漏洞，但必须把“两个候选面都在所固定横向线上的实际截面”写成假设，不能从一个piece的截面任意推断另一个。该结论只消除同source/normal跨target的移动face重计；未支付横向projection面积、v积分或sample deletion费用，仍不是AU闭合。

## 7. 有界交付状态

截至本次交付，两次检查均未发现`A1_EXPOSED_GEOMETRY.md`可读文件；已向作者索稿。本审查认证的是所收到statement的独立证明与第6节新增命题，不认证尚未出现的作者稿。若作者稿随后包含更强速度、删除或投影付款断言，须另行针对审核，不能引用本文件作其背书。

独立结论：正则化三项包含、两项全族显式费用、缩水admission、generic真正共同支撑和同源/法向/横向线唯一移动面均通过；新父盒load与standard admission未保留，deletion pivotality和投影面积预算未证，原AU目标仍OPEN。只写本文件，交付后停止等待。

## 8. 作者精确稿定点对照（更新前次§7状态）

现已读`A1_EXPOSED_GEOMETRY.md`，SHA-256：
`bfecf9e683acf6ffcde8f070f4a97af2a91fb476f5ef04cbf17763bd63074e71`。

以下仅核本次指定三点；此前独立statement结论保持，§7“尚无稿”只记录前次交付时刻，现由本节更新。

1. **优化差集费PASS。** 除P⊂P'外，也有原扩张parent `Q(y_i,(1+c_0)s_i)⊂Q(u_i,2c_0s_i)`，因为center误差≤s_i/a。因此原S只需新增Q'\Q，不必支付整个Q'。稿(1)–(5)给
   `Δ_n=8(c_0^n−1)+32a^{-n}[(2c_0)^n−(1+c_0)^n]`。
   `c_0^n≤e^{1/32}≤32/31`；幂差≤`n(c_0−1)(2c_0)^{n−1}=(2c_0)^{n−1}/32`，而`a^{-n}(2c_0)^{n−1}≤1/a≤1/32`，故`Δ_n≤8/31+1/32=287/992<1/3`。原§1较粗全Q'支付仍正确，但作者这个差集费更小，应采用新常数。本机Python Fraction仅核对这次新有理数：输出`287/992`，到`1/3`的正余量`131/2976`；未重跑几何/随机套件。

2. **R_i^*及整v实际flux界PASS。** 稿§3的H_i只含actual first-m cores，R_i^*(v,y)是在横向raw box projection中取真实最大halo半径，不重新选择iid来源。忽略L_h来定义projection只使该maximum更大。由已独立通过的一面结论，实际exposed source/normal面在几乎每条横向线上至多一次，且其速度就是R_i^*(v,y)。Projection Jacobian为1，故每v通量≤`∫R_i^*(v,y)dy`。固定H_i且raw横向盒随v扩大，给`R_i^*(v,y)≤R_i^*(1,y)`；在长度1的v区间积分即稿(11)。固定L_h/P'/Q'界面只抑制移动面，不增加正速度面。稿保留这些generic trace条件及L_h嵌套，未把局部唯一面误写为已付projection面积。(12)只是更大的充分projection预算，仍未证其期望≤AU。

3. **source-position pivotal PASS，范围准确。** generic上侧exposed点满足`x_ell>u_i,ell+c_0s_i`。把该u_i小幅向负坐标移动，所有当前覆盖pieces的共同upper支持面立即退过x；对其他含i的key，x的lower端约束原已自动满足，upper端约束只能变差，所以不会新增覆盖。无i的key不变。a.s. u_i在B_i内部，小移可留B_i，使原A_i仍包含于A_i'、所有actual cores保持非空。support来源全局恰一次，移动其marked parent是远离x，其他paid sets不变。下侧对称。此为位置微移的pivotal，不是event删除后的列表替换；稿明确两者不能混用。

   稿§4也正确保留关键分布障碍：微移不保证留在任意真实F_i，uniform-F_i law不能免费平移，indicator差`1_{F_i+δe}-1_{F_i}`没有给定的线性variation预算。绝对连续性只消除精确face ties，不提供perimeter/gradient、坐标独立或integration-by-parts费用。因此本节没有认证分布变分或删除费用。

**最终定点处分：三项新增均PASS，无必须修正文点。** 当前证明到有费正则化、共同支撑及真实source/normal通量去重；所剩actual projection-flux的全族期望支付仍OPEN。没有AU闭合，交付后停止。
