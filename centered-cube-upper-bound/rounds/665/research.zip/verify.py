"""R665 structural/provenance checks; --replay explicitly reruns frozen experiments.
No finite check here certifies the open expected-flux budget.
"""
from pathlib import Path
from fractions import Fraction
import argparse, ast, hashlib, json, os, re, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
PAYLOAD=['REPORT.tex','A1_EXPOSED_GEOMETRY.md','A2_SHARED_DELETION.md',
         'A4_JOINT_POTENTIAL.md','S1_JOINT_AUDIT.md','S2_REGULARIZATION_AUDIT.md',
         'FINAL_ACCOUNT_AUDIT.md','CONTINUE.md','FACE_CHECK.py','FACE_CHECK.json',
         'FACE_CHECK.md','REGULARIZATION_CHECK.py','REGULARIZATION_CHECK.json',
         'REGULARIZATION_CHECK.md','verify.py']
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def face_math(d):
    return {k:v for k,v in d.items() if k not in ('python_version','platform','cross_version_replay')}
def reg_math(d):
    return {k:v for k,v in d.items() if k not in ('python','sympy','python_flint','command')}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--replay',action='store_true')
    args=ap.parse_args()
    for name in PAYLOAD: assert (ROOT/name).is_file(),name
    for name in ('FACE_CHECK.py','REGULARIZATION_CHECK.py','verify.py'):
        ast.parse((ROOT/name).read_text(),filename=name)
    tex=(ROOT/'REPORT.tex').read_text()
    assert all(ord(c)>=32 or c in '\t\r\n' for c in tex)
    stack=[]
    for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
        kind,env=m.groups()
        if kind=='begin': stack.append(env)
        else: assert stack and stack.pop()==env,(kind,env)
    assert not stack
    assert ',qquad' not in tex
    assert digest(ROOT/'REPORT.tex') in (ROOT/'FINAL_ACCOUNT_AUDIT.md').read_text()
    assert digest(ROOT/'A1_EXPOSED_GEOMETRY.md') in (ROOT/'S2_REGULARIZATION_AUDIT.md').read_text()
    assert digest(ROOT/'A2_SHARED_DELETION.md') in (ROOT/'S1_JOINT_AUDIT.md').read_text()
    reg_note=(ROOT/'REGULARIZATION_CHECK.md').read_text()
    assert digest(ROOT/'REGULARIZATION_CHECK.py') in reg_note
    assert digest(ROOT/'REGULARIZATION_CHECK.json') in reg_note
    face=json.loads((ROOT/'FACE_CHECK.json').read_text())
    reg=json.loads((ROOT/'REGULARIZATION_CHECK.json').read_text())
    assert (face['instances'],face['line_v_checks'],face['generic_exposed_faces'],face['nongeneric_candidates_skipped'])==(12,338632,169898,18744)
    assert face['violations']==[] and len(face['records'])==84
    assert sum(r['lines'] for r in face['records'])==face['line_v_checks']
    assert {(r['n'],r['variant'],r['sign']) for r in face['records']}=={
        (n,v,s) for n in (2,3) for v in range(3) for s in (-1,1)}
    margins=[]
    for r in face['records']:
        for source,flux in r['flux'].items():
            margin=Fraction(r['projection_cap'][source])-Fraction(flux)
            assert margin>=0
            margins.append(margin)
    assert min(margins)==Fraction(51,200)
    cr=face['cross_version_replay']
    assert cr['mathematical_results_identical'] is True and cr['replay_returncode']==0
    assert face_math(face)==face_math(cr['original_complete_result'])
    assert reg['arb_bits']==256
    assert [int(x['n']) for x in reg['points']]==[1,2,16,256,2**20,2**40]
    assert all(x['Delta_lt_287_over_992'] and x['shell_lt_8'] for x in reg['points'])
    # Exact new ledger arithmetic. This does not reprove the geometric claims.
    assert 8*Fraction(32,31)+32*Fraction(33,512)==Fraction(5119,496)<11
    assert Fraction(8,31)+Fraction(1,32)==Fraction(287,992)<Fraction(1,3)
    out={'status':'PASS','python':sys.version,'command':sys.executable+' verify.py'+(' --replay' if args.replay else ''),
         'report_sha256':digest(ROOT/'REPORT.tex'),'python_ast_files':3,
         'tex_environments':'balanced; no PDF compilation','audit_bindings':'PASS',
         'frozen_face_record_validation':'PASS; 84 exact records, both prior versions identical',
         'minimum_recorded_margin':'51/200','frozen_arb_metadata':'PASS; six recorded points; interval experiment not rerun by default',
         'new_exact_fee_checks':'5119/496<11 and 287/992<1/3',
         'general_flux_bound':'UNPROVED','experiment_replay_this_invocation':'not requested'}
    if args.replay:
        base=Path('/Volumes/data/CodexTemp')
        if not base.is_dir(): raise RuntimeError('Required data temp volume absent; no system-disk fallback')
        work=Path(tempfile.mkdtemp(prefix='centered-cube-r665-replay-',dir=base))
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(work),TMP=str(work),TEMP=str(work))
        runs=[]
        for stem,transform,old in [('FACE_CHECK',face_math,face),('REGULARIZATION_CHECK',reg_math,reg)]:
            shutil.copy2(ROOT/(stem+'.py'),work/(stem+'.py'))
            cp=subprocess.run([sys.executable,stem+'.py'],cwd=work,env=env,capture_output=True,text=True,check=True)
            (work/(stem+'.log')).write_text(cp.stdout+cp.stderr)
            new=json.loads((work/(stem+'.json')).read_text())
            assert transform(new)==transform(old),stem+' mathematical record mismatch'
            runs.append({'script':stem+'.py','returncode':cp.returncode,'mathematical_fields_equal':True})
        out['experiment_replay_this_invocation']={'workdir':str(work),'runs':runs}
    manifest=ROOT/'MANIFEST.json'
    if manifest.exists():
        data=json.loads(manifest.read_text())
        for name,entry in data['members'].items():
            assert Path(name).name==name
            f=ROOT/name
            assert f.stat().st_size==entry['bytes'] and digest(f)==entry['sha256'],name
        out['manifest']='PASS: '+str(len(data['members']))+' payload members'
    else: out['manifest']='not present at this invocation; final archive must check separately'
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
