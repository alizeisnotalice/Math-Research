# R665 regularization certificate

The final run used `/Users/zzh/.local/share/math-research-tools/venv/bin/python REGULARIZATION_CHECK.py`, Python 3.12.14, SymPy 1.14.0, python-flint 0.9.0 and 256-bit Arb. Script SHA-256 `f786bc4cb047bb29ee115882838be05cb4d8d73e09c84800efcd63cccd1cfc77`; result JSON SHA-256 `90440bf7952c28a2048dc6fd90d988f6e46f8c8d073680890838165d860b35db`. The JSON records complete Arb enclosures, radii, all six exact n and m, and the command. An initial structural SymPy equality check was corrected to symbolic simplification, and an initial script that clipped v only at n=1 was corrected to clip whenever v>1. Only the final corrected run is recorded as the result.

For positive a, si<=sj, the inner-admission radius difference is exactly `(sj-si)/a>=0`; and |ui-yi|_infinity<=si/a implies Ai is contained in Ai'=Q(ui,c0 si). Thus the new parent volume is `(c0^n-1)d_i`. A repeat cover has volume `(2c0)^n d_i`, and Poisson factorial moment with b=8 plus `q_i^2<=a^-n q_i` gives the claimed fee `32(2c0/a)^n U`. These statements assume the prescribed exact owner and shared source conditions.

For every integer n>=1, `(1+1/(32n))^n<exp(1/32)` and `2c0/a=1/(16n)+1/(512n^2)<=33/512<1`. Therefore `Creg<8(exp(1/32)-1)+32(33/512)`, whose Arb enclosure is `[2.316447259992821367509982522252057153555986613134528768066789946571330668901 +/- 3.29e-76]`. For n>=256 the repeat coefficient is bounded by `32(33/512)^256<10^-300`, the last inequality checked using exact rational integers. This is a general bound, not an extrapolation from the six points.

Conditional on the proved A2 D2 shell estimate, put `v=min(1,(m^(1/n)-1)/c0)`; then `(1+c0 v)^n<=m` and `8[(1+c0 v)^n-1]/m<=8(1-1/m)<8`. For m=ceil(32768 sqrt(n)) the raw v is greater than one at n=1,2,16 and must be clipped. For every integer n>=256, `m<=32768n+1<2^n<(1+c0)^n`; the strict middle inequality holds at 256 and continues by induction, so the raw v is less than one in this range. This pays the truncated endpoint only and does not pay the remaining expansion to v=1.

## Sharper difference fee

Preserving the looser `Creg` above, the additional cost is `Delta=8(c0^n-1)+32 a^(-n)[(2c0)^n-(1+c0)^n]`. With X=2c0, Y=1+c0, X-Y=1/a and X>=Y, the exact factorization X^n-Y^n=(X-Y) sum_{j=0}^{n-1} X^(n-1-j)Y^j gives at most n/a X^(n-1)=(1/32)X^(n-1). The repeat extra is therefore <=(1/a)(2c0/a)^(n-1)<=1/32. Using binomial(n,j)<=n^j and the infinite geometric series gives c0^n<=32/31 for every positive integer n. Consequently Delta<=8/31+1/32=287/992<1/3, an exact general inequality.

The final 256-bit Arb run also checked the exact difference expression, its sharper bound and Delta<287/992 at n=1,2,16,256,2^20,2^40. The respective Delta values are approximately 0.28125, 0.2524471283, 0.2536957008, 0.2539315181, 0.2539472561, 0.2539472600; the full enclosures and their error radii are in the JSON. No AU budget follows from this fee.
