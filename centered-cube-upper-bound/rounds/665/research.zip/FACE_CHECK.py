"""Frozen exact line-slice diagnostic for source-labelled exposed faces."""
from fractions import Fraction as F
from itertools import product
import json, platform, sys

V=[F(1,10),F(2,5),F(49,100),F(1,2),F(51,100),F(3,5),F(9,10)]
def Q(x): return F(x)
def make(dim, variant, sign):
    # All A upper core faces equal 0; B's distinct face is 1/4.
    ds=[F(1),F(3,4),F(1,2),F(1,2),F(1,4)]
    src=['A','A','B','B','A']; face=[F(0),F(0),F(1,4),F(1,4),F(0)]
    # Cores are genuine nonempty boxes; equal-radius B labels are distinct keys.
    pieces=[]
    for j in range(5):
        lo=[face[j]-Q(1+j%2)]; hi=[face[j]]
        for d in range(1,dim):
            off=F((j+d+variant)%3-1,3)
            lo.append(off-F(2+j%2,2)); hi.append(off+F(3+(j+variant)%2,3))
        if sign==-1: lo[0],hi[0]=-hi[0],-lo[0]
        cap=F(12-j,3)
        cliplo=[-cap]*dim; cliphi=[cap]*dim
        pieces.append(dict(key='K'+str(j),source=src[j],delta=ds[j],lo=lo,hi=hi,clo=cliplo,chi=cliphi))
    # Common mask can have a hole as well as remove a moving endpoint.
    shift=F(variant-1,4)
    masks=[([-F(1,5)+shift]+[-F(1,3)]*(dim-1),[F(1,5)+shift]+[F(1,2)]*(dim-1)),
           ([F(4,5)]+[F(2,3)]*(dim-1),[F(1)]+[F(1)]*(dim-1))]
    if sign==-1:
        masks=[([-b[0]]+a[1:],[-a[0]]+b[1:]) for a,b in masks]
    return pieces,masks

def transverse_box(lo,hi,y): return all(lo[d]<y[d-1]<hi[d] for d in range(1,len(lo)))
def transverse_edges(pieces,masks,vs):
    n=len(pieces[0]['lo']); axes=[]
    for d in range(1,n):
        edges=set()
        for p in pieces:
            edges.update([p['clo'][d],p['chi'][d]])
            for v in vs: edges.update([p['lo'][d]-v*p['delta'],p['hi'][d]+v*p['delta']])
        for lo,hi in masks: edges.update([lo[d],hi[d]])
        e=sorted(edges); axes.append([(a,b) for a,b in zip(e,e[1:]) if a<b])
    return axes

def check(pieces,masks,v,y,sign):
    intervals=[]; endpoints=[]; candidate=[]
    for p in pieces:
        d=p['delta']; lo=[x-v*d for x in p['lo']]; hi=[x+v*d for x in p['hi']]
        if not transverse_box(lo,hi,y) or not transverse_box(p['clo'],p['chi'],y): continue
        a=max(lo[0],p['clo'][0]); b=min(hi[0],p['chi'][0])
        if a>=b: continue
        intervals.append((a,b,p))
        if a==lo[0]: endpoints.append((a,'moving',p))
        if a==p['clo'][0]: endpoints.append((a,'fixed',p))
        if b==hi[0]: endpoints.append((b,'moving',p))
        if b==p['chi'][0]: endpoints.append((b,'fixed',p))
        x=hi[0] if sign==1 else lo[0]
        if a<=x<=b: candidate.append((x,p))
    holes=[]
    for lo,hi in masks:
        if transverse_box(lo,hi,y): holes.append((lo[0],hi[0])); endpoints += [(lo[0],'mask',None),(hi[0],'mask',None)]
    coords=sorted(set(x for x,_,_ in endpoints))
    def occupied(t): return any(a<t<b for a,b,_ in intervals) and not any(a<t<b for a,b in holes)
    exposed={}; skipped=0
    for x,p in candidate:
        hits=[(typ,obj) for xx,typ,obj in endpoints if xx==x]
        # Fixed/mask ties and moving ties between differing source/velocity are nongeneric.
        if any(typ!='moving' for typ,_ in hits) or len({(obj['source'],obj['delta']) for typ,obj in hits if obj is not None})>1:
            skipped+=1; continue
        k=coords.index(x)
        left=occupied((coords[k-1]+x)/2 if k else x-1); right=occupied((x+coords[k+1])/2 if k+1<len(coords) else x+1)
        if (left and not right) if sign==1 else (right and not left):
            exposed.setdefault(p['source'],{}).setdefault(x,set()).add(p['delta'])
    return exposed,skipped

def run():
    stats={'instances':0,'line_v_checks':0,'generic_exposed_faces':0,'nongeneric_candidates_skipped':0,'violations':[], 'records':[]}
    # 12 frozen finite instances; actual n=2,3, variants=0..2, signs +/-.
    for n,variant,sign in product([2,3],range(3),[-1,1]):
        ps,ms=make(n,variant,sign); stats['instances']+=1
        cells=list(product(*transverse_edges(ps,ms,V+[F(1)])))
        for v in V:
            flux={}; cap={}; linecount=0
            for cell in cells:
                y=tuple((a+b)/2 for a,b in cell); area=F(1)
                for a,b in cell: area*=b-a
                exp,skip=check(ps,ms,v,y,sign); stats['nongeneric_candidates_skipped']+=skip
                stats['line_v_checks']+=1; linecount+=1
                for s,loc in exp.items():
                    if len(loc)>1: stats['violations'].append(['multiple',n,variant,sign,str(v),list(map(str,y)),s])
                    vel=max(d for vals in loc.values() for d in vals)
                    flux[s]=flux.get(s,F(0))+vel*area; stats['generic_exposed_faces']+=len(loc)
                    # A fixed-v=1 *unmasked* projection is an upper envelope.
                    eligible=[p['delta'] for p in ps if p['source']==s and transverse_box([x-p['delta'] for x in p['lo']],[x+p['delta'] for x in p['hi']],y) and transverse_box(p['clo'],p['chi'],y)]
                    if not eligible or vel>max(eligible): stats['violations'].append(['speed',n,variant,sign,str(v),list(map(str,y)),s])
                for s in ('A','B'):
                    eligible=[p['delta'] for p in ps if p['source']==s and transverse_box([x-p['delta'] for x in p['lo']],[x+p['delta'] for x in p['hi']],y) and transverse_box(p['clo'],p['chi'],y)]
                    if eligible: cap[s]=cap.get(s,F(0))+max(eligible)*area
            for s,val in flux.items():
                if val>cap[s]: stats['violations'].append(['integral',n,variant,sign,str(v),s,str(val),str(cap[s])])
            stats['records'].append(dict(n=n,variant=variant,sign=sign,v=str(v),lines=linecount,flux={s:str(x) for s,x in flux.items()},projection_cap={s:str(x) for s,x in cap.items()}))
    stats['python_version']=sys.version; stats['platform']=platform.platform(); stats['v_values']=[str(x) for x in V]; stats['method']='exact rational cross-section; v=1 unmasked projection envelope; all endpoints cell-partitioned'
    with open('FACE_CHECK.json','w') as f: json.dump(stats,f,indent=2)
    print('instances',stats['instances'],'line-v checks',stats['line_v_checks'],'exposed',stats['generic_exposed_faces'],'skipped nongeneric candidates',stats['nongeneric_candidates_skipped'],'violations',len(stats['violations']))
    if stats['violations']: print(stats['violations'][:10]); raise SystemExit(1)
if __name__=='__main__': run()
