"""R665 finite Arb enclosures and exact symbolic regularization checks."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json, sys
import sympy as sp
import flint
from flint import arb, ctx

si,sj,a=sp.symbols('si sj a',positive=True)
c=1+1/a
radius=si/a+(1-1/a)*sj+sj/a
gap=sp.factor(c*sj-radius)
assert sp.simplify(gap-(sj-si)/a)==0
# Ai subset Ai' because centre shift <= si/a, expansion adds exactly si/a.
assert sp.simplify(c*si-si-si/a)==0
# Parent volume increment: (c^n-1)d_i. Repeat cover Ai'+c si Q has
# volume (2c)^n d_i; 8^2/2=32 and q_i^2<=a^(-n)q_i.
assert F(8**2,2)==32
assert F(8,31)+F(1,32)==F(287,992)<F(1,3)
base=F(33,512) # 2*(1+1/32)/32
assert base==2*(1+F(1,32))/32
assert 32*base**256 < F(1,10**300)
# Exact induction base for m=ceil(32768 sqrt(n)) <=32768n+1<2^n.
assert 2**256>32768*256+1
assert 32768*2+1 < 2*(32768+1)
ctx.prec=256
points=[]
for n in (1,2,16,256,2**20,2**40):
    an=32*n
    c0=1+arb(1)/an
    first=8*(c0**n-1)
    second=32*(2*c0/an)**n
    total=first+second
    repeat_difference=32*((2*c0/an)**n-((1+c0)/an)**n)
    delta=first+repeat_difference
    repeat_difference_bound=(2*c0/an)**(n-1)/an
    assert repeat_difference>=0 and repeat_difference <= repeat_difference_bound
    assert delta < arb(287)/992
    global_bound=8*((arb(1)/32).exp()-1)+32*arb(33)/512
    assert first>=0 and second>0 and total < global_bound
    s=isqrt((32768**2)*n)
    m=s+(s*s != (32768**2)*n)
    v=(arb(m).log()/n).exp()
    v=(v-1)/c0
    if n==1: assert v>1
    if n>=256: assert v<1
    assert v>1 or v<1
    vclip=arb(1) if v>1 else v
    shell=8*((1+c0*vclip)**n-1)/m
    # Interval computations can include equality at 8(1-1/m), so no strict
    # interval comparison against that mathematically equal value is asserted.
    assert shell < 8
    points.append({'n':str(n),'m':str(m),'raw_v':str(v), 'clipped_v':str(vclip),
      'source_expansion':str(first),'repeat':str(second),'Creg':str(total),
      'repeat_extra':str(repeat_difference),'repeat_extra_bound':str(repeat_difference_bound),'Delta':str(delta),'Delta_lt_287_over_992':True,
      'shell_coefficient':str(shell),'Creg_lt_global_bound':True,'shell_lt_8':True})
result={'python':sys.version,'sympy':sp.__version__,'python_flint':flint.__version__,
 'arb_bits':ctx.prec,'command':'/Users/zzh/.local/share/math-research-tools/venv/bin/python REGULARIZATION_CHECK.py',
 'containment_gap':'(sj-si)/a >= 0 for 0<si<=sj; centre shifts <=si/a',
 'global_bound':'Creg < 8*(exp(1/32)-1)+32*(33/512)',
 'general_reason':'(1+1/(32n))^n < exp(1/32); 2c0/a=1/(16n)+1/(512n^2) <= 33/512 < 1, so its nth power <=33/512',
 'large_n_repeat':'32*(33/512)^256 < 10^-300, hence repeat term < 10^-300 for all integers n>=256',
 'difference_fee':'Delta=8*(c0^n-1)+32*a^(-n)*((2c0)^n-(1+c0)^n)',
 'difference_bound':'repeat extra <= (1/a)*(2*c0/a)^(n-1) <= 1/32; c0^n<=32/31; Delta<=287/992<1/3',
 'shell':'D2: 8/m*((1+c0*v)^n-1); v=min(1,(m^(1/n)-1)/c0) gives <=8(1-1/m)<8',
 'large_n_v':'n>=256: ceil(32768 sqrt n)<=32768n+1<2^n<(1+c0)^n, so unclipped v<1',
 'scope':'the shell endpoint is paid; remaining interval to v=1 is not established',
 'points':points}
Path('REGULARIZATION_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print('symbolic gap:',gap,'; expansion identity exact')
print('global Creg bound:',8*((arb(1)/32).exp()-1)+32*arb(33)/512)
for p in points:
 print('n='+p['n'],'m='+p['m'],'Creg='+p['Creg'],'Delta='+p['Delta'],'repeat_extra='+p['repeat_extra'],'repeat='+p['repeat'],'raw v='+p['raw_v'],'shell coefficient='+p['shell_coefficient'])
print('Python',sys.version.split()[0],'SymPy',sp.__version__,'python-flint',flint.__version__,'Arb bits',ctx.prec)
