"""R741 finite reversible checks and two-source, two-scale true histories."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as Q
from math import isqrt,gcd,lcm
from pathlib import Path
import hashlib,json,platform,subprocess,sys

def walk(N,m,remote):
    # Symmetric edge masses; rows have distinct total degrees.
    adj=[{} for _ in range(N)]
    for i in range(N):
        j=(i+1)%N;v=2+(i%3)
        adj[i][j]=v;adj[j][i]=v
    for i in range(0,N//2,2):
        j=i+N//2
        adj[i][j]=adj[j][i]=1
    deg=[sum(row.values()) for row in adj]
    base=lcm(*deg)
    terminal=[0]*N
    terminal[0]=4;terminal[1]=1;terminal[N//3]=3  # common denominator 5
    best=[Q(x,5) for x in terminal];first=[0]*N
    vals=[v*d for v,d in zip(terminal,deg)] if remote else list(terminal)
    scale=5
    for step in range(1,m+1):
        if remote:
            nxt=[0]*N
            for i,row in enumerate(adj):
                for j,w in row.items():
                    nxt[j]+=vals[i]*w*(base//deg[i])
        else:
            nxt=[(base//deg[i])*sum(w*vals[j] for j,w in row.items()) for i,row in enumerate(adj)]
        vals=nxt;scale*=base
        for i in range(N):
            den=scale*(deg[i] if remote else 1)
            if vals[i]*best[i].denominator>den*best[i].numerator:
                best[i]=Q(vals[i],den);first[i]=step
    ratio=sum(d*x*x for d,x in zip(deg,best))/sum(d*Q(x,5)**2 for d,x in zip(deg,terminal))
    assert ratio<=8
    marker=Q(1,N)
    added=sum(1 for i in range(N) if terminal[i]==0 and best[i]>=marker)
    digest=hashlib.sha256('|'.join(str(q) for q in best).encode()).hexdigest()
    return dict(rows=N,last_power=m,paid_new_at_inverse_N=added,best_beyond_one=sum(s>1 for s in first),
                max_square_ratio_bounds=[(ratio*10**8).__floor__(),(ratio*10**8).__ceil__()],scale=10**8,hash=digest)

specs=[(n,m) for n,m in [(8,8),(24,24),(64,64),(128,128),(192,192)]]
def finite(remote):
    with ThreadPoolExecutor(max_workers=3) as pool:
        return list(pool.map(lambda s:walk(*s,remote),specs))

if '--remote' in sys.argv:
    print(json.dumps([platform.python_version(),finite(True)]));sys.exit()
from flint import arb,ctx
import flint
ctx.prec=256
def exact(x):
    return arb(x.numerator)/x.denominator

def history(n):
    # Four common parents after K-4 baseline parents. Eight receiver rows.
    a=32*n;root=isqrt(n)
    assert root*root==n and (n-4)%2==0
    r0=Q(1,root);S=1+r0/8
    h=1+Q(1,a);hb=exact(h)*(arb(2)**(arb(1)/n))
    assert 2*exact(r0)/a + hb*exact(S)<exact(Q(3,2))
    assert hb*exact(S)-(1-exact(r0)/4)<2*exact(r0)
    assert hb-(1-exact(r0)/4)<exact(r0)
    assert 6*r0>3*r0 and 6*r0+2*r0/a<1
    assert 3*r0/4-r0/8-2*r0/a>6*S/n
    assert S-1>(S+1)/a
    assert 2*exact(h)*n*exact(r0)/arb(n).log()>exact(S)
    assert arb(n-4)*arb(2).log()>arb(n).log()/2
    assert 16*n>4*exact(h)*n*exact(r0)/arb(n).log()
    K=4096*root*a**n;ell=arb(2).log()/K
    vol=4*((2*exact(r0)/a)**n+(4*exact(r0)/a)**n)
    highweight=(2*ell).expm1()/2
    R=vol*highweight
    # Exact K-term baseline compressed; G <= D < 3G.
    logG=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert logG>(4*arb(6)**n+4).log()
    assert highweight>0 and highweight<arb(1)/64 and R>0
    # Positive fourfold phase overlaps in first target group for source 1
    # and in second target group for source S, which is on its long branch.
    dshort=2*hb/n;dlong=2*hb*exact(S)*arb(n).log()/(4*n)
    wshort=2*exact(r0)/a;wlong=4*exact(r0)/a
    assert 0<wshort and wshort<dshort and 0<wlong and wlong<dlong
    return dict(n=n,rec_radii=[str(r0),str(2*r0)],high_source_radii=[str(S),'1'],target_count=8,
        V_T=str(vol),R_high=str(R),highweight=str(highweight),logD_over_K=[str(logG/K),str((logG+arb(3).log())/K)],
        M_exact=0,alpha='1/4',normalized_positive_excess_exact=0,
        pre_deletion_four_corner_overlaps=[str((wshort/(2*dshort))**2),str((wlong/(2*dlong))**2)])

def thin_history_exponents():
    """Integer upper bounds for the inherited R710 family."""
    results = []
    assert 2 * 127 ** 128 < 128 ** 128
    for power in (16, 20, 24, 32, 48, 56):
        n = 2 ** power
        k = isqrt(n)
        m = power // 4
        layers = 17 * k * 2 ** m + 1
        assert 3 * layers < 16 * n
        blocks = (n - m - k) // 128
        assert 1 + k//2 - n*(power + 5) <= -blocks
        assert 3 * layers <= 68 * k * 2 ** m
        results.append(dict(power=power, parent_fraction_log2_upper=power//2 + 5 - blocks))
    return results

def positive_core_history():
    """Exact bounds in one genuine two-scale history, with a fixed small c."""
    n = 64
    a = 32 * n
    source_volume = 2 ** n
    weight = 1 - Q(1, a ** 256)
    volume = Q(3, 16) ** 4 * Q(21, 8) ** 60
    spans = (Q(3, 16), Q(21, 16), Q(21, 8))
    grids = []
    for side in (Q(1, a), Q(3, 2 * a)):
        counts = [span / side for span in spans]
        assert all(count.denominator == 1 for count in counts)
        grids.append([int(count) for count in counts])
    assert grids == [[384, 2688, 5376], [256, 1792, 3584]]

    source_bill = weight * source_volume
    total_bill_upper = source_bill + volume / a ** 192
    assert volume / a ** 192 < Q(1, 2)
    assert Q(9, 8) > 1 + Q(6, n)
    unpaired_bound = 2 * Q(32, 31) * Q(17, 6)
    assert Q(17, 6) ** 4 > n and unpaired_bound < 6
    mass_lower = weight * (volume - 6 * source_volume) - volume / 32
    assert mass_lower > 8 * source_bill
    upper_excess = (weight * volume - volume / 4) / (8 * source_bill)
    lower_excess = (mass_lower - volume / 4) / (8 * total_bill_upper)
    scale_mass_lower = mass_lower - weight * volume / 2
    minimum_coverage = Q(7, 32) ** n
    assert minimum_coverage > Q(1, n ** 24) and weight ** 4 > Q(1, n)
    def enclosure(value):
        scale = 10 ** 8
        return [(scale * value).__floor__(), (scale * value).__ceil__()]
    assert lower_excess > Q(8384246, 100000) and upper_excess < Q(8827041, 100000)
    return dict(n=n, grids=grids, c="2048^(-64)/(2048*log(2048))",
                V_T="(3/16)^4*(21/8)^60", d0=source_volume,
                D_range=["theta*d0", "theta*d0+V_T/2048^192"],
                theta="1-2048^(-256)", R_high="theta*V_T",
                M_range=["theta*(V_T-6*d0)-V_T/32", "theta*V_T"],
                decimal_scale=10 ** 8, M_over_V_lower_enclosure=enclosure(mass_lower / volume),
                M_in_each_scale_over_V_lower_enclosure=enclosure(scale_mass_lower / volume),
                excess_lower_enclosure=enclosure(lower_excess), excess_upper_enclosure=enclosure(upper_excess),
                parent_coverage_lower="(7/32)^64 > 64^(-24)")

cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
with ThreadPoolExecutor(max_workers=2) as ex:
    pf=ex.submit(subprocess.run,cmd,input=Path(__file__).read_text(),text=True,capture_output=True,check=True,timeout=100)
    lf=ex.submit(finite,False)
    histories=[history(n) for n in (256,1024,4096)]
    rv,rs=json.loads(pf.result().stdout);ls=lf.result()
assert ls==rs
print(json.dumps(dict(python=sys.executable,local=platform.python_version(),flint=flint.__version__,arb_bits=256,cmd=cmd,
    remote=rv,exact_walks=ls,true_histories=histories,positive_history=positive_core_history(),thin_histories=thin_history_exponents()),indent=2))
