# R202：原捕获归一化的真实偏差、来源重叠与时间账

状态：证明原归一化项的精确分裂及一项无额外来源矩假设的显式重叠估计，并核对真实删除过程的熵账。没有证明一般中间 hard 域的原 raw 根阶预算。新估计在全部重叠范围成立；重叠接近 1 时仍有线性维数的一阶费用，不能以稀少损失的收益代替一般情形。

## CN1　对象、固定量与导数资格

固定原 `(ω,V,j,y,t)`、一个原窗口及其 b。记 ν=νV、
\[
 \eta_t(v)=1_{Z_t(y)}(v)w_t(y,v),\quad
 e_t=\int\eta_t\,d\nu,\quad \Pi_t=\eta_t\nu/e_t.
\]
这些量在该固定状态下独立于 receiver x 和当前运行尺度 L。e_t=0 的原行先置零；以下只写 e_t>0。ν 是有限正测度，不假设 ν≤β、来源梯度或全 ν 的二阶矩。原 β、ν 仅使用已修复的共同父来源预算 Wβ,Wν≤WA。

原 J 核、完整来源归一化及捕获量为
\[
 J_v(x)=b^{-n}\prod_i\phi((x_i-v_i)/b),\quad
 Q(x)=\int J_v(x)\nu(dv),\quad
 M_U(x)=\int U_v(x)\nu(dv),\quad
 \alpha Q=Dq-M_U.
\]
其中原 U、capture E、同一 α 及所有 good/high/history 门保持原定义。原 active target 上
\[
 a_v=T\Delta_v>0,\quad k_v=DK_{0v},\quad
 \rho_v=1-(k_v+\alpha J_v)/a_v>0.
\]
这只是原 capture 内的 RC 身份；不把它当作 E 外任意余权的微分公式。

令 Xy=x−y、材料导数 \(\mathcal D_y=\partial_{\log L}+X_y\cdot\nabla_x\)。在同一来源、固定 b 及具有实际导数的共同合法分支上，
\[
 \boxed{\mathcal D_y(\alpha J_v)
 ={J_v\over Q}\big[\mathcal D_y(Dq)-\mathcal D_yM_U\big]
 +\alpha J_v\,X_y\cdot(\nabla\log J_v-\nabla\log Q).} \tag{CN1}
\]
只有在已证明 Dq 沿所用分支冻结时才删第一括号内的对应项。M_U 的 BV、capture 门的迹或实际选择器可微性不由 CN1 保证。没有这些资格时，使用本轮 `mixture_score_geometry.md` MG25 的有限差分，保留真实 capture 交换。原 j/window、ν 或 η 改变也须另付状态交换。

## CN2　原平方系数确实给出的抑制

写原分母及平方帽
\[
 S_v=p_v+p_v^++J_v,\quad z_v=J_v/S_v,\quad
 F_v=\min(p_y^2,B_v^2J_v^2)/J_v,\quad W_v=\rho_v^2z_v^2F_v.
\]
Bv 是实际使用的帽，可依来源；特别 B0/Wg(y,v) 可能很大，不能从来源积分免费提出。在 active target 上设 ζv=αJv/av。因 ρv+ζv≤1，有
\[
 0\le 2\rho_v\zeta_v\le\tfrac12. \tag{CN2}
\]
CN1 中完整归一化得分对 \(\mathcal D_y W_v\) 的贡献恰为
\[
 \mathcal N_v=-2\rho_v\zeta_v z_v^2F_v\,
 X_y\cdot(\nabla\log J_v-\nabla\log Q). \tag{CN3}
\]
α=0 时该项点态为零，不先形成倒 α；这不删除 CN1 中可能非零的 capture 导数。ρ=0 不用除 ρ；其余导数用原平方表达或合法有限差分处理。

CN2 是来自原 same-α 的真实抑制，不需要辅助 posterior 改写 α。它仍没有把原 Π 变成 Jν/Q。

## CN3　按真实 Π 重新中心化及显式测度关系

令 m=ν(Rn)、νw=ηtν、νl=(1−ηt)ν，
\[
 Q_w=J*\nu_w,\quad Q_l=J*\nu_l=Q-Q_w,\quad
 \widehat p_w=Q_w/e_t,\quad
 \pi_w(dv)=J_v\nu_w(dv)/Q_w,\quad
 \pi(dv)=J_v\nu(dv)/Q.
\]
νl 包含初始 carrier 外来源、实际删除及软权衰减，不能都称为本时间段新删除质量。e_t>0 给 m>0、Qw,Q>0，且 \(\widehat p_w dx\) 是概率。精确有
\[
 J_v\Pi_t(dv)=\widehat p_w(x)\pi_w(dv). \tag{CN4}
\]
令 gv=∇logJv、gw=∇logQw、g=∇logQ，
\[
 T_w(v)=X_y\cdot(g_v-g_w),\quad
 \mathfrak b_t=X_y\cdot(g_w-g)
 =X_y\cdot\nabla\log(Q_w/Q).
\]
于是完整得分为 Tw+𝔟t，且 Eπw Tw=0。对任意实际 target 系数 Cv，
\[
 \int\Pi_t(dv) C_v\alpha J_v X_y\cdot(g_v-g)
 ={\alpha Q_w\over e_t}
 \left[\operatorname{Cov}_{\pi_w}(C_v,X_y\cdot g_v)
 +\mathfrak b_t\mathbb E_{\pi_w}C_v\right]. \tag{CN5}
\]
这是 MG14 的原测度接口。Cv 中的 ρ、Bv、H、另一个 u 槽及原资格不可从协方差或均值中删除。下面对偏差取得新显式界，不重复证明 MG 的标准条件方差。

## CN4　真实 selected/lost 卷积重叠

定义
\[
 r_t(x)={Q_l(x)\over Q(x)},\qquad
 \mathfrak o_t={1\over e_t}\int {Q_w(x)Q_l(x)\over Q_w(x)+Q_l(x)}dx.
 \tag{CN6}
\]
Q_l=0 时 r_t=0、𝔬t=0、𝔟t=0。否则所有混合核严格正。直接由正性及各卷积总质量，
\[
 \boxed{\mathfrak o_t=\mathbb E_{\widehat p_w}r_t
 \le q_t:=\min\{1,(m-e_t)/e_t\}.} \tag{CN7}
\]
这保留同一原输入在 receiver 空间的真实卷积重叠，而非两个来源各自的 supremum。q_t 是进一步正放后的显式质量价，不称其一般很小。

混合梯度的凸组合给精确式
\[
 g_w-g=r_t(g_w-g_l),\qquad g_l=\nabla\log Q_l.
\]
已证 |φ′/φ|≤8，因此所有这些混合梯度的每一坐标绝对值≤8/b。设 Z=||x−y||1/b，得到
\[
 \boxed{|\mathfrak b_t(x)|\le16 Z(x)r_t(x).} \tag{CN8}
\]
全 ν 可任意远；CN8 没有使用全来源位置矩。

## CN5　偏差的一阶及二阶显式重叠预算

原 Π carrier 的准确资格见 R188 `source_reversibility.md` SR2，亦已在本轮 MG7 保留：
\[
 \|v-y\|_1\le17na,\quad
 \|v-y\|_\infty\le b(5\log n+1/2)\quad\text{on supp }\Pi_t.
\]
本节只需第一项，令
\[
 R=17na/b,\qquad A_n=R+2n(\log2+1/4).
\]
A_n 在本稿是尾界常数，不是原 target 权 A_v。J 是 h 与尺度≤1的 Laplace 混合的乘积，故单坐标
\[
 \mathbb E_\phi e^{|X|/2}\le2e^{1/4}.
\]
在概率 \(\widehat p_w dx\) 下，可先按原 Π 抽取 v，再令 x=v+bX，X 有 φ 的乘积律；这里只描述卷积积分，不假设原来源坐标独立。于是
\[
 \Pr_{\widehat p_w}\{Z>A_n+2s\}\le e^{-s},\qquad s\ge0. \tag{CN9}
\]

**命题。** 定义 q=𝔬t，并按 q=0 连续取零，则
\[
 \boxed{\int\widehat p_w|\mathfrak b_t|dx
 \le16q\,[A_n+2\log(1/q)+2].} \tag{CN10}
\]
同时
\[
 \boxed{\int\widehat p_w\mathfrak b_t^2dx
 \le256q\{[A_n+2\log(1/q)]^2
 +4[A_n+2\log(1/q)]+8\}.} \tag{CN11}
\]
两式可将 q 换为 CN7 的 q_t，不额外假设质量帽。

证明：若 0≤h≤1、Eh≤q，令 z0=A_n+2log(1/q)。由 CN9 及 layer cake，
\[
 E(hZ)\le qz_0+\int_{z_0}^{\infty}\Pr(Z>z)dz
 \le q(z_0+2),
\]
\[
 E(hZ^2)\le qz_0^2+\int_{z_0}^{\infty}2z\Pr(Z>z)dz
 \le q(z_0^2+4z_0+8).
\]
第一式用 h=r_t；第二式由 r_t²≤r_t 和 CN8。q=0 时 r_t=0 几乎处处，偏差为零。两右端关于 q∈(0,1] 单调：去掉常数后导数分别为 A_n+2log(1/q) 及其平方，因此可用 q_t 上放。证毕。

这是一项全输入重叠估计。q≈1 时 CN10 为 O(n)，CN11 为 O(n²)；它们不产生一般根阶。q 很小时保留 qlog(1/q) 收益，不再收裸 m/e 倍数或全 ν 二阶矩。若先用 q_t 代替 𝔬t，会丢失实际空间可辨识性；不能把数值中的稀有来源例解释成普遍低重叠。

## CN6　归一化项的实际回代及全部费用

固定同一 `(j,y,t)`，若 Bv≤B* 对 x 和所有实际 target 统一，且 B* 不依 x，则 CN2、CN4 给
\[
 \int_{E_{\rm rec}}dx\int\Pi_t(dv)|\mathcal N_v|
 \le {B_*^2\over2}
 \left[\int\widehat p_w\mathbb E_{\pi_w}|T_w|dx
       +\int\widehat p_w|\mathfrak b_t|dx\right].
\]
MG17 和 CN10 得到真实价格
\[
 \boxed{\int_{E_{\rm rec}}dx\int\Pi_t|\mathcal N_v|
 \le {B_*^2\over2}\left[
 \sqrt{nV_{\rm sc}+I_{\rm loc}C_w}
 +16\mathfrak o_t\{A_n+2\log(1/\mathfrak o_t)+2\}\right],} \tag{CN12}
\]
\[
 C_w=\int\|(v-y)/b\|_2^2\Pi_t(dv)
 \le17n(a/b)(5\log n+1/2),\quad
 V_{\rm sc}\le9/4,\ I_{\rm loc}\le64.
\]
CN12 是原平方材料导数中的**归一化一项**，不是整个 companion，也不是原 raw。另一个原 Πu 槽及 0≤H≤1 可以先在同一测度中保留，再为这个绝对上界正放成≤1。没有把 bad 槽或 α 重选成新来源。

B* 可作为真实 row 上 Bv 的上确界并保留在右端，但不授予其统一小价。实际 Bv=B0/Wg(y,v) 的 tiny-Wg 费用仍在。若不取该上确界，必须保留原精确积分
\[
 \int_{E_{\rm rec}}dx\iint\Pi_t(du)\Pi_t(dv)\,
 H\,2\rho_v\zeta_v z_v^2F_v
 \big|X_y\cdot\nabla\log(Q_w/Q)\big|. \tag{CN13}
\]
CN13 的变 target 系数不能由 CN10 的无 target 权概率界免费支付。

令右端方括号为显式 K(j,y,t)。在 B* 资格成立的来源部分，原外 β、j/time 价格完整为
\[
 {1\over2}\mathbb E\sum_{V,j}\int_{I_j}{dt\over t}
 \int\beta_V(dy)\,B_*(j,y,t)^2K(j,y,t). \tag{CN14}
\]
I_j 是固定 j 的 ξ=cjt/b∈[1/2,1] 与原可定义域的交集，e_t=0/域外行取零。这里只对绝对项作正上放；不能因此丢掉原唯一 j 或将多个窗口各算成同一份概率。若 B*、K 有统一界，CN14≤B*² K T* Wβ/2，T* 取实际完整 j/time 预算（跨窗口须取统一上界或保逐窗加权）。Wβ≤WA 可用；ν≤β 不可用。若还积分辅助 logL 路径，保其真实长度及状态交换，不能把路径积分免费换成适应的 L(x) 正变差。

η_t 随 t 减少，故在同一固定初始来源和正 e_t 区间，q_t 单调不减。CN10 的质量上界可在**固定、x 独立**辅助时间区间用末端 q_t 上放；末端 e=0 时只用 q=1。真实 g(x) 不得无声替代该固定端点再移出 dx。仅此单调性不给 ∫dt/t·𝔬t 一份删除质量价，尤其原初始 carrier 外来源已计入 νl。

即使 CN12 的方括号被改进成 O(√n)，若它最后作为 companion C 进入已修复的 E_J≤nWA/(2K) 的 Cauchy，仍可能只有 raw n^(3/4)；本稿不称根阶闭合。

## CN7　真实时间熵账：能保什么，不能替什么

本节只用原固定 b、ν 和实际 η_t，不引入热流或重选 J。令
\[
 p=Q/m,\quad p_t=Q_w/e_t,\quad
 \mathcal K_t=D(p_t\Vert p).
\]
凸性/Jensen（将来源 joint 的似然在 x 下条件平均）给
\[
 0\le\mathcal K_t\le
 D(\Pi_t\Vert\nu/m)
 =\int\Pi_t\log(m\eta_t/e_t)
 \le\log(m/e_t). \tag{CN15}
\]
η=0 的来源在 Πt 下为零，不形成 0log0 的倒数。这一端点熵上界保留 m/e_t，未证明小。

在无删除的连续 logt 段，原权重满足 η′=−k_tη、0≤k_t≤n。因此令 \(\bar k_\Pi=E_{\Pi_t}k_t\)、\(\bar k_w(x)=E_{\pi_w}k_t\)，有
\[
 e_t'=-e_t\bar k_\Pi,\quad Q_w'=-Q_w\bar k_w,\quad
 p_t'=p_t(\bar k_\Pi-\bar k_w),
\]
\[
 \boxed{\mathcal K_t'=
 \int p_t(\bar k_\Pi-\bar k_w)\log(p_t/p)dx.} \tag{CN16}
\]
可在正 e_t 的紧时间子段先截断 log 后取极限；k_t 有界且 p_t/p≤m/e_t，给相应可积控制。这里出现真实 score 与 log-likelihood 的协方差，**不是** \(\int p_t\mathfrak b_t^2\)，且无已证明的耗散符号。

一次并发删除的质量比例为 d∈[0,1)，删除来源经同 J 归一的密度为 pD，则
\[
 p_-=(1-d)p_++dp_D,
\]
\[
 \boxed{(1-d)D(p_+\Vert p)+dD(p_D\Vert p)-D(p_-\Vert p)
 =(1-d)D(p_+\Vert p_-)+dD(p_D\Vert p_-)\ge0.} \tag{CN17}
\]
d=0 单独取零，d=1 后原行消失而不定义后验。CN17 收每次实际并发删除一次，未把旧负信用转给新正交通。它也不推出单独 K_t 单调。

因此原时间熵若要支付 CN13，首个尚未证明的实质桥是：在**原 target 系数**下，将材料概率梯度平方或其一阶绝对量，控制到 CN16 的可累计有符号项和 CN17 的实际删除缺口，另保捕获及 selector 交换。原 η_t 是来源软权与森林删除，不是共同空间热半群；没有 de Bruijn 身份可直接套用。仅有 CN15 的有限端点熵不足以补出该桥。

## CN8　当前明确剩余问题及下轮取向

本轮已得到 CN10–12 的实际归一化偏差价格，消除使用全 ν 位置矩及裸 ν(V)/e 的不必要放大。它保留完整空间重叠，在任意有限 ν 上有定义。

一般中段尚有以下具体费用，均未被宣称已付：

1. CN13 中 𝔬t 接近 1 且 Bv、ρ、z、H 与空间偏差相关的原加权积分；CN10 在此仍为 O(n)。
2. CN1 中真实 \((J_v/Q)[\mathcal D(Dq)-\mathcal D M_U]\)。已有 lost capture 上界不是补偿下界，且不能假设资格 BV。
3. 原 current/target 硬面、H、j/time、b/来源改变、receiver 截断边界与适应 selector 的交换。全空间绝对核估计不能自行消掉它们。

精确空间对象还可写成 \(r_+(x)=Q_w/Q\)、\(e_0=e_t/m\) 下的
\[
 \int p_t\mathfrak b_t^2dx
 ={1\over e_0}\int p(x)
 {\big(X_y\cdot\nabla r_+(x)\big)^2\over r_+(x)}dx. \tag{CN18}
\]
这保留原软标签后验捕获概率的材料 Dirichlet 量；不能用它的新名称代替付款。下一步若使用尺度扩散/Stein 表示，必须保留 full 与 selected 混合各自不同的后验扩散系数及其交换，不能把坐标各自混合的 φ 变成一个共同 Gaussian 时间。本文不导入未核验的外部熵耗散定理。
