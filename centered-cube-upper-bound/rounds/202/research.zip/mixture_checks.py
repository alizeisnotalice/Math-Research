#!/usr/bin/env python3
"""Finite exact, scalar quadrature and MC selected-mixture score checks."""
import argparse,hashlib,json,math,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import numpy as np
import mpmath as mp
HERE=Path(__file__).resolve().parent
SAMPLES=20003


def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x


def exact_checks():
    K=[[F(1,2),F(1,4),F(1,4)],[F(1,10),F(3,10),F(3,5)]]
    D=[[F(1,10),-F(1,20),-F(1,20)],[-F(1,50),F(3,50),-F(1,25)]]
    for row,derivative in zip(K,D):
        assert sum(row)==1 and sum(derivative)==0
        for theta in (-F(1,2),F(1,2)):
            assert all(k+theta*d>0 for k,d in zip(row,derivative))
            assert sum(k+theta*d for k,d in zip(row,derivative))==1
    rows=[]
    for label,prior,w in [('equal_capture',[F(3,4),F(1,4)],[F(1),F(1)]),
            ('rare_selected',[F(99,100),F(1,100)],[F(0),F(1)]),
            ('mixed_capture',[F(3,4),F(1,4)],[F(1,10),F(1)])]:
        e=sum(p*a for p,a in zip(prior,w));lhs=inner=bias=cross=F(0);points=[]
        for x in range(3):
            Q=sum(prior[i]*K[i][x] for i in range(2));Qw=sum(prior[i]*w[i]*K[i][x] for i in range(2))
            full=sum(prior[i]*D[i][x] for i in range(2))/Q
            weighted=sum(prior[i]*w[i]*D[i][x] for i in range(2))/Qw
            scores=[D[i][x]/K[i][x] for i in range(2)]
            direct=sum(prior[i]*w[i]*K[i][x]*(scores[i]-full)**2/e for i in range(2))
            inside=sum(prior[i]*w[i]*K[i][x]*(scores[i]-weighted)**2/e for i in range(2))
            b=Qw/e*(weighted-full)**2
            c=sum(prior[i]*w[i]*K[i][x]*(scores[i]-weighted)*(weighted-full)/e for i in range(2))
            assert direct==inside+b and c==0
            lhs+=direct;inner+=inside;bias+=b;cross+=c
            points.append({'x':x,'Q':Q,'Qw':Qw,'g_full':full,'g_w':weighted,'direct_joint':direct,'conditional_variance':inside,'bias':b,'cross':c})
        assert lhs==inner+bias and cross==0
        if label=='rare_selected':assert inner==0 and bias==lhs>0
        rows.append({'label':label,'prior':prior,'capture_weights':w,'e':e,'lhs':lhs,'inner':inner,'bias':bias,'cross':cross,'points':points,'status':'PASS'})
    return {'K':K,'D':D,'legal_theta_interval_checked':['-1/2','1/2'],'cases':rows,'status':'PASS','scope':'Finite Markov likelihood perturbations, not physical cube kernels.'}


def quadrature_case(dps,label,priorq,wq,dq):
    mp.mp.dps=dps
    def val(x):return mp.mpf(x.numerator)/x.denominator
    def out(x):return mp.nstr(x,dps+5)
    prior=list(map(val,priorq));w=list(map(val,wq));v=[mp.mpf(0),val(dq)];e=sum(p*a for p,a in zip(prior,w))
    X=max(abs(a) for a in v)+(80 if dps==25 else 110);half=mp.mpf('.5')
    @lru_cache(maxsize=65536)
    def phi(r):
        r=abs(r)
        return 1-mp.expint(3,half-r)-mp.expint(3,half+r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
    @lru_cache(maxsize=65536)
    def point(x):
        radii=[x-a for a in v];density=[phi(r) for r in radii]
        score=[mp.sign(r)*(mp.expint(2,abs(r)+half)-mp.expint(2,abs(abs(r)-half)))/density[i] for i,r in enumerate(radii)]
        Q=sum(prior[i]*density[i] for i in range(2));Qw=sum(prior[i]*w[i]*density[i] for i in range(2))
        full=sum(prior[i]*density[i]*score[i] for i in range(2))/Q
        weighted=sum(prior[i]*w[i]*density[i]*score[i] for i in range(2))/Qw
        direct=sum(prior[i]*w[i]*density[i]*(score[i]-full)**2/e for i in range(2))
        inner=sum(prior[i]*w[i]*density[i]*(score[i]-weighted)**2/e for i in range(2))
        bias=Qw/e*(weighted-full)**2
        cross=sum(prior[i]*w[i]*density[i]*(score[i]-weighted)*(weighted-full)/e for i in range(2))
        assert abs(direct-inner-bias)<mp.mpf(10)**(-dps+5)
        return direct,inner,bias,cross,Qw/e
    seams=sorted(set([-X,X]+[a+b for a in v for b in (-half,mp.mpf(0),half)]+list(map(mp.mpf,(-32,-16,-8,-4,-2,-1,1,2,4,8,16,32)))))
    integrals=[mp.quad(lambda x:point(x)[index],seams) for index in range(5)]
    direct,inner,bias,cross,mass=integrals
    assert abs(direct-inner-bias)<mp.mpf('1e-16') and abs(cross)<mp.mpf('1e-16') and abs(mass-1)<mp.mpf('1e-16')
    tail_mass=2*mp.exp(half+max(abs(a) for a in v)-X)
    return {'dps':dps,'cutoff_X':out(X),'lhs_direct':out(direct),'inner':out(inner),'bias':out(bias),'cross':out(cross),'selected_mass':out(mass),
        'decomposition_residual':out(direct-inner-bias),'analytic_omitted_mass_upper':out(tail_mass),
        'analytic_each_square_tail_upper':out(256*tail_mass),'finite_seams':[out(x) for x in seams]}


def kernel_pair(radius,dps):
    with mp.workdps(dps):
        r=mp.mpf(float(radius));half=mp.mpf('.5')
        phi=1-mp.expint(3,half-r)-mp.expint(3,half+r) if r<=half else mp.expint(3,r-half)-mp.expint(3,r+half)
        der=mp.expint(2,r+half)-mp.expint(2,abs(r-half))
        assert phi>0
        return float(mp.log(phi)),float(der/phi)


def grid(maximum,ncore,nouter):
    x=np.unique(np.concatenate((.25*(1-np.cos(np.linspace(0,math.pi,ncore+1))),.5+(maximum-.5)*np.linspace(0,1,nouter+1)**2)))
    x[0]=0.;x[-1]=maximum
    pairs=np.array([kernel_pair(a,25) for a in x])
    return x,pairs[:,0],pairs[:,1]


def posterior(log_density,prior,w):
    full_terms=log_density+np.log(prior)[None,:]
    full_exp=np.exp(full_terms-np.max(full_terms,axis=1,keepdims=True));full=full_exp/np.sum(full_exp,axis=1,keepdims=True)
    logw=np.full(len(w),-np.inf);mask=w>0;logw[mask]=np.log(w[mask])
    selected_terms=full_terms+logw[None,:]
    selected_exp=np.exp(selected_terms-np.max(selected_terms,axis=1,keepdims=True));selected=selected_exp/np.sum(selected_exp,axis=1,keepdims=True)
    assert np.all(np.isfinite(full)) and np.all(np.isfinite(selected))
    assert np.max(np.abs(np.sum(full,axis=1)-1))<1e-12 and np.max(np.abs(np.sum(selected,axis=1)-1))<1e-12
    return full,selected


def overlap_bounds(q,A):
    # A scalar evaluation only; an empirical q is not a certified population q.
    assert 0<=q<=1
    if q==0:return {'q':q,'zero_q_branch':True,'CN10_first_moment':0.,'CN11_second_moment':0.}
    z=A+2*math.log(1/q)
    return {'q':q,'zero_q_branch':False,'CN10_first_moment':16*q*(z+2),
        'CN11_second_moment':256*q*(z*z+4*z+8)}


def quantities(x,v,prior,w,table,labels):
    nodes,logs,ells=table
    residual=x[:,None,:]-v[None,:,:];radius=np.abs(residual)
    logJ=np.sum(np.interp(radius,nodes,logs),axis=2)
    g=np.sign(residual)*np.interp(radius,nodes,ells)
    full,selected=posterior(logJ,prior,w)
    gf=np.sum(full[:,:,None]*g,axis=1);gw=np.sum(selected[:,:,None]*g,axis=1)
    delta=g-gw[:,None,:];shift=gw-gf
    conditional_inner=np.sum(selected*np.sum(delta*delta,axis=2),axis=1)
    conditional_lhs=np.sum(selected*np.sum((g-gf[:,None,:])**2,axis=2),axis=1)
    bias=np.sum(shift*shift,axis=1)
    conditional_cross=np.sum(selected*np.sum(delta*shift[:,None,:],axis=2),axis=1)
    actual=g[np.arange(len(x)),labels]
    sampled_inner=np.sum((actual-gw)**2,axis=1);sampled_lhs=np.sum((actual-gf)**2,axis=1)
    sampled_cross=np.sum((actual-gw)*shift,axis=1)
    assert np.max(np.abs(conditional_lhs-conditional_inner-bias))<1e-9
    assert np.max(np.abs(sampled_lhs-sampled_inner-bias-2*sampled_cross))<1e-9
    # New material diagnostic: y=0,b=1. Positive lost-posterior summation
    # avoids catastrophic subtraction for highly discriminated rare mixtures.
    lost=np.sum(full*(1-w)[None,:],axis=1)
    subtraction=1-np.sum(full*w[None,:],axis=1)
    assert np.all(lost>=0) and np.all(lost<=1+1e-14)
    qov=float(np.mean(lost));qov=min(1.,qov)
    material_bias=np.sum(x*shift,axis=1)
    R=float(np.max(np.sum(np.abs(v[w>0]),axis=1)))
    A=R+2*x.shape[1]*(math.log(2)+.25)
    e=float(np.sum(prior*w));mass_q=min(1.,(1-e)/e)
    empirical_bound=overlap_bounds(qov,A);mass_bound=overlap_bounds(mass_q,A)
    material={'y':'zero vector','b':1,'R_selected_support_l1':R,'A_tail_constant':A,
        'qov_empirical':qov,'lost_posterior_min':float(np.min(lost)),
        'lost_posterior_max':float(np.max(lost)),
        'lost_positive_sum_vs_subtraction_max_residual':float(np.max(np.abs(lost-subtraction))),
        'E_absolute_material_bias':float(np.mean(np.abs(material_bias))),
        'E_square_material_bias':float(np.mean(material_bias**2)),
        'empirical_qov_formula_diagnostic':empirical_bound,
        'mass_upper_q_formula_evaluation':mass_bound,
        'scope':'Empirical qov is a finite MC estimate, not a certified population overlap or a proof that CN10/11 hold.'}
    return {'material_overlap':material,'lhs':float(np.mean(sampled_lhs)),'inner':float(np.mean(sampled_inner)),'bias':float(np.mean(bias)),
        'cross':float(np.mean(sampled_cross)),'sampled_residual_lhs_minus_inner_minus_bias':float(np.mean(sampled_lhs-sampled_inner-bias)),
        'sampled_identity_residual_after_2cross':float(np.mean(sampled_lhs-sampled_inner-bias-2*sampled_cross)),
        'conditional_lhs':float(np.mean(conditional_lhs)),'conditional_inner':float(np.mean(conditional_inner)),
        'conditional_cross':float(np.mean(conditional_cross)),
        'maximum_conditional_decomposition_residual':float(np.max(np.abs(conditional_lhs-conditional_inner-bias)))}


def mc_cases():
    specs=[]
    for label,d,prior,w in [
        ('small_uniform',np.full(4,.25),[F(99,100),F(1,100)],[F(0),F(1)]),
        ('large_uniform',np.full(4,2.),[F(99,100),F(1,100)],[F(0),F(1)]),
        ('large_sparse_same_l2',np.array([4.,0,0,0]),[F(99,100),F(1,100)],[F(0),F(1)]),
        ('mixed_capture_uniform',np.ones(4),[F(3,4),F(1,4)],[F(1,10),F(1)])]:
        specs.append(('stress',label,d,prior,w))
    for n in (16,64):
        sparse=np.zeros(n);sparse[0]=math.sqrt(n)
        for label,d in [('uniform',np.ones(n)),('sparse_same_l2',sparse)]:
            specs.append(('expanded',label,d,[F(9999,10000),F(1,10000)],[F(0),F(1)]))
    samples=[];maximum=0.
    for index,(stage,label,d,priorq,wq) in enumerate(specs):
        n=len(d);prior=np.array(list(map(float,priorq)));w=np.array(list(map(float,wq)));eq=sum(p*a for p,a in zip(priorq,wq));e=float(eq)
        v=np.stack((np.zeros(n),d));seed=20261022+index;rng=np.random.Generator(np.random.PCG64(seed))
        labels=rng.choice(2,size=SAMPLES,p=prior*w/e)
        h=rng.uniform(-.5,.5,size=(SAMPLES,n));t=np.sqrt(rng.random(size=(SAMPLES,n)))
        x=v[labels]+h+rng.laplace(0.,t)
        maximum=max(maximum,float(np.max(np.abs(x[:,None,:]-v[None,:,:]))))
        samples.append((stage,label,v,priorq,wq,eq,x,labels,seed))
    coarse=grid(maximum,1024,2048);fine=grid(maximum,2048,4096)
    last=samples[-1];radii=np.abs(last[6][:,None,:]-last[2][None,:,:]).ravel()
    points=list(radii[np.linspace(0,len(radii)-1,128,dtype=int)])+[0.,.5,.5-1e-8,.5+1e-8,maximum]
    validations=[]
    for radius in points:
        reference=kernel_pair(radius,40)
        values=[]
        for table in (coarse,fine):values.append([float(np.interp(radius,table[0],table[1])),float(np.interp(radius,table[0],table[2]))])
        validations.append({'radius':float(radius),'reference_logphi':reference[0],'reference_ell':reference[1],
            'coarse_logphi_error':abs(values[0][0]-reference[0]),'coarse_ell_error':abs(values[0][1]-reference[1]),
            'fine_logphi_error':abs(values[1][0]-reference[0]),'fine_ell_error':abs(values[1][1]-reference[1])})
    rows=[]
    for stage,label,v,pq,wq,eq,x,labels,seed in samples:
        prior=np.array(list(map(float,pq)));w=np.array(list(map(float,wq)));q=quantities(x,v,prior,w,coarse,labels)
        selected=np.linspace(0,SAMPLES-1,256,dtype=int)
        small_coarse=quantities(x[selected],v,prior,w,coarse,labels[selected]);small_fine=quantities(x[selected],v,prior,w,fine,labels[selected])
        entropy=math.log(1/float(eq));q['bias_over_log_one_over_e']=q['bias']/entropy if entropy else None
        rows.append({'stage':stage,'label':label,'n':x.shape[1],'positions':v.tolist(),'prior':pq,'capture_weights':wq,'e':eq,
            'log_one_over_e':entropy,'displacement_l2':float(np.sqrt(np.sum(v[1]**2))),
            'seed':seed,'sample_count':SAMPLES,'sample_sha256':hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()+np.asarray(labels,dtype='<i8').tobytes()).hexdigest(),
            'measure':'selected joint: source pi_i w_i/e then X~J_i; full prior posterior is not substituted',
            'estimates':q,'expanded_grid_selected_count':len(selected),
            'expanded_grid_mean_changes':{key:abs(small_coarse[key]-small_fine[key]) for key in ('lhs','inner','bias','cross')},
            'deterministic_mass_upper_q_exact':min(F(1),(1-eq)/eq),
            'expanded_grid_material_mean_changes':{key:abs(small_coarse['material_overlap'][key]-small_fine['material_overlap'][key]) for key in ('qov_empirical','E_absolute_material_bias','E_square_material_bias')}})
    return {'cases':rows,'interpolation':{'maximum_actual_residual_radius':maximum,'coarse_core_intervals':1024,'coarse_outer_intervals':2048,
        'fine_core_intervals':2048,'fine_outer_intervals':4096,'grid_rule':'core .25(1-cos(theta)); exterior .5+(Rmax-.5)t^2',
        'grid_dps':25,'reference_dps':40,'validation_points':validations,
        'coarse_table_sha256':hashlib.sha256(b''.join(np.asarray(a,dtype='<f8').tobytes() for a in coarse)).hexdigest(),
        'maximum_validation_errors':{key:max(r[key] for r in validations) for key in ('coarse_logphi_error','coarse_ell_error','fine_logphi_error','fine_ell_error')}},
        'confidence_intervals':None,'statistical_certification':False,'status':'COMPLETED_FINITE_MC'}


def run(exact_only=False):
    exact=exact_checks()
    if exact_only:return {'schema':'r202_selected_mixture_exact_v1','exact':exact,'status':'PASS_EXACT_ONLY'}
    assert overlap_bounds(0.,0.)['CN10_first_moment']==0 and overlap_bounds(0.,0.)['CN11_second_moment']==0
    specs=[('equal_capture',[F(1,2),F(1,2)],[F(1),F(1)],F(1)),
        ('rare_selected',[F(99,100),F(1,100)],[F(0),F(1)],F(2)),
        ('mixed_capture',[F(3,4),F(1,4)],[F(1,10),F(1)],F(1,4))]
    quad=[]
    for label,p,w,d in specs:
        runs=[quadrature_case(dps,label,p,w,d) for dps in (25,40)]
        diffs={key:abs(mp.mpf(runs[0][key])-mp.mpf(runs[1][key])) for key in ('lhs_direct','inner','bias','cross')}
        assert all(a<mp.mpf('1e-16') for a in diffs.values())
        quad.append({'label':label,'prior':p,'capture_weights':w,'e':sum(a*b for a,b in zip(p,w)),'positions':[F(0),d],
            'runs':runs,'precision_differences':{key:mp.nstr(a,12) for key,a in diffs.items()}})
    return {'schema':'r202_selected_mixture_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'numpy_version':np.__version__,'mpmath_version':mp.__version__,
            'numpy_entry_sha256':hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),
            'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'identity':'E_selected ||g_i-g_full||^2 = E_selected ||g_i-g_w||^2 + E_Qw/e ||g_w-g_full||^2; centered cross expectation zero',
        'material_overlap_formula':{'direction':'X=x-y with y=0,b=1', 'bias':'X dot (g_w-g_full)', 'overlap':'E_selected_x sum_i posterior_full_i (1-w_i)', 'A':'R+2n(log(2)+1/4), R=max_{w_i>0} ||v_i||_1', 'scope':'Empirical overlap substitution is diagnostic, not a certified population parameter.'},
        'exact':exact,'one_dimensional_quadrature':quad,'monte_carlo':mc_cases(),'status':'COMPLETED',
        'limitations':['Exact finite Markov perturbations, noninterval physical scalar quadrature and finite MC are distinguished; no general proof inferred.',
            'The selected joint law uses fixed capture weights, not original Pi or actual alpha/history/FIRST/FULL.',
            'The bias is retained; neither small-e entropy comparisons nor finite n values certify a dimension bound.',
            'MC uses disclosed interpolation and no confidence interval/statistical certification; full and selected posteriors use logsumexp.',
            'Analytic tails bound truncation only; roots, finite quadrature, logdensity and score interpolation are not directed intervals.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'mixture_checks.json');ap.add_argument('--exact-only',action='store_true');args=ap.parse_args()
    start=time.monotonic();result=run(args.exact_only);args.output.write_text(json.dumps(enc(result),indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'seconds':round(time.monotonic()-start,3)},sort_keys=True))
