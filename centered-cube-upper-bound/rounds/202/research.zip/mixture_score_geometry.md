# R202：混合参考核的中心化 score 与真实加权来源

状态：辅助恒等式与有限费用检查点。本文证明自然 joint 下的 Fisher 收缩、材料 score 的来源矩依赖，以及使用原 wt·1Z 来源后与真实 ΠJ 完全一致的中心化分解。后者消除一个不必要的 ν(V)/e 放大，但改中心的 relative-Fisher bias 和原 target 系数仍必须支付。没有证明一般原 raw 根阶预算。

## MG1　历史窄查与不重复的已证工具

已按关键词窄查外部 R188–201 检查点的责任 Markdown（条件方差、混合 score、Fisher 收缩及相应后验记号），未找到本稿的混合归一化条件方差/加权来源分解。此结论仅指已查责任稿，不是全部历史文献检索。

R201 `signed_transport_budget.md` ST4–5 和 `proof.tex.txt` 已证明单一物理 Jv 的矩、奇偶正交和位移公式，本文引用而不重证：
\[
 J_v(x)=b^{-n}\prod_i\phi((x_i-v_i)/b),\quad
 I_{\rm loc}=\int(\phi'/\phi)^2\phi\le64,\quad
 V_{\rm sc}=\int(1+r\phi'/\phi)^2\phi\le9/4,
\]
\[
 \int J_v(x)[n+(x-y)\cdot\nabla\log J_v(x)]^2dx
 =nV_{\rm sc}+{I_{\rm loc}\over b^2}\|v-y\|_2^2. \tag{MG1}
\]
R188 `source_reversibility.md` SR2 的原 Π carrier 在 MG7 使用，绝不将其套到全 ν。R201 的有限输运 flow 在 MG9 使用，原 alpha/capture 的可微性不由本稿补出。

## MG2　任意有限来源的混合密度及其导数

令 ν 是任意有限正测度，M=ν(Rn)。若 M=0，所有 joint 量取零，不定义逆 Q。先取 M>0，
\[
 Q(x)=\int J_v(x)\nu(dv),\qquad
 \pi_x(dv)={J_v(x)\nu(dv)\over Q(x)},\qquad
 s_v(x)=\nabla\log J_v(x),\quad g(x)=\nabla\log Q(x). \tag{MG2}
\]
Jv 严格正且有统一有限上界，故 0<Q<∞。已证 logφ Lipschitz 常数 Lφ=2/(1−e^−1) 给 |s_v|∞≤Lφ/b；J 及一阶导数的公共可积包络允许对有限 ν 微分。因此 Q 为 C1，
\[
 \nabla Q=\int J_vs_v\nu(dv),\qquad
 g=\mathbb E_{\pi_x}s_v,\qquad |g|_\infty\le L_\phi/b,
 \qquad\int Qdx=M. \tag{MG3}
\]
这里没有假设 ν 有密度、梯度或来源矩。πx 仅是该恒等式的辅助条件律，绝不是原 Πy,t。

自然有限 joint 是
\[
 d\Lambda(x,v)=dx\,J_v(x)\nu(dv)=Q(x)dx\,\pi_x(dv),
 \qquad\Lambda(\text{全空间})=M. \tag{MG4}
\]
若要称概率，必须明确除以 M；不能无声地把自然质量预算当概率预算。

## MG3　translation Fisher 的精确矩阵收缩

固定 x 的条件方差分解给
\[
 \mathbb E_{\pi_x}[s_vs_v^\top]
 =g g^\top+\operatorname{Cov}_{\pi_x}(s_v).
\]
对自然 joint 积分，J 的乘积坐标及单坐标 location score 均值零给
\[
 \boxed{\int Q(x)\operatorname{Cov}_{\pi_x}(s_v)dx
 ={MI_{\rm loc}\over b^2}\operatorname{Id}_n
 -\int Q(x)g(x)g(x)^\top dx.} \tag{MG5}
\]
这些矩阵积分有限：首项由平移不变性等于 MI_loc/b² Id，第二项由条件 Jensen 被它支配，协方差为正半定。故没有 ∞−∞。

取迹得到
\[
 \int Q|\nabla\log Q|^2dx\le{MnI_{\rm loc}\over b^2},\qquad
 \int Q\mathbb E_{\pi_x}|s_v-g|^2dx
 ={MnI_{\rm loc}\over b^2}-\int Q|g|^2dx. \tag{MG6}
\]
固定方向 a∈Rn 的第一常数为 MI_loc||a||²/b²，而不是 MnI_loc||a||²/b²。对变化方向 a(x) 仍有逐点条件方差恒等式，但不能把该固定方向常数免费用于 x 适应的方向。

这是对任意有限 ν 成立的自然 joint 线性来源预算。仅凭它还不能支付原 βΠ²：该测度含 Jv dxν，而原 target 槽通常是 wt1Zν/e。

## MG4　材料 score：方向 x−y 与来源矩

固定 y，令 X=x−y，
\[
 S_{yv}(x)=n+X\cdot s_v(x),\quad
 S_{yQ}(x)=n+X\cdot g(x),\quad
 T_{yv}=S_{yv}-S_{yQ}=X\cdot(s_v-g). \tag{MG7}
\]
逐 x 有 EπT=0、Varπ S=EπT²。固定 y 的材料导数 Dy=∂r+X·∇x 中，J、Q 在固定 b、ν 后均不显含 r，因而
\[
 D_yQ=Q(S_{yQ}-n),\qquad
 D_y\log(J_v/Q)=T_{yv}. \tag{MG8}
\]
n 在这个 log ratio 中严格抵消，未把材料方向改成常方向。

当 ∫||v−y||²ν(dv)<∞，用 MG1、条件方差得到精确全空间式
\[
 \int Q\operatorname{Var}_{\pi_x}(S_{yv})dx
 =nV_{\rm sc}M+{I_{\rm loc}\over b^2}\int\|v-y\|^2\nu(dv)
 -\int Q S_{yQ}^2dx. \tag{MG9}
\]
若源二阶矩无限，只保留非负积分的条件 Jensen/上界（允许右侧∞），绝不作∞−∞。逐 x 的均值和方差仍有限，因为 s_v 对 v 统一有界而 x 固定。

在有界 receiver 集合 ||x−y||₂≤R0 上，还可由 MG6 得
∫Q Varπ(S)≤R0² MnI_loc/b²；这需保留实际 R0，不说明原接收域有该上界。尤其不能把原 Π carrier 偷换成全 π 或全 ν 的 support。

## MG5　固定原来源权的精确对接：不出现 ν(V)/e

固定原 (ω,V,j,y,t)，设
\[
 \eta(v)=1_{Z_t(y)}(v)w_t(y,v),\quad 0\le\eta\le1,
 \quad\nu_w=\eta\nu,\quad e=\nu_w(Rn),
\]
\[
 Q_w(x)=\int J_v(x)\nu_w(dv),\quad
 \pi_{w,x}(dv)={J_v(x)\nu_w(dv)\over Q_w(x)},\quad
 g_w=\nabla\log Q_w. \tag{MG10}
\]
e=0 的原行先取零，不使用原 Π 或 πw 的逆归一。e>0 时 Qw>0，原 Π=νw/e，精确有
\[
 \boxed{\Pi(dv)J_v(x)={Q_w(x)\over e}\pi_{w,x}(dv).} \tag{MG11}
\]
这是实际 target 槽权，不是另给 ν(V)/e 的估计。另有 Qw≤Q 和 πw=ηπ/(Qw/Q)。

记
\[
 S_{yQ_w}=n+X\cdot g_w,\quad
 T_w(v)=S_{yv}-S_{yQ_w},\quad
 B_w(x)=X\cdot(g_w-g)=D_y\log(Q_w/Q).
\]
则 Tfull=Tw+Bw，Eπw Tw=0，所以逐点精确分解为
\[
 \int\Pi(dv)J_v T_{yv}^2
 ={Q_w\over e}\left[\operatorname{Var}_{\pi_w}(S_{yv})+B_w^2\right]. \tag{MG12}
\]
此处正交仅在同一 πw 条件律下成立，未对原 Π 假设新的中心化。

积分后定义
\[
 E_w={1\over e}\int Q_w\operatorname{Var}_{\pi_w}(S_{yv})dx,
 \qquad R_w={1\over e}\int Q_w B_w^2dx,
\]
\[
 \boxed{\int dx\int\Pi(dv)J_v T_{yv}^2=E_w+R_w.} \tag{MG13}
\]
Rw 是改变 full-Q 中心到 weighted-Qw 中心的真实 material relative-Fisher 价；不能只保 Ew。

## MG6　任意 target 系数与原 alpha J 的准确系数

在每个固定 x（及另一来源 u）上，令 Cv 为任意可积 target 系数。α(x) 是原同一 alpha，full normalization Q=∫Jν，不能为 πw 重选它。MG11–12 给
\[
 \boxed{\int\Pi(dv)C_v\alpha J_vT_{yv}
 ={\alpha Q_w\over e}
 \left[\operatorname{Cov}_{\pi_w}(C_v,S_{yv})
 +B_w\mathbb E_{\pi_w}C_v\right].} \tag{MG14}
\]
有二阶矩时，第一项绝对值≤sqrt(Varπw Cv) sqrt(Varπw S)；第二项保留真实 mean。α、Qw/e 均可依 x，不能从 dx 提出。

若 Cv 包含原 ρ、a_v^{-1}、J/S 分母、截帽 F、H 或来源帽 B_v²，它们全部留在 Cv 中；不能把变来源的 B_v²当常数提出。另一 Πu 槽可以在上述条件代数后按原测度积分，但不删除其 bad/reciprocal/history 限制。MG14 只是正确的 centered-covariance 接口，不自行支付 Var Cv、bias 或实际 α 系数。

直接用 full π 的原 Radon–Nikodym 比为
\[
 {d\Pi\over d\pi_x}(v)={Q(x)\eta(v)\over eJ_v(x)}. \tag{MG15}
\]
两槽必须保两份；如果没有相应 Jv 因子，不能使用 MG11。MG14 的消比仅来自原 αJ 中确实存在的一份 J，并非任意把原 Π 改成辅助 π。

## MG7　真实 carrier 对 weighted 第一项的预算

R188 SR2 给原 η 的支持
\[
 D_y\subset\{v:\|v-y\|_1\le17na,\
 \|v-y\|_\infty\le bR_n\},\qquad R_n=5\log n+1/2.
\]
令
\[
 C_w={1\over eb^2}\int\|v-y\|_2^2\nu_w(dv)
 \le17n(a/b)R_n. \tag{MG16}
\]
这是 νw 的真实矩，不把 carrier 套到全 ν。对 νw 应用 MG9 或条件 Jensen，得到
\[
 \boxed{E_w\le nV_{\rm sc}+I_{\rm loc}C_w
 \le nV_{\rm sc}+17n(a/b)R_nI_{\rm loc}.} \tag{MG17}
\]
若不使用 carrier，则保实际 Cw；若 Cw=∞，只得到扩展值上界。

真实测度 dxΠJ 的总质量恰为1（∫Jv dx=1），所以其 Tw 一阶绝对积分还被 sqrt(Ew) 控制。原 β 再积分、j/time/window 求和仍需原预算；实际 Cv/α 的权重不由这一无权一槽费用支付。

## MG8　bias 的显式但昂贵的粗费用

本节给真实 carrier 下的有限价，不把 Rw 留作默认小的 gate。φ=h*w 的二阶矩精确为
\[
 \sigma_\phi^2={1\over12}+\int_0^1 2t\,(2t^2)dt={13\over12}. \tag{MG18}
\]
这里 w 是密度 2t 的 Laplace_t 混合，卷积的两个变量均值零。故在概率 Qw dx/e 下
\[
 {1\over e}\int Q_w\|x-y\|_2^2dx
 =b^2(13n/12+C_w). \tag{MG19}
\]
由 |gw−g|∞≤2Lφ/b，
\[
 |B_w|^2\le{4L_\phi^2\over b^2}\|x-y\|_1^2
 \le{4L_\phi^2 n\over b^2}\|x-y\|_2^2,
\]
\[
 \boxed{R_w\le4L_\phi^2n(13n/12+C_w).} \tag{MG20}
\]
因而 MG13 的真实无权 JΠ 槽平方费用有完全显式的上界
\[
 E_w+R_w\le nV_{\rm sc}+I_{\rm loc}C_w
 +4L_\phi^2n(13n/12+C_w). \tag{MG21}
\]
在原 carrier 下为 O(n²(1+log n))，未产生 ν(V)/e；这比把 full-ν 二阶矩直接用于原 Π 更合资格，但不是原 weighted root 价。第一矩最多为该式平方根。原 Cv、α 和两槽来源约束仍未付，不能把 MG21 移到含这些权重的积分而不保真实比值。

## MG9　不微分 capture 的有限 flow 对齐

固定 y，令 Φh^y(x)=y+e^h(x−y)，
\[
 R_v^h(x)={J_v(\Phi_h^yx)\over J_v(x)},\quad
 m_h=\mathbb E_{\pi_x}R_v^h={Q(\Phi_h^yx)\over Q(x)},\quad
 m_{w,h}=\mathbb E_{\pi_{w,x}}R_v^h={Q_w(\Phi_h^yx)\over Q_w(x)}.
\]
同一固定 ν、νw 下有精确 Bayes tilt
\[
 {d\pi_{\Phi_hx}\over d\pi_x}(v)={R_v^h\over m_h},\qquad
 {d\pi_{w,\Phi_hx}\over d\pi_{w,x}}(v)={R_v^h\over m_{w,h}}, \tag{MG22}
\]
\[
 \log{R_v^h\over m_h}
 =\log{R_v^h\over m_{w,h}}+\log{m_{w,h}\over m_h}. \tag{MG23}
\]
第一项对应 weighted 中心，第二项是不可免费删除的中心偏移。h→0 时各式回到 Tw、Bw；不需要 U 或 actual alpha 可微。

logJ 的物理 Lipschitz 界给
\[
 \epsilon_h(x)={L_\phi\over b}|e^h-1|\|x-y\|_1,
 \quad e^{-\epsilon_h}\le R_v^h,m_h,m_{w,h}\le e^{\epsilon_h},
\]
\[
 e^{-2\epsilon_h}\le d\pi_h/d\pi,\ d\pi_{w,h}/d\pi_w\le e^{2\epsilon_h}. \tag{MG24}
\]
因此各 posterior 的 total-mass TV 距离≤e^(2εh)−1，且各 centered log increment 绝对值≤2εh。保留 receiver 距离费用，没有无价 uniform h 模量。

令实际 capture 剩余标量 Hcap=αQ=Dq−∫Uν。在两侧共同合法且来源相同的 flow 状态，
\[
 \boxed{(\alpha J_v)_h-\alpha J_v
 ={J_v\over Q}\left[(H_{{\rm cap},h}-H_{\rm cap})
 +H_{{\rm cap},h}\left({R_v^h\over m_h}-1\right)\right].} \tag{MG25}
\]
这是保 full normalization 的原有限差分，α=0 时不除 α。Hcap 的实际失捕获、恢复、good 与其它资格仍在第一差分中；没有由 tilt 估计它。

若改变 t、y、ν、窗口或原支持权 η，则 MG22 的同一固定 prior 假设失效，必须另加真实来源权/measure 交换，零权新入口单独保留。若 actual L(x),s(x),R(x),j(x) 改变，仍按 R201 TI15 保留 selector clock 错配和资格；这些 flow 不自动给合法 FIRST 族或 BV。

## MG10　证据建议和最早未付接口

有限数值可核三个不同层次，但不得混称物理 FULL：一是任意有限 prior/score 阵列的条件 Gram 分解；二是 η 固定时 ΠJ=Qwπw/e、Cov+Bmean、两正平方；三是用实际 φ 的有限 source/receiver 点核验 flow tilt。单原子 prior 时 centered variance 必为0；weighted prior 只保一个原子而 full prior 另有原子时，Tw=0但 Bw 可非零，可检出免费改中心的错误。父级若安排实际数值，须分初探、压力、扩大及精度/证据范围；本稿不把建议说成已运行。

本稿新得到真实加权来源的中心化一槽费用 MG17、MG20，精确避免ν(V)/e，但总平方粗费仍为 O(n²log n)，且缺原 target 系数。自然 Fisher 收缩不能免费套原 Π²；全 ν 不自动有源矩，原 Π carrier 不自动约束 π；改变中心有 Rw，不得丢。最早剩余步骤是在 MG14 的同一 Cv、αQw/e 与原两槽/真实 dx 下支付 covariance 和 bias，并同时支付 MG25 的实际 capture 差分。没有从这些辅助费用推出原 raw 根阶，本稿到此停止，等待后续整合。
