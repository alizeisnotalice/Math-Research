# 第202轮：原捕获归一化的加权中心与来源重叠

一般n^(1/2+o(1))一致弱型目标未闭合。本轮基线80a4301，原α、ν、Π、真实dx、所有window/j/time和selector保持。

主要进展是从原ΠJ而非full自然后验出发：Π(dv)Jv=(Qw/e)πw(dv)，从而原full-center材料得分平方严格拆为weighted中心方差与relative-center偏差。第一项用原carrier估计，没有额外ν(V)/e放大。原系数Cv则保留条件协方差与偏差乘真实均值，不把Cv或来源帽Bv提出。

αJ的材料导数保留储备C的真实导数；只在C真正冻结时删去。有限flow保持full归一化与真实capture差，不假原good/history具有BV。自然平移Fisher、材料方向得分和原加权target费用分别列出，不能混用。

辅助稿给weighted材料方差的明确nlogn价及偏差的粗n²logn平方价。主稿已全文独审：令o=e⁻¹∫Qw(Q−Qw)/Q dx，A=17na/b+2n(log2+1/4)，材料偏差一阶≤16o[A+2log(1/o)+2]，平方≤256o[(A+2log(1/o))²+4(A+2log(1/o))+8]，o=0取零。该界不需full来源位置矩；o接近1时仍为线性/平方线性费用。原归一化项可利用2ρ·αJ/a≤1/2，但变来源帽、原target系数及完整β/j/time费用保留。仅有这些无权一槽估计不能支付原capture、双槽资格和自适应selector。

实际数值：3个Fraction有限likelihood扰动证书；3个物理一维25/40位积分；8个多维物理Monte Carlo案例。一维积分及原多维字段检translation score；随后在同8组MC样本上补算X_y材料偏差与实际来源重叠的经验估计，分开记录。稀有单来源选取例内部方差为零但偏差约3.08012，不能免费更换中心。多维同l2均匀/稀疏位移有不同偏差，保留likelihood重叠后再选择估计策略，不据有限结果猜阶。

主代理实际重跑初版mixture_checks.py并与保存JSON逐字节比较通过。最终增加材料诊断后的总复现，以归档README实际记录为准。NumPy2.3.5和mpmath1.3.0为本机已有工具；不使用导入失败的SciPy。代码明确记录插值、求积截尾和MC无置信认证；有限误差检查不构成一般证明。数值详细范围见numerical_review.md。

搜索定位的相对熵耗散论文因出版社429未读取全文，未导入外部定理；相关链接及迁移缺口记在parent_geometry_checkpoint.md。原φ乘积核不是已证明的共同热半群，来源删除也不是热流。

原时间熵的连续导数与并发删除Jensen–Shannon差已精确记录，尚未建立它们到材料Dirichlet费用的桥，不能套共同热流耗散。

最终详细LaTeX、审计及总driver分别记录在proof.tex.txt、audit.md和归档README；不编译PDF。仅在全轮核验后备份、精简归档并独立提交推送。没有逐模型实际扣额数据，不猜成本。

新增材料诊断保y=0,b=1，r_l采用正posterior求和，经验qov插入CN10/11仅是有限diagnostic，不认证真实重叠积分或一般阶数；另外保质量q上界的确定公式。仍使用原8组随机样本，无新sample和无置信区间。旧exact/quad/translation字段逐项不变。
