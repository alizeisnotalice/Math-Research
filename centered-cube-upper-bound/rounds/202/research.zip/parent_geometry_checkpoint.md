# R202 主代理：后验捕获概率的几何位置

此为正在推进的检查点，非一般上界闭合。上一轮R201已单独推送80a4301。

原捕获储备C=Dq与材料导数必须分开记号。alpha=(C-M_U)/Q，Q=∫J_vν，精确导数包含(J_v/Q)𝒟C，只有真正固定C的族才能删。alpha J_v的归一化项需要保同一个full Q，不能免费换后验中心。

本轮有用的真实测度接缝为：ν_w=1_Z w_tν，e=ν_w(V)，Q_w=∫J_vν_w，原Π=ν_w/e，故Π(dv)J_v(x)=(Q_w(x)/e)π_w,x(dv)。它避免直接从full自然测度回原Π时额外付ν(V)/e。材料得分的full中心与weighted中心之差仍要完整支付。其自然方差可用真实Π carrier，bias不能由中心化消失。

## 后验概率表达（代数接口，未付款）

令M=ν(V)>0，p=Q/M，e0=e/M∈(0,1]，r=Q_w/Q∈[0,1]。在固定权重、正平滑J的合法范围，weighted与full的translation score差为∇log r。故其平方费用

∫(Q_w/e)|∇log(Q_w/Q)|² dx = e0^(-1)∫p |∇r|²/r dx。

材料方向X=x-y相应为e0^(-1)∫p (X·∇r)²/r；translation费用不能直接称材料费用。r=0处使用实际零密度极限，或先有限正截断；本项目J>0且e>0时Q_w>0。

两个来源、w=(0,1)时r为logistic(log[e0/(1-e0)]+log(J1/J0))，translation bias=∫J1(1-r)²|∇log(J1/J0)|²。这个式子说明需要估计真实likelihood重叠区域；它只是精确位置，不是新增根阶预算。任意来源混合、原alpha权和selector不能用两来源模型代替。

## 数值方向与证据边界

数值Agent已实际运行初步3个Fraction离散score证书、3个一维物理25/40位积分和8个多维物理MC案例。最终结果及复现尚待其冻结。初步罕见来源e=1e-4的translation bias在n16均匀/稀疏同l2位移约14.5802/3.1161，在n64约.02050/1.54127；这改变下一步决策：仅看位移二范数不足，需保likelihood重叠/可辨识性。不据有限案例拟合维度阶数，不将translation诊断升级为材料界。

## 文献候选核验状态

搜索定位了2012论文“An Integral Representation of the Relative Entropy”（https://www.mdpi.com/1099-4300/14/8/1469）和2017论文“A Dissipation of Relative Entropy by Diffusion Flows”（https://www.mdpi.com/1099-4300/19/1/9/xml）。本次尝试打开均返回HTTP429，未读取全文，未引用其定理作为工具。仅作为后续候选记录。

共同Gaussian热流相对熵耗散是否能与原φ=h*w的坐标独立噪声混合、近零噪声参数及全部窗口对齐尚未证明。不能把原参考核J或删除权w_t直接改名为热半群，也不能假定来源有Poincare/LSI。此方向只是筛查中的新路线。

后续证据更新：原3exact/3quad/8MC已冻结并由父实际重放字节一致；随后同8MC新增材料bias与qov经验诊断，旧translation字段不变。该新增的经验q代入界不等于真实q积分证书，最终JSON与实际总driver记录见归档。此前“仅translation”描述对应初始检查点，新增范围在最终数值说明单列。
