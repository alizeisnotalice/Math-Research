# R202 selected-mixture score checks

The approved scope was executed in order: three exact finite likelihood perturbations, three one-dimensional physical quadrature cases at 25/40 digits, then eight finite Monte Carlo cases. The original physical tests use the translation score g_i=gradient_x log J_i (a scalar in quadrature, vector in MC); the exact finite certificate uses the likelihood-perturbation analogue D_i/K_i. The later MC-only extension below separately computes the relative-center material bias X dot (g_w-g_full), not the full original material derivative. No original Pi, alpha/history or FULL source construction is substituted by these auxiliary mixture laws.

## Exact initial certificate

Two strictly positive three-state Markov likelihood rows K_i sum to one. Derivative rows D_i sum to zero, and both endpoints K_i+theta D_i are positive normalized rows for theta=+-1/2. Their affine dependence therefore supplies a legitimate local likelihood perturbation with score D_i/K_i. Three rational prior/capture-weight pairs cover equal capture, rare selected mass e=1/100 with a zero weight, and mixed capture e=13/40.

Fraction sums verify the direct selected-joint identity, conditional decomposition and zero centered cross at every output state and after integration. The selected joint is pi_i w_i K_i/e. The full posterior uses pi_i K_i/Q; the selected posterior uses pi_i w_i K_i/Qw. They are deliberately different. In the rare case the conditional variance is zero but the bias equals the strictly positive total difference. These exact finite cases are not physical cube kernels.

## Physical one-dimensional initial checks

With b=1, J_i(x)=phi(x-v_i), the script computes the actual E3 density and E2 derivative. It independently integrates the direct source-weighted square, selected-centered square, bias, cross and selected mass. The three cases are equal weights at positions 0,1; rare selected e=.01 at positions 0,2; mixed capture e=13/40 at positions 0,1/4. Kernel and target seams are explicitly split, with cached physical values shared for efficiency but independent direct/decomposed expressions.

At 40 digits, equal capture has lhs=inner about 0.6198426850 and bias zero. Rare selection has lhs=bias about 3.0801176318 while inner is only numerical roundoff. Mixed capture gives lhs about 0.1844691475, inner 0.07389339038 and bias 0.1105757571. Thus ignoring bias fails in the actual scalar kernel model, not just the discrete auxiliary. The largest observed 25/40 difference is below 1.45e-26; cross and selected mass controls also pass.

Finite cutoffs are max|v_i|+80 or +110. The supplied |phi'/phi|<=8 implies squares of score differences <=256. The selected outside mass is at most 2exp(1/2+max|v_i|-X); multiplying by 256 controls each omitted squared quantity and the absolute cross. This is an analytic truncation bound, not a directed-rounding bound on finite quadrature. The high-precision calculations and decimal differences are not interval certificates.

## Pressure and expanded Monte Carlo

Four n=4 pressure cases compare small uniform shift, larger uniform shift and sparse shift with the same l2 norm, and a mixed-capture example. Four expanded cases use n=16,64, e=1/10000, and uniform versus sparse shifts with matching l2 norm. There are 20003 samples per case with explicit PCG64 seeds and sample/label hashes. Source labels are sampled from pi_i w_i/e, then X=v_i+phi noise. The phi sampler is verified by T=sqrt(U): density 2t times Laplace(t) integrates to w, followed by an independent uniform[-1/2,1/2] convolution. Capture weights are fixed in x.

Full and selected posteriors are computed separately with logsumexp; zero capture weights have log weight -infinity, and posterior normalization is checked. The implementation independently checks sample-label lhs-inner-bias=2cross, and the posterior-averaged conditional identity at every sampled x. It does not set sample-label cross to zero. In the mixed n=4 sample the cross mean is approximately -0.010624, a finite-sample fluctuation; its identity residual after subtracting 2cross is numerical roundoff.

Bias is substantial in some samples. With e=1e-4, n=16 uniform/sparse bias estimates are about 14.5802 and 3.1161; with n=64 they are about 0.02050 and 1.54127. The JSON records log(1/e) and bias/log(1/e) alongside n. These selected observations do not establish an entropy bound, an n order, or monotonic behavior and are not a fit. Conditional variance is zero when capture selects only one source, so the observed score discrepancy there is entirely the retained bias.

The physical log density and radial score use the parent-approved interpolation approach. Actual residual radii are scanned before building core Chebyshev and exterior quadratic tables. Doubled grids and independent 40-digit point evaluations test both logphi and ell. Maximum coarse validation errors are about 3.99e-6 for ell and 3.56e-7 for logphi; fine errors are about 1.05e-6 and 9.06e-8. Recomputing selected samples with the fine table changes reported means by at most about 1.71e-5. These are finite sensitivity diagnostics, not uniform interpolation/error certificates. MC has no confidence interval or statistical certification. Same-l2 configurations are finite geometry comparisons, not all-source claims.

## Reproduction

The script has ordinary NumPy/mpmath imports, no SciPy dependency and no embedded local runtime paths. Actual environment was NumPy 2.3.5, mpmath 1.3.0 and the existing bundled Python 3.12:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 mixture_checks.py --output mixture_checks.json
```

The optional --exact-only flag was run first with output in /tmp, confirming the rational interface before physical computation. Relocation needs the script and local task_contract.md; JSON records its portable filename hash plus dependency versions/entry hashes. Full execution took about eight seconds. A fresh isolated-directory replay repeated the complete physical/MC run and its JSON matched byte-for-byte. Timing and absolute execution paths are omitted from JSON. Only the three assigned files were written. No finite result here pays the original receiving-measure change, X_y material score, capture/eligibility dependence or general root budget.


## Narrow CN10/11 overlap and material extension

The parent authorized reuse of the same eight MC sample arrays, with y=0 and b=1, to measure the relative-center material bias Bmat=X dot (g_w-g_full). This is now a separate material_overlap field; it does not rename the old translation norm. The previous exact, one-dimensional quadrature, sample hashes, seeds and every old translation estimate/sensitivity field were compared to the frozen pre-extension JSON and remained identical. No new random sample or one-dimensional quadrature was added.

The lost posterior is computed as the positive sum r_l=sum_i posterior_full_i(1-w_i). The subtraction 1-sum_i posterior_full_i w_i is used only for a finite rounding-residual comparison, avoiding cancellation of tiny overlap. qov_empirical is its sample mean. The code records Eabs(Bmat), E(Bmat^2), the actual selected-support R=max_{w_i>0}||v_i||1, and A=R+2n(log(2)+1/4). Zero q is handled before taking a logarithm; a zero empirical estimate would still not certify zero population overlap.

For z=A+2log(1/q), the two scalar expressions are 16q(z+2) and 256q(z^2+4z+8). They are evaluated twice: once at empirical qov, explicitly labeled a diagnostic plug-in, and once at the deterministic source-mass upper q=min(1,(1-e)/e). The latter exact Fraction is also recorded; it equals one in all eight existing cases. The code does not assert that plugging an empirical overlap into these formulas proves a population bound. There is no confidence interval or other statistical certification.

The n=64,e=1e-4 uniform/sparse cases illustrate the decision information. Their empirical qov values are about 0.00018266 and 0.526315; material absolute means about 0.006895 and 6.41049; square means about 0.139521 and 73.9064. The corresponding empirical-q CN10 expressions are about 0.5960 and 1111.63, versus deterministic mass-q expressions 2987.57 and 2091.57. This displays the potential importance of actual likelihood overlap. It does not establish the smallest empirical overlap as a true upper bound; rare-tail sampling uncertainty is unquantified, and no uniform geometry claim follows.

The existing expanded-table sample subset also checks the new fields: maximum coarse/fine changes are below 9.54e-8 for qov, 1.90e-6 for material absolute mean and 3.24e-5 for material square mean. These finite interpolation sensitivity checks remain nonuniform/noninterval. The complete extended JSON was regenerated and isolated-directory replayed with byte equality. The script and dependency command above are unchanged; only the authorized three files were edited. Independent static review passed the added formulas and scope. Original target coefficients, the full alpha derivative and all capture/qualification/selector fees remain outside this finite diagnostic.
