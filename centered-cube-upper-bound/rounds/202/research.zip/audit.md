# R202 independent audit

## 1. Premise screen before author manuscripts

Read `task_contract.md` before reading new author proofs. The following are independent checks of the proposed identities and their measures, not certification of the original global budget. Only this file is owned by the auditor; no numerical execution, Git operation or delegation was performed.

Use \(\mathcal D=\partial_{\log L}+(x-y)\cdot\nabla_x\), and distinguish it from the original reserve coefficient \(D\). Put \(C=Dq\), \(Q=\int J_z\,d\nu\), \(M=\int U_z\,d\nu\), so \(\alpha Q=C-M\). On a legal regular branch with \(Q>0\), exact quotient differentiation gives
\[
\mathcal D(\alpha J_v)
=-\frac{J_v}{Q}\mathcal DM
+\alpha J_v(\mathcal D\log J_v-\mathcal D\log Q)
+\frac{J_v}{Q}\mathcal DC.
\]
The last term vanishes only for the frozen family in which the whole quantity Dq is constant. A fixed numerical q alone does not imply a fixed D. Neither the quotient identity nor centering proves that actual capture U, good/history or selector families have BV. Differentiating M under the source integral requires its own actual derivative/trace and integrability justification; otherwise retain finite differences.

For fixed window b and fixed finite nonzero positive nu, J_z=P_{1,b}(x-z)>0 and Q>0 at every finite x. The physical positive C1 kernel and bound |grad J_z|<=const J_z justify differentiation under finite nu. Hence
\[
\pi_x(dz)=J_z(x)\nu(dz)/Q(x),\qquad
\nabla\log Q=\mathbb E_{\pi_x}\nabla\log J_z.
\]
Q is independent of running L in this fixed-window family. A varying b or receiver-dependent source measure has additional terms. A zero-nu row is removed before any normalization; Q tending to zero at infinity does not supply a uniform lower bound.

## 2. Exact measure conversions

At fixed original omega,V,j,y,t, write e=integral(1_Z w_t dnu)>0 and retain the original posterior Pi. The reference posterior pi is over the full nu, rather than only the carrier Z. Its exact density conversion is
\[
\frac{d\Pi_{y,t}}{d\pi_x}(z)
=\frac{Q(x)\mathbf1_{Z_t(y)}(z)w_t(y,z)}{e_t(y)J_z(x)}.
\]
The two original slots require both factors. In particular, relative to the natural joint measure Q dx pi(du)pi(dv), the original dx Pi(du)Pi(dv) has ratio
\[
\frac{Q\,\mathbf1_Z(u)\mathbf1_Z(v)w_t(y,u)w_t(y,v)}{e_t(y)^2J_uJ_v}.
\]
For a single slot relative to Q dx pi(dv), its ratio is 1_Z(v)w_t(y,v)/(e_t J_v). All of these remain multiplied by the true outer beta and other original weights. Full pi cannot be reversed globally to Pi outside Z. Conditioning pi to Z changes Q and the centered score; it is not the same alpha normalization.

A variance estimate under pi may be used in a true original-slot Cauchy estimate only with the corresponding RN/test-weight square, or with a proved compensating domination. This is a concrete possible interface, not a supplied bound for that cost. Source weights, inverse J and e, occupation, and alpha coefficients must be combined before asserting any cancellation.

## 3. Translation versus material scores

Let T_z=grad log J_z, with location Fisher I_loc=integral(phi'^2/phi). Under the natural measure Q dx pi(dz)=J_z dx nu(dz), total conditional variance gives the exact finite-mass identity
\[
\int Q\,\mathbb E_\pi|T_z-\nabla\log Q|^2dx
=\frac{n I_{\rm loc}}{b^2}\|\nu\|
-\int Q|\nabla\log Q|^2dx.
\]
No source second moment or source gradient is required here. For a fixed vector h, the corresponding first term is I_loc |h|^2 ||nu||/b^2. These are translation Fisher identities.

The proposed material score instead uses the receiver-dependent vector X_y=x-y. Conditional centering removes any common scalar n, so use S_z=n+X_y dot T_z. The physical product calculation and even/odd orthogonality yield the sufficient natural-joint estimate
\[
\int Q\,\operatorname{Var}_{\pi_x}(S_z)dx
\le nV_{\rm scale}\|\nu\|
+\frac{I_{\rm loc}}{b^2}\int|z-y|^2\nu(dz).
\]
Here V_scale=integral phi(1+r phi'/phi)^2<9/4, while I_loc<=64; these moments are distinct. The displayed upper bound is finite when the stated source second moment is finite. It does not claim that infinite source moment forces infinite conditional variance. Actual bounded source supports may furnish a finite diameter price, which must be retained. The original Pi carrier bounds cannot be applied to full nu for free.

Even pointwise score centering does not supply independence across source coordinates. The reference J product structure is only a receiver integration fact. A bounded translation score gives a crude finite pointwise conditional variance, but after multiplication by X_y its geometry and receiver integral still need payment. No natural-joint square-root estimate alone proves an original beta Pi^2 square-root source budget, and the old order-n energy Cauchy conversion remains unchanged.

## 4. Precise weighted-mixture candidates screened before full proofs

Let nu_w=1_Z w_t nu, e=||nu_w||>0, Q_w=J*nu_w and pi_w=J nu_w/Q_w. The useful identity retaining the original posterior is
\[
J_v\Pi(dv)=\frac{Q_w(x)}e\pi_{w,x}(dv).
\]
It does not replace Pi by pi_w. Set S_v=n+X_y dot grad log J_v, T_w=S_v-E_pi_w S_v and B_rel=X_y dot grad log(Q_w/Q). Then S_v-E_pi S_v=T_w+B_rel, with conditional cross term zero. Consequently
\[
\int dx\int\Pi(dv)J_v(S_v-\mathbb E_\pi S_v)^2
=\frac1e\int Q_w\operatorname{Var}_{\pi_w}(S_v)dx
+\frac1e\int Q_w B_{\rm rel}^2dx.
\]
This nonnegative decomposition also holds with infinite values. The first term is bounded by n V_scale+I_loc integral(|v-y|^2 dPi)/b^2, so the original carrier legitimately applies there. The second term is the material relative Fisher price; it cannot be dropped by changing centers. Its ratio is Q_w/Q=E_pi[1_Z w_t]; for the probability mixture Q_Pi=Q_w/e, the extra constant 1/e has zero receiver derivative.

For an integrable actual target coefficient C_v, the pointwise identity is
\[
\int\Pi(dv)C_v\alpha J_v(S_v-\mathbb E_\pi S_v)
=\frac{\alpha Q_w}e\left[\operatorname{Cov}_{\pi_w}(C_v,S_v)
+B_{\rm rel}\mathbb E_{\pi_w}C_v\right].
\]
Actual alpha(x) is not moved outside the receiver integral. Varying target caps remain inside this covariance/test weight, unless a genuine uniform cap is paid.

On the active original rho branch, 2 rho alpha J/a<=1/2 follows from rho+alpha J/a<=1. Therefore, if a finite B_star is uniform in receiver and target, the local-centered part of the original normalization term is bounded by
\[
\frac{B_\star^2}{2}\sqrt{nV_{\rm scale}+I_{\rm loc}\int |(v-y)/b|^2\Pi(dv)}.
\]
Here z_v^2<=1 and F<=B_star^2 J are positive enlargements; the original Pi J measure is retained before using the mixture identity. A nonuniform cap cannot be extracted for free. The relative-center term, actual capture derivative and all other source/window/selector costs remain.

For a finite receiver flow with fixed source, R_v=J_v(flowed x)/J_v(x)>0 gives the exact tilt pi_new=(R_v/E_pi R)pi. Its centered log increment is log R_v-log E_pi R. The weighted-mixture center differs by log(E_pi_w R/E_pi R). This is an algebraic finite-exchange identity, not an assertion of original qualification BV or a bound for the flow error.

The proposed explicit coarse relative-center bound also passes. Physical phi has variance 13/12; write C_w=integral(|v-y|^2 dPi)/b^2. Since both mixture translation gradients have componentwise magnitude <=L_phi/b,
\[
\frac1e\int Q_w B_{\rm rel}^2dx
\le4L_\phi^2 n(13n/12+C_w).
\]
This follows by integrating |X_y|^2 under Q_w/e and is an explicit single-slot J Pi price with no nu-mass/e penalty. Under the original carrier it is a coarse order n^2 log n square price, not a root-order original weighted estimate. Receiver/source dependent coefficients must still remain in their actual weights. For a finite flow, |log(J_v(flow x)/J_v(x))|<=epsilon=L_phi |e^h-1| |x-y|_1/b gives posterior tilt ratios in [exp(-2epsilon),exp(2epsilon)]; the distance and selector costs persist.

## 5. Numerical static checkpoint

Read complete `mixture_checks.py`, without running it. The three exact Markov perturbations preserve row mass, and the positive perturbation endpoints are checked. Their full/selected likelihood-score decomposition retains the bias. The three physical scalar cases independently integrate direct, centered, bias, cross and selected mass at two precisions, with the correct score sign and analytic tail bounds. The eight Monte Carlo cases sample the selected source label, compute separate full/selected posteriors by log-sum-exp, and distinguish sample-label cross residual from the pointwise conditional identity. Numerical interpolation and the lack of confidence intervals are explicit. These are translation-score diagnostics, not material-score or original history/FIRST/FULL certificates. The final `numerical_review.md` was reread and explicitly distinguishes the physical translation score and finite likelihood perturbation from the material score; the requested evidence-label clarification is complete.

Later reread the narrowly added `overlap_bounds` and MC material-overlap code. It uses the same eight existing samples, with y=0,b=1, and correctly computes lost posterior mass by the positive sum of full-posterior weights times (1-w), rather than relying on cancellation in 1-selected acceptance. The material bias is x dot (g_w-g), and the tail constant uses the actual finite selected-source l1 support. CN10/11 are evaluated at both empirical overlap and the exact mass upper bound; empirical overlap is explicitly not a certified population bound. The zero-overlap branch and doubled-grid material sensitivity are retained. This adds a finite material diagnostic to the earlier translation evidence, without additional cases or a general proof. Reread the final notes' first paragraph and material-extension section (`e8f76186f039d5aa10c1f193accbd407101c40a88f8a3d9f547a5a87e79ed0b1`): the two evidence scopes and unquantified rare-tail sampling uncertainty are accurately distinguished. No necessary revision remains.

## 6. Full author review

Read the complete 245-line `mixture_score_geometry.md` after the premise screen, version `4ac9d07cd96d7635f6bbe28ec686734ce531990495d622098628a38a933747be`. MG1–25 pass within the stated scope. The natural covariance matrix, material finite-moment/extended-value distinction, exact original J Pi conversion, conditional covariance plus bias, carrier use only for weighted nu, explicit coarse bias price, finite Bayes tilt and alpha-J difference agree with the independent checks. The finite-difference formula does not divide by alpha, and fixed-prior/support/selector changes are explicitly retained. No necessary revision was found. This review does not certify the author's historical-search completeness or an original weighted root-order payment.

The later selected/lost-overlap bias candidate also passes the independent screen. Set Q_l=J*((1-eta)nu), r_l=Q_l/(Q_w+Q_l), and q_ov=integral(Q_w r_l dx)/e. Then q_ov<=min(1,(||nu||-e)/e) and |B_rel|<=16 |X_y|_1 r_l/b. The original carrier and physical exponential moment give, for Z=|X_y|_1/b and A=17na/b+2n(log 2+1/4), P(Z>=A+2t)<=exp(-t) under Q_w/e. Fractional-weight layer cake yields
\[
\mathbb E|B_{\rm rel}|\le16q_{\rm ov}[A+2\log(1/q_{\rm ov})+2],
\]
\[
\mathbb EB_{\rm rel}^2\le256q_{\rm ov}[(A+2\log(1/q_{\rm ov}))^2+4(A+2\log(1/q_{\rm ov}))+8].
\]
The square uses r_l^2<=r_l. Zero overlap is handled first by zero bias; the continuous limits are zero. Replacing q_ov by its mass upper bound is valid since the two functions have respective derivatives A+2log(1/q) and its square. These are explicit unweighted selected-J-mixture costs, not removal of actual target coefficients or original source/selector costs.

Read the complete `capture_normalization_budget.md` CN1–18 after the candidate screens. No necessary revision was found. The original alpha-J derivative and coefficient, real selected/lost overlap, moment bounds and uniform-cap-only source return agree with the independent calculations. CN14 retains complete time/window and variable target costs; the fixed-endpoint mass comparison does not use a receiver-dependent terminal time, and a dead endpoint uses q=1. Initial carrier-outside source is not relabeled as new deletion. For CN16, on a compact positive-e interval the score bound implies |p_t'|<=n p_t; the likelihood upper bound m/e and the integrable negative entropy part justify the logarithm truncation limit. Threshold points are understood through the a.e. derivative. The deletion JS identity handles zero deletion and dead rows separately. It supplies no sign or material-Fisher dissipation. CN18 agrees with the parent's posterior-probability Dirichlet identity.

Read the report, `parent_geometry_checkpoint.md`, and reproducer at this stage. The posterior-probability and two-source logistic formulas are algebraically correct and are explicitly interfaces rather than payments. Unread external entropy papers are recorded as unverified candidates, not proof dependencies; this audit does not certify them. The driver verifies the future manifest then uses the actual single-script output interface and complete JSON byte comparison. No final manifest-bound replay is prematurely certified here.

## 7. Final integration and freeze

Read all 747 lines of `proof.tex.txt` and the final report/checkpoint/reproducer. MG1–25 and CN1–18 are transcribed consistently, including the exact RN ratios, natural versus actual measures, finite/extended source moments, retained relative-center bias, derivative of the full Dq, uniform-cap restriction, complete outer/time prices, and fixed-time/zero-row qualifications. The entropy derivative is an a.e. continuous-time formula with justified truncation; the deletion identity handles d=0 and d=1 separately. It is not material Fisher dissipation. The final numerical extension and its empirical-overlap limitation are accurately recorded. No necessary mathematical or transcription revision remains.

Read final JSON metadata: three exact cases, three two-precision physical quadrature cases, and eight MC cases, with the material diagnostic reusing those samples. Parent/author execution and byte-replay statements are their recorded evidence; this auditor statically reviewed the code and did not run experiments or compile TeX. The future manifest-bound total driver has not been prematurely certified.

Accepted scope: exact alpha-J normalization and weighted-mixture interfaces; natural Fisher identities; actual J Pi centered variance with explicit carrier costs; overlap-dependent unweighted material-bias bounds and the stated uniform-cap normalization component; exact finite flow and time-entropy accounts. The main unresolved step remains a compensated original-measure estimate with actual target coefficients, capture/qualification derivatives and selector exchanges. At overlap near one the first-moment price remains order n; no general original raw root-order payment is certified. All assigned review work is complete. This audit is frozen after the following binding, excluding itself and any future manifest.

## 8. Final SHA-256 binding

| File | SHA-256 |
|---|---|
| capture_normalization_budget.md | `c256c66ec0ee856043cc5239aadfbf6c32dc6289bcfb9ddb1c43796fa5bc9c69` |
| mixture_checks.json | `e53394b3d859de1df0c2f0e56c42cd7671e1366484b7430b54d91a590c17bc49` |
| mixture_checks.py | `df169577f2acca2e9270e58851a3df3a1c9f934cea40794afc97745ed639e350` |
| mixture_score_geometry.md | `4ac9d07cd96d7635f6bbe28ec686734ce531990495d622098628a38a933747be` |
| numerical_review.md | `e8f76186f039d5aa10c1f193accbd407101c40a88f8a3d9f547a5a87e79ed0b1` |
| parent_geometry_checkpoint.md | `406e850202f3d91020fb4bee4faab771f365c79109a0b1b61f57a5a4dc3de2c7` |
| proof.tex.txt | `81d74356d49e98edaca7e502d04e09c9d5b11bed95aa3c09c18294108a2f8566` |
| report.md | `ba4eddb89edc4be6580169c6ddf00ff5777ee7d622e7529713aff3a81d2b4b86` |
| reproduce.py | `73a75ec92fb12fc3ec83469a81d4d4d41a0b91874f5107f216b0a1017b56f48c` |
| task_contract.md | `af7a2d15c29204380affea4dfaa174b655c3a361dc3247aa48f2326ebfffc063` |
