#!/usr/bin/env python3
"""Verify hashes and replay finite evidence; not a mathematical proof checker."""
import argparse,hashlib,json,subprocess,sys,os
from pathlib import Path
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);p.add_argument('--numeric-python',default=sys.executable);a=p.parse_args()
m=json.loads((root/'manifest.json').read_text())
for name,digest in m.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(m),'file hashes',flush=True)
if not a.verify_only:
 if a.output_dir is None:p.error('--output-dir required')
 a.output_dir.mkdir(parents=True,exist_ok=True);out=a.output_dir/'mixture_checks.json'
 if out.exists():p.error('Use fresh output path')
 subprocess.run([a.numeric_python,str(root/'mixture_checks.py'),'--output',str(out)],check=True,env=os.environ.copy())
 assert out.read_bytes()==(root/'mixture_checks.json').read_bytes(),'JSON differs; inspect environment and numerical results'
 print('Complete mixture JSON byte-identical',flush=True)
