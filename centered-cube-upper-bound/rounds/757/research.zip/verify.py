"""R757 finite-price exchange, descending redraw and small-vertex coloring."""

import argparse
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
from platform import python_version


@dataclass(frozen=True)
class Price:
    mass: Q
    present: tuple
    anchors: tuple = ()
    edge: tuple = ()
    extra: tuple = ()


def input_case(receiver_count, star):
    receivers = tuple(range(3,3+receiver_count))
    high = (receivers[-1]+1,receivers[-1]+2)
    labels = range(high[-1]+1)
    volumes = tuple(Q(j+1) for j in labels)
    v = tuple(Q(1+(3*j)%5,128) for j in labels)
    positive_weights = {0: Q(1,6),1: Q(1,4),2: Q(1,5),high[0]: Q(1,4),high[1]: Q(1,3)}
    lam = tuple(positive_weights.get(j,Q(0)) for j in labels)
    anchors = ((0,1),(0,2),high)
    masks = ((Q(1),Q(1,4)),(Q(0),Q(2,3)),(Q(3,5),Q(1,2)))
    prices = []
    for t in range(receiver_count-1):
        small = receivers[0 if star else t]
        edge = (small,receivers[t+1])
        pair = anchors[t%3]
        prices.append(Price(Q(receiver_count+6+2*t),tuple(sorted(edge+pair)),pair,edge,masks[t%3]))
    # The first extra price has W>0 but F=0, and the second has W=F=0.
    prices += [Price(Q(5,2),receivers[:2]),Price(Q(1,3),())]
    return volumes,v,lam,prices,receivers


def block(i,k,j,l):
    if max(i,k) < min(j,l):
        return 0,tuple(sorted((i,k)))
    if max(j,l) < min(i,k):
        return 1,tuple(sorted((j,l)))
    return None


def extra(price,i,k,j,l):
    if (tuple(sorted((i,k))) != price.anchors or tuple(sorted((j,l))) != price.edge):
        return Q(0)
    return price.extra[0 if j>l else 1]/(1 if i<k else 2)


def colorings(size,k):
    """Enumerate every coloring up to a permutation of colors."""
    def visit(prefix,used):
        if len(prefix) == size:
            yield prefix
            return
        for color in range(min(used+1,k)):
            yield from visit(prefix+(color,),max(used,color+1))
    return visit((),0)


def coloring_audit(sides,distinct,screened):
    vertices = sorted(set(x for side in sides for edge in side for x in edge))
    index = {x:i for i,x in enumerate(vertices)}
    groups = (*sides,distinct,screened)
    totals = [sum(group.values()) for group in groups]
    assert all(totals)
    rows = []
    for k in (1,2,3,4):
        maxima = [Q(0)]*len(groups)
        count = 0
        for colors in colorings(len(vertices),k):
            count += 1
            for a,group in enumerate(groups):
                cross = sum(mass for (i,j),mass in group.items()
                            if colors[index[i]] != colors[index[j]])
                maxima[a] = max(maxima[a],cross/totals[a])
        # Checking the two scale orders separately also certifies their sum.
        assert all(value <= 1-Q(1,k) for value in maxima[:2])
        if k >= 2:
            assert maxima[2] == maxima[3] == 1
        rows.append({"k":k,"colorings_up_to_color_names":count,
                     "max_cross_fractions":list(map(str,maxima)),"raw_bound":str(1-Q(1,k))})
    return {"small_vertices":vertices,"weights":list(map(str,totals)),
            "columns":["raw_sources_small","raw_receivers_small","four_distinct","extra_screened"],
            "colorings":rows}


def path_audit(v,down,unswapped,redraw,receivers,star):
    labels = range(len(v))
    unit = [Q(1)]*len(v)
    vector = unit.copy()
    original_vector = unit.copy()
    histories = {((j,),()):v[j] for j in labels}
    all_lengths = []
    for length in range(len(receivers)+1):
        matrix_mass = sum(v[j]*vector[j] for j in labels)
        enumerated = sum(histories.values())
        assert matrix_mass == enumerated
        frozen = sum(weight for (_,prices),weight in histories.items() if len(set(prices)) <= 1)
        row = {"length":length,"Q_k":str(matrix_mass),"independent_fresh_redraw":str(enumerated),
               "same_price_submass":str(frozen),
               "without_slot_exchange":str(sum(v[j]*original_vector[j] for j in labels))}
        if length >= 2:
            assert frozen == 0
        if length == len(receivers)-1 and not star:
            assert len(histories) == 1 and matrix_mass > 0
            ((path,prices),weight), = histories.items()
            assert path == receivers[::-1] and weight == matrix_mass
            row["unique_path_labels"] = list(path)
            row["unique_path_prices"] = list(prices)
            assert row["without_slot_exchange"] == "0"
        all_lengths.append(row)
        vector = [sum(down[j][l]*vector[l] for l in labels) for j in labels]
        original_vector = [sum(unswapped[j][l]*original_vector[l] for l in labels) for j in labels]
        next_histories = defaultdict(Q)
        for (path,prices),weight in histories.items():
            for (l,z),p in redraw[path[-1]].items():
                if l < path[-1] and p > 0:
                    next_histories[(path+(l,),prices+(z,))] += weight*p
        histories = dict(next_histories)
    assert all_lengths[1]["Q_k"] != "0"
    if star:
        assert all(row["Q_k"] == "0" for row in all_lengths[2:])
    else:
        assert all(row["Q_k"] != "0" for row in all_lengths[:-1])
        assert all_lengths[-1]["Q_k"] == "0"
    return all_lengths


def evaluate(receiver_count,star=False):
    volumes,v,lam,prices,receivers = input_case(receiver_count,star)
    labels = range(len(v))
    assert all(volumes[j] < volumes[j+1] for j in range(len(v)-1))
    m = tuple(sum(P.mass for P in prices if j in P.present) for j in labels)
    assert all(m[j]>=volumes[j] and 0<v[j]<=volumes[j]/32 for j in labels)
    raw = [[Q(0) for _ in labels] for _ in labels]
    redraw = [defaultdict(Q) for _ in labels]
    sides = (defaultdict(Q),defaultdict(Q))
    distinct,screened = defaultdict(Q),defaultdict(Q)
    base_mass = Q(0)
    price_rows = []
    for z,P in enumerate(prices):
        f = {j:lam[j] for j in P.present if lam[j]>0}
        g = {j:v[j]/m[j] for j in P.present}
        F,W = sum(f.values(),Q(0)),sum(g.values(),Q(0))
        assert F <= 1
        price_rows.append({"z":z,"mu":str(P.mass),"present":P.present,"anchor_pair":P.anchors,
                           "receiver_edge":P.edge,"screen_descending_ascending":list(map(str,P.extra)),
                           "F":str(F),"W":str(W)})
        if not F or not W:
            continue

        base_mass += P.mass*F*W
        edge_marginals = [defaultdict(Q) for _ in range(4)]
        for i,k,j,l in product(f,f,g,g):
            mass = P.mass*F*W*(f[i]/F)*(f[k]/F)*(g[j]/W)*(g[l]/W)
            for edge_ledger,edge in zip(edge_marginals,((i,j),(i,l),(k,j),(k,l))):
                edge_ledger[edge] += mass
            small = block(i,k,j,l)
            if small is None:
                continue
            side,pair = small
            sides[side][pair] += mass
            if len({i,k,j,l}) == 4:
                distinct[pair] += mass
            kept = mass*extra(P,i,k,j,l)
            raw[j][l] += kept
            screened[pair] += kept
        expected = {(i,j):P.mass*f[i]*g[j] for i,j in product(f,g)}
        assert all(ledger == expected for ledger in edge_marginals)

        # Start from just a receiver j. Draw price from its own incidence-mass
        # law, accept with F, draw both sources and the other receiver, then
        # fairly exchange the receiver slots in the extra screen.
        for j in g:
            price_prob = P.mass/m[j]
            for i,k,l in product(f,f,g):
                if block(i,k,j,l) is None:
                    continue
                proposal = price_prob*F*(f[i]/F)*(f[k]/F)*(g[l]/W)
                for first,second in ((j,l),(l,j)):
                    weight = proposal*extra(P,i,k,first,second)/2
                    if weight:
                        redraw[j][l,z] += weight

    C = [[(raw[j][l]+raw[l][j])/(2*v[j]) for l in labels] for j in labels]
    assert all(C[j][j] == 0 and sum(C[j]) <= 1 for j in labels)
    assert all(v[j]*C[j][l] == v[l]*C[l][j] for j,l in product(labels,labels))
    assert all(sum(p for (end,_),p in redraw[j].items() if end==l) == C[j][l]
               for j,l in product(labels,labels))
    assert any(raw[j][l] != raw[l][j] for j,l in product(labels,labels))
    assert sum(v[j]*sum(C[j]) for j in labels) == sum(map(sum,raw))
    down = [[C[j][l] if l<j else Q(0) for l in labels] for j in labels]
    unswapped = [[raw[j][l]/v[j] if l<j else Q(0) for l in labels] for j in labels]
    paths = path_audit(v,down,unswapped,redraw,receivers,star)
    assert Q(paths[1]["Q_k"]) == sum(map(sum,raw))/2
    return {
        "receiver_count":receiver_count,"star":star,
        "d":list(map(str,volumes)),"m":list(map(str,m)),"pi_equals_v":list(map(str,v)),
        "lambda":list(map(str,lam)),"price_rows":price_rows,"base_mass":str(base_mass),
        "pre_exchange_edge_mass": [[j,l,str(raw[j][l])] for j,l in product(labels,labels) if raw[j][l]],
        "exchange_C": [[j,l,str(C[j][l])] for j,l in product(labels,labels) if C[j][l]],
        "fresh_steps_with_price": [[j,l,z,str(p)] for j in labels for (l,z),p in redraw[j].items()],
        "coloring":coloring_audit(sides,distinct,screened),"paths":paths,
    }


def report():
    return {
        "scope":"Finite incidence models with fixed price and owner weights. No Euclidean realization is asserted.",
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "models":[evaluate(4),evaluate(4,star=True),evaluate(7)],
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out is not None:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes() == data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for model in result["models"]:
        nonzero = [row["length"] for row in model["paths"] if row["Q_k"] != "0"]
        print(f"receivers={model['receiver_count']} star={model['star']} positive k={nonzero}")


if __name__ == "__main__":
    main()

