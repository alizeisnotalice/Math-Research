"""Replay the fixed R573 evidence, comparing every mathematical result field."""
from pathlib import Path
import subprocess,sys,tempfile,json,os,hashlib
base=Path(__file__).resolve().parent
skip={'interpreter','python_version','sympy_version','command','runtime_seconds','peak_rss_bytes'}
def math_fields(d):
    return {k:v for k,v in d.items() if k not in skip}
rows=[]
with tempfile.TemporaryDirectory(prefix='ccu_r573_replay_') as td:
    temp=Path(td)
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    for script,saved,name in [
        ('certificate.py','results.original.json','lattice'),
        ('core_increment.py','core.original.json','core'),
        ('forest_check.py','forest.original.json','forest'),
        ('prune_check.py','prune.original.json','prune')]:
        out=temp/(name+'.json')
        cmd=[sys.executable,str(base/'numeric'/script),str(out)]
        if name=='prune':
            cmd.extend([str(temp/'forest.json'),str(temp/'core.json')])
        subprocess.run(cmd,check=True,env=env,stdout=subprocess.PIPE,text=True)
        actual=json.loads(out.read_text())
        expected=json.loads((base/'numeric'/saved).read_text())
        assert math_fields(actual)==math_fields(expected),name
        rows.append({'suite':name,'status':actual['status'],
          'all_mathematical_fields_equal':True,'interpreter':actual['interpreter'],
          'python_version':actual['python_version'],'runtime_seconds':actual['runtime_seconds'],
          'peak_rss_bytes':actual['peak_rss_bytes'],
          'command':cmd,'script_sha256':hashlib.sha256((base/'numeric'/script).read_bytes()).hexdigest()})
result={'status':'PASS_ALL_FOUR_FIXED_SUITES','suites':rows,
 'scope':'Finite exact certificates, not a proof of general weak type or arbitrary-source laminarization.'}
dest=Path(sys.argv[1]) if len(sys.argv)>1 else base/'verification.replay.json'
dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
