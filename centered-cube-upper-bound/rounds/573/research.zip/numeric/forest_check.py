"""27 fixed source-nonduplicating binary-tree accounting checks; no geometry."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time,resource
start=time.perf_counter()

def build(weights,shape):
    nodes=[]
    def leaf(i):
        v={'id':len(nodes),'mass':Q(weights[i]),'leaves':(i,),'children':None};nodes.append(v);return v
    leaves=[leaf(i) for i in range(len(weights))]
    def join(a,b):
        assert set(a['leaves']).isdisjoint(b['leaves'])
        v={'id':len(nodes),'mass':a['mass']+b['mass'],'leaves':a['leaves']+b['leaves'],'children':(a,b)};nodes.append(v);return v
    if shape=='comb':
        root=leaves[0]
        for v in leaves[1:]:root=join(root,v)
    else:
        level=leaves
        while len(level)>1:level=[join(level[i],level[i+1]) for i in range(0,len(level),2)]
        root=level[0]
    return nodes,root

rows=[]
for N in [8,32,128]:
    for model in ['balanced_equal','comb_equal','balanced_period4_powers2']:
        weights=[1 if model!='balanced_period4_powers2' else 2**(i%4) for i in range(N)]
        nodes,root=build(weights,'comb' if model=='comb_equal' else 'balanced')
        W=root['mass']
        assert root['leaves']==tuple(range(N)) and W==sum(map(Q,weights))
        for L,U in [(1,2),(2,8),(4,32)]:
            active=[v for v in nodes if L<=v['mass']<=U]
            assert active
            base=[];charges=[];counts=[0]*N;used=set()
            for v in active:
                children=v['children']
                isbase=children is None or all(c['mass']<L for c in children)
                if isbase:
                    assert used.isdisjoint(v['leaves'])
                    used.update(v['leaves']);base.append(v)
                else:
                    left,right=children
                    heavy,light=(left,right) if left['mass']>=right['mass'] else (right,left)
                    assert L<=heavy['mass']<=U and 2*heavy['mass']>=v['mass']
                    charges.append({'parent':v['id'],'parent_mass':str(v['mass']),'heavy':heavy['id'],'heavy_mass':str(heavy['mass']),'light':light['id'],'light_mass':str(light['mass'])})
                    for i in light['leaves']:counts[i]+=1
            base_mass=sum((v['mass'] for v in base),Q(0))
            charge=sum((Q(v['light_mass']) for v in charges),Q(0))
            weighted_count=sum((Q(w)*c for w,c in zip(weights,counts)),Q(0))
            ratio=Q(U,L);floorlog=0
            while Q(2)**(floorlog+1)<=ratio:floorlog+=1
            assert Q(2)**floorlog<=ratio<Q(2)**(floorlog+1)
            J=1+floorlog
            assert base_mass<=W and max(counts)<=J and charge==weighted_count and charge<=J*W
            rows.append({'leaves':N,'model':model,'leaf_masses':list(map(str,weights)),'band':[L,U],'W':str(W),'active_node_ids':[v['id'] for v in active],'active_count':len(active),'base_node_ids':[v['id'] for v in base],'base_mass_sum':str(base_mass),'base_mass_slack_W':str(W-base_mass),'nonbase_count':len(charges),'light_charges':charges,'sum_lighter_mass':str(charge),'leaf_lightedge_counts':counts,'max_leaf_lightedge_count':max(counts),'one_plus_floor_log2_U_over_L':J,'leaf_weighted_count_sum':str(weighted_count),'charge_identity_error':str(charge-weighted_count),'JW_minus_charge':str(J*W-charge),'all_checks':True})
assert len(rows)==27
result={'status':'PASS_27_EXACT_FOREST_ACCOUNTING_CASES','case_count':27,'dimensions':'leaf counts 8,32,128; not geometric dimension','base_definition':'active leaf or active parent both children mass<L','nonbase_rule':'heavier child active; ties choose left','active_definition':'L<=node mass<=U','source_nonduplication':'each original leaf occurs once, child label sets disjoint, parent is union','rows':rows,'arithmetic_error':'0','interpreter':sys.executable,'python_version':platform.python_version(),'command':[sys.executable,*sys.argv],'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Combinatorial accounting only. Does not construct cube geometry or establish a nonduplicating forest cover for general input.'}
(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('forest_check.replay.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2))
print(json.dumps([{'N':v['leaves'],'model':v['model'],'band':v['band'],'base_mass':v['base_mass_sum'],'W':v['W'],'charge':v['sum_lighter_mass'],'max_count':v['max_leaf_lightedge_count'],'J':v['one_plus_floor_log2_U_over_L']} for v in rows],ensure_ascii=False,indent=2))
