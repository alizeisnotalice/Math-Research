"""Fixed common-core inequalities: 144 rational cases, no sampling or optimization."""
from fractions import Fraction as Q
from functools import reduce
from operator import mul
from pathlib import Path
import sympy as S
import json,sys,platform,time,resource
start=time.perf_counter()
s,a,b=S.symbols('s a b')
merge=(1-s+s*a*b)-(1-s+s*a)*(1-s+s*b)
assert S.expand(merge-s*(1-s)*(1-a)*(1-b))==0
rows=[]
for n in [1,2,3,8,16,32,64,256]:
    profiles={'all_zero':[Q(0)]*n,'all_half':[Q(1,2)]*n,'first_half':[Q(1,2)]+[Q(0)]*(n-1),'first_one':[Q(1)]+[Q(0)]*(n-1),'first_three_halves':[Q(3,2)]+[Q(0)]*(n-1),'alternating_quarter_five_quarters':[Q(1,4) if i%2==0 else Q(5,4) for i in range(n)]}
    for sv in [Q(1),1-Q(1,4*n),1-Q(1,2*n)]:
        m=sv**n
        assert 0<sv<=1 and 2*m>=1
        for label,bs in profiles.items():
            beta=reduce(mul,(max(1-v,Q(0)) for v in bs),Q(1))
            F=reduce(mul,(max(1-sv*v,Q(0)) for v in bs),Q(1))
            rhs1=1-sv+sv*beta
            rhs2=beta*m+(beta+Q(2,n))*(1-m)
            gap1=rhs1-F;gap2=rhs2-F
            assert gap1>=0 and gap2>=0
            rows.append({'n':n,'s':str(sv),'profile':label,'b':[str(v) for v in bs],'m':str(m),'two_m_minus_one':str(2*m-1),'beta':str(beta),'F':str(F),'rhs1':str(rhs1),'rhs2':str(rhs2),'rhs1_minus_F':str(gap1),'rhs2_minus_F':str(gap2),'both_exact_checks':True})
result={'status':'PASS_ALL_144_EXACT_RATIONAL_CASES','symbolic_merge_difference':str(S.factor(merge)),'symbolic_identity_residual':'0','dimensions':[1,2,3,8,16,32,64,256],'s_rule':['1','1-1/(4n)','1-1/(2n)'],'case_count':len(rows),'beta_zero_cases':sum(v['beta']=='0' for v in rows),'F_zero_cases':sum(v['F']=='0' for v in rows),'rows':rows,'arithmetic_error':'0','interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'command':[sys.executable,*sys.argv],'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Fixed common-core family only; cross-group aggregation unpaid. Finite checks do not substitute for general proof.'}
assert len(rows)==144
(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('core.replay.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2))
