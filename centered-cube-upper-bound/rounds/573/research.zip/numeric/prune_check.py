"""Fixed pruning on existing 27 forests x 6 label rules, plus prior core cases."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time,resource
start=time.perf_counter()

def build(weights,shape):
    nodes=[]
    def leaf(i):
        v={'id':len(nodes),'mass':Q(weights[i]),'leaves':frozenset([i]),'children':None};nodes.append(v);return v
    leaves=[leaf(i) for i in range(len(weights))]
    def join(a,b):
        assert a['leaves'].isdisjoint(b['leaves'])
        v={'id':len(nodes),'mass':a['mass']+b['mass'],'leaves':a['leaves']|b['leaves'],'children':(a,b)};nodes.append(v);return v
    if shape=='comb':
        root=leaves[0]
        for v in leaves[1:]:root=join(root,v)
    else:
        level=leaves
        while len(level)>1:level=[join(level[i],level[i+1]) for i in range(0,len(level),2)]
        root=level[0]
    def depths(v,d):
        v['depth']=d
        if v['children']:
            for c in v['children']:depths(c,d+1)
    depths(root,0)
    return nodes,root

old=json.loads((Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).with_name('forest.original.json')).read_text())
rows=[]
for case in old['rows']:
    weights=list(map(Q,case['leaf_masses']));N=case['leaves'];L,U=case['band']
    nodes,root=build(weights,'comb' if case['model']=='comb_equal' else 'balanced')
    W=root['mass'];active=[v for v in nodes if L<=v['mass']<=U]
    base={v['id'] for v in active if v['children'] is None or all(c['mass']<L for c in v['children'])}
    nonbase=[v for v in active if v['id'] not in base]
    def hl(v):
        a,b=v['children'];return (a,b) if a['mass']>=b['mass'] else (b,a)
    heavy_ids={hl(v)[0]['id'] for v in nonbase}
    rules={'none':set(),'all':{v['id'] for v in active},'even_depth':{v['id'] for v in active if v['depth']%2==0},'odd_depth':{v['id'] for v in active if v['depth']%2==1},'active_bases':base,'nonbase_heavychildren':heavy_ids}
    for name,high in rules.items():
        hs=[v for v in active if v['id'] in high]
        maxhigh=[v for v in hs if not any(v['leaves']<a['leaves'] for a in hs)]
        max_ids={v['id'] for v in maxhigh}
        union=set()
        for h in maxhigh:
            assert union.isdisjoint(h['leaves']);union.update(h['leaves'])
        maxmass=sum((v['mass'] for v in maxhigh),Q(0));assert maxmass<=W
        def owner(v):
            hits=[h for h in maxhigh if v['leaves']<=h['leaves']]
            assert len(hits)<=1
            return hits[0] if hits else None
        remaining=[v for v in nonbase if owner(v) is None]
        paid=[];uncovered=[];seen=set()
        for v in remaining:
            h,l=hl(v)
            assert L<=h['mass']<=U
            o=owner(h)
            if o is None:
                assert h['id'] not in high
                uncovered.append({'parent':v['id'],'heavy':h['id']})
            else:
                assert h['id']==o['id'] and h['id'] in max_ids
                assert h['id'] not in seen;seen.add(h['id'])
                assert l['mass']<=h['mass']
                paid.append({'parent':v['id'],'maxhigh_heavy':h['id'],'heavy_mass':str(h['mass']),'light_mass':str(l['mass'])})
        charge=sum((Q(p['light_mass']) for p in paid),Q(0))
        usedmass=sum((Q(p['heavy_mass']) for p in paid),Q(0))
        assert charge<=usedmass<=maxmass<=W
        rows.append({'leaves':N,'model':case['model'],'band':case['band'],'rule':name,'high_ids':sorted(high),'maximal_high_ids':sorted(max_ids),'maximal_high_leafsets':{str(v['id']):sorted(v['leaves']) for v in maxhigh},'W':str(W),'maximal_high_mass':str(maxmass),'remaining_nonbase_ids':[v['id'] for v in remaining],'covered_heavy_payments':paid,'uncovered_low_heavy':uncovered,'covered_light_mass_sum':str(charge),'used_maxhigh_heavy_mass_sum':str(usedmass),'mass_inequality_slack':str(maxmass-charge),'all_exact_checks':True})
assert len(rows)==162
core=json.loads((Path(sys.argv[3]) if len(sys.argv)>3 else Path(__file__).with_name('core.original.json')).read_text())
carrier=[]
for i,c in enumerate(core['rows']):
    beta=Q(c['beta'])
    if beta==0:continue
    product=Q(1)
    for b in map(Q,c['b']):product*=1+b
    residual=1-beta*product
    assert residual>=0
    n=c['n'];m=Q(c['m']);condition=n*beta**2>=1
    squaregap=n*m*m-(m*product)**2
    if condition:assert squaregap>=0
    carrier.append({'core_case_index':i,'n':n,'s':c['s'],'profile':c['profile'],'beta':str(beta),'m':str(m),'product_1_plus_b':str(product),'one_minus_beta_product':str(residual),'n_beta_squared_ge_one':condition,'conditional_squared_gap':str(squaregap) if condition else None,'exact_check':True})
result={'status':'PASS_162_PRUNING_AND_POSITIVE_BETA_CARRIER_CHECKS','forest_cases':27,'label_rules':6,'pruning_cases':len(rows),'positive_beta_core_cases':len(carrier),'squared_carrier_condition_cases':sum(c['n_beta_squared_ge_one'] for c in carrier),'pruning_semantics':'ancestor-maximal high nodes retained as terminal paid blocks; strict active descendants pruned; remaining nonbase operations exclude maximal-high nodes themselves and all descendants. Original base/nonbase and heavy rules fixed before high labeling.','pruning':rows,'carrier':carrier,'arithmetic_error':'0','interpreter':sys.executable,'python_version':platform.python_version(),'command':[sys.executable,*sys.argv],'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Pruning combinatorics and carrier products only; no general-label nonduplicating forest existence or cube coverage claim.'}
(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('prune_check.replay.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['pruning','carrier']},ensure_ascii=False,indent=2))
