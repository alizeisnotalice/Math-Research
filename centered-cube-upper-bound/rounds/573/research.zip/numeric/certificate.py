"""R573 fixed finite-binomial Lebesgue integral certificate. No atom enumeration."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import sys,platform,time,resource,json
import sympy as S
start=time.perf_counter()
nlist=[3,4,8,16,32,64,128,256]

def show(q):
    return str(S.N(S.Rational(q.numerator,q.denominator),22))
rows=[]
for n in nlist:
    r=F(n-1,n)
    a=F(4,3) # length of coordinate small event in both boxes
    b=F(2,3) # length of large event in outer box
    inner_large=2*r-a
    assert inner_large>=0
    square_prefactor=(3*r/4)**(2*n)
    untruncated=F(0);truncated=F(0);volume=F(0)
    saturated=[]
    for k in range(n+1):
        # Separate combinatorial enumeration of receiver coordinates,
        # no source atoms and no product-integral closed form used here.
        outer_vol=F(comb(n,k))*a**(n-k)*b**k
        inner_vol=F(comb(n,k))*a**(n-k)*inner_large**k
        v=outer_vol-inner_vol
        assert v>=0
        T_squared=square_prefactor*(2**k)**2 # whole source count first, then squared
        untruncated+=v*T_squared
        truncated+=v*min(T_squared,F(n))
        volume+=v
        if T_squared>n and v>0:
            saturated.append(k)
    assert volume==F(2)**n-(2*r)**n
    closed_G4=square_prefactor*(F(4)**n-(F(4)-F(8,n))**n)
    assert untruncated==closed_G4
    per_mass=untruncated/(2*r)**n
    closed_G4_ratio=r**n*F(9,8)**n*(1-F(n-2,n)**n)
    assert per_mass==closed_G4_ratio
    interior_fraction=F(2*n-1,2*n+1)**n
    G1=interior_fraction*per_mass
    closed_G1=F(2*n-1,2*n+1)**n*r**n*F(9,8)**n*(1-F(n-2,n)**n)
    assert G1==closed_G1
    trunc_normalized=interior_fraction*truncated/(2*r)**n
    bound_G6=n*interior_fraction/r**n
    exact_volume_bound=n*interior_fraction*volume/(2*r)**n
    assert trunc_normalized<=exact_volume_bound<=bound_G6<=F(27,8)*n
    assert truncated<=untruncated
    q={'n':n,'kappa':'1','r':str(r),'fixed_side_length':'8/3','region':'union of (2n-1)^n interior receiver cells, outside same Omega','counts':{'source_atoms_symbolic':f'({2*n+1})^{n}','interior_cells_symbolic':f'({2*n-1})^{n}','K_regions':n+1},'exact':{'single_cell_volume':str(volume),'single_cell_G4':str(untruncated),'single_cell_truncated':str(truncated),'G4_over_kappa_m':str(per_mass),'G1_normalized':str(G1),'truncated_normalized':str(trunc_normalized),'truncated_over_untruncated':str(truncated/untruncated),'G6_bound_normalized':str(bound_G6),'sharper_volume_bound_normalized':str(exact_volume_bound),'G1_identity_error':'0','G4_identity_error':'0','volume_identity_error':'0','arithmetic_error':'0'},'display':{'G4_over_kappa_m':show(per_mass),'G1_normalized':show(G1),'truncated_normalized':show(trunc_normalized),'truncated_over_untruncated':show(truncated/untruncated),'G6_bound_normalized':show(bound_G6),'sharper_volume_bound_normalized':show(exact_volume_bound)},'saturated_positive_volume_k_min':min(saturated) if saturated else None,'saturated_positive_volume_k_max':max(saturated) if saturated else None,'checks':'all exact Fraction assertions passed'}
    rows.append(q)
result={'status':'PASS_EXACT_INDEPENDENT_K_REGION_INTEGRATION','inputs':{'n':nlist,'kappa':1,'r':'1-1/n','atom_centers':'2k, k in {-n,...,n}^n','atom_mass':'(2r)^n','Omega':'union of disjoint open centered cubes radius r','field':'complete fixed-scale average T_(8/3)nu','cap':'min(T^2,n)','no_full_maximal_claim':True},'independent_formula':{'receiver_K_volume':'binom(n,k)*(4/3)^(n-k)*[(2/3)^k-(2/3-2/n)^k]','complete_T_squared':'(3r/4)^(2n)*(2^k)^2','normalized_global':'[(2n-1)/(2n+1)]^n * single_cell_integral/(2r)^n'},'rows':rows,'interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'command':[sys.executable,*sys.argv],'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Only same inner-region fixed-scale obstruction and its truncation. Not truncated full-scale estimate, no tail assertion, no general weak bound.'}
(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('results.replay.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'runtime_seconds':result['runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes'],'rows':[{'n':q['n'],**q['display'],'first_saturated_k':q['saturated_positive_volume_k_min']} for q in rows]},ensure_ascii=False,indent=2))
