# R142 辅助：共同alpha保留时的最佳单逆核幂增强

状态：仅作一条有界推导。得到不引入alpha负幂、逐点及接收积分均严格加强JR2/JR7的有效公式；尚未得到其来源平均的统一根阶付款。固定原u₀和good C_J≤3范围，不扩大JR的量词。

## CA1. 命题与共同来源合同

固定原ω,V,j,y及同一ν。接收点x上使用原共同

\[
Q_0(x)=\int K_0(x-u)d\nu(u),\quad Q_J(x)=\int J(x-u)d\nu(u),
\]
\[
d_x(u)=DK_0(x-u)-U_x(u)\ge0,
\quad R_x=D(q(x)-Q_0(x))+\int d_x(u)d\nu(u),
\quad\alpha(x)=R_x/Q_J(x).
\tag{CA1}
\]

仅在合法接收域Ω上使用q≥Q₀、Q_J>0，故R_x≥0。Ω外不假设该余额合同成立，不将alpha延伸成正正常数。Q_J=0为零来源行；A_v=0为零余量行，均按原约定处理。

对固定good来源v，记

\[
a(x)=\frac{D K_0(x-v)}{T A_v}>0,\qquad
b(x)=\frac{\alpha(x)J(x-v)}{T A_v}
=\frac{J(x-v)R_x}{T A_vQ_J(x)}\ge0.
\tag{CA2}
\]

原rho=(1−a−b)₊。参数θ≥0、0≤η≤1在接收积分前固定，不能随x逐点优化后继续使用乘积积分。令c_θ=θ^θ/(1+θ)^{1+θ}，c₀=1。

**增强命题：**

\[
\boxed{\rho_v(x)\le c_\theta a(x)^{-\theta}
 [1-b(x)]_+^{1+\theta}.}
\tag{CA3}
\]

与JR2所用单项界c_θa^{-θ}相比，多出的因子位于[0,1]，alpha=0时准确退回旧界，alpha趋0时连续退化；不要求任何统一alpha下界。这个命题逐行使用原alpha，未从同一reserve再分配一份容量。

## CA2. 证明与尖常数

b≥1时两边都为0。b<1时令r=1−b>0，则

\[
(1-a-b)_+=r(1-a/r)_+
\le c_\theta a^{-\theta}r^{1+\theta}.
\]

常数来自max_{z>0}z^θ(1−z)₊=c_θ。θ>0时在a=θ(1−b)/(1+θ)取等号，故对固定b的这一单逆核幂形式，系数与(1−b)幂都是准确的；θ=0取上确界r。证明无需独立来源、乘积ν或距离矩。

原C_J≤3 good门给p_xw_g≤KJ_v。乘上该门并沿JR3同样放松，得到

\[
1_{good}\rho_v\le c_\theta
 \left(\frac{KJ_v}{p_xw_g}\right)^\eta
 \left(\frac{TA_v}{DK_v}\right)^\theta
 \left[1-\frac{J_vR_x}{TA_vQ_J(x)}\right]_+^{1+\theta}.
\tag{CA4}
\]

alpha依赖x和整份ν，这种依赖完整留在最后一因子中。没有先把alpha当常数或把它变成来源独立的随机变量。

## CA3. 固定核的显式接收增强及严格性

先采用JR1固定参数合同：s,L,R,H、j、原u₀、g,h,τ,T固定，y,z,v固定，A_v>0。alpha、q、Q_J仍可随x变化。令

\[
F_{\theta,\eta}(x)=c_\theta
 \left(\frac K{w_g}\right)^\eta\left(\frac{TA_v}{D}\right)^\theta
 h_R(x-z)p_x^{1-\eta}J_v(x)^\eta K_v(x)^{-\theta},
\]
\[
D_\theta(b)=1-(1-b)_+^{1+\theta}\in[0,1].
\tag{CA5}
\]

F的全空间积分就是JR2右边的显式一维乘积，记为B_JR。由CA4有更强的不减法形式

\[
\boxed{
\int_\Omega p_xh_R(x-z)1_{good}\rho_v(x)dx
 +\int_\Omega F_{\theta,\eta}(x)D_\theta\!\left(
 \frac{J_v(x)R_x}{TA_vQ_J(x)}\right)dx
 \le\int_\Omega F_{\theta,\eta}(x)dx\le B_{JR}.}
\tag{CA6}
\]

固定来源的hard盒紧、所有soft核正，故B_JR有限；可以等价写为旧JR2乘积上界减去CA6第二项。扣减项不是虚构的负交通，亦不等同N_del或旧N_Z：它只是原rho中已存在的共同alpha所造成的上界缩减。

对固定θ、η，若Ω∩Q_R(z)中有正Lebesgue测度满足R_x>0，那么F>0、J_v>0给该扣减严格正，因而严格改善相同θ、η的JR2上界。此为逐实例严格性，不是统一比例缺口；R_x可趋0，Ω也可能零测。不将rho=0的域称为新增正交通付款。

还可用完全显式下界

\[
D_\theta(b)\ge\min\{1,b\}
=\min\left\{1,\frac{J_v(x)}{TA_vQ_J(x)}
 \left[D(q-Q_0)+\int(DK_0-U)d\nu\right]\right\}.
\tag{CA7}
\]

因为0≤b≤1时(1−b)^{1+θ}≤1−b，b≥1时Dθ=1。在good域还可由J_v≥p_xw_g/K得到b≥alpha(x)p_xw_g/(KTA_v)，但该替换仅在good域进行，不能用于CA6全Ω扣减时漏掉good资格。

R141的合法reserve下界R_x≥λ_Sν(S)+R_bad也可代入CA7的单调函数；必须使用同一共同选择、重叠扣减和同一x。此代入只提供显式可确认的扣减，不允许把这些部分再作为不同alpha容量各自支付。

## CA4. 自适应单元保留alpha：不作新分层，也不付负alpha矩

采用JR5–JR7的固定参数单元C和全部端点/包络；原u₀固定、C_J≤3不变。将JR7右边的可分乘积被积函数记为

\[
F_C(x)=c_\theta E_p^{1-\eta}E_R
 \left(\frac K{w_+}\right)^\eta\left(\frac{T_+A_+}{D}\right)^\theta
 h_{R_+}(x-z)\prod_i\bar p_i(x_i-y_i)^{1-\eta}
 J_v(x)^\eta\prod_i\underline k_i(x_i-v_i)^{-\theta}.
\tag{CA8}
\]

其全空间积分B_C恰为JR7右边，含原全部位移与维数费用。令Ω_C为实际合法接收域与该单元的交集，A_+>0。实际TA_v≤T_+A_+，所以

\[
b(x)\ge b_C(x):=\frac{\alpha(x)J_v(x)}{T_+A_+}
=\frac{J_v(x)R_x}{T_+A_+Q_J(x)}.
\]

同时JR包络给CA4除最后一因子以外的接收权≤F_C。因此

\[
\boxed{
\int_{\Omega_C}p_xh_R1_{good}\rho_vdx
 +\int_{\Omega_C}F_C(x)D_\theta(b_C(x))dx
 \le\int_{\Omega_C}F_C(x)dx\le B_C.}
\tag{CA9}
\]

这个增强不冻结alpha；实际alpha(x)只在合法域Ω_C中出现，依然用原Q_J和整份ν。F_C取正上包络且b_C取下界的方向相容，因为(1−b)₊^{1+θ}递减。不能在单元以外凭空延伸alpha扣减。

CA9继承JR7全部费用：E_p^{1−η}E_R、w_+^{−η}、(T_+A_+/D)^θ、逆核下包络\underline k^{−θ}及hard R_+^{-n}。JR的保守覆盖含至多(n+1)(2n+3)³单元，前因子可粗界27；仍须逐单元求和，不免费取最优单元。低核下包络损失和来源位移不因27而成为常数。本文没有再按alpha分层，因此没有隐藏的层数或层间重复；alpha=0的单元/点自然给零扣减。

若改用双负幂a^{−θ}b^{−σ}（σ>0），尖常数是θ^θσ^σ/(1+θ+σ)^{1+θ+σ}，但会产生alpha(x)^{−σ}。本稿不使用这种形式：无统一alpha下界时，把其移出dx或对趋0层免费求和均不合法。CA9避免了这个新增费用。

## CA5. 原来源平均、两份分母和停止点

CA9是对每个固定外hard z和内good v的非负不等式。恢复原RT4的两份Π_t、δ_t、dx外β与ν时，必须仍按JR8所列费用操作：用q(x)≥q_-后，接收上界及扣减均带1/q_-，原来源权是

\[
\frac{1_{Z_t}(v)1_{Z_t}(u)w_t(v)w_t(u)}{e_t(y)^2}
\,d\nu(z)d\nu(v)d\nu(u)\,\delta_t(v,u)
\,\frac{dt}{t}\,d\beta_V(y),
\tag{CA10}
\]

外层为原EΣ_{V,j}及参数单元求和。可按JR8对其余正门作相同合法放松；alpha仍按同一x、同一ν计算，不能为每个z,v,u重选。原hard来源未被假定存活或bad，beta不换nu，未使用e_t下界。若使用仅good域有效的CA7最后那个p替换，必须把相应good域指示同时留在扣减中。

先在有限来源/接收截断内对CA9乘这些非负源权，再Tonelli求和，可得到“原正项 + 实际alpha扣减 ≤ JR8原上界”的合法增强。无界极限使用这三个非负量的形式，不作∞−∞。固定来源的B_C有限不保证ν平均有限；因此即使扣减严格为正，也不能把两个可能无穷的来源量相减后宣称有预算。

**本辅助推导的结论：** JR2舍弃alpha确实丢掉了可明确保留的因子(1−alpha J/(TA))₊^{1+θ}。CA6/CA9是无条件有效且在正reserve接收区域上严格增强的显式式子，保留了DK₀与共同alpha J两项；没有假设alpha为正常数，也没有增加alpha负矩费用。

**仍缺的单一步骤：** 需要在真实β、三份共同ν及两e分母下，对CA9的实际扣减给足够的下界，或直接控制其保留下来的非负右侧平均。现有FIRST只保证R_x≥0，不给这个接收权下的维数统一正占比；alpha可趋0，来源平均问题也未由CA9自动解决。因此本稿不声称新的统一εX+C√n polylog(n)Wβ付款，不调整Θ阈值，不对旧负账附门或返还。完成后停止，仅新增本文件，无Git、无PDF。
