# R142 有界真实接收测度探路计划（未运行，待审核）

只取R141的I1(n4)、I2/P1(n16)各最高120位复核节点；固定其实际六源位置、精确质量（G1翻倍、CORE取该节点m、far扣除，总质量1），s=.25、L=.9、R=b=1、y=(.3,…,.3)及原T/Hhat/Lplus/tau/h。改变真正n维接收点x。目标是判断x0大交通是否局限于小dx或p dx区域，以及哪个合法必要门限制它。此为有限原子必要模型，不认证FULL、原forest、真实连续ν或维度阶。

## 1. 固定λ及全部随x重算

λ_test固定为R141最高节点q(x0)，由精确mass及原保存三测试仿射系数求得；不在每个x重设λ。x0以真实φ重算作控制，报告与保存值的误差；上端等号有数值不确定时保留，不为了通过而改λ。

RT4：y、ν、阈值、w_t、eg、A=wtau−wh及e_t=Σνw_t均独立x。重新计算p=P_s,L(x−y)，各源K0=P_s,Hhat(x−z)、K1=P_s,L(x−z)、K2=P_s,Lplus(x−z)、J=P_1,b(x−z)、Q=(K1+K2+J)/3；Q0/ QJ/ Qstar为各自ν积分，q=max三测试。

good⇔p wg≤KQ，bad为补集；E=good且A>0，U=min(TA,DK0)在E上、否则0；alpha=(Dq−ΣνU)/QJ，rho=[1−(U+alpha J)/(TA)]_+在E上。E沿原R136合同；若核对原hard排除B_hard=(R≤L且x在源Q_R)，本菜单R>L使此排除恒假。禁止保留原G1/G4角色。

hardmass(x)=Σν_z 1_{所有坐标|x_i−z_i|≤R/2}，逐六源重算，不能固定为CORE质量。例如G1=−.8在CORE盒负角也会入帽。主门为：3λ/4≤q(x)≤λ、hardmass/R^n≤4λ、hardmass>0、high p eg≥2Kq、heavy eg>ell cj^(−n/2)g^n q、QJ>0、alpha≥0及真实正rho/δ/FA/Psi项；strict_s/scale/tau/h/FIRST三测试同时记录。主帽是4λ，不悄悄额外加旧4q帽；FIRST只核原三测试，不补造history。

FA随x按(B_FA δ p c_v/Q_v)^(1/kv)截原score段；Psi由固定全部未归一化后缀重建，全36对核对。所有36对按新good/bad重枚举，不冻结旧FA区间。

主交通
 Fλ(x)=1_主门 · p(x) hardmass(x)/q(x) · Σ_good,bad rho_vν_vν_u∫δ FA(x,t)Psi w_vw_u/e_t² dt/t。
另明确列旧必要门对照（无固定λ区间/帽，采用旧hardmass≤4q）；它不是主要体积对象。

## 2. 剩余分支与CJ门

固定核Hhat<Lplus（这三例满足）。逐x、逐good端计算
 B_H=(s b/H)^n[1+(1−s)/(s φ(H/(2b)))]^{m_H}，m_H=#{|x_i−z_i|≤H/2}，C_J=1+B_L+B_Lplus。
同一pair累加分别输出Fλ与Fλ,CJ（后者仅保留C_J(v)≤3的good贡献），无需新采样/积分；另报所有当前good均CJ≤3的整体点标记。不得用Q/J≤1替代CJ≤3。

## 3. 有界三阶段接收菜单

批准后采用两种真实n维iid分布：uniform-Q_CORE及p(x)dx。numpy PCG64种子142000+100·case_index+distribution_index，case_index=1/2/3，distribution_index=1为uniform、2为p。p抽样逐坐标：以概率1−s取V~U[−.5,.5]，以概率s取V+sqrt(U)·Laplace(0,1)，其中V/U/Laplace独立；再x=y+LZ。该soft密度等于真实φ，源于E2的rate a≥1、密度2a^-3 Laplace混合，不使用Gaussian。阶段3延续同一流，保存所有坐标和soft分支。

| 阶段 | 每例预算 | 用途 |
|---|---:|---|
| 初探 | 每分布128 iid点 + x0精确恢复 | 先报告真实cost及handle，检查固定λ/门与目标 |
| 门边界压力 | 12确定性点 | axis=1,n/2,n，余坐标0，该轴取±(Hhat/2−10^-8)、±(Hhat/2+10^-8) |
| 扩大 | 每分布新增1024 iid点 | 固定总N=1152/例，不因零命中或失效换点 |

总预算6951接收点（6912随机、36压力、3控制），n最高16。压力点仅核跳变/门，不作体积。其它来源进入hard支持由每个点逐atom检查，不增加角点或对角线“体积”菜单。

numpy+scipy.special.expn float64批处理全部点，原核/门相对margin≤10^-10（含数值等号）标不确定；最多48个70位mpmath复核点，每例16：x0、最高正F四点、全部关键门最小相对margin四点、压力点按axis/符号/内外顺序前七点，同点去重。其它数值近边界点保留不确定，不扩大复核预算。压力点的kernel硬边界明确使用原≤定义。

uniform可估计盒内正目标dx体积（盒体积1）和盒内F积分；p抽样可估计全域正目标p dx质量和∫F dx（均值F/p）。两者分开报告；uniform不覆盖其它hard来源盒，p抽样零命中不代表那些盒无交通。两者均不认证FULL。

## 4. 真实核与简化时间式

φ沿R135 E3表达：r≤.5时1−E3(.5−r)−E3(.5+r)，r>.5时E3(r−.5)−E3(r+.5)，E3(0)=1/2；一维kernel=((1−s)1_|d|≤H/2+sφ(d/H))/H。不用Gaussian。批处理用scipy.special.expn，70位复核用已有vendor mpmath精确同式；没有区间认证。

固定质量使e_t独立x，无需通用timeCDF。先核原score集合与以下推导吻合，不吻合则保留重建失败：

I1/I2有效段score仅{0,n}，令e=A_c t^-n+B_c（A_c/B_c为νc分组和，不与原源A混淆）。正δ=n pair截到FA真实t1的积分为
 cv cu/A_c · [1/e(t1)−1/e(t0)]
 =cv cu·[t0^-n−t1^-n]/[e(t0)e(t1)]。
差分用expm1稳定实现；无需数值积分，仍须新good/bad/FA决定t1。

P1有效首段score{0,n/2,n}，u=t^(n/2)，e=(A_c+B_c u+C_c u²)/u²。高-中、高-低、中-低pair积分分别cvcu∫{1,2u,u²}/(A_c+B_c u+C_c u²)^2 du，截到各真实FA端点；末段全n无正δ。按固定二次分母构造三个公共累积函数，采用固定Gauss–Legendre 32/64节点向量核对（不相合则只再作64/128一次；失败保留），70位复核用64/128节点相合检查。不能粗网格插值或把旧积分乘新rho。

P1公共前缀向量求积总上限1024次（包含70位核对），相同端点缓存，单次返回三个幂；闭式已验证则不消耗此上限。失败主要门的点仍保存全部核/门，主F=0，不需交通积分。达到积分上限时剩余正集合可由正长度/系数判定，积分保持“未算”及[0,理论上界]，不得置零或换点。当前无数学数据缺项；P1稳定原函数/向量积分实现尚待批准后编码，不是已完成的CDF。

## 5. 统计与明确上界

每例分别报确定正、数值不确定、所有失败门共现及固定顺序首失败：λ区间、hard帽、high/heavy、good/rho、FA、CJ。保存全部失败而非只一个标签，不能把相关门说成独立原因。

固定λ主目标有界：rho≤1、ΣΠ_vΠ_u=1、δ≤n，internal≤n log(h/tau)，hardmass/q≤16/3；所以Fλ/p≤B=(16/3)n(h/tau−1)，取log u≤u−1的保存有理上界。p≤L^-n，故uniform盒F≤L^-n B；CJ过滤仍有此界。

最终固定N=1152用二项Clopper–Pearson给正体积比例区间（mpmath betainc二分，不需要scipy.stats）；积分均值只用上述显式界给Hoeffding区间，经验标准误仅描述，不能认证稀有积分。3例×2分布×2目标×2主要指标（正集合概率、积分）取alpha=.05/24作Bonferroni预算；初探不另给声称同时有效的置信结论。p抽样均值使用F/p及上界B；uniform均值使用F及上界L^-n B。

未算积分或不确定分类分别给0下端/理论上界上端并分开统计。置信解释以理想iid抽样和数值分类正确为前提；PRNG复现与70位一致性不等于数学区间证明。零命中只给概率上限，不称集合为空；均值区间可能宽得无效，必须如实显示。

## 6. 环境、依赖及待审核状态

主代理已安装scipy1.15.3至/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime；使用runtime Python /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3，numpy2.3.5，脚本sys.path插入该scipy目录，已有vendor mpmath可用于70位核/前缀复核。不再查找或安装环境，外部runtime不归档。

读取R141 numeric_joint.json（SHA acafcde85224fc1e5e2e9663f00e5233ead8daa8adb0d7382ce3436bb0b7618b）的最高node_id和精确质量；原R136时间源SHA1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de。冻结λ并核输入SHA。除已明确独立x的weight/A/et，所有接收核及标签重新求值。

批准变化记录：父代理明确增加每例每分布128+1024的双分布菜单、float64真实E3 batch、10^-10近门标记、最多48点70位复核、P1固定GL节点相合和24指标置信预算。原计划的有限source/质量/窗口/固定λ及CJ门均不变。此版本冻结后立即实现一次producer；不增加其它菜单或参数优化。
