from fractions import Fraction as F
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
checks={}
def check(stage,triples):
 count=eq=positive=0
 for t,a,b in triples:
  assert a>0 and b>=0 and t>=0
  c=F(t**t,(1+t)**(1+t)) if t else F(1)
  lhs=max(1-a-b,0); old=c/a**t; rhs=old*max(1-b,0)**(1+t)
  assert 0<=lhs<=rhs<=old
  discount=1-max(1-b,0)**(1+t)
  assert discount>=min(1,b)
  count+=1;eq+=lhs==rhs;positive+=lhs>0
 checks[stage]={'checked':count,'equality':eq,'positive_lhs':positive,'passed':True}
check('initial',((t,F(a,4),F(b,4)) for t in [0,1,2] for a in [1,2,4,8] for b in [0,1,2,4,8]))
def stress():
 for t in [0,1,2,8,32]:
  for k in [1,4,12,32]:
   eps=F(1,10**k)
   for b in [F(0),eps,1-eps,F(1),1+eps]:
    for a in [eps,F(1),1+eps]:yield t,a,b
    if t and b<1:yield t,F(t,1+t)*(1-b),b
check('boundary_stress',stress())
check('expanded',((t,F(a,16),F(b,16)) for t in range(33) for a in range(1,65) for b in range(33)))
out={'method':'Exact rational arithmetic for integer theta; analytic proof covers all real theta >=0. This is not a source-average certificate.','stages':checks,'author_sha256':hashlib.sha256((root/'joint_receiver_common_alpha.md').read_bytes()).hexdigest()}
(root/'common_alpha_exact_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
