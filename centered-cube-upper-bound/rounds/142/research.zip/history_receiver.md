# R142 接收正幂 Chernoff 历史定位（限 R134–R141）

检索口径：只查 R134–R141 的 receiver、joint、hard-margin、hard-shell、ratio-column 相关 Markdown。结论是“在此限定范围内未定位到目标公式”，不把未定位解释为历史上不存在。

## 目标式与定位结论

本次待查候选为同时保留两个 good 来源门
\[
J(x-v)\ge p(x-y)w_g(v)/K,\qquad \rho(v)>0\Rightarrow DK_0(x-v)<TA(v),
\]
再用正幂 Chernoff 核积分
\[
(K/w_g(v))^\eta(TA(v)/D)^\theta
\int h_R(x-z)\,p(x-y)^{1-\eta}J(x-v)^\eta K_0(x-v)^{-\theta}\,dx,
\quad \eta,\theta\ge0
\]
支付真实接收交通。限定文件中未找到同时包含上述双门及此正幂乘积积分的已证式或已登记付款。

## 最接近的已定位工作及区别

- **R136，`active_capacity_audit.md` §ACA9–11，行 122–155；§AB14 附近行 172–201。** 已证的是固定 good (v) 下对活跃 bad 容量的有限 (p>1) Hölder/分数矩估计，矩核含 (K_0^{-(p-1)})，并带 (A(v)^\theta J(x-v)^{-\theta})（行 172）。其方向是逆 (J)、逆 (K_0) 的来源容量估计，不是目标的 (J^{+\eta}K_0^{-\theta}p^{1-\eta}) 正幂 Chernoff 接收核。文件行 193、201 明确指出源积分与真实接收乘子尚未整体付清；因此此处不能记作目标式付款。
- **R138，`receiver_source_geometry.md` §RS1–3，行 1–35；`pair_ratio_audit.md` §PRA1–2（行 1–约 50）与实际接口行 126–166。** 已证/冻结的接收对象是同尺度核比 (K_H(x-a)/K_H(x-u)) 的配对界，实际展开为 (p\,K_0(x-a)/K_0(x-u)) 的双来源积分（RS3；PRA2）。PRA1 的单侧硬窗越界项及其概率用于核比比较；pair-ratio 审核结论仍注明来源分离/外层价格未付（`pair_ratio_audit.md` 收尾及 §PRA8）。它不是对目标 (J^{+\eta}) 正幂、双 good 门 Chernoff 核的估计。
- **R138 `pair_ratio_audit.md` §PRA8，行 176–约 205。** 已证一个实际低似然子支：(E_{low}=\{f>0:f w_t/K_0\le L_\zeta\})，(L_\zeta=4De_tJ^\zeta/(TAQ_J))，以及
  \[
  \rho\int_{E_{low}}f\,d\Pi_t\le \rho L_\zeta\alpha Q_J/(De_t).
  \]
  该式以 (K_0) 低似然筛选和共同容量付费，再用固定共同 \(\alpha\) 的二次帽；不是目标中 (J\ge p w_g/K) 与 (DK_0<TA) 的同时门，也不是所列混合正幂核。该稿明说要有既有误差槽且未证明高似然尾，故不覆盖目标接收。
- **R139 `joint_hard_margin.md` §HM4–8，行 44–约 100；`hard_margin_prior_audit.md` 行 69–96、173–190、239附近。** 已证硬核心质量乘 \(\rho\) 的联合阈值帽，典型式为
  \[
  \rho(v)\le[a_v-\lambda_cJ(x-v)m_c/(TA(v)Q_J)]_+,
  \qquad m_c\rho(v)/(qR^n)\le a_v^2TA(v)/(4\lambda_cJ(x-v)R^n).
  \]
  这是用共同 hard 核心容量得到的 **(1/J)** 逆因子联合帽；另有 (J\ge p w_g/K) 的代入充分界（HM6），但没有把真实接收积分改写为目标的正幂 Chernoff 积分。hard-margin 后审给定的 \(S,\lambda_S\) 在整份外 hard-(z) 积分固定，来源选择可依内 good (v)，不得逐 (z) 重选（审计行 173–190）；这是其 selector 合同，不是目标核的 selector 费用结算。
- **R139 `hard_shell_geometry.md` §HS5–9，行 61–约 120；行 222。** HS7 是固定 (p h_R) 载体下硬壳坐标数的真实 Chernoff 界：
  \[
  \int p h_R\,1_{\{d_H\ge D_*\}}dx
  \le \prod_i c_i\inf_{u\ge0}\exp[-uD_*+\sum_i\log(1-\pi_i+e^u\pi_i)].
  \]
  它的 \(c_i,\pi_i\) 依赖当前偏移 (y-z)，无一般外预算，行 222 明确提示依实际核验后才可用于指定层。这个生成函数不含 good-(v) 的 (J\) 或 \(\rho\) 夹门，也不含目标的 (J^{+\eta}K_0^{-\theta}) 接收积分。
- **R141 `round_report.md` 行 11–15、22。** 新增储备扣除后的 \(\hat a=[a-J(v)R_{bad}/(TAQ_J)]_+\) 与 \(\hat\Gamma=\Gamma(\hat a/a)^2\)，以及既有正支补集的条件价格；报告明确样本中门命中 0。此为共同储备对既有 hard×\(\rho\) 二次帽的收紧，不是目标 Chernoff 接收公式。

## 状态与费用账

在 R134–R141 相关 Markdown 中，目标双门的正幂 Chernoff 核尚未定位为已证结果或已付款项。已找到的相关代价结构分别是：R136 的共同 \(\alpha Q_J/D\) 来源容量与 (J^{-\theta}) 分数矩；R138 真实配对核比及另需外层来源分离/高似然尾价格；R139 hard-margin 的固定共同 \(S,\lambda_S\) selector 和 (1/J) 逆因子帽；R139 HS 固定载体生成函数按实际偏移付 \(\prod_i c_i\) 并保留 \(\pi_i\)。没有材料给出目标式中 \((K/w_g)^\eta(TA/D)^\theta\) 两门放松因子、对应 \((\eta,\theta)\) 可用范围/积分有限性及其对真实接收交通的完整 selector/外预算。因此这些均列为未定位的候选账，不声称其不可能成立，也不把相邻已证结果拼接成证明。
