from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
sys.set_int_max_str_digits(0)
b=Path(__file__).resolve().parent
src={c['id']:c for c in json.loads((b.parent/'centered_cube_round136_20261014/active_traffic_v2.json').read_text())['cases']}
j=json.loads((b.parent/'centered_cube_round141_20261015/numeric_joint.json').read_text())
def f(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def pack(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
res=[]
for cid in ['I1','I2']:
 rec=next(r for r in j['verifications'] if r['node_id']==j['summary'][cid]['best_verified_node_id']);row=next(r for r in j['slices'] if r['id']==rec['slice']);c=src[cid];at=c['atoms']
 nu=[f(a['nu']) for a in at[:4]];nu[int(row['source'][1:])-1]*=jf(row['multiplier']);m=jf(rec['mass_exact']);nu+=[1-sum(nu)-m,m]
 D=f(c['parameters']['D']);T=f(c['derived']['T']);p=f(c['derived']['p']);q=max(sum(nu[i]*f(a[key]) for i,a in enumerate(at)) for key in ['K0','J','Q']);QJ=sum(nu[i]*f(a['J']) for i,a in enumerate(at))
 U=[min(T*f(a['A']),D*f(a['K0'])) if a['good'] else F(0) for a in at];alpha=(D*q-sum(nu[i]*U[i] for i in range(6)))/QJ
 rho=[max(F(0),1-(U[i]+alpha*f(a['J']))/(T*f(a['A']))) if a['good'] and f(a['A'])>0 else F(0) for i,a in enumerate(at)]
 total=F(0);pieces=[]
 for a in row['FA_audit']:
  v,u=divmod(a['pair'],6);s=c['score_segments'][a['segment']];ks=s['k'];levels=sorted(set(ks));assert len(levels)==2;lo,hi=map(f,[s['lo'],s['hi']]);cv=[f(x) for x in s['c']];d=levels[1]-levels[0];assert ks[v]-ks[u]==d and c['pairs'][a['pair']]['Psi']
  AA=sum(nu[i]*cv[i] for i in range(6) if ks[i]==levels[1]);BB=sum(nu[i]*cv[i] for i in range(6) if ks[i]==levels[0]);z0=lo**(-d);z1=hi**(-d)
  val=cv[v]*cv[u]*(z0-z1)/((AA*z0+BB)*(AA*z1+BB));total+=rho[v]*nu[v]*nu[u]*val
  pieces.append(dict(pair=a['pair'],segment=a['segment'],integral=pack(val)))
 val=p*m/q*total;reference=f(rec['objective_F']);err=abs(val-reference)/val;assert err<F(1,10**100)
 res.append(dict(case=cid,node=rec['node_id'],exact_objective=pack(val),relative_difference=pack(err),relative_difference_display=float(err),pieces=pieces,passed=True))
out=dict(passed=True,cases=res,scope='exact rational saved coefficients only; not transcendental kernels',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),protocol_sha256=hashlib.sha256((b/'time_algebra.md').read_bytes()).hexdigest())
path=b/'time_exact_check.json';assert not path.exists();path.write_text(json.dumps(out,indent=2));print([(r['case'],r['relative_difference_display']) for r in res])
