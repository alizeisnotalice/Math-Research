import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=70
root=Path(__file__).resolve().parent;p=root/'numeric_receiver.json';d=json.loads(p.read_text());out=[]
for cid,c in d['cases'].items():
 for dist,sts in c['statistics'].items():
  for target,s in sts.items():
   N=s['N'];k=s['definite_positive'];ku=s['positive_plus_numerical_uncertain'];alpha=mp.mpf('.05')/24
   lo,hi=map(lambda v:mp.mpf(str(v)),s['CP_interval']);errors=[]
   if k:errors.append(abs(mp.betainc(k,N-k+1,0,lo,regularized=True)-alpha/2))
   if ku<N:errors.append(abs(mp.betainc(ku+1,N-ku,0,hi,regularized=True)-(1-alpha/2)))
   err=max(errors,default=mp.mpf(0));assert err<mp.mpf('1e-12')
   rows=[r for r in c['records'] if r['distribution']==dist]
   assert len(rows)==1152
   assert all(not r['uncertain'] for r in rows)
   assert sum(r['traffic']['positive_'+('raw' if target=='raw' else 'CJ')] for r in rows)==k
   out.append(dict(case=cid,distribution=dist,target=target,N=N,positive=k,CP=s['CP_interval'],CP_cdf_max_abs_residual=mp.nstr(err,20),empirical_integral=[s['integral_empirical_lower'],s['integral_empirical_upper']],Hoeffding=s['Hoeffding_interval']))
res={'receiver_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checks':out,'status':'PASS CP endpoints checked independently using mpmath regularized beta at 70 digits; no resampling. This verifies arithmetic, not exact classification.'}
(root/'receiver_statistics_check.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n');print(json.dumps(res,ensure_ascii=False,indent=2))
