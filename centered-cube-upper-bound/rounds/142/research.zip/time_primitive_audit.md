# Finite-interval time primitive audit

Scope: \(A,B,C\in\mathbb Q_{>0}\), \(0<u_0<u_1\), \(P(u)=A+Bu+Cu^2\), and the three integrals

\[
J_0=\int_{u_0}^{u_1}\frac{du}{P(u)^2},\qquad
J_{2u}=\int_{u_0}^{u_1}\frac{2u\,du}{P(u)^2},\qquad
J_{u^2}=\int_{u_0}^{u_1}\frac{u^2\,du}{P(u)^2}.
\]

**Conclusion:** All three proposed primitives for nonzero discriminant are correct. The logarithmic branch is real and smooth throughout the specified positive interval. The formulas below supply a finite-interval analytic oracle, including the exact repeated-root case. They do not prove any general source-payment statement or certify floating-point error.

## 1. Nonzero discriminant: direct derivative proof

Set \(\Delta=4AC-B^2\), \(x(u)=P'(u)=B+2Cu\), and choose \(H\) with \(H'=1/P\). The algebraic identity

\[
4CP-x^2=\Delta
\]

gives

\[
\frac{d}{du}\left(2CH+\frac{x}{P}\right)
=\frac{2C}{P}+\frac{2CP-x^2}{P^2}
=\frac{\Delta}{P^2}.
\]

Thus, when \(\Delta\ne0\), valid primitives are

\[
I_0=\frac{2CH+x/P}{\Delta},\qquad
I_{2u}=-\frac1{CP}-\frac BC I_0,\qquad
I_{u^2}=\frac AC I_0-\frac{u}{CP}.
\]

Indeed,

\[
I_{2u}'=\frac{x-B}{CP^2}=\frac{2u}{P^2},
\qquad
I_{u^2}'=\frac{A-(P-ux)}{CP^2}=\frac{u^2}{P^2}.
\]

The requested integrals equal the endpoint differences of these primitives.

## 2. Branches and domain

For \(\Delta>0\), writing \(d=\sqrt\Delta\),

\[
H(u)=\frac2d\arctan\frac{x(u)}d
\]

has derivative \(4C/(d^2+x^2)=1/P\). The usual real principal arctangent is sufficient: \(x(u)>0\), so there is no branch crossing.

For \(\Delta<0\), writing \(s=\sqrt{-\Delta}\),

\[
H(u)=\frac1s\log\frac{x(u)-s}{x(u)+s}
\]

has derivative \(4C/(x^2-s^2)=1/P\). Since

\[
s^2=B^2-4AC<B^2,\qquad 0<s<B<x(u),
\]

both numerator and denominator of the logarithm argument are strictly positive. The ratio lies in \((0,1)\); its real logarithm is negative, while \(H'\) is positive. Absolute-value notation or complex branches are unnecessary on this domain.

## 3. Evaluate interval differences directly

Let \(h=u_1-u_0>0\), \(x_j=B+2Cu_j\), \(P_j=P(u_j)\), and \(D_H=H(u_1)-H(u_0)\). Avoid subtracting two nearly equal transcendental values by using

\[
D_H=\frac2{\sqrt\Delta}\arctan
\left(\frac{2Ch\sqrt\Delta}{\Delta+x_0x_1}\right),
\qquad \Delta>0.
\]

This uses the arctangent subtraction identity without a missing multiple of \(\pi\): both original angles lie in \((0,\pi/2)\), their difference lies in \((0,\pi/2)\), and the displayed denominator is positive.

For \(\Delta<0\), use

\[
D_H=\frac1s\log\left(1+
\frac{4Csh}{(x_1+s)(x_0-s)}\right).
\]

This follows by combining the two logarithms into one ratio. The added quantity is positive. A numerical `log1p` evaluation preserves small increments better than computing the ratio first and then taking its logarithm. When \(x_0-s\) is small, the equivalent identity

\[
x_0-s=\frac{4CP_0}{x_0+s}
\]

avoids a subtractive loss in that denominator; equivalently, the `log1p` argument increment is \(sh(x_0+s)/[(x_1+s)P_0]\).

The finite integrals can then be written as

\[
J_0=\frac{2CD_H+D_Q}{\Delta},
\]

\[
D_Q=\frac{x_1}{P_1}-\frac{x_0}{P_0}
=\frac{h[2CA-B^2-BC(u_0+u_1)-2C^2u_0u_1]}{P_0P_1},
\]

\[
J_{2u}=\frac{h[B+C(u_0+u_1)]}{CP_0P_1}-\frac BC J_0,
\]

\[
J_{u^2}=\frac AC J_0-
\frac{h[A-Cu_0u_1]}{CP_0P_1}.
\]

These rational endpoint differences can be assembled exactly when the endpoints are rational. They also avoid subtracting almost equal endpoint fractions. The remaining subtraction in each complete expression can still be ill-conditioned.

## 4. Exact repeated-root case

When \(\Delta=0\), set \(r=B/(2C)>0\) and \(w=u+r\). Then \(A=Cr^2\) and \(P=Cw^2\). Separate valid primitives are

\[
I_0=-\frac1{3C^2w^3},
\]

\[
I_{2u}=-\frac1{C^2w^2}+\frac{2r}{3C^2w^3},
\]

\[
I_{u^2}=-\frac1{C^2w}+\frac r{C^2w^2}-\frac{r^2}{3C^2w^3}.
\]

Differentiating them yields respectively \(1/(C^2w^4)\), \(2(w-r)/(C^2w^4)\), and \((w-r)^2/(C^2w^4)\), exactly the three required integrands.

For particularly stable endpoint differences, put \(a=u_0\), \(b=u_1\), \(w_0=a+r\), \(w_1=b+r\), and \(D=3C^2w_0^3w_1^3\). Their differences factor into positive quantities:

\[
J_0=\frac{h(w_0^2+w_0w_1+w_1^2)}D,
\]

\[
J_{2u}=\frac{h\{3r^2(a+b)+r(a^2+10ab+b^2)+3ab(a+b)\}}D,
\]

\[
J_{u^2}=\frac{h\{r^2(a^2+ab+b^2)+3rab(a+b)+3a^2b^2\}}D.
\]

With rational endpoints these are exact rational values, without transcendental evaluation or cancellation between signed terms.

## 5. Precision recommendation and limits

Determine the sign of \(\Delta\) by exact rational arithmetic. Do not classify a small nonzero value as zero using a floating-point tolerance. Use the separate repeated-root expressions only for exact zero.

For nonzero \(\Delta\), evaluate the direct interval formulas above at arbitrary precision. In particular, \(2CD_H+D_Q\) cancels strongly as \(\Delta\to0\), so the direct difference formula for \(H\) does **not** by itself make the subsequent \(J_0\) calculation well-conditioned. The formulas for \(J_{2u}\) and \(J_{u^2}\) can also cancel, especially when the positive interval lies close to zero. Increase working precision with guard digits to resolve those subtractions; cancellation can be monitored by comparing term magnitudes with the resulting integral magnitude.

Recompute at successively higher precision until the requested reported digits agree, and check that all three interval values are positive. Such agreement is useful numerical evidence, **not** a certified enclosure or a rigorous absolute/relative error bound. Interval arithmetic with outward rounding would be needed for a numerical error certificate. No numerical quadrature is required by this finite-interval analytic oracle.
