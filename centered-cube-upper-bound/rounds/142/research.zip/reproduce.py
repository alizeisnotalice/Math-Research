#!/usr/bin/env python3
"""Portable replay into a new empty directory; original artifacts stay untouched."""
import argparse,hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--mode',choices=['checks','probe'],default='checks');args=p.parse_args()
source=Path(__file__).resolve().parent;work=args.work.resolve()
if work.exists() and any(work.iterdir()):raise SystemExit('Use a new empty --work directory')
work.mkdir(parents=True,exist_ok=True);dst=work/'centered_cube_round142_20261015';dst.mkdir()
for path in source.iterdir():
 if path.is_file() and path.suffix in ['.py','.md','.tex']:shutil.copy2(path,dst/path.name)
for rnd,filename,expected in [(136,'active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'),(141,'numeric_joint.json','acafcde85224fc1e5e2e9663f00e5233ead8daa8adb0d7382ce3436bb0b7618b')]:
 archive=args.repo/'centered-cube-upper-bound'/'rounds'/str(139 if rnd==136 else rnd)/'research.zip'
 with zipfile.ZipFile(archive) as z:
  names=[name for name in z.namelist() if Path(name).name==filename];assert len(names)==1,(archive,names);raw=z.read(names[0])
 assert hashlib.sha256(raw).hexdigest()==expected
 dep=work/('centered_cube_round136_20261014' if rnd==136 else 'centered_cube_round141_20261015');dep.mkdir();(dep/filename).write_bytes(raw)
if args.mode=='probe':
 # Only the replay copy is adapted to the caller's installed SciPy location.
 path=dst/'numeric_receiver.py';txt=path.read_text();txt=txt.replace("special_pkg.__path__=['/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/special']","special_pkg.__path__=[str(Path(scipy.__file__).resolve().parent/'special')]");path.write_text(txt)
 scripts=['numeric_receiver.py']
else:
 shutil.copy2(source/'numeric_receiver.json',dst/'numeric_receiver.json')
 scripts=['common_alpha_exact_check.py','time_exact_check.py','receiver_statistics_check.py','time_primitive_check.py']
for name in scripts:
 subprocess.run([sys.executable,str(dst/name)],check=True)
 if args.mode=='checks':
  output=Path(name).with_suffix('.json').name
  assert (dst/output).read_bytes()==(source/output).read_bytes(),output+' differs from stored check'
print(json.dumps({'mode':args.mode,'scripts':scripts,'output':str(dst),'result':'PASS'},ensure_ascii=False))
