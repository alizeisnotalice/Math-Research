#!/usr/bin/env python3
"""R142 bounded actual receiver probe. One producer; no mass optimization/kernel surrogate."""
import sys,json,hashlib,time,datetime,traceback,math
from pathlib import Path
from fractions import Fraction as Fr
from functools import lru_cache
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime')
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import numpy as np
# The installed scipy.special __init__ pulls an unrelated broken PROPACK binary.
# Load its genuine installed ufunc extension without that package initialization.
import scipy,types,importlib
special_pkg=types.ModuleType('scipy.special')
special_pkg.__path__=['/Users/zhengzhihao/Desktop/T/output/centered_cube_math_runtime/scipy/special']
sys.modules['scipy.special']=special_pkg
uf=importlib.import_module('scipy.special._ufuncs')
expn=uf.expn
class BetaQuantile:
 @staticmethod
 def ppf(p,a,b):return uf.betaincinv(a,b,p)
beta=BetaQuantile()
import mpmath as mp
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
JOINT=ROOT.parent/'centered_cube_round141_20261015/numeric_joint.json'
OUT=ROOT/'numeric_receiver.json'
IDS=['I1','I2','P1']; LIMIT=1024; call_count=0
EXPECTED={SRC:'1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de',JOINT:'acafcde85224fc1e5e2e9663f00e5233ead8daa8adb0d7382ce3436bb0b7618b'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def f(x):return Fr(str(x))
def jf(x):return Fr(int(x['numerator']),int(x['denominator']))
def fj(x):return dict(numerator=str(x.numerator),denominator=str(x.denominator))
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,Fr) else mp.mpf(x)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(x):OUT.write_text(json.dumps(x,ensure_ascii=False,separators=(',',':'),default=lambda z:z.item() if isinstance(z,np.generic) else z.tolist() if isinstance(z,np.ndarray) else str(z))+'\n')
def phi_np(x):
 r=np.abs(np.asarray(x));a=r<=.5;out=np.empty_like(r)
 out[a]=1-expn(3,.5-r[a])-expn(3,.5+r[a]);out[~a]=expn(3,r[~a]-.5)-expn(3,r[~a]+.5)
 return out
@lru_cache(maxsize=100000)
def phi_mp(r):
 r=abs(r);half=mp.mpf('.5');E=lambda x:mp.mpf('.5') if x==0 else mp.expint(3,x)
 return 1-E(half-r)-E(half+r) if r<=half else E(r-half)-E(r+half)
def kernel_np(s,H,d):return np.prod(((1-s)*(np.abs(d)<=H/2)+s*phi_np(d/H))/H,axis=-1)
def kernel_mp(s,H,d):return mp.fprod(((1-s)*(1 if abs(x)<=H/2 else 0)+s*phi_mp(x/H))/H for x in d)
def margin(a,b):return (a-b)/max(abs(a),abs(b),1e-300)
def relative(a,b):return abs(a-b)/max(abs(b),1e-300)
@lru_cache(None)
def gl_mp(n):return mp.gauss_quadrature(n,'legendre')
class Model:
 def __init__(self,c,rec,row):
  self.c=c;self.cid=c['id'];self.n=c['n'];self.at=c['atoms'];self.params={k:f(c['parameters'][k]) for k in ['s','L','K','D','B_FA','y','b']};self.der={k:f(c['derived'][k]) for k in ['Hhat','Lplus','T','g','tau','h','ell','cj']}
  nu=[f(a['nu']) for a in self.at[:4]];nu[int(row['source'][1:])-1]*=jf(row['multiplier']);m=jf(rec['mass_exact']);nu+=[1-sum(nu)-m,m];self.nuF=nu;self.nu=np.array(list(map(float,nu)))
  self.lambdaF=max(jf(row['affine_coefficients'][lab]['slope'])*m+jf(row['affine_coefficients'][lab]['intercept']) for lab in ['Q0','QJ','Qstar']);self.lam=float(self.lambdaF)
  self.posF=[[f(v) for v in a['position']] for a in self.at];self.pos=np.array([[float(v) for v in a] for a in self.posF]);self.A_F=[f(a['A']) for a in self.at];self.wgF=[f(a['wg']) for a in self.at];self.A=np.array(list(map(float,self.A_F)));self.wg=np.array(list(map(float,self.wgF)));self.egF=sum(nu[i]*self.wgF[i] for i in range(6));self.eg=float(self.egF)
  self.segs=[]
  for ss in c['score_segments']:
   lo,hi=f(ss['lo']),f(ss['hi']);ks=ss['k'];assert [sum(f(t)**2<lo*hi for t in a['thresholds']) for a in self.at]==ks
   coeff=list(map(f,ss['c']));levels=sorted(set(ks));groups={k:sum(nu[i]*coeff[i] for i in range(6) if ks[i]==k) for k in levels}
   self.segs.append(dict(loF=lo,hiF=hi,lo=float(lo),hi=float(hi),k=ks,cF=coeff,c=np.array(list(map(float,coeff))),levels=levels,groupF=groups,group={k:float(v) for k,v in groups.items()}))
  assert all(self.segs[i]['hiF']==self.segs[i+1]['loF'] for i in range(len(self.segs)-1))
  self.psi=np.zeros((6,6),dtype=bool)
  for i in range(6):
   for j in range(6):
    total=Fr(0);suffix=[total]
    for ss in reversed(self.segs):
     power=ss['k'][i]+ss['k'][j];delta=ss['k'][i]-ss['k'][j]
     total+=delta*ss['cF'][i]*ss['cF'][j]*(ss['loF']**(-power)-ss['hiF']**(-power))/power if power else Fr(0);suffix.append(total)
    self.psi[i,j]=max(suffix)>0;assert bool(self.psi[i,j])==c['pairs'][i*6+j]['Psi'] and not c['pairs'][i*6+j]['suffix_ambiguous']
  self.WF=self.der['ell']*self.der['cj']**(-self.n//2)*self.der['g']**self.n;self.W=float(self.WF)
  self.boundF=Fr(16,3)*self.n*(self.der['h']/self.der['tau']-1);self.bound=float(self.boundF);self.uniform_bound=float(self.boundF*self.params['L']**(-self.n))
  self.cache={};self.quad_records=[];self.gl={n:np.polynomial.legendre.leggauss(n) for n in [32,64,128]}
  assert self.der['Hhat']<self.der['Lplus'];assert min(nu)>0 and sum(nu)==1
  self.CJconst={}
  for H in [float(self.params['L']),float(self.der['Lplus'])]:self.CJconst[H]=((float(self.params['s'])*float(self.params['b'])/H)**self.n,1+(1-float(self.params['s']))/(float(self.params['s'])*float(phi_np(np.array([H/(2*float(self.params['b']))]))[0])))
 def scan(self,x):
  s,L,K,D,y,b=map(float,[self.params[z] for z in ['s','L','K','D','y','b']]);H,Lp,T=map(float,[self.der[z] for z in ['Hhat','Lplus','T']]);dx=x[:,None,:]-self.pos[None,:,:]
  p=kernel_np(s,L,x-y);k0=kernel_np(s,H,dx);k1=kernel_np(s,L,dx);k2=kernel_np(s,Lp,dx);J=kernel_np(1.,b,dx);Q=(k1+k2+J)/3
  qvals=np.stack([k0@self.nu,J@self.nu,Q@self.nu],axis=1);q=np.max(qvals,axis=1);qj=qvals[:,1]
  good=p[:,None]*self.wg[None,:]<=K*Q;E=good&(self.A[None,:]>0);U=np.where(E,np.minimum(T*self.A[None,:],D*k0),0.);alpha=(D*q-U@self.nu)/qj
  rho=np.where(E,np.maximum(1-(U+alpha[:,None]*J)/(T*np.where(self.A>0,self.A,1)),0),0)
  hard=np.all(np.abs(dx)<=.5,axis=2);hardmass=hard@self.nu
  CJ=np.ones_like(Q)
  for HH,(a,c) in self.CJconst.items():CJ+=a*c**np.sum(np.abs(dx)<=HH/2,axis=2)
  results=[]
  for r in range(len(x)):
   marg={'lambda_lower':margin(q[r],.75*self.lam),'lambda_upper':margin(self.lam,q[r]),'hard_cap':margin(4*self.lam,hardmass[r]),'high':margin(p[r]*self.eg,2*K*q[r]),'heavy':margin(self.eg,self.W*q[r]),'alpha':margin(D*q[r],float(U[r]@self.nu))}
   gates=dict(lambda_range=.75*self.lam<=q[r]<=self.lam,hard_cap=hardmass[r]<=4*self.lam,hard_positive=hardmass[r]>0,high=p[r]*self.eg>=2*K*q[r],heavy=self.eg>self.W*q[r],QJ_positive=qj[r]>0,alpha_nonnegative=alpha[r]>=0,FIRST_three=all(z<=q[r] for z in qvals[r]),remaining_branch=H<Lp)
   uncertain=[k for k,v in marg.items() if abs(v)<=1e-10]
   gm=[margin(K*Q[r,i],p[r]*self.wg[i]) for i in range(6)];uncertain += ['good:'+str(i) for i,v in enumerate(gm) if abs(v)<=1e-10]
   for i in range(6):
    if E[r,i]:
     rm=margin(T*self.A[i],U[r,i]+alpha[r]*J[r,i]);marg['rho:'+str(i)]=rm
     if abs(rm)<=1e-10:uncertain.append('rho:'+str(i))
     cm=margin(3.,CJ[r,i]);marg['CJ:'+str(i)]=cm
     if abs(cm)<=1e-10:uncertain.append('CJ:'+str(i))
   for name,HH in [('K0',H),('K1',L),('K2',Lp),('J',b),('hard',1.)]:
    if np.any(np.abs(np.abs(dx[r])-HH/2)/HH<=1e-10):uncertain.append('kernel_boundary:'+name)
   if np.any(np.abs(np.abs(x[r]-y)-L/2)/L<=1e-10):uncertain.append('p_boundary')
   if min(p[r],q[r],qj[r])<=0:uncertain.append('underflow_or_nonpositive_kernel')
   rec=dict(x=x[r].tolist(),p=float(p[r]),K0=k0[r].tolist(),K1=k1[r].tolist(),K2=k2[r].tolist(),J=J[r].tolist(),Q=Q[r].tolist(),q_tests=qvals[r].tolist(),q=float(q[r]),QJ=float(qj[r]),alpha=float(alpha[r]),good=good[r].tolist(),bad=(~good[r]).tolist(),E=E[r].tolist(),U=U[r].tolist(),rho=rho[r].tolist(),hard_sources=hard[r].tolist(),hardmass=float(hardmass[r]),CJ=CJ[r].tolist(),gates=gates,margins=marg,good_margins=gm,uncertain=sorted(set(uncertain)),precision='float64',all_good_CJ_le3=bool(np.all(CJ[r,good[r]]<=3)))
   results.append(rec)
  return results
 def prefix(self,ss,cap,precision):
  global call_count
  key=(next(i for i,s in enumerate(self.segs) if s is ss),mp.nstr(cap,70) if precision==70 else float(cap).hex(),precision)
  if key in self.cache:return self.cache[key]
  levels=ss['levels'];d=levels[1]-levels[0];assert len(levels)==3 and levels[2]-levels[1]==d
  if precision==64:
   u0=ss['lo']**d;u1=cap**d;A,B,C=[ss['group'][k] for k in reversed(levels)];out={};last=None
   for degree in [32,64,128]:
    if call_count>=LIMIT:self.cache[key]=(None,'integration_budget_exhausted');return self.cache[key]
    call_count+=1;xx,ww=self.gl[degree];us=(u1-u0)/2*xx+(u1+u0)/2;P=A+B*us+C*us*us;vals=(u1-u0)/2*np.array([np.dot(ww,1/P**2),np.dot(ww,2*us/P**2),np.dot(ww,us**2/P**2)])
    if last is not None:
     err=float(np.max(np.abs(vals-last)/np.maximum(np.abs(vals),1e-300)))
     if err<=1e-10:break
    last=vals
   self.quad_records.append(dict(cap=float(cap),precision='float64',degree=degree,relative_change=err,converged=err<=1e-10))
   res=(vals,None) if err<=1e-10 else (None,'GL_nonconvergence')
  else:
   u0=mm(ss['loF'])**d;u1=cap**d;A,B,C=[mm(ss['groupF'][k]) for k in reversed(levels)];last=None
   for degree in [64,128]:
    if call_count>=LIMIT:self.cache[key]=(None,'integration_budget_exhausted');return self.cache[key]
    call_count+=1;xx,ww=gl_mp(degree);mid=(u1+u0)/2;half=(u1-u0)/2;vals=[mp.mpf(0)]*3
    for node,weight in zip(xx,ww):
     u=mid+half*node;den=(A+B*u+C*u*u)**2
     for i,num in enumerate([mp.mpf(1),2*u,u*u]):vals[i]+=half*weight*num/den
    if last is not None:err=max(abs(vals[i]-last[i])/max(abs(vals[i]),mp.mpf('1e-1000')) for i in range(3))
    last=vals
   self.quad_records.append(dict(cap=mp.nstr(cap,70),precision='mp70',degree=128,relative_change=mp.nstr(err,70),converged=err<=mp.mpf('1e-40')));res=(vals,None) if err<=mp.mpf('1e-40') else (None,'GL70_nonconvergence')
  self.cache[key]=res;return res
 def traffic(self,rec,precision=64):
  usemp=precision==70;xp=mp if usemp else math;cv=lambda x:mm(x) if usemp else float(x);p=cv(rec['p']);Q=[cv(v) for v in rec['Q']];rho=[cv(v) for v in rec['rho']];nu=[mm(v) if usemp else float(v) for v in self.nuF];q=cv(rec['q']);hm=cv(rec['hardmass']);BFA=cv(self.params['B_FA']);target=[xp.mpf(0) if usemp else 0. for _ in range(2)];pairs=[xp.mpf(0) if usemp else 0. for _ in range(36)];caps=[];unknown=[];positive=[False,False]
  for si,ss in enumerate(self.segs):
   ks=ss['k'];lo=cv(ss['loF']);hi=cv(ss['hiF']);cs=[cv(v) for v in ss['cF']]
   for i in range(6):
    if not rec['good'][i] or rho[i]<=0:continue
    for j in range(6):
     delta=ks[i]-ks[j]
     if not rec['bad'][j] or delta<=0 or not self.psi[i,j]:continue
     logcut=(xp.log(BFA)+xp.log(delta)+xp.log(p)+xp.log(cs[i])-xp.log(Q[i]))/ks[i];loglo=xp.log(lo);loghi=xp.log(hi)
     if abs(logcut-loglo)<=(mp.mpf('1e-40') if usemp else 1e-10):rec['uncertain'].append('FA_entry:'+str(i)+':'+str(j))
     if logcut<=loglo:continue
     t1=hi if logcut>=loghi else xp.exp(logcut);positive[0]=True
     if cv(rec['CJ'][i])<=3:positive[1]=True
     caps.append(dict(segment=si,v=i,bad=j,lo=str(lo) if usemp else lo,hi=str(t1) if usemp else t1,delta=delta,CJ_pass=cv(rec['CJ'][i])<=3))
     # Entry uncertainty was checked before either branch.
     if len(ss['levels'])==2:
      d=ss['levels'][1]-ss['levels'][0];assert delta==d;A=cv(ss['groupF'][ss['levels'][1]]);B=cv(ss['groupF'][ss['levels'][0]]);z0=lo**(-d);z1=t1**(-d);diff=-z0*xp.expm1(-d*xp.log(t1/lo));val=cs[i]*cs[j]*diff/((A*z0+B)*(A*z1+B))
     elif len(ss['levels'])==3:
      values,err=self.prefix(ss,t1,precision)
      if err:unknown.append(err);continue
      ranks=(ss['levels'].index(ks[i]),ss['levels'].index(ks[j]));typ={(2,1):0,(2,0):1,(1,0):2}[ranks];val=cs[i]*cs[j]*values[typ]
     else:raise ArithmeticError('Positive delta with unsupported score structure')
     val*=rho[i]*nu[i]*nu[j];pairs[i*6+j]+=val;target[0]+=val
     if cv(rec['CJ'][i])<=3:target[1]+=val
  main=all(rec['gates'].values());old=all(rec['gates'][k] for k in ['hard_positive','high','heavy','QJ_positive','alpha_nonnegative','FIRST_three','remaining_branch']) and hm<=4*q
  hard=p*hm/q;out=dict(positive_raw=positive[0] and main,positive_CJ=positive[1] and main,FA_caps=caps,integral_failures=unknown,computed=not unknown,main_gates_pass=main,old_necessary_gates_pass=old)
  stringify=lambda v:mp.nstr(v,70) if usemp else float(v)
  out.update(internal=[stringify(v) for v in target],pair_contributions=[stringify(v) for v in pairs],F_raw=stringify(hard*target[0]) if main and not unknown else None if main and unknown else 0.,F_CJ=stringify(hard*target[1]) if main and not unknown else None if main and unknown else 0.,old_necessary_F=stringify(hard*target[0]) if old and not unknown else None if old and unknown else 0.,ungated_reference_F=stringify(hard*target[0]) if not unknown else None)
  return out
 def evaluate(self,rec):
  # All kernel/gate fields already evaluated. Avoid time integration only if both targets gate out.
  old=all(rec['gates'][k] for k in ['hard_positive','high','heavy','QJ_positive','alpha_nonnegative','FIRST_three','remaining_branch']) and rec['hardmass']<=4*rec['q']
  if not all(rec['gates'].values()) and not old:return dict(positive_raw=False,positive_CJ=False,FA_caps=[],integral_failures=[],computed=True,main_gates_pass=False,old_necessary_gates_pass=False,F_raw=0.,F_CJ=0.,old_necessary_F=0.,gate_shortcut=True)
  return self.traffic(rec)
 def mp_record(self,x):
  mp.mp.dps=70;phi_mp.cache_clear();xx=[mm(Fr.from_float(float(v))) for v in x];pos=[[mm(v) for v in a] for a in self.posF];s,L,K,D,y,b=[mm(self.params[k]) for k in ['s','L','K','D','y','b']];H,Lp,T=[mm(self.der[k]) for k in ['Hhat','Lplus','T']];nu=[mm(v) for v in self.nuF];A=[mm(v) for v in self.A_F];wg=[mm(v) for v in self.wgF];lam=mm(self.lambdaF);eg=mm(self.egF);dx=[[xx[k]-a[k] for k in range(self.n)] for a in pos];p=kernel_mp(s,L,[v-y for v in xx]);k0=[kernel_mp(s,H,d) for d in dx];k1=[kernel_mp(s,L,d) for d in dx];k2=[kernel_mp(s,Lp,d) for d in dx];J=[kernel_mp(mp.mpf(1),b,d) for d in dx];Q=[(k1[i]+k2[i]+J[i])/3 for i in range(6)];qv=[mp.fsum(nu[i]*v[i] for i in range(6)) for v in [k0,J,Q]];q=max(qv);qj=qv[1];good=[p*wg[i]<=K*Q[i] for i in range(6)];U=[min(T*A[i],D*k0[i]) if good[i] and A[i]>0 else mp.mpf(0) for i in range(6)];alpha=(D*q-mp.fsum(nu[i]*U[i] for i in range(6)))/qj;rho=[max(1-(U[i]+alpha*J[i])/(T*A[i]),mp.mpf(0)) if good[i] and A[i]>0 else mp.mpf(0) for i in range(6)];hard=[all(abs(v)<=mp.mpf('.5') for v in d) for d in dx];hm=mp.fsum(nu[i] for i in range(6) if hard[i]);CJ=[]
  for d in dx:
   cj=mp.mpf(1)
   for HH in [L,Lp]:cj+=(s*b/HH)**self.n*(1+(1-s)/(s*phi_mp(HH/(2*b))))**sum(abs(v)<=HH/2 for v in d)
   CJ.append(cj)
  ma=lambda a,b:(a-b)/max(abs(a),abs(b),mp.mpf('1e-1000'));marg={'lambda_lower':ma(q,mp.mpf('.75')*lam),'lambda_upper':ma(lam,q),'hard_cap':ma(4*lam,hm),'high':ma(p*eg,2*K*q),'heavy':ma(eg,mm(self.WF)*q),'alpha':ma(D*q,mp.fsum(nu[i]*U[i] for i in range(6)))}
  for i in range(6):
   marg['good:'+str(i)]=ma(K*Q[i],p*wg[i])
   if good[i] and A[i]>0:marg['rho:'+str(i)]=ma(T*A[i],U[i]+alpha*J[i]);marg['CJ:'+str(i)]=ma(mp.mpf(3),CJ[i])
  gates=dict(lambda_range=mp.mpf('.75')*lam<=q<=lam,hard_cap=hm<=4*lam,hard_positive=hm>0,high=p*eg>=2*K*q,heavy=eg>mm(self.WF)*q,QJ_positive=qj>0,alpha_nonnegative=alpha>=0,FIRST_three=all(v<=q for v in qv),remaining_branch=H<Lp)
  native=dict(p=p,Q=Q,q=q,rho=rho,good=good,bad=[not v for v in good],hardmass=hm,CJ=CJ,gates=gates,uncertain=[])
  tr=self.traffic(native,70)
  cv=lambda v:mp.nstr(v,70)
  out=dict(p=cv(p),K0=list(map(cv,k0)),K1=list(map(cv,k1)),K2=list(map(cv,k2)),J=list(map(cv,J)),Q=list(map(cv,Q)),q_tests=list(map(cv,qv)),q=cv(q),QJ=cv(qj),alpha=cv(alpha),good=good,U=list(map(cv,U)),rho=list(map(cv,rho)),hard_sources=hard,hardmass=cv(hm),CJ=list(map(cv,CJ)),gates={k:bool(v) for k,v in gates.items()},margins={k:cv(v) for k,v in marg.items()},uncertain=[k for k,v in marg.items() if abs(v)<=mp.mpf('1e-40')]+native['uncertain'],traffic=tr,precision='mp70')
  return out

def stats(records,model,dist):
 alpha=.05/24;N=len(records);bound=model.uniform_bound if dist=='uniform' else model.bound;result={}
 for label,flag,key in [('raw','positive_raw','F_raw'),('CJ','positive_CJ','F_CJ')]:
  definite=0;optimistic=0;lo=[];hi=[];descriptive=[]
  for r in records:
   tr=r.get('traffic',{});uncertain=bool(r['uncertain']);positive=tr.get(flag,False)
   # A failed base gate with a margin separated from zero is safely negative within the numerical model.
   failed=[k for k,v in r['gates'].items() if not v]
   certain_fail=any(k not in ['alpha_nonnegative','lambda_range'] and k not in r['uncertain'] for k in failed)
   if uncertain:optimistic+=1;lo.append(0.);hi.append(bound);continue
   if positive:definite+=1;optimistic+=1
   value=tr.get(key)
   if value is None:lo.append(0.);hi.append(bound);continue
   v=float(value)/(r['p'] if dist=='p' else 1.);lo.append(v);hi.append(v);descriptive.append(v)
  lower=0. if definite==0 else float(beta.ppf(alpha/2,definite,N-definite+1));upper=1. if optimistic==N else float(beta.ppf(1-alpha/2,optimistic+1,N-optimistic));radius=bound*math.sqrt(math.log(2/alpha)/(2*N));mlo=float(np.mean(lo));mhi=float(np.mean(hi))
  result[label]=dict(N=N,definite_positive=definite,positive_plus_numerical_uncertain=optimistic,CP_interval=[lower,upper],integral_empirical_lower=mlo,integral_empirical_upper=mhi,Hoeffding_interval=[max(0.,mlo-radius),min(bound,mhi+radius)],bound=bound,alpha=alpha,descriptive_mean=float(np.mean(descriptive)) if descriptive else None,descriptive_max=max(descriptive) if descriptive else None,assumptions='Ideal iid receivers, exact finite model and reliable numeric labels; no interval-kernel certification')
 return result

def main():
 if OUT.exists():raise SystemExit('Refuse second receiver producer')
 for p,h in EXPECTED.items():assert sha(p)==h
 src=json.loads(SRC.read_text());joint=json.loads(JOINT.read_text());sc={c['id']:c for c in src['cases']};models={};orig={}
 for cid in IDS:
  summ=joint['summary'][cid];rec=next(r for r in joint['verifications'] if r['node_id']==summ['best_verified_node_id']);row=next(r for r in joint['slices'] if r['id']==rec['slice']);models[cid]=Model(sc[cid],rec,row);orig[cid]=rec
 out=dict(status='running',run_count=1,started_utc=utc(),input_sha256={str(p):h for p,h in EXPECTED.items()},sha256={str(p):sha(p) for p in [Path(__file__),ROOT/'numeric_receiver_plan.md',ROOT/'time_algebra.md']},approved_changes='2 distributions, 128+1024 each, float64 E3, margin1e-10, max48 mp70, fixed lambda and CJ',scope='True receiver finite-source necessary model, not FULL/forest/dimension order',cases={},exceptions=[],quadrature_budget=LIMIT)
 for cid,m in models.items():out['cases'][cid]=dict(n=m.n,nu_exact=list(map(fj,m.nuF)),lambda_exact=fj(m.lambdaF),lambda_saved=float(m.lam),bound_G_exact=fj(m.boundF),static=dict(Hhat_less_Lplus=True,weights_et_independent_x=True,Psi_all36_rebuilt=True),records=[],verifications=[])
 out['startup_recovery']=json.loads((ROOT/'numeric_receiver_startup.json').read_text());out['attempt']=3;out['mathematical_execution_count']=2;out['iid_sampling_execution_count']=1;out['environment_loading']='Genuine scipy1.15.3 special._ufuncs expn/betaincinv loaded without unrelated special package init; no installed files modified';save(out);rng={(cid,dist):np.random.Generator(np.random.PCG64(142000+100*(IDS.index(cid)+1)+(1 if dist=='uniform' else 2))) for cid in IDS for dist in ['uniform','p']}
 def run_batch(cid,dist,stage,N):
  m=models[cid];g=rng.get((cid,dist));start=time.monotonic()
  if dist=='uniform':x=g.uniform(-.5,.5,size=(N,m.n));branches=None
  elif dist=='p':V=g.uniform(-.5,.5,size=(N,m.n));U=g.uniform(0,1,size=(N,m.n));lap=g.laplace(0,1,size=(N,m.n));branches=g.uniform(0,1,size=(N,m.n))<float(m.params['s']);x=float(m.params['y'])+float(m.params['L'])*(V+branches*np.sqrt(U)*lap)
  elif dist=='control':x=np.zeros((1,m.n));branches=None
  else:
   arr=[];H=float(m.der['Hhat']);axes=[0,m.n//2-1,m.n-1]
   for axis in axes:
    for sign in [-1,1]:
     for offset in [-1e-8,1e-8]:v=np.zeros(m.n);v[axis]=sign*(H/2+offset);arr.append(v)
   x=np.array(arr);branches=None
  records=m.scan(x);base=len(out['cases'][cid]['records'])
  for i,r in enumerate(records):
   r.update(id=base+i,distribution=dist,stage=stage)
   if branches is not None:r['soft_branches']=branches[i].tolist()
   try:r['traffic']=m.evaluate(r)
   except Exception:r['traffic']=dict(computed=False,F_raw=None,F_CJ=None,positive_raw=False,positive_CJ=False);r['exception']=traceback.format_exc();out['exceptions'].append(dict(case=cid,id=r['id'],traceback=r['exception']))
  out['cases'][cid]['records'].extend(records);out['cases'][cid]['quadrature_records']=m.quad_records;out['quadrature_calls']=call_count;save(out);print(cid,dist,stage,'N',len(records),'positive',sum(r['traffic']['positive_raw'] for r in records),'CJ',sum(r['traffic']['positive_CJ'] for r in records),'uncertain',sum(bool(r['uncertain']) for r in records),'elapsed',time.monotonic()-start,'quad_calls',call_count,flush=True)
 for cid in IDS:
  run_batch(cid,'control','control',1)
  for dist in ['uniform','p']:run_batch(cid,dist,'initial',128)
 for cid in IDS:run_batch(cid,'pressure','pressure',12)
 for cid in IDS:
  for dist in ['uniform','p']:run_batch(cid,dist,'expanded',1024)
 # Predefined up to16 unique high-precision receivers per case.
 for cid in IDS:
  row=out['cases'][cid];records=row['records'];m=models[cid];selected=[]
  def choose(ids):
   for i in ids:
    if i not in selected:selected.append(i)
  choose([r['id'] for r in records if r['distribution']=='control']);positive=[r for r in records if r['traffic'].get('F_raw') is not None and r['traffic'].get('F_raw',0)>0];choose([r['id'] for r in sorted(positive,key=lambda r:(-r['traffic']['F_raw'],r['id']))[:4]]);choose([r['id'] for r in sorted(records,key=lambda r:(min(abs(v) for v in r['margins'].values()),r['id']))[:4]]);choose([r['id'] for r in records if r['distribution']=='pressure'][:7]);assert len(selected)<=16
  for rid in selected:
   low=records[rid];start=time.monotonic()
   try:
    high=m.mp_record(low['x']);high['id']=rid;high['distribution']=low['distribution'];high['relative_errors']={k:float(abs(mm(f(high[k]))-mm(f(low[k])))/max(abs(mm(f(high[k]))),mp.mpf('1e-1000'))) for k in ['p','q','QJ','alpha','hardmass']};high['labels_agree']=high['good']==low['good'] and high['gates']==low['gates'];high['elapsed_seconds']=time.monotonic()-start
    row['verifications'].append(high)
   except Exception:row['verifications'].append(dict(id=rid,exception=traceback.format_exc()));out['exceptions'].append(dict(case=cid,id=rid,type='verification',traceback=traceback.format_exc()))
   row['quadrature_records']=m.quad_records;out['quadrature_calls']=call_count;save(out);print(cid,'mp70',rid,'elapsed',time.monotonic()-start,flush=True)
  control=row['verifications'][0];reference=orig[cid]['objective_F'];controlval=control.get('traffic',{}).get('ungated_reference_F');row['x0_recovery']=dict(old_R141_F=reference,new_ungated_F=controlval,relative_difference=mp.nstr(abs(mm(f(controlval))-mm(f(reference)))/abs(mm(f(reference))),70) if controlval is not None else None,fixed_lambda_gate_uncertainty=control.get('uncertain'),not_mass_certificate=True)
  row['statistics']={dist:stats([r for r in records if r['distribution']==dist],m,dist) for dist in ['uniform','p']};row['summary']=dict(total_receivers=len(records),positive_main=sum(r['traffic']['positive_raw'] for r in records if r['distribution'] in ['uniform','p']),positive_CJ=sum(r['traffic']['positive_CJ'] for r in records if r['distribution'] in ['uniform','p']),uncertain_receivers=sum(bool(r['uncertain']) for r in records),kernel_labels_changed=sum(r['good']!=[a['good'] for a in sc[cid]['atoms']] for r in records),not_global_or_FULL=True)
  save(out)
 out['status']='completed_with_exceptions' if out['exceptions'] else 'completed_finite_receiver_probe';out['finished_utc']=utc();out['summary']=dict(random_receivers=6912,pressure_receivers=36,controls=3,mp70_count=sum(len(c['verifications']) for c in out['cases'].values()),exception_count=len(out['exceptions']),quadrature_calls=call_count,quadrature_budget=LIMIT,FULL_certified=False,forest_certified=False);save(out);print('FINAL',out['summary'],flush=True)
if __name__=='__main__':main()
