#!/usr/bin/env python3
"""Post-probe closed-form arithmetic, no new sampling or quadrature.
Frozen float kernel/FA endpoints are inputs, not exact-kernel certification.
"""
import sys,json,hashlib
from pathlib import Path
from fractions import Fraction as F
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
root=Path(__file__).resolve().parent
src=root.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
data=root/'numeric_receiver.json'
d=json.loads(data.read_text()); orig=json.loads(src.read_text()); case=next(x for x in orig['cases'] if x['id']=='P1'); row=d['cases']['P1']
nu=[F(int(x['numerator']),int(x['denominator'])) for x in row['nu_exact']]
ss=case['score_segments'][0];ks=ss['k'];cf=list(map(F,ss['c']));lev=sorted(set(ks));power=lev[1]-lev[0]
A,B,C=[sum(nu[i]*cf[i] for i in range(6) if ks[i]==k) for k in reversed(lev)]
Delta=4*A*C-B*B
assert A>0 and B>0 and C>0 and lev==[0,power,2*power]
def m(x):
 x=x if isinstance(x,F) else F(str(x));return mp.mpf(x.numerator)/x.denominator
def primitive(u):
 aa,bb,cc=m(A),m(B),m(C);dd=m(Delta);P=aa+bb*u+cc*u*u;v=2*cc*u+bb
 if Delta==0:
  h=bb/(2*cc);z=u+h
  return [-1/(3*cc**2*z**3),(-1/z**2+2*h/(3*z**3))/cc**2,(-1/z+h/z**2-h*h/(3*z**3))/cc**2]
 if Delta>0:
  t=mp.sqrt(dd);H=2/t*mp.atan(v/t)
 else:
  t=mp.sqrt(-dd);assert v>t;H=mp.log((v-t)/(v+t))/t
 I0=(2*cc*H+v/P)/dd
 return [I0,-1/(cc*P)-bb/cc*I0,aa/cc*I0-u/(cc*P)]
cache={};checks=[]
def interval(lo,hi):
 key=(str(lo),str(hi))
 if key in cache:return cache[key]
 values=[]
 for prec in [100,160]:
  with mp.workdps(prec):
   l=primitive(m(lo)**power);r=primitive(m(hi)**power)
   values.append([mp.nstr(v-w,prec) for v,w in zip(r,l)])
 with mp.workdps(160):
  high=list(map(mp.mpf,values[1]));low=list(map(mp.mpf,values[0]));err=max(abs(v-w)/abs(v) for v,w in zip(high,low));assert all(x>0 for x in high);assert err<mp.mpf('1e-80')
  checks.append({'lo':str(lo),'hi':str(hi),'relative_change':mp.nstr(err,12)})
 cache[key]=values[1];return values[1]
results=[];max_gl=mp.mpf(0)
with mp.workdps(160):
 for r in row['records']:
  tr=r['traffic'];caps=tr.get('FA_caps',[])
  if not caps:continue
  vals=[mp.mpf(0),mp.mpf(0)]
  for cap in caps:
   assert cap['segment']==0
   v,u=cap['v'],cap['bad'];rank=(lev.index(ks[v]),lev.index(ks[u]));idx={(2,1):0,(2,0):1,(1,0):2}[rank]
   integ=mp.mpf(interval(cap['lo'],cap['hi'])[idx])*m(cf[v])*m(cf[u])*m(nu[v])*m(nu[u])*m(r['rho'][v])
   vals[0]+=integ
   if cap['CJ_pass']:vals[1]+=integ
  factor=m(r['p'])*m(r['hardmass'])/m(r['q']);Fs=[factor*v if tr['main_gates_pass'] else mp.mpf(0) for v in vals]
  errs=[]
  for v,key in zip(Fs,['F_raw','F_CJ']):
   old=tr[key]
   if old is not None and v:
    err=abs(m(old)-v)/abs(v);errs.append(mp.nstr(err,12));max_gl=max(max_gl,err);assert err<mp.mpf('1e-8')
  results.append({'id':r['id'],'distribution':r['distribution'],'main_gates_pass':tr['main_gates_pass'],'recovered_missing':tr['F_raw'] is None,'F_raw':mp.nstr(Fs[0],80),'F_CJ':mp.nstr(Fs[1],80),'relative_differences_vs_GL':errs})
 summary={}
 for dist in ['uniform','p']:
  stream=[r for r in row['records'] if r['distribution']==dist];by={r['id']:r for r in results};samples=[]
  for r in stream:
   v=mp.mpf(by[r['id']]['F_raw']) if r['id'] in by else mp.mpf(0)
   samples.append(v/m(r['p']) if dist=='p' else v)
  assert len(samples)==1152
  bound=m(d['cases']['P1']['statistics'][dist]['raw']['bound']);alpha=mp.mpf('.05')/24;radius=bound*mp.sqrt(mp.log(2/alpha)/(2*len(samples)));mean=mp.fsum(samples)/len(samples)
  summary[dist]={'N':len(samples),'empirical_integral_mean':mp.nstr(mean,50),'Hoeffding_interval':[mp.nstr(max(0,mean-radius),50),mp.nstr(min(bound,mean+radius),50)],'unknown_kernel_points':sum(bool(r['uncertain']) for r in stream),'max':mp.nstr(max(samples),50)}
 output={'source_sha':hashlib.sha256(src.read_bytes()).hexdigest(),'receiver_sha':hashlib.sha256(data.read_bytes()).hexdigest(),'scope':'Post-hoc closed-form check of stored float64 kernel values and FA endpoints. No new quadrature/sampling. Not exact-kernel or global certificate. Original budget-exhaustion report retained.','Delta_sign':(Delta>0)-(Delta<0),'unique_intervals':len(cache),'precision_digits':[100,160],'max_relative_difference_vs_original_GL':mp.nstr(max_gl,20),'recovered_missing_main_integrals':sum(r['recovered_missing'] for r in results),'checks':checks,'records':results,'statistics':summary}
 (root/'time_primitive_check.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in output.items() if k not in ['checks','records']},ensure_ascii=False,indent=2))
