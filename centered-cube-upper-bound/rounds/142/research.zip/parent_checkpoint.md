# R142 主代理检查点

R141提交aa5a027已核，专用clone开始时干净。上一轮属progress：新条件估计、数值decision evidence与独审均已提交。

主线：同时保留good门J(v)≥p wg(v)/K与正rho所需DK0(v)<TA(v)。对固定参数和来源，任意θ≥0、η≥0都有
1_good rho ≤ cθ (KJ/(p wg))^η (TA/(DK0))^θ,
cθ=θ^θ/(1+θ)^(1+θ)，θ=0取1。
证明是(1-r)+ r^θ≤cθ及good门上的倍率≥1；此处暂丢alphaJ仅作正上界。θ,η须共同选，真实x积分保留hard载体与全部source位移。对0≤η≤1可用p的正上包络；不能把下一步source/selector费用免费删除。作者在独立完成该几何合同及费用，主代理不重复登记一个固定参数恒等式为一般闭合。

有限必要模型的真实接收探路必须冻结λ_test=q(x0)，不可逐x取λ=q(x)。w_t/e_t/Π_t按RT4固定；实际核、finite q、所有good/bad/E/U/rho/FA/high/heavy、C_J<=3及hard支持随x重算。有限max三核不等于原FIRST，Z全六原子也不是原forest证书。

64工具H05已读SKILL、method、cube-interface及provenance开头；这里只用基础非负Chernoff乘积原理，不引用未读论文或对相关ν假设独立。其余来源无需重读。

短探路（不作为主成果）：尝试是否可免费使用φ(u)^r≤φ(ru)。35位mpmath、u=i/40 (0≤i≤400)、r=1.01,1.1,1.5,2,4,10；r=1.1,u=.5时log比约.00813029为正。因此没有采用该强型简化。未把有限网格当全域极值；不扩反例菜单。实际φ为h与Laplace尺度混合卷积；E3公式取自R135真核脚本。研究继续保留完整逐坐标比。

环境检查：bundled Python可用numpy，但import scipy失败；此为只读环境发现，不是数学程序失败。后续使用现成本机科学计算环境或单独仓库外依赖目录，不把依赖包提交。
