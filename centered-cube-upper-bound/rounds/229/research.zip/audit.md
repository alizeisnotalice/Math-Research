# R229 independent audit

## Initial screening — before reading R229 author drafts

Read `task_contract.md`, the frozen R228 audit and receiver-geometry statements, and the R225 scale-boundary section. This checkpoint does not re-prove those frozen results. No R229 author proof or numerical result was used to select the obligations below.

### Exact quantity and the two legal orders

The quantity to improve is the original positive traffic, before the hard-source capacity bound:

\[
2\Lambda\,\mathbb E\sum_{V,j}\int
 q^{-1}p_y(x)h_{R(x)}(x-z)\,a_\omega\rho_0(v)\,
 \mathbf1_{\rm actual}\,\delta_t(v,u)
 \Pi_{y,t}(dv)\Pi_{y,t}(du)\,dx\,\beta_V(dy)\nu_V(dz)\,d\log t.
\]

Here the actual indicator includes the original receiver domain, clock support, terminal good/bad, high, strong-capture, and history gates. Both normalized measures are retained: \(\Pi_{y,t}=\mathbf1_{Z_{y,t}}w_t(y,\cdot)\nu_V/e_t(y)\). In particular there is no replacement of the two \(e_t\) denominators by a source mass. The hard source \(z\) still has its own full \(\nu_V(dz)\) and physical \(h_R\).

On the original good branch, the three halfdensity legs give the coefficient \(2\Lambda\sqrt{K/3}\) and kernels
\[
 h_{R(x)}(x-z)\frac{\sqrt{p_y(x)K_{a,x}(v)}}{\sqrt{w_{g(x)}(y,v)}},
 \qquad a=1,2,J.
\]
No \(16/3\) has yet been used in this route. It is invalid to first pay that hard cap, and then use the same hard window again as an affinity gain. All three legs remain unless an already-qualified allocation or absorption explicitly removes one.

For fixed \((\omega,V,j,y,t,v,u,z)\), Tonelli permits integrating the **true \(dx\)** first. The exact required adaptive column is the integral over the original receiver domain of the displayed halfdensity kernel times **every** retained \(a_\omega,\rho_0\), history, capture, and clock indicator. At fixed \((j,y,t)\), the original \(\Pi\) and score are independent of \(x\); the physical \(L,R,s,g\), terminal sets and remaining gates are not. The R228 fixed-parameter product formula does not bound this adaptive column without an additional selector estimate.

Alternatively, the R227 pair theorem can be applied for each actual receiver row, using valid static envelopes for its two normalized source densities. The subsequent receiver integral then contains the product of those two envelope functions. This is a **weighted adaptive affinity**, not the unweighted fixed-parameter QG column. Moving these envelope factors outside \(dx\), or using a receiver-first bound that leaves an arbitrary time-dependent factor in the pair integral, needs its own uniform domination or weighted-variation theorem.

### What the capture and scale tools do permit

R228 gives a fixed \(Q_a(v)\) exclusion on \(H_0\ge a\), including the boundary; the lower-clamp branch instead has its qualified short-clock alternative. Neither fact grants a global \(Q_a\) exclusion. For fixed physical parameters and a fixed exclusion size, the capture-restricted integral is a **difference of two coordinate products**. Inserting \(\theta(x)\) or an adaptive exclusion size into that formula does not commute with the receiver integral.

A sufficient bridge would therefore be a proved bound on the actual weighted adaptive column above, or a measurable parameter covering/variation estimate whose overlap and selector cost are explicit and still integrable against the original \(\beta(dy)\nu(dz)\Pi\otimes\Pi\). A fixed-parameter \(L^1\) bound and a pointwise choice of its parameter are not such a bridge.

The R225 scale identity can be used with its terminal soft value frozen, retaining its actual bulk and shell terms. Its centered bulk moment is an unweighted, fixed-product statement. Applying it to a halfdensity, a moving hard window, or a moving capture exclusion requires the correct halfdensity jump amplitudes and all resulting hard/capture faces. Capture exclusion alone does not delete scale faces above the excluded core. A weighted integration-by-parts argument must account for derivatives or Stieltjes terms of the weights and gates, or avoid differentiating them by a justified positive domination.

### Source transposition and constants

Only the common \(\nu\otimes\nu\) part of \(\beta\otimes\nu\) is directly available for a two-source transposition; the positive excess \(\beta-\nu\) remains. Even on that common part the whole measure must transpose: the original likelihood/degree factors, the other \(\Pi\), high and history gates, capture center, and physical parameters. Clock detailed balance uses \(e_t\nu\), not a freely substituted stationary \(\beta\) or \(\nu\). Symmetry of a fixed geometric-mean kernel does not make the actual weighted positive traffic antisymmetric. The hard source \(z\) cannot be exchanged with an auxiliary source without restoring its different hard/capture role. Any signed cancellation must identify an unspent negative term under exactly the same carrier and gates.

The pair estimate contributes \(\sqrt{2nL_{\rm clk}}\), with the actual common log-window length \(L_{\rm clk}\le\log2\), and preserves both envelope masses. Thus a proposed selector constant is multiplied by \(2\Lambda\sqrt{K/3}\), and is squared by a subsequent Young inequality. For example, if a genuine joint bound had reduced the remaining source factor to \(C_{\rm sel}\sqrt{XW}\), the resulting Young source coefficient would be
\[
\frac{2\Lambda^2 K nL_{\rm clk}C_{\rm sel}^2}{3\epsilon}\,W.
\]
This conditional coefficient was checked with local exact rational arithmetic (16 parameter combinations); it asserts no such geometric/source bound. A root clock factor by itself therefore does not give a root source fee.

**Screening conclusion.** Receiver-first Tonelli and complete source transposition are legal with all original weights intact. The earliest missing estimate is a weighted adaptive receiver/source bridge, including selector and degree costs. No new original payment, general source cancellation, or arbitrary-positive-\(L^1\) root budget follows yet. Await the bounded author statements; retain the original branch partition and all previously charged errors.

## Independent screening of the proposed scale grid

Before reading `adaptive_geometry.md`, the proposed rounding has the following valid algebra. Put \(\gamma=1+1/n\), \(c=c_j\), \(M=\max(L,R)\), \(m=\min(L,R)\). The original band implies
\[
 c^2M/\gamma^2\le m\le c^2M.
\]
If \(M\le M_k\le\gamma M\), the proposed smaller node \(m_k=c^2M_k\) satisfies \(m\le m_k\le\gamma^3m\). Also \(m_k\ge c\sqrt{LR}\), so the node's product weight is no larger than the actual \(w_g\); its inverse square root is a legal positive upper bound. Radial decrease gives \(P_L\le(L'/L)^nP_{L'}\) when \(L'\ge L\), and the analogous hard-kernel comparison. If the third soft scale is simultaneously rounded upward with the appropriate ratio, the two orientations have squared comparison costs bounded by \(\gamma^{8n}\): the larger scale costs at most \(\gamma\), the smaller at most \(\gamma^3\), with the hard factor carrying full rather than half density. Thus an \(e^4\) total factor is algebraically possible. Local Fraction checks verified these band and squared-cost inequalities in 120 configurations; they do not certify node eligibility.

Since \(m\ge a\), actual admissible \(M\) obeys \(M\ge a/c^2\). An unrestricted geometric grid beginning there has
\[
\sum_k M_k^{-n}\le \frac{c^{2n}a^{-n}}{1-\gamma^{-n}}.
\]
This geometric sum itself needs no additional factor equal to the number of scale nodes. It retains its dimensional \(a^{-n}\) factor and has not yet been integrated against the original sources.

The full bridge still requires proof of the following qualifications. An independently adaptive third scale \(A\in[L,b]\) cannot silently become a fixed node; the actual three legs must supply a rounding rule, a covering cost, or a separately proved uniform column. A ceiling node can exceed \(b\), while its smaller partner can fall below \(b/2\). The frozen QG theorem assumes \(L,R\in[b/2,b]\), \(A\in[L,b]\), with the same reference \(b,C\); extending it to these nodes or changing reference scale needs an explicit proof and normalization comparison. Third-scale rounding must also maintain \(A'\ge L'\). The common-soft envelope pays one explicit \(N_n\) only for the actual shared soft parameter (the J leg has fixed soft 1); it cannot include other soft-dependent weights in its fixed coefficient. These issues are not disproved by the valid grid algebra, and are not settled by it.

## Author review: source transport

Read all of `source_transport.md`, SHA256 `74d24e570c320f2754ad3bf04291db3b9630260f9ab7a42644c3b4b5627be70f`. **Pass for its stated bounded identities and limitations.** This is a distinct legal exchange of hard \(z\) and auxiliary \(v\), both integrated against the same \(\nu\), keeping the anchor \(y\) and its \(e_t(y)\) fixed. It does not require \(\beta=\nu\). Its full transposition includes the posterior support, score, and the actual averaged history/capture field.

ST3 is the exact core/annulus decomposition when the common exclusion radius is independent of the exchanged slots. Capture then gives the ST4 nonnegative crossing identity, including its absolute-value equality. The direction is positive outward traffic; no original negative credit is generated. The qualification to \(H_0\ge a\) or the separately qualified hard-capture case is retained. ST5 follows from two product-difference estimates and the Lipschitz positive part; ST6 retains both posterior-support mismatch terms. Thus these formulas do not silently discard raw-weight, score, or gate costs.

ST7 correctly uses the current coupled \(\nu\le\beta\), same-receiver FIRST, and original high gate. ST8 restores the exact factor \(p_y e_t h_R/a_z\); consequently ST9 has \(\Gamma q\), with no extra surviving \(1/K\). The spatial ratios in ST10 and the unhandled hard-source portion outside \(Z_t\) remain explicit. Neither this replacement nor the commutator may additionally consume the original hard cap. The author's 4398 Fraction checks are reported finite algebra evidence, not independently archived FULL evidence. No new root payment is claimed or established.

## Local numerical certificate and smoothing checkpoint

Statically reviewed `numerical_probe.py` and its raw JSON, including the repaired negative-coefficient handling: only positive coefficients bound the candidate \(m_v\), but every constraint still enters the \(m_z\) bound and final same-data checks. The deterministic finite menu is not a global mass optimizer. The default extra source is \(10^{-10}\); the last \(n=512\) case instead uses the explicitly recorded positive \(10^{-300}\), and retains the previous failure diagnostic. Actual hard-source mass and its strict \(16q/3\) qualification are checked rather than inferred from a soft proxy. Ordinary 40/70-digit results are diagnostics, distinct from the following interval certificate.

Independently executed the final `interval_certificate.py` (SHA256 `58accff3bf2807306cc1662cf9a98b625d56016334f2e3dd9da99f63d2d61286`) using the local Python runtime with the vendor mpmath 1.3.0 path. It returned `N 256 PASS []`; the full output was byte-identical to `interval_certificate.json` (SHA256 `e66d6288c3b8bb71c8325391e3e7187ba03a487a7f32d199d57d2d6e3bed9eb6`). This is the updated \(n=512\) case with exact decimal/rational inputs, not the earlier \(n=64\) version.

Checked the enclosure logic independently. For each fixed spatial argument the inner kernel increases in \(r\), so the directed left/right rectangles enclose its integral. The trapezoid intersection uses \(|(r e^{-a/r})''|\le2/a\) for \(a>0\), with the \(a=0\) term linear, and \(|(r^2e^{-a/r})''|\le2\); summing the four C terms gives 8. The continuous endpoint at \(r=0\) and the \(M/(12N^2)\) error are valid. Monotone spatial endpoint evaluation, signed interval arithmetic, exact dyadic output, and directed decimal formatting retain enclosure direction. This certificate trusts the specified mpmath directed elementary arithmetic; token self-tests alone would not prove a generic interval API. Its strict local gate verdict is supported, while \(Z\), original history, cut/rank, source allocation and global budgets remain unverified.

The local smoothing argument in the parent draft is valid under its strict hard-face/score separation and positive-denominator assumptions. I requested that positivity of the integral additionally require a selected positive hard indicator and retained local multipliers; the parent inserted these hypotheses and I read the repair. Nonzero score alone would not suffice. Smooth common bumps preserve \(\nu\le\beta\); uniform local convergence preserves the finite strict gates and yields positive receiver/clock volume for that qualified local model. This supplies no original forest or history multiplier and no general input estimate.

Also statically reviewed `grid_checks.py`: its 61066 reported Fraction assertions test both orientations and the actual three node legs, including the truncated last node. This is a finite algebra check, not a proof of the adaptive kernel bridge. The general grid argument still awaits the author text. Numerical source/JSON bindings are respectively `56351146235878b5cbca676d709db58adaf27fa08d1b6e5481a1cc222a3166cc` and `2b757dfbbaa0be92b80f7b48a0492600ce378a03aed1d09de174229c910f867a`.

**Subsequent scope correction.** The preceding interval version certifies only its listed margins. The original separate FIRST condition \(J*\nu\le q\) is not implied by \(Q*\nu\le q\); the old point fails it. The parent/compare identified this extra gate and are preparing a repaired finite datum with that gate and \(\alpha_0\ge1\) explicitly checked. Therefore the old interval pass is not certification of all original local caps and must not be used as such. Its execution/hash record remains historical evidence of the specified computation. The smoothing theorem is conditional until the repaired complete local gate list is certified; FULL qualifications remain separate in every version.

## Author review: adaptive common-window bridge

Read all of `adaptive_geometry.md`, SHA256 `c79814192548d0854d6fc569f9158b0e5d4e56096d6ccd7a0ce6b2b49b9755f8`. **Pass for AG5/AG11 and the explicit unpaid interface AG13–14.** The text resolves the initial screening qualifications: it truncates the final grid point at \(b\), so both node scales lie in \([a,b]\subset[b/2,b]\), and uses the actual three deterministic leg formulas. The node for K2 is \(\min(b,\gamma L^*)\), whose scale ratio is at most \(L^*/L\); the J scale stays \(b\). Thus the QG hypotheses and the \(e^4\) pointwise domination are valid without a third-scale menu for these particular legs.

The selected fibers are positively covered by a finite sum. Only the pure kernel enters the common-soft menu; inherited fixed exclusion indicators stay independent of soft, and the other actual gates are dropped positively rather than recomputed. The two orientations, the possible truncated endpoint, the bound \(\sum(M^*)^{-n}\le3c_j^{2n}a^{-n}\), and the menu factor give exactly \(24e^4N_n\). The QG exponential can be bounded by \(E_a\), since \(m^*\ge a\). The stated free-third-scale and independent-soft extensions explicitly pay their extra menus.

AG4 correctly restricts \(Q_a\) inheritance to \(H_0\ge a\), and keeps the \(R\le L\) hard-capture exclusion in the other branch. Its node exclusion \(\max(a,R^*/\gamma^3)\) is no larger than the actual \(R\). AG9 is the difference of products in the same physical hard window; AG10 follows by multiplying the fixed full-affinity bound by the exact retained fraction. Empty exclusion is not treated as a closed singleton. No hard cap has been consumed.

AG13 is a legitimate receiver-first bound: the original two posterior densities and score are independent of receiver \(x\) at fixed \((j,y,t)\), and all receiver-dependent gates have been included in the quantity being bounded. The common clock carrier \([a/c_j,bc_j]\) contains the actual window because \(g\le bc_j\); masked inactive rows are zero. R227 then applies only with the displayed static envelopes, whose source masses are retained. AG14 consequently has the complete four-source measure, original \(q\), \(a^{-n}\), \(c_j^{2n}\), both envelopes and the three-leg sum. This is a genuine new adaptive kernel estimate, but does not establish the required weighted source/clock root budget. The remaining task is to integrate this more precise captured-window bound with the actual high/FIRST/source constraints; neither a unit envelope mass nor a unit \(\|\nu\|/(qa^n)\) has been assumed.

## Final repaired certificate and integration verdict — frozen

Independently executed the repaired three-variant interval verifier, version `8b9d443550508330759f3960d4ad2e979ed90f58cdd3f4939e224eab93bd6ab1`, obtaining a byte-identical complete JSON `45fa020bb7dc48aefffe50c8e492b989c53362aeed444852787d9bf7ae3935a3`. The original point definitely fails J/K0 capacities and \(\alpha_0\ge1\); the first repair \(m_v/4\) still fails K0 capacities; the final repair also takes \(m_z=10^{-150}\), and all 37 listed margins are strictly positive already at \(N=256\). I independently checked the added J/K0 capacities on both measures, \(\lambda=7q/6\), the common q interval, beta hard cap, heavy/high, clock and hard seams. The diagnostic K0 failure is real, rather than an accuracy issue. The final certificate explicitly limits itself to this finite gate list, and its local clock carrier is not an original forest construction.

The final verifier adds only `sqrt(4)` and `sqrt(2)^2` boundary self-tests (19 to 21). I statically checked these additions and compared the final JSON to my executed version: **all three variants, including every interval, are exactly unchanged**. The final metadata/self-test version was actually run by the author; I do not claim an additional independent full execution of that metadata version. Read the final `interval_notes.md`, including its corrected execution attribution and the explicit software trust boundary. These changes do not alter the accepted 37-gate result.

Read the complete final parent `proof.tex.txt` and `report.md`. Equations (229.1)–(229.4) faithfully integrate the accepted adaptive bridge, capture restrictions, original coefficient and remaining envelope/source costs. The smoothing theorem now has the necessary positive-hard and locally positive retained-multiplier hypotheses. Its application preserves only the explicitly listed local predicates; it does not supply continuum FIRST, Z/history, cut/rank or FULL. The very small repaired hard ratio and traffic proxy are stated accurately and are not interpreted as extremality or a global bound. All earlier failures are preserved and qualified.

Statically reviewed final `reproduce.py`: it copies the contract required by the exploration script, replays all three scripts into a fresh external directory, compares each **complete** JSON byte-for-byte, and verifies the manifest both before and after. The recorded mpmath version/environment is required. The parent's final relocated execution and manifest receipt occur after this audit freeze and are to be recorded separately; this audit does not pre-claim that run.

**Final verdict: pass for the bounded results and their stated scope; no outstanding requested repair.** R229 proves a new adaptive common-window receiver bound and a strict finite local model with a qualified smoothing realization. The weighted four-source/two-posterior budget and the arbitrary-positive-\(L^1\) global root target remain unpaid. No second hard cap or negative credit has been consumed. Audit writing stops here.

Final reviewed SHA256 bindings (not including this audit itself):

| File | SHA256 |
|---|---|
| task_contract.md | `f3136768c78b973a6d6b75a66189ceae487801c89afedb0e6805bc41349bd1da` |
| adaptive_geometry.md | `c79814192548d0854d6fc569f9158b0e5d4e56096d6ccd7a0ce6b2b49b9755f8` |
| source_transport.md | `74d24e570c320f2754ad3bf04291db3b9630260f9ab7a42644c3b4b5627be70f` |
| proof.tex.txt | `78f0f55012ec00b49144d2b7555a65ccc33fd9f83198a1b3a4cb6af9dbfe52cf` |
| report.md | `93a20d3fc78cfd17ef9525b67b4c315c67f011a3db86bd01ac35fb05dea282e9` |
| numeric_notes.md | `69376037d468a1b0a627945087753adcd495a073885f48414326d95df350ad6d` |
| numerical_probe.py | `56351146235878b5cbca676d709db58adaf27fa08d1b6e5481a1cc222a3166cc` |
| numerical_probe.json | `2b757dfbbaa0be92b80f7b48a0492600ce378a03aed1d09de174229c910f867a` |
| grid_checks.py | `f155298fef454ed0872a1cb74a342192ebfb1def4b047f9b88c40983fe8901f8` |
| grid_checks.json | `fee15cec367aef84c0e27b00964df881b132952a9b241f89338c5598366d5075` |
| interval_certificate.py | `dab9dab75449aed2c5735f51808658f68763374f8ba48da04ea85f2222cd18da` |
| interval_certificate.json | `6587c96431f61b62f3245c21339375bf887eed9f63903545e3afd9dc44ac9eb3` |
| interval_notes.md | `480a674bb511372904e00afd2730c6b9a096e1d5a40be25219d9171727b7449a` |
| reproduce.py | `95394778dde57a725d37812d9b41fe8fc69b1e4910a0685180c14e9da4311377` |
