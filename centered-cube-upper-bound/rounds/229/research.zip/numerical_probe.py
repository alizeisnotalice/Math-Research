#!/usr/bin/env python3
"""R229 finite same-nu hard/soft spatial feasibility, not FULL."""
import argparse,hashlib,json
from functools import lru_cache
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
K=mp.mpf(256);BETA0=mp.mpf('1e-10')
@lru_cache(maxsize=None)
def phi(x):
 x=abs(x);h=mp.mpf('.5')
 def E3(t):return h if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
 return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def primitive(x):
 sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
 return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
@lru_cache(maxsize=None)
def C(x):return primitive(mp.mpf('.5')-abs(x))-primitive(-mp.mpf('.5')-abs(x))
@lru_cache(maxsize=None)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def prod(v):return mp.fprod(v)
def calc(c,dps,fixed=None):
 with mp.workdps(dps):
  phi.cache_clear();C.cache_clear();fs.cache_clear()
  BETA0=mp.mpf(c.get('beta0','1e-10'))
  n=c['n'];s=mp.mpf(c['s']);xs=[mp.mpf(c['x'])]*n;vs=[mp.mpf(c['v'])]*n;us=[mp.mpf(c['u'])]*n
  if c['mode']=='two_block':vs=[mp.mpf('.65') if i%2 else mp.mpf('1.15') for i in range(n)];us=[mp.mpf('-.1') if i%2 else mp.mpf('-.4') for i in range(n)]
  zs=xs;p0=prod(fs(x,s) for x in xs)
  def kern(a,soft):return prod(fs(x-z,soft) for x,z in zip(xs,a))
  pv,pu,pz=[kern(a,s)/p0 for a in (vs,us,zs)];jv,ju,jz=[kern(a,mp.mpf(1))/p0 for a in (vs,us,zs)];qv,qu,qz=[(2*p+j)/3 for p,j in zip((pv,pu,pz),(jv,ju,jz))]
  alphas=[[C(z) for z in a] for a in (vs,us,zs)]
  def wt(i,t):return prod(min(1,a/t) for a in alphas[i])
  gv,gu,gz=[wt(i,mp.mpf(1)) for i in range(3)]
  t=mp.mpf('.5')*(1+mp.mpf(1)/(10*n));wv,wu,wz=[wt(i,t) for i in range(3)];kv,ku=[sum(a<t for a in alphas[i]) for i in (0,1)]
  good=K*qv-gv;bad=gu-K*qu;ell=1+mp.log(n);chi=1-s+s*phi(mp.mpf('.5'));H0=chi*ell**(mp.mpf(1)/(2*n));H=max(mp.mpf('.5'),min(1,H0));theta=chi*H/H0
  k0=prod(fs((x-v)/H,s)/theta for x,v in zip(xs,vs));D=wt(0,mp.mpf('.5'))-wt(0,mp.exp(-mp.mpf(1)/n))
  # Necessary linear region: A mv + B mz <= rhs, for each actual FIRST and high.
  lines=[(pv-gv/(2*K),pz-gz/(2*K),gu/(2*K)-pu-BETA0),(qv-gv/(2*K),qz-gz/(2*K),gu/(2*K)-qu)]
  out={'linear_mass_constraints':[{'mv_coefficient':aa,'mz_coefficient':bb,'rhs':rr} for aa,bb,rr in lines],'source_coordinates':{'x_all':c['x'],'z_equals_x':True,'v_pattern':(['.65' if i%2 else '1.15' for i in range(2)] if c['mode']=='two_block' else [c['v']]),'u_pattern':(['-.1' if i%2 else '-.4' for i in range(2)] if c['mode']=='two_block' else [c['u']]),'patterns_repeat_to_n':True},'normalized_spatial_kernels':{'P':[pv,pu,pz],'J':[jv,ju,jz],'Q':[qv,qu,qz]},'clock_t':t,'clock_window_end':mp.exp(-mp.mpf(1)/n),'clock_open_window_distances':[t-mp.mpf('.5'),mp.exp(-mp.mpf(1)/n)-t],'clock_weights_g':[gv,gu,gz],'clock_weights_at_t':[wv,wu,wz],'clock_threshold_min_distance_to_t':[min(abs(a-t) for a in aa) for aa in alphas],'hard_boundary_distances':{'p_y':min(abs(abs(x)-mp.mpf('.5')) for x in xs),'P_and_Q_v':min(abs(abs(x-v)-mp.mpf('.5')) for x,v in zip(xs,vs)),'P_and_Q_u':min(abs(abs(x-u)-mp.mpf('.5')) for x,u in zip(xs,us)),'P_and_Q_z':mp.mpf('.5'),'K0_v_in_scaled_coordinate':min(abs(abs((x-v)/H)-mp.mpf('.5')) for x,v in zip(xs,vs))},'k_v':kv,'k_u':ku,'ell':ell,'H0':H0,'Hhat':H,'theta':theta,'good_margin':good,'bad_margin':bad,'delta_score':kv-ku,'capture_Delta':D,'capture_K0_over_T':k0,'mass_trials':0,'beta0':BETA0,'mu':mp.mpf(1)}
  if good<=0 or bad<=0 or kv<=ku:return out
  # Positive mv coefficients bound mv; negative coefficients remain in every mz bound and final cap check.
  if not all(b>0 and r>0 for a,b,r in lines) or not any(a>0 for a,b,r in lines):
   out['obstruction']='nonpositive mz coefficient/rhs or no positive mv upper bound in this finite rule'
   ap,bp,rp=lines[0];aq,bq,rq=lines[1]
   if aq>0 and bq>=0 and rq>0 and bp>=0:
    mvbound=rq/aq;lower=min(mp.mpf(0),ap*mvbound)
    out['linear_elimination_check']={'mv_upper_from_Qcap_high':mvbound,'Pcap_high_lhs_lower_bound_for_nonnegative_masses':lower,'Pcap_high_required_rhs':rp,'necessary_lower_bound_minus_rhs':lower-rp,'incompatible_if_positive':lower>rp,'scope':'Ordinary high precision necessary halfspace elimination; not interval certificate.'}
   return out
  mvmax=min(r/a for a,b,r in lines if a>0);best=None;bestqualified=None;bestmargin=None
  for f in ([None] if fixed else (mp.mpf('.01'),mp.mpf('.1'),mp.mpf('.5'),mp.mpf('.9'))):
   mv=mp.mpf(fixed['mv']) if fixed else f*mvmax;mzmax=min((r-a*mv)/b for a,b,r in lines)
   lo0=max(mv*pv+pu+BETA0,mv*qv+qu)
   zchoices=[('linear_fraction_'+str(zf),zf*mzmax) for zf in (mp.mpf('.1'),mp.mpf('.5'),mp.mpf('.9'))]+[('hard_scaled_min_half_linear_and_8p0lo0_over_3',min(mzmax/2,mp.mpf(8)*p0*lo0/3))]
   if fixed:zchoices=[('fixed_positive_decimal',mp.mpf(fixed['mz']))]
   for zchoice,mz in zchoices:
    capP=mv*pv+pu+mz*pz+BETA0;capQ=mv*qv+qu+mz*qz;lo=max(capP,capQ);eg=mv*gv+gu+mz*gz;hi=eg/(2*K);q=mp.mpf(fixed['q'])/p0 if fixed else (lo+hi)/2
    jcap=mv*jv+ju+mz*jz;captureJ=q*p0*jv/jcap*mp.sqrt(ell);captureQ=qv;capgap=D-k0-captureJ-captureQ
    et=mv*wv+wu+mz*wz;Piv=mv*wv/et;Piu=wu/et;hard=mv*all(abs(x-v)<=mp.mpf('.5') for x,v in zip(xs,vs))+all(abs(x-u)<=mp.mpf('.5') for x,u in zip(xs,us))+mz
    obj=hard/q*(kv-ku)*Piv*Piu;qualified=hard<=16*q*p0/3
    row={'mv_fraction_of_linear_max':f,'mz_construction':zchoice,'mv':mv,'mz':mz,'q_over_p_y':q,'p_y':p0,'H_R':hard,'H_R_over_q':hard/(q*p0),'p_y_H_R_over_q':hard/q,'two_FIRST_margins_normalized':[q-capP,q-capQ],'high_margin_normalized':eg-2*K*q,'capture_J_over_T':captureJ,'capture_Q_over_r_p_y':captureQ,'capture_strict_margin':capgap,'capture_r_strict_lower_threshold':qv/(D-k0-captureJ) if D>k0+captureJ else None,'capture_r_dependence':'margin(r)=Delta-K0_over_T-J_over_T-Qv_over_p_y/r; other parameters fixed','r':1,'nu_total_mass':mv+1+mz,'q_over_nu_total_mass':q*p0/(mv+1+mz),'normalized_nu_masses':[mv/(mv+1+mz),1/(mv+1+mz),mz/(mv+1+mz)],'normalized_beta_extra_y0_mass':BETA0/(mv+1+mz),'normalized_H_R':hard/(mv+1+mz),'et':et,'eg':eg,'integral_Jnu':jcap*p0,'q':q*p0,'Pi_v':Piv,'Pi_u':Piu,'positive_clock_pair':(kv-ku)*Piv*Piu,'hard_weighted_positive_proxy':obj,'hard_qualification_H_le_16q_over_3':qualified,'hard_qualification_margin':16*q*p0/3-hard,'full_capture':capgap>0}
    out['mass_trials']+=1
    if bestmargin is None or capgap>bestmargin['capture_strict_margin']:bestmargin=row
    if row['full_capture'] and min(row['two_FIRST_margins_normalized'])>0 and row['high_margin_normalized']>0 and (best is None or obj>best['hard_weighted_positive_proxy']):best=row
    if row['full_capture'] and min(row['two_FIRST_margins_normalized'])>0 and row['high_margin_normalized']>0 and qualified and (bestqualified is None or obj>bestqualified['hard_weighted_positive_proxy']):bestqualified=row
  out['largest_capture_margin_trial']=bestmargin;out['best_full_capture']=best;out['best_full_capture_and_hard_qualified']=bestqualified
  return out
def menu():
 rows=[]
 for stage,n,mode,xxs,softs,vs,us in [('initial',16,'homogeneous',('0','.3'),('.05',),('.75','.9'),('-.25','.6')),('stress',64,'homogeneous',('.2','.3','.4'),('.05','.5'),('.9','1.15'),('-.25',)),('expanded',512,'two_block',('.2','.3','.4'),('.05',),('.9',),('-.25',))]:
  for x in xxs:
   for s in softs:
    for v in vs:
     for u in us:rows.append({'stage':stage,'n':n,'mode':mode,'x':x,'z_equals_x':True,'v':v,'u':u,'s':s})
 rows.append({'stage':'qualification_n512','beta0':'1e-300','n':512,'mode':'homogeneous','x':'.3','z_equals_x':True,'v':'1.15','u':'-.25','s':'.5'})
 return rows
def convert(x):
 if isinstance(x,mp.mpf):return mp.nstr(x,32)
 if isinstance(x,dict):return {k:convert(v) for k,v in x.items()}
 if isinstance(x,list):return [convert(v) for v in x]
 return x
def main(output):
 rows=[]
 for c in menu():
  r=calc(c,40);item={'configuration':c,'at_40dps':convert(r)}
  if c['stage']=='qualification_n512':
   item['at_70dps']=convert(calc(c,70));item['prior_beta0_1e_minus10_failure_at_70dps']=convert(calc({**c,'beta0':'1e-10'},70));item['verification']='Same successful n64 geometry raised to n512, strictly positive beta0=1e-300 and same finite mass rules, preserving prior 1e-10 failure; independent ordinary 40/70dps check, not interval certificate.'
   print('qualification_n512',item['at_70dps'].get('obstruction'),flush=True)
  if r.get('best_full_capture'):
   hi=calc(c,70);item['at_70dps']=convert(hi);item['verification']='Independent 40/70dps ordinary numerical recomputation; not interval certificate.'
   cert=hi.get('best_full_capture_and_hard_qualified')
   if cert:
    frozen={k:mp.nstr(cert[k],28) for k in ('mv','mz','q')};fr=calc(c,70,frozen);assert fr.get('best_full_capture_and_hard_qualified') is not None
    fr40=calc(c,40,frozen);assert fr40.get('best_full_capture_and_hard_qualified') is not None
    item['frozen_decimal_certificate_at_40dps']=convert(fr40)
    item['frozen_exact_decimal_parameters']=frozen;item['frozen_decimal_certificate_at_70dps']=convert(fr);item['frozen_certificate_scope']='Exact decimal masses/q held fixed for independent 70dps actual-kernel verification; still ordinary noninterval numerical evidence.'
   print(c,'feasible',mp.nstr(hi['best_full_capture']['hard_weighted_positive_proxy'],8),flush=True)
  rows.append(item)
 result={'schema':'R229_same_nu_three_source_positive_geometry_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'kernel_source':'Self-contained E3/E4 phi and C formulas adapted from R228 spatial_probe.py, sha256 6a2c845ce7fad400883d0902e99f68b30b472aad7e474cba058463fd862be523','parameters':{'K':256,'L':1,'R':1,'g':1,'cj':1,'b':1,'a':'.5','beta0_default':'1e-10, qualification_n512 override 1e-300','mu':1,'r':1,'y':'0 in all coordinates','z':'x in all coordinates','ell':'1+log(n)','Dcal':1,'nu':'mv delta_v + delta_u + mz delta_z','beta':'nu+beta0 delta_y','Q':'(2P_s+P_1)/3','objective':'p_y H_R/q * positive_delta Pi_v Pi_u, pointwise only'},'menu_count':len(rows),'results':rows,'scope':['Finite positive mass point sources, not positive L1 inputs or FULL histories.','Same nu supplies all soft caps, stationary-clock mass, and hard receiver kernel.','Full capture includes K0/T, normalized J traffic term and Qv/(r p_y), with r=1 explicitly.','Optimized mass is separately selected for each deterministic configuration, not shared across x.','Hard qualification H_R<=16q/3 is checked and reported, not silently assumed.','No Monte Carlo, no general dimension-order fit, no global payoff or theorem certification.','Ordinary mpmath refinement, not a rigorous interval certificate.']}
 output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'numerical_probe.json');main(ap.parse_args().output)
