# R229 独立 directed-interval 局部证书

**最终结果。** 同一n=512空间几何经两次明确、非搜索的质量修复后，37项明列有限局部门都有严格正区间余量。原冻结候选的J及K0容量失败被保留，不能把数值稿原来的“两FIRST”结果称为完整有限测试清单。这里不认证continuum FIRST、原Z/森林/cut/rank/失败币/后缀/捕获eligible或FULL，也不认证全局来源预算。点源本身不是正L1输入；将严格有限数据平滑所需的独立连续性论证归父级主证明，本证书不代替它。

只写 `interval_certificate.py/json` 与本notes，未改numeric作者文件或已冻结source_transport。使用[L03技能](/Users/zhengzhihao/.codex/skills/math-l03-rational-and-interval-certificates/SKILL.md)的方向/输入纪律；其API-01尚未认证通用区间库，本稿没有把技能当作mpmath正确性的授权。

## 1. 精确输入与三份清楚分开的结果

全部坐标逐维相同：n=512、s=1/2、y=0、x=z=3/10、v=23/20、u=−1/4。原L=R=g=cj=b=1、a=1/2、K=256、Dcal=1、r=1、t=5121/10240、h=exp(−1/512)、ell=1+log512。若把r与static预算关联，则ε_st=16Λ/(3Kr)=8/357，Λ=128/119。

原候选来源 `numerical_probe.json results[23].frozen_exact_decimal_parameters` 的读取快照SHA256为 `2b757dfbbaa0be92b80f7b48a0492600ce378a03aed1d09de174229c910f867a`；它不是验证器的运行依赖，参数在脚本中独立冻结。精确小数为

- mv_original=`3.560498595256761366308356235e240`；
- mz_original=`1.410608588519011261092226737e−108`；
- q=`5.583658996221086241823397501e−109`、beta0=`1e−300`，bad u质量为1。

三份数据都在JSON的variants中，用相同独立区间公式计算：

|版本|精确修复|区间结论|
|---|---|---|
|original_frozen_point|无|Jν>q、K0ν>q；相应β容量也失败，α0<1。不是区间精度不够。|
|first_repair_mv_quarter|mv=mv_original/4，其余不变|Jν≤q、α0≥1通过，但K0ν/K0β仍失败。|
|final_repair_mv_quarter_mz_1e-150|再取mz=精确1e−150|全部37项明列严格局部门通过。|

这两次确定修复由父级逐次授权；没有改坐标、q、beta0、s或物理参数，也没有再次优化搜索。最终

    mv=8.9012464881419034157708905875e239,
    mz=1e−150,
    ν=mv δv+δu+mz δz,  β=ν+beta0 δy。

原点的失败区间例如 `Jν∈[1.55337,1.62469]e−108`、`K0ν∈[7.35626,7.41954]e−84`，均大于q。后者来自 `K0_z∈[5.21495,5.25982]e24`，故单修mv无效。所有精确dyadic端点在JSON，本文短小数仅为包含更宽的展示。

## 2. 独立积分与解析余项

没有调用expint、普通浮点quad或numeric作者的φ/C函数。令E_a(r)=exp(−a/r)。对d≥0，φ(d)=∫₀¹F_d(r)dr，其中

\[
 F_d(r)=\begin{cases}
 r[2-E_{1/2+d}(r)-E_{1/2-d}(r)],&0\le d\le1/2,\\
 r[E_{d-1/2}(r)-E_{d+1/2}(r)],&d\ge1/2.
 \end{cases}
\]

F_d(0)=0，且由原积分 `∫_[−1/2,1/2]exp(−|d−z|/r)dz` 可见对r非负非减，所以精确等距左/右和分别给积分下/上界。

C(d)=∫_[−1/2,1/2]max(h,φ)(z−d)dz。d≤1时为 `1−d+∫_[1/2,d+1/2]φ(z)dz`，d≥1时为 `∫_[d−1/2,d+1/2]φ(z)dz`。设对应端点l,u≥1/2，其soft部分的r积分内函数为

\[
 G_{l,u}(r)=r^2[E_{l-1/2}-E_{l+1/2}-E_{u-1/2}+E_{u+1/2}].
\]

它等于正积分 `∫_l^u∫_[−1/2,1/2]exp(−|z−b|/r)db dz`，故同样非负非减且G(0)=0。

本次在同一个N网格上还计算复合梯形，以显式误差与单调Riemann界取交：

\[
 |\textstyle\int_0^1F-T_N(F)|\le {\sup|F''|\over12N^2}.
\]

这是逐格两次分部积分所得误差核 `(r−r_j)(r_{j+1}−r)/2` 的绝对积分相加。对a>0，

\[
 (rE_a)''=a^2r^{-3}e^{-a/r}\le2/a,
\]

因为 `max z³e^−z=27/e³<2`；a=0时rE₀=r二阶导为0。故φ的M可取其两个正指数参数的 `Σ2/a`。另一方面

\[
 (r^2E_a)''=e^{-z}(2+2z+z^2)\le2\quad(z=a/r\ge0),
\]

括号乘指数的导数为−z²e^−z，所以C四项合计M≤8，误差≤2/(3N²)。这些函数在r=0均有C²延拓；a>0指数平坦，a=0为多项式。所有M和网格是精确有理数。

φ、C均对d≥0非增。φ可由 `φ'=w(d+1/2)−w(d−1/2)≤0` 验证；C同理是even decreasing F与uniform h的卷积。因此可变Hhat产生的d区间，用φ/C在两个directed参数端点处的积分界再包围。hard核跳跃按closed core；JSON另认证全部用到的hard-seam距离为正。

## 3. 向外舍入实现与信任边界

实际软件为既有vendor的mpmath1.3.0，`mp.iv.prec=256` bits（报告为76 decimal digits）；Python Fraction只解析精确十进制/有理输入，绝无float→interval转换。每次内层exp/log、算术、integer power及sqrt均经iv计算。

已实际读取本机 `mpmath/libmp/libmpi.py`：mpi_add:64、sub:73、mul:131、div:214、exp:278、log:285、sqrt:292、pow_int:305。端点路径分别向mpf操作传 `round_floor`/`round_ceiling`；exp/log利用单调性，非负除法、乘方和sqrt用对应外舍入端点。脚本逐函数检查这两个round token，并在JSON保存函数源码hash、行号及以下模块hash：

- libmpi.py：`bb4239122c24a9afb8f9d5c44e2e64eccb9ac417996ef0803c5b65f7753d605d`；
- libmpf.py：`be93f490d56449c6c2568668809e166ad97823b09ed1de1dcc75637d57b9eeca`；
- libelefun.py：`8e80593f814e7713df89e5aca352cfb52afa747c9da46fcb42217f6d841858c8`。

有21项边界自检：精确大/小十进制和分数均被输入区间包含、exp(log2)、log(exp1)、sqrt4、sqrt2平方及四则/整数幂均含相应精确值。自检不是库的普遍正确性证明；本证书信任已定位版本libmp的directed elementary arithmetic实现，解析积分误差则由上节显式控制。不声称L03已经认证此API，也不声称这是由证明助手验证的整套软件。

JSON每个区间保存完整二进制dyadic元组 `[sign,mantissa,exponent,bitcount]`。人读decimal lower/upper用Decimal的ROUND_FLOOR/ROUND_CEILING以50有效位输出，保持方向，不拿nearest显示值判断符号。

## 4. 认证的有限测试清单及实际余量

K1=K2=P_s,1，本点没有另一条独立尺度腿。实际同时验证：

- 输入Pβ≤q；K1ν、K2ν≤q；Qν/Qβ≤q；Jν/Jβ≤q；K0ν/K0β≤q；α0=q/Jν>1。
- high p_y e_g>2Kq、heavy e_g>ell q、e_t>e_g；terminal-good v、terminal-bad u；kv=512、ku=0。
- Hν>0、Hν<16q/3。另取λ=7q/6，认证3λ/4<q<λ及Hβ<4λ。本几何Hν=mz、Hβ=mz+beta0。
- 完整capture `Δ>(K0v+(q/Jν)Jv)/T+Qv/p_y`，含原三来源计算的Jν、Δ、Hhat和T；r=1。
- 1−2^(−1/n)<s，H0在(a,b)内；t严格在(1/2,h)内；v/u/z阈值与t分离，输入及K0各source的hard-seam距离为正。

所有3个variant第一轮N=256已给明确结论，未继续扩大节点数。最终37项区间下界全部正，例如：

|余量|严格区间下界（向下放宽展示）|
|---|---:|
|q−Jν|1.52195e−109|
|q−K0ν|5.58365e−109|
|α0−1|.37470|
|p_y e_g−2Kq|1.13313e−107|
|KQv−p_y w_g(v)|3.72292e−347|
|p_y w_g(u)−KQu|2.97214e−106|
|完整capture差|6.47143e−274|

最终Hν/q在 `[1.79094,1.79095]e−42`，所以此次修复保留的是极小的正hard质量。点态 `p_y Hν/q·512Π_vΠ_u` 在 `[1.82152,1.97717]e−136`。正可行不代表最优、统一比例、receiver质量或全局预算；不得把这些数称为极值证书。

本证书检查的是上述有限列表，**没有**检查全连续FIRST参数族、原Z/partition、rank/cuts、ancestor dimensional gates、FULL/CP/GP/deep/失败币/历史、suffix/FA/eligible的构造。采用局部clock carrier=三个ν点全部存活，只是这个明确必要模型；不赋予它原森林资格。n=512只满足n≥512这一条维数下门。

## 5. 实际运行与独立路径重放

验证器自包含，只依赖已存在的mpmath1.3.0；默认输出同目录JSON，亦支持--output：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 interval_certificate.py --output /tmp/r229_interval_certificate.json
```

已将脚本复制到包外新临时目录，以--output实际完整运行，退出0；三个variant结论一致，完整JSON逐字节相同。最终输出168540 bytes；独立审查另对37门的19项自检版本（script 8b9d4435…，JSON 45fa020b…）实际重跑并逐字节一致。此后只新增sqrt4与sqrt2平方两条边界自检，解析kernel和37门区间未改；最终21项自检版由作者实际运行exit0。最终audit的复跑状态由审查者自行记录，本稿不冒称已重复其运行，未据此重跑numeric作者搜索。父级最终归档driver可复用这份短脚本独立验证；哈希以最终交付消息及JSON内script_sha256为准。
