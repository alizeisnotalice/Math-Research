#!/usr/bin/env python3
"""Exact rational tests of scale-node domination; no kernel or global-budget claim."""
import argparse,json,hashlib
from pathlib import Path
from fractions import Fraction as F

def run():
 checks=0;cases=[]
 for n in (2,16,64,512):
  gam=F(n+1,n);a=F(1,2);b=F(1)
  maxj=0
  while a*gam**(2*(maxj+1))<=b:maxj+=1
  for j in sorted(set((0,maxj//2,maxj))):
   c=gam**(-j);start=a/c**2;nodes=[start]
   while nodes[-1]<b:nodes.append(min(b,nodes[-1]*gam))
   samples=sorted(set(nodes+[(u+v)/2 for u,v in zip(nodes,nodes[1:])]))
   tested=0
   for M in samples:
    node=next(t for t in nodes if t>=M)
    for raw in (c*c*M/gam**2,c*c*M,(c*c*M/gam**2+c*c*M)/2):
     m=max(a,raw)
     if m>c*c*M:continue
     for L,R,Lp,Rp in ((M,m,node,c*c*node),(m,M,c*c*node,node)):
      assert a<=Lp<=b and a<=Rp<=b and Lp>=L and Rp>=R;checks+=1
      assert (Lp*Rp)>=L*R and min(Lp,Rp)**2==c*c*Lp*Rp;checks+=1
      for A,Ap in ((L,Lp),(min(b,gam*L),min(b,gam*Lp)),(b,b)):
       assert L<=A<=b and Lp<=Ap<=b and Ap>=A;checks+=1
       assert (Rp/R)**2*(Lp/L)*(Ap/A)<=gam**8;checks+=1;tested+=1
   assert 1/(1-gam**(-n))+1<=3;checks+=1
   cases.append({'n':n,'j':j,'nodes':len(nodes),'orientation_leg_tests':tested,'normalized_geometric_series_upper':'3'})
 return {'schema':'R229_exact_grid_v1','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':cases,'assertions':checks,'scope':'Exact rational scale/band/three-leg algebra; no soft-menu proof, kernel numerical quadrature, adaptive weighted source budget, or global closure.'}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();d=run();args.output.write_text(json.dumps(d,indent=2)+'\n');print(d['assertions'],'exact assertions')
