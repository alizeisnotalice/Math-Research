# R229：hard/auxiliary共同来源的窗口cross flux与转置价

**有限结论。** 在原hard帽以前，hard z和auxiliary good v确实都以同一ν积分，交换不改变anchor y及e_t(y)。它给下述精确共同窗口commutator；但原capture排核使其符号为**非负外流**，不是可免费扣除的边界信用。完整转置中的posterior支持、score、good/history及capture差必须支付。本稿没有得到新的原根阶付款，按任务限域在此停止，不以少数特殊来源或pureclock价替代原目标。

已读本轮task_contract及R228冻结[receiver_geometry.md RG1–15](/Users/zhengzhihao/Desktop/T/output/centered_cube_round228_20261016_final_checkpoint/receiver_geometry.md:1)、[audit.md §1/4](/Users/zhengzhihao/Desktop/T/output/centered_cube_round228_20261016_final_checkpoint/audit.md:7)。只改本文件，不Git/PDF/spawn。

## ST1 保原母式的交换槽

固定同一实际 `(ω,V,x,y,j,t)`，物理 `a≤L,R≤b≤2a`、s、g、h以及原唯一j、high和过程有效门都取原值，不按交换后的source重选。共同底测度为

\[
 {2\Lambda\over q}p_y(x)\,dx\,\beta_V(dy)
             \nu_V(dz)\nu_V(dv)\nu_V(du)\,{dt\over t}.
\]

hard帽尚未使用；hard因子是 `R(x)^−n 1_{Q_R(x)}(z)`。令

\[
 m_t(b)=1_{Z_{j,V,y,t}}(b)w_t(y,b),\quad
 d_t(b,u)=[k_t(y,b)-k_t(y,u)]_+,
\]

\[
 F_t(z,v,u)={m_t(v)m_t(u)\over e_t(y)^2}
                  G_t(z,v,u)d_t(v,u),\qquad0\le G_t\le1. \tag{ST1}
\]

G包含原RN aω(x,y,z)、target captureρ0、good(v)/bad(u)、FA/suffix补域、强capture-static补域及所有实际history和已付项后的补权。它可非对称、依hard z；这里不是把它当自由FULL门。若还有未积分的source-dependent条件history，须先按原核将其连同原门平均进这个G，再交换整个实际可测field；不能把某个固定z的条件history原样授给另一source。无效行直接置零。

交换z↔v时只有这两份同ν底测度可交换，**不需要β=ν**；β≥ν也不给额外价格。转置定义 `F_t^T(z,v,u)=F_t(v,z,u)`，必须同时将m_t(v)、score及G的全部source角色转置。anchor y不变，因此e_t(y)、另一份m_t(u)、p_y及物理参数不变。与R226的anchor y↔v交换不同，此处没有e_t(v)；不能反而新造它，也不能令hard z先继承Z_t或good资格。

原剩余positive在该行的hard/source积分正是

\[
 I_R=R^{-n}\iiint\chi_R(z)F_t(z,v,u)\,d\nu(z)d\nu(v)d\nu(u),\quad
 \chi_B(b)=1_{Q_B(x)}(b). \tag{ST2}
\]

最后按原共同底测度的其余x/y/t/种子求和；ST2未使用16/3或三腿半密度，无重复hard费用或负信用。

## ST2 共同排除窗口与精确外流身份

取一个在该实际x,y行固定、**不依被交换z/v**的A，满足 `0<A≤R` 且原positive target必排Q_A。实际有两种认证选择：

* R228 RG6的 `H0≥a` 支可取A=a（原a固定）；
* 原hard capture的 `R≤L` 支可取A=R(x)，即使R依x，逐x交换仍合法。

可在同时满足时取较大的这些共同尺寸。R228的A_cap(y,v)一般依v和Δ_yv，不能未经转换当作共同A。`H0<a,R>L`余支没有这里的固定Qa排除授权，不被ST2–4的结论覆盖。

原capture保证 `F_t(z,v,u)=0` 于χ_A(v)=1；这也可直接从ρ0正支持 `TΔ>B≥Dcal K0`、Dcal≥1、Δ≤1和R228 core下界核验。由同ν交换，

\[
\boxed{
 I_R= I_{ann}+{1\over2R^n}\iiint
 [\chi_A(z)-\chi_A(v)][F_t(z,v,u)-F_t(v,z,u)]\,d\nu^3,}
\tag{ST3}
\]

\[
 I_{ann}=R^{-n}\iiint[\chi_R(z)-\chi_A(z)]F_t(z,v,u)\,d\nu^3\ge0.
\]

**证明。** χ_A≤χ_R给hard core与annulus拆分。又因χ_A(v)F=0，core项为 `∫(χ_A(z)−χ_A(v))F/R^n`。将同一ν(z)ν(v)交换，取两式平均即ST3。无需对selector微分；对任意有限非负原截断先成立。A=R时annulus精确为零，但不因此消掉core。

父级要求核的单向符号是

\[
 [\chi_A(z)-\chi_A(v)](F_t-F_t^T)\ge0,
\]
\[
 I_R=I_{ann}+{1\over2R^n}\iiint
 |\chi_A(z)-\chi_A(v)|\,|F_t-F_t^T|\,d\nu^3. \tag{ST4}
\]

若z在core而v在外，capture使转置F_t^T=0，乘积就是原F_t；若v在core而z在外，则F_t=0，两个差同时反号。其余点窗口差为0。这说明capture gate差有确定符号，但方向是正外流：对core crossing而言取绝对值**恰是等式**，不是一种丢掉抵消的粗估计。原两source同ν没有提供反向负交通。

## ST3 真实权差可以分解，但capture差不能删除

设G=G_t(z,v,u)、G^T=G_t(v,z,u)，m_v=m_t(v)、m_z=m_t(z)。正部1-Lipschitz给 `|d_t(v,u)−d_t(z,u)|≤|k_t(y,v)−k_t(y,z)|`。因此逐点有完整误差界

\[
\begin{aligned}
 |F_t-F_t^T|\le {m_t(u)\over e_t(y)^2}\big\{
 &n|m_v-m_z|\\
 &+\min(m_v,m_z)[n|G-G^T|
      +\min(G,G^T)|k_t(y,v)-k_t(y,z)|]\big\}. \tag{ST5}
\end{aligned}
\]

证明两次用 `|ab−cd|≤|a−c|max(b,d)+min(a,c)|b−d|`，并用0≤d_t≤n。m差又精确分为

\[
 |m_v-m_z|=1_{Z_t}(v)1_{Z_t}(z)|w_v-w_z|
 +1_{Z_t}(v)1_{Z_t^c}(z)w_v
 +1_{Z_t}(z)1_{Z_t^c}(v)w_z. \tag{ST6}
\]

所以需要分别支付raw clock weight变化、原Z支持错配、score变化以及完整gate/history差。不能只保平滑w差：原hard z不保证属于Z_t，且core crossing上G^T因capture为零，而G可正。即使w_v=w_z、两个点都在Z_t、score相同，capture/history差仍可承载原全部crossing价。

把ST5代入ST4后，外系数仍是原 `2Λ/q`、p_y、R^−n、β及三份ν，时间e_t^−2原位；不能将这些误差任一个直接归一成1。若随后用R227 pair-envelope估score差，相关两source是原hard z与aux v，仍须它们同一masked normalizer的真实静态包络和两份source质量；hard role本无Z资格，须先按ST6分离。不能把已有pair引理变成free transport预算。

## ST4 实际回代的范围与最早缺项

ST3–6在真实x依参数下逐行成立，可按原nonnegative母式积分，故无需fixed-θ QG或selector菜单。但它们未给小价格：A<R时annulus本身仍需来源/receiver费；A=R时剩余commutator恰等于原正外流。原ν-only rank与共同cut约束可同时保在底测度上，却不把G−G^T变成有利负数。β−ν未被删，hard帽也未重复使用。

原未消费N_Zc/N_del是同一hard角色下的反向score母式；ST3只是hard/aux角色交换，没有产生一份可额外扣除的负信用。转置后capture被抑制的positive不能冒充原negative。欲匹配它们，仍须证明真实score/history、good资格及hard窗口的系数比较，不能凭ST4的正号授“outer−inner退款”。

因此这条独立路线的决定性结论是：共同窗口确给精确transport/commutator，但capture强排除本身使core通量朝不利的正方向，不能单靠对称source取消。当前最早未付项是ST5中捕获/联合history交换价（以及A<R的annulus），它保留原完整source/receiver权。没有证明其为εX+C√n polylog Wβ；不把该误差另命名成已付款，也不继续扩张条件任务。

## ST5 父级保FIRST的hard-to-posterior约束

父级提出的更强局部约束成立。写 `a_z=P_{s(x),L(x)}(x−z)`，只在同一原high及合法e_t行，当前同构造ν≤β与FIRST给

\[
 \int {a_z\over p_y w_t(y,z)}\Pi_{y,t}(dz)
 ={1\over p_y e_t(y)}\int_{Z_t(y)}a_z\nu(dz)
 \le{q\over p_y e_t(y)}
 \le{e_g(y)\over2K e_t(y)}\le{1\over2K}. \tag{ST7}
\]

实际w>0；零过程行先置零。去掉左边w分母的较弱版本也成立。这个形式可以保原hard-to-Π交换中的1/w，不能把它误说成无价ν≤Π。

但原hard来源只在Z上的部分有

\[
 h_R(x-z)1_{Z_t}(z)\nu(dz)
 =p_y e_t(y){h_R(x-z)\over a_z}
               {a_z\over p_yw_t(y,z)}\Pi_{y,t}(dz). \tag{ST8}
\]

因此若另有几何比值帽h_R/a_z≤Γ，直接用ST7的第一界只能得到

\[
 \int_{Z_t}h_R\,d\nu\le p_y e_t\Gamma\,{q\over p_y e_t}=\Gamma q.
 \tag{ST9}
\]

显式小因子1/K被前面的p_y e_t恢复，不能在ST9外再留一份1/K。它正是同一FIRST核对hard密度的点态支配，若采用则替代hard帽，不与16/3相乘。

真实hard窗内可由原fs径向非增取

\[
 \Gamma_{hard}(x)=(L/R)^n f_s(R/(2L))^{-n};\qquad
 \Gamma_{core}(x)=(L/R)^n f_s(A/(2L))^{-n}\quad(z\in Q_A(x)). \tag{ST10}
\]

原严格soft下分母正；研究hard边界时分母零就只给∞，不改变资格。一般这些比例可指数大，不能删去。ST7本身未控制这份空间比值或它在actual x中的来源价格。

此外原hard z不必在Z_t，ST8不覆盖hard来源的Z_t补集；该部分在ST6正是完整posterior支持错配。故父级约束是准确的共同FIRST形式，并保留了1/w的正确位置，但目前不足以支付ST3的全部crossflux/交换价。这里不新增含未付Γ的新付款门。

## ST6 实际有限核验

本机Python Fraction对4个source位置类别（两个core、一个annulus、一个R外），243组整数score配置及非对称gate、raw posterior零支持，实际核对ST3、ST4等式/非负方向及逐pair ST5。共4374项精确有理断言通过；另8组有理来源完成24项ST7–9强FIRST/换源系数/抵消核验，合计4398项通过。它是source交换/符号/误差的代数检查，不是空间FULL、capture可实现性或一般预算证书；一般身份由上文同测度交换证明。
