#!/usr/bin/env python3
"""Directed Riemann enclosures of one R229 local point; never FULL."""
import argparse
import hashlib
import inspect
import json
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import mpmath as mp
from mpmath.libmp import libmpi, libmpf, libelefun

HERE = Path(__file__).resolve().parent
PREC_BITS = 256
INPUT = {'n':512,'s':'1/2','x':'3/10','y':'0','v':'23/20','u':'-1/4',
         'mv':'3.560498595256761366308356235e240',
         'mz':'1.410608588519011261092226737e-108',
         'q':'5.583658996221086241823397501e-109','beta0':'1e-300',
         'mu':'1','K':'256','a':'1/2','b':'1','L':'1','R':'1','g':'1',
         'cj':'1','Dcal':'1','r':'1','t':'5121/10240','h':'exp(-1/n)',
         'nu':'mv delta_v + delta_u + mz delta_x',
         'beta':'nu + beta0 delta_0'}

def qiv(x):
    f = Fraction(str(x))
    return mp.iv.mpf(f.numerator)/mp.iv.mpf(f.denominator)

def frac(t):
    sign, man, exponent, bits = t
    if bits < 0: raise ValueError('Nonfinite interval endpoint')
    return Fraction((-1 if sign else 1)*man)*(Fraction(2)**exponent)

def point(t): return mp.iv.make_mpf((t,t))
def hull(lo,hi):
    assert frac(lo)<=frac(hi), 'Empty certified intersection'
    return mp.iv.make_mpf((lo,hi))
def positive(x): return frac(x._mpi_[0]) > 0
def nonnegative(x): return frac(x._mpi_[0]) >= 0

def record(x):
    lo,hi = x._mpi_
    def dec(t,mode):
        f=frac(t)
        with localcontext() as ctx:
            ctx.prec=50;ctx.rounding=mode
            return str(Decimal(f.numerator)/Decimal(f.denominator))
    return {'lower_dyadic':list(lo),'upper_dyadic':list(hi),
            'lower_decimal':dec(lo,ROUND_FLOOR),'upper_decimal':dec(hi,ROUND_CEILING)}

def riemann(integrand,N,second_derivative_bound):
    # Integrand is nonnegative increasing in r, with its continuous value 0 at r=0.
    lower=mp.iv.mpf(0);upper=mp.iv.mpf(0)
    for j in range(N+1):
        val=mp.iv.mpf(0) if j==0 else integrand(qiv(j)/N)
        if j<N: lower+=val
        if j>0: upper+=val
    lower/=N;upper/=N
    # Composite trapezoid is the average of these two sums. Its rigorous
    # error is sup|F''|/(12N^2); intersect with the monotone rectangle bounds.
    trapezoid=(lower+upper)/2
    error=qiv(second_derivative_bound)/(12*N*N)
    tl=(trapezoid-error)._mpi_[0];tu=(trapezoid+error)._mpi_[1]
    return hull(max(lower._mpi_[0],tl,mp.iv.mpf(0)._mpi_[0],key=frac),
                min(upper._mpi_[1],tu,key=frac))

@lru_cache(None)
def phi_point(d_tuple,N):
    d=point(d_tuple);half=qiv('1/2')
    if frac(d_tuple)<=Fraction(1,2):
        fn=lambda r:r*(2-mp.iv.exp(-(half+d)/r)-mp.iv.exp(-(half-d)/r))
    else:
        fn=lambda r:r*(mp.iv.exp(-(d-half)/r)-mp.iv.exp(-(d+half)/r))
    df=frac(d_tuple)
    aa=[Fraction(1,2)+df,Fraction(1,2)-df] if df<=Fraction(1,2) else [df-Fraction(1,2),df+Fraction(1,2)]
    M=sum((2/a for a in aa if a>0),Fraction(0))
    return riemann(fn,N,M)

def phi(d,N):
    # phi decreases on [0,infinity): freeze both directed argument endpoints.
    assert nonnegative(d)
    left=phi_point(d._mpi_[0],N);right=phi_point(d._mpi_[1],N)
    return hull(right._mpi_[0],left._mpi_[1])

@lru_cache(None)
def C_point(d_tuple,N):
    d=point(d_tuple);half=qiv('1/2')
    if frac(d_tuple)<=1:
        hard=1-d;lo=half;hi=d+half
    else:
        hard=qiv(0);lo=d-half;hi=d+half
    fn=lambda r:r*r*(mp.iv.exp(-(lo-half)/r)-mp.iv.exp(-(lo+half)/r)
                      -mp.iv.exp(-(hi-half)/r)+mp.iv.exp(-(hi+half)/r))
    return hard+riemann(fn,N,Fraction(8))

def C(d,N):
    assert nonnegative(d)
    left=C_point(d._mpi_[0],N);right=C_point(d._mpi_[1],N)
    return hull(right._mpi_[0],left._mpi_[1])

def absv(x):
    lo,hi=x._mpi_
    if frac(lo)>=0:return x
    if frac(hi)<=0:return -x
    return hull(qiv(0)._mpi_[0],max((-x)._mpi_[1],hi,key=frac))

def fs(d,s,N):
    d=absv(d);lo,hi=map(frac,d._mpi_)
    if hi<=Fraction(1,2):hard=qiv(1)
    elif lo>Fraction(1,2):hard=qiv(0)
    else:hard=hull(qiv(0)._mpi_[0],qiv(1)._mpi_[1])
    return (1-s)*hard+s*phi(d,N)

def clamp_weight(Cv,t):
    z=Cv/t;lo,hi=z._mpi_;one=qiv(1)._mpi_[0]
    return hull(min(lo,one,key=frac),min(hi,one,key=frac))

def arithmetic_selftests():
    tests={}
    def contains(z,f):return frac(z._mpi_[0])<=f<=frac(z._mpi_[1])
    for s in [INPUT[k] for k in ['s','x','y','v','u','mv','mz','q','beta0','t']]+['1/3','1/10']:
        assert contains(qiv(s),Fraction(s));tests['exact_input_'+s]=True
    assert contains(mp.iv.exp(mp.iv.log(qiv(2))),Fraction(2));tests['exp_log_2']=True
    assert contains(mp.iv.log(mp.iv.exp(qiv(1))),Fraction(1));tests['log_exp_1']=True
    assert contains(mp.iv.sqrt(qiv(4)),Fraction(2));tests['sqrt_4']=True
    assert contains(mp.iv.sqrt(qiv(2))**2,Fraction(2));tests['sqrt_2_square']=True
    assert contains(qiv('1/3')+qiv('1/7'),Fraction(10,21));tests['add']=True
    assert contains(qiv('1/3')-qiv('1/7'),Fraction(4,21));tests['subtract']=True
    assert contains(qiv('1/3')*qiv('1/7'),Fraction(1,21));tests['multiply']=True
    assert contains(qiv('1/3')/qiv('1/7'),Fraction(7,3));tests['divide']=True
    assert contains(qiv('2/3')**64,Fraction(2,3)**64);tests['integer_power']=True
    return tests

def rounding_provenance():
    names=['mpi_add','mpi_sub','mpi_mul','mpi_div','mpi_pow_int','mpi_exp','mpi_log','mpi_sqrt']
    functions={}
    for name in names:
        fn=getattr(libmpi,name);source=inspect.getsource(fn)
        assert 'round_floor' in source and 'round_ceiling' in source
        functions[name]={'module_file':Path(inspect.getsourcefile(fn)).name,
                         'first_line':inspect.getsourcelines(fn)[1],
                         'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
                         'floor_ceiling_tokens_checked':True}
    files={}
    for module in [libmpi,libmpf,libelefun]:
        p=Path(module.__file__);files[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
    return {'functions':functions,'module_sha256':files,
            'trust_boundary':'mpmath 1.3.0 directed libmp elementary arithmetic is trusted; no claim that L03 certified a generic API.'}

def calculate(N):
    n=INPUT['n'];s=qiv(INPUT['s']);x=qiv(INPUT['x']);v=qiv(INPUT['v']);u=qiv(INPUT['u']);z=x
    mv,mz,q,beta0,K=[qiv(INPUT[k]) for k in ['mv','mz','q','beta0','K']]
    ell=1+mp.iv.log(qiv(n));chi=1-s+s*phi(qiv('1/2'),N)
    H0=chi*mp.iv.exp(mp.iv.log(ell)/(2*n))
    assert frac(H0._mpi_[0])>Fraction(1,2) and frac(H0._mpi_[1])<1
    H=H0;T=1/mp.iv.sqrt(ell);h=mp.iv.exp(-qiv(1)/n);t=qiv(INPUT['t']);tau=qiv('1/2')
    coords={'v':v,'u':u,'z':z}
    P={b:fs(x-bb,s,N)**n for b,bb in coords.items()}
    J={b:phi(absv(x-bb),N)**n for b,bb in coords.items()}
    Q={b:(2*P[b]+J[b])/3 for b in coords}
    py=fs(x,s,N)**n
    masses={'v':mv,'u':qiv(1),'z':mz}
    capsP=sum((masses[b]*P[b] for b in coords),qiv(0))+beta0*py
    capsQ=sum((masses[b]*Q[b] for b in coords),qiv(0))
    Jy=phi(x,N)**n
    Jnu=sum((masses[b]*J[b] for b in coords),qiv(0))
    capsJbeta=Jnu+beta0*Jy
    capsQbeta=capsQ+beta0*(2*py+Jy)/3
    CC={b:C(absv(bb),N) for b,bb in coords.items()}
    wt=lambda b,tt:clamp_weight(CC[b],tt)**n
    wg={b:wt(b,qiv(1)) for b in coords};ww={b:wt(b,t) for b in coords}
    eg=sum((masses[b]*wg[b] for b in coords),qiv(0));et=sum((masses[b]*ww[b] for b in coords),qiv(0))
    Delta=wt('v',tau)-wt('v',h)
    arg=absv(x-v)/H
    K0map={b:(fs(absv(x-bb)/H,s,N)/H)**n for b,bb in coords.items()}
    K0=K0map['v'];capsK0=sum((masses[b]*K0map[b] for b in coords),qiv(0))
    capsK0beta=capsK0+beta0*(fs(x/H,s,N)/H)**n
    captureK=K0/T;captureJ=(q/Jnu)*J['v']/T;captureQ=Q['v']/py
    # exact rational source locations show only z belongs to the closed Q_1(x).
    HR=mz
    HRbeta=HR+beta0
    lam=qiv('7/6')*q
    margins={'FIRST_beta':q-capsP,'FIRST_Q_nu':q-capsQ,
             'FIRST_J_nu':q-Jnu,'FIRST_K0_nu':q-capsK0,
             'FIRST_K1_nu':q-(capsP-beta0*py),'FIRST_K2_nu_same_as_K1':q-(capsP-beta0*py),
             'FIRST_J_beta':q-capsJbeta,'FIRST_K0_beta':q-capsK0beta,'FIRST_Q_beta':q-capsQbeta,
             'alpha0_ge_1':q/Jnu-1,
             'high':py*eg-2*K*q,'terminal_good_v':K*Q['v']-py*wg['v'],
             'terminal_bad_u':py*wg['u']-K*Q['u'],
             'hard_positive':HR,'hard_cap':qiv('16/3')*q-HR,
             'hard_beta_at_lambda':4*lam-HRbeta,
             'common_q_lower':q-qiv('3/4')*lam,'common_q_upper':lam-q,
             'heavy':eg-ell*q,'et_ge_eg':et-eg,
             'capture_complete':Delta-captureK-captureJ-captureQ,
             'far_lower_t':t-tau,'far_upper_t':h-t,
             'strictsoft_lower':s-(1-mp.iv.exp(-mp.iv.log(qiv(2))/n)),
             'H0_ge_a':H0-qiv('1/2'),'H0_lt_b':1-H0,
             'score_threshold_v':t-CC['v'],'score_threshold_u':CC['u']-t,
             'score_threshold_z':CC['z']-t,
             'input_y_hard_seam':qiv('1/2')-x,
             'input_v_hard_seam':absv(x-v)-qiv('1/2'),
             'input_u_hard_seam':absv(x-u)-qiv('1/2'),
             'input_z_hard_seam':qiv('1/2'),
             'K0_y_hard_seam':qiv('1/2')-x/H,
             'K0_v_hard_seam':arg-qiv('1/2'),
             'K0_u_hard_seam':absv(x-u)/H-qiv('1/2'),
             'K0_z_hard_seam':qiv('1/2')}
    # Score count is exact if interval threshold signs separate.
    kv=n if positive(margins['score_threshold_v']) else None
    ku=0 if positive(margins['score_threshold_u']) else None
    Pi_v=mv*ww['v']/et;Pi_u=ww['u']/et
    values={'p_y':py,'caps_beta_P':capsP,'caps_nu_Q':capsQ,'Jnu':Jnu,'ell':ell,
            'chi':chi,'H0':H0,'Hhat':H,'T':T,'h':h,'t':t,'eg':eg,'et':et,
            'H_R':HR,'H_R_beta':HRbeta,'lambda':lam,'H_R_over_q':HR/q,'caps_nu_K0':capsK0,'K0_z':K0map['z'],'alpha0':q/Jnu,'Delta':Delta,'K0v_over_T':captureK,
            'alpha0_Jv_over_T':captureJ,'Qv_over_p_y':captureQ,
            'scaled_K0_argument':arg,'Pi_v':Pi_v,'Pi_u':Pi_u,
            'positive_clock_pair':n*Pi_v*Pi_u,
            'hard_weighted_point_proxy':py*HR/q*n*Pi_v*Pi_u}
    values.update({'P_'+b:P[b] for b in coords});values.update({'J_'+b:J[b] for b in coords})
    values.update({'Q_'+b:Q[b] for b in coords});values.update({'C_y'+b:CC[b] for b in coords})
    values.update({'w_g_'+b:wg[b] for b in coords});values.update({'w_t_'+b:ww[b] for b in coords})
    return {'N':N,'all_local_margins_strictly_positive':all(positive(m) for m in margins.values()),
            'margins':{k:record(v) for k,v in margins.items()},
            'margin_verdicts':{k:positive(v) for k,v in margins.items()},
            'definitely_failed_margins':[k for k,v in margins.items() if frac(v._mpi_[1])<0],
            'values':{k:record(v) for k,v in values.items()},'score_kv':kv,'score_ku':ku,
            'scope':'Directed enclosure of the explicitly listed finite local point gates. Local clock carrier includes all three nu sources; no original Z/history/cut/rank/FULL or receiver-volume certification.'}

def main(output):
    global INPUT
    mp.iv.prec=PREC_BITS
    prov=rounding_provenance();tests=arithmetic_selftests()
    original=INPUT.copy()
    with localcontext() as ctx:
        ctx.prec=100
        quarter_mv=str(Decimal(original['mv'])/4)
    variants=[('original_frozen_point',original),
              ('first_repair_mv_quarter',{**original,'mv':quarter_mv}),
              ('final_repair_mv_quarter_mz_1e-150',{**original,'mv':quarter_mv,'mz':'1e-150'})]
    results=[]
    for label,inputs in variants:
        INPUT=inputs;passes=[]
        for N in [256,1024,4096]:
            result=calculate(N);passes.append(result)
            print(label,'N',N,'PASS' if result['all_local_margins_strictly_positive'] else 'NOT_PASS',
                  [k for k,v in result['margin_verdicts'].items() if not v],flush=True)
            if result['all_local_margins_strictly_positive'] or result['definitely_failed_margins']:break
        results.append({'label':label,'inputs_exact':inputs,'passes':passes,
                        'certified_local_gates':passes[-1]['all_local_margins_strictly_positive']})
    data={'schema':'R229_monotone_directed_local_certificate_v2',
          'finite_gate_list':'Input P beta; K1=K2=P on nu; Q, J, K0 on nu and beta; alpha0>=1; high and heavy; e_t>=e_g; good v/bad u; H_R>0 and H_R cap; beta hard band at lambda=7q/6; common q range; strictsoft lower; interior H0 clipping; clock t interior and v/u score separation; hard-seam separation. Not continuum FIRST/history.',
          'input_origin':{'file':'numerical_probe.json','index':23,'field':'frozen_exact_decimal_parameters',
              'frozen_source_json_sha256':'2b757dfbbaa0be92b80f7b48a0492600ce378a03aed1d09de174229c910f867a'},
          'deterministic_repairs':'Parent authorized mv=original/4, then mz=exact 1e-150; q,beta0 and geometry unchanged. Not a numerical search.',
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'mpmath_version':mp.__version__,'precision_bits':mp.iv.prec,'precision_decimal_digits':mp.iv.dps,
          'rounding_provenance':prov,'arithmetic_boundary_selftests':tests,
          'integration_method':'Intersection of monotone left/right Riemann and composite trapezoid plus explicit |error|<=M/(12N^2). phi M=sum_{a>0}2/a, C M=8. Exact rational mesh in r, variable phi argument bounded by monotone directed endpoints. No expint or ordinary quadrature.',
          'variants':results,'certified_final_local_gates':results[-1]['certified_local_gates'],
          'scope':['Point sources only, not arbitrary positive L1/FULL.',
              'n=512 meets n>=512 only; all other inherited dimensional/history qualifications are unverified.',
              'Every listed finite local gate has a strict directed margin at the final repaired point.',
              'K1=K2=P_s,1 here. J and K0 caps checked for both nu and beta, in addition to Q and input FIRST.',
              'No claim of all unlisted kernels or the full continuum FIRST process.',
              'Local clock carrier is all three nu points; no construction of original Z/forest/cut/rank/history.',
              'All decimal inputs are exact rationals, never binary float inputs.',
              'Raw dyadic endpoints are exact; decimal endpoints use directed Decimal rounding.',
              'No general theorem, positive receiver volume, or uniform geometric/source budget certified.']}
    output.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'interval_certificate.json')
    main(ap.parse_args().output)
