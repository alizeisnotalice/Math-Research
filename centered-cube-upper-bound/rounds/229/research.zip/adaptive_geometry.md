# R229：原三测试腿的自适应共同窗口桥

**范围。** 本稿证明一条真正允许 `L=L(x),R=R(x),s=s(x)` 的接收积分界。固定原比例带 j 后，用向上节点覆盖原核，再以每节点的物理积分因子作几何级数求和；没有把固定参数 QG 直接用于 θ(x)。原三条测试腿的尺度选择不再另外乘 O(n) 个节点数，soft 仍明确支付已证 `4N_n=O(√n log(n+1))`。右侧保留 `a^{-n}c_j^{2n}`、真实 hard 来源、capture 的共同窗口差及原两后验费用。本稿**没有**证明这些来源/clock费用可由原 `W_β` 支付，也没有宣布一般 root 弱型闭合。

只使用 R220 `soft_envelope.md` 的已证公共菜单、R224 QG（κ=25/2^68）及 R228 `receiver_geometry.md` RG6、RG11、RG13–14。本稿不重新领取 hard cap、FA、浮动带或负信用。以下原共同分母是 q，不是三腿测试 Q。

## AG1 准确量词与原三腿

令 n≥2（原应用 n≥512），γ=1+1/n，0<a≤b≤2a。固定原 j≥0，记 c=c_j=γ^{-j}。固定 y,v,z∈R^n，定义

\[
 \alpha_i=bC(|y_i-v_i|/b),\quad
 \bar w_d(y,v)=\prod_{i=1}^n\min\{1,\alpha_i/d\},\quad
 E_d(y,v)=\exp\{-\tfrac\kappa2\sum_i(1-\min(1,\alpha_i/d))\}.
 \tag{AG1}
\]

原终端权为 `w_g=bar w_{cg}`。允许任意可测参数 L(x),R(x)∈[a,b]、s(x)∈[0,1]，满足原 band

\[
 g=\sqrt{LR},\quad m=\min(L,R),\quad M=\max(L,R),\qquad
 c/\gamma\le m/g\le c.
 \tag{AG2}
\]

原三腿分别是

\[
 (A_1,\sigma_1)=(L,s),\quad
 (A_2,\sigma_2)=(\min(b,\gamma L),s),\quad
 (A_3,\sigma_3)=(b,1).
 \tag{AG3}
\]

定义未使用 hard cap 的实际核

\[
 F_i(x)=
 {h_{R(x)}(x-z)\sqrt{P_{s(x),L(x)}(x-y)P_{\sigma_i(x),A_i(x)}(x-v)}
  \over\sqrt{\bar w_{c g(x)}(y,v)}}.
 \tag{AG4}
\]

允许再乘任意实际可测权 0≤χ(x)≤1；χ可以包含原 a_ω、ρ、history、high、terminal good/bad、far clock及当前剩余支指示。本定理从不在新节点上重算这些门。它们只留在原值，或作明确的非负上放。

**自适应积分定理。** 对每条原腿 i=1,2,3，

\[
 \boxed{\int \chi(x)F_i(x)\,dx
 \le 24e^4 N_n\,c^{2n}a^{-n}E_a(y,v),\qquad
 N_n\le8+4\sqrt n\log(n-1).}
 \tag{AG5}
\]

空 band 的左侧为零。AG8–11给比AG5更强、保共同 hard 源 z 和原捕获排除的有限积分表达。任意自由第三尺度 A(x)∈[L(x),b] 不属于AG3；它的额外费用在AG12列出。

## AG2 合法向上节点：上端截断及原 j 都保留

AG2等价于 `c²/γ²≤m/M≤c²`，故

\[
 M\ge M_0:=a/c^2.
 \tag{AG6}
\]

若M0>b，band为空。否则从M0开始按γ倍增，最后一个点精确截在b；若已经到b不再重复。记这个有限集合为 `mathcal M_j`。每个M∈[M0,b]有一个向上节点 M*，满足 `M≤M*≤γM`。

对实际R≤L（含平局）取节点 `L*=M*, R*=c²M*`；对实际R>L取 `L*=c²M*, R*=M*`。两朝向可以在上界中都列一次。于是

\[
 a\le L\le L^*\le b,\quad a\le R\le R^*\le b,
 \qquad g^*=cM^*,\quad c g^*=m^*=c^2M^*.
 \tag{AG7}
\]

节点仍在QG允许的[b/2,b]，且g*≤bc，没有跨原上端。实际较大尺度增幅≤γ，较小尺度增幅≤γ³。这是因为 `m≥c²M/γ²`。此外g*≥g，所以 `bar w_{cg}≥bar w_{cg*}`；分母的方向与所需正上界一致。

给节点使用同样三腿：A1*=L*、A2*=min(b,γL*)、A3*=b。若L*≥L，则
`min(b,γL*)/min(b,γL)≤L*/L`：若两者未截断是等号；若仅分子截断不等式由b≤γL*给出；两者都截断则为1。因此两条移动腿都随L向上，且不另付第三尺度节点。

## AG3 点态覆盖常数与唯一 soft 菜单

一维f_s为偶且沿半径非增（hard和φ均如此）。B*≥B时，

\[
 P_{s,B}(u)\le(B^*/B)^nP_{s,B^*}(u),\qquad
 h_R(u)\le(R^*/R)^n h_{R^*}(u).
\]

因此在AG4中向上替换尺度及分母的损失不超过
`(R*/R)^n(L*/L)^{n/2}(A_i*/A_i)^{n/2}`。R≤L朝向的三个比例依次≤γ³、γ、γ，故总损失≤γ^{4n}；R>L朝向依次≤γ、γ³、γ³，仍≤γ^{4n}≤e⁴。J腿的第三比例实际为1，使用同一宽常数即可。

对每个固定节点，前两腿的同一个soft参数只出现在2n个非负affine因子的半次幂乘积中，J腿只出现在n个。故直接应用已证R220公共菜单（不是对两腿分别付费）：

\[
 \sup_{0\le s\le1}F^*_{i,s}(x)
 \le4\sum_{r\in S_n}F^*_{i,r}(x),\qquad |S_n|=N_n.
\]

其中前两腿σ=r，J腿σ=1。物理尺度、来源及分母已经固定；χ中的依soft资格没有被塞入affine系数。先将χ上放为已认证的几何支持指示，再对纯核用菜单。因此得到合法的**点态有限和**

\[
 \chi(x)F_i(x)\le
 4e^4\sum_{\varepsilon\in\{-,+\}}\sum_{M^*\in\mathcal M_j}
 \sum_{r\in S_n}1_{x\notin Q_{d_{\varepsilon,M^*}}(v)}F^*_{i,\varepsilon,M^*,r}(x).
 \tag{AG8}
\]

无排除时指示恒为1。实际节点选择的fiber已在这个非负和中被上放；不再声称不同fiber的源价互不重叠。

## AG4 真实 capture 支持如何穿过节点

AG8中可用的d如下；这些只由**实际原行**推出，不是节点capture重新计算。

* 不使用capture时，两个朝向均无排除。
* 原正capture行有B_hard=0。在实际R≤L朝向，原行排除Q_R(v)。由AG7，`R≥max(a,R*/γ³)`，故可取 `d_{-,M*}=max(a,R*/γ³)`。实际R>L朝向，仅凭B_hard不能排除任何核。
* 在R228的未触发下截断支H0≥a，原行另有 `x∉Q_a(v)`。因此上一项保留，而R>L朝向也可取 `d_{+,M*}=a`。
* 下截断支H0<a不使用完整Qa排除；仅R≤L的B_hard排除仍合法。RG7的短clock约束可以保在原χ里，本证明没有将它置换成节点条件。

“无排除”不解释为排除闭单点Q0；直接使用指示1。所有正d均为固定节点的真实继承排除。其余更强原A_cap一般依x，未证明能在整个fiber取统一正下界时，不把它放入固定参数乘积差。

对每个固定节点和soft r，令I_l为在原hard节点区间 `[z_l−R*/2,z_l+R*/2]` 上的两半密度积分，I_l^exc为再与 `[v_l−d/2,v_l+d/2]` 相交后的积分。准确有

\[
 J_{i,\varepsilon,M^*,r}(y,z,v)
 =\frac{\prod_l I_l-\prod_l I_l^{exc}}
 {(R^*)^n\sqrt{\bar w_{m^*}(y,v)}}.
 \tag{AG9}
\]

无排除时第二乘积取零。若某I_l=0，J=0；否则令 `Phi=1−∏_l(I_l^exc/I_l)`，无排除时Phi=1。QG给

\[
 0\le J_{i,\varepsilon,M^*,r}
 \le(M^*)^{-n}E_{c^2M^*}(y,v)\,\Phi_{i,\varepsilon,M^*,r}(y,z,v).
 \tag{AG10}
\]

因 `cg*=m*`，此处原w分母与QG的exact-min权完全相同，没有额外γ的逆度损失。若d≥R*且 `||z−v||∞≤(d−R*)/2`，AG9精确为零。最精确的本稿接收上界为

\[
 \boxed{\int\chi F_i\,dx
 \le\mathcal G_{j,i}(y,z,v):=
 4e^4\sum_{\varepsilon,M^*,r}J_{i,\varepsilon,M^*,r}(y,z,v).}
 \tag{AG11}
\]

这保留同一个hard来源及真实共同窗口，而非将两个overlap分开估计。AG10可提供更简洁的有限和上界；AG11的定义是已计算的一维积分乘积，绝非原未付接收积分的改名。

## AG5 求和得到AG5，不漏物理量纲

因为m*=c²M*≥a，`E_{m*}≤E_a`。令q0=γ^{-n}≤1/2（由Bernoulli得γ^n≥2）。除最后截断点外，各节点的M*^-n构成公比q0的几何级数。单独为可能的最后截断点支付M0^-n，得

\[
 \sum_{M^*\in\mathcal M_j}(M^*)^{-n}
 \le M_0^{-n}\{(1-q_0)^{-1}+1\}
 \le3c^{2n}a^{-n}.
\]

AG11中2个朝向、N_n个soft节点及4e⁴恰给24e⁴N_n，证明AG5。这个求和不把物理核归一成单位质量后另求尺度sup；物理因子M*^-n是消去尺度节点个数所需的关键，必须继续保在来源价中。

## AG6 独立第三尺度或独立soft的额外价

若改研究任意可测A(x)∈[L(x),b]，对A另用从a按γ倍增、末点截b的向上网格，个数

\[
 N_A\le1+\left\lceil\frac{\log(b/a)}{\log\gamma}\right\rceil.
\]

先取A的向上节点Aceil，再令A*=max(Aceil,L*)。它仍≤b且≥L*。在R≤L朝向，A*/A≤γ；在R>L朝向≤γ³。因此前述e⁴点态因子仍成立，但AG5右侧明确再乘N_A。若σ独立于s并可自适应，则两个独立soft菜单各一次，右侧的`4N_n`改为`16N_n²`（即AG5再乘4N_n）。这些不是原AG3三腿的费用，不能用将A直接取b的做法省略 `(b/A)^{n/2}`。

## AG7 原正交通的合法接口和仍未支付的来源价

现在固定原(ω,V,j)，q>0是原共同分母，β和ν仍是原来源。原positive的hard来源为ν(dz)，不是Z_g里的后验。对terminal-good v，原点态比较为

\[
 p_y\le\sqrt{K/3}\sum_{i=1}^3
 \frac{\sqrt{p_yK_i(x-v)}}{\sqrt{w_g(y,v)}}.
\]

故可在原未使用hard cap的 `2Λ q^{-1}p_yh_R` 路线上代入AG11。固定(j,y,t)的原Π、e和k不依x；保留所有原门在χ中，随后只作AG4认可的上放，receiver-first Tonelli是合法的。实际t窗口包含在

\[
 I_j=[a/c,bc],\qquad \ell_j=\log(bc^2/a)\in[0,\log2].
\]

空窗交通先取零。原过程不活跃/分母为零处将masked后验密度取零，不发明新的后验过程。设

\[
 a_{j,t}(y,v)=1_{Z_{j,t}(y)}(v)w_t(y,v)/e_t(y),
\]

并取任意静态上包络 `A_j(y,v)≥sup_{t∈I_j}a_{j,t}(y,v)`；若不可积，下面右侧允许为∞。R227已证pair-envelope界给

\[
 \int_{I_j}(k_t(y,v)-k_t(y,u))_+
 a_{j,t}(y,v)a_{j,t}(y,u)\,dt/t
 \le\sqrt{2n\ell_j}\,A_j(y,v)A_j(y,u).
\]

因此，对相应原capture类别，完整可回代界为

\[
 \boxed{\mathcal P_{rem}
 \le2\Lambda\sqrt{K/3}\,\mathbb E\sum_{V,j}\frac{\sqrt{2n\ell_j}}q
 \int\beta(dy)\nu(dz)\nu(dv)\nu(du)
 A_j(y,v)A_j(y,u)\sum_{i=1}^3\mathcal G_{j,i}(y,z,v).}
 \tag{AG13}
\]

这里AG11可用exact product differences，继续保z的几何；若同时估上下clamp类别，应分别使用其合法capture支持，不能把上支Qa排除用于下支。也可以不分支、使用仅由B_hard推出的全域G，AG13直接估全部余量。

仅为展示粗价，AG5将AG13进一步上放为

\[
 2\Lambda\sqrt{K/3}\,(72e^4N_n)\,
 \mathbb E\sum_{V,j}\frac{c_j^{2n}a^{-n}\sqrt{2n\ell_j}}q\,\|\nu\|
 \int\beta(dy)\nu(dv)\nu(du)
 E_a(y,v)A_j(y,v)A_j(y,u).
 \tag{AG14}
\]

此处每个源的测度、共同q、a^-n、j及两包络均仍在。AG14不是root付款：仅接收soft菜单和pair变差已有乘积量级约n log n，且原一般输入未授 `∫A_jν≤1`，也未授 `||ν||/(qa^n)` 为常数。不能删去这两个困难后援引FIRST；原p_y已被三半密度替换，节点p不是实际FIRST权。ν≤β与对称W本身也不支付这些加权四来源积分。AG13中更精细的同窗捕获差是否能和原source/high条件联动，是现在最早的未证步骤。

本稿没有再乘16/3 hard帽：那是另一条先消hard来源的路线。AG13已保全部hard来源，必须在此路线自身结算。没有复用signed/deletion负账；也没有把原唯一j视为正放松后仍自动免求和。

## AG8 本机严格代数检查与复现

实际运行系统Python的Fraction（全有理数），共878个断言全部通过。测试n=2,16,512；n512含j=0、88、177，最后一项靠近band空窗边界。检查了真实band、向上节点留在[a,b]、两个朝向、全部三腿的尺度比与总损失，以及末点截b后的物理节点和。7组节点数依次为3、13、9、3、357、181、3；归一化节点和约1.69444、1.61053、1.61058、1.62806、1.58288、1.58288、1.65861。小数只供显示，断言用精确Fraction；这些有限检查不替代AG2–5的一般证明，也不是原FULL输入认证。

以下为实际运行脚本，可直接复制执行，无第三方依赖：

```python
from fractions import Fraction as F
records=[]; checks=0
for n in (2,16,512):
    gam=F(n+1,n); jmax=0
    while gam**(-2*(jmax+1)) >= F(1,2): jmax+=1
    for j in sorted(set((0,jmax//2,jmax))):
        c=gam**(-j); M0=1/c**2; nodes=[M0]
        while nodes[-1]<2: nodes.append(min(F(2),nodes[-1]*gam))
        q0=gam**(-n)
        assert q0<=F(1,2); checks+=1
        k=len(nodes)-1
        if nodes[-1]==M0*gam**k:
            total=(1-q0**(k+1))/(1-q0)
        else:
            total=(1-q0**k)/(1-q0)+(M0/F(2))**n
        assert total<=3; checks+=1
        cases=0
        for eta in (1/gam**2,(1+1/gam**2)/2,F(1)):
            lo=1/(c*c*eta)
            if lo>2: continue
            for M in (lo,(lo+2)/2,F(2)):
                m=c*c*M*eta
                Ms=next(qm for qm in nodes if qm>=M)
                for reverse in (False,True):
                    L,R=(M,m) if not reverse else (m,M)
                    Ls,Rs=(Ms,c*c*Ms) if not reverse else (c*c*Ms,Ms)
                    assert 1<=L<=Ls<=2 and 1<=R<=Rs<=2; checks+=1
                    assert Ls/L<=gam**3 and Rs/R<=gam**3; checks+=1
                    legs=((L,Ls),(min(F(2),gam*L),min(F(2),gam*Ls)),(F(2),F(2)))
                    for A,As in legs:
                        assert A<=As and As/A<=gam**3; checks+=1
                        assert (Rs/R)**2*(Ls/L)*(As/A)<=gam**8; checks+=1
                        cases+=1
        records.append((n,j,len(nodes),cases,float(total)))
print(checks, records)
```

**交付边界。** 新结论是AG5/AG11：原三腿的连续物理selector已获得合法的、带全部量纲和capture差的接收界，确实跨过了R228所指出的第一处固定参数到自适应参数缺口。AG13–14同时显示下一步的实际来源/两后验总账仍未闭合；本稿不登记新的 `εX+C√n polylog(n)W_β` 付款。
