import sympy as s
eta,S,e,M=s.symbols('eta S e M',positive=True)
delta=eta/(8*S)
zeta=eta/(4*S)
threshold=4*S*e/eta
assert s.simplify(S*zeta+2*S*delta+2*S*e/threshold-eta)==0
assert s.simplify(M*(eta/M)-eta)==0
print('SymPy',s.__version__)
print('uncapped zeta budget residual = 0')
print('entrance multiplier residual = 0')
print('capped zeta branch requires eta >= 2*S; then S/2 <= eta/4 (analytic).')
