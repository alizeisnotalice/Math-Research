# R458 最终独立审计

**FINAL PASS（限定任意精度有限 canonical 终端压缩、准确条件核与列明有限证据）。** 一般根阶弱型上界以及 `R_canonical,out` 的全局根阶源预算仍未证明；本报告不认证这些整体目标。本轮发现的一处可选支持段严格端点歧义已修复，现无待修数学阻断项。2026-10-21。

## 证明与量词

- 固定原全场、完整来源对及原记录，原 `Pi0=Pi/b` sourcewise 帽与 R457 整路径 avoid 成功率 `s_y,s_z>=b>0` 保留。所有新 terminal/canonical 核只作新增分析标签，没有原历史移植；对已筛的新路径不能免费恢复 raw law。
- 旧终端集合 `B_x={Z<=h}` 满足 `h<=rho_x(B_x)<=h+eps0 h`，下界只在存在 active 输入时使用；原子与停止等号保留。质量分位数与 crossing 原子统一比例构造共同可测 `beta_(x,ell)`，不将中心离散化，也不任意挑原子内空间子集。零流/零系数项不归一化。
- 每个 active 严格前缀与 B 都是质量初段，`L_a=rho(B∩D_a)=min(t_x,Z_a)>=h`。预先给定 `ell_j=h+j delta h<=t_x`，向下取最大可用点，`beta_ellj<=rho|B∩D_a`、剩余质量 `<delta h`。每侧最多 `1+ceil(eps0/delta)` 个核，固定eps0、delta时数目不按路径长度或维度增长；核本身仍连续、依原场与来源对。
- **关键系数。** `O_kill` 是杀死前 active occupation，包含初始 active 项。未杀 raw occupation 的每个 active 前缀均含 beta_h，raw 总终端质量1给 `h∫O_raw/Z<=1`；由 `O_kill<=O_raw` 得 `sum_j c_j<=1/h`。没有把 occupation 当概率，也没有拿质量可能小于h的 safe beta 代替 beta_h 来推此界。
- 原实际最后一步按 `d beta_ellj/d rho` 作 thinning，保真实 last-active/bin/terminal 及全 path 标签。last-jump/Tonelli 精确给 `tau=sum_j c_j beta_ellj^safe+tau_err`，`0<=tau_err(E)<=delta`。partial atom 上同样精确；没有重抽原终端或仅证明一个旁路的分布近似。
- 条件avoid后 bin权 `omega_j=c_j B_j/s_x`，两侧真实概率乘积中的权为 `omega_yj omega_zk`。等价原基底形式严格保 `Pi0·b·c_yj c_zk/(s_y s_z)`，原soft只一次，两个分母没有藏成一个 `<=1` 因子。
- 两边任一舍入错误上放为 `delta/s_y+delta/s_z`，乘原soft后至多 `2delta`，故全流错误 `<=2S delta X`，没有 `1/zeta`、阶段数或核数平方的额外系数。父外门仍留在末端积分中，筛后不再声称归一 canonical product。
- geometry(12)–(13) 是更新后的真实 `a'_(jk)`：`b a_zeta E[omega_yj omega_zk|A,y,z;Pi0]`，其和 `<=b a_zeta`。核与父/起点无关，但非零bin和接受系数依原记录。不能把它们换成未加权或可分离接受权。主证(12)–(14)与此相同，不再使用旧未过滤F版本。

## 端点修复及辅助耦合

独审报告 geometry 可选全B支持段的 closed/strict CDF 端点歧义。最终版显式改为

\[
F_-(M/K)-F_-(M/K^3)=\rho\{M/K^3\le m<M/K\}\le2\varepsilon_0h,
\]

所以 `F_-(M/K³)>(4-3eps0)h>h`，对 `m_u>=M/K²`（包括等号）有 `Z_u>=F_-(M/K³)>h`。该修复正确，最终 geometry SHA 为下列新字节；原核心仅需实际 last-active 支持，未依赖这个可选推论。两来源各应用时须保其原高秩门，不赋新节点高秩历史。

辅助 mainproof 的未归一 canonical cutoff 全序成立；不同长度归一化后不再保概率次序。共同部分 `min(w_y/ell_i,w_z/ell_j) mu`、对角加剩余产品耦合及 doubly-safe 质量公式均正确，不能把一般 `d_y d_z/(1-c)` 偷换为 `min(d_y,d_z)`。这些辅助耦合未用于替换实际原路径参考，不额外抵消soft或收取新费用。

## 完整费用与未付项

合并R457，准确比较为

\[
R\le R_{\rm canonical,out}
 +[S\zeta+2S\varepsilon_0/s+2S\delta]X.
\]

原R457已付分支保留，本轮新错误项为 `2S delta X`。若为入口额度而选delta，且原槽倍率M依维度或分层变化，则delta与核数N_delta也相应变化；没有无条件维度一致的核数声明。S=0先零流。S>0时取 `zeta=min(1/2,eta/(4S))`、`delta=eta/(8S)`、`s>=4S eps0/eta`，三项分别至多 `eta/4,eta/2,eta/4`，总和<=eta；有限其余维数用 `R<=S A_n W`，常数依局部额度及固定原参数。入口须整乘 `M=64 Lambda0 Fhat`：本轮新增入口为 `2M S delta X`；原G0、BH各自槽系数分别为16Fhat、32Fhat，不与入口系数累加。旧所有X/W槽不退款，未宣称旧总账已吸收。

单边来源列界、canonical核总质量1、有限核数和耦合恒等式，均不推出实际接受权加权后的共同父外 W 价。本轮没有新增全局 W 付款，完整 `R_canonical,out<=epsilon X+C_epsilon s polylog(n+2)W` 仍是未证几何。

## 独立实际复现及范围

指定 Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，在新隔离目录

`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r458_audit_isolated_a_1q7nk8`

实际运行以下四份可执行内容一次，stdout全部与冻结 `r458_replay.json` 逐字节一致：

- geometry内嵌Python：3个delta阶段，各65个active-start，共195；2340逐终端比较、675部分原子bin发生。只是严格质量轴killed链，不是native完整历史。
- mainproof_check：138 Fraction断言。54项为3个旧背景方向的native局部块核验，84项为原子canonical耦合代数；不可把它们都记作本轮finite-grid新几何覆盖。
- numeric：1340 Fraction/Arb检查，6个有目的rank模型。3条仅复用R457真实几何的mass/rho作小h口径反查，没有重新构造原高h/history；3条明确ABSTRACT-RANK，用于非平凡小TV、partial atom、strict cutoff、last-active grid。没有实施早先拟议的6个静态几何实验。abstract输入的B0是实际离散闭窗，不赋予其原q值或native实现。
- budget_check：SymPy1.14.0两个预算恒等式及capped-zeta解析分支说明，范围仅参数账。

生成numeric JSON除 `compute_index.seconds_in_script` 外所有字段完全相同；运行时间为实际诊断浮点，不作数学证据。Arb256位仅用于K=e严格比较，TV/原子/混合/误差均Fraction。未调用MATLAB、未新增代理、未写repo/作者文件或PDF。PRE临时检查未计为归档新增覆盖。

## 最终10输入字节绑定

以下为最终白名单全部输入；审计自身不自绑定。独立PRE先于作者稿形成，原记录保留在 /tmp/r458_audit_pre.md，不纳入本轮归档输入；其阶段状态由本FINAL取代。

- `r458_main.md`: `85aeffedf35270561370f936f0abd9b292df347d0ad2d64afef412a7d5346db0`
- `r458_geometry.md`: `aa08eb71c27bf0b0345fe7eed6d7c7d6a529e5c9c4ace17b95e9ae14a26343c8`
- `r458_mainproof.md`: `3d872b06c1fee8f25f74918d92945b7dd02c93eb0e4417dbbf71112d2219dcfc`
- `r458_mainproof_check.py`: `23bc12f95084c13a1afee860051482c89bc18997e92d642ec1e32e620a1d8b1f`
- `r458_numeric.md`: `bb16ebf361d56b0f9914e00d977d3a81bd390892193075d624b0cd8c6388c74b`
- `r458_numeric.py`: `e11499b13c8b40c79945b229ffae2fc09d9612517eb214e423d8dee41c73905c`
- `r458_numeric.json`: `a45b209342c4a6ef354ba5277c65ca9a080ebc26aa9c829e402579f00f9b38be`
- `r458_history.md`: `96beb7acd74cfc059b2f2ebedbb786afd19f096671aca16461d0773759d28a0b`
- `r458_budget_check.py`: `63df5c2063b7843a32840a4612c2dbcc75e356988c6ac554b1bad65bb692ae75`
- `r458_replay.json`: `6fd238c1cc9951fe0d64061f5e971bf65dbb37c6d1259aac4909f9d6927a78f6`
