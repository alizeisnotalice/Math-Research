#!/usr/bin/env python3
"""Rank-terminal common reference and killed-terminal bottom decomposition.
No R458 static six-geometry demonstration is run. ABSTRACT-RANK is not native.
"""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform,time
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
started=time.perf_counter();checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def ar(x):return arb(x.numerator)/x.denominator

def model(stage,name,mass,rho,h,K=None,native=False):
 N=len(mass);order=sorted(range(N),key=lambda i:mass[i]);Ke=arb(1).exp() if K is None else ar(K)
 far=[]
 for mi in mass:
  row=[]
  for mj in mass:
   if K is None:
    yes=ar(mj)*Ke<ar(mi);no=ar(mj)*Ke>ar(mi);ck(yes or no);row.append(bool(yes))
   else:row.append(mj*K<mi)
  far.append(row)
 Z=[sum((a for a,take in zip(rho,row) if take),Q(0)) for row in far];active=[z>h for z in Z]
 ck(any(active))
 B=[not t for t in active];MB=sum((a for a,t in zip(rho,B) if t),Q(0));ck(MB>=h)
 P=[[rho[j]/Z[i] if active[i] and far[i][j] else Q(0) for j in range(N)] for i in range(N)]
 window=[]
 for low in mass:
  total=Q(0)
  for m,a in zip(mass,rho):
   if m<low:continue
   inside=(ar(m)<Ke*ar(low)) if K is None else m<=K*low
   if K is None:ck(inside or ar(m)>Ke*ar(low))
   if inside:total+=a
  window.append(total)
 B0=max(window);surplus=(MB-h)/h;eps=B0/h
 ck(MB<=h+B0)
 beta=[Q(0)]*N;remaining=h
 for i in order:
  take=min(remaining,rho[i]);beta[i]=take;remaining-=take
 ck(remaining==0 and sum(beta)==h)
 ck(all(0<=b<=a and (not b or B[i]) for i,(b,a) in enumerate(zip(beta,rho))))
 kappa=[x/h for x in beta];selector=[b/a for b,a in zip(beta,rho)]
 nu=[[Q(0)]*N for _ in range(N)]
 for i in order:
  if active[i]:nu[i]=[sum((P[i][j]*nu[j][k] for j in range(N)),Q(0)) for k in range(N)]
  else:nu[i][i]=Q(1)
 rows=[];stopped=[]
 for i in range(N):
  ck(sum(nu[i])==1 and all(x>=0 for x in nu[i]))
  tv=sum((abs(x-y) for x,y in zip(nu[i],kappa)),Q(0))/2
  ck(tv==1-sum((min(x,y) for x,y in zip(nu[i],kappa)),Q(0)))
  if active[i]:
   ck(all(x<=(rho[j]/h if B[j] else Q(0)) for j,x in enumerate(nu[i])))
   ck(tv<=surplus<=eps)
   rows.append(dict(start=i,mass=mass[i],terminal=nu[i],TV_to_common_kappa=tv))
  else:stopped.append(dict(start=i,TV_to_common_kappa=tv))
 maxpair=max((sum((abs(x-y) for x,y in zip(a['terminal'],b['terminal'])),Q(0))/2 for a in rows for b in rows),default=Q(0))
 ck(maxpair<=2*eps)
 result=dict(stage=stage,name=name,qualification='NATIVE-R457-RANK-INPUT-ONLY' if native else 'ABSTRACT-RANK-NO-GEOMETRY',
 mass=mass,rho=rho,h=h,K='e' if K is None else K,far=far,Z=Z,active=active,terminal_set=B,
 terminal_reference_mass=MB,closed_window_max=B0,window_masses=window,tight_surplus=surplus,eps_window=B0/h,
 beta=beta,kappa=kappa,bottom_selector=selector,beta_partial_atoms=[i for i in range(N) if 0<beta[i]<rho[i]],
 active_starts=rows,stopped_starts_NOT_claimed=stopped,max_TV=max(r['TV_to_common_kappa'] for r in rows),
 max_pairwise_terminal_TV=maxpair,strict_mass_ties=sum(mi==K*mj for mi in mass for mj in mass) if K is not None else 0)
 if native:
  result['native_q_min']=Q(1);result['native_s']=Q(2);result['native_eps_s_over_qh']=2/h
  ck(B0<=2 and MB<=h+2)
 else:
  ck(eps<Q(1,2))
  bad={0,23};C=sum(rho[i] for i in bad);b=1-C/h
  ck(0<C<h and 0 in bad and active[23])
  tau=[[Q(0)]*N for _ in range(N)]
  for i in order:
   if i in bad:continue
   if active[i]:tau[i]=[sum((P[i][j]*tau[j][k] for j in range(N)),Q(0)) for k in range(N)]
   else:tau[i][i]=Q(1)
  beta_safe=[Q(0) if i in bad else x for i,x in enumerate(beta)];beta_mass=sum(beta_safe)
  ck(beta_mass>0)
  kappa_good=[x/beta_mass for x in beta_safe];killed=[]
  for i in range(N):
   if not active[i] or i in bad:continue
   endpoint=tau[i];success=sum(endpoint)
   ck(success>=b and success<=1)
   ck(all(t<=n for t,n in zip(endpoint,nu[i])))
   bottom=[t*w for t,w in zip(endpoint,selector)];rem=[t-z for t,z in zip(endpoint,bottom)]
   coeffs={bottom[j]/beta_safe[j] for j in range(N) if beta_safe[j]}
   ck(len(coeffs)==1);coef=next(iter(coeffs))
   ck(bottom==[coef*x for x in beta_safe])
   rem_mass=sum(rem);bottom_mass=sum(bottom)
   ck(all(x>=0 for x in rem) and rem_mass+bottom_mass==success)
   ck(rem_mass<=surplus)
   conditioned=[x/success for x in endpoint]
   if rem_mass:
    mix=[bottom_mass/success*x+rem_mass/success*y/rem_mass for x,y in zip(kappa_good,rem)]
   else:mix=kappa_good[:]
   ck(mix==conditioned)
   tv=sum((abs(x-y) for x,y in zip(conditioned,kappa_good)),Q(0))/2
   ck(tv<=rem_mass/success)
   ck(b*rem_mass/success<=surplus<=eps)
   ck(b*tv<=eps)
   # Independent forward killed-active occupation, including its initial term.
   O=[Q(0)]*N;O[i]=1
   for a in reversed(order):
    if not active[a] or a in bad:continue
    for j,pij in enumerate(P[a]):
     if pij and active[j] and j not in bad:O[j]+=O[a]*pij
   last=[];reconstructed=[Q(0)]*N;coeff_sum=Q(0);exit_B=Q(0)
   def beta_at(amount):
    ans=[Q(0)]*N;rem0=amount
    for j in order:
     take=min(rem0,rho[j]);ans[j]=take;rem0-=take
    ck(rem0==0 and sum(ans)==amount)
    ck(all(not x or B[j] for j,x in enumerate(ans)))
    return ans
   for a in range(N):
    if not O[a]:continue
    ck(active[a] and a not in bad)
    La=sum((r for r,t,bb in zip(rho,far[a],B) if t and bb),Q(0))
    ck(La>=h)
    ba=beta_at(La)
    ck(ba==[rho[j] if B[j] and far[a][j] else Q(0) for j in range(N)])
    coef=O[a]/Z[a];coeff_sum+=coef;exit_B+=coef*La
    reconstructed=[x+coef*(Q(0) if j in bad else z) for j,(x,z) in enumerate(zip(reconstructed,ba))]
    last.append(dict(active_atom=a,occupation=O[a],Z=Z[a],L=La,coefficient=coef))
   ck(reconstructed==endpoint and h*coeff_sum<=exit_B<=1)
   grids=[]
   for delta in (Q(1,100),Q(1,20),Q(1,5)):
    step=delta*h;groups={}
    for lastrow in last:
     jj=(lastrow['L']-h)//step
     ell=h+jj*step
     ck(ell<=lastrow['L']<ell+step)
     groups[jj]=groups.get(jj,Q(0))+lastrow['coefficient']
    keep=[Q(0)]*N;gridrows=[]
    for jj,cj in sorted(groups.items()):
     ell=h+jj*step;bell=beta_at(ell);safe=[Q(0) if j in bad else z for j,z in enumerate(bell)]
     keep=[x+cj*z for x,z in zip(keep,safe)]
     gridrows.append(dict(bin=jj,ell=ell,cj=cj,beta_safe=safe,partial_atoms=[j for j in range(N) if 0<bell[j]<rho[j]]))
    remgrid=[x-y for x,y in zip(endpoint,keep)];rgrid=sum(remgrid)
    ck(all(x>=0 for x in remgrid))
    ck(rgrid<=delta*h*sum(groups.values())<=delta)
    ck(b*rgrid/success<=delta)
    # Exact normalized mixture of the shared grid references plus remainder.
    mixture=[Q(0)]*N
    for gr in gridrows:
     componentmass=sum(gr['beta_safe']);ck(componentmass>0)
     mixture=[x+gr['cj']*componentmass/success*z/componentmass for x,z in zip(mixture,gr['beta_safe'])]
    mixture=[x+z/success for x,z in zip(mixture,remgrid)]
    ck(mixture==conditioned)
    grids.append(dict(delta=delta,shared_grid_total_size=(MB-h)//step+1,used_bins=gridrows,
      keep=keep,remainder=remgrid,remainder_mass=rgrid,delta_h_sum_c_bound=delta*h*sum(groups.values()),
      soft_conditioned_remainder_cost=b*rgrid/success))
   killed.append(dict(start=i,terminal_tau=endpoint,success_s=success,soft_b=b,
    bottom_constant=next(iter(coeffs)),active_occupation=O,last_active=last,h_sum_last_coefficients=h*coeff_sum,
    total_flow_to_original_B=exit_B,finite_grids=grids,bottom_mass=bottom_mass,remainder_mass=rem_mass,conditional_endpoint=conditioned,
    TV_conditioned_to_kappa_good=tv,conditioned_remainder_weight=rem_mass/success,
    original_soft_remainder_cost=b*rem_mass/success,original_soft_path_RN=b/success,
    independent_double_probability_RN_one_soft=b/(success*success),
    double_scope='independent same-rank copies only; no native two-source paths'))
  result['killed_bad_check']=dict(bad_atoms=sorted(bad),bad_rho=C,soft_b=b,beta_safe=beta_safe,kappa_good=kappa_good,starts=killed,
   max_remainder_mass=max(x['remainder_mass'] for x in killed),
   max_soft_remainder_cost=max(x['original_soft_remainder_cost'] for x in killed),
   max_independent_double_RN=max(x['independent_double_probability_RN_one_soft'] for x in killed),
   grid_summary=[dict(delta=d,shared_grid_total_size=next(g['shared_grid_total_size'] for g in killed[0]['finite_grids'] if g['delta']==d),
      maximum_remainder=max(g['remainder_mass'] for z in killed for g in z['finite_grids'] if g['delta']==d),
      maximum_soft_conditioned_remainder=max(g['soft_conditioned_remainder_cost'] for z in killed for g in z['finite_grids'] if g['delta']==d))
      for d in (Q(1,100),Q(1,20),Q(1,5))])
 return result
mass=list(map(Q,[100,20,4,2,1]));rho=list(map(Q,['1/25000','1/5000','1/1000','1/500','1/250']))
abstract_mass=[Q(2**j) for j in range(28)];abstract_rho=[Q(1)]*28
results=[model('initial','R457_native_small_h',mass,rho,Q(3,1000),native=True),
 model('initial','abstract_integer_h',abstract_mass,abstract_rho,Q(20),K=Q(2)),
 model('boundary','R457_native_active_tie',mass,rho,Q(1,250),native=True),
 model('boundary','abstract_split_atom',abstract_mass,abstract_rho,Q(41,2),K=Q(2)),
 model('expanded','R457_smaller_common',mass,[rho[0],rho[1],rho[2],Q(1,1000),rho[4]],Q(3,800),native=True),
 model('expanded','abstract_strict_cutoff_change',abstract_mass,abstract_rho,Q(41,2),K=Q(199,100))]
out=dict(scope='finite-grid killed-terminal decomposition is primary; source-rank terminal probability checks; ABSTRACT-RANK carries no geometry; native inputs only small-h crosscheck',
 executable=sys.executable,python=platform.python_version(),python_flint=flint.__version__,arb_bits=ctx.prec,checks=checks,
 compute_index=dict(input='R457 masses/rho embedded plus three labelled abstract geometric-mass rank models; six models total',
 responsibility='numeric only; no static six-case geometry experiment was run',status='complete and frozen',
 main_check='last-active shared finite-grid killed-terminal keep/remainder; raw TV auxiliary',arithmetic='Fraction exact; Arb only e cutoff sign',
 command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r458_numeric.py',
 seconds_in_script=time.perf_counter()-started,output='r458_numeric.json'),cases=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r458_numeric.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'python-flint:',flint.__version__,'Arb bits:',ctx.prec)
for a in results:
 print(a['name'],'terminal rho=',a['terminal_reference_mass'],'h=',a['h'],'B0=',a['closed_window_max'],'surplus=',a['tight_surplus'],'eps=',a['eps_window'],'maxTV=',a['max_TV'],'partial=',a['beta_partial_atoms'])
 if 'killed_bad_check' in a:
  z=a['killed_bad_check'];print(' killed C=',z['bad_rho'],'b=',z['soft_b'],'maxrem=',z['max_remainder_mass'],'max softrem/s=',z['max_soft_remainder_cost'],'max double RN=',z['max_independent_double_RN'])
  print(' grid:',z['grid_summary'])
print('PASS',checks,'exact/Arb checks; six rank models, no scan')
