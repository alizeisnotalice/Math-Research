# R458 — canonical terminal quantiles: ordering and the exact unequal-length pair contract

This bounded auxiliary note supports the finite-grid terminal compression. It does not prove the remaining root-dimensional source budget. In particular, it does not replace the actual bin weights or the original history by an unmarked terminal product.

## 1. Native canonical quantiles, with mass atoms retained

Freeze the full field, the actual center set and selector, and
\[
\mu(dw)=dw/m_w,\qquad \rho_x(dw)=c_w(x)\mu(dw).
\]
For \(0<\ell<J(x)=\rho_x(E)\), let
\[
M_{x,\ell}=\inf\{t:\rho_x\{m_w\le t\}\ge\ell\}.
\]
Writing \(T_-(M)=\rho_x\{m_w<M\}\) and
\(a(M)=\rho_x\{m_w=M\}\), define
\[
w_{x,\ell}(t)=1_{\{t<M_{x,\ell}\}}
 +\vartheta_{x,\ell}1_{\{t=M_{x,\ell}\}},\qquad
\vartheta_{x,\ell}=\frac{\ell-T_-(M_{x,\ell})}{a(M_{x,\ell})}.
\tag{1}
\]
If the denominator is zero, the boundary value is irrelevant to this source measure and may be zero. This includes a continuous-CDF cutoff. At \(\ell=J(x)\), simply take \(w=1\) on the bounded actual mass range. Put
\[
\beta_{x,\ell}(dw)=w_{x,\ell}(m_w)\rho_x(dw),\qquad
\kappa_{x,\ell}=\beta_{x,\ell}/\ell. \tag{2}
\]
Then \(\beta_{x,\ell}(E)=\ell\) exactly, including crossing atoms. These are jointly measurable kernels: the CDF is measurable in \((x,t)\), its generalized inverse can be obtained through rational level tests, and the boundary fraction is a measurable quotient. Null-source or zero-entering-flow fibers need not define a probability.

For every two such canonical weights, even with different sources and different lengths,
\[
w_{y,\ell_i}\le w_{z,\ell_j}\quad\hbox{everywhere on the mass axis},
\quad\hbox{or the reverse}. \tag{3}
\]
Order their cutoff masses; at the same cutoff, order the fractions. This elementary order is for the **unnormalized step weights**. It does not assert that the two source measures themselves are ordered.

If \(\ell\le\rho_x\{m_w<m_A/K\}\), with enough strict-past mass to place the quantile below the boundary (in particular if the inequality is strict), the support lies in that strict past. In applying this observation to a compressed terminal bin, the support comes from the actual last-active sampling set; it must be preserved there, not inferred from an unrelated high-rank label. The equality case is handled by the actual strict-past sampling measure or a monotone limit, not by including an atom at \(m_A/K\).

## 2. Common capture and the normalization issue

For a pair of lengths define
\[
C_y^{ij}=\int c_w(y)c_w(z)w_{y,\ell_i}(m_w)\mu(dw),\qquad
C_z^{ij}=\int c_w(y)c_w(z)w_{z,\ell_j}(m_w)\mu(dw),
\]
\[
d_y^{ij}=1-C_y^{ij}/\ell_i,\qquad
d_z^{ij}=1-C_z^{ij}/\ell_j. \tag{4}
\]
These are the canonical probabilities of excluding the opposite source. If both quantiles are supported in the original parent's strict past and \(C_A(y,z)<h\), while \(\ell_i,\ell_j\ge h\), then
\[
d_y^{ij}\ge1-C_A(y,z)/\ell_i\ge b_*,
\qquad d_z^{ij}\ge b_*,
\quad b_*=1-C_A(y,z)/h>0. \tag{5}
\]
The parent mass gate, the strict-past cutoff, and the source labels in this statement are all the original ones.

The exact common part of the two *normalized* probabilities is
\[
\chi_{ij}(dw)=c_w(y)c_w(z)
 \min\!\left(\frac{w_{y,\ell_i}(m_w)}{\ell_i},
             \frac{w_{z,\ell_j}(m_w)}{\ell_j}\right)\mu(dw),
\quad c_{ij}=\chi_{ij}(E). \tag{6}
\]
Always
\[
0\le c_{ij}\le\min(C_y^{ij}/\ell_i,C_z^{ij}/\ell_j).
\]
If, for example, \(w_{y,\ell_i}\le w_{z,\ell_j}\), also
\(c_{ij}\ge C_y^{ij}/\max(\ell_i,\ell_j)\). No ordering of \(d_y^{ij}\) and \(d_z^{ij}\) follows for unequal lengths.

For equal lengths \(h\), (3) gives more: if \(w_y\le w_z\), then
\[
d_y\ge d_z,\quad c=1-d_y,\quad
\int c_yc_z(w_z-w_y)\,d\mu/h=d_y-d_z. \tag{7}
\]
Thus the unequal-length correction is real, not a boundary-atom technicality.

A canonical coupling with the correct two marginals is, when \(c_{ij}<1\),
\[
\operatorname{diag}(\chi_{ij})
+\frac{(\kappa_{y,\ell_i}-\chi_{ij})
       \otimes(\kappa_{z,\ell_j}-\chi_{ij})}{1-c_{ij}}. \tag{8}
\]
For \(c_{ij}=1\), use only its diagonal part. Its doubly exclusive component is
\[
\frac{\kappa_{y,\ell_i}^{\,\bar z}
       \otimes\kappa_{z,\ell_j}^{\,\bar y}}{1-c_{ij}}. \tag{9}
\]
In the equal-length ordered case its mass is \(\min(d_y,d_z)\). In general its mass is \(d_y^{ij}d_z^{ij}/(1-c_{ij})\), which must not be replaced by that minimum.

For any lengths one could instead design a coupling with maximal doubly safe mass \(\min(d_y^{ij},d_z^{ij})\), by coupling the two safe indicators first. This is a generic marginal fact and needs no canonical ordering. Its normalized safe-product part, after conditioning on success, is exactly
\[
\frac{\kappa_{y,\ell_i}^{\,\bar z}
       \otimes\kappa_{z,\ell_j}^{\,\bar y}}{d_y^{ij}d_z^{ij}}.
\]
Consequently this maneuver alone does not improve the existing product-capacity coefficient. A single original soft factor can cancel a success probability relative to a correlated coupling reference, but that reference is not the old product reference with a uniformly bounded density. No extra soft cancellation or history qualification is claimed.

## 3. Interface to the actual killed-path compression

Here the input is the R457 conditional-avoid construction, not an unfiltered product law with a bounded future multiplier. Fix the complete original record \(r\), including \(A,y,z\), the original exclusive starting nodes, and every old history label. Let \(s_{r,y}\) and \(s_{r,z}\) be the two unconditioned probabilities of avoiding the opposite source for the entire auxiliary path. The established barrier gives \(s_{r,y},s_{r,z}\ge b_*>0\).

The separate finite-grid compression theorem supplies the **killed**, unnormalized terminal coefficients
\[
c_{r,x,j}\ge0,\qquad \sum_jc_{r,x,j}\le1/h,
\qquad \ell_j=h+j\delta h. \tag{10}
\]
For \(x=y\) the safe set excludes \(z\), and conversely. Define
\[
\beta_{y,i}^{\,\bar z}=1_{\{c_u(z)=0\}}\beta_{y,\ell_i},\quad
B_{r,y,i}=\beta_{y,i}^{\,\bar z}(E),\quad
\kappa_{r,y,i}^{\,\bar z}=\beta_{y,i}^{\,\bar z}/B_{r,y,i},
\]
and the analogous \(z,j\) quantities. The normalized kernel is only needed when \(B>0\). The killed compression is a submeasure of the killed terminal law, so
\[
\sum_i c_{r,y,i}B_{r,y,i}\le s_{r,y}.
\]
Consequently
\[
\gamma_{r,y,i}=\frac{c_{r,y,i}B_{r,y,i}}{s_{r,y}},
\qquad \sum_i\gamma_{r,y,i}\le1, \tag{11}
\]
with \(\gamma=0\) when \(B=0\). Both the coefficients and the success probability depend on the original record and the retained opposite-source label.

Thus the actual retained compressed endpoint measure, restricted to the father-outside component, is
\[
d\Pi(r)\sum_{i,j}\gamma_{r,y,i}\gamma_{r,z,j}
 1_{\{u,v\notin Q_A\}}\,
 \kappa_{r,y,i}^{\,\bar z}(du)
 \kappa_{r,z,j}^{\,\bar y}(dv). \tag{12}
\]
Equivalently, with \(d\Pi=b_*\,d\Pi^0\), it is
\[
d\Pi^0(r)\,b_*
 \sum_{i,j}\frac{c_{r,y,i}c_{r,z,j}}{s_{r,y}s_{r,z}}\,
 1_{\{u,v\notin Q_A\}}\,
 \beta_{y,i}^{\,\bar z}(du)\beta_{z,j}^{\,\bar y}(dv). \tag{13}
\]
In particular the terminal density within each summand is
\[
\frac{c_u(y)(1-c_u(z))c_v(z)(1-c_v(y))}{m_um_v}
 w_{y,\ell_i}(m_u)w_{z,\ell_j}(m_v)\,du\,dv. \tag{14}
\]
Every cutoff established by the killed compression is retained in its actual bin kernels and coefficients. No new auxiliary node inherits an old history condition merely from its source label.

Equations (12)–(13) expose the original soft factor **once** and expose the two conditioning denominators \(1/(s_{r,y}s_{r,z})\) explicitly. They cannot be hidden in a multiplier declared at most one relative to the unconditioned product. They are identities for the compressed conditional construction; they do not assert that its lost mass is zero. Its rounding loss and its mother-ledger price are proved and charged by the main compression theorem, not again here.

After integrating the original record labels, the bin-specific accepted weight is the actual projection of the coefficient in (13). It need not equal the former static \(a_\zeta(A,y,z)\), and no arbitrary newly imposed future filtering is claimed to be compatible for free. Original history stays in \(r\); the new father-outside restriction is the explicit endpoint event in (12).

The unnormalized canonical ordering and the common-part identities of §2 remain applicable to every bin pair. They do not remove \(1/(s_{r,y}s_{r,z})\), nor do they estimate the full accepted center integral (13) by a root-dimensional source budget. This is the precise remaining joint kernel. This note adds no \(\zeta\) price, no absorption fee, and no additional root \(W\) receipt.

## 4. Bounded verification and route decision

The local script r458_mainproof_check.py was actually run and passed **138 exact Fraction assertions**:

* 54 assertions in three positive-Lebesgue-center, fully matched cube configurations screened the initial exterior-third-source idea. That idea gave only the old \(A_nW\) column price and was stopped.
* 84 assertions in six atomic quantile configurations check exact quantile mass, total ordering with boundary fractions, equal-length common-part mass, both coupling marginals, and the doubly safe mass in (7)–(9).

The native configurations use \(n=16\), side lengths \(1,2\), \(f=1_{[-4,4]^{16}}\) plus an optional central packet, and real disjoint small center cubes. They have exact matching and strict \(K^2\) mass separation, but do not realize all original high-rank or stage/history gates. The atomic quantile checks likewise certify algebra, not native history. The general unequal-length statements above are proved directly and do not rely on a finite model.

The useful outcome is the precise distinction between ordered raw canonical cutoffs and unordered normalized terminal probabilities, and the conditional-avoid bin kernel (12)–(14). It supports auditing the new compression without claiming that compression or canonical coupling has already settled its remaining global center integral.
