# R458 finite-grid killed-terminal与共同参考证书（冻结）

按root后续准确决策执行：**原拟6个静态几何演示没有运行**。本轮主结果是有限rank模型的last-active共同网格分解；原最低质量h参考的TV检查为辅助。六个模型、1340项Fraction/Arb检查通过，未扫描。三条高h模型明确为ABSTRACT-RANK，不声称存在对应真实几何、原q-band或完整history。

## 1. 接口与解析核对

质量m_i>0、来源占用权ρ_i>0，严格prefix为 `D_a={i:m_i K<m_a}`，Z_a=ρ(D_a)。原核在Z_a>h时才active，按ρ/Z_a跳到prefix；Z_a≤h停止。记原terminal初段B={Z≤h}。对own-high起点的原terminal概率ν，既有Green界给 `ν≤ρ|B/h`。

若own-high存在，ρ(B)≥h。取最低质量的h子测度β（最后一个质量原子允许取分数），κ=β/h，与起点无关。按 `TV(P,Q)=½Σ|P−Q|` 的约定，两个概率ν、κ都受ρ_B/h支配，故

`TV(ν,κ)=∫max(ν,κ)−1 ≤ ρ(B)/h−1`。

这里不需要β“最低秩”来证明共同包络TV不等式；最低秩选择用于构造统一canonical参考及后面的last-active网格。若另有几何ρ(B)≤h+s/q，则才可代入eps=s/(qh)。该几何估计不由任意rank输入自动获得。

本轮另精确计算 `B0=max_t ρ([t,Kt])`（闭质量窗，保留质量tie）。terminal初段的最后质量为m*，其strict远过去≤h，余下在闭窗[m*/K,m*]内，故finite rank的ρ(B)≤h+B0。本轮用eps=B0/h核小TV，不赋ABSTRACT模型任何q值。

## 2. 六模型：初步、边界、扩大

三条native输入只是R457已审几何的mass/ρ口径反查：mass按(A,w,mid,common,leaf)为(100,20,4,2,1)，ρ为(1/25000,1/5000,1/1000,1/500,1/250)，K=e。扩大时common的ρ改1/1000；h分别3/1000、1/250、3/800。未重新声明原high-h/history资格。

三条**ABSTRACT-RANK**都取28个原子，m_j=2^j、ρ_j=1、j=0,…,27；参数分别(K,h)=(2,20),(2,41/2),(199/100,41/2)。它们没有真实cube field声明。最后一项专门检验strict mass cutoff：K2时相邻powers-of-two正好在排除边界，K1.99则进入prefix。

| 阶段/模型 | ρ(B) | h | B0/h | tight surplus=(ρ(B)−h)/h | 全own-high最大TV |
|---|---:|---:|---:|---:|---:|
| 初步native小h | 3/500 | 3/1000 | 2 | 1 | 2/7 |
| 初步abstract整数h | 22 | 20 | 1/10 | 1/10 | 1/11 |
| 边界native Z_mid=h | 7/1000 | 1/250 | 3/2 | 3/4 | 3/7 |
| 边界abstract切原子 | 22 | 41/2 | 4/41 | 3/41 | 30/451 |
| 扩大native小common | 1/200 | 3/800 | 4/3 | 1/3 | 1/6 |
| 扩大abstract strict-K | 21 | 41/2 | 2/41 | 1/41 | 20/861 |

每个own-high起点都验证ν概率守恒、完整terminal支持、ν≤ρ_B/h、κ≤ρ_B/h及TV≤tight surplus≤B0/h。abstract前两项active索引22…27；K1.99时为21…27。h41/2把第20号原子只取1/2，β没有被向上或向下取整。

起点效应确实被保留：abstract整数h的TV在起点22为1/21、23为1/11，后续略变；strict-K项所有own-high起点TV均20/861。停止起点不受此结论覆盖，JSON单列其TV而不将它们混入最大值。

native真实q_min1、s2时，s/(qh)分别2000/3、500、1600/3，非常大；本例tiny h绝不能当原small-eps成功。它只验证原秩与量纲口径。ABSTRACT三条eps<1/2才是本轮非平凡小TV检查。

## 3. killed terminal、bottom参考及原soft

仅在三条ABSTRACT模型上附同一个bad旗标：原子0（bottom）与23（高层），每个ρ1，因此C=2<h，b=1−C/h。该flag不称真实opposite source的几何捕获集。对所有safe own-high起点，后向递推killed terminal τ，bad态立即失去质量；s=|τ|。

逐起点核 s≥b、τ≤ν。令w=β/ρ，βsafe=β|bad^c，κgood=βsafe/|βsafe|，严格验证

`τbottom=τw=c·βsafe`，`τrem=τ(1−w)≥0`，`|τrem|≤tight surplus`。

于是条件endpoint τ/s精确是κgood与remainder的正混合；β的分数原子可能同时承载bottom/rem，未假定两者支持不交。核 `TV(τ/s,κgood)≤|τrem|/s` 及 `b|τrem|/s≤B0/h`。这是保一次原soft的有限概率分解，不将条件概率1误写成原soft质量1。

## 4. 本轮主核验：last-active finite-grid

对每个safe-active起点，独立前向计算killed active occupation O，**包含初始active项**，bad active不继续传播。每个last-active a取

`L_a=ρ(B∩D_a)≥h`，`c_a=O_a/Z_a`。

原terminal初段在prefix内的ρ限制恰为最低质量L_a子测度β_(L_a)，所以逐原子精确重建

`τ=Σ_a c_a β_(L_a)^safe`。

另核到原B的总flow（含bad-bottom到达）为Σc_aL_a≤1，因此hΣc_a≤1。没有用“到safe terminal的质量”替代这条上界。

共同网格是预先定义的 `ell_j=h+jδh`，j从0到floor((ρ(B)−h)/(δh))。将每个L_a向下落格，聚合c_j=Σ_bin c_a；所有起点共用同一组β_(ell_j)，不私设起点参考。构造

`τkeep=Σ_j c_j β_(ell_j)^safe`，`τgridrem=τ−τkeep`。

每个起点、每个δ=1/100,1/20,1/5都精确核

`0≤τkeep≤τ`，`|τgridrem|≤δhΣ_jc_j≤δ`，`b|τgridrem|/s≤δ`。

同时把τ/s恢复为这些normalized shared references与remainder的精确正混合；保存每个bin、ell、c_j、原子切分及完整向量。

| ABSTRACT参数 | δ | 共同grid大小 | 全safe-active起点最大grid remainder | 最大原soft条件remainder b·rem/s |
|---|---:|---:|---:|---:|
| K2,h20 | 1/100 | 11 | 0 | 0 |
| 同上 | 1/20 | 3 | 0 | 0 |
| 同上 | 1/5 | 1 | 43/483 | 387/4610 |
| K2,h41/2 | 1/100 | 8 | 3/700 | 333/82000 |
| 同上 | 1/20 | 2 | 1/42 | 37/1640 |
| 同上 | 1/5 | 1 | 32/483 | 1184/18901 |
| K1.99,h41/2 | 1/100 | 3 | 3/700 | 333/82000 |
| 同上 | 1/20 | 1 | 1/42 | 37/1640 |
| 同上 | 1/5 | 1 | 1/42 | 37/1640 |

所有soft remainder都≤其行δ。h20时前两种网格恰对齐L_a=21或22，故remainder为0；这不是一般零误差声明。h41/2则保留非零误差，δ1/100小于原eps且严格改善粗bottom分解。grid总大小不同于每个起点实际使用bin数，二者在JSON分开保存。

两份独立同rank复制仍仅作纯概率诊断：单soft RN为b/s≤1，但b/s²在某些起点>1（JSON保存各值）。它不是真实两来源双路径、没有为第二份添新的soft。

## 5. 复现、误差与计算索引

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r458_numeric.py
```

实际Python3.12.14、python-flint0.9.0、Arb256bits。全部terminal、TV、atom切分、killed occupation、finite-grid、soft费用为Fraction，无浮点误差；Arb仅用于K=e的strict比较，K2/1.99的ties全部有理精确。运行时间字段为诊断浮点，不参与数学判断。

最后实际运行.08秒，最大RSS33,996,800bytes；1340checks PASS。责任为Sol medium；输入全内置，三阶段六个rank模型，无额外scan、repo/他人修改、git或agent。未运行早先计划的静态六几何case。没有用ABSTRACT输入证明几何terminal窗口上界、原high-h/history资格或一般目标。

只交付并冻结 `/tmp/r458_numeric.py`、`/tmp/r458_numeric.json`、`/tmp/r458_numeric.md`。JSON内置compute_index（解释器、命令、输入责任、状态及输出），不另写index或日志文件；同目录自含复现。完成停止。
