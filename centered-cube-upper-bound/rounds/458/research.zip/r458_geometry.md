# R458：双 barrier 原流的有限 canonical 终端分解

本稿保留 R457_joint_kernel 的实际接受权，不把 aζ 删掉后当成用了原历史。新增的是：以任意小的 X 费用，将实际双 whole-avoid 路径的终端分成有限个仅依原来源对的 canonical 核；保留的端点仍在原路径上。根阶 W 总预算尚未证明。

## 1. 准确命题与费用

沿用 R457 的完整记录 ξ、实际初始 own-high exclusive 节点、b=1−C_A(y,z)/h≥ζ、去 soft 流 Π⁰、Sσπ_A² 静态帽。令 Ξ_out 为实际双条件 avoid 提升的父外部分，R_out=|Ξ_out|。所有旧阶段、clock、early、current D_i、初始与旧路径标签都保留。

任意 δ>0，存在原路径测度上的正分拆
\[
\Xi_{\rm out}=\Xi_{\rm can}+\Xi_{\rm err},
\qquad |\Xi_{\rm err}|\le 2S\delta X.\tag{1}
\]
每个来源至多使用
\[
N_\delta=1+\lceil\varepsilon_0/\delta\rceil\tag{2}
\]
个 canonical 终端核。两端联合为实际有限混合，混合系数保留原记录依赖，不能另当免费概率。没有额外 ζ^{-1} 费用。与 R457 合并，仅有
\[
R\le\left[S\zeta+\frac{2S\varepsilon_0}{s}+2S\delta\right]X
   +|\Xi_{\rm can}|.\tag{3}
\]
没有新增 W 费，也没有声称 |Ξ_can| 已获 W 价。若母式该槽系数为 M_old，新增入口费用正是 2M_old SδX；要使它≤ε_add X，取 δ≤ε_add/(2M_old S)，S=0 时零流。旧费用照保，不能暗称总吸收已经完成。

## 2. 来源固有的低秩核及原子

固定来源 x，ρ_x(du)=c_u(x)du/m_u，Z_v(x)=ρ_x{m_u<m_v/K}，
\[
B_x=\{u:Z_u(x)\le h\},\qquad t_x=\rho_x(B_x).
\]
在原 active 来源上，h≤t_x≤h+s/q=(1+ε₀)h。一侧闭质量窗为 s/q：T_x(m)−Z_m(x)≤s/q；故 B_x⊂{T_x(m)≤h+s/q}，闭 CDF 初段容量给上界。下界来自 active 严格前缀包含至少 h 的最低质量。这里 T_x(m)=ρ_x{m_u≤m}，保留原子和阈值等号。

对 0≤ℓ≤t_x，定义 β_{x,ℓ} 为 ρ_x 的最低质量 ℓ 子测度。若分位质量 m_* 处有原子，取
\[
\beta_{x,\ell}=1_{m<m_*}\rho_x+gamma\,1_{m=m_*}\rho_x,
\quad \gamma=\frac{\ell-T_x(m_* -)}{\rho_x\{m=m_*\}}\in[0,1].\tag{4}
\]
无原子时用通常质量分位截断；零分母不作除法。β的质量恰为ℓ，且 β≤ρ_x|B_x。原子的 γ 是辅助保留概率，不假定把原接收中心改为离散点。CDF 与分位构造给可测来源核。

每个 active 状态 a 的严格前缀 D_a={u:m_u<m_a/K} 均包含 β_{x,h}。令
\[
L_x(a)=\rho_x(D_a\cap B_x)\in[h,t_x],\quad
j_x(a)=\left\lfloor\frac{L_x(a)-h}{\delta h}\right\rfloor,
\quad\ell_j=h+j\delta h.\tag{5}
\]
于是 β_{x,ℓ_j}≤ρ_x|D_a∩B_x，且 L_x(a)−ℓ_j<δh。只有(2)范围内的 j 会出现。

## 3. killed 最后一步的精确分解

固定 ξ，以 x=y、对侧 x'=z 为例。初始节点捕 x 排 x' 且 own-high。运行原严格质量下降链，落入捕 x' 的节点立即杀死；否则在 B_x 停止。τ_ξ 是未归一的成功终端测度，a_ξ=τ_ξ(E) 为 whole-avoid 成功概率。R423 总 Green 给 a_ξ≥b；这里不重复把每代帽相加。

令 O_ξ 为杀死前 active 状态的总占用（包含初始 active 状态），定义
\[
c_{\xi,j}=\int_{j_x(a)=j}\frac{O_\xi(da)}{Z_a(x)}.\tag{6}
\]
这些保留了真实最后 active 父的标签。未杀死原链终端概率为1，且每个 active 前缀完整包含 β_{x,h}，故其 active occupation O_raw 满足
\[
1\ge h\int O_{\rm raw}(da)/Z_a(x).
\]
O_ξ≤O_raw 因为杀死只删路径，从而
\[
\sum_jc_{\xi,j}\le1/h.\tag{7}
\]
这不是把 occupation 归一成概率。

给实际最后一步 a→u∈B_x 的终端附一个保留标签，保留概率为 dβ_{x,ℓ_{j_x(a)}}/dρ_x(u)。这是原路径的正分拆，不换端点。最后一步公式及 Tonelli 得
\[
\tau_\xi=\sum_jc_{\xi,j}\,\beta_{x,\ell_j}^{\,x'}+\tau_{\xi,\rm err},
\quad
\beta_{x,\ell_j}^{\,x'}(du)=(1-c_u(x'))\beta_{x,\ell_j}(du),\tag{8}
\]
\[
|\tau_{\xi,\rm err}|
\le\int\frac{O_\xi(da)}{Z_a(x)}[L_x(a)-\ell_{j_x(a)}]
\le\delta.\tag{9}
\]
safe 限制只减少括号内被删质量。部分质量原子按(4)的 γ 保留，所以(8)也在原子边界准确成立；没有假定半原子具有新的 cube 几何。

令 b_{x,j}(x')=β_{x,ℓ_j}^{x'}(E)，在 c_{ξ,j}>0 的分量定义
\[
\kappa_{x,j}^{x'}=\beta_{x,\ell_j}^{x'}/b_{x,j}(x'),\qquad
\omega_{\xi,x,j}=c_{\xi,j}b_{x,j}(x')/a_\xi.\tag{10}
\]
实际非零 bin 的 β位于真实 last-active 前缀，故 m_u<m_A/K²，并位于原 C_A 的质量范围；因此 b_{x,j}(x')≥ℓ_j−C_A(x,x')≥bh>0。零系数分量无需定义条件概率。κ只依 x,x',j 及固定原场，不依 A 或起点；“非零 bin”及混合系数仍依实际记录。

条件 whole-avoid 后，终端律精确为 Σ_jω_{ξ,x,j}κ_{x,j}^{x'} 加剩余，且
\[
1-\sum_j\omega_{\xi,x,j}=|\tau_{\xi,\rm err}|/a_\xi\le\delta/a_\xi.\tag{11}
\]
两端独立仅限给定原完整 ξ 的 R457 新路径。按各端真实 last-parent 分拆，双侧任一剩余的条件概率≤δ/a_y+δ/a_z。乘回原 soft b，使用 b≤a_y,a_z，得到每 ξ 的损失≤2δ。再用 Π⁰静态帽积分得(1)，不多乘阶段数或 N_δ²。

可选的全 B 支持核验：定义严格CDF F_{x,-}(t)=ρ_x{m_u<t}。若原 Z_A(x)>(4−ε₀)h 且 ε₀≤1/2，则两闭窗支配半开带，给 F_{x,-}(m_A/K)−F_{x,-}(m_A/K³)=ρ_x{m_A/K³≤m_u<m_A/K}≤2ε₀h，故 F_{x,-}(m_A/K³)>(4−3ε₀)h>h。任何 m_u≥m_A/K² 都有 Z_u(x)=F_{x,-}(m_u/K)≥F_{x,-}(m_A/K³)>h，因此整个 B_x 在 m_u<m_A/K² 内。这样保留了u恰在阈值时的严格端点。本证明只需更弱的“实际非零 bin 位于最后前缀”，不依赖对新节点赋原高秩门。

## 4. 实际接受权、父外限制与未付项

先在父外删除之前作(8)，最后保留 u,v∉Q_A。积分原标签后，保留的端点投影为
\[
 d\Xi_{\rm can}=S\sigma(dA)\pi_A(dy)\pi_A(dz)
 \sum_{j,k}a'_{jk}(A,y,z)
 \kappa_{y,j}^{z}(du)\kappa_{z,k}^{y}(dv)
 1_{u,v\notin Q_A},\tag{12}
\]
\[
 a'_{jk}=b\,a_\zeta\,
 E[\omega_{\xi,y,j}\omega_{\xi,z,k}\mid A,y,z;\Pi^0],
 \qquad \sum_{j,k}a'_{jk}\le b a_\zeta.\tag{13}
\]
原接受权更新成实际 a'，没有声称 a 完全不变。所有原 stage/current/history 通过条件记录和真实系数保留；每个保留端点仍可连同其真实 whole-avoid 路径交付。新 terminal 不获取旧历史资格。

这比起点依赖的 terminal law 更具体：统一有限来源核，任意小的整流损失，真正父外几何仍由(12)保留。缺口是实际接受系数加权后的跨父总价；κ的全源列只在未 safe 归一的 β/h 层满足 ∫f(x)β_{x,ℓ}(du)/ℓ dx≤du/ℓ，而 safe 归一分母与另一原来源相关。不能删 a'、不能按 N_δ² 重新收同一来源费，也不能以各核总质量1直接得到 W。尚无 |Ξ_can|≤εX+C_ε s polylog(n+2)W 的证明，本轮不宣称闭合。

## 5. 本机有限核验证

指定 Python 已实际运行以下代码：三组 δ=1/2,1/4,1/10，各65个 active-start 实例，共195；逐终端2340次比较全部通过，675次 bin 具有部分质量原子。核验的是严格质量轴 killed Markov 核、实际 last-parent thinning、(7)–(11)，不是 native cube/完整原历史实现。最初试运行的参数表无 active 例，之后一次表长错误触发 IndexError；均未计成功证据。下面是最终实际通过的完整代码，可直接复制运行；没有另写任务授权范围外文件。

```python
from fractions import Fraction as F
m=list(map(F,[1,2,3,4,5,6,8,12,30,80,200,500]))
h=F(19,20);K=F(2)
patterns=[[F(1,7)]*12,[F(1,8)]*12,[F(1,9)]*12,
          [F(x,40) for x in [3,4,5,4,3,5,4,3,4,5,4,5]]]
counts={};checks=fracbins=cases=0
for delta in [F(1,2),F(1,4),F(1,10)]:
 stage=0
 for weights in patterns:
  assert len(weights)==len(m)
  z=[sum((weights[j] for j in range(len(m)) if m[j]*K<m[i]),F(0))
     for i in range(len(m))]
  B=[i for i in range(len(m)) if z[i]<=h]
  t=sum((weights[i] for i in B),F(0))
  assert h<t<=F(3,2)*h and any(v>h for v in z)
  def beta(ell):
   result=[]
   for w in weights:b=min(ell,w);result.append(b);ell-=b
   assert ell==0
   return result
  for mask in [(0,), (1,3), (0,2,5), (4,7), ()]:
   bad=set(mask);cross=sum((weights[i] for i in bad),F(0))
   assert cross<h
   for start in range(len(m)):
    if z[start]<=h or start in bad:continue
    occ=[F(0)]*len(m);occ[start]=1
    term=[F(0)]*len(m);coefs={};direct=[F(0)]*len(m)
    for i in reversed(range(len(m))):
     if z[i]<=h:term[i]+=occ[i];continue
     pref=[j for j in range(i) if m[j]*K<m[i]]
     la=sum((weights[j] for j in pref if j in B),F(0))
     assert h<=la<=t
     jbin=int((la-h)/(delta*h));ell=h+jbin*delta*h
     assert ell<=la<ell+delta*h
     be=beta(ell)
     fracbins+=any(0<b<w for b,w in zip(be,weights))
     coefs[jbin]=coefs.get(jbin,F(0))+occ[i]/z[i]
     for j in pref:
      if j not in bad:
       flow=occ[i]*weights[j]/z[i];occ[j]+=flow
       if j in B:direct[j]+=flow*be[j]/weights[j]
    a=sum(term,F(0));assert a>=1-cross/h and a>0
    kept=[F(0)]*len(m)
    for jbin,c in coefs.items():
     be=beta(h+jbin*delta*h)
     for j in range(len(m)):
      if j not in bad:kept[j]+=c*be[j]
    assert sum(coefs.values(),F(0))<=1/h and kept==direct
    for j in range(len(m)):
     assert 0<=kept[j]<=term[j]
     checks+=1
    rem=a-sum(kept,F(0));assert 0<=rem<=delta
    assert (1-cross/h)*rem/a<=delta
    stage+=1;cases+=1
 counts[str(delta)]=stage
assert cases and fracbins
print({'PASS':True,'phase_cases':counts,'total_active_cases':cases,
       'coordinate_checks':checks,'fractional_bin_occurrences':fracbins,
       'scope':'finite strict-mass killed chains, exact last-parent thinning; not native cubes/history'})
```
