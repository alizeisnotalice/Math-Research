from fractions import Fraction as F

checks = 0
def ck(p):
    global checks
    assert p
    checks += 1

# Three bounded stages, all center domains have positive Lebesgue volume.
# f = 1 on [-4,4]^16 plus a central nonnegative packet of stated mass.
n = 16
for eps, bump in [(F(1,100),F(0)),(F(1,200),F(1)),(F(1,1000),F(16))]:
    ma, mt = F(2**n)+bump, F(1)
    qA = ma/F(2**n)
    ck(F(1) <= qA <= F(4,3))
    ck(ma > 3**8)  # e^8 < 3^8, hence actual K^2=e^8 gap.
    ck(F(6,5)-eps > 1+eps) # every terminal center outside every parent.
    ck(F(6,5)-eps-F(1,2) > F(1,20)) # central packet excluded.
    ck(F(9,10)+F(1,100) < 1-eps) # source y packet inside every parent.
    ck(F(9,10)-F(1,100) > F(6,5)+eps-F(1,2))
    ck(F(9,10)+F(1,100) < F(6,5)-eps+F(1,2))
    ck(2*(F(6,5)-eps) > 1) # terminal cubes disjoint.
    ck(F(1,20)+eps < 1) # every parent captures the central source packet.
    ck(2*eps < 1) # parent center block inside every parent cube.
    p = eps**n
    ck(p == (2*eps)**n/F(2**n))
    ck(p > 0)
    ck((2*eps)**(3*n) > 0)
    # Matching reservoir estimate, even without using actual overlap volumes.
    exterior_lower = ma-2*mt
    ck(exterior_lower/ma >= 1-F(2,2**n))
    # Rational verification of the reservoir reweighting for several retained loads.
    for load in [F(0),F(1,7),F(1),F(3,2)]:
        d = exterior_lower/ma
        ck(load/ma == load*exterior_lower/(d*ma*ma))
    print(f"stage eps={eps} bump_mass={bump}: matched qA={qA}, p_x(A)={p}")
print(f"PASS {checks} exact Fraction assertions; native positive center/source blocks, not original-history realization.")

# Canonical atomic quantile checks, separate from the native geometry above.
def canonical(masses, rho, h):
    remaining=h
    weights=[]
    for r in rho:
        w=min(F(1),remaining/r) if r else F(0)
        weights.append(w)
        remaining-=r*w
    ck(remaining==0)
    return weights

atomic_start=checks
for shift in range(6):
    masses=[F(1),F(2),F(3),F(4)]
    mu=[F(2+shift,5),F(3,5),F(4,5),F(6,5)]
    cy=[1,1,0,1]
    cz=[0,1,1,1]
    h=F(1)
    wy=canonical(masses,[v*c for v,c in zip(mu,cy)],h)
    wz=canonical(masses,[v*c for v,c in zip(mu,cz)],h)
    # Recover the cutoff step functions at zero-capture atoms as well.
    def fullstep(w,c):
        cutoff=max(i for i in range(4) if c[i] and w[i]>0)
        return [F(1) if i<cutoff else w[i] if i==cutoff else F(0) for i in range(4)]
    wy,wz=fullstep(wy,cy),fullstep(wz,cz)
    ck(all(a<=b for a,b in zip(wy,wz)) or all(b<=a for a,b in zip(wy,wz)))
    py=[m*c*w for m,c,w in zip(mu,cy,wy)]
    pz=[m*c*w for m,c,w in zip(mu,cz,wz)]
    common=[min(a,b) for a,b in zip(py,pz)]
    ry=[a-b for a,b in zip(py,common)]
    rz=[a-b for a,b in zip(pz,common)]
    dy=sum(a for a,c in zip(py,cz) if not c)
    dz=sum(a for a,c in zip(pz,cy) if not c)
    d=max(dy,dz)
    ck(sum(common)==1-d)
    coupling=[[common[i] if i==j else F(0) for j in range(4)] for i in range(4)]
    if d:
        for i in range(4):
            for j in range(4):
                coupling[i][j]+=ry[i]*rz[j]/d
    for i in range(4):
        ck(sum(coupling[i])==py[i])
        ck(sum(coupling[j][i] for j in range(4))==pz[i])
    safe=sum(coupling[i][j] for i in range(4) for j in range(4) if not cz[i] and not cy[j])
    ck(safe==min(dy,dz))
    if safe:
        ck(dy*dz/d==safe)
print(f"canonical atomic PASS {checks-atomic_start} assertions; total PASS {checks}.")
