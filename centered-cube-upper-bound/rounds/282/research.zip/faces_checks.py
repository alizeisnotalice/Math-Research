from fractions import Fraction as F
import math

# Geometric fixture only: a=16,n=4 gives d=1 exactly.
y = (F(49, 100), F(1, 5), F(3, 10), F(2, 5))
z = (F(51, 100), F(1, 5), F(3, 10), F(2, 5))
assert sum(abs(a - b) for a, b in zip(y, z)) <= F(1, 2)
rect = [(-F(31, 2), F(1, 2))] * 4
assert all(l <= v <= r for v, (l, r) in zip(y, rect))
assert not all(l <= v <= r for v, (l, r) in zip(z, rect))


def cell(p, K):
    d = F(1, 2**K)
    return [(d * (v // d), d * (v // d + 1)) for v in p]


def full(cs):
    return all(l <= cl and cr <= r for (cl, cr), (l, r) in zip(cs, rect))


assert not full(cell(y, 0))
assert full(cell(y, 1))
assert cell(y, 1) != cell(z, 1)
assert all(full(cell(y, K)) for K in range(1, 15))

# Every failure with y inside its rectangle forces distance to one face <=delta.
checks = 0
for K in range(8):
    for j in range(1, 100):
        p = (F(j, 200),) * 4
        cs = cell(p, K)
        if not full(cs):
            assert min(min(v - l, r - v) for v, (l, r) in zip(p, rect)) <= F(1, 2**K)
        checks += 1

# Entropy chain rule, exact probability masses and floating logarithms.
m = [F(i, 36) for i in range(1, 9)]


def H(ps):
    return -sum(float(p) * math.log(float(p)) for p in ps if p)


coarse = [sum(m[i:i + 2]) for i in range(0, 8, 2)]
chain = H(coarse) + sum(
    float(c) * H([m[i] / c, m[i + 1] / c])
    for i, c in zip(range(0, 8, 2), coarse)
)
assert abs(H(m) - chain) < 1e-14
assert H(m) <= math.log(8) + 1e-14
print({
    'geometry_checks': checks,
    'entropy_chain_residual': abs(H(m) - chain),
    'off_diagonal_pair_preserved': True,
    'status': 'PASS',
})
