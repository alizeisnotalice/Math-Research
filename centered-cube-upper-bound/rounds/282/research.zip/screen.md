# R282 independent refinement-coverage screen

**PASS for constructive coverage and the finite-K bounds below, with precise almost-everywhere and parameter qualifications. No uniform root budget or global closure follows.** This screen was completed before reading `/tmp/r282_faces.md` or any R282 author proof. Current R281 allocation definitions and independently proved entropy/cap tools are the inputs.

## Definitions and exact refinement

Fix n>=1, 0<a<=b<=2a, lambda>0, d=a/(8sqrt(n)), the same original sources rho,nu finite positive L1, actual measurable selectors, and the current R281 hypotheses including ns(x)<=D. Let the probability-one uniformly shifted coarse d-grid be independent of the original data. For each coarse C, refine only the y-source restriction into its nested dyadic descendants C_K(y), of side delta=d2^(-K); keep z in the original coarse C. Keep the SAME coarse same-cell denominator P_d(y-z), which is at least 1/2 on original near.

Replace the R281 latent-whole-C containment indicator by whole-C_K(y) containment in the original latent rectangle, using the ORIGINAL latent law pi_s(x) and density. This defines A_K. It is not a new fine same-cell event or a replacement source. Then 0<=A_K<=1, A_0=A_lat exactly, and A_K is increasing: the closure of a nested descendant is a subset of its parent's closure. The same original pair (y,z) is retained even when the pair lies in different fine descendants.

For each FIXED x and latent rectangle with positive finite side lengths, the latent input density is supported on that rectangle. Every y strictly inside it eventually has its whole descendant contained in it. Its finitely many faces have rho measure zero because rho is L1. Thus dominated convergence and Tonelli give p_y A_K -> p_y for rho-a.e. y (and for the original near z averaging) at that fixed receiver. In particular A_K ->1 on p_y>0 in the original traffic measure; zero p_y has zero traffic and may retain the zero convention. A correct quantifier is 'for each fixed receiver/rectangle, almost everywhere', followed by Fubini for the actual measurable selector. There is generally no single rho-null set that works simultaneously for every possible receiver and every possible rectangle. This distinction does not obstruct the integrated coverage statement.

## Finite-K entropy price

For a fixed coarse C with m_C=rho(C)>0 let p_B=rho(B)/m_C for its depth-K descendants and H_C,K=sum_B p_B log(1/p_B), zero terms omitted. Let H=0 if m_C=0. There are 2^(nK) descendants, so H_C,K<=nK log2. Restricting the real source to these descendants does not change its internal distribution.

The same common-soft and upward-radius domination as R281 applies with the descendant-containment masks. Each descendant-centered aspect profile still has weak constant one. Mixing the normalized descendant mass probabilities into the M fixed shape laws adds exactly H_C,K to each law's entropy. Therefore the actual coarse-cell allocated input has a positive weak envelope with weak constant

m_C [L_(n,D)+2 e^2 M H_C,K].

The actual total allocated F_C,K/q cap remains at most 1, because the subkernel is <=the actual p. No descendant, aspect, or soft menu component receives FIRST separately. The hard source remains the whole coarse nu|C, so the same coarse kappa_d=2+nlog(1+d/a), not a new fine radius, applies. The two actual caps and the already proved I-log-kappa bound thus give per coarse cell

integral F_C,K G_C/q
 <=(16/3)(1+log kappa_d)m_C [L_(n,D)+2 e^2 M H_C,K]+nu(C).

The near bound uses at most the original factor 2 from P_d^-1, then sums the original coarse masses once. Finite-K total entropy is at most nKlog2 times W_rho. It is finite but can grow with K; constructive coverage is not a uniform-price argument. Actual clock/score fees can be attached exactly as in R281 because A_K is static in the auxiliary clock and pair slots.

## Quantitative tail: the proposed constants are valid

Let rho have density f_rho. For B>0 write rho<=B dx+rho_h with rho_h=(f_rho-B)_+dx. Set A=1+nlog(b/a), q_-=3lambda/4. The raw remaining near source mother obeys

T_tail,K <= [2 B n delta/(a q_-)] A W_nu
            +(16/3)e M A ||rho_h||.

There is no additional obligatory factor 2 in either term, but the proof must retain the following structure.

### Bounded-density part: direct grid-independent slab cancellation

For each fixed latent input rectangle I(x,L,r), if it contains y but not the whole delta-descendant containing y, then y lies within distance delta of one of I's faces. Denote that deterministic union of inside boundary slabs by S_delta(x,L,r). It is independent of the coarse shift, the particular coarse C, and z. Thus, for each shift, the latent loss times the same-coarse-pair indicator is bounded by H_(r,L)(x-y) 1_Sdelta times that pair indicator. After averaging shifts, the latter indicator is EXACTLY P_d(y-z). Hence it cancels the coarse denominator before any factor-two majorization:

p_y(1-A_K) <= integral H_(r,L)(x-y)1_Sdelta(x,L,r)(y) pi_s(x)(dr).

A normalized rectangle's inside delta-slabs have total mass at most (2delta/L) sum_i 1/r_i. The original latent law satisfies E[1/r_i]=(1-s)+s phi(0)<=1, since the interval mixture at zero is E_mu[1/r]=phi(0)<=1. Consequently the bounded-density y integral is at most 2Bn delta/a. Drop near only after this bound, divide by q_-, and use the actual adaptive hard envelope's exact L1 price A to obtain the first term above. This cancellation works without assigning any component FIRST.

An alternative proof first uses P_d^-1<=2, drops coarse pair containment, then uses the uniform fine-grid phase. Its average lost interval length is min(width,delta), not 2delta, giving the same constant. If one instead combines the factor-two coarse majorant with a deterministic 2delta slab estimate, one gets a valid but weaker coefficient 4, not the displayed coefficient 2. The direct deterministic-slab cancellation above justifies the sharper proposed statement.

### Heavy-density part: use the original allocation bound directly

Use 0<=1-A_K<=1 on the original measure; do not introduce P_d^-1. On actual E use h_R*nu<=4lambda and q>=q_- first. The actual input p has a common soft-node domination by e times M fixed latent shape laws. For each fixed shape, the homothetic normalized rectangle all-L envelope on [a,b] has exact L1 mass A, by the same radial-volume calculation as the cube envelope after a fixed diagonal change of variables. Therefore integral_E p_actual(x-y)dx<=e M A for each fixed y. The remaining source restriction contributes at most (4lambda/q_-)e M A||rho_h||=(16/3)e M A||rho_h||. This is a direct source-tail bound, not a cap for each component.

## Limits and scope

For each fixed finite original parameter block, rho_h mass tends to zero as B tends to infinity by L1 truncation. Choose B first, then K large enough that delta tends to zero in the first term. Both monotone coverage and this explicit tail bound show input-by-input convergence. Outer parameters, a,lambda,D,M and source masses cannot be treated as uniform without an additional established bound; an outer expectation needs its own integrable control or a separately justified parameter choice.

This does NOT pay the complete limit at a root price. The finite-K source entropy/weak price can diverge as K increases, while the density truncation and necessary K depend on the actual input. No summation of infinitely many new payments with repeated epsilon is licensed. Any old positive paid portions must be removed first, and A_K used on the actual remaining allocation; original sources, posterior normalizers and negative credits remain unchanged.

## Actual local-tool check

I ran 12 exact Fraction checks of the alternative averaged-grid identity, using delta in {1/8,1/32,3/16} and interval widths {1/64,1/4,1,11/8}. Uniform phase integration was done exactly on its breakpoints; expected whole-cell covered length equalled (width-delta)_+, and loss equalled min(width,delta). Output: PASS 12. These finite algebra checks do not replace the continuous slab proof or certify FULL instances.

```python
from fractions import Fraction as F
from math import floor
N=0
for delta in [F(1,8),F(1,32),F(3,16)]:
 for width in [F(1,64),F(1,4),F(1),F(11,8)]:
  rem=width%delta
  knots=sorted(set([F(0),rem,delta]))
  avg=F(0)
  for l,h in zip(knots,knots[1:]):
   q=(l+h)/2
   number=max(0,floor((width-q)/delta))
   avg+=(h-l)*number*delta
  avg/=delta
  assert avg==max(F(0),width-delta)
  assert width-avg==min(width,delta)
  N+=1
print('PASS',N,'exact averaged full-cell coverage identities')
```

Independent screen complete. Author proof has not yet been read; awaiting its specified frozen version for final review.
