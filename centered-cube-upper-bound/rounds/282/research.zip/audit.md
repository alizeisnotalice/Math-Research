# R282 final independent audit: one-sided refinement and arbitrary-L1 tail

**PASS. No necessary mathematical correction.** This is constructive coverage with an explicit finite-depth entropy charge and input-dependent tail control. It is not a uniform root-budget proof or global maximal-operator closure.

## Bound versions and chronology

Author `/tmp/r282_faces.md` SHA256:
`af89b00cb4fb8f07b12f4a88c355a9510a09a41f4ed49c27aa59d50b9e4c58ff`.

Independent statement screen `/tmp/r282_screen.md` SHA256:
`b1249b5fd126869747b64f5ff831b39a118d3065fddbafe1108aa4429d4bd360`.

The screen was saved before reading the author file. The current R281 definitions and already audited entropy/cap tools were permitted inputs. The author SHA was checked on opening the complete proof; no author or repository file was changed.

## 1. Coverage, original pairs, and quantifiers

The nested depth-K descendants refine only the y-source cell. Keeping z anywhere in the original coarse C makes F_C,K G_C the exact positive sum over all fine descendant pairs D,E, including D!=E. The denominator remains the coarse P_d, not the fine same-cell probability. Thus off-diagonal source pairs are not lost or charged a neighbor count.

The indicators of whole-descendant containment increase under refinement, so 0<=A_K<=A_(K+1)<=1 and A_0=A_lat. For each fixed actual x and latent rectangle, its faces have rho measure zero because the original rho is L1. Every strictly interior y eventually has its whole descendant contained. Tonelli with the actual receiver-dependent latent law, rho, nu, the independent analysis shift and the original measurable positive weights proves convergence in the original near mother. This is the legitimate fixed-receiver/rectangle almost-everywhere statement followed by Fubini; it is not a claim that a single null set works for every possible receiver and every rectangle simultaneously. Where p_y=0 the original traffic is zero and the zero allocation convention need not converge to 1.

The construction does not change the original source law, auxiliary posterior, actual selector, or coarse near condition. No deleted carrier or signed negative credit is invoked.

## 2. P1 finite entropy price

For one frozen coarse C, the descendants are a finite actual source partition. Their normalized rho masses add a fixed entropy H_C,K to each of the M normalized rounded-shape label laws. Applying the proved weak-sum theorem once to the full descendant-and-shape family gives

||F_C,K||_(1,infinity)
 <=rho(C)[L_(n,D)+2e^2 M H_C,K].

The total weak mass is e^2 M rho(C); the extra entropy coefficient is therefore exactly 2e^2 M rho(C). The descendant profile centers vary, but each has the same weak constant one; no concentricity or profile independence is needed. The shape probabilities and the actual descendant masses are frozen in x. The actual total F_C,K/q cap remains <=1 from subkernel domination by p_y. No descendant or shape node gets FIRST separately.

The hard response stays the whole coarse nu|C. The old R251 cluster constant remains kappa_d with coarse side d. Its actual cap remains 4lambda on E. The two-cap logarithmic inequality yields the displayed per-coarse-cell bound and, after the sole positive 1/P_d<=2 majorization, exactly P1. The hard mass is added once per coarse cell, not once per descendant. Countable coarse cells and shifts use positive Tonelli. H_K<=nKlog2 W_rho is correct, as is the exact entropy chain rule (3). It is finite for every K and need not be uniformly bounded as K grows.

## 3. P2 constants: the coarse factor does not double them

Equation (4) is the key valid cancellation. On a latent rectangle's support, failure of whole-delta-descendant containment implies y belongs to its deterministic inside delta-face slab. This slab is independent of the shift and z. Thus each same-coarse event times the latent loss is bounded by the same event times the deterministic slab kernel; its shift average is P_d times that slab kernel. Dividing by P_d cancels exactly. One must not insert 1/P_d<=2 at this step and then retain the same constant.

The normalized inside slab mass is <=sum_i 2delta/(Lr_i). The original mixture has E(1/r_i)=(1-s)+s phi(0)<=1, giving the pointwise low-density source bound 2Bn delta/a. Using the adaptive hard L1 envelope only after this bound gives exactly the first P2 term, with q_- and A as stated. The author sentence “outside this slab” is read on the rectangle support, as in the displayed integral; outside the rectangle the latent density itself vanishes.

For the high-density restriction rho_hi=rho 1_{density>B}, use 1-A_K<=1 directly. First use the actual hard cap and q>=q_- on E, giving 16/3. The positive common-soft-node envelope costs e times a sum of M fixed laws. For every fixed aspect r, the normalized all-L homothetic-rectangle envelope has exact L1 mass A=1+nlog(b/a): a fixed diagonal change of coordinates reduces it to the cube calculation and its determinant cancels the shape normalization. Therefore the actual full selector response has L1 upper bound e M A, proving exactly the second P2 term. This bound does not swap a supremum past an integral in the wrong direction; the displayed positive envelope dominates it. No factor-two same-cell loss is introduced for the heavy part.

The density split used by the author is legitimate: rho_lo=rho 1_{density<=B}<=B dx and rho_hi as displayed sum to the original rho. Its high mass tends to zero for every L1 rho. A clipped-density split with (density-B)_+ would also work but is not necessary.

## 4. P3 and original clock/ledger

With A_0=A_lat, R_old=(Ab-A_sc)(1-A_0) has the exact split

R_old=(Ab-A_sc)(A_K-A_0)+(Ab-A_sc)(1-A_K).

Every factor is nonnegative. The new part is bounded by A_K, and the leftover by 1-A_K. Thus P1 and P2 separately bound those actual positive portions without recharging A_0 or the single-cut terms. Their allocations are static in auxiliary time and the two posterior slots. The original R2 mask gives the same already proved scalar B_D; outside 2Lambda is counted once when passing to original traffic, and the actual unique j mask is not copied into a new source sum.

For each fixed finite parameter block, first choose B so the high-density tail term is small, then K so delta_K is small. This proves input-by-input coverage with an explicit raw tail criterion. It supplies no source-uniform bound on the finite-K price, since H_K and necessary B,K can depend on the actual density. The stopping/first-contained increments are nonnegative but their stopping labels depend on actual receiver and shape; they are not automatically an x-independent probability partition. The author correctly exposes rather than deletes that entropy cost.

## 5. Elementary extension to the original full terminal ledger

This extension uses the original SAME disjoint terminal-leaf collection, rho_V<=1_V f dx, W_nu<=||f||_1, fixed global lambda>0, fixed n, and a uniform D (hence uniform M). It does not infer those hypotheses for arbitrary repeated blocks.

Let A_max=1+nlog2, q_-=3lambda/4, and r_V be the density of rho_V. For every seed,

sum_V ||rho_V 1_{r_V>B}||
 <=integral f 1_{f>B},

because r_V<=f on its disjoint V and r_V>B implies f>B. The same bound holds after the normalized seed expectation. Further,

delta_K/a=(8sqrt(n))^(-1)2^(-K)

is independent of the varying a. Summing P2 therefore gives the honest global raw bound

T_tail,K,total
 <= [B sqrt(n)/(4q_-)] 2^(-K) A_max ||f||_1
     +(16/3)e M A_max integral f 1_{f>B}.

Equivalently its first coefficient is Bsqrt(n)/(3lambda). Thus one may choose a common B and K for all those leaves/scales, first B and then K, without any free limit/expectation exchange. Multiplication by a common 2Lambda B_D gives the original positive tail. If D varies but has a proved uniform upper bound, use the corresponding common M and B_D; without such uniform hypotheses retain the actual weighted sums.

The P1 entropy sums are still only bounded by nKlog2 W_rho. This full-ledger tail convergence does NOT turn the P1 price into a uniform root-polylog input budget. No repeated epsilon or infinitely summed payments have been licensed.

## Actual finite evidence and its limit

The independent screen includes an actually executed 12-case exact Fraction check of averaged fine-cell coverage and its full reproducible code. That is an auxiliary consistency check, not the analytic basis of P1-P3.

The author subsequently supplied `/tmp/r282_faces_checks.py`, SHA256 `a0a4b8f59bd82fba1af27e66b2f5279d10703aaa6f347735b7b85c6a34a8a662`. I checked its hash, read the complete code, and actually ran it. Output:

`{'geometry_checks': 792, 'entropy_chain_residual': 0.0, 'off_diagonal_pair_preserved': True, 'status': 'PASS'}`

The 792 count is 8 depths times 99 listed point/rectangle cases, with exact Fraction implications on failing containments. The separate exact fixture checks retention of a near pair in different fine cells; the entropy-chain residual is ordinary floating logarithm arithmetic on rational masses. These are finite diagnostic examples, not an original FULL traffic/history construction, a universal coverage test, or an interval certificate. The zero reported float residual is not an exact symbolic logarithm proof. No numerical result is used to prove the general coverage, entropy, slab cancellation or source budget.

Audit complete; the precise unproved issue is a uniform root-price control of the source-label entropy/first-containment contribution, not coverage or loss of fine off-diagonal pairs.
