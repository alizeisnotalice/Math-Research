#!/usr/bin/env python3
"""R282 one-sided dyadic input bookkeeping and entropy-fee diagnostics."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as m

def enc(x):return m.nstr(x,90)
def mpf(q):return m.mpf(q.numerator)/q.denominator
SEED=28217
DIMS=[('initial',1),('initial',2),('stress',4),('stress',8),('expanded',16),('expanded',32)]
DEPTHS=[1,2,4]
def points(n):
 # Eight correlated centers, not a product law; physical source boxes fit all K<=4.
 inside=[tuple(F(1+4*((i*i+3*i*j+j*j+SEED)%16),64) for j in range(n)) for i in range(8)]
 # The formulas can repeat centers, which means superposed positive densities, not extra independent coordinates.
 return inside+[tuple(F(-1,64) for _ in range(n)),tuple(F(65,64) for _ in range(n))]
def inside(p):return all(0<=x<1 for x in p)
def cell(p,K):return tuple((x*2**K).numerator//(x*2**K).denominator for x in p)
def massweights():
 rho=[F(i+1,36) for i in range(8)]+[F(1,7),F(2,7)]
 raw=[((5*i+3)%11)+1 for i in range(8)];den=sum(raw)
 nu=[F(3*x,2*den) for x in raw]+[F(1,9),F(2,9)]
 return rho,nu

def exact_bookkeeping():
 rows=[];models=[];box_side=F(1,256)
 for phase,n in DIMS:
  pts=points(n);rho,nu=massweights();rhoC=sum((r for p,r in zip(pts,rho) if inside(p)),F(0));nuC=sum((v for p,v in zip(pts,nu) if inside(p)),F(0))
  models.append({'phase':phase,'n':n,'center_count':len(pts),'centers_exact':[[str(x) for x in p] for p in pts],'rho_masses_exact':[str(x) for x in rho],'nu_masses_exact':[str(x) for x in nu],'box_side_exact':str(box_side),'rho_C_exact':str(rhoC),'nu_C_exact':str(nuC),'coordinate_dependence':'deterministic correlated centers and unequal joint masses; no coordinate independence assumed'})
  for K in DEPTHS:
   rb={};nb={}
   for p,r,v in zip(pts,rho,nu):
    if inside(p):
     key=cell(p,K);rb[key]=rb.get(key,F(0))+r;nb[key]=nb.get(key,F(0))+v
     # The entire positive-volume box lies strictly inside this dyadic cell.
     for x,idx in zip(p,key):assert F(idx,2**K)<x-box_side/2<x+box_side/2<F(idx+1,2**K)
   one=sum((r*nuC for r in rb.values()),F(0));full=rhoC*nuC;same=sum((r*nb.get(k,F(0)) for k,r in rb.items()),F(0));off=full-same
   assert sum(rb.values())==rhoC and one==full and off>=0
   near=F(0);refined=F(0);near_same=F(0);pointwise=0
   for i,y in enumerate(pts):
    for j,z in enumerate(pts):
     coarse=inside(y) and inside(z);ref=sum(int(cell(y,K)==key and inside(y) and inside(z)) for key in rb)
     assert ref==int(coarse);pointwise+=1
     mask=sum(abs(a-b) for a,b in zip(y,z))<=F(1,2)
     if mask:
      near+=rho[i]*nu[j]*int(coarse);refined+=rho[i]*nu[j]*ref
      if coarse and cell(y,K)==cell(z,K):near_same+=rho[i]*nu[j]
   assert near==refined
   rows.append({'phase':phase,'n':n,'K':K,'occupied_rho_cells':len(rb),'rho_C_exact':str(rhoC),'nu_C_exact':str(nuC),'one_sided_mass_exact':str(one),'coarse_pair_mass_exact':str(full),'same_fine_cell_mass_exact':str(same),'discarded_offdiagonal_mass_exact':str(off),'near_l1_radius_exact':'1/2','near_coarse_point_mass_exact':str(near),'near_one_sided_point_mass_exact':str(refined),'near_samecell_point_mass_exact':str(near_same),'pointwise_membership_checks':pointwise,'normalized_sparse_rho_cell_probabilities_exact':[str(v/rhoC) for _,v in sorted(rb.items())]})
 return {'models':models,'cases':rows}
def H(ps):return -sum((mpf(p)*m.log(mpf(p)) for p in ps if p>0),m.mpf(0))
def run(dps,book):
 with m.workdps(dps):
  weights=[F(1,6),F(1,3),F(1,2)];hw=H(weights);rows=[]
  for row in book['cases']:
   n,K=row['n'],row['K'];ps=[F(x) for x in row['normalized_sparse_rho_cell_probabilities_exact']];assert sum(ps)==1 and sum(weights)==1
   hp=H(ps);flat=H([w*p for w in weights for p in ps]);rhs=hw+hp;res=abs(flat-rhs);assert res<m.mpf(10)**(-dps+8)
   count=2**(n*K);uniform_mass=F(1,count)
   uniform_entropy=-m.log(mpf(uniform_mass));closed=n*K*m.log(2);assert abs(uniform_entropy-closed)<m.mpf(10)**(-dps+8)
   rows.append({'phase':row['phase'],'n':n,'K':K,'uniform_cell_count_exact':str(count),'uniform_cell_probability_exact':str(uniform_mass),'sparse_cell_entropy':enc(hp),'weight_entropy':enc(hw),'flattened_entropy':enc(flat),'entropy_sum':enc(rhs),'flattening_residual':enc(res),'uniform_entropy_from_probability':enc(uniform_entropy),'uniform_entropy_nKlog2':enc(closed)})
  # Increasing depth at every dimension retains exact linear cost; no uniform-K source bound.
  return {'cases':rows}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();book=exact_bookkeeping();lo=run(40,book);hi=run(60,book)
 with m.workdps(110):
  diff={}
  for i,(x,y) in enumerate(zip(lo['cases'],hi['cases'])):
   for k in ['sparse_cell_entropy','weight_entropy','flattened_entropy','entropy_sum','flattening_residual','uniform_entropy_from_probability','uniform_entropy_nKlog2']:
    diff[str(i)+'/'+k]=abs(m.mpf(x[k])-m.mpf(y[k]))/max(1,abs(m.mpf(y[k])))
  worst=max(diff,key=diff.get);maximum=enc(diff[worst]);assert diff[worst]<m.mpf('1e-28')
 out={'schema':'R282-one-sided-refinement-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'deterministic_seed':SEED,'counts':{'correlated_positive_volume_box_models':6,'refinement_cases':18,'stages_models':{'initial':2,'stress':2,'expanded':2},'pointwise_membership_checks':sum(x['pointwise_membership_checks'] for x in book['cases']),'near_mask_exact_identities':18,'entropy_flattening_cases_per_precision':18,'uniform_entropy_cases_per_precision':18,'precision_fields':len(diff)},'exact_bookkeeping':book,'mp40':lo,'mp60':hi,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'scope':['Positive L1 sources are finite mixtures of axis-aligned boxes with exact rational masses and side1/256; centers and their entire boxes remain in the same dyadic cells for K1,2,4. Repeated centers superpose densities. No independent-coordinate assumption.','Near-mask checks use the center-point atomic law only, clearly singular: the l1 near indicator need not remain constant across boxes at a boundary. These are not a continuous near-receiver or FULL proof.','Only y is refined; every z in the coarse C is retained. Same-fine-cell is separately recorded as a different operation discarding offdiagonal mass.','Uniform2^(nK) entropy is analytically nKlog2, evaluated from exact rational single-cell probability without enumerating the huge grid. This fee diverges as K grows even for smooth uniform rho on C; sparse test-law entropy is not substituted for it.','Ordinary mpmath40/60 for entropy, not interval certification; exact Fraction masses/membership are separate. No final source theorem, uniform refinement budget, original geometry/high/FIRST/history/FULL or dimension order certified.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maximum,'worst':worst}))
if __name__=='__main__':main()
