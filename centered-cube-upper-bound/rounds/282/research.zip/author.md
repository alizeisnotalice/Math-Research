# R282 — one-sided nested refinement with all off-diagonal pairs and a quantitative L1 tail

## Proposition first

Retain exactly R281's sources, actual selectors, original FIRST/hard cap, low-soft condition ns<=D, original middle clock, full original posteriors, and the same near condition. Write q_-=3lambda/4, d=a/(8sqrt(n)), M and L_{n,D} as in R281 S2, kappa=2+n log(1+d/a), and

    A = 1+n log(b/a),  delta_K=d 2^(-K), K=0,1,2,... .

There are nested original receiver/source-pair allocations A_K with

    A_0=A_lat,   0<=A_K<=A_{K+1}<=1,   A_K -> 1

almost everywhere in the original near mother. Fine off-diagonal pairs are retained exactly; no fine same-cell probability is divided out.

Let H_K be the expected coarse-cell source entropy

    H_K = E_shift sum_C rho(C) H({rho(D)/rho(C): D depth-K descendant of C}),
    H(probabilities)=-sum p log p.

Zero-mass cells contribute zero. Then 0<=H_K<=nK log(2) W_rho, and the full A_K-allocated raw near mother obeys

    T_K <= 2 { (16/3)(1+log kappa)
                     [L_{n,D} W_rho+2e^2 M H_K] + W_nu }.        (P1)

This is an explicit finite entropy charge, not a claim that H_K is uniformly polylogarithmic.

For any density threshold B>0, let rho_hi have density r(y)1_{r(y)>B}, where rho(dy)=r(y)dy. The unallocated raw near tail has the quantitative bound

    T_tail,K <= [2Bn delta_K/(a q_-)] A W_nu
                    +(16/3)e M A ||rho_hi||.                    (P2)

No bounded-density hypothesis on rho is imposed: B is an arbitrary splitting parameter. For every finite L1 rho, this tail tends to zero by first taking B large and then K large. The envelope weights used to prove both P1 and P2 are independent of receiver x. Nothing grants FIRST to a latent component or a newly selected source.

For the precise R281 remaining weight R_old=(Ab-Asc)(1-A_lat), there is the exact positive splitting

    R_old=(Ab-Asc)(A_K-A_0)+(Ab-Asc)(1-A_K).                     (P3)

The first summand is bounded by A_K and has price P1. The second is bounded by 1-A_K and has price P2. Multiplication of P1/P2 by the original 2Lambda B_D, B_D<=4sqrt(nD), gives valid original positive-traffic bounds. The original unique j mask is retained until the row-score bound; no new j sum is introduced.

Thus this note supplies exact complete coverage and a finite, explicit arbitrary-L1 tail bound. It does not supply a uniform root-polylog source price: the entropy term in P1 is not controlled at that order as K grows, and P2 alone supplies no source-uniform choice of B,K. The previous paid allocations remain paid only once.

## Construction: only the input source is refined

Fix one original uniformly shifted side-d coarse grid. Inside each coarse C use its standard nested dyadic descendants. Let D_K(y) be y's unique depth-K descendant, of side delta_K. For latent side vector r define

    J_{D,r}(x)=1{closed D subset product_i[x_i-L(x)r_i/2,x_i+L(x)r_i/2]},
    p_D^lat(x,y)=integral J_{D,r}(x) H_{r,L(x)}(x-y) pi_{s(x)}(dr).

The same actual latent kernel probability pi_s as R281 is used; it is a kernel decomposition, not a product-source assertion. On original near and p_y>0 put

    A_K(x,y,z) = E_shift[1{y,z in same coarse C} p_{D_K(y)}^lat(x,y)]
                         / [P_d(y-z) p_y(x)].                   (1)

Set A_K=0 off near or when p_y=0. The only denominator remains the original P_d>=1/2. Nested source cells imply nested J_D, and K=0 gives exactly R281 A_lat.

The hard source z stays anywhere in its original coarse C. At a fixed shift define

    F_C,K(x)=sum_{D depth-K in C} integral_D p_D^lat(x,y) rho(dy),
    G_C(x)=integral_C h_R(x-z) nu(dz).

After dropping near positively, the exact source pairing is F_C,K G_C. If the hard source is also written as a sum over its fine descendants E, this product is precisely

    sum_{D,E depth-K in C} F_D^lat G_E.

It includes ALL D!=E terms. There is no neighbor count or fine same-cell restriction. The actual caps give F_C,K/q<=1 and G_C/(4lambda)<=1; the original coarse hard cluster has weak constant kappa nu(C).

For fixed x and latent r, points y on the rectangle's finitely many faces form a Lebesgue-null set. Since rho is L1, they have rho measure zero for every actual x and r. Every other y with H_{r,L}(x-y)>0 has strictly positive distance to all faces and hence eventually D_K(y) is fully contained. Tonelli over x, the actual pi_{s(x)}, rho, nu, and the shift proves A_K->1 in the original mother. Actual L(x),s(x) remain arbitrary measurable selectors throughout. No assertion about boundary-zero sets of x alone is needed.

## Proof of the finite entropy price

For each descendant D, R281's fixed-node, rounded-shape construction yields the full-cell radial profiles g_{D,R} centered at the center of D, each with weak L1 constant exactly 1. Its envelope is

    F_D^lat <= e^2 rho(D) sum_{k=1}^M integral g_{D,R} pi_k^disc(dR).

The weights rho(D), the finite soft-node laws and the rounded-shape laws are independent of x. The weak-sum lemma R281 S15 is applied once to all descendants AND shape labels of a fixed coarse C. The total weak mass is e^2 M rho(C), and the normalized label entropy is at most

    H_C,K + log M + H_*.

Consequently

    ||F_C,K||_{1,infinity}
         <= rho(C)[L_{n,D}+2e^2 M H_C,K].                       (2)

This is where arbitrary off-diagonal refinement is paid. It does not duplicate the hard mass once per descendant.

Use the actual capped product and the R281 amplification inequality I(A,kappa B)<=(1+log kappa)A+B. For every coarse C,

    integral_E F_C,K G_C/q dx
       <=(16/3)(1+log kappa)rho(C)[L_{n,D}+2e^2 M H_C,K]
                                                        +nu(C).

Sum over the coarse partition, average shifts, and apply P_d^(-1)<=2 to obtain P1. The bound H_C,K<=log(2^(nK)) is elementary. The exact chain rule is also available:

    rho(C) H_C,K
      =sum_{ell=0}^{K-1} sum_{P depth-ell in C}
               rho(P) H({rho(D)/rho(P): D child of P}).         (3)

It identifies the genuine cost of revealing successive source-cell labels. It is not a free dyadic-depth count.

## A quantitative tail retaining arbitrary L1 sources

For a latent rectangle let E_delta(x,r) be its internal face slab: points inside the rectangle whose distance in at least one coordinate to one of its faces is <delta. If y is outside this slab, its entire side-delta_K source cell is contained in the rectangle, for every shift. In particular, directly from the conditional coarse same-cell law in (1),

    p_y(x)(1-A_K(x,y,z))
       <= integral H_{r,L(x)}(x-y) 1_{E_delta_K(x,r)}(y)
                         pi_{s(x)}(dr)                         (4)

on near. There is NO factor 2 in (4): its exceptional event is independent of the grid, so the same-cell numerator is bounded by P_d times the displayed face-slab kernel.

For a fixed rectangle, its normalized kernel mass in the face slab is at most

    min(1, sum_i 2delta/(L r_i)) <= sum_i 2delta/(L r_i).

R281's interval mixture gives integral r^(-1) mu_phi(dr)=phi(0)<=1. Hence for every actual s,

    E_pi_s sum_i r_i^(-1) = n[(1-s)+s phi(0)] <= n.

The low-density part rho_lo<=B dy therefore satisfies, pointwise at every actual receiver,

    integral face-slab-kernel rho_lo(dy) <= 2Bn delta_K/a.       (5)

After dropping near, the actual hard response obeys

    integral_E (h_{R(x)}*nu)(x) dx <= A W_nu,

by the exact common-window hard kernel envelope from R280. Combining with q>=q_- gives the first term of P2.

For the high-density part, simply discard the face mask and use the actual hard cap:

    T_tail,hi <= (16/3) integral_E integral p_y(x) rho_hi(dy) dx. (6)

The last integral has a finite full-soft all-selector L1 envelope. Indeed pi_s is dominated by e times the SUM of the M fixed R281 nodes. For each fixed latent shape r, the homothetic-scale envelope sup_{a<=L<=b} H_{r,L} has L1 mass exactly A=1+n log(b/a), by the change of variables u_i=x_i/r_i and the usual cube-envelope radial integration. Therefore

    integral sup_{actual allowed s,L} p_{s,L}(x-y) dx
         <= e M A.                                            (7)

Here (7) means the explicit positive envelope e sum_k integral sup_L H_{r,L} pi_sigma_k(dr), not an exchange of supremum and integral in the wrong direction. It is centered at y, so its L1 bound is translation invariant. Equations (6)-(7) give the second term of P2. Density truncation is only used to bound two positive parts; the original FIRST/caps and complete posteriors are never reassigned.

The original source total W_rho is finite and ||rho_hi||->0 as B->infinity. Thus P2 proves a finite tail criterion for any desired raw tolerance eta>0: choose B with (16/3)e M A||rho_hi||<=eta/2, then choose K such that [2Bn d2^(-K)/(a q_-)] A W_nu<=eta/2. If W_nu=0 all traffic is zero. The parameters are explicit in the actual source-density tail and do not assert a universal convergence rate.

## First-contained increments and the remaining decision

There is an exact first-contained identity

    J_{D_K(y),r} = J_{C,r}
                    +sum_{ell=1}^K [J_{D_ell(y),r}-J_{D_{ell-1}(y),r}].

Each summand is nonnegative and each (x,y,r) contributes at most once. This does NOT make its source labels an x-independent probability partition: the stopping level and offending coordinate faces depend on actual x,L,r. If one simply uses the fixed envelope coefficient rho(D) at every level, its total mass is sum_ell rho(C), which diverges. If one prices all labels at a fixed depth, the rigorous resulting cost is exactly (2)-(3). The face localization in (4)-(7) gives a real tail estimate but has not produced a uniform replacement of that entropy charge.

Refining only an offending coordinate would likewise be selected by x and the latent shape. Treating that choice as a free fixed source partition is invalid; no such replacement occurs above. A useful next estimate would have to combine first-containment face localization with the TWO actual caps before applying the weak-sum truncation, so that the source-label information is charged only where its face increment contributes. This note has not proved that estimate.

The global source-paid root budget therefore remains open. The new concrete information is that off-diagonal pair loss can be completely eliminated by one-sided refinement, and that the approximation error has the explicit arbitrary-L1 bound P2. The sole additional geometric payment exposed by this construction is the fixed-weight source-label entropy in P1, with its exact chain rule, rather than an unexplained adjacency multiplicity or an assumed finite depth.

## Actual local diagnostic

A local Python Fraction computation checked 792 source/rectangle/depth combinations for the face-slab implication used in (4). It also checked an original-near geometric pair with n=4,a=16,d=1: y=(.49,.2,.3,.4), z=(.51,.2,.3,.4), and a physical input cube with upper faces .5 and side 16. The hard source z is outside that input cube and belongs to a different fine cell, while y's depth-one cell is fully inside. The one-sided construction retains the pair; a fine common-cell construction cannot do so. The entropy chain rule was checked on eight rational probability masses; floating logarithm residual was 0.0. Output: geometry_checks=792, off_diagonal_pair_preserved=True, status=PASS.

These are finite checks of the stated geometric/algebraic facts, not a FULL original-history experiment or an interval-certified source-budget estimate. The proofs of P1-P2 are the analytic arguments above.
