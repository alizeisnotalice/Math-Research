from fractions import Fraction as F
from math import floor
N=0
for delta in [F(1,8),F(1,32),F(3,16)]:
 for width in [F(1,64),F(1,4),F(1),F(11,8)]:
  rem=width%delta
  knots=sorted(set([F(0),rem,delta]))
  avg=F(0)
  for l,h in zip(knots,knots[1:]):
   q=(l+h)/2
   number=max(0,floor((width-q)/delta))
   avg+=(h-l)*number*delta
  avg/=delta
  assert avg==max(F(0),width-delta)
  assert width-avg==min(width,delta)
  N+=1
print('PASS',N,'exact averaged full-cell coverage identities')
