import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--check-only',action='store_true');args=ap.parse_args()
for name,digest in json.loads((p/'manifest.json').read_text()).items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('manifest PASS',flush=True)
if not args.check_only:
 for name in ['faces_checks.py','screen_checks.py']:
  subprocess.run([sys.executable,str(p/name)],check=True,cwd=p)
 with tempfile.TemporaryDirectory() as d:
  out=Path(d)/'result.json'
  subprocess.run([sys.executable,str(p/'r282_numeric.py'),'--output',str(out)],check=True,cwd=p)
  assert out.read_bytes()==(p/'r282_numeric.json').read_bytes(),'JSON differs'
 print('ALL PASS; numerical JSON byte-identical')
