# R414 independent audit — FINAL PASS

FINAL PASS within the frozen scope: cumulative WEIGHTED support budget; finite density-tail audit; two static-D0 cubic-density positive receipts; and their COMPLETE G0-feedback substitution. Each candidate was independently checked before reading its corresponding R414 treatment. Final main/readme/proofs and code were reviewed, and all delivered scripts actually rerun. The unweighted joint heavy-density/current-high remainder, layer-uniform P and global closure remain unproved. Only this audit file was edited.

## 1. Supportive weighted measure: independent proof and parent review

Use the unchanged ORIGINAL decreasing symmetric kernels M_i=f(y)f(z)K_i(y,z)dy dz with first marginal f(y)D_i(y)dy, and SAME-new-source Σ_i b_i(z)≤1. Push Σ_iM_i b_i through the charged stage's ORIGINAL D_i(y), givingν. The sourcewise first-low argument at any d>0 yieldsν((0,d])≤dW. The first index j_d(y) is measurable; no index means no selected contribution. Common explicit K_i versions decrease pointwise, so on the first-low suffix sum_i K_i b_i≤K_j before integrating z. Finite sums precede positive Tonelli. This grouping is not a historical/predictable stopping claim and does not erase separate finite terminal costs.

There is no zero-occupation atom: for each i, D_i(y)=0 has zero first marginal f(y)D_i(y)dy, and multiplication by b_i/countable summation cannot create mass there. A CDF bound on(0,d] alone would NOT handle this singular-weight issue without that fact.

The total Hν≤M0(total)=∫fD0=2G0 and Hν≤SA_nW, using M_i≤M0,Σb_i≤1 and D0≤SA_n. Both orientations already belong toD0, so no further2 is added. If Hν=0 or W=0,ν=0. Otherwise positive layer cake and the bound min(Hν,dW) give

∫t^(-1/2)ν(dt)≤2sqrt(WHν)≤2sqrt(SA_n)W.

Positive-t atoms and all CDF endpoint conventions are allowed. Constant2 is the general CDF constant; no selected-field sharpness example is claimed. On ACTUAL retained high-stage units the marked source projection is≤Mi bi/τ, and the same original-stage measurable weight can multiply that positive domination. Thus the safe actual weighted price is≤2sqrt(WHν)/τ. It says nothing about a renormalized filtered conditional law.

This is not an unweighted receipt. Removing the weight by D_i≤SA_n can restore a linear-n source loss. D_i>s is a lower bound and does not give the missing upper comparison. Parent correctly leaves the geometry-to-weight bridge and P unproved; no formal new payment is inserted for this support result.

## 2. Exact existing quartic input and original normalization

Read the necessary original R391 definition and §4 action-space proof. The ORIGINAL Γ0 cost isG0, its endpoint incidence s0 is relative toσ=qdu,0≤s0≤S, and ∫s0dσ=2G0. The actual Lebesgue occupancy is

D0=T_R* s0=∫s0(A)c_A(x)R_A^(−n)dA.

The inherited centered-cube strong L^(4/3)(dx) averaging estimate dualizes to an L^4(dA)→L^4(dx) bound, NOT an f-weighted L^4 bound. It gives

∫D0^4 dx≤C_*^4∫s0^4dA≤(2C_*^4S³/q_-)G0=A4G0.

The2 is exactly two-end incidence, and1/q_- convertsσ to true receiver dA. C_* stays a qualified symbolic dimension-independent constant; no model A4 or numeric value is substituted for it. The external maximal theorem's full proof was not reaudited here; its previously audited action-space input and the displayed dualization were checked. D0 is not recomputed after R413 or the present filters. G0=0/S=0 empty-flow cases avoid division byA4; the nonempty theorem usesA4>0.

## 3. Independent cubic-density receipts and geometry review

On the SAME actual R413 measure retain all sources, clock/early/first-deletion/stage/far/rank/history and probability-path labels. First pay new z with f(z)≤c_zD0(z)^3. Then on its positive complement pay old y with f(y)≤c_yD0(y)^3. These events restrict existing cost; f,m,q,J,Γ_i,D_i and density thresholds are not clipped or replaced.

For new z, integrate ORIGINAL old source and other ≤1 factors directly. Its accumulated marginal is≤Σ_i f(z)D_i(z)b_i(z)dz≤f(z)D0(z)dz, with NO1/τ. Thus

P_z≤c_z∫D0^4≤c_zA4G0.

For old y, use the already paid-for R413 high-stage bridgeMi bi/τ. At the SAME new z, Mi≤M0 andΣb_i(z)≤1 give the old marginal≤f(y)D0(y)dy/τ. Hence

P_y≤(c_y/τ)∫D0^4≤(c_y/τ)A4G0.

This does not move b_i(z) to old y, require independence of actual saved labels, or add an extra endpoint2. The old-side complement may be dropped only for the upper bound; the actual two branches are disjoint and their union is removed once. D0=0 or f=0 carries zero selected cost. Finite stage sums retain separate old terminal items; original clearing and positive limits justify the full infinite contract.

With c_z=η/(2A4),c_y=ητ/(2A4), the exact split gives

R413=P_z+P_y+R414≤R414+ηG0.

The actual complement has f(z)>ηD0(z)^3/(2A4), f(y)>ητD0(y)^3/(2A4), along with ALL original R413 conditions. It therefore also exceeds the corresponding current-D_i thresholds, but no remainder is declared paid. This is not an assumption that f globally has a density cap. Applying the old quartic inequality to a NEW retained positive cost addsηG0 explicitly; it is not a refund of old fixed clipping, old initial-potential credit or BH negative square. Current-residual accounting, not an exhaustive first-ever-history claim, establishes once-only use. No uniform positive paid proportion/nonzero native R413 example is certified.

The fixed-T0 comparison and repaired geometry(13) have the correct direction: for sufficiently large D0/s a c_xD0³ threshold can exceed2T0. Finite examples illustrate that algebraic possibility only. They do not prove that every remaining actual input has such a positive branch.

## 4. Mandatory full feedback and formal main ledger

Let F_late=(1−32δ)^−1 and0<η<(1−32δ)/16. The new feedback is

Hη=(1−16F_lateη)^−1,
Fhat=F_lateHη=(1−32δ−16η)^−1.

Substitute R413≤R414+ηG0 into the ORIGINAL G0 mother bound and solve, obtaining

G0≤16Fhat[R414+C413X_q+V413W].

C413/V413 are the FORMAL R413 pre-gated/repriced versions, not the author's alternative C_end/V_end. BH has32Fhat in its core slot and the entrance has64ΛFhat. The FULL C413 and V413 terms, including previous source prices and X charges, receive the same new feedback. External E387/S390/8s/H/A_entrance,n terms keep their old displayed coefficients. The main exampleδ=η=1/128 gives F_late=4/3,Fhat=8/5; the geometry's alternativeη=1/(64F_late) givesHη=4/3, both correct.

Multiplying only the new remainder or appendingηG0 to BH without solving would miss feedback; final reports do neither. Low-dimensional full-core replacement remains an alternative, not an added high-dimensional bill. A smaller residual does not imply a smaller complete RHS after feedback or available global absorption. Main/readme retain all old entry/soft/crossing/extreme-geometry/scale/history/limit and source-multiplicity obligations. P and the high-heavy-density joint root budget remain open.

## 5. Auxiliary finite-tail audit

Aux is valid only as its stated support/failed-route refinement, not a new formal payment. Its b_i is asymmetric in the NEW source z despite symmetricMi. For nondecreasing originalT_i and decreasingDi, the correct finite suffix starts at T_{j−1}, includes repeated/large jumps, and keepsTN finite.

The new-source low-D equality cancels f(z) and produces(D_i(z)−s)_+, giving the(d−s)_+ density tail at NEW z. The old-source first index is j_d(y), but its retained tail r_{j,N} and occupancy factor remain at z inside K_j(y,dz). They cannot be replaced by an old-f(y) tail. The final dW bound drops positive tails only as an upper bound. Missing first indices and finite remaining-edge terminal costs are explicitly retained.

Extreme occupancy ratios large enough to reach root scale force an already-paid absolute-low or empty branch in currentR413; those observations are not counted as new receipts. A pair-dependent first ratio-crossing j(y,z) loses the sourcewise row-capacity argument. No contradiction with the new static-D0 old-density payment arises: that separate receipt legitimately usesM0 and discards the NEW-z tail rather than falsely relocating it.

## 6. Actual local execution and corrected evidence scope

Reviewer independently ran243 abstract CDF/weighted-measure Fraction configurations (including zero total),288 pointwise cubic cases and9 feedback identities. These are NOT pooled with delivered evidence.

Read and actually reran the final delivered scripts, matching parent stdout:

- parent:72 positive finite probability-kernel models, phases24/24/24; integer-square-root rational bounds compare an upper weighted-energy enclosure with a lower claimed-bound enclosure;
- aux:18 finite incidence/posterior models, phases6/6/6, with250 threshold subchecks and189/187 positive old/new threshold subcosts;
- geometry:27 scalar records,54 finite cell-space moment-qualified joint/deletion models,9 exact feedback records. Both cubic paid branches are positive in all54 of THOSE models.

These heterogeneous record/threshold/positive-subcost counts are not combined into a misleading number of independent native experiments. Parent/reviewer reruns repeat cases, not new data. All delivered arithmetic is Fraction or explicit rational enclosure; there is no floating-point/native-history certification.

An important numerical-description correction was required and is incorporated in final geometry/main: the54 models compute D0^4 times the measure of TWO POSITIVE SOURCE CELLS only. If the receivers were interpreted as full actual side-one cubes, D0 would also occupy their zero-f Lebesgue remainder, which is not included in that computation. Therefore these are moment-qualified finite CELL-SPACE algebra models, not verification of the full-space Lebesgue quartic moment for genuine cubes. Their m=q=1 is a model normalization; their numeric A4 is not an audited cube-operator constant. No code/data changed for that scope correction. The analytical theorem uses the real R391 moment, not this omitted-space calculation.

The parent weighted models, aux finite incidence and geometry finite cells do not realize all original continuous-du/far/rank/clock/history conditions. Finite positivity does not establish a nonzero paid branch of general nativeR413 or a near-extremizer. General mathematical validity rests on the positive-measure and inherited-moment arguments, not these counts. External route/skill/history-search mentions are scope records, not new mathematical inputs or an exhaustive search certified by this audit.

## Final byte bindings

- `/tmp/r414_main.md`: `4b22ddb135ac2f13eb1f282b7e5c965b293f2ea4ec259d5efa8a6f961e390ddc`
- `/tmp/r414_readme.md`: `e5d00d04e8e18fa616f56a24d43ea6f77a27b401fbb6049c3bc1261d4efde388`
- `/tmp/r414_parent.md`: `289cbaaa2bd6130bfd4f1009cef0a393ac248b6b78eb8e08fd24837b005e97ba`
- `/tmp/r414_aux.md`: `4fdcc74549ab1f83d4bfe07632240f5bdd4aafcb5679f28d8eaa429694b352e0`
- `/tmp/r414_geometry.md`: `1c71c0ae22a4573d6100998ada64a179a8915129e67f7db3023f1d7b4b966d83`
- `/tmp/r414_parent_check.py`: `b11fbfd14c3e223f1bb934e2f2d0ef89cc5b4ac6ee4fb91c63d65c53792fa915`
- `/tmp/r414_parent.result.txt`: `377f89bd0da16d745f066116d0a9a94af6d13802231946eb134599c6a3b0a128`
- `/tmp/r414_aux_check.py`: `a1db798046a77fd77ebb35b893968b53807f83edb4f2fb32031c0ace8e02ac9b`
- `/tmp/r414_aux.result.txt`: `8a3ac9253c7c09c9dc6f885dc32765c35123bc120476cfa5c8b2354d22eb364f`
- `/tmp/r414_geometry_check.py`: `22477db8330e5a7702f7165e37d6ff1e2ed83e12e8431a491ec20cb87947ffb0`
- `/tmp/r414_geometry.result.txt`: `bbd86de5f82bf12cc12f3d306f97374cf9338f4516ff060b6052204ec18f1c29`
- `/tmp/r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `/tmp/r391_geometry.md`: `1ccdc3446df5d157fcf6700f32d3790d65c98c48127318a5acd951a110290c23`

Final corrected bytes are bound above. The R391 input was inspected narrowly; no full-history or external theorem proof re-audit is claimed. All requested bounded R414 review work is complete.
