# R414 working note: a cumulative weighted budget, not an unweighted receipt

Let the unchanged R413 symmetric kernels be M_i=f(y)f(z)K_i(y,z)dy dz, with K_i decreasing, marginal f(y)D_i(y)dy and sum_i b_i(z)<=1. Define the finite positive measure ν on (0,M], M=S A_n, by pushing sum_i M_i(dy,dz)b_i(z) through D_i(y). Terms with D_i(y)=0 have zero mass by the exact marginal. Write H=ν((0,M])<=∫M_0=2G_0 and W=∫f.

The R413 first-low argument gives ν((0,d])<=dW for every d>0: use j(y)=first i with D_i(y)<=d, K_i<=K_j for i>=j, then sum b_i at the same z before integrating. This is a common-kernel statement, not a stagewise sum of dW.

For H,W>0 Tonelli and t^(-1/2)=(1/2)∫_t^∞ u^(-3/2)du give

  E:=∫ t^(-1/2)ν(dt)
    =(1/2)∫_0^∞ ν((0,u])u^(-3/2)du
    <=(1/2)∫_0^∞ min(Wu,H)u^(-3/2)du
    =2 sqrt(W H)<=2 sqrt(2 W G_0)<=2 sqrt(S A_n)W.

The last bound uses H<=M W, not G_0<=M W/2 as an extra assumption. If W=0 or H=0 all relevant integrals vanish. Finite-stage proof precedes nonnegative monotone convergence; this does not erase any original finite terminal cost.

For the actual R413 high-stage-marginal fee Θ, its marked source projection is dominated by τ^(-1)M_i b_i. Therefore its weighted fee ∫D_i(y)^(-1/2)dΘ is at most 2τ^(-1)sqrt(W H). All actual gates remain in Θ; they are only dropped in this positive bound. This does NOT control |Θ| because D_i(y) can be large. No unweighted payment or new formal ledger coefficient is entered. A missing geometry-to-weight bridge remains necessary.

Executed /tmp/r414_parent_check.py: 72 positive finite matched probability-kernel models, 24 initial, 24 varied source weights/probabilities, 24 expanded source/stage counts. Every support threshold checks the cumulative weak bound exactly with Fraction. Square roots are enclosed by rational bounds from integer square root at denominator 10^24; compare an upper enclosure of E to a lower enclosure of 2sqrt(W H). These are finite kernel diagnostics, not native Lebesgue receiver or full-history cube instances. Analytic proof is above.
