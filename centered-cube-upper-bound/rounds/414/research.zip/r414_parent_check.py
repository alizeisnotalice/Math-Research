from fractions import Fraction as F
from math import isqrt

def sqrt_bounds(x):
    scale=10**24
    k=isqrt(x.numerator*scale*scale//x.denominator)
    return F(k,scale),F(k+1,scale)
count=0; positive=0
for phase in range(3):
 for seed in range(24):
  n=3+phase
  weights=[F(1+(seed+j)%5,1+j%2) for j in range(n)]
  laws=[]
  for a in range(3):
   p=[F(1+(seed+a+2*j)%(3+phase)) for j in range(n)]
   den=sum(p); laws.append([x/den for x in p])
  stages=3+phase
  K=[]; D=[]; bs=[]
  for i in range(stages):
   coeff=[F((seed+a)%5+1,1+a)*F(stages-i,stages)**(1+a) for a in range(3)]
   k=[[sum(coeff[a]*laws[a][y]*laws[a][z]/weights[y]/weights[z] for a in range(3)) for z in range(n)] for y in range(n)]
   K.append(k); D.append([sum(weights[z]*k[y][z] for z in range(n)) for y in range(n)])
   bs.append([F(1+(seed+i+z)%3,3*stages) for z in range(n)])
  atoms=[]
  for i in range(stages):
   for y in range(n):
    mass=weights[y]*sum(weights[z]*K[i][y][z]*bs[i][z] for z in range(n))
    atoms.append((D[i][y],mass))
  W=sum(weights); H=sum(v for d,v in atoms)
  for cutoff in sorted(set(d for d,v in atoms)):
   assert sum(v for d,v in atoms if d<=cutoff)<=cutoff*W
  # Certified upper for weighted energy; lower for claimed bound.
  upper=sum(v/sqrt_bounds(d)[0] for d,v in atoms if v)
  bound=2*sqrt_bounds(W*H)[0]
  assert upper<=bound
  count+=1; positive+=H>0
 print('phase',phase+1,'PASS: 24 exact prefix and rational square-root enclosure tests')
print('PASS',count,'models;',positive,'positive. Finite matched probability kernels only; no native geometry or unweighted P certificate.')
