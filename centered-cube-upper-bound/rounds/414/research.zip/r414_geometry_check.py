#!/usr/bin/env python3
"""R414 finite exact diagnostics; no native-du/far/history certification."""
from fractions import Fraction as F
from itertools import product


def scalar_checks():
    count=0
    for f,D0,c in product([F(1,8),F(1),F(4)],
                          [F(2),F(8),F(16)], [F(1,128),F(1,16),F(1)]):
        levels=[D0,D0*F(3,4),D0/2,F(0)]
        b=[F(1,8),F(1,4),F(1,2),F(0)]
        assert sum(b)<=1
        actual=f*sum((bi*Di for bi,Di in zip(b,levels)),F(0)) if f<=c*D0**3 else F(0)
        assert actual<=c*D0**4
        count+=1
    return count


def joint_models():
    count=newpos=oldpos=0
    eps=F(1,10000); pi=[eps,1-eps]
    for s,A4,tau,eta in product([F(2),F(4),F(8)],
                                [F(2),F(32),F(162)],
                                [F(1,4),F(1,2),F(3,4)],
                                [F(1,128),F(1,64)]):
        D=8*s; G=D/2
        f=[s**3/(2*A4),F(10**6)*s**3/A4]
        source_volume=[p/x for p,x in zip(pi,f)]
        assert sum((v*x for v,x in zip(source_volume,f)),F(0))==1
        moment=D**4*sum(source_volume)
        assert moment<=A4*G
        theta=F(1,4);rho=F(1,2)
        T0=rho*theta*s**3/A4
        T=[T0,2*T0,6*T0,2*f[1]]
        assert f[0]>2*T0  # strict distinction from the old fixed density scale
        # Two identical finite receiver types, m=q=1, each sigma=2G.
        # One directed edge of mass G with old-source law pi.  Thus a=s_e=1/2.
        B=F(1,2);degree=F(1,2)
        assert degree>tau*B
        bsum=[F(0),F(0)];new=old=total=F(0)
        cz=eta/(2*A4);cy=eta*tau/(2*A4)
        assert f[0]<=min(cz,cy)*D**3
        assert f[1]>max(cz,cy)*D**3
        for i in range(1,4):
            b=[(min(x,T[i])-min(x,T[i-1]))/x*(1-s/D) for x in f]
            bsum=[u+v for u,v in zip(bsum,b)]
            # Complete deletion rule for these identical finite endpoints:
            # they survive the first two thresholds; at the last both delete.
            posterior=sum((p*max(F(0),1-T[i]/x) for p,x in zip(pi,f)),F(0))
            assert (posterior>1-theta) if i<3 else (posterior==0)
            for y,z in product(range(2),repeat=2):
                cost=D*pi[y]*pi[z]*b[z]
                total+=cost
                if f[z]<=cz*D**3:new+=cost
                elif f[y]<=cy*D**3:old+=cost
        assert max(bsum)<=1
        assert new<=cz*moment
        assert old<=cy*moment/tau
        assert new+old<=eta*G
        assert total-new-old>=0
        newpos+=int(new>0);oldpos+=int(old>0);count+=1
    return count,newpos,oldpos


def feedback_checks():
    count=0
    for delta,eta in product([F(1,256),F(1,128),F(1,96)],
                              [F(1,256),F(1,128),F(1,64)]):
        Fdelta=1/(1-32*delta)
        assert 16*Fdelta*eta<1
        H=1/(1-16*Fdelta*eta)
        # Solve an equality instance of G=16 Fdelta(R+eta G+C X+V W).
        R,CX,VW=F(2,7),F(3,11),F(5,13)
        G=16*Fdelta*H*(R+CX+VW)
        assert G==16*Fdelta*(R+eta*G+CX+VW)
        count+=1
    return count

if __name__=='__main__':
    a=scalar_checks();b,np,op=joint_models();c=feedback_checks()
    print('Stage 1 PASS:',a,'static-cut and cumulative-mark scalar records')
    print('Stage 2 PASS:',b,'finite full-matching joint/deletion models;',np,'positive new-source and',op,'positive disjoint old-source bills')
    print('Stage 3 PASS:',c,'exact feedback coefficient records')
    print('Scope: moment-qualified finite quadrature models, not native-du/far/rank/history R413 realizations; no P claim.')
