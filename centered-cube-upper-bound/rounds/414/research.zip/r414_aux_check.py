from fractions import Fraction as F
from collections import Counter
C=Counter(); thresholds=0; positive=[0,0]
def run(seed,group):
 global thresholds
 n=3+(seed%3 if group=='expanded' else 0); a=3+(seed%2); stages=4+(seed%3 if group=='expanded' else 0)
 f=[F((j+seed)%5+1) for j in range(n)]
 incidence=[[((j+k+seed)%3!=0) for j in range(n)] for k in range(a)]
 for k in range(a):
  if not any(incidence[k]):incidence[k][k%n]=True
 mass=[sum((f[j] for j in range(n) if incidence[k][j]),F(0)) for k in range(a)]
 pi=[[f[j]/mass[k] if incidence[k][j] else F(0) for j in range(n)] for k in range(a)]
 sig=[F(5+k+seed) for k in range(a)]
 T=[F(0)]+[F(i*(seed%3+1),3) for i in range(1,stages+1)]
 if group=='pressure':T=[F(0)]+[F(1,4)]*(stages-1)+[F(9,4)]
 ss=[[F(max(0,2*stages-i-(k+seed)%3),stages) for k in range(a)] for i in range(stages)]
 if group=='pressure':ss[-1]=[F(0)]*a
 mats=[];D=[];bs=[];s=F(1)
 for i in range(stages):
  M=[[sum((sig[k]*ss[i][k]*pi[k][y]*pi[k][z] for k in range(a)),F(0)) for z in range(n)] for y in range(n)]
  d=[sum(M[y],F(0))/f[y] for y in range(n)]
  b=[(min(f[z],T[i+1])-min(f[z],T[i]))/f[z]*max(F(0),1-s/d[z]) if d[z] else F(0) for z in range(n)]
  mats.append(M);D.append(d);bs.append(b)
 for z in range(n):assert sum((bs[i][z] for i in range(stages)),F(0))<=1
 ds=sorted({F(0),F(1),*(v for d in D for v in d)})
 for cut in ds:
  j=[next((i for i in range(stages) if D[i][y]<=cut),None) for y in range(n)]
  old=sum((mats[i][y][z]*bs[i][z] for i in range(stages) for y in range(n) for z in range(n) if D[i][y]<=cut),F(0))
  new=sum((mats[i][y][z]*bs[i][z] for i in range(stages) for y in range(n) for z in range(n) if D[i][z]<=cut),F(0))
  oldbound=F(0);newbound=F(0)
  for y in range(n):
   if j[y] is None:continue
   ii=j[y]
   newbound+=max(F(0),cut-s)*(min(f[y],T[-1])-min(f[y],T[ii]))
   for z in range(n):
    tail=(min(f[z],T[-1])-min(f[z],T[ii]))/f[z]
    gate=max(F(0),1-s/D[ii][z]) if D[ii][z] else F(0)
    oldbound+=mats[ii][y][z]*tail*gate
  assert old<=oldbound<=cut*sum(f)
  assert new<=newbound<=max(F(0),cut-s)*sum(f)
  positive[0]+=old>0;positive[1]+=new>0;thresholds+=1
 C[group]+=1
for group in ('initial','pressure','expanded'):
 for seed in range(6):run(seed,group)
print('PASS',dict(C),'models',sum(C.values()),'threshold checks',thresholds)
print('positive old/new threshold costs',positive)
print('Exact Fraction finite incidence posteriors; not native cube or original history realization.')
