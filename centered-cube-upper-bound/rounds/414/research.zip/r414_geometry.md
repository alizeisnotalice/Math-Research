# R414：原初始占用的自适应密度正分支

2026-10-20。**在 R413 实际余项上，本轮支付两份来源的静态自适应密度 union，价格为 ηG₀，可在原母式作显示反馈吸收。**原占用、阈值和历史都不重算；这是新的互斥正分拆，不是退还旧 clipping 信用。占用层一致引理 P 及全部剩余的根阶预算仍未证明。

## 1. 冻结输入、已有矩界与准确命题

沿用 R413 最终实际费用：原 Γ_i 嵌套、b_i(z)、首次删除和 early 分数、旧 y/新 z、全部原 clock/rank/空间标记、双见证与完整辅助路径均保留。完整 f、实际 m_A=f(Q_A)=q_AR_A^n、真实中心 σ(dA)=q_A dA、π_A=f c_A/m_A 均固定。

记 G₀ 为原 Γ₀ 的总质量；原实际两端边缘密度为 s_i=s_i^u+s_i^v，相对 σ，0≤s_i≤S=β+C_col。原初始和当前占用为

\[
D_i(x)=\int_E s_i(A)c_A(x)R_A^{-n}\,dA,\qquad D_i\le D_0.
\tag{1}
\]

这里 D₀ 是开始原密度阈值 cascade 时的原 Γ₀ 占用，不是本轮删支后的重算占用。

已审 R391 强 L⁴ 对偶给

\[
\int D_0^4\,dx\le A_4G_0,\qquad
A_4=\frac{2C_*^4S^3}{q_-}.\tag{2}
\]

C_* 是原已审中心立方体最大算子 L^{4/3} 界常数。式(2)作用于 Lebesgue 来源变量，不是任意 f 加权 L⁴；本稿会在密度正支上先作正确的点态替换，才使用(2)。只有当原 C_*、S、q 参数资格成立时才可使用该显示 A₄，不能隐去其依赖。

R413 已付 stage 低边缘后，实际高支的来源投影满足

\[
\text{实际第 i 阶段费用}\ \le\ \tau^{-1}M_i(dy,dz)b_i(z),
\qquad
M_i=\int\sigma(dA)s_i(A)\pi_A(dy)\pi_A(dz),\quad0<\tau<1.
\tag{3}
\]

M_i 是上包络而非原带另一端点/clock 的 joint 等式；原定义保标签，证明上界时才积分掉条件概率和其他正门。原 s_i 递减，故 M_i≤M₀，且

\[
M_0(dy,\mathbb R^n)=f(y)D_0(y)dy.\tag{4}
\]

所有阶段在同一新来源上有 Σ_i b_i(z)≤1。R413 还保有旧、新来源 D_i(y),D_i(z)>s，但本轮证明不丢弃其原定义，仅在上界中允许放松。

**准确命题。**固定任意 c_z,c_y>0，在同一 R413 费用空间依次支付

\[
\mathcal P_z=R413[f(z)\le c_zD_0(z)^3],
\]
\[
\mathcal P_y=R413[f(z)>c_zD_0(z)^3,\ f(y)\le c_yD_0(y)^3].
\tag{5}
\]

其精确正补集记为 R414，则

\[
\boxed{R413=\mathcal P_z+\mathcal P_y+R414,
\quad \mathcal P_z+\mathcal P_y
\le(c_z+c_y/\tau)A_4G_0.}\tag{6}
\]

这没有假设一般 f 有密度帽；两个阈值事件是实际被支付的正分支，其完整补集保留。

## 2. 新来源支：原边缘给出的直接累计估计

仅为上界，放松原正门和路径限制，保持阶段 b_i 在原新来源 z。原实际 endpoint 边缘恒等式给

\[
\begin{split}
\mathcal P_z
&\le\sum_i\int f(z)b_i(z)D_i(z)
  1_{f(z)\le c_zD_0(z)^3}\,dz\\
&\le\int f(z)D_0(z)1_{f(z)\le c_zD_0(z)^3}
           \sum_i b_i(z)\,dz\\
&\le c_z\int D_0^4\,dz\le c_zA_4G_0.
\end{split}\tag{7}
\]

新来源侧没有 τ^{-1}：它直接使用原两端占用，不需要 R413 的旧来源条件密度桥。两端因子已包含在 D_i 和(2)中，不再乘2。D₀=0 或 f=0 的来源无费用。

## 3. 旧来源支：共同核和同一 z 的阶段标记

使用高 stage 桥(3)，并只为上界放松“新来源未获付”等额外正门，

\[
\mathcal P_y\le\tau^{-1}\sum_i\int M_i(dy,dz)b_i(z)
 1_{f(y)\le c_yD_0(y)^3}.\tag{8}
\]

阈值在旧 y 上静态固定，不能把 b_i(z) 换成 b_i(y)。直接以 M_i≤M₀，并在同一 z 上求和，得到

\[
\begin{split}
\mathcal P_y
&\le\tau^{-1}\int M_0(dy,dz)1_{f(y)\le c_yD_0(y)^3}
       \sum_i b_i(z)\\
&\le\tau^{-1}\int f(y)D_0(y)1_{f(y)\le c_yD_0(y)^3}dy\\
&\le(c_y/\tau)\int D_0^4\,dy\le(c_y/\tau)A_4G_0.
\end{split}\tag{9}
\]

这证明(6)。实际 union 按(5)只删除一次；证明旧侧时放松新侧补集只产生上界中的交集重计，不产生实际重复付款。没有逐阶段 W 或 G₀ 价格。

可测性来自原 D₀ 和固定 f。所有求和、路径和来源积分都非负，有限阶段先直接使用 Σ_{i≤N}b_i≤1；原尚存边终端项仍保留。到已证明清空的无限合同，按原非负极限通过；未借(7)–(9)宣称有限终端自动消失。没有把原 Γ_i、m、q、s_i、D_i 或密度阈值 T_i 改成删支后的对象。

## 4. 参数、与固定 T₀ 的差异及完整补集

取任意 η>0，令

\[
c_z=\frac{\eta}{2A_4},\qquad
c_y=\frac{\eta\tau}{2A_4}.
\tag{10}
\]

两笔各至多 ηG₀/2，故

\[
R413\le R414+\eta G_0.\tag{11}
\]

R414 保留 R413 的所有原条件，并额外满足

\[
f(z)>\frac{\eta}{2A_4}D_0(z)^3,
\qquad
f(y)>\frac{\eta\tau}{2A_4}D_0(y)^3.
\tag{12}
\]

特别也满足对应的 f(x)>c_xD_i(x)^3，但(12)更强。本轮没有只在各占用层另挑一个常数密度帽；两个事件一次按原 D₀ 全场定义，原全部阶段一并收费。

本轮核查了 R391 geometry 的固定 clipping 证明、R397 source 的固定阈值/尾函数预算、R408–R413 的相关实际费用定义，并对本机 R390–R413 文稿作 `f` 与 `D0³` 同式的定向检索，未见(5)这一同场静态自适应来源正支已经入账。此为所检查材料的范围说明，不是全史无遗漏声明。

已知初始固定尺度为 T₀=ρθs³/A₄（冻结原值），不随来源 D₀(x) 变化。新阈值 c_xD₀(x)³ 在 D₀(x)/s 足够大时严格超过2T₀，所以可支付固定 low-density 停止支之外的密度。具体条件是

\[
\frac{D_0(x)}s>\left(\frac{2\rho\theta}{A_4c_x}\right)^{1/3}.
\tag{13}
\]

本机有限模型同时实现 f>2T₀、(5)和严格正费用，见第6节；它不是原完整 native far/history 合同的非空实例。一般结论不保证此支占固定比例，也没有声称每个高占用层都被支付。

使用(2)给(7)、(9)新的正分支上界，不是再次扣原 BH 负平方、不是退还 R391 初始势支付过的 clipping 信用。它新增 ηG₀ 反馈，下一节完整记录该成本。

## 5. 原母式的显示反馈，不隐藏旧费用放大

使用主稿 R413 **前置门重拆的** C413、V413；不是上一轮作者附件较松的 C_end、V_end。原账为

\[
G_0\le16F_\delta R413+16F_\delta C413X_q+16F_\delta V413W,
\quad F_\delta=(1-32\delta)^{-1}.
\]

若 16F_δη<1，定义

\[
H_\eta=(1-16F_\delta\eta)^{-1}.
\]

与主稿记号一致，F_δH_η=1/(1−32δ−16η)=Fhat。代入(11)并吸收给

\[
\boxed{G_0\le16F_\delta H_\eta
 [R414+C413X_q+V413W].}\tag{14}
\]

于是

\[
B_H\le32F_\delta H_\eta R414
+[E387+32F_\delta H_\eta C413]X_q
+[S390+8s+32F_\delta H_\eta V413]W.\tag{15}
\]

原入口中，R414、C413X_q、V413W 三槽都乘64ΛF_δH_η；外部 E387、S390、8s 及原 H 入口仍按原式，不另乘 H_η。例如取 η=(64F_δ)^{-1}，则 H_η=4/3。旧 X 吸收余额必须在此放大后重新核验，不能称反馈免费。低维仍使用原完整替换，不与高维账叠加。

这是一个实际可吸收分支，并未产生层一致 P。对重尾补集(12)，现有粗界依然允许 2^{k+1}sW。原删除规则额外保证幸存 endpoint 在真正阶段阈值 T_i 通过完整后验测试；它不保证阈值跳内部每个密度点通过测试，也尚未把(12)与双当前高占用、low-common/far/relative、双 collar/终端外侧几何连成可去掉2^k的共同预算。未付目标正是该同场重尾联合费用，不能换成无标记 M_i 或任意刷新后的终端费用。

## 6. 三阶段本机精确检查

实际执行 `/tmp/r414_geometry_check.py`，输出保存为 `/tmp/r414_geometry_check.stdout`：

```
Stage 1 PASS: 27 static-cut and cumulative-mark scalar records
Stage 2 PASS: 54 finite full-matching joint/deletion models; 54 positive new-source and 54 positive disjoint old-source bills
Stage 3 PASS: 9 exact feedback coefficient records
Scope: moment-qualified finite quadrature models, not native-du/far/rank/history R413 realizations; no P claim.
```

第一阶段核静态阈值与递减占用/累计标记的点态估计。第二阶段为两个有限 receiver 类型的完整来源模型：两来源质量和为1，接收质量m=q=1；原边旧来源律为完整π，两个 endpoint 密度均1/2，D₀=8s。小来源质量1/10000，其密度选 s³/(2A₄)>2T₀；大来源密度10⁶s³/A₄。在该有限 cell 测度空间上核验所定义的四阶矩≤A₄G₀、两次真实阈值存活及末次完全删除、实际 b_i、stage 高边缘、静态 union 的互斥性及两侧正费用。取 s=2,4,8、A₄=2,32,162、τ=1/4,1/2,3/4、η=1/128,1/64，54组全部两支严格正。有限模型中的 A₄直接通过矩不等式验证，不将数值 A₄称为已认证原 cube 算子常数。

这些 receiver 是抽象有限类型，不是原生连续中心选择器；数值 moment 只对两个正来源 cell 的指定体积求和。它不验证真实立方体在全空间（包括 f=0 区域）的 Lebesgue 四阶矩，m=q=1 是模型归一化而非 side-1 立方体的实现；没有满足原严格 far、秩和历史所有门，因此不声称构造了原完整 R413 的正核心。它们验证的是已陈述的匹配、矩、删除标记与新增付款代数，并显示新阈值确可超过旧固定阈值。第三阶段精确核 η 反馈及全部旧槽同时放大的等式，未用浮点拟合。

一般收据由(7)–(9)证明。本轮按有界任务停止，未扩展重尾补集的下一路线。
