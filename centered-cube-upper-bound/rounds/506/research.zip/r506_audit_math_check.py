import sympy as s

x,q,u,v=s.symbols('x q u v',positive=True)
F0=x*x/(2*q)
F1=x*s.log(x/q)+q/2
assert s.diff(F0,x,2)==1/q
assert s.diff(F1,x,2)==1/x
assert s.simplify(F0.subs(x,q)-F1.subs(x,q))==0
assert s.simplify(s.diff(F0,x).subs(x,q)-s.diff(F1,x).subs(x,q))==0
D=(u-v)**2/(2*q)
cost=(u*u/q-v*v/q)**2/(u+v)
assert s.factor(8*D-cost-(u-v)**2*(4*q-u-v)/q**2)==0
fu,fc,fv,pc,pv,c=s.symbols('fu fc fv pc pv c')
Duv=fu-fv-pv*(u-v)
Duc=fu-fc-pc*(u-c)
Dcv=fc-fv-pv*(c-v)
assert s.expand(Duv-Duc-Dcv-(pc-pv)*(u-c))==0
print('PASS 6 exact soft-output entropy primitive and Bregman decomposition checks; no continuous flux bound')
