# R506 独立预审：软输出与实际选择器的停止通量

先于阅读任何 R506 作者稿。保完整 f、原中心/mark、原选择器 \(R_B\in[a,b]\)、\(q\le s(B):=g_{R_B}(B)\le\lambda\)、\(\nu=t(B)s(B)dB\)、\(0\le t\le S\)。所有新半径仅作同中心费用的辅助比较，不改变原 π、rank、void 或历史。

## 1. 软输出合法；先保实际有符号选择器账

令
\[
\psi(s)=s^2/q\ (0\le s\le q),\quad
\psi(s)=s\ (q\le s\le\lambda),\quad
\psi(s)=\lambda\ (s\ge\lambda).
\]
它非降、连续、2-Lipschitz，\(0\le\psi(s)\le s\)，在真实接收带上**等于**s。因此 \(\int\psi(g_a)\le W\)。由 L1 径向 AC 和链式法则，最精确的原选择器恒等式是
\[
R_\tau=\int_E t\psi(g_a)dB
+\int_a^b\int_E t(B)1_{R<R_B}
\psi'(g_R)\partial_Rg_R\,dB\,dR.
\tag{1}
\]
概率 mark 同时积分；其原权和 R_B 保留。右端有符号项绝对可积，由 \(\psi'\le2\) 及 R504 的全中心径向变差帽控制。只有明确舍弃负项、再放大实际停止区间后，才得到
\[
R_\tau\le S(W+\mathcal V_\psi),\quad
\mathcal V_\psi=\int_a^b\int(\partial_R\psi(g_R))_+dB\,dR.
\tag{2}
\]
相较硬输出，它在 g<q 时不再为零，故没有逐点理由使 \(\mathcal V_\psi\) 比原 \(\mathcal V_\varphi\) 小。只得到另一足够目标，不是免费改善。

还可先用真正的极大入口：\(R_\tau\le S\int\max_{R\in[a,b]}\psi(g_R)dB\)。逐中心最大值只付到最高值；全正变差会重复支付回落后的再上穿，甚至统计原 E 外的中心。因此若能控制实际停止中心或这个最大值，不应预先要求更强的全部正变差。

## 2. 可避免固定 q 穿越的 r 因子：按原实际水平最后穿越

固定 q 的 R504 重选需权 \(t s/q\le Sr\)。但本轮可保每个原中心的真实水平 s(B)，定义
\[
E_b=\{B\in E:g_b(B)\ge s(B)\},\quad E_c=E\setminus E_b,
\quad\rho(B)=\max\{R\in[a,b]:g_R(B)\ge s(B)\}\quad(B\in E_c).
\]
连续性给 \(\rho<b\)、\(g_\rho=s(B)\)、\(g_R<s(B)\le\lambda\) 对所有 R>ρ 成立。该半径可测，因为 \(\{\rho\ge c\}\) 是 \(\max_{R\in[c,b]}g_R(B)\ge s(B)\) 的可测事件；不要求横截性。

设 \(w_b=t s(B)/\psi(g_b)\le t\le S\) 于 E_b。由 \(\psi(g_\rho)=s(B)\) 得准确账
\[
R_\tau=\int_{E_b}w_b\psi(g_b)dB+\int_{E_c}t\psi(g_b)dB
-\int_a^b\int_{E_c}t1_{\rho\le R}
\psi'(g_R)\partial_Rg_R\,dB\,dR.
\tag{3}
\]
两个末端集合不交，合计至多 **SW**，不需 SrW；a=b 时全为该端点。末段仍是有符号的同源停止通量，不能把负导数部分全部上放后宣称已付。与固定水平不同，阈值 s(B) 依赖原 selector；来源换序时必须保它及 \(1_{\rho\le R}\)，不能按常数阈值或独立随机中心处理。式 (3) 保原中心费用而不把新盒视为原历史父。该改写避免 r 过付款，但尚无新根阶预算。

## 3. 一个合法有限斜率凸熵桥，仍只直接支付辅助周期

可取凸熵 F，满足
\[
F''(s)=1/q\ (0<s<q),\qquad F''(s)=1/s\ (q<s<\lambda),
\qquad F''=0\ (s>\lambda),\quad F(0)=F'(0)=0.
\]
即 \(F(s)=s^2/(2q)\) 于 [0,q]，\(F(s)=s\log(s/q)+q/2\) 于 [q,λ]，之后线性延拓。于是 \(0\le F(s)\le(1+\log r)s\)，不引入小密度处的无限斜率。

对所有 u,v≥0 可安全使用
\[
\frac{[\psi(u)-\psi(v)]^2}{u+v}\le8D_F(u,v).
\tag{4}
\]
两端≤q 时直接给更紧常数4；两端在 [q,λ] 给常数2。跨q时分成两个增量、用平方三角界与凸函数三点 Bregman 正交叉项，得常数8；λ以上截到λ仅减小左侧且不增加所需 Bregman 下界。零点单列。故 R505 的真实辅助坐标鞅可同样得到 \(4\sqrt{n(1+\log r)}W\) 的整周期价。这只是软输出的辅助正工具，原连续曲线没有变成该鞅。

对于实际连续尺度分割，准确 Bregman 账另含
\[
\sum_j\int D_F(g_{R_j},g_{R_{j-1}})
=\int F(g_b)-\int F(g_a)
-\sum_j\int F'(g_{R_{j-1}})(g_{R_j}-g_{R_{j-1}}).
\tag{5}
\]
全中心质量守恒仅消去常数斜率，不能消去这里的密度相关斜率。没有实际条件均值结构或有价漂移比较，就不能套鞅望远镜；细分后 Cauchy 分母总质量也含步数，不能把无限正变差付成一个有限周期。应优先尝试对 (1)/(3) 的实际停止权、或最大值建立同源凸熵／几何比较，保漂移、负通量和端点，而非先丢掉所有这些信息。

本机指定 Python 实际核6项 SymPy 恒等式：上述熵两段曲率、q处值/斜率拼接、低密度标量余量、三点Bregman分解。仅验证代数；一般式 (4) 由分区解析说明，未验证连续通量价或原history。独立预审交付后等待作者。
