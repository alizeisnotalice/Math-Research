# R506：软输出的标量信息价

明确结论：题定函数满足标量界`χ(v)j(u,v)≤2log2·D_F(u,v)`；因此4和8均可取。常数2log2是sharp：任意u=0、0<v<1都有精确等号。这里的全参数结论来自下列分段解析论证，数值搜索和48组有限证书只核实现与边界；这不支付真实空间耗散、对角转移或原history。

## 环境及实际计算范围

命令：

```text
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r506_numeric.py
```

Python3.12.14，NumPy2.5.4，SciPy1.18.1，SymPy1.14.0，python-flint0.9.0，Arb384bits。JSON写到脚本自身目录，除`compute_index.seconds`外没有动态字段。

实际完成164项证书断言：20个符号/严格常数核验，48组有理输入各3项Arb或精确边界断言。另有4个SciPy搜索，仅作discovery，不计作证书。没有cube/来源采样。

初探r=1,2；极端压力包含u/v小至exp(−32)、大至exp32、v接近1、u≈v、r=1退化端点；扩大r=16,1000。差分演化种子506、popsize10、maxiter80、tol1e−9，logv∈[−18,logr]、log(u/v)∈[−24,24]，并在v=1,r以有界一维优化扩至[−32,32]。最大发现比值约1.38629436112，接近2log2；这不是全域最优数值证书。近对角浮点D用Hessian积分以减小消去，仍只作探索。

48组严格输入为每个r∈{1,2,16,1000}的12对，包含0、1/4、r/2、r、2r、4r、10^12r，以及1±10^(−6)。JSON列出完整有理输入、D_F、JS、sharp常数余量与C=4余量。u=v用精确零；u=0,v≤1用符号等号；其他正余量用有限Arb区间下端核验。没有将“区间包含0”当作等号。

stdout为：

```text
PASS 164 symbolic/Arb assertions;4 floating discovery searches,48 exact-input scalar certificates;sharp C=2log2 by scalar analytic argument only
```

## 函数、方向与端点

q=1，r≥1。ψ(s)=s²（s≤1）、s（1<s≤r）、r（s>r）。χ是题定分段导数：v<1时2v，1<v<r时1，v>r时0。端点使用允许的较大单侧值：χ(1)=2、r>1时χ(r)=1；所以界也覆盖较小端点选择。χ(0)=0。

F低/中/高段分别是

`F(s)=s²`，`slog s+s`，`(3+logr)s−rlog(s/r)−2r`。

F与F'在1、r连续，F''为2、1/s、r/s²，均正。D方向固定为`D_F(u,v)=F(u)−F(v)−F'(v)(u−v)`。SymPy实际核连续性与高段二阶导数。

`j(u,v)=u log[2u/(u+v)]+v log[2v/(u+v)]`，零乘对数为0，j(0,0)=0。

## 解析证书：先化为一个比值

令`j0(t)=j(t,1)`。有j0(1)=j0'(1)=0、`j0''(t)=1/[t(t+1)]`（均已符号核）。

当0≤t≤1，Taylor积分给

`j0(t)/(1−t)²=∫_0^1 (1−s)/[(1+s(t−1))(2+s(t−1))]ds`。

分母随t递增，故该积分≤t=0处的`∫_0^1 1/(2−s)ds=log2`。脚本核积分、j0二阶导、基点和被积函数单调导数；t=1按极限，t=0按连续延拓。因此

`j0(t)≤log2(1−t)²`，0≤t≤1。

当t≥1，`j0'(t)=log2−log(1+1/t)`。log凹性与端点给`log(1+x)≥xlog2`（0≤x≤1），所以

`j0'(t)≤log2(1−1/t)`，

从1积分得到`j0(t)≤log2(t−logt−1)`。脚本核导数恒等式及log凹性；这些全区间符号论证不是有限采样的外推。

## 两个曲率缩放分支

v=0或v>r时χ=0，结论由F凸性直接成立。其余令t=u/v，利用j(u,v)=v j0(t)。

**低v：0<v≤1。** 令F1为r=1的F。逐分支有

`F_r''(vs)≥F1''(s)`。

例如s>1时，相关余量分别为`2−1/s²`、`(s−v)/(vs²)`、`(r−v²)/(v²s²)`；对应分支域内均非负，s≤1时同为2。因此

`D_Fr(u,v)≥v² D_F1(t,1)`。

这里`D_F1(t,1)`在t≤1为(t−1)²，在t≥1为t−logt−1。上一节于是给

`χ(v)j(u,v)=2v²j0(t)≤2log2·D_Fr(u,v)`。

**中v：1<v≤r。** 取辅助曲率`G''(s)=1`（s≤1）、`1/s²`（s≥1）。逐分支

`F_r''(vs)≥G''(s)/v`。

低s分支的余量为`2−1/v`或`(1−s)/(vs)`；高s为`(s−1)/(vs²)`或`(r−v)/(v²s²)`，均非负。因此

`D_Fr(u,v)≥v D_G(t,1)`，

而D_G(t,1)在t≤1为(t−1)²/2、t≥1为t−logt−1。故`j0(t)≤2log2 D_G(t,1)`，χ=1给同一常数2log2。

脚本对关键曲率余量逐项化简为精确0。这些比较在有限断点之外成立，足够用于积分型Bregman表示；无需在F''的跳跃点指定唯一值。

## Sharpness与实际决策

对u=0、0<v<1，`D_F(0,v)=v²`、`χ(v)j(0,v)=2v²log2`。脚本以含变量v的SymPy式直接认证等号，因此任何小于2log2的统一常数都不成立。

候选本身没有标量障碍，4/8有充分余量；更强的sharp常数可供作者选择。一般几何仍须另证真实空间耗散及对角连接，不能从这个标量结论推出总体root费用。

白名单仅`/tmp/r506_numeric.py`、`/tmp/r506_numeric.json`、`/tmp/r506_numeric.md`。限定任务完成并停止。
