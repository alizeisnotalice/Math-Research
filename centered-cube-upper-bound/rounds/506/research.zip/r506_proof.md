# R506：同中心存活鞅、连续熵价与实际选择器的恢复权

保 R504–505 同一完整来源 \(\mu=f\,dx\)、\(W<\infty\)、实际中心集合与选择器 \(R_A\in[a,b]\)、\(b\le2a\)、\(m_A=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(\nu=tq_A\,dA\)、\(t\le S\)。记 \(r=\lambda/q\)。目标仍是原同中心带通量 \(\mathcal V_{q,\lambda}(f)\)，不更改原接受权。

本稿建立真正连续、同中心的条件期望模型及有限来源熵价。它保留一个明确的存活权；正混合重启的完整恢复价格恰有线性维数损失。实际选择器只取一处尺度，不能据此断言其根阶预算不可能，但必须保留下述准确 RN 因子。

## 1. 同中心连续条件期望，无来源坐标独立假设

固定粗边长 \(B\in[a,b]\) 和中心 \(A\)，令 \(X\) 在 \(Q(A,B)\) 中均匀。随着 \(R\) 从 \(B\) 下降，若 \(X\notin Q(A,R)\) 则揭露完整 \(X\)，否则只知道仍存活。该滤过递增，且
\[
M_R=\mathbb E[f(X)\mid\mathcal F_R]
=1_{X\in Q(A,R)}g_R(A)+1_{X\notin Q(A,R)}f(X),
\quad g_R=R^{-n}\mu(Q(A,R)).\tag{1}
\]
存活概率为 \(p_{R,B}=(R/B)^n\)，\(\mathbb EM_R=g_B(A)\)。这是 uniform 几何抽样的辅助模型；\(f\) 可以任意相关，未把 \(\pi_A\) 变成坐标乘积。对嵌套矩形相同构造成立，存活权为各边长比之积。

令 \(b_R(A)\) 为两侧各面的等权平均，即
\(R\partial_Rg_R=n(b_R-g_R)\)，并有 \(\int b_R\,dA=W\)。R504 的输出函数满足 \(0\le\varphi'\le2\)。故真正同中心的加权通量有一般预算
\[
\begin{aligned}
\mathcal V^{(B)}
&:=\int_a^B\int p_{R,B}\varphi'(g_R)
(R\partial_Rg_R)_+\,dA\,dR/R\\
&\le2nW\int_a^B(R/B)^n\,dR/R
=2W[1-(a/B)^n].\tag{2}
\end{aligned}
\]
这没有逐坐标绝对值的额外费用，但**也没有去掉存活权**。

同一过程还有精确的连续熵价。采用 R505 的凸函数
\[
\mathcal E(s)=\int_{q/2}^{\lambda}(s-u)_+\,du/u,
\quad0\le\mathcal E(s)\le\log(2r)s,
\quad D_{\mathcal E}(u,v)=\mathcal E(u)-\mathcal E(v)-\mathcal E'(v)(u-v).
\]
记 \(\mathbb E_{\partial Q_R}\) 为先均匀选一个面再均匀选面上点的概率平均。对一般 \(L^1\) 来源，径向层积分及绝对连续链式法则给
\[
\begin{aligned}
&\int_a^B n(R/B)^n
\mathbb E_{\partial Q(A,R)}D_{\mathcal E}(f(x),g_R(A))\,dR/R\\
&\quad=(a/B)^n\mathcal E(g_a(A))
+B^{-n}\int_{Q(A,B)\setminus Q(A,a)}\mathcal E(f(x))\,dx
-\mathcal E(g_B(A)).\tag{3}
\end{aligned}
\]
证明是对 \(p_{R,B}\mathcal E(g_R)\) 求导，并将 \(B^{-n}\int_{Q(A,R)}\mathcal E(f)\) 的面导数相减。所有面迹只在几乎处处尺度使用，不在选择器图像上任意代入。对中心积分，右侧前两项合计至多 \(\log(2r)W\)，所以
\[
\boxed{\int dA\int_a^B n(R/B)^n
\mathbb E_{\partial Q(A,R)}D_{\mathcal E}(f(x),g_R(A))\,dR/R
\le\log(2r)W.}\tag{4}
\]
熵函数斜率有界，故不需 \(f\log f\) 可积，也无 \(\infty-\infty\)。这里有价的是 face 原值到当前平均值的真实跳跃熵；它不等于原 \(\varphi'(g_R)(b_R-g_R)_+\)，不能把 Taylor 补偿项或存活权省去。

## 2. 正混合重启的完整恢复代价

若用非负有限尺度测度 \(\alpha\) 混合 (2) 或 (4)，原连续通量在尺度 \(R\) 所获权为
\[
w(R)=\int_{[R,b]}(R/B)^n\,\alpha(dB).
\]
若要仅依赖这种正覆盖支付**全部** \(\mathcal V\)，须有 \(w(R)\ge1\) 对几乎所有 \(R\in(a,b)\)。对 \(a<b\)，Tonelli 准确给
\[
\alpha([a,b])=w(a)+\int_a^b n w(R)\,dR/R
\ge1+n\log(b/a).\tag{5}
\]
几乎处处覆盖也推出 \(w(a)\ge1\)，由 \(R\downarrow a\) 的单侧极限可见。原子全部保留；特别是靠近 \(b\) 的覆盖要求末端原子至少为1。取
\[
\alpha=\delta_b+n\,dB/B
\]
准确得到 \(w(R)=1\)，并达到 (5)。因此这类**逐尺度正覆盖**不能将已经证明的存活价恢复为根阶价；代价又是 \(O(n\log(b/a))W\)。\(a=b\) 时无连续通量，不需要这一覆盖问题。此结论不排除有符号联合抵消或直接利用真实选择器的另一种证明，也不是一般原目标的下界。

## 3. 实际选择器只停一次：精确保留其 RN 费用

原记录附来源的联合测度为
\[
\nu(dA)\pi_A(dx)
=t(A)\frac{1_{Q(A,R_A)}(x)}{R_A^n}\,dA\,\mu(dx).
\]
固定粗尺度 \(b\) 的可付参考为
\[
d\mathfrak B=t(A)\frac{1_{Q(A,b)}(x)}{b^n}\,dA\,\mu(dx),
\qquad |\mathfrak B|\le SW.
\]
两者有准确关系
\[
\boxed{\frac{d(\nu\pi_A)}{d\mathfrak B}(A,x)
=(b/R_A)^n1_{Q(A,R_A)}(x).}\tag{6}
\]
保原 history 的额外正标记只须同时保留在该等式中；不能在新参考下再生成历史。由 (6) 可直接支付
\(\int(R_A/b)^n\,d\nu\le SW\)，但一般尚未恢复 \(\int d\nu\)。如果对粗来源后验 \(\pi_{A,b}\) 条件化，则存活概率改成 \(m_A/m_{A,b}\)，条件后确为原 \(\pi_A\)；其与 \((b/R_A)^n\) 合起来准确恢复原父密度，并未让逆存活费用消失。

这说明 (5) 不是选择器问题的必要价格：真实选择器只需在 \(R_A\) 处恢复，不要求所有 \(R\) 的覆盖。但是由辅助存活鞅本身仅得到 (6)，尚无几何估计控制其逆权对原记录的平均。若改用依父选择的粗尺度 \(B_A\approx R_A\)，倍率会减小，但 \(\int t(A)g_{B_A}(A)dA\) 不再有固定尺度的 \(SW\) 预算；必须另行支付，不能当作自由参考。

对最后穿越辅助盒，(6) 仅适用于该盒自己的 \(\pi_{A,\rho}\) 及相应父密度，不是把原 \(\pi_{A,R_A}\) 随半径移动。若在相应 crossing 群取原实际水平 \(s_A=q_A\) 的最后穿越，则 \(g_\rho(A)=s_A\)，辅助父密度为 \(t(A)s_A\,dA\)，同原中心费用；若如 R504 固定水平 \(q\)，须重权 \(w(A)=t(A)q_A/q\le Sr\)，辅助父密度才是 \(w(A)q\,dA\)。分别以 \(t\) 或 \(w\) 构造粗参考时，辅助联合测度的 RN 因子均为 \((b/\rho(A))^n1_{Q(A,\rho(A))}\)。这只比较同中心费用，不迁移原来源后验或 history。R504 已保留相应末端与负边界通量；借穿越支付逆权仍需该同源净通量比较，本稿未证明。对原记录自身，未证的一步仍是保原 (6) 中的真实接受权支付逆存活，而非删去该因子或重复付每一尺度。

## 4. 本机符号检查

下列代码检查存活积分、准确重启覆盖与质量保持。最后复用 R504 同一连续中心例 \(f=1_{[-1,1]}\)、\(A\in[1/2,3/4]\)、\(R_A=4(1-A)\)、\(q_A=3/4\)，不新增特殊输入。原费用为 \(3/16\)，加存活权后为 \(9/64\)，粗参考为 \(11/64\)，准确逆权恢复原 \(3/16\)。这只核代数和该真实静态例，未认证原历史或一般维数估计。

```python
import sympy as s
a,b,R,B=s.symbols('a b R B',positive=True)
checks=0
for n in [1,2,7]:
    survival=s.integrate(n*(R/B)**n/R,(R,a,B))
    assert s.simplify(survival-(1-(a/B)**n))==0;checks+=1
    cover=(R/b)**n+s.integrate(n*(R/B)**n/B,(B,R,b))
    assert s.simplify(cover-1)==0;checks+=1
x=s.symbols('x',real=True)
lo,hi=s.Rational(1,2),s.Rational(3,4)
rho=4*(1-x);q=s.Rational(3,4);p=rho/2
original=s.integrate(q,(x,lo,hi))
retained=s.integrate(p*q,(x,lo,hi))
coarse=s.integrate(1-x/2,(x,lo,hi))
restored=s.integrate(s.cancel(p*q/p),(x,lo,hi))
assert (original,retained,coarse)==(s.Rational(3,16),s.Rational(9,64),s.Rational(11,64));checks+=1
assert restored==original;checks+=1
print(f'{checks} exact assertions PASS')
print('original=',original,'survival=',retained,'coarse=',coarse,'restored=',restored)
```

实际 stdout：

```text
8 exact assertions PASS
original= 3/16 survival= 9/64 coarse= 11/64 restored= 3/16
```

结论：连续同中心的熵与条件期望可以严格构造，来源坐标不必独立；但其有价量带存活权。正重启的普遍恢复仍为线性价，真实选择器的 RN 恢复尚未被额外几何支付。本轮没有取得完整 \(\mathcal V\) 或原余流的根阶预算，至此停止。
