# R506：原接收记录的首穿径向耦合及其费用边界

本附件只证明一个可测、保原方向条件的辅助来源耦合。它不把随机坐标周期改认成同中心立方体过程，也不证明完整根阶预算。

## 1. 原记录与辅助首穿半径

设 \(d\mu=f\,dx\)、\(f\ge0\)、\(W=\mu(\mathbb R^n)<\infty\)，
\(Q(B,R)=B+[-R/2,R/2]^n\)，
\(g_R(B)=\mu(Q(B,R))/R^n\)，\(0<a\le b\le2a\)。原接收者有可测选择器 \(R_o(B)\in[a,b]\)，
\(q\le q_o(B)=g_{R_o(B)}(B)\le\lambda\)，及
\[
 d\nu(B)=t(B)q_o(B)\,dB,\qquad 0\le t\le S,
 \qquad R_\tau=\nu(E)<\infty.
\]
原阶段、来源和历史标签全部仍附在这同一测度上；下述操作只追加人工来源。

定义
\[
 R_*(B)=\min\{r\in[a,R_o(B)]:g_r(B)\ge q_o(B)\}.                 \tag{1}
\]
对 \(L^1\) 来源，\((B,R)\mapsto g_R(B)\) 在 \(R\ge a\) 连续，故集合非空紧且首次命中可测。具体可用紧区间上连续函数的最大值及可数有理网格表达首次命中的严格次水平集。如果 \(R_*>a\)，连续性给
\(g_{R_*}=q_o\)，且 \(g_r<q_o\) 对所有 \(a\le r<R_*\) 成立；若 \(R_*=a\)，则 \(g_a\ge q_o\)。因此始终
\[
 R_*\le R_o,\qquad g_{R_*}\ge q_o,\qquad
 \frac{\mu(Q(B,r))}{\mu(Q(B,R_*))}\le(r/R_*)^n
 \quad(a\le r\le R_*).                                      \tag{2}
\]
最后一个式子在 \(R_*=a\) 时只有端点。

记 \(m_*=\mu(Q(B,R_*))\)，附加
\(\pi_*(dx)=1_{Q(B,R_*)}(x)d\mu(x)/m_*\)。这不是把原 \(\pi_{B,R_o}\) 或旧来源换成 \(\pi_*\)；旧来源未必属于新小立方体，新来源也不继承旧历史。

## 2. 可测径向耦合：确切位移与对数边距

固定原记录，令 \(\alpha=a/R_*\)，并在 \(x\sim\pi_*\) 下定义
\[
 T=\max\{\alpha,2\|x-B\|_\infty/R_*\}.
\]
由 (2)，其分布函数满足 \(F_T(t)\le t^n\) 对 \(\alpha\le t\le1\)。因此可以用同一 \(U\sim\mathrm{Unif}(0,1)\) 构造
\[
 T=F_T^{-1}(U)\ge T_0:=\max\{\alpha,U^{1/n}\}.                 \tag{3}
\]
截断处 \(T=\alpha\) 的原子必须保留：可用随机化概率积分变换，或先取分位数再按 \(T\) 的真实条件律抽 \(x\)。标准 Borel 空间上的条件分布与可测分位数使这成为原记录参数化的可测核。取 \(x\) 时保留其全部真实条件分布，尤其不把方向改成独立均匀方向。

令 \(x'=B+(T_0/T)(x-B)\)。当真实半径小于 \(\alpha\) 时，\(T=T_0=\alpha\)，所以 \(x'=x\)；其余情形径向差恰为 \(R_*(T-T_0)/2\)。于是
\[
 \mathbb E_{\pi_*}\|x-x'\|_\infty
 \le\frac{R_*}{2(n+1)}(1-\alpha^{n+1}),\qquad
 \mathbb E_{\pi_*}\log(1/T)\le\frac{1-\alpha^n}{n}.             \tag{4}
\]
证明：\(T\le1\)，而
\(\mathbb ET_0=n/(n+1)+\alpha^{n+1}/(n+1)\)；对数式由
\(\int_0^{\log(1/\alpha)}F_T(e^{-s})ds\le\int_0^{\log(1/\alpha)}e^{-ns}ds\) 得到。

对联合真实中心与辅助来源测度，(4) 给
\[
 \int\nu(dB)\pi_*(dx)\log\frac{R_*}{\max(a,2\|x-B\|_\infty)}
 \le R_\tau/n.                                               \tag{5}
\]
若有限值可测测试 \(F(B,x)\) 对第二变量在 \(\ell^\infty\) 距离下是 \(L\)-Lipschitz，则耦合下的差值 \(F(B,x)-F(B,x')\) 绝对可积，且其绝对值积分至多
\[
 \frac{Lb}{2(n+1)}R_\tau.                                    \tag{6}
\]
只有两个测试分别可积时，差值积分才等于两联合测度的测试积分之差；不作两个可能无穷积分的相减。对欧氏 Lipschitz 测试相应多 \(\sqrt n\)，对 \(\ell^1\) 多 \(n\)。这些是 \(R_\tau\) 费用，不是 \(W\) 付款。特别是硬接收门、记录门不满足这里的 Lipschitz 假设；没有证明可用 (6) 支付其改变。

参考只规定截断径向律。它不规定角向律，不是均匀立方体来源，也不产生 R505 随机坐标周期的矩形中间态。

## 3. 保真实来源的方向列，以及配对的确切范围

原辅助联合测度满足
\[
 d\Xi(B,x)=\frac{t(B)q_o(B)}{g_{R_*}(B)}R_*^{-n}
 1_{Q(B,R_*)}(x)\,dB\,d\mu(x)
 \le S R_*^{-n}1_{Q(B,R_*)}(x)\,dB\,d\mu(x).                 \tag{7}
\]
固定 \(x\)，按 \(|x_i-B_i|\) 的唯一最大坐标及符号分成 \(2n\) 个锥。并列集合对中心 Lebesgue 测度为零。每个方向的来源列 \(\ell_{i,\pm}(x)\) 都满足
\[
 \ell_{i,\pm}(x)\le\frac{S}{2n}[1+n\log(b/a)].               \tag{8}
\]
确切证明是用径向包络
\(1_{2\|B-x\|_\infty\le b}\min\{a^{-n},(2\|B-x\|_\infty)^{-n}\}\)。内立方体积分为 1，外壳积分为 \(n\log(b/a)\)，各锥因几何对称恰得 \(1/(2n)\)。这对任意单选择器及集中 \(f\) 成立，没有使用来源密度帽。

可以在每个真实 \(x\) 上把正负方向的中心子测度按归一乘积配成质量 \(\min(\ell_{i,+},\ell_{i,-})\)。这是可测的有限核，保两侧真实子边缘；总质量的精确分拆为
\[
 R_\tau=2\int\sum_i\min(\ell_{i,+},\ell_{i,-})\,d\mu
       +\int\sum_i|\ell_{i,+}-\ell_{i,-}|\,d\mu.              \tag{9}
\]
此处没有更换任何原转移或给另一中心原历史。方向总列仍只有 \(S[1+n\log(b/a)]\) 的一般界。配对中心的切向位移、半径和原输出门也没有被 (8) 控制。

特别地，(7)—(9) 全部针对未搬移的 \(\nu(dB)\pi_*(dx)\)。搬移后的 \(x'\) 律不必相对 \(\mu\) 绝对连续，也没有已证的同一来源列帽；不能把 (8) 套到 \(x'\) 或径向参考上。

因此本次尝试的唯一未证迁移步骤是：将这个保真实来源及角向条件的首穿耦合，与随机坐标周期的有价增量比较，同时支付其方向不平衡及实际中心/输出门改变。径向小位移和每方向列均不能单独给该比较。未得到全目标的新付款，也不将 (9) 的未配量命名为已缩减原余项。

## 4. 实际运行的有限代数核验

下列自含代码已用本机指定 Python 运行。仅核验 (4) 的两个积分及 (9) 的质量恒等式，不验证一般几何、原历史或根阶预算。

```python
import sympy as s
from fractions import Fraction as F
v, alpha = s.symbols('v alpha', positive=True)
checks = 0
for n in (1, 2, 3, 8):
    et = alpha**(n+1) + s.integrate(n*v**n, (v, alpha, 1))
    assert s.simplify(1-et-(1-alpha**(n+1))/(n+1)) == 0
    margin = s.integrate(s.exp(-n*v), (v, 0, -s.log(alpha)))
    assert s.simplify(margin-(1-alpha**n)/n) == 0
    checks += 2
for p, m in ((F(0), F(1)), (F(1,3), F(2,3)),
             (F(5,7), F(5,7)), (F(7,4), F(2,9))):
    assert p+m == 2*min(p,m)+abs(p-m)
    checks += 1
print(f'PASS {checks}: 8 symbolic radial identities; 4 rational pairing identities. No native-field/history validation.')
```

实际 stdout：
```text
PASS 12: 8 symbolic radial identities; 4 rational pairing identities. No native-field/history validation.
```
