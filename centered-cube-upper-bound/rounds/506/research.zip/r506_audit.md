# R506 独立终审

FINAL PASS（限定已证接口与标量工具）。实际水平停止账、首穿径向耦合及未搬移来源列、同中心存活鞅与其加权熵、sharp软信息常数均通过审查。**完整空间耗散、逆存活恢复、角向／来源列累计价仍未支付；没有取得原 J、原余流或一般一致根阶上界。**

独立 PRE 先于作者阅读形成。已审白名单10件最终字节；未改作者、来源场或仓库。原proof最后穿越段现已明确辅助πρ≠原π_RA迁移；geometry已明确Lipschitz差值可积不等于两个可能无穷积分可相减。

- 软ψ在实际带上等于原平均，原选择器signed停止积分精确；按各父实际水平取末穿越，末端两群合计≤SW，不需固定q的Sr重权。停止阈值及原记录权仍须保留，不能换序时删去或迁移历史。全正变差只是更强的足够入口。
- 首穿实际水平的截断径向CDF≤t^n，含a/R*处原子；分位耦合方向为T≥T0，保真实角向条件。位移及对数边距常数正确。Lipschitz差值价以Rτ计，不是W付款；硬门不满足该测试条件。方向列S A_n/(2n)及相反方向配对恒等式仅针对未搬移的真实μ来源。x'律不继承μ绝对连续或相同列帽，未配量未被计为已付缩减。
- R下降时survivor滤过递增，退出揭露f(X)，存活条件均值为g_R。径向L1 AC及有限熵斜率使face跳跃D_E(f(x),g_R)的积分合法，无需在选中图像赋trace；log(2r)W价保n(R/B)^n权。正重启全尺度覆盖的总权最小1+nlog(b/a)，a、b原子处理正确；它不是一次selector的下界。原νπ对粗固定参考的RN=(b/R_A)^n1_QA，逆权没有被省略。
- Fsoft低／中／高曲率2/q、1/s、λ/s²，与PRE的Fpre不同。χ(v)j(u,v)≤2log2 D_Fsoft(u,v) 的两分支解析证明、零点及较大单侧端点值均正确；u=0,0<v<q取等，故常数sharp。主稿Cauchy回代4n√(log2·W log(b/a)·D)无漏因子，但所需D=O(W polylog(n)/n)未证，不能从标量价或有界斜率推得。

实际独立-I隔离重放geometry12、proof8、PRE6、numeric164，共190个报告核验单位；四stdout逐字一致，numeric JSON仅去compute_index.seconds后逐字段一致。规范SHA256：`f9140df5714e2262182f0d94f82cbca8cdd9481827e39c981ba06ad4b03746f2`。其中20项符号／常数与48×3有理输入证书分列，4次SciPy搜索只作发现，不证明全域最优；sharp结论由解析证明支持。有限耦合／静态例没有认证原history或连续几何付款。

history仅为限定索引，不作为新关键定理。原母倍率、端点、初始／删除／未来来源／尺度拼接等未付槽保留；直接几何入口与旧J路线不叠加收益。最终审查结束，不扩大研究。

最终输入 SHA256：

- `r506_main.md`: `46307dd99cbcef1d30e24305fa17b175fb0c99e9d885be214b2b6748fd0a690b`
- `r506_geometry.md`: `649e616e1360fd77e9aefa77f4389bae90363699c17e18705a277f7ca20d88bb`
- `r506_proof.md`: `2c917b2914983608c396f1e2522480775d506916c821b6bb53a24e0e4b4b845b`
- `r506_audit_pre.md`: `fc9544003f9238025492506c138cbd54879d59dceb11dd1e9ae2b611752afa33`
- `r506_audit_math_check.py`: `fa7672b8338473e8c31e9944c33528741918fa99ddf6ccd80d491beb17054d63`
- `r506_numeric.md`: `badf5d6910eb1ed0bb048e1b25b7522bf3a5c49f21a655d9effc9c3f24d678e4`
- `r506_numeric.py`: `d0d3dcd9cb53f17f2b58d7f64e44560747ad9174327c694bac65bcd3ea274818`
- `r506_numeric.json`: `be726ae47bc9a37004df8d5657931f8f09584364abcf083a05c83c82798f0f55`
- `r506_replay.json`: `4b035915a65fc31cda9e4da6c6a1d19609c34afcd18747d13770257b6d0dfd08`
- `r506_history.md`: `8b44451a858390c556b262561243e617935f70091fdf3107794e611150d3f24f`
