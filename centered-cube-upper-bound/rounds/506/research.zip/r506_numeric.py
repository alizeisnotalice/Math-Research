#!/usr/bin/env python3
"""R506 bounded scalar exploration plus finite interval certificates."""
from pathlib import Path
from fractions import Fraction as Q
import sys,platform,json,time,math
import numpy as np
import scipy
from scipy.optimize import differential_evolution, minimize_scalar
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=384
ROOT=Path(__file__).resolve().parent

def F(s,r):
 if s<=1:return s*s
 if s<=r:return s*math.log(s)+s
 return (3+math.log(r))*s-r*math.log(s/r)-2*r

def fp(s,r):
 if s<=1:return 2*s
 if s<=r:return math.log(s)+2
 return 3+math.log(r)-r/s

def chi(v,r):return 2*v if v<=1 else (1. if v<=r else 0.)

def jj(u,v):
 if u==v==0:return 0.
 return (u*math.log(2*u/(u+v)) if u else 0)+(v*math.log(2*v/(u+v)) if v else 0)

def ratio(logs,r):
 v=math.exp(logs[0]);u=v*math.exp(logs[1])
 if abs(logs[1])<1e-4:
  # A stable Hessian quadrature is used instead of subtracting near equal F values.
  nodes,weights=np.polynomial.legendre.leggauss(16)
  lo,hi=sorted((u,v));ts=lo+(hi-lo)*(nodes+1)/2
  ff=np.where(ts<=1,2,np.where(ts<=r,1/ts,r/ts**2))
  ww=(u-ts) if u>=v else (ts-u)
  D=(hi-lo)/2*float(np.dot(weights,ww*ff))
  # j = v*((1+x)log(1+x)-(2+x)log(1+x/2)), x=u/v-1.
  x=math.expm1(logs[1]);j=v*((1+x)*math.log1p(x)-(2+x)*math.log1p(x/2))
 else:D=F(u,r)-F(v,r)-fp(v,r)*(u-v);j=jj(u,v)
 return chi(v,r)*j/D if D>0 else float('nan')

def ar(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def AF(s,r):
 s,r=Q(s),Q(r)
 if s<=1:return ar(s*s)
 if s<=r:return ar(s)*ar(s).log()+ar(s)
 return (3+ar(r).log())*ar(s)-ar(r)*ar(s/r).log()-2*ar(r)

def AFP(s,r):
 s,r=Q(s),Q(r)
 if s<=1:return ar(2*s)
 if s<=r:return ar(s).log()+2
 return 3+ar(r).log()-ar(r/s)

def AJ(u,v):
 u,v=Q(u),Q(v)
 if u+v==0:return arb(0)
 return (ar(u)*ar(2*u/(u+v)).log() if u else arb(0))+(ar(v)*ar(2*v/(u+v)).log() if v else arb(0))

checks=0
def ck(flag):
 global checks
 assert bool(flag)
 checks+=1

def symbolic_certificate():
 t,s,v,r=sp.symbols('t s v r',positive=True)
 low=t*t;mid=t*sp.log(t)+t;high=(3+sp.log(r))*t-r*sp.log(t/r)-2*r
 for x in [mid.subs(t,1)-1,sp.diff(mid,t).subs(t,1)-2,high.subs(t,r)-mid.subs(t,r),sp.diff(high,t).subs(t,r)-sp.diff(mid,t).subs(t,r)]:ck(sp.simplify(x)==0)
 ck(sp.simplify(sp.diff(high,t,2)-r/t**2)==0)
 j=t*sp.log(2*t/(t+1))+sp.log(2/(t+1))
 ck(j.subs(t,1)==0)
 ck(sp.diff(j,t).subs(t,1)==0)
 ck(sp.simplify(sp.diff(j,t,2)-1/(t*(t+1)))==0)
 z=1+s*(t-1);integrand=(1-s)/(z*(z+1))
 ck(sp.simplify(sp.diff(integrand,t)+(1-s)*s*(2*z+1)/(z*z*(z+1)**2))==0)
 ck(sp.integrate(1/(2-s),(s,0,1))==sp.log(2))
 # t>=1 derivative comparison follows log(1+x)>=x log2, 0<=x<=1.
 ck(sp.simplify(sp.diff(j,t)-sp.log(2)+sp.log(1+1/t))==0)
 ck(sp.diff(sp.log(1+s),s,2)==-1/(1+s)**2)
 # Curvature comparison branch residuals, exact identities; signs follow listed domains.
 targets=[(1/(v*t)-1/t**2,(t-v)/(v*t**2)),(r/(v*v*t*t)-1/t**2,(r-v*v)/(v*v*t*t)),(1/(v*t)-1/v,(1-t)/(v*t)),(1/(v*t)-1/(v*t*t),(t-1)/(v*t*t)),(r/(v*v*t*t)-1/(v*t*t),(r-v)/(v*v*t*t))]
 for left,right in targets:ck(sp.simplify(left-right)==0)
 # Exact sharpness at u=0, 0<v<=1: D=v^2, chi*j=2v^2 log2.
 ck(sp.simplify((0-v*v-2*v*(0-v))-v*v)==0)
 ck(sp.simplify(2*v*(v*sp.log(2))-2*sp.log(2)*v*v)==0)
 ck(2*arb(2).log()<4)
 return {'uniform_constant':'2*log(2)','in_particular':'4 and 8 valid','sharpness':'u=0,0<v<=1 gives exact equality; at v=1 take left derivative chi=2','curvature_low_v':'D_Fr(u,v)>=v^2 D_F1(u/v,1), 0<v<=1','curvature_mid_v':'D_Fr(u,v)>=v D_base(u/v,1),1<v<=r','base':'Fbase second derivative 1 below1,1/s^2 above1; Dbase(t,1)=(t-1)^2/2 below1,t-log(t)-1 above1','proof_scope':'scalar analytic argument only, no true spatial dissipation payment'}

def interval_certificate():
 rows=[];eps=Q(1,10**6)
 for r in [Q(1),Q(2),Q(16),Q(1000)]:
  pairs=[(Q(0),Q(1,4)),(Q(1,8),Q(1,4)),(Q(1,4),Q(1)),(Q(1),Q(1)),(1-eps,Q(1)),(1+eps,Q(1)),(10**12*r,Q(1)),(Q(0),r),(r/2,r),(2*r,r),(r,r/2),(4*r,2*r)]
  for u,v in pairs:
   c=Q(2)*v if v<=1 else (Q(1) if v<=r else Q(0))
   if u==v:
    D=arb(0);J=arb(0);margin=arb(0);kind='exact u=v, both zero';ck(True)
   else:
    D=AF(u,r)-AF(v,r)-AFP(v,r)*ar(u-v);J=AJ(u,v)
    ck(D.is_finite() and D>0)
    if u==0 and v<=1:
     # Exact polynomial/log derivation certified symbolically, not an interval-zero test.
     margin=arb(0);kind='exact sharp equality D=v^2,chi*j=2v^2 log2'
    else:
     margin=2*arb(2).log()*D-ar(c)*J;kind='strict Arb margin'
   ck(margin.is_finite() and margin>=0)
   C4=4*D-ar(c)*J
   ck(C4.is_finite() and C4>=0)
   rows.append({'r':str(r),'u':str(u),'v':str(v),'chi_v':str(c),'D_F_arb':str(D),'JS_arb':str(J),'sharp_margin':str(margin),'margin_kind':kind,'C4_margin':str(C4)})
 return rows

def main():
 t0=time.perf_counter();explore=[]
 for r in [1,2,16,1000]:
  objective=lambda z:-ratio(z,r) if math.isfinite(ratio(z,r)) else 1e9
  sol=differential_evolution(objective,[(-18,math.log(r)),(-24,24)],seed=506,popsize=10,maxiter=80,tol=1e-9,polish=True)
  candidates=[(float(-sol.fun),list(map(float,sol.x)))]
  for v in [1.,float(r)]:
   op=minimize_scalar(lambda t:-ratio([math.log(v),t],r),bounds=(-32,32),method='bounded')
   candidates.append((float(-op.fun),[math.log(v),float(op.x)]))
  best=max(candidates)
  explore.append({'r':r,'max_ratio_found':best[0],'v':math.exp(best[1][0]),'u_over_v':math.exp(best[1][1]),'search_logv':[-18,math.log(r)],'search_log_u_over_v':[-24,24],'endpoint_refinement_log_u_over_v':[-32,32],'scope':'floating exploration only, not global optimum certificate'})
 symbolic=symbolic_certificate();intervals=interval_certificate()
 out={'scope':'scalar soft-output information inequality only; no spatial dissipation, diagonal transfer, geometry/history or general root-budget payment','environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r506_numeric.py','checks':checks,'count_meaning':'20 symbolic/strict-constant identities plus48 finite inputs x3 certificate assertions; optimization points are discovery, not certificates','exploration':explore,'symbolic_certificate':symbolic,'finite_Arb_certificates':intervals,'compute_index':{'seconds':time.perf_counter()-t0}}
 (ROOT/'r506_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print(f'PASS {checks} symbolic/Arb assertions;4 floating discovery searches,48 exact-input scalar certificates;sharp C=2log2 by scalar analytic argument only')
if __name__=='__main__':main()
