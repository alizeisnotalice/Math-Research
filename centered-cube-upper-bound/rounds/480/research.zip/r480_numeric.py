from fractions import Fraction as F
from pathlib import Path
from math import factorial
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=768
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def st(v):return str(v)
z,d,s=sp.symbols('z d s',positive=True);m=sp.symbols('m',positive=True,integer=True)
# Gamma convolution: exponents combine, leaving one monomial integral.
ck(sp.integrate(s**(m-1),(s,0,d))==d**m/m)
ck(sp.simplify(sp.factorial(m)/(m*sp.factorial(m-1)))==1)
ck(sp.diff(sp.lowergamma(m,z)/sp.gamma(m),z)==z**(m-1)*sp.exp(-z)/sp.gamma(m))
for mm in (1,2,4,16,64):
 poly=sum(z**j/sp.factorial(j) for j in range(mm))
 weighted=sum((mm-j)*z**j/sp.factorial(j) for j in range(mm))
 cdf=1-sp.exp(-z)*poly;lost=mm-sp.exp(-z)*weighted
 ck(sp.simplify(sp.diff(cdf,z)-z**(mm-1)*sp.exp(-z)/sp.factorial(mm-1))==0)
 ck(sp.simplify(sp.diff(lost,z)-sp.exp(-z)*poly)==0)
 ck(cdf.subs(z,0)==0);ck(lost.subs(z,0)==0)
 # Symbolic finite-sum layer-cake identity, exact before Arb evaluation.
 ck(sp.expand(weighted-sum(sum(z**l/sp.factorial(l) for l in range(j)) for j in range(1,mm+1)))==0)

rows=[];T=F(2,3)
for rho in (F(1),F(4),F(16),F(64)):
 expneg=(-ar(rho)).exp()
 Fs={j:1-expneg*ar(sum((rho**l/F(factorial(l)) for l in range(j)),F(0))) for j in range(1,65)}
 for mm in (1,2,4,16,64):
  p=sum((F(mm-l)*rho**l/F(factorial(l)) for l in range(mm)),F(0))
  lost=mm-expneg*ar(p);ret=ar(rho)-lost
  cumulative=sum((Fs[j] for j in range(1,mm+1)),arb(0))
  ck((lost-cumulative).contains(0));ck(lost>0);ck(ret>0)
  ck(lost<ar(rho));ck(lost<mm)
  ck(0<Fs[mm]<1)
  if mm>1:ck(Fs[mm]<Fs[mm-1])
  prev=arb(0) if mm==1 else mm-1-expneg*ar(sum((F(mm-1-l)*rho**l/F(factorial(l)) for l in range(mm-1)),F(0)))
  ck((lost-prev-Fs[mm]).contains(0))
  ck(lost>prev)
  half_rho=rho/2
  half=1-(-ar(half_rho)).exp()*ar(sum((half_rho**l/F(factorial(l)) for l in range(mm)),F(0)))
  ck(0<half<Fs[mm])
  if rho>=4 and mm>=2:ck(lost>1)
  rows.append(dict(U=str(rho*T),T=str(T),U_over_T=str(rho),m=mm,target_RN_max_at_w0=st(Fs[mm]),target_RN_at_w_U_over_2=st(half),retained_total_over_T=st(ret),cumulative_absorption_over_T=st(lost),cumulative_absorption=st(ar(T)*lost),step_m_additional_absorption_over_T=st(Fs[mm]),fraction_original_mass_absorbed=st(lost/ar(rho)),exceeds_one_T=(rho>=4 and mm>=2),exact_normalized_absorption='m-exp(-rho)*P(rho)',P_rational_at_rho=str(p)))
result=dict(scope='RAW iteration of one fixed source/band rank fiber, no x refresh. Full subprobability law, no nonempty/success normalization; no native cube/history assertion.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r480_numeric.py',seconds=time.perf_counter()-start),checks=checks,formula=dict(m_step_kernel='(v-w)^(m-1)*exp(-(v-w)/T)/(T^m*(m-1)!)*1_(0<w<v)',target_RN='F_m((U-w)/T), F_m(z)=1-exp(-z)*sum_(l=0)^(m-1) z^l/l!',cumulative_absorption='A_m=T*[m-exp(-rho)*sum_(l=0)^(m-1)(m-l)*rho^l/l!], rho=U/T',per_step_additional_absorption='A_m-A_(m-1)=T*F_m(rho)',exact_layer_cake='A_m/T=sum_(j=1)^m F_j(rho)',general_bound='0<A_m<min(U,m*T); A_m/T tends m as rho tends infinity; for fixed U,T, A_m tends U as m tends infinity'),cases=rows,exactness='Rational inputs/polynomial coefficients exact; symbolic Gamma-convolution/CDF/absorption identities. 768-bit Arb intervals, including tiny survival at rho1,m64. No Monte Carlo or tail truncation.')
(ROOT/'r480_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;20 exact-rational/Arb parameter pairs; raw fixed-fiber Gamma iteration only')
