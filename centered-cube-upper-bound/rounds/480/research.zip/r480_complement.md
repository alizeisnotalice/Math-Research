# R480：同源换父后的合法原记录提升与累计终端账

结论：R479 的两端支配允许构造一个保留旧记录副本、另抽新原记录的次概率递推。它不能同时保持旧来源对。其最大父秩核有精确 Green 公式；该公式说明单步根阶损失不能直接当作累计终端价格。本稿未得到统一收缩或完整根阶预算。

## 1. 可以提升什么，必须更换什么

沿 `/tmp/r479_main.md` 的固定原场及参数。以 \(\xi\) 表示完整原记录，父为 \(A(\xi)\)。令
\[
\overline\Pi(d\xi,dx,ds)=\Pi(d\xi)\pi_A(dx)ds,
\qquad s\in(0,1),\quad j=j(A).
\]
其父—附源—标记推前为
\[
\widehat\nu(dA,dx,ds)=t(A)\sigma(dA)\pi_A(dx)ds.
\]
这是同一原 \(\Pi\) 的扩展；总质量仍为 \(R\)。按实际记录空间的标准Borel结构，写原条件记录核 \(\mathcal C_A(d\xi)=\Pi(d\xi\mid A)\)。零 \(t(A)\) 处任取，不影响测度。

对当前完整记录运行 R479 的实际成功构造，输出 \((B_*,x,s_*)\) 并保留旧记录与全族。成功输出推前由 \(\widehat\nu\) 支配。随后**另抽** \(\xi'\sim\mathcal C_{B_*}\)，保留同一 \(x,s_*\)。由输出支配及条件积分，得到次概率核 \(K\) 满足
\[
\boxed{\overline\Pi K\le\overline\Pi.} \tag{1}
\]
旧 \(\xi\) 始终可以留在联合空间中；(1)只描述新的当前记录边缘。新记录确来自原 \(\Pi\)，不是把旧阶段、时钟或路径移植到辅助父。所有原 \(f,m,q,t,u_j\) 和样本强度固定。

输出若为a(B,x,s)νhat，则给定B后新记录与(x,s)独立，而x的条件律一般是π_B的倾斜，不等于重新独立抽x~π_B。后续只用测度支配，不把该倾斜改回原律。

这种提升不能保旧 \(y,z\)：成功事件有 \(y,z\notin Q_{B_*}\)，而 \(\mathcal C_{B_*}\) 的来源对 \(y',z'\) 必在 \(Q_{B_*}^2\)。二者所在来源集合不交，不能用一个小总变差误差把它们视为同一对。旧父和新父的全历史也不相同。刷新没有丢弃原质量，却不保任何依旧来源或旧历史定义的被积函数；只保当前目标的正质量及(1)。

## 2. 同一参考上的迭代及原费用

因每轮新当前记录边缘受同一 \(\overline\Pi\) 支配，可以数学上迭代 \(K\)。令 \(\Omega_i=\overline\Pi K^i\)。由(1)和正性，\(\Omega_{i+1}\le\Omega_i\)。每次都重新调用真实原条件记录核，不声称这是原历史本身的延续。

置 R479 单步预算
\[
E=\bigl[\tau+\delta S+2rS^2/T\bigr]X+\kappa T\mathcal M,
\qquad \mathcal M\le NW.
\]
则 \(|\overline\Pi|-|\overline\Pi K|\le E\)。但对任意整数 \(N\)，直接迭代只能给
\[
R\le |\Omega_N|+NE. \tag{2}
\]
若 \(e(\omega)=1-K1(\omega)\)，真正的逐轮停止测度是 \(e\,\Omega_i\)，且
\[
R-|\Omega_N|=\sum_{i=0}^{N-1}\int e\,d\Omega_i. \tag{3}
\]
\(\overline\Pi-\overline\Pi K\) 是边缘缺额；其传播的总质量等于相应损失，但它不能在位置上被直接等同于(3)的停止测度。

## 3. 原 Poisson 核给出精确累计放大

固定同一 \((j,x)\)，记 \(U=u_j(x)\)。新记录刷新不改变 \(x,j\) 或最大父增广秩，故每一步秩严格下降。令 \(K_0\) 为只取非空最大点、随后同样补原条件记录的未筛核。它的秩核为
\[
K_0(v,dw)=T^{-1}e^{-(v-w)/T}1_{0<w<v}dw.
\]
实际 \(K\le K_0\)，包括全部原成功筛选。直接卷积得
\[
K_0^m(v,dw)=
\frac{e^{-(v-w)/T}(v-w)^{m-1}}{T^m(m-1)!}
1_{w<v}dw\quad(m\ge1),
\]
\[
\boxed{\sum_{m\ge1}K_0^m(v,dw)=T^{-1}1_{w<v}dw.} \tag{4}
\]
该式保真实中心条件纤维：每次输出中心仍按原增广中心测度的秩条件分布，之后才补原记录。质量原子已经用独立标记展开，不能在(4)另扣原子项。

从完整原父秩 \(dv\) 出发，包括初始时刻的累计占用相对于原参考的密度为
\[
V_U(w)=1+(U-w)/T. \tag{5}
\]
实际成功核的占用由它正支配。因此对所有实际停止事件有完整、但尚非根阶的预算
\[
\sum_{i\ge0}\int e\,d\Omega_i
\le\int \Bigl[1+\frac{u_j(x)-v}{T}\Bigr]
 e(\xi,x,s)\,d\overline\Pi(\xi,x,s). \tag{6}
\]
原生 \(u_j\le S\min\{1+n\log(b/a),1+L+\log r\}\)。统一取上界后，单步预算最多被 \(1+S(1+L+\log r)/T\) 放大；当 \(L=\sqrt n\) 时，这不能保住单步来源项的根阶。

即使仅保未筛核的空样本停止，问题已精确可见：单步每纤维损失为 \(T(1-e^{-U/T})\le T\)，而累计停止价格是
\[
\int_0^U\Bigl[1+\frac{U-w}{T}\Bigr]e^{-w/T}dw=U. \tag{7}
\]
所以不能把每纤维一次 \(T\) 的边界账用于全部到达。式(7)是当前真实秩核的恒等式，不是另造几何反例；它并未排除实际外部成功门可能提供额外收益。

## 4. 终端与唯一缺桥

未筛链从秩 \(v\) 出发的成功跳数服从均值 \(v/T\) 的 Poisson 分布，因而有限且
\[
|\Omega_N|\le\frac1{NT}\int\sum_j\frac{u_j(x)^2}{2}\,d\mu(x)
\longrightarrow0. \tag{8}
\]
同一结论也可由(4)的有限总占用及生存质量递减推出。停止确实完整；困难不是漏掉终端，而是累计终端质量最终恰为 \(R\)。现有工具只有一次 \(\int e\,d\overline\Pi\le E\)，没有对(6)的秩加权失败通量给出 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)W\) 的估计。

要使这一递推付款，必须使用原外部族几何或原接受权，控制实际 Green 占用在停止集合上的集中；不能以新的原记录资格取代这个费用。当前所得可实现提升、精确(4)–(7)与有限终端并未提供该比较，因此不计为完整预算改善，停止此机制。

## 5. 实际本机核验

指定本机 Python/SymPy 实跑下列完整脚本：

```text
PASS 18 exact symbolic assertions; rank Green and terminal accounting, not a native-history fixture.
```

它核一般卷积、全纤维占用及累计空停止恒等式。未模拟实际立方体完整历史，也未把数值代替上述一般论证。

```python
import sympy as s
v,w,z,T,U=s.symbols('v w z T U', positive=True)
checks=0
for m in [1,2,3,5]:
    km=s.exp(-(v-z)/T)*(v-z)**(m-1)/(T**m*s.factorial(m-1))
    step=s.exp(-(z-w)/T)/T
    got=s.integrate(km*step,(z,w,v))
    want=s.exp(-(v-w)/T)*(v-w)**m/(T**(m+1)*s.factorial(m))
    assert s.simplify(got-want)==0
    checks+=1
occupation=1+(U-w)/T
empty=s.integrate(occupation*s.exp(-w/T),(w,0,U))
assert s.simplify(empty-U)==0
checks+=1
visits=s.integrate(occupation,(w,0,U))
assert s.simplify(visits-(U+U**2/(2*T)))==0
checks+=1
for u in [s.Rational(1,2),s.Integer(1),s.Integer(3),s.Integer(10)]:
    for t in [s.Rational(1,3),s.Integer(1),s.Integer(4)]:
        one=t*(1-s.exp(-u/t))
        extra=s.integrate((u-w)/t*s.exp(-w/t),(w,0,u))
        assert s.simplify(one+extra-u)==0
        checks+=1
print(f'PASS {checks} exact symbolic assertions; rank Green and terminal accounting, not a native-history fixture.')
```
