# R480：同一成功流的平移势检查——未获得新的根阶收据

## 1. 唯一候选及原测度

只研究 R479 的实际 \(\Omega=\Psi_{\rm ext}\)，记 \(Q=|\Omega|\)、\(R=|\Pi|\)。其原父 \(A\)、最大父 \(B=B_*\)、人工来源 \(x\)、旧 \(y,z\) 及全部历史均不改变。两个 \((A,x,j)\)、\((B,x,j)\) 边缘 \(\nu_L,\nu_R\) 由同一原 \(\nu\) 支配，\(|\nu|=R\)。正缺额
\[
 d_L=\nu-\nu_L,\quad d_R=\nu-\nu_R,
 \qquad |d_L|=|d_R|=\Delta:=R-Q
\]
满足
\[
 \Delta\le[\tau+\delta S+2rS^2/T]X+\kappa T\mathcal M.
\tag{1}
\]
原参数为 \(H=S/\tau\)、\(T=1024rSH/\delta\)、\(\kappa=8\log(4/\delta)\)。已知
\[
 \mathcal L:=\int_\Omega|\log(R_A/R_B)|
 \le TD_mW/n+(\log r/n)R.\tag{2}
\]
本次候选是：利用双中心外置产生的正平移量，以同一来源 \(x\) 的二次位置势作有符号结算；尝试由两端共同边缘消去循环重复。以下核查表明它还留下实际来源—平移相关项，不能据此付款。

## 2. 精确平移式与可合法计价的部分

设
\[
 z=\frac{x-A}{R_A},\qquad d=\frac{B-A}{R_A},\qquad
 \rho=\frac{R_A}{R_B},\qquad
 h(C,x)=\frac{|x-C|_2^2}{R_C^2}.
\]
因 \(x\in Q_A\cap Q_B\)，\(0\le h\le n/4\)。同一记录逐点恒等式为
\[
 |d|_2^2-2z\cdot d
 =h(B,x)-h(A,x)+(\rho^{-2}-1)h(B,x).\tag{3}
\]
定义真实积分 \(E=\int_\Omega|d|_2^2\)、\(\mathcal W_{\rm tr}=\int_\Omega z\cdot d\)。双中心外置给 \(\|B-A\|_\infty>\max(R_A,R_B)/2\)，从而
\[
 E\ge Q/4.\tag{4}
\]
这里使用中心几何，没有把边界体积换成来源质量。

对同一可测势 \(h\)，两端正缺额给
\[
 \int_\Omega[h(B,x)-h(A,x)]=\int h\,dd_L-\int h\,dd_R,
 \quad\left|\int_\Omega[h(B,x)-h(A,x)]\right|\le\frac n4\Delta.
\tag{5}
\]
因为每个缺额的积分都在 \([0,n\Delta/4]\)，不是另付两倍。单 octave 给 \(1/2\le\rho\le2\)；对 \(u=\log\rho\)，\(|e^{-2u}-1|\le8|u|\)。因此
\[
 \boxed{\left|E-2\mathcal W_{\rm tr}\right|
 \le\frac n4\Delta+2n\mathcal L.}\tag{6}
\]
由 (4)、(6) 进一步只有
\[
 Q\le8\mathcal W_{\rm tr}+n\Delta+8n\mathcal L.\tag{6a}
\]
这是本次尝试的完整有效结论。即便另外能控制 \(\mathcal W_{\rm tr}\) 的符号，仍有维数损失：\(L=\sqrt n\)、固定 \(r,S,\tau,\delta\) 时，已证 \(\Delta\) 上界含 \(O(\sqrt n)W\)，乘 \(n\) 后就是 \(O(n^{3/2})W\)，且 \(n\tau X\) 不能按原固定吸收参数处理；半径项另给 \(O(n)W\)。因此失败不只是尚缺 work 的符号，二次势本身的边缘振幅也过大。故 (6)–(6a) 不提供新的主账收据；旧 (1)–(2) 不被重新扣费。

## 3. 决定性未控项及不能采用的消去

未控项明确为
\[
 \mathcal W_{\rm tr}=
 \int_\Omega \frac{(x-A)\cdot(B_*-A)}{R_A^2}.
\tag{7}
\]
虽然人工 \(x\) 在原记录后按 \(\pi_A\) 独立抽取，但 \(B_*\)、Poisson 可用父集合和成功事件均依赖 \(x\)。因而给定 \((A,B_*)\) 后，\(x\) 不服从 \(\pi_A\)。即使不考虑筛选，任意 \(f\) 下 \(\pi_A\) 的重心也不必为 \(A\)。不能把 (7) 置零，不能用新的 \(x'\sim\pi_A\) 代替它后声称仍是原积分。

准确地，令 \(\chi(A,x)=d\nu_L/d\nu\in[0,1]\)，并取原联合流的条件均值
\(v(A,x)=\mathbb E_\Omega[(B_*-A)/R_A\mid A,x,j]\)。则
\[
 \mathcal W_{\rm tr}=\int\chi(A,x)\frac{x-A}{R_A}\cdot v(A,x)\,d\nu.
\tag{8}
\]
原条件来源的中心性与该实际 \(x\)-依赖位移之间没有已证正交、符号或根阶协方差界。这是此机制需要的新几何输入，不能由两个边缘支配单独推出。

选取最大位移坐标可把单坐标势范围降到 \(1/4\)，但坐标索引变成 \(i(A,B_*,x)\)。此时 (5) 不再适用：两端共同 \(\nu\) 没有携带同一坐标选择标记。逐坐标相加恢复 (6) 的 \(n\) 因子。因此本稿没有用“自适应方向”掩盖该费用。

结论只限这一条机制：需要对 (8) 的实际来源—位移相关作与成功筛选相容的几何结算，同时避免位置势的维数损失。原 \(y,z\) 排斥整个族仍保留，但目前没有将它转成该有符号相关量的可付上界。整体 \(Q\) 的根阶预算仍未证明；不再添加辅助抽样或新的余项名称。

## 4. 本机小型恒等式证书

指定 Python 环境实际运行下列代码。27 个共同捕获点、双中心外置的立方体配置只检查 (3)–(6) 的代数及区间常数；不是完整匹配场或原历史实例。

```python
from fractions import Fraction as F
from flint import arb, ctx
ctx.prec=192
count=0
for n in (1,2,5):
 for rb in (F(3,4),F(1),F(5,4)):
  d0=(1+rb)/2-F(1,10)
  for x0 in (F(17,40),F(9,20),F(19,40)):
   z=[x0]+[F(1,8)]*(n-1)
   d=[d0]+[F(0)]*(n-1)
   rho=1/rb
   hA=sum(v*v for v in z)
   hB=sum((rho*(a-b))**2 for a,b in zip(z,d))
   energy=sum(v*v for v in d)
   work=sum(a*b for a,b in zip(z,d))
   assert energy-2*work==hB-hA+(1/rho**2-1)*hB; count+=1
   assert d0>max(F(1),rb)/2 and energy>F(1,4); count+=1
   assert hA<=F(n,4); count+=1
   assert hB<=F(n,4); count+=1
for rho in (F(4,3),F(4,5)):
 ar=arb(rho.numerator)/rho.denominator
 assert abs(1/ar**2-1)<8*abs(ar.log());count+=1
print('PASS 27 cube-point algebra configurations; 110 assertions (108 Fraction, 2 Arb).')
```

运行命令使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。实际输出：`PASS 27 cube-point algebra configurations; 110 assertions (108 Fraction, 2 Arb).` 一般证明不依赖这些有限检查。
