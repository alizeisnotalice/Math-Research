"""R720 joint Shannon ledger, skew groups, and real independent copies.

Only entropy_audit.json is generated. Exact rational joint laws plus local
Arb256/384 logarithms and remote Decimal110 independent aggregates.
"""
from fractions import Fraction as F
from pathlib import Path
from random import Random
import hashlib,json,platform,socket,subprocess,sys


def cases():
    out=[([F(1)],[F(1)],[(F(2),[0])]),
         ([F(1),F(4)],[F(1,2),F(1,2)],[(F(1),[0,1])]),
         ([F(1),F(1)],[F(1,3),F(2,3)],[(F(1,7),[0,1]),(F(6,7),[0,1])]),
         ([F(1),F(2)],[F(1,3),F(2,3)],[(F(1,5),[0]),(F(4,5),[1])])]
    rng=Random(72020261118)
    for _ in range(60):
        N=rng.randrange(2,8);G=rng.randrange(1,8)
        volumes=[F(rng.randrange(1,10),1<<rng.randrange(0,5)) for i in range(N)]
        theta=[F(rng.randrange(1,10),32) for i in range(N)]
        groups=[]
        for g in range(G):
            pool=[i for i in range(N) if rng.randrange(2)]
            if not pool:pool=[rng.randrange(N)]
            groups.append((F(rng.randrange(1,13),rng.randrange(1,9)),pool))
        out.append((volumes,theta,groups))
    return out


def joint_law(case):
    d,theta,groups=case;M=sum((m for m,p in groups),F(0));D=sum((x*y for x,y in zip(d,theta)),F(0))
    J={};Ji=[F(0)]*len(d);alpha=[];Q=[];dg=[]
    for g,(mass,pool) in enumerate(groups):
        aa=mass/M;qq=sum((theta[i] for i in pool),F(0));dd=min(d[i] for i in pool)
        alpha.append(aa);Q.append(qq);dg.append(dd)
        for i in pool:J[g,i]=aa*theta[i]/qq;Ji[i]+=J[g,i]
    assert sum(J.values(),F(0))==1 and sum(Ji,F(0))==1
    for i,v in enumerate(Ji):
        if v:assert sum((x/v for (g,j),x in J.items() if j==i),F(0))==1
    scales=[d[i]*theta[i]/v for i,v in enumerate(Ji) if v]
    Dused=sum((d[i]*theta[i] for i,v in enumerate(Ji) if v),F(0))
    equality=len(set(scales))==1 and Dused==D
    return d,theta,groups,M,D,J,Ji,alpha,Q,dg,equality


def remote_checks():
    from decimal import Decimal as D,localcontext
    def cv(q):return D(q.numerator)/q.denominator
    with localcontext() as c:
        c.prec=110;rows=[]
        for idx,case in enumerate(cases()):
            d,theta,groups,M,total,J,Ji,alpha,Q,dg,equality=joint_law(case)
            base=sum(cv(alpha[g])*(cv(Q[g]*dg[g]/mass)).ln() for g,(mass,pool) in enumerate(groups))
            inflation=sum(cv(v)*cv(d[i]/dg[g]).ln() for (g,i),v in J.items())
            entropy=-sum(cv(v)*cv(v/Ji[i]).ln() for (g,i),v in J.items())
            gap=cv(total/M).ln()-base-inflation+entropy
            rows.append({'case':idx,'values':[str(base),str(inflation),str(entropy),str(gap)]})
        real=[]
        for b in [32,48,64]:
            n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
            lh=(1+D(1)/a).ln();g=(1-D(2)/a).ln();qraw=(D(n-1)*g).exp();W=(1-qraw)/8+qraw/a
            J=int(D(root)/W);q=(-W/t).exp();alpha=1-q;mass=1-(D(J)*(-W/t)).exp()
            growth=-D(n)*g/D('.5')*(D(J)-q*mass/alpha)
            kappa=(D(n)*lh).exp();lower=t/(2*kappa*D('.5'))*(D('.5')-kappa/t)**2
            for K in [4,8,16]:
                JB=int(D(K*root)/W);lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(J)*g
                lp=D(n)*g-W/t;fd=(1-(-W/t).exp())/(1-lp.exp())
                logDA=D(n)*l2+D(n)*lRA+fd.ln();logmg=-D((3*b//4+4)*n)*l2
                base=D('.5').ln()+D(n)*(l2+lAmin)-logmg
                gap=logDA-logmg-base-growth
                real.append({'b':b,'K':K,'values':[str(growth),str(lower),str(gap)]})
        return {'host':socket.gethostname(),'python':sys.version,'finite_rows':rows,'real_rows':real}


if '--remote' in sys.argv:
    print(json.dumps(remote_checks()));raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent


def cv(q):return arb(q.numerator)/q.denominator
def st(x):return x.str(38)


def floor_unique(x):
    v=x.floor().unique_fmpz();assert v is not None
    return int(v)


def finite_case(case,index,bits):
    ctx.prec=bits
    d,theta,groups,M,D,J,Ji,alpha,Q,dg,equality=joint_law(case)
    base=sum((cv(alpha[g])*cv(Q[g]*dg[g]/mass).log() for g,(mass,pool) in enumerate(groups)),arb(0))
    inflation=sum((cv(v)*cv(d[i]/dg[g]).log() for (g,i),v in J.items()),arb(0))
    entropy=-sum((cv(v)*cv(v/Ji[i]).log() for (g,i),v in J.items()),arb(0))
    lhs=cv(D/M).log();gap=lhs-base-inflation+entropy
    assert entropy>=0 or entropy.contains(0)
    if equality:assert gap.contains(0)
    else:assert gap>0
    # Check the exact pre-Jensen expansion independently source by source.
    source_log=sum((cv(v)*cv(d[i]*theta[i]/(M*v)).log() for i,v in enumerate(Ji) if v),arb(0))
    assert (source_log-(base+inflation-entropy)).contains(0)
    return {'case':index,'source_count':len(d),'group_count':len(groups),'D_exact':str(D),'M_exact':str(M),
            'source_volumes_exact':list(map(str,d)),'source_theta_exact':list(map(str,theta)),
            'groups':[{'mass':str(m),'pool':p,'Q':str(Q[g]),'d_min':str(dg[g])} for g,(m,p) in enumerate(groups)],
            'base':st(base),'volume_inflation':st(inflation),'H_G_given_I':st(entropy),
            'log_D_over_M':st(lhs),'Jensen_gap':st(gap),'exact_equality_condition':equality,
            'joint_marginals_and_source_splits_exact':True,'precision_bits':bits,
            '_values':(base,inflation,entropy,gap)}


def skew_checks():
    ctx.prec=384;rows=[]
    # Identical pool theta=(1/4,1/2,1/4), volumes=(1,2,8), Q=1,dg=1,M=1.
    # Source I is independent of group G, so conditional entropy is H(alpha).
    for exponent in [16,64,128]:
        G=1<<exponent
        for eps in [F(1,2),F(1,1024),F(1,1<<32)]:
            e=cv(eps)
            entropy=-(1-e)*(1-e).log()-e*e.log()+e*arb(G-1).log()
            nominal=arb(G).log()
            inflation=cv(F(5,4))*arb(2).log()
            base=entropy;lhs=cv(F(13,4)).log();gap=lhs-inflation
            assert gap>0 and entropy<=nominal
            rows.append({'group_count_exact':str(G),'epsilon_exact':str(eps),
                         'mass_law':'one group1-epsilon; remaining G-1 groups each epsilon/(G-1)',
                         'H_G_given_I':st(entropy),'nominal_log_group_count':st(nominal),
                         'base':st(base),'volume_inflation':st(inflation),
                         'rhs_after_entropy_exact_formula':'(5/4)*log2',
                         'log_D_over_M':st(lhs),'Jensen_gap':st(gap),
                         'source_splits':'s(g|i)=alpha_g for every one of the3 shared sources'})
    return rows


def real_case(b,K,bits):
    ctx.prec=bits;A=arb;n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();t=A(root)/l2
    lh=(A(1)/a).log1p();kappa=(n*lh).exp();g=(-A(2)/a).log1p()
    W=-((n-1)*g).expm1()/8+((n-1)*g).exp()/a
    JA=floor_unique(A(root)/W);eA=root-JA*W;JB=floor_unique(A(K*root)/W);eB=K*root-JB*W
    lRB=lh-JB*g;lAmin=lRB+l2/n+lh;lRA=lAmin-JA*g
    assert lRA<l2 and lRB<l2 and n*(lAmin-lRB)>l2
    q=(-W/t).exp();alpha=-(-W/t).expm1();Q=A('.5');fullmass=-(-JA*W/t).expm1()
    growth=(-n*g)/Q*(JA-q*fullmass/alpha)
    positive=Q-kappa/t
    assert positive>0
    growth_lower=t/(2*kappa*Q)*positive**2
    assert growth>=growth_lower
    lp=n*g-W/t
    def fd(J,e):return (-(-W/t).expm1())*(-(J*lp).expm1())/(-lp.expm1())+(J*lp).exp()*(-(-e/t).expm1())
    logDA=n*l2+n*lRA+fd(JA,eA).log()
    receiver_clock=(-A((3*b//4+5)*n)*l2).exp()
    Dscaled=fd(JA,eA)+(n*(lRB-lRA)).exp()*fd(JB,eB)+(-K*l2-n*lRA).exp()*(-(-receiver_clock/t).expm1())
    logD=n*l2+n*lRA+Dscaled.log()
    logM=-A((3*b//4+4)*n)*l2
    base=Q.log()+n*(l2+lAmin)-logM
    gap=logDA-logM-base-growth
    assert gap>0
    # D contains DA plus positive B/receiver budgets; their relative size may
    # be far below working precision, so these log enclosures can overlap.
    assert logD>logDA or logD.overlaps(logDA)
    copies=[]
    for r in [1,2,16,1024,1<<40]:
        count_log=A(r).log()
        copies.append({'copies_exact':str(r),'physical_translation_rule':'copy ell shifted by20*ell*e1; all copy parents lie within radius5 of its copy center',
                       'log_DA_total_over_M_total':st(logDA-logM),
                       'H_G':st(count_log),'I_G_and_I':st(count_log),'H_G_given_I_exact':'0',
                       'joint_rhs':st(base+growth),'Jensen_gap':st(gap),
                       'replication_cancels_exactly':True})
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,'Q_exact':'1/2',
            'group_mass_M':st(logM.exp()),'incident_budget_DA':st(logDA.exp()),'full_true_D':st(logD.exp()),
            'd_g_min_incident_volume':st((n*(l2+lAmin)).exp()),
            'actual_theta_average_log_di_over_dg':st(growth),
            'local_owner_growth_lower':st(growth_lower),'growth_over_lower':st(growth/growth_lower),
            'base':st(base),'H_G_given_I_exact':'0','Jensen_gap_using_incident_DA':st(gap),
            'Jensen_gap_using_full_D':st(logD-logM-base-growth),'independent_copies':copies,
            '_values':(growth,growth_lower,gap)}


def main():
    finite=[];real=[]
    for idx,case in enumerate(cases()):
        lo=finite_case(case,idx,256);hi=finite_case(case,idx,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_remote_values']=[float(x) for x in hi['_values']];del hi['_values'];finite.append(hi)
    for b in [32,48,64]:
        for K in [4,8,16]:
            lo=real_case(b,K,256);hi=real_case(b,K,384)
            for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
            hi['_remote_values']=[float(x) for x in hi['_values']];del hi['_values'];real.append(hi)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    if '--reuse-failed-ssh' in sys.argv:
        remote=json.loads((BASE/'entropy_audit.json').read_text())['remote']
        assert remote['exit_code']!=0
        remote['reused_failure_after_second_live_banner_timeout']=True
    else:
        run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
        remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
        if run.returncode==0:remote['result']=json.loads(run.stdout)
        else:remote['stdout']=run.stdout
    if remote['exit_code']==0:
        for local,other in zip(finite,remote['result']['finite_rows']):
            assert local['case']==other['case']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        for local,other in zip(real,remote['result']['real_rows']):
            assert local['b']==other['b'] and local['K']==other['K']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:
        # Persistent remote failure is recorded honestly. A separate local
        # Decimal implementation still provides an independent backend check.
        fallback=remote_checks()
        for local,other in zip(finite,fallback['finite_rows']):
            assert local['case']==other['case']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        for local,other in zip(real,fallback['real_rows']):
            assert local['b']==other['b'] and local['K']==other['K']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['local_Decimal110_fallback']=fallback
        remote['local_Decimal110_crosscheck_passed']=True
    for row in finite+real:del row['_remote_values']
    skew=skew_checks()
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'finite_Jensen_cases':finite,'skew_shared_source_cases':skew,'real_single_A_cases':real,'remote':remote,
            'exact_identity':['J_gi=(m_g/M)*theta_i/Q_g, J_i=sum_gJ_gi, s(g|i)=J_gi/J_i. All finite marginals and splits are computed as exact Fractions.',
                              'theta_i/(M*J_i)=(Q_g/m_g)*s(g|i). Consequently sum_iJ_i log(d_i theta_i/(M J_i))=sum_g alpha_g log(Q_g d_g/m_g)+sum_giJ_gi log(d_i/d_g)-H(G|I).',
                              'Jensen gives log(D/M) at least this expression, including when D contains unincident sources. Equality conditions are checked algebraically; zero-containing intervals are not treated as a positive gap.',
                              'The real A owner-growth average is computed from complete layer masses and the final partial layer with minimum volume. Its closed expression is(-n log rho)/Q*[JA-q(1-q^JA)/(1-q)], q=exp(-W/t), Q=1/2.'],
            'scope':['The64 rational cases test the Shannon/Jensen identity, not cube-history geometry. The9 huge nominal group examples are compressed finite probability laws with three shared sources, not actual cube inputs.',
                     'The9 real A groups are the actual R717 truncated two-center finite histories. All original A sources share the same real half-cross point, with the full source coefficients and owner volumes unchanged.',
                     'Independent copies are actual spatially separated full copies. Their local greedy histories interleave without changing coefficients because parent supports of different copies are disjoint. The source identity determines the copy, giving H(G|I)=0 exactly.',
                     'The entropy budget and owner-growth lower pass these tests; no uniform comparison between conditional entropy and volume growth is proved for arbitrary overlapping groups.',
                     'Local Arb384 logs are crosschecked against256 bits. The independent Decimal110 mode checks all finite Jensen aggregates and real growth/gaps; its actual host and execution status are recorded. If remote SSH fails, it is run locally and is not described as a completed MacBook calculation. Decimal neglects real-history terms far below its precision; local Arb retains them.',
                     'Only entropy_audit.py/json are created. No Git, remote files, GPU use or remaining process.']}
    output=BASE/'entropy_audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'finite_cases':len(finite),'exact_equalities':sum(r['exact_equality_condition'] for r in finite),
                      'skew_cases':len(skew),'remote_exit':remote['exit_code'],'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'local_Decimal_fallback_passed':remote.get('local_Decimal110_crosscheck_passed',False),
                      'real_growth':[{k:r[k] for k in ['b','K','actual_theta_average_log_di_over_dg','local_owner_growth_lower','growth_over_lower']} for r in real]},indent=2))


if __name__=='__main__':main()
