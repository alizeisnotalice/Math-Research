"""Exact finite tests of the size-biased second moment and the owner overlap bound."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from math import prod
from random import Random
import json, sys
from math import log

def boxes(n, seed):
    rng=Random(seed)
    a=32*n
    h=1+F(1,a)
    t=4
    sources={}
    # Distinct lattice centers ensure disjoint shrunken owners.
    for _ in range(90):
        y=tuple(rng.randint(-4,4) for j in range(n))
        r=rng.choice((1,2,3,4,6,8))
        d=(2*r)**n
        vol=F(d,a**n)
        theta=vol*F(rng.randint(1,8),8*t*d)
        sources[y]=(r,d,theta)
    probes=list(sources)[:14]
    pools=[set(y for y,(r,_,_) in sources.items() if max(abs(u-v) for u,v in zip(y,w))<=r) for w in probes]
    masses=[F(rng.randint(1,16),7) for w in probes]
    D=[sum(sources[y][1]*sources[y][2] for y in P) for P in pools]
    total=sum(sources[y][1]*sources[y][2] for y in set.union(*pools))
    ag={i:sources[i][1]*sources[i][2] for i in set.union(*pools)}
    M=sum(masses)
    L={i:sum((masses[g]/D[g] for g,P in enumerate(pools) if i in P),F(0)) for i in ag}
    nu={i:a*L[i]/M for i,a in ag.items()}
    entropy=-sum(float(masses[g]*ag[i]/(M*D[g]))*log(float((masses[g]/D[g])/L[i])) for g,P in enumerate(pools) for i in P)
    kl=sum(float(v)*log(float(v*total/ag[i])) for i,v in nu.items())
    base=sum(float(m/M)*log(float(d/m)) for m,d in zip(masses,D))
    assert abs(log(float(total/M))-(base-entropy+kl))<1e-10
    eps=max(m/d for m,d in zip(masses,D))
    cross=sum(a*(l*l-sum((masses[g]/D[g])**2 for g,P in enumerate(pools) if i in P)) for i,(a,l) in ((i,(ag[i],L[i])) for i in ag))
    assert cross>=0
    # lambda=25 eps/16 gives an exactly rational square-root coefficient 4 eps.
    lam=25*eps/16
    # sqrt(lambda)=5sqrt(eps)/4, sqrt(lambda-eps)=3sqrt(eps)/4.
    assert M<=lam*total+cross/(4*eps)
    pairs=0; positive=0; tighter=0; quadratic=0
    for g,k in combinations_with_replacement(range(len(pools)),2):
        both=pools[g]&pools[k]
        val=sum((sources[y][1]*sources[y][2] for y in both),F(0))
        upper=min(max(sources[y][0] for y in P) for P in (pools[g],pools[k]))
        box=prod(max(F(0),2*h*upper-abs(x-y)) for x,y in zip(probes[g],probes[k]))/t
        assert val<=box
        pairs+=1;positive+=bool(val);tighter+=bool(box<(2*h*upper)**n/t)
        quadratic+=(1+(g!=k))*masses[g]*masses[k]*val/(D[g]*D[k])
    M=sum(masses)
    assert M*M<=total*quadratic
    return [pairs,positive,tighter]

def main():
    stages={}
    for label,dims in [('initial',[1,2]),('pressure',[3,4,8]),('extended',[12,16,32])]:
        out=[boxes(n,17*n+k) for n in dims for k in range(4)]
        stages[label]={'dimensions':dims,'seeds_per_dimension':4,'checked_pairs':sum(x[0] for x in out),'positive_shared_value':sum(x[1] for x in out),'strictly_smaller_than_full_box':sum(x[2] for x in out)}
    rows=[]
    for N in [8,1024,2**32,2**128]:
        for u in [F(1,N),F(1),F(N)]:
            q=(1+N*u)/(1+u)**2
            assert (N+u)*q>=N
            rows.append({'N':N,'shared_value':str(u),'normalized_second_moment':str(q)})
    print(json.dumps({'python':sys.version,'stages':stages,'abstract_hub_tests':rows,'scope':'Disjoint real owners and subcapacity weights for overlap test. No first-crossing condition imposed. Hub tests are incidence models.'},indent=2))
if __name__=='__main__':main()
