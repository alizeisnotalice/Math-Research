"""Exact integer grid checks. All physical coordinates use common integer units."""
import json,os,sys,socket,time
from multiprocessing import get_context
def run(arg):
    s,H=arg # source radius, upper receiver-to-witness displacement
    a=32
    count=outside=forced=0
    # Work in units 1/a, anchor zero, S=s*a, and R rounded upward.
    S=s*a
    for w in range(-H,H+1,2):
        for y in range(-S,S+1,3):
            off=abs(y-w)>S
            # A source interval contains zero; the shared test radius is 2H.
            overlap=max(0,min(y+S,w+2*H)-max(y-S,w-2*H))
            assert overlap>=min(S,H)
            outside+=off
            for noise in (0,s,-s):
                Y=y+noise
                for R in (S,S+1,S+max(2,S//8)):
                    cert=a*abs(Y-w)>(a+1)*R
                    assert not cert or off
                    # Expanded parent, test n=16 and arbitrary a=32.
                    inflated_cert=16*a*abs(Y-w)>(16*(a+1)+a)*R
                    assert not inflated_cert or 16*abs(y-w)>17*S
                    forced+=cert;count+=1
    return count,outside,forced,os.getpid()
if __name__=='__main__':
    parity,workers,level=map(int,sys.argv[1:])
    jobs=[(s,H) for s in range(2+parity,level+1,2) for H in (16,32,64,96)]
    with get_context('fork').Pool(workers) as pool:out=pool.map(run,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=len(set(x[3] for x in out)),parameters=[parity,workers,level],checks=sum(x[0] for x in out),outside=sum(x[1] for x in out),forced=sum(x[2] for x in out))))
