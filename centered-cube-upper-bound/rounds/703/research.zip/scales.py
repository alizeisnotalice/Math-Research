from flint import arb,ctx
import flint,json,sys
ctx.prec=700
cases=inert=0;examples=[]
for b in range(8,1001):
    n=2**b
    L=arb(n).log()
    t=arb(n).sqrt()
    h=1+arb(1)/(32*n)
    ell=(2*h*n/L).log()+(1+arb(2).log())/n
    B=arb(1).exp()*(arb(n)*(arb(1)/(32*n)).log1p()).exp()*n*ell/t
    for p in (2,4,8,16):
        w=((1-arb(1)/p)*(L/t).log()).exp()
        N=int((40*L/w).ceil().unique_fmpz())
        inactive=N>=n
        inert+=inactive
        if not inactive:
            alpha=(w*(-arb(1)/n).exp()-arb(1)/n)/(2*h)
            logloss=B.log()+N*(-alpha).log1p()
            assert logloss< -L
        # Real-valued pre-rounding moment/volume balance and integer rounding bound.
        moment=arb(n)*(arb(min(N,n))/t)**(p-1)
        assert moment<arb(42)**(p-1)*n*w
        if b in (16,64,256,1000) and p==8:
            examples.append([b,N,inactive,str((n*w).log()/L)])
        cases+=1
print(json.dumps(dict(flint=flint.__version__,python=sys.version,precision=ctx.prec,cases=cases,all_axes=inert,samples=examples)))
