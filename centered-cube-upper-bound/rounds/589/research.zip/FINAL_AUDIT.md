# R589 冻结全文最终独审

结论：**PASS，限于报告实际声称的必要约束、完整变形恒等式、条件恢复和有限证据。无剩余必须修复项。** 共同 cut 的累计 loss、合格共同删除的全 union gain、净 halo bank 及一般根阶界仍未证明；本 PASS 不覆盖这些一般目标。

## 冻结字节与实际审查

- `/tmp/ccu_r589_REPORT.tex`：SHA256 `26a6649312d28766b5ad491ee9dc327cad9a34fcee585dfbd5e10566cc4c1b00`。
- `/tmp/ccu_r589_cut_probe.py`：SHA256 `93c597cb945c52351a0d58cdffed39c0c5ff3c74ca8df5a3033cfc09e7125bc5`。
- `/tmp/ccu_r589_cut_results.json`：SHA256 `cc4c86f7a187f4851f8aa6af782088b595864adcd29ddf522987b13c492b9cff`。
- `/tmp/ccu_r589_REPLAY.json`：SHA256 `0d83c496990167894919899963d52e6ff9da2ff50ca86302d99e9daa3b9c3d03`。
- 完整结果去除 execution 后 canonical 数学字段 digest：`31fafcb0b0fb88fb21302a193cc125cdfbc5bf7d53244e624a1e71c41e4af26a`。

本轮先独立审合同与近极值变分，再审指定作者的共同 cut、全尺度固定 d 紧性及共同删除构造，随后全文审整合稿与最终修订；另静态读完整 probe 和读取结果/重放证书。实际工具只做小型 SymPy/Boolean/Fraction/JSON 检查及哈希核对，没有运行 probe main、重做 rectangle arrangement、LP/OT、新几何扫描、git、PDF 或子代理。主代理实际同代码重放的证据另列，不冒称为本审再次执行。

审查指出的三个整合修正已落实：原半核采用 subseteq（含继承 full-core列）；式(11)补回 epsilon 的LaTeX反斜杠；其量词明确只含有序 prefix--suffix或同pivot情形，不适用于反序。共同删除的delta_0=1端点也已在报告中单列，避免除零。

## 1. 完整对象、近极值与 interaction

原完整带、原标签（含重合标签）、H2/top/base、原合格半核及全价保持原资格。自然接收量没有迁移为任意集中对偶；原H_all没有被arm子集或trimmed价替代。费用仍为 `c_fee=2sqrt(n)+5`，其中3W替代旧top1.5W，不双计。

近极值以完整 B_n 的有限 deficit `Delta=B_n W-lambda|E|` 定义，不假定达到或可微。整标签删除、作为新标签的增源、同位置有限细分及共同Bernoulli保留的完整有限差分均合法；原硬band资格不允许直接把改变已有mi当作保留旧 witnesses。转到旧Rprime时保留完整c_feeW，且不能把Delta免费按来源数复制。报告没有将非零deficit除以h后擅取驻点。

对任一同输入、同阈值、同质量窗的源二分，完整 pure/cross三族给精确

`|E|-|E_L|-|E_U|=|E_X\(E_L union E_U)|-|E_L intersect E_U|`。

这是有限并集分解，无无限测度差。近极值的子输入deficits非负，进一步给出真正额外约束

`lambda Interaction=Delta_L+Delta_U-Delta>=-Delta`。

该下界使用全局supremum，并非单纯改名恒等式；但它不是对正interaction、cross fresh或重叠的单独预算。递归对树节点只求和则望远镜为root volume减leaf volumes；子输入并不继承root近极值，不能据此支付累积cut loss。报告的范围正确。

## 2. diffuse/pivot与完整共同 cut

`epsilon=min(1/4,n^(-1/2))` 的原标签盒并只付W/epsilon一次；所有保留实际父均满足mi<epsilon M。其额外归一化defect为 `1/epsilon=max(4,sqrt(n))`，未把它按来源、坐标或band重复收费，也未据此删掉完整H2费用。原H_all保留。

共同坐标全序的prefix/suffix质量、单pivot交集、两臂长度和d_j都正确。反序pivots无源不交保证；同序但不同parent质量只在较大radius内给式(11)，不能直接认成lambda-level。严格majority若要得到更大来源质量，必须损失中央量化间隙的真实几何臂体积；小原子不控制该空间间隙。报告未免费同时使用旧放大量和新majority增长。

共同物理cut作用于完整未trim band。质量、lambda及所有subset band membership不变，但原H2/残余资格不随变形冻结。before-order-crossing区间内，每个cross子集有固定transverse section和j区间 `[a_S-h,b_S]`。报告已使用全部子集的birth-aware形式：

- a_S<=b_S：保留原非空closed interval，包括零宽，再作[-h,0]膨胀；
- a_S>b_S：h_S=a_S-b_S，h<h_S为空，h>=h_S为 `{b_S}+[-(h-h_S),0]`；
- transverse负宽始终空，零宽始终全维零测。

因此取全部S的并才是X_h；不能在穿过negative-width出生后只膨胀旧正体积X0。该修正式在整个before-order-crossing区间有效，无需每个出生事件重新免费声称near-maximal。零宽非空closed盒的保留是必要的：它的原体积零，却可沿j方向变成正体积。

分解 `E_h=P union U_h union X_h` 与X0subsetXh给两个互不相交gain及pure-upper实际loss，式(15)符号与费用正确。near-max只提供 `lambda(gain_X+gain_U)<=lambda loss+Delta`；粗界loss<=B_n W_upper只支付一次完整纯侧，不可按多个cuts复用来源。若改为分段重启，必须更新实际deficit，不能每段免费用原Delta。H2/top及旧半核cap仅对其原输入资格使用，报告没有把变形后的全部新parents免费纳入旧cap。

## 3. 共同删除及未资格化松弛

原半质量删除的完整product cap同时包含各轴所有极值释放，式(17)合法；median两核导出的逐坐标界只在接近beta顶层时有O(n^(-1/2))强度。低beta层未被忽略，也没有被强行赋一个维数一致体积比。

共同Bernoulli删除用同一组标签变量，原actual D_N partition上的Fubini不产生parent-count union bound。variance界和Chebyshev由独立辅助变量直接推出；未使用作者旁注的未引证exponential concentration。合格保留质量在[alpha L,U]，阈值alpha lambda与两条mass bands给式(19)的2q/alpha系数。delta_0=1无信息；delta_0<1时，即使免掉双band损失，q/[alpha(1-delta_0)]仍严格大于一。这只说明当前推导不能吸收，不否定真实halo界或其他相关删除律。

式(20)是完整共同event的union概率，含半质量资格和全部域外几何，不能换成逐父概率之和。bounded B上的monomial V_N(D)是未资格化截断松弛；完全删除N也计入|B|，并非空core的原全空间载体价格。报告明确它不等于合格的(20)。特定宏观tail需删除全部标签，概率上界只诊断该明确随机律；替代父可能覆盖同一点，不能由一个tail的稀少推断整个共同union小。净bank、collision/underfill支付没有因此闭合。

## 4. 固定 d 极值与二阶几何

固定d的full-scale紧性论证合法：以当前component已知总质量确定source图，分裂时实际level并不交，保留最佳分量不减比值；规范化后connected路径使位置有界。非负质量simplex上有限CS并的体积连续，零标签不扩大正标签子集，故至多d个标签的全尺度supremum可达到。它不证明原band B_n达到，也没有d一致紧性或数量界；新增来源可超出固定d资格。报告没有从此声称一般恢复已完成。

式(23)的单个正宽carrier曲率公式正确：以t_j=r/(r-d_j)>=1，`t_j'=-t_j(t_j-1)/(nM)`即可得到所列bracket及其非负性。它不是完整并集曲率。

两源例的几何区间也已独立核验，而非仅接受给定公式：m∈(9/25,16/25)时a,b∈(3/5,1)，两个singleton方盒因a+b<=sqrt2<8/5不交；pair carrier固定为[3/10,1/2]×[-1/2,1/2]。分别相交的x宽为a/2-3/10、b/2-3/10，y高为a、b，故恰有报告的I1、I2，且无triple intersection。此开区间内组合pattern不变，得

`V=7/10+(3/10)(sqrt(m)+sqrt(1-m)), V''(1/2)=-3sqrt(2)/10`。

这是普通平滑overlap的负二阶项，非只发生于contact/birth的奇异效应。各单盒沿该总质量固定路径二阶均零仍不排除此项。报告没有将该例宣称为极值、目标反例或新一般下界；未整合的全部二阶技术草稿不在本审范围。

## 5. probe、实际重放与有限范围

脚本逐个重新生成四个单位源方形(+-3/4, +-3/4)、band[1,4]的15个实际子集，对五个固定h计算真实矩形并与gain/loss。根式域只有正平方自由基，4的根显式化为2，Fraction系数、gcd乘法及Arb512严格定号方向正确；未分离0即失败，无浮点后备。所有实际/比较box端点纳入arrangement，位图执行真实Boolean并差，不以代表点抽样或parent加和替代union。

本模型初始没有零宽box，五个运行h也均不等于h_star；程序只对h_star宽度作精确代数消去。故它直接验证negative-width出生的有限影响，closed零宽处理的一般正确性由上面的几何证明承担，不冒称执行了critical-point的完整arrangement。

h_star=3/2-sqrt2，出生mask5、10；五个h的arrangement格数为25、45、99、99、90。后3例漏掉的完整union面积分别为 `5/8-3sqrt2/8`、`3/4-sqrt2/4`、`3-2sqrt2`，与报告小数相符。本审另对结果的精确根式系数重算，5个signed residual均为零；8个interaction Boolean情形、24个符合X0subsetXh的signed-union Boolean情形亦实际逐项通过。这些是恒等式检查，不是输入扫描。

新增SymPy段仅核给定overlap表达的代数和曲率，代码明确其几何开区间由独立证明负责。该区间和公式已如第4节独立完成核验。optional deletion-monomial计算未执行，报告未称已计算。

主代理已实际重放新版代码。本审读取两个完整结果、去除execution后实际比较为相同，并独立计算上述canonical digest与REPLAY相同；不把读取证书说成自己重跑main。最新版root主体计算约0.0548秒、macOS历史RSS峰值75,530,240 bytes与报告一致；imports在计时外，最终JSON序列化/写盘在记录运行时间之后，未声称可移植资源保证。旧版0.0084秒不再用于新版。

本有限模型不是Rprime、不是保留diffuse/low-beta parent认证，不继承本例全部halfcore cap，不外推连续全部h或维数阶。没有MATLAB、优化器、LP/OT或大范围新几何运行。

## 6. 最终条件回代与未证状态

只需在一列完整B_n近极值输入上、对deficit→0有输入统一的 `g_n J_0-lambda|H|<=D_0,n W`。保留全费用后准确给

`B_n<=c_fee+1/epsilon+4B_n/g_n+D_0,n/g_n`。

g_n>=8时差值至少1/2，得 `B_n<=2c_fee+2/epsilon+2D_0,n/g_n`。把这个完整band上界也保守用作Jprime上界，报告最后的

`16e+(4/3)N_n(3c_fee+2/epsilon+2D_0,n/g_n)`

正确，安全多付已知exception费用。没有在反馈前省N_n、漏双band阈值4、漏diffuse费，或只凭每实例正差值吸收；较小维数仍仅用独立3^n有限性。所有这些结论均以未证bank为前提。

当前的真正缺口仍是共同source/cut选择使完整新coverage相对真实loss、cross-scale collision和underfill产生可统一支付的净收益。恒等式、删除cap、近极值interaction、有限出生/曲率检验都没有提供该全族估计。冻结稿准确保留这一点，故在上述实际范围通过最终审核。
