#!/usr/bin/env python3
"""Frozen four-label common-cut union, retaining all negative-width births."""
import argparse, hashlib, json, math, platform, resource, shlex, sys, time
from fractions import Fraction as F
from functools import lru_cache,cmp_to_key
from pathlib import Path
import flint
import sympy as sp
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r589_cut_results.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512
 Z=();ONE=((1,F(1)),)
 def pack(d):return tuple(sorted((r,c) for r,c in d.items() if c))
 def rat(q):q=F(q);return ((1,q),) if q else Z
 def add(a,b):
  d=dict(a)
  for r,c in b:d[r]=d.get(r,F(0))+c
  return pack(d)
 def scale(a,q):return tuple((r,c*q) for r,c in a if c*q)
 def sub(a,b):return add(a,scale(b,-1))
 def mul(a,b):
  d={}
  for r,c in a:
   for s,e in b:
    g=math.gcd(r,s);rr=r*s//g**2;d[rr]=d.get(rr,F(0))+c*e*g
  return pack(d)
 @lru_cache(None)
 def av(a):return sum((arb(c.numerator)/c.denominator*arb(r).sqrt() for r,c in a),arb(0))
 def sign(a):
  if not a:return 0
  x=av(a)
  if x>0:return 1
  if x<0:return -1
  raise ArithmeticError('Unresolved Arb512 sign')
 def cmp(a,b):return sign(sub(a,b))
 def out(a):return {'exact_squarefree_radical_terms':[[r,str(c)] for r,c in a],'Arb512':av(a).str(65)}
 def root(m):return rat(2) if m==4 else ((m,F(1)),)
 initial=[(F(-3,4),F(-3,4)),(F(-3,4),F(3,4)),(F(3,4),F(-3,4)),(F(3,4),F(3,4))]
 def family(h):
  z=[(x-h if i in (2,3) else x,y) for i,(x,y) in enumerate(initial)]
  records={};groups={'lower':[],'upper':[],'cross':[]}
  for S in range(1,16):
   ids=[i for i in range(4) if S>>i&1];m=len(ids);half=scale(root(m),F(1,2));B=tuple((sub(rat(max(z[i][j] for i in ids)),half),add(rat(min(z[i][j] for i in ids)),half)) for j in range(2))
   widths=[sub(b,a) for a,b in B];positive=all(sign(w)>0 for w in widths)
   typ='lower' if not(S&12) else 'upper' if not(S&3) else 'cross'
   records[S]={'m':m,'widths':widths,'box':B if positive else None,'type':typ}
   if positive:groups[typ].append(B)
  return records,groups
 rec0,g0=family(F(0));E0=g0['lower']+g0['upper']+g0['cross'];birth=sub(rat(F(3,2)),root(2));assert sign(sub(birth,rat(F(1,16))))>0 and sign(sub(rat(F(1,8)),birth))>0
 assert add(sub(root(2),rat(F(3,2))),birth)==Z
 results=[]
 for h in map(F,('0','1/16','1/8','1/4','1/2')):
  rec,g=family(h);Eh=g['lower']+g['upper']+g['cross'];naive=[((sub(B[0][0],rat(h)),B[0][1]),B[1]) for B in g0['cross']]
  boxes={'E0':E0,'E_h':Eh,'L_h':g['lower'],'U_h':g['upper'],'X_h':g['cross'],'U0':g0['upper'],'naive_X':naive,'E_naive':g['lower']+g['upper']+naive}
  ends=[sorted(set(v for fam in boxes.values() for B in fam for v in B[j]),key=cmp_to_key(cmp)) for j in range(2)];idx=[{v:k for k,v in enumerate(ax)} for ax in ends];nx,ny=[len(ax)-1 for ax in ends]
  def paint(fam):
   rows=[0]*nx
   for B in fam:
    x0,x1=[idx[0][v] for v in B[0]];y0,y1=[idx[1][v] for v in B[1]];bits=((1<<(y1-y0))-1)<<y0
    for x in range(x0,x1):rows[x]|=bits
   return rows
  masks={name:paint(fam) for name,fam in boxes.items()}
  totalY=(1<<ny)-1
  masks['G_cross']=[x&~e&totalY for x,e in zip(masks['X_h'],masks['E0'])]
  masks['G_upper']=[u&~(e|x)&totalY for u,e,x in zip(masks['U_h'],masks['E0'],masks['X_h'])]
  masks['Loss']=[u&~e&totalY for u,e in zip(masks['U0'],masks['E_h'])]
  masks['actual_X_minus_naive']=[x&~a&totalY for x,a in zip(masks['X_h'],masks['naive_X'])]
  masks['naive_minus_actual_X']=[a&~x&totalY for x,a in zip(masks['X_h'],masks['naive_X'])]
  masks['visible_birth_full_union']=[e&~a&totalY for e,a in zip(masks['E_h'],masks['E_naive'])]
  masks['birth_hidden_by_E0']=[x&e&totalY for x,e in zip(masks['actual_X_minus_naive'],masks['E0'])]
  masks['birth_fresh_against_E0']=[x&~e&totalY for x,e in zip(masks['actual_X_minus_naive'],masks['E0'])]
  areas={k:Z for k in masks}
  for x in range(nx):
   dx=sub(ends[0][x+1],ends[0][x]);assert sign(dx)>0
   for y in range(ny):
    dy=sub(ends[1][y+1],ends[1][y]);assert sign(dy)>0;area=mul(dx,dy);bit=1<<y
    for name,rows in masks.items():
     if rows[x]&bit:areas[name]=add(areas[name],area)
  lhs=sub(areas['E_h'],areas['E0']);rhs=sub(add(areas['G_cross'],areas['G_upper']),areas['Loss']);assert sub(lhs,rhs)==Z
  assert areas['naive_minus_actual_X']==Z
  assert areas['actual_X_minus_naive']==add(areas['birth_hidden_by_E0'],areas['birth_fresh_against_E0'])
  born=[S for S in rec if rec0[S]['box'] is None and rec[S]['box'] is not None]
  assert born==([5,10] if h>=F(1,8) else [])
  if born:assert sign(areas['visible_birth_full_union'])>0
  else:assert areas['visible_birth_full_union']==Z
  results.append({'h':str(h),'all_15_actual_subsets':[{'mask':S,'mass':rec[S]['m'],'cut_class':rec[S]['type'],'signed_widths':list(map(out,rec[S]['widths'])),'positive_box':rec[S]['box'] is not None,'box_bounds':[[out(a),out(b)] for a,b in rec[S]['box']] if rec[S]['box'] else None} for S in range(1,16)],'born_masks':born,'volumes':{name:out(v) for name,v in areas.items()},'signed_volume_change':out(lhs),'signed_identity_residual_exact':[],'axis_endpoint_counts':list(map(len,ends)),'arrangement_cells':nx*ny})
 # Independent symbolic nested-overlap ledger. Geometry/domain supplied externally.
 m=sp.symbols('m',positive=True)
 I1=m/2-sp.Rational(3,10)*sp.sqrt(m)
 I2=(1-m)/2-sp.Rational(3,10)*sp.sqrt(1-m)
 single_volumes=[m,1-m,sp.Rational(1,5)]
 Vgiven=sp.Rational(7,10)+sp.Rational(3,10)*(sp.sqrt(m)+sp.sqrt(1-m))
 Vderived=sum(single_volumes)-I1-I2
 assert sp.simplify(Vderived-Vgiven)==0
 Vsecond=sp.simplify(sp.diff(Vderived,m,2).subs(m,sp.Rational(1,2)))
 intersection_seconds=[sp.simplify(sp.diff(I,m,2).subs(m,sp.Rational(1,2))) for I in (I1,I2)]
 assert sp.simplify(Vsecond+3*sp.sqrt(2)/10)==0
 assert all(sp.diff(v,m,2)==0 for v in single_volumes)
 assert sp.simplify(sp.diff(Vderived,m,2)+sp.diff(I1+I2,m,2))==0
 assert sp.simplify(Vsecond+sum(intersection_seconds))==0
 smooth_check={'evidence':'SymPy symbolic identities only; actual box intersections and validity on m in (9/25,16/25) are inherited from the separately audited geometric argument, not verified by this script.',
 'model':{'n':2,'source_positions':[['0','0'],['4/5','0']],'masses':['m','1-m'],'parameter_interval':['9/25','16/25']},
 'given_intersection_areas':[str(I1),str(I2)],'single_box_areas':list(map(str,single_volumes)),
 'derived_union':str(sp.simplify(Vderived)),'given_union':str(Vgiven),'union_formula_residual':'0',
 'single_box_second_derivatives':['0','0','0'],'union_second_at_half':str(Vsecond),
 'intersection_second_derivatives_at_half':list(map(str,intersection_seconds)),
 'union_second_plus_intersection_seconds_identity_residual':'0','curvature_cancel_at_half_residual':'0',
 'interpretation':'Nonzero smooth union curvature is entirely accounted for by overlap curvature; zero individual-box curvature does not remove this term. No scan or new geometry reconstruction.'}
 data={'scope':'Five frozen deformations of the complete untrimmed band union E, no H2/top/base deletion and no Rprime or inherited-halfcore claim.',
 'input':{'n':2,'lambda':1,'L':1,'U':4,'sources_rational':[[str(x),str(y)] for x,y in initial],'masses_exact':['1']*4,'cut_coordinate':0,'cut_location':'0','moved_labels':[2,3],'all_15_original_subset_band_qualifications_fixed':True},
 'definitions':{'L_h':'all actual nonempty subset boxes using only labels 0,1','U_h':'all actual nonempty subset boxes using only labels 2,3, translated with sources','X_h':'all actual mixed-subset boxes, including previously negative-width births','E_h':'L_h union U_h union X_h','Gcross':'X_h minus E0','Gupper':'U_h minus (E0 union X_h)','Loss':'U0 minus E_h','naive_X':'X0 Minkowski plus [-h,0] e1','visible_birth_full_union':'E_h minus (L_h union U_h union naive_X)'},
 'critical_birth':{'h_star':out(birth),'born_subsets':[5,10],'birth_coordinate_width':'sqrt(2)-3/2+h','h_star_strictly_between_1_over16_and_1_over8':True,'zero_width_at_h_star':'exact cancellation, area zero'},
 'cases':results,'smooth_nested_overlap_symbolic_check':smooth_check,'optional_deletion_monomial_check':'Not executed: optional V(A) was not defined in the task or the read author formulas; no substitute definition invented.',
 'arithmetic':'Exact Fraction coefficients in canonical squarefree radical basis; Arb512 certifies all nonzero signs; exact zeros by coefficient cancellation; all true rectangle endpoints included, no sampling or floating signs.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'sympy':sp.__version__,'precision_bits':ctx.prec,'processes':1,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]]),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'all_assertions_passed':True}
 args.output.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'cases':[{'h':c['h'],'births':c['born_masks'],'V':c['volumes']['E_h']['Arb512'],'Gcross':c['volumes']['G_cross']['Arb512'],'Gupper':c['volumes']['G_upper']['Arb512'],'Loss':c['volumes']['Loss']['Arb512'],'birth_visible':c['volumes']['visible_birth_full_union']['Arb512']} for c in results],'all_assertions_passed':True,'execution':data['execution']}))
if __name__=='__main__':main()
