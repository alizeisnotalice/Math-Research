"""R715 disjoint A/B actual greedy histories and terminal hazard certificate.

Arb256/384 local certificate; remote Decimal110 check via stdin. Only
two_centers.json is written. Astronomical source counts remain symbolic.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def calculate(b,K,bits):
    ctx.prec=bits;A=arb
    n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();L=b*l2;t=A(root)/l2
    g=(-A(2)/a).log1p();logh=(A(1)/a).log1p();h=logh.exp()
    beta=(-n*A(a).log()).exp();alpha=-(-beta/t).expm1()
    # Exact raw clock fraction: midpoint first digit in final a/8 positions,
    # and at least one boundary digit in the entire n-coordinate word.
    Q=((n-1)*g).exp()
    W=-((n-1)*g).expm1()/8+Q/a
    conditional_boundary=8*W
    JA=floor_unique(A(root)/W);eA=root-JA*W
    JB=floor_unique(A(K*root)/W);eB=K*root-JB*W
    assert 0<eA<W and 0<eB<W
    logBmin=logh;logRB=logBmin-JB*g
    logAmin=logRB+l2/n+logh;logRA=logAmin-JA*g
    RA=logRA.exp();RB=logRB.exp();Amin=logAmin.exp();Bmin=h
    assert RA<2 and RB<2 and Amin>Bmin>1
    # A residual stays>=1/2; B initially has residual1. This strict margin
    # orders every A source ahead of every B source, even in worst case.
    order_margin=n*(logAmin-logRB)-l2
    assert order_margin>0
    assert (order_margin-n*logh).contains(0)
    logP=n*g-W/t
    def fD(J,e):
        return (-(-W/t).expm1())*(-(J*logP).expm1())/(-logP.expm1())+(J*logP).exp()*(-(-e/t).expm1())
    def fV(J,e):
        return W*(-(n*J*g).expm1())/(-(n*g).expm1())+e*(n*J*g).exp()
    # Scale both stacks by RA^n; B has an independent capacity starting at1.
    Bscale=(n*(logRB-logRA)).exp()
    receiver_clock=(-(2*n+1)*l2).exp() # Nr*beta=1/(2*4^n)
    receiver=( -K*l2-n*logRA).exp()*(-(-receiver_clock/t).expm1())
    Dscaled=fD(JA,eA)+Bscale*fD(JB,eB)+receiver
    Vscaled=fV(JA,eA)+Bscale*fV(JB,eB)+(receiver_clock.log()-n*logRA).exp()
    logD=n*l2+n*logRA+Dscaled.log();logV=n*l2+n*logRA+Vscaled.log()
    logVT=-(n+1)*l2;logratio=logD-logVT
    # Original median pool is A only. First coordinate excluded from the high
    # count: remaining sign groups have sizes n/2-1 and n/2 respectively.
    q0=3*b//16+1
    nf=max(0,floor_unique(A(a)/2*(A('.25')/RA-A('.05'))-1))
    p=A(nf)/a;count=n//2-1
    mass=(count*(-p).log1p()).exp();tail=mass
    for j in range(1,q0):
        mass*=A(count+1-j)/j*p/(1-p);tail+=mass
    # The first-axis a/8 restriction is independent of the other coordinates;
    # conditional boundary failure is <=2*tail/(8W).
    fail=2*tail/conditional_boundary
    fullA=-(-JA*W/t).expm1()
    high_lower=fullA-fullA*(W/t).exp()*fail
    assert high_lower>A('.49') and high_lower<A('.5')
    assert A('.05')>A(6)/n and 2*q0*l2>A('.375')*L
    near_upper=2*(1+A(1)/a)*n/L
    assert RA<near_upper and RB<near_upper
    # Continuous open test cells: all A sources hit C_A, no B source does;
    # all B sources hit C_B, no A source does. Every receiver hits both cells.
    eta=Bmin/(4*a)
    gapA=A('.5')-A('.25')*RA
    gapB=A('.5')-A('.25')*RB
    expanded_gapA=A('.5')-(A('.25')+A(4)/n)*RA
    expanded_gapB=A('.5')-(A('.25')+A(4)/n)*RB
    assert gapA>0 and gapB>0 and expanded_gapA>0 and expanded_gapB>0
    assert eta<Bmin/a and eta<Amin/a and eta<A('.125')
    assert -A('.5')+eta<0 and A('.5')-eta>0
    # Actual pre-residual at B is independent of A, and equals the greedy
    # selected capacity for every B update and every receiving update.
    one_hit_hazard=-(-alpha).log1p()
    assert one_hit_hazard>0 and (one_hit_hazard-beta/t).contains(0)
    assert (one_hit_hazard/(beta/t)-1).contains(0)
    before_last_clock=receiver_clock-beta
    assert before_last_clock>0
    terminal_first=K*l2
    terminal_last=K*l2+before_last_clock/t
    terminal_after_all=K*l2+receiver_clock/t
    field_first=K*A(root)*(one_hit_hazard/beta)
    field_last=field_first+before_last_clock*(one_hit_hazard/beta)
    field_after_all=field_first+receiver_clock*(one_hit_hazard/beta)
    assert (terminal_first-field_first).contains(0)
    assert (terminal_last-field_last).contains(0)
    assert (terminal_after_all-field_after_all).contains(0)
    # B source volumes exceed receiver volume, and later hit receivers have
    # identical volume. Hence no actual hit is lost to d_i>=d_j/2 in any band.
    assert n*logBmin>0 and A(1)>=A('.5')
    assert beta/t<l2
    norm_upper=(-logratio-A(4*root).log())/A(10).log()
    norm_lower=((high_lower-A('.25')).log()-A(root).log()-logratio)/A(10).log()
    stages=[]
    for j in range(1,K+1):
        cutoff=floor_unique(A(j*root)/W)
        assert cutoff<=JB
        stages.append({'j':j,'B_update_count_exact':f'{j}*N',
                       'B_remaining_exact':f'2^-{j}','actual_B_hazard_exact':f'{j}*log(2)',
                       'first_cross_point':'B','first_cross_cell_contains_B':True,
                       'ancestor_floor_d_i_over_d_j_min_lower':'1',
                       'actual_hits_deleted_for_floor':0,
                       'first_Kminus1_bands_floor_loss':0 if j<K else None})
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,'a':str(a),'N_symbolic':'sqrt(n)*a^n',
            'A_source_count':'N','B_source_count':f'{K}*N','JA':str(JA),'JB':str(JB),
            'raw_shell_fraction_W':st(W),'conditional_boundary_probability_8W':st(conditional_boundary),
            'A_min_radius':st(Amin),'A_max_radius':st(RA),'B_min_radius':st(Bmin),'B_max_radius':st(RB),
            'all_A_before_B_worst_log_price_margin_lower':st(order_margin),
            'first_receiver_entry_residual_exact':f'2^-{K}',
            'first_receiver_original_half_cross_point':'A',
            'first_receiver_terminal_point':'B','last_receiver_terminal_point':'B',
            'B_minus_A_load_difference_after_A_B_stacks_and_all_receivers_exact':f'1/2-2^-{K}',
            'receiver_count_exact':f'(a/8)*(a/4)^{n-1}','VT_exact':f'2^-{n+1}',
            'V':st(logV.exp()),'VT':st(logVT.exp()),'D':st(logD.exp()),
            'original_A_median_high_weight_lower_every_owner_point':st(high_lower),
            'original_A_median_high_weight_upper':'1/2','original_high_q0':q0,
            'log10_original_normalized_excess_lower':st(norm_lower),'log10_VT_over_4sqrt_n_D':st(norm_upper),
            'log_D_over_VT':st(logratio),
            'continuous_test_cell_radius':st(eta),
            'A_cell_center':'(1/2,0,...)','B_cell_center':'(-1/2,0,...)',
            'A_parent_first_axis_lower_min':st(gapA),'B_parent_first_axis_upper_max':st(-gapB),
            'A_expanded_parent_first_axis_lower_min':st(expanded_gapA),'B_expanded_parent_first_axis_upper_max':st(-expanded_gapB),
            'A_B_original_and_expanded_intersections_disjoint':True,
            'continuous_capture_incidence':{'C_A':{'A_sources':True,'B_sources':False,'receivers':True},
                                            'C_B':{'A_sources':False,'B_sources':True,'receivers':True}},
            'per_hit_actual_hazard_over_beta_over_t':st(one_hit_hazard/(beta/t)),
            'A_contribution_to_B_actual_hazard_exact':'0 (misses B)',
            'B_first_receiver_log_inverse_residual':st(terminal_first),
            'B_last_receiver_log_inverse_residual':st(terminal_last),
            'B_after_all_receivers_log_inverse_residual':st(terminal_after_all),
            'B_last_receiver_hazard_field_sum':st(field_last),
            'B_after_all_receivers_hazard_field_sum':st(field_after_all),
            'last_receiver_positive_hazard_excess_over_Klog2_log10':st((before_last_clock/t).log()/A(10).log()),
            'after_all_receivers_positive_hazard_excess_over_Klog2_log10':st((receiver_clock/t).log()/A(10).log()),
            'all_B_sources_min_volume_ratio_log':st(n*logBmin),
            'receiver_hits_volume_ratio_exact':'1','all_actual_hits_meet_original_ancestor_floor':True,
            'B_stage_rows':stages,
            '_values':(logRA,logRB,high_lower,logratio,terminal_last),
            '_remote_values':[float(logRA),float(logRB),float(high_lower),float(logratio),float(terminal_last)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext,MAX_EMAX,MIN_EMIN
import json,socket,sys
with localcontext() as c:
 c.prec=110;c.Emax=MAX_EMAX;c.Emin=MIN_EMIN
 rows=[]
 for b in [32,48,64]:
  for K in [4,8,16]:
   n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();t=D(root)/l2
   g=(1-D(2)/a).ln();lh=(1+D(1)/a).ln();Q=(D(n-1)*g).exp()
   W=(1-Q)/8+Q/a;JA=int(D(root)/W);JB=int(D(K*root)/W)
   eA=D(root)-JA*W;eB=D(K*root)-JB*W
   lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(JA)*g
   assert lRA<l2 and lRB<l2
   lp=D(n)*g-W/t
   def f(J,e):
    PJ=(D(J)*lp).exp() if D(J)*lp>-1000 else D(0)
    return (1-(-W/t).exp())*(1-PJ)/(1-lp.exp())+PJ*(1-(-e/t).exp())
   logDscaled=(f(JA,eA)+(D(n)*(lRB-lRA)).exp()*f(JB,eB)).ln()
   logratio=D(n)*lRA+logDscaled+D(2*n+1)*l2
   high=1-(-D(JA)*W/t).exp()
   rows.append({'b':b,'K':K,'JA':str(JA),'JB':str(JB),'values':[str(lRA),str(lRB),str(high),str(logratio),str(D(K)*l2)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 approximate independent crosscheck; receiver clock and conditional failure omitted','rows':rows}))
'''


def main():
    rows=[]
    for b in [32,48,64]:
        for K in [4,8,16]:
            low=calculate(b,K,256);high=calculate(b,K,384)
            assert low['JA']==high['JA'] and low['JB']==high['JB']
            for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
            del high['_values'];rows.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['K']==other['K'] and local['JA']==other['JA'] and local['JB']==other['JB']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'remote':remote,
            'real_history':['A=(1/2,0,...), B=(-1/2,0,...). A shells retain first relative digit in the last a/8 positions and boundary words; B shells use the reflected first digit region.',
                            'The exact full-layer raw clock is W=1/8-(1/8-1/a)*(1-2/a)^(n-1). Source owner ratio is beta0=a^-n and t=sqrt(n)/log2.',
                            'A has exactly N=sqrt(n)*a^n labels, B has K*N labels. Partial last layers are actual integer prefixes: eA/beta0 and eB/beta0 are integral by the finite grid count formula.',
                            'B bottom radius is h>1; B maximum is h*rho^(-JB). A bottom is Bmax*2^(1/n)*h; A maximum is Abottom*rho^(-JA). All maxima are strictly<2.',
                            'Every A parent lies in x1>0 and every B parent lies in x1<0, hence their capacities are independent. A minimum price while processing A exceeds B initial maximum by at least factor h^n. Therefore every A update precedes every B update.',
                            'Every receiver parent contains both A and B. Its residual is min(A remaining,B remaining). B sources have radius>1, so every B update precedes every receiver even when receiver residual is controlled by A.',
                            'No extra trigger is inserted. A update N first reaches original half load at A. B update K*N reaches B load1-2^-K, after which every receiver enters with residual<=2^-K controlled by B.',
                            'Receivers have full tiny cores tiling first-axis interval[-1/8,1/8], n/2-1 positive other axes[1/4,3/4], and n/2 negative other axes[-3/4,-1/4]. VT=2^(-n-1) and receiver raw clock=2^(-2n-1).',
                            'A and B shell cores are disjoint inside their respective translated nested shells and across the spatial half spaces. Receiver cores are between them and do not intersect source cores.'],
            'actual_hazard':['On the open B cell every A source misses, so its contribution to the actual hazard field is0. Every B source hits and has true pre-residual Rpre equal to its independent selected capacity.',
                             'For each actual B hit, theta/Rpre=1-exp(-beta0/t), so -log(1-theta/Rpre)=beta0/t exactly. Every earlier receiver also hits B and has the same per-update actual hazard.',
                             'Before the first receiver, terminal log(1/r_j)=K*log2. Before the last receiver it is K*log2+(Nr-1)*beta0/t, including all positive infinitesimal preceding receiver updates. After all receivers it is K*log2+Nr*beta0/t.',
                             'The actual near-source hazard field sums are checked against these values. Positive subprecision excesses are separately logged rather than rounded away.',
                             'All B-source radii exceed1, while all earlier receiving source radii equal1. Thus every actual terminal hit has d_i>=d_j, stronger than d_i>=d_j/2. The ancestor floor deletes no real hit, including the firstK-1 hazard bands.',
                             'After all A/B source updates the B-minus-A load difference is1/2-2^-K. All subsequent receiver updates hit both cells equally, preserving this strict gap and the terminal B location.'],
            'high_and_continuous_capture':['Original R_high is the original half-threshold pool at A, not the B terminal pool. Its true first-cross menu consists of all cells containing every A source, since their total load is exactly1/2.',
                                           'Uniform positive/negative other-axis receiver coordinates allow the same binomial high-loss lower bound with q0=floor(3b/16)+1. Boundary conditioning divides failure by8W, not W alone, because the first-axis restriction has probability1/8.',
                                           'The continuous cells Q(A,eta) and Q(B,eta) with eta=Bmin/(4a) have positive volume. Incidence is exactly: A sources hit only the A cell, B sources hit only the B cell, and all receiver parents hit both cells.',
                                           'Both original and(1+4/n)-expanded A/B parent families remain separated by a strict first-axis gap. Thus original A first-capture intersections and terminal B intersections have no common point.'],
            'scope':['Nine genuine finite histories checked with local Arb256/384 interval arithmetic and certified integer layer floors, plus independent remote Decimal110 approximate checks.',
                     'Full V,VT,D include all source stacks and all receivers. Independent A/B capacity evolution is retained; no false global common-source cell is assumed.',
                     'Exact clock identities establish threshold qualifications. Interval overlap does not imply equality or license discarding tiny positive receiver hazards.',
                     'This finite example does not refute a general weak-type bound; the original normalized excess is reported with the complete source budget.',
                     'Only two_centers.py and two_centers.json are written locally; remote calculations use stdin and leave no files or running processes.']}
    output=Path(__file__).with_name('two_centers.json');output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','K','A_max_radius','B_max_radius','original_A_median_high_weight_lower_every_owner_point','B_first_receiver_log_inverse_residual','log10_VT_over_4sqrt_n_D']} for r in rows]},indent=2))


if __name__=='__main__':main()
