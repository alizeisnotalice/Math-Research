"""Independent exact primal assignment and integer dual enumeration."""
from functools import lru_cache
from itertools import product
from random import Random
from hashlib import sha256
import json

def certificate(scores, supplies, caps):
    slots = [r for r,n in enumerate(supplies) for _ in range(n)]
    @lru_cache(None)
    def primal(a, remaining):
        if a == len(slots):
            return 0
        answers = [primal(a+1, remaining)]
        for j,left in enumerate(remaining):
            if left:
                nxt = list(remaining)
                nxt[j] -= 1
                answers.append(scores[slots[a]][j]+primal(a+1,tuple(nxt)))
        return max(answers)
    answer=primal(0,tuple(caps))
    largest=max(max(row) for row in scores)
    dual=min(sum(a*b for a,b in zip(prices,caps))+
             sum(n*max(0,max(v-l for v,l in zip(row,prices))) for row,n in zip(scores,supplies))
             for prices in product(range(largest+1),repeat=len(caps)))
    assert answer==dual
    return answer

rng=Random(717)
values=[certificate([row[:2],row[2:]],[1,2],[2,1]) for row in product(range(3),repeat=4)]
for _ in range(256):
    scores=[[rng.randrange(5) for _ in range(3)] for _ in range(4)]
    values.append(certificate(scores,[rng.randint(1,2) for _ in scores],[rng.randrange(5) for _ in range(3)]))
print(json.dumps(dict(exhaustive=81, expanded=256, digest=sha256(str(values).encode()).hexdigest())))
