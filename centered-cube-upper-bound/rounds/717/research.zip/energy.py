"""R717 all-bin witness diagonal energy and true rectangle smoothing energy.

Arb256/384 local certificate, exact rational periodic-grid models, remote
Decimal110/Fraction crosscheck. Only energy.json is generated.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx

BASE=Path(__file__).resolve().parent
history={'__name__':'r717_readonly_history'}
exec(compile((BASE/'energy_history.py').read_text(),str(BASE/'energy_history.py'),'exec'),history)


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def calculate(b,K,bits):
    raw=history['calculate'](b,K,bits);ctx.prec=bits;A=arb
    n=1<<b;a=32*n;l2=A(2).log();L=b*l2;logh=(A(1)/a).log1p();h=logh.exp()
    logVT=-(n+1)*l2
    kmin=n-1
    kmax=floor_unique(n*((4*h*n/L).log()/l2))
    count=kmax-kmin+1
    assert count>256
    # Kernel K_H=1_QH/(2H)^n, (2Hk)^n=h^n*2^(k+1).
    # Sum of witness diagonal energies divided by actual VT is exact geometric.
    witness_sum=(logVT-n*logh-kmin*l2).exp()*(-(-count*l2).expm1())
    log_witness_sum=witness_sum.log()
    assert (log_witness_sum-(-2*n*l2-n*logh+(-(-count*l2).expm1()).log())).contains(0)
    Amin=A(raw['A_min_radius']);RA=A(raw['A_max_radius'])
    actual_min=n+floor_unique(n*Amin.log()/l2)
    actual_max=n+floor_unique(n*RA.log()/l2)
    actual_count=actual_max-actual_min+1
    actual_sum=(logVT-n*logh-actual_min*l2).exp()*(-(-actual_count*l2).expm1())
    assert actual_sum<=witness_sum
    assert -n*(-A(2)/a).log1p()/l2<1 # consecutive shell-volume bins have no gaps
    # Exact separable true-density formula, all w=2H>=2h>side lengths:
    # ||K_H*1_T||_2^2 = VT^2/w^n*(1-1/(12w))*(1-1/(6w))^(n-1).
    w0=2*h;logw0=w0.log()
    def term(offset):
        logw=logw0+A(offset)*l2/n
        invw=(-logw).exp()
        logfactor=(-invw/12).log1p()+(n-1)*(-invw/6).log1p()
        return (logVT-n*logw+logfactor).exp()
    prefix=sum((term(j) for j in range(256)),A(0))
    cmax=A(1)/(6*w0)
    q=(-l2+l2*cmax/(1-cmax)).exp()
    assert q<A('.54')
    tail_upper=term(256)/(1-q)
    input_lower=prefix;input_upper=prefix+tail_upper
    # Their exact targets are ordered by the positive added tail. At256 bits
    # these two enclosures may overlap because exponent errors exceed the tail.
    assert input_lower>0 and tail_upper>0 and input_upper<witness_sum
    witness_over_input_log_lower=(witness_sum/input_upper).log()
    witness_over_input_log_upper=(witness_sum/input_lower).log()
    assert witness_over_input_log_lower>0
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,
            'kernel_normalization':'K_H=1_QH/(2H)^n; H_k=h*2^((k+1)/n)/2',
            'allowed_bin_min':str(kmin),'allowed_bin_max':str(kmax),'allowed_bin_count':str(count),
            'allowed_bin_diagonal_sum_over_VT':st(witness_sum),
            'log10_allowed_bin_diagonal_sum_over_VT':st(log_witness_sum/A(10).log()),
            'geometric_sum_formula':'4^-n*h^-n*(1-2^-allowed_bin_count)',
            'actual_A_bin_min':str(actual_min),'actual_A_bin_max':str(actual_max),'actual_A_bin_count':str(actual_count),
            'actual_A_bin_diagonal_sum_over_VT':st(actual_sum),
            'actual_A_bins_have_no_internal_gaps':True,
            'true_input_density_sum_energy_over_VT_lower':st(input_lower),
            'true_input_density_sum_energy_over_VT_upper':st(input_upper),
            'log10_true_input_density_sum_energy_over_VT_lower':st(input_lower.log()/A(10).log()),
            'log10_true_input_density_sum_energy_over_VT_upper':st(input_upper.log()/A(10).log()),
            'summed_explicit_terms':256,'successive_term_ratio_upper':st(q),
            'relative_uncomputed_tail_upper':st(tail_upper/input_lower),
            'log10_witness_energy_over_true_input_energy_lower':st(witness_over_input_log_lower/A(10).log()),
            'log10_witness_energy_over_true_input_energy_upper':st(witness_over_input_log_upper/A(10).log()),
            'VT':raw['VT'],'V':raw['V'],'D':raw['D'],
            'original_R_high_lower':st(A(raw['VT'])*A(raw['original_A_median_high_weight_lower_every_owner_point'])),
            'original_R_high_upper':st(A(raw['VT'])/2),
            'original_high_weight_lower':raw['original_A_median_high_weight_lower_every_owner_point'],
            'log10_original_normalized_excess_lower':raw['log10_original_normalized_excess_lower'],
            'log10_VT_over_4sqrt_n_D':raw['log10_VT_over_4sqrt_n_D'],
            '_values':(log_witness_sum,input_lower.log(),input_upper.log(),witness_over_input_log_lower),
            '_remote_values':[float(log_witness_sum),float(input_lower.log()),float(witness_over_input_log_lower)]}


def geometry():
    exact=[]
    for grid in [8,16,32,64,128]:
        width=grid//4
        f=[F(2) if j<grid//2 else F(0) for j in range(grid)]
        smooth=[sum((f[(j+r)%grid] for r in range(width)),F(0))/width for j in range(grid)]
        energy=sum((x*x for x in smooth),F(0))/grid
        assert sum(f)/grid==1 and energy==F(5,3)+F(16,3*grid*grid)
        exact.append({'grid':grid,'kernel_width_grid_points':width,'mass_exact':'1',
                      'input_squared_L2_exact':'2','smoothed_squared_L2_exact':str(energy),
                      'continuous_limit_exact':'5/3'})
    ctx.prec=384
    states=[]
    for b in [32,48,64]:
        n=1<<b
        for label,m in [('single_axis',1),('logarithmically_many_axes',b),('positive_fraction_of_axes',n//2)]:
            continuous_log=arb(m)*(arb(5)/3).log()
            grid_log=arb(m)*(arb(427)/256).log() # exact grid64 energy per compressed axis
            states.append({'b':b,'n':f'2^{b}','state':label,'compressed_axis_count':str(m),
                           'uncompressed_axis_count':str(n-m),'mass_exact':'1',
                           'continuous_squared_L2_energy_exact':f'(5/3)^{m}',
                           'grid64_squared_L2_energy_exact':f'(427/256)^{m}',
                           'log10_continuous_energy_amplification':st(continuous_log/arb(10).log()),
                           'log10_grid64_energy_amplification':st(grid_log/arb(10).log()),
                           'unsmoothed_squared_L2_energy_exact':f'2^{m}'})
    return {'baseline':'Uniform mass-one density on the unit torus^n, smoothed squared L2 energy1.',
            'single_axis_model':'Periodic density2 on half of each selected coordinate period and0 on its other half; normalized periodic box average of width1/4. Other axes remain uniform.',
            'continuous_exact_derivation':'The convolution has plateau height2 on length1/4 and two linear edges of width1/4; squared integral=4*(1/4)+2*(4/3)*(1/4)=5/3.',
            'exact_finite_grid_checks':exact,'states':states,
            'scope':'Pure geometry only, not an actual R715 greedy history or original first-hit menu. Tensor factorization is exact; exponential growth occurs only when compressed axis count is proportional to n.'}


REMOTE=r'''
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
import json,socket,sys
with localcontext() as c:
 c.prec=110
 rows=[]
 for b in [32,48,64]:
  n=1<<b;a=32*n;l2=D(2).ln();lh=(1+D(1)/a).ln();w0=2*(lh.exp());logvt=-D(n+1)*l2
  logw0=w0.ln()
  def logterm(j):
   lw=logw0+D(j)*l2/n;iv=(-lw).exp()
   return logvt-D(n)*lw+(1-iv/12).ln()+D(n-1)*(1-iv/6).ln()
  initial=logterm(0)
  scaled=sum((logterm(j)-initial).exp() for j in range(256))
  loginput=initial+scaled.ln();logwit=-D(2*n)*l2-D(n)*lh
  rows.append({'b':b,'values':[str(logwit),str(loginput),str(logwit-loginput)]})
 grids=[]
 for L in [8,16,32,64,128]:
  m=L//4;f=[F(2) if j<L//2 else F(0) for j in range(L)]
  g=[sum((f[(j+r)%L] for r in range(m)),F(0))/m for j in range(L)]
  E=sum((v*v for v in g),F(0))/L
  assert E==F(5,3)+F(16,3*L*L)
  grids.append([L,str(E)])
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 scaled log-energy sum and exact Fraction grid','rows':rows,'grids':grids}))
'''


def main():
    rows=[]
    for b in [32,48,64]:
        for K in [4,8,16]:
            low=calculate(b,K,256);high=calculate(b,K,384)
            assert low['allowed_bin_max']==high['allowed_bin_max'] and low['actual_A_bin_min']==high['actual_A_bin_min']
            for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
            del high['_values'];rows.append(high)
    geom=geometry()
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for other in remote['result']['rows']:
            local=next(r for r in rows if r['b']==other['b'])
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'history_sha256':hashlib.sha256((BASE/'energy_history.py').read_bytes()).hexdigest(),
            'real_history_rows':rows,'pure_geometry':geom,'remote':remote,
            'exact_all_bin_argument':['The input is exactly the R715 receiving rectangle T, all late receivers and no deep B sources. Its true density is1_T and VT=2^(-n-1). Every row uses the original A witness.',
                                      'Allowed source volumes range from d_j/2=2^(n-1) to(4hn/log n)^n inclusive. Thus kmin=n-1 and kmax=floor(n*log2(4hn/log n)). All allowed bins, including empty ones, are included.',
                                      'With H_k=h*2^((k+1)/n)/2, the witness measure VT*delta_A has exact smoothed squared L2 energyVT^2/(2H_k)^n. Dividing byVT and summing gives4^-n*h^-n*(1-2^-Nbin), with no factorNbin or n log n.',
                                      'The true rectangle convolution energy factorizes exactly with side lengths1/4,1/2,...,1/2. Its energy isVT^2/w^n*(1-1/(12w))*(1-1/(6w))^(n-1), w=2H_k.',
                                      'Only256 initial terms of the true-density sum are explicitly evaluated. A derivative bound gives each successive term ratio<=q<.54; the entire remaining finite bin interval is bounded by the infinite geometric tail. Tail error is recorded relatively.',
                                      'Young contraction gives each true input energy<=VT, but is much weaker here. Witness diagonal energy divided by true-density energy can itself be exponentially large in n, despite the small exact all-bin witness sum.'],
            'scope':['Nine actual R715 histories and their exact receiving measure are retained in real-history rows; copied energy_history.py makes the package independent of previous temporary directories.',
                     'Periodic compression tests are explicitly pure geometry, with exact finite rational matrices and analytic continuous product energies. They do not claim a new greedy input or a uniform maximal estimate.',
                     'Arb384 enclosures are crosschecked against256 bits and remote Decimal110/Fraction computations. No sampling, remote files, Git changes or running processes.']}
    output=BASE/'energy.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'real_rows':[{k:r[k] for k in ['b','K','log10_allowed_bin_diagonal_sum_over_VT','log10_witness_energy_over_true_input_energy_lower','relative_uncomputed_tail_upper']} for r in rows],
                      'geometric_states':len(geom['states'])},indent=2))


if __name__=='__main__':main()
