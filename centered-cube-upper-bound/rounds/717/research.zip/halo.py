"""R717 sparse legitimate receiver prefix distinguishes old W from new halo.

Reads same-directory energy_history.py without modifying it. Only halo.json
is generated. Local Arb256/384 and independent remote Decimal110 crosscheck.
"""
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys
from flint import arb,ctx

BASE=Path(__file__).resolve().parent
source={'__name__':'halo_readonly_history'}
exec(compile((BASE/'energy_history.py').read_text(),str(BASE/'energy_history.py'),'exec'),source)


def st(x):return x.str(38)


def calculate(b,K,bits):
    raw=source['calculate'](b,K,bits);ctx.prec=bits;A=arb
    n=1<<b;a=32*n;root=1<<(b//2);l2=A(2).log();L=b*l2;t=A(root)/l2
    g=(-A(2)/a).log1p();lh=(A(1)/a).log1p();h=lh.exp()
    W=A(raw['raw_shell_fraction_W']);JA=int(raw['JA']);JB=int(raw['JB'])
    eA=root-JA*W;eB=K*root-JB*W
    logRB=lh-JB*g;logAmin=logRB+l2/n+lh;logRA=logAmin-JA*g;RA=logRA.exp()
    # Exact prefix counts: N'=2^(bn/4), original Nr=2^((b+3)n-1).
    prefix_exponent=(b//4)*n;original_exponent=(b+3)*n-1
    assert 0<prefix_exponent<original_exponent
    logVR=-A((3*b//4+4)*n)*l2
    log_receive_clock=-A((3*b//4+5)*n)*l2
    receive_clock=log_receive_clock.exp()
    assert (logVR-(log_receive_clock+n*l2)).contains(0)
    lp=n*g-W/t
    def fD(J,e):
        return (-(-W/t).expm1())*(-(J*lp).expm1())/(-lp.expm1())+(J*lp).exp()*(-(-e/t).expm1())
    def fV(J,e):
        return W*(-(n*J*g).expm1())/(-(n*g).expm1())+e*(n*J*g).exp()
    Bscale=(n*(logRB-logRA)).exp()
    Dscaled=fD(JA,eA)+Bscale*fD(JB,eB)+(-K*l2-n*logRA).exp()*(-(-receive_clock/t).expm1())
    Vscaled=fV(JA,eA)+Bscale*fV(JB,eB)+(log_receive_clock-n*logRA).exp()
    logD=n*l2+n*logRA+Dscaled.log();logV=n*l2+n*logRA+Vscaled.log()
    logratio=logD-logVR
    high=A(raw['original_A_median_high_weight_lower_every_owner_point'])
    high_integral_lower=logVR.exp()*high
    high_integral_upper=logVR.exp()/2
    old_first=2*RA*(1+A(4)/n)
    old_other=2*RA*(A(4)/n+A(1)/a)
    logWupper=old_first.log()+(n-1)*old_other.log()
    log_old_ratio=2*L+logWupper-logVR
    assert log_old_ratio<0
    gamma=A(1)/(48*65536)
    halfwidth=(gamma*L/n).sqrt()
    loghalo=n*(2*halfwidth).log()
    log_new_ratio=loghalo-logVR
    assert log_new_ratio>0
    assert h>=1
    # Minimum allowed k=n-1 has H=h; every actual A source bin has H>=h.
    Hmin=h
    assert Hmin>=1
    assert (log_new_ratio-n*(A(32).log()+(gamma*L).log()/2+L/4)).contains(0)
    required_density=(-log_new_ratio).exp()
    assert required_density<1
    norm_upper=(-logratio-A(4*root).log())/A(10).log()
    norm_lower=((high-A('.25')).log()-A(root).log()-logratio)/A(10).log()
    return {'b':b,'n':f'2^{b}','K':K,'precision_bits':bits,
            'new_receiver_count_exact':f'2^{prefix_exponent}',
            'original_receiver_count_exact':f'2^{original_exponent}',
            'prefix_is_true_subset':True,'VR_exact':f'2^-{(3*b//4+4)*n}',
            'receiver_raw_clock_exact':f'2^-{(3*b//4+5)*n}',
            'VR':st(logVR.exp()),'V':st(logV.exp()),'D':st(logD.exp()),
            'old_W_box_first_axis_width_upper':st(old_first),
            'old_W_box_other_axis_width_upper':st(old_other),
            'old_capacity_n_squared_log10_ratio_to_VR_upper':st(log_old_ratio/A(10).log()),
            'old_capacity_n_squared_ratio_to_VR_upper':st(log_old_ratio.exp()),
            'gamma_exact':'1/(48*65536)','minimum_bin_kernel_H':st(Hmin),
            'new_common_halo_halfwidth':st(halfwidth),
            'new_common_halo_volume':st(loghalo.exp()),
            'new_halo_log10_volume_ratio_to_VR_lower':st(log_new_ratio/A(10).log()),
            'new_uniform_transport_density_upper':st(required_density),
            'new_no_compression_density_at_most_one':True,
            'original_A_high_weight_lower_every_receiver_point':st(high),
            'original_R_high_integral_lower':st(high_integral_lower),
            'original_R_high_integral_upper':st(high_integral_upper),
            'log_D_over_VR':st(logratio),
            'log10_original_normalized_excess_lower':st(norm_lower),
            'log10_VR_over_4sqrt_n_D':st(norm_upper),
            '_values':(log_old_ratio,log_new_ratio,logratio,high),
            '_remote_values':[float(log_old_ratio),float(log_new_ratio),float(logratio),float(high)]}


REMOTE=r'''
from decimal import Decimal as D,localcontext,MAX_EMAX,MIN_EMIN
import json,socket,sys
with localcontext() as c:
 c.prec=110;c.Emax=MAX_EMAX;c.Emin=MIN_EMIN
 rows=[]
 for b in [32,48,64]:
  for K in [4,8,16]:
   n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();L=D(b)*l2;t=D(root)/l2
   g=(1-D(2)/a).ln();lh=(1+D(1)/a).ln();Q=(D(n-1)*g).exp()
   W=(1-Q)/8+Q/a;JA=int(D(root)/W);JB=int(D(K*root)/W)
   eA=D(root)-JA*W;eB=D(K*root)-JB*W
   lRB=lh-D(JB)*g;lAmin=lRB+l2/n+lh;lRA=lAmin-D(JA)*g;RA=lRA.exp()
   lp=D(n)*g-W/t
   def f(J,e):
    PJ=(D(J)*lp).exp() if D(J)*lp>-1000 else D(0)
    return (1-(-W/t).exp())*(1-PJ)/(1-lp.exp())+PJ*(1-(-e/t).exp())
   scaled=f(JA,eA)+(D(n)*(lRB-lRA)).exp()*f(JB,eB)
   logD=D(n)*l2+D(n)*lRA+scaled.ln()
   logVR=-D((3*b//4+4)*n)*l2
   old=2*L+(2*RA*(1+D(4)/n)).ln()+D(n-1)*(2*RA*(D(4)/n+D(1)/a)).ln()-logVR
   gamma=D(1)/(48*65536);half=(gamma*L/n).sqrt();new=D(n)*(2*half).ln()-logVR
   high=1-(-D(JA)*W/t).exp()
   rows.append({'b':b,'K':K,'values':[str(old),str(new),str(logD-logVR),str(high)]})
 print(json.dumps({'host':socket.gethostname(),'python':sys.version,'backend':'Decimal110 independent aggregate; negligible receiver D contribution and high failure omitted','rows':rows}))
'''


def main():
    rows=[]
    for b in [32,48,64]:
        for K in [4,8,16]:
            low=calculate(b,K,256);high=calculate(b,K,384)
            for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
            del high['_values'];rows.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B -']
    run=subprocess.run(command,input=REMOTE,text=True,capture_output=True,timeout=40)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        for local,other in zip(rows,remote['result']['rows']):
            assert local['b']==other['b'] and local['K']==other['K']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in rows:del row['_remote_values']
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'source_history_sha256':hashlib.sha256((BASE/'energy_history.py').read_bytes()).hexdigest(),
            'rows':rows,'remote':remote,
            'legitimate_receivers':['Keep exactly the same real R715 A/B source stacks. Select the first N_prime=(2^(b/4))^n labels of the original fixed lexicographic receiver grid.',
                                    'The integer prefix exponent is strictly below the original receiver-count exponent. Thus this is a genuine subfamily of full disjoint tiny cores, with unchanged parents, source capacities and source coefficients.',
                                    'All retained receiver parents contain A and B and still follow all A/B sources in actual greedy order. The original first-half pool is all A sources for every retained receiver.',
                                    'Each retained owner has volume(2/a)^n. Hence VR=(n^(1/4)/(16n))^n=2^(-(3b/4+4)n) exactly. No assertion that the selected owners fill a new rectangle is used.',
                                    'Only the receiver terms in full V and D change; both are recomputed, not obtained by subtracting nearly equal gigantic budgets.'],
            'old_and_new_spatial_payment':['The first complete A shell contains both boundary extremes in every coordinate except coordinate1. Thus the FULL canonical first-pool intersection W has width<=2RA(4/n+1/a) on each of n-1 axes, and width<=2RA(1+4/n) on axis1.',
                                            'All original first-half positive threshold cells must include every A source because their total coefficient is exactly1/2. Therefore the same W upper bound covers the complete original first-cross menu, not just the witness A.',
                                            'The old polynomial spatial capacity is n^2*|W|. The certified upper ratio to actual VR is exponentially small in every case.',
                                            'Every allowed source-volume bin has H>=h>=1. Its natural new A-centered halo has halfwidth at least sqrt(gamma log(n)/n); the common minimum halo suffices for all bins.',
                                            'For each bin define the physical transport law from every actual retained receiving point to the uniform distribution on this same halo. Its destination density is exactly VR/halo_volume<=1. This verifies no-compression allocation separately in every source bin.',
                                            'The new halo is not asserted to lie in the old full donor intersection. Its distinct spatial admissibility is the point of this test; capture/energy rules belong to the new channel.'],
            'scope':['Nine cases b32,48,64 and K4,8,16: local Arb256/384 interval checks and independent remote Decimal110 aggregate checks pass.',
                     'The original high estimate is retained pointwise on all actual selected owner points, hence its integral bounds multiply by the new true VR.',
                     'These computations compare the specified old/new spatial capacities on a real finite history; they do not alone prove a uniform allocation or weak-type theorem.',
                     'Only halo.py and halo.json are created; energy_history.py is read-only. No Git changes, remote files, or remaining processes.']}
    output=BASE/'halo.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'rows':[{k:r[k] for k in ['b','K','old_capacity_n_squared_log10_ratio_to_VR_upper','new_halo_log10_volume_ratio_to_VR_lower','original_A_high_weight_lower_every_receiver_point']} for r in rows]},indent=2))


if __name__=='__main__':main()
