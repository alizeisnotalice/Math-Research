#!/usr/bin/env python3
"""R681 abstract ordered-graph diagnostics; no cube geometry is represented."""
from fractions import Fraction as F
from itertools import combinations
from math import factorial,comb,isqrt
from pathlib import Path
import hashlib,json,sys,time,platform
ROOT=Path(__file__).resolve().parent
start=time.time()
def compact(x):
    x=F(x); a,b=x.numerator,x.denominator
    scale=10**12; lo=(a*scale)//b
    return {'interval_12dp':[str(F(lo,scale)),str(F(lo+1,scale))], 'sha256_num_den':hashlib.sha256((hex(a)+'/'+hex(b)).encode()).hexdigest(),'numerator_bits':a.bit_length(),'denominator_bits':b.bit_length(),**({'exact':str(x)} if max(a.bit_length(),b.bit_length())<200 else {})}
def counts(n,k):
    if n==1: yield (k,);return
    for a in range(k+1):
        for rest in counts(n-1,k-a):yield(a,)+rest
def metrics(n,k,edges,d):
    den=n**k; em=ej=eh=event=gate=miss=0; cells=0
    for m in counts(n,k):
        w=factorial(k)
        for a in m:w//=factorial(a) # divisions here exact sequentially? multinomial denominator divides cumulative k! at each prefix
        L=max(i for i,a in enumerate(m) if a)
        M=sum(m[i]*m[j] for i,j in edges)
        J=sum(m[i]*m[j] for i,j in edges if j==L)
        H=sum(bool(m[i]) for i,j in edges if j==L)
        em+=w*M;ej+=w*J;eh+=w*H;event+=w*bool(M);gate+=w*bool(J);miss+=w*bool(M and not J);cells+=1
    assert em==k*(k-1)*len(edges)*n**(k-2)
    assert ej==k*(k-1)*sum((j+1)**(k-2) for i,j in edges)
    assert event==gate+miss
    return {'N':n,'k':k,'d':d,'T':str(F(n,d)),'edges':len(edges),'count_vectors':cells,'E_pair_marks':str(F(em,den)),'E_max_vertex_incidence':str(F(ej,den)),'E_max_vertex_distinct_incoming':str(F(eh,den)),'P_edge':str(F(event,den)),'P_max_vertex_gate':str(F(gate,den)),'P_edge_but_max_vertex_isolated':str(F(miss,den))}
# Stage 1 all ordered graphs on four labels, capacities respected.
all_edges=list(combinations(range(4),2)); small=[]
for mask in range(1<<len(all_edges)):
    edges=[e for j,e in enumerate(all_edges) if mask>>j&1]
    indeg=max([sum(j==v for i,j in edges) for v in range(4)])
    for d in range(max(1,indeg),4):
        for k in range(2,7):
            row=metrics(4,k,edges,d);row['mask']=mask;small.append(row)
# Stage 2 fixed adversarial ordered graph families.
families={
'matching4':(8,[(0,1),(2,3),(4,5),(6,7)],1),
'matching2_highisolates4':(8,[(0,1),(2,3)],1),
'cliques_2x4':(8,list(combinations(range(4),2))+list(combinations(range(4,8),2)),3),
'clique4_highisolates4':(8,list(combinations(range(4),2)),3),
'instar7':(8,[(i,7) for i in range(7)],7),
'outstar7':(8,[(0,j) for j in range(1,8)],1),
'bandwidth2_saturated_after_start':(8,[(i,j) for j in range(8) for i in range(max(0,j-2),j)],2)}
adv=[]
for name,(n,edges,d) in families.items():
    for k in range(2,9):
        row=metrics(n,k,edges,d);row['family']=name;adv.append(row)
# Squarefree inverse mapping audit. Delete earliest predecessor of rightmost occupied edge.
def selected(S,edges):
    ee=[(j,i) for i,j in edges if i in S and j in S]
    if not ee:return None
    j=max(j for j,i in ee);i=min(i for jj,i in ee if jj==j);return(i,j)
inverse=[]
for t in range(1,8):
    edges=[(2*i,2*i+1) for i in range(t)];R=set(range(1,2*t,2)); rec=[]
    for i in range(2*t):
        if i in R:continue
        pair=selected(R|{i},edges)
        if pair and pair[0]==i:rec.append(pair)
    assert len(rec)==t and len({j for i,j in rec})==t
    inverse.append({'retained_degree':t,'original_degree':t+1,'d':1,'inverse_deleted_vertices':len(rec),'distinct_retained_keepers':len({j for i,j in rec}),'inverse_weight_sum':str(F(len(rec),1))})
# Independent finite squarefree subset checks for the closed-form enlarged formulas.
for size in (2,3,4):
    blocks=3; NN=size*blocks
    for kk in range(2,min(5,blocks+1)):
        direct=sum(len({i//size for i in S})==kk for S in combinations(range(NN),kk))
        assert direct==size**kk*comb(blocks,kk)
for mm,hh,kk in ((2,3,3),(3,2,4)):
    direct=sum(not any(2*j in S and 2*j+1 in S for j in range(mm)) for S in combinations(range(2*mm+hh),kk))
    formula=sum(2**r*comb(mm,r)*comb(hh,kk-r) for r in range(max(0,kk-hh),min(mm,kk)+1))
    assert direct==formula
# Stage 3 no word enumeration. Conditional squarefree uniform k-subsets.
large=[]
for n in (256,1024,4096):
    root=isqrt(n);k=128*root;T0=6144*root
    for size in (2,4,8):
        d=size-1;blocks=(d*T0+size-1)//size;N=blocks*size
        independent=F(size**k*comb(blocks,k),comb(N,k))
        T=F(N,d)
        large.append({'n':n,'k':k,'model':'equal_cliques','clique_size':size,'blocks':blocks,'N':N,'d':d,'T':str(T),'P_edge_squarefree':compact(1-independent),'E_pair_marks_squarefree':str(F(k*(k-1)*blocks*comb(size,2),N*(N-1))),'pair_normalization':str(F(k*(k-1),1)/T),'one_vertex_normalization':str(F(k,1)/T),'two_vertex_normalization':str(F(k*(k-1),1)/(T*T))})
# One enlarged missing-gate calculation, half labels isolated and above all matching endpoints.
n=256;k=2048;m=24576;h=49152;N=2*m+h
independent_count=sum(2**r*comb(m,r)*comb(h,k-r) for r in range(k+1))
edge=1-F(independent_count,comb(N,k));all_bottom=F(comb(2*m,k),comb(N,k));bottom_edge=1-F(2**k*comb(m,k),comb(2*m,k))
miss=edge-all_bottom*bottom_edge
large.append({'n':n,'k':k,'model':'matching_with_high_isolates','matching_edges':m,'high_isolates':h,'N':N,'d':1,'T':str(N),'P_edge_squarefree':compact(edge),'P_edge_and_largest_isolated_squarefree':compact(miss),'P_edge_and_largest_isolated_given_edge':compact(miss/edge),'P_no_high_isolate':compact(all_bottom)})
# R680 coefficient, retaining exact a^-n in T*. n are squares so no irrational rounding.
contract=[]
for n in (256,1024,4096):
    root=isqrt(n);k=128*root;a=32*n;T=F(6144*root)-F(1,a**n)
    contract.append({'n':n,'k':k,'Tstar':compact(T),'squarefree_delete_r_normalization':{str(r):compact(F(factorial(k)//factorial(k-r),1)/(T**r)) for r in range(1,9)},'k_over_Tstar':compact(F(k)/T),'k_kminus1_over_Tstar':compact(F(k*(k-1))/T),'k_kminus1_over_Tstar_squared':compact(F(k*(k-1))/(T*T))})
out={'scope':'ABSTRACT RELAXATION ONLY. iid multiset stages 1/2; squarefree subset stage 3. No real cubes, strict cores, history or kernels.','arithmetic':'Python arbitrary-precision int and Fraction; interval_12dp is rigorous floor rational enclosure of width 1e-12','python':sys.version,'platform':platform.platform(),'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input':{'stage1_N':4,'stage1_all_ordered_graphs':64,'stage1_k':[2,3,4,5,6],'stage2_k':list(range(2,9)),'stage3_n':[256,1024,4096]},'stage1':{'records':len(small),'count_vectors_evaluated':sum(r['count_vectors'] for r in small),'positive_missing_gate_records':sum(F(r['P_edge_but_max_vertex_isolated'])>0 for r in small),'maximum_missing_gate':max(small,key=lambda r:F(r['P_edge_but_max_vertex_isolated']))},'stage2':adv,'inverse_rightmost_edge':inverse,'stage3':large,'actual_contract_factors':contract,'all_assertions_passed':True,'errors':[],'elapsed_seconds':time.time()-start}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('script_sha256','stage1','elapsed_seconds','all_assertions_passed')},indent=2))
print('RESULT.json sha256',hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest())
