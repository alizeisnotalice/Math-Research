from pathlib import Path
from fractions import Fraction as F
from math import comb,isqrt
import json,hashlib,re,ast
p=Path(__file__).resolve().parent
r=json.loads((p/'RESULT.json').read_text());t=json.loads((p/'TERMINAL.json').read_text())
for s,z in [('NUMERIC.py',r),('TERMINAL.py',t)]:
 ast.parse((p/s).read_text());assert hashlib.sha256((p/s).read_bytes()).hexdigest()==z['script_sha256']
assert r['all_assertions_passed'] and not r['errors']
assert r['stage1']['records']==720 and r['stage1']['count_vectors_evaluated']==29520
assert len(r['stage2'])==49
for z in r['stage2']:
 assert F(z['P_edge'])==F(z['P_max_vertex_gate'])+F(z['P_edge_but_max_vertex_isolated'])
 assert F(z['E_pair_marks'])==F(z['k']*(z['k']-1)*z['edges'],z['N']**2)
for z in r['inverse_rightmost_edge']:
 assert z['inverse_deleted_vertices']==z['distinct_retained_keepers']==z['retained_degree']
# Independent large-model recomputation, using exact integer combinatorics.
z=r['stage3'][-1];m=z['matching_edges'];h=z['high_isolates'];k=z['k'];N=z['N']
edge=1-F(sum(2**j*comb(m,j)*comb(h,k-j) for j in range(k+1)),comb(N,k))
miss=edge-F(comb(2*m,k)-2**k*comb(m,k),comb(N,k))
for key,x in [('P_edge_squarefree',edge),('P_edge_and_largest_isolated_squarefree',miss),('P_edge_and_largest_isolated_given_edge',miss/edge)]:
 lo,hi=map(F,z[key]['interval_12dp']);assert lo<=x<hi and hi-lo==F(1,10**12)
 digest=hashlib.sha256((hex(x.numerator)+'/'+hex(x.denominator)).encode()).hexdigest()
 assert digest==z[key]['sha256_num_den']
assert miss/edge>F(999999999999,10**12)
for z in t['rows']:
 n=z['n'];k=128*isqrt(n);base=6144*isqrt(n)
 assert z['lower_exponent_for_crude_envelope']==n-k*(base-1).bit_length()
assert t['rows'][4]['lower_exponent_for_crude_envelope']==3670016
# Separate finite coefficient identity recorded by proof author; not proof checking.
s=(p/'S2.md').read_text().split('```python\n')[1].split('```')[0]
exec(compile(s,'S2 reproduction','exec'),{})
stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',(p/'REPORT.tex').read_text()):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(passed=True,graph_records=720,adversarial_records=49,terminal_rows=6,scope='exact recorded arithmetic, finite coefficient identity, syntax and integrity; no general geometric bound')))
