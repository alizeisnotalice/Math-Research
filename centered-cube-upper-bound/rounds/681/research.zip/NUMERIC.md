# R681 exact ordered-graph deletion diagnostics

## Decision and scope

A constant loss from replacing all admitted-pair marks by the largest sampled vertex is **not supported by incoming capacity alone**. The largest-vertex rule has the favorable `k/T` coefficient but can miss almost the entire edge event. Selecting the rightmost edge covers the event, but its inverse map can have `k−1` different retained keepers; incoming capacity then gives the old `k(k−1)/T` scale. Deleting several vertices has favorable factorial coefficients only after a covering and reconstruction argument has been supplied. None of these graphs represents real cubes, strict cores, common intersections, causal receivers, directions, or the frozen kernels. These computations do not disprove a geometric bound.

## Model and exact identities

Labels are ordered `0,...,N−1`, each has weight `q=1/d`, and every vertex has at most `d` incoming edges. Thus the incoming weighted capacity is at most one and `T=N/d`. Sources after the initial boundary can saturate capacity (the bandwidth-d graph has incoming degree `min(d,j)`).

Stages 1/2 draw `k` independent uniform labels, with multiplicities `m`. Write `L=max supp(m)`, `M=Σ_(i→j) m_i m_j`, `J=m_L Σ_(i→L)m_i`, and `H=Σ_(i→L)1_(m_i>0)`. Enumeration weights each count vector by the exact multinomial count `k!/∏m_i!`. Repeated labels therefore remain present. Independent formulas checked against every enumeration are

- `E M = k(k−1)|E|/N²`;
- `E J = k(k−1)Σ_(i→j)(j+1)^(k−2)/N^k`;
- `P(M>0)=P(J>0)+P(M>0,J=0)`.

Stage 3 instead uses a uniform squarefree `k`-subset. This law is stated explicitly; it is not substituted for the multiset law in the original integral. Its exact identities include

- `E M=k(k−1)|E|/[N(N−1)]`;
- `E J=Σ_j indeg(j) C(j−1,k−2)/C(N,k)` when labels are zero-based;
- by the hockey-stick identity and indegree≤d, `E J≤dk/N=k/T`.

For bandwidth-d graphs, if `k>d`, every contributing largest index has saturated indegree, so the last upper bound is an equality. Thus the favorable largest-vertex coefficient is real at the graph level. Coverage, rather than its local coefficient, is the missing step.

For `b` disjoint equal cliques of size `s=d+1`, `N=bs`, the independent-set count is `s^k C(b,k)`. For a matching of `m` edges followed by `h` higher isolated vertices, it is `Σ_r 2^r C(m,r)C(h,k−r)`. Divide by `C(2m+h,k)` for the no-edge probability. In the latter model,

`P(edge and largest isolated)=P(edge)−[C(2m,k)/C(2m+h,k)] P(edge in bottom matching)`.

Both independent-set formulas were separately checked by finite subset enumeration on small inputs before their enlarged use.

## Three bounded stages actually run

1. All 64 ordered simple graphs on four labels, every feasible capacity `d=1,2,3`, and `k=2,...,6`: 720 model-degree-capacity records and 29,520 exact count vectors. All identities passed; 252 records have positive missing-largest-gate probability. The maximal observed missed probability is `795/1024` (a clique on labels 0,1,2 with label 3 isolated, k=6).
2. Seven fixed eight-label graph families for `k=2,...,8`: matching, matching plus four high isolates, two four-cliques, one four-clique plus four high isolates, incoming star, outgoing star, and a bandwidth-2 graph saturating incoming capacity after its initial boundary. All count vectors were enumerated exactly. For matching plus high isolates at k=8, `P(edge)=2888929/4194304`, while the largest-vertex gate sees only `13231/4194304`; the missed event is `1437849/2097152`. Incoming stars have no coverage gap, showing the obstruction depends on where edges sit in the order.
3. Exact combinatorics, no word enumeration, at `n=256,1024,4096`, `k=128√n`, `T=6144√n`, and clique sizes 2,4,8. The n=256 matching has `N=98304,k=2048` and edge probability in `[0.999999999651,0.999999999652]`. At n=1024 and 4096 every tested clique collision probability exceeds `0.999999999999`. For the enlarged matching with 24,576 edges and 49,152 higher isolated labels, the edge probability and missed-largest-gate probability both lie in `[0.999979073881,0.999979073882]`; the conditional probability of a missed largest-vertex gate given an edge exceeds `0.999999999999`.

The last example can be made arbitrarily close to total coverage failure by increasing the number of isolated labels at the top. At the displayed equal-weight rate, the exact computation already separates the two events decisively.

## Inverse reconstruction and factorial expenses

Fix `t` disjoint ordered matching edges `(0,1),(2,3),...,(2t−2,2t−1)`. Retain only their later endpoints. Adding any one missing earlier endpoint makes exactly one edge, which is necessarily the rightmost occupied edge. Deleting its earlier endpoint returns the same retained key. Hence there are exactly `t` possible deleted labels and `t` distinct retained keepers, all with `d=1` and incoming capacity one. This was enumerated for `t=1,...,7`. With original degree `k=t+1`, the inverse incoming budget is `k−1`, not a universal constant.

For a squarefree deletion of `r` specified labels, degree normalization contributes `(k)_r/T^r`, **before** inverse reconstruction multiplicity and deleted-label weight summation. RESULT.json records exact enclosures for r=1,...,8 under the actual `T*=6144√n−(32n)^(-n)`. Whole-label deletion in a multiset with multiplicity r instead retains its `1/r!` factor: before label summation the coefficient is `C(k,r)q_i^r/T^r`. Treating deletion of one support vertex as deletion of one occurrence would be incorrect for that case.

At n=256 the actual factors are

- `k/T*` in `[0.020833333333,0.020833333334]`;
- `k(k−1)/T*` in `[42.645833333333,42.645833333334]`;
- `k(k−1)/(T*)²` in `[0.000433815850,0.000433815851]`.

At n=1024 and 4096, the pair factor is just above `85.3125` and `170.645833333333`, respectively; the one-vertex factor remains just above `1/48`. The small simultaneous-deletion coefficient alone does not bound its inverse map, establish coverage, or control a kernel that depends on the removed labels.

## Reproducibility and status

Interpreter: `/Users/zzh/.local/share/math-research-tools/venv/bin/python` (version/platform recorded in RESULT.json). Command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r681-20261116/NUMERIC.py
```

Arithmetic is exclusively arbitrary-precision integer and `fractions.Fraction`; no random sampling or floating rounding enters any claim. Large fractions are represented by a rigorous rational enclosure of width `10^−12`, numerator/denominator bit lengths, and SHA-256 of their signed hexadecimal numerator/denominator encoding. Source hash and full input ranges are in RESULT.json. Final executed script hash: `6d6caf51516c1e84c338f4e9e218bf7a8d6f06cb7279bd8d78d04e289b6f731f`. Final result hash: `662814a96f3b4be2e58fcb480791eca01a73e7b4131aadc6466a13a7e40bdd5c`. Run completed normally in about 1.70 seconds, all assertions passed, and errors are empty. The Python process exited with code zero. No MATLAB, PDF viewer, Git command, or child agent was used.
