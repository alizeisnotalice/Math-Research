from pathlib import Path
from math import isqrt
import json, hashlib, sys
p=Path(__file__)
rows=[]
for e in (8,12,16,20,24,28):
 n=2**e; s=isqrt(n); k=128*s; base=6144*s
 ceil_log2=(base-1).bit_length()
 # T_* < base and (1+c0)^n > 2^n.
 # Crude normalized singleton envelope k*(1+c0)^n/T_*^k
 # is > k*2^(n-k*ceil_log2). This is NOT a lower bound on D_k.
 rows.append(dict(n=n,k=k,base_upper_T=base,ceil_log2_base=ceil_log2,lower_exponent_for_crude_envelope=n-k*ceil_log2))
assert rows[-2]['lower_exponent_for_crude_envelope']>0
out=dict(python=sys.version,script_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=rows,scope='Exact integer lower bound on the size of an available crude upper-bound coefficient; not a lower bound on actual receiver cost and not a counterexample.')
p.with_name('TERMINAL.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(rows))
