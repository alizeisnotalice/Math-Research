# R681: complete admission peeling is a ledger, not a paid geometry bound

General pure sqrt(n) and earlier n^(1/2+o(1)) goals remain unproved. Keep R680 original account and R679 pair cover. This round does not improve a weak-type constant.

Proved: mark only an older occurrence incident to maximum support label -> D_max,r<=D_{r-1}, full multiplicities valid, normalized r/T. This event is not a cover. Do not spend another round attempting to recover the missing factor using incoming graph capacity alone.

Complete deterministic max-support greedy peeling keeps ALL occurrences of selected labels and deletes all lower incoming neighbors. Retained v has independent full-admission support. Deleted support lies in exact incoming union N(v), rate S_v<=|supp v|. Full comparison:
D_k <= sum_{independent eligible v,1<=r=|v|<=k} [q^v/v! integral K_v] S_v^(k-r)/(k-r)!.
It keeps real receiver integral and moving first core; only nonnegative monotone relaxation occurs. Scalar D(t)<=Dind(t exp(t)) is weaker. Normalized coefficient binom(k,r)(r/T)^(k-r) restores k(k-1)/T at r=k-1; low-degree terms also unpaid. Crude singleton upper-bound coefficient is exponentially large in high n, not evidence actual D is large.

Next genuine target is joint weighted RHS with actual S_v and geometry, or direct paid global construction. Independent graph geometry alone is not sufficient evidence. Same-core local exponential capture cannot be summed across arbitrary repeated source cores. Tightening causal masks may restore padding compatibility but does not pay core repetition. Read final A1 for scope.

No more local birthday refinements, max-vertex graph reformulations, or unbounded abstract counterexample scans. NUMERIC tests only abstract ordered graphs. They do not establish hard-core cube realizability or disprove global theorem. Main and audit ran local Python exact arithmetic. No MATLAB or PDF launched.

Reproduce: /Users/zzh/.local/share/math-research-tools/venv/bin/python NUMERIC.py; same interpreter TERMINAL.py; then verify.py (regeneration changes recorded runtime, so original manifest binds delivered files). Models and rational intervals described in NUMERIC.md. One Astra and three Sol maximum; all R681 tasks stop after bounded delivery. Do not count inactive agents as running. Next research round is R682 after separate R681 verified commit/push.
