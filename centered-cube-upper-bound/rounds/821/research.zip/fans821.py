"""Two actual rays through one early cube, shared positive-L1 prefixes.

All lengths, measures and margins are exact rational numbers. Per-sample
centers have positive n-dimensional receiver neighborhoods with the same last
root; the displayed central points lie on the two specified rays.
"""

from fractions import Fraction as F
from itertools import combinations
from math import prod


def bin_exp(x):
    k = x.numerator.bit_length() - x.denominator.bit_length()
    while F(2) ** k > x:
        k -= 1
    while F(2) ** (k + 1) <= x:
        k += 1
    return k


def run(n, sides):
    d = F(1, 5)
    delta = F(1, 10000 * n)
    eps = delta / 4
    eta = delta / 8
    t0 = sides[0]
    s0 = t0 - d
    lower = F(17, 20) if n == 2 else F(1)
    upper = 2 * lower
    assert lower < t0 and sides[-1] < upper
    assert n >= 2 and 0 < s0 < t0 and max(sides) < 2
    assert delta < min(sides[i] - sides[i - 1] for i in range(1, len(sides))) / 4
    theta_plus = (F(1, 2), F(1, 2)) + (F(0),) * (n - 2)
    theta_minus = (F(1, 2), F(-1, 2)) + (F(0),) * (n - 2)
    pivots = [tuple(-s0 * v for v in theta_plus), tuple(-s0 * v for v in theta_minus)]
    theta = [theta_plus, theta_minus]
    positions = pivots + [
        (sides[j] - t0 / 2 - delta,) + (F(0),) * (n - 1) for j in range(1, len(sides))
    ]
    masses = [t0**n / 2, t0**n / 2] + [
        sides[j] ** n - sides[j - 1] ** n for j in range(1, len(sides))
    ]
    assert all(x > 0 for x in masses)
    assert sum(masses, F(0)) == sides[-1] ** n < upper**n
    assert all(
        max(abs(a - b) for a, b in zip(x, y)) > 2 * eps
        for x, y in combinations(positions, 2)
    )
    bins = [bin_exp(t**n) for t in sides]
    assert len(set(bins)) == len(bins)
    # Both rays share x_0=0, but the pivots are distinct positive blocks.
    zero = (F(0),) * n
    assert all(
        tuple(p + s0 * v for p, v in zip(pivot, direction)) == zero
        for pivot, direction in zip(pivots, theta)
    )
    print(
        "\nFAN n=",
        n,
        "window=",
        (lower, upper),
        "sides=",
        list(map(str, sides)),
        "dyadic bins=",
        bins,
        "delta=",
        delta,
        "source_halfwidth=",
        eps,
        "receiver_halfwidth=",
        eta,
    )
    print(
        "early center=0, pivots=",
        pivots[0][:2],
        pivots[1][:2],
        "each pivot mass=",
        f"t0^{n}/2",
        "total source mass=",
        f"tlast^{n}",
    )
    centers = []
    for i, t in enumerate(sides):
        s = t - d
        for arm in (0, 1):
            pivot = pivots[arm]
            direction = theta[arm]
            center = tuple(p + s * v for p, v in zip(pivot, direction))
            if i == 0:
                assert center == zero
            prefix = set(range(i + 2))
            for j, source in enumerate(positions):
                distance = max(abs(a - b) for a, b in zip(source, center))
                if j in prefix:
                    assert distance + eps + eta < t / 2
                else:
                    assert distance - eps - eta > t / 2
                    # Even the earliest possible contact across the whole
                    # source/receiver neighborhoods is strictly after t_j.
                    next_price = sides[j - 1]
                    earliest = 2 * (source[0] - eps - center[0] - eta)
                    assert earliest > next_price
            assert sum((masses[j] for j in prefix), F(0)) == t**n
            if i:
                centers.append((i, arm, center))
        if i:
            xp = pivots[0][1] + s * theta[0][1]
            xm = pivots[1][1] + s * theta[1][1]
            assert xp == -xm and xp > 0
            # Distance to the entire opposite forward line, not merely to
            # its same-scale point: triangle inequality gives t_i-t_0,
            # achieved at the opposite point of the same ray parameter.
            dist = s - s0
            assert xp - xm == dist and dist > 2 * eta
            print(
                "  level=",
                i,
                "t=",
                t,
                "bin=",
                bins[i],
                "two y=",
                xp,
                xm,
                "cross-ray L1 distance=",
                dist,
                "common mass=",
                f"(t0)^{n}",
                "common/early=",
                1,
                "common/late=",
                (t0 / t) ** n,
                "same-level late-pair overlap/late=",
                1,
                "own pivot mass=",
                f"t0^{n}/2",
                "both target root masses=",
                f"{t}^{n}",
            )
    for (_, _, a), (_, _, b) in combinations(centers, 2):
        assert max(abs(x - y) for x, y in zip(a, b)) > 2 * eta
    print(
        "  verified early+late positive neighborhoods, pairwise disjoint late neighborhoods, distinct rays, all strict source and future-contact margins; upper window endpoint subthreshold"
    )


if __name__ == "__main__":
    run(2, [F(9, 10), F(23, 20), F(33, 20)])
    for n in (32, 64):
        run(n, [F(9, 8) * (1 + F(2, n)) ** i for i in range(5)])
    print(
        "\nPASS exact rational positive-L1 fan samples; no high-dimensional extrapolation"
    )
