"""True source frontiers with Walsh directions, plus KL and parameter checks.
Uses exact rationals for geometry, Arb for logarithms and Gibbs inequalities.
"""
from fractions import Fraction as F
import flint
from flint import arb, ctx

def aa(q):
    q = F(q)
    return arb(q.numerator)/q.denominator

def sign(i,j):
    return 1 if (i & j).bit_count() % 2 == 0 else -1

def test_walsh(n,dimension_count):
    assert n & (n-1) == 0 and 1 < dimension_count <= n
    root = F(9,8)
    d=F(1,5)
    radial=root-d
    delta=F(1,10000*n)
    eps=delta/4
    center_eps=delta/8
    # Nontrivial characters sum to zero over the coordinate set;
    # their products are characters indexed by xor of directions.
    xors={i^j for i in range(dimension_count) for j in range(i+1,dimension_count)}
    assert all(sum(sign(mask,k) for k in range(n))==0 for mask in xors)
    assert all(sign(i,0)==1 for i in range(dimension_count))
    assert n*radial/2 > F(n,3)
    sides=[root*(1+F(2,n))**j for j in range(3)]
    assert F(1)<root<sides[-1]<2
    prefixes=[root**n]+[sides[j]**n-sides[j-1]**n for j in range(1,len(sides))]
    assert all(m>0 for m in prefixes)
    assert sum(prefixes)==sides[-1]**n
    # The initial mass is uniformly divided into dimension_count source blocks
    # centered at -radial*row_i/2. At y=(s-root)*row_i/2,
    # the sup-distance to any initial pivot is at most (s-d)/2.
    for j,t in enumerate(sides):
        assert (t-d)/2+eps+center_eps<t/2
        assert sum(prefixes[:j+1])==t**n
        for h,s in enumerate(sides[1:],1):
            source1=s-root/2-delta
            center1=(t-root)/2
            other_displacement=(t-root)/2
            if h<=j:
                assert max(abs(source1-center1),other_displacement)+eps+center_eps < t/2
            else:
                assert 2*(source1-center1-eps-center_eps)>s
    assert sides[-1]**n<2**n
    low = n*radial/2
    # The dual orthogonality certificate refers to the displayed central pivots.
    print("Walsh physical example, n=",n,"directions=",dimension_count,"verified pair xors=",len(xors),
          "early pivot l1 distance to prior span=",low,
          "late center l1 distance at level 1=",n*(sides[1]-root)/2,
          "common/early=1","actual center cube halfwidth=",center_eps)

def entropy_checks():
    # Exact conditioned source law and actual late law in the nonnested R820 cube pair.
    early=[F(16,36),F(9,36),F(11,36),F(0)]
    late=[F(16,49),F(0),F(11,49),F(22,49)]
    c=sum(p for p,q in zip(early,late) if q)
    assert c==F(3,4)
    ratios={p/(c*q) for p,q in zip(early,late) if p and q}
    assert ratios=={F(49,27)}
    direct=sum(aa(p/c)*aa(p/(c*q)).log() for p,q in zip(early,late) if p and q)
    same=aa(F(49,36)).log()-aa(c).log()
    assert (direct-same).contains(0)
    print("Partial source overlap, c=",c,"likelihood ratio=49/27, KL=",direct.str(16))
    for n,sqrt_n in ((16,4),(64,8),(256,16),(1024,32),(4096,64)):
        # New positive block is located beyond the early right face at all
        # times up to its own true-root candidate. This realizes the ratio.
        early_side=F(9,8)
        late_side=early_side*(1+F(1,sqrt_n))
        delta=F(1,10000*n)
        assert late_side<2
        center=(late_side-early_side)/2
        fresh=late_side-early_side/2-delta
        assert 2*(fresh-delta/2)>late_side
        assert fresh-center+delta/2<late_side/2
        assert center+delta/2<late_side/2
        price=(late_side/early_side)**n
        assert price>1 and late_side**n<2**n
        lp=aa(price).log()
        assert 0<lp<sqrt_n
        for factor in (F(1,4),F(1),F(4)):
            b=aa(factor)*lp
            # Reference sees exactly 1/price of the early support. Early
            # sees all of it. Use the unrelaxed log moment to check the cost.
            direct_surplus=lp+(1+(b.exp()-1)/aa(price)).log()-b
            # log(price + exp(b) - 1) - b, evaluated without cancellation.
            surplus=((aa(price)-1)*(-b).exp()).log1p()
            assert surplus>0 and direct_surplus.overlaps(surplus)
        print("Physical late root n=",n,"receiver cap ratio=",
              aa(price).str(12),"exact log cost=",lp.str(14))
    return direct

def main():
    import platform
    print("Python",platform.python_version(),"python-flint",flint.__version__,"FLINT",flint.__FLINT_VERSION__)
    for n,d in ((16,8),(64,32),(256,128),(1024,512)):
        test_walsh(n,d)
    info=[]
    for prec in (256,384):
        ctx.prec=prec
        print("Arb precision",prec)
        info.append(entropy_checks())
    assert info[0].overlaps(info[1])
    print("PASS exact transversality, actual source allocations and two-precision entropy")
if __name__=="__main__":
    main()
