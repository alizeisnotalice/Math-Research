from pathlib import Path
import subprocess
import sys

if __name__ == "__main__":
    directory=Path(__file__).resolve().parent
    for filename in ("fans821.py","crossprice821.py"):
        print("Running",filename,flush=True)
        subprocess.run([sys.executable,"-B",str(directory/filename)],cwd=directory,check=True)
    print("All round 821 experiments completed.")
