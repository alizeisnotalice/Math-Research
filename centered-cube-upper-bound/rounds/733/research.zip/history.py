from fractions import Fraction as Q
from math import isqrt
from flint import arb,ctx
import sys,json
ctx.prec=256
def model(n,k):
    a=32*n
    lam=arb(2)**(arb(1)/n)
    # All permissible lower bin endpoints for each source give the bounds below.
    status=[]
    for l in range(n):
        sg=(-1)**l
        f=l<n//2
        g=not f or l<k
        x=sg*Q(3,50); y=-sg*Q(63,64)
        statuses=[]
        for bad,R in [(f,3),(g,2)]:
            c=(1 if bad else -1)*sg*Q(3*R,4)
            assert abs(x-c)+Q(1,16*a)<R and abs(c)<R
            miss=abs(x-y+c/R)
            uncertainty=Q(1,16*a)+Q(2,a)+Q(1,n)
            if bad: assert miss-uncertainty>Q(65,64)
            else: assert miss+uncertainty<Q(65,64)
            statuses.append(bad)
        status.append(statuses)
    cnt=[sum(b[j] for b in status) for j in (0,1)]
    assert sum(all(b) for b in status)==k
    K=4096*isqrt(n)*a**n; ell=arb(2).log()/K
    V=arb(1)/(8*a)**n; H=V*ell.expm1()/2
    lg=n*arb(32*n).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert 0<H<V/4 and lg>(4*arb(6)**n+1).log()
    # sixth-power moment evaluated at actual owner enlargement and finite dimension
    T=(1+arb(1)/a)*lam; rho=1+arb(1)/64+lam/a; v=rho-T
    from math import comb
    moment=v+2*T*sum(comb(6,j)*(-arb(15)/16)**j*((2-v)/(2*T))**(2*j+1)/(2*j+1) for j in range(7))
    price=moment*arb(16)**(6*arb(k)/n)
    return dict(n=n,k=k,separate_failures=cnt,joint_failures=k,per_axis=str(price),V_T=str(V),
                high=str(H),log_D_over_K_bounds=[str(lg/K),str((lg+arb(3).log())/K)],excess=0)
print(json.dumps(dict(python=sys.executable,precision=256,cases=[model(n,k) for n in (256,1024,4096) for k in (0,n//64,n//8)]),indent=2))
