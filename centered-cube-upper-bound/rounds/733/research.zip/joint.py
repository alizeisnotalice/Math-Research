"""Reverse coordinate selection: exact receiver moments, independent integration."""
from fractions import Fraction as F
from math import comb,isqrt
import platform,sys,json
def moments(j,p,z,T=F(1),rho=F(65,64)):
    # x in [0,2], by evenness and normalization by 2. g=1 up to rho-T.
    start=rho-T
    assert 0<=start<=2<=rho+T
    end=(2-start)/(2*T)
    return start+2*T*sum(F(comb(p,i))*(-(1-z))**i*end**(j*i+1)/(j*i+1) for i in range(p+1))
def quadr(j,p,z,T=F(1),rho=F(65,64)):
    # Exact polynomial integration by interpolatory quadrature on the ramp.
    m=j*p; w=F(0); start=rho-T
    for k in range(m+1):
        poly=[F(1)]
        for l in range(m+1):
            if l==k:continue
            poly=[u+v for u,v in zip([F(0)]+[q*m/(k-l) for q in poly],[-q*l/(k-l) for q in poly]+[F(0)])]
        x=start+(2-start)*F(k,m)
        g=(rho+T-x)/(2*T)
        w+=sum(c/(s+1) for s,c in enumerate(poly))*(1-(1-z)*(1-g)**j)**p
    return start+(2-start)*w
fixtures=[(m,p,z) for m,p,z in [(1,2,F(1,8)),(2,6,F(1,16)),(2,8,F(1,32)),(3,16,F(1,16)),(2,2,F(1,2))]]
if '--remote' in sys.argv:
    print(json.dumps([str(quadr(*v)) for v in fixtures]));sys.exit()
from flint import arb,ctx,__version__
from pathlib import Path
import subprocess
ctx.prec=256
def A(x):return arb(x.numerator)/x.denominator
out=[]
for m,p,z in fixtures:
    c=moments(m,p,z)
    out.append(dict(m=m,p=p,z=str(z),moment=str(c),alpha_threshold=str((-A(c).log())/(p*(-A(z).log())))))
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
proc=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=100)
assert proc.returncode==0,proc.stderr
assert json.loads(proc.stdout)==[v['moment'] for v in out]
print(json.dumps(dict(python=sys.executable,version=platform.python_version(),flint=__version__,tests=out,remote_command=cmd,remote_exit=proc.returncode,exact_match=True),indent=2))
