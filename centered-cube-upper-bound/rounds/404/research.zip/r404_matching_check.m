% Continuous full-f matching diagnostic, not an interval certificate.
% f=1_[0,2], endpoint A=[0,2], m_A=2, R_w=1.
% Actual receiver set: qmin <= m_w < M=2/e, q_w=m_w.
M=2/exp(1);
fixtures=[];
for qmin=[0.3]
 for yy=[0.5,1]
  for dd=[0.1,0.3]
   fixtures(end+1,:)=[qmin,yy,dd,1]; %#ok<SAGROW>
  end
 end
end
for qmin=[M*(1-1e-6),0.5]
 for yy=[qmin,M,2-M,2-qmin]
  for dd=[1e-6,0.25]
   fixtures(end+1,:)=[qmin,yy,dd,2]; %#ok<SAGROW>
  end
 end
end
for qmin=[0.02,0.1,0.6]
 for yy=[-1,0,0.1,0.5,1,1.8,2,3]
  for dd=[0.001,0.1,0.5,1,3]
   fixtures(end+1,:)=[qmin,yy,dd,3]; %#ok<SAGROW>
  end
 end
end
maxGap=0;maxRatio=0;counts=zeros(1,3);
for kk=1:size(fixtures,1)
 qmin=fixtures(kk,1);yy=fixtures(kk,2);dd=fixtures(kk,3);
 lo=max(0,yy-dd);hi=min(2,yy+dd);
 if hi<=lo
  lhs=0;rhs=0;
 else
  zfun=@(z) log(max(1,M./max(qmin,z)))+log(max(1,M./max(qmin,2-z)));
  breaks=[qmin,M,2-M,2-qmin];breaks=sort(unique(breaks(breaks>lo & breaks<hi)));
  lhs=integral(zfun,lo,hi,'Waypoints',breaks,'AbsTol',1e-12,'RelTol',1e-10)/2;
  wfun=@(m) (max(0,min(hi,m)-lo)+max(0,hi-max(lo,2-m)))./m;
  breaks=[lo,hi,2-lo,2-hi];breaks=sort(unique(breaks(breaks>qmin & breaks<M)));
  rhs=integral(wfun,qmin,M,'Waypoints',breaks,'AbsTol',1e-12,'RelTol',1e-10)/2;
 end
 Rstar=M/qmin;
 bound=(Rstar+2*dd)/2;
 assert(abs(lhs-rhs)<2e-9);
 assert(rhs<=bound+2e-9);
 assert(rhs<=(1+2*dd)/2+2e-9); % even actual fixed R=1 support envelope
 maxGap=max(maxGap,abs(lhs-rhs));maxRatio=max(maxRatio,rhs/bound);
 counts(fixtures(kk,4))=counts(fixtures(kk,4))+1;
end
fprintf('PASS continuous actual-f matching: initial=%d boundary=%d expanded=%d total=%d\n',counts(1),counts(2),counts(3),sum(counts));
fprintf('max Tonelli two-order numerical gap %.17g; max lhs/bound %.17g\n',maxGap,maxRatio);
fprintf('Ordinary MATLAB quadrature; not interval evidence or full-core realization.\n');
