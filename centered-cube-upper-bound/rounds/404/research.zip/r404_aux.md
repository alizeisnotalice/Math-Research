# R404 — sharp all-coordinate envelope for a measurable radius selector

**Result.** The formula below is the exact unrestricted-center envelope for one exclusive occupation, with the entire displacement vector retained. It treats varying actual radii, zero coordinates, large displacements and strict mass cutoffs. It gives a concrete improvement over summing separate face bounds, but its worst-case double-rank price remains dimension-linear. No new root receipt or ledger substitution is asserted.

## 1. The envelope

Fix 0<a≤b, q_->0, y,z∈R^n and a measurable selector a≤R(w)≤b. Set

d_j=|y_j−z_j|,  k=#{j:d_j>0},
P(r)=∏_{j=1}^n(1−d_j/r)_+.

Define the dimensionless function

C_{a,b}(d)
 =1−[P(a)+P(b)]/2+n log(b/a)
                  −(n−k/2)∫_a^b P(r)dr/r.                 (1)

An equivalent expression containing only nonnegative terms is

C_{a,b}(d)
 =(k/2)log(b/a)+1−[P(a)+P(b)]/2
                  +(n−k/2)∫_a^b[1−P(r)]dr/r.             (2)

For every actual receiver subset E and selector,

∫_E 1_{y∈Q_R(w)}1_{z∉Q_R(w)}dw/[q_-R(w)^n]
                         ≤C_{a,b}(d)/q_-.                 (3)

In fact the right side is the supremum of the left side over all measurable selectors on unrestricted centers. This sharpness statement is for a fixed source pair. It does not authorize choosing a different selector for each source pair in the original integral.

Special cases and the full general bound are

C_{a,b}(0)=0,
C_{a,a}(d)=1−P(a),
0≤C_{a,b}(d)≤1+n log(b/a),
max_j d_j≥b ⇒ C_{a,b}(d)=1+n log(b/a).                     (4)

The explicit k in (1) is necessary. When positive displacement coordinates tend to zero while their number stays k, C tends to (k/2)log(b/a). The value at the exactly zero vector is instead zero. Arbitrary measurable radius selection can track a source boundary, so this discontinuity of the selector supremum is genuine.

## 2. Pointwise selector maximization and all-coordinate shell integration

Translate y to zero and reflect coordinates so z_j=d_j≥0. Write

ρ_y(w)=2||w−y||∞,  ρ_z(w)=2||w−z||∞,
r_*(w)=max(a,ρ_y(w)).

Capture of y and noncapture of z require ρ_y≤R<ρ_z. Thus, pointwise in the REAL center w,

1_{ρ_y≤R<ρ_z}/R^n
 ≤1_{ρ_y≤b}1_{r_*<ρ_z}/r_*^n.                             (5)

This is attained wherever positive by R=r_*; elsewhere R=b produces no exclusive capture when the envelope is zero. It is a measurable selector. No distribution for the actual radius, independent-radius integration, or source-density bound has been inserted.

The contribution of ρ_y≤a to the right side of (5) is exactly 1−P(a), by the ordinary fixed-cube overlap volume. For shells ρ_y=r>a, let d_max=max_j d_j. If r<d_max, every shell center is exclusive, giving shell volume density n r^{n−1}. For r>d_max, all factors r−d_j are positive. A coordinate with d_j>0 has one shell face lying inside Q_r(z); a coordinate with d_j=0 has both faces inside. Hence the shell volume density that also captures z is

(1/2)Σ_{j=1}^n(1+1_{d_j=0})∏_{l≠j}(r−d_l).              (6)

The factor 1/2 is the actual normal displacement of a face when the side r changes. Face intersections have zero Lebesgue shell measure; exact capture conventions at r=d_max affect no dr integral. This is an exact face-trace computation, not an n-term union bound.

For almost every r>0, (6) divided by r^n equals

[(2n−k)P(r)+rP'(r)]/(2r),                                (7)

with both terms zero below d_max. Therefore integrating the exclusive shell density gives

1−P(a)+∫_a^b{n/r−[(2n−k)P(r)+rP'(r)]/(2r)}dr,

which is precisely (1). P is continuous and absolutely continuous on [a,b], including its break at d_max, so no boundary term is missing. Formula (2) follows by adding and subtracting ∫dr/r.

The selector attaining (5) can be combined with a finite L1 source f that is constant q_- on a sufficiently large region containing all selected cubes with relevant centers. On that receiver set m_w=q_-R_w^n holds exactly. Thus full matching at the selected radius alone does not invalidate the pointwise envelope's sharpness. This does not furnish an extremizer of the original marked high-rank problem.

For a single fixed pair, the two opposite exclusive maximizing-center regions are disjoint: they require respectively max(a,ρ_y)<ρ_z and max(a,ρ_z)<ρ_y. A common measurable radius field can select the respective minimum radius on each region. Consequently the two pointwise occupation maxima can be attained simultaneously for that pair. Their product bound cannot be improved merely by saying that the two tags use the same selector. A source-integrated improvement must use further joint information across source pairs.

## 3. Strict actual mass cutoff and optional near-vector estimate

Return to the full original field m_w=q_wR_w^n, q_-≤q_w≤λ. Since dw/m_w≤dw/(q_-R_w^n), a strict gate m_w<M implies R_w<(M/q_-)^{1/n}. Define

b_M=min{b,(M/q_-)^{1/n}}.

If M≤q_-a^n, the exclusive occupation with this gate is zero. Otherwise b_M≥a (equality is possible when b=a), and

∫c_w(y)(1−c_w(z))1_{m_w<M}μ(dw)
                              ≤C_{a,b_M}(d)/q_-.         (8)

The endpoint b_M is included only as a positive enlargement of the strict gate. An actual selector may equal b_M on a positive-measure set of centers; no zero-measure assertion about that event is used. If b=a and M>q_-a^n, the nonempty bound is the fixed-radius value C_{a,a}(d)=1−P(a). Only M≤q_-a^n is declared empty. No implication from noncapture to a larger cube has been used.

When d_max≤a, a simpler upper bound retaining coordinate support and l1 displacement follows from the exact shell formula:

C_{a,b}(d)≤(k/2)log(b/a)
 +[Σ_j d_j/a]·[1+(2n−k−1)(1−a/b)/2].                     (9)

To verify (9), use 1−P(a)≤Σd_j/a in the core term. In the shell, use 1−∏_{l≠j}(1−d_l/r)≤Σ_{l≠j}d_l/r in (6). The coefficient identity is

Σ_j(1+1_{d_j=0})Σ_{l≠j}d_l=(2n−k−1)Σ_l d_l.

Equation (1), not (9), remains the stronger exact envelope. In particular the term (k/2)log(b/a) does not vanish as the nonzero d_j become tiny. For the original full-f posterior pair, k=n almost everywhere: each coordinate marginal is absolutely continuous, so {y_j=z_j} has π_A⊗π_A measure zero. Coordinate sparsity must therefore not be presented as a typical source-mass saving.

## 4. Exact interface to the original double-rank discount

Use the R403 original endpoint A, strict far mass m_w<m_A/K, and its two exclusive numerators E_y,E_z. All old source/edge/clock/stage marks stay frozen. Let b_A=min{b,(m_A/(Kq_-))^{1/n}} and set C_A(d)=0 only if m_A/K≤q_-a^n; otherwise set C_A(d)=C_{a,b_A}(d), including the possible fixed-radius case b_A=a. Equation (8) gives

E_y E_z≤C_A(d)^2/q_-².                                   (10)

The same estimate remains an upper bound after any of the existing nonnegative joint tag masks (shared-failure, inner/collar, count-weighted, and so on). It does not require reassigning their tags or subtracting an old negative square.

To quantify the resulting price, set the already frozen R403 constant

B_L=β/(2L)+C_col/[(2−ε)(L−ε)],
h=(1+√n)/(εq_-),
J_C=∫_E σ(dA)∫π_A(dy)π_A(dz) C_A(|y−z|)^2.

The same pointwise original-row/incoming bounds and soft double-rank inequalities used in R403 give the legitimate upper estimate for the two-end original R400 cost (and hence any retained positive submeasure)

R400≤[B_L/(q_-²h²)]J_C.                                  (11)

Indeed the external and small-end soft factors divided by E_yE_z are at most 1/(2Lh²) and 1/[(2−ε)(L−ε)h²], respectively. Insert (10), retain the original old-source conditioning until its pointwise β or C_col bound is used, and sum b_i at the SAME new source before applying Σ_i b_i≤1. This proves (11) without changing full f, the selected masses, the original clocks or history. The discarded positive original restrictions may be kept for a sharper version, but have not been estimated here.

The currently available general evaluation of (11) is only

J_C≤[1+n log(b/a)]² X_q,
R400≤ ε²B_L [1+n log(b/a)]²/(1+√n)² ·X_q.                 (12)

For a full octave this has a dimension-linear coefficient. Choosing L of order n to suppress it would enlarge the inherited R398 price P_L=λh[β(L+ε)+C_col L] accordingly; that is not a root-order resolution. No such parameter change is silently made here.

Thus (1) is a sharp all-coordinate center formula and (11) its honest original-cost interface. What remains missing is a source-integrated estimate for J_C WITH the actual high-rank and surviving tag correlations strong enough to improve (12). The pointwise formula alone supplies none, and no new paid level set or special source class is claimed. The current R403 complement and ledger remain unchanged.

## 5. Three-stage local verification

Executed `python3 /tmp/r404_aux_check.py` locally. Available system Python has neither mpmath nor sympy, so the script uses Fraction, Decimal and an independent ordinary-double midpoint integration; it does not rely on unavailable packages.

Output:

`PASS {'exact_geometry': 1386, 'exact_polynomial': 12, 'native_shell_quadrature': 6, 'expanded_decimal': 504, 'mass_cut': 90, 'fixed_radius_mass_boundary': 3} total 2001`

`ordinary_midpoint_max_abs_error 9.872755946105372e-10`

Stage 1 checks pointwise actual-radius capture/noncapture against (5) on finite 1D/2D grids, including exact face equalities, zero coordinates and large displacements. It separately verifies the polynomial identity behind (7) in Fraction arithmetic. Stage 2 independently integrates the real center-shell face expression at six parameter choices, splitting at d_max, and compares with (1); this is ordinary numerical integration, not an interval certificate. Stage 3 expands to n=1,2,3,4,8,16,32,64, three octave ratios and seven displacement magnitudes with full, one-coordinate and mixed vectors. Formula values computed with 80- and 120-digit Decimal arithmetic agree within the stated script tolerance. Strict mass cutoff implications are checked separately with Fraction. Three additional fixed-radius checks use b=a, verifying that M>q_-a^n retains the positive fixed-cube overlap deficit while M=q_-a^n and M<q_-a^n give an empty strict gate.

These are diagnostics of the geometric formula and its boundaries. They do not realize every original high-rank/history condition or prove the missing source-integrated budget. The theorem relies on the exact positive envelope and shell calculation above. Bounded delivery ends here.
