from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
from math import prod, log

counts={'exact_geometry':0,'exact_polynomial':0,'native_shell_quadrature':0,'expanded_decimal':0,'mass_cut':0}

def poly(ds):
    out=[F(1)]
    for d in ds:
        nxt=[F(0)]*(len(out)+1)
        for j,x in enumerate(out): nxt[j]+=x; nxt[j+1]-=d*x
        out=nxt
    return out

def overlap(r,ds): return prod((max(F(0),1-d/r) for d in ds),start=F(1))
def dec(x): return Decimal(x.numerator)/Decimal(x.denominator)
def envelope(a,b,ds,prec):
    with localcontext() as ctx:
        ctx.prec=prec
        n=len(ds); k=sum(d>0 for d in ds)
        pa,pb=overlap(a,ds),overlap(b,ds)
        logarithm=(dec(b)/dec(a)).ln()
        lo=max(a,max(ds))
        integral=Decimal(0)
        if lo<b:
            coeff=poly(ds)
            rat=sum((coeff[j]*(lo**(-j)-b**(-j))/j for j in range(1,len(coeff))),F(0))
            integral=(dec(b)/dec(lo)).ln()+dec(rat)
        direct=1-(dec(pa)+dec(pb))/2+Decimal(n)*logarithm-(Decimal(n)-Decimal(k)/2)*integral
        positive=Decimal(k)/2*logarithm+1-(dec(pa)+dec(pb))/2+(Decimal(n)-Decimal(k)/2)*(logarithm-integral)
        assert abs(direct-positive)<Decimal(10)**(-(prec-8))
        return +direct

# Stage 1: actual varying-radius indicators and exact polynomial identity.
for n in (1,2):
    for ds in product((F(0),F(1,2),F(2)),repeat=n):
        for w in product((F(-2),F(-1),F(-1,2),F(0),F(1,2),F(1),F(2)),repeat=n):
            ry=2*max(map(abs,w)); rz=2*max(abs(x-d) for x,d in zip(w,ds))
            a,b=F(1),F(2); rmin=max(a,ry)
            major=F(1,rmin**n) if rmin<=b and rmin<rz else F(0)
            for R in (a,F(3,2),b):
                actual=F(int(ry<=R and rz>R),R**n)
                assert actual<=major
                counts['exact_geometry']+=1
            if major:
                assert ry<=rmin and rz>rmin
        coeff=poly(ds); n=len(ds); k=sum(d>0 for d in ds)
        lhs=[F(0)]*n
        for i,d in enumerate(ds):
            pi=poly(ds[:i]+ds[i+1:]); nu=1+int(d==0)
            for j,x in enumerate(pi): lhs[j]+=nu*x
        rhs=[F(2*n-k-j)*x for j,x in enumerate(coeff)]
        assert lhs+[F(0)]==rhs
        counts['exact_polynomial']+=1

# Stage 2: integrate real center-shell faces by independent midpoint quadrature.
maxerr=0.0
cases=[(F(1),F(2),(F(0),F(1,4))),
       (F(1),F(2),(F(1,4),F(1,2))),
       (F(1),F(2),(F(3,2),F(0))),
       (F(1),F(2),(F(1,3),)*4),
       (F(1),F(5,4),(F(0),)*3),
       (F(1),F(2),(F(3),F(1,2)))]
for a,b,ds in cases:
    n=len(ds); dmax=max(ds); edges=sorted(set([a,b]+([dmax] if a<dmax<b else [])))
    total=float(1-overlap(a,ds)); steps=12000
    for left,right in zip(edges,edges[1:]):
        width=float(right-left)/steps
        for j in range(steps):
            r=float(left)+(j+.5)*width
            face=n/r
            if r>float(dmax):
                face-=sum((1+int(d==0))*prod(1-float(e)/r for t,e in enumerate(ds) if t!=i) for i,d in enumerate(ds))/(2*r)
            total+=width*face
    want=float(envelope(a,b,ds,90)); err=abs(total-want); maxerr=max(maxerr,err)
    assert err<2e-8
    counts['native_shell_quadrature']+=1

# Stage 3: expanded vectors, zero coordinates, endpoints and strict mass caps.
for n,ratio,scale in product((1,2,3,4,8,16,32,64),(F(1),F(5,4),F(2)),(F(0),F(1,100),F(1,2),F(1),F(3,2),F(2),F(3))):
    for kind in ('full','one','mixed'):
        ds=tuple(scale if kind=='full' or i==0 else (F(0) if kind=='one' else scale*F(i,n)) for i in range(n))
        v80=envelope(F(1),ratio,ds,80); v120=envelope(F(1),ratio,ds,120)
        assert abs(v80-v120)<Decimal('1e-50')
        bound=Decimal(1)+Decimal(n)*(dec(ratio)).ln()
        assert v120>=-Decimal('1e-70') and v120<=bound+Decimal('1e-25')
        if not any(ds): assert abs(v120)<Decimal('1e-70')
        if max(ds)>=ratio: assert abs(v120-bound)<Decimal('1e-25')
        counts['expanded_decimal']+=1
for n,q,R,c in product((1,2,3),(F(3,4),F(1)),(F(1),F(3,2),F(2)),(F(1,2),F(1),F(5,4),F(2),F(3))):
    M=F(3,4)*c**n
    if q*R**n<M: assert R<c
    counts['mass_cut']+=1
counts['fixed_radius_mass_boundary']=0
# Native 1D fixed field: R=a=b=1, q=q_-=1; the exclusive
# center interval for y=0,z=1/4 has length 1/4.
a=b=F(1); q=F(1); ds=(F(1,4),)
for M in (F(1,2),F(1),F(3,2)):
    actual=F(1,4) if q*a<M else F(0)
    capped=F(0) if M<=q*a else 1-overlap(a,ds)
    assert actual==capped
    if M>q*a: assert capped>0 and a==b
    else: assert capped==0
    counts['fixed_radius_mass_boundary']+=1
print('PASS',counts,'total',sum(counts.values()))
print('ordinary_midpoint_max_abs_error',repr(maxerr))
