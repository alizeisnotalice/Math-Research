from fractions import Fraction as F
from itertools import product
counts={'native_matching_integral':0,'finite_full_source_cancellation':0,'marked_stage_bound':0,'parameter_price':0}
# Exact native Lebesgue model, valid for the lemma's arbitrary K>1.
# f=1 on a bounded box containing all cubes; parent side 2 at 0;
# witness centers [-1/2,1/2]^n, side 1. One parent-point override is null.
for n,rstar,d in product((2,3,4,8,16),(F(5,4),F(3,2),F(7,4)),(F(1,20),F(1,8),F(1,2))):
    mA=F(2)**n; K=(2/rstar)**n
    assert F(1)<K<mA
    exact=(2*d-d*d)**n/mA
    center=(rstar+2*d)**n/mA
    relaxed=(1+2*d)**n/K
    assert exact<=center<=relaxed
    counts['native_matching_integral']+=1
# Finite quadrature checks only: actual full source masses, no claim that
# these atomic receiver weights obey a native Lebesgue center-volume bound.
sources=list(product((F(-1),F(0),F(1)),repeat=2))
centers=list(product((F(-1),F(-1,2),F(0),F(1,2),F(1)),repeat=2))
def cap(c,R,z): return all(abs(x-y)<=R/2 for x,y in zip(c,z))
for seed in range(1,7):
    fs=[F((j*seed+2)%7+1,13) for j in range(len(sources))]
    mA=sum(fs)
    receivers=[]
    for j,c in enumerate(centers):
        R=(F(1),F(3,2),F(2))[j%3]
        m=sum(f for z,f in zip(sources,fs) if cap(c,R,z))
        if m: receivers.append((c,R,m,F(j%4+1,11)))
    for K,d,y in product((F(2),F(3),F(5)),(F(0),F(1),F(2)),sources):
        lhs=F(0); cancelled=F(0); domain=F(0)
        for c,R,m,weight in receivers:
            if not m<mA/K: continue
            loc=sum(f for z,f in zip(sources,fs) if cap(c,R,z) and max(abs(z[j]-y[j]) for j in range(2))<=d)
            lhs+=weight*loc/(m*mA)
            cancelled+=weight*min(F(1),loc/m)/mA
            if max(abs(c[j]-y[j]) for j in range(2))<=R/2+d: domain+=weight/mA
        assert lhs==cancelled and lhs<=domain
        counts['finite_full_source_cancellation']+=1
for seed in range(1,25):
    # Same new source across stages, with arbitrary old-source row cap.
    b=[F((seed*j)%7+1,40) for j in range(1,5)]
    assert sum(b)<=1
    beta=F(seed%5+1,6)
    rows=[beta*F((seed+j)%5,4) for j in range(4)]
    raw=[F(seed%7+j+1,17) for j in range(4)]
    bound=max(raw)
    assert sum(b[i]*rows[i]*raw[i] for i in range(4))<=beta*bound
    counts['marked_stage_bound']+=1
for root,eps,L,beta,col,log2upper in product((2,3,4,8),(F(1,10),F(1,2)),(F(4),F(12)),(F(1,3),F(3,4)),(F(1),F(5,2)),(F(7,10),)):
    n=root*root; s=1+root
    An_upper=1+n*log2upper
    BL=beta/(2*L)+col/((2-eps)*(L-eps))
    assert An_upper<=s*s
    assert BL<=(beta+col)/L
    for t in (F(1),F(2),F(10)):
        fee=eps**2*An_upper*BL/(s*s*t)
        assert fee<=(beta+col)/(4*L*t)
        counts['parameter_price']+=1
print('PASS',counts,'total',sum(counts.values()))
