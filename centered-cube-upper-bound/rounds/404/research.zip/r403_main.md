# 第403轮：共享分离坐标与计数软权重的扩大付款

2026-10-19。上一轮已形成一般近源真实分支付款。本轮扩大已付标签集合，保留完整余项；不是将一个新名字替换未付积分。原一般n^(1/2+o(1))目标仍未达到。

## 完整继承合同

以r402_main.md为权威继承账：完整非负L1来源f、真实接收者du、a≤R_u≤b≤2a、m_u=f(Q_u)=q_uR_u^n、q_-≤q_u≤λ、μ=du/m、σ=qdu、π_u=f c_u/m_u、X_q=σ(E)、W=∫f。所有原源/目标/时钟/历史与stage标记冻结。S=β+C_col，K=e^(√n)，s=1+√n，h=s/(ε_0q_-)，0<ε_0≤1/2。γ_out≤βσ，Σb_i≤1，原两端R400≤2G0≤2βX_q。

取L≥4、0<ζ≤1、d0=ζa/n；始终使用同一near阈值d0。仅near域付款，far原样保留。n≥2用于几何，而原高维换档账n≥9。半径bins及其真实inner/collar沿用R402的r_j=a exp(j/√n)与实际r(w)。L如有重选，必须在R398母拆分中完整替换P_L和高/低秩分支，其余场不变；两份P_L不叠加。

在每一原端点A、旧来源y及新来源z下，以R402同一Q_y⊗Q_z附加actual exclusive witnesses w,t。其严格质量截断分别m_w,m_t<m_A/K；分母E_y=Z_A(y)−C_A(y,z)、E_z=Z_A(z)−C_A(y,z)在live支严格正。每一个原外部v、E_uv/Z_u因子（若用ν表示）和stage均保留，未给w,t新历史资格。

## 新支付一：任一共享分离坐标

定义完整失败坐标集

S_w(y,z)={j: |z_j−w_j|>R_w/2}，
S_t(z,y)={j: |y_j−t_j|>R_t/2}。

在各exclusive支它们均非空。用事件S_w∩S_t≠∅替换原“首个失败坐标相同”。R402单面容量本来就不要求first限制：near下每个F_j(y,z)=∫1_{exclusive且j失败}μ(dw)≤2/q_-。因此共享事件的原始occupation满足

\[
A_{\rm shared}\le\sum_{j=1}^nF_j(y,z)F_j(z,y)\le4n/q_-^2.
\]

左侧是一个真实union事件，每对w,t只计一次；右侧重复覆盖仅作为正上界，不是重复扣费。经R401原soft-complement不等式和逐来源β/C_col容量、stage一次求和，得到同R402的

\[
P_{\rm shared}\le d_{\rm face}X_q,\quad
 d_{\rm face}=4\varepsilon_0^2\left[\frac\beta{2L}+
 \frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}\right]\le S/L.
\]

这是替换旧face付款，不把旧first-same价格再加一次。同参数下旧first-same事件包含于shared，所以新正余量确实不大于旧余量；不保证每一实际输入上有严格改善或统一正比例。

## 同一joint标签上的内层付款与新支付二

在near域先支付shared；对其补集，即两个完整失败集合不相交的标签，依次支付old-inner和old-collar/new-inner。此步骤仍用原同一Q_y⊗Q_z，不能先平均shared再重新采样。其原两端费用为R402已证

\[
\alpha_{\rm bin}=2\beta(\eta_y+\eta_z-\eta_y\eta_z)\le4\beta\zeta,
\quad\eta_y=\frac{\zeta\varepsilon_0}{1-\varepsilon_0},
\quad\eta_z=\frac{\zeta\varepsilon_0}{L-1-\varepsilon_0}.
\]

只把旧inner事件进一步限制，不增加这一上界；它不是新来源费用。外部端扩展采用R402父主文的两端证明和保守2β价，不退回aux仅小端的合同。

在剩余不相交且双collar标签中，以τ=min(1,|S_w||S_t|/n)支付同一标签的份额。由于不相交，

\[
\tau=\min(1,|S_w||S_t|/n)\le\frac{|S_w||S_t|}{n}
 =\frac1n\sum_{j\ne k}\mathbf1_{j\in S_w}\mathbf1_{k\in S_t}.
\]

保留不相交和双collar定义实际正分量；仅作上界时丢掉这些限制。其raw occupation≤n^(-1)Σ_{j≠k}F_j(y,z)F_k(z,y)≤4(n−1)/q_-²。再用完全相同的soft/rank/stage回代，新增费用

\[
P_{\rm large}\le(1-1/n)d_{\rm face}X_q.
\]

该软付款仅作用于shared、inner的补集；其与残余按权重分摊同一标签，不能称为两个不交事件。n=2,3时虽无乘积≥n标签，软付款仍可为正。

## 精确覆盖与总账

同一near联合law逐点分成五项：shared；不相交old-inner；不相交old-collar/new-inner；不相交双collar乘τ；不相交双collar乘(1−τ)。far原样保留。所有项非负，和为原R400。

令最后一项与far合计为R403，则

\[
R400=P_{\rm shared}+P_{\rm inner}+P_{\rm large}+R403,
\quad\Delta_{403}=(2-1/n)d_{\rm face}+\alpha_{\rm bin}
\le2S/L+4\beta\zeta.
\]

余项具体要求：near实际两个失败坐标集合非空且不相交，集合大小乘积<n，并显式保留权重(1−|S_w||S_t|/n)_+，两来源分别在实际radius-bin collar；以及全部far费用。不能仅凭该低乘积条件支付双collar或far。

若要Δ403≤δ，可选L≥max(4,4S/δ)、ζ≤min(1,δ/(8β))（β=0时后一个条件免除）。较大L的完整P_L和ζ缩小后的较大far补集仍保留。当前共同捕获旧系数记χ_n=2(λ/q_-)Sε_0/[K(1+√n)]（即R402的ζ_n，与距离ζ区分），P_L=λh[β(L+ε_0)+C_col L]，Λ=128/119。n≥9时

\[
G_0\le16R403+16(\chi_n+\Delta_{403})X_q+16(s+P_L)W,
\]
\[
B_H\le32R403+[E_{387}+32(\chi_n+\Delta_{403})]X_q+[S_{390}+40s+32P_L]W,
\]
\[
\text{入口}\le\Lambda\{8\lambda HW+2d_{\rm eff}A_nW_\nu/H+64R403
+[2E_{387}+64(\chi_n+\Delta_{403})]X_q+[2S_{390}+80s+64P_L]W\}.
\]

Δ403替换上轮Δ，不把两轮整笔吸收费相加。与R402同参数比较只增加计数软付款的保守(1−1/n)d_face价，shared替换不加价，inner上界原样保留。已支付的χ_n仅一次。新增/更新吸收仍须放回64Λ乘子并核全局可用余额；尚未证明全部旧槽总和可吸收。

低维及固定维度门下的维数用G0≤S(1+Nlog2)W/2直接替换整个core槽，不叠加高维账。固定N需旧参数维度一致。其余入口选择、soft/crossing/entry、重尾/宽距离/低pe/极端尺度补集、初始/删除跳跃/未来删除、全尺度聚合及极限，均完整保留。来源费用P_L的根阶表述保留所有既定ε_0^(-1)等依赖。

## 本机三阶段检查和证明边界

父本机运行python3 r403_check.py：28组带有理权的singlejoint分拆与face证书（初步8组n2–3，阈值压力8组n4–5，扩大12组n6–8），以及36项精确费用检查。所有非空失败集合在每组中枚举，近域五权精确覆盖，旧付款包含于新付款，shared union与disjoint计数软付款容量及inner-union界均核对。另运行作者r403_geometry_check.py，25070项Fraction检查通过。有限标签模型不声称native full-core实现或一般正比例。旧的硬高乘积付款也保留作比较，逐点验证新的软付款至少同样大。新残余是同参数下旧残余的正限制，但新增保守费用后不能据此断言显示总上界逐输入变小。

脚本仅用标准库Fraction及整数；结果保存r403_check.result.txt。使用R402已独审的真实变半径单面定理，本轮不声称重新运行其MATLAB。全类解析证明不由有限枚举替代。G03技能未定义的捕获树/Gram映射不作为工具，这里只用直接已证center容量和非负union界。

独审先独立筛查两个新命题，再审作者与本主文。无实际逐模型扣额数据，不推算额度比例。归档包含详细LaTeX源与必要复现材料，不编译PDF。原一般上界仍未闭合。
