from fractions import Fraction as F
from math import comb, factorial
counts={'initial':0,'boundary':0,'expanded':0}
# Rational polytope offset polynomial: exact coefficient and upper-envelope audit.
for n in [1,2,3,4,9,16,64,256]:
 for rho in [F(0),F(1,128),F(1,32),F(1,8),F(1,2)]:
  terms=[F(comb(n,k),factorial(k))*(2*rho)**k for k in range(n+1)]
  diag=[(2*rho*n)**k/F(factorial(k)**2) for k in range(n+1)]
  assert all(a<=b for a,b in zip(terms,diag))
  assert sum(terms)<=sum(diag)
  # coefficient of x^(2k) in exp(x)^2 dominates its diagonal 1/(k!)^2
  for k in range(n+1):
   assert F(1,factorial(k)**2)<=F(2**(2*k),factorial(2*k))
  phase='initial' if n<=4 else 'boundary' if n<=16 else 'expanded'
  counts[phase]+=1
# For square n, root-scale containment and conservative fee checks are rational.
fees=0
for root in [3,4,8,16,64]:
 n=root**2;s=1+root
 # log(b/a)<=log2<1 so A_n<=1+n<s^2.
 assert 1+n<s*s
 for eps in [F(1,16),F(1,4),F(1,2)]:
  for L in [4,8,32]:
   beta=F(3,4);col=F(5,3);S=beta+col
   BL=beta/(2*L)+col/((2-eps)*(L-eps))
   face=4*eps**2*BL
   delta=2*eps**2*F(1+n,s*s)*BL
   assert delta<=face/2<=S/(2*L)
   # exp(1/root)-1 >= 1/root, so new halfwidth>=a/(2root)>=a/n.
   assert F(1,2*root)>=F(1,n)
   fees+=1
print('PASS exact Minkowski offset coefficient checks:',counts,'total',sum(counts.values()))
print('PASS rational conservative union fees and old-near containment:',fees)
print('Finite arithmetic diagnostics; exponential domination and full matching are proved analytically.')
