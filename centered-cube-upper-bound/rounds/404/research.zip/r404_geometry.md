# R404 — Full near-source payment from matching and actual center volume

## 1. Exact new claim and frozen scope

Keep the full R400 field and original marked costs, before the optional R402–403 near-source partitions. Thus f≥0 is in L1, W=∫f, actual receivers carry Lebesgue measure, m_A=f(Q_A)=q_A R_A^n, q_-≤q_A≤λ, and a≤R_A≤b≤2a. Write μ(dA)=dA/m_A, σ(dA)=q_A dA, π_A(dz)=f(z)c_A(z)dz/m_A, X_q=σ(E). Every actual stage, old-source mark, clock, spatial restriction, strict mass cutoff, and rank gate is unchanged. Let

 K=exp(√n), s=1+√n, h=s/(ε_0 q_-),
 A_n=1+n log(b/a), S=β+C_col, 0<ε_0≤1/2,
 B_L=β/(2L)+C_col/[(2−ε_0)(L−ε_0)], L≥4.

Here β and C_col are the established pointwise OLD-source outgoing and incoming bounds, not new-source or witness bounds.

The screened claim is a matching-based bound for the ENTIRE new-source occupation in a specified neighborhood. For any fixed compact source displacement set D⊂R^n, any actual endpoint A, and any y, put

 Z_A(z)=∫1_{m_w<m_A/K}c_w(z)μ(dw),
 R_*=(m_A/(K q_-))^(1/n).

Then, if R_*>a,

 ∫π_A(dz)1_{z−y∈D}Z_A(z)
      ≤ |D+Q_{R_*}(0)|/m_A.                             (1)

If R_*≤a, the left side is zero. Formula (1) involves actual matching, not merely a lower mass or center-envelope inequality: after swapping source and receiver, f(Q_w)=m_w cancels the small receiver's denominator. The remaining measure is plain actual center volume. This is the new step.

For the whole near region ||z−y||∞≤d, d≥0, (1) implies

 ∫π_A(dz)1_near Z_A(z)
      ≤ (1+2d/a)^n/(q_-K).                              (2)

In particular, no failure-coordinate label, bin collar, or soft count condition is required. The theorem pays the full near part of R400 and therefore also all its R403 near remainder. The far complement is retained explicitly below. This does not claim the full weak-type root bound.

## 2. Proof of the full-f cancellation and Minkowski bound

Since m_w≥q_-R_w^n≥q_-a^n, the strict inequality m_w<m_A/K is impossible when R_*≤a, including equality. Suppose R_*>a. Every live small receiver has R_w<R_*, by the same strict cutoff and q-band lower bound.

Nonnegative Tonelli gives the exact identity

 ∫π_A(dz)1_{z−y∈D}Z_A(z)
 = (1/m_A)∫_{m_w<m_A/K}
       f(Q_A∩Q_w∩(y+D))/m_w dw.                        (3)

The numerator uses the original full f. It is at most f(Q_w)=m_w. Moreover it is zero if Q_w does not meet y+D. If the intersection is nonempty, a point z in it gives

 w∈z+Q_{R_w}(0)⊂y+D+Q_{R_*}(0).

Consequently the integrand in (3) is bounded by the indicator of this actual center domain, divided by m_A. Integrate with respect to the original dw, then enlarge this positive center domain to all of y+D+Q_{R_*}(0). This proves (1). Compactness of D makes its Minkowski sum compact and Lebesgue measurable; no arbitrary set-valued measurability claim is needed. All source measures and actual kernels in (3) are measurable by the original field assumptions.

For D=[−d,d]^n the volume is (R_*+2d)^n. Since m_A=Kq_-R_*^n and R_*≥a, this gives (2). More generally, for a compact rectangular neighborhood D=∏_j[−d_j,d_j], d_j≥0,

 ∫π_A(dz)1_{z−y∈D}Z_A(z)
 ≤ (1/(q_-K))∏_j(1+2d_j/a).                            (4)

Degenerate boxes cause no difficulty: their source integral may vanish because f is a Lebesgue density, while the upper bound remains valid. No assumption about independence of source coordinates is made. The product in (4) is a CENTER volume, not a source probability.

The proof does not integrate the selected radius as an independent variable. R_* is a bound derived from the ACTUAL small mass condition; each selected R_w remains fixed. It does not assume an upper density for f, a fixed-radius boundary strip estimate, or that a new w inherits original history. The same argument would fail at the cancellation step if the denominator m_w were unrelated to the full mass of its own Q_w.

## 3. Complete bilateral moment bound

The native center envelope gives, for every source y,

 Z_A(y)≤∫_E c_w(y)dw/m_w
 ≤ (1/q_-)∫_{2||w−y||∞≤b}
              dw/max(a,2||w−y||∞)^n
 = A_n/q_-.                                            (5)

The last equality follows from cube-shell volume r^n: the inner cube contributes 1 and the shells contribute n log(b/a). It holds for any measurable radius selector in [a,b].

For D=[−d,d]^n define the genuine parent moment

 J_D=∫σ(dA)∫π_A(dy)π_A(dz)1_{z−y∈D}
           [Z_A(y)−C_A(y,z)][Z_A(z)−C_A(y,z)].

Its nonnegative integrand is at most 1_D Z_A(y)Z_A(z). Using (2) for the z integral at each fixed A,y, followed by (5), yields

 J_D≤ [A_n/(q_-²K)](1+2d/a)^n X_q.                     (6)

For rectangular D the factor (1+2d/a)^n is replaced by ∏_j(1+2d_j/a). This is a bound on the ENTIRE source-integrated near bilateral moment, not only equal or shared failure coordinates. Its center proof keeps the full small-receiver mass in (3) before making any geometric enlargement. It does not rely on the stronger R401 receiver-pair relaxation where the parent matching constraint was lost.

The more precise compact-D form of (6) is

 J_D≤(A_n/q_-)∫_{R_*>a}σ(dA)
                        |D+Q_{R_*}(0)|/m_A.            (7)

For a compact D define the finite geometric number V(D)=sup_{r≥a}|D+Q_r(0)|/r^n. Then (7) is at most A_n V(D)X_q/(q_-²K). Accordingly the uniform general-D fee used below is ν_n(D)=ε_0² A_n B_L V(D)/(K s²); an actual-parent average from (7) may give a smaller fee. For a box, V(D) is exactly the product in (4). Any further shape-specific volume estimate must be proved separately.

## 4. Payment of the original complete near costs

Let H_ext and H_small denote the exact R398 high-rank bills, and use their R400 soft-complement factors (1−φ_u(y,z)), (1−ψ_v(y,z)). Define N_D to be their sum restricted to z−y∈D. The old y, actual endpoints, all Γ_i/k_i/ℓ_i marks and each b_i(z) are kept. Thus

 R400=N_D+F_D,
 F_D=H_ext^[(1−φ)1_{z−y∉D}]
                  +H_small^[(1−ψ)1_{z−y∉D}].           (8)

This is an exact nonnegative split, before any optional face or inner selection.

On the live external support Z_u(y)>2h, Z_u(z)>Lh, while on the small-end support Z_v(y)>(2−ε_0)h, Z_v(z)>(L−ε_0)h. The already proved soft inequality therefore gives

 1−φ_u≤[Z_u(y)−C_u][Z_u(z)−C_u]/(2Lh²),
 1−ψ_v≤[Z_v(y)−C_v][Z_v(z)−C_v]
                          /[(2−ε_0)(L−ε_0)h²].         (9)

For C≥h the left side is zero, and (9) remains a positive upper bound. For C<h, (9) uses both original ranks; no such gate is assigned to w.

Insert (9) into the original integrals. For the external bill retain

 dΓ_i(y,u,v)=σ(du)π_u(dy)ℓ_i(u,y,dv), ℓ_i(u,y,E)≤β,

and for the small-end bill retain k_i(v,y)≤C_col. After imposing the original bounds, sum b_i at the SAME new z, using Σ_i b_i(z)≤1. Other positive restrictions may be dropped only for this upper bound. Then (6) gives

 N_D≤(B_L/h²)J_D≤ν_n(d)X_q,
 ν_n(d)=ε_0² A_n B_L (1+2d/a)^n/[K(1+√n)²].             (10)

For boxes use the product in (4). This is a full near-source payment, without a stage count, a price per witness or a new W term. The full f cancellation occurs before taking the remaining parent posterior average; it is not a source-density substitution.

The original external E_uv/Z_u representation is also unchanged. For each old (y,u,v), take g(y,z)=(1−φ_u(y,z))1_{z−y∈D} or its far counterpart in

 π_u[b_i(1−c_v)1_{Z_u>Lh}g(y,·)]
 =E_uv∫b_i(z)g(y,z)1_{Z_u(z)>Lh}ν_uv^z(dz)/Z_u(z).

The proof above bounds the equivalent posterior expression. It never deletes this normalization from an equality or moves an old-y condition to the new source.

## 5. Root-scale neighborhoods and complete costs

Since b/a≤2,

 A_n≤1+n log2≤(1+√n)²,
 B_L≤S/L.

For an arbitrary fixed t with 1≤t<K, choose

 d_t=(a/2)[(K/t)^(1/n)−1].                              (11)

Then (10) pays ALL ||y−z||∞≤d_t with

 ν_n(d_t)=ε_0² A_n B_L/[t(1+√n)²]
                 ≤ε_0² S/(Lt)≤S/(4Lt).                (12)

The displayed d_t is exact; for fixed t and large n it is of order a/(2√n). Thus this is not a tiny collar fraction obtained by another label. For any prescribed δ_near>0, t≥max(1,S/(4Lδ_near)) ensures the near fee ≤δ_near, provided K>t. The complementary finitely many dimensions, once the parameters have uniform dimension bounds, use the existing direct core estimate rather than pretending d_t positive. No change to h or the original χ is made.

Alternatively, any fixed 0<c<1/2 gives the explicit root-scale region d=c a/√n, with

 (1+2d/a)^n/K≤exp[−(1−2c)√n],
 ν_n(d)≤ε_0² S exp[−(1−2c)√n]/L.                        (13)

This follows from log(1+x)≤x, with no asymptotic remainder. In particular d=a/(4√n) gives exponential exp(−√n/2). The proof works at the original R403 d0=ζa/n as well, where ν_n≤ε_0² A_n B_L e^(2ζ)/(Ks²). A new choice of neighborhood always changes its exact far complement in (8); it does not silently retain a previously smaller far region.

The new root-scale neighborhood may be specified by the more general rectangular budget

 Σ_j log(1+2d_j/a)≤√n−log t.

This is simply (4),(10); no further shape result is claimed here.

Return to the R400 mother ledger, replacing ALL optional R402/R403 face/inner fees by (10), not adding them. With ζ_n=2(λ/q_-)Sε_0/[Ks] and P_L=λh[β(L+ε_0)+C_col L], n≥9 gives

 G0≤16F_D+16(ζ_n+ν_n(D))X_q+16(s+P_L)W,
 BH≤32F_D+[E387+32(ζ_n+ν_n(D))]X_q
                          +[S390+40s+32P_L]W,
 entrance≤Λ{8λHW+2d_eff A_entrance,n W_ν/H+64F_D
       +[2E387+64(ζ_n+ν_n(D))]X_q+[2S390+80s+64P_L]W}.

Λ=128/119. A_entrance,n denotes the original entrance constant; it is unchanged and is not redefined in this round. The occupation constant remains A_n=1+n log(b/a). Only the single R400 slot is replaced. Old negative capture credit is not reused. Changing L still requires the COMPLETE R398 high/low repartition with the corresponding P_L; taking t or d at the same L does not change that mother split. The W price is the displayed original P_L and other inherited terms, with their ε_0 and cutoff dependence intact. Any prescribed new entrance absorption requires an actual allocation for 64Λν_n(D), alongside the already retained ζ_n and old terms.

For low dimensions the existing direct alternative is G0≤S(1+N log2)W/2; it replaces the whole core slot where invoked and is not added a second time. For dimension-dependent parameters without uniform bounds, no fixed N is asserted.

Conclusion: the complete near-source remainder, including both collars, all disjoint failure sets and the R403 soft weight, is paid by (10). The sole new spatial complement is F_D with z−y outside the chosen neighborhood. This does not pay that far integral, nor other inherited entrance/global aggregation requirements. It is a new general matching-and-center-volume estimate, not closure of the original root-order theorem.

## 6. Actual local mathematical checks

Executed locally:

    python3 /tmp/r404_geometry_check.py
    PASS {'native_matching_integral': 45,
          'finite_full_source_cancellation': 486,
          'marked_stage_bound': 24,
          'parameter_price': 192} total 747

All arithmetic is Python Fraction. The native checks are exact real-center integrals: f=1 on a sufficiently large bounded box, parent cube of side 2 at zero, small witness cubes of side 1 with centers in [−1/2,1/2]^n. The selected parent point can be assigned side 2 without changing the witness Lebesgue integral. For d≤1/2 the exact value at y=0 is (2d−d²)^n/2^n. The script chooses rational R_* in (1,2) and K=(2/R_*)^n, so all witness masses satisfy the strict cutoff and the exact volume bound (1) is rational. This diagnoses the theorem's arbitrary-K local lemma; it is not a full historical core fixture or an assertion that K has its original exp(√n) value in those examples.

The finite full-source checks recompute every receiver mass from the SAME rational source measure, verify (3) and the center-domain containment, and make no Lebesgue volume claim for arbitrary atomic receiver weights. Marked-stage checks retain one new source across the stage sum. Parameter checks use rational squares n and an explicit upper bound log2<7/10; the original exponential choice and root-radius bound are proved analytically in (11)–(13), not fitted numerically.

Status: new full-neighborhood payment established with exact residual and ledger. No further route is developed after this result.
