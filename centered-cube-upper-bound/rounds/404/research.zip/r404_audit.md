# R404 independent audit — FINAL PASS

FINAL PASS for the full-matching local source-average theorem, its compact-neighborhood/Minkowski extension, complete two-end source-neighborhood payment and exact inherited ledger substitution. No budget for the final simultaneous-far norm region or general closure is certified. Only this audit file was edited.

Only this file is edited. This first contract/prefilter and the later specific candidate proofs were independently derived before reading new R404 author proofs. They distinguish inherited facts, newly screened actual receipts and still-unproved general closure.

## 1. Accurate entering remainder and the prefilter

The R403 remaining near law keeps the SAME normalized exclusive witnesses Q_y tensor Q_z, nonempty DISJOINT complete failure sets, both ACTUAL radius-bin collar events, and exact surviving amplitude (1-|S_w||S_t|/n)_+. Its far source-pair law has NONE of those extra near-only restrictions. Both still retain their original full-f source, endpoint, strict far mass, low common capture, high individual ranks, physical clock, stage and external E_uv/Z_u labels. The two witnesses are not new qualified transitions.

Full matching genuinely gives pi_A(Q_w)<=m_w/m_A<1/K for every actual far-smaller w. It also gives f(Q_A outside Q_w)>(1-1/K)m_A, with no nesting assumption needed. These facts alone do not allocate those large outside masses without repetition across many w,t. High exclusive occupation is a lower bound; it supplies no upper bound for a shared source budget. Similarly, the known unpartitioned face capacities leave a sum over many cross-coordinate receiver pairs, while a small count on each pair does not itself bound how many such pairs use the same source. The pair-tail F_n is valid geometry but not by itself the missing full weighted source integral. No thin collar-volume cap on arbitrary f is licensed.

One precise sufficient, but stronger-than-necessary, interface would bound the raw bilateral moment with the FULL R403 far/near residual tag by C n Xq/q_-^2. The inherited soft-complement argument would then pay it through B_L/h^2, B_L=beta/(2L)+C_col/[(2-epsilon0)(L-epsilon0)]. A source-budget alternative must retain the same actual weights and supply a joint non-repeating allocation, not privately choose source clusters or restart a different plan. This interface is not stated as necessary, minimal in an optimization sense or previously proved progress. The later candidate below supplies an actual localized consequence without pretending that full moment bound is known.

The original entrance on this residual has factor 64Lambda. Any new actual receipt must be placed there with all previous source/outer fees intact; no reference optimization, low-rank witness or negative square may be deducted again. A changed L replaces the complete mother-split P_L once; changing old f/h/clock qualifications and transplanting earlier coverage would be invalid.

## 2. New independently screened source-averaged local occupation

Fix an original actual endpoint A, M=m_A/K and R_*=(M/q_-)^(1/n). For any fixed y and d>=0, define Z_A(z)=integral_{m_t<M}c_t(z)mu(dt). Positive Tonelli and full matching give the exact identity

    integral pi_A(dz)1_{||z-y||infinity<=d} Z_A(z)
      =(1/m_A) integral_{m_t<M}
            f(Q_A intersect Q_t intersect B_infinity(y,d))/m_t dt.

Every summand is at most 1 before the factor 1/m_A, since its numerator is at most f(Q_t)=m_t. A positive summand requires Q_t to intersect B_infinity(y,d). Actual matching and strict mass imply R_t<R_*. Thus these actual centers t lie in a cube of side R_*+2d centered at y. Consequently the displayed integral is at most

    (R_*+2d)^n/m_A.

If no far-smaller receiver exists, Z_A is identically zero and the bound is trivial. Otherwise strict m_t<M and R_t>=a imply R_*>a, so

    (R_*+2d)^n/m_A
      =(1+2d/R_*)^n/(q_-K)
      <=(1+2d/a)^n/(q_-K).

This is a new use of the SAME full matching, not an upper bound for f by volume. The numerator is cancelled against its OWN receiver mass before estimating center volume. No lambda is lost in that cancellation. It is valid for arbitrary L1 concentration, strict mass atoms and measurable selected radii. The positive integration is justified independently of any source-coordinate independence or receiver quadrature. The d=0 bound is merely an envelope; L1 source has zero mass at a singleton.

Since Z_A(y)<=A_n/q_- with A_n=1+n log(b/a), and both exclusive factors are bounded by the corresponding Z values, the complete source-near bilateral moment satisfies

    J_ex,near(d)<=A_n(1+2d/a)^n Xq/(q_-^2 K).

Keeping the actual soft/high-rank supports until applying the inherited endpoint capacities therefore pays the WHOLE R400 source-near bill at price

    epsilon0^2 [A_n/(1+sqrt(n))^2] B_L
                 [(1+2d/a)^n/K] Xq.

For a chosen scalar t0 with 1<=t0<K, d=a[(K/t0)^(1/n)-1]/2 makes the last ratio exactly 1/t0. In the octave A_n<=(1+sqrt(n))^2. This is an actual positive source-region receipt, not a budget for the entire R403 residual. To adopt it, rebuild from the unchanged R400 mother bill and withdraw the previous 402/403 near-piece charges and tags rather than stacking both versions. The new source-far complement retains the original R400 labels, without pretending it still has near-only disjoint/collar/count restrictions.

## 3. Minkowski strengthening, independently screened

For a fixed compact region D, the same Tonelli argument restricts a positive far child center to y+D+Q_(R_*). Hence

    integral pi_A(dz)1_{z-y in D} Z_A(z)
      <= |D+Q_(R_*)|/m_A.

Convexity is not needed for this containment; it is sufficient for the particular geometric descriptions below. No arbitrary y-dependent source measure or density cap is introduced. A nonconvex union can be handled by one actual union indicator and the sum of the separate volume upper bounds.

For the l1 ball B_1(r), its exact cube Minkowski volume is

    |Q_(R_*)+B_1(r)|/R_*^n
      =sum_(k=0)^n binom(n,k)(2r/R_*)^k/k!.

Partition centers by exactly k coordinates lying outside the base cube. There are binom(n,k) coordinate choices and 2^k signs; the outside distances form a k-simplex of volume r^k/k!, while the other coordinates contribute R_*^(n-k). Boundaries are ordinary Lebesgue null sets for this volume calculation, not variable-selector faces discarded at fixed sources.

For r=rho a and a<R_*, the ratio is at most

    sum_(k=0)^n (2rho n)^k/(k!)^2
      <=exp(2sqrt(2rho n)).

The last inequality follows directly because exp(sqrt(x))exp(sqrt(x)) has a positive double series containing all diagonal terms x^k/(k!)^2. No asymptotic estimate is used.

Let 0<theta<=1 be fixed and take

    D_infinity={||z-y||infinity<=a[exp(theta/sqrt(n))-1]/2},
    D_1={||z-y||1<=theta^2 a/8}.

The cube Minkowski ratio is at most exp(theta sqrt(n)); the l1-ball ratio has the same bound by rho=theta^2/8. Thus the SINGLE source-union event has averaged rank at most

    2exp(-(1-theta)sqrt(n))/q_-.

The factor 2 is a volume-union majorant, not two payments of the same actual source pair. It follows that

    J_ex,union<=2A_n exp(-(1-theta)sqrt(n))Xq/q_-^2,

and its whole actual R400 cost is at most

    Delta404 Xq,
    Delta404=2epsilon0^2 A_n/(1+sqrt(n))^2
                       B_L exp(-(1-theta)sqrt(n))
      <=(d_face/2)exp(-(1-theta)sqrt(n))
      <=S exp(-(1-theta)sqrt(n))/(2L).

Here d_face=4epsilon0^2 B_L is only convenient existing coefficient notation, not a second face charge. No new W fee is introduced at a fixed current L; all P_L dependence remains. The exact remaining source region exceeds BOTH displayed norm thresholds and retains every original R400 mark. This does not close that far region.

For theta=1 and the high-dimensional n>=9 contract, the infinity cube contains the prior zeta a/n cube (zeta<=1), so this can genuinely pay the entire earlier near source region and more, before any failure/collar restrictions. For theta<1 no free inclusion of previously covered sets is asserted. In every version the complete alternative R400 ledger must be rebuilt once; the original 64Lambda multiplier and available absorption balance remain mandatory.

## Actual bounded arithmetic

Reviewer ran 32 Fraction scale/unit checks for the conditional raw-moment interface on square dimensions, confirming n/(q_-^2h^2)=epsilon0^2 n/(1+sqrt(n))^2 and its bound. This checks units, not any unknown geometric budget. Reviewer also ran 96 Fraction Minkowski-coefficient and diagonal-series-majorant checks for n=1 through 8 and rational radii/ratios, including the exact interval and two-dimensional polynomials. The exponential bound itself is the positive-series proof above, not a floating-point or fitted inference. No separate reviewer test files were saved, and these checks must not be pooled with later author/parent evidence.

Independent screens PASS for the new local and Minkowski receipts. The final proof and report review below now completes the audit; general closure is not established.

- `/tmp/r403_geometry.md`: `794dc9667d94ba78f3203c52fb4e023311831758c2ed4f4a68fdd025dea79932`
- `/tmp/r403_main.md`: `fb3af092319eb219ddce7e60068b20834298a72b7ce49988d6a02f4867911180`
- `/tmp/r402_main.md`: `f9a996b77ef3cac5f71f1dc6260e50b031dd8e52c8c16e0af3423c2bc63ec93f`


## Final author proof: complete matching, not a source-density bound

Read frozen r404_geometry.md in full and the final edits defining V(D) and separating A_entrance,n from the new occupancy A_n. The exact local source-average identity (3) agrees with the independent proof above. Its cancellation f(Q_A intersect Q_w intersect(y+D))/m_w<=1 uses the SAME complete matched m_w. Only after that cancellation is the actual center set enlarged. It remains valid for arbitrary concentrated L1 f, arbitrary selected radii and strict mass atoms, with no lambda loss.

A positive summand has R_w<R_*, so the center lies in y+D+Q_(R_*). Compact D supplies ordinary measurability; no unproved measurable selection or arbitrary set-valued assertion is needed. If R_*<=a, including equality, the strict mass gate is genuinely empty. This argument is independent of whether an actual selector has a positive-measure radius plateau. The new witnesses are not assigned original clock/history eligibility.

The pointwise Z_A(y)<=A_n/q_- estimate is the actual-center integral of max(a,2||w-y||infinity)^(-n) on the b cube. Combining it with the local average proves the entire bilateral source-neighborhood moment, not just shared-coordinate or inner-tag subpieces. The general compact-set form (7) and finite V(D)=sup_(r>=a)|D+Q_r|/r^n are valid; compactness bounds this supremum by an enclosing finite box. For rectangles the supremum is the stated product attained at r=a. The uniform general-D fee is precisely epsilon0^2 A_n B_L V(D)/(K s^2).

The original actual external and small-end sourcewise beta/C_col bounds, old-y labels and global sum b_i(z)<=1 transfer this moment bound to the complete original R400 neighborhood cost exactly as displayed. There is no stage-count price, changed target/source law, second negative-square use or free erasure of the old E_uv/Z_u conditional normalization. The full new-source integral remains the original pi_A witness of the switching measure.

## Parent union theorem and complete report review

Read final r404_main.md and readme in full. The parent separately proves the l1-body Minkowski formula; the author compact-D theorem is its legitimate input, without falsely attributing that shape proof to the attachment. Coordinate-outside-cube/simplex decomposition gives the exact polynomial volume. The diagonal-positive-double-series domination proves its exponential estimate in every dimension. Both this estimate and the infinity-cube estimate hold uniformly for the actual R_*>a. The single UNION source event is paid once, with the sum of its two volume envelopes only used as a majorant.

It follows that the full R400 union neighborhood is priced by

    Delta404(theta)=2epsilon0^2 A_n B_L exp(-(1-theta)sqrt(n))/s^2
       <=(d_face/2)exp(-(1-theta)sqrt(n))
       <=S exp(-(1-theta)sqrt(n))/(2L).

The complete parent main uses theta=1. For the master high-dimensional n>=9 contract, its infinity halfwidth is at least a/(2sqrt(n))>=a/n>=zeta a/n. Therefore the entire old R403 near source region, including all its surviving double collars and count weight, is paid; no prior near-only tag survives on the new far region. The added l1 region is a genuine compact neighborhood, not the measure-zero class of vectors with exactly sparse coordinates.

The exact complement is the original R400 measure restricted simultaneously to

    ||z-y||infinity>a(exp(1/sqrt(n))-1)/2,
    ||z-y||1>a/8.

All original old/new source, endpoint, stage, high-rank, low-common-soft, clock and history labels remain; the previous near-only failure/collar/count restrictions are NOT transplanted to this far law. From the SAME R400 mother field this new remainder is <=old R403 at n>=9, and Delta404<=d_face/2<=Delta403. Thus the stated same-parameter comparison of both residual and displayed local fee is valid, not an inference from residual size alone. Different parameters must still be compared through complete ledgers.

The parent explicitly withdraws ALL optional R402/R403 near-piece fees and replaces them once by Delta404, while retaining the prior common-capture chi_n once. Its 16/32/64 factors in core/BH/entrance are correct. P_L at the current L, all S390/E387 terms and original outer fees remain in full. A_entrance,n denotes the UNCHANGED old entry constant; it is not substituted by this round's 1+n log(b/a). A changed L still requires the complete mother high/low repartition. Source-price root-order statements preserve their original epsilon0 and cutoff dependencies. Actual global balance must cover 64Lambda Delta404; the final report does not presume that all old fees are absorbable. The direct low-dimensional core bound is an alternative, not a second charge.

## Auxiliary all-coordinate envelope: valid separate tool, not main premise

Read final r404_aux.md and its full check script. Its actual pointwise selector maximum (5) is correct: the least allowed capturing radius r_*=max(a,rho_y) realizes the exclusive event when r_*<=b and r_*<rho_z, and otherwise no allowed radius has that event. The shell trace correctly counts one face for a positive displacement coordinate and two for an exactly zero coordinate. With k positive coordinates, its expression is [(2n-k)P+rP']/(2r); integrating the continuous absolutely continuous P gives the stated formula including both endpoint terms. The nonnegative form, limits, fixed-radius formula, sharp fixed-pair statement and simultaneous opposite-region selector construction follow. Sharpness is only a fixed source-pair envelope, not a single field maximizing every source pair or an original-core extremizer.

The final strict mass-cut treatment is now correct: ONLY M<=q_-a^n is declared empty. If M>q_-a^n and b=a, the allowed fixed-radius bound C_(a,a)=1-P(a) must remain. A b_M endpoint is included solely as a positive enlargement; an actual selected radius can equal it on a positive center set, and no such event is dropped as null. The analogous parent-cut C_A convention in the original-cost interface has been corrected accordingly.

The optional near-vector bound and original double-rank majorant keep the actual source law and old marks. Its currently evaluated general price is still dimension-linear and is not entered into the main theorem. For the full L1 posterior pair, k=n almost everywhere; exact coordinate zeros cannot be called a typical source-mass saving. The main source-averaged matching theorem does not rely on this auxiliary pointwise supremum, and nothing in the auxiliary is reused as an additional payment.

## Actual script executions and scope

Reviewer read and actually ran all three delivered Python scripts to completion:

1. r404_geometry_check.py: 747 Fraction grouped checks =45 native_matching_integral +486 finite_full_source_cancellation +24 marked_stage_bound +192 parameter_price. The native fixed-witness/parent-point model evaluates genuine continuous center integrals at arbitrary rational K, not the original exp(sqrt(n)) with all historical gates. Finite receiver weights verify matching cancellation but deliberately make no Lebesgue volume claim. The stage tests keep the same new source across the cumulative sum.
2. r404_body_check.py: 40 exact Minkowski coefficient checks and 45 exact conservative-fee/old-near-containment checks. The exponential theorem itself is the positive-series proof; finite arithmetic does not establish it by fitting.
3. FINAL r404_aux_check.py: 2001 mixed checks, comprising 1491 Fraction checks (1386 exact geometry,12 polynomial,90 mass cuts,3 fixed-radius mass-boundary cases), six ordinary-double midpoint shell comparisons and 504 ordinary Decimal80/120 comparisons. The earlier 1998 version is superseded, not added. The saved midpoint maximum absolute error is 9.872755946105372e-10. Decimal self-consistency is not an outward interval certificate.

Parent/reviewer repetitions are the same cases, not additional independent experiments. The preliminary reviewer-only 32 and 96 checks above are separate from the delivered script counts. These cases do not realize all original quality, synchronized high-rank or historical core assumptions. The all-class result is the analytic full-f and actual-center proof, not the check counts.

Read the MATLAB matching script and saved output, but did not independently rerun MATLAB in this review. Its formulas correctly represent continuous f=1_[0,2], parent mass2 and actual side1 receiver centers parametrized by their overlap mass m in [qmin,2/e). The displayed z-rank logs and the alternative receiver integral are the two actual Tonelli orders; their factor 1/2 is the true parent posterior normalization. The saved parent run has 140 ordinary-double cases (4/16/120), maximum two-order gap 2.2204460492503131e-16. This is neither an interval proof nor a synchronized original-quality/high-history fixture. Its reporting in main/readme is appropriately limited.

## Final byte bindings

The following SHA-256 values bind the exact reviewed files. Subsequent changes require updating this audit. The standard parent auxiliary result has the same final 2001-check content as the author's underscore-named result; only the standard archive path is bound below.

- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
- `/tmp/r404_readme.md`: `675193ed434dd3ef2e4f9e2edd31ab9806434d1c2ea05f5ea6bb63bc37d8f57c`
- `/tmp/r404_geometry.md`: `40c6e289b5975657334317f985a9fa4f084a8cf2d45ce935975ac0f99316d1bf`
- `/tmp/r404_geometry_check.py`: `bd1275d18cc7f6b8bfb38025769b2dfb341e4147c62b4b409b621d68a58f3ded`
- `/tmp/r404_geometry.result.txt`: `022b0c1ced2262f25508783d9b225a5b2237426f1035e33a8ca5e8e290ba7cdf`
- `/tmp/r404_aux.md`: `33c15edf8f66c6246046fb11be2e4db663096bbfa53ada1656d14623298a9866`
- `/tmp/r404_aux_check.py`: `74bd1a60a71eaf150a179b9c2f88c925473dbdaa1eb5f70a091aa24ebdc0d1c9`
- `/tmp/r404_aux.result.txt`: `b89a25b12718718197a9ccea0976e99539d5044d711b5cdff1286aff15cf5db7`
- `/tmp/r404_body_check.py`: `5d72dd8ab7558947c32b06e10fa26931471341b2c452c76ceb475b079edf0372`
- `/tmp/r404_body.result.txt`: `dcafa841dae22689e89321a9b5871852f782a9fc97043b42fa809026492a178e`
- `/tmp/r404_matching_check.m`: `9305100b39cd77443c1cdd90fabbc76af340f087d2f3f7450cdd54c38f87f517`
- `/tmp/r404_matching.result.txt`: `44f0726422a9c9219d205c49dcd1a622336530b93f8cdf544016341cf7a42d8e`
- `/tmp/r400_main.md`: `1e0fb7906923a1442a5b1988407e41e400810f9a6748b571a32904181e90d304`
- `/tmp/r403_main.md`: `fb3af092319eb219ddce7e60068b20834298a72b7ce49988d6a02f4867911180`


Inherited complete reductions are bound as context, not reaudited wholesale. FINAL PASS within the stated actual neighborhood-payment and reporting scope. The joint far norm region and global closure remain unresolved. Freeze and stop; no additional search or duplicated numerical pipeline is part of this audit.
