#!/usr/bin/env python3
"""R317 exact finite rank/quota identities, standard library only."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
counts=Counter(); diagnostics=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def fixtures():
 return {
 'ordinary':([1,3,5,8],[F(1,4),1,2,3],1,4),
 'no_gate':([0,1,2,3],[0,F(1,4),1,2],1,4),
 'a_start':([5,6,8,9],[2,3,4,5],1,4),
 'overshoot':([0,1,21,30],[0,F(1,2),10,14],1,4),
 'gate_at_b':([1,2,3,10],[F(1,2),1,2,8],1,4),
 'gate_exact':([1,4,5,8],[F(1,4),2,3,4],1,4),
 'zero_increment':([1,4,4,8],[F(1,2),F(3,2),F(3,2),3],1,4),
 'H_equals_d':([0,1,4,8],[0,F(1,2),3,5],1,1),
 'same_atom_cross_both':([0,1,21,21],[0,F(1,2),12,12],1,4)}
def run(name,n,scale):
 js,aas,d,H=fixtures()[name];J=[scale*F(x) for x in js];A=[scale*F(x) for x in aas];d*=scale;H*=scale
 radii=[F(1),F(4,3),F(3,2),F(2)];R=[r**(-n) for r in radii];ell=[R[i]-(R[i+1] if i+1<len(R) else 0) for i in range(4)]
 C=lambda a:min(d,a);D=lambda a:min(H,a);g=lambda a:C(a)-(d/H)*D(a)
 for i in range(4):
  pj=J[i-1] if i else F(0);pa=A[i-1] if i else F(0)
  ck('increment_contract',0<=A[i]-pa<=J[i]-pj)
  ck('tent_nonnegative',g(A[i])>=0)
 ck('terminal_layer_mass',sum(ell)==R[0] and ell[-1]==R[-1])
 direct=sum((ell[i]*g(A[i]) for i in range(4) if J[i]>=H),F(0))
 gated=[g(A[i]) if J[i]>=H else F(0) for i in range(4)]
 sbp=sum((R[i]*(gated[i]-(gated[i-1] if i else 0)) for i in range(4)),F(0))
 ck('gated_summation_by_parts',direct==sbp)
 crossing=next((i for i in range(4) if J[i]>=H),None)
 low=sum((ell[i]*C(A[i]) for i in range(4) if J[i]<H),F(0))
 if crossing is None:
  early=sum((R[i]*(C(A[i])-C(A[i-1] if i else F(0))) for i in range(4)),F(0))
  ck('never_cross_early_identity',low==early)
  ck('never_cross_zero_high',direct==0)
  diagnostics['never_cross']+=1
  return dict(name=name,n=n,scale=scale,J=J,A=A,d=d,H=H,crossing=None,high=direct,O_low=low,E_early=early)
 k=crossing;pj=J[k-1] if k else F(0);pa=A[k-1] if k else F(0);h=J[k]-pj;theta=(H-pj)/h;AH=pa+theta*(A[k]-pa)
 ck('rank_fraction',0<theta<=1)
 ck('rank_capture',0<=AH<=H)
 init=R[k]*g(AH)
 # Keep the entire rest of the crossing atom; no source-specific reordering.
 post_cross=R[k]*((C(A[k])-C(AH))-(d/H)*(D(A[k])-D(AH)))
 post_later=sum((R[i]*((C(A[i])-C(A[i-1]))-(d/H)*(D(A[i])-D(A[i-1]))) for i in range(k+1,4)),F(0))
 ck('rank_initializer_post_identity',direct==init+post_cross+post_later)
 atom_sbp=R[k]*g(A[k])+sum((R[i]*(g(A[i])-g(A[i-1])) for i in range(k+1,4)),F(0))
 ck('crossing_atom_sbp',direct==atom_sbp)
 early=sum((R[i]*(C(A[i])-C(A[i-1] if i else F(0))) for i in range(k)),F(0))+R[k]*(C(AH)-C(pa))
 ck('early_initializer_identity',low+init==early-(d/H)*R[k]*AH)
 ck('early_quota_nonnegative',early>=0)
 ck('initializer_nonnegative',init>=0)
 diagnostics['negative_cross_post']+=post_cross<0
 diagnostics['negative_later_post']+=post_later<0
 diagnostics['cross_at_b']+=k==3
 diagnostics['cross_at_a']+=k==0
 diagnostics['exact_H_atom']+=J[k]==H
 diagnostics['large_overshoot']+=h>=4*H
 diagnostics['same_atom_cross_d_H']+=pa<d and A[k]>H
 return dict(name=name,n=n,scale=scale,J=J,A=A,d=d,H=H,crossing=k,theta=theta,AH=AH,high=direct,initializer=init,post_cross=post_cross,post_later=post_later,O_low=low,E_early=early,early_subtraction=(d/H)*R[k]*AH)
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [serial(v) for v in x]
 return x

def main():
 all_names=list(fixtures());initial=['ordinary','no_gate','a_start'];stress=[n for n in all_names if n not in initial]
 specs=[('initial',[1,2],[F(1)],initial),('boundary',[1,4],[F(1)],stress),('expanded',[8,16,64,256],[F(1,1024),F(1024)],all_names)]
 reports=[];stages=[]
 for stage,ns,scales,names in specs:
  before=sum(counts.values());m=0
  for n in ns:
   for scale in scales:
    for name in names:reports.append(run(name,n,scale));m+=1
  stages.append(dict(stage=stage,models=m,checks=sum(counts.values())-before,dimensions=ns))
 result=dict(status='PASS',arithmetic='exact Fraction',scope='Finite radius-menu algebra only, not continuous-measure or original-selector certification.',provenance='Independently derived gated summation by parts; common-rank initializer formula confirmed with joint_mass before execution. Fixed fixtures preregistered before execution.',check_counts=dict(counts),total_checks=sum(counts.values()),diagnostics=dict(diagnostics),stages=stages,radii=[F(1),F(4,3),F(3,2),F(2)],models=reports)
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps(serial({k:result[k] for k in ['status','check_counts','total_checks','diagnostics','stages']}),sort_keys=True))
if __name__=='__main__':main()
