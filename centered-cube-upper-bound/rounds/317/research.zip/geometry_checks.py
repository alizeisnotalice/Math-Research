from fractions import Fraction as F
from itertools import product
ct={'geometry':0,'projection':0,'refinement':0,'strict_fixture':0}
centers=[-F(19,20),-F(7,10),F(7,10),F(19,20)]
cells=[(x-F(1,100),x+F(1,100)) for x in centers]
yboxes=[(-F(1,200)-F(1,2000),-F(1,200)+F(1,2000)),
        (F(1,200)-F(1,2000),F(1,200)+F(1,2000))]
zbox=(-F(1,1000),F(1,1000));R=F(9,5);eta=F(3,5);h=F(1,100)
for cell,ybox in product(cells,yboxes):
 assert max(abs(x-y) for x,y in product(cell,ybox))<1;ct['geometry']+=1
capture=[0,1,1,0]
for cell,cap in zip(cells,capture):
 distances=[abs(x-z) for x,z in product(cell,zbox)]
 if cap:
  assert max(distances)<R/2 and min(distances)>eta*R/2
 else:assert min(distances)>R/2
 ct['geometry']+=1
for i,j in product((1,2),(0,3)):
 assert min(abs(x-w) for x,w in product(cells[i],cells[j]))>h
 ct['geometry']+=1
assert F(3)<=4*F(4,3) and R>1/eta and R<F(2)-2*h;ct['geometry']+=1

def check(U,vol,c,d,H):
 J=[sum(u*v for u,v in zip(row,vol)) for row in U]
 A=[sum(u*v*ci for u,v,ci in zip(row,vol,c)) for row in U]
 vv=[];pp=[];gg=[]
 for a,j in zip(A,J):
  active=j>=H and 0<a<H
  p=a/j if j else F(0);g=min(d,a)-d*a/H if active else F(0)
  vv.append(g/(a*(1-p)) if active else F(0));pp.append(p);gg.append(g)
 rho=[sum(v*row[i] for v,row in zip(vv,U)) for i in range(len(vol))]
 field=[sum(v*p*row[i] for v,p,row in zip(vv,pp,U)) for i in range(len(vol))]
 Cv=sum(v*a for v,a in zip(vv,A))
 E=sum(v*a*p for v,a,p in zip(vv,A,pp))
 fine=sum(m*b*b/r for m,b,r in zip(vol,field,rho) if r)
 coarse=(sum(m*b for m,b in zip(vol,field))**2/sum(m*r for m,r in zip(vol,rho))
         if sum(m*r for m,r in zip(vol,rho)) else F(0))
 assert 0<=coarse<=fine<=E<=Cv and sum(gg)==Cv-E
 ct['projection']+=1;ct['refinement']+=1
 active=[i for i,(a,j) in enumerate(zip(A,J)) if j>=H and 0<a<H]
 C=sum(A[i] for i in active);m=F(len(active))
 census=min(C,d*m)-d*C/H
 assert sum(gg)<=min(census,Cv-fine)
 return sum(gg),census,Cv-fine
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
assert all(sum(row[i] for row in U)<=1 for i in range(4))
res=check(U,[F(1,50)]*4,capture,F(3,200),F(1,40))
assert res==(F(7,1000),F(3,250),F(43,6000));ct['strict_fixture']+=1
layer=1/R-1/(F(2)-2*h)
assert layer==F(5,99)
assert tuple(layer*x for x in res)==(F(7,19800),F(1,1650),F(43,118800))
ct['strict_fixture']+=1
for rows,cols in ((2,3),(3,5),(5,8)):
 for seed in range(12):
  V=[[F((seed+3*y+5*x)%7,7*rows) for x in range(cols)] for y in range(rows)]
  vol=[F(x+1,cols) for x in range(cols)]
  c=[(seed+x)%2 for x in range(cols)]
  for H,d in ((F(1,8),F(1,32)),(F(1,2),F(1,4)),(F(2),F(1,2))):
   check(V,vol,c,d,H)
print('PASS',ct)
