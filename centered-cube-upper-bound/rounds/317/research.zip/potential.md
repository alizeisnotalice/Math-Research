# R317 — an atom-correct signed tent account and merged initialization

## 1. Scope and what is paid

Keep the full original R316 U_y,A_yz,J_y,ell_n, source measures beta,nu, actual selected scales, FIRST and same-radius hard caps. No source, gate, posterior or softness is recomputed. Let H>=d>0, c=d/H, and

    g(A)=min(d,A)-c min(H,A).

This is the R316 tent: it vanishes at A=0 and A>=H, has slope 1-c on (0,d), and slope -c on (d,H). Define its original PHYSICAL-prefix occupancy

    R_tent=integral beta(dy)ell_n(dr)1{J_y(r)>=H}
                                          integral g(A_yz(r))nu(dz). (1)

The conclusions are:

* A precise signed Stieltjes account holds for continuous, atomic and mixed physical radius laws. The whole physical crossing atom is retained.
* The initializer by itself costs at most 4lambda(H-d)W_beta. More importantly, it MERGES with the already paid low-J clipped-capacity term inside the same 4lambda H W_beta fee. There is no extra initializer multiple to add.
* The terminal b atom has the alternative direct fee (1-c)W_nu, already covered by the R315 top payment when that allocation is used.
* The positive post-entry flux is the existing R313 first-d quota. The signed account does not supply a new general source-root price for it. No new root theorem is counted.

For H=d, g is identically zero and every tent term below vanishes. R316 already pays the parameter regime H0<=d directly; it is not reopened here.

## 2. Finite radius identity and a whole crossing atom

First take physical radii a=r_1<...<r_m=b and cumulative values J_i,A_i(z), including all mass at r_i. Put k=min{i:J_i>=H}. If there is no such k, (1) is zero for this row. Otherwise put G_i=integral g(A_i(z))nu(dz). With r_(m+1)^(-n)=0, the exact finite identity is

    sum_(i>=k)[r_i^(-n)-r_(i+1)^(-n)]G_i
       =r_k^(-n)G_k
             +sum_(i>k)r_i^(-n)(G_i-G_(i-1)).        (2)

Thus the original gate triggers on the WHOLE inclusive J_k atom, not on a silently truncated atom. To express (2) using row rank H, write j=J_(k-1)<=H, h=J_k-j>0 and theta_H=(H-j)/h in [0,1]. Release the entire actual receiver block at r_k with the SAME theta for every z:

    A_H(z)=A_(k-1)(z)+theta_H[A_k(z)-A_(k-1)(z)].

Then the first term of (2) is exactly

    r_k^(-n) integral g(A_H)nu
      +r_k^(-n) integral [g(A_k)-g(A_H)]nu.          (3)

The second term in (3) is the signed remainder of the crossing atom. It may be negative, including complete cancellation of a positive initializer when the same atom subsequently pushes A beyond H. Dropping it as though the original gate used only theta_H would be incorrect. Taking j=H and theta_H=0 is allowed. No source-dependent order of receivers is used.

At a continuous crossing use J(tau)=H and A_H=A(tau). At an atom at a there is no earlier mass. At an atom at b the remainder in (3) is weighted by b^(-n) and is still retained. Exact landing on H gives theta_H=1; it is not a never-cross case.

## 3. General-measure Stieltjes account

For a row with J_y(b)>=H define tau_y=inf{r:J_y(r)>=H}. Let

    G_y(r)=integral g(A_yz(r))nu(dz).

Its bounded-variation physical Stieltjes measure is used with inclusive CDFs. Positive-first-moment domination gives absolute integrability of its signed increments: |dg(A)|<=dA along the common block refinement, and the integrated physical weighted dA budget is F1<=A_n W_nu. Thus signed Fubini is justified by an actual source budget, not a formal cancellation of infinite quantities.

The physical version of (2) is

    integral ell_n(dr)1{J_y(r)>=H}G_y(r)
       =tau_y^(-n)G_y(tau_y)
                           +integral_(tau_y,b]r^(-n)dG_y(r). (4)

The b endpoint jump is included in the Stieltjes integral. The original b^(-n)G_y(b) term is part of the left side's ell_n atom, not an additional unrecorded boundary fee. For tau=b, (4) simply reads b^(-n)G_y(b).

At every physical radius atom refine the actual block by one common theta as in section 2. Denote the resulting cumulative values by J^o,A^o and the capture increment by dA^o. Define the SAME true quota fluxes as R313,

    N_(H,t)=integral beta(dy)nu(dz)
              integral R^(-n)1{J^o>=H,A^o<t}dA^o.    (5)

Rows which never cross contribute zero. Let

    Init=integral_{J_y(b)>=H} beta(dy) tau_y^(-n)
                                            integral g(A_H(z))nu(dz).

The chain rule, including each full difference in (3), gives the exact identity

    R_tent=Init+N_(H,d)-c N_(H,H)
          =Init+(1-c)N_(H,d)
                           -c[N_(H,H)-N_(H,d)].     (6)

The last bracket is nonnegative: it is the physical weighted capture flux after row rank H with capture rank between d and H. Captures before d give the positive term; captures from d to H give the negative credit; captures after H and all noncaptures give zero. In particular, missed receivers after entry produce no positive dilution term. Their sole possible effect is the activation of the J gate, already accounted for by Init and the complete crossing block.

Formula (6) does not replace physical-prefix gating with a different internal ordering. It is derived from (4) by the exact decomposition (3). It therefore remains valid when one physical atom crosses both capture thresholds d and H, or crosses row rank H and finishes beyond capture rank H.

## 4. Real initialization fee, and why it must merge

At row rank H, all included original receivers have their actual side R<=tau_y and total released U_y mass H. The SAME-receiver hard cap gives

    M_H(y):=integral A_H(z)nu(dz)<=4lambda tau_y^n H.

Since 0<=g(A)<= (1-c)A,

    Init<=4lambda(H-d)W_beta.                       (7)

This uses no cap at a virtual receiver: the theta part is a common fraction of original receivers, each of which has its own original cap.

It is unnecessary to add (7) to an independent 4lambda H low-row price. Define the ACTUAL low-physical-row contribution

    Low=integral beta nu ell_n 1{J_y(r)<H}min(d,A_yz(r)),

and the exact early first-d quota

    E_early=integral beta nu integral R^(-n)
                                      1{J^o<H,A^o<d}dA^o.

On a crossing row, the low layer ends just BEFORE tau. The exact identity is

    Low_y+tau_y^(-n) integral g(A_H)nu
       =(E_early)_y-c tau_y^(-n)M_H(y).             (8)

For a never-cross row the initializer and subtraction are zero and Low_y=(E_early)_y. To verify (8), the low physical layers give the first-d quota before tau minus tau^(-n)min(d,A(tau-)); the early quota adds precisely tau^(-n)[min(d,A_H)-min(d,A(tau-))]. Substitution of g(A_H)=min(d,A_H)-cA_H proves (8). This also handles tau=a,b and theta_H=0,1.

Integrating the original hard cap along the common release up to row rank H gives E_early<=4lambda H W_beta. Therefore

    Low+Init<=4lambda H W_beta,                     (9)

with the explicit negative correction in (8) retained if useful. There is no added beta factor from initialization. The same initializer captures may not be charged again as an independent early prefix.

## 5. Terminal source fee and exact relationship with the old quota

An alternative, compatible physical decomposition of (1) keeps its terminal ell_n atom. Its price is

    b^(-n) integral beta(dy)1{J_y(b)>=H}
                             integral g(A_yz(b))nu(dz)
       <=(1-c)W_nu.                                (10)

Indeed g<= (1-c)A and actual R(x)<=b implies c_x(z)<=1{z in Q_b(x)}. Apply original FIRST at x, extend x positively, and use |Q_b|=b^n. This is one genuine source fee with no scale multiplicity. It is the fixed-top-scale part of the already available R315 top payment. It is an alternative allocation of the terminal term, not an extra saving to add after paying the complete top interval or after using all of (6) without subtracting its remainder.

For clarity, the full clipped capacity high-row part also has the EXACT decomposition

    O_high=R_tent+c O_H,high,
    O_H,high=integral beta nu ell_n1{J>=H}min(H,A)
             =integral_cross beta tau^(-n)M_H+N_(H,H).

Combine this with (6),(8): every c term cancels and one obtains

    O_d=E_early+N_(H,d),                            (11)

exactly the R313 quota identity. Replacing O_H,high by its upper first-moment budget is the R316 paid relaxation, not a new resource. Dropping the negative credit in (6) leaves a larger bound; it does not justify paying the remaining first-d captures by an unproved small-error condition.

Thus the signed potential supplies an atom-correct settlement, a paid initializer that merges without new multiplicity, and an explicit source-paid terminal term. It strictly identifies which apparent positive variance creation is absent after saturation. After these corrections, its unpaid positive flux is still N_(H,d), already the precise R313 task. No new source-root estimate for that flux follows from FIRST or same-radius caps here. R315/R316 geometric prices remain applicable with their exact weights; the remaining low-capture collar geometry is not solved by changing potentials.

All original q, low-pe/m, aspect d and source/history gates are unchanged. Every authorized outer Lambda multiplies all terms inside the original outer integration. Absorption involving X=lambda|E| requires the independently proved finite original entry. No global theorem is asserted.

## 6. Executed exact finite checks

The independent self-contained `/tmp/r317_checks.py` and `/tmp/r317_checks.json` passed 1480 Fraction assertions in two fresh runs, on 90 finite radius menus. These include 90 gated summation-by-parts and terminal-layer checks; 80 each for crossing-atom summation by parts, common-rank initializer/post identity, merged early identity, initializer nonnegativity, early quota nonnegativity, rank capture and rank fraction; 360 increment-contract and 360 tent-nonnegativity assertions; and 10 each for never-cross zero-high and early-all-quota identities. Boundaries include activation at a and b, exact H landing, large overshoots, zero increments, H=d, and one atom crossing both capture thresholds.

One exact overshoot case has theta_H=3/20, A_H=77/40, Init=83/240 and remaining-cross-atom term -83/240, giving zero tent occupancy. It verifies why retaining the entire signed crossing remainder is essential. The tests certify finite-menu algebra only, not continuous measure approximation, the original full-soft kernel realization, or a general source-root price. General-measure claims are proved in sections 3-5.

Frozen diagnostic SHA256 values:

    r317_checks.py:   863c4ded4e7ed3758e823e5c7fb780800076a49977b1ae563d23e94934c4f68a
    r317_checks.json: 1480323fdf8a3cf64d9a0df01eaa679469760d6bb5978ec0578793005075a66f

Only `/tmp/r317_potential.md` is authored here; other authors' files and Git are unchanged.
