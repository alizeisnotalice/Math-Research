# R317 — direct native deep-birth entrance and the historical high-source variant

**Proved:** BOTH R316 native remainders have an exact three-way split into failed local birth, a local near-birth window, and a deep-birth remainder. The main version below starts directly with the COMPLETE full-source normalized entrance: it needs no soft FIRST, high-source deletion, or B_pre. The second version retains the exact historical mu_hi fine-cell birth object when that object is needed. Failed and near birth have explicit source prices in both versions. Neither version assumes whole-heavy-component birth or imports historical FULL gates. The remaining deep-birth traffic is explicit and unpriced at the required order.

Only this file was written. R316 is frozen at `/tmp/r316_entry.md`, SHA256 `11b7d67fce5e8e38dc46b5883a9cad80fd55befacc9c7eb6877625611b1a2bb1`. Archive notation `105::proof.md:136` means that member/line in `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/105/research.zip`.

## Main version: the COMPLETE full-source entrance

Use R316 sections2–4 exactly: `M(x)=sup_[a,b] h_r*f(x)`, `E_band={2lambda<M<=4lambda}`, the fresh maximizing selector R*, full frozen source f dz, and normalized `G_N=1_E lambda/M<=1/2`. Write

`nu_res,f=(f-sqrt(n)lambda)_+ dz`, `W_res,f=||nu_res,f||`.

The R104 output is the existing actual positive `H_native` from R316(5), with ALL its original owner, finite-truncation, capture, harmonic-deficiency and heavy-component masks. Write

`dT_f=A_f(x,z)h_R(x-z)dx nu_res,f(dz)`, `0<=A_f<=G_N<=1/2`.

Its actual row is at most lambda, because `nu_res,f<=f` and `G_N h_R*f=lambda` on E_band. Every radius r in[a,b] satisfies `h_r*f(x)<=4lambda` there. None of the native gates is changed in the following construction.

On fixed half-open fine cells F_i of full side a/n, define NEW frozen fields

`m_i=integral_(F_i) f`, `s_i=(m_i sqrt(n)/(e^2 lambda))^(1/n)` if m_i>0, and s_i=0 otherwise. (F1)

These are the complete-f fine-cell birth radii. They are NOT the historical R105 mu_hi radii t_i defined later, and are not birth radii of R104's connected heavy components.

For deterministic L>=0, split this SAME positive traffic exactly at its hard source's fine-cell label:

`dT_f,fail=1_{R<s_i}dT_f`,

`dT_f,near=1_{s_i<=R<=s_i exp(L/n)}dT_f`,

`dT_f,deep=1_{R>s_i exp(L/n)}dT_f`. (F2)

Cells m_i=0 have zero nu_res,f mass. Boundary equalities belong to near, so the split is complete and disjoint.

Here is the full failed-birth receipt. For a captured source z in F_i on the interior `R<=b-2a/n`, the whole fine cell is in `Q_(R+2a/n)(x)`. The complete-band cap at that enlarged radius gives

`m_i<=4lambda(R+2a/n)^n<=4e^2 lambda R^n`,

hence `s_i^n<=4sqrt(n)R^n`. Interior failed-birth radii therefore belong to the frozen window `[a,b] intersect [s_i/(4sqrt(n))^(1/n),s_i)`. The exact hard column-envelope mass is at most `1+log(4sqrt(n))`. Apply A_f<=1/2 to each immutable source packet `nu_res,f|F_i` and sum: the interior failure costs at most `(1/2)[1+log(4sqrt(n))]W_res,f`.

The other failed-birth part still carries `R<s_i` and has `R>b-2a/n`. Its whole hard-radius window is `[max(a,b-2a/n),b]`. Its envelope mass is at most3 by the elementary endpoint proof in(10) below; that proof includes n=1, b=a, all narrow bands, and singleton intervals. Thus this part costs at most `(3/2)W_res,f`. Failure in total costs at most

`||T_f,fail|| <= (1/2)[4+log(4sqrt(n))]W_res,f`. (F3)

For near birth, each source cell has the fixed window `[a,b] intersect[s_i,s_i exp(L/n)]`. Its column envelope is at most `1+min(L,n log(b/a))`, including nonempty singleton windows. The same packetwise bound, disjoint-source summation and A_f<=1/2 give

`||T_f,near|| <= (1/2)[1+min(L,n log(b/a))]W_res,f`. (F4)

All source packets are frozen, the packet masses sum to W_res,f ONCE, and no receiver-union disjointness is assumed. In particular their total price is

`H_native <= (1/2)[5+log(4sqrt(n))+min(L,n log(b/a))]W_res,f`

`            +H_deep,f,L`. (F5)

The remainder is exactly `||T_f,deep||`, with its original positive dx/source traffic and all native masks. Its additional actual qualification is

`m_i < (e^2 lambda/sqrt(n))R^n exp(-L)` for captured z in F_i. (F6)

Take L=sqrt(n) and use the COMPLETE full-source R316 entrance. The main usable result is

`X_band <= (768/767){P104(f,lambda)`

` +(1/2)[5+log(4sqrt(n))+min(sqrt(n),n log(b/a))]W_res,f`

` +H_deep,f,sqrt(n)}.` (F7)

There is no B_pre, no soft FIRST hypothesis and no extra output absorption in(F7). P104 is the explicit entire R316(3) price, including its actual cap/residual source split. The new coefficient is ADDED to its residual coefficient. Only R104's previously absorbed1/768 is used; the exact coefficient on the new bracket is384/767, and on H_deep,f,sqrt(n) is768/767.

This is an actual qualification `F_f=1_{R>s_(i(z)) exp(1/sqrt(n))}` of a known COMPLETE-band positive remainder, with its entire complement paid in(F3)–(F4). The qualification is a NEW full-f deep-birth condition; one cannot substitute m_i or s_i for mu_hi(F_i) or the original R105 t_i in an old theorem without checking its hypotheses. Its unresolved task is the actual bound on H_deep,f,sqrt(n), retaining all native gates. No old FULL/history or all-physical-scales conclusion is asserted.

The remainder of this file gives the independently useful high-source variant. There the immutable cell mass IS the original mu_hi mass used in R105, at the expense of R316's already-priced B_pre. These are alternative entrances, not costs to add together.

## 1. The source cells and historical birth object

Fix the R316 native retained event, full input f, common q in `[3lambda/4,lambda]`, `0<a<=b<=2a`, fresh maximizing hard selector R=R*(x), and

`mu=mu_hi=f 1_{f>q sqrt(n)} dz`, `W_hi=||mu||`.

Write `g=dmu/dz`, `nu_res=(g-sqrt(n)lambda)_+ dz`, and `W_res=||nu_res||`. These are frozen before the receiver is chosen. In particular `nu_res<=mu<=f dz`.

Partition space by fixed half-open fine cells **F_i** of full side `d0=a/n`; one may subdivide R104's side-a ownership grid. Put

`H_i=mu(F_i)`, `t_i=(H_i sqrt(n)/(e^2 q))^(1/n)` if `H_i>0`, and `t_i=0` otherwise. (1)

The cells F_i are NOT the fixed connected heavy components `C_x` in R104. Nor are they side-a ownership cells, side-5a macro-packages, or shared-forest nodes. The birth radius in (1) belongs to each **entire fine source cell**, using its complete mu mass, rather than the captured part or its nu_res mass.

This is exactly the kind of object called C in `105::proof.md:136–159`: line136 expressly distinguishes it from the other three objects; lines139–141 give (1). R105's original hypothesis `t_C<=R` is at145–150. Its historical justification at152–159 uses already-paid whole-cell anomalous-output deletion AND a paid hard top strip, yielding the stronger full-cell response cap `H_C/(R+2d0)^n<=q/sqrt(n)`. Those old deletions and that cap are NOT available automatically for the fresh native input. R105 also preserves old FULL gates at132–134,164–169. We do not import them.

R104's heavy threshold is instead

`nu_res(C_x)>lambda a^n exp(sqrt(n))` (`104::proof.md:894–918`).

It is a lower bound on a different, entire connected package. Failed local birth means the lower bound `mu(F_i)>e^2 q R^n/sqrt(n)` on one fine cell. These two scalar conditions do not contradict one another, and the heavy threshold supplies no upper bound on that fine-cell mass. Thus heavy-component status alone does not prove local birth. This observation is not a claim to construct a counterexample satisfying every native mask; the prices below are valid whether or not a particular failed-birth slot is empty.

## 2. Preserve the exact native traffic and its two bounds

Let `dT` be exactly R316's `H_native,hi`, including its actual high-excess source, harmonic deficiency, finite K0, non-small captured mass, fixed unique heavy component, and every native GOOD gate. Denote its scalar density by

`dT=A(x,z) h_R(x-z) dx nu_res(dz)`, `H_native,hi=||T||`. (2)

All original factors are retained in A. They are those of R316 section4 applied to the section6 source/gate, which instantiate `104::proof.md:855–921`. In particular

`0<=A(x,z)<=G_hi(x,z)=1_{E_ret}(x) GOOD_h(x-z) lambda/H(x)<=4/7`, (3)

where `H(x)=integral h_R(x-z)GOOD_h(x-z)mu(dz)>7lambda/4` on E_ret. There is also the stronger actual receiver-row bound

`integral A(x,z)h_R(x-z)nu_res(dz)<=lambda 1_{E_ret}(x)`. (4)

Indeed (3), `nu_res<=mu`, and the definition of H give (4) directly. No removal of the positive source or replacement of dx is involved. If the joint soft kernel is retained, all the following splits multiply that SAME joint traffic by hard `(x,z)` indicators; the soft source kernel is unchanged.

The maximizing R316 selector supplies an additional hypothesis used only in the sharper failed-birth price:

`h_r*f(x)<=4lambda for EVERY r in[a,b], x in E_ret`. (5)

This follows from `E_ret subset {2lambda<sup_[a,b] h_r*f<=4lambda}`. It is stronger than R104's generic cap at the selected radius alone; (5) must not be inferred for an arbitrary nonmaximizing R104 input.

## 3. Exact three-way split

Fix deterministic `L>=0`. For the unique fine-cell label i=i(z), define actual positive submeasures

`dT_fail=1_{R<t_i}dT`,

`dT_near,L=1_{t_i<=R<=t_i exp(L/n)}dT`,

`dT_deep,L=1_{R>t_i exp(L/n)}dT`. (6)

They are disjoint and sum exactly to T. Cells with H_i=0 have zero nu_res mass, so they create no exceptional source terms. Endpoint equalities belong to near; the strict deep condition below is retained. All these indicators are measurable (fixed countable cells and measurable R). Neither the source nor any R104 owner/component label is recomputed after splitting.

## 4. Failed birth: the stronger logarithmic native-cap price

Set

`B=4lambda sqrt(n)/q`, so `4sqrt(n)<=B<=16sqrt(n)/3`. (7)

Split T_fail exactly into its **interior** part `R<=b-2d0` and **top** part `R>b-2d0`. The top part still includes the failed-birth indicator; bounding it by the whole top window is only an inequality, not a new partition.

For an interior captured pair z in F_i intersect Q_R(x), the whole fine cell is contained in `Q_(R+2d0)(x)`. The enlarged radius belongs to[a,b]. Hence (5) and mu<=f give

`H_i<=4lambda(R+2d0)^n<=4e^2 lambda R^n`,

because `R>=a` and `(1+2a/(nR))^n<=e^2`. Thus `t_i^n<=B R^n`. Together with failed birth this confines the actual radius to the source-fixed window

`R in [a,b] intersect [t_i B^(-1/n),t_i)`. (8)

For every nonempty window the exact hard column envelope has mass at most `1+log B`. Using A<=4/7 only for the positive upper estimate, integrating against each fixed packet `nu_res|F_i`, then summing the disjoint source cells, proves

`||T_fail,interior|| <= (4/7)(1+log B) W_res`. (9)

The top part uses the single fixed window `[ell,b]`, where `ell=max(a,b-2a/n)`. Its envelope mass is

`1+n log(b/ell)<=3`. (10)

For completeness: if ell=a then `b/a<=1+2/n`; if ell=b-2a/n>=a then `b/ell=1+2a/(n ell)<=1+2/n`. Both imply `n log(b/ell)<=n log(1+2/n)<=2`. This proof covers n=1, a narrow band, b=a, and the case b-2a/n<a (when the interior is empty). Closed singleton windows have envelope mass1, so no endpoint mass is lost. Therefore

`||T_fail,top|| <= (12/7) W_res`,

and the full actual failed-birth complement is priced by

`||T_fail|| <= (4/7)(4+log B) W_res`. (11)

No historical whole-cell deletion is needed for (11). The upper cap comes from the native COMPLETE hard band itself.

## 5. Independent failed-birth price using only the row bound

This is an ALTERNATIVE to (11), not an additional expense. It also applies when only (4), not the full-radius cap (5), is known.

For an active failed-birth cell necessarily `t_i>a`. Set `r_i=min(b,t_i)>a`. The receivers that can capture a source z in F_i with R<t_i lie in

`U_i=F_i+Q_(r_i)`, `|U_i|=(r_i+a/n)^n<=e r_i^n<=H_i sqrt(n)/(e q)`. (12)

For EACH fixed cell, its actual failed-birth receiver row is bounded by the total row (4), and is zero outside U_i. Its traffic is therefore at most `lambda|U_i|`. Sum this inequality over cells. Receiver sets U_i may overlap; this only enlarges the upper bound and produces no multiplicity assumption. The full source masses are disjoint, `sum_i H_i=W_hi`. Consequently

`||T_fail|| <= (lambda/q)(sqrt(n)/e)W_hi <= (4/(3e))sqrt(n)W_hi`. (13)

This uses no pointwise cap on mu, no whole-component birth, and no physical-top deletion. One can take the smaller of (11) and (13), with their stated different source masses; they must not be added as if pricing disjoint failures.

## 6. Near birth: one fixed source packet per fine cell

For cell F_i, the near-birth radii belong to the fixed window

`J_i=[a,b] intersect [t_i,t_i exp(L/n)]`.

If nonempty, let `r_i^-=max(a,t_i)` and `r_i^+=min(b,t_i exp(L/n))`. The hard column identity is

`integral sup_(r_i^-<=r<=r_i^+) h_r(x-z) dx`

`=1+n log(r_i^+/r_i^-)<=1+min(L,n log(b/a))`. (14)

One proves this by integrating in `u=2||x-z||_infinity`, whose sublevel volume is u^n; it is recorded at `104::proof.md:135–142`. Use A<=4/7 and integrate first against the immutable packet `nu_res|F_i`. Positive Tonelli and the disjoint cell partition give

`||T_near,L|| <= (4/7)[1+min(L,n log(b/a))] W_res`. (15)

There is no cell-count, component-count, forest-depth, or receiver-overlap multiplier. Source W_res occurs exactly once in this sum. Formula(15) is the R105 window argument at `105::proof.md:175–207`, applied directly to (2) with its sharper gate4/7. That argument only requires the birth predicate on this actual subbranch, frozen packets and the window; it does not establish or require us to assert all of historical R105's old FULL qualifications. In particular we have not recreated a receiver-dependent source and called it FIRST.

## 7. Usable resulting entrance and the precise remaining geometry

Take L=sqrt(n). Combining (6), (11), and (15) yields the proved local connector

`H_native,hi <= (4/7)[5+log(4lambda sqrt(n)/q)`

`                         +min(sqrt(n),n log(b/a))] W_res + H_deep`, (16)

where `H_deep=||T_deep,sqrt(n)||` is the SAME actual native positive traffic with the added qualification

`H_i < (e^2 q/sqrt(n)) R^n exp(-sqrt(n))` for its hard source z in F_i. (17)

This is the exact algebraic consequence of `R>t_i exp(1/sqrt(n))`; the inequality is strict. It is a bound on the entire original fine-cell mu mass, not on a point density or a captured piece. All inherited native masks, complete dx, fixed source nu_res, original K0 and heavy component labels remain. For example the frozen source restriction `sum_{t_i<b exp(-1/sqrt(n))}nu_res|F_i` covers all possible deep sources, but source/component labels are not recalculated from it.

Use the R316 high-source entrance, with its original native deletion fee B_pre and explicit P104 source price:

`X_band <= B_pre +(768/767)[P104(mu,lambda)+H_native,hi]`.

It now becomes the actual proved bound

`X_band <= B_pre +(768/767){P104(mu,lambda)`

`              +(4/7)[5+log(4lambda sqrt(n)/q)`

`                         +min(sqrt(n),n log(b/a))] W_res + H_deep}.` (18)

Here `B_pre=(2C_base+8)sqrt(n)W+(32/3)kappa_n W+(256/3)K_*^2 sqrt(n)W_lo`; P104 is exactly R316(3), with the cap/residual split of mu. The new fee is added to those source prices; the same W_res may fund distinct authorized branches, so their coefficients are added. No additional epsilon X is used in (16); the sole R104 absorption remains1/768, already absorbed into768/767. The coefficient multiplying the new bracket and H_deep is respectively3072/5369 and768/767. One may replace the failure part in(18) by(13), rather than add it.

This is a usable qualification F: `F(x,z)=1_{R>t_(i(z)) exp(1/sqrt(n))}` on the exact native residual. Its complete actual complement has the explicit prices above. It supplies the fine-cell **deep-birth** geometric premise from the original source. It supplies no distinct-child LCA, CP/GP gates, forest weights, fullcell all-radius cap q/sqrt(n), early-exit allocation, terminal-source identity, or common terminal leaf.

The next concrete unpaid problem is to bound precisely this H_deep at root/polylog source cost (possibly plus an explicitly budgeted output fraction), or to construct further qualifications on it and pay their exact positive complements. It is not legitimate to call H_deep the old FULL R_out without that construction. The old historical initial/jump/future-deleted/suffix terms arise only if an actual downstream identity is applied to a correctly qualified branch; this local connector does not silently create, pay, or erase them. The all-physical-scales assembly remains outside the certified finite-octave entrance, as explicitly stated in R316 section5.

## 8. Checked scope and evidence

| Statement | Status and exact basis |
|---|---|
| Birth object is a whole fine source cell, not a heavy component | Verified `105::proof.md:136–159`; notation F_i used here to avoid confusion |
| Original heavy threshold does not itself supply a fine-cell upper mass bound | Exact R104 objects at `104::proof.md:894–918`; no counterexample claimed |
| Actual gate<=4/7 and row<=lambda | Proved from R316 section6 normalization and nu_res<=mu, equations(3)–(4) |
| Full-radius cap needed in the logarithmic failure receipt | Verified native maximizer definition R316 section2/6; not generic R104 selected-radius hypothesis |
| Failed birth logarithmic/top receipt | New proof(7)–(11), valid n>=1 and all 0<a<=b<=2a |
| Independent row-volume failure receipt | New proof(12)–(13); alternate, not cumulative |
| Near birth source-once receipt | New direct proof(14)–(15); finite-window identity `104::proof.md:135–142`, matching `105::proof.md:175–207` |
| Native deep-birth qualification and full actual complement | Exact partition(6), qualification(17), bound(18) |
| All old FULL/history hypotheses, root price of H_deep, all-scale assembly | NOT established here |

Actual local Python/Fraction execution checked the direct coefficient `(1/2)(768/767)=384/767` and `lambda/q<=4/3`, `B/sqrt(n)<=16/3`, `1/(1-1/768)=768/767`, and `(4/7)(768/767)=3072/5369`. A numerical sweep of top-window ratios for n=1,2,3,4,5,16,64,512,1024,100000 and b/a in[1,2] gave maximum sampled `n log(b/ell)=1.9980219583<2`; this is only a diagnostic, while the elementary inequalities in(10) are the proof. Independent audit by `/root/r285_final_audit` confirmed both failure receipts and the near window, including the need to retain failed birth on the top subbranch.
