#!/usr/bin/env python3
"""R317 finite fine-cell birth geometry algebra, standard library only."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
counts=Counter(); diagnostics=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def run(n):
 rows=[]
 for b in sorted({F(1),1+F(1,n),F(2)}):
  a=F(1);edge=b-F(2,n);closed_lower=max(a,edge);ratio=b/closed_lower
  ck('closed_envelope_ratio',ratio<=1+F(2,n))
  ck('rational_log_majorant',n*(ratio-1)<=2)
  # Keep the original strict TOP gate; closed support may include its boundary.
  points=sorted({a,b,(a+b)/2}|({edge} if a<=edge<=b else set()))
  for R in points:
   top=R>edge
   ck('top_or_interior_partition',top==(not R<=edge))
   if top:
    ck('top_in_closed_envelope',closed_lower<=R<=b)
    diagnostics['top_at_a']+=R==a
   else:
    ck('interior_legal_inflation',R+F(2,n)<=b)
    ck('interior_volume_ratio',(R+F(2,n))**n<=R**n*(1+F(2,n))**n)
   if R==edge:ck('top_strict_boundary',not top)
  rows.append(dict(b=str(b),strict_top_edge=str(edge),closed_lower=str(closed_lower),ratio=str(ratio)))
 # Birth window in volumes v=R^n, T=t^n. No roots or floats.
 for B in sorted({F(1),F(4,3),(1+F(2,n))**n,F(2)**n}):
  for T in [F(0),F(1),(1+F(1,n))**n,F(2)**n]:
   lower=T/B
   for v in sorted({F(0),lower/2,lower,(lower+T)/2,T,2*T}):
    birth=lower<=v<T
    ck('birth_volume_equivalence',birth==(T<=B*v and v<T))
    if T==0:ck('zero_source_empty_birth',not birth)
    if v==lower:ck('birth_lower_inclusive',birth==(lower<T))
    if v==T:ck('birth_upper_excluded',not birth)
    if B==1:ck('B_one_empty_birth',not birth)
  # Rational radius witnesses give an independent n-th power equivalence.
 for factor in [F(1),F(5,4),F(2)]:
  B=factor**n
  for t in [F(1),F(3,2),F(2)]:
   for R in [t/(2*factor),t/factor,(t/factor+t)/2,t,2*t]:
    ck('rational_radius_birth',(t/factor<=R<t)==(t**n/B<=R**n<t**n))
 return dict(n=n,top_geometry=rows)
def main():
 stages=[];models=[]
 for stage,ns in [('initial',[1,4]),('boundary',[9,16,25]),('expanded',[64,256])]:
  before=sum(counts.values())
  models.extend(run(n) for n in ns)
  stages.append(dict(stage=stage,dimensions=ns,checks=sum(counts.values())-before))
 result=dict(status='PASS',arithmetic='Fraction',scope='Finite geometric algebra only; no actual function realization, FIRST or continuous source certification.',check_counts=dict(counts),total_checks=sum(counts.values()),diagnostics=dict(diagnostics),stages=stages,models=models,birth_parameters='B=1,4/3,(1+2/n)^n,2^n; T=t^n=0,1,(1+1/n)^n,2^n; rational-root checks factors1,5/4,2.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','diagnostics','stages']},sort_keys=True))
if __name__=='__main__':main()
