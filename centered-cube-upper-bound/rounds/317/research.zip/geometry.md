# R317 — common receiver-mass projection retains cross-row capture overlap

## 1. Precise claim and scope

Keep the original R302/R315/R316 fields, without recomputing their sources or masks:

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_yz(r)=integral_{R(x)<=r}U_y(x)c_x(z)dx,
    c_x(z)=1{z in Q_(R(x))(x)},
    rho(x)=integral U_y(x)beta(dy)<=1,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr.

The sources are finite positive L1 measures, a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, and the same-radius hard cap is nu(Q_R(x))<=4lambda R(x)^n. All original low-pe,m, full e_g, history, aspect and positive outer factors remain. The R315 source domination and all-radius cap are required only when its separate geometric receipts are invoked. No nu<=beta, density bound, component FIRST, or higher-softness FIRST is assumed.

Fix H>=d>0. The active set for a fixed original source z and layer r is

    Y_z(r)={y:J_y(r)>=H, 0<A_yz(r)<H}.

For active rows let

    p_y=A_yz(r)/J_y(r),
    g(A)=min(d,A)-(d/H)A,
    v_y=g(A_yz(r))/[A_yz(r)(1-p_y)].

Set v_y=0 and p_y=0 off the active set. Thus 0<=v_y<=1, and denominators on its active support are positive. These are the ORIGINAL A,J. Define the actual shared receiver fields on E_r=E intersect {R<=r}:

    rho_v(x)=integral v_y U_y(x)beta(dy),
    b_v(x)=integral v_y U_y(x)p_y beta(dy),
    C_v=integral v_y A_yz(r)beta(dy).                 (1)

Both receiver fields are zero outside E_r. They satisfy 0<=b_v<=rho_v<=rho<=1. Crucially v depends on y,z,r but not on a freely chosen endpoint label; no weighted FIRST is presumed beyond this positive domination.

Let {Omega_i} be any finite or countable measurable partition of the actual receiver space. Put

    M_i=integral_(Omega_i)rho_v(x)dx,
    B_i=integral_(Omega_i)b_v(x)dx,
    S_projection(z,r)=C_v-sum_i B_i^2/M_i,           (2)

where a zero M_i contributes zero (and necessarily B_i=0). Then the true minimum-tent layer satisfies

    T_tent(z,r):=integral_(Y_z(r))g(A_yz(r))beta(dy)
              <= S_projection(z,r).                 (3)

The right side is nonnegative. Refining the SAME receiver partition increases the subtracted quadratic term and decreases this upper certificate. It is a shared-receiver geometric inequality, not a new optimization of only C_z(r)<=r^n: it uses the actual overlap of different soft rows at their original receiver locations.

This certificate can be strictly smaller than the R316 source-column Jensen certificate. Section 5 gives an explicit positive-volume prescribed-kernel example where the improvement occurs on nonempty collar-far geometry. This is a strict finite geometric comparison, not a universal source-root bound and not a certification of the original historical low-pe gate in that example. The universal root estimate remains open at the precise integrated prediction-defect step in section 4.

## 2. Proof, source conservation, and the remaining projection loss

All fields in (1) are measurable positive integrals of the actual data. For fixed z,r the common-softness envelope supplies J_y(r)<=A_n Csoft_n/q_-, so the relevant weighted beta and receiver measures are finite. Alternatively all the following calculations first hold on finite positive truncations and then pass by Tonelli. Let

    E_v=integral v_y A_yz(r)^2/J_y(r) beta(dy).

Then, exactly,

    T_tent=C_v-E_v,
    integral_(E_r)b_v(x)dx=C_v,
    E_v=integral_(E_r)dx integral v_y U_y(x)p_y^2 beta(dy). (4)

For rho_v(x)>0 the original beta measure v_y U_y(x)beta(dy)/rho_v(x) is a probability. Cauchy-Schwarz at this actual receiver gives

    b_v(x)^2/rho_v(x)
        <=integral v_y U_y(x)p_y^2 beta(dy).

There is no evaluation of FIRST at a source point or at a virtual center. Integration gives the first inequality in

    E_v >= integral_(E_r)b_v^2/rho_v dx
        >= sum_i (integral_(Omega_i)b_v dx)^2
                         /(integral_(Omega_i)rho_v dx). (5)

The second inequality is again Cauchy-Schwarz, now inside each common receiver cell. It proves (3). All beta rows have been combined before the cells are summed; a source mass is never charged once per row or cell. Since p_y^2<=p_y, every term in (5) is bounded by E_v<=C_v. Thus subtraction is finite and nonnegative, not an infinity-minus-infinity convention.

For a refinement Omega_i=union_j Omega_ij, Cauchy-Schwarz gives

    B_i^2/M_i<=sum_j B_ij^2/M_ij.

This proves the monotone improvement. A fixed refining sequence of dyadic half-open receiver cubes generates the Borel sigma algebra. For the finite measure rho_v dx, the cell averages of b_v/rho_v converge in L2 to that bounded function. This follows by approximation with dyadic step functions, since 0<=b_v/rho_v<=1. Consequently the limiting certificate is

    S_infinity=C_v-integral b_v^2/rho_v dx.           (6)

No uncountable optimization or measurable choice of a new actual selector is required; a fixed dyadic partition sequence is sufficient.

There is an exact expression for the gap still lost by receiver projection:

    S_infinity-T_tent
       =integral_(E_r)rho_v(x)
             Var_(v_y U_y(x)beta/rho_v(x))(p_y)dx.   (7)

Thus grouping does not manufacture an overlap credit. It retains the part of the quadratic capture energy that is visible through the actual common receiver mixture, and loses precisely the conditional cross-row variance in (7). A small cell size alone cannot remove this latter loss. This observation is particularly relevant when the same receiver receives contributions from rows with different cumulative capture fractions.

## 3. Combination with the R316 census and the original entry

Use the unchanged R316 quantities

    m_z(r)=beta(Y_z(r)),
    C_z(r)=integral_(Y_z(r)) A_yz(r)beta(dy),
    S_census(z,r)=min(C_z(r),d m_z(r))-(d/H)C_z(r).

Both S_census and S_projection bound the SAME true tent layer. Therefore

    R_H,d <= K_partition,
    K_partition=integral nu(dz)ell_n(dr)
                   min(S_census(z,r),S_projection(z,r)). (8)

This is a pointwise minimum of two proved upper bounds, not a sum of separate source payments. It is never worse than the R316 certificate, and section 5 shows strict improvement in a genuine cube/source configuration. Refinement decreases K_partition. The common grid can be fixed for all sources and layers, so no source-dependent cover-selection fee or duplication is hidden in (8).

Every quantity in (8) is integrable. Indeed 0<=S_projection<=C_v<=C_z, and integral C_z nu ell<=F1<=A_n W_nu, where A_n=1+n log(b/a). The use of the original FIRST in (1) and in this last first-moment bound remains unchanged. In particular the unconditional price deduced so far is still only K_partition<=A_n W_nu.

The exact original minimum-tent entry now yields

    T_target<=8lambda H W_beta+2(d/H)A_n W_nu
                                           +2K_partition. (9)

At H=sqrt(d A_n/(4lambda))>=d this becomes

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
                                           +2K_partition. (10)

The original identity lambda d=(4/3)kappa0 psi_inf/v0 and all low-m, aspect, unique-band and positive outer/clock costs are retained. No native higher-softness FIRST is transferred to this old selector. If H<d at the usual choice, the coarse R316 first-moment argument handles that parameter regime; it is not a new consequence of projection.

The R315 bottom/deep/top/contact receipts also remain available. However, (5) projects the WHOLE rank-one tent layer. One may bound its collar-far subset by that whole certificate, or compare the complete bound (9) with the complete R315 continuation. One may NOT subtract the full projection energy from the already restricted oriented collar integral without proving an additional localized inequality. Its far/contact/collar restrictions couple u and w and generally destroy the rank-one identity (4). This limitation prevents a free reuse of the same overlap credit after geometric pieces have been removed.

## 4. Exact remaining geometric estimate

The new certificate exploits more information than C_z<=r^n: it keeps where actual soft rows overlap, their actual cumulative capture fractions, and their common receiver weights. To get the requested source-root conclusion by this route one must still prove, for some fixed partition or its limit,

    K_partition<=epsilon X+C_epsilon sqrt(A_n)log^p(n+2)
                                 (W_beta+W_nu),     (11)

with all dependence on lambda d, H and aspect stated. Equivalently, the integrated receiver-visible prediction energy must remove the large first-moment portion that remains after taking the census minimum. No such lower bound on that energy has been proved here for arbitrary original full-soft rows and masks.

Neither FIRST rho_v<=1 nor the hard cap supplies it directly. FIRST controls total receiver mass, while b_v/rho_v is a conditional mixture of the ACTUAL row capture fractions. The all-radius hard cap controls nu at a given original receiver; it does not force that conditional mixture toward 1, nor bound the posterior variance (7) by a root source budget. Winner contact pays the already identified near-receiver part, but does not furnish this far-receiver prediction estimate.

Accordingly the strict improvement in (8) is a usable geometric certificate, not a claim that its price is automatically root order. The unresolved tasks include (11), or a sharper localized projection that retains collar-far coupling; any nonzero winner defect; and the complete global outer/aspect ledger. The actual original low-pe,m and full e_g constraints have not been discarded in the theorem, but no extra consequence of them is silently assumed.

## 5. Positive-volume prescribed-kernel fixture with strict collar-far improvement

This fixture verifies a strict improvement beyond scalar column occupancy while retaining actual physical receiver locations. Its scope is the broad prescribed-kernel/row-upper-cap contract. It is NOT certified to satisfy the original low-pe,m, history gates or the native canonical interior-softness margin s>c/n.

Take n=1, a=1, b=L=2, selected R=9/5, s=0, q=1, lambda=4/3. Let beta be the sum of two uniform source intervals of mass 1 each, centered at -1/200 and +1/200, each of length 1/1000. Let nu have mass 1 uniformly on [-1/1000,1/1000], and f=beta+nu. Let E consist of four disjoint intervals of length 1/50 centered, in order, at

    -19/20, -7/10, 7/10, 19/20.

For every receiver and beta source point here, |x-y|<1, so the actual kernel P_(0,2)(x-y)=1/2. Use alpha=1 for the first beta interval on all four cells, and alpha=1 for the second beta interval except on the third cell, where alpha=0. This is an explicit z-independent bounded row gate. The prescribed aggregate response is at most 1=q at every actual receiver (the ungated beta response equals 1). Since f has mass 3 and every legal hard scale is >=1, h_t*f<=3<4lambda globally. Thus source domination and all-radius hard upper caps hold, without asserting that the selected R is a hard winner or that full-f soft FIRST holds.

For every z in the support of nu, precisely the two inner cells capture z. With H=1/40 and d=3/200, at every layer r>=9/5 the two row data are

    (J_1,J_2)=(1/25,3/100),
    (A_1,A_2)=(1/50,1/100),
    (p_1,p_2)=(1/2,1/3),
    (v_1,v_2)=(3/10,3/5).

The exact tent layer, the R316 census upper bound and the common four-cell receiver certificate are respectively

    T_tent=7/1000,
    S_census=3/250,
    S_projection=43/6000.                           (12)

Thus the new certificate is strictly below the old census bound and strictly above the exact tent, with its remaining gap exactly described by (7).

This comparison also occurs on nonempty collar-far geometry. Choose eta=3/5 and h=1/100, giving a/eta=5/3<9/5 and t_h=99/50. For every relevant z, the two capturing cells lie outside Q_(eta R)(x), whereas the two outer cells miss z. Every capturing/missing pair has distance at least 23/100>h. Hence on the layer interval [9/5,99/50), the entire physical oriented tent is collar-far. Its ell mass is

    (9/5)^(-1)-(99/50)^(-1)=5/99.

Multiplying (12) by this common mass yields

    exact collar-far tent =7/19800,
    receiver certificate =43/118800,
    census certificate =1/1650.                     (13)

These are genuine positive-volume kernel/cube calculations, not an atomic receiver quadrature. They demonstrate that receiver overlap information can improve the bound on the intended geometric configuration. They do not certify a new root theorem, the historical low-pe qualifications, or full native canonical FIRST for this fixture. A fixed one-dimensional fixture is evidence for strictness of the general inequality, not the goal of the result.

## 6. Reproducible exact checks

The embedded script checks the fixture's entire source/receiver intervals, the upper caps, the collar-far geometry, the exact fractions in (12),(13), and refinement monotonicity. It also checks the two Jensen inequalities and census comparison on finite nonnegative row/receiver fixtures in three sizes. A fresh isolated Python process passed 17 geometry diagnostics, 109 projection diagnostics, 109 refinement diagnostics and 2 exact strict-fixture comparisons. These counters refer to the displayed check groups, not individual scalar comparisons inside each group. Only the explicit one-dimensional fixture is claimed to use the prescribed physical kernels; the other matrices are finite algebra diagnostics.

```python
from fractions import Fraction as F
from itertools import product
ct={'geometry':0,'projection':0,'refinement':0,'strict_fixture':0}
centers=[-F(19,20),-F(7,10),F(7,10),F(19,20)]
cells=[(x-F(1,100),x+F(1,100)) for x in centers]
yboxes=[(-F(1,200)-F(1,2000),-F(1,200)+F(1,2000)),
        (F(1,200)-F(1,2000),F(1,200)+F(1,2000))]
zbox=(-F(1,1000),F(1,1000));R=F(9,5);eta=F(3,5);h=F(1,100)
for cell,ybox in product(cells,yboxes):
 assert max(abs(x-y) for x,y in product(cell,ybox))<1;ct['geometry']+=1
capture=[0,1,1,0]
for cell,cap in zip(cells,capture):
 distances=[abs(x-z) for x,z in product(cell,zbox)]
 if cap:
  assert max(distances)<R/2 and min(distances)>eta*R/2
 else:assert min(distances)>R/2
 ct['geometry']+=1
for i,j in product((1,2),(0,3)):
 assert min(abs(x-w) for x,w in product(cells[i],cells[j]))>h
 ct['geometry']+=1
assert F(3)<=4*F(4,3) and R>1/eta and R<F(2)-2*h;ct['geometry']+=1

def check(U,vol,c,d,H):
 J=[sum(u*v for u,v in zip(row,vol)) for row in U]
 A=[sum(u*v*ci for u,v,ci in zip(row,vol,c)) for row in U]
 vv=[];pp=[];gg=[]
 for a,j in zip(A,J):
  active=j>=H and 0<a<H
  p=a/j if j else F(0);g=min(d,a)-d*a/H if active else F(0)
  vv.append(g/(a*(1-p)) if active else F(0));pp.append(p);gg.append(g)
 rho=[sum(v*row[i] for v,row in zip(vv,U)) for i in range(len(vol))]
 field=[sum(v*p*row[i] for v,p,row in zip(vv,pp,U)) for i in range(len(vol))]
 Cv=sum(v*a for v,a in zip(vv,A))
 E=sum(v*a*p for v,a,p in zip(vv,A,pp))
 fine=sum(m*b*b/r for m,b,r in zip(vol,field,rho) if r)
 coarse=(sum(m*b for m,b in zip(vol,field))**2/sum(m*r for m,r in zip(vol,rho))
         if sum(m*r for m,r in zip(vol,rho)) else F(0))
 assert 0<=coarse<=fine<=E<=Cv and sum(gg)==Cv-E
 ct['projection']+=1;ct['refinement']+=1
 active=[i for i,(a,j) in enumerate(zip(A,J)) if j>=H and 0<a<H]
 C=sum(A[i] for i in active);m=F(len(active))
 census=min(C,d*m)-d*C/H
 assert sum(gg)<=min(census,Cv-fine)
 return sum(gg),census,Cv-fine
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
assert all(sum(row[i] for row in U)<=1 for i in range(4))
res=check(U,[F(1,50)]*4,capture,F(3,200),F(1,40))
assert res==(F(7,1000),F(3,250),F(43,6000));ct['strict_fixture']+=1
layer=1/R-1/(F(2)-2*h)
assert layer==F(5,99)
assert tuple(layer*x for x in res)==(F(7,19800),F(1,1650),F(43,118800))
ct['strict_fixture']+=1
for rows,cols in ((2,3),(3,5),(5,8)):
 for seed in range(12):
  V=[[F((seed+3*y+5*x)%7,7*rows) for x in range(cols)] for y in range(rows)]
  vol=[F(x+1,cols) for x in range(cols)]
  c=[(seed+x)%2 for x in range(cols)]
  for H,d in ((F(1,8),F(1,32)),(F(1,2),F(1,4)),(F(2),F(1,2))):
   check(V,vol,c,d,H)
print('PASS',ct)
```

Only /tmp/r317_geometry.md is written. Other authors' files and Git are unchanged. This bounded route stops with the strict certificate improvement (3),(8) and the unproved root-price step (11).
