# R317 independent preauthor screen

Saved BEFORE reading any R317 author proof. Own this audit only; no Git or other-author edits.

## 1. Exact high-J tent Stieltjes statement

Fix original U_y, actual radius R in[a,b], sources beta,nu, ell_n, H>=d>0. Put c=d/H and g(A)=min(d,A)-c min(H,A). J_y(r),A_yz(r) are inclusive right-continuous cumulative functions. For fixedy,z the fee is integral ell_n(dr) W(r), W(r)=1{J(r)>=H}g(A(r)). It is NONNEGATIVE as an occupancy, but W is not in general nondecreasing. Tent g increases with slope1-c up to d, decreases with slope-c from d to H, and is zero thereafter.

If J(b)<H, the fee is zero. Otherwise let tau=inf{r in[a,b]:J(r)>=H}; inclusive right-continuity makes the high-J gate active at tau, including tau=a or b. The exact integration-by-parts identity is

 integral ell_n 1{J>=H}g(A)=tau^(-n)g(A(tau))
                    +integral_(tau,b] r^(-n)d[g(A(r))].

The signed measure after tau is genuine, not a nonnegative innovation measure. The b terminal atom in ell_n is indispensable; if tau=b the first term alone remains. At a use the full inclusive initial mass. J(tau-)<=H, possibly equality even when an atom is present; treating the crossing as always strict would be wrong. The initialization cannot be set to zero just because g(0)=0.

For EVERY capture atom, including one crossing both d and H, the exact increment is

 Delta g=(1-c)Delta min(d,A)
       -c Delta[min(H,A)-min(d,A)].

Equivalently it integrates the rank slope1-c before d, -c between d,H and0 afterH over the actual capture increment. Replacing Delta g by the post-atom derivative times Delta A is invalid. Continuous and singular-continuous parts use the corresponding Stieltjes chain rule. Any common refinement of a radius atom must release the same actual receiver block fraction for allz; no favorable source-dependent receiver ordering. H=d gives g identicallyzero.

The common row-mass quota at H provides an optional initialization payment: split the first actual radius block uniformly at total row massH, obtaining A_H<=H. Then g(A_H)<=(1-c)A_H and actual hard caps give tau^(-n)integral g(A_H)nu<=4lambda(1-c)H per beta row. All remaining same-radius block capture increments and their SIGNED tent flux must stay, as well as later flux; the original high-J gate was not recomputed. This is a valid paid initialization only with its complete modified remainder and with the preexisting R302 small-J fee kept separately. It is not automatically a better full bound.

## 2. What capture increments/FIRST do and do not prove

Discarding negative tent flux is a safe upper bound, but loses its cancellation. The resulting positive capture-rank quota is bounded by the actual first moment, which via shared FIRST gives only A_n Wnu in general. Source copies across beta rows cannot be eliminated merely by saying every pair(y,z) has one low-capture interval. The frozen R316 shared-source census gives the legitimate concave certificate with negative credit; its proved scalar relaxation still permits A_n. Thus a new rank expression or signed identity alone is not a new source-root budget, nor an original target allocation. A strict improvement needs an actual integrated saving: source-conserving cross-row high-J/early-capture packing, true receiver/source overlap producing controlled negative flux, or a separately paid native target branch.

No counterexample to the original input class is inferred from this failure of a relaxation. Endpoint/atomic identities are useful exact bookkeeping, but do not certify the missing root estimate.

## 3. Native heavy component versus the ORIGINAL birth gate

Read frozen R316 entry/geometry and directly checked original ZIP105::proof.md134–169 and104::proof.md735–743. The ORIGINAL birth label C is a fine side-d0=a/n cell with H_C=mu_hi(C), t_C=(H_C sqrt(n)/(e²q))^(1/n), using the fixed complete high source and commonq. It is NOT the side-a ownership cell, connected heavy component, or shared forest node. R316's component lower bound m_component>lambda a^n exp(sqrt(n)) supplies no fine-cell upper bound and does not imply t_C<=R. Heavy source mass must not be substituted for H_C, and the capped residual mass must not replace the complete mu_hi cell mass. Original R105 gets birth from the paid whole-cell response exception AND legal top-radius strip; those qualifications are not automatically furnished by R104's uniform construction.

## 4. Constructive paid birth-failure screen (new independent candidate)

Although heavy alone does not give birth, the native full hardband cap and nu_H<=mu_hi<=f permit a direct source-once payment of its failure. Fix the original fine grid and fixedcommon q in[3lambda/4,lambda], d0=a/n. Partition actual capturing traffic into TOP R>b-2d0 (all scales if this cutoff<a) and INTERIOR R<=b-2d0. The top is bounded by the CLOSED hard-scale envelope on[max(a,b-2d0),b], mass

 1+n log[b/max(a,b-2d0)]<=1+n log(1+2/n)<=3.

Do not define actual top by strictR>max(a,b-2d0), which would omitR=a if b-2d0<a. A positive original gate boundedby1 may be retained; its source is fixed before receivers. Thus top costs<=3W_H.

On INTERIOR, z in fine C and Q_R(x) implies C subset Q_(R+2d0)(x). The larger radius is legal at the SAME receiver, so native full allradius ceiling gives

 H_C=mu_hi(C)<=4lambda(R+2d0)^n<=4e²lambda R^n.

Consequently t_C^n<=B R^n, B=4lambda sqrt(n)/q<= (16/3)sqrt(n). Any failed birth R<t_C is therefore in the SOURCE-FROZEN interval[t_C/B^(1/n),t_C), intersect[a,b]. Its hard-envelope mass is at most1+logB. By Tonelli over the fixed nu_H (and dropping gates only in the positive majorant), interior failed-birth traffic costs<=(1+logB)W_H. Together

 T_(top or interior failedbirth)<=[4+log((16/3)sqrt(n))]W_H.

The remaining actual branch has legal interior and t_C<=R exactly. This only uses the same-E full cap, full source domination, fixed original fine labels and gate<=1; it does not require soft FIRST, component mass control or a hypothetical density ceiling. It applies to the native H_native,hi source cap/excess and also any other actual fixed dominated source for which these fine labels are defined. It does NOT supply the other FULL/LCA/CP/GP/history gates or a root estimate for the resulting qualified heavy branch. Source/input semantics and original entry multiplier must still be retained. This constructive candidate was sent to the primary for an independent author check, not promoted here as a completed chain.

## Actual local diagnostics

{'atomic_stieltjes': 432, 'rank_crossings': 1728, 'initialization': 144, 'birth_window_power': 19}

Executed exact Python Fraction diagnostics for discrete inclusive Stieltjes identities (terminal atom included), capture atoms crossing d/H, common-quota initialization and powered birth-window inclusion. All PASS. These are algebraic/endpoint checks, not continuum FIRST/kernel realization or a source-root theorem. Author comparisons and final bindings follow below.


## 5. Independent native fine-cell connector screens before author proof

Screened the supplied native H_native,hi statements without reading the new author file. Its actual scalar gate is<=G_hi<=4/7 and its full hard row is<=lambda. Put Wres=nu_res(total) for nu_res=(dmu_hi/dz-sqrt(n)lambda)_+dz. Fine-cell mass H_i is ALWAYS the complete fixed mu_hi(F_i), while actual traffic source remains nu_res<=mu_hi; no capped mass or heavy-component mass is substituted for H_i.

The native allradius failure window in §4 therefore sharpens to (4/7)(4+lnB)Wres, B=4lambda sqrt(n)/q. Its top bound may be applied only to failed-birth top traffic and upper bounded by the whole top window; then the three birth branches remain exact. Alternatively remove ALL top traffic first and retain interior near/deep branches. Either is coherent, but definitions must state which; source gates/denominators are never recomputed.

An independent alternative fails-birth payment is also valid without the allradius window argument. For active failed-birth fine cells, t_i>a and r_i=min(b,t_i)>=a. Capturing receivers lie in U_i=F_i+Q_(r_i), whose volume (r_i+a/n)^n<=e r_i^n<=H_i sqrt(n)/(e q). EACH cell's traffic row is<=the full actual native rowlambda, so summing nonnegative cell contributions gives (lambda/q)(sqrt(n)/e)Whi. Overlapping U_i cause no missing fee because the cell-wise source contributions are summed and the complete H_i sum equalsWhi. This is an ALTERNATIVE upper bound for the same failure traffic, not an extra disjoint payment; the logarithmic Wres method is the primary stronger native route.

For the source-frozen nearbirth packet nu_res|F_i, radius lies in[a,b] intersect[t_i,t_i exp(L/n)], including both endpoints. Its one-column hard envelope has mass1+n ln(rplus/rminus)<=1+min(L,n ln(b/a)); empty intervals contributezero. Actual gate<=4/7 gives total nearbirth fee (4/7)[1+min(L,n ln(b/a))]Wres after summing disjoint fine sources. t_i=0 has no positive nu_res mass; t_i>b gives empty nearbirth but may active failure. This does not use component FIRST or a new source input. At L=sqrt(n), remaining deep trafficR>t_i exp(L/n) obeys strictly H_i<e²q R^n exp(-sqrt(n))/sqrt(n), with t_i<=R automatically. Its original owner/component/capture gates remain. This pays a genuine fine-cell birth-failure/near-window entrance, not the other original FULL/LCA/CP/GP/history qualifications.


## 6. Full-source main birth-field variant — independent PASS before author proof

For the direct R316 complete-input entrance, there is no need to invoke the optional high-source soft-FIRST route. Keep nu_res=(f-sqrt(n)lambda)_+, actual G_N=lambda/M<=1/2, and the full native hardband. Define NEW fixed fine-cell masses m_i=integral_(F_i)f and s_i^n=m_i sqrt(n)/(e²lambda). These are new full-f labels, not the historical mu_hi,t_i. The exact same legal enlarged-scale argument gives s_i^n<=4sqrt(n)R^n at interior captures, so B=4sqrt(n). Failed birth costs<=one-half[4+ln(4sqrt(n))]Wres. Near s_i<=R<=s_i exp(L/n) costs<=one-half[1+min(L,nln(b/a))]Wres. Therefore

 H_native<=one-half[5+ln(4sqrt(n))+min(L,nln(b/a))]Wres+H_deep,f,
 X_band<=768/767{P104(f,lambda)+samefee+H_deep,f}.

This main statement is unconditional for the original complete-input hardband (under the accepted R104 theorem). It retains the actual old owner/component/capture masks and uses true Lebesgue receivers. H_deep,f obeys m_i<e²lambda R^n exp(-L)/sqrt(n) at each participating fine source cell. Choosing L=sqrt(n) adds only source-root/log fees; no Bpre or soft deletion is needed. The new deep field is NOT an identity with legacy fine-cell birth, FULL or low-pe traffic. The optional mu_hi variant remains a separate valid statement when that source contract is wanted.

## 7. Atom-correct potential author comparison — PASS

Read /tmp/r317_potential.md after the independent screen; frozen SHA25674274db4e344c69a9ba941448e460b3845a527aaf6f3a9c6b6fbb5e7d18b89fe. Exact physical Stieltjes identity, signed whole crossing-atom remainder, common rankH initialization and terminalb handling agree with the independent derivation. Its signed Fubini is justified by the actual first-moment budget because |dg(A)|<=dA. No continuous-only chain rule is applied to jumps.

The useful refinement over pricing initialization separately is correct: Low+Init=E_early-(d/H)integral_cross tau^(-n)M_H, so both merge within the already-paid4lambda H Wbeta. The common post-H quota flux identity Rtent=Init+N_(H,d)-(d/H)N_(H,H) has the full signed crossing remainder and recovers exactly the R313 first-d quota after the other capacity terms are rejoined. This is not an additional resource or new general root fee. The terminal alternative(1-d/H)Wnu is legitimate and not counted on top of the complete R315 top payment. No correction requested. The1480 diagnostics are finite-menu scalar/endpoint checks only.

## 8. Receiver projection-energy candidate — independent screen

Before its author proof, screened the supplied actual-receiver projection certificate at fixedz,r. Original v(y,z,r) is endpoint-independent, p_y=A_yz/J_y on activity. Define rho_v(x)=integral_beta vU_y(x)1{R(x)<=r}, b_v(x)=integral_beta vU_y(x)p_y1prefix. Then E_v=integral_beta vA²/J=integral dx integral_beta vU p², and receiverwise Jensen gives E_v>=integral b_v²/rho_v>=sum_cells B_i²/M_i for a shared actual receiver partition. Mi=0 impliesBi=0. Hence tent=C_v-E_v<=C_v-sum B_i²/M_i. Refining the actual common partition decreases this upper certificate. rho_v<=rho<=1 is inherited, not a new source or receiver selection. Taking a pointwise minimum with another valid per(z,r) census upper bound is lawful and pays each original source once.

No new source-root estimate follows merely from projection/refinement. A sigma0 fixed-kernel fixture can diagnose the broad aggregate-row-upper-cap class, but cannot be called an example of native interior canonicalFIRST with sigma>c/n. Its original low-pe/m/aspect/FULL/history qualifications would need separate certification. This scope point was sent to the author.


## 9. Fine-cell native connector author comparison — PASS

Read /tmp/r317_entry.md after saving both independent birth screens. Its full-source main(F1)–(F7) and high-source alternative(1)–(18) agree with the independent proofs. All four actual branches are exact: failed TOP (still R<s_i), failed interior, near with both equalities, and strict deep. A whole-top hard window is used only as a positive upper majorant for failed TOP; it does not remove near/deep top traffic. The legal smaller cutoff, n=1, b=a/narrowband and singleton source-window cases are correctly retained.

New complete-f s_i labels, historical complete-mu_hi t_i labels, side-a ownership cells and connected heavy components are explicitly distinguished. Source traffic is the fixed capped residual, while the entire fine-cell mass in the birth label stays uncapped. The(1/2)[5+ln(4sqrt(n))+min(L,nln(b/a))]Wres coefficient, multiplied by768/767 only once, is correct; P104 remains its exact cap/residual sum and the new price is added to Wres. No Bpre/softFIRST is inserted in the main direct-fullinput route. High-source alternative has gate4/7, B=4lambda sqrt(n)/q, Bpre outside768/767 and coefficient3072/5369 on its new bracket; it is not added to the main entrance.

Its independent row-volume failure bound is valid as an ALTERNATIVE, not another expense. Sourcecell failed receivers lie in Fi+Q_min(b,ti); actual row<=lambda gives a sum proportional to complete Hi, whose cells are disjoint even though receiver supports overlap. Taking the smaller valid total failure price is permitted. No source density cap or receiver-dependent source is asserted.

The resulting Hdeep retains the entire positive H_native traffic, original truncation/ownership/component/capture masks and new strict complete-cell exponential-mass bound. It is unpriced at the required general order. Paid birth qualifications do not certify the remaining FULL/LCA/CPGP, early exit, lowpe/aspect or history hypotheses. This is a genuine new complete-hardband qualified entrance rather than a free transfer to old R_out.

Primary combined.md/research.tex formulas match this main statement; static proof reading only, no compilation. The only integration wording request was to describe README's paid TOP specifically as failed-birth TOP, since ALL TOP was not removed by this allocation. Final binding awaits the author's receiver-certificate note and final wording/evidence freeze.


## 10. Final receiver-certificate author comparison — PASS

Read final /tmp/r317_geometry.md, SHA256279fe248d9b1cb8ea5b1208d08672bd0468e68dc7400feb2866272019c3c45c4. Receiverwise conditional Cauchy-Schwarz, cellwise projection, refinement and dyadic-limit assertions agree with the independent screen. Conditional cross-row variance is EXACTLY the residual projection gap, not assumed small. The pointwise minimum with the census upper bound is lawful and does not sum duplicate source prices. Every certificate is bounded by the actual first moment. Its rank-one projection cannot be subtracted freely from a separately restricted collar/contact/far pair integral; that limitation is explicitly stated. No general source-root price is certified.

Verified the explicit positive-volume one-dimensional prescribed-kernel fixture: the two beta intervals have mass1 each, kernelP_(0,2)=1/2 on all four receiver cells, alpha is z-independent, aggregate beta row response<=q, and the global upper hard caps/source domination hold. Its exact data yield tent7/1000, census3/250, receiver certificate43/6000; on the claimed collar-far layer interval the mass is5/99, giving7/19800<43/118800<1/1650. This proves strictness of this certificate in the stated broad class only. It does NOT realize full-f canonicalFIRST, native interior-positive-softness or historical lowpe/m qualifications; these limits are explicit. The refinement tests on other matrices are algebra diagnostics only.

## 11. Final primary integration and corrections — PASS

Read current combined.md, research.tex and README.md statically; no compilation or source edits. Their main unconditional statement correctly applies the COMPLETE full-f hardband R316 entrance, with coefficient768/767 and unchanged exact P104, to the actual newly qualified deep-birth H_native remainder. New bracket source price is added to Wres and not maximized against unrelated fees; no new epsilonX absorption is introduced. The high-source version is an alternative and Bpre stays outside its multiplier. Fixed complete-f cell fields and historical mu_hi cell fields remain distinct.

The exact four-way partition is failedbirth TOP, failedbirth interior, near with endpoint equalities, strict deep. Entire TOP is a positive upper majorant only for the failedbirth part. The README wording was corrected to say birth failure(TOP and interior), avoiding an assertion of payment for all TOP. Actual TOP remainsR>b-2a/n, notR>max(a,b-2a/n), soR=a is retained correctly in narrow bands. Boundaryb=a and zero-mass cells need no illegal radius or division. Strict deep property remains a complete cell-mass bound, not pointwise density control.

The original tent note's whole J-crossing atom, d/H capture crossings, signed continuation, low+initialization merger, terminal alternative and original quota equivalence are all faithfully retained. This is accurate bookkeeping, not a second root payment or a transfer of the negative flux through a new gate. Physical-radius atoms are not history time atoms. The receiver projection certificate is presented as an improvement with an unproved integrated price, and is not inserted as a source-paid term into the full native entry.

A prefinal checkpoint geometry copy lacked the explicit offactivityp=0 guard and final diagnostic-scope paragraph. The primary synchronized it to the final author proof; checked BYTE-IDENTICAL final geometry copies and current TeX's zero guard. No mathematical change or further test rerun was required for that synchronization.

## 12. Actual evidence and its exact scope

Inspected primary fresh logs and scripts: potential1480 checks on90 finite menus, birth1313 checks over dimensions through256, receiver geometry237 grouped checks(17geometry,109projection,109refinement,2strictfixture), total3030. The potential checkpoint JSON is byte-identical to its author frozen result. The source-window script checks exact finite parameter/endpoint algebra only; it does not claim an actual f/FIRST construction. The receiver note's single interval fixture genuinely uses positive-volume prescribed kernels but lacks original historical qualifications. Its other matrices are algebra diagnostics. These execution statements are attributed to the primary fresh runs whose logs were read, not a duplicate execution by this reviewer.

This reviewer's independently executed local diagnostics are432 atomic Stieltjes,1728 rank-crossing,144 common-quota initialization and19 powered birth-window checks. These2323 are separate from the primary3030, and finite diagnostics do not substitute for the analytic measure/source-envelope proofs. No asymptotic fit, expanded counterexample campaign or new input-family claim was used.

## Frozen reviewed bytes

Checkpoint root:/Users/zhengzhihao/Desktop/T/output/centered_cube_round317_20261018_final_checkpoint.

| File | SHA-256 |
|---|---|
| /tmp/r317_entry.md | e25ad73ba8acd0757027f78e1608c3c78f921ff454c5a9924ba8890555b1bbb6 |
| /tmp/r317_potential.md | 74274db4e344c69a9ba941448e460b3845a527aaf6f3a9c6b6fbb5e7d18b89fe |
| /tmp/r317_geometry.md | 279fe248d9b1cb8ea5b1208d08672bd0468e68dc7400feb2866272019c3c45c4 |
| checkpoint/entry.md | e25ad73ba8acd0757027f78e1608c3c78f921ff454c5a9924ba8890555b1bbb6 |
| checkpoint/potential.md | 74274db4e344c69a9ba941448e460b3845a527aaf6f3a9c6b6fbb5e7d18b89fe |
| checkpoint/geometry.md | 279fe248d9b1cb8ea5b1208d08672bd0468e68dc7400feb2866272019c3c45c4 |
| checkpoint/combined.md | dc49ecd64bde0e6540be5a994100984e9c1422e14c1067cf167a75e89da10834 |
| checkpoint/research.tex | 483a80940157385d4f80b4517b24076c2d65f37e23a19d515f8c217c8a822cf4 |
| checkpoint/README.md | 7ee078b8f88239d311d335d9f8845238fe8b0b4bdff71841ad788efbeb5b5f18 |
| checkpoint/potential_checks.py | 863c4ded4e7ed3758e823e5c7fb780800076a49977b1ae563d23e94934c4f68a |
| checkpoint/potential_checks.json | 1480323fdf8a3cf64d9a0df01eaa679469760d6bb5978ec0578793005075a66f |
| checkpoint/potential_checks.log | 0afe71b098e760e110d0387c9e3ee69dc8cbac4de14b7329107a2d4d7e445fbb |
| checkpoint/birth_checks.py | 64c162d217fdca3fa7379610a449d5b9d297bf1bd4f7ee40a3c8ab8cdb7d72f4 |
| checkpoint/birth_checks.json | 803b89008f63c791f08e8b370b6d380382fe5ccc15a947c896419e4ec06563d5 |
| checkpoint/birth_checks.log | 8b0d5b1cb0e8ad384edab9a4bfd40d495fe6e2bd093e67dcbe88b4750aad3faa |
| checkpoint/geometry_checks.py | c71c96eead76bdc5763ac8647b3c962f113fef12725e27ccd3a5d01f0761d424 |
| checkpoint/geometry_checks.log | 8c09ba2a6629b19ee55a1d78555ee3f67db30e04dbb60aa88e88521c1661eded |

## Final verdict and exact outstanding obligations

PASS for the bounded mathematical results and their final integration. This round genuinely source-pays the complete failed/near fine-cell-birth complement of the direct native heavy traffic, preserving the general complete-hardband entrance. The remaining H_deep is the actual source/capture/component-qualified positive traffic with strict complete-f fine-cell exponential-mass bound; it is not oldR_out or a proved source-root fee. A direct estimate for it, or a qualification-preserving further split with its entire failure complement paid, remains necessary.

Separately, the old weighted low-capture collar-far geometric fee remains unpriced. Tent Stieltjes identities, merged initialization and receiver projection do not close it. No FULL/LCA/CPGP/history, lowpe/aspect or native-to-old target equivalence is silently inherited. If such a history route is constructed, its true initial/deletion-jump/future-deleted continuous/suffix/wide/aspect terms and coefficients must arise from an actual identity and remain; they are not appended without identity to the new native heavy ancestor and are not erased. Cross-physical-octave/all-scale assembly is outside this proof. No general weak-type closure or final global absorption is certified. Final audit frozen; stop bounded.
