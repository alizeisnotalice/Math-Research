# R637 whole-row 限制与混合尺度正控制：独立精确审查

先读 CONTRACT/BASE，独立证明 whole-row 规则限制并独立解析控制输入，再读取 `joint_geometry.md` 对照。第二部分实际运行本机数学 Python 的 Fraction，全数有理认证；没有浮点 LP、git、仓库或他人文件改动，没有新代理。

**结论：两项均通过。** whole-row clique 规则不可能在 hard 分支给正 D；指定混合尺度控制例全部 membership、AC 盒余量、旧 KKT、严格新见证、真实 receiver union 和 D=V/5 均正确。后者是 nonhard 正控制，不是 hard 主步。

## 1. 全族 whole-row clique 规则限制

设每个 selected cube `C_l=Q(y_l,ρ_l)` 的完整需求 `d_l=(2ρ_l)^n` 指派给一个包 p(l)。包 p 的质量 b_p≥0、支撑位于所指派全部 cubes 的正体积共同交内，并独自满足 `b_p≥max_{p(l)=p}d_l`。容量总质量 `B=Σb_p`。

对每个非空包，从共同交取 x_p。令 `ρ_p=max_{p(l)=p}ρ_l`。对所有 assigned receiver 点 z∈C_l/a，逐坐标有

\[
\|z-x_p\|_\infty<(1+1/a)\rho_l\le(1+1/a)\rho_p.
\]

所以

\[
\left|\bigcup_{p(l)=p}C_l/a\right|
\le(1+1/a)^n\max_{p(l)=p}d_l\le Pb_p.
\]

将全部实际 receiver 取并，准确得到

\[
\boxed{V_{\rm new}\le PB,\quad
V_{\rm new}-RB\le(P-R)B.}
\]

hard 条件 R>6PH、H≥32 给 R>P；非空 selected family 的 B>0，因此 D 严格负。空族只给 0。所有 selected rows/尺度均被计入，无包数倍增或独立 M。

与作者 `joint_geometry.md` §2 逐行对照一致。该限制只针对“每行由一个 clique 包独自支付全部需求”的规则。若一个 row 的需求由多个容量 cells/cliques 共同分摊，b_p 可以小于该 row 的完整需求，上述指派假设不成立，不能据此否定一般容量模型。共同 source 可达性也不改变这条容量/receiver 几何界。

## 2. 正控制的准确坐标与半径含义

本例 n=2、a=64、H=32。旧“大星”A_j 半边长为 1，旧 receiver B_j 半边长为 1/a。宏中心是 CONTRACT 所给实际 C5 中心的 9/10，即

\[
y_0=(0,0),\ y_1=(81/50,0),\ y_2=(54/25,81/50),
\quad y_3=(27/50,63/25),\ y_4=(-9/10,63/50).
\]

新大星半边长为 `(6/5,1,6/5,1,1)`。全部使用半边长；没有把直径 2 误作半径。

旧严格交图的边为 `01,12,23,34,40`，无 triangle。新严格交图增加 `02`，其全部 maximal positive-volume cliques 为 `012,23,34,40`。Fraction 枚举全部 31 个非空标签子集，新正体积 cliques 共 12 个（含单点及非 maximal）。不存在仅边界交被错误计入的 clique。

## 3. μ 的真实盒 membership 与余量

每个 source 小盒的半边长 h=1/200，分别在以下中心放质量 m/2，并均匀摊开：

| 盒 | 中心 | 旧 membership | 新 membership | 旧最小内余量 | 新最小内余量 |
|---|---|---|---|---:|---:|
| 01 | (49/50,4/5) | 01 | 012 | 3/200 | 3/200 |
| 12 | (59/50,4/5) | 12 | 012 | 3/200 | 3/200 |
| 23 | (6/5,2) | 23 | 23 | 7/200 | 47/200 |
| 34 | (0,9/5) | 34 | 34 | 19/200 | 19/200 |
| 40 | (0,4/5) | 04 | 04 | 19/200 | 19/200 |

内余量定义为对所列全部 member cubes 取 `ρ−||盒中心−星中心||∞−h` 的最小值，故认证的是**整个小盒严格位于交内**。

对每一个未列 member 的 star，亦检查至少一个坐标严格分离整个盒：`max_i|center_i−y_ji|−h−ρ_j>0`。旧所有这类外余量的全局最小值为 7/40；新最小值为 119/200。因此没有 partial membership 或中心测试代替整盒的问题。

五盒面积均为 1/10000，可用真实密度 `5000m` 在每盒均匀放 m/2；它们互不交。μ 是一个真实非负 L1 来源，非原子代理。

## 4. 旧 source KKT 与最优 λ 精确通过

\[
P=(65/64)^2=4225/4096,\quad
\epsilon=(64P)^{-1}=64/4225,
\]

\[
v=4/a^2=1/1024,\quad
m=4+2\epsilon v=135201/33800,
\quad \lambda_j=1/2.
\]

旧 receivers 两两不交，其最小分离余量 `||y_i−y_j||∞−2/a` 为 983/800>0，所以 v_j=v、V=5/1024 是真实 increments/union，而非体积和代理。

每个旧 A_j 接收恰好两个 edge boxes，故 μ(A_j)=m。旧交图为 C5，λ_j=1/2 在全部旧 source cells 可行；在 μ 支撑的每个 edge cell，Lλ=1。并且

\[
\lambda_j(m-4)=\epsilon v,\quad
Q=\sum_j\lambda_jd_j=10,
\]

\[
M=5m/2=135201/13520=Q+\epsilon V,
\quad R=V/Q=1/2048=2/a^2.
\]

这些条件也认证 λ 的 regularized 最优性，而非只验矩：目标的梯度在 λ 处为 m_j；对任意旧可行 θ，`Σθ_jm_j=∫Lθdμ≤M=Σλ_jm_j`。凹性给一阶 supporting inequality，正 v_j 的 log 项严格凹，故该正 λ 为唯一 regularized 最优解。

## 5. 同一 μ 的全部新见证严格合法

新大星积分逐行精确为

\[
\mu(C_0)=\mu(C_2)=3m/2=405603/67600,
\quad\mu(C_1)=\mu(C_3)=\mu(C_4)=m.
\]

其需求体积为 `(144/25,4,144/25,4,4)`。严格 surplus 依次为

\[
(16227/67600,\ 1/33800,\ 16227/67600,\ 1/33800,\ 1/33800),
\]

均为正。不是每行单独另选来源；五行同时使用第 3 节的同一 μ。

## 6. τ 的真实 AC 容量上证书

在中心 `(27/25,4/5)`、半边长 1/200 的小盒放质量 144/25；在 `(0,9/5)`、同半边长的小盒放质量 4，均匀摊开。

- 第一盒整个严格位于新 clique 012，且无其它 membership，最小内余量 23/200；密度为 57600。
- 第二盒整个严格位于新 clique 34，且无其它 membership，最小内余量 19/200；密度为 40000。
- 对未列 membership 的全盒外余量也均正，最小为 119/200。

因此新行 τ 质量为 `(144/25,144/25,144/25,4,4)`，逐行至少需求。总质量

\[
\boxed{B=\|\tau\|_1=244/25.}
\]

μ 与 τ 是两份不同、各自合法的真实 AC 对象；没有让 τ 承担旧 KKT 条件，也没有把 τ 的质量当作 μ 的额外来源。

附带精确交叉认证：新 packing 权 `ν=(1/2,0,1/2,1/2,1/2)` 在全部 12 个正体积 cliques 上均可行，目标正是 244/25。故本例 B 甚至等于实际新 linear 最优值；这不是浮点 solver 的最优性声明。

## 7. 实际 receiver union 与正目标

新 receivers 也两两不交。最小真实分离余量 `||y_i−y_j||∞−(ρ_i+ρ_j)/a` 为 1961/1600>0，因此

\[
V_{\rm new}=\frac4{a^2}\left(\frac{36}{25}+1+\frac{36}{25}+1+1\right)
=\frac{588}{25a^2}=\frac{147}{25600}.
\]

所以

\[
\boxed{V_{\rm new}-RB
=\frac{588}{25a^2}-\frac{2}{a^2}\frac{244}{25}
=\frac4{a^2}=\frac1{1024}=V/5.}
\]

全部五个标签保留，至多一个新 candidate 对应每个旧标签；新增 triangle 的实际容量变化和混合尺度更新均被完整模型表达。

## 8. whole-row 边界与 nonhard 范围

本例 τ 本身就能按 whole-row 规则指派：0、1、2 交给质量 144/25 的 clique 包，3、4 交给质量 4 的 edge 包。因此它满足第 1 节的普遍限制，没有绕过该限制。

此处

\[
R=1/2048,\qquad6PH=12675/64,
\]

远不满足困难分支。确切地 `Vnew=147/25600≤PB=10309/1024`；所以 D>0 与 `D≤(P−R)B` 完全相容。

这是一份 **nonhard 算法/模型正控制**：证明有限共同 source、实际 clique、真实 AC 容量与完整 receiver 可以同时实现一个严格正更新。它不证明 hard family 的一般正更新，不证明维数阶，也不能把本例的 whole-row τ 提升为已被第 1 节排除的一般 hard 路线。真正跨多 clique 分摊的整族容量步骤仍未证。

## 9. 实际计算与最终状态

本机 math venv 的 Python Fraction 实际运行：全盒 old/new membership 与 inside/outside 余量、所有旧/新 star 图与新全部 31 子集的正体积交、KKT、receiver pair 分离、μ/τ 所有行质量、B、Vnew、D 和 nonhard 阈值全部精确通过。无浮点近似、无 LP/MILP、无昂贵实验。

**最终：whole-row 全族限制通过；指定混合尺度正控制完整通过，无须修正；不构成困难分支或一般根阶结论。完成 bounded 独审，停止待命。**
