# R637 共同来源 / 容量有限模型独审（Sol high）

独立输入：本轮 CONTRACT 与 BASE；先核有限模型和实际 C5-clone 几何，未先读作者模型/结果。唯一写入本文件，无仓库操作、无新代理、无广扫。

**判定：按下列精确 positive-cell 约定，有限 pool 的 MIP 精确表示一份共同真实 AC 旧 KKT 来源、一个真实有限新 receiver union 和另一份共同 AC 容量上证书。Farkas 方向正确。它不是全动作最优或一般根阶估计；generic 非严格新 witness 不自动有同源 strict recovery。**

## 1. 共同 source：有限 cells 表示是精确的

将全部旧 A_j 和全部 candidate C_l 的 coordinate faces 共同细分，只保留正体积 rectangular cells C 且旧 Lλ(C)=1。记 H_jC、G_lC 为内部恒定 membership。用**单一** x_C≥0 施加

    Hx=m,
    G_lx≥d_l b_l.

对 b_l=0，第二式仅是自动的非负性；b_l=1 时才是新 witness demand。所有 selected rows 共用同一 x，不能分别解每行后拼接。

任一真实 AC 旧 KKT μ 的 cell masses 给出 x；反过来，每个可行 x 都可在各 cell 均匀摊放，构成真实非负 L1 μ_x，并精确保留全部旧矩和全部 pool candidate 积分。因 cells 是 old+candidate 的共同 refinement，这次均匀化对**有限所列约束**没有损失；这不宣称保留未列出的 canonical last-bad 半径或 all-future caps。

由 Hx=m、每个保留 column 满足 Σλ_jH_jC=1，自动有

    Σ_Cx_C=Σ_jλ_jm_j=Q+εV=M.

所以没有另领或暗改来源质量。旧 λ 是否为正则最优仍需独立的旧 packing/KKT 认证；不能由一次 candidate source 可行性替代旧 λ 的验证。

若实现按完整 old/candidate incidence pattern 去重，source/capacity 可将同 pattern 的质量合并，并在其中任一已认证的正体积 representative box 上摊放，因为这些有限约束的全部列相同。receiver pattern 去重则必须累加其全部真实 atoms 的体积，不能只用一块 representative 的体积代替整个 pattern。

边界和零体积 cells 必须删除：AC 来源不能在其上放质量。小而正的 cell 可以放有限质量（密度可以很大），不能擅加来源密度帽。positive-volume clique 必须用各坐标严格正交长判定，不能按浮点容差把点/面接触当成真实交叠。

## 2. 容量 τ 和真实 receiver union

所有 candidate star faces 细分后，仅保留其 union 内的有界正体积 cells D，足以表示一份无浪费的 AC τ。外部不在任何 candidate 中的质量可删除而不损 demand、只降低费用；不能在无限体积外部 cell 上声称均匀摊放有限质量。令 y_D≥0、A_lD=1_{D⊂C_l}，

    A_ly≥d_l b_l,   B=Σ_Dy_D.

将 y 均匀摊放即得实际 τ，且 ||τ||1=B。这些 y 不必满足旧 KKT，也不必等于 x；它们是同一 selected 新族的一份共同容量证书。所有 selected rows 必须共用这一 y。

τ 的最小质量 LP 对偶 ν≥0、Aᵀν≤1 给的是容量**下界**。目标 V_new−RB 需要实际 primal y 的质量上证书；仅有对偶下界会给过于乐观的目标上界，不能证明付款。对固定 selected family，Qlin,new≤B，因此实际可行 x,y 给

    V_new−RB ≤ V_new−R Qlin,new.

它是完整线性 deficit 的保守下界。source x 本身也能给一份质量至多 M 的新容量来源，故对 source 可行的选择，容量最优≤M；无需强迫 y 与 x 相等。

receiver atoms E 由所有 C_l/a faces 共同细分，并仅计 candidate receiver union 内的有界正体积 cells，w_E=|E|>0。外部 atoms 恒不覆盖，应省略而不引入无限体积权。二元 b 和

    0≤z_E≤1,  z_E≤Σ_{l:E⊂C_l/a}b_l

在正目标系数 w_E 下使每个最优 z_E 恰为 selected receiver union 的 indicator。因此 max Σw_Ez_E−RΣy 精确使用真实 union，不是逐 cube 体积和。若一个可行证书 z 不饱和，Σw_Ez_E只是该真实 union 的合法下界，目标仍保守；不能将未覆盖 atom 设为1。

每个旧**标签**最多选一个 candidate，且总 selected labels≤N。C5 的几何 clone group 不应误当成这个“旧标签”：每个保留 clone 本身是一个旧标签。删除、重复 candidate 和 receiver overlap 都应由这一计数与真实 atoms 处理，不能重新激活未计数的旧零标签。

对每个有限 pool，以上模型与所有 AC sources/capacities 的有限所列可行条件等价；但 pool 外动作、canonical all-scale conditions 及任意几何 family 都不在其最优性声明内。浮点 MILP incumbent 仍需精确可行性重放；solver upper bound 也不是一个真实正向构造。

## 3. 固定选择的 Farkas 证书方向

固定 selected rows，source 可行问题为

    Hx=m, Gx≥d, x≥0.

不可行证书可取 α 任意、β≥0，使

    Hᵀα−Gᵀβ≥0,
    α·m−β·d<0.

方向正确：若存在可行 x，则

    αm−βd=x·(Hᵀα−Gᵀβ)+β·(Gx−d)≥0,

与负号矛盾。反向完备性只是这个有限矩阵 LP 的 Farkas alternative，不依赖无限维强对偶或 AC 弱极限。β 只对应实际 selected rows；对未选 rows 可取0。

## 4. strict recovery 的准确边界

当前合同和 MIP 要求 μ(C_l)≥|C_l|，这是合法的**非严格** finite witness/capacity 更新，足以给新 Qlin≤M 和纯几何 near-S_N 比较。一般 f 的最初 strict-witness 入口保持原定义，不因这个非严格有限模型失效。

但仅有等号不能保证同一 μ 的稍小半径成为 strict-bad：例如 μ=1_C dx 时，同中心各内 cube 平均仍为1。此例只说明逻辑限制，不是本项目 hard 反例。若后续确需每个 selected candidate 在阈值1严格坏，须另认证同一 x 的共同正裕量 G_lx>d_l，或证明实际允许且误差已付的特定 strict 更新；不能把 μ 全局放大后仍称其满足旧 Hx=m、旧 KKT 和旧 M。

也不能把几何 union ∪C_l/a 自动叫作 μ 的阈值1坏域；star 中心的 witness 与整个小 receiver 的逐点平均是不同声明。当前目标使用其真实 Lebesgue union 并通过 packing 反证，未要求这种不成立的额外包含。

## 5. C5 与 clone 的独立充分构造

将题给 base centers 解释为确切 rationals：

    (0,0),(9/5,0),(12/5,9/5),(3/5,14/5),(-1,7/5),

所有大星半径1、d=4。相邻 C5 ∞距离为 9/5,9/5,9/5,8/5,7/5，非边最小∞距12/5，所以正交叠图严格为 C5、无三 clique。小 B 半径1/64，两两不交；λ=1/2 时每 edge load=1、其余≤1。在每条 edge 的正体积共同交放 m/2 质量，m=4+2ε(1/1024)，给同一 AC 来源、每 m_j=m，精确满足 KKT。

clone 的充分条件是：各五组用同一个 finite offset pattern，||offset||∞≤η<1/10；使用相同组内相对顺序，真实 positive increments v_i>0，group union U=Σv_i。上述严格间距使相邻整 groups 全部 pairwise 相交、非邻 groups 全部分离、组内全交。轴平行 boxes 的有限 Helly2 给每条 edge 两整 groups 有共同正体积交；小 receiver groups 也相互分离。因此 maximal cliques 恰为相邻两整 groups，且

    λ_{g,i}=v_i/(2U),  m=4+2εU,
    Q=10, V=5U, M=5m/2=Q+εV.

每条 edge-group 共同交内放 m/2，source membership 正好为该两个 groups。每 clone 捕获两条 incident edges 的质量 m，λ_{g,i}(m−4)=εv_i。此为同一份总质量 M，不是每 group/row 另领 M。若 offset/order 不满足真实 union 相同、receiver groups 不交或上述完整 clique 条件，就不能沿用该 λ 公式。

此 odd-C5 的 source 还可作无损核证简化：旧 tight cells 的 membership 必为相邻两整 groups，因 proper 子集的正 λ 总量严格小于1。若5条 edge-group 总质量为 s_e，则各组旧矩给 s_{e-1}+s_e=m；奇环唯一解 s_e=m/2。source 自由只剩每条 edge 共同交内的 candidate 细胞分配，不能为各 candidate 单独更换 edge 总额。已将这一精确压缩条件发给 Terra。

一个完全冻结的10-label 控制：每组 offsets (0,0),(1/64,0)，a=64,H=32，得到

    ε=64/4225,
    (v1,v2)=(1/1024,1/2048), U=3/2048,
    (λ1,λ2)=(1/3,1/6), m=270403/67600,
    Q=10, V=15/2048, M=270403/27040.

本机 Python Fraction 对全部1023个非空 label 子族计算了严格正交长：maximal cliques 恰5个相邻整 groups（各4标签），全部 clique load≤1；跨 groups 小 receiver 不交。按 edges (01,04,12,23,34) 排序，整 group 共同交体积为

    59/160,189/320,443/1600,59/320,369/1600 >0.

两种 clone 的 KKT 残差和 M−Q−εV 均精确为0。该控制已发 Terra，未作广扫。它不在 hard 分支，不能外推维数阶。

## 6. σ=1 的有限 pool：确切最优值为0

收到并只读 Terra 的 `numeric/reachability_sigma1.json`、`numeric/mixed_control_sigma9.json` 及脚本；随后主代理告知独立 Terra 已从实际盒重建全部 sourcecells 并完成重放，故本审**没有重复这批计算**。具体数字认证依据 `/tmp/ccu_r637/independent_numeric/REPORT.md` 和 `reachability_results.json`。

这批 K=1,2,4 控制每组 offsets 为 i/256，和本报告§5另外给出的2-clone offset 1/64控制不同；不能混用其 U、m、λ 数据。以下均使用各实际证书的 U、m，仍满足 Q=10、V=5U、R=U/2。

独立 receipt 逐个实际 positive source pattern 核过20+40+80=140份负 gap Farkas 证书，排除 pool 列出的四种扩大尺度 65/64、6/5、7/5、3/2 的每个相应 single candidate。这是对各该单行、所有合法共同 KKT 来源的排除，因此也排除任何包含该行的共同选择；它没有把逐行可行性错误拼成共同可行性。

**范围必须限制为所列 finite pool。** 不能说所有连续 ρ>1 都不可达：旧 μ(A_j)=m>4 已保证同中心 Cρ⊃A_j 在 1<ρ<sqrt(m/4) 时自动严格可达，只是这些极小扩大不在本 pool 中。

现在只余尺度1的旧 clones 可选。对任意 selected subset，设有 k 个非空 macro groups。各组真实 receiver union 至多 U，不同 groups receivers 不交，所以

    V_sel≤kU.

每个非空 group 任取一个 selected clone、赋 packing 权1/2，其余权0。旧 C5-clone 图中每个 clique 至多含相邻两个 groups，故这是 selected 星族的可行 packing，给

    Qlin,sel≥2k.

于是包括空选择在内，

    V_sel−R Qlin,sel≤kU−(U/2)(2k)=0.

任一实际容量 τ 的 B≥Qlin,sel，其 MIP 正向目标亦≤0。另一方面，选全部旧 clones，每条 edge-group 共同正体积交内放容量质量2，得到同一 AC τ、B=10，所有需求为4；旧 KKT 来源本身同时见证全部选行，真实 receiver 为5U，因此达到目标0。

**结论：这三个 σ=1 冻结 finite pools 的真正最优正向目标均精确为0。** 这是利用已认证单行不可达性加全族解析上界的有限结论，不是依据浮点 MILP gap，也不排除 pool 外动作或一般几何。

## 7. σ=9/10 混合 selected families：Qlin=B，完整目标通过

独立 receipt 从实际 rectangles 精确核过 K=1,2,4 的共同旧 KKT 来源、所有新 strict witnesses、τ、真实 receiver union。每个旧标签仅选一个新星：macro groups 0、2 的半径为6/5，其余 groups 为1；所有 clones 保留，标签数不增。五份正面积 source boxes 共同构成一份实际 AC μ；τ 是另外两份正面积 boxes 上的同一 AC 容量，总质量

    B=244/25.

本审进一步给出不需重跑数字的容量最优性证明：任取新 group0 的一个 radius6/5 star 和 group3 的一个 radius1 star。其纵向中心距离为63/25，而半径和为11/5=55/25，严格分离余量8/25。clone offsets 仅沿横向，不改变这个分离。因此这两星真正不交；给二者 packing 权各1、其余0，是全部 selected 新族的可行 packing，并给

    Qlin,new≥144/25+4=244/25=B.

receipt 已认证的共同 AC τ 给反向 Qlin,new≤B，故三个 selected families 都有

    Qlin,new=B=244/25.

因此已验的正向目标不是仅靠 τ 的保守下界，在这三份 **selected 全族** 上也恰为真实线性 deficit：

    (V_new−R Qlin,new)/V
       =1/5, 71/375, 239/1375       (K=1,2,4).

K=1 的实际数值是 V_new=147/25600、R=1/2048、D=1/1024=V/5；所有源行都有严格质量余量。K=2、4 的实际 increments、来源细节和 union 使用独立 receipt 的已验值，本审未重复重放。

这既不是 canonical-last-bad 更新声明，也不是 σ=9/10 pool 的全局最优声明。它只认证给定 selected 混合族的完整共同 source/容量/receiver 及真实 D。它们不在 hard 分支，不能外推一般维数预算。σ=1 的某些新星仅边界相触而 σ=9/10 有真实正体积新 clique，这种实际几何差别不能由浮点边界 clique 替代。

## 8. 最终验收状态

有限 MIP 的共同来源表示、Farkas 方向、真实 AC 容量上证书、正体积/真 union/标签数及旧 KKT 量词均通过本审限定。已追加两个解析收口：σ=1 finite-pool exact optimum=0；σ=9/10 三个 mixed selected families 的容量恰为 B，故给出的 D/V 是各自真实线性 D。

实际计算分工：本审自己只做§5冻结10-label几何的轻量 Fraction 检查；140负 gap及三份 mixed 几何/来源/τ重放由独立 Terra 完成并有 receipt，本审只读取其记录并作上述解析回代，没有重复 MILP或数字批次。一般困难族统一正更新、canonical 完整 D 预算与根阶目标仍未证明。

唯一写入文件为本报告；完成 bounded 独审，停止。
