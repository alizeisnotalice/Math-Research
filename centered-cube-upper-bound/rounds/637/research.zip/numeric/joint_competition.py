#!/usr/bin/env python3
"""Exact shared-source guard: individual feasibility is not joint feasibility."""
from fractions import Fraction as F
from pathlib import Path
import json,sys,platform

def cube(x,r):return ((x-r,x+r),(-r,r))
def inside(s,b):return all(lo<sl and sh<hi for (sl,sh),(lo,hi) in zip(s,b))
def area(b):return (b[0][1]-b[0][0])*(b[1][1]-b[1][0])

def run():
 a=64; eps=F(1,64)/F(65,64)**2;v=F(4,a*a);m=4+2*eps*v
 old=[cube(F(-1,20),F(1)),cube(F(1,20),F(1))]
 new=[cube(F(-1),F(9,10)),cube(F(1),F(9,10))]
 witnesses=[cube(F(-1,2),F(1,100)),cube(F(1,2),F(1,100))]
 assert F(1,10)>F(2,a) # true old receivers disjoint
 assert old[0][0][1]>old[1][0][0] # full old simplex; lambda=(1/2,1/2)
 assert all(area(b)==F(81,25) for b in new)
 for j,w in enumerate(witnesses):
  assert all(inside(w,b) for b in old) and inside(w,new[j])
  assert m>area(new[j])
  assert m==4+eps*v/F(1,2)
 assert new[0][0][1]<new[1][0][0]
 # On every old tight cell H1=H2=1; G1+G2<=1 because new cubes disjoint.
 # alpha=(1,0), beta=(1,1) is a common exact Farkas certificate.
 alpha=(1,0);beta=(1,1);gap=m-sum(area(b) for b in new)
 assert gap<0
 return {'status':'PASS','scope':'two separate actual KKT sources each feasible; no common KKT source for both new witnesses; finite nonhard guard','old_mass':str(m),'new_demands':[str(area(b)) for b in new],'alpha':alpha,'beta':beta,'strict_farkas_gap':str(gap),'python':sys.version,'platform':platform.platform()}
if __name__=='__main__':
 result=run();Path(__file__).with_name('competition_result.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS exact individual/joint source distinction')
