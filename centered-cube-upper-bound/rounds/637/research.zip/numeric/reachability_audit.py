#!/usr/bin/env python3
import sys,json,itertools,hashlib,time,resource,platform,concurrent.futures,os
from pathlib import Path
from fractions import Fraction as F
from geometry import box,union
P=Path(__file__).resolve().parent;SRC=P

def run(K):
 reach=json.loads((SRC/'farkas_certificates.json').read_text());entry=next(x for x in reach['cases'] if x['K']==K)
 macros=[(0,0),(F(9,5),0),(F(12,5),F(9,5)),(F(3,5),F(14,5)),(-1,F(7,5))];centers=[(F(x)+F(i,256),F(y)) for x,y in macros for i in range(K)]
 N=len(centers);scales=[F(1),F(65,64),F(6,5),F(7,5),F(3,2)]
 old=[box(c,F(1)) for c in centers];cand=[box(c,r) for c in centers for r in scales];U=(4+F(K-1,2))/64**2;v=[F(4,64**2) if i%K==0 else F(1,2*64**2) for i in range(N)];small=[box(c,F(1,64)) for c in centers];prefix=F(0)
 for i in range(N):
  current=union(small[:i+1]);assert current-prefix==v[i];prefix=current
 assert prefix==5*U
 lam=[x/(2*U) for x in v];eps=F(1,64)*F(64,65)**2;m=4+2*eps*U;assert all(4+eps*v[i]/lam[i]==m for i in range(N))
 # Recreate every open Cartesian cell from all old and candidate face coordinates.
 def axis_masks(axis):
  j=axis*2;edges=sorted({t for b in old+cand for t in b[j:j+2]});out=[]
  for x,y in zip(edges,edges[1:]):
   midpoint=(x+y)/2; oldmask=sum(1<<i for i,b in enumerate(old) if b[j]<midpoint<b[j+1]);newmask=sum(1<<i for i,b in enumerate(cand) if b[j]<midpoint<b[j+1]);out.append((oldmask,newmask))
  return out
 X=axis_masks(0);Y=axis_masks(1); patterns=set();allcells=0
 for (ox,cx),(oy,cy) in itertools.product(X,Y):
  om=ox&oy;cm=cx&cy;load=sum((lam[i] for i in range(N) if om>>i&1),F(0));assert load<=1
  if load==1:patterns.add((om,cm));allcells+=1
 assert patterns
 checked=0
 expected={i*len(scales)+j for i in range(N) for j in range(1,len(scales))};assert {r['candidate'] for r in entry['rows']}==expected and len(entry['rows'])==len(expected)
 for row in entry['rows']:
  idx=row['candidate'];i=row['label'];r=F(row['scale']);assert idx==i*len(scales)+scales.index(r) and F(row['demand'])==4*r*r
  alpha=list(map(F,row['alpha_by_group']));assert len(alpha)==5
  dotm=m*sum(alpha);assert dotm==F(row['max_mass']) and dotm-F(row['demand'])==F(row['gap'])
  if dotm>=F(row['demand']):continue
  for om,cm in patterns:
   lhs=sum((alpha[j] for j in range(5) if om>>(j*K)&1),F(0));rhs=(cm>>idx)&1;assert lhs>=rhs,(K,idx,om,cm,lhs,rhs)
  checked+=1
 assert checked==20*K
 return {'K':K,'source_grid_cells':len(X)*len(Y),'saturated_source_cells':allcells,'distinct_patterns':len(patterns),'negative_certificate_count':checked,'pattern_inequalities':checked*len(patterns)}
if __name__=='__main__':
 start=time.monotonic();cpu=time.process_time();workers=min(os.cpu_count() or 1,3)
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:out=list(pool.map(run,(1,2,4)))
 assert sum(z['negative_certificate_count'] for z in out)==140
 result={'status':'PASS','cases':out,'python':sys.version,'workers':workers,'platform':platform.platform(),'wall_s':time.monotonic()-start,'cpu_parent_s':time.process_time()-cpu,'rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'reachability_sha256':hashlib.sha256((SRC/'farkas_certificates.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (P/'reachability_results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS all 140 negative certificates across all source cells')
