#!/usr/bin/env python3
import os,sys,json,time,resource,hashlib,warnings
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import numpy as np,scipy
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import lil_matrix,csc_matrix
NTHREAD=int(os.environ.get('R637_THREADS','15')); K=int(sys.argv[1]); sec=int(os.environ.get('R637_SECONDS','30')); start=time.perf_counter();cpu=time.process_time();a=64;eps=F(1,64)/F(65,64)**2
vertices=[(F(0),F(0)),(F(9,5),F(0)),(F(12,5),F(9,5)),(F(3,5),F(14,5)),(F(-1),F(7,5))];offs=[F(i,4*a) for i in range(K)];centers=[(x+h,y) for x,y in vertices for h in offs];N=len(centers); scales=[F(1),F(65,64),F(6,5),F(7,5),F(3,2)]
def box(c,r):return [(c[0]-r,c[0]+r),(c[1]-r,c[1]+r)]
old=[box(c,F(1)) for c in centers];oldB=[box(c,F(1,a)) for c in centers]; cand=[box(c,r) for c in centers for r in scales]; recv=[box(c,r/a) for c in centers for r in scales];L=len(cand)
def arrangement(boxes,off=0):
 cuts=[sorted({z for b in boxes for z in b[i]}) for i in (0,1)];axes=[]
 for j in range(2):
  axis=[]
  for l,u in zip(cuts[j],cuts[j][1:]):
   mid=(l+u)/2;mask=sum(1<<i for i,b in enumerate(boxes) if b[j][0]<mid<b[j][1]);axis.append((mask,l,u))
  axes.append(axis)
 cells={};
 for mx,x0,x1 in axes[0]:
  for my,y0,y1 in axes[1]:
   key=mx&my
   if not key:continue
   vol=(x1-x0)*(y1-y0)
   if key not in cells:cells[key]=[F(0),[[x0,x1],[y0,y1]]]
   cells[key][0]+=vol
 return cells,tuple(map(len,axes))
def inc(mask):return [i for i in range(N) if mask>>i&1]
oldcells,_=arrangement(old);big_groups=set()
for mask in oldcells:
 gs=frozenset(i//K for i in inc(mask));big_groups.add(gs)
 assert len(gs)<=2 and (len(gs)<2 or (max(gs)-min(gs)) in (1,4))
assert all(frozenset((i,(i+1)%5)) in big_groups for i in range(5))
rcells,_=arrangement(oldB);v=[F(0)]*N
for mask,(vol,_) in rcells.items():v[min(inc(mask))]+=vol
U=[sum(v[g*K:(g+1)*K]) for g in range(5)];assert len(set(U))==1 and U[0]>0
lam=[t/(2*U[0]) for t in v];assert all(x>0 for x in lam)
for mask in oldcells:assert sum(lam[i] for i in inc(mask))<=1
m=F(4)+2*eps*U[0];assert all(lam[i]*(m-4)==eps*v[i] for i in range(N));V=sum(v);Q=4*sum(lam);R=V/Q;M=5*m/2;assert M==Q+eps*V
# Source cells partitioned by original and candidate membership; retain old load exactly 1.
source_full,source_axis=arrangement(old+cand);sources=[]
for mask,(vol,rep) in source_full.items():
 om=mask&((1<<N)-1);cm=mask>>N
 if sum(lam[i] for i in inc(om))==1:sources.append((om,cm,rep))
assert sources
# Check realizable equal old moments using one source cell per C5 group edge.
edgecells=[]
for j in range(5):
 mask=sum(1<<(g*K+i) for g in (j,(j+1)%5) for i in range(K));match=next((idx for idx,x in enumerate(sources) if x[0]==mask),None);assert match is not None;edgecells.append(match)
cap_full,cap_axis=arrangement(cand);caps=[(mask,rep) for mask,(vol,rep) in cap_full.items()]
recv_full,recv_axis=arrangement(recv);receivers=[(mask,vol) for mask,(vol,rep) in recv_full.items()]
nx,ny,nz=len(sources),len(caps),len(receivers);cols=nx+ny+L+nz;rows=N+2*L+N+nz+1;A=lil_matrix((rows,cols),dtype=float);lb=np.full(rows,-np.inf);ub=np.full(rows,np.inf)
for x,(om,cm,rep) in enumerate(sources):
 for i in inc(om):A[i,x]=1
 for l in range(L):
  if cm>>l&1:A[N+l,x]=1
for i in range(N):lb[i]=ub[i]=float(m)
for j,(cm,rep) in enumerate(caps):
 for l in range(L):
  if cm>>l&1:A[N+L+l,nx+j]=1
for l,r in enumerate(scales*(N)):
 d=4*r*r;A[N+l,nx+ny+l]=-float(d);lb[N+l]=0;A[N+L+l,nx+ny+l]=-float(d);lb[N+L+l]=0
for i in range(N):
 for h in range(5):A[N+2*L+i,nx+ny+5*i+h]=1
 ub[N+2*L+i]=1
for z,(mask,vol) in enumerate(receivers):
 row=N+2*L+N+z;A[row,nx+ny+L+z]=1
 for l in range(L):
  if mask>>l&1:A[row,nx+ny+l]=-1
 ub[row]=0
# At least one selected; empty solution can be checked separately.
for l in range(L):A[rows-1,nx+ny+l]=1
lb[rows-1]=1
c=np.zeros(cols);c[nx:nx+ny]=1./float(Q);c[nx+ny+L:]=[-float(vol/V) for mask,vol in receivers]
intg=np.zeros(cols);intg[nx+ny:nx+ny+L]=1
upper=np.full(cols,np.inf);upper[nx+ny:]=1
pre={'K':K,'N':N,'candidates':L,'source_axis':source_axis,'source_patterns':nx,'capacity_axis':cap_axis,'capacity_patterns':ny,'receiver_axis':recv_axis,'receiver_pattern_count':nz,'variables':cols,'rows':rows,'nonzeros':int(A.nnz),'v':[str(x) for x in v],'U':str(U[0]),'lambda':[str(x) for x in lam],'m':str(m),'Q':str(Q),'V':str(V),'R':str(R),'M':str(M),'geometry':{'centers':[[str(x),str(y)] for x,y in centers],'scales':list(map(str,scales))},'eps':str(eps),'old_edge_source_cells':edgecells,'source_cells':[{'old_mask':str(om),'candidate_mask':str(cm),'rep':[[str(t) for t in p] for p in rep]} for om,cm,rep in sources],'capacity_cells':[{'candidate_mask':str(mask),'rep':[[str(t) for t in p] for p in rep]} for mask,rep in caps],'receiver_patterns':[{'candidate_mask':str(mask),'volume':str(vol)} for mask,vol in receivers]}
out=Path(__file__).resolve().parent; (out/f'geometry_K{K}.json').write_text(json.dumps(pre,separators=(',',':')))
print(json.dumps({k:pre[k] for k in ['K','N','candidates','source_axis','source_patterns','capacity_axis','capacity_patterns','receiver_axis','receiver_pattern_count','variables','rows','nonzeros','Q','V','R']}),flush=True)
with warnings.catch_warnings():
 warnings.simplefilter('ignore',RuntimeWarning)
 result=milp(c,integrality=intg,bounds=Bounds(np.zeros(cols),upper),constraints=LinearConstraint(csc_matrix(A),lb,ub),options={'time_limit':sec,'mip_rel_gap':0.0,'threads':NTHREAD})
solution={'status':int(result.status),'message':result.message,'success':bool(result.success),'objective_scaled':float(result.fun) if result.fun is not None else None,'dual_bound':getattr(result,'mip_dual_bound',None),'mip_gap':getattr(result,'mip_gap',None),'node_count':getattr(result,'mip_node_count',None),'selected':[],'source_positive':[],'capacity_positive':[],'receiver_positive':[],'objective_unscaled':None,'objective_normalized':None,'max_integrality_error':None}
if result.x is not None:
 X=result.x;solution['selected']=[l for l in range(L) if X[nx+ny+l]>0.5];solution['source_positive']=[[i,float(X[i])] for i in range(nx) if X[i]>1e-9];solution['capacity_positive']=[[j,float(X[nx+j])] for j in range(ny) if X[nx+j]>1e-9];solution['receiver_positive']=[[j,float(X[nx+ny+L+j])] for j in range(nz) if X[nx+ny+L+j]>1e-9];solution['objective_normalized']=float(-result.fun);solution['objective_unscaled']=float(-result.fun*float(V));solution['max_integrality_error']=float(max(abs(X[nx+ny+i]-round(X[nx+ny+i])) for i in range(L)))
solution['run']={'python':sys.version,'scipy':scipy.__version__,'numpy':np.__version__,'threads':NTHREAD,'wall_s':time.perf_counter()-start,'cpu_s':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'geometry_sha256':hashlib.sha256((out/f'geometry_K{K}.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out/f'solution_K{K}.json').write_text(json.dumps(solution,indent=2,default=lambda x:float(x)))
print(json.dumps({k:solution[k] for k in ['status','message','success','objective_unscaled','objective_normalized','dual_bound','mip_gap','node_count','selected','run']},default=lambda x:float(x)),flush=True)
