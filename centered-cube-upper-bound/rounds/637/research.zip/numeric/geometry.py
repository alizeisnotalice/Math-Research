#!/usr/bin/env python3
import itertools,json,sys,hashlib,resource,time,platform
from pathlib import Path
from fractions import Fraction as F
sys.set_int_max_str_digits(0)
P=Path(__file__).resolve().parent

def box(c,r):return (c[0]-r,c[0]+r,c[1]-r,c[1]+r)
def area(b):return max(F(0),b[1]-b[0])*max(F(0),b[3]-b[2])
def intersect(*bs):return (max(b[0] for b in bs),min(b[1] for b in bs),max(b[2] for b in bs),min(b[3] for b in bs))
def union(bs):
 if not bs:return F(0)
 xs=sorted({v for b in bs for v in b[:2]});total=F(0)
 for l,h in zip(xs,xs[1:]):
  intervals=sorted((b[2],b[3]) for b in bs if b[0]<h and b[1]>l); y=None;end=None; length=F(0)
  for lo,hi in intervals:
   if y is None:y,end=lo,hi
   elif lo>end:length+=end-y;y,end=lo,hi
   else:end=max(end,hi)
  if y is not None:length+=end-y
  total+=(h-l)*length
 return total

def mass_at(q,sources):return sum((mass*area(intersect(q,b))/area(b) for b,mass in sources),F(0))

def run(K):
 a=64;eps=F(1,64)*F(64,65)**2; macros=[(0,0),(F(9,5),0),(F(12,5),F(9,5)),(F(3,5),F(14,5)),(-1,F(7,5))];centers=[(F(9,10)*F(x)+F(i,4*a),F(9,10)*F(y)) for x,y in macros for i in range(K)]; N=len(centers)
 old=[box(c,F(1)) for c in centers];small=[box(c,F(1,a)) for c in centers];v=[];before=F(0)
 for i in range(N):
  nxt=union(small[:i+1]);v.append(nxt-before);before=nxt
 U=(4+F(K-1,2))/a**2; assert v==[F(4,a*a) if i%K==0 else F(1,2*a*a) for i in range(N)]
 assert before==5*U
 lam=[vv/(2*U) for vv in v];Q=sum(4*x for x in lam);R=before/Q; assert Q==10
 # Partition of all old stars by exact coordinate boundaries gives all geometrical incidence patterns.
 xx=sorted({x for b in old for x in b[:2]});yy=sorted({y for b in old for y in b[2:]});patterns=set()
 for (l,h),(b,t) in itertools.product(zip(xx,xx[1:]),zip(yy,yy[1:])):
  x=(l+h)/2;y=(b+t)/2;pattern=tuple(i for i,c in enumerate(old) if c[0]<x<c[1] and c[2]<y<c[3])
  if pattern:patterns.add(pattern);assert sum((lam[i] for i in pattern),F(0))<=1
 m=4+2*eps*U;coords=[(F(49,50),F(4,5)),(F(59,50),F(4,5)),(F(6,5),F(2)),(0,F(9,5)),(0,F(4,5))]
 src=[(box(c,F(1,200)),m/2) for c in coords];
 for b,w in src:
  sat=[i for i,q in enumerate(old) if area(intersect(q,b))==area(b)]
  assert all(area(intersect(q,b)) in (0,area(b)) for q in old)
  assert sum((lam[i] for i in sat),F(0))==1
 for i,q in enumerate(old):assert mass_at(q,src)==4+eps*v[i]/lam[i]==m
 total=sum((w for b,w in src),F(0));assert total==Q+eps*before
 radii=[F(6,5),F(1),F(6,5),F(1),F(1)];new=[box(c,radii[j]) for j in range(5) for c in centers[j*K:(j+1)*K]]
 margins=[mass_at(q,src)-area(q) for q in new];assert min(margins)>0
 recv=[box(c,radii[j]/a) for j in range(5) for c in centers[j*K:(j+1)*K]];Vnew=union(recv)
 tau=[(box((F(27,25),F(4,5)),F(1,200)),F(144,25)),(box((F(0),F(9,5)),F(1,200)),F(4))]
 tau_margin=[mass_at(q,tau)-area(q) for q in new];assert min(tau_margin)>=0
 B=sum(w for b,w in tau);D=Vnew-R*B
 # Independent selected-family packing lower certificate: one clone per specified macro.
 nu={g*K:F(1,2) for g in (0,2,3,4)}
 xs=sorted({u for b in new for u in b[:2]});ys=sorted({u for b in new for u in b[2:]});cells=0;maxload=F(0)
 for (l,h),(b,t) in itertools.product(zip(xs,xs[1:]),zip(ys,ys[1:])):
  x=(l+h)/2;y=(b+t)/2;inside=[i for i,q in enumerate(new) if q[0]<x<q[1] and q[2]<y<q[3]]
  if inside:
   cells+=1;load=sum((nu.get(i,F(0)) for i in inside),F(0));assert load<=1;maxload=max(maxload,load)
 objective=sum((nu[i]*area(new[i]) for i in nu),F(0));assert objective==B

 assert Vnew==(F(588,25)+F(27,10)*(K-1))/a**2 and B==F(244,25) and D==(4+F(13,50)*(K-1))/a**2
 expected={1:F(1,5),2:F(71,375),4:F(239,1375)};assert D/before==expected[K]
 return {'K':K,'centers':[[str(x),str(y)] for x,y in centers],'newr':[str(radii[j]) for j in range(5) for i in range(K)],'V':str(before),'Q':str(Q),'R':str(R),'M':str(total),'m':str(m),'Vnew':str(Vnew),'B':str(B),'D':str(D),'D_over_V':str(D/before),'old_patterns_checked':len(patterns),'old_margins':len(old),'new_strict':len(new),'tau_caps':len(new),'nu_cells':cells,'nu_max_load':str(maxload),'nu_objective':str(objective),'min_new_margin':str(min(margins)),'min_tau_excess':str(min(tau_margin))}
if __name__=='__main__':
 start=time.monotonic();out=[run(k) for k in (1,2,4)];
 payload={'status':'PASS','cases':out,'python':sys.version,'wall_s':time.monotonic()-start,'cpu_s':time.process_time(),'max_rss_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(P/'geometry_results.json').write_text(json.dumps(payload,indent=2)+'\n');print('PASS 3 exact geometry cases')
