#!/usr/bin/env python3
import hashlib,json,os,platform,resource,shlex,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent; (P/'SUMMARY.json').unlink(missing_ok=True)
for f in ('geometry_results.json','reachability_results.json','competition_result.json'):(P/f).unlink(missing_ok=True)
if not __debug__:raise RuntimeError('assertions required; do not use -O')
start=time.monotonic();env=os.environ.copy();env.update({'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'})
stages=[]
for name in ('geometry.py','reachability_audit.py','joint_competition.py'):
 t=time.monotonic();x=subprocess.run([sys.executable,str(P/name)],cwd=P,env=env,text=True,capture_output=True,check=True);stages.append({'script':name,'wall_s':time.monotonic()-t,'output':x.stdout.strip()})
g=json.loads((P/'geometry_results.json').read_text());q=json.loads((P/'reachability_results.json').read_text());assert g['status']=='PASS' and len(g['cases'])==3 and q['status']=='PASS' and sum(z['negative_certificate_count'] for z in q['cases'])==140
assert json.loads((P/'competition_result.json').read_text())['status']=='PASS'
files=[P/x for x in ('joint_competition.py','competition_result.json','geometry.py','reachability_audit.py','verify.py','farkas_certificates.json','geometry_results.json','reachability_results.json','optional/run.py','optional/run_sigma9.py','optional/historical_six_cases.json')]
out={'status':'PASS','cases':{'positive_controls':3,'farkas_certificates':140,'common_source_guard':1},'scope':'selected-family capacity Q_C=B, not canonical Q*; finite controls not general dimension theorem','python':sys.version,'interpreter':sys.executable,'platform':platform.platform(),'cpu_count':os.cpu_count(),'workers':{'geometry':1,'reachability':q['workers']},'command':shlex.join([sys.executable,*sys.argv]),'environment':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','PYTHONDONTWRITEBYTECODE')},'stages':stages,'wall_s':time.monotonic()-start,'hashes':{str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
(P/'SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS 3 positive controls, selected-family dual, and 140 Farkas certificates + common-source guard')
