#!/usr/bin/env python3
"""R779 exact real two-price peaks, translated windows, and zero-probe comparison."""

from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(values):
    return sum(values,F(0))


def prod(values):
    result=F(1)
    for x in values:
        result*=x
    return result


def length(i):
    return max(F(0),i[1]-i[0])


def section(*intervals):
    return max(i[0] for i in intervals),min(i[1] for i in intervals)


def intersect(*boxes):
    return tuple(section(*axis) for axis in zip(*boxes))


def contains(a,b):
    return all(l<=c<=d<=r for (l,r),(c,d) in zip(a,b))


def box(centre,r):
    return tuple((z-r,z+r) for z in centre)


def volume(b):
    return prod(length(i) for i in b)


def delta(y,z,scale=F(1)):
    return (z[0]-y[1])/scale,(z[1]-y[0])/scale


def triangular_bounds(i):
    lo,hi=i
    nearest=F(0) if lo<=0<=hi else min(abs(lo),abs(hi))
    far=max(abs(lo),abs(hi))
    return max(F(0),1-far),max(F(0),1-nearest)


def both_signs(room,weight):
    l,r=room
    return [(l,r,weight),(-r,-l,weight)]


def union_length(windows):
    result=F(0)
    right=None
    for lo,hi in sorted(windows):
        result += hi-lo if right is None else max(F(0),hi-max(lo,right))
        right=hi if right is None else max(right,hi)
    return result


def score_range(windows,I):
    points=sorted({*I,*(x for a,b,_ in windows for x in (a,b) if I[0]<x<I[1])})
    samples=points+[(a+b)/2 for a,b in zip(points,points[1:])]
    values=[max((w for a,b,w in windows if a<=x<=b),default=F(0)) for x in samples]
    return min(values),max(values)


def window_norm(windows,q):
    enlarged=[(a-q/2,b+q/2,w) for a,b,w in windows]
    points=sorted({x for a,b,_ in enlarged for x in (a,b)})
    pieces=[]
    for a,b in zip(points,points[1:]):
        x=(a+b)/2
        value=max((w for lo,hi,w in enlarged if lo<=x<=hi),default=F(0))
        if value:
            pieces.append(((a,b),value))
    direct=ss(length(i)*c for i,c in pieces)
    levels=sorted({w for _,_,w in enlarged})
    threshold=F(0)
    layer=F(0)
    for w in levels:
        layer+=(w-threshold)*union_length([(a,b) for a,b,t in enlarged if t>=w])
        threshold=w
    assert direct==layer>0
    return direct,enlarged,pieces


def certify(n):
    a=32*n
    h=1+F(1,a)
    R=F(2)
    D=(2*R)**n/2
    scale=2*h*R
    small=F(5,4)
    middle=2-F(1,4*n)
    shifts=[-F(5,2),-F(1,8*n),F(1,8*n),F(5,2)]
    radii=[small,middle,middle,small]
    parents=[box((z,)*n,r) for z,r in zip(shifts,radii)]
    marks=list(parents)
    marks[2]=tuple((lo,hi-F(1,16*n)) for lo,hi in marks[2])
    owners=[box((z,)*n,r/a) for z,r in zip(shifts,radii)]
    assert all(1<=r<2 for r in radii)
    assert all(contains(p,o) for p,o in zip(parents,owners))
    assert all(not volume(intersect(o,p)) for i,o in enumerate(owners) for p in owners[:i])
    q=small/R
    assert q==F(5,8)

    period=F(1,4*n)
    def mu_axis(i):
        lo,hi=section(i,(F(-8),F(8)))
        if lo>=hi:
            return F(0)

        def primitive(x):
            j=x//period
            t=x-j*period
            return j*period+t/2+max(F(0),t-period/2)

        return primitive(hi)-primitive(lo)

    def mu(Q):
        return prod(map(mu_axis,Q))

    I=list(map(volume,owners))
    m=list(map(mu,parents))
    assert m==list(map(volume,parents)) and D<=m[1]==m[2]<2*D
    s={(e,j):mu(intersect(marks[e],marks[j])) for e,j in product(range(4),repeat=2)}
    K={(e,j):s[e,j]/(m[e]*m[j]) if e!=j else F(0) for e,j in s}
    degree={e:ss(I[j]*K[e,j] for j in range(4)) for e in (1,2)}
    assert K[1,2]>0 and all(K[e,0]*K[e,3]>0 for e in (1,2))
    eps=F(1,128*n)
    low=F(41,32)
    high=F(13,8)
    middle_gap=F(23,16)
    low_interval=F(5,8),F(21,32)
    high_interval=F(25,32),F(27,32)
    profiles={
        "single_positive_low": [(*low_interval,F(1))],
        "symmetric_high": both_signs(high_interval,F(1)),
        "weighted_both_magnitudes": both_signs(low_interval,F(3,4))+both_signs(high_interval,F(1)),
        "broad_supported_control": [(F(-2),F(2),F(1))],
    }
    norm={name:window_norm(windows,q) for name,windows in profiles.items()}
    assert [norm[key][0] for key in profiles]==[F(21,32),F(11,8),F(103,64),F(37,8)]
    cases=[
        ("low_forward",(low,)*n,False,"single_positive_low",True),
        ("high_forward",(high,)*n,False,"symmetric_high",True),
        ("high_reverse",(high,)*n,True,"symmetric_high",True),
        ("mixed_magnitudes",(high,)*(n//2)+(low,)*(n-n//2),False,"weighted_both_magnitudes",True),
        ("gap_outside_window",(middle_gap,)*n,False,"weighted_both_magnitudes",False),
        ("low_expensive_control",(low,)*n,True,"broad_supported_control",False),
    ]

    common_profile=profiles["weighted_both_magnitudes"]
    common_norms={q_used:window_norm(common_profile,q_used) for q_used in (q,F(1))}
    assert [common_norms[q_used][0] for q_used in (q,F(1))]==[F(103,64),F(151,64)]
    common={q_used:{"Z_q":cost[0],"passed":[],"failed":[],
                    "passing_mass":F(0),"failing_mass":F(0),"row_ranges":{}}
            for q_used,cost in common_norms.items()}

    rows=[]
    price_blocks=[]
    old_positive=old_failure=F(0)
    for case,magnitudes,reversed_sign,name,wanted in cases:
        left,right=(3,0) if reversed_sign else (0,3)
        sign=1 if reversed_sign else -1
        y=box(tuple(sign*p for p in magnitudes),eps)
        z=box(tuple(-sign*p for p in magnitudes),eps)
        assert all(not volume(intersect(y,y0))*volume(intersect(z,z0)) for y0,z0 in price_blocks)
        price_blocks.append((y,z))
        assert contains(marks[left],y) and contains(marks[right],z)
        assert all(contains(marks[e],y) and contains(marks[e],z) for e in (1,2))
        # Two genuine prices, normalized separately on their original intersections.
        per_middle={}
        normalized_two_prices=mu(y)*mu(z)
        for e in (1,2):
            first=I[left]*I[e]*K[left,e]
            second=I[right]*K[e,right]/degree[e]
            amount=first*second*mu(intersect(y,marks[left],marks[e]))/s[left,e]*mu(intersect(z,marks[e],marks[right]))/s[e,right]
            per_middle[e]=amount
        old=ss(per_middle.values())
        direct_density=ss(I[e]*I[left]*I[right]/(degree[e]*m[e]**2*m[left]*m[right]) for e in (1,2))
        assert 0<old==direct_density*normalized_two_prices and all(per_middle.values())

        t_ranges=[delta(i,j,scale) for i,j in zip(y,z)]
        weights=[score_range(profiles[name],r) for r in t_ranges]
        Aq=[triangular_bounds(r) for r in t_ranges]
        A_lo,A_hi=prod(x[0] for x in Aq),prod(x[1] for x in Aq)
        Z,dilated,pieces=norm[name]
        paid_lo,paid_hi=prod(c/Z for c,d in weights),prod(d/Z for c,d in weights)
        assert 0<A_lo<=A_hi
        passed = A_hi<=paid_lo
        assert passed==wanted and (passed or paid_hi<A_lo)
        if passed:
            old_positive+=old
        else:
            old_failure+=old
        zero1=[triangular_bounds(delta(i,j,scale)) for i,j in zip(y,owners[right])]
        zero2=[triangular_bounds(delta(i,j,scale)) for i,j in zip(z,owners[left])]
        old_probes=(prod(t[1] for t in zero1),prod(t[1] for t in zero2))
        assert A_lo>2*sum(old_probes)
        if case.startswith("high"):
            assert old_probes==(0,0)

        # The entire true owner has a q/2 allowance after rescaling.
        for price,owner in zip(z,owners[right]):
            lo,hi=delta(price,owner,scale)
            assert max(abs(lo),abs(hi))<=q/2
        for price,owner in zip(y,owners[left]):
            lo,hi=delta(price,owner,scale)
            assert max(abs(lo),abs(hi))<=q/2
        if passed:
            for yi,zi,oi,g_range in zip(y,z,owners[right],weights):
                t_pointwise=delta(yi,oi,scale)
                assert score_range(dilated,t_pointwise)[0]>=g_range[0]

        centre_y=tuple((lo+hi)/2 for lo,hi in y)
        receiver_integrals=[]
        for i in (0,3):
            axis=[]
            for origin,coord in zip(centre_y,owners[i]):
                normalized=(coord[0]-origin)/scale,(coord[1]-origin)/scale
                axis.append(scale*ss(w*length(section(seg,normalized)) for seg,w in pieces)/Z)
            receiver_integrals.append(prod(axis))
        assert ss(receiver_integrals)<=scale**n

        # One fixed function, chosen before the price block or its direction.
        common_weights=[score_range(common_profile,r) for r in t_ranges]
        for q_used,result in common.items():
            Z0,dilated0,_=common_norms[q_used]
            assert q_used>=q
            rhs_lo=prod(lo/Z0 for lo,hi in common_weights)
            rhs_hi=prod(hi/Z0 for lo,hi in common_weights)
            if A_hi<=rhs_lo:
                result["passed"].append(case)
                result["passing_mass"]+=old
                for yi,oi,(lo,_) in zip(y,owners[right],common_weights):
                    assert score_range(dilated0,delta(yi,oi,scale))[0]>=lo
            else:
                assert rhs_hi<A_lo
                result["failed"].append(case)
                result["failing_mass"]+=old
            result["row_ranges"][case]=[rhs_lo,rhs_hi]
        rows.append({"case":case,"t_range_on_first_axis":t_ranges[0],
                     "price_half_side":eps,"true_old_peak_by_middle":per_middle,
                     "combined_true_old_peak_mass":old,"old_intersection_A_interval":[A_lo,A_hi],
                     "profile":name,"Z_q":Z,"test_right_hand_side_range":[paid_lo,paid_hi],
                     "passes_for_all_prices_in_box":passed,"old_zero_probe_pair_upper_endpoints":old_probes,
                     "owner_envelope_integral_at_reference_y":receiver_integrals,
                     "whole_reference_envelope_integral":scale**n,
                     "same_radius_owner_cap_dividing_by_m_small":scale**n/m[right]})
    assert old_positive>0 and old_failure>0
    assert common[q]["failed"]==["gap_outside_window"]
    assert common[F(1)]["passed"]==["high_forward","high_reverse","mixed_magnitudes"]
    assert all(r["passing_mass"]+r["failing_mass"]==old_positive+old_failure for r in common.values())
    return {"n":n,"radius_octave":"[1,2)","true_radii":radii,"centres_on_diagonal":shifts,
            "marks":"u,e0,e1,g; trim high faces of C_e1 by 1/(16n); all other C=A",
            "physical_parent_source_mass_equals_volume":True,
            "real_degree_by_middle":degree,"q":q,"h":h,"D":D,"R":R,
            "price_density_period":period,
            "true_disjoint_small_owners_at_fixed_y":True,"cases":rows,
            "tested_price_blocks_are_pairwise_disjoint":True,
            "same_predeclared_weighted_window_on_all_six_cases":{
                "function_intervals_and_weights":common_profile,"actual_and_conservative_q":{str(q_used):r for q_used,r in common.items()}},
            "tested_true_peak_mass_passing":old_positive,"tested_true_peak_mass_failing":old_failure,
            "scope":"four real product cubes, positive price boxes, both ordered small-end directions; no upstream high-dimensional masks"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B geometry779.py","dimensions":[certify(n) for n in (2,4,8,16,32)]},
                     indent=2,sort_keys=True,default=str))
