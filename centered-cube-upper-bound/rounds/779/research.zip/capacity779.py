"""Exact finite tests for cube spectra, pooled price capacity, and face multiplicity."""
from fractions import Fraction as F
from itertools import combinations, product
from math import comb
import json
import platform
import sys

import flint
from flint import arb, ctx
import sympy as sp

ctx.prec = 256


def noneg_fourier():
    t = sp.symbols('t', real=True)
    series = sp.series((1+t**2/3)*(sp.sin(t)/t)**2, t, 0, 8).removeO()
    assert series.coeff(t,2)==0 and series.coeff(t,4)==-sp.Rational(1,15)
    counts = []
    for n in (1,2,8,32):
        tested = 0
        for rate in (F(1), F(17,16), F(3,2), F(2)):
            for j in range(1,70):
                x = ar(F(j,32))
                h = (x*ar(rate)).sin()/(x*ar(rate))
                assert (1/(1+x*x/3))**n > (h*h)**n
                tested += 1
        counts.append([n,tested])
    x=ar(F(1,32))
    fail = (1+ar(F(7,20))*x*x)*(x.sin()/x)**2-1
    assert fail>0
    # The pointwise tent/Laplace comparison would be invalid.
    d=ar(F(7,5))
    ratio=(1-d/2)*ar(1)/arb(3).sqrt()*(arb(3).sqrt()*d).exp()
    assert ratio>1
    return {'series':str(series),'sampled_strict_comparisons':counts,
            'c_7_over_20_failure_at_1_over_32':str(fail),
            'space_tent_over_laplace_at_dx_7_over_5_R_1':str(ratio)}


def ar(q):
    q=F(q)
    return arb(q.numerator)/q.denominator


def solve_box(nodes, caps, H=F(1)):
    # Distances are integer multiples of a log(2); measure units are 1/Pi_R(0).
    n = len(nodes)
    gram = sp.Matrix([[sp.Rational(1,2)**sum(abs(x-y) for x,y in zip(u,v))
                       for u in nodes] for v in nodes])
    assert all(gram[:i,:i].det()>0 for i in range(1,n+1))
    lam=sp.Matrix(caps)
    solutions=set()
    for mode in product(range(3), repeat=n):  # zero, interior, cap
        free=[i for i,e in enumerate(mode) if e==1]
        v=sp.Matrix([lam[i] if e==2 else 0 for i,e in enumerate(mode)])
        if free:
            rhs=sp.Matrix([H for i in free])-(gram*v).extract(free,[0])
            vf=gram.extract(free,free).inv()*rhs
            for i,x in zip(free,vf):
                v[i]=x
        if not all(0<=v[i]<=lam[i] for i in range(n)):
            continue
        potential=gram*v
        if all((v[i]==0 or potential[i]<=H) and
               (v[i]==lam[i] or potential[i]>=H) for i in range(n)):
            solutions.add(tuple(v))
    assert len(solutions)==1
    nu=sp.Matrix(next(iter(solutions)))
    energy=(nu.T*gram*nu)[0]
    raw=gram*lam
    G=gram*nu
    raw_gate=sum((lam[i] for i in range(n) if raw[i]<=H),sp.S(0))
    assert energy<=H*sum(nu)
    return {'nodes':nodes, 'supply':list(map(str,lam)),
            'raw_low_potential_paid':str(raw_gate),
            'equilibrium_measure':list(map(str,nu)), 'potential':list(map(str,G)),
            'selected':str(sum(nu)),'remaining':str(sum(lam)-sum(nu)),
            'energy':str(energy)}


def hall_case(positions, supplies, priority, radius, cap):
    # Unit aliquots, a rational 1-D spatial destination with constant capacity.
    edges=sorted({x-radius for x in positions}|{x+radius for x in positions})
    rooms=[(x,y,int((y-x)*cap)) for x,y in zip(edges,edges[1:])]
    assert all(c==(y-x)*cap for x,y,c in rooms)
    rights=[j for j,(a,b,w) in enumerate(rooms) for _ in range(w)]
    neighbours=[[h for h,j in enumerate(rights)
                 if x-radius<=rooms[j][0] and rooms[j][1]<=x+radius] for x in positions]
    legs=[i for i in range(len(supplies)) for _ in range(supplies[i])]
    # Independent augmenting matching on replicated units; old source totals do not fall.
    match=[None]*len(rights)
    def augment(i,seen):
        for j in neighbours[legs[i]]:
            if j in seen: continue
            seen.add(j)
            if match[j] is None or augment(match[j],seen):
                match[j]=i
                return True
        return False
    for i in sorted(range(len(legs)),key=lambda u:-priority[legs[u]]):
        augment(i,set())
    received=[sum(idx is not None and legs[idx]==j for idx in match) for j in range(len(supplies))]
    result=sum(v*w for v,w in zip(priority,received))
    def deficit(group):
        best=0
        for count in range(1,len(group)+1):
            for subset in combinations(group,count):
                used={j for i in subset for j in neighbours[i]}
                best=max(best,sum(supplies[i] for i in subset)-len(used))
        return best
    layer=[]
    for v,next_v in zip([0]+sorted(set(priority)),sorted(set(priority))):
        group=[i for i,x in enumerate(priority) if x>v]
        demand=sum(supplies[i] for i in group)
        missed=deficit(group)
        layer.append((v,next_v,demand,missed))
    assert result==sum((b-a)*(mass-d) for a,b,mass,d in layer)
    return {'positions':positions,'amounts':supplies,'priority':priority,'s':radius,'H':cap,
            'served':received,'served_priority':result,'total_priority':sum(a*b for a,b in zip(priority,supplies)),
            'layers':layer,'unweighted_deficit':deficit(list(range(len(supplies))))}


def face_test():
    out=[]
    for n in (64,256,1024,4096,2**16,2**24,2**40,2**80):
        ell=arb(n+2).log()
        theta=n/ell
        delta=arb(2)/n
        Z=2+(theta-1)*(2*delta+delta*delta)
        pre=(n*Z.log()+4*ell)/theta.log()
        m=int(pre.ceil().unique_fmpz())
        assert pre>m-1 and pre<m
        bracket=n*Z.log()-m*theta.log()
        assert bracket<=-4*ell
        row={'n':n,'m':m, 'm_times_log_over_n':str(m*ell/n),
             'log_moment_minus_gate':str(bracket)}
        if n<=4096:
            # Smoothed independent corners attain each opposite face with probability 1/2.
            corner_bad=sum(comb(n,j) for j in range(m))
            row['corner_pass_lower_millionths']=(10**6*((1<<n)-corner_bad))//(1<<n)
            # Original stratified-source notebook: one atom per cell plus nonnegative
            # background fraction 20/(K+20); in either terminal interval of length 1/n
            # at most K/n+1 cells contribute. No regularity of background needed.
            K=4*n
            p_upper=min(F(1),2*F(5+20,K+20)**2)
            tail=min(F(1),comb(n,m)*p_upper**m)
            row['stratified_independent_near_face_prob_upper']=str(p_upper)
            row['stratified_tail_certified_at_most_millionths']=-((-tail.numerator*10**6)//tail.denominator)
        # Also keep the K(n) prescribed in the lower-bound notebook itself.
        root=(3*arb(n)/(74*arb(n).log())).sqrt()
        K0=max(48,int((root+ar(F(1,2))).floor().unique_fmpz())-20)
        cells=(K0+n-1)//n+1
        side=(F(cells)+F(40,n))/(K0+20)
        one=min(F(1),2*side*side)
        prob=min(F(1),F(n,m)*one)
        if n<=4096:
            prob=min(prob,comb(n,m)*one**m)
        row['original_notebook_K']=K0
        row['original_K_single_axis_bound']=str(one)
        row['original_K_tail_upper_millionths']=(prob.numerator*10**6+prob.denominator-1)//prob.denominator
        out.append(row)
    return out


def main():
    hall=[hall_case([0,1,2],[5,4,1],[1,4,8],1,1),
          hall_case([0,0,2,3],[4,3,2,6],[2,8,3,1],1,2),
          hall_case([0,2,3,6],[3,4,5,2],[4,1,2,9],2,2)]
    checks=0
    for w in product((1,2,4),repeat=3):
        for p in product((1,3,7),repeat=3):
            hall_case([0,1,3],w,p,1,1)
            checks+=1
    eq=[solve_box([(0,),(1,),(3,)],[2,3,2]),
        solve_box([(0,0),(1,0),(0,2),(2,2)],[F(1,8),3,4,F(1,4)]),
        solve_box([(0,0),(1,0),(0,1),(2,2),(4,4)],[1,3,F(1,4),4,2])]
    assert eq[0]['raw_low_potential_paid']=='0' and F(eq[0]['selected'])>0
    print(json.dumps({'python':sys.version.split()[0],'arch':platform.machine(),'sympy':sp.__version__,
                      'flint':flint.__version__,'precision':ctx.prec,'spectrum':noneg_fourier(),
                      'equilibrium':eq,'continuous_intervals_atomic_supply':hall,
                      'rank_weighted_hall_regression':checks,'opposite_faces':face_test()},
                     sort_keys=True,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
