# R271 independent statement screen

This note was derived before reading `/tmp/r271_bottleneck.md` or an auxiliary author's proposed proof. It does not certify a new spatial/source payment or general closure.

## 1. Terminal near carrier and two-time degree bound

**Verdict: PASS, with the original terminal hard-source gate retained.** Fix the original seed, leaf, receiver x, source y, band j and terminal g. Let t,t'≤g. Write

    s=min(t,t'), u=max(t,t'), E_s=e_s(y)≥E_u=e_u(y),
    eta=1−d/(2b),
    M*=ν(Q_R(x) intersect B_1(y,d/2) intersect Z_g(y)),
    H*=R^(−n) M*.

The letters s,u here order times, not soft parameters. They avoid ambiguous notation e_min/e_max: the later-time degree E_u is the smaller degree.

On the near set, each normalized coordinate distance r_i=|y_i−z_i|/b is below one and C(r_i)≥1−r_i. Since c_j g≤b, every physical clamp min(1,bC(r_i)/(c_jg)) is at least C(r_i). Thus

    w_g(y,z)≥product_i(1−r_i)≥1−sum_i r_i≥eta≥15/16.

For every t≤g, monotonicity gives w_t≥w_g and Z_g⊂Z_t, including the stated right-continuous endpoint convention. Hence, simultaneously for both times,

    e_u≥eta M*,
    H*≤min((16/3)q, E_u/(eta R^n)).             (S1)

The hard-cap branch uses the actual all-scale receiver band and ν≤f. On positive-degree rows the sharp useful ordering is

    H*²/(E_s E_u)
      ≤ H*/(eta R^n E_s)
      ≤ E_u/(eta² R^(2n) E_s).                 (S2)

One may also retain the unrelaxed first quantity in a minimum, or replace it by ((16/3)q)²/(E_sE_u). All physical R powers remain. If a relevant degree is zero, (S1) forces H*=0; the original masked posterior row is zero and must be treated before division. No arbitrary value is assigned to a 0/0 degree ratio.

### Original provenance actually checked

- R114 `ratio_settlement.md`, lines 28–43, S3–S4: the actual strict-CP/LCA source gate gives hard z∈Z_(j,V)(y,g). The proof uses the original same-top-cell and forbidden-block condition, not near distance alone.
- R259 frozen `source_bridge.md`, lines 229–258, SB6: explicitly retains that original hard gate, Z_g⊂Z_t and the near weight lower bound; its lines 30–47 give the same original clock/carrier and g≤bc_j.
- Master `GENERAL_CURRENT_REDUCTION.md`, lines 9–13: original FIRST and all-hard-scale receiver band.
- R113 `coupled_transport.md`, lines 51–84, C7–C8, and R259 SB1 lines 11–15: current actual sources ν≤β≤α=μ_hi|V≤f dx.

Therefore (S1) applies after returning to the original mother term while its terminal source gate is present. An upper expression which removed a_omega/CP/history cannot later be treated as retaining Z_g. The R222 post-hardcap conditional eta≤1 alone does not supply (S1). A raw actual hard numerator with additional masks ≤1 is bounded by H*, so retaining this terminal-support enlargement is legitimate before any such gate loss.

For any fixed source submeasure 0≤ρ≤β, actual p_y=P_(s(x),L(x))(x−y) satisfies integral p_y dρ≤integral p_y df≤q at its original FIRST receiver. Additional positive masks preserve this upper bound. It gives no FIRST for arbitrary auxiliary nodes, no source-role exchange, and no permission to take y-dependent degrees outside the second Cauchy factor. The source submeasure must remain a genuine submeasure of β.

## 2. Clock compression in the common decreasing degree

**Verdict: PASS as an extended nonnegative analytic inequality.** Use logtime v and the positive actual degree e(v). Its continuous derivative satisfies

    −dlog e(v)=m(v)dv + nonnegative deletion-jump measure,
    m(v)=Π_v k_v.

Set z(v)=−log e(v) and dμ_clock=m(v)dv. The pushforward of this continuous measure under z is dominated by Lebesgue measure on the z line. Flat degree portions have zero clock measure; deletion jumps leave gaps and add no clock atoms. This follows either on the monotone absolutely continuous phases and then by summing their disjoint z intervals, or by the positive Stieltjes change of variables. Thus

    sup_v integral exp(−|z(v)−z(v')|/2) dμ_clock(v')≤4.      (S3)

For a nonnegative **time-static** physical kernel K(v_source) (fixed original row/target, with w_g retained), define

    B_t=integral_(Z_t) k_t w_t sqrt(K/w_g) dν.

If m_t=0 then B_t=0. On m_t>0 apply Schur to f=B_t/(sqrt(e_t)m_t), and set f=0 on the zero-m_t set. Since

    B_t B_t'/e_early
      =[B_t/sqrt(e_t)] [B_t'/sqrt(e_t')]
         exp(−|log e_t−log e_t'|/2),

(S3) proves

    doubleintegral B_t B_t'/e_early dlogt dlogt'
      ≤4 integral B_t²/(e_t m_t) dlogt
      ≤4 integral (K/w_g) [integral 1_(Z_t) k_t w_t dlogt] dν.       (S4)

The second step is source Cauchy with measure 1_Z k_t w_t ν, whose mass is e_t m_t. Its zero-mass case is exact. Infinite quantities may be handled by finite positive truncation; no new finite bound is inferred from an infinite right side.

For each source, the continuous clamp loss satisfies

    integral 1_(Z_t) k_t w_t dlogt
       ≤1_(Z_start) w_start−1_(Z_end) w_end.                (S5)

The exact identity subtracts the nonnegative removed weight at internal carrier deletions. With internal endpoint conventions one uses start-plus and end-minus; replacing the final carrier by the smaller right-continuous Z_g only weakens the upper bound. Threshold births change the derivative count at a time-null set and create no weight jump. No extra n or clock count is needed in (S4).

Combining (S2) with (S4), a squared hard-weighted clock obeys

    H*² [integral B_t/e_t dlogt]²
      ≤4H*/(eta R^n)
         integral (K/w_g) [integral 1_(Z_t)k_t w_t dlogt] dν.       (S6)

On H*>0, (S1) itself ensures positive degree over the whole common clock. H*=0 is zero before division. An actual clock-dependent hard mask can first be enlarged by H*; it cannot be claimed time-static without that positive enlargement. A time-dependent capture/target factor must either remain inside the time integral or be replaced by a proved static majorant. This compression alone has not paid the remaining spatial/source integral or the terminal denominator w_g.

## 3. Auxiliary true target convolution and logLip6

**Verdict: PASS at fixed actual scales**, assuming a≤L,R≤b≤2a, L≤A≤b, m=min(L,R), and original common scalar target soft σ∈[0,1]. Define C_z=C(|z−v|/b), C_y=C(|y−v|/b), and m1=min(R,A), M1=max(R,A).

In one coordinate, the normalized convolution h_R*f_(σ,A) has height at most 1/M1: use probability normalization when R≥A and f_σ≤1 when A≥R. Also f_σ(·/A)≤max(h,φ)(·/b), so enlarging the R integration interval to b gives the independent upper bound b C_z/(RA). Together,

    h_R*f_(σ,A)(z−v)
       ≤M1^(−1) min(1,bC_z/m1).                          (S7)

Because m≤m1, dividing by min(1,bC_y/m) costs at most max(1,C_z/C_y). Tensorization therefore gives the requested bound once global logLip6 for C is established.

Here is a self-contained proof of that constant. For 0<u≤1,

    exp(−1/u)≤u/e,
    C(1)=integral_0^1 u²(1−exp(−1/u))²du
       ≥1/3−1/(2e)+1/(5e²)>1/6.

The final strict inequality follows already from e>8/3. On 0≤r≤1, C(r)=1−r+integral_(1/2)^(r+1/2)φ and |C'|≤1, C(r)≥C(1)>1/6, so |(log C)'|<6 wherever differentiated. On r≥1,

    C(r)=integral_0^1 u²(1−exp(−1/u))² exp[−(r−1)/u]du.

Its tail logarithmic hazard is nonincreasing and initially at most (1/2)/C(1)<3. C is continuous at r=1, though the one-sided derivatives need not agree; continuity and these piecewise bounds yield the global logLip6. Absolute values of displacement introduce no extra factor. Consequently,

    integral h_R(x−z) P_(σ,A)(x−v)/barw_m(y,v) dx
       ≤max(R,A)^(−n) exp[6||y−z||_1/b].                  (S8)

It is a true dx convolution. For the original near radius d/2 its cost is at most exp[3/(8√n)]. There is no adaptive-selector, source integration, or new FIRST assertion in (S8).

## 4. Bounded computation and limits

Actually executed 21 standard-library Fraction diagnostics for the near product and ordered-degree pair inequalities. The dimensions were n=1,4,16,64 (so sqrt(n) and the true near radius are rational), with three ξ values; nine further positive-degree pairs checked the two stages of (S2). These are finite algebra evidence, not an original FULL geometry certificate.

```python
from fractions import Fraction as F
checks=0
for n,root in [(1,1),(4,2),(16,4),(64,8)]:
    r=F(1,16*root);eta=1-r
    for xi in (F(1,2),F(9,10),F(1)):
        lower=min(F(1),(1-r/n)/xi)**n
        assert lower>=eta
        checks+=1
eta=F(15,16);H=F(1)
for latefactor in (F(1),F(2),F(3)):
    for ratio in (F(1),F(2),F(4)):
        E_late=eta*latefactor;E_early=ratio*E_late
        value=H*H/(E_early*E_late)
        assert H<=E_late/eta
        assert value<=H/(eta*E_early)
        assert value<=E_late/(eta*eta*E_early)
        checks+=1
print('PASS',checks,'exact near-product and ordered-degree-pair checks')
```

No author bottleneck proof was read for this screen. These statements preserve the complete actual posterior and terminal gate. They are analytical interfaces only; all remaining original spatial/source, w_g, receiver and signed-credit costs must still be assessed independently.

## 5. Stronger pure-weight loss, including removed sources

**Verdict: PASS for a nonempty original interval tau≤g.** For each source v the pure clamp w_t(v) is defined independently of whether v is in the carrier. Decreasing Z implies

    D_Z(v)=integral_tau^g 1_(Z_t)(v) k_t(v)w_t(v)dlogt
      ≤1_(Z_tau)(v) integral_tau^g k_t(v)w_t(v)dlogt
      =1_(Z_tau)(v)[w_tau(v)−w_g(v)].                    (S9)

This is valid even if v is removed before g; it uses the globally defined pure w_g, not 1_(Z_g)w_g. If the actual interval is empty, define D_Z=0 separately; a reversed integral of w_tau−w_g is not an applicable upper bound.

Since c_jg≤b and 0<C_i≤1,

    w_g≥product_i C_i,
    1−w_g≤sum_i(1−C_i)=Delta_b,
    1−C_i≤min(|y_i−v_i|/b,1).

Together with w_tau≤1 this proves

    0≤D_Z≤min(1,Delta_b,||y−v||_1/b).

On the genuine target-near domain ||y−v||_1≤d/2, it follows that D_Z≤d/(2b)≤1/(16sqrt(n)). No actual source gate is manufactured from this target-near condition; it is an additional restriction of the target integral. This inequality estimates positive continuous clamp loss and does not consume or recreate signed deletion credit.

Actually ran six exact Fraction clamp/deletion cases (including deletion at tau, internal thresholds and g). They verify continuous-loss telescoping and the strict pure-weight upper bound; they are not FULL source geometry evidence.

```python
from fractions import Fraction as F
from math import prod
A=[F(1),F(2)];tau=F(1,2);g=F(4)
w=lambda t:prod(min(F(1),x/t) for x in A)
for death in (F(1,2),F(3,4),F(3,2),F(3),F(4),F(5)):
    end=min(g,death)
    knots=sorted(set([tau,end]+[x for x in A if tau<x<end]))
    loss=sum(w(l)-w(r) for l,r in zip(knots,knots[1:]))
    assert loss==w(tau)-w(end)
    assert loss<=w(tau)-w(g)<=1-w(g)
print('PASS 6 exact clamp continuous-loss/deletion cases')
```

## 6. Outer source Cauchy and Young constants

**Verdict: PASS for the proposed conditional algebra, with A_int explicitly unpaid.** Suppose the original actual three-target upper expression is

    P≤2Lambda sqrt(K/3) integral_E F(x)dx,
    F(x)=q^(-1) integral ρ(dy) sqrt(p_y(x)) H*(x,y)
                       sum_(i=1)^3 integral B_i(t)/e_t dlogt.

The first source Cauchy factor is integral p_y dρ≤q, valid only for ρ≤β at the original FIRST selector. The second factor retains the y-dependent degrees. Applying the three-term sum-square inequality, then (S6) separately to the three static physical targets, proves

    F(x)^2≤12 A(x)/(eta q),

where the precise nonnegative remaining quantity is

    A(x)=integral ρ(dy) [H*(x,y)/R(x)^n]
             sum_i integral [K_i(x,v)/w_g(y,v)] D_Z(y,v) ν(dv).

The 12 is exactly three target terms times the Schur constant four; no independent-posterior or source-role replacement is used. Then the pointwise Young inequality cF≤epsilon lambda+c²F²/(4epsilon lambda), c=2Lambda sqrt(K/3), gives

    P≤epsilon X +4Lambda²K/(eta q lambda epsilon) integral_E A(x)dx
      ≤epsilon X +16Lambda²K/(3eta lambda²epsilon) A_int.

This assumes the common leaf receiver accounting needed to sum a single epsilon X. If K,eta,lambda,q vary over outer data, their factors must stay inside the corresponding expectation/leaf sum unless a proved common bound is used (eta≥15/16 is available). The actual source ρ, all surviving gates and static physical targets must have their original meanings. A_int still has a real target/anchor/source/receiver integral and w_g denominator; neither this algebra nor (S9) has shown it is input-budget bounded.
