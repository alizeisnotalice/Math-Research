#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Manifest PASS')
if not args.check_only:
 subprocess.run([sys.executable,str(root/'kernel_checks.py')],check=True)
 with tempfile.TemporaryDirectory() as td:
  out=Path(td)/'result.json'
  subprocess.run([sys.executable,str(root/'numeric_checks.py'),'--output',str(out)],check=True)
  assert out.read_bytes()==(root/'numeric_checks.json').read_bytes(),'numeric replay differs'
 print('Full numerical replay byte-identical; kernel checks PASS')
