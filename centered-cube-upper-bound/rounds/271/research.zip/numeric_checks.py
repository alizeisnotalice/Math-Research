#!/usr/bin/env python3
"""R271 Schur rows on genuine finite intervals plus exact interface arithmetic."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,90)
def mm(x):
 q=F(x);return mp.mpf(q.numerator)/q.denominator
def menus():
 return [('initial','one',[(F(0),F(1))]),('initial','adjacent',[(F(-1),F(0)),(F(0),F(2))]),('initial','shifted',[(F(100),F(101))]),('initial','long',[(F(-10),F(10))]),('stress','large_deletion_gaps',[(F(-10),F(-9)),(F(0),F(1)),(F(20),F(21))]),('stress','many_gaps',[(F(3*k),F(3*k)+F(1,10)) for k in range(20)]),('stress','huge_gap',[(F(0),F(1)),(F(100),F(102))]),('stress','tiny_interval',[(F(0),F(1,10**12)),(F(1),F(100))]),('expanded','wide',[(F(-100),F(100))]),('expanded','sixtyfour',[(F(8*k),F(8*k+2)) for k in range(64)]),('expanded','adjacent128',[(F(k),F(k+1)) for k in range(128)]),('expanded','shifted_almost_dense',[(F(10**6)+F(k)*F(1000001,1000000),F(10**6)+F(k)*F(1000001,1000000)+1) for k in range(64)])]

def row(r,intervals):
 val=mp.mpf(0)
 for a,b in intervals:
  if r<a:val+=2*mp.exp(-(a-r)/2)*(-mp.expm1(-(b-a)/2))
  elif r>b:val+=2*mp.exp(-(r-b)/2)*(-mp.expm1(-(b-a)/2))
  else:val+=2*(-mp.expm1(-(r-a)/2)-mp.expm1(-(b-r)/2))
 return val

def run(dps):
 with mp.workdps(dps):
  records=[];quadchecks=0
  for stage,name,raw in menus():
   assert all(a<b for a,b in raw) and all(raw[i][1]<=raw[i+1][0] for i in range(len(raw)-1))
   # Translation makes shifts near1e6 harmless. Root coefficients use guard digits
   # because nearly full rows may have exponentially small missing tails.
   origin=raw[0][0];intervals=[(mm(a-origin),mm(b-origin)) for a,b in raw]
   candidates=[]
   with mp.workdps(dps+40):
    ints=[(mm(a-origin),mm(b-origin)) for a,b in raw]
    for i,(a,b) in enumerate(ints):
     candidates.extend([a,b,(a+b)/2])
     A=mp.exp(a/2)-sum(mp.exp(y/2)*(-mp.expm1(-(y-x)/2)) for x,y in ints[:i])
     B=mp.exp(-b/2)-sum(mp.exp(-x/2)*(-mp.expm1(-(y-x)/2)) for x,y in ints[i+1:])
     if A>0 and B>0:
      root=mp.log(A/B)
      if a<root<b:candidates.append(root)
    best=max(candidates,key=lambda r:row(r,ints));maximum=row(best,ints)
   best=+best;maximum=+maximum;assert maximum<=4+mp.mpf('1e-35')
   queries=[best,(intervals[0][0]+intervals[0][1])/2,(intervals[-1][0]+intervals[-1][1])/2];checks=[]
   for r in queries:
    analytic=row(r,intervals)
    numerical=sum(mp.quad(lambda x:mp.exp(-abs(r-x)/2),[a,r,b] if a<r<b else [a,b]) for a,b in intervals)
    residual=abs(analytic-numerical);assert residual<mp.mpf('1e-32');quadchecks+=1
    checks.append({'r_relative_to_origin':enc(r),'analytic_row':enc(analytic),'independent_quad_row':enc(numerical),'absolute_residual':enc(residual)})
   records.append({'stage':stage,'name':name,'origin_exact':str(origin),'intervals_exact':[[str(a),str(b)] for a,b in raw],'positive_total_length_exact':str(sum(b-a for a,b in raw)),'gap_total_length_exact':str(raw[-1][1]-raw[0][0]-sum(b-a for a,b in raw)),'candidate_points':len(candidates),'row_maximum':enc(maximum),'maximizer_relative_to_origin':enc(best),'margin_to_4':enc(4-maximum),'quad_checks':checks})
  return {'cases':records,'independent_quad_rows':quadchecks}

def exact_interfaces():
 hard=[]
 for eta in [F(1,2),F(7,8),F(1)]:
  for H in [F(0),F(1,100),F(3)]:
   for n,R in [(1,F(1)),(2,F(3,2)),(8,F(2))]:
    # e_u and e_s are rational squares, with e_u>=eta R^n H.
    need=eta*R**n*H;root=1
    while root*root<need:root+=1
    eu=F(root*root);es=F((root+1)**2);lhs=H*H/(es*eu);rhs=H/(eta*R**n*es);assert lhs<=rhs
    hard.append({'eta':str(eta),'H':str(H),'n':n,'R':str(R),'e_s_square':str(es),'e_u_square':str(eu),'sqrt_e_u_over_e_s_exact':str(F(root,root+1)),'support_margin_exact':str(eu-need),'lhs_exact':str(lhs),'rhs_exact':str(rhs),'margin_exact':str(rhs-lhs)})
 cs=[]
 for profile in range(3):
  weights=[F(0),F(1,10),F(1),F(3)];aa=[F(1),F(1,2),F(2),F(3)];bb=aa if profile==0 else [F(2),F(1),F(0),F(1,3)] if profile==1 else [F(0),F(0),F(1,100),F(0)]
  A=sum(w*a*a for w,a in zip(weights,aa));B=sum(w*b*b for w,b in zip(weights,bb));cross=sum(w*a*b for w,a,b in zip(weights,aa,bb))
  for slack in [F(0),F(1,10),F(2)]:
   capA=A+slack;capB=B+slack;assert cross*cross<=capA*capB
   cs.append({'profile':profile,'weights_p_beta_exact':list(map(str,weights)),'sqrt_A_i_exact':list(map(str,aa)),'sqrt_B_i_exact':list(map(str,bb)),'FIRST_A_mass_exact':str(A),'FIRST_B_mass_exact':str(B),'cap_A_exact':str(capA),'cap_B_exact':str(capB),'cross_squared_exact':str(cross*cross),'CS_bound_exact':str(capA*capB),'margin_exact':str(capA*capB-cross*cross)})
 return {'mixed_hard':hard,'FIRST_CS':cs}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and not k.endswith('_exact') and k not in ['stage','name','maximizer_relative_to_origin','r_relative_to_origin']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(70);exact=exact_interfaces()
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);print('precision_diagnostic',worst,md,flush=True);assert diff[worst]<mp.mpf('1e-30')
 out={'schema':'R271-clock-Schur-interface-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'interval_union_cases_per_precision':12,'stage_cases':{'initial':4,'stress':4,'expanded':4},'independent_quad_rows_per_precision':hi['independent_quad_rows'],'exact_mixed_hard_cases':len(exact['mixed_hard']),'exact_FIRST_CS_cases':len(exact['FIRST_CS']),'precision_fields_compared':len(diff)},'mp40':lo,'mp70':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'exact_interfaces':exact,'scope':['Twelve finite unions of true positive-length continuous r-intervals retain all deletion gaps; arbitrary r0 shifts are removed only by translation invariance. These are clock-image interval tools, not a constructed original cube flow.','Analytic exponential row integrals evaluated at every interval endpoint/midpoint and every interior stationary point. Stationary coefficients use40 guard digits; row/independent mpquad comparisons use40/70 working digits. Outside the domain union a positive kernel row cannot have a new maximum away from its boundary, so the listed union maximum is the full supported row norm.','Every finite-domain integral includes its whole listed interval union: omitted-domain integral is exactly zero by definition. Extension to the whole real line would add a nonnegative tail; the universal4 bound comes from that analytic whole-line integral, not finite sampling.','Cross-precision comparison covers row values and residuals, not maximizing locations: symmetry can yield equally maximal rows at different locations. Ordinary mpmath is not outward interval arithmetic. Fraction hard/FIRST-CS rows are interface arithmetic only, not physical FIRST, history or FULL certification. Rational square e values make displayed square-root ratios exact.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
