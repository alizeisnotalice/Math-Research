#!/usr/bin/env python3
import mpmath as m
m.mp.dps=40
E=lambda k,x:m.expint(k,x)
def phi(x):
    x=abs(x);h=m.mpf('.5')
    return E(3,x-h)-E(3,x+h) if x>=h else 1-E(3,h-x)-E(3,h+x)
def C(x):
    x=abs(x)
    return 1-x+m.mpf(1)/3-E(4,x)-E(4,1)+E(4,x+1) if x<=1 else E(4,x-1)-2*E(4,x)+E(4,x+1)
def f(s,x):return (1-s)*int(abs(x)<=m.mpf('.5'))+s*phi(x)
y=m.mpf(0);z=m.mpf('.01');b=m.mpf(1)
cases=[('.5','.5','.5','0','.1'),('1','.5','.5','0','.1'),
       ('.5','1','1','1','2'),('.75','.5','1','.5','.8'),
       ('1','.75','1','.5','3'),('.75','.75','.75','1','0')]
mx=m.mpf(0)
for k,(R,L,A,s,v) in enumerate(cases,1):
    R,L,A,s,v=map(m.mpf,(R,L,A,s,v))
    r0=min(R,A);mm=min(L,R);M=max(R,A)
    om=min(1,C(y-v)/mm)
    lo=z-R/2;hi=z+R/2
    pts=sorted(set([lo,hi]+[q for q in [v-A/2,v+A/2] if lo<q<hi]))
    val=sum(m.quad(lambda x:f(s,(x-v)/A),[l,r])
            for l,r in zip(pts,pts[1:]))/(R*A*om)
    exactbound=min(1,C(z-v)/r0)/(M*om)
    shiftbound=m.exp(6*abs(y-z))*min(1,C(y-v)/r0)/(M*om)
    assert val<=exactbound and exactbound<=shiftbound
    mx=max(mx,val/shiftbound)
    print(k,'column',m.nstr(val,18),'clamp_bound',m.nstr(exactbound,18),
          'shift_bound',m.nstr(shiftbound,18))
print('PASS',len(cases),'max_shift_ratio',m.nstr(mx,25),
      'C1',m.nstr(C(1),25),
      'Lc',m.nstr((1-phi(m.mpf('1.5')))/C(1),25))
