# R520 历史与复现边界

基线R519提交a6aa2e22fb7440892e28cb4026d25837e258a2f7，已确认origin/main接收；本轮起始工作区干净。上一轮属于进展。本轮继续完整慢支实际B，不把有限模型替代一般目标。

复用Astra几何作者、Sol独审和Sol数值。主代理主推导、整合并操作仓库；Agent仅写各自/tmp文件。数值任务在R519最终审查时作为下一轮独立准备，519文件及归档未修改。R520单独提交。

沿用64工具的正场平方/交叉与对偶适用条件检查。二动作下降由真实概率支配及Hilbert恒等式直接证明；近优捕获式由逐窗分解证明，不借未经核验的外部高阶定理。无无限维强对偶假定、没有来源密度帽或外放松代替实际字段。

本轮扩展G的理论与数值G=4/3分开。三个模型按probe/pressure/expanded_density沿用既定点，真实whole-highslow、sourcecell核心、有限边界及实际相位全部保留。一次winner更新不是优化至最优，也不是统一递推收缩率。主代理实际检查JSON的三个finite_strict_decrease_from_brackets均为true。

解释器/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python；Python3.12.14，python-flint0.9.0，Arb256。正文Fraction程序只核代数，numeric给指定真实输入的严格球证书。独立隔离重放的stdout与JSON（仅排顶层seconds）逐字段比较见replay.json。PRE自身的额外720项检查另标范围，不作为额外一般结论或重复成果计数。未运行MATLAB，未安装软件，不编译PDF。

仅将主稿、作者证明、独立审查、必要代码/结果/重放与LaTeX精简归档。一般预算缺口仍在，所有原入口与未付费用保留。实际扣额数据不可得，不猜模型成本比例。

主代理另用Arb256读取冻结JSON的Bafter/Bbefore球和精确core4因子f4，核有限下降比例下界1−(Bafter/Bbefore)/f4，三组分别严格大于0.621%、1.515%、0.937%；周期比例与有限域精确比例明确区分。
