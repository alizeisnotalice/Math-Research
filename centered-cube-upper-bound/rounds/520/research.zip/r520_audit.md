FINAL PASS（仅限R520已证明的比较、下降机制及三个指定有限输入；一般平方预算及完整根阶目标未闭合）。独立先审、作者后审及最终冻结核对未发现阻断。只写本审计，九项冻结输入均未修改。

1. 二动作winner在平价/原子下仍为概率核，逐父支配πflat≤2π，正源字段满足0≤V≤2A，故曲率||V−A||²≤B；价格身份及η=δ/B给Bnew≤B−δ²/B。零B有明确分支。每父总概率一直为1，多步不产生2^k帽。该下降作用于辅助实际相位平方，不宣称原history记录单调。
2. 全支撑、右端原子与成本右连续足以从δ=0识别完整最优场；近零δ不提供完整oracle gap上界。精确F的近优序列误差≤ε/2与当前可计算字段的oracle gap明确分开。主证明捕获下界保真实新壳、旧动作q、跨phase有符号势差及端点；同phase才可使用δ窗<h。未以F无价替换原Li/alpha。
3. 任意有限共同G>1的放宽合法，原low/rapid/top互斥付款为CS(1+2G)W，源格只用R≤b。G²J和C_*(G)的loglog n依赖均保留；更改G重新分支，未冒称原同一P单调。理论多对数G与数值G=4/3范围分开。给定尚未证明的B预算后的回代指数正确。
4. 数值的first-hit条件律、连续窗邻层交叉、j=4d及Z/实际合场/分相位B区分正确。有限Lf≤周期L使实际finite highslow包含于周期highslow；core4上原alpha、分类及实际字段精确一致，其余用正场夹界。端点及固定周期type更新覆盖全部finite highslow，没有边界miss。周期winner不是finite oracle，真实有限下降由前后平方的分别夹界另证。
5. 最终比例核验：周期下降约1.0178050812%、1.9082947910%、1.3328454965%，与main的约1.02%、1.91%、1.33%一致。Arb256独算100[1−(Bafter/Bbefore)/f4]，严格下界球分别为0.621033689361077436%、1.51512987806675628%、0.937374104453584597%；因此main/history“超过0.621%、1.515%、0.937%”均安全，不把其称有限精确比例。

实际本机执行指定Python -I：proof 459、geometry 300及numeric 343检查通过；stdout与replay一致。numeric写出在进程内捕获，JSON仅剔顶层seconds后全部字段一致，canonical SHA256为029830abb1a453e84727614fd4f6b5906cef7113dd87f4a75a37598bd3a6f49a。PRE另720项仅为代数辅助，不重复当一般成果。上述数值只核三个固定输入和一次更新；未运行MATLAB。

main/history完整保留原R_*回代、入口、适用核帽及全部未付母账。低振幅/近平价场的联合来源付款、统一递推收缩与终端预算仍缺，算法下降及三点证据不构成一般闭合。

冻结输入SHA256：
- `r520_main.md`: `ff4af00675d26b77ee8ef80f554bd8d83a886ca6f1cb0bf111d7ae77b555c7d5`
- `r520_proof.md`: `804f487cf1f6804bc9a854590f6164dad855c080ddc44d6f7dd84b87524233d5`
- `r520_geometry.md`: `ff0186f0199209572fd400a26617634fc7dadd503b32f4191c1ffceeeda6be51`
- `r520_audit_pre.md`: `9f0064f613137a2ca3ac7c5f041e992ea0fc05d6252480bf3ae2c6405cb8aca0`
- `r520_numeric.py`: `01b09158977936c8c6e6730fc64d3bbdc76e7e8991e189eb1061e4748cad8e04`
- `r520_numeric.json`: `8cce4f47b1ab8122fb6177742ed4af3355c874011decbf0358d763da04715dc0`
- `r520_numeric.md`: `c0903a4394a7bf232e8d0d959fed63e6b0c383d2e8988266cefbcb8009a192ad`
- `r520_history.md`: `d91d03782739c22c07c2c4216a25010e800d5057b57eac0b75b9be489941f108`
- `r520_replay.json`: `920a74336118b22c52a178f8bb02bdc80fa27adb56fd2bcfaee314171d0f55ed`
