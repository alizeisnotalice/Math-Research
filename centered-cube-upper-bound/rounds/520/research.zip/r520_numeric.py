#!/usr/bin/env python3
"""R520 endpoint highslow actual phase energy, aligned field and finite bounds."""
from pathlib import Path
from fractions import Fraction as Q
import json,sys,platform,time
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def firsthit(n,p,targets):
 S=sum(p,arb(0));remaining=S;dp=[arb(0) for j in range(n+1)];dp[0]=arb(1);P=[]
 for prob,target in zip(p[:-1],targets):
  ratio=prob/remaining;ck(ratio>0 and ratio<1);nd=[arb(0) for j in range(n+1)];hit=arb(0)
  for r,mass in enumerate(dp):
   if mass==0:continue
   m=n-r;w=(1-ratio)**m
   for inc in range(m+1):
    z=mass*w;nr=r+inc
    if nr==target:hit+=z
    else:nd[nr]+=z
    if inc<m:w=w*(m-inc)/(inc+1)*ratio/(1-ratio)
  P.append(hit);dp=nd;remaining-=prob
 out=[x*S**n for x in P];none=sum(dp,arb(0))*S**n
 ck((sum(out,arb(0))+none-S**n).contains(0))
 return out,none

def model(n,qpower,stage):
 q=2**qpower;ks=list(range(qpower+1,n+1));K=len(ks);delta=Q(1,10000*n*K);G=Q(4,3)
 base=arb(2).root(n);grow=aa(G).root(n);R=[base**(k-qpower) for k in ks];V=[grow*r for r in R]
 oldA=[r-1-2*aa(delta) for r in R];oldB=[r-1+2*aa(delta) for r in R]
 newA=[v-1-2*aa(delta) for v in V];newB=[v-1+2*aa(delta) for v in V]
 ck(all(1+2*aa(delta)<r<2-2*aa(delta) for r in R))
 ck(all(oldB[j]<newA[j] for j in range(K)));ck(all(newB[j]<oldA[j+1] for j in range(K-1)));ck(newB[-1]<1)
 Fold=[oldA[j]-8*j*aa(delta) for j in range(K)]
 Fnew=[newA[j]-(8*j+4)*aa(delta) for j in range(K)]
 S=1-8*K*aa(delta)
 bins=[Fold[0]]+[Fold[j]-Fold[j-1] for j in range(1,K)]+[S-Fold[-1]]
 ck(all(z>0 for z in bins));ck((sum(bins,arb(0))-S).contains(0))
 asc,none=firsthit(n,bins,ks)
 C=1+arb(4).log();An=1+n*arb(2).log();threshold=1/An;baseK=arb(2).root(4)
 L=1000*n;factor2=Q(L-2,L)**n;factor3=Q(L-3,L)**n;beta_cell=Q(2*n,L+3)
 ck(beta_cell<Q(1,500));ck(Q(2*n)/beta_cell==L+3)
 def st(x):return x.str(35,radius=True)
 results=[]
 for name,P in [('ascending_k',asc)]:
  ell=[q*p for p in P];beta_k=[ell[j]+(ell[j-1]/2 if j else 0)+(ell[j+1]/2 if j+1<K else 0) for j in range(K)];alpha=[b/C for b in beta_k]
  energy=sum((l*b for l,b in zip(ell,beta_k)),arb(0));discrete=sum((l*l for l in ell),arb(0))
  high=[];low=[];unclassified=[]
  for j,a in enumerate(alpha):
   if a>threshold:high.append(j)
   elif a<threshold:low.append(j)
   else:unclassified.append(j)
  ck(not unclassified)
  highP=sum((P[j] for j in high),arb(0));highScore=sum((ell[j]*beta_k[j] for j in high),arb(0))
  rows=[{'k':k,'P_arb':st(P[j]),'ell_arb':st(ell[j]),'alpha_arb':st(alpha[j]),'An_alpha_arb':st(An*alpha[j]),'class':'high' if j in high else 'low','K_target_arb':st(baseK.max(An*alpha[j]))} for j,k in enumerate(ks)]
  out={'shared_selector':name,'rows':rows,'real_window_Q_over_W_periodic_arb':st(energy),'discrete_label_sum_ell_squared_arb':st(discrete),'finite_Q_over_W_lower_arb':st(aa(factor2)*energy),'finite_Q_over_W_upper_arb':st(energy),'high_k':[ks[j] for j in high],'high_P_arb':st(highP),'high_receiver_nu_per_cell_arb':st(q*highP),'high_score_per_cell_arb':st(highScore),'high_score_fraction_periodic_arb':st(highScore/energy)}
  if name=='ascending_k':
   slowP=rapidP=unknownP=arb(0);slowScore=rapidScore=unknownScore=arb(0);details=[];joint=[]
   for j in high:
    k=ks[j];remaining=n-k;prob=(Fnew[j]-Fold[j])/(S-Fold[j]);ck(prob>0 and prob<1)
    w=(1-prob)**remaining;target=baseK.max(An*alpha[j]);sp=rp=up=arb(0)
    for inc in range(remaining+1):
     z=P[j]*w;ratio=arb(2)**inc
     if ratio<target:
      sp+=z;joint.append((k,inc,z))
     elif ratio>target:rp+=z
     else:up+=z
     if inc<remaining:w=w*(remaining-inc)/(inc+1)*prob/(1-prob)
    ck((sp+rp+up-P[j]).contains(0))
    slowP+=sp;rapidP+=rp;unknownP+=up;slowScore+=q*sp*beta_k[j];rapidScore+=q*rp*beta_k[j];unknownScore+=q*up*beta_k[j]
    details.append({'k':k,'additional_coordinate_probability_arb':st(prob),'slow_P_arb':st(sp),'rapid_P_arb':st(rp),'unresolved_P_arb':st(up)})
   out['full_high_classification']={'slow_P_arb':st(slowP),'rapid_P_arb':st(rapidP),'unresolved_P_arb':st(unknownP),'slow_receiver_nu_per_cell_arb':st(q*slowP),'slow_oldscore_per_cell_arb':st(slowScore),'slow_score_fraction_periodic_arb':st(slowScore/energy),'rapid_score_fraction_periodic_arb':st(rapidScore/energy),'finite_safe_slow_receiver_nu_over_W_lower_arb':st(aa(factor3)*q*slowP),'finite_safe_slow_score_over_W_lower_arb':st(aa(factor3)*slowScore),'details':details,'reason':'ascending first-hit filters only earlier coordinates; above current radius remaining coordinates retain categorical conditional law'}
  results.append(out)
 # Endpoint probability is one on every actual finite highslow parent.
 phases={};aligned={};actual={};oldslow={};excess={}
 for k,d,p in joint:
  a=aa(Q(q,G))*2**d*p
  phases.setdefault(d,{})[k]=a
  aligned[k]=aligned.get(k,arb(0))+a
  actual[k+d]=actual.get(k+d,arb(0))+a
  oldslow[k]=oldslow.get(k,arb(0))+q*p
  excess[k]=excess.get(k,arb(0))+aa(Q(q,G))*(2**d-1)*p
 def norm(cols):
  return sum((a*a+a*cols.get(k+1,arb(0)) for k,a in cols.items()),arb(0))
 def inner(x,y):
  return sum((a*(y.get(k,arb(0))+(y.get(k-1,arb(0))+y.get(k+1,arb(0)))/2) for k,a in x.items()),arb(0))
 oldcols=dict(zip(ks,ell));phase_norms={d:norm(cols) for d,cols in phases.items()}
 B=sum(phase_norms.values(),arb(0));ZZ=norm(aligned);AA=norm(actual);LZ=inner(oldcols,aligned)
 oldcross=inner(oldcols,oldslow);gain=inner(oldcols,excess)
 ck((oldcross-slowScore).contains(0));ck((LZ-oldcross/aa(G)-gain).contains(0))
 ck(all((aligned[k]-oldslow[k]/aa(G)-excess[k]).contains(0) for k in aligned))
 ck((sum((p for k,d,p in joint),arb(0))-slowP).contains(0));ck(unknownP==0)
 active=len(phases)
 if active==1:ck((ZZ-B).contains(0))
 else:ck(ZZ<active*B)
 J=1
 while arb(4)**aa(Q(J,8))<An:J+=1
 ck(arb(4)**aa(Q(J-1,8))<An);ck(arb(4)**aa(Q(J,8))>An)
 ck(max(4*d for d in phases)<J)
 factor4=Q(L-4,L)**n
 lower=(slowScore-aa(Q(3,8))*energy)/aa(G)
 ck(LZ>lower)
 finite_cross_gap=aa(factor4)*LZ-(slowScore-aa(Q(3,8))*aa(factor2)*energy)/aa(G)
 ck(finite_cross_gap>0)
 def bracket(v):return {'lower_arb':st(aa(factor4)*v),'upper_arb':st(v)}
 endpoint={'scope':'all periodic highslow; endpoint on ALL actual finite highslow, sandwiched by positive fields; no miss','joint_rows':[{'k':k,'d':d,'phase_j':4*d,'old_window_start':str(Q(k,2)),'actual_window_start':str(Q(k+d,2)),'P_arb':st(p),'new_source_column_arb':st(aa(Q(q,G))*2**d*p)} for k,d,p in joint],
 'active_phase_j':[4*d for d in sorted(phases)],'active_phase_count':active,'theoretical_J':J,
 'phase_norms_per_W_arb':{str(4*d):st(v) for d,v in phase_norms.items()},
 'B_over_W_periodic_arb':st(B),'Z_norm_squared_over_W_periodic_arb':st(ZZ),'actual_A_norm_squared_over_W_periodic_arb':st(AA),
 'L_Z_over_W_periodic_arb':st(LZ),'old_slow_score_over_W_periodic_arb':st(slowScore),'shell_gain_in_L_Z_over_W_arb':st(gain),
 'R518_relaxed_cross_lower_over_W_arb':st(lower),'R518_relaxation_gap_over_W_arb':st(LZ-lower),
 'finite_R518_cross_gap_lower_over_W_arb':st(finite_cross_gap),'Z_squared_over_B_arb':st(ZZ/B),'B_over_old_Q_arb':st(B/energy),'L_Z_over_old_Q_arb':st(LZ/energy),
 'finite_core_factor_exact':str(factor4),'finite_B_over_W':bracket(B),'finite_Z_norm_squared_over_W':bracket(ZZ),'finite_L_Z_over_W':bracket(LZ),
 'finite_old_slow_score_over_W':bracket(slowScore),'finite_actual_A_norm_squared_over_W':bracket(AA),
 'normalizer_identity':'Z=D/G+positive endpoint shell field; residual window displacement exactly zero'}
 # One periodic two-iid-draw lower-cost winner update; no optimization loop.
 before={};winner={};oracle_rows=[]
 def add(field,phase,window,value):
  cols=field.setdefault(phase,{});cols[window]=cols.get(window,arb(0))+value
 for k,d,p in joint:
  add(before,0,k,q*p/2);add(before,4*d,k+d,aa(Q(q,G))*2**d*p/2)
 def beta_at(field,phase,k):
  cols=field.get(phase,{})
  return cols.get(k,arb(0))+(cols.get(k-1,arb(0))+cols.get(k+1,arb(0)))/2
 delta_cost=arb(0);ties=0
 for k,d,p in joint:
  cold=q*beta_at(before,0,k);cnew=aa(Q(q,G))*2**d*beta_at(before,4*d,k+d)
  if cold<cnew:po=aa(Q(3,4));choice='old'
  elif cold>cnew:po=aa(Q(1,4));choice='new'
  else:po=aa(Q(1,2));choice='unresolved_keep';ties+=1
  add(winner,0,k,q*p*po);add(winner,4*d,k+d,aa(Q(q,G))*2**d*p*(1-po))
  if choice!='unresolved_keep':delta_cost+=p*abs(cold-cnew)/4
  oracle_rows.append({'k':k,'d':d,'cost_old_arb':st(cold),'cost_new_arb':st(cnew),'lower_cost_action':choice,'winner_old_probability':str(Q(3,4) if choice=='old' else Q(1,4) if choice=='new' else Q(1,2))})
 def field_inner(x,y):return sum((inner(cols,y.get(phase,{})) for phase,cols in x.items()),arb(0))
 ck(all(value<2*before[phase][k] for phase,cols in winner.items() for k,value in cols.items()))
 Bbefore=field_inner(before,before);crossAV=field_inner(before,winner);VV=field_inner(winner,winner)
 delta_oracle=Bbefore-crossAV;ck((delta_oracle-delta_cost).contains(0));ck(ties==0);ck(delta_cost>0);ck(delta_cost<Bbefore)
 eta=delta_cost/Bbefore;after={}
 for phase in set(before)|set(winner):
  for k in set(before.get(phase,{}))|set(winner.get(phase,{})):
   add(after,phase,k,(1-eta)*before.get(phase,{}).get(k,arb(0))+eta*winner.get(phase,{}).get(k,arb(0)))
 Bafter=field_inner(after,after);diff2=Bbefore+VV-2*crossAV
 ck(diff2<Bbefore);ck((Bafter-(Bbefore-2*eta*delta_oracle+eta**2*diff2)).contains(0))
 paid_upper=Bbefore-delta_cost**2/Bbefore;ck(Bafter<paid_upper);ck(Bafter<Bbefore)
 finite_decrease=Bafter<aa(factor4)*Bbefore
 endpoint['single_two_action_update']={'scope':'periodic oracle, fixed original wholehighslow; finite implementation uses the same periodic rule, not finite oracle','rows':oracle_rows,'unresolved_cost_rows':ties,'B_before_over_W_arb':st(Bbefore),'winner_V_squared_over_W_arb':st(VV),'A_V_over_W_arb':st(crossAV),'delta_cost_integral_over_W_arb':st(delta_cost),'eta_arb':st(eta),'A_minus_V_squared_over_W_arb':st(diff2),'B_after_over_W_arb':st(Bafter),'theorem_upper_B_minus_delta_squared_over_B_arb':st(paid_upper),'B_after_over_before_arb':st(Bafter/Bbefore),'finite_before_over_W':bracket(Bbefore),'finite_after_over_W':bracket(Bafter),'finite_strict_decrease_from_brackets':bool(finite_decrease)}
 print('MODEL',stage,'n',n,'q',q,'B/W',st(B),'Z2/W',st(ZZ),'LZ/W',st(LZ),'phases',endpoint['active_phase_j'],flush=True)
 return {'stage':stage,'n':n,'q0':q,'candidate_k':ks,'delta':str(delta),'G':str(G),'h':'1/8','1_plus_u_arb':st(baseK),'a':1,'b':2,'An_arb':st(An),'C_arb':st(C),'threshold_1_over_An_arb':st(threshold),'R_top_arb':st(R[-1]),'V_top_arb':st(V[-1]),'combined_allowed_coordinate_mass_arb':st(S),'combined_survival_probability_arb':st(S**n),'combined_stripe_discard_upper_bound_exact':str(8*n*K*delta),'no_eligible_P_arb':st(none),'selectors':results,'endpoint':endpoint,'finite_embedding':{'L':L,'W':str(L**n),'source_cell':'[-2,L+1]^n, one R516-valid real source cell','source_cell_side':L+3,'beta_exact':str(beta_cell),'cell_side_identity':'ell=n*b/beta=L+3 with b=2','center_distance_to_macro_cell_boundary_at_least':2,'source_grid':'{0,...,L-1}^n, cubes halfdelta, each mass1','old_receiver_cells':'[0,L-1]^n repeated selected admissible phase region','safe_receiver_cells':'[1,L-2]^n','safe_receiver_factor_over_W_exact':str(factor3),'interior_source_factor_over_W_exact':str(factor2),'alpha_error_on_safe_centers':0,'scope':'safe old parent source indices all interior, where finite L equals periodic L exactly; not an arbitrary small source-cell claim'}}

def main():
 start=time.perf_counter();models=[model(16,1,'probe'),model(64,2,'pressure'),model(64,4,'expanded_density')]
 out={'scope':'R520 bounded actual endpoint action on whole highslow; strict Arb periodic energies and finite L1 brackets, not a general budget proof','environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r520_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS actual endpoint phases and finite bounds; one lower-cost winner energy update')
if __name__=='__main__':main()
