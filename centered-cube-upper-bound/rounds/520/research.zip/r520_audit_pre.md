# R520 独立 PRE：最小平方的真实新壳最优性限制

独立起步；仅读取R519 proof/geometry及其已证窗帽，不读取R520作者。保真实Lebesgue中心、μ≪dx、原t、源格、全部bulk动作和实际phase。下列是一个可证的局部最优性约束及其精确缺口，不是一般预算。

## 1. 闭包最优点给出的准确逐父条件

沿R519记H、可行场集合C、最小范数点A*、P=||A*||²。将原bulk旧场放在phase0，记L_U^0。令

c(B,g)=<A*,v(B,g)>, c_*(B)=inf_{1≤g≤G} c(B,g).

R519可数右逼近及可测oracle给∫_U c_*(B)dB=m(A*)=P。设实际概率核π_ε形成A_ε且||A_ε||²≤P+ε。投影不等式及平方展开严格给

||A_ε−A*||²+2[<A*,A_ε>−P]≤ε,
∫_U∫[c(B,g)−c_*(B)]π_ε,B(dg)dB≤ε/2.                 (1)

此处测试场是未知精确A*；不是可执行间隙r(A)=||A||²−m(A)。由近优能量≤ε不能反推r(A)≤ε/2；R519对r(A)只给||A||²−P≤2r(A)。

因此对任意可测非负阈值d(B)，动作集c−c_*≥d(B)的π加权d总量≤ε/2；特别固定阈值κ>0时其中心×动作测度≤ε/(2κ)。这适用于真正可行的逼近序列，不假设A*由某概率核实现，也不假设逐父argmin达到。若实际最优核存在，非负gap为0几乎处处，才可称其支持逐父最小score动作。仅由m(A*)=P直接宣称存在该核不合法。

## 2. 对真实新增来源的额外关系

A*每个实际phase分量保持0≤A*_{ij}≤C_*，因所有可行场有此帽，范数闭包可取几乎处处收敛子序列。固定父B∈格i，置s=log_γm_B、g=(R/R_B)^n、z=log_γ[m(B,R)/m_B]、j=floor(z/h)、τ=min(z,1)，定义

b_j(B)=t_B/R_B^n ∫_{Q_B}∫_[s,s+1] A*_{ij}(y,σ)dσ dμ(y),
d(B,g)=t_B/(gR_B^n) ∫_{Q(B,R)\Q_B}∫_[s+z,s+z+1] A*_{ij}(y,σ)dσ dμ(y).

这里d确是同一实际新壳与A*的score，非重新抽样来源。旧半径动作合法且在phase0，故c_*≤b_0。正窗长度1的一侧流失、流入各长τ，给精确拆分

c(B,g)=b_j(B)/g+d(B,g)+e(B,g),
|e(B,g)|≤C_* t_Bq_B τ/g.                                  (2)

记δ(B,g)=c(B,g)−c_*(B)≥0，由(2)得到

d(B,g)≤(1−1/g)b_0(B)+(b_0(B)−b_j(B))_+/g
        +C_*t_Bq_B τ/g+δ(B,g).                            (3)

这是独立于原α的严格附加限制：近最优动作不可能同时承担很大新增来源A*势、很小体积稀释、很小换窗损失，除非换phase显著降低旧盒势。phase0时中间的跨phase缺陷完全消失，且τ<h；对任意phase不能擅删该项。

设J_ε为π_ε的实际新增空间壳字段。积分(3)，保每父概率1及(1)，得

<A*,J_ε>≤(1−1/G)<A*,L_U^0>+D_phase(π_ε)
 +C_*∫_U∫ t_Bq_B τ/g π_ε,B(dg)dB+ε/2,                    (4)

D_phase=∫_U∫(b_0−b_j)_+/g π_ε,B(dg)dB.

<A*,L_U^0>≤√(P Q_U)≤√(P Q_good)。以上可用于审查一个拟议最优核是否实际把新增来源重复降低，而不只是降低旧盒归一系数。零t父各项为0；端点g=1、质量平台z=0也直接成立；相位跳跃保在b_j中，没有由窗连续性消去标签。

## 3. 原α与slow尚未补上的交集

原α测的是原Li对原旧核的score/(C t_Bq_B)（t_B>0），而b_0测A*_{i0}。两测试场不同，原高α不推出b_0下界，更不推出b_j≈b_0。slow只给m(B,R)/m_B<K_B，K_B=max(1+u,A_nα)，并不保证所有动作处于phase0或τ≤h。因此用原高α替代b_0、删D_phase、或将τ换成h均缺依据。

现有窗帽只能将(4)后两项粗付C_*∫tq≤C_*S A_nW，仍为线性维数费用。即使这两项很小，(4)只是新增壳的最优性上界；保留的旧源重复仍未支付，不能由它推出P的多对数界，亦不能忽略R519已指出的稀释系数抵消。下一步真正应证的是同一实际动作族中，原Li高score与A*各phase旧盒势之间的可积比较，以及该比较和真实新壳进入/重复的联合收益；必须给出来源价格或可吸收系数，不能仅再写对偶等价条件。

## 4. 本机辅助核对与停止范围

实际使用/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I，以Fraction对240组非负分段常值测试场、精确区间窗积分检查(2)、单侧窗损失和(3)，共720项通过，stdout为“PASS 720 Fraction checks of window-loss decomposition and near-oracle shell restriction; algebra only”。这仅核代数方向，不将标量测试冒充真实立方体输入或来源预算；一般式由上述逐窗证明。未运行MATLAB。

## 5. 主代理追加G扩大接口的独核

允许每个固定输入选有限共同G≥1（如log^p(n+2)），V=min(G^(1/n)R_B,b)。上述(1)—(4)以及R518/519实际构造不暗依赖G≤2。关键逐phase带界仍是γ^(jh)q/G≤q_new<γ^((j+1)h)λ，帽C_*=S[1+ln(Gγ^(1+h)r)]；J仍由Kmax=max(1+u,A_n)决定。rapid与top分别付CSGW，原Li/alpha固定，依序重划low/rapid/top/bulk，不重复付款。源格包含只用R≤b。完整Q回代保G²J/(1−3h)²及2CS(1+2G)/(1−3h)项。

G为polylog时C_*变成O(loglog n)，不得继续沿用固定G下“帽不依赖n”的表述。G=1的显式概率密度2g/(G²−1)须以δ1处理；若G>(b/a)^n则bulk空，端点付款仍成立。扩大G会同时改变分支和中心集合，因此不可未经说明宣称原同一P关于G单调；若冻结中心域另比较动作集合才有此单调性。原三个G=4/3数值输入不认证扩大后的动作域或其预算。此扩展给新的合法可用域，不自动付平方费用。

本PRE提供(1)—(4)、G扩大合法性及精准剩余交集；未证明一般P预算、原history单调或完整根阶。到此停止，等待作者稿后审。


## 6. R520作者后审（PRE最终追加）

独立上述公式后，已完整读r520_proof.md、r520_geometry.md及numeric.py/json/md。当前未发现需修作者的实质问题。

几何二winner：成本可测、平价公平规则含原子，胜出概率密度2Pr(c_T>c_R)+Pr(c_T=c_R)在[0,2]，故真实正源场0≤V≤2A并给||V−A||²≤B。min价格身份给δ=<A,A−V>，η=δ/B所得B_new≤B−δ²/B方向及常数正确，B=0有单独分支。支配只用于当步曲率，每步仍每父概率1，帽不随迭代乘2^k。此为同一原输入上的辅助实际相位平方下降，不是原history记录值单调。

δ=0在每个开半径区间正概率、右端原子及实际phase成本右连续条件下，确能将几乎处处平价扩至全部动作，识别完整最小平方；不要求窗可微。有限次迭代δ<B保正比例原核，仍全支撑。近零δ只给可执行改进，不是完整oracle gap的上界；未证明一般输入振幅持续足够大或平价场平方已小。G扩大的费用与本文§5一致。

主推导：对近最优实际动作r及任意来源前可测外扩ρ≤V，c(ρ)≥c(r)−e(r)，按同一真实新phase分解旧盒及新壳，给加权捕获下界(1)正确。窗一侧流出/流入分别被同一C_*帽控制，绝对差至多C_*min(δ,1)，无需2倍。跨phase有符号差保留；同phase才有b=c(r)、δ<h。端点只能κ=1且不承诺正收益。积分误差≤ε/2在精确F=A*的账中，不能当当前A或原Li的oracle误差，也未变换原α分母。假设将来B≤log^A(n+2)W后，G=log^p的回代指数(A+2p+1)/2正确；该B假设当前未证。

数值：独核真实完整小源捕获、ascending first-hit条件律、原连续邻窗交叉及实际j=4d。endpoint phase字段、合场A与比较Z分别计算，Z=D/G+正壳及相位合并费用保留。有限原Lf≤周期L使alpha_f≤alpha_periodic，所以实际finite highslow是周期highslow的子集；质量分类同时单调，未误断边界alpha相等。core4源的所有贡献父均为旧alpha精确相同的safe父，故whole实际finite highslow场在core4上与周期相等，外围仅用正场夹界；端点概率覆盖全部finite highslow，未删除边界miss。

一次二动作更新的周期cost、δ=ΣP_kd|cold−cnew|/4、η及实际相位平方展开正确。将该固定周期type规则用于finite仍合法，但不声称它是finite oracle。三组均严格满足B_after,periodic<f4 B_before,periodic，故由正场上下夹证得到finite真实下降；不把周期δ身份移作finite δ身份。仅这三点及一次更新，不推一般预算、收敛或最优性。

实际重放：指定本机Python -I执行两正文唯一Python围栏，stdout分别PASS 459 exact near-optimal capture comparison checks; scalar algebra only、PASS 300 exact tournament probability, domination, price identity and dimension-free curvature checks; finite algebra only。执行numeric完整源并在进程内捕获JSON写出，343守卫；仅删除顶层seconds后与现有JSON全字段一致，canonical SHA256=029830abb1a453e84727614fd4f6b5906cef7113dd87f4a75a37598bd3a6f49a。另逐组确认finite_strict_decrease_from_brackets全true。未改作者文件、未运行MATLAB。这些有限算术证据与一般几何证明分开。

PRE至此冻结；等待最终输入白名单后只写最终audit。一般平方预算、平价/低振幅联合来源付款和完整母账仍未闭合。
