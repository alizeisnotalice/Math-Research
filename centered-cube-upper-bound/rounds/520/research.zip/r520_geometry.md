# R520：允许多对数 G 的完整母账与二动作胜出下降

本稿的一个主候选是：对完整 bulk 的每个真实中心，从现有概率核抽两个合法动作，用当前**实际相位字段**的价格选较便宜者。选取仍在来源抽样前完成。已证明其实际平方下降，且曲率直接由当前平方控制，不另付 A_nW。未证明完整输入上的多对数平方预算；平价或近乎平价部分仍需联合来源几何。

## 1. 先核对扩大 G 后的完整母账

R518 中 G≤2 不是后续相位比较的必要条件。固定任意 G>1，令

V_B=min{G^(1/n)R_B,b},   K_B=max{1+u,A_n α_i(B)},
J=1+floor(log_γ(max{1+u,A_n})/h),   d=1−3h>0.

保原真实 μ、t_B≤S、L_i、α_i、r，α 不因任何删除或迭代重算。low、rapid、top 依次互斥删除：

E_low≤CSW,   E_rapid≤CSGW,   E_top≤CSGW.                    (1)

rapid 仍用真实首达 K_Bm_B 的半径付款，q_old≤G q_payer/K_B；top={R_B≥b/G^(1/n)} 用固定 b 付款。这两个 payer 不假装属于原密度带。

剩余 bulk 满足完整 g∈[1,G] 可用，所有新质量比<K_B≤max{1+u,A_n}。同一真实相位 j 内的新密度范围为

γ^(jh)q/G≤q_new<γ^((j+1)h)λ,

所以每父总概率为 1 的任何随机 selector 仍有相位帽

C_*(G)=S[1+log(G γ^(1+h)r)].                               (2)

密度带的比值变大 G 倍，其费用已留在 (2)；不能继续使用 G≤2 时的固定帽。源格不变：所有半径≤b，原保留中心距离格边≥b/2，候选仍在原格。J 不因 G 增长，因为 slow 的真实质量比帽仍是 K_B。

R518 的正窗比较与相位 Hilbert Cauchy 原样给出，对任何覆盖全部 bulk 的真实概率族，实际平方 B 满足

Q≤(1−β)^−2 [G²J B/d²+2CS(1+2G)W/d].                      (3)

没有新 miss。若 G=(log(n+2))^p>1（固定 p），则 C_*=O(log log(n+2))、J=O(log(n+2))，rapid/top 和 G²J 都只是明确的多对数费用。若 bulk 为空，(1) 已付款，不需假定完整区间非空。不能把 G 任意扩大后忽略这些费用。

作为起点，可选完整区间体积律加端点原子

π_B^0(dg)=1/2·[2g/(G²−1)]dg+1/2·δ_G(dg),  1≤g≤G.          (4)

它合法、来源前可测、全支撑。任意初始真实概率族都满足粗起始界 B_0≤C_* S A_n W。这仅作有限下降的起始账，不是目标预算。

## 2. 准确主命题：整族二动作胜出

设 H=⊕_(i,j)L²(μ|C_i×dσ)，v(B,R) 为 R519 可测 oracle 中的**真实**相位向量：用实际盒、实际质量窗、原 t_B，放入真实 j，其余分量为 0。

给完整 bulk 上任意来源前概率族 π_B，令

A=∫bulk∫v(B,R)π_B(dR)dB,   B=||A||²,
c_B(R)=<A,v(B,R)>≥0.                                     (5)

每个中心独立抽 R_1,R_2∼π_B。成本较低者胜出；相等时公平选择两次抽样中的一个。记胜出概率核为 π_B^♭，其真实字段为 V。

定义价格振幅

δ=1/2 ∫bulk∬ |c_B(R)−c_B(T)| π_B(dR)π_B(dT)dB.             (6)

**命题。** 该选择及全中心混合仍完全合法，且

0≤V≤2A 逐点,
δ=<A,A−V>,   0≤δ≤B,
||V−A||²≤B.                                              (7)

若 B>0，令 η=δ/B，并逐父用

π_B^new=(1−η)π_B+ηπ_B^♭.                                  (8)

则实际同流字段 A_new=(1−η)A+ηV 满足

B_new≤B−δ²/B.                                            (9)

B=0 时目标平方已经为 0，取 η=0。命题不需要内点支持、窗连续可微、薄壳质量估计或相位不跳跃。端点与跨相位动作都原样参加比较。

### 证明合法性与概率支配

成本 (B,R)↦c_B(R) 可测，有限范数由固定输入的既有单父界保证。胜出规则只依赖真实全局字段 A 的已积分价格；不观察随后抽取的来源 y，也不按每个来源重选半径。每次胜出值仍来自该父完整合法区间。

对任何动作可测集 D，胜出落在 D 意味着至少一次抽样落在 D，所以

π_B^♭(D)≤2π_B(D),   π_B^♭(全部)=1.                         (10)

更精确地，胜出核相对原核的密度是

r_B(R)=2π_B{T:c_B(T)>c_B(R)}+π_B{T:c_B(T)=c_B(R)}∈[0,2].    (11)

此式也包括原子和平价。非负核积分给 0≤V≤2A。故逐来源、逐实际相位 |V−A|≤A，积一次真实 μ 后给 (7) 的曲率界。这不是独立来源平方，也没有 W²。

### 证明价格下降

min{x,y}=(x+y−|x−y|)/2。对父的两次动作抽样积分，再对同一个 Lebesgue 中心域积分，得到

<A,V>=∫bulk E min{c_B(R_1),c_B(R_2)}dB=B−δ.                (12)

非负性给 δ≤B。再用 Hilbert 平方恒等式，

||A_new||²=B−2ηδ+η²||V−A||²≤B−2ηδ+η²B.

取 η=δ/B 即 (9)。证明完成。

(10) 用于证明当步曲率，不是新的永久中心权 t_B。多次胜出后仍每父总概率 1，因此每一步仍直接使用 (2) 的 C_* 相位帽；不可迭代成 2^k C_*。所有 low/rapid/top 费用只付最初一次，原 α 不重算，源格和历史不改变。

## 3. 与原积分及完整 oracle 的关系

这是一个实际可用的下降量，而非给未知余项另命名：δ 由当前同一个 A 与各父两动作的价格差决定；V、混合概率和 B_new 都明确。曲率控制只用正来源核的两次抽样支配，免去通常把任意 oracle 替代场的曲率粗估为 C_*S A_nW 的成本。

完整可测 oracle 成本满足

m(A)≤<A,V>=B−δ.                                          (13)

所以二动作给一个可执行的真实 oracle 改进下界。反向不成立：很薄的一组廉价动作可以令 δ 很小而完整 oracle gap 仍较大。本稿不把 δ 当成完整 gap 的双边证书。

若当前概率核对每个开半径区间给正质量且在右端点有原子，例如 (4)，则 **δ=0 时**，对几乎每个中心，c_B 在 π_B 下几乎处处恒定。R519 的成本在每个内点从右连续；全支撑把恒定性扩到所有内点，端点原子补上最后一点。因而 m(A)=B，此 A 已是完整动作域的最小范数字段：对任何真实 V'，<A,V'−A>≥0，故 ||V'||²≥B。

在 B>0 且 δ<B 时，(8) 保留正比例原概率核，故上述全支撑性质在有限次迭代仍保留。若 δ=B，则 (9) 已给零平方，另无平价障碍。这里 δ=0 只是准确的最优性识别，**不是最优值已经小**；其平价场依然可能承载全部未付来源重复。

## 4. 有限递推的真实收益与唯一未证几何环节

同一数据上有限次重复给

B_(k+1)≤B_k[1−(δ_k/B_k)²].                               (14)

每一步都是完整真实概率族替换，不新增遗漏集。若前 N 步实际检测到 δ_k≥εB_k，则

B_N≤(1−ε²)^N B_0≤exp(−Nε²)C_*S A_nW.                     (15)

这不是额外假设替代问题，而是当前机制的准确成败判据；命题 (9)/(14) 对所有输入无条件成立，(15) 只陈述检测到足够振幅时的真实收益。达到所需多对数 B 后直接接 (3)，迭代步数本身不乘入母账。

本轮没有证明任意 bulk 必定持续满足这种振幅下界。唯一未证步骤是：对缺乏足够价格振幅、尤其完整 oracle 平价的实际场，利用真实来源交集、slow 的 m(V_B)<K_Bm_B 与共享父动作，证明剩余 B 已有多对数 W 预算，或产生另一项足够的同流下降。不能由 slow 的末端质量帽直接推出价格振幅；本稿也不以旧盒系数衰减充当这个缺步。

母稿的支持动作最优性所强制的加权捕获，可用于研究这一平价部分；这里没有假定支持半径都可同相位外扩，也没有丢掉端点或跨相位价格跳变。扩大到多对数 G 使可用区间更长，所有费用已由 (1)—(3)核算，但它本身尚未证明平价场的来源付款。

**结论：** 本轮完成无 n 曲率费的实际二动作下降桥及可扩大 G 的完整常数核对。完整 bulk 的目标平方估计仍未证明；停止继续扩展。

## 5. 本机精确代数检查

实际在本机 Python Fraction 上运行 30 组、每组 3 个父/4 个动作/5 个来源坐标的非负有限数据，保非等中心权和动作概率，累计 300 项检查。输出：

`PASS 300 exact tournament probability, domination, price identity and dimension-free curvature checks; finite algebra only`

这些数据仅核验概率与 Hilbert 代数，不冒作真实立方体数值证书；任意 μ 的几何合法性由第 1—2 节证明。

```python
from fractions import Fraction as F
from random import Random
def dot(x,y):return sum((a*b for a,b in zip(x,y)),F(0))
checks=0
for seed in range(30):
 rng=Random(seed)
 kernel=[[tuple(F(rng.randrange(0,10),7) for _ in range(5)) for r in range(4)] for b in range(3)]
 probs=[[F(1,10),F(2,10),F(3,10),F(4,10)] for b in range(3)]
 center=[F(1,3),F(2,5),F(3,4)]
 A=tuple(sum(center[b]*probs[b][r]*kernel[b][r][y] for b in range(3) for r in range(4)) for y in range(5))
 B=dot(A,A);win=[];delta=F(0)
 for b in range(3):
  costs=[dot(A,v) for v in kernel[b]];w=[F(0)]*4
  for r in range(4):
   for s in range(4):
    p=probs[b][r]*probs[b][s]
    if costs[r]<costs[s]:w[r]+=p
    elif costs[s]<costs[r]:w[s]+=p
    else:w[r]+=p/2;w[s]+=p/2
    delta+=center[b]*p*abs(costs[r]-costs[s])/2
  assert sum(w)==1;checks+=1
  assert all(w[r]<=2*probs[b][r] for r in range(4));checks+=1
  win.append(w)
 V=tuple(sum(center[b]*win[b][r]*kernel[b][r][y] for b in range(3) for r in range(4)) for y in range(5))
 assert all(0<=v<=2*a for v,a in zip(V,A));checks+=1
 assert B-dot(A,V)==delta;checks+=1
 D=dot(tuple(v-a for v,a in zip(V,A)),tuple(v-a for v,a in zip(V,A)))
 assert D<=B;checks+=1
 eta=delta/B if B else F(0)
 new=tuple((1-eta)*a+eta*v for a,v in zip(A,V))
 assert dot(new,new)<=B-delta*delta/B;checks+=1
print('PASS',checks,'exact tournament probability, domination, price identity and dimension-free curvature checks; finite algebra only')
```
