# R248: a centered all-subset Gram payment for actual transport types

This file replaces the difference-level Minkowski bound in R109 by a
single all-subset estimate, and allows a fixed affine reference type.
It retains the shared target cap and the full physical volume cost.
The improvement is an actual extraction-price theorem. It does not
pay the whole residual traffic or grant a stronger cut to an already
frozen residual source without rebuilding that original extraction.
The exact inputs are [R109 mixed_type_main.md:9–123](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/mixed_type_main.md:9)
and [integration_main.md:19–49](/Users/zhengzhihao/Desktop/T/output/centered_cube_round109_20261013/integration_main.md:19).

## TC1. Exact proposition and permitted choices

Fix n>=1, an octave [a0,2a0], and coordinate ratios rho_i in [1,3].
For a type I subset [n], let A_I,t be the normalized rectangle average
whose full side is rho_i t in I and t outside I. Let s_I>=0 belong
to L1 intersect L-infinity, with the original one shared capacity

    S=sum_I s_I<=tau, W=sum_I integral s_I.

Any finite subfamily of types is allowed; missing types have s_I=0.
Let F_I>=0 be fixed geometric coefficients, not receiver selectors.
For a fixed reference type H subset [n], define

    E_H(s)=integral sum_{I,J} F_I F_J
          26^{|(I symmetric-difference H)
                    intersect (J symmetric-difference H)|}
                             s_I(u)s_J(u)du,
    C5=1+42 log 2.

Then

    ||sup_{a0<=t<=2a0} sum_I F_I A_I,t s_I||_2
                         <=C5 sqrt(E_H(s)).           (TC1)

H is fixed for the whole spatial/operator estimate. It may depend on
the already known source family and probability seed, but is not a
free function H(x) of the receiver. Since TC1 holds for every fixed H
for the same left side, its scalar right side may be minimized over
the finite collection of H. This does not sum a 2^n kernel menu.

The type interaction is evaluated at the same actual target u; it
does not assume independent source coordinates or independent labels.
The theorem is uniform in the common scale t, not a bound for
`sum_I sup_t A_I,t s_I` with no additional cost.

## TC2. Uniform scalar estimate, including inverse stretches

Put h(u)=sin(u)/u with h(0)=1. For every rho in [1/3,3], let

    delta(u)=h(rho u)-h(u), v(u)=(h(u),delta(u)/5).

The elementary bound needed below is

    ||v(u)||<=1, ||u v'(u)||<=42[1-||v(u)||].          (TC2)

For |u|<=1, the same integral and Taylor estimates used in R109 M3
give

    |delta|<=4u^2/3, |u h'|<=u^2/3,
    |u delta'|<=10u^2/3, h(u)^2<=1-19u^2/120.

They remain valid for inverse stretches: |rho^2-1|<=8 and
rho^2+1<=10 on [1/3,3]. Consequently

    ||v||^2<=1-(157/1800)u^2,
    1-||v||>=157u^2/3600,
    ||u v'||<=sqrt(5)u^2/3<=42*157u^2/3600.

For |u|>=1, |h(u)|<=sin(1)<6/7, |delta|<=2,
|u h'|<=2 and |u delta'|<=4, whence

    ||v||^2<=36/49+4/25=1096/1225,
    1-||v||>=129/2450,
    ||u v'||<=sqrt(116)/5<42*129/2450.

The derivative identity `u h'(u)=cos u-h(u)` is valid for every
nonzero u and gives the displayed bounds even when rho u is small.
At u=0 both sides of the derivative inequality vanish. Thus TC2 holds
without a frequency cutoff, a coordinate count, or a numerical claim.

## TC3. One Cauchy estimate over all subsets

First take H empty. At frequency xi let u_i=pi t xi_i and tensorize
`V_t= tensor_i (h(u_i),delta_i(u_i)/5)`, using the actual rho_i.
TC2 gives

    ||V_t||<=1, ||t partial_t V_t||<=42.              (TC3)

For the derivative, put b_i=||v_i|| in [0,1]. The triangle bound is
42 sum_i(1-b_i)product_{j!=i}b_j<=42. The last inequality is the
algebraic expansion of product_i[b_i+(1-b_i)]; it is not an input
independence hypothesis. Zero b_i require no division.

Let m_J be the product multiplier with delta_i in J and h elsewhere.
The coordinates of V_t are `5^{-|J|}m_J`. The exact finite expansion
of the whole operator is

    sum_I F_I A_I,t s_I=sum_J T_J,t g_J,
    g_J=sum_{I contains J}F_I s_I.

Applying frequency Cauchy to ALL J at once, then Plancherel, gives

    ||sum_I F_I A_I,t s_I||_2<=sqrt(E_empty),
    ||t partial_t sum_I F_I A_I,t s_I||_2
                                        <=42 sqrt(E_empty),

because

    sum_J25^{|J|}||g_J||_2^2
      =integral sum_{I,I'}F_I F_I' (1+25)^{|I intersect I'|}
                                                   s_I s_I'
      =E_empty.                                      (TC4)

The one-octave fundamental theorem of calculus and Minkowski now
give C5=1+42 log 2. Unlike R109 M11--12, there is no separate final
Minkowski sum over the difference levels |J|. Merely retaining those
old level norms would not by itself give TC4.

For general H change variables x=D_H u, where D_H has diagonal
rho_i on H and one elsewhere. The reference I=H becomes the cube.
Its alternatives have ratio rho_i outside H and rho_i^-1 inside H,
all in [1/3,3]. The difference set is exactly I symmetric-difference H.
Apply the preceding all-subset proof in these coordinates. The
Jacobian in the squared output norm cancels the Jacobian in the
input Gram integral, proving TC1 with exactly E_H and no det D_H fee.

For rough inputs, use a common nonnegative approximate identity and
common spatial truncation. The finite family converges in L2 and
retains its common capacity cap. First pass to finite rational scale
maxima, then increase the rational menu. For locally integrable input,
the rectangle average is continuous in positive t (box boundaries
have zero Lebesgue measure); thus rational and full scale suprema
agree. E_H is a finite continuous quadratic expression in the L2
inputs. This completes the same legitimate limit used by R109 M12.

## TC4. Concentration and dispersion in one actual type formula

The Gram is positive semidefinite: TC4 expresses it as a sum of
nonnegative squared cumulative-type densities. Its centered version
has the identical representation after I is replaced by I triangle H.
It can therefore be evaluated on the original finite flow; it is not
an unknown operator norm introduced in place of the estimate.

If all transported mass has a single type I0, choose H=I0. Then

    E_H=F_I0^2 ||s_I0||_2^2<=F_I0^2 tau W.           (TC5)

There is no symbol factor 26^{|I0|}. The familiar single-rectangle
affine cube bound with the original dimension-free L2 constant C2
can replace C5 in this single-type case. Its volume F_I0 remains.
At the other extreme H empty retains genuine low intersections of
diffuse types without assigning them independent coordinates.

Two explicit further bounds make the cost testable. Put D_I=I triangle H.
Then, by weighted Cauchy and the one shared cap,

    E_H<=tau sum_I F_I^2 26^{|D_I|} W_I,
    W_I=integral s_I.                                (TC6)

Indeed `2|D_I intersect D_J|<=|D_I|+|D_J|` first bounds the Gram by
`integral(sum_I F_I 26^{|D_I|/2}s_I)^2`, and then use sum s_I<=tau.
There is no separate tau per direction. For a more refined diffuse
certificate, suppose |D_I|<=d_max and distinct simultaneously active
types have |D_I intersect D_J|<=d0<=d_max. With F_I<=F_max and

    W_collision=integral_{S>0} [sum_I s_I(u)^2]/S(u)du,

the diagonal/off-diagonal expansion gives

    E_H<=F_max^2 tau [26^{d0}W
                +(26^{d_max}-26^{d0})W_collision].  (TC7)

This is a conditional certificate about the actual target type law.
Shared capacity does not force W_collision small. Single-type
concentration is handled by the choice of H, not incorrectly called
dispersion. Several fixed type clusters may instead use separate
centers followed by the explicitly paid sum of their square-root
Gram bounds; no spatially adaptive affine reference is free.

## TC5. Actual unpadded moves and the full extraction payment

The geometry is exactly R109 integration_main V1--3. Original pieces
have side a/n. Label an edge by the set I of coordinates whose source
and target grid indices actually differ; do not pad this set to size r.
Every allowed edge has |I|<=r. Coordinates outside I move by at most
a/n, those in I by at most a+a/n. Hence, for original R(x)>=a,

    h_R eta<=sum_I F_I A_I,(1+2/n)R s_I,
    F_I=(3+2/n)^{|I|}(1+2/n)^{n-|I|},
    rho_i=(3+2/n)/(1+2/n).                           (TC8)

The s_I are target marginals of that SAME plan, and still sum to at
most tau. If a preassigned bound m_i<=n on its actual grid-index
displacements is known for the whole family, one may replace the
active side by `1+2(m_i+1)/n`, retain the base side `1+2/n`, and use
the corresponding fixed rho_i and exact determinant F_I. A different
edge-specific aspect ratio cannot be substituted without organizing
its additional operator families and their costs.

Let T_eta be the original positive extracted traffic, with real dx,
original receiver E and X=lambda|E|. Its inherited receiver/RN weight
is at most one, just as in R109 M13; all original sources and positive
gates are kept until this documented upper relaxation. TC1, ordinary
Cauchy over E, and scalar Young prove for every epsilon>0

    T_eta<=epsilon X+C5^2 E_H(s)/(4epsilon lambda).    (TC9)

Seed averages and disjoint original leaf receiver domains allow the
corresponding sum/expectation of E_H. A center may be fixed separately
in each such leaf/seed estimate; no free center per incoming receiver
or target point is claimed. In particular if this actual Gram satisfies
`E sum_V E_H(s_V)<=A tau W_eta`, its source price in TC9 is
`C5^2 A tau/(4epsilon lambda) W_eta`. This is a real extraction fee;
it is paid only when this displayed Gram bound is proved or computed
for the certified plan. TC6--7 are sufficient explicit ways to do so.

Universally |I|<=r, F_I<=3^r e^2, and H empty give

    E_empty<=e^4 234^r tau W_eta.                    (TC10)

Thus the guaranteed price is `C5^2 e^4 234^r tau/(4epsilon lambda)`.
With the original tau=ell_n lambda/sqrt(n), choosing
`r=max(1,floor(log(n)/log(234)))` costs at most
`C5^2 e^4 ell_n sqrt(n)/(4epsilon)` for n>=512, since 234^r<=n.
This constant improvement alone is not the global geometric advance:
the structural result is the centered, unpadded actual-type Gram,
which simultaneously avoids false concentrated-type symbol costs
and retains real dispersion gains. Even with zero symbol loss the
physical F_I^2 can be of order 9^{|I|}; no sqrt(n)-coordinate halo
follows from a small Gram symbol factor.

Take the minimum with the existing R109 price and the legitimate
single-type/group estimates when appropriate; there is no claim of
a uniformly better numerical constant at every small dimension.
The original running-maximum combination with the old short networks
still pays the sum of its network comparison coefficients, as in
R109 V3; it does not acquire a fresh target cap or epsilon X for each
label. Saturated-cut witnesses and the high-neighborhood cost remain
separate, unchanged charges.

This changes the comparison price for the same certified plan, not
the identities beta/nu of the remaining source. To obtain a larger
coordinate cut, one must run that larger original network and replay
its residual, top/rank, source and receiver labels as required by
R109 V4--11. Old beta is not given hard rank; old nu is not declared
to have a stronger cut merely from TC10. The generally unpaid joint
traffic remains unpaid.

## TC6. The same centered Gram pays the actual common soft operator

Use the original probability kernel

    K_s,L=tensor_i[(1-s)delta_0+s w_L(u_i)du_i],
    P_s,L=h_L*K_s,L,
    w(u)=integral_0^1 exp(-|u|/r)dr.

The authentic multiplier bounds are R112 proof.tex.txt:590--653,
J9--10. With D=L partial_L they are

    |K|<=1, |DK|<=2, |partial_s K|<=H_n(s),
    |D partial_s K|<=4H_n(s),
    H_n(s)=min(n,1/s), integral_0^1 H_n=1+log n,

where H_n(0)=n. For every fixed c>0, put
`G_s,t=sum_I F_I K_s,t/c * A_I,t s_I`. Multiplying the all-subset
vector of TC3 by the same K gives four L2 bounds with common factor
sqrt(E_H): constants `1,44,H_n(s),46H_n(s)` for
`G,DG,partial_sG,D partial_sG`, respectively. Here 44=2+42 and
46=4+42. The mixed derivative does not differentiate a softness
dependent input or plan: the original target family is fixed first.

Apply the two-parameter fundamental theorem of calculus on
[0,1] times [a0,2a0], then Minkowski. It proves

    ||sup_{s,t} sum_I F_I K_s,t/c*A_I,t s_I||_2
       <=Csoft5(n) sqrt(E_H),
    Csoft5(n)=1+44log2+(1+46log2)(1+log n).            (TC11)

After the fixed D_H change of variables, K is evaluated at fixed
coordinate-scaled frequencies. Its scalar quantities still satisfy
0<=a_i<=1 and 0<=b_i<=2a_i from R112 J10, so all four bounds persist
with no affine determinant loss. The rough-input limit follows
R112:726: K_s,t/c*A_I,t is continuous in (s,t) in L1 kernel norm,
and the common nonnegative approximations retain the shared cap.
No parameter menu or type-dependent soft choice has been added.

In the original soft transport comparison, c=1+2/n, t=cL, and
positivity gives `P_s,L eta<=sum_I F_I K_s,L*A_I,cL s_I` with the
same actual source-to-target plan; this is R112 J15--16 with unpadded
types. Thus TC11 replaces J17's squared comparison cost by
`Csoft5(n)^2 E_H(s)`. A source response paid through
`integral_E P_s(x),L(x) eta(x)dx` has the corresponding exact Young
fee `epsilon X+Csoft5(n)^2 E_H/(4epsilon lambda)`.

The actual soft subtraffic has the additional genuine hard-cap factor
from R112 J21--22 (proof.tex.txt:815--837):

    U_eta<=C_h P_s,L eta, C_h=16/3,
    T_Ueta<=epsilon X
              +C_h^2 Csoft5(n)^2 E_H/(4epsilon lambda). (TC11a)

Thus this factor is squared in its source price. The old running-maximum
increments are combined as in R112 J18--19, with each actual network
coefficient paid once. All original row-splitting factors and other
embedding/recovery charges remain as stated in that ledger. Neither
TC11 nor TC11a directly pays the current double-Pi remainder.

## TC7. A finite min-cost rerouting interface with sources fixed

For an actual finite original network, freeze the complete extracted
submeasure on every source piece, and all component/coupled subflows
whose identities are needed to preserve the original beta and nu.
Restrict to reroutings along its original allowed edges that preserve
these data, the shared target capacities, and the original maximum
flow value. The original plan is a nonempty feasible witness. Keeping
only total flow value, without these source constraints, would not
preserve pointwise coupled-source inclusion.

If target pieces are P_l and the type-I mass delivered there is f_I,l,
use the same uniform target distribution as the original construction:
`s_I,l=f_I,l/|P_l|`. For any fixed H the objective is exactly

    E_H=sum_l |P_l| sum_{I,J} F_I F_J
        26^{|(I triangle H) intersect (J triangle H)|}
                                      s_I,l s_J,l.  (TC12)

Its Gram feature indexed by A subset [n] is
`5^{|A|} F_I 1_{A subset I triangle H}`. Hence TC12 is a convex
quadratic in the finite edge-flow variables. On the compact feasible
rerouting polytope it attains a minimum, and that value is no larger
than the actual original plan's E_H. This is a concrete finite
min-cost *rerouting* interface, not an assumption that its optimal
value has a root budget. Different fixed H may be solved separately
and their scalar minima compared; H is not optimized independently
at each target cell.

Any subsequent seed-average use must keep the original measurable
finite-data selection convention (for example a fixed active-set
ordering and minimum-norm tie rule). Neither the convex objective nor
its minimum grants new source marginals. If extraction itself changes,
the original running maximum, residual sources and all cut/row labels
must instead be rebuilt. No such reconstruction is performed here.

## TC8. Local verification record

The analytic proof does not use a sampled multiplier bound. A local
Python standard-library calculation actually passed 56 exact
Fraction/integer checks: the four scalar rational comparisons;
TC4/TC6/TC7 and the zero-deviation single-type symbol for n=1,2,3,4
and three fixed centers; and the exact 234-base integer cutoff for
n=512,10^6,10^12,10^30. These check the finite algebra and constants,
not a continuous-frequency theorem, a certified flow, or FULL.

```python
from fractions import Fraction as Q
from itertools import combinations
checks=0
assert Q(19,120)-Q(16,225)==Q(157,1800); checks+=1
assert 1-Q(36,49)-Q(4,25)==Q(129,1225); checks+=1
assert Q(5,9)<(42*Q(157,3600))**2; checks+=1
assert Q(116,25)<(42*Q(129,2450))**2; checks+=1
for n in range(1,5):
 types=[frozenset(c) for k in range(n+1)
        for c in combinations(range(n),k)]
 den=sum(range(1,len(types)+1))
 s={I:Q(k+1,den) for k,I in enumerate(types)}
 q0=1+Q(2,n); rho=(3+Q(2,n))/q0
 F={I:q0**n*rho**len(I) for I in types}
 for H in [frozenset(),frozenset(range(n)),
           frozenset(range(0,n,2))]:
  D={I:I^H for I in types}
  E=sum(F[I]*F[J]*26**len(D[I]&D[J])*s[I]*s[J]
        for I in types for J in types)
  G=sum(25**len(A)*sum(F[I]*s[I] for I in types
                       if A<=D[I])**2 for A in types)
  assert E==G; checks+=1
  assert E<=sum(F[I]**2*26**len(D[I])*s[I]
                for I in types); checks+=1
  col=sum(t*t for t in s.values()); fmax=max(F.values())
  assert E<=fmax**2*(26**(n-1)
             +(26**n-26**(n-1))*col); checks+=1
  assert 26**len((H^H)&(H^H))==1; checks+=1
for n in [512,10**6,10**12,10**30]:
 r=1
 while 234**(r+1)<=n:r+=1
 assert 234**r<=n<234**(r+1); checks+=1
print('PASS',checks)
```
