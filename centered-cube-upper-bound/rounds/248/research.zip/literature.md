# 局部稀疏坐标扩张：相关定理与迁移边界

## 核验结论

Talagrand 的 product-measure 结果可以合法地在 receiver cube `Q` 上使用：归一化限制测度 `μ_Q=1_Q dx/|Q|` 是 `Q` 上坐标独立的均匀乘积概率。因此，“产品概率结论不能转为真实 Lebesgue receiver 体积”不是障碍；在 `Q` 内有 `μ_Q(E)=|E∩Q|/|Q|`。真正的迁移缺口在于定理所控制的距离/匹配扩张，是否能控制本题 `H_{r,a,V}(S)` 的局部部分，以及如何将任意 `β`（无相对 `μ_Q` 的密度上界）接入。局部 `a` 位移、给定 `N` 稀疏条件、至多 `r` 个坐标改变与原文的单源/多源 matching relation 之间，尚未建立所需比较；故这些来源不直接给出所需方向性容量，亦不声称一般 `√n` endpoint。

## 一手来源（实际阅读）

1. Michel Talagrand, [“Some Isoperimetric Inequalities and Their Applications”](https://www.imj-prg.fr/wp-content/uploads/2020/prix/talagrand1990.pdf), ICM 1990 proceedings, §§3–4，尤其 Theorem 3.1、3.2、4.1（PDF第8–11页，印刷页1018–1021）。定理 3.1：均匀独立符号 `X∈{−1,1}^n`、非空 `A`，以到 `conv(A)` 的欧氏距离 `φ_A` 定义，原文给出 `E exp(φ_A²/8) ≤ 1/P(A)`。定理 3.2 将 convex-distance 型结果推广到一般 product probability spaces（不是只限有限因子空间）；其距离由逐坐标可匹配的向量集合取凸包定义，前提仍是参考测度为坐标乘积。定理 4.1 处理原文定义的 `H(A,q,k)` 多候选坐标 matching 扩张，假设 `P(A)>1/2` 及 `q,k≥1`，并给出该扩张的产品测度下界（原文式 (4.2)）。这里不转录常数公式。其多候选 matching 结构与本题坐标改变关系有表面接近性，但没有核实它蕴含本题局部 `a` 位移的几何比较；它也不处理任意 source 密度 `β` 相对 `μ_Q` 的加权质量。

2. Michel Talagrand, [“Concentration of Measure and Isoperimetric Inequalities in Product Spaces”](https://pmihes.centre-mersenne.org/articles/10.1007/BF02699376/), *Publ. Math. IHÉS* 81 (1995), 73–205。保留为背景原始文献索引。主代理本轮只核验该题录页面，未独立复核其内部具体命题，因此本轮主证明不引用其定理或常数。

## 工具适用性

本机 [math-k05-talagrand-convex-concentration/SKILL.md](/Users/zhengzhihao/.codex/skills/math-k05-talagrand-convex-concentration/SKILL.md) 及其 `references/provenance.md` 已阅读。技能要求区分 product convex-distance、Gaussian、transport-entropy 等版本，并核实乘积独立条件；未核实的迁移须标作未证迁移。对这里的 receiver，`μ_Q` 确实满足乘积前提，故几何问题可在该概率空间中表述。剩下须另证：相关 Talagrand 扩张能控制本题的局部坐标移动，以及如何在无密度帽时把任意 `β` 的质量同 `μ_Q` 容量联系起来。该 note 只定位方法和条件，不认证最终关键 lemma。


## 主代理复核记录

主代理实际打开1990原文PDF并核对§3 Theorems 3.1/3.2及§4 Theorem 4.1所在段落。1990稿PDF第8页（零基P7）起为§3，不把旧稿中的页码范围当作精确定位。纠正了“3.2只限有限空间”及“概率不能转Lebesgue体积”的初稿措辞。主要类型Gram定理由本轮显式解析证明给出，不以本note或文献标题作为认证。
