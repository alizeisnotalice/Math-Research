#!/usr/bin/env python3
"""R248 full relocated evidence replay; no cube endpoint certification."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    m=json.loads((ROOT/'manifest.json').read_text())
    for n,h in m.items():assert digest(ROOT/n)==h,n
    return len(m)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);a=ap.parse_args();count=verify()
    if a.verify_only:print('verified',count,'manifest hashes');return
    if a.output_dir is None:ap.error('--output-dir required')
    out=a.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False)
    for n in ('numeric_checks.py','task_contract.md'):shutil.copyfile(ROOT/n,out/n)
    start=time.monotonic()
    r=subprocess.run([sys.executable,str(out/'numeric_checks.py'),'--output',str(out/'numeric_checks.json'),'--contract',str(out/'task_contract.md')],check=True,capture_output=True,text=True,env=os.environ.copy())
    assert (out/'numeric_checks.json').read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'entire JSON mismatch'
    j=json.loads((out/'numeric_checks.json').read_text())
    code=(ROOT/'transport_cost.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    (out/'author_exact.py').write_text(code)
    ar=subprocess.run([sys.executable,str(out/'author_exact.py')],check=True,capture_output=True,text=True)
    assert 'PASS 56' in ar.stdout
    uniform_checks=0
    for c in j['gram_cases']:
        if 'hypergeometric_exact' in c:
            n,k=c['n'],c['k'];assert F(c['gram_exact'])<=(1+F(25*k,n))**k
            uniform_checks+=1
    assert uniform_checks==6
    assert verify()==count
    receipt=dict(complete_replay=True,entire_json_byte_identical=True,manifest_hashes_before_and_after=count,counts=j['counts'],author_exact_checks=56,uniform_rational_bound_checks=uniform_checks,json_sha256=digest(out/'numeric_checks.json'),stdout=r.stdout.strip(),author_stdout=ar.stdout.strip(),elapsed_seconds=time.monotonic()-start,scope='Exact finite label identities and ordinary scalar sampling; not general FULL, network optimizer execution, soft-corollary numerical verification or the general endpoint.')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
