# R248合同：共同仿射基底下的类型交叠几何

一般任意正L1中心立方体n^(1/2+o(1))上界仍为目标，未完成。上一轮247形成独审动态测试矩并推送544f5d4，属实质已保存进展，但未支付补域。本轮不把新门或常数改善替代全局几何。

## 候选与必要定义

原R109共享目标帽的输运矩形族：标签I⊂[n]，sI≥0、ΣsI≤τ，W=Σ∫sI，A_I,t为I上全边ρt、其它t的归一矩形平均，ρ∈[1,3]，t共用[a,2a]。实际体积因子F_I=(3+2/n)^|I|(1+2/n)^(n−|I|)，不可丢弃。

取任一全局固定reference B⊂[n]，定义
E_B=∫Σ_{I,I'} F_I F_I' 26^{|(I△B)∩(I'△B)|}sI sI'。
候选：||sup_t ΣI F_I A_I,t sI||2²≤(1+42log2)² E_B。
可对固定B的标量上界取min；不授权逐接收x无价选B。主机制是整体仿射变换与所有tensor差分阶一次Cauchy，不再逐阶Minkowski。scalar基础v=(sinc(u),(sinc(ρu)−sinc(u))/5)在ρ∈[1/3,3]上满足||v||≤1、||uv'||≤42(1−||v||)。集中单类型取其自身为B后无差分指数，volume F²仍保；diffuse类型保真实交叠。不把未证明受τW控制的E_B称已付预算。

## 允许工具与风险

使用已审R109 M1–13和原共享目标容量/同尺度输运资格，原实际变动坐标标签可不padding。β/ν与原真实receiver、全部维度/物理尺度费用保留。几何cut继承R113耦合：β载于S、H_r(S)⊂N、lowN receiver；饱和计划源是提取η^A，不能移植给残余β，J27不保。

局部resampling路线由Astra仅筛真实cut与原加权交通容量，不得把未知L2/entropy改名成根阶付款。K05凸距离技能只在正确product参考测度上用；μQ=1Qdx/|Q|合法product，不把β当独立。数值沿L03边界，精确Fraction与普通mpmath分开，不声称区间证书。

## 责任和判据

r217_compare写transport_cost.md主lemma及原回代；r217_audit先独审命题再读证明，只写audit.md；r217_numeric写numeric_checks.py/json,numeric_notes.md，3阶段≤12类型配置、scalar约数百点、40/70精度和精确Gram恒等式；r217_peak写cut_geometry.md短结果；r248_cut_literature写literature.md且须主代理核来源；主代理推导整合proof.tex.txt/report.md、独立全复跑、精简归档和逐轮推送。各agent不修改他人文件、交付停止。

成功是经独审的结构性类型估计及合法原付款后果，而非计数报告或声称全余项已付。若所有现有流仍仅有指数最坏预算，须明确。一般闭合须原所有分支有根阶预算，有限模型/条件标签结构不是替代。保详细LaTeX文本，不编译PDF。
