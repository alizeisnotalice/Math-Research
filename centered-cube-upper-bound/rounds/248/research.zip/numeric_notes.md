# R248：共享labels Gram、固定reference及scalar有限证据

实际完成12组结构配置（初探4、压力5、扩大3），其中6组explicit labels、6组uniform k-subsets；explicit组共8个固定reference变体与8个实际F加权Gram/J展开恒等式。另306个scalar点（初探42、压力210、扩大54），包含300个正u ratio与6个零端点。全部已本机实际运行。有限结构是条件模型，不认证原流具有均匀labels资格、一般来源付款或FULL/root闭合。

## 先核符号和预定菜单

使用sinc(u)=sin(u)/u。Fourier归一化sinc仅重标u，不改无量纲形式：

u h'=cos(u)-sinc(u)，u delta'=cos(rho*u)-sinc(rho*u)-cos(u)+sinc(u)。

在u=0导数及norm亏损均0，单独核界0<=0，不计算0/0。ratio的连续极限是2sqrt(1+(rho²-1)²/25)。接近0时用稳定Taylor计算1-sinc和u*sinc'；norm直接从两分量求，亏损用(1-norm²)/(1+norm)的稳定展开，避免近1和近sin零点的两种消减。

初始方案为6 explicit+6对称组及约300scalar点；根据父级准确增强，在原12组内加入两个集中结构的固定B、实际F非齐次系数，并把rho范围扩至[1/3,3]，没有增加结构组数。

## 精确Fraction部分

explicit六组：concentrated_single(n4)、concentrated_cluster(n6)、disjoint(n6)、variable_sizes(n5，含重叠/空label/零系数)、zero_labels(n8)、seeded_variable(n12，16条确定seed标签)。每组共享非负s，sum s<=tau=1；JSON逐条保labels和有理系数，不padding为同大小。

分别直接计算两两intersection Gram及J展开：

G=sum 26^|I∩I'| s_I s_I' =sum_J25^|J|(sum_{I superset J}s_I)^2。

Fraction核其完全相等，并核G<=26^r(sum s)^2<=26^r tau sum s。reference变体以I△B替代I，同时保持s及原F_I；B每组全局固定，不能随receiver x无价选择。也独立精确计算实际F_I=(3+2/n)^|I|(1+2/n)^(n-|I|)的加权pair Gram及加权J展开。两者完全相等；max F_I²乘未加权G另给精确上界，mp层保9^r e^4的统一transport上界。

两个集中结果：

- single：B空时G=456976；取B={0,1,2,3}，G=1=(sum s)^2。实际F加权G/n从2572632521.265625降至5629.6884765625，故集中单类型的差分指数可去，但volume F²确仍非零且很大。
- cluster：B空时G=22477/2；固定B={0,1,2}后G=691/16。此B为其中一个完整label，另一变换label为{2,3}。

对称六组(n,k)=(4,0),(4,4),(16,2),(64,8),(512,16),(1000000,32)，总s=1，类型均匀。无需枚举comb(n,k)个types，独立比较精确hypergeometric式

sum_j comb(k,j)comb(n-k,k-j)26^j/comb(n,k)

与交集阶乘矩式sum_j25^j comb(k,j)^2/comb(n,j)。所有Fraction相等，含k0/k=n端点，并核<=26^k。这里只是类型均匀条件模型；没有推断原交通具备该分布。

## 成本比较和结构价值边界

每组输出旧Q_r²=(sum_j8^j sqrt(comb(r,j)))²、新Gram、Gram/旧Q²，以及共同乘9^r e^4后的成本/n。explicit另输出实际非齐次F加权成本，不把统一上界冒充实际F值。

代表数值：uniform n16,k2的G=299/24≈12.4583；n512,k16的G≈2838.70615；n1e6,k32的G≈1.02590984。最后一例G/旧Q²≈3.2073e-59，然而9^32 e^4 G/n≈1.9233017403e26。Gram显著改善不等于费用已获一般付款；volume不能省，不能从这些例拟合一般维数阶。

## Scalar普通多精度证据

rho精确取{1/3,1/2,1,3/2,2,3}，每个51个u点；u范围0到1e6，非零最小1e-30，rho*u最大3e6。包含近零、0.1至大尾部、近pi/2pi/3pi等小数位置的振荡压力。pi附近输入是JSON记载的确定十进制，不声称等于数学pi。

全部采样通过||v||<=1和||uv'||<=42(1-||v||)。300个正u样点的最大观测ratio为3.7735924528226415245，rho=3,u=1e-30，接近相应零点极限。它仅是有限菜单观测最大值，不是全域上界证明。每点及cost独立mp40/70复核，enc50保留工作精度差异；差值分母max(1,abs(high))。Gram/cost最大差约3.017794388e-41，scalar最大差约1.000864235e-37。普通mpmath非区间证据，不据一致性声称严格舍入/求值误差包围。

## 实际运行与可迁移复现

最终脚本完整实际运行，之前也实际运行过未稳定norm版和未补加权J恒等式版；最终JSON来自稳定norm及完整加权Fraction账版本。未扩模型菜单，未额外timing重跑；父级将作唯一最终包外完整复跑。

依赖：bundled Python3.12.14、vendor mpmath1.3.0，加Python标准库；无需numpy/scipy。JSON无runtime、时间戳或绝对路径，绑定源码与冻结合同SHA。CLI --output PATH、--contract PATH；默认相邻numeric_checks.json及task_contract.md。解压后在同目录运行：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 numeric_checks.py --contract task_contract.md --output replay.json
cmp numeric_checks.json replay.json
```

最终源码SHA256：1180700f0718f96166263363934e455ddff35db6ba07a75ae27eab6fc1edb768。JSON334846字节，SHA256：ce24bfc6910bf01c7bb15eb03f851861a91f52f1b05c2996d93a30cf2041ac11。合同SHA256：9fbbdcc4b9683c19f37b222202eeeb590f6f77fed275c69377021da80ae1e3f1。counts键供driver直接读取。
