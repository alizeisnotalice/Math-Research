#!/usr/bin/env python3
"""R248 finite label Gram and scalar sinc evidence, not interval/FULL proof."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
from math import comb
import argparse, hashlib, json, random
import mpmath as mp

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x): return mp.nstr(x,50)
def fm(x): return mp.mpf(x.numerator)/x.denominator

def label_cases():
    rng=random.Random(248)
    return [
      ('initial','concentrated_single',4,[({0,1,2,3},F(1))]),
      ('initial','concentrated_cluster',6,[({0,1,2},F(3,4)),({0,1,3},F(1,4))]),
      ('pressure','disjoint',6,[({0,1,2},F(1,2)),({3,4,5},F(1,2))]),
      ('pressure','variable_sizes',5,[(set(),F(1,8)),({0},F(1,8)),({0,1},F(1,4)),({1,2,3},F(1,4)),(set(range(5)),F(1,8)),({4},F(0))]),
      ('pressure','zero_labels',8,[(set(),F(0)),({0,1},F(0)),({1,2,3},F(0))]),
      ('expanded','seeded_variable',12,[(set(rng.sample(range(12),rng.randrange(7))),F(rng.randrange(10),200)) for _ in range(16)])]

def exact_label(c):
    phase,name,n,rows=c; tau=F(1); total=sum((s for _,s in rows),F()); r=max((len(I) for I,s in rows),default=0); assert total<=tau
    direct=sum((26**len(I&J)*s*t for I,s in rows for J,t in rows),F())
    subsets={frozenset(J) for I,_ in rows for j in range(len(I)+1) for J in combinations(sorted(I),j)}
    expansion=sum((25**len(J)*sum((s for I,s in rows if J<=I),F())**2 for J in subsets),F())
    cap=26**r*tau*total; strong=26**r*total**2
    assert direct==expansion and direct<=strong<=cap
    references=[]
    for B in [set()]+([set(rows[0][0])] if name in ['concentrated_single','concentrated_cluster'] else []):
        transformed=[(I^B,s) for I,s in rows]
        R=max((len(I) for I,s in transformed),default=0)
        G=sum((26**len(I&J)*s*t for I,s in transformed for J,t in transformed),F())
        js={frozenset(J) for I,_ in transformed for j in range(len(I)+1) for J in combinations(sorted(I),j)}
        expanded=sum((25**len(J)*sum((s for I,s in transformed if J<=I),F())**2 for J in js),F())
        assert G==expanded and G<=26**R*tau*total
        fs=[(F(3)+F(2,n))**len(I)*(1+F(2,n))**(n-len(I)) for I,_ in rows]
        WG=sum((26**len((I^B)&(J^B))*s*t*fs[i]*fs[j] for i,(I,s) in enumerate(rows) for j,(J,t) in enumerate(rows)),F())
        weighted_expansion=sum((25**len(J)*sum((s*fs[i] for i,(I,s) in enumerate(rows) if J<=I^B),F())**2 for J in js),F())
        assert WG==weighted_expansion
        if name=='concentrated_single' and B: assert G==total**2
        references.append({'B_fixed':sorted(B),'reference_scope':'one globally fixed reference, not receiver-dependent menu','transformed_r':R,'gram_exact':str(G),'J_expansion_exact':str(expanded),'cap_exact':str(26**R*tau*total),'actual_F_coefficients':[str(v) for v in fs],'actual_F_weighted_gram_exact':str(WG),'actual_F_weighted_J_expansion_exact':str(weighted_expansion)})
    return {'references':references,'phase':phase,'name':name,'n':n,'r':r,'tau':str(tau),'total_s':str(total),'labels':[{'I':sorted(I),'s':str(s)} for I,s in rows],'gram_exact':str(direct),'J_expansion_exact':str(expansion),'distinct_J_count':len(subsets),'cap_exact':str(cap),'strong_cap_exact':str(strong),'cap_slack_exact':str(cap-direct),'kind':'explicit finite labels'}

def symmetric():
    out=[]
    for phase,n,k in [('initial',4,0),('pressure',4,4),('initial',16,2),('pressure',64,8),('expanded',512,16),('expanded',1000000,32)]:
        den=comb(n,k)
        hyper=sum((F(comb(k,j)*comb(n-k,k-j)*26**j,den) for j in range(max(0,2*k-n),k+1)),F())
        moments=sum((F(25**j*comb(k,j)**2,comb(n,j)) for j in range(k+1)),F())
        assert hyper==moments and hyper<=26**k
        out.append({'phase':phase,'name':f'uniform_{n}_{k}','kind':'uniform k-subsets conditional model, not original type-flow qualification','n':n,'r':k,'k':k,'type_count_exact':str(den),'tau':'1','total_s':'1','gram_exact':str(hyper),'hypergeometric_exact':str(hyper),'J_moment_expansion_exact':str(moments),'cap_exact':str(26**k),'cap_slack_exact':str(26**k-hyper)})
    return out

def costs(row,dps):
    with mp.workdps(dps):
        r=row['r']; G=fm(F(row['gram_exact'])); old=sum(mp.mpf(8)**j*mp.sqrt(comb(r,j)) for j in range(r+1))**2
        transport=mp.mpf(9)**r*mp.exp(4)
        result={k:enc(v) for k,v in {'old_Qr_squared':old,'Gram_as_mp':G,'Gram_over_old_Qr_squared':G/old,'transport_F_squared_upper':transport,'conditional_transport_Gram_over_n':transport*G/row['n'],'conditional_old_transport_over_n':transport*old/row['n'],'worst_Gram_cap_over_old':fm(F(row['cap_exact']))/old}.items()}
        for idx,ref in enumerate(row.get('references',[])):
            rg=fm(F(ref['gram_exact'])); wg=fm(F(ref['actual_F_weighted_gram_exact'])); maxF=max(F(v) for v in ref['actual_F_coefficients'])
            assert F(ref['actual_F_weighted_gram_exact'])<=maxF**2*F(ref['gram_exact'])
            assert fm(maxF)**2<=transport
            result[f'reference_{idx}_actual_F_weighted_Gram_over_n']=enc(wg/row['n'])
            result[f'reference_{idx}_transport_upper_Gram_over_n']=enc(transport*rg/row['n'])
        return result

# Stable small-u quantities: d=1-sinc(u), z=u*sinc'(u).
def stable(u):
    if not u: return mp.mpf(0),mp.mpf(0)
    if abs(u)>=mp.mpf('.2'):
        h=mp.sin(u)/u
        return 1-h,mp.cos(u)-h
    term=u*u/6; deficit=term; deriv=-2*term; j=1
    while True:
        term*=-u*u/((2*j+2)*(2*j+3)); j+=1
        deficit+=term; deriv-=2*j*term
        if abs(term)<mp.eps*abs(deficit): break
        assert j<200
    return deficit,deriv

def scalar_points():
    # 6 rho values times 51 distinct nonnegative u: 306 points including u=0.
    base=['0','1e-30','1e-20','1e-12','1e-6','.001','.01','.05','.1','.2','.3','.5','.75','1','1.25','1.5','2','2.5','3','3.1415926535897932384626433832795','3.25','3.5','4','4.5','5','6','7','8','10','12','16','20','24','32','40','48','64','80','100','128','160','256','512','1000','10000','1000000']
    # Additional rational near-oscillation pressure without pretending pi is exact.
    base+=['3.14159265358979','6.28318530717958','9.42477796076937','31.4159265358979','314.159265358979']
    return [(rho,u) for rho in ['1/3','0.5','1','1.5','2','3'] for u in base]

def scalar(rho_s,u_s,dps):
    with mp.workdps(dps):
        rho,u=fm(F(rho_s)),mp.mpf(u_s)
        if not u: return {'norm':'1.0','uvprime_norm':'0.0','deficit':'0.0','ratio':None,'zero_limit_ratio':enc(2*mp.sqrt(1+(rho*rho-1)**2/25)),'scalar_bound_slack':'0.0'}
        d,z=stable(u); dr,zr=stable(rho*u); delta=d-dr
        # 1-||v||² computed without subtraction near u=0.
        squared_deficit=2*d-d*d-delta*delta/25
        assert squared_deficit>=0
        h=mp.sin(u)/u
        norm=mp.sqrt(h*h+delta*delta/25); deficit=squared_deficit/(1+norm)
        deriv=mp.sqrt(z*z+(zr-z)**2/25); ratio=deriv/deficit
        slack=42*deficit-deriv
        assert norm<=1 and slack>=0
        return {k:enc(v) for k,v in {'norm':norm,'uvprime_norm':deriv,'deficit':deficit,'ratio':ratio,'scalar_bound_slack':slack}.items()}

def diff(a,b):
    with mp.workdps(100):
        vals=[abs(mp.mpf(a[k])-mp.mpf(b[k]))/max(1,abs(mp.mpf(b[k]))) for k in a if a[k] is not None]
        return max(vals,default=mp.mpf(0))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json')); ap.add_argument('--contract',type=Path,default=Path(__file__).with_name('task_contract.md')); args=ap.parse_args()
    out={'scope':'Finite nonnegative shared-label Gram certificates and ordinary multiprecision scalar samples, no outward intervals, FULL or global source-flow qualification. Transport factor 9^r exp(4) retained.','source_sha256':sha(__file__),'contract_sha256':sha(args.contract),'dependencies':{'python':'3.12.14','mpmath':mp.__version__},'gram_cases':[],'scalar_cases':[]}; md=mp.mpf(0)
    for row in [exact_label(c) for c in label_cases()]+symmetric():
        a,b=costs(row,40),costs(row,70); delta=diff(a,b); assert delta<mp.mpf('1e-25');md=max(md,delta);row.update({'mp40':a,'mp70':b,'precision_max_scaled_difference':enc(delta)});out['gram_cases'].append(row)
    maxratio=(mp.mpf(0),None); scalar_md=mp.mpf(0)
    for rho,u in scalar_points():
        a,b=scalar(rho,u,40),scalar(rho,u,70);delta=diff(a,b);assert delta<mp.mpf('1e-25');scalar_md=max(scalar_md,delta)
        row={'rho':rho,'u':u,'phase':'initial' if u in ['0','.1','.5','1','2','3','4'] else ('expanded' if mp.mpf(u)>=100 else 'pressure'),'mp40':a,'mp70':b,'precision_max_scaled_difference':enc(delta)}
        out['scalar_cases'].append(row)
        if b['ratio'] is not None:
            rr=mp.mpf(b['ratio'])
            if rr>maxratio[0]: maxratio=(rr,{'rho':rho,'u':u,'ratio':b['ratio']})
    out['counts']={'gram_cases':len(out['gram_cases']),'explicit_label_cases':6,'hypergeometric_cases':6,'fixed_reference_variants':8,'weighted_reference_identities':8,'scalar_points':len(out['scalar_cases']),'scalar_positive_u_ratio_checks':sum(c['u']!='0' for c in out['scalar_cases']),'scalar_zero_endpoint_checks':6}
    out['summary']={'max_observed_ratio':maxratio[1],'gram_max_scaled_precision_difference':enc(md),'scalar_max_scaled_precision_difference':enc(scalar_md),'precision_scope':'enc50 mp40/mp70 comparison, not certified interval error','sinc_convention':'sin(u)/u; normalized Fourier convention merely rescales u'}
    args.output.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(out['counts']);print(out['summary'])
if __name__=='__main__': main()
