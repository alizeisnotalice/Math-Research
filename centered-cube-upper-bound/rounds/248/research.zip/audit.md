# R248 独立审核

## 命题先行筛查（未读transport_cost作者稿）

首次目录仅有literature.md，尚无本轮合同/主作者稿；不从缺失文本补造原接口。仅写audit.md，不Git/PDF/spawn、不改他人。以下先独立核给定准确候选。

### 1. sinc向量的统一常数：PASS

h(0)=1、h(u)=sin(u)/u，δ=h(ρu)−h(u)，v=(h,δ/5)，固定共同ρ∈[1,3]。u=0时||v||=1、uv′=0。利用偶性只需u>0。

0<u≤1时，h≤1−u²/7（sin的交错Taylor），h≥0；积分cos表示给|δ|≤(ρ²−1)u²/6≤4u²/3，|u h′|≤u²/3及|u δ′|≤(ρ²+1)u²/3≤10u²/3。因此

`1−||v||²≥(1/7−16/225)u²=113u²/1575`，
`1−||v||≥113u²/3150`，`||uv′||≤sqrt(5)u²/3`。

u≥1时，全域|h(u)|≤6/7：在[1,7/6]用sinc递减及h(1)≤6/7，之后用1/u。ρu≥1同样成立，故||v||²≤1044/1225、1−||v||≥181/2450。又uh′=cosu−h(u)，得||uv′||≤sqrt(116)/5。两区均严格足以给`||uv′||≤42(1−||v||)`以及||v||≤1。本机Fraction已实际核两个最终常数平方比较，分别5/9≤(42·113/3150)²及116/25≤(42·181/2450)²；一般依据是上面的解析分区，不从有限点猜测。

### 2. 同时标签张量与Plancherel：PASS，需共同基底

令g_J=Σ_{I⊃J}s_I、c_J=5^{|J|}g_J，固定所有s_I再变共同t。乘子展开一次为 `Σ_J c_hat_J Π_{i∈J}(δ(tξ_i)/5) Π_{i∉J}h(tξ_i)`。这是一个2^n维向量内积，不逐|J|做Minkowski。记V=⊗v(tξ_i)、r_i=||v(tξ_i)||，则||V||=Πr_i≤1，且

`||∂logt V||≤42Σ_i(1−r_i)Π_{l≠i}r_l≤42`。

最后一和是独立Bernoulli数值中恰一个失败的概率，或直接展开非负乘积恒等式可证≤1；这里只是代数，不假设原来源或坐标随机独立。r_i=0时不用除r_i，界仍成立。

因此Plancherel给起点L2范数≤||c||_{L2(l2)}、每时刻导数≤42||c||；只沿log-time作FTC和Minkowski得

`||sup_{a≤t≤2a} Σ_I A_{I,t}s_I||²_2≤(1+42log2)² Σ_J25^{|J|}||g_J||²_2`。

非负有限展开恰给`Σ_J25^{|J|}g_J²=Σ_{I,I′}26^{|I∩I′|}s_I s_I′`，没有隐含标签个数或binomial费用。sup可用连续卷积代表及有理t恢复；L2值绝对连续/时间导数可积给几乎处处FTC，无需对任意L1函数指定边界trace。L1∩L∞保证每个标签L2且有限展开合法；固定n总共仅2^n个不同subset，重复标签须先聚合。若另取countable非负标签极限，必须保共同ρ/同一实际函数族及有限右端/总质量，不能对t重选输入或标签。

### 3. 粗帽与原量费用

若|I|≤r且Σs_I≤τ（几乎处处），W=Σ||s_I||1，则右端≤26^r τW。原运输额外幅度因子F≤3^r e²若确在相应原接口成立，平方后必须保F²≤9^r e4，合为e4·234^r·τW再乘(1+42log2)²。不能丢e4、不能声称234^r一般是根阶或免费扩维。该运输接口的实际资格待作者原稿审，当前只核代数费用。

所有标签须共享一个固定ρ、同一t及同一空间基底。ρ随I/t/source变化、标签依t重新生成、或标签有不同移动平移时，上述共同tensor乘子/导数证明不自动适用。固定共同平移可由L2酉性处理；移动phase的导数与逐标签shift需另证，尚未授权“simultaneously shift”改进。实际研究中的receiver/source门与T参数选择也不能因这个抽象最大平均界自动获得费用。

命题先行结论：给定共同矩形核下的向量常数、平方重叠张量账和有限/合格非负极限成立。一般原交通/root预算仍不由此闭合；等作者稿后核真实接入。


## 独立增强筛查：固定reference B的中心化Gram

在未读作者稿前收到新增准确命题。对任意全局固定B⊂[n]，令D_B=diag(ρ^{1_{i∈B}})，x=D_Bx′，s′_I(x′)=s_I(D_Bx′)。原normalized矩形平均共轭成relative side ρ^{1_{i∈I}−1_{i∈B}}t；每坐标的非平凡比只依该坐标是否在B，为ρ或1/ρ，active标签恰I△B，故仍共享同一tensor基底。原label幅度F_I完整保留。

scalar向量界可扩至ρ∈[1/3,3]：小u证明仍用|ρ²−1|≤8及ρ²+1≤10。大u只需|h(u)|≤6/7、|δ|≤2，得1−||v||²≥129/1225，1−||v||≥129/2450；导数仍≤sqrt(116)/5。本机Fraction另实际核116/25≤(42·129/2450)²，故同5/42有效，不需更换常数。

Plancherel给relative Gram权26^{|(I△B)∩(I′△B)|}。detD_B=ρ^{|B|}在原L2平方与右侧源积分变元中相消，没有额外Jacobian幅度，也不能误多乘ρ^{|B|}。如果s′有pointwise capτ，其L1总量为det^-1 W，回原坐标后同样抵消。该计算是矩形算子的共轭，不宣称原中心cube极大问题对任意仿射变换具有额外不变性。

原F_I来自运输的物理体积/源密度费用，不能因reference改变而改写成3^{|I△B|}或删除。单label I0选B=I0只消symbol exponential，F_I0²仍保留。对同一operator的有限多个全局固定B上界可取min，无菜单损失；B可在整组冻结输入后确定，但不允许逐x或t免费选不同基底。真实标签须记录实际改变坐标；padding成更大subset会改变矩形或隐藏假费用，不能据此制造改善。

增强抽象命题通过；原运输representation与receiver/source回代仍待稿后审，不能将centered Gram本身称一般付款。


## 同轮独立补筛：全soft两参数推论

新增候选先独筛，后窄读R112 astra_joint.md:74–121的J9–10。共同卷积K_{s,L}=⊗[(1−s)δ0+s w_L]乘子满足|K|≤1、|DK|≤2、|∂sK|≤H_n、|D∂sK|≤4H_n，H_n=min(n,1/s)、∫H_n=1+logn；该有限乘积代数不假设接受后来源独立。

对本轮一次全J的V，W=KV的向量范数分别满足1、D导数44、s导数H_n、混合导数46H_n。2D FTC的四项因而给

`Csoft5=1+44log2+(1+46log2)(1+logn)`，

`||sup_{s∈[0,1], L∈[a,2a]} K_s,L*Σ F_I A_I,(1+2/n)L s_I||2²≤Csoft5² E_B`。

D_B变元后K频率为w_hat(Lξ_i/d_Bi)，固定d_Bi>0仍逐坐标0≤b_i≤2a_i，所以J10及常数不变；t=(1+2/n)L使log导数正相同。Jacobian仍在两侧抵消。必须同一计划、共同K与所有label同L，在正卷积后取共同sup；不同label的s/L选择不由此授权。该推论可用于已认证原soft extraction的同类比较，source价格Csoft5²E_B/(4ελ)；不授旧残余β或当前完整Π余项的付款，也不免费扩大旧cut。基础12/306数值只核Gram/scalar，不称soft两参数数值验证。

## 作者稿后初审

合同现已完整读取。transport_cost.md已全文审：TC2小u的157/1800常数来自19/120−16/225，large-u的129/2450与inverse-ρ正确；TC3整体tensor Cauchy、导数概率代数、L2近似/有理scale极限正确。TC4 centered Gram的PSD、单type基底、weighted τ帽与collision证书均通过；collision不是由共享cap自动小。FI须是固定label几何系数，稿中已明确。

已窄读R109 integration_main.md:9–40、42–109。TC8 actual-changed格标签无需padding；outside位移≤a/n、inside≤a+a/n，在原R≥a下给明确rectangle与完整FI。所有label共享t=(1+2/n)R；a≤R≤2a为一个octave。TC9的真实receiver Cauchy–Young因X=λ|E|给εX+C5²E_B/(4ελ)，q/FIRST未另被假设，原RN≤1与共享cap只用一次。多网络runmax仍须按原系数总账支付，不能每label领εX。

TC10的FI≤3^r e²、26^r合为e4·234^r保留；n≥512时r=max(1,floor(logn/log234))有234^r≤n，故该认证提取网络价格可达所列根阶对数级。该r更新必须重新运行网络并重建top/rank/尾源/receiver标签，不能将新r-halo追授冻结的旧β/ν。本轮主要机制是centered actual-type Gram，不以729→234常数改写充一般几何突破。等待最终soft整合/主稿绑定。

cut_geometry.md CG2–4通过：K_i是均匀Q下的可逆概率核，保绝对连续，互异≤r个坐标且每次位移≤a才保终点入N。normalized推前支持于低体积N给L²及entropy下界，而非按mass的上界；p=0非零ac源被排除、零源不归一化。η^A的饱和计划不能替代残余β/ν计划；没有已证RN比较或将该局部辅助核等同Π。超过r或把H_r(S)迭代成H_r(N)均未授权，稿中未声称新traffic付款。


## 主稿初次整合审核与新增corollary独筛

主proof.tex.txt已全文审核。scalar/full-subset/affine步骤与独筛一致。hard原回代保真实dx、共同计划目标cap及完整FI，εX系数正确。soft段已独立窄读R112 J21–22：原U_η≤C_hP_{s,L}η，C_h=16/3；故原交通付款必须用C_h² Csoft5²E_B/(4ελ)，稿中已保平方而非只收C_h。所有网络running-maximum增量的费用仍相加，未对每label重领targetcap或εX。

有限网络重路由部分是有条件的固定资料存在性：target-piece密度由edge-flow线性给出，E_B是PSD Gram的凸二次目标。只有保持完整source提取子测度、需保持的coupled子流、shared target帽与maxflow值的非空紧多面体才可优化，原计划保证非空；只固定总流值不足以保原点态source耦合。固定B逐个求解再取最小不产生菜单数学费用，但不声称多项式计算或逐receiver免费选B。本轮没有实际求此QP、没有给优化Gram一般付款；若将其优化选择放到随机seed外积分，还须证明相应可测性（已向主代理建议补明），不从逐网络存在性自动推出。当前主证明没有使用随机优化解。

新增uniform-k corollary先独筛通过：必须逐空间点满足s_I=S/binom(n,k)，不能只要求总label质量均匀。所有|I|=k时FI共同，故E_empty=F_k² G||S||²，G=Σ_j25^j binom(k,j)²/binom(n,j)。因binom(k,j)/binom(n,j)≤(k/n)^j，得G≤(1+25k/n)^k≤exp(25k²/n)。k=0及k=n均合法，F_k²不省。此是附加类型分布资格，不声称原流自动拥有；即使k≈√n的symbol费用受控，原物理指数9^k仍可能很大。driver可在既有六组hypergeometric有理G上核新有理帽，不增加模型样本。


## 最终作者/主稿/报告整合结论

**PASS：共同基底下的all-subset Gram定理、hard/soft认证提取费用及固定网络有条件重路由接口成立。未证明一般残余双Π交通/root闭合。** transport_cost.md最终TC6–8已全文补审，主proof最终uniform-k与QP可测性句已核，合同、cut辅助稿及report/reproduce范围一致。

- TC6与主稿soft推论保相同输入/计划、共同s,L、不混source-dependent软选择；导数44/46与Csoft5正确，原软端C_h²=256/9费用保留。固定仿射后逐坐标J10代数不变，无新det费用。
- TC7的fixed-source/coupled约束与主稿固定网络凸QP只陈述存在性；主稿已明确随机seed外积分使用优化解须另证可测性。本轮没有实际求解QP，也没有把它的未知最优Gram称已付预算。
- uniform-k新corollary明确逐点s_I=S/binom(n,k)的附加资格，G有理帽及exp帽方向正确，F_k²仍在。原shared cap与有限hypergeometric例都不推出实际流自动均匀。
- 已认证计划的提取比较确可付款，当前旧残余来源不因新r或reference而自动有新cut。rough worst e4·234^r与更细centered Gram可保取min，未把常数优化当完整几何闭合。
- cut_geometry不提供新的交通付款，初始source密度/entropy上界或到饱和计划的RN转移仍缺。主证明不依赖literature.md的外部迁移；文献原文核查属于主代理已报告执行，本人未再浏览或独立认证1990/1995内部定理。下表literature hash只绑定交付版本及其非依赖范围，不冒称外部文献复核。

### 正式数值与复现的静审

本人静审numeric_checks.py、原始JSON与notes，未重复完整数值运行。6个explicit与6个hypergeometric组均保共享非负cap；实际FI的Fraction weighted Gram及全J展开准确，reference变换只动I△B不动FI，8个reference/weighted恒等式计数一致。大n对称组用精确超几何式与阶乘矩式独立相等，不枚举全部labels，范围明确是条件模型而非原flow资格。

sinc小u稳定级数的deficit/导数符号正确，inverse-ρ及u=0单列，亏损用稳定(1−norm²)/(1+norm)而非近1直接相减。300个正u与6零点构成306样点；有限最大ratio3.77359245不是全域最优常数。40/70比较按max(1,|high|)缩放，结构最大差3.017794388e−41、scalar1.000864235e−37为普通数值诊断，不是interval或50位正确数字保证；输入近π的十进制不被当作精确π。数值未测soft两参数/真实优化器/FULL。

已实际解析两Python脚本AST，并读取JSON counts及source/contract内置SHA与实文件一致。本人本轮额外实际工具只有初筛3项Fraction常数平方比较；为可重放性，精确等价命令为：

```python
from fractions import Fraction as F
assert F(5,9)<=(42*F(113,3150))**2
assert F(116,25)<=(42*F(181,2450))**2
assert F(116,25)<=(42*F(129,2450))**2
print('PASS 3')
```

这是解析证明常数的有限算术检查，不混入正式12/306或作者56项。作者56项代码已静审，Gram/cap/collision与整数cutoff断言准确；root driver会完整提取执行它，并在既有六个exactG核uniform rational帽。本审核不提前记录这些root包外运行通过。

report准确区分结构定理、认证提取费用、未实施QP、cut缺口及一般目标未完。reproduce.py先核manifest，复制源码/合同到包外新目录，重算完整JSON并字节比较，执行作者56项和既有6组有理帽后再核manifest，外置回执；未增加模型、未以基础数值冒充soft数值验证。

## 最终受审版本

| 文件 | SHA256 |
|---|---|
| task_contract.md | `9fbbdcc4b9683c19f37b222202eeeb590f6f77fed275c69377021da80ae1e3f1` |
| proof.tex.txt | `df1d176d4fb20151f51e3a341b3b9dda04772aa6ae7fe47cb2285b526d8025da` |
| transport_cost.md | `1faa69d4bf2c34bdec42a3ffc427ec6900575201e298cc2e80af64ae5723be3d` |
| cut_geometry.md | `7f7658fdd003449291cd2d1ba0ed96af37fe406b9281885d5e6d462616651382` |
| literature.md | `201b53a1354930ce1914be71532f88996928285e0d812096ff7fe2f8c978e44c` |
| numeric_checks.py | `1180700f0718f96166263363934e455ddff35db6ba07a75ae27eab6fc1edb768` |
| numeric_checks.json | `ce24bfc6910bf01c7bb15eb03f851861a91f52f1b05c2996d93a30cf2041ac11` |
| numeric_notes.md | `ab42e39f6650bd0b907f0716abf97c810a28edd014e84704c04686a33f1e615b` |
| report.md | `3ed60ae78f9bf13d30bba980d20a4c3857216c20bfa090f589ecd7d357acca14` |
| reproduce.py | `951fc8b0095a3f22c92ebaa67d40096ab33db9dfa1a544c6a45e3bf002e9edf7` |

最终审核至此冻结，停止写入。保原所有来源/网络/体积/菜单费用；一般残余共同source/receiver预算及全局弱型目标未由本轮工具代付。
