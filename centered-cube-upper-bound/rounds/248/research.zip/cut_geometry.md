# R248：原 cut 的坐标更新筛查（有界未闭合记录）

本稿只检查 R247 动态门补域的 cut 路线。没有得到新的原交通付款，也没有把辅助 Markov 核替换为原完整后验。R247 的补域仍是原正测度上的
\[
 T_x(v)e_t(y)<HqD(x,y,v),
\]
并保原 high、heavy、capture、历史、真实接收点和所有来源。下面的结论只定位低接收体积能够支持的推论，以及首次缺少的加权比较。

## CG1　使用的原资格

固定原外数据、终端叶 \(V\) 和实际接收立方体 \(Q=Q_R(x)\subset V\)，其中 \(a\le R\le b\le2a\)。原耦合残余来源满足
\[
 0\le\nu\le\beta\le f\,dx,\qquad
 \beta(V\setminus S)=0,
\]
\[
 H_{r,a,V}(S)\subset N,\qquad
 |N\cap Q|<|Q|/\ell.
 \tag{CG1}
\]
这里 \(r=\max(1,\lfloor\log n/\log729\rfloor)\)，\(H\) 只允许至多 \(r\) 个坐标改变，每个坐标位移至多 \(a\)。所有支持陈述按原半开 piece 和零测边界约定理解。

来源依据：R109 `integration_main.md` V9–V11；R112 `astra_joint.md` J25–J26、J28–J30；R237 冻结 `source_ledger.md` SL1–SL5。耦合 R113 保留这些 cut 资格，但不保留 R112 J27 的逐来源正提取结论。饱和计划是
\[
 \pi_\alpha^A:\eta_\alpha^A\longleftrightarrow
 \tau_r\mathbf1_N\,du,\qquad
 \eta_\alpha^A\le\eta_\alpha,
 \tag{CG2}
\]
而不是以残余 \(\beta\) 或 \(\nu\) 为源的计划。原所有类型共用一次目标容量，不能逐坐标标签复制该容量。

## CG2　可以严格成立的局部更新

写 \(Q=\prod_{i=1}^n I_i\)，每个 \(I_i\) 长 \(R\)。在一维定义
\[
 K_i(z_i,du_i)=\frac{\mathbf1_{I_i}(u_i)
                  \mathbf1_{|u_i-z_i|\le a}}{2a}\,du_i
 +\left(1-\frac{|I_i\cap[z_i-a,z_i+a]|}{2a}\right)
   \delta_{z_i}(du_i).
 \tag{CG3}
\]
它是概率核：连续部分质量至多一，余项非负。连续部分在 \((z_i,u_i)\) 对称，原地项也自伴，故 \(K_i\) 对 \(I_i\) 上均匀概率测度可逆且保持该测度。

取至多 \(r\) 个**互异**坐标组成 \(I\)，在这些坐标各用一次 \(K_i\)，其余坐标不动，得到 \(K_I\)。也可对这些 \(I\) 取任意固定概率混合 \(K\)。则 \(K\) 对 \(\mu_Q=|Q|^{-1}\mathbf1_Qdx\) 可逆，且
\[
 z\in S\cap Q\quad\Longrightarrow\quad K(z,N\cap Q)=1.
 \tag{CG4}
\]
证明只用每条更新路径在 \(Q\subset V\) 内、至多改变 \(r\) 个坐标且各位移至多 \(a\)，然后应用 CG1。这个结论不涉及原 \(Z_{j,t}(y)\)、\(w_t\)、\(e_t\) 或 \(\Pi_t\)；因此不是原来源过程的可逆性结论。

## CG3　低体积给出的方向

设 \(\sigma\) 是支撑于 \(S\cap Q\) 的非零有限绝对连续测度，例如 \(\nu|_{S\cap Q}\)。归一化后写
\[
 \sigma/\sigma(Q)=f\,d\mu_Q,\qquad
 (\sigma/\sigma(Q))K=f_K\,d\mu_Q.
\]
\(K\) 保持绝对连续性，且 \(f_K\) 支撑于 \(N\cap Q\)。若 \(p=\mu_Q(N\cap Q)\)，则 \(p>0\)，Cauchy 与条件 Jensen 分别给
\[
 \int_Q f_K^2\,d\mu_Q\ge p^{-1}>\ell,
 \qquad
 \int_Q f_K\log f_K\,d\mu_Q\ge\log(1/p)>\log\ell.
 \tag{CG5}
\]
允许左侧为 \(+\infty\)。若 \(\sigma(Q)=0\)，该来源行零，无需归一化；若 \(p=0\)，CG4 与绝对连续性排除非零 \(\sigma\)。

这些是下界。即便另有辅助核的 \(L^2\) 收缩或熵耗散估计，也必须保留相应初始 \(\int f^2\) 或 \(\int f\log f\) 费用。CG1 并未给它们一个按原来源质量计的上界。原 \(\nu\) 的 rank 仅限制完整 birth piece 的质量，不限制 piece 内密度；它也不授予 \(\beta\) 同一 rank。总量 \(\beta(V)<\sqrt n\nu(V)\) 不能改作逐点密度比较。

## CG4　迭代与原交通之间首次缺少的步骤

超过 \(r\) 个互异坐标的更新，或重复更新使某个坐标累计位移超过 \(a\)，不再由 CG1 保证终点属于 \(N\)。不能把 \(H_r(S)\subset N\) 迭代成 \(H_r(N)\subset N\)。多步混合至 \(\mu_Q\) 因而既需要初始密度费用，也需要说明离开该短路径支持后如何计入原交通。

更早的加权缺口已发生在一次合法短路径：CG4 只给 \(\sigma K\) 的支持包含，**不给**它相对 \(\tau_r\mathbf1_Ndu\) 的密度上界。CG2 是提取来源 \(\eta_\alpha^A\) 的真实计划，不是残余来源的支配关系。两者之间没有经认证的 Radon–Nikodym 比较；不能把既有 high-\(N\)/提取费用再用一次来支付残余来源。

回到本任务，需要处理的是原来源 \(\beta(dy)\nu(dz)\)、硬核 \(h_R(x-z)\) 与完整 \(\Pi_t(dv)\Pi_t(du)\) 下的正 score \((k_t(v)-k_t(u))_+\)，并保补域和历史权。局部核 CG3 没有把这项加权交通送到 CG2 的计划，也没有证明每单位真实来源在 \((x,j,t)\) 的多次使用可由一次目标容量结算。均匀 \(Q\) 的可逆性不能提供这个比较；\(\nu\)、\(\beta\) 和原后验均不是 \(\mu_Q\)。

因此本路线停在明确的结构缺口：**尚无从原加权正交通到已认证 cut 计划的、保共同目标容量且不重复来源费用的转移估计。** 本稿不把这一缺口改名为新的待付矩，也不提出无依据的逐点支配作为已证结论。

## CG5　交付范围

CG3–CG5 是原 cut 上可直接核验的辅助几何结论；没有得到 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)W\) 的新付款，不扩大 R247 已付门。本分支没有新增数值实验；本轮正式数值附件检验的是另一条共同仿射基底/类型 Gram 路线，不能作为本稿加权转移缺口的证据。停止本路线，保原完整来源、后验和既有费用分配。
