# R402 — A paid same-coordinate bilateral fraction for near source pairs

## 1. Exact scope and new receipt

Keep the complete R398–401 field, actual du, full f, matching m_w=q_wR_w^n, q_-≤q_w≤λ, and a≤R_w≤b≤2a. All original χ, clocks, stages γ_i and b_i, ranks and h remain unchanged. Write ε=ε_0≤1/2, K=exp(√n), s=1+√n, h=s/(εq_-), S=β+C_col. In this note ε denotes only the already frozen ε_0.

The proof treats n≥2; the original large-dimensional switching branch has n≥9. The remaining lower dimensions are handled by the existing direct center bound, not discarded.

For a fixed endpoint v and two sources y,z define

 Z_v(y)=∫c_w(y)1_{m_w<m_v/K}μ(dw),
 C_v(y,z)=∫c_w(y)c_w(z)1_{m_w<m_v/K}μ(dw),
 E_v(y,z)=[Z_v(y)−C_v(y,z)][Z_v(z)−C_v(y,z)].             (1)

E_v is the bilateral exclusive product, not the old external normalization E_uv. Assign each receiver w capturing y but not z to its **first** violated coordinate j, in a fixed order 1,…,n. Equivalently j is the least index with |z_j−w_j|>R_w/2. Define

 A_v,j(y,z)=∫1_{m_w<m_v/K}c_w(y)(1−c_w(z))
                    1_{first violated coordinate is j}μ(dw),
 D_v(y,z)=∑_(j=1)^n A_v,j(y,z)A_v,j(z,y).                (2)

This is a measurable disjoint partition of the actual exclusive receiver measure. It follows exactly that

 E_v=(∑_j A_v,j(y,z))(∑_k A_v,k(z,y)),  0≤D_v≤E_v.

Set

 ω_v(y,z)=1_{||y−z||_∞≤a/n}D_v(y,z)/E_v(y,z),             (3)

with value zero when E_v=0. This is in [0,1], fixed across the stages, and is the fraction of two exclusive witnesses whose first separation coordinate agrees. No w inherits original history or an original transition mark.

Insert ω_u into the actual remaining external bill H_ext^(1−φ), and ω_v into the actual remaining small-end bill H_small^(1−ψ). Denote their sum by P_face. For every L≥4,

 P_face≤d_face X_q,
 d_face=4ε²[β/(2L)+C_col/((2−ε)(L−ε))]
                         ≤S/L.                         (4)

This is a new price for an actual positive fractional component of R_400, valid for arbitrary full f. It does not require ω to have a positive uniform mean. The exact surviving complement is

 R_402=H_ext^[(1−φ)(1−ω_u)]
                   +H_small^[(1−ψ)(1−ω_v)],
 R_400=P_face+R_402.                                    (5)

Every old source, target, spatial and rank factor, as well as b_i and the stage restriction, stays in each term. The complement includes all far source pairs ||y−z||_∞>a/n and the cross-coordinate witness part of every near pair.

## 2. A native one-face capacity with arbitrary selected radii

The geometric fact paying (4) is the following. Fix y,z with |y_j−z_j|=d≤a/n, n≥2. Then

 ∫_E c_w(y)1_{z fails capture in coordinate j}μ(dw)
                                      ≤2/q_-.          (6)

The left side may further carry any positive restriction, such as the strict far mass gate or the first-coordinate assignment. The face direction is determined by the sign of z_j−y_j; no extra factor for two signs is needed for a fixed pair.

If d=0 the left side is zero. Otherwise translate y to zero and reflect the j-coordinate so z_j=d>0. A receiver contributing to (6) has

 |w_j|≤R_w/2,  w_j+R_w/2<d,  R_w≥a.

Since d≤a/2, w_j<0. Put t=−2w_j. Then

 a−2d<t≤b,
 max(a,t)≤R_w≤min(b,t+2d),  R_w<t+2d,
 2||w_perp||_∞≤R_w.

Let B=max(a,t), U=min(b,t+2d); over the enlarged interval t∈[a−2d,b], U≥B. With ρ=2||w_perp||_∞ and m_w≥q_-R_w^n, the actual density is bounded by

 1/[q_-max(a,t,ρ)^n],  with ρ≤U.

The (n−1)-dimensional center volume below ρ is ρ^(n−1). Thus its transverse integral is exactly

 ∫_0^U d(ρ^(n−1))/max(B,ρ)^n
 =1/B+(n−1)(1/B−1/U)
 ≤1/B+2(n−1)d/B².                                      (7)

The remaining real coordinate measure is dt/2. Integrating gives

 left side of (6)
 ≤(1/(2q_-))[log(b/a)+2d/a
       +2(n−1)d(2d/a²+1/a−1/b)]
 ≤(1/(2q_-))[log2+2x+2(n−1)x(1+2x)],  x=d/a≤1/n.

The bracket is increasing in x, and at x=1/n is

 log2+2+4/n−4/n²≤log2+3<4,

for n≥2. This proves (6). Endpoint strictness only enlarges the envelope in this proof; selector fields may place y on faces on sets of positive center measure. No step assumes a fixed selected radius, a thin source mass, or small f near a boundary.

In particular this estimate remains bounded as d decreases, rather than incorrectly asserting an O(d) capacity for an arbitrary radius field. The transverse maximum in (7) is what keeps the variable-radius proof valid.

## 3. One shared coordinate costs n, with complete receiver reuse retained

For a near pair, each term A_v,j in (2), in either direction, is bounded by 2/q_- by (6). Hence, pointwise for every actual v,

 1_near D_v(y,z)≤4n/q_-².

Consequently the genuine simultaneous moment has the unconditional price

 J_diag:=∫σ(dv)E_(π_v⊗π_v)[1_near D_v(y,z)]
                              ≤4nX_q/q_-².             (8)

This does not pay the entire bilateral moment: the latter has n² coordinate pairs, whereas (8) pays only its same-coordinate part. The first-coordinate assignment makes the decomposition exact and prevents overlap counting. The two exclusive witnesses are integrated over the actual field before (8); there is no price per stage, no receiver count, and no private source partition.

For E_v>0, (3) also gives the exact identity E_vω_v=1_near D_v. At E_v=0 both sides vanish. The geometry therefore controls a fraction of the existing bilateral cost, not merely an unrelated auxiliary moment.

## 4. Transfer to the actual original marked remainder

Use the R401 soft-complement inequality without deleting either rank hypothesis. At the external end, the original source has Z_u(y)≥T_v(y)>2h, while the new source has Z_u(z)>Lh. At the small end the complete mass-window bound gives

 Z_v(y)>(2−ε)h,  Z_v(z)>(L−ε)h.

For c=C/h<1, and A+B≤AB,

 (A−c)(B−c)≥AB(1−c).

Take (A,B)=(2,L) or (2−ε,L−ε), respectively; L≥4 and ε≤1/2 suffice. For c≥1 the actual soft complement is zero. Thus on their original rank supports,

 (1−φ_u)ω_u≤1_near D_u/(2Lh²),
 (1−ψ_v)ω_v≤1_near D_v/[(2−ε)(L−ε)h²].                  (9)

Keep the exact old-source expansions

 dΓ_i(y,u,v)=σ(du)π_u(dy)ℓ_i(u,y,dv),  ℓ_i(u,y,E)≤β,
 ∫dΓ_i(y,u,v)du=σ(dv)π_v(dy)k_i(v,y), k_i(v,y)≤C_col.

Both sourcewise bounds are the already verified original bounds, not bounds transferred to the new z or the witnesses. Insert (9) in the actual marked bills, take their proved positive upper bounds using ℓ_i and k_i, and sum the actual b_i(z) at the same source first. Since ∑_i b_i(z)≤1, (8) yields

 P_face≤[β/(2L)+C_col/((2−ε)(L−ε))]J_diag/h²
 ≤4ε²[n/(1+√n)²]
             [β/(2L)+C_col/((2−ε)(L−ε))]X_q.

Dropping n/(1+√n)²≤1 proves (4). Moreover β/(2L)≤β/L and
(2−ε)(L−ε)≥L for L≥4, ε≤1/2; together with 4ε²≤1 this gives d_face≤S/L.

This argument prices an actual component before eliminating the parent receiver. It does not need to pay the stronger all-receiver-pair relaxation from R401, and it makes no claim that the latter has n-order total mass. The full F_n tool remains available for the unpaid complement; none of its decay is converted into a source-density assumption here.

The external E_uv/Z_u normalization is unchanged. For each fixed old triple (y,u,v), the additional factor (1−φ_u(y,z))ω_u(y,z), or its complementary factor, may be inserted in the exact conditional identity

 π_u[b_i(1−c_v)1_{Z_u>Lh}g(y,·)]
 =E_uv∫b_i(z)g(y,z)1_{Z_u(z)>Lh}ν_uv^z(dz)/Z_u(z).

The old y remains conditioned throughout. The proof above estimates the actual posterior expression directly; it never sets E_uv/Z_u to one, changes the source law for free, or uses the old BH negative square again.

## 5. Parameters, complete complement and ledger

For any fixed L≥4, (4) has its displayed exact coefficient and (5) is an exact nonnegative split. To make the new fee ≤δX_q, it suffices to select L≥max{4,S/δ}. If a previous comparison fixed a smaller L, this choice must be made in the complete R398 mother split: the new P_L replaces the previous low-rank receipt, with all intermediate rank bands accounted for there. It is not a free change of an already fixed cutoff and the two P_L charges are not added. None of f, γ_i, b_i, χ, the original ranks or h changes.

Let ζ_n=2(λ/q_-)Sε/[K(1+√n)] be the combined R399–400 coefficient. For n≥9 the resulting core slot is

 G_0≤16R_402+16(ζ_n+d_face)X_q+16(s+P_L)W,
 P_L=λh[β(L+ε)+C_col L].                                (10)

Hence

 BH≤32R_402+[E387+32(ζ_n+d_face)]X_q
                   +[S390+40s+32P_L]W,                 (11)

and the original entrance is

 Λ{8λHW+2d_eff A_nW_ν/H+64R_402
       +[2E387+64(ζ_n+d_face)]X_q
       +[2S390+80s+64P_L]W}.                            (12)

Only d_face is new relative to R400; ζ_n is retained once. If a total new coefficient δ is desired for these two fractions together, choose L≥max{4,2S/δ} and use the R400 dimension threshold N_(δ/2), so that for n>N_(δ/2), d_face≤δ/2 and ζ_n≤δ/2. The entire lower-dimensional complement is still paid directly by

 G_0≤S[1+N_(δ/2)log2]W/2.

That direct core bound replaces the switching route on those dimensions. Global admissibility also requires the available original entrance balance to cover 64Λδ; it is not asserted merely by choosing δ symbolically.

On the remaining R_402, the R400 low-common-capture conditions and all original high-rank gates remain. Its new factor 1−ω equals one on far source pairs. On near pairs it is exactly the fraction of exclusive witness pairs whose first separation coordinates differ, with the zero-product convention already specified. No fixed fraction of traffic is asserted to fall into the paid part. The general budget for this full complement is still open.

## 6. Actual local verification

Executed on the local machine:

    python3 /tmp/r402_geometry_check.py
    PASS {'face_bound': 32, 'native_face_model': 54,
          'witness_split': 96, 'price': 144} total 326

All arithmetic is Fraction. The face-bound checks include the near cutoff d=a/n and certify log2<7/10 using a positive atanh series with a rational tail. The native varying-radius tests use y=0, z=(d,0,…), a=1,b=2, centers with t=−2w_1∈[1,3/2], selected R=t+d/2 and transverse center box of side R. A bounded source f=q on a sufficiently large finite box gives exact matching m=qR^n. The actual face capacity is

 [1/(2q)]log[(3/2+d/2)/(1+d/2)],

certified by rational upper/lower logarithm series. It is positive as d decreases and tests the variable-selector issue that invalidates a naive fixed-radius thin-strip argument. It is not an example of all original core/history gates.

The remaining checks verify the exact diagonal/cross-coordinate partition, the ratio zero convention, the soft-complement inequality and the coefficients in (4). Their finite witness arrays are algebraic checks, not a claim that every such array is a native full core. The general theorem is the analytic receiver-center proof (6)–(9).

Status: a complete explicitly defined positive fraction of the actual R400 cost is now paid by (4), with its full complement and entrance price retained. No further route is developed after this result.
