from fractions import Fraction as F
from itertools import product

counts={'face_bound':0,'native_face_model':0,'witness_split':0,'price':0}
# A rational certificate log 2 < 7/10: atanh series with geometric tail.
x=F(1,3)
partial=2*sum(x**(2*k+1)/F(2*k+1) for k in range(8))
tail=2*x**17/(17*(1-x*x))
assert partial+tail<F(7,10)
for n in [2,3,4,8,16,32,64,128]:
    for frac in [F(0),F(1,8),F(1,2),F(1)]:
        d=frac/n
        bracket=F(7,10)+2*d+2*(n-1)*d*(1+2*d)
        assert bracket<4
        assert bracket/2<2
        counts['face_bound']+=1

# Native varying-selector n-dimensional face field.
# y=0, z=(d,0,...), a=1,b=2, t=-2w_1 in[1,3/2],
# selected R=t+d/2, other centers in [-R/2,R/2]^(n-1).
# R>=t captures y, R<t+2d excludes z, and R stays in the octave.
# f=q on a large finite box gives exact matching m=q R^n.
# Its face capacity is (1/(2q))*log((3/2+d/2)/(1+d/2)).
# Certify this by rational upper/lower atanh series, no floating-point logs.
def log_interval(r,terms=18):
    u=(r-1)/(r+1)
    assert 0<=u<1
    lo=2*sum(u**(2*k+1)/F(2*k+1) for k in range(terms))
    hi=lo+2*u**(2*terms+1)/(F(2*terms+1)*(1-u*u))
    return lo,hi
for n,q,dfrac in product([2,3,4,8,16,32],[F(3,4),F(1),F(2)],[F(1,4),F(1,2),F(1)]):
    d=dfrac/n
    Rlo=1+d/2
    Rhi=F(3,2)+d/2
    assert 1<=Rlo<=Rhi<=2
    lo,hi=log_interval(Rhi/Rlo)
    assert 0<lo/(2*q)<=hi/(2*q)<2/q
    # The source is captured and excluded along exactly the claimed direction.
    for t in [F(1),F(5,4),F(3,2)]:
        R=t+d/2
        assert R>=t and R<t+2*d
    counts['native_face_model']+=1

# Exact diagonal versus cross-coordinate decomposition and ratio zero case.
for n in [2,3,4,8]:
    for seed in range(1,25):
        left=[F((seed*(j+2)+j)%7,7) for j in range(n)]
        right=[F((seed*(j+5)+2*j)%7,7) for j in range(n)]
        E=sum(left)*sum(right)
        D=sum(a*b for a,b in zip(left,right))
        omega=D/E if E else F(0)
        assert 0<=omega<=1
        assert D+sum(left[j]*right[k] for j in range(n) for k in range(n) if j!=k)==E
        assert E*omega==D
        # One-face bounds normalized to q=2, so each capacity <=1.
        assert D<=n
        counts['witness_split']+=1
assert (F(0) if F(0)==0 else F(1))==0

for eps,L,beta,Ccol,c in product([F(1,8),F(1,4),F(1,2)],
                                [F(4),F(8),F(16)],
                                [F(1,2),F(3,4)],
                                [F(1),F(2)],
                                [F(0),F(1,2),F(999,1000),F(1)]):
    B=beta/(2*L)+Ccol/((2-eps)*(L-eps))
    assert B<=(beta+Ccol)/L
    assert 4*eps*eps*B<=(beta+Ccol)/L
    for a,b in [(F(2),L),(2-eps,L-eps)]:
        assert (a-c)*(b-c)>=a*b*(1-c)
    counts['price']+=1
print('PASS',counts,'total',sum(counts.values()))
print('native_scope: varying-radius continuous center field, matched bounded f; not original core/history')
