# R402 independent audit — FINAL PASS

FINAL PASS for the actual same-coordinate and ordered inner-witness positive receipts, the uniform-cut single-joint partition and complete parameter-dependent ledger. General closure and the actual source-collar remainder are not certified paid. Only this audit file was edited; author files and repository were not modified.

Only this file is edited. These derivations precede reading new R402 author proofs. The first screen concerns the collar/bin identity; the second screens the parent's later, more specific actual near-source diagonal payment. General closure is not certified.

## 1. Near-source inner-cube containment

Let ||y-z||infinity<=d and fix an actual receiver cube of side R, center w. Use closed cubes and define its inner cube to be empty when R<=2d. If y belongs to the inner cube of side R-2d, the triangle inequality implies z belongs to the outer R cube. Thus pointwise

    c_R(y)(1-c_R(z)) <= c_R(y)-c_(R-2d),empty(y).

For R<=2d the right side is just c_R(y), so the inequality remains valid. With another open/half-open convention, fixed-w boundaries are Lebesgue/source-null because f is L1; positive Tonelli removes their product-measure exceptions. This does not authorize dropping variable-selector boundaries pointwise at fixed y,z, where they can have positive receiver measure.

For any actual frozen strict mass set m_w<M, define B(y) by integrating that collar difference against mu(dw)=dw/m_w. Full matching gives the exact positive identity

    integral f(y)B(y)dy
      =integral_{m_w<M}[1-f(Q_inner,w)/m_w]dw.

It is actual lost source mass, not the collar volume divided by cube volume. No bound proportional to geometric thickness is available here for arbitrary f without an additional proved condition. This identity alone supplies no free root-order collar price.

## 2. Fixed-bin positive split

If r_j<=R_w<r_(j+1), nested actual cubes give

    c_R(y)(1-c_R(z))
      <=c_rj(y)(1-c_rj(z))+(c_R(y)-c_rj(y)).

Indeed c_R(z)>=c_rj(z), then expand c_R(y)=c_rj(y)+(c_R(y)-c_rj(y)) and discard the final positive factor 1-c_rj(z)<=1. The actual strict mass restriction can be retained on both parts. For the fixed first part, m_w>=q_-r_j^n and the center difference volume is exactly

    r_j^n-product_k(r_j-|y_k-z_k|)_+.

Hence its integrated mu capacity, summed over bins, is at most

    q_-^(-1) sum_j[1-product_k(1-|y_k-z_k|/r_j)_+].

This is an integrated actual-center bound, not an indicator inequality with a dimensionful q factor. Only this fixed part uses a fixed center-volume formula. The second part is the actual selected-radius collar and must retain its full-f charge. No sum over bins is presumed free.

## 3. Later single-coordinate separation capacity, independently derived

Now assume n>=2, a<=R_w<=b<=2a and ||y-z||infinity<=a/n. Fix a coordinate j where d_j=|y_j-z_j|>0 and orient it so z_j-y_j=d_j. A cube that captures y but misses z in this coordinate has

    t=-2(w_j-y_j), R_w>=a, R_w>=t,
    R_w<t+2d_j, t in (a-2d_j,b].

Since 2d_j<=a, this longitudinal t is nonnegative. Boundaries may be included for an upper envelope; the strict fail condition is still retained by the original event. Set B=max(a,t), U=min(b,t+2d_j). For each fixed t, actual transverse centers and their arbitrary selected radius obey B<=R_w<=U. The true (n-1)-dimensional radial center envelope gives

    integral_transverse c_w(y)/m_w dw'
      <=q_-^(-1)[1/B+(n-1)(1/B-1/U)].

To see this, with v=2||w'-y'||infinity, use density max(B,v)^(-n) supported on v<=U. The flat region contributes B^(n-1)/B^n=1/B; the rest contributes (n-1)integral_B^U v^(-2)dv. This bounds actual variable radii simultaneously; it never treats their selected values as independently integrated radii.

The longitudinal measure is dt/2. Write e=2d_j/a<=2/n and r=b/a<=2. Direct integration of the clipped reciprocals gives

    integral_(a-2d_j)^b dt/B = e+log r,
    integral_(a-2d_j)^b dt/U = log r+e/r.

Consequently the single specified-coordinate fail capacity is at most

    [log r+e+(n-1)e(1-1/r)]/(2q_-)
      <=[log2+1+1/n]/(2q_-) <2/q_-.

This is an evaluated envelope, not the actual selector integral. If d_j=0, the original fail event in that coordinate is empty and must be assigned zero; the relaxed closed envelope need not be zero in that case. Arbitrarily small positive d_j need not yield a small receiver-center capacity because the actual selector can hug a face boundary. There is no fixed-radius thin-volume shortcut.

Assign every actual exclusive receiver to its first failing coordinate. Each C_j(y,z) is a positive restriction of the above single-coordinate event, with any strict far-mass cutoff retained. Thus C_j(y,z)<=2/q_- for each j and

    D_diag(y,z)=sum_j C_j(y,z)C_j(z,y)<=4n/q_-^2.

Also D_diag<=E(y,z)E(z,y), where E denotes the full exclusive rank Z-C, since the product expands into all ordered coordinate pairs. These definitions use actual receiver occupations; no coordinate independence of f is asserted.

## 4. Genuine positive residual restriction and price

On the R400 low-common double-source residual at either endpoint A, use the actual mark

    rho_A(y,z)=1_{||y-z||infinity<=a/n}
                    D_diag,A(y,z)/[(Z_A(y)-C_A)(Z_A(z)-C_A)],

with zero when the denominator vanishes. It is in [0,1]. On the positive R400 residual the original individual rank bounds make the denominator positive anyway. The mark can depend on the old source y and new switching source z, so the original source-labeled lift must remain.

The already independently verified R401 scalar interface, before averaging away any original labels, gives

    (1-C_A/h)_+ rho_A
      <=1_near D_diag,A/(A0 B0 h^2),

where A0 B0=2L at the external large endpoint and (2-epsilon0)(L-epsilon0) at the small endpoint. Use the actual outgoing sourcewise beta bound and incoming sourcewise C_col bound separately, plus sum_i b_i(z)<=1. For L>=4 and 0<epsilon0<=1/2 the paid component of R400 is therefore at most

    [4n/(q_-^2h^2)]
     [beta/(2L)+C_col/((2-epsilon0)(L-epsilon0))] X_q
    <=4epsilon0^2[beta/(2L)+C_col/((2-epsilon0)(L-epsilon0))]X_q
    <=S X_q/L, S=beta+C_col.

No source fee is added by this marked estimate at the frozen parameters. The previously established P_L still carries its full L dependence; choosing L for an absorption target must keep that complete price and available global balance. R398's actual entrance multiplier on this R400 bill is 64Lambda, so a coarse displayed absorption S/L at this point costs 64Lambda S/L at the entrance, not S/L alone.

This is a real positive restriction of the actual switching remainder, not a uniform fraction or entire near-source payment. The complement includes near-source off-diagonal coordinate-pair contributions and all farther sources. It does not inherit spatial separation, a new receiver history, or a root budget. n=1 is outside this capacity argument and requires an explicit previous whole-core alternative if an all-dimensional statement is claimed.

## Actual bounded local calculations

Reviewer executed 1548 Fraction/Boolean checks for the first screen: 378 closed-boundary collar inclusions, 1134 fixed-bin splits and 36 exact fixed-center difference-volume identities. These are finite geometry/algebra checks, not native synchronized core examples. Reviewer then executed 264 Fraction coefficient/soft-interface checks for the later capacity estimate. The logarithmic inequality log2<1 was used analytically; no floating-point evaluation certified the general bound. No separate reviewer test files were saved, and these counts are not pooled with future author/parent experiments.

Independent statement screens PASS. The final frozen author and main-report review below completes this bounded audit.


## Final author geometry review

Read the complete frozen r402_geometry.md and its standalone script. Its actual selected-radius face estimate agrees with the independent derivation. The transverse integral (7) is the integral of a simultaneous pointwise envelope over actual center coordinates. It does not integrate independently selected radii, and a fixed source pair has only one possible face direction in a specified failing coordinate. First-failing-coordinate restrictions can only reduce that capacity.

The final endpoint text correctly allows R_w=b: max(a,t)<=R_w<=min(b,t+2d), with R_w<t+2d separately. The earlier strict minimum would have incorrectly excluded legitimate top-radius receivers; this is now corrected without a numerical or mathematical change to the closed envelope. The d_j=0 case is correctly set to the empty actual fail event. The one-face bound 2/q_- and same-coordinate bilateral bound 4n/q_-^2 hold for n>=2, while n=1 belongs to the previously available direct whole-core alternative.

The sharper exact face-envelope integral in the parent main is also analytically valid. For e=2d_j/a and r=b/a, the two clipped reciprocal integrals are e+log r and log r+e/r; consequently its value is [log r+e+(n-1)e(1-1/r)]/(2q_-). This gives the stated capacity, independently of MATLAB. Neither this exact envelope value nor its d->0 limit is asserted to equal the actual selected-field capacity.

The diagonal selector is a fraction of the actual independent conditional exclusive witness product, since D_diag<=E_y E_z and their zero-product conventions agree. Retaining the R401 soft complement, sourcewise beta/C_col and the same global source-stage sum produces exactly d_face as displayed; no extra lambda/q factor is missing. The external old-y lift and its E_uv/Z_u factor remain intact. The face-only intermediate residual named in the geometry attachment is not identified with the later final joint residual in main.

## Final collar/bin and actual same-joint review

Read the final r402_aux.md, including its corrections. Its source-collar identity now explicitly uses a fixed d independent of the integrated source variable; the earlier pointwise choice d=||y-z|| must not be substituted into that identity as if it specified one fixed inner cube. The current containment, positive Tonelli identity and retained strict mass gate are correct. Its radius bins cover the octave including b and the b=a single-bin case. The lower selected-radius estimate m_w>=q_- r(w)^n is valid; no lower quality bound for the artificial inner cube is assumed.

For exp-spaced bins, the geometric series includes all bins. With theta=1/sqrt(n) and d0=zeta a/n, the fixed inner exclusive occupation is at most zeta(1+sqrt(n))/q_-. The actual complementary collar has only its full-f lost-mass identity; it has not been paid by its geometric volume. The pointwise variable-radius screening example is a legitimate warning about fixed-source envelopes, not a lower bound for the source-integrated core.

The final auxiliary proof is correctly restricted to the original H_small remainder and proves its beta coefficient, not the later parent two-endpoint extension. Its Q_y and Q_z are explicit full-f conditional exclusive probability kernels on the live support. Same-diagonal, off-diagonal old-inner, off-diagonal old-collar/new-inner, and off-diagonal double-collar are tested on ONE such product lift. Only after dropping the off-diagonal restriction for an upper bound is the full inner-union probability written as p_y+p_z-p_y p_z. The off-diagonal law itself is not asserted independent. Thus the corrected version does not first average a diagonal mark and then silently resample witnesses while claiming the same final geometric pair.

The parent main makes the uniform-cut choice explicit: it only pays diagonal at distance<=d0, a positive restriction of the proved a/n branch. Therefore distance>d0 is retained in full and the near four-way joint partition is exact. No already-paid diagonal interval (d0,a/n] is simultaneously called unmodified far remainder. The auxiliary can be used with precisely this restricted diagonal selector.

## Parent two-endpoint extension and exact fees

Read the final main and readme. Their extension from the auxiliary small-end statement to the external endpoint is independently valid: at the large endpoint E_y>h and E_z>(L-1)h, stronger than the same uniform lower bounds (1-epsilon0)h and (L-1-epsilon0)h used at the small endpoint. At each old labeled external triple keep its old v, external exclusion, clock and any normalized E_uv/Z_u representation. The additional conditional exclusive witnesses do not replace any of those labels.

For L>=4, epsilon0<=1/2 and zeta<=1, eta_y=zeta epsilon0/(1-epsilon0) and eta_z=zeta epsilon0/(L-1-epsilon0) both belong to [0,1]. On either endpoint the actual inner-union probability is bounded by eta_y+eta_z-eta_y eta_z after dropping only its positive different-coordinate restriction. Summing the source-stage marks once gives R400<=2G0<=2beta Xq. Hence the parent's conservative two-endpoint charge

    alpha_bin=2beta(eta_y+eta_z-eta_y eta_z)<=4beta zeta

is valid. This parent proof is separate from the auxiliary beta bound; the two prices are not added. A surviving off-diagonal conditional measure is never renormalized and charged as if its normalizing constant were one.

Thus on the same explicit joint lift,

    R400=P_diag+P_inner+R402_joint,
    Delta=d_face+alpha_bin<=S/L+4beta zeta.

The complete final residual consists of the far original marked traffic and near tags with different first separation coordinates and both actual radius-bin collar events. Its genuine E_y E_z denominators, old source, current receiver, stage and history marks remain. This is a positive fractional decomposition of the actual switching bill, not a paid uniform fraction or automatically a subflow of gamma0.

The choices L>=max(4,2S/delta) and 0<zeta<=min(1,delta/(8beta)) give Delta<=delta for the original beta>0 contract. L must be chosen in the complete R398 mother split, replacing its previous low-rank threshold and complete P_L price rather than retuning it for free or adding two inconsistent low-rank receipts. f,m,q,J,h, original ranks and stages stay fixed.

The final main names the joint remainder R402_joint, distinguishing it from the face-only intermediate attachment. Its core, BH and entrance formulae have the correct factors 16,32,64. The pre-existing zeta_n coefficient is retained once, and only Delta is new; original entrance absorption is 64Lambda Delta. The available global absorption balance is not presumed. All P_L dependencies and original outer fees remain. Low dimensions use the prior direct whole-core alternative without stacking the high-dimensional replacement. No source-collar or general remainder budget is inferred.

## Actual reviewer executions and evidence boundary

Reviewer read and ran the geometry script to exit 0:

    PASS face_bound32 + native_face_model54 + witness_split96 + price144 =326.

All arithmetic is Fraction, with rational logarithm enclosures. The native varying-radius model has full matching f=q on a sufficiently large compact box and genuine transverse center integration, but no complete original high-rank/core history. Its log expression is positive for d>0 and need not vanish as d decreases; d=0 is a different actual fail event. The finite witness arrays and coefficient cases check algebra, not realizability of every original historical field.

Reviewer read and ran the FINAL auxiliary script to exit 0:

    PASS inner_shell1950 + fixed_bin_split1950 + strict_cut72
         +ordered_two_inner243 +same_joint_diagonal45 =4260.

The earlier 4215 version is superseded, not added to this total. The new 45 checks explicitly verify the single same-joint partition for diagonal, anti-diagonal, fractional and zero/full selectors. These are finite set/algebra tests, not a native high-history certificate or a test of source-collar mass smallness. The final two scripts therefore contain 4586 grouped Fraction checks; parent/reviewer reruns are not additional independent experiments. The preliminary 1548 and 264 reviewer checks described above are separate and are not pooled into that count.

The MATLAB script and saved result were read but not independently rerun by this reviewer. The parent record contains 63 ordinary-double varying-radius envelope quadratures, maximum absolute error 5.0515147620444623e-15. This is a numerical diagnostic of the exact face-envelope formula, not an interval certificate or original-core realization. The analytic proof and rational checks provide the stated mathematical support. The final reporting correctly separates these evidence types.

The corrected fixed-d condition, allowed top-radius endpoint and same-joint labeling are all reflected in the frozen proof/report scope. No further modification is required. General n^(1/2+o(1)) closure remains unproved.

## Final frozen byte bindings

SHA-256 binds the exact reviewed final files. Any later change requires an updated audit.

- `/tmp/r402_main.md`: `f9a996b77ef3cac5f71f1dc6260e50b031dd8e52c8c16e0af3423c2bc63ec93f`
- `/tmp/r402_readme.md`: `c63a1edaa853fb7a55ed7af6ecaaeeb887b22ebc094fab5cfbcef88ff17d3d22`
- `/tmp/r402_geometry.md`: `586017741954884bbf6b7f76b476cc6a6f4994223567bb3353e1723ce790c2ef`
- `/tmp/r402_geometry_check.py`: `b47d75bf5b7fe3dc8c2e09d2d67a8e21dfa8da785237c0a1bd2395ba9c2689bc`
- `/tmp/r402_geometry.result.txt`: `b97e1232738c9bdfec2f81d37fe7aa719e37b9b23a2baedde141fd6a5ef26b54`
- `/tmp/r402_aux.md`: `ef954b86d51c482791fcee0d976fba8411aab0d452a6418da986bccf1a646ba3`
- `/tmp/r402_aux_check.py`: `1f6adc0ca68086a1f3b9096024a31975c675a70617852d8d592bfdb134b8b2ef`
- `/tmp/r402_aux.result.txt`: `f72600f7aa0a941522f3dc09796c6cd7cf8c6321a43d8ab3995b9a7278953ff2`
- `/tmp/r402_face_check.m`: `41b4c30b83ee991a55e2e9e1612263c40ecd92820ec4a1cd276042e5dad23d75`
- `/tmp/r402_face.result.txt`: `1730d2d4ecc138cd020576186467650f7565f1c54e82025d4c399ae9e1cda7fd`


FINAL PASS within the bounded actual positive-payment and reporting scope above. The complete far/double-collar residual and global absorption remain open. Freeze this audit and stop; no further search or duplicate numerical pipeline was undertaken.
