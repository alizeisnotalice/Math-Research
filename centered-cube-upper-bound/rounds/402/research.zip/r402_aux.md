# R402 — near-source exclusive occupation with the actual boundary cost retained

**Outcome.** There is an exact near-source reduction to the full-f mass of actual inner collars. Radius bins further separate an explicit small fixed-radius center term. The collar cost has no proved root-order budget under the present contract. The marked inner-capture part of the near branch does have the explicit absorption price in §4. The full near/far residual remains unclosed; the collar is retained exactly.

## 1. Actual field and a safe containment

Let f≥0 belong to L1, m_w=f(Q_{R_w}(w))=q_wR_w^n, q_-≤q_w≤λ, a≤R_w≤b≤2a, and μ(dw)=dw/m_w. For a strict actual mass cutoff M>0 put

E_M(y,z)=∫_E c_w(y)(1−c_w(z))1_{m_w<M} μ(dw).

Fix d≥0 independently of all source integration variables, and suppose ||y−z||∞≤d. Interpret cubes of nonpositive side as empty. The triangle inequality, separately for EVERY actual selected radius, gives

c_w(y)(1−c_w(z))
 ≤c_{R_w,w}(y)−c_{(R_w−2d)_+,w}(y).                     (1)

Indeed capture in the inner cube forces capture of z in the actual outer cube. No conclusion about a larger cube is inferred from noncapture. Define B_{M,d}(y) by integrating the right side of (1) against 1_{m_w<M}μ(dw). Then

E_M(y,z)≤B_{M,d}(y),
∫f(y)B_{M,d}(y)dy
 =∫_{E∩{m_w<M}} [1−f(Q_{(R_w−2d)_+}(w))/m_w]dw.         (2)

The source integral identity in (2) holds for this FIXED d. If a width is instead chosen as a function of the integrated source y, that identity may not be written using the mass of one fixed inner cube. For fixed d, (2) is the complete matching statement. It is a receiver-volume integral of the ACTUAL posterior collar fraction, not a collar-volume estimate for f. It retains the strict cutoff and all original receiver selection. At d=0 both sides of (1) vanish. For 2d≥R_w the bound simply retains the full cube mass.

## 2. Radius-bin decomposition with all parameters explicit

Choose θ>0 and, for b>a, N=ceil(log(b/a)/θ), r_j=a exp(jθ), j=0,...,N−1. Partition the actual receivers into these radius bins, using upper endpoints min(r_{j+1},b), with b included only in the last bin. If b=a use one bin with r_0=a. Let r(w) be its bin's lower radius. Every receiver still has its original R_w,m_w,q_w.

For each actual w,

c_{R_w,w}(y)(1−c_{R_w,w}(z))
 ≤c_{r(w),w}(y)(1−c_{r(w),w}(z))
    +c_{R_w,w}(y)−c_{r(w),w}(y).                         (3)

The first term uses the valid implication noncapture at R_w implies noncapture at r(w)≤R_w. Put

B_bin,M(y)=∫_{E∩{m_w<M}}
             [c_{R_w,w}(y)−c_{r(w),w}(y)]dw/m_w.

Since m_w≥q_-r_j^n on bin j, enlarging ONLY the positive fixed-radius center integral to all real centers gives

E_M(y,z)≤B_bin,M(y)+C_bin(y−z),                           (4)
C_bin(t)=q_-^{-1}Σ_{j:q_-r_j^n<M}
             [1−∏_{i=1}^n(1−|t_i|/r_j)_+].             (5)

The product is the exact normalized overlap volume of two fixed-side r_j center cubes. A bin with q_-r_j^n≥M contains no live receiver under the strict cutoff, so no threshold-equality exception is omitted. No independence assumption about f is involved.

Consequently, for ||t||∞≤d,

C_bin(t)≤q_-^{-1}Σ_{j:q_-r_j^n<M}min(1,nd/r_j)
 ≤ min{N, (nd/a)/(1−e^{−θ})}/q_-.                        (6)

For θ=1/√n, 1/(1−e^{−θ})≤1+√n. Thus d≤a/n gives the explicit fixed-radius part

C_bin(t)≤(1+√n)/q_-.                                    (7)

This is an upper bound for one part of (4), not a bound for E_M. Its exact complementary source price is

∫f B_bin,M
 =∫_{E∩{m_w<M}} [1−f(Q_{r(w)}(w))/m_w]dw.               (8)

The discarded inner mass is measured using the same full f. It may not be replaced by q_w r(w)^n, since the q-band contract is given only at R_w. Equations (2) and (8) are alternative decompositions, not two fees to add. Either can be carried under further positive original marks; any integration over another source or receiver must retain its actual weights.

## 3. Why a uniformly small pointwise near-source bound is unavailable

The obstruction is compatible with FULL matching, not just its lower inequality. For a single screening example let f be 1 on a sufficiently large cube containing all cubes below, and zero outside it; set λ=q_-=q_w=1 for this example. For centers w with a<2||w||∞<b whose unique largest absolute coordinate is negative, choose R_w=2||w||∞. Let y=0 and z=(d,...,d), any d>0. Then y is captured and z is not, m_w=R_w^n, and for M>b^n all these centers are live. Half of every center cube shell has the specified face sign. Therefore their actual exclusive occupation is

(n/2)log(b/a),                                           (9)

independently of d>0. If the original q_- is fixed to 3λ/4, the same q_w=λ=1 field also satisfies that band. A fixed source on the cube face is intentional here: this tests a pointwise center-envelope assertion. It does NOT imply that the source-integrated original remainder is large, and does not preclude a source-averaged geometric improvement.

Thus a bound vanishing with d cannot follow from full matching alone at every source pair. The valid constructive substitute is (4): small fixed-radius center cost plus actual source-collar cost. The finite-bin sum in (6) has no hidden n² fee, but the remaining full-source collar integral in (8) is currently bounded only by |E∩{m<M}|. This is a receiver-scale price, not a root W price. Applying it to the original marked near-source residual without an additional joint estimate would not close that residual. This excludes paying the WHOLE near branch by (6). The narrower marked inner-capture receipt below remains valid, with the collar retained.

## 4. One actual joint partition: diagonal first, then the two inner tags

Apply this geometry only to the original R400 HIGH-SMALL remainder, not automatically to H_ext. Retain its complete original integrand

A_i(v,y,z)=k_i(v,y)b_i(z)1_{T_v(z)>Lh}(1−ψ_v(y,z)).

An additional frozen mark Ω(v,y,z)∈[0,1] may be retained throughout. It must not stand for a diagonal tag already averaged out if the final remainder is to refer to the SAME tags. Let H^Ω=Σ_i∫σπ_vπ_v ΩA_i. Then H^Ω≤H_small≤G0≤βX_q.

On the live support, let E_y=E_v(y,z), E_z=E_v(z,y), with the same strict mass cutoff M=m_v/K. For L>1+ε0,

E_y>(1−ε0)h,  E_z>(L−1−ε0)h.                            (10)

These follow from the original two rank conditions and C_v(y,z)<h, with the native closed-window loss ε0h. No old history qualification is transferred to either new tag.

Define actual conditional exclusive kernels

Q_y(dw)=1_{m_w<m_v/K}c_w(y)(1−c_w(z))μ(dw)/E_y,
Q_z(dt)=1_{m_t<m_v/K}c_t(z)(1−c_t(y))μ(dt)/E_z.

Both are probability kernels on the live support. Lift the original ΩA_i by the conditional PRODUCT Q_y⊗Q_z. This is an explicit auxiliary joint measure, not an assertion that original sources or receiver events are independent. Its marginal is exactly the original integral. It is the same product lift on which the diagonal receipt is to be evaluated.

For its actual tags set I_y(w)=c_{r(w),w}(y) and I_z(t)=c_{r(t),t}(z). On the exclusive supports these distinguish inner capture from actual collar capture. Let δ_diag(v,y,z,w,t)∈[0,1] be the already proved diagonal selector on this SAME lift, including any first-separating-coordinate conventions. Its old-variable marginal is ρ_diag=∫δ_diag dQ_y dQ_z. A scalar 1−ρ_diag must not be substituted before independently resampling the two tags when identifying the final geometric complement.

For ||y−z||∞≤d0, partition this one lifted measure by

δ_diag,
(1−δ_diag) I_y,
(1−δ_diag)(1−I_y) I_z,
(1−δ_diag)(1−I_y)(1−I_z).

The four factors sum to one pointwise. Outside the near set retain the original far part. Denote their integrals by H_diag^Ω,H_off,yin^Ω,H_off,zin^Ω,H_off,doublecol^Ω, respectively. Then

H^Ω=H_far^Ω+H_diag^Ω+H_off,yin^Ω
                    +H_off,zin^Ω+H_off,doublecol^Ω.       (11)

This is a SINGLE joint partition: the remaining two tags are simultaneously off-diagonal and in their actual collars. Every original source, stage, clock and history mark stays attached. The diagonal fee is charged separately by its established theorem; it is not charged again here.

The marginal inner probabilities are

p_y=∫I_y dQ_y=E_y,in/E_y,
p_z=∫I_z dQ_z=E_z,in/E_z,
E_y,in=∫1_{m_w<m_v/K}c_{r(w),w}(y)(1−c_w(z))μ(dw),

with E_z,in defined by interchange. By (5)–(6), on the near set both inner occupations are at most

C_*=q_-^{-1}min{N,(nd0/a)/(1−e^{−θ})}.

Define

η_y=min{1,C_*/[(1−ε0)h]},
η_z=min{1,C_*/[(L−1−ε0)h]},
η_tot=η_y+η_z−η_yη_z.

Thus p_y≤η_y and p_z≤η_z. On the actual joint measure,

(1−δ_diag)[I_y+(1−I_y)I_z]≤I_y+(1−I_y)I_z.

Only AFTER dropping the positive off-diagonal restriction do we use the product lift to integrate the right side as p_y+p_z−p_yp_z. Therefore

H_off,yin^Ω+H_off,zin^Ω≤η_tot H_near^Ω
                         ≤βη_tot X_q.                  (12)

The off-diagonal integral itself need not factorize. The estimate does not double-charge diagonal traffic: the priced submeasure on the left excludes it, even though its upper bound uses the full inner union. A weaker β(η_y+η_z)X_q is also valid. These are alternative upper bounds, not fees to add.

With θ=1/√n and d0=ζa/n, 0<ζ≤1,

η_y≤min{1,ζε0/(1−ε0)},
η_z≤min{1,ζε0/(L−1−ε0)}.                                (13)

The bin count is N=max{1,ceil(√n log(b/a))}; the geometric sum in (6), not an omitted bin fee, proves (13). A smaller ζ changes the far complement as well as the price. No fixed fraction of the original remainder is asserted to be paid. If L≤1+ε0, only the one-sided old-source split is asserted; the two-kernel construction above is not invoked.

In the R399 large-dimensional ledger, once the distinct diagonal fee is accounted for on this same lift, replace its remaining Hsmall term by H_far^Ω+H_off,doublecol^Ω and add 32βη_tot X_q in BH, or 64Λβη_tot X_q at the original entrance. For the full original Hsmall slot take Ω=1; if Ω is another restriction, its complementary original marked traffic must also be retained. All diagonal fees, the prior R399 η_n fee, H_ext and other inherited terms stay. An allotted NEW entrance absorption δ requires 64Λβη_tot≤δ; no allotment is presumed. There is no new W fee. The low-dimensional direct core bound remains an alternative, not a second charge.

This proof concerns the displayed Hsmall bill, whose total is at most G0. It does not assert the same price for every switching component merely from a 2G0 upper bound. The final H_off,doublecol^Ω keeps the SAME w,t, their original E_y,E_z denominators and the diagonal selector; (8) alone does not pay it. Together with the stated far and complementary original terms, this is the complete unpriced remainder.

## 5. Local exact checks

`/tmp/r402_aux_check.py` was actually run with Python Fraction arithmetic:

`PASS {'inner_shell': 1950, 'fixed_bin_split': 1950, 'strict_cut': 72, 'ordered_two_inner': 243, 'same_joint_diagonal': 45} total 4260`

The first two sets exhaust a finite 1D/2D coordinate grid, varying actual radius and source separation, and check the two exact pointwise containments (1),(3), including face equalities and empty inner cubes. The third checks the strict-cut implication under matching m=qR^n. The fourth checks the ordered two-inner positive partition and its combined bound under a frozen fractional mark ω, including endpoints 0 and 1. The final 45 checks use the same two-tag product measure with diagonal, anti-diagonal, full, empty and fractional diagonal selectors; they verify the single joint partition and the off-diagonal inner-union bound. These are finite algebra/set diagnostics, not native high-rank/core fixtures. The real-center integration and full-source identities are proved above. Work stops with the unpaid collar cost explicit.
