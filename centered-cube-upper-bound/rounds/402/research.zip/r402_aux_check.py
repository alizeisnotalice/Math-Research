from fractions import Fraction as F
from itertools import product
counts={'inner_shell':0,'fixed_bin_split':0,'strict_cut':0}
for n in (1,2):
    pts=list(product((F(-1),F(-1,2),F(0),F(1,2),F(1)), repeat=n))
    for y,z,R in product(pts,pts,(F(1),F(2),F(3))):
        d=max(abs(a-b) for a,b in zip(y,z))
        c=lambda x,r: int(r>0 and max(map(abs,x))<=r/2)
        cy,cz=c(y,R),c(z,R)
        assert cy*(1-cz)<=cy-c(y,R-2*d)
        counts['inner_shell']+=1
        r=R/2
        assert cy*(1-cz)<=c(y,r)*(1-c(z,r))+cy-c(y,r)
        counts['fixed_bin_split']+=1
for n,R,q,lo,M in product((1,2,3),(F(1),F(3,2),F(2)),(F(3,4),F(1)),(F(3,4),),(F(1),F(3,2),F(2),F(4))):
    m=q*R**n
    if m<M:
        assert lo*R**n<M
    counts['strict_cut']+=1
counts['ordered_two_inner']=0
for ey,ez,fy,fz,omega in product((F(1,2),F(3,4),F(1)),(F(1,3),F(2,3),F(1)),(F(0),F(1,2),F(1)),(F(0),F(1,2),F(1)),(F(0),F(1,2),F(1))):
    py,pz=ey*fy,ez*fz
    old=omega*py
    new=omega*(1-py)*pz
    residual=omega*(1-py)*(1-pz)
    assert old+new+residual==omega
    assert old+new<=omega*(ey+ez-ey*ez)
    counts['ordered_two_inner']+=1
counts['same_joint_diagonal']=0
patterns=[(F(0),F(0),F(0),F(0)),(F(1),F(0),F(0),F(1)),(F(0),F(1),F(1),F(0)),(F(1),F(1),F(1),F(1)),(F(1,2),F(1,3),F(2,3),F(1,4))]
for py,pz,diag in product((F(0),F(1,3),F(1)),(F(0),F(2,3),F(1)),patterns):
    pieces=[F(0)]*4
    for i,j in product((0,1),repeat=2):
        mass=(py if i else 1-py)*(pz if j else 1-pz)
        dd=diag[2*i+j]
        values=(dd,(1-dd)*i,(1-dd)*(1-i)*j,(1-dd)*(1-i)*(1-j))
        for k,x in enumerate(values): pieces[k]+=mass*x
    assert sum(pieces)==1
    assert pieces[1]+pieces[2]<=py+pz-py*pz
    counts['same_joint_diagonal']+=1
print('PASS',counts,'total',sum(counts.values()))
