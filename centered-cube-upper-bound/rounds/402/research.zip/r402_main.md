# 第402轮：近来源同坐标与内层见证的联合付款

日期2026-10-19。目标仍是一般中心立方体弱型根阶上界。本轮不再单独支付R401的更强全矩放松，而在原两端低共同捕获高秩余项上保留实际见证，证明两个不重叠的近来源分支具有可任意缩小的X_q费用。远来源和近来源不同坐标双collar仍完整未付。

## 冻结约定与本轮统一参数

继承R398–401的完整非负L1来源f、实际du、选定立方体Q_u、a≤R_u≤b≤2a、m_u=f(Q_u)=q_uR_u^n、q_-≤q_u≤λ、σ=qdu、μ=du/m、π_u=f c_u/m_u、X_q=σ(E)、W=∫f。全部原Γ_i/γ_i、时钟、来源、历史及stage b_i冻结，Σb_i≤1，γ_out≤βσ，G0≤βX_q。K=e^(√n)，s=1+√n，h=s/(ε_0q_-)，0<ε_0≤1/2。C_col为原逐来源列界，S=β+C_col。

本轮取L≥4，0<ζ≤1，d0=ζa/n，且证明近源分支时n≥2。L是R398母分拆的可选参数；若由旧L改为新L，必须完整替换P_L以及相应高/低rank分拆，不能免费重调或把两份P_L叠加。其余原场不变。半径bins采用r_j=a exp(j/√n)，最后一bin含b；b=a时只一个bin。

统一只在||y−z||∞≤d0支付diagonal，不预先支付较大a/n近域的diagonal。于是far始终指dist>d0的原余项，避免把(d0,a/n]已扣过的分量再次列入far。

## 第一项：同首分离坐标的真实正分量

对每个exclusive receiver w（捕获y但不捕获z，且m_w<m_endpoint/K），以固定坐标顺序选择首个不捕获z的坐标j。由单面实际center包络，near dist≤a/n时每个坐标的occupation A_j(y,z)≤2/q_-，n≥2。

这里必须允许R_w随中心变化。取该坐标的有向变量t，R_w的约束为max(a,t)≤R_w≤min(b,t+2d_j)，并另保R_w<t+2d_j。横向真实center包络积分为1/B+(n−1)(1/B−1/U)，B=max(a,t)，U=min(b,t+2d_j)，纵向测度dt/2。缩放a=1、r=b/a后，∫dt/B=e+log r，∫dt/U=log r+e/r；故其全积分恰给[log(b/a)+e+(n−1)e(1−a/b)]/(2q_-)，e=2d_j/a≤2/n，从而小于2/q_-。d_j=0实际该face为空；该解析包络的d→0极限不等于实际值。绝不假设固定R薄层，也不以source体积代替f质量。

因此同坐标双侧occupation之和D_diag=Σ_j A_j(y,z)A_j(z,y)≤4n/q_-²。沿用R401保软补集的双rank不等式，原两端余项中这个正分量满足

\[
P_{\rm diag}\le d_{\rm face}X_q,
\quad d_{\rm face}=4\varepsilon_0^2\left[\frac\beta{2L}
+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}\right]\le S/L.
\]

这里省略n/s²≤1只作上界。实际单一joint标签及严格mass门见r402_geometry.md；引用其a/n定理到更小d0是正限制，不产生额外费用。

## 第二项：同一对见证上的内层联合付款

对每个原端点A及两源y,z，令E_y=Z_A(y)−C_A(y,z)、E_z=Z_A(z)−C_A(y,z)。在原R400正余项上两者严格正。定义条件概率kernel

Q_y(dw)=1_{m_w<m_A/K}c_w(y)(1−c_w(z))μ(dw)/E_y，
Q_z(dt)=1_{m_t<m_A/K}c_t(z)(1−c_t(y))μ(dt)/E_z。

在每一原带来源/边/时钟/stage标记下，附加同一个Q_y⊗Q_z乘积标签。其边缘正是原费用；这是明确构造的见证law，不是假定f坐标独立。定义I_y(w)=1_{y∈Q_{r(w)}(w)}、I_z(t)=1_{z∈Q_{r(t)}(t)}。

在near域按同一对实际w,t依次分成：首分离坐标相同；不同坐标且I_y=1；不同坐标且I_y=0,I_z=1；不同坐标且I_y=I_z=0。四项逐点不交并覆盖。不能先把diagonal积分成scalar再重新采样标签，最后宣称同一对见证off-diagonal。

固定radius-bin center交叠体积给

\[
E_{y,\rm in},E_{z,\rm in}\le C_*\le
\frac{nd0/a}{q_-(1-e^{-1/\sqrt n})}
\le\frac{\zeta(1+\sqrt n)}{q_-}.
\]

bin计数是max(1,ceil(√n log(b/a)))，上述几何级数已包含全部bins。使用的是m_w≥q_-r(w)^n和固定内cube的center测度；未给内cube假设q下界，也未支付实际source collar。

在小端，原秩条件给E_y>(1−ε_0)h、E_z>(L−1−ε_0)h。父代理在此明确扩展到大端：原Z_u(y)>2h、Z_u(z)>Lh且C_u<h，故E_y>h、E_z>(L−1)h，也满足相同较弱下界。大端保原v、外部(1−c_v(z))以及E_uv/Z_u（若用ν表示），不把新w/t赋予原历史资格。因此两端均有

p_y=Q_y(I_y)≤η_y=ζε_0/(1−ε_0)，
p_z=Q_z(I_z)≤η_z=ζε_0/(L−1−ε_0)。

本参数范围使η_y,η_z∈[0,1]。不同坐标inner联合是无条件inner联合的正子集；只有在丢掉该正限制作上界后，才用同一乘积law得到p_y+p_z−p_yp_z≤η_y+η_z−η_yη_z。不会把已条件化off-diagonal law假定为独立。

原两端R400总量≤2G0≤2βX_q（嵌套γ_i和Σb_i≤1逐端证明），故本轮第二个真实分量满足

\[
P_{\rm inner}\le\alpha_{\rm bin}X_q,
\quad\alpha_{\rm bin}=2\beta(\eta_y+\eta_z-\eta_y\eta_z)
\le 2\beta\zeta\varepsilon_0\left[\frac1{1-\varepsilon_0}+
\frac1{L-1-\varepsilon_0}\right]\le4\beta\zeta.
\]

r402_aux.md只单独证明小端β系数；这里是父代理明确证明的两端扩展，付保守2β系数，不能把两者费用再相加。

## 精确补集与完整回代

本主文R402_joint表示最终联合余项；几何附件的R_402仅表示扣除同坐标分量后的中间余项，二者不混用。

R400=P_diag+P_inner+R402_joint。其中R402_joint是far原余项，加near同一对w,t首分离坐标不同且两来源分别处于其实际radius-bin collar的分量。保留真实E_yE_z分母及全部原标记。来源可以任意集中；没有任何已证小collar体积⇒小f质量结论。

因此新费用Δ=d_face+α_bin≤S/L+4βζ。若要求Δ≤δ，可取L≥max(4,2S/δ)、ζ≤min(1,δ/(8β))。这是可选正分量的吸收参数，不保证其占原余项的统一正比例；ζ缩小同时扩大far补集。

旧共同捕获系数ζ_n=2(λ/q_-)Sε_0/[K(1+√n)]（与距离参数ζ不同），P_L=λh[β(L+ε_0)+C_col L]，Λ=128/119。n≥9时有

\[
G_0\le16R_{402}^{\rm joint}+16(\zeta_n+\Delta)X_q+16(s+P_L)W,
\]
\[
B_H\le32R_{402}^{\rm joint}+[E_{387}+32(\zeta_n+\Delta)]X_q+[S_{390}+40s+32P_L]W,
\]
\[
\text{入口}\le\Lambda\{8\lambda HW+2d_{\rm eff}A_nW_\nu/H+64R_{402}^{\rm joint}
+[2E_{387}+64(\zeta_n+\Delta)]X_q+[2S_{390}+80s+64P_L]W\}.
\]

新增原入口费用是64ΛΔ。未证明全部旧吸收槽的总和已可吸收。对有限低维用旧直接核心界G0≤S(1+Nlog2)W/2替换整个槽，不叠加高维付款。若要同时使ζ_n和Δ小，可给二者分别预留预算，冻结维度一致常数后选择有限N；没有维度一致参数界时不声称N固定。P_L按当前L完整保留，其根阶表述还需保留既定ε_0^(-1)等参数的依赖。

全部未付还包括R402_joint、原H入口/选择、soft/crossing/entry、重尾/宽距离/低pe/极端尺度补集、初始与删除跳跃/未来删除、全尺度聚合及截断极限。未复用旧负信用。r400_main.md提供继承账定义，本轮只替换R400这一槽。

## 实际检查、修正与复现

父本机实际复跑r402_geometry_check.py 326项Fraction（32容量、54真实变半径center模型、96见证拆分、144费用），r402_aux_check.py 4260项Fraction（含45项同一joint-diagonal分拆）。有限参数不认证完整高秩历史，全类证明来自上述解析论证。

本机MATLAB实际运行r402_face_check.m，63组变半径face积分与闭式log表达比较通过，最大绝对误差5.0515147620444623e-15；n=2,3,4,8,16,64,256，b/a=1,1.25,2，e=(2/n)乘0.01,0.25,1。普通double积分，不是区间证书。

审查修正均已纳入：允许R=b的上端点必须用闭包络并单列严格R<t+2d；source collar积分公式中d必须固定；diagonal和inner须在同一joint标签分割，不能先平均后重采样；near统一d0，不重复把已付较大near域列入far。没有把这些修正计作一般证明已完成。

使用64项工具的G03检查其适用边界：它未提供本题方向捕获树定理；这里的first-coordinate容量及联合分割是本轮直接证明，不借未定义树接口。代码运行用本机数学工具；无实际逐模型扣额数据，不猜成本。

复现：python3 r402_geometry_check.py；python3 r402_aux_check.py；MATLAB run('r402_face_check.m')。归档含详细LaTeX源和必要材料，不编译PDF。一般n^(1/2+o(1))上界仍未闭合。
