# R686 iid uniform-center intersection/halo moment audit

## Decision and scope

Retaining the true nonempty original intersection greatly reduces the expanded-intersection moment, but the specified auxiliary raw moment still has a base of order k/2 in each coordinate. Thus a global moment bound obtained by keeping only a low parent field and nonempty intersection, while dropping original eligibility/history and the full receiver conditions, cannot get a dimension-independent bound for this relaxation.

This is an explicitly requested **auxiliary continuous iid model**, not an actual hard saturated history. It does not construct finite original owners, eligible strict cores, causal receiver masks or the original all-outside cost. In fact this model's parent field is at most one, so it has no high-threshold common-witness core of the required kind. Its large auxiliary moment is not a counterexample to the original target.

The earlier missing-input profile-cover interface remains in NUMERIC.py but was not optimized or supplied with a synthetic fixture. This explicitly requested iid task replaces that pending calculation.

## Independent derivation

In one coordinate, k≥2 iid centers are uniform on [−2,2]. Let R be their range. Choosing the minimum and maximum and placing the remaining k−2 points between them gives the range density

`f_k(t)=k(k−1)t^(k−2)(4−t)/4^k`, `0<t<4`.

The original radius-one intervals intersect exactly when R≤2. Conditional on that event, their intersection has length 2−R and its halo with h=1 has length 4−R. Hence the retained original-intersection halo expectation is exactly

`m_k=[k(k−1)/4^k] integral_0^2 t^(k−2)(4−t)^2 dt`.

SymPy integrates this formula for k=j+2,j≥0 and simplifies it to

`m_k=2^(1−k)(k²+3k+4)/(k+1)`

`    =2^(1−k)[k+2+2/(k+1)]`.

As a separate exact check, Fraction evaluates the three antiderivative terms

`[k(k−1)/4^k] [16·2^(k−1)/(k−1)−8·2^k/k+2^(k+1)/(k+1)]`

for each requested fixed k. Every value equals the closed form exactly.

If each interval is first expanded to radius two and then intersected without retaining the original R≤2 gate, the expected length instead is

`m_expanded=[k(k−1)/4^k] integral_0^4 t^(k−2)(4−t)^2 dt=8/(k+1)`.

That is a different operation and a much larger quantity. SymPy and Fraction verify it independently. Their exact ratio is

`m_k/m_expanded=2^(−k−2)(k²+3k+4)`.

## Exact fixed-k values

| k | original-intersection halo m_k | expanded-intersection expectation | (2^k m_k)/4 |
|---|---:|---:|---:|
| 2 | 7/3 | 8/3 | 7/3 |
| 4 | 4/5 | 8/5 | 16/5 |
| 8 | 23/288 | 8/9 | 46/9 |
| 16 | 77/139264 | 8/17 | 154/17 |
| 32 | 281/17716740096 | 8/33 | 562/33 |
| 64 | 1073/149879795598890106880 | 8/65 | 2146/65 |
| 128 | 4193/5487053166600132723346915544837262409728 | 8/129 | 8386/129 |

The original gate probability is `(k+1)/2^k` per coordinate. Its rarity removes the artificial expanded-intersection growth exponential in k, but the source multiplicity still leaves a factor of order k per coordinate.

## Product dimensions and source normalization

Coordinate independence gives

`E[halo volume with original-intersection gate]=m_k^n`.

The continuous source-weight density is `dq(y)=2^−n dy` on [−2,2]^n. Thus total source rate is 2^n. Each parent volume is 2^n, so the source-reference cost is

`U=integral (2^n)dq=4^n`.

The parent field is

`g(x)=2^−n |[−2,2]^n intersect Q(x,1)|≤1`.

The specified auxiliary raw moment divided by U therefore is

`[(2^k m_k)/4]^n=[(k²+3k+4)/(2(k+1))]^n`,

and its logarithm is exactly

`n log[(k²+3k+4)/(2(k+1))]`.

The base is `(k+2+2/(k+1))/2`, which is larger than one for every k≥2 and is asymptotic to k/2. For `k=ceil(128sqrt(n))`, the logarithm divided by n behaves as `(1/2)log(n)+log64`.

The exact integer k is obtained from integer square roots of 16384n and checked on both sides; no floating ceiling is used. The following centers are approximations to the 256-bit Arb certified balls retained in RESULT.json.

| n | exact k | log ratio divided by n | log ratio |
|---|---:|---:|---:|
| 256 | 2048 | 6.932448 | 1774.706782 |
| 257 | 2052 | 6.934398 | 1782.140205 |
| 1024 | 4096 | 7.625107 | 7808.109842 |
| 65536 | 32768 | 9.704122 | 635969.310752 |
| 1000000 | 128000 | 11.066654 | 11066653.987342 |

For comparison, the corresponding expanded-intersection expression has logarithm `n[(k+1)log2−log(k+1)]`, much larger still. Both are stored. All five retained log ratios are positive.

These computations are for the displayed raw moment, not for an unrecorded normalization. If one subsequently divides by a fixed `(C sqrt(n))^k`, its logarithmic expense at k≈sqrt(n) is only O(sqrt(n)log(n)), whereas the auxiliary logarithm above is of order n log(n). That arithmetic observation still does not identify this relaxed moment with the original eligible all-outside cost.

The source model verifies the low field g≤1, but its intersection-compatible keys are not assigned to actual high-rate strict cores. Original all-outside indicators, first-core assignment, chronological saturation, causal masks, and finite disjoint owners are not certified. Their removal is precisely why this calculation is a test of a relaxed moment argument and cannot refute the original problem.

## Reproducibility and stopping

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r686-20261116/NUMERIC.py --iid-uniform
```

RESULT.json records the complete model, general symbolic identities, seven exact Fraction checks, five dimension checks, Python/SymPy/python-flint versions, precision, command, code hash and results. Large m_k values are stored in factorized exact form for the dimension tests, avoiding huge powers or decimal strings. No Monte Carlo, numerical quadrature, arbitrary scan, geometric grid, actual owner family, agent, Git operation or PDF was used.

The run finished normally in about 0.22 seconds; both symbolic identities and all exact checks passed, errors are empty, and the Python process exited with code zero. Source SHA-256: `51d964d07a31d17a60eddbdf9eb7b7404ed048b10171a029fd135ca0221b07be`. Result SHA-256: `a904bbeb10522808201ee92c4188d10c13d847859c857ab0542060cdeb67e755`.
