# R686 continuation: actual-parent capture; no new uniform bound

The original all-L1/all-scales/Lebesgue pure C_n<=K sqrt(n) goal remains open. Preserve R684 accurate receiver normalization, full far/up/self/source fees, original P0 over ALL input parents, and user cap ONE Astra / THREE GPT-6.1 Sol. Current agents reused, no additional agents. Local math tools used only for proof-relevant computation; MATLAB not launched.

## What was genuinely checked

R673 iid short sample k=ceil128sqrt(n), profile rate sigma>=4096sqrt(n), actual partial owners, one common original witness, min source radius>=anchor seed: expectation of expanded original intersection<=3M exp(-2k). Extend capture from historical witness tests to ANY intersection of an actual receiver parent with Ev={sum vi1Ai>=.8sigma}, provided target radius<=anchor radius. The SAME sample pays the entire real receiver union<=eta M, eta=3exp[-(2+ln.8)k]. This is an enlarged legal capture class, NOT a paid global budget.

For a fixed attaining original packing dual density h with integral P0, take profiles only from the earliest group STILL REPRESENTED among remaining receivers. All remaining target radii<=its original seed. If eta M<=L tau integral_(Ev minus D) h, capture ALL intersecting target parents and add Ev to D. Every remaining parent avoids D, so h1_(D complement) keeps its dual constraints. Fresh deleted regions pay the accepted total once. Taking arbitrary later anchors would invalidate this argument; merely increasing anchor order is insufficient.

The missing global alternative T is: when no profile at the current earliest represented group meets that affordability inequality, show remaining receiver measure<=C tau integral_(D complement)h, uniformly over actual generated states and the selected attaining dual. NO PROOF of T, nor always-affordable profile existence. Source parents can reuse already-deleted dual mass even while surviving target parents avoid it. This is now the precise positive target; no more standalone profile-LP reformulations count as progress.

S2 also gives sufficient mixed original-packing debit: z_i=eta sum_p lambda_p v_i^p, residual w_h=(1-profilecoverage_b)_+ |X_h|/d_h. If joint load sum(z+w)1Ai<=C tau, one original packing pays V<=C tau P0. Joint load bound NOT proved. No old-q cap on target variables, including q_h=0. Two separately feasible capacities cannot be added for free.

## What not to overclaim or repeat

Whole-profile cover cost<=exp(O(sqrt n))U is stronger than original scalar payment; not proved necessary. Minimum cost within each core and formal source reuse are not global payment. R677 already recorded full-pool first-hit short moments; tau normalization is not a novel mechanism by itself. Old Theta-normalized rich high moment remains false.

Exact auxiliary iid uniform-center model: y uniform[-2,2]^n, unit cube and unit halo. One-coordinate retained halo m_k=2^(1-k)(k^2+3k+4)/(k+1). With continuous q-density2^-n, g<=1, total rate2^n and U4^n, bare ordered moment/U=[(k^2+3k+4)/(2(k+1))]^n. Keeping nonempty original intersections alone does not yield uniform bare moment. THIS HAS NO high-tau saturated history or actual finite owners/receivers; it is not an original-goal or profile-cover counterexample. Do not spend another round constructing unrelated relaxed counterexamples.

## Actual verification

NUMERIC.py --iid-uniform ran in /Users/zzh/.local/share/math-research-tools/venv/bin/python: SymPy general identities, seven Fraction cases k2..128 by doubling, five256-bitArb dimension cases n256,257,1024,65536,10^6. Independent verify.py reconstructs each retained moment from truncated range probability and first moment, checks recorded fractions and interval logs plus file bindings. PASS. Unused profile-validator interface remains in the same script; no profile LP, empirical geometry experiment or MATLAB run was performed. No PDF.

Next completed round will be687 after this round's final independent audit/archive/push. Continue actual joint geometry at T or equivalent complete mixed budget; do not call local capture an upper-bound breakthrough.
