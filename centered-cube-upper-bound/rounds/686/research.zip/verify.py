from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json,hashlib
from flint import arb,ctx
P=Path(__file__).resolve().parent
j=json.loads((P/'RESULT.json').read_text())
assert hashlib.sha256((P/'NUMERIC.py').read_bytes()).hexdigest()==j['script_sha256']
ctx.prec=256
for row in j['fixed_k_exact_checks']:
 k=row['k'];prob=F(k+1,2**k)
 # Integrate R against the range density, independently of the halo polynomial.
 first=F(k*(k-1),4**k)*(4*F(2**k,k)-F(2**(k+1),k+1))
 halo=4*prob-first
 assert halo==F(row['m_original_intersection_exact'])
 assert F(row['m_expanded_intersection_exact'])==F(8,k+1)
 assert halo/F(8,k+1)==F(row['m_keep_over_expanded'])
 assert 2**k*halo/4==F(row['normalized_base_2k_m_over4'])
for row in j['dimension_checks']:
 n=row['n'];k=row['k_exact_ceil_128sqrt_n']
 assert (k-1)**2<16384*n<=k*k
 b=F(k*k+3*k+4,2*(k+1));assert b==F(row['normalized_base_exact'])
 v=n*(arb(b.numerator).log()-arb(b.denominator).log())
 assert v.overlaps(arb(row['log_normalized_ratio'])) and v>0
# The expanded capture exponent has the correct sign and remains positive.
assert 2+(arb(4)/5).log()>0
if (P/'MANIFEST.json').exists():
 for name,digest in json.loads((P/'MANIFEST.json').read_text()).items():
  assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
print(json.dumps({'status':'PASS','independent_exact_range_checks':len(j['fixed_k_exact_checks']),'interval_log_crosschecks':len(j['dimension_checks']),'scope':'auxiliary product model and source binding only; no original high-threshold history or uniform upper bound'}))
