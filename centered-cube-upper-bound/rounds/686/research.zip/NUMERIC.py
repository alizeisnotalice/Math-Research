#!/usr/bin/env python3
"""R686 exact global profile/capture interface; awaits an author-frozen fixture."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json,hashlib,sys
ROOT=Path(__file__).resolve().parent

def exact(value):
    if not isinstance(value,(str,int)) or isinstance(value,bool):raise ValueError('Use exact integer/fraction strings; no floating profile data')
    return F(value)
def rational_json(value):
    if isinstance(value,F):return str(value)
    if isinstance(value,list):return [rational_json(v) for v in value]
    if isinstance(value,dict):return {k:rational_json(v) for k,v in value.items()}
    return value

def validate_frozen_profiles(data):
    """Build exact candidate cover columns; this function does not optimize a model."""
    if data['profile_scope']!='author-specified finite candidates':
        raise ValueError('Complete continuous-profile enumeration needs its separately frozen bounds and certificate; do not silently reinterpret finite candidates as global')
    sources=data['sources'];cores=data['cores'];profiles=data['profiles']
    if len(sources)>8 or len(cores)>8 or len(profiles)>16:raise ValueError('Initial bounded interface: at most8 sources/cores and16 candidate profiles; enlarge only for a frozen authorized input')
    sid=[s['id'] for s in sources];cid=[c['id'] for c in cores];pid=[p['id'] for p in profiles]
    if any(len(set(ids))!=len(ids) for ids in (sid,cid,pid)):raise ValueError('IDs must be unique in each category')
    q=[exact(s['q']) for s in sources];d=[exact(s['d']) for s in sources]
    if any(v<=0 for v in q+d):raise ValueError('Active sources require positive q,d')
    sigma=exact(data['sigma']);Tmin=exact(data['Tmin'])
    if not sigma>=Tmin>0:raise ValueError('Require frozen sigma>=Tmin>0')
    rule=data['chronology_rule']
    if rule not in ('b>=anchor','b>anchor'):raise ValueError('Freeze whether self capture is permitted')
    C=[]
    for c in cores:
        if len(set(c['source_ids']))!=len(c['source_ids']) or any(i not in sid for i in c['source_ids']):raise ValueError('Invalid frozen core source IDs')
        C.append(set(sid.index(i) for i in c['source_ids']))
    targets=data['target_core_ids']
    if len(set(targets))!=len(targets) or any(i not in cid for i in targets):raise ValueError('Invalid target core IDs')
    columns=[]
    for p in profiles:
        if p['anchor_core'] not in cid or any(i not in sid for i in p['v']):raise ValueError('Unknown profile anchor or source')
        anchor=cid.index(p['anchor_core']);v=[exact(p['v'].get(i,'0')) for i in sid]
        if any(not F(0)<=v[i]<=q[i] for i in range(len(sid))):raise ValueError('Profile violates0<=v<=q')
        if any(v[i] and i not in C[anchor] for i in range(len(sid))):raise ValueError('Profile support escapes its frozen anchor core')
        if sum(v,F(0))!=sigma:raise ValueError('Profile mass differs from frozen sigma')
        masses=[sum((v[i] for i in cc),F(0)) for cc in C]
        covered=[]
        for b in range(len(cid)):
            later=b>=anchor if rule=='b>=anchor' else b>anchor
            if later and masses[b]>=F(4,5)*sigma:covered.append(cid[b])
        columns.append({'id':p['id'],'anchor_core':p['anchor_core'],'v':v,'cost':sum((d[i]*v[i] for i in range(len(sid))),F(0)),'capture_masses_all_cores':masses,'covered_core_ids':covered,'cover_target_column':[int(t in covered) for t in targets]})
    return rational_json({'status':'frozen candidate profiles validated; optimization not yet executed','source_ids':sid,'core_ids_chronological':cid,'target_core_ids':targets,'sigma':sigma,'capture_threshold':F(4,5)*sigma,'global_source_reference_U':sum((d[i]*q[i] for i in range(len(sid))),F(0)),'columns':columns,'scope':'Only these finite supplied candidates. The program has not verified cube geometry or global continuous-profile completeness.'})

def iid_uniform_audit():
    import time,platform
    from math import isqrt
    import sympy as sp
    import flint
    from flint import arb,ctx
    tick=time.time();ctx.prec=256
    t=sp.symbols('t',nonnegative=True);j=sp.symbols('j',integer=True,nonnegative=True);kk=j+2
    direct=sp.integrate(kk*(kk-1)*t**j*(4-t)**2/4**kk,(t,0,2))
    closed=2**(1-kk)*(kk**2+3*kk+4)/(kk+1)
    assert sp.simplify(direct-closed)==0
    expanded=sp.integrate(kk*(kk-1)*t**j*(4-t)**2/4**kk,(t,0,4))
    assert sp.simplify(expanded-8/(kk+1))==0
    fixed=[]
    for k in (2,4,8,16,32,64,128):
        integral=F(k*(k-1),4**k)*(16*F(2**(k-1),k-1)-8*F(2**k,k)+F(2**(k+1),k+1))
        formula=F(k*k+3*k+4,(k+1)*2**(k-1))
        exp_integral=F(k*(k-1),4**k)*(16*F(4**(k-1),k-1)-8*F(4**k,k)+F(4**(k+1),k+1))
        assert integral==formula and exp_integral==F(8,k+1)
        base=F(2**k)*formula/4
        assert base==F(k*k+3*k+4,2*(k+1)) and base>1
        fixed.append({'k':k,'m_original_intersection_exact':formula,'m_expanded_intersection_exact':exp_integral,'m_keep_over_expanded':formula/exp_integral,'normalized_base_2k_m_over4':base,'log_normalized_base':str(arb(base.numerator).log()-arb(base.denominator).log()),'Fraction_integral_matches_formula':True})
    dims=[]
    for n in (256,257,1024,65536,10**6):
        k=isqrt(16384*n)
        if k*k<16384*n:k+=1
        assert (k-1)**2<16384*n<=k*k
        base=F(k*k+3*k+4,2*(k+1))
        logbase=arb(base.numerator).log()-arb(base.denominator).log()
        logratio=n*logbase
        logexpanded=n*((k+1)*arb(2).log()-arb(k+1).log())
        assert logratio>0 and logexpanded>logratio
        dims.append({'n':n,'k_exact_ceil_128sqrt_n':k,'m_exact_factorized':'2^(1-'+str(k)+')*('+str(k*k+3*k+4)+'/'+str(k+1)+')','normalized_base_exact':str(base),'log_normalized_ratio':str(logratio),'log_normalized_ratio_per_n':str(logbase),'log_normalized_expanded_intersection_ratio':str(logexpanded),'log_retained_over_expanded_ratio':str(logratio-logexpanded),'positive_retained_log_ratio':True})
    out={'status':'completed explicitly requested iid uniform source-center model','scope':'AUXILIARY CONTINUOUS MODEL ONLY. Independent centers uniform[-2,2]^n, parent radius1, halo h=1, infinitesimal source weight density2^-n. No disjoint actual owners, chronological saturation, historical strict cores, original high-tau recursion, causal masks or full all-outside kernel are verified. Not a counterexample to the original goal.','python':sys.version,'platform':platform.platform(),'sympy_version':sp.__version__,'python_flint_version':flint.__version__,'arb_precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve()),'--iid-uniform'],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'range_density_1d':'k(k-1)t^(k-2)(4-t)/4^k, 0<t<4','original_intersection_gate':'R<=2 in every coordinate','halo_length_on_gate':'4-R','m_integral':'k(k-1)/4^k integral_0^2 t^(k-2)(4-t)^2 dt','m_closed_form':'2^(1-k)(k^2+3k+4)/(k+1)','expanded_without_gate':'8/(k+1)','symbolic_integral':str(direct),'symbolic_expanded_integral':str(expanded),'source_normalization':{'weight_density':'2^-n dy','total_source_rate':'2^n','parent_volume':'2^n','source_reference_U':'4^n','parent_field':'g(x)=2^-n volume([-2,2]^n intersect Q(x,1))<=1','moment_quantity':'(total_source_rate)^k * E[halo volume with original-intersection gate] / U = [(2^k m_k)/4]^n','log_quantity':'n log[(k^2+3k+4)/(2(k+1))]','not_included':'Original all-outside product, strict-core eligibility, causal receivers and finite owner realization are not identified with this auxiliary moment.'},'fixed_k_exact_checks':rational_json(fixed),'dimension_checks':dims,'summary':{'fixed_k_Fraction_checks':len(fixed),'dimension_Arb_checks':len(dims),'symbolic_identities_passed':True,'all_exact_checks_passed':True},'elapsed_seconds':time.time()-tick,'errors':[],'old_profile_interface_status':'Retained in NUMERIC.py but unused and not optimized; the explicit iid task replaces the missing-input profile computation.'}
    (ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'source_sha256':out['script_sha256'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'dimension_checks':dims},indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path);p.add_argument('--iid-uniform',action='store_true');args=p.parse_args()
    if args.iid_uniform:
        if args.input:p.error('Use --input or --iid-uniform separately')
        iid_uniform_audit();return
    if args.input is None:
        print('Awaiting S2/Astra frozen fixture; no profiles, cover LP, or synthetic instance generated.');return
    raw=args.input.read_bytes();data=json.loads(raw);result=validate_frozen_profiles(data)
    out={'input':data,'input_path':str(args.input.resolve()),'input_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'result':result,'optimization_executed':False,'scope':'Validation interface only until frozen LP certification is explicitly added for the supplied bounded instance.'}
    (ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
