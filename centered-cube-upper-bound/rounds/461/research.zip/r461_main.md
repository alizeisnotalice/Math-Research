# 第461轮：双捕获双排除的精确中心体积包络

## 目标与状态

继续控制原实际P=Xi_can,out上的有效交叠费用，而不是继续扩展selector公式。本轮建立任意维数、任意有限点配置的可测边长中心极值核，明确父外两终端的真实Lebesgue体积费用。该核是外包络，不是已经闭合的源价；一般n^(1/2+o(1))上界及中间段硬层整体预算仍未证明。

## 核心几何结果

给定必须捕获的Y={y,z}、必须排除的Z={u,v}、L<=R_A<=U，以及p>0，原中心上的R_A^{-p}积分被一个显式且在放松类内达到的极值E_p支配。令r(A)=max(L,2 max_{x in Y}||A-x||_infty)。可行中心正是r(A)<=U且r(A)<2 min_{x in Z}||A-x||_infty。因费用随边长下降，r(A)本身为最优可测选择。

精确值为
\[
E_p=L^{-p}V(L)+\int_L^U t^{-p}S(t)dt.
\]
V(L)是固定边长捕获全部Y但排除全部Z的中心体积。S(t)是新增捕获中心面的外向通量，且在进入时已经排除Z。它不是V'(t)：排除立方体也在扩张，V'还扣除了旧中心被排除的流出量。附件envelope给出每个面的包含-排除乘积式，处理坐标重合、零宽面、重复排除点及L=U的固定边长base。证明通过分段仿射距离的coarea，保真实Lebesgue中心，无来源密度帽。

q-band和两端严格质量门只用于取
\[
L=\max\{a,[K^2\max(m_u,m_v)/\lambda]^{1/n}\},\quad U=b.
\]
若K²maxmass>=lambda b^n，真实父集合为空；否则按公式保base。对原同一父选择器，R_A^{-n}父核受E_n支配，q_A/m_A²核受E_{2n}/q支配。最大化的放松选择器可能不满足完整f质量匹配和history，不能把它当原场。每组来源/终端分别求极值也可能丢掉原父共享的收益；这笔损失未认证可忽略。

一个对完整双来源父核有用的通用推论是
\[
E_{2n}\le 2L^{-n}-U^{-n}\le2L^{-n},\qquad
\int_{\mathrm{eligible}}\frac{q_A}{m_A^2}dA
\le\frac{2r}{K^2\max(m_u,m_v)}.
\]
证明是只保一个required点、删除所有排除点，精确积分n t^{n-1}t^{-2n}。该父核本身没有额外n因子，因此下一步应尽量保双来源密度到换序后再估，避免过早使用单来源A_n包络。但还必须控制随后真实来源/终端权的重复积分；这里没有把指数质量门直接转为全局源价。

## 与实际源价的连接检查

Astra在同一实际record中作嵌套立方体插值：公平soft费用等于log2加共同截断的signed质量增长 ∫(dG/G−dH/H)。终端之外的来源只进入G，不能只向终端内部捕获质量收费。该式保父终点与原接受权，但虚拟中间尺度没有原q-band，且各record的嵌套族不同；未把它们当实际接收者。

Sol先积父中心，保留正上放带来的Δ_accept、Δ_w，并将log(mA/mu)拆成同父外部增长减未捕获终端质量。共享后的粗预算仍含一次额外父累计A_n，约为n²W级费用，未达到目标n polylog(n)W。不能把外部来源质量按每个终端重复计W；也不能把两个真实负项丢掉后再宣称有净节省。

因此后续具体缺口是：在实际P权重下，把外源增长、内部捕获负项与上述中心面通量共同结算，去掉粗估计中多余的父重复费用。精确核提供可计算的几何约束，但本轮没有证明这种结算成立。

## 原完整总账

R458比较仍为
\[
R_{433}\le[S\zeta+2S\varepsilon_0/s+2S\delta]X+R.
\]
R460同流软选择比较仍为
\[
(2\sqrt n-\log N)R\le C_p+SX/e.
\]
本轮未给C_p新增根阶源价；旧soft/return/rounding费、N/S依赖及各母槽16/32/64倍率不变。单一中间父核的精确最大值不能当作完整剩余交集的估计。

## 工具和验证范围

使用A02外放松与误差预算技能核对原可行集到放松集的包含、目标方向和达到性；未借用未经阅读的外部定理或把数值最优当证明。指定本机数学Python实际用于SymPy/Fraction精确分段积分及Arb辅助恒等式核验。

主要几何计算包含10个预先指定配置：初步一维直接中心积分；坐标重合、必含点同时被排除、重复排除点、固定边长的压力检查；二维三维扩大配置。IE公式与独立矩形分割算法逐段一致，239项精确断言含支持/次数等常规检查，不等于239独立样本。所有断点和多项式片段保留。特别例证中V为常数但S=1/2，证实漏掉移动排除边界会算错。高维一般式依解析证明，不外推这些有限检查。

geometry另有33项固定记录连续源插值检查，complement有18项Arb检查；它们不认证原完整field/history。仅使用1 Astra high、2 Sol high、1 Sol medium及1 Luna medium历史定位；其余空闲。Luna索引只帮助选择实验，最终未重跑已有R443示范；该临时索引不重复归档。没有实际扣额数据，不估算模型成本。保持LaTeX文本与必要复现，不编译PDF。

主代理已在独立临时目录重放geometry、complement及numeric脚本：stdout为33、18及239项通过，numeric JSON除运行seconds外逐字段一致。complement已改用无条件3^n A_n几何包络及n log3费用，消除未经合同保证的K²>r前提；数值相应更新并实际重跑。numeric的非负断言要求SymPy返回True，不接受unknown，强化后复现仍一致。

主代理另对10个现有精确E_{2n}值核验上述通用上界，使用有理数精确比较；这不是一般证明的替代。复现代码读取本包已有JSON，不增加输入配置：

```python
from pathlib import Path
from fractions import Fraction as F
import json
data=json.loads(Path('r461_numeric_check.json').read_text())
for row in data['fixtures']:
 n=row['n']; L=F(row['L']); U=F(row['U'])
 exact=F(row['E'][str(2*n)])
 assert exact <= 2*L**(-n)-U**(-n)
print('PASS 10 pair-tail rational checks')
```
