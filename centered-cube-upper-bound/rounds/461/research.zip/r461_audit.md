# R461 FINAL PASS（限定范围）

独立 PRE 先于作者稿形成，随后核对最终八份冻结输入。本 PASS 仅认证一般中心几何包络、同一实际记录的径向 signed 恒等式、明确缺额的粗参考上界及下列有限复现。**不认证实际有效交叠的根阶源价、不认证完整余项或一般弱型闭合；原母账不变。**

多点包络的最小可行边长、可测达到性、required 面速度 \(1/2\)、inclusive excluded normal-mask 与 tangential 容斥均正确。\(S(t)\) 是新进入 required 面的通量，不能替成允许域体积 \(V'(t)\)。严格不捕获与坐标重合处理一致。已修正 \(L=U\) 的 fixed-side base；仅 \(K^2\max(m_u,m_v)\ge\lambda b^n\) 可由严格质量门直接判空。实际核的 \(E_n\) 与 \(E_{2n}/q\) 上放方向正确，放松 selector 不获原 matching/history。

径向插值所需是 \((y,u,v,j,k)\) 投影的 AC，不是完整 clock 记录的产品 AC。固定终端/bin 后的 Lebesgue 点控制对包含该来源点的缩小立方体一致有效，故允许依父变化的偏移。对数 Stieltjes 差保共同下端点；没有把其极限与全 \(P\) 积分无条件交换。虚拟尺度不获真实 q-band。

complement 已移除合同未保证的 \(K^2>r\)：octave 给 \(R_u\le2R_A\)，故无条件中心帽 \(3^nA_n\) 与 \(n\log3\) 正确。同源平均帽仍为 \(A_n\)，canonical 列与来源熵估计保真实 \(f\)。接受上放缺额、\(-\log w\) 缺额及同父外源正项/未捕获负项符号正确。外源 Tonelli 展开未获额外根价；粗式保 \(S,N,r\) 依赖，不将其称完整新付款。单端参考积分有限，且 \(w(-\log w)\le1/e\) 与原生 \(J\) 帽也保证该缺额有限，未作未定义的无穷相减。两方向以固定先验加权，不额外乘二。

隔离复现使用指定 Python：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
目录：`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r461_audit_lt3y0xtg`。
从冻结 md 提取 geometry/complement 各一代码块并运行，分别 `PASS 33`、`PASS 18`；复制 numeric 脚本隔离运行 `PASS 239`。三份 stdout 与 replay 逐字一致，numeric JSON 删除唯一运行秒数字段后逐字段一致。239 是十个预设配置的精确断言数，非独立几何样本数；33 为固定记录插值，18 为有限 Arb 标量检查。均不认证原完整场/history。独立 PRE 的临时符号辅助不加入归档统计。

补充的通用 pair-tail 推论亦通过：只保一个 required 点并删全部 excluded 后，base 加径向面通量积分给 E₂ₙ≤2L⁻ⁿ−U⁻ⁿ，故实际父核≤2r/[K² max(m_u,m_v)]；没有额外 n，但仍未积分来源/终端权，不是新 W 付款。最后仅新增重放 main 内嵌代码，在 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r461_audit_pairtail_i89adob6` 得 `PASS 10 pair-tail rational checks`，stdout 与更新 replay 一致。这十项复用已有配置，不增加几何样本；未重跑未改的其他代码。

最终输入 SHA256（审计自身不绑定）：

- `r461_main.md`: `80b0e8d233ef092a375d82b1d8bd0ce48d8f80a765702a1415e65b77d1a7fe80`
- `r461_envelope.md`: `2a6f8e223fa68969bfb981104be940e246a065d43deaa02dcc9e6822d1e07dd5`
- `r461_geometry.md`: `074809261333def64536929ded42da21951d8ca8b7f78afcdba252466ede0352`
- `r461_complement.md`: `63ecb32c5c2f43263554d8e71b2f00e6388d9a7c482aee54a9b39ed56c6ab7b4`
- `r461_numeric_plan.md`: `c670fea4c382a22689e53042bdba35d34ab295ba4b8bc63b605b451e78014f14`
- `r461_numeric_check.py`: `08f1c99d7ac7cab31fe7360ecc6af53fb3678b27b43b2854daa1f908fe77266e`
- `r461_numeric_check.json`: `655fed6ec07fefaec112b4a814d4e8feacebdc22dfe402ff3d72cb6d2fc948f4`
- `r461_replay.json`: `43cf72a842ae2a090963b1299a1984684b296f97441cdfdde292d8752db52da1`
