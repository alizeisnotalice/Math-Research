# R461 main: exact extremal center-volume envelope with two exclusion points

This is a geometric kernel identity for all finite point configurations, not a source-density estimate or a paid full remainder. It retains Lebesgue center measure. Let required points Y be nonempty, excluded points Z finite (the application has Y={y,z}, Z={u,v}), 0<L<=U, and p>0. Cubes have side t and center A. For Z empty, the minimum of excluded-point distances is defined as +infinity and the excluded union is empty. We maximize t^{-p} over measurable selected sides t(A) in [L,U] whose cubes contain every Y and contain no point of Z. Infeasible centers have weight zero.

Write alpha_i=max_{y in Y}y_i, beta_i=min_{y in Y}y_i, d_i=alpha_i-beta_i, d=max_i d_i. Define the required-center box B_Y(t)=product_i[alpha_i-t/2,beta_i+t/2], empty for t<d, and r(A)=max(L,2 max_{y in Y}||A-y||_infty). Feasibility is r(A)<=U and r(A)<2 min_{z in Z}||A-z||_infty. On feasible centers the maximizing selected side is exactly r(A). Thus the supremum over all measurable selectors is attained by the explicit measurable selector r on its feasible set, and its value is

E_p(Y,Z;L,U)=L^{-p} V(L)+integral_L^U t^{-p} S(t)dt. (1)

When L=U the integral is zero and E=L^{-p}V(L), retaining the fixed-side base. Here V(L)=|B_Y(L) minus union_{z in Z} Q_L(z)| and S(t) is the influx of NEW required centers at side t which are outside all excluded-center cubes at THAT SAME t. S is not dV(t)/dt: exclusions themselves expand, and their outflux must not be forgotten.

For t>d, let F_i^+(t) be the upper face with coordinate beta_i+t/2 and F_i^-(t) the lower face alpha_i-t/2, tangential intervals inherited from B_Y(t). Each face moves outward with speed 1/2. Then exactly

S(t)=1/2 sum_{i,sign} H^{n-1}(F_i^sign(t) minus union_{z in Z} Q_t(z)). (2)

Faces meeting in edges have n-dimensional coarea measure zero. If d>=U the integral term is zero. Values at finitely many t breakpoints do not affect the integral. At coincident source/exclusion coordinates, however, use inclusive exclusion on the face: a whole face may coincide for an interval of t and must be removed. This preserves the original strict non-capture condition.

An explicit inclusion-exclusion formula applies. For T subset Z put d_k(T)=max(Y union T)_k-min(Y union T)_k. For an upper face, the normal-coordinate indicator J_i^+(T,t) is one exactly when beta_i<=z_i<=beta_i+t for all z in T; for a lower face J_i^-(T,t)=1 exactly when alpha_i-t<=z_i<=alpha_i for all z in T. Empty T has indicator one. Then

S(t)=1_{t>d}/2 sum_{i,sign} sum_{T subset Z}(-1)^{|T|} J_i^sign(T,t) product_{k != i}(t-d_k(T))_+. (3)

V(L)=sum_{T subset Z}(-1)^{|T|} product_k(L-d_k(T))_+.

For n=1 the tangential empty product is one. Cubes are closed for capture; the no-capture set is open, hence the weak inequalities in J. Coincident required points and repeated excluded points are allowed if Z is first deduplicated; if any excluded point equals a required one, V=S=0.

Proof of (1): partition feasible centers into r=L and r>L. The first part has volume V(L). On the latter, the level surfaces of r are the faces of the expanding required-center box. The distance to every excluded point is tested at this minimal feasible side r, so enlarging the selected side never creates feasibility or improves the decreasing weight. Coarea of this piecewise affine r gives (2); intersection of each face with excluded cubes has the normal indicator and product tangential length in (3). This proves the formula without regularity assumptions on a putative side selector.

Every integrand is piecewise polynomial of degree at most n-1 times t^{-p}, with breakpoints among required spans, augmented spans and positive normal-coordinate differences. For p=n or 2n and rational coordinates, L,U, the exact integral is a rational linear combination of endpoint powers and logarithms of positive rationals. No sampling of receiver centers is needed to define E_p. Rational lower/upper radius bounds can safely enclose nonrational strict-mass thresholds; choosing a lower bound smaller than the actual threshold only enlarges the envelope.

Application to the original actual parents: m_A=q_A R_A^n, q_A<=lambda and m_A>K^2 max(m_u,m_v) imply R_A>[K^2 max(m_u,m_v)/lambda]^{1/n}. Hence take L=max(a,that threshold), U=b. For every fixed actual (y,z,u,v), the parent kernel satisfies

integral_{actual eligible A} 1/R_A^n dA <= E_n(Y,Z;L,b),
integral_{actual eligible A} q_A/m_A^2 dA <= (1/q) E_{2n}(Y,Z;L,b). (4)

Put H=K^2 max(m_u,m_v). If H>=lambda b^n the actual parent set is empty by the strict mass inequality. Otherwise L<=b; in the degenerate octave a=b retain the fixed-side base E=b^{-p}V(b), rather than declaring it empty. No q-band assumption is imposed on the maximizing surrogate selector; (4) is therefore an outer geometric bound, not a realization of the original field. All original stage/history and source-dependent weights must remain on the actual side when used in the full integral. The envelope may be too large to pay the target; it is not a new source-mass budget, and no small boundary volume is converted to small f mass.

The formula makes explicit the genuine parent-center geometry that a later shared external-source charge must use. Establishing a root-scale source price after integrating this kernel with the actual source/terminal weights remains open.

## Universal pair-kernel tail retained before source integration

Dropping all but one required point and every excluded point enlarges the feasible selector class. Its exact envelope is L^{n-p}+n integral_L^U t^{n-p-1}dt. In particular, including L=U,

E_{2n}<=2L^{-n}-U^{-n}<=2L^{-n}.

Consequently the actual two-source parent kernel in (4) is at most 2/(qL^n)<=2(lambda/q)/(K^2 max(m_u,m_v)). There is no extra factor n in this parent-kernel bound. This is a bound before integrating source and terminal weights; those weights can repeat a source many times. It does not imply a global W price or eliminate the actual acceptance fees. The common-parent q_A/m_A^2 density must be kept until this step; using a one-source R_A^{-n} envelope first would lose this tail structure.
