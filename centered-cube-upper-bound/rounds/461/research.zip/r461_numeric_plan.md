# R461：全配置中心包络的有限精确复核

计算对象已按主代理冻结为 r461_envelope.md 的 E_p(Y,Z;L,U)，p=n,2n；未运行先前拟议R443静态场。结果支持“新增required-face influx”公式，并明确否定以 dV/dt 替代 S 的做法。这里没有qband实现、实际source f、原history或费用付款认证：E是中心几何outer bound，其后的source/terminal积分价格仍开放。

## 对象与两个独立实现

令B_Y(t)为包含全部required点的中心盒，V(L)为该盒扣全部excluded中心立方体并集的体积。核验

E_p=L^(-p)V(L)+∫_L^U t^(-p)S(t)dt。

实现一按公式(3)对excluded子集做容斥，包含normal-coordinate弱不等式；实现二在每个face的tangential矩形中，按每个excluded cube边界切成矩形单元，以单元中点精确判断覆盖并求有理体积。这里的中点只判断边界已完全切分后的常值覆盖，不是以中心点代理整块积分；0维face也保inclusive排除。V(L)另用完整n维矩形分割，与容斥独立比较。

breakpoints含required/augmented spans、normal-coordinate差及L,U。每个开区间的S是次数≤n−1的多项式：取n个有理节点插值，再以两个额外有理点交叉核验两实现；SymPy对其乘t^(-p)精确积分，保endpoint powers和log。完整分段多项式及E表达式均记录于JSON。每个1D配置还独立按A的距离函数r(A)=max(L,2max_y|A−y|)分段，直接积分可行中心上的r(A)^(-p)，与face公式比较。

## 有界三阶段与实际结果

初步为每维的单required/单excluded点；压力包含required=excluded、coincident faces、two-sided exclusion与L=U；扩大仅至错位3D和重复excluded去重。最终10个预设配置（1D四个、2D三个、3D三个），无随机扫描，distinct excluded最多两个。

| 配置 | n | E_n | E_2n |
|---|---:|---|---|
| initial_1d | 1 | 1+log(6)/2 | 37/12 |
| fixed_side_base_1d | 1 | 1 | 2 |
| face_tie_1d | 1 | 0 | 0 |
| two_exclusions_1d | 1 | log(5)/2 | 11/10 |
| initial_2d | 2 | 13/8−log(2)/2+3log(3)/2 | 6191/864 |
| coincident_faces_2d | 2 | −1/6−log(2)+3log(3)/2 | 1645/1296 |
| required_excluded_2d | 2 | 0 | 0 |
| initial_3d | 3 | 9/4−3log(2)/2+5log(3)/2 | 157237/10368 |
| offset_3d | 3 | −263/256+log(8) | 1711/1024 |
| duplicate_exclusion_3d | 3 | −199/128+log(16) | 5257/3840 |

最直接的判别例：Y={0},Z={3/4}。对3/4<t<2，V(t)=t−(t−3/4)=3/4，所以dV/dt=0；但一侧新增required face尚未被excluded cube覆盖，S(t)=1/2。因此只对V求导会丢失真实新增可行中心，导致错误E。inclusive face排除在required=excluded的1D/2D例得到S=V=E=0，而不是留下coincident face假贡献。

L=U=1/2的fixed-side例V=1/2，故E_1=1、E_2=2，积分为空但base不空。这不同于应用中strict mass门本身使eligible parents为空；没有将L=U一般误判为空。

## 执行、误差与scope

实际 **239项精确断言**，包含质量/几何/多项式/积分等交叉断言；不是239个独立配置。输入仅上述10例。Fraction处理坐标和体积，SymPy作有理插值及exact power/log积分，无浮点数学判定、无Monte Carlo。指定解释器：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r461_numeric_check.py
```

Python 3.12.14、SymPy 1.14.0；最后命令wall约0.19秒。JSON内运行seconds仅为浮点元数据。脚本自含所有输入，输出写脚本自身目录。

这仅验证10个配置的恒等式实现与边界口径，不是对所有n≤3配置的穷尽核验，也不代替主代理一般coarea/容斥证明。不从少维推断sqrt阶，不把小中心体积当小f质量，不支付soft费用。原先提出的D候选未执行，已由本次冻结E任务替代。

冻结归档白名单：r461_numeric_plan.md、r461_numeric_check.py、r461_numeric_check.json。完成即停。
