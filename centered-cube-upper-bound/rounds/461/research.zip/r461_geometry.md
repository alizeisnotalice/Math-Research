# R461：同一实际父的径向增长尝试

**状态：未得新付款。** 本轮只考察同一实际记录的嵌套立方体插值，检验能否将父累计量计给真实新增来源。保留完整 \(P=\Xi_{\rm can,out}\)；没有改变接收场、终端、接受权或历史。

## 1. 唯一候选及可证表示

取实际正记录 \(\xi=(A,y,z,u,v,j,k,\ldots)\)，记
\(w_y=w_{y,j}(m_u)>0,w_z=w_{z,k}(m_v)>0\)。令
\[
 a_\xi=(A-y)/R_A,\quad Q_r^\xi=y+r(a_\xi+[-1/2,1/2]^n),\quad0<r\le R_A.
\]
因 \(y\in Q_A\)，这些立方体嵌套，且 \(Q_{R_A}^\xi=Q_A\)。它们只是积分插值，**不是新增实际接收者**。定义
\[
 G(r)=\int_{Q_r^\xi}f(x)dx,\qquad
 H(r)=\frac12\int_{Q_r^\xi}f(x)
 \left[\frac{c_u(x)w_{x,j}(m_u)}{w_y}
       +\frac{c_v(x)w_{x,k}(m_v)}{w_z}\right]dx.
\tag{1}
\]
于是公平 soft 费用逐记录严格等于
\[
 \Gamma(\xi)=\log\frac{G(R_A)}{H(R_A)}.
\tag{2}
\]
实际两端互排斥保证 \(y\in Q_u\setminus Q_v\)。Lebesgue 微分给 \(H(r)/G(r)\to1/2\)。这里先对固定(u,v,j,k)的f、f c_u w及f c_v w使用微分定理；真实两端核及有限bin正thinning给实际(y,u,v,j,k)投影对dy du dv的绝对连续性，再以Fubini迁移到实际记录。无需声称含全部clock的完整record对产品测度绝对连续。Lebesgue点的平均误差对所有包含y且边长趋零的立方体一致趋零，因此A依赖的归一偏移也可使用；不假定来源独立或有密度上界。因此
\[
 \boxed{\Gamma(\xi)=\log2+
 \lim_{\epsilon\downarrow0}\int_{(\epsilon,R_A]}
       \left(\frac{dG(r)}{G(r)}-\frac{dH(r)}{H(r)}\right).}
\tag{3}
\]
每个正 \(\epsilon\) 上质量函数连续、单调，正值后的对数 Stieltjes 公式成立。两个积分须使用相同下端点；不可分别放到零后作无穷相减。也未证明可把此极限与全 \(P\) 积分任意交换。(3) 的极限本身等于已知可积的 \(\Gamma-\log2\)。

候选机制原本是用 \(dH/H\) 抵消父壳增长 \(dG/G\)，再将剩余量只向新增 \(f\) 结算。以下是该机制尚缺的具体一步。

## 2. 外部质量为何必须共同计价

将 \(dG=dG_{\rm in}+dG_{\rm out}\)，其中 out 表示 \(Q_u\cup Q_v\) 外的真实来源，则截断后的 signed 增量精确分成
\[
 \int\frac{dG_{\rm out}}G+
 \int\left(\frac{dG_{\rm in}}G-\frac{dH}H\right).
\tag{4}
\]
第一项为正；外部新增来源不进入 \(H\)。第二项可带符号。故仅以终端捕获质量 \(G_u=\int f c_u w_{x,j}\) 支付每个父的增长，会遗漏完整父质量来自终端外部的部分。反过来要求第一项独立具有根阶费用也可能过强；必须保留同一实际 \(P\) 下第二项的抵消。

实际 matching 只给终点 \(G(R_A)=q_A R_A^n\)，并不给所有虚拟 \(r\) 的 \(G(r)/r^n\) 相同band。归一偏移 \(a_\xi\) 又依实际父与来源而变：\(dA\) 的原生壳预算不提供这些虚拟嵌套族的增长测度支配。若固定来源后逐个重新选择最有利的径向族，会丢失共同 selector。

**唯一缺桥：** 尚无实际 Lebesgue 父中心和原接受权下的共同分配，能把 (4) 的 signed 总增长计给全局来源一次，而保留跨终端的外部质量与内部负项。已有 \(D(y)\le A_n\) 只将这个重复来源负载保留下来，不能删除它。低 common、父外和质量差在实际 \(P\) 中仍全部保留；本轮没有证明它们使上述分配成立。

(3) 是尝试的精确核验，不是新的几何费用界。\(\log2\,R\le S\log2\,X\) 只是分解中的基项，未单独付款。R460 原比较、旧费用及完整未付 channel 均不变；没有新增信用或新余项。

## 3. 实际计算及局限

指定 Python 实跑 **33 项精确断言**：三个连续来源分段常数模型，8个仿射径向区间各自核验增长与符号，端点比依次 \(56/11,28/9,48/13\)。这是原生立方体与连续来源的固定记录插值检查，不是实际接收集合全场或原历史实例。无参数扫描。代码如下。

```python
from fractions import Fraction as F
import sympy as s
y=F(-17,20); left=F(3,40); right=F(37,40)
cells=[(F(-9,10),F(-4,5),0,F(1,2)),
       (F(-4,5),F(-7,10),0,F(1,4)),
       (F(-1,5),F(1,5),1,F(0)),
       (F(7,10),F(9,10),2,F(1,2))]
checks=0
for dens in [(F(5),F(10),F(10)),(F(10),F(5),F(15)),
             (F(15),F(5),F(5))]:
 def GH(r):
  a=y-left*r;b=y+right*r
  p=[max(F(0),min(b,hi)-max(a,lo))*dens[j]
     for lo,hi,j,_ in cells]
  return sum(p),sum(x*c[3] for x,c in zip(p,cells))
 cuts={F(1,100),F(2)}
 for lo,hi,_,_ in cells:
  for edge in (lo,hi):
   for rr in ((y-edge)/left,(edge-y)/right):
    if F(1,100)<rr<F(2):cuts.add(rr)
 cuts=sorted(cuts);g0,h0=GH(cuts[0])
 assert g0==2*h0;checks+=1
 total=F(1)
 for a,b in zip(cuts,cuts[1:]):
  ga,ha=GH(a);gb,hb=GH(b);gm,hm=GH((a+b)/2)
  assert 2*gm==ga+gb and 2*hm==ha+hb;checks+=1
  total*=gb*ha/(ga*hb)
 g,h=GH(F(2));assert 2*total==g/h;checks+=1
 Q=lambda x:s.Rational(x.numerator,x.denominator)
 assert s.simplify(s.logcombine(s.log(2)+s.log(Q(total))
                    -s.log(Q(g/h)),force=True))==0;checks+=1
print('PASS',checks)
```
