# R461：先积父中心的交叠对数账

同一实际 \(P=\Xi_{\rm can,out}\) 与 R460 的软费用 \(C_p\) 全部保留。本稿只检验一个方向：固定终端后先积真实父中心。得到的完整粗价格仍为 \(O(n^2W)\)，未获目标 \(n\,\mathrm{polylog}(n)W\)。

## 1. 正上放的增加项明确保留

固定一端和 bin \(j\)，令
\[
g_{u,j}(y)=f(y)c_u(y)w_{y,j}(m_u),\quad G_{u,j}=\int g_{u,j}\le m_u,
\quad I_{Au}^\beta=\int_{Q_A}g_{u,j}.
\]
父积分域 \(\mathcal A_u\) 保 \(u\notin Q_A\)、\(m_A>K^2m_u\)。定义
\[
H_{u,j}=\int_{\mathcal A_u}\frac{I_{Au}^\beta}{R_A^n}
                    \log\frac{m_A}{I_{Au}^\beta}\,dA.
\]
零交叠按极限取零。R459 单端参考在该域的测度为
\(d\nu_j=S\sigma(dA)\pi_A(dy)\beta_{y,\ell_j}(du)/\ell_j\)，
实际投影 \(P_j\le\nu_j\)。因此准确地
\[
C_e=\sum_j\frac S{\ell_j}\int H_{u,j}\frac{du}{m_u}
       -\Delta_{\rm accept}-\Delta_w, \tag{1}
\]
其中
\[
\Delta_{\rm accept}=\sum_j\int\log(m_A/I^\beta_{Au})\,d(\nu_j-P_j)\ge0,
\qquad
\Delta_w=\sum_j\int-\log w_{y,j}(m_u)\,dP_j\ge0.
\]
故替换接受流为参考平均只是一项有明确增加量的上放，不再称同一接受权的等式。

## 2. 可证的父中心容量及其实际代价

设 \(r=\lambda/q\)。不假定 \(K^2>r\)；同octave无条件给 \(R_u\le2R_A\)。在 \(G=G_{u,j}>0\) 时置 \(p_A=I^\beta_{Au}/G\)。相交父的中心满足
\(\|A-u\|_\infty\le(R_A+R_u)/2\le3R_A/2\)。因此对
\(d\nu(A)=1_{\mathcal A_u,I^\beta>0}R_A^{-n}dA\)，真实变边长径向包络给
\[
\nu(E)\le3^n A_n,\qquad
D_u:=\int p_A\,d\nu\le A_n,\quad A_n=1+n\log(b/a).
\]
第二式先积 \(g/G\)，使用同源中心容量。Jensen 给
\[
\int p_A\log(1/p_A)d\nu
 \le D_u\log(3^nA_n/D_u)\le A_n(n\log3+1).
\]
再由 \(m_A/m_u\le r(b/a)^n\)，得到严格粗界
\[
H_{u,j}\le A_nG_{u,j}
 \left[\log\frac{m_u}{G_{u,j}}+\log r+n\log(b/a)+n\log3+1\right]. \tag{2}
\]

这里来源分母确可共享一次：\(a_j(u)=G_{u,j}/m_u\le1\)，canonical 列恒等式给
\(\int a_jdu\le\ell_jW\)。又 \(|E|\le A_nW/q\)，故
\[
\int a_j\log(1/a_j)du
 \le\ell_jW\left[\log_+\frac{A_n}{q\ell_j}+1\right].
\]
结合(1)–(2)，两个方向分别适用同一上界；软费用
\(C_p\le p_0C_0+p_1C_1\)，因而不另乘2：
\[
C_p\le SN A_n
 \left[\log r+n\log(b/a)+n\log3+\log_+\frac{A_n}{qh}+2\right]W. \tag{3}
\]
这是真实全费用，但阶数不足；除信息增益 \(\sqrt n\) 后仍约 \(n^{3/2}W\)。不列为新增付款。

## 3. 必须共享的外部质量，而非逐终端小源价

不能强求 \(H_{u,j}\lesssim nG_{u,j}\)。完整匹配给出更准确的同父拆分。令
\[
E_{Au}=f(Q_A\setminus Q_u),\qquad T_{Au}=f(Q_u\setminus Q_A).
\]
则
\[
\log\frac{m_A}{m_u}
 =\log(1+E_{Au}/m_u)-\log(1+T_{Au}/m_A). \tag{4}
\]
代入 \(H\) 后，第二项是真实负交叠损失；第一项不能逐个 \(u\) 各收一份 \(W\)。其全局正费用恰为
\[
\int f(x)\sum_j\frac S{\ell_j}\int\frac{du}{m_u}
 \int_{\mathcal A_u}
 \frac{I^\beta_{Au}}{R_A^n}
 \frac{\log(1+E_{Au}/m_u)}{E_{Au}}
 1_{Q_A\setminus Q_u}(x)\,dA\,dx. \tag{5}
\]
\(E=0\) 时该来源积分为零。式(5)仅是 Tonelli，未证明其列有根阶价格。需将它与(4)负项及(1)的两个接受缺额共同控制；单独丢负项所得正列目前只恢复(3)。这正是本方向所缺的共享外源结算，并非提出另一个免费参考流。没有来源密度帽，也未把固定边长薄层公式套到实际选择器。

## 4. 有限核验

本机实际运行18项200位 Arb 区间检查，覆盖 \(n=1,4,16\)、零/相等/不等捕获比例，核 Jensen 与父熵包络方向。它们不是原历史或维度阶数的证明。实际代码：

~~~python
from flint import arb,ctx
ctx.prec=200
count=0
for n in [1,4,16]:
 A=1+n*arb(2).log();B=(3**n)*A
 for cs in [(1,2,3),(1,1,1),(0,1,3)]:
  ps=[arb(c)/(4*3**n) for c in cs]
  D=sum(ps)*B/3
  E=sum([-p*p.log() if not p.is_zero() else arb(0) for p in ps])*B/3
  gap=D*(B/D).log()-E
  assert gap.contains(0) if len(set(cs))==1 else gap.lower()>0
  assert (A*(n*arb(3).log()+1)-E).lower()>0
  count+=2
print("PASS",count)
~~~
