from fractions import Fraction as F
from itertools import product,combinations
from pathlib import Path
import json,sys,platform,time
import sympy as s
ROOT=Path(__file__).resolve().parent
t=s.Symbol('t', positive=True); a=s.Symbol('a', real=True)
checks=0;start=time.perf_counter()
def ck(v):
 global checks
 assert v
 checks+=1
def Q(x): return s.Rational(x.numerator,x.denominator) if isinstance(x,F) else s.Rational(x)
def span(points,k):return max(x[k] for x in points)-min(x[k] for x in points)
def subsets(Z):
 for r in range(len(Z)+1):
  for T in combinations(Z,r):yield T
def ieV(Y,Z,L):
 return sum(((-1)**len(T)*prod(max(F(0),L-span(Y+list(T),k)) for k in range(len(Y[0]))) for T in subsets(Z)),F(0))
def prod(xs):
 v=F(1)
 for x in xs:v*=x
 return v
def rect_measure(lo,hi,Z,tau,normal=None):
 # Partition at every cube boundary; a tangential midpoint identifies coverage exactly.
 dims=len(lo)
 if any(x>=y for x,y in zip(lo,hi)):return F(0)
 endpoints=[sorted({lo[k],hi[k],*[b for z in Z for b in (z[k]-tau/2,z[k]+tau/2) if lo[k]<b<hi[k]]}) for k in range(dims)]
 ans=F(0)
 intervals=[list(zip(e,e[1:])) for e in endpoints]
 for cell in product(*intervals):
  mid=[(x+y)/2 for x,y in cell]
  covered=any(all(abs(mid[k]-z[k])<=tau/2 for k in range(dims)) for z in Z)
  if not covered:ans+=prod(y-x for x,y in cell)
 return ans
def gridV(Y,Z,L):
 n=len(Y[0]);lo=[max(y[k] for y in Y)-L/2 for k in range(n)];hi=[min(y[k] for y in Y)+L/2 for k in range(n)]
 return rect_measure(lo,hi,Z,L)
def ieS(Y,Z,tau):
 n=len(Y[0]);d=max(span(Y,k) for k in range(n))
 if tau<=d:return F(0)
 ans=F(0)
 for i in range(n):
  al=max(y[i] for y in Y);be=min(y[i] for y in Y)
  for sign in (-1,1):
   for T in subsets(Z):
    good=all((be<=z[i]<=be+tau) if sign==1 else (al-tau<=z[i]<=al) for z in T)
    if good:ans+=F((-1)**len(T),2)*prod(max(F(0),tau-span(Y+list(T),k)) for k in range(n) if k!=i)
 return ans
def gridS(Y,Z,tau):
 n=len(Y[0]);lo=[max(y[k] for y in Y)-tau/2 for k in range(n)];hi=[min(y[k] for y in Y)+tau/2 for k in range(n)]
 if any(x>=y for x,y in zip(lo,hi)):return F(0)
 ans=F(0)
 for i in range(n):
  for face in (lo[i],hi[i]):
   Zi=[tuple(z[k] for k in range(n) if k!=i) for z in Z if abs(face-z[i])<=tau/2]
   ans+=rect_measure([lo[k] for k in range(n) if k!=i],[hi[k] for k in range(n) if k!=i],Zi,tau)/2
 return ans
def breaks(Y,Z,L,U):
 n=len(Y[0]);bs={L,U}
 for T in subsets(Z):
  for k in range(n):bs.add(span(Y+list(T),k))
 for k in range(n):
  al=max(y[k] for y in Y);be=min(y[k] for y in Y)
  for z in Z:bs.update((z[k]-be,al-z[k]))
 return sorted(x for x in bs if L<=x<=U)
def exactint(poly,p,l,u):
 ans=0
 for (k,),coef in s.Poly(poly,t).terms():
  e=k-p
  ans+=coef*s.log(Q(u)/Q(l)) if e==-1 else coef*(Q(u)**(e+1)-Q(l)**(e+1))/(e+1)
 return s.expand_log(s.expand(ans),force=True)
def direct1(Y,Z,L,U,p):
 al=max(y[0] for y in Y);be=min(y[0] for y in Y)
 lo=al-U/2;hi=be+U/2
 if lo>=hi:return s.Integer(0)
 bs={lo,hi,al-L/2,be+L/2,(al+be)/2}
 for (z,) in Z:bs.update((z,z-L/2,z+L/2,(z+al)/2,(z+be)/2))
 bs=sorted(x for x in bs if lo<=x<=hi);ans=0
 for l,u in zip(bs,bs[1:]):
  mid=(l+u)/2;rr=max(L,2*(al-mid),2*(mid-be))
  if rr>U or any(rr>=2*abs(mid-z[0]) for z in Z):continue
  if rr==L:ans+=Q(u-l)*Q(L)**(-p)
  else:
   expr=2*(Q(al)-a) if 2*(al-mid)>L else 2*(a-Q(be))
   ans+=s.integrate(expr**(-p),(a,Q(l),Q(u)))
 return s.expand_log(s.simplify(ans),force=True)
def pts(rows):return [tuple(F(x) for x in row) for row in rows]
fixtures=[
 ('initial_1d',[['0']],[['3/4']], '1/2','2'),
 ('fixed_side_base_1d',[['0']],[['3/4']], '1/2','1/2'),
 ('face_tie_1d',[['0']],[['0'],['1']], '1/2','2'),
 ('two_exclusions_1d',[['-1/4'],['1/4']],[['-3/4'],['1']], '1/2','2'),
 ('initial_2d',[['0','0']],[['3/4','0']], '1/2','2'),
 ('coincident_faces_2d',[['0','0'],['1/2','1/4']],[['0','3/4'],['1','1/4']], '1/2','2'),
 ('required_excluded_2d',[['0','0'],['1/2','0']],[['1/2','0'],['1','1']], '1/2','2'),
 ('initial_3d',[['0','0','0']],[['3/4','0','0']], '1/2','2'),
 ('offset_3d',[['0','0','0'],['1/2','1/4','-1/4']],[['1','0','0'],['0','-3/4','1/2']], '1/2','2'),
 ('duplicate_exclusion_3d',[['-1/4','0','0'],['1/4','1/2','0']],[['3/4','0','1/4'],['3/4','0','1/4']], '1/2','2')]
rows=[]
for name,y,z,l,u in fixtures:
 Y=pts(y);Z=list(dict.fromkeys(pts(z)));L=F(l);U=F(u);n=len(Y[0]);V=ieV(Y,Z,L);ck(V==gridV(Y,Z,L));bs=breaks(Y,Z,L,U);pieces=[]
 for lo,hi in zip(bs,bs[1:]):
  nodes=[lo+(hi-lo)*F(k+1,n+1) for k in range(n)]
  points=[]
  for tau in nodes:
   v=ieS(Y,Z,tau);ck(v==gridS(Y,Z,tau));ck(v>=0);points.append((Q(tau),Q(v)))
  poly=s.expand(s.interpolate(points,t));ck(poly==0 or s.degree(poly,t)<=n-1)
  for frac in (F(1,2*n+3),F(2*n+2,2*n+3)):
   tau=lo+(hi-lo)*frac;ck(poly.subs(t,Q(tau))==Q(ieS(Y,Z,tau)));ck(ieS(Y,Z,tau)==gridS(Y,Z,tau))
  pieces.append((lo,hi,poly))
 Es={}
 for p in (n,2*n):
  E=Q(V)/Q(L)**p+sum((exactint(poly,p,lo,hi) for lo,hi,poly in pieces),s.Integer(0));E=s.simplify(E);ck(E.is_nonnegative is True)
  if n==1:ck(s.simplify(E-direct1(Y,Z,L,U,p))==0)
  Es[str(p)]=str(E)
 if any(z in Y for z in Z):ck(V==0 and all(poly==0 for _,_,poly in pieces) and all(s.sympify(v)==0 for v in Es.values()))
 rows.append(dict(name=name,n=n,Y=Y,Z=Z,L=L,U=U,V_L=V,pieces=[dict(lo=l,hi=u,S=str(pol)) for l,u,pol in pieces],E=Es))
# Wrong dV/dt diagnostic: Y={0},Z={3/4},L=1/2,U=2.
# On (3/4,2): V(t)=3/4 is constant but correct new-face influx S=1/2.
ck(ieV(pts([['0']]),pts([['3/4']]),F(1))==F(3,4));ck(ieV(pts([['0']]),pts([['3/4']]),F(3,2))==F(3,4));ck(ieS(pts([['0']]),pts([['3/4']]),F(1))==F(1,2))
out=dict(scope='Exact finite E_p Lebesgue-center envelope checks; no qband field, source mass budget, or original history certification',executable=sys.executable,python=platform.python_version(),sympy=s.__version__,checks=checks,fixtures=rows,wrong_dV_diagnostic='Y=0,Z=3/4,t in (3/4,2): dV/dt=0, S=1/2',compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r461_numeric_check.py',arithmetic='Fraction geometry, SymPy exact interpolation and power/log integration; no Monte Carlo',seconds=time.perf_counter()-start))
(ROOT/'r461_numeric_check.json').write_text(json.dumps(out,default=lambda x:str(x),indent=2)+'\n')
print('Python',platform.python_version(),'SymPy',s.__version__,sys.executable)
for row in rows:print(row['name'],'n=',row['n'],'pieces=',len(row['pieces']),'E=',row['E'])
print('PASS',checks,'exact assertions;',len(rows),'fixed configurations; no scan')
