from fractions import Fraction as F
from math import comb
import json
from functools import lru_cache
BITS=96; UNIT=2**BITS; TERMS=40
@lru_cache(None)
def log_bounds(x):
 if x==1:return (0,0)
 assert x>1
 k=0
 while x>=2:x/=2;k+=1
 def series(v):
  z=(v-1)/(v+1);s=F(0)
  for j in range(TERMS):s+=2*z**(2*j+1)/(2*j+1)
  rem=2*z**(2*TERMS+1)/((2*TERMS+1)*(1-z*z))
  return s,s+rem
 a,b=series(x);c,d=series(F(2));a+=k*c;b+=k*d
 return a.numerator*UNIT//a.denominator,-((-b.numerator*UNIT)//b.denominator)
gamma_checks=0
for exponent in range(-12,13):
 v=F(2)**exponent
 lo,hi=log_bounds(1+v)
 assert F(hi,UNIT)-v/(1+v)<=v*v/2
 gamma_checks+=1
rows=[]
for n,q,base in [(1,2,32),(2,8,128),(4,16,256)]:
 runs=[]
 for N in [base,4*base]:
  den=q**N;lo=hi=psum=0
  for k in range(N+1):
   probnum=comb(N,k)*(q-1)**(N-k);psum+=probnum
   x=F(2*q*k,N)
   if x>1:
    a,b=log_bounds(x);lo+=probnum*a;hi+=probnum*b
  assert psum==den
  elow=F(lo,2*den*UNIT);ehigh=F(hi,2*den*UNIT)
  eta=F(1,N*N)
  actual_lower=(1-eta)**n*elow;actual_upper=(1+eta)**n*ehigh
  # Real distinct atoms y_j=(eta*(j/(N-1)-1/2),0,...,0), weight1/N.
  # Core cube captures every atom; support lies in expanded cube.
  assert 0<=actual_lower<=actual_upper
  var=F(q-1,N)
  # tau log_+ is 1-Lipschitz in current mass for side length1.
  l2lo,l2hi=log_bounds(F(2));targetlo=F(l2lo,2*UNIT);targethi=F(l2hi,2*UNIT)
  # |Ephi(K/(Np))-phi(1)| <= E|mass-1| <= sqrt(var).
  err=max(abs(elow-targethi),abs(ehigh-targetlo))
  assert err*err<=var
  assert targethi-elow<=var
  # One-scale version of the new small-atom terminal deficit certificate.
  geometry_error=((1+eta)**n-1)*targethi+(1-(1-eta)**n)*ehigh
  assert (1+eta)**n*targethi-actual_lower<=var+geometry_error
  runs.append({'N':N,'survival_probability':str(F(1,q)),'clock_time':'log('+str(q)+')','cluster_diameter':str(eta),'expected_reference_phi_interval':[str(elow),str(ehigh)],'actual_distinct_atom_single_scale_phi_interval':[str(actual_lower),str(actual_upper)],'mass_variance':str(var),'display_actual_lower':float(actual_lower),'display_actual_upper':float(actual_upper)})
 rows.append({'n':n,'runs':runs})
print(json.dumps({'status':'PASS','scope':'Exact binomial expectation and certified log intervals; actual distinct microcluster one-scale Phi sandwich; not continuous-window spatial integration','gamma_small_atom_checks':gamma_checks,'bits':BITS,'atanh_terms':TERMS,'rounds':rows},indent=2))
