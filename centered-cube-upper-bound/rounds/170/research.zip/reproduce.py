#!/usr/bin/env python3
"""Verify final bundle hashes and replay using the recorded local dependencies."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
for name,digest in json.loads((HERE/'manifest.json').read_text())['sha256'].items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
print('Bundle hashes PASS',flush=True)
if a.verify_only:raise SystemExit
if a.output_dir is None:p.error('--output-dir required')
out=a.output_dir.resolve();out.mkdir(parents=True,exist_ok=True);assert out!=HERE
def clean(z):
    if isinstance(z,dict):return {k:clean(v) for k,v in z.items() if k not in ('wall_seconds','elapsed_seconds')}
    if isinstance(z,list):return [clean(v) for v in z]
    return z
receipt={}
for name in ['pair_reserve_probe','pair_certificate','high_column_check','filtered_boundary_check']:
    code="""from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('replay_module',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.HERE=Path(sys.argv[2]);m.main()
"""
    with (out/(name+'.log')).open('w') as log:
        subprocess.run([sys.executable,'-B','-c',code,str(HERE/(name+'.py')),str(out)],stdout=log,stderr=subprocess.STDOUT,check=True)
    assert clean(json.loads((HERE/(name+'.json')).read_text()))==clean(json.loads((out/(name+'.json')).read_text())),name
    receipt[name]={'all_mathematical_fields_identical':True};print(name,'PASS',flush=True)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
