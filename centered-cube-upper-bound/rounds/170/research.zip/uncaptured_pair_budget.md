# R170：high 来源转移的真实列收缩与未捕获储备的加权接缝

状态：得到一个保留原 `e_t,Z_t`、完整外 `beta` 的来源列收缩，及其接近等号时的共同输入几何。它不是已付的 raw 分支。本稿不重报 R169 标量门，也不将未捕获次概率的定义登记为预算。原剩余 `sqrt(n) B F>q−N` 的加权列仍未闭合。只用本轮合同、冻结 R169 结果，以及合同引用的 R128 RT4–6；没有外部定理、数值优化、Git 或他人文件修改。

## 1. 原行和真实来源转移

固定原 `(omega,V,x,j,t)`，保持相同的接收选择器、共同 `q`、来源 `nu<=beta<=f dx`。写

    p_y=K1(x-y), k_u=K0(x-u), QJ=Jnu(x),
    e_y=e_{y,t}, w_yu=w_t(y,u), Z_y=Z_{y,t},
    H_y=1{p_y e_{y,g}>=2Kq}.

原 t 资格保证 `e_y>=e_{y,g}`。只在满足这一资格的 y 上令 H 非零；还可附加原 middle、history 等资格，它们只减小以下核。定义在 `e_y>0` 的真实高行转移

    P(y,du)=H_y 1_{Z_y}(u) w_yu nu(du)/e_y.              (UP1)

其他行定义为零。它是原 Pi 的带门子核，不重新选择支持、尺度、终端或归一化。一般 `Z_y(u)!=Z_u(y)`，不假定对称或可逆。全体源总质量不归一为 1。

**命题：完整外 beta 的列收缩。** 对任意非负可测函数 h(u)，

    int beta(dy) int P(y,du) h(u)
       <= (1/(2K)) int h(u) nu(du).                    (UP2)

证明：high 与 `e_t>=e_g` 给 `H_y/e_y<=H_y p_y/(2Kq)`；原 `0<=w<=1`，FIRST 与 `beta<=f dx` 给 `int p_y beta(dy)<=q`。Tonelli 后，nu 的每列密度满足

    int H_y 1_Zy(u) w_yu/e_y beta(dy)
      <= (1/(2Kq)) int p_y beta(dy)
      <= 1/(2K).

不需要移动 x 积分，也没有用到坐标独立性。`QJ=0` 的来源行原本为零；UP2 不涉及 alpha 的除法。bad 子核、任意额外 `[0,1]` 交通门仍满足同一列上界。

由于 `nu<=beta`，在同一固定行上还有真实正算子不等式

    beta P^m <= (2K)^(-m) nu, m>=1.                    (UP3)

归纳时 `nu P<=beta P<=nu/(2K)` 即可。若 `2K>1`，相应算子级数在 L1(beta) 上有几何费用；这只是来源转移工具，不是允许把原交通多次转置。每次转置的 good、alpha、rho、时间资格都需重新匹配，当前没有这种匹配命题。

## 2. 精确列密度和接近极值的共同输入几何

UP2 有比直接丢到 1/(2K) 更强的、可用于极值分析的精确版本。令

    M_x(dy)=p_y beta(dy)/q,             M_x(total)<=1,
    eta_y=2Kq/(p_y e_y) on H_y=1,       0<eta_y<=1,
    eta_y=0 on H_y=0.

记 UP1 的列密度为 `c_t(u)=(d(beta P)/dnu)(u)`，则

    2K c_t(u)=int M_x(dy) H_y eta_y 1_Zy(u) w_yu.       (UP4)

这保留同一完整输入 q 和同一当前核 p；M 是次概率，不是逐来源另选的最大核。逐列亏损具有准确非负分解

    1−2K c_t(u)
      = [1−M_x(total)]
        + int M_x(dy) (1−H_y)
        + int M_x(dy) H_y(1−eta_y)
        + int M_x(dy) H_y eta_y (1−1_Zy(u))
        + int M_x(dy) H_y eta_y 1_Zy(u)(1−w_yu).        (UP5)

因此若某列满足 `2K c_t(u)>=1−epsilon`，以下每项都至多 epsilon：完整输入中 beta 的当前核质量亏损、当前 p-beta 测度下的非 high 质量、high 饱和度亏损、原支持亏损、核重叠亏损。尤其不能同时让列接近饱和并任意配置远离 u 的外来源。

更具体地，原 `xi=c_j t/b`，定义实际坐标重叠损失

    L_t(y,u)=sum_i [log(xi/C((y_i-u_i)/b))]_+,
    w_yu=exp(−L_t(y,u)).

对每个 `r>0`，UP5 严格推出

    int M_x(dy) H_y eta_y 1_Zy(u) 1{L_t(y,u)>=r}
       <= [1−2K c_t(u)]/(1−exp(−r)).                   (UP6)

这是一致的来源几何陈述，允许任意相关 nu。它控制的是真实软重叠损失，不把阈值计数差 delta 偷换为 L_t；接近阈值的许多坐标可以有很小总损失，因此不能由 UP6 免费推出 delta=O(sqrt(n))。

UP4–6 给出了下一步极值分析的明确对象：危险的加权列如果还接近无权列极值，其外 y 必须同时接近当前 FIRST 质量饱和、high 饱和、原 Z 支持及高软重叠。不能分别取这些条件的来源上确界后仍声称保留这一共同几何。

## 3. 同 alpha 的未捕获来源核：保留 bad-u 因子

令

    A_y=alpha_y QJ/D=q−int U_y dnu/D,
    c_y(u)=U_y(u)/(D k_u),
    R=q−int k_u dnu(u)>=0.

实际 s>0，故 k_u>0。原同 alpha 给

    A_y=R+int k_u(1−c_y(u))dnu(u).                      (UP7)

当 A_y>0，定义真实未捕获次概率

    mu_y(du)=k_u(1−c_y(u))nu(du)/A_y.

它保留 y 依赖，缺失质量为 R/A_y。在实际 bad 源上 c_y=0，故对任意 h>=0，

    A_y^(-1) int_bad h(u) Pi_y,t(du)
       = e_y^(-1) int_bad∩Zy h(u) w_yu/k_u mu_y(du).   (UP8)

当 A_y=0，UP7 中所有非负项为零，实际 bad 的 nu 质量为零，故这一好坏两源交通为零。这不等于说 R=0 时 alpha=0。

定义含原 alpha 的源核

    L(y,du)=H_y 1_bad_y(u) Pi_y,t(du)/A_y, A_y>0,
    L=0 otherwise.

UP2 直接给一个有指定来源权的真实列界：

    int A_y beta(dy) L(y,du) <= nu(du)/(2K).            (UP9)

UP9 的 `A_y beta(dy)` 不能替成 beta，也不能把它当成免费新来源。它说明 high 列收缩和未捕获储备在哪一种权下兼容；恰好缺少的就是 raw 的好源系数相对 A_y 的控制。

## 4. raw 的准确加权列和最具体未证位置

在原正余域记

    d_y(v)=[1−D k_v/(TDelta_y(v))]_+,
    G_y(v)=TDelta_y(v)d_y(v)^2/w_g(y,v).

零分母的零交通行不造商。原同 alpha 的数值二次包络是

    A_y rho_y(v)
      <= QJ TDelta_y(v)d_y(v)^2/(4D J_v).               (UP10)

与 `chiJ=J_v/(3Q_v)` 及原 good `p_y/Q_v<=K/w_g(y,v)` 合用，hard 源尚未计价的原行满足

    I_j,t(x) <= K QJ/(12D) int nu(du) C_x,j,t(u),       (UP11)

其中可完全显式写出的实际加权列是

    C_x,j,t(u)
      = int beta(dy) H_y 1_bad_y(u) 1_Zy(u) w_yu
          /(A_y e_y)
          * int_good_y Pi_y,t(dv) G_y(v) delta_t(v,u).  (UP12)

A_y=0 行按上节置零；其余原正交通门、middle 和 R169 补集门可原样放入两积分中。上式不是把 C 宣称为已知有界范数，而是明确待证的列。UP8 等价地把其中的 `Pi_bad/A_y` 写为 `w/(e k) mu_y`，未消失的低 `k_u/w_yu` 代价仍在。

用 UP4 的同一 M_x 后，准确得到

    C_x,j,t(u)
      = (1/(2K)) int M_x(dy) H_y eta_y
          1_bad_y(u) 1_Zy(u) w_yu
          * [int_good_y G_y(v)delta_t(v,u)Pi_y,t(dv)]/A_y.
                                                               (UP13)

这同时保留了共同输入、high 饱和度、软重叠、alpha 储备与好源位置。无权列 UP2 不能控制最后一行的 `G delta/A_y`：它依 y 和 u；固定源测试函数的列收缩不允许将其作为一个共同 h(u) 代入。低 A_y 尤其不能通过 UP9 隐去。

一个足够且费用明确的下一步命题，是在原剩余域对所有实际行证明

    int nu(du) C_x,j,t(u) <= C_* sqrt(n) n^{o(1)}.      (UP14, unproved)

这里 C_* 必须是已知常数或已支付参数费用，不可定义为左端上确界。也可直接证明对应 `QJ dx dt/t` 积分上界，无需更强的逐行 UP14，但必须保留原 beta 与 q、所有 x 依赖。

若 UP14 成立，UP11 恢复原 raw 的费用严格为

    [8 Lambda K log(2)/(9D)] C_* sqrt(n)n^{o(1)} W_beta.

顺序是：hard 帽 16/3 只一次，外 2Lambda；UP11、UP14 先在固定 x 行完成；然后共同 t 窗上放到 [a,b]，保留原唯一 `j(x)` 合并 j，再付 log2；最后 `int QJ dx=||nu||`，`E sum||nu||<=W_beta`。若只获得各 j 分别不一致的界，则不能省 j 菜单费用。本文尚未证明 UP14，也没有支付其补集。

可检验的桥接任务应直接作用于 UP13：利用 UP5–6 的同时饱和几何，控制同一 y,u,v 上的 `G_y(v)delta/A_y`；或者构造一个能承接该系数的原来源势并证明转移不等式，随后才可用 UP3 求和。尚未证明任何一种桥接。没有人为折减原交通，也没有借用已消费负项。

## 5. 对称核与 K0 排序：结构工具的有效边界

R128 RT4–6 明确：固定 x,j 后，`g=sqrt(LR)`、`tau=a/c_j`、`h=g exp(−u0/n)`、`T=c_j^(n/2)/(g^n sqrt(1+log n))` 都不依外 y。因 w_t(y,u) 只依坐标差的绝对值，

    a(y,u)=TDelta_y(u)/D=a(u,y)>=0.

忽略 good 截断的未捕获密度为 `(k_u−a(y,u))_+`。乘外 k_y 后令

    L0(y,u)=k_y(k_u−a)_+.

若 `k_u=M>=m=k_y`，则

    L0(y,u)−L0(u,y)
      = a(M−m),       0<=a<=m;
      = m(M−a),       m<a<M;
      = 0,            a>=M.                            (UP15)

共同对称部分是 `M(m−a)_+`，其余是沿 k 增大方向的非负流。这给出确定的几何排序，而非对称假设。

原 good 截断还产生准确附加项

    k_y k_u(1−c_y(u))
      = L0(y,u)+k_y min(a,k_u)1_bad_y(u).               (UP16)

因此原全核不由 UP15 变成可逆核；beta!=nu 时外/内来源也不同。归一化 A_y、实际 Z_y、e_y 及 good-v 权都须保留。正 raw 不能仅因 UP15 存在反对称部分就使用有符号消去。

另有对实际 bad 边的独立排序：由 `Q_u>=p_u/3`，

    bad_y(u) => p_u<(3/K) p_y w_g(y,u)<=(3/K)p_y.       (UP17)

若所选原 K>3，坏源边严格沿 p 下降；这与 UP15 的 K0 上升排序是两种不同量，尚无可免费比较的共同势。本文只陈述条件 UP17，不改变既定 K。它可作为 UP13 加权桥接的结构输入，不能单独给出原交通的路径求和价。

## 6. 有界检查点

已证明：UP2 的完整 beta 真实 high-Pi 列收缩；UP4–6 的精确饱和亏损和软重叠几何；UP9 指定权下的 alpha 核列界；UP15–17 的源对排序。UP7–13 交叉核了父稿未捕获恒等式，目的是固定加权接缝，不重报旧付款。

未证明：UP14 或等价的实际 receiver 积分预算。特别是无权列收缩不等于 `sqrt(n)BF>q−N` 补集的 raw 收缩；beta=nu、R=0 和很小 A_y 都保留。当前没有新增 FULL/L1/history 正分支覆盖结论。到此保存结构稿，交由主代理与独审接续，不继续反例搜索或给未付项另起一个可付名称。
