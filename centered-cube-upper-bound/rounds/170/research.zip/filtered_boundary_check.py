#!/usr/bin/env python3
"""Finite algebra checks for soft_threshold_energy (6),(8),(11), not FULL.

Fraction checks decide support/weights/jumps exactly. mpmath GL on every
continuous threshold/deletion interval checks the complete signed ledger.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
SOURCE_DIR=Path(__file__).resolve().parent
HERE=SOURCE_DIR
mp.mp.dps=60
NODES={}

def st(x):return str(x.numerator) if x.denominator==1 else str(x)
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def weights(case,t,active,conv=lambda x:x):
    return [conv(case['nu'][i])*prod(min(conv(F(1)),conv(c)/t) for c in case['C'][i]) if i in active else conv(F(0)) for i in range(case['N'])]
def prod(xs):
    z=1
    for x in xs:z*=x
    return z

def support(c,t,side='post'):
    return [i for i in range(c['N']) if i not in c['deletions'] or (t<c['deletions'][i] if side=='post' else t<=c['deletions'][i])]

def state(c,t,active):
    a=weights(c,t,active);e=sum(a,F(0));p=[v/e for v in a]
    k=[sum(v<t for v in row) for row in c['C']]
    ff=sum((c['A'][i]*p[i] for i in range(c['N'])),F(0))
    return a,e,p,k,ff

def defects(c,p,k,active):
    # A vanishes outside terminal G, including every deletable source.
    conv=mm if isinstance(p[0],mp.mpf) else lambda x:x
    AA=[conv(v) for v in c['A']]
    G,B=c['G'],c['B'];E=[i for i in active if i not in G and i not in B]
    zero=p[0]*0
    PG=sum((p[i] for i in G),zero);PE=sum((p[i] for i in E),zero)
    AK=sum((p[i]*AA[i]*k[i] for i in G),zero);AG=sum((p[i]*AA[i] for i in G),zero)
    KG=sum((p[i]*k[i] for i in G),zero);KE=sum((p[i]*k[i] for i in E),zero)
    GG=PG*AK-AG*KG;GE=PE*AK-AG*KE
    HZ=zero;rev=zero;eta=zero;raw=zero;ndel=zero
    for v in G:
      for u in B:
       D=k[v]-k[u];pos=max(D,0);neg=max(-D,0);mass=p[v]*p[u];ps=conv(c['Psi'][v][u]);av=AA[v];ee=conv(c['eta'][v][u])
       raw+=ps*(av*ee*pos-neg)*mass
       HZ+=(1-ps)*av*D*mass
       rev+=ps*(1-av)*neg*mass
       eta+=ps*av*(1-ee)*pos*mass
    for v in E:
      for u in B:ndel+=max(k[u]-k[v],0)*p[v]*p[u]
    return [raw-ndel,GG,GE,HZ,rev,eta,ndel]

def build(label,stage,N,n,seed,delete=False,eta_one=True,all_psi=False):
    ng=max(2,N//3);nb=max(1,N//3);G=list(range(ng));B=list(range(ng,ng+nb));E=list(range(ng+nb,N))
    pool=list(map(F,['1/5','7/20','1/2','11/20','13/20','3/4','17/20','1','6/5']))
    C=[[pool[(i*5+j*3+seed+(j//3))%len(pool)] for j in range(n)] for i in range(N)]
    if label=='no_delete_full_pair':
      C[0]=[F(1,5)]*n;C[1]=[F(3,10)]*n;C[ng]=[F(9,10)]*n
    # Explicit anti-order control: high A has smaller score than low A.
    if label=='no_delete_anti_order':C[0]=[F(9,10)]*n;C[1]=[F(3,10)]*n
    nu=[F(i+1,N*(N+1)//2) for i in range(N)]
    aval=[F(1),F(1,4),F(3,4),F(0),F(1,2)]
    A=[aval[i%len(aval)] if i in G else F(0) for i in range(N)]
    dt=[F(3,5),F(13,20),F(4,5),F(9,10)]
    deletions={i:dt[(i+seed)%len(dt)] for i in E} if delete else {}
    if label=='eta_defect_simultaneous_deletion':
      for i in E[:2]:deletions[i]=F(13,20)
    # With no deletion E survives to terminal, and is part of G with A=0.
    if not delete:G+=E
    Psi=[[F(int(all_psi or (v*3+u*5+seed)%4!=0)) for u in range(N)] for v in range(N)]
    eta=[[F(1) if eta_one else F(1+(v+u+seed)%3,4) for u in range(N)] for v in range(N)]
    return dict(label=label,stage=stage,N=N,n=n,nu=nu,C=C,A=A,G=G,B=B,deletions=deletions,Psi=Psi,eta=eta,lo=F(1,2),hi=F(1),g=F(1))

def integrate(c,order,dps=60):
    mp.mp.dps=dps
    if (order,dps) not in NODES:NODES[(order,dps)]=mp.gauss_quadrature(order,'legendre')
    nodes,ww=NODES[(order,dps)];total=[mp.mpf(0)]*7
    cuts=sorted(set([c['lo'],c['hi']]+[v for row in c['C'] for v in row if c['lo']<v<c['hi']]+list(c['deletions'].values())))
    for l,r in zip(cuts[:-1],cuts[1:]):
      mid=(l+r)/2;active=support(c,mid);k=[sum(v<mid for v in row) for row in c['C']]
      for node,w in zip(nodes,ww):
       t=(mm(l)+mm(r))/2+node*(mm(r)-mm(l))/2;a=weights(c,t,active,mm);e=sum(a);p=[v/e for v in a]
       dd=defects(c,p,k,active);factor=w*(mm(r)-mm(l))/(2*t)
       for j in range(7):total[j]+=factor*dd[j]
    return total

def check(c,reference=False):
    mp.mp.dps=60
    cuts=sorted(set([c['lo'],c['hi']]+[v for row in c['C'] for v in row if c['lo']<v<c['hi']]+list(c['deletions'].values())))
    derivative=[];negative_counts=[0,0,0];local_ledger=[]
    for l,r in zip(cuts[:-1],cuts[1:]):
      t=(l+r)/2;active=support(c,t);a,e,p,k,ff=state(c,t,active)
      ep=-sum((a[i]*k[i] for i in active),F(0));fp=sum((c['A'][i]*(-k[i]*a[i]*e-a[i]*ep)/e**2 for i in active),F(0))
      cov=sum((p[i]*c['A'][i]*k[i] for i in active),F(0))-ff*sum((p[i]*k[i] for i in active),F(0))
      derivative.append(-fp==cov)
      ds=defects(c,p,k,active)
      # Continuous form of (8): raw=-F'-(GG+GE+HZ+rev+eta)-Ndel.
      local_ledger.append(ds[0]==cov-sum(ds[1:]))
      for j in range(3):negative_counts[j]+=int(ds[j+1]<0)
    initial=state(c,c['lo'],support(c,c['lo']))[4];terminal=state(c,c['hi'],support(c,c['hi'],'pre'))[4]
    jumps=[];joint=initial;inverses=F(0)
    for t in sorted(set(c['deletions'].values())):
      a0,e0,p0,k0,f0=state(c,t,support(c,t,'pre'));a1,e1,p1,k1,f1=state(c,t,support(c,t,'post'));d=e0-e1
      j=f1-f0;joint+=j;inverses+=1/e1-1/e0
      jumps.append(dict(t=st(t),removed=[i for i,v in c['deletions'].items() if v==t],jump=st(j),rhs_Fpre_d_over_e=st(f0*d/e1),eq6_exact=j==f0*d/e1,inverse_jump=st(1/e1-1/e0)))
    wg=[prod(min(F(1),v/c['g']) for v in row) for row in c['C']];wl=[prod(min(F(1),v/c['lo']) for v in row) for row in c['C']]
    ratio=max(wl[i]/wg[i] for i in range(c['N']) if c['A'][i]>0)
    CA=sum((c['A'][i]*wg[i]*c['nu'][i] for i in range(c['N'])),F(0));eg=sum((wg[i]*c['nu'][i] for i in support(c,c['g'])),F(0))
    el=state(c,c['lo'],support(c,c['lo']))[1];cap=ratio*CA/eg;tel=ratio*CA*(1/el+inverses)
    for jump in jumps:
      jump['pointwise_bound_exact']=F(jump['jump'])<=ratio*CA*F(jump['inverse_jump'])
    vals32=integrate(c,32);vals64=integrate(c,64);rhs=mm(initial-terminal+sum((F(j['jump']) for j in jumps),F(0)))-sum(vals64[1:])
    ref=None
    if reference:
      vals96=integrate(c,96,80);rhs96=mm(initial-terminal+sum((F(j['jump']) for j in jumps),F(0)))-sum(vals96[1:])
      ref=dict(dps=80,GL_order=96,max_abs_GL64_96=mp.nstr(max(abs(a-b) for a,b in zip(vals64,vals96)),12),eq8_abs_residual=mp.nstr(abs(vals96[0]-rhs96),12))
    assumptions=(all(v>0 for v in c['nu']) and all(v>0 for row in c['C'] for v in row) and all(F(0)<=v<=F(1) for v in c['A']) and not(set(c['G'])&set(c['B'])) and all(c['A'][i]==0 for i in range(c['N']) if i not in c['G']) and not(set(c['deletions'])&(set(c['G'])|set(c['B']))))
    out=dict(label=c['label'],stage=c['stage'],sources=c['N'],dimension=c['n'],continuous_intervals=len(cuts)-1,
       exact_checks=dict(prototype_assumptions=assumptions,eq6_derivative_count=len(derivative),eq6_derivative_all=all(derivative),eq8_pointwise_count=len(local_ledger),eq8_pointwise_all=all(local_ledger),eq6_deletion_count=len(jumps),eq6_deletion_all=all(j['eq6_exact'] for j in jumps),eq11_initial_bound=initial<=ratio*CA/el,eq11_joint_bound=joint<=cap,eq11_telescoping_bound=joint<=tel<=cap,each_deletion_bound=all(j['pointwise_bound_exact'] for j in jumps)),
       boundary_exact=dict(initial=st(initial),terminal=st(terminal),initial_plus_jumps=st(joint),actual_weight_ratio=st(ratio),C_A=st(CA),e_g=st(eg),cap=st(cap),slack=st(cap-joint),telescoping_upper=st(tel)),
       boundary_decimal=dict(initial_plus_jumps=float(joint),actual_weight_ratio=float(ratio),cap=float(cap),joint_over_cap=float(joint/cap)),jumps=jumps,
       integrated=dict(zip(['R_signed','C_GG','C_GE','H_Z','R_reverse','R_eta','N_del'],[mp.nstr(v,28) for v in vals64])),
       signed_balance=dict(rhs=mp.nstr(rhs,28),eq8_abs_residual=mp.nstr(abs(vals64[0]-rhs),12),max_abs_GL32_64=mp.nstr(max(abs(a-b) for a,b in zip(vals32,vals64)),12)),
       negative_defect_midpoint_counts=dict(zip(['C_GG','C_GE','H_Z'],negative_counts)),high_precision_reference=ref,
       input=dict(nu=[st(v) for v in c['nu']],C=[[st(v) for v in row] for row in c['C']],A=[st(v) for v in c['A']],G=c['G'],B=c['B'],deletions={str(i):st(t) for i,t in c['deletions'].items()},
          Psi_GB=[[int(c['Psi'][v][u]) for u in c['B']] for v in c['G']],eta_GB=[[st(c['eta'][v][u]) for u in c['B']] for v in c['G']],lo=st(c['lo']),hi=st(c['hi']),g=st(c['g'])))
    return out

def main():
    menu=[('no_delete_full_pair','initial',4,1,0,False,True,True),('no_delete_anti_order','initial',5,3,1,False,True,False),
          ('threshold_and_deletion','pressure',6,4,2,True,True,False),('eta_defect_simultaneous_deletion','pressure',9,5,1,True,False,False),
          ('expanded_12x8','expanded',12,8,3,True,False,False),('expanded_18x16','expanded',18,16,4,True,False,False),('expanded_24x32','expanded',24,32,5,True,False,False)]
    rows=[check(build(*args),reference=i in (1,3)) for i,args in enumerate(menu)]
    checks=[v for r in rows for k,v in r['exact_checks'].items() if not k.endswith('count')]
    inp=SOURCE_DIR/'soft_threshold_energy.md'
    out=dict(scope='Finite prototype algebra and boundary accounting only. No FULL geometry, same-alpha realization, history, raw spatial payment or general coverage certified.',
      convention='Terminal G/B never deleted; A fixed in [0,1] supported on G; Z only decreases; all nonterminal E deleted before g. No sorting assumed; Psi fixed pair mask.',
      formula_source=dict(path=inp.name,sha256=hashlib.sha256(inp.read_bytes()).hexdigest()),cases=rows,
      summary=dict(cases=len(rows),stages=['initial','pressure','expanded'],exact_boolean_checks=len(checks),exact_all=all(checks),continuous_derivative_checks=sum(r['exact_checks']['eq6_derivative_count'] for r in rows),pointwise_signed_checks=sum(r['exact_checks']['eq8_pointwise_count'] for r in rows),deletion_event_checks=sum(r['exact_checks']['eq6_deletion_count'] for r in rows),max_eq8_abs_residual=max(float(r['signed_balance']['eq8_abs_residual']) for r in rows),max_GL32_64_abs_difference=max(float(r['signed_balance']['max_abs_GL32_64']) for r in rows)),
      limitations=['Fraction certifies only the finite generated prototype values and algebra.','mpmath quadrature is not an interval certificate.','actual e^M is a rational weight ratio, not an assumed geometric exponential bound.','Every signed defect is retained; no A/k or G/E sorting imposed.','No terminal source deletion, support creation, time-varying A/Psi or endpoint deletion tested.'])
    HERE.mkdir(parents=True,exist_ok=True);(HERE/'filtered_boundary_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary'],indent=2))
if __name__=='__main__':main()
