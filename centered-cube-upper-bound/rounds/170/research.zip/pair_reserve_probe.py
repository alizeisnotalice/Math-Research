#!/usr/bin/env python3
"""R170 finite atomic necessary-row diagnostics. No FULL/L1/history assertion.

Pi uses the frozen source support Z=all. Its weights and normalization at fixed
(y,xi) do not depend on the receiver x. Good/rho/gates do depend on x.
"""
from pathlib import Path
from fractions import Fraction
import importlib.util,json,hashlib,math
SOURCE_DIR=Path(__file__).resolve().parent
HERE=SOURCE_DIR
R168=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint')
R169=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round169_20261016_final_checkpoint')
spec=importlib.util.spec_from_file_location('r170_frozen_tools',R168/'middle_source_lp.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
np,mp,old=prior.np,prior.mp,prior.old

def arr(g,key):return np.array(g[key])
def time_observable(g,nu,q,rho,xi,Bbeta):
    C=arr(g,'C');wt=np.prod(np.minimum(1.,C/xi),axis=1);ks=np.sum(C<xi,axis=1)
    et=float(wt@nu);Pi=wt*nu/et;bad=~arr(g,'good').astype(bool);good=~bad
    K0=arr(g,'K0');A=arr(g,'A');J=arr(g,'J');Q=arr(g,'Q');wg=arr(g,'wg')
    QJ=float(J@nu);Ry=q-float(arr(g,'U')@nu)/g['D'];N=float(K0@nu);Rc=q-N
    dv=np.where(A>0,np.maximum(1-g['D']*K0/np.where(A>0,A,1),0),0)
    bb=float(K0[bad]@nu[bad]);penalty=g['D']*bb*J/(QJ*np.where(A>0,A,1));badcap=np.maximum(dv-penalty,0)
    xy=np.array([float(Fraction(v))-float(Fraction(y)) for v,y in zip(g['xq'],g['yq'])])
    Ky=float(old.kernel_np(g['s'],g['Hhat'],xy[None,:])[0])
    Fy=A*dv**2/(Ky*wg);gate=np.sqrt(g['n'])*Bbeta*Fy/Rc if Rc>0 else np.full(len(A),float('inf'))
    vals=np.zeros(11);pairs=[]
    for v in range(len(nu)):
      for u in range(len(nu)):
       de=max(int(ks[v]-ks[u]),0)
       if not good[v] or not bad[u] or de==0 or rho[v]<=0:continue
       base=float(J[v]/(3*Q[v])*de*Pi[v]*Pi[u]);actual=float(rho[v])*base
       lowc=g['D']*K0[u]*J[v]*et/(A[v]*QJ*wt[u]*de)
       lc_ratio=lowc/((4*(g['n']+1)**2/(3*g['n']))*dv[v]**2)
       vals+=np.array([actual,dv[v]*base,badcap[v]*base,actual*(gate[v]<=1),actual*K0[u]/wt[u],actual*Pi[u],actual*lc_ratio,actual*gate[v],actual*(lc_ratio<1),base*min(dv[v],penalty[v]),actual*(K0[u]*nu[u]/Ry)/Pi[u]])
       pairs.append(dict(v=v,u=u,delta=de,Pi_v=float(Pi[v]),Pi_u=float(Pi[u]),kappa_u=float(K0[u]/wt[u]),lowc_ratio=float(lc_ratio),residual_gate_ratio=float(gate[v]),score_density=actual,Gamma_over_Pi=float(et*K0[u]/(Ry*wt[u]))))
    mean=float(ks@Pi);var=float((ks**2)@Pi)-mean**2;cov=float((bad*ks)@Pi)-float(Pi[bad].sum())*mean
    return vals,dict(mean_k=mean,variance_k=var,cov_bad_k=cov,xi=xi,k=ks.tolist(),wt=wt.tolist(),et=et,Pi=Pi.tolist(),Gamma_bad=(np.where(bad,K0*nu/Ry,0)).tolist(),Gamma_total=bb/Ry,pairs=pairs)

def integrate(g,nu,q,rho,Bbeta,lo,hi,order):
    cuts=sorted(set([lo,hi]+[float(c) for c in arr(g,'C').ravel() if lo<c<hi]))
    nodes,weights=np.polynomial.legendre.leggauss(order);tot=np.zeros(11)
    for a,b in zip(cuts[:-1],cuts[1:]):
      aa,bb=math.log(a),math.log(b)
      for z,w in zip(nodes,weights):tot+=float(w)*(bb-aa)/2*time_observable(g,nu,q,rho,math.exp((aa+bb)/2+z*(bb-aa)/2),Bbeta)[0]
    labels=['original_rho_chiJ_Pi2_delta','no_alpha_rho_d','bad_reserve_only_rho_cap','residual_gate_paid_score','score_times_kappa_u','score_times_Pi_bad_u','score_times_lowc_ratio','score_times_residual_gate_ratio','lowc_passing_score','bad_reserve_only_removed_score','Gamma_replaced_bad_score']
    out=dict(zip(labels,map(float,tot)))
    I=tot[0]
    out.update(positive_score=bool(I>0),paid_fraction=float(tot[3]/I) if I>0 else None,unpaid_fraction=float(1-tot[3]/I) if I>0 else None,
       traffic_weighted_kappa_u=float(tot[4]/I) if I>0 else None,traffic_weighted_Pi_bad_u=float(tot[5]/I) if I>0 else None,
       traffic_weighted_lowc_ratio=float(tot[6]/I) if I>0 else None,traffic_weighted_residual_gate_ratio=float(tot[7]/I) if I>0 else None,
       lowc_passing_fraction=float(tot[8]/I) if I>0 else None,
       Gamma_replaced_over_original_score=float(tot[10]/I) if I>0 else None,
       bad_reserve_only_fractional_reduction=float(tot[9]/tot[1]) if tot[1]>0 else None,
       all_alpha_fractional_reduction=float(1-I/tot[1]) if tot[1]>0 else None)
    return out

def record(label,stage,g,nu,q,lam,slot=0.,status='finite necessary model'):
    nu=np.array(nu);good=arr(g,'good').astype(bool);bad=~good;K0=arr(g,'K0');A=arr(g,'A');J=arr(g,'J');U=arr(g,'U');D=g['D']
    N=float(K0@nu);QJ=float(J@nu);Ry=q-float(U@nu)/D;alpha=D*Ry/QJ
    rho=np.where(good&(A>0),np.maximum(1-(D*K0+alpha*J)/np.where(A>0,A,1),0),0)
    bb=float(K0[bad]@nu[bad]);goodres=float(np.where(good,K0-U/D,0)@nu)
    xy=np.array([float(Fraction(v))-float(Fraction(y)) for v,y in zip(g['xq'],g['yq'])]);Ky=float(old.kernel_np(g['s'],g['Hhat'],xy[None,:])[0]);Bbeta=N+slot*Ky
    lo=.5;hi=min(g['h'],g['zg']);ints={}
    for name,l,h in [('original_threshold_window',lo,hi),('certificate_subwindow',.51,.53)]:
      if h<=hi:
       aa=integrate(g,nu,q,rho,Bbeta,l,h,48);bb96=integrate(g,nu,q,rho,Bbeta,l,h,96)
       ints[name]=dict(bounds=[l,h],GL96=bb96,max_GL48_96_abs_difference=max(abs(aa[k]-bb96[k]) for k in aa if isinstance(aa[k],float) and aa[k] is not None))
    g=dict(g)
    frozen_dx=np.array([[float(Fraction(x))-float(Fraction(z)) for x,z in zip(g['xq'],row)] for row in g['positions']])
    for key,ss,scale in [('F_s_a',g['s'],g['a']),('F_s_b',g['s'],g['b']),('F_1_a',1.,g['a']),('F_1_b',1.,g['b'])]:
      if key not in g:g[key]=old.kernel_np(ss,scale,frozen_dx).tolist()
    rb=prior.common_readback({k:np.array(v) if isinstance(v,list) and k not in ['xq','yq','positions'] else v for k,v in g.items()},nu,q,lam,0,1)
    future=[];dx=np.array([[float(Fraction(x))-float(Fraction(z)) for x,z in zip(g['xq'],row)] for row in g['positions']])
    for ss in np.linspace(g['s'],1,16):
      for LL in np.linspace(g['a'],g['b'],21):future.append((float(old.kernel_np(float(ss),float(LL),dx)@nu)/q,float(ss),float(LL)))
    worst=max(future)
    gates=dict(q_tests_all_le_q=all(z<=q*(1+1e-12) for z in rb['q_tests'].values()),future_grid_all_le_q=worst[0]<=1+1e-10,high=rb['high_ratio']>=1,
       heavy=float(arr(g,'wg')@nu)>g['ell']*g['g']**g['n']*q,lambda_band=.75*lam<=q<=lam,hard_cap_nu=rb['hard_cap_ratio']<=1,hard_positive=rb['hard_nu_mass']>0,
       nu_mass_one=abs(float(nu.sum())-1)<1e-12,QJ_positive=QJ>0,alpha_nonnegative=alpha>=0,positive_rho=bool(max(rho)>0),strict_s=0<g['s']<1,scale=g['a']<=g['L']<=g['b'] and g['a']<=g['R']<=g['b'] and g['b']<=2*g['a'],
       tau_h_g=g['tau']<g['h']<g['zg'],Hhat_less_Lplus=g['Hhat']<g['Lplus'])
    return dict(label=label,stage=stage,status=status,n=g['n'],s=g['s'],L=g['L'],R=g['R'],xq=g['xq'],yq=g['yq'],positions=g['positions'],nu=nu.tolist(),q=q,lambda_value=lam,
       reverse_source_single_necessary_gate=dict(target_original_bad=1,Delta=float(g['delta'][1]),TDelta=float(A[1]),DK0_y=D*Ky,ratio=float(A[1]/(D*Ky)),fails=bool(A[1]<=D*Ky),scope='Only pre-alpha necessary test; no reverse alpha/Pi/source qualification recomputed'),
       source_components=[dict(source=i,nu=float(nu[i]),good=bool(good[i]),K0_nu=float(K0[i]*nu[i]),U_nu_over_D=float(U[i]*nu[i]/D),uncaptured_K0_nu=float((K0[i]-U[i]/D)*nu[i]),hard_nu=float(g['hard'][i]*nu[i])) for i in range(len(nu))],
       good=good.tolist(),rho=rho.tolist(),alpha=alpha,QJ=QJ,K0=K0.tolist(),N=N,R_common=q-N,R_y=Ry,bad_nu_mass=float(nu[bad].sum()),B_bad=bb,
       B_bad_over_R_y=bb/Ry,B_bad_over_R_common=bb/(q-N) if q>N else None,good_uncaptured_reserve=goodres,
       reserve_identity_residual=Ry-((q-N)+bb+goodres),Gamma_total=bb/Ry,beta=dict(choice='nu + slot delta_y',slot_mass=slot,B=Bbeta,K0_y=Ky,outer_y_mass=slot,
         positive_outer_atomic_row=slot>0,scope='beta=nu has no mass at y=0. Slot variant only finite atomic diagnostics; no L1/history.'),
       necessary_gates=gates,q_tests=rb['q_tests'],high_ratio=rb['high_ratio'],hard_cap_nu_ratio=rb['hard_cap_ratio'],future_grid=dict(count=len(future),worst_ratio=worst[0],argmax_u=worst[1],argmax_L=worst[2]),
       raw_costs=dict(history_factor='a_omega not constructed; retained in [0,1]',hard_density_nu=rb['hard_density'],prefactor_per_Lambda_at_history1=2*g['p']*rb['hard_density']/q,
         conditional_score_row_per_Lambda_upper=2*g['p']*rb['hard_density']/q*ints['original_threshold_window']['GL96']['original_rho_chiJ_Pi2_delta'],
         outer_atomic_slot_weighted_row_per_Lambda_upper=slot*2*g['p']*rb['hard_density']/q*ints['original_threshold_window']['GL96']['original_rho_chiJ_Pi2_delta'],
         receiver_dx='one fixed receiver; no positive dx mass or coverage asserted',hardcap_spent=False),
       integration=ints,points=[time_observable(g,nu,q,rho,x,Bbeta)[1] for x in (.51,.52,.53)],
       unimplemented_qualifications=['Psi/source labels','history a_omega','continuous receiver dx mass','L1 f and beta realization','FULL source quantifiers'])

def mp_selected_check(sel):
    mp.mp.dps=70;M=lambda z:mp.mpf(str(z));nu=[mp.mpf(Fraction(z).numerator)/Fraction(z).denominator for z in sel['nu_exact']]
    g=sel['geometry'];cs=[[prior.kt.mp_C(mp.mpf(Fraction(z).numerator)/Fraction(z).denominator) for z in row] for row in g['positions']]
    vals=[];errors=[]
    for t in ['.51','.52','.53']:
      wt=[mp.fprod(min(1,c/M(t)) for c in row) for row in cs];et=mp.fsum(w*v for w,v in zip(wt,nu));Pi=[w*v/et for w,v in zip(wt,nu)]
      ff=np.prod(np.minimum(1.,arr(g,'C')/float(t)),axis=1)*np.array([float(z) for z in nu]);ff/=ff.sum()
      errors.extend(abs(float(v)-float(w)) for v,w in zip(Pi,ff))
      vals.append(dict(xi=t,Pi=[mp.nstr(v,30) for v in Pi],Pi_bad=mp.nstr(Pi[1],30)))
    return dict(dps=70,checks=vals,max_Pi_abs_float_mp70_difference=max(errors),scope='mp70 threshold weights only; frozen kernel reserve values are independently certified by pair_certificate.')

def main():
    inp=json.loads((R168/'middle_source_lp.json').read_text());comp=json.loads((R169/'input_completion.json').read_text());s=inp['selected_rational_candidate'];g=s['geometry'];rb=s['float_readback']
    cases=[record('refined_selected','initial',g,rb['nu'],rb['q'],rb['lambda_value'],status='R168 refined nu future necessary bound independently certified; R169 atomic F completion, not L1')]
    oldsel=inp['first_pass']['selected_rational_candidate'];r=oldsel['float_readback']
    cases.append(record('historical_rejected_five_kernel_point','known_pressure',oldsel['geometry'],r['nu'],r['q'],r['lambda_value'],status='REJECTED by true future s=.25,L=.5; negative control only'))
    cases.append(record('refined_optional_beta_y_slot','known_pressure',g,rb['nu'],rb['q'],rb['lambda_value'],slot=1e-8,status='R169 optional atomic beta slot; finite future pressure only, no L1/history'))
    for ix in [7,10,11,13]:
      c=inp['cases'][ix];r=c['results'][0]['readback']
      cases.append(record(c['label'],'enlarged_frozen_range',c['geometry'],r['nu'],r['q'],r['lambda_value'],status='Frozen R168 finite LP point only; future grid can reject; no completion'))
    paths=[R168/'middle_source_lp.py',R168/'middle_source_lp.json',R169/'input_completion.json',Path(old.__file__),prior.DEP]
    out=dict(scope='Finite necessary atomic rows at fixed external y=0. Original-form Pi² delta diagnostics, not certified FULL traffic or an integrated dx/beta estimate.',
       definitions=dict(Z='all frozen nu sources; no receiver-dependent Z choice',Pi='wt nu / et',B_bad='sum_{bad} K0_i nu_i',R_y='alpha QJ/D=q-U nu/D',R_common='q-K0 nu',Gamma='1bad K0 nu/R_y (subprobability, no renormalization)',
        kappa='K0_u/wt_u',score='sum_good,bad rho_v chiJ_v (kv-ku)+ Pi_v Pi_u',bad_reserve_cap='[d_v-D B_bad J_v/(QJ TDelta_v)]+',residual_gate='sqrt(n) (K0 beta) [TDelta_v d_v²/(K0_y wg_v)] <= q-K0nu'),
       inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},cases=cases,selected_prior_FA_lowc_checks=s['mp70']['time_checks'],mp70=mp_selected_check(s),
       R169_base_completion=dict(sigma_mass=comp['exact_formula_mp70']['base']['sigma_boundary_mass'],hard_F=comp['exact_formula_mp70']['base']['hard_F'],outer_y_mass_for_beta_nu=0),
       limitations=['No beta outer mass at y=0 when beta=nu; conditional diagnostic integral is not positive actual outer traffic.','Optional beta slot is atomic and has only finite necessary future pressure here.','FA/Psi/history not independently constructed for enlarged points; lowc is reported pointwise and under the score weight.','No full input or positive receiver dx realization; no general payment or n-order inference.'])
    HERE.mkdir(parents=True,exist_ok=True);(HERE/'pair_reserve_probe.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({c['label']:dict(reserve=c['B_bad_over_R_y'],I=c['integration']['original_threshold_window']['GL96']['original_rho_chiJ_Pi2_delta'],unpaid=c['integration']['original_threshold_window']['GL96']['unpaid_fraction'],future=c['future_grid']['worst_ratio']) for c in cases},indent=2))
if __name__=='__main__':main()
