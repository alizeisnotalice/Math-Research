#!/usr/bin/env python3
"""R170 bounded source-pair certificate for the frozen finite R169 geometry.
No search, allfuture replay, smoothing replay, or FULL/L1 claim.
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import importlib.util,json,hashlib,time
HERE=Path(__file__).resolve().parent
R168=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint')
TOOLS=R168/'lp_candidate_certificate.py'
SELECTED=R168/'lp_refined_certificate.json'
COMPLETION=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round169_20261016_final_checkpoint/completion_certificate.json')
sp=importlib.util.spec_from_file_location('r170_interval_tools',TOOLS);ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct)
I=ct.I
NU=[F(3,25),F(2749,3125),F(1,3125)];q=F(9,2500)
S=F(1,4);L=F(9,10);X=[F(51,100)]+[F(2,5)]*3
POS=[[F(53,50)]+[F(19,20)]*3,[F(-3,5)]*4,X]
ADDED=[x+F(9,20) for x in X]

def interval(row):return I(Decimal(row[0]),Decimal(row[1]))
def dot(v):return sum((I(n)*z for n,z in zip(NU,v)),I(0))
def weight(C,xi):return [ct.prod((cc/I(xi)).capped_one() for cc in row) for row in C]

def score_interval(C,lo,hi,rhochi):
    # The proof of this profile is part of every run, including the full window.
    assert all(cc.hi<I(lo).lo for cc in C[0])
    assert all(cc.lo>I(hi).hi for row in C[1:] for cc in row)
    P=I(NU[0])*ct.prod(C[0]);B=NU[1]+NU[2];b=NU[1]
    amin=F(P.lo)/hi**4;amax=F(P.hi)/lo**4
    assert 0<amin<=amax<B
    def pb(a):return I(b)/(I(B)+I(a))
    def p0(a):return I(a)/(I(B)+I(a))
    def covariance_magnitude(a):return I(4*b)*I(a)/((I(a)+I(B))**2)
    def variance(a):return I(16*B)*I(a)/((I(a)+I(B))**2)
    cov=I(covariance_magnitude(amin).lo,covariance_magnitude(amax).hi)
    var=I(variance(amin).lo,variance(amax).hi)
    pbad=I(pb(amax).lo,pb(amin).hi)
    pgood0=I(p0(amin).lo,p0(amax).hi)
    emass=I((I(B)+I(amin)).lo,(I(B)+I(amax)).hi)
    return dict(xi_interval=[str(lo),str(hi)],fixed_Z_mask=[True]*3,k=[4,0,0],
        e=emass.out(),Pi_bad=pbad.out(),Pi_good_target=pgood0.out(),
        minus_Cov_indicator_bad_k=cov.out(),Var_k=var.out(),
        good_bad_delta_pair=cov.out(),weighted_rho_chi_good_bad_delta=(rhochi*cov).out(),
        dPi_bad_dlogxi=cov.out(),formula='-Cov(1_bad,k)=4*a*nu_bad/(a+nu_bad+nu_core)^2, a=nu_target*prod(C_target)/xi^4')

def run(Na,M):
    ell=I(1)+2*ct.log2_interval();g=I(L).sqrt();h=g*ct.iv.exp_neg(F(1,400))
    T=1/(I(L**2)*ell.sqrt())
    H=g*(I(1-S)+I(S)*ct.iv.phi(F(1,2),Na))*ell.sqrt().sqrt().sqrt()
    C=[[ct.iv.C(abs(z),Na) for z in row] for row in POS]
    wg=weight(C,g);Delta=[a-b for a,b in zip(weight(C,I(F(1,2))),weight(C,h))]
    A=[T*d for d in Delta]
    delta=[[x-z for x,z in zip(X,row)] for row in POS]
    K0=[ct.kern(S,H,row,Na) for row in delta]
    K1=[ct.kern(S,I(L),row,Na) for row in delta]
    K2=[ct.kern(S,I(1),row,Na) for row in delta]
    J=[ct.kern(F(1),I(1),row,Na) for row in delta]
    Q=[(a+b+c)/I(3) for a,b,c in zip(K1,K2,J)]
    p=ct.kern(S,I(L),X,Na)
    good=[True,False,True]
    for i in range(3):
        margin=Q[i]-p*wg[i] if good[i] else p*wg[i]-Q[i]
        assert margin.lo>0
    assert A[0].lo>K0[0].hi and 0<A[2].lo<K0[2].lo and A[2].hi<K0[2].lo
    U=[K0[0],I(0),A[2]]
    N=dot(K0);uncaptured_good=I(NU[2])*(K0[2]-A[2]);bad=I(NU[1])*K0[1]
    global_reserve=I(q)-N;alphaQJ=I(q)-dot(U)
    assert global_reserve.lo>0 and uncaptured_good.lo>0 and bad.lo>0
    jnu=dot(J);alpha=alphaQJ/jnu
    rho=I(1)-(K0[0]+alpha*J[0])/A[0]
    chi=J[0]/(3*Q[0]);rhochi=rho*chi
    assert rho.lo>0 and rho.hi<1 and chi.lo>0 and chi.hi<1
    bad_fraction=bad/alphaQJ
    assert bad_fraction.hi<Decimal('.0006')
    K0y=ct.kern(S,H,X,Na)
    dv=I(1)-K0[0]/A[0]
    all_alpha_relative_suppression=alpha*J[0]/(A[0]*dv)
    bad_only_relative_suppression=bad*J[0]/(jnu*A[0]*dv)
    assert all_alpha_relative_suppression.lo>Decimal('.85') and bad_only_relative_suppression.hi<Decimal('.0006')
    Fgate=A[0]*dv*dv/(K0y*wg[0])
    formal_gate_ratio=2*N*Fgate/global_reserve
    assert formal_gate_ratio.lo>1
    K0sigma=M*ct.kern(S,H,[x-r for x,r in zip(X,ADDED)],Na)
    first_gap=I(q)-N-K0sigma
    assert first_gap.lo>0
    parts=dict(q_minus_K0F=first_gap,K0_F_minus_beta_formal_beta_eq_nu=K0sigma,
               good_uncaptured=uncaptured_good,bad_uncaptured=bad)
    scores=[score_interval(C,x,x,rhochi) for x in (F(51,100),F(13,25),F(53,100))]
    whole=score_interval(C,F(51,100),F(53,100),rhochi)
    assert Decimal(whole['Pi_bad'][0])>Decimal('.99')
    return dict(a_subdivisions=Na,N_K0nu=N.out(),QJ=jnu.out(),alpha=alpha.out(),rho_target=rho.out(),chiJ_target=chi.out(),
        alphaQJ=alphaQJ.out(),reserve_decomposition=dict(
            q_minus_K0nu=global_reserve.out(),good_uncaptured=uncaptured_good.out(),bad_uncaptured=bad.out()),
        bad_reserve_fraction=bad_fraction.out(),
        relative_suppression_from_pre_alpha_d=dict(all_alpha=all_alpha_relative_suppression.out(),bad_only=bad_only_relative_suppression.out(),exact_ratio_bad_to_all='bad_K0_reserve/(alpha_QJ)'),
        atomic_F_formal_beta_nu_decomposition={k:v.out() for k,v in parts.items()},
        atomic_F_part_fractions={k:(v/alphaQJ).out() for k,v in parts.items()},
        formal_beta_eq_nu_gate=dict(K0_y=K0y.out(),F_y_target=Fgate.out(),sqrt_n_N_F_over_q_minus_N=formal_gate_ratio.out(),passes=False,formal_traffic_coverage_fraction_whole_window=0,
            caveat='beta=nu has no mass at y=0; this is a formal conditional row diagnostic, not covered actual beta traffic.'),
        point_score_checks=scores,whole_time_interval_score=whole)

def main():
    start=time.monotonic();sel=json.loads(SELECTED.read_text());comp=json.loads(COMPLETION.read_text())
    assert sel['candidate']['nu']==list(map(str,NU)) and F(sel['candidate']['q'])==q
    assert comp['geometry']['nu']==list(map(str,NU)) and F(comp['geometry']['q'])==q
    M=interval(comp['refinements'][-1]['exact_added_mass_interval'])
    rows=[run(64,M),run(128,M)]
    out=dict(scope='Finite fixed-row source-pair and bad-reserve certificate only. Original Z/Psi/beta/history/L1 not realized.',
        inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (TOOLS,SELECTED,COMPLETION,ct.DEP)},
        parameters=dict(n=4,nu=list(map(str,NU)),q=str(q),xq=list(map(str,X)),yq=['0']*4,positions=[list(map(str,z)) for z in POS],
            s=str(S),L=str(L),R='1',a='1/2',b='1',D='1',K='1',cj='1',legacy_time_parameter='1/100',good_mask=[True,False,True],source_support_for_score=[True]*3),
        arithmetic='Directed Decimal and certified E/exp/log/sqrt from frozen R166/R168. No float arithmetic enters bounds.',
        refinements=rows,
        decisions=dict(bad_K0_reserve_fraction_less_than_0006=True,Pi_bad_greater_than_099_whole_window=True,
            formal_beta_nu_reserve_gate_fails=True,source_threshold_covariance_strictly_negative=True),
        limitations=['Covariance and derivative statements assume fixed Z equal to all three finite sources on [.51,.53]; actual Z eligibility is not constructed.',
            'beta=nu has no outer atom at y=0; formal gate and row-pair diagnostics are not positive actual beta traffic.',
            'Bad-reserve small and posterior bad-mass large coexist only proved for this finite row, not uniformly or as an integrated counterexample.',
            'No allfuture or symmetric smoothing result is rerun; prior atomic F mass interval is used only in the reserve split.',
            'No original q/hard/time/j/history/beta integrated budget is paid.'],
        wall_seconds=round(time.monotonic()-start,3))
    (HERE/'pair_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    fine=rows[-1]
    print(json.dumps(dict(seconds=out['wall_seconds'],bad_fraction=fine['bad_reserve_fraction'],reserve_fractions=fine['atomic_F_part_fractions'],
        formal_gate=fine['formal_beta_eq_nu_gate'],whole_window=fine['whole_time_interval_score']),indent=2))
if __name__=='__main__':main()
