# R170：bad未捕获reserve与原双后验交通的独立审计

状态：命题前独立检查点；尚未读取 `uncaptured_pair_budget.md`。只读R170合同及此前已审共同K0/来源合同，不重跑数值、不扩展路线。责任文件仅本稿。

## 1. 固定原行与实际bad储备

固定原ω,V、接收x、实际j、外y以及原t。K0=P_{s(x),Hhat(x,j)}是对所有外y共用的合法future核；原D_y(x)为终端bad来源集，D_y⊂Z_g(y)⊂Z_t(y)。定义
\[
A_y(x)=\int_{D_y(x)}K_{0,x}(u)d\nu_V(u),\qquad
m_{y,t}(x)=\Pi_{y,t}(D_y(x)).
\tag{PA1}
\]

原U_y在D_y上为零，其它来源上U_y≤DK0，完整FIRST给q≥K0ν。因此
\[
\alpha_yQ_J=Dq-\int U_y d\nu
\ge D\int_{D_y}K_0d\nu=D A_y.
\tag{PA2}
\]

这是同一个实际α_y；未删除其它来源、重选α、把q换成有限核max。D_y依x,y，而A_y并非全外中心共用标量。它可以用于每个外y的原good/bad对，但不能拿来直接归一整份外β。

令d_{yv}=(1-DK0_v/(TΔ_{yv}))_+。在原positive good域TΔ>0，沿已核二次式有
\[
A_y\rho_{yv}
\le\frac{Q_JT\Delta_{yv}d_{yv}^2}{4DJ_v}.
\tag{PA3}
\]

与R169共同R=q−K0ν不同，此处A_y=0确使bad交通为零：s>0保证K0严格正，故ν(D_y)=0，再由Π支配ν得m_{y,t}=0。反之A_y>0时，D_y⊂Z_t及w_t>0给m_{y,t}>0。零QJ/et等沿原零交通，不除零。

## 2. bad质量究竟消掉哪些因子

固定y,t的原Π_t不依x，但D_y、A_y、m_{y,t}均因终端bad门依x。以bad储备归一
\[
d\mathcal B_{x,y}(u)
=1_{D_y(x)}(u)\frac{K_{0,x}(u)}{A_y(x)}d\nu_V(u)
\]
是一份**依x,y**的概率。原bad后验准确写成
\[
1_{D_y}d\Pi_{y,t}(u)
=\frac{A_y}{e_t(y)}\frac{w_t(y,u)}{K_{0,x}(u)}d\mathcal B_{x,y}(u).
\tag{PA4}
\]

因此(PA3)消去的是(PA4)分子中的A_y，仍留下e_t^{-1}和w_t/K0。不能把\mathcal B移到dx外冒作冻结Π，也不能宣称两个e_t分母均因此抵消。

等价地定义原bad条件后验Π^D=1_DΠ/m及其κ均值
\[
\overline\kappa_{y,t}
=\int\frac{K_0}{w_t}d\Pi^D_{y,t}
=\frac{A_y}{e_t m_{y,t}}.
\tag{PA5}
\]

由(PA3)得到的准确结果是
\[
m_{y,t}\rho_{yv}
\le\frac{Q_JT\Delta_{yv}d_{yv}^2}{4DJ_v}
\frac{m_{y,t}}{A_y}
=\frac{Q_JT\Delta_{yv}d_{yv}^2}{4DJ_v e_t\overline\kappa_{y,t}}.
\tag{PA6}
\]

bad质量m可以在条件概率表达中被吸收到这一比值，但1/(e_t\barκ)=m/A_y仍是实际费用。high只给1/e_t≤p/(2Kq)，代入会产生p/q等新的核因子，不把该费用变成1。另一个good后验Π(v)应保持为概率积分；它可以在上界对v统一后归一，而非在展开时随意删掉其e_t。

## 3. 原good/bad双后验的精确行上界

先按原资格使用一次hard帽，则signed外系数为32Λ/3。以下只写帽后、尚未乘此常数的行量。对固定x,j,t,y,v，由χJ=Jv/(3Qv)、原good p/Qv≤K/wg(y,v)，从(PA3)–(PA4)得到
\[
p\chi_{J,v}\rho_{yv}\int_{D_y}\delta_t(v,u)d\Pi_{y,t}(u)
\le\frac{KQ_J}{12D}
\frac{T\Delta_{yv}d_{yv}^2}{e_t(y)w_g(y,v)}
\int\frac{w_t(y,u)}{K_{0,x}(u)}\delta_t(v,u)d\mathcal B_{x,y}(u).
\tag{PA7}
\]

这是仍保留真实pair几何的转置/归一接口，外β和good Π(v)尚在。若仅用δ≤n，则(PA7)成为
\[
\le\frac{KQ_J n}{12D}
\frac{T\Delta_{yv}d_{yv}^2}{w_g(y,v)}\frac{m_{y,t}}{A_y}.
\tag{PA8}
\]

因此一般外β剩余的明确receiver费用是
\[
\int d\beta_V(y)\int d\Pi_{y,t}(v)
\frac{T\Delta_{yv}d_{yv}^2}{w_g(y,v)}\frac{m_{y,t}}{A_y}
\,1_{\rm surviving\ original\ gates},
\tag{PA9}
\]

或保留δ时(PA7)的更精确平均。没有由同α、高区或Π归一直接给出的(PA9)常数帽。将它命名“未捕获核列预算”不会完成付款。若改先积分x，仍须证明这一center-dependent \mathcal B的真实列估计；它不是J那样的固定归一卷积核，且外β没有变成ν。

## 4. 一个具体、可核的条件付款检查模板

这只是独立筛查作者命题的充分接口，不声称原middle自动满足它。令共同B_β(x,j)=K0β_V。Bβ>0时M_x(dy)=K0_yβ(dy)/Bβ为当前行概率。对A_y,m>0，若所选实际子域满足
\[
\sqrt n\,B_β
\frac{T\Delta_{yv}d_{yv}^2}{K_{0,x}(y)w_g(y,v)}
 m_{y,t}\le A_y,
\tag{PA10}
\]

则(PA8)在M_x归一后给统一行帽KQJ√n/(12D)。它是average-bad reserve门，等价于√n BβF_y(v)≤e_t\barκ_{y,t}；与逐u高κ门不同，但仍是一个新增条件，不证明一般middle或旧门补集覆盖。

若不使用δ≤n，而逐pair证明更强的带δ共同核上界，也可接受；必须明确其对原β/Π²的积分和所有费用，不能把β归一为bad条件后验。任何使用(U_y未捕获的全部中心核)的新归一同理需要真实外y列/行预算。

在(PA10)给出统一x行帽后，原唯一j指示可保留到共同[a,b]时间窗再合并，时长≤log2；fixed-b的∫QJdx=‖ν‖。因此该**条件接口若被作者实际采用并满足**，完整signed价将是
\[
\frac{8\Lambda K\log2}{9D}\sqrt n\,W_β.
\tag{PA11}
\]

反之若作者先做fixed-y column估计并扩大各j接收域，则不能回头用唯一j免费合并，须付原N_j等费用。新门依t并非问题，前提行上界对允许t统一；终端bad集合依x也不是问题，前提全程不假装其固定。

## 5. 作者成稿审计清单与停止点

1. bad reserve是否确来自原U_y=0及完整FIRST，而非把已花来源另命名？
2. A_y=0、m=0、QJ=0、et=0处理是否准确；尤其中心bad reserve与共同q−K0ν的零情形不能混同？
3. 原Π²的两份et在哪里保留、归一；是否误把(PA4)的wt/K0或(PA6)的m/A_y删掉？
4. 共同K0对外y独立已由原R128定义核实；center-dependent bad核\mathcal B却不能获得相同独立性或归一卷积列质量。
5. 作者结论是明确条件门预算还是一般middle；新门实际非空/FULL覆盖是否有独立证据？
6. hard一次、32Λ/3、time/j、β来源量、接收dx、固定块及聚合history是否齐全？

独立结论：bad储备确可接入原双后验，但bad质量只将储备转为m/A_y=1/(et\barκ)，不免费消除原归一/反核费用。一个真实共同核/行支配如(PA10)，或其更精确pair版本，才可闭合条件预算。独立检查点已保存；现在才允许读取作者 `uncaptured_pair_budget.md`，之后有限对读，不开展新路线。

## 6. 对 parent_pair_identity.md 的对读

先行§§1–5已保存后才读取父级P1/P2。本稿(PA1)的A_y专指bad储备；为避免同名混淆，本节将父级实际总reserve记为
\[
A_y^{\rm act}=q-D^{-1}\int U_y d\nu=\alpha_yQ_J/D,
\quad R=q-K_0\nu,
\quad c_y=U_y/(DK_0).
\]

父级分解A_act=R+∫K0(1−c_y)dν准确，且R≥0。μ_y=K0(1−c_y)ν/A_act的总质量为1−R/A_act，确是次概率而非必为概率；bad支c_y=0，所以P1两侧均为
\[
\frac1{A_y^{\rm act}e_t}\int_{\rm bad\cap Z_t}H(u)w_t(y,u)d\nu(u).
\]

P1通过。A_act=0使两个非负项均零，继而bad ν质量零；R=0单独不具这一结论。原positive核严格正的s>0条件已在合同中满足。

父级以A_actρ≤QJTΔd²/(4DJv)接P1，再用good核比较，P2的KQJ/(12D)、G_y(v)/e_t及内δ wt/K0均准确。它比本稿仅使用A_bad的形式保留更多未捕获来源，但μ的非bad部分不因此成为原bad交通，也不能把次概率补质量任意安在有利来源上。

P2只是原交通的准确上界接口：外β不归一，μ依x,y，wt/K0与et^{-1}仍有真实费用。父稿明确不把它登记为新付款，此范围通过。后续作者若只重写P2而不给共同核支配/真实列预算/新条件门及其费用，不算完成一般middle接缝。

作者稿此时尚未落盘；停止等待准确成稿。

## 7. high–Π真实列界及解析迭代：作者稿前独立核验

按父级新增准确命题，先独立检查并保存此节，随后才读作者对应UP段。以下记a_K=(2K)^{-1}；若要称严格收缩/几何衰减，须2K>1，测度不等式本身对K>0成立。

固定原ω,V、原[a,b]块与当前合法接收点x。令j=j(x)、t=t(x)是可测、接收点适应的选择；对非零行y要求原high p_y e_g(y)≥2Kq，以及原时间/支撑合同e_t(y)≥e_g(y)、0≤w_t≤1。可把全部原时间资格一并留作行指示，不给不合法t强行赋原流程意义。定义
\[
T_x(y,du)=1_{H_x}(y)\Pi_{j(x),V,y,t(x)}(du),
\tag{PA12}
\]

其中H_x至少包含上述high与所需资格，零/未定义原后验行扩充为零核。假定原核族的共同可测性及j,t选择可测，使T_x成为正次Markov核。它不含α/ρ/score，也不是新的原history。

固定x下，展开Π且用high，得到测度支配
\[
\begin{aligned}
(\beta_VT_x)(du)
&=d\nu_V(u)\int\frac{1_{H_x}(y)1_{Z_t(y)}(u)w_t(y,u)}{e_t(y)}d\beta_V(y)\\
&\le\frac{d\nu_V(u)}{2Kq}\int p_y(x)d\beta_V(y)
\le\frac1{2K}d\nu_V(u).
\end{aligned}
\tag{PA13}
\]

最后一步是同一共同当前核的FIRST及β_V≤f，不是逐来源另选测试。该界不需要Z对称或β=ν；也未将ν归一为概率。任意声称“arbitrary t”的版本必须仍满足非零行的e_t≥e_g与原时间资格，high单独不保证任意t都合法。

由ν≤β，正核保序给βT_x≤a_Kν≤a_Kβ。对每个整数m≥1归纳可得
\[
\beta_VT_x^m\le a_K^m\nu_V.
\tag{PA14}
\]

例如βT²≤a_KνT≤a_KβT≤a_K²ν。m=0不能写成β≤ν。核只需在β-a.e.中心上定义，因下一步ν≤β保持该支撑；取共同零扩充可避免在无定义反向中心上暗造资格。每步重新按同一T_x检查high，而非固定第一次高区后继续无门移动。

J_b(x-v)=P_{1,b}(x-v)为原块固定b的归一接收核。对每个合法x先将(PA14)乘J_b(x-v)，然后正Tonelli，得
\[
\int_{\mathcal E}dx\int J_b(x-v)\,d(\beta_VT_x^m)(v)
\le a_K^m\int_{\mathbb R^n}dx\int J_b(x-v)d\nu_V(v)
=a_K^m\|\nu_V\|.
\tag{PA15}
\]

\mathcal E应为原FIRST合法接收域，或在其外将T_x设零；无需FIRST在全空间成立。T_x可以依x，因支配逐x成立；右端能积分成ν质量，是由于固定b的J归一，不是因为T_x可移到dx外。跨ω,V可进一步给a_K^mWβ。

本节无需额外j菜单或time费用，因为只处理给定的j(x),t(x)。若另把此式对多个j或time积分，必须保留相应实际选择/长度/求和费用，不能把“任意可测选择均成立”误读为“所有选择可免费相加”。

**迭代身份限制。** (PA14)–(PA15)是解析核复合，不证明原流程真的访问这些中心或实现m步history。原good/bad/ρ、同α与delta可能在换中心时改变；没有得到加权G/A的列界，也没有证明原pair raw被该链尾支配。只有后续出现明确且保门的原交通支配时，才可据此登记实际付款。

独立裁定：通过(PA13)的原Π列支配及上述量词下的全局解析迭代界；仍非一般middle raw付款。检查点已保存，随后对读作者版本。

## 8. uncaptured_pair_budget.md 成稿独审

先独立保存§§1–7后读取作者成稿UP1–17。本次通过结构工具与准确剩余接口，不认证UP14或新raw付款。

### 8.1 UP1–6：真实high列界、迭代和饱和几何通过

UP1明确仅在原time资格保证e_t≥e_g的外y上保留H，并将其它零行置零，符合(PA12)的必要量词。UP2的逐列证明与(PA13)吻合：1/e_t上放p/(2Kq)，wt≤1，最后对同一p以β≤f用一次FIRST。bad子核或其它[0,1]门只缩小正核，不需要对称、可逆或坐标独立性。

UP3对m≥1的测度归纳准确。对应函数算子在L1(β)上也有\(\|Pf\|_{L^1(β)}\le(2K)^{-1}\|f\|_{L^1(β)}\)，所以2K>1时解析级数有几何范数界。作者没有把它叫原history路径，这一范围正确。父级要求的接收适应j(x),t(x)及固定b的J全局版已经在(PA12)–(PA15)独立核验通过；原FIRST域外须零扩充或限制积分，不要求FIRST在全空间成立。

UP4以同一\(M_x=p_yβ/q\)及\(\eta_y=2Kq/(p_ye_t)\)写列密度，因H非零时p_y、e_t均正且η≤1，等式准确。UP5五项亏损展开的系数之和为
\[
(1-H)+H(1-\eta)+H\eta(1-Z)+H\eta Z(1-w)
=1-H\eta Zw,
\]

加上1−M_x(total)恰为1−2Kc_t(u)。每项非负，因此接近等号时每项≤ε的结论准确。它们必须在同一M_x下同时成立，不能分别换来源或测试。

UP6用L_t=−log wt及L_t≥r时1−wt≥1−e^{-r}，从第五亏损项直接得到所写尾帽；r>0条件和常数正确。这是实际软重叠损失的加权几何约束，未把L_t替换成原score差δ。当前作者未证明该约束控制Gδ/A，不能因无权列近饱和就自动得到raw根阶。

### 8.2 UP7–10：实际reserve、零行及指定权列界通过

UP7/UP8与父级P1及本稿§6同式：mu_y质量是1−R/A_y，非必为1；原bad上c_y=0允许精确替换，但1/e_t和wt/k_u仍在。A_y=0使badν零的结论正确，不与R=0混同。QJ=0原来源零，UP2本身不需要除α。

UP9展开A_yβ(dy)L(y,du)后就是原high-bad子核的β列；A=0行bad零，故≤ν/(2K)成立。它是带**指定来源权A_yβ**的列界，不允许换回β或当作另可免费分配的来源预算。UP10数值二次包络与(PA3)一致，使用实际同α，不在不同v上重选α。

### 8.3 UP11–14：准确剩余及条件费用通过；UP14未证

UP11–12的KQJ/(12D)、β槽、ν(u)槽、1/(A_y e_t)、wt以及good-v的Π平均逐项准确。UP13以同一M_x、η重写后，βH/e_t=(1/(2K))M_xHη，故1/(2K)系数正确，没有偷偷把Gδ/A移成只依u的测试函数。

UP2能控制固定非负h(u)，而UP13中的好源平均/A_y同时依y与u。稿件明确不据UP2支付此权，范围正确。若未来确证UP14的统一实际行界，hard一次32Λ/3、原唯一j留到共同[a,b]时间窗、再∫QJdx=‖ν‖，确给
\[
\frac{8\Lambda K\log2}{9D}\,C_*\sqrt n\,n^{o(1)}W_β.
\]

当前只是“若UP14成立”的真实费用核算，不能记为本轮已付分支。另行对各j、t、不一致选择或重复history上界求和时，必须重新支付相应费用。无权迭代(PA15)也未提供UP14所需的原交通支配。

### 8.4 UP15–17的有限代数检查

原共同g、τ、h、T不依外y，C偶性使Δ_y(u)=Δ_u(y)；在原有效非空时间行τ≤h，故a=TΔ/D≥0。设k_u=M≥m=k_y，逐区间a≤m、m<a<M、a≥M展开
\(m(M-a)_+-M(m-a)_+\)，分别为a(M−m)、m(M−a)、0，UP15正确。共同对称最小部分为M(m−a)_+。

合同U_y=1_good min(TΔ,Dk_u)在原正Δ支成立；good与bad互补，故
\[
k_yk_u(1-c_y(u))
=k_y(k_u-a)_++k_y\min(a,k_u)1_{bad_y}(u),
\]

UP16正确。若另有非互补的capture资格被并入U，必须重新加入对应未捕获项；此式仅按本轮明确合同使用。它不证明全核可逆，原支持、et、α与β/ν差异仍在。

UP17从bad_y(u)及Q_u≥p_u/3得到p_u<(3/K)p_ywg≤(3/K)p_y，方向和常数正确；K>3时才给统一严格下降，不能为使用该结论重新选择原K。该p排序与K0排序不是同一个势，也未证明可用于原路径费用求和。

### 8.5 最终裁定

**通过的新增结构工具：** 完整β的原high–Π列支配、同一解析核的迭代衰减、接收适应选择下固定b的J全局积分界、五项精确饱和亏损与软重叠损失尾帽。通过UP9指定权列界及UP15–17有限代数关系。

**未通过为已付款结论：** UP14、其等价原接收积分预算、原history实现的多步链、带Gδ/A的列收缩。作者没有声称这些已证，因此无需纠正其结果身份。实际bad reserve可使用，但未自动取消原双后验的低κ/归一费用；当前无新增FULL/L1/history正分支覆盖结论。

独审与作者版本绑定完成；无数值重跑、无Git，仅本文件更新。交付停止。
