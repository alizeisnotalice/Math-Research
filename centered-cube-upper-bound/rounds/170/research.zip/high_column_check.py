#!/usr/bin/env python3
"""Exact finite checks of the high-column lemma, not geometric realizations."""
from fractions import Fraction as F
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
def rowmul(a,T):
    return [sum((a[i]*T[i][j] for i in range(len(a))),F(0)) for j in range(len(a))]
def main():
    records=[]
    for stage,N in enumerate((2,4,8),1):
      for variant in range(8):
        K=F(1+variant%3)
        eps=F(1,16*(variant+1)*N)
        beta=[eps]+[(1-eps)/F(N-1)]*(N-1)
        nu=[v*F(2+(j+variant)%3,4) for j,v in enumerate(beta)]
        p=[F(1)]+[eps/F(2*K*N)]*(N-1)
        q=sum((a*b for a,b in zip(p,beta)),F(0))
        W=[[F(1) if i==0 else F(1+(i+2*j+variant)%4,4) for j in range(N)] for i in range(N)]
        Z=[[True if i==0 else (i+j+variant)%3!=0 for j in range(N)] for i in range(N)]
        et=[sum((nu[j]*W[i][j] for j in range(N) if Z[i][j]),F(0)) for i in range(N)]
        eg=[e*F(3+(i+variant)%2,4) for i,e in enumerate(et)]
        H=[p[i]*eg[i]>=2*K*q and et[i]>0 for i in range(N)]
        T=[[nu[j]*W[i][j]/et[i] if H[i] and Z[i][j] else F(0) for j in range(N)] for i in range(N)]
        assert all(sum(row,F(0))<=1 for row in T)
        a=beta[:];slacks=[]
        for m in range(1,5):
            a=rowmul(a,T)
            slack=[nu[j]/(2*K)**m-a[j] for j in range(N)]
            assert min(slack)>=0
            slacks.append(str(min(slack)))
        assert any(H)
        records.append(dict(stage=stage,N=N,variant=variant,K=str(K),high_count=sum(H),
            min_column_slack_powers_1_to_4=slacks))
    result=dict(scope='Exact finite kernel arithmetic conditional on the lemma hypotheses; no cube/FIRST/history realization assertion.',
        stages=[dict(stage=s,N=n,cases=8) for s,n in enumerate((2,4,8),1)],cases=24,
        rational_column_checks=sum(4*r['N'] for r in records),all_pass=True,records=records)
    (HERE/'high_column_check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('cases','rational_column_checks','all_pass')}))
if __name__=='__main__':main()
