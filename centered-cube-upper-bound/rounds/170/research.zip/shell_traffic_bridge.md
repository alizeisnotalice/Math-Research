# R170：来源对 δ 到真实 hard 壳层的加权比较

状态：证明原 Π_t²、good/bad、ρ 权下的来源对—接收壳层比较，以及壳层项的真实 FIRST 体积价格。剩余是明确的两个来源偏离项及不对齐时间窗；未证明它们的根阶费用，未登记一般中间域付款。以下不把 R169 的接收尺度 score A 当成原 δ，也不假定来源独立。

## 1. 原量词与一个精确几何分解

沿 R170 原合同，固定原 x,y,t,j；p、L、s、g、ρ、good/bad 都用原值。令 z=c_jt/b∈[1/2,1]。因为 F=max(h,φ) 在正半轴单调，C=h*F 连续，C(0)=1，C 在 (0,∞) 严格递减且趋于零，定义唯一 r_z≥0 满足 C(r_z)=z，并置 θ_z=b r_z。于是原阈值计数准确为

\[
 k_z(v)=\sum_i1_{\{|y_i-v_i|>\theta_z\}}.
\]

取参数 ε>0，定义真实接收阈值壳层与两端偏离数

\[
 S_z(x,y;\varepsilon)=\sum_i1_{\{\big||x_i-y_i|-\theta_z\big|\le\varepsilon L\}},
\]
\[
 F_\varepsilon(x,v)=\sum_i1_{\{|x_i-v_i|>\varepsilon L\}}.
\]

对所有来源 v,u，不作任何概率假设，有

\[
 \boxed{\delta_t(v,u)
 \le S_z(x,y;\varepsilon)+F_\varepsilon(x,v)+F_\varepsilon(x,u).}       \tag{S1}
\]

证明：若某坐标不在右边三个集合中，三角不等式保证 |y_i−v_i|、|y_i−u_i| 同在 θ_z 的同一侧，该坐标对 k_z(v)−k_z(u) 的贡献为零。其余每坐标正贡献至多1；先用正部和控制总和的正部，得到 (S1)。闭壳层包含所有阈值等号，不需要排除零测边界。

这是来源对 score 的实际比较，不是对 A 的再次估计。代价是明写 F_v、F_u，不能预先声称它们小。

## 2. 与 R169 真实 hard 壳层接合，并保留对齐时间费用

取固定 0<r≤1/4，要求原扩尺度 Le^r≤b。R169 的扩尺度跨界数为

\[
 N_+(x,y;r)=\sum_i1_{\{L/2<|x_i-y_i|\le Le^r/2\}}.
\]

只在实际对齐门

\[
 \mathsf A_{r,\varepsilon}:
 \quad \theta_z-\varepsilon L>L/2,\qquad
 \theta_z+\varepsilon L\le Le^r/2                         \tag{S2}
\]

上，有 S_z≤N_+。该门可能为空；非空必须 ε<(e^r−1)/4。其 z 窗包含于

\[
 C((Le^r/2-\varepsilon L)/b)
 \le z<C((L/2+\varepsilon L)/b).
\]

因此不能把全部原时间区间替换成对齐窗。反过来，在此门内可安全使用真实时间长度上界

\[
 \int1_{\mathsf A_{r,\varepsilon}}\frac{dt}{t}
 \le\tau_r:=\min\{\log2,e^r-1\}.                         \tag{S3}
\]

证明：0≤F≤1，故 C=h*F 是1-Lipschitz；在 C≥1/2 的相关窗口上 log C 是2-Lipschitz。窗口的 log z 长度至多
\(2(L/b)[(e^r-1)/2-2\varepsilon]\le e^r-1\)。再与原 log2 时间帽取小。原 Ψ、history、t≤g、z≤z_g 门只会进一步截短；没有将必要窗口当成全部实际交通。

## 3. FIRST 对真实壳层的积分支付

令

\[
 \ell(s)=\log\frac{1-s+s\phi(1/2)}{s\phi(1/2)}.
\]

对于每个来源 y，扩尺度测试逐坐标给

\[
 \boxed{\frac{P_{s,Le^r}(x-y)}{P_{s,L}(x-y)}
 \ge e^{-nr}\exp\{\ell(s)N_+(x,y;r)\}.}                 \tag{S4}
\]

未跨界坐标只用 f_s 单调；跨界坐标满足旧位置>1/2、新位置≤1/2，故其 f_s 比至少为
\((1-s+s\phi(1/2))/(s\phi(1/2))\)。归一化代价是准确的 e^{-nr}。这比仅控制原 b-core 外坐标的两尺度下界保留了真正新增的 hard 质量。

现在使用**完整原输入 f**和同一个 receiver FIRST。因为 p f/q 是概率密度，(S4) 及未来测试给

\[
 \frac1q\int p_x(y)e^{\ell(s)N_+(x,y;r)}f(y)dy\le e^{nr}.
\]

Jensen 与原 \(\sum_V\beta_V\le fdy\) 因而得到，当 s<1 时

\[
 \boxed{\int p_x(y)N_+(x,y;r)d\bar\beta_\omega(y)
 \le\min\{n,nr/\ell(s)\}\,q.}                           \tag{S5}
\]

同样有真实壳层尾界

\[
 \int_{N_+\ge M}p_x(y)d\bar\beta_\omega(y)
 \le e^{nr-\ell(s)M}q.                                  \tag{S6}
\]

β 不被概率化，ν 不被当成 β；只对已由当前等式归一化的 p f/q 使用 Jensen。s=1 时 ell=0，(S5) 仅保留 nq；没有虚构 hard 跳益。没有 soft 菜单费：测试软度正是当前 s，测试 Le^r 是同一 receiver 的合法 future，可依当前 L，但不依被积分 y。

这项支付具有 hard 的线性成本 nr/ell(s)，并未违背 R169 hard-face TV≥2n(1-s) 的压力。r 取常数量级时，它通常仍是线性，不自动变成根阶。

## 4. 保留原权后的实际交通比较和完整费用

记原 pair 权

\[
 W_{x,y,t}(v,u)=\rho_y(v)\chi_J(v)
 1_{\rm good}(v)1_{\rm bad}(u),\qquad0\le W\le1.
\]

把 (S1) 乘此权，并在原完整 Π_t² 上积分，得到

\[
 \int W\delta_t\,d\Pi_t^2
 \le N_+\int W\,d\Pi_t^2
    +\int W[F_\varepsilon(x,v)+F_\varepsilon(x,u)]\,d\Pi_t^2
                                                                    \tag{S7}
\]

在 (S2) 上成立。可再将第一项上放为 N_+。第二项中的同一 α、ρ、χ_J、good/bad 和 Π_t 均未删除，坏来源 u 没有换成补偿来源或外 hard 来源。

令 \(\mathcal T_A\) 是实际原剩余中间域与 (S2)、Le^r≤b 的交集上的完整 raw；若再加 nearmax R<e^H 或其他原门，以下上界仍成立。令 \(\mathcal E_A^{\rm src}\) 为**同一原 raw 测度及同一分支**，只把 δ 换成
\(F_\varepsilon(x,v)+F_\varepsilon(x,u)\)。则

\[
 \boxed{\mathcal T_A
 \le\frac{32\Lambda}{3}(n+2)\tau_r
 q\,\mathbb E\int_{\mathcal E}
       \min\{n,nr/\ell(s(x))\}\,dx
 +\mathcal E_A^{\rm src}.}                              \tag{S8}
\]

ell=0 按 min 值 n 理解。\(\mathcal E\) 是原接收域；若依种子，使用所写期望。证明按以下顺序进行：对壳层项用原 hard/history 帽16/3一次；用 W≤1、Π_t² 总质量1；使用 (S3)；合并原叶 β 后用 (S5)；最后安全计列数 n+2。外 signed 因子2Λ合成32Λ/3。没有隐去选择器、来源聚合或时间价格。

只有壳层这一正上界项使用 hard 帽。误差 \(\mathcal E_A^{\rm src}\) 仍保留原 q^{-1}h_R a_ω dν(z')，未预领第二次帽，亦未宣称它已付。若原唯一 j 被保留到另行证明的统一行帽，才能相应改善 n+2；本文不自行删列费。

在一条实际额外局部来源分支 F_v=F_u=0 上，误差确实为零，(S8) 给该分支的完整体积界。若另有 ell(s)≥ell_*>0，它不超过
\[
 \frac{32\Lambda}{3}\frac{n(n+2)r\tau_r}{\ell_*}
 q\,\mathbb E|\mathcal E|.                              \tag{S9}
\]
这是明确的条件预算，不是 Wβ 预算，也未认证该局部分支覆盖未付中间交通。把 r 任意缩小得到小系数会同步缩小对齐窗和所需 ε；不能据此宣称一般付款。

## 5. 两端来源偏离项为何仍是实质接缝

第一，(S2) 要求 ε<(e^r−1)/4。R169 根阶尺度 r≈sqrt(H/[n log(n+2)]) 对应很薄的来源局部化半径 εL。原 good/bad 只给
\[
 \frac{KQ(x-u)}{w_g(u)}<p
 \le\frac{KQ(x-v)}{w_g(v)};
\]
它不是 |x−u| 或 |x−v| 的逐坐标上界。尤其 bad-u 端在 (S7) 中没有一份 J(x−u) 权，不能从 χ_J(v) 转给 u。对称化会改变资格与同一 α 的权，不能免费实行。

第二，即使先给某一端一份自然的 J 权，偏离计数也没有无条件根阶空间价格。对任意固定来源 v 和固定 L≤b，真实 dx 恒等式为

\[
 \int J_b(x-v)F_\varepsilon(x,v)dx
 =n\left[1-\int_{-\varepsilon L/b}^{\varepsilon L/b}\phi(t)dt\right]
 \ge n[1-2\varepsilon\phi(0)].                           \tag{S10}
\]

这是产品核积分，不是对一般来源 ν 的独立性假设。若 L=L(x)≤b，右侧同一下界仍由逐点 F_ε(x,v)≥Σ1_{|x_i−v_i|>εb} 得到。在小 ε 下该自然真实空间成本仍为线性。此式不是满足所有原门的反例，也不排除原 good/bad/ρ 的进一步抵消；它准确说明不能仅凭 FIRST、核归一化或“薄壳”一词支付误差。

第三，不对齐时间窗未被 (S8) 覆盖。在那里 (S1) 的 S_z 是 C 阈值半径 θ_z 周围的接收壳层，而非物理 hard 边界 L/2；R169 N5–N9 和 (S4) 不直接为其提供 hard 跳益。替换为 hard 壳层须另付两个半径之间的带状计数，不能把它删掉。

本路线精确留下的待证项是 (S8) 中的 \(\mathcal E_A^{\rm src}\)，以及原交通在不对齐窗上的部分。下一步必须使用原 same-alpha reserve/good-bad 核比，对这些真实 Π_t² 权下的来源偏离项给出可积分预算；(S10) 表明独立核归一化不足。本文没有把这些未付项重新命名为已控范数，没有证明一般 root 弱型结论。
