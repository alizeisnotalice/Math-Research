# R170 source-pair geometry / threshold energy：独立检查点

状态：已读 R170 `task_contract.md`，沿已核 R168/R169 定义自行推导；**未读本轮作者稿**。只写本文件，不 Git、不 spawn、不改他人。下面列出精确可用关系与不可省费用，不把 proxy root score 当作原交通付款。

## 1. 变量、支持与闭面先固定

固定同一原接收行、来源 y 和合法时间参数 ξ=c_jt/b。原

    C_i(v)=C((y_i−v_i)/b)>0,
    w_ξ(v)=∏min(1,C_i(v)/ξ),  k_ξ(v)=#{C_i(v)<ξ},
    Π_t=1_{Z_t}w_ξν/e_t.

C、F 不是概率核；Π_t 是原完整支持、原 e_t 归一化的概率，ν、β 不是概率。固定 (omega,V,j,y,t) 的 Π_t 不依 x/外硬 z'，不表示终端 g(x)、w_g、e_g、rho、same-alpha 或尺度选择不依 x。

在 ξ=C_i(v) 上，单坐标权 min(1,C_i/ξ) 连续，严格 k 的值是未激活；其 log 导数左右不同，a.e. 导数为 −1_{C_i<ξ}。因此来源阈值的 log 权没有 hard 值跳；不能将物理 L 的 hard 跳 ell(s) 直接套在这个 ξ 面上。若写 Stieltjes 跳量须固定一致的一侧端点约定，不能把面的正质量删除。

Z_t 可随时间改变；固定 t 的 x 独立性绝不授予 Z_t 在整段 t 上恒定。后面的微分能量恒等式只在固定支持的子窗或另有完整支持变化证书时使用。

## 2. 原 delta 的准确似然比关系

在固定实际 x、核参数与 Q 的时间子窗，令

    r_ξ(v)=KQ(x−v)/(p w_ξ(v)),
    L_ξ(v,u)=log[r_ξ(v)/r_ξ(u)].

核与 p 在该行上固定，w 正，故避开有限阈值或按 a.e. 意义，

    dL_ξ(v,u)/dlogξ=k_ξ(v)−k_ξ(u),
    delta_ξ(v,u)=(dL_ξ/dlogξ)_+.                         (BEA1)

因此原 delta 是这个**来源对当前似然比**的正变差。相反

    d log[w_ξ(v)/w_ξ(u)]/dlogξ=−k_ξ(v)+k_ξ(u).

两个符号不能混用。

原 good(v)、bad(u) 只是终端值门

    p w_g(v)≤KQ_v,   p w_g(u)>KQ_u,

因而 r_g(v)≥1>r_g(u)，L_g(v,u)>0，即 Q_v/Q_u>w_g(v)/w_g(u)。good 等号允许，bad 严格，仍给严格 pair 分离。这个标量门不约束其时间导数符号或正总变差。

对固定 pair，若 ξ0≤ξg，则严格积分关系是

    L_ξg−L_ξ0=∫(k_v−k_u)dlogξ,
    ∫delta dlogξ=(L_ξg−L_ξ0)+∫(k_u−k_v)_+dlogξ.          (BEA2)

除非另证负变差/排序/端点预算，不能将 ∫delta 换成一个端点差。原 u 不可替换成补偿 w 或外硬 z'。

## 3. nearmax N5 的控制对象与相消

R169 N5–N9 控制的是单源 p=P_{s,L}(x−y) 的物理尺度分支 score A_y，以及该 x−y 的 hard 壳层、Tdist/L 和合法单侧窗口。R(x,y)<exp(H) 不自动给 R(x,v)、R(x,u) 的同样上帽。

在 pair 当前比值中，

    log[r_ξ(v)/r_ξ(u)]
      =log(Q_v/Q_u)−log[w_ξ(v)/w_ξ(u)],

共同 −log p **完全相消**。因此即使 A_y 有 root 上界，也没有链式法则将它转成 BEA1 的源阈值差。若另对物理尺度微分 Q_v/Q_u，还会出现两个源核各自的尺度 score；终端 w_g 若沿所选 g 变化，也另有导数/门。它们不能被共同 p 的 A_y 代替。

N5 的原费必须保留：n h²log(e/|h|)、(Tdist/L)h²、真实扩/缩硬壳计数及 ell(s)；N8 还要双侧合法空间和明确壳层/距离条件。作者如将这些作为桥，须给出将**原 Π_t² rho chiJ good/bad delta**支配到这些量的准确不等式和原 dx/beta/nu 下的占用预算。

## 4. 任意相关来源下可合法使用的能量关系

### 4.1 定点方差与原正门

固定原 Π_t。对 k=k_ξ，任意来源相关性下的准确恒等式为

    ∬(k(v)−k(u))²dΠ_t(v)dΠ_t(u)=2Var_{Π_t}(k).

两份同一 Π 的对称性还给

    ∬(k(v)−k(u))_+dΠ²=(1/2)∬|k(v)−k(u)|dΠ²
       ≤sqrt(Var_{Π_t}(k)/2).                            (BEA3)

实际 rho_v chiJ_v 1good(v)1bad(u) 与资格门介于 0,1，故其原非负 inner traffic≤BEA3；这是合法上放，不代表能量已付。若仅归一化 good/bad 子域，其 Π(G)Π(D) 质量因子必须保留，零分母子域按零交通。不能把限制后的源概率无费重置。

k 是 n 个阈值指示之和，Var(k)包括全部协方差项。一般相关 ν/Π 下没有 Var(k)≤Cn 的结论；将其当独立坐标求和不合法。BEA3 若仅给 O(n) 量级，不是 root 交通成果。

### 4.2 固定支持时间窗的 posterior score

仅在 Z_t=Z 固定的子窗，令 τ=logξ、q_τ(v)=1_Zw_{e^τ}(v)/e_τ。权和 e_τ 连续且在非零有限窗有正下界，直接微分给

    ∂_τ q_τ(v)=−[k_τ(v)−bar k_τ]q_τ(v)   a.e.,
    bar k_τ=∫k_τdΠ_τ.

这是原 Π 的 score；其平方积分为 Var(k)，不是未归一化 ν 的 score。对不随时间的测试 F，∂_τ EΠF=−CovΠ(F,k)。这些结论来自同一个实际归一化，不能把 e_t 换为 e_g。

**阈值正面项不能丢。** 每个来源的 k_τ(v) 随 τ 在 τ_i(v)=log C_i(v) 有正单位 jump。用一致端点约定（或将端点放在无面质量处）作 Stieltjes 乘积法则，得到

    d bar k_τ = dFace_τ − VarΠτ(k)dτ,
    dFace_τ =∑_i∫q_{τ_i(v)}(v) δ_{τ_i(v)}(dτ)ν(dv).       (BEA4)

q 在这些阈值时连续，因此跳时取值没有额外左右分歧；k 的严格面值影响端点约定，不能凭 a.e. 导数就把 Face 删除。有限来源时此式直接为有限 step 与连续权的乘积法则；一般有限正 ν 由非负 Fubini/受控微分同样成立。

所以 ∫Var dτ=Face(I)−[bar k]_{ends}，不是单纯 bar k 的端点下降。Face 的总占用尚无一般原预算。Z_t 若移动，BEA4 另有支持/归一化的变化项；必须在原 Z_t 上计全，不能先改支持后沿用固定 Z 恒等式。

时间 Cauchy 可以合法给

    ∫_I ∬delta dΠ²dτ
       ≤sqrt[(|I|/2)∫_I VarΠτ(k)dτ],  |I|≤log2,

但右侧能量、Face、支持与外 raw 测度都仍待付，不能给它改名就登记 root 预算。

## 5. 已有点态核门可用，但不消去 delta

由 good、chiJ 和 wg>0，原已核的

    1good pchiJ≤min(p,KJ/(3wg))

允许对任意固定 θ∈[0,1] 上放为

    1good pchiJ≤(K/3)^θ p^(1−θ)(J/wg)^θ.

这可作为几何/能量桥的核因子，但 delta、Π 的完整支持/归一化、same-alpha 的 rho、source/cell相关性与所有外费仍在。θ 核积分的 root 代理即便成立，也不是上述原加权 pair 交通已付的证明。R168 的 Bernstein future 平均仅控制未取凹幂 P，不自动转移到这些 θ 项或 source-score。

## 6. 作者后审入口与停止点

下一步只审冻结 `shell_traffic_bridge.md` 与 `soft_threshold_energy.md` 中的准确命题，逐项对照：

1. 导数变量、pair 符号、closed faces 与 terminal/current 区别；
2. actual Π_t、Z_t 变化及一般相关 ν；
3. 是否保留 good/bad、same-alpha 和原 u；
4. energy/壳层的真实占用，不把 A_y 或 Var 代理当付款；
5. hard16/3一次、signed2Lambda、time/j/history、外 beta/nu 与 soft/scale 总费。

作者前独立检查点完成；一般 middle traffic 未闭合。保存后停止等待准确冻结稿，不读未指定历史、不扩大研究。


## 7. 冻结 `shell_traffic_bridge.md` 的 S1–S10 后审

已在作者前检查点之后实读冻结全稿。绑定 SHA256：

    cad244af2121451529e81890b1d56e62126921deeb72b27a035892cc28a7d4cf

结论：S1–S10 在显示条件与原 R170 合同下严格通过，无实质数学修订。只认证作者明确的壳层比较与体积价格，不把未付来源偏离或错位时间窗当作已付交通。

### 7.1 C 的严格逆与阈值等号

F 在 core 为 1、外为严格递减的 phi，C 是连续偶函数，C(0)=1、正且趋零。对 0<d<1，滑窗导数 a.e. 为 phi(d+1/2)−1<0；对 d>1，为 phi(d+1/2)−phi(d−1/2)<0。由局部绝对连续性与积分给 C 在正半轴严格递减；d=1 的单边导数差不妨碍结论。

因此每个 z∈[1/2,1] 有唯一 r_z≥0，且 C(t)<z 当且仅当 |t|>r_z。z=1 给 r_z=0，严格 k 面值仍正确，不误变为 ≥。

### 7.2 S1 的 pair 几何与 S2–S3 的闭面

若某坐标不在 S_z、F_v、F_u 内，两个端点距 x 都≤epsilon L，而 ||x_i−y_i|−theta_z|>epsilon L，所以它们距 y 严格同在 theta_z 的同侧，k_v−k_u 的该坐标为0。对其余坐标以正部和控制总和正部，S1成立。shell 定义为闭 ≤、far 定义为严格 >，覆盖所有等号，无需删除超平面或假设坐标独立。

S2 的 theta−epsilon L>L/2 是严格左门，theta+epsilon L≤Le^r/2 是闭右门，正好把闭 S_z 嵌入 N_+ 的 (L/2,Le^r/2]。可用窗非空必须 epsilon<(e^r−1)/4，作者未把必要窗当全部实际时间。由 C 严格递减，z 的下端闭、上端严格方向正确。

在实际 z≥1/2 的截窗上 log C 的 Lipschitz 常数≤2。若未截的下端落到 C<1/2，只会缩短实际窗，仍可用相同截断比较。故 log z 长度≤(L/b)(e^r−1−4epsilon)≤e^r−1，再与原 log2 帽取小，S3 的 tau_r正确。dt/t=dz/z 保持原 j,b，其他实际门只缩短时间窗。

### 7.3 S4–S6 的完整 FIRST 与归一化

S4 与独立 GA3 的 hard-entry 比较一致：非跨界单坐标 f_s 不减，跨界比值至少 exp(ell(s))，n 维物理因子为 exp(−nr)。未来尺度 Le^r 必须≤b，软度为原当前 s，故这个 receiver 上的测试共同且合法，不依 y 另选。

由当前 FIRST **等式** ∫p_x(y)f(y)dy=q，mu(dy)=p_x(y)f(y)dy/q 是总质量 1 的概率。S4 与未来测试给 E_mu exp(ell N_+)≤exp(nr)，Jensen 于是给 E_mu N_+≤nr/ell（s<1）。随后才使用非负测度包含 Σ beta_V≤fdy，得到 S5。trivial N_+≤n 给另一个 nq 帽，两者取小正确。

关键归一化未丢：作者没有把 p beta/q 子概率直接当概率用 Jensen，没有给每个叶或 y 另领一个 q。如果去掉当前等式，仅有未来上界，这个具体 Jensen 常数不能原样无条件沿用。

S6 是同一 mgf 的 Markov 上尾，先 beta≤f 后用共同测试，方向与常数正确。s=1 时 ell=0，作者仅保留 nq；s↓0 的 nr/ell 费用显式而非隐藏。s=0 本身不在需要 log(s) 的命题中。没有 soft 菜单费，因使用的软度就是当前 s。

### 7.4 S7–S9 的实际权与完整价格

W=rho chiJ good bad 是原同-alpha 权且 0≤W≤1。乘 S1 并在原完整 Π_t² 上积分，再仅在 S2 用 S_z≤N_+，即为 S7。第一项可以上放 N_+，其余保留原 u、rho、chiJ、支持与概率归一化，未作 source 置换或 transpose。

在壳层项，分支不依外 hard 来源，正门上放后一次 hard16/3 与 signed2Lambda 合成 32Lambda/3。N_+(x,y;r) 不随 t 改变，Π_t² 的总质量在每个 t 为1；对齐窗长≤tau_r，可先取其长度帽，不需要错误冻结终端门。再以 S5 合并原叶来源，得到 q min(n,nr/ell(s(x)))，最后付原 j≤n+2。故 S8 的

    (32Lambda/3)(n+2)tau_r q E∫_E min(n,nr/ell(s(x)))dx

准确，无遗漏 n、归一化或来源总质量。s=1 按 min 值 n 处理，未对零 ell 除法。

E_A^src 仍是同一原 raw 分支将 delta 换成 F_v+F_u 的量，保留 q^(−1)h_R a_omega dnu(z')；没有预领第二次硬帽或将该误差称已付。若实际额外来源局部分支 F_v=F_u=0，误差确为零；再有 ell≥ell_*>0，就得到 S9 的 n(n+2)r tau_r/ell_* 显式体积价。它是条件局部分支，非 W_beta 价，也不认证覆盖一般中间域。r 缩小会同步收窄对齐与来源局部门，作者已保持这个代价。

### 7.5 S10 的真实 dx 检验

对固定 v、固定 L≤b，J_b 的产品归一化直接给

    ∫J_b(x−v)F_epsilon(x,v)dx
      =n[1−∫_{−epsilon L/b}^{epsilon L/b}phi]
      ≥n[1−2epsilon phi(0)].

这只 tensor 固定核，不使用 ν 坐标独立。L=L(x)≤b 时，F_epsilon(x,v)≥∑1_{|x_i−v_i|>epsilon b}，故同一下界仍成立，但不将原等式误称适用于自适应 L。小 epsilon 下自然全空间计数费线性，正确说明单独核归一化不能付款；该式并非所有原门同时实现的反例。

bad u 端没有自动 J_u 权；χJ_v 不能免费转给 u、不能对称化后丢资格/alpha。未对齐时间的 C-threshold shell 也不能无费换成物理 hard shell。作者保留这两处准确缺口。

### 7.6 判定与停止

通过的是 S1 的真实 source-pair 比较、对齐窗、完整 FIRST 归一化的壳层一阶矩及 S8/S9 的显示体积费用。未付仍为 E_A^src、未对齐时间和这些局部源偏离的原加权预算；没有新的一般 root 或 W_beta 交通声明。

本指定冻结稿审查完成，停止等待 `soft_threshold_energy.md`，不扩展研究。


## 8. 冻结 `soft_threshold_energy.md` 的原负信用与 filtered 后审

实读全稿并复核 R117 JG1–8、R121 GL1–5、R128 `research.zip:proof.md` 489–523 的必要原定义。冻结稿绑定 SHA256：

    e57860681e0f9cfda58382bfa16aa8d92d8d64e9329056656dd96e02d019d556

结论：式 (8)、(11)–(16) 在稿件明确的完整行、原未消费负项和统一终端比值条件下通过。新证明支付的是初始 filtered 项与全部删除上跳的联合边界，以及进一步满足三项兼容/排序条件的原 signed 分支；没有证明一般正 delta 交通已付，也没有证明该条件分支覆盖新的 FULL 正交通实例。

### 8.1 原负项确实可用，但只能同一完整行分配一次

原 R128 的当前母账是 `2Lambda(P_rem−N_Zc−N_del)`；N_Zc 保留原 suffix 补集 Psi 的全部 survivor 反向分数负项，不跟随更严的正项空间、FA、capture 等门。原 N_del 保留当前仍存活、将来删除的来源对负项。已在原 suffix Z 上消费的负信用不在这个母账中。

作者 (4) 的 G×B 负项是 `−Psi D_minus`，没有乘 A、eta；E_t×B 负项没有乘 Psi、A、eta 或终端 good 门，方向与母账一致。将全部 survivor G 保留而仅给正项加 A、eta，是合法地保留原信用，不是添加新的负信用。特别 A=0 的 G 来源仍可贡献原反向负项，它随后准确出现在 R_rev 中。

允许按完整 `(omega,V,j,x,y,zprime,原历史)` 行乘一个共同可测指示来划分母账，包括依赖 x、y、zprime 的行条件；指示必须在该行辅助时间内固定，且原正项和两类未消费负项同乘。对不交叠行分支，这就是原有限截断积分的线性分割，每份负项只分配一次。这里是对原交通作分析性分区，不改变原来源或选择器。不能按 t 或 `(v,u)` 单独筛正项后，再取用该完整行的全部母账负项；也不能同时把本分支负项留给补集。

### 8.2 式 (8) 独立代数核验：符号、阈值与删除

对连续段，冻结 A，直接微分 `F=NA/e` 得

    −F' = Cov_Pi(A,k)
         = C_GG + C_GE + integral_(G×B) A(v)D(v,u) dPi².

这里 A 在 B 与 E_t 均为0。G×G 的二分之一系数、G×E_t 的单次交叉系数均正确；没有使用坐标独立性或 source transpose。

逐对恒等式为

    Psi[A eta D_plus−D_minus]
      = Psi A D−Psi(1−A)D_minus−Psi A(1−eta)D_plus.

把 `Psi A D=A D−(1−Psi)A D` 代入，并在真实连续段积分，得到作者 (8) 的所有符号：初始 F 为正，终端 F 为负，全部删除跳为正，C_GG、C_GE、H_Z、R_rev、R_eta 与 N_del 均带负号。H_Z 一般没有固定符号；删除它等于重新取用已消费 suffix 信用，不能这样做。

阈值面 C_i=z 只改变 k 的面值；wt 自身连续且对 log t 局部绝对连续，所以此处只微分 wt 时没有额外阈值原子。source 质量可在阈值面上，仍然成立。真实禁块删除另外产生有限跳跃，不能与连续阈值混同。

支持 A 包含于固定 G⊂Zg⊂Zt。故真实删除 H_t 与 A 支持不交，`NA(t)=integral_G A wt dnu` 在该删除时刻连续；它在连续时间只随 wt 下降，绝不是整个区间固定。于是

    Delta F = NA(t)[1/e_after−1/e_before]
            = F_before d_t/e_after.

端点按原单侧值分配一次。若另外选择多个时间区间，每段须另付端点；作者没有把任意时间集合当成一次 FTC。所有 signed 等式先在原有限截断成立，不能通过 infinity−infinity 延拓。

式 (9) 的 `1−A≥1−rho` 正确，原 alpha≥0，由 `U≤D K0`、`K0 nu≤q` 可得。对 TDelta>0，其右侧确为 min(1,(DK0+alpha J)/(TDelta))。它属于现存 R_rev 的一部分，不能再作为第二份 RC 负信用。

### 8.3 式 (11)：终端权重比值是明确条件，跳跃统一望远镜

在 {A>0} 上假设 `w_initial≤exp(M) wg`。由 wt 递减，全部相关时刻有 `NA(t)≤exp(M) C_A`。所以每个删除跳用同一个分子上界，得到

    F_initial + sum Delta F
      ≤ exp(M) C_A [1/e_initial + sum Delta(1/e)]
      ≤ exp(M) C_A/e_g.

最后一个不等式用 1/e 的全部连续与跳跃增量非负，以及 e_t≥e_g>0。只求删除跳的倒数增量小于全部倒数增量；不能把连续下降漏掉后写成等式。无删除次数、最小 e 或 log(e_initial/e_g) 的隐藏费用。端点删除若计入本段，分子仍连续并以相同倒数跳计一次，但这不退还原 near/初始/其他边界账。

M 必须是在本付款分支统一可上放的非负常数；若 M 随完整行变化，则保持 exp(M(row)) 的费用，直到确有统一界。FIRST、nearmax 或 high 都没有自动给 (10)。条件 `M≤log(n)/2` 才把此处的 exp(M) 变成 sqrt(n)。

### 8.4 式 (12)–(15)：保留实际 dx、high 配对和全部常数

终端 good 给 `p wg≤KQ`，且 `A≤chiJ=J/(3Q)`。逐来源乘积后积分，得到

    p C_A≤(K/3) Jnu(x).

此步既没有丢原 good 端，也没有将 receiver 自适应的 p 当成对 x 的归一化核。一般相关 nu 可直接使用。

对同一个 receiver 的当前核与 q，high 给 `1_H/e_g≤p/(2Kq)`；原 beta≤f 与 FIRST 给 `integral p dbeta≤q`。所以式 (13) 恰是 1/(2K)，不是来源概率归一化。分支可同时依赖 x、y、zprime，只要与原正负账同切；对每个剩余固定行参数，非负分支指示上放至1，再使用同一 p、q 的 beta 积分即可。q 或当前核不得按 y 另选。

结合两式，边界来源行价为 `exp(M) Jnu(x)/6`。保留实际 `1_{j(x)=j}` 到这个对 j 一致的上界后，再合并唯一 j，无需 n+2。若先放松为每个 j 的全积分，则不能再免去层数费。

对实际 hard 来源仅一次使用 `q^(-1) h_R nu≤16/3`，并将原 a_omega≤1 上放；这给

    signed2Lambda × hard(16/3) × high-good(1/6)
      =16Lambda/9.

J=P_(1,b) 的 b 是原固定 block 参数，故 `integral_x Jnu(x)dx=||nu||`。随后原 `E sum_V||nu_V||≤W_beta` 给 (15)。若改成 receiver 自适应 b(x)，该空间积分就不能原样使用；作者与合同均明确固定 b。没有另领 history 或来源总质量。时间已经以 FTC 积分，不再乘 log2；两个 Pi 因子始终完整。

### 8.5 式 (16) 的准确 coverage 与未付项

作者四条件中：(10) 与 M≤log(n)/2 控制边界；`A(1−Psi)=0` 消去 H_Z；G×G 的联合同序保证 C_GG≥0；活跃 A 与 E_t 的联合排序保证 C_GE≥0。其余 F_terminal、R_rev、R_eta、N_del 原本非负。因此这些完整行共同条件下，(8) 确实给 (16) 的 signed sqrt(n) 费用。

这些是对几乎全部辅助时刻/来源对的完整行条件，不是“只在排序成立的时刻取正交通”的选择。没有源坐标独立、2^n masks、自由来源置换或重新选择 alpha。s=0 或1 未出现除 s、log s 或 1/(1−s)；只要原行 e_g>0、有合法 good/high 及冻结 A，以上代数与条件定理不发生软度端点奇异。e_g=0 的行不属于需要归一化的 high 行。

尚未证明这些条件在原中间域覆盖新的 FULL 正交通实例，也未证明所有条件失败行的总费用。特别一般 C_GG、C_GE、H_Z 可为负，exp(M) 可很大。同 alpha 本身不推出排序，式 (9) 也没有自动控制这些缺陷。式 (17) 是准确的未付 signed 缺陷账，不是已经支付的能量。式 (18)–(19) 仅对共同来源测试函数有效，不能用于依 y 变化的 k_y、A_y、rho_y。

### 8.6 主稿绑定检查与停止

已对读主稿 `proof.tex.txt` 的 filtered 节，当前 SHA256：

    d843e9c9fb39fd50a742387b569d50b1f232d1149931fd5e6010bab4f5ff7880

数学与冻结能量稿一致，明确保留终端比值、大 M、排序失败和剩余分支未付。主稿正确说明 A 分子随连续 wt 下降而删除时不损失 A 支持。已向父级建议补入“完整行时间独立共同指示同时分配原正项与两种未消费负项、每份只用一次”的明文，使浓缩主稿的条件 signed 声明自足；这不是能量稿的实质缺口，能量稿第1、5节已写明。

本审查未以有限后验数值替代原合同证明，也未把边界价当成独立正 delta 交通价。指定独审完成，停止，不扩展研究。
