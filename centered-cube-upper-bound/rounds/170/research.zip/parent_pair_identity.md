# Parent checkpoint: actual uncaptured measure and the exact remaining column

This is an algebraic target specification, not a new paid branch. It is written before reading author proofs. Use the R170 contract, fixed actual x,j,y,t. Write

\[
 A_y=q-D^{-1}\int U_y\,d\nu=\alpha_yQ_J/D,\quad
 c_y(u)=U_y(u)/(D K_0(x-u)).
\]

For 0<s<=1 the kernel is positive. Since FIRST gives K0nu<=q and 0<=c<=1,

\[
 A_y=(q-K_0\nu)+\int K_0(x-u)(1-c_y(u))d\nu(u).
\]

If A_y>0, define the subprobability

\[
 d\mu_y(u)=K_0(x-u)(1-c_y(u))d\nu(u)/A_y.
\]

Its missing mass is (q-K0nu)/A_y. On actual bad sources U_y=0, hence c_y=0. Therefore for every nonnegative measurable H,

\[
 A_y^{-1}\int_{\mathrm{bad}}H(u)d\Pi_{y,t}(u)
 =\frac1{e_{y,t}}\int_{\mathrm{bad}\cap Z_{y,t}}
 H(u)\frac{w_t(y,u)}{K_0(x-u)}d\mu_y(u). \tag{P1}
\]

Both sides have the original support, weight and normalization. No symmetry in y,u is assumed. If A_y=0, then both nonnegative terms in its decomposition vanish; in particular bad has zero nu measure because K0>0. Thus the two-source good/bad contribution is zero, even though conclusions about all other traffic would require care. This is different from q-K0nu=0 alone, which does not imply alpha=0.

Let d_y(v)=[1-DK0(x-v)/(TDelta_y(v))]_+ and G_y(v)=TDelta_y(v)d_y(v)^2/w_g(y,v). The same-alpha envelope gives

\[
 A_y\rho_y(v)\le Q_J T\Delta_y(v)d_y(v)^2/(4D J_v).
\]

Using chiJ=Jv/(3Qv) and good p/Qv<=K/wg, the hard-source-reduced row is bounded by

\[
 \frac{KQ_J}{12D}\int d\beta(y)\int_{\mathrm{good}}d\Pi_{y,t}(v)
 \frac{G_y(v)}{e_{y,t}}
 \int_{\mathrm{bad}\cap Z_{y,t}}
 \delta_t(v,u)\frac{w_t(y,u)}{K_0(x-u)}d\mu_y(u). \tag{P2}
\]

All original middle/terminal/history indicators may be retained; dropping them only enlarges the nonnegative expression. P2 does not by itself pay the receiver integral. In particular beta remains a finite source measure rather than a probability, mu_y depends on x,j,y, and the ratio wt/K0 plus e_t inverse has not disappeared. Merely calling mu a Markov or capture kernel does not establish a column bound.

The precise sufficient next estimate is a uniform O(sqrt(n) n^o(1)) bound on the three-integral factor in P2, with actual source and scale dependencies accounted for, or a direct integrated QJ dx bound by sqrt(n)n^o(1)Wbeta. A conditional bound must state its real gate and remaining complement. This checkpoint is an exact specification of the missing estimate, not a claim of progress from renaming it.
