# R170：bad来源储备与源阈值协方差的独立证书

## 1. 准确对象、等级与结论

先独立读R170合同、R169来源定义及冻结R168/R169证书，再与数值作者确定observable。本稿不搜索位置或ν，不重跑allfuture、原子补全或平滑；只在同一有限行核验储备、原倾斜权归一化和源阈值统计。

沿冻结几何n=4、y=0、x=(51/100,2/5,2/5,2/5)，s=1/4、L=9/10、R=b=1；原三源位置为

\[
z_0=(53/50,19/20,19/20,19/20),\quad z_1=(-3/5)^4,\quad z_2=x,
\]

\[
\nu=(3/25,2749/3125,1/3125),\quad q=9/2500,
\quad G=\{0,2\},\quad B=\{1\}.
\]

其中ν按上述质量理解为原子测度，不是一般原来源的概率归一化。以下Π是按定义归一化的有限倾斜测度；为此有限检验固定Zξ=全部三源，**没有认证原Z/Ψ资格**。

主要严格结果为

\[
\frac{D\int_BK_0d\nu}{\alpha Q_J}
\in[.00047782444378,.00047798624079]<.0006,
\tag{P1}
\]

而在整个ξ∈[.51,.53]，

\[
\Pi_\xi(B)\in[.99540059062134,.99600421901368]>.99.
\tag{P2}
\]

这说明本有限行中“大bad后验质量”与“bad贡献大部分α储备”并不等价。区别在于K0来源加权及wξ/eξ归一化。它不否定已证bad储备不等式，也不是FULL/L1或一般积分反例。

## 2. 原same-α的精确bad分解

以下先对一般同一行推导。设D>0，A_y(v)=TΔ_y(v)，B_0(v)=DK0(v)，G+=G∩{Δ>0}，G0=G\G+。原定义是

\[
U_y=1_{G_+}\min\{A_y,B_0\},\qquad
\alpha_yQ_J=Dq-\int U_y d\nu.
\]

因为K0对外y共同、原FIRST给K0ν≤q，逐项恒等式是

\[
\boxed{\alpha_yQ_J
=D(q-K_0\nu)
+D\int_BK_0d\nu
+\int_{G_+}(DK_0-T\Delta_y)_+d\nu
+D\int_{G_0}K_0d\nu.}
\tag{P3}
\]

每项均非负；不是另选α或删来源。若某good v的ρv>0，则A_v>DK0_v，故该v自身的未捕获储备项为0；α仍可由其他good、bad以及共同FIRST差额产生。

bad项确实给D K0_badν≤αQJ。但对原Πξ，准确的加权式为

\[
\int_B\frac{K_0}{w_\xi}\,d\Pi_\xi
=\frac{\int_{B\cap Z_\xi}K_0d\nu}{e_\xi}
\le\frac{\alpha Q_J}{De_\xi}.
\tag{P4}
\]

这里K0/wξ不能删掉。已知high、eξ≥eg与QJ≤q可给既有ER7–9；本稿不重报其付款。普通Πξ(B)只积分1，无法由(P4)在没有K0/wξ下门时替换出来。

### 2.1 本有限行的严格分账

N=K0ν、R=q−N。目标source0满足A0>DK0_0，source2满足0<A2<DK0_2，source1为bad。因此(P3)在这里精确简化为

\[
\alpha Q_J=(q-N)+\nu_1K0_1+\nu_2(K0_2-A_2),\quad D=1.
\tag{P5}
\]

N64/N128两级认证所有符号、good/bad分类与分母正性，得到(P1)。再使用R169已审原子F=ν+Mδr的**既有M区间**，只作储备分账，不重跑其allfuture证明。对formal β=ν，继承的精确恒等式为

\[
\alpha Q_J=(q-K_0F)+K_0(F-\beta)
+\int K_0(1-c_y)d\nu,
\quad c_y=U_y/(DK_0),\ D=1.
\]

四个非负部分占αQJ的区间如下；各区间分别外包，端点不要求相加恰为1：

| 部分 | 严格比例区间 |
|---|---|
| q−K0F | [.96271875259908,.96272479229878] |
| K0(F−β)，formal β=ν | [.00016914813710,.00016917189852] |
| good未捕获项 | [.03662846415166,.03663386025125] |
| bad未捕获项 | [.00047782444378,.00047798624079] |

本例α主要来自共同FIRST差额，并非bad来源。若以d_v=(1−DK0_v/A_v)_+为未加α的ρ基线，则实际relative suppression为αJ_v/(A_v d_v)，只用bad储备下界所保证的relative suppression为[D K0_badν/QJ]J_v/(A_vd_v)，二者之比精确为(P1)。程序还严格认证总suppression>.85，而bad-only suppression<.0006；不能把bad贡献小误写成α本身小。不能把这个单行结构推给一般middle。

## 3. 源阈值协方差：完整保留归一化与支持

取有限来源质量ν_i≥0，核几何Ciℓ>0。先在Zξ固定、eξ>0的参数片段，写

\[
a_i(\xi)=1_Z(i)\nu_i\prod_\ell\min(1,C_{i\ell}/\xi),
\quad e=\sum_i a_i,\quad\pi_i=a_i/e,
\quad k_i=\#\{\ell:C_{i\ell}<\xi\}.
\]

ν总质量不需为1。离开有限阈值点，按τ=logξ求导：

\[
a_i'=-k_i a_i,\quad e'=-e\,\mathbb E_\pi k,
\quad \pi_i'=\pi_i(\mathbb E_\pi k-k_i).
\]

因此对不随ξ变化的源observable f_i，准确有

\[
\boxed{\frac d{d\log\xi}\mathbb E_{\Pi_\xi}f
=-\operatorname{Cov}_{\Pi_\xi}(f,k).}\tag{P6}
\]

若f也依ξ，应加EΠ f′，不能只保留协方差。对固定片段内的k本身，dEΠk/dlogξ=−VarΠk。

协方差的有限分子式是

\[
\operatorname{Cov}_\pi(f,k)
=\frac1{2e^2}\sum_{i,j}a_i a_j(f_i-f_j)(k_i-k_j).
\tag{P7}
\]

Var对应把两个差都取k差。此式直接保留两份e分母，适于有向区间认证；无需假设源坐标独立。e=0沿原零交通约定，不对它除法。

### 3.1 时间阈值及Z变化不能免费忽略

固定Z时，wξ连续，因此Πξ在Ciℓ阈值处连续；f固定时(P6)可逐片积分，没有归一化跳项。但k自身在阈值ξ0跳跃，EΠk的跳量为Σ_iπ_i(ξ0)·# {ℓ:Ciℓ=ξ0}，不能把dEΠk在整个区间都写成纯负方差。

若Z也改变，令a_i^±为两侧真实未归一质量。对同一固定f，e^±>0时精确跳变为

\[
\mathbb E_+f-\mathbb E_-f
=\frac{\sum_i(a_i^+-a_i^-)(f_i-\mathbb E_-f)}{e^+}.
\tag{P8}
\]

必须计入新增/删除来源与新归一化；任意可测Z_t若未证明分段正则，不能先套微分公式。对于相同支持的两个阈值ξ1,ξ2，另有完全有限的比较式

\[
\mathbb E_{\Pi_2}f-\mathbb E_{\Pi_1}f
=\frac{\operatorname{Cov}_{\Pi_1}(f,r)}{\mathbb E_{\Pi_1}r},
\quad r_i=w_{\xi_2}(i)/w_{\xi_1}(i),\quad
\mathbb E_{\Pi_1}r=e_2/e_1.
\]

新支持超出旧支持时不能定义该比值来遗漏新增质量，应回到(P8)或原有限求和。

### 3.2 与原good/bad正计数差的关系

固定同一G/B，令a(v)=ρvχJ,v1G(v)，b(u)=1B(u)。对同一个Π，signed pair为

\[
\iint a(v)b(u)(k_v-k_u)d\Pi(v)d\Pi(u)
=\mathbb E b\,\operatorname{Cov}(a,k)
-\mathbb E a\,\operatorname{Cov}(b,k).
\tag{P9}
\]

原positive-part pair减去对应backward pair才等于(P9)，不能将δ=(kv−ku)+直接替换成signed差。若去掉ρχ、取a=1G且G/B分割全支持，signed pair简化为Cov(1G,k)。原p的接收score不是这里的来源阈值k；不能用共同p-score抵消后假称δ已控制。

全支持无权pair满足Eδ=(1/2)E|kV−kU|≤sqrt(VarΠk/2)，只用两次同Π抽样，不要求坐标独立。但归一化本身不给VarΠk=O(n)：抽象二源Π=(1/2,1/2)、k=(0,n)已有Var=n²/4。这只是说明额外相关几何不可省略，不是原FULL反例或新付款。

## 4. 本例的全时间窗协方差区间

本例在整个[.51,.53]，区间严格认证所有target Ci<.51，另两源全部Ci>.53，所以k=(4,0,0)。固定Z=全部三源，令

\[
A_C=\nu_0\prod_\ell C_{0\ell},\quad
z=A_C\xi^{-4},\quad B_*=\nu_1+\nu_2=22/25,
\quad e=z+B_*.
\]

于是

\[
\Pi_0=\frac z{z+B_*},\quad\Pi_1=\frac{\nu_1}{z+B_*},
\]

\[
-\operatorname{Cov}(1_B,k)
=4\Pi_0\Pi_1=\frac{4z\nu_1}{(z+B_*)^2},
\quad\operatorname{Var}(k)=\frac{16zB_*}{(z+B_*)^2}.
\tag{P10}
\]

认证z<B_*使右侧均对z递增；用ξ两端、C乘积的有向区间即可覆盖整个窗，**并非只在midpoint验证**。N=128结果向外简写：

| 量 | 全ξ窗的严格包围 |
|---|---|
| eξ | [.88320911016936,.88374470367844] |
| Πξ(B) | [.99540059062134,.99600421901368] |
| Πξ(target good) | [.00363346588300,.00423731385643] |
| −CovΠ(1B,k) | [.01447578939647,.01687129886134] |
| VarΠ k | [.05792422093898,.06750974444331] |
| ρχJ加权原good/bad δ-pair | [.00184828562241,.00216784111744] |

源0是唯一正score good，bad仅源1；源2的k=0。因此(P10)恰等于此窗的无权good/bad正δpair，backward pair为0，而非仅signed界。加权式仍保留同一原ρ与χJ；它只是dimensionless内pair，不含raw的p/q、hard、外β、history、dx或2Λ等价。

(P6)在此窗给dΠξ(B)/dlogξ=4Π0Π1>0。bad后验增大来自目标源的倾斜权ξ^−4下降及eξ归一化，并不要求bad K0储备大。

## 5. formal β=ν的已付reserve门检查

仅作与数值作者一致的conditional row诊断，令formal β=ν，则B=N=K0ν，R=q−N。R169门为

\[
\sqrt n\,N\,\frac{T\Delta_v d_v^2}{K0_y w_{g,v}}\le R.
\]

对唯一正score good源0，本证书得

\[
\frac{\sqrt n\,N\,T\Delta_0d_0^2}{R K0_yw_{g,0}}
\in[22.22443876275,22.24982012735]>1.
\tag{P11}
\]

所以在此整个时间窗，formal row的正ρχδ-pair均未落入该门，formal加权覆盖比例精确为0。但formal β=ν在y=0没有来源质量，这**不**认证实际外β交通的零覆盖，也不反驳已付条件预算。原子F及有限支持仍不提供L1、耦合β、原Z/Ψ或history。

## 6. 精度、三阶段、真实费用与交付

初步为ξ=.52的N64有向区间；已有压力为同原窗两端.51/.53；扩大阶段为整个闭窗的解析单调包围及N128加细。bad储备不依ξ，双精度层均认证其比例<.0006。全窗协方差、归一化和formal门同时留档。没有扩大ν或位置菜单。

复算：

```sh
python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/170/work/pair_certificate.py
```

脚本使用冻结R166/R168的有向Decimal、认证Taylor指数尾、E3/E4凸上下和、认证log及整数sqrt。全部bound不经过float/mp。读取R168 refined选择与R169 completion的既有M区间，完整输入SHA保存在JSON；同α由全三源U重新按定义计算，没有重跑allfuture或平滑。运行约2.6秒，代码/JSON只写本责任文件。

成功是严格验证了(P1)与(P2)的并存，并给出(P6)–(P10)在原有限倾斜权、真实归一化和支持条件下的精确形式。这选择下一步应检查的机制：必须处理K0/wξ容量与来源阈值计数的联合几何，单看bad后验比例或共同p-score不够。

仍缺的是原实际来源/接收/history测度下这种联合几何的可积价格；本稿没有从有限行推断该价格存在或不存在。原q^-1、hard帽16/3（至多一次）、时间log2、j/唯一归属及外Wβ都未在这里支付或删去。全部结论为bounded checkpoint，不作FULL/L1或一般中间域付款宣称，交付停止。
