# R170 y依赖未捕获reserve核：精确工具合同

**结论：所查F05/G03/D01/E01没有一项已核来源直接控制当前“两个原来源因子＋实际receiver dx”的未捕获reserve积分。** 最可操作的充分条件是F05的两侧weighted Schur证书；目前只恢复出来源row，缺真实column及原交通到算子的映射。G03私有捕获映射保持evidencepending。本文件只核接口、来源状态与必要历史，不认证本轮新核引理。

## SP1. 先固定实际核，避免把y依赖reserve当共同row

按本轮合同，固定原x,j及共同输入β,ν，令
\[
 r(v)=d\nu/d\beta(v)\in[0,1],\quad c_y(v)=U_y(v)/(DK_0(x-v))\in[0,1],
\]
\[
 \mathfrak R_y=\alpha_yQ_J/D
 =q-K_0f(x)+K_0(f-\beta)(x)
 +\int K_0(x-v)[1-r(v)c_y(v)]d\beta(v).
 \tag{SP1}
\]
原s>0使K0>0；退化零交通行先排除。每个右端项非负，但c_y及分母依原y，不能分别领取各项后仍保留整份同α余额。\(\mathfrak R_y>0\) 时，一个明确的候选来源算子核是
\[
 \mathcal K_{x,j}(y,v)=\frac{K_0(x-v)[1-r(v)c_y(v)]}{\mathfrak R_y},
 \qquad \int\mathcal K_{x,j}(y,v)d\beta(v)\le1.
 \tag{SP2}
\]
这只是该核的row帽，不宣称它已经支配当前含ρ、δ、Π²的正交通。原加权三槽的source边缘仍须另算。核一般不对称；没有已证PSD/Gram表示；c_y(y)=0也不给L1来源上的正对角质量。ν≤β只给子测度支配，不给第二来源边缘相同、不把β归一化为概率。

若父级采用与SP2略不同的正核，应把下面每个谓词对那个**明确核**重新验证，不能靠“reserve kernel”同名套用。

## SP2. 四项工具的实际可用范围与缺失谓词

本轮读取各相关SKILL及下列绑定方法/来源合同；没有新调用未读外文定理。F05的Cauchy–Schwarz、有限流方程或势证书的充分方向均可直接核验，不需要假设一般强对偶。

|工具与绑定来源|精确可用条件|当前核的匹配与未满足项|
|---|---|---|
|F05 `math-f05-l2-spectral-parameter-schur-test/SKILL.md` 执行1–4；`references/method.md` 1–4、6–8|两σ有限底测度m_out,m_in，可测核A及正权a(y),b(v)，同时有∫|A(y,v)|b(v)dm_in≤R a(y)、∫|A(y,v)|a(y)dm_out≤C b(v)，且R,C对全部保留参数统一，则L2范数≤√RC。独立证明来自逐行Cauchy、Tonelli及column界。|对SP2取两侧β、a=b=1，第一式R=1已得；第二式 \(\int\mathcal K_{x,j}(y,v)d\beta(y)\le C\) 未得。\(\mathfrak R_y\)依y，不能用共同α或ν≤β把它提出。若目标包含dx，须给lifted output measure及对x,j/time/selector的column预算；固定x范数不付原dx。即使Schur成立，仍须证明原ρδΠ²可由该bilinear form和已付L2振幅支配。|
|G03 `math-g03-directional-capture-tree-quadratic-audit/SKILL.md` 当前状态及执行1–7；`references/source-contract-P-e8f8.md`|当前只认证明确有限Hermitian/PSD矩阵算术；私有树、方向、可行捕获叶、来源→Gram及同输入谓词必须正式定义。P-e8f8的实际来源限单位圆盘D、有限正Borelμ、原点归零Bloch空间B°，admissible有限嵌套面积分割/L1条件期望极限、固定排序、实际reduced Bergman packets P0 1_R及同μ的有限packet-Gram。|当前ℝ^n核SP2不具有该Bergman表示/圆盘空间，也无正式私有捕获映射。全1 PSD矩阵即可有对角1、最大特征值N及ones二次型N²；对角/PSD不控制source交叉项。来源所依Bergman表示、SDP/Grothendieck外引仍open；本题捕获适用性必须标evidencepending，不能用G03作核估计定理。|
|D01 `math-d01-kantorovich-duality/SKILL.md` 执行1–7及`references/method.md`|静态正OT先指定等总质量边缘和可行coupling。max上界可直接用cost≤φ(y)+ψ(v)并积分已知边缘；一般cost强对偶/势达到另需匹配拓扑/成本定理。向量KR要求Polish度量、有限维欧氏靶、总向量质量0及一阶矩；P1π−P2π=μ不是两个正边缘。路径SOT另需闭凸/统一有界特征、小跳统一条件、成本可测lsc/凸等。|由SP2定义γ=K β⊗β，仅第一边缘≤β，第二边缘未知；ν≤β不补等边缘。可用非负势与已证明边缘上界作弱证书，但当前缺第二边缘/势预算。交换y,v会改变c_y、α_y、Z/e和资格，故没有免费转置coupling。向量/路径模型也无已证映射；不调用其强对偶。|
|E01 `math-e01-occupation-measure-flow-lp/SKILL.md` 执行2–7；`references/frozen-source-locators.md`|独立有限MDP构件：有限状态动作、μ0概率、归一转移P、γ_discount∈[0,1)，occupation满足outflow−γP*inflow=μ0，总质量1/(1−γ)。连续Dynkin/Liouville需实际过程/生成元、合适测试函数、初末质量/可积性；弱LP不自动无gap/轨迹恢复。冻结modal来源只在共同时间边缘及compact/continuous数据下作弱LP投影/合并；均场二次项还需PSD/交互权非负才谈凸性。|原Π_t是删源条件存活后的非线性归一化，非已给归一Markov转移的保质量流；未给初始过程、killing/注入/终端规则及真实occupation质量。只凭μ_t单调不能声明其能量是E01某个flow成本。若构造killed流，归一条件化与删除通量须显式，不能把失去的质量抹去。两个来源因子也不是自动线性occupation目标。|

F05方法所列Bennett逆向保持citation-only，Birman–Solomyak/Peller转述不替代当前核的因子化与端点。D01来源已读卡不等于本题适用。E01的固定标量终止时刻与任意随机停止LP等价在已核来源中有反例；若能量路线引入停止，必须先规定是哪一个模型。以上不使用任何私人“捕获”“occupation”“transport”名称补定义。

只有row不足的最小算术压力：有限β为N点均匀概率，K(y,v)=N·1_{v=v0}则每row积分1，而column v0积分N，L2算子范数√N。它只否定“单侧row推出统一Schur”的一般推理，不声称该矩阵能实现原几何。要取得新付款，必须利用原K0、c_y、同α/窗口结构真的证明column，而非再作row归一化。

## SP3. Z_t/e_t的原冻结单调合同（能量路线可用）

仅回读两份已明定位的历史小段，不通读全历史：

1. `rounds/117/research.zip:proof.md:29–52`（JG1–2）固定同一ω,V,j,y，
   \(A_i(y,v)=bC(|y_i-v_i|/b)/c_j\)，
   \(Z_t=D_V(y)\cap(T_0(y)\setminus A_{j,t}(y))\)，
   \(\mu_t=1_{Z_t}w_t\nu_V,e_t=\mu_t(\mathbb R^n),\Pi_t=\mu_t/e_t\)。原最粗light禁块A_j,t随t扩张，取右连续、有限跳跃、跳间恒定的既定版本；w_t非增，故μ_t按测度序非增，e_t非增。不能在单时刻插入新禁块或换support。heavy为 \(e_t>B_jt^n\)、\(a/c_j\le t\le bc_j\)，非空集是从τ_j开始的初始区间，右端可含可不含；在区间内e_t有限正。**Π_t并不按测度序单调**。
2. `rounds/135/research.zip:proof.md:123–152,186–200` 固定ν/正阈值，u=log t时w_t连续且a.e.导数−k_tw_t。严格k_t取左态；Stieltjes均值采用右态k̄_t，阈值注入计坐标重数。固定support有dEΠ k̄=dC−VarΠ(k)du，实际原Z删除须加dM_del；同点先按旧score删除再按删除后Π计穿越，\(|\Delta^{del}m|\le n r_{del}/e_{-}\)。初端不重计，末端按右态约定计阈值。于是 \(\int Var\,dt/t\le C_r+n+nR_{del,r}\)，EΠ²δ≤√(Var/2)。

直接可自证的辅助身份：在每个无删除跳区间，
\[
 -\partial_{\log t}\log e_t=\mathbb E_{\Pi_t}k_t,\qquad
 \partial_{\log t}(d\Pi_t/d\nu)
 =-(k_t-\mathbb E_{\Pi_t}k_t)(d\Pi_t/d\nu).
\]
即归一化漂移为centered score；sqrt密度的L2(ν)速度平方为Var/4。删除跳时要加真实非负log质量损失 \(\log(e_-/e_+)\)；不能把区间身份跨跳无费延拓。e_t≥e_g对合法t≤g可用，但没有统一e_g/||ν||下界，故log(eτ/e_g)、注入及删除费用都未自动付。

**与当前任务的精确连接缺口：** 这些恒等式属于固定(y,j)的同一来源过程。当前reserve核又含c_y(v)、终端wg/Δ、同α、good/bad；它们并非由上述单调性控制的共同势。要用能量付原正交通，仍需在真实 \(q^{-1}p h_Ra_\omega\,dx\,d\beta(y)d\nu(z')\) 下支付对应平方根能量/删除通量，或证明对该加权pair算子的两侧证书。逐行O(n)能量只会经Tsmall≤4X得O(√n)X，不能自动成为εX+C√nWβ。hard帽16/3至多一次，j≤n+2、时间log2及接收selector必须继续入账。

## SP4. 下一份可核验证书应包含什么

- 明确真实input/output测度、核及振幅，保留两个**原**来源因子，不在转置中换α/Z/e。
- 同一完整输入的两侧正权row/column上界，或对真实耦合两边缘的非负势预算；常数统一于全部合法receiver参数并含原dx。
- 若走occupation，先给保质量/kill/reset过程、初末律与测试域，再证明occupation与原Π²正量的同向映射；保留同一时间边缘和删除项。
- 用实际budget证明外积分为Wβ或已许可εX，随后恢复一次hard、j/time/selector费。缺任一项时，结论保持条件化，不把未付column或能量改名为范数。

此有限工具核验到此停止；没有外网泛搜、数值实验、Git或spawn，不改其他文件。
