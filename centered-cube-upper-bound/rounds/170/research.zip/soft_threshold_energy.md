# R170 — 阈值时间流、原负项与 high 列结构的联合结算

状态：得到一个有条件、保留原接收测度的根阶付款命题，以及完整缺陷恒等式。没有证明这些条件覆盖全部中间交通；没有把来源阈值分数当接收核 score。本文仅写入责任文件，无 Git、无额外代理。

## 1. 命题筛查及原式来源

固定完整 receiver row `r=(ω,V,j,x,y,z′,原历史)`，令辅助时间 `rtime=log t`。以下 `g, G=S_g, B=D_g, α_y, ρ, χ_J` 均为该行的终端量，在辅助 t 中冻结；`Z_t,w_t,e_t,Π_t` 随 t 变化。固定 `(ω,V,j,y,t)` 时，后四者不依 x。不得把两种冻结方式混为一谈。

只使用以下归档原式：

* R117 `research.zip:proof.md`，JG1–JG8（行 29–107）：`μ_t=1_{Z_t}w_tν` 随 t 按测度序递减；真实有限禁块删除；`Z_g⊂Z_t`；heavy/far 时间为原初段区间。
* R121 `research.zip:proof.md`，GL1–GL5（行 1474–1551）：`G_t=G ⊔ (Z_t\Z_g)`；全部 far 有利负项为 bad × `G_t` 上的反向分数差，不加 FA、空间或后来正项门。
* R128 `research.zip:proof.md`，行 489–523、604–667：当前 signed 余项为 `2Λ(P_rem−N_{Z^c}−N_del)`。`Ψ=1_{𝒵^c}` 是固定行、时间不变的原 suffix 剩余配对门；其补集负项已经消费。其余正项门可以更严，负项不能跟随加门。
* R135 `research.zip:proof.md`，AF14 及邻近说明：冻结终端测试的归一化导数带均值/删除项。本文不将该旧恒等式本身作为新结果；新输入是将初始项和全部删除上跳合成一个 `1/e_g` 预算，再用真实 high/FIRST 列结构付款。

原始未消费部分的共同外测度为

\[
 d\mathcal T=1_{\{j(x)=j\}}1_{\rm original}\,
 q^{-1}p_y h_R(x-z')a_\omega\,
 dx\,d\beta_V(y)\,d\nu_V(z').                         \tag{1}
\]

包含原 high 门，`p_y=P_{s,L}(x-y)`；所有新行条件均通过在 (1) 上乘同一行指示来划分原正负项，只分配一次负项。实际 far 区间记为 `(\ell,r)`，端点用原一侧值，区间外的原初始/near/跳边界费用不由本文退款。

核心筛查：一般相关 `Π_t` 并无根阶方差；对 `k_y(v)` 不能应用只作用于共同来源测试函数的列收缩。可行的建设性替代是保留 signed 时间流，在原空间核 `J` 上结算其真实边界。

## 2. 精确时间流：全部删除与已消费信用

写

\[
 k_t(v)=\#\{i:C((y_i-v_i)/b)<c_jt/b\},\quad
 D_t(v,u)=k_t(v)-k_t(u),\quad E_t=Z_t\setminus Z_g.
\]

`-d log w_t(v)/d log t=k_t(v)` 几乎处处成立。阈值交叉时 `w_t` 连续；本文不微分 k，所以没有遗漏 score 的阈值原子。在真实禁块删除时须另外保留跳跃。

令 `b_t=Π_t(B)`。非删除时

\[
 \frac{db_t}{d\log t}
 =\iint_{G\times B}D_t\,d\Pi_t^2
  +\iint_{E_t\times B}D_t\,d\Pi_t^2.                 \tag{2}
\]

若在 t 删除 `H_t=Z_{t-}\setminus Z_t`，令 `d_t=\int_{H_t}w_t dν`，则 B 全部存活，且

\[
 b_t-b_{t-}=b_{t-}\frac{d_t}{e_t}\ge0,
 \qquad e_{t-}=e_t+d_t.                              \tag{3}
\]

记当前正项额外指示/权重 `0≤η_t(v,u)≤1`，并置
`A(v)=1_G(v)ρ_y(v)χ_J(x-v)`，故 `0≤A≤1`。它冻结于终端，不作 t 微分。当前完整行余项是

\[
 \mathcal R=\int_\ell^r\iint_{G\times B}
 \Psi\{A\eta_tD_t^+-D_t^-\}\,d\Pi_t^2\frac{dt}{t}
 -\int_\ell^r\iint_{E_t\times B}D_t^-\,d\Pi_t^2\frac{dt}{t}. \tag{4}
\]

最后一项正是原 `N_del` 的行密度；不向它加入 η、ρ、Ψ 或终端 good 门。本文讨论的行选择保留与 (4) 相同的历史/high 限制。

由 `AηD^+−D^-=D−(1−Aη)D^+` 和 (2)，有完全有符号恒等式

\[
 \begin{split}
 \mathcal R={}& b_{r-}-b_{\ell+}
 -\sum_{\ell<t<r}(b_t-b_{t-})
 -\int_\ell^r\iint_{E_t\times B}D_t^+\,d\Pi_t^2\frac{dt}{t}\\
 &-\int_\ell^r\iint_{G\times B}(1-\Psi)D_t\,d\Pi_t^2\frac{dt}{t}
 -\int_\ell^r\iint_{G\times B}\Psi(1-A\eta_t)D_t^+\,d\Pi_t^2\frac{dt}{t}.
                                                               \tag{5}
 \end{split}
\]

这是删除负项的准确好处：归一化删除上跳与 future-deleted 正 flux 都在有利方向。可是其中的 `(1−Ψ)D_t` 是**已消费 suffix 的信用回加**。当原 suffix 定理适用于同一完整时间段时，其积分非正，故式 (5) 对它取负反而产生非负费用。不能从 (5) 得到免费 `\mathcal R≤1`，也不能在已付旧账外再次取用它。即使撤销旧 suffix 消费、改以全配对重算，`p_y b_t` 仍不保留可空间积分的 J，不能仅凭 `b_t≤1` 得到 Wβ 费用。

## 3. 保留 J 的 filtered 恒等式与同 α 反向储备

置 `F_t=Π_t A`。在连续段

\[
 -F'_t=\operatorname{Cov}_{\Pi_t}(A,k_t),\qquad
 F_t-F_{t-}=F_{t-}\frac{d_t}{e_t}\quad\text{(删除时)}. \tag{6}
\]

这里导数是对 `log t`。定义

\[
 \begin{aligned}
 C_{GG}(t)&=\frac12\iint_{G\times G}(A(v)-A(u))(k_t(v)-k_t(u))\,d\Pi_t^2,\\
 C_{GE}(t)&=\iint_{G\times E_t}A(v)(k_t(v)-k_t(u))\,d\Pi_t^2,\\
 H_Z(t)&=\iint_{G\times B}(1-\Psi)A(v)D_t(v,u)\,d\Pi_t^2,\\
 R_{\rm rev}(t)&=\iint_{G\times B}\Psi(1-A(v))D_t^-\,d\Pi_t^2,\\
 R_\eta(t)&=\iint_{G\times B}\Psi A(v)(1-\eta_t)D_t^+\,d\Pi_t^2.
 \end{aligned}                                                     \tag{7}
\]

分解 covariance，且使用 `AD^+−D^-=AD−(1−A)D^-`，得到

\[
 \boxed{\mathcal R=F_{\ell+}-F_{r-}
 +\sum_{\ell<t<r}\Delta F_t
 -\int_\ell^r(C_{GG}+C_{GE}+H_Z+R_{\rm rev}+R_\eta)\frac{dt}{t}
 -N_{\rm del}^{\rm row}.}                                         \tag{8}
\]

所有等式在原有限截断上成立；有限项先相减。任意截断极限须分别有可积控制，不能将 `∞−∞` 解释为 (8)。若另选多个时间分段，必须为每段另列端点；本文不将时间选择免费改成任意集合。

同一个 α 在 (7) 中给出真正留下的负储备。因为 `χ_J≤1`，在 `TΔ>0` 上

\[
 1-A\ge1-\rho
 =\min\left\{1,\frac{DK_0+\alpha_yJ}{T\Delta_y}\right\}.           \tag{9}
\]

因此 `R_rev` 至少包含将 (9) 乘以原 `ΨD^-dΠ²` 的量。这只来自原反向负项；不能另外再从 RC capture 容量中减出同一份。α_y 在完整行内冻结，故 (6)–(9) 没有 α 导数；若改动终端 g 或根据 t 重新选择 α，此结论即不适用，必须新增测试函数变化项。

## 4. 新联合边界引理：一次支付初始和全部删除

假设该行满足以下实际终端比值条件，M 为统一非负常数：

\[
 w_{\ell+}(v)\le e^M w_g(v)
 \quad\nu\text{-a.e. on }\{A>0\}.                                \tag{10}
\]

因 w 随 t 递减，(10) 自动控制 `[\ell,r]` 上同一固定 A 的所有时刻。它是有待覆盖的来源几何条件，不由 FIRST 或方差界自动推出。

令 `C_A=\int_G A(v)w_g(v)dν(v)`。删除只发生在终端集合外，故其时刻 A 加权分子连续；由 (10)

\[
 F_{\ell+}\le\frac{e^M C_A}{e_{\ell+}},\qquad
 \Delta F_t\le e^M C_A\left(\frac1{e_t}-\frac1{e_{t-}}\right).
\]

`e_t` 递减且 `e_t≥e_g>0`，所以初始项和所有删除项**合计**满足

\[
 F_{\ell+}+\sum_{\ell<t<r}\Delta F_t
 \le \frac{e^M C_A}{e_g}.                                        \tag{11}
\]

连续下降的 `e_t` 只使右侧望远镜余量增大，不能遗漏它却声称等式。该界没有删除次数、`\log(e_\ell/e_g)` 或最小 e 的另行费用。端点删除若归入当前段，也按同样 `Δ(1/e)` 加一次，(11) 仍成立；原其他边界账不能因此取消。

good 条件给 `p_yw_g(v)≤KQ(x-v)`，而 `A≤χ_J=J/(3Q)`，故

\[
 p_y C_A\le \frac K3J\nu_V(x),\qquad
 p_y\left(F_{\ell+}+\sum\Delta F_t\right)
 \le\frac{Ke^M}{3}\frac{J\nu_V(x)}{e_g(y)}.                       \tag{12}
\]

这是保留自然 J 的关键；没有将接收自适应核 `p_x(y)` 当成对 x 的概率密度。

在原 high 门 `p_y e_g(y)≥2Kq` 下，FIRST 对同一当前核给

\[
 \int 1_H\frac{d\beta_V(y)}{e_g(y)}
 \le\frac1{2Kq}\int p_y\,d\beta_V(y)
 \le\frac1{2K}.                                                  \tag{13}
\]

新行条件再乘在左侧仍成立。结合 (12)–(13)，每个实际 x,j 的联合边界有

\[
 \int 1_{H,\rm branch}p_y
 \left(F_{\ell+}+\sum\Delta F_t\right)d\beta_V(y)
 \le\frac{e^M}{6}J\nu_V(x).                                     \tag{14}
\]

原 `j(x)` 在固定 x 是唯一的，故在 (14) 保留 `1_{j(x)=j}` 再求和没有 `n+2` 费用；若先放松为对全部 j 求和，必须改乘 `n+2`。这不是对 j 各自付款后免费取最大。

对 (1) 的 z′ 积分使用一次原 hard 帽 `q^{-1}h_Rν_V≤16/3`，`a_ω≤1`。再积分 x 并用固定 b 的 `\int Jν_V=\|ν_V\|`，得到**真实 raw 边界费用**

\[
 2\Lambda\,\mathbb E\sum_{V,j}\int1_{H,\rm branch}
 q^{-1}p_y h_R(x-z')a_\omega
 \left(F_{\ell+}+\sum\Delta F_t\right)
 dx\,d\beta_V(y)\,d\nu_V(z')
 \le\frac{16\Lambda}{9}e^M W_\beta.                             \tag{15}
\]

这里 `\mathbb E\sum_V\|ν_V\|≤Wβ` 按原来源合同。时间已通过 FTC 结算，没有再乘 `log 2`，也没有删去某个 Π 因子来制造独立性。tiny e_g 已由 (13) 吸收。

## 5. 一个可审的实际条件分支，以及完整未付缺陷

(15) 可以合法支付下述共同 receiver/source 分支，条件均在原同一行、同一来源上测试：

1. (10) 成立，取 `M≤(1/2)log n`；
2. `A(v)(1−Ψ(v,u))=0`，对 `ν|G⊗ν|B` 几乎处处成立（活跃 A 不落在已消费 suffix 配对中）；
3. 对几乎每个辅助 t，`(A(v)−A(u))(k_t(v)−k_t(u))≥0` 在 `Π_t|G⊗Π_t|G` 上成立；
4. 对几乎每个辅助 t，`k_t(v)≥k_t(u)` 在 `Π_t|{A>0}⊗Π_t|E_t` 上成立。无未来删除时此项为空。

第二项使 `H_Z=0`，后三项给 `C_GG,C_GE≥0`。`F_{r-},R_rev,Rη,N_del` 都是有利项，故 (8) 和 (15) 给该行分支原 signed 余项

\[
 2\Lambda(P_{\rm rem}-N_{Z^c}-N_{\rm del})_{\rm branch}
 \le\frac{16\Lambda}{9}\sqrt n\,W_\beta.                         \tag{16}
\]

这是有条件的 signed 付款，不是对正 δ 独立取根阶帽；同一分支分得的负项不能在补集再次使用。条件 3、4 是明确的联合分数排序，保留同一 source 对，未用独立 Bernoulli 或自由 mask。条件 2 是现有消费账的兼容条件，不能默认为真。

没有证明该分支拥有新的 FULL 正交通实例，也没有声称覆盖原中间域。尤其 `A=ρχ_J` 的同 α 结构不自动使 A 与 k 同序；near-threshold 相邻双簇可能有 `k` 差 n 而空间位移很小，空间核重叠本身不能替代条件 3、4。

对于不满足排序的行，仍保留一个实际可用、没有取绝对值浪费的结算目标：

\[
 \mathfrak D=\int_\ell^r
 (C_{GG}+C_{GE}+H_Z+R_{\rm rev}+R_\eta)\frac{dt}{t}
 +N_{\rm del}^{\rm row}+F_{r-}.                                  \tag{17}
\]

原式准确为 `\mathcal R=F_{\ell+}+ΣΔF−\mathfrak D`。式 (9) 是可与坏来源几何联合使用的真实有利部分；它有可能补偿 `C_GG,C_GE,H_Z` 的负部。本文没有把 `\mathfrak D` 改名成已受控能量，也没有证明其全局非负或负部根阶可积。所需下一条不等式必须在 (1) 的同一测度下控制 `−\mathfrak D`，并同时处理 (10) 失败的终端权重比值。

## 6. 新列收缩的能力与边界

父级给出的 high 列结构可直接自证。固定 x,j,t，保留原可用 high 行集，有

\[
 \int1_H\Pi_t^y(dv)\,d\beta_V(y)
 =d\nu_V(v)\int1_H\frac{1_{Z_t(y)}w_t(y,v)}{e_t(y)}d\beta_V(y)
 \le\frac1{2K}d\nu_V(v).                                        \tag{18}
\]

因为 `e_t≥e_g`、`w_t≤1`，并用同一 `\int p_y dβ≤q`。对每个共同来源函数 `f(v)`，Jensen 因而给

\[
 \int1_H|\Pi_t^y f|^2d\beta_V(y)
 \le\frac1{2K}\int|f|^2d\nu_V.                                  \tag{19}
\]

一般 `k_y(v),ρ_y(v),A_y(v)` 依 y；(19) 不能直接用于它们。本文的联合边界引理绕开这一问题：先以终端 good 关系将 A 的来源积分换成固定 `Jν(x)`，再用 (13)，最后才对 x 积分。它给出了完整的实际 raw 付款 (15)，而不是对抽象列范数重新命名。

结论：已证新量是「原 filtered posterior 的初始项加全部删除上跳」在终端比值条件 (10) 下的根阶/指数 M 费用；式 (8) 保留每一项未消费信用。未闭合的是全局联合几何能否以 (9) 的同 α 反向储备补偿排序失败及 suffix 信用，和如何结算大终端权重比值行。一般上界仍开放。
