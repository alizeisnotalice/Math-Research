# R145 自适应插值与来源回代独立先审

状态：已读本轮任务合同及指定 R136 FK4–5 必要片段；沿用已审 R144 softscale 的 SS2/SS7/SS9 量词，不读本轮作者稿。本文件仅给最小先审合同，等待具体新式。

## 1. 固定参数的零阶锚点确为概率积分

固定 \(b=1\)、\(s,L,H\)、来源位移 \(u,v\)，令
\[
dP(d)=p_{s,L}(d)\,dd,\qquad
F(d)=\frac{C(v)}{k_{s,H}(d-u)\phi(d-v)}.
\]
这里 \(P\) 是质量 1 的固定参数概率，且
\[
I_\theta=C(u)C(v)\int F^\theta dP.
\]
对 \(\lambda=\theta/\theta_0\in[0,1]\)，同一测度上的 Hölder 给
\[
I_\theta\le I_0^{1-\lambda}I_{\theta_0}^{\lambda}
\le[C(u)C(v)]^{1-\lambda}M_{\theta_0,s}^{\lambda}.
\]
\(I_0=C(u)C(v)\le1\) 使用的是 \(\int p_{s,L}=1\)，不是 Lebesgue 测度本身为概率。指定 FK4–5 片段未显示此零阶插值；这只说明该限定片段没有写出，不宣称遍历历史后的新颖性。

固定参数的 n 维张量化因而可给 \(M_{\theta_0,s}^{n\lambda}\)，并保留来源衰减乘积的 \(1-\lambda\) 次幂。\(b\ne1\) 的物理逆核费仍为 \(b^{2n\theta}\)。\(\theta=c/n\) 消除了旧粗常数的线性维数指数，但不自动支付原来源或接收费用。

## 2. 自适应参数不能沿用质量 1 的零阶锚点

若 \(s=s(x),L=L(x),H=H(x)\)，仍可对**同一已固定选择器**应用 Hölder：
\[
\int a(x)F(x)^\theta dx
\le\big(\int a(x)dx\big)^{1-\lambda}
\big(\int a(x)F(x)^{\theta_0}dx\big)^\lambda.
\]
但这时必须分别估计两个实际积分。\(a(x)=p_{s(x),L(x)}(x-y)\) 一般不是概率密度，\(\int a\ne1\)；H 不进入这个裸零阶锚点，并不使自适应 s/L 的质量免费。若裸接收零阶质量上界为 \(Z_0\)，它以 \(Z_0^{1-\lambda}\) 留下，小 \(\lambda\) 不会压低这份主要价格。

FK4 对每个固定 \(s,L,H\) 的一致帽不控制“每个 x 重新选核”的正阶端点积分。必须使用事前共同包络、付费单元覆盖，或证明实际自适应端点估计。可测性仅使积分有定义，不交换 \(\int\sup\) 与 \(\sup\int\)。

R144 SS7/SS7e 可点态控制自适应 H，随后实际接收积分；SS9 才将原门、共同 \(\alpha\)、实际 \(q\) 放松为可比较乘积系数。若用它构造本轮端点，须保留其 first 项及全部尺度权。不能在辅助尺度节点重算 \(\alpha,q,e,Q_J\) 或来源资格，也不能将保留这些 x 依赖权的积分冒称裸乘积概率。不同插值端点必须来自同一原非负测度及同一选择器；若端点用了不同合法上界，须先展示它们分别支配同一端点积分。

## 3. 来源回代的最低条件

1. FK4 处理的是固定 \(u,v\) 的接收积分，不处理原 \(\nu\) 相关性。来源衰减即使至多 1，也不能删除外 \(\nu(dz)/q\) 或把三源变为产品概率。
2. 原 \(\Pi_t\)、两份 \(e_t^{-1}\)、\(Q_J\)、\(TA\)、共同 reserve 与窗口在插值中固定为原量。由截断来源重算归一化量，不属于该 Hölder 证明。
3. 若由低门插入 \(1_{c<\eta_n}\le(\eta_n/c)^\theta\)，须完整列出 \(\eta_n^\theta\)、\(\delta^{1+\theta}\)、\(e,Q_J,TA,w_t\) 的新幂及物理尺度费，确认与 FK4 的两个 C 幂精确匹配。仅给核矩 \(s^{-c}\) 不支付这些因子。
4. 外 hard 来源、原 good/bad 域、\(\Psi\)、FA、history、\(dt/t\)、\(d\beta\)、\(\mathbb E\sum_{V,j}\)、\(2\Lambda\) 和所有层级仍须显示；来源未消尽前不能引用唯一 j 的共同数值帽。原 \(c_j\le1\)、\(\tau_j\ge a\)，共同 \([a,b]\) 的正扩张合法。

本轮可接受的进展是：先证固定参数小幂矩；再给一个明确自适应接收上界，列清零阶锚点价格及正阶端点价格；最后写出实际低尾的全部来源系数。只有证明其完整外层 \(\le\varepsilon X+C\sqrt n\,\mathrm{polylog}(n)W_\beta\)，才登记一般付款。基本 Hölder 插值本身不承担这个结论。

先审结束，等待主代理发送具体候选；不扩大历史核查。

## 4. 作者转发的实际 measure 先插值候选

仅依据作者转发的新式，尚未读本轮作者稿。固定事前 \(s,L,R\) 单元 \(C\)，\(p_{actual}\le E_p\bar p\)，其中 \(\bar p\) 是归一概率。固定原门权 \(0\le m\le1\)，允许其含实际共同 \(\rho\)、good、history 或 hard 盒；记
\[
Z_C=\int_{\Omega_C}p_{actual}(x)m(x)dx\le E_p,
\quad C_u=\prod_iC(|u_i-y_i|/b),\quad C_v=\prod_iC(|v_i-y_i|/b).
\]
设 \(r=\theta/\theta_0\)。作者候选为
\[
\int_{\Omega_C}p_{actual}m\,
C_uC_v^{1+\theta}(\underline K_{C,H(x)}J_v)^{-\theta}dx
\le(C_uC_vZ_C)^{1-r}E_p^r b^{2n\theta}
M_{\theta_0,s_-}^{nr}[1+n\theta_0\log(b/a)]^r.
\]
**独立初审通过。** 先在同一实际测度 \(1_{\Omega_C}p_{actual}m\,dx\) 上插值，零端点正是 \(C_uC_vZ_C\)。在 \(\theta_0\) 端点才以 \(E_p\bar p\) 放松、删除 \(m\)，并用 R144 H 包络；固定辅助 H 节点后，FK4 证明给每节点 \(b^{2n\theta_0}M_{\theta_0,s_-}^n\)。因而端点成本乘 \([1+n\theta_0\log(b/a)]\)，插值后全部取 r 次幂，得到显示式。

这里需明确一个小推广：FK4 原命题的分子混合软度与分母软度相同，当前 \(\bar p\) 和 \(\underline K\) 未必如此。但其原证明只需分子是同尺度带内的归一 hard/soft 混合，分母满足 \(\underline K\ge\prod_i(s_-/H)\phi((x_i-u_i)/H)\)。故可逐行复用 FK2–5 的纯 soft 下界证明，不需把非归一 \(\underline K\) 称为概率核，也不需对其重新归一。

这个先插值的 H 费用满足
\[
[1+n\theta_0\log(b/a)]^r
\le1+n\theta\log(b/a),
\quad
[1+n\theta_0\log(b/a)]^r\le(b/a)^{n\theta}.
\]
第一式为凹性，第二式为 \(\log(1+x)\le x\)。它是具体尺度系数改善；若再用 \(Z_C\le E_p\)，则 \(Z_C^{1-r}E_p^r\le E_p\)，\(E_p\) 并未被小幂消去。\(Z_C\) 若保留实际 \(\rho\) 或 hard 交叠，仍是随来源变化的实际接收积分，需要另行有价平均。

回代预告中的 \(Q_J\le q\) 必须给出原 \(q\) 定义或已证接口；本轮合同单独的 \(q\ge Q_0\) 不推出它。未得到该依据前，保留 \(Q_J^\theta/q\)。若该比较确有原合同支持，\(0\le\theta<1\) 下 \(q^{\theta-1}\le q_-^{\theta-1}\) 方向正确。其余预告的 \(e^{-2-\theta}\)、\(\delta^{1+\theta}\) 以及额外 \(w_t(u)^\theta\) 均符合低门插入的代数；最终必须逐项核对实际新式，尚不登记来源付款。

## 5. adaptive_interpolation 最终稿绑定

已读 `adaptive_interpolation.md`，绑定 SHA-256：
`2ff23adede89fd09176f8dcf504570ee0e0e7d5166deb71e0fb90f986c6368b3`。

**通过其声明范围。** AI3、AI5–8 的量词及端点价格符合第 4 节先审；实际分区明确为事前不交半开单元，\(\bar P_C\) 才是概率，\(\underline K\) 的质量缺口没有丢掉。AI9 比较的具体结合成立：在 \(\theta_0\) 先付 R144 H 包络，再在同一实际接收测度插值，H 因子为 \((1+n\theta_0L_H)^r\le1+n\theta L_H\)。固定参数及来源零阶插值已有 R137，不重新登记为新定理。

真实 w 版本 AI13 是同一 \(\mu_C\) 上 \(w_uw_v\) 乘 \([w_uA_v/(K_uJ_v)]^\theta\) 的矩，故 AI15→AI16 的零阶/正阶指数准确。\(Z_C^{hard}\) 保留原 hard、\(\rho\)、low、good 与 history；删除这些门只发生在正阶端点上界中，没有同时宣称估计其低门收益。AI19 的来源权转为 AI20 时，确实留下 \(e_t^{-\theta}w_u^{\theta-r}w_v^{-r}\)，两份 posterior 和外 hard 来源 \(\nu\) 未变成免费概率。

本审计精准核到 R136 `active_bad_geometry.md` §7 的原 FIRST 同行 \(Q_J\le q\) 陈述；AI18–20 已明确额外调用该合同，而非从 \(q\ge Q_0\) 推导。未认证扩张域仍保留 AI18 的实际 \(Q_J^\theta/q\)。AI21 仅在同 \(q_-\) 层、同 \(\theta,\theta_0\) 作有限和 Hölder；\(\sum Z_C\) 的实际质量及未消尽来源、j、time/层级均明列，未给免费菜单总价。

门方向已明确：\(c<\eta_n\) 时 \(G=(\eta_n/c)^\theta\ge1\)，是低门上界的费用；其倒数不能降低原交通。AI18 前文字和最终缺口均无将其认成收益的暗示。小幂核价及 H 因子改善不支付来源负矩或完整原交通。

## 6. source_tail 最终稿检查

已读 `source_tail.md`，绑定 SHA-256：
`bce41ca740bc156c889f6b149881b6482103bdee57925cbfdfb7db5af9c68322`。

ST2 保留原三来源、\(q^{-1}\)、实际 hard 资格、\(\rho\)、原 low 门、两份 posterior 及依 z 的 history；没有把来源平均写成产品概率。ST3–4 的来源质量比方向正确：\(C_y\le w_t\) 及有限源凹性给 \(e_t^{-1}\int C_y^{1-\lambda}d\nu\le(N_t/e_t)^\lambda\)，这不是统一常数。

ST9 的原 high/FIRST 与 good 仅在同一实际行相接：\(Q_J/e_t\le p_x/(2K)\)、\(J_v\ge p_xw_g/K\)，所以 \(J_ve_t/Q_J\ge2w_g\)。代入原 c 得 ST10 的真实必要门，且它仅给 \(K_u/w_u\) 的上界。作者没有将其误读成来源权下界或弱负矩付款。

ST5 的旧 \(nR_t^{7\theta}\) 价格保留了 score 与来源比；其来源负幂上界方向与 \(\theta\le1/5\) 的范围一致。ST7/8 被准确标为 R137 已有接口而非新增付款。低门幂再次明确为 \(G\ge1\)；保留原门的实际端点与删门后的固定核端点被清楚区分。

因此 source_tail 声明范围通过：ST9–10 是合法门化简，但来源平均总价未证。两稿都没有把旧 R137 插值登记为新成果，也没有把有限数值中的 \(1/G\) 称为收益。本文未运行或认证本轮数值；主代理报告的修正数值只作另外证据，不影响本解析判定。

最终审计结束：上述两个 SHA 绑定稿均通过其明确声明的范围，无剩余更正。一般 \(n^{1/2+o(1)}\) 预算仍未闭合。只写本文件，未运行 Git/PDF，不继续扩展。
