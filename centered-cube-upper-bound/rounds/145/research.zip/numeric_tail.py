#!/usr/bin/env python3
"""R145 tail transforms of the frozen R144 three-point screen, no resampling/integration."""
import json,math,hashlib,datetime,time,decimal,statistics
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'centered_cube_round144_20261015/numeric_geometry.json'
EXPECTED='98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517'
THETA_KEYS=['1/n','2/n','1/4'];MREFS=[1,1.25,1.5,2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def quant(values):
 v=sorted(values)
 if not v:return {'N':0}
 def q(p):
  i=(len(v)-1)*p;j=int(i);return v[j]+(v[min(j+1,len(v)-1)]-v[j])*(i-j)
 return {'N':len(v),**{str(p):q(p) for p in [0,.1,.5,.9,.99,1]}}
def weighted_quant(values,weights):
 pairs=sorted((v,w) for v,w in zip(values,weights) if w>0)
 if not pairs:return {'positive_weight_N':0,'total_weight':0}
 with decimal.localcontext() as ctx:
  ctx.prec=70;dw=[decimal.Decimal(str(w)) for v,w in pairs];total=sum(dw);out={'positive_weight_N':len(pairs),'total_weight':float(total)};acc=decimal.Decimal(0);i=0
  for p in [0,.1,.5,.9,.99,1]:
   if p==0:out[str(p)]=pairs[0][0];continue
   if p==1:out[str(p)]=pairs[-1][0];continue
   target=decimal.Decimal(str(p))*total
   while i<len(pairs)-1 and acc+dw[i]<target:acc+=dw[i];i+=1
   out[str(p)]=pairs[i][0]
 return out
def correlation(x,y):
 if len(x)<3:return None
 mx=statistics.mean(x);my=statistics.mean(y);xx=[v-mx for v in x];yy=[v-my for v in y];den=math.sqrt(sum(v*v for v in xx)*sum(v*v for v in yy));return sum(a*b for a,b in zip(xx,yy))/den if den else None
def ranks(v):
 order=sorted(range(len(v)),key=v.__getitem__);r=[0]*len(v);i=0
 while i<len(v):
  j=i+1
  while j<len(v) and v[order[j]]==v[order[i]]:j+=1
  for k in range(i,j):r[order[k]]=(i+j-1)/2
  i=j
 return r
def summary(rows):
 out={'sample_N':len(rows),'receiver_N':len({(r['case'],r['id']) for r in rows}),'pair_segment_N':len({(r['case'],r['id'],r['segment'],r['v'],r['u']) for r in rows})}
 if not rows:return out
 out['ell']=quant([r['ell'] for r in rows]);out['ell_over_n']=quant([r['ell_over_n'] for r in rows]);out['gate_cost_direction']='G>=1 upper-bounds the low indicator; its reciprocal supplies no low-tail bound.'
 out['markers']={k:sum(r[k] for r in rows) for k in ['Psi','FA_closed','FA_strict_interior','positive_interior_occupation']}
 out['theta']={}
 for key in THETA_KEYS:
  ts=[r['theta'][key] for r in rows];out['theta'][key]={'valid_interpolant_sample_N':sum(t['valid_interpolant'] for t in ts),'G':quant([t['G'] for t in ts]),'log_G':quant([t['log_G'] for t in ts]),'scalar_cost_reference':{str(m):{'illustrative_product_G_times_Mpower':quant([t['scalar_cost_reference'][str(m)]['illustrative_product'] for t in ts if t['valid_interpolant']])} for m in MREFS}}
 out['proxy_weighted']={}
 for weight in ['receiver_equal_weight','whole_score_proxy_weight','rho_score_proxy_weight']:
  weights=[r[weight] for r in rows]
  out['proxy_weighted'][weight]={'ell':weighted_quant([r['ell'] for r in rows],weights),'G_1_over_n':weighted_quant([r['theta']['1/n']['G'] for r in rows],weights)}
 return out
start=time.monotonic();assert sha(SRC)==EXPECTED;d=json.loads(SRC.read_text());pairs=d['posthoc_capacity_split_screen']['pair_segment_records'];assert len(pairs)==690
positive={(cid,r['id']):r for cid,c in d['cases'].items() for r in c['positive_rows']};pairreps=Counter((r['case'],r['id'],r['v']) for r in pairs);receiver_samples=Counter()
for r in pairs:receiver_samples[(r['case'],r['id'])]+=len(r['samples'])
rows=[];checks={'decimal_digits':70,'sample_count':0,'max_abs_ell_error':0,'max_relative_G_error':0,'invalid_nonpositive_ratio':[]}
with decimal.localcontext() as ctx:
 ctx.prec=70;Dec=decimal.Decimal
 for pair in pairs:
  cid=pair['case'];pr=positive[(cid,pair['id'])];source=next(s for s in pr['sources'] if s['source_index']==pair['v']);n=pair['n'];thetas={'1/n':1/n,'2/n':2/n,'1/4':.25};decs={'1/n':Dec(1)/n,'2/n':Dec(2)/n,'1/4':Dec(1)/4};reps=pairreps[(cid,pair['id'],pair['v'])]
  for sample in pair['samples']:
   r=sample['c_over_eta'];assert 0<r<1
   ell=-math.log(r);dell=-Dec(str(r)).ln();checks['max_abs_ell_error']=max(checks['max_abs_ell_error'],float(abs(Dec(str(ell))-dell)))
   ts={}
   for key,theta in thetas.items():
    lg=theta*ell;G=math.exp(lg);dg=(decs[key]*dell).exp();checks['max_relative_G_error']=max(checks['max_relative_G_error'],float(abs(Dec(str(G))-dg)/dg));valid=theta<=.25
    cost_reference={str(m):{'log_illustrative_product':theta*(4*n*math.log(m)+ell),'illustrative_product':math.exp(theta*(4*n*math.log(m)+ell))} for m in MREFS} if valid else {str(m):None for m in MREFS}
    ts[key]={'theta':theta,'log_G':lg,'G':G,'valid_interpolant':valid,'constant_M0_power':4*n*theta if valid else None,'source_decay_power':1-4*theta if valid else None,'scalar_cost_reference':cost_reference}
   row={k:pair[k] for k in ['case','id','stage','distribution','n','eta','v','u','v_name','u_name','segment','delta','rho_v','FA_cap']};row.update(sample);row.update(ell=ell,ell_over_n=ell/n,theta=ts,p=pr['p'],R=pr['R'],x_mean=pr['x_mean'],x_min=pr['x_min'],x_max=pr['x_max'],j_v=source['j'],a_v=source['a'],b_v=source['b'],rho_saved=source['rho'],receiver_equal_weight=1/receiver_samples[(cid,pair['id'])],whole_score_proxy_weight=source['W']/(reps*len(pair['samples'])),rho_score_proxy_weight=source['Wrho']/(reps*len(pair['samples'])))
   rows.append(row);checks['sample_count']+=1
assert checks['sample_count']==2070
strata={}
for stage in ['initial','pressure','expanded']:
 rs=[r for r in rows if r['stage']==stage]
 strata[stage]={'all_samples':summary(rs),'positive_FA_interior_samples':summary([r for r in rs if r['positive_interior_occupation']]),'cases':{cid:{'all_samples':summary([r for r in rs if r['case']==cid]),'positive_FA_interior_samples':summary([r for r in rs if r['case']==cid and r['positive_interior_occupation']])} for cid in ['I1','P1']},'time_labels':{label:summary([r for r in rs if r['label']==label]) for label in ['lo_right','geometric_mid','hi_left']}}
source_strata={}
for cid in ['I1','P1']:
 for source in sorted({r['v_name'] for r in rows if r['case']==cid}):
  key=cid+'/'+source;rs=[r for r in rows if r['case']==cid and r['v_name']==source];source_strata[key]={'all_samples':summary(rs),'positive_FA_interior_samples':summary([r for r in rs if r['positive_interior_occupation']]),'stages':{stage:summary([r for r in rs if r['stage']==stage]) for stage in ['initial','pressure','expanded']}}
# Joint proxy correlations keep one time label and source identity; never interpret as distance recovery.
joint={}
for cid in ['I1','P1']:
 for source in sorted({r['v_name'] for r in rows if r['case']==cid}):
  for stage in ['initial','pressure','expanded']:
   rs=[r for r in rows if r['case']==cid and r['v_name']==source and r['stage']==stage and r['label']=='geometric_mid' and r['positive_interior_occupation']]
   key=cid+'/'+source+'/'+stage;joint[key]={'N':len(rs),'scope':'Saved geometric midpoint inside original FA only, proxy features, no distance recovery','ell_vs':{}}
   for feature in ['p','R','j_v','a_v','b_v','rho_saved','x_mean']:
    x=[r['ell'] for r in rs];y=[r[feature] for r in rs];joint[key]['ell_vs'][feature]={'spearman':correlation(ranks(x),ranks(y)),'pearson':correlation(x,y),'feature_quantiles':quant(y)}
interpolation_table={str(n):{key:{'theta':theta,'valid':theta<=.25,'M0_power':4*n*theta if theta<=.25 else None,'source_decay_power':1-4*theta if theta<=.25 else None} for key,theta in [('1/n',1/n),('2/n',2/n),('1/4',.25)]} for n in [4,16]}
out={'status':'completed_frozen_tail_transform','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':{'R144_numeric_geometry':sha(SRC)},'plan_sha256':sha(ROOT/'numeric_tail_plan.md'),'script_sha256':sha(Path(__file__)),'execution_count':3,'execution_history':'Initial run; weighted-CDF accumulation correction; final low-gate direction correction deleting reciprocal/break-even outputs. Each run transforms only2070 existing screen points, no old6951 replay, kernels or quadrature.','scope':'Transform 2070 existing low screen points only; no old6951 replay, kernels, sampling, quadrature, general dimension fit or whole-window claim.','checks':checks,'quantile_definition':'Unweighted linear interpolation at (N−1)p; weighted left inverse empirical CDF with decimal70 cumulative saved weights (first cumulative weight >= p total), min/max exact over positive weights, no interpolation.','weight_definition':'receiver_equal=1/number saved samples per receiver. Whole_score/rho_score proxies divide saved source W/Wrho equally across its pair-segments and their three points; not quadrature, density, FA integrated traffic or probability.','interpolation_contract':{'theta0':.25,'direction':'1_low <= G=(eta/c)^theta >=1. G is inflation, no reciprocal low-gate bound. M0 powers and source decay powers only; illustrative scalar products multiply G and M0^power, not a complete integrated bound and not independent payments if M0 came from the same moment.','M0_references':MREFS,'direction_correction':'Earlier reciprocal and artificial break-even comparisons deleted; no reverse Markov inference.','actual_M0_estimated':False,'source_decay_evaluable':False,'table':interpolation_table},'strata':strata,'source_strata':source_strata,'joint_proxy_correlations':joint,'samples':rows,'missing_geometry':['full receiver x coordinates','source positions','C(u)C(v)','separate K_u/J_v/e/TA/QJ factors for each low-screen sample','actual FK4 integral M0'],'elapsed_seconds':time.monotonic()-start}
(ROOT/'numeric_tail.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':out['status'],'checks':checks,'elapsed_seconds':out['elapsed_seconds']},ensure_ascii=False))
