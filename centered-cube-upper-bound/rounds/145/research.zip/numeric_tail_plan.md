# R145 numeric_tail 冻结协议（执行前）

仅输入R144 numeric_geometry.json，绑定SHA=98d87b6b33c8ae65a7480c0dec809698532d047753aa86b1e013938cac9dc517。读取posthoc_capacity_split_screen原690 pair-segment/2070三点记录及同文件179正行摘要，不重算R142/143或旧6951行，不重新采样、求积、计算真实核。只写本目录numeric_tail_plan.md、numeric_tail.py/json/notes.md。

## 1. 实际字段与保留合同

pair-segment有case、id、stage、distribution、n、eta、v/u及名字、segment/delta、rho_v、原FA_cap；sample有label、t、c_over_eta、high、Psi、FA_closed、FA_strict_interior及positive_interior_occupation。原case正行摘要含p、R、x_mean/min/max和来源a,j,b,rho,W/WD/Wrho、接收外权/integration。记录全部来源/time/FA标记，禁止换掉原bad/good/score/Psi门。

不包含全维x或source位置，不能反解来源距离、坐标卷积C(u)C(v)、实际核积分M或归一化e/TA/QJ的分量。仅关联已有p、j、R、a/b/rho与x摘要作必要描述，不补读旧接收核或猜位移。

## 2. 固定转换与分组

每个保存low sample取r=c/eta∈(0,1)，ell=log(eta/c)=−log r。固定theta=1/n、2/n、1/4：门因子G=exp(theta ell)作为真实low门上界膨胀成本报告；G≥1，不输出1/G为收益或概率。分位为min,10%,median,90%,99%,max（线性插值，记录算法）。统计分组：原initial/pressure/expanded分开；每stage再按case、source、t标签、原FA positive strict interior分开；跨case混合摘要只描述已有菜单，不作维数阶。

不把三个时间点当iid/求积节点。主要分布是保存sample的等计数经验分布；补报每pair等权或每receiver等权时明确权定义。whole-score来源权W及rho W只可作描述代理，不当成FA时间积分权；每pair三点均匀分配其保存来源W（同来源同窗若多段，等分pair-segment数）仅用于诊断。按case分布分别报告FA严格内部样本的来源权代理占比，保留未加权统计，零源权不除零。

## 3. 核插值费用与来源衰减（方向修正后的合同）

固定theta0=1/4。I_theta的n维常数因子为M0^(4n theta)，来源衰减因子为P^(1−4theta)，P=逐坐标[C(u)C(v)]之积，物理b^(2n theta)仍完整。只报告M0的指数、来源衰减指数，以及theta缩小时这两项的变化。不估实际M0，也不从保存字段猜P。

正确低门方向为1_{c<eta}≤(eta/c)^theta=G≥1。G是膨胀成本，1/G没有可用的low门上界；不得使用M0^(4n theta)/G或其所谓临界M0作预算决策。固定参考M0=1,1.25,1.5,2仅作标量费用演示：G·M0^(4n theta)，方向是相乘；这不等于真实积分推导，若M0已由同一G的核矩积分得到，不能再把两者独立重复相乘付款。真实改善需来源衰减或另证空间尾压缩，不能反向Markov。

I1(n4)的theta=2/n=.5超过theta0且FK4 θ<1/3，门因子可数值计算，但插值指数/参考费用标null；其它本菜单theta均在[0,theta0]。不使用FK5粗指数上界作必要失败条件。

## 4. 算术与解释边界

保存r为float64，先用math.log/exp，对全部2070值用Python decimal 70位ln/exp复核门成本；报告最大相对/绝对差，非区间证明。保留输入数值原样，无下溢截零。逐sample留转换后的所有theta量并汇总三阶段，使一次脚本运行可复现全部新增数值；UTC/耗时除外。目标解释小theta对极低c门的有限效果及与M0的权衡，不重报high=0作为新结果，不认证一般阶数或全窗尾分布。


## 执行中方向修正记录（2026-10-15）

首版曾保存G的倒数及M0^(4n theta)/G的假想break-even；主代理指出1/G不是合法low门界后，删除这些输出和路线。修订仅重跑2070旧screen点的代数转换，保留首版错误的本说明，不修改R144输入或重算6951行。此修正优先于首版数值比较，不把“减小theta不改收益符号”作为结论。
