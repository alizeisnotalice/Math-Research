# R145 来源平均短交付：low 门未支付弱负权

结论：本轮没有从零阶 C 插值得到新的、适用于一般 ν 的来源付款。核插值、真实 w_t 基线、high/FIRST 消去整体 e_t 负幂及剩余 R_t^{7θ} 价格均已在 R137 证明；不重复登记。R144 实际 low 门结合原 high 和 good，可推出下述不含 QJ/e_t 的明确必要门，但其方向仍不能控制来源弱负权。一般根阶目标未闭合。

## 1. 准确平均目标及历史去重

仍使用原 fixed ν、Π_t=w_t1_Ztν/e_t、δ=(k_v−k_u)_+，并令

\[
c_x(v,u)=\frac{DK_u(x)J_v(x)e_t}{TA_vQ_J(x)w_t(u)\delta(v,u)},
\qquad\eta_n=\frac{4(n+1)^2}{3n}.
\tag{ST1}
\]

商只在原正有限行及 δ>0 上形成；原零交通行先置零。真实尚未支付的来源平均目标是

\[
\begin{aligned}
\mathfrak P_{low}=2\Lambda\mathbb E\sum_{V,j}
\int d\beta_V(y)\int\frac{dt}{t}\int dx\,\frac{p_x}{q(x)}
\int &h_{R_{scale}}(x-z)a_\omega(x,y,z)\\
{}\cdot\iint &\chi_{orig}(x,y,z,v,u,t)\rho_v\delta(v,u)
1_{\{c_x(v,u)<\eta_n\}}d\Pi_t(u)d\Pi_t(v)\,d\nu_V(z).
\end{aligned}
\tag{ST2}
\]

χ_orig 含旧已付补集、原 terminal good／D0、Ψ、FA、high 和其余实际正资格；aω 单独显示。内层的 z 依赖保持在外 ν(z) 积分内。时间窗、唯一 j、全部 history／scale 层级照原合同。目标仍为 ST2≤εX+C√n polylog(n)Wβ，不以 β=ν 或来源独立性简化。

本次先行候选是以主插值保留的 C 尾直接配对 w_tν/e_t，消去两份 e_t。必要历史核查发现：R137 `interpolation_audit.md` IA3 已有准确零阶 C 锚定；IA5–8 及 `normalized_capacity.md` NC3–7、NC9–24 已有真实 w_t 插值、完整母式插值、来源弱负矩和 high 接合。故以下只审 ST1 的新 low 门是否改变那个来源价格。

## 2. 一般来源积分的准确价格仍在

记 C_y(z)=∏_i C(|z_i−y_i|/b)、κ=b/(c_jt)。原窗给 1≤κ≤b/a≤2，且

\[
C_y(z)\le w_t(z)\le\kappa^nC_y(z).
\tag{ST3}
\]

因此插值后出现 C_y^{1−λ} 时，不能把它重新当成一份 w_t。准确转换为

\[
\frac1{e_t}\int_{Z_t} C_y(z)^{1-\lambda}d\nu(z)
=\int\frac{C_y(z)^{1-\lambda}}{w_t(z)}d\Pi_t(z),
\qquad0\le\lambda\le1.
\tag{ST4}
\]

令 N_t=ν(Z_t)、R_t=N_t/e_t。在有限正行上，凹性与 C_y≤w_t 给 ST4≤R_t^λ；两份来源最多给 R_t^{2λ}。这是有量纲归一化后的真实质量比，不是常数。直接先用 ST3 上界两份 w_t 还会留下 κ^{2n}；这个零阶损失已由 R137 的真实 w_t 插值解决，不应重引。

更好的既有 NC13–24 价格为

\[
\mathcal S_\theta=
\int w_v^{-4\theta}
\left[\int\delta(v,u)^{1+\gamma}w_u^{-3\gamma}d\Pi_t(u)\right]^{1/(1+\gamma)}d\Pi_t(v)
\le nR_t^{7\theta},
\quad\gamma=\frac\theta{1-\theta},\quad0\le\theta\le\frac15.
\tag{ST5}
\]

这是旧的明确有限来源费用，不是本轮新能量。原 high/FIRST 也已给

\[
Q_J/e_t\le p_x/(2K).
\tag{ST6}
\]

它准确消去 NC 中整体 e_t^{−θ} 与 QJ^θ 的组合；Π 内的弱负权不会同时消失。固定概率核块的既有完整前价为

\[
c_\theta(2KD\sqrt\ell)^{-\theta}
\kappa^{8n\theta}(b/a)^{3n\theta}M_*^{4n\theta}\mathcal S_\theta,
\tag{ST7}
\]

cθ=θ^θ/(1+θ)^{1+θ}，M*=M_{1/4,s}。小 θ=O(1/[n log(n+2)]) 可控制 ST7 的核／尺度前因子，不能把 Sθ 的零阶 score 量降至根阶。取 θ 适应 log R_t 可控制 R_t^{7θ}，但 θ→0 时仍回到原 S0=∫δdΠ²。

实际接收选择器下须用 NC21 的完整价格

\[
2\Lambda\mathbb E\sum_j\int d\beta(y)d\nu(z)\frac{dt}{t}\,
 c_\theta M\kappa^{8n\theta}(b/a)^{n\theta}
 \widetilde M_*^{4n\theta}\mathcal D^\theta\mathcal S_\theta.
\tag{ST8}
\]

这里 M 是原接收列质量，\(\mathcal D=b^{2n}\widehat H^4/M^4\) 为 NC19–21 的实际接收乘子比；不以固定概率核的质量 1 替换它们。ST8 仍要付外 ν(z)、β、time/j 和各层级，不能直接套来源已消尽后的唯一 j 帽。R144 的小 θ H 菜单估计只减少同一系数菜单的重复价格，不控制这些来源负矩。

## 3. R144 low 门真正增加的必要限制

在同一个实际 high、good 接收行，ST6 与 good 的 J_v≥p_xw_g(v)/K 同时成立。因此

\[
\frac{J_ve_t}{Q_J}\ge2w_g(v),
\qquad
c_x(v,u)\ge\frac{2DK_u(x)w_g(v)}{TA_vw_t(u)\delta(v,u)}.
\tag{ST9}
\]

故原 low 支必满足

\[
\boxed{2DK_u(x)w_g(v)<
\eta_nTA_vw_t(u)\delta(v,u).}
\tag{ST10}
\]

这是一般 ν 下直接由原门得到的真实两源必要条件；没有冻结 α、重算 QJ、删源归一化或把 β 换成 ν。它消去了门中的 QJ/e_t 与 p_x，仍保留实际 K_u、A_v/w_g(v) 和 score。

然而 ST10 给的是 K_u/w_t(u) 的**上界**。它不为 w_t(u) 提供来源无关的正下界，也不控制 ST5 中的 w_u^{−3γ}、w_v^{−4θ}。K_u 可以与 w_u 一起变小，不能从“来源 C 尾衰减”直接推出其后验质量便宜。ST10 仅在原 good∩high 内使用，不能把相应门删掉后继续宣称它成立。

还有一个直接方向核验：在 c<η_n 上，门幂 (η_n/c)^θ≥1。因此把 low 指示用此幂上界，再只作来源归一化，本身不会制造任何抑制。若保留 low 指示作接收积分，它一般依 x，不能使用删除此门后的固定来源乘积端点并同时声称保留了 low 收益。

准确的二选一是：

1. 保留 low／good／history 的真实 x 依赖，在同一原测度上插值；这由 NC7 允许，但需为该带门端点证明新的实际接收价格。
2. 为调用现有固定来源端点而删除这些正门；得到 ST7／ST8 一类旧费用，low 的几何减少没有被估计，不能登记本轮新付款。

## 4. 限定归一机制与停止边界

有一个可核验的限定机制：若 bad 来源 k_t(u)=0，则 w_t(u)=1，且 R136 ACA2 给每个坐标 |u_i−y_i|<b。实际 K_u 有接收位置依赖的统一正下界；再用 A_v/J_v 的真实核尾比，可在固定参数块内消去两份来源概率质量，而不付 R_t^{7θ}。但该计算即使取 θ=O(1/[n log n])仍只给 O(n) 的 fixed-block score 价；自适应参数和完整外层另需支付。k_t(u)≥1 的原 low 支全部保留。因此按主代理范围要求，不展开这一特殊支长证明，也不登记为一般进展或根阶付款。

三阶段检查：初探 ST3–4 识别来源归一化候选；历史压力核查确认 NC 已支付零阶核损失但保留真实弱负矩；扩大至任意 ν 后，ST9–10 是确实可用的新门化简，尚不足以给 ST2 总价。本文没有运行新数值，不据 R144 有限样本认证一般输入。

本轮的具体缺口不是另一个命名后的能量：需要在 ST2 的同一接收测度下，对 **low＋good＋high** 带门端点作来源平均，既利用 ST10 的 K_u/w_u 限制，又控制 good 端的 A_v/w_g(v)，并给 β、三来源、time/j 和自适应参数的总价。现有无门小幂包络未完成这一项。高 c 已付支不重新领取；futurebad、Ndel、原负项及 low 的全部未覆盖来源仍留原账。

仅写 source_tail.md，未改其他文件，未运行 Git/PDF；完成停止。
