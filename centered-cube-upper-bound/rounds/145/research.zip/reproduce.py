"""python reproduce.py REPO NEW_WORK [checks|full]; Python>=3.11 and mpmath.
checks: saved-point transforms and scalar menu tests; full also repeats 18 integrals.
"""
from pathlib import Path
import sys,json,zipfile,shutil,subprocess
src=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();mode=sys.argv[3] if len(sys.argv)>3 else 'checks'
assert mode in ['checks','full'] and not work.exists();work.mkdir(parents=True)
out=work/'centered_cube_round145_20261015';out.mkdir()
for p in src.iterdir():
 if p.is_file() and p.suffix in ['.py','.md','.json']:shutil.copy2(p,out/p.name)
items=[(144,'numeric_geometry.json','centered_cube_round144_20261015/numeric_geometry.json'),(142,'numeric_receiver.json','centered_cube_round142_20261015/numeric_receiver.json'),(139,'active_traffic_v2.json','centered_cube_round136_20261014/active_traffic_v2.json')]
if mode=='full':
 items += [(136,p,p) for p in ['centered_cube_round135_20261014/real_joint_numeric.py','centered_cube_round136_20261014/active_traffic_v2.py','centered_cube_round136_20261014/fractional_kernel_envelope.md','centered_cube_round136_20261014/fractional_kernel_audit.md']]
for rnd,name,target in items:
 with zipfile.ZipFile(repo/f'centered-cube-upper-bound/rounds/{rnd}/research.zip') as z:data=z.read(name)
 p=work/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def normalized(x):
 if isinstance(x,list):return [normalized(v) for v in x]
 if isinstance(x,dict):return {(Path(k).name if k.startswith('/') else k):normalized(v) for k,v in x.items() if k not in ['elapsed_seconds','started_utc','finished_utc']}
 return x
for name in ['numeric_tail','geometric_margin','menu_cost_check']+(['numeric_kernel'] if mode=='full' else []):
 subprocess.run([sys.executable,str(out/(name+'.py'))],check=True,stdout=subprocess.DEVNULL)
 got=json.loads((out/(name+'.json')).read_text());old=json.loads((src/(name+'.json')).read_text())
 assert normalized(got)==normalized(old),name
 print(name,'PASS',flush=True)
print('PASS: deterministic output reproduced; only timing and absolute path keys normalized.')
