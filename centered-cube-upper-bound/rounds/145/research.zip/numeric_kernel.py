#!/usr/bin/env python3
"""18 frozen one-dimensional true-kernel interpolation probes; no outer/source sampling."""
import sys,json,time,datetime,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'numeric_kernel.json'
SOURCES=[ROOT/'numeric_kernel_plan.md',ROOT.parent/'centered_cube_round135_20261014/real_joint_numeric.py',ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.py',ROOT.parent/'centered_cube_round136_20261014/fractional_kernel_envelope.md',ROOT.parent/'centered_cube_round136_20261014/fractional_kernel_audit.md']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def txt(x,n=38):return mp.nstr(x,n)
def E3(x):
 if x==0:return mp.mpf('.5')
 e=mp.exp(-x);return ((1-x)*e+x*x*mp.e1(x))/2

def E4(x):return mp.mpf(1)/3 if x==0 else (mp.exp(-x)-x*E3(x))/3

def phi(x):
 r=abs(x);h=mp.mpf('.5')
 return 1-E3(h-r)-E3(h+r) if r<=h else E3(r-h)-E3(r+h)
def prim(x):
 if x<0:return -prim(-x)
 h=mp.mpf('.5');return x-E4(h-x)+E4(h+x) if x<=h else h-E4(x-h)+E4(x+h)
def mass(a,b):return prim(b)-prim(a)
def C(x):
 d=abs(x);h=mp.mpf('.5');lo,hi=-h-d,h-d;p,q=max(lo,-h),min(hi,h)
 return mass(lo,hi)+(q-p-mass(p,q) if p<q else 0)
def constants():return 4*mp.e,2/(5*mp.sqrt(mp.e)),2*mp.sqrt(mp.e)
def M(t,s):
 c,a,A=constants();return c**(2+t)*a**(-2*t)*s**(-t)*(mp.exp(3*t/2)*mp.mpf('1.5')**(2*t)+2*A/(1-3*t))
def tail(t,s,L,H,u,v,R):
 c,a,A=constants();K=c**(2+t)*a**(-2*t)*s**(-t)*mp.exp(-(1-t/H)*abs(u)-abs(v))/((1+abs(u))**(1-t)*(1+abs(v)));beta=1-3*t*L
 return 2*K*s*A*mp.exp(-beta*R/L)/beta

def menu():
 out=[]
 initial=[('.5','1','.1','0','0'),('1','.5','.1','0','0'),('.5','.5','1','0','0'),('1','1','1','.49','.51'),('1','.5','.1','.499','.501'),('1','.5','.1','.501','.499')]
 pressure=[('1','.5','.1','8','-8'),('1','.5','.1','16','0'),('1','.5','1','0','16')]
 for phase,rows in [('initial',initial),('pressure',pressure)]:
  for l,(L,H,s,u,v) in enumerate(rows,1):out.append(dict(id=phase[0].upper()+str(l),phase=phase,n=16,L=L,H=H,s=s,u=u,v=v))
 for n in [16,64,256]:
  for l,(L,H,u,v) in enumerate([('.5','1','0','0'),('1','.5','.499','.501'),('1','.5','8','-8')],1):out.append(dict(id='E'+str(n)+'_'+str(l),phase='expanded',n=n,L=L,H=H,s='boundary',u=u,v=v))
 return out
QUADS={}
def integrate(c,dps,order):
 with mp.workdps(dps):
  L,H,u,v=[mp.mpf(c[k]) for k in ['L','H','u','v']];s=1-mp.power(2,-mp.mpf(1)/c['n']) if c['s']=='boundary' else mp.mpf(c['s']);t=mp.mpf(1)/c['n'];t0=mp.mpf('.25');Cu,Cv=C(u),C(v);I0=Cu*Cv;assert 0<Cu<=1 and 0<Cv<=1
  R=max(32,int(mp.ceil(abs(u)+2)),int(mp.ceil(abs(v)+2)))
  while max(tail(z,s,L,H,u,v,R) for z in [t,t0])>mp.mpf('1e-20')*I0:R+=1
  points=set([mp.mpf(-R),mp.mpf(R),mp.mpf(0),u,v,-L/2,L/2,u-H/2,u+H/2,v-mp.mpf('.5'),v+mp.mpf('.5')])
  for b in [1,2,4,8,16,32,64,128]:
   if b<R:points.update([mp.mpf(b),mp.mpf(-b)])
  points=sorted(x for x in points if -R<=x<=R)
  key=(dps,order)
  if key not in QUADS:QUADS[key]=mp.gauss_quadrature(order,'legendre')
  nodes,weights=QUADS[key];sumt=mp.mpf(0);sum0=mp.mpf(0);p_mass=mp.mpf(0);evaluations=0
  for a,b in zip(points,points[1:]):
   mid=(a+b)/2;half=(b-a)/2
   for x,w in zip(nodes,weights):
    d=mid+half*x;pd=((1-s)*int(abs(d/L)<mp.mpf('.5'))+s*phi(d/L))/L;kd=((1-s)*int(abs((d-u)/H)<mp.mpf('.5'))+s*phi((d-u)/H))/H;pv=phi(d-v);assert pd>0 and kd>0 and pv>0
    logratio=mp.log(Cv)-mp.log(kd)-mp.log(pv);base=half*w*pd*I0;sumt+=base*mp.exp(t*logratio);sum0+=base*mp.exp(t0*logratio);p_mass+=half*w*pd;evaluations+=1
  return dict(dps=dps,order=order,Itheta=txt(sumt,dps),Itheta0=txt(sum0,dps),I0=txt(I0,dps),R=R,breakpoints=[txt(x,dps) for x in points],theta=txt(t,dps),s_value=txt(s,dps),p_mass_on_truncation=txt(p_mass,dps),tail_theta=txt(tail(t,s,L,H,u,v,R),dps),tail_theta0=txt(tail(t0,s,L,H,u,v,R),dps),evaluations=evaluations)
def run_case(c):
 start=time.monotonic();a=integrate(c,25,32);b=integrate(c,40,64)
 with mp.workdps(55):
  I,Iref,I0=map(mp.mpf,[b['Itheta'],b['Itheta0'],b['I0']]);t=mp.mpf(1)/c['n'];s=mp.mpf(b['s_value']);alpha=4*t;cap=I0**(1-alpha)*M(mp.mpf('.25'),s)**alpha;actualcap=I0**(1-alpha)*Iref**alpha;error=max(abs(I-mp.mpf(a['Itheta']))/I,abs(Iref-mp.mpf(a['Itheta0']))/Iref);stable=error<=mp.mpf('1e-7');tailratio=max(mp.mpf(b['tail_theta']),mp.mpf(b['tail_theta0']))/I0
  return dict(**c,status='numerically_stable_not_interval_certified' if stable else 'convergence_failure',low=a,high=b,relative_two_precision_order_difference=txt(error),Itheta_over_I0=txt(I/I0),universal_interpolation_cap=txt(cap),universal_cap_over_actual=txt(cap/I),actual_endpoint_interpolation_cap=txt(actualcap),actual_endpoint_cap_over_actual=txt(actualcap/I),M_theta0=txt(M(mp.mpf('.25'),s)),Itheta0_over_I0=txt(Iref/I0),max_explicit_tail_over_I0=txt(tailratio),log_nD_actual=txt(c['n']*mp.log(I)),log_nD_universal_cap=txt(c['n']*mp.log(cap)),log_nD_ratio_to_I0=txt(c['n']*mp.log(I/I0)),interpolation_numerical_violation=actualcap<I*(1-mp.mpf('1e-7')),elapsed_seconds=time.monotonic()-start)
def definition_check():
 import importlib.util
 spec=importlib.util.spec_from_file_location('r135_original_kernel',SOURCES[1]);original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
 with mp.workdps(100):
  xs=['0','.499','.5','.501','1','8','16','128'];rows=[]
  for x in xs:
   z=mp.mpf(x);a,b=phi(z),original.phi(z);c,d=C(z),original.Cfun(z);rows.append(dict(x=x,phi_relative_difference=txt(abs(a-b)/b),C_relative_difference=txt(abs(c-d)/d)))
  err=max(mp.mpf(r[k]) for r in rows for k in ['phi_relative_difference','C_relative_difference']);assert err<mp.mpf('1e-35')
  return dict(precision=100,rows=rows,recovery_note='Supplementary definition check at 50 digits failed for C(128) because cancellation produced zero; moved only definition check to 100 digits. The 18 integral cases use |u|,|v|<=16 and were not rerun.',max_relative_difference=txt(err),scope='Agreement with existing E3/E4 code at eight frozen points only; not a new integral or all-position certificate')
def summarize(out):
 with mp.workdps(55):
  for r in out['cases']:
   if 'high' not in r:continue
   t=mp.mpf(1)/r['n'];ss=mp.mpf(r['high']['s_value']);i0=mp.mpf(r['high']['I0']);cap=mp.mpf(r['universal_interpolation_cap']);r['log_nD_old_FK5_cap']=txt(r['n']*mp.log(M(t,ss)));r['log_nD_universal_cap_over_I0_product']=txt(r['n']*mp.log(cap/i0));r['numerical_p_normalization_residual']=txt(abs(mp.mpf(r['high']['p_mass_on_truncation'])-1))
  valid=[r for r in out['cases'] if 'high' in r]
  out['definition_check']=definition_check();out['script_sha256']=sha(Path(__file__));out['summary']=dict(planned_cases=18,completed_cases=len(valid),stable_cases=sum(r['status']=='numerically_stable_not_interval_certified' for r in valid),convergence_failures=[r['id'] for r in valid if r['status']=='convergence_failure'],interpolation_numerical_violations=[r['id'] for r in valid if r['interpolation_numerical_violation']],max_relative_two_precision_order_difference=txt(max(mp.mpf(r['relative_two_precision_order_difference']) for r in valid)),max_explicit_tail_over_I0=txt(max(mp.mpf(r['max_explicit_tail_over_I0']) for r in valid)),max_p_normalization_residual=txt(max(mp.mpf(r['numerical_p_normalization_residual']) for r in valid)),finite_interval_rigorous_error_certified=False,FULL=False,new_receiver_samples=0,dimension_rate_fitted=False)
 return out
def save(out):OUT.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
def main():
 out=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='18 fixed 1D real-kernel probes only; no old receiver samples, no dimension fitting, no FULL payment',input_sha256={str(p):sha(p) for p in SOURCES},script_sha256=sha(Path(__file__)),menu=menu(),cases=[],finite_interval_certified=False,explicit_tail_formula=True)
 save(out)
 for c in out['menu']:
  try:
   r=run_case(c);out['cases'].append(r);print(c['id'],r['status'],'ratio',r['Itheta_over_I0'],'cap/actual',r['universal_cap_over_actual'],'err',r['relative_two_precision_order_difference'],'seconds',r['elapsed_seconds'],flush=True)
  except Exception as e:
   import traceback
   out['cases'].append(dict(**c,status='exception',error=repr(e),traceback=traceback.format_exc()));print(c['id'],'exception',repr(e),flush=True)
  save(out)
 out.update(status='completed' if all(c['status']=='numerically_stable_not_interval_certified' for c in out['cases']) else 'completed_with_failures',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());summarize(out);save(out)
if __name__=='__main__':main()
