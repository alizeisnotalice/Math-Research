# R145：两来源几何裕量的有效条件与零裕量失败点

结论：原 low/good 两门给出下面的确定性位移条件，但它需要的正几何裕量在本轮恢复的 2070 个既有低核比样本中全部未命中，FA 内部亦如此。因而这条覆盖没有处理已知难例，不登记新付款，不继续扩大三事件估计。这里只保存有效接口与准确未付余部。只写本文件，不 Git/PDF，不改他人文件。

## 1. 可证的几何命题

在每个原实际接收点 \(x\) 上，记
\[
p_x=P_{s,L}(x-y),\quad J_v=P_{1,b}(x-v),\quad K_u=P_{s,H}(x-u),
\quad b/2\le H,L\le b,\quad0<s\le1.
\]
所有参数取其原实际值，允许依 \(x\) 自适应。用 \(K_{\rm good}\) 表示 good 门常数。限于原 \(u\in D_0,v\in G,\delta=(k_t(v)-k_t(u))_+>0\) 的有限正归一化域。两门为
\[
p_xw_g(v)\le K_{\rm good}J_v,\qquad
K_uJ_v<B_{vu}:=\frac{\eta_nTA_vQ_Jw_t(u)\delta}{De_t},
\quad \eta_n=\frac{4(n+1)^2}{3n}.
\tag{LG1}
\]
\(T,A_v,Q_J,e_t\) 保留原共同 \(\nu\)，不另归一。

定义
\[
E=\log\frac{(b/H)^np_x^2w_g(v)^2}{K_{\rm good}^2B_{vu}},\quad
m_u=\#\{i:|x_i-u_i|>H/2\},\quad
\Theta_{vu}=\sum_i\log\frac{\phi((x_i-v_i)/b)}{\phi((x_i-u_i)/H)}.
\tag{LG2}
\]
则原 low/good 交叠必满足
\[
\boxed{E<\Theta_{vu}+m_u\log(1/s).}
\tag{LG3}
\]
证明只需逐坐标实际核比较：hard 内 \((1-s)+s\phi\ge\phi\)，hard 外等于 \(s\phi\)，因为 \(0<\phi\le1\)。所以
\[
K_u\ge s^{m_u}P_{1,H}(x-u)
=s^{m_u}(b/H)^ne^{-\Theta_{vu}}J_v.
\]
将 good 的 \(J_v\ge p_xw_g/K_{\rm good}\) 代入 low 即得 LG3。没有小幂 Markov、\(C_0^n\) 核比较常数或 \(2^n\) 个坐标子集覆盖；\(s^{m_u}\) 是实际必须保留的 soft 费用。

若确有 \(E>0\)，可再用实核的 log-Lipschitz 界
\[
\Theta_{vu}\le\lambda_\phi\left[
\|u-v\|_1/H+(1/H-1/b)\|x-v\|_1\right],\quad
\lambda_\phi=\frac{1-w(1)}{\int_0^1w(r)dr},\quad
w(r)=\int_0^1e^{-r/t}dt.
\tag{LG4}
\]
其简证：在 \([0,1/2]\)，\(-\phi'/\phi=[w(1/2-r)-w(1/2+r)]/\phi(r)\) 非减；在 \((1/2,\infty)\)，\(\phi(r)=\int_0^1 2t\sinh(1/(2t))e^{-r/t}dt\)，故 \(-\phi'/\phi\) 的导数为负方差，非增。最大值正是 \(\lambda_\phi\)。尾部这里是对数凸，未假定混合核联合对数凹。于是正裕量时，hard 外坐标费用、来源距离费用、接收位移费用中至少一项大于 \(E/3\)。本轮不再扩大这一条件分支，因为下一节显示它没有覆盖已知难例。

## 2. 必需裕量与实际压力检查

令
\[
c=\frac{DK_uJ_ve_t}{TA_vQ_Jw_t(u)\delta},\qquad
\gamma_v=\frac{p_xw_g(v)}{K_{\rm good}J_v}\le1.
\]
直接计算有
\[
\boxed{E=n\log(b/H)+2\log\gamma_v+\log(J_v/K_u)+\log(c/\eta_n).}
\tag{LG5}
\]
特别地
\[
 E>0\iff J_v/K_u>(H/b)^n\gamma_v^{-2}\eta_n/c.
\tag{LG6}
\]
low 的 \(c/\eta_n<1\) 与 good 的 \(\gamma_v\le1\) 都不能提供正裕量；还需要实际核偏斜满足 LG6。既有 \(c/\eta_n\le9.13\times10^{-6}\) 的筛查本身不足判断。

主代理本轮从原 R142 记录恢复 \(w_g,H,b,K_{\rm good},p,J_v,K_u\)，实际运行 `geometric_margin.py`，在同一 2070 点上按 LG5 计算；结果保存于 `geometric_margin.json`。本作者读取了该结果，未重复核积分或把该浮点诊断称为全窗认证。

| 实际样本组 | 点数 | 最大 \(E\) | \(E>0\) 点数 | FA 内部 \(E>0\) 点数 |
|---|---:|---:|---:|---:|
| I1 initial | 18 | −8.21606 | 0 | 0 |
| I1 expanded | 81 | −8.21982 | 0 | 0 |
| P1 initial | 297 | −28.96561 | 0 | 0 |
| P1 pressure | 45 | −19.22295 | 0 | 0 |
| P1 expanded | 1629 | −25.05199 | 0 | 0 |

所以 LG4 的正裕量覆盖在这批已知难点中没有提供任何认证分支。这不是一般反例，但足以停止把该三事件分解当成本轮解决 low 尾的主张。

## 3. 必须原位保留的零裕量交通

零裕量域准确为
\[
 E\le0\iff p_x^2w_g(v)^2\le
 K_{\rm good}^2(H/b)^n
 \frac{\eta_nTA_vQ_Jw_t(u)\delta}{De_t}.
\tag{LG7}
\]
右侧仍含完整来源归一化量与尺度因子；\(w_g(v)\) 又没有统一正下界。故不能把它命名为“小接收密度”后宣布 \(p_xdx\) 有小概率。已恢复的样本全部留在此余部。单给 LG4 的来源位移上界或固定尺度接收积分，均不支付 LG7。

记 \(\mathfrak P[f]\) 为原尚未付正交通插入 \(f\) 的完整积分，包含
\[
2\Lambda\mathbb E\sum_{V,j}\int q^{-1}p_xh_R(x-z)
\rho_v\Psi\chi_{FA}\chi_{\rm history}\,
\delta\frac{w_t(v)w_t(u)}{e_t^2}f\,
 dx\,d\beta(y)d\nu(z)d\nu(v)d\nu(u)\frac{dt}{t},
\]
及全部原 good/bad、hard、旧已付补集、唯一 \(j\)、合法时间窗和层级资格。若 \(L\) 表示 LG1，两来源几何路线至少仍须支付
\[
\mathfrak P[1_L1_{E\le0}]
\quad\text{以及}\quad\mathfrak P[1_L1_{E>0}],
\qquad
\mathfrak P[1_L]\le\varepsilon X+C_\varepsilon\sqrt n\log^A(2+n)W_\beta.
\tag{LG8}
\]
第二项虽有 LG3--4 的几何条件，预算也未证。第一项是本路线的具体主缺口：需要保留 LG7 中的真实 \(p_x^2w_g^2\) 与 \(TA_vQ_Jw_t(u)\delta/e_t\) 关联，直接估计其原交通，而不是删源、给 \(\nu\) 添加距离矩、或冻结自适应尺度。两份 \(e_t^{-1}\)、\(q\)、外 hard 来源、\(\beta\)、原共同 \(\nu\) 和参数费用全部留在 LG8。

初探完成 LG3 的真实两来源比较，既有压力检验显示正裕量 0 命中；扩大到一般输入时没有足够预算，故停止。R144 已付 high 子支不重复领取；原 Ψ 内负项、futurebad、\(N_{\rm del}\) 及其余旧余部保留。没有用单原子或固定尺度替代一般输入，没有重复后缀恒等式，没有新的全局付款。
